#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI 自造工艺书数据集 · md → xlsx 转换器（task-167 / T-176，2026-11-19）。

背景（T-170 实测卡点）：
    `tests/fixtures/process_sheet_benchmark_ai/` 只有 .md 正文。主链能跑（10 阶段 7/7）
    但 L2 召回 0/21：md 被 `deepparse._parse_md` 解析成「段/参数」，而平台确定性执行器
    （`app.engine.ruleexec.judge_limit_rule` 等）按「工序页 + 行 + L 列」的 xlsx 文本绑定，
    md 模式下取数作用域失效 → 47 条 insufficient。对照程序化基准（xlsx+md 双格式）
    可计算召回 160/160 = 100%。

本脚本做两件事（都不改产品代码）：
    1) 把 AI 生成的 md 工艺书按**平台内置食品包**的版式写成 xlsx：
       版式常量照抄 `tools/build_benchmark_bulk.py`
       （R_TITLE/R_DATE/R_VERSION/R_PROC_NAME/R_PROD/R_RAW_HEAD/R_STEP_START、
        标准工序五列 A/F/L/Q/U、签署列 col=19+i*4、商品名 N7、工艺参数表与工序页 L 列同源），
       生成 `工艺参数表`，并固定 docProps 时间 + 规范化 zip 条目时间 → 两次生成字节一致。
    2) 把 gold.json 的证据文本从「md 表格整行」迁移为「xlsx 单元格/表头行」口径：
       注入点与缺陷语义不变，只把 `evidence_text/clean_text/injected_text/location`
       表示成平台 xlsx 解析后的逐字文本（与程序化基准 gold 同口径）。
       迁移前 md 口径原样保存为 `gold_md_source.json`，可审计、可回溯。

硬约束（AGENTS.md 铁律 6）：
    · 第一条可执行语句断言 RULEPROOF_DB 指向 /tmp 下的临时库（本脚本不 import app 层，
      也不连接任何数据库，断言用于和全仓脚本口径保持一致）；
    · 绝不读写 `data/ruleproof.db`；不修改产品代码；不碰 `dist/`。

用法：
    cd platform
    PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
    $PY tools/md_to_xlsx.py --bench tests/fixtures/process_sheet_benchmark_ai
    $PY tools/md_to_xlsx.py --bench tests/fixtures/process_sheet_benchmark_ai --verify-repro
    $PY tools/md_to_xlsx.py --bench tests/fixtures/process_sheet_benchmark_ai --check

退出码：0 = 全部通过；1 = 有文件/校验失败（stderr 打印原因）。
"""
from __future__ import annotations

# —— 铁律 6：第一条可执行语句断言临时库（不 import app，也不连库）——
import os
import sys

_DB = str(os.environ.get("RULEPROOF_DB") or "").strip()
if not _DB:
    os.makedirs("/tmp/mdx", exist_ok=True)
    _DB = "/tmp/mdx/md_to_xlsx_%d.sqlite" % os.getpid()
    os.environ["RULEPROOF_DB"] = _DB
_TMP_PREFIXES = ("/tmp/", "/private/tmp/", "/var/folders/", "/private/var/folders/")
if not _DB.startswith(_TMP_PREFIXES):
    sys.stderr.write(
        "[FATAL] RULEPROOF_DB 必须指向 /tmp 下临时库（铁律 6），当前=%r；拒绝运行\n" % _DB)
    raise SystemExit(2)

import argparse  # noqa: E402
import hashlib  # noqa: E402
import json  # noqa: E402
import re  # noqa: E402
import shutil  # noqa: E402
import tempfile  # noqa: E402
import zipfile  # noqa: E402
from datetime import datetime  # noqa: E402
from pathlib import Path  # noqa: E402

try:
    from openpyxl import Workbook, load_workbook
except Exception as _e:  # noqa: BLE001 - 缺 openpyxl 必须显式报错，不静默降级
    sys.stderr.write("[FATAL] 需要 openpyxl：%s\n" % _e)
    raise SystemExit(2)

ROOT = Path(__file__).resolve().parents[1]                      # platform/
DEFAULT_BENCH = ROOT / "tests" / "fixtures" / "process_sheet_benchmark_ai"

# ---------------------------------------------------------------- 版式常量
# 全部照抄 tools/build_benchmark_bulk.py（与 app/engine/engine.py:parse_xlsx 的
# 标签/偏移约定一致；benchmark 基准实跑可计算召回 160/160）：
#   · 工序页：A1 标题、A3 实施日期/C3 值、A4 版本号/C4 值、A7 工序名称/C7 值、
#     K7 商品名 / N7 商品名值（标签+3）、A11 生产数…、A14 原材料名、
#     A22 制造作业标准书、A23 标准工序表头、R24 起工序行；
#     五个工序列 = A(工序)/F(作业内容)/L(作业条件)/Q(作业要点)/U(器具)；
#     签署列 = col 19 + i*4（S/W/AA/AE），标签在 R3、值在 R4。
#   · 包装指示书：设计总重量标签 G4、值 J4、单位 N4；包材清单 序号/名称/编号/规格/数量。
#   · 工艺参数表：从工序页单元格回填（D 列 = 工序页 L 列），保证同源。
R_TITLE, R_DATE, R_VERSION, R_PROC_NAME, R_PROD, R_RAW_HEAD = 1, 3, 4, 7, 7, 14
R_MATERIAL_START = 15
R_STD_DOC, R_STD_HEAD, R_STEP_START = 22, 23, 24
R_MAX_STEP_ROWS = 22
SIGN_ROLES = ["研发经理", "生产经理", "品管经理", "研发"]
# 标准工序五列 → openpyxl 列号
STEP_COLS = {"工序": 1, "作业内容": 6, "作业条件": 12, "作业要点": 17, "器具": 21}
STEP_COL_LETTERS = {"工序": "A", "作业内容": "F", "作业条件": "L", "作业要点": "Q", "器具": "U"}

# 固定 docProps 时间 + zip 条目时间（照抄 build_benchmark_bulk.py 的 FIXED_TIME）：
# openpyxl 保存会用“当前时间”覆盖 core.xml，只设 wb.properties 不够，必须回写。
FIXED_TIME = datetime(2026, 11, 19, 9, 30, 0)
_FIXED_UTC = "2026-11-19T09:30:00Z"
_FIXED_ZIP_DATE = (2026, 11, 19, 9, 30, 0)
PROPS_CREATOR = "process_sheet_benchmark_ai/md_to_xlsx.py"

SHEET_TITLE_SUFFIX = " 车间作业标准书"
PKG_SHEET_NAME = "包装指示书"
PARAM_SHEET_NAME = "工艺参数表"
PARAM_NOTE = ("参数来源：企业自定工艺参数（AI 生成内容；85℃/200ppm/10℃/0-8℃/20h "
              "为平台点位判据，非国标强制值）")

# md 表头四要素 → 表格列名（顺序固定，与 AI 提示词 A 的输入契约一致）
STEP_HEADER = ["工序", "作业内容", "作业条件", "作业要点", "器具"]


# ---------------------------------------------------------------- md 解析

_BULLET_RE = re.compile(r"^-\s*([^：:]+?)\s*[：:]\s*(.*)$")
_SHEET_RE = re.compile(r"^##\s*Sheet[:：]\s*(.+)$")
_SEP_CELL_RE = re.compile(r"^:?-{2,}:?$")


def _split_table_row(line: str) -> list:
    """`| a | b |` → ['a','b']（去首尾竖线与单元格首尾空白，保留单元格内部原文）。"""
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def parse_md(path: Path) -> dict:
    """解析 AI 工艺书 md：`## Sheet:` 分段 + 表头四要素 + 标准工序五列表 + 包装指示书。"""
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    doc = {"source": str(path), "title": "", "sheets": [],
           "packaging": None, "raw_text": text}
    cur = None
    for line in lines:
        s = line.strip()
        m = _SHEET_RE.match(s)
        if m:
            cur = {"name": m.group(1).strip(), "bullets": [], "steps": []}
            doc["sheets"].append(cur)
            continue
        if cur is None:
            if s.startswith("# ") and not doc["title"]:
                doc["title"] = s[2:].strip()
            continue
        if not s:
            continue
        if s.startswith("- "):
            bm = _BULLET_RE.match(s)
            if bm:
                cur["bullets"].append((bm.group(1).strip(), bm.group(2).strip()))
            continue
        if s.startswith("|"):
            cells = _split_table_row(s)
            if len(cells) < len(STEP_HEADER):
                continue
            if all(_SEP_CELL_RE.match(c) for c in cells):
                continue
            if cells[0] == STEP_HEADER[0] and cells[1:] == STEP_HEADER[1:]:
                continue  # 表头行
            cur["steps"].append(cells[:len(STEP_HEADER)])
            continue
    # 表头四要素 + 包装字段
    for sheet in doc["sheets"]:
        b = {k: v for k, v in sheet["bullets"]}
        sheet["impl_date"] = b.get("实施日期", "")
        sheet["version"] = b.get("版本号", "")
        sheet["product"] = b.get("商品名", "")
        sheet["sign"] = _parse_sign(b.get("签署", ""))
        if PKG_SHEET_NAME in sheet["name"]:
            doc["packaging"] = _parse_packaging(sheet, b, doc)
    doc["process_sheets"] = [s for s in doc["sheets"] if PKG_SHEET_NAME not in s["name"]]
    return doc


def _parse_sign(text: str) -> dict:
    """`研发经理 陈一鸣 / 生产经理 周立 / ...` → {role: name}。"""
    out = {}
    for tok in re.split(r"\s*/\s*", text or ""):
        tok = tok.strip()
        if not tok:
            continue
        for role in sorted(SIGN_ROLES, key=len, reverse=True):
            if tok.startswith(role):
                name = tok[len(role):].strip(" :：")
                if name:
                    out[role] = name
                break
    return out


def _fmt_num(s: str):
    """'380' → 380(int)；'7.2' → 7.2(float)；解析不了原样返回。"""
    s = str(s).strip()
    try:
        f = float(s)
    except ValueError:
        return s
    return int(f) if f.is_integer() else f


def _parse_packaging(sheet: dict, b: dict, doc: dict) -> dict:
    design_raw = b.get("设计总重量", "")
    m = re.search(r"(\d+(?:\.\d+)?)\s*(kg|g|千克|克)", design_raw)
    design_total, design_unit = (None, "")
    if m:
        design_total, design_unit = _fmt_num(m.group(1)), m.group(2)
    materials = []
    mat_raw = b.get("包材清单（序号连续）") or b.get("包材清单") or ""
    if not mat_raw:
        # 有些 AI 稿的包材清单写在标题行下一行的 `- 包材清单：` 里（无序号）
        for k, v in sheet["bullets"]:
            if k.startswith("包材清单") and v:
                mat_raw = v
                break
    for part in re.split(r"\s*/\s*", mat_raw or ""):
        part = part.strip()
        if not part:
            continue
        mm = re.match(r"^(\d+)\s+(.+)$", part)
        seq, name = (mm.group(1), mm.group(2).strip()) if mm else ("", part)
        if name:
            materials.append({"seq": seq, "name": name})
    return {
        "sheet": sheet["name"],
        "impl_date": sheet.get("impl_date", ""),
        "version": sheet.get("version", ""),
        "product": sheet.get("product") or doc.get("title", "").replace(" 工艺书", ""),
        "sign": sheet.get("sign", {}),
        "design_total": design_total,
        "design_unit": design_unit,
        "design_raw": design_raw,
        "listing_date": b.get("上市日期", ""),
        "revision": b.get("修订记录", ""),
        "materials": materials,
        "bullets": list(sheet["bullets"]),
    }


# ---------------------------------------------------------------- xlsx 构造

def _sign_cell_col(role: str) -> int:
    return 19 + SIGN_ROLES.index(role) * 4


def _write_process_sheet(ws, doc: dict, sheet: dict):
    title = sheet.get("product") or ""
    ws.cell(R_TITLE, 1, sheet["name"] + SHEET_TITLE_SUFFIX)
    ws.cell(R_DATE, 1, "实施日期")
    ws.cell(R_DATE, 3, sheet["impl_date"])
    ws.cell(R_VERSION, 1, "版本号")
    ws.cell(R_VERSION, 3, sheet["version"])
    ws.cell(R_PROC_NAME, 1, "工 序  名  称")
    ws.cell(R_PROC_NAME, 3, sheet["name"])
    ws.cell(R_PROD, 11, "商品名")
    ws.cell(R_PROD, 14, title)
    for role in SIGN_ROLES:
        col = _sign_cell_col(role)
        ws.cell(R_DATE, col, role)
        ws.cell(R_DATE + 1, col, sheet.get("sign", {}).get(role, ""))
    ws.cell(11, 1, "生产数")
    ws.cell(11, 8, "净重")
    ws.cell(11, 13, "毛重")
    ws.cell(11, 18, "备注")
    ws.cell(R_RAW_HEAD, 1, "原 材 料 名")
    ws.cell(R_RAW_HEAD, 2, "投入量合计（确认用）")
    # md 正文只有工序表，没有原材料清单：只写表头标签（与基准布局一致），不臆造投料量
    ws.cell(R_STD_DOC, 1, "制造作业标准书")
    ws.cell(R_STD_HEAD, 1, "标准工序")
    ws.cell(R_STD_HEAD, 4, "蒸气压")
    ws.cell(R_STD_HEAD, 6, "作业内容")
    ws.cell(R_STD_HEAD, 12, "作业条件")
    ws.cell(R_STD_HEAD, 17, "作业要点")
    ws.cell(R_STD_HEAD, 21, "器具")
    for i, cells in enumerate(sheet["steps"][:R_MAX_STEP_ROWS]):
        r = R_STEP_START + i
        for idx, key in enumerate(STEP_HEADER):
            if cells[idx]:
                ws.cell(r, STEP_COLS[key], cells[idx])


def _write_packaging_sheet(ws, doc: dict):
    pkg = doc["packaging"]
    ws.cell(1, 1, "商品包装指示书")
    ws.cell(2, 1, "实施日期")
    ws.cell(2, 3, pkg.get("impl_date", ""))
    ws.cell(2, 5, "上市日期")
    ws.cell(2, 7, pkg.get("listing_date", ""))
    ws.cell(2, 10, "商品名")
    ws.cell(2, 13, pkg.get("product", ""))
    for i, role in enumerate(SIGN_ROLES):
        col = 28 + i * 4
        ws.cell(2, col, role)
        ws.cell(3, col, (pkg.get("sign") or {}).get(role, ""))
    ws.cell(4, 1, "版本号")
    ws.cell(4, 3, pkg.get("version", ""))
    ws.cell(4, 7, "设计总重量")
    if pkg.get("design_total") is not None:
        ws.cell(4, 10, pkg["design_total"])
    ws.cell(4, 14, pkg.get("design_unit", ""))
    ws.cell(5, 1, "修订记录")
    ws.cell(5, 3, pkg.get("revision", ""))
    ws.cell(24, 1, "序号")
    ws.cell(24, 2, "包材相关")
    ws.cell(26, 2, "名称")
    ws.cell(26, 4, "包材编号")
    ws.cell(26, 6, "规格")
    ws.cell(26, 9, "数量")
    for i, mat in enumerate(pkg.get("materials") or []):
        r = 27 + i
        seq = mat.get("seq", "")
        ws.cell(r, 1, _fmt_num(seq) if str(seq).isdigit() else seq)
        ws.cell(r, 2, mat.get("name", ""))


def _write_param_sheet(ws, wb: Workbook, doc: dict):
    """工艺参数表：逐条取工序页 A/F/L 单元格（与工序页 L 列同源，与基准口径一致）。"""
    ws.cell(1, 1, PARAM_SHEET_NAME)
    ws.cell(2, 1, PARAM_NOTE)
    for j, h in enumerate(["序号", "工序", "作业内容", "作业条件", "监测方式"], start=1):
        ws.cell(4, j, h)
    row = 5
    for sheet in doc["process_sheets"]:
        src = wb[sheet["name"]]
        for i in range(R_STEP_START, R_STEP_START + R_MAX_STEP_ROWS):
            a = src.cell(i, 1).value
            if a is None or str(a).strip() == "":
                continue
            ws.cell(row, 1, row - 4)
            ws.cell(row, 2, str(a).strip())
            f = src.cell(i, 6).value
            l = src.cell(i, 12).value
            if f:
                ws.cell(row, 3, str(f))
            if l:
                ws.cell(row, 4, str(l))
            ws.cell(row, 5, "工序自检 + 品管抽检")
            row += 1


def _fix_props(wb: Workbook):
    pr = wb.properties
    pr.creator = PROPS_CREATOR
    pr.lastModifiedBy = "process_sheet_benchmark_ai"
    pr.created = FIXED_TIME
    pr.modified = FIXED_TIME
    pr.title = "工艺书 AI 数据集（md→xlsx 转换）"


def _normalize_xlsx_zip(path: Path):
    """固定 zip 条目时间戳 + docProps/core.xml 时间，保证重复构建字节级一致（SHA 可复现）。"""
    tmp = path.with_suffix(".xlsx.tmp")
    with zipfile.ZipFile(path, "r") as zin, \
            zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name in zin.namelist():
            data = zin.read(name)
            if name == "docProps/core.xml":
                text = data.decode("utf-8")
                for tag in ("created", "modified"):
                    text = re.sub(
                        rf"(<dcterms:{tag}[^>]*>)[^<]*(<)",
                        rf"\g<1>{_FIXED_UTC}\g<2>", text)
                data = text.encode("utf-8")
            zi = zipfile.ZipInfo(name, date_time=_FIXED_ZIP_DATE)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o600 << 16
            zout.writestr(zi, data)
    tmp.replace(path)


def save_workbook(wb: Workbook, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    _normalize_xlsx_zip(path)


def build_workbook(doc: dict) -> Workbook:
    wb = Workbook()
    wb.remove(wb.active)
    for sheet in doc["process_sheets"]:
        ws = wb.create_sheet(sheet["name"])
        _write_process_sheet(ws, doc, sheet)
    pkg = doc.get("packaging")
    if pkg:
        _write_packaging_sheet(wb.create_sheet(PKG_SHEET_NAME), doc)
    _write_param_sheet(wb.create_sheet(PARAM_SHEET_NAME), wb, doc)
    _fix_props(wb)
    return wb


def convert_file(md_path: Path, xlsx_path: Path) -> dict:
    doc = parse_md(md_path)
    if not doc["process_sheets"]:
        raise SystemExit("[FATAL] %s 未解析到任何 `## Sheet:` 工序页" % md_path)
    wb = build_workbook(doc)
    save_workbook(wb, xlsx_path)
    return doc


# ---------------------------------------------------------------- xlsx 文本视图（与平台解析同口径）
# 平台 `app.engine.deepparse._parse_xlsx` 的文本口径：逐个 Sheet、逐行取非空单元格，
# 用 " | " 连接成一行（anchor = sheet 名）。gold 证据必须能在这份文本里逐字命中。
def xlsx_text_rows(path: Path) -> list:
    wb = load_workbook(path, read_only=True, data_only=True)
    rows = []
    try:
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                cells = [str(c).strip() for c in row if c is not None and str(c).strip()]
                if cells:
                    rows.append((ws.title, " | ".join(cells)))
    finally:
        wb.close()
    return rows


# ---------------------------------------------------------------- gold 证据口径迁移

# 表头四要素/包装字段 → xlsx 中「标签 → (行, 列)」映射（用于 md 项目符号行的证据定位）
BULLET_CELL = {
    "实施日期": (3, "C"), "版本号": (4, "C"), "商品名": (7, "N"),
    "设计总重量": (4, "J"), "修订记录": (5, "C"),
}


def _md_line_to_step_index(doc: dict, sheet_name: str, line_no: int):
    """md 文件里的 1-based 行号 → 该 Sheet 的标准工序数据行下标（0-based）。"""
    sheet = next((s for s in doc["sheets"] if s["name"] == sheet_name), None)
    if not sheet:
        return None
    # 重新扫描 md，统计该 Sheet 内 line_no 之前出现的数据行数
    lines = doc["raw_text"].splitlines()
    cur, idx = None, 0
    for i, line in enumerate(lines, start=1):
        s = line.strip()
        m = _SHEET_RE.match(s)
        if m:
            cur = m.group(1).strip()
            idx = 0
            continue
        if cur != sheet_name or not s.startswith("|"):
            continue
        cells = _split_table_row(s)
        if len(cells) < len(STEP_HEADER):
            continue
        if all(_SEP_CELL_RE.match(c) for c in cells):
            continue
        if cells[0] == STEP_HEADER[0] and cells[1:] == STEP_HEADER[1:]:
            continue
        if i == line_no:
            return idx
        idx += 1
    return None


def _find_md_file(input_dir: Path, layer: str, num: str) -> Path:
    hits = sorted(input_dir.glob("%s_%s_*.md" % (layer, num)))
    if len(hits) != 1:
        raise SystemExit("[FATAL] %s_%s_*.md 命中 %d 个（应为 1）" % (layer, num, len(hits)))
    return hits[0]


def migrate_gold_entries(bench: Path, docs: dict) -> dict:
    """把 gold.json 的 evidence/clean/injected/location 迁到 xlsx 口径（注入点不变）。

    docs: {file_id: parsed_md_dict}（L1+L2）。
    返回 {"gold": 新 gold, "md_source": 旧 gold, "stats": {...}, "entries": [...]}。
    """
    input_dir = bench / "input"
    gold_path = bench / "gold.json"
    gold = json.loads(gold_path.read_text(encoding="utf-8"))
    md_source = json.loads(json.dumps(gold, ensure_ascii=False))  # 深拷贝留档
    changed, failures = 0, []
    for e in gold.get("entries") or []:
        fid = str(e.get("file_id") or "")
        m = re.match(r"PS-(L[12])-(\d+)$", fid)
        if not m:
            failures.append((e.get("issue_id"), "file_id 非法：%r" % fid))
            continue
        layer, num = m.group(1), m.group(2)
        l2_md = _find_md_file(input_dir, layer, num)
        l1_md = _find_md_file(input_dir, "L1", num)
        l2_doc, l1_doc = docs[l2_md.name], docs[l1_md.name]
        loc = e.get("location") or {}
        line_no = loc.get("row")
        sheet_name = loc.get("sheet") or ""
        if not isinstance(line_no, int) or line_no < 1:
            failures.append((e.get("issue_id"), "location.row 缺失/非法：%r" % line_no))
            continue
        l2_lines = l2_doc["raw_text"].splitlines()
        l1_lines = l1_doc["raw_text"].splitlines()
        if line_no > len(l2_lines) or line_no > len(l1_lines):
            failures.append((e.get("issue_id"), "line_no 越界：%d" % line_no))
            continue
        line2, line1 = l2_lines[line_no - 1].strip(), l1_lines[line_no - 1].strip()
        new_loc = {"page": None, "sheet": sheet_name, "row": None, "col": None}
        ev = cl = inj = ""
        if line2.startswith("|"):
            cells2, cells1 = _split_table_row(line2), _split_table_row(line1)
            if len(cells2) < len(STEP_HEADER) or len(cells1) < len(STEP_HEADER):
                failures.append((e.get("issue_id"), "表格行列数不足（%d/%d）" % (len(cells2), len(cells1))))
                continue
            diffs = [i for i in range(len(STEP_HEADER)) if cells2[i] != cells1[i]]
            if len(diffs) != 1:
                failures.append((e.get("issue_id"), "单元格差异数=%d（应为 1）：%r" % (len(diffs), diffs)))
                continue
            j = diffs[0]
            ev, cl = cells2[j], cells1[j]
            inj = ev
            step_idx = _md_line_to_step_index(l2_doc, sheet_name, line_no)
            if step_idx is None:
                failures.append((e.get("issue_id"), "未定位到工序行下标（sheet=%r line=%d）"
                                 % (sheet_name, line_no)))
                continue
            new_loc["row"] = R_STEP_START + step_idx
            new_loc["col"] = STEP_COL_LETTERS[STEP_HEADER[j]]
        elif line2.startswith("- "):
            bm2, bm1 = _BULLET_RE.match(line2), _BULLET_RE.match(line1)
            if not bm2 or not bm1:
                failures.append((e.get("issue_id"), "项目符号行无法解析：%r" % line2[:60]))
                continue
            key2, val2 = bm2.group(1).strip(), bm2.group(2).strip()
            key1, val1 = bm1.group(1).strip(), bm1.group(2).strip()
            if key2 != key1:
                failures.append((e.get("issue_id"), "项目符号键不一致：%r vs %r" % (key1, key2)))
                continue
            ev, cl, inj = "%s | %s" % (key2, val2), "%s | %s" % (key1, val1), "%s | %s" % (key2, val2)
            cell = BULLET_CELL.get(key2)
            if cell:
                new_loc["row"], new_loc["col"] = cell
        else:
            failures.append((e.get("issue_id"), "注入行既非表格行也非项目符号行：%r" % line2[:60]))
            continue
        e["evidence_text"] = ev
        e["clean_text"] = cl
        e["injected_text"] = inj
        e["location"] = new_loc
        changed += 1
    # 校验：xlsx 解析文本视图里必须逐字命中 evidence_text
    verify_fail = []
    for e in gold.get("entries") or []:
        rows = docs.get("__xlsx_rows__", {}).get(str(e.get("file_id")))
        if rows is None:
            continue
        if not any(ev in row for _, row in rows for ev in [str(e.get("evidence_text") or "")]):
            verify_fail.append(e.get("issue_id"))
    return {"gold": gold, "md_source": md_source, "changed": changed,
            "failures": failures, "verify_fail": verify_fail}


# ---------------------------------------------------------------- 数据集整体转换

def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_shasums(bench: Path) -> list:
    files = sorted([p for p in (bench / "input").glob("*") if p.is_file()]
                   + [p for p in bench.glob("*") if p.is_file() and p.name != "SHA256SUMS"
                      and p.parent == bench])
    lines = ["%s  %s" % (_sha256(p), p.relative_to(bench)) for p in files]
    (bench / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return lines


def convert_benchmark(bench: Path, rewrite_gold: bool = True,
                      update_meta: bool = True) -> dict:
    """把 bench/input/*.md 全部转成同名 .xlsx；可选迁移 gold.json 证据口径并更新 meta/SHA。"""
    input_dir = bench / "input"
    md_files = sorted(input_dir.glob("*.md"))
    if not md_files:
        raise SystemExit("[FATAL] %s 下没有 .md" % input_dir)
    docs, ok, failed = {}, [], []
    for md in md_files:
        xlsx = md.with_suffix(".xlsx")
        try:
            doc = convert_file(md, xlsx)
            docs[md.name] = doc
            ok.append((md, xlsx))
        except SystemExit:
            raise
        except Exception as e:  # noqa: BLE001 - 逐文件失败必须如实汇总，不中断
            failed.append((md.name, "%s: %s" % (type(e).__name__, e)))
    # xlsx 文本视图（gold 证据校验用）
    xlsx_rows = {}
    for md, xlsx in ok:
        layer = md.name.split("_", 1)[0]
        num = md.name.split("_")[1]
        xlsx_rows["PS-%s-%s" % (layer, num)] = xlsx_text_rows(xlsx)
    docs["__xlsx_rows__"] = xlsx_rows
    result = {"converted": [(str(md.relative_to(bench)), str(xlsx.relative_to(bench)))
                            for md, xlsx in ok],
              "failed": failed, "gold": None, "md_source": None}
    if rewrite_gold:
        mig = migrate_gold_entries(bench, docs)
        if mig["failures"]:
            result["gold_failures"] = mig["failures"]
            raise SystemExit("[FATAL] gold 证据迁移失败 %d 条：%r"
                             % (len(mig["failures"]), mig["failures"][:5]))
        if mig["verify_fail"]:
            raise SystemExit("[FATAL] gold evidence 未在 xlsx 解析文本中逐字命中：%r"
                             % mig["verify_fail"][:5])
        gold = mig["gold"]
        gold["version"] = "0.2.0"
        gold["stats"] = _gold_stats(gold)
        gold["conversion"] = {
            "from": "md 表格整行文本（md 口径，2026-11-19 首版）",
            "to": "xlsx 单元格 / 表头标签行文本（平台 deepparse._parse_xlsx 同口径）",
            "by": "tools/md_to_xlsx.py::migrate_gold_entries",
            "scope": "仅 evidence_text/clean_text/injected_text/location 表示形式；"
                     "注入点、缺陷类型、点位、severity、computable 不变",
            "md_source_backup": "gold_md_source.json（转换前原样留档）",
            "entries_changed": mig["changed"],
        }
        (bench / "gold.json").write_text(
            json.dumps(gold, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        (bench / "gold_md_source.json").write_text(
            json.dumps(mig["md_source"], ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        result["gold"] = gold
        result["md_source"] = mig["md_source"]
    if update_meta:
        meta_path = bench / "meta.json"
        meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.is_file() else {}
        meta["version"] = "0.2.0"
        meta["formats"] = {"md": len(md_files), "xlsx": len(ok)}
        meta["document_roles"] = {
            "xlsx": "平台内置食品工艺包（app.engine.engine.parse_xlsx / deepparse）可解析；"
                    "确定性执行器按工序页 + 行 + L 列取数",
            "md": "AI 生成正文原稿（转换输入）；gold 逐字性由 md 构造保证，转换后 gold 迁移为 xlsx 口径",
        }
        meta["conversion"] = {
            "generator": "tools/md_to_xlsx.py",
            "method": "md（## Sheet: 分段 + 表头四要素 + 标准工序五列表 + 包装指示书）→ "
                      "xlsx（工序页/包装指示书/工艺参数表）",
            "layout_source": "tools/build_benchmark_bulk.py::_write_process_sheet/build_workbook 版式常量照抄",
            "constants": {
                "R_TITLE": R_TITLE, "R_DATE": R_DATE, "R_VERSION": R_VERSION,
                "R_PROC_NAME": R_PROC_NAME, "R_PROD": R_PROD, "R_RAW_HEAD": R_RAW_HEAD,
                "R_MATERIAL_START": R_MATERIAL_START, "R_STD_DOC": R_STD_DOC,
                "R_STD_HEAD": R_STD_HEAD, "R_STEP_START": R_STEP_START,
                "R_MAX_STEP_ROWS": R_MAX_STEP_ROWS, "SIGN_ROLES": SIGN_ROLES,
                "step_cols": STEP_COLS, "product_cell": "N7", "sign_cols": "19+i*4",
            },
            "generated_sheets": ["工序页（每个 ## Sheet，除包装指示书）", PKG_SHEET_NAME,
                                 PARAM_SHEET_NAME + "（与工序页 L 列同源）"],
            "reproducible": {
                "fixed_docprops_time": FIXED_TIME.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "normalized_zip": "zip 条目时间戳固定 + docProps/core.xml 回写",
                "check": "两次生成字节一致（sha256 对比，见 scripts/qa/ai_dataset_xlsx_eval.py）",
            },
            "gold_evidence_migration": {
                "why": "md 口径 evidence_text 是表格整行（含 |），平台 xlsx 解析文本按单元格"
                       "拼接；不迁移则召回必然 0（与 T-170 卡点同源）",
                "from": "md 表格整行 / 项目符号行",
                "to": "xlsx 单元格原文 / 表头标签行（如 `版本号 | X`）",
                "invariant": "注入点（行/格）、缺陷类型、点位、severity、computable 不变；"
                             "evidence 仍是注入后原文，可由 gold_md_source.json 逐条回溯",
            },
        }
        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=1) + "\n",
                             encoding="utf-8")
    sums = write_shasums(bench)
    result["sha256sums"] = sums
    return result


def _gold_stats(gold: dict) -> dict:
    entries = gold.get("entries") or []
    comp = [e for e in entries if e.get("computable")]

    def _count(key):
        out = {}
        for e in entries:
            out[str(e.get(key))] = out.get(str(e.get(key)), 0) + 1
        return out

    return {
        "entries": len(entries),
        "l1": len([e for e in entries if str(e.get("layer")) == "L1"]),
        "l2": len([e for e in entries if str(e.get("layer")) == "L2"]),
        "computable": len(comp),
        "semantic": len(entries) - len(comp),
        "by_point": _count("point_code"),
        "by_defect_type": _count("defect_type"),
        "by_severity": _count("severity"),
    }


def check_benchmark(bench: Path) -> dict:
    """离线自检（不跑主链）：xlsx↔md 数量、字节可复现、布局/解析口径。"""
    input_dir = bench / "input"
    mds = sorted(input_dir.glob("*.md"))
    xlsxs = sorted(input_dir.glob("*.xlsx"))
    out = {"md": len(mds), "xlsx": len(xlsxs), "missing_xlsx": [], "repro": [],
           "failures": []}
    md_by_stem = {p.stem: p for p in mds}
    xlsx_by_stem = {p.stem: p for p in xlsxs}
    for stem, md in md_by_stem.items():
        if stem not in xlsx_by_stem:
            out["missing_xlsx"].append(md.name)
    with tempfile.TemporaryDirectory(prefix="mdx_repro_") as td:
        td = Path(td)
        for md in mds:
            a, b = td / (md.stem + ".a.xlsx"), td / (md.stem + ".b.xlsx")
            convert_file(md, a)
            convert_file(md, b)
            ha, hb = _sha256(a), _sha256(b)
            cur = xlsx_by_stem.get(md.stem)
            hcur = _sha256(cur) if cur and cur.is_file() else None
            ok = (ha == hb)
            fresh = (hcur == ha) if hcur else None
            out["repro"].append({"file": md.name, "sha256": ha,
                                 "byte_identical": ok, "matches_delivered": fresh})
    out["pass"] = (not out["missing_xlsx"]
                   and all(r["byte_identical"] for r in out["repro"])
                   and all(r["matches_delivered"] is not False for r in out["repro"])
                   and not out["failures"])
    return out


# ---------------------------------------------------------------- main

def main() -> int:
    ap = argparse.ArgumentParser(description="AI 工艺书 md → xlsx 转换器")
    ap.add_argument("--bench", default=str(DEFAULT_BENCH), help="数据集目录（默认 AI 数据集）")
    ap.add_argument("--no-gold", action="store_true", help="不迁移 gold.json（只生成 xlsx）")
    ap.add_argument("--verify-repro", action="store_true", help="转换后逐份做两次生成字节对比")
    ap.add_argument("--check", action="store_true", help="只做离线自检（不重写任何文件）")
    a = ap.parse_args()
    bench = Path(a.bench)
    if not bench.is_absolute():
        bench = (ROOT / bench).resolve()
    if not (bench / "input").is_dir():
        raise SystemExit("[FATAL] 目录不存在：%s" % (bench / "input"))
    if a.check:
        rep = check_benchmark(bench)
        print(json.dumps(rep, ensure_ascii=False, indent=1))
        return 0 if rep.get("pass") else 1
    res = convert_benchmark(bench, rewrite_gold=not a.no_gold)
    print("[md_to_xlsx] 转换 %d 份 md → xlsx（失败 %d 份）"
          % (len(res["converted"]), len(res["failed"])))
    if res["failed"]:
        for name, err in res["failed"]:
            print("  FAIL %s：%s" % (name, err))
        return 1
    g = res.get("gold") or {}
    if g:
        print("[md_to_xlsx] gold 证据迁移：%d 条 → xlsx 口径；md 原口径留档 gold_md_source.json"
              % (g.get("conversion") or {}).get("entries_changed", 0))
        print("[md_to_xlsx] gold 版本=%s stats=%s" % (g.get("version"), g.get("stats")))
    print("[md_to_xlsx] SHA256SUMS 覆盖 %d 个文件" % len(res.get("sha256sums") or []))
    if a.verify_repro:
        rep = check_benchmark(bench)
        print("[md_to_xlsx] 可复现自检：pass=%s" % rep["pass"])
        for r in rep["repro"]:
            print("  %-40s sha256=%s 两次一致=%s 与交付一致=%s"
                  % (r["file"], r["sha256"][:16], r["byte_identical"], r["matches_delivered"]))
        return 0 if rep["pass"] else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
