# -*- coding: utf-8 -*-
"""工艺书基准数据集 · 批量程序化生成（task-157 / T-166）。

用途：把 `tests/fixtures/process_sheet_benchmark/` 从 L1 3 + L2 3 扩到
**L1 20 份干净底稿 + L2 60 份注入稿（每份 2-4 个注入，共 180 条 gold）**。

设计原则（与 docs/qa/工艺书数据集设计_20261119.md 一致）：
1. 纯模板 + 参数集生成，**不使用 LLM 生成正文**：同一套渲染函数生成正文与 gold，
   gold 的 `evidence_text` 直接取注入后的单元格原文，保证逐字一致、可复现。
2. L1 干净稿参数全部落在平台食品点位判据（`seed/library_supplement.json`）与
   行业合理值内；生成后做静态合规自检，Path A 实跑 clean FP 必须 = 0。
3. L2 = L1 底稿 + 单格替换；每份注入稿与底稿的逐格差异数 == 该文件 gold 条目数。
4. 缺陷类型覆盖调研报告高频类：数值越界 / 字段缺失 / 前后矛盾 / 日期·时序 /
   单位 / 工序·步骤 / 同名不同规格 / 值与国标冲突。可在确定性执行器上计算的缺陷
   （参数越界、跨 Sheet 日期/名称/版本/签名）占多数；语义类缺陷单独标记
   `computable=false`，用于诚实报告 Path A 抓不到哪些类型。

硬约束：
- **绝不写 `data/ruleproof.db`**：脚本第一行断言 `RULEPROOF_DB` 指向 `/tmp/l2/*`，
  且本脚本不 import 平台 DB 层（静态自检只 import 解析器/数值抽取器）。
- 不修改产品代码；产物只落 `tests/fixtures/process_sheet_benchmark/`。

用法：
    cd platform
    PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
    PYTHONPATH=/tmp/qa_pylibs $PY tools/build_benchmark_bulk.py
    PYTHONPATH=/tmp/qa_pylibs $PY scripts/qa/validate_generated_dataset.py \\
        tests/fixtures/process_sheet_benchmark
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

# ---------------------------------------------------------------- 数据库硬隔离
# 第一行纪律：本脚本只允许在 /tmp/l2/* 下产生伴随数据库；默认显式设为临时库，
# 若外部已设置则必须是 /tmp/l2/ 前缀。任何情况都不触碰 data/ruleproof.db。
_L2_TMP = Path("/tmp/l2")
_L2_TMP.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("RULEPROOF_DB", str(_L2_TMP / "build_benchmark_bulk.sqlite"))
_DB = os.environ["RULEPROOF_DB"]
if not _DB.startswith("/tmp/l2/"):
    raise SystemExit(f"[FATAL] RULEPROOF_DB 必须指向 /tmp/l2/*，当前={_DB!r}；拒绝运行以免污染 data/ruleproof.db")
os.environ.setdefault("RULEPROOF_LLM_CACHE", "0")

from openpyxl import Workbook  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]              # platform/
BENCH = ROOT / "tests" / "fixtures" / "process_sheet_benchmark"
INPUT = BENCH / "input"

FIXED_TIME = datetime(2026, 11, 19, 9, 30, 0)
BENCHMARK_ID = "process_sheet_benchmark"
BENCH_VERSION = "2.0.0"

# 版式常量：与平台内置食品包 app/engine/engine.py:parse_xlsx 的标签/偏移约定一致。
R_TITLE, R_DATE, R_VERSION, R_PROC_NAME, R_PROD, R_RAW_HEAD = 1, 3, 4, 7, 7, 14
R_STD_DOC, R_STD_HEAD, R_STEP_START = 22, 23, 24
R_MATERIAL_START = 15
R_MAX_STEP_ROWS = 22
SIGN_ROLES = ["研发经理", "生产经理", "品管经理", "研发"]
SIGN_SETS = [
    {"研发经理": "陈一鸣", "生产经理": "周立", "品管经理": "林岚", "研发": "吴迪"},
    {"研发经理": "沈知远", "生产经理": "韩卓", "品管经理": "许清", "研发": "方雨桐"},
    {"研发经理": "程亦凡", "生产经理": "罗启明", "品管经理": "蒋文博", "研发": "苏晓"},
    {"研发经理": "陆承志", "生产经理": "马骁", "品管经理": "顾亦宁", "研发": "叶蓁"},
    {"研发经理": "赵启航", "生产经理": "钱立群", "品管经理": "孙妍", "研发": "李慕白"},
    {"研发经理": "郑博文", "生产经理": "冯磊", "品管经理": "曹静", "研发": "唐果"},
]

# 平台食品点位判据（seed/library_supplement.json；非国标数值，报告必须写"平台判据"）
PLATFORM_CRITERIA = {
    "FOOD01-001": "中心温度≥85℃",
    "FOOD01-002": "消毒液浓度≥200ppm",
    "FOOD01-003": "冷却≤10℃",
    "FOOD01-004": "冷藏暂存 0-8℃",
    "FOOD01-005": "解冻≥20h",
    "FOOD01-006": "重量单位统一 g/kg",
}

# 点位 → 平台内置执行器规则码（与 tests/fixtures/.../tools/run_benchmark.py 共享）
POINT_RULE = {
    "FOOD01-001": "RW20260525005", "FOOD01-002": "RW20260525006",
    "FOOD01-003": "RW20260525009", "FOOD01-004": "RW20260525010",
    "FOOD01-005": "RW20260525011", "FOOD01-006": "RW20260525012",
    "FOOD02-001": "E3", "FOOD02-002": "E4",
    "FOOD03-001": "RW20260526004", "FOOD03-002": "RW20260525003",
    "FOOD03-003": "RW20260525001", "FOOD04-001": "RW20260525002",
    "FOOD04-002": "RW20260525002", "FOOD05-001": "B-2",
    "FOOD05-002": "C-3", "FOOD05-003": "B-4", "FOOD05-004": "RW20260525007",
}
POINT_NAME = {
    "FOOD01-001": "炒制/烹制中心温度达标", "FOOD01-002": "消毒浓度与时间达标",
    "FOOD01-003": "冷却终温达标", "FOOD01-004": "冷藏暂存温度达标",
    "FOOD01-005": "解冻条件标注", "FOOD01-006": "重量与单位统一",
    "FOOD02-001": "葱姜蒜类前处理三要素", "FOOD02-002": "肉类前处理完整性",
    "FOOD03-001": "实施日期跨 Sheet 一致", "FOOD03-002": "产品名称全称/简称一致",
    "FOOD03-003": "工单号/版本号一致", "FOOD04-001": "版本号非占位符",
    "FOOD04-002": "人员签名非占位符", "FOOD05-001": "半成品工序闭环",
    "FOOD05-002": "序号连续", "FOOD05-003": "投料量与总重匹配",
    "FOOD05-004": "产品名称规范",
    # 302 通用点位（语义判定；Path A 无确定性执行器）
    "B01-002": "必填条款字段无空缺", "B01-004": "章节所需内容要素齐备",
    "C06-002": "参数符合适用区间", "D02-001": "同一事实前后一致",
    "D02-003": "文字与表格内容一致", "F05-002": "步骤依赖无无法启动循环",
    "F05-003": "关键节点有完成判据",
}

# 注入槽位定义：槽位 → gold 元数据；computable=Path A 确定性执行器可否命中
SLOT_DEF = {
    "center_temp": {"point": "FOOD01-001", "defect": "数值越界", "severity": "高",
                    "rule": "RW20260525005", "computable": True},
    "center2_temp": {"point": "FOOD01-001", "defect": "前后矛盾", "severity": "中",
                     "rule": "RW20260525005", "computable": True},
    "ppm": {"point": "FOOD01-002", "defect": "数值越界", "severity": "高",
            "rule": "RW20260525006", "computable": True},
    "ppm2": {"point": "FOOD01-002", "defect": "数值越界", "severity": "中",
             "rule": "RW20260525006", "computable": True},
    "cooling": {"point": "FOOD01-003", "defect": "数值越界", "severity": "高",
                "rule": "RW20260525009", "computable": True},
    "cold": {"point": "FOOD01-004", "defect": "数值越界", "severity": "中",
             "rule": "RW20260525010", "computable": True},
    "thaw": {"point": "FOOD01-005", "defect": "数值越界", "severity": "高",
             "rule": "RW20260525011", "computable": True},
    "impl_date": {"point": "FOOD03-001", "defect": "日期·时序", "severity": "高",
                  "rule": "RW20260526004", "computable": True},
    "version": {"point": "FOOD04-001", "defect": "字段缺失", "severity": "高",
                "rule": "RW20260525002", "computable": True},
    "signature": {"point": "FOOD04-002", "defect": "字段缺失", "severity": "中",
                  "rule": "RW20260525002", "computable": True},
    "product": {"point": "FOOD03-002", "defect": "前后矛盾", "severity": "中",
                "rule": "RW20260525003", "computable": True},
    # ---- 语义缺陷（无确定性执行器，Path A 抓不到；Path B 语义区）----
    "unit": {"point": "FOOD01-006", "defect": "单位", "severity": "中",
             "rule": "RW20260525012", "computable": False},
    "flow": {"point": "F05-002", "defect": "工序·步骤", "severity": "中",
             "rule": "", "computable": False},
    "spec": {"point": "D02-001", "defect": "同名不同规格", "severity": "中",
             "rule": "", "computable": False},
    "std_conflict": {"point": "C06-002", "defect": "值与国标冲突", "severity": "高",
                     "rule": "", "computable": False},
    "cool_missing": {"point": "FOOD01-003", "defect": "字段缺失", "severity": "中",
                     "rule": "RW20260525009", "computable": False},
}

# 注入槽位环形序列：偶/奇位分属两组（同一份注入稿不会同时命中两个同点位的温度槽）
RING_BAKERY = ["center_temp", "cooling", "ppm", "cold", "ppm2", "center2_temp",
               "impl_date", "version", "signature", "product"]
RING_MEAT = ["center_temp", "cooling", "ppm", "cold", "thaw", "center2_temp",
             "impl_date", "version", "signature", "product"]
RING_CONDIMENT = ["center_temp", "cooling", "ppm", "cold", "ppm2", "center2_temp",
                  "impl_date", "version", "signature", "product"]
SEM_RING = ["unit", "flow", "spec", "std_conflict", "cool_missing"]


def _col_letter(idx: int) -> str:
    s = ""
    while idx:
        idx, rem = divmod(idx - 1, 26)
        s = chr(65 + rem) + s
    return s


def _col_index(letter: str) -> int:
    n = 0
    for ch in letter:
        n = n * 26 + (ord(ch) - 64)
    return n


# ---------------------------------------------------------------- 产品参数集（手工写死，可审计）
# 每份参数均满足平台判据：中心温度 ≥85℃、消毒 ≥200ppm、冷却 ≤10℃、冷藏 0-8℃、解冻 ≥20h。
BAKERY = [
    dict(idx=1, product="麦香法式欧包", short="法式欧包", net=180,
         bake=92, bake_min=18, bake2=90, bake2_min=5, ppm=250, soak=10,
         ferment=28, rh=75, fmin=60, cool=10, cold_lo=0, cold_hi=8, cold_h=6,
         moisture=45, impl="2026-08-01", flour=100, whole=20, water=68,
         oven=180,
        flow_inj="发酵前入炉预烘烤"),
    dict(idx=2, product="经典白吐司", short="白吐司", net=450,
         bake=94, bake_min=20, bake2=90, bake2_min=6, ppm=260, soak=10,
         ferment=30, rh=80, fmin=75, cool=10, cold_lo=0, cold_hi=8, cold_h=6,
         moisture=44, impl="2026-07-20", flour=100, whole=0, water=70,
         oven=185,
        flow_inj="发酵前入炉预烘烤"),
    dict(idx=3, product="黄油曲奇", short="曲奇", net=200,
         bake=96, bake_min=15, bake2=88, bake2_min=4, ppm=240, soak=12,
         ferment=26, rh=70, fmin=45, cool=10, cold_lo=0, cold_hi=6, cold_h=8,
         moisture=42, impl="2026-06-15", flour=100, whole=0, water=30,
         oven=170,
        flow_inj="发酵前入炉预烘烤"),
    dict(idx=4, product="原味贝果", short="贝果", net=120,
         bake=93, bake_min=16, bake2=90, bake2_min=5, ppm=280, soak=10,
         ferment=30, rh=78, fmin=50, cool=8, cold_lo=0, cold_hi=8, cold_h=8,
         moisture=46, impl="2026-07-01", flour=100, whole=0, water=60,
         oven=188,
        flow_inj="发酵前入炉预烘烤"),
    dict(idx=5, product="法式可颂", short="可颂", net=90,
         bake=95, bake_min=17, bake2=88, bake2_min=5, ppm=255, soak=11,
         ferment=26, rh=72, fmin=40, cool=6, cold_lo=0, cold_hi=8, cold_h=10,
         moisture=43, impl="2026-06-30", flour=100, whole=0, water=45,
         oven=175,
        flow_inj="发酵前入炉预烘烤"),
    dict(idx=6, product="全麦软欧", short="软欧", net=220,
         bake=91, bake_min=19, bake2=90, bake2_min=6, ppm=245, soak=10,
         ferment=30, rh=82, fmin=70, cool=10, cold_lo=0, cold_hi=8, cold_h=6,
         moisture=48, impl="2026-08-10", flour=100, whole=40, water=66,
         oven=190,
        flow_inj="发酵前入炉预烘烤"),
    dict(idx=7, product="黑麦欧包", short="欧包", net=260,
         bake=92, bake_min=21, bake2=91, bake2_min=5, ppm=265, soak=12,
         ferment=28, rh=85, fmin=65, cool=8, cold_lo=0, cold_hi=8, cold_h=6,
         moisture=47, impl="2026-07-05", flour=100, whole=50, water=72,
         oven=200,
        flow_inj="发酵前入炉预烘烤"),
]

MEAT = [
    dict(idx=8, product="五香卤牛腱", short="卤牛腱", net=500,
         thaw=24, ppm=250, soak=10, brine_lo=0, brine_hi=4, hang=12,
         center=85, hold=90, second=90, second_min=30, cool=10,
         cold_lo=0, cold_hi=8, cold_h=4, salt="3.5", impl="2026-07-15",
         material="冷冻牛腱", material_net=7052, flow_inj="腌制前直接入锅卤制"),
    dict(idx=9, product="酱香肘花", short="肘花", net=400,
         thaw=26, ppm=260, soak=10, brine_lo=0, brine_hi=4, hang=12,
         center=86, hold=100, second=91, second_min=25, cool=10,
         cold_lo=0, cold_hi=8, cold_h=4, salt="3.0", impl="2026-06-20",
         material="冷冻猪肘", material_net=6850, flow_inj="腌制前直接入锅卤制"),
    dict(idx=10, product="香辣牛肉干", short="牛肉干", net=250,
         thaw=28, ppm=240, soak=12, brine_lo=0, brine_hi=4, hang=10,
         center=88, hold=80, second=92, second_min=20, cool=8,
         cold_lo=0, cold_hi=6, cold_h=6, salt="4.0", impl="2026-05-18",
         material="冷冻牛后腿肉", material_net=7200, flow_inj="腌制前直接入锅卤制"),
    dict(idx=11, product="盐焗鸡胸", short="鸡胸", net=300,
         thaw=22, ppm=270, soak=10, brine_lo=0, brine_hi=4, hang=8,
         center=85, hold=30, second=90, second_min=20, cool=10,
         cold_lo=0, cold_hi=8, cold_h=4, salt="2.5", impl="2026-08-02",
         material="冷冻鸡胸肉", material_net=6800, flow_inj="腌制前直接入锅卤制"),
    dict(idx=12, product="蜜汁猪肉脯", short="猪肉脯", net=200,
         thaw=24, ppm=280, soak=10, brine_lo=0, brine_hi=4, hang=12,
         center=87, hold=60, second=91, second_min=25, cool=8,
         cold_lo=0, cold_hi=8, cold_h=6, salt="3.5", impl="2026-07-08",
         material="冷冻猪后腿肉", material_net=6900, flow_inj="腌制前直接入锅卤制"),
    dict(idx=13, product="酱卤鸭脖", short="鸭脖", net=350,
         thaw=20, ppm=250, soak=10, brine_lo=0, brine_hi=4, hang=12,
         center=86, hold=90, second=92, second_min=30, cool=10,
         cold_lo=0, cold_hi=8, cold_h=4, salt="3.8", impl="2026-06-11",
         material="冷冻鸭脖", material_net=7100, flow_inj="腌制前直接入锅卤制"),
    dict(idx=14, product="黑椒牛肉粒", short="牛肉粒", net=450,
         thaw=30, ppm=300, soak=10, brine_lo=0, brine_hi=4, hang=10,
         center=88, hold=70, second=93, second_min=20, cool=8,
         cold_lo=0, cold_hi=6, cold_h=6, salt="3.2", impl="2026-08-15",
         material="冷冻牛肉粒", material_net=7300, flow_inj="腌制前直接入锅卤制"),
]

CONDIMENT = [
    dict(idx=15, product="古法酿造酱油", short="古法酱油", net=500,
         cook=121, cook_min=20, koji=30, koji_h=48, ferment=45, ferment_d=90,
         steril=121, steril_min=30, cool=10, ppm=250, soak=10,
         cold_lo=0, cold_hi=8, cold_h=12, quality=("氨基酸态氮", "≥0.4g/100mL"),
         impl="2026-06-30", flow_inj="制曲后蒸煮"),
    dict(idx=16, product="鲜味生抽", short="生抽", net=500,
         cook=118, cook_min=18, koji=31, koji_h=46, ferment=43, ferment_d=80,
         steril=120, steril_min=30, cool=10, ppm=260, soak=10,
         cold_lo=0, cold_hi=8, cold_h=12, quality=("氨基酸态氮", "≥0.5g/100mL"),
         impl="2026-07-12", flow_inj="制曲后蒸煮"),
    dict(idx=17, product="原酿黄豆酱", short="黄豆酱", net=300,
         cook=115, cook_min=25, koji=28, koji_h=60, ferment=40, ferment_d=60,
         steril=118, steril_min=25, cool=10, ppm=240, soak=12,
         cold_lo=0, cold_hi=8, cold_h=12, quality=("氨基酸态氮", "≥0.5g/100mL"),
         impl="2026-05-30", flow_inj="制曲后蒸煮"),
    dict(idx=18, product="古法香醋", short="香醋", net=500,
         cook=120, cook_min=20, koji=32, koji_h=44, ferment=42, ferment_d=100,
         steril=121, steril_min=30, cool=10, ppm=280, soak=10,
         cold_lo=0, cold_hi=8, cold_h=12, quality=("总酸", "≥3.5g/100mL"),
         impl="2026-06-06", flow_inj="制曲后蒸煮"),
    dict(idx=19, product="复合调味酱", short="调味酱", net=450,
         cook=116, cook_min=22, koji=29, koji_h=52, ferment=41, ferment_d=70,
         steril=118, steril_min=25, cool=10, ppm=250, soak=10,
         cold_lo=0, cold_hi=8, cold_h=12, quality=("可溶性固形物", "≥30%"),
         impl="2026-08-05", flow_inj="制曲后蒸煮"),
    dict(idx=20, product="鲜味蚝油", short="蚝油", net=500,
         cook=118, cook_min=20, koji=30, koji_h=50, ferment=43, ferment_d=75,
         steril=120, steril_min=25, cool=10, ppm=270, soak=10,
         cold_lo=0, cold_hi=8, cold_h=12, quality=("氨基酸态氮", "≥0.3g/100mL"),
         impl="2026-07-25", flow_inj="制曲后蒸煮"),
]


# ---------------------------------------------------------------- 文档定义（工序模板）

def _bakery_doc(p: dict) -> dict:
    sign = SIGN_SETS[(p["idx"] - 1) % len(SIGN_SETS)]
    version = f"PS-BAK-2026-V{p['idx']:02d}"
    sheets = [
        {"name": "面团前处理", "process_name": "面团前处理",
         "materials": [("1", "高筋小麦粉", p["flour"], "kg"), ("2", "全麦粉", p["whole"], "kg"),
                       ("3", "饮用水", p["water"], "kg"), ("4", "干酵母", 1.2, "kg"),
                       ("5", "食用盐", 1.8, "kg")],
         "steps": [
             ("出库", "高筋小麦粉、全麦粉出库", "提前12h从常温库领料", "", "常温库"),
             ("计量", "按配方称量面粉、酵母、盐、水",
              f"面粉{p['flour']}kg、水{p['water']}kg、酵母1.2kg、盐1.8kg", "", "电子秤"),
             ("搅拌", "和面机低速搅拌3min后高速搅拌5min", "面团温度24℃", "", "和面机"),
             ("消毒", "和面机、周转筐清洗消毒",
              f"消毒液浓度{p['ppm']}ppm、浸泡时间{p['soak']}min，消毒后清水冲洗至无残留", "", "水槽"),
             ("分割", f"面团分割为每份{p['net']}g", "分割重量偏差≤2g", "", "分割机"),
         ]},
        {"name": "发酵工序", "process_name": "发酵工序",
         "materials": [("1", "面团", p["net"], "g")],
         "steps": [
             ("发酵", "面团入醒发箱发酵",
              f"发酵温度{p['ferment']}℃、相对湿度{p['rh']}%、时间{p['fmin']}min", "", "醒发箱"),
             ("排气", "发酵后排气翻面", "发酵体积增至2倍", "", "操作台"),
             ("消毒", "醒发箱周转箱清洗消毒",
              f"消毒液浓度{p['ppm'] + 10}ppm、浸泡时间{p['soak']}min，消毒后清水冲洗至无残留",
              "", "水槽"),
             ("冷藏暂存", "面团转入冷藏库暂存",
              f"冷藏库温度{p['cold_lo']}-{p['cold_hi']}℃，暂存最长{p['cold_h']}小时", "", "冷藏库"),
         ]},
        {"name": "烘焙工序", "process_name": "烘焙工序",
         "materials": [("1", "发酵面团", p["net"], "g")],
         "steps": [
             ("烘烤", "面团入炉烘烤",
              f"中心温度≥{p['bake']}℃且烘烤{p['bake_min']}min",
              f"烤箱温度{p['oven']}℃", "平炉"),
             ("二次烘烤", "面包复烤上色",
              f"中心温度≥{p['bake2']}℃且复烤{p['bake2_min']}min", "", "平炉"),
             ("出炉", "出炉后置于冷却架自然摊凉", "出炉后30min内转入冷却工序", "", "冷却架"),
             ("标识", "打印产品标签", "标签内容含生产日期与批次",
              f"单只净重{p['net']}g", "标签机"),
         ]},
        {"name": "冷却工序", "process_name": "冷却工序",
         "materials": [("1", "烤制面包", p["net"], "g")],
         "steps": [
             ("冷却", "面包转入冷却间冷却", f"冷却至中心温度≤{p['cool']}℃", "", "冷却架"),
             ("装袋", "冷却后装袋封口", f"装袋净重{p['net']}g", "", "封口机"),
             ("成品检验", "按企业标准进行出厂检验", f"水分含量≤{p['moisture']}%", "", "化验室"),
         ]},
    ]
    slots = {
        "center_temp": ("step", "烘焙工序", 0, "L"),
        "center2_temp": ("step", "烘焙工序", 1, "L"),
        "ppm": ("step", "面团前处理", 3, "L"),
        "ppm2": ("step", "发酵工序", 2, "L"),
        "cooling": ("step", "冷却工序", 0, "L"),
        "cool_missing": ("step", "冷却工序", 0, "L"),
        "cold": ("step", "发酵工序", 3, "L"),
        "impl_date": ("cell", "烘焙工序", "C3"),
        "version": ("cell", "发酵工序", "C4"),
        "product": ("cell", "发酵工序", "N7"),
        "signature": ("cell", "冷却工序", "AA4"),
        "unit": ("step", "冷却工序", 1, "L"),
        "flow": ("step", "烘焙工序", 0, "F"),
        "spec": ("step", "烘焙工序", 3, "Q"),
        "std_conflict": ("step", "冷却工序", 2, "L"),
    }
    return _doc(p, "烘焙", "PS-BAK", version, sheets, slots, sign)


def _meat_doc(p: dict) -> dict:
    sign = SIGN_SETS[(p["idx"] - 1) % len(SIGN_SETS)]
    version = f"PS-MEAT-2026-V{p['idx']:02d}"
    sheets = [
        {"name": "原料前处理", "process_name": "原料前处理",
         "materials": [("1", p["material"], p["material_net"], "g"), ("2", "饮用水", 3000, "g"),
                       ("3", "食用盐", 120, "g")],
         "steps": [
             ("出库", f"{p['material']}从冷冻库领料", "提前12h转入冷藏库", "", "周转筐"),
             ("解冻", f"{p['material']}移入冷藏库解冻",
              f"解冻温度0-8℃，解冻时间{p['thaw']}h", "", "周转筐"),
             ("清洗消毒", "原料肉清洗后消毒",
              f"消毒液浓度{p['ppm']}ppm、浸泡时间{p['soak']}min，消毒后清水冲洗至无残留",
              "", "水槽"),
             ("修整", "去除筋膜、淤血", "修整后单块重量1000g～1200g", "", "刀具"),
         ]},
        {"name": "腌制工序", "process_name": "腌制工序",
         "materials": [("1", "修整原料肉", 6000, "g"), ("2", "腌料", 180, "g")],
         "steps": [
             ("腌制", "原料肉加腌料滚揉腌制",
              f"腌制温度{p['brine_lo']}-{p['brine_hi']}℃、腌制时间{p['hang']}h", "", "滚揉机"),
             ("器具消毒", "滚揉机与周转筐清洗消毒",
              f"消毒液浓度{p['ppm'] + 10}ppm、浸泡时间{p['soak']}min，消毒后清水冲洗至无残留",
              "", "水槽"),
         ]},
        {"name": "卤制工序", "process_name": "卤制工序",
         "materials": [("1", "腌制原料肉", 6000, "g"), ("2", "香辛料包", 1, "包"),
                       ("3", "生抽", 8000, "g"), ("4", "冰糖", 2000, "g")],
         "steps": [
             ("配料", "按配方配制卤水", "香辛料包1包、生抽8000g、冰糖2000g", "", "电子秤"),
             ("卤制", "原料肉入夹层锅卤制",
              f"中心温度≥{p['center']}℃并保持{p['hold']}min", "", "夹层锅"),
             ("浸泡", "卤制后原汤浸泡", "浸泡时间120min", "", "夹层锅"),
         ]},
        {"name": "冷却暂存工序", "process_name": "冷却暂存工序",
         "materials": [("1", "卤制肉品", p["net"], "g")],
         "steps": [
             ("冷却", "卤制后出锅摊凉", f"冷却至中心温度≤{p['cool']}℃", "", "冷却间"),
             ("转入暂存", "冷却后转入周转筐于冷藏库暂存",
              f"冷藏库温度{p['cold_lo']}-{p['cold_hi']}℃，暂存最长{p['cold_h']}小时", "", "周转筐"),
             ("装袋", "按规格装袋封口", f"装袋净重{p['net']}g", f"单袋净重{p['net']}g", "真空包装机"),
             ("速冻", "装袋后速冻定型", "速冻库温度-30℃", "", "速冻机"),
         ]},
        {"name": "二次杀菌工序", "process_name": "二次杀菌工序",
         "materials": [("1", "装袋肉品", p["net"], "g")],
         "steps": [
             ("杀菌", "装袋后水浴杀菌",
              f"杀菌中心温度≥{p['second']}℃并保持{p['second_min']}min", "", "水浴锅"),
             ("成品检验", "按 GB 2726 进行出厂检验", f"食盐含量≤{p['salt']}%", "", "化验室"),
         ]},
    ]
    slots = {
        "center_temp": ("step", "卤制工序", 1, "L"),
        "center2_temp": ("step", "二次杀菌工序", 0, "L"),
        "ppm": ("step", "原料前处理", 2, "L"),
        "ppm2": ("step", "腌制工序", 1, "L"),
        "cooling": ("step", "冷却暂存工序", 0, "L"),
        "cool_missing": ("step", "冷却暂存工序", 0, "L"),
        "cold": ("step", "冷却暂存工序", 1, "L"),
        "thaw": ("step", "原料前处理", 1, "L"),
        "impl_date": ("cell", "卤制工序", "C3"),
        "version": ("cell", "腌制工序", "C4"),
        "product": ("cell", "腌制工序", "N7"),
        "signature": ("cell", "冷却暂存工序", "AA4"),
        "unit": ("step", "冷却暂存工序", 2, "L"),
        "flow": ("step", "卤制工序", 1, "F"),
        "spec": ("step", "冷却暂存工序", 2, "Q"),
        "std_conflict": ("step", "二次杀菌工序", 1, "L"),
    }
    return _doc(p, "肉制品", "PS-MEAT", version, sheets, slots, sign)


def _condiment_doc(p: dict) -> dict:
    sign = SIGN_SETS[(p["idx"] - 1) % len(SIGN_SETS)]
    version = f"PS-SOY-2026-V{p['idx']:02d}"
    q_name, q_val = p["quality"]
    sheets = [
        {"name": "原料前处理", "process_name": "原料前处理",
         "materials": [("1", "非转基因大豆", 5000, "g"), ("2", "小麦", 2500, "g"),
                       ("3", "饮用水", 6000, "g")],
         "steps": [
             ("出库", "大豆、小麦出库", "常温库领料", "", "斗车"),
             ("清洗", "大豆清洗除杂", "去除霉变粒、砂石", "", "水槽"),
             ("浸泡", "大豆浸泡", "浸泡时间8h，水温25℃", "", "浸泡池"),
             ("蒸煮", "大豆蒸煮", f"中心温度≥{p['cook']}℃、时间{p['cook_min']}min", "", "蒸煮锅"),
             ("设备消毒", "蒸煮锅与工器具清洗消毒",
              f"消毒液浓度{p['ppm']}ppm、浸泡时间{p['soak']}min，消毒后清水冲洗至无残留",
              "", "水槽"),
         ]},
        {"name": "制曲工序", "process_name": "制曲工序",
         "materials": [("1", "蒸煮大豆", 5000, "g"), ("2", "小麦曲种", 15, "g")],
         "steps": [
             ("接种", "蒸煮后大豆冷却接种曲种", "曲种用量0.3%", "", "接种台"),
             ("制曲", "入曲房制曲", f"制曲温度{p['koji']}℃、时间{p['koji_h']}h", "", "曲房"),
             ("器具消毒", "曲房工器具清洗消毒",
              f"消毒液浓度{p['ppm'] + 10}ppm、浸泡时间{p['soak']}min，消毒后清水冲洗至无残留",
              "", "水槽"),
         ]},
        {"name": "发酵工序", "process_name": "发酵工序",
         "materials": [("1", "成曲", 5000, "g"), ("2", "食盐水", 7500, "g")],
         "steps": [
             ("发酵", "成曲入发酵池发酵",
              f"发酵温度{p['ferment']}℃、发酵时间{p['ferment_d']}天", "", "发酵池"),
             ("淋油", "发酵成熟后淋油", "头淋、二淋分池收集", "", "淋油池"),
         ]},
        {"name": "淋油灭菌工序", "process_name": "淋油灭菌工序",
         "materials": [("1", "生酱油", p["net"], "g")],
         "steps": [
             ("灭菌", "生酱油加热灭菌",
              f"灭菌中心温度≥{p['steril']}℃、时间{p['steril_min']}min", "", "灭菌器"),
             ("冷却", "灭菌后冷却", f"冷却至中心温度≤{p['cool']}℃", "", "冷却器"),
             ("灌装", "灭菌后灌装", f"灌装温度≤45℃", "", "灌装机"),
             ("成品检验", "按 GB 2717 出厂检验", f"{q_name}{q_val}",
              "菌落总数≤10000CFU/g", "化验室"),
         ]},
        {"name": "成品暂存工序", "process_name": "成品暂存工序",
         "materials": [("1", "成品调味品", p["net"], "g")],
         "steps": [
             ("冷藏暂存", "成品转入冷藏库暂存",
              f"冷藏库温度{p['cold_lo']}-{p['cold_hi']}℃，暂存最长{p['cold_h']}小时", "", "冷藏库"),
             ("贴标", "贴标后装箱", f"单瓶净重{p['net']}g", f"单瓶净重{p['net']}g", "贴标机"),
         ]},
    ]
    slots = {
        "center_temp": ("step", "原料前处理", 3, "L"),
        "center2_temp": ("step", "淋油灭菌工序", 0, "L"),
        "ppm": ("step", "原料前处理", 4, "L"),
        "ppm2": ("step", "制曲工序", 2, "L"),
        "cooling": ("step", "淋油灭菌工序", 1, "L"),
        "cool_missing": ("step", "淋油灭菌工序", 1, "L"),
        "cold": ("step", "成品暂存工序", 0, "L"),
        "impl_date": ("cell", "淋油灭菌工序", "C3"),
        "version": ("cell", "制曲工序", "C4"),
        "product": ("cell", "制曲工序", "N7"),
        "signature": ("cell", "成品暂存工序", "AA4"),
        "unit": ("step", "成品暂存工序", 1, "L"),
        "flow": ("step", "原料前处理", 3, "F"),
        "spec": ("step", "成品暂存工序", 1, "Q"),
        "std_conflict": ("step", "淋油灭菌工序", 3, "L"),
    }
    return _doc(p, "调味品", "PS-SOY", version, sheets, slots, sign)


def _doc(p: dict, industry: str, prefix: str, version: str, sheets: list,
         slots: dict, sign: dict) -> dict:
    impl = datetime.strptime(p["impl"], "%Y-%m-%d")
    listing = impl + timedelta(days=30)
    return {
        "file_id": f"PS-L1-{p['idx']:02d}",
        "layer": "L1",
        "industry": industry,
        "product": p["product"],
        "short": p["short"],
        "version": version,
        "impl_date": p["impl"],
        "listing_date": listing.strftime("%Y-%m-%d"),
        "sign": sign,
        "sheets": sheets,
        "slots": slots,
        "idx": p["idx"],
        "params": p,
        "flow_injected": p["flow_inj"],
        "material_unit": "kg" if industry == "烘焙" else "g",
        "process_sheet_names": [s["name"] for s in sheets],
        "packaging": {
            "design_total": p["net"], "design_unit": "g",
            "revision": f"V1（{p['impl']}）：首次发布",
            "materials": [("1", "包装袋", f"PK-{p['idx']:03d}", "200*150mm", "1", "个"),
                          ("2", "产品标签", f"LB-{p['idx']:03d}", "80*50mm", "1", "张"),
                          ("3", "外箱", f"BX-{p['idx']:03d}", "400*300*250mm", "1", "个")],
        },
    }


def _sign_cell(role: str) -> str:
    i = SIGN_ROLES.index(role)
    return f"{_col_letter(19 + i * 4)}4"


def _slot_parts(doc: dict, slot: str):
    """槽位定义为 (kind, sheet, sel, col)；cell 类槽位 col=None。"""
    t = doc["slots"][slot]
    kind, sheet, sel = t[0], t[1], t[2]
    col = t[3] if len(t) > 3 else None
    return kind, sheet, sel, col


# ---------------------------------------------------------------- xlsx 构造

def _fix_props(wb: Workbook):
    pr = wb.properties
    pr.creator = "process_sheet_benchmark/build_benchmark_bulk.py"
    pr.lastModifiedBy = "process_sheet_benchmark"
    pr.created = FIXED_TIME
    pr.modified = FIXED_TIME
    pr.title = "工艺书基准（构造数据）"


_FIXED_UTC = "2026-11-19T09:30:00Z"


def _normalize_xlsx_zip(path: Path):
    """固定 zip 条目时间戳 + docProps/core.xml 元数据时间，保证重复构建字节级一致（SHA 可复现）。

    注：openpyxl `Workbook.save()` 会用"当前时间"覆盖 core.xml 的 dcterms:modified，
    只在 `wb.properties` 上设固定值不够；这里对 core.xml 做确定性回写。
    """
    tmp = path.with_suffix(".xlsx.tmp")
    with zipfile.ZipFile(path, "r") as zin, \
            zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name in zin.namelist():
            data = zin.read(name)
            if name == "docProps/core.xml":
                text = data.decode("utf-8")
                for tag in ("created", "modified"):
                    text = re.sub(
                        rf"(<dcterms:{tag}[^>]*>)[^<]*(<)", rf"\g<1>{_FIXED_UTC}\g<2>", text)
                data = text.encode("utf-8")
            zi = zipfile.ZipInfo(name, date_time=(2026, 11, 19, 9, 30, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o600 << 16
            zout.writestr(zi, data)
    tmp.replace(path)


def save_workbook(wb: Workbook, path: Path):
    wb.save(path)
    _normalize_xlsx_zip(path)


def _write_process_sheet(ws, doc: dict, sheet: dict):
    ws.cell(R_TITLE, 1, sheet["name"] + " 车间作业标准书")
    ws.cell(R_DATE, 1, "实施日期")
    ws.cell(R_DATE, 3, doc["impl_date"])
    ws.cell(R_VERSION, 1, "版本号")
    ws.cell(R_VERSION, 3, doc["version"])
    ws.cell(R_PROC_NAME, 1, "工 序  名  称")
    ws.cell(R_PROC_NAME, 3, sheet["process_name"])
    ws.cell(R_PROD, 11, "商品名")
    ws.cell(R_PROD, 14, doc["product"])
    for i, role in enumerate(SIGN_ROLES):
        col = 19 + i * 4
        ws.cell(R_DATE, col, role)
        ws.cell(R_DATE + 1, col, doc["sign"][role])
    ws.cell(11, 1, "生产数")
    ws.cell(11, 8, "净重")
    ws.cell(11, 13, "毛重")
    ws.cell(11, 18, "备注")
    ws.cell(R_RAW_HEAD, 1, "原 材 料 名")
    ws.cell(R_RAW_HEAD, 2, "投入量合计（确认用）")
    default_unit = doc.get("material_unit") or "g"
    for i, mat in enumerate(sheet["materials"]):
        seq, name, net = mat[0], mat[1], mat[2]
        unit = mat[3] if len(mat) > 3 else default_unit
        r = R_MATERIAL_START + i
        ws.cell(r, 2, int(seq))
        ws.cell(r, 3, name)
        ws.cell(r, 8, f"{net} {unit}")
        ws.cell(r, 13, f"{net} {unit}")
    ws.cell(R_STD_DOC, 1, "制造作业标准书")
    ws.cell(R_STD_HEAD, 1, "标准工序")
    ws.cell(R_STD_HEAD, 4, "蒸气压")
    ws.cell(R_STD_HEAD, 6, "作业内容")
    ws.cell(R_STD_HEAD, 12, "作业条件")
    ws.cell(R_STD_HEAD, 17, "作业要点")
    ws.cell(R_STD_HEAD, 21, "器具")
    for i, (a, f, l, q, u) in enumerate(sheet["steps"][:R_MAX_STEP_ROWS]):
        r = R_STEP_START + i
        ws.cell(r, 1, a)
        if f:
            ws.cell(r, 6, f)
        if l:
            ws.cell(r, 12, l)
        if q:
            ws.cell(r, 17, q)
        if u:
            ws.cell(r, 21, u)


def _write_packaging_sheet(ws, doc: dict):
    pkg = doc["packaging"]
    ws.cell(1, 1, "商品包装指示书")
    ws.cell(2, 1, "实施日期")
    ws.cell(2, 3, doc["impl_date"])
    ws.cell(2, 5, "上市日期")
    ws.cell(2, 7, doc["listing_date"])
    ws.cell(2, 10, "商品名")
    ws.cell(2, 13, doc["product"])
    for i, role in enumerate(SIGN_ROLES):
        col = 28 + i * 4
        ws.cell(2, col, role)
        ws.cell(3, col, doc["sign"][role])
    ws.cell(4, 1, "版本号")
    ws.cell(4, 3, doc["version"])
    ws.cell(4, 7, "设计总重量")
    ws.cell(4, 10, pkg["design_total"])
    ws.cell(4, 14, pkg["design_unit"])
    ws.cell(5, 1, "修订记录")
    ws.cell(5, 3, pkg["revision"])
    ws.cell(24, 1, "序号")
    ws.cell(24, 2, "包材相关")
    ws.cell(26, 2, "名称")
    ws.cell(26, 4, "包材编号")
    ws.cell(26, 6, "规格")
    ws.cell(26, 9, "数量")
    for i, (seq, name, code, spec, qty, unit) in enumerate(pkg["materials"]):
        r = 27 + i
        ws.cell(r, 1, int(seq))
        ws.cell(r, 2, name)
        ws.cell(r, 4, code)
        ws.cell(r, 6, spec)
        ws.cell(r, 9, int(qty))
        ws.cell(r, 10, unit)


def _write_param_sheet_from_wb(ws, wb: Workbook, doc: dict):
    """工艺参数表：从当前（可能是注入后的）工序页单元格取值，保证同源一致。"""
    ws.cell(1, 1, "工艺参数表")
    ws.cell(2, 1, "参数来源：企业自定工艺参数（构造数据；85℃/200ppm/10℃/0-8℃/20h 为平台点位判据，非国标强制值）")
    headers = ["序号", "工序", "作业内容", "作业条件", "监测方式"]
    for j, h in enumerate(headers, start=1):
        ws.cell(4, j, h)
    row = 5
    for sheet in doc["process_sheet_names"]:
        src = wb[sheet]
        for i in range(R_STEP_START, R_STEP_START + R_MAX_STEP_ROWS):
            a = src.cell(i, 1).value
            if a is None or str(a).strip() == "":
                continue
            ws.cell(row, 1, row - 4)
            ws.cell(row, 2, str(a).strip())
            f = src.cell(i, 6).value
            l = src.cell(i, 12).value
            if f:
                ws.cell(row, 3, str(f))
            if l:
                ws.cell(row, 4, str(l))
            ws.cell(row, 5, "工序自检 + 品管抽检")
            row += 1


def build_workbook(doc: dict, injections: dict | None = None) -> Workbook:
    """按 doc 定义构建 xlsx；injections={slot: 注入文本}（单格替换）。"""
    wb = Workbook()
    wb.remove(wb.active)
    for sheet in doc["sheets"]:
        ws = wb.create_sheet(sheet["name"])
        _write_process_sheet(ws, doc, sheet)
    for ws in list(wb.worksheets):
        pass
    wb.create_sheet("包装指示书")
    _write_packaging_sheet(wb["包装指示书"], doc)
    wb.create_sheet("工艺参数表")
    # 先注入（单格替换），再从注入后的工序页回填工艺参数表 → 参数表与工序页严格同源
    for slot, text in (injections or {}).items():
        kind, sheet, sel, col = _slot_parts(doc, slot)
        if kind == "step":
            wb[sheet].cell(R_STEP_START + int(sel), _col_index(str(col)), text)
        else:
            m = re.match(r"([A-Z]+)(\d+)", sel)
            wb[sheet].cell(int(m.group(2)), _col_index(m.group(1)), text)
    _write_param_sheet_from_wb(wb["工艺参数表"], wb, doc)
    _fix_props(wb)
    return wb


def _param_sheet_mismatches(wb: Workbook, doc: dict) -> list:
    """工艺参数表 D 列必须与工序页 L 列逐条同源（注入后也一样）。"""
    ws = wb["工艺参数表"]
    expect = []
    for sheet in doc["process_sheet_names"]:
        src = wb[sheet]
        for i in range(R_STEP_START, R_STEP_START + R_MAX_STEP_ROWS):
            a = src.cell(i, 1).value
            if a is None or str(a).strip() == "":
                continue
            l = src.cell(i, 12).value
            expect.append("" if l is None else str(l))
    got = []
    r = 5
    while r < 5 + len(expect) + 5:
        a = ws.cell(r, 2).value
        if a is None or str(a).strip() == "":
            break
        v = ws.cell(r, 4).value
        got.append("" if v is None else str(v))
        r += 1
    if got != expect:
        return [{"idx": i, "param_sheet": got[i] if i < len(got) else None,
                 "process": expect[i] if i < len(expect) else None}
                for i in range(max(len(got), len(expect)))
                if i >= len(got) or i >= len(expect) or got[i] != expect[i]][:5]
    return []


def workbook_cells(wb: Workbook) -> dict:
    out = {}
    for ws in wb.worksheets:
        rows = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None or str(cell.value).strip() == "":
                    continue
                rows.append((cell.row, cell.column_letter, _cell_value(cell.value)))
        rows.sort(key=lambda x: (x[0], x[1]))
        out[ws.title] = rows
    return out


def _cell_value(v):
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def read_slot_value(wb: Workbook, doc: dict, slot: str):
    kind, sheet, sel, col = _slot_parts(doc, slot)
    if kind == "step":
        v = wb[sheet].cell(R_STEP_START + int(sel), _col_index(str(col))).value
    else:
        m = re.match(r"([A-Z]+)(\d+)", sel)
        v = wb[sheet].cell(int(m.group(2)), _col_index(m.group(1))).value
    return "" if v is None else str(v)


# ---------------------------------------------------------------- gold / 注入变换

def _fmt_num(n: float) -> str:
    if float(n).is_integer():
        return str(int(n))
    return ("%.2f" % n).rstrip("0").rstrip(".")


def transform_injection(doc: dict, slot: str, clean: str, variant: int) -> str:
    """由干净原文确定性地产生注入原文（同一渲染源，保证 gold 逐字）。"""
    if slot in ("center_temp", "center2_temp"):
        low = [78, 80, 82][variant % 3]
        return re.sub(r"中心温度≥\d+(?:\.\d+)?℃", f"中心温度≥{low}℃", clean, count=1)
    if slot == "ppm":
        low = [150, 120, 180][variant % 3]
        return re.sub(r"\d+ppm", f"{low}ppm", clean, count=1)
    if slot == "ppm2":
        # 与 ppm 在同一份注入稿中可能同时出现：取不同的越界值，避免 gold evidence 重复
        low = [120, 180, 150][variant % 3]
        return re.sub(r"\d+ppm", f"{low}ppm", clean, count=1)
    if slot == "cooling":
        high = [15, 18, 20][variant % 3]
        return re.sub(r"冷却至中心温度≤\d+(?:\.\d+)?℃", f"冷却至中心温度≤{high}℃", clean, count=1)
    if slot == "cold":
        high = [12, 15, 18][variant % 3]
        return re.sub(r"冷藏库温度\d+-\d+℃", f"冷藏库温度{high}℃", clean, count=1)
    if slot == "thaw":
        low = [12, 16, 18][variant % 3]
        return re.sub(r"解冻时间\d+h", f"解冻时间{low}h", clean, count=1)
    if slot == "impl_date":
        d = datetime.strptime(doc["impl_date"], "%Y-%m-%d") + timedelta(days=45)
        return d.strftime("%Y-%m-%d")
    if slot in ("version", "signature"):
        return "X"
    if slot == "product":
        return doc["short"]
    if slot == "unit":
        return re.sub(r"(净重\d+(?:\.\d+)?)g", r"\1kg", clean, count=1)
    if slot == "flow":
        return doc["flow_injected"]
    if slot == "spec":
        m = re.search(r"\d+", clean)
        n = int(m.group(0))
        new = n - 30 if n >= 100 else max(20, n - 20)
        return clean[:m.start()] + str(new) + clean[m.end():]
    if slot == "std_conflict":
        m = re.search(r"\d+(?:\.\d+)?", clean)
        n = float(m.group(0))
        if "≤" in clean:
            delta = 10 if n >= 10 else 2
            new = n + delta
        elif "≥" in clean:
            new = n * 0.5
        else:
            new = n + 5
        return clean[:m.start()] + _fmt_num(new) + clean[m.end():]
    if slot == "cool_missing":
        return "冷却间温度按工艺经验控制"
    raise ValueError(f"未知槽位：{slot}")


def injection_plan(base_i: int, industry: str) -> list:
    """返回 3 份派生稿的注入槽位列表：4 / 3 / 2 个，共 8 个可计算 + 1 个语义。"""
    ring = {"烘焙": RING_BAKERY, "肉制品": RING_MEAT, "调味品": RING_CONDIMENT}[industry]
    p = (base_i * 3) % len(ring)
    d1 = [ring[(p + k) % 10] for k in (0, 2, 4, 6)]
    d2 = [ring[(p + k) % 10] for k in (1, 3, 5)]
    d3 = [ring[(p + 8) % 10], SEM_RING[base_i % len(SEM_RING)]]
    return [d1, d2, d3]


def build_gold_entry(doc: dict, l2_id: str, issue_n: int, slot: str,
                     clean_text: str, injected_text: str) -> dict:
    meta = SLOT_DEF[slot]
    point = meta["point"]
    kind, sheet, sel, col = _slot_parts(doc, slot)
    if kind == "step":
        row, col_letter = R_STEP_START + int(sel), col
    else:
        m = re.match(r"([A-Z]+)(\d+)", sel)
        row, col_letter = int(m.group(2)), m.group(1)
    label = {
        "center_temp": "加热中心温度", "center2_temp": "二次加热中心温度",
        "ppm": "消毒液浓度", "ppm2": "器具消毒液浓度", "cooling": "冷却终温",
        "cold": "冷藏暂存温度", "thaw": "解冻时长", "impl_date": "实施日期",
        "version": "版本号", "signature": "人员签名", "product": "商品名",
        "unit": "净重单位", "flow": "工序顺序", "spec": "同一产品净重",
        "std_conflict": "出厂检验限值", "cool_missing": "冷却终温标注",
    }[slot]
    return {
        "schema_version": "gold-v1",
        "file_id": l2_id,
        "issue_id": f"{l2_id}-G{issue_n}",
        "base_file_id": doc["file_id"],
        "layer": "L2",
        "industry": doc["industry"],
        "point_code": point,
        "point_name": POINT_NAME[point],
        "defect_type": meta["defect"],
        "evidence_text": injected_text,
        "clean_text": clean_text,
        "injected_text": injected_text,
        "location": {"page": None, "sheet": sheet, "row": row, "col": col_letter},
        "expected_state": "fail",
        "severity": meta["severity"],
        "source": "constructed_injection",
        "executor_rule": meta["rule"],
        "computable": meta["computable"],
        "issue": f"{label}：{clean_text} → {injected_text}（{doc['industry']}·{doc['product']}）",
    }


# ---------------------------------------------------------------- md 渲染（正文与 gold 同源）

def render_md(wb: Workbook, doc: dict, title_note: str) -> str:
    proc = doc["process_sheet_names"]
    pkg = "包装指示书"
    first = wb[proc[0]]
    product = str(first.cell(R_PROD, 14).value or "")
    version = str(first.cell(R_VERSION, 3).value or "")
    impl = str(first.cell(R_DATE, 3).value or "")
    design = wb[pkg].cell(4, 10).value
    unit = wb[pkg].cell(4, 14).value
    lines = [
        f"# {product} 生产工艺书（{doc['industry']}·{title_note}）",
        "",
        "> 构造数据（非任何企业真实工艺文件；参数为企业自定工艺参数，平台判据 85℃/200ppm/10℃/0-8℃/20h 非国标强制值）。",
        "> 与同名 .xlsx 内容一一对应；文末 `- R{行} | {列}: {值}` 为单元格定位，用于引文逐字校验。",
        "",
        "## 1. 产品概述",
        "",
        f"- 产品名称：{product}",
        f"- 所属行业：{doc['industry']}",
        f"- 文件版本：{version}",
        f"- 实施日期：{impl}",
        f"- 设计总重量：{design} {unit}",
        f"- 工艺路线：{' → '.join(str(wb[s].cell(R_PROC_NAME, 3).value or s) for s in proc)}",
        "",
        "## 2. 工艺流程",
        "",
    ]
    for i, s in enumerate(proc, start=1):
        pname = wb[s].cell(R_PROC_NAME, 3).value or s
        lines.append(f"{i}. {pname}（Sheet：{s}）")
    lines += [
        "",
        "## 3. 关键控制点",
        "",
    ]
    ccp_order = [("center_temp", "加热中心温度"), ("center2_temp", "二次加热中心温度"),
                 ("ppm", "消毒液浓度"), ("cooling", "冷却终温"),
                 ("cold", "冷藏暂存温度"), ("thaw", "解冻条件")]
    for slot, label in ccp_order:
        if slot not in doc["slots"]:
            continue
        val = read_slot_value(wb, doc, slot)
        lines.append(f"- {label}：{val}")
    lines += [
        "",
        "## 4. 工艺参数表",
        "",
        "| 工序 | 作业内容 | 作业条件 |",
        "|---|---|---|",
    ]
    for s in proc:
        ws = wb[s]
        for r in range(R_STEP_START, R_STEP_START + R_MAX_STEP_ROWS):
            a = ws.cell(r, 1).value
            if a is None or str(a).strip() == "":
                continue
            f = ws.cell(r, 6).value or ""
            l = ws.cell(r, 12).value or ""
            lines.append(f"| {a} | {f} | {l} |")
    equip = []
    for s in proc:
        ws = wb[s]
        for r in range(R_STEP_START, R_STEP_START + R_MAX_STEP_ROWS):
            u = ws.cell(r, 21).value
            if u and str(u).strip() and str(u).strip() not in equip:
                equip.append(str(u).strip())
    lines += ["", "## 5. 设备清单", ""]
    for i, e in enumerate(equip, start=1):
        lines.append(f"{i}. {e}")
    lines += ["", "## 6. 物料配比", "", "| 序号 | 物料名称 | 投入量 |", "|---|---|---|"]
    ws0 = wb[proc[0]]
    r = R_MATERIAL_START
    while r < R_STD_DOC:
        name = ws0.cell(r, 3).value
        if name is None or str(name).strip() == "":
            r += 1
            continue
        seq = ws0.cell(r, 2).value
        net = ws0.cell(r, 8).value
        lines.append(f"| {seq} | {name} | {net} |")
        r += 1
    lines += [
        "",
        "## 7. 中间控制",
        "",
        "- 每道工序由操作人自检并记录作业条件，品管员按批抽检关键控制点。",
        f"- 冷却后产品在转入下一工序前核对终温与暂存时限（见关键控制点）。",
        "- 发现偏离工艺参数时按偏差处理流程隔离并上报，不得直接放行。",
        "",
        "## 8. 成品检验",
        "",
    ]
    found = False
    for s in proc:
        ws = wb[s]
        for r in range(R_STEP_START, R_STEP_START + R_MAX_STEP_ROWS):
            a = str(ws.cell(r, 1).value or "")
            if "检验" in a:
                f = ws.cell(r, 6).value or ""
                l = ws.cell(r, 12).value or ""
                lines.append(f"- {a}：{f}；判定条件：{l}")
                found = True
    if not found:
        lines.append("- 按企业标准进行出厂检验。")
    lines += ["", "## 附：文档单元格原文（与 xlsx 同源，供引文逐字校验）", ""]
    for ws in wb.worksheets:
        lines.append(f"### Sheet: {ws.title}")
        by_row = {}
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None or str(cell.value).strip() == "":
                    continue
                by_row.setdefault(cell.row, []).append(
                    f"{cell.column_letter}: {_cell_value(cell.value)}")
        for rr in sorted(by_row):
            lines.append(f"- R{rr} | " + " | ".join(by_row[rr]))
        lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------- 静态合规自检（不触碰 DB）

def static_clean_check(xlsx: Path) -> list:
    """只 import 解析器/抽取器（无 DB），按平台判据校验干净稿数值。"""
    sys.path.insert(0, str(ROOT))
    from app.engine import engine, rexec  # noqa: E402
    doc = engine.parse_xlsx(str(xlsx))
    facts = rexec.extract_numeric_facts(doc.process_text)
    issues = []
    for f in facts:
        if f.metric == "温度" and f.scope == "中心温度" and f.value < 85:
            issues.append(f"中心温度<85: {f.sheet} {f.quote} → {f.value}")
        if f.metric == "温度" and f.scope == "冷却" and f.value > 10:
            issues.append(f"冷却温度>10: {f.sheet} {f.quote} → {f.value}")
        if f.metric == "温度" and f.scope == "冷藏暂存" and f.value > 8:
            issues.append(f"冷藏暂存>8: {f.sheet} {f.quote} → {f.value}")
        if f.metric == "浓度" and f.value < 200:
            issues.append(f"消毒浓度<200: {f.sheet} {f.quote} → {f.value}")
        if f.metric == "时间" and f.unit in ("h", "小时") and "解冻" in (f.row or "") and f.value < 20:
            issues.append(f"解冻<20h: {f.sheet} {f.quote} → {f.value}")
    versions = {h.version for h in doc.headers.values() if h.version is not None}
    if len(versions) != 1:
        issues.append(f"版本号跨 Sheet 不一致：{versions}")
    dates = {h.impl_date for h in doc.headers.values() if h.impl_date}
    if len(dates) != 1:
        issues.append(f"实施日期跨 Sheet 不一致：{dates}")
    names = {h.product_name for h in doc.headers.values() if h.product_name}
    if len(names) != 1:
        issues.append(f"商品名跨 Sheet 不一致：{names}")
    for sn, h in doc.headers.items():
        for role, val in h.signatures.items():
            if str(val).strip() in ("", "X", "x"):
                issues.append(f"签名占位符：{sn}/{role}={val!r}")
    return issues


# ---------------------------------------------------------------- 主构建

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_shasums() -> dict:
    files = sorted(p for p in BENCH.rglob("*") if p.is_file()
                   and p.name != "SHA256SUMS"
                   and "__pycache__" not in p.parts and p.suffix != ".pyc")
    lines, mapping = [], {}
    for p in files:
        rel = p.relative_to(BENCH).as_posix()
        digest = sha256(p)
        mapping[rel] = digest
        lines.append(f"{digest}  {rel}")
    (BENCH / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return mapping


def _count(entries: list, key: str) -> dict:
    out = {}
    for e in entries:
        out[e[key]] = out.get(e[key], 0) + 1
    return dict(sorted(out.items(), key=lambda kv: str(kv[0])))


def _clean_docs() -> list:
    docs = []
    for p in BAKERY:
        docs.append(_bakery_doc(p))
    for p in MEAT:
        docs.append(_meat_doc(p))
    for p in CONDIMENT:
        docs.append(_condiment_doc(p))
    return docs


README_TEMPLATE = """# 工艺书基准（process_sheet_benchmark v{v}）

> task-157（T-166）产物：**程序化模板批量生成**的工艺书审核基准数据集。
> 用于验证平台「文档解析 → 内置食品工艺包确定性命中 → gold 逐字校验」闭环。
> **性质：构造数据（clean=按模板构造；L2=在 clean 上逐格注入），不含任何企业真实工艺文件；
> 不能用于宣称客户真实工艺书准确率，也不能用于宣称对未见缺陷的泛化能力。**

## 0. 规模

| 层 | 份数 | 说明 |
|---|---|---|
| L1 干净底稿 | **{n_l1}** | 烘焙 {n_bak} / 肉制品 {n_meat} / 调味品 {n_cond}；每份 6-8 个章节（xlsx 多 Sheet + md 8 节） |
| L2 注入稿 | **{n_l2}** | 每个 L1 基底派生 3 份（每份 2-4 个注入） |
| gold 条目 | **{n_gold}** | 其中可被确定性执行器判定的 {n_comp} 条、语义判定 {n_sem} 条 |
| L3 / L4 | 0 | 本轮未做（NOT DONE，见报告） |

格式：每份文档同时提供 `.xlsx`（平台内置食品包可解析）与 `.md`（同内容文本版，供 LLM/引文使用）。

## 1. 快速使用

```bash
cd platform
PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
export PYTHONPATH=/tmp/qa_pylibs no_proxy=127.0.0.1,localhost
# 重建（固定随机性/固定文档属性时间，字节级可复现）
PYTHONPATH=/tmp/qa_pylibs $PY tools/build_benchmark_bulk.py
# 平台确定性与 LLM 两臂实跑（默认 Path B 抽样 8 份；--pathb-limit 可调）
PYTHONPATH=/tmp/qa_pylibs $PY tests/fixtures/process_sheet_benchmark/tools/run_benchmark.py
# 三道自动验收（逐字/point_code/schema/SHA）
PYTHONPATH=/tmp/qa_pylibs $PY scripts/qa/validate_generated_dataset.py \\
    tests/fixtures/process_sheet_benchmark
```

## 2. 数据口径

- 3 个细分行业、20 个产品；行业参数（烘焙中心温度/肉制品解冻与卤制/调味品蒸煮灭菌）均落在
  **平台食品点位判据**内：中心温度 ≥85℃、消毒液 ≥200ppm、冷却 ≤10℃、冷藏暂存 0-8℃、解冻 ≥20h。
  这些阈值是平台判据（`seed/library_supplement.json`），**不是国标数值**。
- L1 不含半成品清单（平台 B-2 依赖种子本体，非食品行业半成品名会被误判）；Sheet 名避开
  内置执行器硬编码的 `蔬菜前处理`/`肉类前处理`。
- L2 = L1 + **单格替换**：注入文本完整落在一个单元格内，`evidence_text` = 该单元格原文；
  注入稿与底稿的逐格差异数 == 该文件 gold 条目数（meta.json:construction.diff_report 可核）。
- gold 的 `location` 一律指向 **xlsx 单元格**（sheet/row/col），`clean_text` 为底稿同格原文。

## 3. gold schema（gold-v1，见 gold.json）

必填：`schema_version/file_id/issue_id/layer/industry/point_code/point_name/defect_type/
evidence_text/clean_text/injected_text/location/expected_state/severity/source/executor_rule/issue`。
本数据集额外提供：`base_file_id`（L2 对应 L1 基底）、`computable`（Path A 确定性执行器可否命中）。

`expected_state ∈ {{pass, fail, na, insufficient, unknown}}`；本数据集 L1 用 pass、L2 用 fail。
`source ∈ {{constructed_injection, real_restored, adversarial_designed, external_ai}}`。

## 4. 指标口径

- **clean-control FP**：L1 干净稿上的 finding 总数（预注册硬门槛 = 0）。
- **注入召回**：gold 条目中存在 finding 同时满足「执行器规则码映射到同一 point_code」且
  「finding 任一锚点 quote 逐字包含 evidence_text」。
- **L2 clamp**：注入稿上非 gold 的额外 finding 占比（预注册 ≤5%）。
- **五态分布**：内置执行器 `rule_status` 的 满足/不满足/不适用/证据不足/执行失败 计数。
- 语义类 gold（`computable=false`）是**故意注入**、Path A 无确定性执行器覆盖的类型，
  不计入 Path A 能力诿过；其召回在 Path B 单列。

## 5. SHA256

见 `SHA256SUMS`；`validate_generated_dataset.py` 默认重算校验（无缺项/无陈旧）。
"""


def main():
    ap = argparse.ArgumentParser(description="程序化批量生成工艺书基准数据集")
    ap.add_argument("--no-clean-check", action="store_true", help="跳过静态合规自检")
    args = ap.parse_args()

    docs = _clean_docs()
    assert len(docs) == 20, len(docs)
    by_ind = {}
    for d in docs:
        by_ind[d["industry"]] = by_ind.get(d["industry"], 0) + 1
    assert by_ind == {"烘焙": 7, "肉制品": 7, "调味品": 6}, by_ind

    # 清理旧产物（仅本数据集目录；不触碰任何 DB）
    for pyc_dir in BENCH.rglob("__pycache__"):
        shutil.rmtree(pyc_dir, ignore_errors=True)
    INPUT.mkdir(parents=True, exist_ok=True)
    for p in INPUT.iterdir():
        if p.is_file() and (p.name.startswith("L1_") or p.name.startswith("L2_")
                            or p.name.startswith("L3_") or p.name.startswith("L4_")):
            p.unlink()
    for name in ("validation.json", "metrics.json"):
        f = BENCH / name
        if f.exists():
            f.unlink()

    entries, clean_control, diff_report, base_index = [], [], [], []
    written = []
    n_gold = 0
    for base_i, doc in enumerate(docs):
        wb_clean = build_workbook(doc, {})
        clean_cells = workbook_cells(wb_clean)
        slot_clean = {s: read_slot_value(wb_clean, doc, s) for s in doc["slots"]}

        rel = f"L1_{doc['idx']:02d}_{doc['industry']}_{doc['product']}"
        xlsx = INPUT / f"{rel}.xlsx"
        md = INPUT / f"{rel}.md"
        save_workbook(wb_clean, xlsx)
        md.write_text(render_md(wb_clean, doc, "干净底稿"), encoding="utf-8")
        written += [xlsx, md]
        clean_control.append({
            "file_id": doc["file_id"], "layer": "L1", "industry": doc["industry"],
            "product": doc["product"], "expected_state": "pass", "expected_findings": 0,
        })
        if not args.no_clean_check:
            issues = static_clean_check(xlsx)
            if issues:
                raise SystemExit(f"[FATAL] 干净稿静态合规自检失败 {doc['file_id']}：\n" + "\n".join(issues))

        plans = injection_plan(base_i, doc["industry"])
        base_index.append({"base_file_id": doc["file_id"], "industry": doc["industry"],
                           "product": doc["product"],
                           "l2_file_ids": [f"PS-L2-{(base_i * 3 + k + 1):02d}" for k in range(3)]})
        for k, plan in enumerate(plans):
            l2_id = f"PS-L2-{(base_i * 3 + k + 1):02d}"
            variant = base_i * 3 + k
            injections = {}
            for slot in plan:
                clean_text = slot_clean[slot]
                injected_text = transform_injection(doc, slot, clean_text, variant)
                if injected_text == clean_text:
                    raise SystemExit(f"[FATAL] {l2_id} 槽位 {slot} 注入未生效")
                if any(w in injected_text for w in ("大约", "左右", "若干", "酌情", "视情况", "约")):
                    raise SystemExit(f"[FATAL] {l2_id} 槽位 {slot} evidence 含模糊词：{injected_text}")
                injections[slot] = injected_text
            wb_inj = build_workbook(doc, injections)
            cells_inj = workbook_cells(wb_inj)
            diffs = []
            for sheet in cells_inj:
                if sheet == "工艺参数表":
                    continue
                d1 = {(r, c): v for r, c, v in clean_cells[sheet]}
                d2 = {(r, c): v for r, c, v in cells_inj[sheet]}
                for key in sorted(set(d1) | set(d2)):
                    if d1.get(key) != d2.get(key):
                        diffs.append({"sheet": sheet, "row": key[0], "col": key[1],
                                      "clean": d1.get(key), "injected": d2.get(key)})
            if len(diffs) != len(plan):
                raise SystemExit(f"[FATAL] {l2_id} 逐格差异 {len(diffs)} != 注入数 {len(plan)}：{diffs}")
            mismatch = _param_sheet_mismatches(wb_inj, doc)
            if mismatch:
                raise SystemExit(f"[FATAL] {l2_id} 工艺参数表与工序页不同源：{mismatch[:3]}")
            for n, slot in enumerate(plan, start=1):
                n_gold += 1
                entries.append(build_gold_entry(
                    doc, l2_id, n, slot, slot_clean[slot], injections[slot]))
            rel2 = f"L2_{l2_id[-2:]}_{doc['industry']}_{doc['product']}_注入{k + 1}"
            xlsx2 = INPUT / f"{rel2}.xlsx"
            md2 = INPUT / f"{rel2}.md"
            save_workbook(wb_inj, xlsx2)
            md2.write_text(render_md(wb_inj, doc, f"注入缺陷版（派生{k + 1}）"), encoding="utf-8")
            written += [xlsx2, md2]
            diff_report.append({"file_id": l2_id, "base": doc["file_id"],
                                "diff_count": len(diffs), "diffs": diffs,
                                "diff_only_gold": len(diffs) == len(plan)})

    assert len(entries) == 180, len(entries)
    comp = sum(1 for e in entries if e["computable"])
    sem = len(entries) - comp

    gold = {
        "schema_version": "gold-v1",
        "benchmark_id": BENCHMARK_ID,
        "version": BENCH_VERSION,
        "created_at": "2026-11-19",
        "nature": "构造数据（L1=按模板程序化构造的干净底稿；L2=在 L1 上单格注入），不含企业真实工艺文件",
        "generator": "tools/build_benchmark_bulk.py（模板+参数集，不依赖 LLM）",
        "clean_control": clean_control,
        "entries": entries,
        "stats": {
            "gold_entries": len(entries),
            "clean_control_files": len(clean_control),
            "computable_entries": comp,
            "semantic_entries": sem,
            "by_point": _count(entries, "point_code"),
            "by_defect_type": _count(entries, "defect_type"),
            "by_severity": _count(entries, "severity"),
            "by_industry": _count(entries, "industry"),
            "by_computable": {"可计算(Path A)": comp, "语义(Path B)": sem},
        },
    }
    (BENCH / "gold.json").write_text(
        json.dumps(gold, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

    meta = {
        "benchmark_id": BENCHMARK_ID,
        "version": BENCH_VERSION,
        "created_at": "2026-11-19",
        "task": "task-157 / T-166 自己批量造数据：工艺书 L1 20 + L2 60 + 准确率基线",
        "generator": "tools/build_benchmark_bulk.py",
        "generation_method": "程序化模板 + 显式参数集（不调用 LLM 生成正文）；固定文档属性时间与 zip 时间戳，字节级可复现",
        "nature": "构造数据（不是企业真实工艺文件）",
        "layers": {"L1": 20, "L2": 60, "L3": 0, "L4": 0},
        "industries": {"烘焙": 7, "肉制品": 7, "调味品": 6},
        "formats": {"xlsx": 80, "md": 80},
        "document_roles": {
            "xlsx": "平台内置食品工艺包（app.engine.engine.parse_xlsx/build_report）可解析执行",
            "md": "同内容文本版（8 个章节 + 单元格原文附录），供直连大模型/通用 runner 与引文逐字校验使用",
        },
        "document_structure": {
            "xlsx_sheets": "4-5 个工序 Sheet（表头四要素 + 原材料清单 + 标准工序表）+ 工艺参数表 + 包装指示书 = 6-8 个章节",
            "md_sections": ["产品概述", "工艺流程", "关键控制点", "工艺参数表", "设备清单",
                            "物料配比", "中间控制", "成品检验"],
        },
        "parameter_basis": {
            "note": "干净稿参数按行业常识取值并满足平台食品点位判据；85℃/200ppm/10℃/0-8℃/20h 是平台点位判据，不是国标数值",
            "platform_criteria": PLATFORM_CRITERIA,
            "public_sources": [
                "GB 14881-2025 食品安全国家标准 食品生产通用卫生规范（6.1.1 危害分析/关键控制点；13.1.1.2 工艺参数记录）",
                "《肉制品生产许可审查细则（2023版）》第45/46条（热加工中心温度与时间、冷却温度时间）",
                "《食品安全国家标准 速冻面米与调制食品》GB 19295-2021 4.2（≤-18℃）",
                "《餐饮服务食品安全操作规范》（2018修订）熟制中心温度≥70℃、热藏≥60℃/冷藏≤8℃",
                "GB 2717-2018 酱油（氨基酸态氮 ≥0.4 g/100mL）；GB 2719-2018 食醋（总酸 ≥3.5 g/100mL）",
            ],
        },
        "construction": {
            "method": "L1 = build_benchmark_bulk.py 按行业模板 + 参数集构造；L2 = L1 + 每份 2/3/4 处单格替换",
            "diff_only_gold": all(r["diff_only_gold"] for r in diff_report),
            "diff_report": diff_report,
            "injection_plan": "每个基底派生 3 份（4/3/2 个注入 = 8 个可计算缺陷 + 1 个语义缺陷），共 20×9=180 条 gold",
            "clean_transformations": [
                "表头四要素跨 Sheet 统一：版本号/实施日期/商品名/签署",
                "不含半成品清单：避免平台 B-2（依赖种子本体，非食品基准行业名不在本体）在干净稿误报",
                "Sheet 名避开内置执行器硬编码的 蔬菜前处理/肉类前处理：避免 E3/E4 错误适用",
                "参数取值同时满足平台点位判据与行业常识（例：烘焙中心温度 91-96℃）",
                "成品检验/菌落/理化限值放在工序 Sheet 的作业条件列时避开 ppm/mg/kg 数值，避免被消毒浓度规则误抽",
            ],
            "base_index": base_index,
        },
        "gold_stats": gold["stats"],
        "honesty": {
            "not_real_customer_data": True,
            "cannot_claim": "客户真实工艺书准确率 / 对未见缺陷的泛化能力",
            "same_document_injection_upper_bound": "被审文档即含注入缺陷的文档，规则按平台点位判据执行，属上界实验",
            "deterministic_only": "Path A 实跑的是平台内置食品包确定性执行器（18 个检查函数）；语义类 gold（unit/flow/spec/std_conflict/cool_missing）无确定性执行器覆盖，单独标记 computable=false",
            "parameter_provenance": "全部参数为企业自定工艺参数（构造值），平台判据阈值不是国标数值",
        },
    }
    (BENCH / "meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

    readme = README_TEMPLATE.format(
        v=BENCH_VERSION, n_l1=20, n_bak=7, n_meat=7, n_cond=6, n_l2=60,
        n_gold=len(entries), n_comp=comp, n_sem=sem)
    (BENCH / "README.md").write_text(readme, encoding="utf-8")

    sums = write_shasums()
    print(f"[build] 写入 {len(written)} 个输入文件（L1 20×2 + L2 60×2）")
    print(f"[build] gold entries={len(entries)}（可计算 {comp} / 语义 {sem}）clean_control={len(clean_control)}")
    print(f"[build] diff_only_gold={meta['construction']['diff_only_gold']}")
    print(f"[build] by_defect_type={gold['stats']['by_defect_type']}")
    print(f"[build] by_point={gold['stats']['by_point']}")
    print(f"[build] by_industry={gold['stats']['by_industry']}")
    print(f"[build] SHA256SUMS 覆盖 {len(sums)} 个文件")
    print(f"[build] 输出目录：{BENCH}")


if __name__ == "__main__":
    main()
