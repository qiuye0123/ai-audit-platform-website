# PROJECT_MEMORY — AI 审核平台「规衡」

> 项目地图（跨会话保持一致）。**本文件只写当前真实状态**，不写历史方案。
> 版本：1.5.0-20261118 基线 ｜ 最后更新：2026-11-18
> 开工顺序：`AGENTS.md`（铁律）→ 本文件（地图）→ `docs/CURRENT/00-索引.md` → `docs/CURRENT/07-已知问题与NOT-DONE.md`
> 版本控制：**当前无 git**（清理方案阶段 1 待执行）；关键状态由 `docs/qa/基线清单_20261118.txt`（966 文件 SHA256）固化

---

## 一、这是什么

企业级**规则驱动的文档审核平台**。企业把审核标准写成规则，平台执行规则、给证据、交人工复核、出报告，并把复核结果沉淀回规则。

第一场景：**食品生产工艺书审核**；同样适配合同、招标文件、质量记录、申报材料。

**产品边界（不可越界）**：
- 平台输出「差异 / 缺口 / 待人工确认」，**不输出「合规/不合规」法律结论**
- 不替代人做最终判断；人必须 100% 复核展示项
- 不做视频/图像内容审核；图片只做 OCR 取字
- 不宣称「100% 准确」或「全面超过直连大模型」——准确率见 §七

## 二、技术栈

| 层 | 选择 | 备注 |
|---|---|---|
| 语言 | Python **3.10+**（实测 3.12） | 系统 3.9 会因 `X \| None` 语法直接失败；`start.sh`/`rp` 有解释器选择逻辑 |
| HTTP | 标准库 `http.server` 多线程 | 无 FastAPI/Flask |
| 前端 | 原生 HTML/CSS/JS，无框架 | 四端各自 HTML + 共享 `app.js`/`style.css` |
| 存储 | SQLite（**87 张表**） | `app/db.py` 单一 schema + 幂等迁移 |
| 依赖 | `openpyxl` `python-docx` `pypdf` `pypdfium2` `pillow` `requests` | 见 `requirements.txt` |
| 默认端口 | 8765（`RULEPROOF_PORT`） | |

## 三、目录地图

```text
platform/
├── AGENTS.md            工程铁律（打包进交付包）
├── PROJECT_MEMORY.md    本文件：项目地图
├── README.md            30 秒上手
├── VERSION              1.5.0
├── rp                   CLI 入口（bash → python3 -m app.cli）
├── start.sh             一键启动（含 Python 3.10+ 选择）
├── seed.py              种子：角色/权限/内置规则/四端演示账号
├── seed_demo_bulk.py    演示数据批量扩充（大项目/发现/日志）
├── app/
│   ├── config.py        配置单一事实源（.env + 环境变量）
│   ├── db.py            87 表 schema + 连接/事务
│   ├── repositories.py  Repository 层
│   ├── auth.py          JWT 会话 + token_version 失效
│   ├── cli.py           全部 CLI 命令
│   ├── api/             server.py(5574 行) + 24 个 *_routes.py 模块
│   ├── services/        133 个服务模块（业务逻辑都在这）
│   └── engine/          LLM/OCR/规则执行/解析/事实抽取/IR
├── web/                 四端 HTML + JS；architecture/ 21 张架构图
├── scripts/qa/          gate.py + 270+ 测试脚本
├── tests/               test_suite.py（119 项）+ fixtures
├── docs/CURRENT/        当前真相（10 文件）
├── docs/qa/             过程证据（按日期）
├── docs/architecture/   架构图集与报告
├── dist/                交付包与验收证据
├── migrations/          SQL 迁移
└── sdk/                 开放平台 SDK
```

## 四、四个门户（服务端强制隔离）

| 角色 | 登录入口 | 首页 | 能做什么 | 不能做什么 |
|---|---|---|---|---|
| 审核员 `reviewer` | `/reviewer/login` | `/reviewer` | 本人项目全流程、复核、建规则草稿、知识库 | 发布规则、看本体/词典、看账号/模型/审计/运维 |
| 业务管理员 `admin` | `/admin/business/login` | `/admin/business` | 本租户项目只读、规则发布、冲突裁决、本体/词典、知识库、空间 | **新建项目**、复核、跨租户 |
| 系统管理员 `super_admin` | `/admin/system/login` | `/admin/system` | 模型/智能体/账号/开放平台/通知/数据边界/审计/运维 | 审核业务视图 |
| 平台运营 `platform_op` | `/platform/login` | `/platform` | 租户开通/维护、租户管理员、平台管理员、架构图、消息 | 任何业务接口 |

演示账号（`seed.py` 输出）：
```text
系统管理员 13800000000 / 首次登录强制改密（密码只在 seed 输出行打印一次）
审核员     13700002222 / Rev@123456
平台运营   13600003333 / Plat@123456
业务管理员 13500001111 / Acme@123456
```

## 五、审核主链（唯一路径）

```text
建项目 → 上传(docx/xlsx/pdf) → agent-parse 解析(可 OCR)
→ manifest 冻结：规则+版本+证据要求+scope 快照 + aliases/terms 快照
→ D1 适用性 → D2/D3 事实抽取与证据定位 → D4 判据执行 → D5 结论
→ finding 五态：pass / fail / na / insufficient / unknown
→ 人工复核(确认/误报/证据不足/规则路由错误) → 隐藏池(默认关) + 人工漏报
→ 报告门禁 → HTML/DOCX 报告 → 反馈沉淀 → 定向复审
```

关键契约：
- **生效规则** = `current_version_id` 且该版本 `published`；不读 `rule.status`
- **五态不可合并**：insufficient ≠ fail，unknown ≠ pass，na 不进 unknown
- **证据** 必须回原文锚点 `{quote, locator, content_hash}`
- **解析缺口**必须让缺失类证据降为 insufficient，不得记 fail
- **隐藏池**打开需二次确认 + 写审计；评测/盲审模式提交独立复核前不显示 N

## 六、规则体系

- 生命周期（2026-11-18 起**无审批**）：`draft ──直接发布──> published`；回滚为草稿；`pending/approved` 只作历史
- 发布后只做**冲突提醒**，不阻断不回滚
- 规则形式：单条规则 / 决策表 / 审核库点位（无独立决策表 tab）
- 规则库只显示已发布/生效；草稿在**草稿箱**独立菜单
- 编辑已发布规则 fork 新草稿版本，旧版本继续生效，发布后 superseded
- 冲突三态：已证明冲突 / 未发现冲突 / 无法判定；裁决六路径
- 规则进化：反馈 → 候选 → 人工确认 → 草稿（不自动发布）

## 七、模型与 OCR（四态：未配置/已配置待测/连接正常/连接失败）

| 能力 | 主 | 备 | 状态 |
|---|---|---|---|
| 对话/判定 | DeepSeek `deepseek-chat` | 其他已配置 chat 模型自动兜底 | 有 Key 即真实调用 |
| OCR | 百度 Unlimited-OCR-2 | PaddleOCR-VL | Paddle 无凭据 → 未配置（不伪造） |
| 视觉兜底 | 视觉模型识别扫描页 | — | **仅辅助**；数值事实不得来自通用视觉模型 |

- 统一入口 `app/engine/llm_router.py`：DB 默认 → DB 可用 chat 候选 → 环境变量 → NONE
- 租户 `external_model=deny` 时**发送前拒绝**（fail-closed）
- 7 个智能体：`agent-parse / fact / rulegen / conflict / judge / fp / ruleminer`；无模型时显式 `degraded/skipped`，不伪装执行

## 八、准确率现状（**未达标，不得宣称达标**）

| 数据集 | 指标 | 值 | 状态 |
|---|---|---|---|
| CT | F1 | 0.0925 | 历史口径，本轮未重跑 |
| P01 | F1 | 0.2094 | 历史口径，本轮未重跑 |
| BX | F1 | 0.7839 | 历史口径，本轮未重跑 |
| 阶段3 直连TP覆盖 | 条目/定位 | FAIL | 4 轮未达双 100% |

- clean-control 门禁策略：S1=0 FP / S2≤5 / S3≤10 / 总≤15 per 100 docs
- P01/CT/BX **本轮 NOT TESTED**；旧数字只作历史对照
- 准确率门禁阈值目前**小于测量噪声**（PL-2 未修）

## 九、测试与门禁

```text
全量 gate：python3 scripts/qa/gate.py        275 项 → 基线 PASS 273 / FAIL 0 / SKIP 3
单元：    python3 tests/test_suite.py        119/119
主链：    python3 scripts/qa/full_chain.py   38/38
UI：      scripts/qa/ui_audit.py             ui_issue_count 0
包验证：  dist/validate_final_package_*.py   68/68
```

gate 分域：安全/权限 34、规则 70、审核主链 104、UI 11、CLI 5、模型OCR 4、智能体 16、打包 7、其它 24。
**缺口**：知识库测试未登记进 gate、架构图校验只在包 validate。

## 十、当前状态（2026-11-18 22:2x）

```text
可以：本地起服务、四端登录、审核主链跑通、规则发布/冲突裁决、报告生成、CLI 全链路
阻断：评审吸收 C-1/TL-1/TL-6/C-6/C-5 修复进行中（task-129）
      C-4/TL-5/PL-2 未开工
      包已被判定阻断，须修复后重打包
```

**详细已知问题见 `docs/CURRENT/07-已知问题与NOT-DONE.md`**（唯一权威清单）。

## 十一、约定（不可违背）

```text
1 不伪造：没跑过写 NOT TESTED；跑不通写 FAIL；SKIP 不算 PASS
2 不静默失败：禁止 except: pass；异常上抛或留结构化日志
3 CLI 与 HTTP 同源；前端隐藏 ≠ 权限，服务端必须 403
4 关键写操作审计必须同事务（audit.log_in_tx）；审计失败业务回滚
5 审计日志只读、不可导出；AppSecret 只一次性展示
6 重置密码必须随机临时密码，7 天过期，首次登录强制改密
7 无真实数据来源的按钮/统计/消息不得显示为已生效
8 演示库 data/ruleproof.db 不进包；包内由 seed.py 现场生成
```

## 十二、长期待办（等用户指令）

```text
TODO-1 架构图更新 → 已完成（T-113，manifest v4.1，21 图）
TODO-2 3 分钟视频：脚本+旁白+全套生成提示词+简化视频草稿 → 未开始
入口：docs/delivery/待办任务_长期_20261117.md
```
