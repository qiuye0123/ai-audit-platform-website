# CHANGELOG

本文件记录版本变更。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。
日期为 Asia/Shanghai。

## 2026-11-26 · 1.6.0（build57 / 部署前收口）

- 版本统一：正式交付文档/表格/手册升级到 **1.6.0**；历史 QA 证据保持原版本，不破坏审计哈希。
- 外部独立审查 7 项（F-01…F-07）修复：CLI rule create 真实 actor、validate 自检正则/__pycache__、CORS 白名单、freeze_closure legacy 契约、功能总表指纹/full 模式、外部验收文档口径、full_chain/l147 环境依赖。
- 新增外部评审 P1 修复：CLI ppb/ppm 与温度 F22/F23 同源、签名 X 报告门禁 verified（L178）。
- 新增：死代码/半接线清理（dead_functions 18→5、dead_modules 12→8、undoc switches 15→0、half-wired 27→14）；CLI 覆盖 150/209→166/209；审核台 P2 四项；E2E 328/328。
- 新增文档：功能总表 311 行、规则体系总表 22 sheets/569 规则、全链路路径总表 578 行、四角色手册 48–64 页/25–35 截图、文档总清单 747 项。
- 挑战集：Codex/Gemini 两套校验通过；平台语义 vs 直连首轮样本（Codex .781/.056，Gemini .896/.839；非确定性主链 F1）。
- 边界：客户真实 gold/369 clean-control/OCR 质量/云端 Docker/TLS 未完成；不得宣称商业 SLA。



> 说明：本项目在 2026-11-18 之前无 git，历史条目根据 `docs/qa/` 与 `docs/交付/` 的当日报告回溯。
> 2026-11-18 22:55 起有 git（tag `v1.5.0-20261118-baseline`），此后每条变更可按 commit 追溯。

---


## 2026-11-19 决策：放弃 Zev（智跃开放平台）

- **决定**：⛔ 放弃 Zev-1 融合，不投（用户 2026-11-19 决定）
- **依据**：探测确认 api.zleap.com 是**工具 API**（search/fetch/parser/convert/translate），
  **不是 LLM**（无 chat/completions）→ 无法提升判定准确率；
  唯一互补场景（扫描件多模态解析）因仓库内 58/58 份 PDF 全有文本层、0 份图片型 → 始终 NOT TESTED
- **处置**：删除 `scripts/ai/zev_client.py`；撤销本机存储的 API Key（`~/.config/ruleproof/zev.key`）；
  `docs/qa/Zev接口探测_20261119.md` 标注「已放弃 · 仅供留档」；CURRENT/07、08、00、13、10 同步
- **后续**：准确率攻坚聚焦「规则判据生成」与「直连发现源 + 平台账本」两条线，不再评估外部 API 拼接


## 2026-11-19 下午（build11 前）

- **DuMate 12 条质疑全闭环**：E-11（失败当成功）/E-13（发布不可追溯）修复 + E-12（KPI 双分母）修复；
  其余 9 条复核 **9/9 PASS，0 项"代码在但没生效"**
- **规则生效口径收口**（架构审查唯一「必须重构」P0）：新增 `effective_rule_rows()`，
  24 处调用点（14 改 / 9 判定不改 / 1 受写作用域限制）；真实库 15 条漂移规则 0/15→15/15；
  P01 A/B ΔF1 −0.13pp（95% CI [−2.27,+1.96]，p=0.9，accuracy_gate PASS）→ **默认开启**，env=0 可回滚
- **新增门禁**（277→283 条）：本体添加失败提示 / 本体发布可追溯 / 规则库KPI口径 / 规则生效口径 /
  库隔离扫描 / 准确率报告口径 / clean-control上界
- **本机 AI 驱动能力打通**：`scripts/ai/drive_local_ai.sh`（驱动 DuMate 内置 opencode 跑数据集生成与复测）
- 工艺书 10 阶段主链首跑（L1 20 + L2 60）+ 3 个平台误报修复（进行中，见专项报告）


## 2026-11-19 清理与备份（lead 决策）

- **删除 `_archive/`（636M → 0）**：旧手册 170M / 旧包解压副本 106M / 旧包 zip 197M（3 个）/
  旧视频成片 75M / `docs/_archive` 83M 已随前一批清理移除；本次删除剩余 38M
  （`video-out` 20M / `git` 17M / 验收证据_20261117 228K / 其他）
- **备份迁移**：git bundle（17M，含 build9 tag）→ 工作区外 `../_backup/`；
  `draft_sub.mp4`（16M）→ `../_backup/video/`；`platform-feishu.png` → `../_backup/`
- **Chrome QA 临时 profile 清理**：`.chrome-ui` 154M / `.chrome-wb2` 147M / `.chrome-lib` 41M /
  `.chrome-wb` 6.6M / `.chrome-ia` = 349M（测试时生成的浏览器用户数据，脚本每次重建）
  → 删除，并在 `.gitignore` 增加 `.chrome-*/`
- **build 残留清理**：`dist/AI审核平台-…/`（解压目录 110M）删除（validate / 起服都自己解压到 /tmp）
- 工作区从 1.2G → **393M**（platform 目录）；校验：`git bundle` 真实 clone 恢复演练通过
  （HEAD=c14229f、3 个 tag、1733 文件、AGENTS.md 含铁律 6）
- **注意**：`_archive` 内的历史产物已彻底删除，只有 `../_backup/` 的 git bundle 保留全量源码历史；
  旧包 zip 不再保留（可从 git tag + build 脚本重建）


## 2026-11-19（T-146 / T-148 / T-149 / T-150 / T-151 / T-152）

### 修复
- **T-146 误报修复**：干净底稿 80 份 有 finding 80/80 → **0/80**，finding 200 → **0**
  - F-日期 改为「按字段语义归类，只判同一字段 ≥2 个不同值」（不同字段各一值属正常业务事实，不报）
  - F-单位 改为「同指标标签 + 数值近似相等 + kg/g 互差 1000 倍」才报
  - 兜底白名单：只补确定性可解释事实；**degraded/probable 结论一律不进兜底**
  - 代价：P01 弃权变多（FN abstain 43→53），P01 F1 .2094→.1969（-0.0125，噪声带内但方向可靠）
- **T-148 PDF 渲染能力探测**：`pdf_render_capability()` 三态（available/unavailable/unknown）
  - 图像 PDF 不再静默 0 字符：`parse_status=partial` + `ocr_unavailable=True` + 摘要前缀 `[OCR 能力不可用]`
  - audit 的 ocr 阶段 reason 从「OCR 引擎未配置」改为「PDF 渲染能力不可用（含真实 dylib 报错）」
  - 新测试 42/42，已加入 gate（第 277 条）
- **/reviews 兼容契约**：夹具随 T-146 兜底口径更新（版本号：X → F-版本），断言未放宽

### 清理
- **T-149 目录分层**：`docs/manual`(45.9M) + `manual_v2`(10.4M) + `artifacts`(29.9M) → `docs/_archive/`（375 文件 86.1MB）
  - dist 880MB → 400MB（删 build5 坏包 190M + 解压目录 243M + 20261116 移归档 46M）
  - 工作区 1.5G → 1.1G；打包排除规则 `{"manual","manual_v2"}→{"_archive"}`
- **T-150 CURRENT 补齐**：02-审核主链契约（246 行）/ 03-架构地图（181 行）/ 13-开工清单（109 行）

### 实测（重点：负结果也是结果）
- **T-151 E1 V3B 复现 PASS**：F1 **1.0**（TP114/FP0/FN0），predictions/score **字节级复现** 11-17 冻结产物
- **T-151 E4 判据翻译 FAIL**：可翻译率 29/41=70.7%、复算一致率 29/29=100%，但 **FP 过滤率 0/40=0%**
  - 根因：直连的 40 条「FP」在事实层几乎全是真的（29 条可复算的全部被原文确认；18+2 条对应 gold 12 条标准问题只是码归属不同；20 条是 gold 未收录的真实观察）
  → 结论：「判据复算」只能验证不能过滤；真瓶颈是码归属/判据标准/金标覆盖
- **T-152 当前源码复跑**：P01 .1969 / CT .0965 / BX .7862（均未达标；单轮非确定，不构成验收基线）
- **T-152 na_recheck A/B**：Δ tp+1（判据≥4）→ 保持默认关闭；但 3 个采纳都是真跨条款矛盾
- **T-152 CT 路由机制纠正**：真因不是 `_audit_category_gate`，是「44 份 CT 横跨 14 类但统一按招标文件建项目」
  → `manifest._object_route` case_hint 优先导致 14 类规则被 freeze 判 `audit_type_not_routed`

### 新增诊断工具
- `scripts/qa/diagnose_rerun.py`（读 T-65 产物出四桶 case 级样本）
- `scripts/qa/diagnose_evidence.py` / `diagnose_pass_miss.py` / `diagnose_code_attr.py` / `_diag_common.py` / `ct_route_probe.py`
- `scripts/qa/direct_criterion_translate.py`（E4 判据翻译器）
- `scripts/qa/pdf_render_capability_test.py`

### gate
- 277 条 → **PASS 274 / FAIL 0 / SKIP 3**（耗时 1086.9s）

### 已知新根因（未修，见 CURRENT/07 §6.4）
- N-1 同内容跨码重复上报（78/103 码归属 FP 是多码重复；去重后 F1 .1969→.2375）
- N-2 CT 路由真因（case_hint 优先 vs 每份文档类型）
- N-3 「证据/定位桶」其实是 finding 粒度（引文不在原文 0 条）
- N-4 pass 漏报是「未联读冲突条款」（22/34）

## [Unreleased] — 待发布（2026-11-18 22:0x–23:3x）

### 修复 — 评审吸收 P0（T-136 / task-129）

- **C-1 硬阻断**：未发布草稿的 scope 写回 `rule` 主记录，导致 `manifest.freeze()` 读取到被草稿污染的
  作用范围，**编辑草稿会改变旧生效版本的审核对象**。
  改法：作用域改为**版本级快照**（`app/services/rule.py` `:1021/:1180/:1271/:1621/:1861/:2914`）；
  freeze 读「生效 published 版本」的 scope，旧数据回退主记录并在快照里标来源
  （`app/services/manifest.py` `:130/:1842/:2030`）。
- **TL-1 契约级**：`fallback=fail` 把 insufficient/unknown 改写成 fail，与文档「insufficient 不是 fail」矛盾。
  改法：fail 拆 `fail_by_violation`（真违规）/ `fail_by_absence`（缺失/解析/证据不足），后者 →
  `insufficient` + 原因（`app/services/manifest_exec.py:3529`）。
- **TL-6 契约级**：`parse_gap` 不联动 missing-evidence，解析缺口下仍产出 fail finding。
  改法：新增 `_parse_gap_presence()`，缺失类证据判定读 `document.parse_status`；搜索范围 × parse_gap
  相交 → `insufficient` + `reason=parse_gap_search_scope`（`manifest_exec.py:1164/:1288`）。
- **C-6 条件阻断**：范围读取异常 / 显式空选择 fail-open 扩大审核范围。
  改法：三态分离 —— `None`=未指定（全量）/ `[]`=显式 0 条（拒绝冻结）/ 读取异常=fail-closed
  （`app/services/manifest.py:1726`）。
- **C-5**：计算/关系类证据门禁过宽（出现 `result`/`value` 任一字段即 passed）。
  改法：计算类最小集 = 操作数行 + 公式 + 单位 + 复算结果；关系类 = 规则端锚点 + 对象端锚点 +
  连接依据；缺项显式列出并降 insufficient（`manifest_exec.py:1089/:1206/:1230/:1375/:4348`）。

**验收**：新增 `scripts/qa/absorb_p0_test.py`（33/33 PASS，含 6 条「旧口径复现点」双向断言）。
回归：test_suite 119/119、full_chain 38/38、core_p0_fix 80/80、permission_p0 105、
code_review_fix 61/61、silent_failures 112=基线。

### 修复 — DuMate 全量质疑 E-01..E-09

| 编号 | 问题 | 改法 |
|---|---|---|
| E-01 | 系统端首页「3 账号」与「账号安全 7 启用」口径冲突 | `health.accounts` 改本租户口径（排除 platform_op/已删除）— `app/services/home.py` |
| E-02 | 平台端初始账号「不可操作」但接口允许编辑 | 保护判定统一按「初始手机号 or id」，且**先于**参数校验 — `app/services/tenants.py`；平台管理员页加受保护账号说明 + CLI 轮换路径 — `web/platform.html` |
| E-03 | 同一账号在平台端显示「管理员」、系统端显示「系统管理员」 | `list_tenant_admins` 下发 `role_code`/`role_label`；平台端角色列显示真实角色 — `app/services/tenants.py` + `web/platform.js` |
| E-04 | 审核端首页「待处理冲突」未标注「仅本人可裁范围」 | KPI hint 按角色区分 — `app/services/home.py`（首版参数写反，已由回归发现并修正） |
| E-05 | 待复核列表只列 8 个项目（158 条）与顶部 212 不闭合，无「查看全部」 | 下发 `todo_total`/`todo_shown`/`todo_pending_total`；前端补「共 N 个项目…仅展示前 8 个 → 查看全部项目」— `home.py` + `web/app.js` |
| E-06 | `/favicon.ico` 登录前 401、登录后 404 污染控制台 | `do_GET` 开头（guard 之前）返回 204 — `app/api/server.py`（首版误加在 `do_POST`，已由回归发现并修正） |
| E-07 | 首次登录后立即点菜单被 boot 覆盖回首页 | 新增 `_bootUserNavigated` 显式标记，menu/[data-go] 点击置 true，`loadUser` 只在未主动导航时兜底渲染首页 — `web/app.js`（首版用 `!currentView` 判断，因 `currentView` 初值即 `"home"` 导致**三端首屏空白**，已二次修复） |
| E-09 | 工作台「其他疑似问题 (0)」入口 0 条仍可点 | 两条入口（`#wb106-btn-hidden` / `#wb-hidden-toggle`）0 条时 `disabled + aria-disabled + title 原因` — `web/workbench_view.js` |

**验收**：`docs/qa/DuMate质疑处理_20261118.md`（15/15 + 9/9 PASS）；
独立回归 `docs/qa/DuMate修复回归_20261118.md`（10 项 0 FAIL、真实 HTTP 6/6 PASS、sysadmin 134/134）。

### 新增 — 浅蓝主题（参考 Gemini 官网浅色系）

- `web/login.css`：深色绿底 → 浅蓝白渐变 + 白卡 + 浅蓝主按钮（类名/构图不变）
- `web/login_bg.js`：绿色 3D 星空 → 近白中心 + 极浅蓝光斑；保留 `prefers-reduced-motion` 降级
- `web/style.css`：**文件末尾追加**主题层（不改既有选择器块内部规则）；
  前 2199 行 md5 改前改后一致
- 可读性：13 组前景/背景对全部 ≥4.5:1；修掉改前 5 处不达标
- 验收：UI 三档 `ui_issue_count=0`、`component_rc=0`；截图见 `docs/qa/主题浅蓝改造_20261118.md`

### 新增 — 21 张架构图全量更新（manifest v4.1）

- 实质内容更新 18 张：无审批直发、四角色边界（审核员不看本体/词典）、草稿箱独立、
  发布后冲突不阻断、知识库「其他」文件类型、模型/OCR 四态、7 智能体、CLI 平台入口、
  安全守卫、审计同事务
- 重新生成 21 张 PNG（10,051,185 B）+ 21 张模糊封面（189,521 B）
- 旧说法清零（`T-110 进行中` / `submit→approve→publish` / `draft→pending→approved` 等 0 命中）
- 验收：`architecture_assets_test` 25/0、`architecture_ui_test.mjs`（真实 Chrome 三档 21 卡）228/0

### 修复 — 审计同事务补全（feedback.settle）

- 新增 `_settle_write()`：反馈状态变更 + `audit.log_in_tx` 同一事务（`app/services/feedback.py`）
- 覆盖 frozen / ignore / new_rule 阻断 / 主成功路径 4 条写路径
- 顺带修掉 ignore 分支的旧半写（抑制行独立事务 + 失败吞异常）
- 新增 `scripts/qa/audit_tx_test.py` 28/28 PASS（含审计失败注入回滚）
- **仍多事务**（如实登记）：`rule.create_rule`、`rule_versions.insert`、`ruleparam.*`、
  `rsi_protocol.record_candidate`

### 新增 — 项目上下文体系（清理阶段 0+1）

- `platform/AGENTS.md`（153 行）：工程铁律 / 四角色 / 无审批生命周期 / 主链契约 / 审计要求 / 交付清单
- `PROJECT_MEMORY.md` 重写（178 行）：清掉「26 表 / 51 测试 / 待审批」等全部过期口径
- `docs/CURRENT/` 首批 4 份：`00-索引` / `06-测试与门禁` / `07-已知问题与NOT-DONE` / `08-路线图`
- `docs/qa/基线清单_20261118.txt`：966 文件逐文件 SHA256（`shasum -c` 全 OK）
- `README.md` 重写、`CHANGELOG.md` 新建
- **git 初始化**：首次提交 `b11b477`（1389 文件 / 37 MB），tag `v1.5.0-20261118-baseline`，
  分支 `main` + `dev`；`.gitignore` 排除 `data/ dist/ _archive/` 与截图/Office/视频/日志生成物

### 新增 — 宣传视频

- `docs/delivery/video-20261118/`：10 分镜 / 2 分 14 秒 / 1920×1080 / 30fps
- 脚本分镜、旁白 TTS、全套生成提示词、SRT + ASS 字幕、两版成片（无字幕 / 烧字幕）
- 配色沿用 Gemini 浅色系；含一帧真实产品界面（非示意图）
- 体积 59 MB → 16 MB（libx264 CRF 21，像素级对比无偏移）

### 修复 — 菜单基线同步

- T-109/T-105 新增「草稿箱」「知识库」菜单后，`global_ux_static_test.py` 硬编码数组过期
  → 同步三端菜单数组 + 规则空态文案，42/46 → **46/46 PASS**

### 修复 — server.py 快照

- `/favicon.ico` 204 处理 + 位置修正 → `SERVER_PY_SNAPSHOT` 更新为 5574 行 / `8d3586bd…`
  （每处变化均在快照里写明原因，未静默改上限）

### 测试基线（截至本条目）

```text
全量 gate            273 PASS / 0 FAIL / 3 SKIP（276）  ← 19:01 实测，打包前需重跑
test_suite           119/119
full_chain           38/38
sysadmin_pages       134/134
server_split         50 PASS / 0 FAIL
global_ux_static     46/46
workbench_review_ux  64/64
silent_failures      112 = 基线 112
absorb_p0            33/33
audit_tx             28/28
包 validate          68/68（zip cad2fc31…）
```

### 已知未修（下一版本）

```text
C-4  发布后冲突检测无「检测状态」       未开工，阻断「无冲突可证」
TL-5 OCR 无按页 engine/tier provenance  未开工，影响扫描件数值判定
PL-2 准确率门禁阈值小于噪声             未开工，影响「门禁可执行」声明
E-10 模型地址被拒时前端不提示            DuMate 第三轮发现（S2），待修
准确率 P01/CT/BX                         历史口径，当前源码 NOT TESTED
旧 pending/approved 规则                 未批量迁移
```

---

## [1.5.0] — 2026-11-17

首个「可交付」版本。主要能力：

### 新增
- 四端分离：审核员 / 业务管理员 / 系统管理员 / 平台运营（服务端 RBAC + 租户 + 空间 + 本人归属）
- 规则引擎：规则版本、决策表、审核库点位（302 点 / 103 文件类型 / 69 审核类型）
- 审核主链：manifest 冻结 + D1–D5 + 五态结论 + 证据锚点
- 人工复核：展示项 100% 复核、隐藏池（可逆视图过滤）、人工漏报登记、报告门禁
- 7 个智能体：parse / fact / rulegen / conflict / judge / fp / ruleminer
- 知识库、本体建模、企业词典
- 原生 CLI（与 HTTP 同服务层 / 同权限 / 同审计）
- 开放平台：应用与凭据、HMAC-SHA256、事件订阅、回调投递状态、沙箱验签
- 审计日志（只读、不可导出、支持筛选/统计/详情/分页）
- 模型与 OCR 四态（未配置 / 已配置待测 / 连接正常 / 连接失败）

### 变更
- 规则生命周期改为**无审批直发**（`draft → published`）；`pending/approved` 降为历史
- 报告导出：PDF 移除（环境依赖不可控），保留 HTML + DOCX
- 工作空间只影响规则引擎；首页与项目列表始终汇总
- 业务管理员只读项目详情，不能复核/编辑/生成/导出报告

### 修复
- 报告门禁 fail-closed（可见项未裁决不放行）
- 数据边界 `external_model=deny` 发送前拒绝（fail-closed）
- `super_admin` 业务只读白名单反向判定
- 初始密码不常驻页面；临时密码记录可查、7 天过期、首次登录强制改密

### 测试基线
```text
全量 gate 273/0/3 ｜ test_suite 119/119 ｜ full_chain 38/38 ｜ 包 validate 68/68
```

---

## [1.4.0] — 2026-11-14 ～ 11-16

（回溯摘要，详见 `docs/qa/*_2026111[4-6].md`）

- 双轨 / 四桶比对策略实验（后调整为当前单轨五态口径）
- JEV 校准路由与选择性预测（弃权机制）
- 规则进化闭环：反馈 → 候选 → 人工确认 → 草稿
- 术语边界、本体只读/编辑分离
- Docker 部署修复、可移植性探测（非 macOS 环境降级）

## [1.3.5] — 2026-11-13

（回溯摘要）

- 全站 UI 按最新角色矩阵统一（四角色，无只读角色）
- 系统管理员 IT 首页、账号目标租户、业务管理员空间成员
- 逐页 UI 结构与视觉修复

## [1.0.0] — 2026-11-09

首个内部可用版本：规则 + 审核 + 复核 + 报告的端到端闭环。

---

## 约定

- **每条变更必须能追溯到证据**：代码给文件:行；行为给测试命令与数字；不给"已优化"这种空话
- **不写未验证为已验证**：没跑过的写 `NOT TESTED`，跑不通的写 `FAIL`
- **破坏性变更**（schema / 权限 / 状态枚举 / 接口契约）必须单列一段并说明迁移方式
