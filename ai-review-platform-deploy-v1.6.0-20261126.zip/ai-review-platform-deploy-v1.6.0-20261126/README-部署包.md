# AI 审核平台 · 部署包 v1.6.0（2026-11-26）

## 最短部署（Docker）
```bash
tar -xzf AI审核平台_部署包_v1.6.0_20261126.tar.gz
cd AI审核平台_部署包_v1.6.0_20261126
cp deploy/.env.production.example .env.production
python3 - <<'PY'
import secrets,pathlib
p=pathlib.Path('.env.production');s=p.read_text()
s=s.replace('CHANGE_ME_SESSION_SECRET',secrets.token_urlsafe(32))
s=s.replace('CHANGE_ME_ADMIN_PASSWORD',secrets.token_urlsafe(14))
p.write_text(s)
PY
chmod 600 .env.production
docker compose -f deploy/docker-compose.yml up -d --build
curl -fsS http://127.0.0.1:8765/health
ADMIN_PASSWORD="$(grep '^RULEPROOF_ADMIN_PASSWORD=' .env.production | cut -d= -f2-)" \
  bash deploy/smoke-test.sh http://127.0.0.1:8765
```

## 必看
- 生产首次启动前：`.env.production` 中 `RULEPROOF_SEED_DEMO=0`（空生产库），否则会创建演示账号。
- 若已用 `1` 初始化过，演示账号不会自动删除；需清空 data/重建或手动停用。
- Nginx：使用 `deploy/nginx/ai-review.conf`；上传上限已 350m；TLS/域名/安全组只开 80/443/22。
- 模型/OCR：见 `模型接入说明.md`；无 Key 时确定性规则可用，语义/OCR 降级不伪造通过。
- PDF 预览依赖：Dockerfile 已安装 `pypdfium2` + `poppler-utils` + 中文字体；部署后必须上传 PDF 验证 `/pdf-meta` 与页图。
- 数据：Docker named volume `ai_review_data`；备份需覆盖 DB + uploads + knowledge；`restore.sh` 默认只恢复 DB，文件需另行恢复。
- 当前包 SHA/发布登记以 `docs/qa/artifacts/RELEASES.md` 与包外 `.sha256` 为准。
