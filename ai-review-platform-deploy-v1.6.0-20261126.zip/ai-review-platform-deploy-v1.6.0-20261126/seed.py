"""种子数据：初始化数据库并写入内置角色与内置规则。

安全边界：
- RULEPROOF_ENV=prod 且未显式提供 RULEPROOF_ADMIN_PASSWORD 时，生成随机初始密码；
- prod 默认不创建固定密码演示账号；
- start.sh 只在数据库不存在或显式 RULEPROOF_SEED=1 时调用 seed。
"""
import os
import secrets
import sys

# 2026-11-24 事故 C：禁止在“产品库已存在”时无显式允许地执行 seed.py。
# 背景：某 lane 在未显式设置 RULEPROOF_DB 的情况下执行 seed.py，向 data/ruleproof.db
# 写入 4 租户/12 用户/257 项目/1520 finding/4 审计；已从 /tmp 备份恢复。此守卫把
# “误 seed 产品库”变成启动期显式拒绝（初始建库仍允许；显式人工操作需 opt-in）。
_REPO = os.path.dirname(os.path.abspath(__file__))
_PRODUCT_DB = os.path.abspath(os.path.join(_REPO, "data", "ruleproof.db"))
_resolved = os.environ.get("RULEPROOF_DB") or _PRODUCT_DB
_resolved_abs = os.path.abspath(_resolved)
_in_package = any(("dist/" in _resolved_abs.replace("\\", "/")) or ("完整交付版" in _resolved_abs) for _ in [0])
_allow = str(os.environ.get("RULEPROOF_ALLOW_PRODUCT_DB_WRITE", "")).strip().lower() in ("1", "true", "yes", "on")
if (_resolved_abs == _PRODUCT_DB and not _in_package and not _allow
        and os.path.exists(_PRODUCT_DB) and os.path.getsize(_PRODUCT_DB) > 0):
    sys.stderr.write(
        "拒绝 seed 产品库：RULEPROOF_DB 指向 %s（已有数据）。\n"
        "如确需人工重建产品库，请显式 export RULEPROOF_ALLOW_PRODUCT_DB_WRITE=1。\n"
        "测试/演示/打包请设置 RULEPROOF_DB=/tmp/... 或使用包内演示库。\n" % _PRODUCT_DB)
    raise SystemExit(3)

sys.path.insert(0, ".")
from app import db  # noqa: E402
from app import repositories as R  # noqa: E402
from app.engine.rules_meta import BUILTIN_RULES  # noqa: E402

# L92（2026-11-24）：**唯一四角色**。修复 L88 G01（P0）：seed 曾声称 7 角色、权限
# 单一事实源只有 4 个，quality_director/rule_admin/regulatory_advisor 是悬空角色
# （0 权限/0 菜单/0 门户/0 用户）。现只保留 4 个真实角色；run() 启动时用
# app/services/permission_registry.ROLE_CODES 做一致性断言（禁止再手写第二份角色
# 名单），旧库的 3 个悬空角色由 _purge_legacy_roles 删除并报告。
ROLES = [
    ("super_admin", "系统管理员"), ("admin", "业务管理员"), ("reviewer", "审核员"),
    ("platform_op", "平台运营"),
]
# 历史遗留角色（L92 前 seed 写入、无权限/无菜单/无用户）；seed 负责清理：
LEGACY_DANGLING_ROLES = ("quality_director", "rule_admin", "regulatory_advisor")


def _assert_roles_consistent() -> tuple:
    """seed 角色清单必须与权限注册表 ROLE_CODES/ROLE_LABELS 完全一致。

    L92 P0 根因就是「seed 自写一份角色名单、注册表另写一份」；这里把双事实源
    变成启动期硬失败（prod 直接中止，dev/演示同样拒绝继续，避免再落悬空角色）。
    """
    from app.services import permission_registry as _perm_reg
    seed_codes = tuple(code for code, _name in ROLES)
    if seed_codes != tuple(_perm_reg.ROLE_CODES):
        raise SystemExit(
            "seed 角色清单与权限注册表不一致：seed=%s registry=%s"
            % (seed_codes, tuple(_perm_reg.ROLE_CODES)))
    for code, name in ROLES:
        if _perm_reg.ROLE_LABELS.get(code) != name:
            raise SystemExit("seed 角色展示名与注册表不一致：%s=%r vs %r"
                             % (code, name, _perm_reg.ROLE_LABELS.get(code)))
    return seed_codes


def _purge_legacy_roles(c) -> dict:
    """幂等清理旧库的 3 个悬空角色（先解绑 user_role/role_permission，再删 role 行）。

    只删已知遗留 code，不动任何自定义/未来角色；返回 {removed, unbound_users} 供
    seed 输出与 QA 校验（L92 角色统一）。
    """
    removed, unbound = 0, 0
    wanted = {str(code) for code, _name in ROLES}
    for code in LEGACY_DANGLING_ROLES:
        if code in wanted:
            continue
        row = c.execute("SELECT id FROM role WHERE code=?", (code,)).fetchone()
        if not row:
            continue
        rid = row[0]
        unbound += int(c.execute("DELETE FROM user_role WHERE role_id=?", (rid,)).rowcount or 0)
        c.execute("DELETE FROM role_permission WHERE role_id=?", (rid,))
        c.execute("DELETE FROM role WHERE id=?", (rid,))
        removed += 1
    return {"removed": removed, "unbound_users": unbound}


def _seed_live_keys_allowed() -> bool:
    """演示种子是否允许把环境变量里的真实凭据写入演示库（T-99）。

    安全边界：
    - 只在显式 ``RULEPROOF_SEED_DEMO=1`` 且非生产时有意义（调用方判定）；
    - ``RULEPROOF_SEED_LIVE_KEYS=0`` 可显式关闭；
    - 交付打包脚本会在 ``platform/dist/...`` 包目录内执行 seed.py：该路径下即使带
      demo 标志也一律拒绝写入明文凭据，防止真实密钥进入交付包；
    - 生产（RULEPROOF_ENV=prod）永不写明文，由运行时环境变量注入。
    """
    flag = str(os.environ.get("RULEPROOF_SEED_LIVE_KEYS", "")).strip().lower()
    if flag in ("0", "false", "no"):
        return False
    try:
        here = os.path.dirname(os.path.abspath(__file__)).replace("\\", "/")
        parts = [p for p in here.split("/") if p]
        if "dist" in parts or any("完整交付版" in p for p in parts):
            return False
    except Exception:
        return False
    return True



def _seed_food_history():
    """预置 3 个食品历史项目：真实 12-14 页 PDF + 每个 12 条带页码证据的发现。"""
    import json, os, hashlib
    base = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base, "seed", "food_history.json")
    if not os.path.exists(data_path):
        return 0
    try:
        data = json.load(open(data_path, encoding="utf-8"))
    except Exception:
        return 0
    made = 0
    with db.session() as c:
        ws = c.execute("SELECT id FROM workspace WHERE tenant_id='t-default' AND status='active' ORDER BY created_at, rowid LIMIT 1").fetchone()
        wsid = ws[0] if ws else ""
        if not wsid:
            return 0
        for i, item in enumerate(data, 1):
            name = item.get("name") or ""
            if not name or c.execute("SELECT 1 FROM audit_case WHERE name=?", (name,)).fetchone():
                continue
            fpath = os.path.join(base, "seed", "food_history", item.get("file") or "")
            if not os.path.exists(fpath):
                continue
            cid = f"case-hist-{i}"; did = f"doc-hist-{i}"; rid = f"run-hist-{i}"
            fs = item.get("findings") or []
            crit = sum(1 for f in fs if f.get("severity") == "critical")
            warn = len(fs) - crit
            now = item.get("created_at") or db.now()
            c.execute("INSERT INTO audit_case(id,name,status,progress,created_at,created_by,audit_type,last_audit_at,tenant_id,workspace_id) "
                      "VALUES(?,?,'completed',100,?,?,?,?,?,?)",
                      (cid, name, now, "user-reviewer", "food", now, "t-default", wsid))
            c.execute("INSERT INTO document(id,filename,doc_type,hash,status,created_at,path,parse_status,parse_summary,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                      (did, item.get("file") or "", "food", hashlib.sha256(open(fpath, "rb").read()).hexdigest(),
                       "parsed", now, fpath, "ok", "历史食品工艺记录", "t-default", wsid))
            c.execute("INSERT INTO case_document(case_id,document_id) VALUES(?,?)", (cid, did))
            c.execute("INSERT INTO audit_run(id,case_id,created_at,created_by,audit_type,total,critical,warning,suspected) VALUES(?,?,?,?,?,?,?,?,?)",
                      (rid, cid, now, "user-reviewer", "food", len(fs), crit, warn, 0))
            c.execute("UPDATE audit_case SET last_run_id=? WHERE id=?", (rid, cid))
            for j, f in enumerate(fs, 1):
                fid = f"fnd-hist-{i}-{j:02d}"; aid = f"anc-hist-{i}-{j:02d}"; eid = f"ev-hist-{i}-{j:02d}"
                c.execute("INSERT INTO finding(id,case_id,rule_id,rule_version,severity,certainty,confidence,status,title,summary,suggestion,grade,engine,run_id,point_id,source_code,tenant_id,workspace_id,state) "
                          "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (fid, cid, f"HIST-FOOD-{j:02d}", "v1", f.get("severity") or "warning", "deterministic", 1.0, "pending",
                           f.get("title") or "", f.get("summary") or "", f.get("suggestion") or "", "R1",
                           "manual_history", rid, "", "", "t-default", wsid, "不满足"))
                c.execute("INSERT INTO anchor(id,document_id,sheet,row,col,locator,quote,hash) VALUES(?,?,?,?,?,?,?,?)",
                          (aid, did, f.get("page") or "", None, "", f.get("page") or "", f.get("quote") or "",
                           hashlib.sha256((f.get("quote") or "").encode()).hexdigest()))
                c.execute("INSERT INTO evidence(id,finding_id,document_id,anchor_id,excerpt,label) VALUES(?,?,?,?,?,?)",
                          (eid, fid, did, aid, f.get("quote") or "", "历史项目样例"))
            made += 1
    return made


def _seed_business_demo():
    """预置 8 个跨类型业务项目：合同、施工、招标、评标、保密协议、许可申报、检验报告等。"""
    import json, os, hashlib
    base = os.path.dirname(os.path.abspath(__file__))
    manifest = os.path.join(base, "seed", "demo_projects.json")
    if not os.path.exists(manifest):
        return 0
    try:
        items = json.load(open(manifest, encoding="utf-8"))
    except Exception:
        return 0
    made = 0
    with db.session() as c:
        ws = c.execute("SELECT id FROM workspace WHERE tenant_id='t-default' AND status='active' ORDER BY created_at, rowid LIMIT 1").fetchone()
        wsid = ws[0] if ws else ""
        if not wsid:
            return 0
        for i, item in enumerate(items, 1):
            name = item.get("name") or ""
            if not name or c.execute("SELECT 1 FROM audit_case WHERE name=?", (name,)).fetchone():
                continue
            fpath = os.path.join(base, "seed", "demo_docs", item.get("filename") or "")
            if not os.path.exists(fpath):
                continue
            cid = f"case-biz-{i:02d}"; did = f"doc-biz-{i:02d}"; rid = f"run-biz-{i:02d}"
            fs = item.get("findings") or []
            crit = sum(1 for f in fs if f.get("severity") == "critical")
            warn = len(fs) - crit
            created = item.get("created_at") or db.now()
            c.execute("INSERT INTO audit_case(id,name,status,progress,created_at,created_by,audit_type,document_type,last_audit_at,last_run_id,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (cid, name, item.get("status") or "completed", 100 if item.get("status") == "completed" else 30,
                       created, "user-reviewer", item.get("audit_type") or "general", item.get("document_type") or "",
                       created, rid, "t-default", wsid))
            c.execute("INSERT INTO document(id,filename,doc_type,hash,status,created_at,path,parse_status,parse_summary,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                      (did, item.get("filename") or "", item.get("document_type") or "文档",
                       hashlib.sha256(open(fpath, "rb").read()).hexdigest(), "parsed", created,
                       fpath, "ok", f"识别 {max(10, len(fs) * 2)} 段、{len(fs)} 条关注参数", "t-default", wsid))
            c.execute("INSERT INTO case_document(case_id,document_id) VALUES(?,?)", (cid, did))
            c.execute("INSERT INTO audit_run(id,case_id,created_at,created_by,audit_type,total,critical,warning,suspected) VALUES(?,?,?,?,?,?,?,?,?)",
                      (rid, cid, created, "user-reviewer", item.get("audit_type") or "general", len(fs), crit, warn, 0))
            for j, f in enumerate(fs, 1):
                fid = f"fnd-biz-{i:02d}-{j:02d}"; aid = f"anc-biz-{i:02d}-{j:02d}"; eid = f"ev-biz-{i:02d}-{j:02d}"
                c.execute("INSERT INTO finding(id,case_id,rule_id,rule_version,severity,certainty,confidence,status,title,summary,suggestion,grade,engine,run_id,point_id,source_code,tenant_id,workspace_id,state) "
                          "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (fid, cid, f"DEMO-{i:02d}-{j:02d}", "v1", f.get("severity") or "warning",
                           "deterministic", 0.9, f.get("status") or "pending", f.get("title") or "",
                           f.get("summary") or "", f.get("suggestion") or "",
                           "R1" if f.get("severity") == "critical" else "R2", "demo_project_doc",
                           rid, "", "", "t-default", wsid, "不满足"))
                c.execute("INSERT INTO anchor(id,document_id,sheet,row,col,locator,quote,hash) VALUES(?,?,?,?,?,?,?,?)",
                          (aid, did, "", None, "", f"第 {min(14, j + 1)} 页", f.get("quote") or "",
                           hashlib.sha256((f.get("quote") or "").encode()).hexdigest()))
                c.execute("INSERT INTO evidence(id,finding_id,document_id,anchor_id,excerpt,label) VALUES(?,?,?,?,?,?)",
                          (eid, fid, did, aid, f.get("quote") or "", "业务样例证据"))
                if j <= 3:
                    _kind = "false_positive" if j == 3 else ("manual" if j == 1 else "confirm")
                    _status = "pending" if j == 1 else ("settled" if j == 2 else "ignored")
                    c.execute("INSERT OR IGNORE INTO feedback(id,case_id,finding_id,kind,rule_code,title,payload,actor,created_at,rsi_status,rsi_action,rsi_rule_id,handled_at,handled_by,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              (f"fb-biz-{i:02d}-{j:02d}", cid, fid, _kind,
                               f"DEMO-{i:02d}-{j:02d}", f.get("title") or "",
                               __import__("json").dumps({"reason": "样例复核反馈：该判定需要结合原始记录复核。", "suggestion": "建议调整阈值或补充证据要求。"}, ensure_ascii=False),
                               "user-reviewer", created, _status, "revise" if _status == "settled" else "",
                               "r-demo" if _status == "settled" else "", created if _status != "pending" else "",
                               "user-reviewer" if _status != "pending" else "", "t-default", wsid))
            made += 1
        # 冲突样例：供当前空间测试冲突详情 / 裁决 / 忽略
        _conf = [
            ("FOOD01-001", "FOOD01-001", "duplicate", "「炒制/烹制中心温度达标」重复映射：两条规则同指标、同上下限，命中会重复。", "warning", "两条规则等价，建议合并或停用其一", '{"metric":"中心温度","op":">=","value":85,"unit":"℃"}', '{"metric":"中心温度","op":">=","value":85,"unit":"℃"}', "open"),
            ("C05-005", "C09-003", "numeric_conflict", "校准有效期同一对象出现“已过期”和“覆盖生产日期”两种相反结论。", "critical", "确认校准有效期和判定口径，保留一条规则", '{"metric":"校准有效期","op":"<","value":"2026-06-30"}', '{"metric":"校准有效期","op":">=","value":"2026-08-12"}', "open"),
            ("B02-001", "A04-001", "scope_conflict", "附件齐全与签署完整性都覆盖出厂检验报告，但责任字段和证据位置不同。", "warning", "明确两条规则的证据范围，避免重复提示", '{"scope":"附件清单"}', '{"scope":"签署页"}', "resolved"),
            ("F04-001", "F05-001", "unit_mismatch", "付款节点规则一条按“工作日”、一条按“自然日”，同一条款可能同时命中。", "warning", "统一工作日/自然日口径", '{"unit":"工作日","metric":"付款期限"}', '{"unit":"自然日","metric":"付款期限"}', "open"),
            ("A01-001", "A02-001", "priority_conflict", "主体名称一致性规则与经营范围规则对同一主体信息的优先级未定义。", "warning", "明确主体名称优先，经营范围作为补充校验", '{"scope":"主体信息","priority":"高"}', '{"scope":"经营范围","priority":"中"}', "ignored"),
        ]
        for k, (a, b, typ, detail, sev, sug, sa, sb, status) in enumerate(_conf, 1):
            c.execute("INSERT OR IGNORE INTO conflict(id,rule_a,rule_b,type,detail,status,created_at,severity,suggestion,slots_a,slots_b,resolved_at,resolved_by,note,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (f"cf-biz-{k:02d}", a, b, typ, detail, status, db.now(), sev, sug, sa, sb,
                       db.now() if status != "open" else "", "业务管理员" if status != "open" else "",
                       "样例冲突处理记录" if status != "open" else "", "t-default", wsid))
    return made



def _seed_complex_cases():
    """内置多文件复杂案例：Word+Excel+PDF，Excel 多 Sheet，几十条不同等级发现。

    仅用于演示，不写入真实准确率；文件与 finding/evidence 均由本函数生成。
    """
    import os, hashlib, shutil
    base = os.path.dirname(os.path.abspath(__file__))
    outdir = os.path.join(base, "seed", "complex_docs")
    os.makedirs(outdir, exist_ok=True)
    try:
        from docx import Document
        from openpyxl import Workbook
    except Exception:
        return 0

    def w(name, title, sections):
        path = os.path.join(outdir, name)
        if os.path.exists(path):
            return path
        d = Document()
        d.add_heading(title, 0)
        d.add_paragraph("演示文件：仅用于内置多文件复杂案例；内容为合成业务样例，不是真实客户材料。")
        for h, lines in sections:
            d.add_heading(h, level=1)
            for x in lines:
                d.add_paragraph(x)
            if h in ("设备清单", "报价与评分", "工艺参数", "检验记录"):
                t = d.add_table(rows=1, cols=3)
                t.style = "Table Grid"
                for i, v in enumerate(("项目", "要求/数值", "核对说明")):
                    t.rows[0].cells[i].text = v
                for i in range(1, 6):
                    row = t.add_row().cells
                    row[0].text = f"{h}-{i:02d}"
                    row[1].text = f"示例值 {i} / 85"
                    row[2].text = "需与报价表、检验报告交叉核对"
        d.save(path)
        return path

    def x(name, sheets):
        path = os.path.join(outdir, name)
        if os.path.exists(path):
            return path
        wb = Workbook()
        first = True
        for sheet, rows in sheets:
            ws = wb.active if first else wb.create_sheet()
            first = False
            ws.title = sheet
            for row in rows:
                ws.append(row)
            ws.freeze_panes = "A2"
            for col, width in (("A", 26), ("B", 20), ("C", 18), ("D", 18)):
                ws.column_dimensions[col].width = width
        wb.save(path)
        return path

    def copy_pdf(name, source):
        path = os.path.join(outdir, name)
        if not os.path.exists(path):
            src = os.path.join(base, "seed", "food_history", source)
            if os.path.exists(src):
                shutil.copyfile(src, path)
        return path if os.path.exists(path) else ""

    doc_a = w("复杂演示-智慧园区设备采购合同.docx", "智慧园区设备采购合同（演示）", [
        ("合同主体", ["甲方：星海科技（演示）", "乙方：华东设备（演示）", "合同编号：HT-2026-1107"]),
        ("采购范围", ["采购 128 台边缘网关、24 台核心交换机、36 台 PoE 接入交换机。", "交付地点：星海科技一号园区。", "交付期：合同生效后 30 个日历日。"]),
        ("付款与验收", ["预付款 30%，到货验收后支付 60%，质保金 10%。", "验收标准：设备清单、报价表、到货验收报告三者一致。", "延期交付按合同总额每日 0.5% 计违约金。"]),
    ])
    xls_a = x("复杂演示-设备清单与报价.xlsx", [
        ("设备清单", [["序号", "设备名称", "数量", "单位"], ["1", "边缘网关", 128, "台"], ["2", "核心交换机", 24, "台"], ["3", "PoE 交换机", 36, "台"], ["4", "光模块", 192, "个"], ["5", "机柜", 8, "台"]]),
        ("报价汇总", [["项目", "单价", "数量", "小计"], ["边缘网关", 6800, 128, 870400], ["核心交换机", 42000, 24, 1008000], ["PoE 交换机", 9800, 36, 352800], ["光模块", 850, 192, 163200], ["合计", "", "", 2394400]]),
        ("评分表", [["评分项", "分值", "得分", "备注"], ["价格", 40, 32, "高于基准价"], ["技术", 40, 35, "部分参数需复核"], ["服务", 20, 17, "响应时间 4h"]]),
        ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "数量不一致", "严重", "清单 128 台，报价 120 台"], ["2", "单位混用", "一般", "个/套混用"], ["3", "日期缺失", "一般", "验收日期空白"]]),
    ])
    pdf_a = copy_pdf("复杂演示-到货验收报告.pdf", "华东食品-酱卤牛肉-工艺记录-2026-08.pdf")
    doc_b = w("复杂演示-网络设备招标文件.docx", "网络设备采购招标文件（演示）", [
        ("招标公告", ["项目编号：ZB-2026-1108", "投标截止时间：2026-11-20 09:30", "开标地点：市公共资源交易中心。"]),
        ("资格要求", ["投标人须具备信息系统集成及服务资质。", "近三年至少 2 个同类项目业绩。", "项目负责人须具备高级项目经理资格。"]),
        ("评审办法", ["综合评分法；价格 40 分、技术 45 分、服务 15 分。", "技术参数负偏离超过 3 项按无效投标处理。"]),
    ])
    doc_b2 = w("复杂演示-网络设备招标文件-附件.docx", "招标文件附件：技术需求与合同条款（演示）", [
        ("技术需求", ["核心交换机交换容量≥ 25.6Tbps。", "PoE 交换机单端口供电≥ 30W。", "所有设备原厂质保≥ 3 年。"]),
        ("合同条款", ["交货期：合同签订后 20 个工作日。", "付款：验收后 15 个工作日内支付 95%。", "逾期交付按每日 0.3% 计违约金。"]),
    ])
    xls_b = x("复杂演示-投标报价与评分.xlsx", [
        ("投标报价", [["投标人", "报价", "工期", "质保"], ["甲公司", 2380000, "20 天", "3 年"], ["乙公司", 2260000, "25 天", "3 年"], ["丙公司", 2190000, "30 天", "2 年"]]),
        ("技术评分", [["投标人", "技术得分", "负偏离项", "说明"], ["甲公司", 41, 1, "1 项参数负偏离"], ["乙公司", 38, 4, "超过 3 项，应按无效处理"], ["丙公司", 35, 2, "需复核"]]),
        ("价格评分", [["投标人", "评标价", "价格分"], ["甲公司", 2380000, 36], ["乙公司", 2260000, 38], ["丙公司", 2190000, 40]]),
        ("资格核对", [["投标人", "资质", "业绩", "项目经理"], ["甲公司", "符合", "2 个", "高级"], ["乙公司", "符合", "1 个", "高级"], ["丙公司", "符合", "2 个", "中级"]]),
        ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "负偏离超限", "严重", "乙公司 4 项"], ["2", "业绩不足", "一般", "乙公司 1 个"], ["3", "项目经理资格", "严重", "丙公司中级"]]),
    ])
    pdf_b = copy_pdf("复杂演示-招标公告.pdf", "华东食品-每日坚果-工艺记录-2026-07.pdf")
    doc_c = w("复杂演示-酱卤牛肉工艺规程.docx", "酱卤牛肉工艺规程（演示）", [
        ("产品信息", ["产品名称：酱卤牛肉", "执行标准：GB 2726（演示）", "批次：2026-10-18-A"]),
        ("关键工序", ["解冻：0–8℃，解冻 12 小时。", "卤制：中心温度≥ 85℃，保温≥ 10 分钟。", "冷却：2 小时内冷却至 10℃ 以下。", "包装：净含量 250g，允许偏差 ±3g。"]),
        ("检验要求", ["每批检测菌落总数、大肠菌群、亚硝酸盐。", "检验记录须有检验员签字和日期。"]),
    ])
    xls_c = x("复杂演示-工艺参数与检验记录.xlsx", [
        ("工艺参数", [["工序", "参数", "实测", "单位"], ["解冻", "温度", 5, "℃"], ["卤制", "中心温度", 82, "℃"], ["卤制", "保温时间", 12, "分钟"], ["冷却", "冷却时间", 150, "分钟"], ["包装", "净含量", 247, "g"]]),
        ("配料表", [["原料", "投料量", "单位", "批次"], ["牛肉", 100, "kg", "B-01"], ["酱油", 6, "kg", "B-01"], ["食盐", 2.2, "kg", "B-01"]]),
        ("检验记录", [["项目", "结果", "单位", "判定"], ["菌落总数", 12000, "CFU/g", "符合"], ["大肠菌群", 30, "MPN/100g", "符合"], ["亚硝酸盐", 18, "mg/kg", "符合"], ["中心温度", 82, "℃", "不符合"]]),
        ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "中心温度不足", "严重", "82℃ 低于 85℃"], ["2", "检验签字缺失", "一般", "检验员签字空白"], ["3", "净含量偏差", "提示", "247g 接近下限"]]),
    ])
    pdf_c = copy_pdf("复杂演示-成品检验报告.pdf", "华东食品-速冻水饺-工艺记录-2026-06.pdf")
    docs = {
        "a": [("复杂演示-智慧园区设备采购合同.docx", "采购合同", doc_a), ("复杂演示-设备清单与报价.xlsx", "设备清单与报价", xls_a), ("复杂演示-到货验收报告.pdf", "到货验收报告", pdf_a)],
        "b": [("复杂演示-网络设备招标文件.docx", "招标文件", doc_b), ("复杂演示-网络设备招标文件-附件.docx", "招标附件", doc_b2), ("复杂演示-投标报价与评分.xlsx", "投标报价与评分", xls_b), ("复杂演示-招标公告.pdf", "招标公告", pdf_b)],
        "c": [("复杂演示-酱卤牛肉工艺规程.docx", "工艺规程", doc_c), ("复杂演示-工艺参数与检验记录.xlsx", "工艺参数与检验记录", xls_c), ("复杂演示-成品检验报告.pdf", "成品检验报告", pdf_c)],
    }
    cases = [
        ("case-complex-a", "复杂演示｜智慧园区设备采购（3 文件）", "a", 36, "reviewing", 62, "设备采购合同"),
        ("case-complex-b", "复杂演示｜网络设备招标评审（4 文件）", "b", 42, "completed", 100, "招标采购文件"),
        ("case-complex-c", "复杂演示｜酱卤牛肉工艺与检验（3 文件）", "c", 39, "reviewing", 55, "食品工艺书"),
    ]
    levels = ["critical", "warning", "suspected"]
    titles = {
        "a": ["设备数量与报价表不一致", "到货验收日期早于合同生效", "预付款比例超出约定", "验收报告缺少签字", "核心交换机参数负偏离", "质保期限不足", "光模块数量不匹配", "付款节点与验收脱节", "违约金比例缺失", "设备清单单位混用"],
        "b": ["技术负偏离超过限制", "投标人业绩数量不足", "项目经理资格不符", "报价与清单合计不一致", "资格条件与评审办法冲突", "投标截止时间与公告不一致", "价格分计算错误", "质保期不满足要求", "投标文件缺少附件", "评分表分值合计异常"],
        "c": ["卤制中心温度不足", "保温时间不足", "冷却时间超出限制", "净含量偏差超限", "检验记录缺少签字", "配料表投料量不一致", "批次号前后不一致", "菌落总数接近限值", "亚硝酸盐结果异常", "工艺参数单位混用"],
    }
    made = 0
    with db.session() as c:
        ws = c.execute("SELECT id FROM workspace WHERE tenant_id='t-default' AND status='active' ORDER BY created_at, rowid LIMIT 1").fetchone()
        wsid = ws[0] if ws else ""
        if not wsid:
            return 0
        for cid, cname, key, count, status, progress, dtype in cases:
            if c.execute("SELECT 1 FROM audit_case WHERE id=?", (cid,)).fetchone():
                continue
            now = "2026-11-12 10:00:00"
            c.execute("INSERT INTO audit_case(id,name,status,progress,created_at,created_by,audit_type,document_type,last_audit_at,last_run_id,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (cid, cname, status, progress, now, "user-reviewer", "general", dtype, now, "run-" + cid, "t-default", wsid))
            for idx, (fn, dt, path) in enumerate(docs[key], 1):
                if not path:
                    continue
                did = f"doc-{cid}-{idx}"
                data = open(path, "rb").read()
                c.execute("INSERT INTO document(id,filename,doc_type,hash,status,created_at,path,parse_status,parse_summary,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                          (did, fn, dt, hashlib.sha256(data).hexdigest(), "parsed", now, path, "ok",
                           f"{fn} · 已解析；多文件案例（{len(docs[key])} 份）", "t-default", wsid))
                c.execute("INSERT INTO case_document(case_id,document_id) VALUES(?,?)", (cid, did))
            crit = sum(1 for i in range(count) if levels[i % 3] == "critical")
            warn = sum(1 for i in range(count) if levels[i % 3] == "warning")
            sus = count - crit - warn
            c.execute("INSERT INTO audit_run(id,case_id,created_at,created_by,audit_type,total,critical,warning,suspected) VALUES(?,?,?,?,?,?,?,?,?)",
                      ("run-" + cid, cid, now, "user-reviewer", "general", count, crit, warn, sus))
            for j in range(1, count + 1):
                fn, dt, path = docs[key][(j - 1) % len(docs[key])]
                did = f"doc-{cid}-{((j - 1) % len(docs[key])) + 1}"
                title = titles[key][(j - 1) % len(titles[key])] + f"（样例 {j:02d}）"
                sev = levels[(j - 1) % 3]
                if sev == "critical": sev = "critical"
                elif sev == "warning": sev = "warning"
                else: sev = "suspected"
                sheet = ""
                locator = f"第 {1 + (j % 8)} 页"
                if fn.endswith(".xlsx"):
                    sheet = ["设备清单", "报价汇总", "评分表", "异常记录", "工艺参数", "检验记录"][j % 6]
                    locator = f"{sheet}!A{1 + (j % 28)}"
                quote = f"{key.upper()} 样例原文：{title}；需要在 {fn} 中核对数量、单位、日期和签字。"
                fid = f"fnd-{cid}-{j:02d}"; aid = f"anc-{cid}-{j:02d}"; eid = f"ev-{cid}-{j:02d}"
                c.execute("INSERT INTO finding(id,case_id,rule_id,rule_version,severity,certainty,confidence,status,title,summary,suggestion,grade,engine,run_id,point_id,source_code,tenant_id,workspace_id,state) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (fid, cid, f"COMPLEX-{j:03d}", "v1", sev, "semantic", 0.82 if sev != "critical" else 0.9,
                           "pending" if j % 7 else "confirmed", title,
                           f"多文件交叉核对发现：{title}。涉及 {fn}，需回看原文/表格。",
                           "补证、统一数量/单位/日期口径，并由审核员复核。",
                           "R1" if sev == "critical" else ("R2" if sev == "warning" else "R3"),
                           "demo_complex", "run-" + cid, f"COMPLEX-{j:03d}", "DEMO", "t-default", wsid, "不满足"))
                c.execute("INSERT INTO anchor(id,document_id,sheet,row,col,locator,quote,hash) VALUES(?,?,?,?,?,?,?,?)",
                          (aid, did, sheet, (1 + (j % 28)) if sheet else None, "", locator, quote, hashlib.sha256(quote.encode()).hexdigest()))
                c.execute("INSERT INTO evidence(id,finding_id,document_id,anchor_id,excerpt,label) VALUES(?,?,?,?,?,?)",
                          (eid, fid, did, aid, quote, "多文件复杂案例证据"))
            made += 1
    return made


# ============================================================================
# 演示数据扩展（2026-11-21，用户三次明确要求「多放演示数据」）
#
# 用户原话要点：
# 1 内置演示数据多放几条复杂测试用例：一个项目 3-4 份文件、一份 Word 一份 Excel
#   一份 PDF、同时打开、Excel 里有多个系统；每份几十个问题；不同难度等级、多来几份。
# 2 四个角色账号都多放演示数据，尽可能多。
# 3 新增实例/新增别名的类型选项、本体建模、规则进化、冲突提醒都要造大量演示数据。
#
# 约束：全部幂等（先查后插 / INSERT OR IGNORE）；文件用 python-docx / openpyxl
# 真实生成，PDF 因无 reportlab 用现有样本复制改名；只写 RULEPROOF_DB 指向的库。
#
# 2026-11-21（build22 门禁 4 条 FAIL 修正）：本轮新增演示数据统一迁入**演示专用空间
# ws-demo**，不再写默认空间 ws-default。原因：ws-default 是四个回归门禁（本体开关缺省、
# 本体发布指针、规则挖掘候选、产品库基线）的「干净基线」，演示数据写进去会破坏假设。
# ws-default 仅保留 f346c40 之前就存在的内置演示（历史食品/业务/复杂案例）。
# ============================================================================

_DEMO_GEN_SUBDIR = "demo_generated"
_DEMO_LEVELS = ("critical", "warning", "suspected")
# 演示专用空间：本轮新增演示数据（多文件案例/批量项目/本体演示/RSI/冲突）的唯一落点。
_DEMO_WS_ID = "ws-demo"
_DEMO_WS_NAME = "食品工艺书"


def _ensure_demo_workspace():
    """创建/确保演示专用空间 ws-demo 存在（幂等）。返回是否新建。

    ws-default 是默认空间与门禁基线；本函数只新增空间，不改动 ws-default 的任何设置。
    created_at 用当前时间：ws-default 由 db.init_db 先创建，故 ws-default 的 created_at
    永远 ≤ 本空间；基线种子函数用 `ORDER BY created_at, rowid` 取默认空间，仍解析到
    ws-default，不受本空间影响。
    """
    with db.session() as c:
        # 固定默认空间命名：ws-default=通用工作空间；ws-demo=食品工艺书。
        c.execute("UPDATE workspace SET name='通用工作空间' WHERE id='ws-default'")
        row = c.execute("SELECT id FROM workspace WHERE id=?", (_DEMO_WS_ID,)).fetchone()
        if row:
            c.execute("UPDATE workspace SET name=? WHERE id=?", (_DEMO_WS_NAME, _DEMO_WS_ID))
            return 0
        try:
            c.execute(
                "INSERT INTO workspace(id,tenant_id,name,status,created_by,created_at,settings_json) "
                "VALUES(?,?,?,'active','seed',?,'{}')",
                (_DEMO_WS_ID, "t-default", _DEMO_WS_NAME, db.now()))
        except Exception:
            # 唯一键 (tenant_id,name) 冲突（别的 id 已占用同名空间）：按名字兜底查找
            row = c.execute("SELECT id FROM workspace WHERE tenant_id='t-default' AND name=?",
                            (_DEMO_WS_NAME,)).fetchone()
            if not row:
                raise
            return 0
        return 1


def _demo_write_docx(path, title, blocks):
    """真实生成 Word：标题 + 一级小节 + 段落 + 表格（python-docx）。已存在则跳过。"""
    import os as _os
    if _os.path.exists(path) and _os.path.getsize(path) > 2000:
        return path
    from docx import Document
    d = Document()
    d.add_heading(title, 0)
    d.add_paragraph("演示文件：内容为合成业务样例，用于内置演示数据，不是真实客户材料。")
    for b in blocks:
        kind = b[0] if b else ""
        if kind == "h":
            d.add_heading(b[1], level=1)
        elif kind == "p":
            for line in (b[1] if isinstance(b[1], (list, tuple)) else [b[1]]):
                d.add_paragraph(str(line))
        elif kind == "t":
            # 兼容两种写法：("t", (header, rows)) 与 ("t", header, rows)
            if len(b) >= 3:
                header, rows = b[1], b[2]
            else:
                header, rows = b[1]
            t = d.add_table(rows=1, cols=len(header))
            t.style = "Table Grid"
            for i, v in enumerate(header):
                t.rows[0].cells[i].text = str(v)
            for row in rows:
                cells = t.add_row().cells
                for i, v in enumerate(row):
                    cells[i].text = str(v)
    d.save(path)
    return path


def _demo_write_xlsx(path, sheets):
    """真实生成 Excel：多 Sheet + 表头冻结 + 列宽（openpyxl）。已存在则跳过。"""
    import os as _os
    if _os.path.exists(path) and _os.path.getsize(path) > 1500:
        return path
    from openpyxl import Workbook
    wb = Workbook()
    first = True
    for sheet, rows in sheets:
        ws = wb.active if first else wb.create_sheet()
        first = False
        ws.title = sheet
        for row in rows:
            ws.append(list(row))
        ws.freeze_panes = "A2"
        for col, width in (("A", 24), ("B", 22), ("C", 20), ("D", 20), ("E", 18), ("F", 18)):
            ws.column_dimensions[col].width = width
    wb.save(path)
    return path


def _demo_copy_pdf(base, path, source_name):
    """无 reportlab：用仓库内已有 PDF 样本复制改名（任务书允许）。"""
    import os as _os
    import shutil
    if _os.path.exists(path) and _os.path.getsize(path) > 1000:
        return path
    for src in (os_path_join(base, "seed", "food_history", source_name),
                os_path_join(base, "seed", "complex_docs", "复杂演示-到货验收报告.pdf")):
        if _os.path.exists(src):
            try:
                shutil.copyfile(src, path)
                return path
            except Exception:
                continue
    return ""


def os_path_join(*parts):
    import os as _os
    return _os.path.join(*parts)


def _demo_safe_name(name):
    return (name or "").replace("/", "-").replace("\\", "-").replace("｜", "-")


def _demo_insert_case(c, *, cid, name, status, progress, created, by, audit_type,
                      document_type, wsid, tenant, files, findings, focus="",
                      audit_category="演示数据", last_audit_at=None, run_engine="demo_complex"):
    """插入 1 个项目 + N 份文档 + M 条发现（含 anchor/evidence/audit_run），幂等。

    files: [{"filename","doc_type","path","summary","sheets"}]（sheets 仅 xlsx 用）
    findings: [{"title","severity","suggestion","summary","file","sheet","locator",
                "status","state","grade","certainty","confidence","rule_code"}]
    """
    import hashlib
    import os as _os
    if c.execute("SELECT 1 FROM audit_case WHERE id=?", (cid,)).fetchone():
        return 0
    created = created or db.now()
    last_audit_at = last_audit_at or created
    rid = "run-" + cid
    c.execute(
        "INSERT INTO audit_case(id,name,status,progress,created_at,created_by,audit_type,"
        "document_type,focus,audit_category,last_audit_at,last_run_id,tenant_id,workspace_id) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (cid, name, status, progress, created, by, audit_type, document_type,
         focus, audit_category, last_audit_at, rid, tenant, wsid))
    for idx, f in enumerate(files, 1):
        path = f.get("path") or ""
        try:
            h = hashlib.sha256(open(path, "rb").read()).hexdigest() if path and _os.path.exists(path) else ""
        except Exception:
            h = ""
        did = f"doc-{cid}-{idx}"
        c.execute(
            "INSERT INTO document(id,filename,doc_type,hash,status,created_at,path,parse_status,"
            "parse_summary,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (did, f.get("filename") or "", f.get("doc_type") or "文档", h, "parsed", created,
             path, "ok", f.get("summary") or f"{f.get('filename') or ''} · 已解析（演示数据）",
             tenant, wsid))
        c.execute("INSERT INTO case_document(case_id,document_id) VALUES(?,?)", (cid, did))
    crit = sum(1 for x in findings if x.get("severity") == "critical")
    warn = sum(1 for x in findings if x.get("severity") == "warning")
    sus = len(findings) - crit - warn
    c.execute(
        "INSERT INTO audit_run(id,case_id,created_at,created_by,audit_type,total,critical,"
        "warning,suspected) VALUES(?,?,?,?,?,?,?,?,?)",
        (rid, cid, last_audit_at, by, audit_type, len(findings), crit, warn, sus))
    for j, f in enumerate(findings, 1):
        file_idx = int(f.get("file") or 0)
        file_idx = file_idx if 0 <= file_idx < len(files) else 0
        did = f"doc-{cid}-{file_idx + 1}"
        sheet = f.get("sheet") or ""
        locator = f.get("locator") or ("{}!A{}".format(sheet, 1 + (j % 28)) if sheet else f"第 {1 + (j % 12)} 页")
        quote = f.get("quote") or f"{f.get('title')}：需要在 {files[file_idx].get('filename')} 中核对数量、单位、日期与签字。"
        fid = f"fnd-{cid}-{j:03d}"
        aid = f"anc-{cid}-{j:03d}"
        eid = f"ev-{cid}-{j:03d}"
        c.execute(
            "INSERT INTO finding(id,case_id,rule_id,rule_version,severity,certainty,confidence,"
            "status,title,summary,suggestion,grade,engine,run_id,point_id,source_code,"
            "tenant_id,workspace_id,state) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (fid, cid, f.get("rule_code") or f"DEMO-{cid[-6:]}-{j:02d}", "v1",
             f.get("severity") or "warning", f.get("certainty") or "semantic",
             f.get("confidence") if f.get("confidence") is not None else 0.86,
             f.get("status") or "pending", f.get("title") or "",
             f.get("summary") or f"多文件交叉核对发现：{f.get('title')}，涉及 {files[file_idx].get('filename')}。",
             f.get("suggestion") or "补证、统一数量/单位/日期口径，并由审核员复核。",
             f.get("grade") or ("R1" if f.get("severity") == "critical" else ("R2" if f.get("severity") == "warning" else "R3")),
             f.get("engine") or run_engine, rid, f.get("rule_code") or "", "DEMO", tenant, wsid,
             f.get("state") or "不满足"))
        c.execute(
            "INSERT INTO anchor(id,document_id,sheet,row,col,locator,quote,hash) VALUES(?,?,?,?,?,?,?,?)",
            (aid, did, sheet, (1 + (j % 28)) if sheet else None, "", locator, quote,
             hashlib.sha256(quote.encode()).hexdigest()))
        c.execute(
            "INSERT INTO evidence(id,finding_id,document_id,anchor_id,excerpt,label) VALUES(?,?,?,?,?,?)",
            (eid, fid, did, aid, quote, "多文件案例证据"))
    return 1


# ---------------------------------------------------------------------------
# P1-1 四角色演示账号：reviewer / admin / super_admin / platform_op 每角色 ≥3 个
# ---------------------------------------------------------------------------
_DEMO_ACCOUNTS = [
    # (id, phone, name, email, pwd, role_code, portal, department)
    ("user-reviewer-02", "13700002223", "李娜", "rev2@local", "Rev@123456", "reviewer", "reviewer", "质量审核二部"),
    ("user-reviewer-03", "13700002224", "张敏", "rev3@local", "Rev@123456", "reviewer", "reviewer", "供应商质量部"),
    ("user-reviewer-04", "13700002225", "陈晨", "rev4@local", "Rev@123456", "reviewer", "reviewer", "合同管理部"),
    ("user-admin-02", "13500001112", "李强", "tenant2@local", "Acme@123456", "admin", "admin", "合同管理部"),
    ("user-admin-03", "13500001113", "陈静", "tenant3@local", "Acme@123456", "admin", "admin", "审计部"),
    ("user-super-02", "13800000002", "赵磊", "super2@local", "Admin@123456", "super_admin", "admin", "信息技术部"),
    ("user-platform-02", "13600003334", "孙磊", "plat2@local", "Plat@123456", "platform_op", "platform", "平台运营部"),
    ("user-platform-03", "13600003335", "郑爽", "plat3@local", "Plat@123456", "platform_op", "platform", "客户成功部"),
]


def _seed_role_accounts():
    """四个角色各补足到 ≥3 个演示账号（幂等）。"""
    try:
        from app import auth
    except Exception:
        return 0
    made = 0
    with db.session() as c:
        for (uid, phone, name, email, pw, role, portal, dept) in _DEMO_ACCOUNTS:
            exists = c.execute("SELECT 1 FROM user WHERE id=?", (uid,)).fetchone()
            h, salt = auth.hash_password(pw)
            c.execute(
                "INSERT OR IGNORE INTO user(id,username,name,email,phone,status,password_hash,"
                "salt,must_change_pwd,created_at,portal,initial_password,tenant_id,department) "
                "VALUES(?,?,?,?,?,'active',?,?,0,?,?,?,'t-default',?)",
                (uid, phone, name, email, phone, h, salt, db.now(), portal, pw, dept))
            c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) SELECT ?, id FROM role WHERE code=?",
                      (uid, role))
            if not exists:
                made += 1
    return made


# ---------------------------------------------------------------------------
# 演示空间成员关系：四个角色的演示账号都能在登录后看到 ws-demo
# ---------------------------------------------------------------------------
_DEMO_WS_MEMBER_IDS = (
    # 四角色核心演示账号（reviewer / admin / super_admin / platform_op）
    "user-reviewer", "user-tenant", "user-admin", "user-platform",
    # ws-demo 演示项目的 owner（审核员 02~04）；admin 汇总视图不依赖成员关系
    "user-reviewer-02", "user-reviewer-03", "user-reviewer-04",
    "user-admin-02", "user-admin-03", "user-super-02",
    "user-platform-02", "user-platform-03",
)


def _seed_demo_workspace_members():
    """给演示账号补 ws-demo 成员关系（user_workspace，幂等）。

    只写成员关系，不改动 ws-default 的任何数据；admin 的租户汇总视图本来就不按
    成员空间切分，所以这里只保证「登录后能看到演示空间」。
    """
    made = 0
    with db.session() as c:
        for uid in _DEMO_WS_MEMBER_IDS:
            if not c.execute("SELECT 1 FROM user WHERE id=?", (uid,)).fetchone():
                continue
            cur = c.execute("INSERT OR IGNORE INTO user_workspace(user_id,workspace_id) VALUES(?,?)",
                            (uid, _DEMO_WS_ID))
            made += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
    return made


# ---------------------------------------------------------------------------
# P1-2 审核员项目（每个 reviewer ≥6 个在办项目、每个项目 ≥2 份文件）
# ---------------------------------------------------------------------------
_REVIEWER_ACCOUNTS = [
    ("user-reviewer", "王芳", "质量审核部"),
    ("user-reviewer-02", "李娜", "质量审核二部"),
    ("user-reviewer-03", "张敏", "供应商质量部"),
    ("user-reviewer-04", "陈晨", "合同管理部"),
]

_REVIEWER_THEMES = [
    {
        "key": "contract", "name": "采购合同专项复核", "audit_type": "contract", "doc_type": "采购合同",
        "docx_title": "采购合同（演示）",
        "docx_blocks": [
            ("h", "合同主体"), ("p", ["甲方：星海科技（演示）", "乙方：华东设备（演示）", "合同编号：HT-2026-10-18"]),
            ("h", "采购与交付"), ("p", ["采购 96 台边缘网关、18 台核心交换机，交付地点：星海科技一号园区。",
                                        "交付期：合同生效后 30 个日历日；逾期按每日 0.5% 计违约金。"]),
            ("h", "付款与验收"), ("p", ["预付款 30%，到货验收后支付 60%，质保金 10%。",
                                        "验收标准：设备清单、报价表、到货验收报告三者一致。"]),
            ("t", (["条款", "约定", "核对说明"],
                   [["付款节点", "验收后支付", "缺具体天数"], ["质保期", "2 年", "低于要求 3 年"],
                    ["违约金", "每日 0.5%", "比例偏高"], ["验收", "三方签字", "缺少乙方签字栏"]])),
        ],
        "xlsx_sheets": [
            ("报价明细", [["序号", "设备", "单价", "数量", "小计"],
                          ["1", "边缘网关", 6800, 96, 652800], ["2", "核心交换机", 42000, 18, 756000],
                          ["3", "光模块", 850, 160, 136000], ["合计", "", "", "", 1544800]]),
            ("付款计划", [["节点", "比例", "金额", "条件"], ["预付款", "30%", 463440, "合同生效"],
                          ["到货款", "60%", 926880, "到货验收"], ["质保金", "10%", 154480, "质保期满"]]),
            ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "数量不一致", "严重", "清单 96 台，报价 88 台"],
                          ["2", "单位混用", "一般", "个/套混用"], ["3", "日期缺失", "一般", "验收日期空白"]]),
        ],
        "findings": ["付款节点缺少明确天数", "质保期限不足合同要求", "设备数量与报价表不一致", "到货验收日期早于合同生效",
                     "预付款比例超出授权", "验收报告缺少乙方签字", "核心交换机参数负偏离", "光模块数量不匹配",
                     "违约金比例高于上限", "设备清单单位混用"],
    },
    {
        "key": "tender", "name": "招标文件合规审查", "audit_type": "tender", "doc_type": "招标文件",
        "docx_title": "招标文件与评审办法（演示）",
        "docx_blocks": [
            ("h", "招标公告"), ("p", ["项目编号：ZB-2026-11-08", "投标截止时间：2026-11-20 09:30",
                                       "开标地点：市公共资源交易中心。"]),
            ("h", "资格要求"), ("p", ["投标人须具备信息系统集成及服务资质。", "近三年至少 2 个同类项目业绩。",
                                       "项目负责人须具备高级项目经理资格。"]),
            ("h", "评审办法"), ("p", ["综合评分法：价格 40 分、技术 45 分、服务 15 分。",
                                       "技术参数负偏离超过 3 项按无效投标处理。"]),
            ("t", (["评分项", "分值", "说明"], [["价格", 40, "基准价法"], ["技术", 45, "负偏离扣分"],
                                                ["服务", 15, "响应时间与人员配置"]])),
        ],
        "xlsx_sheets": [
            ("投标报价", [["投标人", "报价", "工期", "质保"], ["甲公司", 2380000, "20 天", "3 年"],
                          ["乙公司", 2260000, "25 天", "3 年"], ["丙公司", 2190000, "30 天", "2 年"]]),
            ("技术评分", [["投标人", "技术得分", "负偏离项", "说明"], ["甲公司", 41, 1, "1 项负偏离"],
                          ["乙公司", 38, 4, "超过 3 项，应按无效处理"], ["丙公司", 35, 2, "需复核"]]),
            ("资格核对", [["投标人", "资质", "业绩", "项目经理"], ["甲公司", "符合", "2 个", "高级"],
                          ["乙公司", "符合", "1 个", "高级"], ["丙公司", "符合", "2 个", "中级"]]),
        ],
        "findings": ["技术负偏离超过限制未作无效处理", "投标人业绩数量不足", "项目经理资格不符", "报价与清单合计不一致",
                     "资格条件与评审办法相互矛盾", "投标截止时间与公告不一致", "价格分计算错误", "质保期不满足要求",
                     "投标文件缺少必要附件", "评分表分值合计异常"],
    },
    {
        "key": "construction", "name": "施工合同与结算复核", "audit_type": "construction", "doc_type": "施工合同",
        "docx_title": "建设工程施工合同（演示）",
        "docx_blocks": [
            ("h", "工程概况"), ("p", ["工程名称：城投产业园二期道路工程", "合同价：2860 万元",
                                       "工期：180 日历天。"]),
            ("h", "结算条款"), ("p", ["结算按实际完成工程量计量，材料价差按施工期信息价调整。",
                                       "设计变更须经监理与建设单位书面确认。"]),
            ("h", "质量与安全"), ("p", ["隐蔽工程验收记录须齐全。", "安全文明施工费按合同价 2.5% 计取。"]),
            ("t", (["项目", "合同值", "结算值", "核对"], [["合同价", "2860 万", "2932 万", "超合同 2.5%"],
                                                          ["变更签证", "3 项", "6 项", "3 项无书面确认"],
                                                          ["材料价差", "按信息价", "按供应商报价", "口径不一致"]])),
        ],
        "xlsx_sheets": [
            ("合约清单", [["序号", "项目", "合同量", "结算量"], ["1", "路基土方", 12000, 12800],
                          ["2", "水稳基层", 26000, 26000], ["3", "沥青面层", 48000, 48120]]),
            ("变更签证", [["编号", "事由", "金额", "确认状态"], ["BG-01", "管线迁改", 186000, "已确认"],
                          ["BG-02", "路基换填", 240000, "缺监理签字"], ["BG-03", "绿化调整", 96000, "缺书面确认"]]),
            ("材料价差", [["材料", "投标价", "结算价", "调整方式"], ["沥青", 4200, 4680, "信息价"],
                          ["水泥", 430, 452, "供应商报价"]]),
            ("结算汇总", [["项目", "金额"], ["合约内", 28600000], ["变更", 522000], ["价差", 148000], ["合计", 29260000]]),
        ],
        "findings": ["结算总额超过合同价未说明原因", "变更签证缺少监理签字", "材料价差未按信息价调整",
                     "实际工程量与图纸不符", "安全文明施工费计取基数错误", "隐蔽工程验收记录缺失",
                     "结算清单合计与分项不一致", "变更事项超出合同授权范围", "工期顺延未办理签证",
                     "质量保证金扣留比例不足"],
    },
    {
        "key": "food", "name": "食品工艺与检验复核", "audit_type": "food", "doc_type": "工艺规程",
        "docx_title": "酱卤牛肉工艺规程（演示）",
        "docx_blocks": [
            ("h", "产品信息"), ("p", ["产品名称：酱卤牛肉", "执行标准：GB 2726（演示）", "批次：2026-10-18-A"]),
            ("h", "关键工序"), ("p", ["解冻：0–8℃，解冻 12 小时。", "卤制：中心温度≥ 85℃，保温≥ 10 分钟。",
                                       "冷却：2 小时内冷却至 10℃ 以下。", "包装：净含量 250g，允许偏差 ±3g。"]),
            ("h", "检验要求"), ("p", ["每批检测菌落总数、大肠菌群、亚硝酸盐。", "检验记录须有检验员签字和日期。"]),
            ("t", (["工序", "参数", "限值", "实测"], [["解冻", "温度", "0–8℃", "5℃"], ["卤制", "中心温度", "≥85℃", "82℃"],
                                                      ["冷却", "冷却时间", "≤120 分钟", "150 分钟"],
                                                      ["包装", "净含量", "250±3g", "247g"]])),
        ],
        "xlsx_sheets": [
            ("工艺参数", [["工序", "参数", "实测", "单位"], ["解冻", "温度", 5, "℃"], ["卤制", "中心温度", 82, "℃"],
                          ["卤制", "保温时间", 12, "分钟"], ["冷却", "冷却时间", 150, "分钟"]]),
            ("检验记录", [["项目", "结果", "单位", "判定"], ["菌落总数", 12000, "CFU/g", "符合"],
                          ["大肠菌群", 30, "MPN/100g", "符合"], ["亚硝酸盐", 18, "mg/kg", "符合"],
                          ["中心温度", 82, "℃", "不符合"]]),
            ("配料表", [["原料", "投料量", "单位", "批次"], ["牛肉", 100, "kg", "B-01"],
                        ["酱油", 6, "kg", "B-01"], ["食盐", 2.2, "kg", "B-01"]]),
        ],
        "findings": ["卤制中心温度未达标", "保温时间不足", "冷却时间超出限制", "净含量偏差接近下限",
                     "检验记录缺少检验员签字", "配料表投料量不一致", "批次号前后不一致", "菌落总数接近限值",
                     "亚硝酸盐结果异常", "工艺参数单位混用"],
    },
    {
        "key": "nda", "name": "保密与数据安全协议审查", "audit_type": "contract", "doc_type": "保密协议",
        "docx_title": "源代码保密协议（演示）",
        "docx_blocks": [
            ("h", "协议双方"), ("p", ["甲方：云川软件有限公司", "乙方：外包开发团队", "协议编号：NDA-2026-08-12"]),
            ("h", "保密范围"), ("p", ["包括源代码、设计文档、客户数据与测试数据。", "保密期限：协议终止后 3 年。"]),
            ("h", "数据安全"), ("p", ["乙方不得将数据传输至境外服务器。", "发生数据泄露应在 24 小时内通知甲方。"]),
            ("t", (["条款", "约定", "风险点"], [["保密期限", "3 年", "低于客户要求 5 年"],
                                                ["泄露通知", "24 小时", "未约定违约金"],
                                                ["数据出境", "未约定", "高风险缺口"]])),
        ],
        "xlsx_sheets": [
            ("保密事项清单", [["编号", "保密事项", "等级", "期限"], ["M-01", "源代码", "绝密", "3 年"],
                              ["M-02", "客户数据", "机密", "3 年"], ["M-03", "设计文档", "秘密", "2 年"]]),
            ("权限矩阵", [["角色", "源代码", "客户数据", "设计文档"], ["开发", "读写", "只读", "读写"],
                          ["测试", "只读", "只读", "只读"], ["运维", "只读", "只读", "无"]]),
            ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "保密期限不足", "严重", "客户要求 5 年"],
                          ["2", "缺少违约金", "严重", "泄露无赔付责任"]]),
        ],
        "findings": ["保密期限短于客户要求", "缺少数据泄露违约金条款", "数据出境条款缺失", "权限矩阵与最小授权不符",
                     "源代码访问未分级", "通知时限与应急处置脱节", "协议编号与台账不一致", "乙方人员清单缺失",
                     "分包转包未作限制", "协议签署页缺少日期"],
    },
    {
        "key": "supplier", "name": "供应商准入资料审查", "audit_type": "supplier", "doc_type": "准入申请",
        "docx_title": "供应商准入申请与承诺（演示）",
        "docx_blocks": [
            ("h", "申请主体"), ("p", ["供应商名称：恒昌包装材料有限公司", "统一社会信用代码：91320500MA1XXXXXX9",
                                       "申请品类：食品级包装袋。"]),
            ("h", "资质清单"), ("p", ["营业执照、食品生产许可证、检验报告、ISO 22000 证书。",
                                       "所有证书应在有效期内，且经营范围内包含申请品类。"]),
            ("h", "承诺事项"), ("p", ["承诺所供产品符合 GB 4806 食品接触材料标准。", "承诺配合年度现场审核。"]),
            ("t", (["证书", "编号", "有效期", "核对"], [["营业执照", "91320500MA1XXXXXX9", "长期", "经营范围缺失"],
                                                        ["食品生产许可证", "SC10232050500123", "2027-05-01", "符合"],
                                                        ["检验报告", "JY-2026-0812", "2026-08-12", "已过期"]])),
        ],
        "xlsx_sheets": [
            ("基本资质", [["证书", "编号", "有效期至", "状态"], ["营业执照", "91320500MA1XXXXXX9", "长期", "经营范围不符"],
                          ["食品生产许可证", "SC10232050500123", "2027-05-01", "有效"],
                          ["ISO 22000", "CN-22000-2025-088", "2026-09-30", "已过期"]]),
            ("业绩清单", [["年度", "客户", "合同额", "履约评价"], ["2024", "华东食品", 320, "良好"],
                          ["2025", "星海科技", 180, "良好"], ["2026", "城投产业园", 96, "待评价"]]),
            ("财务与合规", [["指标", "数值", "要求", "结论"], ["注册资本", "500 万", "≥300 万", "符合"],
                            ["近三年处罚", "1 次", "0 次", "不符合"]]),
        ],
        "findings": ["营业执照经营范围不含申请品类", "检验报告已过期", "ISO 22000 证书过期", "近三年存在行政处罚",
                     "注册资本证明缺失", "业绩清单与合同不一致", "承诺书未签字盖章", "现场审核计划缺失",
                     "供应商编码重复", "附件清单与实际附件不符"],
    },
    {
        "key": "compliance", "name": "跨系统对账与合规审计", "audit_type": "compliance", "doc_type": "审计底稿",
        "docx_title": "跨系统对账与合规审计说明（演示）",
        "docx_blocks": [
            ("h", "审计范围"), ("p", ["覆盖 ERP 采购订单、SRM 供应商门户、财务应付凭证三套系统。",
                                       "抽期：2026-07-01 至 2026-09-30。"]),
            ("h", "对账口径"), ("p", ["订单金额以 ERP 为准，发票金额以财务系统为准。",
                                       "差异超过 0.5% 或金额超过 5 万元须逐笔说明。"]),
            ("h", "例外事项"), ("p", ["抽查 120 笔，发现 17 笔差异。", "其中 6 笔无审批，4 笔跨期入账。"]),
            ("t", (["系统", "记录数", "差异数", "差异率"], [["ERP", 120, 17, "14.2%"], ["SRM", 118, 9, "7.6%"],
                                                            ["财务", 120, 12, "10.0%"]])),
        ],
        "xlsx_sheets": [
            ("ERP-采购订单", [["订单号", "供应商", "金额", "状态"], ["PO-260701", "恒昌包装", 186000, "已入库"],
                              ["PO-260702", "云川软件", 420000, "部分入库"], ["PO-260703", "远航物流", 96000, "已入库"]]),
            ("SRM-供应商门户", [["订单号", "供应商", "金额", "确认状态"], ["PO-260701", "恒昌包装", 186000, "已确认"],
                                ["PO-260702", "云川软件", 410000, "未确认"], ["PO-260704", "恒昌包装", 58000, "已确认"]]),
            ("财务-应付凭证", [["凭证号", "供应商", "金额", "期间"], ["AP-2607-01", "恒昌包装", 186000, "2026-07"],
                               ["AP-2608-12", "云川软件", 420000, "2026-08"], ["AP-2609-03", "远航物流", 96000, "2026-09"]]),
            ("例外事项", [["编号", "事项", "金额", "等级"], ["EX-01", "订单与发票差异", 10000, "严重"],
                          ["EX-02", "无审批付款", 58000, "严重"], ["EX-03", "跨期入账", 96000, "一般"]]),
            ("汇总", [["系统", "抽查数", "差异数"], ["ERP", 120, 17], ["SRM", 118, 9], ["财务", 120, 12]]),
        ],
        "findings": ["ERP 与财务系统金额不一致", "SRM 订单未确认即入库", "差异说明缺失审批", "跨期入账未调整",
                     "供应商主数据不一致", "订单状态与入库单不符", "发票与合同主体不一致", "对账差异率超过阈值",
                     "例外事项未闭环", "审计底稿缺少复核签字"],
    },
]


def _seed_reviewer_projects():
    """每个审核员 ≥6 个在办项目、每个项目 ≥2 份真实文件（Word + Excel）。"""
    import os as _os
    import hashlib
    try:
        from docx import Document  # noqa: F401
        from openpyxl import Workbook  # noqa: F401
    except Exception:
        return 0
    base = os.path.dirname(os.path.abspath(__file__))
    roots = [_os.path.join(base, "seed", _DEMO_GEN_SUBDIR, "reviewer"), _os.path.join(base, "seed", "demo_docs")]
    for d in roots:
        _os.makedirs(d, exist_ok=True)
    made = 0
    with db.session() as c:
        # 本轮新增演示数据统一落演示专用空间 ws-demo；ws-default 保持门禁干净基线。
        wsid = _DEMO_WS_ID
        for r_idx, (uid, uname, dept) in enumerate(_REVIEWER_ACCOUNTS):
            for t_idx, theme in enumerate(_REVIEWER_THEMES):
                cid = f"case-rev-{r_idx + 1:02d}-{t_idx + 1:02d}"
                if c.execute("SELECT 1 FROM audit_case WHERE id=?", (cid,)).fetchone():
                    continue
                pname = f"演示项目｜{theme['name']}（{uname}）"
                # 日期落在 9/10 月：保持演示数据丰富，同时不晚于 ws-default 基线最新
                # 项目（2026-11-13），避免「项目列表第一项」是其他空间的演示项目而触发
                # 默认空间上下文的跨空间 403（门禁按列表第一项做写侧/导出断言）。
                created = f"2026-{9 + (t_idx % 2):02d}-{(r_idx * 3 + t_idx) % 27 + 1:02d} {9 + (t_idx % 8)}:20:00"
                sub = _os.path.join(roots[0], cid)
                _os.makedirs(sub, exist_ok=True)
                docx_name = _demo_safe_name(f"{uname}-{theme['name']}-主文件.docx")
                xlsx_name = _demo_safe_name(f"{uname}-{theme['name']}-明细表.xlsx")
                docx_path = _demo_write_docx(_os.path.join(sub, docx_name), theme["docx_title"], theme["docx_blocks"])
                xlsx_path = _demo_write_xlsx(_os.path.join(sub, xlsx_name), theme["xlsx_sheets"])
                files = [
                    {"filename": docx_name, "doc_type": theme["doc_type"], "path": docx_path,
                     "summary": f"{theme['name']} · 主文件已解析；含条款与核对表"},
                    {"filename": xlsx_name, "doc_type": "明细表", "path": xlsx_path,
                     "summary": f"{theme['name']} · 明细表已解析；{len(theme['xlsx_sheets'])} 个 Sheet"},
                ]
                findings = []
                for j in range(10):
                    title = theme["findings"][j % len(theme["findings"])]
                    files_idx = j % 2
                    sheet = theme["xlsx_sheets"][j % len(theme["xlsx_sheets"])][0] if files_idx == 1 else ""
                    findings.append({
                        "title": f"{title}（第 {j + 1} 处）",
                        "severity": ("critical", "warning", "warning", "suspected")[j % 4],
                        "suggestion": "补证并复核金额/日期/签字，必要时退回补充材料。",
                        "summary": f"多文件交叉核对：{title}；需回看主文件与明细表。",
                        "file": files_idx, "sheet": sheet,
                        "locator": (f"{sheet}!A{2 + j}" if sheet else f"第 {1 + (j % 9)} 页"),
                        "status": "pending" if j % 4 else "confirmed",
                        "quote": f"原文：{title}；数值/日期/签字需与明细表核对（{theme['name']}）。",
                        "rule_code": f"{theme['key'].upper()}-REV-{j + 1:02d}",
                    })
                status = "reviewing" if t_idx % 3 != 2 else "auditing"
                made += _demo_insert_case(
                    c, cid=cid, name=pname, status=status, progress=40 + (t_idx * 7) % 50,
                    created=created, by=uid, audit_type=theme["audit_type"],
                    document_type=theme["doc_type"], wsid=wsid, tenant="t-default",
                    files=files, findings=findings,
                    focus=f"演示：{theme['name']}；多文件交叉核对", audit_category="演示项目（审核员）",
                    last_audit_at=created, run_engine="demo_reviewer_doc")
    return made


# ---------------------------------------------------------------------------
# P1-3 历史归档项目（显著扩大项目/文档/发现总量；供 admin 汇总与平台演示）
# ---------------------------------------------------------------------------
_ARCHIVE_TOTAL = 224


def _seed_archive_projects():
    """批量历史完成项目：224 个（4 个审核员轮转），每个 2 份文件 + 5 条发现。"""
    import os as _os
    try:
        from docx import Document  # noqa: F401
        from openpyxl import Workbook  # noqa: F401
    except Exception:
        return 0
    base = os.path.dirname(os.path.abspath(__file__))
    pool = _os.path.join(base, "seed", _DEMO_GEN_SUBDIR, "pool")
    _os.makedirs(pool, exist_ok=True)
    pool_files = []
    for t_idx, theme in enumerate(_REVIEWER_THEMES):
        docx_path = _demo_write_docx(
            _os.path.join(pool, _demo_safe_name(f"归档样本-{theme['name']}-主文件.docx")),
            theme["docx_title"], theme["docx_blocks"])
        xlsx_path = _demo_write_xlsx(
            _os.path.join(pool, _demo_safe_name(f"归档样本-{theme['name']}-明细表.xlsx")),
            theme["xlsx_sheets"])
        pool_files.append((docx_path, xlsx_path))
    made = 0
    with db.session() as c:
        # 本轮新增演示数据统一落演示专用空间 ws-demo；ws-default 保持门禁干净基线。
        wsid = _DEMO_WS_ID
        for n in range(1, _ARCHIVE_TOTAL + 1):
            cid = f"case-arc-{n:03d}"
            if c.execute("SELECT 1 FROM audit_case WHERE id=?", (cid,)).fetchone():
                continue
            t_idx = (n - 1) % len(_REVIEWER_THEMES)
            theme = _REVIEWER_THEMES[t_idx]
            r_idx = (n - 1) % len(_REVIEWER_ACCOUNTS)
            uid, uname, _dept = _REVIEWER_ACCOUNTS[r_idx]
            year = 2025 + (n % 2)
            # 月份限 1..10：2026 年归档不晚于基线最新项目，见 _seed_reviewer_projects 注释
            month = (n * 5) % 10 + 1
            day = (n * 7) % 27 + 1
            created = f"{year}-{month:02d}-{day:02d} {8 + (n % 9)}:{10 + (n % 40):02d}:00"
            docx_path, xlsx_path = pool_files[t_idx]
            docx_name = _demo_safe_name(f"{theme['name']}-{year}{month:02d}{day:02d}-主文件.docx")
            xlsx_name = _demo_safe_name(f"{theme['name']}-{year}{month:02d}{day:02d}-明细表.xlsx")
            files = [
                {"filename": docx_name, "doc_type": theme["doc_type"], "path": docx_path,
                 "summary": f"历史归档样例（{theme['name']}）· 主文件已解析"},
                {"filename": xlsx_name, "doc_type": "明细表", "path": xlsx_path,
                 "summary": f"历史归档样例（{theme['name']}）· 明细表 {len(theme['xlsx_sheets'])} 个 Sheet"},
            ]
            findings = []
            for j in range(5):
                title = theme["findings"][(n + j) % len(theme["findings"])]
                files_idx = j % 2
                sheet = theme["xlsx_sheets"][j % len(theme["xlsx_sheets"])][0] if files_idx else ""
                findings.append({
                    "title": f"{title}（归档 {n:03d}-{j + 1}）",
                    "severity": ("critical", "warning", "warning", "suspected", "warning")[j % 5],
                    "file": files_idx, "sheet": sheet,
                    "summary": f"历史归档样例：{title}。",
                    "status": "confirmed" if j % 3 else "pending",
                    "rule_code": f"ARC-{t_idx + 1:02d}-{j + 1:02d}",
                })
            made += _demo_insert_case(
                c, cid=cid, name=f"归档项目｜{theme['name']}｜{year}-{month:02d}-{day:02d}（{uname}）",
                status="completed", progress=100, created=created, by=uid,
                audit_type=theme["audit_type"], document_type=theme["doc_type"],
                wsid=wsid, tenant="t-default", files=files, findings=findings,
                focus=theme["name"], audit_category="演示项目（历史归档）",
                last_audit_at=created, run_engine="demo_archive")
    return made


def _seed_fill_ongoing_docs():
    """在办项目补齐到 ≥2 份文档（用户要求「每个项目 ≥2 份文档」；历史单文件项目补附件）。

    只处理 t-default 下审核员的在办项目，唯一目的是让演示数据满足「多文件」要求；
    已完成的历史项目保持原样，不重复堆文档。幂等：按 doc-<case>-supp 判重。
    """
    import os as _os
    import hashlib
    try:
        from openpyxl import Workbook  # noqa: F401
    except Exception:
        return 0
    base = os.path.dirname(os.path.abspath(__file__))
    suppdir = _os.path.join(base, "seed", _DEMO_GEN_SUBDIR, "supplement")
    _os.makedirs(suppdir, exist_ok=True)
    made = 0
    with db.session() as c:
        # 本轮新增演示数据统一落演示专用空间 ws-demo；ws-default 保持门禁干净基线。
        wsid = _DEMO_WS_ID
        rows = c.execute(
            "SELECT a.id, a.name, a.created_by, COUNT(cd.document_id) n FROM audit_case a "
            "LEFT JOIN case_document cd ON cd.case_id=a.id "
            "WHERE a.tenant_id='t-default' AND a.workspace_id=? "
            "AND a.status IN ('reviewing','auditing','draft') "
            "AND a.created_by LIKE 'user-reviewer%' GROUP BY a.id HAVING n<2",
            (wsid,)).fetchall()
        for cid, cname, owner, _n in rows:
            did = f"doc-{cid}-supp"
            if c.execute("SELECT 1 FROM document WHERE id=?", (did,)).fetchone():
                continue
            own = _os.path.join(suppdir, _demo_safe_name(owner or "reviewer"))
            _os.makedirs(own, exist_ok=True)
            fn = _demo_safe_name(f"{cid}-补充附件与核对清单.xlsx")
            path = _demo_write_xlsx(_os.path.join(own, fn), [
                ("补充说明", [["项目", "说明"], [cname or cid, "演示补充附件：随主文件一并核对，覆盖数量/日期/签字三类证据。"]]),
                ("核对清单", [["序号", "核对项", "要求", "结论"], ["1", "文件完整性", "主文件+附件齐套", "待复核"],
                              ["2", "日期一致性", "签署日期不晚于生效日期", "待复核"],
                              ["3", "数量金额一致", "清单×单价=合计", "待复核"]]),
                ("附件目录", [["序号", "附件名称", "来源", "状态"], ["1", "报价明细表", "供应商提交", "已收"],
                              ["2", "验收记录", "项目组提交", "已收"], ["3", "补充协议", "合同管理部", "待补"]]),
            ])
            try:
                h = hashlib.sha256(open(path, "rb").read()).hexdigest()
            except Exception:
                h = ""
            c.execute(
                "INSERT OR IGNORE INTO document(id,filename,doc_type,hash,status,created_at,path,"
                "parse_status,parse_summary,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (did, fn, "补充附件", h, "parsed", db.now(), path, "ok",
                 "演示补充附件与核对清单 · 已解析", "t-default", wsid))
            c.execute("INSERT OR IGNORE INTO case_document(case_id,document_id) VALUES(?,?)", (cid, did))
            made += 1
    return made


# ---------------------------------------------------------------------------
# P0 多文件复杂案例：5 个新案例（3-5 份文件、Word+Excel+PDF、20-30 条问题、易/中/难）
# ---------------------------------------------------------------------------
_COMPLEX2_CASES = [
    {
        "cid": "case-mf-01", "level": "易",
        "name": "复杂演示2（易）｜供应商准入资料包（3 文件 · 20 问题）",
        "status": "completed", "progress": 100, "audit_type": "supplier", "document_type": "准入资料包",
        "created": "2026-11-03 10:10:00",
        "docx": ("复杂演示2-供应商准入申请与承诺.docx", "供应商准入申请与承诺（演示）",
                 [("h", "申请主体"), ("p", ["供应商：恒昌包装材料有限公司；统一社会信用代码：91320500MA1XXXXXX9。",
                                            "申请品类：食品级包装袋（直接接触食品）。"]),
                  ("h", "提交资料"), ("p", ["营业执照、食品生产许可证、检验报告、ISO 22000 证书、承诺书。"]),
                  ("t", (["资料", "编号", "有效期", "核对结论"],
                         [["食品生产许可证", "SC10232050500123", "2027-05-01", "符合"],
                          ["检验报告", "JY-2026-0812", "2026-08-12", "已过期"],
                          ["ISO 22000", "CN-22000-2025-088", "2026-09-30", "已过期"]])),
                  ("h", "承诺事项"), ("p", ["承诺产品符合 GB 4806 系列标准。", "承诺配合年度现场审核与飞行检查。"]),
                  ("t", (["资料", "要求", "缺失/问题"], [["营业执照", "经营范围含包装", "经营范围不含食品包装"],
                                                          ["检验报告", "一年内", "报告已过期"],
                                                          ["承诺书", "法人签字", "缺少签字"]])),
                  ]),
        "xlsx": ("复杂演示2-供应商资质与业绩清单.xlsx",
                 [("基本资质", [["证书", "编号", "有效期至", "状态"], ["营业执照", "91320500MA1XXXXXX9", "长期", "经营范围不符"],
                                ["食品生产许可证", "SC10232050500123", "2027-05-01", "有效"],
                                ["ISO 22000", "CN-22000-2025-088", "2026-09-30", "已过期"],
                                ["检验报告", "JY-2026-0812", "2026-08-12", "已过期"]]),
                  ("业绩清单", [["年度", "客户", "合同额(万元)", "履约评价"], ["2024", "华东食品", 320, "良好"],
                                ["2025", "星海科技", 180, "良好"], ["2026", "城投产业园", 96, "待评价"]]),
                  ("财务与合规", [["指标", "数值", "要求", "结论"], ["注册资本", "500 万", "≥300 万", "符合"],
                                  ["近三年行政处罚", "1 次", "0 次", "不符合"],
                                  ["社保缴纳人数", 46, "≥30", "符合"]]),
                  ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "报告过期", "严重", "检验报告与 ISO 证书均过期"],
                                ["2", "经营范围不符", "严重", "营业执照未含食品包装"],
                                ["3", "签字缺失", "一般", "承诺书无法人签字"]]),
                  ]),
        "pdf": ("复杂演示2-营业执照与许可证扫描件.pdf", "华东食品-每日坚果-工艺记录-2026-07.pdf"),
        "titles": ["营业执照经营范围不含申请品类", "检验报告已过期", "ISO 22000 证书过期", "近三年存在行政处罚",
                   "注册资本证明材料缺失", "业绩清单与合同台账不一致", "承诺书缺少法人签字", "现场审核计划缺失",
                   "供应商编码与主数据重复", "附件清单与实际附件不符", "食品接触材料检测项目缺失",
                   "生产许可品类与申请品类不一致", "质量管理体系文件未提交", "供应商分级评价未完成",
                   "银行开户证明缺失", "授权委托书过期", "历史供货质量事故未披露", "环评批复缺失",
                   "特种设备使用登记缺失", "年度自查报告缺失"],
    },
    {
        "cid": "case-mf-02", "level": "易",
        "name": "复杂演示2（易）｜设备到货验收资料包（3 文件 · 20 问题）",
        "status": "completed", "progress": 100, "audit_type": "acceptance", "document_type": "验收资料包",
        "created": "2026-11-05 14:00:00",
        "docx": ("复杂演示2-设备到货验收报告.docx", "设备到货验收报告（演示）",
                 [("h", "验收概况"), ("p", ["合同编号：HT-2026-10-18；到货日期：2026-11-02。",
                                            "验收地点：星海科技一号园区 3 号机房；参加方：甲方、乙方、监理。"]),
                  ("h", "验收内容"), ("p", ["核对设备型号、数量、序列号、外观与随机资料。",
                                            "加电测试与连通性测试结果记录于附表。"]),
                  ("t", (["设备", "合同数量", "到货数量", "核对"], [["边缘网关", 96, 88, "少 8 台"],
                                                                    ["核心交换机", 18, 18, "型号不符 2 台"],
                                                                    ["光模块", 160, 160, "序列号缺失"]]),
                         )],
                 ),
        "xlsx": ("复杂演示2-到货清单与检验记录.xlsx",
                 [("到货清单", [["序号", "设备名称", "型号", "数量", "单位"], ["1", "边缘网关", "GW-3200", 88, "台"],
                                ["2", "核心交换机", "CS-7800", 18, "台"], ["3", "PoE 交换机", "PS-2400", 32, "台"],
                                ["4", "光模块", "SFP-10G", 160, "个"]]),
                  ("开箱检验", [["设备", "外观", "序列号", "加电", "结论"], ["边缘网关", "正常", "缺失 2 台", "通过", "部分不符"],
                                ["核心交换机", "划痕", "一致", "通过", "外观不合格"], ["光模块", "正常", "无法核对", "未测", "待复核"]]),
                  ("附件清单", [["附件", "应到", "实到", "结论"], ["电源线", 152, 152, "符合"],
                                ["机柜螺丝包", 36, 30, "缺少"], ["说明书", 152, 148, "缺少"]]),
                  ("异常记录", [["序号", "异常", "等级", "说明"], ["1", "数量短缺", "严重", "边缘网关少 8 台"],
                                ["2", "型号不符", "严重", "核心交换机 2 台型号不符"],
                                ["3", "序列号缺失", "一般", "光模块序列号无法核对"]]),
                  ]),
        "pdf": ("复杂演示2-设备出厂检验报告.pdf", "华东食品-速冻水饺-工艺记录-2026-06.pdf"),
        "titles": ["到货数量少于合同数量", "设备型号与合同不符", "序列号缺失无法追溯", "外观检验不合格",
                   "加电测试记录缺失", "随机附件数量不足", "说明书与合格证缺失", "验收报告缺少监理签字",
                   "到货日期晚于合同交付期", "核心交换机固件版本不符", "光模块未做连通性测试",
                   "验收结论未区分合格与待复核", "质保起始日与验收日不一致", "设备清单单位混用",
                   "包装破损未记录", "验收人员未签字", "抽检比例不足", "整改计划缺失",
                   "备品备件清单缺失", "入库单与验收单数量不一致"],
    },
    {
        "cid": "case-mf-03", "level": "中",
        "name": "复杂演示2（中）｜多系统采购对账包（4 文件 · 24 问题）",
        "status": "reviewing", "progress": 65, "audit_type": "reconciliation", "document_type": "对账资料包",
        "created": "2026-11-10 09:30:00",
        "docx": ("复杂演示2-采购合同与结算条款.docx", "采购合同与结算条款（演示）",
                 [("h", "合同主体"), ("p", ["甲方：星海科技（演示）；乙方：华东设备（演示）；合同编号：HT-2026-10-18。"]),
                  ("h", "结算条款"), ("p", ["结算以 ERP 采购订单为准，发票金额以财务系统为准。",
                                            "差异超过 0.5% 且金额超过 5 万元须逐笔说明并审批。"]),
                  ("t", (["条款", "约定", "风险点"], [["对账口径", "ERP 为准", "SRM 未同步"],
                                                      ["差异审批", "逐笔说明", "4 笔无审批"],
                                                      ["付款条件", "对账后 15 日", "对账未完成即付款"]]),
                         )],
                 ),
        "xlsx": ("复杂演示2-多系统订单对账底稿.xlsx",
                 [("ERP-采购订单", [["订单号", "供应商", "金额", "状态", "入库"], ["PO-260701", "恒昌包装", 186000, "已入库", "186000"],
                                    ["PO-260702", "云川软件", 420000, "部分入库", "410000"],
                                    ["PO-260703", "远航物流", 96000, "已入库", "96000"]]),
                  ("SRM-供应商门户", [["订单号", "供应商", "金额", "确认状态"], ["PO-260701", "恒昌包装", 186000, "已确认"],
                                      ["PO-260702", "云川软件", 410000, "未确认"],
                                      ["PO-260704", "恒昌包装", 58000, "已确认"]]),
                  ("财务-应付凭证", [["凭证号", "供应商", "金额", "期间"], ["AP-2607-01", "恒昌包装", 186000, "2026-07"],
                                     ["AP-2608-12", "云川软件", 420000, "2026-08"],
                                     ["AP-2609-03", "远航物流", 96000, "2026-09"]]),
                  ("差异说明", [["编号", "差异事项", "金额", "审批"], ["DF-01", "订单与发票差异", 10000, "无"],
                                ["DF-02", "SRM 未确认", 10000, "无"], ["DF-03", "跨期入账", 96000, "无"]]),
                  ("汇总", [["系统", "抽查数", "差异数", "差异率"], ["ERP", 120, 17, "14.2%"],
                            ["SRM", 118, 9, "7.6%"], ["财务", 120, 12, "10.0%"]]),
                  ]),
        "xlsx2": ("复杂演示2-供应商对账单.xlsx",
                  [("对账单", [["供应商", "对账期", "我方金额", "对方金额", "差异"], ["恒昌包装", "2026-07", 186000, 186000, 0],
                               ["云川软件", "2026-08", 420000, 410000, 10000],
                               ["远航物流", "2026-09", 96000, 96000, 0]]),
                   ("差异明细", [["供应商", "差异项", "金额", "说明"], ["云川软件", "服务范围争议", 10000, "SRM 未确认"]]),
                   ]),
        "pdf": ("复杂演示2-供应商对账单扫描件.pdf", "华东食品-酱卤牛肉-工艺记录-2026-08.pdf"),
        "titles": ["ERP 与财务系统采购金额不一致", "SRM 订单未确认即入库", "对账差异说明缺少审批",
                   "跨期入账未做期末调整", "供应商主数据编码不一致", "订单状态与入库单不符",
                   "发票与合同主体不一致", "对账差异率超过阈值", "例外事项未闭环跟踪",
                   "审计底稿缺少复核签字", "采购订单金额与合同不一致", "入库单缺少收货人签字",
                   "付款审批早于对账完成", "供应商对账单金额与 ERP 不符", "多系统期间口径不一致",
                   "部分订单未纳入对账范围", "发票重复入账风险", "差异金额计算错误",
                   "对账周期超过合同约定", "供应商确认回函缺失", "系统间数据同步延迟未记录",
                   "应付暂估与发票金额不一致", "采购退回未冲减对账金额", "对账完成时间晚于付款时间"],
    },
    {
        "cid": "case-mf-04", "level": "中",
        "name": "复杂演示2（中）｜工程项目结算审核包（4 文件 · 26 问题）",
        "status": "reviewing", "progress": 58, "audit_type": "settlement", "document_type": "结算资料包",
        "created": "2026-11-12 15:20:00",
        "docx": ("复杂演示2-施工合同与补充协议.docx", "建设工程施工合同与补充协议（演示）",
                 [("h", "工程概况"), ("p", ["工程名称：城投产业园二期道路工程；合同价：2860 万元；工期：180 日历天。"]),
                  ("h", "结算与变更"), ("p", ["结算按实际完成工程量计量，材料价差按施工期信息价调整。",
                                              "设计变更须经监理与建设单位书面确认后方可计量。"]),
                  ("t", (["项目", "合同值", "结算值", "核对"], [["合同价", "2860 万", "2932 万", "超合同 2.5%"],
                                                                ["变更签证", "3 项", "6 项", "3 项无书面确认"],
                                                                ["材料价差", "信息价", "供应商报价", "口径不一致"]]),
                         )],
                 ),
        "docx2": ("复杂演示2-设计变更与现场签证.docx", "设计变更单与现场签证（演示）",
                  [("h", "变更清单"), ("p", ["BG-01 管线迁改：已确认，金额 18.6 万元。",
                                             "BG-02 路基换填：缺监理签字，金额 24 万元。",
                                             "BG-03 绿化调整：缺书面确认，金额 9.6 万元。"]),
                   ("h", "签证要求"), ("p", ["签证须附现场照片、工程量计算书与监理确认。"]),
                   ("t", (["编号", "事由", "金额", "确认状态"], [["BG-01", "管线迁改", "18.6 万", "已确认"],
                                                                 ["BG-02", "路基换填", "24 万", "缺监理签字"],
                                                                 ["BG-03", "绿化调整", "9.6 万", "缺书面确认"]]),
                          )],
                  ),
        "xlsx": ("复杂演示2-工程结算清单.xlsx",
                 [("合约清单", [["序号", "项目", "合同量", "结算量", "单价"], ["1", "路基土方", 12000, 12800, 46],
                                ["2", "水稳基层", 26000, 26000, 118], ["3", "沥青面层", 48000, 48120, 236]]),
                  ("变更签证", [["编号", "事由", "金额", "确认状态"], ["BG-01", "管线迁改", 186000, "已确认"],
                                ["BG-02", "路基换填", 240000, "缺监理签字"], ["BG-03", "绿化调整", 96000, "缺书面确认"]]),
                  ("材料价差", [["材料", "投标价", "结算价", "调整方式"], ["沥青", 4200, 4680, "信息价"],
                                ["水泥", 430, 452, "供应商报价"]]),
                  ("结算汇总", [["项目", "金额(元)"], ["合约内", 28600000], ["变更", 522000],
                                ["价差", 148000], ["合计", 29260000]]),
                  ]),
        "pdf": ("复杂演示2-工程结算审核报告.pdf", "华东食品-每日坚果-工艺记录-2026-07.pdf"),
        "titles": ["结算总额超过合同价未说明原因", "变更签证缺少监理签字", "材料价差未按信息价调整",
                   "实际工程量与图纸不符", "安全文明施工费计取基数错误", "隐蔽工程验收记录缺失",
                   "结算清单分项合计与总额不一致", "变更事项超出合同授权范围", "工期顺延未办理签证",
                   "质量保证金扣留比例不足", "暂列金额使用未报批", "甲供材料未在结算中抵扣",
                   "重复计量同一分项工程量", "单价与合同清单不一致", "签证日期晚于结算日期",
                   "现场照片与签证内容不符", "工程量计算书缺失", "材料进场验收单缺失",
                   "变更审批流程不完整", "结算审核人员未签字", "合同外新增项目未签补充协议",
                   "税率与合同约定不一致", "预付款未按约定抵扣", "索赔事项未按程序办理",
                   "结算资料清单与实际不符", "审计底稿缺少交叉复核记录"],
    },
    {
        "cid": "case-mf-05", "level": "难",
        "name": "复杂演示2（难）｜集团跨系统合规审计包（5 文件 · 30 问题）",
        "status": "reviewing", "progress": 35, "audit_type": "compliance", "document_type": "合规审计包",
        "created": "2026-11-13 10:05:00",
        "docx": ("复杂演示2-集团合规管理办法.docx", "集团合规管理办法（演示）",
                 [("h", "总则"), ("p", ["适用范围：集团总部及下属 7 家子公司。", "合规审计每年至少一次，覆盖采购、财务、人事三类系统。"]),
                  ("h", "职责分工"), ("p", ["内审部负责年度合规审计计划与整改跟踪。",
                                            "业务部门负责提供系统台账与例外事项说明。"]),
                  ("h", "例外管理"), ("p", ["例外事项须在 10 个工作日内完成整改并归档证据。",
                                            "重大例外事项须报合规委员会审批。"]),
                  ("t", (["要求", "条款", "核对点"], [["每年至少一次", "第 5 条", "2026 年未实施"],
                                                      ["例外 10 日整改", "第 12 条", "6 项超期"],
                                                      ["重大例外报批", "第 13 条", "2 项未报批"]]),
                         )],
                 ),
        "docx2": ("复杂演示2-整改报告与跟踪表.docx", "整改报告与跟踪表（演示）",
                  [("h", "整改进展"), ("p", ["17 项例外中已完成整改 8 项，超期 6 项，未启动 3 项。"]),
                   ("h", "未闭环事项"), ("p", ["EX-02 无审批付款 5.8 万元：未追责。",
                                                "EX-05 供应商主数据不一致：未统一编码。"]),
                   ("t", (["事项", "责任人", "截止日", "状态"], [["EX-01", "财务部", "2026-11-10", "已完成"],
                                                               ["EX-02", "采购部", "2026-11-05", "超期"],
                                                               ["EX-05", "信息部", "2026-11-15", "未启动"]]),
                          )],
                  ),
        "xlsx": ("复杂演示2-跨系统审计底稿.xlsx",
                 [("ERP-总账", [["凭证号", "摘要", "金额", "期间", "状态"], ["GL-2607-11", "采购入库", 186000, "2026-07", "已过账"],
                                  ["GL-2608-21", "服务费", 420000, "2026-08", "已过账"], ["GL-2609-31", "运费", 96000, "2026-09", "待审"]]),
                  ("财务-凭证", [["凭证号", "供应商", "金额", "审批人"], ["AP-2607-01", "恒昌包装", 186000, "王海"],
                                  ["AP-2608-12", "云川软件", 420000, ""], ["AP-2609-03", "远航物流", 96000, "刘敏"]]),
                  ("HR-供应商", [["供应商", "联系人", "银行卡号", "状态"], ["恒昌包装", "张三", "****1234", "在职"],
                                  ["云川软件", "李四", "****5678", "已离职"], ["远航物流", "王五", "****9012", "在职"]]),
                  ("例外事项", [["编号", "事项", "金额", "整改状态"], ["EX-01", "订单与发票差异", 10000, "已完成"],
                                ["EX-02", "无审批付款", 58000, "超期"], ["EX-05", "供应商主数据不一致", 0, "未启动"]]),
                  ("整改跟踪", [["事项", "责任人", "截止日", "状态", "证据"], ["EX-01", "财务部", "2026-11-10", "已完成", "已归档"],
                                ["EX-02", "采购部", "2026-11-05", "超期", "缺失"], ["EX-05", "信息部", "2026-11-15", "未启动", "缺失"]]),
                  ("汇总", [["系统", "例外数", "已整改", "超期"], ["ERP", 7, 4, 2], ["财务", 6, 3, 2], ["HR", 4, 1, 2]]),
                  ]),
        "pdf": ("复杂演示2-年度审计报告样本.pdf", "华东食品-酱卤牛肉-工艺记录-2026-08.pdf"),
        "pdf2": ("复杂演示2-现场抽查记录样本.pdf", "华东食品-速冻水饺-工艺记录-2026-06.pdf"),
        "titles": ["2026 年度合规审计未按计划实施", "例外事项整改超期", "重大例外事项未报合规委员会",
                   "无审批付款", "供应商主数据跨系统不一致", "HR 系统供应商联系人已离职未更新",
                   "ERP 总账与财务凭证金额不一致", "跨期入账未调整", "采购订单缺少验收单",
                   "付款审批人与合同约定不一致", "供应商银行卡变更未复核", "审计底稿缺少交叉复核记录",
                   "例外事项整改证据未归档", "审计范围未覆盖全部子公司", "审计抽样比例不足",
                   "合规委员会会议记录缺失", "整改责任人未落实", "重复供应商编码未清理",
                   "服务费合同与服务范围不符", "运费结算与物流单据不一致", "审计发现未纳入跟踪台账",
                   "信息系统权限未按最小授权", "供应商准入资料过期未更新", "合同续签未履行审批",
                   "发票抬头与合同主体不一致", "预算外支出未审批", "关联交易未披露",
                   "审计报告签发日期晚于报告期", "整改验收无独立复核", "合规培训记录缺失"],
    },
]


def _seed_multi_file_complex_cases():
    """P0：5 个新多文件复杂案例，文件真实生成（Word/Excel），PDF 由样本复制。"""
    import os as _os
    base = os.path.dirname(os.path.abspath(__file__))
    outdir = _os.path.join(base, "seed", "complex_docs")
    _os.makedirs(outdir, exist_ok=True)
    try:
        from docx import Document  # noqa: F401
        from openpyxl import Workbook  # noqa: F401
    except Exception:
        return 0
    made = 0
    with db.session() as c:
        # 本轮新增演示数据统一落演示专用空间 ws-demo；ws-default 保持门禁干净基线。
        wsid = _DEMO_WS_ID
        for spec in _COMPLEX2_CASES:
            cid = spec["cid"]
            if c.execute("SELECT 1 FROM audit_case WHERE id=?", (cid,)).fetchone():
                continue
            files = []
            # 1) Word 主文件
            fn, title, blocks = spec["docx"]
            files.append({"filename": fn, "doc_type": "Word 主文件",
                          "path": _demo_write_docx(_os.path.join(outdir, fn), title, blocks),
                          "summary": f"{title} · 已解析；含条款/工序/核对表（演示）", "sheets": []})
            # 2) Excel 多 Sheet
            fn, sheets = spec["xlsx"]
            files.append({"filename": fn, "doc_type": "Excel 明细表",
                          "path": _demo_write_xlsx(_os.path.join(outdir, fn), sheets),
                          "summary": f"{fn} · 已解析 {len(sheets)} 个 Sheet；含多系统/多明细表（演示）",
                          "sheets": [s[0] for s in sheets]})
            # 3) 可选第二份 Excel（多系统/对账）
            if spec.get("xlsx2"):
                fn, sheets = spec["xlsx2"]
                files.append({"filename": fn, "doc_type": "Excel 明细表",
                              "path": _demo_write_xlsx(_os.path.join(outdir, fn), sheets),
                              "summary": f"{fn} · 已解析 {len(sheets)} 个 Sheet（演示）",
                              "sheets": [s[0] for s in sheets]})
            # 4) 可选第二份 Word
            if spec.get("docx2"):
                fn, title, blocks = spec["docx2"]
                files.append({"filename": fn, "doc_type": "Word 附件",
                              "path": _demo_write_docx(_os.path.join(outdir, fn), title, blocks),
                              "summary": f"{title} · 已解析（演示）", "sheets": []})
            # 5) PDF（无 reportlab：复制现有样本改名）
            fn, src = spec["pdf"]
            files.append({"filename": fn, "doc_type": "PDF 扫描件",
                          "path": _demo_copy_pdf(base, _os.path.join(outdir, fn), src),
                          "summary": f"{fn} · 已解析（演示样本）", "sheets": []})
            if spec.get("pdf2"):
                fn, src = spec["pdf2"]
                files.append({"filename": fn, "doc_type": "PDF 扫描件",
                              "path": _demo_copy_pdf(base, _os.path.join(outdir, fn), src),
                              "summary": f"{fn} · 已解析（演示样本）", "sheets": []})
            titles = spec["titles"]
            count = max(20, len(titles))
            findings = []
            for j in range(count):
                t = titles[j % len(titles)]
                if j >= len(titles):
                    t = f"{t}（{files[j % len(files)]['filename']} 第 {j + 1} 处）"
                file_idx = j % len(files)
                fobj = files[file_idx]
                sheet = (fobj["sheets"][(j // 2) % len(fobj["sheets"])]
                         if fobj.get("sheets") else "")
                findings.append({
                    "title": t,
                    "severity": _DEMO_LEVELS[j % 3] if j % 7 else "suspected",
                    "suggestion": "补证后由审核员复核：核对数量/单位/日期/签字，必要时退回补充材料。",
                    "summary": f"多文件交叉核对发现：{t}；涉及 {fobj['filename']}，需回看原文与表格。",
                    "file": file_idx, "sheet": sheet,
                    "locator": (f"{sheet}!A{2 + (j % 30)}" if sheet else f"第 {1 + (j % 10)} 页"),
                    "status": "pending" if j % 3 else "confirmed",
                    "quote": f"原文（{fobj['filename']}）：{t}；数值/日期/签字需与其余文件交叉核对。",
                    "rule_code": f"MF2-{cid[-2:]}-{j + 1:02d}",
                    "confidence": 0.9 if j % 3 == 0 else (0.82 if j % 3 == 1 else 0.74),
                })
            made += _demo_insert_case(
                c, cid=cid, name=spec["name"], status=spec["status"], progress=spec["progress"],
                created=spec["created"] or db.now(), by="user-reviewer",
                audit_type=spec["audit_type"], document_type=spec["document_type"],
                wsid=wsid, tenant="t-default", files=files, findings=findings,
                focus=f"难度：{spec['level']}；{len(files)} 份文件 · {len(findings)} 条问题；Word+Excel+PDF 混排",
                audit_category=f"复杂案例（{spec['level']}）",
                last_audit_at=spec["created"], run_engine="demo_complex_multi_file")
    return made


def _seed_ontology_demo():
    """P2：本体实例 ≥60 条 + 别名 ≥60 条（新增 40 实例 / 70 别名，平台共享层）。"""
    entities = [
        # (type_key, name, props, [aliases...])
        ("Product", "酱卤牛腱", {"规格": "250g"}, ["卤牛腱", "酱牛腱"]),
        ("Product", "速冻荠菜水饺", {"规格": "500g"}, ["荠菜水饺", "野菜水饺"]),
        ("Product", "每日坚果混合装", {"规格": "25g×30"}, ["坚果混合装", "每日坚果"]),
        ("Product", "喷香烤肉拌饭", {"规格": "380g"}, ["烤肉拌饭", "拌饭"]),
        ("Product", "藤椒鸡腿排", {"规格": "200g"}, ["鸡腿排", "藤椒鸡排"]),
        ("Product", "低温慢煮鸡胸", {"规格": "150g"}, ["慢煮鸡胸", "低温鸡胸"]),
        ("Product", "原切牛腩块", {"规格": "1kg"}, ["牛腩块", "原切牛腩"]),
        ("Product", "净菜西兰花", {"规格": "300g"}, ["西兰花净菜", "西兰花"]),
        ("Party", "云川软件技术有限公司", {"地区": "苏州"}, ["云川软件", "云川"]),
        ("Party", "华东设备制造（苏州）有限公司", {"地区": "苏州"}, ["华东设备", "华东制造"]),
        ("Party", "恒昌包装材料有限公司", {"地区": "无锡"}, ["恒昌包装", "恒昌"]),
        ("Party", "远航物流股份有限公司", {"地区": "上海"}, ["远航物流", "远航"]),
        ("Party", "江北建设集团有限公司", {"地区": "南京"}, ["江北建设", "江北集团"]),
        ("Party", "味源食品（苏州）有限公司", {"地区": "苏州"}, ["味源食品", "味源"]),
        ("Party", "星海科技有限公司", {"地区": "苏州"}, ["星海科技", "星海"]),
        ("Party", "城投产业园开发有限公司", {"地区": "苏州"}, ["城投产业园", "城投"]),
        ("Metric", "卤制中心温度", {"unit": "℃", "scope": "卤制"}, ["中心温度(卤制)", "卤制温度"]),
        ("Metric", "冷却终了温度", {"unit": "℃", "scope": "冷却"}, ["冷却温度", "终了温度"]),
        ("Metric", "亚硝酸盐残留", {"unit": "mg/kg", "scope": "检验"}, ["亚硝酸盐", "亚硝残留"]),
        ("Metric", "菌落总数", {"unit": "CFU/g", "scope": "检验"}, ["菌落计数", "菌落群"]),
        ("Metric", "采购合同金额", {"unit": "元", "scope": "采购"}, ["合同金额", "采购金额"]),
        ("Metric", "质保金比例", {"unit": "%", "scope": "合同"}, ["质量保证金比例", "质保金"]),
        ("Metric", "预付款比例", {"unit": "%", "scope": "合同"}, ["首付款比例", "预付款"]),
        ("Metric", "日违约金费率", {"unit": "%", "scope": "合同"}, ["违约金费率", "逾期费率"]),
        ("Metric", "合同工期", {"unit": "日", "scope": "工程"}, ["工期", "履约期限"]),
        ("Metric", "逾期天数", {"unit": "日", "scope": "合同"}, ["延迟天数", "逾期日数"]),
        ("ProcessStep", "解冻", {"温度": "0–8℃"}, ["解冻工序", "原料解冻"]),
        ("ProcessStep", "卤制", {"中心温度": "≥85℃"}, ["卤制工序", "卤煮"]),
        ("ProcessStep", "冷却", {"终了温度": "≤10℃"}, ["冷却工序", "风冷"]),
        ("ProcessStep", "包装", {"净含量": "250±3g"}, ["包装工序", "封口包装"]),
        ("ProcessStep", "杀菌", {"温度": "121℃"}, ["杀菌工序", "高温杀菌"]),
        ("ProcessStep", "到货验收", {}, ["验收工序", "开箱验收"]),
        ("ProcessStep", "供应商对账", {}, ["对账工序", "月度对账"]),
        ("ProcessStep", "工程结算", {}, ["结算工序", "竣工结算"]),
        ("HalfProduct", "卤制牛腱半成品", {"规格": "5kg/袋"}, ["牛腱半成品", "卤牛腱坯"]),
        ("HalfProduct", "水饺馅料", {"规格": "10kg/箱"}, ["饺子馅", "馅料"]),
        ("HalfProduct", "坚果混合料", {"规格": "8kg/袋"}, ["混合坚果料", "坚果料"]),
        ("HalfProduct", "腌制鸡腿排", {"规格": "4kg/袋"}, ["腌制鸡排", "鸡腿排坯"]),
    ]
    aliases = []
    for type_key, name, props, alist in entities:
        eid = "onto-demo-" + _demo_safe_name(name)
        for k, alias in enumerate(alist):
            aliases.append((f"oa-demo-{_demo_safe_name(name)}-{k + 1}", type_key, alias, eid,
                            f"演示数据：{name} 的常用同义写法（{alias}），由内置演示种子登记。"))
    made = 0
    made_alias = 0
    with db.session() as c:
        for type_key, name, props, alist in entities:
            eid = "onto-demo-" + _demo_safe_name(name)
            if c.execute("SELECT 1 FROM onto_entity WHERE id=?", (eid,)).fetchone():
                continue
            try:
                import json as _json
                props_json = _json.dumps(props, ensure_ascii=False)
            except Exception:
                props_json = "{}"
            c.execute("INSERT OR IGNORE INTO onto_entity(id,type_key,name,props_json,created_at) VALUES(?,?,?,?,?)",
                      (eid, type_key, name, props_json, db.now()))
            made += 1
        for aid, type_key, alias, eid, evidence in aliases:
            if not c.execute("SELECT 1 FROM onto_alias WHERE id=?", (aid,)).fetchone():
                made_alias += 1
            c.execute(
                "INSERT OR IGNORE INTO onto_alias(id,type_key,alias,entity_id,evidence,source,status,created_at) "
                "VALUES(?,?,?,?,?,'seed','approved',?)",
                (aid, type_key, alias, eid, evidence, db.now()))
        # 本体版本记录（发布历史演示）——落演示空间；created_at 用**历史固定时间**，
        # 避免与门禁里真实 publish 写入的行在同秒时「最新已发布版本」指针二义
        # （E-13 断言 version_snapshot.published_version 必须指向本次发布行）。
        for vid, ver, status, note, _created in (
                ("ov-demo-1", "v1", "published", "内置食品本体基线", "2026-10-01 09:00:00"),
                ("ov-demo-2", "v2", "published", "扩充采购/合同/工程指标实体与别名", "2026-10-15 09:00:00"),
                ("ov-demo-3", "v3", "draft", "待发布：补充跨系统对账实体", "2026-10-20 09:00:00")):
            c.execute("INSERT OR IGNORE INTO onto_version(id,version,status,snapshot_json,health_json,"
                      "created_at,published_at,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?)",
                      (vid, ver, status,
                       __import__("json").dumps({"note": note, "entities": len(entities)}, ensure_ascii=False),
                       __import__("json").dumps({"errors": 0, "warnings": 0}, ensure_ascii=False),
                       _created, _created if status == "published" else "",
                       "t-default", _DEMO_WS_ID))
    return made, made_alias


def _seed_rsi_conflicts_demo():
    """P2：规则进化（RSI）≥12 轮历史 + 自动开启/关闭轨迹 + 规则冲突 ≥15 组。"""
    import json as _json
    base = os.path.dirname(os.path.abspath(__file__))
    codes = ["RW20260525005", "RW20260525009", "RW20260525012", "B-4", "C-3", "RW20260525003",
             "RW20260525006", "RW20260525010", "RW20260525011", "B-2", "E3", "E4"]
    rsi_rounds = [
        # (round, date, rule_code, action, decision, delta_note)
        (1, "2026-01-15", codes[0], "revise", "accepted", "中心温度阈值 85℃ 下限明确到子要求"),
        (2, "2026-02-19", codes[1], "revise", "accepted", "冷却温度按工序分别配置上限"),
        (3, "2026-03-18", codes[2], "adjust_param", "blocked", "重量单位一致性无法回放（样本不足）"),
        (4, "2026-04-22", codes[3], "revise", "accepted", "投料量容差从 1% 调整到 2%"),
        (5, "2026-05-20", codes[4], "adjust_behavior", "accepted", "序号连续命中范围收窄"),
        (6, "2026-06-17", codes[5], "revise", "rolled_back", "产品名称规范收窄后误报上升，回滚"),
        (7, "2026-07-15", codes[6], "adjust_param", "blocked", "消毒浓度阈值缺少可执行判据"),
        (8, "2026-08-12", codes[7], "revise", "accepted", "冷藏暂存温度拆分为冷藏/暂存两条"),
        (9, "2026-09-16", codes[8], "new_rule", "pending", "解冻时长达标建议新建规则（待人工发布）"),
        (10, "2026-10-14", codes[9], "revise", "accepted", "半成品工序闭环补充跨文件证据要求"),
        (11, "2026-10-28", codes[10], "adjust_behavior", "rolled_back", "葱姜蒜规格放宽后证据不足，回滚"),
        (12, "2026-11-05", codes[11], "new_rule", "pending", "肉类前处理完整性建议新建规则（待人工发布）"),
        (13, "2026-11-12", "RW20260526004", "revise", "blocked", "实施日期一致缺少可回放样本"),
        (14, "2026-11-18", "RW20260525002", "adjust_behavior", "accepted", "版本号/签名非占位符忽略关键词补充"),
    ]
    made_fb = 0
    made_rsi = 0
    with db.session() as c:
        # 本轮新增演示数据统一落演示专用空间 ws-demo；ws-default 保持门禁干净基线。
        wsid = _DEMO_WS_ID
        # 反馈台账：14 条（覆盖待沉淀/已沉淀/已忽略）
        for k, (rnd, dt, code, action, decision, note) in enumerate(rsi_rounds):
            fid = f"fb-rsi-{k + 1:02d}"
            third = k % 3
            status = "settled" if third == 0 else ("ignored" if third == 1 else "pending")
            _new_fb = not c.execute("SELECT 1 FROM feedback WHERE id=?", (fid,)).fetchone()
            _new_rc = not c.execute("SELECT 1 FROM rsi_candidate WHERE id=?", (f"rc-demo-{k + 1:02d}",)).fetchone()
            c.execute(
                "INSERT OR IGNORE INTO feedback(id,case_id,finding_id,kind,rule_code,title,payload,"
                "actor,created_at,rsi_status,rsi_action,rsi_rule_id,handled_at,handled_by,tenant_id,workspace_id) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                # 反馈/误报样例必须挂演示空间的项目与发现（不能挂 ws-default 基线发现，
                # 否则 decision/feedback 会改变默认空间的规则挖掘输入）。
                (fid, "case-mf-02" if k % 2 else "case-mf-01",
                 "fnd-case-mf-{:02d}-{:03d}".format(2 if k % 2 else 1, (k % 20) + 1),
                 "false_positive" if third == 0 else ("manual" if third == 1 else "confirm"),
                 code, f"第 {rnd} 轮进化：{note}",
                 _json.dumps({"reason": note, "suggestion": "按进化建议修订并回放验证。"}, ensure_ascii=False),
                 "user-reviewer", dt + " 10:00:00", status,
                 action if status == "settled" else "", code if status == "settled" else "",
                 dt + " 12:00:00" if status != "pending" else "",
                 "user-tenant" if status != "pending" else "", "t-default", wsid))
            made_fb += 1 if _new_fb else 0
            # RSI 候选（每轮一条留痕）
            cid = f"rc-demo-{k + 1:02d}"
            before = {"rule_code": code, "enabled": True, "severity": "critical"}
            after = ({"slots": {"metric": "中心温度", "op": ">=", "value": 85, "unit": "℃"}}
                     if decision != "rolled_back" else
                     {"behavior": {"enabled": False, "note": "回滚：误报上升"}})
            c.execute(
                "INSERT OR IGNORE INTO rsi_candidate(id,feedback_id,rule_code,action,before_json,after_json,"
                "decision,note,created_at,decided_at,decided_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (cid, fid, code, action, _json.dumps(before, ensure_ascii=False),
                 _json.dumps(after, ensure_ascii=False), decision,
                 f"第 {rnd} 轮：{note}", dt + " 10:05:00",
                 dt + " 12:05:00" if decision != "pending" else "",
                 "system" if decision in ("accepted", "rolled_back", "blocked") else ""))
            made_rsi += 1 if _new_rc else 0
        # 错误书：把 10 条演示空间发现标记为人工误报（供规则进化 → 错误书展示）。
        # 目标发现必须在 ws-demo 内：decision 表无 workspace 列，若挂 ws-default 基线
        # 发现会改变默认空间的规则挖掘输入（build22 门禁 FAIL 根因之一）。
        for k in range(1, 11):
            fnd = f"fnd-case-mf-01-{k:03d}"
            c.execute("INSERT OR IGNORE INTO decision(id,finding_id,decision,reason,note,user_id,created_at) "
                      "VALUES(?,?,?,?,?,?,?)",
                      (f"dec-demo-{k:02d}", fnd, "false_positive",
                       "人工复核判定为误报：判据过严/作用域过大", "演示数据：错误书样例",
                       "user-reviewer", f"2026-10-{(k % 27) + 1:02d} 16:00:00"))
        # 本体消费开关自动开启/关闭轨迹（12+ 轮，含 auto_on / auto_off）
        rounds = [
            (0, "hold", 0, 0, 0.0, -0.004, 0.004, 0.62, 0.62, "样本不足，继续观察"),
            (0, "observe_negative", 0, 0, -0.002, -0.006, 0.002, 0.61, 0.61, "负向第 1/2 轮"),
            (0, "insufficient_sample", 0, 0, 0.001, -0.003, 0.005, 0.62, 0.62, "带标签样本 <100"),
            (0, "hold", 0, 0, 0.002, -0.002, 0.006, 0.63, 0.63, "未达开关门槛"),
            (0, "auto_on", 0, 1, 0.011, 0.006, 0.016, 0.68, 0.62, "ΔF1 CI 下界 ≥ +0.5pp → 自动开启"),
            (1, "hold", 1, 1, 0.003, -0.001, 0.007, 0.66, 0.63, "开启后首轮观察"),
            (1, "observe_negative", 1, 1, -0.002, -0.005, 0.001, 0.63, 0.64, "负向第 1/2 轮"),
            (1, "auto_off", 1, 0, -0.009, -0.014, -0.004, 0.60, 0.66, "连续 2 轮 CI 上界 < 0 → 自动关闭"),
            (0, "hold", 0, 0, 0.001, -0.003, 0.005, 0.62, 0.62, "关闭后基线观察"),
            (0, "auto_on", 0, 1, 0.013, 0.007, 0.019, 0.69, 0.62, "样本累积后再次自动开启"),
            (1, "observe_negative", 1, 1, -0.001, -0.004, 0.002, 0.64, 0.64, "负向第 1/2 轮"),
            (1, "auto_off", 1, 0, -0.007, -0.012, -0.002, 0.61, 0.65, "连续 2 轮负向 → 自动关闭"),
            (0, "hold", 0, 0, 0.0, -0.004, 0.004, 0.62, 0.62, "继续观察"),
            (0, "hold", 0, 0, 0.002, -0.002, 0.006, 0.63, 0.62, "等待下一次带标签评测"),
        ]
        for rnd, (eb, action, ba, aa, f1, lo, hi, f1on, f1off, reason) in enumerate(rounds, 1):
            c.execute(
                "INSERT OR IGNORE INTO ontology_switch_eval(id,round_no,tenant_id,workspace_id,"
                "enabled_before,enabled_after,action,n,delta_f1,ci_lo,ci_hi,f1_on,f1_off,min_n,"
                "classes_json,detail_json,actor,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (f"oev-demo-{rnd:02d}", rnd, "t-default", wsid, ba, aa, action,
                 320 + rnd * 7, f1, lo, hi, f1on, f1off, 200,
                 _json.dumps({"中心温度": {"n": 120}, "冷却温度": {"n": 90}, "重量单位": {"n": 110}},
                             ensure_ascii=False),
                 _json.dumps({"reason": reason, "source": "auto_eval"}, ensure_ascii=False),
                 "system", "2026-{:02d}-{:02d} 09:00:00".format(
                     1 + (rnd - 1) * 11 // 13, 5 + (rnd * 7) % 19)))
        # 当前开关状态与最后一轮一致（关闭 / auto 模式，来源 auto_eval）
        try:
            row = c.execute("SELECT settings_json FROM workspace WHERE id=?", (wsid,)).fetchone()
            st = {}
            try:
                st = _json.loads((row[0] if row else "") or "{}")
            except Exception:
                st = {}
            st["ontology"] = {"enabled": False, "mode": "auto", "source": "auto_eval",
                              "updated_at": "2026-11-18 09:00:00", "updated_by": "system",
                              "reason": "演示数据：自动开关轨迹终态为关闭（等待下一次带标签评测）"}
            c.execute("UPDATE workspace SET settings_json=? WHERE id=?",
                      (_json.dumps(st, ensure_ascii=False), wsid))
        except Exception:
            pass
        # 规则冲突：原有 5 组 + 追加 12 组（≥15 组，含已裁决/未裁决）
        new_conflicts = [
            ("RW20260525005", "RW20260525009", "numeric_conflict", "中心温度与冷却温度两条规则共用「温度」槽位，阈值方向相反可能同时命中。", "warning", "拆分槽位并明确作用工序", '{"metric":"中心温度","op":">=","value":85}', '{"metric":"冷却温度","op":"<=","value":10}', "open", "", ""),
            ("B-4", "C-3", "scope_conflict", "投料量与总重匹配、序号连续同覆盖配料表，证据位置不同导致重复提示。", "warning", "统一配料表证据范围", '{"scope":"配料表"}', '{"scope":"配料表序号"}', "resolved", "both_valid", "两条规则均保留，明确证据分工"),
            ("RW20260525003", "RW20260525007", "duplicate", "产品名称一致与产品名称规范同源：名称正则与规范词典重复校验。", "warning", "合并为一条名称规范规则", '{"metric":"产品名称"}', '{"metric":"产品名称"}', "resolved", "rule_b", "关闭重复规则，保留名称规范"),
            ("RW20260525012", "B-4", "unit_mismatch", "重量单位一致性与投料量匹配对同一数值分别按 g/kg 与百分比计算。", "critical", "统一重量换算口径为 kg", '{"unit":"g","metric":"净含量"}', '{"unit":"%","metric":"投料量"}', "open", "", ""),
            ("E3", "E4", "priority_conflict", "葱姜蒜规格与肉类前处理完整性同属前处理类，优先级未定义。", "warning", "明确前处理类规则执行顺序", '{"scope":"前处理","priority":"中"}', '{"scope":"肉类前处理","priority":"中"}', "open", "", ""),
            ("RW20260525006", "RW20260525011", "scope_conflict", "消毒浓度与解冻时长在解冻/清洗环节均引用用水记录，证据范围重叠。", "warning", "按工序拆分用水记录证据", '{"scope":"清洗用水"}', '{"scope":"解冻用水"}', "ignored", "ignored", "已确认证据范围不同，忽略该冲突"),
            ("RW20260525002", "RW20260526004", "priority_conflict", "版本号/签名非占位符与实施日期一致对文件头信息校验权重未定。", "warning", "文件头校验按严重度排序", '{"scope":"文件头","priority":"高"}', '{"scope":"实施日期","priority":"中"}', "open", "", ""),
            ("B-2", "E4", "scope_conflict", "半成品工序闭环与肉类前处理完整性对半成品记录的要求不一致。", "warning", "补充半成品记录证据要求", '{"scope":"半成品"}', '{"scope":"肉类前处理"}', "resolved", "rule_a", "以半成品工序闭环为准"),
            ("FOOD01-001", "RW20260525005", "duplicate", "炒制中心温度达标与加热中心温度达标重复映射同一指标。", "warning", "合并为「中心温度达标」单规则", '{"metric":"中心温度"}', '{"metric":"加热中心温度"}', "resolved", "both_wrong", "两条均改为引用统一中心温度规则"),
            ("C05-005", "C09-003", "numeric_conflict", "校准有效期口径冲突：一条按「已过期」一条按「覆盖生产日期」。", "critical", "确认校准有效期判定口径", '{"metric":"校准有效期","op":"<","value":"2026-06-30"}', '{"metric":"校准有效期","op":">=","value":"2026-08-12"}', "open", "", ""),
            ("F04-001", "F05-001", "unit_mismatch", "付款节点一条按工作日、一条按自然日计算。", "warning", "统一按自然日计算", '{"unit":"工作日","metric":"付款期限"}', '{"unit":"自然日","metric":"付款期限"}', "resolved", "rule_b", "以自然日为准并修订工作日规则"),
            ("A01-001", "A02-001", "priority_conflict", "主体名称一致性与经营范围规则优先级未定义。", "warning", "主体名称优先，经营范围作为补充", '{"scope":"主体信息","priority":"高"}', '{"scope":"经营范围","priority":"中"}', "open", "", ""),
        ]
        for k, (a, b, typ, detail, sev, sug, sa, sb, status, resolution, note) in enumerate(new_conflicts, 1):
            c.execute(
                "INSERT OR IGNORE INTO conflict(id,rule_a,rule_b,type,detail,status,created_at,severity,"
                "suggestion,slots_a,slots_b,resolved_at,resolved_by,note,tenant_id,workspace_id,"
                "resolution,resolution_detail) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (f"cf-demo-{k:02d}", a, b, typ, detail, status, db.now(), sev, sug, sa, sb,
                 db.now() if status != "open" else "",
                 "业务管理员" if status != "open" else "",
                 note or ("演示数据：冲突裁决样例" if status != "open" else ""),
                 "t-default", wsid, resolution, note))
        # 冲突检测记录（门禁据此区分「检完无冲突」与「未检测」）
        total_conf = c.execute("SELECT COUNT(*) FROM conflict WHERE tenant_id='t-default'").fetchone()[0]
        c.execute(
            "INSERT OR IGNORE INTO conflict_check(id,scope,rule_id,rule_version_id,status,error,checked_at,"
            "conflicts_found,conflicts_new,detail_json,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            ("cc-demo-01", "full", "", "", "ok", "", db.now(), int(total_conf or 0), int(total_conf or 0),
             _json.dumps({"source": "seed demo"}, ensure_ascii=False), "t-default", wsid))
    return made_fb, made_rsi


def _seed_platform_tenants():
    """平台端演示租户：正式/试用、有效期、首个租户管理员，便于平台首页和消息中心测试。"""
    try:
        from app.services import tenants as _t
        demos = [
            ("华东食品有限公司", "华东食品", "13900001001", "王海", "formal", "2027-12-31"),
            ("星海科技有限公司", "星海科技", "13900001002", "刘敏", "trial", "2026-12-15"),
            ("城投产业园开发有限公司", "城投产业园", "13900001003", "赵强", "formal", "2028-06-30"),
            # 2026-11-21 用户要求「平台运营侧多放演示数据」：补充 4 家租户（正式/试用/临期）
            ("云川软件技术有限公司", "云川软件", "13900001004", "陈立", "formal", "2028-03-31"),
            ("江北建设集团有限公司", "江北建设", "13900001005", "王建国", "formal", "2027-09-30"),
            ("恒昌包装材料有限公司", "恒昌包装", "13900001006", "李秀英", "trial", "2026-11-30"),
            ("远航物流股份有限公司", "远航物流", "13900001007", "张海涛", "trial", "2026-01-31"),
        ]
        made = 0
        with db.session() as c:
            existing = {r[0] for r in c.execute("SELECT name FROM tenant").fetchall()}
        for name, adm, phone, aname, edition, expires in demos:
            if name in existing:
                continue
            r = _t.create_tenant(code="DEMO-" + str(len(existing) + made + 1), name=name, admin_phone=phone,
                                 admin_pwd="Tenant@123456", actor="seed",
                                 edition=edition, expires_at=expires, admin_name=aname)
            if r.get("ok"):
                made += 1
        return made
    except Exception:
        import logging
        logging.getLogger(__name__).debug("platform demo tenants skipped", exc_info=True)
        return 0


def _seed_open_app():
    """开放平台演示应用：内置沙箱回调，便于验证签名/投递/重试。"""
    try:
        from app.services import open as _open
        from app.services import ctx as _ctx
        from app import repositories as _R
        if _R.open_apps.list():
            return 0
        # X3：seed 进程没有 HTTP 请求上下文，`_open.create_app` 取到的 tenant/workspace
        # 是空串，导致“首页开放应用=1、开放平台列表=0”（列表按当前租户过滤）。
        # 显式写入默认租户/空间，与 db.py 迁移的旧数据回填口径一致。
        with _ctx.scoped("t-default", "ws-default"):
            _open.create_app(name="演示 ERP 接入",
                             callback_url="http://127.0.0.1:8765/api/v1/open/sandbox",
                             events="audit.completed,ping")
        return 1
    except Exception:
        return 0


def run():
    db.init_db()
    _assert_roles_consistent()
    _prod = str(os.environ.get("RULEPROOF_ENV") or "").lower() in ("prod", "production")
    _demo = str(os.environ.get("RULEPROOF_SEED_DEMO") or "").lower() in ("1", "true", "yes")
    _admin_pwd = str(os.environ.get("RULEPROOF_ADMIN_PASSWORD") or "").strip()
    if _prod and not _admin_pwd:
        _admin_pwd = secrets.token_urlsafe(18)
    if not _admin_pwd:
        _admin_pwd = "Admin@123456"
    try:
        from app.services import permissions as _perms
        _perms.ensure_seed()
    except Exception:
        pass
    with db.session() as c:
        c.execute("INSERT OR IGNORE INTO org(id,name,region) VALUES('org-1','味源食品（苏州）有限公司','苏州')")
        c.execute("INSERT OR IGNORE INTO plant(id,org_id,name) VALUES('plant-1','org-1','苏州一厂')")
        for code, name in ROLES:
            c.execute("INSERT OR IGNORE INTO role(id,code,name) VALUES(?,?,?)", ("role-" + code, code, name))
        # L92：旧库清理 3 个悬空角色（幂等；新库 no-op）。必须在 ensure_seed 对账后
        # 再清一次，避免 role_permission 残留指向已删角色。
        _legacy_purged = _purge_legacy_roles(c)
        for r in BUILTIN_RULES:
            _rid = "R-" + r["code"]
            c.execute("INSERT OR IGNORE INTO rule(id,code,name,category,rclass,status,source) VALUES(?,?,?,?,?,?,?)",
                      (_rid, r["code"], r["name"], r["category"], r["rclass"], "published", "内置规则"))
            # 内置规则也必须有已发布版本；否则 manifest 会因“无 published 版本”静默跳过，
            # 出现“16 条内置规则但 rule_version 只有客户规则”的空转。
            _rvid = "rv-builtin-" + r["code"]
            c.execute("INSERT OR IGNORE INTO rule_version(id,rule_id,version,slots_json,evidence_json,tests_json,published_at,status,approved_at,approved_by) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (_rvid, _rid, "v1",
                       __import__("json").dumps({"criterion": r.get("condition") or r["name"],
                                                 "condition": r.get("condition") or "",
                                                 "severity": r.get("severity") or "warning"},
                                                ensure_ascii=False),
                       "[]", "{}", __import__("app.db", fromlist=["now"]).now(), "published",
                       __import__("app.db", fromlist=["now"]).now(), "seed"))
            c.execute("UPDATE rule SET current_version_id=? WHERE id=? AND (current_version_id IS NULL OR current_version_id='')",
                      (_rvid, _rid))
        c.execute("INSERT OR IGNORE INTO eval_set(id,name,golden_json) VALUES('es-1','食品工艺书黄金样例','{}')")
        # 系统管理员（首次部署内置账号密码；首次登录强制改密）
        from app import auth
        pwd = _admin_pwd
        h, salt = auth.hash_password(pwd)
        _force_cfg = str(os.environ.get("RULEPROOF_FORCE_PWD_CHANGE", "0")).strip() in ("1", "true", "yes")
        force = _prod or _force_cfg
        _pwd_store = None if _prod else pwd
        c.execute("INSERT OR IGNORE INTO user(id,username,name,email,phone,status,password_hash,salt,must_change_pwd,created_at,portal,initial_password) "
                  "VALUES('user-admin','13800000000','陈志远','admin@local','13800000000','active',?,?,?,?,'admin',?)",
                  (h, salt, 1 if force else 0, __import__("app.db", fromlist=["now"]).now(), _pwd_store))
        c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) SELECT 'user-admin', id FROM role WHERE code='super_admin'")
        # 演示账号只用于开发/测试；prod 默认不创建固定密码账号。
        if _demo or not _prod:
            DEMO_USERS = [
                ("user-reviewer", "13700002222", "王芳", "rev@local", "Rev@123456", "reviewer"),
                ("user-platform", "13600003333", "赵磊", "plat@local", "Plat@123456", "platform_op"),
                ("user-tenant", "13500001111", "周敏", "tenant@local", "Acme@123456", "admin"),
            ]
            for uid, phone, name, email, pw, role in DEMO_USERS:
                h2, s2 = auth.hash_password(pw)
                c.execute("INSERT OR IGNORE INTO user(id,username,name,email,phone,status,password_hash,salt,must_change_pwd,created_at,portal,initial_password) "
                          "VALUES(?,?,?,?,?,'active',?,?,?,?,?,?)",
                          (uid, phone, name, email, phone, h2, s2, 1 if force else 0,
                           __import__("app.db", fromlist=["now"]).now(),
                           {"user-platform": "platform", "user-tenant": "admin"}.get(uid, "reviewer"), pw))
                c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) SELECT ?, id FROM role WHERE code=?", (uid, role))
        if _prod:
            print("系统管理员：手机号 13800000000 / " + pwd + "（首次登录强制改密；该密码只在本行输出，请立即保存）")
        else:
            print(f"系统管理员：手机号 13800000000 / {pwd}（首次登录{'强制' if force else '不强制'}改密）")
        if _demo or not _prod:
            print("演示账号：13700002222/Rev@123456 · 13600003333/Plat@123456 · 13500001111/Acme@123456")
        for _uid, _dept in (("user-admin", "信息技术部"), ("user-platform", "平台运营部"),
                            ("user-tenant", "质量管理部"), ("user-reviewer", "质量审核部")):
            c.execute("UPDATE user SET department=? WHERE id=? AND COALESCE(department,'')=''", (_dept, _uid))
        # 不写死演示消息：消息只能由真实业务事件（审核完成、规则发布、超时、模型异常等）触发。
    # 智能体（示例，含职责/工作流/提示词等 profile）
    import json as _j

    def _agent_profile(desc, group, tags, resp, notresp, modes, inputs, outputs, workflow, prompts, params):
        return {
            "desc": desc, "group": group, "tags": tags,
            "responsibility": resp, "not_responsibility": notresp,
            "run_modes": modes, "inputs": inputs, "outputs": outputs,
            "workflow": workflow, "prompts_list": prompts, "params_list": params,
            "nodes": len(workflow), "params": len(params), "prompts": len(prompts),
            # 与 ensure_agent_assets 的运行时规范对齐，避免重新 seed 时把节点/提示词清空后重复补版本
            "runtime_version": 2,
        }

    # 节点工作流/提示词/参数只认 agent_definitions.AGENT_RUNTIME 一处定义，seed 不再复制一份，
    # 避免历史 bug：seed 写了提示词、ensure_agent_assets 又用旧规范盖掉，出现“有模型节点但没提示词”。
    from app.services.agent_definitions import AGENT_RUNTIME as _AGENT_RUNTIME

    def _wf(aid):
        return [dict(x) for x in ((_AGENT_RUNTIME.get(aid) or {}).get("workflow") or [])]

    def _pl(aid):
        return [dict(x) for x in ((_AGENT_RUNTIME.get(aid) or {}).get("prompts") or [])]

    def _pm(aid):
        return [{"name": n, "v": v, "type": t, "desc": d}
                for n, v, t, d in ((_AGENT_RUNTIME.get(aid) or {}).get("params") or [])]

    AGENTS = [
        ("agent-parse", "文档解析智能体", "parse", "active", _agent_profile(
            "把 PDF / DOCX / 扫描件解析成可审核的文本与事实，保留页码与定位。",
            "解析", ["工作流", "能力", "启用"],
            "识别文件格式并抽取文本、表格与数值事实；扫描件走视觉 OCR；输出带页码锚点。",
            "不做业务判定（不判断合规）；不改写原文；不做图像理解以外的图形/印章识别。",
            [{"k": "触发时机", "v": "上传文件 / 手动运行"}, {"k": "入口", "v": "智能体 → 文档解析 → 运行"},
             {"k": "输出落点", "v": "返回文本 + 事实 + 页数"}, {"k": "依赖", "v": "解析器 + 视觉模型（扫描件）"}],
            ["文件路径（xlsx/docx/pdf）", "是否启用 OCR"],
            ["全文文本", "结构化事实（kind/value/unit/context）", "页数/段落数"],
            _wf("agent-parse"), _pl("agent-parse"), _pm("agent-parse"),
        )),
        ("agent-fact", "事实抽取智能体", "extract", "active", _agent_profile(
            "把工艺文本抽成结构化事实（工序/参数/数值/单位/对象），供规则判定复用。",
            "解析", ["工作流", "能力", "启用"],
            "从自然语言工艺描述中抽取可判定的事实，并用本体别名归一化对象名。",
            "不判断事实是否合规；不对缺失内容做补全；数值必须来自原文。",
            [{"k": "触发时机", "v": "文档解析后 / 手动运行"}, {"k": "入口", "v": "智能体 → 事实抽取 → 运行"},
             {"k": "输出落点", "v": "结构化事实列表"}, {"k": "依赖", "v": "模型 + 本体别名"}],
            ["工艺文本", "本体别名表"],
            ["事实列表（kind / value / unit / object / context）"],
            _wf("agent-fact"), _pl("agent-fact"), _pm("agent-fact"),
        )),
        ("agent-rulegen", "规则生成智能体", "rule", "active", _agent_profile(
            "把自然语言审核要求或企业标准，转成可执行的规则草稿。",
            "规则", ["工作流", "能力", "启用"],
            "识别规则类别（限值/关键字/一致性），填槽位，生成草稿并进入审批流。",
            "不直接发布规则；不编造标准里没有的阈值；生成后必须人工确认。",
            [{"k": "触发时机", "v": "管理员描述要求 / 导入标准"}, {"k": "入口", "v": "智能体 → 规则生成 → 运行"},
             {"k": "输出落点", "v": "规则库（草稿）"}, {"k": "依赖", "v": "模型 + 规则模板"}],
            ["自然语言要求 / 标准文本", "分类提示（可选）"],
            ["规则草稿（code / name / category / slots）"],
            _wf("agent-rulegen"), _pl("agent-rulegen"), _pm("agent-rulegen"),
        )),
        ("agent-conflict", "规则冲突分析智能体", "conflict", "active", _agent_profile(
            "检测规则集之间的冲突（同一参数限值矛盾、作用域重叠），输出冲突三态。",
            "规则", ["工作流", "能力", "启用"],
            "对限值类规则做区间比较，对关键词类规则做互斥检测；冲突落库并可裁决。",
            "不自动修改规则；冲突裁决必须人工确认。",
            [{"k": "触发时机", "v": "规则发布前 / 手动运行"}, {"k": "入口", "v": "智能体 → 冲突分析 → 运行"},
             {"k": "输出落点", "v": "冲突检测页"}, {"k": "依赖", "v": "规则库"}],
            ["规则集（默认取已发布规则）"],
            ["冲突列表（A vs B / 类型 / 说明）", "冲突三态"],
            _wf("agent-conflict"), _pl("agent-conflict"), _pm("agent-conflict"),
        )),
        ("agent-judge", "点位判定智能体", "semantic", "active", _agent_profile(
            "执行审核点位的语义判定：按判据对照原文，输出五态与证据。",
            "审核", ["工作流", "能力", "启用"],
            "对每个点位判断 pass/fail/na/insufficient，给出逐字证据与理由。",
            "不编造证据；证据不足必须如实标注；不因侧重而放宽硬性要求。",
            [{"k": "触发时机", "v": "每次审核的模型点位判定"}, {"k": "入口", "v": "审核链路自动调用"},
             {"k": "输出落点", "v": "findings + 五态"}, {"k": "依赖", "v": "模型 + 点位判据 + 原文"}],
            ["点位判据 / 证据要求 / 文档原文"],
            ["五态结论", "逐字证据", "一句话理由"],
            _wf("agent-judge"), _pl("agent-judge"), _pm("agent-judge"),
        )),
        ("agent-fp", "误报归因智能体", "analyze", "active", _agent_profile(
            "分析错误书里的误报案例，归因并给出规则修订建议（进入 RSI 闭环）。",
            "规则", ["工作流", "能力", "启用"],
            "对每条误报判断归因（判据过严/作用域过大/证据不足/OCR 误读），产出修订建议。",
            "不自动改规则；建议需人工确认后生成草稿；不评价审核员。",
            [{"k": "触发时机", "v": "错误书有新增 / 手动运行"}, {"k": "入口", "v": "智能体 → 误报归因 → 运行"},
             {"k": "输出落点", "v": "规则进化建议 + 可生成草稿"}, {"k": "依赖", "v": "模型 + 错误书数据"}],
            ["错误书条目（规则/问题/理由/证据）"],
            ["归因结论", "修订建议", "可直接生成规则草稿"],
            _wf("agent-fp"), _pl("agent-fp"), _pm("agent-fp"),
        )),
        ("agent-ruleminer", "规则挖掘智能体", "rulemine", "active", _agent_profile(
            "从历史审核发现、复核反馈与重复问题中挖掘候选规则，只产出候选供人工确认。",
            "规则", ["工作流", "规则挖掘", "闭环"],
            "读取重复发现，聚类同类问题，判断规则形式（单条参数规则/决策表组合），产出候选与依据。",
            "不自动发布规则；不把单次偶发问题当规则；不编造企业标准；候选必须人工确认后创建草稿。",
            [{"k": "触发时机", "v": "审核完成后出现重复发现 / 管理员手动运行"},
             {"k": "入口", "v": "规则生成与挖掘 → 规则挖掘；审核落库后自动委托"},
             {"k": "输出落点", "v": "规则候选（不自动落库/发布）"}, {"k": "依赖", "v": "发现/反馈/案例 + 模型（归因可选）"}],
            ["发现/反馈/案例", "规则形式判断", "工作空间规则库"],
            ["重复问题候选", "建议形式（单条/决策表）", "可生成规则草稿的标题与摘要"],
            _wf("agent-ruleminer"), _pl("agent-ruleminer"), _pm("agent-ruleminer"),
        )),
    ]
    with db.session() as ac:
        # ---- 默认模型 / OCR 配置（T-99：真实凭据只从环境变量取，绝不写死在代码里）----
        # 生产（RULEPROOF_ENV=prod）：DB 一律不写明文凭据，运行时由环境变量注入；
        # 演示（显式 RULEPROOF_SEED_DEMO=1）：可把部署方注入的 DEEPSEEK_API_KEY /
        # BAIDU_OCR_BEARER 写入本地演示库 model_config，供当前页面做真实验证；
        # 交付包目录内（platform/dist/...）即使带 demo 标志也禁止写入（见 _seed_live_keys_allowed）。
        from app import config as _cfg
        import os as _os_seed
        _c = _cfg.LLM
        _write_keys = bool(_demo and not _prod and _seed_live_keys_allowed())
        _llm_model = (_c.get("model") or "deepseek-chat").strip() or "deepseek-chat"
        _llm_base = (_c.get("base_url") or "https://api.deepseek.com").strip() or "https://api.deepseek.com"
        _env_llm_key = (_os_seed.environ.get("DEEPSEEK_API_KEY")
                        or _os_seed.environ.get("RULEPROOF_LLM_API_KEY") or "").strip()
        _llm_key = _env_llm_key if _write_keys else ""
        # 状态只表示“凭据就绪待真实测试”，不把“有 Key”写成已连接；真实调用结果由
        # activation test / 页面「测试连接」回写 ok / fail。
        _chat_status = "configured" if (_llm_key or _c.get("api_key") or _env_llm_key) else "unconfigured"
        ac.execute("INSERT OR IGNORE INTO model_config(id,name,provider,model_id,base_url,api_key,"
                   "capabilities,is_default,enabled,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   ("mdl-default", f"{_llm_model}（默认）", "DeepSeek", _llm_model,
                    _llm_base, _llm_key, "chat", 1, 1, _chat_status,
                    __import__("app.db", fromlist=["now"]).now()))
        if _llm_key:
            # 已有演示库：仅补空凭据，不覆盖人工配置
            ac.execute("UPDATE model_config SET api_key=?, status='configured', provider='DeepSeek', "
                       "model_id=?, base_url=?, enabled=1 WHERE id='mdl-default' "
                       "AND (api_key IS NULL OR TRIM(api_key)='')",
                       (_llm_key, _llm_model, _llm_base))
        _bearer = ""
        if _write_keys:
            _bearer = (_os_seed.environ.get("BAIDU_OCR_BEARER")
                       or _os_seed.environ.get("RULEPROOF_BAIDU_OCR_BEARER") or "").strip()
        # 模型预设（未配置 key 也展示，状态 unconfigured；管理员在页面填 key 即生效）
        PRESETS = [
            ("mdl-flash", "DeepSeek 4.1 Flash", "DeepSeek", "deepseek-flash", "https://api.deepseek.com", "chat"),
            ("mdl-ernie", "文心 5.5 Flash", "Baidu Qianfan", "ernie-5.5-flash-preview", "https://qianfan.baidubce.com/v2", "chat"),
            # OCR 主链路：百度智能云 Unlimited-OCR-2（千帆 v2 Bearer 单凭据，或 aip API Key+Secret）
            ("mdl-baidu-ocr", "百度智能云 Unlimited-OCR-2", "百度智能云", "Unlimited-OCR-2",
             "https://qianfan.baidubce.com/v2", "ocr"),
            # 备用通道：PaddleOCR-VL（本轮无凭据 → 保持未配置，不伪造可用）
            ("mdl-paddle-ocr", "PaddleOCR-VL", "PaddlePaddle", "PaddleOCR-VL-1.6",
             "https://paddleocr.aistudio-app.com/api/v2/ocr/jobs", "ocr"),
        ]
        for mid, name, provider, model_id, base, cap in PRESETS:
            _key = _bearer if mid == "mdl-baidu-ocr" else ""
            _status = "configured" if _key else "unconfigured"
            ac.execute("INSERT OR IGNORE INTO model_config(id,name,provider,model_id,base_url,api_key,"
                       "capabilities,is_default,enabled,status,created_at) VALUES(?,?,?,?,?,?,?,0,1,?,?)",
                       (mid, name, provider, model_id, base, _key, cap, _status,
                        __import__("app.db", fromlist=["now"]).now()))
            if _key:
                # 已有演示库：仅补空凭据，不覆盖人工配置
                ac.execute("UPDATE model_config SET api_key=?, status='configured', provider=?, "
                           "model_id=?, base_url=?, enabled=1 WHERE id=? "
                           "AND (api_key IS NULL OR TRIM(api_key)='')",
                           (_key, provider, model_id, base, mid))
        # 旧版本预置的「千帆 DeepSeek-OCR」不是 Unlimited-OCR：未配置密钥的行直接删除，
        # 已配置密钥的行保留但停用并标记旧模型，避免静默改指用户凭据（T-99：不启用旧 OCR）。
        ac.execute("DELETE FROM model_config WHERE "
                   "(id IN ('mdl-ocr','mdl-qianfan-ocr') OR name LIKE '%DeepSeek-OCR%') "
                   "AND COALESCE(model_id,'') NOT LIKE '%Unlimited%' "
                   "AND COALESCE(provider,'') NOT LIKE '%unlimited%' "
                   "AND (api_key IS NULL OR TRIM(api_key)='')")
        ac.execute("UPDATE model_config SET name='千帆 DeepSeek-OCR（旧，建议改用 Unlimited-OCR-2）', "
                   "enabled=0, status='unconfigured' "
                   "WHERE (id IN ('mdl-ocr','mdl-qianfan-ocr') OR name LIKE '%DeepSeek-OCR%') "
                   "AND COALESCE(model_id,'') NOT LIKE '%Unlimited%' "
                   "AND COALESCE(provider,'') NOT LIKE '%unlimited%'")
        # 清理旧的三条审核智能体（用户要求删除）
        ac.execute("DELETE FROM agent_run WHERE agent_version_id IN (SELECT id FROM agent_version WHERE agent_id IN ('agent-1','agent-2','agent-3'))")
        ac.execute("DELETE FROM agent_version WHERE agent_id IN ('agent-1','agent-2','agent-3')")
        ac.execute("DELETE FROM agent WHERE id IN ('agent-1','agent-2','agent-3')")
        for aid, name, typ, status, prof in AGENTS:
            ac.execute("INSERT OR REPLACE INTO agent(id,name,type,status,profile_json) VALUES(?,?,?,?,?)",
                       (aid, name, typ, status, _j.dumps(prof, ensure_ascii=False)))
    # T-199（2026-11-20）：权限点/角色权限包以 app/services/permission_registry.py 为
    # 唯一事实源。上面的早期 ensure_seed 只能灌 permission 行（此时 role 行还没插），
    # 这里在角色写入后再对账一次，保证「seed 一次」即可得到完整 role_permission 缓存，
    # 不再依赖后续服务启动补种（旧实现首次 seed 后 role_permission 为空）。
    try:
        from app.services import permissions as _perms2
        _perm_seed = _perms2.ensure_seed()
        print("权限种子：权限点 %d，角色包 %d 个，清理过期缓存 %d 行"
              % (int(_perm_seed.get("permission_points") or 0),
                 len(_perm_seed.get("roles", [])),
                 int(_perm_seed.get("stale_permission_rows_removed") or 0)))
    except Exception as _perm_err:  # noqa: BLE001 - 权限种子失败不阻断演示启动，但必须可见
        print("权限种子对账失败（不阻断演示启动）:", str(_perm_err)[:200])
    from app.engine import ontology
    n = ontology.seed_to_db()
    try:
        with db.session() as c:
            for lid, key, src, tgt in [
                ("ol-demo-1", "measured_by", "ProcessStep:炒卷心菜", "Metric:中心温度"),
                ("ol-demo-2", "measured_by", "ProcessStep:炒土豆丝", "Metric:中心温度"),
                ("ol-demo-3", "measured_by", "ProcessStep:煎蛋", "Metric:中心温度"),
                ("ol-demo-4", "measured_by", "ProcessStep:热处理番茄沙司", "Metric:中心温度"),
                ("ol-demo-5", "measured_by", "ProcessStep:焯水蔬菜", "Metric:冷却温度"),
            ]:
                c.execute("INSERT OR IGNORE INTO onto_link(id,key,source_id,target_id) VALUES(?,?,?,?)",
                          (lid, key, src, tgt))
    except Exception:
        pass
    # 演示数据（演示租户/项目/复杂案例/开放平台演示应用）只允许进入开发/演示环境：
    # RULEPROOF_ENV=prod 默认不写任何演示数据（P1-01：禁止固定口令 Tenant@123456 的
    # 演示租户管理员、开发示例项目与开放平台应用进入生产库）；显式演示需同时设
    # RULEPROOF_SEED_DEMO=1。
    if _demo or not _prod:
        # 2026-11-21（build22 门禁修正）：演示专用空间 ws-demo 先建；本轮新增演示数据
        # （P0 多文件复杂案例 / P1 四角色账号与项目量 / P2 本体·规则进化·冲突提醒）
        # 全部写 ws-demo，ws-default 保持干净基线。
        #
        # 写入顺序有意为之：演示数据**先**写、内置基线数据（food/business/complex）**后**写。
        # 规则挖掘 collect_groups 默认只取「最近 1000 条 finding」（rowid DESC）再按空间过滤，
        # 若演示数据最后写，会挤掉 ws-default 的全部基线 finding → 候选数变 0（build22 FAIL 根因）。
        _demo_ws_created = _ensure_demo_workspace()
        _complex2 = _seed_multi_file_complex_cases()
        _users = _seed_role_accounts()
        _members = _seed_demo_workspace_members()
        _rev = _seed_reviewer_projects()
        _arc = _seed_archive_projects()
        _onto, _onto_alias = _seed_ontology_demo()
        _fill = _seed_fill_ongoing_docs()
        _rsi_fb, _rsi = _seed_rsi_conflicts_demo()
        _ten = _seed_platform_tenants()
        _opn = _seed_open_app()
        # ws-default 的干净基线（f346c40 之前就存在的内置演示数据）最后写。
        _hist = _seed_food_history()
        _biz = _seed_business_demo()
        _complex = _seed_complex_cases()
    else:
        _hist = _biz = _complex = _complex2 = _users = _rev = _arc = _onto = 0
        _onto_alias = _rsi_fb = _rsi = _fill = 0
        _ten = _opn = 0
        print("生产模式：跳过演示租户/演示用户/演示项目/复杂案例/开放平台演示应用"
              "（如需演示数据：RULEPROOF_SEED_DEMO=1 后重新 seed）")
    try:
        from app.services import sysconfig as _sc
        with db.session() as _c0:
            _existing = {r[0] for r in _c0.execute("SELECT key FROM sys_config").fetchall()}
        _defaults = {
            "usage.monthly_budget": "1000", "usage.alert_pct": "80",
            "usage.input_price": "0.5", "usage.output_price": "1.5",
            "usage.currency": "CNY", "usage.hard_stop": "0"}
        _sc.set_many({k: v for k, v in _defaults.items() if k not in _existing})
    except Exception:
        pass
    if _demo or not _prod:
        print(f"seed done（{'演示' if _demo else '开发'}模式）：{len(ROLES)} 角色，"
              f"{len(BUILTIN_RULES)} 内置规则，{n} 本体实体，{_hist} 个食品历史项目，"
              f"{_biz} 个跨类型业务项目，{_complex} 个多文件复杂案例，"
              f"{_complex2} 个多文件复杂案例（V2：Word+Excel+PDF 混排），"
              f"{_users} 个四角色演示账号，{_rev} 个审核员在办项目，{_arc} 个历史归档项目，"
              f"{_onto} 个本体实例 / {_onto_alias} 个别名，{_fill} 个在办项目补齐第 2 份附件，"
              f"{_rsi_fb} 条 RSI 反馈/{_rsi} 轮 RSI 留痕，"
              f"{_ten} 个平台演示租户，{_opn} 个开放平台演示应用；"
              f"新增演示数据落演示空间 {_DEMO_WS_ID}（{'新建' if _demo_ws_created else '已存在'}），"
              f"ws-default 保持干净基线")
    else:
        print(f"seed done（生产模式，无演示数据）：{len(ROLES)} 角色，"
              f"{len(BUILTIN_RULES)} 内置规则，{n} 本体实体；演示项目/租户/开放应用=0")


def _apply_migrations():
    """建库/重建库后自动补数据迁移（热路径索引、平台升级表等）。

    2026-11-20（工程化四域核查）：迁移此前只靠 `rp db migrate` 手工执行，
    新库会缺 16 个热路径索引（/api/v1/projects 等接口在真实库上慢）。
    这里在 seed 完成后幂等应用（CREATE INDEX IF NOT EXISTS），失败不阻断演示启动但会打印原因。

    L109（2026-11-25）：``auto_only=True`` —— fresh init 只应用 auto=True 的迁移
    （热路径索引/升级历史/审计 append-only 触发器）；``auto=False`` 的 feature-lazy
    运行期 schema（direct_claim*/evolution_accuracy_round 等）不自动建，保持 fresh
    与产品库 104 表同构，由运行期 ensure 兜底或显式 ``rp db migrate`` 安装。
    """
    try:
        from app import data_migrations as _dm
        # apply() 强制先备份（backup_required），seed 场景备份到临时目录，避免污染 data/
        import tempfile as _tf
        r = _dm.apply(backup=True, backup_dir=_tf.mkdtemp(prefix="seed_migrate_bak_"),
                      auto_only=True)
        applied = [a["id"] for a in (r.get("applied") or [])]
        if applied:
            print(f"数据迁移: 已应用 {len(applied)} 项 {applied}")
        else:
            print("数据迁移: 无待应用（已是最新）")
        if r.get("deferred"):
            print(f"数据迁移: 延迟（feature-lazy，显式 rp db migrate 安装）"
                  f" {r['deferred']}")
    except Exception as _e:  # noqa: BLE001 - 迁移失败不阻断 seed，但必须可见
        print("数据迁移失败（不阻断演示启动）:", str(_e)[:200])


if __name__ == "__main__":
    run()
    _apply_migrations()


# 智能体资产自愈（幂等）：重建库后自动补提示词/参数/版本
try:
    from app.services import agents as _agents
    print("智能体资产:", _agents.ensure_agent_assets())
except Exception as _e:
    print("智能体资产补齐失败:", _e)
