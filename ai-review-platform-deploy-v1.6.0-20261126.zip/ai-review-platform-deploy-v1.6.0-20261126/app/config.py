"""应用配置（单一事实源）。支持 .env 文件 + 环境变量覆盖。"""
import os


def _load_dotenv():
    """从平台根目录 .env 读取 KEY=VALUE（不覆盖已存在的环境变量）。"""
    env_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    if not os.path.exists(env_file):
        return
    with open(env_file, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())


_load_dotenv()

# 平台根目录（config.py 位于 app/）：默认数据库与相对路径的锚点，不依赖启动 CWD。
PLATFORM_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_DB_PATH = os.path.join(PLATFORM_ROOT, "data", "ruleproof.db")


def _env(name, default):
    """读取环境变量；空串/纯空白一律视为“未设置”，回退默认值（X1）。

    `.env.example` 里的 `RULEPROOF_DB=` 等留空项经 `_load_dotenv` 写入环境变量后，
    旧实现会把空串当成显式配置（`Path("")` → sqlite3 unable to open database file）。
    这里统一按“未设置”处理，避免空模板覆盖安全默认值。
    """
    v = os.environ.get(name)
    v = v.strip() if isinstance(v, str) else ""
    return v if v else default


# 监听地址：默认 127.0.0.1（本地/单机安全默认）；容器化部署由
# Dockerfile/docker-compose 显式传 RULEPROOF_HOST=0.0.0.0（或 server --host）。
HOST = _env("RULEPROOF_HOST", "127.0.0.1")
PORT = int(_env("RULEPROOF_PORT", "8765"))
# 默认库固定在平台根 data/ruleproof.db（与 app/db.py 的 DB_PATH 默认一致）；
# 显式设置 RULEPROOF_DB（含相对路径）时仍以显式值为准。
DB_PATH = _env("RULEPROOF_DB", DEFAULT_DB_PATH)

GOLDEN = _env("RULEPROOF_GOLDEN", "")  # 样例文件路径由部署方通过环境变量提供
STANDARDS_DIR = _env("RULEPROOF_STANDARDS", "")

APP_NAME = "AI 审核平台"
def _read_version() -> str:
    import os
    v = os.environ.get("RULEPROOF_VERSION")
    if v:
        return v.strip()
    try:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return open(os.path.join(here, "VERSION"), encoding="utf-8").read().strip() or "1.1.0"
    except Exception:
        return "1.1.0"


APP_VERSION = _read_version()

LLM = {
    "enabled": _env("RULEPROOF_LLM_ENABLED", "") == "1",
    "base_url": _env("RULEPROOF_LLM_BASE_URL", ""),
    "api_key": _env("RULEPROOF_LLM_API_KEY", ""),
    "model": _env("RULEPROOF_LLM_MODEL", ""),
    "timeout_seconds": 20,
    "max_tokens": 512,
}

# 扫描件 OCR：外部命令（读 PDF 输出文本到 stdout），如 paddleocr 包装脚本；空 = 未配置。
OCR_CMD = _env("RULEPROOF_OCR_CMD", "")

# 告警阈值：规则 override 率超过该值触发告警；命中为 0 也告警（从未命中）。
ALERT_OVERRIDE_THRESHOLD = float(_env("RULEPROOF_ALERT_OVERRIDE", "0.5"))

# 通用文件审核点库 JSON（可随时替换升级；空 = 使用内置最小集）
AUDIT_POINTS = _env("RULEPROOF_AUDIT_POINTS", "")
# 正式「文件审核库」目录（含 审核点库.json / 文件类型与路由.json / 审核提示词.jsonl）
AUDIT_LIBRARY = _env("RULEPROOF_AUDIT_LIBRARY", "")

# LibreOffice Kit（DOCX → PDF 导出）
LO_NODE = _env("RULEPROOF_LO_NODE", "")  # 可选：LibreOffice Kit 的 node，不配置则 PDF 导出不可用
LO_CLI = _env("RULEPROOF_LO_CLI", "")  # 可选：LibreOffice Kit CLI

# ---------------------------------------------------------------- 数据边界（P1-8）
# 部署方默认值；管理端 sys_config（data.policy.*）与这些环境变量同为「显式配置」，
# DB 优先。全部留空 = 未配置，必须由交付方显式提示客户补全，不得静默默认。
DATA_REGION = _env("RULEPROOF_DATA_REGION", "")  # 数据处理/存储所在地，如 cn、cn-shanghai、customer-dc
DATA_EXTERNAL_MODEL = _env("RULEPROOF_ALLOW_EXTERNAL_MODEL", "")  # allow/deny；空 = 未声明
DATA_DELETION_CONTACT = _env("RULEPROOF_DATA_DELETION_CONTACT", "")  # 数据删除/导出申请联系人
DATA_POLICY_NOTE = _env("RULEPROOF_DATA_POLICY_NOTE", "")  # 交付方补充说明（合同口径等）

# 留存天数（"" = 未配置；0 = 不自动删除/永久保留，需合同确认）
RETENTION = {
    "cases_days": _env("RULEPROOF_RETENTION_CASES_DAYS", ""),      # 审核项目 + 上传原文件
    "logs_days": _env("RULEPROOF_RETENTION_LOG_DAYS", ""),         # 审计日志
    "cache_days": _env("RULEPROOF_RETENTION_CACHE_DAYS", ""),      # llm_cache 判定缓存
    "reports_days": _env("RULEPROOF_RETENTION_REPORT_DAYS", ""),   # 报告
}

