"""L93 核心单据模型 · DB 字段修复（发现/报告/规则/运行/关联/孤儿监控）。

本模块只依赖标准库 + 传入的 ``sqlite3.Connection``，不 import ``app.*``：
- ``app/db.py`` 的 ``init_db`` 在幂等迁移后调用 :func:`refresh_health`；
- ``app/data_migrations.py`` 的 CLI 调用 :func:`backfill_plan` / :func:`backfill_apply`
  与 :func:`health_snapshot`（dry-run/显式 apply，产品库路径由 CLI 层拒绝）；
- QA 直接以只读连接调用 :func:`health_snapshot` / :func:`rule_mapping_audit`。

口径（与 L90 审计、L93 修复报告一致）：

1. **finding 来源四要素**：``created_by/created_at/source/source_kind``
   + 权威关联 ``rule_version_id/manifest_result_id``。
   - 新写入由 ``FindingRepo.insert``（主链）+ ``finding`` AFTER INSERT 触发器（
     覆盖 semantic_core/seed 等直 SQL 路径）补全；
   - 历史回填**只从可证明的事实派生**，不伪造：
     ``created_at/created_by`` ← ``audit_run``（人工 finding 走 ``audit_log`` 的
     ``finding.manual_added`` 事件），``rule_version_id`` ← (规则码→唯一规则 + 唯一版本行)
     或「规则码 + 版本」精确命中，``manifest_result_id`` ←
     ``run.manifest_id + manifest_result(rule_code, object_id)`` 唯一命中；
     任何多义/缺失一律留空并计入 skipped 原因。
2. **报告签发**：``report.status/signed_by/signed_at/content_hash``；
   生成写生成人/生成时间/内容 hash，签发写签发人/时间（同一事务 + 审计）。
3. **规则发布人**：``rule.created_by`` + ``rule_version.published_by``；历史空值只报告。
4. **关联/孤儿**：``audit_run.manifest_id`` 新写点 + 反向 ``audit_manifest.run_id``
   可证回填；finding 物理删除由 DB 触发器写 ``reference_orphan_alert``（不改历史行）；
   历史孤儿只统计报告（``orphan_report``）。
5. **重复规则码**：只监控（``rule_code_duplicates``），不加唯一约束破坏历史。

``docmodel_health_report`` 是幂等刷新的监控快照表（沿用 L92
``state_legacy_report`` 的口径：只重算监控表，不改任何业务行）。
"""
from __future__ import annotations

import logging

import json
import sqlite3
import time
import uuid

LANE = "L93"
BACKFILL_VERSION = "l93_docmodel_backfill_v1"
MIGRATION_ID = "20261124_003_docmodel_fields"
MIGRATION_NAME = "L93 单据模型字段（发现来源/报告签发/规则发布人/运行清单关联）"

# 健康报表关注的列（表 -> [(列, 说明)]）。缺表/缺列自动跳过（老库/未迁移库）。
EMPTY_RATE_COLUMNS = {
    "finding": [
        ("created_by", "发现创建人"),
        ("created_at", "发现创建时间"),
        ("source", "发现来源路径"),
        ("source_kind", "发现来源分类"),
        ("rule_version_id", "权威规则版本行"),
        ("manifest_result_id", "清单结果关联"),
        ("run_id", "审核运行关联"),
    ],
    "rule": [
        ("created_by", "规则创建人"),
        ("created_at", "规则创建时间"),
    ],
    "rule_version": [
        ("published_by", "规则版本发布人"),
        ("published_at", "规则版本发布时间"),
        ("approved_by", "规则版本审批人"),
    ],
    "audit_run": [
        ("manifest_id", "执行清单关联"),
        ("created_by", "运行创建人"),
        ("created_at", "运行创建时间"),
    ],
    "report": [
        ("created_by", "报告生成人"),
        ("created_at", "报告生成时间"),
        ("signed_by", "报告签发人"),
        ("signed_at", "报告签发时间"),
        ("content_hash", "报告内容 hash"),
        ("exported_by", "报告导出人"),
        ("exported_hash", "导出内容 hash"),
    ],
}

# finding.engine -> (source, source_kind)。只做显式映射，未知 engine 不猜。
ENGINE_SOURCE_MAP = {
    "manual": ("manual_review", "manual"),
    "manual_history": ("seed_manual", "import"),
    "deterministic": ("legacy_engine", "run"),
    "demo_complex": ("seed_demo", "import"),
    "demo_project_doc": ("seed_demo", "import"),
    "demo_extra": ("seed_demo", "import"),
}

MANUAL_AUDIT_ACTIONS = ("finding.manual_added", "finding.created")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _new_id(prefix: str) -> str:
    return prefix + uuid.uuid4().hex[:12]


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        return bool(conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (table,)).fetchone())
    except sqlite3.Error:
        return False


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {str(r[1]) for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}
    except sqlite3.Error:
        return set()


def _scalar(conn: sqlite3.Connection, sql: str, params=(), default=0):
    try:
        row = conn.execute(sql, params).fetchone()
        return default if row is None or row[0] is None else row[0]
    except sqlite3.Error:
        return default


def _rows(conn: sqlite3.Connection, sql: str, params=()) -> list:
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    except sqlite3.Error:
        return []


def _rate(empty: int, total: int):
    if total <= 0:
        return None
    return round(float(empty) / float(total), 6)


# ---------------------------------------------------------------------------
# 1) 健康快照 / 空值率报表
# ---------------------------------------------------------------------------

def _column_metric(conn, table: str, column: str, label: str) -> dict | None:
    if not _table_exists(conn, table) or column not in _columns(conn, table):
        return None
    total = int(_scalar(conn, f'SELECT COUNT(*) FROM "{table}"'))
    empty = int(_scalar(
        conn, f'SELECT COUNT(*) FROM "{table}" WHERE COALESCE("{column}",\'\')=\'\''))
    return {"table": table, "column": column, "metric": "empty_rate",
            "label": label, "total": total, "empty": empty,
            "empty_rate": _rate(empty, total)}


def health_snapshot(conn: sqlite3.Connection) -> dict:
    """只读体检：字段空值率 + 关联可解析率 + 重复/孤儿 + 0 行事实。"""
    out = {"lane": LANE, "generated_at": _now(),
           "empty_rates": [], "rows": [],
           "findings": {}, "rules": {}, "rule_versions": {},
           "reports": {}, "audit_runs": {}, "associations": {}, "orphans": {},
           "rule_code_duplicates": {}}

    # ---- 1. 逐列空值率（不存在的表/列显式记入 missing_columns）----
    missing = []
    for table, cols in EMPTY_RATE_COLUMNS.items():
        if not _table_exists(conn, table):
            missing.append({"table": table, "column": "*", "reason": "table_missing"})
            continue
        have = _columns(conn, table)
        for column, label in cols:
            if column not in have:
                missing.append({"table": table, "column": column, "reason": "column_missing"})
                continue
            m = _column_metric(conn, table, column, label)
            if m:
                out["empty_rates"].append(m)
                out["rows"].append({"table_name": table, "column_name": column,
                                    "metric": m["metric"], "total_rows": m["total"],
                                    "empty_rows": m["empty"],
                                    "empty_rate": m["empty_rate"], "detail": label})
    out["missing_columns"] = missing

    # ---- 2. finding 来源完整率 / 解析率 / 来源分布 ----
    fcols = _columns(conn, "finding")
    f_total = int(_scalar(conn, "SELECT COUNT(*) FROM finding"))
    out["findings"]["total"] = f_total
    if {"created_by", "created_at", "source", "source_kind"} <= fcols:
        complete = int(_scalar(
            conn,
            "SELECT COUNT(*) FROM finding WHERE COALESCE(created_by,'')<>'' "
            "AND COALESCE(created_at,'')<>'' AND COALESCE(source,'')<>'' "
            "AND COALESCE(source_kind,'')<>''"))
        out["findings"]["provenance_four_complete"] = complete
        out["findings"]["provenance_four_empty"] = f_total - complete
        out["rows"].append({"table_name": "finding", "column_name": "*",
                            "metric": "provenance_four_complete",
                            "total_rows": f_total, "empty_rows": f_total - complete,
                            "empty_rate": _rate(f_total - complete, f_total),
                            "detail": "created_by+created_at+source+source_kind 四要素齐全"})
        out["findings"]["by_source_kind"] = {
            str(r["source_kind"] or ""): int(r["n"]) for r in _rows(
                conn, "SELECT source_kind, COUNT(*) n FROM finding GROUP BY source_kind")}
        out["findings"]["by_source"] = {
            str(r["source"] or ""): int(r["n"]) for r in _rows(
                conn, "SELECT source, COUNT(*) n FROM finding GROUP BY source")}
    if "rule_version_id" in fcols:
        rv_ok = int(_scalar(conn, "SELECT COUNT(*) FROM finding "
                                  "WHERE COALESCE(rule_version_id,'')<>''"))
        out["findings"]["rule_version_id_resolved"] = rv_ok
        out["findings"]["rule_version_id_unresolved"] = f_total - rv_ok
        out["rows"].append({"table_name": "finding", "column_name": "rule_version_id",
                            "metric": "resolved", "total_rows": f_total,
                            "empty_rows": f_total - rv_ok,
                            "empty_rate": _rate(f_total - rv_ok, f_total),
                            "detail": "finding→rule_version 可解析（权威版本行）"})
    if "manifest_result_id" in fcols:
        mr_ok = int(_scalar(conn, "SELECT COUNT(*) FROM finding "
                                  "WHERE COALESCE(manifest_result_id,'')<>''"))
        out["findings"]["manifest_result_id_resolved"] = mr_ok
        out["findings"]["manifest_result_id_unresolved"] = f_total - mr_ok
        out["rows"].append({"table_name": "finding", "column_name": "manifest_result_id",
                            "metric": "resolved", "total_rows": f_total,
                            "empty_rows": f_total - mr_ok,
                            "empty_rate": _rate(f_total - mr_ok, f_total),
                            "detail": "finding→manifest_result 可解析"})
    if "run_id" in fcols:
        run_ok = int(_scalar(
            conn, "SELECT COUNT(*) FROM finding f JOIN audit_run r ON r.id=f.run_id"))
        out["findings"]["run_resolved"] = run_ok
        out["findings"]["run_dangling"] = f_total - run_ok
        out["rows"].append({"table_name": "finding", "column_name": "run_id",
                            "metric": "fk_resolved", "total_rows": f_total,
                            "empty_rows": f_total - run_ok,
                            "empty_rate": _rate(f_total - run_ok, f_total),
                            "detail": "finding.run_id → audit_run 可解析"})

    # ---- 3. rule / rule_version ----
    rule_total = int(_scalar(conn, "SELECT COUNT(*) FROM rule"))
    out["rules"]["total"] = rule_total
    rv_total = int(_scalar(conn, "SELECT COUNT(*) FROM rule_version"))
    published = int(_scalar(conn, "SELECT COUNT(*) FROM rule_version WHERE status='published'"))
    out["rule_versions"].update({"total": rv_total, "published": published})
    if "published_by" in _columns(conn, "rule_version"):
        pub_empty = int(_scalar(
            conn, "SELECT COUNT(*) FROM rule_version WHERE status='published' "
                  "AND COALESCE(published_by,'')=''"))
        out["rule_versions"]["published_by_empty"] = pub_empty
        out["rule_versions"]["published_by_empty_rate"] = _rate(pub_empty, published)
        out["rows"].append({"table_name": "rule_version", "column_name": "published_by",
                            "metric": "published_missing_publisher",
                            "total_rows": published, "empty_rows": pub_empty,
                            "empty_rate": _rate(pub_empty, published),
                            "detail": "已发布版本缺发布人（历史空值只报告，不伪造）"})
    if "published_at" in _columns(conn, "rule_version"):
        pubat_empty = int(_scalar(
            conn, "SELECT COUNT(*) FROM rule_version WHERE status='published' "
                  "AND COALESCE(published_at,'')=''"))
        out["rule_versions"]["published_at_empty"] = pubat_empty
        out["rows"].append({"table_name": "rule_version", "column_name": "published_at",
                            "metric": "published_missing_time",
                            "total_rows": published, "empty_rows": pubat_empty,
                            "empty_rate": _rate(pubat_empty, published),
                            "detail": "已发布版本缺发布时间"})
    # 规则码重复：只监控，绝不加唯一约束破坏历史
    if rule_total and "code" in _columns(conn, "rule"):
        dups = _rows(conn, "SELECT code, COUNT(*) n FROM rule GROUP BY code "
                           "HAVING COUNT(*)>1 ORDER BY n DESC, code")
        groups = len(dups)
        dup_rows = sum(int(r["n"]) for r in dups)
        out["rule_code_duplicates"] = {
            "groups": groups, "rows": dup_rows,
            "examples": [{"code": r["code"], "count": int(r["n"])} for r in dups[:10]]}
        out["rows"].append({"table_name": "rule", "column_name": "code",
                            "metric": "duplicate_groups", "total_rows": rule_total,
                            "empty_rows": groups,
                            "empty_rate": _rate(groups, rule_total),
                            "detail": "重复规则码分组数（不强制唯一，只监控）"})

    # ---- 4. report：0 行必须显式暴露，不得伪装成“签发字段齐全” ----
    rep_total = int(_scalar(conn, "SELECT COUNT(*) FROM report")) \
        if _table_exists(conn, "report") else 0
    out["reports"]["total"] = rep_total
    out["reports"]["signing_columns_present"] = (
        _table_exists(conn, "report")
        and {"signed_by", "signed_at", "content_hash"} <= _columns(conn, "report"))
    if rep_total == 0:
        out["reports"]["note"] = "0 行报告：签发字段/内容 hash 无数据级样本（不当作 100% 齐全）"
        out["rows"].append({"table_name": "report", "column_name": "*",
                            "metric": "row_count", "total_rows": 0, "empty_rows": 0,
                            "empty_rate": None, "detail": "0 行报告（签发模型仅代码级验证）"})
    else:
        rcols = _columns(conn, "report")
        if {"signed_by", "signed_at"} <= rcols:
            signed = int(_scalar(
                conn, "SELECT COUNT(*) FROM report WHERE COALESCE(signed_by,'')<>'' "
                      "AND COALESCE(signed_at,'')<>''"))
            out["reports"]["signed"] = signed
            out["reports"]["unsigned"] = rep_total - signed
            out["rows"].append({"table_name": "report", "column_name": "signed_by",
                                "metric": "unsigned_rows", "total_rows": rep_total,
                                "empty_rows": rep_total - signed,
                                "empty_rate": _rate(rep_total - signed, rep_total),
                                "detail": "报告未签发行数"})

    # ---- 5. audit_run.manifest_id ----
    if _table_exists(conn, "audit_run"):
        run_total = int(_scalar(conn, "SELECT COUNT(*) FROM audit_run"))
        run_manifest = int(_scalar(
            conn, "SELECT COUNT(*) FROM audit_run WHERE COALESCE(manifest_id,'')<>''"))
        out["audit_runs"] = {"total": run_total, "with_manifest": run_manifest,
                             "without_manifest": run_total - run_manifest,
                             "with_manifest_rate": _rate(run_manifest, run_total)}
        if "manifest_id" in _columns(conn, "audit_run"):
            run_dangling = 0
            if _table_exists(conn, "audit_manifest"):
                run_dangling = int(_scalar(
                    conn, "SELECT COUNT(*) FROM audit_run r WHERE "
                          "COALESCE(r.manifest_id,'')<>'' AND NOT EXISTS "
                          "(SELECT 1 FROM audit_manifest m WHERE m.id=r.manifest_id)"))
            out["audit_runs"]["manifest_dangling"] = run_dangling
            out["rows"].append({"table_name": "audit_run", "column_name": "manifest_id",
                                "metric": "missing_manifest", "total_rows": run_total,
                                "empty_rows": run_total - run_manifest,
                                "empty_rate": _rate(run_total - run_manifest, run_total),
                                "detail": "运行未绑定执行清单（历史 94/95 断链）"})
    if _table_exists(conn, "audit_manifest"):
        man_total = int(_scalar(conn, "SELECT COUNT(*) FROM audit_manifest"))
        man_run = int(_scalar(
            conn, "SELECT COUNT(*) FROM audit_manifest WHERE COALESCE(run_id,'')<>''"))
        out["associations"]["manifests"] = {"total": man_total,
                                            "with_run_id": man_run}

    # ---- 6. 规则码映射审计（finding→rule：pk / code / ambiguous / unresolved）----
    out["associations"]["finding_to_rule"] = rule_mapping_audit(conn)

    # ---- 7. 孤儿（历史只统计，不修改）----
    out["orphans"] = orphan_report(conn)
    for kind, info in out["orphans"].items():
        if not isinstance(info, dict):
            continue
        if int(info.get("orphan") or 0) or int(info.get("dangling") or 0):
            out["rows"].append({"table_name": kind, "column_name": "*",
                                "metric": "orphan_rows", "total_rows": int(info.get("total") or 0),
                                "empty_rows": int(info.get("orphan") or info.get("dangling") or 0),
                                "empty_rate": _rate(int(info.get("orphan")
                                                        or info.get("dangling") or 0),
                                                    int(info.get("total") or 0)),
                                "detail": info.get("note") or "悬挂引用"})
    return out


def refresh_health(conn: sqlite3.Connection) -> dict:
    """幂等刷新 ``docmodel_health_report`` 监控快照表（只写监控表，不改业务行）。"""
    snap = health_snapshot(conn)
    if not _table_exists(conn, "docmodel_health_report"):
        return {"ok": False, "reason": "docmodel_health_report_missing",
                "rows": len(snap["rows"])}
    stamp = snap["generated_at"]
    conn.execute("DELETE FROM docmodel_health_report")
    n = 0
    for r in snap["rows"]:
        tid = f'{r["table_name"]}:{r["column_name"]}:{r["metric"]}'
        conn.execute(
            "INSERT OR REPLACE INTO docmodel_health_report"
            "(id,table_name,column_name,metric,total_rows,empty_rows,empty_rate,"
            "detail,detected_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (tid, r["table_name"], r["column_name"], r["metric"],
             int(r["total_rows"] or 0), int(r["empty_rows"] or 0), r["empty_rate"],
             str(r["detail"] or ""), stamp))
        n += 1
    # 额外落地：finding 来源分布、规则码重复分组（监控用，key 稳定可复算）
    try:
        for sk, cnt in (snap["findings"].get("by_source_kind") or {}).items():
            tid = f"finding:source_kind={sk}:count"
            conn.execute(
                "INSERT OR REPLACE INTO docmodel_health_report"
                "(id,table_name,column_name,metric,total_rows,empty_rows,empty_rate,"
                "detail,detected_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (tid, "finding", "source_kind", "distribution", int(cnt), 0, None,
                 sk or "(空)", stamp))
            n += 1
        dups = snap.get("rule_code_duplicates") or {}
        conn.execute(
            "INSERT OR REPLACE INTO docmodel_health_report"
            "(id,table_name,column_name,metric,total_rows,empty_rows,empty_rate,"
            "detail,detected_at) VALUES(?,?,?,?,?,?,?,?,?)",
            ("rule:code:duplicate_groups", "rule", "code", "duplicate_groups",
             int(dups.get("rows") or 0), int(dups.get("groups") or 0), None,
             json.dumps(dups.get("examples") or [], ensure_ascii=False)[:400], stamp))
        n += 1
    except sqlite3.Error:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    return {"ok": True, "rows": n, "detected_at": stamp}


# ---------------------------------------------------------------------------
# 2) finding→rule 映射审计 / 孤儿报表（只读，不改历史）
# ---------------------------------------------------------------------------

def rule_mapping_audit(conn: sqlite3.Connection) -> dict:
    if not _table_exists(conn, "finding") or not _table_exists(conn, "rule"):
        return {"available": False}
    rules = _rows(conn, "SELECT id, code, status FROM rule")
    by_id = {str(r["id"]): r for r in rules}
    by_code: dict[str, list] = {}
    for r in rules:
        by_code.setdefault(str(r["code"] or ""), []).append(r)
    dup_groups = {k: v for k, v in by_code.items() if len(v) > 1}
    out = {"total": 0, "resolved_by_pk": 0, "resolved_by_code_unique": 0,
           "ambiguous_code": 0, "unresolved": 0,
           "resolved_rate": 0.0, "rule_code_duplicate_groups": len(dup_groups),
           "examples_unresolved": [], "examples_ambiguous": []}
    try:
        frows = conn.execute("SELECT id, rule_id FROM finding").fetchall()
    except sqlite3.Error:
        return {"available": False}
    for f in frows:
        rid = str(f[1] or "")
        out["total"] += 1
        if rid in by_id:
            out["resolved_by_pk"] += 1
        elif len(by_code.get(rid) or []) == 1:
            out["resolved_by_code_unique"] += 1
        elif len(by_code.get(rid) or []) > 1:
            out["ambiguous_code"] += 1
            if len(out["examples_ambiguous"]) < 5:
                out["examples_ambiguous"].append(str(f[0]))
        else:
            out["unresolved"] += 1
            if len(out["examples_unresolved"]) < 5:
                out["examples_unresolved"].append(str(f[0]))
    resolved = out["resolved_by_pk"] + out["resolved_by_code_unique"]
    out["resolved"] = resolved
    out["resolved_rate"] = _rate(out["total"] - resolved, out["total"])
    return out


def orphan_report(conn: sqlite3.Connection) -> dict:
    """关联孤儿体检（只读）。finding 物理删除的**新增**引用由触发器写告警表。"""
    out = {"reference_orphan_alert": {"total": 0, "note": "新增删除告警（DB 触发器）"},
           "audit_log_object_unresolved": {"total": 0}}
    checks = [
        ("feedback", "finding_id", "finding", "feedback→finding 悬挂（历史只报告）"),
        ("decision", "finding_id", "finding", "decision→finding 悬挂"),
        ("evolution_task", "finding_id", "finding", "evolution_task→finding 悬挂"),
        ("finding_certificate", "finding_id", "finding", "证书→finding 悬挂"),
        ("evidence", "finding_id", "finding", "evidence→finding 悬挂"),
        ("rule_version", "rule_id", "rule", "版本→规则 悬挂"),
        ("manifest_result", "manifest_id", "audit_manifest", "清单结果→清单 悬挂"),
        ("audit_run", "case_id", "audit_case", "运行→项目 悬挂"),
        ("audit_case", "id", "audit_case", "（占位，不检测）"),
    ]
    for table, col, ref_table, note in checks[:-1]:
        if not (_table_exists(conn, table) and _table_exists(conn, ref_table)):
            continue
        if col not in _columns(conn, table):
            continue
        if col == "id":
            continue
        total = int(_scalar(conn, f'SELECT COUNT(*) FROM "{table}"'))
        empty = int(_scalar(
            conn, f'SELECT COUNT(*) FROM "{table}" WHERE COALESCE("{col}",\'\')=\'\''))
        orphan = int(_scalar(
            conn, f'SELECT COUNT(*) FROM "{table}" t WHERE COALESCE(t."{col}",\'\')<>\'\' '
                  f'AND NOT EXISTS (SELECT 1 FROM "{ref_table}" r '
                  f'WHERE r.id=t."{col}")'))
        out[table if col != "case_id" else "audit_run_case"] = {
            "total": total, "empty": empty, "orphan": orphan, "note": note}
    if _table_exists(conn, "reference_orphan_alert"):
        rows = _rows(conn, "SELECT ref_table, COUNT(*) n FROM reference_orphan_alert "
                           "GROUP BY ref_table")
        out["reference_orphan_alert"] = {
            "total": int(_scalar(conn, "SELECT COUNT(*) FROM reference_orphan_alert")),
            "by_table": {str(r["ref_table"]): int(r["n"]) for r in rows},
            "note": "finding 物理删除触发的新增悬挂引用告警（历史孤儿不在此表）"}
    return out


# ---------------------------------------------------------------------------
# 3) 历史回填：只从可证明事实派生，dry-run 默认，幂等
# ---------------------------------------------------------------------------

def _engine_source(engine: str) -> tuple[str, str]:
    e = str(engine or "")
    if e.startswith("manifest"):
        return "manifest_exec", "run"
    if e.startswith("semantic_core"):
        return "semantic_core", "run"
    return ENGINE_SOURCE_MAP.get(e, ("", ""))


def engine_source(engine: str) -> tuple[str, str]:
    """finding.engine → (source, source_kind) 的显式映射（未知 engine 返回空对）。"""
    return _engine_source(engine)


def _find_rule(rule_ref: str, by_id: dict, by_code: dict) -> tuple[dict | None, str]:
    """返回 (rule, reason)。多义/缺失返回 None + 原因。"""
    ref = str(rule_ref or "")
    if not ref:
        return None, "rule_ref_empty"
    if ref in by_id:
        return by_id[ref], "rule_pk"
    cands = by_code.get(ref) or []
    if len(cands) == 1:
        return cands[0], "rule_code_unique"
    if len(cands) > 1:
        return None, "rule_code_ambiguous"
    return None, "rule_not_found"


def _resolve_rule_version(conn, finding: dict, rule: dict | None) -> tuple[str, str]:
    if not rule:
        return "", "rule_not_found"
    rv = _rows(conn, "SELECT id,version FROM rule_version WHERE rule_id=?", (rule["id"],))
    if not rv:
        return "", "rule_version_none"
    version = str(finding.get("rule_version") or "")
    exact = [r for r in rv if str(r["version"] or "") == version]
    if len(exact) == 1:
        return str(exact[0]["id"]), "rule_version_exact"
    if len(rv) == 1:
        return str(rv[0]["id"]), "rule_single_version"
    return "", "rule_version_ambiguous"


def _resolve_manifest_result(conn, finding: dict, run: dict | None) -> tuple[str, str]:
    mid = str((run or {}).get("manifest_id") or "")
    if not mid:
        return "", "run_without_manifest"
    if not _table_exists(conn, "manifest_result"):
        return "", "manifest_result_table_missing"
    code = str(finding.get("rule_id") or "")
    obj = str(finding.get("object_id") or "")
    try:
        rows = conn.execute(
            "SELECT id FROM manifest_result WHERE manifest_id=? AND rule_code=? "
            "AND COALESCE(object_id,'')=?", (mid, code, obj)).fetchall()
    except sqlite3.Error:
        return "", "manifest_result_query_failed"
    if len(rows) == 1:
        return str(rows[0][0]), "manifest_result_unique"
    if len(rows) > 1:
        return "", "manifest_result_ambiguous"
    return "", "manifest_result_not_found"


def _manual_audit(conn, finding_id: str) -> dict | None:
    if not _table_exists(conn, "audit_log"):
        return None
    _ph = ",".join("?" * len(MANUAL_AUDIT_ACTIONS))
    try:
        row = conn.execute(
            f"SELECT actor, created_at FROM audit_log WHERE object=? AND action IN ({_ph}) "
            "ORDER BY COALESCE(created_at,'') DESC LIMIT 1",
            (finding_id, *MANUAL_AUDIT_ACTIONS)).fetchone()
    except sqlite3.Error:
        return None
    return dict(row) if row else None


def backfill_plan(conn: sqlite3.Connection, limit: int = 0) -> dict:
    """生成历史回填计划（只读）。返回 items + 各列可填/跳过原因统计。"""
    plan = {"version": BACKFILL_VERSION, "mode": "dry-run",
            "findings_total": 0, "items": [], "columns": {},
            "skipped_reasons": {}, "unresolvable": {},
            "run_manifest": {"total": 0, "fillable": 0},
            "manifest_run": {"total": 0, "fillable": 0}}
    if not _table_exists(conn, "finding"):
        plan["error"] = "finding_table_missing"
        return plan
    fcols = _columns(conn, "finding")
    need = {"created_by", "created_at", "source", "source_kind",
            "rule_version_id", "manifest_result_id"}
    missing = sorted(need - fcols)
    if missing:
        plan["error"] = "finding_columns_missing:" + ",".join(missing)

    rules = _rows(conn, "SELECT id, code FROM rule") if _table_exists(conn, "rule") else []
    by_id = {str(r["id"]): r for r in rules}
    by_code: dict[str, list] = {}
    for r in rules:
        by_code.setdefault(str(r["code"] or ""), []).append(r)
    runs = {}
    if _table_exists(conn, "audit_run"):
        for r in _rows(conn, "SELECT id,created_at,created_by,manifest_id FROM audit_run"):
            runs[str(r["id"])] = r

    rows = conn.execute("SELECT * FROM finding ORDER BY rowid").fetchall()
    plan["findings_total"] = len(rows)
    cols = {c: {"fillable": 0, "already": 0, "unresolved": 0} for c in (
        "created_by", "created_at", "source", "source_kind",
        "rule_version_id", "manifest_result_id")}
    skipped: dict[str, int] = {}
    unresolvable: dict[str, int] = {}

    def _skip(col: str, reason: str):
        skipped[f"{col}:{reason}"] = skipped.get(f"{col}:{reason}", 0) + 1

    for raw in rows:
        f = dict(raw)
        fid = str(f.get("id") or "")
        engine = str(f.get("engine") or "")
        run = runs.get(str(f.get("run_id") or ""))
        changes: dict[str, str] = {}
        basis: dict[str, str] = {}

        # created_at / created_by：真实人工 finding 用审计事件（finding.manual_added），
        # 其余（含 seed 的 manual_history/demo_*）用所属运行——运行是它们被写入的上下文。
        manual = engine == "manual"
        audit = _manual_audit(conn, fid) if manual and _table_exists(conn, "audit_log") else None
        if not str(f.get("created_at") or "").strip():
            if manual:
                if audit and str(audit.get("created_at") or ""):
                    changes["created_at"] = str(audit["created_at"])
                    basis["created_at"] = "audit_log.finding.manual_added"
                else:
                    _skip("created_at", "manual_without_audit")
            elif run and str(run.get("created_at") or ""):
                changes["created_at"] = str(run["created_at"])
                basis["created_at"] = "audit_run.created_at"
            else:
                _skip("created_at", "run_not_resolvable")
        else:
            cols["created_at"]["already"] += 1
        if not str(f.get("created_by") or "").strip():
            if manual:
                if audit and str(audit.get("actor") or ""):
                    changes["created_by"] = str(audit["actor"])
                    basis["created_by"] = "audit_log.actor"
                else:
                    _skip("created_by", "manual_without_audit")
            elif run and str(run.get("created_by") or ""):
                changes["created_by"] = str(run["created_by"])
                basis["created_by"] = "audit_run.created_by"
            else:
                _skip("created_by", "run_not_resolvable")
        else:
            cols["created_by"]["already"] += 1

        # source / source_kind：engine 显式映射（不猜）
        src, kind = _engine_source(engine)
        if not str(f.get("source") or "").strip():
            if src:
                changes["source"] = src
                basis["source"] = "engine_map"
            else:
                _skip("source", "engine_unknown")
        else:
            cols["source"]["already"] += 1
        if not str(f.get("source_kind") or "").strip():
            if kind:
                changes["source_kind"] = kind
                basis["source_kind"] = "engine_map"
            else:
                _skip("source_kind", "engine_unknown")
        else:
            cols["source_kind"]["already"] += 1

        # rule_version_id
        if not str(f.get("rule_version_id") or "").strip():
            rule, why = _find_rule(str(f.get("rule_id") or ""), by_id, by_code)
            rvid, why2 = _resolve_rule_version(conn, f, rule)
            if rvid:
                changes["rule_version_id"] = rvid
                basis["rule_version_id"] = f"{why}+{why2}"
            else:
                _skip("rule_version_id", why2)
                unresolvable[why2] = unresolvable.get(why2, 0) + 1
        else:
            cols["rule_version_id"]["already"] += 1

        # manifest_result_id
        if not str(f.get("manifest_result_id") or "").strip():
            mrid, why3 = _resolve_manifest_result(conn, f, run)
            if mrid:
                changes["manifest_result_id"] = mrid
                basis["manifest_result_id"] = why3
            else:
                _skip("manifest_result_id", why3)
                unresolvable[why3] = unresolvable.get(why3, 0) + 1
        else:
            cols["manifest_result_id"]["already"] += 1

        if changes:
            for col in changes:
                cols[col]["fillable"] += 1
            plan["items"].append({"id": fid, "fields": changes, "basis": basis,
                                  "case_id": str(f.get("case_id") or "")})
            if limit and len(plan["items"]) >= int(limit):
                break
    for col in cols:
        cols[col]["unresolved"] = sum(v for k, v in skipped.items() if k.startswith(col + ":"))
    plan["columns"] = cols
    plan["skipped_reasons"] = skipped
    plan["unresolvable"] = unresolvable
    plan["fillable_rows"] = len(plan["items"])
    # 运行→清单：空 manifest_id 的运行可证回填（audit_manifest.run_id=run.id）
    if _table_exists(conn, "audit_run") and _table_exists(conn, "audit_manifest"):
        run_total = int(_scalar(conn, "SELECT COUNT(*) FROM audit_run"))
        run_empty = int(_scalar(
            conn, "SELECT COUNT(*) FROM audit_run WHERE COALESCE(manifest_id,'')=''"))
        run_items = []
        for r in _rows(conn, "SELECT id FROM audit_run WHERE COALESCE(manifest_id,'')=''"):
            hit = _rows(conn, "SELECT id FROM audit_manifest WHERE run_id=?", (r["id"],))
            if len(hit) == 1:
                run_items.append({"run_id": r["id"], "manifest_id": hit[0]["id"],
                                  "basis": "audit_manifest.run_id"})
        plan["run_manifest"] = {"total": run_total, "empty": run_empty,
                               "fillable": len(run_items), "items": run_items[:200]}
        man_items = []
        for m in _rows(conn, "SELECT id FROM audit_manifest WHERE COALESCE(run_id,'')=''"):
            hit = _rows(conn, "SELECT id FROM audit_run WHERE manifest_id=?", (m["id"],))
            if len(hit) == 1:
                man_items.append({"manifest_id": m["id"], "run_id": hit[0]["id"],
                                  "basis": "audit_run.manifest_id"})
        plan["manifest_run"] = {"total": int(_scalar(
            conn, "SELECT COUNT(*) FROM audit_manifest")), "fillable": len(man_items),
            "items": man_items[:200]}
    return plan


def _insert_audit(conn, actor: str, action: str, object_: str,
                  before: dict, after: dict) -> None:
    try:
        conn.execute(
            "INSERT INTO audit_log(id,actor,action,object,before_json,after_json,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (_new_id("aud-"), actor or "system", action, object_,
             json.dumps(before, ensure_ascii=False, sort_keys=True)[:2000],
             json.dumps(after, ensure_ascii=False, sort_keys=True)[:2000], _now()))
    except sqlite3.Error:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)


def backfill_apply(conn: sqlite3.Connection, plan: dict | None = None, *,
                   actor: str = "cli", dry_run: bool = False,
                   limit: int = 0) -> dict:
    """按计划回填（单事务；只填空列；每 finding 一条审计；写 data_backfill_log）。"""
    plan = plan or backfill_plan(conn, limit=limit)
    out = {"version": BACKFILL_VERSION, "mode": "dry-run" if dry_run else "apply",
           "findings_total": plan.get("findings_total", 0),
           "fillable_rows": plan.get("fillable_rows", 0),
           "columns": plan.get("columns") or {},
           "skipped_reasons": plan.get("skipped_reasons") or {},
           "applied": 0, "audit_rows": 0, "run_manifest_applied": 0,
           "manifest_run_applied": 0, "idempotent": False,
           "batch_id": "", "health": None}
    if dry_run:
        return out
    if plan.get("error"):
        out["error"] = plan["error"]
        return out
    fid_cols = {"created_by", "created_at", "source", "source_kind",
                "rule_version_id", "manifest_result_id"}
    batch_id = _new_id("bkl93-")
    out["batch_id"] = batch_id
    conn.execute("BEGIN IMMEDIATE")
    try:
        for item in plan.get("items") or []:
            fid = item.get("id")
            applied_fields: dict[str, str] = {}
            for col, val in (item.get("fields") or {}).items():
                if col not in fid_cols:
                    continue
                cur = conn.execute(
                    f'UPDATE finding SET "{col}"=? WHERE id=? AND '
                    f'COALESCE("{col}",\'\')=\'\'', (val, fid))
                if cur.rowcount == 1:
                    applied_fields[col] = val
            if applied_fields:
                out["applied"] += 1
                _insert_audit(conn, actor, "finding.provenance_backfilled", str(fid),
                              {}, {"filled": applied_fields,
                                   "basis": item.get("basis") or {},
                                   "batch_id": batch_id})
                out["audit_rows"] += 1
        for item in (plan.get("run_manifest") or {}).get("items") or []:
            cur = conn.execute(
                "UPDATE audit_run SET manifest_id=? WHERE id=? AND "
                "COALESCE(manifest_id,'')=''", (item["manifest_id"], item["run_id"]))
            if cur.rowcount == 1:
                out["run_manifest_applied"] += 1
                _insert_audit(conn, actor, "audit_run.manifest_linked", str(item["run_id"]),
                              {}, {"manifest_id": item["manifest_id"],
                                   "basis": item.get("basis")})
        for item in (plan.get("manifest_run") or {}).get("items") or []:
            cur = conn.execute(
                "UPDATE audit_manifest SET run_id=? WHERE id=? AND "
                "COALESCE(run_id,'')=''", (item["run_id"], item["manifest_id"]))
            if cur.rowcount == 1:
                out["manifest_run_applied"] += 1
                _insert_audit(conn, actor, "audit_manifest.run_linked",
                              str(item["manifest_id"]),
                              {}, {"run_id": item["run_id"],
                                   "basis": item.get("basis")})
        out["idempotent"] = not (out["applied"] or out["run_manifest_applied"]
                                 or out["manifest_run_applied"])
        # data_migrations 记录：迁移版本 + 回填批次（幂等 OR IGNORE）
        try:
            import hashlib
            conn.execute(
                "CREATE TABLE IF NOT EXISTS schema_migration("
                "version TEXT PRIMARY KEY, name TEXT DEFAULT '', "
                "checksum TEXT DEFAULT '', applied_at TEXT DEFAULT '')")
            conn.execute(
                "INSERT OR IGNORE INTO schema_migration(version,name,checksum,applied_at) "
                "VALUES(?,?,?,?)",
                (MIGRATION_ID, MIGRATION_NAME,
                 hashlib.sha256(MIGRATION_ID.encode()).hexdigest(), _now()))
        except sqlite3.Error:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
        _record_backfill_log(conn, batch_id, out, plan, actor)
        # 刷新监控快照（只写监控表）
        try:
            out["health"] = refresh_health(conn)
        except sqlite3.Error as exc:
            out["health"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return out


def _record_backfill_log(conn, batch_id: str, out: dict, plan: dict,
                         actor: str) -> None:
    if not _table_exists(conn, "data_backfill_log"):
        return
    stamp = _now()
    try:
        conn.execute(
            "INSERT INTO data_backfill_log(id,batch_id,lane,mode,table_name,column_name,"
            "candidate_rows,filled_rows,skipped_rows,detail_json,actor,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (_new_id("dbk-"), batch_id, LANE, out.get("mode") or "",
             "finding", "*", int(out.get("fillable_rows") or 0),
             int(out.get("applied") or 0),
             int(plan.get("findings_total") or 0) - int(out.get("applied") or 0),
             json.dumps({"columns": out.get("columns") or {},
                         "skipped_reasons": out.get("skipped_reasons") or {},
                         "run_manifest_applied": out.get("run_manifest_applied", 0),
                         "manifest_run_applied": out.get("manifest_run_applied", 0)},
                        ensure_ascii=False)[:4000],
             actor or "cli", stamp))
        for col in ("created_by", "created_at", "source", "source_kind",
                    "rule_version_id", "manifest_result_id"):
            stat = (out.get("columns") or {}).get(col) or {}
            if not stat.get("fillable"):
                continue
            conn.execute(
                "INSERT INTO data_backfill_log(id,batch_id,lane,mode,table_name,"
                "column_name,candidate_rows,filled_rows,skipped_rows,detail_json,"
                "actor,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (_new_id("dbk-"), batch_id, LANE, out.get("mode") or "",
                 "finding", col, int(stat.get("fillable") or 0),
                 int(stat.get("fillable") or 0), int(stat.get("unresolved") or 0),
                 json.dumps({"already": stat.get("already", 0)}, ensure_ascii=False),
                 actor or "cli", stamp))
    except sqlite3.Error:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)


def backfill(conn: sqlite3.Connection, *, dry_run: bool = True, actor: str = "cli",
             limit: int = 0) -> dict:
    """dry-run / apply 统一入口（供 data_migrations CLI 与 QA 复用）。"""
    plan = backfill_plan(conn, limit=limit)
    if dry_run:
        h = health_snapshot(conn)
        return {"ok": not bool(plan.get("error")), "mode": "dry-run",
                "version": BACKFILL_VERSION, "plan": plan,
                "health": {"findings": h.get("findings"),
                           "rules": h.get("rules"),
                           "rule_versions": h.get("rule_versions"),
                           "reports": h.get("reports"),
                           "audit_runs": h.get("audit_runs")}}
    out = backfill_apply(conn, plan, actor=actor, dry_run=False)
    out["ok"] = not bool(out.get("error"))
    return out


