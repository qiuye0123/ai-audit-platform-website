"""
数据层：SQLite 连接、全量 schema、迁移、事务上下文。

全量系统架构：所有核心实体（组织/工厂/部门/用户/角色/模板/规则/版本/文档/锚点/
审核Case/Finding/证据/决策/报告/Agent/版本/运行/评测集/评测运行/审计/冲突）都落库。
"""
import logging
import os
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

HERE = Path(__file__).resolve().parent
# 默认库固定在平台根 data/ruleproof.db；空/纯空白 RULEPROOF_DB 视为“未设置”（X1：
# 复制 .env.example 后的 `RULEPROOF_DB=` 不得把库路径变成空串/当前目录）。
# 注意：与 app/config.py 的 DEFAULT_DB_PATH 保持同一默认，不要只改一处。
DEFAULT_DB_PATH = HERE.parent / "data" / "ruleproof.db"
_RAW_DB_PATH = (os.environ.get("RULEPROOF_DB") or "").strip()
DB_PATH = Path(_RAW_DB_PATH) if _RAW_DB_PATH else DEFAULT_DB_PATH

# ===========================================================================
# L109（2026-11-25）：DB schema 单一事实源收口（L105 D3 商业阻塞）
#
# 修复前 schema 定义分散在 3 处，导致 fresh install ≠ 产品库、`--schema-drift` 长期
# drift=28：① app/db.py 静态 SCHEMA（98 表）；② migrations/*.sql 历史 SQL（001 的
# 25 表 / 002 的运行期表，未进 schema_migration catalog）；③ 7 个服务的运行期 DDL
# （rsi_guard/direct_draft/evolution/conflict/pstates/password_reset/manifest_exec）。
#
# 本 lane 起的**唯一事实源**口径：
#   1) 基线对象（新库/产品库都必须存在）→ 本文件 SCHEMA / init_db 幂等 DDL；
#      `department/template/template_field` 等产品库存量历史空表纳入 init_db，
#      保证 fresh init = 产品库表集合（均为零引用只读死表，DROP 属独立迁移批次）。
#   2) 迁移基础设施（schema_migration / platform_upgrade / 热路径索引）→
#      app/data_migrations.py 的迁移目录唯一定义；init_db 调用
#      ``data_migrations.ensure_infra_schema()`` 幂等安装（同一份目录，不复制 DDL）。
#   3) 运行期按需对象（feature-lazy）→ 本文件 RUNTIME_EXTENSION_* 常量唯一定义，
#      服务层 ensure_*() 一律调用 ``ensure_runtime_schema/ensure_runtime_columns``
#      （保留运行期兜底）；同时登记进迁移目录（auto=False：fresh init 不自动建，
#      显式 ``rp db migrate``/data_migrations apply 全量安装）。
#   4) 审计 append-only 触发器（AUDIT_APPEND_ONLY_SQL）只经迁移安装：产品库不在本
#      lane 自动应用（launch/升级时显式迁移），避免测试/报告写产品库。
#
# 迁移/测试入口：scripts/qa/l109_db_source_test.py、schema_drift_test.py（baseline）。
# ===========================================================================

# 历史遗留只读表（产品库存量存在、业务代码零引用：docs/CURRENT/25-未接线功能台账）。
# 纳入 init_db 使 fresh install 与产品库同构（L109 D3）；保留空表基线，不删数据。
L109_LEGACY_SCHEMA = (
    """CREATE TABLE IF NOT EXISTS department (
  id TEXT PRIMARY KEY, plant_id TEXT, name TEXT NOT NULL,
  FOREIGN KEY(plant_id) REFERENCES plant(id)
)""",
    """CREATE TABLE IF NOT EXISTS template (
  id TEXT PRIMARY KEY, code TEXT, name TEXT, doc_type TEXT,
  version TEXT, status TEXT DEFAULT 'draft', schema_json TEXT, created_at TEXT
)""",
    """CREATE TABLE IF NOT EXISTS template_field (
  id TEXT PRIMARY KEY, template_id TEXT, key TEXT, label TEXT, type TEXT,
  unit TEXT, source TEXT, consumed_by TEXT,
  FOREIGN KEY(template_id) REFERENCES template(id)
)""",
)

# 冲突检测状态表（T-164 / 评审 C-4）：原先 db.py SCHEMA 与 app/services/conflict.py
# 各有一份 DDL；L109 起只保留本常量，SCHEMA 与运行期 ensure 共用（单一事实源）。
CONFLICT_CHECK_SCHEMA = (
    """CREATE TABLE IF NOT EXISTS conflict_check (
  id TEXT PRIMARY KEY,
  scope TEXT DEFAULT 'full',            -- 'full' | 'publish' | 'rule_version'
  rule_id TEXT DEFAULT '',
  rule_version_id TEXT DEFAULT '',
  status TEXT DEFAULT 'ok',             -- 'running' | 'ok' | 'failed' | 'partial'
  error TEXT DEFAULT '',
  checked_at TEXT,
  conflicts_found INTEGER DEFAULT 0,
  conflicts_new INTEGER DEFAULT 0,
  detail_json TEXT DEFAULT '{}',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT ''
)""",
    """CREATE INDEX IF NOT EXISTS idx_conflict_check_ws
  ON conflict_check(tenant_id, workspace_id, checked_at)""",
    """CREATE INDEX IF NOT EXISTS idx_conflict_check_scope
  ON conflict_check(scope, status)""",
)

# 进化效果指标表（T-177 自进化度量）：SCHEMA 与 evolution.py 运行期 ensure 共用
# 同一常量（单一事实源；evolution_effect_test.py 交叉核对）。
EVOLUTION_EFFECT_SCHEMA = (
    """CREATE TABLE IF NOT EXISTS evolution_effect (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  subject_id TEXT DEFAULT '',
  cycle_time_s REAL,
  igain REAL,
  recurrence INTEGER DEFAULT 0,
  rollback_count INTEGER DEFAULT 0,
  adoption_rate REAL,
  created_at TEXT,
  payload_json TEXT DEFAULT '{}'
)""",
    """CREATE INDEX IF NOT EXISTS idx_evo_effect_subject
  ON evolution_effect(kind, subject_id, created_at)""",
)

# 运行期按需 schema（feature-lazy）：表/索引 DDL 的**唯一定义**。
# 服务层 ensure_*() 通过 ensure_runtime_schema() 建（老库/测试夹具兜底）；
# data_migrations 的 lazy 迁移条目引用同一份常量（fresh init 不自动建，保持与
# 产品库 104 表同构；显式 apply 时全量安装）。
RUNTIME_EXTENSION_SCHEMA = {
    # 进化效果指标（init_db 已建；运行期 ensure 兜底）
    "evolution_effect": EVOLUTION_EFFECT_SCHEMA,
    # RSI 影子池（app/services/rsi_guard.py 原运行期 DDL；产品库已有该表）
    "rsi_shadow": (
        """CREATE TABLE IF NOT EXISTS rsi_shadow(
  id TEXT PRIMARY KEY, rule_code TEXT, candidate_id TEXT, status TEXT,
  samples INTEGER DEFAULT 0, correct INTEGER DEFAULT 0, started_at TEXT,
  published_at TEXT, tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
  decided_at TEXT DEFAULT '', decision_note TEXT DEFAULT '')""",
    ),
    # 冲突检测状态（init_db 已建；运行期 ensure 兜底老库/最小夹具库）
    "conflict_check": CONFLICT_CHECK_SCHEMA,
    # 跨轮 claim 去重（P1-7 Phase3，2026-11-21）：状态簿记 + 追加式 occurrence
    "direct_claim": (
        """CREATE TABLE IF NOT EXISTS direct_claim (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  claim_key TEXT NOT NULL,
  rule_code TEXT DEFAULT '',
  quote TEXT DEFAULT '',
  quote_norm TEXT DEFAULT '',
  issue_type TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  zone TEXT DEFAULT '',
  shadow_item_id TEXT DEFAULT '',
  first_direct_item_id TEXT DEFAULT '',
  first_draft_id TEXT DEFAULT '',
  first_run_id TEXT DEFAULT '',
  first_document_id TEXT DEFAULT '',
  last_direct_item_id TEXT DEFAULT '',
  last_draft_id TEXT DEFAULT '',
  last_run_id TEXT DEFAULT '',
  last_document_id TEXT DEFAULT '',
  times_seen INTEGER DEFAULT 0,
  times_seen_rounds INTEGER DEFAULT 0,
  first_seen_at TEXT DEFAULT '',
  last_seen_at TEXT DEFAULT '',
  updated_at TEXT DEFAULT '',
  UNIQUE(case_id, claim_key)
)""",
        """CREATE INDEX IF NOT EXISTS idx_direct_claim_case ON direct_claim(case_id)""",
        """CREATE INDEX IF NOT EXISTS idx_direct_claim_status ON direct_claim(case_id, status)""",
        """CREATE TABLE IF NOT EXISTS direct_claim_occurrence (
  id TEXT PRIMARY KEY,
  claim_id TEXT NOT NULL,
  claim_key TEXT DEFAULT '',
  case_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  draft_id TEXT DEFAULT '',
  document_id TEXT DEFAULT '',
  direct_item_id TEXT DEFAULT '',
  is_new_claim INTEGER DEFAULT 0,
  zone TEXT DEFAULT '',
  shadow_item_id TEXT DEFAULT '',
  transition TEXT DEFAULT '',
  created_at TEXT DEFAULT ''
)""",
        """CREATE INDEX IF NOT EXISTS idx_direct_claim_occ_case
  ON direct_claim_occurrence(case_id)""",
        """CREATE INDEX IF NOT EXISTS idx_direct_claim_occ_claim
  ON direct_claim_occurrence(claim_id)""",
    ),
    # 直连发现每次运行的指标（L11 成本/时延）
    "direct_discovery_metrics": (
        """CREATE TABLE IF NOT EXISTS direct_discovery_metrics (
  id TEXT PRIMARY KEY,
  run_id TEXT DEFAULT '',
  case_id TEXT NOT NULL,
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  trigger TEXT DEFAULT '',
  documents INTEGER DEFAULT 0,
  direct_calls INTEGER DEFAULT 0,
  rules INTEGER DEFAULT 0,
  new_direct_items INTEGER DEFAULT 0,
  duplicate_claims INTEGER DEFAULT 0,
  latency_ms INTEGER DEFAULT 0,
  latency_llm_sum_ms INTEGER DEFAULT 0,
  tokens_in INTEGER DEFAULT 0,
  tokens_out INTEGER DEFAULT 0,
  per_doc_json TEXT DEFAULT '[]',
  ok INTEGER DEFAULT 1,
  errors_json TEXT DEFAULT '[]',
  raw_root TEXT DEFAULT '',
  created_at TEXT DEFAULT ''
)""",
        """CREATE INDEX IF NOT EXISTS idx_dd_metrics_case ON direct_discovery_metrics(case_id)""",
        """CREATE INDEX IF NOT EXISTS idx_dd_metrics_run ON direct_discovery_metrics(run_id)""",
        """CREATE INDEX IF NOT EXISTS idx_dd_metrics_created ON direct_discovery_metrics(created_at)""",
    ),
    # 空间准确率看板（T-177）：轮次 + 唯一键（P1-9 幂等写入）
    "evolution_accuracy_round": (
        """CREATE TABLE IF NOT EXISTS evolution_accuracy_round (
  id TEXT PRIMARY KEY,
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
  round_no INTEGER DEFAULT 0,
  label TEXT DEFAULT '', source TEXT DEFAULT '',
  docs_json TEXT DEFAULT '[]', n_docs INTEGER DEFAULT 0,
  rule_count INTEGER DEFAULT 0, rules_added_json TEXT DEFAULT '[]',
  metrics_json TEXT DEFAULT '{}', delta_json TEXT DEFAULT '{}',
  method_json TEXT DEFAULT '{}', notes TEXT DEFAULT '',
  created_at TEXT, created_by TEXT DEFAULT ''
)""",
        """CREATE INDEX IF NOT EXISTS idx_acc_round_ws
  ON evolution_accuracy_round(tenant_id, workspace_id, round_no)""",
    ),
    # 点位五态落库失败标记表（P1-8：台账不完整不得静默）
    "point_state_write_failure": (
        """CREATE TABLE IF NOT EXISTS point_state_write_failure (
  batch_id TEXT PRIMARY KEY,
  case_id TEXT DEFAULT '',
  failed_json TEXT NOT NULL DEFAULT '[]',
  failed_count INTEGER DEFAULT 0,
  total INTEGER DEFAULT 0,
  source TEXT DEFAULT '',
  created_at TEXT DEFAULT ''
)""",
    ),
}

# 运行期按需列（老库/最小夹具库兜底）：表 → ((列, DDL), ...)。只加列，不改数据。
RUNTIME_EXTENSION_COLUMNS = {
    # rsi_guard.py：影子记录租户/空间 + 转正结论（老库 rsi_shadow 仅 8 列）
    "rsi_shadow": (("tenant_id", "TEXT DEFAULT ''"),
                   ("workspace_id", "TEXT DEFAULT ''"),
                   ("decided_at", "TEXT DEFAULT ''"),
                   ("decision_note", "TEXT DEFAULT ''")),
    # direct_draft.py：claim 幂等键列（可复算，不含 run_id）
    "direct_item": (("claim_key", "TEXT DEFAULT ''"),
                    ("document_id", "TEXT DEFAULT ''")),
    # evolution.py：RSI 候选预注册不可变快照列
    "rsi_candidate": (("prereg_sha256", "TEXT DEFAULT ''"),
                      ("prereg_ref", "TEXT DEFAULT ''"),
                      ("prereg_at", "TEXT DEFAULT ''"),
                      ("prereg_by", "TEXT DEFAULT ''")),
    # manifest_exec.py：D5 逐点五态落盘字段（fail_closed/quote_ok 等；
    # 后 4 列为 L78 多实例 cap 可观测字段，老库兜底也在此统一）
    "point_state": (("case_id", "TEXT DEFAULT ''"),
                    ("source", "TEXT DEFAULT ''"),
                    ("raw_state", "TEXT DEFAULT ''"),
                    ("fail_closed", "INTEGER DEFAULT 0"),
                    ("quote_ok", "INTEGER DEFAULT -1"),
                    ("generated_count", "INTEGER DEFAULT 0"),
                    ("kept_count", "INTEGER DEFAULT 0"),
                    ("cap_truncated", "INTEGER DEFAULT 0"),
                    ("mi_limit", "INTEGER DEFAULT 0")),
    # password_reset.py：临时密码签发时租户快照列（兜底老库；新库 SCHEMA 已含）
    "password_reset": (("tenant_id", "TEXT DEFAULT ''"),),
}

# 审计日志 DB 级 append-only（L109 P3）：经 data_migrations 迁移安装，产品库不自动写。
AUDIT_APPEND_ONLY_SQL = (
    """CREATE TRIGGER IF NOT EXISTS trg_audit_log_no_update
BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log_is_append_only'); END""",
    """CREATE TRIGGER IF NOT EXISTS trg_audit_log_no_delete
BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log_is_append_only'); END""",
)
AUDIT_APPEND_ONLY_TRIGGERS = ("trg_audit_log_no_update", "trg_audit_log_no_delete")


def audit_append_only_status(db_path=None) -> dict:
    """只读检查 ``audit_log`` 的 append-only 触发器状态（L150 / L140 A-05）。

    语义（严格只读，**不改 schema、不自动安装触发器**）：
    - 触发器安装仍只经 ``data_migrations`` 迁移
      ``20261125_004_l109_audit_append_only``（``rp db migrate`` / fresh seed 自动迁移）；
    - 本函数供启动自检、健康/对账状态与测试复用：拿到 ``status`` 后由调用方决定
      WARN 还是 fail。缺失时只报告，不修复——避免“服务启动顺手改产品库 schema”。

    返回字段：
    - ``checked``：是否成功检查（文件不存在/无法打开为 False）；
    - ``status``：``db_missing`` / ``audit_table_missing`` / ``pass`` / ``warn`` / ``error``；
    - ``enabled``：两个触发器是否齐全（未检查为 None）；
    - ``triggers`` / ``missing``：已存在/缺失的触发器名（用常量 AUDIT_APPEND_ONLY_TRIGGERS）；
    - ``audit_rows``：audit_log 行数（表存在时；只读 COUNT，便于确认自检连的是哪个库）；
    - ``db``：被检查的库路径；``note``：口径说明。
    """
    target = Path(db_path) if db_path else Path(DB_PATH)
    out = {"db": str(target), "checked": False, "status": "db_missing",
           "enabled": None, "triggers": [], "missing": list(AUDIT_APPEND_ONLY_TRIGGERS),
           "audit_table_present": False, "audit_rows": None,
           "note": "append-only 触发器只经显式数据迁移安装（rp db migrate）；"
                   "本自检只读，不自动建触发器/不改 schema"}
    if not target.exists():
        return out
    try:
        # 只读 URI 打开：避免对产品库产生 -wal/-journal 写入或 mtime 变化（铁律 6）。
        # as_uri() 负责空格/中文路径的百分号编码（纯 quote 拼 file: 在含非 ASCII
        # 目录的产品库路径上会被 sqlite 误判为普通文件名）。
        try:
            uri = target.resolve().as_uri() + "?mode=ro"
        except Exception:
            from urllib.parse import quote as _quote
            uri = "file:%s?mode=ro" % _quote(str(target), safe="/")
        conn = sqlite3.connect(uri, uri=True, timeout=5)
        try:
            has_table = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='audit_log'"
            ).fetchone()
            names = {str(r[0]) for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='audit_log'"
            ).fetchall()}
            out["audit_table_present"] = bool(has_table)
            out["triggers"] = [n for n in AUDIT_APPEND_ONLY_TRIGGERS if n in names]
            out["missing"] = [n for n in AUDIT_APPEND_ONLY_TRIGGERS if n not in names]
            if not has_table:
                out["checked"] = True
                out["enabled"] = False
                out["status"] = "audit_table_missing"
            else:
                out["checked"] = True
                out["enabled"] = not out["missing"]
                out["status"] = "pass" if out["enabled"] else "warn"
            if has_table:
                try:
                    out["audit_rows"] = int(conn.execute(
                        "SELECT COUNT(*) FROM audit_log").fetchone()[0] or 0)
                except Exception:  # noqa: BLE001 - 行数只用于辅助诊断，失败不影响 status
                    out["audit_rows"] = None
        finally:
            conn.close()
    except Exception as exc:  # noqa: BLE001 - 自检失败要显式报告，不能伪装成 PASS/FAIL 之外静默
        out["checked"] = False
        out["status"] = "error"
        out["enabled"] = None
        out["error"] = "%s: %s" % (type(exc).__name__, exc)
    return out


def ensure_runtime_schema(conn: sqlite3.Connection, *groups: str) -> dict:
    """幂等安装运行期按需对象（单一事实源：RUNTIME_EXTENSION_SCHEMA）。

    服务层 ensure_*() 调用本函数（保留运行期兜底）；data_migrations lazy 迁移同源。
    返回本次新增的表/索引数量（重复调用 = 0），失败上抛由调用方决定是否降级。
    """
    stats = {"groups": [g for g in groups], "tables": 0, "indexes": 0}
    before_t = {str(r[0]) for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    before_i = {str(r[0]) for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    for group in groups:
        statements = RUNTIME_EXTENSION_SCHEMA.get(group)
        if statements is None:
            raise KeyError("未知运行期 schema 组：%s" % group)
        for sql in statements:
            conn.execute(sql)
    after_t = {str(r[0]) for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    after_i = {str(r[0]) for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    stats["tables"] = len(after_t - before_t)
    stats["indexes"] = len(after_i - before_i)
    return stats


# 运行期按需唯一索引（与表同源）：单独登记/单独建，老库若已有历史重复行，
# 唯一索引失败只降级（服务层先查后插兜底），不得把整表判为不可用。
RUNTIME_EXTENSION_UNIQUE_INDEXES = (
    ("ux_acc_round_ws_no", "evolution_accuracy_round",
     ("tenant_id", "workspace_id", "round_no")),
)


def ensure_runtime_unique_index(conn: sqlite3.Connection, table: str) -> int:
    """幂等创建某表的运行期唯一索引（失败上抛，由调用方按老库重复数据降级）。"""
    created = 0
    for idx_name, idx_table, cols in RUNTIME_EXTENSION_UNIQUE_INDEXES:
        if idx_table != table:
            continue
        conn.execute(
            'CREATE UNIQUE INDEX IF NOT EXISTS "%s" ON "%s"(%s)'
            % (idx_name, table, ",".join('"%s"' % c for c in cols)))
        created += 1
    return created


def ensure_runtime_columns(conn: sqlite3.Connection, table: str) -> int:
    """幂等补齐运行期按需列（单一事实源：RUNTIME_EXTENSION_COLUMNS）。只加列。"""
    cols = {str(r[1]) for r in conn.execute(
        'PRAGMA table_info("%s")' % table).fetchall()}
    if not cols:
        return 0
    added = 0
    for col, ddl in RUNTIME_EXTENSION_COLUMNS.get(table, ()):
        if col not in cols:
            conn.execute('ALTER TABLE "%s" ADD COLUMN %s %s' % (table, col, ddl))
            added += 1
    return added




SCHEMA = """
CREATE TABLE IF NOT EXISTS org (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, region TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS plant (
  id TEXT PRIMARY KEY, org_id TEXT, name TEXT NOT NULL,
  FOREIGN KEY(org_id) REFERENCES org(id)
);
CREATE TABLE IF NOT EXISTS role (
  id TEXT PRIMARY KEY, code TEXT UNIQUE, name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user (
  id TEXT PRIMARY KEY, external_id TEXT, name TEXT, email TEXT,
  status TEXT DEFAULT 'active', plant_id TEXT, created_at TEXT,
  portal TEXT DEFAULT '', initial_password TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS user_role (
  user_id TEXT, role_id TEXT, PRIMARY KEY(user_id, role_id)
);
CREATE TABLE IF NOT EXISTS rule (
  id TEXT PRIMARY KEY, code TEXT, name TEXT, category TEXT, rclass TEXT,
  status TEXT DEFAULT 'draft', source TEXT, scope_json TEXT, created_at TEXT,
  created_by TEXT DEFAULT '',
  current_version_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS rule_version (
  id TEXT PRIMARY KEY, rule_id TEXT, version TEXT, slots_json TEXT,
  evidence_json TEXT, tests_json TEXT, published_at TEXT, status TEXT DEFAULT 'draft',
  approved_at TEXT DEFAULT '', approved_by TEXT DEFAULT '', superseded_at TEXT DEFAULT '',
  published_by TEXT DEFAULT '',
  FOREIGN KEY(rule_id) REFERENCES rule(id)
);
-- L50（2026-11-24）：规则分组/标签（组织管理维度，与 scope_json.tags 路由标签严格分离）。
-- 独立两表，不写 rule.scope_json/slots，不影响 manifest 路由与判定语义；
-- 老库由本 SCHEMA 的 CREATE TABLE IF NOT EXISTS 幂等补表，无需手工迁移；
-- 回滚：DROP TABLE rule_tag_item; DROP TABLE rule_tag;（纯组织数据，不参与判定）
CREATE TABLE IF NOT EXISTS rule_tag (
  id TEXT PRIMARY KEY,
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
  name TEXT NOT NULL, color TEXT DEFAULT '',
  created_by TEXT DEFAULT '', created_at TEXT DEFAULT '', updated_at TEXT DEFAULT '',
  UNIQUE(tenant_id, workspace_id, name)
);
CREATE INDEX IF NOT EXISTS idx_rule_tag_ws ON rule_tag(tenant_id, workspace_id);
CREATE TABLE IF NOT EXISTS rule_tag_item (
  tag_id TEXT NOT NULL, rule_id TEXT NOT NULL,
  created_by TEXT DEFAULT '', created_at TEXT DEFAULT '',
  PRIMARY KEY(tag_id, rule_id)
);
CREATE INDEX IF NOT EXISTS idx_rule_tag_item_rule ON rule_tag_item(rule_id);
CREATE TABLE IF NOT EXISTS document (
  id TEXT PRIMARY KEY, filename TEXT, doc_type TEXT, hash TEXT,
  status TEXT DEFAULT 'parsed', source_system TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS anchor (
  id TEXT PRIMARY KEY, document_id TEXT, sheet TEXT, row INTEGER, col TEXT,
  locator TEXT, quote TEXT, hash TEXT,
  FOREIGN KEY(document_id) REFERENCES document(id)
);
CREATE TABLE IF NOT EXISTS audit_case (
  id TEXT PRIMARY KEY, name TEXT, status TEXT DEFAULT 'created',
  pack_version TEXT, model_version TEXT, progress INTEGER DEFAULT 0, created_at TEXT,
  created_by TEXT DEFAULT '', audit_type TEXT DEFAULT '', focus TEXT DEFAULT '', audit_category TEXT DEFAULT '', document_type TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS case_document (
  case_id TEXT, document_id TEXT, PRIMARY KEY(case_id, document_id)
);
CREATE TABLE IF NOT EXISTS audit_run (
  id TEXT PRIMARY KEY, case_id TEXT, created_at TEXT, created_by TEXT DEFAULT '',
  audit_type TEXT DEFAULT '', focus TEXT DEFAULT '', total INTEGER DEFAULT 0,
  critical INTEGER DEFAULT 0, warning INTEGER DEFAULT 0, suspected INTEGER DEFAULT 0, trace_json TEXT DEFAULT '',
  FOREIGN KEY(case_id) REFERENCES audit_case(id)
);

CREATE TABLE IF NOT EXISTS llm_trace (
  id TEXT PRIMARY KEY, run_id TEXT DEFAULT '', case_id TEXT DEFAULT '', model TEXT DEFAULT '',
  prompt_hash TEXT DEFAULT '', prompt_chars INTEGER DEFAULT 0, latency_ms INTEGER DEFAULT 0,
  tokens_in INTEGER DEFAULT 0, tokens_out INTEGER DEFAULT 0, point_ids TEXT DEFAULT '',
  response_text TEXT DEFAULT '', created_at TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS finding (
  id TEXT PRIMARY KEY, case_id TEXT, rule_id TEXT, rule_version TEXT,
  severity TEXT, certainty TEXT, confidence REAL, state TEXT DEFAULT '', status TEXT DEFAULT 'pending',
  title TEXT, summary TEXT, suggestion TEXT, grade TEXT, engine TEXT, run_id TEXT DEFAULT '',
  -- L27 Phase0 Task 0.1（2026-11-23）：逐字引文 + 原文字符区间（老库由 init_db 幂等 ALTER 补列）
  verbatim_quote TEXT DEFAULT '', char_start INTEGER DEFAULT -1,
  char_end INTEGER DEFAULT -1, anchor_mode TEXT DEFAULT 'unanchored',
  issue_identity TEXT DEFAULT '',
  -- L71 P2a（2026-11-24）：证据回填字段（老库由 init_db 幂等 ALTER 补列）
  anchor_source TEXT DEFAULT 'none', anchor_strength TEXT DEFAULT 'none',
  text_profile TEXT DEFAULT '', quote_summary TEXT DEFAULT '',
  backfill_status TEXT DEFAULT '', backfill_reason TEXT DEFAULT '',
  backfill_version TEXT DEFAULT '',
  -- L93（2026-11-24）：核心单据来源四要素 + 权威版本/清单结果关联
  -- （老库由 init_db 的 _init_docmodel_schema 幂等 ALTER 补列；新写入由
  --  FindingRepo.insert + finding AFTER INSERT 触发器兜底补全）
  created_by TEXT DEFAULT '', created_at TEXT DEFAULT '',
  source TEXT DEFAULT '', source_kind TEXT DEFAULT '',
  rule_version_id TEXT DEFAULT '',
  FOREIGN KEY(case_id) REFERENCES audit_case(id)
);
-- L72 P2b（2026-11-24）：Certificate Kernel 证书表（advisory；KERNEL=0 时不签发/不读表）。
-- 一条 fail finding 一张证书；唯一 (finding_id, verifier_version) 保证重签幂等。
-- 老库由 init_db 的 executescript(SCHEMA) 幂等建表（CREATE TABLE IF NOT EXISTS）。
CREATE TABLE IF NOT EXISTS finding_certificate (
  id TEXT PRIMARY KEY, finding_id TEXT NOT NULL,
  case_id TEXT DEFAULT '', rule_code TEXT DEFAULT '', rule_version_sha TEXT DEFAULT '',
  status TEXT DEFAULT '', verifier_version TEXT DEFAULT '', verifier_kind TEXT DEFAULT '',
  quote TEXT DEFAULT '', char_start INTEGER DEFAULT -1, char_end INTEGER DEFAULT -1,
  recompute_json TEXT DEFAULT '{}', checks_json TEXT DEFAULT '[]',
  inputs_digest TEXT DEFAULT '', issued_at TEXT DEFAULT '', digest TEXT DEFAULT '',
  certificate_type TEXT DEFAULT '', result_id TEXT DEFAULT '',
  certificate_json TEXT DEFAULT '{}', created_at TEXT DEFAULT '',
  UNIQUE(finding_id, verifier_version)
);
CREATE INDEX IF NOT EXISTS idx_finding_cert_case
  ON finding_certificate(case_id, status);
CREATE INDEX IF NOT EXISTS idx_finding_cert_digest
  ON finding_certificate(inputs_digest);
CREATE TABLE IF NOT EXISTS evidence (
  id TEXT PRIMARY KEY, finding_id TEXT, document_id TEXT, anchor_id TEXT,
  excerpt TEXT, label TEXT,
  FOREIGN KEY(finding_id) REFERENCES finding(id)
);
CREATE TABLE IF NOT EXISTS decision (
  id TEXT PRIMARY KEY, finding_id TEXT, decision TEXT, reason TEXT, note TEXT,
  user_id TEXT, created_at TEXT,
  FOREIGN KEY(finding_id) REFERENCES finding(id)
);
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, case_id TEXT, finding_id TEXT,
  kind TEXT, rule_code TEXT, title TEXT, payload TEXT,
  actor TEXT, created_at TEXT,
  rsi_status TEXT DEFAULT 'pending', rsi_action TEXT, rsi_rule_id TEXT,
  handled_at TEXT, handled_by TEXT
);
CREATE TABLE IF NOT EXISTS evolution_task (
  id TEXT PRIMARY KEY, finding_id TEXT, rule_code TEXT, title TEXT,
  status TEXT DEFAULT 'open', root_cause TEXT, suggestion TEXT,
  action TEXT, rule_id TEXT, note TEXT,
  created_at TEXT, handled_at TEXT, handled_by TEXT,
  FOREIGN KEY(finding_id) REFERENCES finding(id)
);
-- E1 自进化效果度量（T12，2026-11-23）：5 指标落库，供只读查询
-- GET /api/v1/metrics/evolution/effect。写入点在 app/services/evolution.settle_feedback
-- （开关 RULEPROOF_EVOLUTION_METRICS，默认 "1" 开；="0" 回滚为不落库）。
-- L109：evolution_effect DDL 统一在 EVOLUTION_EFFECT_SCHEMA 常量（SCHEMA 与 ensure 同源）。
""" + "".join(_s + ";\n" for _s in EVOLUTION_EFFECT_SCHEMA) + """
CREATE TABLE IF NOT EXISTS report (
  id TEXT PRIMARY KEY, case_id TEXT, version TEXT, summary_json TEXT,
  signatures_json TEXT, disclaimer TEXT, exported_at TEXT,
  -- L92（2026-11-24，修订 L88 G13）：报告持久化状态（draft/generated/signed/
  -- exported/revoked），旧库由 init_db 的 _init_state_guard_schema 幂等补列。
  status TEXT DEFAULT 'generated',
  -- L93（2026-11-24）：报告签发模型（生成人/时间、签发人/时间、内容 hash、
  -- 导出人/时间/hash）。旧库由 _init_docmodel_schema 幂等补列；
  -- 0 行历史在 docmodel_health_report 中显式报告，不当作“字段齐全”。
  created_by TEXT DEFAULT '', created_at TEXT DEFAULT '',
  signed_by TEXT DEFAULT '', signed_at TEXT DEFAULT '',
  content_hash TEXT DEFAULT '',
  exported_by TEXT DEFAULT '', exported_hash TEXT DEFAULT '',
  FOREIGN KEY(case_id) REFERENCES audit_case(id)
);
CREATE TABLE IF NOT EXISTS model_config (
  id TEXT PRIMARY KEY, name TEXT, provider TEXT, model_id TEXT, base_url TEXT,
  api_key TEXT, capabilities TEXT, is_default INTEGER DEFAULT 0,
  enabled INTEGER DEFAULT 1, status TEXT DEFAULT 'unknown', created_at TEXT
);

CREATE TABLE IF NOT EXISTS agent (
  id TEXT PRIMARY KEY, name TEXT, type TEXT, status TEXT DEFAULT 'draft', profile_json TEXT
);
CREATE TABLE IF NOT EXISTS agent_version (
  id TEXT PRIMARY KEY, agent_id TEXT, version TEXT, prompt TEXT, model TEXT,
  tools_json TEXT, published_at TEXT, status TEXT DEFAULT 'draft',
  FOREIGN KEY(agent_id) REFERENCES agent(id)
);
CREATE TABLE IF NOT EXISTS agent_run (
  id TEXT PRIMARY KEY, agent_version_id TEXT, case_id TEXT, status TEXT,
  cost REAL, latency_ms INTEGER, result_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS agent_node_run (
  id TEXT PRIMARY KEY, agent_run_id TEXT, agent_id TEXT, node_id TEXT,
  node_name TEXT, node_type TEXT, status TEXT, latency_ms INTEGER,
  input_json TEXT DEFAULT '{}', output_json TEXT DEFAULT '{}',
  error TEXT DEFAULT '', created_at TEXT
);
CREATE TABLE IF NOT EXISTS eval_set (
  id TEXT PRIMARY KEY, name TEXT, golden_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS eval_run (
  id TEXT PRIMARY KEY, eval_set_id TEXT, metrics_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS notify_setting (
  id TEXT PRIMARY KEY, config_json TEXT DEFAULT '{}', updated_at TEXT DEFAULT '', updated_by TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY, actor TEXT, action TEXT, object TEXT,
  before_json TEXT, after_json TEXT, request_id TEXT, ip TEXT, created_at TEXT,
  tenant_id TEXT, workspace_id TEXT
);
CREATE TABLE IF NOT EXISTS decision_table (
  id TEXT PRIMARY KEY, code TEXT, name TEXT, hit_policy TEXT DEFAULT 'first',
  rules_json TEXT DEFAULT '[]', status TEXT DEFAULT 'draft', version TEXT DEFAULT 'v0.1',
  source TEXT DEFAULT '', created_at TEXT,
  scope_types TEXT DEFAULT '[]', canary_percent INTEGER DEFAULT 100
);
CREATE TABLE IF NOT EXISTS decision_table_version (
  id TEXT PRIMARY KEY, table_id TEXT, version TEXT, rules_json TEXT DEFAULT '[]', published_at TEXT
);
CREATE TABLE IF NOT EXISTS llm_cache (
  id TEXT PRIMARY KEY, k TEXT UNIQUE, v TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS rsi_candidate (
  id TEXT PRIMARY KEY, feedback_id TEXT, rule_code TEXT, action TEXT,
  before_json TEXT DEFAULT '{}', after_json TEXT DEFAULT '{}',
  decision TEXT DEFAULT 'accepted', note TEXT, created_at TEXT,
  decided_at TEXT, decided_by TEXT
);
CREATE TABLE IF NOT EXISTS rulegen_candidate (
  id TEXT PRIMARY KEY, point_code TEXT, name TEXT, category TEXT, rclass TEXT,
  source_kind TEXT DEFAULT 'rulegen', source_ref_json TEXT DEFAULT '{}',
  schema_json TEXT DEFAULT '{}', slots_json TEXT DEFAULT '{}',
  criteria_text TEXT DEFAULT '', shadow_cases_json TEXT DEFAULT '[]',
  shadow_json TEXT DEFAULT '{}', status TEXT DEFAULT 'suggested',
  rule_id TEXT DEFAULT '', note TEXT DEFAULT '',
  created_by TEXT DEFAULT '', created_at TEXT,
  decided_by TEXT DEFAULT '', decided_at TEXT,
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS point_state (
  id TEXT PRIMARY KEY, batch_id TEXT, point_id TEXT, state TEXT,
  confidence REAL, created_at TEXT,
  -- L27 Phase0 Task 0.1（2026-11-23）：点位级原文区间（老库由 init_db 幂等 ALTER 补列）
  char_start INTEGER DEFAULT -1, char_end INTEGER DEFAULT -1,
  anchor_mode TEXT DEFAULT 'unanchored', verbatim_quote TEXT DEFAULT '',
  -- L78（2026-11-24）：多实例 cap 截断可观测（字段名与 L67 §9.2 约定一致；
  -- 老库由 init_db / manifest_exec._d5_point_log_ensure_cols 幂等 ALTER 补列）
  generated_count INTEGER DEFAULT 0, kept_count INTEGER DEFAULT 0,
  cap_truncated INTEGER DEFAULT 0, mi_limit INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS qa_sample (
  id TEXT PRIMARY KEY, finding_id TEXT, case_id TEXT,
  original_status TEXT, qa_status TEXT DEFAULT 'pending', note TEXT,
  created_at TEXT, created_by TEXT, handled_at TEXT, handled_by TEXT
);
CREATE TABLE IF NOT EXISTS job_lock (
  name TEXT PRIMARY KEY, owner TEXT, acquired_at TEXT, expires_at TEXT
);
CREATE TABLE IF NOT EXISTS rule_param (
  id TEXT PRIMARY KEY, rule_code TEXT, params_json TEXT DEFAULT '{}',
  source TEXT DEFAULT '', updated_at TEXT DEFAULT '',
  pending_json TEXT DEFAULT '', pending_by TEXT DEFAULT '', pending_at TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS conflict (
  id TEXT PRIMARY KEY, rule_a TEXT, rule_b TEXT, type TEXT, detail TEXT,
  status TEXT DEFAULT 'open', created_at TEXT,
  severity TEXT DEFAULT 'warning', suggestion TEXT DEFAULT '',
  slots_a TEXT DEFAULT '', slots_b TEXT DEFAULT '',
  resolved_at TEXT DEFAULT '', resolved_by TEXT DEFAULT '', note TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
  -- T-63 裁决结果：rule_a/rule_b/both_wrong/both_valid/need_more/ignored
  resolution TEXT DEFAULT '', resolution_detail TEXT DEFAULT '',
  closed_rule_ids TEXT DEFAULT '[]',
  recreate_rule_id TEXT DEFAULT '', recreate_task TEXT DEFAULT '',
  impact_json TEXT DEFAULT ''
);
-- T-164 / 评审 C-4：冲突检测状态。detect() 成功/失败都落一行，报告门禁据此区分
-- 「检完无冲突」与「未检完/检测失败/从未检测」——旧库没有记录时门禁阻断并要求先检测一次。
-- 只新增表，不改 conflict 既有裁决数据；旧库由 init_db 幂等补表。
-- L109：DDL 统一在 CONFLICT_CHECK_SCHEMA 常量（SCHEMA 与运行期 ensure 同源）。
""" + "".join(_s + ";\n" for _s in CONFLICT_CHECK_SCHEMA) + """
CREATE TABLE IF NOT EXISTS rule_snapshot (
  id TEXT PRIMARY KEY, case_id TEXT, rule_code TEXT, hit INTEGER, override INTEGER,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS onto_entity (
  id TEXT PRIMARY KEY, type_key TEXT, name TEXT, props_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS onto_alias (
  id TEXT PRIMARY KEY, type_key TEXT, alias TEXT, entity_id TEXT
);
CREATE TABLE IF NOT EXISTS onto_link (
  id TEXT PRIMARY KEY, key TEXT, source_id TEXT, target_id TEXT
);
CREATE TABLE IF NOT EXISTS notification (
  id TEXT PRIMARY KEY, actor TEXT, type TEXT, title TEXT, detail TEXT,
  read INTEGER DEFAULT 0, created_at TEXT, tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS onto_version (
  id TEXT PRIMARY KEY, version TEXT, status TEXT DEFAULT 'draft',
  snapshot_json TEXT, health_json TEXT, created_at TEXT, published_at TEXT
);
CREATE TABLE IF NOT EXISTS sys_config (
  key TEXT PRIMARY KEY, value TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS password_reset (
  id TEXT PRIMARY KEY, user_id TEXT, actor TEXT, source TEXT,
  temp_password TEXT, created_at TEXT, expires_at TEXT,
  used_at TEXT, used_by TEXT, tenant_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS open_app (
  id TEXT PRIMARY KEY, app_key TEXT UNIQUE, app_secret TEXT, name TEXT,
  callback_url TEXT, events TEXT, status TEXT DEFAULT 'active', created_at TEXT,
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS open_task (
  id TEXT PRIMARY KEY, project_id TEXT, external_id TEXT, callback_url TEXT,
  status TEXT DEFAULT 'accepted', created_at TEXT, tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS open_task_queue (
  id TEXT PRIMARY KEY, app_key TEXT, payload_json TEXT, status TEXT DEFAULT 'accepted',
  error TEXT DEFAULT '', project_id TEXT DEFAULT '', created_at TEXT, updated_at TEXT,
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS open_nonce (
  nonce TEXT PRIMARY KEY, app_key TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS open_event (
  id TEXT PRIMARY KEY, task_id TEXT, type TEXT, payload TEXT,
  delivered INTEGER DEFAULT 0, retry_count INTEGER DEFAULT 0, created_at TEXT,
  tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS open_sandbox (
  id TEXT PRIMARY KEY, app_key TEXT, signature TEXT, timestamp TEXT, nonce TEXT,
  body TEXT, valid INTEGER, received_at TEXT
);
CREATE TABLE IF NOT EXISTS calibration (
  id TEXT PRIMARY KEY, confidence REAL, correct INTEGER, created_at TEXT,
  rule_code TEXT DEFAULT '', point_id TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_user_role_user ON user_role(user_id);
CREATE INDEX IF NOT EXISTS idx_finding_case ON finding(case_id);
CREATE INDEX IF NOT EXISTS idx_anchor_doc ON anchor(document_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor);
-- P2 慢节点最小修（2026-11-22）：rule_version.rule_id 缺索引，latest_version/
-- 静态分析逐规则查版本时全表扫描（EXPLAIN: SCAN rule_version）。纯查询加速，
-- 不改任何语义；旧库由本幂等 DDL 在下次 init_db 自动补建。
CREATE INDEX IF NOT EXISTS idx_rule_version_rule ON rule_version(rule_id);
"""

# ---------------------------------------------------------------------------
# T-39 双轨审核 / 置信图 / 可见性策略：数据与策略底座（离线，新增表，不动主链）
# 依据 docs/delivery/双轨直连草稿与交叉复核_20261117.md、
#      docs/delivery/置信图与分层裁决_20261117.md、
#      docs/delivery/直连与平台可见性策略_20261117.md
# 约定：
#   * direct_draft / direct_item 只 INSERT，不允许 UPDATE/DELETE（触发器兜底）；
#   * platform_finding 是既有 finding + evidence 的只读统一视图（view，不是新表）；
#   * comparison_item 只做提示性四桶分组，human_status 默认 unreviewed，
#     自动比对不得写人工结论（服务层写入口唯一）；
#   * suppression_ledger 抑制台账：抑制≠删除，禁止物理删除，恢复只改状态；
#   * adjudication_event 追加式裁决事件：禁止 UPDATE/DELETE；
#   * confidence_calibration 按 来源/规则/文档类型/风险/置信分箱 聚合校准样本。
# ---------------------------------------------------------------------------
DUAL_TRACK_SCHEMA = """
CREATE TABLE IF NOT EXISTS direct_draft (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL UNIQUE,
  case_id TEXT NOT NULL,
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  draft_index INTEGER DEFAULT 0,
  schema_version TEXT DEFAULT '',
  prompt_version TEXT DEFAULT '',
  prompt_sha256 TEXT DEFAULT '',
  prompt_chars INTEGER DEFAULT 0,
  ruleset_sha256 TEXT DEFAULT '',
  doc_sha256 TEXT DEFAULT '',
  model TEXT DEFAULT '',
  model_source TEXT DEFAULT '',
  sampling_json TEXT DEFAULT '{}',
  raw_response TEXT NOT NULL,
  raw_sha256 TEXT NOT NULL,
  parse_status TEXT DEFAULT '',
  parsed_items_json TEXT DEFAULT '[]',
  items_count INTEGER DEFAULT 0,
  quote_check_json TEXT DEFAULT '{}',
  latency_ms INTEGER DEFAULT 0,
  tokens_in INTEGER DEFAULT 0,
  tokens_out INTEGER DEFAULT 0,
  error TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_direct_draft_case ON direct_draft(case_id);
CREATE TABLE IF NOT EXISTS direct_item (
  id TEXT PRIMARY KEY,
  draft_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  case_id TEXT DEFAULT '',
  item_index INTEGER DEFAULT 0,
  rule_code TEXT DEFAULT '',
  quote TEXT DEFAULT '',
  quote_status TEXT DEFAULT '',
  quote_match_status TEXT DEFAULT '',
  quote_offset INTEGER,
  quote_line INTEGER,
  quote_length INTEGER DEFAULT 0,
  issue_type TEXT DEFAULT '',
  issue TEXT DEFAULT '',
  reason TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  location_hint TEXT DEFAULT '',
  confidence REAL,
  raw_item_json TEXT DEFAULT '{}',
  created_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1,
  UNIQUE(draft_id, item_index)
);
CREATE INDEX IF NOT EXISTS idx_direct_item_draft ON direct_item(draft_id);
CREATE INDEX IF NOT EXISTS idx_direct_item_case ON direct_item(case_id);
CREATE TABLE IF NOT EXISTS comparison_item (
  id TEXT PRIMARY KEY,
  item_key TEXT NOT NULL UNIQUE,
  case_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  bucket TEXT NOT NULL CHECK(bucket IN ('both','direct_only','platform_only','conflict')),
  match_key_json TEXT DEFAULT '{}',
  match_key_code TEXT DEFAULT '',
  match_key_clause TEXT DEFAULT '',
  match_key_subject TEXT DEFAULT '',
  match_key_issue_type TEXT DEFAULT '',
  direct_draft_id TEXT DEFAULT '',
  direct_item_id TEXT DEFAULT '',
  direct_item_index INTEGER,
  platform_finding_id TEXT DEFAULT '',
  platform_index INTEGER,
  auto_similarity REAL,
  auto_note TEXT DEFAULT '',
  auto_features_json TEXT DEFAULT '{}',
  human_status TEXT DEFAULT 'unreviewed',
  human_actor TEXT DEFAULT '',
  human_reason TEXT DEFAULT '',
  human_label TEXT DEFAULT '',
  visibility TEXT DEFAULT '',
  visibility_reason TEXT DEFAULT '',
  visibility_json TEXT DEFAULT '{}',
  created_at TEXT DEFAULT '',
  updated_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_comparison_case ON comparison_item(case_id);
CREATE INDEX IF NOT EXISTS idx_comparison_bucket ON comparison_item(case_id, bucket);
CREATE TABLE IF NOT EXISTS suppression_ledger (
  id TEXT PRIMARY KEY,
  ledger_key TEXT NOT NULL UNIQUE,
  case_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  source TEXT NOT NULL CHECK(source IN ('direct','platform','both')),
  comparison_item_id TEXT DEFAULT '',
  direct_item_id TEXT DEFAULT '',
  platform_finding_id TEXT DEFAULT '',
  rule_code TEXT DEFAULT '',
  object_id TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  issue_type TEXT DEFAULT '',
  raw_claim_json TEXT NOT NULL,
  raw_claim_sha256 TEXT NOT NULL,
  evidence_json TEXT DEFAULT '{}',
  refute_evidence_json TEXT DEFAULT '{}',
  confidence REAL,
  risk_level TEXT DEFAULT 'medium',
  suppression_reason TEXT DEFAULT '',
  reason_note TEXT DEFAULT '',
  visibility_status TEXT DEFAULT 'suppressed',
  sampled INTEGER DEFAULT 0,
  sampled_at TEXT DEFAULT '',
  human_result TEXT DEFAULT '',
  human_actor TEXT DEFAULT '',
  human_reason TEXT DEFAULT '',
  human_at TEXT DEFAULT '',
  recovered_finding_ref TEXT DEFAULT '',
  recovered_at TEXT DEFAULT '',
  recovered_by TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_ledger_case ON suppression_ledger(case_id);
CREATE INDEX IF NOT EXISTS idx_ledger_status ON suppression_ledger(case_id, visibility_status);
CREATE TABLE IF NOT EXISTS human_omission (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  actor TEXT DEFAULT '',
  quote TEXT DEFAULT '',
  issue TEXT DEFAULT '',
  rule_hint TEXT DEFAULT '',
  object_id TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  locator_json TEXT DEFAULT '{}',
  status TEXT DEFAULT 'pending',
  match_type TEXT DEFAULT '',
  matched_ref TEXT DEFAULT '',
  recovered_ledger_id TEXT DEFAULT '',
  feedback_candidate_json TEXT DEFAULT '{}',
  note TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  reconciled_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_omission_case ON human_omission(case_id, status);
CREATE TABLE IF NOT EXISTS adjudication_event (
  id TEXT PRIMARY KEY,
  case_id TEXT DEFAULT '',
  run_id TEXT DEFAULT '',
  comparison_item_id TEXT DEFAULT '',
  ledger_id TEXT DEFAULT '',
  omission_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  action TEXT NOT NULL,
  actor TEXT DEFAULT '',
  before_status TEXT DEFAULT '',
  after_status TEXT DEFAULT '',
  reason_code TEXT DEFAULT '',
  reason TEXT DEFAULT '',
  evidence_json TEXT DEFAULT '{}',
  created_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_adjudication_case ON adjudication_event(case_id);
CREATE INDEX IF NOT EXISTS idx_adjudication_item ON adjudication_event(comparison_item_id);
CREATE TABLE IF NOT EXISTS confidence_calibration (
  id TEXT PRIMARY KEY,
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  source TEXT NOT NULL,
  rule_code TEXT DEFAULT '',
  doc_type TEXT DEFAULT '',
  risk_level TEXT DEFAULT 'medium',
  confidence_bin TEXT DEFAULT '',
  n_samples INTEGER DEFAULT 0,
  n_correct INTEGER DEFAULT 0,
  reliability REAL,
  ece REAL,
  min_samples INTEGER DEFAULT 30,
  auto_confirm_allowed INTEGER DEFAULT 0,
  auto_suppress_allowed INTEGER DEFAULT 0,
  created_at TEXT DEFAULT '',
  updated_at TEXT DEFAULT '',
  UNIQUE(source, rule_code, doc_type, risk_level, confidence_bin)
);
CREATE INDEX IF NOT EXISTS idx_calibration_group ON confidence_calibration(source, rule_code, doc_type);
"""

# 不可变 / 追加式兜底触发器：服务层之外也无法改历史。
DUAL_TRACK_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS trg_direct_draft_no_update
BEFORE UPDATE ON direct_draft
BEGIN SELECT RAISE(ABORT, 'direct_draft_immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_direct_draft_no_delete
BEFORE DELETE ON direct_draft
BEGIN SELECT RAISE(ABORT, 'direct_draft_immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_direct_item_no_update
BEFORE UPDATE ON direct_item
BEGIN SELECT RAISE(ABORT, 'direct_item_immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_direct_item_no_delete
BEFORE DELETE ON direct_item
BEGIN SELECT RAISE(ABORT, 'direct_item_immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_suppression_ledger_no_delete
BEFORE DELETE ON suppression_ledger
BEGIN SELECT RAISE(ABORT, 'suppression_is_not_deletion'); END;
CREATE TRIGGER IF NOT EXISTS trg_suppression_ledger_raw_immutable
BEFORE UPDATE OF raw_claim_json, raw_claim_sha256, source, created_at ON suppression_ledger
BEGIN SELECT RAISE(ABORT, 'suppression_raw_claim_immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_adjudication_event_no_update
BEFORE UPDATE ON adjudication_event
BEGIN SELECT RAISE(ABORT, 'adjudication_event_append_only'); END;
CREATE TRIGGER IF NOT EXISTS trg_adjudication_event_no_delete
BEFORE DELETE ON adjudication_event
BEGIN SELECT RAISE(ABORT, 'adjudication_event_append_only'); END;
"""

# ---------------------------------------------------------------------------
# L80 / P0-C 裁决来源统计（2026-11-24，89 号规格 / 87 号 D1 第③步）：
# 每个激活单元 (run_id, object_id, rule_version_id, instance_id) 一行 append-only 台账。
# 口径：
#   * 只新增一张表 + 3 索引 + 2 触发器（禁止 UPDATE/DELETE，与 adjudication_event 同规）；
#   * **开关 RULEPROOF_ADJUDICATION_LEDGER 默认 0**：=0 时 init_db 不执行本段 DDL
#     （0 DDL、0 行、逐字节回退），=1 时才幂等建表；老库无迁移风险（新表）。
#   * 单实例规则 instance_id=''；多实例（S1..Sn / sub id）逐实例一行。
#   * 不落原文：只落 quote_sha256 + evidence_ref_json 引用。
# 回滚：开关=0（不建表/不写入/不统计）；已建表可安全保留（无任何读取方依赖）。
# ---------------------------------------------------------------------------
ADJUDICATION_LEDGER_ENV = "RULEPROOF_ADJUDICATION_LEDGER"
ADJUDICATION_LEDGER_STRICT_ENV = "RULEPROOF_ADJUDICATION_LEDGER_STRICT"

ADJUDICATION_LEDGER_SCHEMA = """
CREATE TABLE IF NOT EXISTS adjudication_ledger (
  id TEXT PRIMARY KEY,
  schema_version TEXT DEFAULT 'adjudication_ledger/v1',
  run_id TEXT NOT NULL,
  case_id TEXT DEFAULT '', tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
  object_id TEXT DEFAULT '',
  rule_code TEXT DEFAULT '', rule_version_id TEXT DEFAULT '',
  item_key TEXT DEFAULT '',
  manifest_id TEXT DEFAULT '',
  instance_id TEXT DEFAULT '', instance_index INTEGER DEFAULT 0,
  final_state TEXT NOT NULL,
  adjudicator TEXT NOT NULL,
  undecided_reason TEXT DEFAULT '',
  abstain_reason TEXT DEFAULT '',
  executor TEXT DEFAULT '',
  executor_tier TEXT DEFAULT '',
  fact_source TEXT DEFAULT '',
  extraction_source TEXT DEFAULT '',
  model_calls INTEGER,
  model_calls_scope TEXT DEFAULT 'none',
  model_ids TEXT DEFAULT '',
  recomputed INTEGER DEFAULT 0,
  recompute_kind TEXT DEFAULT '',
  evidence_status TEXT DEFAULT '',
  quote_sha256 TEXT DEFAULT '',
  evidence_ref_json TEXT DEFAULT '{}',
  route_status TEXT DEFAULT 'in_manifest',
  route_reason TEXT DEFAULT '',
  mapped_route INTEGER DEFAULT 0,
  human_decision_id TEXT DEFAULT '',
  human_decision TEXT DEFAULT '',
  attribution_basis TEXT NOT NULL,
  attribution_confidence TEXT NOT NULL,
  created_at TEXT DEFAULT '',
  ledger_version TEXT DEFAULT '',
  UNIQUE(run_id, rule_version_id, object_id, instance_id, item_key)
);
CREATE INDEX IF NOT EXISTS idx_adjledger_run ON adjudication_ledger(run_id);
CREATE INDEX IF NOT EXISTS idx_adjledger_case ON adjudication_ledger(case_id);
CREATE INDEX IF NOT EXISTS idx_adjledger_adj ON adjudication_ledger(adjudicator, run_id);
CREATE TRIGGER IF NOT EXISTS trg_adjledger_no_update BEFORE UPDATE ON adjudication_ledger
BEGIN SELECT RAISE(ABORT,'adjudication_ledger_append_only'); END;
CREATE TRIGGER IF NOT EXISTS trg_adjledger_no_delete BEFORE DELETE ON adjudication_ledger
BEGIN SELECT RAISE(ABORT,'adjudication_ledger_append_only'); END;
"""


def adjudication_ledger_env_on() -> bool:
    """RULEPROOF_ADJUDICATION_LEDGER（默认 0；只有显式真值才开）。

    唯一解析处之一（另一处 app/services/adjudication_ledger.py 同口径；两边都读
    环境变量而不是互相 import，避免 db ↔ services 循环依赖）。=0 时不建表、不写入。
    """
    return str(os.environ.get(ADJUDICATION_LEDGER_ENV, "0") or "").strip().lower() in (
        "1", "true", "yes", "on")


def _init_adjudication_ledger_schema(c: sqlite3.Connection) -> dict:
    """幂等创建裁决台账表/索引/触发器（仅开关=1 时由 init_db 调用）。

    返回 {tables, indexes, triggers, created}（created=本次新建表数，便于测试断言
    「=0 无 DDL」与「=1 幂等」）。
    """
    before = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    c.executescript(ADJUDICATION_LEDGER_SCHEMA)
    after = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    idx = c.execute("SELECT count(*) FROM sqlite_master WHERE type='index' "
                    "AND name LIKE 'idx_adjledger_%'").fetchone()[0]
    trg = c.execute("SELECT count(*) FROM sqlite_master WHERE type='trigger' "
                    "AND name LIKE 'trg_adjledger_%'").fetchone()[0]
    return {"tables": len(after & {"adjudication_ledger"}),
            "created": len(after - before),
            "indexes": int(idx or 0), "triggers": int(trg or 0)}


# ---------------------------------------------------------------------------
# T-52 隐藏项全量进化闭环（V3.3 §14）：持久进化池 + 追加式状态事件 + 抽样台账。
# 依据 docs/delivery/V3.3人工隐藏开关_增补_20261117.md §14。
# 约定：
#   * 本 schema **只新增**表/索引/触发器，不改任何既有表；
#   * hidden_evolution_item 是持久进化池：每个隐藏项（suppression_ledger 行）
#     或视图过滤项（comparison_item 非 visible 行）一行，重启可读；
#   * hidden_evolution_event 追加式审计：禁止 UPDATE/DELETE；
#   * hidden_evolution_sample 追加式抽样审计：禁止 UPDATE/DELETE；
#   * trg_hidden_evolution_ledger_insert：suppression_ledger 任何 INSERT（不论
#     调用方是 visibility 策略、人工动作还是测试）都**立即**在进化池落一行，
#     保证“隐藏即入池 100%”不依赖 UI/人工/服务层钩子；未裁决行的 TTL 默认
#     处置只能是 weak_default（服务层 apply_ttl 落实），不是 gold。
# ---------------------------------------------------------------------------
HIDDEN_EVOLUTION_SCHEMA = """
CREATE TABLE IF NOT EXISTS hidden_evolution_item (
  id TEXT PRIMARY KEY,
  hidden_item_id TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL DEFAULT 'hidden',
  case_id TEXT NOT NULL DEFAULT '',
  run_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  source TEXT DEFAULT '',
  source_ref TEXT DEFAULT '',
  ledger_id TEXT DEFAULT '',
  comparison_item_id TEXT DEFAULT '',
  direct_item_id TEXT DEFAULT '',
  platform_finding_id TEXT DEFAULT '',
  rule_code TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  issue_type TEXT DEFAULT '',
  object_id TEXT DEFAULT '',
  suppression_reason TEXT DEFAULT '',
  hidden_reason TEXT DEFAULT 'display_policy_filtered',
  risk_level TEXT DEFAULT 'medium',
  evidence_status TEXT DEFAULT '',
  hidden_at TEXT DEFAULT '',
  reveal_count INTEGER DEFAULT 0,
  last_revealed_at TEXT DEFAULT '',
  last_revealed_by TEXT DEFAULT '',
  reveal_after_default_count INTEGER DEFAULT 0,
  revealed_after_default INTEGER DEFAULT 0,
  human_action TEXT DEFAULT 'none',
  human_actor TEXT DEFAULT '',
  human_action_at TEXT DEFAULT '',
  adjudication TEXT DEFAULT 'unreviewed',
  evolution_status TEXT DEFAULT 'pending',
  label TEXT DEFAULT '',
  label_strength TEXT DEFAULT 'none_pending',
  label_source TEXT DEFAULT '',
  default_disposition TEXT DEFAULT '',
  ttl_days INTEGER DEFAULT 30,
  ttl_deadline TEXT DEFAULT '',
  default_closed_at TEXT DEFAULT '',
  recovered_finding_id TEXT DEFAULT '',
  recovered_at TEXT DEFAULT '',
  sampling_required INTEGER DEFAULT 0,
  sampled INTEGER DEFAULT 0,
  sampled_at TEXT DEFAULT '',
  sampled_by TEXT DEFAULT '',
  sample_result TEXT DEFAULT '',
  evolution_candidate_id TEXT DEFAULT '',
  enqueue_source TEXT DEFAULT '',
  feedback_enqueued INTEGER DEFAULT 1,
  gold_eligible INTEGER DEFAULT 0,
  calibration_eligible INTEGER DEFAULT 0,
  threshold_eligible INTEGER DEFAULT 0,
  no_gold INTEGER DEFAULT 1,
  auto_threshold_change INTEGER DEFAULT 0,
  auto_training INTEGER DEFAULT 0,
  created_at TEXT DEFAULT '',
  updated_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_hev_case ON hidden_evolution_item(case_id);
CREATE INDEX IF NOT EXISTS idx_hev_status ON hidden_evolution_item(evolution_status);
CREATE INDEX IF NOT EXISTS idx_hev_rule ON hidden_evolution_item(rule_code, hidden_reason, source);
CREATE INDEX IF NOT EXISTS idx_hev_label ON hidden_evolution_item(label_strength);
CREATE INDEX IF NOT EXISTS idx_hev_ttl ON hidden_evolution_item(ttl_deadline);
CREATE INDEX IF NOT EXISTS idx_hev_candidate ON hidden_evolution_item(evolution_candidate_id);
CREATE TABLE IF NOT EXISTS hidden_evolution_event (
  id TEXT PRIMARY KEY,
  item_id TEXT DEFAULT '',
  hidden_item_id TEXT DEFAULT '',
  case_id TEXT DEFAULT '',
  action TEXT NOT NULL,
  actor TEXT DEFAULT '',
  before_status TEXT DEFAULT '',
  after_status TEXT DEFAULT '',
  before_label_strength TEXT DEFAULT '',
  after_label_strength TEXT DEFAULT '',
  default_disposition TEXT DEFAULT '',
  reason_code TEXT DEFAULT '',
  reason TEXT DEFAULT '',
  detail_json TEXT DEFAULT '{}',
  source_event_id TEXT,
  created_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_heve_item ON hidden_evolution_event(item_id);
CREATE INDEX IF NOT EXISTS idx_heve_case ON hidden_evolution_event(case_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_heve_source_event ON hidden_evolution_event(source_event_id);
CREATE TABLE IF NOT EXISTS hidden_evolution_sample (
  id TEXT PRIMARY KEY,
  item_id TEXT DEFAULT '',
  hidden_item_id TEXT DEFAULT '',
  case_id TEXT DEFAULT '',
  risk_level TEXT DEFAULT '',
  default_disposition TEXT DEFAULT '',
  result TEXT NOT NULL,
  actor TEXT DEFAULT '',
  note TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_hevs_item ON hidden_evolution_sample(item_id);
CREATE INDEX IF NOT EXISTS idx_hevs_case ON hidden_evolution_sample(case_id);
"""

HIDDEN_EVOLUTION_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS trg_hidden_evolution_event_no_update
BEFORE UPDATE ON hidden_evolution_event
BEGIN SELECT RAISE(ABORT, 'hidden_evolution_event_append_only'); END;
CREATE TRIGGER IF NOT EXISTS trg_hidden_evolution_event_no_delete
BEFORE DELETE ON hidden_evolution_event
BEGIN SELECT RAISE(ABORT, 'hidden_evolution_event_append_only'); END;
CREATE TRIGGER IF NOT EXISTS trg_hidden_evolution_sample_no_update
BEFORE UPDATE ON hidden_evolution_sample
BEGIN SELECT RAISE(ABORT, 'hidden_evolution_sample_append_only'); END;
CREATE TRIGGER IF NOT EXISTS trg_hidden_evolution_sample_no_delete
BEFORE DELETE ON hidden_evolution_sample
BEGIN SELECT RAISE(ABORT, 'hidden_evolution_sample_append_only'); END;
CREATE TRIGGER IF NOT EXISTS trg_hidden_evolution_ledger_insert
AFTER INSERT ON suppression_ledger
BEGIN
  INSERT OR IGNORE INTO hidden_evolution_item (
    id, hidden_item_id, category, case_id, run_id, tenant_id, workspace_id,
    source, source_ref, ledger_id, comparison_item_id, direct_item_id,
    platform_finding_id, rule_code, subject, issue_type, object_id,
    suppression_reason, hidden_reason, risk_level, hidden_at,
    evolution_status, label_strength, ttl_days, ttl_deadline,
    enqueue_source, feedback_enqueued, gold_eligible, calibration_eligible,
    threshold_eligible, no_gold, auto_threshold_change, auto_training,
    created_at, updated_at
  ) VALUES (
    'hev_' || NEW.id,
    NEW.id,
    'hidden',
    COALESCE(NEW.case_id, ''),
    COALESCE(NEW.run_id, ''),
    COALESCE(NEW.tenant_id, ''),
    COALESCE(NEW.workspace_id, ''),
    COALESCE(NEW.source, ''),
    NEW.id,
    NEW.id,
    COALESCE(NEW.comparison_item_id, ''),
    COALESCE(NEW.direct_item_id, ''),
    COALESCE(NEW.platform_finding_id, ''),
    COALESCE(NEW.rule_code, ''),
    COALESCE(NEW.subject, ''),
    COALESCE(NEW.issue_type, ''),
    COALESCE(NEW.object_id, ''),
    COALESCE(NEW.suppression_reason, ''),
    CASE COALESCE(NEW.suppression_reason, '')
      WHEN 'unverifiable_quote' THEN 'unverifiable_quote'
      WHEN 'unverifiable_computation' THEN 'unverifiable_quote'
      WHEN 'unverifiable_relation' THEN 'unverifiable_quote'
      WHEN 'missing_locator' THEN 'weak_locator'
      WHEN 'low_evidence_noncritical' THEN 'low_confidence'
      WHEN 'deterministic_refuted' THEN 'display_policy_filtered'
      ELSE 'display_policy_filtered' END,
    COALESCE(NEW.risk_level, 'medium'),
    COALESCE(NEW.created_at, ''),
    'pending',
    'none_pending',
    30,
    '',
    'trigger:suppression_ledger_insert',
    1, 0, 0, 0, 1, 0, 0,
    COALESCE(NEW.created_at, datetime('now', 'localtime')),
    COALESCE(NEW.created_at, datetime('now', 'localtime'))
  );
  INSERT OR IGNORE INTO hidden_evolution_event (
    id, item_id, hidden_item_id, case_id, action, actor, before_status, after_status,
    before_label_strength, after_label_strength, default_disposition, reason_code,
    reason, detail_json, source_event_id, created_at, immutable
  ) VALUES (
    'hev_e' || lower(hex(randomblob(8))),
    'hev_' || NEW.id,
    NEW.id,
    COALESCE(NEW.case_id, ''),
    'enqueued',
    'system:hidden_evolution',
    '',
    'pending',
    '',
    'none_pending',
    '',
    'hidden_created',
    '隐藏项创建即入进化池（DB 触发器兜底，不依赖 UI/人工动作；weak 默认，非 gold）',
    '{"via": "trigger:suppression_ledger_insert", "no_gold": true, "auto_threshold_change": false, "auto_training": false}',
    NULL,
    COALESCE(NEW.created_at, datetime('now', 'localtime')),
    1
  );
END;
"""


def _init_hidden_evolution_schema(c: sqlite3.Connection) -> dict:
    """幂等创建 T-52 隐藏项进化池表/索引/触发器（仅新增，不改既有表）。"""
    stats = {"tables": 0, "indexes": 0, "triggers": 0}
    before_t = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    before_i = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    c.executescript(HIDDEN_EVOLUTION_SCHEMA)
    after_t = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    after_i = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    stats["tables"] = len(after_t - before_t)
    stats["indexes"] = len(after_i - before_i)
    c.executescript(HIDDEN_EVOLUTION_TRIGGERS)
    stats["triggers"] = c.execute(
        "SELECT count(*) FROM sqlite_master WHERE type='trigger' "
        "AND (name LIKE 'trg_hidden_evolution_%')").fetchone()[0]
    return stats


# ---- T-75 规则进化知识库（20261118，仅新增两张表 + 索引，不改既有表）----
# 口径：
#   * 以工作空间为单位，知识库数据只按 (tenant_id, workspace_id) 隔离；
#   * 只有一级文件夹（knowledge_folder 无 parent_id、无嵌套），文件可归属一个文件夹或
#     根目录（folder_id=''）；删除文件夹不级联，需服务层确认后显式删除文件；
#   * 同空间同名文件夹唯一（DB 唯一索引兜底并发）；同空间同文件夹同内容文件唯一
#     （sha256 唯一索引兜底并发重复上传，幂等返回已存在记录）；
#   * 文件实体落盘 data/knowledge/<tenant>/<workspace>/，DB 只存相对 stored_name；
#   * 全部是 CREATE IF NOT EXISTS，旧库 init_db 幂等补表，不迁移/不改写既有数据。
#   * 2026-11-20 T-188：删除改为「回收站」软删（新增列，不重写既有行），
#     `deleted_at<>''` 即回收站中的记录；文件夹软删时把原名称存 orig_name，
#     名称列改为 `__deleted__<id>` 以释放唯一索引，供用户重建同名文件夹。
KNOWLEDGE_SCHEMA = """
CREATE TABLE IF NOT EXISTS knowledge_folder (
  id TEXT PRIMARY KEY,
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  name TEXT NOT NULL,
  created_by TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  deleted_at TEXT DEFAULT '',
  deleted_by TEXT DEFAULT '',
  deleted_via TEXT DEFAULT '',
  orig_name TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_kfolder_ws ON knowledge_folder(tenant_id, workspace_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_kfolder_ws_name ON knowledge_folder(tenant_id, workspace_id, name);
CREATE TABLE IF NOT EXISTS knowledge_file (
  id TEXT PRIMARY KEY,
  folder_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  filename TEXT NOT NULL,
  stored_name TEXT DEFAULT '',
  size INTEGER DEFAULT 0,
  sha256 TEXT DEFAULT '',
  mime TEXT DEFAULT '',
  uploaded_by TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  deleted_at TEXT DEFAULT '',
  deleted_by TEXT DEFAULT '',
  deleted_via TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_kfile_ws ON knowledge_file(tenant_id, workspace_id);
CREATE INDEX IF NOT EXISTS idx_kfile_folder ON knowledge_file(folder_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_kfile_ws_folder_sha ON knowledge_file(tenant_id, workspace_id, folder_id, sha256);
"""

# T-188 回收站列迁移（旧库 ALTER TABLE ADD COLUMN；幂等；可回滚，见交付说明）。
KNOWLEDGE_RECYCLE_COLUMNS = {
    "knowledge_folder": (("deleted_at", "TEXT DEFAULT ''"),
                         ("deleted_by", "TEXT DEFAULT ''"),
                         ("deleted_via", "TEXT DEFAULT ''"),
                         ("orig_name", "TEXT DEFAULT ''")),
    "knowledge_file": (("deleted_at", "TEXT DEFAULT ''"),
                       ("deleted_by", "TEXT DEFAULT ''"),
                       ("deleted_via", "TEXT DEFAULT ''")),
}


def _init_knowledge_schema(c: sqlite3.Connection) -> dict:
    """幂等创建 T-75 知识库表/索引（仅新增，不改既有表；旧库兼容）。

    T-188：旧库补回收站列（ALTER TABLE ADD COLUMN，幂等）+ 存活记录索引。
    """
    stats = {"tables": 0, "indexes": 0, "migrations": 0}
    before_t = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    before_i = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    c.executescript(KNOWLEDGE_SCHEMA)
    for table, cols in KNOWLEDGE_RECYCLE_COLUMNS.items():
        exists = [r[1] for r in c.execute(f"PRAGMA table_info({table})").fetchall()]
        if not exists:
            continue
        for col, ddl in cols:
            if col not in exists:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
                stats["migrations"] += 1
        # 历史行（回收站功能上线前）一律视为存活：deleted_at 为空即可，无需回填。
    c.execute("CREATE INDEX IF NOT EXISTS idx_kfile_alive ON "
              "knowledge_file(tenant_id, workspace_id, deleted_at)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_kfolder_alive ON "
              "knowledge_folder(tenant_id, workspace_id, deleted_at)")
    after_t = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    after_i = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    stats["tables"] = len(after_t - before_t)
    stats["indexes"] = len(after_i - before_i)
    return stats


# ---- P2 数据完整性/并发（20261118，仅新增表 + 索引 + 隔离列；不改既有行语义）----
#   * purge_execution：删除预览凭证的 jti 一次性抢占（P2-02）。jti 主键 INSERT
#     成功者才允许执行删除，杜绝并发双执行/重放；跨进程/重启后仍然有效；
#   * http_idempotency：HTTP Idempotency-Key 落库（P2-08）。key 主键 + scope 指纹，
#     重启/多进程仍生效；按 expires_at 过期清理，表容量有界；
#   * rule_point_mapping 增加 tenant_id/workspace_id 隔离列与索引（P2-17）。
P2_SCHEMA = """
CREATE TABLE IF NOT EXISTS purge_execution(
  jti TEXT PRIMARY KEY,
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  actor TEXT DEFAULT '',
  executed_at TEXT DEFAULT '',
  result_json TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS http_idempotency(
  key TEXT PRIMARY KEY,
  scope TEXT DEFAULT '',
  status INTEGER DEFAULT 200,
  body_b64 TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  expires_at REAL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_http_idem_exp ON http_idempotency(expires_at);
"""


def _init_p2_schema(c: sqlite3.Connection) -> dict:
    """幂等创建 P2 并发/幂等表 + rule_point_mapping 隔离列（旧库兼容）。"""
    stats = {"tables": 0, "indexes": 0, "migrations": 0}
    before_t = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    before_i = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    c.executescript(P2_SCHEMA)
    # rule_point_mapping 隔离列：旧库补列并按既有口径回填默认租户/空间；
    # 新库由 init_db 里 CREATE TABLE 直接带列（此处为幂等兜底）。
    cols = [r[1] for r in c.execute("PRAGMA table_info(rule_point_mapping)").fetchall()]
    if cols:
        for col, dv in (("tenant_id", "t-default"), ("workspace_id", "ws-default")):
            if col not in cols:
                c.execute(f"ALTER TABLE rule_point_mapping ADD COLUMN {col} TEXT DEFAULT ''")
                stats["migrations"] += 1
            c.execute(f"UPDATE rule_point_mapping SET {col}=? WHERE {col} IS NULL OR {col}=''",
                      (dv,))
    c.execute("CREATE INDEX IF NOT EXISTS idx_rpm_scope ON "
              "rule_point_mapping(tenant_id, workspace_id, rule_id)")
    after_t = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    after_i = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='index'").fetchall()}
    stats["tables"] = len(after_t - before_t)
    stats["indexes"] = len(after_i - before_i)
    return stats


def _platform_finding_view_sql(c: sqlite3.Connection) -> str:
    """既有 finding + evidence → 统一只读视图 platform_finding。

    列按当前库实际 schema 动态生成（老库/迁移差异不炸），证据做子查询聚合。
    """
    cols = {r[1] for r in c.execute("PRAGMA table_info(finding)").fetchall()}
    ordered = ["id", "case_id", "rule_id", "rule_version", "severity", "certainty",
               "confidence", "state", "status", "title", "summary", "suggestion",
               "grade", "engine", "run_id", "point_id", "object_id",
               "subrequirement_id", "manifest_result_id", "occurrence_count",
               "tenant_id", "workspace_id"]
    select = [f"f.{name} AS {name}" for name in ordered if name in cols]
    select += [
        "(SELECT r.code FROM rule r WHERE r.id = f.rule_id) AS rule_code",
        "(SELECT r.name FROM rule r WHERE r.id = f.rule_id) AS rule_name",
        "(SELECT group_concat(e.excerpt, char(10)) FROM evidence e "
        "WHERE e.finding_id = f.id) AS evidence_text",
        "(SELECT count(*) FROM evidence e WHERE e.finding_id = f.id) AS evidence_count",
        "(SELECT group_concat(e.anchor_id, '|') FROM evidence e WHERE e.finding_id = f.id "
        "AND COALESCE(e.anchor_id, '') <> '') AS anchor_ids",
        "(SELECT group_concat(e.label, '|') FROM evidence e WHERE e.finding_id = f.id "
        "AND COALESCE(e.label, '') <> '') AS evidence_labels",
    ]
    return "CREATE VIEW platform_finding AS SELECT " + ", ".join(select) + " FROM finding f"


def _init_dual_track_schema(c: sqlite3.Connection) -> dict:
    """幂等创建双轨数据表/触发器/platform_finding 视图（仅新增，不改既有表）。"""
    stats = {"tables": 0, "triggers": 0, "view": 0, "migrations": 0}
    before = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    c.executescript(DUAL_TRACK_SCHEMA)
    after = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    stats["tables"] = len(after - before)
    c.executescript(DUAL_TRACK_TRIGGERS)
    # V3.2 口径修复迁移（W-02，仅加列）：direct_item.quote_match_status 独立记录
    # quote 匹配四态（exact/exact_after_trim/normalized_ws/not_found）。
    try:
        _di_cols = [r[1] for r in c.execute("PRAGMA table_info(direct_item)").fetchall()]
        if "quote_match_status" not in _di_cols:
            c.execute("ALTER TABLE direct_item ADD COLUMN quote_match_status TEXT DEFAULT ''")
            stats["migrations"] += 1
    except Exception:
        logging.getLogger(__name__).warning("direct_item.quote_match_status migration failed",
                                            exc_info=True)
    stats["triggers"] = c.execute(
        "SELECT count(*) FROM sqlite_master WHERE type='trigger' "
        "AND (name LIKE 'trg_direct_%' OR name LIKE 'trg_suppression_%' "
        "OR name LIKE 'trg_adjudication_%')").fetchone()[0]
    try:
        # 视图无数据，每次 init 重建以跟随 finding 列迁移。
        c.execute("DROP VIEW IF EXISTS platform_finding")
        c.execute(_platform_finding_view_sql(c))
        stats["view"] = 1
    except Exception:  # 视图失败不影响既有主链；测试会显式校验
        logging.getLogger(__name__).warning("platform_finding view creation failed",
                                            exc_info=True)
    return stats


# ---------------------------------------------------------------------------
# L92（2026-11-24）：7 张核心 status 表的 DB 兜底（幂等迁移 + 触发器 + 遗留值报告）
#
# 背景（L88 G11）：rule/rule_version/audit_case/finding/audit_manifest/task_job/report
# 的 status 列无 DB CHECK/触发器，服务层是唯一防线；直接 SQL / 通用 repository 可写坏
# 状态（实测 rule.status='corrupt_demo' 成功）。本段在 init_db 末尾幂等执行：
#   1) report 表补 status 列（旧库 ALTER；新库 SCHEMA 已带，DEFAULT 'generated'）；
#   2) 每表建 BEFORE INSERT / BEFORE UPDATE OF status 触发器：值域 = 规范态 ∪ 遗留别名
#      （值域来自 app/services/state_machines.py 单一事实源；用文件路径加载避免
#      app.db ↔ app.services 包循环依赖）；空串/缺省列放行（走 DB 默认值）；
#   3) 只做**值域**兜底，不强制迁移方向（迁移方向由服务层/BaseRepo 校验）：测试夹具
#      常直接 INSERT 目标态（status='completed'），若 DB 强制方向会破坏夹具；
#   4) notification.read 位 0/1 兜底；
#   5) 既有非法值**保留不改**，写入 state_legacy_report（幂等重算）供人工迁移/报告，
#      不静默清洗历史数据。
# 回滚：DROP TRIGGER trg_state_* / DROP TABLE state_legacy_report；report.status 列
# 保留不影响旧代码（旧代码不读该列）。
# ---------------------------------------------------------------------------
_STATE_MACHINES_MOD = None


def _state_machines_mod():
    """按文件路径加载状态机单一事实源（不触发 app.services 包 __init__ 循环）。"""
    global _STATE_MACHINES_MOD
    if _STATE_MACHINES_MOD is not None:
        return _STATE_MACHINES_MOD
    import importlib.util
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "services", "state_machines.py")
    spec = importlib.util.spec_from_file_location("_ruleproof_state_machines", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _STATE_MACHINES_MOD = mod
    return mod


def _sql_literal(value) -> str:
    """把状态值转成 SQL 字面量（仅用于本段生成 DDL，值来自代码常量，非用户输入）。"""
    if isinstance(value, (int, float)):
        return str(value)
    return "'" + str(value).replace("'", "''") + "'"


def _status_guard_ddl(table: str, column: str, values, kind: str) -> str:
    """生成某表/列的值域触发器 DDL（幂等 CREATE TRIGGER IF NOT EXISTS）。"""
    vals = ",".join(_sql_literal(v) for v in values)
    tag = f"{table}_{column}"
    msg = f"invalid_state_value:{table}.{column}" + (f":{kind}" if kind else "")
    return f"""
CREATE TRIGGER IF NOT EXISTS trg_state_{tag}_insert
BEFORE INSERT ON {table}
WHEN NEW.{column} IS NOT NULL AND NEW.{column} <> '' AND NEW.{column} NOT IN ({vals})
BEGIN SELECT RAISE(ABORT, '{msg}'); END;
CREATE TRIGGER IF NOT EXISTS trg_state_{tag}_update
BEFORE UPDATE OF {column} ON {table}
WHEN NEW.{column} IS NOT NULL AND NEW.{column} <> '' AND NEW.{column} NOT IN ({vals})
BEGIN SELECT RAISE(ABORT, '{msg}'); END;
"""


def _table_columns(c, table: str) -> list:
    try:
        return [r[1] for r in c.execute(f"PRAGMA table_info({table})").fetchall()]
    except Exception:
        return []


def state_legacy_scan(conn=None) -> dict:
    """扫描 7 张状态表的既有非法值（只读）。返回 {table: {value: count}}。

    供 QA/运维报告用：既有非法值不修改（保留历史值），由本函数与
    ``state_legacy_report`` 表暴露，交人工迁移决策。
    """
    sm = _state_machines_mod()
    own = conn is None
    c = conn or connect()
    out = {}
    try:
        for table, (column, kind) in sm.DB_STATUS_COLUMNS.items():
            if column not in _table_columns(c, table):
                continue
            allowed = list(sm.allowed_values(kind))
            ph = ",".join("?" * len(allowed))
            rows = c.execute(
                f"SELECT {column}, COUNT(*) FROM {table} "
                f"WHERE {column} IS NOT NULL AND {column} <> '' "
                f"AND {column} NOT IN ({ph}) GROUP BY {column}", tuple(allowed)).fetchall()
            if rows:
                out[table] = {str(r[0]): int(r[1]) for r in rows}
        for table, (column, values) in sm.DB_BIT_COLUMNS.items():
            if column not in _table_columns(c, table):
                continue
            ph = ",".join("?" * len(values))
            rows = c.execute(
                f"SELECT {column}, COUNT(*) FROM {table} "
                f"WHERE {column} IS NOT NULL AND {column} NOT IN ({ph}) "
                f"GROUP BY {column}", tuple(values)).fetchall()
            if rows:
                out[table] = {str(r[0]): int(r[1]) for r in rows}
    finally:
        if own:
            c.close()
    return out


def _init_state_guard_schema(c: sqlite3.Connection) -> dict:
    """幂等安装 7 张核心状态表 DB 兜底（report.status 列 + 值域触发器 + 遗留值报告）。"""
    sm = _state_machines_mod()
    stats = {"triggers": 0, "migrations": 0, "legacy_values": 0, "legacy_rows": 0}
    # 1) report.status 列（旧库补列；新库 SCHEMA 已带）
    cols = _table_columns(c, "report")
    if cols and "status" not in cols:
        c.execute("ALTER TABLE report ADD COLUMN status TEXT DEFAULT 'generated'")
        stats["migrations"] += 1
    # 2) 值域触发器（7 张核心 status 表 + notification.read 位）
    for table, column, kind, values in sm.db_guard_specs():
        if column not in _table_columns(c, table):
            logging.getLogger(__name__).warning(
                "state guard 跳过：表/列不存在 %s.%s", table, column)
            continue
        c.executescript(_status_guard_ddl(table, column, values, kind))
        stats["triggers"] += c.execute(
            "SELECT count(*) FROM sqlite_master WHERE type='trigger' "
            "AND name IN (?,?)",
            (f"trg_state_{table}_{column}_insert",
             f"trg_state_{table}_{column}_update")).fetchone()[0]
    # 3) 遗留值报告表（幂等重算；不修改历史行）
    c.execute("""
CREATE TABLE IF NOT EXISTS state_legacy_report(
  id TEXT PRIMARY KEY,
  table_name TEXT NOT NULL,
  column_name TEXT NOT NULL,
  value TEXT NOT NULL,
  row_count INTEGER DEFAULT 0,
  detected_at TEXT DEFAULT ''
);
""")
    c.execute("DELETE FROM state_legacy_report")
    stamp = now()
    for table, values in state_legacy_scan(c).items():
        for value, cnt in values.items():
            c.execute(
                "INSERT OR REPLACE INTO state_legacy_report"
                "(id,table_name,column_name,value,row_count,detected_at) "
                "VALUES(?,?,?,?,?,?)",
                (f"{table}:{value}", table, "status", value, int(cnt), stamp))
            stats["legacy_values"] += 1
            stats["legacy_rows"] += int(cnt)
    return stats


def now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def new_id(prefix: str = "") -> str:
    return prefix + uuid.uuid4().hex[:12]


# ---------------------------------------------------------------------------
# L93（2026-11-24）核心单据模型 DB 字段修复
#
# 只加列/索引/新表/触发器，不改任何历史业务行：
#   * finding：created_by/created_at/source/source_kind/rule_version_id（来源四要素 +
#     权威版本行；manifest_result_id 早已有列，本文负责新写点与历史回填）；
#   * report：created_by/created_at/signed_by/signed_at/content_hash/exported_by/
#     exported_hash（签发模型；status 由 L92 提供）；
#   * rule：created_by；rule_version：published_by；
#   * 监控表 docmodel_health_report（空值率/解析率/重复码/0 行报告快照，幂等重算）/
#     reference_orphan_alert（finding 物理删除的新增悬挂引用告警，不改历史）/
#     data_backfill_log（data_migrations 回填批次记录）；
#   * 触发器：
#       - finding AFTER INSERT：语义直 SQL/seed 等非 Repository 写路径的来源字段兜底
#         补全（有 Repository 写点时已显式写值，条件不满足 → 不触发）；
#       - finding AFTER DELETE：把被删除 finding 仍被 feedback/decision/evidence/
#         finding_certificate/evolution_task/audit_log 引用的事实写进告警表
#         （只记录新增删除，不修改历史行、不阻断删除）；
#   * 历史数据回填不在这里自动执行：必须显式
#     ``python -m app.data_migrations --docmodel-backfill --dry-run|--apply``。
# ---------------------------------------------------------------------------
DOCMODEL_SCHEMA = """
CREATE TABLE IF NOT EXISTS docmodel_health_report (
  id TEXT PRIMARY KEY, table_name TEXT NOT NULL, column_name TEXT NOT NULL,
  metric TEXT NOT NULL, total_rows INTEGER DEFAULT 0, empty_rows INTEGER DEFAULT 0,
  empty_rate REAL, detail TEXT DEFAULT '', detected_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_docmodel_health_table
  ON docmodel_health_report(table_name, metric);
CREATE TABLE IF NOT EXISTS reference_orphan_alert (
  id TEXT PRIMARY KEY, finding_id TEXT NOT NULL, ref_table TEXT NOT NULL,
  ref_count INTEGER DEFAULT 0, detected_at TEXT DEFAULT '',
  source TEXT DEFAULT 'finding_delete_trigger', detail TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_orphan_alert_finding
  ON reference_orphan_alert(finding_id);
CREATE INDEX IF NOT EXISTS idx_orphan_alert_table
  ON reference_orphan_alert(ref_table, detected_at);
CREATE TABLE IF NOT EXISTS data_backfill_log (
  id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, lane TEXT DEFAULT 'L93',
  mode TEXT NOT NULL, table_name TEXT DEFAULT '', column_name TEXT DEFAULT '',
  candidate_rows INTEGER DEFAULT 0, filled_rows INTEGER DEFAULT 0,
  skipped_rows INTEGER DEFAULT 0, detail_json TEXT DEFAULT '{}',
  actor TEXT DEFAULT '', created_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_data_backfill_batch
  ON data_backfill_log(batch_id, created_at);
"""

# 触发器：SQLite 触发器内不能用 db.now()，用 strftime 等价格式（本地时间）。
DOCMODEL_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS trg_finding_provenance_fill
AFTER INSERT ON finding
WHEN COALESCE(NEW.created_at,'')='' OR COALESCE(NEW.created_by,'')=''
  OR COALESCE(NEW.source,'')='' OR COALESCE(NEW.source_kind,'')=''
  OR COALESCE(NEW.rule_version_id,'')='' OR COALESCE(NEW.manifest_result_id,'')=''
BEGIN
  UPDATE finding SET
    created_at = CASE WHEN COALESCE(NEW.created_at,'')<>'' THEN NEW.created_at
      ELSE COALESCE((SELECT r.created_at FROM audit_run r WHERE r.id=NEW.run_id),
                    strftime('%Y-%m-%d %H:%M:%S','now','localtime'), '') END,
    created_by = CASE WHEN COALESCE(NEW.created_by,'')<>'' THEN NEW.created_by
      ELSE COALESCE((SELECT r.created_by FROM audit_run r WHERE r.id=NEW.run_id),
                    (SELECT c.created_by FROM audit_case c WHERE c.id=NEW.case_id),
                    'system') END,
    source = CASE WHEN COALESCE(NEW.source,'')<>'' THEN NEW.source
      WHEN COALESCE(NEW.engine,'') LIKE 'manifest%' THEN 'manifest_exec'
      WHEN COALESCE(NEW.engine,'') LIKE 'semantic_core%' THEN 'semantic_core'
      WHEN NEW.engine='manual' THEN 'manual_review'
      WHEN NEW.engine='manual_history' THEN 'seed_manual'
      WHEN NEW.engine IN ('demo_complex','demo_project_doc','demo_extra') THEN 'seed_demo'
      WHEN NEW.engine='deterministic' THEN 'legacy_engine'
      ELSE 'direct_insert' END,
    source_kind = CASE WHEN COALESCE(NEW.source_kind,'')<>'' THEN NEW.source_kind
      WHEN COALESCE(NEW.engine,'') LIKE 'manifest%' THEN 'run'
      WHEN COALESCE(NEW.engine,'') LIKE 'semantic_core%' THEN 'run'
      WHEN NEW.engine='manual' THEN 'manual'
      WHEN NEW.engine IN ('manual_history','demo_complex',
                          'demo_project_doc','demo_extra') THEN 'import'
      WHEN NEW.engine='deterministic' THEN 'run'
      ELSE 'direct' END,
    rule_version_id = CASE
      WHEN COALESCE(NEW.rule_version_id,'')<>'' THEN NEW.rule_version_id
      ELSE COALESCE(
        (SELECT rv.id FROM rule_version rv
          WHERE rv.rule_id IN (SELECT id FROM rule WHERE id=NEW.rule_id OR code=NEW.rule_id)
            AND rv.version=COALESCE(NEW.rule_version,'')
            AND (SELECT COUNT(*) FROM rule_version x WHERE x.rule_id IN
                   (SELECT id FROM rule WHERE id=NEW.rule_id OR code=NEW.rule_id))=1
          LIMIT 1),
        (SELECT rv.id FROM rule_version rv
          WHERE rv.rule_id IN (SELECT id FROM rule WHERE id=NEW.rule_id OR code=NEW.rule_id)
            AND (SELECT COUNT(*) FROM rule_version x WHERE x.rule_id IN
                   (SELECT id FROM rule WHERE id=NEW.rule_id OR code=NEW.rule_id))=1
          LIMIT 1), '') END,
    manifest_result_id = CASE
      WHEN COALESCE(NEW.manifest_result_id,'')<>'' THEN NEW.manifest_result_id
      ELSE COALESCE(
        (SELECT mr.id FROM manifest_result mr
          JOIN audit_run r ON r.manifest_id=mr.manifest_id
          WHERE r.id=NEW.run_id AND mr.rule_code=NEW.rule_id
            AND COALESCE(mr.object_id,'')=COALESCE(NEW.object_id,'')
            AND (SELECT COUNT(*) FROM manifest_result mr2
                   JOIN audit_run r2 ON r2.manifest_id=mr2.manifest_id
                 WHERE r2.id=NEW.run_id AND mr2.rule_code=NEW.rule_id
                   AND COALESCE(mr2.object_id,'')=COALESCE(NEW.object_id,''))=1
          LIMIT 1), '') END
  WHERE id=NEW.id;
END;
CREATE TRIGGER IF NOT EXISTS trg_finding_delete_orphan_alert
AFTER DELETE ON finding
BEGIN
  INSERT OR IGNORE INTO reference_orphan_alert
    (id,finding_id,ref_table,ref_count,detected_at,source,detail)
  SELECT 'feedback|'||OLD.id, OLD.id, 'feedback', COUNT(*),
         strftime('%Y-%m-%d %H:%M:%S','now','localtime'),
         'finding_delete_trigger', 'feedback.finding_id 在 finding 物理删除后悬挂'
  FROM feedback WHERE finding_id=OLD.id HAVING COUNT(*)>0;
  INSERT OR IGNORE INTO reference_orphan_alert
    (id,finding_id,ref_table,ref_count,detected_at,source,detail)
  SELECT 'decision|'||OLD.id, OLD.id, 'decision', COUNT(*),
         strftime('%Y-%m-%d %H:%M:%S','now','localtime'),
         'finding_delete_trigger', 'decision.finding_id 在 finding 物理删除后悬挂'
  FROM decision WHERE finding_id=OLD.id HAVING COUNT(*)>0;
  INSERT OR IGNORE INTO reference_orphan_alert
    (id,finding_id,ref_table,ref_count,detected_at,source,detail)
  SELECT 'evidence|'||OLD.id, OLD.id, 'evidence', COUNT(*),
         strftime('%Y-%m-%d %H:%M:%S','now','localtime'),
         'finding_delete_trigger', 'evidence.finding_id 在 finding 物理删除后悬挂'
  FROM evidence WHERE finding_id=OLD.id HAVING COUNT(*)>0;
  INSERT OR IGNORE INTO reference_orphan_alert
    (id,finding_id,ref_table,ref_count,detected_at,source,detail)
  SELECT 'cert|'||OLD.id, OLD.id, 'finding_certificate', COUNT(*),
         strftime('%Y-%m-%d %H:%M:%S','now','localtime'),
         'finding_delete_trigger', 'finding_certificate.finding_id 在 finding 物理删除后悬挂'
  FROM finding_certificate WHERE finding_id=OLD.id HAVING COUNT(*)>0;
  INSERT OR IGNORE INTO reference_orphan_alert
    (id,finding_id,ref_table,ref_count,detected_at,source,detail)
  SELECT 'evo|'||OLD.id, OLD.id, 'evolution_task', COUNT(*),
         strftime('%Y-%m-%d %H:%M:%S','now','localtime'),
         'finding_delete_trigger', 'evolution_task.finding_id 在 finding 物理删除后悬挂'
  FROM evolution_task WHERE finding_id=OLD.id HAVING COUNT(*)>0;
  INSERT OR IGNORE INTO reference_orphan_alert
    (id,finding_id,ref_table,ref_count,detected_at,source,detail)
  SELECT 'audit|'||OLD.id, OLD.id, 'audit_log', COUNT(*),
         strftime('%Y-%m-%d %H:%M:%S','now','localtime'),
         'finding_delete_trigger', 'audit_log.object 仍指向已物理删除的 finding'
  FROM audit_log WHERE object=OLD.id HAVING COUNT(*)>0;
END;
"""


def _init_docmodel_schema(c: sqlite3.Connection) -> dict:
    """幂等安装 L93 单据模型字段/索引/监控表/触发器，并刷新监控快照。

    - 老库缺列 → ALTER 补列（默认空串/0，不改历史行）；
    - 新表/索引/触发器一律 IF NOT EXISTS；
    - 监控快照表 docmodel_health_report 幂等重算（沿用 L92 state_legacy_report 口径）；
    - 失败不静默：由 init_db 调用方 fail-fast。
    """
    stats = {"columns": 0, "tables": 0, "indexes": 0, "triggers": 0, "health": None}
    add_columns = {
        "finding": [("created_by", "TEXT DEFAULT ''"), ("created_at", "TEXT DEFAULT ''"),
                    ("source", "TEXT DEFAULT ''"), ("source_kind", "TEXT DEFAULT ''"),
                    ("rule_version_id", "TEXT DEFAULT ''")],
        "report": [("created_by", "TEXT DEFAULT ''"), ("created_at", "TEXT DEFAULT ''"),
                   ("signed_by", "TEXT DEFAULT ''"), ("signed_at", "TEXT DEFAULT ''"),
                   ("content_hash", "TEXT DEFAULT ''"),
                   ("exported_by", "TEXT DEFAULT ''"), ("exported_hash", "TEXT DEFAULT ''")],
        "rule": [("created_by", "TEXT DEFAULT ''")],
        "rule_version": [("published_by", "TEXT DEFAULT ''")],
    }
    for table, cols in add_columns.items():
        have = _table_columns(c, table)
        if not have:
            continue
        for col, ddl in cols:
            if col in have:
                continue
            try:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
                stats["columns"] += 1
            except sqlite3.Error as exc:
                raise RuntimeError(
                    f"L93 迁移失败：ALTER TABLE {table} ADD COLUMN {col}：{exc}") from exc
    before_tables = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    c.executescript(DOCMODEL_SCHEMA)
    after_tables = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    stats["tables"] = len(after_tables - before_tables)
    stats["indexes"] = int(c.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='index' "
        "AND name IN ('idx_docmodel_health_table','idx_orphan_alert_finding',"
        "'idx_orphan_alert_table','idx_data_backfill_batch')").fetchone()[0] or 0)
    # 业务字段索引：新写点/体检查询用（列不存在时跳过，老库由 data_migrations 再补）
    for table, idx, cols in (
            ("finding", "idx_finding_manifest_result", ("manifest_result_id",)),
            ("finding", "idx_finding_rule_version", ("rule_version_id",)),
            ("finding", "idx_finding_source_kind", ("source_kind",)),
            ("finding", "idx_finding_created_at", ("created_at",)),
            ("report", "idx_report_case_status", ("case_id", "status")),
            ("audit_run", "idx_audit_run_manifest", ("manifest_id",))):
        have = _table_columns(c, table)
        if not have or any(x not in have for x in cols):
            continue
        try:
            c.execute(f'CREATE INDEX IF NOT EXISTS "{idx}" ON "{table}"'
                      f'({",".join(cols)})')
            stats["indexes"] += 1
        except sqlite3.Error:
            logging.getLogger(__name__).warning(
                "L93 索引创建跳过 %s", idx, exc_info=True)
    c.executescript(DOCMODEL_TRIGGERS)
    stats["triggers"] = int(c.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' "
        "AND name IN ('trg_finding_provenance_fill','trg_finding_delete_orphan_alert')"
    ).fetchone()[0] or 0)
    try:
        from . import docmodel as _docmodel
        stats["health"] = _docmodel.refresh_health(c)
    except Exception as exc:  # noqa: BLE001 —— 监控刷新失败不阻断建库，但必须显式
        logging.getLogger(__name__).warning(
            "L93 监控快照刷新失败（schema 已就绪）：%s", exc, exc_info=True)
        stats["health"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return stats


# ---------------------------------------------------------------------------
# L94（2026-11-24）：DB 迁移单一事实源 / schema drift 报告 / 重复数据监控
#
# 背景（90 号 §二-4 / L93 遗留）：
#   * 产品库 data/ruleproof.db 的 schema 落后于 init_db 新库（L92/L93 列/表/触发器未在
#     产品库执行），需要**只读差异报告**而不是自动改产品库；
#   * rule.code / document.hash / point_state(batch_id,point_id) 存在历史重复数据，
#     不能加唯一约束破坏历史（尤其 rule.code 150 组/424 行），只能加**非唯一索引**
#     + 监控报表（duplicate_monitor_report，可追溯）；
#   * 版本化迁移目录（data_migrations.MIGRATIONS）必须与 init_db 实际建出的对象一致，
#     由 scripts/qa/schema_drift_test.py 交叉校验（单一事实源）。
# ---------------------------------------------------------------------------
L94_MONITOR_SCHEMA = """
CREATE TABLE IF NOT EXISTS duplicate_monitor_report (
  id TEXT PRIMARY KEY,
  table_name TEXT NOT NULL,
  key_columns TEXT NOT NULL,
  label TEXT DEFAULT '',
  total_rows INTEGER DEFAULT 0,
  dup_groups INTEGER DEFAULT 0,
  dup_rows INTEGER DEFAULT 0,
  top_json TEXT DEFAULT '[]',
  detected_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_duplicate_monitor_table
  ON duplicate_monitor_report(table_name, detected_at);
"""

# 非唯一索引：加速“按规则码/文档哈希/点位重复”的监控查询；**不**加 UNIQUE，
# 历史重复数据原样保留（强制唯一会把产品库变成不可启动）。
L94_MONITOR_INDEXES = (
    ("idx_rule_code_nonunique", "rule", ("code",)),
    ("idx_document_hash_nonunique", "document", ("hash",)),
    ("idx_point_state_batch_point_nonunique", "point_state", ("batch_id", "point_id")),
)

# 重复数据监控口径（table, key_columns, label）；key 列全为空的行不参与重复统计。
L94_DUP_MONITOR_TARGETS = (
    ("rule", ("code",), "规则编码（rule.code；历史 150 组/424 行，只监控不唯一化）"),
    ("document", ("hash",), "文档内容哈希（document.hash；同文件多项目复用）"),
    ("point_state", ("batch_id", "point_id"), "审核批次点位（point_state.batch_id+point_id）"),
)


def _init_l94_monitor_schema(c: sqlite3.Connection) -> dict:
    """L94：幂等安装重复数据监控表 + 非唯一索引（init_db 每次启动幂等执行）。"""
    stats = {"tables": 0, "indexes": 0}
    before = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    c.executescript(L94_MONITOR_SCHEMA)
    after = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    stats["tables"] = len(after - before)
    for idx, table, cols in L94_MONITOR_INDEXES:
        have = _table_columns(c, table)
        if not have or any(x not in have for x in cols):
            continue
        try:
            c.execute(f'CREATE INDEX IF NOT EXISTS "{idx}" ON "{table}"'
                      f'({",".join(cols)})')
            stats["indexes"] += 1
        except sqlite3.Error:
            logging.getLogger(__name__).warning(
                "L94 监控索引创建跳过 %s", idx, exc_info=True)
    return stats


def _open_ro(db_path) -> sqlite3.Connection:
    """只读打开 SQLite（schema 监控/漂移报告绝不写产品库）。"""
    conn = sqlite3.connect("file:%s?mode=ro" % str(db_path), uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def schema_snapshot(db_path) -> dict:
    """只读 schema 快照：表→列（名/类型/notnull/默认值）、索引→表、触发器名。

    返回结构稳定、可直接 diff / JSON 序列化（schema_drift_test 机读产物）。
    """
    path = Path(db_path)
    conn = _open_ro(path)
    try:
        tables: dict[str, dict] = {}
        for name in [str(r[0]) for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' "
                "AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]:
            cols = {}
            for r in conn.execute('PRAGMA table_info("%s")' % name).fetchall():
                cols[str(r[1])] = {"type": str(r[2] or ""),
                                   "notnull": int(r[3] or 0),
                                   "default": r[4],
                                   "pk": int(r[5] or 0)}
            tables[name] = {"columns": cols}
        indexes: dict[str, str] = {}
        for r in conn.execute(
                "SELECT name, tbl_name FROM sqlite_master WHERE type='index' "
                "AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall():
            indexes[str(r[0])] = str(r[1])
        triggers = sorted(str(r[0]) for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='trigger' "
            "AND name NOT LIKE 'sqlite_%'").fetchall())
    finally:
        conn.close()
    return {"path": str(path), "exists": path.exists(),
            "tables": tables, "indexes": indexes, "triggers": triggers}


def _cols_of(snap: dict, table: str) -> set:
    return set(((snap.get("tables") or {}).get(table) or {}).get("columns") or {})


def schema_diff(a_snap: dict, b_snap: dict, a_label: str = "a",
                b_label: str = "b") -> dict:
    """两份 schema 快照差异（以 b 为“期望新库”，报告 a 缺什么/多什么）。"""
    a_tables = set((a_snap.get("tables") or {}).keys())
    b_tables = set((b_snap.get("tables") or {}).keys())
    missing_tables = sorted(b_tables - a_tables)
    extra_tables = sorted(a_tables - b_tables)
    missing_columns: dict[str, list] = {}
    extra_columns: dict[str, list] = {}
    for t in sorted(a_tables & b_tables):
        a_cols, b_cols = _cols_of(a_snap, t), _cols_of(b_snap, t)
        if b_cols - a_cols:
            missing_columns[t] = sorted(b_cols - a_cols)
        if a_cols - b_cols:
            extra_columns[t] = sorted(a_cols - b_cols)
    a_idx = set((a_snap.get("indexes") or {}).keys())
    b_idx = set((b_snap.get("indexes") or {}).keys())
    missing_indexes = sorted(b_idx - a_idx)
    extra_indexes = sorted(a_idx - b_idx)
    a_trg = set(a_snap.get("triggers") or [])
    b_trg = set(b_snap.get("triggers") or [])
    missing_triggers = sorted(b_trg - a_trg)
    extra_triggers = sorted(a_trg - b_trg)
    drift = (len(missing_tables) + len(extra_tables)
             + sum(len(v) for v in missing_columns.values())
             + sum(len(v) for v in extra_columns.values())
             + len(missing_indexes) + len(extra_indexes)
             + len(missing_triggers) + len(extra_triggers))
    return {"a_label": a_label, "b_label": b_label,
            "missing_in_a": {"tables": missing_tables,
                             "columns": missing_columns,
                             "indexes": missing_indexes,
                             "triggers": missing_triggers},
            "extra_in_a": {"tables": extra_tables,
                           "columns": extra_columns,
                           "indexes": extra_indexes,
                           "triggers": extra_triggers},
            "drift_count": drift,
            "identical": drift == 0}


def migration_records(db_path) -> dict:
    """版本化迁移记录 vs 代码目录（只读）：已执行/缺失/多余（单一事实源监控）。"""
    path = Path(db_path)
    applied, available = [], False
    try:
        conn = _open_ro(path)
        try:
            try:
                rows = conn.execute(
                    "SELECT version,name,checksum,applied_at FROM schema_migration "
                    "ORDER BY applied_at,version").fetchall()
                available = True
                applied = [{"id": str(r["version"]), "name": str(r["name"] or ""),
                            "checksum": str(r["checksum"] or ""),
                            "applied_at": str(r["applied_at"] or "")}
                           for r in rows]
            except sqlite3.Error:
                available = False
        finally:
            conn.close()
    except sqlite3.Error:
        available = False
    expected: list[str] = []
    try:
        from . import data_migrations as _dm
        expected = [str(m["id"]) for m in _dm.migration_catalog()]
    except Exception:  # noqa: BLE001 - 迁移目录不可用时保持空（上层显式报告）
        expected = []
    try:
        from . import docmodel as _docmodel
        if _docmodel.MIGRATION_ID not in expected:
            expected.append(str(_docmodel.MIGRATION_ID))
    except Exception:  # noqa: BLE001
        pass
    applied_ids = [x["id"] for x in applied]
    return {"available": available, "applied": applied,
            "expected": expected,
            "missing": [x for x in expected if x not in applied_ids],
            "unexpected": [x for x in applied_ids if x not in expected]}


def schema_drift_report(db_path=None, fresh_path=None, cleanup: bool = True) -> dict:
    """产品库（只读） vs init_db 新库的 schema 差异报告（**不自动改产品库**）。

    - 默认 fresh 库在系统临时目录新建；调用方也可传入 ``fresh_path``（测试用）。
    - 产品库只以 ``mode=ro`` 打开，本函数不写产品库（调用方另做指纹三同断言）。
    """
    import tempfile
    import time as _t
    product_path = Path(db_path or DB_PATH)
    stale = {"ok": False, "db": str(product_path)}
    if not product_path.exists():
        stale.update({"code": "db_not_found",
                      "error": "数据库不存在：%s" % product_path})
        return stale
    tmp_dir = None
    fresh = Path(fresh_path) if fresh_path else None
    try:
        product_snap = schema_snapshot(product_path)
        if fresh is None:
            tmp_dir = tempfile.mkdtemp(prefix="rp_schema_fresh_")
            fresh = Path(tmp_dir) / "fresh.sqlite"
        fconn = sqlite3.connect(str(fresh))
        try:
            init_db(fconn, skip_product_guard=True)
        finally:
            fconn.close()
        fresh_snap = schema_snapshot(fresh)
        diff = schema_diff(product_snap, fresh_snap,
                           a_label="product:%s" % product_path,
                           b_label="fresh:init_db")
        return {"ok": True,
                "generated_at": _t.strftime("%Y-%m-%d %H:%M:%S"),
                "product": {"path": str(product_path),
                            "tables": len(product_snap["tables"]),
                            "indexes": len(product_snap["indexes"]),
                            "triggers": len(product_snap["triggers"])},
                "fresh": {"path": str(fresh),
                          "tables": len(fresh_snap["tables"]),
                          "indexes": len(fresh_snap["indexes"]),
                          "triggers": len(fresh_snap["triggers"])},
                "missing_in_product": diff["missing_in_a"],
                "extra_in_product": diff["extra_in_a"],
                "drift_count": diff["drift_count"],
                "identical": diff["identical"],
                "action": "monitor_only（不自动修改产品库；执行迁移需显式 "
                          "python -m app.data_migrations --db <库> 并先备份）",
                "migrations": migration_records(product_path)}
    except Exception as exc:  # noqa: BLE001 —— 报告失败必须显式，不静默
        stale.update({"code": "schema_drift_failed",
                      "error": "%s: %s" % (type(exc).__name__, exc)})
        return stale
    finally:
        if cleanup and tmp_dir:
            import shutil as _sh
            _sh.rmtree(tmp_dir, ignore_errors=True)


def duplicate_report(db_path=None) -> dict:
    """重复数据监控报表（只读）：rule.code / document.hash / point_state。

    返回每组重复的组数/行数/Top10；不写库、不修改历史重复数据。
    """
    import time as _t
    path = Path(db_path or DB_PATH)
    out = {"ok": False, "db": str(path), "generated_at": "", "metrics": []}
    if not path.exists():
        out.update({"code": "db_not_found",
                    "error": "数据库不存在：%s" % path})
        return out
    conn = _open_ro(path)
    try:
        metrics = []
        for table, cols, label in L94_DUP_MONITOR_TARGETS:
            have = _table_columns(conn, table)
            item = {"table": table, "key_columns": list(cols), "label": label,
                    "available": bool(have) and all(c in have for c in cols)}
            if not item["available"]:
                item.update({"missing_columns": [c for c in cols if c not in have],
                             "total_rows": 0, "dup_groups": 0, "dup_rows": 0,
                             "top": []})
                metrics.append(item)
                continue
            key_sql = ", ".join(chr(34) + c + chr(34) for c in cols)
            where = " AND ".join('COALESCE("%s",\'\')<>\'\'' % c for c in cols)
            total = conn.execute('SELECT COUNT(*) FROM "%s"' % table).fetchone()[0]
            dup_groups = conn.execute(
                'SELECT COUNT(*) FROM (SELECT %s FROM "%s" WHERE %s GROUP BY %s '
                "HAVING COUNT(*)>1)" % (key_sql, table, where, key_sql)).fetchone()[0]
            dup_rows = conn.execute(
                "SELECT COALESCE(SUM(c),0) FROM (SELECT COUNT(*) c FROM \"%s\" "
                "WHERE %s GROUP BY %s HAVING COUNT(*)>1)"
                % (table, where, key_sql)).fetchone()[0]
            top_rows = conn.execute(
                "SELECT %s, COUNT(*) AS cnt FROM \"%s\" WHERE %s GROUP BY %s "
                "HAVING COUNT(*)>1 ORDER BY cnt DESC LIMIT 10"
                % (key_sql, table, where, key_sql)).fetchall()
            top = [{**{c: r[c] for c in cols}, "count": int(r["cnt"])} for r in top_rows]
            item.update({"total_rows": int(total), "dup_groups": int(dup_groups),
                         "dup_rows": int(dup_rows), "top": top})
            metrics.append(item)
        out.update({"ok": True, "generated_at": _t.strftime("%Y-%m-%d %H:%M:%S"),
                    "metrics": metrics})
        return out
    except sqlite3.Error as exc:
        out.update({"code": "duplicate_report_failed",
                    "error": "%s: %s" % (type(exc).__name__, exc)})
        return out
    finally:
        conn.close()


def record_duplicate_monitor(db_path=None, metrics: list | None = None) -> dict:
    """把重复监控结果写入 duplicate_monitor_report（只写监控表；产品库拒绝）。"""
    import json as _json
    import time as _t
    path = Path(db_path or DB_PATH)
    try:
        resolved = path.resolve()
    except Exception:
        resolved = path
    try:
        product = DEFAULT_DB_PATH.resolve()
    except Exception:
        product = DEFAULT_DB_PATH
    if resolved == product:
        return {"ok": False, "code": "product_db_write_forbidden",
                "error": "重复监控记录不得直接写产品库（铁律 6）：请对 /tmp 副本执行"}
    rep = duplicate_report(path) if metrics is None else {
        "ok": True, "db": str(path), "metrics": list(metrics)}
    if not rep.get("ok"):
        return rep
    stamp = _t.strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(str(path), timeout=30)
    try:
        conn.executescript(L94_MONITOR_SCHEMA)
        n = 0
        for m in rep.get("metrics") or []:
            conn.execute(
                "INSERT INTO duplicate_monitor_report(id,table_name,key_columns,label,"
                "total_rows,dup_groups,dup_rows,top_json,detected_at) "
                "VALUES(?,?,?,?,?,?,?,?,?)",
                (new_id("dmon"), str(m.get("table") or ""),
                 _json.dumps(m.get("key_columns") or [], ensure_ascii=False),
                 str(m.get("label") or ""), int(m.get("total_rows") or 0),
                 int(m.get("dup_groups") or 0), int(m.get("dup_rows") or 0),
                 _json.dumps(m.get("top") or [], ensure_ascii=False, default=str),
                 stamp))
            n += 1
        conn.commit()
        return {"ok": True, "db": str(path), "recorded": n, "detected_at": stamp,
                "report": rep}
    except sqlite3.Error as exc:
        try:
            conn.rollback()
        except sqlite3.Error:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
        return {"ok": False, "code": "duplicate_monitor_write_failed",
                "error": "%s: %s" % (type(exc).__name__, exc), "db": str(path)}
    finally:
        conn.close()


# ---- 规则状态机迁移（20261117，仅 rule / rule_version，不涉及安全列）----
# 迁移口径：
#   * rule_version 增加 approved_at / approved_by / superseded_at（幂等）；
#   * 同一规则历史多条 published → 只保留 current_version_id 指向者（无指针取最新），
#     其余降为 superseded，保证「同一规则 published ≤ 1」；
#   * rule.status='published' 但 current_version_id 缺失/失效 → 回填到保留的 published 版本；
#   * archived 规则不得残留生效版本：published 全部 superseded，current_version_id 清空；
#   * 建部分唯一索引 uq_rule_version_published，DB 层兜底唯一 published 约束。
def _migrate_rule_state_machine(c: sqlite3.Connection) -> dict:
    stats = {"superseded": 0, "backfilled": 0, "archived_cleared": 0, "index": 0}
    cols = [r[1] for r in c.execute("PRAGMA table_info(rule_version)").fetchall()]
    for _col, _ddl in (("approved_at", "TEXT DEFAULT ''"),
                       ("approved_by", "TEXT DEFAULT ''"),
                       ("superseded_at", "TEXT DEFAULT ''")):
        if _col not in cols:
            try:
                c.execute(f"ALTER TABLE rule_version ADD COLUMN {_col} {_ddl}")
            except Exception:
                logging.getLogger(__name__).debug("rule_version migration skipped: %s", _col,
                                                  exc_info=True)
    stamp = now()
    # 1) 已下线规则：published 失效 + 指针清空
    for (rid,) in c.execute("SELECT id FROM rule WHERE COALESCE(status,'')='archived'").fetchall():
        cur = c.execute("UPDATE rule_version SET status='superseded', superseded_at=? "
                        "WHERE rule_id=? AND status='published'", (stamp, rid))
        stats["superseded"] += max(0, cur.rowcount or 0)
        c.execute("UPDATE rule SET current_version_id='' WHERE id=?", (rid,))
        stats["archived_cleared"] += 1
    # 2) 每规则唯一 published：保留 current_version_id 指向者，其余 superseded
    rows = c.execute("SELECT id, status, current_version_id FROM rule "
                     "WHERE COALESCE(status,'')<>'archived'").fetchall()
    for rid, status, cid in rows:
        pubs = [p[0] for p in c.execute(
            "SELECT id FROM rule_version WHERE rule_id=? AND status='published' "
            "ORDER BY rowid DESC", (rid,)).fetchall()]
        if not pubs:
            continue
        cid = str(cid or "")
        keep = cid if cid in pubs else pubs[0]
        for pid in pubs:
            if pid == keep:
                continue
            c.execute("UPDATE rule_version SET status='superseded', superseded_at=? WHERE id=?",
                      (stamp, pid))
            stats["superseded"] += 1
        if str(status or "") == "published" and cid != keep:
            c.execute("UPDATE rule SET current_version_id=? WHERE id=?", (keep, rid))
            stats["backfilled"] += 1
    # 3) published 规则指针失效 → 回退到唯一 published 版本
    for rid, cid in c.execute("SELECT id, current_version_id FROM rule "
                              "WHERE COALESCE(status,'')='published'").fetchall():
        cid = str(cid or "")
        if cid and c.execute("SELECT 1 FROM rule_version WHERE id=? AND rule_id=? "
                             "AND status='published'", (cid, rid)).fetchone():
            continue
        got = c.execute("SELECT id FROM rule_version WHERE rule_id=? AND status='published' "
                        "ORDER BY rowid DESC LIMIT 1", (rid,)).fetchone()
        if got:
            c.execute("UPDATE rule SET current_version_id=? WHERE id=?", (got[0], rid))
            stats["backfilled"] += 1
    # 4) DB 层唯一约束：每规则最多一条 published
    try:
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_rule_version_published "
                  "ON rule_version(rule_id) WHERE status='published'")
        stats["index"] = 1
    except Exception as exc:
        # P2-12：唯一约束是「每规则仅 1 published」的 DB 兜底，建不起来=系统带病，
        # 必须 fail-fast 中止启动（禁止 warning 后继续运行）。
        raise RuntimeError(
            "关键迁移失败：无法创建 uq_rule_version_published 唯一索引"
            f"（{type(exc).__name__}: {exc}）；请先修复 rule_version 重复 published 数据"
        ) from exc
    return stats


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")     # 并发读写：写不阻塞读
    conn.execute("PRAGMA busy_timeout = 15000")   # 并发写锁等待，避免瞬时 502
    return conn


def _assert_product_db_write_allowed() -> None:
    """2026-11-24 事故 C/D 后补：禁止非授权进程对产品库执行 init_db/迁移。

    产品库只允许：服务/CLI/seed/start.sh/打包（包内演示库非本路径）或显式
    RULEPROOF_ALLOW_PRODUCT_DB_WRITE=1 的人工操作。测试/评测/一次性脚本必须
    使用 RULEPROOF_DB=/tmp/...；本函数把“误 init_db 产品库”变成启动期错误。
    初始建库（产品库不存在或 0 字节）仍允许，避免本地首次启动被误伤。
    """
    try:
        prod = Path(DEFAULT_DB_PATH).resolve()
        cur = Path(DB_PATH).resolve()
    except Exception:
        return
    if cur != prod:
        return
    allow = str(os.environ.get("RULEPROOF_ALLOW_PRODUCT_DB_WRITE") or "").strip().lower() in (
        "1", "true", "yes", "on")
    if allow:
        return
    try:
        if not prod.exists() or prod.stat().st_size == 0:
            return
    except Exception:
        return
    import sys as _sys
    argv = [str(x).replace("\\", "/") for x in getattr(_sys, "argv", [])]
    joined = " ".join(argv)
    allowed_proc = (
        any(a.endswith(("seed.py", "start.sh", "app/cli.py", "app/api/server.py", "/rp", "rp")) for a in argv)
        or "app.cli" in joined or "app.api.server" in joined
    )
    if allowed_proc:
        return
    raise RuntimeError(
        "拒绝写入产品库：进程未授权执行 init_db/迁移（RULEPROOF_DB=%s）。"
        "测试/评测/一次性脚本必须显式 RULEPROOF_DB=/tmp/...；人工重建请设 "
        "RULEPROOF_ALLOW_PRODUCT_DB_WRITE=1。" % prod)


def init_db(conn: sqlite3.Connection | None = None, *,
            skip_product_guard: bool = False) -> None:
    """建库/迁移全量 schema（幂等）。

    skip_product_guard=True 仅供“schema 快照/drift 报告”对显式临时连接建新库使用
    （连接的是一条 /tmp 新库，不是产品库）；业务入口一律不得传该参数。
    """
    if not skip_product_guard:
        _assert_product_db_write_allowed()
    c = conn or connect()
    try:
        c.executescript(SCHEMA)
        # ---- L109（2026-11-25）：历史遗留表 + RSI 影子池纳入基线 schema ----
        # department/template/template_field 为产品库存量只读死表（旧 migrations/001
        # 基线），rsi_shadow 原先只由 rsi_guard 运行期建；纳入 init_db 后
        # fresh install = 产品库表集合（104 表），运行期 ensure 退化为兜底。
        for _sql in L109_LEGACY_SCHEMA:
            c.execute(_sql)
        for _sql in RUNTIME_EXTENSION_SCHEMA["rsi_shadow"]:
            c.execute(_sql)
        # 轻量迁移：document.path（项目制上传落盘）
        for _sql in ("ALTER TABLE open_event ADD COLUMN app_key TEXT",
                     "ALTER TABLE open_event ADD COLUMN callback_url TEXT",
                     "ALTER TABLE open_event ADD COLUMN status TEXT DEFAULT 'pending'",
                     "ALTER TABLE open_event ADD COLUMN attempts INTEGER DEFAULT 0",
                     "ALTER TABLE open_event ADD COLUMN last_error TEXT",
                     "ALTER TABLE open_event ADD COLUMN next_retry_at TEXT",
                     "ALTER TABLE manifest_evidence ADD COLUMN checklist_json TEXT DEFAULT '[]'",
                     "ALTER TABLE point_state ADD COLUMN file_id TEXT",
                     "ALTER TABLE onto_alias ADD COLUMN evidence TEXT DEFAULT ''",
                     "ALTER TABLE onto_alias ADD COLUMN source TEXT DEFAULT 'legacy'",
                     "ALTER TABLE onto_alias ADD COLUMN status TEXT DEFAULT 'approved'",
                     "ALTER TABLE onto_alias ADD COLUMN created_at TEXT",):
            try:
                c.execute(_sql)
            except Exception:
                pass
        try:
            c.execute("ALTER TABLE calibration ADD COLUMN source TEXT")
        except Exception:
            pass
        # L27 Phase0 Task 0.1（2026-11-23）：findings/point_state 逐字引文 + 原文区间
        # （只加列、带默认值；=0 回退杆在 auditpoints.finding_include_quote，不依赖本迁移）
        for _sql in ("ALTER TABLE finding ADD COLUMN verbatim_quote TEXT DEFAULT ''",
                     "ALTER TABLE finding ADD COLUMN char_start INTEGER DEFAULT -1",
                     "ALTER TABLE finding ADD COLUMN char_end INTEGER DEFAULT -1",
                     "ALTER TABLE finding ADD COLUMN anchor_mode TEXT DEFAULT 'unanchored'",
                     "ALTER TABLE finding ADD COLUMN issue_identity TEXT DEFAULT ''",
                     # L71 P2a（2026-11-24）证据回填字段：只加列带默认值；=0 时写路径完全不写这些列
                     "ALTER TABLE finding ADD COLUMN anchor_source TEXT DEFAULT 'none'",
                     "ALTER TABLE finding ADD COLUMN anchor_strength TEXT DEFAULT 'none'",
                     "ALTER TABLE finding ADD COLUMN text_profile TEXT DEFAULT ''",
                     "ALTER TABLE finding ADD COLUMN quote_summary TEXT DEFAULT ''",
                     "ALTER TABLE finding ADD COLUMN backfill_status TEXT DEFAULT ''",
                     "ALTER TABLE finding ADD COLUMN backfill_reason TEXT DEFAULT ''",
                     "ALTER TABLE finding ADD COLUMN backfill_version TEXT DEFAULT ''",
                     "ALTER TABLE point_state ADD COLUMN char_start INTEGER DEFAULT -1",
                     "ALTER TABLE point_state ADD COLUMN char_end INTEGER DEFAULT -1",
                     "ALTER TABLE point_state ADD COLUMN anchor_mode TEXT DEFAULT 'unanchored'",
                     "ALTER TABLE point_state ADD COLUMN verbatim_quote TEXT DEFAULT ''",
                     # L78（2026-11-24）多实例 cap 截断可观测：只加列带默认值
                     "ALTER TABLE point_state ADD COLUMN generated_count INTEGER DEFAULT 0",
                     "ALTER TABLE point_state ADD COLUMN kept_count INTEGER DEFAULT 0",
                     "ALTER TABLE point_state ADD COLUMN cap_truncated INTEGER DEFAULT 0",
                     "ALTER TABLE point_state ADD COLUMN mi_limit INTEGER DEFAULT 0"):
            try:
                c.execute(_sql)
            except Exception:
                pass
        # 点位明细：理由与引文（让“查过了”可见）
        for _sql in ("ALTER TABLE point_state ADD COLUMN reason TEXT",
                     "ALTER TABLE point_state ADD COLUMN quote TEXT",
                     "ALTER TABLE point_state ADD COLUMN title TEXT"):
            try:
                c.execute(_sql)
            except Exception:
                pass
        # 权限点 + 角色权限包 + 用户-空间关系
        c.executescript("""
        CREATE TABLE IF NOT EXISTS permission(
          code TEXT PRIMARY KEY, module TEXT, action TEXT, name TEXT);
        CREATE TABLE IF NOT EXISTS role_permission(
          role_id TEXT, permission_code TEXT, PRIMARY KEY(role_id, permission_code));
        CREATE TABLE IF NOT EXISTS user_workspace(
          user_id TEXT, workspace_id TEXT, PRIMARY KEY(user_id, workspace_id));
        """)
        for _t in ("user",):
            try:
                c.execute("ALTER TABLE user ADD COLUMN current_workspace_id TEXT")
            except Exception:
                pass
        try:
            c.execute("ALTER TABLE user ADD COLUMN initial_password TEXT DEFAULT ''")
        except Exception:
            pass
        try:
            c.execute("ALTER TABLE user ADD COLUMN onboarded_at TEXT")
        except Exception:
            # 已存在该列（老库/重复迁移）不需要中断初始化
            import logging as _lg
            _lg.getLogger(__name__).debug("user.onboarded_at migration skipped", exc_info=True)
        # 多租户 + 工作空间（四层：平台 / 租户 / 空间 / 审核数据）
        c.executescript("""
        CREATE TABLE IF NOT EXISTS tenant(
          id TEXT PRIMARY KEY, code TEXT UNIQUE, name TEXT, status TEXT DEFAULT 'active',
          created_at TEXT, note TEXT,
          logo_url TEXT DEFAULT '', platform_name TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS workspace(
          id TEXT PRIMARY KEY, tenant_id TEXT, name TEXT, status TEXT DEFAULT 'active',
          created_by TEXT, created_at TEXT, settings_json TEXT,
          UNIQUE(tenant_id, name));
        CREATE INDEX IF NOT EXISTS idx_ws_tenant ON workspace(tenant_id);
        CREATE TABLE IF NOT EXISTS audit_manifest(
          id TEXT PRIMARY KEY, case_id TEXT, run_id TEXT DEFAULT '',
          tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
          source TEXT DEFAULT 'published_rules', status TEXT DEFAULT 'frozen',
          objects_json TEXT DEFAULT '[]', rules_json TEXT DEFAULT '[]',
          items_json TEXT DEFAULT '[]', hash TEXT DEFAULT '', created_at TEXT DEFAULT '',
          created_by TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS auditpoint_confirmation(
          point_id TEXT, tenant_id TEXT, workspace_id TEXT, status TEXT DEFAULT 'confirmed',
          criterion TEXT DEFAULT '', scope_json TEXT DEFAULT '[]',
          confirmed_by TEXT DEFAULT '', confirmed_at TEXT DEFAULT '',
          library_version TEXT DEFAULT '', point_hash TEXT DEFAULT '',
          PRIMARY KEY(point_id, tenant_id, workspace_id)
        );
        CREATE TABLE IF NOT EXISTS task_job(
          id TEXT PRIMARY KEY, name TEXT, status TEXT DEFAULT 'queued',
          owner TEXT DEFAULT '', case_id TEXT DEFAULT '', timeout INTEGER DEFAULT 1800,
          started TEXT DEFAULT '', finished TEXT DEFAULT '', error TEXT DEFAULT '',
          result_json TEXT DEFAULT '', cancel_requested INTEGER DEFAULT 0,
          deadline REAL, idem_key TEXT DEFAULT '', updated_at TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_task_job_idem ON task_job(idem_key);
        CREATE TABLE IF NOT EXISTS manifest_active(
          case_id TEXT, object_id TEXT, rule_code TEXT, result_id TEXT, updated_at TEXT,
          PRIMARY KEY(case_id, object_id, rule_code)
        );
        CREATE TABLE IF NOT EXISTS manifest_active_sub(
          case_id TEXT, object_id TEXT, rule_code TEXT, sub_id TEXT,
          result_id TEXT, status TEXT DEFAULT '', updated_at TEXT,
          PRIMARY KEY(case_id, object_id, rule_code, sub_id)
        );
        CREATE TABLE IF NOT EXISTS manifest_evidence(
          id TEXT PRIMARY KEY, result_id TEXT, reason TEXT DEFAULT '', status TEXT DEFAULT 'open',
          requested_by TEXT DEFAULT '', created_at TEXT DEFAULT '', fulfilled_at TEXT DEFAULT '',
          evidence_ref TEXT DEFAULT '', new_result_id TEXT DEFAULT '', checklist_json TEXT DEFAULT '[]');
        CREATE TABLE IF NOT EXISTS manifest_review(
          id TEXT PRIMARY KEY, result_id TEXT, status TEXT, reason TEXT DEFAULT '',
          reviewer TEXT DEFAULT '', role TEXT DEFAULT '', created_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS manifest_result(
          id TEXT PRIMARY KEY, manifest_id TEXT, item_key TEXT,
          object_id TEXT DEFAULT '', rule_id TEXT DEFAULT '', rule_code TEXT DEFAULT '',
          d1_json TEXT DEFAULT '{}', d2_json TEXT DEFAULT '{}', d3_json TEXT DEFAULT '{}',
          d4_json TEXT DEFAULT '{}', d5_json TEXT DEFAULT '{}',
          conclusion TEXT DEFAULT '', execution TEXT DEFAULT '', updated_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS business_term(
          id TEXT PRIMARY KEY, tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
          term_key TEXT, name TEXT, definition TEXT, synonyms_json TEXT DEFAULT '[]',
          not_equal_json TEXT DEFAULT '[]', source TEXT DEFAULT '', scope TEXT DEFAULT '',
          entity_type TEXT DEFAULT '', unit TEXT DEFAULT '', relations_json TEXT DEFAULT '[]',
          version INTEGER DEFAULT 1, status TEXT DEFAULT 'draft',
          confirmed_by TEXT DEFAULT '', confirmed_at TEXT DEFAULT '', created_at TEXT DEFAULT '',
          UNIQUE(term_key, workspace_id));
        """)
        c.execute("INSERT OR IGNORE INTO tenant(id, code, name, status, created_at) "
                  "VALUES('t-default','default','默认租户','active',?)", (now(),))
        c.execute("INSERT OR IGNORE INTO workspace(id, tenant_id, name, status, created_at) "
                  "VALUES('ws-default','t-default','通用工作空间','active',?)", (now(),))
        c.execute("UPDATE workspace SET name='通用工作空间' WHERE name IN ('通用空间','默认空间')")
        try:
            c.execute("ALTER TABLE rule ADD COLUMN current_version_id TEXT DEFAULT ''")
        except Exception:
            pass
        # 规则状态机：approved/superseded 列 + 每规则唯一 published + current_version_id 回退
        try:
            _migrate_rule_state_machine(c)
        except Exception as exc:  # P2-12：关键迁移失败必须中止启动（fail-fast）
            if isinstance(exc, RuntimeError) and str(exc).startswith("关键迁移失败"):
                raise
            raise RuntimeError(
                "关键迁移失败：规则状态机迁移异常"
                f"（{type(exc).__name__}: {exc}），已中止初始化，禁止带病运行"
            ) from exc
        # 业务表加隔离键（默认回填到默认租户/空间）
        for _t in ("rule", "decision_table", "audit_case", "document", "finding",
                   "feedback", "calibration", "doc_type_custom", "point_suppression",
                   "rule_point_mapping", "audit_run", "user", "audit_log", "qa_sample"):
            for _col, _dv in (("tenant_id", "t-default"), ("workspace_id", "ws-default")):
                try:
                    c.execute(f"ALTER TABLE {_t} ADD COLUMN {_col} TEXT")
                except Exception:
                    pass
                try:
                    c.execute(f"UPDATE {_t} SET {_col}=? WHERE {_col} IS NULL OR {_col}=''", (_dv,))
                except Exception:
                    pass
        # T-197（本体 P1-2）：本体资产加租户隔离键。
        # - 列用 ALTER ... TEXT 且**不设默认值**：旧库已有行 = NULL = 平台共享资产；
        # - 新写入由 repositories.BaseRepo 按 ctx 自动落 tenant_id，
        #   服务层再显式把 workspace_id 置 NULL（本体资产是租户级，不随空间切分）；
        # - 读过滤在 repositories（include_global=True）+ ontology_assets 双重保证。
        for _t in ("onto_entity", "onto_alias", "onto_link", "onto_version"):
            for _col in ("tenant_id", "workspace_id"):
                try:
                    c.execute(f"ALTER TABLE {_t} ADD COLUMN {_col} TEXT")
                except Exception:
                    pass
        # T-197（本体 P0-2）：影子评估轮次 + 自动开关评估记录。
        # 只追加新表；不参与 finding/报告主链，删除也不影响判定（影子只记录不判）。
        c.executescript("""
        CREATE TABLE IF NOT EXISTS ontology_shadow_round(
          id TEXT PRIMARY KEY,
          case_id TEXT DEFAULT '', run_id TEXT DEFAULT '',
          tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
          point_count INTEGER DEFAULT 0, changed_count INTEGER DEFAULT 0,
          classes_json TEXT DEFAULT '{}', records_json TEXT DEFAULT '[]',
          labels_json TEXT DEFAULT '[]', created_at TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_onto_shadow_ws
          ON ontology_shadow_round(tenant_id, workspace_id, created_at);
        CREATE TABLE IF NOT EXISTS ontology_switch_eval(
          id TEXT PRIMARY KEY, round_no INTEGER DEFAULT 0,
          tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
          enabled_before INTEGER DEFAULT 0, enabled_after INTEGER DEFAULT 0,
          action TEXT DEFAULT '', n INTEGER DEFAULT 0,
          delta_f1 REAL, ci_lo REAL, ci_hi REAL, f1_on REAL, f1_off REAL,
          min_n INTEGER DEFAULT 0, classes_json TEXT DEFAULT '{}',
          detail_json TEXT DEFAULT '{}', actor TEXT DEFAULT '', created_at TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_onto_eval_ws
          ON ontology_switch_eval(tenant_id, workspace_id, created_at);
        """)
        # 规则→审核点类型的映射表（客户规则挂载点）
        c.executescript("""
        CREATE TABLE IF NOT EXISTS rule_point_mapping(
          id TEXT PRIMARY KEY, rule_id TEXT, rule_code TEXT,
          tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '',
          point_id TEXT, point_name TEXT, score REAL,
          status TEXT DEFAULT 'mapped', note TEXT, created_at TEXT);
        CREATE INDEX IF NOT EXISTS idx_rpm_rule ON rule_point_mapping(rule_id);
        """)
        # 类型记忆：同一项目/用户下次上传默认继承上次选择的文档类型
        c.executescript("""
        CREATE TABLE IF NOT EXISTS doc_type_memory(
          id TEXT PRIMARY KEY, scope TEXT, scope_id TEXT, doc_type TEXT, updated_at TEXT);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_dtm ON doc_type_memory(scope, scope_id);
        """)
        # 误报抑制：客户判某点位在某类型下不适用，下次不再报
        c.executescript("""
        CREATE TABLE IF NOT EXISTS point_suppression(
          id TEXT PRIMARY KEY, point_id TEXT, doc_type TEXT, reason TEXT, created_at TEXT,
          -- L109：租户/空间隔离列进建表 DDL（原先依赖“先建表后 ALTER”的次序，首轮
          -- init_db 加列会被吞掉 → fresh 首轮缺列，与产品库不同构；旧库由下方 ALTER 补）
          tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '');
        """)
        # 客户自助新增的文档类型（事后治理：即可生效，管理员可复核删除）
        c.executescript("""
        CREATE TABLE IF NOT EXISTS doc_type_custom(
          id TEXT PRIMARY KEY, code TEXT, name TEXT, aliases_json TEXT,
          audit_types_json TEXT, point_ids_json TEXT, status TEXT DEFAULT 'active',
          created_by TEXT, created_at TEXT,
          -- L109：租户/空间隔离列进建表 DDL（同 point_suppression；旧库下方 ALTER 补）
          tenant_id TEXT DEFAULT '', workspace_id TEXT DEFAULT '');
        """)
        # 轻量迁移：rule / decision_table 增加负责人（owner）
        for tbl in ("rule", "decision_table"):
            cols = [r[1] for r in c.execute(f"PRAGMA table_info({tbl})").fetchall()]
            if cols and "owner" not in cols:
                c.execute(f"ALTER TABLE {tbl} ADD COLUMN owner TEXT DEFAULT ''")
            if cols and "owner_id" not in cols:
                c.execute(f"ALTER TABLE {tbl} ADD COLUMN owner_id TEXT DEFAULT ''")
        cols = [r[1] for r in c.execute("PRAGMA table_info(document)").fetchall()]
        if "path" not in cols:
            c.execute("ALTER TABLE document ADD COLUMN path TEXT")
        # 轻量迁移：user 本地账号字段
        ucols = [r[1] for r in c.execute("PRAGMA table_info(user)").fetchall()]
        for col, ddl in [("username", "TEXT"), ("password_hash", "TEXT"), ("salt", "TEXT"),
                         ("phone", "TEXT"), ("department", "TEXT"), ("must_change_pwd", "INTEGER DEFAULT 0"),
                         ("last_login", "TEXT"), ("created_by", "TEXT")]:
            if col not in ucols:
                c.execute(f"ALTER TABLE user ADD COLUMN {col} {ddl}")
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_user_username ON user(username)")
        _ucols = [r[1] for r in c.execute("PRAGMA table_info(user)").fetchall()]
        if "portal" not in _ucols:
            c.execute("ALTER TABLE user ADD COLUMN portal TEXT DEFAULT ''")
        # 旧账号按角色归属端；平台/管理/审核三端分离
        c.execute("UPDATE user SET portal='platform' WHERE COALESCE(portal,'')='' AND id IN (SELECT ur.user_id FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE r.code='platform_op')")
        c.execute("UPDATE user SET portal='admin' WHERE COALESCE(portal,'')='' AND id IN (SELECT ur.user_id FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE r.code IN ('admin','super_admin'))")
        c.execute("UPDATE user SET portal='reviewer' WHERE COALESCE(portal,'')='' AND id IN (SELECT ur.user_id FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE r.code='reviewer')")
        c.execute("UPDATE user SET portal='reviewer' WHERE COALESCE(portal,'')=''")
        # open_event 补投递所需字段
        ccols = [r[1] for r in c.execute("PRAGMA table_info(audit_case)").fetchall()]
        if "last_audit_at" not in ccols:
            c.execute("ALTER TABLE audit_case ADD COLUMN last_audit_at TEXT")
        for col in ("audit_type", "focus", "last_run_id", "audit_category", "document_type"):
            if col not in ccols:
                c.execute(f"ALTER TABLE audit_case ADD COLUMN {col} TEXT DEFAULT ''")
        fcols = [r[1] for r in c.execute("PRAGMA table_info(finding)").fetchall()]
        if "run_id" not in fcols:
            c.execute("ALTER TABLE finding ADD COLUMN run_id TEXT DEFAULT ''")
        if "point_library_version" not in fcols:
            c.execute("ALTER TABLE finding ADD COLUMN point_library_version TEXT DEFAULT ''")
        acols = [r[1] for r in c.execute("PRAGMA table_info(audit_run)").fetchall()]
        if "point_library_version" not in acols:
            c.execute("ALTER TABLE audit_run ADD COLUMN point_library_version TEXT DEFAULT ''")
        dtcols = [r[1] for r in c.execute("PRAGMA table_info(decision_table)").fetchall()]
        for col, ddl in (("scope_types", "TEXT DEFAULT '[]'"), ("canary_percent", "INTEGER DEFAULT 100")):
            if col not in dtcols:
                c.execute(f"ALTER TABLE decision_table ADD COLUMN {col} {ddl}")
        tcols = [r[1] for r in c.execute("PRAGMA table_info(tenant)").fetchall()]
        for _col, _ddl in (("industry", "TEXT DEFAULT ''"), ("contact_name", "TEXT DEFAULT ''"),
                           ("contact_phone", "TEXT DEFAULT ''"), ("contact_email", "TEXT DEFAULT ''"),
                           ("edition", "TEXT DEFAULT 'trial'"), ("expires_at", "TEXT DEFAULT ''"),
                           ("logo_url", "TEXT DEFAULT ''"), ("platform_name", "TEXT DEFAULT ''")):
            if _col not in tcols:
                c.execute(f"ALTER TABLE tenant ADD COLUMN {_col} {_ddl}")
        ucols = [r[1] for r in c.execute("PRAGMA table_info(user)").fetchall()]
        for _col, _ddl in (("is_initial", "INTEGER DEFAULT 0"), ("account_no", "TEXT DEFAULT ''")):
            if _col not in ucols:
                c.execute(f"ALTER TABLE user ADD COLUMN {_col} {_ddl}")
        arcols = [r[1] for r in c.execute("PRAGMA table_info(audit_run)").fetchall()]
        if "batch_ids" not in arcols:
            c.execute("ALTER TABLE audit_run ADD COLUMN batch_ids TEXT DEFAULT ''")
        if "trace_json" not in arcols:
            c.execute("ALTER TABLE audit_run ADD COLUMN trace_json TEXT DEFAULT ''")
        if "plan_json" not in arcols:
            c.execute("ALTER TABLE audit_run ADD COLUMN plan_json TEXT DEFAULT ''")
        if "manifest_id" not in arcols:
            c.execute("ALTER TABLE audit_run ADD COLUMN manifest_id TEXT DEFAULT ''")
        mrcols = [r[1] for r in c.execute("PRAGMA table_info(manifest_result)").fetchall()]
        for _col, _ddl in (("review_status", "TEXT DEFAULT 'pending'"),
                           ("review_reason", "TEXT DEFAULT ''"),
                           ("reviewer", "TEXT DEFAULT ''"),
                           ("reviewed_at", "TEXT DEFAULT ''")):
            if _col not in mrcols:
                c.execute(f"ALTER TABLE manifest_result ADD COLUMN {_col} {_ddl}")
        _evcols = [r[1] for r in c.execute("PRAGMA table_info(manifest_evidence)").fetchall()]
        if "new_result_id" not in _evcols:
            c.execute("ALTER TABLE manifest_evidence ADD COLUMN new_result_id TEXT DEFAULT ''")
        _btcols = [r[1] for r in c.execute("PRAGMA table_info(business_term)").fetchall()]
        for _col, _ddl in (("entity_type", "TEXT DEFAULT ''"), ("unit", "TEXT DEFAULT ''"),
                           ("relations_json", "TEXT DEFAULT '[]'")):
            if _col not in _btcols:
                c.execute(f"ALTER TABLE business_term ADD COLUMN {_col} {_ddl}")
        _ncols = [r[1] for r in c.execute("PRAGMA table_info(notification)").fetchall()]
        for _col in ("tenant_id", "workspace_id"):
            if _col not in _ncols:
                c.execute(f"ALTER TABLE notification ADD COLUMN {_col} TEXT DEFAULT ''")
        _casecols = [r[1] for r in c.execute("PRAGMA table_info(audit_case)").fetchall()]
        if "compat_mode" not in _casecols:
            c.execute("ALTER TABLE audit_case ADD COLUMN compat_mode TEXT DEFAULT ''")
        fcols_manifest = [r[1] for r in c.execute("PRAGMA table_info(finding)").fetchall()]
        if "object_id" not in fcols_manifest:
            c.execute("ALTER TABLE finding ADD COLUMN object_id TEXT DEFAULT ''")
        if "subrequirement_id" not in fcols_manifest:
            c.execute("ALTER TABLE finding ADD COLUMN subrequirement_id TEXT DEFAULT ''")
        if "manifest_result_id" not in fcols_manifest:
            c.execute("ALTER TABLE finding ADD COLUMN manifest_result_id TEXT DEFAULT ''")
        if "occurrence_count" not in fcols_manifest:
            c.execute("ALTER TABLE finding ADD COLUMN occurrence_count INTEGER DEFAULT 1")
        if "occurrence_ids_json" not in fcols_manifest:
            c.execute("ALTER TABLE finding ADD COLUMN occurrence_ids_json TEXT DEFAULT '[]'")
        fcols_lt = [r[1] for r in c.execute("PRAGMA table_info(finding)").fetchall()]
        if "llm_trace_ids" not in fcols_lt:
            c.execute("ALTER TABLE finding ADD COLUMN llm_trace_ids TEXT DEFAULT ''")
        ltcols = [r[1] for r in c.execute("PRAGMA table_info(llm_trace)").fetchall()]
        for _col, _ddl in (("evidence_ids", "TEXT DEFAULT ''"), ("messages_json", "TEXT DEFAULT ''"),
                           ("stage", "TEXT DEFAULT '未标注'")):
            if _col not in ltcols:
                c.execute(f"ALTER TABLE llm_trace ADD COLUMN {_col} {_ddl}")
        rpcols = [r[1] for r in c.execute("PRAGMA table_info(rule_param)").fetchall()]
        for col in ("pending_json", "pending_by", "pending_at"):
            if col not in rpcols:
                c.execute(f"ALTER TABLE rule_param ADD COLUMN {col} TEXT DEFAULT ''")
        calcols = [r[1] for r in c.execute("PRAGMA table_info(calibration)").fetchall()]
        for _col, _ddl in (("state", "TEXT DEFAULT ''"), ("confidence", "REAL")):
            _fcols = [r[1] for r in c.execute("PRAGMA table_info(finding)").fetchall()]
            if _col not in _fcols:
                c.execute(f"ALTER TABLE finding ADD COLUMN {_col} {_ddl}")
        for col in ("rule_code", "point_id"):
            if col not in calcols:
                c.execute(f"ALTER TABLE calibration ADD COLUMN {col} TEXT DEFAULT ''")
        ccols2 = [r[1] for r in c.execute("PRAGMA table_info(conflict)").fetchall()]
        for col in ("severity", "suggestion", "slots_a", "slots_b", "resolved_at", "resolved_by", "note",
                    "tenant_id", "workspace_id"):
            if col not in ccols2:
                c.execute(f"ALTER TABLE conflict ADD COLUMN {col} TEXT DEFAULT ''")
        # T-63（20261117）冲突裁决：resolution/closed_rule_ids/recreate_rule_id/task/impact。
        # 仅加列，不改旧行状态；旧冲突（无这些列的值）按 open/未裁决读取，历史数据不丢。
        for col in ("resolution", "resolution_detail", "closed_rule_ids",
                    "recreate_rule_id", "recreate_task", "impact_json"):
            if col not in ccols2:
                c.execute(f"ALTER TABLE conflict ADD COLUMN {col} TEXT DEFAULT ''")
        c.execute("UPDATE conflict SET tenant_id='t-default', workspace_id='ws-default' WHERE COALESCE(tenant_id,'')='' AND COALESCE(workspace_id,'')=''")
        for col in ("point_id", "source_code"):
            if col not in fcols:
                c.execute(f"ALTER TABLE finding ADD COLUMN {col} TEXT DEFAULT ''")
        dcols = [r[1] for r in c.execute("PRAGMA table_info(document)").fetchall()]
        for col in ("parse_status", "parse_summary"):
            if col not in dcols:
                c.execute(f"ALTER TABLE document ADD COLUMN {col} TEXT")
        ecols = [r[1] for r in c.execute("PRAGMA table_info(open_event)").fetchall()]
        for col in ("app_key", "callback_url"):
            if col not in ecols:
                c.execute(f"ALTER TABLE open_event ADD COLUMN {col} TEXT")
        for _tbl, _cols in (("auditpoint_confirmation", ("library_version", "point_hash")),
                            ("open_app", ("tenant_id", "workspace_id")),
                            ("open_task", ("tenant_id", "workspace_id")),
                            ("open_task_queue", ("tenant_id", "workspace_id")),
                            ("open_event", ("tenant_id", "workspace_id")),
                            ("open_sandbox", ("tenant_id", "workspace_id"))):
            _cols_now = [r[1] for r in c.execute(f"PRAGMA table_info({_tbl})").fetchall()]
            for _col in _cols:
                if _col not in _cols_now:
                    c.execute(f"ALTER TABLE {_tbl} ADD COLUMN {_col} TEXT DEFAULT ''")
        # X3：历史开放平台资产归属回填。早期 seed 在无请求上下文时写入
        # tenant_id=''/workspace_id=''，仓库层按租户过滤后“首页计数 1、列表 0”。
        # 仅回填完全未归属的行到默认租户/空间（与 conflict 等既有回填口径一致），
        # 已有部分归属的行不动，避免跨租户误改。
        try:
            c.execute("UPDATE open_app SET tenant_id='t-default', workspace_id='ws-default' "
                      "WHERE COALESCE(tenant_id,'')='' AND COALESCE(workspace_id,'')=''")
        except Exception:
            logging.getLogger(__name__).warning("open_app 历史归属回填失败（不影响启动）",
                                                exc_info=True)
        # ---- 安全迁移（20261117，仅加列/索引，不改任何规则状态结构）----
        # 1) 会话版本：改密/重置/停用/登出后旧 JWT 失效（token_version 不一致即拒绝）
        _ucols_sec = [r[1] for r in c.execute("PRAGMA table_info(user)").fetchall()]
        if "token_version" not in _ucols_sec:
            c.execute("ALTER TABLE user ADD COLUMN token_version INTEGER DEFAULT 0")
        c.execute("UPDATE user SET token_version=0 WHERE token_version IS NULL")
        # 2) 异步任务实例归属 + 心跳：多实例 recover 不得杀其他实例 running
        _tjcols_sec = [r[1] for r in c.execute("PRAGMA table_info(task_job)").fetchall()]
        for _col, _ddl in (("instance_id", "TEXT DEFAULT ''"), ("heartbeat", "REAL")):
            if _col not in _tjcols_sec:
                c.execute(f"ALTER TABLE task_job ADD COLUMN {_col} {_ddl}")
        c.execute("CREATE INDEX IF NOT EXISTS idx_task_job_status_inst ON task_job(status, instance_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_task_job_heartbeat ON task_job(heartbeat)")
        # 3) 通知配置租户级（id=tenant:<tid>，平台默认保留 global 单例只读回退）
        _nscols_sec = [r[1] for r in c.execute("PRAGMA table_info(notify_setting)").fetchall()]
        if "tenant_id" not in _nscols_sec:
            c.execute("ALTER TABLE notify_setting ADD COLUMN tenant_id TEXT DEFAULT ''")
        # 4) 开放平台 nonce/沙箱清理所用时间索引（时区统一为 db.now() 本地时间）
        try:
            c.execute("CREATE INDEX IF NOT EXISTS idx_open_nonce_created ON open_nonce(created_at)")
        except Exception:
            logging.getLogger(__name__).debug("open_nonce created_at 索引创建跳过", exc_info=True)
        try:
            c.execute("CREATE INDEX IF NOT EXISTS idx_open_sandbox_received ON open_sandbox(received_at)")
        except Exception:
            logging.getLogger(__name__).debug("open_sandbox received_at 索引创建跳过", exc_info=True)
        # ---- T-39 双轨数据底座（新增 direct_draft/direct_item/comparison_item/
        # suppression_ledger/human_omission/adjudication_event/confidence_calibration
        # + platform_finding 只读视图；不改既有表，不接主链）----
        try:
            _init_dual_track_schema(c)
        except Exception as exc:
            # P2-12：双轨底座是产品主链（人工复核/可见性）依赖表，初始化失败必须
            # fail-fast，禁止 warning 后带病运行。
            raise RuntimeError(
                "关键迁移失败：双轨数据底座 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- L80 / P0-C 裁决来源统计（新增 adjudication_ledger + 索引 + append-only
        # 触发器；**默认开关 =0 → 不执行任何 DDL，旧库逐字节不变**；=1 才幂等建表）。
        # 开关=1 时建表失败按 fail-fast 处理：台账开启却建表失败会让“激活单元无账可查”，
        # 不得 warning 后带病运行（显式非法组合由服务层 validate_switches 拒绝）。----
        if adjudication_ledger_env_on():
            try:
                _init_adjudication_ledger_schema(c)
            except Exception as exc:
                raise RuntimeError(
                    "关键迁移失败：裁决台账 schema 初始化异常"
                    f"（{type(exc).__name__}: {exc}）"
                ) from exc
        # ---- T-52 隐藏项全量进化闭环（新增 hidden_evolution_item/event/sample
        # + 抑制台账 INSERT 即入池触发器；不接人工/UI，不改既有表）----
        try:
            _init_hidden_evolution_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：隐藏项进化 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- T-75 规则进化知识库（新增 knowledge_folder/knowledge_file 两张表
        # + 唯一索引；不改既有表，旧库幂等补表）----
        try:
            _init_knowledge_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：知识库 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- P2 并发/幂等（purge_execution / http_idempotency / rule_point_mapping 隔离）----
        try:
            _init_p2_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：P2 并发/幂等 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- T-194 影子池（独立 shadow_item 表 + 索引/不可删/原始留痕触发器；
        # 只新增表，不改既有表；formal 报告只读 finding 表即天然不含影子项）----
        try:
            _init_shadow_pool_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：影子池 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- L92（2026-11-24）：7 张核心状态表 DB 兜底（report.status 补列 +
        # 值域触发器 + 遗留非法值报告；幂等；不修改历史行）----
        try:
            _init_state_guard_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：状态机 DB 兜底 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- L93（2026-11-24）：核心单据模型字段修复（finding 来源四要素/报告签发/
        # 规则发布人/运行清单关联；监控表 + 删除告警触发器 + 来源兜底触发器；
        # 幂等；历史数据回填必须显式走 data_migrations --docmodel-backfill）----
        try:
            _init_docmodel_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：L93 单据模型 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- L94（2026-11-24）：重复数据监控表 + 非唯一索引（rule.code/
        # document.hash/point_state；不强制唯一，历史重复数据原样保留）----
        try:
            _init_l94_monitor_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：L94 重复监控 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        # ---- L109（2026-11-25）：迁移基础设施由 data_migrations 目录单一定义 ——
        # schema_migration / platform_upgrade / 16 条热路径索引 + 升级索引在这里安装。
        # 目的：fresh init_db 即与「init_db + 版本化迁移」同构（原先要跑完 seed 的
        # migrations 才补齐 2 表 17 索引，裸 init_db 与产品库 drift=28）。
        # 同一份定义来自迁移目录（MIGRATIONS 里 base=True 的条目），不复制 DDL。
        try:
            from . import data_migrations as _dm
            _dm.ensure_infra_schema(c)
        except Exception as exc:
            raise RuntimeError(
                "关键迁移失败：迁移基础设施 schema 初始化异常"
                f"（{type(exc).__name__}: {exc}）"
            ) from exc
        c.commit()
    finally:
        if conn is None:
            c.close()


@contextmanager
def session():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# T-194 影子池产品化 Phase 1（2026-11-20）：独立 shadow_item 表
#
# 为什么用独立表而不是给 finding 加字段（见 docs/qa/影子池产品化_20261120.md §2）：
#   1. 直连侧疑似项（direct_item / 直连候选）**没有 finding 行**——finding 字段扩展
#      无法表达它们；影子池输入天然包含直连独有候选。
#   2. `zone` 在既有体系里已被 audit_zone 占用（deterministic/evidence/shadow/
#      unknown，manifest.freeze 写到 items_json.zone）。再给 finding 加一个
#      formal/shadow/discarded 的 `zone` 会造成同名异义，报告/架构图/口径易混。
#   3. formal 的语义 = “不在 shadow_item 里”，正式报告只读 finding 表即天然不含
#      影子项（零渲染改造即隔离）；被仲裁进影子/丢弃的平台 finding 通过
#      platform_finding_id 反查剔除（服务层 formal_excluded_finding_ids）。
#   4. 回滚 = DROP TABLE shadow_item（触发器/索引随表删除），对 finding 主链零影响。
#
# 约定：
#   * 只新增表/索引/触发器，不改任何既有表；
#   * 禁止物理删除（影子项不是删除，只可裁决/升级/归档 purged_at）；
#   * 原始 claim / 归属 / zone 不可 UPDATE（不可篡改留痕），状态列可推进；
#   * no_gold=1：影子项不是 gold；裁决只写 feedback 候选，不自动调阈值/不自动训练。
# ---------------------------------------------------------------------------
SHADOW_POOL_SCHEMA = """
CREATE TABLE IF NOT EXISTS shadow_item (
  id TEXT PRIMARY KEY,
  item_key TEXT NOT NULL UNIQUE,
  case_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  zone TEXT NOT NULL DEFAULT 'shadow'
    CHECK(zone IN ('shadow','discarded')),
  zone_source TEXT NOT NULL DEFAULT 'arbiter'
    CHECK(zone_source IN ('direct','platform','both','arbiter')),
  shadow_reason TEXT DEFAULT '',
  shadow_confidence REAL,
  shadow_round INTEGER DEFAULT 1,
  shadow_status TEXT NOT NULL DEFAULT 'pending'
    CHECK(shadow_status IN ('pending','confirmed','false_positive','unsure',
                            'skipped','escalated')),
  platform_finding_id TEXT DEFAULT '',
  direct_item_id TEXT DEFAULT '',
  comparison_item_id TEXT DEFAULT '',
  ledger_id TEXT DEFAULT '',
  rule_code TEXT DEFAULT '',
  object_id TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  issue_type TEXT DEFAULT '',
  severity TEXT DEFAULT '',
  risk_level TEXT DEFAULT 'medium',
  claim_json TEXT NOT NULL DEFAULT '{}',
  claim_sha256 TEXT NOT NULL DEFAULT '',
  evidence_json TEXT DEFAULT '{}',
  refute_json TEXT DEFAULT '{}',
  shadow_reviewed_by TEXT DEFAULT '',
  shadow_reviewed_at TEXT DEFAULT '',
  decision_note TEXT DEFAULT '',
  shadow_escalated_at TEXT DEFAULT '',
  escalation_count INTEGER DEFAULT 0,
  default_disposition TEXT DEFAULT '',
  feedback_id TEXT DEFAULT '',
  revealed_before_decide INTEGER DEFAULT 0,
  no_gold INTEGER DEFAULT 1,
  auto_threshold_change INTEGER DEFAULT 0,
  auto_training INTEGER DEFAULT 0,
  purged_at TEXT DEFAULT '',
  purged_by TEXT DEFAULT '',
  created_at TEXT DEFAULT '',
  updated_at TEXT DEFAULT '',
  immutable INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_shadow_case ON shadow_item(case_id);
CREATE INDEX IF NOT EXISTS idx_shadow_case_zone ON shadow_item(case_id, zone);
CREATE INDEX IF NOT EXISTS idx_shadow_case_status ON shadow_item(case_id, shadow_status);
CREATE INDEX IF NOT EXISTS idx_shadow_finding ON shadow_item(platform_finding_id);
CREATE INDEX IF NOT EXISTS idx_shadow_scope ON shadow_item(tenant_id, workspace_id);
CREATE INDEX IF NOT EXISTS idx_shadow_status_created ON shadow_item(shadow_status, created_at);
"""

SHADOW_POOL_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS trg_shadow_item_no_delete
BEFORE DELETE ON shadow_item
BEGIN SELECT RAISE(ABORT, 'shadow_item_is_not_deletion'); END;
CREATE TRIGGER IF NOT EXISTS trg_shadow_item_raw_immutable
BEFORE UPDATE OF case_id, zone, zone_source, item_key, claim_json, claim_sha256, created_at
ON shadow_item
BEGIN SELECT RAISE(ABORT, 'shadow_item_raw_immutable'); END;
"""


def _init_shadow_pool_schema(c: sqlite3.Connection) -> dict:
    """幂等创建 shadow_item 表/索引/触发器（仅新增，不改既有表）。"""
    stats = {"table": 0, "indexes": 0, "triggers": 0}
    before = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    c.executescript(SHADOW_POOL_SCHEMA)
    after = {r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    stats["table"] = len(after - before)
    c.executescript(SHADOW_POOL_TRIGGERS)
    stats["indexes"] = int(c.execute(
        "SELECT count(*) FROM sqlite_master WHERE type='index' "
        "AND name LIKE 'idx_shadow_%'").fetchone()[0] or 0)
    stats["triggers"] = int(c.execute(
        "SELECT count(*) FROM sqlite_master WHERE type='trigger' "
        "AND name LIKE 'trg_shadow_item_%'").fetchone()[0] or 0)
    return stats


def drop_shadow_pool_schema(c: sqlite3.Connection) -> dict:
    """回滚影子池迁移（仅人工/迁移脚本显式调用；产品主链不调用）。

    回滚安全前提：shadow_item 只存影子候选，不参与 finding/报告主链；
    删除后正式报告口径回到“无影子池”旧行为（N 提示消失，不存在数据歧义）。
    """
    c.executescript("DROP TRIGGER IF EXISTS trg_shadow_item_no_delete;"
                    "DROP TRIGGER IF EXISTS trg_shadow_item_raw_immutable;")
    c.execute("DROP TABLE IF EXISTS shadow_item")
    return {"dropped": 1}
