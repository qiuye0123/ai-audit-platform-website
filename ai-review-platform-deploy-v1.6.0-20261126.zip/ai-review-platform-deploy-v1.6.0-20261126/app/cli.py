# -*- coding: utf-8 -*-
"""AI 审核平台 CLI：整套系统命令行入口。

设计：
- 本机模式（默认）：直接调用服务层，使用 RULEPROOF_DB / --db 指定的库
- 所有命令输出 JSON（便于脚本/自动化）；错误写 stderr 并返回非 0
- 权限：按 --as 用户的角色校验关键操作（发布规则/改模型/建空间/建账号）
"""
import argparse
import json
import logging
import os
import sys


# ---------------- CLI 退出码契约（2026-11-22 节点穷举测试 P3） ----------------
# POSIX 进程退出码只有 0-255：直接 sys.exit(HTTP status) 会被 shell 截断成
# 147(403)/144(400)/148(404)/172(428) 这类魔数，脚本无法按文档判断「无权限」。
# 这里统一映射成稳定的小整数；真实 HTTP 状态码仍原样保留在 stderr JSON 的
# `status` 字段（403 就是 403，不被截断）。$? 与 json.status 是两个不同口径：
#   0 成功
#   1 通用业务失败 / 未预期异常
#   2 参数或请求非法（400/405/415；argparse 缺参同为 2）
#   3 业务拒绝且无明确 4xx 语义（如报告门禁阻断、旧数据缺失）
#   4 无权限（401/403）
#   5 对象不存在（404）
#   6 冲突 / 前置条件未满足（409/422/428）
#   7 其它 4xx
_HTTP_EXIT_MAP = {400: 2, 401: 4, 403: 4, 404: 5, 405: 2, 409: 6,
                  415: 2, 422: 6, 428: 6}


def _exit_code(code=1, status=None) -> int:
    """把 (code, status) 归一成 0-255 的稳定退出码（stderr JSON 的 status 不受影响）。"""
    try:
        st = int(status) if status not in (None, "") else 0
    except (TypeError, ValueError):
        st = 0
    try:
        c = int(code)
    except (TypeError, ValueError):
        c = 1
    # 显式 HTTP 状态优先（_err(msg, 2, status=409) 这类必须按 409→6），再看 code。
    for target in (st, c):
        if target in _HTTP_EXIT_MAP:
            return _HTTP_EXIT_MAP[target]
    if 0 < st < 400:
        # 小整数 status 是调用方塞进来的 CLI 分类码（如 terms _fail(2, ...)），按码退出。
        return st
    if st:
        if 400 <= st <= 499:
            return 7      # 其它 4xx
        if st >= 500:
            return 1      # 服务端/未知失败仍属于通用失败
    if 0 <= c <= 255:
        return c
    return 7


def _dump(obj, code=0):
    print(json.dumps(obj, ensure_ascii=False, indent=1))
    sys.exit(code)


def _err(msg, code=1, detail=None, err_code=None, status=None):
    out = {"ok": False, "error": msg}
    if detail:
        out["detail"] = detail
    if err_code:
        out["code"] = err_code
    if status is None and isinstance(code, int) and code in (400, 401, 403, 404):
        status = code
    if status is not None:
        out["status"] = status
    print(json.dumps(out, ensure_ascii=False), file=sys.stderr)
    # $? = 分类码（0/2/4/5/6/7）；真实 HTTP status 见 stderr JSON 的 status 字段。
    sys.exit(_exit_code(code, status))


def _err_deny(deny):
    """把 HTTP 同款 (status, body) 拒绝转成 CLI stderr + 分类退出码。"""
    status, body = deny
    out = {"ok": False, "status": status}
    if isinstance(body, dict):
        out.update(body)
    else:
        out["error"] = str(body)
    print(json.dumps(out, ensure_ascii=False), file=sys.stderr)
    sys.exit(_exit_code(status=status))


def _platform_root() -> str:
    """平台根目录（不 import app，--db 默认路径要在任何 app 模块导入前确定）。"""
    import pathlib
    return str(pathlib.Path(__file__).resolve().parents[1])


def _apply_global_db(args) -> str:
    """L91 P0：在**任何 app.* 模块导入之前**解析 ``--db`` 并写入 RULEPROOF_DB。

    根因：``app.db.DB_PATH`` 在 ``import app.db`` 时固化（``_RAW_DB_PATH``），而旧
    ``_boot()`` 要等到 import 完 ``app.services`` 之后才 setenv → ``--db`` 永远无效，
    只读命令 ``rp version`` 因此会打到进程环境变量（未设置时=产品库）。
    这里提前解析；返回本次进程应使用的库路径，供 ``_boot`` 做一致性断言。
    """
    raw = str(getattr(args, "db", "") or "").strip()
    if raw:
        # 显式 --db 是用户意图：相对路径解析成绝对路径，避免子进程（seed/serve）因
        # CWD 不同而落到另一处；--db 与 ./rp / -m app.cli 两个入口因此同源。
        path = os.path.abspath(os.path.expanduser(raw))
        os.environ["RULEPROOF_DB"] = path
        return path
    cur = (os.environ.get("RULEPROOF_DB") or "").strip()
    if cur:
        return os.path.abspath(os.path.expanduser(cur))
    return os.path.join(_platform_root(), "data", "ruleproof.db")


def _silence_third_party_warnings() -> None:
    """成功命令的 stderr 不得混入第三方库 Python warning（L89 CLI 契约缺口）。

    典型：``/tmp/qa_pylibs`` 里 requests 的 ``RequestsDependencyWarning`` 会让
    ``rp model list`` 在“成功”时 stderr 也非空，脚本化消费无法区分业务错误。
    只忽略**已知第三方依赖告警**，不吞产品代码自身 warning。
    """
    import warnings
    for _pat in (r".*character detection dependency.*",
                 r".*RequestsDependencyWarning.*",
                 r".*urllib3 .* doesn't match a supported version.*"):
        try:
            warnings.filterwarnings("ignore", message=_pat)
        except Exception:  # noqa: BLE001 - 过滤器语法变化不阻断 CLI
            pass
    for _mod in (r"^requests(\.|$)", r"^urllib3(\.|$)", r"^charset_normalizer(\.|$)"):
        try:
            warnings.filterwarnings("ignore", module=_mod)
        except Exception:  # noqa: BLE001
            pass


# ---------------- L91 P1：只读命令不得 init_db / 迁移 ----------------
# 设计：显式登记「只读动作」；未登记的一律按写命令处理（fail-safe：宁可多初始化
# 一次，也不让写命令落在缺表的库上）。``list/show/status/version/backup`` 等纯读
# 动作既不建表、不种子权限，也不写回退杆审计。
_READONLY_CMDS = {
    "version", "doctor", "gate",       # 环境/版本/门禁（不写业务库）
    "resolve", "export",               # 统一解析 / 数据导出（只读 DB）
}
_READONLY_ACTIONS = {
    "ws": {"list", "members", "rules-review", "settings"},   # settings 带 --patch 是写（见下）
    "rule": {"list", "static", "drift-report"},
    "rule-tag": {"list"},
    "evidence": {"list"},
    "ledger": {"", "list"},
    "adjudication-ledger": {"stats"},
    "point": {"list", "stale", "library", "options", "confirmations",
              "route", "recommended",
              # L170：审计分类元数据（HTTP GET /api/v1/audit-categories，只读）
              "categories"},
    "semantic": {"root-cause"},
    "task": {"list", "show"},
    "project": {"list", "show",
                # L170：我的审核（HTTP GET /api/v1/my-audits，只读）
                "my-audits"},
    "finding": {"list",
                # L170：问题分析统计（HTTP GET /api/v1/analytics/issues，只读）
                "analytics"},
    "human-review": {"show", "status", "queue", "omissions", "backend"},
    "hidden-item": {"list", "metrics"},
    "direct-draft": {"list", "show"},
    "compare": {"list", "show"},
    "visibility": {"show"},
    "omission": {"list"},
    "exception": {"list"},
    "open": {"apps", "events", "sandbox", "task"},
    "model": {"list", "config", "points", "effective"},
    "user": {"list",
             # L170：本人身份/权限自查（HTTP GET /api/v1/me、/me/permissions，只读）
             "me"},
    "tenant": {"list", "admin-list",
               # L170：公开品牌（HTTP GET /api/v1/public/tenant-branding，公开只读）
               "branding"},
    "decision": {"list", "show", "evaluate"},
    "ontology": {"show", "versions", "validate", "status", "impact", "capabilities"},
    "terms": {"list"},
    "knowledge": {"list", "folders", "files"},
    "notify-config": {"get"},
    "data-policy": {"status", "get"},
    "notifications": {"list",
                      # L170：主动告警（HTTP GET /api/v1/alerts，只读）
                      "alerts"},
    "agent": {"list", "show", "versions"},
    "evolution": {"replay", "trend",
                  # L170：误报库与反馈台账（HTTP GET /api/v1/errorbook、/api/v1/feedback、
                  # /feedback/mine，只读）；feedback-settle 是业务写，不在只读白名单。
                  "errorbook", "feedback-list", "feedback-mine"},
    "auditlog": {"list"},
    "shadow": {"list", "metrics"},
    "conflict-check": {"status"},
    "db": {"backup"},
}


def _needs_db_init(args) -> bool:
    """该 CLI 调用是否允许初始化/迁移数据库（L91 P1）。

    ``False`` = 只读：跳过 ``init_db`` / ``ensure_seed`` / 回退杆审计，保证
    ``rp version`` 之类命令不改动既有库（表数/sha256/备份目录都不变）。
    """
    cmd = str(getattr(args, "cmd", "") or "")
    if cmd in _READONLY_CMDS:
        return False
    # L163：L155 抽取校验（rp extraction verify/confidence-policy）是只读能力：
    # 不建表、不种子、不写审计（与 HTTP 只读端点同语义）。
    if cmd == "kie" and (bool(getattr(args, "extraction_verify", False))
                         or bool(getattr(args, "extraction_policy", False))):
        return False
    # L170：文档类型主数据只读（rp doctypes list|last → doc 隐藏动作）：不建表/不种子/不写审计。
    if cmd == "doc" and (bool(getattr(args, "doctypes_list", False))
                         or bool(getattr(args, "doctypes_last", False))):
        return False
    action = str(getattr(args, "action", "") or "")
    # ``db migrate``：真迁移要初始化（先备份后建表）；``--dry-run`` 只检查，零写库。
    if cmd == "db" and action == "migrate":
        return not bool(getattr(args, "dry_run", False))
    acts = _READONLY_ACTIONS.get(cmd)
    if acts is None:
        return True
    if action not in acts:
        return True
    # 带副作用参数的“读取型”命令：参数一旦打开写路径就必须初始化。
    if cmd == "ws" and action == "settings" and str(getattr(args, "patch", "") or "").strip():
        return True
    if cmd == "shadow" and action == "list" and (
            bool(getattr(args, "reveal", False)) or bool(getattr(args, "include_hidden", False))):
        return True   # reveal 写审计
    return False


def _boot(args, init: bool = True):
    """初始化 CLI 运行环境；``init=False``（只读命令）时绝不执行 DDL/种子。"""
    # 兜底：正常流程里 main() 已在 import app 前设置；这里再判一次防止调用方绕过。
    if getattr(args, "db", None):
        os.environ["RULEPROOF_DB"] = os.path.abspath(os.path.expanduser(str(args.db)))
    # CLI 也使用统一 JSON 日志（模型调用/任务等 stderr 事件）；stdout 仍只放业务 JSON。
    try:
        from app import obs
        obs.install()
    except Exception:
        pass
    from app import db
    # P0 防回退断言：DB_PATH 是 import 时固化的；若与 main 解析结果不一致，说明
    # 有模块抢跑 import，--db 会静默失效（正是 L89 CLI-1）→ 显式失败，不带病运行。
    _expect = str(getattr(args, "_db_expected", "") or "")
    if _expect:
        try:
            import pathlib
            if pathlib.Path(str(db.DB_PATH)).resolve() != pathlib.Path(_expect).resolve():
                raise RuntimeError(
                    "内部错误：--db 未生效（app.db.DB_PATH=%s，期望 %s）"
                    % (db.DB_PATH, _expect))
        except RuntimeError:
            raise
        except Exception:  # noqa: BLE001 - 路径解析异常不阻断（断言本身需可用）
            pass
    if init:
        db.init_db()
        try:
            from app.services import permissions
            permissions.ensure_seed()
        except Exception:
            pass
    return db


def _user_id(args, db):
    # 默认身份：--user > RULEPROOF_CLI_USER > user-admin（系统管理员）。
    # 系统管理员只读业务（与 HTTP B 边界一致），业务写命令需显式 --user；
    # 交付包/手册脚本可用 RULEPROOF_CLI_USER 固定一个业务身份。
    ident = args.user or os.environ.get("RULEPROOF_CLI_USER") or "user-admin"
    with db.session() as c:
        row = c.execute("SELECT id FROM user WHERE id=? OR username=? OR phone=? LIMIT 1",
                        (ident, ident, ident)).fetchone()
    if not row:
        _err(f"用户不存在：{ident}")
    return row["id"]


def _peek_db_role(db_path: str, ident: str) -> str:
    """只读查询账号角色（不 import app.db）：供 CLI 迁移前备份的权限前置使用。

    迁移前备份发生在 _boot/init_db 之前（保证快照早于任何 schema 变更），因此不能
    依赖服务层身份解析；这里直接读 sqlite，读不到/结构异常一律返回空 → 由调用方
    fail-closed 拒绝，避免先导出整库再拒绝越权请求。
    """
    import sqlite3
    try:
        con = sqlite3.connect("file:%s?mode=ro" % str(db_path), uri=True)
    except Exception:  # noqa: BLE001
        return ""
    try:
        try:
            cols = {str(r[1]) for r in con.execute("PRAGMA table_info(user)").fetchall()}
        except Exception:  # noqa: BLE001
            return ""
        where, params = ["id=?"], [str(ident)]
        if "username" in cols:
            where.append("username=?"); params.append(str(ident))
        if "phone" in cols:
            where.append("phone=?"); params.append(str(ident))
        row = con.execute("SELECT id FROM user WHERE " + " OR ".join(where)
                          + " LIMIT 1", tuple(params)).fetchone()
        if not row:
            return ""
        codes = [str(r[0]) for r in con.execute(
            "SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id "
            "WHERE ur.user_id=?", (row[0],)).fetchall()]
    except Exception:  # noqa: BLE001
        return ""
    finally:
        try:
            con.close()
        except Exception:  # noqa: BLE001
            pass
    for pref in ("super_admin", "admin", "reviewer", "platform_op"):
        if pref in codes:
            return pref
    return codes[0] if codes else ""


def _user_tenant(uid, db) -> str:
    """账号所属租户；缺失时回落默认租户（只用于显式 CLI 作用域校验）。"""
    with db.session() as c:
        row = c.execute("SELECT tenant_id FROM user WHERE id=?", (uid,)).fetchone()
    return ((row["tenant_id"] if row else "") or "t-default")


def _l170_tenant_scope(args, db, user) -> str:
    """L170 只读/低风险命令的租户作用域：返回有效 tenant；非系统/平台身份越权 403。

    与 HTTP 同口径：HTTP 租户来自会话（admin/reviewer 只能本租户），CLI 的 --tenant
    只是显式作用域，不能放大范围；系统管理员保留显式 --tenant（租户级只读）。
    """
    uid = str((user or {}).get("sub") or "")
    role = str((user or {}).get("role") or "")
    ut = _user_tenant(uid, db) if uid else ""
    tenant = str(getattr(args, "tenant", "") or "").strip()
    if ut and tenant and tenant != ut and role not in ("super_admin", "platform_op"):
        _err("无权跨租户访问", 403, err_code="forbidden")
    return tenant or ut or "t-default"


def _scope(args, db):
    from app.services import ctx
    return ctx.scoped(args.tenant, args.ws)


def _need_admin(uid):
    from app.services import account
    if not (set(account.roles_of(uid)) & {"admin", "super_admin"}):
        _err("无权限：需要管理员", 403, err_code="forbidden")


def _need(uid, code):
    from app.services import permissions
    if not permissions.has(uid, code):
        # 与 HTTP _guard 的权限拒绝同 code：CLI 的 stderr 必须可被脚本按
        # status + code 识别，不能只有文案。
        _err(f"无权限：{code}", 403, err_code="forbidden")


def _need_action(uid, user, action):
    """业务动作权限：与 HTTP _guard 的 permission.can 动作表同一事实源。

    DB 权限包（permissions.has）用于菜单/按钮与自定义角色；product 动作矩阵
    （permission.can）才是 HTTP 实际拒绝依据。CLI 过去只查 DB 权限包，导致
    admin「*」在 CLI 可执行 HTTP 403 的动作（如 admin 发起审核），F4 即此口径差。
    """
    from .services import permission as _perm
    if not _perm.can((user or {}).get("role") or "", action):
        _err(f"无权限（需 {action}）", 403, err_code="forbidden")


def _is_admin(uid) -> bool:
    from app.services import account
    return bool(set(account.roles_of(uid)) & {"admin", "super_admin"})


def _cli_actor(args, db):
    """CLI 身份：与 HTTP 会话用户同构（sub/id/role/roles）。"""
    from app.services import account
    uid = _user_id(args, db)
    roles = account.roles_of(uid) or ["reviewer"]
    role = next((r for r in ("super_admin", "admin", "reviewer", "platform_op")
                 if r in roles), roles[0])
    return uid, {"sub": uid, "id": uid, "role": role, "roles": roles}


def _set_scope(args):
    """显式设置 CLI 作用域，语义与 HTTP 每请求设置 current tenant/workspace 一致。"""
    from app.services import ctx
    ctx.set_context(args.tenant or "t-default", args.ws or "")


def _require_business_role(user):
    """补证/复核类命令允许的角色与 HTTP/service 保持一致。"""
    if str((user or {}).get("role") or "") not in ("admin", "super_admin", "reviewer"):
        _err("无权限", 403, err_code="forbidden")


def _case_allowed(args, db, case_id: str):
    """CLI case 统一入口：与 HTTP 同语义（404 不存在、403 无权、跨空间按项目空间判权）。

    P1（2026-11-22 节点穷举测试）：HTTP 项目列表跨空间汇总，打开非当前空间项目时
    自动把请求上下文切到项目所属空间；CLI 过去直接用 ``--ws``（默认 ws-default）
    判权，导致跨空间项目一律 403。这里在 403 时按项目真实空间重判一次，并把进程
    上下文绑到项目空间（与 HTTP ``_case_owned`` 同语义）。跨租户仍在首判 404、
    他人项目在二次判定仍 403，因此不放宽任何可见性。
    """
    from app.services import ids as _ids
    from app import repositories as _R
    _uid, user = _cli_actor(args, db)
    # CLI 的 --tenant/--ws 是显式作用域，不能借此越过账号自身租户。
    _urow = _R.users.get(_uid) or {}
    _ut = str(_urow.get("tenant_id") or "")
    if str(user.get("role") or "") not in ("super_admin", "platform_op"):
        if _ut and args.tenant and args.tenant != _ut:
            _err("无权跨租户访问", 403, err_code="forbidden")
        if _ut:
            args.tenant = _ut
    _set_scope(args)
    try:
        return _ids.resolve("case", case_id, user)
    except _ids.IDLookupError as e:
        if e.status != 403:
            _err(e.message, e.status, err_code=e.code, status=e.status)
        # 跨空间重判：取项目真实空间（R.cases.get 已按租户过滤，跨租户取不到）。
        _row = _R.cases.get(case_id) or {}
        _cw = str(_row.get("workspace_id") or "")
        if not _cw or _cw == str(args.ws or ""):
            _err(e.message, e.status, err_code=e.code, status=e.status)
        _prev_ws = args.ws
        args.ws = _cw
        _set_scope(args)
        try:
            return _ids.resolve("case", case_id, user)
        except _ids.IDLookupError as e2:
            args.ws = _prev_ws
            _set_scope(args)
            _err(e2.message, e2.status, err_code=e2.code, status=e2.status)


def _bind_case_scope(case_row: dict):
    """CLI 进程上下文切到案例真实租户/空间（与 HTTP 每请求上下文一致）。

    对象级例外授权的审计记录带 tenant_id/workspace_id，且 ``report_gate`` /
    ``report.check_gate`` 读取审计时按上下文过滤。CLI 只传 --tenant 时 workspace
    为空，若不在 case 解析后绑定真实空间，CLI 写入的授权记录在 HTTP 门禁里会因
    workspace 不匹配而不可见（跨入口不一致）。返回绑定时使用的 case 行。
    """
    from app.services import ctx
    row = case_row or {}
    if row:
        ctx.set_context(row.get("tenant_id") or "t-default",
                        row.get("workspace_id") or "")
    return row


def cmd_resolve(args, db):
    """kind + id 统一解析；与 HTTP /api/v1/resolve 同一服务/同一状态码。

    除 8 个主 kind 外，也支持二级 ID：manifest_result / manifest_evidence / batch。
    二级 ID 必须先解析到所属 case，再按租户/空间/归属判 403/404。
    """
    from app.services import ids as _ids
    from app import repositories as _R
    _uid, user = _cli_actor(args, db)
    _urow = _R.users.get(_uid) or {}
    _ut = str(_urow.get("tenant_id") or "")
    if str(user.get("role") or "") not in ("super_admin", "platform_op"):
        if _ut and args.tenant and args.tenant != _ut:
            _err("无权跨租户访问", 403, err_code="forbidden")
        if _ut:
            args.tenant = _ut
    _set_scope(args)
    kind = str(args.kind or "").strip().lower()
    if kind in ("manifest_result", "manifest_evidence", "batch"):
        from app.api.server import resolve_secondary
        obj, deny = resolve_secondary(kind, args.id, user)
        if deny:
            _err_deny(deny)
        _dump({"ok": True, "kind": kind, "object": obj})
    try:
        obj = _ids.resolve(kind, args.id, user)
    except _ids.IDLookupError as e:
        print(json.dumps({"ok": False, "error": e.message, "code": e.code,
                          "status": e.status}, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(status=e.status))
    _dump({"ok": True, "kind": kind, "object": obj})


def cmd_init(args, db):
    import subprocess
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    env = dict(os.environ)
    env["RULEPROOF_DB"] = str(db.DB_PATH)
    r = subprocess.run([sys.executable, "seed.py"], cwd=root, env=env,
                       capture_output=True, text=True)
    if r.returncode != 0:
        _err("seed 失败", 2, (r.stderr or r.stdout)[-800:])
    _dump({"ok": True, "db": str(db.DB_PATH), "seed": (r.stdout or "").strip().splitlines()[-1:]})


def cmd_serve(args, db):
    import subprocess
    cmd = [sys.executable, "-m", "app.api.server", "--port", str(args.port)]
    print(json.dumps({"ok": True, "cmd": " ".join(cmd)}, ensure_ascii=False), flush=True)
    r = subprocess.run(cmd)
    sys.exit(r.returncode)


def cmd_ws(args, db):
    from app.services import workspaces as W
    uid = _user_id(args, db)
    if args.action == "list":
        # T-199：空间查看权限点接线（旧 ws.view 死在 DB 里无消费方）。
        _need(uid, "ws.view")
        _dump({"ok": True, "items": W.list_for(uid, args.tenant)})
    if args.action == "create":
        _need(uid, "ws.manage")
        settings = {}
        if args.types:
            settings["doc_types"] = [x.strip() for x in args.types.split(",") if x.strip()]
        _res = W.create(args.name, uid, args.tenant, settings or None)
        # CLI 失败契约（T-81 D-01）：服务层业务拒绝（ok:false）必须 stderr + 非 0，
        # 与 HTTP POST /api/v1/workspaces/create 的 400 语义同源；不得 stdout 报 ok:true。
        if not _res.get("ok"):
            _err(str(_res.get("reason") or "创建空间失败"), 400,
                 err_code=str(_res.get("code") or "invalid_request"))
        _dump({"ok": True, "workspace": _res})
    if args.action == "settings":
        ws = args.ws
        if args.patch:
            _need(uid, "ws.manage")
            _dump({"ok": True, "settings": W.save_settings(ws, json.loads(args.patch))})
        _dump({"ok": True, "settings": W.get_settings(ws)})
    # ---- L91：补齐 HTTP /api/v1/workspaces 已有动作（members/rules-review/switch） ----
    if args.action == "members":
        # 与 HTTP GET /api/v1/workspaces/members 同口径：仅本租户可查看成员选择器。
        _need(uid, "ws.view")
        from app.services import account as _acc_m
        if not (set(_acc_m.roles_of(uid) or []) & {"admin", "super_admin"}):
            _err("仅业务管理员可查看空间成员", 403, err_code="forbidden")
        _dump({"ok": True, "items": W.member_options(_user_tenant(uid, db))})
    if args.action == "rules-review":
        # 与 HTTP GET /api/v1/workspaces/rules-review 同源：读当前（或 --ws 指定）空间的规则体检。
        from app.services import rules_review as _rr
        with _scope(args, db):
            _dump({"ok": True, **_rr.check(args.ws or "")})
    if args.action == "switch":
        # 与 HTTP POST /api/v1/workspaces/switch 同源（服务层：跨租户拒绝/不存在拒绝）。
        target = str(getattr(args, "id", "") or "").strip()
        if not target:
            _err("缺少 --id（目标空间 ID）", 2, err_code="invalid_argument", status=400)
        _res = W.switch(uid, target)
        if not _res.get("ok"):
            _err(str(_res.get("reason") or "切换空间失败"), 400,
                 err_code=str(_res.get("code") or "switch_failed"), status=400)
        _dump({"ok": True, **{k: v for k, v in _res.items()}})


def cmd_knowledge(args, db):
    """知识库 CLI（F1 评审 P0 第二批）：与 HTTP /api/v1/knowledge 同一服务层/同一权限/同一审计。

    修复前知识库只有 HTTP 入口、没有任何 CLI 命令，违反 AGENTS §1「CLI 是一等入口」
    （新增用户能力必须同时有 CLI，或书面说明为何不能）。本命令全部复用
    ``app.services.knowledge``：写操作（上传/重命名/移动/回收站/恢复/彻底删除）由
    服务层在同一事务写审计，角色/租户/空间与 HTTP 同源（业务管理员+审核员可用，
    系统管理员/平台运营 403）。

    动作（与 HTTP 路由一一对应）：
      list                    文件夹 + 文件（= GET /api/v1/knowledge）
      folders                 仅文件夹
      files                   仅文件（--folder-id root 表示根目录）
      upload --file PATH      上传（multipart 那条链路的同一 upload()，含 sha256 去重）
      rename --id ID --name N 重命名（文件或文件夹，--kind）
      move --id ID --folder-id 移动文件到一级文件夹（空=未归档）
      delete --id ID          删除进回收站（软删，可恢复；= POST op=trash）
      recycle                 回收站列表（= GET /api/v1/knowledge/recycle）
      restore --id ID         从回收站恢复（--kind file|folder）
      purge --id ID --confirm 彻底删除（不可恢复；必须显式二次确认）
    """
    from app import repositories as R
    from app.services import knowledge as KB
    from app.services import ctx as _ctx
    uid, user = _cli_actor(args, db)
    role = str(user.get("role") or "")
    if role in ("super_admin", "platform_op"):
        # 与 HTTP 同口径：知识库写/读都属审核业务，系统管理员/平台运营一律 403
        # （服务层 _ensure_role 还有第二道；这里提前给出 CLI 的 403 + 非 0 退出码）。
        _err("无权限：知识库仅业务角色在所属空间使用", 403, err_code="forbidden",
             status=403)
    user_tenant = _user_tenant(uid, db)
    tenant = (args.tenant or user_tenant or "t-default").strip()
    if user_tenant and tenant != user_tenant:
        _err(f"无权限：只能操作本租户（{user_tenant}）", 403, err_code="forbidden",
             status=403)
    urow = R.users.get(uid) or {}
    ws = str(args.ws or urow.get("current_workspace_id") or "ws-default").strip()
    with db.session() as c:
        wrow = c.execute("SELECT id,tenant_id,status FROM workspace WHERE id=?",
                         (ws,)).fetchone()
    if not wrow:
        _err(f"工作空间不存在：{ws}", 404, err_code="workspace_missing", status=404)
    if str(wrow["tenant_id"] or "") != tenant:
        _err("无权限：工作空间不属于当前租户", 403, err_code="forbidden", status=403)

    def _kb_call(fn, *a, **kw):
        try:
            return fn(*a, **kw)
        except KB.KnowledgeError as e:
            _err(e.message, int(e.status or 400), err_code=e.code, status=e.status,
                 detail={k: v for k, v in (e.extra or {}).items()})
        except Exception as e:  # noqa: BLE001 - 不静默失败：CLI 必须给出可读错误
            _err(f"知识库操作失败：{type(e).__name__}: {e}", 1,
                 err_code="internal_error")

    act = str(args.action or "list")
    with _ctx.scoped(tenant, ws):
        if act == "list":
            out = _kb_call(KB.list_knowledge, user,
                           folder_id=(str(args.folder_id or "") or None))
            _dump({**out, "action": "list", "role": role})
        if act == "folders":
            out = _kb_call(KB.list_knowledge, user, folder_id=None)
            _dump({"ok": True, "action": "folders", "tenant_id": out.get("tenant_id"),
                   "workspace_id": out.get("workspace_id"),
                   "count": len(out.get("folders") or []),
                   "items": out.get("folders") or []})
        if act == "files":
            out = _kb_call(KB.list_knowledge, user,
                           folder_id=(str(args.folder_id or "") or None))
            _dump({"ok": True, "action": "files", "tenant_id": out.get("tenant_id"),
                   "workspace_id": out.get("workspace_id"),
                   "folder_id": out.get("folder_id") or "",
                   "count": len(out.get("files") or []),
                   "items": out.get("files") or []})
        if act == "recycle":
            _dump({**_kb_call(KB.list_recycle, user), "action": "recycle", "role": role})
        if act == "upload":
            path = str(getattr(args, "file", "") or "")
            if not path:
                _err("缺少 --file（要上传的本地文件路径）", 2, err_code="invalid_request",
                     status=400)
            try:
                data = open(path, "rb").read()
            except OSError as e:
                _err(f"--file 读取失败：{e}", 2, err_code="invalid_request", status=400)
            out = _kb_call(KB.upload, user, os.path.basename(path), data,
                           folder_id=str(getattr(args, "folder_id", "") or ""),
                           source="cli")
            _dump({**out, "action": "upload"})
        if act in ("rename", "move", "delete", "restore", "purge"):
            oid = str(getattr(args, "id", "") or "").strip()
            if not oid:
                _err("缺少 --id", 2, err_code="invalid_request", status=400)
            kind = str(getattr(args, "kind", "") or "file")
            if kind not in ("file", "folder"):
                _err("--kind 只能是 file/folder", 2, err_code="invalid_request", status=400)
            if act == "rename":
                name = str(getattr(args, "name", "") or "")
                if not name.strip():
                    _err("缺少 --name", 2, err_code="invalid_request", status=400)
                out = (_kb_call(KB.rename_folder, user, oid, name) if kind == "folder"
                       else _kb_call(KB.rename_file, user, oid, name))
                _dump({**out, "action": "rename"})
            if act == "move":
                out = _kb_call(KB.move_files, user, [oid],
                               folder_id=str(getattr(args, "folder_id", "") or ""))
                _dump({**out, "action": "move"})
            if act == "delete":
                # 软删（进回收站）：与 HTTP POST op=trash 同源，可恢复。
                out = (_kb_call(KB.trash_folder, user, oid) if kind == "folder"
                       else _kb_call(KB.trash_files, user, [oid]))
                _dump({**out, "action": "delete", "recoverable": True})
            if act == "restore":
                out = _kb_call(KB.restore_items, user, kind, [oid])
                _dump({**out, "action": "restore"})
            if act == "purge":
                if not bool(getattr(args, "confirm", False)):
                    _err("彻底删除不可恢复，必须显式 --confirm", 2,
                         err_code="confirm_required", status=409)
                out = (_kb_call(KB.delete_folder, user, oid, confirm=True, purged=True)
                       if kind == "folder"
                       else _kb_call(KB.delete_file, user, oid, confirm=True, purged=True))
                _dump({**out, "action": "purge", "recoverable": False})
    _err("未知 action：" + act, 2, err_code="invalid_action", status=400)


_RULE_PUBLISH_HINTS = {
    "invalid_transition": "非法状态迁移",
    "concurrent_transition": "并发状态冲突",
    "executor_unreachable": "规则执行器不可达",
    "ir_invalid": "规则 IR 校验失败",
    "ir_incomplete": "规则 IR 不完整",
    "ir_needs_structure": "规则缺少正式发布条件",
    "scope_missing": "规则未声明适用范围",
    "conflict": "与已发布规则存在冲突",
    "regression_blocked": "版本回归未通过",
    "decision_table_binding_invalid": "决策表绑定失效",
    "decision_table_binding_unverified": "决策表绑定无法校验",
    "rule not found": "规则不存在",
    "no_version": "规则没有可提交版本",
}


def _rule_publish_failure(res) -> tuple:
    """把 rule.publish / publish_via_lifecycle 的错误体转成 (code, 可读中文原因)。

    T-96 P0-04：create --publish 失败必须向上传播；这里只做展示层归一，
    状态机/门禁判定仍以 app.services.rule 为事实源，不在这里放宽。
    """
    res = res if isinstance(res, dict) else {}
    code = str(res.get("error") or res.get("code") or "rule_publish_failed")
    label = _RULE_PUBLISH_HINTS.get(code, "")
    msg = str(res.get("message") or "").strip()
    if not msg:
        msg = label or code
    elif label and label not in msg:
        msg = label + "：" + msg
    return code, msg


def _rule_publish_status(res):
    """发布失败的真实 HTTP 状态（仅 4xx），用于 CLI 退出码契约映射。

    L91：``rule create --publish`` 发布门禁拒绝时 HTTP 是 422（缺结构可补）/400，
    旧 CLI 一律 exit 1；现在 422→6、400→2、403→4，与 ``_HTTP_EXIT_MAP`` 同源。
    非 4xx/缺失返回 None（保持原来的通用失败 exit 1）。
    """
    res = res if isinstance(res, dict) else {}
    try:
        st = int(res.get("http_status") or 0)
    except (TypeError, ValueError):
        st = 0
    return st if 400 <= st <= 499 else None


def _publish_result_fields(res) -> dict:
    """T-110：把发布结果展开为 CLI 顶层可读字段（状态/生效版本/发布后冲突提醒）。

    产品口径（2026-11-18，T-107/T-110）：规则发布无需审批，draft 可直接发布；
    发布成功后冲突检测只做提醒（记录 conflict_count/conflict_ids + 去向），
    **不阻断发布、不回滚**。故冲突不是失败：本函数只展开字段，不用来做错误判定。
    """
    res = res if isinstance(res, dict) else {}
    try:
        conflict_count = int(res.get("conflict_count") or 0)
    except Exception:
        conflict_count = 0
    out = {
        "status": str(res.get("status") or ""),
        "status_label": str(res.get("status_label") or res.get("label") or ""),
        "publish_mode": str(res.get("publish_mode") or ""),
        "approval_required": bool(res.get("approval_required", False)),
        "effective_version": str(res.get("effective_version") or ""),
        "effective_status": str(res.get("effective_status") or ""),
        "conflict_count": conflict_count,
        "conflict_ids": [str(x) for x in (res.get("conflict_ids") or []) if str(x or "").strip()],
        "conflict_reminder": str(res.get("conflict_reminder") or ""),
    }
    if conflict_count > 0:
        out["conflict_location"] = ("冲突提醒页（管理端/审核端「冲突提醒」；"
                                    "HTTP /api/v1/conflicts；CLI 暂无 conflict 命令）")
    return out


def _rulegen_cli(args, uid):
    """候选池 CLI：suggest(list)/gaps/gen/confirm/reject/shadow/publish，全部走服务层。

    输出 JSON；失败写 stderr 并返回服务层 status 作为退出码（403/400/404/409），
    与 HTTP 同源（同一批 app.services.rule.rulegen_* 函数、同一审计与权限）。
    """
    import json as _json
    from app.services import ctx as _ctx
    from app.services import rule as _rgs

    def _fail(out):
        _err(out.get("error") or "操作失败", int(out.get("status") or 1),
             detail={k: v for k, v in out.items()
                     if k not in ("error", "status", "ok")},
             err_code=str(out.get("code") or ""), status=int(out.get("status") or 1))

    def _read_file():
        path = str(getattr(args, "file", "") or "")
        if not path:
            _err("缺少 --file（JSON 输入文件）", 2, err_code="invalid_request", status=400)
        try:
            with open(path, encoding="utf-8") as f:
                return _json.load(f)
        except Exception as e:
            _err(f"--file 读取失败：{type(e).__name__}: {e}", 2,
                 err_code="invalid_request", status=400)

    with _ctx.scoped(args.tenant, args.ws):
        if args.action == "suggest":
            out = _rgs.rulegen_candidates(str(getattr(args, "status", "") or ""),
                                          int(getattr(args, "limit", 20) or 20), uid)
            if not out.get("ok"):
                _fail(out)
            return {"ok": True, "items": out.get("items") or [],
                    "total": out.get("total"), "contract": out.get("contract")}
        if args.action == "suggest-gaps":
            out = _rgs.rulegen_gaps(int(getattr(args, "limit", 50) or 50), uid)
            if not out.get("ok"):
                _fail(out)
            return out
        if args.action == "suggest-gen":
            payload = _read_file()
            if isinstance(payload, list):
                payload = {"items": payload}
            if not isinstance(payload, dict):
                _err("--file 必须是对象或数组", 2, err_code="invalid_request", status=400)
            out = _rgs.rulegen_suggest(payload, uid)
            if not out.get("ok"):
                _fail(out)
            return out
        cid = str(getattr(args, "id", "") or "")
        if not cid:
            _err("缺少 --id（候选 id）", 2, err_code="invalid_request", status=400)
        if args.action == "suggest-confirm":
            out = _rgs.rulegen_confirm(cid, uid)
        elif args.action == "suggest-reject":
            out = _rgs.rulegen_reject(cid, uid, reason=str(getattr(args, "reason", "") or
                                                            getattr(args, "name", "") or ""))
        elif args.action == "suggest-shadow":
            cases = None
            if str(getattr(args, "file", "") or ""):
                raw = _read_file()
                cases = raw.get("cases") if isinstance(raw, dict) else raw
            out = _rgs.rulegen_shadow(cid, cases, uid)
        elif args.action == "suggest-publish":
            out = _rgs.rulegen_publish(cid, uid)
        else:  # pragma: no cover
            _err("未知 suggest 动作", 2)
    if not out.get("ok"):
        _fail(out)
    return out


def cmd_rule(args, db):
    from app import repositories as R
    from app.services import rule as RS
    uid = _user_id(args, db)
    # L170：企业标准目录沉淀（HTTP POST /api/v1/sediment）。写操作，复用 HTTP 同一
    # 权限口径（仅业务管理员：_ADMIN_POST）与同一服务层 rule.import_from_standards
    # （每命中一条限值即调用 create_rule，写既有策略/候选审计），并保持 HTTP 的目录
    # 白名单（只允许 RULEPROOF_STANDARDS 或平台根目录内，越界 403）。
    if args.action == "import":
        from app.services import account as _acc_imp
        from app import config as _cfg_imp
        _role_imp = next((r for r in ("super_admin", "admin", "reviewer", "platform_op")
                          if r in set(_acc_imp.roles_of(uid) or [])), "")
        if _role_imp == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        if _role_imp != "admin":
            # HTTP：super_admin 被业务边界拒绝；reviewer/其他非管理员走 _ADMIN_POST 403。
            if _role_imp == "super_admin":
                _err("系统管理员不访问审核业务", 403, err_code="forbidden")
            _err("无权限（需管理员）", 403, err_code="forbidden")
        _dir_imp = str(getattr(args, "dir", "") or "").strip() or str(_cfg_imp.STANDARDS_DIR or "")
        if not _dir_imp:
            _err("未配置企业标准目录（RULEPROOF_STANDARDS）", 400,
                 err_code="not_configured", status=400)
        if not os.path.isdir(_dir_imp):
            _err(f"目录不存在：{_dir_imp}", 400, err_code="invalid_directory", status=400)
        _allowed_imp = os.path.realpath(_cfg_imp.STANDARDS_DIR or os.getcwd())
        _real_imp = os.path.realpath(_dir_imp)
        _root_imp = os.path.realpath(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))))
        if not (_real_imp == _allowed_imp
                or _real_imp.startswith(_allowed_imp + os.sep)
                or _real_imp == _root_imp or _real_imp.startswith(_root_imp + os.sep)):
            _err("目录不在允许的导入范围内", 403, err_code="forbidden_directory",
                 status=403)
        with _scope(args, db):
            try:
                _out_imp = RS.import_from_standards(_dir_imp)
            except Exception as _e_imp:  # noqa: BLE001 - 与 HTTP 同口径：导入失败 400
                _err(f"导入失败：{type(_e_imp).__name__}", 400,
                     err_code="import_failed", status=400)
        _dump({"ok": True, "dir": _dir_imp, **_out_imp})
    if args.action == "list":
        # T-107 P0-03 计数口径：items/count 仍是 DB rule 表行（机读兼容，不改变既有口径），
        # 另下发 counts = rule_library.rule_counts("tenant")（T-107 唯一计数事实源：
        # rule_rows / 内置-客户 / executable_versions / library_points / view_total，
        # 禁止把 DB 行与审核库点位相加混用）。status_label 与 rule.status_labels() 同源。
        from app.services import rule_library as _RL
        _labels = (RS.status_labels() or {}).get("rule") or {}
        with _scope(args, db):
            items = [{**{k: r.get(k) for k in ("id", "code", "name", "status", "category", "rclass")},
                      "status_label": _labels.get(str(r.get("status") or ""), "")}
                     for r in R.rules.list(order="created_at DESC")]
            try:
                _counts = _RL.rule_counts("tenant")
            except Exception:
                _counts = {}
        _dump({"ok": True, "items": items, "count": len(items),
               "count_scope": "db_rule_table", "counts": _counts})
    # ---------------- P0-5/T-191 D3：判据候选池闭环（与 HTTP 服务层同源） ----------------
    if args.action.startswith("suggest"):
        _sug = _rulegen_cli(args, uid)
        _dump(_sug)
    if args.action == "create":
        _need(uid, "rule.create")
        # T-96 P0-04：--publish 是显式发布动作，先校验发布权限再做任何写操作，
        # 避免 reviewer 建出草稿后才在发布阶段失败，留下“半成功”规则。
        if args.publish:
            _need(uid, "rule.publish")
        slots = {}
        if getattr(args, "evidence", ""):
            slots["required_evidence"] = args.evidence
        for k in ("criterion", "metric", "op", "value", "unit", "object"):
            v = getattr(args, k, None)
            if v not in (None, ""):
                slots["op" if k == "op" else k] = v
        if args.template:
            slots.setdefault("_template", args.template)
        _sl_scope = {"applicable_when": args.scope} if str(getattr(args, "scope", "") or "").strip() else {}
        with _scope(args, db):
            # F-01（build56 外部审查 P1）：透传真实操作人，rule.created_by 不得再写死
            # 'system'（审计追责缺口）。actor=uid 由服务层 _actor_role 解析角色并同时用于
            # created_by 落库（app/services/rule.py:created_by=actor or 'system'），与 HTTP
            # 入口（actor=会话用户）同源。
            out = RS.create_rule(code=args.code, name=args.name, category=args.category or "general",
                                 rclass=args.rclass or "R3", slots=slots, source="cli",
                                 scope=_sl_scope, actor=uid)
            if args.publish:
                # T-96 P0-04 + T-107/T-110 产品口径（2026-11-18）：规则不再需要审批，
                # draft 直接 publish；**不再走旧的 submit→approve→publish 链路**
                # （submit/approve 仅保留为旧数据/旧接口 legacy 兼容）。
                # 发布门禁（IR/执行器/scope）任一失败 → stderr 可读错误 + 退出码非 0；
                # 只有 DB 真正变 published 才输出 published，绝不静默假成功。
                pub = RS.publish(out["rule_id"], uid)
                latest = R.rules.get(out["rule_id"]) or {}
                if isinstance(pub, dict) and (pub.get("error") or pub.get("ok") is False):
                    code, msg = _rule_publish_failure(pub)
                    # L91：发布门禁 422（缺结构可补）→ CLI 退出码 6（_HTTP_EXIT_MAP），
                    # 不再一律退 1；真实 HTTP 状态保留在 stderr JSON 的 status 字段。
                    _err("规则已创建为草稿，但发布失败：" + msg, 1,
                         status=_rule_publish_status(pub),
                         detail={"rule_id": out["rule_id"],
                                 "status": str(latest.get("status") or "draft"),
                                 "publish": pub,
                                 "next_step": "草稿已保留（可直接编辑/补齐门禁后用"
                                              " `rule publish --id <rule_id>` 直发，新口径无需审批）"},
                         err_code=code)
                if str(latest.get("status") or "") != "published":
                    _err("规则发布失败：数据库状态未变为 published（当前 %s）"
                         % (str(latest.get("status") or "unknown")), 1,
                         detail={"rule_id": out["rule_id"], "publish": pub},
                         err_code="rule_publish_not_effective")
                out = dict(out)
                out.update(_publish_result_fields(pub))
                out["status"] = "published"
                out["publish"] = pub
        _dump({"ok": True, **out})
    def _find_rule(ref):
        return next((x for x in R.rules.list() if x.get("code") == ref or x.get("id") == ref), None)
    if args.action == "drift-report":
        # X-12 P0-2：回退一致性检查（不依赖开关当前值，列出「切到 0 会掉出执行集」的规则）
        _need(uid, "rule.publish")
        with _scope(args, db):
            _rep = RS.effective_selection_diff()
        _dump({"ok": True, **{k: v for k, v in _rep.items()}})
    if args.action == "repair-drift":
        # X-12 P0-2：漂移修复（dry-run 默认；--apply 才写库，逐条写审计、幂等）
        _need(uid, "rule.publish")
        _dry = not bool(getattr(args, "apply", False))
        with _scope(args, db):
            _out = RS.repair_effective_drift(dry_run=_dry, actor=uid)
        if not _out.get("ok"):
            _err("规则漂移修复失败", 1, detail=_out, err_code="repair_failed")
        _dump(_out)
    if args.action == "restore":
        r = _find_rule(args.id or args.code)
        if not r:
            _err(f"规则不存在：{args.id or args.code}")
        _dump(RS.restore_version(r["id"], getattr(args, "version", "") or "", uid))
    if args.action in ("publish", "submit", "approve", "archive", "rollback"):
        # reviewer：可提交审批（rule.submit），发布/批准/回滚仍仅管理员（rule.publish）
        _need(uid, "rule.submit" if args.action == "submit" else "rule.publish")
        # T-81 D-02：帮助同时声明 --id/--code，生命周期分支必须两者都解析，
        # 不得静默忽略 --id（修复前只按 --code 查找，--id 报『规则不存在：』）。
        _ref = args.id or args.code
        r = _find_rule(_ref)
        if not r:
            _err(f"规则不存在：{_ref}")
        fn = {"publish": RS.publish, "submit": RS.submit, "approve": RS.approve,
              "archive": RS.archive, "rollback": RS.rollback}[args.action]
        _res = fn(r["id"], uid) if args.action != "publish" else fn(r["id"])
        if isinstance(_res, dict) and _res.get("error"):
            # 生命周期失败统一 stderr 可读中文原因 + 非 0（T-96 P0-04 同类问题：
            # 只回英文 error code 会让脚本/用户无法判断合法状态迁移）。
            _code, _msg = _rule_publish_failure(_res)
            _err(_msg, 1, err_code=str(_res.get("code") or _code),
                 status=_rule_publish_status(_res),
                 detail={k: _res.get(k) for k in ("action", "rule_id", "from", "current")
                         if _res.get(k)})
        _payload = {"ok": True, "result": _res}
        if args.action == "publish":
            # T-110：显式 rule publish 也输出发布后冲突提醒（count/去向），冲突不算失败。
            _payload.update(_publish_result_fields(_res))
        _dump(_payload)
    if args.action == "static":
        from app.services import rule_static
        with _scope(args, db):
            _dump({"ok": True, **rule_static.analyze(args.ws)})
    if args.action == "mine":
        _need(uid, "rule.manage")
        from .services import rule_mining
        with _scope(args, db):
            _dump({"ok": True, **rule_mining.mine(args.limit)})
    if args.action == "mechanism-feedback":
        _need(uid, "rule.manage")
        from .services import mechanism_mining
        with _scope(args, db):
            _dump({"ok": True, **{k: v for k, v in mechanism_mining.mine_from_feedback(args.limit).items() if k != "specs"}})
    if args.action == "mechanism":
        _need(uid, "rule.manage")
        from .services import mechanism_mining
        _catalog = str(getattr(args, "catalog", "") or "")
        if not _catalog:
            _err("需要 --catalog 机制目录 JSON", 2, err_code="invalid_argument")
        try:
            specs = mechanism_mining.load_catalog(_catalog)
        except Exception as e:
            _err(f"读取机制目录失败：{e}", 2)
        with _scope(args, db):
            out = mechanism_mining.materialize(specs, publish=bool(args.publish), by=uid)
        _dump(out)

def _rule_tag_scope(args, db):
    """L50 规则分组标签 CLI 作用域：与 HTTP 每请求 ctx 同义。

    - 平台身份拒绝（与 HTTP _guard 同口径）；
    - --tenant 不能越过账号所属租户（与其它新业务命令同口径）；
    - --ws 必须是该租户下的启用空间，否则 404（不静默落默认空间）；
    - 系统管理员的业务写由 main() 的 _is_biz_cmd/_SUPER_BIZ_READ 在读白名单外拒绝。
    """
    from app import repositories as _R
    from app.services import ctx as _ctx
    uid, user = _cli_actor(args, db)
    role = str((user or {}).get("role") or "")
    if role not in ("reviewer", "admin", "super_admin"):
        _err("平台身份不可访问业务接口", 403, err_code="forbidden")
    _urow = _R.users.get(uid) or {}
    _ut = str(_urow.get("tenant_id") or "")
    if _ut and getattr(args, "tenant", "") and args.tenant != _ut:
        _err("无权跨租户访问", 403, err_code="forbidden")
    ws = str(getattr(args, "ws", "") or "") or "ws-default"
    with db.session() as c:
        wrow = c.execute("SELECT tenant_id FROM workspace WHERE id=? AND status='active'",
                         (ws,)).fetchone()
    if not wrow or str(wrow["tenant_id"] or "") != (_ut or ""):
        _err("工作空间不存在或不属于当前租户", 404, err_code="not_found")
    _ctx.set_context(_ut or "t-default", ws)
    return uid, user


def cmd_rule_tag(args, db):
    """规则分组标签（L50）：与 HTTP /api/v1/rules/tags* 同一服务层（同一权限/隔离/审计）。"""
    from app.services import rule_tags as RT
    uid, user = _rule_tag_scope(args, db)
    action = str(getattr(args, "action", "") or "")
    try:
        if action == "list":
            out = RT.list_tags(user)
        elif action == "create":
            if not str(getattr(args, "name", "") or "").strip():
                _err("需要 --name 标签名称", 2, err_code="invalid_argument")
            out = RT.create_tag(user, args.name, color=str(getattr(args, "color", "") or ""))
        elif action == "rename":
            if not str(getattr(args, "tag", "") or "").strip():
                _err("需要 --tag 标签 id", 2, err_code="invalid_argument")
            out = RT.rename_tag(user, args.tag,
                                name=(args.name if str(getattr(args, "name", "") or "").strip() else None),
                                color=(args.color if str(getattr(args, "color", "") or "").strip() else None))
        elif action == "delete":
            if not str(getattr(args, "tag", "") or "").strip():
                _err("需要 --tag 标签 id", 2, err_code="invalid_argument")
            out = RT.delete_tag(user, args.tag)
        elif action in ("assign", "unassign"):
            if not str(getattr(args, "tag", "") or "").strip():
                _err("需要 --tag 标签 id", 2, err_code="invalid_argument")
            rules = [str(x).strip() for x in (getattr(args, "rule", None) or []) if str(x).strip()]
            if not rules:
                _err("需要 --rule 规则 id/code（可重复）", 2, err_code="invalid_argument")
            body = {"rule_ids": rules}
            out = (RT.assign(user, args.tag, body) if action == "assign"
                   else RT.unassign(user, args.tag, body))
        elif action == "full-audit":
            if not str(getattr(args, "tag", "") or "").strip():
                _err("需要 --tag 标签 id", 2, err_code="invalid_argument")
            out = RT.full_audit(user, args.tag, limit=int(getattr(args, "limit", 200) or 200))
        else:
            _err("未知动作：%s" % action, 2, err_code="invalid_argument")
    except RT.RuleTagError as exc:
        payload = exc.payload()
        # CLI stderr 与其它命令同构：既有 http_status（服务层）也有 status（机读/退出码）。
        payload["status"] = int(exc.status)
        print(json.dumps(payload, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(status=exc.status))
    _dump(out)


def cmd_doc(args, db):
    # L170：文档类型主数据只读能力（HTTP GET /api/v1/doctypes、/api/v1/doctypes/last）。
    # 入口：`rp doctypes list|last`（main() 归一为 --types-list/--types-last）。
    if bool(getattr(args, "doctypes_list", False)) or bool(getattr(args, "doctypes_last", False)):
        from app.services import doctypes as _dt
        from app.services import ctx as _ctx_dt
        _uid, _user = _cli_actor(args, db)
        # HTTP /doctypes 属业务只读：平台运营身份不可访问业务接口（与 _guard 同码）。
        if str((_user or {}).get("role") or "") == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        # 文档类型/记忆表按租户隔离：上下文与 HTTP 每请求一致（账号租户 + --ws）。
        _tenant_dt = _l170_tenant_scope(args, db, _user)
        with _ctx_dt.scoped(_tenant_dt, str(getattr(args, "ws", "") or "")):
            if bool(getattr(args, "doctypes_list", False)):
                _dump({"ok": True, "tenant_id": _tenant_dt, "items": _dt.list_active()})
            _scope_name = str(getattr(args, "types_scope", "") or "project")
            _scope_id = str(getattr(args, "types_id", "") or "")
            _dump({"ok": True, "tenant_id": _tenant_dt,
                   **_dt.recall(_scope_name, _scope_id)})
    if not str(getattr(args, "file", "") or "").strip():
        _err("缺少文件参数：rp doc <文件路径>（文档类型主数据见 rp doctypes --help）",
             2, err_code="invalid_argument", status=400)
    from app.engine import deepparse
    try:
        parsed = deepparse.parse_and_extract(args.file)
    except Exception as e:
        _err(f"解析失败：{type(e).__name__}: {e}", 2)
    doc = parsed["doc"]
    # L144 fail-closed 后 parse_and_extract 对缺失/不支持文件返回 failed 而不是抛异常；
    # CLI 必须与旧异常语义一致：失败写 stderr、退出码 2，不能把空解析当 ok。
    _pst = str(doc.get("parse_status") or "ok")
    if _pst == "failed":
        _reason = str(doc.get("parse_error") or doc.get("parse_summary") or "解析失败")
        _err(f"解析失败：{_reason}", 2)
    _dump({"ok": True, "file": args.file, "sections": len(doc.get("sections") or []),
           "facts": parsed.get("fact_count", 0),
           "text": (doc.get("text") or "")[:args.preview]})


# ---------------- L163：L155 Extractor-Verifier 只读 CLI 能力 ----------------
# 与 HTTP 两个只读端点同一服务层/同一权限口径（review_routes.py 第二道角色校验）：
#   POST /api/v1/extraction/verify              -> rp extraction verify --input BODY.json
#   GET  /api/v1/extraction/confidence-policy   -> rp extraction confidence-policy
# 只读语义：不写库、不写审计、不调模型；未登录/越权一律 stderr JSON + 非 0 退出码。
_EXTRACTION_READ_ROLES = ("reviewer", "admin")


def _extraction_read_guard(args, db):
    """L163：抽取校验只读端点角色校验（与 HTTP _extraction_guard 同文案/同码）。"""
    uid, user = _cli_actor(args, db)
    role = str((user or {}).get("role") or "")
    if role not in _EXTRACTION_READ_ROLES:
        _err("仅审核员/业务管理员可使用抽取校验（只读）", 403, err_code="forbidden")
    return uid, user


def _extraction_body(args) -> dict:
    """读取 `--input` 的 JSON body（HTTP /api/v1/extraction/verify 同款契约）。

    参数/输入错误一律退出码 2（CLI 参数非法）且 stderr JSON 的 status=400，与
    HTTP 400 invalid_request 同口径；`-` 表示从 stdin 读取（便于管道）。
    """
    raw = str(getattr(args, "input", "") or "").strip()
    if not raw:
        _err("缺少 --input（HTTP /api/v1/extraction/verify 同款 JSON body 文件；- 表示 stdin）",
             2, err_code="invalid_argument", status=400)
    if raw == "-":
        try:
            text = sys.stdin.read()
        except Exception as exc:  # noqa: BLE001
            _err("读取 stdin 失败：%s" % type(exc).__name__, 2,
                 err_code="invalid_input", status=400)
    else:
        path = os.path.abspath(os.path.expanduser(raw))
        if not os.path.isfile(path):
            _err("输入文件不存在：%s" % raw, 2, err_code="input_not_found", status=400)
        try:
            with open(path, "r", encoding="utf-8") as fh:
                text = fh.read()
        except Exception as exc:  # noqa: BLE001
            _err("读取输入文件失败：%s" % type(exc).__name__, 2,
                 err_code="invalid_input", status=400)
    try:
        payload = json.loads(text or "")
    except Exception:  # noqa: BLE001
        _err("--input 必须是合法 JSON（与 HTTP /api/v1/extraction/verify body 同款）",
             2, err_code="invalid_json", status=400)
    if not isinstance(payload, dict) or not payload:
        _err("请求体必须是非空 JSON 对象（见 L155 接口契约）", 2,
             err_code="invalid_request", status=400)
    return payload


def cmd_kie(args, db):
    from app.engine import keyinfo
    from app.services import kie
    # L163：抽取校验（只读，与 HTTP /api/v1/extraction/* 同一服务层）。
    if getattr(args, "extraction_policy", False):
        _extraction_read_guard(args, db)
        from app.services import extraction_confidence as _ec_pol
        _dump({"ok": True, "contract": "l155/v1", "read_only": True,
               "policy": _ec_pol.confidence_policy()})
    if getattr(args, "extraction_verify", False):
        _extraction_read_guard(args, db)
        payload = _extraction_body(args)
        from app.services import extraction_confidence as _ec_ver
        from app.services import extraction_verifier as _ev_ver
        try:
            out = _ec_ver.score_request(payload)
        except _ev_ver.VerificationInputError as exc:
            _err(str(exc), 400, err_code=getattr(exc, "code", "invalid_request"),
                 status=400)
        except Exception as exc:  # noqa: BLE001 - 校验失败显式 500 语义（exit 1）
            _err("抽取校验失败：%s" % type(exc).__name__, 1, err_code="verify_failed")
        _payload = {"ok": True, "contract": "l155/v1", "read_only": True,
                    "verify": out.get("verify") or {},
                    "confidence": out.get("confidence") or {}}
        if bool(getattr(args, "no_confidence", False)):
            _payload.pop("confidence", None)
        _dump(_payload)
    if args.doc_id:
        _dump({"ok": True, **kie.extract_document(args.doc_id, args.type, bool(args.llm))})
    if args.file:
        from app.engine import deepparse
        try:
            _pd = deepparse.parse_and_extract(args.file)["doc"]
        except Exception as e:
            _err(f"解析失败：{type(e).__name__}")
        if str(_pd.get("parse_status") or "ok") == "failed":
            _err(f"解析失败：{_pd.get('parse_error') or _pd.get('parse_summary') or '解析失败'}", 2)
        text = _pd.get("text", "")
        _dump({"ok": True, **keyinfo.extract(text, doc_type=args.type, use_llm=bool(args.llm))})
    _err("需要 --file 或 --doc-id", 2)


def cmd_audit(args, db):
    from app.services import project
    uid, _audit_user = _cli_actor(args, db)
    if args.mode == "full":
        # legacy full 链不再作为产品模式暴露：HTTP POST /api/v1/reviews 对
        # mode=full 返回 400 invalid_mode（兼容契约测试锁定），CLI 同动作同状态/
        # 同错误码，不再出现“帮助宣称支持、argparse 先拒”的两套答案。
        # 参数合法性先于权限校验（与 HTTP 返回 invalid_mode 而非 403 一致）。
        _err("mode 只支持 manual/assisted", 400, err_code="invalid_mode")
    # 两模式都只允许审核员发起（HTTP POST /projects/{id}/audit 同表同码），
    # 业务管理员/系统管理员/平台身份一律 403。
    _need_action(uid, _audit_user, "audit.run")
    semantic = bool(getattr(args, "semantic", False) or (args.mode == "assisted"))
    with _scope(args, db):
        cid = project.create(args.name, user=uid, audit_type=args.type or "")
        for p in args.docs:
            project.add_document(cid, p, os.path.basename(p))
        try:
            # L61：把本次 CLI 请求模式显式登记给 version_snapshot（线程局部），
            # 快照落库时持久化 audit_mode/semantic/ai_assist/llm_enabled 组合。
            from app.services import version_snapshot as _vs_mode
            _vs_mode.note_request_mode(
                semantic=semantic, ai_assist=(args.mode == "assisted"),
                doc_type=args.type or "", source="cli:audit")
            try:
                out = project.audit(cid, semantic=semantic,
                                    ai_assist=(args.mode == "assisted"),
                                    doc_type=args.type or "", actor=uid)
            finally:
                _vs_mode.clear_request_mode()
        except Exception as _exc:
            # L52 ⑤：冻结清单阻断/0 执行 → CLI stderr JSON + 非 0 退出码（不静默成功）
            try:
                from app.services import single_entry as _se_cli
                if isinstance(_exc, _se_cli.ManifestExecutionBlocked):
                    _err(str(_exc), 1, err_code=_exc.code, detail=_exc.detail,
                         status=int(_exc.http_status))
            except Exception:  # noqa: BLE001
                pass
            raise
    _dump({"ok": True, "case_id": cid, "mode": args.mode,
           "semantic": semantic, "summary": out.get("summary"),
           "findings": len(out.get("findings") or [])})


def cmd_task(args, db):
    from app.services import task
    uid = _user_id(args, db)
    if args.action == "list":
        _dump({"ok": True, "items": task.list_tasks(limit=args.limit,
                                                    owner="" if _is_admin(uid) else uid)})
    elif args.action == "show":
        d = task.get(args.id)
        if d.get("error"):
            _err(d["error"], 404)
        if not _is_admin(uid) and d.get("owner") != uid:
            _err("无权限：不能查看他人任务", 403)
        _dump({"ok": True, "task": d})
    elif args.action == "cancel":
        d = task.get(args.id)
        if d.get("error"):
            _err(d["error"], 404)
        if not _is_admin(uid) and d.get("owner") != uid:
            _err("无权限：不能取消他人任务", 403)
        _dump({"ok": True, **task.cancel(args.id, uid)})


def cmd_point(args, db):
    from app.services import point_confirm
    uid = _user_id(args, db)
    # L170：审计分类元数据（HTTP GET /api/v1/audit-categories，只读）。
    # 与 HTTP 处理体同源：优先 auditpoints.load().categories，缺失时用内置 A-G 分类兜底。
    if args.action == "categories":
        from app.services import auditpoints as _ap
        _cats = []
        try:
            _lib = _ap.load()
            _cats = [{"id": c.get("id"), "name": c.get("name")}
                     for c in (getattr(_lib, "categories", None) or [])]
        except Exception:  # noqa: BLE001 - 点位库读取失败按 HTTP 同口径回退内置分类
            _cats = []
        if not _cats:
            _cats = [{"id": x, "name": y} for x, y in [
                ("A", "主体、资格与程序"), ("B", "结构与内容完备"), ("C", "事实、数据与证据"),
                ("D", "逻辑、论证与结论"), ("E", "权利义务与风险分配"),
                ("F", "商务、执行与合规底线"), ("G", "披露、申报与绩效")]]
        _dump({"ok": True, "items": _cats})
    with _scope(args, db):
        if args.action == "list":
            _dump({"ok": True, **point_confirm.status()})
        elif args.action in ("confirm", "revoke", "prepare", "activate"):
            # 与 HTTP 点位写路由同一门禁：仅 admin/super_admin（不是只查
            # rule.manage，否则自定义角色会在 CLI 放行、HTTP 403）。
            _need_admin(uid)
            if args.action == "confirm":
                _dump({"ok": True, **point_confirm.confirm(args.point_id, args.criterion or "", [], uid)})
            elif args.action == "revoke":
                _dump({"ok": True, **point_confirm.revoke(args.point_id, uid)})
            elif args.action == "prepare":
                _dump({"ok": True, **point_confirm.prepare_migration(
                    args.ws or args.workspace_id, uid)})
            else:
                _dump({"ok": True, **point_confirm.activate_workspace(
                    args.ws or args.workspace_id, uid)})
        elif args.action == "stale":
            if not args.case:
                _err("缺少 --case")
            from app.services import project as _pj
            _c = R.cases.get(args.case)
            if not _c:
                _err("项目不存在", 404)
            if not _is_admin(uid) and _c.get("created_by") != uid:
                _err("无权限：不能查看他人项目", 403)
            _dump(point_confirm.stale_for_case(args.case, notify=False))
        # ---- L91：补齐 HTTP /api/v1/audit-points 已有动作（复用同一服务层） ----
        elif args.action == "library":
            # GET /api/v1/audit-points/library：点位库（文件类型/审核类型/分类）。
            from app.api import point_routes as _ptr
            _dump({"ok": True, **_ptr._library()})
        elif args.action == "options":
            # GET /api/v1/audit-points/options：当前空间可选平台点位（HTTP 处理体复用的
            # 入参只有 session user，这里注入 CLI 身份 shim，避免复制一份取点逻辑）。
            from app.api import point_routes as _ptr
            _uid_o, _user_o = _cli_actor(args, db)

            class _CliSession(object):
                def _session_user(self):
                    return {"sub": _uid_o, "id": _uid_o,
                            "role": _user_o.get("role") or "",
                            "roles": _user_o.get("roles") or []}

            _dump({"ok": True, **_ptr._options(_CliSession())})
        elif args.action == "confirmations":
            # GET /api/v1/audit-points/confirmations：点位确认汇总（只读）。
            _dump({"ok": True, **point_confirm.status()})
        elif args.action == "route":
            # GET /api/v1/audit-points/route：按层级/规则族路由平台点位。
            from app.services import auditpoints as _ap
            _tier = str(getattr(args, "tier", "") or "S2")
            _fams = [x.strip() for x in str(getattr(args, "families", "") or "").split(",")
                     if x.strip()]
            _dump({"ok": True, "tier": _tier, "families": _fams,
                   "items": _ap.route(tier=_tier, families=_fams or None)})
        elif args.action == "recommended":
            # GET /api/v1/audit-points/recommended：按空间主文件类型推荐点位。
            _dump({"ok": True, **point_confirm.recommended(
                str(getattr(args, "workspace_id", "") or args.ws or ""))})
        elif args.action == "execute":
            # GET/POST /api/v1/audit-points/execute：单点语义执行（复用 extract 服务层；
            # HTTP 语义=直接返回执行结果，CLI 加 ok 包裹并保留 result 字段）。
            from app.services import extract as _extract
            _raw = str(getattr(args, "point_json", "") or "").strip()
            _pt = None
            if _raw.startswith("@"):
                _path = _raw[1:]
                if not os.path.exists(_path):
                    _err("--point-json 文件不存在：%s" % _path, 2,
                         err_code="invalid_argument", status=400)
                try:
                    _raw = open(_path, encoding="utf-8").read()
                except Exception as _e:  # noqa: BLE001
                    _err("读取 --point-json 文件失败：%s" % _e, 2,
                         err_code="invalid_argument", status=400)
            if _raw:
                try:
                    _pt = json.loads(_raw)
                except Exception:
                    _err("--point-json 必须是 JSON 对象", 2,
                         err_code="invalid_argument", status=400)
                if not isinstance(_pt, dict):
                    _err("--point-json 必须是 JSON 对象", 2,
                         err_code="invalid_argument", status=400)
            elif args.point_id:
                from app.services import auditpoints as _ap
                _pobj = _ap.point_index().get(str(args.point_id))
                if not _pobj:
                    _err("点位不存在：%s" % args.point_id, 404,
                         err_code="not_found", status=404)
                _pt = _pobj.to_dict() if hasattr(_pobj, "to_dict") else dict(_pobj)
            if not _pt:
                _err("execute 需要 --point-json（审核点 JSON）或 --point-id", 2,
                     err_code="invalid_argument", status=400)
            _txt = str(getattr(args, "text", "") or "")
            _tf = str(getattr(args, "text_file", "") or "")
            if _tf:
                if not os.path.exists(_tf):
                    _err("--text-file 不存在：%s" % _tf, 2,
                         err_code="invalid_argument", status=400)
                with open(_tf, encoding="utf-8", errors="replace") as _fh:
                    _txt = _fh.read()
            _out = _extract.execute_audit_point(_pt, _txt)
            _dump({"ok": True, "point_id": str(_pt.get("id") or args.point_id or ""),
                   "result": _out})


def cmd_artifacts(args, db):
    from app.services import semantic_artifacts
    _case_allowed(args, db, args.case)
    with _scope(args, db):
        out = semantic_artifacts.build(args.case, args.out or "")
    _dump(out)


def cmd_semantic(args, db):
    """确定性语义闭环：读取结构化根因 / 同案例重审。

    只读根因走既有 finding resolver（不存在 404、越权 403）；
    重审走 review 服务入口与项目归属校验，旧 run/finding 不覆盖。
    """
    from app.services import review
    from app import repositories as R
    uid, user = _cli_actor(args, db)
    _set_scope(args)
    if args.action == "root-cause":
        if args.finding:
            from app.services import ids as _ids
            try:
                row = _ids.resolve("finding", args.finding, user)
            except _ids.IDLookupError as e:
                _err(e.message, e.status, err_code=e.code, status=e.status)
            if args.case and str(row.get("case_id") or "") != str(args.case):
                _err("发现不存在", 404, err_code="not_found")
            out = review.semantic_root_cause(
                row, case_id=args.case or "", run_id=args.run or "")
            if not out.get("ok"):
                _err(out.get("reason") or "根因读取失败", int(out.get("status") or 404),
                     err_code=out.get("code") or "not_found")
            _dump(out)
        if not args.case:
            _err("需要 --finding 或 --case", 400, err_code="invalid_request")
        _case_allowed(args, db, args.case)
        rows = R.findings.list("case_id=?", (args.case,), order="rowid")
        if args.run:
            rows = [f for f in rows if str(f.get("run_id") or "") == str(args.run)]
        items = [review.semantic_root_cause(f, case_id=args.case) for f in rows]
        counts = {}
        for item in items:
            key = item.get("category") or "unknown"
            counts[key] = counts.get(key, 0) + 1
        _dump({"ok": True, "case_id": args.case, "total": len(items),
               "counts": counts, "items": items})
    if args.action == "reaudit":
        if not args.case:
            _err("需要 --case", 400, err_code="invalid_request")
        _case_allowed(args, db, args.case)
        out = review.reaudit_same_case(
            args.case, actor=uid, role=user.get("role") or "",
            rule_codes=args.rules or None, activate=bool(args.activate),
            reason=args.reason or "")
        if not out.get("ok"):
            _err(out.get("message") or out.get("error") or "重审失败",
                 int(out.get("status") or 400),
                 err_code=out.get("code") or "reaudit_failed")
        _dump(out)
    _err(f"未知动作：{args.action}", 400, err_code="invalid_action")


def cmd_extra(args, db):
    """Extra 复核裁决：与 HTTP 共用权限、feedback、审计逻辑。"""
    from app.services import extra_review
    uid, user = _cli_actor(args, db)
    from app.services import permission as _perm
    if not _perm.can(user.get("role") or "", "finding.decide"):
        _err("无权限（需 finding.decide）", 403, err_code="forbidden")
    _set_scope(args)
    r = extra_review.decide(args.rule_code, args.decision, quote=getattr(args, "quote", "") or "",
                            reason=getattr(args, "reason", "") or "",
                            case_id=getattr(args, "case", "") or "",
                            actor=user.get("name") or user.get("username") or uid)
    if not r.get("ok"):
        _err(r.get("error") or "裁决失败", 400, err_code="bad_request")
    _dump(r)


def cmd_project(args, db):
    from app.services import review, project
    from app.services import ctx as _ctx
    uid, user = _cli_actor(args, db)
    # L170：审核员「我的审核」（HTTP GET /api/v1/my-audits）。与 HTTP 同服务层
    # project.my_audits、同角色范围（reviewer=本人；admin=本租户全部；super_admin=租户级
    # 只读）、同分页/汇总/空态字段；admin/reviewer 与 HTTP 一样清空 workspace。
    if args.action == "my-audits":
        _role = str((user or {}).get("role") or "")
        if _role == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        _ut = _user_tenant(uid, db)
        _tenant = str(args.tenant or _ut or "t-default").strip()
        # 与 project list 同口径：--tenant 不能越权到其他租户（HTTP 租户来自会话）。
        if _ut and _tenant != _ut and _role not in ("super_admin", "platform_op"):
            _err("无权跨租户访问", 403, err_code="forbidden")
        _ws = "" if _role in ("admin", "reviewer") else str(args.ws or "")
        _page = max(1, int(getattr(args, "page", 1) or 1))
        _size = int(getattr(args, "page_size", 0) or 0)
        _size = min(100, max(1, _size or 20))
        with _ctx.scoped(_tenant, _ws):
            _data = project.my_audits(
                "" if _role in ("admin", "super_admin") else uid,
                status_f=str(getattr(args, "status", "") or ""),
                keyword=str(getattr(args, "q", "") or ""),
                date_from=str(getattr(args, "date_from", "") or ""),
                date_to=str(getattr(args, "date_to", "") or ""),
                page=_page, page_size=_size)
        _dump({"ok": True, "tenant_id": _tenant, **_data})
    if args.action == "list":
        # 项目列表与首页同口径：只按租户隔离，跨工作空间汇总；空间只作为筛选条件。
        # 不能把 --ws 塞进上下文，否则列表会退化成“当前空间”，与产品契约相反。
        user_tenant = _user_tenant(uid, db)
        tenant_id = (args.tenant or user_tenant or "t-default").strip()
        # 系统管理员是租户级角色：CLI --tenant 不能越权查看其他租户（与 HTTP 同口径；
        # 平台运营的平台级跨租户能力走平台接口，不经过业务项目列表）。
        if user_tenant and tenant_id != user_tenant:
            _err(f"无权限：只能查看本租户（{user_tenant}）", 403, err_code="forbidden")
        with _ctx.scoped(tenant_id, ""):
            data = project.list_projects(uid, _is_admin(uid))
        out = {"ok": True, "tenant_id": tenant_id}
        # stale_count/stale_project_count/stale_library_version 由
        # stats.decorate_project_list 接线；CLI 必须原样透出，不能只取 items。
        for key in ("items", "total", "page", "page_size", "pages",
                    "stale_count", "stale_project_count", "stale_library_version"):
            if key in data:
                out[key] = data[key]
        _dump(out)
    if args.action == "create":
        # L163：与 HTTP POST /api/v1/projects 同源——服务层 project.create（内部写
        # project.created 审计）、权限点 project.create（仅审核员；业务管理员/系统
        # 管理员/平台身份 403 与 HTTP 同口径）、tenant/ws 走 --tenant/--ws 作用域。
        uid, user = _cli_actor(args, db)
        _need_action(uid, user, "project.create")
        # 与 project list 同口径：--tenant 只是显式作用域，不能越权到其他租户
        # （HTTP 项目创建租户来自会话，不存在跨租户参数；CLI 必须同边界）。
        _ut = _user_tenant(uid, db)
        if (str((user or {}).get("role") or "") not in ("super_admin", "platform_op")
                and _ut and args.tenant and args.tenant != _ut):
            _err("无权跨租户访问", 403, err_code="forbidden")
        name = str(getattr(args, "name", "") or "").strip()
        if not name:
            _err("缺少 --name（项目名称）", 2, err_code="invalid_argument", status=400)
        with _scope(args, db):
            try:
                cid = project.create(
                    name, user=uid,
                    description=str(getattr(args, "description", "") or ""),
                    audit_type=str(getattr(args, "audit_type", "") or ""),
                    focus=str(getattr(args, "focus", "") or ""),
                    audit_category=str(getattr(args, "audit_category", "") or ""),
                    document_type=str(getattr(args, "document_type", "") or ""))
            except ValueError as e:
                # 与 HTTP 400 invalid_project 同码；非法文件类型/空间未配置等属参数错误。
                _err(str(e), 400, err_code="invalid_project", status=400)
        _dump({"ok": True, "project_id": cid, "case_id": cid, "name": name,
               "tenant_id": args.tenant, "workspace_id": args.ws})
    if args.action == "show":
        # L91（P1）：缺 --case 属参数错误 → 退出码 2（旧实现落到业务层 404/退出码 5，
        # 与“所有失败 = 参数 2 / 404 = 5”的退出码契约冲突）。
        if not str(getattr(args, "case", "") or "").strip():
            _err("缺少 --case（项目 ID）", 2, err_code="invalid_argument", status=400)
        _case_allowed(args, db, args.case)
        rep = review.case_report(args.case)
        if not rep:
            _err("项目不存在", 404, err_code="not_found")
        _dump({"ok": True, "case": rep.get("case"), "summary": rep.get("summary"),
               "layers": rep.get("layers"),
               "findings": [{k: f.get(k) for k in ("id", "rule_id", "title", "severity", "status", "layer")}
                            for f in rep.get("findings") or []]})


def cmd_finding(args, db):
    from app.services import review
    uid, user = _cli_actor(args, db)
    # L170：问题分析统计（HTTP GET /api/v1/analytics/issues）。与 HTTP 同服务层
    # analytics.summary、同范围规则：reviewer 只看本人数据且跨空间；admin 看本租户
    # 全部；super_admin 按 CLI --ws 作用域；平台运营 403。
    if args.action == "analytics":
        from app.services import analytics as _an15
        _role = str((user or {}).get("role") or "")
        if _role == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        _ut = _user_tenant(uid, db)
        _tenant = str(args.tenant or _ut or "t-default").strip()
        if _ut and _tenant != _ut and _role not in ("super_admin", "platform_op"):
            _err("无权跨租户访问", 403, err_code="forbidden")
        try:
            _days = int(getattr(args, "days", 30) or 30)
        except (TypeError, ValueError):
            _days = 30
        _days = max(1, min(_days, 365))
        # 与 HTTP 处理体逐字同口径：reviewer/admin 清空 workspace，只对 reviewer 加 owner。
        _ws = "" if _role in ("admin", "reviewer") else str(args.ws or "")
        _owner = uid if _role == "reviewer" else ""
        from app.services import ctx as _ctx15
        with _ctx15.scoped(_tenant, _ws):
            _res = _an15.summary(_ws, _tenant, _days, _owner)
        _dump({"ok": True, "tenant_id": _tenant, "days": _days, "analytics": _res})
    # 按 finding ID 直接判定时没有 case 参数：此时只设置作用域，由 finding resolver
    # 校验归属（不存在 404、他人/跨空间/跨租户 403）。只有显式 --case 才额外校验
    # case 本身的可见性与归属，不能把缺省值 None 传给 _case_allowed。
    _set_scope(args)
    # 权限必须先于对象解析：HTTP POST /findings/<id>/decision 在 _guard 里按
    # permission.can(role, "finding.decide") 判定，业务管理员（admin）不在该动作表
    # → 403。CLI 同动作必须同状态码，不能先解析 --case 而把 403 变成 404。
    if args.action == "decide":
        from app.services import permission as _perm
        if not _perm.can(user.get("role") or "", "finding.decide"):
            _err("无权限（需 finding.decide）", 403, err_code="forbidden")
    if args.action in ("list", "add") and not args.case:
        _err("需要 --case", 400, err_code="invalid_request")
    if args.case is not None:
        _case_allowed(args, db, args.case)
    if args.action == "list":
        rep = review.case_report(args.case)
        if not rep:
            _err("项目不存在", 404, err_code="not_found")
        _dump({"ok": True, "items": [{k: f.get(k) for k in ("id", "rule_id", "title", "severity", "status")}
                                     for f in rep.get("findings") or []]})
    if args.action == "decide":
        _need(uid, "audit.review")
        from app.services import ids as _ids
        try:
            _row = _ids.resolve("finding", args.finding, user)
        except _ids.IDLookupError as e:
            _err(e.message, e.status, err_code=e.code, status=e.status)
        if args.case and str(_row.get("case_id") or "") != str(args.case):
            _err("发现不存在", 404, err_code="not_found")
        # L148/T-③：裁决原因策略与 HTTP 同源（review_routes 单一实现）：误报/补证/忽略
        # 必须填写原因，未知动作 400 invalid_decision。校验在对象解析之后执行，
        # 保证 404/403 先于 400，与 HTTP finding_routes 的判定顺序一致。
        from app.api.review_routes import validate_decision_reason as _validate_reason
        _chk = _validate_reason(args.decision, args.reason or "")
        if not _chk.get("ok"):
            _payload = {"ok": False, "status": int(_chk.get("status") or 400),
                        "code": str(_chk.get("code") or "invalid_request"),
                        "error": str(_chk.get("error") or "参数错误"),
                        "decision": str(_chk.get("decision") or args.decision or ""),
                        "action": str(_chk.get("action") or "")}
            print(json.dumps(_payload, ensure_ascii=False), file=sys.stderr)
            sys.exit(_exit_code(status=_payload["status"]))
        _dump({"ok": True, "result": review.decide(args.finding, args.decision,
                                                   reason=args.reason or "", user=uid)})
    if args.action == "add":
        _need(uid, "audit.review")
        r = review.add_manual_finding(args.case, args.severity, args.title, args.detail,
                                      locator=args.locator, quote=args.quote,
                                      document_id=args.document, user=uid, user_id=uid)
        if r.get("error"):
            _err(r["error"], 400, err_code="bad_request")
        _dump({"ok": True, "finding": r})

def _evidence_err(r):
    """补证服务错误 → 与 HTTP 一致的状态码（403/404/400）。"""
    msg = str(r.get("error") or "补证操作失败")
    code = str(r.get("code") or "")
    if code == "forbidden":
        _err(msg, 403, err_code=code)
    if "不存在" in msg:
        _err(msg, 404, err_code="not_found")
    _err(msg, 400, err_code=code or "bad_request")


def cmd_evidence(args, db):
    """补证事项 CLI：与 HTTP 共用二级 ID resolver / manifest_exec。"""
    from app.services import manifest_exec as me
    uid, user = _cli_actor(args, db)
    _set_scope(args)
    _require_business_role(user)
    role = user.get("role") or "reviewer"
    from app.api.server import list_manifest_evidence, resolve_secondary
    if args.action == "list":
        payload, deny = list_manifest_evidence(args.result or "", user)
        if deny:
            _err_deny(deny)
        return _dump({"ok": True, **payload})
    if args.action == "request":
        _obj, deny = resolve_secondary("manifest_result", args.result, user)
        if deny:
            _err_deny(deny)
        _cl = [x for x in (args.checklist or "").split(",") if x.strip()]
        r = me.request_evidence(args.result, args.reason or "", uid, role, _cl)
        if r.get("error"):
            _evidence_err(r)
        return _dump({"ok": True, **r})
    if args.action in ("fulfill", "reaudit"):
        _obj, deny = resolve_secondary("manifest_evidence", args.evidence, user)
        if deny:
            _err_deny(deny)
        r = (me.fulfill_evidence(args.evidence, args.ref or "", uid, role)
             if args.action == "fulfill" else me.reaudit_evidence(args.evidence, uid, role))
        if r.get("error"):
            _evidence_err(r)
        return _dump({"ok": True, **r})
    _err("未知补证操作", 400, err_code="bad_request")


def _hr_exit(out: dict):
    """human-review 服务结果 → CLI 输出/退出码（与 HTTP 状态码同源）。

    失败时 stderr 保留服务层全部可机读字段（code/status/missing/allowed...），
    不能只留一句话：脚本要能按 status+code 识别，并与 HTTP body 对齐。
    """
    if not out.get("ok"):
        status = int(out.get("status") or 1)
        payload = dict(out)
        payload["ok"] = False
        payload.setdefault("status", status)
        payload.setdefault("code", "error")
        print(json.dumps(payload, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(status=status))
    _dump(out)


def _hr_locator(value: str) -> dict:
    """--locator 支持 JSON（document/sheet/row/line...）或自由文本。"""
    text = str(value or "").strip()
    if not text:
        return {}
    if text.startswith("{"):
        try:
            obj = json.loads(text)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
    return {"text": text}


def cmd_human_review(args, db):
    """T-43 人工复核闭环：与 HTTP 同一批服务函数（app.services.human_review）。

    权限/租户/审计与 HTTP 同源：
    - 审核员：本人项目可裁决展示项、登记漏报、后台对账；
    - 业务管理员：只读（status/queue/omissions/backend），写操作 403；
    - 系统管理员/平台运营：禁止访问审核业务（403，与 HTTP 一致）。
    """
    from app.services import human_review as _hr
    uid, user = _cli_actor(args, db)
    actor, role = uid, (user or {}).get("role") or ""
    if not args.case:
        _err("需要 --case", 400, err_code="invalid_request")
    case_row = _case_allowed(args, db, args.case)
    _bind_case_scope(case_row)
    action = str(args.action or "")
    _include_hidden = bool(getattr(args, "include_hidden", False))
    if action in ("status", "queue", "show"):
        out = _hr.case_payload(args.case, actor=actor, role=role,
                               include_hidden=_include_hidden, via="cli")
        if out.get("ok") and action == "queue":
            out = {"ok": True, "case_id": args.case,
                   "review": out.get("review") or {},
                   "gate": out.get("gate") or {},
                   "permissions": out.get("permissions") or {}}
        elif out.get("ok") and action == "show":
            # T-50：产品视图 = 工作台 + V3.2 §15 四项报告门禁（同源 product_gate）
            _pg = _hr.product_gate(args.case)
            out = {"ok": True, "case_id": args.case,
                   "case": out.get("case") or {},
                   "enabled": bool(out.get("enabled")),
                   "review": out.get("review") or {},
                   "decisions": out.get("decisions") or {},
                   "omissions": out.get("omissions") or {},
                   "gate": out.get("gate") or {},
                   "gates": _pg.get("gates") or {},
                   "gate_reasons": _pg.get("reasons") or [],
                   "gate_detail": _pg.get("detail") or {},
                   "manifest": _pg.get("manifest") or {},
                   # T-51：隐藏开关数据（默认仅摘要；--include-hidden 时含独立 items）
                   "hidden": out.get("hidden") or {},
                   "hidden_items": out.get("hidden_items") or [],
                   "review_mode": out.get("review_mode") or "",
                   "mode_label": out.get("mode_label") or "",
                   "independent_submitted": bool(out.get("independent_submitted")),
                   "permissions": out.get("permissions") or {},
                   "not_gold": True}
        return _hr_exit(out)
    if action == "backend":
        return _hr_exit(_hr.backend_view(args.case, actor=actor, role=role))
    if action == "omissions":
        return _hr_exit(_hr.list_omissions(args.case, actor=actor, role=role,
                                           status=args.status or ""))
    if action == "decide":
        if not args.item:
            _err("需要 --item（展示项 item_id）", 400, err_code="invalid_request")
        return _hr_exit(_hr.decide_item(
            args.case, args.item, args.decision or "",
            actor=actor, role=role, reason=args.reason or "",
            label=args.label or ""))
    if action == "omit":
        return _hr_exit(_hr.submit_omission(
            args.case, actor=actor, role=role, quote=args.quote or "",
            issue=args.issue or "", locator=_hr_locator(args.locator),
            rule_hint=args.rule_hint or "", subject=args.subject or "",
            object_id=args.object_id or "", note=args.note or ""))
    if action == "reconcile":
        return _hr_exit(_hr.reconcile_case(args.case, actor=actor, role=role))
    if action == "prepare":
        doc_text = ""
        if args.doc_text_file:
            try:
                with open(args.doc_text_file, encoding="utf-8") as f:
                    doc_text = f.read()
            except OSError as e:
                _err(f"读取 --doc-text-file 失败：{e}", 400, err_code="bad_request")
        return _hr_exit(_hr.prepare_case(args.case, actor=actor, role=role,
                                         doc_text=doc_text))
    _err(f"未知 human-review 操作：{action}", 400, err_code="invalid_request")


# ===========================================================================
# T-50（W-14）V3.2 产品接线 CLI：direct-draft / compare / visibility /
# ledger list|recover / omission add|list。全部只调用 app.services.human_review
# 的同一批服务函数（HTTP 也调同一批），权限/租户/审计在服务层，禁止入口各写一套。
# 失败：stderr 输出服务层可机读 JSON（status/code/missing...）+ 退出码=status；
# 成功：stdout 单个 JSON。全局 --db/--tenant/--ws/--user 对全部命令生效。
# ===========================================================================
def _bind_business_scope(args, db):
    """新业务读命令的 CLI 作用域：与 HTTP 每请求 ctx 同义，--tenant 不能越过账号租户。"""
    from app import repositories as _R
    uid, user = _cli_actor(args, db)
    role = str((user or {}).get("role") or "")
    if role not in ("reviewer", "admin"):
        _err("无权限：该命令仅审核员/业务管理员可用", 403, err_code="forbidden")
    _urow = _R.users.get(uid) or {}
    _ut = str(_urow.get("tenant_id") or "")
    if _ut and args.tenant and args.tenant != _ut:
        _err("无权跨租户访问", 403, err_code="forbidden")
    if _ut:
        args.tenant = _ut
    _set_scope(args)
    return uid, user


def _svc_out(out):
    """服务层结果 → CLI JSON/退出码（ok→stdout；失败→stderr + 同状态码）。"""
    if not out.get("ok"):
        status = int(out.get("status") or 1)
        payload = dict(out)
        payload["ok"] = False
        payload.setdefault("status", status)
        payload.setdefault("code", "error")
        print(json.dumps(payload, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(status=status))
    _dump(out)


def _read_text_file(path):
    if not path:
        return ""
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        _err(f"读取 --doc-text-file 失败：{e}", 400, err_code="bad_request")


def cmd_direct_draft(args, db):
    """直连草稿（不可变原始输出）：list/show，与 HTTP /api/v1/direct-drafts 同源。"""
    from app.services import human_review as HR
    uid, user = _bind_business_scope(args, db)
    role = str((user or {}).get("role") or "")
    if args.case:
        _bind_case_scope(_case_allowed(args, db, args.case))
    if args.action == "list":
        return _svc_out(HR.direct_draft_list(
            actor=uid, role=role, case_id=args.case or "", run_id=args.run or "",
            limit=args.limit, offset=args.offset))
    return _svc_out(HR.direct_draft_show(
        draft_id=args.draft or "", run_id=args.run or "", actor=uid, role=role))


def cmd_compare(args, db):
    """四桶差异（提示性比对）：list/show，与 HTTP /api/v1/comparisons 同源。"""
    from app.services import human_review as HR
    uid, user = _bind_business_scope(args, db)
    role = str((user or {}).get("role") or "")
    if args.case:
        _bind_case_scope(_case_allowed(args, db, args.case))
    if args.action == "list":
        return _svc_out(HR.comparison_list(
            actor=uid, role=role, case_id=args.case or "", bucket=args.bucket or "",
            visibility=args.visibility or "", human_status=args.human_status or "",
            limit=args.limit, offset=args.offset))
    if not args.item:
        _err("需要 --item（比对项 item_id）", 400, err_code="invalid_request")
    return _svc_out(HR.comparison_show(
        item_id=args.item, actor=uid, role=role,
        doc_text=_read_text_file(args.doc_text_file)))


def cmd_visibility(args, db):
    """可见性策略应用状态：show，与 HTTP /api/v1/visibility 同源。"""
    from app.services import human_review as HR
    uid, user = _bind_business_scope(args, db)
    role = str((user or {}).get("role") or "")
    if not args.case:
        _err("需要 --case", 400, err_code="invalid_request")
    _bind_case_scope(_case_allowed(args, db, args.case))
    return _svc_out(HR.visibility_show(case_id=args.case, actor=uid, role=role))


def cmd_omission(args, db):
    """人工漏报：add（写，审计）/list，与 HTTP /api/v1/human-omissions 同源。"""
    from app.services import human_review as HR
    uid, user = _bind_business_scope(args, db)
    role = str((user or {}).get("role") or "")
    if args.case:
        _bind_case_scope(_case_allowed(args, db, args.case))
    if args.action == "list":
        return _svc_out(HR.omission_list(
            actor=uid, role=role, case_id=args.case or "", status=args.status or "",
            limit=args.limit, offset=args.offset))
    if not args.case:
        _err("需要 --case", 400, err_code="invalid_request")
    return _svc_out(HR.submit_omission(
        args.case, actor=uid, role=role, quote=args.quote or "",
        issue=args.issue or "", locator=_hr_locator(args.locator),
        rule_hint=args.rule_hint or "", subject=args.subject or "",
        object_id=args.object_id or "", note=args.note or ""))


def cmd_hidden_item(args, db):
    """T-51 人工“显示隐藏疑似问题 (N)”开关：与 HTTP /hidden-items 同一批服务函数。

    list            默认关闭，只返回数量/进化摘要（production 显示 N；
                    evaluation 提交独立复核前不返回 N/内容）
    list --reveal   打开隐藏区（二次确认的显式动作；写 reveal 审计；返回独立区）
    confirm/reject/request-evidence/recover/merge/rule-error  逐条裁决（写审计）
    metrics         隐藏项指标（hidden_count/reveal_rate/TP/FP/recovery/time/
                    feedback_coverage，分 production/evaluation/source/reason）
    mode            读取/设置复核模式（--mode production|evaluation）
    submit-independent  评价/盲审模式提交独立复核（提交后才可打开隐藏项）
    evolution-defaults  无动作超 TTL → suspected_false_positive（weak_default，非 gold）
    enqueue         回填进化池（幂等；所有隐藏项 feedback_enqueued=true）
    """
    from app.services import human_review as HR
    action = str(args.action or "")
    uid, user = _bind_business_scope(args, db)
    role = str((user or {}).get("role") or "")
    if args.case:
        _bind_case_scope(_case_allowed(args, db, args.case))
    if action == "metrics":
        return _svc_out(HR.hidden_metrics(case_id=args.case or "", actor=uid,
                                          role=role))
    if action == "evolution-defaults":
        return _svc_out(HR.apply_evolution_defaults(
            case_id=args.case or "", actor=uid, role=role,
            ttl_days=args.ttl_days, dry_run=bool(args.dry_run)))
    if not args.case:
        _err("需要 --case", 400, err_code="invalid_request")
    if action == "list":
        if args.reveal or args.include_hidden:
            return _svc_out(HR.reveal_hidden(
                args.case, actor=uid, role=role, note=args.note or "", via="cli"))
        return _svc_out(HR.hidden_items(args.case, actor=uid, role=role,
                                        include_hidden=False, via="cli"))
    if action == "mode":
        if args.mode:
            # X-14 P0-3：业务管理员可用 --force --reason 受审计地强制回退 evaluation；
            # 审核员 --force 仍由服务层 403（同上 HTTP 口径）。
            if args.force:
                if not str(args.reason or "").strip():
                    _err("强制回退复核模式必须填写 --reason（写入审计）", 400,
                         err_code="force_reason_required")
            return _svc_out(HR.review_mode_set(
                args.case, args.mode, actor=uid, role=role,
                reason=args.reason or "", force=bool(args.force)))
        return _svc_out(HR.review_mode_get(args.case, actor=uid, role=role))
    if action == "submit-independent":
        return _svc_out(HR.submit_independent_review(
            args.case, actor=uid, role=role, note=args.note or ""))
    if action == "enqueue":
        return _svc_out(HR.enqueue_evolution_for_case(
            args.case, actor=uid, role=role, via="cli"))
    if not args.item:
        _err("需要 --item（隐藏项 ID / hidden_item_id）", 400,
             err_code="invalid_request")
    return _svc_out(HR.hidden_item_action(
        args.case, args.item, action, actor=uid, role=role,
        reason=args.reason or "", merge_into=args.into or "", via="cli"))


def cmd_shadow(args, db):
    """影子池（三区仲裁 Phase 2）：list/reveal/decide/metrics/export/escalate。

    与 HTTP ``/api/v1/projects/{cid}/shadow-items*`` **同一批服务函数**
    （``app.services.dual_track_gateway`` → ``shadow_pool``），因此权限/审计/状态码完全同源：

    - ``list``     默认只给 N/汇总（不返回明细）；``--reveal`` 等价打开明细（写审计）
    - ``reveal``   二次确认后打开（写 ``shadow.revealed`` 审计）；盲审未提交 403
    - ``decide``   四动作（confirm/false_positive/unsure/skip）；admin 403；discarded 409
    - ``metrics``  池大小/真问题比例/裁决耗时/升级率/weak 默认处置（非 gold）
    - ``export``   ``shadow.export``（默认仅业务管理员）；写审计；``--out`` 落文件
    - ``escalate`` 系统/调度动作：人类角色一律 403（服务层强制；HTTP 侧用调度令牌）

    成功 stdout 单个 JSON；失败 stderr JSON（含 status/code）+ 退出码=status。
    """
    # T-202 唯一入口约束：CLI 也只经 dual_track_gateway（不直接 import shadow_pool）。
    from app.services import dual_track_gateway as GW
    SP = GW
    uid, user = _bind_shadow_scope(args, db)
    role = str((user or {}).get("role") or "")
    action = str(getattr(args, "action", "") or "")
    if action == "escalate":
        # 系统/调度动作：人类角色一律 403（服务层强制，CLI 不能成为系统动作后门）。
        # 调度器用 `--system` 显式声明系统身份，且必须已配置 RULEPROOF_SCHEDULER_TOKEN
        # （与 HTTP X-Scheduler-Token 同一把钥匙，fail-closed）。
        case_ids = [x for x in str(getattr(args, "case", "") or "").replace(
            ",", " ").split() if x]
        if bool(getattr(args, "system", False)):
            token = str(os.environ.get("RULEPROOF_SCHEDULER_TOKEN") or "").strip()
            if not token:
                _err("未配置 RULEPROOF_SCHEDULER_TOKEN：拒绝系统动作（fail-closed）", 403,
                     err_code="scheduler_token_required", status=403)
            actor, role_eff = "system:scheduler", ""
        else:
            actor, role_eff = uid, role
        return _svc_out(SP.escalate_pending(
            case_ids, rounds=int(getattr(args, "rounds", None) or
                                 SP.DEFAULT_ESCALATION_ROUNDS),
            older_than_hours=int(getattr(args, "older_than_hours", None) or
                                 SP.DEFAULT_ESCALATION_HOURS),
            actor=actor, role=role_eff,
            dry_run=bool(getattr(args, "dry_run", False))))
    case_id = str(getattr(args, "case", "") or "")
    if not case_id:
        _err("需要 --case", 400, err_code="invalid_request")
    _bind_case_scope(_case_allowed(args, db, case_id))
    if action == "list":
        if args.reveal or args.include_hidden:
            return _svc_out(SP.shadow_items(
                case_id, reveal=True, actor=uid, role=role,
                reason=args.reason or "", status=args.status or "", via="cli"))
        return _svc_out(SP.shadow_items(
            case_id, reveal=False, actor=uid, role=role,
            reason=args.reason or "", status=args.status or "", via="cli"))
    if action == "reveal":
        # 二次确认：CLI 用 --confirm 显式确认，缺省拒绝（与 HTTP confirm=true 同义）。
        if not bool(getattr(args, "confirm", False)):
            _err("打开影子池需要二次确认（--confirm；打开动作将被审计）", 400,
                 err_code="confirm_required", status=400)
        return _svc_out(SP.shadow_items(
            case_id, reveal=True, actor=uid, role=role,
            reason=args.reason or "", status=args.status or "", via="cli_reveal"))
    if action == "decide":
        item_id = str(getattr(args, "item", "") or "")
        if not item_id:
            _err("需要 --item（影子项 id，如 shi_xxx）", 400, err_code="invalid_request")
        if not str(getattr(args, "decide_action", "") or "").strip():
            _err("需要 --action（confirm|false-positive|unsure|skip）", 400,
                 err_code="invalid_request")
        return _svc_out(SP.decide(
            case_id, item_id, str(args.decide_action), actor=uid, role=role,
            note=getattr(args, "note", "") or ""))
    if action == "metrics":
        return _svc_out(SP.shadow_metrics(case_id, actor=uid, role=role))
    if action == "export":
        out = SP.shadow_export(case_id, actor=uid, role=role,
                               include_discarded=not bool(
                                   getattr(args, "exclude_discarded", False)))
        if not out.get("ok"):
            return _svc_out(out)
        fmt = str(getattr(args, "format", "json") or "json").lower()
        out_path = str(getattr(args, "out", "") or "").strip()
        if fmt == "csv":
            from app.api.shadow_routes import _items_to_csv
            content = _items_to_csv(out.get("items") or [])
        elif fmt == "json":
            content = json.dumps(out, ensure_ascii=False, indent=1)
        else:
            _err("--format 仅支持 json|csv", 400, err_code="invalid_format", status=400)
        if out_path:
            try:
                with open(out_path, "w", encoding="utf-8") as f:
                    f.write(content)
            except OSError as e:
                _err(f"影子清单写入失败：{type(e).__name__}: {e}", 1)
            meta = {k: v for k, v in out.items() if k != "items"}
            meta["format"] = fmt
            meta["out"] = out_path
            meta["bytes"] = len(content.encode("utf-8"))
            return _dump(meta)
        if fmt == "csv":
            print(content, end="")
            return None
        return _dump(out)
    _err(f"未知 shadow 操作：{action}", 400, err_code="invalid_request")


def _bind_shadow_scope(args, db):
    """影子池 CLI 作用域：与 HTTP 会话同义（账号真实租户，禁止 --tenant 放大）。

    reviewer/admin 可用（admin 只读由服务层强制）；super_admin/platform_op 由
    ``_is_biz_cmd`` + 服务层双重拒绝（平台边界，与 HTTP 同口径）。
    """
    from app import repositories as _R
    uid, user = _cli_actor(args, db)
    role = str((user or {}).get("role") or "")
    if role not in ("reviewer", "admin", "super_admin", "platform_op"):
        _err("无权限：影子池仅审核员/业务管理员可用", 403, err_code="forbidden",
             status=403)
    _urow = _R.users.get(uid) or {}
    _ut = str(_urow.get("tenant_id") or "")
    if _ut and args.tenant and args.tenant != _ut:
        _err("无权跨租户访问", 403, err_code="forbidden", status=403)
    if _ut:
        args.tenant = _ut
    _set_scope(args)
    return uid, user


def _cmd_snapshot_show(args, db):
    """策略快照读取（L53）：`rp snapshot show --case <case> [--run <run>] [--summary] [--verify]`。

    - 只读；输出 JSON（stdout）。`--case` 必须命中当前身份可见的项目；
    - 未给 `--run` 时取该项目最新一条已保存快照；没有快照 → stderr JSON + 非 0；
    - 快照块含 snapshot_id / schema_version / engine_mode / parser_version /
      switches 覆盖与缺失清单 / content_fingerprint（去实例 id 的可跨库指纹）；
    - `--verify` 追加“保存时 vs 当前运行配置”一致性校验；
    - 缺库/无快照/run 不属于该项目都返回可读错误，不抛 traceback。
    """
    from app.services import version_snapshot as _vs
    from app import repositories as _R
    _case_allowed(args, db, args.case)
    case_id = str(args.case or "")
    run_id = str(getattr(args, "run", "") or "").strip()
    if run_id:
        row = _R.audit_runs.get(run_id) or {}
        if not row:
            _err(f"审核 run 不存在：{run_id}", 404, err_code="run_not_found", status=404)
        if str(row.get("case_id") or "") != case_id:
            _err(f"审核 run 不属于该项目：run={run_id} case={case_id}",
                 404, err_code="run_case_mismatch", status=404)
    else:
        saved = _vs.list_saved(case_id, limit=50)
        if saved:
            run_id = str(saved[0].get("run_id") or "")
        else:
            runs = _R.audit_runs.list("case_id=?", (case_id,),
                                      order="created_at DESC", limit=1)
            run_id = str((runs[0].get("id") if runs else "") or "")
    if not run_id:
        _err(f"该项目尚无审核 run，无策略快照可读：case={case_id}（库={str(db.DB_PATH)}）",
             404, err_code="run_missing", status=404)
    snap = _vs.load(case_id, run_id)
    if not snap:
        _err(f"未找到该 run 的策略快照：case={case_id} run={run_id}（库={str(db.DB_PATH)}）；"
             f"旧 run 可能早于快照上线或保存失败，可用 rp manifest --case 查看清单",
             404, err_code="snapshot_missing", status=404)
    block = _vs.report_block(snap)
    out = {
        "ok": True,
        "case_id": case_id,
        "run_id": run_id,
        "db": str(db.DB_PATH),
        "snapshot_id": snap.get("snapshot_id") or "",
        "digest": snap.get("digest") or "",
        "schema": snap.get("schema") or "",
        "schema_version": snap.get("schema_version") or snap.get("schema") or "",
        "engine_mode": snap.get("engine_mode") or "",
        "parser_version": snap.get("parser_version")
        or (snap.get("parser") or {}).get("version") or "",
        "switches_coverage": snap.get("switches_coverage") or "",
        "missing_switches": list(snap.get("missing_switches") or []),
        "content_fingerprint": ((snap.get("content_fingerprint") or {}).get("sha256") or ""),
        "report_block": block,
    }
    if getattr(args, "verify", False):
        try:
            out["verify"] = _vs.verify(case_id, run_id) or {}
        except Exception as exc:  # noqa: BLE001 - 校验失败要可读，不吞
            out["verify"] = {"found": False,
                             "error": f"{type(exc).__name__}: {str(exc)[:200]}"}
    if not getattr(args, "summary", False):
        # 默认输出完整快照（可追溯/可复核）；--summary 只出上面的摘要块。
        out["snapshot"] = snap
    _dump(out)


def _cmd_snapshot_replay(args, db):
    """历史快照重放（L61）：`rp snapshot replay --run <run> [--snapshot <id>] [--verify]`。

    - 默认**真实重跑**：用该 run 的冻结规则集合 + 持久化模式组合重跑一次审核，
      再比对 content_fingerprint / findings / 逐字引文；重跑写入新 audit_run 与
      `snapshot.replayed` 审计（不是模拟，也不改历史 run 结论）；
    - `--verify`：只做快照自身完整性 + 冻结闭包完整性 + 配置一致性校验，不重跑；
    - 退出码契约：0 一致；3 重放完成但结论不一致（stderr JSON 含 differences）；
      6 不可重放（快照被改/输入被改/配置漂移/模式未持久化，stderr JSON 含 blockers）；
      5 run/snapshot 不存在；4 无权限；2 参数非法。
    """
    from app.services import version_snapshot as _vs
    from app import repositories as _R
    run_id = str(getattr(args, "run", "") or "").strip()
    if not run_id:
        _err("需要 --run <run_id>（历史审核 run）", 400, err_code="invalid_request")
    row = _R.audit_runs.get(run_id) or {}
    if not row:
        _err(f"审核 run 不存在：{run_id}", 404, err_code="run_not_found", status=404)
    case_id = str(getattr(args, "case", "") or "").strip() or str(row.get("case_id") or "")
    if not case_id:
        _err(f"无法从 run 定位项目：run={run_id}", 404, err_code="case_not_found",
             status=404)
    if str(row.get("case_id") or "") and str(row.get("case_id") or "") != case_id:
        _err(f"审核 run 不属于该项目：run={run_id} case={case_id}", 404,
             err_code="run_case_mismatch", status=404)
    _case_allowed(args, db, case_id)
    execute = not bool(getattr(args, "verify", False))
    try:
        res = _vs.replay(case_id, run_id,
                         snapshot_id=str(getattr(args, "snapshot_id", "") or ""),
                         execute=execute,
                         actor=str(getattr(args, "user", "") or "cli"))
    except Exception as exc:  # noqa: BLE001 - CLI 失败要可读 JSON，不吐 traceback
        _err(f"重放失败：{type(exc).__name__}: {str(exc)[:300]}", 1,
             err_code="replay_failed")
    if not isinstance(res, dict):
        _err("重放返回非对象", 1, err_code="replay_failed")
    if not res.get("found"):
        _err(res.get("error") or "快照不存在", 404,
             err_code=res.get("code") or "snapshot_missing", status=404)
    _findings = res.get("findings") or {}
    payload = {
        "ok": True,
        "mode": res.get("mode") or ("replay" if execute else "verify"),
        "case_id": case_id,
        "run_id": run_id,
        "snapshot_id": res.get("snapshot_id") or "",
        "db": str(db.DB_PATH),
        "replayable": bool(res.get("replayable")),
        "executed": bool(res.get("executed")),
        "identical": bool(res.get("identical")),
        "snapshot_integrity_ok": res.get("snapshot_integrity_ok"),
        "content_identical": res.get("content_identical"),
        "content_fingerprint": res.get("content_fingerprint"),
        "findings": {k: _findings.get(k) for k in
                     ("identical", "stored_count", "replayed_count", "added_count",
                      "removed_count", "changed_count", "stored_fingerprint",
                      "replayed_fingerprint")},
        "finding_diff": {k: _findings.get(k) for k in ("added", "removed",
                                                       "changed_groups", "quotes")},
        "modes": res.get("modes"),
        "mode_combination": ((res.get("modes") or {}).get("stored_combination") or ""),
        "replay_blockers": res.get("replay_blockers") or [],
        "differences": res.get("differences") or [],
        "new_run_id": res.get("new_run_id") or "",
        "new_snapshot_id": res.get("new_snapshot_id") or "",
        "input_check": res.get("input_check"),
        "config_check": res.get("config_check"),
        "caveats": res.get("caveats") or [],
        "checked_at": res.get("checked_at") or "",
    }
    payload["audit_events"] = (["snapshot.replayed"] if payload["executed"]
                               else ["snapshot.replay_verified"])
    if not payload["replayable"]:
        payload["ok"] = False
        payload["code"] = "replay_not_replayable"
        payload["reason"] = ("不可重放：" + "；".join(
            str(b.get("detail") or b.get("code")) for b in payload["replay_blockers"])[:800])
        print(json.dumps(payload, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(6))
    if not payload["identical"]:
        payload["ok"] = False
        payload["code"] = "replay_mismatch"
        payload["reason"] = "重放完成但结论不一致（见 differences）"
        print(json.dumps(payload, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(3))
    _dump(payload)


def _cmd_snapshot_cleanup(args, db):
    """`rp snapshot replay --cleanup [--case] [--apply] [--keep-days N] [--keep-last N]`。

    L98 P1：清理 replay 派生临时 run/工件（runsnapshot v2/冻结闭包键/manifest 结果/
    finding 及其子表/llm_trace/audit_run）。**默认 dry-run**，`--apply` 才执行；
    保留策略默认 keep-days=7 + 每案例 keep-last=1；人工痕迹/报告引用/最新 run/
    被其他 replay 引用/历史有效 run 一律保护。退出码：0 成功（dry-run 也 0）；
    4 无权限；5 案例不存在。审计：`snapshot.replay_cleanup`。
    """
    from app.services import version_snapshot as _vs
    uid, user = _cli_actor(args, db)
    case_id = str(getattr(args, "case", "") or "").strip()
    if not case_id:
        _err("需要 --case <case_id>（replay 派生 run 归属具体案例；平台级请逐案例执行）",
             2, err_code="invalid_argument")
    _case_allowed(args, db, case_id)
    dry = not bool(getattr(args, "apply", False))
    res = _vs.replay_cleanup(
        case_id=case_id, dry_run=dry,
        keep_days=int(getattr(args, "keep_days", 7) or 0),
        keep_last=int(getattr(args, "keep_last", 1) or 0),
        actor=uid or "cli")
    if not res.get("ok"):
        _err(res.get("error") or "清理失败", 1, err_code="cleanup_failed")
    payload = {"ok": True, "action": "snapshot_replay_cleanup", "db": str(db.DB_PATH),
               **res}
    payload["next_action"] = ("确认计划后加 --apply 执行清理"
                              if dry else "已执行清理（审计 snapshot.replay_cleanup）")
    _dump(payload)


_GLOBAL_VALUE_OPTS = ("--db", "--tenant", "--ws", "--user")


def _snapshot_argv(argv):
    """把 `rp [全局参数] snapshot show ...` 归一成 `rp ... manifest --snapshot-show ...`。

    为什么不新增顶层子命令：`scripts/qa/platform_cli_menu_test.py` 要求
    web/platform.js 的 CLI_ALL 与 build_parser() 子命令**逐个一致**；新增顶层命令会
    迫使改 web/（本轮由 L51 前端 lane 独占）。用 argv 归一既保留
    `rp snapshot show` 的一等入口体验，又不改变 build_parser() 的命令集合。
    """
    argv = list(argv or [])
    # 找到首个非全局选项的位置（全局参数可出现在子命令前：rp --user x snapshot show）
    idx, i = None, 0
    while i < len(argv):
        tok = str(argv[i])
        if tok in _GLOBAL_VALUE_OPTS:
            i += 2
            continue
        if any(tok.startswith(opt + "=") for opt in _GLOBAL_VALUE_OPTS):
            i += 1
            continue
        if tok.startswith("-"):
            return argv  # -h/未知全局参数：交给 argparse 处理
        idx = i
        break
    if idx is None or str(argv[idx]) != "snapshot":
        return argv
    prefix, rest = argv[:idx], argv[idx + 1:]
    if rest and rest[0] in ("-h", "--help"):
        print("usage: rp snapshot show --case <case_id> [--run <run_id>] "
              "[--summary] [--verify]\n"
              "       rp snapshot replay --run <run_id> [--snapshot <snapshot_id>] "
              "[--case <case_id>] [--verify]\n"
              "       rp snapshot replay --cleanup --case <case_id> [--apply] "
              "[--keep-days N] [--keep-last N]\n"
              "策略快照读取/历史重放/重放派生 run 清理（L53/L61/L98）：JSON stdout；"
              "缺库/无快照/无权限 → stderr JSON + 非 0 退出码；replay 不一致→3，"
              "不可重放→6；cleanup 默认 dry-run，--apply 执行。")
        sys.exit(0)
    action = rest[0] if rest and not str(rest[0]).startswith("-") else "show"
    if action == "show" and "--replay" in rest:
        # 契约允许 `rp snapshot show --replay` 作为 replay 别名：先剥掉 "show" 再切动作，
        # 否则 "show" 会作为位置参数残留给 argparse。
        rest = rest[1:]
        action = "replay"
        rest = [x for x in rest if x != "--replay"]
    if action == "replay":
        rest = rest[1:] if rest and str(rest[0]) == action else rest
        # replay 的 case 可从 run 反查：argparse 的 --case 是 required，这里补空值占位，
        # cmd_manifest 分支再按 run→case 解析（不改变 manifest 原有 required 契约）。
        if not any(tok == "--case" or str(tok).startswith("--case=") for tok in rest):
            rest = ["--case", ""] + rest
        # L98：`--cleanup`（含 --apply/--keep-days/--keep-last）不需要 --run
        return prefix + ["manifest", "--snapshot-replay"] + rest
    if action != "show":
        _err(f"未知 snapshot 操作：{action}（支持 show/replay）", 400,
             err_code="invalid_request")
    rest = rest[1:] if rest and rest[0] == action else rest
    return prefix + ["manifest", "--snapshot-show"] + rest


def _report_argv(argv):
    """把 `rp [全局参数] report sign|export ...` 归一成 `rp ... report --report-sign|--report-export ...`。

    为什么不新增顶层子命令：``scripts/qa/platform_cli_menu_test.py`` 要求 web/platform.js
    的 CLI_ALL 与 ``build_parser()`` 子命令**逐个一致**；新增顶层命令会迫使改 web/。
    与 ``_snapshot_argv`` 同一做法：argv 归一既保留 ``rp report sign`` 一等入口体验，
    又不改变命令集合。老用法 ``rp report <case> --format html`` 原样透传。
    """
    argv = list(argv or [])
    idx, i = None, 0
    while i < len(argv):
        tok = str(argv[i])
        if tok in _GLOBAL_VALUE_OPTS:
            i += 2
            continue
        if any(tok.startswith(opt + "=") for opt in _GLOBAL_VALUE_OPTS):
            i += 1
            continue
        if tok.startswith("-"):
            return argv  # -h/未知全局参数：交给 argparse 处理
        idx = i
        break
    if idx is None or str(argv[idx]) != "report":
        return argv
    prefix, rest = argv[:idx], argv[idx + 1:]
    if rest and str(rest[0]) in ("-h", "--help"):
        print("usage: rp report <case> [--format html|docx|csv] [--out PATH]\n"
              "       rp report sign --id <report_id> [--content-hash sha256:...] "
              "[--note TEXT]\n"
              "       rp report export --id <report_id> [--format html|docx] --out PATH\n"
              "报告签发/导出（L94）：与 HTTP POST /api/v1/reports/{id}/sign|export 同一"
              "服务层/权限/审计。\n"
              "  sign   仅审核员本人项目；重复签发幂等（already_signed=true）；内容 hash "
              "不一致 → 非 0 + content_hash_mismatch。\n"
              "  export 只导出已签发报告；未签发 → report_not_signed；无报告行 → "
              "report_not_generated；审计 report.exported。\n"
              "  失败写 stderr JSON（status 为真实 HTTP 状态码），退出码分类见 docs/CLI手册.md。")
        sys.exit(0)
    if rest and str(rest[0]) in ("sign", "export"):
        action = str(rest[0])
        return prefix + ["report", "--report-" + action] + rest[1:]
    return argv


def _extraction_argv(argv):
    """把 `rp [全局参数] extraction verify|confidence-policy ...` 归一为 `rp kie --extraction-* ...`。

    为什么不新增顶层子命令：``scripts/qa/platform_cli_menu_test.py`` 要求 web/platform.js
    的 CLI_ALL 与 ``build_parser()`` 子命令**逐个一致**；新增顶层命令会迫使改 web/。
    与 ``_snapshot_argv``/``_report_argv`` 同一做法：argv 归一保留
    ``rp extraction ...`` 一等入口体验，又不改变 build_parser() 的命令集合。

    L163：L155 Extractor-Verifier 只读能力的 CLI 入口，与 HTTP
    ``POST /api/v1/extraction/verify``、``GET /api/v1/extraction/confidence-policy``
    同一服务层（extraction_confidence.score_request / confidence_policy）、同一角色
    口径（仅 reviewer/admin）、同一只读语义（不写库/不写审计/不调模型）。
    """
    argv = list(argv or [])
    idx, i = None, 0
    while i < len(argv):
        tok = str(argv[i])
        if tok in _GLOBAL_VALUE_OPTS:
            i += 2
            continue
        if any(tok.startswith(opt + "=") for opt in _GLOBAL_VALUE_OPTS):
            i += 1
            continue
        if tok.startswith("-"):
            return argv  # -h/未知全局参数：交给 argparse 处理
        idx = i
        break
    if idx is None or str(argv[idx]) != "extraction":
        return argv
    prefix, rest = argv[:idx], argv[idx + 1:]
    if not rest or str(rest[0]) in ("-h", "--help"):
        print("usage: rp extraction verify --input BODY.json|-\n"
              "       rp extraction confidence-policy\n"
              "L155 Extractor-Verifier 只读能力（与 HTTP /api/v1/extraction/verify、\n"
              "/api/v1/extraction/confidence-policy 同一服务层；仅 reviewer/admin）：\n"
              "  verify             抽取值校验 + 字段级置信度；--input 为 HTTP 同款 JSON body\n"
              "                     （- 表示 stdin）。返回 {ok,contract,read_only,verify,confidence}；\n"
              "                     --no-confidence 可省略 confidence（等价 HTTP include_confidence=false）。\n"
              "  confidence-policy  置信度策略/阈值/信号（只读）。\n"
              "只读：不写库、不写审计、不调模型；失败写 stderr JSON（status 为真实 HTTP 状态码）\n"
              "且退出码非 0；缺 --input/JSON 非法=2，无权限=4，接口契约错误=2。")
        sys.exit(0)
    action = str(rest[0])
    if action == "verify":
        return prefix + ["kie", "--extraction-verify"] + rest[1:]
    if action in ("confidence-policy", "policy"):
        extra = [str(x) for x in rest[1:]]
        if extra:
            _err("confidence-policy 不接受多余参数：%s" % " ".join(extra), 400,
                 err_code="invalid_request")
        return prefix + ["kie", "--extraction-policy"]
    _err("未知 extraction 操作：%s（支持 verify/confidence-policy）" % action, 400,
         err_code="invalid_request")


_L170_PRODUCT_ALIASES = ("doctypes", "me", "feedback", "alerts",
                         "capabilities", "dashboard")
_L170_PRODUCT_USAGE = """usage: rp doctypes list|last | rp me [--permissions] | rp feedback list|mine|settle
       rp alerts | rp capabilities | rp dashboard
L170 产品级只读/低风险能力（与 HTTP 同服务层、同权限、同 JSON 字段）：
  rp doctypes list                                文档类型主数据（GET /api/v1/doctypes）
  rp doctypes last [--scope project|user] [--id ID] 上次选择的文档类型（GET /doctypes/last）
  rp me [--permissions]                           本人身份 / 角色权限自查（GET /me、/me/permissions）
  rp feedback list [--kind K] [--status S] [--limit N]  复核反馈台账（GET /feedback，管理员）
  rp feedback mine                                我的复核反馈（GET /feedback/mine）
  rp feedback settle --id F [--action A] [--note N] [--auto-publish]
                                                  反馈沉淀/忽略（POST /feedback/<id>/settle，管理员）
  rp alerts                                       主动告警（GET /api/v1/alerts）
  rp capabilities                                 系统能力/上限（GET /api/v1/system/capabilities）
  rp dashboard                                    全局 KPI（GET /api/v1/dashboard，管理员）
保持 49 个 CLI 顶层命令不变：以上入口由 main() 归一成既有命令的隐藏动作/子动作。
只读语义：不写库、不写审计（feedback settle 为业务写：复用 feedback.settle 权限与审计）。
失败写 stderr JSON（status 为真实 HTTP 状态码）且退出码非 0；缺参=2，无权限=4，不存在=5。"""


def _l170_product_argv(argv):
    """L170：把 ``rp doctypes|me|feedback|alerts|capabilities|dashboard`` 归一为既有命令。

    为什么不新增顶层子命令：``scripts/qa/platform_cli_menu_test.py`` 要求 web/platform.js
    的 CLI_ALL 与 ``build_parser()`` 子命令逐个一致；新增顶层命令会迫使改 web/（不在本
    lane 写作用域）。与 ``_snapshot_argv``/``_report_argv``/``_extraction_argv`` 同一模式：
    一等入口体验保留，build_parser() 命令集合（49）不变。
    """
    argv = list(argv or [])
    if not argv:
        return argv
    # 找到首个非全局选项的位置（全局参数可出现在子命令前：rp --user x me）。
    idx, i = None, 0
    while i < len(argv):
        tok = str(argv[i])
        if tok in _GLOBAL_VALUE_OPTS:
            i += 2
            continue
        if any(tok.startswith(opt + "=") for opt in _GLOBAL_VALUE_OPTS):
            i += 1
            continue
        if tok.startswith("-"):
            return argv  # -h/未知全局参数：交给 argparse
        idx = i
        break
    if idx is None or str(argv[idx]) not in _L170_PRODUCT_ALIASES:
        return argv
    name = str(argv[idx])
    prefix, rest = argv[:idx], argv[idx + 1:]
    if rest and str(rest[0]) in ("-h", "--help"):
        print(_L170_PRODUCT_USAGE)
        sys.exit(0)

    if name == "doctypes":
        action = str(rest[0]) if rest and not str(rest[0]).startswith("-") else ""
        if not action:
            print(_L170_PRODUCT_USAGE)
            sys.exit(0)
        extra = []
        if action == "list":
            if rest[1:]:
                _err("doctypes list 不接受参数：%s" % " ".join(str(x) for x in rest[1:]),
                     400, err_code="invalid_request")
            return prefix + ["doc", "--types-list"]
        if action == "last":
            j = 1
            while j < len(rest):
                tok = str(rest[j])
                if tok in ("--scope", "--types-scope"):
                    if j + 1 >= len(rest):
                        _err("%s 缺少取值" % tok, 400, err_code="invalid_request")
                    extra += ["--types-scope", str(rest[j + 1])]
                    j += 2
                elif tok.startswith("--scope=") or tok.startswith("--types-scope="):
                    extra += ["--types-scope=" + tok.split("=", 1)[1]]
                    j += 1
                elif tok in ("--id", "--types-id"):
                    if j + 1 >= len(rest):
                        _err("%s 缺少取值" % tok, 400, err_code="invalid_request")
                    extra += ["--types-id", str(rest[j + 1])]
                    j += 2
                elif tok.startswith("--id=") or tok.startswith("--types-id="):
                    extra += ["--types-id=" + tok.split("=", 1)[1]]
                    j += 1
                else:
                    _err("doctypes last 不支持参数：%s" % tok, 400,
                         err_code="invalid_request")
            return prefix + ["doc", "--types-last"] + extra
        _err("未知 doctypes 操作：%s（支持 list/last）" % action, 400,
             err_code="invalid_request")

    if name == "me":
        # 只接受 --permissions（无位置参数）；其他参数交给 argparse 按非法参数处理。
        for tok in rest:
            if str(tok) not in ("--permissions",):
                if str(tok).startswith("-"):
                    continue
                _err("me 不接受位置参数：%s（仅 --permissions）" % tok, 400,
                     err_code="invalid_request")
        return prefix + ["user", "me"] + [str(x) for x in rest]

    if name == "feedback":
        action = str(rest[0]) if rest and not str(rest[0]).startswith("-") else ""
        if not action:
            print(_L170_PRODUCT_USAGE)
            sys.exit(0)
        if action not in ("list", "mine", "settle"):
            _err("未知 feedback 操作：%s（支持 list/mine/settle）" % action, 400,
                 err_code="invalid_request")
        if action == "settle":
            out = []
            j = 1
            while j < len(rest):
                tok = str(rest[j])
                if tok in ("--id", "--feedback-id"):
                    if j + 1 >= len(rest):
                        _err("%s 缺少取值" % tok, 400, err_code="invalid_request")
                    out += ["--feedback-id", str(rest[j + 1])]
                    j += 2
                elif tok.startswith("--id=") or tok.startswith("--feedback-id="):
                    out += ["--feedback-id=" + tok.split("=", 1)[1]]
                    j += 1
                elif tok in ("--action", "--feedback-action"):
                    if j + 1 >= len(rest):
                        _err("%s 缺少取值" % tok, 400, err_code="invalid_request")
                    out += ["--feedback-action", str(rest[j + 1])]
                    j += 2
                elif tok.startswith("--action=") or tok.startswith("--feedback-action="):
                    out += ["--feedback-action=" + tok.split("=", 1)[1]]
                    j += 1
                else:
                    out.append(tok)
                    j += 1
            return prefix + ["evolution", "feedback-settle"] + out
        return prefix + ["evolution", "feedback-" + action] + [str(x) for x in rest[1:]]

    if name == "alerts":
        if rest:
            _err("alerts 不接受参数：%s" % " ".join(str(x) for x in rest), 400,
                 err_code="invalid_request")
        return prefix + ["notifications", "alerts"]

    if name in ("capabilities", "dashboard"):
        if rest:
            _err("%s 不接受参数：%s" % (name, " ".join(str(x) for x in rest)), 400,
                 err_code="invalid_request")
        return prefix + ["version", "--" + name]

    return argv


def cmd_manifest(args, db):
    if getattr(args, "snapshot_replay", False) and getattr(args, "cleanup", False):
        # L98 P1：`rp snapshot replay --cleanup [--apply]` 清理 replay 派生 run/工件
        return _cmd_snapshot_cleanup(args, db)
    if getattr(args, "snapshot_replay", False):
        # L61：`rp snapshot replay --run/--snapshot`（历史快照重放；见 main() argv 归一）
        return _cmd_snapshot_replay(args, db)
    if getattr(args, "snapshot_show", False):
        # L53：`rp snapshot show --case/--run` 的实体实现（见 main() 的 argv 归一）。
        # 走 manifest 命令的只读权限口径：同租户/空间判权；系统管理员/平台身份边界保持一致。
        return _cmd_snapshot_show(args, db)
    from app.services import manifest
    _case_allowed(args, db, args.case)
    _runs = __import__("app.repositories", fromlist=["audit_runs"]).audit_runs.list(
        "case_id=?", (args.case,), order="created_at DESC", limit=1)
    _mid = (_runs[0].get("manifest_id") if _runs else "") or ""
    if not _mid:
        _r = manifest.freeze(args.case)
        if not _r.get("ok"):
            _err(_r.get("error") or "生成审核清单失败", 400, err_code="bad_request")
        _mid = _r["manifest_id"]
    from app import db
    c = db.connect()
    row = c.execute("SELECT * FROM audit_manifest WHERE id=?", (_mid,)).fetchone()
    c.close()
    if not row:
        _err("审核清单不存在", 404, err_code="not_found")
    out = dict(row)
    for k in ("objects_json", "rules_json", "items_json"):
        try: out[k] = json.loads(out.get(k) or "[]")
        except Exception: out[k] = []
    if getattr(args, "execute", False):
        # L52 ③：清单执行入口与 HTTP 同口径（响应 mode 标注）：
        #   已有执行结果 → 只读重放（幂等，不写 active/finding）；
        #   首次执行 → manifest.execute + project.materialize_manifest_run 完整物化。
        from app.services import manifest_exec
        _actor = str(getattr(args, "user", "") or "cli")
        try:
            from app.services import single_entry as _se
            _se_on = _se.enabled()
        except Exception:  # noqa: BLE001
            _se_on = False
        if _se_on:
            _ro = manifest.replay_readonly(_mid, actor=_actor)
            if _ro.get("executed"):
                _dump(_ro)
                return
            _res = manifest.execute(_mid, actor=_actor)
            if isinstance(_res, dict) and _res.get("ok") is not False:
                from app.services import project as _pj
                _mat = _pj.materialize_manifest_run(
                    args.case, _mid, _res, actor=_actor, entry="cli:manifest --execute")
                _res = {**_res, **_mat, "manifest_only_entry": True}
            _dump(_res)
        else:
            _dump(manifest_exec.run(_mid))
    else:
        _dump(out)


def cmd_ledger(args, db):
    """对象级审核台账（旧，--case/--batch）与 T-50 抑制台账 list/recover（新）。

    - 未给 action（`rp ledger --case X`）：保持旧契约（pstates.ledger 对象级台账）；
    - `rp ledger list`：抑制台账（抑制≠删除）→ app.services.human_review.ledger_list；
    - `rp ledger recover --ledger sl_xxx --reason ...`：人工恢复（写审计 + 写回 finding）。
    旧入口行为不变（full_chain/历史脚本不回归）。
    """
    from app.services import pstates
    action = str(getattr(args, "action", "") or "")
    if action in ("list", "recover"):
        from app.services import human_review as _hr_l
        uid, user = _bind_business_scope(args, db)
        role = str((user or {}).get("role") or "")
        if args.case:
            _bind_case_scope(_case_allowed(args, db, args.case))
        if action == "list":
            return _svc_out(_hr_l.ledger_list(
                actor=uid, role=role, case_id=args.case or "",
                status=args.status or "", source=args.source or "",
                limit=args.limit, offset=args.offset))
        if not args.ledger:
            _err("需要 --ledger（抑制台账 id，如 sl_xxx）", 400,
                 err_code="invalid_request")
        if not str(args.reason or "").strip():
            _err("恢复必须填写 --reason（人工动作需审计）", 400,
                 err_code="reason_required")
        return _svc_out(_hr_l.ledger_recover(
            ledger_id=args.ledger, actor=uid, role=role,
            reason=args.reason or ""))
    if not args.case:
        _err("需要 --case", 400, err_code="invalid_request")
    _case_allowed(args, db, args.case)
    if args.batch:
        from app.api.server import resolve_secondary
        _, user = _cli_actor(args, db)
        for _bid in [x.strip() for x in str(args.batch).split(",") if x.strip()]:
            _obj, deny = resolve_secondary("batch", _bid, user)
            if deny:
                _err_deny(deny)
            if _obj.get("case_id") != args.case:
                _err("批次不存在", 404, err_code="not_found")
    _dump(pstates.ledger(args.batch, case_id=args.case))


def cmd_adjudication_ledger(args, db):
    """裁决来源台账（L80 / P0-C，89 号 §6.1）：stats/export；与 HTTP 同服务层/权限/审计。

    输入：--case <项目> 与/或 --run <批次>（stats 至少给一个；export 还需 --out）。
    开关：RULEPROOF_ADJUDICATION_LEDGER 默认 0；=0 显式失败（ledger_disabled，退出码 6），
    不做“空成功”误导调用方。权限：仅审核员/业务管理员（HTTP 同口径 403）。
    """
    from app.services import adjudication_ledger as _adj
    action = str(getattr(args, "action", "") or "")
    if action not in ("stats", "export"):
        _err("需要子命令 stats|export", 400, err_code="invalid_request")
    _uid, _user = _bind_business_scope(args, db)
    case_id = str(getattr(args, "case", "") or "")
    run_id = str(getattr(args, "run", "") or "")
    if not case_id and run_id:
        try:
            with db.session() as _c_cli:
                _row = _c_cli.execute("SELECT case_id FROM audit_run WHERE id=?",
                                      (run_id,)).fetchone()
            case_id = str((_row["case_id"] if _row else "") or "")
        except Exception as _e:  # 铁律 2：读取失败显式失败，不静默空成功
            _err(f"读取审核批次失败：{type(_e).__name__}: {_e}", 1,
                 err_code="run_lookup_failed")
        if not case_id:
            _err("审核批次不存在", 404, err_code="not_found")
    if case_id:
        _bind_case_scope(_case_allowed(args, db, case_id))
    try:
        _sw = _adj.validate_switches()
    except ValueError as _e:
        _err(str(_e), 6, err_code="invalid_switch_combo", status=409)
    if not _sw.get("ledger"):
        _err("裁决来源台账未启用（RULEPROOF_ADJUDICATION_LEDGER=0）",
             6, err_code="ledger_disabled", status=409)
    if action == "stats":
        if not case_id and not run_id:
            _err("需要 --case 或 --run", 400, err_code="invalid_request")
        out = _adj.ledger_stats(case_id=case_id, run_id=run_id,
                                group_by=str(getattr(args, "group_by", "") or ""))
        if not out.get("ok"):
            _err(out.get("error") or "统计不可用",
                 int(out.get("status") or 1) if isinstance(out.get("status"), int) else 1,
                 err_code=out.get("code") or "stats_unavailable")
        _dump(out)
    # export：CSV/JSON + stats + SHA256SUMS；写 report.exported 审计（服务层）
    out_dir = str(getattr(args, "out", "") or "")
    if not out_dir:
        _err("export 需要 --out <目录>", 400, err_code="invalid_request")
    fmt = str(getattr(args, "format", "") or "csv").lower()
    if fmt not in ("csv", "json"):
        _err("--format 只支持 csv|json", 400, err_code="invalid_request")
    out = _adj.export(case_id=case_id, run_id=run_id, out_dir=out_dir,
                      fmt=fmt, actor=_uid)
    if not out.get("ok"):
        _err(out.get("error") or "导出失败",
             int(out.get("status") or 1) if isinstance(out.get("status"), int) else 1,
             err_code=out.get("code") or "export_failed")
    _dump(out)


def _report_service_error(_e):
    """CLI：报告服务层异常 → stderr JSON + 分类退出码（错误码与 HTTP 同源）。

    - 越权（ReportPermissionError）：status 403/401，退出码 4（CLI 分类）；
    - 门禁/状态机/防篡改/0 报告行（ReportGateError 或 ValueError）：业务拒绝，
      退出码 3（与既有 `rp report` 门禁语义一致），stderr JSON.status=409。
    """
    from app.services import report as _rep
    status = int(getattr(_e, "status", 0) or 0)
    code = str(getattr(_e, "code", "") or "")
    if isinstance(_e, _rep.ReportPermissionError):
        _err(str(_e), status or 403, err_code=code or "forbidden",
             status=status or 403)
    _err(str(_e), 3, err_code=code or "report_blocked", status=status or 409)


def _report_entry_target(args, db):
    """L94：解析 `rp report sign|export --id <report_id>` 的目标（report 行 + 所属 case）。

    - report id 命中 → 返回该行与所属 case（`_case_allowed` 判跨租户 404 / 他人 403）；
    - report id 未命中但 case id 命中 → 返回 (None, case_id, case) 走服务层
      `report_not_generated`（0 报告行可机读，不笼统报 404）；
    - 两者都不存在 → 404。
    """
    from app import repositories as _R
    rid = str(getattr(args, "report_id", "") or "").strip()
    if not rid:
        _err("缺少 --id <report_id>", 2, err_code="invalid_request", status=400)
    row = _R.reports.get(rid)
    if row:
        case_id = str(row.get("case_id") or "")
        case_row = _case_allowed(args, db, case_id)
        return row, case_id, case_row
    case_row = _case_allowed(args, db, rid)
    return None, rid, case_row


def _cmd_report_sign(args, db):
    """L94：`rp report sign --id <report_id> [--content-hash H] [--note T]`。

    与 HTTP POST /api/v1/reports/{id}/sign 同一服务层（report.sign_report）：
    审核员本人项目；门禁通过；已有生成报告行；hash 未变；重复签发幂等；
    写 report.signed 审计（服务层同事务）。
    """
    from app.services import report
    uid, _user = _cli_actor(args, db)
    role = str(_user.get("role") or "")
    if role != "reviewer":
        _err("报告签发仅审核员可执行", 403, err_code="forbidden")
    _need(uid, "report.view")
    _need(uid, "report.export")
    row, case_id, case_row = _report_entry_target(args, db)
    _bind_case_scope(case_row)
    expected = str(getattr(args, "content_hash", "") or "").strip()
    if row is not None and expected:
        actual = str(row.get("content_hash") or "")
        if not actual or actual != expected:
            _err("content_hash 与当前报告行不一致（可能不是最新版本或内容被篡改），拒绝签发",
                 3, err_code="content_hash_mismatch", status=409)
    try:
        out = report.sign_report(case_id, actor=uid, role=role,
                                 note=str(getattr(args, "note", "") or ""),
                                 report_id=str((row or {}).get("id") or ""))
    except Exception as _e:  # noqa: BLE001 —— 统一映射（权限 4 / 业务拒绝 3）
        _report_service_error(_e)
    out = dict(out or {})
    out.update({"ok": True, "action": "sign", "case_id": case_id,
                "report_id": out.get("report_id") or str((row or {}).get("id") or "")})
    _dump(out)


def _cmd_report_export(args, db):
    """L94：`rp report export --id <report_id> --format html|docx --out <文件>`。

    只导出已签发报告（未签发 → report_not_signed；0 报告行 → report_not_generated；
    hash 被篡改 → content_hash_mismatch），内容由服务层 `report.export_report`
    渲染并写导出回执 + `report.exported` 审计（与 HTTP POST .../export 同源）。
    """
    from app.services import report
    uid, _user = _cli_actor(args, db)
    role = str(_user.get("role") or "")
    if role != "reviewer":
        _err("报告导出仅审核员可执行", 403, err_code="forbidden")
    _need(uid, "report.view")
    _need(uid, "report.export")
    fmt = str(getattr(args, "format", "") or "html").strip().lower()
    if fmt == "pdf":
        _err("PDF 报告导出已移除；请导出 DOCX 或 HTML", 2,
             err_code="pdf_export_removed", status=403)
    if fmt not in ("html", "docx"):
        _err("report export --format 只支持 html|docx", 2,
             err_code="invalid_request", status=400)
    out_path = str(getattr(args, "out", "") or "").strip()
    if not out_path:
        _err("report export 需要 --out <文件路径>", 2,
             err_code="invalid_request", status=400)
    row, case_id, case_row = _report_entry_target(args, db)
    _bind_case_scope(case_row)
    if row is None:
        _err("尚未生成报告，不能导出：请先完成报告生成", 3,
             err_code="report_not_generated", status=409)
    if not (str(row.get("signed_by") or "").strip()
            and str(row.get("signed_at") or "").strip()):
        _err("报告尚未签发，不能导出：请先执行 rp report sign --id <report_id>", 3,
             err_code="report_not_signed", status=409)
    if report.verify_content_hash(row) is False:
        _err("报告内容与生成时的 content_hash 不一致（可能被篡改），拒绝导出", 3,
             err_code="content_hash_mismatch", status=409)
    try:
        # L94：目标行必须属于本 case 且为当前最新报告行（历史版本导出会造成单据歧义）
        report._target_report_row(case_id, str(row.get("id") or ""))
    except Exception as _e:  # noqa: BLE001
        _report_service_error(_e)
    try:
        content = report.export_report(case_id, fmt, actor=uid, role=role,
                                       report_id=str(row.get("id") or ""))
    except Exception as _e:  # noqa: BLE001
        _report_service_error(_e)
    raw = bytes(content) if isinstance(content, (bytes, bytearray)) \
        else str(content).encode("utf-8")
    _out_dir = os.path.dirname(os.path.abspath(out_path))
    if _out_dir:
        os.makedirs(_out_dir, exist_ok=True)
    with open(out_path, "wb") as fh:
        fh.write(raw)
    from app import repositories as _R
    latest = (_R.reports.list("case_id=?", (case_id,),
                              order="exported_at DESC") or [{}])[0]
    _dump({"ok": True, "action": "export", "case_id": case_id,
           "report_id": latest.get("id") or row.get("id") or "",
           "format": fmt, "out": out_path, "bytes": len(raw),
           "content_hash": str(row.get("content_hash") or ""),
           "exported_hash": str(latest.get("exported_hash") or ""),
           "exported_at": str(latest.get("exported_at") or ""),
           "status": str(latest.get("status") or "")})


def cmd_report(args, db):
    """报告查看/导出：与 HTTP 同一角色、同一访问检查、同一门禁（F-23 P0）。

    修复前 CLI 只做 `_case_allowed`（租户/归属），直接调用 report.build_report_*，
    并用不带 access 的 check_gate（access=None → can_export 恒 True），业务管理员
    在 HTTP 403 后可用 CLI 成功导出 HTML/DOCX，并在门禁前写入 unknown.accepted 审计。
    现口径：

    - 角色：仅审核员（与 HTTP GET /reviews/{cid}/report.*、POST /reviews/{cid}/report
      同口径；admin/super_admin/platform_op → 403）；
    - 案例级访问：走报告服务严格导出门禁 `_strict_export_access`（跨租户 404、
      他人项目 403），CLI 参数不能绕过；
    - accept-parse-gaps / accept-unknown 是复核侧写操作：必须角色/案例门禁通过后
      才写；业务管理员带 --accept-* 也不能落审计；
    - accept-unknown（T-35）：V08 起例外授权只能按对象，`--accept-unknown` 必须配合
      `--result-id`（`--result-hash/--run-id/--reason`）；无 `--result-id` 时**列出
      对象级候选并拒绝批量**（退出码 400，不写审计）。批量旧 point_ids 审计不再产生。
      关键项需两名不同授权人，CLI 单人授权会 `pending`，报告门禁仍以退出码 3 阻断；
      第二人可用 `rp exception accept`（业务管理员可作第二授权人）或 HTTP/UI 完成。
    - 正式报告（html/docx）经 `report.generate` 记录报告（可追溯），门禁未过退出码 3；
    - CSV 保持原契约：默认过门禁，`--allow-ungated-csv` 显式例外（仅 CSV）。
    - L94：新增 `rp report sign --id` / `rp report export --id`（同一服务层
      `report.sign_report` / `report.export_report`，见 `_cmd_report_sign/export`）。
    """
    # L94：`rp report sign|export`（main() 的 _report_argv 已归一为隐藏动作开关）
    if getattr(args, "report_sign", False):
        return _cmd_report_sign(args, db)
    if getattr(args, "report_export", False):
        return _cmd_report_export(args, db)
    from app.services import report, export
    from app import repositories as R
    from app.services import project as _pj
    if not str(getattr(args, "case", "") or "").strip():
        _err("缺少项目 ID：rp report <case> [--format html|docx|csv]；"
             "签发/按报告导出请用 rp report sign|export --id <report_id>",
             2, err_code="invalid_request", status=400)
    uid, _user = _cli_actor(args, db)
    role = str(_user.get("role") or "")
    fmt = str(args.format or "").strip().lower()
    # 1) 角色门禁：与 HTTP GET 报告同一文案/状态码（CLI 不能成为导出后门）
    if role != "reviewer":
        _err("报告导出仅审核员可执行", 403, err_code="forbidden")
    # 1.1) T-199：报告权限点接线（事件源=单一注册表；reviewer 持有 view+export）
    _need(uid, "report.view")
    _need(uid, "report.export")
    # 2) 案例范围：CLI --tenant/--ws 不能越过账号自身租户；不存在 404、无权 403
    _case_row = _case_allowed(args, db, args.case)
    # 2.1) 绑定案例真实租户/空间：对象级例外授权审计带 workspace_id，读取方
    #      （report_gate/report.check_gate）按上下文过滤，跨入口必须同源。
    _bind_case_scope(_case_row)
    # 3) 报告服务严格访问检查：与 HTTP POST /reviews/{cid}/report 同源
    try:
        report._strict_export_access(args.case, actor=uid, role=role)
    except report.ReportPermissionError as _e:
        _err(str(_e), int(getattr(_e, "status", 403) or 403),
             err_code=getattr(_e, "code", "forbidden") or "forbidden")
    if fmt not in ("html", "docx", "csv"):
        _err("PDF 报告导出已移除；format 支持 html/docx/csv", 2)
    # 4) 复核侧接受记录：必须通过角色/案例门禁后才允许写审计
    if getattr(args, "accept_parse_gaps", False):
        _case = R.cases.get(args.case) or {}
        for _d in _pj.documents(args.case):
            if ( _d.get("parse_status") or "ok") not in ("partial", "failed"):
                continue
            if str(_d.get("parse_summary") or "").startswith("[缺口已接受]"):
                continue
            R.documents.update(_d["id"], parse_summary="[缺口已接受] CLI 接受 ｜ " + str(_d.get("parse_summary") or ""))
            R.audit_logs.log(actor=uid, action="parse_gap.accepted", object=args.case,
                             after=__import__("json").dumps({"document_id": _d["id"], "reason": "CLI 显式接受"}, ensure_ascii=False))
    if getattr(args, "accept_unknown", False):
        # T-35：对象级例外授权（逐项）。旧实现一次写 point_ids 批量审计，V08 之后
        # 不再作为放行依据，造成“CLI 接受成功但仍被门禁阻断”。现口径：
        #   - 必须 --result-id（+ 可选 --result-hash/--run-id/--reason）；
        #   - 未给 --result-id：列出 collect_unknown 的对象级候选并拒绝批量（不写审计）；
        #   - 逐对象调用 HTTP 同一实现（app/api/exception_routes.post_accept）。
        from app.api import exception_routes as _exc
        _rid = str(getattr(args, "result_id", "") or "").strip()
        if not _rid:
            _cand = _exc.candidates_payload(args.case)
            _err_text = ("禁止批量豁免：请用 --result-id 逐项接受（先看 candidates）；"
                         "本次未写任何审计")
            _cand.update({"ok": False, "code": "result_id_required",
                          "status": 400, "error": _err_text})
            print(json.dumps(_cand, ensure_ascii=False, indent=1))
            # 批量/缺 result_id 是 CLI 用法错误：退出码 2（JSON status 仍对齐 HTTP 400）。
            _err(_err_text, 2, err_code="result_id_required", status=400)
        _body = {"result_id": _rid,
                 "result_hash": str(getattr(args, "result_hash", "") or ""),
                 "run_id": str(getattr(args, "run_id", "") or ""),
                 "reason": str(getattr(args, "reason", "") or "CLI 对象级例外接受")}
        _status, _out = _exc.post_accept(args.case, _body, _user)
        if _status != 200:
            _err_deny((_status, _out))
        if not _out.get("accepted"):
            # 关键项第一次授权（或已授权但还差第二人）：记录已写，但报告门禁不会放行；
            # 明确提示，避免再次出现“接受成功但报告仍阻断”的误解。
            print(json.dumps({"ok": True, "accepted": [], "pending": _out.get("pending") or [],
                              "requires_second": True,
                              "note": "关键项双人授权：已记录 1 人，还需另一名不同操作人授权"},
                             ensure_ascii=False), file=sys.stderr)
    if fmt in ("html", "docx"):
        # 5) 正式报告：走 report.generate（含访问 + 门禁 + 报告记录/审计），
        #    与 HTTP POST /reviews/{cid}/report 同一服务入口。
        try:
            _gen = report.generate(args.case, actor=uid, role=role)
        except report.ReportPermissionError as _e:
            _err(str(_e), int(getattr(_e, "status", 403) or 403),
                 err_code=getattr(_e, "code", "forbidden") or "forbidden")
        except report.ReportGateError as _e:
            # L77：携带门禁机读错误码（audit_write_failed 等）；未触发时仍为 report_blocked。
            # 退出码保持 3（报告门禁语义，既有 CLI 契约），错误码在 stderr JSON。
            _err("报告未通过门禁：" + (str(_e) or "未满足放行条件"), 3,
                 err_code=getattr(_e, "code", "") or "report_blocked")
        # L94：正式报告导出强制走服务层严格入口（职责分离 + 门禁 + L87 审计状态 +
        # 导出回执/`report.exported` 审计一次写全），不再在 CLI 直出 build_report_*。
        try:
            rep = report.export_report(args.case, fmt, actor=uid, role=role)
        except Exception as _e:  # noqa: BLE001 —— 权限/门禁错误码与 HTTP 同源
            _report_service_error(_e)
        _report_meta = {"report_id": _gen.get("id"), "report_version": _gen.get("version"),
                        "content_hash": _gen.get("content_hash") or ""}
    else:
        if not getattr(args, "allow_ungated_csv", False):
            _gate = report.check_gate(args.case)
            if not _gate.get("ok"):
                _err("报告未通过门禁：" + "；".join(_gate.get("reasons") or ["未满足放行条件"]), 3)
        rep = export.findings_csv(args.case)
        _report_meta = {}
    if args.out:
        mode = "wb" if isinstance(rep, bytes) else "w"
        with open(args.out, mode, **({} if mode == "wb" else {"encoding": "utf-8"})) as fh:
            fh.write(rep)
        _dump({"ok": True, "out": args.out, "bytes": os.path.getsize(args.out), **_report_meta})
    if isinstance(rep, bytes):
        _err("二进制报告需要 --out 路径", 2)
    print(rep)

def cmd_exception(args, db):
    """对象级例外授权 CLI（T-35）：与 HTTP /projects/{cid}/unknown-candidates 同源。

    - `exception list --case CID`：列出当前 run 的对象级 unknown 候选
      （result_id/result_hash/run_id/key_item/required_actors/waivable/accepted）
      与报告门禁状态；禁止批量，只读；
    - `exception accept --case CID --result-id ID [--result-hash H] [--run-id R]
      --reason TEXT`：逐对象接受一次。批量形状（list/逗号串）由共用实现固定
      400 batch_forbidden；hash/run 变化 409；execution_failed 409 non_waivable；
      跨租户/他人项目 403/404；
    - 角色：reviewer（项目负责人）/ admin（关键项第二授权人；页面不展示入口）。
      关键项需两名不同 actor，单人调用返回 pending（JSON requires_second=true），
      报告门禁仍阻断；第二人再次 accept 同一 result_id 后生效。
    """
    from app.api import exception_routes as _exc
    uid, user = _cli_actor(args, db)
    role = str(user.get("role") or "")
    if role not in _exc.ACCEPT_ROLES:
        _err("无例外授权权限", 403, err_code="forbidden")
    _case_row = _case_allowed(args, db, args.case)
    _bind_case_scope(_case_row)
    action = str(args.action or "").strip().lower()
    if action == "list":
        _dump(_exc.candidates_payload(args.case))
    if action != "accept":
        _err("未知操作：" + action, 2)
    if not str(args.result_id or "").strip():
        _err("必须提供 --result-id（一次只接受一个对象，禁止批量）", 2,
             err_code="result_id_required", status=400)
    _status, _out = _exc.post_accept(args.case, {
        "result_id": str(args.result_id or ""),
        "result_hash": str(args.result_hash or ""),
        "run_id": str(args.run_id or ""),
        "reason": str(args.reason or ""),
    }, user)
    if _status != 200:
        _err_deny((_status, _out))
    _dump(_out)


def cmd_export(args, db):
    """数据导出：与 HTTP /api/v1/export/* 同一实现、同一权限、同一 403/404。"""
    from app.api.server import (build_projects_csv, build_findings_csv,
                                build_audit_records_csv)
    _, user = _cli_actor(args, db)
    _set_scope(args)
    kind = str(args.kind or "").strip()
    if kind == "projects":
        data, deny = build_projects_csv(user)
    elif kind == "findings":
        data, deny = build_findings_csv(user, args.case or "")
    elif kind == "audit-records":
        data, deny = build_audit_records_csv(user, args.date_from or "",
                                             args.date_to or "", args.reviewer or "")
    elif kind == "audit-logs":
        data, deny = None, (403, {"error": "审计日志只读，不提供导出", "code": "forbidden"})
    else:
        data, deny = None, (400, {"error": "未知导出类型", "code": "invalid_request"})
    if deny:
        _err_deny(deny)
    if args.out:
        with open(args.out, "wb") as fh:
            fh.write(data)
        _dump({"ok": True, "kind": kind, "out": args.out, "bytes": os.path.getsize(args.out)})
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()
    sys.exit(0)


def cmd_open(args, db):
    """开放平台：与 HTTP 同一作用域/同一对象解析/同一角色门禁。

    HTTP 只允许系统管理员访问开放平台（业务管理员/审核员/平台运营 403）；
    CLI 的 --user 是显式身份，因此必须给出同样的 403，而不是“本机就是管理员”。
    """
    from app.services import open as OP
    _uid, user = _cli_actor(args, db)
    if user.get("role") != "super_admin":
        _err("无权限：仅系统管理员可访问开放平台", 403, err_code="forbidden")
    _set_scope(args)
    tenant, ws = args.tenant or "t-default", args.ws or ""
    from app.api.server import open_app_scope, open_task_detail_scoped, _open_callback_ok
    aid = str(args.id or "").strip()
    if args.action == "apps":
        _dump({"ok": True, "items": OP.list_apps()})
    if args.action == "create":
        cb = args.callback or ""
        if args.sandbox and not cb:
            cb = "http://127.0.0.1:8093/api/v1/open/sandbox"
        if cb:
            _okc, _whyc = _open_callback_ok(cb)
            if not _okc:
                _err("callback_url 不被允许：" + _whyc, 400, err_code="invalid_url")
        # DU-15：审计 actor = CLI --user 身份（与 HTTP 会话 actor 同源）。
        _dump({"ok": True, "app": OP.create_app(args.name, cb, args.events or "audit.completed",
                                                actor=_uid)})
    if args.action == "test":
        if not aid:
            _err("缺少 --id", 400, err_code="invalid_request")
        _app, deny = open_app_scope(aid, user, tenant, ws)
        if deny:
            _err_deny(deny)
        _dump({"ok": True, **OP.send_test_event(aid)})
    if args.action == "events":
        _dump({"ok": True, "items": OP.list_events()})
    if args.action == "deliver":
        _dump({"ok": True, **OP.deliver_pending()})
    if args.action == "sandbox":
        _dump({"ok": True, "items": OP.list_sandbox()})
    if args.action == "update":
        if not aid:
            _err("缺少 --id", 400, err_code="invalid_request")
        _app, deny = open_app_scope(aid, user, tenant, ws)
        if deny:
            _err_deny(deny)
        cb = str(args.callback or "")
        if cb:
            _okc, _whyc = _open_callback_ok(cb)
            if not _okc:
                _err("callback_url 不被允许：" + _whyc, 400, err_code="invalid_url")
        _dump({"ok": True, **OP.update_app(aid, args.name or "", cb,
                                          args.events or "", args.status or "")})
    if args.action == "rotate":
        if not aid:
            _err("缺少 --id", 400, err_code="invalid_request")
        _app, deny = open_app_scope(aid, user, tenant, ws)
        if deny:
            _err_deny(deny)
        _dump({"ok": True, **OP.rotate_secret(aid)})
    if args.action == "task":
        if not aid:
            _err("缺少 --id", 400, err_code="invalid_request")
        detail, deny = open_task_detail_scoped(aid, tenant, ws, strict_workspace=True)
        if deny:
            _err_deny(deny)
        _dump({"ok": True, **detail})
    _err("未知开放平台操作", 400, err_code="bad_request")


def cmd_model(args, db):
    from app.services import model
    uid = _user_id(args, db)
    if args.action == "list":
        _need(uid, "model.view")
        _dump({"ok": True, **model.list_models()})
    # ---- L91：补齐 HTTP /api/v1/model(s) 已有只读/受控动作 ----
    if args.action == "config":
        _need(uid, "model.view")
        _dump({"ok": True, **model.config_info()})
    if args.action == "points":
        _need(uid, "model.view")
        _dump({"ok": True, "items": model.points()})
    if args.action == "effective":
        _need(uid, "model.view")
        _dump({"ok": True, **model.effective()})
    if args.action == "test":
        _need(uid, "model.manage")
        mid = str(getattr(args, "id", "") or "").strip()
        if mid:
            _dump({"ok": True, **model.test_model(mid)})
        _dump({"ok": True, **model.test_connection()})
    if args.action == "set":
        _need(uid, "model.manage")
        # 节点穷举测试 P3：缺 --id 过去落到服务层抛 Exception("模型不存在")，
        # 被 main 的兜底转成 exit=1 + "Exception: ..."；参数错误应统一 400。
        mid = str(getattr(args, "id", "") or "").strip()
        if not mid:
            _err("缺少 --id（模型 ID）", 2, err_code="invalid_request", status=400)
        try:
            result = model.update_model(mid, is_default=bool(args.default))
        except Exception as e:  # 服务层对不存在的模型只抛通用 Exception
            if "模型不存在" in str(e):
                _err(f"模型不存在：{mid}", 404, err_code="not_found", status=404)
            raise
        _dump({"ok": True, "result": result})


def cmd_user(args, db):
    from app.services import account
    uid = _user_id(args, db)
    # L170：本人身份/权限自查（HTTP GET /api/v1/me、/api/v1/me/permissions）。
    # 一等入口 `rp me [--permissions]`（main() 归一为 `rp user me`）。
    # 未登录态在 CLI 不存在（--user 一定有身份），因此与 HTTP 已登录分支同口径。
    if args.action == "me":
        from app import repositories as _R
        from app.services import permission as _perm
        _uid, _user = _cli_actor(args, db)
        _row = _R.users.get(_uid) or {}
        _role = str((_user or {}).get("role") or "reviewer")
        _roles = list((_user or {}).get("roles") or [])
        _portal = (_row.get("portal")
                   or account.portal_of_role(_role) or "")
        # 与 HTTP GET /api/v1/me 已登录分支同一字段口径（不含会话 token/过期时间）。
        _me = {"sub": _uid,
               "name": _row.get("name") or (_user or {}).get("name", ""),
               "username": _row.get("username") or "",
               "phone": _row.get("phone") or "",
               "email": _row.get("email") or "",
               "created_at": _row.get("created_at") or "",
               "onboarded_at": _row.get("onboarded_at") or "",
               "must_change_pwd": bool(_row.get("must_change_pwd")),
               "portal": _portal,
               "role": _role,
               "roles": _roles}
        out = {"ok": True, "user": _me}
        if bool(getattr(args, "permissions", False)):
            # HTTP GET /api/v1/me/permissions 返回 permission.permissions(role) 原样视图。
            out["permissions"] = _perm.permissions(_role)
        _dump(out)
    if args.action == "list":
        # DU-01（P0，2026-11-25）：CLI 与 HTTP 同源鉴权——user.view 在权限注册表中
        # 仅授予 super_admin（HTTP GET /api/v1/users：非 super_admin 403）。
        # 修复前本分支不校验权限、不传 actor → 任意已知账号可 dump 全租户账号与
        # 明文 initial_password，属越权读+凭据泄露。
        _need(uid, "user.view")
        _actor_id, _actor = _cli_actor(args, db)
        if (_actor.get("role") or "") != "super_admin":
            _err("无权限：user.view", 403, err_code="forbidden")
        _rows = account.list_users(_actor.get("role") or "", _actor_id)
        # L163：分页/筛选（HTTP GET /api/v1/users?page&page_size&q&role&status 同一
        # 服务层 list_users_page、同一脱敏函数）。未传任何分页/筛选参数时保持旧的
        # 全量列表语义不变；分页参数的边界与 HTTP 一致（page≥1，page_size 5-100）。
        _page = int(getattr(args, "page", 0) or 0)
        _size = int(getattr(args, "page_size", 0) or 0)
        _q = str(getattr(args, "q", "") or "")
        _status = str(getattr(args, "status", "") or "")
        _role_f = str(getattr(args, "role", "") or "")
        _paged = bool(_page or _size or _q or _status
                      or (_role_f and args.action == "list"))
        if _paged:
            _data = account.list_users_page(
                _actor.get("role") or "", _actor_id, _q, _role_f, _status,
                _page or 1, _size or 20)
            _out = {"ok": True, "filters": {"q": _q, "role": _role_f, "status": _status},
                    **_data}
            _out = account.sanitize_users_payload(_out, _actor)
            _dump(_out)
        _dump({"ok": True, "items": account.sanitize_users_payload(_rows, _actor)})
    if args.action == "create":
        _need(uid, "user.manage")
        # 节点穷举测试 P3：缺手机号过去落到服务层抛 PermissionError("手机号不能为空")，
        # 被兜底转成 exit=1 + "PermissionError: ..."；参数错误统一 400 invalid_request。
        phone = str(args.phone or args.username or "").strip()
        if not phone:
            _err("缺少手机号：请用 --phone（11 位手机号）或 --username", 2,
                 err_code="invalid_request", status=400)
        if not (len(phone) == 11 and phone.isdigit()):
            _err(f"手机号必须为 11 位数字（当前：{phone}）", 2,
                 err_code="invalid_request", status=400)
        try:
            result = account.create_user(
                username=args.username, name=args.name, role=args.role or "reviewer",
                phone=phone, email=args.email or "")
        except PermissionError as e:
            msg = str(e) or "参数不合法"
            if any(k in msg for k in ("无开通账号权限", "当前身份只能开通",
                                      "只能在本租户开通")):
                _err(msg, 403, err_code="forbidden", status=403)
            _err(msg, 2, err_code="invalid_request", status=400)
        _dump({"ok": True, "result": result})
    if args.action == "reset-password":
        _need(uid, "user.manage")
        # DU-01：目标账号查找同样按 actor 租户过滤（旧实现 list_users() 默认全库）。
        _actor_id, _actor = _cli_actor(args, db)
        target = args.id or next(
            (x["id"] for x in account.list_users(_actor.get("role") or "", _actor_id)
             if x.get("phone") == args.phone or x.get("id") == args.phone), "")
        if not target:
            _err("账号不存在；请用 --id 或 --phone", 2)
        actor_role = "super_admin" if "super_admin" in set(account.roles_of(uid)) else "admin"
        _dump({"ok": True, **account.reset_password(target, args.password or "", actor=uid,
                                                      actor_role=actor_role)})
    if args.action == "change-password":
        # DU-09（P2，2026-11-25）：补 CLI 自助改密——与 HTTP POST /api/v1/me/password
        # 同一服务实现（account.change_own_password），复杂度走 password_policy 单一事实源。
        if not uid:
            _err("未登录：缺少 --user", 403, err_code="forbidden")
        old = str(getattr(args, "old_password", "") or "")
        new = str(getattr(args, "new_password", "") or "") or str(args.password or "")
        if not old or not new:
            _err("缺少 --old-password / --new-password", 2, err_code="invalid_request",
                 status=400)
        try:
            _r = account.change_own_password(uid, old, new)
        except ValueError as e:
            _msg = str(e)
            if _msg == "原密码错误":
                _err(_msg, 400, err_code="wrong_password", status=400)
            _err(_msg, 400, err_code="weak_password", status=400)
        _dump({"ok": True, **(_r or {})})


def cmd_gate(args, db):
    import subprocess
    r = subprocess.run([sys.executable, "scripts/qa/gate.py"], env=dict(os.environ, RULEPROOF_DB=str(db.DB_PATH)))
    _dump({"ok": r.returncode == 0, "exit": r.returncode}, 0 if r.returncode == 0 else 1)


def cmd_conflict_check(args, db):
    """冲突检测状态（T-164 / 评审 C-4）：run = 全量检测并落状态；status = 查看最近记录。

    老库升级后首次生成报告会被冲突检测门禁阻断（「无冲突」不可证），
    先执行一次 ``./rp conflict-check run`` 即可解除；之后每次规则发布会自动记录检测状态。
    """
    from app.services import conflict as _cf
    act = str(getattr(args, "action", "") or "run")
    _uid, _user = _cli_actor(args, db)
    _set_scope(args)
    if act == "status":
        _dump({"ok": True,
               "checks": _cf.list_checks(limit=int(getattr(args, "limit", 20) or 20)),
               "gate": _cf.report_gate_status(
                   tenant_id=getattr(args, "tenant", "") or "",
                   workspace_id=getattr(args, "ws", "") or ""),
               "switch": _cf.CONFLICT_CHECK_ENV})
    # run：检测并登记冲突（业务写，需要管理员；与 HTTP /api/v1/conflicts/detect 同源）
    from app.services import account as _account
    if str(_user.get("role") or "") == "platform_op":
        _err("无权限：平台身份不可访问业务接口", 403, err_code="forbidden")
    if not (set(_account.roles_of(_uid) or []) & {"admin", "super_admin"}):
        _err("无权限：冲突检测需要管理员", 403, err_code="forbidden")
    out = _cf.detect(persist=True, scope="full") or {}
    payload = {"scope": "full", "rules": int(out.get("rules") or 0),
               "conflict_count": len(out.get("conflicts") or []),
               "critical": int(out.get("critical") or 0)}
    try:
        from app.services import audit as _audit
        with db.session() as c:
            _audit.log_in_tx(c, _uid, "conflict.checked", "", "",
                             json.dumps(payload, ensure_ascii=False))
    except Exception as _exc:  # 审计写失败可见（不静默成功）
        _err(f"冲突检测已完成，但审计写入失败：{type(_exc).__name__}: {_exc}", 1,
             detail=payload, err_code="audit_failed")
    _dump({"ok": True, "checked": True, **payload,
           "gate": _cf.report_gate_status(
               tenant_id=getattr(args, "tenant", "") or "",
               workspace_id=getattr(args, "ws", "") or ""),
           "switch": _cf.CONFLICT_CHECK_ENV})


def cmd_db(args, db):
    """数据库备份/恢复/迁移：平台级 IT 动作，仅系统管理员（super_admin）。

    P1-05：业务管理员（admin）曾可按「管理员」放行导出整库（跨租户数据外带）、
    覆盖生产库或改数据结构；与 HTTP 无对应入口，CLI 不能成为越权后门。
    """
    uid = _user_id(args, db)
    from app.services import account
    if "super_admin" not in set(account.roles_of(uid) or []):
        _err("无权限：数据库备份/恢复/迁移仅系统管理员（super_admin）可执行",
             403, err_code="forbidden")
    from app.services import db_backup
    from app import data_migrations
    if args.action == "backup":
        out = args.out or "backup.db"
        _dump({"ok": True, **db_backup.backup(db.DB_PATH, out)})
    if args.action == "restore":
        if not args.source:
            _err("需要 --from 指定备份文件", 2)
        if not getattr(args, "yes", False):
            _err("恢复会覆盖当前数据库；确认后加 --yes", 2, err_code="confirmation_required")
        _dump({"ok": True, **db_backup.restore(
            db.DB_PATH, args.source, backup_dir=args.backup_dir or None)})
    if args.action == "migrate":
        _dump({"ok": True, **data_migrations.apply(
            db.DB_PATH, dry_run=bool(getattr(args, "dry_run", False)),
            backup_dir=args.backup_dir or None, actor=uid)})



def cmd_notifications(args, db):
    from app.services import notify
    uid = _user_id(args, db)
    # L170：主动告警（HTTP GET /api/v1/alerts，只读）。与消息中心不同：HTTP 该端点
    # 不要求 msg.view，任意已登录业务角色可读；平台运营身份在 _guard 里被拒绝。
    if args.action == "alerts":
        _uid_a, _user_a = _cli_actor(args, db)
        if str((_user_a or {}).get("role") or "") == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        _dump({"ok": True, "items": notify.alerts()})
    # T-199：消息中心查看权限点接线（旧 msg.view 死权限点）
    _need(uid, "msg.view")
    if args.action == "list":
        _dump({"ok": True, "items": notify.list_for(uid, unread_only=bool(args.unread), limit=args.limit)})
    if args.action == "read":
        if not args.id:
            _err("需要 --id", 2)
        try:
            _dump({"ok": True, **notify.mark_read(args.id, uid)})
        except Exception as e:
            _err(str(e), 1)
    if args.action == "read-all":
        _dump({"ok": True, **notify.mark_all_read(uid)})


def cmd_version(args, db):
    from app import config
    _want_cap = bool(getattr(args, "capabilities", False))
    _want_dash = bool(getattr(args, "dashboard", False))
    if _want_cap or _want_dash:
        # L170：`rp capabilities` / `rp dashboard` 归一入口（保持 49 顶层命令契约）。
        if _want_cap and _want_dash:
            _err("--capabilities 与 --dashboard 不能同时使用", 2,
                 err_code="invalid_argument", status=400)
        _uid_v, _user_v = _cli_actor(args, db)
        _role_v = str((_user_v or {}).get("role") or "")
        if _want_cap:
            # HTTP GET /api/v1/system/capabilities：任意已登录业务身份可读（reviewer/
            # admin/super_admin），平台运营身份由 _guard 拒绝。
            if _role_v == "platform_op":
                _err("平台身份不可访问业务接口", 403, err_code="forbidden")
            from app.engine import ocr as _ocr
            from app.services import calibration as _cal15
            try:
                _cal = _cal15.summary()
            except Exception:  # noqa: BLE001 - 与 HTTP 同口径：校准统计失败不阻断能力读取
                _cal = {}
            try:
                from app.services import project as _pj_cap
                _limits = {"max_files": int(_pj_cap.MAX_FILES),
                           "max_file_mb": int(_pj_cap.MAX_FILE_BYTES // 1024 // 1024),
                           "max_total_mb": int(_pj_cap.MAX_TOTAL_BYTES // 1024 // 1024)}
            except Exception:  # noqa: BLE001
                _limits = {}
            _dump({"ok": True, "ocr": _ocr.status(), "limits": _limits,
                   "calibration": {"samples": _cal.get("samples", 0)}})
        # HTTP GET /api/v1/dashboard：仅业务/系统管理员（_ADMIN_GET），审核员 403。
        if _role_v == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        if _role_v not in ("admin", "super_admin"):
            _err("无权限（需管理员）", 403, err_code="forbidden")
        from app.services import stats as _stats15
        from app.services import ctx as _ctx_dash15
        _tenant_dash15 = _l170_tenant_scope(args, db, _user_v)
        with _ctx_dash15.scoped(_tenant_dash15, str(getattr(args, "ws", "") or "")):
            _dash15 = _stats15.dashboard()
        _dump({"ok": True, "dashboard": _dash15})
    _dump({"ok": True, "version": config.APP_VERSION, "python": sys.version.split()[0], "db": str(db.DB_PATH)})


def _cli_parser_coverage() -> dict:
    """CLI 命令树覆盖率（L163 doctor 输出；只读静态自检，不执行任何业务命令）。

    统计口径与 docs/qa/build56_CLI全局完善_20261125.md 一致：
    - top_commands：argparse 顶层子命令数（防漂移契约：必须 = web/platform.js CLI_ALL）；
    - action_nodes：positional ``action`` 的 choices 总数（49 命令下的动作叶子）；
    - nodes：顶层命令 + 子解析器节点（当前无二级子解析器，故 nodes == top_commands）；
    - handlers_ok / help_ok：每个节点是否绑定 ``fn`` 且 ``--help`` 可渲染。
    """
    p = build_parser()
    subs = [a for a in p._actions if a.__class__.__name__ == "_SubParsersAction"]
    if not subs:
        return {"ok": False, "error": "解析器无子命令"}
    nodes = []
    action_nodes = 0
    top = sorted(subs[0].choices.items())

    def walk(path, sp):
        nonlocal action_nodes
        nodes.append((path, sp))
        for a in sp._actions:
            if a.__class__.__name__ == "_SubParsersAction":
                for n, child in a.choices.items():
                    walk(path + " " + n, child)
            elif a.dest == "action" and getattr(a, "choices", None):
                action_nodes += len(a.choices)

    for name, sp in top:
        walk(name, sp)
    handlers_ok = 0
    help_ok = 0
    help_fail = []
    for name, sp in nodes:
        try:
            sp.format_help()
            help_ok += 1
        except Exception:  # noqa: BLE001 - 渲染失败必须显式计数（不能静默）
            help_fail.append(name)
        try:
            fn = sp.get_default("fn")
        except Exception:  # noqa: BLE001
            fn = None
        if callable(fn):
            handlers_ok += 1
    root = _platform_root()
    manual = os.path.join(root, "docs", "CLI手册.md")
    matrix = os.path.join(root, "docs", "qa", "build56_CLI全局完善_20261125.md")
    # L170：剩余产品级能力（仅 HTTP 缺口收敛）交付说明；doctor 一并检查存在性。
    residual = os.path.join(root, "docs", "qa", "build56_CLI剩余能力_20261126.md")
    return {
        "ok": (handlers_ok == len(nodes) and help_ok == len(nodes)),
        "top_commands": len(top),
        "nodes": len(nodes),
        "action_nodes": action_nodes,
        "handlers_ok": handlers_ok,
        "help_ok": help_ok,
        "help_fail": help_fail,
        "aliases": {"extraction": ["verify", "confidence-policy"],
                    "report": ["sign", "export"],
                    "snapshot": ["show", "replay"],
                    # L170 产品级只读/低风险能力一等入口（均为既有命令的别名归一，
                    # 顶层命令数保持 49）
                    "doctypes": ["list", "last"],
                    "me": ["--permissions"],
                    "feedback": ["list", "mine", "settle"],
                    "alerts": [],
                    "capabilities": [],
                    "dashboard": []},
        "docs": {"manual": os.path.isfile(manual), "matrix_report": os.path.isfile(matrix),
                 "residual_report": os.path.isfile(residual)},
        "commands": [name for name, _ in top],
    }


def cmd_doctor(args, db):
    """CLI 自检：环境、数据库、权限种子、核心模块可读、CLI 覆盖率（L163）。"""
    checks = []
    checks.append({"name": "python", "ok": sys.version_info >= (3, 10), "detail": sys.version.split()[0]})
    try:
        from app.services import permissions, notify, project, rule, report
        checks.append({"name": "services", "ok": True, "detail": "导入成功"})
    except Exception as e:
        checks.append({"name": "services", "ok": False, "detail": f"{type(e).__name__}: {e}"})
    try:
        with db.session() as c:
            n = c.execute("SELECT count(*) FROM rule").fetchone()[0]
        checks.append({"name": "database", "ok": True, "detail": f"{db.DB_PATH} · {n} 条规则"})
    except Exception as e:
        checks.append({"name": "database", "ok": False, "detail": f"{type(e).__name__}: {e}"})
    # L163：CLI 覆盖率——顶层命令/动作节点/handler/--help 可解析 + 手册与矩阵报告存在。
    try:
        cov = _cli_parser_coverage()
        docs_ok = bool((cov.get("docs") or {}).get("manual"))
        checks.append({
            "name": "cli_coverage",
            "ok": bool(cov.get("ok")) and docs_ok,
            "detail": ("%d 顶层命令 · %d 动作节点 · handler %d/%d · --help %d/%d"
                       % (cov.get("top_commands"), cov.get("nodes"),
                          cov.get("handlers_ok"), cov.get("nodes"),
                          cov.get("help_ok"), cov.get("nodes"))
                      + (" · 手册缺失" if not docs_ok else "")),
        })
    except Exception as e:  # noqa: BLE001 - 覆盖率自检失败必须显式暴露
        cov = {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
        checks.append({"name": "cli_coverage", "ok": False,
                       "detail": cov["error"]})
    ok = all(x["ok"] for x in checks)
    _dump({"ok": ok, "cli": "rp", "checks": checks, "coverage": cov})


def cmd_tenant(args, db):
    from app.services import tenants
    uid = _user_id(args, db)
    # L170：公开品牌读取（HTTP GET /api/v1/public/tenant-branding，公开端点）。
    # 未配置/租户码不存在回退默认品牌，与 HTTP 同函数（tenant_config_routes.public_get）。
    if args.action == "branding":
        from app.api import tenant_config_routes as _tcr
        _st, _body = _tcr.public_get({"tenant": str(getattr(args, "code", "") or "")})
        _dump(dict(_body or {}))
    if args.action == "list":
        _need(uid, "platform.tenant.view")
        _dump({"ok": True, "items": tenants.list_tenants()})
    if args.action == "create":
        _need(uid, "platform.tenant.manage")
        if not args.name or not args.admin_phone or not args.admin_pwd:
            _err("开通租户需要 --name、--admin-phone、--admin-pwd", 2)
        _dump({"ok": True, **tenants.create_tenant(
            code=args.code or "", name=args.name, admin_phone=args.admin_phone,
            admin_pwd=args.admin_pwd, actor=uid, edition=args.edition or "trial",
            expires_at=args.expires_at or "", admin_name=args.admin_name or "")})
    if args.action == "admin-list":
        _need(uid, "platform.tenant.view")
        if not args.tenant_id:
            _err("需要 --tenant-id", 2)
        _dump({"ok": True, "items": tenants.list_tenant_admins(args.tenant_id)})
    if args.action == "admin-add":
        _need(uid, "platform.tenant.manage")
        if not args.tenant_id:
            _err("需要 --tenant-id", 2)
        _dump({"ok": True, **tenants.add_tenant_admin(
            args.tenant_id, args.name or "", args.phone or "", args.email or "",
            args.password or "", uid)})
    if args.action == "admin-status":
        _need(uid, "platform.tenant.manage")
        if not args.admin_id or not args.status:
            _err("需要 --admin-id 与 --status active|disabled", 2)
        _dump({"ok": True, **tenants.set_tenant_admin_status(args.admin_id, args.status, uid)})
    if args.action == "admin-reset":
        _need(uid, "platform.tenant.manage")
        if not args.admin_id:
            _err("需要 --admin-id", 2)
        _dump({"ok": True, **tenants.reset_tenant_admin_password(
            args.admin_id, args.password or "", uid)})
    # ---- L91：补齐 HTTP /api/v1/platform 已有受控生命周期动作 ----
    # 与 platform_routes 同服务层函数/同权限点（platform.tenant.manage）；写操作由
    # tenants.* 内部落审计（platform.tenant.update/status/delete、platform.admin.*）。
    def _tenant_fail(res, fallback=400):
        status = int((res or {}).get("http_status") or fallback)
        _err(str((res or {}).get("reason") or (res or {}).get("error") or "操作失败"),
             max(1, min(status, 599)), err_code=str((res or {}).get("code") or "tenant_error"),
             status=status)

    if args.action in ("update", "status", "delete"):
        _need(uid, "platform.tenant.manage")
        tid = str(getattr(args, "id", "") or getattr(args, "tenant_id", "") or "").strip()
        if not tid:
            _err("需要 --id（租户 ID）", 2, err_code="invalid_argument", status=400)
        if args.action == "status":
            if not args.status:
                _err("需要 --status active|suspended|deleted", 2,
                     err_code="invalid_argument", status=400)
            _res = tenants.set_status(tid, args.status)
        elif args.action == "delete":
            _res = tenants.delete_tenant(tid, uid)
        else:
            fields = {k: v for k, v in {
                "name": args.name or "", "edition": args.edition or "",
                "expires_at": args.expires_at or "",
            }.items() if v}
            if not fields:
                _err("没有可更新字段：用 --name/--edition/--expires-at", 2,
                     err_code="invalid_argument", status=400)
            _res = tenants.update_tenant(tid, fields, uid)
        if not _res.get("ok"):
            _tenant_fail(_res)
        _dump({"ok": True, "result": _res})
    if args.action in ("admin-update", "admin-delete"):
        _need(uid, "platform.tenant.manage")
        aid = str(getattr(args, "id", "") or getattr(args, "admin_id", "") or "").strip()
        if not aid:
            _err("需要 --id（平台管理员 ID）", 2, err_code="invalid_argument", status=400)
        if args.action == "admin-delete":
            _res = tenants.delete_platform_admin(aid, uid)
        else:
            if not (args.name or args.email):
                _err("没有可更新字段：用 --name/--email", 2,
                     err_code="invalid_argument", status=400)
            _res = tenants.update_platform_admin(aid, args.name or "", args.email or "", uid)
        if not _res.get("ok"):
            _tenant_fail(_res)
        _dump({"ok": True, "result": _res})


def cmd_decision(args, db):
    from app.services import decision_table as DT
    uid = _user_id(args, db)
    if args.action in ("list", "show"):
        # T-199：决策表查看权限点接线（旧 dt.view 死权限点）
        _need(uid, "dt.view")
        with _scope(args, db):
            if args.action == "list":
                _dump({"ok": True, "items": DT.list_tables()})
            else:
                if not args.code:
                    _err("需要 --code", 2)
                _dump({"ok": True, **DT.detail(args.code)})
    if args.action == "evaluate":
        _need(uid, "dt.view")
        if not args.code:
            _err("需要 --code", 2)
        try:
            facts = json.loads(args.facts or "{}")
        except Exception:
            _err("--facts 必须是 JSON", 2)
        with _scope(args, db):
            # P1-B3-03：CLI 与 HTTP 同源同参（audit_type/case_id 决定 scope 与 canary）
            _dump({"ok": True, **DT.evaluate(
                args.code, facts,
                audit_type=str(getattr(args, "audit_type", "") or ""),
                case_id=str(getattr(args, "case_id", "") or ""))})
    if args.action in ("create", "update", "publish"):
        _need(uid, "rule.manage" if args.action != "publish" else "rule.publish")
        # T-199：决策表维护权限点接线（旧 dt.manage 死权限点；审核员不可写）
        _need(uid, "dt.manage")
        if args.action in ("create", "update"):
            if not args.code or not args.name:
                _err("需要 --code 与 --name", 2)
            raw = args.rules or ""
            if args.rules_file:
                try:
                    raw = open(args.rules_file, encoding="utf-8").read()
                except Exception as e:
                    _err(f"读取 rules 文件失败：{e}", 2)
            try:
                rules = json.loads(raw or "[]")
            except Exception:
                _err("--rules/--rules-file 必须是合法 JSON 数组", 2)
            with _scope(args, db):
                if args.action == "create":
                    out = DT.create(args.code, args.name, rules, args.hit_policy or "first", by=uid)
                    if args.publish and not out.get("error"):
                        out["publish"] = DT.publish(args.code, by=uid)
                    # P1-B3-02：code 重复是冲突（409 语义），CLI 必须非 0 退出 + stderr，
                    # 不能像「字段校验失败」那样静默当普通错误。
                else:
                    out = DT.update(args.code, args.name, rules, args.hit_policy or "", by=uid)
        else:
            with _scope(args, db):
                out = DT.publish(args.code, by=uid)
        _dump({"ok": not out.get("error"), **out})


_ONTOLOGY_ASSET_CONFLICT_CODES = {"alias_conflict", "duplicate_entity",
                                 "duplicate_alias", "duplicate_link", "entity_in_use"}


def _parse_json_object(raw, label):
    """CLI 参数 JSON 对象解析（错误=退出码 2，不抛栈）。"""
    txt = str(raw or "").strip()
    if not txt:
        return None
    try:
        val = json.loads(txt)
    except Exception:
        _err("--%s 必须是合法 JSON 对象" % label, 2,
             err_code="invalid_argument", status=400)
    if not isinstance(val, dict):
        _err("--%s 必须是合法 JSON 对象" % label, 2,
             err_code="invalid_argument", status=400)
    return val


def _ontology_asset_reply(res):
    """本体资产写结果 → CLI 退出码（与 HTTP ontology_routes._asset_reply 同映射）。"""
    res = res if isinstance(res, dict) else {}
    if not res.get("ok"):
        code = str(res.get("code") or "")
        msg = str(res.get("reason") or res.get("error") or "本体写入失败")
        if code == "not_found":
            _err(msg, 404, err_code=code, status=404)
        elif code == "shared_asset":
            _err(msg, 403, err_code=code, status=403)
        elif code in _ONTOLOGY_ASSET_CONFLICT_CODES:
            _err(msg, 409, err_code=code, status=409)
        _err(msg, 400, err_code=code or "write_failed", status=400)
    _dump({"ok": True, **{k: v for k, v in res.items() if k != "ok"}})


def _ontology_target_ws(args, db, user):
    """CLI 本体目标空间解析（与 HTTP _ontology_target_workspace 同口径）。

    未传 = --ws；不存在或跨租户统一 404（不泄露存在性）。
    """
    from app.services import workspaces as _wsm
    wsid = str(getattr(args, "workspace_id", "") or getattr(args, "ws", "") or "").strip()
    row = _wsm.get(wsid) if wsid else {}
    if not row:
        _err("工作空间不存在", 404, err_code="not_found", status=404)
    from app import repositories as _R
    urow = _R.users.get((user or {}).get("sub") or "") or {}
    utenant = str(urow.get("tenant_id") or "")
    rtenant = str(row.get("tenant_id") or "")
    if utenant and rtenant and utenant != rtenant:
        _err("工作空间不存在", 404, err_code="not_found", status=404)
    return wsid


def cmd_ontology(args, db):
    from app.services import ontology_service as O
    from app.services import account
    from app.services import permissions as _perms
    uid, _actor = _cli_actor(args, db)
    roles = set(account.roles_of(uid))
    # T-125：本体域角色门禁与 HTTP 同源。HTTP `_guard` 对 /api/v1/ontology 与
    # /api/v1/ontology/* 的 GET/POST 统一用 permissions.ontology_denied(role) 拒绝
    # （T-122：用户口径「审核员不看本体」是角色边界，读/写都拒绝，避免
    # types/instances/links/validate/status 经只读接口泄露）。
    # CLI 过去只对写命令限制、读命令 show/versions/validate/status 无校验，reviewer
    # 仍能拿到本体数据；此处按同一事实源补齐，admin/super_admin 只读保持可用；
    # discover/add-term/threshold 的既有「仅 admin」写限制不变（不改写侧口径）。
    if _perms.ontology_denied(str(_actor.get("role") or "")):
        _err("审核员不看本体（服务端已拒绝）", 403, err_code="forbidden")
    if args.action == "show":
        _dump({"ok": True, **O.snapshot()})
    if args.action == "versions":
        _dump({"ok": True, "items": O.list_versions()})
    if args.action == "validate":
        from app.engine import engine
        _dump({"ok": True, **engine.ONTO.validate()})
    if args.action == "status":
        with _scope(args, db):
            _dump({"ok": True, **O.workspace_status()})
    # ---- L91：补齐 HTTP /api/v1/ontology 已有读取动作 ----
    if args.action == "impact":
        # GET /api/v1/ontology/impact：术语变更影响面（规则/决策表/智能体/审核点）。
        # 与 HTTP 同口径：--term 缺省时返回空影响面 + 提示（不报参数错，保持只读可用）。
        _out = O.impact(str(getattr(args, "term", "") or ""))
        _dump({"ok": True, **(_out if isinstance(_out, dict) else {"items": _out})})
    if args.action == "capabilities":
        # GET /api/v1/ontology/capabilities：空间本体能力/开关读取。
        _ws_cap = _ontology_target_ws(args, db, _actor)
        _out = O.capabilities(_ws_cap)
        _dump({"ok": True, **(_out if isinstance(_out, dict) else {"items": _out})})
    # ---- L91：补齐 HTTP 本体写动作（资产 CRUD/快照/发布/开关）；HTTP 口径仅 admin ----
    if args.action in ("snapshot", "publish", "switch", "entity-create", "entity-update",
                       "entity-delete", "alias-create", "alias-update", "alias-delete",
                       "link-create", "link-delete"):
        _need(uid, "onto.manage")
        if "admin" not in roles:
            _err("无权限：仅业务管理员可维护本体", 403, err_code="forbidden")
        with _scope(args, db):
            if args.action == "snapshot":
                _dump({"ok": True, **O.snapshot()})
            elif args.action == "publish":
                _vid = str(getattr(args, "id", "") or "").strip()
                if not _vid:
                    _err("publish 需要 --id（本体版本 ID）", 2,
                         err_code="invalid_argument", status=400)
                _pr = O.publish_version(_vid)
                if isinstance(_pr, dict) and _pr.get("error"):
                    _st = int(_pr.get("http_status") or 400)
                    _err(str(_pr.get("error")), max(1, min(_st, 599)),
                         err_code=str(_pr.get("code") or "publish_failed"), status=_st)
                _dump({"ok": True, **(_pr or {})})
            elif args.action == "switch":
                _ws_sw = _ontology_target_ws(args, db, _actor)
                _enabled = True if getattr(args, "enabled", False) else (
                    False if getattr(args, "disabled", False) else None)
                _mode = str(getattr(args, "mode", "") or "").strip() or None
                if _enabled is None and not _mode:
                    _err("switch 需要 --enabled / --disabled 或 --mode", 2,
                         err_code="invalid_argument", status=400)
                _out = O.set_control(_ws_sw, enabled=_enabled, mode=_mode,
                                     actor=uid, reason=str(args.reason or ""),
                                     source="manual")
                if not _out.get("ok"):
                    _code = str(_out.get("code") or "")
                    _st = 404 if _code == "not_found" else (
                        403 if _code in ("forbidden", "workspace_required", "invalid_mode")
                        else 400)
                    _err(str(_out.get("reason") or "切换失败"), max(1, min(_st, 599)),
                         err_code=_code or "invalid_switch", status=_st)
                _dump({"ok": True, **{k: v for k, v in _out.items() if k != "ok"}})
            elif args.action == "entity-create":
                if not str(getattr(args, "name", "") or "").strip():
                    _err("entity-create 需要 --name", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.create_entity(
                    str(getattr(args, "type", "") or "HalfProduct"),
                    str(args.name), _parse_json_object(args.props, "props") or {},
                    actor=uid))
            elif args.action == "entity-update":
                _eid = str(getattr(args, "id", "") or "").strip()
                if not _eid:
                    _err("entity-update 需要 --id", 2,
                         err_code="invalid_argument", status=400)
                _kw = {}
                if str(getattr(args, "name", "") or "").strip():
                    _kw["name"] = str(args.name)
                if str(getattr(args, "type", "") or "").strip():
                    _kw["type_key"] = str(args.type)
                _props_u = _parse_json_object(args.props, "props")
                if _props_u is not None:
                    _kw["props"] = _props_u
                if not _kw:
                    _err("entity-update 没有可更新字段：--name/--type/--props", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.update_entity(_eid, actor=uid, **_kw))
            elif args.action == "entity-delete":
                _eid = str(getattr(args, "id", "") or "").strip()
                if not _eid:
                    _err("entity-delete 需要 --id", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.delete_entity(_eid, actor=uid))
            elif args.action == "alias-create":
                if not str(getattr(args, "alias", "") or "").strip():
                    _err("alias-create 需要 --alias", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.create_alias(
                    str(getattr(args, "type", "") or ""), str(args.alias),
                    str(getattr(args, "entity_id", "") or ""),
                    str(getattr(args, "evidence", "") or ""), actor=uid))
            elif args.action == "alias-update":
                _aid = str(getattr(args, "id", "") or "").strip()
                if not _aid:
                    _err("alias-update 需要 --id", 2,
                         err_code="invalid_argument", status=400)
                _kw = {}
                if str(getattr(args, "alias", "") or "").strip():
                    _kw["alias"] = str(args.alias)
                if str(getattr(args, "evidence", "") or "").strip():
                    _kw["evidence"] = str(args.evidence)
                if str(getattr(args, "status", "") or "").strip():
                    _kw["status"] = str(args.status)
                if not _kw:
                    _err("alias-update 没有可更新字段：--alias/--evidence/--status", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.update_alias(_aid, actor=uid, **_kw))
            elif args.action == "alias-delete":
                _aid = str(getattr(args, "id", "") or "").strip()
                if not _aid:
                    _err("alias-delete 需要 --id", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.delete_alias(_aid, actor=uid))
            elif args.action == "link-create":
                _sid = str(getattr(args, "source_id", "") or "").strip()
                _tid = str(getattr(args, "target_id", "") or "").strip()
                if not _sid or not _tid:
                    _err("link-create 需要 --source-id 与 --target-id", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.create_link(
                    str(getattr(args, "key", "") or "produced_by"), _sid, _tid, actor=uid))
            elif args.action == "link-delete":
                _lid = str(getattr(args, "id", "") or "").strip()
                if not _lid:
                    _err("link-delete 需要 --id", 2,
                         err_code="invalid_argument", status=400)
                _ontology_asset_reply(O.delete_link(_lid, actor=uid))
    if args.action in ("discover", "add-term", "threshold"):
        # T-199：本体维护权限点接线（旧 onto.manage 死权限点）
        _need(uid, "onto.manage")
        if "admin" not in roles:
            _err("无权限：仅业务管理员可维护本体", 403)
        with _scope(args, db):
            if args.action == "discover":
                _dump({"ok": True, **O.discover()})
            elif args.action == "threshold":
                _dump({"ok": True, **O.save_threshold(args.threshold, uid)})
            else:
                aliases = [x.strip() for x in (args.aliases or "").split(",") if x.strip()]
                _dump({"ok": True, **O.add_manual(args.canonical, aliases, args.type, uid, args.evidence)})


def cmd_terms(args, db):
    """企业业务词典：查看 / 维护 / 确认术语 + 迁移旧 ontology_terms。

    - list 只读，按当前租户/空间读取；--all-spaces 汇总本租户全部空间；
    - create/update/delete/confirm 是写操作，权限与 HTTP 一致：
      仅 admin/super_admin；业务管理员不能跨租户；空间必须属于当前租户；
    - create/update/confirm 幂等：重复同一请求返回 idempotent=true，不重复写审计/版本；
    - migrate 迁移审计由服务层 terms 记录，dry_run 由服务层事务回滚；
    - 失败一律写 stderr 并返回非 0；权限失败 403、对象/空间不存在 404。
    """
    from app.services import terms as TM
    from app.services import account
    from app.services import ctx as _ctx

    def _fail(status, msg, code=""):
        """terms 失败统一写 stderr；status 保留真实产品语义，进程码用分类码。"""
        out = {"ok": False, "status": status, "error": msg}
        if code:
            out["code"] = code
        print(json.dumps(out, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(status=status))

    uid = _user_id(args, db)
    roles = set(account.roles_of(uid))
    is_super = "super_admin" in roles
    is_admin = bool(roles & {"admin", "super_admin"})
    # T-126：企业词典与本体同属规则配置层，用户口径「审核员不看本体/企业词典」。
    # CLI 与 HTTP 同源：非 admin/super_admin 对 terms 读/写一律 403（reviewer 不再能 list）；
    # 系统管理员的只读/写边界仍由全局 _super_admin_biz_readonly 判定（读放行、写拒绝）。
    if not is_admin:
        _fail(403, "无权限：需要管理员；审核员不看企业词典（服务端已拒绝）", "forbidden")
    user_tenant = _user_tenant(uid, db)
    tenant_id = (args.tenant or user_tenant or "t-default").strip()
    # 系统管理员是租户级角色：CLI --tenant 不能越权读写其他租户业务词典
    # （与 HTTP 租户隔离/系统管理员只看本租户同口径）。
    if user_tenant and tenant_id != user_tenant:
        _fail(403, f"无权限：只能操作本租户（{user_tenant}）", "forbidden")

    workspace_id = (getattr(args, "workspace_id", "") or "").strip()
    all_spaces = bool(getattr(args, "all_spaces", False))
    dry_run = bool(getattr(args, "dry_run", False))

    # 写权限先于参数细节校验：非管理员无论参数如何都只得到 403，不暴露其他分支。
    if args.action in ("create", "update", "delete", "confirm", "migrate") and not is_admin:
        _fail(403, "无权限：需要管理员", "forbidden")

    if all_spaces and workspace_id:
        _fail(2, "--all-spaces 与 --workspace-id 不能同时使用", "invalid_argument")
    if all_spaces and args.action in ("create", "update", "delete", "confirm"):
        _fail(2, f"--all-spaces 不支持 {args.action}；写操作必须指定单一空间", "invalid_argument")

    def _ws_row(wid):
        with db.session() as c:
            row = c.execute("SELECT id,tenant_id,name,status FROM workspace WHERE id=?",
                            (wid,)).fetchone()
        return dict(row) if row else None

    def _one_ws(wid):
        row = _ws_row(wid)
        if not row:
            _fail(404, f"工作空间不存在：{wid}", "workspace_missing")
        if (row.get("tenant_id") or "") != tenant_id:
            _fail(403, "无权限：工作空间不属于当前租户", "forbidden")
        return row

    # ---------------------------------------------------------------- 词典写操作工具
    def _write_ws():
        """写命令的作用空间：--workspace-id 优先，其次全局 --ws。"""
        wid = workspace_id or args.ws or "ws-default"
        _one_ws(wid)
        return wid

    def _split_names(value):
        """同义词/不等同：兼容 JSON 数组与中英文逗号/分号/竖线/顿号分隔字符串。"""
        if value is None:
            return []
        if isinstance(value, (list, tuple)):
            raw = list(value)
        else:
            s = str(value).strip()
            if not s:
                return []
            raw = None
            if s.startswith("["):
                try:
                    parsed = json.loads(s)
                    if isinstance(parsed, list):
                        raw = parsed
                except Exception:
                    raw = None
            if raw is None:
                raw = (s.replace("，", ",").replace("；", ",").replace(";", ",")
                       .replace("|", ",").replace("、", ",").split(","))
        out, seen = [], set()
        for x in raw:
            s = str(x or "").strip()
            k = s.replace("\u3000", "").replace(" ", "")
            if not s or not k or k in seen:
                continue
            seen.add(k)
            out.append(s)
        return out

    def _json_list(value, label):
        if value is None:
            return []
        s = str(value).strip()
        if not s:
            return []
        try:
            parsed = json.loads(s)
        except Exception:
            _fail(400, f"--{label} 必须是合法 JSON 数组", "invalid_argument")
        if not isinstance(parsed, list):
            _fail(400, f"--{label} 必须是合法 JSON 数组", "invalid_argument")
        if label == "relations" and any(not isinstance(x, dict) for x in parsed):
            _fail(400, "--relations 的每一项必须是 JSON 对象", "invalid_argument")
        return parsed

    def _load_json(raw):
        if isinstance(raw, list):
            return raw
        try:
            value = json.loads(raw or "[]")
        except Exception:
            return []
        return value if isinstance(value, list) else []

    def _row_by_id(tid, wid):
        with db.session() as c:
            row = c.execute(
                "SELECT * FROM business_term WHERE id=? AND tenant_id=? AND workspace_id=?",
                (tid, tenant_id, wid)).fetchone()
        return dict(row) if row else None

    def _render(row):
        d = dict(row or {})
        d["term_id"] = d.get("id")
        for key in ("synonyms_json", "not_equal_json", "relations_json"):
            d[key.replace("_json", "")] = _load_json(d.get(key))
        d["not_equal_count"] = len(d.get("not_equal") or [])
        d["effective"] = str(d.get("status") or "").lower() in TM.EFFECTIVE_STATUSES
        return d

    def _service_fail(res, fallback=400):
        """服务层失败统一走 stderr：优先使用 service 给出的 http_status/code。"""
        try:
            status = int(res.get("http_status") or fallback)
        except Exception:
            status = fallback
        _fail(status, res.get("error") or "术语操作失败",
              res.get("code") or "term_error")

    # ---------------------------------------------------------------- list
    if args.action == "list":
        if all_spaces:
            with db.session() as c:
                rows = [dict(r) for r in c.execute(
                    "SELECT id,tenant_id,name,status FROM workspace "
                    "WHERE tenant_id=? ORDER BY id", (tenant_id,)).fetchall()]
            scope_ws = ""
        else:
            scope_ws = workspace_id or args.ws or "ws-default"
            rows = [_one_ws(scope_ws)]
        items = []
        status = (getattr(args, "status", "") or "").strip()
        for w in rows:
            with _ctx.scoped(w.get("tenant_id") or tenant_id, w["id"]):
                for t in TM.list_terms(status):
                    t["workspace_name"] = w.get("name") or ""
                    items.append(t)
        _dump({"ok": True, "action": "list", "tenant_id": tenant_id,
               "workspace_id": scope_ws, "all_spaces": all_spaces,
               "count": len(items), "items": items})

    # ---------------------------------------------------------------- create
    if args.action == "create":
        target_ws = _write_ws()
        name = (args.name or "").strip()
        definition = (args.definition or "").strip()
        if len(name) < 2 or len(definition) < 4:
            _fail(400, "术语名称至少 2 字、定义至少 4 字", "invalid_argument")
        key = ((args.key or name).strip().upper().replace(" ", "-"))
        synonyms = _split_names(args.synonyms)
        not_equal = _split_names(args.not_equal)
        relations = _json_list(args.relations, "relations")
        source = (args.source or "").strip()
        term_scope = (args.scope or "").strip()
        entity_type = (args.entity_type or "").strip()
        unit = (args.unit or "").strip()
        with _ctx.scoped(tenant_id, target_ws):
            with db.session() as c:
                row = c.execute(
                    "SELECT * FROM business_term WHERE tenant_id=? AND workspace_id=? "
                    "AND (term_key=? OR name=?) "
                    "ORDER BY CASE WHEN status='confirmed' THEN 0 ELSE 1 END, rowid LIMIT 1",
                    (tenant_id, target_ws, key, name)).fetchone()
            existing = dict(row) if row else None
            if existing:
                same = (
                    (existing.get("term_key") or "") == key
                    and (existing.get("name") or "") == name
                    and (existing.get("definition") or "") == definition
                    and _load_json(existing.get("synonyms_json")) == synonyms
                    and _load_json(existing.get("not_equal_json")) == not_equal
                    and _load_json(existing.get("relations_json")) == relations
                    and (existing.get("source") or "") == source
                    and (existing.get("scope") or "") == term_scope
                    and (existing.get("entity_type") or "") == entity_type
                    and (existing.get("unit") or "") == unit
                )
                if same:
                    _dump({"ok": True, "action": "create", "created": False,
                           "idempotent": True, "term_id": existing.get("id"),
                           "key": existing.get("term_key") or key,
                           "status": existing.get("status") or "draft",
                           "term": _render(existing),
                           "tenant_id": tenant_id, "workspace_id": target_ws})
                _fail(400, f"术语已存在：{existing.get('name') or name}", "term_exists")
            res = TM.create_term(name, definition, synonyms, not_equal, source,
                                 term_scope, key, uid, entity_type, unit, relations)
            if not res.get("ok"):
                # HTTP create 对服务层错误统一 400；CLI 保持同状态，同时透出 service code。
                _fail(400, res.get("error") or "术语创建失败",
                      res.get("code") or "invalid_argument")
            created = _row_by_id(str(res.get("term_id") or ""), target_ws)
            _dump({"ok": True, "action": "create", "created": True,
                   "idempotent": False, "term_id": res.get("term_id"),
                   "key": res.get("key") or key, "status": res.get("status") or "draft",
                   "term": _render(created),
                   "tenant_id": tenant_id, "workspace_id": target_ws})

    # ---------------------------------------------------------------- update
    if args.action == "update":
        target_ws = _write_ws()
        tid = (getattr(args, "term_id", "") or "").strip()
        if not tid:
            _fail(400, "缺少 --id/--term-id", "invalid_argument")
        fields = ("name", "definition", "synonyms", "not_equal", "source", "scope",
                  "key", "entity_type", "unit", "relations")
        if not any(getattr(args, f, None) is not None for f in fields):
            _fail(400, "没有需要更新的字段", "invalid_argument")
        with _ctx.scoped(tenant_id, target_ws):
            existing = _row_by_id(tid, target_ws)
            if not existing:
                _fail(404, f"术语不存在：{tid}", "not_found")
            body = {}
            changed = []
            if args.name is not None:
                value = str(args.name).strip()
                if len(value) < 2:
                    _fail(400, "术语名称至少 2 字", "invalid_argument")
                if value != (existing.get("name") or ""):
                    body["name"] = value
                    changed.append("name")
            if args.definition is not None:
                value = str(args.definition).strip()
                if len(value) < 4:
                    _fail(400, "术语定义至少 4 字", "invalid_argument")
                if value != (existing.get("definition") or ""):
                    body["definition"] = value
                    changed.append("definition")
            if args.synonyms is not None:
                value = _split_names(args.synonyms)
                if value != _load_json(existing.get("synonyms_json")):
                    body["synonyms"] = value
                    changed.append("synonyms")
            if args.not_equal is not None:
                value = _split_names(args.not_equal)
                if value != _load_json(existing.get("not_equal_json")):
                    body["not_equal"] = value
                    changed.append("not_equal")
            if args.relations is not None:
                value = _json_list(args.relations, "relations")
                if value != _load_json(existing.get("relations_json")):
                    body["relations"] = value
                    changed.append("relations")
            for field, column in (("source", "source"), ("scope", "scope"),
                                  ("entity_type", "entity_type"), ("unit", "unit")):
                value = getattr(args, field, None)
                if value is None:
                    continue
                value = str(value).strip()
                if value != (existing.get(column) or ""):
                    body[field] = value
                    changed.append(field)
            if args.key is not None:
                value = str(args.key).strip().upper().replace(" ", "-")
                if value != (existing.get("term_key") or ""):
                    body["key"] = value
                    changed.append("key")
            if not body:
                _dump({"ok": True, "action": "update", "updated": False,
                       "idempotent": True, "term_id": tid, "changed": [],
                       "term": _render(existing),
                       "tenant_id": tenant_id, "workspace_id": target_ws})
            res = TM.update_term(tid, body, actor=uid)
            if not res.get("ok"):
                _service_fail(res)
            updated = _row_by_id(tid, target_ws) or existing
            _dump({"ok": True, "action": "update",
                   "updated": bool(res.get("changed", True)),
                   "idempotent": bool(res.get("idempotent")),
                   "term_id": tid, "changed": changed,
                   "version": res.get("version"), "status": res.get("status"),
                   "term": _render(updated),
                   "projection": res.get("projection") or {},
                   "reverse_projection": res.get("reverse_projection") or {},
                   "conflicts": res.get("conflicts") or [],
                   "tenant_id": tenant_id, "workspace_id": target_ws})

    # ---------------------------------------------------------------- delete
    if args.action == "delete":
        target_ws = _write_ws()
        tid = (getattr(args, "term_id", "") or "").strip()
        if not tid:
            _fail(400, "缺少 --id/--term-id", "invalid_argument")
        with _ctx.scoped(tenant_id, target_ws):
            existing = _row_by_id(tid, target_ws)
            if not existing:
                _fail(404, f"术语不存在：{tid}", "not_found")
            res = TM.delete_term(tid, actor=uid, reason=(getattr(args, "reason", "") or ""))
            if not res.get("ok"):
                _service_fail(res)
            _dump({"ok": True, "action": "delete", "deleted": True, "term_id": tid,
                   "name": existing.get("name") or "",
                   "reverse_projection": res.get("reverse_projection") or {},
                   "reason": res.get("reason") or "",
                   "tenant_id": tenant_id, "workspace_id": target_ws})

    # ---------------------------------------------------------------- confirm
    if args.action == "confirm":
        target_ws = _write_ws()
        tid = (getattr(args, "term_id", "") or "").strip()
        if not tid:
            _fail(400, "缺少 --id/--term-id", "invalid_argument")
        with _ctx.scoped(tenant_id, target_ws):
            existing = _row_by_id(tid, target_ws)
            if not existing:
                _fail(404, f"术语不存在：{tid}", "not_found")
            # 已确认的重复请求直接返回幂等，不重复写确认审计/投影。
            if str(existing.get("status") or "").lower() == "confirmed":
                _dump({"ok": True, "action": "confirm", "confirmed": False,
                       "idempotent": True, "term_id": tid, "status": "confirmed",
                       "term": _render(existing), "projection": {},
                       "tenant_id": tenant_id, "workspace_id": target_ws})
            res = TM.confirm(tid, uid)
            if not res.get("ok"):
                _service_fail(res)
            updated = _row_by_id(tid, target_ws) or existing
            _dump({"ok": True, "action": "confirm", "confirmed": True,
                   "idempotent": bool(res.get("idempotent")),
                   "term_id": tid, "status": "confirmed",
                   "term": _render(updated),
                   "projection": res.get("projection") or {},
                   "conflicts": res.get("conflicts") or [],
                   "tenant_id": tenant_id, "workspace_id": target_ws})

    # ---------------------------------------------------------------- migrate
    if args.action == "migrate":
        target_ws = "" if all_spaces else (workspace_id or args.ws or "ws-default")
        if target_ws:
            # 不存在的空间交给服务层返回 workspace_missing；已存在但跨租户先拒绝。
            row = _ws_row(target_ws)
            if row and (row.get("tenant_id") or "") != tenant_id:
                _fail(403, "无权限：工作空间不属于当前租户", "forbidden")
        res = TM.migrate_legacy_ontology_terms(
            tenant_id=tenant_id, workspace_id=target_ws, actor=uid,
            dry_run=dry_run, all_spaces=all_spaces)
        out = dict(res)
        out["action"] = "migrate"
        if out.get("ok"):
            _dump(out)
        code = out.get("code") or "migration_failed"
        exit_code = (404 if code == "workspace_missing" else
                     3 if code in ("legacy_data_missing", "legacy_data_invalid") else 1)
        if exit_code in (403, 404):
            out["status"] = exit_code
        fail = {"ok": False, "action": "migrate",
                "error": out.get("reason") or "迁移失败", **out}
        print(json.dumps(fail, ensure_ascii=False), file=sys.stderr)
        sys.exit(_exit_code(exit_code))

    _fail(2, f"未知 terms 操作：{args.action}", "invalid_argument")


def _policy_role_tenant(args, db):
    """数据边界命令的身份与租户：角色按账号真实角色，租户只取账号所属租户。"""
    from app.services import account
    uid = _user_id(args, db)
    roles = set(account.roles_of(uid) or [])
    role = next((r for r in ("super_admin", "admin", "reviewer", "platform_op") if r in roles),
                (roles and sorted(roles)[0]) or "reviewer")
    tenant = _user_tenant(uid, db)
    if args.tenant and str(args.tenant) != str(tenant):
        _err("跨租户访问被拒绝：--tenant 与账号所属租户不一致", 403,
             err_code="tenant_mismatch", status=403)
    return uid, role, tenant


def _policy_need_read(role):
    if role != "super_admin":
        _err("无权限：数据边界策略仅系统管理员可访问", 403,
             err_code="forbidden", status=403)


def cmd_data_policy(args, db):
    """数据边界策略：状态/配置/删除预览/删除执行（与 HTTP 同一服务层与权限）。

    - status/get/set：仅系统管理员；set 必须 --yes，写审计 data.policy.updated；
    - purge-preview：只读影响面 + 签发一次性预览凭证（写审计 data.purge.preview）；
    - purge-execute：默认 dry-run（0 删除）；--execute 真实删除，仅系统管理员，
      必须 --token（来自 purge-preview）+ --confirm 确认删除。
    """
    from app.services import sysconfig
    uid, role, tenant = _policy_role_tenant(args, db)
    action = str(args.action or "")
    if action in ("status", "get"):
        _policy_need_read(role)
        status = sysconfig.data_policy_status()
        if action == "get":
            _dump({"ok": True, "tenant_id": tenant, "role": role,
                   "policy": status["policy"], "configured": status["configured"],
                   "warnings": status["warnings"]})
        _dump({"ok": True, "tenant_id": tenant, "role": role, **status})
    if action == "set":
        _policy_need_read(role)
        if not getattr(args, "yes", False):
            _err("写操作需要 --yes 确认（数据边界策略涉及合规口径）", 2,
                 err_code="confirm_required")
        fields = {}
        try:
            cfg = json.loads(getattr(args, "config", "") or "{}")
            if isinstance(cfg, dict):
                fields.update(cfg)
        except Exception:
            _err("--config 必须是 JSON 对象", 2)
        for item in (getattr(args, "sets", None) or []):
            if "=" not in str(item):
                _err("--set 必须是 KEY=VALUE", 2)
            k, v = str(item).split("=", 1)
            fields[k.strip()] = v.strip()
        if not fields:
            _err("没有可保存的字段：用 --set key=value 或 --config JSON", 2)
        try:
            result = sysconfig.set_data_policy(fields, actor=uid)
        except ValueError as exc:
            _err(str(exc), 400, err_code="invalid_policy", status=400)
        status = sysconfig.data_policy_status()
        _dump({"ok": True, "tenant_id": tenant, "role": role,
               "changed": result.get("changed") or {},
               "configured": status["configured"],
               "policy": status["policy"], "warnings": status["warnings"]})
    if action == "purge-preview":
        _policy_need_read(role)
        # P1-08：workspace 参数不得被忽略；不传=整租户，传了就必须按该空间限定。
        wid = str(getattr(args, "workspace_id", "") or "").strip()
        try:
            result = sysconfig.create_purge_preview(
                tenant, workspace_id=wid, actor=uid, request_id="cli", ip="cli")
        except ValueError as exc:
            _err(str(exc), 400, err_code="invalid_workspace", status=400)
        _dump({"ok": True, "tenant_id": tenant, "workspace_id": wid,
               "role": role, **result})
    if action == "purge-execute":
        _policy_need_read(role)
        if not str(getattr(args, "token", "") or ""):
            _err("删除执行必须先预览：缺少 --token（来自 data-policy purge-preview）", 428,
                 err_code="preview_required", status=428)
        dry_run = not bool(getattr(args, "execute", False))
        if not dry_run and role != "super_admin":
            _err("实际删除仅系统管理员执行（业务管理员可 purge-preview/dry-run）", 403,
                 err_code="forbidden", status=403)
        wid = str(getattr(args, "workspace_id", "") or "").strip()
        result = sysconfig.purge_execute(
            tenant, preview_token=str(args.token), actor=uid,
            confirm=str(getattr(args, "confirm", "") or ""), dry_run=dry_run,
            workspace_id=wid, request_id="cli", ip="cli", role=role)
        if not result.get("ok"):
            _err(result.get("error") or "删除执行失败", int(result.get("status") or 1),
                 err_code=result.get("code"), status=result.get("status"),
                 detail={k: result.get(k) for k in ("dry_run", "tenant_id", "deleted")})
        _dump(result)
    _err("未知 action：" + action, 2)


def cmd_notify_config(args, db):
    from app.services import notify
    uid = _user_id(args, db)
    from app.services import account
    if "super_admin" not in set(account.roles_of(uid)):
        _err("无权限：仅系统管理员可配置消息", 403)
    # T-199：通知配置权限点接线（config.notify，super_admin 由通配持有）
    _need(uid, "config.notify")
    if args.action == "get":
        _dump({"ok": True, **notify.get_config()})
    if args.action == "save":
        try:
            cfg = json.loads(args.config or "{}")
        except Exception:
            _err("--config 必须是 JSON", 2)
        _dump({"ok": True, **notify.save_config(cfg, uid)})

def cmd_agent(args, db):
    """智能体（全系统）：与 HTTP /api/v1/agents* 同一权限事实源。

    L108 修复（L106 G1/G2/G5）：
    - 旧实现 list/show/versions **无任何鉴权**：reviewer 可读全部提示词/工作流；
    - 旧实现 run 用 ``_need_admin`` 放行业务管理员，与 HTTP（agent.manage + IT 隔离）不同源；
    - 旧实现 run 不传 actor → 审计 actor=system，无法追溯操作人。
    现在：读 = agent.view、写/运行 = agent.manage（注册表唯一事实源，当前仅系统管理员）；
    未知/未注册角色 fail-closed 403；run 的审计 actor = 当前 CLI 身份 uid。
    """
    from app.services import agents
    from app.services import account as _account
    from app.services import permission_registry as _preg
    from app import repositories as R
    uid, user = _cli_actor(args, db)
    _role = str((user or {}).get("role") or "")
    # 未知/悬空角色与 HTTP _guard 同口径 fail-closed：
    #   ① roles_of 会过滤未注册角色（全为未知 → [])，此时 _cli_actor 回退成 reviewer，
    #      若不拦就会让「DB 里只有一个自定义角色 + 误授 agent.view」的账号拿到 reviewer
    #      身份并通过 DB 权限点（fail-open）；② role 本身也必须在注册表四角色内。
    if not _account.roles_of(uid) or not _preg.is_known_role(_role):
        _err("无权限：未知角色（未在权限注册表内）", 403, err_code="forbidden")
    if args.action in ("list", "show", "versions"):
        # HTTP：GET /api/v1/agents 由 server._guard 的 IT 隔离（admin 403）
        # + agent_routes 管理员门禁（reviewer 403）共同决定 → 等价于仅持 agent.view 的角色。
        _need(uid, "agent.view")
        if args.action == "list":
            _dump({"ok": True, **agents.list_agents()})
        if not args.id:
            _err("需要 --id", 2)
        if args.action == "show":
            _detail = agents.agent_detail(args.id)
            if not _detail:
                _err("智能体不存在", 404, err_code="not_found")
            _dump({"ok": True, **_detail})
        # versions：与详情同源（唯一生效版本标记 + 旧库多条 published 可观测）
        eff = agents.effective_version(args.id) or {}
        rows = [dict(x) for x in R.agent_versions.list(
            "agent_id=?", (args.id,), order="published_at DESC, version DESC")]
        for x in rows:
            x["effective"] = bool(x.get("id") and x.get("id") == eff.get("id"))
        _dump({"ok": True, "items": rows,
               "effective_version": str(eff.get("version") or ""),
               "effective_version_id": str(eff.get("id") or ""),
               "published_count": sum(1 for x in rows
                                      if (x.get("status") or "") == "published")})
    if args.action == "run":
        # 与 HTTP POST /api/v1/agents/{id}/run 同源：agent.manage（不再用 _need_admin 放行 admin）
        _need(uid, "agent.manage")
        if not args.id:
            _err("需要 --id", 2)
        try:
            payload = json.loads(args.payload or "{}")
        except Exception:
            _err("--payload 必须是 JSON", 2)
        with _scope(args, db):
            # 审计 actor 必须=当前 CLI 身份，不能落成 system（L108 G5）
            _dump({"ok": True, **agents.run_agent(args.id, payload, actor=uid)})


def cmd_evolution(args, db):
    """规则进化：历史回放 / 效果趋势 / 回滚建议。

    与 HTTP 端共用 evolution 服务、权限与审计：
    - replay/trend 只读，要求 evo.view；
    - rollback 只生成建议（applied=False），要求 evo.manage，审计
      evolution.rollback_suggested，不修改规则；
    - 空样本指标保持 None，不冒充 100%/0%。
    """
    from app.services import evolution as EV
    uid, user = _cli_actor(args, db)
    _set_scope(args)
    rule = str(getattr(args, "rule", "") or "").strip()
    action = str(getattr(args, "action", "") or "")
    version = str(getattr(args, "version", "") or "").strip()
    limit = int(getattr(args, "limit", 200) or 200)
    # L170：误报库（HTTP GET /api/v1/errorbook）与复核反馈闭环
    # （HTTP GET /api/v1/feedback、/feedback/mine、POST /feedback/<id>/settle）。
    # 一等入口：rp evolution errorbook / rp feedback list|mine|settle。
    if action in ("errorbook", "feedback-list", "feedback-mine", "feedback-settle"):
        from app.services import feedback as _fb15
        from app.services import ctx as _ctx_ev15
        role15 = str((user or {}).get("role") or "")
        if role15 == "platform_op":
            _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        # 与 HTTP 每请求上下文同口径：租户取账号真实租户（--tenant 不得放大范围）。
        _tenant15 = _l170_tenant_scope(args, db, user)
        _ctx_ev15.set_context(_tenant15, str(getattr(args, "ws", "") or ""))
        if action == "errorbook":
            # HTTP GET /api/v1/errorbook 在 _ADMIN_GET：仅业务管理员/系统管理员。
            if role15 not in ("admin", "super_admin"):
                _err("无权限（需管理员）", 403, err_code="forbidden")
            _off = max(0, int(getattr(args, "offset", 0) or 0))
            _lim = max(1, min(int(getattr(args, "limit", 100) or 100), 500))
            _all = EV.error_book()
            _dump({"ok": True, "items": _all[_off:_off + _lim],
                   "total": len(_all), "limit": _lim, "offset": _off})
        if action == "feedback-list":
            # HTTP GET /api/v1/feedback 在 _ADMIN_GET：仅业务管理员/系统管理员。
            if role15 not in ("admin", "super_admin"):
                _err("无权限（需管理员）", 403, err_code="forbidden")
            from app.services import account as _acc15
            _items = _fb15.list_feedback(
                str(getattr(args, "kind", "") or ""),
                str(getattr(args, "status", "") or ""),
                limit=max(1, min(int(getattr(args, "limit", 200) or 200), 500)))
            # 与 HTTP 处理体同口径：department 按 actor_id 一次批量补齐（无 N+1）。
            _dept = _acc15.departments_of([x.get("actor_id") or "" for x in _items])
            for _x in _items:
                _x["department"] = _dept.get(str(_x.get("actor_id") or ""), "")
            _dump({"ok": True, "items": _items,
                   "stats": _fb15.stats(), "rules": _fb15.rule_ledger()})
        if action == "feedback-mine":
            # HTTP GET /api/v1/feedback/mine：任意已登录业务身份，只返回本人反馈。
            _dump({"ok": True, "items": _fb15.list_mine(uid)})
        # feedback-settle：HTTP POST /api/v1/feedback/<id>/settle。权限唯一口径在
        # 服务层 feedback.settle_permission（admin 可；reviewer 只读拒绝并写
        # feedback.settle_denied 审计；super_admin/platform_op 由 business_write_deny
        # 拒绝）。CLI 先做与 HTTP _feedback_scope 一致的 404/403，再调同一 settle 服务。
        _fid15 = str(getattr(args, "feedback_id", "") or "").strip()
        if not _fid15:
            _err("缺少 --feedback-id（反馈 ID）", 2, err_code="invalid_argument",
                 status=400)
        from app.api.role_scope import feedback_scope as _fb_scope15
        from app.services import ids as _ids15

        class _CliFeedbackHandler(object):
            def _resolve_id(self, kind, ident, user=None):
                try:
                    row = _ids15.resolve(kind, ident, user if user is not None else user15)
                except _ids15.IDLookupError as _e:
                    return None, (_e.status, {"error": _e.message, "code": _e.code})
                return row, None

        user15 = {"sub": uid, "id": uid, "role": role15,
                  "roles": list((user or {}).get("roles") or [])}
        _frow15, _fdeny15 = _fb_scope15(_CliFeedbackHandler(), _fid15)
        if _fdeny15:
            _err_deny(_fdeny15)
        _fres15 = _fb15.settle(
            _fid15, str(getattr(args, "feedback_action", "revise") or "revise"),
            str(getattr(args, "note", "") or ""), uid,
            auto_publish=bool(getattr(args, "auto_publish", False)))
        if _fres15.get("ok"):
            _dump({"ok": True, **_fres15})
        _fstatus15 = (403 if (_fres15.get("status") == 403
                              or _fres15.get("code") == "forbidden")
                      else int(_fres15.get("http_status") or 400))
        _err(str(_fres15.get("error") or _fres15.get("message") or "反馈处置失败"),
             _fstatus15, err_code=str(_fres15.get("code") or "settle_failed"),
             status=_fstatus15)
    # T-177：空间准确率看板（GET 同源 /api/v1/workspace/accuracy）
    #   accuracy        → 看板 JSON（每轮 F1+CI+n_docs+δ_min+规则数+配对Δ+判定）
    #   accuracy-record → 记录一轮真实评测结果（逐文档 tp/fp/n，需要 evo.manage）
    #   coldstart       → 冷启动「建议先补 N 条规则」（真实反馈聚类，不调模型）
    if action in ("accuracy", "accuracy-record", "coldstart"):
        if action == "accuracy":
            res = EV.accuracy_board(limit=max(1, min(limit, 200)), user=user)
        elif action == "coldstart":
            res = EV.accuracy_coldstart(limit=max(1, min(limit, 50)), user=user)
        else:
            try:
                docs = json.loads(str(getattr(args, "docs", "") or "[]"))
            except Exception:
                _err("--docs 必须是 JSON 数组", 2, err_code="invalid_argument")
            res = EV.accuracy_record_round(
                {"docs": docs, "label": getattr(args, "label", "") or "",
                 "source": getattr(args, "source", "") or "",
                 "rule_count": int(getattr(args, "rule_count", 0) or 0),
                 "notes": getattr(args, "notes", "") or ""},
                user=user, source=getattr(args, "source", "") or "")
        if not res.get("ok"):
            _err(str(res.get("error") or "操作失败"), int(res.get("status") or 400),
                 err_code=str(res.get("code") or "failed"))
        _dump({"ok": True, **res})
    if not rule:
        _err("需要 --rule（规则编码）", 2, err_code="invalid_argument")

    def _out(res):
        status = str((res or {}).get("status") or "")
        if status in ("no_rule", "version_not_found"):
            msg = (res or {}).get("status_reason") or (res or {}).get("reason") or "规则不存在"
            code = "version_not_found" if status == "version_not_found" else "not_found"
            _err(msg, 404, err_code=code)
        _dump({"ok": True, **res})

    if action in ("replay", "trend"):
        if not EV.user_can_view(user):
            _err("无权限：需要 evo.view", 403, err_code="forbidden")
        if action == "replay":
            _out(EV.replay_rule(rule, version=version, limit=limit))
        _out(EV.effect_trend(rule, limit=limit, version=version))
    if action == "rollback":
        if not EV.user_can_manage(user):
            _err("无权限：需要 evo.manage", 403, err_code="forbidden")
        _out(EV.rollback_suggestion(rule, version=version, limit=limit,
                                    user=uid, source="cli"))
    _err(f"未知进化操作：{action}", 2, err_code="invalid_argument")


def _auditlog_scope(args, db):
    """审计导出的 CLI 作用域：与 auditlog list 同源（账号真实租户，禁止 --tenant 放大）。"""
    from app import repositories as _R
    uid, user = _cli_actor(args, db)
    role = str((user or {}).get("role") or "")
    row = _R.users.get(uid) or {}
    tenant_id = str(row.get("tenant_id") or "")
    workspace_id = str(row.get("workspace_id") or "")
    if role != "super_admin":
        # 非 super_admin（平台运营）允许显式 --tenant 过滤；默认取 --tenant。
        tenant_id = str(args.tenant or tenant_id or "")
        workspace_id = str(args.ws or workspace_id or "")
    elif tenant_id and args.tenant and args.tenant != tenant_id:
        _err("无权跨租户导出审计日志", 403, err_code="forbidden", status=403)
    return uid, user, role, tenant_id, workspace_id


def _auditlog_export(args, db):
    """审计导出（T-201，默认关闭；仅 super_admin/platform_op；必须 --confirm）。"""
    import tempfile
    from app.services import audit_export
    uid, _user, role, tenant_id, workspace_id = _auditlog_scope(args, db)
    out = audit_export.export(
        actor=uid, role=role, fmt=str(getattr(args, "format", "csv") or "csv"),
        confirm=bool(getattr(args, "confirm", False)),
        q=args.q or "", result=args.result or "",
        action=args.action_filter or "", actor_filter=args.actor or "",
        date_from=args.date_from or "", date_to=args.date_to or "",
        tenant_id=tenant_id, workspace_id=workspace_id, ip="cli", request_id="cli")
    if not out.get("ok"):
        _err(out.get("error") or "审计导出失败", int(out.get("status") or 400),
             err_code=str(out.get("code") or ""), status=int(out.get("status") or 400))
    content = out.pop("content")
    out_path = str(getattr(args, "out", "") or "").strip()
    if not out_path:
        out_path = os.path.join(tempfile.gettempdir(), out.get("filename") or "audit_export.csv")
    try:
        with open(out_path, "wb") as f:
            f.write(content)
    except Exception as e:  # noqa: BLE001 - 写文件失败必须非 0 退出并给原因
        _err(f"导出文件写入失败：{type(e).__name__}: {e}", 1)
    out["out"] = out_path
    _dump(out)


def _auditlog_export_config(args, db):
    """审计导出开关（仅 super_admin；二次确认 --confirm；写审计）。"""
    from app.services import audit_export
    uid, _user, role, tenant_id, workspace_id = _auditlog_scope(args, db)
    if role != "super_admin":
        _err("仅系统管理员可变更审计导出开关", 403, err_code="forbidden", status=403)
    enable = bool(getattr(args, "enable", False))
    disable = bool(getattr(args, "disable", False))
    if enable == disable:
        _err("需要且只支持一个：--enable 或 --disable", 2, err_code="invalid_argument")
    if not bool(getattr(args, "confirm", False)):
        _err("变更审计导出开关属于敏感操作，必须二次确认（--confirm）", 400,
             err_code="confirm_required", status=400)
    scope = str(getattr(args, "scope", "platform") or "platform")
    out = audit_export.set_enabled(
        enable, actor=uid, role=role,
        tenant_id=(tenant_id if scope == "workspace" else ""),
        workspace_id=(workspace_id if scope == "workspace" else ""),
        request_id="cli")
    if not out.get("ok"):
        _err(out.get("error") or "开关变更失败", int(out.get("status") or 400),
             err_code=str(out.get("code") or ""), status=int(out.get("status") or 400))
    _dump(out)


def cmd_auditlog(args, db):
    """审计日志（只读）：与 HTTP /api/v1/audit-logs 同源。

    T-201：``action=export`` 为审计导出（默认关闭，需 super_admin/platform_op +
    --confirm，写审计+水印列）；``action=export-config`` 为开关变更（仅 super_admin）。

    P0-01：审计轨迹属于租户内安全数据，本命令同样只允许系统管理员（super_admin），
    业务管理员/审核员一律 403；查询范围强制取账号真实租户 + 空间（与 HTTP JWT
    会话口径一致），不接受 --tenant/--ws 跨租户放大，旧库全量查询不再可达。
    """
    action = str(getattr(args, "action", "") or "list")
    if action == "export":
        return _auditlog_export(args, db)
    if action == "export-config":
        return _auditlog_export_config(args, db)
    from app.services import audit
    from app import repositories as R
    uid, user = _cli_actor(args, db)
    role = str((user or {}).get("role") or "")
    if role != "super_admin":
        _err("仅系统管理员可查看审计日志", 403, err_code="forbidden")
    _need(uid, "log.view")
    row = R.users.get(uid) or {}
    tenant_id = str(row.get("tenant_id") or "") or _user_tenant(uid, db)
    workspace_id = str(row.get("workspace_id") or "")
    _dump({"ok": True, **audit.search_logs(
        q=args.q or "", result=args.result or "", action=args.action_filter or "",
        actor=args.actor or "", date_from=args.date_from or "", date_to=args.date_to or "",
        limit=args.limit, offset=args.offset,
        tenant_id=tenant_id, workspace_id=workspace_id)})



# 系统管理员业务只读边界（与 app/api/server.py 的 B 口径一致）：
# _BIZ_CMDS 内的命令默认拒绝，只有明确只读的「命令 + action」放行。
#
# S4（评审 P0 第二批）：名单必须与 argparse 实际命令名逐字一致。
# 修复前集合里写的是 ``conflict``，而实际命令是 ``conflict-check``（``_is_biz_cmd``
# 按 ``args.cmd`` 精确匹配）→ 系统管理员可执行 ``rp conflict-check run``（写冲突检测
# 状态），绕过「系统管理员不访问审核业务」的写边界（与 HTTP POST /conflicts/detect 403 不一致）。
_BIZ_CMDS = {"rule", "audit", "project", "finding", "report", "manifest",
             "ledger", "point", "evidence", "terms", "decision", "evolution",
             # S4：真实命令名是 conflict-check（不是 conflict）；run=全量检测=业务写，
             # 系统管理员/平台运维一律拒绝，status 也不在白名单（与 HTTP 只读口径一致）。
             "conflict-check",
             "doc", "artifacts", "semantic", "ontology", "human-review",
             # T-50（W-14）V3.2 产品数据命令：系统管理员/平台运营禁止访问（与 HTTP 同口径）
             "direct-draft", "compare", "visibility", "omission",
             # T-203 影子池：仅 reviewer/admin（admin 只读由服务层强制）；
             # super_admin/platform_op 的平台边界由本清单拒绝（与 HTTP 403 同口径）。
             "shadow",
             # S4 补漏（同为业务写，HTTP 侧 super_admin 一律 403）：
             #   extra    = /api/v1/reviews/extra/decide（人工复核裁决）
             #   task     = /api/v1/tasks/{id}/cancel（写）；list/show 属只读白名单
             #   ws       = /api/v1/workspaces/create + settings/save（写）
             #   knowledge= 知识库写（服务层另有一道 _ensure_role 拒绝平台身份）
             "extra", "task", "ws", "knowledge",
             # L50 规则分组标签：组织元数据；写=业务管理动作（系统管理员/平台运营拒绝），
             # 只读 list 由 _SUPER_BIZ_READ 放行（与 HTTP 系统管理员只读口径一致）。
             "rule-tag",
             # L80 裁决来源台账：HTTP 侧超管/平台运营 403（_case_owned 拒绝），CLI 同口径；
             # 不放行只读白名单（台账含业务判定归因，属审核业务数据）。
             "adjudication-ledger"}
_SUPER_BIZ_READ = {
    "rule": {"list", "static", "drift-report"},
    "project": {"list", "show",
                # L170：我的审核（HTTP GET /api/v1/my-audits 属系统管理员只读白名单）
                "my-audits"},
    "evidence": {"list"},
    # L91：补齐 HTTP GET /api/v1/audit-points 的只读动作（点位库/选项/确认/路由/推荐）。
    "point": {"list", "stale", "library", "options", "confirmations", "route",
              "recommended",
              # L170：审计分类元数据（HTTP GET /api/v1/audit-categories）
              "categories"},
    "terms": {"list"},
    "decision": {"list", "show", "evaluate"},
    "evolution": {"replay", "trend",
                  # L170：误报库/反馈台账只读（HTTP GET /api/v1/errorbook、/feedback、/feedback/mine）
                  "errorbook", "feedback-list", "feedback-mine"},
    # L91：补齐 HTTP GET /api/v1/ontology/{impact,capabilities} 的只读白名单。
    "ontology": {"show", "versions", "validate", "status", "impact", "capabilities"},
    "finding": {"list",
                # L170：问题分析统计（HTTP GET /api/v1/analytics/issues 属系统管理员只读白名单）
                "analytics"},
    "doc": {"*"},
    # S4 补漏：只读动作与 HTTP GET 白名单对齐（GET /api/v1/tasks、GET /workspaces）。
    # 注意：``ws settings`` 带 --patch 是写，由 _super_admin_biz_readonly 单独判定后拒绝。
    "task": {"list", "show"},
    # L91：members/rules-review 与 HTTP GET /api/v1/workspaces/* 同口径放行只读；
    # switch 是写（改 user.current_workspace_id），系统管理员仍拒绝。
    "ws": {"list", "settings", "members", "rules-review"},
    # L50：分组标签只读动作与 HTTP GET /api/v1/rules/tags 对齐；
    # full-audit 会写审计（属写动作），系统管理员 CLI 拒绝（HTTP POST 同口径 403）。
    "rule-tag": {"list"},
}


def _is_biz_cmd(args) -> bool:
    return str(getattr(args, "cmd", "") or "") in _BIZ_CMDS


def _super_admin_biz_readonly(args, db) -> bool:
    """系统管理员能否执行该 CLI 业务命令（只读口径）。

    S4 收口原则：**白名单只放行真正的只读动作**，任何会写库/写审计的动作一律
    fail-closed 拒绝。带副作用的「读取型」命令必须在这里按参数再判一次
    （``ws settings --patch`` 就是写：``workspaces.save_settings``）。
    """
    cmd = str(getattr(args, "cmd", "") or "")
    if cmd == "manifest":
        # 只允许读已存在的清单；--execute 或清单需要现生成时属于写/执行动作，拒绝。
        if bool(getattr(args, "execute", False)):
            return False
        try:
            from app import repositories as _R
            runs = _R.audit_runs.list("case_id=?", (getattr(args, "case", "") or "",),
                                       order="created_at DESC", limit=1)
            return bool(runs and str(runs[0].get("manifest_id") or "").strip())
        except Exception:
            return False
    if cmd == "ledger":
        # 旧契约 `rp ledger --case/--batch`（对象级台账只读）保留；
        # T-50 新增 list/recover 属双轨业务数据（含隐藏项/恢复写），系统管理员一律拒绝，
        # 与 HTTP /api/v1/suppression-ledger 同口径。
        return not str(getattr(args, "action", "") or "")
    if cmd == "ws":
        # `ws list` 只读；`ws settings` 只有在**不带 --patch** 时才是只读
        # （带 --patch 会调 workspaces.save_settings 落库 + 写审计，属业务写）。
        action = str(getattr(args, "action", "") or "")
        if action == "list":
            return True
        if action == "settings":
            return not bool(str(getattr(args, "patch", "") or "").strip())
        return False
    actions = _SUPER_BIZ_READ.get(cmd)
    if actions is None:
        return False
    return "*" in actions or str(getattr(args, "action", "") or "") in actions


class _CliParser(argparse.ArgumentParser):
    """让 ``--help`` 输出在 Python 3.9 与 3.10+ 下保持逐字节一致。

    argparse 在 3.9 把可选参数分组标题写成 “optional arguments:”，3.10+ 改为
    “options:”。系统自带 ``python3`` 可能仍是 3.9，而 ``./rp`` 会按入口约定选择
    3.10+，两条一等入口的 ``--help`` 因此出现假差异。统一标题后，
    ``./rp --help`` 与 ``python3 -m app.cli --help`` 可直接逐字节比对。
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        try:
            self._optionals.title = "options"
        except Exception:  # pragma: no cover - argparse 内部结构变化时保持可用
            pass

    def error(self, message):
        """L91：argparse 参数错误也必须 stderr JSON + 退出码 2（与全部失败契约一致）。

        旧实现走 argparse 默认行为：打印 usage 文本（非 JSON）再 exit 2；脚本按
        “stderr 是 JSON”解析时会直接失败。这里保留 usage 供人读，放进 JSON 的
        ``detail.usage``，stdout 保持空。
        """
        try:
            usage = self.format_usage().strip()
        except Exception:  # noqa: BLE001
            usage = ""
        out = {"ok": False, "error": str(message), "code": "invalid_arguments",
               "status": 400, "detail": {"usage": usage} if usage else {}}
        print(json.dumps(out, ensure_ascii=False), file=sys.stderr)
        sys.exit(2)


def build_parser():
    p = _CliParser(
        prog="rp",
        description="AI 审核平台 CLI",
        epilog=(
            "入口：./rp <命令> 或 python3 -m app.cli <命令>（等价；./rp 自动选择 Python 3.10+）。\n"
            "输出：成功写 stdout 的 JSON；失败写 stderr 的 JSON 且退出码非 0。\n"
            "退出码为分类码（POSIX 0-255）：2=参数/请求非法，4=无权限(401/403)，"
            "5=对象不存在(404)，6=冲突/前置条件(409/422/428)，7=其它4xx；"
            "真实 HTTP 状态码看 stderr JSON 的 status 字段（403 不截断）。\n"
            "写操作记录审计日志；CLI 与 HTTP API 共用服务层、权限与数据库。"
            "别名命令（不新增顶层命令）：rp extraction verify|confidence-policy 调 L155 "
            "Extractor-Verifier 只读能力；rp report sign|export；rp snapshot show|replay。"
            "规则发布无需审批（draft→published 直接发布；submit/approve 为旧流程 legacy 兼容）；"
            "发布后冲突只提醒（conflict_count/去向），不阻断发布。"
            "完整手册见交付包 docs/CLI手册.md。"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--db", help="SQLite 路径（默认 RULEPROOF_DB）")
    p.add_argument("--tenant", default="t-default", help="租户（默认 t-default）")
    p.add_argument("--ws", default="ws-default", help="工作空间（默认 ws-default）")
    p.add_argument("--user", default=None,
                   help="操作身份：用户 id / 手机号 / 用户名（默认 RULEPROOF_CLI_USER，未设置则 user-admin）")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="初始化数据库与种子")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("serve", help="启动 HTTP 服务")
    s.add_argument("--port", type=int, default=8093)
    s.set_defaults(fn=cmd_serve)

    s = sub.add_parser("ws", help="工作空间：list/create/settings/members/rules-review/switch")
    s.add_argument("action", choices=["list", "create", "settings", "members",
                                      "rules-review", "switch"])
    s.add_argument("--name", default="")
    s.add_argument("--types", default="")
    s.add_argument("--patch", default="")
    s.add_argument("--id", default="", help="switch 的目标空间 ID")
    s.set_defaults(fn=cmd_ws)

    s = sub.add_parser("rule", help="规则（新建后可 draft→published 直接发布，无需审批；submit/approve 为旧流程 legacy 兼容；import=企业标准目录沉淀，仅业务管理员）")
    s.add_argument("action", choices=["list", "create", "publish", "submit", "approve", "archive", "rollback", "restore", "static", "mine", "mechanism", "mechanism-feedback", "drift-report", "repair-drift",
                                     # L170：企业标准目录 → 限值规则草稿（HTTP POST /api/v1/sediment，
                                     # 仅业务管理员；与 HTTP 同服务层 rule.import_from_standards，
                                     # 每命中一条限值生成规则草稿并写既有审计）。
                                     "import",
                                     # P0-5/T-191 D3：判据生成候选池闭环（与 /api/v1/rules/suggest 同源）
                                     "suggest", "suggest-gaps", "suggest-gen", "suggest-confirm",
                                     "suggest-reject", "suggest-shadow", "suggest-publish"])
    s.add_argument("--code", default="", help="规则编码（create 新建编码；生命周期命令与 --id 二选一）")
    s.add_argument("--id", default="", help="规则 ID（生命周期 submit/approve/publish/archive/rollback/restore 可用；与 --code 二选一）")
    s.add_argument("--version", default="")
    s.add_argument("--name", default="")
    s.add_argument("--category", default="")
    s.add_argument("--rclass", default="")
    s.add_argument("--criterion", default="")
    s.add_argument("--metric", default="")
    s.add_argument("--op", default="")
    s.add_argument("--value", default="")
    s.add_argument("--unit", default="")
    s.add_argument("--template", default="")
    s.add_argument("--scope", default="", help="适用文件类型/后缀，如 xlsx")
    s.add_argument("--evidence", default="", help="required_evidence，如 净含量")
    s.add_argument("--publish", action="store_true",
                   help="create 后直接发布（draft→published；无需审批；返回发布后冲突提醒）")
    s.add_argument("--file", default="", help="suggest-gen/--shadow 的 JSON 输入文件（typed schema v1 / 影子用例）")
    s.add_argument("--status", default="", help="suggest 列表状态过滤")
    s.add_argument("--reason", default="", help="suggest-reject 拒绝原因")
    s.add_argument("--limit", type=int, default=20)
    s.add_argument("--catalog", default="seed/mechanisms/p01_catalog.json", help="机制目录 JSON")
    # L170：import（沉淀）的企业标准目录；语义与 HTTP POST /api/v1/sediment body.dir
    # 同源（缺省 config.STANDARDS_DIR；只允许 STANDARDS_DIR 或平台根目录内，越界 403）。
    s.add_argument("--dir", default="",
                   help="import：企业标准 PDF 目录（缺省 RULEPROOF_STANDARDS；只允许标准目录/平台根）")
    s.add_argument("--dry-run", dest="dry_run", action="store_true", default=True,
                   help="repair-drift 只输出计划不写库（默认）")
    s.add_argument("--apply", dest="apply", action="store_true",
                   help="repair-drift 真正修复（写审计，幂等）")
    s.set_defaults(fn=cmd_rule)

    s = sub.add_parser("rule-tag", help="规则分组标签（L50）：list/create/rename/delete/assign/unassign/full-audit；与 HTTP /api/v1/rules/tags 同一服务层（组织分组，不影响 manifest 路由）")
    s.add_argument("action", choices=["list", "create", "rename", "delete", "assign",
                                     "unassign", "full-audit"])
    s.add_argument("--tag", default="", help="标签 id（rename/delete/assign/unassign/full-audit）")
    s.add_argument("--name", default="", help="标签名称（create/rename）")
    s.add_argument("--color", default="", help="标签颜色 #RRGGBB（可选，缺省按名称稳定取色）")
    s.add_argument("--rule", action="append", default=[],
                   help="规则 id/code（assign/unassign 可重复：--rule R1 --rule R2）")
    s.add_argument("--limit", type=int, default=200, help="full-audit 自检条数上限（1~500）")
    s.set_defaults(fn=cmd_rule_tag)

    s = sub.add_parser("doc", help="解析文档；文档类型主数据（doctypes）见 rp doctypes list|last")
    # L170：file 改为可选（只是为了让 `rp doctypes ...` 归一后的隐藏动作不带文件；
    # 普通 `rp doc` 缺文件仍在 cmd_doc 里显式 400=exit2，契约不变）。
    s.add_argument("file", nargs="?", default="")
    s.add_argument("--preview", type=int, default=500)
    # L170：文档类型主数据只读能力（HTTP GET /api/v1/doctypes、/api/v1/doctypes/last）。
    # 一等入口是 `rp doctypes list|last`（main() 的 _l170_product_argv 归一到这里），
    # 不新增顶层命令以保持 web/platform.js CLI_ALL 49 防漂移契约。
    s.add_argument("--types-list", dest="doctypes_list", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--types-last", dest="doctypes_last", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--types-scope", dest="types_scope", default="project",
                   help="doctypes last：project|user（与 HTTP /doctypes/last?scope= 同源）")
    s.add_argument("--types-id", dest="types_id", default="",
                   help="doctypes last：project ID 或 user ID（HTTP ?id=）")
    s.set_defaults(fn=cmd_doc)

    s = sub.add_parser("kie", help="关键信息抽取")
    s.add_argument("--file", default="")
    s.add_argument("--doc-id", dest="doc_id", default="")
    s.add_argument("--type", default="contract", choices=["contract", "bid", "announcement"])
    s.add_argument("--llm", action="store_true")
    # L163：L155 抽取校验只读能力的隐藏动作开关（对外一等入口为 `rp extraction ...`，
    # 由 main() 的 _extraction_argv 归一到这里；不新增顶层命令以保持 CLI_ALL 防漂移）。
    s.add_argument("--input", default="",
                   help="L155 抽取校验 body JSON 文件（- 表示 stdin；配合 rp extraction verify）")
    s.add_argument("--extraction-verify", dest="extraction_verify", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--extraction-policy", dest="extraction_policy", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--no-confidence", dest="no_confidence", action="store_true",
                   help=argparse.SUPPRESS)
    s.set_defaults(fn=cmd_kie)

    s = sub.add_parser("audit", help="跑一次审核")
    s.add_argument("--name", default="CLI 审核")
    s.add_argument("--docs", nargs="+", required=True)
    s.add_argument("--mode", choices=["manual", "assisted", "full"], default="manual",
                   help="manual=客户规则；assisted=项目 AI 辅助；full=已废弃（与 HTTP /reviews 一致返回 400 invalid_mode）")
    s.add_argument("--semantic", action="store_true", help="显式启用语义富集")
    s.add_argument("--type", default="")
    s.set_defaults(fn=cmd_audit)

    s = sub.add_parser("resolve", help="统一 kind + id 解析（含二级 ID）")
    s.add_argument("--kind", required=True,
                   help="case/project/report/rule/document/finding/point/task/"
                        "manifest_result/manifest_evidence/batch")
    s.add_argument("--id", required=True)
    s.set_defaults(fn=cmd_resolve)

    s = sub.add_parser("evidence", help="补证事项")
    s.add_argument("action", choices=["list", "request", "fulfill", "reaudit"])
    s.add_argument("--result", default="")
    s.add_argument("--evidence", default="")
    s.add_argument("--reason", default="")
    s.add_argument("--checklist", default="")
    s.add_argument("--ref", default="")
    s.set_defaults(fn=cmd_evidence)

    s = sub.add_parser("manifest", help="审核清单")
    s.add_argument("--case", required=True)
    s.add_argument("--execute", action="store_true")
    # L53 策略快照读取（对用户暴露为 `rp snapshot show`，由 main() 归一；见 _snapshot_argv）
    s.add_argument("--snapshot-show", dest="snapshot_show", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--run", default="", help="snapshot show：指定 run（缺省取最新快照）")
    s.add_argument("--summary", action="store_true",
                   help="snapshot show：只输出摘要（不含完整快照 JSON）")
    s.add_argument("--verify", action="store_true",
                   help="snapshot show：追加与当前运行配置的一致性校验；"
                        "snapshot replay：只校验不重跑")
    # L61 历史快照重放（对用户暴露为 `rp snapshot replay`，由 main() argv 归一）
    s.add_argument("--snapshot-replay", dest="snapshot_replay",
                   action="store_true", help=argparse.SUPPRESS)
    s.add_argument("--snapshot", dest="snapshot_id", default="",
                   help="snapshot replay：期望的快照 id（缺省=run 的已保存快照）")
    # L98 P1：`rp snapshot replay --cleanup` 清理 replay 派生临时 run/工件
    #   （默认 dry-run；--apply 执行；保留策略 keep-days/keep-last，历史有效 run 不删）
    s.add_argument("--cleanup", action="store_true", help=argparse.SUPPRESS)
    s.add_argument("--apply", action="store_true",
                   help="snapshot replay --cleanup：真正执行清理（缺省只 dry-run）")
    s.add_argument("--keep-days", dest="keep_days", type=int, default=7,
                   help="snapshot replay --cleanup：保留最近 N 天内的 replay run（默认 7）")
    s.add_argument("--keep-last", dest="keep_last", type=int, default=1,
                   help="snapshot replay --cleanup：每案例保留最近 N 个 replay run（默认 1）")
    s.set_defaults(fn=cmd_manifest)

    s = sub.add_parser("ledger", help="审核台账：旧对象级 --case/--batch；T-50 抑制台账 list/recover")
    s.add_argument("action", nargs="?", default="",
                   choices=["", "list", "recover"],
                   help="list=抑制台账列表；recover=人工从抑制池恢复（写审计）；省略=旧对象级台账")
    s.add_argument("--case", default="")
    s.add_argument("--batch", default="")
    s.add_argument("--ledger", default="", help="抑制台账 id（recover，如 sl_xxx）")
    s.add_argument("--status", default="", help="list 状态过滤（suppressed/recovered）")
    s.add_argument("--source", default="", help="list 来源过滤（direct/platform/both）")
    s.add_argument("--reason", default="", help="recover 原因（必填，写审计）")
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--offset", type=int, default=0)
    s.set_defaults(fn=cmd_ledger)

    s = sub.add_parser(
        "adjudication-ledger",
        help="裁决来源台账（L80 / P0-C）：stats/export；与 HTTP /adjudication-stats、"
             "/adjudication-ledger 同服务层/权限/审计（开关 RULEPROOF_ADJUDICATION_LEDGER 默认 0）")
    s.add_argument("action", choices=["stats", "export"], help="stats=统计；export=逐行+统计+SHA256SUMS")
    s.add_argument("--case", default="", help="项目 id（与 --run 至少给一个）")
    s.add_argument("--run", default="", help="审核批次 run id")
    s.add_argument("--group-by", default="", help="统计分组：adjudicator,document,rule_type（逗号分隔）")
    s.add_argument("--out", default="", help="export 输出目录")
    s.add_argument("--format", default="csv", choices=["csv", "json"], help="export 逐行格式（默认 csv）")
    s.set_defaults(fn=cmd_adjudication_ledger)
    s = sub.add_parser("point", help="点位模板确认 / 平台审核点位库（与 HTTP /api/v1/audit-points 同源）")
    s.add_argument("action", choices=["list", "confirm", "revoke", "stale", "prepare", "activate",
                                      # L91：补齐 HTTP 已有点位动作（库/选项/确认/路由/执行/推荐）
                                      "library", "options", "confirmations", "route",
                                      "execute", "recommended",
                                      # L170：审计分类元数据（HTTP GET /api/v1/audit-categories）
                                      "categories"])
    s.add_argument("--point-id", default="")
    s.add_argument("--workspace-id", default="")
    s.add_argument("--case", default="")
    s.add_argument("--criterion", default="")
    s.add_argument("--tier", default="S2", help="route 的层级（默认 S2）")
    s.add_argument("--families", default="", help="route 的规则族（逗号分隔）")
    s.add_argument("--point-json", dest="point_json", default="",
                   help="execute 的审核点 JSON（字符串或 @文件路径，字段同 HTTP body.point）")
    s.add_argument("--text", default="", help="execute 的待审原文")
    s.add_argument("--text-file", dest="text_file", default="",
                   help="execute 从文件读取待审原文（UTF-8）")
    s.set_defaults(fn=cmd_point)

    s = sub.add_parser("artifacts", help="四件语义交付物导出")
    s.add_argument("--case", required=True)
    s.add_argument("--out", default="")
    s.set_defaults(fn=cmd_artifacts)

    s = sub.add_parser("semantic", help="确定性语义闭环：结构化根因 / 同案例重审")
    s.add_argument("action", choices=["root-cause", "reaudit"])
    s.add_argument("--finding", default="")
    s.add_argument("--case", default="")
    s.add_argument("--run", default="")
    s.add_argument("--rules", default="")
    s.add_argument("--activate", action="store_true")
    s.add_argument("--reason", default="")
    s.set_defaults(fn=cmd_semantic)

    s = sub.add_parser("task", help="异步任务")
    s.add_argument("action", choices=["list", "show", "cancel"])
    s.add_argument("--id", default="")
    s.add_argument("--limit", type=int, default=30)
    s.set_defaults(fn=cmd_task)

    s = sub.add_parser("project", help="项目")
    s.add_argument("action", choices=["list", "show", "create",
                                      # L170：审核员「我的审核」（HTTP GET /api/v1/my-audits）
                                      "my-audits"])
    s.add_argument("--case", default="")
    # L163：project create —— 与 HTTP POST /api/v1/projects 同一服务层 project.create，
    # 同一权限点 project.create（仅审核员），同一审计 project.created。
    s.add_argument("--name", default="", help="create：项目名称")
    s.add_argument("--description", default="", help="create：项目说明")
    s.add_argument("--audit-type", dest="audit_type", default="", help="create：审核类型")
    s.add_argument("--focus", default="", help="create：审核重点")
    s.add_argument("--audit-category", dest="audit_category", default="",
                   help="create：审核类别")
    s.add_argument("--document-type", dest="document_type", default="",
                   help="create：文件类型（受工作空间类型范围约束）")
    # L170：my-audits 分页/筛选（与 HTTP GET /api/v1/my-audits?status&q&from&to&page&page_size
    # 同一服务层 project.my_audits，同一空态/汇总字段口径）。
    s.add_argument("--status", default="", help="my-audits：项目状态筛选")
    s.add_argument("--q", default="", help="my-audits：关键词（项目名/ID）")
    s.add_argument("--from", dest="date_from", default="", help="my-audits：起始日期 YYYY-MM-DD")
    s.add_argument("--to", dest="date_to", default="", help="my-audits：结束日期 YYYY-MM-DD")
    s.add_argument("--page", type=int, default=1, help="my-audits：页码（默认 1）")
    s.add_argument("--page-size", dest="page_size", type=int, default=20,
                   help="my-audits：每页条数（默认 20，上限 100）")
    s.set_defaults(fn=cmd_project)

    s = sub.add_parser("finding", help="发现")
    s.add_argument("action", choices=["list", "decide", "add",
                                      # L170：问题分析统计（HTTP GET /api/v1/analytics/issues）
                                      "analytics"])
    # None 表示未显式传 --case；decide 允许只按 finding ID 判定。
    s.add_argument("--case", default=None)
    s.add_argument("--finding", default="")
    s.add_argument("--days", type=int, default=30,
                   help="analytics：统计窗口天数（默认 30，1-365，与 HTTP ?days= 同源）")
    # L148/T-③：与 HTTP 四态同源（确认/误报/退回补证/忽略）；ignored 是 L132 G12 缺口。
    s.add_argument("--decision", default="confirmed",
                   choices=["confirmed", "false_positive", "need_evidence", "ignored"])
    s.add_argument("--reason", default="",
                   help="裁决原因：false_positive/need_evidence/ignored 必填（与 HTTP 同源）")
    s.add_argument("--title", default="")
    s.add_argument("--severity", default="warning", choices=["critical", "warning", "suspected"])
    s.add_argument("--detail", default="")
    s.add_argument("--locator", default="")
    s.add_argument("--quote", default="")
    s.add_argument("--document", default="")
    s.set_defaults(fn=cmd_finding)

    s = sub.add_parser("extra", help="Extra 人工复核")
    s.add_argument("action", choices=["decide"])
    s.add_argument("--rule-code", dest="rule_code", required=True)
    s.add_argument("--decision", choices=["confirm", "false_positive"], required=True)
    s.add_argument("--quote", default="")
    s.add_argument("--reason", default="")
    s.add_argument("--case", default="")
    s.set_defaults(fn=cmd_extra)

    s = sub.add_parser("human-review", help="人工复核闭环（展示项 100%% 复核/漏报对账/报告门禁）")
    s.add_argument("action", choices=["show", "status", "queue", "decide", "omit",
                                      "omissions", "reconcile", "backend", "prepare"])
    s.add_argument("--case", required=True, help="项目 ID")
    s.add_argument("--item", default="", help="展示项 item_id（decide）")
    s.add_argument("--decision", default="",
                   help="裁决：confirmed_direct_true/confirmed_platform_true/confirmed_both_true/"
                        "direct_false_positive/platform_false_positive/both_false/"
                        "evidence_insufficient/rule_or_route_error")
    s.add_argument("--reason", default="", help="裁决原因（否定类裁决必填）")
    s.add_argument("--label", default="")
    s.add_argument("--quote", default="", help="漏报证据原文（证据，必填）")
    s.add_argument("--issue", default="", help="漏报问题描述（必填）")
    s.add_argument("--locator", default="", help="漏报位置（JSON 或文本；必填）")
    s.add_argument("--rule-hint", dest="rule_hint", default="")
    s.add_argument("--subject", default="")
    s.add_argument("--object-id", dest="object_id", default="")
    s.add_argument("--note", default="")
    s.add_argument("--status", default="", help="omissions 状态过滤")
    s.add_argument("--doc-text-file", dest="doc_text_file", default="",
                   help="prepare 的原文（用于直连草稿 quote 回查/平台证据核验）")
    s.add_argument("--include-hidden", dest="include_hidden", action="store_true",
                   help="显示隐藏疑似问题（显式打开，写 reveal 审计；默认关闭）")
    s.set_defaults(fn=cmd_human_review)

    s = sub.add_parser(
        "hidden-item",
        help="人工‘显示隐藏疑似问题 (N)’开关：list/裁决/恢复/指标/复核模式/进化池")
    s.add_argument("action", choices=["list", "confirm", "reject",
                                      "request-evidence", "recover", "merge",
                                      "rule-error", "metrics", "mode",
                                      "submit-independent", "evolution-defaults",
                                      "enqueue"])
    s.add_argument("--case", default="", help="项目 ID（除 metrics 外必填）")
    s.add_argument("--item", default="", help="隐藏项 ID（hidden_item_id/sl_xxx）")
    s.add_argument("--reason", default="", help="裁决原因（否定/补证/恢复/合并/规则错误必填）")
    s.add_argument("--into", default="", help="merge 目标可见项 comparison_item id")
    s.add_argument("--reveal", action="store_true",
                   help="list 时打开隐藏区（写 reveal 审计；默认关闭）")
    s.add_argument("--include-hidden", dest="include_hidden", action="store_true",
                   help="等价 --reveal（显式打开隐藏区）")
    s.add_argument("--note", default="")
    s.add_argument("--mode", default="", choices=["", "production", "evaluation"],
                   help="mode 设置为指定复核模式；缺省读取当前模式")
    s.add_argument("--force", action="store_true",
                   help="mode=production 时强制回退 evaluation 锁（仅业务管理员；必须配 --reason，写审计）")
    s.add_argument("--ttl-days", dest="ttl_days", type=int,
                   default=30, help="evolution-defaults 的 TTL 天数（默认 30）")
    s.add_argument("--dry-run", dest="dry_run", action="store_true",
                   help="evolution-defaults 只预览不写")
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--offset", type=int, default=0)
    s.set_defaults(fn=cmd_hidden_item)

    # ---------------- T-50（W-14）V3.2 双轨数据产品命令（HTTP 同源） ----------------
    s = sub.add_parser("direct-draft", help="直连草稿（不可变原始输出）列表/详情；与 /api/v1/direct-drafts 同源")
    s.add_argument("action", choices=["list", "show"])
    s.add_argument("--case", default="", help="项目 ID（list 过滤 / show 由 draft 反查）")
    s.add_argument("--draft", default="", help="直连草稿 id（show）")
    s.add_argument("--run", default="", help="直连 run_id（show；与 --draft 二选一）")
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--offset", type=int, default=0)
    s.set_defaults(fn=cmd_direct_draft)

    s = sub.add_parser("compare", help="双轨四桶差异列表/详情；与 /api/v1/comparisons 同源")
    s.add_argument("action", choices=["list", "show"])
    s.add_argument("--case", default="", help="项目 ID（list 过滤）")
    s.add_argument("--item", default="", help="比对项 item_id（show）")
    s.add_argument("--bucket", default="", help="both/direct_only/platform_only/conflict")
    s.add_argument("--visibility", default="", help="visible/duplicate/suppressed/hidden/unset")
    s.add_argument("--human-status", dest="human_status", default="",
                   help="unreviewed/confirmed_* 等人工裁决状态")
    s.add_argument("--doc-text-file", dest="doc_text_file", default="",
                   help="show 的原文（平台 finding 证据回查用）")
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--offset", type=int, default=0)
    s.set_defaults(fn=cmd_compare)

    s = sub.add_parser("visibility", help="可见性策略应用状态；与 /api/v1/visibility 同源")
    s.add_argument("action", choices=["show"])
    s.add_argument("--case", required=True, help="项目 ID")
    s.set_defaults(fn=cmd_visibility)

    s = sub.add_parser("omission", help="人工漏报 add/list；与 /api/v1/human-omissions 同源")
    s.add_argument("action", choices=["add", "list"])
    s.add_argument("--case", default="", help="项目 ID（add 必填；list 可作为过滤）")
    s.add_argument("--quote", default="", help="证据原文（add 必填）")
    s.add_argument("--issue", default="", help="问题描述（add 必填）")
    s.add_argument("--locator", default="", help="位置（JSON 或文本；add 必填）")
    s.add_argument("--rule-hint", dest="rule_hint", default="")
    s.add_argument("--subject", default="")
    s.add_argument("--object-id", dest="object_id", default="")
    s.add_argument("--note", default="")
    s.add_argument("--status", default="", help="list 状态过滤")
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--offset", type=int, default=0)
    s.set_defaults(fn=cmd_omission)

    s = sub.add_parser("report", help="报告：导出 / 签发（sign）/ 按报告 ID 导出（export）")
    s.add_argument("case", nargs="?", default="", help="项目 ID（旧用法：生成并导出报告）")
    # L94：`rp report sign|export`（由 main() 的 _report_argv 归一为隐藏动作开关）
    s.add_argument("--report-sign", dest="report_sign", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--report-export", dest="report_export", action="store_true",
                   help=argparse.SUPPRESS)
    s.add_argument("--id", dest="report_id", default="",
                   help="报告 ID（sign/export 必填）")
    s.add_argument("--content-hash", dest="content_hash", default="",
                   help="sign：期望的报告内容 hash（sha256:...）；不一致 → 409 content_hash_mismatch")
    s.add_argument("--note", default="", help="sign：签发备注（写 signatures_json/审计，≤200 字）")
    s.add_argument("--format", default="html")
    s.add_argument("--out", default="")
    s.add_argument("--accept-parse-gaps", action="store_true", help="显式接受解析缺口（写审计日志）")
    s.add_argument("--accept-unknown", action="store_true",
                   help="逐对象接受当前 run 的 unknown（必须配合 --result-id；禁止批量）")
    s.add_argument("--result-id", dest="result_id", default="",
                   help="对象级 result_id（unknown-candidates 的 binding.result_id）")
    s.add_argument("--result-hash", dest="result_hash", default="",
                   help="对象级 result_hash（可选；与服务器 binding 不一致→409 stale_hash）")
    s.add_argument("--run-id", dest="run_id", default="",
                   help="对象所属审核批次（可选；非当前批次→409 stale_run）")
    s.add_argument("--reason", default="", help="接受 unknown 的理由（必填，写审计）")
    s.add_argument("--allow-ungated-csv", action="store_true", help="显式允许未过门禁的 CSV 原始发现导出")
    s.set_defaults(fn=cmd_report)

    s = sub.add_parser("exception", help="对象级例外授权（unknown 逐项接受，禁止批量）")
    s.add_argument("action", choices=["list", "accept"])
    s.add_argument("--case", required=True)
    s.add_argument("--result-id", dest="result_id", default="")
    s.add_argument("--result-hash", dest="result_hash", default="")
    s.add_argument("--run-id", dest="run_id", default="")
    s.add_argument("--reason", default="")
    s.set_defaults(fn=cmd_exception)

    s = sub.add_parser("export", help="数据导出（CSV，与 HTTP export 同源）")
    s.add_argument("kind", choices=["projects", "findings", "audit-records", "audit-logs"])
    s.add_argument("--case", default="", help="findings 导出必须指定")
    s.add_argument("--from", dest="date_from", default="")
    s.add_argument("--to", dest="date_to", default="")
    s.add_argument("--reviewer", default="")
    s.add_argument("--out", default="", help="写入文件；缺省输出 CSV 到 stdout")
    s.set_defaults(fn=cmd_export)

    s = sub.add_parser("open", help="开放平台")
    s.add_argument("action", choices=["apps", "create", "test", "events", "deliver",
                                      "sandbox", "update", "rotate", "task"])
    s.add_argument("--id", default="")
    s.add_argument("--name", default="")
    s.add_argument("--callback", default="")
    s.add_argument("--events", default="")
    s.add_argument("--sandbox", action="store_true")
    s.add_argument("--status", default="")
    s.set_defaults(fn=cmd_open)

    s = sub.add_parser("model", help="模型：list/set/config/points/effective/test")
    s.add_argument("action", choices=["list", "set", "config", "points", "effective", "test"])
    s.add_argument("--id", default="")
    s.add_argument("--default", action="store_true")
    s.set_defaults(fn=cmd_model)

    s = sub.add_parser("user", help="账号；me=本人身份/权限自查；change-password 为自助改密（任意登录身份）")
    s.add_argument("action", choices=["list", "create", "reset-password", "change-password",
                                      # L170：本人身份自查（HTTP GET /api/v1/me、
                                      # /api/v1/me/permissions）；一等入口 rp me。
                                      "me"])
    s.add_argument("--permissions", action="store_true",
                   help="me：同时输出角色权限视图（等价 HTTP GET /api/v1/me/permissions）")
    s.add_argument("--id", default="")
    s.add_argument("--username", default="")
    s.add_argument("--name", default="")
    s.add_argument("--role", default="")
    s.add_argument("--phone", default="")
    s.add_argument("--email", default="")
    s.add_argument("--password", default="")
    s.add_argument("--old-password", default="", help="自助改密：原密码")
    s.add_argument("--new-password", default="", help="自助改密：新密码（复杂度同密码策略）")
    # L163：user list 分页/筛选（与 HTTP GET /api/v1/users?page&page_size&q&role&status
    # 同一服务层 account.list_users_page；不带这些参数时保持旧的全量列表语义）。
    s.add_argument("--page", type=int, default=0, help="list：页码（≥1，触发分页）")
    s.add_argument("--page-size", dest="page_size", type=int, default=0,
                   help="list：每页条数（5-100，默认 20）")
    s.add_argument("--q", default="", help="list：关键词（姓名/手机号/邮箱）")
    s.add_argument("--status", default="", help="list：状态筛选（如 active）")
    s.set_defaults(fn=cmd_user)

    s = sub.add_parser("tenant", help="平台租户治理：租户/租户管理员/平台管理员生命周期；branding=公开品牌")
    s.add_argument("action", choices=["list", "create", "admin-list", "admin-add", "admin-status",
                                      "admin-reset",
                                      # L91：补齐 HTTP /api/v1/platform 已有受控动作
                                      "update", "status", "delete",
                                      "admin-update", "admin-delete",
                                      # L170：登录页/平台公开品牌（HTTP GET
                                      # /api/v1/public/tenant-branding，公开读）
                                      "branding"])
    s.add_argument("--id", default="", help="租户 ID（update/status/delete）或平台管理员 ID（admin-update/admin-delete）")
    s.add_argument("--code", default="")
    s.add_argument("--name", default="")
    s.add_argument("--tenant-id", dest="tenant_id", default="")
    s.add_argument("--admin-id", dest="admin_id", default="")
    s.add_argument("--status", default="")
    s.add_argument("--edition", choices=["trial", "formal"], default="trial")
    s.add_argument("--expires-at", dest="expires_at", default="")
    s.add_argument("--admin-name", dest="admin_name", default="")
    s.add_argument("--admin-phone", dest="admin_phone", default="")
    s.add_argument("--admin-pwd", dest="admin_pwd", default="")
    s.add_argument("--phone", default="")
    s.add_argument("--email", default="")
    s.add_argument("--password", default="")
    s.set_defaults(fn=cmd_tenant)

    s = sub.add_parser("decision", help="决策表")
    s.add_argument("action", choices=["list", "show", "evaluate", "create", "update", "publish"])
    s.add_argument("--code", default="")
    s.add_argument("--name", default="")
    s.add_argument("--rules", default="")
    s.add_argument("--rules-file", dest="rules_file", default="")
    s.add_argument("--hit-policy", dest="hit_policy", default="first")
    s.add_argument("--facts", default="{}")
    # P1-B3-03：与 HTTP 求值同源同参 —— 灰度用例必须能指定 case_id，
    # 适用范围用例必须能指定 audit_type（否则 CLI 测出来永远 match）。
    s.add_argument("--audit-type", dest="audit_type", default="",
                   help="求值时按业务文档类型判定适用范围（与 HTTP body.audit_type 同源）")
    s.add_argument("--case-id", dest="case_id", default="",
                   help="求值时按案例 ID 做灰度分流（与 HTTP body.case_id 同源）")
    s.add_argument("--publish", action="store_true")
    s.set_defaults(fn=cmd_decision)

    s = sub.add_parser("ontology", help="本体建模：读取/资产 CRUD/发布/快照/开关/影响面")
    s.add_argument("action", choices=["show", "versions", "validate", "status", "discover",
                                      "add-term", "threshold",
                                      # L91：补齐 HTTP /api/v1/ontology 既有动作
                                      "impact", "capabilities", "snapshot", "publish",
                                      "switch", "entity-create", "entity-update",
                                      "entity-delete", "alias-create", "alias-update",
                                      "alias-delete", "link-create", "link-delete"])
    s.add_argument("--canonical", default="")
    s.add_argument("--aliases", default="")
    s.add_argument("--type", "--type-key", dest="type", default="",
                   help="实体类型 key（entity-create/link 源类型）")
    s.add_argument("--evidence", default="")
    s.add_argument("--threshold", type=int, default=10)
    s.add_argument("--id", default="", help="实体/别名/关系 ID（update/delete）或本体版本 ID（publish）")
    s.add_argument("--name", default="", help="实体名称（entity-create/entity-update）")
    s.add_argument("--props", default="", help="实体属性 JSON 对象（entity-create/update）")
    s.add_argument("--alias", default="", help="别名文本（alias-create/alias-update）")
    s.add_argument("--status", default="",
                   help="别名状态（alias-update：approved/proposed/rejected）")
    s.add_argument("--entity-id", dest="entity_id", default="", help="别名归属实体（alias-create）")
    s.add_argument("--key", default="", help="关系类型 key（link-create，默认 produced_by）")
    s.add_argument("--source-id", dest="source_id", default="", help="关系源实体（link-create）")
    s.add_argument("--target-id", dest="target_id", default="", help="关系目标实体（link-create）")
    s.add_argument("--term", default="", help="影响面查询术语（impact）")
    s.add_argument("--workspace-id", dest="workspace_id", default="",
                   help="目标空间（capabilities/switch；缺省用 --ws）")
    s.add_argument("--mode", default="", help="本体执行模式（switch）")
    s.add_argument("--enabled", dest="enabled", action="store_true", help="打开本体（switch）")
    s.add_argument("--disabled", dest="disabled", action="store_true", help="关闭本体（switch）")
    s.add_argument("--reason", default="", help="开关变更原因（switch，写审计）")
    s.set_defaults(fn=cmd_ontology)

    s = sub.add_parser("terms", help="企业业务词典：查看/维护/确认/迁移")
    s.add_argument("action", choices=["list", "create", "update", "delete", "confirm", "migrate"])
    s.add_argument("--id", "--term-id", dest="term_id", default="",
                   help="术语 ID（update/delete/confirm）")
    s.add_argument("--name", default=None, help="术语标准名（create/update）")
    s.add_argument("--definition", default=None, help="术语定义，至少 4 字（create/update）")
    s.add_argument("--synonyms", default=None,
                   help="同义词：逗号分隔或 JSON 数组（create/update）")
    s.add_argument("--not-equal", dest="not_equal", default=None,
                   help="不等同词：逗号分隔或 JSON 数组（create/update）")
    s.add_argument("--source", default=None, help="术语来源（create/update）")
    s.add_argument("--scope", default=None, help="术语适用范围（create/update）")
    s.add_argument("--key", default=None, help="术语唯一 key；缺省由名称生成（create/update）")
    s.add_argument("--entity-type", dest="entity_type", default=None,
                   help="本体实体类型（create/update）")
    s.add_argument("--unit", default=None, help="单位（create/update）")
    s.add_argument("--relations", default=None, help="关系 JSON 数组（create/update）")
    s.add_argument("--reason", default="", help="delete 删除原因（写入审计）")
    s.add_argument("--workspace-id", dest="workspace_id", default="",
                   help="工作空间 ID；省略时用全局 --ws（默认 ws-default）")
    s.add_argument("--dry-run", dest="dry_run", action="store_true",
                   help="migrate 预演：事务回滚，不写业务数据")
    s.add_argument("--all-spaces", dest="all_spaces", action="store_true",
                   help="list/migrate 作用于当前租户全部工作空间（不可与 --workspace-id 同用）")
    s.add_argument("--status", default="", help="list 按状态过滤（draft/candidate/confirmed/active）")
    s.set_defaults(fn=cmd_terms)

    s = sub.add_parser("knowledge",
                       help="知识库：文件夹/文件列表、上传、重命名/移动、回收站、彻底删除"
                            "（与 HTTP /api/v1/knowledge 同源）")
    s.add_argument("action", choices=["list", "folders", "files", "upload", "rename",
                                      "move", "delete", "recycle", "restore", "purge"])
    s.add_argument("--id", default="", help="文件/文件夹 ID（rename/move/delete/restore/purge）")
    s.add_argument("--kind", choices=["file", "folder"], default="file",
                   help="对象类型（默认 file）")
    s.add_argument("--name", default="", help="新名称（rename）")
    s.add_argument("--file", default="", help="本地文件路径（upload）")
    s.add_argument("--folder-id", dest="folder_id", default="",
                   help="文件夹 ID（files 过滤 / upload 归属 / move 目标；空=根目录）")
    s.add_argument("--confirm", action="store_true",
                   help="purge 二次确认（彻底删除不可恢复）")
    s.set_defaults(fn=cmd_knowledge)

    s = sub.add_parser("notify-config", help="消息事件/可见角色配置")
    s.add_argument("action", choices=["get", "save"])
    s.add_argument("--config", default="{}")
    s.set_defaults(fn=cmd_notify_config)

    s = sub.add_parser("data-policy", help="数据边界策略：状态/配置/删除预览/删除执行")
    s.add_argument("action", choices=["status", "get", "set", "purge-preview",
                                      "purge-execute"])
    s.add_argument("--set", dest="sets", action="append", default=[], metavar="KEY=VALUE",
                   help="保存单个策略字段（可重复），如 --set region=cn-shanghai")
    s.add_argument("--config", default="{}", help="一次性保存多个字段（JSON 对象）")
    s.add_argument("--yes", action="store_true", help="set 写操作确认")
    s.add_argument("--token", "--preview-token", dest="token", default="",
                   help="purge-execute 的预览凭证（来自 purge-preview）")
    s.add_argument("--confirm", default="", help="真实删除的二次确认文本：确认删除")
    s.add_argument("--execute", action="store_true",
                   help="purge-execute 真实删除（默认 dry-run 0 删除；仅系统管理员）")
    s.add_argument("--workspace-id", dest="workspace_id", default="",
                   help="删除预览/执行的限定工作空间（省略=整租户；必须属于账号租户，"
                        "预览与执行范围必须一致）")
    s.set_defaults(fn=cmd_data_policy)

    s = sub.add_parser("notifications", help="站内消息；alerts=主动告警（HTTP GET /api/v1/alerts）")
    s.add_argument("action", choices=["list", "read", "read-all",
                                      # L170：主动告警（与 HTTP GET /api/v1/alerts 同源）
                                      "alerts"])
    s.add_argument("--id", default="")
    s.add_argument("--unread", action="store_true")
    s.add_argument("--limit", type=int, default=50)
    s.set_defaults(fn=cmd_notifications)

    s = sub.add_parser("agent", help="智能体（全系统）")
    s.add_argument("action", choices=["list", "show", "versions", "run"])
    s.add_argument("--id", default="")
    s.add_argument("--payload", default="{}")
    s.set_defaults(fn=cmd_agent)

    s = sub.add_parser("evolution", help="规则进化：历史回放/效果趋势/回滚建议/空间准确率看板；errorbook/feedback=误报库与复核反馈闭环")
    s.add_argument("action", choices=["replay", "trend", "rollback",
                                      "accuracy", "accuracy-record", "coldstart",
                                      # L170：误报库（HTTP GET /api/v1/errorbook）与复核反馈
                                      # 闭环（HTTP GET /api/v1/feedback、/feedback/mine、
                                      # POST /feedback/<id>/settle）。一等入口：
                                      # rp evolution errorbook / rp feedback list|mine|settle。
                                      "errorbook", "feedback-list", "feedback-mine",
                                      "feedback-settle"])
    s.add_argument("--feedback-id", dest="feedback_id", default="",
                   help="feedback-settle：反馈 ID（HTTP POST /api/v1/feedback/<id>/settle）")
    s.add_argument("--feedback-action", dest="feedback_action", default="revise",
                   choices=["revise", "new_rule", "ignore", "reject", "false_positive"],
                   help="feedback-settle：处置动作（默认 revise，与 HTTP body.action 同源）")
    s.add_argument("--note", default="", help="feedback-settle：处置备注")
    s.add_argument("--auto-publish", dest="auto_publish", action="store_true",
                   help="feedback-settle：沉淀后立即发布（默认只生成草稿，与 HTTP 同源）")
    s.add_argument("--kind", default="", help="feedback-list：反馈类型过滤（confirm/false_positive/...）")
    s.add_argument("--status", default="", help="feedback-list：反馈状态过滤（pending/settled/...）")
    s.add_argument("--offset", type=int, default=0, help="errorbook：偏移量（与 HTTP ?offset= 同源）")
    s.add_argument("--rule", "--code", dest="rule", default="", help="规则编码或规则 ID")
    s.add_argument("--version", default="", help="回放/趋势截至的规则版本（缺省为最新）")
    s.add_argument("--limit", type=int, default=200, help="最多回放多少条历史已复核样本")
    # T-177：空间准确率看板（真实评测结果落库；空态不伪造）
    s.add_argument("--docs", default="",
                   help="accuracy-record：逐文档混淆计数 JSON，如 "
                        '[{"case_id":"c1","doc":"d1","tp":2,"fp":0,"fn":1}]')
    s.add_argument("--label", default="", help="accuracy-record：轮次标签")
    s.add_argument("--source", default="", help="accuracy-record：数据来源（eval_harness/manual_gold）")
    s.add_argument("--rule-count", dest="rule_count", type=int, default=0,
                   help="accuracy-record：本轮生效规则数（缺省自动数本空间 published 规则）")
    s.add_argument("--notes", default="", help="accuracy-record：备注")
    s.set_defaults(fn=cmd_evolution)

    s = sub.add_parser("auditlog", help="审计日志（只读）；export=审计导出（默认关闭）")
    s.add_argument("action", nargs="?", default="list",
                   choices=["list", "export", "export-config"],
                   help="list=查询（默认）/ export=导出 / export-config=导出开关变更")
    s.add_argument("--q", default="")
    s.add_argument("--result", default="")
    s.add_argument("--action", dest="action_filter", default="")
    s.add_argument("--actor", default="")
    s.add_argument("--date-from", dest="date_from", default="")
    s.add_argument("--date-to", dest="date_to", default="")
    s.add_argument("--limit", type=int, default=20)
    s.add_argument("--offset", type=int, default=0)
    # T-201 审计导出（默认关闭；仅 super_admin/platform_op；敏感操作需二次确认）
    s.add_argument("--format", default="csv", choices=["csv", "jsonl"],
                   help="导出格式（csv/jsonl）")
    s.add_argument("--out", default="", help="导出文件路径（缺省写系统临时目录）")
    s.add_argument("--confirm", action="store_true",
                   help="二次确认（export/export-config 必填）")
    s.add_argument("--enable", action="store_true", help="export-config：开启导出")
    s.add_argument("--disable", action="store_true", help="export-config：关闭导出")
    s.add_argument("--scope", default="platform", choices=["platform", "workspace"],
                   help="export-config 配置作用域（默认平台级）")
    s.set_defaults(fn=cmd_auditlog)

    # T-203 影子池产品化 Phase 2：与 HTTP /api/v1/projects/{cid}/shadow-items* 同源
    s = sub.add_parser(
        "shadow",
        help="影子池（三区仲裁）：list/reveal/decide/metrics/export/escalate；与 HTTP 同源")
    s.add_argument("action", choices=["list", "reveal", "decide", "metrics",
                                      "export", "escalate"],
                   help="list=默认只给 N；reveal=打开明细（写审计）；decide=四动作裁决；"
                        "metrics=指标；export=导出（仅业务管理员）；escalate=系统二次复核")
    s.add_argument("--case", default="",
                   help="项目 ID（escalate 可传多个，逗号/空格分隔）")
    s.add_argument("--item", default="", help="影子项 ID（decide，如 shi_xxx）")
    s.add_argument("--action", dest="decide_action", default="",
                   help="decide 动作：confirm|false-positive|unsure|skip")
    s.add_argument("--reason", default="", help="理由过滤（list）/ 升级原因（escalate）")
    s.add_argument("--status", default="",
                   help="list 状态过滤（pending/confirmed/false_positive/unsure/skipped/escalated）")
    s.add_argument("--reveal", action="store_true",
                   help="list 时打开明细（等价 reveal；写 reveal 审计）")
    s.add_argument("--include-hidden", dest="include_hidden", action="store_true",
                   help="等价 --reveal")
    s.add_argument("--exclude-discarded", dest="exclude_discarded", action="store_true",
                   help="export 不含 discarded 留痕（默认包含：discarded 也要可审计导出）")
    s.add_argument("--confirm", action="store_true",
                   help="reveal 二次确认（必须显式给出；写审计）")
    s.add_argument("--note", default="", help="decide/reveal 备注（写审计）")
    s.add_argument("--format", default="json", choices=["json", "csv"],
                   help="export 格式（默认 json）")
    s.add_argument("--out", default="", help="export 写入文件路径（缺省输出 stdout）")
    s.add_argument("--rounds", type=int, default=2, help="escalate 最大复核轮次（默认 2）")
    s.add_argument("--older-than-hours", dest="older_than_hours", type=int, default=72,
                   help="escalate 多久未动作才升级（小时，默认 72）")
    s.add_argument("--dry-run", dest="dry_run", action="store_true",
                   help="escalate 只统计不写库")
    s.add_argument("--system", action="store_true",
                   help="escalate 以调度系统身份执行（需 RULEPROOF_SCHEDULER_TOKEN；"
                        "人类角色一律 403）")
    s.set_defaults(fn=cmd_shadow)

    s = sub.add_parser("version", help="版本信息；capabilities/dashboard=系统能力与 KPI（只读）")
    # L170：`rp capabilities` / `rp dashboard` 归一到这里（不新增顶层命令）。
    s.add_argument("--capabilities", action="store_true",
                   help="输出系统能力（HTTP GET /api/v1/system/capabilities 只读）")
    s.add_argument("--dashboard", action="store_true",
                   help="输出全局 KPI（HTTP GET /api/v1/dashboard 只读；仅业务/系统管理员）")
    s.set_defaults(fn=cmd_version)

    s = sub.add_parser("doctor", help="CLI 环境自检")
    s.set_defaults(fn=cmd_doctor)

    s = sub.add_parser("gate", help="运行构建门禁")
    s.set_defaults(fn=cmd_gate)

    # T-164 / 评审 C-4：冲突检测状态。老库升级后首次报告会被门禁阻断，
    # `rp conflict-check run` 跑一次全量检测即解除（并在 conflict_check 留状态）。
    s = sub.add_parser("conflict-check",
                       help="冲突检测状态：run=全量检测并落状态 / status=最近记录")
    s.add_argument("action", nargs="?", default="run", choices=["run", "status"])
    s.add_argument("--limit", type=int, default=20, help="status 返回最近 N 条（默认 20）")
    s.set_defaults(fn=cmd_conflict_check)

    s = sub.add_parser("db", help="数据库")
    s.add_argument("action", choices=["backup", "restore", "migrate"])
    s.add_argument("--out", default="")
    s.add_argument("--from", dest="source", default="", help="restore 的来源备份")
    s.add_argument("--backup-dir", default="", help="备份目录（migrate/restore）")
    s.add_argument("--dry-run", action="store_true", help="migrate 只检查不写库")
    s.add_argument("--yes", action="store_true", help="restore 确认覆盖")
    s.set_defaults(fn=cmd_db)
    return p


def main(argv=None):
    # L53：`rp snapshot show ...` 归一为 manifest 的只读快照读取（保持 build_parser()
    # 子命令集合不变，避免与 web/platform.js CLI_ALL 的防漂移契约冲突）。
    if argv is None:
        argv = sys.argv[1:]
    argv = _snapshot_argv(argv)
    # L94：`rp report sign|export` 归一为 report 命令的隐藏动作开关（命令集合不变）
    argv = _report_argv(argv)
    # L163：`rp extraction verify|confidence-policy` 归一为 kie 的隐藏动作开关
    # （命令集合不变，保持 web/platform.js CLI_ALL 防漂移契约）。
    argv = _extraction_argv(argv)
    # L170：`rp doctypes|me|feedback|alerts|capabilities|dashboard` 归一为既有命令的
    # 隐藏动作/子动作（保持 49 顶层命令契约；见 _l170_product_argv）。
    argv = _l170_product_argv(argv)
    args = build_parser().parse_args(argv)
    # ---------------- L91 P0：--db 必须在任何 app.* 导入之前生效 ----------------
    # app.db.DB_PATH 在 import 时固化；旧流程先 import app.services 再 setenv，
    # 导致 --db 永远无效（未设 RULEPROOF_DB 时读命令会打到产品库）。这里先解析。
    _db_expected = _apply_global_db(args)
    args._db_expected = _db_expected
    # 成功命令 stderr 不混第三方库 Python warning（只影响已知依赖告警）。
    _silence_third_party_warnings()
    # L91 P1：只读命令不执行 init_db/迁移（version/list/show/backup...）。
    _need_init = _needs_db_init(args)
    # L77（build49 P0，90 号 §二-3）：生产环境禁止回退杆（SINGLE_ENTRY_FIX=0 /
    # SNAPSHOT_V3=0）。启动期 fail-fast：可读配置错误写 stderr + 退出码 2，
    # 先于 DB 初始化与任何业务动作；非 prod 仅 warning（审计在 _boot 后补写）。
    try:
        from .services import single_entry as _se_guard
    except Exception:  # noqa: BLE001 - 守卫模块不可用不阻断（保持旧行为并留痕）
        _se_guard = None
        logging.getLogger(__name__).debug("single_entry startup guard unavailable",
                                          exc_info=True)
    if _se_guard is not None:
        try:
            # L94：写命令的“非 prod warning+审计”改到 _boot（init_db）之后 —— 旧实现
            # 在 DB 建表前就调用守卫，回退杆审计因 audit_log 不存在而静默丢失（且被
            # 每进程去重集合标记为已写，之后不再补写）。这里只做 prod fail-fast；
            # 只读命令仍按 L91 只 warning、不写库/不审计。
            if _se_guard.is_prod() or not _need_init:
                _se_guard.assert_production_switches(emit_audit=False)
        except _se_guard.ConfigError as _cfg_exc:
            print(json.dumps(_cfg_exc.to_dict(), ensure_ascii=False), file=sys.stderr)
            sys.exit(2)
    # db migrate 是数据层变更入口：先备份，再跑既有 init_db，最后执行版本化迁移。
    # 这样即使 init_db 的轻量加列先执行，也已有可回滚的 SQLite 快照。
    # L91：--dry-run 是“只检查不写库”，不得建表、不得产生整库备份（L89 CLI 缺口）。
    if getattr(args, "cmd", "") == "db" and getattr(args, "action", "") == "migrate" \
            and not bool(getattr(args, "dry_run", False)):
        _db_path = _db_expected
        # P1-05：迁移前备份 = 整库导出（含全部租户数据），必须先确认操作者是
        # super_admin，不能先备份再在 cmd_db 里拒绝（否则越权请求仍能拿到整库文件）。
        if os.path.exists(_db_path):
            _ident = (args.user or os.environ.get("RULEPROOF_CLI_USER")
                      or "user-admin")
            if _peek_db_role(_db_path, _ident) != "super_admin":
                _err("无权限：数据库备份/恢复/迁移仅系统管理员（super_admin）可执行",
                     403, err_code="forbidden")
        try:
            from app.services import db_backup as _bk
            if os.path.exists(_db_path):
                _pre = _bk.backup(_db_path,
                                  backup_dir=(getattr(args, "backup_dir", "") or None),
                                  label="pre-cli-migrate")
                print(json.dumps({"ok": True, "pre_migrate_backup": _pre["backup"]},
                                 ensure_ascii=False), file=sys.stderr)
        except Exception as e:  # noqa: BLE001
            _err(f"迁移前备份失败：{type(e).__name__}: {e}", 1,
                 err_code="backup_failed")
    db = _boot(args, init=_need_init)
    # L77：非 prod 回退杆使用留痕（prod 已在启动守卫 fail-fast；每进程每种组合一次）。
    # L91：只读命令不写审计（否则“只读不改库”不成立）。
    # L94：写命令在 init_db 之后才 warning+审计（表已就绪，审计不会再因 no such table 丢失）。
    if _se_guard is not None and _need_init:
        try:
            _se_guard.assert_production_switches(emit_audit=True)
        except _se_guard.ConfigError:  # prod 已在启动期 fail-fast；此处不应出现
            logging.getLogger(__name__).warning("rollback lever prod guard raised after boot",
                                                exc_info=True)
        except Exception:  # noqa: BLE001 - 审计留痕失败不阻断 CLI（已 warning）
            logging.getLogger(__name__).debug("rollback lever audit skipped",
                                              exc_info=True)
    try:
        # 系统管理员业务边界与 HTTP 同口径（B）：只读查看放行，写业务/有副作用动作仍 403。
        # 之前 CLI 对全部业务命令一刀切 403，与 HTTP GET 只读 200 形成两套口径（F4/F9）。
        from .services import account as _acc
        if getattr(args, "cmd", "") not in ("init", "serve", "version", "doctor", "gate"):
            _uid0 = _user_id(args, db)
            _roles0 = set(_acc.roles_of(_uid0) or [])
            if "super_admin" in _roles0 and _is_biz_cmd(args):
                if not _super_admin_biz_readonly(args, db):
                    _err("系统管理员不访问审核业务（只读查看可加 --user <业务身份> 执行写操作）",
                         403, err_code="forbidden")
            # 平台运营与 HTTP 同口径：平台身份不可访问业务接口（F4 补充）。
            _role0 = _cli_actor(args, db)[1].get("role") or ""
            if _role0 == "platform_op" and _is_biz_cmd(args):
                _err("平台身份不可访问业务接口", 403, err_code="forbidden")
        args.fn(args, db)
    except SystemExit:
        raise
    except Exception as e:
        _err(f"{type(e).__name__}: {e}")

if __name__ == "__main__":
    main()
