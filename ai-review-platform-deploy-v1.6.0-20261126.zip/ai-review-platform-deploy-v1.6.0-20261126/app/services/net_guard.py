"""出站 URL 安全校验：每次投递前重新解析，拒绝环回/私网/链路本地/元数据地址。

注意：这是“使用前重新校验”，仍不能彻底消除 DNS-rebinding 的 TOCTOU；
彻底方案是解析一次后直接连接固定 IP 并保留 Host/SNI，需要独立网络层。
"""
from __future__ import annotations
import ipaddress
import socket
from urllib.parse import urlparse


def check_url(url: str, allow_loopback: bool = False) -> tuple[bool, str]:
    try:
        u = urlparse(str(url or "").strip())
    except Exception:
        return False, "URL 非法"
    if u.scheme not in ("http", "https") or not u.hostname:
        return False, "只允许 http/https 地址"
    host = u.hostname
    try:
        ips = [ipaddress.ip_address(host)]
    except Exception:
        try:
            ips = [ipaddress.ip_address(x[4][0]) for x in socket.getaddrinfo(host, None)]
        except Exception:
            return False, "域名无法解析"
    for ip in ips:
        if ip.is_loopback:
            if allow_loopback:
                continue
            return False, "不允许环回地址"
        if ip.is_private or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return False, "不允许内网/链路本地地址"
    return True, ""


class _PinnedHTTPSConnection:
    """HTTPS 固定 IP 连接，仍用原 host 做 SNI/证书校验。

    实现要点（P2-18 回归修复）：
    - HTTPSConnection.connect() 会调用 ``self._create_connection(address, timeout,
      source_address)``（位置/关键字参数随 Python 版本略有差异，3.12 为 3 个位置
      参数）；覆盖实现必须接受这些参数，否则真实 HTTPS 请求会 TypeError。
    - 覆盖层只替换 TCP 目标为“已校验 IP”，host/port 仍用原始构造参数：SNI、
      证书 hostname 校验、Host 头都继续按原域名，安全语义不变。
    - 单次解析：request_url 已解析并校验过 IP，这里不再解析域名。
    """
    def __init__(self, host: str, ip: str, port: int, timeout: float, context):
        import http.client as _hc
        self._conn = _hc.HTTPSConnection(host, port, timeout=timeout, context=context)
        self._ip = ip
        self._host = host
        self._port = port
        self._timeout = timeout

    def _pinned_create_connection(self, address=None, timeout=None, source_address=None):
        """http.client 的 _create_connection 契约：连接固定 IP，不再解析域名。"""
        import socket as _socket
        return _socket.create_connection(
            (self._ip, self._port),
            self._timeout if timeout is None else timeout,
            source_address,
        )

    def request(self, method, path, body=None, headers=None):
        conn = self._conn
        # 只替换 TCP 目标，Host/SNI 仍为原域名；签名兼容 http.client 的调用契约。
        conn._create_connection = self._pinned_create_connection
        if headers is not None:
            headers.setdefault("Host", self._host)
        return conn.request(method, path, body=body, headers=headers)

    def getresponse(self):
        return self._conn.getresponse()

    def close(self):
        return self._conn.close()


def request_url(url: str, body: bytes = b"", headers: dict = None, timeout: float = 8,
                allow_loopback: bool = False):
    """安全请求：先解析/校验，再直接连接已校验 IP；返回 (status, response_bytes)。

    HTTPS 仍以原 hostname 做 SNI 和证书校验；HTTP 设置 Host 头。
    """
    import http.client as _hc
    import ssl as _ssl
    from urllib.parse import urlparse
    u = urlparse(str(url or ""))
    if u.scheme not in ("http", "https") or not u.hostname:
        raise ValueError("只允许 http/https 地址")
    host = u.hostname
    port = u.port or (443 if u.scheme == "https" else 80)
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except Exception as exc:
        raise ValueError("域名无法解析") from exc
    ips = []
    for info in infos:
        ip = info[4][0]
        if ip not in ips:
            ips.append(ip)
    for ip in ips:
        ipobj = ipaddress.ip_address(ip)
        if ipobj.is_loopback:
            if allow_loopback:
                continue
            raise ValueError("不允许环回地址")
        if ipobj.is_private or ipobj.is_link_local or ipobj.is_reserved or ipobj.is_multicast:
            raise ValueError("不允许内网/链路本地地址")
    if not ips:
        raise ValueError("域名无法解析")
    # 选择第一个已校验 IP，之后不再解析域名
    ip = ips[0]
    path = (u.path or "/") + (("?" + u.query) if u.query else "")
    hs = dict(headers or {})
    hs.setdefault("Host", host + (f":{port}" if (u.scheme == "http" and port != 80) or (u.scheme == "https" and port != 443) else ""))
    if u.scheme == "https":
        ctx = _ssl.create_default_context()
        conn = _PinnedHTTPSConnection(host, ip, port, timeout, ctx)
        try:
            conn.request("POST", path, body=body, headers=hs)
            resp = conn.getresponse()
            return resp.status, resp.read()
        finally:
            conn.close()
    conn = _hc.HTTPConnection(ip, port, timeout=timeout)
    try:
        conn.request("POST", path, body=body, headers=hs)
        resp = conn.getresponse()
        return resp.status, resp.read()
    finally:
        conn.close()
