# -*- coding: utf-8 -*-
"""双轨/影子五机制**唯一对外入口** gateway（T-202，2026-11-20）。

## 为什么需要它

双轨/影子链路上有五套机制（``direct_draft`` / ``visibility_policy`` /
``suppression_ledger`` / ``shadow_pool`` / ``accuracy_shadow``），历史演进中各自都能
“决定某条发现是否可见/进哪个区”，导致同一件事有 2–3 条实现路径、口径漂移。本模块
**不删除旧机制**（不做大迁移），而是把职责固化成一条主链，并把**唯一对外 API** 收到
这里：产品代码只允许经本 gateway 调用这五套机制做“可见性/分区/标注”决策。

## 唯一主链（顺序不可变）

::

    直连发现 / 平台 finding
      │
      ├─① direct_draft            不可变原件（raw_response 只能追加，不裁决）
      │
      ├─② shadow_pool.classify()  唯一仲裁：formal / shadow / discarded
      │                           （R1–R4；formal 不落库 = 不在 shadow_item 表）
      │
      ├─③ visibility_policy       仅策略：证据/反证/风险判定（返回决策，不落库、不分区）
      │
      ├─④ suppression_ledger      仅台账：已裁决抑制（抑制≠删除，可恢复，写审计）
      │
      └─⑤ accuracy_shadow         只读标注：只给 finding 标 shadow_coverage，不参与分区

职责边界（硬约束，测试见 ``scripts/qa/dual_track_gateway_test.py`` B 组）：

| 机制 | 唯一职责 | 允许决定 zone？ | 允许决定可见性？ | 落库 |
|---|---|---|---|---|
| direct_draft | 不可变原件（直连原始输出 + 条目） | 否 | 否 | 是（只 INSERT） |
| shadow_pool | **唯一仲裁** formal/shadow/discarded | **是（唯一）** | 隐含（zone 决定报告口径） | 是（shadow_item） |
| visibility_policy | 策略：证据/反证/风险/校准分支（纯函数） | 否 | 否（只给策略决策，供仲裁/台账消费） | 否 |
| suppression_ledger | 台账：已裁决抑制/恢复/抽样对账 | 否 | 否（只记账，不重新判可见性） | 是（ledger） |
| accuracy_shadow | 只读标注：shadow_coverage=covered/missing | 否 | 否 | 仅标注字段/审计 |

## 对外 API 分组

- 元信息：:func:`main_chain` / :func:`responsibilities` / :data:`MAIN_CHAIN`
- ① 原件：:func:`direct_draft_source` / :func:`direct_draft_list` /
  :func:`direct_draft_get` / :func:`direct_draft_items` / :func:`direct_draft_stats`
- ② 仲裁：:func:`classify`（+ gateway 元信息）/ :func:`record_arbitration` /
  :func:`report_partition` / :func:`formal_finding_ids` / :func:`finding_zone`
- ③ 策略：:func:`resolve_visibility` / :func:`resolve_comparison_visibility` /
  :func:`visibility_candidate_from_direct` / :func:`visibility_candidate_from_platform` /
  :func:`policy_snapshot` / :func:`policy_version` / :func:`is_high_risk_text` /
  :func:`reason_codes` / :func:`high_risk_keywords`
- ④ 台账：:func:`apply_case_visibility` / :func:`apply_comparison_visibility` /
  :func:`suppress_decision` / :func:`ledger_list` / :func:`ledger_get` /
  :func:`ledger_recover` / :func:`ledger_hidden_summary` / :func:`ledger_stats` /
  :func:`ledger_record_human_result`；人工漏报面 :func:`omission_list` /
  :func:`omission_get` / :func:`omission_record` / :func:`omission_reconcile` /
  :func:`omission_reconcile_pending` / :func:`feedback_candidates`
- ⑤ 标注：:func:`shadow_recall` / :func:`route_repair` / :func:`coverage_mark_enabled` /
  :func:`accuracy_mode`

## 约束（可执行）

`scripts/qa/dual_track_gateway_test.py` 用 AST 扫描 ``app/**/*.py``：白名单
（本 gateway + 五套机制自身 + 离线评测 ``cross_review.py``）之外，**0 处**直接
import/调用五套机制的“决策函数”。新增调用方必须走本 gateway，或在测试里显式
登记白名单并写清下线计划（见 ``docs/qa/双轨唯一入口约束_20261120.md``）。

## 兼容

所有包装函数默认**原样透传返回值**（除 :func:`classify` / :func:`resolve_visibility`
/ :func:`resolve_comparison_visibility` 额外附加 ``gateway`` 元信息键），因此旧调用方
行为不变（5 场景对比见测试 E 组）；不做数据库变更、不新增表、不改审计事件。
"""
from __future__ import annotations

import logging
import os

GATEWAY_VERSION = "dual-track-gateway/v1"
GATEWAY_SCHEMA = "dual-track-gateway/v1"
MAIN_CHAIN_SCHEMA = "dual-track-main-chain/v1"

# 机制 → 代码位置（文档/测试共用；改文件必须同步这里）
MECHANISM_FILES = {
    "direct_draft": "app/services/direct_draft.py",
    "shadow_pool": "app/services/shadow_pool.py",
    "visibility_policy": "app/services/visibility_policy.py",
    "suppression_ledger": "app/services/suppression_ledger.py",
    "accuracy_shadow": "app/services/accuracy_shadow.py",
}

# 唯一主链（有序）：step / mechanism / role / decides_zone / decides_visibility
MAIN_CHAIN = (
    {"step": 1, "name": "source", "mechanism": "direct_draft",
     "role": "不可变原件（原始响应只追加，不裁决）",
     "decides_zone": False, "decides_visibility": False, "storage": "direct_draft/direct_item"},
    {"step": 2, "name": "arbitrate", "mechanism": "shadow_pool",
     "role": "唯一仲裁 formal/shadow/discarded（R1–R4）",
     "decides_zone": True, "decides_visibility": True,
     "storage": "shadow_item（formal 不落库）"},
    {"step": 3, "name": "policy", "mechanism": "visibility_policy",
     "role": "仅策略：证据/反证/风险/校准分支（纯函数，不落库）",
     "decides_zone": False, "decides_visibility": False, "storage": "无（纯函数）"},
    {"step": 4, "name": "ledger", "mechanism": "suppression_ledger",
     "role": "仅台账：已裁决抑制/恢复/抽样对账（抑制≠删除）",
     "decides_zone": False, "decides_visibility": False, "storage": "suppression_ledger"},
    {"step": 5, "name": "annotate", "mechanism": "accuracy_shadow",
     "role": "只读标注：shadow_coverage=covered/missing（不参与分区决策）",
     "decides_zone": False, "decides_visibility": False,
     "storage": "finding 标注字段 + 审计"},
)

RESPONSIBILITIES = {
    "direct_draft": {
        "role": "不可变原件", "is_source": True, "unique_arbiter": False,
        "decides_zone": False, "decides_visibility": False,
        "may_write": ["direct_draft", "direct_item"],
        "must_not": ["决定可见性", "分区裁决", "按 gold 调序"],
        "offline_only": False,
    },
    "shadow_pool": {
        "role": "唯一仲裁（formal/shadow/discarded）", "is_source": False,
        "unique_arbiter": True, "decides_zone": True, "decides_visibility": True,
        "may_write": ["shadow_item"],
        "must_not": ["把 formal 写进 shadow_item", "物理删除影子项", "自动写人工结论"],
        "offline_only": False,
    },
    "visibility_policy": {
        "role": "策略（证据/反证/风险/校准）", "is_source": False,
        "unique_arbiter": False, "decides_zone": False, "decides_visibility": False,
        "may_write": ["confidence_calibration"],
        "must_not": ["自己决定分区/可见性", "落库隐藏态", "自动抑制（Phase 1 关闭）"],
        "offline_only": False,
    },
    "suppression_ledger": {
        "role": "台账（已裁决抑制/恢复）", "is_source": False,
        "unique_arbiter": False, "decides_zone": False, "decides_visibility": False,
        "may_write": ["suppression_ledger", "human_omission"],
        "must_not": ["重新判可见性", "物理删除台账", "改原始主张"],
        "offline_only": False,
    },
    "accuracy_shadow": {
        "role": "只读标注（shadow_coverage）", "is_source": False,
        "unique_arbiter": False, "decides_zone": False, "decides_visibility": False,
        "may_write": ["finding 标注/候选回填（增强层）"],
        "must_not": ["推翻主链结论", "静默移出 finding", "绕过 manifest 冻结"],
        "offline_only": False,
    },
}


def main_chain() -> dict:
    """唯一主链元信息（文档/测试/健康检查共用，纯数据）。"""
    return {
        "gateway": GATEWAY_VERSION,
        "schema": MAIN_CHAIN_SCHEMA,
        "steps": [dict(x) for x in MAIN_CHAIN],
        "order": tuple(x["name"] for x in MAIN_CHAIN),
        "mechanisms": tuple(x["mechanism"] for x in MAIN_CHAIN),
        "rule": ("直连发现 → direct_draft（原件）→ shadow_pool.classify（唯一仲裁）"
                 "→ visibility_policy（仅策略）→ suppression_ledger（仅台账）"
                 "→ accuracy_shadow（只读标注）"),
        "constraint": ("产品代码禁止直接 import 五套机制的决策函数；只能经 "
                       "app.services.dual_track_gateway 调用"),
        "not_gold": True,
    }


def responsibilities() -> dict:
    """五套机制职责表（只读副本）。"""
    return {k: dict(v) for k, v in RESPONSIBILITIES.items()}


def mechanism_files() -> dict:
    return dict(MECHANISM_FILES)


# ===========================================================================
# 懒加载：避免 import 环 + 只在真正调用时加载底层模块
# ===========================================================================
def _dd():
    from . import direct_draft as _m
    return _m


def _sp():
    from . import shadow_pool as _m
    return _m


def _vp():
    from . import visibility_policy as _m
    return _m


def _sl():
    from . import suppression_ledger as _m
    return _m


def _ash():
    from . import accuracy_shadow as _m
    return _m


def _gateway_meta(mechanism: str, step: str, **extra) -> dict:
    out = {"gateway": GATEWAY_VERSION, "mechanism": mechanism, "chain_step": step}
    out.update(extra)
    return out


# ===========================================================================
# ① 原件：direct_draft（不可变原始输出 + 条目，只读）
# ===========================================================================
#: 直连草稿表名（消费方不要直接 import direct_draft）
DIRECT_DRAFT_TABLE = "direct_draft"
DIRECT_ITEM_TABLE = "direct_item"
#: 三区常量（消费方不要直接 import shadow_pool）
ZONE_FORMAL = "formal"
ZONE_SHADOW = "shadow"
ZONE_DISCARDED = "discarded"
ZONES = (ZONE_FORMAL, ZONE_SHADOW, ZONE_DISCARDED)
#: 台账表名（消费方不要直接 import suppression_ledger）
LEDGER_TABLE = "suppression_ledger"
OMISSION_TABLE = "human_omission"
#: 影子池审计事件（“审计事件不变”断言用）
SHADOW_AUDIT_EVENTS = ("shadow.added", "shadow.revealed", "shadow.decided",
                       "shadow.escalated", "shadow.purged")


def direct_draft_source(conn, case_id: str) -> dict:
    """取一个项目的直连原件（草稿 + 条目），供主链第 1、3 步消费。

    返回 ``{drafts, items, run_id, draft_id, case_id}``；无草稿时 drafts/items 为空，
    不抛异常（调用方按需报 400，与改造前一致）。
    """
    dd = _dd()
    cid = str(case_id or "").strip()
    drafts = list(dd.list_drafts(conn, case_id=cid) or [])
    items, run_id, draft_id = [], "", ""
    for draft in drafts:
        items.extend(dd.get_items(conn, draft["id"]) or [])
        run_id = run_id or str(draft.get("run_id") or "")
        draft_id = draft_id or str(draft.get("id") or "")
    return {"case_id": cid, "drafts": drafts, "items": items,
            "run_id": run_id, "draft_id": draft_id}


def direct_draft_list(conn, case_id: str = "") -> list:
    return _dd().list_drafts(conn, case_id=str(case_id or ""))


def direct_draft_get(conn, draft_id: str = "", run_id: str = "") -> dict:
    return _dd().get_draft(conn, draft_id=str(draft_id or ""),
                           run_id=str(run_id or ""))


def direct_draft_items(conn, draft_id: str) -> list:
    return _dd().get_items(conn, str(draft_id or ""))


def direct_draft_stats(conn, case_id: str = "") -> dict:
    return _dd().draft_stats(conn, case_id=str(case_id or ""))


# ===========================================================================
# ② 唯一仲裁：shadow_pool.classify（formal/shadow/discarded）
# ===========================================================================
def classify(finding_like: dict | None, platform_finding: dict | None = None,
             direct_finding: dict | None = None) -> dict:
    """**唯一仲裁入口**：候选 → ``formal | shadow | discarded``（R1–R4 透传）。

    返回值在底层结论上追加 ``gateway`` 元信息（不覆盖任何原键）：
    ``{gateway, mechanism: "shadow_pool", chain_step: "arbitrate", unique_arbiter: True}``。
    """
    out = dict(_sp().classify(finding_like, platform_finding, direct_finding) or {})
    out["gateway"] = _gateway_meta("shadow_pool", "arbitrate", unique_arbiter=True,
                                   role="unique_arbiter")
    return out


def record_arbitration(finding_id, reason: str, *, case_id: str = "",
                       source: str = "", confidence="", item: dict | None = None,
                       run_id: str = "", actor: str = "system:shadow_pool",
                       role: str = "", platform_finding: dict | None = None,
                       direct_finding: dict | None = None,
                       claim_key: str = "") -> dict:
    """把仲裁结论落库（shadow / discarded 留痕；透传 ``shadow_pool.to_shadow``）。

    ``formal`` 不落库（不在 shadow_item 表 = formal），调用方直接按 formal 处理。
    ``claim_key`` 是跨轮可复算的 claim 幂等键（不在场时退回 direct_item id 口径）。
    """
    return _sp().to_shadow(finding_id, reason, confidence=confidence, source=source,
                           case_id=case_id, item=item, run_id=run_id, actor=actor,
                           role=role, platform_finding=platform_finding,
                           direct_finding=direct_finding, claim_key=str(claim_key or ""))


def report_partition(case_id: str) -> dict:
    """报告口径分区统计（formal / shadow / discarded；内部只读，无 actor 可调）。"""
    return _sp().report_stats(str(case_id or ""))


def formal_finding_ids(case_id: str) -> list:
    return _sp().formal_finding_ids(str(case_id or ""))


def finding_zone(finding_id: str) -> str:
    return _sp().finding_zone(str(finding_id or ""))


def formal_excluded_finding_ids(case_id: str) -> list:
    return _sp().formal_excluded_finding_ids(str(case_id or ""))


# ---------------------------------------------------------------------------
# ②-b 影子池读取/裁决/指标/导出/二次复核（T-203 Phase 2 产品入口经此透传）
# ---------------------------------------------------------------------------
# 说明：``shadow_items`` / ``decide`` / ``shadow_export`` / ``shadow_metrics`` /
# ``escalate_pending`` / ``purge`` 都是 shadow_pool 的**产品读写入口**（不是分区
# 决策函数，但仍在 gateway 白名单约束下统一出口，见 docs/qa/双轨唯一入口约束_20261120.md）。
# HTTP（app/api/shadow_routes.py）与 CLI（app/cli.py rp shadow *）只允许经本 gateway
# 调用，禁止直接 import shadow_pool，从而保持"唯一入口"约束的 F 组断言为 0 违规。
def shadow_items(case_id: str, **kwargs) -> dict:
    return _sp().shadow_items(str(case_id or ""), **kwargs)


def shadow_item(case_id: str, item_id: str, **kwargs) -> dict:
    return _sp().shadow_item(str(case_id or ""), str(item_id or ""), **kwargs)


def decide(case_id: str, item_id: str, action: str, **kwargs) -> dict:
    return _sp().decide(str(case_id or ""), str(item_id or ""), action, **kwargs)


def shadow_metrics(case_id: str = "", **kwargs) -> dict:
    return _sp().shadow_metrics(str(case_id or ""), **kwargs)


def shadow_export(case_id: str, **kwargs) -> dict:
    return _sp().shadow_export(str(case_id or ""), **kwargs)


def escalate_pending(case_ids, **kwargs) -> dict:
    return _sp().escalate_pending(case_ids, **kwargs)


def purge(case_id: str = "", **kwargs) -> dict:
    return _sp().purge(str(case_id or ""), **kwargs)


def shadow_constants() -> dict:
    """影子池只读常量快照（状态/动作/理由/文案），供 HTTP/CLI/前端文案同源。"""
    sp = _sp()
    return {
        "zones": tuple(sp.ZONES), "zone_sources": tuple(sp.ZONE_SOURCES),
        "zone_source_labels": dict(sp.ZONE_SOURCE_LABELS),
        "shadow_reasons": tuple(sp.SHADOW_REASONS),
        "reason_labels": dict(sp.REASON_LABELS),
        "statuses": tuple(sp.SHADOW_STATUSES),
        "status_labels": dict(sp.STATUS_LABELS),
        "open_statuses": tuple(sp.OPEN_STATUSES),
        "resolved_statuses": tuple(sp.RESOLVED_STATUSES),
        "decide_actions": tuple(sp.DECIDE_ACTIONS),
        "action_labels": dict(sp.ACTION_LABELS),
        "warning": sp.SHADOW_WARNING,
        "export_permission": sp.EXPORT_PERMISSION,
        "export_default_roles": tuple(sp.EXPORT_DEFAULT_ROLES),
        "default_escalation_rounds": sp.DEFAULT_ESCALATION_ROUNDS,
        "default_escalation_hours": sp.DEFAULT_ESCALATION_HOURS,
    }


# ===========================================================================
# ③ 仅策略：visibility_policy（证据/反证/风险；返回决策，不落库、不分区）
# ===========================================================================
def policy_version() -> str:
    return str(_vp().POLICY_VERSION)


def policy_snapshot(policy=None) -> dict:
    """策略配置快照（替代调用方 ``visibility_policy.PolicyConfig()``）。"""
    policy = policy or _vp().PolicyConfig()
    return dict(policy.as_dict())


def default_policy():
    """默认策略配置对象（仅离线实验/显式策略需要；产品代码优先用快照）。"""
    return _vp().PolicyConfig()


def resolve_visibility(candidate: dict, *, side: str = "direct", policy=None,
                       calibration: dict | None = None) -> dict:
    """**唯一策略入口**：候选 → 可见性**策略决策**（不落库、不决定分区）。

    - ``side="direct"`` → ``visibility_policy.evaluate_direct``（D0–D5）
    - ``side="platform"`` → ``visibility_policy.evaluate_platform``（P0–P6）

    返回值原样透传，追加 ``gateway`` 元信息：
    ``{role: "strategy_only", decides_zone: False, decides_visibility: False}``。
    """
    vp = _vp()
    side = str(side or "direct").strip().lower()
    if side == "direct":
        out = dict(vp.evaluate_direct(candidate, policy, calibration) or {})
    elif side == "platform":
        out = dict(vp.evaluate_platform(candidate, policy, calibration) or {})
    else:
        raise ValueError(f"非法 side：{side}（可选 direct/platform）")
    out["gateway"] = _gateway_meta(
        "visibility_policy", "policy", role="strategy_only",
        decides_zone=False, decides_visibility=False, side=side)
    return out


def resolve_comparison_visibility(record: dict, *, policy=None,
                                  calibration_map: dict | None = None,
                                  context: dict | None = None) -> dict:
    """四桶比对记录 → 双方策略决策 + 记录级可见性建议（透传 evaluate_comparison）。

    注意：记录级 ``visibility`` 只是**策略建议**，真正落库/承认为可见性状态必须走
    第 ④ 步 :func:`apply_comparison_visibility`（台账/比对项状态）。
    """
    out = dict(_vp().evaluate_comparison(record, policy=policy,
                                         calibration_map=calibration_map,
                                         context=context) or {})
    out["gateway"] = _gateway_meta(
        "visibility_policy", "policy", role="strategy_only",
        decides_zone=False, decides_visibility=False, side="comparison")
    return out


def visibility_candidate_from_direct(item: dict, **overrides) -> dict:
    return _vp().candidate_from_direct_item(item, **overrides)


def visibility_candidate_from_platform(finding: dict, bucket: str = "",
                                       **overrides) -> dict:
    return _vp().candidate_from_platform_finding(finding, bucket=bucket, **overrides)


def is_high_risk_text(text: str) -> bool:
    """高风险类别关键词（与 visibility_policy._HIGH_RISK_KEYWORDS 同源，只读）。"""
    kw = tuple(_vp()._HIGH_RISK_KEYWORDS)  # noqa: SLF001 - gateway 是唯一允许的消费方
    return any(k in str(text or "") for k in kw)


def high_risk_keywords() -> tuple:
    return tuple(_vp()._HIGH_RISK_KEYWORDS)  # noqa: SLF001


def reason_codes() -> dict:
    """可见性原因码表（只读副本；消费方不要 import visibility_policy）。"""
    return dict(_vp().REASON_CODES)


def hidden_reason_codes() -> tuple:
    return tuple(_vp().HIDDEN_REASON_CODES)


# ===========================================================================
# ④ 仅台账：suppression_ledger（已裁决抑制；抑制≠删除，可恢复）
# ===========================================================================
def apply_case_visibility(conn, case_id: str, **kwargs) -> dict:
    """对一个 case 的全部比对项应用可见性策略并落台账（透传，行为不变）。"""
    return _sl().apply_case_visibility(conn, str(case_id or ""), **kwargs)


def apply_comparison_visibility(conn, comparison_item_id: str, **kwargs) -> dict:
    return _sl().apply_comparison_visibility(conn, str(comparison_item_id or ""), **kwargs)


def suppress_decision(conn, **kwargs) -> dict:
    """把策略的隐藏决策落进台账（仅 ledger=True 的决策；透传）。"""
    return _sl().suppress_decision(conn, **kwargs)


def ledger_list(conn, case_id: str = "", source: str = "", status: str = "",
                sampled: bool | None = None, run_id: str = "") -> list:
    return _sl().list_ledger(conn, case_id=str(case_id or ""), source=source,
                             status=status, sampled=sampled, run_id=run_id)


def ledger_get(conn, ledger_id: str) -> dict:
    return _sl().get(conn, str(ledger_id or ""))


def ledger_recover(conn, ledger_id: str, **kwargs) -> dict:
    return _sl().recover(conn, str(ledger_id or ""), **kwargs)


def ledger_hidden_summary(conn, case_id: str = "") -> str:
    return _sl().hidden_summary_text(conn, case_id=str(case_id or ""))


def ledger_record_human_result(conn, ledger_id: str, result: str, **kwargs) -> dict:
    return _sl().record_human_result(conn, str(ledger_id or ""), result, **kwargs)


def ledger_stats(conn, case_id: str = "") -> dict:
    return _sl().stats(conn, case_id=str(case_id or ""))


# 人工漏报对账（suppression_ledger 的 human_omission 面；仍属“台账”，不决定可见性）
def omission_list(conn, case_id: str = "", status: str = "") -> list:
    return _sl().list_omissions(conn, case_id=str(case_id or ""), status=str(status or ""))


def omission_get(conn, omission_id: str) -> dict:
    return _sl().get_omission(conn, str(omission_id or ""))


def omission_record(conn, **kwargs) -> dict:
    return _sl().record_omission(conn, **kwargs)


def omission_reconcile(conn, omission_id: str, **kwargs) -> dict:
    return _sl().reconcile_omission(conn, str(omission_id or ""), **kwargs)


def omission_reconcile_pending(conn, case_id: str, **kwargs) -> dict:
    return _sl().reconcile_pending(conn, str(case_id or ""), **kwargs)


def feedback_candidates(conn, case_id: str = "") -> list:
    return _sl().list_feedback_candidates(conn, case_id=str(case_id or ""))


# ===========================================================================
# ⑤ 只读标注：accuracy_shadow（shadow_coverage；不参与分区决策）
# ===========================================================================
def accuracy_mode() -> dict:
    ash = _ash()
    return {"mode": ash.mode(), "mode_name": ash.mode_name(),
            "enabled": bool(ash.enabled()),
            "coverage_mark": bool(ash.coverage_mark_enabled()),
            "validator": bool(ash.validator_enabled()),
            "anchor": bool(ash.anchor_enabled()),
            "route_repair": bool(ash.route_repair_enabled())}


def coverage_mark_enabled() -> bool:
    return bool(_ash().coverage_mark_enabled())


def route_repair(manifest_out: dict) -> dict:
    """路由补齐（manifest 被路由丢掉的规则交给影子层补召回；透传）。"""
    return _ash().route_repair(manifest_out)


def shadow_recall(case_id: str, docs: list, items: list, collected: list, *,
                  run_id: str = "", route_ctx: dict | None = None) -> dict:
    """影子召回 + 验证/归并 + **只读覆盖标注**（透传 accuracy_shadow.recall）。

    这是标注器唯一入口：增强层可以补候选/标 shadow_coverage，不得推翻主链结论。
    """
    return _ash().recall(case_id, docs, items, collected,
                         run_id=run_id, route_ctx=route_ctx)


# ===========================================================================
# ⑥ Phase 3：直连发现作为主链发现源（发现源接入，不是裁决）
# ===========================================================================
# 背景（P1-7）：``direct_draft`` 原件能力已存在，但只有离线脚本在调用；主链
# ``project.audit`` 完成后从不生成直连草稿 → 生产库 direct_draft/direct_item 恒 0 行，
# 三区仲裁/影子池拿不到「直连独有发现」，L1（平台不低于直连）无从验证。
# 本段把「直连模型 → 不可变原件」这一步收进唯一入口：调用方（project 主链）
# 只允许经本 gateway 生成/落库原件；分区仍只由 ``classify`` 决定。
DIRECT_DISCOVERY_SCHEMA = "direct-discovery/v1"
DIRECT_RAW_ROOT_ENV = "RULEPROOF_DIRECT_RAW_ROOT"


def _env_int(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name) or default))
    except Exception:  # noqa: BLE001 - 坏配置回退默认值，不阻断
        return default


def direct_discovery_documents(docs: list) -> list:
    """主链文档 → 直连发现用全文（复用影子层同一解析口径，不重复解析）。

    ``docs`` 是 ``project.documents(case_id)`` 的行（含 path/id/filename）；
    返回 ``[{document_id, filename, text}]``（无解析文本的文档被跳过）。
    """
    return [dict(d) for d in (_ash()._doc_texts(docs) or [])]


def direct_discovery_rules(codes: list) -> list:
    """主链直连发现的规则集：只取本轮 manifest 允许的规则码（与影子召回同源）。

    不读全库 published 规则：直连发现与平台主链必须看同一份冻结规则集，否则
    差异无法归因到「平台漏检」。
    """
    clean = [str(c) for c in (codes or []) if str(c or "").strip()]
    if not clean:
        return []
    try:
        return [dict(r) for r in (_ash()._rules_for_codes(clean) or [])]
    except Exception:  # noqa: BLE001 - 规则解析失败 = 本轮跳过直连发现，不阻断主链
        return []


def pick_evidence_document(doc_texts: list, quote: str) -> dict:
    """直连 finding 的真实来源文档：按引文逐字/归一命中定位，**不钉死 docs[0]**。

    复用 ``accuracy_shadow._pick_doc``；结果必须再校验引文确实在该文档里命中，
    否则返回 ``{}``（宁可不锚定，也不能把引文钉到错误文档上）。
    """
    q = str(quote or "")
    if not q or not doc_texts:
        return {}
    try:
        doc = _ash()._pick_doc(doc_texts, q) or {}
        text = str(doc.get("text") or "")
    except Exception:  # noqa: BLE001
        return {}
    if not text:
        return {}
    if q in text:
        return dict(doc)
    norm_q = "".join(q.split())
    if norm_q and norm_q in "".join(text.split()):
        return dict(doc)
    return {}


def run_direct_discovery(case_id: str, documents: list, rules: list, *,
                         run_id: str = "", tenant_id: str = "",
                         workspace_id: str = "", raw_root: str = "",
                         trigger: str = "project.audit", max_docs: int = 0,
                         runs: int = 1, generation: dict | None = None) -> dict:
    """直连发现源（Phase 3）：逐文档调用直连模型并**不可变落库**（direct_draft/direct_item）。

    这是产品主链生成直连原件的**唯一入口**（``direct_draft`` 只允许被本 gateway 调用）。
    本函数**不裁决**：返回的 ``claims``（跨轮 claim 去重后的本轮 claim 清单，
    含首次出现/复用的 direct_item_id + 真实来源 document_id）供调用方把条目按
    真实来源文档送 ``classify``；``item_doc_map`` 仅覆盖本轮**新增**条目（兼容旧调用方）。

    跨轮去重（2026-11-21 收尾）：同一 (case, rule_code, 归一后 quote) 历史已存在 →
    direct_item 不新增（原始 raw 仍在 direct_draft，可回放），claims 标记 is_new=False。

    L11：每次运行把 latency/token 写 ``direct_discovery_metrics``（失败不影响发现结果），
    并返回 ``metrics`` 摘要；与平台主链的倍数对比见 ``compare_platform_arm``。

    - 逐文档调用：每次调用的 quote_check 以该文档全文为基准，因此 offset/line 天然
      属于该文档（多文档项目不存在「引文钉在 docs[0]」的问题）；
    - 单文档失败不拖垮其它文档（errors 逐文档记录）；模型不可用只记错误；
    - ``raw_root`` 缺省用环境变量 ``RULEPROOF_DIRECT_RAW_ROOT``，再缺省
      ``platform/data/direct_drafts``（append-only 原件目录）。
    """
    import time as _time

    cid = str(case_id or "").strip()
    if not cid:
        raise ValueError("case_id 不能为空")
    from .. import db as _db

    t0 = _time.time()
    docs = [d for d in (documents or []) if str(d.get("text") or "").strip()]
    cap = int(max_docs or _env_int("RULEPROOF_DIRECT_DISCOVERY_MAX_DOCS", 3))
    if cap > 0:
        docs = docs[:cap]
    root = (str(raw_root or "").strip()
            or str(os.environ.get(DIRECT_RAW_ROOT_ENV) or "").strip()
            or os.path.join(os.path.dirname(os.path.dirname(
                os.path.dirname(os.path.abspath(__file__)))), "data", "direct_drafts"))
    out = {
        "schema": DIRECT_DISCOVERY_SCHEMA, "gateway": GATEWAY_VERSION,
        "case_id": cid, "audit_run_id": str(run_id or ""), "trigger": str(trigger or ""),
        "ok": True, "enabled": True, "raw_root": root,
        "documents": len(docs), "rules": len(rules or []),
        "direct_calls": 0, "drafts": 0, "persisted": 0, "items": 0,
        "item_doc_map": {}, "doc_results": [], "errors": [],
        "claims": [], "new_direct_items": 0, "duplicate_claims": 0,
        "claims_seen": 0, "metrics": {}, "per_doc": [],
    }
    if not docs:
        out.update({"ok": False, "skipped": "no_parsed_text",
                    "errors": ["no_parsed_text"]})
        return out
    if not rules:
        out.update({"ok": False, "skipped": "empty_rule_set",
                    "errors": ["empty_rule_set"]})
        return out
    dd = _dd()
    store = dd.ImmutableRawStore(root)
    conn = _db.connect()
    try:
        claim_by_key = {}
        tokens_in = tokens_out = llm_lat_sum = new_items = dup_claims = 0
        for doc in docs:
            did = str(doc.get("document_id") or "")
            entry = {"document_id": did, "filename": str(doc.get("filename") or ""),
                     "run_id": "", "draft_id": "", "items": 0, "new_items": 0,
                     "duplicate_claims": 0, "latency_ms": 0, "latency_llm_ms": 0,
                     "tokens_in": 0, "tokens_out": 0, "created": False, "error": ""}
            try:
                results = dd.run_direct_draft(
                    cid, str(doc.get("text") or ""), rules, store,
                    runs=max(1, int(runs or 1)), generation=generation,
                    case_meta={"document_id": did, "source": "project.audit",
                               "trigger": str(trigger or ""),
                               "audit_run_id": str(run_id or "")})
                out["direct_calls"] += 1
                for res in results or []:
                    entry["run_id"] = entry["run_id"] or str(res.get("run_id") or "")
                    rec = res.get("record") or {}
                    entry["latency_llm_ms"] += int(rec.get("latency_ms") or 0)
                    entry["tokens_in"] += int(rec.get("tokens_in") or 0)
                    entry["tokens_out"] += int(rec.get("tokens_out") or 0)
                    llm_lat_sum += int(rec.get("latency_ms") or 0)
                    tokens_in += int(rec.get("tokens_in") or 0)
                    tokens_out += int(rec.get("tokens_out") or 0)
                    try:
                        persisted = dd.persist_run(
                            conn, res, doc_text=str(doc.get("text") or ""),
                            tenant_id=str(tenant_id or ""),
                            workspace_id=str(workspace_id or ""),
                            document_id=did)
                        conn.commit()   # 异步消费方（仲裁/工作台）需立即看到
                    except Exception as exc:  # noqa: BLE001 - 落库失败只记该文档
                        entry["error"] = f"persist: {type(exc).__name__}: {str(exc)[:160]}"
                        out["errors"].append({"document_id": did, **{"error": entry["error"]}})
                        continue
                    entry["draft_id"] = entry["draft_id"] or str(
                        persisted.get("draft_id") or "")
                    if persisted.get("created"):
                        out["drafts"] += 1
                        out["persisted"] += 1
                    items = persisted.get("items") or []
                    entry["created"] = bool(persisted.get("created"))
                    entry["items"] += len(items)
                    entry["new_items"] += int(persisted.get("new_items") or len(items))
                    entry["duplicate_claims"] += int(persisted.get("duplicate_claims") or 0)
                    new_items += int(persisted.get("new_items") or len(items))
                    dup_claims += int(persisted.get("duplicate_claims") or 0)
                    out["items"] += len(items)
                    out["new_direct_items"] += int(persisted.get("new_items") or len(items))
                    out["duplicate_claims"] += int(persisted.get("duplicate_claims") or 0)
                    for it in items:
                        iid = str(it.get("id") or "")
                        if iid:
                            out["item_doc_map"][iid] = did
                    # 跨轮 claim 清单（同一 claim 在多文档命中时保留首见，附全部文档）
                    for cl in (persisted.get("claims") or []):
                        ck = str(cl.get("claim_key") or "")
                        if not ck:
                            continue
                        cl = dict(cl)
                        cl["document_id"] = str(cl.get("document_id") or did) or did
                        cl.setdefault("run_id", entry["run_id"])
                        cl.setdefault("draft_id", str(persisted.get("draft_id") or ""))
                        if ck in claim_by_key:
                            prev = claim_by_key[ck]
                            prev["document_ids"] = list(dict.fromkeys(
                                list(prev.get("document_ids") or []) + [cl["document_id"]]))
                        else:
                            cl["document_ids"] = [cl["document_id"]]
                            claim_by_key[ck] = cl
                    if str(rec.get("error") or ""):
                        entry["error"] = str(rec.get("error") or "")[:200]
                if entry["error"]:
                    out["errors"].append({"document_id": did,
                                          "error": entry["error"]})
            except Exception as exc:  # noqa: BLE001 - 单文档失败隔离
                entry["error"] = f"{type(exc).__name__}: {str(exc)[:200]}"
                out["errors"].append({"document_id": did, "error": entry["error"]})
            entry["latency_ms"] = int((_time.time() - t0) * 1000)
            out["per_doc"].append(entry)
            out["doc_results"].append(entry)
        out["claims"] = list(claim_by_key.values())
        out["claims_seen"] = len(out["claims"])
        latency_ms = int((_time.time() - t0) * 1000)
        out["latency_ms"] = latency_ms
        out["tokens_in"], out["tokens_out"] = tokens_in, tokens_out
        out["tokens_total"] = tokens_in + tokens_out
        out["latency_llm_sum_ms"] = llm_lat_sum
        try:
            out["metrics"] = dd.record_discovery_metrics(
                conn, case_id=cid, run_id=str(run_id or ""),
                tenant_id=str(tenant_id or ""), workspace_id=str(workspace_id or ""),
                trigger=str(trigger or ""), documents=len(docs),
                direct_calls=int(out["direct_calls"]), rules=len(rules or []),
                new_direct_items=new_items, duplicate_claims=dup_claims,
                latency_ms=latency_ms, latency_llm_sum_ms=llm_lat_sum,
                tokens_in=tokens_in, tokens_out=tokens_out,
                per_doc=out["per_doc"], ok=not out["errors"],
                errors=[str((e or {}).get("error") or "") for e in out["errors"]],
                raw_root=root)
            conn.commit()
        except Exception as exc:  # noqa: BLE001 - 指标写失败不影响发现结果（但留痕）
            out["metrics_error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
    finally:
        conn.close()
    out["ok"] = not out["errors"]
    return out


# ---------------------------------------------------------------------------
# 全文 sweep 候选通道（2026-11-21，可选前置发现源，默认关）
#
# 定位：L1 主检出通道反转的最小闭环。外部评审结论：把「逐规则窄判、D5 判 fail 才物化」
# 的闸门式架构，改为「全文 sweep（B 臂措辞）产候选 → 校验后物化，na/abstain/pass 不再
# 终结候选」。本通道**只复用** direct_draft 的不可变原件能力与既有调用路径，不新造管线：
#   LLM 调用 → direct_draft.run_sweep_draft（B 措辞，prompt_version=sweep-candidates-v1）
#   → 不可变落库（direct_draft/direct_item，原文可回放）
#   → (a) 码归属校准：候选码必须映射到本轮冻结清单里的真实规则码，否则丢弃并审计
#   → (b) 逐字锚定：quote 经 _collapse_quote_ws 归一后必须命中原文；未命中先 re-anchor
#        （按标点切最长可信片段回锚），仍不行不物化
#   → (c) 去重：同 (case, rule_code, 归一 quote) 以平台现有结论优先（平台 fail 保留）；
#        平台判 pass 但 sweep 判违反 → 物化但标 sweep_override=True 供复核
#   → 物化 finding（engine='sweep-channel' / 覆盖平台 pass 时 'sweep-channel:override'）
#
# 默认关：开关判定在 project.audit 收尾（RULEPROOF_SWEEP_CHANNEL + 空间设置
# mod_sweep_channel），关闭时本模块的函数一次都不会被调用（零 LLM/零落库/零审计）。
# ---------------------------------------------------------------------------
SWEEP_SCHEMA = "sweep-candidates/v1"
SWEEP_ENGINE = "sweep-channel"
SWEEP_ENGINE_OVERRIDE = "sweep-channel:override"
SWEEP_RAW_ROOT_ENV = "RULEPROOF_SWEEP_RAW_ROOT"
SWEEP_MAX_DOCS_ENV = "RULEPROOF_SWEEP_CHANNEL_MAX_DOCS"
SWEEP_ANCHOR_MIN_LEN = 8
# sweep 物化前置码归属（E2）：先按 span 重推码、再落库；**独立于全局 RULEPROOF_CODE_ATTRIB**。
# 默认 off（未设置）：不 import 码归属模块、不产 attribution 字段、不改码、零计数 →
# 与现行为逐字段一致。=1/replace：仅确定性信号高置信单码时替换（机制短语逐字命中 /
# 算术矛盾唯一最高分）；=suggest：只记录建议、不改码。
SWEEP_ATTRIB_ENV = "RULEPROOF_SWEEP_ATTRIB"


def _sweep_attrib_mode() -> str:
    """sweep 物化前置码归属开关：off（默认）/ suggest / replace。

    只读 ``RULEPROOF_SWEEP_ATTRIB``；与全局 ``RULEPROOF_CODE_ATTRIB`` 完全独立。
    未设置/0/off → off（连码归属模块都不 import）。非法值按 off（不静默改码）。
    """
    raw = str(os.environ.get(SWEEP_ATTRIB_ENV) or "").strip().lower()
    if raw in ("", "0", "off", "false", "no"):
        return "off"
    if raw in ("suggest", "observe"):
        return "suggest"
    if raw in ("1", "on", "true", "yes", "replace", "high", "2", "apply"):
        return "replace"
    return "off"


def _sweep_rule_meta_from_frozen(item: dict, fallback_code: str = "") -> dict:
    """冻结 manifest item（或已发布规则行）→ 物化 finding 需要的规则元数据。"""
    it = item or {}
    code = str(it.get("code") or it.get("rule_code") or fallback_code or "")
    slots = it.get("slots") if isinstance(it.get("slots"), dict) else {}
    return {"rule_id": str(it.get("rule_id") or code),
            "code": code,
            "name": str(it.get("name") or it.get("rule_name") or code),
            "version": str(it.get("version") or ""),
            "criterion": str(slots.get("criterion") or it.get("criterion")
                             or it.get("requirement") or "")}


def sweep_rules(codes: list) -> list:
    """sweep 可用规则集 = 本轮 manifest 冻结清单（与平台主链同一份规则集，同源）。"""
    return direct_discovery_rules(codes)


def _sweep_norm_quote(quote: str) -> str:
    """归一后 quote（唯一空白口径 = manifest_exec._collapse_quote_ws，与证据门禁同源）。"""
    from .manifest_exec import _norm_quote
    try:
        return str(_norm_quote(str(quote or "")))
    except Exception:  # noqa: BLE001 - 归一失败按空处理（空 quote 一律不物化）
        return ""


def _sweep_anchor(doc_text: str, quote: str) -> dict:
    """quote 逐字/归一命中原文并回写**原文真实片段**（证据必须能在原文里复核）。

    返回 ``{"ok", "quote", "match", "reason"}``：
    - ``verbatim``：原文直接包含（最严）；
    - ``collapse_ws``：按 ``_collapse_quote_ws`` 归一后命中，回写原文片段；
    - ``reanchored``：整段未命中，按标点切分取最长可信片段回锚（≥8 字）后命中；
    - 不 ok：``quote_empty`` / ``quote_not_found``。
    不做模糊相似匹配、不做子序列拼接：宁可少物化，也不能造证据。
    """
    from .manifest_exec import _collapse_quote_ws
    raw = str(quote or "").strip().strip("“”\"'「」『』` ")
    if not raw:
        return {"ok": False, "quote": "", "match": "", "reason": "quote_empty"}
    doc = str(doc_text or "")
    if not doc:
        return {"ok": False, "quote": "", "match": "", "reason": "doc_empty"}
    if raw in doc:
        return {"ok": True, "quote": raw, "match": "verbatim", "reason": ""}
    norm_doc = _collapse_quote_ws(doc)
    norm_q = _collapse_quote_ws(raw)
    if norm_q and norm_q in norm_doc:
        _loc = _sweep_locate_norm(doc, raw, _collapse_quote_ws)
        if _loc:
            return {"ok": True, "quote": _loc, "match": "collapse_ws", "reason": ""}
    # re-anchor：整段未命中时，先用「空白全剥离」回锚整句（覆盖数字/单位两侧空格差异，
    # 与 direct_draft.locate_quote 的 normalized_ws 同源），再按标点切最长可信片段回锚。
    # 注意：物化证据写的是**原文真实片段**（不是模型 quote），因此报告证据门禁仍可逐字复核。
    import re as _re

    def _flat(text):
        return _re.sub(r"\s+", "", str(text or ""))

    if len(_flat(raw)) >= SWEEP_ANCHOR_MIN_LEN and _flat(raw) in _flat(doc):
        _loc = _sweep_locate_norm(doc, raw, _collapse_quote_ws)
        if _loc:
            return {"ok": True, "quote": _loc, "match": "reanchored_ws",
                    "reason": "whole_quote_ws_insensitive"}
    segs = [x.strip() for x in _re.split(r"[\s，。；：、,.;:！？!?（）()\[\]\{\}]+", raw)
            if x and x.strip()]
    segs = [x for x in segs if len(x) >= SWEEP_ANCHOR_MIN_LEN]
    segs.sort(key=len, reverse=True)
    for seg in segs[:6]:
        if _collapse_quote_ws(seg) in norm_doc:
            _loc = _sweep_locate_norm(doc, seg, _collapse_quote_ws)
            if _loc:
                return {"ok": True, "quote": _loc, "match": "reanchored",
                        "reason": f"anchor_segment={seg[:40]}"}
    for seg in segs[:6]:
        if _flat(seg) and _flat(seg) in _flat(doc):
            _loc = _sweep_locate_norm(doc, seg, _collapse_quote_ws)
            if _loc:
                return {"ok": True, "quote": _loc, "match": "reanchored_ws",
                        "reason": f"anchor_segment_ws={seg[:40]}"}
    return {"ok": False, "quote": "", "match": "", "reason": "quote_not_found"}


def _sweep_locate_norm(doc_text: str, quote: str, collapse) -> str:
    """归一命中后回写原文真实连续片段（用去空白下标映射，保证可逐字复核）。"""
    def _stripped_map(text):
        chars, idx = [], []
        for i, ch in enumerate(str(text or "")):
            if ch.isspace() or ch in ("\u00a0", "\u3000"):
                continue
            chars.append(ch)
            idx.append(i)
        return "".join(chars), idx

    doc_flat, doc_idx = _stripped_map(doc_text)
    q_flat, _ = _stripped_map(quote)
    if not q_flat:
        return ""
    pos = doc_flat.find(q_flat)
    if pos < 0:
        return ""
    start = doc_idx[pos]
    end = doc_idx[pos + len(q_flat) - 1]
    return str(doc_text)[start:end + 1]


def _sweep_platform_state(collected: list, manifest_items: list) -> dict:
    """平台侧现状：同码已有 finding 的 (code, 归一 quote) 键 + 每个码的 D5 结论。"""
    existing = set()
    existing_by_code = {}
    for f in collected or []:
        if not isinstance(f, dict):
            continue
        code = str(f.get("rule_code") or f.get("code") or f.get("point_id") or "").strip()
        if not code:
            continue
        quotes = []
        for ev in (f.get("evidence") or []):
            q = str((ev or {}).get("quote") or "")
            if q:
                quotes.append(_sweep_norm_quote(q))
        if str(f.get("summary") or ""):
            quotes.append(_sweep_norm_quote(str(f.get("summary") or "")))
        for q in quotes:
            if q:
                existing.add((code, q))
        existing_by_code.setdefault(code, set()).update(q for q in quotes if q)
    verdict = {}
    for it in manifest_items or []:
        if not isinstance(it, dict):
            continue
        code = str(it.get("rule") or it.get("code") or "").strip()
        if not code:
            continue
        d5 = it.get("d5")
        st = str((d5 or {}).get("status") if isinstance(d5, dict) else d5 or "")
        if st:
            verdict[code] = st
    return {"existing": existing, "existing_by_code": existing_by_code,
            "verdict": verdict}


def run_sweep_channel(case_id: str, documents: list, rules: list, *,
                      run_id: str = "", tenant_id: str = "", workspace_id: str = "",
                      raw_root: str = "", trigger: str = "project.audit",
                      max_docs: int = 0, collected: list = None,
                      manifest_items: list = None,
                      generation: dict | None = None) -> dict:
    """执行全文 sweep 候选通道并物化 finding 候选（**调用方保证开关已开**）。

    不裁决可见性、不改 manifest 的 D1–D5 结论、不改审核 summary/报告口径：
    只把「真实规则码 + 逐字可锚定」的候选作为 finding 物化（平台 fail 去重优先），
    平台判 pass 的候选加 ``sweep_override`` 标记供人工复核。

    返回 ``{"ok","findings","items","discarded","deduped","overridden",...}``；
    单文档/单候选失败一律隔离记录，不上抛（与 direct_discovery 同口径）。
    """
    import time as _time
    from .. import db as _db
    from .. import repositories as R

    cid = str(case_id or "").strip()
    if not cid:
        raise ValueError("case_id 不能为空")
    docs = [d for d in (documents or []) if str((d or {}).get("text") or "").strip()]
    cap = int(max_docs or _env_int(SWEEP_MAX_DOCS_ENV, 3))
    if cap > 0:
        docs = docs[:cap]
    root = (str(raw_root or "").strip()
            or str(os.environ.get(SWEEP_RAW_ROOT_ENV) or "").strip()
            or os.path.join(os.path.dirname(os.path.dirname(
                os.path.dirname(os.path.abspath(__file__)))), "data", "direct_drafts"))
    out = {"schema": SWEEP_SCHEMA, "gateway": GATEWAY_VERSION, "case_id": cid,
           "audit_run_id": str(run_id or ""), "trigger": str(trigger or ""),
           "enabled": True, "ok": True, "raw_root": root, "documents": len(docs),
           "rules": len(rules or []), "direct_calls": 0, "drafts": 0,
           "tokens_in": 0, "tokens_out": 0, "latency_ms": 0,
           "candidates": 0, "materialized": 0, "discarded": 0, "deduped": 0,
           "overridden": 0, "discard_reasons": {}, "dedupe_reasons": {},
           "override_codes": [], "errors": [], "findings": [], "items": [],
           "prompt_version": _dd().SWEEP_PROMPT_VERSION}
    if not docs:
        out.update({"ok": False, "skipped": "no_parsed_text",
                    "errors": ["no_parsed_text"]})
        return out
    if not rules:
        out.update({"ok": False, "skipped": "empty_rule_set",
                    "errors": ["empty_rule_set"]})
        return out
    dd = _dd()
    store = dd.ImmutableRawStore(root)
    code_map = {}
    rule_by_code = {}
    for r in rules or []:
        code = str((r or {}).get("code") or (r or {}).get("rule_code") or "").strip()
        if code:
            code_map[code.upper()] = code
            rule_by_code[code] = dict(r or {})
    ps = _sweep_platform_state(collected or [], manifest_items or [])
    # 码归属前置（E2，默认 off）：重推器只读**本轮冻结规则清单**（manifest items，含
    # slots.pack_meta.mechanisms 机制短语）；关时整段不执行 → 零 import/零字段/零行为。
    attrib_mode = _sweep_attrib_mode()
    attrib_catalog = {}
    attrib_items = {}
    if attrib_mode != "off":
        from . import rule_code_attrib as _rca

        attrib_catalog = _rca.build_catalog(list(manifest_items or []))
        if not attrib_catalog:  # 无冻结清单（异常降级）→ 用本轮规则集兜底（无机制字段）
            attrib_catalog = _rca.build_catalog(list(rule_by_code.values()))
        for _mi in manifest_items or []:
            _mc = str((_mi or {}).get("code") or (_mi or {}).get("rule_code") or "").strip()
            if _mc:
                attrib_items[_mc] = dict(_mi or {})
    seen_sweep = set()
    t0 = _time.time()
    conn = _db.connect()
    try:
        for doc in docs:
            did = str(doc.get("document_id") or doc.get("id") or "")
            try:
                results = dd.run_sweep_draft(
                    cid, str(doc.get("text") or ""), rules, store,
                    generation=generation,
                    case_meta={"document_id": did, "source": "project.audit_sweep",
                               "trigger": str(trigger or ""),
                               "audit_run_id": str(run_id or "")})
                out["direct_calls"] += 1
                for res in results or []:
                    rec = res.get("record") or {}
                    out["tokens_in"] += int(rec.get("tokens_in") or 0)
                    out["tokens_out"] += int(rec.get("tokens_out") or 0)
                    try:
                        persisted = dd.persist_run(
                            conn, res, doc_text=str(doc.get("text") or ""),
                            tenant_id=str(tenant_id or ""),
                            workspace_id=str(workspace_id or ""),
                            document_id=did)
                        conn.commit()
                    except Exception as exc:  # noqa: BLE001 - 落库失败只记该文档
                        err = f"persist: {type(exc).__name__}: {str(exc)[:160]}"
                        out["errors"].append({"document_id": did, "error": err})
                        continue
                    if persisted.get("created"):
                        out["drafts"] += 1
                    items = ((res.get("parsed") or {}).get("items")
                             or persisted.get("items") or [])
                    out["candidates"] += len(items)
                    for it in items:
                        _sweep_materialize_item(
                            out, it, doc=doc, did=did, cid=cid, run_id=str(run_id or ""),
                            code_map=code_map, rule_by_code=rule_by_code, ps=ps,
                            seen_sweep=seen_sweep, collected=collected,
                            attrib_mode=attrib_mode, attrib_catalog=attrib_catalog,
                            attrib_items=attrib_items)
            except Exception as exc:  # noqa: BLE001 - 单文档失败隔离
                out["errors"].append({"document_id": did,
                                      "error": f"{type(exc).__name__}: {str(exc)[:200]}"})
    finally:
        try:
            conn.close()
        except Exception as _close_err:  # 只影响资源释放，留痕不吞掉
            logging.getLogger(__name__).warning(
                "sweep_materialize close conn failed: %s", _close_err)
    out["latency_ms"] = int((_time.time() - t0) * 1000)
    out["ok"] = not out["errors"]
    return out


def _sweep_materialize_item(out: dict, item: dict, *, doc: dict, did: str, cid: str,
                            run_id: str, code_map: dict, rule_by_code: dict,
                            ps: dict, seen_sweep: set, collected: list,
                            attrib_mode: str = "off", attrib_catalog: dict = None,
                            attrib_items: dict = None) -> None:
    """候选 → 校验(逐字引文/码归属前置/去重) → 物化 finding；失败/丢弃全部计数并留痕。

    顺序写死（E2 只改这一处：重推码**先于**落库）：
      ① 模型自报码映射到本轮真实规则码（unmapped → 丢弃）
      ② 引文逐字/归一锚定（不命中 → 不物化，连重推都不做；证据优先）
      ③ 码归属前置（``attrib_mode`` ≠ off 才执行）：按 span 对**冻结规则清单**重推码，
         仅确定性信号高置信（机制短语逐字命中 / 算术矛盾唯一最高分）且单码时替换主码
      ④ 用**最终码**做平台/内部去重 → 写 finding/evidence（落库码 = 重推后的码）
    默认 off 时 ③ 整段不执行、不 import、不产字段、零计数 → 与现行为逐字段一致。
    """
    from .. import db as _db
    from .. import repositories as R

    def _drop(reason: str, sample: dict | None = None):
        out["discarded"] += 1
        out["discard_reasons"][reason] = out["discard_reasons"].get(reason, 0) + 1
        if len(out["items"]) < 200:
            out["items"].append({"document_id": did, "reason": reason,
                                 "discarded": True,
                                 "rule_code": str((item or {}).get("rule_code") or ""),
                                 "quote": str((item or {}).get("quote") or "")[:120],
                                 **(sample or {})})

    raw_code = str((item or {}).get("rule_code") or "").strip()
    mapped = code_map.get(raw_code.upper())
    if not mapped:
        _drop("unmapped_code")
        return
    doc_text = str(doc.get("text") or "")
    # ② 证据前置：quote 必须逐字/归一命中原文；不满足 → 不物化（重推也不做，证据优先）
    anchor = _sweep_anchor(doc_text, str((item or {}).get("quote") or ""))
    if not anchor.get("ok"):
        _drop(str(anchor.get("reason") or "quote_miss"))
        return
    # ③ 码归属前置（先重推码、再落库；默认 off 时整段不执行 → 零 import/零字段/零计数）
    _model_code = mapped
    _attr_mode = str(attrib_mode or "off")
    _hc = None
    _bitem = None
    if _attr_mode != "off":
        from . import rule_code_attrib as _rca
        _catalog = attrib_catalog or _rca.build_catalog(list(rule_by_code.values()))
        _issue = "；".join([x for x in (
            str((item or {}).get("issue") or ""),
            str((item or {}).get("reason") or "")) if x])
        _attr = _rca.rederive(
            {"code": _model_code, "quote": anchor["quote"], "summary": _issue,
             "title": str((rule_by_code.get(_model_code) or {}).get("name") or "")},
            doc_text, _catalog)
        _hc = _rca.high_confidence(_attr)
        _bucket = out.setdefault("attribution", {
            "schema": _rca.SIGNAL_VERSION, "mode": _rca.sweep_mode(),
            "signal_version": _rca.SIGNAL_VERSION, "scanned": 0, "suggested": 0,
            "replaced": 0, "rejected": 0, "skipped": 0, "items": []})
        _bucket["scanned"] += 1
        if _attr.get("proposed"):
            _bucket["suggested"] += 1
            if len(_bucket["items"]) < 50:
                _bitem = {
                    "document_id": did, "model_code": _model_code,
                    "suggested": [p["rule_code"] for p in _attr["proposed"]],
                    "kind": [p.get("kind") for p in _attr["proposed"]],
                    "multi_code": bool(_attr.get("multi_code")),
                    "high_confidence": bool(_hc.get("ok")),
                    "high_confidence_kind": _hc.get("kind") or "",
                    "reason": _hc.get("reason") or "",
                    "replaced": False,
                    "evidence": _attr.get("attribution_evidence")}
                _bucket["items"].append(_bitem)
        elif _attr.get("rejected_over_limit"):
            _bucket["rejected"] += 1
        else:
            _bucket["skipped"] += 1
        if _attr_mode == _rca.SWEEP_MODE_REPLACE:
            _new_code = str(_hc.get("rule_code") or "")
            if _hc.get("ok") and _new_code and _new_code != _model_code and (
                    _new_code in rule_by_code or _new_code in (attrib_items or {})):
                mapped = _new_code
                _bucket["replaced"] += 1
                if _bitem is not None:
                    _bitem.update({"replaced": True, "final_code": _new_code})
            elif _attr.get("proposed"):
                _bucket["rejected"] += 1  # 有候选但非高置信/多码/码不在清单 → 不替换
    # 物化用的规则元数据：重推命中时用冻结 manifest item（与主链同一份冻结快照）
    rule = (rule_by_code.get(mapped)
            or _sweep_rule_meta_from_frozen((attrib_items or {}).get(mapped) or {},
                                            fallback_code=mapped)
            or {})
    norm_q = _sweep_norm_quote(anchor["quote"])
    if not norm_q:
        _drop("quote_empty_norm")
        return
    key = (mapped, norm_q)
    if key in ps["existing"]:
        out["deduped"] += 1
        out["dedupe_reasons"]["platform_fail"] = out["dedupe_reasons"].get("platform_fail", 0) + 1
        return
    # 平台同码 finding 已存在且引文互相包含（同一条问题被平台拆得更长/更短）→ 视为重复
    # 包含判定用「空白全剥离」口径（归一空白后仍可能差数字/单位两侧空格）
    import re as _re0

    def _flat0(x):
        return _re0.sub(r"\s+", "", str(x or ""))

    for eq in ps["existing_by_code"].get(mapped) or ():
        fe, fq = _flat0(eq), _flat0(norm_q)
        if fe and fq and (fe in fq or fq in fe) and min(len(fe), len(fq)) >= 8:
            out["deduped"] += 1
            out["dedupe_reasons"]["platform_overlap"] = (
                out["dedupe_reasons"].get("platform_overlap", 0) + 1)
            return
    if key in seen_sweep:
        out["deduped"] += 1
        out["dedupe_reasons"]["sweep_dup"] = out["dedupe_reasons"].get("sweep_dup", 0) + 1
        return
    verdict = str(ps["verdict"].get(mapped) or "")
    override = (verdict == "pass")
    issue = str((item or {}).get("issue") or (item or {}).get("reason") or "").strip()
    reason = str((item or {}).get("reason") or "").strip()
    summary = "；".join([x for x in (issue, reason) if x])[:500] or f"全文 sweep 候选：{mapped}"
    fid = _db.new_id("fnd")
    try:
        R.findings.insert(
            id=fid, case_id=cid, rule_id=str((rule or {}).get("rule_id") or mapped),
            rule_version=str((rule or {}).get("version") or "sweep"),
            severity="warning", certainty="probable",
            confidence=float((item or {}).get("confidence") or 0.7) or 0.7,
            state="fail", status="pending",
            title=str((rule or {}).get("name") or mapped)[:80],
            summary=summary,
            suggestion=("全文 sweep 候选（平台判 pass，待复核）：引文逐字命中、码已校准"
                        if override else
                        "全文 sweep 候选（平台 D1–D5 未给出 fail）：引文逐字命中、码已校准")[:500],
            engine=(SWEEP_ENGINE_OVERRIDE if override else SWEEP_ENGINE),
            run_id=str(run_id or ""), point_id=mapped, source_code=mapped)
        aid = _db.new_id("anc")
        eid = _db.new_id("evd")
        R.anchors.insert(id=aid, document_id=did, sheet="", row=None, col="",
                         locator="sweep:全文", quote=anchor["quote"][:500], hash="")
        R.evidences.insert(id=eid, finding_id=fid, document_id=did, anchor_id=aid,
                           excerpt=anchor["quote"][:500],
                           label=("全文 sweep 候选（覆盖平台 pass）" if override
                                  else "全文 sweep 候选"))
    except Exception as exc:  # noqa: BLE001 - 物化失败按丢弃计数，不阻断其它候选
        _drop(f"materialize_error:{type(exc).__name__}")
        return
    seen_sweep.add(key)
    out["materialized"] += 1
    entry = {"id": fid, "code": mapped, "rule_code": mapped, "point_id": mapped,
             "rule_name": str((rule or {}).get("name") or ""),
             "title": str((rule or {}).get("name") or mapped)[:80],
             "summary": summary, "state": "fail", "severity": "warning",
             "certainty": "probable", "engine": (SWEEP_ENGINE_OVERRIDE if override
                                                else SWEEP_ENGINE),
             "sweep_override": override, "platform_verdict": verdict,
             "quote_match": str(anchor.get("match") or ""),
             "evidence": [{"quote": anchor["quote"][:500], "locator": "sweep:全文",
                           "document_id": did}],
             "document_id": did}
    if _attr_mode != "off":  # 默认关时不产该字段（逐字段一致）
        entry["code_attribution"] = {
            "mode": _attr_mode, "model_code": _model_code, "final_code": mapped,
            "applied": _model_code != mapped,
            "kind": (_hc.get("kind") if _hc else ""),
            "reason": (_hc.get("reason") if _hc else ""),
            "evidence": (_hc.get("evidence") if _hc else "")}
    out["findings"].append(entry)
    if len(out["items"]) < 200:
        _diag = {"document_id": did, "materialized": True,
                 "rule_code": mapped, "finding_id": fid,
                 "quote_match": str(anchor.get("match") or ""),
                 "platform_verdict": verdict, "sweep_override": override,
                 "quote": anchor["quote"][:120]}
        if _attr_mode != "off":
            _diag.update({"model_code": _model_code,
                          "code_attribution_applied": _model_code != mapped,
                          "code_attribution_kind": (_hc.get("kind") if _hc else "")})
        out["items"].append(_diag)
    if override:
        out["overridden"] += 1
        if mapped not in out["override_codes"]:
            out["override_codes"].append(mapped)


# ---------------------------------------------------------------------------
# L11 成本/延迟：查询入口（API 只允许经本 gateway；服务层实现在 direct_draft）
# ---------------------------------------------------------------------------
def direct_discovery_metrics(case_id: str = "", run_id: str = "", limit: int = 20) -> dict:
    """最近 N 次直连发现的延迟 P50/P95 + 总 token + 每文档均值（L11 直连侧）。"""
    from .. import db as _db
    conn = _db.connect()
    try:
        return _dd().direct_discovery_metrics(conn, case_id=str(case_id or ""),
                                              run_id=str(run_id or ""),
                                              limit=int(limit or 20))
    finally:
        conn.close()


def direct_discovery_compare(case_id: str = "", run_id: str = "",
                             limit: int = 20) -> dict:
    """L11 Δcost/Δlatency：直连发现 vs 平台主链（同 audit run_id；平台侧无记录则 not_measured）。"""
    from .. import db as _db
    conn = _db.connect()
    try:
        return _dd().compare_platform_arm(conn, case_id=str(case_id or ""),
                                          run_id=str(run_id or ""),
                                          limit=int(limit or 20))
    finally:
        conn.close()


def claim_apply_outcome(claim_id: str, status: str, *, zone: str = "",
                        shadow_item_id: str = "", transition: str = "") -> dict:
    """推进跨轮 claim 结论状态（更新而不是新增影子行）；写库+提交，返回 before/after。"""
    from .. import db as _db
    conn = _db.connect()
    try:
        res = _dd().claim_apply_outcome(
            conn, str(claim_id or ""), status=str(status or ""), zone=str(zone or ""),
            shadow_item_id=str(shadow_item_id or ""), transition=str(transition or ""))
        conn.commit()
        return res
    finally:
        conn.close()


def claim_get(claim_id: str) -> dict:
    from .. import db as _db
    conn = _db.connect()
    try:
        return _dd().get_claim(conn, str(claim_id or ""))
    finally:
        conn.close()


def direct_discovery_claims(case_id: str, status: str = "") -> dict:
    """跨轮 claim 状态（只读；审计/排查用，不含 gold 类字段）。"""
    from .. import db as _db
    conn = _db.connect()
    try:
        dd = _dd()
        dd.ensure_claim_schema(conn)
        claims = dd.list_claims(conn, case_id=str(case_id or ""), status=str(status or ""))
        return {"ok": True, "case_id": str(case_id or ""), "claims": claims,
                "count": len(claims),
                "idempotency_key": "claim_key=sha256(case_id|rule_code|归一quote)",
                "not_gold": True}
    finally:
        conn.close()


__all__ = [
    # 元信息
    "GATEWAY_VERSION", "GATEWAY_SCHEMA", "MAIN_CHAIN_SCHEMA", "MAIN_CHAIN",
    "RESPONSIBILITIES", "MECHANISM_FILES", "main_chain", "responsibilities",
    "mechanism_files",
    # 常量（消费方用它代替五套模块常量）
    "DIRECT_DRAFT_TABLE", "DIRECT_ITEM_TABLE", "ZONE_FORMAL", "ZONE_SHADOW",
    "ZONE_DISCARDED", "ZONES", "LEDGER_TABLE", "OMISSION_TABLE",
    "SHADOW_AUDIT_EVENTS",
    # ① 原件
    "direct_draft_source", "direct_draft_list", "direct_draft_get",
    "direct_draft_items", "direct_draft_stats",
    # ② 唯一仲裁
    "classify", "record_arbitration", "report_partition", "formal_finding_ids",
    "finding_zone", "formal_excluded_finding_ids",
    # ②-b 影子池产品入口（读取/裁决/指标/导出/二次复核）
    "shadow_items", "shadow_item", "decide", "shadow_metrics", "shadow_export",
    "escalate_pending", "purge", "shadow_constants",
    # ③ 仅策略
    "policy_version", "policy_snapshot", "default_policy", "resolve_visibility",
    "resolve_comparison_visibility", "visibility_candidate_from_direct",
    "visibility_candidate_from_platform", "is_high_risk_text",
    "high_risk_keywords", "reason_codes", "hidden_reason_codes",
    # ④ 仅台账
    "apply_case_visibility", "apply_comparison_visibility", "suppress_decision",
    "ledger_list", "ledger_get", "ledger_recover", "ledger_hidden_summary",
    "ledger_record_human_result", "ledger_stats",
    "omission_list", "omission_get", "omission_record", "omission_reconcile",
    "omission_reconcile_pending", "feedback_candidates",
    # ⑤ 只读标注
    "accuracy_mode", "coverage_mark_enabled", "route_repair", "shadow_recall",
    # ⑥ Phase 3 直连发现源（原件生成/落库 + 真实来源文档定位）
    "DIRECT_DISCOVERY_SCHEMA", "DIRECT_RAW_ROOT_ENV",
    "direct_discovery_documents", "direct_discovery_rules",
    "pick_evidence_document", "run_direct_discovery",
    # ⑥-b L11 指标 + 跨轮 claim 查询
    "direct_discovery_metrics", "direct_discovery_compare", "direct_discovery_claims",
    "claim_apply_outcome", "claim_get",
]
