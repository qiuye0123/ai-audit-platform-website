# -*- coding: utf-8 -*-
"""新建规则-文件入口的智能体路由。

- enterprise_standard / sop / rule_export：deterministic 拆条款，再逐条交给 agent-rulegen；
- historical_audit：交给 agent-ruleminer，只产出候选，不落库、不发布。
"""
from __future__ import annotations


def decompose(path: str, limit: int = 30, source_type: str = "document") -> dict:
    from . import agents, rule
    stype = str(source_type or "document")
    lim = max(1, min(100, int(limit or 30)))
    if stype == "historical_audit":
        from ..engine import deepparse
        text = (deepparse.parse_document(path).text or "")
        rr = agents.run_agent("agent-ruleminer",
                              {"text": text, "limit": lim, "min_count": 2})
        res = rr.get("result") or {}
        cands = []
        for x in (res.get("candidates") or []):
            title = str(x.get("title") or "").strip()
            if not title:
                continue
            score = (x.get("quality") or {}).get("score")
            try:
                conf = max(0.0, min(1.0, float(score) / 100.0))
            except Exception:
                conf = 0.5
            cands.append({
                "name": title[:60], "category": "consistency", "rclass": "R4",
                "slots": {"criterion": title, "evidence": str(x.get("summary") or "")[:300]},
                "quote": str(x.get("summary") or title)[:300], "confidence": conf,
                "representation": x.get("form") or "single",
                "form_reason": x.get("form_reason") or "",
                "source_type": "historical_audit", "agent": "agent-ruleminer",
                "agent_run_id": rr.get("run_id") or "",
                "agent_mode": str(res.get("agent_mode") or ""),
                "agent_degraded": bool(res.get("degraded")),
                "count": x.get("count") or 0, "requires_human_confirm": True,
            })
        _run_id = str(rr.get("run_id") or "")
        return {"chars": len(text), "candidates": cands, "source_type": "historical_audit",
                "agent": "agent-ruleminer", "agent_status": rr.get("status"),
                "agent_run_id": _run_id, "agent_run_ids": [_run_id] if _run_id else [],
                "agent_mode": str(res.get("agent_mode") or ""),
                "degraded": bool(res.get("degraded")),
                "degraded_reason": str(res.get("degraded_reason") or ""),
                "agent_coverage": {"total": len(cands), "agent_backed": len(cands)},
                "note": "历史审核材料只产出候选；需人工确认后创建草稿，不自动发布"}

    res = rule.decompose_document(path, lim, source_type=stype)
    backed = 0
    run_ids, modes = [], {}
    for c in (res.get("candidates") or []):
        src = str(c.get("quote") or c.get("name") or "").strip()
        if not src:
            continue
        try:
            rr = agents.run_agent("agent-rulegen", {"text": src, "save": False})
            r = rr.get("result") or {}
            if rr.get("status") in ("ok", "degraded") and (r.get("slots") or r.get("name")):
                _mode = r.get("agent_mode") or "deterministic_fallback"
                c.update({
                    "name": r.get("name") or c.get("name"),
                    "category": r.get("category") or c.get("category"),
                    "rclass": r.get("rclass") or c.get("rclass"),
                    "slots": r.get("slots") or c.get("slots"),
                    "representation": r.get("representation") or c.get("representation"),
                    "form_reason": r.get("form_reason") or c.get("form_reason"),
                    "agent": "agent-rulegen", "agent_run_id": rr.get("run_id") or "",
                    "agent_mode": _mode,
                    "agent_degraded": bool(r.get("degraded")),
                })
                run_ids.append(str(rr.get("run_id") or ""))
                modes[_mode] = modes.get(_mode, 0) + 1
                backed += 1
            else:
                c.update({"agent": "deterministic_fallback",
                          "agent_error": str(r.get("error") or rr.get("error") or "")[:120]})
        except Exception as e:
            c.update({"agent": "deterministic_fallback",
                      "agent_error": f"{type(e).__name__}: {str(e)[:100]}"})
    _total = len(res.get("candidates") or [])
    res.update({"agent": "agent-rulegen",
                "agent_coverage": {"total": _total, "agent_backed": backed},
                "agent_run_ids": [x for x in run_ids if x],
                "agent_status": ("ok" if (_total and backed == _total)
                                 else ("degraded" if backed else "failed")),
                "agent_modes": modes,
                "degraded": bool(_total and backed < _total),
                "note": "条款候选已逐条经过规则生成智能体；失败项显式标记 deterministic_fallback；只进草稿箱，不自动发布"})
    return res
