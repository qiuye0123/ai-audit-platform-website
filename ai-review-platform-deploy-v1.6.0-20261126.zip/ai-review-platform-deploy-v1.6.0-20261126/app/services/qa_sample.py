"""抽样复核：按比例抽取已复核案例做质量抽检，度量审核一致性。"""
from contextlib import nullcontext
from .. import db
from .. import repositories as R
from . import ctx


def _scope(tenant_id: str = "", workspace_id: str = ""):
    return ctx.scoped(tenant_id, workspace_id) if (tenant_id or workspace_id) else nullcontext()


def create(percent: int = 10, actor: str = "", tenant_id: str = "", workspace_id: str = "") -> dict:
    percent = max(1, min(50, int(percent or 10)))
    with _scope(tenant_id, workspace_id):
        decided = ([f for f in R.findings.list("status=?", ("confirmed",))]
                   + [f for f in R.findings.list("status=?", ("false_positive",))])
        decided = [f for f in decided if not R.qa_samples.list("finding_id=?", (f["id"],))]
        take = max(1, round(len(decided) * percent / 100))
        picked = decided[:take]
        ids = []
        for f in picked:
            sid = db.new_id("qa")
            R.qa_samples.insert(id=sid, finding_id=f["id"], case_id=f.get("case_id") or "",
                                original_status=f.get("status") or "", qa_status="pending",
                                created_at=db.now(), created_by=actor)
            ids.append(sid)
        R.audit_logs.log(actor=actor or "system", action="qa.sampled", after=f"{len(ids)} 条")
    return {"sampled": len(ids), "candidates": len(decided), "percent": percent}


def judge(sample_id: str, agree: bool, note: str = "", actor: str = "",
          tenant_id: str = "", workspace_id: str = "") -> dict:
    # F-28 服务层第二道角色校验：系统管理员/平台运营不得写审核业务。
    from . import permissions as _perms
    if _perms.actor_write_denied(actor):
        return _perms.deny_write_payload("qa.judge")
    with _scope(tenant_id, workspace_id):
        row = R.qa_samples.get(sample_id)
        if not row:
            return {"error": "样本不存在"}
        R.qa_samples.update(sample_id, qa_status=("agree" if agree else "disagree"), note=note,
                            handled_at=db.now(), handled_by=actor)
        R.audit_logs.log(actor=actor or "system", action="qa.judged", object=sample_id,
                         after=("agree" if agree else "disagree"))
    return {"id": sample_id, "status": "agree" if agree else "disagree"}


def stats(tenant_id: str = "", workspace_id: str = "") -> dict:
    with _scope(tenant_id, workspace_id):
        rows = R.qa_samples.list()
    total = len(rows)
    done = [x for x in rows if x.get("qa_status") in ("agree", "disagree")]
    agree = sum(1 for x in done if x["qa_status"] == "agree")
    return {"total": total, "pending": total - len(done), "judged": len(done),
            "agree": agree, "consistency": round(agree / len(done), 3) if done else None}


def list_samples(status: str = "", tenant_id: str = "", workspace_id: str = "") -> list:
    out = []
    with _scope(tenant_id, workspace_id):
        for x in R.qa_samples.list(order="created_at DESC"):
            if status and x.get("qa_status") != status:
                continue
            f = R.findings.get(x.get("finding_id") or "") or {}
            out.append({"id": x["id"], "finding_id": x.get("finding_id"), "case_id": x.get("case_id"),
                        "title": f.get("title") or "", "rule_id": f.get("rule_id") or "",
                        "original": x.get("original_status"), "qa_status": x.get("qa_status"),
                        "note": x.get("note") or "", "created_at": x.get("created_at")})
    return out
