"""P1-6 运行版本快照 v2：让历史结论可追溯、可回放、缓存按版本/租户隔离。

与 ``app/services/manifest.py`` 的关系：
- manifest（v1）在审核运行时由 project.py 自动写入 ``sys_config.manifest:<case>:<run>``，
  是本轮审核的**基线**快照；本模块**不改 manifest.py、不覆盖其存储键**。
- version_snapshot（v2）是**扩展快照**：在 v1 维度（文件/解析器/规则/参数/本体/提示词/
  模型/采样/执行器）之上补齐 P1 要求 —— 模型 provider 与配置来源、提示词文件哈希、
  采样参数全集、解析器分层、本体分段哈希、执行器+路由版本、审核点库/决策表版本、
  运行开关；并提供差异比对、回放校验、报告/审计可引用的快照块。
- v2 存入 ``sys_config.runsnapshot:v2:<case>:<run>``，不写/不删 v1 键，避免与
  manifest 所有者（project/manifest 链路）产生写冲突。
- V01 冻结闭包（task-29）：v2 通过 audit_run.manifest_id 反查该 run 的
  ``manifest_closure:<manifest_id>``，把文件原始内容哈希/解析产物哈希/OCR 配置/
  业务参考时间与时区/外部查询结果（含时间戳）/单位字典/规则冲突优先级/对象绑定摘要
  纳入快照与 diff；``verify_freeze_closure`` 在执行后/回放前复核冻结闭包完整性。

缓存隔离（llm_cache 按版本/租户）：
- ``cache_scope`` / ``cache_key`` / ``cache_get`` / ``cache_put`` 提供命名空间化缓存：
  key = ``v2|<scope_v1..vN>|<raw_key>``，scope 由 租户 + 工作空间 + 快照 digest +
  提示词版本/哈希 + 模型 + 采样参数 共同决定；换租户、换提示词、换模型、换采样、
  换执行器都会 miss，不会复用旧结论。
- 主判定链路 ``app/services/auditpoints.py`` 的缓存键已包含 租户/工作空间 +
  PROMPT_VERSION + 模型 + 判据 + 文档哈希，但**尚未**包含解析器/本体/参数/采样；
  切换到 v2 命名空间需要改 auditpoints.py（不在本任务写作用域），
  ``cache_isolation_report()`` 如实返回该缺口，供交付说明披露。

诚实边界：
- 快照记录“当时配置”，不保证外部模型提供方更新后重跑结论一致；
- ``verify`` 只校验**配置是否一致**，不自动重跑历史审核；自动重跑需 review/manifest 链路接线；
- 快照字段取自运行时真实对象/文件/DB，不臆造；取不到的字段显式返回 error/空值，不填假数。
"""
import hashlib
import json
import os
import logging
import threading
from datetime import datetime

from .. import config, db
from .. import repositories as R

SCHEMA = "run_snapshot_v2"
KEY_PREFIX = "runsnapshot:v2:"
CACHE_NAMESPACE_PREFIX = "v2|"

# 参与「执行器」与「路由」指纹的代码文件（路径相对 platform 根目录）。
_EXECUTOR_MODULES = (
    ("engine.ruleexec", "app/engine/ruleexec.py"),
    ("engine.factreview", "app/engine/factreview.py"),
    ("engine.engine", "app/engine/engine.py"),
    ("engine.rexec", "app/engine/rexec.py"),
    ("engine.judge", "app/engine/judge.py"),
    ("services.assertions", "app/services/assertions.py"),
    ("services.decision_table", "app/services/decision_table.py"),
)
_ROUTING_MODULES = (
    ("services.manifest", "app/services/manifest.py"),
    ("services.manifest_exec", "app/services/manifest_exec.py"),
    ("services.rule_router", "app/services/rule_router.py"),
    ("services.auditpoints", "app/services/auditpoints.py"),
    ("engine.auditpoints", "app/engine/auditpoints.py"),
    ("services.point_confirm", "app/services/point_confirm.py"),
)
_PARSER_MODULES = (
    ("engine.deepparse", "app/engine/deepparse.py"),
    ("engine.docparse", "app/engine/docparse.py"),
    ("engine.pdf_render", "app/engine/pdf_render.py"),
    ("services.parse_bridge", "app/services/parse_bridge.py"),
)
_PROMPT_MODULES = (
    ("services.auditpoints", "app/services/auditpoints.py"),
    ("services.auditpoints_judge_agent", "app/services/agents.py"),
    ("services.extract", "app/services/extract.py"),
)
_PROMPT_FILES = ("审核提示词.jsonl", "审核提示词.md", "前置判断与汇总提示词.md")
_LIBRARY_FILES = ("审核点库.json", "文件类型与路由.json")
# 影响结论的运行开关（只记是否设置与值，均为非密钥项；任何 API Key 一律不落快照）。
_ENV_FLAGS = (
    "RULEPROOF_VOTES", "RULEPROOF_LLM_CACHE", "RULEPROOF_EVIDENCE_CHECK",
    "RULEPROOF_BATCH_SIZE", "RULEPROOF_CLAUSE_BATCH", "RULEPROOF_POINT_TEXT_LIMIT",
    "RULEPROOF_ACCURACY_MODE", "RULEPROOF_AUDIT_DAG", "RULEPROOF_TYPED_POINTS",
    "RULEPROOF_MECHANISM_CHECKS", "RULEPROOF_FULLDOC_RECALL", "RULEPROOF_RESIDUAL_ROUNDS",
    "RULEPROOF_STRICT_SCOPE", "RULEPROOF_MAX_BODY_BYTES",
)
_PROVIDER_HOSTS = (
    ("api.deepseek.com", "deepseek"),
    ("qianfan.baidubce.com", "baidu-qianfan"),
    ("dashscope.aliyuncs.com", "aliyun-dashscope"),
    ("api.openai.com", "openai"),
    ("api.moonshot.cn", "moonshot"),
    ("open.bigmodel.cn", "zhipu"),
)

# ================================================================ L53 策略快照 v3
# 背景（L46c 策略稳定性清单）：v2 只记录 14 个 _ENV_FLAGS，41 个真实影响判定的开关
# 里 29 个未落库；解析器只有内容哈希没有语义版本；无 engine_mode；manifest hash /
# 闭包 digest / v2 digest 都含实例内随机 id，跨库不可复现；无读取入口。
# v3 只做“只增写”的补牙，不改任何判定路径：
#   1) switches：41 个判定开关的 {set,value,default_return,read_site} + 覆盖/缺失清单
#   2) parser_version：显式语义版本（与哈希并存，哈希只证明字节一致）
#   3) engine_mode：deterministic | semantic | assisted（由可观测信号确定性推导）
#   4) model/prompt 版本（模型 version/config_sha 与提示词 version/sha 并存）
#   5) packs：规则包/扩展开关占位（packs/enables/overrides，本期空数组）
#   6) content_fingerprint：去随机实例 id 的可跨库比对内容指纹
# 回退：RULEPROOF_SNAPSHOT_V3=0 → 与旧版 v2 快照逐字段一致（不新增任何 key）。
V3_SCHEMA = "run_snapshot_v3"
V3_ENV = "RULEPROOF_SNAPSHOT_V3"
# parser 语义版本：parser 契约（文本层 + 表格 + docx 页眉页脚 + 隐藏文本守卫）变更时
# 必须同步 bump；它不能代替哈希（哈希证明字节一致，语义版本说明“口径是哪一代”）。
PARSER_VERSION = "deepparse-2026-11-24.1"
# 41 个判定/执行开关（清单来源：L46c snapshot_schema_design.json
# switches_json_required_keys）。每项 (名称, 未设置时代码默认返回值, 读取点)；
# 默认值取自产品代码的真实解析点（test 里用源码探针防漂移）。
_JUDGMENT_SWITCHES = (
    ("RULEPROOF_EXEC_FIXES_V2", "1", "app/engine/tools.py:exec_fix_v2"),
    ("RULEPROOF_EXEC_FIXES_V3", "1", "app/engine/tools.py:exec_fix_v3"),
    ("RULEPROOF_CONSISTENCY_TEXT", "1", "app/engine/ruleexec.py:_consistency_text_enabled"),
    ("RULEPROOF_DOCX_HEADER_FACTS", "1", "app/engine/deepparse.py"),
    ("RULEPROOF_CONDITIONAL_TRIGGER", "1", "app/services/manifest.py:conditional_trigger_enabled"),
    ("RULEPROOF_ROUTE_DOC_BUDGET", "20", "app/services/manifest.py:route_doc_budget"),
    ("RULEPROOF_FREEZE_PARSE", "1", "app/services/manifest.py:_parse_artifact_closure"),
    ("RULEPROOF_FREEZE_PARSE_RECONCILE", "observe", "app/services/manifest_exec.py"),
    ("RULEPROOF_DET_LIMIT_RULES", "1", "app/services/manifest_exec.py:_deterministic_limit_result"),
    ("RULEPROOF_DET_APPLICABILITY", "1", "app/services/manifest_exec.py:_deterministic_applicability_result"),
    ("RULEPROOF_DET_CONSISTENCY", "1", "app/services/manifest_exec.py:_deterministic_consistency_result"),
    ("RULEPROOF_DET_DOMAIN", "1", "app/services/manifest_exec.py:_deterministic_domain_result"),
    ("RULEPROOF_DET_PLACEHOLDER", "1", "app/services/manifest_exec.py:_deterministic_placeholder_result"),
    ("RULEPROOF_DEDUPE", "1", "app/services/review.py"),
    ("RULEPROOF_MULTI_INSTANCE", "1", "app/engine/ruleexec.py:multi_instance_enabled"),
    ("RULEPROOF_MULTI_INSTANCE_LIMIT", "5", "app/engine/ruleexec.py:multi_instance_limit"),
    ("RULEPROOF_SEMANTIC_MULTI_INSTANCE", "0", "app/services/manifest_exec.py:semantic_multi_instance_enabled"),
    ("RULEPROOF_VOTES", "3", "app/services/manifest_exec.py:_stability_n"),
    ("RULEPROOF_LLM_CACHE", "1", "app/services/manifest.py"),
    ("RULEPROOF_EVIDENCE_CHECK", "1", "app/services/auditpoints.py:_evidence_check_enabled"),
    ("RULEPROOF_D1_STRUCTURAL", "0", "app/services/auditpoints.py:_state_calibration_clause"),
    ("RULEPROOF_ONTOLOGY_NORM", "1", "app/engine/ruleexec.py:_onto_norm_enabled"),
    ("RULEPROOF_JUDGE_GUARD", "1", "app/engine/ruleexec.py:_judge_guard_on"),
    ("RULEPROOF_PROMPT_BOUNDARY", "1", "app/services/auditpoints.py:_prompt_boundary_enabled"),
    ("RULEPROOF_STRICT_SCOPE", "0", "app/repositories.py"),
    ("RULEPROOF_AUDIT_DAG", "1", "app/services/project.py"),
    ("RULEPROOF_TYPED_POINTS", "", "app/services/auditpoints.py"),
    ("RULEPROOF_MECHANISM_CHECKS", "0", "app/services/auditpoints.py"),
    ("RULEPROOF_FULLDOC_RECALL", "", "app/services/full_doc_recall.py:enabled"),
    ("RULEPROOF_RESIDUAL_ROUNDS", "1", "app/services/review.py"),
    ("RULEPROOF_ACCURACY_MODE", "0", "app/services/accuracy_shadow.py:mode"),
    ("RULEPROOF_P0_LIMIT_SCOPE_FIX", "1", "app/engine/ruleexec.py:11584"),
    ("RULEPROOF_DISINFECT_SCOPE_FIX", "1", "app/engine/rexec.py:_disinfect_scope_fix_on"),
    ("RULEPROOF_THAW_CRITERION_PENDING", "1", "app/engine/ruleexec.py"),
    ("RULEPROOF_LEGACY_SCOPE_OPT_IN", "", "app/services/manifest.py:_legacy_scope_opt_in"),
    ("RULEPROOF_FINDING_INCLUDE_QUOTE", "1", "app/services/auditpoints.py:finding_include_quote"),
    ("RULEPROOF_NA_RECHECK_INSUFFICIENT", "0", "app/services/manifest_exec.py"),
    ("RULEPROOF_CROSS_CODE_DEDUPE", "1", "app/services/project.py:3958"),
    ("RULEPROOF_HIDDEN_TEXT_GUARD", "1", "app/engine/deepparse.py:hidden_text_guard_enabled"),
    ("RULEPROOF_SHADOW_ARBITRATION", "1", "app/services/project.py"),
    ("RULEPROOF_ACTIVE_RUN_SCOPE", "1", "app/services/manifest_exec.py:_active_scope_enabled"),
)
# 41 个开关名（required）与默认值分离：覆盖/缺失按 required 计算，
# 若清单被误删/改名，missing 会显式非空而不是静默缩小口径。
_JUDGMENT_SWITCH_REQUIRED = tuple(x[0] for x in _JUDGMENT_SWITCHES)
_JUDGMENT_SWITCH_DEFAULTS = {x[0]: x[1] for x in _JUDGMENT_SWITCHES}
_JUDGMENT_SWITCH_READ_SITES = {x[0]: x[2] for x in _JUDGMENT_SWITCHES}
# 主判定链路缓存键（auditpoints._judge_points_batch）当前覆盖的维度。
# 由 scripts/qa/version_snapshot_test.py 对源码做探针校验，避免文档与代码漂移。
_MAIN_PATH_CACHE_COMPONENTS = {
    "tenant_workspace": True,
    "prompt_version": True,
    "model": True,
    "criterion": True,
    "document_hash": True,
    "evidence_window": True,
    "parser": False,
    "ontology": False,
    "rule_params": False,
    "sampling": False,
    "executors": False,
}



# ================================================================ L61 主链 82/85/87 开关入快照
# 背景（外部评审 I4，90 号 §二-2/7）：L53 只把 41 个「判定开关设计清单」写进快照，
# 而 L59 开关注册表实测「审核主链产品读取」开关为 82 个（build49 建前 L71 证据回填
# +3 → 85；L78 多实例可观测 +2 → 87）。外部评审据此判「主链 82 开关未全入快照」。
# L61 口径：
#   1) 主链清单以**运行期**注册表（docs/qa/artifacts/switch_registry_20261124.json）为准，
#      文件缺失时回退本静态表（交付包可不带 docs/qa）；覆盖率 = 已入快照数/注册表数；
#   2) 每个开关记录 {set,value,default_return,default_known,read_site,layer,
#      impact_class,affects_judgment,registry_status}；未设置且默认值可推导的再记
#      effective/effective_source（可推导才写，不臆造）；
#   3) impact_class=judgment|evidence|routing 为「影响判定/证据/路由」的决定性开关，
#      单独报 decisive 覆盖；execution_safety/observability/deployment/meta 也记录但
#      标注「不改变单次判定」，避免把 82/85 笼统说成"全部影响判定"；
#   4) 未记录/生效值不可推导的开关逐条进 not_included / effective_unresolved 清单并给理由。
# 生成口径：scripts/qa/gen_l61_snapshot_switch_table.py（--check 防漂移）。
# 回退：RULEPROOF_SNAPSHOT_V3=0 → 不追加本块（与旧 v2 逐字段一致）。
_MAIN_CHAIN_TABLE_SCHEMA = "l61-main-chain-switch-table/v1"
_MAIN_CHAIN_REGISTRY_REL = "docs/qa/artifacts/switch_registry_20261124.json"
_MAIN_CHAIN_L59_BASELINE = 82
_MAIN_CHAIN_SINCE_L59 = (
    # build49 建前 L71 证据回填 3 开关（82→85）
    "RULEPROOF_EVIDENCE_BACKFILL",
    "RULEPROOF_EVIDENCE_BACKFILL_REQUIRED",
    "RULEPROOF_EVIDENCE_CELL_EXACT_SHORT",
    # L78 多实例 no-base-fail / cap 截断可观测 2 开关（85→87；与 L59 基线合计 +5）
    "RULEPROOF_MI_NO_BASE_FAIL_FIX",
    "RULEPROOF_MI_TRUNCATION_VISIBLE",
)
_MAIN_CHAIN_DECISIVE_CLASSES = ("judgment", "evidence", "routing")
_MAIN_CHAIN_CLASSES = ("judgment", "evidence", "routing", "execution_safety",
                       "observability", "deployment", "meta")

_MAIN_CHAIN_SWITCHES = (
    # (name, default_return, default_known, layer, impact_class, read_site)
    ("RULEPROOF_AUDIT_DAG", "1", True, "执行", "judgment", "app/services/project.py:3463"),
    ("RULEPROOF_AUDIT_LAYER", "", True, "语义", "judgment", "app/services/review.py:1708"),
    ("RULEPROOF_BATCH_SIZE", "4", True, "执行", "judgment", "app/services/auditpoints.py:3956"),
    ("RULEPROOF_BUSINESS_TIMEZONE", "", False, "部署", "judgment", "app/services/manifest.py:1608"),
    ("RULEPROOF_CLAUSE_BATCH", "0", True, "执行", "judgment", "app/services/auditpoints.py:3950"),
    ("RULEPROOF_COOLING_CHECK", "0", True, "执行", "judgment", "app/services/review.py:1827"),
    ("RULEPROOF_CROSS_CODE_DEDUPE", "1", True, "执行", "judgment", "app/services/project.py:4362"),
    ("RULEPROOF_D1_STRUCTURAL", "0", True, "执行", "judgment", "app/services/auditpoints.py:2723"),
    ("RULEPROOF_DEDUPE", "1", True, "执行", "judgment", "app/services/review.py:1613"),
    ("RULEPROOF_DEDUPE_V2", "", False, "执行", "judgment", "app/services/review.py:1219"),
    ("RULEPROOF_DET_APPLICABILITY", "1", True, "执行", "judgment", "app/services/manifest_exec.py:611"),
    ("RULEPROOF_DET_CONSISTENCY", "1", True, "执行", "judgment", "app/services/manifest_exec.py:531"),
    ("RULEPROOF_DET_DOMAIN", "1", True, "执行", "judgment", "app/services/manifest_exec.py:589"),
    ("RULEPROOF_DET_LIMIT_RULES", "1", True, "执行", "judgment", "app/services/manifest_exec.py:660"),
    ("RULEPROOF_DET_PLACEHOLDER", "1", True, "执行", "judgment", "app/services/manifest_exec.py:632"),
    ("RULEPROOF_DIRECT_DISCOVERY_TIMEOUT", "", False, "执行", "judgment", "app/services/project.py:2023"),
    ("RULEPROOF_DISINFECT_SCOPE_FIX", "1", True, "执行", "judgment", "app/engine/rexec.py:50"),
    ("RULEPROOF_EFFECTIVE_RULE_SELECT", "1", True, "执行", "judgment", "app/services/rule.py:2899"),
    ("RULEPROOF_FAIL_MIN_CONF", "", True, "执行", "judgment", "app/services/auditpoints.py:3529"),
    ("RULEPROOF_FAIL_MIN_CONF_BY_TYPE", "", True, "执行", "judgment", "app/services/auditpoints.py:3537"),
    ("RULEPROOF_FREEZE_ALL", "", False, "执行", "judgment", "app/services/manifest.py:2374"),
    ("RULEPROOF_JUDGE_BATCH_MAX_POINTS", "", False, "执行", "judgment", "app/services/auditpoints.py:3077"),
    ("RULEPROOF_JUDGE_BATCH_MAX_TOKENS", "", True, "执行", "judgment", "app/services/auditpoints.py:3087"),
    ("RULEPROOF_JUDGE_GUARD", "1", True, "执行", "judgment", "app/engine/ruleexec.py:13287"),
    ("RULEPROOF_JUDGE_GUARD_APPLIC", "", False, "执行", "judgment", "app/engine/ruleexec.py:14689"),
    ("RULEPROOF_JUDGE_GUARD_BX", "", False, "执行", "judgment", "app/engine/ruleexec.py:14757"),
    ("RULEPROOF_JUDGE_GUARD_CROSSREF", "", False, "执行", "judgment", "app/engine/ruleexec.py:14759"),
    ("RULEPROOF_JUDGE_GUARD_CROSSREF_SECOND_HOP", "", False, "执行", "judgment", "app/engine/ruleexec.py:14755"),
    ("RULEPROOF_JUDGE_GUARD_DICT", "", False, "执行", "judgment", "app/engine/ruleexec.py:14818"),
    ("RULEPROOF_JUDGE_GUARD_NUMERIC", "", False, "执行", "judgment", "app/engine/ruleexec.py:14658"),
    ("RULEPROOF_L3_POINT_LIMIT", "60", True, "执行", "judgment", "app/services/review.py:1725"),
    ("RULEPROOF_LAYER_RULES", "60", True, "执行", "judgment", "app/services/review.py:1721"),
    ("RULEPROOF_LEDGER_STRICT", "1", True, "执行", "judgment", "app/services/pstates.py:48"),
    ("RULEPROOF_LEGACY_SCOPE_OPT_IN", "", True, "执行", "judgment", "app/services/manifest.py:2242"),
    ("RULEPROOF_LLM_CACHE", "1", True, "执行", "judgment", "app/services/auditpoints.py:3985"),
    ("RULEPROOF_LLM_MODEL", "", True, "执行", "judgment", "app/config.py:68"),
    ("RULEPROOF_LONG_WINDOWS", "1", True, "执行", "judgment", "app/services/auditpoints.py:401"),
    ("RULEPROOF_MANIFEST_VOTES", "", False, "执行", "judgment", "app/services/manifest_exec.py:5979"),
    ("RULEPROOF_MECHANISM_CHECKS", "0", True, "执行", "judgment", "app/services/auditpoints.py:3659"),
    ("RULEPROOF_MI_LIMIT", "", False, "执行", "judgment", "app/services/manifest_exec.py:6977"),
    ("RULEPROOF_MI_NO_BASE_FAIL_FIX", "1", True, "执行", "judgment", "app/services/manifest_exec.py:7008"),
    ("RULEPROOF_MI_SPLIT_SPAN", "1", True, "执行", "judgment", "app/services/manifest_exec.py:6961"),
    ("RULEPROOF_MI_TRUNCATION_VISIBLE", "1", True, "执行", "judgment", "app/services/manifest_exec.py:7019"),
    ("RULEPROOF_MULTI_INSTANCE_LIMIT", "", False, "执行", "judgment", "app/engine/ruleexec.py:13064"),
    ("RULEPROOF_POINT_TEXT_LIMIT", "48000", True, "执行", "judgment", "app/services/auditpoints.py:2804"),
    ("RULEPROOF_PROMPT_BOUNDARY", "1", True, "执行", "judgment", "app/services/auditpoints.py:2742"),
    ("RULEPROOF_RESIDUAL_ROUNDS", "1", True, "执行", "judgment", "app/services/review.py:1770"),
    ("RULEPROOF_RULE_PREFILTER", "0", True, "执行", "judgment", "app/services/review.py:876"),
    ("RULEPROOF_SEMANTIC_TIMEOUT", "60", True, "语义", "judgment", "app/services/manifest_exec.py:796"),
    ("RULEPROOF_SHADOW_ARBITRATION", "1", True, "语义", "judgment", "app/services/project.py:988"),
    ("RULEPROOF_SINGLE_WINDOW_MAX", "60000", True, "执行", "judgment", "app/services/auditpoints.py:378"),
    ("RULEPROOF_STABILITY_VOTES", "", False, "执行", "judgment", "app/services/manifest_exec.py:5978"),
    ("RULEPROOF_STRICT_SCOPE", "0", True, "执行", "judgment", "app/repositories.py:225"),
    ("RULEPROOF_STRUCT_CHECKS", "0", True, "执行", "judgment", "app/services/review.py:1854"),
    ("RULEPROOF_TABLE_PRECEDENCE", "multi", True, "执行", "judgment", "app/services/review.py:655"),
    ("RULEPROOF_THAW_CRITERION_PENDING", "1", True, "执行", "judgment", "app/engine/packs/food.py:631"),
    ("RULEPROOF_TYPED_POINTS", "", False, "执行", "judgment", "app/services/auditpoints.py:3886"),
    ("RULEPROOF_UNKNOWN_ACCEPT_DAYS", "", False, "报告", "judgment", "app/services/report_gate.py:741"),
    ("RULEPROOF_VOTES", "1", True, "执行", "judgment", "app/services/auditpoints.py:4007"),
    ("RULEPROOF_AUDIT_LIBRARY", "", True, "部署", "evidence", "app/config.py:82"),
    ("RULEPROOF_AUDIT_POINTS", "", True, "部署", "evidence", "app/config.py:80"),
    ("RULEPROOF_CONSISTENCY_OUTLIER_QUOTE", "1", True, "执行", "evidence", "app/engine/ruleexec.py:173"),
    ("RULEPROOF_EVIDENCE_BACKFILL", "1", True, "执行", "evidence", "app/services/auditpoints.py:613"),
    ("RULEPROOF_EVIDENCE_BACKFILL_REQUIRED", "0", True, "执行", "evidence", "app/services/auditpoints.py:619"),
    ("RULEPROOF_EVIDENCE_CELL_EXACT_SHORT", "1", True, "执行", "evidence", "app/services/auditpoints.py:625"),
    ("RULEPROOF_EVIDENCE_CHECK", "1", True, "执行", "evidence", "app/services/auditpoints.py:2218"),
    ("RULEPROOF_EVIDENCE_GATE", "0", True, "执行", "evidence", "app/services/review.py:1864"),
    ("RULEPROOF_EVIDENCE_MAX_CHARS", "12000", True, "执行", "evidence", "app/services/auditpoints.py:377"),
    ("RULEPROOF_FACT_IDENTITY_FIX", "1", True, "解析", "evidence", "app/engine/rule_ir2.py:289"),
    ("RULEPROOF_FREEZE_PARSE", "1", True, "解析", "evidence", "app/services/manifest.py:769"),
    ("RULEPROOF_FREEZE_PARSE_RECONCILE", "observe", True, "解析", "evidence", "app/services/manifest_exec.py:4283"),
    ("RULEPROOF_MISSING_CONTEXT_QUOTE", "1", True, "执行", "evidence", "app/engine/ruleexec.py:179"),
    ("RULEPROOF_OCR_CMD", "", True, "解析", "evidence", "app/config.py:74"),
    ("RULEPROOF_PDF_RENDER_CMD", "", False, "解析", "evidence", "app/engine/ocr.py:337"),
    ("RULEPROOF_RECORD_PAIRS", "1", True, "执行", "evidence", "app/services/review.py:1636"),
    ("RULEPROOF_DOCTYPE_MIN_SCORE", "0", True, "路由", "routing", "app/services/review.py:1091"),
    ("RULEPROOF_DOCTYPE_TOPK", "3", True, "路由", "routing", "app/services/review.py:1106"),
    ("RULEPROOF_DOCTYPE_TOPK_MIN", "20", True, "路由", "routing", "app/services/review.py:1119"),
    ("RULEPROOF_EXTRA_AUDIT_TYPES", "D05", True, "路由", "routing", "app/services/review.py:1139"),
    ("RULEPROOF_MAX_FILES", "", False, "路由", "routing", "app/services/project.py:265"),
    ("RULEPROOF_NO_ROUTE", "0", True, "路由", "routing", "app/services/review.py:1383"),
    ("RULEPROOF_UNKNOWN_FACE", "", False, "路由", "routing", "app/services/review.py:1129"),
    ("RULEPROOF_AGENT_MAX_RETRY", "2", True, "语义", "execution_safety", "app/services/rule.py:4828"),
    ("RULEPROOF_AUDIT_SERIAL", "1", True, "执行", "execution_safety", "app/services/review.py:1659"),
    ("RULEPROOF_AUDIT_STATE_CONSISTENCY", "1", True, "执行", "execution_safety", "app/services/audit_ledger.py:409"),
    ("RULEPROOF_DEBUG_FINDINGS", "", False, "执行", "observability", "app/services/review.py:1930"),
    ("RULEPROOF_DEBUG_LOCK", "", False, "执行", "observability", "app/services/review.py:1662"),
    ("RULEPROOF_DEBUG_PIPE", "", False, "执行", "observability", "app/services/review.py:1839"),
    ("RULEPROOF_LAYER_DEBUG", "", False, "执行", "observability", "app/services/review.py:1739"),
    ("RULEPROOF_MAX_BODY_BYTES", "MAX_JSON_BODY_BYTES_DEFAULT / MAX_UPLOAD_BODY_BYTES_DEFAULT", False, "路由", "deployment", "app/api/http_guard.py:212"),
    ("RULEPROOF_VERSION_SNAPSHOT", "1", True, "报告", "meta", "app/services/manifest_exec.py:5709"),
)

# counts: current=89 (L59 baseline=82), decisive=80, default_known=64, default_unknown=25

_MAIN_CHAIN_BY_NAME = {row[0]: row for row in _MAIN_CHAIN_SWITCHES}
_MAIN_CHAIN_REGISTRY_CACHE = {"loaded": False, "path": "", "required": [],
                              "git_head": "", "generated_at": "", "error": ""}


def _main_chain_registry() -> dict:
    """读取运行期 L59 注册表的主链清单（只读、缓存；失败回退静态表）。

    为什么运行期读注册表：注册表是外部评审/门禁承认的「主链 82」口径来源，
    并行 lane 新增主链开关时快照覆盖率必须随之变化（多出的开关进 not_included
    并给「静态表未同步」理由），不能靠静态常量把新开关静默漏掉。
    """
    cache = _MAIN_CHAIN_REGISTRY_CACHE
    if cache["loaded"]:
        return cache
    path = os.path.join(_REPO_ROOT, _MAIN_CHAIN_REGISTRY_REL)
    cache["path"] = _MAIN_CHAIN_REGISTRY_REL
    cache["loaded"] = True
    if not os.path.isfile(path):
        cache["error"] = "registry_missing"
        cache["required"] = [row[0] for row in _MAIN_CHAIN_SWITCHES]
        return cache
    try:
        with open(path, encoding="utf-8") as f:
            reg = json.load(f)
        names = [str(x) for x in (reg.get("main_chain_82") or []) if str(x).strip()]
        if not names:
            raise ValueError("main_chain_82 为空")
        cache.update({"required": names,
                      "git_head": str(reg.get("git_head") or ""),
                      "generated_at": str(reg.get("generated_at") or "")})
    except Exception as exc:  # noqa: BLE001 - 注册表坏/缺失回退静态表并留痕
        cache["error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
        cache["required"] = [row[0] for row in _MAIN_CHAIN_SWITCHES]
    return cache

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ================================================================ 小工具
def _sha(text: str, n: int = 16) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:n]


def _file_sha(path: str, n: int = 16) -> str:
    try:
        return _sha(open(path, "rb").read(), n)
    except Exception:
        return ""


def _module_sha(rel_path: str) -> str:
    return _file_sha(os.path.join(_REPO_ROOT, rel_path))


def _json_sha(obj, n: int = 16) -> str:
    return _sha(json.dumps(obj, ensure_ascii=False, sort_keys=True), n)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ctx_ids(tenant_id=None, workspace_id=None) -> tuple:
    if tenant_id is not None and workspace_id is not None:
        return str(tenant_id or ""), str(workspace_id or "")
    try:
        from . import ctx
        c = ctx.get_context() or {}
        return (str(tenant_id if tenant_id is not None else c.get("tenant_id") or ""),
                str(workspace_id if workspace_id is not None else c.get("workspace_id") or ""))
    except Exception:
        return str(tenant_id or ""), str(workspace_id or "")


def _library_dir() -> str:
    d = str(getattr(config, "AUDIT_LIBRARY", "") or os.environ.get("RULEPROOF_AUDIT_LIBRARY", "") or "")
    if d and os.path.isdir(d):
        return d
    bundled = os.path.join(_REPO_ROOT, "文件审核库")
    return bundled if os.path.isdir(bundled) else ""


# ================================================================ 各维度快照
def _content_sha(path: str) -> tuple:
    """原始文件字节 sha256（V01：内容标识不是 document_id）。"""
    try:
        from . import manifest as _mf
        return _mf.file_content_digest(path)
    except Exception:
        return "", 0, "sha_helper_unavailable"


def _files_snapshot(case_id: str) -> list:
    files = []
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT d.id,d.path,d.filename,d.hash,d.parse_status,d.doc_type FROM document d "
                "JOIN case_document cd ON cd.document_id=d.id WHERE cd.case_id=? "
                "ORDER BY d.filename", (case_id,)).fetchall()
        for r in rows:
            sha, size, err = _content_sha(str(r["path"] or ""))
            files.append({"name": r["filename"] or "", "hash": r["hash"] or "",
                          "parse_status": r["parse_status"] or "",
                          "doc_type": r["doc_type"] or "",
                          "document_id": str(r["id"] or ""),
                          "sha256": sha, "hash_algo": "sha256-raw-bytes",
                          "size": size, "readable": bool(sha), "read_error": err})
    except Exception:
        files = []
    return files


def _rules_snapshot() -> dict:
    rules, items = [], []
    try:
        from . import rule as _rule_scope
        rules = _rule_scope.effective_rule_rows() or []  # T-171 生效口径（默认 0=旧行为）
        for r in rules:
            v = {}
            try:
                v = R.rules.published_version(r["id"]) or {}
            except Exception:
                v = {}
            content = "\n".join(str(v.get(k) or "") for k in
                                ("slots_json", "evidence_json", "tests_json"))
            items.append({"code": str(r.get("code") or ""),
                          "version": str(v.get("version") or ""),
                          "content_sha": _sha(content),
                          "published_at": str(v.get("published_at") or "")})
        items.sort(key=lambda x: (x["code"], x["version"]))
    except Exception as exc:
        return {"count": 0, "sha": "", "items": [], "error": f"{type(exc).__name__}"}
    sha = _sha("|".join(f"{x['code']}:{x['version']}:{x['content_sha']}" for x in items))
    return {"count": len(items), "sha": sha, "items": items,
            "content_hashed": True, "note": "content_sha 覆盖 rule_version 的 slots/evidence/tests，"
                                            "同版本号改内容也会检出变化"}


def _params_snapshot() -> dict:
    try:
        from . import ruleparam
        sha12 = ruleparam.params_sha() if hasattr(ruleparam, "params_sha") else ""
        rows = ruleparam.list_all() if hasattr(ruleparam, "list_all") else []
        return {"count": len(rows or []), "sha": sha12}
    except Exception as exc:
        return {"count": 0, "sha": "", "error": f"{type(exc).__name__}"}


def _model_snapshot() -> dict:
    cfg, db_row = {}, {}
    try:
        from ..engine import llm_router
        cfg = llm_router.resolve(refresh=True) or {}
    except Exception:
        cfg = {}
    try:
        with db.session() as c:
            r = c.execute("SELECT id,name,provider,model_id,base_url,is_default FROM model_config "
                          "WHERE is_default=1 ORDER BY created_at DESC LIMIT 1").fetchone()
            db_row = dict(r) if r else {}
    except Exception:
        db_row = {}
    base_url = str(cfg.get("base_url") or db_row.get("base_url") or "")
    host = ""
    try:
        from urllib.parse import urlparse
        host = (urlparse(base_url).hostname or "") if base_url else ""
    except Exception:
        host = ""
    provider = str(db_row.get("provider") or "").strip()
    if not provider:
        for h, name in _PROVIDER_HOSTS:
            if host == h or host.endswith("." + h):
                provider = name
                break
    if not provider:
        provider = str(cfg.get("source") or "").lower() or "unknown"
    return {
        "provider": provider,
        "model": str(cfg.get("model") or db_row.get("model_id") or ""),
        "source": str(cfg.get("source") or ("DB" if db_row else "NONE")),
        "enabled": bool(cfg.get("enabled")),
        "base_url_host": host,       # 只记主机名；完整地址不落快照（敏感）
        "base_url_sha": _sha(base_url),  # 完整地址的哈希，用于差异检测
        "api_key_present": bool(str(cfg.get("api_key") or "")),
        "timeout_seconds": int(cfg.get("timeout_seconds") or 0),
        "model_config_id": str(db_row.get("id") or ""),
        "model_config_name": str(db_row.get("name") or ""),
    }


def _sampling_snapshot() -> dict:
    def _env(name, default=""):
        v = os.environ.get(name)
        return default if v is None or v == "" else v

    out = {
        "temperature": 0,
        "max_tokens": int(getattr(config, "LLM", {}).get("max_tokens", 512) or 512),
        "votes": int(_env("RULEPROOF_VOTES", "1") or 1),
        "cache_enabled": _env("RULEPROOF_LLM_CACHE", "1") != "0",
        # 2026-11-21：auditpoints 已把引文证据门禁默认改为开（默认 1，=0 才回滚），
        # 快照必须取生效默认值，否则血缘口径会写成 evidence_check=false（与执行不一致）。
        "evidence_check": _env("RULEPROOF_EVIDENCE_CHECK", "1") == "1",
        "batch_size": int(_env("RULEPROOF_BATCH_SIZE", "4") or 4),
        "clause_batch": _env("RULEPROOF_CLAUSE_BATCH", "0") == "1",
        "point_text_limit": int(_env("RULEPROOF_POINT_TEXT_LIMIT", "48000") or 48000),
        "judge_max_tokens": 1500,
        "note": "temperature=0 与 judge_max_tokens 为代码默认值；其余来自环境变量开关",
    }
    out["sha"] = _json_sha({k: v for k, v in out.items() if k != "note"})
    return out


def _parser_snapshot() -> dict:
    modules = {name: _module_sha(rel) for name, rel in _PARSER_MODULES}
    try:
        from . import manifest as _mf
        fingerprint = _mf.parser_ocr_fingerprint()
    except Exception as exc:
        fingerprint = {"sha": "", "ocr": {}, "modules": modules,
                       "error": f"{type(exc).__name__}: {str(exc)[:120]}"}
    ocr = dict(fingerprint.get("ocr") or {})
    ocr.setdefault("configured", False)
    ocr.setdefault("backend", "none")
    return {"name": "deepparse", "modules": modules,
            "modules_sha": fingerprint.get("modules_sha") or _json_sha(modules),
            "sha": _json_sha(modules),
            "v01_fingerprint_sha": fingerprint.get("sha") or "",
            "ocr": ocr}


def _ontology_snapshot() -> dict:
    out = {"hashes": {}, "counts": {}}
    try:
        from . import ontology_service as _ontology
        overrides = _ontology.gate_overrides()
        static_aliases = _ontology.gate_static_aliases()
    except Exception:
        overrides, static_aliases = {}, {}
    out["overrides_sha"] = _json_sha(overrides)
    out["static_alias_sha"] = _json_sha(static_aliases)

    def _rows(sql):
        try:
            with db.session() as c:
                return [dict(r) for r in c.execute(sql).fetchall()]
        except Exception:
            return []

    entities = _rows("SELECT id,type_key,name,props_json FROM onto_entity")
    aliases = _rows("SELECT type_key,alias,entity_id FROM onto_alias")
    links = _rows("SELECT key,source_id,target_id FROM onto_link")
    terms = _rows("SELECT id,name,status FROM business_term") if _table_exists("business_term") else []
    try:
        with db.session() as c:
            r = c.execute("SELECT id,version,status,published_at FROM onto_version "
                          "WHERE status='published' ORDER BY created_at DESC LIMIT 1").fetchone()
            pub = dict(r) if r else {}
    except Exception:
        pub = {}
    out["counts"] = {"entities": len(entities), "aliases": len(aliases),
                     "links": len(links), "terms": len(terms)}
    out["hashes"] = {
        "entities": _json_sha([(x.get("id"), x.get("type_key"), x.get("name"), x.get("props_json")) for x in entities]),
        "aliases": _json_sha([(x.get("type_key"), x.get("alias"), x.get("entity_id")) for x in aliases]),
        "links": _json_sha([(x.get("key"), x.get("source_id"), x.get("target_id")) for x in links]),
        "terms": _json_sha([(x.get("id"), x.get("name"), x.get("status")) for x in terms]),
    }
    out["published_version"] = {"id": pub.get("id") or "", "version": pub.get("version") or "",
                                "published_at": pub.get("published_at") or ""}
    out["sha"] = _json_sha({"hashes": out["hashes"],
                            "overrides": out["overrides_sha"],
                            "static": out["static_alias_sha"],
                            "version": out["published_version"].get("id")})
    return out


def _table_exists(table: str) -> bool:
    try:
        with db.session() as c:
            return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                             (table,)).fetchone() is not None
    except Exception:
        return False


def _code_group(modules) -> dict:
    shas = {name: _module_sha(rel) for name, rel in modules}
    return {"modules": shas, "sha": _json_sha(shas)}


def _executors_snapshot() -> dict:
    return _code_group(_EXECUTOR_MODULES)


def _routing_snapshot() -> dict:
    return _code_group(_ROUTING_MODULES)


def _audit_library_snapshot() -> dict:
    lib_dir = _library_dir()
    files, total_points, version = {}, None, ""
    for name in _LIBRARY_FILES:
        p = os.path.join(lib_dir, name) if lib_dir else ""
        files[name] = _file_sha(p) if p else ""
    audit_types = document_types = 0
    try:
        from . import auditpoints as ap
        version = str(ap.library_version() or "")
        _st = ap.stats() or {}
        total_points = int(_st.get("total") or _st.get("points_total") or 0)
        audit_types = int(_st.get("audit_types") or 0)
        document_types = int(_st.get("document_types") or 0)
    except Exception:
        pass
    return {"dir": os.path.basename(lib_dir) if lib_dir else "",
            "files": files, "library_version": version, "points_total": total_points,
            "audit_types": audit_types, "document_types": document_types,
            "sha": _json_sha({"files": files, "version": version})}


def _prompt_snapshot() -> dict:
    lib_dir = _library_dir()
    files = {}
    for name in _PROMPT_FILES:
        p = os.path.join(lib_dir, name) if lib_dir else ""
        files[name] = _file_sha(p) if p and os.path.isfile(p) else ""
    version = ""
    try:
        from . import auditpoints as ap
        version = str(getattr(ap, "PROMPT_VERSION", "") or "")
    except Exception:
        pass
    modules = {name: _module_sha(rel) for name, rel in _PROMPT_MODULES}
    return {"version": version, "files": files, "source_modules": modules,
            "sha": _json_sha({"version": version, "files": files})}


def _decision_tables_snapshot() -> list:
    out = []
    try:
        rows = R.decision_tables.list("status=?", ("published",)) or []
    except Exception:
        rows = []
    for r in rows:
        try:
            out.append({"code": r.get("code") or "", "version": r.get("version") or "",
                        "hit_policy": r.get("hit_policy") or "",
                        "rules_sha": _sha(str(r.get("rules_json") or ""))})
        except Exception:
            continue
    out.sort(key=lambda x: (x["code"], x["version"]))
    return out


def _env_snapshot() -> dict:
    out = {}
    for k in _ENV_FLAGS:
        v = os.environ.get(k)
        out[k] = {"set": v is not None and str(v) != "", "value": "" if v is None else str(v)}
    return out


# ---------------------------------------------------------------- L53 策略快照 v3
def v3_enabled() -> bool:
    """RULEPROOF_SNAPSHOT_V3（默认 1）：关闭时 build() 逐字段回退旧 v2 快照。"""
    raw = str(os.environ.get(V3_ENV, "1") or "1").strip().lower()
    return raw not in ("0", "false", "off", "no")


def _switch_value(name: str) -> dict:
    raw = os.environ.get(name)
    return {"set": raw is not None and str(raw) != "",
            "value": "" if raw is None else str(raw),
            "default_return": _JUDGMENT_SWITCH_DEFAULTS.get(name, ""),
            "read_site": _JUDGMENT_SWITCH_READ_SITES.get(name, "")}


def _switches_snapshot() -> dict:
    """41 个判定开关的 {set,value,default_return,read_site} + 覆盖/缺失清单。

    只记录“当前进程是否设置/值是多少/未设置时产品默认返回什么/读取点在哪”。
    密钥类开关不在此清单（本清单全部是非密钥行为开关）；值按原始字符串落库，
    不解析成 bool，避免“默认值 vs 显式设置默认值”两种状态被混为一谈。
    """
    values = {name: _switch_value(name) for name in _JUDGMENT_SWITCH_REQUIRED}
    missing = [name for name in _JUDGMENT_SWITCH_REQUIRED if name not in values]
    digest_body = {name: {"set": d["set"], "value": d["value"],
                          "default_return": d["default_return"]}
                   for name, d in values.items()}
    return {"required": list(_JUDGMENT_SWITCH_REQUIRED),
            "values": values,
            "count": len(values),
            "required_count": len(_JUDGMENT_SWITCH_REQUIRED),
            "coverage": f"{len(values) - len(missing)}/{len(_JUDGMENT_SWITCH_REQUIRED)}",
            "missing": missing,
            "set_count": sum(1 for d in values.values() if d.get("set")),
            "digest": _json_sha(digest_body),
            "defaults_from": "产品代码真实解析点的未设置默认值（test 源码探针防漂移）"}


# ---------------------------------------------------------------- L61 模式提示（CLI → 快照）
# ``project.audit(semantic=True/False)`` 是调用期形参，快照构建点（manifest_exec/
# project 内部）拿不到它；HTTP 产品路径的 semantic 由 LLM 配置推导（可观测），CLI 的
# ``--semantic`` 则不是。L61 用线程局部“请求模式提示”让**调用方显式声明**本次请求的
# semantic/ai_assist（CLI 在调用 project.audit 前置入），快照据此持久化
# audit_mode/semantic/ai_assist/llm_enabled 组合；没有提示时按 llm_enabled+audit_mode
# 推导并在 semantic_source 里注明来源，不把“推导值”伪装成“请求值”。
_MODE_HINT = threading.local()


def note_request_mode(*, semantic=None, ai_assist=None, doc_type=None,
                      source: str = "") -> None:
    """登记本次审核请求的模式（线程局部；仅在 build/save 读取时短期有效）。"""
    _MODE_HINT.data = {
        "semantic": None if semantic is None else bool(semantic),
        "ai_assist": None if ai_assist is None else bool(ai_assist),
        "doc_type": None if doc_type is None else str(doc_type or ""),
        "source": str(source or ""),
    }


def clear_request_mode() -> None:
    try:
        del _MODE_HINT.data
    except AttributeError:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)


def _request_mode_hint() -> dict:
    return dict(getattr(_MODE_HINT, "data", None) or {})


def _modes_snapshot(model: dict) -> dict:
    """引擎模式 + 请求模式组合：deterministic | semantic | assisted（可观测信号推导）。

    - assisted   ：本次审核模式为 AI 辅助（project.audit(ai_assist=True) 写入 ctx）；
    - semantic   ：LLM 语义通道启用（D4 语义判定可能参与）；
    - deterministic：0-LLM 确定性链路（LLM 关闭）。
    持久化组合 = audit_mode / semantic / ai_assist / llm_enabled 四元组；同输入在
    manual/assisted、LLM 开/关、semantic 请求真/假下快照组合不同 → 可区分。
    semantic 优先取调用方显式声明的请求提示（CLI note_request_mode），否则按产品
    HTTP 路径口径取 llm_enabled（project_write_routes._sem = llm_router.enabled）。
    """
    llm_enabled = bool((model or {}).get("enabled"))
    audit_mode = ""
    try:
        from . import ctx as _ctx
        audit_mode = str((_ctx.get_audit_mode() or {}).get("mode") or "")
    except Exception:
        audit_mode = ""
    hint = _request_mode_hint()
    # ai_assist：请求提示 > ctx 审核模式（project.audit 写入）；都不可观测 → None（未知）
    if hint.get("ai_assist") is not None:
        ai_assist = bool(hint["ai_assist"])
        ai_assist_source = "request_hint:" + (hint.get("source") or "caller")
    elif audit_mode == "assisted":
        ai_assist, ai_assist_source = True, "ctx.audit_mode"
    elif audit_mode == "manual":
        ai_assist, ai_assist_source = False, "ctx.audit_mode"
    else:
        ai_assist, ai_assist_source = None, "not_observable"
    if hint.get("semantic") is not None:
        semantic = bool(hint["semantic"])
        semantic_source = "request_hint:" + (hint.get("source") or "caller")
    else:
        semantic = llm_enabled
        semantic_source = "llm_enabled_derived(http_product_path)"
    if hint.get("doc_type"):
        doc_type = str(hint["doc_type"])
    else:
        try:
            from . import ctx as _ctx2
            doc_type = str((_ctx2.get_audit_mode() or {}).get("doc_type") or "")
        except Exception:
            doc_type = ""
    if ai_assist is True:
        mode = "assisted"
    elif llm_enabled:
        mode = "semantic"
    else:
        mode = "deterministic"
    parts = ["assisted" if ai_assist is True else
             ("manual" if ai_assist is False else "mode-unknown"),
             "semantic" if semantic else "no-semantic",
             "llm" if llm_enabled else "no-llm"]
    combination = "+".join(parts)
    return {
        "engine_mode": mode,
        "audit_mode": audit_mode,
        "ai_assist": ai_assist,
        "semantic": semantic,
        "llm_enabled": llm_enabled,
        "doc_type": doc_type,
        "mode_combination": combination,
        # 旧字段（L53 消费者）：semantic_enabled 保留 = LLM 语义通道启用
        "semantic_enabled": llm_enabled,
        "ai_assist_source": ai_assist_source,
        "semantic_source": semantic_source,
        "semantic_param_observable": hint.get("semantic") is not None,
        "distinguishable": True,
        "note": "组合=audit_mode/semantic/ai_assist/llm_enabled；semantic 优先取调用方"
                "显式请求提示（CLI note_request_mode），无提示时按产品 HTTP 路径口径"
                "取 llm_enabled 并标 semantic_source，不把推导值伪装为请求值",
    }


def _model_version_snapshot(model: dict) -> dict:
    """模型版本（与 provider/model 并列）：version + config_sha + prompt 版本引用。"""
    model = model or {}
    version = f"{model.get('provider') or ''}:{model.get('model') or ''}"
    config_sha = _json_sha({"provider": model.get("provider"),
                            "model": model.get("model"),
                            "source": model.get("source"),
                            "base_url_sha": model.get("base_url_sha"),
                            "timeout_seconds": model.get("timeout_seconds")})
    return {"version": version, "config_sha": config_sha,
            "note": "version=provider:model 语义版本；config_sha 覆盖来源/地址哈希/超时，不含密钥"}




# ---------------------------------------------------------------- L61 主链开关入快照
def _main_chain_effective(name: str, snap: dict):
    """未设置开关的运行时生效值（只写**可推导**值；不可推导返回 (None, "", reason)）。"""
    if name == "RULEPROOF_AUDIT_LIBRARY":
        lib_dir = _library_dir()
        if lib_dir:
            return os.path.basename(lib_dir), "audit_library.dir", ""
        return "", "audit_library.dir", ""
    if name == "RULEPROOF_AUDIT_POINTS":
        return str(getattr(config, "AUDIT_POINTS", "") or ""), "config.AUDIT_POINTS", ""
    if name == "RULEPROOF_LLM_MODEL":
        # 空=按部署配置/DB 默认模型；快照 model.model 是本次真实解析结果
        return str((snap.get("model") or {}).get("model") or ""), "model.model", ""
    if name == "RULEPROOF_BUSINESS_TIMEZONE":
        ref = ((snap.get("freeze_closure") or {}).get("business_reference") or {})
        if ref.get("timezone"):
            return str(ref.get("timezone")), "freeze_closure.business_reference.timezone", ""
        return str(os.environ.get("TZ") or ""), "TZ env", ""
    if name == "RULEPROOF_OCR_CMD":
        return str(getattr(config, "OCR_CMD", "") or ""), "config.OCR_CMD", ""
    if name == "RULEPROOF_PDF_RENDER_CMD":
        # 读取点是 os.environ.get(...) or ""（app/engine/pdf_render.py:42 / ocr.py:306）
        return str(os.environ.get("RULEPROOF_PDF_RENDER_CMD") or ""), "env(call_site default '')", ""
    if name == "RULEPROOF_AUDIT_LAYER":
        layer = "legacy"
        try:
            from . import workspaces as _ws
            wid = str(snap.get("workspace_id") or "")
            st = _ws.get_settings(wid) or {} if wid else {}
            if isinstance(st.get("audit_layer"), str) and st.get("audit_layer"):
                layer = st["audit_layer"]
        except Exception:
            layer = "legacy"
        return layer, "workspace.settings.audit_layer|legacy_default", ""
    return None, "", ("未设置且默认值读自运行时配置/DB/夹逼函数（注册表 static 扫描未捕获）；"
                      "快照记录『未设置』事实与读取点，不臆造生效值")


def _main_chain_switch_record(name: str, snap: dict) -> dict:
    """单个主链开关记录：env 状态 + 静态默认 + 影响面 + 可推导生效值。"""
    row = _MAIN_CHAIN_BY_NAME.get(name)
    raw = os.environ.get(name)
    if row is None:
        # 运行期注册表有、静态表未同步（并行 lane 新增）：仍记录 env 事实，标未分类。
        return {"set": raw is not None and str(raw) != "",
                "value": "" if raw is None else str(raw),
                "default_return": "", "default_known": False,
                "read_site": "", "layer": "", "impact_class": "unclassified",
                "affects_judgment": None, "registry_status": "",
                "effective": None, "effective_source": "unclassified",
                "resolved": False,
                "reason": "运行期注册表主链新增但静态表未同步；需重跑 "
                          "scripts/qa/gen_l61_snapshot_switch_table.py 并更新代码常量"}
    default_return, default_known, layer, impact_class, read_site = \
        row[1], bool(row[2]), row[3], row[4], row[5]
    is_set = raw is not None and str(raw) != ""
    rec = {"set": is_set,
           "value": "" if raw is None else str(raw),
           "default_return": default_return,
           "default_known": default_known,
           "read_site": read_site,
           "layer": layer,
           "impact_class": impact_class,
           "affects_judgment": impact_class in _MAIN_CHAIN_DECISIVE_CLASSES,
           "registry_status": str((_registry_status_by_name().get(name) or "")),
           "effective": None, "effective_source": "", "resolved": False, "reason": ""}
    if is_set:
        rec.update({"effective": str(raw), "effective_source": "env", "resolved": True})
        return rec
    if default_known:
        rec.update({"effective": default_return,
                    "effective_source": "code_default(registry static)", "resolved": True})
        return rec
    value, source, reason = _main_chain_effective(name, snap)
    if value is not None:
        rec.update({"effective": value, "effective_source": source, "resolved": True})
        if not str(value).strip() and name != "RULEPROOF_PDF_RENDER_CMD":
            rec["reason"] = "生效值为空（未配置/默认回落），来源见 effective_source"
    else:
        rec["reason"] = reason
    return rec


_REGISTRY_STATUS_CACHE = {"loaded": False, "map": {}}


def _registry_status_by_name() -> dict:
    """注册表 status（active-default/opt-in…），只用于披露；缺失返回空 dict。"""
    if _REGISTRY_STATUS_CACHE["loaded"]:
        return _REGISTRY_STATUS_CACHE["map"]
    _REGISTRY_STATUS_CACHE["loaded"] = True
    path = os.path.join(_REPO_ROOT, _MAIN_CHAIN_REGISTRY_REL)
    try:
        with open(path, encoding="utf-8") as f:
            reg = json.load(f)
        _REGISTRY_STATUS_CACHE["map"] = {
            str(s.get("name")): str(s.get("status") or "")
            for s in (reg.get("switches") or []) if isinstance(s, dict)}
    except Exception:
        _REGISTRY_STATUS_CACHE["map"] = {}
    return _REGISTRY_STATUS_CACHE["map"]


def _main_chain_switches_snapshot(snap: dict) -> dict:
    """主链产品读取开关全覆盖块（L59 清单：82 基线 / 当前注册表实测数）。

    coverage = values 覆盖 required 的比例（required 取自运行期注册表）；
    not_included = required 里没有记录项的开关（正常应为空）；
    effective_unresolved = 未设置且生效值不可推导的开关（逐条理由，不虚报全可观测）；
    decisive = 影响判定/证据/路由的决定性开关子集（全量入快照才算覆盖）。
    """
    reg = _main_chain_registry()
    required = list(reg.get("required") or [])
    values = {name: _main_chain_switch_record(name, snap) for name in required}
    not_included = [name for name in required if name not in values]
    unclassified = [name for name, d in values.items()
                    if d.get("impact_class") == "unclassified"]
    decisive = [n for n, d in values.items()
                if d.get("impact_class") in _MAIN_CHAIN_DECISIVE_CLASSES]
    decisive_included = [n for n in decisive if n in values]
    effective_unresolved = [
        {"switch": n, "reason": str(d.get("reason") or "")}
        for n, d in values.items() if not d.get("resolved")]
    non_decisive = [n for n in required if n not in decisive]
    body = {"required": required,
            "values": values,
            "not_included": not_included,
            "effective_unresolved": effective_unresolved,
            "coverage": f"{len(values) - len(not_included)}/{len(required)}",
            "count": len(values), "required_count": len(required),
            "baseline_l59": {"count": _MAIN_CHAIN_L59_BASELINE,
                             "coverage": f"{_MAIN_CHAIN_L59_BASELINE}/"
                                         f"{_MAIN_CHAIN_L59_BASELINE}",
                             "note": "L59 注册表基线主链数；build49 建前 L71 证据回填 +3、"
                                     "L78 多实例可观测 +2 后以运行期注册表为准"},
            "since_l59": [n for n in _MAIN_CHAIN_SINCE_L59
                          if n in required] + [n for n in required
                                               if n not in _MAIN_CHAIN_BY_NAME],
            "decisive": {"classes": list(_MAIN_CHAIN_DECISIVE_CLASSES),
                         "required": decisive, "count": len(decisive),
                         "coverage": f"{len(decisive_included)}/{len(decisive)}"},
            "non_decisive": non_decisive,
            "non_decisive_note": "execution_safety/observability/deployment/meta 类也写入快照，"
                                 "但标注『不改变单次判定内容』；不把它们计入『影响判定/证据/路由』"
                                 "覆盖，避免虚报",
            "unclassified": unclassified,
            "effective_coverage": f"{len(values) - len(effective_unresolved)}/{len(values)}",
            "effective_unresolved_count": len(effective_unresolved),
            "source": {"registry": reg.get("path") or "",
                       "registry_git_head": reg.get("git_head") or "",
                       "registry_generated_at": reg.get("generated_at") or "",
                       "registry_error": reg.get("error") or "",
                       "table_schema": _MAIN_CHAIN_TABLE_SCHEMA,
                       "table_generated_by": "scripts/qa/gen_l61_snapshot_switch_table.py",
                       "table_rows": len(_MAIN_CHAIN_SWITCHES)},
            }
    body["digest"] = _json_sha({n: {"set": d["set"], "value": d["value"],
                                    "default_return": d["default_return"],
                                    "effective": d["effective"],
                                    "impact_class": d["impact_class"]}
                                for n, d in values.items()})
    # diff()/verify 对带 "sha" 的 dict 做紧凑比较（只输出前后 sha，不吐整块 40KB），
    # sha 与 digest 同值：内容指纹口径不变，只是可读性/传输优化。
    body["sha"] = body["digest"]
    return body


def _packs_snapshot() -> dict:
    """规则包（rule_pack）摘要：读**当前启用**的 pack（真实规则数据），不再占位。

    启用口径：工作空间内已发布生效规则的版本槽位带 ``slots.rule_pack``
    （``app/services/rule_pack.py:_point_slots`` 写入 industry/pack/version/point_code）
    或 ``slots.pack_meta`` 的 pack 来源 → 视为该 pack 已启用；按
    (industry, pack, version) 聚合规则编码/点位/内容摘要。
    ``enables``/``overrides``：产品当前没有「按空间启停 pack」与「pack 点位覆盖」
    机制，因此为空数组并显式 note，不伪造。
    ``available``：configs/rule_packs/<industry>/<pack>.json 已安装清单（文件 sha/版本），
    与 packs（已启用）区分；无任何启用 pack 时 ``packs: []`` 且 ``reserved=false``。
    """
    packs, errors = {}, []
    try:
        from . import rule as _rule_scope
        rows = _rule_scope.effective_rule_rows() or []
    except Exception as exc:  # noqa: BLE001 - 读取失败显式留 error，不静默当无 pack
        rows = []
        errors.append(f"effective_rules:{type(exc).__name__}: {str(exc)[:160]}")
    for r in rows:
        try:
            v = R.rules.published_version(r["id"]) or {}
            slots = json.loads(str(v.get("slots_json") or "{}"))
        except Exception:
            continue
        if not isinstance(slots, dict):
            continue
        pack = slots.get("rule_pack") if isinstance(slots.get("rule_pack"), dict) else {}
        meta = slots.get("pack_meta") if isinstance(slots.get("pack_meta"), dict) else {}
        industry = str(pack.get("industry") or meta.get("industry") or "")
        name = str(pack.get("pack") or meta.get("pack") or "")
        version = str(pack.get("version") or meta.get("version") or "")
        if not (industry or name):
            continue
        key = (industry, name, version)
        item = packs.setdefault(key, {
            "id": f"{industry}/{name}".strip("/") or name or industry,
            "industry": industry, "pack": name, "version": version,
            "source": "slots.rule_pack" if pack else "slots.pack_meta",
            "rule_codes": [], "points": [], "content_shas": [],
        })
        code = str(r.get("code") or "")
        item["rule_codes"].append(code)
        point = str(pack.get("point_code") or meta.get("point_code") or "")
        if point:
            item["points"].append(point)
        content = "\n".join(str(v.get(k) or "") for k in
                            ("slots_json", "evidence_json", "tests_json"))
        item["content_shas"].append(_sha(content))
    enabled = []
    for key in sorted(packs):
        item = packs[key]
        item["rule_codes"] = sorted(x for x in item["rule_codes"] if x)
        item["points"] = sorted(x for x in item["points"] if x)
        item["rules_count"] = len(item["rule_codes"])
        item["points_count"] = len(set(item["points"])) if item["points"] else len(item["rule_codes"])
        item["digest"] = _json_sha({"id": item["id"], "version": item["version"],
                                    "rule_codes": item["rule_codes"],
                                    "content_shas": item["content_shas"]})
        item["digest_source"] = "rules_content(slots/evidence/tests)"
        item.pop("content_shas", None)
        # 若已安装 pack 文件与启用 pack 的 id/version 匹配，补文件字节 sha（更强证据）
        item["file"] = ""
        item["file_sha"] = ""
        enabled.append(item)
    available = []
    try:
        from . import rule_pack as _rp
        for p in _rp.list_packs() or []:
            fpath = str(p.get("path") or "")
            available.append({"file": os.path.basename(fpath),
                              "industry": str(p.get("industry") or ""),
                              "pack": str(p.get("pack") or ""),
                              "version": str((p.get("stats") or {}).get("version")
                                             or p.get("version") or ""),
                              "ok": bool(p.get("ok")), "errors": list(p.get("errors") or []),
                              "file_sha": _file_sha(fpath) if fpath else "",
                              "points_count": int((p.get("stats") or {}).get("points") or 0)})
    except Exception as exc:  # noqa: BLE001
        errors.append(f"list_packs:{type(exc).__name__}: {str(exc)[:160]}")
    for item in enabled:
        for av in available:
            if av.get("industry") == item.get("industry") and \
                    (av.get("pack") == item.get("pack") or
                     str(av.get("pack") or "") in str(item.get("pack") or "")):
                item["file"] = av["file"]
                item["file_sha"] = av["file_sha"]
                break
    body = {"packs": enabled, "enables": [], "overrides": []}
    return {
        "schema": "rule_packs_v1",
        "reserved": False,          # L61：不再占位；有/无 pack 由真实规则推导
        "available": available,     # 已安装（configs/rule_packs）但未必启用
        "count": len(enabled),
        "packs": enabled,
        "enables": [],
        "overrides": [],
        "enables_note": "产品当前无『按工作空间启停 pack』机制；enables 恒空并显式说明",
        "overrides_note": "产品当前无『pack 点位覆盖』机制；overrides 恒空并显式说明",
        "enabled_source": "rules.effective.published_version.slots.rule_pack|pack_meta",
        "errors": errors,
        "sha": _json_sha(body),
        "digest": _json_sha(body),
        "note": "读当前启用 pack（真实规则槽位）→ id/version/digest/enables/overrides；"
                "无启用 pack 时 packs=[] 且 reserved=false（不占位、不臆造）",
    }


CONTENT_FP_ALGO = ("sha256:canonical-json(rules[code,version,content_sha]"
                   "|documents[filename,sha256]|parsed[filename,text_sha256,chars]"
                   "|parser_version)-v1")


def _stable_closure_content(case_id: str, run_id: str) -> dict:
    """从冻结闭包提取“去实例 id”的稳定内容项（跨库同输入可比）。

    闭包的 files.sha / parsed_artifacts.sha 元组含 document_id（每库随机），
    这里只取 filename + 内容 sha256（文件）/ filename + text_sha256 + chars（解析产物）。
    """
    mid = _manifest_id_for_run(case_id, run_id)
    if not mid:
        return {"available": False, "reason": "no_manifest_for_run", "manifest_id": ""}
    try:
        from . import manifest as _mf
        closure = _mf.load_closure(mid) or {}
    except Exception as exc:
        return {"available": False, "manifest_id": mid,
                "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
    if not closure:
        return {"available": False, "reason": "closure_missing(legacy_manifest)",
                "manifest_id": mid}
    files = closure.get("files") or {}
    parsed = closure.get("parsed_artifacts") or {}
    docs = sorted(
        [{"filename": str(x.get("filename") or ""),
          "sha256": str(x.get("sha256") or "")}
         for x in (files.get("items") or []) if str(x.get("sha256") or "")],
        key=lambda x: (x["filename"], x["sha256"]))
    parts = sorted(
        [{"filename": str(x.get("filename") or ""),
          "text_sha256": str(x.get("text_sha256") or ""),
          "chars": int(x.get("chars") or 0)}
         for x in (parsed.get("items") or []) if str(x.get("text_sha256") or "")],
        key=lambda x: (x["filename"], x["text_sha256"]))
    return {"available": True, "manifest_id": mid,
            "closure_digest": str(closure.get("digest") or ""),
            "documents": docs, "parsed_artifacts": parts,
            "source": "freeze_closure",
            "instance_id_fields_excluded": ["document_id", "manifest_id", "case_id",
                                            "run_id", "finding_id", "rule_id"]}


def _content_fingerprint(files: list, rules: dict, case_id: str, run_id: str) -> dict:
    """跨库可复现的内容指纹：规则 content_sha + 文档字节 sha256 + 解析产物文本 sha256。

    与 ``digest`` 的分工：digest 覆盖全部运行配置（含实例 id、租户、时间），用于同库
    防篡改/缓存命名空间；content_fingerprint 只取“同输入同规则必然相同”的内容项，
    用于跨实例证明“同输入 → 同判定内容”。两者并存，旧 digest 语义不变。
    """
    rules_part = sorted(
        [{"code": str(x.get("code") or ""),
          "version": str(x.get("version") or ""),
          "content_sha": str(x.get("content_sha") or "")}
         for x in ((rules or {}).get("items") or [])],
        key=lambda x: (x["code"], x["version"]))
    closure = _stable_closure_content(case_id, run_id) if case_id or run_id else {
        "available": False, "reason": "no_case_run"}
    source = "freeze_closure"
    if closure.get("available"):
        docs = closure.get("documents") or []
        parsed = closure.get("parsed_artifacts") or []
    else:
        # 无闭包（legacy/旧清单）时至少用文档清单的原始字节 sha 兜底；
        # 解析产物无法证明时不造假，显式 available=False。
        source = "files_only_fallback"
        docs = sorted(
            [{"filename": str(f.get("name") or ""),
              "sha256": str(f.get("sha256") or "")}
             for f in (files or []) if str(f.get("sha256") or "")],
            key=lambda x: (x["filename"], x["sha256"]))
        parsed = []
    body = {"algorithm": CONTENT_FP_ALGO,
            "parser_version": PARSER_VERSION,
            "rules": rules_part,
            "documents": docs,
            "parsed_artifacts": parsed}
    return {
        "algorithm": CONTENT_FP_ALGO,
        "sha256": _sha(json.dumps(body, ensure_ascii=False, sort_keys=True), 24),
        "rules_sha": _json_sha(rules_part),
        "documents_sha": _json_sha(docs),
        "parsed_artifacts_sha": _json_sha(parsed),
        "rules_count": len(rules_part),
        "documents_count": len(docs),
        "parsed_count": len(parsed),
        "source": source,
        "closure_available": bool(closure.get("available")),
        "parser_version": PARSER_VERSION,
        "excludes": ["run_id", "case_id", "manifest_id", "document_id", "rule_id",
                     "finding_id", "built_at"],
        "note": "只含内容标识（规则 code+version+content_sha、文档字节 sha、解析文本 sha），"
                "跨库同输入必须相等；不含任何实例内随机 id",
    }


def _v3_extend(snap: dict, case_id: str, run_id: str) -> dict:
    """在旧 v2 快照上追加 v3/L61 字段（只增写，不改已有字段语义）。

    L53 字段：switches(41)/parser_version/engine_mode/model_version/packs/content_fingerprint；
    L61 字段（外部评审 I4）：main_chain_switches（主链 82/85/87 全覆盖 + 未纳入理由）、
    modes（audit_mode/semantic/ai_assist/llm_enabled 组合）、packs 由占位改为真实摘要、
    snapshot_revision/replay 元信息（历史快照重放引擎可判）。
    """
    model = snap.get("model") or {}
    rules = snap.get("rules") or {}
    switches = _switches_snapshot()
    content_fp = _content_fingerprint(snap.get("files") or [], rules, case_id, run_id)
    modes = _modes_snapshot(model)
    model_version = _model_version_snapshot(model)
    # 在 model/prompt 子块内补版本（序列化后仍可读；旧字段不动）
    model = dict(model)
    model["version"] = model_version["version"]
    model["config_sha"] = model_version["config_sha"]
    prompt = dict(snap.get("prompt") or {})
    prompt["model_version"] = model_version["version"]
    snap["model"] = model
    snap["prompt"] = prompt
    snap["parser"] = dict(snap.get("parser") or {},
                          version=PARSER_VERSION)
    packs = _packs_snapshot()
    main_chain = _main_chain_switches_snapshot(snap)
    snap.update({
        "schema_version": V3_SCHEMA,
        "snapshot_revision": "L61-20261124",
        "parser_version": PARSER_VERSION,
        "engine_mode": modes["engine_mode"],
        "engine": modes,
        "modes": {k: modes.get(k) for k in
                  ("engine_mode", "audit_mode", "ai_assist", "semantic",
                   "llm_enabled", "doc_type", "mode_combination", "ai_assist_source",
                   "semantic_source", "semantic_param_observable")},
        "mode_combination": modes["mode_combination"],
        "model_version": model_version,
        "switches": switches,
        "missing_switches": switches["missing"],
        "switches_coverage": switches["coverage"],
        "main_chain_switches": main_chain,
        "main_chain_switches_coverage": main_chain["coverage"],
        "decisive_switches_coverage": main_chain["decisive"]["coverage"],
        "effective_switches_coverage": main_chain["effective_coverage"],
        "packs": packs,
        "packs_count": packs.get("count", 0),
        "content_fingerprint": content_fp,
        "replay": {
            "engine": "version_snapshot.replay-v1",
            "supported": True,
            "mode_combination": modes["mode_combination"],
            "mode_source": modes["ai_assist_source"],
            "semantic_source": modes["semantic_source"],
            "requires": ["snapshot_digest_integrity", "freeze_closure_guard",
                         "mode_combination_persisted", "content_fingerprint"],
            "note": "历史快照重放：同一快照+同输入重跑并比对 content_fingerprint/"
                    "findings/引文；输入或快照被改 → 明确 not_replayable，不伪造一致",
        },
    })
    return snap



def _files_digest(files: list) -> str:
    return _sha("|".join(
        f"{f.get('name')}:{f.get('hash')}:{f.get('sha256') or f.get('hash')}:{f.get('parse_status')}"
        for f in files))


def _manifest_id_for_run(case_id: str, run_id: str) -> str:
    """run → 该轮冻结的 manifest_id（V01 闭包反查用）。"""
    rid = str(run_id or "").strip()
    if rid:
        try:
            row = R.audit_runs.get(rid) or {}
            mid = str(row.get("manifest_id") or "").strip()
            if mid:
                return mid
        except Exception:
            pass
    if not case_id:
        return ""
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT manifest_id FROM audit_run WHERE case_id=? AND manifest_id<>'' "
                "ORDER BY rowid DESC LIMIT 1", (case_id,)).fetchone()
        return str(row["manifest_id"]) if row else ""
    except Exception:
        return ""


def _freeze_closure_snapshot(case_id: str, run_id: str) -> dict:
    """V01：把该 run 的 manifest 冻结闭包摘要纳入 v2 快照（字段口径与 manifest 一致）。"""
    mid = _manifest_id_for_run(case_id, run_id)
    if not mid:
        return {"available": False, "reason": "no_manifest_for_run",
                "note": "该 run 没有关联清单（legacy 链路），冻结闭包不可用"}
    try:
        from . import manifest as _mf
        closure = _mf.load_closure(mid)
        if not closure:
            return {"available": False, "reason": "closure_missing(legacy_manifest)",
                    "manifest_id": mid,
                    "note": "清单为 task-29 之前冻结，无 V01 闭包；完整性不可证明"}
        summary = _mf.closure_summary(closure)
        summary["available"] = True
        summary["manifest_id"] = mid
        return summary
    except Exception as exc:
        return {"available": False, "manifest_id": mid,
                "error": f"{type(exc).__name__}: {str(exc)[:160]}"}


def verify_freeze_closure(case_id: str, run_id: str) -> dict:
    """回放前复核：该 run 的冻结闭包 vs 当前文件/解析器/决策表/绑定边界。

    与 ``verify``（配置 diff）互补：这里只回答“重新执行会不会读到不同内容”。
    会写 manifest.integrity_verified / integrity_blocked 审计（由 manifest.execution_guard）。
    """
    mid = _manifest_id_for_run(case_id, run_id)
    if not mid:
        return {"available": False, "ok": False, "reason": "no_manifest_for_run",
                "case_id": case_id, "run_id": run_id}
    try:
        from . import manifest as _mf
        guard = _mf.execution_guard(mid)
        return {"available": True, "ok": bool(guard.get("ok")),
                "legacy": bool(guard.get("legacy")),
                "manifest_id": mid,
                "closure_digest": guard.get("closure_digest") or "",
                "issues": guard.get("issues") or [],
                "checks": [{"name": c.get("name"), "ok": c.get("ok"),
                            "skipped": c.get("skipped")}
                           for c in guard.get("checks") or []],
                "checked_at": guard.get("checked_at") or ""}
    except Exception as exc:
        return {"available": False, "ok": False, "manifest_id": mid,
                "error": f"{type(exc).__name__}: {str(exc)[:160]}"}


# ================================================================ 构建 / 摘要
def build(case_id: str = "", run_id: str = "", tenant_id=None, workspace_id=None) -> dict:
    """构建扩展快照（读取真实运行时对象；不落库）。

    schema 保持 ``run_snapshot_v2``（存储键前缀/消费方兼容），
    当 RULEPROOF_SNAPSHOT_V3=1（默认）时追加 v3 字段并写 ``schema_version=run_snapshot_v3``；
    =0 时逐字段回退旧 v2 输出（不新增任何 key，digest 与旧版一致）。
    """
    tid, wid = _ctx_ids(tenant_id, workspace_id)
    files = _files_snapshot(case_id) if case_id else []
    snap = {
        "schema": SCHEMA,
        "app_version": str(getattr(config, "APP_VERSION", "") or ""),
        "built_at": _now(),
        "case_id": str(case_id or ""),
        "run_id": str(run_id or ""),
        "tenant_id": tid,
        "workspace_id": wid,
        "files": files,
        "files_digest": _files_digest(files),
        "rules": _rules_snapshot(),
        "rule_params": _params_snapshot(),
        "model": _model_snapshot(),
        "prompt": _prompt_snapshot(),
        "sampling": _sampling_snapshot(),
        "parser": _parser_snapshot(),
        "ontology": _ontology_snapshot(),
        "executors": _executors_snapshot(),
        "routing": _routing_snapshot(),
        "audit_library": _audit_library_snapshot(),
        "decision_tables": _decision_tables_snapshot(),
        "env": _env_snapshot(),
        # V01：冻结闭包摘要（文件内容哈希/解析产物/OCR/业务参考时间/外部结果/单位/冲突优先级/绑定）
        "freeze_closure": _freeze_closure_snapshot(case_id, run_id),
    }
    if v3_enabled():
        # L53 补牙：只增写 v3 字段；旧字段语义/取值不变（回退杆 RULEPROOF_SNAPSHOT_V3=0）
        _v3_extend(snap, case_id, run_id)
    snap["digest"] = digest(snap)
    snap["snapshot_id"] = "rs2-" + snap["digest"][:12]
    return snap


def digest(snap: dict) -> str:
    """快照内容指纹（排除生成时间与其自身），用于差异检测与缓存命名空间。

    v3 模式下覆盖新增字段（开关/引擎/内容指纹等），因此“改判定开关”会改变 digest
    → 缓存命名空间与漂移检测能看见；=0 回退时与旧版 digest 逐字节一致。
    """
    body = {k: v for k, v in (snap or {}).items() if k not in ("built_at", "digest", "snapshot_id")}
    return _sha(json.dumps(body, ensure_ascii=False, sort_keys=True, default=str), 24)


_DIFF_FIELDS = (
    ("files", "文件清单"), ("files_digest", "文件哈希汇总"),
    ("rules", "规则版本/内容"), ("rule_params", "规则参数"), ("model", "模型/provider"),
    ("prompt", "提示词版本/哈希"), ("sampling", "采样参数"), ("parser", "解析器"),
    ("ontology", "本体"), ("executors", "执行器"), ("routing", "路由"),
    ("audit_library", "审核点库"), ("decision_tables", "决策表"), ("env", "运行开关"),
    ("freeze_closure", "冻结闭包(V01)"),
    # L53 v3：判定开关/引擎模式/规则包/去 id 内容指纹（旧快照无这些字段 → verify 兼容窄比）
    ("switches", "判定开关(41)"), ("engine_mode", "引擎模式"),
    # L61：主链 82/85/87 开关全覆盖（改任一开关 → verify 可检出；modes 不进 diff）
    ("main_chain_switches", "主链开关(82/85/87)"),
    ("model_version", "模型版本"), ("packs", "规则包/扩展"),
    ("content_fingerprint", "内容指纹(去id)"),
)


def diff(a: dict, b: dict, fields=None) -> list:
    """对比两份快照；返回字段级差异（含变更前后的可读摘要）。

    ``fields`` 可限定比较字段（verify 对旧 v2 快照做兼容窄比，避免“新增字段=漂移”误报）。
    """
    out = []
    a, b = a or {}, b or {}
    pairs = fields if fields is not None else _DIFF_FIELDS
    for key, label in pairs:
        if json.dumps(a.get(key), ensure_ascii=False, sort_keys=True, default=str) == \
                json.dumps(b.get(key), ensure_ascii=False, sort_keys=True, default=str):
            continue
        av, bv = a.get(key), b.get(key)
        if isinstance(av, dict) and isinstance(bv, dict) and (
                ("sha" in av and "sha" in bv) or
                (key == "main_chain_switches" and "digest" in av and "digest" in bv)):
            # 主链开关块 40KB+：verify 差异只输出前后摘要 sha，不吐整块
            out.append({"field": key, "label": label,
                        "a_sha": av.get("sha") or av.get("digest"),
                        "b_sha": bv.get("sha") or bv.get("digest")})
        elif key == "files":
            out.append({"field": key, "label": label,
                        "a": [f.get("hash") for f in av or []],
                        "b": [f.get("hash") for f in bv or []]})
        else:
            out.append({"field": key, "label": label, "a": av, "b": bv})
    return out


# ================================================================ 持久化 / 回放校验
def _key(case_id: str, run_id: str) -> str:
    return f"{KEY_PREFIX}{str(case_id or '').strip()}:{str(run_id or '').strip()}"


def save(case_id: str, run_id: str, snap: dict = None, actor: str = "") -> dict:
    """保存快照到 sys_config（独立键，不覆盖 manifest v1）。

    审计事件保持 ``manifest.snapshot_v2_frozen``（历史消费者按该 action 检索），
    after_json 增补 schema_version / engine_mode / missing_switches / content_fingerprint，
    让「审计 trace」可回答“这次用的是哪套策略、缺哪些开关、内容指纹是什么”。
    """
    if not str(case_id or "").strip() or not str(run_id or "").strip():
        raise ValueError("save 需要非空 case_id 与 run_id，避免产生不可回放的快照")
    snap = snap or build(case_id, run_id)
    key = _key(case_id, run_id)
    from . import sysconfig
    sysconfig.set_many({key: json.dumps(snap, ensure_ascii=False)})
    _cf = (snap.get("content_fingerprint") or {})
    _modes = snap.get("modes") or snap.get("engine") or {}
    _mc = snap.get("main_chain_switches") or {}
    _audit_after = {"snapshot_id": snap.get("snapshot_id"),
                    "digest": snap.get("digest"),
                    "run_id": run_id,
                    "schema_version": snap.get("schema_version") or snap.get("schema"),
                    "snapshot_revision": snap.get("snapshot_revision") or "",
                    "engine_mode": snap.get("engine_mode") or "",
                    # L61：同输入不同模式可区分（audit_mode/semantic/ai_assist/llm_enabled）
                    "audit_mode": _modes.get("audit_mode") or "",
                    "semantic": _modes.get("semantic"),
                    "ai_assist": _modes.get("ai_assist"),
                    "llm_enabled": _modes.get("llm_enabled"),
                    "mode_combination": snap.get("mode_combination")
                    or _modes.get("mode_combination") or "",
                    "parser_version": snap.get("parser_version")
                    or (snap.get("parser") or {}).get("version") or "",
                    "missing_switches": list(snap.get("missing_switches") or []),
                    "switches_coverage": snap.get("switches_coverage") or "",
                    "main_chain_switches_coverage":
                        snap.get("main_chain_switches_coverage") or "",
                    "main_chain_switches_count": _mc.get("count") or 0,
                    "packs_count": snap.get("packs_count") or 0,
                    "content_fingerprint": _cf.get("sha256") or ""}
    try:
        from .. import repositories as _R
        _R.audit_logs.log(actor=actor or "system", action="manifest.snapshot_v2_frozen",
                          object=str(case_id),
                          after=json.dumps(_audit_after, ensure_ascii=False))
    except Exception:
        import logging
        logging.getLogger(__name__).warning("snapshot_v2 审计事件写入失败", exc_info=True)
    # 注意：manifest_exec.run 的返回体直接把本 dict 作为 version_snapshot 透出
    # （既有 strategy_snapshot 钩子），因此模式组合/主链覆盖会随 manifest/run 返回，
    # 不需要改 manifest_exec.py。
    return {"ok": True, "key": key, "snapshot_id": snap.get("snapshot_id"),
            "digest": snap.get("digest"),
            "schema": snap.get("schema"),
            "schema_version": snap.get("schema_version") or snap.get("schema"),
            "snapshot_revision": snap.get("snapshot_revision") or "",
            "engine_mode": snap.get("engine_mode") or "",
            "audit_mode": _modes.get("audit_mode") or "",
            "semantic": _modes.get("semantic"),
            "ai_assist": _modes.get("ai_assist"),
            "llm_enabled": _modes.get("llm_enabled"),
            "mode_combination": snap.get("mode_combination")
            or _modes.get("mode_combination") or "",
            "parser_version": snap.get("parser_version")
            or (snap.get("parser") or {}).get("version") or "",
            "missing_switches": list(snap.get("missing_switches") or []),
            "switches_coverage": snap.get("switches_coverage") or "",
            "main_chain_switches_coverage":
                snap.get("main_chain_switches_coverage") or "",
            "main_chain_switches_count": _mc.get("count") or 0,
            "decisive_switches_coverage":
                snap.get("decisive_switches_coverage") or "",
            "effective_switches_coverage":
                snap.get("effective_switches_coverage") or "",
            "packs_count": snap.get("packs_count") or 0,
            "content_fingerprint": _cf.get("sha256") or ""}


def load(case_id: str, run_id: str) -> dict:
    from . import sysconfig
    raw = sysconfig.get(_key(case_id, run_id), "")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def list_saved(case_id: str = "", limit: int = 20) -> list:
    """已保存快照索引（按更新时间倒序）。"""
    out = []
    try:
        with db.session() as c:
            if case_id:
                rows = c.execute("SELECT key,value,updated_at FROM sys_config WHERE key LIKE ? "
                                 "ORDER BY updated_at DESC LIMIT ?",
                                 (f"{KEY_PREFIX}{case_id}:%", int(limit))).fetchall()
            else:
                rows = c.execute("SELECT key,value,updated_at FROM sys_config WHERE key LIKE ? "
                                 "ORDER BY updated_at DESC LIMIT ?",
                                 (KEY_PREFIX + "%", int(limit))).fetchall()
    except Exception:
        return []
    for r in rows:
        key = str(r["key"] or "")
        tail = key[len(KEY_PREFIX):]
        if ":" not in tail:
            continue
        cid, rid = tail.split(":", 1)
        try:
            d = json.loads(r["value"] or "{}")
        except Exception:
            d = {}
        out.append({"key": key, "case_id": cid, "run_id": rid,
                    "snapshot_id": d.get("snapshot_id") or "",
                    "digest": d.get("digest") or "",
                    "built_at": d.get("built_at") or "",
                    "updated_at": r["updated_at"] or "",
                    "schema": d.get("schema") or "",
                    "schema_version": d.get("schema_version") or d.get("schema") or "",
                    "engine_mode": d.get("engine_mode") or "",
                    "switches_coverage": d.get("switches_coverage") or "",
                    "main_chain_switches_coverage":
                        d.get("main_chain_switches_coverage") or "",
                    "mode_combination": d.get("mode_combination") or "",
                    "packs_count": d.get("packs_count") or 0,
                    "snapshot_revision": d.get("snapshot_revision") or "",
                    "missing_switches": list(d.get("missing_switches") or []),
                    "content_fingerprint": ((d.get("content_fingerprint") or {})
                                            .get("sha256") or "")})
    return out


def _modes_of(snap: dict) -> dict:
    """取快照模式块：L61 modes > engine > 空（旧快照无模式观测时明确 unknown）。"""
    snap = snap or {}
    m = snap.get("modes")
    if isinstance(m, dict) and m:
        return m
    e = snap.get("engine")
    if isinstance(e, dict) and e:
        return e
    return {}


def _main_chain_summary_of(snap: dict) -> dict:
    """主链开关块摘要（旧快照无该块 → available=False，不臆造 0/85）。"""
    snap = snap or {}
    block = snap.get("main_chain_switches")
    if not isinstance(block, dict) or not block:
        return {"available": False,
                "coverage": snap.get("main_chain_switches_coverage") or "",
                "decisive_coverage": snap.get("decisive_switches_coverage") or "",
                "effective_coverage": snap.get("effective_switches_coverage") or "",
                "count": 0, "not_included": [], "effective_unresolved": [],
                "note": "该快照为 L61 之前的格式（无 main_chain_switches 块）"}
    return {"available": True,
            "count": block.get("count") or 0,
            "required_count": block.get("required_count") or 0,
            "coverage": block.get("coverage") or "",
            "decisive_coverage": (block.get("decisive") or {}).get("coverage") or "",
            "effective_coverage": block.get("effective_coverage") or "",
            "not_included": list(block.get("not_included") or []),
            "effective_unresolved": list(block.get("effective_unresolved") or []),
            "digest": block.get("digest") or ""}


def _build_in_case_scope(case_id: str, run_id: str) -> dict:
    """在项目自身租户/空间作用域内构建当前快照。

    快照构建会读“当前租户/空间可见的规则集/本体”：若调用方线程上下文不是项目空间，
    同一 run 会读到不同规则集 → verify 假漂移。报告/门禁侧已各自切上下文；这里把
    作用域收口进 verify 自身，保证 CLI/审计任何入口口径一致（失败恢复调用方上下文）。
    """
    case = {}
    try:
        case = R.cases.get(case_id) or {}
    except Exception:
        case = {}
    tid = str(case.get("tenant_id") or "")
    wid = str(case.get("workspace_id") or "")
    if not tid and not wid:
        return build(case_id, run_id)
    from . import ctx as _ctx
    # L98 P1：完整状态快照/恢复（含 system/审核模式/case 归因）
    saved = _ctx.snapshot()
    switched = (str(saved.get("tenant_id") or "") != tid
                or str(saved.get("workspace_id") or "") != wid)
    try:
        if switched:
            _ctx.set_context(tid, wid)
        return build(case_id, run_id, tenant_id=tid or None, workspace_id=wid or None)
    finally:
        if switched:
            try:
                _ctx.restore(saved)
            except Exception:
                import logging
                logging.getLogger(__name__).debug("verify ctx restore skipped",
                                                  exc_info=True)


def verify(case_id: str, run_id: str, current: dict = None) -> dict:
    """回放校验：把保存的快照与「当前运行环境」对比，判断配置是否仍一致。

    兼容：旧 v2 快照（无 schema_version/switches 等 v3 字段）只比较它自己拥有的字段，
    不把「新字段在旧快照里不存在」误报成漂移（legacy_compare=True 显式标注）。
    当前快照在项目自身租户/空间作用域构建（避免调用方上下文不同 → 假漂移）。
    """
    stored = load(case_id, run_id)
    if not stored:
        # L133：快照缺失 → 显式“不可复现”，不构建当前快照冒充（=0 也不冒充，
        # 兜底读取只在 report_block/history_view 的 current_fallback 分支显式发生）。
        return {"found": False, "replayable": False,
                "reproducible": False, "fully_reproducible": False,
                "status": "unreproducible", "code": "history_snapshot_missing",
                "source": "missing", "history_switch": history_strict_state(),
                "error": "未找到该 run 的 v2 快照（可能未保存，或该 run 早于 v2 上线）"
                         "；可用 rp snapshot show --case/--run 查看，或重跑审核生成快照"}
    cur = current or _build_in_case_scope(case_id, run_id)
    legacy_compare = not stored.get("schema_version")
    fields = _DIFF_FIELDS
    if legacy_compare:
        stored_keys = {k for k, _ in _DIFF_FIELDS if k in stored}
        fields = tuple(x for x in _DIFF_FIELDS if x[0] in stored_keys)
    elif "main_chain_switches" not in stored:
        # L53 时期 v3 快照（无 L61 主链开关块）：不把「新增字段缺失」报成漂移
        fields = tuple(x for x in _DIFF_FIELDS if x[0] != "main_chain_switches")
    changed = diff(stored, cur, fields=fields)
    stored_cf = stored.get("content_fingerprint") or {}
    cur_cf = cur.get("content_fingerprint") or {}
    content_same = None
    if stored_cf.get("sha256") and cur_cf.get("sha256"):
        content_same = stored_cf.get("sha256") == cur_cf.get("sha256")
    caveats = [
        "只校验运行配置一致性，不自动重跑历史审核；重跑需 review/manifest 链路接线",
        "外部模型提供方可能更新模型行为，配置一致不保证输出逐字一致",
        "V01 回放必须使用冻结闭包里的业务参考时间/时区与外部查询结果；"
        "不得用当天日期重新解释“有效期未过”，也不得实时重查外部来源",
        "文件完整性以原始字节 sha256 为准（document_id 不是内容标识）；"
        "同 ID 换内容必须由 execution_guard 阻断，不能靠快照 digest 静默放行",
    ]
    if legacy_compare:
        caveats.append("该快照为 v2 旧格式（无 schema_version）；按字段交集窄比，"
                       "不含 v3 开关/引擎/内容指纹字段")
    try:
        m = stored.get("model") or {}
        if m.get("enabled"):
            caveats.append("快照记录的是外部模型配置；重放仍需同一模型/端点/密钥可用")
    except Exception:
        pass
    stored_modes = _modes_of(stored)
    cur_modes = _modes_of(cur)
    stored_mc = _main_chain_summary_of(stored)
    cur_mc = _main_chain_summary_of(cur)
    # 模式是「该 run 的请求属性」，在审核上下文之外重观测不到（ctx.audit_mode 为空）；
    # 只有当前上下文能观测到模式时才比较，否则显式标 unobservable，不算漂移。
    cur_mode_observable = bool(cur_modes.get("audit_mode") or
                               cur_modes.get("ai_assist") is not None)
    mode_identical = None
    if cur_mode_observable and stored_modes.get("mode_combination"):
        mode_identical = (stored_modes.get("mode_combination")
                          == cur_modes.get("mode_combination"))
    try:
        _stored_integrity = (bool(str(stored.get("digest") or ""))
                             and digest(stored) == str(stored.get("digest")))
    except Exception:
        _stored_integrity = False
    return {"found": True, "case_id": case_id, "run_id": run_id,
            # L133：来源/可复现状态显式（可复现=冻结快照自身完整；与“当前环境是否一致”分开）
            "source": "frozen_snapshot",
            "reproducible": bool(_stored_integrity),
            "fully_reproducible": None,
            "status": "frozen" if _stored_integrity else "tampered",
            "history_switch": history_strict_state(),
            "stored_snapshot_id": stored.get("snapshot_id"),
            "current_snapshot_id": cur.get("snapshot_id"),
            "stored_digest": stored.get("digest"),
            "current_digest": cur.get("digest"),
            "stored_schema_version": stored.get("schema_version") or stored.get("schema"),
            "current_schema_version": cur.get("schema_version") or cur.get("schema"),
            "stored_snapshot_revision": stored.get("snapshot_revision") or "",
            "legacy_compare": bool(legacy_compare),
            "engine_mode": stored.get("engine_mode") or "",
            "mode_combination_stored": stored_modes.get("mode_combination") or "",
            "mode_combination_current": cur_modes.get("mode_combination") or "",
            "mode_observable_current": cur_mode_observable,
            "mode_identical": mode_identical,
            "missing_switches": list(stored.get("missing_switches") or []),
            "switches_coverage": stored.get("switches_coverage") or "",
            "main_chain_switches_coverage": stored_mc.get("coverage") or "",
            "decisive_switches_coverage": stored_mc.get("decisive_coverage") or "",
            "effective_switches_coverage": stored_mc.get("effective_coverage") or "",
            "main_chain_switches_current_coverage": cur_mc.get("coverage") or "",
            "main_chain_switches_identical":
                None if not stored_mc.get("available") else
                stored_mc.get("digest") == cur_mc.get("digest"),
            "effective_unresolved_count": len(stored_mc.get("effective_unresolved") or []),
            "packs_count": stored.get("packs_count") or 0,
            "stored_content_fingerprint": stored_cf.get("sha256") or "",
            "current_content_fingerprint": cur_cf.get("sha256") or "",
            "content_identical": content_same,
            "identical": len(changed) == 0,
            "changed": changed,
            "replayable": len(changed) == 0,
            "caveats": caveats,
            "checked_at": _now()}


def replay_context(case_id: str, run_id: str) -> dict:
    """报告/审计可引用的回放上下文：v1 manifest + v2 快照 + 漂移校验。

    L133（六视角④）：追加 ``history`` 冻结读取摘要（manifest/findings/证据/规则版本/
    本体可解析性 + 显式 reproducible/code）。快照缺失时 ``reproducible=False``
    （``code=history_snapshot_missing``），不再让 ``report_ready`` 单凭 v1 manifest
    把“不可复现”读成“可出报告即历史可信”。
    """
    from . import manifest as _manifest
    v1 = _manifest.load(case_id, run_id) or {}
    v2 = load(case_id, run_id)
    hist = history_repro_summary(case_id, run_id)
    v1_drift = []
    try:
        v1_drift = _manifest.diff(v1, _manifest.build(case_id)) if v1 else []
    except Exception:
        v1_drift = [{"field": "manifest", "note": "v1 当前值构建失败"}]
    ver = verify(case_id, run_id)
    closure = {}
    closure_guard = {}
    try:
        closure = _manifest.closure_summary(
            manifest_id=_manifest_id_for_run(case_id, run_id)) or {}
        closure_guard = verify_freeze_closure(case_id, run_id)
    except Exception as exc:
        closure = {"available": False, "error": f"{type(exc).__name__}: {str(exc)[:120]}"}
    return {
        "case_id": case_id, "run_id": run_id,
        "manifest_v1": v1,
        "snapshot_v2": v2,
        # L53：审计 trace 可直接引用的策略快照摘要（snapshot_id + 缺失开关 + 内容指纹）
        "strategy_snapshot": {
            "snapshot_id": v2.get("snapshot_id") or "",
            "schema_version": v2.get("schema_version") or v2.get("schema") or "",
            "snapshot_revision": v2.get("snapshot_revision") or "",
            "engine_mode": v2.get("engine_mode") or "",
            "mode_combination": v2.get("mode_combination") or "",
            "parser_version": v2.get("parser_version")
            or (v2.get("parser") or {}).get("version") or "",
            "missing_switches": list(v2.get("missing_switches") or []),
            "switches_coverage": v2.get("switches_coverage") or "",
            "main_chain_switches_coverage":
                v2.get("main_chain_switches_coverage") or "",
            "decisive_switches_coverage":
                v2.get("decisive_switches_coverage") or "",
            "packs_count": v2.get("packs_count") or 0,
            "content_fingerprint": ((v2.get("content_fingerprint") or {}).get("sha256") or ""),
        },
        "freeze_closure": closure,
        "freeze_closure_guard": closure_guard,
        "manifest_v1_drift": v1_drift,
        "snapshot_v2_verify": ver,
        # L133：冻结历史读取摘要（manifest/findings/证据/规则版本/本体 + reproducible）
        "history": hist,
        "reproducible": hist.get("reproducible"),
        "fully_reproducible": hist.get("fully_reproducible"),
        "status": hist.get("status") or "",
        "code": hist.get("code") or "",
        "missing": hist.get("missing") or [],
        "frozen_result_ready": bool(hist.get("snapshot_found")),
        "history_switch": hist.get("history_switch") or history_strict_state(),
        "available": bool(v1 or v2),
        # 兼容旧消费方：report_ready 只表示“有 v1/v2 可引用”，不表示可复现；
        # 可复现性看 reproducible/fully_reproducible。
        "report_ready": bool(v2 or v1),
        "note": "report/audit 可用本结构做回放引用；v1 由 audit 主链自动保存，"
                "v2/v3 在审核执行链路保存；V01 冻结闭包与守卫结论随 v2 一起引用；"
                "L133 起追加 history/reproducible，快照缺失显式不可复现，"
                "不用当前规则/本体覆盖历史",
    }


def report_block(snap: dict = None, case_id: str = "", run_id: str = "") -> dict:
    """给报告/审计页面使用的精简快照块（不含敏感字段）。

    L133（六视角④）：历史读取只认**已保存的冻结快照**。未显式传 ``snap`` 时：
      - 给了 case+run：只 ``load`` 该 run 的冻结快照；缺失时严格模式
        （``RULEPROOF_HISTORY_SNAPSHOT_STRICT`` 默认 1）返回显式“不可复现块”
        （``found=False/reproducible=False/code=history_snapshot_missing``），
        **不再 build 当前配置冒充历史**；=0 回退旧宽松行为（当前配置兜底但显式
        ``source=current_fallback/degraded=True``）。
      - 未给 case/run：保持旧契约（构建当前快照，用于“当前环境”场景，source=current）。
    """
    _state = history_strict_state()
    _source = "current"
    _degraded = False
    if snap:
        _source = "frozen_snapshot"
    elif case_id and run_id:
        snap = load(case_id, run_id)
        if snap:
            _source = "frozen_snapshot"
        elif _state.get("strict"):
            return {
                "found": False, "source": "missing", "reproducible": False,
                "degraded": True, "code": "history_snapshot_missing",
                "error": "不可复现",
                "note": ("该 run 无已保存的冻结快照：严格模式不返回当前配置伪块；"
                         "可用 rp snapshot show --case/--run 确认或重跑审核生成快照"),
                "history_switch": _state,
                "schema": None, "schema_version": "", "snapshot_id": "",
                "digest": "", "built_at": "", "model": "", "model_source": "",
                "prompt_version": "", "prompt_sha": "", "rules": "",
                "rules_count": None, "params_sha": "", "ontology_sha": "",
                "parser_sha": "", "sampling_sha": "", "executors_sha": "",
                "routing_sha": "", "content_fingerprint": "",
                "content_fingerprint_rules": "", "content_fingerprint_documents": "",
                "content_fingerprint_parsed": "", "engine_mode": "",
                "mode_combination": "", "switches_coverage": "",
                "main_chain_switches_coverage": "", "decisive_switches_coverage": "",
                "effective_switches_coverage": "", "packs_count": 0, "packs": [],
                "missing_switches": [], "cache_namespace": "",
                "tenant_workspace": "", "run_id": str(run_id or ""),
                "app_version": "", "closure_available": False,
                "closure_manifest_id": "", "closure_digest": "",
            }
        else:
            # =0 回退旧宽松行为：允许当前配置兜底，但必须显式 degraded，不标成冻结。
            snap = build(case_id, run_id)
            _source = "current_fallback"
            _degraded = True
    else:
        snap = build(case_id, run_id)
    model = snap.get("model") or {}
    _cf = snap.get("content_fingerprint") or {}
    _mode_block = _modes_of(snap)
    _mc_block = _main_chain_summary_of(snap)
    _integrity = None
    if _source == "frozen_snapshot":
        try:
            _integrity = bool(str(snap.get("digest") or "")) and digest(snap) == str(
                snap.get("digest"))
        except Exception:
            _integrity = False
    return {
        # L133：读取来源/可复现标记显式化（report/audit/CLI 可据此区分“冻结快照”
        # 与“当前配置”，快照缺失时不再出现全 None 伪块而不自知）。
        "found": True,
        "source": _source,
        "reproducible": (bool(_integrity) if _source == "frozen_snapshot"
                         else (False if _source == "current_fallback" else None)),
        "degraded": bool(_degraded),
        "history_switch": _state,
        "schema": snap.get("schema"),
        # L53 v3：报告/门禁块里显式暴露 schema_version/engine_mode/缺失开关/内容指纹，
        # 使报告与审计不必读代码当前值就能回答“这次用了哪套策略、缺什么、内容是否同输入”。
        "schema_version": snap.get("schema_version") or snap.get("schema"),
        "snapshot_id": snap.get("snapshot_id"),
        "digest": snap.get("digest"),
        "engine_mode": snap.get("engine_mode") or "",
        "parser_version": snap.get("parser_version")
        or (snap.get("parser") or {}).get("version") or "",
        "model_version": (snap.get("model_version") or {}).get("version")
        or model.get("version") or "",
        "switches_coverage": snap.get("switches_coverage") or "",
        # L61：主链 82/85/87 全覆盖 + 模式组合（同输入不同模式可区分）
        "snapshot_revision": snap.get("snapshot_revision") or "",
        "mode_combination": snap.get("mode_combination") or "",
        "audit_mode": _mode_block.get("audit_mode") or "",
        "semantic": _mode_block.get("semantic"),
        "ai_assist": _mode_block.get("ai_assist"),
        "llm_enabled": _mode_block.get("llm_enabled"),
        "main_chain_switches_coverage":
            snap.get("main_chain_switches_coverage") or "",
        "main_chain_switches_count": (snap.get("main_chain_switches") or {}).get("count") or 0,
        "decisive_switches_coverage":
            snap.get("decisive_switches_coverage") or "",
        "effective_switches_coverage":
            snap.get("effective_switches_coverage") or "",
        "packs_count": snap.get("packs_count") or 0,
        "packs": [{"id": p.get("id"), "version": p.get("version"),
                   "digest": p.get("digest")}
                  for p in ((snap.get("packs") or {}).get("packs") or [])],
        "missing_switches": list(snap.get("missing_switches") or []),
        "content_fingerprint": _cf.get("sha256") or "",
        "content_fingerprint_rules": _cf.get("rules_sha") or "",
        "content_fingerprint_documents": _cf.get("documents_sha") or "",
        "content_fingerprint_parsed": _cf.get("parsed_artifacts_sha") or "",
        "content_fingerprint_source": _cf.get("source") or "",
        "app_version": snap.get("app_version"),
        "built_at": snap.get("built_at"),
        "run_id": snap.get("run_id"),
        "tenant_workspace": f"{snap.get('tenant_id') or ''}/{snap.get('workspace_id') or ''}",
        "model": f"{model.get('provider') or ''}:{model.get('model') or ''}",
        "model_source": model.get("source"),
        "prompt_version": (snap.get("prompt") or {}).get("version"),
        "prompt_sha": (snap.get("prompt") or {}).get("sha"),
        "rules": (snap.get("rules") or {}).get("sha"),
        "rules_count": (snap.get("rules") or {}).get("count"),
        "params_sha": (snap.get("rule_params") or {}).get("sha"),
        "ontology_sha": (snap.get("ontology") or {}).get("sha"),
        "parser_sha": (snap.get("parser") or {}).get("sha"),
        "sampling_sha": (snap.get("sampling") or {}).get("sha"),
        "executors_sha": (snap.get("executors") or {}).get("sha"),
        "routing_sha": (snap.get("routing") or {}).get("sha"),
        # V01 冻结闭包（审计/报告可见；不含解析全文与密钥）
        "closure_available": bool((snap.get("freeze_closure") or {}).get("available")),
        "closure_manifest_id": (snap.get("freeze_closure") or {}).get("manifest_id"),
        "closure_digest": (snap.get("freeze_closure") or {}).get("digest"),
        "closure_files_sha": ((snap.get("freeze_closure") or {}).get("files") or {}).get("sha"),
        "closure_parsed_sha": ((snap.get("freeze_closure") or {}).get("parsed_artifacts") or {}).get("sha"),
        "closure_parser_ocr_sha": ((snap.get("freeze_closure") or {}).get("parser_ocr") or {}).get("sha"),
        "frozen_reference_time": ((snap.get("freeze_closure") or {}).get("business_reference") or {}).get("reference_time"),
        "frozen_timezone": ((snap.get("freeze_closure") or {}).get("business_reference") or {}).get("timezone"),
        "frozen_external_results": ((snap.get("freeze_closure") or {}).get("external_results") or {}).get("count"),
        "frozen_unit_dictionary_sha": ((snap.get("freeze_closure") or {}).get("unit_dictionary") or {}).get("sha"),
        "frozen_conflict_priority_sha": ((snap.get("freeze_closure") or {}).get("rule_conflict_priority") or {}).get("sha"),
        "frozen_binding_sha": ((snap.get("freeze_closure") or {}).get("binding") or {}).get("sha"),
        "frozen_binding_subset": ((snap.get("freeze_closure") or {}).get("binding") or {}).get("selected_subset_of_allowed"),
        "cache_namespace": cache_scope(tenant_id=snap.get("tenant_id") or "",
                                       workspace_id=snap.get("workspace_id") or "",
                                       version_digest=snap.get("digest") or "",
                                       prompt_version=(snap.get("prompt") or {}).get("version") or "",
                                       prompt_sha=(snap.get("prompt") or {}).get("sha") or "",
                                       model=f"{model.get('provider') or ''}:{model.get('model') or ''}")["scope_key"],
    }


# ================================================================ llm_cache 版本/租户隔离
def cache_scope(tenant_id=None, workspace_id=None, version_digest: str = "",
                prompt_version: str = "", prompt_sha: str = "", model: str = "",
                sampling_sha: str = "", purpose: str = "") -> dict:
    """构造缓存命名空间：租户/空间 + 快照版本 + 提示词 + 模型 + 采样。"""
    tid, wid = _ctx_ids(tenant_id, workspace_id)
    if not sampling_sha:
        try:
            sampling_sha = _sampling_snapshot().get("sha") or ""
        except Exception:
            sampling_sha = ""
    scope = {
        "tenant_id": tid,
        "workspace_id": wid,
        "version_digest": str(version_digest or ""),
        "prompt_version": str(prompt_version or ""),
        "prompt_sha": str(prompt_sha or ""),
        "model": str(model or ""),
        "sampling_sha": str(sampling_sha or ""),
        "purpose": str(purpose or ""),
    }
    scope["scope_key"] = _sha(json.dumps(scope, ensure_ascii=False, sort_keys=True), 24)
    return scope


def cache_key(scope: dict, raw_key: str) -> str:
    """命名空间化缓存键：换租户/版本/提示词/模型/采样都不会命中旧键。"""
    if not isinstance(scope, dict) or not scope.get("scope_key"):
        raise ValueError("cache_key 需要 cache_scope() 返回的 scope")
    return f"{CACHE_NAMESPACE_PREFIX}{scope['scope_key']}|{raw_key}"


def cache_get(scope: dict, raw_key: str):
    key = cache_key(scope, raw_key)
    try:
        rows = R.llm_cache.list("k=?", (key,))
        if rows:
            return json.loads(rows[0]["v"])
    except Exception:
        return None
    return None


def cache_put(scope: dict, raw_key: str, payload) -> str:
    key = cache_key(scope, raw_key)
    try:
        R.llm_cache.insert(id=db.new_id("lc"), k=key,
                           v=json.dumps(payload, ensure_ascii=False),
                           created_at=db.now())
    except Exception:
        # 并发写入冲突（k UNIQUE）不阻塞主流程，按已有值读取
        import logging
        logging.getLogger(__name__).debug("v2 缓存写入冲突/失败", exc_info=True)
    return key


def cache_isolation_report() -> dict:
    """缓存隔离现状（主链路 key vs v2 命名空间），供交付说明披露。"""
    return {
        "main_path": {
            "module": "app/services/auditpoints.py",
            "key_components": dict(_MAIN_PATH_CACHE_COMPONENTS),
            "tenant_isolated": bool(_MAIN_PATH_CACHE_COMPONENTS["tenant_workspace"]),
            "version_isolated": bool(_MAIN_PATH_CACHE_COMPONENTS["prompt_version"]),
            "gaps": [k for k, v in _MAIN_PATH_CACHE_COMPONENTS.items() if not v],
        },
        "v2_namespace": {
            "available": True,
            "api": "version_snapshot.cache_scope/cache_key/cache_get/cache_put",
            "dimensions": ["tenant_id", "workspace_id", "version_digest", "prompt_version",
                           "prompt_sha", "model", "sampling_sha", "purpose"],
            "prefix": CACHE_NAMESPACE_PREFIX,
            "wired_into_main_path": False,
            "note": "主链路切换需修改 app/services/auditpoints.py（不在 P1 写作用域）；"
                    "现有主链路 key 已含租户/空间+提示词版本+模型",
        },
    }


# ================================================================ L61 历史快照重放引擎
# 外部评审 I4：「同库 verify 有，历史快照 replay 无」。replay 与 verify 分工：
#   - verify：只比对**配置**（不重跑），回答「现在的环境还与快照一致吗」；
#   - replay：在 verify 基础上，用**冻结清单的规则集合 + 持久化的模式组合**重跑一次
#     审核，再比对 content_fingerprint / findings / 引文，回答「同输入重跑，结论还一致吗」。
# 诚实边界（写进返回与报告）：
#   1) 重跑是真实审核（写入新 audit_run/findings，并写 snapshot.replayed 审计），不是模拟；
#   2) 输入/快照被改（冻结闭包守卫失败、快照自身 digest 不符）→ replayable=False 并给清单，
#      不执行、不伪造一致；
#   3) 配置漂移（开关/模型/提示词/采样等变化）→ 不是「同一快照+同输入」，不执行并给 changed；
#   4) LLM 语义通道启用时输出可能天然抖动 → caveat 明示，即使 findings 不同也不称“篡改”。

_REPLAY_ENGINE = "version_snapshot.replay-v1"


def _saved_row_to_entry(key: str, value: str, updated_at: str = "") -> dict:
    tail = key[len(KEY_PREFIX):] if key.startswith(KEY_PREFIX) else key
    if ":" not in tail:
        return {}
    cid, rid = tail.split(":", 1)
    try:
        snap = json.loads(value or "{}")
    except Exception:
        return {}
    if not isinstance(snap, dict):
        return {}
    return {"snapshot": snap, "case_id": cid, "run_id": rid, "key": key,
            "updated_at": updated_at or ""}


def find_by_snapshot_id(snapshot_id: str, case_id: str = "") -> dict:
    """按 snapshot_id 反查已保存快照（跨 case；给了 case_id 时优先该 case）。"""
    sid = str(snapshot_id or "").strip()
    if not sid:
        return {}
    prefixes = ([f"{KEY_PREFIX}{case_id}:"] if case_id else []) + [KEY_PREFIX]
    for prefix in prefixes:
        try:
            with db.session() as c:
                rows = c.execute(
                    "SELECT key,value,updated_at FROM sys_config WHERE key LIKE ? "
                    "ORDER BY updated_at DESC LIMIT 500",
                    (prefix + "%",)).fetchall()
        except Exception:
            rows = []
        for r in rows:
            entry = _saved_row_to_entry(str(r["key"] or ""), str(r["value"] or ""),
                                        str(r["updated_at"] or ""))
            if entry and str(entry["snapshot"].get("snapshot_id") or "") == sid:
                return entry
    return {}


def _latest_run_id(case_id: str) -> str:
    try:
        row = R.cases.get(case_id) or {}
        rid = str(row.get("last_run_id") or "")
        if rid:
            return rid
    except Exception:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    try:
        with db.session() as c:
            row = c.execute("SELECT id FROM audit_run WHERE case_id=? ORDER BY rowid DESC "
                            "LIMIT 1", (case_id,)).fetchone()
        return str(row["id"] if row else "")
    except Exception:
        return ""


def _frozen_rule_codes(case_id: str, run_id: str) -> dict:
    """该 run 冻结清单里的规则编码（重放必须用同一规则集合，不能用「当前全部生效规则」）。"""
    mid = _manifest_id_for_run(case_id, run_id)
    if not mid:
        return {"manifest_id": "", "codes": [], "available": False,
                "reason": "no_manifest_for_run"}
    try:
        with db.session() as c:
            row = c.execute("SELECT rules_json FROM audit_manifest WHERE id=?",
                            (mid,)).fetchone()
        raw = str(row["rules_json"] or "") if row else ""
        codes = sorted({str(x.get("code") or "") for x in json.loads(raw or "[]")
                        if isinstance(x, dict) and str(x.get("code") or "")})
    except Exception as exc:  # noqa: BLE001 - 取不到规则集合就不能声称同一输入
        return {"manifest_id": mid, "codes": [], "available": False,
                "reason": f"{type(exc).__name__}: {str(exc)[:160]}"}
    if not codes:
        return {"manifest_id": mid, "codes": [], "available": False,
                "reason": "frozen_manifest_rules_empty"}
    return {"manifest_id": mid, "codes": codes, "available": True, "reason": ""}


def findings_for_run(case_id: str, run_id: str) -> list:
    """按 run 读取结论（finding×evidence×anchor），归一成可跨库/跨 run 比对的单元。

    排除随机 id / 人工复核字段（status/review_*）/ 时间戳：只保留判定语义
    （code/state/severity/certainty/title/summary/engine）+ 逐字引文 + 定位。
    """
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT f.id AS fid, f.rule_id AS rule_id, f.state AS state, "
                " f.severity AS severity, f.certainty AS certainty, f.title AS title, "
                " f.summary AS summary, f.engine AS engine, f.verbatim_quote AS verbatim_quote, "
                " e.excerpt AS excerpt, a.quote AS anchor_quote, a.locator AS locator "
                "FROM finding f LEFT JOIN evidence e ON e.finding_id=f.id "
                "LEFT JOIN anchor a ON a.id=e.anchor_id "
                "WHERE f.case_id=? AND f.run_id=? ORDER BY f.rowid, e.rowid",
                (case_id, run_id)).fetchall()
    except Exception:
        return []
    grouped = {}
    order = []
    for r in rows:
        fid = str(r["fid"] or "")
        if fid not in grouped:
            grouped[fid] = {"code": str(r["rule_id"] or ""),
                            "state": str(r["state"] or ""),
                            "severity": str(r["severity"] or ""),
                            "certainty": str(r["certainty"] or ""),
                            "title": str(r["title"] or ""),
                            "summary": str(r["summary"] or ""),
                            "engine": str(r["engine"] or ""),
                            "quotes": set(), "locators": set()}
            order.append(fid)
        item = grouped[fid]
        for q in (r["excerpt"], r["anchor_quote"], r["verbatim_quote"]):
            q = str(q or "").strip()
            if q:
                item["quotes"].add(q)
        loc = str(r["locator"] or "").strip()
        if loc:
            item["locators"].add(loc)
    out = []
    for fid in order:
        item = grouped[fid]
        item["quotes"] = sorted(item["quotes"])
        item["locators"] = sorted(item["locators"])
        out.append(item)
    out.sort(key=lambda x: (x["code"], x["state"], x["title"], x["summary"],
                            json.dumps(x["quotes"], ensure_ascii=False)))
    return out


def _findings_diff(stored: list, replayed: list) -> dict:
    """两份 run 结论差异：按「同一条 finding 的完整语义指纹」做多重集差分。"""
    def _key(x):
        return json.dumps(x, ensure_ascii=False, sort_keys=True)

    a = [_key(x) for x in (stored or [])]
    b = [_key(x) for x in (replayed or [])]
    a_set, b_set = set(a), set(b)
    added = [json.loads(x) for x in b if x not in a_set]
    removed = [json.loads(x) for x in a if x not in b_set]
    # 同 code+state 但内容变化（引文/定位/标题/摘要）→ changed 计数
    def _groups(items):
        g = {}
        for x in items or []:
            g.setdefault((x.get("code"), x.get("state")), []).append(_key(x))
        return {k: sorted(v) for k, v in g.items()}

    ga, gb = _groups(stored), _groups(replayed)
    changed_groups = [{"code": k[0], "state": k[1]}
                      for k in sorted(set(ga) & set(gb))
                      if ga[k] != gb[k]]
    qa, qb = [], []
    for x in stored or []:
        qa.extend(x.get("quotes") or [])
    for x in replayed or []:
        qb.extend(x.get("quotes") or [])
    from collections import Counter
    ca, cb = Counter(qa), Counter(qb)
    quotes_added = sorted((cb - ca).elements())
    quotes_removed = sorted((ca - cb).elements())
    return {"identical": (a_set == b_set),
            "stored_count": len(stored or []),
            "replayed_count": len(replayed or []),
            "stored_fingerprint": _json_sha(stored or []),
            "replayed_fingerprint": _json_sha(replayed or []),
            "added": added[:50], "removed": removed[:50],
            "added_count": len(added), "removed_count": len(removed),
            "changed_groups": changed_groups[:50],
            "changed_count": len(changed_groups),
            "quotes": {"identical": quotes_added == [] and quotes_removed == [],
                       "stored_count": len(qa), "replayed_count": len(qb),
                       "added": quotes_added[:50], "removed": quotes_removed[:50]},
            }


def _legacy_modes(stored: dict) -> dict:
    """从 L53 engine 块回退推导模式（历史快照无 L61 modes 块时用）。"""
    engine = stored.get("engine") if isinstance(stored.get("engine"), dict) else {}
    audit_mode = str(engine.get("audit_mode") or "")
    if "ai_assist" in engine:
        ai_assist = engine.get("ai_assist")
    elif audit_mode == "assisted":
        ai_assist = True
    elif audit_mode == "manual":
        ai_assist = False
    else:
        ai_assist = None
    llm_enabled = engine.get("llm_enabled")
    if llm_enabled is None:
        llm_enabled = bool((stored.get("model") or {}).get("enabled"))
    semantic = engine.get("semantic")
    if semantic is None:
        semantic = bool(llm_enabled)
    return {"engine_mode": stored.get("engine_mode") or engine.get("engine_mode") or "",
            "audit_mode": audit_mode, "ai_assist": ai_assist,
            "semantic": bool(semantic), "llm_enabled": bool(llm_enabled),
            "doc_type": str(engine.get("doc_type") or ""),
            "mode_combination": str(engine.get("mode_combination") or ""),
            "source": "engine_block_fallback" if engine else "not_observable"}


def _same_legacy_placeholder_packs(stored: dict, current: dict) -> bool:
    """L53 时期 packs 是占位（reserved=True，packs/enables/overrides 空）；
    当前 packs 已改为真实摘要（reserved=False）。两者「都无启用 pack」时不算漂移。"""
    sp = stored.get("packs") if isinstance(stored.get("packs"), dict) else {}
    cp = current.get("packs") if isinstance(current.get("packs"), dict) else {}
    if not sp or not cp:
        return False
    return (sp.get("reserved") is True and not (sp.get("packs") or [])
            and not (sp.get("enables") or []) and not (cp.get("packs") or []))




# ================================================================ L133 历史审核结果冻结读取（可复现）
# 背景（build52 六视角④）：审核执行时已把本轮运行配置冻结进 ``runsnapshot:v2``
# （manifest / 冻结闭包 / 规则版本 / 本体 / 开关 / 模型 / 解析器），但读取侧此前只有两档：
#   ① ``load()`` 原始读（谁调谁自己解释，缺快照时无统一口径）；
#   ② 报告/门禁只读“最近一次 run”（``case.last_run_id``），历史 run 无入口。
# 后果：规则库/因子/本体升级后，3 个月前审核的工艺书**结果仍在库里**，但没有一处读取面
# 能证明“这是当时冻结的 manifest/findings/证据/开关/模型/解析器，没有被新规则覆盖”；
# 快照缺失时 ``report_block(case, run)`` 只回一个全 None 的伪块、``replay_context`` 仍给
# ``report_ready=True``，等于静默把“不可复现”伪装成“可读”。
#
# 本段补齐**只读**的冻结读取面（不写业务数据、不重跑、不改历史 run 结论）：
#   - ``history_view(case_id, run_id)``：单入口返回
#     frozen.manifest / frozen.findings / frozen.evidence / frozen.report /
#     frozen.switches（+ model / parser / rules / ontology 版本）+
#     current（仅用于对比，永不回填 frozen）+ diff（单独标注，不覆盖历史）+
#     旧版本规则/本体可解析性 + reproducible/status 显式状态。
#   - ``report_block`` / ``verify`` / ``replay_context`` / ``replay`` 接入严格口径：
#     快照缺失 → 显式 ``不可复现``（code=history_snapshot_missing），不再静默用当前配置。
#   - replay 增加冻结结果摘要、冻结规则版本漂移检测（防“用当前发布版本冒充历史版本”）
#     与幂等键（同一来源 run+快照+环境重复回放 → 结果指纹稳定、回放键可核对）。
#
# 开关 ``RULEPROOF_HISTORY_SNAPSHOT_STRICT``（默认 1）：
#   1 = 严格：快照缺失 → 显式不可复现，绝不拿当前配置冒充当时结果；
#   0 = 回退旧宽松行为：允许当前配置兜底，但返回值必须显式标注
#       ``source=current_fallback/degraded=True``（可回退，不可再静默）。
HISTORY_ENGINE = "version_snapshot.history-v1"
HISTORY_STRICT_ENV = "RULEPROOF_HISTORY_SNAPSHOT_STRICT"
HISTORY_STRICT_DEFAULT = "1"
HISTORY_FROZEN_DIMENSIONS = (
    "manifest", "findings", "evidence", "report", "switches", "model", "parser",
    "rules", "ontology",
)
# 差异字段 → 升级类别：让“哪些升级被标注、但历史结果不变”可以机读区分。
_HISTORY_FIELD_IMPACT = {
    "rules": "rule_library_upgraded",
    "rule_params": "factor_params_upgraded",
    "ontology": "ontology_upgraded",
    "model": "model_changed",
    "model_version": "model_changed",
    "prompt": "prompt_changed",
    "parser": "parser_changed",
    "sampling": "sampling_changed",
    "executors": "executor_code_changed",
    "routing": "routing_code_changed",
    "audit_library": "audit_library_changed",
    "decision_tables": "decision_tables_changed",
    "switches": "switches_changed",
    "main_chain_switches": "switches_changed",
    "engine_mode": "engine_mode_changed",
    "packs": "rule_packs_changed",
    "files": "input_files_changed",
    "files_digest": "input_files_changed",
    "freeze_closure": "input_closure_changed",
    "content_fingerprint": "input_or_rules_changed",
}


def history_strict_enabled() -> bool:
    """``RULEPROOF_HISTORY_SNAPSHOT_STRICT``（默认 1）：=0 回退旧宽松读取。"""
    raw = os.environ.get(HISTORY_STRICT_ENV)
    if raw is None or str(raw).strip() == "":
        raw = HISTORY_STRICT_DEFAULT
    return str(raw).strip().lower() not in ("0", "false", "off", "no")


def history_strict_state() -> dict:
    """开关状态（报告/审计/测试共用同一解析口径）。"""
    raw = os.environ.get(HISTORY_STRICT_ENV)
    explicit = raw is not None and str(raw).strip() != ""
    value = str(raw).strip() if explicit else HISTORY_STRICT_DEFAULT
    strict = history_strict_enabled()
    return {
        "switch": HISTORY_STRICT_ENV,
        "value": value,
        "default": HISTORY_STRICT_DEFAULT,
        "strict": strict,
        "source": "env" if explicit else "default",
        "mode": "strict_frozen_only" if strict else "legacy_current_fallback",
        "note": ("严格：历史读取只认冻结快照，缺失即显式不可复现"
                 if strict else
                 "回退：快照缺失时允许当前配置兜底，但必须显式标注 current_fallback/"
                 "degraded，不可冒充当时结果"),
    }


# ---------------------------------------------------------------- 冻结读取底层（直连 SQL，绕开当前 ctx）
def _history_run_row(run_id: str) -> dict:
    """直读 audit_run（不经过租户上下文过滤；历史 run 的 tenant 列可能为 NULL）。"""
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT id, case_id, created_at, created_by, trace_json, manifest_id "
                "FROM audit_run WHERE id=?", (str(run_id or ""),)).fetchone()
        return dict(row) if row else {}
    except Exception:
        # 旧库未跑 init_db/迁移时可能没有 manifest_id 列：退回基础列，仍可判 run 是否存在
        try:
            with db.session() as c:
                row = c.execute(
                    "SELECT id, case_id, created_at, created_by, trace_json "
                    "FROM audit_run WHERE id=?", (str(run_id or ""),)).fetchone()
            return dict(row) if row else {}
        except Exception:
            return {}


def _history_manifest_row(case_id: str, run_id: str) -> dict:
    """该 run 冻结的 audit_manifest 行（冻结后不可变；缺失=无清单，不拿当前清单兜底）。"""
    cols = ("id, case_id, run_id, source, status, objects_json, rules_json, items_json, "
            "hash, created_at, created_by")
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT " + cols + " FROM audit_manifest WHERE run_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                (str(run_id or ""),)).fetchone()
            if not row:
                # 历史数据 audit_manifest.run_id 为空：仅按该 run 已登记的 manifest_id 反查，
                # 绝不按 case 取“最新清单”（那会把新规则结果冒充历史）。
                mrow = c.execute("SELECT manifest_id FROM audit_run WHERE id=?",
                                 (str(run_id or ""),)).fetchone()
                mid = str((mrow["manifest_id"] if mrow else "") or "")
                if mid:
                    row = c.execute("SELECT " + cols + " FROM audit_manifest WHERE id=?",
                                    (mid,)).fetchone()
        return dict(row) if row else {}
    except Exception:
        return {}


def _history_manifest_id(case_id: str, run_id: str, mrow: dict = None) -> str:
    mrow = mrow or _history_manifest_row(case_id, run_id)
    if mrow.get("id"):
        return str(mrow.get("id") or "")
    try:
        mid = _manifest_id_for_run(case_id, run_id)
        return str(mid or "")
    except Exception:
        return ""


def _history_evidence(case_id: str, run_id: str) -> dict:
    """冻结证据（finding×evidence×anchor）的行指纹：历史结论的证据不能被新库改写。"""
    rows = []
    try:
        with db.session() as c:
            cur = c.execute(
                "SELECT f.id AS finding_id, e.excerpt AS excerpt, e.label AS label, "
                " a.locator AS locator, a.quote AS anchor_quote "
                "FROM finding f LEFT JOIN evidence e ON e.finding_id=f.id "
                "LEFT JOIN anchor a ON a.id=e.anchor_id "
                "WHERE f.case_id=? AND f.run_id=? ORDER BY f.rowid, e.rowid",
                (str(case_id or ""), str(run_id or ""))).fetchall()
            for r in cur:
                rows.append({"finding_id": str(r["finding_id"] or ""),
                             "excerpt": str(r["excerpt"] or ""),
                             "label": str(r["label"] or ""),
                             "locator": str(r["locator"] or ""),
                             "anchor_quote": str(r["anchor_quote"] or "")})
    except Exception as exc:
        return {"available": False, "count": 0, "sha": "", "items": [],
                "error": "%s: %s" % (type(exc).__name__, str(exc)[:160])}
    return {"available": True, "count": len(rows), "sha": _json_sha(rows, 24),
            "items": rows[:100], "truncated": len(rows) > 100}


def _json_contains_exact(obj, needle: str, depth: int = 0) -> bool:
    """递归判断 JSON 中是否出现与 needle **完全相等**的字符串值。

    用于报告行归属：不能用 ``needle in summary_json`` 的子串匹配（``run-a`` 会误命中
    ``run-a2``）。只比字符串值，不做包含判断。
    """
    if depth > 12 or not needle:
        return False
    if isinstance(obj, str):
        return obj == needle
    if isinstance(obj, dict):
        return any(_json_contains_exact(k, needle, depth + 1)
                   or _json_contains_exact(v, needle, depth + 1)
                   for k, v in obj.items())
    if isinstance(obj, (list, tuple)):
        return any(_json_contains_exact(x, needle, depth + 1) for x in obj)
    return False


def _history_reports(case_id: str, run_id: str) -> dict:
    """该 run 的已落库报告行（只取元数据；报告正文按需从冻结 findings 重建）。"""
    out = []
    rid = str(run_id or "")
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT id, version, status, created_at, content_hash, summary_json "
                "FROM report WHERE case_id=? ORDER BY created_at DESC",
                (str(case_id or ""),)).fetchall()
        for r in rows:
            summary_raw = str(r["summary_json"] or "")
            if rid:
                try:
                    if not _json_contains_exact(json.loads(summary_raw), rid):
                        continue
                except Exception:
                    # 非 JSON 摘要：退回精确子串（带边界）判断，避免把别 run 认成本 run
                    if ('"' + rid + '"') not in summary_raw:
                        continue
            out.append({"report_id": str(r["id"] or ""),
                        "version": str(r["version"] or ""),
                        "status": str(r["status"] or ""),
                        "created_at": str(r["created_at"] or ""),
                        "content_hash": str(r["content_hash"] or "")})
    except Exception as exc:
        return {"available": False, "count": 0, "items": [], "sha": "",
                "error": "%s: %s" % (type(exc).__name__, str(exc)[:160])}
    return {"available": True, "count": len(out), "items": out[:20],
            "sha": _json_sha(out, 24),
            "note": "报告行只按 summary_json 中引用的 run_id 精确归属；无行不等于不可复现"
                    "（可由冻结 findings 重建），结论以历史 run 实际结果为准"}


def _history_rule_content_sha(version_row: dict) -> str:
    """规则版本内容哈希（与 manifest._rule_version_content_sha 同算法，全量 sha256）。"""
    row = version_row or {}
    content = "\n".join(str(row.get(k) or "") for k in
                        ("slots_json", "evidence_json", "tests_json"))
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _history_rule_versions(case_id: str, run_id: str) -> dict:
    """冻结时的规则版本是否仍可解析（旧版本 slots/evidence/tests 原样可读）。

    优先级：冻结闭包 ``rule_versions``（version_id + content_sha，最强证据）
    → 旧清单回退 ``audit_manifest.rules_json`` 按冻结 version 号反查版本行。
    不读“当前生效版本”；旧版本被改写/删除 → 显式 ``parseable=False``，不静默换新版本。
    """
    out = {"manifest_id": "", "available": False, "source": "", "count": 0,
           "items": [], "all_parseable": False, "content_unchanged": None,
           "missing": [], "changed": [], "reason": "", "note": ""}
    mrow = _history_manifest_row(case_id, run_id)
    mid = _history_manifest_id(case_id, run_id, mrow)
    out["manifest_id"] = mid
    if not mid:
        out["reason"] = "no_manifest_for_run"
        out["note"] = "该 run 无冻结清单（legacy 链路），旧版本规则无可解析依据"
        return out
    closure = {}
    try:
        from . import manifest as _mf_hist
        closure = _mf_hist.load_closure(mid) or {}
    except Exception as exc:  # noqa: BLE001 - 闭包读失败不影响 manifest 回退
        out["reason"] = "closure_read_error"
        out["note"] = "%s: %s" % (type(exc).__name__, str(exc)[:160])
        closure = {}
    rows = closure.get("rule_versions") or []
    if rows:
        out["source"] = "freeze_closure"
        for row in rows:
            row = row if isinstance(row, dict) else {}
            vid = str(row.get("version_id") or "")
            item = {"rule_id": str(row.get("rule_id") or ""),
                    "code": str(row.get("code") or ""),
                    "version": str(row.get("version") or ""),
                    "version_id": vid,
                    "frozen_content_sha": str(row.get("content_sha") or ""),
                    "live_content_sha": "", "parseable": False,
                    "content_sha_match": None, "content_sha_checked": False,
                    "live_status": "", "reason": ""}
            if not vid:
                item["reason"] = "frozen_version_id_missing"
                out["missing"].append({k: item[k] for k in ("code", "version", "rule_id")})
                out["items"].append(item)
                continue
            live = {}
            try:
                with db.session() as c:
                    r = c.execute("SELECT id, rule_id, version, slots_json, evidence_json, "
                                  "tests_json, status, published_at FROM rule_version WHERE id=?",
                                  (vid,)).fetchone()
                live = dict(r) if r else {}
            except Exception:
                live = {}
            if not live:
                item["reason"] = "rule_version_missing"
                out["missing"].append({k: item[k] for k in ("code", "version", "rule_id")})
                out["items"].append(item)
                continue
            item["parseable"] = True
            item["live_status"] = str(live.get("status") or "")
            item["live_content_sha"] = _history_rule_content_sha(live)
            if item["frozen_content_sha"]:
                item["content_sha_checked"] = True
                item["content_sha_match"] = (
                    item["live_content_sha"] == item["frozen_content_sha"])
                if not item["content_sha_match"]:
                    item["reason"] = "rule_version_content_changed"
                    out["changed"].append({
                        "code": item["code"], "version": item["version"],
                        "frozen_content_sha": item["frozen_content_sha"],
                        "live_content_sha": item["live_content_sha"]})
            out["items"].append(item)
    if not out["items"]:
        # 旧清单（无闭包）：按 audit_manifest.rules_json 的冻结版本号反查版本行；
        # 只能证明“行还在/内容未校验”，显式记 source 与 content_sha_checked=False。
        entries = []
        try:
            entries = json.loads(mrow.get("rules_json") or "[]")
        except Exception:
            entries = []
        for ent in entries if isinstance(entries, list) else []:
            if not isinstance(ent, dict):
                continue
            code, ver, rule_ref = (str(ent.get("code") or ""),
                                   str(ent.get("version") or ""),
                                   str(ent.get("rule_id") or ""))
            item = {"rule_id": rule_ref, "code": code, "version": ver,
                    "version_id": str(ent.get("version_id") or ""),
                    "frozen_content_sha": str(ent.get("content_sha") or ""),
                    "live_content_sha": "", "parseable": False,
                    "content_sha_match": None, "content_sha_checked": False,
                    "live_status": "", "reason": ""}
            live = {}
            try:
                with db.session() as c:
                    if item["version_id"]:
                        r = c.execute("SELECT * FROM rule_version WHERE id=?",
                                      (item["version_id"],)).fetchone()
                    else:
                        r = c.execute("SELECT * FROM rule_version WHERE rule_id=? AND version=? "
                                      "ORDER BY rowid DESC LIMIT 1", (rule_ref, ver)).fetchone()
                live = dict(r) if r else {}
            except Exception:
                live = {}
            if live:
                item["parseable"] = True
                item["version_id"] = str(live.get("id") or item["version_id"])
                item["live_status"] = str(live.get("status") or "")
                item["live_content_sha"] = _history_rule_content_sha(live)
                if item["frozen_content_sha"]:
                    item["content_sha_checked"] = True
                    item["content_sha_match"] = (
                        item["live_content_sha"] == item["frozen_content_sha"])
                else:
                    item["reason"] = "content_sha_unavailable(legacy_manifest)"
            else:
                item["reason"] = "frozen_version_row_missing"
                out["missing"].append({"code": code, "version": ver,
                                       "rule_id": rule_ref})
            out["items"].append(item)
        if out["items"]:
            out["source"] = "manifest_rules_only"
            out["note"] = ("无冻结闭包（旧清单）：只能按冻结 version 反查版本行，"
                           "旧版本内容哈希不可校验（content_sha_checked=False）")
    out["count"] = len(out["items"])
    out["available"] = bool(out["items"])
    if out["items"]:
        out["all_parseable"] = all(bool(x.get("parseable")) for x in out["items"])
        checked = [x for x in out["items"] if x.get("content_sha_checked")]
        out["content_unchanged"] = (all(x.get("content_sha_match") for x in checked)
                                    if checked else None)
    if not out.get("note"):
        if not out["available"]:
            out["note"] = "清单内没有可解析的规则版本（rules_json 为空或结构异常）"
        elif out["all_parseable"]:
            out["note"] = "冻结时的规则版本仍可按 version_id 原样解析；不读当前生效版本"
        else:
            out["note"] = "存在无法解析/被改写的冻结规则版本（见 missing/changed），不得用当前版本顶替"
    return out


def _frozen_rule_version_drift(case_id: str, run_id: str) -> dict:
    """冻结规则版本 vs 当前生效版本：判断“重跑会不会读到新规则内容”。

    replay 用冻结清单的**规则码**调 project.audit，而冻结/执行取的是“当前 published
    版本”；规则升级后同一 code 的生效版本已变 → 重跑会用新版本内容。必须在 replay 前
    显式检出并阻断（code=frozen_rule_version_drift），不得用新规则冒充历史。
    """
    rules = _history_rule_versions(case_id, run_id)
    items = []
    for item in rules.get("items") or []:
        rule_ref = str(item.get("rule_id") or "")
        if not rule_ref:
            continue
        cur = {}
        try:
            with db.session() as c:
                r = c.execute("SELECT id, version, status, published_at FROM rule_version "
                              "WHERE rule_id=? AND status='published' "
                              "ORDER BY published_at DESC, rowid DESC LIMIT 1",
                              (rule_ref,)).fetchone()
            cur = dict(r) if r else {}
        except Exception:
            cur = {}
        frozen_vid = str(item.get("version_id") or "")
        if not cur:
            items.append({"code": item.get("code") or "", "rule_id": rule_ref,
                          "frozen_version": item.get("version") or "",
                          "frozen_version_id": frozen_vid,
                          "current_version": "", "current_version_id": "",
                          "reason": "no_current_published_version"})
            continue
        if frozen_vid and str(cur.get("id") or "") != frozen_vid:
            items.append({"code": item.get("code") or "", "rule_id": rule_ref,
                          "frozen_version": item.get("version") or "",
                          "frozen_version_id": frozen_vid,
                          "current_version": str(cur.get("version") or ""),
                          "current_version_id": str(cur.get("id") or ""),
                          "reason": "published_version_changed"})
    return {"drifted": bool(items), "items": items[:50], "count": len(items),
            "frozen_rules_available": bool(rules.get("available")),
            "rules_all_parseable": bool(rules.get("all_parseable")),
            "note": ("当前生效版本与冻结版本不一致：重跑会读到新规则内容，拒绝冒充历史"
                     if items else
                     "当前生效版本=冻结版本（同 version_id），冻结规则内容可原样执行的证据齐备"
                     if rules.get("available") else
                     "无冻结规则版本记录，无法证明重跑用的是历史版本")}


def _history_ontology(case_id: str, run_id: str, stored: dict = None) -> dict:
    """冻结时的本体/术语快照是否仍可解析（D4 只读冻结 binding，不读实时本体）。"""
    out = {"manifest_id": "", "available": False, "parseable": False,
           "frozen_sha": "", "closure_ontology_sha": "", "sha_match": None,
           "entity_count": None, "alias_count": None, "term_count": None,
           "relation_count": None, "sources": {}, "reason": "", "note": ""}
    mrow = _history_manifest_row(case_id, run_id)
    mid = _history_manifest_id(case_id, run_id, mrow)
    out["manifest_id"] = mid
    if not mid:
        out["reason"] = "no_manifest_for_run"
        out["note"] = "该 run 无冻结清单，本体快照不可用"
        return out
    binding = {}
    try:
        from . import manifest as _mf_hist
        binding = _mf_hist.load_ontology_snapshot(mid) or {}
    except Exception as exc:  # noqa: BLE001
        out["reason"] = "ontology_snapshot_read_error"
        out["note"] = "%s: %s" % (type(exc).__name__, str(exc)[:160])
        return out
    out["available"] = bool(binding)
    out["parseable"] = isinstance(binding, dict) and bool(binding)
    if binding:
        out["frozen_sha"] = str(binding.get("sha") or "")
        out["entity_count"] = len(binding.get("entities") or [])
        out["alias_count"] = sum(len(v or []) for v in (binding.get("aliases") or {}).values())
        out["term_count"] = len(binding.get("terms") or [])
        out["relation_count"] = len(binding.get("relations") or [])
        out["sources"] = binding.get("sources") or {}
    snap = stored if isinstance(stored, dict) else (load(case_id, run_id) or {})
    closure_onto = ((snap.get("freeze_closure") or {}).get("ontology") or {})
    out["closure_ontology_sha"] = str(closure_onto.get("sha") or "")
    if binding and out["closure_ontology_sha"]:
        out["sha_match"] = (out["frozen_sha"] == out["closure_ontology_sha"])
    if not out["available"]:
        out["reason"] = "ontology_snapshot_missing"
        out["note"] = ("该 run 无冻结本体快照（旧清单未落 manifest_ontology）；"
                       "不能用当前本体顶替历史 D4 取数口径")
    elif out["sha_match"] is False:
        out["note"] = "冻结本体快照与冻结闭包登记的 ontology sha 不一致（被改写/落库异常），需审计"
    else:
        out["note"] = "冻结本体/术语快照可按 manifest_id 原样解析；不读实时本体"
    return out


def _history_manifest_summary(case_id: str, run_id: str, mrow: dict = None) -> dict:
    """冻结 manifest 摘要（v1 baseline：manifest:<case>:<run>）+ audit_manifest 行。"""
    mrow = mrow if isinstance(mrow, dict) and mrow else _history_manifest_row(case_id, run_id)
    v1 = {}
    try:
        from . import manifest as _mf_hist
        v1 = _mf_hist.load(case_id, run_id) or {}
    except Exception:
        v1 = {}
    out = {"manifest_id": str(mrow.get("id") or ""),
           "audit_manifest_found": bool(mrow),
           "v1_found": bool(v1),
           "hash": str(mrow.get("hash") or ""),
           "source": str(mrow.get("source") or ""),
           "status": str(mrow.get("status") or ""),
           "created_at": str(mrow.get("created_at") or ""),
           "rules_count": None, "items_count": None, "objects_count": None,
           "v1": {}, "note": ""}
    for key, col in (("rules_count", "rules_json"), ("items_count", "items_json"),
                     ("objects_count", "objects_json")):
        try:
            out[key] = len(json.loads(mrow.get(col) or "[]"))
        except Exception:
            out[key] = None
    if v1:
        out["v1"] = {
            "created_at": v1.get("created_at") or "",
            "rules": v1.get("rules") or {},
            "ontology_sha": v1.get("ontology_sha") or "",
            "params_sha": v1.get("params_sha") or "",
            "parser": {"sha": (v1.get("parser") or {}).get("sha") or "",
                       "sha_v01": (v1.get("parser") or {}).get("sha_v01") or ""},
            "model": v1.get("model") or {},
            "prompt_version": v1.get("prompt_version") or "",
            "files": [{"name": f.get("name") or "", "hash": f.get("hash") or ""}
                      for f in (v1.get("files") or [])],
            "units_sha": v1.get("units_sha") or "",
            "conflict_priority_sha": v1.get("conflict_priority_sha") or "",
        }
    if not mrow:
        out["note"] = "该 run 无 audit_manifest 冻结清单；manifest 维度不可复现"
    elif not v1:
        out["note"] = "audit_manifest 存在但 v1 manifest 键缺失；清单仍可读（audit_manifest 行）"
    else:
        out["note"] = "manifest 为审核时冻结（audit_manifest + manifest v1 键），不读当前清单"
    return out


def _history_frozen_content(case_id: str, run_id: str, stored: dict,
                            findings: list = None) -> dict:
    """冻结结果内容：manifest / findings / evidence / report / rules / ontology + 配置块。"""
    stored = stored or {}
    mrow = _history_manifest_row(case_id, run_id)
    findings = findings if findings is not None else findings_for_run(case_id, run_id)
    try:
        rep = report_block(stored)
    except Exception as exc:  # noqa: BLE001 - 配置块读失败不影响结果块
        rep = {"error": "%s: %s" % (type(exc).__name__, str(exc)[:160])}
    return {
        "manifest": _history_manifest_summary(case_id, run_id, mrow),
        "findings": {"available": True, "count": len(findings or []),
                     "sha": _json_sha(findings or [], 24),
                     "items": (findings or [])[:100],
                     "truncated": len(findings or []) > 100,
                     "note": "按 run_id 直读历史 finding（该 run 冻结结论，不随规则升级重算）"},
        "evidence": _history_evidence(case_id, run_id),
        "report": _history_reports(case_id, run_id),
        "rules": _history_rule_versions(case_id, run_id),
        "ontology": _history_ontology(case_id, run_id, stored),
        # 配置维度（当时冻结的开关/模型/解析器/提示词/规则/本体哈希）
        "snapshot": rep,
        "config_summary": {
            "snapshot_id": stored.get("snapshot_id") or "",
            "digest": stored.get("digest") or "",
            "schema_version": stored.get("schema_version") or stored.get("schema") or "",
            "snapshot_revision": stored.get("snapshot_revision") or "",
            "built_at": stored.get("built_at") or "",
            "switches_coverage": stored.get("switches_coverage") or "",
            "main_chain_switches_coverage":
                stored.get("main_chain_switches_coverage") or "",
            "decisive_switches_coverage":
                stored.get("decisive_switches_coverage") or "",
            "engine_mode": stored.get("engine_mode") or "",
            "mode_combination": stored.get("mode_combination") or "",
            "model": ((stored.get("model") or {}).get("model") or ""),
            "model_provider": ((stored.get("model") or {}).get("provider") or ""),
            "model_version": (stored.get("model_version") or {}).get("version") or "",
            "parser_version": stored.get("parser_version")
            or (stored.get("parser") or {}).get("version") or "",
            "parser_sha": (stored.get("parser") or {}).get("sha") or "",
            "prompt_version": (stored.get("prompt") or {}).get("version") or "",
            "rules_sha": (stored.get("rules") or {}).get("sha") or "",
            "rules_count": (stored.get("rules") or {}).get("count"),
            "ontology_sha": (stored.get("ontology") or {}).get("sha") or "",
            "params_sha": (stored.get("rule_params") or {}).get("sha") or "",
            "content_fingerprint":
                ((stored.get("content_fingerprint") or {}).get("sha256") or ""),
        },
    }


def _history_current_summary(cur: dict) -> dict:
    """当前环境摘要（**只用于差异对比**；绝不回填 frozen 字段）。"""
    cur = cur or {}
    return {
        "snapshot_id": cur.get("snapshot_id") or "",
        "digest": cur.get("digest") or "",
        "schema_version": cur.get("schema_version") or cur.get("schema") or "",
        "built_at": cur.get("built_at") or "",
        "rules": {"count": (cur.get("rules") or {}).get("count"),
                  "sha": (cur.get("rules") or {}).get("sha") or ""},
        "rule_params": {"sha": (cur.get("rule_params") or {}).get("sha") or ""},
        "ontology": {"sha": (cur.get("ontology") or {}).get("sha") or "",
                     "counts": (cur.get("ontology") or {}).get("counts") or {}},
        "model": {"provider": (cur.get("model") or {}).get("provider") or "",
                  "model": (cur.get("model") or {}).get("model") or "",
                  "enabled": (cur.get("model") or {}).get("enabled")},
        "parser": {"sha": (cur.get("parser") or {}).get("sha") or "",
                   "version": (cur.get("parser") or {}).get("version") or ""},
        "prompt": {"version": (cur.get("prompt") or {}).get("version") or "",
                   "sha": (cur.get("prompt") or {}).get("sha") or ""},
        "switches_coverage": cur.get("switches_coverage") or "",
        "main_chain_switches_coverage":
            cur.get("main_chain_switches_coverage") or "",
        "engine_mode": cur.get("engine_mode") or "",
        "content_fingerprint": (cur.get("content_fingerprint") or {}).get("sha256") or "",
    }


def _history_value_brief(key: str, value):
    """差异项的紧凑摘要（不把 40KB 开关块整块塞进读取面）。"""
    if isinstance(value, dict):
        if "sha" in value:
            return {"sha": value.get("sha"), "count": value.get("count")}
        if key == "main_chain_switches":
            return {"digest": value.get("digest"), "coverage": value.get("coverage")}
        if key == "switches":
            return {"coverage": value.get("coverage"),
                    "missing_count": len(value.get("missing") or [])}
        if key == "freeze_closure":
            return {"available": bool(value.get("available")), "digest": value.get("digest")}
        return {"sha": _sha(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                       default=str), 16)}
    if isinstance(value, list):
        return {"count": len(value),
                "sha": _sha(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                       default=str), 16)}
    return value


def _history_diff(stored: dict, cur: dict) -> dict:
    """快照 vs 当前差异（**单独标注**；不改写历史结果）。口径与 verify 兼容旧快照。"""
    stored, cur = stored or {}, cur or {}
    legacy_compare = not stored.get("schema_version")
    fields = _DIFF_FIELDS
    if legacy_compare:
        stored_keys = {k for k, _ in _DIFF_FIELDS if k in stored}
        fields = tuple(x for x in _DIFF_FIELDS if x[0] in stored_keys)
    elif "main_chain_switches" not in stored:
        fields = tuple(x for x in _DIFF_FIELDS if x[0] != "main_chain_switches")
    items = []
    for key, label in fields:
        a, b = stored.get(key), cur.get(key)
        try:
            same = (json.dumps(a, ensure_ascii=False, sort_keys=True, default=str)
                    == json.dumps(b, ensure_ascii=False, sort_keys=True, default=str))
        except Exception:
            same = a == b
        if same:
            continue
        items.append({
            "field": key, "label": label,
            "impact": _HISTORY_FIELD_IMPACT.get(key, "config_changed"),
            "frozen": _history_value_brief(key, a),
            "current": _history_value_brief(key, b),
            "frozen_digest": _sha(json.dumps(a, ensure_ascii=False, sort_keys=True,
                                             default=str), 16),
            "current_digest": _sha(json.dumps(b, ensure_ascii=False, sort_keys=True,
                                              default=str), 16),
            "affects_history_display": False,
            "note": "仅标注差异：历史结果仍按冻结快照展示，不用当前配置覆盖",
        })
    if legacy_compare:
        note = "旧格式快照：按字段交集窄比，不把新增字段缺失误报成升级"
    elif "main_chain_switches" not in stored:
        note = "L53 格式快照：不比较新增的主链开关块"
    else:
        note = "冻结快照 vs 当前运行环境；差异单独标注，不影响历史结果读取"
    return {"identical": not items, "count": len(items),
            "changed_fields": [x["field"] for x in items],
            "impacts": sorted({x["impact"] for x in items}),
            "items": items, "legacy_compare": bool(legacy_compare), "note": note}


def _history_missing_payload(case_id: str, run_id: str) -> dict:
    """严格模式下“快照缺失”的统一返回（所有入口同一 code/文案，禁止静默）。"""
    state = history_strict_state()
    return {
        # 查询本身成功（run 存在），但“历史结果可复现”明确为否；不用 ok=False 把
        # “不可复现”伪装成接口错误，也不静默返回当前配置。
        "ok": True, "engine": HISTORY_ENGINE,
        "case_id": str(case_id or ""), "run_id": str(run_id or ""),
        "snapshot_found": False,
        "reproducible": False, "fully_reproducible": False,
        "status": "unreproducible", "code": "history_snapshot_missing",
        "missing": ["snapshot_v2"], "error": "",
        "note": ("该 run 没有已保存的冻结快照（可能早于快照上线/保存失败）；"
                 "严格模式（%s=1）显式判为不可复现，不用当前规则/本体/配置冒充当时结果"
                 % HISTORY_STRICT_ENV),
        "history_switch": state,
    }


def history_view(case_id: str = "", run_id: str = "", current: dict = None) -> dict:
    """历史审核结果的**冻结读取**入口（六视角④最小闭环核心）。

    返回结构（CLI/HTTP/报告可共用）：
      found / snapshot_found / reproducible / fully_reproducible / status / code / note
      frozen:  manifest/findings/evidence/report/rules/ontology/snapshot/config_summary
      current: 当前运行环境摘要（仅对比用，不回填 frozen）
      diff:    冻结 vs 当前差异（单独标注；默认不影响历史展示）
      history_switch / caveats / checked_at / view_digest（同输入两次读取幂等）
    严格模式（默认）：快照缺失 → ``reproducible=False, code=history_snapshot_missing``，
    不构建、不返回当前配置的伪快照；``RULEPROOF_HISTORY_SNAPSHOT_STRICT=0`` 时回退为
    ``status=legacy_current_fallback``（当前配置兜底，显式 degraded）。
    """
    state = history_strict_state()
    out = {"ok": True, "engine": HISTORY_ENGINE,
           "case_id": str(case_id or ""), "run_id": str(run_id or ""),
           "found": False, "snapshot_found": False,
           "reproducible": False, "fully_reproducible": False,
           "status": "", "code": "", "error": "", "note": "", "missing": [],
           "frozen": {}, "current": {}, "diff": {},
           "history_switch": state, "caveats": [],
           "checked_at": _now(), "view_digest": ""}
    rid = str(run_id or "").strip()
    if not rid:
        out.update(ok=False, status="invalid_request", code="invalid_request",
                   error="history_view 需要 run_id")
        return out
    run = _history_run_row(rid)
    cid = str(case_id or "").strip() or str(run.get("case_id") or "")
    out["case_id"] = cid
    out["run_id"] = rid
    if not run:
        out.update(ok=False, status="error", code="run_not_found",
                   error=f"审核 run 不存在：run={rid}",
                   note="无法定位历史结果（不读当前配置兜底）")
        return out
    if cid and str(run.get("case_id") or "") != cid:
        out.update(ok=False, status="error", code="run_case_mismatch",
                   error=f"run={rid} 不属于 case={cid}",
                   note="拒绝跨项目读取历史快照")
        return out
    out["found"] = True
    stored = load(cid, rid) if cid else {}
    if not stored:
        out.update(_history_missing_payload(cid, rid))
        out["checked_at"] = _now()
        out["view_digest"] = _sha(json.dumps(
            {"case": cid, "run": rid, "status": out.get("status"),
             "code": out.get("code"), "strict": state.get("strict")},
            ensure_ascii=False, sort_keys=True), 24)
        if not state.get("strict"):
            # 回退：旧宽松行为（当前配置兜底），但必须显式 degraded，不标成 frozen。
            try:
                cur = current if current is not None else _build_in_case_scope(cid, rid)
            except Exception as exc:  # noqa: BLE001
                cur = {}
                out["fallback_error"] = "%s: %s" % (type(exc).__name__, str(exc)[:160])
            out.update(status="legacy_current_fallback", code="",
                       reproducible=None, fully_reproducible=False,
                       error="", note=("回退模式（%s=0）：快照缺失，以当前运行配置兜底；"
                                       "结果非当时冻结，不可复现（degraded）"
                                       % HISTORY_STRICT_ENV),
                       missing=["snapshot_v2"])
            out["current"] = _history_current_summary(cur)
            try:
                out["frozen"] = {"degraded": True, "source": "current_fallback",
                                 "snapshot": report_block(cur)}
            except Exception as exc:  # noqa: BLE001
                out["frozen"] = {"degraded": True, "source": "current_fallback",
                                 "error": "%s: %s" % (type(exc).__name__,
                                                      str(exc)[:160])}
            out["caveats"].append("RULEPROOF_HISTORY_SNAPSHOT_STRICT=0：旧宽松行为，"
                                  "frozen 块来自当前配置兜底，不可作为历史证据")
        return out
    # ---- 快照完整性（被改过的快照不能当历史结论）
    try:
        recomputed = digest(stored)
    except Exception:
        recomputed = ""
    integrity = bool(str(stored.get("digest") or "")) and recomputed == str(stored.get("digest"))
    out["snapshot_found"] = True
    out["reproducible"] = bool(integrity)
    out["status"] = "frozen" if integrity else "tampered"
    if not integrity:
        out["code"] = "history_snapshot_tampered"
        out["error"] = "快照自身 digest 与内容不一致（被改/损坏），不可作为历史结论"
        out["missing"] = ["snapshot_integrity"]
    findings = findings_for_run(cid, rid)
    frozen = _history_frozen_content(cid, rid, stored, findings=findings)
    out["frozen"] = frozen
    rules_ok = bool((frozen.get("rules") or {}).get("all_parseable"))
    rules_content_ok = ((frozen.get("rules") or {}).get("content_unchanged") is not False)
    onto_ok = bool((frozen.get("ontology") or {}).get("parseable"))
    out["fully_reproducible"] = bool(integrity and rules_ok and rules_content_ok
                                     and onto_ok
                                     and (frozen.get("manifest") or {}).get(
                                         "audit_manifest_found"))
    if not rules_ok:
        out["missing"].append("frozen_rule_versions_parseable")
    if not rules_content_ok:
        out["missing"].append("frozen_rule_version_content_changed")
    if not onto_ok:
        out["missing"].append("frozen_ontology_snapshot")
    if not (frozen.get("manifest") or {}).get("audit_manifest_found"):
        out["missing"].append("audit_manifest")
    # ---- 当前环境（仅对比）：构建失败不伪造“无差异”
    if current is not None:
        cur = current
        cur_error = ""
    else:
        try:
            cur = _build_in_case_scope(cid, rid)
            cur_error = ""
        except Exception as exc:  # noqa: BLE001
            cur = {}
            cur_error = "%s: %s" % (type(exc).__name__, str(exc)[:160])
    out["current"] = _history_current_summary(cur)
    if cur_error:
        out["current"]["error"] = cur_error
        out["diff"] = {"identical": None, "count": None, "changed_fields": [],
                       "impacts": [], "items": [], "legacy_compare": False,
                       "note": "当前环境快照构建失败：差异不可判定（不写成一致）",
                       "error": cur_error}
        out["caveats"].append("当前环境构建失败：diff 不可判定")
    else:
        out["diff"] = _history_diff(stored, cur)
    # 旧格式/缺块显式提示
    if not stored.get("schema_version"):
        out["caveats"].append("该快照为 v2 旧格式（无 schema_version）；按字段交集窄比，"
                              "不含 v3 开关/引擎/指纹字段")
    if not out["reproducible"]:
        out["caveats"].append("快照完整性未通过：历史结论仅作展示，未通过完整性校验")
    out["caveats"].extend([
        "history_view 只读：不重跑审核、不写业务数据、不改历史 run 结论",
        "frozen 块只来自该 run 冻结的 manifest/snapshot/DB 行；current 仅供差异对比",
        "差异（diff）单独标注：规则库/因子/本体升级不会回填/覆盖历史结果"
        if out["diff"].get("identical") is not True else "当前环境与冻结快照一致",
    ])
    out["view_digest"] = _sha(json.dumps({
        "case": cid, "run": rid, "snapshot_id": frozen["config_summary"].get("snapshot_id"),
        "frozen_findings_sha": frozen["findings"].get("sha"),
        "frozen_evidence_sha": frozen["evidence"].get("sha"),
        "rules_parseable": rules_ok, "ontology_parseable": onto_ok,
        "diff_fields": list((out["diff"] or {}).get("changed_fields") or []),
        "reproducible": out["reproducible"],
    }, ensure_ascii=False, sort_keys=True), 24)
    out["checked_at"] = _now()
    return out


def history_repro_summary(case_id: str = "", run_id: str = "") -> dict:
    """轻量可复现摘要（供 replay_context/replay/门禁引用，不构建当前快照）。"""
    state = history_strict_state()
    rid = str(run_id or "")
    run = _history_run_row(rid) if rid else {}
    cid = str(case_id or "").strip() or str(run.get("case_id") or "")
    out = {"engine": HISTORY_ENGINE, "case_id": cid, "run_id": rid,
           "run_found": bool(run), "snapshot_found": False,
           "reproducible": False, "fully_reproducible": False,
           "status": "", "code": "", "note": "", "missing": [],
           "history_switch": state, "checked_at": _now()}
    if not run:
        out.update(status="error", code="run_not_found",
                   note="审核 run 不存在（不读当前配置兜底）")
        return out
    stored = load(cid, rid) if cid else {}
    if not stored:
        out.update(_history_missing_payload(cid, rid))
        out["run_found"] = True
        return out
    try:
        integrity = bool(stored.get("digest")) and digest(stored) == str(stored.get("digest"))
    except Exception:
        integrity = False
    findings = findings_for_run(cid, rid)
    rules = _history_rule_versions(cid, rid)
    onto = _history_ontology(cid, rid, stored)
    manifest = _history_manifest_summary(cid, rid)
    out.update({
        "run_found": True, "snapshot_found": True,
        "reproducible": bool(integrity),
        "status": "frozen" if integrity else "tampered",
        "code": "" if integrity else "history_snapshot_tampered",
        "note": ("" if integrity else
                 "快照自身 digest 与内容不一致，不可作为历史结论"),
        "snapshot_id": stored.get("snapshot_id") or "",
        "stored_digest": stored.get("digest") or "",
        "built_at": stored.get("built_at") or "",
        "rules_all_parseable": bool(rules.get("all_parseable")),
        "rules_content_unchanged": rules.get("content_unchanged"),
        "rules_parseable_count": sum(1 for x in (rules.get("items") or [])
                                     if x.get("parseable")),
        "rules_missing": rules.get("missing") or [],
        "rules_changed": rules.get("changed") or [],
        "ontology_parseable": bool(onto.get("parseable")),
        "ontology_sha": onto.get("frozen_sha") or "",
        "manifest_available": bool(manifest.get("audit_manifest_found")),
        "findings_count": len(findings or []),
        "findings_sha": _json_sha(findings or [], 24),
        "switches_coverage": stored.get("switches_coverage") or "",
        "main_chain_switches_coverage":
            stored.get("main_chain_switches_coverage") or "",
        "model": ((stored.get("model") or {}).get("model") or ""),
        "model_version": (stored.get("model_version") or {}).get("version") or "",
        "parser_version": stored.get("parser_version")
        or (stored.get("parser") or {}).get("version") or "",
        "engine_mode": stored.get("engine_mode") or "",
        "mode_combination": stored.get("mode_combination") or "",
    })
    out["fully_reproducible"] = bool(
        integrity and out["rules_all_parseable"]
        and out["rules_content_unchanged"] is not False
        and out["ontology_parseable"] and out["manifest_available"])
    if not integrity:
        out["missing"].append("snapshot_integrity")
    if not out["rules_all_parseable"]:
        out["missing"].append("frozen_rule_versions_parseable")
    if out["rules_content_unchanged"] is False:
        out["missing"].append("frozen_rule_version_content_changed")
    if not out["ontology_parseable"]:
        out["missing"].append("frozen_ontology_snapshot")
    if not out["manifest_available"]:
        out["missing"].append("audit_manifest")
    return out


def _ridempotency(out: dict, case_id: str, run_id: str, mode: str) -> None:
    """把幂等键/结果指纹/历史重复记录写入 replay 返回体（就地更新，不写业务数据）。"""
    try:
        key = str(out.get("replay_key") or "")
        fp = _replay_result_fingerprint(out)
        out["replay_result_fingerprint"] = fp
        if not key:
            out["idempotency"] = {"engine": REPLAY_IDEMPOTENCY_ENGINE,
                                  "replay_key": "", "result_fingerprint": fp,
                                  "repeat": False, "idempotent": True,
                                  "note": "无 replay_key（快照/输入不可哈希）：不做重复判定"}
            out["idempotent"] = True
            return
        block = _replay_idempotency_block(case_id, key, fp, mode)
        out["idempotency"] = block
        out["idempotent"] = bool(block.get("idempotent"))
    except Exception as exc:  # noqa: BLE001 - 幂等判定失败不改变 replay 主结论，但显式留痕
        out["idempotency"] = {"engine": REPLAY_IDEMPOTENCY_ENGINE,
                              "error": "%s: %s" % (type(exc).__name__, str(exc)[:160])}
        out["idempotent"] = None


# ---------------------------------------------------------------- replay 幂等键（L133）
REPLAY_IDEMPOTENCY_ENGINE = "version_snapshot.replay-idempotency-v1"


def _replay_key(case_id: str, run_id: str, stored: dict, cur: dict = None,
                mode: str = "") -> str:
    """回放幂等键：同一来源 run+快照+输入内容+环境配置 → 同一键。

    只含内容标识（不含时间/随机 id）：
      source_run / snapshot_id / stored_digest / frozen content_fingerprint /
      frozen rule code+version / mode_combination / 当前内容指纹与配置差异字段。
    """
    stored = stored or {}
    frozen_rules = []
    try:
        mid = _manifest_id_for_run(case_id, run_id)
        if mid:
            from . import manifest as _mf_key
            closure = _mf_key.load_closure(mid) or {}
            frozen_rules = sorted(
                [str(x.get("code") or "") + ":" + str(x.get("version") or "")
                 + ":" + str(x.get("version_id") or "") + ":"
                 + str(x.get("content_sha") or "")
                 for x in (closure.get("rule_versions") or []) if isinstance(x, dict)])
    except Exception:
        frozen_rules = []
    if not frozen_rules:
        frozen_rules = sorted(
            [str(x.get("code") or "") + ":" + str(x.get("version") or "")
             for x in ((stored.get("rules") or {}).get("items") or [])])
    cur = cur or {}
    cur_cf = (cur.get("content_fingerprint") or {}).get("sha256") or ""
    stored_cf = (stored.get("content_fingerprint") or {}).get("sha256") or ""
    body = {
        "engine": REPLAY_IDEMPOTENCY_ENGINE,
        "operation_mode": str(mode or ""),
        "case_id": str(case_id or ""),
        "source_run_id": str(run_id or ""),
        "snapshot_id": str(stored.get("snapshot_id") or ""),
        "stored_digest": str(stored.get("digest") or ""),
        "stored_content_fingerprint": stored_cf,
        "current_content_fingerprint": cur_cf,
        "frozen_rules": frozen_rules,
        "mode_combination": str(stored.get("mode_combination")
                                or (stored.get("engine") or {}).get(
                                    "mode_combination") or ""),
        "current_rules_sha": ((cur.get("rules") or {}).get("sha") or ""),
        "current_ontology_sha": ((cur.get("ontology") or {}).get("sha") or ""),
        "current_switches_coverage": cur.get("switches_coverage") or "",
    }
    return _sha(json.dumps(body, ensure_ascii=False, sort_keys=True, default=str), 24)


def _prior_replay_events(case_id: str, replay_key: str, mode: str = "") -> list:
    """按幂等键回查历史回放审计（只读；用于回答“同一快照重复回放结果是否稳定”）。"""
    key = str(replay_key or "")
    if not key:
        return []
    _want_action = ("snapshot.replay_verified" if str(mode or "") == "verify"
                    else ("snapshot.replayed" if str(mode or "") == "replay" else ""))
    out = []
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT action, object, after_json, created_at FROM audit_log "
                "WHERE action IN ('snapshot.replayed','snapshot.replay_verified') "
                "ORDER BY rowid DESC LIMIT 2000").fetchall()
        for r in rows:
            try:
                data = json.loads(r["after_json"] or "{}")
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            if str(data.get("replay_key") or "") != key:
                continue
            if _want_action and str(r["action"] or "") != _want_action:
                continue
            if str(case_id or "") and str(data.get("case_id") or r["object"] or "") != str(case_id):
                continue
            out.append({"action": str(r["action"] or ""),
                        "created_at": str(r["created_at"] or ""),
                        "new_run_id": str(data.get("new_run_id") or ""),
                        "replay_key": key,
                        "replay_result_fingerprint":
                            str(data.get("replay_result_fingerprint") or ""),
                        "identical": data.get("identical"),
                        "findings_identical": data.get("findings_identical")})
    except Exception:
        logging.getLogger(__name__).debug("prior replay scan failed", exc_info=True)
    return out


def _replay_result_fingerprint(out: dict) -> str:
    """一次回放/校验结果的内容指纹（排除时间/新 run id），供幂等重复比对。"""
    findings = out.get("findings") or {}
    cf = out.get("content_fingerprint") or {}
    diff = out.get("differences") or []
    body = {
        "engine": str(out.get("engine") or ""),
        "mode": str(out.get("mode") or ""),
        "executed": bool(out.get("executed")),
        "identical": bool(out.get("identical")),
        "replayable": bool(out.get("replayable")),
        "content_identical": out.get("content_identical"),
        "stored_content_fingerprint": cf.get("stored") or "",
        "replayed_content_fingerprint": cf.get("replayed") or "",
        "findings_identical": findings.get("identical"),
        "findings_stored_fingerprint": findings.get("stored_fingerprint") or "",
        "findings_replayed_fingerprint": findings.get("replayed_fingerprint") or "",
        "modes_identical": out.get("modes_identical"),
        "mode_combination": (out.get("modes") or {}).get("stored_combination") or "",
        "blockers": sorted(str(b.get("code") or "") for b in (out.get("replay_blockers") or [])),
        "diff_fields": sorted(str(x.get("field") or "") for x in diff),
    }
    return _sha(json.dumps(body, ensure_ascii=False, sort_keys=True, default=str), 24)


def _replay_idempotency_block(case_id: str, replay_key: str, result_fp: str,
                              mode: str) -> dict:
    prior = _prior_replay_events(case_id, replay_key, mode=mode)
    same_result = [x for x in prior
                   if x.get("replay_result_fingerprint") == result_fp]
    latest = prior[0] if prior else {}
    repeat = bool(prior)
    return {
        "engine": REPLAY_IDEMPOTENCY_ENGINE,
        "replay_key": replay_key,
        "result_fingerprint": result_fp,
        "repeat": repeat,
        "prior_count": len(prior),
        "prior_same_result_count": len(same_result),
        "prior_replay_run_id": (same_result[0].get("new_run_id")
                                if same_result else latest.get("new_run_id") or ""),
        "prior_at": (same_result[0].get("created_at")
                     if same_result else latest.get("created_at") or ""),
        "idempotent": bool(same_result) or (not repeat),
        "note": ("同一来源快照/输入/环境已有回放记录：本次结果指纹与历史一致 → 幂等"
                 if same_result else
                 ("同一来源快照/输入/环境已有回放记录，但本次结果指纹不同（环境或结论已变，"
                  "不是幂等重复，需审计）" if repeat else
                  "首次回放：记录 replay_key 供后续重复回放核对幂等")),
        "mode": mode,
    }


def replay(case_id: str = "", run_id: str = "", snapshot_id: str = "",
           execute: bool = True, actor: str = "", current: dict = None) -> dict:
    """历史快照重放：同一快照 + 同输入重跑，比对 content_fingerprint/findings/引文。

    返回结构（CLI 直接消费）：
      found / replayable / executed / identical / replay_blockers / differences /
      input_check / config_check / content_fingerprint / findings / modes / caveats
    不可重放时 ``replayable=False`` + ``replay_blockers``（明确原因），且绝不执行；
    输入/快照被改、配置漂移都不会被写成“一致”。
    """
    out = {"ok": True, "engine": _REPLAY_ENGINE,
           "mode": "replay" if execute else "verify",
           "case_id": str(case_id or ""), "run_id": str(run_id or ""),
           "snapshot_id": str(snapshot_id or ""),
           "execute": bool(execute), "found": False, "replayable": False,
           "executed": False, "identical": False,
           "replay_blockers": [], "differences": [], "caveats": [],
           "checked_at": _now()}
    rid = str(run_id or "").strip()
    if not rid:
        out.update(ok=False, code="invalid_request", error="replay 需要 --run <run_id>")
        return out
    # 0) 定位 case / 快照
    if not str(case_id or "").strip():
        row = R.audit_runs.get(rid) or {}
        case_id = str(row.get("case_id") or "")
    out["run_id"] = rid
    stored = load(case_id, rid) if case_id else {}
    if snapshot_id:
        sid = str(snapshot_id).strip()
        if not stored or str(stored.get("snapshot_id") or "") != sid:
            found = find_by_snapshot_id(sid, case_id) or {}
            if not found:
                out.update(ok=False, found=False, code="snapshot_not_found",
                           error=f"未找到 snapshot_id={sid} 的已保存快照"
                                 f"（可用 rp snapshot show --case <case> 查快照 id）")
                out["replay_blockers"].append({"code": "snapshot_not_found",
                                               "detail": out["error"]})
                return out
            stored = found["snapshot"]
            case_id = found["case_id"]
            rid = found["run_id"]
            out.update(case_id=case_id, run_id=rid)
    if not case_id:
        out.update(ok=False, code="case_not_found",
                   error=f"run={rid} 不存在或不属于任何项目，无法定位快照")
        out["replay_blockers"].append({"code": "case_not_found", "detail": out["error"]})
        return out
    if not stored:
        out.update(ok=False, found=False, code="snapshot_missing",
                   # L133：不可复现必须显式（历史结果仍可按历史 DB 行展示，但不能回放）
                   reproducible=False, fully_reproducible=False,
                   status="unreproducible", source="missing",
                   history_switch=history_strict_state(),
                   error=f"未找到 run={rid} 的已保存快照（可能早于快照上线/保存失败）；"
                         f"可先 rp snapshot show --case {case_id} --run {rid} 确认")
        out["replay_blockers"].append({"code": "snapshot_missing", "detail": out["error"]})
        return out
    out.update(found=True, case_id=case_id, run_id=rid,
               snapshot_id=str(stored.get("snapshot_id") or ""),
               stored_digest=str(stored.get("digest") or ""),
               snapshot_schema_version=stored.get("schema_version") or stored.get("schema") or "",
               snapshot_revision=str(stored.get("snapshot_revision") or ""))
    # L133：冻结结果摘要（manifest/findings/证据/规则版本/本体可解析性）与可复现状态。
    # 与 history_view/verify 同一口径：快照缺失/被改时不声称可复现。
    try:
        out["history"] = history_repro_summary(case_id, rid)
    except Exception as exc:  # noqa: BLE001 - 摘要失败不改变 replay 主判定，但显式留痕
        out["history"] = {"engine": HISTORY_ENGINE, "error":
                          "%s: %s" % (type(exc).__name__, str(exc)[:160])}
    out["reproducible"] = (out["history"].get("reproducible")
                           if isinstance(out.get("history"), dict) else None)
    out["fully_reproducible"] = (out["history"].get("fully_reproducible")
                                 if isinstance(out.get("history"), dict) else None)
    out["history_switch"] = (out["history"].get("history_switch")
                             if isinstance(out.get("history"), dict)
                             else history_strict_state())

    # 1) 快照自身完整性（被改过的快照不能作为“历史结论”重放）
    recomputed = digest(stored)
    out["snapshot_integrity_ok"] = bool(
        str(stored.get("digest") or "") and recomputed == str(stored.get("digest")))
    if not out["snapshot_integrity_ok"]:
        out["replay_blockers"].append({
            "code": "snapshot_tampered",
            "detail": "快照自身 digest 与内容不一致（被改过/损坏）：不能把被改记录当历史结论重放",
            "recomputed_digest": recomputed})

    # 2) 模式组合（L61 modes 优先；L53 engine 块回退推导；都不可观测 → 阻塞）
    modes = stored.get("modes") if isinstance(stored.get("modes"), dict) else {}
    mode_source = "modes_block"
    if not modes:
        legacy = _legacy_modes(stored)
        modes = legacy
        mode_source = legacy.get("source") or "not_observable"
    out["modes"] = {"stored": modes, "source": mode_source}
    ai_assist = modes.get("ai_assist")
    if ai_assist not in (True, False):
        out["replay_blockers"].append({
            "code": "mode_not_persisted",
            "detail": "快照未持久化 audit_mode/ai_assist，无法证明重跑与历史 run 是同一模式；"
                      "拒绝猜测模式后重放"})

    # 3) 内容指纹（L61 之前快照无 → 不可证明同输入）
    stored_cf = stored.get("content_fingerprint") or {}
    if not stored_cf.get("sha256"):
        out["replay_blockers"].append({
            "code": "legacy_snapshot_no_content_fingerprint",
            "detail": "该快照为 L53 之前/回退杆产物（无 content_fingerprint），"
                      "无法证明重跑读取的是同一输入内容"})

    # 4) 输入完整性：冻结闭包守卫（文件/解析产物/参数/解析器/规则/决策表/绑定）
    mid = _manifest_id_for_run(case_id, rid)
    guard = (verify_freeze_closure(case_id, rid) if mid else
             {"available": False, "ok": False, "reason": "no_manifest_for_run",
              "issues": [{"code": "no_manifest_for_run",
                          "detail": "该 run 无冻结清单，输入一致性不可证明"}]})
    out["input_check"] = {
        "manifest_id": mid,
        "closure_available": bool(guard.get("available")),
        "ok": bool(guard.get("available") and guard.get("ok")),
        "issues": list(guard.get("issues") or []),
        "checks": guard.get("checks") or [],
        "legacy": guard.get("legacy"),
        "closure_digest": guard.get("closure_digest") or "",
    }
    if not out["input_check"]["ok"]:
        out["replay_blockers"].append({
            "code": "input_changed",
            "detail": "冻结闭包完整性校验未通过：文件/解析产物/规则/参数/决策表/绑定与冻结时"
                      "不一致，本次不是「同一输入」，拒绝重跑后冒充一致",
            "issues": out["input_check"]["issues"]})
    rule_frozen = _frozen_rule_codes(case_id, rid)
    out["input_check"]["frozen_rule_codes"] = rule_frozen.get("codes") or []
    if not rule_frozen.get("available"):
        out["replay_blockers"].append({
            "code": "frozen_rules_unavailable",
            "detail": "取不到冻结清单的规则集合，无法用同一规则集合重跑（当前规则全量重跑"
                      "会引入历史 run 不存在的新规则）",
            "reason": rule_frozen.get("reason") or ""})
    # L133：冻结规则版本 vs 当前生效版本。replay 用冻结清单的规则码调 project.audit，
    # 而冻结/执行取当前 published 版本；规则升级后同一 code 的生效版本已变 → 重跑会用
    # 新内容。必须显式检出并阻断，不得用新规则冒充历史（历史读取仍走冻结快照）。
    try:
        rule_drift = _frozen_rule_version_drift(case_id, rid)
    except Exception as exc:  # noqa: BLE001
        rule_drift = {"drifted": False, "items": [], "count": 0,
                      "error": "%s: %s" % (type(exc).__name__, str(exc)[:160])}
    out["frozen_rule_versions"] = rule_drift
    if rule_drift.get("drifted"):
        out["replay_blockers"].append({
            "code": "frozen_rule_version_drift",
            "detail": "当前生效规则版本已不是冻结时的版本（规则库升级）：重跑会读到新规则"
                      "内容，拒绝用新规则结果冒充历史；历史结果仍按冻结快照读取",
            "items": rule_drift.get("items") or []})

    # 5) 配置一致性（verify 口径）；旧占位 packs 与新 packs 都空 → 不算漂移
    cur = current
    if cur is None and stored.get("content_fingerprint"):
        try:
            cur = _build_in_case_scope(case_id, rid)
        except Exception:
            cur = None
    ver = verify(case_id, rid, current=cur) if stored.get("content_fingerprint") else {}
    changed = list(ver.get("changed") or [])
    if _same_legacy_placeholder_packs(stored, cur or {}):
        changed = [x for x in changed if x.get("field") != "packs"]
    config_identical = bool(ver.get("found")) and not changed
    out["config_check"] = {
        "verify_found": bool(ver.get("found")),
        "identical": config_identical,
        "changed_fields": [x.get("field") for x in changed],
        "changed": changed[:20],
        "content_identical": ver.get("content_identical"),
        "stored_content_fingerprint": ver.get("stored_content_fingerprint") or "",
        "current_content_fingerprint": ver.get("current_content_fingerprint") or "",
        "mode_observable_current": ver.get("mode_observable_current"),
        "mode_identical": ver.get("mode_identical"),
    }
    if ver.get("found") and not config_identical:
        out["replay_blockers"].append({
            "code": "conditions_drift",
            "detail": "运行配置/文件指纹与快照不一致（见 changed_fields）：重跑不是"
                      "「同一快照+同输入」，拒绝用不同条件下的结果冒充一致",
            "changed_fields": [x.get("field") for x in changed]})
    # L133：回放幂等键（同一来源 run+快照+输入内容+当前环境 → 同一键；结果指纹供
    # 重复回放核对“结果是否稳定”）。
    try:
        out["replay_key"] = _replay_key(
            case_id, rid, stored, cur, mode=("replay" if execute else "verify"))
    except Exception:  # noqa: BLE001 - 键计算失败不改变主判定，但显式空值
        out["replay_key"] = ""

    # 6) 不可重放：明确原因，不执行、不伪造一致
    if out["replay_blockers"]:
        out["caveats"].append("存在 replay_blockers：未执行重跑；不把缺失证据当成『一致』")
        return out
    out["replayable"] = True

    # 7) 仅校验模式（--verify）：不重跑
    content_identical = bool(
        stored_cf.get("sha256")
        and ver.get("content_identical") is True)
    out.update(content_identical=content_identical,
               modes_identical=(ver.get("mode_identical")
                                if ver.get("mode_observable_current") else None))
    if not execute:
        out["identical"] = bool(content_identical and config_identical)
        _ridempotency(out, case_id, rid, "verify")
        out["caveats"].append("--verify 只做快照/输入/配置校验，不重跑；"
                              "findings/引文一致性需不加 --verify 的 replay 验证")
        _audit_replay_event(case_id, rid, out, actor)
        return out

    # 8) 真实重跑：同一冻结规则集合 + 持久化模式组合
    from . import project as _project, ctx as _ctx
    case = R.cases.get(case_id) or {}
    try:
        _ctx.set_context(str(case.get("tenant_id") or ""),
                         str(case.get("workspace_id") or ""))
    except Exception:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    doc_type = str(modes.get("doc_type") or "")
    semantic = bool(modes.get("semantic"))
    n_before = _count_runs(case_id)
    try:
        note_request_mode(semantic=semantic, ai_assist=bool(ai_assist),
                          doc_type=doc_type, source="snapshot.replay")
        try:
            audit_out = _project.audit(
                case_id, semantic=semantic, ai_assist=bool(ai_assist),
                doc_type=doc_type, rule_codes=(rule_frozen.get("codes") or None))
        finally:
            clear_request_mode()
    except Exception as exc:  # noqa: BLE001 - 重跑失败必须显式返回，不冒充一致
        out.update(ok=False, executed=False, code="replay_execution_failed",
                   error=f"重跑失败：{type(exc).__name__}: {str(exc)[:300]}")
        out["caveats"].append("重跑异常：不产生『一致』结论")
        _audit_replay_event(case_id, rid, out, actor)
        return out
    new_run = _latest_run_id(case_id)
    if not new_run or new_run == rid or _count_runs(case_id) <= n_before:
        out.update(ok=False, executed=False, code="replay_no_new_run",
                   error="重跑未产生新的 audit_run，无法证明重放发生")
        _audit_replay_event(case_id, rid, out, actor)
        return out
    new_snap = load(case_id, new_run)
    stored_findings = findings_for_run(case_id, rid)
    replayed_findings = findings_for_run(case_id, new_run)
    fdiff = _findings_diff(stored_findings, replayed_findings)
    new_cf = (new_snap or {}).get("content_fingerprint") or {}
    new_modes = (new_snap or {}).get("modes") or {}
    content_identical = bool(stored_cf.get("sha256")
                             and stored_cf.get("sha256") == new_cf.get("sha256"))
    stored_combo = str(modes.get("mode_combination")
                       or _legacy_modes(stored).get("mode_combination") or "")
    new_combo = str(new_modes.get("mode_combination")
                    or (new_snap or {}).get("mode_combination") or "")
    modes_identical = (stored_combo == new_combo) if stored_combo else None
    identical = bool(out["replayable"] and content_identical
                     and fdiff.get("identical")
                     and modes_identical is not False)
    differences = []
    if not content_identical:
        differences.append({"field": "content_fingerprint",
                            "stored": stored_cf.get("sha256") or "",
                            "replayed": new_cf.get("sha256") or "",
                            "stored_parts": {k: stored_cf.get(k) for k in
                                             ("rules_sha", "documents_sha",
                                              "parsed_artifacts_sha")},
                            "replayed_parts": {k: new_cf.get(k) for k in
                                               ("rules_sha", "documents_sha",
                                                "parsed_artifacts_sha")}})
    if not fdiff.get("identical"):
        differences.append({"field": "findings", "added": fdiff.get("added"),
                            "removed": fdiff.get("removed"),
                            "changed_groups": fdiff.get("changed_groups"),
                            "quotes": fdiff.get("quotes")})
    if modes_identical is False:
        differences.append({"field": "modes", "stored": stored_combo,
                            "replayed": new_combo})
    # L98 P1：把 replay 派生 run 登记为可清理对象（只写 sys_config 标记，不动 run）
    out["replay_marker_written"] = _mark_replay_run(
        case_id, rid, str(stored.get("snapshot_id") or ""), new_run, actor)
    out.update(executed=True, new_run_id=new_run, new_snapshot_id=
               (new_snap or {}).get("snapshot_id") or "",
               content_identical=content_identical,
               content_fingerprint={
                   "stored": stored_cf.get("sha256") or "",
                   "replayed": new_cf.get("sha256") or "",
                   "identical": content_identical,
                   "stored_parts": {k: stored_cf.get(k) for k in
                                    ("rules_sha", "documents_sha", "parsed_artifacts_sha")},
                   "replayed_parts": {k: new_cf.get(k) for k in
                                      ("rules_sha", "documents_sha",
                                       "parsed_artifacts_sha")}},
               findings=fdiff,
               modes={"stored": modes, "replayed": new_modes,
                      "stored_combination": stored_combo,
                      "replayed_combination": new_combo,
                      "identical": modes_identical},
               modes_identical=modes_identical,
               identical=identical,
               differences=differences)
    out["caveats"].extend([
        "replay 是真实重跑：本次新增 audit_run=%s（写 findings/审计），不改历史 run 的结论"
        % new_run,
        "判定内容一致性以 content_fingerprint（去实例 id）+ findings 语义 + 逐字引文比对；"
        "不比较随机 id/时间戳/人工复核状态",
        "本次新增 run 已写 replay 标记：`rp snapshot replay --cleanup` 可按保留策略"
        "（默认保留 7 天 / 每案例最近 1 个 replay run）清理派生 run 与工件，"
        "历史有效 run 永不删除",
    ])
    if bool(modes.get("llm_enabled")):
        out["caveats"].append("本次重放启用了 LLM 语义通道：模型输出天然可能抖动，"
                              "findings 差异不能直接等同『被篡改』")
    _ridempotency(out, case_id, rid, "replay")
    _audit_replay_event(case_id, rid, out, actor)
    return out


def _count_runs(case_id: str) -> int:
    try:
        with db.session() as c:
            row = c.execute("SELECT count(*) AS n FROM audit_run WHERE case_id=?",
                            (case_id,)).fetchone()
        return int((row["n"] if row else 0) or 0)
    except Exception:
        return 0


def _audit_replay_event(case_id: str, run_id: str, out: dict, actor: str = "") -> None:
    """重放/校验留痕（审计是“重放发生过”的唯一证据；写失败不阻断结论但留 warning）。"""
    try:
        from .. import repositories as _R
        _R.audit_logs.log(
            actor=actor or "cli", action=("snapshot.replayed" if out.get("executed")
                                         else "snapshot.replay_verified"),
            object=str(case_id),
            after=json.dumps({
                "case_id": case_id, "run_id": run_id,
                "snapshot_id": out.get("snapshot_id") or "",
                "stored_digest": out.get("stored_digest") or "",
                "mode": out.get("mode") or "",
                "replayable": bool(out.get("replayable")),
                "executed": bool(out.get("executed")),
                "identical": bool(out.get("identical")),
                "new_run_id": out.get("new_run_id") or "",
                "blockers": [b.get("code") for b in (out.get("replay_blockers") or [])],
                "changed_fields": [d.get("field") for d in (out.get("differences") or [])],
                "content_identical": out.get("content_identical"),
                "findings_identical": (out.get("findings") or {}).get("identical"),
                "mode_combination": (out.get("modes") or {}).get(
                    "stored_combination") or "",
                # L133：回放幂等键 + 结果指纹（重复回放可核对“结果是否稳定”）+
                # 冻结规则版本漂移/可复现状态（历史读取面与回放面同一口径）。
                "replay_key": out.get("replay_key") or "",
                "replay_result_fingerprint": out.get("replay_result_fingerprint") or "",
                "idempotent": out.get("idempotent"),
                "repeat": (out.get("idempotency") or {}).get("repeat"),
                "reproducible": out.get("reproducible"),
                "rule_version_drift": bool(
                    (out.get("frozen_rule_versions") or {}).get("drifted")),
                "history_missing": (out.get("history") or {}).get("missing") or [],
            }, ensure_ascii=False, default=str))
    except Exception:
        import logging
        logging.getLogger(__name__).warning("snapshot replay audit write failed",
                                            exc_info=True)


# ===========================================================================
# L98 P1（2026-11-24）：快照 replay 的临时 run/工件清理与保留策略
# ===========================================================================
# 背景：`replay()` 是真实重跑 —— 每次成功 replay 都会在案例下新增一个 audit_run、
# 一批 finding/evidence/certificate、manifest 结果与 runsnapshot v2 / 冻结闭包
# sys_config 键，以及 `snapshot.replayed` 审计。反复 replay 会积累“派生 run”，
# 让项目里的 run 数/最新 run 指向被 replay 顶到前面的临时结果。
#
# 清理口径（保守，绝不删历史有效 run）：
#   1. 只有**带 replay 标记**的 run 才会被考虑：标记 = sys_config `replay.run:<run>`
#      （replay() 成功时写入）；兼容回退 = `snapshot.replayed` 审计里的 new_run_id；
#   2. 保护（一律不删，给 reason）：
#      - 案例最新 run（last_run_id / created_at 最新）—— 报告与后续操作可能正引用它；
#      - 有任何人工痕迹：finding 非 pending 状态 / decision / feedback / qa_sample /
#        manifest_review / shadow/comparison 双轨记录；
#      - 被报告 summary_json 引用；
#      - 被另一个 replay 标记当作 source_run_id；
#      - 年龄小于 keep_days（默认 7 天；解析不出时间按保护处理）；
#      - 同案例按新→旧排序的前 keep_last 个 replay run（默认 1）。
#   3. 删除（同事务、幂等）：finding 子表（evidence/certificate/decision/feedback/
#      evolution_task/qa_sample/reference_orphan_alert）+ manifest_result/
#      manifest_evidence/manifest_review + audit_manifest(仅 run_id 匹配) + llm_trace
#      + 对应 sys_config 键（runsnapshot:v2 / manifest / manifest_closure /
#      manifest_artifact / manifest_ontology / manifest_closure_required / replay 标记）
#      + audit_run 行。审计日志（只读轨迹）不删。
#   4. 已不存在的 run 但残留标记/快照键 = 孤儿工件，一并清掉（只清孤儿键）。
REPLAY_MARK_PREFIX = "replay.run:"
REPLAY_MARK_SCHEMA = "replay_run_marker_v1"
REPLAY_RETENTION_DAYS_ENV = "RULEPROOF_REPLAY_RETENTION_DAYS"
REPLAY_KEEP_LAST_ENV = "RULEPROOF_REPLAY_KEEP_LAST"
_REPLAY_CLOSURE_PREFIXES = ("manifest_closure:", "manifest_artifact:",
                            "manifest_ontology:", "manifest_closure_required:")


def _mark_replay_run(case_id: str, source_run_id: str, snapshot_id: str,
                     new_run_id: str, actor: str = "") -> bool:
    """把 replay 派生 run 登记为可清理对象（sys_config，幂等 upsert）。"""
    rid = str(new_run_id or "").strip()
    if not rid:
        return False
    try:
        from . import sysconfig
        payload = {"schema": REPLAY_MARK_SCHEMA, "run_id": rid,
                   "case_id": str(case_id or ""),
                   "source_run_id": str(source_run_id or ""),
                   "snapshot_id": str(snapshot_id or ""),
                   "actor": str(actor or ""), "marked_at": _now(),
                   "kind": "snapshot_replay"}
        sysconfig.set_many({REPLAY_MARK_PREFIX + rid:
                            json.dumps(payload, ensure_ascii=False)})
        return True
    except Exception:
        logging.getLogger(__name__).warning("replay marker write failed run=%s",
                                            rid, exc_info=True)
        return False


def list_replay_runs(case_id: str = "") -> list:
    """列出 replay 派生 run 标记（sys_config 为主，历史审计回退）。

    返回 [{run_id, case_id, source_run_id, snapshot_id, marked_at, origin}]；
    不读取/不修改任何业务数据。
    """
    out, known = [], set()
    try:
        with db.session() as c:
            rows = c.execute("SELECT key, value, updated_at FROM sys_config "
                             "WHERE key LIKE ? ORDER BY updated_at DESC, key DESC",
                             (REPLAY_MARK_PREFIX + "%",)).fetchall()
        for r in rows:
            rid = str(r["key"] or "")[len(REPLAY_MARK_PREFIX):]
            try:
                data = json.loads(r["value"] or "{}")
            except Exception:
                data = {}
            if not isinstance(data, dict):
                data = {}
            item = {"run_id": rid or str(data.get("run_id") or ""),
                    "case_id": str(data.get("case_id") or ""),
                    "source_run_id": str(data.get("source_run_id") or ""),
                    "snapshot_id": str(data.get("snapshot_id") or ""),
                    "marked_at": str(data.get("marked_at") or r["updated_at"] or ""),
                    "origin": "sys_config"}
            if item["run_id"] and item["run_id"] not in known:
                known.add(item["run_id"])
                out.append(item)
    except Exception:
        logging.getLogger(__name__).debug("replay marker list failed", exc_info=True)
    # 审计回退：早期 replay 可能只留了 snapshot.replayed 审计
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT object, after_json, created_at FROM audit_log "
                "WHERE action='snapshot.replayed' ORDER BY rowid DESC LIMIT 2000").fetchall()
        for r in rows:
            try:
                data = json.loads(r["after_json"] or "{}")
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            rid = str(data.get("new_run_id") or "")
            if not rid or rid in known:
                continue
            known.add(rid)
            out.append({"run_id": rid,
                        "case_id": str(data.get("case_id") or r["object"] or ""),
                        "source_run_id": str(data.get("run_id") or ""),
                        "snapshot_id": str(data.get("snapshot_id") or ""),
                        "marked_at": str(r["created_at"] or ""),
                        "origin": "audit_log"})
    except Exception:
        logging.getLogger(__name__).debug("replay audit fallback failed", exc_info=True)
    cid = str(case_id or "").strip()
    if cid:
        out = [x for x in out if str(x.get("case_id") or "") == cid]
    return out


def _replay_run_row(run_id: str) -> dict:
    """直读 audit_run（不用仓储，避免 ctx 严格作用域把 NULL 租户的历史 run 过滤掉）。"""
    try:
        with db.session() as c:
            r = c.execute("SELECT * FROM audit_run WHERE id=?", (str(run_id or ""),)).fetchone()
        return dict(r) if r else {}
    except Exception:
        return {}


def _replay_protect_reasons(run_id: str, run: dict, case_id: str,
                            markers: list) -> list:
    """返回该 replay run 的保护原因（空 = 可清理）。只读。"""
    reasons = []
    rid = str(run_id)
    if not run:
        return ["run_missing"]
    # 1) 案例最新 run
    latest = _latest_run_id(case_id)
    if latest and str(latest) == rid:
        reasons.append("is_latest_run")
    # 2) 人工痕迹
    try:
        with db.session() as c:
            frows = c.execute("SELECT id, COALESCE(status,'') AS st FROM finding "
                              "WHERE run_id=?", (rid,)).fetchall()
            fids = [str(r["id"]) for r in frows]
            if any(str(r["st"] or "") not in ("", "pending") for r in frows):
                reasons.append("finding_reviewed")
            if fids:
                for tbl, col in (("decision", "finding_id"), ("feedback", "finding_id"),
                                 ("qa_sample", "finding_id")):
                    try:
                        n = c.execute("SELECT count(*) AS n FROM %s WHERE %s IN (%s)"
                                      % (tbl, col, ",".join("?" * len(fids))),
                                      tuple(fids)).fetchone()
                        if n and int(n["n"] or 0) > 0:
                            reasons.append("has_%s" % tbl)
                    except Exception:
                        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            mid = str(run.get("manifest_id") or "")
            if mid:
                try:
                    n = c.execute("SELECT count(*) AS n FROM manifest_review "
                                  "WHERE result_id IN (SELECT id FROM manifest_result "
                                  "WHERE manifest_id=?)", (mid,)).fetchone()
                    if n and int(n["n"] or 0) > 0:
                        reasons.append("has_manifest_review")
                except Exception:
                    logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            if fids:
                for tbl, col in (("shadow_item", "platform_finding_id"),
                                 ("comparison_item", "platform_finding_id"),
                                 ("suppression_ledger", "platform_finding_id")):
                    try:
                        n = c.execute("SELECT count(*) AS n FROM %s WHERE %s IN (%s)"
                                      % (tbl, col, ",".join("?" * len(fids))),
                                      tuple(fids)).fetchone()
                        if n and int(n["n"] or 0) > 0:
                            reasons.append("has_%s" % tbl)
                    except Exception:
                        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    except Exception:
        logging.getLogger(__name__).debug("replay protect scan failed", exc_info=True)
        return ["protect_scan_failed"]
    # 3) 被报告引用
    try:
        with db.session() as c:
            n = c.execute("SELECT count(*) AS n FROM report WHERE case_id=? AND "
                          "COALESCE(summary_json,'') LIKE ?",
                          (case_id, "%" + rid + "%")).fetchone()
        if n and int(n["n"] or 0) > 0:
            reasons.append("referenced_by_report")
    except Exception:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    # 4) 被另一个 replay 当作 source run
    for m in markers:
        if str(m.get("source_run_id") or "") == rid:
            reasons.append("replay_source_of_other")
            break
    return reasons


def _parse_ts(value):
    txt = str(value or "").strip()
    if not txt:
        return None
    txt = txt.replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(txt[:19], fmt)
        except Exception:
            continue
    return None


def _delete_replay_run_artifacts(case_id: str, run_id: str,
                                 manifest_id: str = "") -> dict:
    """同事务删除一个 replay 派生 run 的工件（幂等；调用前必须已过保护检查）。"""
    stats = {"findings": 0, "evidence": 0, "certificates": 0, "manifest_results": 0,
             "manifest_evidence": 0, "manifest_reviews": 0, "llm_traces": 0,
             "sys_config_keys": 0, "audit_manifests": 0, "audit_runs": 0}
    with db.session() as c:
        fids = [str(r["id"]) for r in c.execute(
            "SELECT id FROM finding WHERE run_id=?", (run_id,)).fetchall()]
        if fids:
            ph = ",".join("?" * len(fids))
            for tbl, col, key in (("evidence", "finding_id", "evidence"),
                                  ("finding_certificate", "finding_id", "certificates"),
                                  ("decision", "finding_id", None),
                                  ("feedback", "finding_id", None),
                                  ("evolution_task", "finding_id", None),
                                  ("qa_sample", "finding_id", None),
                                  ("reference_orphan_alert", "finding_id", None)):
                try:
                    cur = c.execute("DELETE FROM %s WHERE %s IN (%s)"
                                    % (tbl, col, ph), tuple(fids))
                    if key and cur.rowcount:
                        stats[key] += int(cur.rowcount or 0)
                except Exception:
                    logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            cur = c.execute("DELETE FROM finding WHERE id IN (%s)" % ph, tuple(fids))
            stats["findings"] = int(cur.rowcount or 0)
        mid = str(manifest_id or "")
        if mid:
            mrids = [str(r["id"]) for r in c.execute(
                "SELECT id FROM manifest_result WHERE manifest_id=?", (mid,)).fetchall()]
            if mrids:
                mph = ",".join("?" * len(mrids))
                for tbl, key in (("manifest_evidence", "manifest_evidence"),
                                 ("manifest_review", "manifest_reviews")):
                    try:
                        cur = c.execute("DELETE FROM %s WHERE result_id IN (%s)"
                                        % (tbl, mph), tuple(mrids))
                        stats[key] = int(cur.rowcount or 0)
                    except Exception:
                        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            cur = c.execute("DELETE FROM manifest_result WHERE manifest_id=?", (mid,))
            stats["manifest_results"] = int(cur.rowcount or 0)
        cur = c.execute("DELETE FROM llm_trace WHERE run_id=?", (run_id,))
        stats["llm_traces"] = int(cur.rowcount or 0)
        # audit_manifest：只删 run_id 精确匹配本 replay run 的清单行
        try:
            cur = c.execute("DELETE FROM audit_manifest WHERE id=? AND run_id=?",
                            (mid, run_id)) if mid else None
            stats["audit_manifests"] = int(cur.rowcount or 0) if cur else 0
        except Exception:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
        # sys_config：快照/清单工件 + replay 标记（键先收集，提交后再删？同连接即可）
        keys = [REPLAY_MARK_PREFIX + run_id,
                KEY_PREFIX + str(case_id) + ":" + str(run_id),
                "manifest:" + str(case_id) + ":" + str(run_id)]
        if mid:
            keys.extend([p + mid for p in _REPLAY_CLOSURE_PREFIXES])
        try:
            cur = c.execute("DELETE FROM sys_config WHERE key IN (%s)"
                            % ",".join("?" * len(keys)), tuple(keys))
            stats["sys_config_keys"] = int(cur.rowcount or 0)
        except Exception:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
        cur = c.execute("DELETE FROM audit_run WHERE id=?", (run_id,))
        stats["audit_runs"] = int(cur.rowcount or 0)
    return stats


def replay_cleanup(case_id: str = "", dry_run: bool = True,
                   keep_days: int = 7, keep_last: int = 1,
                   actor: str = "") -> dict:
    """清理 replay 派生临时 run/工件；默认 dry-run，绝不删历史有效 run。

    保留策略：keep_days（默认 7 天，或 env RULEPROOF_REPLAY_RETENTION_DAYS）
    + 每案例保留最近 keep_last 个 replay run（默认 1，或 env
    RULEPROOF_REPLAY_KEEP_LAST）；人工痕迹/报告引用/被引用的 run 永不删除。
    幂等：重复执行第二次 deleted=0。
    """
    try:
        # 直接读字面量：开关注册表门禁（L59）按字面量扫描（常量名保留给文档/测试引用）
        keep_days = int(keep_days if keep_days is not None else
                        os.environ.get("RULEPROOF_REPLAY_RETENTION_DAYS", "7"))
    except Exception:
        keep_days = 7
    try:
        keep_last = int(keep_last if keep_last is not None else
                        os.environ.get("RULEPROOF_REPLAY_KEEP_LAST", "1"))
    except Exception:
        keep_last = 1
    keep_last = max(0, keep_last)
    keep_days = max(0, keep_days)
    markers = list_replay_runs(case_id)
    out = {"ok": True, "mode": "dry_run" if dry_run else "execute",
           "case_id": str(case_id or ""), "keep_days": keep_days,
           "keep_last": keep_last, "markers": len(markers),
           "replay_runs": len(markers), "deleted": 0, "protected": [],
           "orphans_cleaned": [], "artifacts": {}, "runs_total": 0,
           "runs_after": None, "historical_runs_preserved": 0,
           "idempotent_hint": "重复执行 deleted=0", "caveats": [],
           "checked_at": _now()}
    if not markers:
        # 幂等路径也如实报告 run 总量（不因为没东西删就返回 0）
        try:
            with db.session() as c:
                if case_id:
                    rows = c.execute("SELECT id FROM audit_run WHERE case_id=?",
                                     (str(case_id),)).fetchall()
                else:
                    rows = c.execute("SELECT id FROM audit_run").fetchall()
            out["runs_total"] = len(rows)
            out["historical_runs_preserved"] = len(rows)
        except Exception:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
        out["caveats"].append("没有 replay 派生 run 标记：无需清理（幂等 deleted=0）")
        return out
    # 按案例分组（同案例新→旧），用于 keep_last
    by_case = {}
    for m in markers:
        by_case.setdefault(str(m.get("case_id") or ""), []).append(m)
    keep_set = set()
    for cid, rows in by_case.items():
        ordered = sorted(rows, key=lambda x: str(x.get("marked_at") or ""), reverse=True)
        for m in ordered[:keep_last]:
            keep_set.add(str(m.get("run_id") or ""))
    now_ts = datetime.now()
    cleanup_plan = []
    for m in markers:
        rid = str(m.get("run_id") or "")
        cid = str(m.get("case_id") or "")
        run = _replay_run_row(rid)
        if run and not cid:
            cid = str(run.get("case_id") or "")
        reasons = _replay_protect_reasons(rid, run, cid, markers) if run else ["run_missing"]
        if rid in keep_set and "run_missing" not in reasons:
            reasons.append("keep_last")
        created = _parse_ts(run.get("created_at") or "") if run else None
        if run and keep_days > 0:
            if created is None:
                reasons.append("age_unknown")
            else:
                try:
                    age_days = (now_ts - created).total_seconds() / 86400.0
                    if age_days < keep_days:
                        reasons.append("younger_than_keep_days")
                except Exception:
                    reasons.append("age_unknown")
        reasons = list(dict.fromkeys(reasons))
        # run 已不存在 = 孤儿标记/快照键：不是保护对象，按孤儿工件清理
        orphan = (not run) and reasons == ["run_missing"]
        entry = {"run_id": rid, "case_id": cid, "marker_origin": m.get("origin") or "",
                 "created_at": str(run.get("created_at") or ""),
                 "manifest_id": str(run.get("manifest_id") or ""),
                 "decision": "orphan" if orphan else ("protect" if reasons else "delete"),
                 "reasons": reasons}
        cleanup_plan.append(entry)
    out["protected"] = [x for x in cleanup_plan if x["decision"] == "protect"]
    to_delete = [x for x in cleanup_plan if x["decision"] in ("delete", "orphan")]
    # 历史有效 run 计数（= 非 replay run 数；dry-run 前）。按 --case 过滤，
    # 避免别的案例的 run 混进本案例的保留数口径。
    replay_ids = {str(m.get("run_id") or "") for m in markers}
    try:
        with db.session() as c:
            if case_id:
                all_runs = [dict(r) for r in c.execute(
                    "SELECT id, case_id FROM audit_run WHERE case_id=?",
                    (str(case_id),)).fetchall()]
            else:
                all_runs = [dict(r) for r in c.execute(
                    "SELECT id, case_id FROM audit_run").fetchall()]
        out["runs_total"] = len(all_runs)
        out["historical_runs_preserved"] = sum(
            1 for r in all_runs if str(r.get("id") or "") not in replay_ids)
    except Exception:
        pass
    out["to_delete"] = [x["run_id"] for x in to_delete]
    if dry_run:
        out["replay_runs"] = len(to_delete)
        out["deleted"] = 0
        out["caveats"].append("dry-run：未删除任何行；--apply/execute 才执行清理")
        return out
    deleted_ok = 0
    artifacts = {}
    for x in to_delete:
        try:
            if x["reasons"] == ["run_missing"]:
                # 孤儿标记/快照键：只清 sys_config 键（不碰任何业务行）
                from . import sysconfig
                keys = [REPLAY_MARK_PREFIX + x["run_id"]]
                if x["case_id"]:
                    keys.append(KEY_PREFIX + x["case_id"] + ":" + x["run_id"])
                n = int(sysconfig.delete_keys(keys) or 0)
                artifacts["orphan_keys"] = artifacts.get("orphan_keys", 0) + n
                out["orphans_cleaned"].append({"run_id": x["run_id"], "keys": n})
                deleted_ok += 1
                continue
            st = _delete_replay_run_artifacts(x["case_id"], x["run_id"],
                                              x["manifest_id"])
            for k, v in st.items():
                artifacts[k] = artifacts.get(k, 0) + int(v or 0)
            deleted_ok += 1
        except Exception as exc:  # noqa: BLE001 - 单条失败不阻断其余，但如实上报
            logging.getLogger(__name__).warning("replay cleanup failed run=%s",
                                                x["run_id"], exc_info=True)
            x["error"] = "%s: %s" % (type(exc).__name__, str(exc)[:200])
            out.setdefault("errors", []).append({"run_id": x["run_id"],
                                                 "error": x["error"]})
    out["deleted"] = deleted_ok
    out["artifacts"] = artifacts
    try:
        with db.session() as c:
            if case_id:
                out["runs_after"] = int(c.execute(
                    "SELECT count(*) AS n FROM audit_run WHERE case_id=?",
                    (str(case_id),)).fetchone()["n"] or 0)
            else:
                out["runs_after"] = int(c.execute(
                    "SELECT count(*) AS n FROM audit_run").fetchone()["n"] or 0)
    except Exception:
        out["runs_after"] = None
    # 审计：清理动作必须留痕（不删审计，只追加）
    try:
        R.audit_logs.log(actor=actor or "system",
                         action="snapshot.replay_cleanup",
                         object=str(case_id or ""),
                         after=json.dumps({
                             "deleted": deleted_ok,
                             "protected": len(out["protected"]),
                             "artifacts": artifacts,
                             "keep_days": keep_days, "keep_last": keep_last,
                             "dry_run": False,
                         }, ensure_ascii=False, default=str))
    except Exception:
        logging.getLogger(__name__).warning("replay cleanup audit failed", exc_info=True)
    return out
