"""账号管理（P0）：管理员建号 / 重置密码 / 停用启用 / 列表。"""
from .. import auth, db
from .. import repositories as R
from . import permission_registry as _perm_reg


# L92：角色展示名/开号白名单不再手写，全部从权限注册表派生（禁止第二份角色名单）。
ROLE_LABEL = {code: _perm_reg.ROLE_LABELS[code] for code in _perm_reg.ROLE_CODES}

PORTAL_LABEL = {"platform": "平台端", "admin": "管理端", "reviewer": "审核端"}


def portal_of_role(role: str) -> str:
    # 未知/悬空角色 fail-closed：不落到任何门户（不再回退 home/admin）。
    if not _perm_reg.is_known_role(role):
        return ""
    if role == "platform_op":
        return "platform"
    if role in ("super_admin", "admin"):
        return "admin"
    if role == "reviewer":
        return "reviewer"
    return ""


def portal_of_roles(roles) -> str:
    ps = {portal_of_role(r) for r in (roles or []) if portal_of_role(r)}
    if len(ps) != 1:
        return ""
    return next(iter(ps))


def _username_for(c, phone: str, portal: str) -> str:
    """同一手机号可跨端存在，但 username 仍全局唯一。"""
    if not c.execute("SELECT 1 FROM user WHERE username=?", (phone,)).fetchone():
        return phone
    return f"{phone}#{portal}"






def department_of(user_id: str = "", name: str = "") -> str:
    """按用户 ID 或姓名取部门；无则返回空。"""
    try:
        u = R.users.get(user_id) if user_id else None
        if u:
            return (u.get("department") or "")
        if name:
            for x in R.users.list():
                if (x.get("name") or "") == name:
                    return (x.get("department") or "")
    except Exception:
        pass
    return ""


def departments_of(user_ids) -> dict:
    """批量取用户部门（id→department），单查询替代逐条 department_of。

    P2 慢节点最小修（/api/v1/feedback）：口径同 ``department_of(id)``——
    查不到该用户返回空串；查询失败返回 {} 由调用方回退旧逐条实现。
    """
    ids = [str(u) for u in dict.fromkeys(user_ids or ()) if str(u or "")]
    if not ids:
        return {}
    try:
        rows = R.users.list("id IN (%s)" % ",".join("?" * len(ids)), tuple(ids))
    except Exception:
        return {}
    return {str(u.get("id") or ""): (u.get("department") or "") for u in rows}

def roles_of(user_id: str) -> list:
    """一个账号可拥有的全部身份（按优先级）。"""
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?",
                (user_id,)).fetchall()
        codes = [r["code"] for r in rows]
        # L92：DB 里若残留未知/悬空角色（旧库未跑 seed 清理），一律不授予任何身份
        # （fail-closed；不再让 quality_director 这类历史角色进入权限/门户判定）。
        codes = [c for c in codes if _perm_reg.is_known_role(c)]
        order = {"super_admin": 0, "admin": 1, "reviewer": 2, "platform_op": 3}
        return sorted(codes, key=lambda x: order.get(x, 9))
    except Exception:
        return []


def _role_of(user_id: str) -> str:
    with db.session() as c:
        rows = c.execute("SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?",
                         (user_id,)).fetchall()
    codes = [r["code"] for r in rows]
    for pref in ("super_admin", "admin", "reviewer"):
        if pref in codes:
            return pref
    return codes[0] if codes else ""



def _add_role(user_id: str, role_code: str):
    with db.session() as c:
        c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) SELECT ?, id FROM role WHERE code=?",
                  (user_id, role_code))


def list_users(actor_role: str = "", actor_id: str = "") -> list:
    """账号列表。**只读脱敏出口**：返回行不含 ``initial_password`` 明文。

    DU-01（P0，2026-11-25）：修复前默认空参（``list_users()``）不做角色过滤，
    CLI ``user list`` 因此可被任意已知账号调用并 dump 全部租户账号 + 明文初始密码。
    现在数据范围 fail-closed：

    - ``super_admin``：只返回**本租户**账号；actor 行缺失或无租户身份 → 空列表
      （旧实现回落 ``SELECT * FROM user`` 全库 → 跨租户泄露）；
    - ``admin``（业务管理员）：只返回自己 + 自己开通的审核员，且必须同租户；
      业务管理员本无开号/看号权限，此分支只服务历史兼容与自省，HTTP 仍 403；
    - 其它/空角色：空列表（未鉴权不得枚举账号）。
    """
    out = []
    if actor_role not in ("super_admin", "admin"):
        return out
    try:
        _actor = R.users.get(actor_id) if actor_id else None
    except Exception:
        _actor = None
    if not _actor:
        # actor 行不存在：fail-closed，绝不回落到全库列表
        return []
    # 内置初始账号（seed 写入）历史上 tenant_id 为 NULL；HTTP 请求上下文对这类
    # 账号回落 ``t-default``（见 server._session_user）。列表口径与之同源，
    # 既不跨租户，也不让内置系统管理员看到空列表。
    _tid = str(_actor.get("tenant_id") or "t-default")
    try:
        with db.session() as _c:
            # 本租户账号 + 无租户归属的内置/历史账号（tenant NULL）：后者不属任何
            # 租户，不构成跨租户泄露；否则 seed 内置的四角色演示账号会在列表消失。
            _rows = _c.execute(
                "SELECT * FROM user WHERE (tenant_id=? OR COALESCE(tenant_id,'')='') "
                "ORDER BY created_at DESC", (_tid,)).fetchall()
        _users = [dict(x) for x in _rows]
    except Exception:
        _users = R.users.list("tenant_id=?", (_tid,), order="created_at DESC")
    for u in _users:
        _u_tid = str(u.get("tenant_id") or "")
        if _u_tid and _u_tid != _tid:
            continue
        role = _role_of(u["id"])
        # 平台运营账号在平台端维护，不出现在管理端账号列表
        if role == "platform_op":
            continue
        if actor_role == "admin":
            # 管理员：只保留自己 + 自己创建的审核员，其他管理员和超管一律不可见
            if u["id"] != actor_id:
                if role != "reviewer" or (u.get("created_by") or "") != actor_id:
                    continue
        out.append({
            "id": u["id"], "name": u.get("name") or "",
            "email": u.get("email") or "", "phone": u.get("phone") or "",
            "status": u.get("status") or "active", "role": role, "role_label": ROLE_LABEL.get(role, role),
            "created_at": u.get("created_at") or "", "last_login": u.get("last_login") or "",
            "department": u.get("department") or "",
            "must_change_pwd": bool(u.get("must_change_pwd")),
            # DU-01（L123，2026-11-25）：账号列表是**只读脱敏面**，明文初始密码只在
            # 创建/重置的响应里一次性返回；服务层从这里起就不再输出，避免 CLI/HTTP
            # 任意调用方（含未来新入口）误把凭据带到列表里。
            "is_initial": bool(u.get("is_initial")),
            "tenant_id": u.get("tenant_id") or "",
        })
    return out


# ---------------- 账号列表出口脱敏（DU-01：HTTP/CLI 同一实现） ----------------
# 背景：外部审核报告 DU-01（P0）——CLI ``user list`` 过去直接输出服务层原始行，
# 带出 ``initial_password`` 明文且无鉴权；HTTP 侧已有 ``_sanitize_user_item``，
# 但两份实现会让 CLI 与 HTTP 的输出口径漂移。现在唯一实现放在服务层，
# server.py（HTTP）与 cli.py（CLI）都调用这里，输出字段同源。
def sanitize_user_item(u: dict, viewer_id: str = "") -> dict:
    """账号列表单行：移除明文初始密码，补充待改密/自身/初始账号原因。"""
    d = dict(u or {})
    d.pop("initial_password", None)   # 初始密码只在创建/重置时一次性展示
    d["must_change_pwd"] = bool(d.get("must_change_pwd"))
    d["initial_account"] = bool(d.get("is_initial"))
    d["is_self"] = bool(viewer_id) and str(d.get("id") or "") == str(viewer_id)
    if d["is_self"]:
        d["manage_blocked_reason"] = "不能停用/删除当前登录的自身账号"
    elif d["initial_account"]:
        d["manage_blocked_reason"] = "内置初始账号不可停用/删除"
    else:
        d["manage_blocked_reason"] = ""
    d["status_label"] = "待改密" if (d["must_change_pwd"] and str(d.get("status")) == "active") else (
        "启用" if str(d.get("status")) == "active" else "停用")
    return d


def sanitize_users_payload(payload, viewer: dict = None):
    """账号列表载荷脱敏（list / paged dict 两种形状）+ 创建/重置策略说明。"""
    viewer = viewer or {}
    uid = str(viewer.get("sub") or viewer.get("id") or "")
    if isinstance(payload, list):
        return [sanitize_user_item(x, uid) for x in payload]
    if isinstance(payload, dict):
        if isinstance(payload.get("items"), list):
            payload["items"] = [sanitize_user_item(x, uid) for x in payload["items"]]
        try:
            payload["can_create_roles"] = list(CREATE_ROLE_ALLOWED.get("super_admin") or ())
            payload["create_role_note"] = "系统管理员可创建：系统管理员 / 业务管理员 / 审核员；同一手机号同一端只能有一个账号"
        except Exception:
            payload["can_create_roles"] = []
        payload["initial_password_policy"] = ("列表不展示初始密码；创建/重置时一次性展示，首次登录必须改密，"
                                              "改密后自动清除临时密码记录")
    return payload


# 账号开通权限：唯一事实源 permission_registry.CREATABLE_ROLES（L92）
# 系统管理员可开通其他系统管理员、业务管理员、审核员；业务管理员无开号权限；
# 白名单里的角色必须全部在注册表 ROLE_CODES 内（import 期即可发现悬空）。
CREATE_ROLE_ALLOWED = {actor: tuple(roles) for actor, roles in _perm_reg.CREATABLE_ROLES.items()}
for _actor, _roles in CREATE_ROLE_ALLOWED.items():
    _bad = [r for r in _roles if not _perm_reg.is_known_role(r)]
    if _bad:
        raise RuntimeError(f"CREATE_ROLE_ALLOWED 含未知角色：{_actor}->{_bad}")




def can_manage(actor_role: str, target_role: str) -> bool:
    """超管可管理所有人；管理员只能管理审核员。"""
    if actor_role == "super_admin":
        return True
    return False


def create_user(username: str, name: str, role: str = "", phone: str = "", email: str = "",
                password: str = "", created_by: str = "", actor_role: str = "super_admin",
                roles: list = None, tenant_id: str = "", department: str = "") -> dict:
    # 没有"账号"字段：登录标识 = 手机号或邮箱；内部仍用 username 列存手机号（兼容）
    phone = (phone or username or "").strip()
    username = phone
    if not phone:
        raise PermissionError("手机号不能为空")
    if not (len(phone) == 11 and phone.isdigit()):
        raise PermissionError("手机号必须为 11 位数字")
    want0 = list(roles or ([role] if role else []))
    if "super_admin" in want0 and "admin" in want0:
        raise PermissionError("同一手机号不能同时是系统管理员和业务管理员")
    _portal0 = portal_of_roles(want0)
    if not _portal0:
        raise PermissionError("一个账号只能属于一个端；同一手机号请分别开通管理端/审核端/平台端账号")
    # 同一手机号允许跨端，但不允许同一端重复；用裸表查询，避免被当前租户/空间作用域漏掉
    with db.session() as _cdup:
        _same = [dict(x) for x in _cdup.execute("SELECT id,phone,email,portal FROM user WHERE phone=? AND phone!=''", (phone,)).fetchall()]
        for _u in _same:
            _ur = _role_of(_u["id"])
            _up = _u.get("portal") or portal_of_role(_ur)
            if _up == _portal0:
                raise PermissionError(f"该手机号已在{ROLE_LABEL.get(_ur, _ur)}账号中存在")
        if email and _cdup.execute(
                "SELECT 1 FROM user WHERE email=? AND COALESCE(portal,'')=? LIMIT 1", (email, _portal0)).fetchone():
            raise PermissionError("该邮箱已存在")
    allow = CREATE_ROLE_ALLOWED.get(actor_role or "")
    if not allow:
        raise PermissionError("无开通账号权限")
    want = list(roles or ([role] if role else []))
    if not want:
        raise PermissionError("至少选择一个身份")
    # L92 未知角色 fail-closed：请求体里的任意未知角色直接拒绝（不只是白名单外）。
    _unknown = [r for r in want if not _perm_reg.is_known_role(r)]
    if _unknown:
        raise PermissionError(f"未知角色：{'、'.join(map(str, _unknown))}")
    _portal = portal_of_roles(want)
    if not _portal:
        raise PermissionError("一个账号只能属于一个端")
    username = _username_for(db.connect(), phone, _portal)
    bad = [r for r in want if r not in allow]
    if bad:
        raise PermissionError(f"当前身份只能开通：{'、'.join(ROLE_LABEL.get(r, r) for r in allow)}")
    from . import password_policy as _pwp
    _perr = _pwp.validate_new_password(password) if password else ""
    if _perr:
        raise PermissionError(_perr)
    pwd = password or auth.generate_password(10)
    h, salt = auth.hash_password(pwd)
    uid = db.new_id("user")
    # 系统管理员只能在本租户开号；目标租户由登录身份决定，前端不能选择。
    _actor = R.users.get(created_by) if created_by else None
    _actor_tid = (_actor or {}).get("tenant_id") or ""
    _requested_tid = (tenant_id or "").strip()
    if actor_role == "super_admin":
        if not _actor_tid:
            # 内部脚本/测试调用没有登录身份：落到请求租户或默认租户；API 调用始终有 actor。
            _actor_tid = _requested_tid or "t-default"
        if _requested_tid and _requested_tid != _actor_tid:
            raise PermissionError("系统管理员只能在本租户开通账号")
        _tid = _actor_tid
        _wrow = db.connect().execute("SELECT id FROM workspace WHERE tenant_id=? AND status='active' ORDER BY created_at LIMIT 1", (_tid,)).fetchone()
        _wid = _wrow["id"] if _wrow else ((_actor or {}).get("current_workspace_id") or "")
    else:
        _tid = _actor_tid
        _wid = (_actor or {}).get("current_workspace_id") or (_actor or {}).get("workspace_id") or ""
    R.users.insert(id=uid, username=username, name=name or phone, email=email, phone=phone,
                   status="active", password_hash=h, salt=salt, must_change_pwd=1,
                   initial_password=pwd,
                   created_at=db.now(), created_by=created_by, portal=_portal,
                   department=(department or "").strip(),
                   tenant_id=_tid, workspace_id=_wid, current_workspace_id=_wid)
    for r in want:
        _add_role(uid, r)
    R.audit_logs.log(actor=created_by or "system", action="account.created", object=uid,
                     after=f"{username}({'/'.join(ROLE_LABEL.get(r, r) for r in want)})")
    # 初始密码只返回给当前系统管理员用于交付，不写入审计日志
    return {"id": uid, "username": username, "created": True,
            "initial_password": pwd}


def reset_password(user_id: str, password: str = "", actor: str = "admin", actor_role: str = "super_admin") -> dict:
    u = R.users.get(user_id)
    if not u:
        raise ValueError("用户不存在")
    target_role = _role_of(user_id)
    if not can_manage(actor_role, target_role):
        raise ValueError("无权操作该账号（管理员只能管理审核员）")
    from . import password_policy as _pwp
    _perr = _pwp.validate_new_password(password) if password else ""
    if _perr:
        raise ValueError(_perr)
    pwd = password or auth.generate_password(10)
    h, salt = auth.hash_password(pwd)
    R.users.update(user_id, password_hash=h, salt=salt, must_change_pwd=1, initial_password=pwd)
    from . import password_reset as _pr
    rec = _pr.issue(user_id, pwd, actor=actor or "admin", source="system_admin")
    R.audit_logs.log(actor=actor or "admin", action="account.password_reset", object=user_id)
    return {"temporary_password": pwd, "reset_record_id": rec["id"], "expires_at": rec["expires_at"]}


def change_own_password(user_id: str, old_password: str, new_password: str) -> dict:
    """自助改密（HTTP ``POST /api/v1/me/password`` 与 CLI ``user change-password`` 唯一实现）。

    DU-09（P2，2026-11-25）：修复前 HTTP 只校验 ``len(new) >= 8``，首登账号可把密码设成
    ``aaaaaaaa``；``password_policy.validate_new_password`` 已存在但**未接线**改密路径。
    现在复杂度/常见弱口令校验统一走密码策略单一事实源（与创建/重置同口径），
    改密成功后清除初始密码、标记临时密码记录已使用、吊销旧 JWT（返回新版本号）。

    失败一律 ``ValueError``：``原密码错误`` / 策略文案 / ``用户不存在``。
    """
    # 用裸表读取：内置初始账号 tenant_id 为 NULL，而 HTTP 请求上下文会按会话租户
    # 给 R.users.get 追加租户过滤 → 作用域查询会误判“用户不存在”。改密前还要校验
    # 原密码，裸读不构成越权面。
    try:
        with db.session() as _c:
            _row = _c.execute("SELECT * FROM user WHERE id=?", (user_id,)).fetchone()
        u = dict(_row) if _row else None
    except Exception:
        u = None
    if not u:
        raise ValueError("用户不存在")
    if not auth.verify_password(old_password or "", u.get("password_hash") or "",
                                u.get("salt") or ""):
        raise ValueError("原密码错误")
    from . import password_policy as _pwp
    _perr = _pwp.validate_new_password(new_password or "")
    if _perr:
        raise ValueError(_perr)
    h, salt = auth.hash_password(new_password)
    R.users.update(user_id, password_hash=h, salt=salt, must_change_pwd=0, initial_password="")
    try:
        from . import password_reset as _prc
        _prc.mark_used(user_id, user_id)
    except Exception:  # noqa: BLE001 - 记录清理失败不影响改密（下次登录仍可用新密码）
        import logging as _log
        _log.getLogger(__name__).debug("password reset record mark used skipped", exc_info=True)
    try:
        _ver = auth.bump_token_version(user_id)
    except Exception:  # noqa: BLE001 - 吊销失败降级为新旧版本号+1，仍返回 200 但留告警
        import logging as _log
        _log.getLogger(__name__).warning("password change token_version bump failed", exc_info=True)
        _ver = int(u.get("token_version") or 0) + 1
    R.audit_logs.log(actor=user_id, action="user.password_changed", object=user_id, after="")
    return {"ok": True, "token_version": int(_ver or 0), "must_change_pwd": False}


def update_user(user_id: str, name: str = "", phone: str = "", email: str = "",
                actor: str = "", actor_role: str = "super_admin", department: str = "") -> dict:
    u = R.users.get(user_id)
    if not u:
        raise ValueError("用户不存在")
    target_role = _role_of(user_id)
    if actor_role != "super_admin":
        raise ValueError("账号管理仅系统管理员可用")
    _actor = R.users.get(actor) if actor else None
    if _actor and (_actor.get("tenant_id") or "") and (_actor.get("tenant_id") or "") != (u.get("tenant_id") or ""):
        raise ValueError("只能编辑本租户账号")
    # 手机号是绑定标识，不允许修改；只能停用或删除账号。
    if (phone or "").strip() and (phone or "").strip() != (u.get("phone") or ""):
        raise ValueError("手机号不可修改；如需变更请停用或删除账号后重新开通")
    name = (name or "").strip()
    email = (email or "").strip()
    if len(name) < 2:
        raise ValueError("姓名至少 2 个字")
    _portal_t = u.get("portal") or portal_of_role(target_role)
    if email and email != (u.get("email") or "") and any(
            (_x.get("portal") or portal_of_role(_role_of(_x["id"]))) == _portal_t
            for _x in R.users.list("email=?", (email,))):
        raise ValueError("该邮箱已存在")
    upd = {"name": name, "email": email, "department": (department or "").strip()}
    R.users.update(user_id, **upd)
    R.audit_logs.log(actor=actor or "admin", action="account.updated", object=user_id, after=name)
    return {"id": user_id, "updated": True}

def _is_last_super(tenant_id: str, exclude_id: str = "") -> bool:
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT u.id FROM user u JOIN user_role ur ON ur.user_id=u.id JOIN role r ON r.id=ur.role_id "
                "WHERE u.tenant_id=? AND r.code='super_admin' AND COALESCE(u.status,'active')='active'",
                (tenant_id,)).fetchall()
        ids = [x[0] for x in rows if x[0] != exclude_id]
        return len(ids) == 0
    except Exception:
        return False


def set_status(user_id: str, status: str, actor: str = "admin", actor_role: str = "super_admin") -> dict:
    if status not in ("active", "disabled"):
        raise ValueError("状态只能是 active/disabled")
    u = R.users.get(user_id)
    if not u:
        raise ValueError("用户不存在")
    if actor_role != "super_admin":
        raise ValueError("账号管理仅系统管理员可用")
    if user_id == actor:
        raise ValueError("不能停用当前登录账号")
    target_role = _role_of(user_id)
    _actor = R.users.get(actor) if actor else None
    if _actor and (_actor.get("tenant_id") or "") and (_actor.get("tenant_id") or "") != (u.get("tenant_id") or ""):
        raise ValueError("只能操作本租户账号")
    if target_role == "super_admin":
        if u.get("is_initial"):
            raise ValueError("初始系统管理员不能停用")
        if _is_last_super(u.get("tenant_id") or "", user_id):
            raise ValueError("至少保留一个启用状态的系统管理员")
    R.users.update(user_id, status=status)
    R.audit_logs.log(actor=actor or "admin", action="account.status_changed", object=user_id, after=status)
    return {"id": user_id, "status": status}


def delete_user(user_id: str, actor: str = "admin", actor_role: str = "super_admin") -> dict:
    if actor_role != "super_admin":
        raise ValueError("账号管理仅系统管理员可用")
    u = R.users.get(user_id)
    if not u:
        raise ValueError("用户不存在")
    if user_id == actor:
        raise ValueError("不能删除当前登录账号")
    if u.get("is_initial"):
        raise ValueError("初始系统管理员不能删除")
    target_role = _role_of(user_id)
    _actor = R.users.get(actor) if actor else None
    if _actor and (_actor.get("tenant_id") or "") and (_actor.get("tenant_id") or "") != (u.get("tenant_id") or ""):
        raise ValueError("只能删除本租户账号")
    if target_role == "super_admin" and _is_last_super(u.get("tenant_id") or "", user_id):
        raise ValueError("至少保留一个系统管理员")
    R.audit_logs.log(actor=actor or "admin", action="account.deleted", object=user_id,
                     after=f"{u.get('name') or ''}/{u.get('phone') or ''}")
    with db.session() as c:
        c.execute("DELETE FROM user_role WHERE user_id=?", (user_id,))
        c.execute("DELETE FROM user_workspace WHERE user_id=?", (user_id,))
        c.execute("DELETE FROM user WHERE id=?", (user_id,))
        c.commit()
    return {"id": user_id, "deleted": True}

def list_users_page(actor_role: str = "", actor_id: str = "", q: str = "",
                    role: str = "", status: str = "", page: int = 1,
                    page_size: int = 20) -> dict:
    rows = list_users(actor_role, actor_id)
    q = (q or "").strip().lower()
    if q:
        rows = [u for u in rows if q in (u.get("name") or "").lower()
                or q in (u.get("phone") or "").lower() or q in (u.get("email") or "").lower()]
    if role:
        rows = [u for u in rows if u.get("role") == role]
    if status:
        rows = [u for u in rows if (u.get("status") or "active") == status]
    page = max(1, int(page or 1)); page_size = min(100, max(5, int(page_size or 20)))
    total = len(rows); pages = max(1, (total + page_size - 1) // page_size)
    page = min(page, pages)
    return {"items": rows[(page - 1) * page_size: page * page_size], "total": total,
            "page": page, "pages": pages, "page_size": page_size}
