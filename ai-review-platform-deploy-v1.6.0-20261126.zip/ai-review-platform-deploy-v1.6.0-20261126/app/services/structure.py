"""文档结构层：把正文切成可引用的「条款实例」，为判定提供最小单位。"""
import re

_CLAUSE_HEAD = re.compile(
    r"^\s*(第[一二三四五六七八九十百零〇\d]+条|[一二三四五六七八九十]+[、.]|"
    r"\d+[.、)]|\(\d+\)|（\d+）|[A-Z][.)]\s|Article\s+\d+|Section\s+\d+)", re.I)


def segment(text: str, min_len: int = 12) -> list:
    """按条款编号/段落切分，返回 [{id, start, end, text, kind}]。"""
    text = text or ""
    lines = text.splitlines(keepends=True)
    out, pos, buf, start = [], 0, [], 0

    def flush(end_pos):
        nonlocal buf, start
        body = "".join(buf).strip()
        if len(body) >= min_len:
            out.append({"id": f"C{len(out) + 1}", "start": start, "end": end_pos,
                        "text": body, "kind": "clause"})
        buf = []

    for ln in lines:
        if _CLAUSE_HEAD.match(ln) and buf:
            flush(pos)
            start = pos
        if not buf:
            start = pos
        buf.append(ln)
        pos += len(ln)
    flush(pos)
    if not out and text.strip():
        out.append({"id": "C1", "start": 0, "end": len(text), "text": text.strip(), "kind": "doc"})
    return out


def locate(clauses: list, quote: str) -> dict:
    """把引文定位到条款（精确子串优先，其次前 20 字匹配）。"""
    q = (quote or "").strip()
    if not q:
        return {}
    for c in clauses:
        if q in c["text"]:
            return c
    head = q[:20]
    if len(head) >= 8:
        for c in clauses:
            if head in c["text"]:
                return c
    return {}


def norm_with_map(text: str):
    """返回 (归一化文本, 归一化下标 -> 原文下标映射)。"""
    out, idx = [], []
    for i, ch in enumerate(text or ""):
        if ch in " \t\r\n\u3000":
            continue
        c = {"％": "%", "，": ",", "：": ":"}.get(ch, ch)
        out.append(c)
        idx.append(i)
    return "".join(out), idx


def find_span(text: str, anchor: str, pad: int = 40):
    """在原文中按“归一化后包含”定位锚点，返回原文片段（含上下文）与起止下标。"""
    nq = (anchor or "").strip()
    if not nq:
        return None
    nd, idx = norm_with_map(text)
    nq_norm, _ = norm_with_map(nq)
    if not nq_norm:
        return None
    pos = nd.find(nq_norm)
    if pos < 0:
        return None
    start = idx[pos]
    end = idx[pos + len(nq_norm) - 1] + 1
    return {"quote": (text or "")[max(0, start - pad): min(len(text), end + pad)].strip(),
            "start": start, "end": end}
