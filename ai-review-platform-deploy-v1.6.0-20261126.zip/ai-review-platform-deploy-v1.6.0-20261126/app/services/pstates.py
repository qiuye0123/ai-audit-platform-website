"""点位五态落库：pass / fail / na / insufficient / unknown 全部记录，用于计算真实覆盖率。

P1-8（2026-11-21）：``record`` 不再 `except Exception: continue` 静默吞单行写失败。
失败行收集后抛 :class:`LedgerWriteError`（结构化，带 batch + point_id 列表），
同时把失败批次写入 ``point_state_write_failure`` 标记表；``report_gate.check``
对 ``ledger_incomplete`` 的 run/batch 追加阻断 reason（覆盖度分母残缺不得签发）。

回滚面：
  · 行为回滚：``RULEPROOF_LEDGER_STRICT=0`` 恢复旧口径（只 warning、不抛错、不标记）。
  · 表回滚：``DROP TABLE IF EXISTS point_state_write_failure;``（仅标记表，无业务数据）。
"""
import json
import logging
import uuid

from .. import db
from .. import repositories as R

STATES = ("pass", "fail", "na", "insufficient", "unknown")

LOG = logging.getLogger(__name__)

# 「台账不完整」标记表：按 batch 记录写失败（一次 run 可能多 batch）。
# L169：SQL 一律用**字面量表名**（不再用 f-string 拼 {FAILURE_TABLE}），让
# system_consistency_scan 的 S4 能静态识别产品读写路径；常量仅用于 DDL 兜底分组名。
FAILURE_TABLE = "point_state_write_failure"
# L109（2026-11-25）：DDL 单一事实源 = app/db.py 的
# RUNTIME_EXTENSION_SCHEMA["point_state_write_failure"]；本模块只在运行期兜底。
_FAILURE_READY = False


class LedgerWriteError(RuntimeError):
    """点位台账部分行写入失败（不得静默吞掉：覆盖度分母会缩水）。"""

    def __init__(self, batch_id: str, failed: list, total: int = 0):
        self.batch_id = str(batch_id or "")
        self.failed = list(failed or [])
        self.total = int(total or 0)
        self.point_ids = [str((x or {}).get("point_id") or "") for x in self.failed]
        super().__init__(
            f"点位台账写入失败 {len(self.failed)}/{self.total} 行"
            f"（batch={self.batch_id}，失败 point_id={self.point_ids[:20]}）")


def _strict_on() -> bool:
    """默认严（抛错 + 标记）；显式 ``RULEPROOF_LEDGER_STRICT=0`` 回退旧口径。"""
    import os
    return str(os.environ.get("RULEPROOF_LEDGER_STRICT", "1")).strip() != "0"


def _ensure_failure_table() -> bool:
    global _FAILURE_READY
    if _FAILURE_READY:
        return True
    try:
        with db.session() as c:
            db.ensure_runtime_schema(c, FAILURE_TABLE)
        _FAILURE_READY = True
        return True
    except Exception:  # noqa: BLE001
        LOG.warning("point_state_write_failure schema init failed", exc_info=True)
        return False


def mark_ledger_incomplete(batch_id: str, failed: list, total: int = 0,
                           source: str = "", case_id: str = "") -> dict:
    """标记某 batch 的台账写不完整（幂等；同一 batch 取并集）。调用方/门禁共用。"""
    bids = [str((x or {}).get("point_id") or "") if isinstance(x, dict) else str(x)
            for x in (failed or [])]
    if not _ensure_failure_table():
        return {"ok": False, "error": "标记表不可用", "batch_id": str(batch_id or ""),
                "failed": bids}
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT failed_json, failed_count FROM point_state_write_failure "
                "WHERE batch_id=?", (str(batch_id or ""),)).fetchone()
            merged = []
            try:
                merged = list(json.loads((row["failed_json"] if row else "") or "[]"))
            except Exception:
                merged = []
            for pid in bids:
                if pid and pid not in merged:
                    merged.append(pid)
            c.execute(
                "INSERT INTO point_state_write_failure"
                "(batch_id,case_id,failed_json,failed_count,"
                "total,source,created_at) VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(batch_id) DO UPDATE SET failed_json=excluded.failed_json,"
                "failed_count=excluded.failed_count,total=excluded.total,"
                "source=excluded.source",
                (str(batch_id or ""), str(case_id or ""),
                 json.dumps(merged, ensure_ascii=False), len(merged),
                 int(total or 0), str(source or "")[:80], db.now()))
        return {"ok": True, "batch_id": str(batch_id or ""), "failed": merged,
                "count": len(merged)}
    except Exception:  # noqa: BLE001
        LOG.warning("mark ledger incomplete failed batch=%s", batch_id, exc_info=True)
        return {"ok": False, "error": "标记写入失败", "batch_id": str(batch_id or ""),
                "failed": bids}


def mark_run_ledger_incomplete(run_id: str, failed: list = None,
                               source: str = "", reason: str = "") -> dict:
    """把一次 run 标 ``ledger_incomplete``（写 audit_run.trace_json，不新增表/列）。"""
    rid = str(run_id or "").strip()
    if not rid:
        return {"ok": False, "error": "run_id 为空"}
    bids = [str((x or {}).get("point_id") or "") if isinstance(x, dict) else str(x)
            for x in (failed or [])]
    try:
        with db.session() as c:
            row = c.execute("SELECT trace_json FROM audit_run WHERE id=?", (rid,)).fetchone()
            if not row:
                return {"ok": False, "error": "run 不存在", "run_id": rid}
            try:
                trace = json.loads(row["trace_json"] or "{}")
                if not isinstance(trace, dict):
                    trace = {}
            except Exception:
                trace = {}
            trace["ledger_incomplete"] = {
                "flag": True, "source": str(source or "")[:80],
                "reason": str(reason or "")[:300],
                "failed_point_ids": bids[:200], "failed_count": len(bids),
                "marked_at": db.now()}
            c.execute("UPDATE audit_run SET trace_json=? WHERE id=?",
                      (json.dumps(trace, ensure_ascii=False), rid))
        return {"ok": True, "run_id": rid, "failed_count": len(bids)}
    except Exception:  # noqa: BLE001
        LOG.warning("mark run ledger incomplete failed run=%s", rid, exc_info=True)
        return {"ok": False, "error": "run 标记写入失败", "run_id": rid}


def ledger_incomplete(batches: list = None, run_id: str = "") -> dict:
    """查询台账不完整标记：run 级（trace_json）+ batch 级（标记表）合并。"""
    out = {"flag": False, "run_id": str(run_id or ""), "batches": [],
           "failed_count": 0, "rows": [], "sources": []}
    if not _ensure_failure_table():
        # 标记表不可用 → 不能证明台账完整：按严口径视作不完整（fail-closed）
        out.update({"flag": True, "error": "标记表不可用",
                    "sources": ["marker_table_unavailable"]})
        return out
    bids = [str(x) for x in (batches or []) if str(x)]
    rows = []
    try:
        with db.session() as c:
            for b in bids:
                r = c.execute(
                    "SELECT * FROM point_state_write_failure WHERE batch_id=?",
                    (b,)).fetchone()
                if r:
                    rows.append(dict(r))
            if run_id:
                r = c.execute("SELECT trace_json FROM audit_run WHERE id=?",
                              (str(run_id),)).fetchone()
                marker = {}
                if r:
                    try:
                        marker = (json.loads(r["trace_json"] or "{}") or {}).get(
                            "ledger_incomplete") or {}
                    except Exception:
                        marker = {}
                if marker.get("flag"):
                    out["flag"] = True
                    out["sources"].append("run_trace")
                    out["failed_count"] += int(marker.get("failed_count") or 0)
                    out["rows"].append({"batch_id": "", "run_id": str(run_id),
                                        "marker": marker})
    except Exception:  # noqa: BLE001
        LOG.warning("ledger incomplete lookup failed", exc_info=True)
        out.update({"flag": True, "error": "标记读取失败",
                    "sources": ["lookup_error"]})
        return out
    if rows:
        out["flag"] = True
        out["sources"].append("batch_marker")
        out["batches"] = [str(x.get("batch_id") or "") for x in rows]
        for r in rows:
            try:
                ids = json.loads(r.get("failed_json") or "[]")
            except Exception:
                ids = []
            out["failed_count"] += len(ids)
            out["rows"].append({"batch_id": r.get("batch_id"), "failed": ids,
                                "source": r.get("source") or "",
                                "created_at": r.get("created_at") or ""})
    out["sources"] = sorted(set(out["sources"]))
    return out


def new_batch() -> str:
    return uuid.uuid4().hex[:12]


def record(batch: str, rows: list, source: str = "", case_id: str = "") -> int:
    """落五态台账；**单行写失败不得静默吞**（P1-8）。

    成功行照常落库；失败行收集后：
      1) 先写 batch 级 ``ledger_incomplete`` 标记（即使调用方吞异常，门禁仍能读到）；
      2) 抛 :class:`LedgerWriteError`（带 batch + point_id 列表）让调用方感知。
    显式 ``RULEPROOF_LEDGER_STRICT=0`` 恢复旧口径（只 warning、不抛错/不标记）。
    """
    if not rows:
        return 0
    n = 0
    failed = []
    for r in rows:
        r = r or {}
        st = str(r.get("state") or "unknown")
        if st not in STATES:
            st = "unknown"
        pid = str(r.get("point_id") or r.get("code") or "")
        try:
            # L27 Phase0 Task 0.1：可选携带原文区间（老库由 db.init_db 幂等补列；
            # 调用方未给时写列默认值，逐字段回退）。
            R.point_states.insert(id=db.new_id("ps"), batch_id=batch,
                                  point_id=pid,
                                  state=st, confidence=r.get("confidence"),
                                  reason=str(r.get("reason") or "")[:300],
                                  quote=str(r.get("quote") or "")[:200],
                                  title=str(r.get("title") or "")[:60],
                                  file_id=str(r.get("file_id") or ""),
                                  verbatim_quote=str(r.get("verbatim_quote") or "")[:500],
                                  char_start=int(r.get("char_start", -1) or -1),
                                  char_end=int(r.get("char_end", -1) or -1),
                                  anchor_mode=str(r.get("anchor_mode") or "unanchored"),
                                  created_at=db.now())
            n += 1
        except Exception as e:  # noqa: BLE001
            failed.append({"point_id": pid, "error": f"{type(e).__name__}: {str(e)[:200]}"})
    if not failed:
        return n
    total = len(rows)
    if not _strict_on():
        LOG.warning("点位台账写入失败 %s/%s 行（RULEPROOF_LEDGER_STRICT=0 降级放行）"
                    "batch=%s failed=%s", len(failed), total, batch,
                    [x["point_id"] for x in failed][:20])
        return n
    # 标记必须尽力写入（写标记本身失败也不能掩盖原始错误：错误仍上抛）
    mark_ledger_incomplete(batch, failed, total=total, source=source, case_id=case_id)
    LOG.error("点位台账写入失败 %s/%s 行 batch=%s failed=%s",
              len(failed), total, batch, [x["point_id"] for x in failed][:20])
    raise LedgerWriteError(batch, failed, total=total)


def coverage_batches(batches: list) -> dict:
    """按一组批次统计（一次审核可能因多文件产生多个批次）。"""
    if not batches:
        return {"batch": "", "total": 0, "note": "本次审核没有判定记录"}
    rows = []
    for b in batches:
        rows.extend(R.point_states.list("batch_id=?", (b,)))
    total = len(rows)
    if not total:
        return {"batch": ",".join(batches), "total": 0}
    counts = {s: 0 for s in STATES}
    for r in rows:
        counts[r.get("state") or "unknown"] = counts.get(r.get("state") or "unknown", 0) + 1
    judged = counts["pass"] + counts["fail"]
    return {"batch": ",".join(batches), "total": total, **counts,
            "judged_rate": round(judged / total, 3),
            "na_rate": round(counts["na"] / total, 3),
            "abstain_rate": round((counts["insufficient"] + counts["unknown"]) / total, 3)}


def coverage(batch: str = "") -> dict:
    """按批次统计覆盖率。batch 为空时返回「全部」汇总，不做"最近批次"猜测。"""
    rows = R.point_states.list("batch_id=?", (batch,)) if batch else R.point_states.list()
    total = len(rows)
    if not total:
        return {"batch": batch, "total": 0, "note": "尚无可统计的判定记录"}
    counts = {s: 0 for s in STATES}
    for r in rows:
        counts[r.get("state") or "unknown"] = counts.get(r.get("state") or "unknown", 0) + 1
    judged = counts["pass"] + counts["fail"]
    return {"batch": batch, "total": total, **counts,
            "judged_rate": round(judged / total, 3),
            "na_rate": round(counts["na"] / total, 3),
            "abstain_rate": round((counts["insufficient"] + counts["unknown"]) / total, 3)}


def detail(batch: str = "", limit: int = 500) -> list:
    """点位明细：状态 + 理由 + 引文，供前端“查过了”视图使用。"""
    where, args = ("batch_id=?", (batch,)) if batch else ("1=1", ())
    rows = R.point_states.list(where + " ORDER BY point_id", args, limit=limit)
    return [{"point_id": r.get("point_id"), "title": r.get("title") or "",
             "state": r.get("state"), "confidence": r.get("confidence"),
             "reason": r.get("reason") or "", "quote": r.get("quote") or "",
             "file_id": r.get("file_id") or ""} for r in rows]


def summary(batch: str = "") -> dict:
    rows = detail(batch, limit=5000)
    out = {}
    for r in rows:
        out[r["state"]] = out.get(r["state"], 0) + 1
    return {"total": len(rows), "by_state": out}


def flips(file_id: str) -> list:
    """同一文件同一点位在不同批次里出现 pass 与 fail 的，即为翻转点，必须人工复核。"""
    if not file_id:
        return []
    c = db.connect()
    try:
        rows = c.execute("SELECT point_id, GROUP_CONCAT(DISTINCT state) FROM point_state "
                         "WHERE file_id=? GROUP BY point_id", (file_id,)).fetchall()
    finally:
        c.close()
    out = []
    for pid, states in rows:
        ss = set((states or "").split(","))
        if {"pass", "fail"} <= ss:
            out.append(pid)
    return sorted(out)


EXECUTION = {
    "pass": "completed",
    "fail": "completed",
    "na": "not_applicable",
    "insufficient": "evidence_insufficient",
    "unknown": "not_judged",
    "missing": "not_executed",
}

# ---------------- L78（2026-11-24）：多实例 cap 截断可观测 ----------------
# 背景（90 号 §二-6 / L67 §9.2）：MI cap 截断此前只在审计里，报告/台账看不到
# 「已检出 N 处、仅展示前 K」。manifest_exec 把统一字段落 point_state
# （generated_count/kept_count/cap_truncated/mi_limit）与 run 返回（d5.multi_instance），
# 本段负责台账同源展示与提示文案（报告 report.py 复用同一函数，不复制口径）。
MI_RECORD_FIELDS = ("generated_count", "kept_count", "cap_truncated", "limit")


def multi_instance_notice_text(notice: dict) -> str:
    """统一截断提示文案（台账/报告同源，不允许两套措辞）。

    格式：``已检出 {N} 处，仅展示前 {K}，需人工复核（规则 {code} · 对象 {obj} · 上限 {limit}）``
    """
    n = notice if isinstance(notice, dict) else {}
    try:
        generated = int(n.get("generated_count") or 0)
        kept = int(n.get("kept_count") or 0)
    except (TypeError, ValueError):
        generated, kept = 0, 0
    try:
        limit = int(n.get("limit") or n.get("mi_limit") or 0)
    except (TypeError, ValueError):
        limit = 0
    rule = str(n.get("rule") or n.get("point_id") or "")
    obj = str(n.get("object") or n.get("object_id") or "")
    detail = "（规则 %s%s%s）" % (rule, (" · 对象 " + obj) if obj else "",
                                 (" · 上限 " + str(limit)) if limit else "") if (rule or limit) else ""
    return "已检出 %d 处，仅展示前 %d，需人工复核%s" % (generated, kept, detail)


def _ledger_batches(case_id: str = "", batch: str = "") -> list:
    """解析台账批次：显式 batch 优先；否则取该 case 最近一次 audit_run 的 batch_ids。"""
    batches = [x for x in str(batch or "").split(",") if x]
    if batches or not case_id:
        return batches
    try:
        c = db.connect()
        row = c.execute("SELECT id, batch_ids FROM audit_run WHERE case_id=? "
                        "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
        _ids = [x for x in str((row["batch_ids"] if row else "") or "").split(",") if x]
        if not _ids and row is not None:
            # L78：manifest 链的 point_state 批次键 = 该 manifest 最新 audit_run.id
            # （manifest_exec.d5_point_log_batch 口径），batch_ids 只记语义复核批次。
            _run_id = str(row["id"] or "")
            if _run_id:
                _has = c.execute("SELECT 1 FROM point_state WHERE batch_id=? LIMIT 1",
                                 (_run_id,)).fetchone()
                if _has:
                    _ids = [_run_id]
        c.close()
        return _ids
    except Exception:  # 铁律 2：批次解析失败留痕，返回空（台账按旧口径继续）
        LOG.warning("L78 多实例提示：台账批次解析失败 case=%s", case_id, exc_info=True)
        return []


def multi_instance_notices(case_id: str = "", batch: str = "",
                           limit: int = 200) -> dict:
    """收集本次审核的 MI cap 截断项（point_state 优先，manifest_result d5_json 兜底）。

    返回 ``{"notices": [...], "truncated_count": n, "total_generated": g,
    "total_kept": k, "note": ""|"已检出 N 处…", "source": "point_state|manifest_result|"}``。
    无截断 → notices 为空、note 为空串（报告/台账不显示提示，不虚报）。
    每条 notice：``{rule, object, generated_count, kept_count, limit, note}``。
    """
    batches = _ledger_batches(case_id=case_id, batch=batch)
    notices, seen, source = [], set(), ""

    def _add(rule, obj, generated, kept, cap, src):
        nonlocal source
        key = (str(rule or ""), str(obj or ""))
        if key in seen:
            return
        seen.add(key)
        source = source or src
        item = {"rule": str(rule or ""), "object": str(obj or ""),
                "generated_count": int(generated or 0),
                "kept_count": int(kept or 0), "limit": int(cap or 0)}
        item["note"] = multi_instance_notice_text(item)
        notices.append(item)

    if batches:
        for b in batches:
            try:
                rows = R.point_states.list("batch_id=?", (b,), limit=limit)
            except Exception:
                rows = []
            for r in rows:
                if not int(r.get("cap_truncated") or 0):
                    continue
                _add(r.get("point_id"), r.get("file_id"),
                     r.get("generated_count"), r.get("kept_count"),
                     r.get("mi_limit"), "point_state")
    # 兜底：point_state 未开（RULEPROOF_D5_POINT_LOG=0）或旧批次 → 读 manifest_result.d5_json
    if case_id and not notices:
        try:
            c = db.connect()
            ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                           "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                           (case_id,)).fetchone()
            mid = str((ar["manifest_id"] if ar else "") or "")
            _objs = {}
            if mid:
                m = c.execute("SELECT objects_json FROM audit_manifest WHERE id=?",
                              (mid,)).fetchone()
                import json as _j
                for _o in _j.loads((m["objects_json"] if m else "") or "[]"):
                    _objs[str(_o.get("object_id") or "")] = str(_o.get("filename") or "")
            rows = c.execute("SELECT rule_code, object_id, d5_json FROM manifest_result "
                             "WHERE manifest_id=?", (mid,)).fetchall() if mid else []
            c.close()
            import json as _j
            for r in rows:
                try:
                    _d5 = _j.loads(r["d5_json"] or "{}") or {}
                except Exception:
                    _d5 = {}
                mi = _d5.get("multi_instance") if isinstance(_d5.get("multi_instance"), dict) else {}
                if not mi or not mi.get("cap_truncated"):
                    continue
                _add(mi.get("rule") or r["rule_code"], _objs.get(str(r["object_id"] or ""),
                                                                  str(r["object_id"] or "")),
                     mi.get("generated_count"), mi.get("kept_count"),
                     mi.get("limit"), "manifest_result")
        except Exception:  # 铁律 2：兜底读取失败留痕，不阻断台账
            LOG.warning("L78 多实例提示：manifest_result 兜底读取失败 case=%s",
                        case_id, exc_info=True)
    total_g = sum(int(n.get("generated_count") or 0) for n in notices)
    total_k = sum(int(n.get("kept_count") or 0) for n in notices)
    note = ""
    if notices:
        # 文案与 multi_instance_notice_text 同源：固定短语「已检出 N 处，仅展示前 K，需人工复核」
        note = ("本次审核有 %d 个（文档 × 规则）多实例点位发生 cap 截断，"
                "已检出 %d 处，仅展示前 %d，需人工复核。"
                % (len(notices), total_g, total_k))
    return {"notices": notices, "truncated_count": len(notices),
            "total_generated": total_g, "total_kept": total_k,
            "note": note, "source": source}


def ledger(batch: str = "", case_id: str = "", limit: int = 2000) -> dict:
    """对象级审核台账：每条点位判定都有对象/状态/证据，不再只存违规发现。"""
    batches = [x for x in str(batch or "").split(",") if x]
    if not batches and case_id:
        try:
            c = db.connect()
            row = c.execute("SELECT batch_ids FROM audit_run WHERE case_id=? ORDER BY created_at DESC LIMIT 1",
                            (case_id,)).fetchone()
            c.close()
            batches = [x for x in str((row["batch_ids"] if row else "") or "").split(",") if x]
        except Exception:
            batches = []
    rows = []
    for b in batches:
        rows.extend(R.point_states.list("batch_id=?", (b,), limit=limit))
    if not batches and not case_id:
        rows = R.point_states.list(limit=limit)
    # 应审计划：优先 manifest（规则版本×对象），回退执行器 plan
    expected = []
    manifest_id, mitems = "", []
    if case_id:
        try:
            c0 = db.connect()
            _ar = c0.execute("SELECT plan_json, manifest_id FROM audit_run WHERE case_id=? ORDER BY created_at DESC LIMIT 1",
                             (case_id,)).fetchone()
            c0.close()
            if _ar:
                import json as _j
                manifest_id = _ar["manifest_id"] or ""
                if manifest_id:
                    c1 = db.connect()
                    _m = c1.execute("SELECT items_json FROM audit_manifest WHERE id=?", (manifest_id,)).fetchone()
                    c1.close()
                    mitems = _j.loads((_m["items_json"] if _m else "") or "[]")
                if _ar["plan_json"]:
                    expected = _j.loads(_ar["plan_json"] or "[]")
        except Exception:
            expected = []
    seen = {str(r.get("point_id") or "") for r in rows}
    # manifest_result 是正式 D1–D5 结果：并入台账，但不与 point_state 重复
    if manifest_id:
        try:
            c2 = db.connect()
            _objs = c2.execute("SELECT objects_json FROM audit_manifest WHERE id=?", (manifest_id,)).fetchone()
            _objmap = {}
            import json as _j
            if _objs:
                for _o in _j.loads(_objs["objects_json"] or "[]"):
                    _objmap[_o.get("object_id") or ""] = _o.get("filename") or ""
            for _mr in c2.execute("SELECT * FROM manifest_result WHERE manifest_id=?", (manifest_id,)):
                _m = dict(_mr)
                _state = {"满足": "pass", "不满足": "fail", "不适用": "na",
                          "证据不足": "insufficient", "无法判断": "unknown"}.get(
                              str(_m.get("conclusion") or ""), "unknown")
                _code = str(_m.get("rule_code") or "")
                _obj = _objmap.get(_m.get("object_id") or "", "")
                if any(str(x.get("point_id") or "") == _code and str(x.get("file_id") or "") == _obj for x in rows):
                    continue
                _mi_m = {}
                try:
                    _d5_m = _j.loads(_m.get("d5_json") or "{}") or {}
                    if isinstance(_d5_m.get("multi_instance"), dict):
                        _mi_m = _d5_m["multi_instance"]
                except Exception:
                    _mi_m = {}
                rows.append({"batch_id": "", "point_id": _code, "title": "",
                             "state": _state, "file_id": _obj, "confidence": None,
                             "reason": f"manifest:{_m.get('execution') or ''}", "quote": "",
                             "execution": _m.get("execution") or "",
                             # L78：manifest_result.d5_json 的多实例可观测字段
                             "generated_count": int(_mi_m.get("generated_count") or 0),
                             "kept_count": int(_mi_m.get("kept_count") or 0),
                             "cap_truncated": bool(_mi_m.get("cap_truncated")),
                             "mi_limit": int(_mi_m.get("limit") or 0)})
            c2.close()
        except Exception:
            pass
    for it in mitems or []:
        code = str((it or {}).get("code") or "")
        obj = str((it or {}).get("filename") or "")
        # 同一规则可能对应多个对象；以 规则码+对象 判重
        key = f"{code}|{obj}"
        if any(str(r.get("point_id") or "") == code and str(r.get("file_id") or "") == obj for r in rows):
            continue
        if key in seen:
            continue
        seen.add(key)
        rows.append({"batch_id": "", "point_id": code, "title": (it or {}).get("name") or "",
                     "state": "missing", "file_id": obj, "confidence": None,
                     "reason": "应审但未执行（manifest）", "quote": ""})
    for e in expected or []:
        pid = str((e or {}).get("point_id") or "")
        if pid and pid not in seen:
            rows.append({"batch_id": "", "point_id": pid, "title": (e or {}).get("title") or "",
                         "state": "missing", "file_id": "", "confidence": None,
                         "reason": "应审但未执行", "quote": ""})
            seen.add(pid)
    out = []
    for r in rows:
        st = str(r.get("state") or "unknown")
        out.append({
            "batch_id": r.get("batch_id"),
            "object": r.get("file_id") or "",
            "point_id": r.get("point_id"),
            "title": r.get("title") or "",
            "state": st,
            "applicable": st != "na",
            "execution": EXECUTION.get(st, "not_judged"),
            "confidence": r.get("confidence"),
            "reason": r.get("reason") or "",
            "quote": r.get("quote") or "",
            # L78：多实例 cap 截断可观测字段（非 MI 规则为 0/false，旧消费者可忽略）
            "generated_count": int(r.get("generated_count") or 0),
            "kept_count": int(r.get("kept_count") or 0),
            "cap_truncated": bool(r.get("cap_truncated")),
            "limit": int(r.get("mi_limit") or r.get("limit") or 0),
        })
    counts = {s: 0 for s in STATES}
    counts["missing"] = 0
    for r in out:
        counts[r["state"]] = counts.get(r["state"], 0) + 1
    # L78（2026-11-24）：多实例 cap 截断在台账显式提示（不静默；无截断则不新增文案）
    payload = {"batches": batches, "total": len(out), "counts": counts,
               "expected": len(expected or []), "manifest_id": manifest_id,
               "manifest_items": len(mitems or []), "missing": counts.get("missing", 0),
               "records": out,
               "note": "na 不等于 pass；insufficient/unknown 不得计入通过"}
    try:
        _mi = multi_instance_notices(case_id=case_id, batch=",".join(batches))
        payload["multi_instance_notices"] = _mi["notices"]
        payload["multi_instance_truncated"] = int(_mi["truncated_count"])
        payload["multi_instance_generated"] = int(_mi["total_generated"])
        payload["multi_instance_kept"] = int(_mi["total_kept"])
        payload["multi_instance_note"] = _mi["note"]
        payload["multi_instance_source"] = _mi["source"]
    except Exception:  # 铁律 2：提示构建失败留痕，不阻断台账
        LOG.warning("L78 多实例台账提示构建失败 case=%s", case_id, exc_info=True)
    return payload


def unknown_classes(case_id: str, batches: list | None = None) -> dict:
    """unknown 三分类：customer_rule / platform_builtin / not_applicable。"""
    bs = batches if batches is not None else None
    if bs is None:
        try:
            c = db.connect()
            r = c.execute("SELECT batch_ids FROM audit_run WHERE case_id=? ORDER BY created_at DESC LIMIT 1",
                          (case_id,)).fetchone()
            c.close()
            bs = [x for x in str((r["batch_ids"] if r else "") or "").split(",") if x]
        except Exception:
            bs = []
    try:
        rules = {str(x.get("code") or ""): x for x in R.rules.list()}
    except Exception:
        rules = {}
    out = {"customer_rule": [], "platform_builtin": [], "not_applicable": [],
           "customer_not_applicable": [], "customer_insufficient": [], "customer_unexecuted": []}
    # 文档类型映射：file_id 可能是文件名
    dtype = {}
    try:
        from . import project as _pj
        for d in _pj.documents(case_id):
            dtype[str(d.get("filename") or "")] = str(d.get("doc_type") or "").lower()
    except Exception:
        dtype = {}
    for b in bs:
        for row in detail(b, limit=5000):
            if str(row.get("state") or "") != "unknown":
                continue
            pid = str(row.get("point_id") or "")
            reason = str(row.get("reason") or "")
            rule = rules.get(pid)
            applicable = None
            try:
                if rule:
                    v = R.rules.latest_version(rule["id"]) or {}
                    slots = __import__("json").loads(v.get("slots_json") or "{}")
                    applicable = slots.get("applicable_types") or slots.get("types") or None
            except Exception:
                applicable = None
            _fit = True
            if applicable:
                fn = str(row.get("file_id") or "").lower(); dt = dtype.get(row.get("file_id") or "", "")
                _fit = any(str(t).lower() in (dt, fn) or str(t).lower() in fn for t in applicable)
            if "不适用" in reason or "不在适用" in reason or (applicable and not _fit):
                out["not_applicable"].append(pid)
                if rule:
                    out["customer_not_applicable"].append(pid)
            elif rule and str(rule.get("source") or "") not in ("内置规则", "library", ""):
                out["customer_rule"].append(pid)
                if "证据" in reason or "insufficient" in reason.lower():
                    out["customer_insufficient"].append(pid)
                else:
                    out["customer_unexecuted"].append(pid)
            else:
                out["platform_builtin"].append(pid)
    return out
