# -*- coding: utf-8 -*-
"""项目审核的 7 节点 DAG 组件（默认路径）。

用法：project.audit 默认调用；RULEPROOF_AUDIT_DAG=0 回退旧 orchestrator。
每个节点调用现有单次函数，不复制业务逻辑。

接线纪律（可审计）：
- 每个节点在同一轮审核里最多真实执行一次：parse 结果传给 fact 复用，不重复解析；
  规则生成只跑 agent-rulegen，冲突分析只跑 agent-conflict（不再由 policy_to_rules 重复跑）。
- 没有输入的节点显式 skipped 并写原因（rulegen 无新制度、fp 在人工复核后触发）；
  ruleminer 显式 delegated 给审核落库后的真实调用，不在 DAG 内制造第二套候选。
- 每个执行节点输出 agent / run_id / agent_mode / degraded，节点轨迹状态按真实情况
  标记 ok / skipped / delegated / failed，供 audit_run.trace_json 审计。
"""
from __future__ import annotations

from . import agent_dag, orchestrator, review

NODE_SPECS = [
    {"id": "parse", "name": "文档解析", "agent": "agent-parse", "depends_on": []},
    {"id": "fact", "name": "事实抽取", "agent": "agent-fact", "depends_on": ["parse"]},
    {"id": "rulegen", "name": "规则生成", "agent": "agent-rulegen", "depends_on": ["fact"]},
    {"id": "conflict", "name": "冲突分析", "agent": "agent-conflict", "depends_on": ["rulegen"]},
    {"id": "judge", "name": "点位判定", "agent": "agent-judge", "depends_on": ["conflict"]},
    {"id": "fp", "name": "误报归因", "agent": "agent-fp", "depends_on": ["judge"]},
    {"id": "ruleminer", "name": "规则挖掘", "agent": "agent-ruleminer", "depends_on": ["judge"]},
]


def _nodes() -> list:
    return [dict(n) for n in NODE_SPECS]


def _pick_run(seg: list, stage: str) -> dict:
    """从 orchestrator 轨迹片段里取某阶段真实智能体调用证据。"""
    run_ids, modes, degraded, count = [], "", False, 0
    for e in seg or []:
        if str(e.get("stage") or "") != stage:
            continue
        det = e.get("detail") or {}
        rid = str(det.get("run_id") or "")
        if rid and rid not in run_ids:
            run_ids.append(rid)
        modes = modes or str(det.get("agent_mode") or "")
        degraded = degraded or bool(det.get("degraded"))
        try:
            count += int(det.get("count") or 0)
        except Exception:
            pass
    return {"run_id": run_ids[-1] if run_ids else "", "run_ids": run_ids,
            "agent_mode": modes, "degraded": degraded, "count": count}


def run_components(case_id: str, docs: list, ai_assist: bool = True, doc_type: str = "",
                   policy_text: str = "", claimed_codes=None) -> dict:
    nodes = _nodes()
    findings, trace = [], []
    # project.audit 在 manifest.freeze 里会重置线程上下文，这里恢复 case 归因，
    # 让 agent_run 带上 case_id（judge 等 payload 未显式带 case_id 的调用依赖它）。
    try:
        from . import ctx as _ctx_dag
        _ctx_dag.set_case(case_id)
    except Exception:
        pass

    def h_parse(node, ctx):
        documents = []
        for d in docs or []:
            p = d.get("path") or ""
            r = orchestrator.parse_document(p, case_id=case_id, ai_assist=bool(ai_assist))
            documents.append({
                "path": p, "ok": bool(r.get("ok")),
                "unstructured": bool(r.get("unstructured")),
                "chars": len(str(r.get("text") or "")),
                "text": str(r.get("text") or ""),
                "run_id": str(r.get("run_id") or ""),
                "agent_mode": str(r.get("agent_mode") or ""),
                "degraded": bool(r.get("degraded")),
                "degraded_reason": str(r.get("degraded_reason") or ""),
                "skipped": bool(r.get("skipped")),
                "reason": str(r.get("reason") or ""),
            })
        if not documents:
            return {"skipped": True, "agent": "agent-parse",
                    "reason": "项目内没有可解析文件"}
        real = [x for x in documents if x.get("run_id")]
        # L108：解析节点的 skipped/降级原因必须进入 DAG 轨迹，不能只留一个 ok；
        # 扫描件无 OCR 时 agent-parse 返回 degraded=True，这里原样上卷，不伪造成功。
        _degraded_docs = [x for x in documents if x.get("degraded")]
        _skipped_reasons = [
            {"path": str(x.get("path") or "").rsplit("/", 1)[-1],
             "reason": str(x.get("reason") or "")[:300]}
            for x in documents if x.get("skipped") and str(x.get("reason") or "")][:10]
        if not real and all(x.get("skipped") for x in documents):
            return {"documents": documents, "skipped": True, "agent": "agent-parse",
                    "reason": "全部为结构化表格，无需 agent-parse",
                    "skipped_reasons": _skipped_reasons,
                    "degraded": bool(_degraded_docs),
                    "run_ids": [], "run_id": ""}
        return {"documents": documents, "agent": "agent-parse",
                "run_ids": [x["run_id"] for x in real],
                "run_id": real[-1]["run_id"] if real else "",
                "agent_mode": real[-1]["agent_mode"] if real else "",
                "degraded": bool(_degraded_docs),
                "degraded_documents": [
                    {"path": str(x.get("path") or "").rsplit("/", 1)[-1],
                     "reason": str(x.get("degraded_reason") or x.get("reason") or "")[:300]}
                    for x in _degraded_docs][:10],
                "skipped_reasons": _skipped_reasons,
                "parsed": len(real), "total": len(documents)}

    def h_fact(node, ctx):
        documents = ctx.get("documents") or []
        if not documents:
            return {"skipped": True, "agent": "agent-fact",
                    "reason": "解析节点未产出文本，事实抽取无输入"}
        out = []
        for d in documents:
            p = d.get("path") or ""
            # 只有非结构化文档走抽取；结构化表格由规则引擎直接读取
            if not d.get("unstructured"):
                orchestrator._add("extract", "skipped",
                                  f"{str(p).rsplit('/', 1)[-1]} 为结构化表格，字段由规则引擎直接读取")
                continue
            # agent-fact 契约要求 text；parse 节点已解析，直接复用，不再重复解析
            text = str(d.get("text") or "")
            if not text.strip():
                orchestrator._add("extract", "skipped",
                                  f"无文本可抽取：{str(p).rsplit('/', 1)[-1]}")
                continue
            out.append(orchestrator.extract_facts(p, text, case_id=case_id))
        real = [x for x in out if x.get("run_id")]
        if not real:
            return {"facts": out, "skipped": True, "agent": "agent-fact",
                    "reason": "没有需要抽取的非结构化文本",
                    "run_ids": [], "run_id": ""}
        return {"facts": out, "agent": "agent-fact",
                "run_ids": [x["run_id"] for x in real],
                "run_id": real[-1]["run_id"],
                "agent_mode": real[-1].get("agent_mode") or "",
                "degraded": any(x.get("degraded") for x in real),
                "fact_count": sum(len((x.get("result") or {}).get("facts") or [])
                                  for x in real)}

    def h_rulegen(node, ctx):
        if not (policy_text or "").strip():
            # 无新制度/标准：显式跳过，不伪造规则生成
            orchestrator._add("rulegen", "skipped", "本次未提供新制度/标准文本")
            return {"skipped": True, "agent": "agent-rulegen",
                    "reason": "本次未提供新制度/标准文本"}
        out = orchestrator.policy_to_rules(policy_text, save=True, case_id=case_id,
                                           with_conflict=False)
        rg = (out or {}).get("rulegen") or {}
        if rg.get("error"):
            return {"agent": "agent-rulegen", "result": out, "run_id": rg.get("run_id") or "",
                    "error": str(rg.get("error"))[:200]}
        return {"agent": "agent-rulegen", "result": out,
                "run_id": str(rg.get("run_id") or ""),
                "agent_mode": str(rg.get("agent_mode") or ""),
                "degraded": bool(rg.get("degraded")),
                "degraded_reason": str(rg.get("degraded_reason") or ""),
                "rule_id": str(rg.get("rule_id") or "")}

    def h_conflict(node, ctx):
        # 有 policy_text 时本次生成了候选草稿：冲突分析需包含草稿（与旧链路同口径），
        # 仍只调用 agent-conflict 一次，不重复。
        r = orchestrator.audit_rule_health(
            case_id, include_drafts=bool((policy_text or "").strip()))
        return {"agent": "agent-conflict", "result": r,
                "run_id": str(r.get("run_id") or ""),
                "agent_mode": str(r.get("agent_mode") or ""),
                "degraded": bool(r.get("degraded")),
                "include_drafts": bool(r.get("include_drafts")),
                "conflicts": int(r.get("conflicts") or 0)}

    def h_judge(node, ctx):
        _mark = orchestrator.trace_mark()
        for d in docs or []:
            p = d.get("path") or ""
            findings.extend(review.judge_findings(
                p, "", "", "", exclude_codes=claimed_codes, include_decision_tables=False))
        _judge = _pick_run(orchestrator.trace_since(_mark), "judge")
        out = {"agent": "agent-judge", "findings": len(findings),
               "run_id": _judge["run_id"], "run_ids": _judge["run_ids"],
               "agent_mode": _judge["agent_mode"], "degraded": _judge["degraded"],
               "judged": _judge["count"]}
        if not _judge["run_id"]:
            # 没有点位时 agent-judge 不执行，显式记录原因
            out.update({"skipped": True, "reason": "无待判定点位"})
        return out

    def h_fp(node, ctx):
        # 误报归因是复核后触发（orchestrator.post_decision），审核阶段不执行
        orchestrator._add("feedback", "skipped", "反馈归因在人工复核后触发")
        return {"skipped": True, "agent": "agent-fp",
                "reason": "反馈归因在人工复核（post_decision）后触发，审核阶段不执行",
                "trigger": "post_decision"}

    def h_mine(node, ctx):
        # 规则挖掘不能在这里重复跑：project.audit 在 findings 落库后调用
        # agent-ruleminer，能拿到真实 case_id 和复核结果。此处显式委托，
        # 保留 7 节点 DAG 结构，但不制造第二套候选。
        orchestrator._add("ruleminer", "delegated",
                          "候选由审核完成后的 agent-ruleminer 执行，避免重复挖掘")
        return {"delegated": True, "agent": "agent-ruleminer",
                "reason": "候选由审核落库后的 agent-ruleminer 执行，避免 DAG 内重复挖掘",
                "delegate_stage": "post_audit"}

    handlers = {"parse": h_parse, "fact": h_fact, "rulegen": h_rulegen,
                "conflict": h_conflict, "judge": h_judge, "fp": h_fp,
                "ruleminer": h_mine}
    res = agent_dag.run(nodes, handlers, {"case_id": case_id}, stop_on_error=False)
    dag_trace = res.get("trace") or []
    outputs = res.get("outputs") or {}
    # 把节点的真实状态（skipped/delegated/failed）落到轨迹上，别让“跳过”伪装成 ok
    for t in dag_trace:
        o = outputs.get(t.get("id")) or {}
        if o.get("skipped"):
            t["status"] = "skipped"
            t["reason"] = str(o.get("reason") or "")
        elif o.get("delegated"):
            t["status"] = "delegated"
            t["reason"] = str(o.get("reason") or "")
        elif o.get("error"):
            t["status"] = "failed"
            t["reason"] = str(o.get("error") or "")
    expected = [n["id"] for n in nodes]
    got = [str(t.get("id") or "") for t in dag_trace]
    coverage = {
        "total": len(expected),
        "covered": len([x for x in got if x in expected]),
        "missing": [x for x in expected if x not in got],
        "duplicates": sorted({x for x in got if got.count(x) > 1}),
        "order_ok": got == expected,
        "statuses": {str(t.get("id")): str(t.get("status")) for t in dag_trace},
    }
    orchestrator._add("dag", "executed" if res.get("ok") else "failed",
                      "" if res.get("ok") else f"failed={res.get('failed')}",
                      {"coverage": coverage})
    return {"findings": findings, "trace": dag_trace, "failed": res.get("failed"),
            "ok": res.get("ok"), "coverage": coverage}
