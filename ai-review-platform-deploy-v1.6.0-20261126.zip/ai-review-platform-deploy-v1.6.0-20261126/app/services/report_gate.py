"""正式报告放行门禁（P0-5）。

放行必须同时满足：
1. 范围内 unknown = 0（五态里的“未执行/失败”不得带病出报告）
2. 强制复核项清零（所有待复核 finding 已决策）
3. 高严重度（critical）已全部签发
4. 解析缺口已接受（partial/failed 必须有确认）
5. V3.2 §15 双轨/人工四项门禁全部为 0（T-50，W-14 产品接线）：
   visible_unreviewed = 0
   unresolved_critical_conflict = 0
   incomplete_applicable_requirement = 0
   suppressed_risk_decision_missing = 0
   计数与阻断同源（human_review.product_gate；CLI/HTTP 读同一函数）。
6. L77（build49 P0，90 号 §二-3）：最近一次 run 的 manifest.executed 下沉审计写失败
   （audit_run.trace_json.audit_failed=true）→ 禁止签发正式报告，错误码
   audit_write_failed；回退开关 RULEPROOF_AUDIT_HARD_FAIL=0（默认 1）回到旧“只告警”。
   默认（无 audit_failed）输出与接入前逐字节一致。
"""
import hashlib
import json
import logging
import os
import time

from .. import db
from .. import repositories as R
from . import pstates
# M1（T-82）：状态归一的唯一事实源（na 家族不得被折成 unknown/阻断）
from . import audit_ledger as _audit_ledger

# ---------------------------------------------------------------------------
# P0-4 / P1-8（2026-11-21 外部交叉复测 A3/A5）：签发边界 fail-closed。
#
# 1) 复核门禁（human_review.gate_check / product_gate）异常时，此前只记 warning 后
#    继续放行 → 被抑制的真问题、未完成的适用要求可不经人工裁决签发。现在追加
#    阻断 reason，code=human_review_gate_unavailable（fail-closed）。
# 2) 点位台账写失败（pstates.record 抛 LedgerWriteError，run 标记 ledger_incomplete）
#    → 覆盖度分母残缺，追加阻断 reason，code=ledger_incomplete。
#
# 降级放行必须显式开关：RULEPROOF_REPORT_GATE_STRICT=0（默认 "1"=严，可回滚）。
# ---------------------------------------------------------------------------
GATE_UNAVAILABLE_CODE = "human_review_gate_unavailable"
LEDGER_INCOMPLETE_CODE = "ledger_incomplete"
# L77（build49 P0，90 号 §二-3）：manifest.executed 下沉审计写失败 → 禁止签发正式报告。
# project.audit 已把 audit_failed 标记落 audit_run.trace_json；本门禁只读该标记并阻断
# （HTTP 409 / CLI 非 0 同源），错误码走 audit_write_failed。回退：RULEPROOF_AUDIT_HARD_FAIL=0。
AUDIT_WRITE_FAILED_CODE = "audit_write_failed"
# L87（2026-11-24，外部复验 §7 P0-3）：审计状态跨写入点一致性——失败/半状态禁止签发。
# 与 project.audit / 语义重审 / report.generate 读**同一事实源**（audit_ledger.audit_state：
# case.status + 当前/最新 run 标记 + 唯一恢复事件）。回退：RULEPROOF_AUDIT_STATE_CONSISTENCY=0
# （仅回退本门禁，L77 标记门禁保持不变）。
AUDIT_STATE_FAILED_CODE = "audit_state_failed"
AUDIT_STATE_INCONSISTENT_CODE = "audit_state_inconsistent"
_GATE_STRICT_ENV = "RULEPROOF_REPORT_GATE_STRICT"


def gate_strict() -> bool:
    """签发边界是否 fail-closed（默认 True；显式 =0 才降级放行）。"""
    return str(os.environ.get(_GATE_STRICT_ENV, "1")).strip() != "0"


def _append_code_reason(reasons: list, code: str, detail: str) -> str:
    """追加带 code 的阻断 reason（同 code 去重，返回最终文本）。"""
    text = f"[{code}] {detail}"
    if not any(code in str(x) for x in reasons):
        reasons.append(text)
    return text


def _unavailable_detail(exc, what: str) -> str:
    """统一的可读失败原因：含异常类型（不外泄堆栈/密钥）。"""
    _e = f"{type(exc).__name__}: {str(exc)[:200]}" if exc is not None else "未知异常"
    if gate_strict():
        return (f"{what}校验失败（fail-closed，禁止签发正式报告）：{_e}；"
                f"请修复数据后重试（降级放行需显式设置 {_GATE_STRICT_ENV}=0）")
    return (f"{what}校验失败，已按 {_GATE_STRICT_ENV}=0 显式降级放行：{_e}；"
            "该次签发未经完整门禁校验，必须人工复核")


def _latest_batches(case_id: str) -> list:
    rows = R.audit_runs.list("case_id=?", (case_id,))
    out = []
    for r in reversed(rows):
        raw = r.get("batch_ids") or ""
        if isinstance(raw, str) and raw.strip():
            try:
                val = json.loads(raw)
                out = val if isinstance(val, list) else [str(val)]
            except Exception:
                out = [x.strip() for x in raw.split(",") if x.strip()]
        elif isinstance(raw, list):
            out = raw
        if out:
            break
    return [str(x) for x in out]


# ---------------------------------------------------------------------------
# V08 报告例外授权：对象级 unknown 例外（result_id + result_hash + run_id）
#
# 评审反例（V08）：旧“接受 unknown”是一次性批量审计记录（point_ids 列表），缺对象/
# hash/run 绑定；一次接受即可覆盖当前全部 unknown，且对 execution_failed/关键项没有
# 双人约束，形成报告门禁绕过。现行契约：
#   1) 例外只能按对象授权：result_id + result_hash + run_id 三项必须同时落审计；
#      point_ids 形式的旧批量记录一律不作为放行依据（禁止批量豁免）；
#   2) 关键项（severity=critical 的规则/关键规则）必须两名不同操作人分别授权；
#   3) 不可豁免：execution_failed（含 blocked/failed）与完整性错误（结果缺失/执行数 0/
#      冻结清单为空）不得以例外放行；
#   4) 失效：run 变化、结果 hash 变化（重判/补证/结果更新）、超有效期（默认 7 天）→
#      旧授权自动失效；
#   5) report_gate.check 与 report.check_gate 仍共用 collect_unknown（F-05 同源不变）。
#
# 写作用域说明（T-28）：HTTP/CLI 的对象级入口接线不在本任务写作用域（不改 server/cli）；
# 本模块先提供 accept_unknown_object() 服务 API。旧批量入口（HTTP/CLI 写 point_ids）
# 的审计记录会被识别为 legacy_batch 并拒绝放行——这是 V08 要求的“禁止批量豁免”行为。
# ---------------------------------------------------------------------------

_UNKNOWN_REGISTRY = ("未知", "无法判断", "未执行", "执行失败", "证据不足")

# 例外不可豁免类别：执行失败 + 完整性错误（结果缺失/清单为空/执行数为 0）
_NON_WAIVABLE_STATES = frozenset({"execution_failed", "blocked", "failed", "missing",
                                  "executor_error", "执行失败"})
_NON_WAIVABLE_EXECUTIONS = frozenset({"failed", "blocked", "execution_failed"})
_ACCEPT_DEFAULT_TTL_DAYS = 7
_ACCEPT_ACTORS = ("reviewer", "admin", "super_admin")


def unknown_key_candidates(item: dict) -> set:
    """一条 unknown 明细可被外部展示/兼容匹配的候选键（不含授权语义）。

    授权语义只看 result_id+result_hash+run_id（见 unknown_object_ref）；本函数只为
    报告/旧接口提供可读键，不能单独作为放行依据。
    """
    cands = set()
    for k in ("point_id", "rule", "rule_code", "result_id", "id"):
        v = str((item or {}).get(k) or "").strip()
        if v:
            cands.add(v)
    return cands


# ---------------- 对象级绑定：unknown 明细 → (result_id, hash, run_id) ----------------

def _case_run_id(case_id: str) -> str:
    try:
        return str((R.cases.get(case_id) or {}).get("last_run_id") or "")
    except Exception:
        return ""


def _epoch(ts) -> float:
    try:
        return time.mktime(time.strptime(str(ts or ""), "%Y-%m-%d %H:%M:%S"))
    except Exception:
        return 0.0


def _result_content_hash(row: dict) -> str:
    """manifest_result 对象级内容 hash（D1–D5 + 结论 + 执行 + 复核状态）。

    任一项变化（重判/补证/结果更新/复核决策）都会改变 hash，使旧例外授权失效。
    """
    payload = {k: str((row or {}).get(k) or "") for k in
               ("d1_json", "d2_json", "d3_json", "d4_json", "d5_json",
                "conclusion", "execution", "review_status")}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False,
                                     sort_keys=True).encode("utf-8")).hexdigest()[:32]


def point_state_hash(row: dict) -> str:
    """平台 point_state 对象级内容 hash（点位状态/理由/文件/批次）。"""
    payload = {k: str((row or {}).get(k) or "") for k in
               ("id", "batch_id", "point_id", "state", "reason", "quote", "file_id")}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False,
                                     sort_keys=True).encode("utf-8")).hexdigest()[:32]


def _manifest_result_row(result_id: str) -> dict:
    c = db.connect()
    try:
        row = c.execute("SELECT * FROM manifest_result WHERE id=?",
                        (str(result_id or ""),)).fetchone()
        return dict(row) if row else {}
    finally:
        c.close()


def _manifest_case_id(manifest_id: str) -> str:
    c = db.connect()
    try:
        row = c.execute("SELECT case_id FROM audit_manifest WHERE id=?",
                        (str(manifest_id or ""),)).fetchone()
        return str((row["case_id"] if row else "") or "")
    finally:
        c.close()


def report_issuance_fact(case_id: str) -> dict:
    """L93（2026-11-24）：最近一条报告的签发事实（只读，advisory，不参与阻断）。

    L90 GP03：报告“有流程无签批单据”。本函数把 report.status/signed_by/signed_at/
    content_hash 作为**事实**暴露给门禁调用方（HTTP/CLI/状态页同源），但不加入
    reasons（不阻断），阻断口径仍只由既有硬规则决定。

    兼容性：0 报告行时返回 available=False；``check`` 只在 available=True 时挂载
    ``report_issuance``/``stats.report_issuance``，保证无报告行的输出与接入前
    逐字节一致（L72 E4 契约）。0 行事实由 docmodel_health_report 显式报告。
    """
    try:
        rows = R.reports.list("case_id=?", (case_id,), order="exported_at DESC")
    except Exception as exc:  # noqa: BLE001 —— 事实读取失败不阻断门禁，显式标注
        return {"available": False, "report_rows": 0, "signed": False,
                "advisory": True, "error": f"{type(exc).__name__}: {str(exc)[:120]}"}
    if not rows:
        return {"available": False, "report_rows": 0, "signed": False,
                "advisory": True, "note": "0 行报告（签发事实无数据级样本）"}
    row = dict(rows[0])
    status = str(row.get("status") or "")
    try:
        from . import state_machines as _sm
        status = _sm.normalize("report", status) or status
    except Exception:  # noqa: BLE001 —— 状态机不可用时用原值
        pass
    signed_by = str(row.get("signed_by") or "")
    signed_at = str(row.get("signed_at") or "")
    stored_hash = str(row.get("content_hash") or "")
    hash_verified = None
    if stored_hash:
        hash_verified = _verify_report_content_hash(row)
    return {"available": True, "report_rows": len(rows),
            "report_id": row.get("id") or "",
            "version": row.get("version") or "",
            "status": status,
            "signed": bool(signed_by and signed_at),
            "signed_by": signed_by, "signed_at": signed_at,
            "content_hash": stored_hash,
            "content_hash_verified": hash_verified,
            "advisory": True,
            "note": "签发事实仅 advisory，不参与门禁阻断"}


def _verify_report_content_hash(row: dict):
    """重算报告生成时 content_hash（与 report._report_content_hash 同口径）。"""
    import hashlib
    stored = str(row.get("content_hash") or "")
    if not stored:
        return None
    try:
        summary = json.loads(row.get("summary_json") or "{}")
    except Exception:  # noqa: BLE001
        return False
    payload = json.dumps({"case_id": str(row.get("case_id") or ""),
                          "version": str(row.get("version") or ""),
                          "summary": summary or {},
                          "disclaimer": str(row.get("disclaimer") or "")},
                         ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    expect = "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return stored == expect


def _run_for_manifest(manifest_id: str) -> str:
    c = db.connect()
    try:
        row = c.execute("SELECT id FROM audit_run WHERE manifest_id=? "
                        "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                        (str(manifest_id or ""),)).fetchone()
        return str((row["id"] if row else "") or "")
    finally:
        c.close()


def _rule_severity(code: str) -> str:
    try:
        from ..severity import normalize as _sev_norm
        for r in R.rules.list() or []:
            if str((r or {}).get("code") or "") == str(code or ""):
                return str(_sev_norm(r.get("severity"), r.get("rclass")) or "")
    except Exception:
        pass
    return ""


def _non_waivable_result(row: dict, item_state: str = "") -> tuple:
    """返回 (不可豁免?, 原因)。execution_failed/blocked/failed/missing 不得例外放行。"""
    st = _audit_ledger.normalize_state(item_state) if str(item_state or "") else ""
    if st in _NON_WAIVABLE_STATES:
        return True, "结果缺失/执行失败不可通过例外豁免"
    exec_state = str((row or {}).get("execution") or "")
    if exec_state in _NON_WAIVABLE_EXECUTIONS:
        return True, "执行失败（execution_failed）不可通过例外豁免"
    try:
        d4 = json.loads((row or {}).get("d4_json") or "{}")
    except Exception:
        d4 = {}
    try:
        d5 = json.loads((row or {}).get("d5_json") or "{}")
    except Exception:
        d5 = {}
    if _audit_ledger.normalize_state((d4 or {}).get("status")) in _NON_WAIVABLE_STATES or \
            _audit_ledger.normalize_state((d5 or {}).get("status")) in _NON_WAIVABLE_STATES:
        return True, "执行失败（d4/d5 blocked/failed）不可通过例外豁免"
    for sub in (d4.get("subs") or []):
        if _audit_ledger.normalize_state((sub or {}).get("status")) in ("blocked", "failed"):
            return True, "子要求执行失败（execution_failed）不可通过例外豁免"
    return False, ""


def _d5_status(row: dict) -> str:
    try:
        raw = str((json.loads((row or {}).get("d5_json") or "{}") or {}).get("status") or "")
        return _audit_ledger.normalize_state(raw) if raw else ""
    except Exception:
        return ""


def unknown_object_ref(item: dict, case_id: str = "", run_id: str = "") -> dict:
    """一条 unknown/missing 明细 → 对象级绑定（V08 授权/失效判断的唯一依据）。"""
    item = item or {}
    run_id = str(run_id or "") or _case_run_id(case_id)
    source = str(item.get("source") or "")
    base = {"source": source, "rule_code": str(item.get("rule_code") or ""),
            "object_id": str(item.get("object_id") or ""),
            "sub_id": str(item.get("sub_id") or ""),
            "state": str(item.get("state") or ""),
            "keys": sorted(unknown_key_candidates(item)),
            "case_id": case_id, "run_id": run_id}
    if source == "manifest":
        rid = str(item.get("result_id") or "")
        if not rid:
            return {**base, "kind": "manifest_missing", "result_id": "",
                    "result_hash": "", "waivable": False, "key_item": False,
                    "required_actors": 1,
                    "non_waivable_reason": "结果缺失（完整性错误）不可通过例外豁免"}
        row = _manifest_result_row(rid)
        if not row:
            return {**base, "kind": "manifest_result", "result_id": rid,
                    "result_hash": "", "waivable": False, "key_item": False,
                    "required_actors": 1,
                    "non_waivable_reason": "结果行不存在/已变更，需重审后再授权"}
        mid = str(row.get("manifest_id") or "")
        bind_run = _run_for_manifest(mid) or str(item.get("run_id") or "") or run_id
        non_waivable, why = _non_waivable_result(row, base["state"])
        key_item = _rule_severity(str(row.get("rule_code") or "")) == "critical"
        return {**base, "kind": "manifest_result", "result_id": rid,
                "result_hash": _result_content_hash(row), "run_id": bind_run,
                "object_id": str(row.get("object_id") or base["object_id"]),
                "rule_code": str(row.get("rule_code") or base["rule_code"]),
                "manifest_id": mid, "waivable": not non_waivable,
                "key_item": key_item, "required_actors": 2 if key_item else 1,
                "non_waivable_reason": why}
    # 平台 point_state：result_id = point_state 行 id（对象级），hash 覆盖点位状态/理由。
    psid = str(item.get("point_state_id") or item.get("id") or "")
    psrow = {}
    if psid:
        c = db.connect()
        try:
            r = c.execute("SELECT * FROM point_state WHERE id=?", (psid,)).fetchone()
            psrow = dict(r) if r else {}
        finally:
            c.close()
    if not psrow:
        return {**base, "kind": "platform_point", "result_id": psid,
                "result_hash": "", "waivable": False, "key_item": False,
                "required_actors": 1,
                "non_waivable_reason": "平台点位结果不存在/已变更，需重审后再授权"}
    st = str(psrow.get("state") or "")
    why = str(psrow.get("reason") or "")
    non_waivable = _platform_non_waivable(st, why)
    return {**base, "kind": "platform_point",
            "result_id": str(psrow.get("id") or psid),
            "result_hash": point_state_hash(psrow),
            "run_id": run_id, "point_id": str(psrow.get("point_id") or ""),
            "batch_id": str(psrow.get("batch_id") or ""),
            "state": st or base["state"],
            "waivable": not non_waivable, "key_item": False, "required_actors": 1,
            "non_waivable_reason": ("执行失败（execution_failed）不可通过例外豁免"
                                    if non_waivable else "")}


def _platform_non_waivable(state, reason) -> bool:
    """平台点位五态没有 execution_failed：只有显式执行失败语义才归不可豁免类别。

    not_judged/模型不可用等 unknown 属于可例外授权范围（报告中必须保留计数）；
    “执行失败/执行受阻/executor_error”才属于 V08 的 execution_failed 禁止类别。
    """
    st = str(state or "")
    why = str(reason or "")
    return (st in ("execution_failed", "blocked", "failed")
            or any(x in why for x in ("执行失败", "执行受阻", "execution_failed",
                                      "executor_error")))


def collect_platform_unknown(case_id: str) -> list:
    """当前 run 的平台点位未知行（unknown / insufficient），带对象级绑定所需字段。"""
    rows, seen = [], set()
    for batch in _latest_batches(case_id):
        try:
            _rows = R.point_states.list("batch_id=?", (batch,),
                                        order="point_id", limit=5000)
        except Exception:
            _rows = []
        for row in _rows or []:
            # M1：状态归一后再判定，na 家族（not_applicable/skipped…）不会落进 unknown；
            # 空状态保持原口径跳过（不因归一凭空制造 unknown）
            raw_st = str(row.get("state") or "").strip()
            if not raw_st:
                continue
            st = _audit_ledger.normalize_state(raw_st)
            pid = str(row.get("point_id") or "")
            if st not in ("unknown", "insufficient") or not pid or pid in seen:
                continue
            seen.add(pid)
            rows.append({"source": "platform_point", "point_id": pid, "rule_code": pid,
                         "state": st, "reason": str(row.get("reason") or ""),
                         "file_id": str(row.get("file_id") or ""),
                         "point_state_id": str(row.get("id") or ""),
                         "batch_id": str(row.get("batch_id") or batch),
                         "run_id": _case_run_id(case_id)})
    return rows


def collect_manifest_unknown(case_id: str, cats: dict | None = None) -> list:
    """当前 active manifest 的 unknown 明细（与报告四类口径同源，source=manifest）。"""
    if cats is None:
        try:
            from . import report as _report
            cats = _report.report_categories(case_id)
        except Exception:
            cats = {}
    out, seen = [], set()
    for it in (((cats or {}).get("unknown") or {}).get("items") or []):
        it = it or {}
        if str(it.get("source") or "") != "manifest":
            continue
        key = (str(it.get("result_id") or ""), str(it.get("rule_code") or ""),
               str(it.get("sub_id") or ""), str(it.get("object_id") or ""))
        if key in seen:
            continue
        seen.add(key)
        out.append(it)
    return out


# ---------------- 授权记录解析/校验 ----------------

def _accept_records(case_id: str) -> list:
    """读取 unknown.accepted 审计记录（一次读取，统一分类）。"""
    try:
        rows = R.audit_logs.list("action=? AND object=?", ("unknown.accepted", case_id),
                                 order="created_at DESC", limit=500)
    except Exception:
        try:
            rows = R.audit_logs.list("object=?", (case_id,),
                                     order="created_at DESC", limit=500)
        except Exception:
            rows = []
    out = []
    for r in rows or []:
        try:
            meta = json.loads(r.get("after_json") or r.get("after") or "{}")
        except Exception:
            meta = {}
        if not isinstance(meta, dict):
            meta = {}
        out.append({"record": r, "meta": meta,
                    "actor": str(r.get("actor") or ""),
                    "created_at": str(r.get("created_at") or "")})
    return out


def _classify_accept_record(rec: dict) -> str:
    """object = 合规对象级授权；batch/legacy_batch = 禁止的批量；invalid = 缺字段。"""
    meta = (rec or {}).get("meta") or {}
    for k in ("result_ids", "object_ids", "batch_ids"):
        v = meta.get(k)
        if isinstance(v, (list, tuple, set)) and len(v) > 1:
            return "batch"
    rid = meta.get("result_id")
    if isinstance(rid, (list, tuple, set)):
        return "batch"
    if str(meta.get("batch") or "").strip().lower() in ("1", "true", "yes", "on"):
        return "batch"
    if not str(rid or "").strip():
        if meta.get("point_ids") or meta.get("all") or meta.get("scope") == "all":
            return "legacy_batch"
        return "invalid"
    if "," in str(rid) or "|" in str(rid) or len(str(rid)) > 200:
        # 一个 result_id 字段里塞多个对象 = 批量，拒绝
        return "batch"
    if not str(meta.get("result_hash") or "").strip():
        return "invalid"
    if not str(meta.get("run_id") or "").strip():
        return "invalid"
    return "object"


def validate_unknown_accepts(case_id: str, items: list) -> dict:
    """对象级例外校验：只有 result_id+hash+run_id 匹配且授权人数足够的对象才放行。"""
    run_id = _case_run_id(case_id)
    object_recs, stats = [], {"rejected_batch": 0, "rejected_invalid": 0}
    for rec in _accept_records(case_id):
        cls = _classify_accept_record(rec)
        if cls == "object":
            object_recs.append(rec)
        elif cls in ("batch", "legacy_batch"):
            stats["rejected_batch"] += 1
        else:
            stats["rejected_invalid"] += 1
    out = {"run_id": run_id, "accepted_keys": [], "accepted_bindings": 0,
           "accepted": False, "actor": "", "reason": "",
           "rejected_batch": stats["rejected_batch"],
           "rejected_invalid": stats["rejected_invalid"],
           "stale_run": 0, "stale_hash": 0, "expired": 0, "non_waivable": 0,
           "pending_dual": [], "details": [], "records": len(object_recs)}
    accepted_keys = set()
    _newest = None
    for item in items or []:
        b = unknown_object_ref(item, case_id=case_id, run_id=run_id)
        hits = []
        for rec in object_recs:
            m = rec.get("meta") or {}
            if str(m.get("result_id") or "") != str(b.get("result_id") or ""):
                continue
            if str(m.get("run_id") or "") != str(b.get("run_id") or run_id):
                out["stale_run"] += 1
                continue
            if str(m.get("result_hash") or "") != str(b.get("result_hash") or ""):
                out["stale_hash"] += 1
                continue
            expires_at = str(m.get("expires_at") or "")
            if expires_at and _epoch(expires_at) and _epoch(expires_at) < time.time():
                out["expired"] += 1
                continue
            hits.append(rec)
        detail = {"kind": b.get("kind"), "result_id": b.get("result_id"),
                  "result_hash": b.get("result_hash"), "run_id": b.get("run_id"),
                  "rule_code": b.get("rule_code"), "object_id": b.get("object_id"),
                  "sub_id": b.get("sub_id"), "state": b.get("state"),
                  "key_item": bool(b.get("key_item")),
                  "required_actors": int(b.get("required_actors") or 1),
                  "waivable": bool(b.get("waivable")),
                  "keys": list(b.get("keys") or []),
                  "non_waivable_reason": b.get("non_waivable_reason") or "",
                  "accepted": False, "actors": []}
        if not b.get("waivable"):
            out["non_waivable"] += 1
            detail["reason"] = b.get("non_waivable_reason") or "不可豁免类别"
            out["details"].append(detail)
            continue
        actors = sorted({str(r.get("actor") or "") for r in hits if r.get("actor")})
        detail["actors"] = actors
        if len(actors) >= int(b.get("required_actors") or 1):
            accepted_keys |= set(b.get("keys") or [])
            out["accepted_bindings"] += 1
            detail["accepted"] = True
            if _newest is None:
                _newest = hits[0]
        else:
            detail["reason"] = ("关键项需要两名不同操作人授权（当前 %d 人）"
                                % len(actors)) if b.get("key_item") else "尚未授权"
            if hits:
                out["pending_dual"].append(
                    {"result_id": b.get("result_id"), "kind": b.get("kind"),
                     "rule_code": b.get("rule_code"), "object_id": b.get("object_id"),
                     "sub_id": b.get("sub_id"), "key_item": bool(b.get("key_item")),
                     "actors": actors,
                     "required_actors": int(b.get("required_actors") or 1)})
        out["details"].append(detail)
    out["accepted_keys"] = sorted(accepted_keys)
    out["accepted"] = bool(out["accepted_bindings"])
    if _newest:
        meta = _newest.get("meta") or {}
        out["actor"] = str(_newest.get("actor") or "")
        out["reason"] = str(meta.get("reason") or "")
    return out


def latest_unknown_accept(case_id: str, items: list | None = None) -> dict:
    """当前 run 最近一次对象级 unknown 授权的聚合（重跑/结果变更后旧授权自动失效）。"""
    if items is None:
        items = collect_platform_unknown(case_id) + collect_manifest_unknown(case_id)
    acc = validate_unknown_accepts(case_id, items)
    return {"run_id": acc.get("run_id") or "", "keys": list(acc.get("accepted_keys") or []),
            "accepted": bool(acc.get("accepted")),
            "actor": acc.get("actor") or "", "reason": acc.get("reason") or "",
            "details": acc}


def collect_unknown(case_id: str, cats: dict | None = None) -> dict:
    """unknown 唯一集合：平台 point_state + manifest active + 对象级授权校验（同源）。"""
    run_id = _case_run_id(case_id)
    platform = collect_platform_unknown(case_id)
    manifest = collect_manifest_unknown(case_id, cats)
    items = list(platform) + list(manifest)
    for it in items:
        try:
            it["binding"] = unknown_object_ref(it, case_id=case_id, run_id=run_id)
        except Exception:
            it["binding"] = {}
    acc = validate_unknown_accepts(case_id, items)
    accepted = set(acc.get("accepted_keys") or [])

    def _unaccepted(rows):
        return [x for x in rows if not (unknown_key_candidates(x) & accepted)]

    return {"run_id": run_id,
            "accepted_unknown": bool(acc.get("accepted")),
            "accepted_keys": sorted(accepted),
            "accepted_count": len(accepted),
            "accept": acc,
            "platform": platform, "manifest": manifest,
            "platform_unaccepted": _unaccepted(platform),
            "manifest_unaccepted": _unaccepted(manifest),
            "keys": sorted({k for x in items for k in unknown_key_candidates(x)})}


# ---------------- 对象级授权服务 API（V08；HTTP/CLI 接线不在 T-28 写作用域） ----------------

def accept_unknown_object(case_id: str, result_id, result_hash: str = "", run_id: str = "",
                          reason: str = "", actor: str = "", role: str = "",
                          ttl_days=None) -> dict:
    """按对象授权一个 unknown/证据不足结果（禁止批量）。

    参数：
    - result_id：manifest_result.id 或 point_state.id；传 list/逗号串 → 直接拒绝“批量豁免”。
    - result_hash：对象级内容 hash（collect_unknown 的 binding.result_hash）；不匹配=结果已变更。
    - run_id：当前审核批次；不匹配=过期批次；缺省取 case.last_run_id。
    - 关键项第一次授权只落“1 人”，需要另一名不同操作人再次授权后才放行（双人）。
    """
    from . import review as _rv  # 延迟导入避免循环依赖
    if isinstance(result_id, (list, tuple, set, dict)):
        return {"ok": False, "code": "batch_forbidden",
                "error": "禁止批量豁免：一次只能授权一个对象（result_id 必须为单个 ID）"}
    rid = str(result_id or "").strip()
    if not rid:
        return {"ok": False, "code": "result_id_required", "error": "必须提供对象级 result_id"}
    if "," in rid or "|" in rid or " " in rid:
        return {"ok": False, "code": "batch_forbidden",
                "error": "禁止批量豁免：result_id 不允许包含多个对象"}
    if not str(reason or "").strip():
        return {"ok": False, "code": "reason_required", "error": "接受 unknown 必须填写理由"}
    if not str(actor or "").strip():
        return {"ok": False, "code": "actor_required", "error": "必须记录授权人"}
    if role and str(role) not in _ACCEPT_ACTORS:
        return {"ok": False, "code": "forbidden", "error": "无例外授权权限"}
    cur_run = _case_run_id(case_id)
    if not cur_run:
        return {"ok": False, "code": "run_required", "error": "没有可绑定的审核批次"}
    if run_id and str(run_id) != cur_run:
        return {"ok": False, "code": "stale_run",
                "error": "只能按当前审核批次授权（旧批次授权已失效）"}
    # 定位对象：manifest_result 优先，其次 point_state（均校验归属 case）
    binding = {}
    row = _manifest_result_row(rid)
    if row:
        mid = str(row.get("manifest_id") or "")
        if _manifest_case_id(mid) != str(case_id):
            return {"ok": False, "code": "not_found", "error": "对象不属于该项目"}
        bind_run = _run_for_manifest(mid) or cur_run
        if bind_run != cur_run:
            return {"ok": False, "code": "stale_run",
                    "error": "只能按当前审核批次授权（对象所属批次不是当前 run）"}
        non_waivable, why = _non_waivable_result(row)
        key_item = _rule_severity(str(row.get("rule_code") or "")) == "critical"
        binding = {"kind": "manifest_result", "result_id": rid,
                   "result_hash": _result_content_hash(row), "run_id": bind_run,
                   "rule_code": str(row.get("rule_code") or ""),
                   "object_id": str(row.get("object_id") or ""), "sub_id": "",
                   "state": _d5_status(row),
                   "waivable": not non_waivable, "key_item": key_item,
                   "required_actors": 2 if key_item else 1,
                   "non_waivable_reason": why}
    else:
        psrow = {}
        try:
            c = db.connect()
            try:
                r = c.execute("SELECT * FROM point_state WHERE id=?", (rid,)).fetchone()
                psrow = dict(r) if r else {}
            finally:
                c.close()
        except Exception:
            psrow = {}
        if not psrow:
            return {"ok": False, "code": "not_found", "error": "对象级 result_id 不存在"}
        batch_ids = set(_latest_batches(case_id))
        if str(psrow.get("batch_id") or "") not in batch_ids:
            return {"ok": False, "code": "stale_run",
                    "error": "只能按当前审核批次授权（点位批次不是当前 run）"}
        st = str(psrow.get("state") or "")
        why = str(psrow.get("reason") or "")
        non_waivable = _platform_non_waivable(st, why)
        binding = {"kind": "platform_point", "result_id": rid,
                   "result_hash": point_state_hash(psrow), "run_id": cur_run,
                   "point_id": str(psrow.get("point_id") or ""), "rule_code": "",
                   "object_id": "", "sub_id": "", "state": st,
                   "waivable": not non_waivable, "key_item": False,
                   "required_actors": 1,
                   "non_waivable_reason": ("执行失败（execution_failed）不可通过例外豁免"
                                           if non_waivable else "")}
    try:
        if result_hash and str(result_hash) != str(binding.get("result_hash") or ""):
            R.audit_logs.log(actor=actor, action="unknown.accept_rejected", object=case_id,
                             after=json.dumps({"result_id": rid, "reason": "result_hash 不匹配",
                                               "run_id": cur_run}, ensure_ascii=False))
            return {"ok": False, "code": "stale_hash",
                    "error": "结果/证据已变更（result_hash 不匹配），请重新读取后授权",
                    "current_hash": binding.get("result_hash") or "",
                    "expected_hash": str(result_hash or "")}
    except Exception:
        pass
    if not binding.get("waivable"):
        try:
            R.audit_logs.log(actor=actor, action="unknown.accept_rejected", object=case_id,
                             after=json.dumps({"result_id": rid, "kind": binding.get("kind"),
                                               "reason": binding.get("non_waivable_reason") or "不可豁免",
                                               "run_id": cur_run}, ensure_ascii=False))
        except Exception:
            pass
        return {"ok": False, "code": "non_waivable",
                "error": binding.get("non_waivable_reason") or "该对象属于不可豁免类别",
                "result_id": rid, "run_id": cur_run}
    # 已有授权（同 run+result_id+hash 的不同操作人）
    actors_before = set()
    for rec in _accept_records(case_id):
        m = rec.get("meta") or {}
        if str(m.get("result_id") or "") != rid:
            continue
        if str(m.get("run_id") or "") != str(binding.get("run_id") or ""):
            continue
        if str(m.get("result_hash") or "") != str(binding.get("result_hash") or ""):
            continue
        aa = str(rec.get("actor") or "")
        if aa:
            actors_before.add(aa)
    actors_after = sorted(actors_before | {str(actor)})
    try:
        _ttl = ttl_days
        if _ttl is None:
            try:
                _ttl = int(os.environ.get("RULEPROOF_UNKNOWN_ACCEPT_DAYS",
                                          str(_ACCEPT_DEFAULT_TTL_DAYS)) or _ACCEPT_DEFAULT_TTL_DAYS)
            except Exception:
                _ttl = _ACCEPT_DEFAULT_TTL_DAYS
        expires_at = time.strftime("%Y-%m-%d %H:%M:%S",
                                   time.localtime(time.time() + max(0, int(_ttl)) * 86400))
        meta = {"result_id": rid, "result_hash": binding.get("result_hash") or "",
                "run_id": binding.get("run_id") or cur_run,
                "kind": binding.get("kind") or "",
                "point_id": binding.get("point_id") or "",
                "rule_code": binding.get("rule_code") or "",
                "object_id": binding.get("object_id") or "",
                "sub_id": binding.get("sub_id") or "",
                "state": binding.get("state") or "",
                "key_item": bool(binding.get("key_item")),
                "required_actors": int(binding.get("required_actors") or 1),
                "reason": str(reason)[:300], "actor_id": str(actor),
                "expires_at": expires_at, "schema": "unknown.accept.object.v1"}
        R.audit_logs.log(actor=actor, action="unknown.accepted", object=case_id,
                         after=json.dumps(meta, ensure_ascii=False))
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "code": "audit_failed",
                "error": f"授权审计写入失败：{type(e).__name__}"}
    accepted = len(actors_after) >= int(binding.get("required_actors") or 1)
    return {"ok": True, "accepted": accepted,
            "result_id": rid, "result_hash": binding.get("result_hash"),
            "run_id": binding.get("run_id") or cur_run,
            "kind": binding.get("kind"), "key_item": bool(binding.get("key_item")),
            "required_actors": int(binding.get("required_actors") or 1),
            "actors": actors_after, "requires_second": not accepted,
            "expires_at": meta.get("expires_at") if isinstance(meta, dict) else "",
            "note": ("关键项双人授权：已记录 1 人，还需另一名不同操作人授权"
                     if not accepted else "对象级例外授权已生效")}


def _frozen_run_state(case_id: str) -> dict:
    """F-08：最近一次 run 的冻结清单一族统计（门禁硬阻断依据）。

    返回 items=冻结条目数（无 manifest 时为 None）、results=执行结果行数、
    na=全部不适用行数、persisted=落库审核结论（trace_json.summary）。
    """
    out = {"run_id": "", "manifest_id": "", "items": None, "results": 0,
           "na": 0, "persisted": {},
           # L77：manifest.executed 审计写失败标记（project.audit 落 trace；默认 False）
           "audit_failed": False, "manifest_audit": {}}
    try:
        with db.session() as c:
            ar = c.execute(
                "SELECT id,manifest_id,trace_json FROM audit_run WHERE case_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
            if not ar:
                return out
            out["run_id"] = str(ar["id"] or "")
            mid = str(ar["manifest_id"] or "")
            out["manifest_id"] = mid
            try:
                trace = json.loads(ar["trace_json"] or "{}")
            except Exception:
                trace = {}
            # L77：审计失败标记只读回显（不改变任何判定语义；阻断在 check() 顶部）
            if isinstance(trace, dict):
                out["audit_failed"] = bool(trace.get("audit_failed"))
                _ma = trace.get("manifest_audit")
                out["manifest_audit"] = _ma if isinstance(_ma, dict) else {}
            if isinstance(trace, dict) and isinstance(trace.get("summary"), dict):
                out["persisted"] = trace["summary"]
            if not mid:
                return out
            m = c.execute("SELECT items_json FROM audit_manifest WHERE id=?",
                          (mid,)).fetchone()
            if not m:
                return out
            try:
                items = json.loads(m["items_json"] or "[]")
            except Exception:
                items = []
            out["items"] = len(items)
            rows = c.execute("SELECT d5_json FROM manifest_result WHERE manifest_id=?",
                             (mid,)).fetchall()
            out["results"] = len(rows)
            _na = 0
            for r in rows:
                try:
                    # M1：na 同义状态（not_applicable/not applicable/skipped…）同计「不适用」；
                    # 全部不适用仍旧硬阻断（合法阻断），不因归一面放宽
                    if _audit_ledger.is_na_state(
                            (json.loads(r["d5_json"] or "{}") or {}).get("status")):
                        _na += 1
                except Exception:
                    continue
            out["na"] = _na
    except Exception:
        return out
    return out


def check(case_id: str) -> dict:
    case = R.cases.get(case_id)
    if not case:
        return {"ok": False, "reasons": ["项目不存在"]}
    reasons = []
    # P0-证据（用户优先级 5）：门禁只做**只读预演**——核验 fail 发现引文是否逐字命中
    # 归属对象原文/单元格，但绝不落库改写 finding（persist=False）。
    # 理由：门禁有副作用会造成「出报告前/后两套准确率口径」（fail 被静默降级），
    # 且非幂等。真正的降级收敛到唯一入口 report.generate（正式生成报告时显式执行一次）。
    # 阻断语义不变：下面直接依据预演结果（将被降级 N 条）阻断签发。
    _evidence_gate = {}
    try:
        from . import review as _rv_ev
        _evidence_gate = _rv_ev.enforce_evidence_quotes(case_id, persist=False)
    except Exception:
        logging.getLogger(__name__).warning("evidence quote gate skipped", exc_info=True)
        _evidence_gate = {}
    # 未审核/草稿项目不得导出空报告；兼容旧 /reviews 路径（有发现但可能没有 last_run_id）
    _all = R.findings.by_case(case_id)
    _all_findings_raw = list(_all)
    # T-194 影子池（Phase 1）：正式报告只统计 formal。
    #   1) 被仲裁进 shadow/discarded 的既有平台 finding 从正式门禁口径剔除（不阻断报告）；
    #   2) shadow 单列“疑似问题（未裁决）N 条”提示，不进通过率分母、不阻断放行；
    #   3) discarded 不出现于报告（仅审计可查）。
    # 影子项本身存独立 shadow_item 表、从不写入 finding 表 → 报告渲染天然不含新影子项。
    _shadow_pool = {"enabled": False, "hint": None, "formal": {}, "shadow": {},
                    "discarded": {}, "pass_rate": {},
                    "formal_excluded_finding_ids": [],
                    "note": "影子池统计未启用（表未初始化/无数据）"}
    _sp_excluded = set()
    try:
        # T-202：影子池报告口径（唯一仲裁/分区）只经 dual_track_gateway 读取，
        # 不直接引用 shadow_pool 模块（唯一入口约束见 docs/qa/双轨唯一入口约束_20261120.md）。
        from . import dual_track_gateway as _dt_gw
        _shadow_pool = _dt_gw.report_partition(case_id)
        _sp_excluded = {str(x) for x in
                        (_shadow_pool.get("formal_excluded_finding_ids") or [])}
        if _sp_excluded:
            _all = [f for f in _all
                    if str(f.get("id") or "") not in _sp_excluded]
    except Exception:  # noqa: BLE001 —— 影子池统计失败不得阻断项目主链门禁
        logging.getLogger(__name__).warning("shadow pool report stats skipped",
                                            exc_info=True)
    if not (case.get("last_run_id") or "").strip() and not _all_findings_raw:
        reasons.append("项目尚未完成审核（无审核批次），不能导出正式报告")

    # F-08：空清单 / 规则零执行 / 全不适用 硬阻断正式报告，不能导出“通过”报告
    _frz = _frozen_run_state(case_id)
    # L77（build49 P0，90 号 §二-3 / 外部评审 Top3）：最近一次 run 的 manifest.executed
    # 下沉审计写失败 → 本次执行无法自证，禁止签发正式报告（错误码 audit_write_failed）。
    # 只读 trace 标记；回退开关 RULEPROOF_AUDIT_HARD_FAIL=0 时忽略（旧“只告警”行为）。
    _audit_hard = {"enabled": True, "blocked": False,
                   "code": AUDIT_WRITE_FAILED_CODE, "detail": {}}
    try:
        from . import single_entry as _se_af
        _audit_hard["enabled"] = bool(_se_af.audit_hard_fail_enabled())
    except Exception:  # noqa: BLE001 - 开关不可用按默认硬阻断（fail-closed）
        _audit_hard["enabled"] = True
    if _frz.get("audit_failed") and _audit_hard["enabled"]:
        _ma = _frz.get("manifest_audit") or {}
        _audit_hard.update(blocked=True, detail={
            "run_id": str(_frz.get("run_id") or ""),
            "manifest_id": str(_frz.get("manifest_id") or ""),
            "reason": str(_ma.get("reason") or "")[:300],
            "action": str(_ma.get("action") or "")[:100],
            "switch": "RULEPROOF_AUDIT_HARD_FAIL=1",
        })
        _append_code_reason(
            reasons, AUDIT_WRITE_FAILED_CODE,
            "最近一次审核的 manifest.executed 审计未能落库（audit_failed）："
            "本次执行无法自证，禁止签发正式报告；请修复审计库写入后重跑审核。"
            + (f"原因：{_audit_hard['detail']['reason']}"
               if _audit_hard["detail"]["reason"] else ""))
    # L87（2026-11-24，外部复验 §7 P0-3）：审计状态一致性门禁。与 project.audit /
    # 语义重审 / report.generate 读同一事实源（audit_ledger.audit_state），覆盖 L77
    # 「只读最近 run trace」看不到的失败态：case=audit_failed 但 run 标记缺失（语义重审
    # 失败批次按 L58 契约被清理）、case 与 run 来源矛盾（半状态）等（last_run_id 悬空
    # 只由 audit_state 告警、不阻断，保持既有案件/夹具契约）。
    # failed/inconsistent → 一律禁止签发；恢复（成功重跑写唯一 audit.recovered 且
    # case=completed、当前 run 干净）后由同一事实源自动放行。开关默认 1，=0 回退。
    _audit_state = {}
    try:
        from . import audit_ledger as _alg_rg
        if _alg_rg.audit_state_consistency_enabled():
            _audit_state = _alg_rg.audit_state(case_id)
    except Exception:  # noqa: BLE001 - 读状态失败：沿用 L77 标记门禁（不吞异常，留痕）
        logging.getLogger(__name__).warning(
            "L87 audit state gate skipped case=%s", case_id, exc_info=True)
        _audit_state = {}
    _st_state = str((_audit_state or {}).get("state") or "")
    if _st_state in ("failed", "inconsistent"):
        if _audit_hard.get("blocked"):
            # L77 已按 audit_write_failed 阻断（同一失败）：并入状态机证据，不重复 code
            _audit_hard.setdefault("audit_state", {
                "state": _st_state,
                "case_status": str(_audit_state.get("case_status") or ""),
                "failure_epoch": str(_audit_state.get("failure_epoch") or ""),
                "recovered_event_count": int(
                    _audit_state.get("recovered_event_count") or 0),
            })
        else:
            _code_st = (AUDIT_STATE_INCONSISTENT_CODE if _st_state == "inconsistent"
                        else AUDIT_STATE_FAILED_CODE)
            _audit_hard.update(blocked=True, code=_code_st, detail={
                "case_status": str(_audit_state.get("case_status") or ""),
                "current_run_id": str(_audit_state.get("current_run_id") or ""),
                "latest_run_id": str(_audit_state.get("latest_run_id") or ""),
                "failed_run_ids": list(_audit_state.get("failed_run_ids") or [])[:10],
                "reasons": list(_audit_state.get("reasons") or [])[:6],
                "failure_epoch": str(_audit_state.get("failure_epoch") or ""),
                "switch": "RULEPROOF_AUDIT_STATE_CONSISTENCY=1",
            })
            _audit_hard["audit_state"] = {
                "state": _st_state,
                "case_status": str(_audit_state.get("case_status") or ""),
                "failure_epoch": str(_audit_state.get("failure_epoch") or ""),
                "recovered_event_count": int(
                    _audit_state.get("recovered_event_count") or 0),
            }
            _append_code_reason(
                reasons, _code_st,
                "审核状态未收敛（" + (("case.status="
                                      + str(_audit_state.get("case_status") or ""))
                                     if _st_state == "failed" else "状态来源矛盾")
                + "）：审计失败状态未解除/状态不一致，本次不得签发正式报告；"
                "请修复审计库写入后重跑审核（成功重跑会写唯一 audit.recovered 并恢复签发）。"
                + ("原因：" + "；".join(list(_audit_state.get("reasons") or [])[:3])
                   if _audit_state.get("reasons") else ""))
    # L52 ②（2026-11-24）：legacy 链路无冻结清单 → 禁止签发正式报告。
    # 判据：compat_mode=legacy + 最近审核批次存在 + 该批次 manifest_id 为空（legacy 全链
    # 无 manifest，L46a H04/H05）。有 manifest 的 compat 案件仍走主链，不在此列。
    _se_on = True
    _legacy_orch = False
    _legacy_no_manifest = False
    # L58 ②：legacy 报告的签发边界显式化——「无 finding 才可签发」；
    # 有 finding 一律 fail-closed，且把「缺逐字引文」单列，避免低证据结论混入报告。
    _legacy_findings = 0
    _legacy_no_quote = 0
    _legacy_clean_signable = False
    try:
        from . import single_entry as _se_rg
        _se_on = _se_rg.enabled()
        if _se_on:
            _legacy_no_manifest = bool(_se_rg.legacy_run_without_manifest(case_id))
            _legacy_findings = len(_all_findings_raw or [])
            _legacy_no_quote = sum(
                1 for _f in (_all_findings_raw or [])
                if not str((_f or {}).get("verbatim_quote") or "").strip())
            # 只对「有结论要签发」的 legacy 报告硬阻断：有 finding 时报告承载的是
            # 无 manifest/无逐字引文的低证据结论（L46a R2），必须 fail-closed；
            # 干净 legacy 报告（0 finding）没有结论要签发，保留既有「旧链路报告」
            # 回归契约（gate #007），仅在报告正文标注执行口径。
            if _legacy_no_manifest and _all_findings_raw:
                reasons.append(
                    "legacy 审核链路无冻结清单（manifest_id 为空）且报告含 finding："
                    "按 L52/L58 fail-closed 禁止签发正式报告（legacy 报告仅允许"
                    "「无 finding」的干净文档签发）；请用 project.audit 的 "
                    "manual/assisted 两模式重新审核")
                if _legacy_no_quote:
                    reasons.append(
                        f"legacy 审核链路 finding 缺少逐字引文（{_legacy_no_quote} 条 "
                        "verbatim_quote 为空）：无 manifest 的 legacy 结论不得作为正式"
                        "报告依据（L46a R2 / L58 ②）")
            elif _legacy_no_manifest:
                # 保留 gate #007「旧链路报告」契约：无 finding 时可签发，报告正文标注口径。
                _legacy_clean_signable = True
            try:
                with db.session() as _c_se:
                    _r_se = _c_se.execute(
                        "SELECT trace_json FROM audit_run WHERE case_id=? "
                        "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                        (case_id,)).fetchone()
                _tj = json.loads((_r_se["trace_json"] if _r_se else "") or "{}")
                _legacy_orch = bool(_tj.get("legacy_orchestrator"))
            except Exception:
                _legacy_orch = False
    except Exception:  # noqa: BLE001 - 标注失败不改变既有门禁
        logging.getLogger(__name__).warning(
            "single_entry report gate annotation skipped case=%s", case_id, exc_info=True)
    _items = _frz.get("items")
    _results = int(_frz.get("results") or 0)
    _na = int(_frz.get("na") or 0)
    if _frz.get("manifest_id") and _items == 0:
        reasons.append("审核清单为空（冻结 items=0，无适用规则/规则未冻结），不能导出正式报告")
    elif _items is not None and int(_items or 0) > 0 and _results == 0:
        reasons.append(f"本次审核规则执行数为 0（冻结清单 {int(_items)} 条但无执行结果），"
                       "不能导出正式报告")
    elif _items is not None and int(_items or 0) > 0 and _results and _na == _results:
        reasons.append("本次审核全部规则不适用（无适用规则），不能导出正式报告")
    elif not _frz.get("manifest_id") and _frz.get("persisted"):
        _ps = _frz["persisted"]
        try:
            _ps_items = int(_ps.get("manifest_items") or 0)
            _ps_total = int(_ps.get("total_findings") or 0)
        except Exception:
            _ps_items, _ps_total = -1, -1
        if _ps_items == 0 and _ps_total == 0:
            reasons.append("审核清单为空（无适用规则），不能导出正式报告")

    fs = _all
    # 不再只按 last_run 过滤：重跑后上一轮未签发发现也必须继续阻断，避免“界面说没问题”
    fs = [f for f in fs if (f.get("status") or "pending") != "false_positive"]

    pending = [f for f in fs if (f.get("status") or "pending") == "pending"]
    if pending:
        reasons.append(f"仍有 {len(pending)} 条待复核发现")

    critical = [f for f in fs if f.get("severity") == "critical"]
    crit_pending = [f for f in critical if (f.get("status") or "pending") == "pending"]
    if crit_pending:
        reasons.append(f"高严重度发现未签发：{len(crit_pending)} 条")

    # P0-证据：引文未逐字命中 → 不得签发正式报告。阻断依据 = 只读预演结果，不写库：
    #   (a) 预演命中：本次正式生成时会被降级 N 条（门禁本身不改 finding 状态）；
    #   (b) 已降级：历史正式生成已落库的 need_evidence 继续阻断，避免“降级后自动放行”。
    # 预演按正式报告口径过滤影子池剔除项（与 fs 同源：影子项不进正式报告、不阻断放行）。
    _ev_preview = [x for x in (_evidence_gate.get("downgraded") or [])
                   if str((x or {}).get("id") or "") not in _sp_excluded]
    _ev_blocked = [f for f in fs
                   if str(f.get("status") or "") == "need_evidence"
                   and "证据门禁" in str(f.get("summary") or "")]
    if _ev_preview:
        reasons.append(
            f"{len(_ev_preview)} 条 fail 发现引文未逐字命中归属对象原文/单元格"
            "（证据门禁预演），正式生成报告时将被降级为证据不足/人工复核，"
            "不得签发正式报告")
    if _ev_blocked:
        reasons.append(
            f"{len(_ev_blocked)} 条发现引文未逐字命中归属对象原文/单元格（证据门禁），"
            "已降级证据不足/人工复核，不得签发正式报告")

    # L72 P2b（2026-11-24）：Certificate Kernel 证书节（只读；默认关 → 不读表/不加字段，
    # 与接入前逐字节一致）。KERNEL=1 + REQUIRED=0 → advisory（只写 stats/warnings，不改变 ok）；
    # KERNEL=1 + REQUIRED=1 → 无证书/证书 fail/insufficient/stale 的 fail finding 阻断签发。
    # `enforce_certificates(persist=True)` 是唯一降级写点（report.generate 侧），门禁本身不写库。
    _cert_gate = {}
    _cert_stats = None
    try:
        from . import certificate_service as _cs_cert
        _cert_conf = _cs_cert.config_error()
        if _cs_cert.kernel_enabled():
            _cert_gate = _cs_cert.gate_section(case_id, findings=fs)
            for _cr in (_cert_gate.get("reasons") or []):
                if _cr and not any(_cr in x or x in _cr for x in reasons):
                    reasons.append(_cr)
            if _cert_gate.get("config_error"):
                _conf_msg = ("[certificate_config] 证书门禁配置非法"
                             f"（{_cert_gate['config_error']}）：REQUIRED=1 需要 KERNEL=1，"
                             "按 fail-closed 阻断签发")
                if not any("证书门禁配置非法" in x for x in reasons):
                    reasons.append(_conf_msg)
        elif _cert_conf:
            _cert_gate = {"enabled": False, "required": True, "mode": "blocking",
                          "ok": False, "config_error": _cert_conf, "stats": {},
                          "warnings": [], "reasons": [], "items": []}
            _msg = ("[certificate_config] 证书门禁 REQUIRED=1 但 KERNEL=0：配置非法，"
                    "按 fail-closed 阻断签发")
            if not any("证书门禁 REQUIRED=1 但 KERNEL=0" in x for x in reasons):
                reasons.append(_msg)
    except Exception as _e:  # noqa: BLE001 —— 证书门禁异常与人工/产品门禁同模式
        _req_on = False
        try:
            from . import certificate_service as _cs_cert2
            _req_on = bool(_cs_cert2.required_enabled())
        except Exception:
            _req_on = False
        logging.getLogger(__name__).warning("certificate gate skipped", exc_info=True)
        _cert_gate = {"enabled": True, "required": _req_on, "skipped_error": True,
                      "error": f"{type(_e).__name__}: {str(_e)[:200]}",
                      "mode": "blocking" if _req_on else "advisory"}
        if _req_on:
            _msg = ("[certificate_unavailable] 证书门禁读取异常（fail-closed），"
                    "禁止签发正式报告")
            if not any("证书门禁读取异常" in x for x in reasons):
                reasons.append(_msg)

    # P0-稳定性（用户优先级 4）：同文件重审 N=3 多数投票；关键规则 pass↔fail 翻转
    # 由 marker 硬阻断签发（不是 UI 提示）。票源 = 最近 3 次带 manifest 的审核。
    _stab = {}
    try:
        from . import manifest_exec as _mex_st
        _stab = _mex_st.stability_votes(case_id, persist=True)
    except Exception:
        logging.getLogger(__name__).warning("stability votes skipped", exc_info=True)
        _stab = {}
    try:
        from . import stability as _st
        _legacy_flips = _st.unresolved(case_id) or []
    except Exception:
        _legacy_flips = []
    _all_flips, _seen_flip = [], set()
    for _f in list(_stab.get("flips") or []) + list(_legacy_flips or []):
        _key = (str(_f.get("point") or _f.get("rule_code") or ""),
                str(_f.get("object_id") or ""),
                tuple(sorted(_f.get("states") or [])))
        if _key in _seen_flip:
            continue
        _seen_flip.add(_key)
        _all_flips.append(_f)
    _key_flips = [f for f in _all_flips if f.get("key_rule")]
    if _key_flips:
        _codes = "、".join(sorted({str(f.get("rule_code") or f.get("point") or "")
                                   for f in _key_flips})[:6])
        reasons.append(
            f"关键规则判定翻转（{len(_key_flips)} 条：{_codes}）：最近 "
            f"{int(_stab.get('n') or 3)} 次审核 pass↔fail 不一致，"
            "稳定性 marker 阻断签发；需人工确认后重审至稳定")
    _other_flips = [f for f in _all_flips if not f.get("key_rule")]
    if _other_flips:
        reasons.append(f"发现 {len(_other_flips)} 条判定翻转（pass↔fail），需人工确认")
    # V10：execution_failed 是独立票型，不能被 N 次多数票消除；存在即阻断，要求重审至执行完整。
    _vote_blocked = list(_stab.get("blocked_items") or [])
    if _vote_blocked:
        _exec_votes = int((_stab.get("votes_summary") or {}).get("execution_failed_votes") or 0)
        reasons.append(f"N=3 稳定性投票中 {len(_vote_blocked)} 个问题实例存在执行失败"
                       f"（execution_failed 票 {_exec_votes} 张），不能被多数票消除；"
                       "需重审至执行完整后再签发")

    # 人工接受 unknown（V08）：必须对象级 result_id+result_hash+run_id 绑定；重跑/结果变更/
    # 过期后旧授权自动失效；旧批量 point_ids 记录不作为放行依据（禁止批量豁免）。
    # report.check_gate 继续共用 collect_unknown（F-05 同源不变）。
    _platform_unknown_rows = collect_platform_unknown(case_id)
    _acc = validate_unknown_accepts(case_id, _platform_unknown_rows)
    # 只要存在例外授权尝试，就把 manifest unknown 一并纳入对象级校验（关键项双人/失效/
    # 不可豁免的原因必须对用户可见）。无授权尝试时保持轻量：manifest unknown 由
    # report.check_gate 的并集口径阻断；授权后 report.check_gate/collect_unknown 同源放行。
    _acc_union = _acc
    _union_checked = False
    if (_acc.get("records") or _acc.get("rejected_batch")
            or _acc.get("rejected_invalid")):
        try:
            _union_items = list(_platform_unknown_rows) + collect_manifest_unknown(case_id)
            _acc_union = validate_unknown_accepts(case_id, _union_items)
            _union_checked = True
        except Exception:
            _acc_union = _acc
    accepted_unknown = 1 if _acc.get("accepted") else 0
    accepted_ids = list(_acc.get("accepted_keys") or [])

    unknown = 0
    unknown_ids = set()
    for row in _platform_unknown_rows:
        if str(row.get("state") or "") == "unknown":
            unknown += 1
            unknown_ids.add(str(row.get("point_id") or ""))
    _accepted_set = {str(x) for x in accepted_ids if str(x).strip()}
    _remaining = unknown_ids - _accepted_set if _accepted_set else set(unknown_ids)
    # legacy_compat：平台点位 unknown 保留为附录，不阻断；客户规则 unknown 仍阻断
    _compat = str(case.get("compat_mode") or "") == "legacy"
    # L52 ②：compat 豁免只对「没有 manifest 的纯 legacy 传输」有效；兼容路径一旦
    # 走了 project.audit/manifest 主链，门禁必须按主链全强度判定（不得用 legacy
    # 豁免放宽 unknown/解析缺口）——收紧点与关闭 RULEPROOF_SINGLE_ENTRY_FIX=0 可回退。
    if _compat and _se_on:
        try:
            from . import single_entry as _se_compat
            if _se_compat.case_has_manifest(case_id):
                _compat = False
        except Exception:  # noqa: BLE001 - 查询失败保持旧口径并留痕
            logging.getLogger(__name__).warning(
                "compat tightening manifest lookup failed case=%s", case_id, exc_info=True)
    _platform_unknown = set()
    if _compat:
        try:
            _cls = pstates.unknown_classes(case_id, _latest_batches(case_id))
            _cust = set(_cls.get("customer_unexecuted") or []) | set(_cls.get("customer_insufficient") or [])
            _platform_unknown = (set(_cls.get("platform_builtin") or [])
                                 | set(_cls.get("not_applicable") or [])
                                 | set(_cls.get("customer_not_applicable") or []))
        except Exception:
            _cust, _platform_unknown = set(_remaining), set()
        _remaining = set(_remaining) & _cust
    # 接受必须覆盖当前 run 的全部 unknown；部分接受不能放行
    if _remaining:
        reasons.append(f"存在 {len(_remaining)} 个 unknown（未执行/执行失败）判定")
    unknown = len(_remaining)
    _union_unaccepted = any(not d.get("accepted")
                            for d in (_acc_union.get("details") or []))
    if not _compat and (_remaining or _union_unaccepted):
        # V08 例外授权失败原因必须显式（不能只给一句“存在 unknown”）；
        # 全部对象已合法授权时不再保留旧批量/失效记录原因（统计仍在 stats 里）。
        if _remaining and _acc_union.get("rejected_batch"):
            reasons.append(
                f"{int(_acc_union.get('rejected_batch'))} 条旧批量 unknown 接受记录"
                "（point_ids 列表）不作为放行依据：V08 要求按对象绑定 "
                "result_id+result_hash+run_id，禁止批量豁免")
        _nw = [d for d in (_acc_union.get("details") or []) if not d.get("waivable")]
        if _nw:
            reasons.append(
                f"{len(_nw)} 个 unknown 属于不可豁免类别（执行失败 execution_failed/"
                "完整性错误），不能用例外授权放行")
        _pend = list(_acc_union.get("pending_dual") or [])
        _key_open = [d for d in (_acc_union.get("details") or [])
                     if d.get("key_item") and not d.get("accepted")]
        if _pend or _key_open:
            reasons.append(
                f"{max(len(_pend), len(_key_open))} 个关键项 unknown 授权人数不足："
                "关键项需双人（两名不同操作人分别授权）")
        if _acc_union.get("stale_hash"):
            reasons.append(
                f"{int(_acc_union.get('stale_hash'))} 条 unknown 例外授权已失效："
                "结果/证据已变更（result_hash 不匹配），需重新授权")
        if _acc_union.get("expired"):
            reasons.append(
                f"{int(_acc_union.get('expired'))} 条 unknown 例外授权已过期，需重新授权")

    from . import project as _pj
    docs = _pj.documents(case_id)
    # 目前没有“缺口接受”字段，partial/failed 一律视为未接受（诚实缺口）
    unaccepted = [d for d in docs
                  if (d.get("parse_status") or "ok") in ("partial", "failed")
                  and not str(d.get("parse_summary") or "").startswith("[缺口已接受]")]
    # compat 模式：缺口不删除，列入报告附录，不作为静默通过
    if unaccepted and not _compat:
        reasons.append(f"{len(unaccepted)} 份文件解析缺口未确认接受")

    # P1-6：扩展版本快照 v2（delivery-ready）一致性。报告/门禁必须能显示快照一致/差异；
    # 环境漂移不阻断“已执行审核”的签发（否则改配置文件就无法出报告），但差异必须可审计。
    _vs_stats = {"found": False, "identical": None, "changed": [], "note": "",
                 "replayable": None, "snapshot_id": "", "digest": ""}
    try:
        from . import version_snapshot as _vs
        from . import ctx as _ctxv
        _run = str(case.get("last_run_id") or "")
        if _run:
            _snap = _vs.load(case_id, _run)
            if _snap:
                _blk = _vs.report_block(_snap)
                _tid = str(case.get("tenant_id") or "t-default")
                _wid = str(case.get("workspace_id") or "ws-default")
                # L98 P1：用完整状态快照/恢复（旧写法只恢复 tenant/workspace/mode，
                # system/doc_type/case 被 set_context 静默清空）。
                _saved_ctx = _ctxv.snapshot()
                _switched = (_saved_ctx.get("tenant_id") or "") != _tid or \
                            (_saved_ctx.get("workspace_id") or "") != _wid
                try:
                    if _switched:
                        _ctxv.set_context(_tid, _wid)
                    _cur = _vs.build(case_id, _run, tenant_id=_tid, workspace_id=_wid)
                finally:
                    if _switched:
                        try:
                            _ctxv.restore(_saved_ctx)
                        except Exception:
                            logging.getLogger(__name__).debug("ctx restore skipped", exc_info=True)
                _ver = _vs.verify(case_id, _run, current=_cur)
                _vs_stats = {"found": True,
                             "identical": bool(_ver.get("identical")),
                             "replayable": bool(_ver.get("replayable")),
                             "changed": [str((c or {}).get("field") or "")
                                         for c in (_ver.get("changed") or [])][:20],
                             "snapshot_id": _blk.get("snapshot_id") or "",
                             "digest": _blk.get("digest") or "",
                             "built_at": _blk.get("built_at") or "",
                             "note": "" if _ver.get("identical")
                                     else "运行环境配置与审核时快照存在差异（报告已列出，需审计关注）"}
            else:
                _vs_stats["note"] = "该 run 无 v2 扩展快照（旧 run 或审核执行未保存）"
        else:
            _vs_stats["note"] = "项目尚无审核 run"
    except Exception as e:  # noqa: BLE001
        _vs_stats["note"] = f"快照校验跳过：{type(e).__name__}"

    # T-43 人工复核闭环（Phase 2/3）：有双轨数据时，展示项未复核 / 可见性未应用 /
    # 人工漏报未对账都不得出正式报告；无任何双轨数据的项目 enabled=False，行为零变化。
    _human_loop = {"enabled": False, "ok": True, "reasons": [], "stats": {},
                   "not_gold": True}
    _gate_fail_closed = {"strict": gate_strict(),
                         "codes": ([str(_audit_hard.get("code")
                                        or AUDIT_WRITE_FAILED_CODE)]
                                   if _audit_hard.get("blocked") else []),
                         "human_review": {}, "product_gate": {},
                         "ledger_incomplete": {}}

    def _mark_gate_unavailable(part: str, exc, what: str) -> dict:
        """复核门禁不可用：默认阻断（fail-closed），=0 时显式降级放行并留痕。"""
        _strict = gate_strict()
        _msg = _unavailable_detail(exc, what)
        logging.getLogger(__name__).warning(
            "%s gate error (strict=%s) → %s", part, _strict,
            "fail-closed 阻断" if _strict else "显式降级放行", exc_info=True)
        _payload = {"enabled": True, "ok": not _strict, "skipped_error": True,
                    "fail_closed": _strict, "code": GATE_UNAVAILABLE_CODE,
                    "reasons": [_msg]}
        _gate_fail_closed["codes"] = sorted(set(_gate_fail_closed["codes"] +
                                                [GATE_UNAVAILABLE_CODE]))
        _gate_fail_closed[part] = {"failed": True, "strict": _strict,
                                   "error": f"{type(exc).__name__}: {str(exc)[:200]}"
                                            if exc is not None else ""}
        if _strict:
            _append_code_reason(reasons, GATE_UNAVAILABLE_CODE, _msg)
        return _payload

    try:
        from . import human_review as _hr
        _human_loop = _hr.gate_check(case_id) or {}
        if _human_loop.get("skipped_error"):
            # gate_check 内部吞异常后自报 skipped_error（ok=True）——同样视为不可用，
            # 不能因为「异常被内层吞了」就放行。
            _human_loop = _mark_gate_unavailable(
                "human_review", RuntimeError("human_review.gate_check skipped_error"),
                "人工复核门禁")
        else:
            for _hr_reason in (_human_loop.get("reasons") or []):
                if _hr_reason and not any(_hr_reason in x or x in _hr_reason
                                          for x in reasons):
                    reasons.append(_hr_reason)
    except Exception as _e:  # noqa: BLE001
        # 2026-11-20（gpt-5.2 评审 P0-6）：人工复核门禁异常此前只 warning（fail-open），
        # 门禁算不出来时报告仍可放行。改为 fail-closed：明确阻断并给可读原因。
        _human_loop = _mark_gate_unavailable("human_review", _e, "人工复核门禁")

    # T-51（V3.3 增补）隐藏疑似问题开关 + 进化池最小钩子：只做聚合统计，
    # 不改变“隐藏项不进报告正文”的口径；evaluation 提交独立复核前不返回 N。
    _hidden_toggle = {"enabled": False, "mode": "production", "locked": False,
                      "hidden_count": None, "evolution": {}, "no_gold": True,
                      "note": "隐藏开关统计未接线"}
    try:
        from . import human_review as _hr_ht
        _hidden_toggle = _hr_ht.hidden_report_stats(case_id)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning("hidden toggle stats skipped",
                                            exc_info=True)

    # T-50（W-14）V3.2 §15 四项报告门禁：visible_unreviewed /
    # unresolved_critical_conflict / incomplete_applicable_requirement /
    # suppressed_risk_decision_missing 必须全部为 0。计数与"是否阻断"同源
    # （human_review.product_gate，CLI/HTTP 也读同一函数），避免只做 UI 提示。
    _product_gate = {"gates": {}, "reasons": [], "detail": {}, "manifest": {}}
    try:
        from . import human_review as _hr_pg
        _product_gate = _hr_pg.product_gate(case_id) or {}
        if _product_gate.get("skipped_error"):
            # 同上：product_gate 内部吞异常后自报 skipped_error，不得当 0 门禁放行。
            _product_gate = dict(_product_gate)
            _product_gate.update(_mark_gate_unavailable(
                "product_gate", RuntimeError("human_review.product_gate skipped_error"),
                "产品四项报告门禁"))
            _product_gate["applied_reasons"] = []
        else:
            _pg_reasons = []
            for _pg_reason in (_product_gate.get("reasons") or []):
                if _pg_reason and not any(
                        _pg_reason in x or x in _pg_reason for x in reasons):
                    reasons.append(_pg_reason)
                    _pg_reasons.append(_pg_reason)
            _product_gate["applied_reasons"] = _pg_reasons
    except Exception as _e:  # noqa: BLE001
        # 2026-11-20（gpt-5.2 评审 P0-6）：产品门禁异常此前 fail-open（skipped_error 但不阻断）。
        # 改为 fail-closed：四项报告门禁算不出来时禁止出正式报告。
        _product_gate = {"gates": {}, "reasons": [], "detail": {},
                         "manifest": {}, "skipped_error": True, "fail_closed": True}
        _product_gate.update(_mark_gate_unavailable("product_gate", _e, "产品四项报告门禁"))
        _product_gate["applied_reasons"] = []

    # P1-8（2026-11-21 外部交叉复测 A5）：点位台账写失败 → 覆盖度分母残缺，
    # 同一 run 重算得到不同口径；标记存在即阻断签发（fail-closed）。
    _ledger_incomplete = {"flag": False, "run_id": str((_frz or {}).get("run_id") or ""),
                          "batches": [], "failed_count": 0, "rows": [], "sources": []}
    try:
        _ledger_incomplete = pstates.ledger_incomplete(
            _latest_batches(case_id), run_id=_ledger_incomplete["run_id"])
    except Exception as _e:  # noqa: BLE001
        logging.getLogger(__name__).warning("ledger incomplete check failed",
                                            exc_info=True)
        _ledger_incomplete = {"flag": True, "run_id": "",
                              "batches": [], "failed_count": 0, "rows": [],
                              "sources": ["lookup_error"],
                              "error": f"{type(_e).__name__}: {str(_e)[:150]}"}
    # 禁止用 `_frz` 之前的旧变量：这里只依赖 check() 顶部已算出的冻结态。
    _gate_fail_closed["ledger_incomplete"] = _ledger_incomplete
    if _ledger_incomplete.get("flag"):
        _gate_fail_closed["codes"] = sorted(set(_gate_fail_closed["codes"] +
                                                [LEDGER_INCOMPLETE_CODE]))
        _li_msg = (f"点位台账写入不完整（run/batch 标记 ledger_incomplete，"
                   f"失败 {int(_ledger_incomplete.get('failed_count') or 0)} 行）："
                   "覆盖度分母残缺，同一 run 无法复算，禁止签发正式报告；"
                   "请先补写台账或重跑该批次")
        _append_code_reason(reasons, LEDGER_INCOMPLETE_CODE, _li_msg)

    # T-164 / 评审 C-4：冲突检测状态门禁。上面 unresolved_critical_conflict 只查「已登记
    # 的未裁决冲突」——检测没跑完/跑失败/从未检测时，冲突表里同样没有记录，会被误当成
    # 「无冲突」。这里要求本工作空间存在一次成功的全量检测（conflict_check 最新状态 ok）；
    # 无记录 / failed / partial / running 一律阻断，并给出可执行的一次性检测命令。
    # 开关 RULEPROOF_CONFLICT_GATE_REQUIRE_CHECK 默认 "1"；=0 回到旧行为（兼容回滚）。
    _conflict_check_gate = {"enabled": True, "ok": True, "status": "unknown",
                            "reason": "", "skipped_error": False}
    try:
        from . import conflict as _cf_gate
        _conflict_check_gate = _cf_gate.report_gate_status(case_id)
        if not _conflict_check_gate.get("ok"):
            _cc_reason = str(_conflict_check_gate.get("reason") or "").strip()
            if not _cc_reason:
                _cc_reason = ("冲突检测未完成，无法证明「无冲突」，正式报告已阻断；"
                              "请先执行一次全量冲突检测：`./rp conflict-check run`。")
            if not any(_cc_reason in x or x in _cc_reason for x in reasons):
                reasons.append(_cc_reason)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning("conflict check gate skipped", exc_info=True)
        _conflict_check_gate = {"enabled": True, "ok": True, "status": "skipped",
                                "reason": "", "skipped_error": True}
    _gate_flags = {name: int((_product_gate.get("gates") or {}).get(name) or 0)
                   for name in ("visible_unreviewed",
                                "unresolved_critical_conflict",
                                "incomplete_applicable_requirement",
                                "suppressed_risk_decision_missing")}
    # 展示项未复核：human_review.gate_check 已给出同义原因（双轨数据存在时）；
    # 这里只保证计数出现在 gates 中，不重复追加原因。
    if _gate_flags["visible_unreviewed"] and not any(
            "展示项未复核" in x for x in reasons):
        reasons.append(f"仍有 {_gate_flags['visible_unreviewed']} 条展示项未复核"
                       f"（visible_unreviewed={_gate_flags['visible_unreviewed']}）："
                       "展示项必须 100% 裁决")
    _gate_stats = {"flags": _gate_flags,
                   "manifest": {k: (_product_gate.get("manifest") or {}).get(k)
                                for k in ("count", "missing", "incomplete", "items",
                                          "results", "run_id", "manifest_id", "note")},
                   "detail": (lambda d: {
                       "unresolved_critical_conflict":
                           list((d or {}).get("unresolved_critical_conflict") or [])[:50],
                       "suppressed_risk_decision_missing":
                           list((d or {}).get("suppressed_risk_decision_missing") or [])[:50],
                   })(_product_gate.get("detail")),
                   "skipped_error": bool(_product_gate.get("skipped_error"))}

    _frz_stats = {"frozen_items": _frz.get("items"),
                  "frozen_results": _results, "frozen_na": _na,
                  "persisted_status": str((_frz.get("persisted") or {}).get("status") or "")}
    _votes_summary = dict(_stab.get("votes_summary") or {})
    _stab_stats = {"n": int(_stab.get("n") or 0),
                   "runs": int(_stab.get("runs_count") or 0),
                   "insufficient_runs": int(_stab.get("insufficient_runs") or 0),
                   "points": int(_stab.get("points") or 0),
                   "stable": bool(_stab.get("stable")),
                   "vote_recorded": bool(_stab.get("vote_recorded")),
                   "flips": len(_all_flips),
                   "key_flips": len(_key_flips),
                   "execution_blocked": len(_vote_blocked),
                   "planned_runs": int(_votes_summary.get("planned_runs") or 0),
                   "valid_votes": int(_votes_summary.get("valid_votes") or 0),
                   "invalid_votes": int(_votes_summary.get("invalid_votes") or 0),
                   "na_votes": int(_votes_summary.get("na_votes") or 0),
                   "execution_failed_votes": int(
                       _votes_summary.get("execution_failed_votes") or 0)}
    _acc_stats = {"accepted_bindings": int(_acc_union.get("accepted_bindings") or 0),
                  "accepted_keys": len(accepted_ids),
                  "rejected_batch": int(_acc_union.get("rejected_batch") or 0),
                  "rejected_invalid": int(_acc_union.get("rejected_invalid") or 0),
                  "non_waivable": int(_acc_union.get("non_waivable") or 0),
                  "pending_dual": len(_acc_union.get("pending_dual") or []),
                  "stale_hash": int(_acc_union.get("stale_hash") or 0),
                  "stale_run": int(_acc_union.get("stale_run") or 0),
                  "expired": int(_acc_union.get("expired") or 0),
                  "union_checked": bool(_union_checked),
                  "run_id": _acc_union.get("run_id") or ""}
    _ev_stats = {"checked": int(_evidence_gate.get("checked") or 0),
                 "verified": int(_evidence_gate.get("verified") or 0),
                 # 只读预演：若不修复，正式生成报告时会被降级的条数（门禁本身不改 DB）
                 "would_downgrade": len(_ev_preview),
                 # 历史已落库降级（need_evidence + 证据门禁标记）条数
                 "downgraded": len(_ev_blocked),
                 "downgraded_now": 0,
                 "preview_only": True,
                 "blocked": bool(_ev_preview or _ev_blocked)}
    _result = {"ok": not reasons, "reasons": reasons,
            # P0-4/P1-8：签发边界 fail-closed 状态（strid 开关 + 不可用部件 + 台账残缺）
            "gate_fail_closed": _gate_fail_closed,
            "ledger_incomplete": _ledger_incomplete,
            # T-50：V3.2 §15 四项门禁（计数 0=通过；gates 为唯一口径）
            "gates": _gate_flags,
            "stats": {**_frz_stats, "findings": len(fs), "pending": len(pending),
                      "critical": len(critical), "unknown": (0 if accepted_unknown else unknown),
                      "unknown_raw": unknown, "unknown_platform": len(_platform_unknown),
                      "compat_mode": _compat, "unknown_accepted_count": len(accepted_ids),
                      "parse_gaps_unaccepted": (0 if _compat else len(unaccepted)),
                      "parse_gaps_compat": (len(unaccepted) if _compat else 0),
                      "unknown_accepted": bool(accepted_unknown),
                      "unknown_exception": _acc_stats,
                      "gates": _gate_flags,
                      "gate_detail": _gate_stats,
                      "conflict_check": _conflict_check_gate,
                      "stability": _stab_stats, "evidence_gate": _ev_stats,
                      "version_snapshot": _vs_stats,
                      "human_review": dict(_human_loop.get("stats") or {},
                                           enabled=bool(_human_loop.get("enabled")),
                                           gate_ok=bool(_human_loop.get("ok")),
                                           code=str(_human_loop.get("code") or ""),
                                           fail_closed=bool(
                                               _human_loop.get("fail_closed")))
                      if _human_loop.get("enabled") else {"enabled": False},
                      "hidden_toggle": dict(_hidden_toggle),
                      # L52：唯一执行出口/兼容收紧/legacy-only 编排标注（只标不额外阻断）
                      "single_entry_fix": bool(_se_on),
                      "legacy_no_manifest_blocked": bool(_legacy_no_manifest),
                      "legacy_findings": int(_legacy_findings),
                      "legacy_findings_no_quote": int(_legacy_no_quote),
                      "legacy_clean_signable": bool(_legacy_clean_signable),
                      "legacy_orchestrator": bool(_legacy_orch),
                      # T-194 影子池：单列 N 提示（不阻断）、只读、不进通过率分母
                      "shadow_pool": dict(_shadow_pool,
                                          shadow_count=int((_shadow_pool.get("shadow") or {}).get("open") or 0),
                                          shadow_hint=_shadow_pool.get("hint")),
                      "shadow_count": int((_shadow_pool.get("shadow") or {}).get("open") or 0),
                      "shadow_hint": _shadow_pool.get("hint"),
                      "shadow_formal_findings": int(
                          (_shadow_pool.get("formal") or {}).get("findings") or 0)},
            "human_review": _human_loop,
            "hidden_toggle": dict(_hidden_toggle),
            # T-194 影子池报告口径（formal / shadow N / discarded / 分母不含 shadow）
            "shadow_pool": _shadow_pool,
            # T-164 / C-4：冲突检测状态（enabled=False 仅当开关=0 回滚口径）
            "conflict_check": _conflict_check_gate,
            "gate_detail": _gate_stats,
            "unknown_exception": {**_acc_stats,
                                  "details": list(_acc_union.get("details") or [])[:200]},
            "stability": {**_stab_stats, "flips_detail": _all_flips,
                          "votes_summary": _votes_summary,
                          "blocked_items": list(_vote_blocked)[:50],
                          "votes": list((_stab.get("items") or []))},
            "evidence_gate": {**_ev_stats,
                              "would_downgrade": len(_ev_preview),
                              "would_downgrade_items": list(_ev_preview),
                              "downgraded_items": list(_ev_blocked[:50])},
            "version_snapshot": _vs_stats}
    if _cert_gate:
        _cert_stats = {
            "enabled": bool(_cert_gate.get("enabled")),
            "required": bool(_cert_gate.get("required")),
            "mode": str(_cert_gate.get("mode") or ""),
            "ok": bool(_cert_gate.get("ok", True)),
            "coverage_rate": _cert_gate.get("coverage_rate"),
            "stats": dict(_cert_gate.get("stats") or {}),
            "blocked": len(_cert_gate.get("blocked") or []),
            "warnings": len(_cert_gate.get("warnings") or []),
            "reasons": len(_cert_gate.get("reasons") or []),
            "config_error": str(_cert_gate.get("config_error") or ""),
            "skipped_error": bool(_cert_gate.get("skipped_error")),
        }
    # 默认（KERNEL=0）不新增任何 key / stats → 与接入前逐字节一致（L72 B1 断言）。
    if _cert_gate:
        _result["certificate"] = _cert_gate
        _result["stats"]["certificate"] = _cert_stats
    # L77/L87：仅在审计写失败或审计状态不一致真正阻断时挂载（正常 run 输出与接入前
    # 逐字节一致）。error_code 取实际阻断码（L77=audit_write_failed；L87 状态门禁=
    # audit_state_failed / audit_state_inconsistent）。
    if _audit_hard.get("blocked"):
        _result["audit_hard_fail"] = dict(_audit_hard)
        _result["stats"]["audit_hard_fail"] = dict(_audit_hard)
        _result["error_code"] = str(_audit_hard.get("code")
                                    or AUDIT_WRITE_FAILED_CODE)
    # L93：报告签发事实（advisory）。仅当存在报告行时挂载 → 无报告行的输出与接入前
    # 逐字节一致（L72 E4 契约）；0 行事实由 docmodel_health_report 显式报告。
    try:
        _issuance = report_issuance_fact(case_id)
    except Exception as _exc:  # noqa: BLE001 —— 事实失败不阻断门禁
        _issuance = {"available": False, "signed": False, "advisory": True,
                     "error": f"{type(_exc).__name__}: {str(_exc)[:120]}"}
    if _issuance.get("available"):
        _result["report_issuance"] = _issuance
        _result["stats"]["report_issuance"] = {
            k: _issuance.get(k) for k in
            ("available", "report_id", "version", "status", "signed", "signed_by",
             "signed_at", "content_hash", "content_hash_verified", "advisory")}
    return _result
