"""RSI 评测协议：候选留痕、可回滚、可冻结、可算改进器增益。

对齐综述的三条要求：
1) 候选先经过验证，再决定「接受 / 回滚 / 归档」；
2) 改进器可以被冻结（消融对照）；
3) 改进器增益（I-gain）与任务增益分开度量。

候选状态机（本轮收口，避免「插入即 accepted」）：

    pending ──gate_publish 通过──> accepted ──> shadow 期 ──> promoted
       │                              │
       ├──gate_publish 真实违规──> blocked └──rollback──> rolled_back
       └──gate_publish 无法确证──> uncertain（旧版本不存在/不可读、回放样本不足）

``uncertain``（2026-11-23 LaneY，P2 B3）：门禁**无法确证**时的独立结论。旧实现里
规则版本型 revise 的候选快照只含 ruleparam 参数（不含版本内容）→ 恒被判
「沉淀物不可执行」而记 ``blocked``，但同一动作实际已发布新版本 v0.2，账面与真实
结果不一致。``blocked`` 现在只用于真实违反门禁（不可执行/互斥冲突/回放收益≤0）。

生产接线：
- ``record_candidate`` 是 ``feedback.settle`` / ``ontology_gate.record_patch`` 的落痕入口；
  插入永远从 ``pending`` 开始，随后**立即调用** ``gate_publish`` 做发布前置门禁
  （校验 + 回放），通过才接受，失败则 blocked；通过后进入影子期。
- ``frozen``/``rollback`` 是既有 HTTP 入口（冻结消融、回滚沉淀）。
"""
import json
import logging
import os

from .. import db
from .. import repositories as R

_LOG = logging.getLogger(__name__)

DECISION_PENDING = "pending"
DECISION_ACCEPTED = "accepted"
DECISION_BLOCKED = "blocked"
# B3（2026-11-23 LaneY）：门禁无法确证（旧版本不存在/不可读、回放样本不足），
# 与「真实违反门禁」的 blocked 必须分开，否则会出现「账面无通过、实际已发布」。
DECISION_UNCERTAIN = "uncertain"
DECISION_ROLLED_BACK = "rolled_back"

# 只有真正改动「规则行为/参数」的沉淀才需要回放样本门禁；
# 本体别名等结构性修订只做可执行性校验。
_REPLAY_ACTIONS = {"revise", "adjust_param", "adjust_behavior", "new_version",
                   "false_positive", "manual", "settle"}


def frozen() -> bool:
    """改进器冻结开关：用于「完整循环 vs 冻结改进器」的对照实验。"""
    if os.environ.get("RULEPROOF_RSI_FROZEN") == "1":
        return True
    try:
        from . import sysconfig
        return sysconfig.get("rsi.frozen", "0") == "1"
    except Exception:
        return False


def set_frozen(v: bool, by: str = "") -> dict:
    # F-28 服务层第二道角色校验：系统管理员/平台运营不得写审核业务。
    from . import permissions as _perms
    if _perms.actor_write_denied(by):
        return _perms.deny_write_payload("rsi.frozen")
    from . import sysconfig
    sysconfig.set_many({"rsi.frozen": "1" if v else "0"})
    R.audit_logs.log(actor=by or "system", action="rsi.frozen", after="1" if v else "0")
    return {"frozen": v}


def record_candidate(feedback_id: str, rule_code: str, action: str,
                     before: dict, after: dict, note: str = "", by: str = "",
                     candidate_type: str = "", parent_candidate_id: str = "",
                     holdout=None, holdout_slice: str = "") -> str:
    """候选落痕：先 pending，再走发布门禁，绝不「插入即 accepted」。

    返回值仍是候选 id（调用方兼容）；候选状态由 gate_publish 决定，
    可通过 ``candidate_state(cid)`` 读取。

    L117（2026-11-25）候选安全门①（生成阶段）：落痕前先过
    ``rsi_guard.generation_guard`` —— 候选只能改白名单规则行为层代码，禁止触碰
    权限/开关默认/DB schema/审计/证书/租户边界/产品库/发布门禁；越界候选落
    ``decision=blocked`` + ``evolution.blocked`` 审计，不进入发布门禁/影子期。
    通过时把最小谱系（来源/父候选/代数/holdout 标记/扫描摘要）写进 after 快照
    的 ``_lineage`` 段（审核字段，见 ``evolution.candidate_timeline``）。
    """
    cid = db.new_id("rc")
    try:
        from . import rsi_guard as _safety
        guard = _safety.generation_guard(
            cid, feedback_id=feedback_id, rule_code=rule_code, action=action,
            before=before or {}, after=after or {}, note=note or "",
            by=by or "system", candidate_type=candidate_type,
            parent_candidate_id=parent_candidate_id, holdout=holdout,
            holdout_slice=holdout_slice)
    except Exception:  # noqa: BLE001 - 安全门自身异常不得把候选吞成通过
        _LOG.warning("候选安全门（生成）异常 cid=%s", cid, exc_info=True)
        guard = {"ok": True, "blocked": False, "status": "error",
                 "after": after, "lineage": {},
                 "reason": "safety_gate_error"}
    _after = guard.get("after") if isinstance(guard.get("after"), dict) else after
    if guard.get("blocked"):
        R.rsi_candidates.insert(id=cid, feedback_id=feedback_id, rule_code=rule_code,
                                action=action,
                                before_json=json.dumps(before or {}, ensure_ascii=False),
                                after_json=json.dumps(_after or {}, ensure_ascii=False),
                                decision=DECISION_BLOCKED, note=(note or ""),
                                created_at=db.now(), decided_at=db.now(),
                                decided_by=str(by or "safety-gate")[:80])
        _mark(cid, DECISION_BLOCKED, by or "safety-gate",
              "L117 候选安全门阻断（生成）："
              + "；".join(v.get("detail") or "" for v in (guard.get("violations") or [])[:3]))
        return cid
    R.rsi_candidates.insert(id=cid, feedback_id=feedback_id, rule_code=rule_code, action=action,
                            before_json=json.dumps(before or {}, ensure_ascii=False),
                            after_json=json.dumps(_after or {}, ensure_ascii=False),
                            decision=DECISION_PENDING, note=note or "",
                            created_at=db.now(), decided_at="", decided_by="")
    # 生产调用：候选生成即走发布门禁（校验 + 回放），通过才 accepted，失败 blocked。
    try:
        gate = gate_publish(cid, by=by or "system")
    except Exception:  # noqa: BLE001 - 门禁异常不能把候选吞成 accepted
        _LOG.debug("RSI 候选发布门禁失败 cid=%s", cid, exc_info=True)
        gate = {"ok": False, "decision": DECISION_PENDING, "reason": "gate_error"}
    # 通过门禁的「规则」改动进入影子期：先影子观察，再人工转正。
    # 本体别名等结构性修订不是规则执行体，不能占用规则影子期。
    try:
        _is_rule_change = bool(gate.get("ok")) and not str(action or "").startswith("ontology.") \
            and not str(rule_code or "").startswith("ONTO:")
        if _is_rule_change:
            from . import rsi_guard as _guard
            _guard.shadow_start(rule_code, cid, actor=by or "system")
    except Exception:  # noqa: BLE001
        _LOG.debug("RSI 影子期启动失败 rule=%s", rule_code, exc_info=True)
    return cid


def candidate_state(candidate_id: str) -> dict:
    row = R.rsi_candidates.get(candidate_id) or {}
    if not row:
        return {}
    return {"id": row.get("id"), "rule_code": row.get("rule_code"),
            "action": row.get("action"), "decision": row.get("decision") or "",
            "note": row.get("note") or "", "decided_at": row.get("decided_at") or "",
            "decided_by": row.get("decided_by") or ""}


def _mark(candidate_id: str, decision: str, by: str = "", extra_note: str = "") -> None:
    row = R.rsi_candidates.get(candidate_id) or {}
    note = str(row.get("note") or "")
    if extra_note and extra_note not in note:
        note = (note + " | " + extra_note).strip(" |")
    try:
        R.rsi_candidates.update(candidate_id, decision=decision, note=note,
                                decided_at=db.now(), decided_by=by or "system")
    except Exception:  # noqa: BLE001
        _LOG.debug("RSI 候选状态更新失败 cid=%s", candidate_id, exc_info=True)


def _with_policy(out: dict, note) -> dict:
    """L73：把 Policy Compiler advisory 明细挂到 RSI 返回值（开关关时 note=None → 逐字节旧输出）。"""
    if note:
        out["policy"] = note
    return out


def _candidate_before_snapshot(row: dict) -> dict:
    try:
        before = json.loads((row or {}).get("before_json") or "{}")
    except (TypeError, ValueError):
        before = {}
    return before if isinstance(before, dict) else {}


def _rollback_rule_version(before: dict, rule_code: str, by: str) -> dict:
    """L131：规则版本型候选回滚到 before 的生效版本内容（追加新版本，历史不删）。

    生效口径：rule.current_version_id 且 status=published。回滚=把旧版本内容
    重新走「edit→publish」生命周期发布成新版本（版本历史/旧版本行全部保留可恢复），
    若当前生效内容已等于 before（候选未真正上线），则不改版本、只记 noop。
    """
    version = before.get("version") if isinstance(before.get("version"), dict) else {}
    eff = version.get("effective") if isinstance(version.get("effective"), dict) else {}
    target = eff.get("slots") if isinstance(eff.get("slots"), dict) else None
    if not target:
        return {"kind": "rule_version", "skipped": True,
                "reason": "before 快照无可恢复的生效版本内容"}
    live = version_snapshot(rule_code)
    live_eff = (live.get("effective") or {}) if isinstance(live, dict) else {}
    live_slots = live_eff.get("slots") if isinstance(live_eff.get("slots"), dict) else {}
    if live_slots == target:
        return {"kind": "rule_version", "noop": True,
                "effective_version": str(live_eff.get("version") or ""),
                "reason": "当前生效版本内容已等于候选 before（候选未上线，无需改版本）"}
    rid = str((live or {}).get("rule_id") or "")
    if not rid:
        try:
            for r in R.rules.list("code=?", (str(rule_code or ""),)):
                rid = str(r.get("id") or "")
                if rid:
                    break
        except Exception:  # noqa: BLE001
            rid = ""
    if not rid:
        return {"kind": "rule_version", "error": "规则不存在，无法恢复旧版本内容"}
    from . import rule as _rule
    upd = _rule.update_slots(rid, dict(target), actor=by or "system")
    if upd.get("error"):
        return {"kind": "rule_version",
                "error": "恢复旧版本内容失败：%s"
                         % (upd.get("message") or upd.get("error"))}
    pub = _rule.publish(rid, actor=by or "system")
    if pub.get("error"):
        return {"kind": "rule_version",
                "error": "回滚发布旧版本内容失败：%s"
                         % (pub.get("message") or pub.get("error"))}
    after = version_snapshot(rule_code)
    after_eff = (after.get("effective") or {}) if isinstance(after, dict) else {}
    after_slots = after_eff.get("slots") if isinstance(after_eff.get("slots"), dict) else {}
    return {"kind": "rule_version", "restored": after_slots == target,
            "previous_version": str(eff.get("version") or ""),
            "effective_version": str(after_eff.get("version") or ""),
            "effective_version_id": str(after_eff.get("id") or ""),
            "note": "旧版本内容已作为新版本重新发布；历史版本行全部保留可恢复"}


def _ontology_overrides_raw() -> dict:
    """读本体别名 override 原始数据（仅经 T-200 门面；不直接 import 内部模块）。"""
    from . import ontology_service as _onto
    return _onto.gate_overrides_raw()


def _rollback_ontology(before: dict, rule_code: str, by: str) -> dict:
    """L131：本体别名候选回滚到 before 的别名集合（保留其它实体别名）。"""
    code = str(rule_code or "")
    canonical = str(before.get("canonical") or "").strip()
    if not canonical and "ONTO:" in code:
        canonical = code.split("ONTO:", 1)[1].strip()
    if not canonical:
        return {"kind": "ontology", "error": "缺少本体标准名（canonical），无法回滚"}
    desired = [str(x) for x in (before.get("aliases") or []) if str(x).strip()]
    from . import ontology_service as _onto
    data = _ontology_overrides_raw()
    current = [str(x) for x in (data.get(canonical) or []) if str(x).strip()]
    try:
        _onto.restore_gate_aliases(canonical, desired)
    except Exception as e:  # noqa: BLE001
        return {"kind": "ontology", "error": "本体别名恢复失败：%s" % type(e).__name__}
    now = [str(x) for x in (_ontology_overrides_raw().get(canonical) or []) if str(x).strip()]
    return {"kind": "ontology", "restored": now == desired,
            "canonical": canonical, "aliases": now,
            "added_removed": [x for x in current if x not in desired],
            "removed_restored": [x for x in desired if x not in current]}


def _rollback_params(before: dict, rule_code: str, by: str) -> dict:
    """运行参数/行为回滚（内置参数型规则；与既有 rsi.rollback 语义一致）。"""
    from . import ruleparam
    rc = str(rule_code or "")
    restored = {"kind": "rule_param", "rule_code": rc}
    try:
        if not before.get("params"):
            ruleparam.reset(rc, by or "system")     # 原本没有覆盖 → 删除覆盖行
        else:
            ruleparam.update(rc, **before["params"])
        if before.get("behavior") and before.get("params"):
            ruleparam.set_behavior(rc, **before["behavior"])
        if before.get("params"):
            ruleparam.publish(rc, by or "system")
    except Exception as e:  # noqa: BLE001
        return {"kind": "rule_param", "error": f"回滚失败：{type(e).__name__}"}
    restored["params"] = snapshot(rc)
    return restored


def rollback(candidate_id: str, by: str = "") -> dict:
    """回滚一次沉淀（L131 增强：规则版本 / 本体别名 / 运行参数，事务+审计+幂等）。

    - 幂等：已回滚候选再次调用返回 ``ok=True, idempotent=True``（不再报错）；
    - 规则版本型候选：把 before 的生效版本内容重新走编辑→发布生命周期恢复
      （追加新版本，**旧版本行/旧内容全部保留可恢复**）；候选未上线时只记 noop；
    - 本体别名候选：把别名集合恢复到 before（保留其它实体别名）；
    - 内置参数/行为候选：恢复 params/behavior（既有语义）；
    - 候选状态与 ``rsi.rollback``/``evolution.rollback`` 审计在同一事务（log_in_tx）；
    - 权限：业务写拒绝角色（super_admin/platform_op）403。
    """
    from . import permissions as _perms
    if _perms.actor_write_denied(by):
        return _perms.deny_write_payload("rsi.rollback")
    cid = str(candidate_id or "")
    row = R.rsi_candidates.get(cid)
    if not row:
        return {"error": "候选不存在"}
    if str(row.get("decision") or "") == DECISION_ROLLED_BACK:
        return {"ok": True, "candidate_id": cid, "idempotent": True,
                "decision": DECISION_ROLLED_BACK,
                "note": "候选已是 rolled_back：按幂等返回（不重复恢复/不重复审计）"}
    before = _candidate_before_snapshot(row)
    action = str(row.get("action") or "")
    rc = str(row.get("rule_code") or "")
    _version = before.get("version") if isinstance(before.get("version"), dict) else {}
    _eff = _version.get("effective") if isinstance(_version.get("effective"), dict) else {}
    if action.startswith("ontology.") or rc.startswith("ONTO:"):
        restore = _rollback_ontology(before, rc, by)
    elif isinstance(_eff.get("slots"), dict) and _eff.get("slots"):
        restore = _rollback_rule_version(before, rc, by)
    else:
        restore = _rollback_params(before, rc, by)
    if restore.get("error"):
        restore.update({"ok": False, "candidate_id": cid, "restored": False,
                        "error": restore.get("error")})
        R.audit_logs.log(actor=by or "system", action="evolution.rollback",
                         object=cid,
                         after=json.dumps({"ok": False, "reason": restore.get("error"),
                                           "kind": restore.get("kind"),
                                           "policy_version": "l131.evolution_guard/v1"},
                                          ensure_ascii=False)[:2000])
        return restore
    if restore.get("restored") is False:
        # 恢复结果与目标不一致 → 不落 rolled_back（不伪造回滚成功）
        return {"ok": False, "candidate_id": cid, "restored": False,
                "reason": "回滚后复核未恢复目标内容，候选状态未改", "detail": restore}
    detail = {"candidate_id": cid, "decision": DECISION_ROLLED_BACK,
              "restored": True, "kind": restore.get("kind"),
              "rule_code": rc, "action": action,
              "detail": {k: restore.get(k) for k in
                         ("effective_version", "previous_version", "noop",
                          "canonical", "aliases", "added_removed",
                          "removed_restored", "skipped", "note")},
              "policy_version": "l131.evolution_guard/v1"}
    # ---- 候选状态 + 两条审计同一事务（log_in_tx 失败整体回滚，不出现「状态已变审计缺失」）----
    from . import audit as _audit
    try:
        with db.session() as c:
            cur = c.execute(
                "UPDATE rsi_candidate SET decision=?, decided_at=?, decided_by=? "
                "WHERE id=? AND COALESCE(decision,'')<>?",
                (DECISION_ROLLED_BACK, db.now(), str(by or "system")[:80], cid,
                 DECISION_ROLLED_BACK))
            if cur.rowcount == 0:
                c.rollback()
                return {"ok": True, "candidate_id": cid, "idempotent": True,
                        "decision": DECISION_ROLLED_BACK,
                        "note": "并发/重复回滚：候选已是 rolled_back"}
            _audit.log_in_tx(c, actor=by or "system", action="rsi.rollback",
                             object_=cid,
                             after=json.dumps(detail, ensure_ascii=False)[:2000])
            _audit.log_in_tx(c, actor=by or "system", action="evolution.rollback",
                             object_=cid,
                             after=json.dumps(detail, ensure_ascii=False)[:2000])
    except Exception as e:  # noqa: BLE001 - 事务失败不得谎报回滚成功
        _LOG.warning("RSI 回滚事务失败 cid=%s", cid, exc_info=True)
        return {"ok": False, "candidate_id": cid, "error": f"回滚事务失败：{type(e).__name__}"}
    return {"ok": True, "candidate_id": cid, "decision": DECISION_ROLLED_BACK,
            "restored": True, "idempotent": False,
            "rollback": restore, "audit_action": "evolution.rollback",
            "note": "已回滚到候选 before 快照；旧版本/旧别名保留可恢复"}


# ---------------------------------------------------------------------------
# L131（2026-11-25）自进化上线闸口：人工审批 / 拒绝 / 审批状态
#
# 生产接线：
#   - POST /api/v1/evolution/rules/<candidate_id>/hitl-approve
#   - POST /api/v1/evolution/rules/<candidate_id>/hitl-reject
#   - GET  /api/v1/evolution/rules/<candidate_id>/hitl-status
#   （app/services/evolution.py::handle_http 分发；服务层第二道管理员校验）
#   - rsi_guard.shadow_finish(promoted) → rsi_guard.promotion_guard 会**拒绝**
#     没有审批证据的自动转正（写 evolution.hitl_required 审计）。
# 回退：RULEPROOF_EVOLUTION_HITL_GOLDEN=0 → 全部 no-op（旧 gate/shadow 行为）。
# ---------------------------------------------------------------------------
def _hitl_view_allowed(user) -> bool:
    """审批状态只读权限：与 evolution 的 evo.view 同口径。"""
    if user is None:
        return True
    try:
        from . import evolution as _evo
        return bool(_evo.user_can_view(user))
    except Exception:  # noqa: BLE001
        role = str((user or {}).get("role") or "")
        return role in ("admin", "super_admin", "reviewer")


def approve_candidate(candidate_id: str, by: str = "", user=None,
                      note: str = "", golden=None,
                      ack_insufficient_evidence: bool = False) -> dict:
    """人工审批候选（管理员动作）：污染复检 + 黄金集全量回归 + 审批证据落库。

    审批参数（均为管理员显式动作）：
    - ``golden``：本次指定的黄金集（dict/list）；缺省读已登记黄金集
      （``set_golden_set``，带租户/空间隔离）。候选自带黄金集不作为自证证据；
    - ``ack_insufficient_evidence``：无黄金集/不可评估/作用域隔离时，管理员
      显式承担风险的确认（缺省 False → 拒绝默认放行）。
    返回 ok/approved/code/reason/approval/golden；非管理员 403；黄金集退化 409 阻断。
    """
    from . import rsi_guard as _guard
    if not _guard.hitl_enabled():
        return {"ok": True, "status": "disabled", "hitl": "disabled",
                "approved": False, "candidate_id": str(candidate_id or ""),
                "note": "RULEPROOF_EVOLUTION_HITL_GOLDEN=0：按旧 gate/shadow 行为，无需审批"}
    actor = _guard.hitl_actor_check(by, user)
    if not actor.get("ok"):
        return {"ok": False, "status": actor.get("status") or 403,
                "code": actor.get("code") or "forbidden",
                "error": actor.get("error") or "无权限审批",
                "hitl": "approval_denied", "candidate_id": str(candidate_id or "")}
    out = _guard.record_approval(str(candidate_id or ""),
                                 by=actor.get("actor") or by,
                                 user={"role": actor.get("role") or "admin"},
                                 note=note, golden=golden,
                                 ack_insufficient_evidence=ack_insufficient_evidence)
    out.setdefault("candidate_id", str(candidate_id or ""))
    out["hitl"] = "approved" if out.get("approved") else (
        "blocked" if out.get("blocked") else "rejected")
    if out.get("approved"):
        out.setdefault("audit_action", _guard.HITL_ACTION_APPROVED)
    return out


def reject_candidate(candidate_id: str, by: str = "", user=None,
                     reason: str = "") -> dict:
    """人工拒绝候选（管理员动作）；后续上线必须重新审批（写 evolution.hitl_rejected）。"""
    from . import rsi_guard as _guard
    if not _guard.hitl_enabled():
        return {"ok": True, "status": "disabled", "hitl": "disabled",
                "candidate_id": str(candidate_id or ""),
                "note": "RULEPROOF_EVOLUTION_HITL_GOLDEN=0：按旧行为，无需人工拒绝"}
    actor = _guard.hitl_actor_check(by, user)
    if not actor.get("ok"):
        return {"ok": False, "status": actor.get("status") or 403,
                "code": actor.get("code") or "forbidden",
                "error": actor.get("error") or "无权限拒绝",
                "hitl": "reject_denied", "candidate_id": str(candidate_id or "")}
    return _guard.record_rejection(str(candidate_id or ""),
                                   by=actor.get("actor") or by,
                                   user={"role": actor.get("role") or "admin"},
                                   reason=reason)


def hitl_status(candidate_id: str, user=None, deep: bool = False) -> dict:
    """候选审批/黄金集/污染只读状态（GET 入口；evo.view 权限）。"""
    if not _hitl_view_allowed(user):
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "无权限查看候选审批状态（需要 evo.view）"}
    from . import rsi_guard as _guard
    out = _guard.hitl_status(str(candidate_id or ""), deep=bool(deep))
    out["candidate_id"] = str(candidate_id or "")
    return out


def rollback_evolution_candidate(candidate_id: str, by: str = "", user=None) -> dict:
    """一键回滚入口（HTTP 服务层）：管理员动作 + 业务写角色校验 + rollback()。"""
    if user is not None:
        role = str((user or {}).get("role") or "")
        from . import permissions as _perms
        if role and _perms.write_denied(role):
            return _perms.deny_write_payload("rsi.rollback")
        if role and role != "admin":
            try:
                from . import evolution as _evo
                if not _evo.user_can_manage(user):
                    return {"ok": False, "status": 403, "code": "forbidden",
                            "error": "一键回滚需要 evo.manage（业务管理员）"}
            except Exception:  # noqa: BLE001
                return {"ok": False, "status": 403, "code": "forbidden",
                        "error": "一键回滚需要 evo.manage（业务管理员）"}
    out = rollback(str(candidate_id or ""), by or "")
    return out


def snapshot(rule_code: str) -> dict:
    from . import ruleparam
    return {"params": ruleparam.get(rule_code) or {},
            "pending": ruleparam.pending(rule_code) or {},
            "behavior": ruleparam.behavior(rule_code)}


def _brief_version(row: dict) -> dict:
    """单个规则版本的紧凑快照：带 slots 内容；解析失败显式记 error（不伪造空内容）。"""
    row = row or {}
    slots, err = None, ""
    try:
        parsed = json.loads(row.get("slots_json") or "{}")
    except Exception as e:  # noqa: BLE001 - 解析失败是「不可读」，不是违规
        parsed, err = None, f"slots_json 解析失败：{type(e).__name__}"
    if isinstance(parsed, dict):
        slots = parsed
    elif not err:
        err = "slots_json 不是对象"
    return {"id": str(row.get("id") or ""), "version": str(row.get("version") or ""),
            "status": str(row.get("status") or ""), "slots": slots, "error": err}


def version_snapshot(rule_code: str) -> dict:
    """规则版本内容快照（B3）：版本型规则 revise 的候选门禁唯一真实依据。

    旧实现的候选 before/after 只含 ``ruleparam`` 参数/行为，不含规则版本内容：
    ``feedback.settle(action=revise)`` 实际 fork 并（可能）发布新版本后，
    ``validate_candidate`` 看到的仍是空沉淀物 → 候选恒 ``blocked``，而版本已真实
    发布。现在候选快照带本段，门禁即可对「候选 → 版本内容」做真实评估。

    返回：
      exists     规则库是否存在该 code（False = 内置参数型/本体等非版本型规则）
      readable   是否存在**可读**的版本内容（版本行存在且 slots_json 可解析）
      latest     最新版本（rowid 末条）{id,version,status,slots,error}
      effective  当前生效（published）版本，同结构；无 published 版本时为 None
      versions   最近 6 个版本 {id,version,status}（候选→发布→有效版本可追）
      reason     不存在/不可读的机器可读原因（uncertain 时必须落到 note/审计）
    """
    code = str(rule_code or "").strip()
    if not code:
        return {"exists": False, "readable": False, "reason": "未关联规则码"}
    try:
        rows = R.rules.list("code=?", (code,))
    except Exception as e:  # noqa: BLE001 - 读取失败按不可读处理，不能当成违规
        _LOG.warning("规则版本快照：规则读取失败 rule=%s", code, exc_info=True)
        return {"exists": False, "readable": False,
                "reason": f"规则读取失败：{type(e).__name__}"}
    if not rows:
        return {"exists": False, "readable": False,
                "reason": "规则不存在（内置参数型或无规则行）"}
    rule = rows[0]
    rid = str(rule.get("id") or "")
    try:
        vers = R.rule_versions.list("rule_id=?", (rid,))
    except Exception as e:  # noqa: BLE001
        _LOG.warning("规则版本快照：版本读取失败 rule=%s", code, exc_info=True)
        return {"exists": True, "readable": False, "rule_id": rid,
                "rule_status": str(rule.get("status") or ""),
                "reason": f"版本读取失败：{type(e).__name__}"}
    if not vers:
        return {"exists": True, "readable": False, "rule_id": rid,
                "rule_status": str(rule.get("status") or ""),
                "reason": "旧版本不存在（规则无版本行）"}
    latest = _brief_version(vers[-1])
    eff_row = None
    try:
        eff_row = R.rules.published_version(rid)
    except Exception:  # noqa: BLE001 - 退回按 status 找 published 行
        eff_row = None
    if not eff_row:
        for v in reversed(vers):
            if str(v.get("status") or "") == "published":
                eff_row = v
                break
    effective = _brief_version(eff_row) if eff_row else None
    readable = bool((latest.get("slots") is not None)
                    or (isinstance(effective, dict) and effective.get("slots") is not None))
    out = {"exists": True, "rule_id": rid,
           "rule_status": str(rule.get("status") or ""),
           "readable": readable, "latest": latest, "effective": effective,
           "versions": [{"id": str(v.get("id") or ""), "version": str(v.get("version") or ""),
                         "status": str(v.get("status") or "")} for v in vers[-6:]],
           "reason": "" if readable else "旧版本内容不可读（slots_json 非法）"}
    return out


def gate_snapshot(rule_code: str) -> dict:
    """门禁快照 = 运行参数/行为快照 + 规则版本内容快照（B3 修复点）。

    ``feedback.settle`` / 崩溃恢复写候选 before/after 时应使用本函数：版本型规则的
    revise 候选因此自带「被修订的旧版本内容 + 新版本内容」，候选→发布→有效版本
    同一条记录可追，门禁也不再因快照缺内容而误判 blocked。
    内置参数型规则（无规则行）时 ``version.exists=False``，行为与旧快照一致。
    """
    snap = snapshot(rule_code)
    try:
        snap["version"] = version_snapshot(rule_code)
    except Exception as e:  # noqa: BLE001 - 快照异常不得把候选吞成通过/违规
        _LOG.warning("门禁版本快照失败 rule=%s", rule_code, exc_info=True)
        snap["version"] = {"exists": False, "readable": False,
                           "reason": f"版本快照读取失败：{type(e).__name__}"}
    return snap


def _snapshot_version_content(version_snap: dict) -> tuple:
    """从版本快照段取门禁评估内容：优先 latest（候选新版本），其次 effective
    （旧生效版本 = 被 revise 的旧版本内容）。返回 (content_slots, meta)。"""
    for label in ("latest", "effective"):
        row = (version_snap or {}).get(label) or {}
        slots = row.get("slots") if isinstance(row, dict) else None
        if isinstance(slots, dict) and slots:
            return slots, {"source": label,
                           "version": str(row.get("version") or ""),
                           "version_id": str(row.get("id") or ""),
                           "status": str(row.get("status") or "")}
    return {}, {}


def _gate_version_context(rule_code: str, after: dict, before: dict) -> dict:
    """解析 revise 候选门禁所需的版本内容上下文（B3）。

    优先级：候选 after 快照 → 候选 before 快照（**旧版本内容**）→ 现读规则库。
    - ``is_version_rule=True`` 且 ``has_content=True``：可真实评估；
    - ``is_version_rule=True`` 且 ``has_content=False``：旧版本不存在/不可读，
      门禁**无法确证** → 调用方必须返回 ``uncertain`` 并记录 reason，不能记 blocked；
    - ``is_version_rule=False``：非版本型规则（内置参数型/本体），保持旧逻辑。
    """
    is_version_rule = False
    fallback = ""
    for label, snap in (("candidate_after", after), ("candidate_before", before)):
        vs = (snap or {}).get("version") if isinstance(snap, dict) else None
        if not isinstance(vs, dict):
            continue
        if vs.get("exists") or vs.get("readable"):
            is_version_rule = is_version_rule or bool(vs.get("exists", True))
            if vs.get("readable"):
                content, meta = _snapshot_version_content(vs)
                if content:
                    return {"is_version_rule": True, "readable": True, "has_content": True,
                            "content": content,
                            "source": f"{label}:{meta.get('source') or ''}",
                            "version": str(meta.get("version") or ""),
                            "effective_version": str(
                                ((vs.get("effective") or {}) or {}).get("version") or ""),
                            "reason": ""}
            fallback = fallback or str(vs.get("reason") or "版本快照不可读")
    live = version_snapshot(rule_code)
    is_version_rule = is_version_rule or bool(live.get("exists"))
    if live.get("readable"):
        content, meta = _snapshot_version_content(live)
        if content:
            return {"is_version_rule": True, "readable": True, "has_content": True,
                    "content": content,
                    "source": "live_rule:" + str(meta.get("source") or ""),
                    "version": str(meta.get("version") or ""),
                    "effective_version": str(
                        ((live.get("effective") or {}) or {}).get("version") or ""),
                    "reason": ""}
    if is_version_rule:
        return {"is_version_rule": True, "readable": False, "has_content": False,
                "content": {}, "source": "none", "version": "",
                "effective_version": str(
                    ((live.get("effective") or {}) or {}).get("version") or ""),
                "reason": (fallback or str(live.get("reason") or "")
                           or "版本内容为空，无法用作门禁依据")}
    return {"is_version_rule": False, "readable": False, "has_content": False, "content": {},
            "source": "none", "version": "", "effective_version": "", "reason": ""}


def _version_ctx_brief(vctx: dict) -> dict:
    """门禁版本上下文的可落库/可返回摘要（不含整段 slots，避免 payload 膨胀）。"""
    return {k: (vctx or {}).get(k) for k in
            ("is_version_rule", "readable", "has_content", "source", "version",
             "effective_version", "reason")}



def igain(rule_code: str) -> dict:
    """改进器增益：该规则沉淀前后的反向反馈率变化（I-gain，不是任务增益）。"""
    rows = [x for x in R.feedback.list() if (x.get("rule_code") or "") == rule_code]
    if not rows:
        # 无样本 ≠ 零收益：显式 N/A，避免被读成“改进为 0”
        return {"rule_code": rule_code, "samples": 0, "igain": None,
                "display": "N/A", "note": "无反馈样本"}
    acc = [x for x in R.rsi_candidates.list("rule_code=?", (rule_code,))
           if (x.get("decision") or "") == DECISION_ACCEPTED]
    if not acc:
        return {"rule_code": rule_code, "samples": len(rows), "igain": None,
                "display": "N/A", "note": "尚未沉淀（无 accepted 候选），无改进器增益可算"}
    cut = min(x.get("created_at") or "" for x in acc)
    before = [x for x in rows if (x.get("created_at") or "") < cut]
    after = [x for x in rows if (x.get("created_at") or "") >= cut]
    rate = lambda xs: (sum(1 for x in xs if x.get("kind") == "false_positive") / len(xs)) if xs else None
    rb, ra = rate(before), rate(after)
    return {"rule_code": rule_code, "before_n": len(before), "after_n": len(after),
            "reverse_rate_before": rb, "reverse_rate_after": ra,
            "igain": (round(rb - ra, 4) if rb is not None and ra is not None else None)}


def list_candidates(rule_code: str = "") -> list:
    rows = R.rsi_candidates.list("rule_code=?", (rule_code,)) if rule_code else R.rsi_candidates.list()
    out = []
    for x in rows:
        out.append({"id": x["id"], "feedback_id": x.get("feedback_id"), "rule_code": x.get("rule_code"),
                    "action": x.get("action"), "decision": x.get("decision"),
                    "before": json.loads(x.get("before_json") or "{}"),
                    "after": json.loads(x.get("after_json") or "{}"),
                    "created_at": x.get("created_at"), "note": x.get("note")})
    return out


# ---------------- 自进化治理（同本体方法：校验 → 门禁 → 契约 → 生效追踪）----------------
def _has_numeric(params: dict) -> bool:
    """参数快照是否含可执行阈值：支持 value / range(lo,hi) / enum 三种形态。"""
    p = params or {}
    if not p:
        return False
    if p.get("value") not in (None, "", []):
        return True
    return p.get("lo") is not None and p.get("hi") is not None


def validate_candidate(rule_code: str, after: dict, action: str = "") -> dict:
    """候选校验：沉淀物必须可执行，且不能与现有规则互斥。

    支持四种沉淀形态（此前只有 slots 形态，导致参数/行为/本体沉淀永远“不可执行”）：
    - slots：数值判据（metric/op/value）或语义判据（criterion 至少 4 个汉字）；
    - params/pending：内置规则阈值修订（metric/op/value、range、enum）；
    - behavior：行为参数修订（enabled/severity/ignore_keywords/scope_types）；
    - aliases：本体别名修订（非空别名列表）。
    """
    errs, warns = [], []
    after = after or {}
    slots = after.get("slots") or {}
    has_numeric = all(slots.get(k) not in (None, "") for k in ("metric", "op", "value")) \
        or _has_numeric(slots)
    import re as _re
    _crit = (slots.get("criterion") or "").strip()
    # 至少 4 个汉字：既能挡住「」「。」这类空判据，又不误伤「日期不一致」这类正常规则名
    has_criterion = len(_re.findall(r"[\u4e00-\u9fa5]", _crit)) >= 4
    has_params = _has_numeric(after.get("params") or {}) or _has_numeric(after.get("pending") or {})
    _pending = after.get("pending") or {}
    _beh = after.get("behavior") or {}
    has_behavior = bool(
        _beh.get("enabled") is False or str(_beh.get("severity") or "").strip()
        or _beh.get("ignore_keywords") or _beh.get("scope_types")
        or _pending.get("enabled") is False or str(_pending.get("severity") or "").strip()
        or _pending.get("ignore_keywords") or _pending.get("scope_types"))
    _aliases = [str(x).strip() for x in (after.get("aliases") or []) if str(x).strip()]
    has_alias = bool(_aliases)
    if not (has_numeric or has_criterion or has_params or has_behavior or has_alias):
        errs.append("沉淀物不可执行：即无 metric/op/value、criterion，也无 params/behavior/aliases")
    if not (slots.get("point_id") or after.get("point_id")):
        warns.append("未映射到审核点类型，可能永不执行")
    # 冲突：同 rule_code 的现有版本
    try:
        from . import conflict as _cf
        exists = [r for r in R.rules.list("code=?", (rule_code,))]
        if exists:
            c = _cf.check(rule_code, slots) if hasattr(_cf, "check") else {}
            if c.get("kind") == "互斥冲突":
                errs.append(f"与现有规则互斥：{c.get('detail') or ''}")
    except Exception:  # noqa: BLE001
        _LOG.debug("候选冲突校验跳过 rule=%s", rule_code, exc_info=True)
    return {"ok": not errs, "errors": errs, "warnings": warns}


def _replay_gate(rule_code: str) -> dict:
    """回放门禁：必须有可用的标注样本，且回放收益 > 0，才允许发布。

    样本/收益统一走 calibration（租户/空间口径），不再用裸 SQL 读全库，
    避免跨租户样本把门禁放行。
    """
    try:
        from . import calibration as _cal
        res = _cal.replay_igain(rule_code) if hasattr(_cal, "replay_igain") else {"samples": 0, "igain": None}
    except Exception as e:  # noqa: BLE001
        _LOG.debug("回放门禁读取失败 rule=%s: %s", rule_code, e)
        return {"ok": False, "reason": f"回放门禁不可用：{type(e).__name__}", "samples": 0}
    samples = int(res.get("samples") or 0)
    need = int(os.environ.get("RULEPROOF_REPLAY_MIN", "10") or 0)
    if samples < need:
        return {"ok": False, "reason": f"回放样本不足（{samples}/{need}），不允许发布",
                "samples": samples, "need": need}
    if res.get("igain") is not None and res["igain"] <= 0:
        return {"ok": False, "reason": f"回放未带来收益 igain={res['igain']}",
                "samples": samples, "igain": res.get("igain")}
    return {"ok": True, "samples": samples, "igain": res.get("igain"),
            "accuracy": res.get("acc")}


def gate_publish(candidate_id: str, by: str = "", force: bool = False) -> dict:
    """发布门禁（候选发布前置）：校验 → 回放 → accepted / blocked / uncertain。

    生产接线：``record_candidate`` 每次都会调用本函数；已决候选默认幂等返回。
    新规则候选（action=new_rule）尚未发布，保持 pending，等人工审批发布。

    2026-11-23 LaneY（P2 B3）：规则版本型 ``revise`` 的候选 before/after 快照带
    ``version`` 段（规则版本内容，见 ``gate_snapshot``），门禁用它做真实评估。
    三态口径：
    - ``accepted``（= allowed）：版本内容可执行 + 回放门禁通过（或无需回放）；
    - ``blocked``：**真实违反门禁**（沉淀物不可执行 / 互斥冲突 / 回放收益≤0）；
    - ``uncertain``：门禁**无法确证**——旧版本不存在/不可读，或回放样本不足；
      不再把「无法评估」记成 blocked（旧行为：恒 blocked 但版本实际已发布）。
    """
    row = R.rsi_candidates.get(candidate_id)
    if not row:
        return {"ok": False, "decision": "", "reason": "候选不存在"}
    decision = str(row.get("decision") or "")
    if decision in (DECISION_ACCEPTED, DECISION_BLOCKED, DECISION_UNCERTAIN,
                    DECISION_ROLLED_BACK) and not force:
        return {"ok": decision == DECISION_ACCEPTED, "decision": decision,
                "reason": "候选已决，幂等返回", "candidate_id": candidate_id}
    # ---- L117 候选安全门②（审核阶段）：重扫已落库快照 + 校验生成阶段扫描摘要 ----
    # 防止「登记后/审核前」候选内容被篡改，或绕过生成入口直接插入的越界候选。
    try:
        from . import rsi_guard as _safety
        rguard = _safety.review_guard(candidate_id, row=row, by=by or "system")
    except Exception:  # noqa: BLE001 - 安全门自身异常不得把候选吞成通过
        _LOG.warning("候选安全门（审核）异常 cid=%s", candidate_id, exc_info=True)
        rguard = {"ok": True, "blocked": False, "status": "error"}
    if rguard.get("blocked"):
        _safety.mark_candidate_blocked(candidate_id, rguard.get("reason") or "",
                                       by or "safety-gate")
        return {"ok": False, "decision": DECISION_BLOCKED,
                "candidate_id": candidate_id,
                "reason": rguard.get("reason") or "候选安全门（审核）阻断",
                "violations": rguard.get("violations") or [],
                "audit_action": "evolution.blocked", "safety": {
                    "stage": "review", "policy_version": rguard.get("policy_version"),
                    "blocked": True,
                    "categories": rguard.get("categories") or []}}
    try:
        after = json.loads(row.get("after_json") or "{}")
    except Exception:  # noqa: BLE001 - 快照损坏 → 按「不可读」走 uncertain/blocked 口径
        after = {}
    try:
        before = json.loads(row.get("before_json") or "{}")
    except Exception:  # noqa: BLE001
        before = {}
    if not isinstance(after, dict):
        after = {}
    if not isinstance(before, dict):
        before = {}
    action = str(row.get("action") or "")
    code = str(row.get("rule_code") or "")
    # ---- B3：版本型 revise 的版本内容上下文（不可确证 → uncertain，不是 blocked）----
    vctx = (_gate_version_context(code, after, before) if action == "revise"
            else {"is_version_rule": False, "readable": False, "has_content": False,
                  "content": {}, "source": "none", "version": "",
                  "effective_version": "", "reason": ""})
    if vctx.get("is_version_rule") and not vctx.get("has_content"):
        reason = ("门禁无法确证（不是违规阻断）：旧版本不存在/不可读 —— "
                  + (str(vctx.get("reason") or "") or "无版本内容"))
        _mark(candidate_id, DECISION_UNCERTAIN, by, reason)
        R.audit_logs.log(actor=by or "system", action="rsi.gate_uncertain",
                         object=candidate_id,
                         after=json.dumps({"reason": reason, "action": action,
                                           "rule_code": code,
                                           "version": _version_ctx_brief(vctx)},
                                          ensure_ascii=False)[:1000])
        return {"ok": False, "decision": DECISION_UNCERTAIN, "candidate_id": candidate_id,
                "reason": reason, "version": _version_ctx_brief(vctx)}
    eval_after = after
    if vctx.get("has_content"):
        # 用版本内容做校验依据（有运行参数槽位时以候选显式 slots 覆盖）
        eval_after = dict(after)
        slots = dict(vctx.get("content") or {})
        if isinstance(after.get("slots"), dict):
            slots.update(after["slots"])
        eval_after["slots"] = slots
    v = validate_candidate(code, eval_after, action)
    if not v["ok"]:
        if action == "new_rule":
            _mark(candidate_id, DECISION_PENDING, by,
                  "待人工发布：" + ";".join(v["errors"]))
            return {"ok": False, "decision": DECISION_PENDING, "candidate_id": candidate_id,
                    "reason": "新规则候选需人工审批发布", **v}
        _mark(candidate_id, DECISION_BLOCKED, by, "校验阻断：" + ";".join(v["errors"]))
        R.audit_logs.log(actor=by or "system", action="rsi.gate_blocked",
                         object=candidate_id, after="validity:" + ";".join(v["errors"])[:300])
        out = {"ok": False, "decision": DECISION_BLOCKED, "candidate_id": candidate_id,
               "reason": "候选校验未通过，已阻断发布", **v}
        if vctx.get("is_version_rule"):
            out["version"] = _version_ctx_brief(vctx)
        return out
    # L73 P1a（铁律 7 / 82 号 §7）：候选释放前 Policy Compiler advisory 校验。
    # 开关 RULEPROOF_POLICY_COMPILER=0（默认）→ 整段不进入，门禁结论逐字节不变；
    # =1 → 只把结果放进 `policy` 明细 + 写政策审计，**绝不改变** accepted/blocked/uncertain。
    _policy_note = None
    try:
        from . import policy_compiler as _policy_pc_rsi
        if _policy_pc_rsi.enabled():
            _policy_note = _policy_pc_rsi.advisory_candidate_policy(
                candidate_id=candidate_id, rule_code=code, action=action,
                after=eval_after, actor=by or "system")
            for _pa, _pp in _policy_pc_rsi.audit_events(
                    _policy_note, stage="rsi", candidate_id=candidate_id):
                _policy_pc_rsi.write_audit(_pa, _pp, actor=by or "system",
                                           object_id=candidate_id)
    except Exception:
        _LOG.warning("policy compiler rsi advisory degraded candidate=%s",
                     candidate_id, exc_info=True)
    # 回放门禁：本体/结构类修订不要求回放样本；规则行为/参数修订必须过
    needs_replay = (action in _REPLAY_ACTIONS or bool(after.get("slots")) or bool(
        after.get("params") or after.get("pending") or after.get("behavior"))
        or bool(vctx.get("has_content")))
    if needs_replay and not action.startswith("ontology."):
        replay = _replay_gate(code)
        if not replay.get("ok"):
            # 回放收益≤0（有足够样本）= 真实违反门禁；样本不足/门禁不可用 = 无法确证
            _insufficient = "igain" not in replay
            if vctx.get("has_content") and _insufficient:
                reason = ("门禁无法确证（不是违规阻断）：回放证据不足 —— "
                          + str(replay.get("reason") or ""))
                _mark(candidate_id, DECISION_UNCERTAIN, by, reason)
                R.audit_logs.log(actor=by or "system", action="rsi.gate_uncertain",
                                 object=candidate_id,
                                 after=json.dumps({"reason": reason, "action": action,
                                                   "rule_code": code, "replay": replay,
                                                   "version": _version_ctx_brief(vctx)},
                                                  ensure_ascii=False)[:1000])
                return _with_policy({"ok": False, "decision": DECISION_UNCERTAIN,
                                     "candidate_id": candidate_id, "reason": reason,
                                     "samples": replay.get("samples"), "replay": replay,
                                     "version": _version_ctx_brief(vctx)}, _policy_note)
            _mark(candidate_id, DECISION_BLOCKED, by, replay.get("reason") or "回放门禁阻断")
            R.audit_logs.log(actor=by or "system", action="rsi.gate_blocked",
                             object=candidate_id, after=str(replay.get("reason") or "")[:300])
            out = {"ok": False, "decision": DECISION_BLOCKED, "candidate_id": candidate_id,
                   "samples": replay.get("samples"), "reason": replay.get("reason")}
            if vctx.get("is_version_rule"):
                out["version"] = _version_ctx_brief(vctx)
            return _with_policy(out, _policy_note)
    else:
        replay = {"ok": True, "samples": 0, "note": "结构性修订，无回放要求"}
    _mark(candidate_id, DECISION_ACCEPTED, by, "发布门禁通过")
    _audit_payload = {"rule_code": code, "action": action, "replay": replay}
    if vctx.get("is_version_rule"):
        _audit_payload["version"] = _version_ctx_brief(vctx)
    R.audit_logs.log(actor=by or "system", action="rsi.gate_passed",
                     object=candidate_id,
                     after=json.dumps(_audit_payload, ensure_ascii=False))
    out = {"ok": True, "decision": DECISION_ACCEPTED, "candidate_id": candidate_id,
           "warnings": v["warnings"], "replay": replay,
           "contract": contract_of(candidate_id)}
    if vctx.get("is_version_rule"):
        out["version"] = _version_ctx_brief(vctx)
    return _with_policy(out, _policy_note)



def contract_of(candidate_id: str) -> str:
    import hashlib
    row = R.rsi_candidates.get(candidate_id) or {}
    payload = json.dumps({k: row.get(k) for k in ("rule_code", "action", "after_json")},
                         ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


def effectiveness(rule_code: str) -> dict:
    """生效追踪：沉淀后这条规则在各种审核里是否真的产出过发现（按当前租户/空间口径）。

    修复点：``finding`` 表没有 ``rule_code`` 列（历史 SQL 直接查它 → 异常被吞成
    findings=0，会把任何规则误判为“长期零发现”）。finding 的规则编码统一存
    ``rule_id``；这里用仓储层计数，自动带租户/空间隔离。
    """
    try:
        n = R.findings.count("rule_id=?", (rule_code,))
    except Exception:  # noqa: BLE001
        n = 0
    return {"rule_code": rule_code, "findings": n, "effective": n > 0}


# ---------------------------------------------------------------------------
# L131 服务层薄封装：黄金集登记/状态、污染复检、回归结果（CLI/CI/运维/测试共用）
# 说明：CLI 命令未在本 lane 写作用域（app/cli.py 不在可改文件），HTTP 入口为
#   POST /api/v1/evolution/rules/<candidate_id>/hitl-approve（body.golden 显式指定）
#   GET  /api/v1/evolution/rules/<candidate_id>/hitl-status（含黄金集状态）；
#   黄金集登记由本服务层供 CI/运维/审批前置调用，交付说明如实记录 CLI 缺口。
# ---------------------------------------------------------------------------
def set_golden_set(cases, name: str = "", kind: str = "rule", by: str = "",
                   tenant_id: str = None, workspace_id: str = None,
                   require_admin: bool = False) -> dict:
    """登记管理员指定黄金集（脏/重/冲突校验 + 租户空间隔离作用域）。"""
    from . import rsi_guard as _guard
    return _guard.set_golden_set(cases, name=name, kind=kind, by=by,
                                 tenant_id=tenant_id, workspace_id=workspace_id,
                                 require_admin=require_admin)


def clear_golden_set(by: str = "") -> dict:
    """清除已登记黄金集（重登记/回退用；写审计）。"""
    from . import rsi_guard as _guard
    return _guard.clear_golden_set(by=by)


def golden_set_status() -> dict:
    """黄金集只读状态（可用性/类型/条数/摘要/作用域隔离）。"""
    from . import rsi_guard as _guard
    out = _guard.load_golden_set(with_cases=False)
    return {"ok": bool(out.get("available")),
            "available": bool(out.get("available")),
            "isolation_ok": bool(out.get("isolation_ok", True)),
            "set_id": out.get("set_id") or "",
            "kind": out.get("kind") or "",
            "count": out.get("count") or 0,
            "digest": out.get("digest") or "",
            "reason": out.get("reason") or "",
            "policy_version": _guard.HITL_POLICY_VERSION}


def pollution_scan(candidate_id: str, golden=None) -> dict:
    """候选污染防护复检（来源/训练数据标记 + 脏重冲突 + 黄金集隔离；只读）。"""
    from . import rsi_guard as _guard
    return _guard.pollution_scan(str(candidate_id or ""), golden=golden)


def golden_regression(candidate_id: str, golden=None) -> dict:
    """候选黄金集全量回归（只读；不落库，审批时由 rsi_guard.record_golden_evidence 落审计）。"""
    from . import rsi_guard as _guard
    return _guard.golden_regression(str(candidate_id or ""), golden=golden)


def guard_summary(limit: int = 100) -> dict:
    """L131 护栏运行摘要（策略 + 黄金集 + 审计事件计数）。"""
    from . import rsi_guard as _guard
    return _guard.guard_summary(limit=limit)
