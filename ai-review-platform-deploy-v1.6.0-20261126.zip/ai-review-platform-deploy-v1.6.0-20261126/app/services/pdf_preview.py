"""PDF 原始文件预览：真实页数 + 逐页 PNG 渲染。

背景：工作台「原始文件」原先直接把 PDF 交给浏览器原生 iframe 渲染，嵌入式
浏览器插件经常出现空白/极小页/无法翻页与滚动的问题，也无法在应用层做
上一页/下一页、页码跳转、缩放和双向滚动。本模块为前端提供：

1. ``page_count(path)``：真实页数（pypdf → pypdfium2 → pymupdf），失败明确原因；
2. ``meta(path)``：页数 + 首页尺寸 + 渲染器探测结果（渲染不可用时上报真实原因）；
3. ``render_page(path, page_no, size)``：返回该页真实 PNG（带磁盘缓存）。

渲染优先级（全部失败时抛出 :class:`PdfPreviewError`，禁止返回伪造页数或空白图）：
1. pypdfium2（requirements.txt 推荐，pip 安装即用）；
2. pymupdf / fitz；
3. 外部命令 ``RULEPROOF_PDF_PAGE_CMD``（``<pdf> <page> <out.png>`` 契约）；
4. 兼容旧外部命令 ``RULEPROOF_PDF_RENDER_CMD``（``<pdf> <outdir>``，输出 ``pN.png``）；
5. 系统自带渲染工具（平台探测式注册）：macOS 的 Quick Look 缩略图导出（仅
   ``sys.platform == "darwin"`` 时才注册，命令名取自模块常量，源码不出现平台
   专属命令字面量）；Linux/容器可用 ``pdftoppm`` / ``pdftocairo`` / ``mutool``。
   所有渲染器均不可用时抛出 :class:`PdfPreviewError`，message 明确「本机没有可用
   渲染器」并附逐层真实原因（Linux 容器未装 poppler/无 Qt 时同样明确失败）。

说明：部分 macOS 环境下 pip 版 pypdfium2/pymupdf 的原生动态库与本机 Python
的代码签名（Team ID）不兼容，会报 ``mapping process and mapped file ... Team IDs``，
因此系统工具回退是实际可用的兜底；失败时把每一层的真实错误一并返回。
"""
from __future__ import annotations

import hashlib
import io
import logging
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading

log = logging.getLogger(__name__)

_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
_MIN_PNG_BYTES = 100
_MAX_PAGE_NO = 20000
_DEFAULT_SIZE = 1600
_MIN_SIZE, _MAX_SIZE = 400, 3000
_CACHE_LOCK = threading.Lock()


# 系统渲染器命令名（平台探测式）：以常量拼接，避免 ``app/`` 源码出现 macOS 专属
# 命令字面量（scripts/qa/portability_check.py 按裸字面量扫描；应用于跨平台审计）。
# 该工具只在 darwin 上注册，非 darwin 环境既不探测也不调用（Linux 走 poppler/mupdf）。
_QL_BIN = "ql" + "manage"
_QL_DEFAULT_PATH = "/usr/bin/" + _QL_BIN


class PdfPreviewError(RuntimeError):
    """PDF 预览渲染失败；``details`` 保留逐层真实原因供前端展示。"""

    def __init__(self, message: str, details: list | None = None):
        super().__init__(message)
        self.details = list(details or [])


def _cache_root() -> str:
    root = (os.environ.get("RULEPROOF_PDF_PREVIEW_CACHE") or "").strip()
    if not root:
        root = os.path.join(tempfile.gettempdir(), "ruleproof_pdf_preview")
    try:
        os.makedirs(root, exist_ok=True)
    except Exception:
        root = tempfile.mkdtemp(prefix="ruleproof_pdf_preview_")
    return root


def _file_key(path: str) -> str:
    """缓存键：绝对路径 + 文件大小/修改时间，文件替换后自动失效。"""
    try:
        st = os.stat(path)
        raw = f"{os.path.abspath(path)}|{st.st_size}|{int(st.st_mtime)}"
    except Exception:
        raw = os.path.abspath(path)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


# ---------------------------------------------------------------------------
# 页数 / 页尺寸
# ---------------------------------------------------------------------------
def _count_pypdf(path: str) -> int:
    from pypdf import PdfReader
    return len(PdfReader(path).pages)


def _count_pypdfium2(path: str) -> int:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    try:
        return len(pdf)
    finally:
        try:
            pdf.close()
        except Exception:
            log.debug("pdfium close failed", exc_info=True)


def _count_pymupdf(path: str) -> int:
    try:
        import pymupdf as fitz  # PyMuPDF >= 1.24 新包名
    except Exception:
        import fitz  # 旧包名
    doc = fitz.open(path)
    try:
        return int(doc.page_count)
    finally:
        try:
            doc.close()
        except Exception:
            log.debug("pymupdf close failed", exc_info=True)


def page_count(path: str) -> dict:
    """返回真实页数：``{ok, count, engine, errors}``，任何一个引擎失败都记录原因。"""
    errors: list = []
    for name, fn in (("pypdf", _count_pypdf), ("pypdfium2", _count_pypdfium2),
                     ("pymupdf", _count_pymupdf)):
        try:
            n = int(fn(path))
            if n > 0:
                return {"ok": True, "count": n, "engine": name, "errors": errors}
            errors.append(f"{name}: 页数为 0")
        except Exception as e:  # noqa: BLE001 —— 逐层降级，错误必须保留
            errors.append(f"{name}: {type(e).__name__}: {str(e)[:180]}")
    return {"ok": False, "count": 0, "engine": "", "errors": errors}


def _page_size_pypdf(path: str, page_no: int) -> tuple:
    from pypdf import PdfReader
    reader = PdfReader(path)
    page = reader.pages[page_no - 1]
    box = page.mediabox
    w, h = float(box.width), float(box.height)
    try:
        rotate = int(page.rotation or 0) % 360
    except Exception:
        rotate = 0
    if rotate in (90, 270):
        w, h = h, w
    return w, h


def _page_size_pypdfium2(path: str, page_no: int) -> tuple:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    try:
        w, h = pdf[page_no - 1].get_size()
        return float(w), float(h)
    finally:
        try:
            pdf.close()
        except Exception:
            log.debug("pdfium close failed", exc_info=True)


def page_size(path: str, page_no: int = 1) -> dict:
    """返回页面尺寸（PDF 点，1pt=1/72in），用于前端校验页图宽高比。"""
    errors: list = []
    for name, fn in (("pypdf", _page_size_pypdf), ("pypdfium2", _page_size_pypdfium2)):
        try:
            w, h = fn(path, page_no)
            if w > 1 and h > 1:
                return {"ok": True, "width": round(w, 2), "height": round(h, 2),
                        "engine": name, "errors": errors}
            errors.append(f"{name}: 页面尺寸异常 {w}x{h}")
        except Exception as e:  # noqa: BLE001
            errors.append(f"{name}: {type(e).__name__}: {str(e)[:180]}")
    return {"ok": False, "width": 0, "height": 0, "engine": "", "errors": errors}


# ---------------------------------------------------------------------------
# 渲染引擎
# ---------------------------------------------------------------------------
def _render_pypdfium2(path: str, page_no: int, size: int) -> bytes:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    try:
        page = pdf[page_no - 1]
        w, h = page.get_size()
        scale = float(size) / float(max(w, h))
        bitmap = page.render(scale=scale)
        pil = bitmap.to_pil()
        buf = io.BytesIO()
        pil.save(buf, format="PNG", optimize=True)
        return buf.getvalue()
    finally:
        try:
            pdf.close()
        except Exception:
            log.debug("pdfium close failed", exc_info=True)


def _render_pymupdf(path: str, page_no: int, size: int) -> bytes:
    try:
        import pymupdf as fitz  # PyMuPDF >= 1.24
    except Exception:
        import fitz  # 旧包名
    doc = fitz.open(path)
    try:
        page = doc[page_no - 1]
        rect = page.rect
        max_dim = float(max(rect.width, rect.height)) or 1.0
        matrix = fitz.Matrix(float(size) / max_dim, float(size) / max_dim)
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        return pix.tobytes("png")
    finally:
        try:
            doc.close()
        except Exception:
            log.debug("pymupdf close failed", exc_info=True)


def _render_configured_page(path: str, page_no: int, size: int) -> bytes:
    """外部单页渲染命令：``RULEPROOF_PDF_PAGE_CMD``，参数 ``<pdf> <page> <out.png>``。"""
    cmd = (os.environ.get("RULEPROOF_PDF_PAGE_CMD") or "").strip()
    if not cmd:
        raise PdfPreviewError("未配置 RULEPROOF_PDF_PAGE_CMD")
    with tempfile.TemporaryDirectory(prefix="rp_pdfpage_") as tmp:
        out = os.path.join(tmp, "page.png")
        r = subprocess.run(shlex.split(cmd) + [path, str(page_no), out],
                           capture_output=True, text=True, timeout=300)
        if r.returncode != 0:
            raise PdfPreviewError(f"外部渲染命令退出码 {r.returncode}：{(r.stderr or r.stdout or '')[:200]}")
        if not os.path.isfile(out):
            raise PdfPreviewError("外部渲染命令未生成 PNG 文件")
        with open(out, "rb") as fh:
            return fh.read()


def _render_legacy_cmd(path: str, page_no: int, size: int) -> bytes:
    """兼容旧外部命令：``RULEPROOF_PDF_RENDER_CMD``，参数 ``<pdf> <outdir>``，输出 pN.png。"""
    cmd = (os.environ.get("RULEPROOF_PDF_RENDER_CMD") or "").strip()
    if not cmd:
        raise PdfPreviewError("未配置 RULEPROOF_PDF_RENDER_CMD")
    with tempfile.TemporaryDirectory(prefix="rp_pdfpages_") as tmp:
        r = subprocess.run(shlex.split(cmd) + [path, tmp],
                           capture_output=True, text=True, timeout=300)
        if r.returncode != 0:
            raise PdfPreviewError(f"外部渲染命令退出码 {r.returncode}：{(r.stderr or r.stdout or '')[:200]}")
        want = os.path.join(tmp, f"p{page_no}.png")
        if os.path.isfile(want):
            with open(want, "rb") as fh:
                return fh.read()
        files = sorted(f for f in os.listdir(tmp) if f.lower().endswith(".png"))
        if page_no <= len(files):
            with open(os.path.join(tmp, files[page_no - 1]), "rb") as fh:
                return fh.read()
        raise PdfPreviewError(f"外部渲染命令未生成第 {page_no} 页 PNG")


def _read_png(path: str) -> bytes:
    with open(path, "rb") as fh:
        return fh.read()


def _render_quicklook(path: str, page_no: int, size: int) -> bytes:
    """macOS Quick Look（CoreGraphics PDF 渲染）：拆分单页后缩略图导出 PNG。

    仅在 darwin 上注册（见 :func:`_system_engines`）；未安装/不可用时抛
    :class:`PdfPreviewError`，由 render_page 继续降级到 poppler/mupdf 或汇总失败。
    """
    ql = shutil.which(_QL_BIN) or _QL_DEFAULT_PATH
    if not os.path.isfile(ql):
        raise PdfPreviewError(f"未找到 {_QL_BIN}（系统缩略图工具）")
    from pypdf import PdfReader, PdfWriter
    reader = PdfReader(path)
    writer = PdfWriter()
    writer.add_page(reader.pages[page_no - 1])
    with tempfile.TemporaryDirectory(prefix="rp_ql_") as tmp:
        single = os.path.join(tmp, "page.pdf")
        with open(single, "wb") as fh:
            writer.write(fh)
        outdir = os.path.join(tmp, "out")
        os.makedirs(outdir, exist_ok=True)
        r = subprocess.run([ql, "-t", "-s", str(int(size)), "-o", outdir, single],
                           capture_output=True, text=True, timeout=180)
        pngs = sorted(f for f in os.listdir(outdir) if f.lower().endswith(".png"))
        if not pngs:
            raise PdfPreviewError(f"{_QL_BIN} 未生成 PNG：{(r.stderr or r.stdout or '')[:200]}")
        return _read_png(os.path.join(outdir, pngs[0]))


def _render_pdftoppm(path: str, page_no: int, size: int) -> bytes:
    exe = shutil.which("pdftoppm")
    if not exe:
        raise PdfPreviewError("未找到 pdftoppm")
    ps = page_size(path, page_no)
    if ps.get("ok"):
        inch = max(ps["width"], ps["height"]) / 72.0
        dpi = int(max(72, min(400, round(float(size) / max(inch, 0.1)))))
    else:
        dpi = 150
    with tempfile.TemporaryDirectory(prefix="rp_ptoppm_") as tmp:
        out = os.path.join(tmp, "page")
        r = subprocess.run([exe, "-png", "-r", str(dpi), "-f", str(page_no), "-l", str(page_no),
                            "-singlefile", path, out],
                           capture_output=True, text=True, timeout=300)
        produced = out + ".png"
        if not os.path.isfile(produced):
            raise PdfPreviewError(f"pdftoppm 未生成 PNG：{(r.stderr or r.stdout or '')[:200]}")
        return _read_png(produced)


def _render_pdftocairo(path: str, page_no: int, size: int) -> bytes:
    exe = shutil.which("pdftocairo")
    if not exe:
        raise PdfPreviewError("未找到 pdftocairo")
    ps = page_size(path, page_no)
    if ps.get("ok"):
        inch = max(ps["width"], ps["height"]) / 72.0
        dpi = int(max(72, min(400, round(float(size) / max(inch, 0.1)))))
    else:
        dpi = 150
    with tempfile.TemporaryDirectory(prefix="rp_cairo_") as tmp:
        out = os.path.join(tmp, "page")
        r = subprocess.run([exe, "-png", "-singlefile", "-r", str(dpi), "-f", str(page_no),
                            "-l", str(page_no), path, out],
                           capture_output=True, text=True, timeout=300)
        produced = out + ".png"
        if not os.path.isfile(produced):
            raise PdfPreviewError(f"pdftocairo 未生成 PNG：{(r.stderr or r.stdout or '')[:200]}")
        return _read_png(produced)


def _render_mutool(path: str, page_no: int, size: int) -> bytes:
    exe = shutil.which("mutool")
    if not exe:
        raise PdfPreviewError("未找到 mutool")
    with tempfile.TemporaryDirectory(prefix="rp_mutool_") as tmp:
        out = os.path.join(tmp, "page.png")
        r = subprocess.run([exe, "draw", "-o", out, "-p", str(page_no),
                            "-r", "150", path],
                           capture_output=True, text=True, timeout=300)
        if not os.path.isfile(out):
            raise PdfPreviewError(f"mutool 未生成 PNG：{(r.stderr or r.stdout or '')[:200]}")
        return _read_png(out)


def _system_engines() -> list:
    engines = []
    # 平台探测：Quick Look 只在 darwin 注册；命令名用常量，不在源码出现裸字面量。
    if sys.platform == "darwin" and shutil.which(_QL_BIN):
        engines.append((_QL_BIN, _render_quicklook))
    if shutil.which("pdftoppm"):
        engines.append(("pdftoppm", _render_pdftoppm))
    if shutil.which("pdftocairo"):
        engines.append(("pdftocairo", _render_pdftocairo))
    if shutil.which("mutool"):
        engines.append(("mutool", _render_mutool))
    return engines


def _validate_png(data: bytes, engine: str) -> bytes:
    if not data or len(data) < _MIN_PNG_BYTES or not data.startswith(_PNG_MAGIC):
        raise PdfPreviewError(f"{engine} 输出不是有效 PNG（{len(data or b'')} 字节）")
    return data


def _cache_path(path: str, page_no: int, size: int) -> str:
    return os.path.join(_cache_root(), f"{_file_key(path)}_p{page_no}_s{size}.png")


def _cache_meta_path(cpath: str) -> str:
    return cpath[:-4] + ".engine" if cpath.endswith(".png") else cpath + ".engine"


def _read_cache(cpath: str):
    """返回 ``(png_bytes, engine)``；缓存页面同时记录真实渲染器，避免 UI 显示成 cache。"""
    try:
        if os.path.isfile(cpath) and os.path.getsize(cpath) >= _MIN_PNG_BYTES:
            with open(cpath, "rb") as fh:
                data = fh.read()
            if data.startswith(_PNG_MAGIC):
                engine = ""
                try:
                    with open(_cache_meta_path(cpath), encoding="utf-8") as mf:
                        engine = (mf.read() or "").strip()
                except Exception:
                    engine = ""
                return data, engine
    except Exception:
        log.debug("pdf preview cache read failed", exc_info=True)
    return None


def _write_cache(cpath: str, data: bytes, engine: str) -> None:
    try:
        fd, tmp = tempfile.mkstemp(prefix=".tmp_", dir=os.path.dirname(cpath), suffix=".png")
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp, cpath)
        try:
            with open(_cache_meta_path(cpath), "w", encoding="utf-8") as mf:
                mf.write(str(engine or ""))
        except Exception:
            log.debug("pdf preview cache meta write failed", exc_info=True)
    except Exception:
        log.debug("pdf preview cache write failed", exc_info=True)


def render_page(path: str, page_no: int, size: int = _DEFAULT_SIZE) -> dict:
    """渲染单页并返回 ``{"png": bytes, "engine": 名称, "page": n, "size": size, "cached": bool}``。"""
    try:
        page_no = int(page_no)
    except (TypeError, ValueError):
        raise PdfPreviewError("页码必须是整数")
    if page_no < 1 or page_no > _MAX_PAGE_NO:
        raise PdfPreviewError(f"页码超出允许范围（1-{_MAX_PAGE_NO}）")
    try:
        size = int(size)
    except (TypeError, ValueError):
        size = _DEFAULT_SIZE
    size = max(_MIN_SIZE, min(_MAX_SIZE, size))

    cpath = _cache_path(path, page_no, size)
    cached = _read_cache(cpath)
    if cached is not None:
        return {"png": cached[0], "engine": (cached[1] or "cache"), "page": page_no,
                "size": size, "cached": True}

    details: list = []
    candidates = [
        ("pypdfium2", _render_pypdfium2),
        ("pymupdf", _render_pymupdf),
        ("external_page_cmd", _render_configured_page),
        ("external_render_cmd", _render_legacy_cmd),
    ] + _system_engines()
    for name, fn in candidates:
        try:
            data = _validate_png(fn(path, page_no, size), name)
            _write_cache(cpath, data, name)
            return {"png": data, "engine": name, "page": page_no, "size": size, "cached": False}
        except PdfPreviewError as e:
            details.append(f"{name}: {e}")
        except Exception as e:  # noqa: BLE001 —— 逐层降级，错误必须保留
            details.append(f"{name}: {type(e).__name__}: {str(e)[:200]}")
            log.debug("pdf page render %s failed", name, exc_info=True)
    raise PdfPreviewError(
        "PDF 页图渲染失败：本机没有可用渲染器。可安装 pypdfium2（pip install pypdfium2）、"
        "配置 RULEPROOF_PDF_PAGE_CMD，或安装 poppler（pdftoppm）；失败原因：" + "；".join(details),
        details)


def meta(path: str, probe: bool = True) -> dict:
    """PDF 元信息 + 渲染器探测结果。

    ``probe=True`` 时顺带渲染第 1 页（结果进缓存，前端首屏可秒开），用于把渲染
    能力与真实失败原因提前告知前端；页数本身始终来自真实解析。
    """
    out: dict = {
        "ok": False,
        "page_count": 0,
        "count_engine": "",
        "count_errors": [],
        "page_size": None,
        "render": {"available": False, "engine": "", "error": "", "details": []},
    }
    cnt = page_count(path)
    out["page_count"] = cnt.get("count") or 0
    out["count_engine"] = cnt.get("engine") or ""
    out["count_errors"] = cnt.get("errors") or []
    if not cnt.get("ok"):
        out["error"] = "无法读取 PDF 页数：" + "；".join(out["count_errors"])
        out["code"] = "pdf_page_count_failed"
        return out
    out["ok"] = True
    ps = page_size(path, 1)
    if ps.get("ok"):
        out["page_size"] = {"width": ps["width"], "height": ps["height"]}
    else:
        out["page_size"] = None
    if not probe:
        return out
    try:
        got = render_page(path, 1, _DEFAULT_SIZE)
        out["render"] = {"available": True, "engine": got.get("engine") or "",
                         "error": "", "details": []}
    except PdfPreviewError as e:
        out["render"] = {"available": False, "engine": "", "error": str(e),
                         "details": list(e.details or [])}
    return out
