"""旧版 review.run_review 兼容入口（legacy 适配器）。

入口契约（P0-1）：

- 唯一产品入口是 ``project.audit`` 的 manual / assisted 两模式；
- :func:`run_review` 是 legacy 适配器：调用方必须**显式**传 ``legacy=True``，
  否则直接拒绝（不做隐式回退 / 不接管产品入口）；
- :func:`run_legacy_audit` 只由 ``project.audit(legacy=True)`` 调用，不能被产品
  入口静默调用；返回值与 project 两模式共享 ``review.normalize_result`` schema。

points_path 日落：默认拒绝并在写库前抛 LegacyPointsPathDeprecated；
只有显式设置 RULEPROOF_ALLOW_LEGACY_POINTS=1 才允许旧版标准对照回退。
"""
import logging
import os

from .. import db
from .. import repositories as R
from ..engine import engine, stdcheck

# points_path 日落开关：只有显式 1 才允许旧版审核点库直传（与 audit_orchestrator 保持一致）
LEGACY_POINTS_ENV = "RULEPROOF_ALLOW_LEGACY_POINTS"
LEGACY_POINTS_ERROR = "legacy_points_path_deprecated"
# legacy 入口必须显式声明；不能靠默认参数静默进入旧链
LEGACY_EXPLICIT_ERROR = "legacy_entry_requires_explicit_flag"


class LegacyEntryExplicitRequired(ValueError):
    """legacy 适配器未显式声明 legacy=True：拒绝且不写库。"""

    code = LEGACY_EXPLICIT_ERROR
    error = LEGACY_EXPLICIT_ERROR
    http_status = 400

    def __init__(self):
        super().__init__(
            "review_legacy.run_review 只能显式 legacy=True 调用；"
            "产品审核请使用 project.audit(ai_assist=True/False)，"
            "旧一次性兼容入口请使用 review.run_review。"
        )

    def to_dict(self) -> dict:
        return {
            "ok": False,
            "error": self.code,
            "code": self.code,
            "message": str(self),
            "http_status": 400,
            "remediation": "legacy=True；产品入口 project.audit(ai_assist=True/False)",
        }


class LegacyPointsPathDeprecated(RuntimeError):
    """points_path 日落错误：默认拒绝，不做静默回退。"""

    code = LEGACY_POINTS_ERROR
    error = LEGACY_POINTS_ERROR
    http_status = 410        # Gone：旧入口按日落处理
    deprecated = True

    def __init__(self, points_path: str = ""):
        self.points_path = str(points_path or "")
        super().__init__(
            f"{LEGACY_POINTS_ERROR}: points_path 已日落，默认拒绝旧版审核点库直传；"
            f"只有显式设置 {LEGACY_POINTS_ENV}=1 才允许兼容期回退。"
        )

    def to_dict(self) -> dict:
        return {
            "ok": False,
            "error": self.code,
            "code": self.code,
            "message": str(self),
            "deprecated": True,
            "points_path": self.points_path,
            "remediation": f"{LEGACY_POINTS_ENV}=1",
        }


def legacy_points_enabled() -> bool:
    """只有精确的 1 才放行；与入口层回退判断保持同一语义。"""
    return os.environ.get(LEGACY_POINTS_ENV) == "1"


def _reject_legacy_points(points_path: str) -> None:
    """显式开关未开启时拒绝 points_path，避免任何静默忽略/回退。"""
    if points_path and not legacy_points_enabled():
        raise LegacyPointsPathDeprecated(points_path)


def _doc_type(path: str) -> str:
    return path.rsplit(".", 1)[-1].lower() if "." in path else ""


def _attach_document(case_id: str, path: str) -> str:
    """把旧入口的文件挂到项目下；旧链路只按路径取数，因此补 path 但不做预解析。"""
    from . import review as _rv
    doc_id = _rv.import_document(path, doc_type=_doc_type(path) or "process_sheet",
                                 source="legacy")
    R.documents.update(doc_id, path=str(path))
    R.cases.add_document(case_id, doc_id)
    return doc_id


def _legacy_points_conflicts(doc_paths: list, points_path: str) -> list:
    """旧版标准对照：只在显式开关放行后执行，且仅对表格文件生效。"""
    conflicts_out = []
    for p in doc_paths:
        if _doc_type(p) not in ("xlsx", "xls"):
            continue
        doc = engine.parse_xlsx(p)
        for c in stdcheck.check(doc.process_text, points_path):
            if c.state == "不一致":
                R.conflicts.insert(id=db.new_id("cfg"), rule_a="工艺要点", rule_b=c.process,
                                   type="规则-事实", detail=c.detail, status="open")
            conflicts_out.append(c.to_dict())
    return conflicts_out


def run_review(case_name: str, doc_paths: list, points_path: str = "",
               pack_version: str = "food.process.v1", model_version: str = "det-0.1",
               semantic: bool = False, created_by: str = "", *,
               legacy: bool = False) -> dict:
    """legacy 适配器：旧的一次性审核调用 → 项目容器 → ``project.audit(legacy=True)``。

    必须显式 ``legacy=True``；未声明时抛 LegacyEntryExplicitRequired，且在写库前拒绝。
    points_path 日落：默认拒绝；只有 RULEPROOF_ALLOW_LEGACY_POINTS=1 时才执行旧版标准对照。
    """
    from . import review as _rv
    if not legacy:
        raise LegacyEntryExplicitRequired()
    _rv.assert_entry_writable(created_by, entry="review_legacy")
    points_path = str(points_path or "")
    # 必须在任何写库动作之前拒绝，避免留下半成品 Case/Run
    _reject_legacy_points(points_path)
    if points_path:
        logging.getLogger(__name__).warning(
            "legacy points_path 已日落，但开关 %s=1 显式放行：%s",
            LEGACY_POINTS_ENV, points_path)
        # L52 ②：显式放行必须留痕（不再“warning 日志即算审计”）；
        # legacy 报告无 manifest 由 report_gate 硬阻断签发。
        try:
            from . import single_entry as _se_lp
            if _se_lp.enabled():
                _se_lp.audit("legacy.points_path_enabled", case_name or "", {
                    "entry": "review_legacy.run_review",
                    "points_path": str(points_path)[:300],
                    "legacy_only": True, "manifest_id": "",
                    "report_signing_blocked": True,
                })
        except Exception:  # noqa: BLE001 - 审计失败不阻断旧链执行
            logging.getLogger(__name__).debug(
                "legacy points audit skipped", exc_info=True)
    paths = [str(p) for p in (doc_paths or []) if str(p or "").strip()]
    if not paths:
        raise ValueError("缺少 doc_paths")
    from . import project
    case_id = project.create(case_name, user=created_by, compat_mode="legacy")
    for path in paths:
        _attach_document(case_id, path)
    out = project.audit(case_id, semantic=semantic, legacy=True)
    # 旧入口允许显式覆盖包/模型版本；项目主链不消费这两个字段，适配器落回 case
    try:
        R.cases.update(case_id, pack_version=pack_version, model_version=model_version)
    except Exception:
        logging.getLogger(__name__).debug("legacy pack/model version update skipped", exc_info=True)
    # points_path 是纯 legacy 兼容语义，由适配器自己完成，不进入项目主链
    out["conflicts"] = _legacy_points_conflicts(paths, points_path) if points_path else []
    return _rv.normalize_result(out, entry="review_legacy", pipeline="legacy",
                                mode="legacy", case_id=case_id)


def run_legacy_audit(case_id: str, semantic: bool = False, created_by: str = "",
                     pack_version: str = "food.process.v1",
                     model_version: str = "det-0.1") -> dict:
    """``project.audit(legacy=True)`` 的旧版后端（只允许显式 legacy 链调用）。

    不跑产品 manual/assisted 流程，也不应被任何产品入口直接调用；返回结构经
    ``review.normalize_result`` 归一，与 manual/assisted 共享 schema 与审计口径。
    """
    case = R.cases.get(case_id)
    if not case:
        raise ValueError("项目不存在")
    docs = R.cases.documents(case_id) or []
    doc_rows = [(str(d.get("id") or ""), str(d.get("path") or "")) for d in docs]
    doc_rows = [(did, path) for did, path in doc_rows if did and path]
    if not doc_rows:
        raise ValueError("项目内没有可审核的文件")
    doc_paths = [path for _did, path in doc_rows]

    # 兼容入口复用 review 的解析/发现/增强实现，避免复制业务逻辑
    from . import review as _rv
    _findings_for = _rv._findings_for
    dynamic_rule_findings = _rv.dynamic_rule_findings
    semantic_enrich = _rv.semantic_enrich
    # 脚本/接口直接调用完整链路时，不受之前线程内审核模式影响
    try:
        from . import ctx as _ctx_r
        _ctx_r.set_audit_mode("")
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)

    run_id = db.new_id("run")
    R.audit_runs.insert(id=run_id, case_id=case_id, created_at=db.now(),
                        created_by=created_by or case.get("created_by", "") or "",
                        audit_type="", focus="", total=0, critical=0, warning=0, suspected=0)
    collected = []          # 汇总 findings（用于 summary + 返回，id 用 DB 主键）
    _bk_text_cache = {}     # L71：每文档只解析一次（证据回填原文口径）
    for doc_id, path in doc_rows:
        _bk_text = ""
        try:
            from . import auditpoints as _ap_bk
            if _ap_bk.evidence_backfill_enabled() and _ap_bk.finding_include_quote():
                if path not in _bk_text_cache:
                    try:
                        from ..engine import deepparse as _dp_bk
                        _bk_text_cache[path] = str(_dp_bk.parse_document(path).text or "")
                    except Exception:
                        logging.getLogger(__name__).warning(
                            "legacy evidence backfill doc parse failed: %s", path,
                            exc_info=True)
                        _bk_text_cache[path] = ""
                _bk_text = _bk_text_cache.get(path) or ""
        except Exception:
            logging.getLogger(__name__).warning(
                "legacy evidence backfill config failed", exc_info=True)
        for f in _findings_for(path):
            # 空壳 finding（无规则码、无标题）不是业务发现，不能落成“未命名问题”。
            if not any(str(f.get(k) or "").strip() for k in ("rule_code", "source_code", "id", "title")):
                continue
            fid = db.new_id("fnd")
            # L71 P2a：落库前证据回填（locations[] → verbatim_quote/char span/anchor_mode；
            # 摘要移入 quote_summary；legacy 链回填失败只标 skipped_legacy，不新增强制）
            _bk_anchor = {}
            try:
                from . import auditpoints as _ap_bk2
                if _ap_bk2.evidence_backfill_enabled() and _ap_bk2.finding_include_quote():
                    _bk_anchor = _ap_bk2.attach_finding_quote_fields(
                        dict(f), _bk_text, locations=f.get("locations") or [],
                        doc_path=path, legacy_chain=True)
            except Exception:  # 铁律 2：回填异常留痕，不阻断 legacy 落库
                logging.getLogger(__name__).warning(
                    "legacy finding evidence backfill failed rule=%s",
                    f.get("rule_code") or f.get("id"), exc_info=True)
                _bk_anchor = {}
            _bk_cols = {}
            if _bk_anchor:
                _bk_cols = {
                    "verbatim_quote": str(_bk_anchor.get("verbatim_quote") or ""),
                    "char_start": int(_bk_anchor.get("char_start", -1)),
                    "char_end": int(_bk_anchor.get("char_end", -1)),
                    "anchor_mode": str(_bk_anchor.get("anchor_mode") or "unanchored"),
                    "issue_identity": str(_bk_anchor.get("issue_identity") or ""),
                }
                try:
                    _bk_cols.update(_ap_bk2.evidence_write_columns(_bk_anchor))
                except Exception:
                    logging.getLogger(__name__).debug("legacy write columns skipped",
                                                      exc_info=True)
            R.findings.insert(
                id=fid, case_id=case_id,
                rule_id=(f.get("source_code") or f.get("rule_code") or f.get("id") or "UNKNOWN"),
                point_id=(f.get("point_id") or ""), source_code=(f.get("source_code") or ""),
                rule_version="builtin",
                severity=f.get("level") or "warning",
                certainty="certain" if (f.get("level") or "") == "critical" else "probable",
                confidence=f.get("confidence"),
                state={"满足":"pass","不满足":"fail","证据不足":"insufficient",
                       "弃权(需人工)":"insufficient","需人工":"insufficient",
                       "不适用":"na","未知":"unknown","执行失败":"unknown"}.get(str(f.get("state") or ""), f.get("state") or "fail"),
                status="pending", title=f.get("title") or "未命名问题", run_id=run_id,
                summary=f.get("description") or f.get("detail") or "", suggestion=f.get("suggestion") or "", engine="deterministic",
                **_bk_cols,
            )
            anchors_out = []
            # 回填成功时用逐字 quote + 修复后的单元格坐标写 anchor（失败实例保留原摘要以便复核）
            _bk_locs = (_bk_anchor.get("locations") if _bk_anchor else None) or f.get("locations") or []
            for loc in _bk_locs:
                aid = db.new_id("anc")
                R.anchors.insert(id=aid, document_id=doc_id, sheet=loc.get("sheet", ""),
                                 row=loc.get("row"), col=loc.get("col", ""),
                                 locator=loc.get("locator", ""), quote=loc.get("quote", ""),
                                 hash=loc.get("hash", ""))
                R.evidences.insert(id=db.new_id("evd"), finding_id=fid, document_id=doc_id,
                                   anchor_id=aid, excerpt=loc.get("quote", ""), label=f["title"])
                anchors_out.append({"locator": loc.get("locator", ""), "sheet": loc.get("sheet", ""),
                                    "quote": loc.get("quote", "")})
            # 返回给调用方的 rule_code 必须与落库 rule_id 同源（engine 发现只有
            # id 字段，如 S1/G-酱油饭）；否则调用方拿 LEGACY 去查趋势/台账会空，
            # 与 R.findings.rule_id 口径漂移（test_suite 趋势用例）。
            _rc = f.get("source_code") or f.get("rule_code") or f.get("id") or "LEGACY"
            collected.append({
                "id": fid,
                "code": _rc,
                "rule_code": _rc,
                "rule_name": f.get("rule_name", ""), "category": f.get("category", ""),
                "rclass": f.get("rclass", ""), "severity": f.get("level") or "warning",
                "title": f.get("title") or "未命名问题", "summary": f.get("description") or f.get("detail") or "", "suggestion": f.get("suggestion") or "",
                "evidence": anchors_out,
            })

    # 合并第二条执行路径：客户沉淀/自定义规则（此前只在 dynamic_rule_findings 里跑，主链路不调用）
    try:
        _dyn = dynamic_rule_findings(doc_paths[0], "") if doc_paths else []
        _exist = {(f.get("rule_code"), f.get("title")) for f in collected}
        for _d in _dyn:
            _k = (_d.get("rule_code"), _d.get("title"))
            if _k in _exist:
                continue
            _exist.add(_k)
            collected.append({
                "id": _d.get("id") or db.new_id("fnd"), "code": _d.get("id") or "",
                "rule_code": _d.get("rule_code") or "", "rule_name": _d.get("title") or "",
                "category": _d.get("category") or "", "rclass": "",
                "severity": _d.get("level") or "warning",
                "title": _d.get("title") or "", "summary": _d.get("description") or "",
                "suggestion": _d.get("suggestion") or "",
                "evidence": _d.get("locations") or [],
            })
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)

    collected = semantic_enrich(collected) if semantic else collected
    # legacy 链只有「发现 / 无发现」两态，不产生平台点位 unknown；状态在合并后确定
    summary = {"status": "不通过" if any(f["severity"] == "critical" for f in collected) else "通过"}
    # summary 必须在两条执行路径合并 / 语义富集之后计算，否则计数与 findings 漂移
    out = _rv.normalize_result(
        {"case_id": case_id, "summary": summary, "findings": collected, "conflicts": [],
         # 与项目链返回结构对齐，避免内部脚本按不同 schema 分支
         "orchestration": [], "dag": None},
        entry="project.audit", pipeline="legacy", mode="legacy", case_id=case_id)
    _summary = out["summary"]
    R.audit_runs.update(run_id, total=_summary["total_findings"],
                        critical=_summary["critical_count"],
                        warning=_summary["warning_count"],
                        suspected=sum(1 for f in collected if f["severity"] == "suspected"))
    R.cases.update(case_id, status="completed", progress=100, last_run_id=run_id,
                   last_audit_at=db.now(), pack_version=pack_version,
                   model_version=model_version)
    from . import stats
    stats.snapshot_rules(case_id)
    # 三入口共享审计口径：review.completed + summary JSON（review_compat 同口径）
    _rv.log_entry_completion(case_id, _summary, entry="project.audit",
                             pipeline="legacy", mode="legacy")
    return out

