import hashlib
import json
import logging
import os
import time
import urllib.parse

"""规则进化：人工复核反馈 → 错误书（误报案例）→ 规则修订建议。"""
from .. import db
from .. import repositories as R
from ..engine.rules_meta import BUILTIN_RULES
from . import rule


def error_book() -> list:
    """错误书：所有被人工判为「误报」的发现（附规则 + 证据 + 理由），供规则复盘。"""
    rows = R.decisions.list("decision=?", ("false_positive",), order="created_at DESC")
    out = []
    for d in rows:
        f = R.findings.get(d["finding_id"])
        if not f:
            continue
        evs = R.evidences.list("finding_id=?", (f["id"],))
        anchors = [R.anchors.get(e["anchor_id"]) for e in evs]
        out.append({"decision": d, "finding": f,
                    "evidence": [a for a in anchors if a]})
    return out


def _suggest(rate: float, hit: int) -> str:
    if hit == 0:
        return "从未命中：规则可能过严或场景未覆盖，建议复盘适用场景"
    if rate >= 0.5:
        return "override 率过高：建议修订条件、收紧作用域或降级为「疑似」"
    if rate > 0.2:
        return "override 率偏高：建议复核阈值/单位/作用域/计量基准"
    return "健康"


def evolution_suggestions() -> list:
    """规则健康：命中数、已复核数、误报数、override 率、修订建议。

    规则全集 = 内置规则（rules_meta 单一事实源）+ DB 里的自定义规则，二者按 code 合并。
    """
    base = {r["code"]: {"name": r["name"], "category": r["category"], "rclass": r["rclass"]}
            for r in BUILTIN_RULES}
    for r in R.rules.list():
        base.setdefault(r["code"], {"name": r["name"], "category": r["category"], "rclass": r["rclass"]})
    # 补上事实层规则（F-*）与审核点规则：它们不在规则表里，但会产生误报
    # P2 慢节点最小修（首页 /home → 告警）：findings 一次取回后按 rule_id 分组，
    # 替代逐规则 R.findings.list("rule_id=?") 的 N+1；口径（租户/空间过滤、
    # status 计数、hit 总数）与旧逐条查询逐字一致。
    _all_findings = R.findings.list()
    for f in _all_findings:
        code = f.get("rule_id") or ""
        if code and code not in base:
            base[code] = {"name": f.get("title") or code, "category": "事实层", "rclass": "fact"}
    _by_rule = {}
    for f in _all_findings:
        _by_rule.setdefault(f.get("rule_id") or "", []).append(f)

    out = []
    for code, meta in base.items():
        fs = _by_rule.get(code) or []
        decided = [f for f in fs if f["status"] in ("confirmed", "false_positive")]
        fp = [f for f in decided if f["status"] == "false_positive"]
        rate = len(fp) / len(decided) if decided else 0.0
        out.append({
            "rule_code": code, "name": meta["name"], "category": meta["category"],
            "rclass": meta["rclass"], "hit": len(fs), "decided": len(decided),
            "false_positive": len(fp), "override_rate": round(rate, 2),
            "suggestion": _suggest(rate, len(fs)),
        })
    return out


def feedback_to_rule(finding_id: str, decision: str, reason: str = "") -> dict:
    """人工复核写入后，即时产出该规则的进化信号。"""
    f = R.findings.get(finding_id)
    if not f:
        return {}
    fs = R.findings.list("rule_id=?", (f["rule_id"],))
    decided = [x for x in fs if x["status"] in ("confirmed", "false_positive")]
    fp = [x for x in decided if x["status"] == "false_positive"]
    rate = len(fp) / len(decided) if decided else 0.0
    return {"rule_code": f["rule_id"], "override_rate": round(rate, 2),
            "suggestion": _suggest(rate, len(fs))}


def historical_false_positive(rule_code: str, title: str) -> int:
    """负例库：某（规则,发现标题）历史上被判「误报」的次数，用于再次出现时提示。"""
    n = 0
    for d in R.decisions.list("decision=?", ("false_positive",)):
        f = R.findings.get(d["finding_id"])
        if f and f["rule_id"] == rule_code and f["title"] == title:
            n += 1
    return n


def point_suggestions() -> list:
    """按「审核点位 id」统计误报/命中，生成点位级建议（服务 302 点位库的 RSI）。"""
    from . import auditpoints as ap
    lib = ap.load()
    meta = {p.id: p for p in lib.points}
    # 按 rule_id（= 点位 id）聚合
    agg = {}
    for f in R.findings.list():
        code = f.get("rule_id") or ""
        d = agg.setdefault(code, {"hit": 0, "decided": 0, "fp": 0})
        d["hit"] += 1
        if f.get("status") in ("confirmed", "false_positive"):
            d["decided"] += 1
        if f.get("status") == "false_positive":
            d["fp"] += 1
    out = []
    for code, d in agg.items():
        p = meta.get(code)
        if not p:
            continue  # 只统计属于审核点库的点位
        rate = d["fp"] / d["decided"] if d["decided"] else 0.0
        if d["hit"] == 0:
            sug = "从未命中：建议复盘适用场景"
        elif rate >= 0.5:
            sug = "误报率过高：建议修订判据/收紧适用范围或降级等级"
        elif rate > 0.2:
            sug = "误报率偏高：建议复核判据与证据要求"
        else:
            sug = "健康"
        out.append({
            "point_id": code, "name": p.name, "category": p.category,
            "level": p.level_raw, "severity": p.severity,
            "hit": d["hit"], "decided": d["decided"], "false_positive": d["fp"],
            "override_rate": round(rate, 2), "suggestion": sug,
        })
    out.sort(key=lambda x: (-x["override_rate"], -x["hit"]))
    return out


# ===================== RSI：错题集 → 确认 → 沉淀规则库 =====================
def _task_of(finding_id: str) -> dict:
    try:
        rows = R.evolution_tasks.list("finding_id=?", (finding_id,), order="created_at DESC")
        return rows[0] if rows else {}
    except Exception:
        return {}


def feedback_list() -> list:
    """错题集（审核员反馈）：每条附处理状态。"""
    out = []
    for it in error_book():
        f = it["finding"]
        d = it["decision"]
        t = _task_of(f["id"])
        out.append({
            "finding_id": f["id"], "rule_code": f.get("rule_id") or "", "title": f.get("title") or "",
            "severity": f.get("severity") or "", "summary": f.get("summary") or "",
            "reason": d.get("reason") or "", "reviewer": d.get("user_id") or "",
            "reported_at": d.get("created_at") or "",
            "status": t.get("status") or "open",
            "root_cause": t.get("root_cause") or "", "suggestion": t.get("suggestion") or "",
            # L18（S2）：同一字段 root_cause 的展示投影（agent-fp 六类 / evolution 四类）。
            "root_cause_label": _attribution_display(t.get("root_cause") or ""),
            "root_cause_code": attribution_normalize(t.get("root_cause") or "")["code"],
            "attribution_agent_fp": attribution_normalize(t.get("root_cause") or "")["agent_fp"],
            "attribution_evolution": attribution_normalize(t.get("root_cause") or "")["evolution"],
            "attribution_known": attribution_normalize(t.get("root_cause") or "")["known"],
            "action": t.get("action") or "", "rule_id": t.get("rule_id") or "",
            "handled_at": t.get("handled_at") or "",
        })
    return out


def feedback_stats() -> dict:
    items = feedback_list()
    total = len(items)
    openn = sum(1 for x in items if x["status"] == "open")
    settled = sum(1 for x in items if x["status"] == "settled")
    ignored = sum(1 for x in items if x["status"] == "ignored")
    return {"total": total, "open": openn, "settled": settled, "ignored": ignored,
            "settle_rate": round(settled / total, 3) if total else 0.0}


def analyze_feedback(finding_id: str, user: str = "") -> dict:
    """AI 归因：分析这条误报的根因并给出规则修订建议。"""
    # F-28 服务层第二道角色校验：系统管理员/平台运营不得写审核业务。
    from . import permissions as _perms
    if _perms.actor_write_denied(user):
        return _perms.deny_write_payload("evolution.analyze")
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "发现不存在"}
    d = {}
    try:
        ds = R.decisions.list("finding_id=?", (finding_id,), order="created_at DESC")
        d = ds[0] if ds else {}
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    base = feedback_to_rule(finding_id, "false_positive", d.get("reason") or "")
    root, sugg, src = "", base.get("suggestion", ""), "heuristic"
    try:
        from . import extract as _ex
        import json as _j
        prompt = ("以下是一条被审核员判为误报的审核发现。请判断根因。统一枚举机器码："
                  "parse(解析错误)/extract(抽取错误)/rule(规则错误/判据过严)/executor(执行器错误)/"
                  "evidence(证据不足)/human_label(人工标注错误)/scope(作用域过大)；也接受中文标签"
                  "（解析/抽取/规则/执行器/证据/人工标注/判据过严/作用域过大/证据不足/原文误读）。"
                  "并给出一句可执行的规则修订建议。只输出 JSON：{\"root_cause\":\"...\",\"suggestion\":\"...\"}。\n"
                  + _j.dumps({"规则": f.get("rule_id"), "问题": f.get("title"), "描述": f.get("summary"),
                              "审核员理由": d.get("reason") or ""}, ensure_ascii=False))
        obj = _ex._json_of(_ex._chat([{"role": "user", "content": prompt}], max_tokens=300))
        if isinstance(obj, dict):
            # L18（S2）：写回同一字段 root_cause —— 已知值落统一机器码，未知值保留原值（不覆盖）。
            root = attribution_persist_value(obj.get("root_cause") or "")
            sugg = obj.get("suggestion") or sugg
            src = "llm"
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    old = _task_of(finding_id)
    if old:
        R.evolution_tasks.update(old["id"], status="analyzed", root_cause=root, suggestion=sugg)
        tid = old["id"]
    else:
        tid = db.new_id("evo")
        R.evolution_tasks.insert(id=tid, finding_id=finding_id, rule_code=f.get("rule_id") or "",
                                 title=f.get("title") or "", status="analyzed",
                                 root_cause=root, suggestion=sugg, created_at=db.now())
    R.audit_logs.log(actor=user or "system", action="evolution.analyzed", object=finding_id)
    # 契约保持 server_split_contract 的金标准顶层 keys（root_cause,source,suggestion,task_id）：
    # root_cause 已写回统一机器码；两套口径投影由 GET /api/v1/evolution/attribution 提供，
    # 不在这里扩返回键（避免路由契约漂移）。
    return {"task_id": tid, "root_cause": root, "suggestion": sugg, "source": src}


def _finding_quote(finding_id: str) -> str:
    """取误报发现的可定位引文；没有证据锚点时为空，不伪造。"""
    try:
        for e in R.evidences.list("finding_id=?", (finding_id,)):
            a = R.anchors.get(e.get("anchor_id") or "") or {}
            q = str(a.get("quote") or e.get("excerpt") or "").strip()
            if q:
                return q[:500]
    except Exception:
        logging.getLogger(__name__).debug("finding quote lookup skipped", exc_info=True)
    return ""

def settle_feedback(finding_id: str, action: str = "revise", note: str = "", user: str = "") -> dict:
    """确认沉淀：revise=修订现有规则（新版本草稿）/ new_rule=新建规则草稿 / ignore=忽略。"""
    # F-28 服务层第二道角色校验：系统管理员/平台运营不得写审核业务。
    from . import permissions as _perms
    if _perms.actor_write_denied(user):
        return _perms.deny_write_payload("evolution.settle")
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "发现不存在"}
    t = _task_of(finding_id)
    rule_code = f.get("rule_id") or ""
    rule_id = ""
    if action == "new_rule":
        name = f"{f.get('title') or rule_code}（由误报反馈生成）"
        r = rule.create_rule(code=f"RSI-{db.new_id('x')[:6].upper()}", name=name,
                             category="consistency", rclass="R3",
                             slots={"from_finding": finding_id, "rule_code": rule_code},
                             source="rsi_feedback")
        rule_id = r["rule_id"]
        status, msg = "settled", "已生成新规则草稿"
    elif action == "revise":
        rid = ""
        try:
            for r in R.rules.list():
                if (r.get("code") or "") == rule_code:
                    rid = r["id"]; break
        except Exception:
            rid = ""
        if rid:
            # B2/B3 修复（T-177）：旧沉淀路径与 UI 路径统一走规则服务的状态机口径。
            # published/approved → rule._fork_draft 克隆新草稿版本（rule.status=draft，
            # 旧 published 版本继续生效）；已是 draft 时保持旧语义「每次沉淀生成一个新草稿
            # 版本」（rsi_e2e 门禁用例按此断言，见 scripts/qa/rsi_e2e.py），再统一 patch
            # slots.false_positive_quotes。绝不直插「复制 slots」的裸版本行。
            _rrow = R.rules.get(rid) or {}
            _rstatus = str(_rrow.get("status") or "draft")
            if _rstatus in ("approved", "published"):
                try:
                    _info, _err = rule._fork_draft(rid, _rstatus, user or "system",
                                                   reason="settle_feedback")
                except rule._TransitionConflict:
                    return {"error": "concurrent_transition", "action": "revise", "rule_id": rid}
                if _err:
                    return _err
            elif _rstatus == "draft":
                _rows = R.rule_versions.list("rule_id=?", (rid,))
                R.rule_versions.insert(id=db.new_id("rv"), rule_id=rid,
                                       version=f"v0.{len(_rows) + 1}",
                                       slots_json=(_rows[-1].get("slots_json") if _rows else "{}"),
                                       evidence_json="[]", tests_json="{}", status="draft")
            else:  # pending / archived：不可编辑，如实返回
                return {"ok": False, "status": "blocked", "rule_id": rid,
                        "error": "invalid_transition",
                        "message": "规则当前状态不可修订（待审批请先回滚；已下线请先恢复）"}
            _latest = R.rules.latest_version(rid) or {}
            try:
                slots = json.loads(_latest.get("slots_json") or "{}")
            except Exception:
                slots = {}
            if not isinstance(slots, dict):
                slots = {}
            quote = _finding_quote(finding_id)
            marks = [str(x) for x in (slots.get("false_positive_quotes") or []) if str(x).strip()]
            if quote and quote not in marks:
                marks.append(quote)
            patch = {"false_positive_quotes": marks[-50:]} if marks else {}
            _upd = rule.update_slots(rid, patch, actor=user or "system")
            if _upd.get("error"):
                return {"ok": False, "status": "blocked", "rule_id": rid,
                        "error": _upd.get("error"), "message": _upd.get("message") or "修订失败"}
            rule_id = rid
            status = "settled"
            msg = (f"已生成 {rule_code} 的新版本草稿 {_upd.get('draft_version')}"
                   f"（规则进入修订中；旧生效版本 {_upd.get('effective_version') or '无'} 继续执行）"
                   + ("，含误报引文负例" if quote else ""))
        else:
            status, msg = "settled", "该规则为内置规则，已记录修订建议（需在规则库手工调整）"
    else:
        status, msg = "ignored", "已忽略"
    if t:
        R.evolution_tasks.update(t["id"], status=status, action=action, rule_id=rule_id, note=note,
                                 handled_at=db.now(), handled_by=user or "")
    else:
        R.evolution_tasks.insert(id=db.new_id("evo"), finding_id=finding_id, rule_code=rule_code,
                                 title=f.get("title") or "", status=status,
                                 root_cause="", suggestion="", action=action, rule_id=rule_id, note=note,
                                 created_at=db.now(), handled_at=db.now(), handled_by=user or "")
    # B6 两本账合一（新账）：旧路径同样把反馈台账状态同步，避免「evolution_task=settled 但
    # feedback 仍 pending」（T-172 真实库即有 34 条此类不一致；历史存量不迁移见报告 NOT DONE）。
    try:
        from . import feedback as _fb_sync
        _fbs = R.feedback.list("finding_id=?", (finding_id,), order="created_at DESC")
        if _fbs:
            _fb_sync._settle_write(_fbs[0]["id"], status=status, action=action, user=user,
                                   rule_id=rule_id, after=msg,
                                   audit_action=f"feedback.{action}")
    except Exception:
        logging.getLogger(__name__).warning("feedback ledger sync skipped", exc_info=True)
    R.audit_logs.log(actor=user or "system", action=f"evolution.{action}", object=finding_id, after=msg)
    # E1（T12，2026-11-23）：反馈处置 → 效果度量落库。度量失败只告警、不回滚业务（可用开关关闭），
    # 但必须在返回体里显式暴露 effect 状态（铁律 2：不允许静默失败）。
    effect = {}
    try:
        effect = record_effect(
            kind="feedback_settle", subject_id=finding_id,
            cycle_time_s=_effect_cycle_time(t.get("created_at") if t else ""),
            rule_code=rule_code,
            payload={"action": action, "status": status, "rule_id": rule_id,
                     "finding_id": finding_id, "rule_code": rule_code,
                     "user": str(user or "")[:80], "message": str(msg)[:300],
                     "task_id": (t or {}).get("id") or ""},
        )
    except Exception:  # noqa: BLE001 - 度量是旁路，绝不能阻断处置
        logging.getLogger(__name__).warning("evolution_effect record failed", exc_info=True)
        effect = {"status": "error"}
    return {"ok": True, "status": status, "message": msg, "rule_id": rule_id,
            "effect": effect}


# ===================== E1 自进化效果度量落库（T12，2026-11-23） =====================
# 依据：docs/CURRENT/59-自进化链路再评估_20261123.md §2 V1 / §3 S1、docs/CURRENT/56-后续工作计划v2_20261123.md E1。
# 目标（最小可用）：把 cycle_time / igain / recurrence（复发） / rollback_count / adoption_rate 5 个效果指标
# 落在 evolution_effect 表，可由只读 API（app/api/metrics_routes.py::GET /api/v1/metrics/evolution/effect）查询；
# 不再让「自进化有没有用」只停留在离线报告。
#
# 口径（写死，避免事后漂移）：
#   cycle_time_s   = 反馈进入进化池（evolution_task.created_at）→ 本次处置完成的秒数；无起点记 NULL（不猜 0）
#   igain          = 该规则已裁决 finding 的准确率相对 0.5 基线的提升 = confirmed/(confirmed+fp) - 0.5
#                    （与 calibration.replay_igain 同一口径；无已裁决样本记 NULL，不冒充 0）
#   recurrence     = 「同规则 + 同问题标题」在本次之前已处置（settled/ignored）的反馈条数（复发计数）
#   rollback_count = 该规则在 rsi_candidate 中已回滚（decision='rolled_back'）的候选次数
#   adoption_rate  = 该规则已处置反馈中 settled（采纳沉淀）占比 = settled/(settled+ignored)；无处置记 NULL
# 开关：RULEPROOF_EVOLUTION_METRICS，默认 "1"（开）；显式 "0" 回滚为不落库。
_EFFECT_ENV = "RULEPROOF_EVOLUTION_METRICS"
_EFFECT_READY = False
# L109（2026-11-25）：表/索引 DDL 单一事实源 = app/db.py 的 EVOLUTION_EFFECT_SCHEMA
# （init_db 建基线、本模块 ensure 兜底同源；evolution_effect_test.py 交叉核对）。
_EFFECT_COLS = ("id", "kind", "subject_id", "cycle_time_s", "igain", "recurrence",
                "rollback_count", "adoption_rate", "created_at", "payload_json")


def _effect_enabled() -> bool:
    """默认开；显式 RULEPROOF_EVOLUTION_METRICS=0 关闭（回滚杆，不动业务逻辑）。"""
    return str(os.environ.get(_EFFECT_ENV, "1")).strip() != "0"


def _effect_ensure_table() -> bool:
    """懒建表兜底：旧库未跑 init_db、或测试只建最小表时仍可写。

    表定义唯一真相源是 app/db.py 的 SCHEMA（两条 DDL 必须一致，测试 evolution_effect_test.py 会核对）。
    """
    global _EFFECT_READY
    if _EFFECT_READY:
        return True
    try:
        with db.session() as c:
            db.ensure_runtime_schema(c, "evolution_effect")
        _EFFECT_READY = True
        return True
    except Exception:  # noqa: BLE001 - 建表失败要让调用方看到 unavailable，不静默
        logging.getLogger(__name__).warning("evolution_effect schema init failed", exc_info=True)
        return False


def _effect_parse_ts(value) -> float | None:
    """解析 db.now() 的 ``%Y-%m-%d %H:%M:%S``（兼容 ISO 'T'+时区写法）；失败返回 None。"""
    text = str(value or "").strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            return float(time.mktime(time.strptime(text[:len("2026-11-23T12:00:00")], fmt)))
        except Exception:  # noqa: BLE001 - 换下一种格式
            continue
    # ISO 带 '+08:00' 时 strptime 已处理；带毫秒时截断到秒再试
    try:
        import datetime as _dt
        return _dt.datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()
    except Exception:  # noqa: BLE001
        return None


def _effect_cycle_time(started_at) -> float | None:
    """反馈进入进化池 → 处置完成 的秒数；起点不可解析时不猜 0，如实 NULL。"""
    start = _effect_parse_ts(started_at)
    if start is None:
        return None
    return round(max(0.0, time.time() - start), 3)


def _effect_rule_metrics(rule_code: str, finding_id: str) -> dict:
    """按规则聚合 4 个可计算指标；无样本的一律 None（不把「没数据」写成 0）。"""
    code = str(rule_code or "").strip()
    out = {"igain": None, "recurrence": 0, "rollback_count": 0, "adoption_rate": None}
    if not code:
        return out
    log = logging.getLogger(__name__)
    # igain：已裁决 finding 的准确率相对 0.5 基线
    try:
        decided = confirmed = 0
        for f in R.findings.list("rule_id=?", (code,)):
            st = str(f.get("status") or "")
            if st in ("confirmed", "false_positive"):
                decided += 1
                confirmed += 1 if st == "confirmed" else 0
        if decided:
            out["igain"] = round(confirmed / decided - 0.5, 4)
    except Exception:  # noqa: BLE001
        log.warning("effect igain failed rule=%s", code, exc_info=True)
    # recurrence：同规则 + 同标题、本次之前已处置的反馈条数
    try:
        title = ""
        f = R.findings.get(finding_id) or {}
        title = str(f.get("title") or "")
        n = 0
        for t in R.evolution_tasks.list("rule_code=?", (code,)):
            if str(t.get("status") or "") not in ("settled", "ignored"):
                continue
            if str(t.get("finding_id") or "") == str(finding_id or ""):
                continue
            if title and str(t.get("title") or "") != title:
                continue
            n += 1
        out["recurrence"] = n
    except Exception:  # noqa: BLE001
        log.warning("effect recurrence failed rule=%s", code, exc_info=True)
    # rollback_count：该规则已回滚的 RSI 候选次数（rsi_candidate.decision='rolled_back'）
    try:
        with db.session() as c:
            row = c.execute("SELECT COUNT(*) FROM rsi_candidate WHERE rule_code=? AND decision=?",
                            (code, "rolled_back")).fetchone()
        out["rollback_count"] = int(row[0] if row else 0)
    except Exception:  # noqa: BLE001
        log.warning("effect rollback_count failed rule=%s", code, exc_info=True)
    # adoption_rate：已处置反馈中 adopted=settled 的占比
    try:
        settled = ignored = 0
        for t in R.evolution_tasks.list("rule_code=?", (code,)):
            st = str(t.get("status") or "")
            if st == "settled":
                settled += 1
            elif st == "ignored":
                ignored += 1
        if settled + ignored:
            out["adoption_rate"] = round(settled / (settled + ignored), 4)
    except Exception:  # noqa: BLE001
        log.warning("effect adoption_rate failed rule=%s", code, exc_info=True)
    return out


def record_effect(kind: str, subject_id: str = "", cycle_time_s: float | None = None,
                  rule_code: str = "", igain: float | None = None,
                  recurrence: int | None = None, rollback_count: int | None = None,
                  adoption_rate: float | None = None, payload: dict | None = None) -> dict:
    """写一条效果度量。返回 {"status": inserted|disabled|unavailable|error, "id": ...}。

    · kind/subject_id 为查询键（如 kind=feedback_settle、subject_id=finding_id）；
    · 显式传入的指标优先；rule_code 非空时缺省指标按 _effect_rule_metrics 聚合；
    · 开关关闭 → status=disabled（不做任何写）。
    """
    if not _effect_enabled():
        return {"status": "disabled"}
    if not _effect_ensure_table():
        return {"status": "unavailable"}
    metrics = _effect_rule_metrics(rule_code, subject_id) if rule_code else {}
    row = {
        "id": db.new_id("eff"),
        "kind": str(kind or "unknown")[:40],
        "subject_id": str(subject_id or "")[:120],
        "cycle_time_s": cycle_time_s,
        "igain": igain if igain is not None else metrics.get("igain"),
        "recurrence": int(recurrence if recurrence is not None else metrics.get("recurrence") or 0),
        "rollback_count": int(rollback_count if rollback_count is not None
                              else metrics.get("rollback_count") or 0),
        "adoption_rate": adoption_rate if adoption_rate is not None else metrics.get("adoption_rate"),
        "created_at": db.now(),
        "payload_json": json.dumps(payload or {}, ensure_ascii=False, default=str),
    }
    try:
        with db.session() as c:
            c.execute("INSERT INTO evolution_effect(" + ",".join(_EFFECT_COLS) + ") VALUES("
                      + ",".join("?" for _ in _EFFECT_COLS) + ")",
                      tuple(row.get(k) for k in _EFFECT_COLS))
        return {"status": "inserted", "id": row["id"]}
    except Exception as e:  # noqa: BLE001 - 失败必须可见，不能伪装成功
        logging.getLogger(__name__).error("evolution_effect insert failed", exc_info=True)
        return {"status": "error", "error": f"{type(e).__name__}: {str(e)[:200]}"}


def effect_list(kind: str = "", subject_id: str = "", limit: int = 50) -> dict:
    """只读查询效果度量（时间倒序）+ 5 指标汇总。空表返回空态，不伪造数据。"""
    if not _effect_ensure_table():
        return {"format": "ruleproof.evolution_effect/v1", "status": "unavailable",
                "items": [], "summary": {"n": 0}}
    try:
        lim = max(1, min(int(limit or 50), 500))
    except (TypeError, ValueError):
        lim = 50
    where, args = [], []
    if kind:
        where.append("kind=?")
        args.append(str(kind))
    if subject_id:
        where.append("subject_id=?")
        args.append(str(subject_id))
    sql = ("SELECT " + ",".join(_EFFECT_COLS) + " FROM evolution_effect"
           + (" WHERE " + " AND ".join(where) if where else "")
           + " ORDER BY created_at DESC, rowid DESC LIMIT ?")
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(sql, tuple(args) + (lim,)).fetchall()]
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).error("evolution_effect query failed", exc_info=True)
        return {"format": "ruleproof.evolution_effect/v1", "status": "error",
                "items": [], "summary": {"n": 0}}
    items = []
    for r in rows:
        try:
            payload = json.loads(r.get("payload_json") or "{}")
        except Exception:  # noqa: BLE001 - 坏 JSON 原样返回，不丢行
            payload = {"_payload_parse_error": True}
        items.append({**r, "payload": payload})
    def _avg(key):
        vals = [r[key] for r in items if isinstance(r.get(key), (int, float))]
        return round(sum(vals) / len(vals), 4) if vals else None
    summary = {
        "n": len(items),
        "avg_cycle_time_s": _avg("cycle_time_s"),
        "avg_igain": _avg("igain"),
        "avg_recurrence": _avg("recurrence"),
        "rollback_count_sum": sum(int(r.get("rollback_count") or 0) for r in items),
        "avg_adoption_rate": _avg("adoption_rate"),
        "window": {"kind": kind or None, "subject_id": subject_id or None, "limit": lim},
    }
    return {"format": "ruleproof.evolution_effect/v1", "status": "ok",
            "items": items, "summary": summary}


# ===================== 历史回放 / 效果趋势 =====================
# 只用真实落库的 confirmed/false_positive 结论、原文/证据做回放，不生成合成样本；
# 指标无样本时一律返回 None，不把“没有样本”美化成 100% 或 0%。
_REPLAY_LABELS = ("confirmed", "false_positive")
_REPLAY_EPS = 0.001


def _ratio(num: int, den: int):
    return round(float(num) / den, 3) if den else None


def _delta(old, new):
    if old is None or new is None:
        return None
    return round(float(new) - float(old), 3)


def _pct(value) -> str:
    return f"{round(float(value) * 100, 1)}%" if value is not None else "未知"


def _version_brief(version: dict) -> dict:
    version = version or {}
    return {"id": version.get("id") or "",
            "version": version.get("version") or "",
            "status": version.get("status") or "",
            "published_at": version.get("published_at") or ""}


def _rule_row(code: str) -> dict:
    try:
        rows = R.rules.list("code=?", (code,), order="rowid DESC", limit=1)
    except Exception:
        rows = []
    return rows[0] if rows else {}


def _versions(rule_id: str) -> list:
    try:
        return R.rule_versions.list("rule_id=?", (rule_id,), order="rowid ASC")
    except Exception:
        return []


def _parse_slots(version: dict):
    if not version:
        return None, "没有规则版本"
    try:
        slots = json.loads(version.get("slots_json") or "{}")
    except Exception:
        return None, "版本槽位 JSON 不可读"
    if not isinstance(slots, dict) or not slots:
        return None, "版本槽位为空，无法执行回放"
    return slots, ""


def _latest_feedback(finding_id: str) -> dict:
    try:
        rows = R.feedback.list("finding_id=?", (finding_id,),
                               order="created_at DESC, rowid DESC", limit=1)
    except Exception:
        rows = []
    return rows[0] if rows else {}


def _latest_decision(finding_id: str) -> dict:
    try:
        rows = R.decisions.list("finding_id=?", (finding_id,),
                                order="created_at DESC, rowid DESC", limit=1)
    except Exception:
        rows = []
    return rows[0] if rows else {}


def _sample_text(finding: dict, doc_cache: dict):
    """取该发现真实对应的原文/证据；不拿 finding.summary 冒充原文。

    优先使用历史案例文档（与规则回归闸同一口径），文档缺失/不可解析时回退到
    证据摘录或锚点原文。返回 (text, basis, quote_count)。
    """
    quotes = []
    try:
        evs = R.evidences.list("finding_id=?", (finding.get("id") or "",), order="id")
    except Exception:
        evs = []
    for e in evs:
        q = str(e.get("excerpt") or "").strip()
        if not q and e.get("anchor_id"):
            try:
                anchor = R.anchors.get(e.get("anchor_id")) or {}
            except Exception:
                anchor = {}
            q = str(anchor.get("quote") or "").strip()
        if q and q not in quotes:
            quotes.append(q)
    # 证据已指明文档时只回放该文档，避免把同案例其他文档的问题算到这条反馈上
    ev_doc_ids = {str(e.get("document_id") or "") for e in evs if e.get("document_id")}
    doc_texts = []
    try:
        docs = R.cases.documents(finding.get("case_id") or "")
    except Exception:
        docs = []
    for d in sorted(docs, key=lambda x: str(x.get("id") or "")):
        if ev_doc_ids and str(d.get("id") or "") not in ev_doc_ids:
            continue
        path = str(d.get("path") or "")
        if not path or not os.path.isfile(path):
            continue
        if path in doc_cache:
            text = doc_cache[path]
        else:
            text = ""
            try:
                from ..engine import deepparse
                text = str((deepparse.parse_document(path).text or "")).strip()
            except Exception:
                logging.getLogger(__name__).debug("replay parse skipped", exc_info=True)
            doc_cache[path] = text
        if text:
            doc_texts.append(text)
    if doc_texts:
        text = "\n\n".join(doc_texts)
        # 解析器偶发丢段落时，用已落库的证据补齐触发上下文
        for q in quotes:
            if q not in text:
                text += "\n" + q
        return text, "document", len(quotes)
    if quotes:
        return "\n".join(quotes), "evidence", len(quotes)
    return "", "none", 0


def _load_history(rule_code: str, limit: int = 200):
    """读取规则最近 limit 条已复核样本；返回 (samples, total_decided, truncated)。"""
    cap = max(1, int(limit or 200))
    try:
        rows = R.findings.list(
            "rule_id=? AND status IN ('confirmed','false_positive')",
            (rule_code,), order="rowid DESC")
    except Exception:
        rows = []
    samples, total, doc_cache = [], 0, {}
    for f in rows:
        label = str(f.get("status") or "")
        if label not in _REPLAY_LABELS:
            continue
        total += 1
        if len(samples) >= cap:
            continue
        fb = _latest_feedback(f.get("id") or "")
        dec = _latest_decision(f.get("id") or "")
        text, basis, quote_count = _sample_text(f, doc_cache)
        samples.append({
            "finding_id": f.get("id") or "",
            "case_id": f.get("case_id") or "",
            "rule_version": f.get("rule_version") or "",
            "label": label,
            "expected_fail": label == "confirmed",
            "title": f.get("title") or "",
            "decided_at": fb.get("created_at") or dec.get("created_at") or "",
            "reason": str(dec.get("reason") or "")[:200],
            "feedback_kind": fb.get("kind") or "",
            "text": text,
            "basis": basis,
            "text_chars": len(text),
            "quote_count": quote_count,
        })
    return samples, total, total > len(samples)


def _eval_state(slots: dict, text: str):
    from ..engine import ruleexec
    try:
        res = ruleexec.judge_rule(dict(slots or {}), text or "", [])
        return str((res or {}).get("state") or "unknown"), ""
    except Exception as exc:
        logging.getLogger(__name__).debug("replay eval failed", exc_info=True)
        return "error", str(exc)[:160]


def _score_version(version: dict, samples: list) -> dict:
    """把一个版本跑在冻结样本集上，返回命中/召回/误报/覆盖率。"""
    slots, slots_err = _parse_slots(version)
    replayable = sum(1 for s in samples if s.get("text"))
    p = {
        "version": (version or {}).get("version") or "",
        "version_id": (version or {}).get("id") or "",
        "status": (version or {}).get("status") or "",
        "published_at": (version or {}).get("published_at") or "",
        "checked": False,
        "error": slots_err,
        "samples": len(samples),
        "replayable": replayable,
        "evaluated": 0,
        "coverage": _ratio(replayable, len(samples)),
        "evaluated_coverage": None,
        "hit": 0,
        "hit_rate": None,
        "recall": None,
        "false_positive_rate": None,
        "precision": None,
        "confusion": {"tp": 0, "fn": 0, "fp": 0, "tn": 0},
        "confirmed": {"total": 0, "replayable": 0, "evaluated": 0, "hit": 0},
        "false_positive": {"total": 0, "replayable": 0, "evaluated": 0, "hit": 0},
        "states": {},
        "basis": {},
        "execution_errors": 0,
        "details": [],
    }
    for s in samples:
        if s.get("text"):
            p["basis"][s["basis"]] = int(p["basis"].get(s["basis"], 0)) + 1
    if not slots:
        return p
    p["checked"] = True
    for s in samples:
        label = s["label"]
        bucket = p["confirmed"] if label == "confirmed" else p["false_positive"]
        bucket["total"] += 1
        detail = {
            "finding_id": s["finding_id"],
            "case_id": s["case_id"],
            "label": label,
            "title": s["title"],
            "expected_fail": s["expected_fail"],
            "source_rule_version": s["rule_version"],
            "feedback_kind": s["feedback_kind"],
            "decided_at": s["decided_at"],
            "basis": s["basis"],
            "evidence_quotes": s["quote_count"],
            "text_chars": s["text_chars"],
            "state": "",
            "fired": False,
            "outcome": "",
            "error": "",
            "reason": s["reason"],
        }
        if not s["text"]:
            detail["outcome"] = "not_replayable"
            p["details"].append(detail)
            continue
        bucket["replayable"] += 1
        state, eval_err = _eval_state(slots, s["text"])
        p["states"][state] = int(p["states"].get(state, 0)) + 1
        detail["state"] = state
        if state not in ("满足", "不满足", "证据不足", "不适用"):
            detail["outcome"] = "error"
            detail["error"] = eval_err or state
            p["execution_errors"] += 1
            p["details"].append(detail)
            continue
        fired = state == "不满足"
        if fired:
            p["hit"] += 1
            bucket["hit"] += 1
        if label == "confirmed":
            outcome = "tp" if fired else "fn"
        else:
            outcome = "fp" if fired else "tn"
        p["confusion"][outcome] += 1
        p["evaluated"] += 1
        bucket["evaluated"] += 1
        detail["fired"] = fired
        detail["outcome"] = outcome
        p["details"].append(detail)
    tp, fn = p["confusion"]["tp"], p["confusion"]["fn"]
    fp, tn = p["confusion"]["fp"], p["confusion"]["tn"]
    p["evaluated_coverage"] = _ratio(p["evaluated"], len(samples))
    p["hit_rate"] = _ratio(p["hit"], p["evaluated"])
    p["recall"] = _ratio(tp, tp + fn)
    p["false_positive_rate"] = _ratio(fp, fp + tn)
    p["precision"] = _ratio(tp, tp + fp)
    return p


def _recommend_single(p: dict) -> dict:
    if not p.get("checked"):
        return {"action": "fix_version",
                "reason": p.get("error") or "规则版本不可执行",
                "signals": ["invalid_version"]}
    if p["replayable"] == 0:
        return {"action": "insufficient_data",
                "reason": "历史样本缺少可回放原文/证据，无法计算命中、召回或误报率；未按 0% 或 100% 处理",
                "signals": ["no_replayable_text"]}
    if p["evaluated"] == 0:
        return {"action": "fix_execution",
                "reason": f"{p['replayable']} 条样本规则执行失败，无法形成有效回放指标",
                "signals": ["execution_failed"]}
    signals = []
    conf, fp = p["confirmed"], p["false_positive"]
    recall, fpr = p["recall"], p["false_positive_rate"]
    if conf["evaluated"] == 0:
        signals.append("no_confirmed_samples")
    if fp["evaluated"] == 0:
        signals.append("no_false_positive_samples")
    if recall is not None:
        if recall <= 0:
            signals.append("zero_recall")
        elif recall < 1:
            signals.append("recall_loss")
    if fpr is not None:
        if fpr >= 0.5:
            signals.append("high_false_positive")
        elif fpr > 0.2:
            signals.append("elevated_false_positive")
    if p["coverage"] is not None and p["coverage"] < 0.5:
        signals.append("low_coverage")
    if p["evaluated"] < 3:
        signals.append("small_sample")
    if p["evaluated"] and p["states"].get("不适用", 0) > p["evaluated"] * 0.5:
        signals.append("mostly_not_applicable")
    tp, fn = p["confusion"]["tp"], p["confusion"]["fn"]
    fp_n, tn = p["confusion"]["fp"], p["confusion"]["tn"]
    if "zero_recall" in signals:
        action = "rollback_or_revise"
        reason = (f"历史确认样本仍命中 {tp}/{tp + fn}（回放召回 0%），"
                  f"误报复现 {fp_n}/{fp_n + tn}；建议回滚或修订判据/作用域")
    elif "high_false_positive" in signals:
        action = "tighten_scope"
        reason = (f"历史误报样本复现 {fp_n}/{fp_n + tn}（误报复现率 {_pct(fpr)}），"
                  f"确认命中 {tp}/{tp + fn}；建议收紧作用域或调整阈值")
    elif "recall_loss" in signals:
        action = "revise"
        reason = (f"历史确认样本仍命中 {tp}/{tp + fn}（回放召回 {_pct(recall)}），"
                  "较历史复核出现漏报；建议修订判据")
    elif "elevated_false_positive" in signals:
        action = "review_threshold"
        reason = (f"历史误报样本复现 {fp_n}/{fp_n + tn}（误报复现率 {_pct(fpr)}），"
                  "建议复核阈值/单位/作用域")
    elif "no_false_positive_samples" in signals:
        action = "expand_samples"
        reason = (f"历史确认样本命中 {tp}/{tp + fn}，但没有可评估的误报样本，"
                  "误报趋势未知；建议补充反例后再下结论")
    elif "no_confirmed_samples" in signals:
        action = "expand_samples"
        reason = (f"历史误报样本复现 {fp_n}/{fp_n + tn}，但没有可评估的确认样本，"
                  "召回未知；建议补充正例后再下结论")
    elif "low_coverage" in signals:
        action = "expand_samples"
        reason = (f"仅 {p['replayable']}/{p['samples']} 条历史样本有可回放原文/证据，"
                  "覆盖不足；建议补充证据链或原文")
    elif "small_sample" in signals:
        action = "monitor"
        reason = (f"有效样本仅 {p['evaluated']} 条，当前确认命中 {tp}/{tp + fn}、"
                  f"误报复现 {fp_n}/{fp_n + tn}；建议继续积累复核样本")
    else:
        action = "keep"
        reason = (f"历史确认命中 {tp}/{tp + fn}，误报复现 {fp_n}/{fp_n + tn}，"
                  f"覆盖 {_pct(p['coverage'])}；当前版本与历史复核结论一致")
    if "mostly_not_applicable" in signals:
        reason += "；多数样本判定为不适用，请检查适用条件/作用域"
    if p["status"] and p["status"] != "published":
        reason += "；当前为草稿版本，结果仅用于发布前评估"
    return {"action": action, "reason": reason, "signals": signals,
            "sample_size": p["evaluated"]}


def _trend_direction(first: dict, last: dict) -> str:
    dr = _delta(first.get("recall"), last.get("recall"))
    df = _delta(first.get("false_positive_rate"), last.get("false_positive_rate"))
    if dr is None and df is None:
        return "insufficient_data"
    if dr is None:
        if df < -_REPLAY_EPS:
            return "improving"
        if df > _REPLAY_EPS:
            return "degrading"
        return "flat"
    if df is None:
        if dr > _REPLAY_EPS:
            return "improving"
        if dr < -_REPLAY_EPS:
            return "degrading"
        return "flat"
    good_recall, bad_recall = dr > _REPLAY_EPS, dr < -_REPLAY_EPS
    good_fp, bad_fp = df < -_REPLAY_EPS, df > _REPLAY_EPS
    if (good_recall or good_fp) and not (bad_recall or bad_fp):
        return "improving"
    if (bad_recall or bad_fp) and not (good_recall or good_fp):
        return "degrading"
    if not (good_recall or bad_recall or good_fp or bad_fp):
        return "flat"
    return "mixed"


def _recommend_trend(points: list, current: dict, previous: dict,
                     delta: dict, trend: str) -> dict:
    latest = points[-1] if points else {}
    if latest and not latest.get("checked"):
        return {"action": "fix_version",
                "reason": (f"最新版本 {latest.get('version') or ''} 槽位不可执行："
                           f"{latest.get('error') or ''}").strip(),
                "signals": ["invalid_latest_version"]}
    if current is None:
        return {"action": "insufficient_data",
                "reason": "没有可回放的版本/样本，未生成趋势；未按 100% 或 0% 处理",
                "signals": ["insufficient_data"]}
    if previous is None:
        base = _recommend_single(current)
        if base["action"] in ("keep", "monitor", "expand_samples"):
            return {"action": "baseline_only",
                    "reason": (f"只有 {current['version']} 一个可回放版本，已建立基线；"
                               "需要下一版本发布后才能对比趋势"),
                    "signals": base["signals"] + ["single_version"],
                    "sample_size": current["evaluated"]}
        return base
    signals = []
    d_recall = (delta or {}).get("recall")
    d_fpr = (delta or {}).get("false_positive_rate")
    if current["recall"] is not None and current["recall"] <= 0:
        signals.append("zero_recall")
    if current["false_positive_rate"] is not None and current["false_positive_rate"] >= 0.5:
        signals.append("high_false_positive")
    if d_recall is not None and d_recall < -_REPLAY_EPS:
        signals.append("recall_drop")
    if d_fpr is not None and d_fpr > _REPLAY_EPS:
        signals.append("false_positive_increase")
    if current["confirmed"]["evaluated"] == 0:
        signals.append("no_confirmed_samples")
    if current["false_positive"]["evaluated"] == 0:
        signals.append("no_false_positive_samples")
    if current["coverage"] is not None and current["coverage"] < 0.5:
        signals.append("low_coverage")
    if current["evaluated"] < 3:
        signals.append("small_sample")
    if trend == "improving":
        signals.append("improving")
    elif trend == "degrading":
        signals.append("degrading")
    elif trend == "mixed":
        signals.append("mixed")
    tp, fn = current["confusion"]["tp"], current["confusion"]["fn"]
    fp_n, tn = current["confusion"]["fp"], current["confusion"]["tn"]
    if "zero_recall" in signals:
        action = "rollback_or_revise"
        reason = (f"最新版本 {current['version']} 回放召回 0%（{tp}/{tp + fn}），"
                  f"较上一个可回放版本 {previous['version']} 的 {_pct(previous['recall'])} 下降明显；"
                  "建议回滚或修订")
    elif "high_false_positive" in signals:
        action = "tighten_scope"
        reason = (f"最新版本误报复现率 {_pct(current['false_positive_rate'])}"
                  f"（{fp_n}/{fp_n + tn}），建议收紧作用域或阈值")
    elif "recall_drop" in signals:
        action = "rollback_or_revise"
        reason = (f"较上一个可回放版本 {previous['version']} 召回从 {_pct(previous['recall'])} "
                  f"降至 {_pct(current['recall'])}，出现回归；建议回滚或修订")
    elif "false_positive_increase" in signals:
        action = "tighten_scope"
        reason = (f"较上一个可回放版本 {previous['version']} 误报复现率从 "
                  f"{_pct(previous['false_positive_rate'])} 升至 "
                  f"{_pct(current['false_positive_rate'])}；建议收紧作用域或阈值")
    elif "no_false_positive_samples" in signals:
        action = "expand_samples"
        reason = "趋势样本缺少误报反例，无法判断误报变化；建议补充反例"
    elif "no_confirmed_samples" in signals:
        action = "expand_samples"
        reason = "趋势样本缺少确认正例，无法判断召回变化；建议补充正例"
    elif "low_coverage" in signals:
        action = "expand_samples"
        reason = (f"仅 {current['replayable']}/{current['samples']} 条样本可回放，"
                  "趋势覆盖不足；建议补充原文/证据")
    elif trend == "improving":
        action = "keep"
        reason = (f"较上一个可回放版本 {previous['version']}，召回 {_pct(previous['recall'])} → "
                  f"{_pct(current['recall'])}，误报复现率 "
                  f"{_pct(previous['false_positive_rate'])} → "
                  f"{_pct(current['false_positive_rate'])}；效果改善")
    elif trend == "degrading":
        action = "revise"
        reason = "最近一个版本相对首版本出现效果下降；建议复核规则修订"
    elif "small_sample" in signals:
        action = "monitor"
        reason = (f"有效样本仅 {current['evaluated']} 条，趋势置信有限；"
                  "建议继续积累复核样本")
    else:
        action = "keep"
        reason = (f"最新版本 {current['version']} 召回 {_pct(current['recall'])}、"
                  f"误报复现率 {_pct(current['false_positive_rate'])}，"
                  "与上一个可回放版本相比无退化")
    if current["status"] != "published":
        reason += "；当前版本为草稿，趋势仅用于发布前评估"
    rec = {"action": action, "reason": reason, "signals": signals,
           "sample_size": current["evaluated"]}
    if (action == "rollback_or_revise" and previous is not None
            and previous.get("status") == "published"):
        # 只给建议目标，不自动回滚；调用方可用 rule.restore_version 生成新草稿
        rec["rollback_to"] = previous.get("version") or ""
        rec["rollback_version_id"] = previous.get("version_id") or ""
    return rec


def _replay_notes(samples: list, total: int, truncated: bool,
                  version: dict, p: dict) -> list:
    notes = []
    if truncated:
        notes.append(f"仅回放最近 {len(samples)} 条已复核样本（共 {total} 条），不是全量历史")
    missing = len(samples) - p["replayable"]
    if missing:
        notes.append(f"{missing} 条已复核样本缺少原文/证据摘录，未计入召回/误报分母")
    failed = p["replayable"] - p["evaluated"]
    if failed:
        notes.append(f"{failed} 条样本规则执行失败，未计入指标")
    if p["basis"].get("evidence"):
        notes.append("部分样本使用历史证据摘录回放（触发上下文，不一定是完整原文）")
    if (version or {}).get("status") and version["status"] != "published":
        notes.append("回放对象不是已发布版本，结果不代表线上效果")
    if p["evaluated"] and p["states"].get("不适用", 0) > p["evaluated"] * 0.5:
        notes.append("多数样本判定为不适用，请检查适用条件/作用域")
    notes.append("本回放只读历史 confirmed/false_positive 结论，不修改规则或反馈")
    return notes


def _trend_notes(samples: list, total: int, truncated: bool,
                 points: list, current: dict) -> list:
    notes = []
    if truncated:
        notes.append(f"仅回放最近 {len(samples)} 条已复核样本（共 {total} 条），不是全量历史")
    if current is None:
        notes.append("没有可回放的有效样本，未生成趋势（不按 100% 或 0% 处理）")
    else:
        missing = len(samples) - current["replayable"]
        if missing:
            notes.append(f"{missing} 条样本缺少原文/证据摘录，未计入趋势分母")
        if current["basis"].get("evidence"):
            notes.append("部分样本使用历史证据摘录回放（触发上下文，不一定是完整原文）")
    if len([p for p in points if p.get("evaluated")]) < 2:
        notes.append("可回放版本不足两个，暂不能形成版本间趋势")
    if points and not points[-1].get("checked"):
        notes.append("最新版本槽位不可执行，趋势使用最近一个可回放版本")
    if current is not None and current["status"] != "published":
        notes.append("当前比较版本不是已发布版本，趋势仅用于发布前评估")
    notes.append("本回放只读历史 confirmed/false_positive 结论，不修改规则或反馈")
    return notes


def replay_rule(rule_code: str, version: str = "", limit: int = 200) -> dict:
    """只读回放：把指定规则版本（默认最新版本）跑在历史复核样本上。

    样本来自 finding.status 为 confirmed/false_positive 的真实历史结论；文本优先取
    案例原文，缺失时回退到证据摘录，绝不使用 summary 合成样本。返回命中/召回/误报
    /覆盖率及推荐动作。没有样本或没有可回放文本时指标为 None，不冒充 100%。
    """
    code = str(rule_code or "").strip()
    out = {
        "rule_code": code, "rule_id": "", "rule_name": "", "rule_status": "",
        "checked": False, "status": "no_rule", "reason": "",
        "version": None,
        "history_total": 0, "selected": 0, "truncated": False,
        "replayable": 0, "evaluated": 0,
        "coverage": None, "evaluated_coverage": None,
        "hit": 0, "hit_rate": None, "recall": None,
        "false_positive_rate": None, "precision": None,
        "confusion": {"tp": 0, "fn": 0, "fp": 0, "tn": 0},
        "confirmed": {"total": 0, "replayable": 0, "evaluated": 0, "hit": 0},
        "false_positive": {"total": 0, "replayable": 0, "evaluated": 0, "hit": 0},
        "states": {}, "basis": {}, "details": [],
        "recommendation": {"action": "insufficient_data",
                           "reason": "未执行回放", "signals": ["not_run"]},
        "notes": [],
    }
    if not code:
        out["reason"] = "规则编码为空"
        return out
    r = _rule_row(code)
    if not r:
        out["reason"] = "规则不存在或当前上下文不可见"
        return out
    out["rule_id"] = r.get("id") or ""
    out["rule_name"] = r.get("name") or ""
    out["rule_status"] = r.get("status") or ""
    versions = _versions(out["rule_id"])
    if not versions:
        out["status"] = "no_version"
        out["reason"] = "规则没有版本化槽位，无法回放；内置/旧规则可能属于此类"
        return out
    if version:
        found = next((x for x in versions
                      if str(x.get("id") or "") == str(version)
                      or str(x.get("version") or "") == str(version)), None)
        if not found:
            out["status"] = "version_not_found"
            out["reason"] = f"未找到版本 {version}"
            return out
    else:
        found = versions[-1]
    out["version"] = _version_brief(found)
    samples, total, truncated = _load_history(code, limit)
    p = _score_version(found, samples)
    for key in ("checked", "replayable", "evaluated", "coverage", "evaluated_coverage",
                "hit", "hit_rate", "recall", "false_positive_rate", "precision",
                "confusion", "confirmed", "false_positive", "states", "basis"):
        out[key] = p[key]
    out["details"] = p["details"]
    out["history_total"] = total
    out["selected"] = len(samples)
    out["truncated"] = truncated
    out["recommendation"] = _recommend_single(p)
    out["notes"] = _replay_notes(samples, total, truncated, found, p)
    if not p["checked"]:
        out["status"] = "invalid_version"
        out["reason"] = p["error"] or "版本槽位不可执行"
        return out
    if total == 0:
        out["status"] = "no_samples"
        out["reason"] = "没有历史 confirmed/false_positive 样本，未计算命中/召回/误报（不返回 100%）"
        return out
    if p["replayable"] == 0:
        out["status"] = "no_replayable_samples"
        out["reason"] = "有历史复核样本，但均缺少可回放原文/证据摘录，指标保持未知"
        return out
    if p["evaluated"] == 0:
        out["status"] = "execution_failed"
        out["reason"] = "样本有回放文本，但规则执行失败，未形成有效指标"
        return out
    out["status"] = "ok"
    out["reason"] = ""
    return out


def effect_trend(rule_code: str, limit: int = 200, version: str = "") -> dict:
    """按规则版本顺序回放同一批历史样本，输出召回/误报/命中趋势与推荐动作。

    只比较真实存在的版本；没有样本时 points 保留版本但指标为 None，current/趋势为空。
    version 非空时截止到该版本（含），用于评估“若把该版本当当前版本”的回滚建议。
    """
    code = str(rule_code or "").strip()
    requested_version = str(version or "").strip()
    out = {
        "rule_code": code, "rule_id": "", "rule_name": "", "rule_status": "",
        "checked": False, "status": "no_rule", "reason": "",
        "requested_version": requested_version,
        "history_total": 0, "selected": 0, "truncated": False,
        "replayable": 0, "coverage": None,
        "points": [], "current": None, "previous": None, "delta": None,
        "trend": "insufficient_data",
        "recommendation": {"action": "insufficient_data",
                           "reason": "未执行回放", "signals": ["not_run"]},
        "notes": [],
    }
    if not code:
        out["reason"] = "规则编码为空"
        return out
    r = _rule_row(code)
    if not r:
        out["reason"] = "规则不存在或当前上下文不可见"
        return out
    out["rule_id"] = r.get("id") or ""
    out["rule_name"] = r.get("name") or ""
    out["rule_status"] = r.get("status") or ""
    versions = _versions(out["rule_id"])
    if not versions:
        out["status"] = "no_version"
        out["reason"] = "规则没有版本化槽位，无法回放；内置/旧规则可能属于此类"
        return out
    if requested_version:
        idx = next((i for i, x in enumerate(versions)
                    if str(x.get("id") or "") == requested_version
                    or str(x.get("version") or "") == requested_version), -1)
        if idx < 0:
            out["status"] = "version_not_found"
            out["reason"] = f"未找到版本 {requested_version}"
            return out
        versions = versions[:idx + 1]
    samples, total, truncated = _load_history(code, limit)
    points = []
    for v in versions:
        p = _score_version(v, samples)
        p.pop("details", None)
        points.append(p)
    out["points"] = points
    out["history_total"] = total
    out["selected"] = len(samples)
    out["truncated"] = truncated
    out["checked"] = any(p.get("checked") for p in points)
    if points:
        out["replayable"] = points[-1].get("replayable", 0)
        out["coverage"] = points[-1].get("coverage")
    evaluated_points = [p for p in points if p.get("evaluated", 0) > 0]
    current = evaluated_points[-1] if evaluated_points else None
    previous = evaluated_points[-2] if len(evaluated_points) >= 2 else None
    out["current"] = current
    out["previous"] = previous
    delta = None
    if current is not None and previous is not None:
        delta = {
            "recall": _delta(previous.get("recall"), current.get("recall")),
            "false_positive_rate": _delta(previous.get("false_positive_rate"),
                                           current.get("false_positive_rate")),
            "hit": int(current.get("hit", 0)) - int(previous.get("hit", 0)),
            "coverage": _delta(previous.get("coverage"), current.get("coverage")),
        }
    out["delta"] = delta
    out["trend"] = (_trend_direction(evaluated_points[0], evaluated_points[-1])
                    if len(evaluated_points) >= 2 else "insufficient_history")
    out["recommendation"] = _recommend_trend(points, current, previous, delta, out["trend"])
    out["notes"] = _trend_notes(samples, total, truncated, points, current)
    if requested_version:
        out["notes"].append(f"趋势仅统计到指定版本 {requested_version}（含），未使用其后的版本")
    if not out["checked"]:
        out["status"] = "invalid_version"
        out["reason"] = "所有版本槽位均不可执行"
    elif total == 0:
        out["status"] = "no_samples"
        out["reason"] = "没有历史 confirmed/false_positive 样本，未生成趋势（不返回 100%）"
    elif current is None:
        if out["replayable"] == 0:
            out["status"] = "no_replayable_samples"
            out["reason"] = "有历史样本但均缺少可回放原文/证据摘录，趋势保持未知"
        else:
            out["status"] = "execution_failed"
            out["reason"] = "样本有回放文本但规则执行失败，未形成有效趋势"
    else:
        out["status"] = "ok"
        out["reason"] = ""
    return out


# ===================== HTTP / CLI 适配：历史回放 / 效果趋势 / 回滚建议 =====================
# 产品边界：
# - replay/trend 只读历史 confirmed/false_positive，不写规则、不改反馈；
# - rollback_to 只是建议目标，本模块绝不调用 rule.restore_version / rb.rollback；
# - 空样本保持 None，HTTP/CLI 都不得把它包装成 100% 或 0%；
# - 权限：查看需 evo.view（管理员/审核员默认可见），请求回滚建议需 evo.manage；
# - 审计：只有“生成回滚建议”写 audit_log，action=evolution.rollback_suggested。
_EVOLUTION_VIEW_ROLES = ("admin", "super_admin", "reviewer")
_EVOLUTION_MANAGE_ROLES = ("admin", "super_admin")
_EVOLUTION_HTTP_PARTS = ("api", "v1", "evolution", "rules")
_HTTP_LIMIT_MAX = 1000


def _user_id(user) -> str:
    u = user or {}
    return str(u.get("sub") or u.get("id") or "")


def user_can_view(user) -> bool:
    """是否可查看进化回放/趋势：角色默认允许，也兼容自定义角色授权。"""
    u = user or {}
    if str(u.get("role") or "") in _EVOLUTION_VIEW_ROLES:
        return True
    uid = _user_id(u)
    if not uid:
        return False
    try:
        from . import permissions
        return bool(permissions.has(uid, "evo.view") or permissions.has(uid, "evo.manage"))
    except Exception:
        return False


def user_can_manage(user) -> bool:
    """是否可请求回滚建议：建议会写审计，按管理动作要求 evo.manage。"""
    u = user or {}
    if str(u.get("role") or "") in _EVOLUTION_MANAGE_ROLES:
        return True
    uid = _user_id(u)
    if not uid:
        return False
    try:
        from . import permissions
        return bool(permissions.has(uid, "evo.manage"))
    except Exception:
        return False


def _trend_metrics(point: dict) -> dict:
    """把趋势点压缩成建议里可展示的指标；无样本时全部保留 None。"""
    p = point or {}
    return {
        "version": p.get("version") or "",
        "version_id": p.get("version_id") or "",
        "status": p.get("status") or "",
        "evaluated": int(p.get("evaluated") or 0),
        "recall": p.get("recall"),
        "false_positive_rate": p.get("false_positive_rate"),
        "precision": p.get("precision"),
        "hit": int(p.get("hit") or 0),
        "hit_rate": p.get("hit_rate"),
        "coverage": p.get("coverage"),
        "confusion": p.get("confusion") or {"tp": 0, "fn": 0, "fp": 0, "tn": 0},
    }


def rollback_suggestion(rule_code: str, version: str = "", limit: int = 200,
                        user: str = "", source: str = "api") -> dict:
    """生成回滚建议（只读规则，不执行回滚）。

    返回值中的 rollback_to/rollback_version_id 来自 effect_trend 的推荐；
    applied 恒为 False，requires_manual_confirm 恒为 True。管理员确认后仍需显式调用
    rule.restore_version 走原有审批/审计链路，本函数不会修改任何规则/版本/反馈。
    """
    code = str(rule_code or "").strip()
    trend = effect_trend(code, limit=limit, version=version)
    status = str(trend.get("status") or "")
    rec = dict(trend.get("recommendation") or {})
    current = trend.get("current") or {}
    previous = trend.get("previous") or {}
    exists = status not in ("no_rule", "version_not_found")
    rollback_to = str(rec.get("rollback_to") or "") if exists else ""
    rollback_version_id = str(rec.get("rollback_version_id") or "") if exists else ""
    out = {
        "rule_code": code,
        "rule_id": trend.get("rule_id") or "",
        "rule_name": trend.get("rule_name") or "",
        "rule_status": trend.get("rule_status") or "",
        "status": status,
        "status_reason": trend.get("reason") or "",
        "checked": bool(trend.get("checked")),
        "requested_version": trend.get("requested_version") or "",
        "current_version": current.get("version") or "",
        "previous_version": previous.get("version") or "",
        "action": rec.get("action") or "",
        "reason": rec.get("reason") or "",
        "signals": rec.get("signals") or [],
        "rollback_to": rollback_to or None,
        "rollback_version_id": rollback_version_id or None,
        "recommended": bool(rollback_to),
        "applied": False,
        "auto_applied": False,
        "requires_manual_confirm": True,
        "sample_size": int(rec.get("sample_size") or current.get("evaluated") or 0),
        "metrics_available": status == "ok" and current.get("evaluated", 0) > 0,
        "current_metrics": _trend_metrics(current) if current else None,
        "previous_metrics": _trend_metrics(previous) if previous else None,
        "note": ("只给建议，不自动回滚、不修改规则；需管理员人工确认后走规则回滚/审批流程"
                 if rollback_to else
                 "当前没有可建议的回滚目标；本结果不修改规则"),
    }
    if exists:
        audit_payload = {
            "rule_code": code, "action": out["action"],
            "rollback_to": out["rollback_to"],
            "rollback_version_id": out["rollback_version_id"],
            "current_version": out["current_version"],
            "previous_version": out["previous_version"],
            "recommended": out["recommended"], "applied": False,
            "sample_size": out["sample_size"], "source": str(source or "api"),
        }
        R.audit_logs.log(actor=user or "system", action="evolution.rollback_suggested",
                         object=code, after=json.dumps(audit_payload, ensure_ascii=False))
    return out


def _http_error(status: int, error: str, code: str, **extra) -> tuple:
    out = {"ok": False, "status": status, "code": code, "error": error}
    out.update(extra)
    return status, out


def _http_data(data: dict, code: str) -> tuple:
    """服务结果 → HTTP；只有“规则/版本不存在”是 404，空样本仍是 200。"""
    status = str((data or {}).get("status") or "")
    if status in ("no_rule", "version_not_found"):
        err_code = "version_not_found" if status == "version_not_found" else "not_found"
        return _http_error(404, (data or {}).get("status_reason")
                           or (data or {}).get("reason") or "规则不存在",
                           err_code, rule_code=(data or {}).get("rule_code") or code,
                           detail_status=status)
    return 200, {"ok": True, **dict(data or {})}


def _query_value(query, key: str) -> str:
    if not isinstance(query, dict):
        return ""
    v = query.get(key)
    if isinstance(v, (list, tuple)):
        v = v[0] if v else ""
    return str(v if v is not None else "")


def _request_value(query, body, key: str) -> str:
    """query 优先，POST JSON body 兜底（两者都不传时返回空串）。"""
    value = _query_value(query, key)
    if value or not isinstance(body, dict):
        return value
    return str(body.get(key) if body.get(key) is not None else "")


def _http_limit(query, body=None) -> tuple:
    raw = _request_value(query, body, "limit")
    if not raw:
        return 200, ""
    try:
        n = int(raw)
    except (TypeError, ValueError):
        return None, "limit 必须是整数"
    if n < 1 or n > _HTTP_LIMIT_MAX:
        return None, f"limit 必须在 1-{_HTTP_LIMIT_MAX} 之间"
    return n, ""


def _http_path_parts(path: str) -> list:
    raw = str(path or "").split("?", 1)[0].strip("/")
    return [urllib.parse.unquote(x) for x in raw.split("/") if x]


def _http_route_parts(path: str):
    """解析进化端点路径，返回 (rule_code, action) 或 None。

    兼容两种写法（后者与现有 /api/v1/evolution/<code>/draft 风格一致）：
      /api/v1/evolution/rules/<code>/<action>
      /api/v1/evolution/<code>/<action>
    """
    parts = _http_path_parts(path)
    if len(parts) == 6 and tuple(parts[:4]) == _EVOLUTION_HTTP_PARTS:
        return parts[4], parts[5]
    if len(parts) == 5 and tuple(parts[:3]) == ("api", "v1", "evolution"):
        return parts[3], parts[4]
    return None


def http_route(method: str, path: str, query=None, body=None, user=None) -> tuple | None:
    """进化 HTTP 路由（纯函数，返回 (status, body)；非本模块路径返回 None）。

    端点（也支持省略 /rules 的等价写法）：
      GET  /api/v1/evolution/rules/<code>/replay?version=&limit=
      GET  /api/v1/evolution/rules/<code>/trend?version=&limit=
      POST /api/v1/evolution/rules/<code>/rollback-suggestion?version=&limit=

    权限先于资源解析：无权限返回 403，不暴露规则是否存在；规则/版本不存在返回 404。
    空样本返回 200 + status=no_samples，指标为 None，不冒充 100%/0%。
    """
    route = _http_route_parts(path)
    if route is None:
        return None
    code, action = route
    method = str(method or "").upper()
    _actions = ("replay", "trend", "rollback-suggestion",
                "hitl-approve", "hitl-reject", "hitl-status", "rollback")
    if action not in _actions:
        return None
    if not code:
        return _http_error(404, "规则编码为空", "not_found")
    if not _user_id(user):
        return _http_error(401, "未登录", "unauthorized")
    # ---- L131 自进化上线闸口：人工审批 / 拒绝 / 审批状态 / 一键回滚 ----
    if action == "hitl-status":
        if method != "GET":
            return _http_error(405, "审批状态为只读，请使用 GET", "method_not_allowed")
        if not user_can_view(user):
            return _http_error(403, "无权限：需要 evo.view", "forbidden")
        try:
            from . import rsi_protocol as _rsi_proto
            deep = str(_query_value(query, "deep") or "").strip().lower() in (
                "1", "true", "yes", "on")
            return _http_data(_rsi_proto.hitl_status(code, user=user, deep=deep), code)
        except Exception as e:  # noqa: BLE001 - 状态读取失败必须可见
            return _http_error(500, "审批状态读取失败：%s" % type(e).__name__,
                               "storage_unavailable")
    if action in ("hitl-approve", "hitl-reject", "rollback"):
        if method != "POST":
            return _http_error(405, "该动作为写操作，请使用 POST", "method_not_allowed")
        if not user_can_manage(user):
            return _http_error(403, "无权限：需要 evo.manage", "forbidden")
        from . import rsi_protocol as _rsi_proto
        uid = _user_id(user)
        try:
            if action == "hitl-approve":
                payload = body if isinstance(body, dict) else {}
                out = _rsi_proto.approve_candidate(
                    code, by=uid, user=user,
                    note=str(payload.get("note") or ""),
                    golden=payload.get("golden"),
                    ack_insufficient_evidence=bool(
                        payload.get("ack_insufficient_evidence") is True))
            elif action == "hitl-reject":
                payload = body if isinstance(body, dict) else {}
                out = _rsi_proto.reject_candidate(
                    code, by=uid, user=user,
                    reason=str(payload.get("reason") or ""))
            else:
                out = _rsi_proto.rollback_evolution_candidate(code, by=uid, user=user)
        except Exception as e:  # noqa: BLE001 - 失败必须返回 5xx（不假成功）
            return _http_error(500, "L131 动作执行失败：%s" % type(e).__name__,
                               "internal_error")
        _status = 200
        if not isinstance(out, dict):
            return _http_error(500, "L131 动作返回格式非法", "internal_error")
        if not out.get("ok"):
            _status = int(out.get("status") or 0)
            if _status not in (400, 403, 404, 409, 422, 500, 503):
                _status = 409 if out.get("blocked") else 400
        return _status, out
    limit, limit_error = _http_limit(query, body)
    version = _request_value(query, body, "version")
    if action in ("replay", "trend"):
        if method != "GET":
            return _http_error(405, "写操作请使用 POST", "method_not_allowed")
        if not user_can_view(user):
            return _http_error(403, "无权限：需要 evo.view", "forbidden")
        if limit_error:
            return _http_error(400, limit_error, "invalid_argument")
        if action == "replay":
            return _http_data(replay_rule(code, version=version, limit=limit), code)
        return _http_data(effect_trend(code, limit=limit, version=version), code)
    # rollback-suggestion：只生成建议 + 审计，不写规则
    if method != "POST":
        return _http_error(405, "回滚建议请使用 POST", "method_not_allowed")
    if not user_can_manage(user):
        return _http_error(403, "无权限：需要 evo.manage", "forbidden")
    if limit_error:
        return _http_error(400, limit_error, "invalid_argument")
    data = rollback_suggestion(code, version=version, limit=limit,
                               user=_user_id(user), source="http")
    return _http_data(data, code)


def _evolution_module_off(user) -> bool:
    """与 /api/v1/evolution 现有 GET 路由同口径：空间显式关闭模块则拒绝。"""
    try:
        from . import workspaces
        cur = workspaces.current(_user_id(user))
        return workspaces.explicit_off(cur.get("id", ""), "mod_evolution")
    except Exception:
        return False


def handle_http(handler, method: str) -> bool:
    """在现有 HTTP Handler 上分发进化端点，返回 True 表示已处理。

    server.py 接一行即可（GET/POST 各一行），例如：
        if evolution.handle_http(self, "GET"): return
        if evolution.handle_http(self, "POST"): return
    鉴权/上下文复用 Handler 自身的 _guard/_session_user，不另起一套会话。
    """
    path = str(getattr(handler, "path", "") or "").split("?", 1)[0]
    route = _http_route_parts(path)
    if route is None or route[1] not in ("replay", "trend", "rollback-suggestion",
                                        "hitl-approve", "hitl-reject",
                                        "hitl-status", "rollback"):
        return False
    gate = handler._guard(str(method or "").upper(), path)
    if gate:
        handler._send(gate[0], gate[1])
        return True
    user = handler._session_user() or {}
    if user and _evolution_module_off(user):
        handler._send(403, handler._json({"error": "该工作空间已关闭规则进化模块",
                                          "code": "module_off"}))
        return True
    body = (handler._body() or {}) if str(method or "").upper() == "POST" else None
    out = http_route(method, path, handler._query(), body, user)
    if out is None:
        return False
    handler._send(out[0], handler._json(out[1]))
    return True


# ===================== 空间准确率看板（T-177 V1：让「有没有变好」可见） =====================
# 设计文档：docs/CURRENT/17-自进化闭环最小可用版设计_20261119.md §3
#
# 原则（AGENTS §3/§13）：
#   1) 只展示真实评测结果（逐文档 tp/fp/fn 由评测 harness/人工 gold 通过 API/CLI 写入），
#      没有数据就返回空态，绝不用 0/None 冒充「已生效的准确率」；
#   2) 每个 F1 必须带 95% CI + n_docs + δ_min；相邻轮配对 ΔF1 用 CI 规则判定；
#   3) CI 口径与 scripts/qa/stats_ci.py 逐字一致：文档级 bootstrap、n_boot=2000、
#      seed=20261119、type-7 百分位（纯标准库，产品内复刻，不依赖 scripts/ 目录）。
ACC_BOOT = 2000
ACC_SEED = 20261119
ACC_METHOD = {"metric": "item-level micro-F1", "f1_formula": "2*TP/(2*TP+FP+FN)",
              "resampling_unit": "document", "n_boot": ACC_BOOT, "seed": ACC_SEED,
              "ci": "95% percentile bootstrap (type-7)", "delta_min": "2.80 * sigma_delta / sqrt(n)"}
ACC_MAX_DOCS = 5000
_ACC_TABLE_READY = False
_ACC_UNIQUE_READY = False
# L109（2026-11-25）：表/索引 DDL 单一事实源 = app/db.py 的
# RUNTIME_EXTENSION_SCHEMA["evolution_accuracy_round"] + RUNTIME_EXTENSION_UNIQUE_INDEXES；
# 本模块只在运行期兜底（老库/最小夹具库），不再内联 DDL 副本。
# P1-9（2026-11-21 外部交叉复测 A7）：准确率轮次写入幂等。
# 唯一键 = 空间内的轮次号；写入走 INSERT ... ON CONFLICT DO NOTHING，冲突时返回
# 已存在行并标 ok=True/audit_failed=True（行已在 → 不诱导调用方重试）。
# 回滚面：
#   ① 数据回滚：DROP INDEX IF EXISTS ux_acc_round_ws_no;（只删约束，不删行）
#   ② 行为回滚：RULEPROOF_ACC_ROUND_IDEMPOTENT=0 恢复旧 INSERT 语义（默认 "1"=幂等）
_ACC_IDEMPOTENT_ENV = "RULEPROOF_ACC_ROUND_IDEMPOTENT"


def _acc_idempotent_on() -> bool:
    """默认幂等；显式 ``RULEPROOF_ACC_ROUND_IDEMPOTENT=0`` 回退旧 INSERT（可回滚杆）。"""
    return str(os.environ.get(_ACC_IDEMPOTENT_ENV, "1")).strip() != "0"


def _acc_ensure_table() -> bool:
    """懒建表（口径同 app/services/conflict.py::_ensure_check_table）：旧库幂等补表。"""
    global _ACC_TABLE_READY, _ACC_UNIQUE_READY
    if _ACC_TABLE_READY:
        return True
    try:
        with db.session() as c:
            db.ensure_runtime_schema(c, "evolution_accuracy_round")
        _ACC_TABLE_READY = True
    except Exception:
        logging.getLogger(__name__).warning("evolution_accuracy_round schema init failed", exc_info=True)
        return False
    # 唯一索引单独建：旧库若已有重复轮次，建索引会失败——不能因此把整表判为不可用；
    # 记录降级状态（写入侧仍做先查后插兜底），并在日志里给清理/回滚指引。
    try:
        with db.session() as c:
            db.ensure_runtime_unique_index(c, "evolution_accuracy_round")
        _ACC_UNIQUE_READY = True
    except Exception:
        _ACC_UNIQUE_READY = False
        logging.getLogger(__name__).warning(
            "evolution_accuracy_round unique index unavailable（历史重复轮次？）；"
            "写入降级为「先查后插」。回滚/清理：DROP INDEX IF EXISTS ux_acc_round_ws_no",
            exc_info=True)
    return True


def _acc_insert_round_idempotent(row: dict) -> dict:
    """幂等写入一轮评测；返回 {"status": inserted|conflict|error, "row": ..., "error": ...}。

    · 唯一键 (tenant_id, workspace_id, round_no) 冲突 → status=conflict，row=已存在行；
    · 表无唯一索引（历史重复）→ 先查后插，仍返回 conflict；
    · RULEPROOF_ACC_ROUND_IDEMPOTENT=0 → 旧行为（直接 INSERT，可回滚）。
    """
    cols = ("id", "tenant_id", "workspace_id", "round_no", "label", "source",
            "docs_json", "n_docs", "rule_count", "rules_added_json", "metrics_json",
            "delta_json", "method_json", "notes", "created_at", "created_by")
    vals = tuple(row.get(c) for c in cols)
    sql = ("INSERT INTO evolution_accuracy_round(" + ",".join(cols) + ") VALUES("
           + ",".join("?" for _ in cols) + ")")
    try:
        with db.session() as c:
            if not _acc_idempotent_on():
                c.execute(sql, vals)
                return {"status": "inserted", "row": row}
            clash = c.execute(
                "SELECT * FROM evolution_accuracy_round WHERE tenant_id=? AND "
                "workspace_id=? AND round_no=?",
                (row.get("tenant_id") or "", row.get("workspace_id") or "",
                 int(row.get("round_no") or 0))).fetchone()
            if clash:
                return {"status": "conflict", "row": dict(clash)}
            cur = c.execute(sql + " ON CONFLICT DO NOTHING", vals)
            if cur.rowcount == 0:
                clash = c.execute(
                    "SELECT * FROM evolution_accuracy_round WHERE tenant_id=? AND "
                    "workspace_id=? AND round_no=?",
                    (row.get("tenant_id") or "", row.get("workspace_id") or "",
                     int(row.get("round_no") or 0))).fetchone()
                return {"status": "conflict", "row": dict(clash) if clash else {}}
            return {"status": "inserted", "row": row}
    except Exception as e:  # noqa: BLE001
        logging.getLogger(__name__).error("accuracy round insert failed", exc_info=True)
        return {"status": "error", "row": {}, "error": f"{type(e).__name__}: {str(e)[:200]}"}


def _acc_scope() -> dict:
    try:
        from . import ctx as _ctx
        cur = _ctx.get_context() or {}
    except Exception:
        cur = {}
    return {"tenant_id": str(cur.get("tenant_id") or ""),
            "workspace_id": str(cur.get("workspace_id") or "")}


def _acc_f1(tp, fp, fn):
    den = 2.0 * float(tp) + float(fp) + float(fn)
    return (2.0 * float(tp) / den) if den > 0 else None


def _acc_r4(x):
    return None if x is None else round(float(x), 4)


def _acc_quantile(sorted_vals, q: float) -> float:
    """type-7 线性插值分位数（与 numpy.percentile 默认 / stats_ci.py 一致）。"""
    n = len(sorted_vals)
    if n == 0:
        raise ValueError("empty")
    if n == 1:
        return float(sorted_vals[0])
    pos = q * (n - 1)
    lo = int(pos // 1)
    hi = min(lo + 1, n - 1)
    frac = pos - lo
    return float(sorted_vals[lo]) * (1.0 - frac) + float(sorted_vals[hi]) * frac


def _acc_ci95(values) -> list:
    s = sorted(v for v in values if v is not None)
    if not s:
        return [None, None]
    return [_acc_r4(_acc_quantile(s, 0.025)), _acc_r4(_acc_quantile(s, 0.975))]


def _acc_mean(xs):
    return (sum(xs) / len(xs)) if xs else None


def _acc_sd(xs):
    n = len(xs)
    if n < 2:
        return None
    m = sum(xs) / n
    return (sum((x - m) ** 2 for x in xs) / (n - 1)) ** 0.5


def _acc_doc_key(d: dict) -> str:
    return str(d.get("case_id") or "") + "|" + str(d.get("doc") or "")


def _acc_single_arm(docs: list) -> dict:
    """单臂：pooled micro-F1 + 文档级 bootstrap 95% CI（与 stats_ci.single_arm_ci 同口径）。"""
    import random
    n = len(docs)
    tp = int(sum(int(d["tp"]) for d in docs))
    fp = int(sum(int(d["fp"]) for d in docs))
    fn = int(sum(int(d["fn"]) for d in docs))
    f1 = _acc_f1(tp, fp, fn)
    rng = random.Random(ACC_SEED)
    dist = []
    for _ in range(ACC_BOOT):
        atp = afp = afn = 0
        for _ in range(n):
            d = docs[rng.randrange(n)]
            atp += int(d["tp"]); afp += int(d["fp"]); afn += int(d["fn"])
        dist.append(_acc_f1(atp, afp, afn))
    ci = _acc_ci95(dist)
    pr = tp / (tp + fp) if (tp + fp) else None
    rc = tp / (tp + fn) if (tp + fn) else None
    per_doc = [_acc_f1(d["tp"], d["fp"], d["fn"]) for d in docs]
    per_doc = [x for x in per_doc if x is not None]
    return {"tp": tp, "fp": fp, "fn": fn, "f1": _acc_r4(f1),
            "f1_ci95": ci,
            "ci_halfwidth": (round((ci[1] - ci[0]) / 2.0, 4)
                             if ci[0] is not None else None),
            "precision": _acc_r4(pr), "recall": _acc_r4(rc),
            "n_docs": n, "per_doc_f1_mean": _acc_r4(_acc_mean(per_doc)),
            "per_doc_f1_sd": _acc_r4(_acc_sd(per_doc))}


def _acc_verdict(delta_ci: list, p_value=None) -> dict:
    """AGENTS §13 判定口径：BLOCK / WARN / PASS / 提升 / 未检出显著差异。"""
    lo, hi = (delta_ci or [None, None])[0], (delta_ci or [None, None])[1]
    if lo is None or hi is None:
        return {"code": "insufficient", "label": "样本不足，无法判定",
                "rule": "需要可配对的同文档评测数据"}
    if hi <= -0.01:
        code, label = "block", "BLOCK（回归）"
    elif hi <= 0:
        code, label = "warn", "WARN（未检出提升，可能回归）"
    elif lo >= 0.005:
        code, label = "improve", "提升（CI 下界 ≥ +0.5pp）"
    else:
        code, label = "pass", "PASS（方向为正，未达「提升」声明门槛）"
    return {"code": code, "label": label,
            "rule": "BLOCK=CI上界≤−1.0pp; WARN=CI上界≤0; 提升=CI下界≥+0.5pp; 其余=未检出显著差异",
            "p_value_centered_bootstrap": _acc_r4(p_value)}


def _acc_paired(a_docs: list, b_docs: list) -> dict:
    """相邻两轮配对：同文档同一轮重采样 → ΔF1 分布、95% CI、δ_min、判定。

    a=上一轮（基线），b=本轮；Δ = F1(b) − F1(a)。
    """
    import random
    ka = {_acc_doc_key(d): d for d in a_docs}
    kb = {_acc_doc_key(d): d for d in b_docs}
    common = sorted(set(ka) & set(kb))
    if not common:
        return {"available": False, "reason": "两轮文档集合不可配对（无同名 case_id+doc）",
                "aligned_docs": 0, "unaligned_docs": len(b_docs)}
    pairs = [(ka[k], kb[k]) for k in common]
    atp = sum(int(a["tp"]) for a, _ in pairs)
    afp = sum(int(a["fp"]) for a, _ in pairs)
    afn = sum(int(a["fn"]) for a, _ in pairs)
    btp = sum(int(b["tp"]) for _, b in pairs)
    bfp = sum(int(b["fp"]) for _, b in pairs)
    bfn = sum(int(b["fn"]) for _, b in pairs)
    f1a = _acc_f1(atp, afp, afn)
    f1b = _acc_f1(btp, bfp, bfn)
    delta_hat = (f1b - f1a) if (f1a is not None and f1b is not None) else None
    rng = random.Random(ACC_SEED)
    diffs = []
    for _ in range(ACC_BOOT):
        xatp = xafp = xafn = xbtp = xbfp = xbfn = 0
        for _ in range(len(pairs)):
            a, b = pairs[rng.randrange(len(pairs))]
            xatp += int(a["tp"]); xafp += int(a["fp"]); xafn += int(a["fn"])
            xbtp += int(b["tp"]); xbfp += int(b["fp"]); xbfn += int(b["fn"])
        fa = _acc_f1(xatp, xafp, xafn)
        fb = _acc_f1(xbtp, xbfp, xbfn)
        if fa is not None and fb is not None:
            diffs.append(fb - fa)
    ci = _acc_ci95(diffs)
    p_value = None
    if delta_hat is not None and diffs:
        p_value = sum(1 for d in diffs if abs(d - delta_hat) >= abs(delta_hat)) / len(diffs)
    per_doc_delta = []
    for a, b in pairs:
        fa = _acc_f1(a["tp"], a["fp"], a["fn"])
        fb = _acc_f1(b["tp"], b["fp"], b["fn"])
        if fa is not None and fb is not None:
            per_doc_delta.append(fb - fa)
    sigma = _acc_sd(per_doc_delta)
    n = len(per_doc_delta)
    delta_min = (2.80 * sigma / (n ** 0.5)) if (sigma is not None and n > 0) else None
    return {"available": True, "n_docs": n,
            "aligned_docs": len(common), "unaligned_docs": len(b_docs) - len(common),
            "f1_a": _acc_r4(f1a), "f1_b": _acc_r4(f1b),
            "delta_f1": _acc_r4(delta_hat),
            "delta_f1_ci95": ci,
            "delta_f1_ci_halfwidth": (round((ci[1] - ci[0]) / 2.0, 4)
                                       if ci[0] is not None else None),
            "sigma_delta": _acc_r4(sigma),
            "delta_min": _acc_r4(delta_min),
            "p_value_centered_bootstrap": _acc_r4(p_value),
            "verdict": _acc_verdict(ci, p_value)}


def _acc_rule_count(tenant_id: str, workspace_id: str) -> int:
    """当前空间生效规则数（published 版本存在）；仅度量用，不参与权限。"""
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT COUNT(*) AS n FROM rule r WHERE "
                "(r.workspace_id=? OR r.workspace_id='' OR r.workspace_id IS NULL) AND "
                "EXISTS(SELECT 1 FROM rule_version rv WHERE rv.rule_id=r.id "
                "AND rv.status='published')", (workspace_id or "",)).fetchone()
        return int((row or {}).get("n") or 0)
    except Exception:
        logging.getLogger(__name__).debug("rule count skipped", exc_info=True)
        return 0


def _acc_rules_added(workspace_id: str, since: str, until: str) -> dict:
    """本轮新增生效规则归因：时间窗内 published 的本空间规则版本（不做单规则因果归因）。"""
    if not since:
        return {"items": [], "note": "首轮无对照窗口（没有上一轮）"}
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT r.code AS code, r.name AS name, rv.version AS version, "
                "rv.published_at AS published_at FROM rule_version rv "
                "JOIN rule r ON r.id = rv.rule_id "
                "WHERE rv.status='published' AND rv.published_at > ? AND rv.published_at <= ? "
                "AND r.workspace_id=? ORDER BY rv.published_at", (since, until, workspace_id or "")
            ).fetchall()
        items = [{"code": r["code"] or "", "name": r["name"] or "",
                  "version": r["version"] or "", "published_at": r["published_at"] or ""}
                 for r in rows]
    except Exception:
        logging.getLogger(__name__).warning("rules_added lookup skipped", exc_info=True)
        items = []
    return {"items": items, "count": len(items),
            "note": "时间窗内本空间新发布的规则；ΔF1 是整轮信号，非单规则因果归因"}


def _acc_round_out(row: dict) -> dict:
    try:
        metrics = json.loads(row.get("metrics_json") or "{}")
    except Exception:
        metrics = {}
    try:
        delta = json.loads(row.get("delta_json") or "{}")
    except Exception:
        delta = {}
    try:
        rules_added = json.loads(row.get("rules_added_json") or "[]")
    except Exception:
        rules_added = []
    return {"id": row.get("id") or "", "round_no": int(row.get("round_no") or 0),
            "label": row.get("label") or "", "source": row.get("source") or "",
            "created_at": row.get("created_at") or "", "created_by": row.get("created_by") or "",
            "n_docs": int(row.get("n_docs") or 0),
            "rule_count": int(row.get("rule_count") or 0),
            "rules_added": rules_added if isinstance(rules_added, list) else [],
            "notes": row.get("notes") or "",
            "f1": metrics.get("f1"), "f1_ci95": metrics.get("f1_ci95") or [None, None],
            "ci_halfwidth": metrics.get("ci_halfwidth"),
            "tp": metrics.get("tp"), "fp": metrics.get("fp"), "fn": metrics.get("fn"),
            "precision": metrics.get("precision"), "recall": metrics.get("recall"),
            "per_doc_f1_sd": metrics.get("per_doc_f1_sd"),
            "delta": delta if isinstance(delta, dict) else {}}


def accuracy_board(limit: int = 20, user=None) -> dict:
    """空间准确率看板（只读）：每轮 F1+CI+n_docs+δ_min+规则数 + 相邻轮配对 Δ + 判定。

    空态：没有任何轮次时返回 empty=true + empty_reason + 接入方式，不出现 F1 数字。
    """
    if user is not None and not user_can_view(user):
        return {"ok": False, "status": 403, "error": "无权限查看规则进化（需要 evo.view）",
                "code": "forbidden"}
    limit = max(1, min(int(limit or 20), 200))
    scope = _acc_scope()
    out = {"ok": True, "empty": True, "empty_reason": "", "workspace": scope,
           "method": dict(ACC_METHOD), "rounds": [], "latest": None, "summary": {}}
    if not _acc_ensure_table():
        out["empty_reason"] = "看板存储不可用（建表失败），请检查数据库"
        return out
    try:
        if not scope["workspace_id"]:
            out["empty_reason"] = "未指定工作空间上下文，无法读取空间准确率"
            return out
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM evolution_accuracy_round WHERE workspace_id=? "
                "AND (tenant_id=? OR tenant_id='') ORDER BY round_no ASC",
                (scope["workspace_id"], scope["tenant_id"])).fetchall()]
    except Exception:
        logging.getLogger(__name__).warning("accuracy board read failed", exc_info=True)
        out["empty_reason"] = "看板读取失败，请稍后重试"
        return out
    rounds = [_acc_round_out(r) for r in rows][-limit:]
    out["rounds"] = rounds
    if not rounds:
        out["empty_reason"] = ("当前空间还没有记录任何评测轮次：准确率看板只展示真实评测结果，"
                              "不会伪造数字。接入方式：POST /api/v1/workspace/accuracy/rounds "
                              "或 ./rp evolution accuracy-record。")
        return out
    out["empty"] = False
    out["latest"] = rounds[-1]
    best = max((r for r in rounds if r.get("f1") is not None),
               key=lambda x: x.get("f1") or 0, default=None)
    verdicts = [r["delta"]["verdict"]["code"] for r in rounds
                if isinstance(r.get("delta"), dict) and (r["delta"].get("verdict") or {}).get("code")]
    out["summary"] = {"n_rounds": len(rounds),
                      "best_round_no": (best or {}).get("round_no"),
                      "best_f1": (best or {}).get("f1"),
                      "latest_verdict": (rounds[-1].get("delta") or {}).get("verdict"),
                      "verdicts": verdicts,
                      "latest_rule_count": rounds[-1].get("rule_count")}
    return out


def _acc_parse_docs(docs) -> tuple:
    """校验并归一逐文档混淆计数；返回 (docs, error)。非法输入整体拒绝，不半写。"""
    if not isinstance(docs, list) or not docs:
        return [], "docs 不能为空：需要逐文档的 {case_id, doc, tp, fp, fn}"
    if len(docs) > ACC_MAX_DOCS:
        return [], f"docs 最多 {ACC_MAX_DOCS} 条"
    norm, seen = [], set()
    for i, d in enumerate(docs):
        if not isinstance(d, dict):
            return [], f"docs[{i}] 必须是对象"
        for k in ("tp", "fp", "fn"):
            v = d.get(k)
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                return [], f"docs[{i}].{k} 必须是数字"
            if float(v) < 0 or float(v) != int(v):
                return [], f"docs[{i}].{k} 必须是非负整数"
        # 允许 tp/fp/fn 全 0 的文档：它是「无 gold 且无预测」的对照文档（TN），
        # 文档级 bootstrap 的样本单位必须包含它；但不允许整轮全是 0（无任何判定）。
        key = str(d.get("case_id") or "") + "|" + str(d.get("doc") or "")
        if not str(d.get("doc") or "").strip() and not str(d.get("case_id") or "").strip():
            return [], f"docs[{i}] 至少需要 case_id 或 doc 作为配对键"
        if key in seen:
            return [], f"docs[{i}] 重复的文档键 {key}"
        seen.add(key)
        norm.append({"case_id": str(d.get("case_id") or ""), "doc": str(d.get("doc") or ""),
                     "tp": int(d.get("tp")), "fp": int(d.get("fp")), "fn": int(d.get("fn"))})
    if not any((x["tp"] + x["fp"] + x["fn"]) > 0 for x in norm):
        return [], "整轮 tp/fp/fn 全为 0：没有任何可度量的判定，拒绝记录"
    return norm, ""


def accuracy_record_round(payload: dict = None, user="", source: str = "") -> dict:
    """记录一轮空间评测结果（admin / evo.manage）：算 F1+CI、配对 Δ+δ_min、新规则归因后落库。"""
    if not user_can_manage(user):
        return {"ok": False, "status": 403, "error": "无权限记录评测轮次（需要 evo.manage）",
                "code": "forbidden"}
    body = payload if isinstance(payload, dict) else {}
    docs, err = _acc_parse_docs(body.get("docs"))
    if err:
        return {"ok": False, "status": 400, "error": err, "code": "invalid_docs"}
    scope = _acc_scope()
    if not scope["workspace_id"]:
        return {"ok": False, "status": 400,
                "error": "缺少工作空间上下文，无法记录空间准确率", "code": "no_workspace"}
    if not _acc_ensure_table():
        return {"ok": False, "status": 500, "error": "看板存储不可用", "code": "storage_unavailable"}
    src = str(source or body.get("source") or "eval_harness").strip()[:40] or "eval_harness"
    label = str(body.get("label") or "").strip()[:120]
    notes = str(body.get("notes") or "").strip()[:500]
    who = str((user or {}).get("sub") or (user or {}).get("id") or "") if isinstance(user, dict) else str(user or "")
    now = db.now()
    metrics = _acc_single_arm(docs)
    # 上一轮（同空间）：配对 Δ、新发布规则归因
    prev = {}
    try:
        with db.session() as c:
            r = c.execute("SELECT * FROM evolution_accuracy_round WHERE workspace_id=? "
                          "AND (tenant_id=? OR tenant_id='') ORDER BY round_no DESC LIMIT 1",
                          (scope["workspace_id"], scope["tenant_id"])).fetchone()
        prev = dict(r) if r else {}
    except Exception:
        logging.getLogger(__name__).warning("previous round lookup skipped", exc_info=True)
        prev = {}
    round_no = int(prev.get("round_no") or 0) + 1
    # P1-9：允许调用方显式传 round_no 做确定性重试（同一 round_no 重复写 → 幂等返回，
    # 不产生重复轮次；不传则沿用「上一轮 +1」的自增口径）。
    _explicit_no = body.get("round_no")
    if _explicit_no is not None and str(_explicit_no).strip() != "":
        try:
            _en = int(_explicit_no)
        except Exception:
            return {"ok": False, "status": 400, "error": "round_no 必须是整数",
                    "code": "invalid_round_no"}
        if _en <= 0:
            return {"ok": False, "status": 400, "error": "round_no 必须为正整数",
                    "code": "invalid_round_no"}
        round_no = _en
    if prev:
        try:
            prev_docs = json.loads(prev.get("docs_json") or "[]")
        except Exception:
            prev_docs = []
        delta = _acc_paired(prev_docs, docs)
        delta["vs_round_no"] = int(prev.get("round_no") or 0)
        delta["vs_round_id"] = prev.get("id") or ""
        try:
            prev_rule_count = int(prev.get("rule_count") or 0)
        except Exception:
            prev_rule_count = 0
        added = _acc_rules_added(scope["workspace_id"], prev.get("created_at") or "", now)
    else:
        delta = {"available": False, "reason": "首轮：没有上一轮可配对", "vs_round_no": 0,
                 "verdict": {"code": "baseline", "label": "基线轮（无对照）",
                             "rule": "首轮只报绝对指标；与下一轮配对后才有 ΔF1 判定"}}
        prev_rule_count = 0
        added = {"items": [], "count": 0, "note": "首轮无对照窗口"}
    try:
        rule_count = int(body.get("rule_count") or 0)
    except Exception:
        rule_count = 0
    rule_count_src = "caller"
    if rule_count <= 0:
        rule_count = _acc_rule_count(scope["tenant_id"], scope["workspace_id"])
        rule_count_src = "auto: published versions in workspace"
    rule_ids = [x.get("code") for x in added.get("items") or []]
    delta["rules_added_count"] = added.get("count") or 0
    delta["rules_added_codes"] = rule_ids
    delta["rule_count_delta"] = rule_count - prev_rule_count
    row = {"id": db.new_id("acr"), "tenant_id": scope["tenant_id"],
           "workspace_id": scope["workspace_id"], "round_no": round_no,
           "label": label or f"第 {round_no} 轮", "source": src,
           "docs_json": json.dumps(docs, ensure_ascii=False),
           "n_docs": len(docs),
           "rule_count": rule_count,
           "rules_added_json": json.dumps(added.get("items") or [], ensure_ascii=False),
           "metrics_json": json.dumps(metrics, ensure_ascii=False),
           "delta_json": json.dumps(delta, ensure_ascii=False),
           "method_json": json.dumps(ACC_METHOD, ensure_ascii=False),
           "notes": notes, "created_at": now, "created_by": who}
    # P1-9：唯一键 (tenant_id, workspace_id, round_no) + ON CONFLICT DO NOTHING。
    # 冲突 = 该轮已存在（审计失败后的重试/并发写）→ 返回已存在行，不新增轮次。
    _ins = _acc_insert_round_idempotent(row)
    _conflict = _ins.get("status") == "conflict"
    if _ins.get("status") == "error":
        return {"ok": False, "status": 500, "error": "评测轮次写入失败",
                "code": "storage_error"}
    _saved_row = _ins.get("row") or row
    _audit_ok = True
    _audit_err = ""
    try:
        R.audit_logs.log(
            actor=who or "system",
            action=("evolution.accuracy_round_duplicate_ignored" if _conflict
                    else "evolution.accuracy_recorded"),
            object=_saved_row.get("id") or row["id"],
            after=json.dumps({"round_no": round_no, "n_docs": len(docs),
                              "f1": metrics.get("f1"),
                              "delta_f1": delta.get("delta_f1"),
                              "label": row["label"],
                              "duplicate_ignored": _conflict},
                             ensure_ascii=False))
    except Exception as _e:
        # 铁律 4：审计失败不得静默；但行已落库，不能再返回 ok=False 诱导重试
        # （重试会产生重复轮 → 配对 ΔF1≈0 假 PASS）。标记 audit_failed 由调用方补审计。
        _audit_ok = False
        _audit_err = f"{type(_e).__name__}: {str(_e)[:150]}"
        logging.getLogger(__name__).error(
            "accuracy round audit failed（行已落库，重试幂等，不再诱导重试）",
            exc_info=True)
    out = _acc_round_out(_saved_row)
    out.update({"ok": True, "audit_failed": not _audit_ok,
                "audit_error": _audit_err,
                "duplicate": _conflict,
                "created": not _conflict,
                "rule_count_source": rule_count_src,
                "rules_added_count": added.get("count") or 0})
    if _conflict:
        out["note"] = ("该轮已存在（同 tenant/workspace/round_no），本次未重复写入；"
                       "行已在，无需重试")
        out["code"] = "duplicate_round"
    elif not _audit_ok:
        out["code"] = "audit_failed"
        out["note"] = "行已落库但审计写入失败；重试幂等（不会产生重复轮次），请补审计"
    return out


def accuracy_coldstart(limit: int = 5, user=None) -> dict:
    """冷启动 playbook：按真实反馈聚类，给出「建议先补这 N 条规则」清单（不调模型、不编造）。

    数据 = feedback 表（manual=漏报 / false_positive=误报）按 rule_code 聚类；
    rule_code 为空的人工新增问题聚为 UNCOVERED（规则库没有覆盖这类判据）。
    """
    if user is not None and not user_can_view(user):
        return {"ok": False, "status": 403, "error": "无权限查看规则进化（需要 evo.view）",
                "code": "forbidden"}
    limit = max(1, min(int(limit or 5), 50))
    try:
        rows = R.feedback.list(order="created_at DESC", limit=1000)
    except Exception:
        rows = []
    clusters = {}
    for r in rows:
        kind = str(r.get("kind") or "")
        if kind not in ("manual", "false_positive"):
            continue
        code = str(r.get("rule_code") or "").strip() or "UNCOVERED"
        cl = clusters.setdefault(code, {"rule_code": code, "miss": 0, "false_positive": 0,
                                        "total": 0, "evidence": []})
        cl["total"] += 1
        if kind == "manual":
            cl["miss"] += 1
        else:
            cl["false_positive"] += 1
        if len(cl["evidence"]) < 3:
            try:
                payload = json.loads(r.get("payload") or "{}")
            except Exception:
                payload = {}
            reason = str(payload.get("reason") or payload.get("detail") or "").strip()
            cl["evidence"].append({"kind": kind, "title": str(r.get("title") or "")[:120],
                                   "reason": reason[:200],
                                   "created_at": r.get("created_at") or "",
                                   "finding_id": r.get("finding_id") or ""})
    out = {"ok": True, "empty": True, "empty_reason": "",
           "method": "真实反馈聚类（manual=漏报 / false_positive=误报；不调模型、不生成判据）",
           "suggestions": []}
    if not clusters:
        out["empty_reason"] = ("当前空间还没有反向反馈（漏报/误报）：先让审核员完成第一批复核，"
                              "再回来看「建议先补的规则」。工具不会在没有证据时编造建议。")
        return out
    sug = []
    for code, cl in clusters.items():
        fp_rate = (cl["false_positive"] / cl["total"]) if cl["total"] else 0.0
        score = cl["miss"] * 2 + cl["false_positive"]
        if code == "UNCOVERED":
            advice = (f"规则库未覆盖：{cl['miss']} 条人工新增问题（漏报）无对应规则编码，"
                      "建议新增点位/规则判据")
            action = "new_rule"
        elif cl["miss"] > 0 and cl["miss"] >= cl["false_positive"]:
            advice = (f"漏报为主（{cl['miss']} 条）：建议补充/放宽该规则判据，"
                      "或拆出未覆盖的子场景")
            action = "revise_criterion"
        elif fp_rate >= 0.5:
            advice = (f"误报率 {round(fp_rate * 100)}%（{cl['false_positive']}/{cl['total']}）："
                      "建议收窄作用域（文档类型/点位）或降级为疑似")
            action = "narrow_scope"
        else:
            advice = (f"正负样本混杂（漏报 {cl['miss']} / 误报 {cl['false_positive']}）："
                      "建议先补负例卡 + 复核判据阈值")
            action = "review"
        sug.append({"rule_code": code, "miss": cl["miss"],
                    "false_positive": cl["false_positive"], "total": cl["total"],
                    "false_positive_rate": round(fp_rate, 3), "score": score,
                    "advice": advice, "action": action,
                    "evidence": cl["evidence"]})
    sug.sort(key=lambda x: (-x["score"], -x["total"], x["rule_code"]))
    out["empty"] = False
    out["suggestions"] = [dict(rank=i + 1, **s) for i, s in enumerate(sug[:limit])]
    out["next_step"] = ("按建议 1..N 补规则/判据后，用留出材料跑第 2 轮评测并记录到看板，"
                        "与第 1 轮配对 ΔF1（声明提升需 CI 下界 ≥ +0.5pp）")
    return out


# ===================== L18：S2 归因枚举统一（agent-fp 六类 ↔ evolution 四类） =====================
# 依据：docs/CURRENT/59-自进化链路再评估_20261123.md §2 V2 / §3 S2；
# docs/CURRENT/62-阶段总结与下一步_20261123.md「剩余」第 1 项（L18）。
#
# 背景（V2 归因口径分裂）：
#   agent-fp 六类（app/services/agents.py DEFAULT_PROMPTS["feedback.attribute"]）：
#       解析 / 抽取 / 规则 / 执行器 / 证据 / 人工标注
#   evolution 四类（app/services/agent_runners.py FP_JSON_SCHEMA 与下方 analyze_feedback）：
#       判据过严 / 作用域过大 / 证据不足 / 原文误读
#   同一反馈两套标签，无法统计、无法按类制定策略。
#
# 本段口径（写死，避免事后漂移）：
#   1) 统一机器码 7 个语义码（other 为未知兜底，不计入映射率分母）；
#   2) 落盘仍是**同一个字段**：evolution_task.root_cause / feedback.payload.root_cause。
#      已知值写统一机器码；未知值不覆盖原值（只统计为 other）——即「未知→other 留原值」；
#   3) 展示层按 agent_fp / evolution 两个口径投影（映射表见 attribution_map_table）；
#   4) 映射率口径：agent-fp 6/6 → evolution、evolution 4/4 → agent-fp、各自往返 100%。
#
# 统一机器码 → 两套口径投影（本表是唯一事实源；改映射必须升 ATTRIBUTION_ENUM_VERSION）：
#   parse      解析错误     agent-fp=解析     evolution=原文误读
#   extract    抽取错误     agent-fp=抽取     evolution=原文误读
#   rule       规则错误     agent-fp=规则     evolution=判据过严
#   executor   执行器错误   agent-fp=执行器   evolution=判据过严
#   evidence   证据不足     agent-fp=证据     evolution=证据不足
#   human_label 人工标注错误 agent-fp=人工标注 evolution=原文误读
#   scope      作用域过大   agent-fp=规则     evolution=作用域过大
ATTRIBUTION_ENUM_VERSION = "L18-attribution-v1"
ATTRIBUTION_AGENT_FP = ("解析", "抽取", "规则", "执行器", "证据", "人工标注")
ATTRIBUTION_EVOLUTION = ("判据过严", "作用域过大", "证据不足", "原文误读")
ATTRIBUTION_UNIFIED = {
    "parse": {"label": "解析错误", "agent_fp": "解析", "evolution": "原文误读",
              "definition": "文档结构/版式/表格解析失败或错位，导致判据读不到原文"},
    "extract": {"label": "抽取错误", "agent_fp": "抽取", "evolution": "原文误读",
                "definition": "指标/数值/条款抽取错误或单位归一错误"},
    "rule": {"label": "规则错误", "agent_fp": "规则", "evolution": "判据过严",
             "definition": "规则判据本身过严/阈值错误，不是文档或执行的问题"},
    "executor": {"label": "执行器错误", "agent_fp": "执行器", "evolution": "判据过严",
                 "definition": "执行器/算子/编译执行错误（含条件触发与作用域路由）"},
    "evidence": {"label": "证据不足", "agent_fp": "证据", "evolution": "证据不足",
                 "definition": "证据锚点/引文缺失或不可回查，结论无法证明"},
    "human_label": {"label": "人工标注错误", "agent_fp": "人工标注", "evolution": "原文误读",
                    "definition": "人工复核/标注判断错误（误判误报或漏标）"},
    "scope": {"label": "作用域过大", "agent_fp": "规则", "evolution": "作用域过大",
              "definition": "规则适用范围/业务类型/文档类型过宽，覆盖了不该覆盖的对象"},
    "other": {"label": "未归类", "agent_fp": "", "evolution": "",
              "definition": "未知值兜底：原始值保留在字段/raw 中，不参与映射率分母"},
}
_ATTRIBUTION_ALIASES = {}
for _code, _meta in ATTRIBUTION_UNIFIED.items():
    if _code == "other":
        continue
    _ATTRIBUTION_ALIASES[_code] = _code
    _ATTRIBUTION_ALIASES[_meta["label"]] = _code
    _ATTRIBUTION_ALIASES[_meta["agent_fp"]] = _code
    _ATTRIBUTION_ALIASES[_meta["evolution"]] = _code
# 历史 enumschema 变体与英文机器码别名（兼容 agent_runners.FP_JSON_SCHEMA 的「解析错误/人工标注错误」）
_ATTRIBUTION_ALIASES.update({
    "解析": "parse", "解析错误": "parse", "parse_error": "parse",
    "抽取": "extract", "抽取错误": "extract", "extract_error": "extract",
    "规则": "rule", "规则错误": "rule", "rule_error": "rule",
    "执行器": "executor", "执行器错误": "executor", "executor_error": "executor",
    "证据": "evidence", "证据不足": "evidence", "evidence_insufficient": "evidence",
    "人工标注": "human_label", "人工标注错误": "human_label",
    "human_label_error": "human_label", "human": "human_label",
    "作用域过大": "scope", "scope_too_wide": "scope",
    "判据过严": "rule", "criterion_too_strict": "rule",
    "原文误读": "parse", "source_misread": "parse",
    "其他": "other", "未归类": "other", "other": "other", "unknown": "other",
})
# 子串兜底匹配用「最长标签优先」，避免「证据不足（缺引文）」这类历史自由文本丢归因。
_ATTRIBUTION_SUBSTRING = tuple(sorted(
    ((alias, code) for alias, code in _ATTRIBUTION_ALIASES.items()
     if alias and not alias.isascii()),
    key=lambda x: -len(x[0])))


def _attribution_source_enum(raw: str, code: str) -> str:
    """记录原始值来自哪套枚举（用于统计「两套标签各占多少」）。"""
    value = str(raw or "").strip()
    if value in ATTRIBUTION_AGENT_FP:
        return "agent_fp"
    if value in ATTRIBUTION_EVOLUTION:
        return "evolution"
    if value in ATTRIBUTION_UNIFIED:
        return "unified"
    return "alias" if value else "empty"


def attribution_normalize(value) -> dict:
    """归因值归一：任意历史值（两套标签/机器码/自由文本）→ 统一机器码。

    未知值返回 ``code="other"`` 且 ``known=False``、``raw`` 保留原值；
    不改写任何数据（写回见 ``attribution_persist_value`` / ``attribution_backfill``）。
    """
    raw = str(value if value is not None else "").strip()
    out = {"raw": raw, "code": "other", "label": ATTRIBUTION_UNIFIED["other"]["label"],
           "agent_fp": "", "evolution": "", "known": False, "source_enum": "empty",
           "version": ATTRIBUTION_ENUM_VERSION}
    if not raw:
        return out
    code = _ATTRIBUTION_ALIASES.get(raw) or _ATTRIBUTION_ALIASES.get(raw.lower())
    if not code:
        hits = {c for alias, c in _ATTRIBUTION_SUBSTRING if alias in raw}
        if len(hits) == 1:
            code = hits.pop()
    if not code:
        return out
    meta = ATTRIBUTION_UNIFIED[code]
    out.update({"code": code, "label": meta["label"], "agent_fp": meta["agent_fp"],
                "evolution": meta["evolution"], "known": True,
                "source_enum": _attribution_source_enum(raw, code)})
    return out


def attribution_project(value, target: str = "evolution") -> str:
    """把任意归因值投影到指定口径（agent_fp / evolution / label）；未知返回空串。"""
    n = attribution_normalize(value)
    if not n["known"]:
        return ""
    if target == "agent_fp":
        return n["agent_fp"]
    if target == "evolution":
        return n["evolution"]
    return n["label"]


def _attribution_display(value) -> str:
    """展示值：已知→统一标签；未知→原值（不丢信息、不伪装成已归类）。"""
    n = attribution_normalize(value)
    return n["label"] if n["known"] else n["raw"]


def attribution_persist_value(value) -> str:
    """写回同一字段的值：已知→统一机器码；未知→保留原值（未知→other 但不覆盖）。"""
    n = attribution_normalize(value)
    return n["code"] if n["known"] else str(value or "").strip()


def attribution_map_table() -> dict:
    """双向映射表（agent-fp 六类 ↔ evolution 四类）+ 覆盖率/往返率，供前端徽标与验收。"""
    af_to_ev = {}
    for label in ATTRIBUTION_AGENT_FP:
        n = attribution_normalize(label)
        af_to_ev[label] = n["evolution"]
    ev_to_af = {}
    for label in ATTRIBUTION_EVOLUTION:
        n = attribution_normalize(label)
        ev_to_af[label] = n["agent_fp"]
    af_round = sum(1 for label in ATTRIBUTION_AGENT_FP
                   if attribution_normalize(
                       attribution_normalize(label)["agent_fp"])["agent_fp"] == label)
    ev_round = sum(1 for label in ATTRIBUTION_EVOLUTION
                   if attribution_normalize(
                       attribution_normalize(label)["evolution"])["evolution"] == label)
    total_af = len(ATTRIBUTION_AGENT_FP)
    total_ev = len(ATTRIBUTION_EVOLUTION)
    return {
        "version": ATTRIBUTION_ENUM_VERSION,
        "agent_fp_to_evolution": af_to_ev,
        "evolution_to_agent_fp": ev_to_af,
        "rates": {
            "agent_fp_to_evolution": round(sum(1 for x in af_to_ev.values() if x) / total_af, 4),
            "evolution_to_agent_fp": round(sum(1 for x in ev_to_af.values() if x) / total_ev, 4),
            "agent_fp_roundtrip": round(af_round / total_af, 4),
            "evolution_roundtrip": round(ev_round / total_ev, 4),
        },
        "counts": {"agent_fp": total_af, "evolution": total_ev,
                   "agent_fp_mapped": sum(1 for x in af_to_ev.values() if x),
                   "evolution_mapped": sum(1 for x in ev_to_af.values() if x)},
    }


def attribution_enum_payload() -> dict:
    """统一枚举的机读清单（前端渲染映射表 / 测试断言 100% 覆盖率用）。"""
    return {
        "version": ATTRIBUTION_ENUM_VERSION,
        "write_field": "evolution_task.root_cause / feedback.payload.root_cause（同一字段）",
        "agent_fp": list(ATTRIBUTION_AGENT_FP),
        "evolution": list(ATTRIBUTION_EVOLUTION),
        "unified": [{"code": code, **{k: meta[k] for k in ("label", "agent_fp", "evolution", "definition")}}
                    for code, meta in ATTRIBUTION_UNIFIED.items()],
        "mapping": attribution_map_table(),
        "unknown_policy": "未知值 code=other、保留原值（不覆盖字段），不计入映射率分母",
    }


def _attribution_items(limit: int = 200, user=None) -> list:
    """归因复核列表：evolution_task.root_cause 与 feedback.payload.root_cause 同源合并。"""
    items = []
    try:
        tasks = R.evolution_tasks.list(order="created_at DESC", limit=max(limit * 2, 100))
    except Exception:
        tasks = []
    try:
        fbs = R.feedback.list(order="created_at DESC", limit=max(limit * 2, 100))
    except Exception:
        fbs = []
    role = str((user or {}).get("role") or "")
    uid = _user_id(user)
    own_finding_ids = set()
    if role == "reviewer":
        # 审核员只读自己的反馈（与 /api/v1/feedback/mine 同口径）；任务行按 finding 关联。
        for r in fbs:
            if str(r.get("actor") or "") == uid:
                own_finding_ids.add(str(r.get("finding_id") or ""))
    for t in tasks:
        fid = str(t.get("finding_id") or "")
        if role == "reviewer" and fid not in own_finding_ids:
            continue
        n = attribution_normalize(t.get("root_cause") or "")
        items.append({
            "source": "evolution_task", "id": t.get("id") or "",
            "finding_id": fid, "rule_code": t.get("rule_code") or "",
            "title": t.get("title") or "", "status": t.get("status") or "",
            "raw_root_cause": t.get("root_cause") or "",
            "root_cause": t.get("root_cause") or "",
            "code": n["code"], "label": _attribution_display(t.get("root_cause") or ""),
            "agent_fp": n["agent_fp"], "evolution": n["evolution"],
            "known": n["known"], "source_enum": n["source_enum"],
            "suggestion": t.get("suggestion") or "", "actor": t.get("handled_by") or "",
            "created_at": t.get("created_at") or "",
        })
    for r in fbs:
        if role == "reviewer" and str(r.get("actor") or "") != uid:
            continue
        try:
            payload = json.loads(r.get("payload") or "{}")
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        raw = payload.get("root_cause") or ""
        if not raw:
            # 没有归因值的反馈也要可见（空态证据），但与「未知值」分开计。
            pass
        n = attribution_normalize(raw)
        items.append({
            "source": "feedback", "id": r.get("id") or "",
            "finding_id": r.get("finding_id") or "", "rule_code": r.get("rule_code") or "",
            "title": r.get("title") or "", "status": r.get("rsi_status") or "",
            "raw_root_cause": raw, "root_cause": raw,
            "code": n["code"], "label": _attribution_display(raw),
            "agent_fp": n["agent_fp"], "evolution": n["evolution"],
            "known": n["known"], "source_enum": n["source_enum"],
            "suggestion": payload.get("suggestion") or "",
            "actor": r.get("actor") or "", "created_at": r.get("created_at") or "",
        })
    items.sort(key=lambda x: (x.get("created_at") or "", x.get("id") or ""), reverse=True)
    return items[:max(1, int(limit or 200))]


def attribution_review(limit: int = 200, user=None) -> dict:
    """归因复核列表（S3 断点 1）：统一枚举 + 映射徽标 + 覆盖率 + 未知值清单。"""
    if user is not None and not user_can_view(user):
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "无权限查看归因复核（需要 evo.view）"}
    try:
        limit = max(1, min(int(limit or 200), _HTTP_LIMIT_MAX))
    except (TypeError, ValueError):
        limit = 200
    items = _attribution_items(limit=limit, user=user)
    by_code = {}
    agent_dist = {}
    evolution_dist = {}
    source_enum = {"agent_fp": 0, "evolution": 0, "unified": 0, "alias": 0, "empty": 0}
    unknown, empty, known = [], 0, 0
    for it in items:
        if not it["raw_root_cause"]:
            empty += 1
        elif it["known"]:
            known += 1
            by_code[it["code"]] = by_code.get(it["code"], 0) + 1
            agent_dist[it["agent_fp"]] = agent_dist.get(it["agent_fp"], 0) + 1
            evolution_dist[it["evolution"]] = evolution_dist.get(it["evolution"], 0) + 1
        else:
            unknown.append({"source": it["source"], "id": it["id"],
                            "rule_code": it["rule_code"], "raw": it["raw_root_cause"],
                            "created_at": it["created_at"]})
        source_enum[it["source_enum"]] = source_enum.get(it["source_enum"], 0) + 1
    mapped_den = known + len(unknown)
    return {
        "ok": True, "view": "attribution_review", "enum": attribution_enum_payload(),
        "items": items,
        "stats": {
            "scanned": len(items), "known": known, "unknown": len(unknown),
            "empty": empty, "mapped_rate": (round(known / mapped_den, 4) if mapped_den else None),
            "by_code": by_code, "agent_fp": agent_dist, "evolution": evolution_dist,
            "source_enum": source_enum,
        },
        "unknown": unknown[:50],
        "note": ("同一字段（root_cause）两套枚举统一：已知→机器码，未知→other 且保留原值；"
                 "empty 表示尚未归因，不计入映射率分母"),
    }


def attribution_backfill(dry_run: bool = True, limit: int = 0, user: str = "") -> dict:
    """历史归因映射/回填：evolution_task.root_cause + feedback.payload.root_cause。

    - 已知值且非机器码 → 写回统一机器码（同一字段）；
    - 未知值 → 保留原值（只计数，不覆盖）；
    - ``dry_run=True``（默认）只扫描不写库；正式回填给审计 ``evolution.attribution_backfill``。
    产品库不自动执行；迁移口径见 docs/qa/L18自进化前端与归因_20261123.md §2.3。
    """
    out = {"ok": True, "dry_run": bool(dry_run), "scanned": 0, "converted": 0,
           "already": 0, "unknown": 0, "empty": 0, "by_code": {}, "unknown_samples": []}
    try:
        tasks = R.evolution_tasks.list(order="created_at DESC", limit=int(limit or 0))
    except Exception:
        tasks = []
    for t in tasks:
        raw = t.get("root_cause") or ""
        n = attribution_normalize(raw)
        out["scanned"] += 1
        if not raw:
            out["empty"] += 1
            continue
        if not n["known"]:
            out["unknown"] += 1
            if len(out["unknown_samples"]) < 20:
                out["unknown_samples"].append({"source": "evolution_task", "id": t.get("id"),
                                               "raw": raw[:200]})
            continue
        out["by_code"][n["code"]] = out["by_code"].get(n["code"], 0) + 1
        if str(raw) == n["code"]:
            out["already"] += 1
            continue
        out["converted"] += 1
        if not dry_run:
            try:
                R.evolution_tasks.update(t["id"], root_cause=n["code"])
            except Exception:
                logging.getLogger(__name__).warning(
                    "归因回填写库失败 task=%s", t.get("id"), exc_info=True)
    try:
        fbs = R.feedback.list(order="created_at DESC", limit=int(limit or 0))
    except Exception:
        fbs = []
    for r in fbs:
        try:
            payload = json.loads(r.get("payload") or "{}")
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        raw = payload.get("root_cause") or ""
        n = attribution_normalize(raw)
        out["scanned"] += 1
        if not raw:
            out["empty"] += 1
            continue
        if not n["known"]:
            out["unknown"] += 1
            if len(out["unknown_samples"]) < 20:
                out["unknown_samples"].append({"source": "feedback", "id": r.get("id"),
                                               "raw": raw[:200]})
            continue
        out["by_code"][n["code"]] = out["by_code"].get(n["code"], 0) + 1
        if str(raw) == n["code"]:
            out["already"] += 1
            continue
        out["converted"] += 1
        if not dry_run:
            payload["root_cause"] = n["code"]
            try:
                R.feedback.update(r["id"], payload=json.dumps(payload, ensure_ascii=False))
            except Exception:
                logging.getLogger(__name__).warning(
                    "归因回填写库失败 feedback=%s", r.get("id"), exc_info=True)
    out["mapped_rate"] = (round((out["scanned"] - out["unknown"] - out["empty"])
                                / max(1, out["scanned"] - out["empty"]), 4)
                          if (out["scanned"] - out["empty"]) > 0 else None)
    if not dry_run:
        try:
            R.audit_logs.log(actor=user or "system", action="evolution.attribution_backfill",
                             after=json.dumps({k: out[k] for k in
                                               ("scanned", "converted", "already", "unknown",
                                                "empty", "by_code")}, ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).warning("归因回填审计失败", exc_info=True)
    return out


# ===================== L18：S4 预注册 hash（防候选事后改） =====================
# 依据：docs/CURRENT/59 §2 V4（「预注册可事后改」）、§3 S4（「改一个字节即 FAIL」）。
#
# 机制：
#   候选创建时（HTTP 沉淀路径由 server.py 6 行钩子调用；其余路径在候选首读时补齐）写
#   ``rsi_candidate.prereg_sha256`` = sha256(候选不可变注册内容规范化 JSON)；
#   可选 ``prereg_ref`` 指向外部预注册文件（JSON），此时 hash 的是文件字节。
#   门禁读取（候选时间线 / prereg_assert）时重算并断言：
#     · 不一致 → 候选 decision=blocked + 审计 rsi.gate_blocked（reason=prereg_sha256_mismatch）；
#     · 历史候选（本 lane 上线前创建、prereg_sha256 为 NULL）→ 允许 null，标 legacy_null，
#       不阻断（迁移口径见报告 §2.3；回填入口见 prereg_register_candidate）。
#   威胁模型：防「服务/日志/报告层事后改候选内容或预注册文件」；直改 DB 列不在模型内
#   （有 DB 写权限可同时改 hash —— 该类篡改由审计/备份治理，不在本断言范围）。
_PREREG_ENV = "RULEPROOF_PREREG"
_PREREG_SINCE_ENV = "RULEPROOF_PREREG_SINCE"
_PREREG_SINCE_DEFAULT = "2026-11-23 20:00:00"
# L109：列定义单一事实源 = app/db.py RUNTIME_EXTENSION_COLUMNS["rsi_candidate"]
_PREREG_COLUMNS = dict(db.RUNTIME_EXTENSION_COLUMNS["rsi_candidate"])
_PREREG_READY_FOR = ""
_PREREG_INMUTABLE_FIELDS = ("id", "feedback_id", "rule_code", "action",
                            "before_json", "after_json", "created_at")


def _prereg_enabled() -> bool:
    """默认 1=启用断言；显式 ``RULEPROOF_PREREG=0`` 回滚为不校验（仍可注册/展示）。"""
    return str(os.environ.get(_PREREG_ENV, "1")).strip() != "0"


def _prereg_since() -> str:
    return str(os.environ.get(_PREREG_SINCE_ENV) or _PREREG_SINCE_DEFAULT)


def _prereg_ensure() -> bool:
    """幂等迁移：给 rsi_candidate 补 prereg_* 列（历史行 NULL/''，允许旧库直接跑）。"""
    global _PREREG_READY_FOR
    key = str(getattr(db, "DB_PATH", "") or os.environ.get("RULEPROOF_DB", "") or "")
    if key and _PREREG_READY_FOR == key:
        return True
    try:
        with db.session() as c:
            db.ensure_runtime_columns(c, "rsi_candidate")
    except Exception:
        logging.getLogger(__name__).warning("prereg 列迁移失败", exc_info=True)
        return False
    _PREREG_READY_FOR = key
    return True


def _prereg_candidate_row(candidate_id: str) -> dict:
    _prereg_ensure()
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM rsi_candidate WHERE id=?",
                            (str(candidate_id or ""),)).fetchone()
        return dict(row) if row else {}
    except Exception:
        logging.getLogger(__name__).warning("prereg 候选读取失败 cid=%s", candidate_id,
                                            exc_info=True)
        return {}


def _prereg_canonical(row: dict) -> dict:
    """候选「不可变注册内容」规范化快照（不含 decision/note/prereg_* 等可变列）。"""
    row = row or {}

    def _obj(text):
        try:
            v = json.loads(text or "{}")
        except Exception:
            return {"_parse_error": True, "_raw": str(text or "")[:2000]}
        return v if isinstance(v, (dict, list)) else {"_value": v}

    return {"v": ATTRIBUTION_ENUM_VERSION.replace("attribution", "prereg"),
            "candidate_id": str(row.get("id") or ""),
            "feedback_id": str(row.get("feedback_id") or ""),
            "rule_code": str(row.get("rule_code") or ""),
            "action": str(row.get("action") or ""),
            "before": _obj(row.get("before_json")),
            "after": _obj(row.get("after_json")),
            "created_at": str(row.get("created_at") or "")}


def _prereg_hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _prereg_embedded_hash(row: dict) -> str:
    canonical = json.dumps(_prereg_canonical(row), ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"))
    return _prereg_hash_bytes(canonical.encode("utf-8"))


def _prereg_file_hash(path: str) -> str:
    with open(str(path), "rb") as fh:
        return _prereg_hash_bytes(fh.read())


def _prereg_compute(row: dict) -> tuple:
    """按候选当前登记的 ref 重算 hash：返回 (sha256, ref, error)。"""
    ref = str((row or {}).get("prereg_ref") or "").strip()
    if ref and ref not in ("embedded", "candidate"):
        try:
            return _prereg_file_hash(ref), ref, ""
        except OSError as e:
            return "", ref, f"预注册文件不可读：{type(e).__name__}"
    return _prereg_embedded_hash(row), "embedded", ""


def _prereg_update(candidate_id: str, **cols) -> bool:
    _prereg_ensure()
    if not cols:
        return False
    try:
        with db.session() as c:
            sets = ",".join(f"{k}=?" for k in cols)
            c.execute(f"UPDATE rsi_candidate SET {sets} WHERE id=?",
                      [*cols.values(), str(candidate_id or "")])
        return True
    except Exception:
        logging.getLogger(__name__).warning("prereg 写库失败 cid=%s", candidate_id, exc_info=True)
        return False


def prereg_register_candidate(candidate_id: str, prereg_path: str = "", by: str = "",
                              audit: bool = True) -> dict:
    """候选创建时写预注册 hash（幂等；已登记且一致不覆盖，不一致不覆盖并审计）。

    ``prereg_path`` 为空 → hash 候选不可变注册内容（embedded）；
    非空 → hash 该预注册文件字节（供「预注册 JSON 落盘」场景）。
    """
    cid = str(candidate_id or "").strip()
    row = _prereg_candidate_row(cid)
    if not row:
        return {"ok": False, "status": 404, "code": "candidate_not_found",
                "error": "候选不存在", "candidate_id": cid}
    ref = str(prereg_path or "").strip()
    if ref:
        try:
            sha = _prereg_file_hash(ref)
        except OSError as e:
            return {"ok": False, "status": 400, "code": "prereg_unreadable",
                    "error": f"预注册文件不可读：{type(e).__name__}", "candidate_id": cid}
    else:
        sha = _prereg_embedded_hash(row)
        ref = "embedded"
    old = str(row.get("prereg_sha256") or "")
    if old:
        if old == sha:
            return {"ok": True, "status": "already_registered", "candidate_id": cid,
                    "prereg_sha256": sha, "prereg_ref": row.get("prereg_ref") or ref,
                    "prereg_at": row.get("prereg_at") or ""}
        # 已登记且重算不一致：不覆盖（先登记者为准），落审计由门禁读取时统一处理。
        return {"ok": False, "status": "prereg_sha256_mismatch", "candidate_id": cid,
                "error": "候选已登记预注册 hash 且当前内容与登记值不一致（拒绝覆盖）",
                "expected": old, "actual": sha, "blocked": True}
    ok = _prereg_update(cid, prereg_sha256=sha, prereg_ref=ref,
                        prereg_at=db.now(), prereg_by=str(by or "system")[:80])
    if ok and audit:
        try:
            R.audit_logs.log(actor=by or "system", action="evolution.prereg_registered",
                             object=cid, after=json.dumps(
                                 {"prereg_sha256": sha, "prereg_ref": ref},
                                 ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).warning("prereg 注册审计失败 cid=%s", cid, exc_info=True)
    return {"ok": bool(ok), "status": "registered" if ok else "write_failed",
            "candidate_id": cid, "prereg_sha256": sha, "prereg_ref": ref,
            "prereg_at": db.now() if ok else ""}


def prereg_assert(candidate_id: str, by: str = "gate-read", block: bool = True) -> dict:
    """门禁读取断言：重算预注册 hash 并与登记值比对。

    返回 ``status``：
      verified      一致（verified=True）
      mismatch      不一致 → block=True 时写 decision=blocked + 审计（幂等）
      legacy_null   历史候选未预注册（允许 null，不阻断，verified=False）
      unreadable    预注册文件不可读（按无法确证处理：不阻断，需人工复核）
      not_found     候选不存在
    """
    cid = str(candidate_id or "").strip()
    if not _prereg_enabled():
        return {"ok": True, "status": "disabled", "verified": False, "candidate_id": cid,
                "note": "RULEPROOF_PREREG=0：预注册断言回滚为不校验"}
    row = _prereg_candidate_row(cid)
    if not row:
        return {"ok": False, "status": "not_found", "verified": False,
                "candidate_id": cid, "error": "候选不存在"}
    expected = str(row.get("prereg_sha256") or "")
    if not expected:
        return {"ok": True, "status": "legacy_null", "verified": False,
                "candidate_id": cid,
                "note": "历史候选未预注册（允许 null）；不阻断，仅标未验证"}
    actual, ref, err = _prereg_compute(row)
    if err:
        return {"ok": True, "status": "unreadable", "verified": False,
                "candidate_id": cid, "prereg_ref": ref, "error": err,
                "note": "预注册载体不可读：门禁无法确证，不阻断，需人工复核"}
    if actual == expected:
        return {"ok": True, "status": "verified", "verified": True,
                "candidate_id": cid, "prereg_sha256": actual, "prereg_ref": ref,
                "checked_at": db.now()}
    # ---- 防事后改：不一致 → blocked + 审计（重复读取幂等，不重复写 audit/state）----
    note = str(row.get("note") or "")
    already = "prereg_sha256_mismatch" in note and str(row.get("decision") or "") == "blocked"
    if block and not already:
        _prereg_update(cid, decision="blocked", decided_at=db.now(),
                       decided_by=str(by or "gate-read")[:80],
                       note=(note + " | prereg_sha256_mismatch（预注册 hash 不一致，已阻断）"
                             ).strip(" |"))
        try:
            R.audit_logs.log(
                actor=by or "gate-read", action="rsi.gate_blocked", object=cid,
                after=json.dumps({"reason": "prereg_sha256_mismatch",
                                  "kind": "prereg_tamper", "expected": expected,
                                  "actual": actual, "prereg_ref": ref},
                                 ensure_ascii=False)[:1000])
        except Exception:
            logging.getLogger(__name__).warning("prereg 篡改审计失败 cid=%s", cid, exc_info=True)
    return {"ok": False, "status": "mismatch", "verified": False, "blocked": True,
            "candidate_id": cid, "decision": "blocked",
            "reason": "prereg_sha256_mismatch",
            "expected": expected, "actual": actual, "prereg_ref": ref,
            "audited": block and not already}


def _prereg_backfill_new(limit: int = 200) -> dict:
    """读时补齐：本 lane 上线后创建的候选若尚无 prereg hash，按当前内容补登记。

    只为 ``created_at >= RULEPROOF_PREREG_SINCE`` 的候选补登记；更早的一律视为历史候选
    （prereg_sha256 保留 NULL → 门禁标记 legacy_null），避免把历史未知状态伪装成已验证。
    """
    out = {"checked": 0, "registered": 0, "skipped_legacy": 0, "skipped_has_hash": 0}
    _prereg_ensure()
    since = _prereg_since()
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT id, created_at, prereg_sha256 FROM rsi_candidate "
                "ORDER BY rowid DESC LIMIT ?", (int(limit or 200),)).fetchall()
    except Exception:
        return out
    for r in rows:
        out["checked"] += 1
        if str(r["prereg_sha256"] or ""):
            out["skipped_has_hash"] += 1
            continue
        if str(r["created_at"] or "") < since:
            out["skipped_legacy"] += 1
            continue
        res = prereg_register_candidate(r["id"], by="lazy-read", audit=False)
        if res.get("ok") and res.get("status") == "registered":
            out["registered"] += 1
    return out


def _candidate_gate_events(candidate_id: str, limit: int = 30) -> list:
    """候选门禁时间线：审计里 rsi.* / evolution.prereg* 事件（时间正序）。"""
    try:
        rows = R.audit_logs.list("object=?", (str(candidate_id or ""),),
                                 order="created_at ASC", limit=max(1, int(limit or 30)))
    except Exception:
        return []
    _L131_ACTIONS = ("evolution.hitl_approved", "evolution.hitl_rejected",
                     "evolution.hitl_blocked", "evolution.hitl_required",
                     "evolution.golden_gate", "evolution.rollback")
    events = []
    for r in rows:
        action = str(r.get("action") or "")
        if not (action.startswith("rsi.") or action.startswith("evolution.prereg")
                or action in _L131_ACTIONS):
            continue
        verdict = {"rsi.gate_passed": "accepted", "rsi.gate_blocked": "blocked",
                   "rsi.gate_uncertain": "uncertain", "rsi.rollback": "rolled_back",
                   "evolution.hitl_approved": "hitl_approved",
                   "evolution.hitl_rejected": "hitl_rejected",
                   "evolution.hitl_blocked": "hitl_blocked",
                   "evolution.hitl_required": "hitl_required",
                   "evolution.golden_gate": "golden_gate",
                   "evolution.rollback": "rolled_back",
                   }.get(action, "")
        events.append({"at": r.get("created_at") or "", "action": action,
                       "actor": r.get("actor") or "", "decision": verdict,
                       "detail": str(r.get("after_json") or "")[:300]})
    return events


def _candidate_lineage_review(row: dict, decision: str = "",
                              prereg_status: str = "") -> dict:
    """L117 候选审核字段：从候选快照提取 lineage/holdout/安全门阻断状态（只读）。

    谱系段在候选生成时由 ``rsi_guard.generation_guard`` 写入 after 快照的
    ``_lineage``（来源/父候选/代数/holdout/扫描摘要/阻断原因）；本函数只做读取与
    展示，不写库、不改变任何候选状态。历史候选（无谱系段）返回 status=unmarked。
    """
    row = dict(row or {})

    def _obj(text):
        try:
            v = json.loads(text or "{}")
        except (TypeError, ValueError):
            return {}
        return v if isinstance(v, dict) else {}

    after, before = _obj(row.get("after_json")), _obj(row.get("before_json"))
    try:
        from . import rsi_guard as _safety
        enabled = bool(_safety.safety_enabled())
        policy_version = _safety.SAFETY_POLICY_VERSION
        key = _safety.SAFETY_LINEAGE_KEY
        lin = after.get(key) if isinstance(after.get(key), dict) else (
            before.get(key) if isinstance(before.get(key), dict) else {})
        max_depth = _safety.SAFETY_MAX_LINEAGE_DEPTH
    except Exception:  # noqa: BLE001 - 安全门不可用：按未标记展示，不阻断视图
        enabled, policy_version, lin, max_depth = False, "", {}, 0
    lineage = {"candidate_type": str(lin.get("candidate_type") or ""),
               "source": lin.get("source") or {},
               "parent_candidate_id": str(lin.get("parent_candidate_id") or ""),
               "generation": int(lin.get("generation") or 0)
               if str(lin.get("generation") or "").lstrip("-").isdigit() else 0,
               "holdout": bool(lin.get("holdout")),
               "holdout_slice": str(lin.get("holdout_slice") or ""),
               "reviewed": bool(lin.get("reviewed")),
               "reviewed_by": str(lin.get("reviewed_by") or ""),
               "created_by": str(lin.get("created_by") or ""),
               "scan_sha256": str(lin.get("scan_sha256") or ""),
               "max_depth": max_depth}
    note_text = str(row.get("note") or "")
    blocked = bool(lin.get("blocked"))
    safety_blocked_via_review = bool(
        str(decision or "") == "blocked" and not blocked
        and ("候选安全门" in note_text or "L117 安全门阻断" in note_text))
    blocked = blocked or safety_blocked_via_review
    if blocked:
        safety_status = "blocked"
    elif lineage["candidate_type"] or lineage["generation"]:
        safety_status = "passed"
    else:
        safety_status = "unmarked"
    reasons = [str(x)[:200] for x in (lin.get("blocked_reasons") or [])][:5]
    if not reasons and safety_blocked_via_review:
        reasons = [seg.strip()[:200] for seg in note_text.split("|")
                   if "候选安全门" in seg or "L117 安全门阻断" in seg][:5]
    safety = {"enabled": enabled, "policy_version": policy_version,
              "status": safety_status,
              "label": {"blocked": "安全门已阻断", "passed": "安全门通过",
                        "unmarked": "历史候选·未标记"}.get(safety_status, safety_status),
              "blocked_stage": str(lin.get("blocked_stage")
                                   or ("review" if safety_blocked_via_review else "")),
              "blocked_at": str(lin.get("blocked_at") or ""),
              "reasons": reasons,
              "prereg_status": str(prereg_status or ""),
              "decision": str(decision or "")}
    hitl = {"enabled": False, "policy_version": "", "approved": False,
            "status": "disabled", "approver": "", "golden": {},
            "pollution": {"ok": None, "issues": []}}
    try:
        from . import rsi_guard as _guard
        _hitl = _guard.hitl_status(str(row.get("id") or ""), deep=False)
        hitl = {"enabled": bool((_hitl.get("policy") or {}).get("enabled")),
                "policy_version": (_hitl.get("policy") or {}).get("policy_version") or "",
                "approved": bool(_hitl.get("approved")),
                "status": _hitl.get("status") or "",
                "approver": _hitl.get("approver") or "",
                "approved_at": _hitl.get("approved_at") or "",
                "reason": _hitl.get("reason") or "",
                "golden": _hitl.get("golden") or {},
                "pollution": _hitl.get("pollution") or {},
                "can_promote": bool(_hitl.get("can_promote"))}
    except Exception:  # noqa: BLE001 - L131 读视图失败按 disabled 展示，不阻断既有视图
        logging.getLogger(__name__).debug(
            "L131 hitl 读视图降级 candidate=%s", row.get("id"), exc_info=True)
    return {"lineage": lineage, "safety": safety,
            "holdout": bool(lineage["holdout"]),
            "hitl": hitl}


def candidate_safety_report(limit: int = 100, user=None) -> dict:
    """L117 候选安全门运行报告（审核/审计用只读视图）。

    返回：策略（白/黑名单、受保护权限事实、开关/回退杆）、``evolution.blocked``
    审计事件（按阶段/分类）、rulegen 候选池扫描摘要、最近候选的谱系/holdout 统计。
    权限与 ``candidate_timeline`` 同口径（evo.view）。
    """
    if user is not None and not user_can_view(user):
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "无权限查看候选安全门报告（需要 evo.view）"}
    try:
        limit = max(1, min(int(limit or 100), 500))
    except (TypeError, ValueError):
        limit = 100
    try:
        from . import rsi_guard as _safety
        summary = _safety.candidate_safety_summary(limit=limit)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning("候选安全门报告降级", exc_info=True)
        summary = {"ok": False, "policy": {}, "blocked_events": [],
                   "rulegen_sweep": {}}
    events = list(summary.get("blocked_events") or [])
    by_stage, by_category = {}, {}
    for ev in events:
        stage = str(ev.get("stage") or "")
        by_stage[stage] = by_stage.get(stage, 0) + 1
        for cat in ev.get("categories") or []:
            by_category[cat] = by_category.get(cat, 0) + 1
    holdout = 0
    lineage_marked = 0
    try:
        for row in R.rsi_candidates.list(order="rowid DESC", limit=limit):
            lr = _candidate_lineage_review(dict(row))
            if lr.get("holdout"):
                holdout += 1
            if lr["lineage"].get("generation"):
                lineage_marked += 1
    except Exception:  # noqa: BLE001
        pass
    # L131：人工审批/黄金集/污染防护运行摘要（只读；开关=0 时如实 disabled）
    hitl_golden = {"enabled": False, "policy": {}, "events": {},
                   "recent": {}, "golden_set": {}}
    try:
        from . import rsi_guard as _guard
        _summary = _guard.guard_summary(limit=limit)
        hitl_golden = {"enabled": bool((_summary.get("policy") or {}).get("enabled")),
                       "policy": _summary.get("policy") or {},
                       "events": _summary.get("events") or {},
                       "recent": _summary.get("recent") or {},
                       "golden_set": _summary.get("golden_set") or {}}
    except Exception:  # noqa: BLE001 - 护栏摘要失败只降级，不改安全门视图
        logging.getLogger(__name__).warning("L131 护栏摘要降级", exc_info=True)
    return {"ok": True, "view": "candidate_safety_report",
            "policy": summary.get("policy") or {},
            "events": {"total": len(events), "by_stage": by_stage,
                       "by_category": by_category, "recent": events[:50]},
            "rulegen_sweep": summary.get("rulegen_sweep") or {},
            "lineage": {"holdout": holdout, "lineage_marked": lineage_marked,
                        "total_scanned": limit},
            "hitl_golden": hitl_golden,
            "audit_action": "evolution.blocked",
            "note": ("每个越界候选在生成/审核/应用阶段写 evolution.blocked；"
                     "blocked 只阻断候选，不改既有发布闸门，也不自动发布")}


def candidate_timeline(limit: int = 50, rule_code: str = "", user=None) -> dict:
    """候选/门禁时间线（S3 断点 2）：状态 + 时间 + 预注册 hash 校验结果。

    L117（2026-11-25）自进化候选安全门接线：
      * **审阅面拦截**：读取候选时间线时对规则判据候选池（rulegen）做安全扫描
        （``rsi_guard.enforce_rulegen_pool``），越界候选置 rejected + evolution.blocked；
      * **审核字段**：每条候选返回 ``lineage``（来源/父候选/代数/holdout 标记/扫描摘要）
        与 ``safety``（生成/审核/应用阶段阻断原因），并给出 blocked 审计事件；
      * 开关 ``RULEPROOF_RSI_SAFETY_GATE=0`` 时以上全部回退为旧返回（不增字段语义）。
    """
    if user is not None and not user_can_view(user):
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "无权限查看候选时间线（需要 evo.view）"}
    try:
        limit = max(1, min(int(limit or 50), 500))
    except (TypeError, ValueError):
        limit = 50
    # L117 安全门（审阅面）：rulegen 候选池扫描阻断；失败只降级，不影响视图读取
    safety = {"enabled": True, "policy_version": "", "rulegen_sweep": {},
              "blocked_recent": []}
    try:
        from . import rsi_guard as _safety
        safety = {"enabled": bool(_safety.safety_enabled()),
                  "policy_version": _safety.SAFETY_POLICY_VERSION,
                  "rulegen_sweep": _safety._rulegen_sweep_summary(limit=200),
                  "blocked_recent": _safety.blocked_events(limit=20)}
    except Exception:  # noqa: BLE001 - 安全门读取失败不得让候选视图 500
        logging.getLogger(__name__).warning("候选安全门读视图降级", exc_info=True)
    backfill = _prereg_backfill_new(limit=200)
    _prereg_ensure()
    try:
        with db.session() as c:
            if rule_code:
                rows = c.execute(
                    "SELECT * FROM rsi_candidate WHERE rule_code=? ORDER BY rowid DESC LIMIT ?",
                    (str(rule_code), limit)).fetchall()
            else:
                rows = c.execute(
                    "SELECT * FROM rsi_candidate ORDER BY rowid DESC LIMIT ?", (limit,)).fetchall()
    except Exception as e:
        return {"ok": False, "status": 500, "code": "storage_unavailable",
                "error": f"候选读取失败：{type(e).__name__}"}
    items = []
    stats = {"total": 0, "by_decision": {}, "prereg_verified": 0,
             "prereg_mismatch": 0, "prereg_legacy_null": 0, "prereg_unreadable": 0,
             "blocked_by_prereg": 0, "blocked_by_safety": 0, "holdout": 0,
             "lineage_marked": 0, "hitl_approved": 0, "hitl_pending": 0,
             "hitl_golden_degraded": 0, "hitl_golden_insufficient": 0}
    for row in rows:
        row = dict(row)
        cid = str(row.get("id") or "")
        verify = prereg_assert(cid, by="gate-read", block=True)
        status = str(verify.get("status") or "")
        decision = ("blocked" if status == "mismatch" else str(row.get("decision") or ""))
        stats["total"] += 1
        stats["by_decision"][decision] = stats["by_decision"].get(decision, 0) + 1
        if status == "verified":
            stats["prereg_verified"] += 1
        elif status == "mismatch":
            stats["prereg_mismatch"] += 1
            stats["blocked_by_prereg"] += 1
        elif status == "legacy_null":
            stats["prereg_legacy_null"] += 1
        elif status == "unreadable":
            stats["prereg_unreadable"] += 1
        lineage_review = _candidate_lineage_review(row, decision, status)
        if lineage_review.get("lineage", {}).get("holdout"):
            stats["holdout"] += 1
        if lineage_review.get("lineage", {}).get("generation"):
            stats["lineage_marked"] += 1
        if str(lineage_review.get("safety", {}).get("status") or "") == "blocked":
            stats["blocked_by_safety"] += 1
        _hitl = lineage_review.get("hitl") or {}
        if _hitl.get("approved"):
            stats["hitl_approved"] += 1
        elif _hitl.get("enabled") and decision in ("pending", "accepted", "uncertain"):
            stats["hitl_pending"] += 1
        _gv = str((_hitl.get("golden") or {}).get("verdict") or "")
        if _gv == "degraded":
            stats["hitl_golden_degraded"] += 1
        elif _gv == "insufficient_evidence":
            stats["hitl_golden_insufficient"] += 1
        items.append({
            "id": cid,
            "feedback_id": row.get("feedback_id") or "",
            "rule_code": row.get("rule_code") or "",
            "action": row.get("action") or "",
            "decision": decision,
            "decision_label": {"pending": "待验收", "accepted": "已通过",
                               "blocked": "已阻断", "uncertain": "无法确证",
                               "rolled_back": "已回滚"}.get(decision, decision),
            "note": str(row.get("note") or "")[:300],
            "created_at": row.get("created_at") or "",
            "decided_at": row.get("decided_at") or "",
            "decided_by": row.get("decided_by") or "",
            "prereg": {
                "status": status,
                "label": {"verified": "hash 一致", "mismatch": "hash 不一致·已阻断",
                          "legacy_null": "历史候选·未预注册（允许 null）",
                          "unreadable": "预注册不可读", "not_found": "候选不存在",
                          "disabled": "断言已回滚（RULEPROOF_PREREG=0）",
                          }.get(status, status),
                "sha256": verify.get("prereg_sha256") or verify.get("actual") or
                          str(row.get("prereg_sha256") or ""),
                "expected": verify.get("expected") or "",
                "ref": verify.get("prereg_ref") or row.get("prereg_ref") or "",
                "at": row.get("prereg_at") or "",
                "by": row.get("prereg_by") or "",
                "verified": bool(verify.get("verified")),
                "blocked": status == "mismatch",
            },
            "timeline": _candidate_gate_events(cid),
            # L117 审核字段（最小落地）：谱系 + 安全门状态（不改变既有字段语义）
            **lineage_review,
        })
    return {"ok": True, "view": "candidate_timeline",
            "backfill": backfill, "items": items, "stats": stats,
            "safety": safety,
            "note": ("门禁读取即断言：预注册 hash 不一致 → 候选 blocked + 审计 "
                     "rsi.gate_blocked；历史候选 null 不阻断、标未验证；"
                     "L117 安全门：rulegen 候选池读取即扫描，越界候选 rejected + "
                     "evolution.blocked；候选带 lineage/holdout/safety 审核字段")}


def effective_versions(limit: int = 50, user=None) -> dict:
    """生效版本与回滚（S3 断点 3）：版本列表 + 生效版本 + 回滚只读记录。"""
    if user is not None and not user_can_view(user):
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "无权限查看生效版本（需要 evo.view）"}
    try:
        limit = max(1, min(int(limit or 50), 500))
    except (TypeError, ValueError):
        limit = 50
    can_manage = user_can_manage(user)
    try:
        rules = R.rules.list(order="created_at DESC", limit=limit)
    except Exception:
        rules = []
    items = []
    effective_count = 0
    for r in rules:
        rid = str(r.get("id") or "")
        code = str(r.get("code") or "")
        pub = None
        try:
            pub = R.rules.published_version(rid)
        except Exception:
            pub = None
        try:
            vers = R.rule_versions.list("rule_id=?", (rid,), order="rowid DESC", limit=5)
        except Exception:
            vers = []
        effective = None
        if pub:
            effective = {"id": pub.get("id") or "", "version": pub.get("version") or "",
                         "status": pub.get("status") or "",
                         "published_at": pub.get("published_at") or ""}
            effective_count += 1
        status = str(r.get("status") or "")
        items.append({
            "rule_id": rid, "code": code, "name": r.get("name") or "",
            "category": r.get("category") or "", "status": status,
            "status_label": {"draft": "草稿", "pending": "待审批", "approved": "已审批",
                             "published": "已发布", "archived": "已下线"}.get(status, status),
            "effective": effective,
            "versions": [{"id": v.get("id") or "", "version": v.get("version") or "",
                          "status": v.get("status") or "",
                          "published_at": v.get("published_at") or "",
                          "superseded_at": v.get("superseded_at") or "",
                          "approved_by": v.get("approved_by") or ""} for v in vers],
            "can_rollback": bool(status in ("published", "approved", "pending") and can_manage),
            "rollback_hint": ("回滚为草稿（旧生效版本继续执行到新版本发布）"
                              if status in ("published", "approved", "pending")
                              else "当前状态不可回滚"),
        })
    rollback_records = []
    try:
        rows = R.audit_logs.list(
            "action IN (?,?,?,?)",
            ("rule.rollback", "rsi.rollback", "rule.effective_select_rollback_detected",
             "evolution.rollback"),
            order="created_at DESC", limit=limit)
    except Exception:
        rows = []
    for r in rows:
        rollback_records.append({
            "at": r.get("created_at") or "", "actor": r.get("actor") or "",
            "action": r.get("action") or "", "object": r.get("object") or "",
            "detail": str(r.get("after_json") or "")[:300],
        })
    return {"ok": True, "view": "effective_versions", "items": items,
            "rollback_records": rollback_records,
            "stats": {"rules": len(items), "effective": effective_count,
                      "rollback_records": len(rollback_records)},
            "permissions": {"can_manage": can_manage, "readonly": not can_manage},
            "note": ("生效口径 = rule.current_version_id 且该版本 status=published；"
                     "回滚按钮只对 pending/approved/published 显示，reviewer 只读")}

