# -*- coding: utf-8 -*-
"""L50 规则分组标签服务：组织用的「分组/标签」+ 批量打标 + 分组全链路自检。

与 ``rule.scope_json.tags``（路由标签）严格区分（用户需求 + 设计约束 1）：

- 本模块的标签是**组织管理维度**，存放在独立表 ``rule_tag`` / ``rule_tag_item``，
  **绝不写 rule.scope_json / slots**，因此不影响 manifest 路由、D1 触发与发布门禁；
- ``scope.tags`` 是审核语义务的路由标签（rule.search_by_tags / manifest 消费），
  两者同名不同域，互不读写。

隔离（设计约束 2）：
- 所有读写都按请求上下文 ctx 的 ``tenant_id/workspace_id`` 强隔离：
  ``rule_tag`` 行带 tenant/workspace；跨租户、跨空间不可见、不可改（统一 404）；
- 标签列表/全链路自检只读当前工作空间；
- 打标只允许当前工作空间内可见的规则（规则表 workspace 精确匹配），不借
  ``R.rules.get`` 的租户级 include_global 口径跨空间写。

权限（设计约束 3）：
- create/rename/delete = admin / super_admin；
- assign/unassign = reviewer / admin / super_admin（审核员可创建规则）；
- list / full-audit = 登录用户（reviewer/admin/super_admin/platform_op）；
- 所有写操作写 audit_logs（与业务写同事务，使用 audit.log_in_tx）。
  HTTP 层系统管理员仍受 F-28 业务边界（``role_scope.super_admin_denied``）约束：
  super_admin 的写请求在 server._guard 处 403，读请求放行；本文件的服务层按显式
  需求放行 super_admin，供 CLI / 内部任务复用同一套服务。

全链路自检（full_audit）只读 dry-run，不写规则状态、不实际跑文档审核：
对组内每条规则依次检查 scope 完整性、``rule_ir.compile_rule`` 可编译、引擎
``rule_schema.executor_reachable`` 执行器可达、``rule._pre_lifecycle_gates(
require_executor=True)`` 发布门禁，并汇总当前发布/生效状态，逐条给出
``issues`` / ``next_action`` 与 ``summary``（ready/blocked/draft/published + by_issue）。

回滚：
- 功能级：删除 ``app/api/rule_tag_routes.py`` 的 server.py 分发 + 本文件即可回到旧行为；
- 数据级：``DROP TABLE rule_tag_item; DROP TABLE rule_tag``（纯组织数据，不参与判定）；
- 老库由 ``init_db`` 的 ``SCHEMA``（CREATE TABLE IF NOT EXISTS）幂等补表，无需手工迁移。
"""
from __future__ import annotations

import json
import logging
import re

from .. import db
from .. import repositories as R
from . import ctx as _ctx

# --------------------------------------------------------------------------- 常量
MANAGE_ROLES = ("admin", "super_admin")
ASSIGN_ROLES = ("reviewer", "admin", "super_admin")
READ_ROLES = ("reviewer", "admin", "super_admin", "platform_op")

MAX_TAG_NAME = 40
MAX_TAGS_PER_WORKSPACE = 200
MAX_RULES_PER_CALL = 500
MAX_BATCH_TAGS = 20
MAX_AUDIT_LIMIT = 500
DEFAULT_AUDIT_LIMIT = 200

# 分组色板：与浅蓝主题兼容的低饱和色；未指定 color 时按名称稳定取色（可复现）。
PALETTE = ("#2F6BFF", "#0EA5A4", "#7C3AED", "#DB2777",
           "#D97706", "#16A34A", "#0891B2", "#9333EA")

_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")

# issues 等级：block=阻断发布/执行；draft=可补全/流程中；warn=提示（不参与状态判定）
LEVEL_BLOCK = "block"
LEVEL_DRAFT = "draft"
LEVEL_WARN = "warn"

# 发布门禁错误 → (等级, 可读 next_action)。未知错误 fail-closed 视为阻断。
_GATE_LEVEL = {
    "executor_unreachable": (LEVEL_BLOCK, "fix_executor"),
    "ir_invalid": (LEVEL_BLOCK, "edit_slots"),
    "ir_needs_structure": (LEVEL_DRAFT, "edit_slots"),
    "ir_incomplete": (LEVEL_DRAFT, "edit_slots"),
    "scope_missing": (LEVEL_BLOCK, "edit_scope"),
    "scope_wildcard_forbidden": (LEVEL_BLOCK, "edit_scope"),
    "scope_workspace_wide_reason_required": (LEVEL_DRAFT, "edit_scope"),
    "decision_table_binding_invalid": (LEVEL_BLOCK, "fix_binding"),
    "decision_table_binding_unverified": (LEVEL_BLOCK, "fix_binding"),
    "regression_blocked": (LEVEL_BLOCK, "fix_regression"),
    "no_version": (LEVEL_BLOCK, "edit_slots"),
    "invalid_transition": (LEVEL_BLOCK, "review"),
    "concurrent_transition": (LEVEL_WARN, "retry"),
}

_NEXT_ACTION_LABEL = {
    "none": "已生效，无需操作",
    "publish": "发布生效",
    "approve": "批准（旧审批流程）后发布",
    "edit_scope": "补适用范围（scope）后发布",
    "edit_slots": "补判据/槽位后发布",
    "fix_executor": "修执行器/模板配置后发布",
    "fix_binding": "修复决策表绑定后发布",
    "fix_regression": "修复版本回归问题后发布",
    "restore": "恢复已下线规则后再发布",
    "review": "人工复核发布状态",
    "retry": "稍后重试",
    "remove_item": "从分组移除（规则已不存在）",
}


class RuleTagError(Exception):
    """服务层可映射为 HTTP 的错误（路由层统一转 code/error/http_status）。"""

    def __init__(self, status: int, code: str, message: str, extra: dict | None = None):
        super().__init__(message)
        self.status = int(status)
        self.code = str(code)
        self.message = str(message)
        self.extra = dict(extra or {})

    def payload(self) -> dict:
        out = {"ok": False, "error": self.message, "code": self.code,
               "http_status": self.status}
        out.update(self.extra)
        return out


# --------------------------------------------------------------------------- 基础
def _scope() -> tuple:
    """当前请求上下文 (tenant_id, workspace_id)，缺失即拒绝（不静默落默认库）。"""
    cur = _ctx.get_context() or {}
    tenant = str(cur.get("tenant_id") or "")
    workspace = str(cur.get("workspace_id") or "")
    if not tenant or not workspace:
        raise RuleTagError(403, "workspace_required",
                           "缺少租户/工作空间上下文，无法操作规则分组标签")
    return tenant, workspace


def _role(user: dict) -> str:
    return str((user or {}).get("role") or "")


def _actor(user: dict) -> str:
    u = user or {}
    return str(u.get("sub") or u.get("user_id") or u.get("name") or "system")


def _require_role(user: dict, allowed, action: str) -> str:
    role = _role(user)
    if role not in allowed:
        label = "业务管理员" if tuple(allowed) == MANAGE_ROLES else "业务管理员/审核员"
        raise RuleTagError(403, "forbidden", f"无权限（{action}需{label}角色）")
    return role


def _validate_name(name) -> str:
    value = str(name or "").strip()
    if not value:
        raise RuleTagError(400, "invalid_tag_name", "分组标签名称不能为空")
    if len(value) > MAX_TAG_NAME:
        raise RuleTagError(400, "invalid_tag_name", f"分组标签名称不能超过 {MAX_TAG_NAME} 个字")
    if _CTRL_RE.search(value):
        raise RuleTagError(400, "invalid_tag_name", "分组标签名称不能包含控制字符")
    return value


def _validate_color(color, name: str) -> str:
    value = str(color or "").strip()
    if not value:
        return PALETTE[sum(ord(ch) for ch in name) % len(PALETTE)]
    if len(value) > 32 or _CTRL_RE.search(value):
        raise RuleTagError(400, "invalid_tag_color", "分组标签颜色格式非法（≤32 字符）")
    if not _COLOR_RE.match(value):
        raise RuleTagError(400, "invalid_tag_color", "分组标签颜色须为 #RRGGBB 十六进制色值")
    return value.upper()


def _tag_dict(row: dict, rule_count: int = 0) -> dict:
    return {"id": row.get("id") or "", "name": row.get("name") or "",
            "color": row.get("color") or "", "rule_count": int(rule_count or 0),
            "created_by": row.get("created_by") or "",
            "created_at": row.get("created_at") or "",
            "updated_at": row.get("updated_at") or "",
            "tenant_id": row.get("tenant_id") or "",
            "workspace_id": row.get("workspace_id") or ""}


def _tag_row(tag_id: str, tenant: str, workspace: str) -> dict | None:
    tid = str(tag_id or "").strip()
    if not tid:
        return None
    with db.session() as c:
        r = c.execute("SELECT * FROM rule_tag WHERE id=? AND tenant_id=? AND workspace_id=?",
                      (tid, tenant, workspace)).fetchone()
    return dict(r) if r else None


def _tag_or_404(tag_id: str, tenant: str, workspace: str) -> dict:
    row = _tag_row(tag_id, tenant, workspace)
    if not row:
        raise RuleTagError(404, "not_found", "规则分组标签不存在或当前工作空间不可见")
    return row


def _find_tag_by_name(name: str, tenant: str, workspace: str) -> dict | None:
    with db.session() as c:
        r = c.execute("SELECT * FROM rule_tag WHERE tenant_id=? AND workspace_id=? AND name=?",
                      (tenant, workspace, name)).fetchone()
    return dict(r) if r else None


def _audit_in_tx(c, actor: str, action: str, object_: str, after: dict) -> None:
    from . import audit as _audit
    _audit.log_in_tx(c, actor=actor, action=action, object_=object_,
                     after=json.dumps(after, ensure_ascii=False))


def _rules_by_keys(keys: list, tenant: str, workspace: str) -> tuple:
    """把规则 id/code 列表解析为当前空间可见规则行；返回 (rows, missing)。"""
    out, missing, seen = [], [], set()
    with db.session() as c:
        for key in keys:
            k = str(key or "").strip()
            if not k or k in seen:
                continue
            seen.add(k)
            row = c.execute(
                "SELECT id, code, name, status, tenant_id, workspace_id, source "
                "FROM rule WHERE id=?", (k,)).fetchone()
            if row is None:
                row = c.execute(
                    "SELECT id, code, name, status, tenant_id, workspace_id, source "
                    "FROM rule WHERE code=? AND COALESCE(tenant_id,'')=?",
                    (k, tenant)).fetchone()
            if row is None:
                missing.append(k)
                continue
            d = dict(row)
            if str(d.get("tenant_id") or "") not in ("", tenant) \
                    or str(d.get("workspace_id") or "") != workspace:
                missing.append(k)
                continue
            out.append(d)
    return out, missing


def _rule_item_ids(tag_id: str) -> list:
    with db.session() as c:
        rows = c.execute("SELECT rule_id FROM rule_tag_item WHERE tag_id=? ORDER BY rowid ASC",
                         (tag_id,)).fetchall()
    return [str(r[0]) for r in rows if r and r[0]]


def _rule_rows_for_ids(rule_ids: list, tenant: str, workspace: str) -> dict:
    if not rule_ids:
        return {}
    ph = ",".join("?" * len(rule_ids))
    with db.session() as c:
        rows = c.execute(
            "SELECT * FROM rule WHERE id IN (%s) AND COALESCE(tenant_id,'')=? "
            "AND COALESCE(workspace_id,'')=?" % ph,
            (*rule_ids, tenant, workspace)).fetchall()
    return {str(r["id"]): dict(r) for r in rows}


def _versions_for_ids(rule_ids: list) -> dict:
    """一次查询取回全部版本行 → {rule_id: {"latest": row, "published": row}}。"""
    out = {}
    if not rule_ids:
        return out
    ph = ",".join("?" * len(rule_ids))
    with db.session() as c:
        rows = c.execute(
            "SELECT * FROM rule_version WHERE rule_id IN (%s) ORDER BY rowid ASC" % ph,
            tuple(rule_ids)).fetchall()
    for r in rows:
        d = dict(r)
        rid = str(d.get("rule_id") or "")
        slot = out.setdefault(rid, {"latest": None, "published": None})
        slot["latest"] = d
        if str(d.get("status") or "") == "published":
            slot["published"] = d
    return out


# --------------------------------------------------------------------------- 读取
def list_tags(user: dict) -> dict:
    """当前工作空间的分组标签列表（含每标签的有效规则数）。"""
    _require_role(user, READ_ROLES, "查看分组标签")
    tenant, workspace = _scope()
    with db.session() as c:
        rows = c.execute(
            "SELECT t.*, COUNT(r.id) AS rule_count FROM rule_tag t "
            "LEFT JOIN rule_tag_item i ON i.tag_id=t.id "
            "LEFT JOIN rule r ON r.id=i.rule_id "
            "  AND COALESCE(r.tenant_id,'')=t.tenant_id "
            "  AND COALESCE(r.workspace_id,'')=t.workspace_id "
            "WHERE t.tenant_id=? AND t.workspace_id=? "
            "GROUP BY t.id ORDER BY t.name COLLATE NOCASE ASC",
            (tenant, workspace)).fetchall()
    items = [_tag_dict(dict(r), r["rule_count"] or 0) for r in rows]
    role = _role(user)
    return {"ok": True, "items": items, "total": len(items),
            "tenant_id": tenant, "workspace_id": workspace,
            "perms": {"can_manage": role in MANAGE_ROLES,
                      "can_assign": role in ASSIGN_ROLES,
                      "can_full_audit": role in READ_ROLES}}


def tags_for_rules(rule_ids, user: dict | None = None) -> dict:
    """批量规则 → {rule_id: [{id,name,color}]}（只返回当前空间可见标签）。"""
    ids = []
    for x in (rule_ids or []):
        s = str(x or "").strip()
        if s and s not in ids:
            ids.append(s)
    if not ids:
        return {}
    try:
        tenant, workspace = _scope()
    except RuleTagError:
        return {rid: [] for rid in ids}
    out = {rid: [] for rid in ids}
    for i in range(0, len(ids), 300):
        chunk = ids[i:i + 300]
        ph = ",".join("?" * len(chunk))
        with db.session() as c:
            rows = c.execute(
                "SELECT i.rule_id, t.id AS tag_id, t.name, t.color FROM rule_tag_item i "
                "JOIN rule_tag t ON t.id=i.tag_id "
                "WHERE i.rule_id IN (%s) AND t.tenant_id=? AND t.workspace_id=? "
                "ORDER BY t.name COLLATE NOCASE ASC" % ph,
                (*chunk, tenant, workspace)).fetchall()
        for r in rows:
            d = dict(r)
            out.setdefault(str(d["rule_id"]), []).append(
                {"id": d.get("tag_id") or "", "name": d.get("name") or "",
                 "color": d.get("color") or ""})
    return out


def attach_tags(rows: list) -> list:
    """给 GET /api/v1/rules 行附 ``tags``（就地修改，返回同一列表）。"""
    if not rows:
        return rows
    mapping = tags_for_rules([str(x.get("id") or "") for x in rows])
    for row in rows:
        row["tags"] = mapping.get(str(row.get("id") or ""), [])
    return rows


def filter_rules_by_tag(rows: list, tag_id: str, user: dict | None = None):
    """按分组标签过滤规则行；标签不存在/跨空间 → None（调用方 404）。"""
    try:
        tenant, workspace = _scope()
    except RuleTagError:
        return None
    tag = _tag_row(tag_id, tenant, workspace)
    if not tag:
        return None
    ids = set(_rule_item_ids(tag["id"]))
    if not ids:
        return []
    return [row for row in rows if str(row.get("id") or "") in ids]


# --------------------------------------------------------------------------- 写：标签
def create_tag(user: dict, name, color: str = "") -> dict:
    _require_role(user, MANAGE_ROLES, "创建分组标签")
    tenant, workspace = _scope()
    tag_name = _validate_name(name)
    tag_color = _validate_color(color, tag_name)
    actor = _actor(user)
    if _find_tag_by_name(tag_name, tenant, workspace):
        raise RuleTagError(409, "duplicate_tag", f"分组标签「{tag_name}」已存在", {"name": tag_name})
    with db.session() as c:
        n = c.execute("SELECT COUNT(*) FROM rule_tag WHERE tenant_id=? AND workspace_id=?",
                      (tenant, workspace)).fetchone()[0]
    if int(n or 0) >= MAX_TAGS_PER_WORKSPACE:
        raise RuleTagError(400, "too_many_tags",
                           f"单个工作空间最多 {MAX_TAGS_PER_WORKSPACE} 个分组标签")
    now = db.now()
    row = {"id": db.new_id("rt"), "tenant_id": tenant, "workspace_id": workspace,
           "name": tag_name, "color": tag_color, "created_by": actor,
           "created_at": now, "updated_at": now}
    try:
        with db.session() as c:
            c.execute("INSERT INTO rule_tag(id, tenant_id, workspace_id, name, color, "
                      "created_by, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?)",
                      (row["id"], row["tenant_id"], row["workspace_id"], row["name"],
                       row["color"], row["created_by"], row["created_at"], row["updated_at"]))
            _audit_in_tx(c, actor, "rule_tag.created", row["id"],
                         {"name": row["name"], "color": row["color"]})
    except Exception as exc:  # 唯一约束并发兜底
        if "UNIQUE" in str(exc).upper():
            raise RuleTagError(409, "duplicate_tag",
                               f"分组标签「{tag_name}」已存在", {"name": tag_name}) from exc
        raise
    return {"ok": True, "tag": _tag_dict(row), "created": True}


def rename_tag(user: dict, tag_id: str, name=None, color=None) -> dict:
    _require_role(user, MANAGE_ROLES, "重命名分组标签")
    tenant, workspace = _scope()
    tag = _tag_or_404(tag_id, tenant, workspace)
    if name is None and color is None:
        raise RuleTagError(400, "invalid_request", "缺少 name 或 color，未做任何修改")
    new_name = _validate_name(name) if name is not None else tag["name"]
    new_color = _validate_color(color, new_name) if color is not None else tag["color"]
    if new_name != tag["name"]:
        other = _find_tag_by_name(new_name, tenant, workspace)
        if other and other.get("id") != tag["id"]:
            raise RuleTagError(409, "duplicate_tag", f"分组标签「{new_name}」已存在",
                               {"name": new_name})
    now = db.now()
    try:
        with db.session() as c:
            c.execute("UPDATE rule_tag SET name=?, color=?, updated_at=? "
                      "WHERE id=? AND tenant_id=? AND workspace_id=?",
                      (new_name, new_color, now, tag["id"], tenant, workspace))
            _audit_in_tx(c, _actor(user), "rule_tag.renamed", tag["id"],
                         {"from": {"name": tag["name"], "color": tag["color"]},
                          "to": {"name": new_name, "color": new_color}})
    except Exception as exc:
        if "UNIQUE" in str(exc).upper():
            raise RuleTagError(409, "duplicate_tag", f"分组标签「{new_name}」已存在") from exc
        raise
    tag.update({"name": new_name, "color": new_color, "updated_at": now})
    return {"ok": True, "tag": _tag_dict(tag, len(_rule_item_ids(tag["id"]))),
            "renamed": True}


def delete_tag(user: dict, tag_id: str) -> dict:
    _require_role(user, MANAGE_ROLES, "删除分组标签")
    tenant, workspace = _scope()
    tag = _tag_or_404(tag_id, tenant, workspace)
    unlinked = len(_rule_item_ids(tag["id"]))
    with db.session() as c:
        c.execute("DELETE FROM rule_tag_item WHERE tag_id=?", (tag["id"],))
        c.execute("DELETE FROM rule_tag WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (tag["id"], tenant, workspace))
        _audit_in_tx(c, _actor(user), "rule_tag.deleted", tag["id"],
                     {"name": tag["name"], "unlinked": unlinked})
    return {"ok": True, "deleted": tag["id"], "unlinked": unlinked,
            "tag": _tag_dict(tag, 0)}


# --------------------------------------------------------------------------- 写：打标
def _normalize_keys(body: dict) -> list:
    raw = []
    for field in ("rule_ids", "rules", "rule_id"):
        val = (body or {}).get(field)
        if val is None:
            continue
        if isinstance(val, (list, tuple)):
            raw.extend(list(val))
        else:
            raw.append(val)
    keys = []
    for x in raw:
        s = str(x or "").strip()
        if s and s not in keys:
            keys.append(s)
    return keys


def assign(user: dict, tag_id: str, body: dict) -> dict:
    """把规则加入分组（单/批量，幂等）：body.rule_ids / rules / rule_id。"""
    _require_role(user, ASSIGN_ROLES, "规则打标")
    tenant, workspace = _scope()
    tag = _tag_or_404(tag_id, tenant, workspace)
    keys = _normalize_keys(body)
    if not keys:
        raise RuleTagError(400, "invalid_request", "缺少 rule_ids/rule_id（至少一条规则）")
    if len(keys) > MAX_RULES_PER_CALL:
        raise RuleTagError(400, "too_many_rules",
                           f"单次最多 {MAX_RULES_PER_CALL} 条规则")
    rows, missing = _rules_by_keys(keys, tenant, workspace)
    if missing:
        raise RuleTagError(404, "rule_not_found",
                           "部分规则不存在或不在当前工作空间：" + "、".join(missing[:10]),
                           {"missing": missing[:50]})
    actor = _actor(user)
    now = db.now()
    added, already = [], []
    with db.session() as c:
        for row in rows:
            cur = c.execute(
                "INSERT OR IGNORE INTO rule_tag_item(tag_id, rule_id, created_by, created_at) "
                "VALUES(?,?,?,?)", (tag["id"], row["id"], actor, now))
            if cur.rowcount and cur.rowcount > 0:
                added.append(row["id"])
            else:
                already.append({"rule_id": row["id"], "code": row.get("code") or "",
                                "reason": "已在该分组"})
        _audit_in_tx(c, actor, "rule_tag.assigned", tag["id"],
                     {"name": tag["name"], "added": len(added),
                      "already": len(already), "rules": added[:50]})
    return {"ok": True, "tag": _tag_dict(tag, len(_rule_item_ids(tag["id"]))),
            "assigned": added, "added": len(added), "already": already,
            "total": len(rows)}


def unassign(user: dict, tag_id: str, body: dict) -> dict:
    """把规则移出分组（单/批量，幂等）：不存在/不可见的规则记 skipped，不阻断。"""
    _require_role(user, ASSIGN_ROLES, "取消规则打标")
    tenant, workspace = _scope()
    tag = _tag_or_404(tag_id, tenant, workspace)
    keys = _normalize_keys(body)
    if not keys:
        raise RuleTagError(400, "invalid_request", "缺少 rule_ids/rule_id（至少一条规则）")
    if len(keys) > MAX_RULES_PER_CALL:
        raise RuleTagError(400, "too_many_rules",
                           f"单次最多 {MAX_RULES_PER_CALL} 条规则")
    rows, missing = _rules_by_keys(keys, tenant, workspace)
    actor = _actor(user)
    removed, skipped = [], [{"rule_id": m, "reason": "规则不存在或当前工作空间不可见"}
                            for m in missing]
    with db.session() as c:
        for row in rows:
            cur = c.execute("DELETE FROM rule_tag_item WHERE tag_id=? AND rule_id=?",
                            (tag["id"], row["id"]))
            if cur.rowcount and cur.rowcount > 0:
                removed.append(row["id"])
            else:
                skipped.append({"rule_id": row["id"], "code": row.get("code") or "",
                                "reason": "不在该分组"})
        _audit_in_tx(c, actor, "rule_tag.unassigned", tag["id"],
                     {"name": tag["name"], "removed": len(removed),
                      "skipped": len(skipped), "rules": removed[:50]})
    return {"ok": True, "tag": _tag_dict(tag, len(_rule_item_ids(tag["id"]))),
            "removed": removed, "skipped": skipped, "total": len(keys)}


# --------------------------------------------------------------------------- 全链路自检
def _next_action(code: str) -> str:
    return code if code in _NEXT_ACTION_LABEL else "review"


def _issue(code: str, level: str, message: str, next_action: str) -> dict:
    return {"code": code, "level": level, "message": message,
            "next_action": _next_action(next_action)}


def _merge_issue(issues: list, item: dict) -> None:
    """按 code 去重；同 code 升级等级 block > draft > warn（保留首条可读文案）。"""
    _rank = {LEVEL_BLOCK: 3, LEVEL_DRAFT: 2, LEVEL_WARN: 1}
    for idx, old in enumerate(issues):
        if old.get("code") == item.get("code"):
            if _rank.get(item["level"], 0) > _rank.get(old["level"], 0):
                issues[idx] = item
            return
    issues.append(item)


def _gate_issue(gate: dict) -> dict | None:
    if not gate:
        return None
    code = str(gate.get("error") or "gate_failed")
    level, action = _GATE_LEVEL.get(code, (LEVEL_BLOCK, "review"))
    if code == "ir_needs_structure" and not gate.get("completable"):
        level = LEVEL_BLOCK
    msg = str(gate.get("message") or "").strip() or f"发布门禁未通过：{code}"
    if code == "ir_needs_structure" and gate.get("missing"):
        msg = msg + "（缺：" + "、".join(str(x) for x in (gate.get("missing") or [])[:6]) + "）"
    if code == "ir_incomplete" and gate.get("missing"):
        msg = msg + "（缺：" + "、".join(str(x) for x in (gate.get("missing") or [])[:6]) + "）"
    return _issue(code, level, msg, action)


def _rule_scope_info(row: dict, slots: dict) -> dict:
    from . import rule as _rule_svc
    try:
        scope_obj = json.loads(row.get("scope_json") or "{}")
    except Exception:
        scope_obj = {}
    if not isinstance(scope_obj, dict):
        scope_obj = {}
    try:
        derived = _rule_svc.derive_rule_scope(scope_obj, slots, rule=row)
    except Exception as exc:  # 派生失败 fail-closed：按未声明处理
        logging.getLogger(__name__).warning("rule tag full_audit scope derive failed: %s",
                                            type(exc).__name__)
        derived = {"declared": False, "status": "missing",
                   "route_types": [], "tags": [], "tags_only": False,
                   "workspace_wide": False}
    return derived


def _audit_one_rule(row: dict, version: dict, published_version: dict) -> dict:
    """单条规则的全链路自检（只读，不写状态、不跑审核）。"""
    from . import rule as _rule_svc
    try:
        from .rule_ir import compile_rule as _compile_rule
    except Exception:  # pragma: no cover - 导入失败按不可编译处理
        _compile_rule = None
    try:
        from ..engine import rule_schema as _engine_schema
    except Exception:  # pragma: no cover
        _engine_schema = None

    issues = []
    status = str(row.get("status") or "")
    rid = str(row.get("id") or "")
    try:
        slots = json.loads((version or {}).get("slots_json") or "{}")
    except Exception:
        slots = {}
    if not isinstance(slots, dict):
        slots = {}

    # ---- 1) 版本 ----
    if not version:
        _merge_issue(issues, _issue("version_missing", LEVEL_BLOCK,
                                    "规则没有版本记录，无法编译/发布", "edit_slots"))
        slots = {}

    # ---- 2) scope 完整性（与发布门禁同源 derive_rule_scope）----
    scope = _rule_scope_info(row, slots)
    wildcard = [str(x) for x in (scope.get("wildcard_tokens") or [])]
    if wildcard:
        _merge_issue(issues, _issue(
            "scope_wildcard_forbidden", LEVEL_BLOCK,
            "适用范围含隐式全量通配（" + "、".join(wildcard[:5]) + "），发布会被拒绝",
            "edit_scope"))
    elif not scope.get("declared"):
        _merge_issue(issues, _issue(
            "scope_missing", LEVEL_BLOCK,
            "规则未声明适用范围（applicable_types/applicable_when），发布会被拒绝",
            "edit_scope"))

    # ---- 3) 规则 IR 可编译 ----
    compilable = False
    publishable = False
    if _compile_rule is not None and version:
        try:
            comp = _compile_rule(slots, row.get("category") or "",
                                 row.get("rclass") or "", row.get("name") or "")
            compilable = bool(comp.get("complete"))
            publishable = bool(comp.get("publishable"))
            if not compilable:
                missing = [str(x) for x in (comp.get("missing") or []) if str(x).strip()]
                msg = "规则 IR 不完整（缺少判据/阈值/结构化条件），发布会被拒绝"
                if missing:
                    msg += "（缺：" + "、".join(missing[:6]) + "）"
                _merge_issue(issues, _issue("ir_incomplete", LEVEL_DRAFT, msg, "edit_slots"))
            elif not publishable:
                _merge_issue(issues, _issue(
                    "ir_needs_structure", LEVEL_DRAFT,
                    "规则缺可补全的发布结构，补齐后即可发布", "edit_slots"))
        except Exception as exc:  # pragma: no cover - 编译异常按不可编译
            logging.getLogger(__name__).warning("rule tag full_audit compile failed: %s",
                                                type(exc).__name__)
            _merge_issue(issues, _issue("compile_failed", LEVEL_BLOCK,
                                        f"规则 IR 编译异常：{type(exc).__name__}", "review"))

    # ---- 4) 执行器可达 ----
    executor_ok, executor_why = True, ""
    if _engine_schema is not None and version:
        try:
            executor_ok, executor_why = _engine_schema.executor_reachable(slots)
        except Exception as exc:  # pragma: no cover
            executor_ok, executor_why = False, f"执行器检查异常：{type(exc).__name__}"
        if not executor_ok:
            _merge_issue(issues, _issue(
                "executor_unreachable", LEVEL_BLOCK,
                str(executor_why or "规则模板没有可达的执行器"), "fix_executor"))

    # ---- 5) 发布门禁 dry-run（require_executor=True，与 publish 同源）----
    gate = {}
    if version:
        try:
            gate = _rule_svc._pre_lifecycle_gates(rid, row, version,
                                                 action="发布", require_executor=True) or {}
        except Exception as exc:
            logging.getLogger(__name__).warning("rule tag full_audit gate failed: %s",
                                                type(exc).__name__)
            gate = {"error": "gate_failed",
                    "message": f"发布门禁执行异常：{type(exc).__name__}"}
        gi = _gate_issue(gate)
        if gi:
            _merge_issue(issues, gi)
    gate_passed = not gate

    # ---- 6) 状态（已下线单独提示）----
    if status == "archived":
        _merge_issue(issues, _issue("rule_archived", LEVEL_BLOCK,
                                    "规则已下线，不能进入审核执行集；需先恢复", "restore"))

    # ---- 状态判定：published / blocked / draft / ready ----
    has_block = any(x["level"] == LEVEL_BLOCK for x in issues)
    has_draft = any(x["level"] == LEVEL_DRAFT for x in issues)
    if status == "published":
        state = "published"
    elif has_block:
        state = "blocked"
    elif has_draft or status == "pending":
        state = "draft"
    else:
        state = "ready"

    # ---- next_action（按状态取首个可执行动作）----
    next_action = "none"
    if state == "published":
        next_action = "review" if issues else "none"
    elif state == "ready":
        next_action = "publish"
    elif state == "draft":
        if status == "pending":
            next_action = "approve"
        else:
            draft_actions = [x["next_action"] for x in issues if x["level"] == LEVEL_DRAFT]
            next_action = draft_actions[0] if draft_actions else "edit_slots"
    else:  # blocked
        block_actions = [x["next_action"] for x in issues if x["level"] == LEVEL_BLOCK]
        next_action = block_actions[0] if block_actions else "review"
    next_action = _next_action(next_action)

    return {
        "rule_id": rid,
        "code": row.get("code") or "",
        "name": row.get("name") or "",
        "category": row.get("category") or "",
        "rclass": row.get("rclass") or "",
        "status": status,
        "status_label": _rule_svc.status_label(status),
        "state": state,
        "state_label": {"published": "已发布", "ready": "可发布",
                        "draft": "待补全/流程中", "blocked": "阻断"}.get(state, state),
        "ready": state in ("published", "ready"),
        "published": state == "published",
        "issues": issues,
        "next_action": next_action,
        "next_action_label": _NEXT_ACTION_LABEL.get(next_action, next_action),
        "scope": {"status": scope.get("status") or "missing",
                  "declared": bool(scope.get("declared")),
                  "wildcard_tokens": wildcard,
                  "route_types": list(scope.get("route_types") or []),
                  "tags_only": bool(scope.get("tags_only")),
                  "workspace_wide": bool(scope.get("workspace_wide"))},
        "compile": {"compilable": compilable, "publishable": publishable},
        "executor": {"reachable": bool(executor_ok), "reason": str(executor_why or "")},
        "gate": {"passed": gate_passed,
                 "error": str((gate or {}).get("error") or ""),
                 "message": str((gate or {}).get("message") or "")},
        "version": {"latest": str((version or {}).get("version") or ""),
                    "latest_status": str((version or {}).get("status") or ""),
                    "latest_version_id": str((version or {}).get("id") or ""),
                    "published": str((published_version or {}).get("version") or ""),
                    "published_version_id": str((published_version or {}).get("id") or "")},
    }


def _audit_orphan(rule_id: str) -> dict:
    return {
        "rule_id": rule_id, "code": "", "name": "", "category": "", "rclass": "",
        "status": "missing", "status_label": "已不存在", "state": "blocked",
        "state_label": "阻断", "ready": False, "published": False,
        "issues": [_issue("rule_missing", LEVEL_BLOCK,
                          "规则已不存在（可能被清理），分组项失效，建议移除", "remove_item")],
        "next_action": "remove_item", "next_action_label": _NEXT_ACTION_LABEL["remove_item"],
        "scope": {"status": "missing", "declared": False, "wildcard_tokens": [],
                  "route_types": [], "tags_only": False, "workspace_wide": False},
        "compile": {"compilable": False, "publishable": False},
        "executor": {"reachable": False, "reason": "规则不存在"},
        "gate": {"passed": False, "error": "rule_missing", "message": "规则不存在"},
        "version": {"latest": "", "latest_status": "", "latest_version_id": "",
                    "published": "", "published_version_id": ""},
    }


def full_audit(user: dict, tag_id: str, limit: int = DEFAULT_AUDIT_LIMIT) -> dict:
    """分组全链路自检（只读 dry-run，不实际跑文档审核）。"""
    _require_role(user, READ_ROLES, "分组全链路自检")
    tenant, workspace = _scope()
    tag = _tag_or_404(tag_id, tenant, workspace)
    try:
        limit = max(1, min(int(limit or DEFAULT_AUDIT_LIMIT), MAX_AUDIT_LIMIT))
    except (TypeError, ValueError):
        limit = DEFAULT_AUDIT_LIMIT
    rule_ids = _rule_item_ids(tag["id"])
    total = len(rule_ids)
    selected = rule_ids[:limit]
    rows = _rule_rows_for_ids(selected, tenant, workspace)
    versions = _versions_for_ids(list(rows.keys()))
    results = []
    for rid in selected:
        row = rows.get(rid)
        if not row:
            results.append(_audit_orphan(rid))
            continue
        slot = versions.get(rid) or {}
        results.append(_audit_one_rule(row, slot.get("latest") or {},
                                       slot.get("published") or {}))

    summary = {"total": total,
               "checked": len(results),
               "truncated": total > len(results),
               "ready": 0, "blocked": 0, "draft": 0, "published": 0,
               "published_unhealthy": 0,
               "rules_with_issues": 0,
               "by_issue": {}}
    for item in results:
        state = item["state"]
        if state in ("ready", "blocked", "draft", "published"):
            summary[state] = summary.get(state, 0) + 1
        if item["state"] == "published" and not item["ready"]:
            summary["published_unhealthy"] += 1
        if item["issues"]:
            summary["rules_with_issues"] += 1
        for issue in item["issues"]:
            code = issue["code"]
            summary["by_issue"][code] = summary["by_issue"].get(code, 0) + 1

    published_ids = [x["rule_id"] for x in results if x["state"] == "published" and x["ready"]]
    blocked_ids = [x["rule_id"] for x in results if x["state"] == "blocked"]
    # 「分组可发起全链路审核」的最低条件：组内存在已发布且自检健康的规则。
    audit_ready = bool(published_ids)
    out = {"ok": True, "tag": _tag_dict(tag, total),
           "tenant_id": tenant, "workspace_id": workspace,
           "generated_at": db.now(),
           "limit": limit, "summary": summary,
           "audit_ready": audit_ready,
           "audit_ready_rule_ids": published_ids,
           "blocked_rule_ids": blocked_ids,
           "rules": results,
           "notes": [
               "本自检为只读 dry-run：不发布规则、不写规则状态、不实际跑文档审核。",
               "ready=发布门禁通过可直接发布；draft=待补全/旧审批流程中；blocked=存在阻断问题。",
               "published=当前已发布；published_unhealthy=已发布但自检发现漂移（需人工复核）。",
           ]}
    try:
        R.audit_logs.log(actor=_actor(user), action="rule_tag.full_audit",
                         object=tag["id"],
                         after=json.dumps({"name": tag["name"],
                                           "summary": {"total": summary["total"],
                                                       "ready": summary["ready"],
                                                       "blocked": summary["blocked"],
                                                       "draft": summary["draft"],
                                                       "published": summary["published"]}},
                                          ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).warning("rule_tag.full_audit 审计写入失败（不阻断只读自检）",
                                            exc_info=True)
    return out


# --------------------------------------------------------------------------- 批量导入打标
def _str_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        raw = list(value)
    else:
        raw = [value]
    out = []
    for x in raw:
        s = str(x or "").strip()
        if s and s not in out:
            out.append(s)
    return out


def prepare_batch_tags(body: dict, user: dict):
    """批量入库前解析 tag_ids / tag_names（在创建规则之前调用，失败即整体拒绝）。

    返回 ``(plan, None)`` 或 ``(None, (http_status, error_body))``。
    plan = {"tags": [{id,name,color}], "missing_names": [...], "created_names": [...]}
    """
    body = body or {}
    tag_ids = _str_list(body.get("tag_ids"))
    tag_names = _str_list(body.get("tag_names"))
    if not tag_ids and not tag_names:
        return {"tags": [], "missing_names": [], "created_names": []}, None
    role = _role(user)
    if role not in ASSIGN_ROLES:
        return None, (403, {"ok": False, "error": "无权限（规则打标需业务管理员/审核员角色）",
                            "code": "forbidden"})
    try:
        tenant, workspace = _scope()
    except RuleTagError as exc:
        return None, (exc.status, exc.payload())
    resolved, seen = [], set()
    for tid in tag_ids:
        tag = _tag_row(tid, tenant, workspace)
        if not tag:
            return None, (404, {"ok": False,
                                "error": f"分组标签不存在或当前工作空间不可见：{tid}",
                                "code": "tag_not_found", "tag_id": tid})
        if tag["id"] not in seen:
            seen.add(tag["id"])
            resolved.append({"id": tag["id"], "name": tag["name"], "color": tag["color"]})
    missing_names, created_names = [], []
    for name in tag_names:
        try:
            tag_name = _validate_name(name)
        except RuleTagError as exc:
            return None, (exc.status, exc.payload())
        tag = _find_tag_by_name(tag_name, tenant, workspace)
        if tag:
            if tag["id"] not in seen:
                seen.add(tag["id"])
                resolved.append({"id": tag["id"], "name": tag["name"],
                                 "color": tag["color"]})
            continue
        if role not in MANAGE_ROLES:
            return None, (403, {"ok": False,
                                "error": f"分组标签「{tag_name}」不存在；审核员只能使用已存在的标签",
                                "code": "tag_create_forbidden", "name": tag_name})
        missing_names.append(tag_name)
        created_names.append(tag_name)
    if len(resolved) + len(missing_names) > MAX_BATCH_TAGS:
        return None, (400, {"ok": False,
                            "error": f"单次批量打标最多 {MAX_BATCH_TAGS} 个分组标签",
                            "code": "too_many_tags"})
    return ({"tags": resolved, "missing_names": missing_names,
             "created_names": created_names, "actor": _actor(user)}, None)


def commit_batch_tags(plan: dict, created: list, skipped: list, user: dict) -> dict:
    """批量入库成功后逐条打标；返回响应增量（tags/tagged/tag_created）。

    - 同时给本次 created 与幂等 skipped（同来源同判据已存在）规则打标，
      使重复上传/重试时打标仍然生效（幂等）；
    - 全部规则被拒时（created/skipped 均空）不创建新标签，避免产生孤儿标签。
    """
    plan = plan or {}
    resolved = list(plan.get("tags") or [])
    missing_names = list(plan.get("missing_names") or [])
    rule_ids = []
    for item in list(created or []) + list(skipped or []):
        rid = str((item or {}).get("rule_id") or "")
        if rid and rid not in rule_ids:
            rule_ids.append(rid)
    if not resolved and not missing_names:
        return {"tags": [], "tagged": 0, "tag_created": []}
    if not rule_ids:
        # 没有可打标规则：不建新标签；已有标签原样回显（assigned=0）
        return {"tags": [dict(t, assigned=0, created=False) for t in resolved],
                "tagged": 0, "tag_created": []}
    tenant, workspace = _scope()
    actor = _actor(user)
    # 1) admin 的 tag_names 缺失项 → 创建（与 create_tag 同校验/同审计口径）
    created_tags = []
    for name in missing_names:
        if _find_tag_by_name(name, tenant, workspace):
            continue
        try:
            out = create_tag(user, name)
            tag = out["tag"]
            created_tags.append(tag)
            resolved.append({"id": tag["id"], "name": tag["name"],
                             "color": tag["color"]})
        except RuleTagError:
            # 并发下已存在 → 回读；其它错误整体上抛给路由层 4xx/5xx
            tag = _find_tag_by_name(name, tenant, workspace)
            if tag:
                resolved.append({"id": tag["id"], "name": tag["name"],
                                 "color": tag["color"]})
            else:
                raise
    # 2) 逐条打标（幂等 INSERT OR IGNORE）
    now = db.now()
    tag_rows = {rid: [] for rid in rule_ids}
    assigned_counts = {t["id"]: 0 for t in resolved}
    try:
        with db.session() as c:
            for tag in resolved:
                for rid in rule_ids:
                    cur = c.execute(
                        "INSERT OR IGNORE INTO rule_tag_item(tag_id, rule_id, created_by, created_at) "
                        "VALUES(?,?,?,?)", (tag["id"], rid, actor, now))
                    if cur.rowcount and cur.rowcount > 0:
                        assigned_counts[tag["id"]] = assigned_counts.get(tag["id"], 0) + 1
                    tag_rows[rid].append({"id": tag["id"], "name": tag["name"],
                                          "color": tag["color"]})
            _audit_in_tx(c, actor, "rule_tag.assigned", "batch",
                         {"tags": [t["name"] for t in resolved],
                          "rules": rule_ids[:50], "total": len(rule_ids)})
    except Exception:
        logging.getLogger(__name__).error("batch rule tag assign failed", exc_info=True)
        raise
    for item in list(created or []) + list(skipped or []):
        rid = str((item or {}).get("rule_id") or "")
        if rid and rid in tag_rows:
            item["tags"] = tag_rows[rid]
    for tag in resolved:
        tag["assigned"] = assigned_counts.get(tag["id"], 0)
        tag["created"] = any(t["id"] == tag["id"] for t in created_tags)
    tagged = sum(1 for rid in rule_ids if tag_rows.get(rid))
    return {"tags": resolved, "tagged": tagged,
            "tag_created": [t["name"] for t in created_tags]}
