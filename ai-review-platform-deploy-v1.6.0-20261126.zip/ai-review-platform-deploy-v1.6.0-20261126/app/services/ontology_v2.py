"""本体 v2：实体/别名/关系/单位/作用域 + 冲突检测 + 版本快照 + 自动发现。

设计目标（对应六项提升）：
1 覆盖扩面      —— 从规则与点位自动发现候选指标名
2 实体+关系模型 —— entities / relations（属于、含税口径、上下位）
3 自动发现      —— discover_candidates()
4 冲突检测      —— detect_conflicts()（同一别名挂两个实体 / 单位冲突）
5 版本与回放    —— snapshot() / versions
6 单位体系      —— units 归一（元/万元、%/‰、日/自然日）
"""
import json
import logging
import os
import re

from .. import db

STORE = "docs/blind/ontology_v2.json"
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_SEED = os.path.join(_ROOT, "seed", "ontology_v2.json")
_BLIND = os.path.join(_ROOT, "docs", "blind", "ontology_v2.json")

_DEFAULT = {
    "version": 1,
    "entities": {
        "采购金额": {"type": "金额", "unit": "元", "scope": ["政府采购", "招标"],
                     "aliases": ["采购金额", "单次采购金额", "合同金额", "采购总额", "订单金额", "中标金额", "投标报价"]},
        "质保金比例": {"type": "比例", "unit": "%", "scope": ["合同"],
                       "aliases": ["质保金比例", "质量保证金比例", "质保金", "质量保证金"]},
        "预付款比例": {"type": "比例", "unit": "%", "scope": ["合同"],
                       "aliases": ["预付款比例", "首付款比例", "预付款", "首付款"]},
        "逾期天数": {"type": "时长", "unit": "日", "scope": ["合同"],
                     "aliases": ["逾期天数", "延迟天数", "逾期日数", "延期天数"]},
        "违约金费率": {"type": "费率", "unit": "%", "scope": ["合同"],
                       "aliases": ["违约金费率", "日违约金率", "逾期费率", "违约金比例"]},
        "最高限价": {"type": "金额", "unit": "元", "scope": ["招标", "采购"],
                     "aliases": ["最高限价", "招标控制价", "控制价", "最高投标限价", "预算金额"]},
        "投标报价": {"type": "金额", "unit": "元", "scope": ["招标", "采购"],
                     "aliases": ["投标报价", "报价", "投标总价", "总报价"]},
        "工期": {"type": "时长", "unit": "日", "scope": ["工程", "采购"],
                 "aliases": ["工期", "履约期限", "交付期限", "服务期限", "合同工期"]},
    },
    "relations": [
        {"from": "投标报价", "type": "属于", "to": "采购金额"},
        {"from": "最高限价", "type": "约束", "to": "投标报价"},
        {"from": "质保金比例", "type": "属于", "to": "采购金额"},
    ],
    "units": {"元": {"base": "元", "factor": 1}, "万元": {"base": "元", "factor": 10000},
              "%": {"base": "%", "factor": 1}, "‰": {"base": "%", "factor": 0.1},
              "日": {"base": "日", "factor": 1}, "自然日": {"base": "日", "factor": 1}},
}


def _consumption_on() -> bool:
    """判定链是否允许消费本体 v2 资产（T-197 per-space 开关）。"""
    try:
        from . import ontology_control
        return bool(ontology_control.consumption_enabled("ontology_v2"))
    except Exception:
        return True


def _load(force: bool = False) -> dict:
    """读取本体 v2 资产。

    T-197（P0-2）：默认按「空间本体开关」裁决——关闭时返回 {}（消费方拿到空字典 =
    不读本体）。管理端校验/发布/快照等**维护操作**显式传 ``force=True`` 读全量资产，
    否则空间开关默认关会让管理员页面看不到自己的本体资产。
    无空间上下文（脚本/旧调用方）沿用进程 env 口径，保持既有实验脚本行为不变。
    """
    if not force and not _consumption_on():
        return {}
    best = None
    seed_norm = None
    for path in (STORE, _SEED, _BLIND):
        try:
            d = json.loads(open(path, encoding="utf-8").read())
        except Exception:
            continue
        if path == _SEED:
            _n = d.get("normalization")
            if isinstance(_n, dict) and _n:
                seed_norm = _n
        if best is None or len(d.get("entities") or {}) > len(best.get("entities") or {}):
            best = d
    if best is None:
        best = json.loads(json.dumps(_DEFAULT))
    # T-157：择优只按「实体数最多」，而运行时已发布快照（docs/blind）与 seed 实体数同为 88 时
    # 旧快照会遮蔽 seed 的 normalization 段（新增可选数据段，不含实体/关系/单位）。
    # 这里只补**缺失的** normalization，不覆盖已有 entities/relations/units，也不改写已发布快照
    # （避免升级覆盖管理员编辑过的本体；发布一次后新段自然落库）。
    if seed_norm and not isinstance(best.get("normalization"), dict):
        best = dict(best)
        best["normalization"] = seed_norm
    # 首次安装：把更完整的种子写回 STORE，保证后续读写一致
    try:
        cur = json.loads(open(STORE, encoding="utf-8").read())
    except Exception:
        cur = None
    if cur is None or len(cur.get("entities") or {}) < len(best.get("entities") or {}):
        try:
            _save(best)
        except Exception:
            pass
    return best


_NORM_DEFAULTS = {
    "org_forms": [],
    "code_confusable": {},
    "code_key_pattern": "",
    "code_segment_separators": r"\-_/\.\s",
    "code_numeric_segment": False,
    "version": 0,
}


def normalization_rules() -> dict:
    """归一数据段（公开只读，T-157）。

    返回：
    - ``org_forms``             组织形式等价尾缀（只对尾缀命中生效，剥离后 ≥2 字）
    - ``code_confusable``       编号易混字符表（o→0 / i→1 / s→5）
    - ``code_key_pattern``      编号形态门控正则（两侧都匹配才启用编号归一）
    - ``code_segment_separators`` 编号分段分隔符正则字符类
    - ``code_numeric_segment``  纯数字段是否按整数归一（去前导零）

    缺段/缺字段时返回安全默认值（向后兼容：调用方不用判 None，也不假设字段存在）。

    T-197（P0-2）：空间本体关闭 → 返回空归一数据段（组织形式/编号易混归一不生效）。
    """
    if not _consumption_on():
        return dict(_NORM_DEFAULTS)
    d = _load(force=True)
    raw = d.get("normalization")
    raw = dict(raw) if isinstance(raw, dict) else {}
    conf = raw.get("code_confusables")
    if not isinstance(conf, dict):
        conf = {}
    # 兼容单数写法（code_confusable）与 seed 数据字段名（code_confusables）
    if not conf and isinstance(raw.get("code_confusable"), dict):
        conf = raw.get("code_confusable")
    out = json.loads(json.dumps(_NORM_DEFAULTS))
    out["org_forms"] = [str(x).strip() for x in (raw.get("org_forms") or []) if str(x).strip()]
    out["code_confusable"] = {str(k): str(v) for k, v in conf.items() if str(k).strip()}
    out["code_key_pattern"] = str(raw.get("code_key_pattern") or "")
    _seps = str(raw.get("code_segment_separators") or "").strip()
    out["code_segment_separators"] = _seps or _NORM_DEFAULTS["code_segment_separators"]
    out["code_numeric_segment"] = bool(raw.get("code_numeric_segment"))
    try:
        out["version"] = int(raw.get("version") or 0)
    except Exception:
        out["version"] = 0
    return out


def _save(d: dict) -> None:
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    open(STORE, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1))


def alias_index() -> dict:
    """别名 → [实体...]，用于取数与冲突检测。

    T-197（P0-2）：空间本体关闭时返回 {} —— 对齐/取数拿不到别名 = 不读本体。
    管理端冲突检测等维护视图请用 ``alias_index_raw()``。
    """
    if not _consumption_on():
        return {}
    return alias_index_raw()


def alias_index_raw() -> dict:
    """全量别名索引（维护/校验用，不受空间消费开关影响）。"""
    idx = {}
    d = _load(force=True)
    for canon, e in (d.get("entities") or {}).items():
        for a in [canon] + list(e.get("aliases") or []):
            idx.setdefault(a, []).append(canon)
    return idx


def resolve(text: str, canonical: str, scope: str = "") -> list:
    """在文本中找该实体的所有别名的最近出现，返回 [(别名, 位置, 值, 单位)]。"""
    d = _load(force=True)
    e = (d.get("entities") or {}).get(canonical) or {}
    names = sorted({canonical, *(e.get("aliases") or [])}, key=len, reverse=True)
    out = []
    for n in names:
        for m in re.finditer(re.escape(n), text or ""):
            tail = (text or "")[m.end(): m.end() + 40]
            vm = re.search(r"[:：]?\s*(?:人民币)?\s*([0-9][0-9,\.]*)\s*(万元|元|%|‰|日|自然日)?", tail)
            if vm:
                out.append((n, m.start(), vm.group(1).replace(",", ""), vm.group(2) or e.get("unit") or ""))
    return out


def detect_conflicts() -> list:
    """同一别名挂多个实体、或同名实体单位不一致。"""
    d = _load(force=True)
    idx = {}
    for canon, e in (d.get("entities") or {}).items():
        for a in [canon] + list(e.get("aliases") or []):
            idx.setdefault(a, []).append(canon)
    out = []
    for a, owners in idx.items():
        if len(set(owners)) > 1:
            out.append({"kind": "alias_shared", "alias": a, "entities": sorted(set(owners))})
    units = {}
    for canon, e in (d.get("entities") or {}).items():
        u = e.get("unit") or ""
        if canon in units and units[canon] != u:
            out.append({"kind": "unit_conflict", "entity": canon})
        units[canon] = u
    return out


def discover_candidates(min_len: int = 2) -> list:
    """只从规则的 metric 字段与点位名称里发现候选实体（不从长句切词）。"""
    cand = {}
    try:
        from .. import repositories as R
        for r in R.rules.list("status=?", ("published",)):
            v = R.rules.latest_version(r["id"]) or {}
            try:
                slots = json.loads(v.get("slots_json") or "{}")
            except Exception:
                slots = {}
            for key in ("metric", "object", "subject"):
                t = str(slots.get(key) or "").strip()
                if len(t) >= min_len:
                    cand[t] = cand.get(t, 0) + 1
    except Exception:
        pass
    try:
        from . import auditpoints as AP
        for p in AP.load().points:
            name = (p.name or "").strip()
            if 2 <= len(name) <= 10 and any(k in name for k in ("金额", "比例", "期限", "数量", "日期", "编号")):
                cand[name] = cand.get(name, 0) + 1
    except Exception:
        pass
    idx = alias_index()
    return [{"term": t, "count": c} for t, c in sorted(cand.items(), key=lambda x: -x[1])
            if t not in idx][:50]


def coverage() -> dict:
    """本体对点位判据的覆盖：点位判据里提到了几个已入本体的实体。"""
    idx = alias_index_raw()
    try:
        from . import auditpoints as AP
        lib = AP.load()
    except Exception:
        return {"points": 0, "covered": 0}
    covered = 0
    for p in lib.points:
        s = f"{p.name} {p.criterion} {p.trigger}"
        if any(a in s for a in idx):
            covered += 1
    return {"points": len(lib.points), "covered": covered,
            "rate": round(covered / max(1, len(lib.points)), 3),
            "entities": len(_load(force=True).get("entities") or {})}


def snapshot() -> dict:
    d = _load(force=True)
    return {"version": d.get("version"), "entities": len(d.get("entities") or {}),
            "relations": len(d.get("relations") or []), "conflicts": detect_conflicts()}


# ---------------- 校验与发布门禁（借鉴 ONTOS：错误阻断、警告放行）----------------
_TYPES = {"金额", "比例", "费率", "时长", "数量", "日期", "编号", "其他"}


def validate() -> dict:
    d = _load(force=True)
    ents = d.get("entities") or {}
    errs, warns = [], []
    for canon, e in ents.items():
        if not canon or len(canon) < 2:
            errs.append({"code": "E_NAME", "entity": canon, "msg": "实体名过短"})
        if e.get("type") not in _TYPES:
            errs.append({"code": "E_TYPE", "entity": canon, "msg": f"类型不在白名单：{e.get('type')}"})
        if e.get("type") in ("金额", "比例", "费率", "时长") and not e.get("unit"):
            warns.append({"code": "W_UNIT", "entity": canon, "msg": "未配置单位"})
        if not (e.get("aliases") or []):
            warns.append({"code": "W_ALIAS", "entity": canon, "msg": "没有别名，易取不到数"})
        for a in e.get("aliases") or []:
            if a in ents and a != canon:
                errs.append({"code": "E_ALIAS_DUP", "entity": canon, "msg": f"别名与实体同名：{a}"})
    for r in d.get("relations") or []:
        for side in ("from", "to"):
            if (r.get(side) or "") not in ents:
                errs.append({"code": "E_REL", "entity": r.get(side), "msg": f"关系端点不存在：{r.get(side)}"})
    # 同一类型下单位应一致（金额不能既有元又有万元）
    units = {}
    for canon, e in ents.items():
        t, u = e.get("type"), (e.get("unit") or "")
        if t in ("金额", "比例", "时长"):
            units.setdefault(t, {})
            units[t].setdefault(u, []).append(canon)
    for t, m in units.items():
        if len([u for u in m if u]) > 1:
            warns.append({"code": "W_UNIT_MIX", "entity": t, "msg": f"{t} 类存在多种单位：{list(m.keys())}"})
    return {"ok": not errs, "errors": errs, "warnings": warns,
            "entities": len(ents), "relations": len(d.get("relations") or [])}


def contract_hash() -> str:
    """契约哈希：覆盖实体/关系/单位 + 归一数据段（T-157，版本治理缺口 T-154 §6.8）。

    变更说明：T-157 起 ``normalization`` 也参与哈希，因此升级后重算出的哈希与旧快照里
    记录的哈希不同。全库无读取方用旧哈希做校验/放行（只作为冻结元数据）；迁移办法是
    调用一次 ``publish()``（HTTP ``POST /api/v1/ontology/publish``）用新公式重算并写回。
    """
    import hashlib
    d = _load(force=True)
    payload = json.dumps({"entities": d.get("entities"), "relations": d.get("relations"),
                          "units": d.get("units"),
                          "normalization": d.get("normalization") or {}},
                         ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


# ---------------- 发布落库与审计（T-168/E-13：发布必须可追溯，不许假成功）----------------
# 铁律 4：onto_version 行、本体快照文件、ontology.publish 审计必须同一失败域——
# 审计插入失败 → db.session 回滚版本行，并把快照文件恢复为发布前字节，异常上抛由路由返回 5xx；
# 校验阻断 → 写 ontology.publish_blocked 审计（不静默）；成功 → 版本行/审计/文件三者都在。
_PUBLISH_ACTION = "ontology.publish"
_PUBLISH_BLOCKED_ACTION = "ontology.publish_blocked"


def _now_iso() -> str:
    return __import__("datetime").datetime.now().isoformat(timespec="seconds")


def _published_snapshot(d: dict, version: int, chash: str, v: dict) -> dict:
    """本次发布的实体/关系摘要 → onto_version.snapshot_json（contract_hash 一并落库）。"""
    ents = d.get("entities") or {}
    rels = d.get("relations") or []
    return {
        "source": "ontology_v2",
        "version": version,
        "contract_hash": chash,
        "published_at": d.get("published_at") or "",
        "entities": sorted(ents.keys()),
        "relations": [{"from": r.get("from"), "type": r.get("type"), "to": r.get("to")}
                      for r in rels if isinstance(r, dict)],
        "counts": {"entities": len(ents), "relations": len(rels),
                   "errors": len(v.get("errors") or []),
                   "warnings": len(v.get("warnings") or [])},
    }


def _record_publish_blocked(reason: str, v: dict) -> None:
    """被校验阻断也要留痕（ontology.publish_blocked + reason）。

    单独事务：阻断时没有业务写可绑定，但**不吞异常**——审计写不进去就向上抛，
    避免“被阻断而且没有任何痕迹”的静默失败。
    """
    from . import audit as _audit
    after = json.dumps({"reason": str(reason or ""), "blocked": True,
                        "errors": (v or {}).get("errors") or [],
                        "warnings": len((v or {}).get("warnings") or [])},
                       ensure_ascii=False)[:2000]
    with db.session() as c:
        _audit.log_in_tx(c, actor="system", action=_PUBLISH_BLOCKED_ACTION,
                         object_="ontology_v2", before="", after=after)


def _write_publish_tx(new_doc: dict, row: dict, actor: str, after: str) -> None:
    """同事务写 onto_version 行 + ontology.publish 审计，并原子替换本体快照文件。

    失败处理（不静默）：事务自动回滚版本行；临时文件清理；快照文件恢复为发布前字节；
    原异常继续上抛（路由 5xx），调用方不会拿到 ok:true 的假发布。
    """
    from . import audit as _audit
    old_bytes = None
    try:
        with open(STORE, "rb") as f:
            old_bytes = f.read()
    except OSError:
        old_bytes = None
    _dir = os.path.dirname(STORE)
    if _dir:
        os.makedirs(_dir, exist_ok=True)
    tmp = STORE + ".publish.tmp." + db.new_id()
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(json.dumps(new_doc, ensure_ascii=False, indent=1))
    try:
        with db.session() as c:
            # T-197（P1-2）：发布版本行带 tenant_id（ctx 自动）且 workspace_id=NULL。
            # 说明：ontology_v2 JSON 是平台级共享资产（docs/blind 快照），租户自定义
            # 本体走 DB 本体图（onto_entity/onto_alias，已按租户隔离）；版本行按租户
            # 隔离保证「跨租户看不到/发布不了别人的版本」。
            try:
                from . import ctx as _ctx_pub
                _pub_cur = _ctx_pub.get_context() or {}
            except Exception:
                _pub_cur = {}
            c.execute(
                "INSERT INTO onto_version(id,version,status,snapshot_json,health_json,"
                "created_at,published_at,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,NULL)",
                (row["id"], row["version"], row["status"], row["snapshot_json"],
                 row["health_json"], row["created_at"], row["published_at"],
                 (_pub_cur.get("tenant_id") or None)))
            _audit.log_in_tx(c, actor=actor or "system", action=_PUBLISH_ACTION,
                             object_=row["id"], after=after)
            os.replace(tmp, STORE)
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError as exc:
            logging.getLogger(__name__).warning("publish 清理临时快照失败：%s", exc)
        try:
            if old_bytes is not None:
                with open(STORE, "wb") as f:
                    f.write(old_bytes)
            elif os.path.exists(STORE):
                os.remove(STORE)
        except OSError as exc:
            logging.getLogger(__name__).warning("publish 回滚本体快照文件失败：%s", exc)
        raise


def publish(actor: str = "") -> dict:
    """错误未清零不允许发布；警告可发布。发布记版本与契约哈希，并同事务落库+审计。

    T-168/E-13 修复要点（原实现只 ``_save()`` 写 json 文件 → 假发布、不可追溯）：
    - 成功：``onto_version`` 新增一行（status=published，snapshot_json 含实体/关系摘要与
      contract_hash，health_json 含校验告警），审计动作 ``ontology.publish``，object=版本行 id；
    - 校验阻断：``ok=False`` 且写 ``ontology.publish_blocked``（reason 进 after_json）；
    - 审计写失败：事务回滚 + 快照文件回滚，异常上抛，不产生“已发布无审计”。
    """
    v = validate()
    if not v["ok"]:
        _record_publish_blocked("校验未通过，已阻断发布", v)
        return {"ok": False, "reason": "校验未通过，已阻断发布", **v}
    d = _load(force=True)
    d = dict(d)
    d["version"] = int(d.get("version", 1)) + 1
    d["contract_hash"] = contract_hash()
    d["published_at"] = _now_iso()
    snap = _published_snapshot(d, d["version"], d["contract_hash"], v)
    health = {"ok": True, "score": 100, "errors": [],
              "warnings": v.get("warnings") or [],
              "entities": snap["counts"]["entities"],
              "relations": snap["counts"]["relations"]}
    now = db.now()
    vid = db.new_id("ov")
    row = {"id": vid, "version": str(d["version"]), "status": "published",
           "snapshot_json": json.dumps(snap, ensure_ascii=False),
           "health_json": json.dumps(health, ensure_ascii=False),
           "created_at": now, "published_at": now}
    after = json.dumps({"version": d["version"], "contract_hash": d["contract_hash"],
                        "warnings": len(v.get("warnings") or []),
                        "entities": snap["counts"]["entities"],
                        "relations": snap["counts"]["relations"]},
                       ensure_ascii=False)
    _write_publish_tx(d, row, actor=actor, after=after)
    return {"ok": True, "version": d["version"], "contract_hash": d["contract_hash"],
            "warnings": v["warnings"], "version_id": vid}
