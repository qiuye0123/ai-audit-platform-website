"""字段级 schema 校验：定义字段类型/必填/格式/范围，对抽取结果做结构化校验。"""
import os
import re
import logging

from ..engine import deepparse

# 文档类型 → 字段 schema（可扩展；当前内置食品工艺书与合同通用字段）
SCHEMAS = {
    "food": {
        "fields": [
            {"name": "检验日期", "type": "date", "required": True},
            {"name": "复核日期", "type": "date", "required": False},
            {"name": "中心温度", "type": "number", "min": 0, "max": 300, "unit": "℃"},
            {"name": "消毒浓度", "type": "number", "min": 50, "max": 2000, "unit": "ppm"},
            {"name": "冷却温度", "type": "number", "min": -50, "max": 100, "unit": "℃"},
        ]
    },
    "contract": {
        "fields": [
            {"name": "甲方", "type": "text", "required": True},
            {"name": "乙方", "type": "text", "required": True},
            {"name": "金额", "type": "number", "min": 0},
            {"name": "签署日期", "type": "date", "required": False},
        ]
    },
}

_DATE = re.compile(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}$")
_NUM_WORDS = {
    "不低于": ">=", "不得低于": ">=", "至少": ">=", "不小于": ">=", "≥": ">=", ">=": ">=",
    "不高于": "<=", "不得高于": "<=", "不超过": "<=", "不大于": "<=", "≤": "<=", "<=": "<=",
    "大于": ">", ">": ">", "小于": "<", "<": "<",
}


def _numeric(v):
    """把 85 / "不低于85℃" / "≤ 10" 解析成 float；无法解析返回 None。"""
    if isinstance(v, (int, float)):
        return float(v)
    text = str(v or "").strip()
    m = re.search(r"(-?\d+(?:\.\d+)?)", text)
    if not m:
        return None
    try:
        return float(m.group(1))
    except Exception:
        return None


def load_schema(audit_type: str) -> dict:
    """优先读 DB 覆盖配置，其次内置默认。"""
    try:
        from . import sysconfig
        raw = sysconfig.get("schema:" + (audit_type or "food"), "")
        if raw:
            import json
            return json.loads(raw)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    if not audit_type or audit_type == "food":
        return SCHEMAS["food"]
    return SCHEMAS.get(audit_type) or {}


def save_schema(audit_type: str, schema: dict, by: str = "") -> dict:
    import json
    from . import sysconfig
    from .. import repositories as R
    if not isinstance(schema.get("fields"), list):
        return {"error": "schema.fields 必须是数组"}
    try:
        sysconfig.set_many({"schema:" + audit_type: json.dumps(schema, ensure_ascii=False)})
        R.audit_logs.log(actor=by or "system", action="schema.updated", object=audit_type)
        return {"ok": True, "audit_type": audit_type, "fields": len(schema["fields"])}
    except Exception as e:  # noqa
        return {"error": f"保存失败：{type(e).__name__}"}


def validate(facts: list, audit_type: str = "") -> list:
    """对事实做 schema 校验，返回问题列表（不抛异常）。"""
    schema = load_schema(audit_type)
    by_name = {}
    for f in facts:
        obj = str(f.get("object") or "")
        if obj:
            by_name.setdefault(obj, []).append(f)
    issues = []
    for spec in schema["fields"]:
        name = spec["name"]
        got = by_name.get(name) or []
        if not got:
            # 默认不把“字段缺失”当问题：不同模板字段名不同，空引文缺失告警噪声大；
            # 需要严格必填时显式开启 RULEPROOF_SCHEMA_REQUIRED=1。
            if spec.get("required") and os.environ.get("RULEPROOF_SCHEMA_REQUIRED", "0") == "1":
                issues.append({"field": name, "level": "warning", "title": f"字段缺失：{name}",
                               "detail": f"schema 要求 {name} 必填，但未抽取到"})
            continue
        for f in got:
            v = f.get("value")
            t = spec.get("type")
            if t == "number":
                num = _numeric(v)
                if num is None:
                    issues.append({"field": name, "level": "warning", "title": f"字段类型错误：{name}",
                                   "detail": f"{v} 不是数值"})
                    continue
                if spec.get("min") is not None and num < spec["min"]:
                    issues.append({"field": name, "level": "critical", "title": f"字段超出范围：{name}",
                                   "detail": f"{num} < 下限 {spec['min']}"})
                if spec.get("max") is not None and num > spec["max"]:
                    issues.append({"field": name, "level": "critical", "title": f"字段超出范围：{name}",
                                   "detail": f"{num} > 上限 {spec['max']}"})
            elif t == "date":
                if not _DATE.match(str(v)[:10]):
                    issues.append({"field": name, "level": "warning", "title": f"日期格式不规范：{name}",
                                   "detail": f"{v}"})
            elif t == "text":
                if not str(v).strip():
                    issues.append({"field": name, "level": "warning", "title": f"字段为空：{name}", "detail": ""})
    return issues


def check_document(path: str, audit_type: str = "") -> list:
    try:
        facts = [f.to_dict() if hasattr(f, "to_dict") else f
                 for f in deepparse.extract_facts(
                     deepparse.parse_and_extract(path)["doc"].get("text", ""), "schema")]
    except Exception:
        return []
    return validate(facts, audit_type)
