"""决策表（Decision Table）：把「多条件组合 → 结论」表达为一张表，补齐 C 类规则引擎能力。

- 命中策略：first（首次命中即返回）/ collect（收集所有命中）/ unique（重叠即冲突）
- 多表命中策略：priority（按冻结顺序取第一张命中的表）/ conflict（多张命中即冲突，
  不自动取舍）/ all（保留全部命中表与行）。策略显式校验，非法值不静默降级。
- 条件：metric op value（支持 >= <= = > < in range between contains before after）
- 输出：severity + message（可选 suggestion）；每个命中行带 table/source/conditions/matched，
  保留命中来源与参与求值的实际事实（含非数值字符串），不伪造原文坐标
- 版本：发布后生成不可变版本快照
"""
import logging
import hashlib
import json
import re

from .. import db
from .. import repositories as R

OPERATORS = ("=", "!=", ">=", "<=", ">", "<", "contains", "before", "after", "in", "range", "between")

# 单表命中策略与多表决策策略（priority/conflict/all）分开：前者决定一张表内如何取行，
# 后者决定多张表同时命中时如何裁决。
HIT_POLICIES = ("first", "collect", "unique")
DECISION_POLICIES = ("priority", "conflict", "all")
DEFAULT_DECISION_POLICY = "conflict"
# 给前端/CLI 的策略选项（可读取，不允许调用方改坏常量）。
_DECISION_POLICY_OPTIONS = (
    {"value": "conflict", "label": "冲突即不可判定",
     "description": "多张决策表同时命中时不自动取舍，返回 conflict（D4/报告置 insufficient）"},
    {"value": "priority", "label": "按声明顺序优先",
     "description": "只取冻结/声明顺序中最先命中的一张决策表，其余不产出"},
    {"value": "all", "label": "全部命中",
     "description": "保留所有命中决策表与行，供逐行产出；冲突仍需人工确认"},
)


def decision_policy_options() -> list:
    """策略可选项（只读副本），供 UI/CLI 渲染 decision_policy 配置。"""
    return [dict(x) for x in _DECISION_POLICY_OPTIONS]


def _policy_value(config):
    """从 rule slots / manifest item / 裸值中取 policy；保持原始值便于报错。"""
    if isinstance(config, dict):
        for key in ("decision_policy", "policy"):
            if config.get(key) not in (None, ""):
                return config.get(key)
        for key in ("decision_policy", "policy"):
            if key in config:
                return config.get(key)
        return ""
    return config


def read_decision_policy(config, default: str = DEFAULT_DECISION_POLICY) -> dict:
    """读取并校验多表命中策略。

    - 空值（未配置）合法，回落到 default；
    - 大小写/前后空格归一；
    - 非法值返回 ok=False（调用方必须阻断或显式降级，不能当 priority 静默执行）。
    """
    _default = str(default or "").strip().lower()
    if _default not in DECISION_POLICIES:
        _default = DEFAULT_DECISION_POLICY
    raw = _policy_value(config)
    text = str(raw if raw is not None else "").strip().lower()
    if not text:
        return {"ok": True, "policy": _default, "raw": raw, "error": ""}
    if text in DECISION_POLICIES:
        return {"ok": True, "policy": text, "raw": raw, "error": ""}
    return {"ok": False, "policy": _default, "raw": raw,
            "error": "decision_policy 仅支持 %s，收到：%s"
                     % ("/".join(DECISION_POLICIES), raw)}


def validate_decision_policy(policy) -> dict:
    """校验 decision_policy（read_decision_policy 的等价别名，语义更直白）。"""
    return read_decision_policy(policy)


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _match(cond: dict, facts: dict):
    if not isinstance(cond, dict):
        return None
    if "all" in cond:
        return _tri_all(cond["all"], facts)
    if "any" in cond:
        return _tri_any(cond["any"], facts)
    if "not" in cond:
        r = _match(cond["not"], facts)
        return None if r is None else (not r)
    metric = cond.get("metric")
    if not metric or metric not in facts:
        return None
    raw = facts[metric]
    vals = raw if isinstance(raw, (list, tuple)) else [raw]
    results = [_match_one(cond, v) for v in vals]
    if any(r is True for r in results):
        return True
    if all(r is False for r in results):
        return False
    return None


def _tri_all(conds, facts):
    rs = [_match(c, facts) for c in (conds or [])]
    if any(r is False for r in rs):
        return False
    if rs and all(r is True for r in rs):
        return True
    return None


def _tri_any(conds, facts):
    rs = [_match(c, facts) for c in (conds or [])]
    if any(r is True for r in rs):
        return True
    if rs and all(r is False for r in rs):
        return False
    return None


def _match_one(cond: dict, fact):
    op = cond.get("op")
    if op == "in":
        return str(fact) in [str(x) for x in (cond.get("values") or [])]
    if op == "between":
        lo, hi = cond.get("lo"), cond.get("hi")
        try:
            return float(lo) <= float(fact) <= float(hi)
        except Exception:
            return str(lo) <= str(fact) <= str(hi)
    if op == "range":
        lo, hi = _num(cond.get("lo")), _num(cond.get("hi"))
        n = _num(fact)
        if n is None:
            return None
        return (lo is None or n >= lo) and (hi is None or n <= hi)
    if isinstance(fact, (int, float)) and not isinstance(fact, bool):
        val = _num(cond.get("value"))
        if val is None:
            return None
        return {">=": fact >= val, "<=": fact <= val, ">": fact > val,
                "<": fact < val, "=": fact == val, "!=": fact != val}.get(op)
    val = cond.get("value")
    if val is None:
        return None
    if op == "contains":
        return str(val) in str(fact)
    if op == "before":
        return str(fact) < str(val)
    if op == "after":
        return str(fact) > str(val)
    if op in ("=", "!="):
        return (fact == val) if op == "=" else (fact != val)
    return None


REQUIRED_ROW = ("severity", "message")


def _jsonable(value):
    """把事实/条件值转成可 JSON 序列化的结构；非数值原样保留，不做数值化。"""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return str(value)


def _condition_metrics(conditions) -> list:
    """递归取出条件里的 metric（all/any/not），保持声明顺序并去重。"""
    out = []

    def walk(node):
        if isinstance(node, (list, tuple)):
            for one in node:
                walk(one)
            return
        if not isinstance(node, dict):
            return
        if node.get("metric"):
            out.append(str(node["metric"]))
        for key in ("all", "any"):
            if isinstance(node.get(key), (list, tuple)):
                walk(node[key])
        if isinstance(node.get("not"), dict):
            walk(node["not"])

    walk(conditions)
    return list(dict.fromkeys([x for x in out if x]))


def _matched_facts(conditions, facts) -> dict:
    """命中行实际使用的事实值：只记录条件引用的 metric，缺失的不补、不猜。"""
    out = {}
    for metric in _condition_metrics(conditions):
        if metric in (facts or {}):
            out[metric] = _jsonable((facts or {}).get(metric))
    return out


def _hit_source(code: str, version: str, row_no: int, hit_policy: str) -> dict:
    """命中来源：决策表/版本/行；ref 与报告 anchor 的降级 locator 保持同构。"""
    ref = f"decision_table:{code}:row:{row_no}"
    return {"kind": "decision_table", "code": code, "version": str(version or ""),
            "row": row_no, "hit_policy": hit_policy, "ref": ref}


def _make_hit(code: str, version: str, hit_policy: str, row_no: int,
              rule: dict, facts: dict) -> dict:
    """构造命中行：保留来源、条件快照与实际事实，非数值条件不转数字。"""
    rule = rule if isinstance(rule, dict) else {}
    conditions = rule.get("when") or []
    source = _hit_source(code, version, row_no, hit_policy)
    return {"row": row_no,
            "severity": rule.get("severity", "warning"),
            "message": rule.get("message", ""),
            "suggestion": rule.get("suggestion", ""),
            "table": code,
            "hit_policy": hit_policy,
            "source_ref": source["ref"],
            "source": source,
            "conditions": _jsonable(conditions),
            "matched": _matched_facts(conditions, facts)}


def _evaluate_rules(code: str, version: str, hit_policy: str, rules: list, facts: dict):
    """按单表命中策略取行；返回 (hits, unknown)。三值逻辑保持原语义。"""
    hits, unknown = [], False
    for i, r in enumerate(rules or []):
        if not isinstance(r, dict):
            continue
        rs = [_match(c, facts) for c in (r.get("when") or [])]
        if any(x is False for x in rs):
            continue
        if any(x is None for x in rs):
            unknown = True
            continue
        hits.append(_make_hit(code, version, hit_policy, i + 1, r, facts))
        if hit_policy == "first":
            break
    return hits, unknown


_STRING_OPS = {"=", "!=", "contains", "before", "after", "in"}


def _validate_cond(c, i=1) -> dict:
    if not isinstance(c, dict):
        return {"ok": False, "error": f"第 {i} 行条件不是对象"}
    if "all" in c or "any" in c:
        key = "all" if "all" in c else "any"
        if not isinstance(c.get(key), list) or not c[key]:
            return {"ok": False, "error": f"第 {i} 行 {key} 必须是非空数组"}
        for x in c[key]:
            r = _validate_cond(x, i)
            if not r["ok"]:
                return r
        return {"ok": True}
    if "not" in c:
        return _validate_cond(c["not"], i)
    bad = [k for k in c if k not in ("metric", "op", "value", "values", "lo", "hi", "type")]
    if bad:
        return {"ok": False, "error": f"第 {i} 行条件含未知字段 {bad}"}
    if not str(c.get("metric") or "").strip():
        return {"ok": False, "error": f"第 {i} 行条件缺少 metric"}
    if c.get("op") not in OPERATORS:
        return {"ok": False, "error": f"第 {i} 行算子非法：{c.get('op')}"}
    if c.get("op") in ("range", "between"):
        if c.get("lo") is None or c.get("hi") is None:
            return {"ok": False, "error": f"第 {i} 行 range/between 需要 lo 与 hi"}
        return {"ok": True}
    if c.get("op") == "in":
        if not isinstance(c.get("values"), list) or not c["values"]:
            return {"ok": False, "error": f"第 {i} 行 in 需要非空 values"}
        return {"ok": True}
    val = c.get("value")
    if val is None:
        return {"ok": False, "error": f"第 {i} 行缺少 value"}
    if c.get("op") in _STRING_OPS:
        if isinstance(val, bool) or not isinstance(val, (str, int, float)):
            return {"ok": False, "error": f"第 {i} 行 value 类型不支持"}
        return {"ok": True}
    if isinstance(val, str):
        try:
            val = float(val.strip())
        except Exception:
            return {"ok": False, "error": f"第 {i} 行 value 必须是数字（字符串请用 =/contains）"}
        c["value"] = val
    if not isinstance(val, (int, float)) or isinstance(val, bool):
        return {"ok": False, "error": f"第 {i} 行 value 必须是数字（字符串请用 =/contains）"}
    return {"ok": True}


def analyze(rules: list) -> dict:
    intervals = {}
    for idx, r in enumerate(rules or [], 1):
        for c in (r.get("when") or []):
            if not isinstance(c, dict) or "metric" not in c:
                continue
            m, op = c.get("metric"), c.get("op")
            lo = hi = None
            n = _num(c.get("value")) if c.get("value") is not None else None
            if op == ">=": lo = n
            elif op == ">": lo = n
            elif op == "<=": hi = n
            elif op == "<": hi = n
            elif op in ("range", "between"):
                lo, hi = _num(c.get("lo")), _num(c.get("hi"))
            elif op == "=":
                lo = hi = n
            if lo is None and hi is None:
                continue
            intervals.setdefault(str(m), []).append({"row": idx, "lo": lo, "hi": hi})
    overlaps, gaps = [], []
    INF = float("inf")
    for m, rows in intervals.items():
        rows = sorted(rows, key=lambda x: (x["lo"] is None, x["lo"] if x["lo"] is not None else -INF))
        for a, b in zip(rows, rows[1:]):
            alo = a["lo"] if a["lo"] is not None else -INF
            ahi = a["hi"] if a["hi"] is not None else INF
            blo = b["lo"] if b["lo"] is not None else -INF
            if blo <= ahi:
                overlaps.append({"metric": m, "rows": [a["row"], b["row"]]})
            else:
                gaps.append({"metric": m, "between": [ahi, blo]})
    return {"overlaps": overlaps, "gaps": gaps, "ok": not overlaps}


def validate_rules(rules) -> dict:
    """结构校验：未知字段、缺 metric、op/value 非法、缺结论字段 → 直接阻断。
    目的：避免「字段写错 → 静默不命中 → 被误判为业务未违规」。"""
    if not isinstance(rules, list) or not rules:
        return {"ok": False, "error": "规则不能为空"}
    for i, r in enumerate(rules, 1):
        if not isinstance(r, dict):
            return {"ok": False, "error": f"第 {i} 行不是对象"}
        unknown = [k for k in r if k not in ("when", "severity", "message", "suggestion")]
        if unknown:
            return {"ok": False,
                    "error": f"第 {i} 行存在未知字段 {unknown}（合法字段：when/severity/message/suggestion）"}
        when = r.get("when")
        if not isinstance(when, list) or not when:
            return {"ok": False, "error": f"第 {i} 行 when 必须是非空数组"}
        for c in when:
            _vc = _validate_cond(c, i)
            if not _vc["ok"]:
                return _vc
        for k in REQUIRED_ROW:
            if not r.get(k):
                return {"ok": False, "error": f"第 {i} 行缺少 {k}"}
    return {"ok": True}


def normalize_canary(value) -> tuple:
    """canary_percent 归一化（X-13）：None→100；0 是合法值（全量关闭灰度）。

    旧实现 ``int(x or 100)`` 把 0 吞成 100 → 「0% 灰度」不可达；这里显式区分
    None（缺省=100）与 0（合法=全部 skipped），非法值返回错误而不是静默改写。
    """
    if value is None or value == "":
        return 100, ""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None, f"canary_percent 必须是 0-100 的整数（收到 {value!r}）"
    if n < 0 or n > 100:
        return None, f"canary_percent 必须在 0-100 之间（收到 {n}）"
    return n, ""


# 决策表 code 是业务主键（URL 路径 / 包装规则编码 DT-<code> / 审计 object / 冲突检测
# A-B 侧都用它）。评审 P1-B3-02：旧实现允许同 code 重复创建 → 两条并存、只有先建那条
# 可达、无法单独下线，并产出假冲突；P2-B3-02：500 字符/路径片段/SQL 片段都能落库。
# 现在：字符集 + 长度白名单（invalid_code 400），同租户（含全局）内查重（duplicate_code 409）。
CODE_PATTERN = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")


def validate_code(code: str) -> tuple:
    """返回 (normalized_code, error, err_code)。空/非法/超长都显式拒绝，不静默改写。"""
    value = str(code or "").strip()
    if not value:
        return "", "编码不能为空", "invalid_code"
    if not CODE_PATTERN.match(value):
        return value, ("编码只允许字母/数字/下划线/中划线/点，长度 1–64"
                       "（收到 %r）" % value[:80]), "invalid_code"
    return value, "", ""


def list_duplicates() -> list:
    """存量重复 code 巡检（P1-B3-02「已有重复的给出巡检脚本」的服务层入口）。

    返回 ``[{code, count, ids, names, statuses}]``；空列表 = 无重复。
    使用方式（只读，不改数据）::

        PYTHONPATH=. python3 -c "from app.services import decision_table as D; \
            print(D.list_duplicates())"

    合并建议（人工确认后执行，不自动改数据）：保留最新一条为唯一可达项，其余逐条
    调用 ``archive``/``update`` 改名（本仓库不在巡检中自动迁移，避免误合并业务资产）。
    """
    from collections import defaultdict
    groups = defaultdict(list)
    try:
        rows = R.decision_tables.list(order="created_at DESC")
    except Exception:
        return []
    for r in rows:
        groups[str(r.get("code") or "")].append(r)
    out = []
    for code, items in groups.items():
        if len(items) > 1:
            out.append({"code": code, "count": len(items),
                        "ids": [x.get("id") or "" for x in items],
                        "names": [x.get("name") or "" for x in items],
                        "statuses": [x.get("status") or "" for x in items]})
    out.sort(key=lambda x: (-x["count"], x["code"]))
    return out


def find_duplicate(code: str) -> dict:
    """同 code 是否已存在（跨租户可见范围内查重；decision_table 无 tenant 隔离时全库查）。"""
    try:
        rows = R.decision_tables.list("code=?", (code,))
    except Exception:
        rows = []
    return rows[0] if rows else {}


def create(code: str, name: str, rules: list, hit_policy: str = "first",
           source: str = "", by: str = "", scope_types: list = None,
           canary_percent: int = 100) -> dict:
    if not code or not name:
        return {"error": "code 与 name 必填"}
    code, _cverr, _ccode = validate_code(code)
    if _cverr:
        return {"error": _cverr, "code": _ccode}
    if hit_policy not in HIT_POLICIES:
        return {"error": "hit_policy 仅支持 first/collect/unique"}
    _dup = find_duplicate(code)
    if _dup:
        # code 是业务主键：重复创建会让两条不可区分、只有先建那条可达（评审实测）。
        return {"error": f"决策表编码 {code} 已存在（请换一个编码，或编辑/下线已有表）",
                "code": "duplicate_code", "existing_id": _dup.get("id") or "",
                "existing_status": _dup.get("status") or ""}
    _v = validate_rules(rules)
    if not _v["ok"]:
        return {"error": _v["error"]}
    _cv, _cerr = normalize_canary(canary_percent)
    if _cerr:
        return {"error": _cerr, "code": "invalid_canary"}
    tid = db.new_id("dt")
    R.decision_tables.insert(id=tid, code=code, name=name, hit_policy=hit_policy,
                             rules_json=json.dumps(rules, ensure_ascii=False),
                             status="draft", version="v0.1", source=source, created_at=db.now(),
                             scope_types=json.dumps(scope_types or [], ensure_ascii=False),
                             canary_percent=_cv)
    R.audit_logs.log(actor=by or "system", action="decision_table.created", object=code)
    return {"id": tid, "code": code, "status": "draft", "version": "v0.1"}


def update(code: str, name: str = "", rules: list = None, hit_policy: str = "",
           scope_types: list = None, canary_percent: int = None, by: str = "") -> dict:
    """编辑决策表（草稿态才能改；改完需重新发布）。"""
    row = get(code)
    if not row:
        return {"error": "决策表不存在"}
    if row.get("status") == "published":
        return {"error": "已发布，请先下线再编辑（或直接新建版本）"}
    upd = {}
    if name:
        upd["name"] = name
    if rules is not None:
        _v = validate_rules(rules)
        if not _v["ok"]:
            return {"error": _v["error"]}
        upd["rules_json"] = json.dumps(rules, ensure_ascii=False)
    if hit_policy in HIT_POLICIES:
        upd["hit_policy"] = hit_policy
    if scope_types is not None:
        upd["scope_types"] = json.dumps(scope_types, ensure_ascii=False)
    if canary_percent is not None:
        _cv, _cerr = normalize_canary(canary_percent)
        if _cerr:
            return {"error": _cerr, "code": "invalid_canary"}
        upd["canary_percent"] = _cv
    if upd:
        _before = {k: row.get(k) for k in upd}
        R.decision_tables.update(row["id"], **upd)
        R.audit_logs.log(actor=by or "system", action="decision_table.updated", object=code,
                         before=json.dumps(_before, ensure_ascii=False),
                         after=json.dumps({k: (upd[k] if k != "rules_json" else "<rules>")
                                           for k in upd}, ensure_ascii=False))
    return {"ok": True, "code": code, "updated": list(upd.keys())}


def detail(code: str) -> dict:
    row = get(code)
    if not row:
        return {}
    return {"code": row["code"], "name": row["name"], "status": row["status"],
            "version": row.get("version"), "hit_policy": row.get("hit_policy"),
            "scope_types": json.loads(row.get("scope_types") or "[]"),
            "canary_percent": row.get("canary_percent", 100),
            "rules": json.loads(row.get("rules_json") or "[]")}


def get(code: str) -> dict:
    rows = R.decision_tables.list("code=?", (code,))
    return rows[0] if rows else {}


def archive(code: str, by: str = "") -> dict:
    """决策表下线（X-13）：发布后无法整体关闭的补充路径；写审计，幂等。

    下线后 evaluate 显式返回 state=archived（不静默 no_match），publish 拒绝复活。
    P2-B3-04（评审 B3-E5）：同时联动下线其包装规则 ``DT-<code>``（source=
    decision_table_autobind）。旧实现只改表状态，包装规则仍 published →
    「已下线资产仍有生效规则」的死引用，并被 rule_counts.executable_versions
    计入可执行版本（新审核永不执行它，计数虚高）。
    """
    row = get(code)
    if not row:
        return {"error": "决策表不存在", "code": "not_found"}
    if str(row.get("status") or "") == "archived":
        return {"ok": True, "code": code, "status": "archived", "unchanged": True,
                "audit": False}
    R.decision_tables.update(row["id"], status="archived")
    R.audit_logs.log(actor=by or "system", action="decision_table.archived", object=code,
                     before=str(row.get("status") or ""), after="archived")
    wrap = _archive_wrapper_rule(code, by)
    return {"ok": True, "code": code, "status": "archived", "unchanged": False,
            "audit": True, "wrapper_rule": wrap}


def _archive_wrapper_rule(code: str, by: str = "") -> dict:
    """下线决策表的包装规则（P2-B3-04）：返回 {rule_code, rule_id, action, error}。

    只处理 ``source=decision_table_autobind`` 且 code == ``DT-<code>`` 的规则；找不到
    或已是 archived 时幂等返回（不报错、不重复写审计）。规则下线走 rule.archive
    真实生命周期（版本 superseded、current_version_id 清空），不直写状态。
    """
    rcode = f"DT-{code}"
    out = {"rule_code": rcode, "rule_id": "", "action": "none", "error": ""}
    try:
        rows = [r for r in R.rules.list() if str(r.get("code") or "") == rcode]
    except Exception:
        rows = []
    if not rows:
        return out
    row = rows[0]
    out["rule_id"] = row.get("id") or ""
    if str(row.get("status") or "") == "archived":
        out["action"] = "already_archived"
        return out
    try:
        from . import rule as _rule
        res = _rule.archive(row["id"], by or "system")
    except Exception as exc:  # noqa: BLE001 —— 下线失败必须可见，不得静默
        out["action"] = "failed"
        out["error"] = f"{type(exc).__name__}: {exc}"
        return out
    if res.get("error"):
        out["action"] = "failed"
        out["error"] = str(res.get("error"))
        return out
    out["action"] = "archived"
    try:
        R.audit_logs.log(actor=by or "system", action="decision_table.wrapper_archived",
                         object=code,
                         after=json.dumps({"rule_code": rcode,
                                           "rule_id": row.get("id") or ""},
                                          ensure_ascii=False))
    except Exception as _e:  # 静默兜底改为留痕（反补丁治理）
        logging.getLogger(__name__).debug("silent fallback: %s", _e)
    return out


def publish(code: str, by: str = "") -> dict:
    row = get(code)
    if not row:
        return {"error": "决策表不存在"}
    if str(row.get("status") or "") == "archived":
        return {"error": "决策表已下线，不能重新发布；请 copy 为草稿后重新发布",
                "code": "table_archived"}
    # 已发布且规则未变：不再产生新版本（避免「更新失败但版本号仍增加」）
    hist = R.decision_table_versions.list("table_id=?", (row["id"],), order="id DESC")
    if row.get("status") == "published" and hist and \
            (hist[0].get("rules_json") or "") == (row.get("rules_json") or ""):
        return {"error": "规则无变更，不产生新版本", "version": row.get("version")}
    v = f"v{len(hist) + 1}.0"
    R.decision_table_versions.insert(id=db.new_id("dtv"), table_id=row["id"], version=v,
                                     rules_json=row.get("rules_json") or "[]", published_at=db.now())
    R.decision_tables.update(row["id"], status="published", version=v)
    R.audit_logs.log(actor=by or "system", action="decision_table.published", object=code, after=v)
    binding = _auto_bind_rule(row, v, by)
    try:
        R.audit_logs.log(actor=by or "system", action="decision_table.rule_bound", object=code,
                         after=json.dumps(binding, ensure_ascii=False))
    except Exception as _e:  # 静默兜底改为留痕（反补丁治理）
        logging.getLogger(__name__).debug("silent fallback: %s", _e)
    return {"code": code, "status": "published", "version": v, "rule_binding": binding}


def _table_rules_hash(rules_json: str) -> str:
    return hashlib.sha256((rules_json or "[]").encode("utf-8")).hexdigest()


def binding_of(code: str, version: str = "") -> dict:
    """决策表版本的不可变绑定：code + version + rules_hash（附灰度参数）。

    wrapper 规则发布时写入 slots.decision_table_binding；manifest 冻结执行时仍按
    code+version+rules_hash 冻结。发布门禁校验：hash 必须与冻结版本一致，且版本必须
    仍是该表当前 published 版本，避免「表已重发、wrapper 仍旧绑定」的漂移。
    """
    row = get(code)
    if not row:
        return {}
    v = str(version or row.get("version") or "")
    if not v:
        return {}
    hist = R.decision_table_versions.list("table_id=?", (row["id"],), order="id DESC")
    ver = next((x for x in hist if str(x.get("version") or "") == v), None)
    if not ver:
        return {}
    try:
        scope_types = json.loads(row.get("scope_types") or "[]")
    except Exception:
        scope_types = []
    pct = row.get("canary_percent")
    return {"code": str(row.get("code") or code), "version": v,
            "rules_hash": _table_rules_hash(ver.get("rules_json") or "[]"),
            "hit_policy": str(row.get("hit_policy") or "first"),
            "scope_types": scope_types if isinstance(scope_types, list) else [],
            "canary_percent": int(100 if pct is None else pct)}


def verify_binding(binding: dict) -> dict:
    """校验 wrapper 绑定：版本存在、rules_hash 一致、且仍为该决策表当前 published 版本。"""
    binding = binding or {}
    code = str(binding.get("code") or "")
    version = str(binding.get("version") or "")
    want = str(binding.get("rules_hash") or "")
    if not code or not version or not want:
        return {"ok": False, "error": "binding_incomplete",
                "reason": "决策表绑定缺少 code/version/rules_hash"}
    row = get(code)
    if not row:
        return {"ok": False, "error": "table_missing", "reason": f"决策表 {code} 不存在"}
    if str(row.get("status") or "") != "published":
        return {"ok": False, "error": "table_unpublished",
                "reason": f"决策表 {code} 未发布（{row.get('status')}）"}
    hist = R.decision_table_versions.list("table_id=?", (row["id"],), order="id DESC")
    ver = next((x for x in hist if str(x.get("version") or "") == version), None)
    if not ver:
        return {"ok": False, "error": "version_missing",
                "reason": f"决策表 {code} 不存在冻结版本 {version}"}
    got = _table_rules_hash(ver.get("rules_json") or "[]")
    if got != want:
        return {"ok": False, "error": "hash_mismatch", "expected": want, "actual": got,
                "reason": f"决策表 {code}@{version} rules_hash 不一致"
                          f"（绑定 {want[:12]}…，实际 {got[:12]}…）"}
    current = str(row.get("version") or "")
    if current != version:
        return {"ok": False, "error": "stale_binding", "current_version": current,
                "bound_version": version,
                "reason": f"决策表 {code} 已发布新版本 {current}，绑定 {version} 已过期"}
    return {"ok": True, "code": code, "version": version, "rules_hash": got,
            "current_version": current}


_GENERIC_EVIDENCE = "原文"


def _decision_table_evidence_required(metrics: list) -> str:
    """决策表 wrapper 的证据口径。

    条件指标（合同金额/预付款比例…）是**取数键**，不是原文里必须逐字出现的证据词：
    真实合同会写「合同总价」「预付款为合同总价的 35%」等别名/口径写法，若把指标名
    当字面证据，D3/D4 会在决策表真正执行前就判证据不足（决策表客户项目永不执行）。
    决策表的证据要求由冻结表版本里的条件求值承担，wrapper 只要求「原文」即可；
    原始指标名保留在 description 中供追溯。
    """
    return _GENERIC_EVIDENCE


def _auto_bind_rule(row: dict, version: str, by: str = "") -> dict:
    """发布决策表时自动创建/更新执行规则（wrapper），并绑定 code+version+hash。

    这是客户正常发布路径的一部分，不是测试分支。规则只声明 decision_tables，
    具体条件仍在冻结的决策表版本里。wrapper 每次绑定变化都走
    draft→submit→approve→publish 真实迁移（旧 published 版本自动 superseded），
    不允许直写状态；绑定不变时复用，不重复建规则/版本。
    """
    code = str(row.get("code") or "").strip()
    rcode = f"DT-{code}"
    binding = binding_of(code, version)
    if not binding:
        return {"ok": False, "rule_code": rcode, "rule_id": "", "action": "failed",
                "error": "决策表版本绑定信息缺失（无法计算 code+version+hash）"}
    scope_types = [str(x) for x in (binding.get("scope_types") or []) if str(x).strip()]
    types = scope_types or ["txt", "docx", "pdf", "xlsx", "md"]
    actor = by or "system"
    try:
        from . import rule as _rule
        from .. import repositories as _R
        existing = next((r for r in _R.rules.list() if str(r.get("code") or "") == rcode), None)
        if existing:
            rid = existing["id"]
            cur_ver = _R.rules.published_version(rid) or _R.rules.latest_version(rid) or {}
            try:
                cur_slots = json.loads(cur_ver.get("slots_json") or "{}")
            except Exception:
                cur_slots = {}
            _ev_ok = str(cur_slots.get("required_evidence") or "") in (
                "", _GENERIC_EVIDENCE)
            try:
                _cond_metrics = []
                for _r0 in json.loads(row.get("rules_json") or "[]"):
                    for _c0 in (_r0.get("when") or []):
                        _m0 = str((_c0 or {}).get("metric") or "").strip()
                        if _m0 and _m0 not in _cond_metrics:
                            _cond_metrics.append(_m0)
            except Exception:
                _cond_metrics = []
            _obj_ok = (not _cond_metrics
                       or str(cur_slots.get("object") or "") == "、".join(_cond_metrics))
            if (str(existing.get("status") or "") == "published"
                    and (cur_slots.get("decision_table_binding") or {}) == binding
                    and _ev_ok and _obj_ok):
                return {"ok": True, "rule_code": rcode, "rule_id": rid,
                        "action": "reused", "error": "", "binding": binding,
                        "rule_version": cur_ver.get("version") or ""}
            if (str(existing.get("status") or "") == "published"
                    and (cur_slots.get("decision_table_binding") or {}) == binding
                    and not (_ev_ok and _obj_ok)):
                # 旧版本 wrapper 把条件指标名当字面证据 / 缺 object 指标键，导致决策表
                # 在真实措辞上 evidence_missing 或事实取数被冻结别名白名单拒绝；
                # 重新发布时修正（业务修复，非测试口径）。
                _upd0 = _rule.update_slots(
                    rid, {"required_evidence": _GENERIC_EVIDENCE,
                          "object": "、".join(_cond_metrics)}, actor)
                if _upd0.get("error"):
                    return {"ok": False, "rule_code": rcode, "rule_id": rid,
                            "action": "rebind", "error": _upd0.get("error") or "update_failed",
                            "binding": binding}
                pub0 = _rule.publish_via_lifecycle(rid, actor)
                return {"ok": not bool(pub0.get("error")), "rule_code": rcode,
                        "rule_id": rid, "action": "evidence_fixed",
                        "error": pub0.get("error") or "",
                        "rule_version": pub0.get("version") or "", "binding": binding}
            st = str(existing.get("status") or "")
            if st in ("pending", "approved"):
                rb = _rule.rollback(rid, actor)
                if rb.get("error"):
                    return {"ok": False, "rule_code": rcode, "rule_id": rid,
                            "action": "rebind", "error": rb.get("error") or "rollback_failed",
                            "binding": binding}
            try:
                _cond_metrics2 = []
                for _r1 in json.loads(row.get("rules_json") or "[]"):
                    for _c1 in (_r1.get("when") or []):
                        _m1 = str((_c1 or {}).get("metric") or "").strip()
                        if _m1 and _m1 not in _cond_metrics2:
                            _cond_metrics2.append(_m1)
            except Exception:
                _cond_metrics2 = []
            upd = _rule.update_slots(rid, {"decision_tables": [code],
                                           "decision_table_binding": binding,
                                           "required_evidence": _GENERIC_EVIDENCE,
                                           "object": "、".join(_cond_metrics2)},
                                     actor)
            if upd.get("error"):
                return {"ok": False, "rule_code": rcode, "rule_id": rid,
                        "action": "rebind", "error": upd.get("error") or "update_failed",
                        "binding": binding}
            pub = _rule.publish_via_lifecycle(rid, actor)
            return {"ok": not bool(pub.get("error")), "rule_code": rcode, "rule_id": rid,
                    "action": "republished", "error": pub.get("error") or "",
                    "rule_version": pub.get("version") or "", "binding": binding}
        # 证据词来自决策表条件指标；表本身不知道业务字段之外的证据。
        try:
            _rules = json.loads(row.get("rules_json") or "[]")
        except Exception:
            _rules = []
        _metrics = []
        for _r in _rules:
            for _c in (_r.get("when") or []):
                _m = str((_c or {}).get("metric") or "").strip()
                if _m and _m not in _metrics:
                    _metrics.append(_m)
        slots = {"criterion": f"执行决策表 {code}",
                 "decision_tables": [code],
                 "decision_table_binding": binding,
                 "applicable_types": types,
                 "required_evidence": _decision_table_evidence_required(_metrics),
                 # 条件指标必须进入 manifest 的冻结别名裁剪键：manifest._rule_metric_keys
                 # 只读 metric/object/subject/parameter；决策表条件在 rules_json 里，
                 # 不放 object 会让本该保留的指标别名（合同总价→合同金额）被裁掉，
                 # D4 取数时被冻结别名白名单拒绝 → 决策表事实缺失（客户项目永不命中）。
                 "object": "、".join(_metrics),
                 "terms": ["决策表"],
                 "left": "决策表", "right": "文档",
                 "description": f"决策表 {row.get('name') or code} 发布时自动绑定的执行规则；"
                                f"条件以冻结表版本 {version} 为准；"
                                f"条件取数键：{'、'.join(_metrics) or '（无）'}"}
        got = _rule.create_rule(code=rcode, name=f"决策表执行｜{row.get('name') or code}",
                                category="completeness", rclass="R3", slots=slots,
                                source="decision_table_autobind",
                                scope={"applicable_types": types})
        rid = got.get("rule_id") or ""
        if not rid:
            return {"ok": False, "rule_code": rcode, "rule_id": "", "action": "created",
                    "error": "rule_create_failed", "binding": binding}
        pub = _rule.publish_via_lifecycle(rid, actor)
        return {"ok": not bool(pub.get("error")), "rule_code": rcode, "rule_id": rid,
                "action": "created", "error": pub.get("error") or "",
                "rule_version": pub.get("version") or "", "binding": binding}
    except Exception as e:
        return {"ok": False, "rule_code": rcode, "rule_id": "", "action": "failed",
                "error": f"{type(e).__name__}: {e}", "binding": binding}


def copy_as_draft(code: str, new_code: str = "", by: str = "") -> dict:
    """已发布表不可就地编辑：复制为新草稿再改。

    P1-B3-02/P2-B3-02：新编码同样走唯一性 + 字符集校验（copy 也是创建入口，
    不校验等于给重复/非法 code 留后门）。
    """
    row = get(code)
    if not row:
        return {"error": "决策表不存在"}
    nc = new_code or f"{code}-COPY"
    nc, _cverr, _ccode = validate_code(nc)
    if _cverr:
        return {"error": _cverr, "code": _ccode}
    if get(nc):
        return {"error": f"{nc} 已存在", "code": "duplicate_code"}
    import json as _j
    tid = db.new_id("dt")
    R.decision_tables.insert(id=tid, code=nc, name=f"{row.get('name') or code}（副本）",
                             hit_policy=row.get("hit_policy") or "first",
                             rules_json=row.get("rules_json") or "[]", status="draft",
                             version="v0.1", source=row.get("source") or "",
                             created_at=db.now(),
                             scope_types=row.get("scope_types") or "[]",
                             canary_percent=(100 if row.get("canary_percent") is None else int(row.get("canary_percent"))))
    R.audit_logs.log(actor=by or "system", action="decision_table.copied", object=code,
                     after=_j.dumps({"new": nc}, ensure_ascii=False))
    return {"id": tid, "code": nc, "status": "draft", "version": "v0.1"}


def evaluate(code: str, facts: dict, audit_type: str = "", case_id: str = "") -> dict:
    """对给定事实执行决策表；仅对已发布表求值，并遵守灰度范围。"""
    row = get(code)
    if not row:
        return {"error": "决策表不存在"}
    if str(row.get("status") or "") == "archived":
        return {"code": code, "state": "archived", "skipped": "archived",
                "matched": False, "hits": [], "error": "决策表已下线（不执行）"}
    if row.get("status") != "published":
        return {"error": "决策表未发布"}
    # 灰度：scope_types 限定的文档类型才生效
    try:
        scope = json.loads(row.get("scope_types") or "[]")
    except Exception:
        scope = []
    if scope and audit_type and audit_type not in scope:
        # F-22：skipped 必须显式带 state，调用方不得用 no_match 兜底伪装成“已求值未命中”
        return {"code": code, "state": "skipped", "skipped": "scope",
                "matched": False, "hits": []}
    # 灰度：按 case_id 哈希取模，稳定分流
    pct = 100 if row.get("canary_percent") is None else int(row.get("canary_percent"))
    if pct < 100:
        import zlib
        bucket = zlib.crc32((case_id or code).encode()) % 100
        if bucket >= pct:
            return {"code": code, "state": "skipped", "skipped": "canary",
                    "matched": False, "hits": []}
    rules = json.loads(row.get("rules_json") or "[]")
    policy = str(row.get("hit_policy") or "first")
    hits, unknown = _evaluate_rules(code, row.get("version"), policy, rules, facts)
    if policy == "unique" and len(hits) > 1:
        return {"code": code, "version": row.get("version"), "matched": False,
                "state": "conflict", "conflict": True, "hits": hits,
                "error": "unique 命中策略出现多条重叠结果"}
    return {"code": code, "version": row.get("version"), "matched": bool(hits),
            "unknown": (not hits) and unknown,
            "state": "match" if hits else ("unknown" if unknown else "no_match"), "hits": hits}


def evaluate_frozen(snapshot: dict, facts: dict, audit_type: str = "", case_id: str = "") -> dict:
    """按 manifest 冻结的决策表版本求值；不读当前已发布版本。"""
    code = str((snapshot or {}).get("code") or "")
    version = str((snapshot or {}).get("version") or "")
    if not code or not version:
        return {"error": "frozen decision table missing code/version", "code": code, "version": version}
    row = get(code)
    if not row:
        return {"error": "决策表不存在", "code": code, "version": version}
    hist = R.decision_table_versions.list("table_id=?", (row["id"],), order="id DESC")
    ver = next((x for x in hist if str(x.get("version") or "") == version), None)
    if not ver:
        return {"error": "冻结版本不存在", "code": code, "version": version}
    rules_json = ver.get("rules_json") or "[]"
    want_hash = str((snapshot or {}).get("rules_hash") or "")
    if want_hash:
        import hashlib as _h
        if _h.sha256(rules_json.encode("utf-8")).hexdigest() != want_hash:
            return {"error": "冻结版本哈希不匹配", "code": code, "version": version}
    import json as _j
    rules = _j.loads(rules_json)
    scope = (snapshot or {}).get("scope_types") or []
    if scope and audit_type and audit_type not in scope:
        return {"code": code, "version": version, "state": "skipped",
                "skipped": "scope", "matched": False, "hits": []}
    pct = int((snapshot or {}).get("canary_percent") if (snapshot or {}).get("canary_percent") is not None else 100)
    if pct < 100:
        import zlib
        if zlib.crc32((case_id or code).encode()) % 100 >= pct:
            return {"code": code, "version": version, "state": "skipped",
                    "skipped": "canary", "matched": False, "hits": []}
    hit_policy = str((snapshot or {}).get("hit_policy") or row.get("hit_policy") or "first")
    hits, unknown = _evaluate_rules(code, version, hit_policy, rules, facts)
    if hit_policy == "unique" and len(hits) > 1:
        return {"code": code, "version": version, "matched": False,
                "state": "conflict", "conflict": True, "hits": hits,
                "error": "unique 命中策略出现多条重叠结果"}
    return {"code": code, "version": version, "matched": bool(hits),
            "unknown": (not hits) and unknown,
            "state": "match" if hits else ("unknown" if unknown else "no_match"), "hits": hits}


def _result_state(res: dict) -> str:
    """统一 evaluate 结果的 state：兼容 error/skipped 等早期返回形状。"""
    res = res or {}
    state = str(res.get("state") or "")
    if state:
        return state
    if res.get("error"):
        return "error"
    if res.get("skipped"):
        return "skipped"
    if res.get("hits"):
        return "match"
    if res.get("unknown"):
        return "unknown"
    return "no_match"


def _spec_priority(spec, pos: int) -> int:
    raw = (spec or {}).get("priority", pos) if isinstance(spec, dict) else pos
    try:
        return int(raw)
    except (TypeError, ValueError):
        return pos


def evaluate_tables(specs, facts: dict, decision_policy: str = DEFAULT_DECISION_POLICY,
                    audit_type: str = "", case_id: str = "") -> dict:
    """按多表命中策略执行一组决策表，供 UI/CLI/多表调用方复用。

    specs 支持 code 字符串或 manifest 冻结快照（{code, version, ...}）：
    - 带 version 的快照按冻结版本求值（evaluate_frozen），避免当前表漂移；
    - 带 status 的快照（missing_or_unpublished）不执行，保留不可用状态；
    - priority 冲突按快照 priority/声明顺序裁决，all 保留全部命中表与行。

    decision_policy 非法时显式 error，不静默按 priority/conflict 执行。

    说明：manifest_exec 当前仍自带一套多表聚合（该文件不在本服务职责内）；本函数提供
    决策表层的同语义可配置实现，conflict/priority 裁决口径与 manifest 保持一致。
    """
    _vp = validate_decision_policy(decision_policy)
    empty = {"results": [], "matches": [], "match": None, "conflict": None,
             "hits": [], "matched": False}
    if not _vp["ok"]:
        return {"ok": False, "error": _vp["error"], "decision_policy": "",
                "state": "error", **empty}
    policy = _vp["policy"]
    if isinstance(specs, (str, dict)):
        specs = [specs]
    spec_list = [x for x in (specs or []) if x]
    if not spec_list:
        return {"ok": False, "error": "未声明决策表", "decision_policy": policy,
                "state": "error", **empty}
    results = []
    for pos, spec in enumerate(spec_list):
        _keep_state = ""
        if isinstance(spec, dict):
            code = str(spec.get("code") or "")
            status = str(spec.get("status") or "")
            if status:
                _keep_state = status
                res = {"code": code, "version": str(spec.get("version") or ""),
                       "hit_policy": str(spec.get("hit_policy") or ""), "hits": [],
                       "error": "决策表不可用，未执行"}
            elif spec.get("version"):
                res = evaluate_frozen(spec, facts, audit_type=audit_type, case_id=case_id)
            else:
                res = evaluate(code, facts, audit_type=audit_type, case_id=case_id)
        else:
            code = str(spec)
            res = evaluate(code, facts, audit_type=audit_type, case_id=case_id)
        res = dict(res or {})
        res.setdefault("code", code)
        res["state"] = _keep_state or _result_state(res)
        res["priority"] = _spec_priority(spec, pos)
        results.append(res)

    matches = [x for x in results if x.get("state") == "match" and x.get("hits")]
    conflicts = [x for x in results if x.get("state") == "conflict"]
    if conflicts:
        cf = dict(conflicts[0])
        cf["result"] = "conflict"
        return {"ok": True, "decision_policy": policy, "results": results,
                "matches": matches, "match": None, "conflict": cf,
                "hits": list(cf.get("hits") or []), "state": "conflict",
                "matched": False, "error": str(cf.get("error") or "决策表命中冲突")}
    # 多表同时命中：conflict 策略不自动取舍；priority/all 才允许继续产出。
    if len(matches) > 1 and policy == "conflict":
        hits = [h for x in matches for h in (x.get("hits") or [])]
        cf = {"code": ",".join(str(x.get("code") or "") for x in matches),
              "version": "", "hit_policy": "multi", "hits": hits,
              "facts": {}, "result": "conflict",
              "error": "多张决策表同时命中且未声明优先级"}
        return {"ok": True, "decision_policy": policy, "results": results,
                "matches": matches, "match": None, "conflict": cf,
                "hits": hits, "state": "conflict", "matched": False,
                "error": cf["error"]}
    if matches:
        matches.sort(key=lambda x: int(x.get("priority") or 0))
        match = matches[0]
        if policy == "all":
            hits = [h for x in matches for h in (x.get("hits") or [])]
        else:
            hits = list(match.get("hits") or [])
        return {"ok": True, "decision_policy": policy, "results": results,
                "matches": matches, "match": match, "conflict": None,
                "hits": hits, "state": "match", "matched": bool(hits),
                "error": ""}
    error = next((str(x.get("error") or "") for x in results if x.get("error")), "")
    state = "error" if error else (
        "unknown" if any(x.get("state") == "unknown" for x in results) else "no_match")
    return {"ok": not error, "decision_policy": policy, "results": results,
            "matches": [], "match": None, "conflict": None, "hits": [],
            "state": state, "matched": False, "error": error}


def list_tables() -> list:
    out = []
    for r in R.decision_tables.list(order="created_at DESC"):
        _owner = r.get("owner") or ""
        try:
            from . import account as _acc
            _dept = _acc.department_of(_owner)
        except Exception:
            _dept = ""
        out.append({"id": r["id"], "code": r["code"], "name": r["name"],
                    "hit_policy": r.get("hit_policy"), "status": r.get("status"),
                    "version": r.get("version"), "owner": _owner, "department": _dept,
                    "rows": len(json.loads(r.get("rules_json") or "[]")),
                    "scope_types": json.loads(r.get("scope_types") or "[]"),
                    "canary_percent": r.get("canary_percent", 100)})
    return out
