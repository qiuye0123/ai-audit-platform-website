"""裁决来源统计（L80 / P0-C）：``adjudication_ledger`` 唯一写入口 + 统计 + 导出。

规格：``docs/CURRENT/89-裁决来源统计规格_20261124.md``（L75 / P0-C）；
落地依据：``docs/CURRENT/87-build49决策清单_20261124.md`` D1 第③步；
施工报告：``docs/qa/L80_裁决台账实现_20261124.md``。

一句话
------
每个**激活单元** ``(run_id, object_id, rule_version_id, instance_id)`` 一行只追加台账，
记录事实来源 / 执行器 / 模型调用 / 程序复算 / 最终裁决者 / 弃权原因 / 路由状态；
四类裁决者（pure_program / model_validated / human / undecided）互斥且和 = 激活数；
模型抽取占比与裁决者正交；映射路由与真实路由分列。开关
``RULEPROOF_ADJUDICATION_LEDGER`` 默认 **0**（=0 逐字节回退：0 DDL / 0 行 / 报告无该块）。

铁律
----
* 只投影，不改变任何判定：本模块不写 finding / manifest_result / d1–d5，
  只读 d1–d5 + d4 tool_trace + 证据门禁 + 人工复核事件；
* 唯一写入口 ``emit_rows``（append-only；禁止 UPDATE/DELETE，由 DB 触发器兜底）；
* 写失败不得阻断审核：整段 try/except + 结构化 warning + 审计
  ``adjudication.ledger.write_failed``（铁律 2：不静默）；
* 不落原文：只落 ``quote_sha256`` + ``evidence_ref_json`` 引用（控体积/隐私）；
* 统计唯一入口 ``ledger_stats()``（报告 JSON / HTTP / CLI / 导出共用，A7 可复算）。

append-only 与人工归因
----------------------
人工复核发生在台账写入**之后**，而台账禁止 UPDATE。因此人工归因是
``ledger_stats()`` 读时投影：从 ``manifest_review``（append-only 历史）
取最新人工裁决覆盖 ``adjudicator=human``，不修改台账行本身。台账行保留写入时
的自动归因（executor/recomputed/evidence_status），两者都落在统计块的
``overlay`` 字段里，可对账。
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
from datetime import datetime

from .. import db

LOG = logging.getLogger(__name__)

# 与 app/db.py 同一环境变量名（db 层 init_db 也读同一变量；两边不互相 import）
ENV_LEDGER = "RULEPROOF_ADJUDICATION_LEDGER"
ENV_STRICT = "RULEPROOF_ADJUDICATION_LEDGER_STRICT"

SCHEMA_VERSION = "adjudication_ledger/v1"
LEDGER_VERSION = "adjudication_ledger/v1"
STATS_SCHEMA = "adjudication_stats/v1"
ROUTE_SCHEMA = "adjudication_route/v1"
ROUTE_KEY_PREFIX = "adjudication_route:"
OFF_TOKENS = ("0", "false", "no", "off")

# ---------------------------------------------------------------- 枚举（89 号 §4.2）
ADJUDICATORS = ("pure_program", "model_validated", "human", "undecided")
FINAL_STATES = ("pass", "fail", "insufficient", "na", "unknown", "needs_model",
                "execution_failed", "missing")
TERMINAL_STATES = ("pass", "fail", "insufficient", "na", "execution_failed")
UNDECIDED_REASONS = ("no_state", "missing_executor", "model_unverified",
                     "missing_artifact", "ambiguous_engine", "model_disabled")
ABSTAIN_REASONS = ("wide_upper_bound", "missing_unit", "unknown_unit",
                   "approx_unconfirmed", "unsupported_type", "quote_not_found",
                   "no_evidence", "parse_gap", "jev_calibration",
                   "scope_unverified", "fail_by_absence", "policy_pending",
                   "execution_failed", "insufficient_not_recorded")
EXECUTOR_TIERS = ("deterministic", "model", "human", "n/a")
FACT_SOURCES = ("doc_text", "sheet_cell", "docx", "pdf", "kie", "facts",
                "mixed", "none", "unknown")
EXTRACTION_SOURCES = ("deterministic", "model", "none", "unknown")
MODEL_CALLS_SCOPES = ("instance", "rule", "document", "run", "none")
RECOMPUTE_KINDS = ("numeric", "sum_check", "consistency", "quote_gate",
                   "cite_bind", "date_compare", "applicability",
                   "deterministic_text", "none", "unknown")
ROUTE_STATUSES = ("in_manifest", "routed_out", "na_all_mode", "na_direct")
ATTRIBUTION_BASES = ("executor_field", "d4_tool_trace", "artifact_declared",
                     "engine_subset_prior", "state_only", "human_event",
                     "manifest_route")
ATTRIBUTION_CONFIDENCES = ("high", "medium", "low")

DET_EXECUTORS = ("ruleexec", "ruleexec.", "decision_table", "tool")
MODEL_EXECUTORS = ("agent-judge", "semantic", "kie", "llm-judge")

# 台账列顺序 = INSERT 列顺序（与 db.ADJUDICATION_LEDGER_SCHEMA 一一对应）
COLUMNS = ("id", "schema_version", "run_id", "case_id", "tenant_id",
           "workspace_id", "object_id", "rule_code", "rule_version_id",
           "item_key", "manifest_id", "instance_id", "instance_index",
           "final_state", "adjudicator", "undecided_reason", "abstain_reason",
           "executor", "executor_tier", "fact_source", "extraction_source",
           "model_calls", "model_calls_scope", "model_ids", "recomputed",
           "recompute_kind", "evidence_status", "quote_sha256",
           "evidence_ref_json", "route_status", "route_reason", "mapped_route",
           "human_decision_id", "human_decision", "attribution_basis",
           "attribution_confidence", "created_at", "ledger_version")

# 内部字段（row_from_* 生成，入库前剥离；不得进入 DB 列）
_INTERNAL_KEYS = ("_reason_hint", "_model_disabled", "_source")


# ================================================================ 开关
def _is_on(raw) -> bool:
    return str(raw or "0").strip().lower() not in OFF_TOKENS


def enabled() -> bool:
    """RULEPROOF_ADJUDICATION_LEDGER 唯一解析（默认 0；每次调用读取，便于正/反测试）。

    字面量名 + 裸 ``0`` 默认值：既是扫描器（开关注册表）可识别的读取点，也让
    default_off 分类为 opt-in（开关=1 才建表/写入/统计）。
    """
    return _is_on(os.environ.get("RULEPROOF_ADJUDICATION_LEDGER", 0))


def strict_enabled() -> bool:
    """RULEPROOF_ADJUDICATION_LEDGER_STRICT 唯一解析（默认 0=advisory）。"""
    return _is_on(os.environ.get("RULEPROOF_ADJUDICATION_LEDGER_STRICT", 0))


def validate_switches() -> dict:
    """显式校验非法组合（89 号 §7）：STRICT=1 且 LEDGER=0 → 报错，不静默。

    返回 {"ledger": bool, "strict": bool, "mode": "disabled|advisory|blocking"}；
    非法组合抛 ValueError（调用方转 HTTP 409 / CLI 退出码非 0）。
    """
    ledger_on, strict_on = enabled(), strict_enabled()
    if strict_on and not ledger_on:
        raise ValueError(
            "非法开关组合：RULEPROOF_ADJUDICATION_LEDGER_STRICT=1 但 "
            "RULEPROOF_ADJUDICATION_LEDGER=0（严格模式只在台账开启时有效）")
    return {"ledger": ledger_on, "strict": strict_on,
            "mode": "blocking" if (ledger_on and strict_on)
            else ("advisory" if ledger_on else "disabled")}


def gate_mode() -> str:
    try:
        return validate_switches()["mode"]
    except ValueError:
        return "invalid"


# ================================================================ 建表 / 开关联动
def table_exists(conn=None) -> bool:
    c = conn or db.connect()
    own = conn is None
    try:
        row = c.execute("SELECT name FROM sqlite_master WHERE type='table' "
                        "AND name='adjudication_ledger'").fetchone()
        return bool(row)
    finally:
        if own:
            try:
                c.close()
            except Exception:
                logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)


def ensure_table(conn=None) -> bool:
    """幂等建表（仅开关=1 时可用）；失败只 warning 返回 False，不阻断调用方。

    注意：init_db 在开关=1 时已建表；本函数兜底“先建库后开开关 / CLI 直连老库”场景。
    """
    if not enabled():
        return False
    c = conn
    own = False
    if c is None:
        c = db.connect()
        own = True
    try:
        db._init_adjudication_ledger_schema(c)
        if own:
            c.commit()
        return True
    except Exception:  # 铁律 2：建表失败留痕；写失败不阻断审核（审计兜底）
        LOG.warning("adjudication_ledger 建表失败（不阻断主链；RULEPROOF_ADJUDICATION_LEDGER=1）",
                    exc_info=True)
        return False
    finally:
        if own:
            try:
                c.close()
            except Exception:
                logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)


# ================================================================ 纯分类函数
def _ext_of(path: str) -> str:
    p = str(path or "")
    return p.rsplit(".", 1)[-1].lower() if "." in p else ""


def normalize_final_state(raw) -> str:
    """d5/sub 原始状态 → 89 号 §4.2 final_state 枚举（非法值 fail-closed 为 unknown）。"""
    s = str(raw if raw is not None else "").strip()
    low = s.lower()
    if s in ("pass", "fail", "na", "insufficient"):
        return s
    if s == "execution_failed":
        return "execution_failed"
    if low in ("not_applicable", "not applicable", "n/a", "skipped", "不适用"):
        return "na"
    if low in ("unknown", "needs_model", "missing", ""):
        return "unknown" if low == "unknown" else low
    if low in ("blocked", "failed", "execution_failed", "执行失败"):
        return "execution_failed"
    if low in ("ok", "满足", "通过"):
        return "pass"
    if low in ("不满足", "不通过"):
        return "fail"
    if low in ("证据不足",):
        return "insufficient"
    if low in ("无法判断", "未判断"):
        return "unknown"
    return "unknown"


def executor_tier(executor: str) -> str:
    ex = str(executor or "").strip()
    if not ex:
        return "n/a"
    if is_deterministic(ex):
        return "deterministic"
    if is_model(ex):
        return "model"
    if ex == "human":
        return "human"
    return "n/a"


def is_deterministic(executor: str) -> bool:
    ex = str(executor or "").strip()
    return any(ex == p or ex.startswith(p) for p in DET_EXECUTORS)


def is_model(executor: str) -> bool:
    ex = str(executor or "").strip()
    return any(ex == p or ex.startswith(p) for p in MODEL_EXECUTORS)


def classify_adjudicator(row: dict) -> dict:
    """89 号 §4.3 单一裁决者判定函数（**唯一实现**；禁止调用方自写）。

    返回 {"adjudicator", "undecided_reason"}；human 优先、再看终态、再看执行器。
    纯函数：不修改入参（`finalize_row` 负责写回）。
    """
    r = row if isinstance(row, dict) else {}
    human = str(r.get("human_decision") or "")
    if human in ("confirm", "reject", "rule_error", "need_evidence"):
        return {"adjudicator": "human", "undecided_reason": ""}
    fs = str(r.get("final_state") or "")
    if fs in ("unknown", "needs_model", "missing", ""):
        return {"adjudicator": "undecided", "undecided_reason": "no_state"}
    executor = str(r.get("executor") or "").strip()
    if not executor:
        hint = str(r.get("undecided_reason") or "")
        reason = hint if hint in UNDECIDED_REASONS else "missing_executor"
        if r.get("_model_disabled"):
            reason = "model_disabled"
        return {"adjudicator": "undecided", "undecided_reason": reason}
    if is_deterministic(executor):
        return {"adjudicator": "pure_program", "undecided_reason": ""}
    if is_model(executor):
        verified = str(r.get("evidence_status") or "") == "verified"
        recomputed = r.get("recomputed")
        if verified and recomputed == 1:
            return {"adjudicator": "model_validated", "undecided_reason": ""}
        return {"adjudicator": "undecided", "undecided_reason": "model_unverified"}
    return {"adjudicator": "undecided", "undecided_reason": "ambiguous_engine"}


def finalize_row(row: dict) -> dict:
    """补全枚举/互斥裁决者/弃权原因/归因置信（就地写回，返回同一 dict）。"""
    r = row if isinstance(row, dict) else {}
    fs = normalize_final_state(r.get("final_state"))
    if fs not in FINAL_STATES:  # pragma: no cover - normalize 已 fail-closed
        fs = "unknown"
    r["final_state"] = fs
    ex = str(r.get("executor") or "").strip()
    r["executor"] = ex
    r["executor_tier"] = executor_tier(ex)
    if str(r.get("extraction_source") or "") not in EXTRACTION_SOURCES:
        r["extraction_source"] = "unknown"
    if str(r.get("fact_source") or "") not in FACT_SOURCES:
        r["fact_source"] = "unknown"
    if str(r.get("route_status") or "") not in ROUTE_STATUSES:
        r["route_status"] = "in_manifest"
    # 弃权原因：insufficient / execution_failed 必填（A3 硬约束）
    abstain = str(r.get("abstain_reason") or "").strip()
    if fs in ("insufficient", "execution_failed"):
        if not abstain:
            abstain = _abstain_code(r)
        r["abstain_reason"] = abstain
        if fs == "execution_failed" and not abstain.startswith("execution_failed"):
            r["abstain_reason"] = "execution_failed:" + (r.get("_reason_hint")
                                                         or abstain or "unknown")
    else:
        r["abstain_reason"] = ""
    # 程序复算：model_validated 必须 verified ∧ recomputed=1（A4）
    rec = r.get("recomputed")
    if rec not in (0, 1, None):
        rec = int(bool(rec))
    r["recomputed"] = rec
    if str(r.get("recompute_kind") or "") not in RECOMPUTE_KINDS:
        r["recompute_kind"] = "unknown" if rec is None else "none"
    if str(r.get("model_calls_scope") or "") not in MODEL_CALLS_SCOPES:
        r["model_calls_scope"] = "none"
    if str(r.get("attribution_basis") or "") not in ATTRIBUTION_BASES:
        r["attribution_basis"] = "state_only"
    if str(r.get("attribution_confidence") or "") not in ATTRIBUTION_CONFIDENCES:
        r["attribution_confidence"] = "low"
    cls = classify_adjudicator(r)
    r["adjudicator"] = cls["adjudicator"]
    r["undecided_reason"] = cls["undecided_reason"]
    if cls["adjudicator"] != "undecided":
        r["undecided_reason"] = ""
    return r


def _abstain_code(row: dict) -> str:
    """原始 reason/raw_state/detail 关键字 → 89 号 §4.2 弃权原因枚举（首个匹配）。"""
    r = row if isinstance(row, dict) else {}
    raw = " ".join(str(r.get(k) or "") for k in (
        "abstain_reason", "_reason_hint", "_raw_reason", "detail", "raw_state"))
    low = raw.lower()
    table = (
        (("jev", "校准"), "jev_calibration"),
        (("wide", "上界", "upper_bound"), "wide_upper_bound"),
        (("missing_unit", "缺单位", "单位缺失", "unknown_unit"), "missing_unit"),
        (("approx", "近似"), "approx_unconfirmed"),
        (("unsupported", "不支持"), "unsupported_type"),
        (("quote", "引文", "证据缺失引文"), "quote_not_found"),
        (("parse", "解析"), "parse_gap"),
        (("scope_unverified", "适用性未验证"), "scope_unverified"),
        (("policy", "待定"), "policy_pending"),
        (("fail_by_absence",), "fail_by_absence"),
        (("evidence", "证据"), "no_evidence"),
    )
    for keys, code in table:
        if any(k in low for k in keys):
            return code
    return "insufficient_not_recorded"


def _recompute_kind(executor: str, evidence_status: str) -> str:
    ex = str(executor or "")
    if not ex:
        return "none"
    if ex.startswith("ruleexec.consistency"):
        return "consistency"
    if ex.startswith("ruleexec.applicability"):
        return "applicability"
    if ex.startswith("ruleexec.placeholder"):
        return "deterministic_text"
    if ex.startswith(("ruleexec.limit", "ruleexec.domain")):
        return "numeric"
    if ex.startswith("ruleexec.evidence"):
        return "quote_gate" if evidence_status == "verified" else "none"
    if ex == "decision_table":
        return "applicability"
    if ex == "tool":
        return "numeric"
    if ex == "ruleexec":
        return "deterministic_text"
    return "quote_gate" if evidence_status == "verified" else "unknown"


def _infer_executor(sub: dict, item: dict, d1: dict, d4: dict) -> str:
    """89 号 §5#3：取执行器；无 tool_trace 时按「确定性通道先验」显式降置信。

    只对**确定性闸门**（证据/适用性/类型支持/区间守卫）做先验归因，且
    ``attribution_basis=engine_subset_prior / medium``；模型类/未知通道一律返回 ""，
    由 ``classify_adjudicator`` fail-closed 为 undecided（不猜）。
    """
    sub = sub if isinstance(sub, dict) else {}
    tt = sub.get("tool_trace") or {}
    ex = str(tt.get("executor") or tt.get("tool") or "").strip()
    if ex:
        return ex
    raw_state = str(sub.get("raw_state") or "").lower()
    if raw_state in ("evidence_missing", "evidence_insufficient"):
        return "ruleexec.evidence"
    if raw_state.startswith("decision_table"):
        return "decision_table"
    if raw_state in ("unsupported", "unsupported_type", "type_unsupported"):
        return "ruleexec"
    if raw_state in ("scope_unverified", "applicability_unverified"):
        return "ruleexec.applicability"
    if raw_state in ("quote_not_found", "quote_missing", "parse_gap"):
        return "ruleexec.evidence"
    if raw_state in ("wide_upper_bound", "approx_unconfirmed", "missing_unit",
                     "unknown_unit", "fail_by_absence", "policy_pending"):
        return "ruleexec"
    return ""




def _sub_quote(sub: dict) -> str:
    sub = sub if isinstance(sub, dict) else {}
    tt = sub.get("tool_trace") or {}
    eg = sub.get("evidence_gate") or {}
    for cand in (sub.get("quote"), sub.get("source_quote"), tt.get("quote"),
                 tt.get("source_quote"), eg.get("quote")):
        if str(cand or "").strip():
            return str(cand)
    return ""


def _evidence_status(sub: dict, final_state: str, executor: str) -> str:
    sub = sub if isinstance(sub, dict) else {}
    eg = sub.get("evidence_gate") if isinstance(sub.get("evidence_gate"), dict) else None
    if final_state == "fail":
        if eg and eg.get("passed") is True:
            return "verified"
        if eg and eg.get("passed") is False:
            return "missing"
        if _sub_quote(sub) and is_deterministic(executor):
            return "partial"
        return "unverified"
    if final_state == "insufficient":
        if eg and eg.get("passed") is False:
            return "missing"
        return "partial"
    if final_state in ("pass", "na", "execution_failed"):
        return "not_required"
    return "unverified"


def _recomputed(sub: dict, executor: str, evidence_status: str,
                final_state: str) -> tuple:
    sub = sub if isinstance(sub, dict) else {}
    eg = sub.get("evidence_gate") if isinstance(sub.get("evidence_gate"), dict) else None
    if final_state in ("unknown", "needs_model", "missing"):
        return 0, "none"
    if is_model(executor):
        if eg and eg.get("passed") is True and evidence_status == "verified":
            return 1, "quote_gate"
        return 0, "none"
    if is_deterministic(executor):
        raw_state = str(sub.get("raw_state") or "").lower()
        if raw_state in ("evidence_missing", "decision_table_unavailable"):
            return 0, "none"
        return 1, _recompute_kind(executor, evidence_status)
    return 0, "none"


def _fact_source(doc_type: str, item: dict, path: str = "") -> str:
    dt = str(doc_type or "").lower().lstrip(".")
    if not dt:
        dt = _ext_of(path)
    if dt in ("xlsx", "xls", "xlsm", "csv", "tsv"):
        return "sheet_cell" if dt != "csv" else "doc_text"
    if dt in ("docx", "doc"):
        return "docx"
    if dt == "pdf":
        return "pdf"
    if dt in ("txt", "md", "markdown", "html", "htm"):
        return "doc_text"
    try:
        scope = (item or {}).get("execution_hints", {}).get("evidence_scope") or []
        if "document_set" in scope:
            return "mixed"
    except Exception:
        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    return "unknown"


def _extraction_source(executor: str, final_state: str) -> str:
    if not str(executor or "").strip():
        return "unknown"
    if is_model(executor):
        return "model"
    if is_deterministic(executor):
        return "deterministic"
    return "unknown"


def _quote_sha256(quote: str) -> str:
    q = str(quote or "")
    return hashlib.sha256(q.encode("utf-8")).hexdigest() if q else ""


def _mapped_attr(item: dict, d4: dict, executor: str) -> tuple:
    """返回 (attribution_basis, attribution_confidence)。executor 来自 tool_trace 时高置信。"""
    sub_execs = []
    for s in ((d4 or {}).get("subs") or []):
        tt = (s or {}).get("tool_trace") or {}
        if tt.get("executor"):
            sub_execs.append(str(tt["executor"]))
    if sub_execs:
        return "executor_field", "high"
    if executor:
        return "engine_subset_prior", "medium"
    return "state_only", "low"


# ================================================================ 行构造（写入口输入）
def _row_id(run_id: str, rule_version_id: str, object_id: str,
            instance_id: str, item_key: str) -> str:
    raw = "|".join(str(x or "") for x in (run_id, rule_version_id, object_id,
                                          instance_id, item_key))
    return "adj" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _base_row(*, run_id: str, case_id: str, tenant_id: str, workspace_id: str,
              manifest_id: str, item: dict, code: str, object_id: str,
              item_key: str, rule_version_id: str) -> dict:
    return {
        "run_id": str(run_id or ""), "case_id": str(case_id or ""),
        "tenant_id": str(tenant_id or ""), "workspace_id": str(workspace_id or ""),
        "object_id": str(object_id or ""), "rule_code": str(code or ""),
        "rule_version_id": str(rule_version_id or ""), "item_key": str(item_key or ""),
        "manifest_id": str(manifest_id or ""),
        "instance_id": "", "instance_index": 0,
        "route_status": "in_manifest", "route_reason": "",
        "human_decision_id": "", "human_decision": "",
        "model_calls": None, "model_ids": "", "model_calls_scope": "document",
        "schema_version": SCHEMA_VERSION, "ledger_version": LEDGER_VERSION,
        "created_at": db.now(), "evidence_ref_json": "{}",
        "quote_sha256": "", "mapped_route": 0,
    }


def rows_for_item(*, run_id: str, case_id: str, tenant_id: str = "",
                  workspace_id: str = "", manifest_id: str = "",
                  item: dict, d1: dict = None, d2: dict = None,
                  d3: dict = None, d4: dict = None, d5: dict = None,
                  doc_type: str = "", path: str = "") -> list:
    """单条 manifest item → 0..n 行台账（=激活单元；1 行/实例）。

    实例口径：``d4.subs`` 每项 = 一个执行实例（单实例规则 = 1；多实例 S1..Sn /
    ``#MI<n>`` 逐实例）。无 subs 时（D1 不适用 / D2 缺版本 / D3 无文本 / 决策表
    整体 skipped）也落 1 行，终态取 d5，执行器按确定性先验显式低置信。
    """
    item = item if isinstance(item, dict) else {}
    d1 = d1 if isinstance(d1, dict) else {}
    d2 = d2 if isinstance(d2, dict) else {}
    d4 = d4 if isinstance(d4, dict) else {}
    d5 = d5 if isinstance(d5, dict) else {}
    code = str(item.get("code") or "")
    object_id = str(item.get("object_id") or "")
    rule_id = str(item.get("rule_id") or "")
    item_key = f"{object_id}|{rule_id}"
    rule_version_id = str((d2 or {}).get("version") or item.get("version") or "")
    subs = [s for s in (d4.get("subs") or []) if isinstance(s, dict)]
    rows = []
    if subs:
        for idx, sub in enumerate(subs):
            sid = str(sub.get("id") or "")
            fs = normalize_final_state(sub.get("status"))
            executor = _infer_executor(sub, item, d1, d4)
            ev_status = _evidence_status(sub, fs, executor)
            rec, rec_kind = _recomputed(sub, executor, ev_status, fs)
            basis, conf = _mapped_attr(item, {"subs": [sub]}, executor)
            quote = _sub_quote(sub)
            er = {"quote_sha256": _quote_sha256(quote), "quote_len": len(quote),
                  "evidence_type": str(sub.get("evidence_type") or ""),
                  "source_locator": str(sub.get("source_locator")
                                        or (sub.get("tool_trace") or {}).get("source_locator")
                                        or "")[:200]}
            row = _base_row(run_id=run_id, case_id=case_id, tenant_id=tenant_id,
                            workspace_id=workspace_id, manifest_id=manifest_id,
                            item=item, code=code, object_id=object_id,
                            item_key=item_key, rule_version_id=rule_version_id)
            row.update({
                "instance_id": sid, "instance_index": idx,
                "final_state": fs, "executor": executor,
                "fact_source": _fact_source(doc_type, item, path),
                "extraction_source": _extraction_source(executor, fs),
                "recomputed": rec, "recompute_kind": rec_kind,
                "evidence_status": ev_status, "quote_sha256": _quote_sha256(quote),
                "evidence_ref_json": json.dumps(er, ensure_ascii=False, sort_keys=True),
                "model_calls": 0 if is_deterministic(executor) else None,
                "model_calls_scope": "none" if is_deterministic(executor) else "document",
                "attribution_basis": basis, "attribution_confidence": conf,
                "abstain_reason": str(sub.get("abstain_reason") or ""),
                "_reason_hint": " ".join(str(sub.get(k) or "") for k in
                                         ("reason", "detail", "raw_state")),
                "_raw_reason": str(sub.get("raw_state") or ""),
                "_model_disabled": bool(
                    (sub.get("raw_item") or {}).get("module_disabled")
                    or "mod_agents" in str(sub.get("detail") or "")),
            })
            row["id"] = _row_id(run_id, rule_version_id, object_id, sid, item_key)
            rows.append(finalize_row(row))
    else:
        fs = normalize_final_state(d5.get("status"))
        executor = ""
        raw_reason = " ".join(str(x or "") for x in (d5.get("reason"), d4.get("detail"),
                                                    d4.get("reason")))
        tt = d4.get("tool_trace") or {}
        if tt.get("executor"):
            executor = str(tt.get("executor"))
        elif d1.get("status") == "not_applicable":
            executor = "ruleexec.applicability"
        elif fs == "execution_failed" and "规则版本" in raw_reason:
            executor = ""  # 规则版本缺失 = 不可归因（missing_artifact，不猜确定性）
        elif fs == "execution_failed":
            executor = "ruleexec"
        elif fs == "insufficient" and ("文本" in raw_reason or "范围" in raw_reason
                                       or "sheet" in raw_reason):
            executor = "ruleexec.evidence"
        ev_status = _evidence_status({}, fs, executor)
        rec = 0
        rec_kind = "none"
        if is_deterministic(executor):
            rec, rec_kind = (1, _recompute_kind(executor, ev_status))
        basis, conf = ("executor_field", "high") if tt.get("executor") else (
            ("engine_subset_prior", "medium") if executor else ("state_only", "low"))
        row = _base_row(run_id=run_id, case_id=case_id, tenant_id=tenant_id,
                        workspace_id=workspace_id, manifest_id=manifest_id,
                        item=item, code=code, object_id=object_id,
                        item_key=item_key, rule_version_id=rule_version_id)
        row.update({
            "final_state": fs, "executor": executor,
            "fact_source": _fact_source(doc_type, item, path),
            "extraction_source": _extraction_source(executor, fs),
            "recomputed": rec, "recompute_kind": rec_kind,
            "evidence_status": ev_status, "quote_sha256": "",
            "model_calls": 0 if is_deterministic(executor) else None,
            "model_calls_scope": "none" if is_deterministic(executor) else "document",
            "attribution_basis": basis, "attribution_confidence": conf,
            "abstain_reason": "",
            "undecided_reason": ("missing_artifact"
                                 if (not executor and "版本" in raw_reason) else ""),
            "_reason_hint": raw_reason,
            "_raw_reason": str(d5.get("reason") or ""),
        })
        row["id"] = _row_id(run_id, rule_version_id, object_id, "", item_key)
        rows.append(finalize_row(row))
    return rows


def row_for_finding(*, run_id: str, case_id: str, tenant_id: str = "",
                    workspace_id: str = "", manifest_id: str = "",
                    finding: dict, manifest_id_of_case: str = "") -> dict:
    """legacy/direct 通道（无 manifest 行）→ 低置信台账行（artifact_declared）。"""
    f = finding if isinstance(finding, dict) else {}
    code = str(f.get("rule_id") or f.get("rule_code") or f.get("point_id") or "")
    object_id = str(f.get("object_id") or "")
    instance_id = "legacy:" + str(f.get("id") or "")[:12]
    item_key = f"{object_id}|{code}"
    fs = normalize_final_state(f.get("state") or f.get("status"))
    if str(f.get("status") or "") in ("confirmed", "false_positive", "need_evidence"):
        fs = normalize_final_state(f.get("state"))
    executor = "legacy"
    if str(f.get("engine") or "").startswith("manifest"):
        executor = "legacy"
    ev_status = "verified" if str(f.get("backfill_status") or "") in (
        "verified", "backfilled", "ok") else "unverified"
    row = {
        "id": _row_id(run_id, str(f.get("rule_version") or ""), object_id,
                      instance_id, item_key),
        "schema_version": SCHEMA_VERSION, "run_id": str(run_id or ""),
        "case_id": str(case_id or ""), "tenant_id": str(tenant_id or ""),
        "workspace_id": str(workspace_id or ""), "object_id": object_id,
        "rule_code": code, "rule_version_id": str(f.get("rule_version") or ""),
        "item_key": item_key, "manifest_id": str(manifest_id or ""),
        "instance_id": instance_id, "instance_index": 0,
        "final_state": fs, "abstain_reason": "",
        "executor": executor, "executor_tier": "n/a",
        "fact_source": "unknown", "extraction_source": "unknown",
        "model_calls": None, "model_calls_scope": "document", "model_ids": "",
        "recomputed": None, "recompute_kind": "unknown",
        "evidence_status": ev_status,
        "quote_sha256": _quote_sha256(str(f.get("verbatim_quote") or "")),
        "evidence_ref_json": json.dumps(
            {"finding_id": str(f.get("id") or ""),
             "engine": str(f.get("engine") or "")}, ensure_ascii=False, sort_keys=True),
        "route_status": "na_direct", "route_reason": "no_manifest_row",
        "mapped_route": 0, "human_decision_id": "", "human_decision": "",
        "attribution_basis": "artifact_declared", "attribution_confidence": "low",
        "created_at": db.now(), "ledger_version": LEDGER_VERSION,
        "_reason_hint": str(f.get("summary") or "")[:200],
        "_source": "finding_reconcile",
    }
    if fs in ("insufficient", "execution_failed"):
        row["abstain_reason"] = _abstain_code(row)
    return finalize_row(row)


# ================================================================ 唯一写入口
def _clean_row(row: dict) -> dict:
    out = {}
    for k in COLUMNS:
        v = row.get(k)
        if k in ("model_calls", "recomputed"):
            pass
        out[k] = v
    # NOT NULL 列兜底
    out["final_state"] = str(out.get("final_state") or "unknown")
    out["adjudicator"] = str(out.get("adjudicator") or "undecided")
    out["attribution_basis"] = str(out.get("attribution_basis") or "state_only")
    out["attribution_confidence"] = str(out.get("attribution_confidence") or "low")
    return out


def emit_rows(rows: list, *, conn=None) -> dict:
    """批量事务写台账（append-only；唯一写入口）。

    - 幂等：同 (run, rule_version, object, instance, item_key) 已存在 → 跳过；
    - 失败不阻断：返回 {"ok": False, ...} 并写审计 ``adjudication.ledger.write_failed``
      （若审计也失败只 warning，不抛出）；
    - 不在这里写 ``adjudication.ledger.written``（由 emit_run 在 run 末统一写一条）。
    """
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if not rows:
        return {"ok": True, "written": 0, "skipped": 0, "run_ids": []}
    if not enabled():
        return {"ok": False, "skipped_disabled": True, "written": 0, "skipped": len(rows)}
    if not ensure_table():
        _audit_failure("adjudication_ledger_ensure_table_failed", rows, "")
        return {"ok": False, "error": "table_unavailable", "written": 0,
                "skipped": len(rows)}
    c = conn
    own = False
    if c is None:
        c = db.connect()
        own = True
    written = 0
    try:
        cols = COLUMNS
        sql = ("INSERT INTO adjudication_ledger(%s) VALUES(%s) "
               "ON CONFLICT(run_id, rule_version_id, object_id, instance_id, item_key) "
               "DO NOTHING" % (",".join(cols), ",".join("?" * len(cols))))
        before_total = c.total_changes
        for row in rows:
            clean = _clean_row(row)
            c.execute(sql, [clean.get(k) for k in cols])
        written = int(c.total_changes - before_total)
        if own:
            c.commit()
        return {"ok": True, "written": written, "skipped": len(rows) - written,
                "run_ids": sorted({str(r.get("run_id") or "") for r in rows})}
    except Exception as exc:  # 铁律 2：写失败必须留痕，不阻断审核
        try:
            if own:
                c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
        LOG.warning("adjudication_ledger 写入失败（不阻断审核）rows=%s: %s",
                    len(rows), exc, exc_info=True)
        _audit_failure("adjudication_ledger_write_failed", rows, f"{type(exc).__name__}: {exc}")
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "written": 0,
                "skipped": len(rows)}
    finally:
        if own:
            try:
                c.close()
            except Exception:
                logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)


def _audit_failure(action: str, rows: list, reason: str) -> None:
    payload = {"action": action, "reason": str(reason or "")[:500],
               "rows": len(rows or []),
               "run_ids": sorted({str((r or {}).get("run_id") or "")
                                  for r in (rows or [])})[:20],
               "switch": ENV_LEDGER}
    try:
        from .. import repositories as R
        R.audit_logs.log(actor="system", action="adjudication.ledger.write_failed",
                         object=(payload["run_ids"][0] if payload["run_ids"] else "adjudication_ledger"),
                         after=json.dumps(payload, ensure_ascii=False)[:1000])
    except Exception:  # 审计也失败：只能 warning（禁止静默仍留日志）
        LOG.warning("adjudication.ledger.write_failed 审计写入失败：%s", reason)


def emit_run(rows: list, *, run_id: str = "", case_id: str = "",
             manifest_id: str = "") -> dict:
    """run 末统一写（一次事务）+ 审计 ``adjudication.ledger.written``（1 条/run）。"""
    res = emit_rows(rows)
    if not res.get("ok"):
        return res
    rid = str(run_id or (res.get("run_ids") or [""])[0] or "")
    stats_counts = {"rows": len(rows or []), "written": int(res.get("written") or 0),
                    "skipped": int(res.get("skipped") or 0)}
    try:
        _rows = [r for r in (rows or []) if isinstance(r, dict)]
        adj = {}
        for r in _rows:
            adj[r.get("adjudicator") or "undecided"] = \
                adj.get(r.get("adjudicator") or "undecided", 0) + 1
        attributed = sum(v for k, v in adj.items() if k != "undecided")
        payload = {
            "schema": "adjudication_ledger.written/v1",
            "run_id": rid, "case_id": str(case_id or ""),
            "manifest_id": str(manifest_id or ""),
            "rows": len(_rows), "written": res.get("written"),
            "by_adjudicator": adj, "attributed": attributed,
            "unattributed": adj.get("undecided", 0),
            "model_calls_attributed": sum(int(r.get("model_calls") or 0) for r in _rows
                                          if r.get("model_calls_scope") in
                                          ("instance", "rule")),
            "coverage": (round(attributed / len(_rows), 6) if _rows else None),
            "write_ms": res.get("write_ms"),
        }
        from .. import repositories as R
        R.audit_logs.log(actor="system", action="adjudication.ledger.written",
                         object=rid or "adjudication_ledger",
                         after=json.dumps(payload, ensure_ascii=False)[:2000])
    except Exception:  # 审计失败只 warning；台账已写入
        LOG.warning("adjudication.ledger.written 审计写入失败 run=%s", rid, exc_info=True)
    res.update({"written": int(res.get("written") or 0),
                "rows": len(rows or []), "run_id": rid})
    return res


def append_human_decision(*, result_id: str, decision: str, reviewer: str = "",
                          role: str = "", reason: str = "") -> dict:
    """复核写点钩子（manifest_exec.decide 调用）：只记一条审计，不改台账行。

    append-only 约束下人工归因不落 UPDATE，而由 ``ledger_stats`` 读 ``manifest_review``
    投影（见模块 docstring）。本函数保证「复核动作在台账开关下显式可见」。
    """
    if not enabled():
        return {"ok": True, "skipped": "disabled"}
    try:
        from .. import repositories as R
        R.audit_logs.log(
            actor=reviewer or "system", action="adjudication.ledger.human_decision",
            object=str(result_id or ""),
            after=json.dumps({"result_id": result_id, "decision": decision,
                              "role": role or "", "reason": str(reason or "")[:200]},
                             ensure_ascii=False)[:1000])
        return {"ok": True}
    except Exception:
        LOG.warning("adjudication.ledger.human_decision 审计写入失败 result=%s",
                    result_id, exc_info=True)
        return {"ok": False}


# ================================================================ 路由计数
def route_counts(*, gate: dict, items=None, rules_mode: str = "") -> dict:
    """由冻结 gate 计算 89 号 §3.5 三列路由（映射 / 真实 / 路由出清单 / 差账）。

    口径（与离线复算一致，单位 = doc×rule 对）：
      * actual = 冻结清单 items 数；
      * routed_out = gate.routed_out 每条已记录 object_count 之和（映射阶段被排除的
        对象数；规则级排除且对象数未知的记入 unattributed_rules，不硬凑 0）；
      * mapped = binding.allowed_total + routed_out（mapped 模式：映射候选 = 允许对象
        + 已记录排除）；
      * builtin = binding.allowed_total（all 模式：内置常驻全集）；
      * unattributed = max(0, mapped + builtin − actual − routed_out)（必须 ≥0；
        当前产品在 BX 数据集曾差 36 个 doc×rule，故本函数不掩盖 >0）。
    纯函数：只读 gate，不修改。
    """
    gate = gate if isinstance(gate, dict) else {}
    routing = gate.get("routing") or {}
    binding = gate.get("binding") or {}
    allowed = int(binding.get("allowed_total") or 0)
    actual = len(items) if items is not None else int(gate.get("included_items") or 0)
    routed_entries = gate.get("routed_out") or []
    routed_pairs = 0
    unknown_rules = []
    reasons = {}
    for ro in routed_entries:
        code = str((ro or {}).get("code") or "")
        reason = str((ro or {}).get("reason") or "")
        reasons[reason] = reasons.get(reason, 0) + 1
        try:
            n = int((ro or {}).get("object_count") or 0)
        except (TypeError, ValueError):
            n = 0
        if n > 0:
            routed_pairs += n
        elif code:
            unknown_rules.append({"code": code, "reason": reason})
    mode = str(rules_mode or "").strip().lower()
    if mode not in ("mapped", "all"):
        mode = "mapped" if allowed else "all"
    if mode == "mapped":
        mapped = allowed + routed_pairs
        builtin = 0
    else:
        mapped = 0
        builtin = allowed
    unattributed = max(0, mapped + builtin - actual - routed_pairs)
    return {
        "schema": ROUTE_SCHEMA,
        "rules_mode": {"mapped": 1 if mode == "mapped" else 0,
                       "all": 1 if mode == "all" else 0},
        "mapped": mapped, "builtin": builtin, "actual": actual,
        "routed_out": routed_pairs,
        "unattributed": unattributed,
        "by_reason": reasons,
        "routed_out_rules": len(routed_entries),
        "unattributed_rules": unknown_rules[:100],
        "unattributed_rules_count": len(unknown_rules),
        "unit": "doc_rule_pair",
        "note": ("mapped/builtin/actual/routed_out/unattributed 单位=doc×rule 对；"
                 "规则级排除且未记录 object_count 的进 unattributed_rules（不硬凑 0）"),
    }


def snapshot_route(*, case_id: str, run_id: str, manifest_id: str,
                   gate: dict) -> dict:
    """冻结 gate 的路由三列落 sys_config（仅开关=1；供 stats/报告/快照复用）。"""
    if not enabled():
        return {"ok": True, "skipped": "disabled"}
    route = ((gate or {}).get("routing") or {}).get("adjudication_route")
    if not isinstance(route, dict):
        route = route_counts(gate=gate or {})
    payload = {"schema": ROUTE_SCHEMA, "run_id": str(run_id or ""),
               "case_id": str(case_id or ""), "manifest_id": str(manifest_id or ""),
               "generated_at": db.now(), "route": route}
    try:
        from . import sysconfig
        key = ROUTE_KEY_PREFIX + str(run_id or "")
        if not run_id or not sysconfig.get(key, ""):
            if run_id:
                sysconfig.set_many({key: json.dumps(payload, ensure_ascii=False)})
        return {"ok": True, "key": key if run_id else "", "route": route}
    except Exception:
        LOG.warning("adjudication_route 快照写入失败（不阻断审核）run=%s",
                    run_id, exc_info=True)
        return {"ok": False, "error": "snapshot_write_failed", "route": route}


def route_stats_for_runs(run_ids: list) -> dict:
    """聚合多个 run 的路由快照；同时用 audit_manifest.items_json 复算 actual 对账。"""
    from . import sysconfig
    out = {"schema": ROUTE_SCHEMA, "rules_mode": {"mapped": 0, "all": 0},
           "mapped": 0, "builtin": 0, "actual": 0, "routed_out": 0,
           "unattributed": 0, "by_reason": {}, "runs": len(run_ids or []),
           "unattributed_rules": [], "unattributed_rules_count": 0,
           "unit": "doc_rule_pair", "note": "", "actual_source": "audit_manifest.items_json"}
    if not run_ids:
        out["note"] = "no_run"
        return out
    missing_snapshot = []
    for rid in run_ids:
        raw = sysconfig.get(ROUTE_KEY_PREFIX + str(rid), "")
        if not raw:
            missing_snapshot.append(str(rid))
            continue
        try:
            payload = json.loads(raw)
        except ValueError:
            missing_snapshot.append(str(rid))
            continue
        route = payload.get("route") or {}
        for k in ("mapped", "builtin", "routed_out"):
            out[k] += int(route.get(k) or 0)
        for k, v in (route.get("by_reason") or {}).items():
            out["by_reason"][k] = out["by_reason"].get(k, 0) + int(v or 0)
        for m, flag in (route.get("rules_mode") or {}).items():
            if flag:
                out["rules_mode"][m] = out["rules_mode"].get(m, 0) + 1
        out["unattributed_rules_count"] += int(route.get("unattributed_rules_count") or 0)
        out["unattributed_rules"].extend(list(route.get("unattributed_rules") or [])[:20])
    # actual 以落库 manifest items 为准复算（快照与清单漂移必须可见）
    actual = 0
    try:
        with db.session() as c:
            for rid in run_ids:
                r = c.execute("SELECT manifest_id FROM audit_run WHERE id=?",
                              (str(rid),)).fetchone()
                mid = str((r["manifest_id"] if r else "") or "")
                if not mid:
                    continue
                mr = c.execute("SELECT items_json FROM audit_manifest WHERE id=?",
                               (mid,)).fetchone()
                if mr is not None:
                    try:
                        actual += len(json.loads(mr["items_json"] or "[]"))
                    except ValueError:
                        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    except Exception:
        LOG.warning("adjudication route actual 复算失败", exc_info=True)
    out["actual"] = actual
    out["unattributed"] = max(0, out["mapped"] + out["builtin"]
                              - out["actual"] - out["routed_out"])
    if missing_snapshot:
        out["note"] = ("missing_route_snapshot:%d" % len(missing_snapshot))
        out["missing_snapshot_runs"] = missing_snapshot[:20]
    out["unattributed_rules"] = out["unattributed_rules"][:100]
    return out


# ================================================================ 读 / 统计
def ledger_rows(*, run_id: str = "", case_id: str = "", limit: int = 200,
                offset: int = 0, run_ids: list = None) -> dict:
    """只读逐行台账（分页）。开关=0 返回 0 行 + disabled 标记（0 DDL/0 查询）。

    ``run_ids``：多 run 键（如 manifest 先执行后建 audit_run 时会落到 ``mid:<manifest>``
    兜底键，统计需同时覆盖同一清单的两个键，避免漏账/重账）。
    """
    if not enabled():
        return {"ok": True, "disabled": True, "total": 0, "rows": []}
    if not ensure_table():
        return {"ok": False, "error": "table_unavailable", "total": 0, "rows": []}
    where, args = [], []
    keys = [str(x) for x in (run_ids or []) if str(x or "")]
    if keys:
        where.append("run_id IN (%s)" % ",".join("?" * len(keys)))
        args.extend(keys)
    elif run_id:
        where.append("run_id=?")
        args.append(str(run_id))
    elif case_id:
        where.append("case_id=?")
        args.append(str(case_id))
    else:
        return {"ok": False, "error": "需要 run_id 或 case_id", "code": "invalid_request",
                "total": 0, "rows": []}
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    lim = max(1, min(int(limit or 200), 5000))
    off = max(0, int(offset or 0))
    try:
        with db.session() as c:
            total = c.execute("SELECT count(*) FROM adjudication_ledger" + clause,
                              tuple(args)).fetchone()[0]
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM adjudication_ledger" + clause +
                " ORDER BY object_id, rule_code, instance_index, id LIMIT ? OFFSET ?",
                tuple(args) + (lim, off)).fetchall()]
        return {"ok": True, "disabled": False, "total": int(total or 0),
                "limit": lim, "offset": off, "rows": rows}
    except Exception as exc:  # 铁律 2
        LOG.warning("adjudication_ledger 读取失败 run=%s case=%s", run_id, case_id,
                    exc_info=True)
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "total": 0,
                "rows": []}


def _wilson(k: int, n: int, z: float = 1.96) -> list:
    """Wilson 95% CI（n=0 → [None, None]；报告禁止无分母百分比）。"""
    if not n:
        return [None, None]
    p = k / n
    denom = 1.0 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return [round(max(0.0, centre - half), 6), round(min(1.0, centre + half), 6)]


def _sha256(payload) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def run_keys_for(case_id: str, run_id: str) -> tuple:
    """(审计 run_id, 统计用 run 键列表)。manifest 先执行后建 run 的兜底键 ``mid:<mid>``
    一并纳入，保证「同一冻结清单同一次执行」不漏账（run_id 为真实 audit_run.id）。"""
    rid = _resolve_run_id(case_id, run_id)
    keys = [rid] if rid else []
    if rid:
        try:
            with db.session() as c:
                r = c.execute("SELECT manifest_id FROM audit_run WHERE id=?",
                              (rid,)).fetchone()
            mid = str((r["manifest_id"] if r else "") or "")
        except Exception:
            mid = ""
        if mid:
            keys.append("mid:" + mid)
    return rid, keys


def _resolve_run_id(case_id: str, run_id: str) -> str:
    """默认 run：显式 run_id > case.last_run_id > 台账最新 run（报告口径）。"""
    if run_id:
        return str(run_id)
    if not case_id:
        return ""
    try:
        with db.session() as c:
            row = c.execute("SELECT last_run_id FROM audit_case WHERE id=?",
                            (str(case_id),)).fetchone()
            last = str((row["last_run_id"] if row else "") or "")
            if last:
                return last
            row2 = c.execute("SELECT run_id FROM adjudication_ledger WHERE case_id=? "
                             "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                             (str(case_id),)).fetchone()
            return str((row2["run_id"] if row2 else "") or "")
    except Exception:
        return ""


def _human_overlay(rows: list, run_ids: list) -> tuple:
    """人工复核 → 读时投影 human（append-only 台账不 UPDATE；见模块 docstring）。

    来源（均为 append-only 历史，取最新一条）：
      ① ``manifest_review``（manifest_exec.decide 子要求复核）；
      ② ``decision`` JOIN finding.manifest_result_id（finding 级复核，能映射到 result 的）。
    台账行本身的 ``human_decision`` 字段保留写入时值（正常为空），统计以本投影为准。
    """
    candidates = {}
    observed = 0
    adj_events = 0
    if not rows:
        return candidates, {"applied": 0, "observed_events": 0, "adjudication_events": 0}
    manifests = sorted({str(r.get("manifest_id") or "") for r in rows
                        if str(r.get("manifest_id") or "")})
    try:
        with db.session() as c:
            if manifests:
                q = ",".join("?" * len(manifests))
                reviews = c.execute(
                    "SELECT mr.result_id, mr.status, mr.reviewer, mr.created_at, "
                    "       mr.id AS review_id, m.item_key, m.manifest_id "
                    "FROM manifest_review mr JOIN manifest_result m ON m.id=mr.result_id "
                    "WHERE m.manifest_id IN (%s) "
                    "ORDER BY mr.created_at DESC, mr.rowid DESC" % q,
                    tuple(manifests)).fetchall()
                observed += len(reviews)
                for rv in reviews:
                    key = (str(rv["manifest_id"] or ""), str(rv["item_key"] or ""))
                    if key not in candidates:
                        candidates[key] = {
                            "decision": _normalize_human_decision(rv["status"]),
                            "decision_id": str(rv["review_id"] or ""),
                            "reviewer": str(rv["reviewer"] or ""),
                            "created_at": str(rv["created_at"] or ""),
                            "source": "manifest_review",
                        }
                # finding 级复核（decision 表）：映射到 manifest_result.item_key
                decs = c.execute(
                    "SELECT d.id AS decision_id, d.decision, d.user_id, d.created_at, "
                    "       m.item_key, m.manifest_id "
                    "FROM decision d JOIN finding f ON f.id=d.finding_id "
                    "JOIN manifest_result m ON m.id=f.manifest_result_id "
                    "WHERE m.manifest_id IN (%s) "
                    "ORDER BY d.created_at DESC, d.rowid DESC" % q,
                    tuple(manifests)).fetchall()
                observed += len(decs)
                for d in decs:
                    key = (str(d["manifest_id"] or ""), str(d["item_key"] or ""))
                    if key in candidates:
                        continue
                    candidates[key] = {
                        "decision": _normalize_human_decision(d["decision"]),
                        "decision_id": str(d["decision_id"] or ""),
                        "reviewer": str(d["user_id"] or ""),
                        "created_at": str(d["created_at"] or ""),
                        "source": "decision",
                    }
            if run_ids:
                adj_events = int(c.execute(
                    "SELECT count(*) FROM adjudication_event WHERE run_id IN (%s)"
                    % ",".join("?" * len(run_ids)),
                    tuple(str(x) for x in run_ids)).fetchone()[0] or 0)
    except Exception:
        LOG.warning("adjudication human overlay 读取失败（按无人工作业）", exc_info=True)
        return {}, {"applied": 0, "observed_events": 0, "adjudication_events": 0}
    applied = 0
    for row in rows:
        key = (str(row.get("manifest_id") or ""), str(row.get("item_key") or ""))
        hit = candidates.get(key)
        if not hit:
            continue
        if hit["decision"] in ("confirm", "reject", "need_evidence"):
            row["adjudicator"] = "human"
            row["undecided_reason"] = ""
            row["human_decision"] = hit["decision"]
            row["human_decision_id"] = hit["decision_id"]
            row["attribution_basis"] = "human_event"
            row["attribution_confidence"] = "high"
            applied += 1
    return candidates, {"applied": applied, "observed_events": observed,
                        "adjudication_events": adj_events}


def _normalize_human_decision(raw) -> str:
    """manifest_review.status / decision.decision → 89 号 §4.2 human_decision 枚举。"""
    v = str(raw or "").strip()
    return {"confirmed": "confirm", "confirm": "confirm",
            "false_positive": "reject", "reject": "reject",
            "need_evidence": "need_evidence",
            "rule_error": "rule_error", "ignored": "ignored",
            "rejected": "reject"}.get(v, "")


def _model_calls_overlay(rows: list, run_ids: list) -> dict:
    """llm_trace → 逐行模型调用归因（A5 守恒）：Σ行(instance/rule) + run 未归因 = trace 行数。"""
    traced = []
    if run_ids:
        try:
            with db.session() as c:
                q = ",".join("?" * len(run_ids))
                traced = [dict(r) for r in c.execute(
                    "SELECT id, run_id, model, point_ids FROM llm_trace "
                    "WHERE run_id IN (%s)" % q,
                    tuple(str(x) for x in run_ids)).fetchall()]
        except Exception:
            LOG.warning("adjudication model_calls 读取 llm_trace 失败", exc_info=True)
            traced = []
    # 行索引：point_id / rule_code / instance_id / item_key → row
    idx = {}
    for row in rows:
        for key in (str(row.get("rule_code") or ""),
                    str(row.get("instance_id") or ""),
                    str(row.get("item_key") or ""),
                    f"{row.get('object_id')}|{row.get('rule_code')}"):
            if key:
                idx.setdefault(key, []).append(row)
    attributed = 0
    for tr in traced:
        pids = []
        try:
            pids = json.loads(tr.get("point_ids") or "[]")
        except ValueError:
            pids = [str(tr.get("point_ids") or "")]
        hit_rows = []
        for pid in pids:
            hit_rows.extend(idx.get(str(pid), []))
        # A5 硬约束：一条 trace 只归因到 1 行 → Σ行 model_calls + run 未归因 == trace 数
        hit_rows = sorted({id(r): r for r in hit_rows}.values(),
                          key=lambda r: str(r.get("id") or ""))
        if hit_rows:
            row = hit_rows[0]
            row["model_calls"] = int(row.get("model_calls") or 0) + 1
            row["model_calls_scope"] = ("instance" if str(row.get("instance_id") or "")
                                        else "rule")
            mids = [str(tr.get("model") or "")]
            old = str(row.get("model_ids") or "")
            row["model_ids"] = ",".join(sorted({x for x in (old.split(",") if old else [])
                                                + mids if x}))
            attributed += 1
    run_unattributed = len(traced) - attributed
    # 无匹配行时保持 NULL（不可归因），不得伪造 0（§4.3）
    stats = {"trace_calls": len(traced), "attributed": attributed,
             "run_unattributed": run_unattributed,
             "conserved": (attributed + run_unattributed) == len(traced),
             "diff": len(traced) - attributed - run_unattributed,
             "run_unattributed_share": (round(run_unattributed / len(traced), 6)
                                        if traced else None),
             "attributed_rows": [
                 {"id": str(r.get("id") or ""), "rule_code": str(r.get("rule_code") or ""),
                  "instance_id": str(r.get("instance_id") or ""),
                  "model_calls": int(r.get("model_calls") or 0),
                  "model_calls_scope": str(r.get("model_calls_scope") or ""),
                  "model_ids": str(r.get("model_ids") or "")}
                 for r in rows if r.get("model_calls_scope") in ("instance", "rule")
             ][:200]}
    return stats


def _reconcile(rows: list, run_ids: list, case_id: str) -> dict:
    """台账 ↔ manifest_result / finding / point_state 对账（只读，差异显式）。"""
    out = {"manifest_results": 0, "manifest_results_missing_ledger": [],
           "findings": 0, "findings_covered": 0, "findings_missing_ledger": [],
           "note": "", "point_state_rows": 0, "point_state_rule_objects": 0}
    row_pairs = {(str(r.get("object_id") or ""), str(r.get("rule_code") or ""))
                 for r in rows}
    row_items = {str(r.get("item_key") or "") for r in rows}
    manifests = sorted({str(r.get("manifest_id") or "") for r in rows
                        if str(r.get("manifest_id") or "")})
    try:
        with db.session() as c:
            if manifests:
                q = ",".join("?" * len(manifests))
                mres = [dict(x) for x in c.execute(
                    "SELECT id, item_key FROM manifest_result "
                    "WHERE manifest_id IN (%s)" % q, tuple(manifests)).fetchall()]
                out["manifest_results"] = len(mres)
                miss = [x["id"] for x in mres if str(x["item_key"] or "") not in row_items]
                out["manifest_results_missing_ledger"] = miss[:50]
            fwhere, fargs = "", ()
            if run_ids:
                fwhere = " WHERE run_id IN (%s)" % ",".join("?" * len(run_ids))
                fargs = tuple(str(x) for x in run_ids)
            frows = [dict(x) for x in c.execute(
                "SELECT id, object_id, rule_id, run_id, state, status FROM finding"
                + fwhere, fargs).fetchall()]
            out["findings"] = len(frows)
            covered, missing = 0, []
            for f in frows:
                pair = (str(f.get("object_id") or ""), str(f.get("rule_id") or ""))
                if pair in row_pairs or f"{pair[0]}|{pair[1]}" in row_items:
                    covered += 1
                else:
                    missing.append(str(f.get("id") or ""))
            out["findings_covered"] = covered
            out["findings_missing_ledger"] = missing[:50]
            # point_state（LaneP 逐点五态）：按批次 run_id 对账（doc×rule 级）
            if run_ids:
                pwhere = " WHERE batch_id IN (%s)" % ",".join("?" * len(run_ids))
                prow = c.execute("SELECT count(*), count(DISTINCT file_id || '|' || point_id) "
                                 "FROM point_state" + pwhere,
                                 tuple(str(x) for x in run_ids)).fetchone()
                out["point_state_rows"] = int(prow[0] or 0) if prow else 0
                out["point_state_rule_objects"] = int(prow[1] or 0) if prow else 0
    except Exception:
        LOG.warning("adjudication 对账读取失败（统计按部分口径继续）", exc_info=True)
        out["note"] = "reconcile_partial"
    out["findings_missing_count"] = len(out["findings_missing_ledger"])
    out["manifest_results_missing_count"] = len(out["manifest_results_missing_ledger"])
    return out


def ledger_stats(*, case_id: str = "", run_id: str = "",
                 group_by: str = "", rows: list = None) -> dict:
    """唯一统计入口（报告 JSON / HTTP / CLI / 导出 / 快照共用；A7 同源）。

    统计前先断言：``Σ四类 == activated_instances``；不满足 → fail-closed 不出数
    （返回 ok=False + error，不产出可被误读的百分比）。
    """
    if strict_enabled() and not enabled():
        return {"ok": False, "schema": STATS_SCHEMA, "error": "invalid_switch_combo",
                "code": "invalid_switch_combo",
                "detail": "RULEPROOF_ADJUDICATION_LEDGER_STRICT=1 但 "
                          "RULEPROOF_ADJUDICATION_LEDGER=0（严格模式只在台账开启时有效）"}
    if not enabled():
        return {"ok": False, "disabled": True, "schema": STATS_SCHEMA,
                "error": "决策台账开关关闭（RULEPROOF_ADJUDICATION_LEDGER=0）",
                "code": "ledger_disabled"}
    if not ensure_table():
        return {"ok": False, "schema": STATS_SCHEMA, "error": "table_unavailable",
                "code": "table_unavailable"}
    rid, run_keys = run_keys_for(case_id, run_id)
    if not rid and not case_id:
        return {"ok": False, "schema": STATS_SCHEMA,
                "error": "需要 case_id 或 run_id", "code": "invalid_request"}
    if rows is None:
        if rid:
            raw = ledger_rows(run_ids=run_keys, limit=5000)
            rows = list(raw.get("rows") or [])
            # 分页兜底：超过 5000 行时继续取（统计必须全量）
            if int(raw.get("total") or 0) > len(rows):
                got = len(rows)
                while got < int(raw.get("total") or 0):
                    more = ledger_rows(run_ids=run_keys, limit=5000, offset=got)
                    batch = list(more.get("rows") or [])
                    if not batch:
                        break
                    rows.extend(batch)
                    got += len(batch)
        else:
            raw = ledger_rows(case_id=case_id, limit=5000)
            rows = list(raw.get("rows") or [])
            got = len(rows)
            while got < int(raw.get("total") or 0):
                more = ledger_rows(case_id=case_id, limit=5000, offset=got)
                batch = list(more.get("rows") or [])
                if not batch:
                    break
                rows.extend(batch)
                got += len(batch)
    # 缺 manifest_id 的旧行补 manifest_id（report 块按 item_key 对人工复核）
    _need = sorted({str(r.get("run_id") or "") for r in rows
                    if not str(r.get("manifest_id") or "") and str(r.get("run_id") or "")})
    if _need:
        try:
            _map = {}
            with db.session() as c:
                for _rid0 in _need:
                    mr = c.execute("SELECT manifest_id FROM audit_run WHERE id=?",
                                   (_rid0,)).fetchone()
                    if mr:
                        _map[_rid0] = str(mr["manifest_id"] or "")
            for r in rows:
                if not str(r.get("manifest_id") or ""):
                    r["manifest_id"] = _map.get(str(r.get("run_id") or ""), "")
        except Exception:
            LOG.warning("adjudication manifest_id 回填失败", exc_info=True)
    run_ids = sorted({str(r.get("run_id") or "") for r in rows if str(r.get("run_id") or "")})
    if not run_ids and rid:
        run_ids = [rid]
    # ---- 人工归因（读时投影）+ 模型调用归因（A5）
    _overlay, human_meta = _human_overlay(rows, run_ids)
    model_calls = _model_calls_overlay(rows, run_ids)
    # ---- 互斥统计
    pop = len(rows)
    by_adj = {k: 0 for k in ADJUDICATORS}
    by_state = {k: 0 for k in FINAL_STATES}
    by_undecided = {}
    by_abstain = {}
    recomputed = {"n_1": 0, "n_0": 0, "n_unknown": 0}
    extraction_known = extraction_model = extraction_unknown = extraction_none = 0
    scope_counts = {"instance": 0, "rule": 0, "document": 0}
    confidence_counts = {}
    for r in rows:
        adj = str(r.get("adjudicator") or "undecided")
        if adj not in by_adj:
            by_adj["undecided"] += 1
        else:
            by_adj[adj] += 1
        fs = str(r.get("final_state") or "unknown")
        by_state[fs] = by_state.get(fs, 0) + 1
        if adj == "undecided":
            ur = str(r.get("undecided_reason") or "")
            by_undecided[ur] = by_undecided.get(ur, 0) + 1
        if fs in ("insufficient", "execution_failed"):
            ac = str(r.get("abstain_reason") or "insufficient_not_recorded").split(":")[0]
            by_abstain[ac] = by_abstain.get(ac, 0) + 1
        rec = r.get("recomputed")
        if rec == 1:
            recomputed["n_1"] += 1
        elif rec == 0:
            recomputed["n_0"] += 1
        else:
            recomputed["n_unknown"] += 1
        es = str(r.get("extraction_source") or "unknown")
        if es == "model":
            extraction_model += 1
            extraction_known += 1
        elif es == "deterministic":
            extraction_known += 1
        elif es == "none":
            extraction_none += 1
        else:
            extraction_unknown += 1
        if str(r.get("instance_id") or ""):
            scope_counts["instance"] += 1
        elif str(r.get("manifest_id") or "") and str(r.get("route_status") or "") != "na_direct":
            scope_counts["rule"] += 1
        else:
            scope_counts["document"] += 1
        conf = str(r.get("attribution_confidence") or "low")
        confidence_counts[conf] = confidence_counts.get(conf, 0) + 1
    sum_adj = sum(by_adj.values())
    # ---- 路由
    routes = route_stats_for_runs(run_ids)
    if routes.get("runs", 0) and not routes.get("mapped") and not routes.get("builtin"):
        # 无快照：mapped 未知，actual 仍以清单复算为准（不伪造 mapped）
        routes["note"] = (routes.get("note") or "") + ";mapped_unavailable_no_snapshot"
    # ---- 对账
    reconcile = _reconcile(rows, run_ids, case_id)
    # ---- 不变量（A1–A5 机读）
    blackbox = sum(1 for r in rows
                   if str(r.get("final_state") or "") in TERMINAL_STATES
                   and str(r.get("adjudicator") or "") == "undecided"
                   and not str(r.get("undecided_reason") or ""))
    mv_without_program = sum(
        1 for r in rows if r.get("adjudicator") == "model_validated"
        and not (r.get("evidence_status") == "verified" and r.get("recomputed") == 1))
    insufficient_no_reason = sum(
        1 for r in rows if r.get("final_state") in ("insufficient", "execution_failed")
        and not str(r.get("abstain_reason") or ""))
    missing_basis = sum(1 for r in rows if not str(r.get("attribution_basis") or ""))
    missing_executor = sum(1 for r in rows
                           if str(r.get("undecided_reason") or "") == "missing_executor")
    invariant = {
        "sum_equals_population": sum_adj == pop,
        "sum_by_adjudicator": sum_adj,
        "blackbox_adjudicator": blackbox,
        "model_validated_without_program": mv_without_program,
        "insufficient_without_reason": insufficient_no_reason,
        "missing_attribution_basis": missing_basis,
        "missing_executor_rows": missing_executor,
        "model_calls_conserved": bool(model_calls.get("conserved")),
        "route_source_available": bool(routes.get("mapped") or routes.get("builtin")),
        "route_conserved": (
            bool(routes["mapped"] + routes["builtin"]
                 == routes["actual"] + routes["routed_out"]
                 + routes["unattributed"])
            if (routes.get("mapped") or routes.get("builtin")) else None),
        "coverage": (round((pop - by_adj["undecided"]) / pop, 6) if pop else None),
    }
    failures = []
    if not invariant["sum_equals_population"]:
        failures.append("sum_equals_population")
    if blackbox:
        failures.append("blackbox_adjudicator")
    if mv_without_program:
        failures.append("model_validated_without_program")
    if insufficient_no_reason:
        failures.append("insufficient_without_reason")
    if missing_basis:
        failures.append("missing_attribution_basis")
    if not invariant["model_calls_conserved"]:
        failures.append("model_calls_conserved")
    # 路由守恒只在「有快照可证」时判失败（无快照 = mapped 未知，显式 None，不伪造 0）
    if invariant["route_conserved"] is False:
        failures.append("route_conserved")
    strict = bool(strict_enabled())
    gate = {"mode": "blocking" if strict else "advisory", "strict": strict,
            "passed": not failures, "failures": failures,
            "blocking": bool(strict and failures),
            "note": ("STRICT=0：只告警不阻断报告签发；STRICT=1 时才作为 blocking 门禁"
                     if not strict else "STRICT=1：不变量失败将阻断正式报告（build49 末灰度）")}
    by_adj_list = []
    for k in ADJUDICATORS:
        n = by_adj[k]
        by_adj_list.append({"value": k, "n": n,
                            "share": (round(n / pop, 6) if pop else None),
                            "wilson95": _wilson(n, pop)})
    stats = {
        "ok": True, "schema": STATS_SCHEMA,
        "enabled": True, "run_id": rid, "case_id": str(case_id or ""),
        "case_scope": (not bool(run_id)),
        "run_ids": run_ids[:50],
        "generated_at": db.now(),
        "population": {"activated_instances": pop,
                       "attributed": pop - by_adj["undecided"],
                       "unattributed": by_adj["undecided"],
                       "by_instance_scope": scope_counts,
                       "attribution_confidence": confidence_counts},
        "by_adjudicator": by_adj_list,
        "by_final_state": by_state,
        "undecided_reasons": [{"value": k, "n": v}
                              for k, v in sorted(by_undecided.items(),
                                                 key=lambda x: -x[1])],
        "model_extraction": {"n_known": extraction_known,
                             "n_model": extraction_model,
                             "share": (round(extraction_model / extraction_known, 6)
                                       if extraction_known else None),
                             "unknown": extraction_unknown,
                             "none": extraction_none,
                             "note": "unknown 不进分母（不许把未知当 0 或当模型）"},
        "model_calls": model_calls,
        "abstain": {"n": sum(by_abstain.values()),
                    "top_reasons": [{"reason_code": k, "n": v}
                                    for k, v in sorted(by_abstain.items(),
                                                       key=lambda x: -x[1])]},
        "recomputed": recomputed,
        "routes": routes,
        "reconciliation": reconcile,
        "human_overlay": human_meta,
        "invariants": invariant,
        "gate": gate,
        "rows_sha256": _sha256([(r.get("id"), r.get("final_state"),
                                 r.get("adjudicator"), r.get("executor"),
                                 r.get("model_calls"), r.get("evidence_status"))
                                for r in rows]),
        "note": ("只统计本 run/本案例台账；未决≠弃权（弃权=有裁决者的结论）；"
                 "人工归因为读时投影（append-only 台账不 UPDATE）"),
    }
    # A7：统计可复算（同输入 sha256 相同；排除 generated_at）
    core = {k: v for k, v in stats.items() if k not in ("generated_at", "stats_sha256")}
    stats["stats_sha256"] = _sha256(core)
    stats["generated_at_epoch"] = int(datetime.now().timestamp())
    # 分组（可选）：adjudicator / document / rule_type；不支持的维度显式 not_available
    if group_by:
        groups = {}
        for dim in [x.strip() for x in str(group_by).split(",") if x.strip()]:
            if dim == "adjudicator":
                groups[dim] = [{"value": d["value"], "n": d["n"], "share": d["share"]}
                               for d in by_adj_list]
            elif dim == "document":
                acc = {}
                for r in rows:
                    k = str(r.get("object_id") or "")
                    acc[k] = acc.get(k, 0) + 1
                groups[dim] = [{"value": k, "n": v}
                               for k, v in sorted(acc.items(), key=lambda x: -x[1])][:200]
            elif dim == "rule_type":
                acc = {}
                for r in rows:
                    k = str(r.get("rule_code") or "").split("-")[0][:12] or "unknown"
                    acc[k] = acc.get(k, 0) + 1
                groups[dim] = [{"value": k, "n": v}
                               for k, v in sorted(acc.items(), key=lambda x: -x[1])][:200]
            else:
                groups[dim] = {"not_available": True,
                               "note": "该维度暂无落地字段（89 号 §6.1 group_by 子集）"}
        stats["groups"] = groups
    return stats


def stats_for_case(case_id: str) -> dict:
    """报告 JSON 块入口：开关=0 返回 None（报告逐字节回退）；失败 advisory 不抛。"""
    if not enabled():
        return None
    try:
        validate_switches()
        stats = ledger_stats(case_id=case_id)
        if not stats.get("ok"):
            return {"schema": STATS_SCHEMA, "enabled": True, "advisory_error": True,
                    "run_id": "", "error": stats.get("error") or "stats_unavailable",
                    "code": stats.get("code") or "stats_unavailable"}
        return stats
    except Exception as exc:  # 铁律 2：报告块失败只降级不阻断报告
        LOG.warning("adjudication_stats 报告块生成失败 case=%s: %s", case_id, exc,
                    exc_info=True)
        return {"schema": STATS_SCHEMA, "enabled": True, "advisory_error": True,
                "run_id": "", "error": f"{type(exc).__name__}: {exc}",
                "code": "stats_error"}


def rows_to_csv(rows: list) -> str:
    """逐行台账 → CSV 文本（HTTP format=csv 与 CLI/导出共用同一列序）。"""
    import csv as _csv
    import io as _io
    buf = _io.StringIO()
    w = _csv.DictWriter(buf, fieldnames=list(COLUMNS))
    w.writeheader()
    for row in rows or []:
        w.writerow({k: (row or {}).get(k) for k in COLUMNS})
    return buf.getvalue()


# ================================================================ 导出（CSV+stats+SHA256SUMS）
def export(*, case_id: str = "", run_id: str = "", out_dir: str = "",
           fmt: str = "csv", actor: str = "") -> dict:
    """导出逐行台账 + 统计 + SHA256SUMS（与报告导出同审计口径 report.exported）。"""
    if not enabled():
        return {"ok": False, "disabled": True, "code": "ledger_disabled",
                "error": "决策台账开关关闭（RULEPROOF_ADJUDICATION_LEDGER=0）"}
    if not out_dir:
        return {"ok": False, "code": "invalid_request", "error": "需要 out_dir"}
    rid = _resolve_run_id(case_id, run_id)
    data = ledger_rows(run_id=rid, case_id=(case_id if not rid else ""), limit=5000)
    if not data.get("ok"):
        return data
    all_rows = list(data.get("rows") or [])
    total = int(data.get("total") or 0)
    if total > len(all_rows):
        got = len(all_rows)
        while got < total:
            more = ledger_rows(run_id=rid, case_id=(case_id if not rid else ""),
                               limit=5000, offset=got)
            batch = list(more.get("rows") or [])
            if not batch:
                break
            all_rows.extend(batch)
            got += len(batch)
    stats = ledger_stats(case_id=case_id, run_id=rid)
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as exc:
        return {"ok": False, "code": "export_dir_failed",
                "error": f"{type(exc).__name__}: {exc}"}
    base = str(rid or case_id or "adjudication_ledger")
    paths = []
    if str(fmt or "csv").lower() == "json":
        p = os.path.join(out_dir, base + ".adjudication_ledger.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"schema": SCHEMA_VERSION, "run_id": rid,
                       "case_id": str(case_id or ""), "rows": all_rows},
                      f, ensure_ascii=False, indent=1)
        paths.append(p)
    else:
        p = os.path.join(out_dir, base + ".adjudication_ledger.csv")
        import csv as _csv
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = _csv.DictWriter(f, fieldnames=list(COLUMNS))
            w.writeheader()
            for row in all_rows:
                w.writerow({k: row.get(k) for k in COLUMNS})
        paths.append(p)
    sp = os.path.join(out_dir, base + ".adjudication_stats.json")
    with open(sp, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)
    paths.append(sp)
    # SHA256SUMS
    sums = []
    for path in paths:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        sums.append(f"{h.hexdigest()}  {os.path.basename(path)}")
    sump = os.path.join(out_dir, base + ".SHA256SUMS")
    with open(sump, "w", encoding="utf-8") as f:
        f.write("\n".join(sums) + "\n")
    paths.append(sump)
    res = {"ok": True, "run_id": rid, "case_id": str(case_id or ""),
           "rows": len(all_rows), "files": paths,
           "sha256": {os.path.basename(p): s.split("  ")[0]
                      for p, s in zip(paths, sums)},
           "stats_sha256": stats.get("stats_sha256")}
    # 审计：导出留痕（与 report.exported 同口径；失败只 warning）
    try:
        from .. import repositories as R
        R.audit_logs.log(actor=actor or "system", action="report.exported",
                         object=rid or str(case_id or ""),
                         after=json.dumps({"format": "adjudication_ledger_" + str(fmt),
                                           "rows": len(all_rows),
                                           "run_id": rid,
                                           "case_id": str(case_id or ""),
                                           "stats_sha256": stats.get("stats_sha256")},
                                          ensure_ascii=False)[:1000])
    except Exception:
        LOG.warning("adjudication_ledger export 审计写入失败 run=%s", rid, exc_info=True)
    return res


# ================================================================ 遗留通道对账补账
def reconcile_and_emit_findings(*, case_id: str, run_id: str,
                                tenant_id: str = "", workspace_id: str = "",
                                manifest_id: str = "") -> dict:
    """legacy/direct/fact-* 通道 finding → 低置信台账行（只补无 manifest 覆盖的）。

    只读 finding，不写 finding；幂等（唯一键含 finding id，重复调用跳过）。
    """
    if not enabled():
        return {"ok": True, "skipped": "disabled"}
    if not run_id:
        return {"ok": True, "skipped": "no_run"}
    try:
        if not ensure_table():
            return {"ok": False, "error": "table_unavailable"}
        with db.session() as c:
            existing = {(str(r["object_id"] or ""), str(r["rule_code"] or ""))
                        for r in c.execute(
                            "SELECT object_id, rule_code FROM adjudication_ledger "
                            "WHERE run_id=?", (str(run_id),)).fetchall()}
            frows = [dict(x) for x in c.execute(
                "SELECT * FROM finding WHERE run_id=? ORDER BY rowid", (str(run_id),)
            ).fetchall()]
        todo = []
        for f in frows:
            pair = (str(f.get("object_id") or ""), str(f.get("rule_id") or ""))
            if pair in existing:
                continue
            todo.append(row_for_finding(
                run_id=run_id, case_id=case_id, tenant_id=tenant_id,
                workspace_id=workspace_id, manifest_id=manifest_id, finding=f))
    except Exception as exc:  # 铁律 2：补账失败只 warning，不阻断审核
        LOG.warning("adjudication legacy 对账补账读取失败 run=%s: %s", run_id, exc,
                    exc_info=True)
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    if not todo:
        return {"ok": True, "written": 0, "rows": 0, "note": "no_legacy_findings"}
    res = emit_rows(todo)
    res.update({"legacy_rows": len(todo)})
    return res
