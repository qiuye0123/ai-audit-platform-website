"""Certificate Kernel 服务层（P2b advisory 接入：签发 / 落表 / 覆盖统计 / 报告门禁节 / 降级）。

与 `app/engine/certificate.py` 的分工：
  * kernel（纯函数）：证书 schema、canonical JSON/digest、9 类确定性 verifier、10 项 checks、
    独立 checker `verify_certificate`、门禁聚合 `gate_report`；
  * 本模块（服务层）：从 finding/文档/运行快照组装证书输入 → 签发 → 幂等落 `finding_certificate`
    → 覆盖统计（pass/fail/insufficient/missing/stale）→ 报告门禁节（advisory/blocking）
    → 唯一写点的降级执行（`enforce_certificates(persist=True)`，与 L4 证据门禁同模式）。

开关（默认关闭；关闭时与接入前逐字节一致）：
  * `RULEPROOF_CERTIFICATE_KERNEL`   默认 "0"：=0 不签发、不读表、不挂门禁；
  * `RULEPROOF_CERTIFICATE_REQUIRED` 默认 "0"：=0 advisory（只统计/告警，不改变报告 ok）；
    =1 blocking（无证书 / 证书 fail / insufficient / stale 的 fail finding 阻断签发）。
    非法组合 REQUIRED=1 + KERNEL=0 → `config_error()` 显式报
    `certificate_required_without_kernel`（不静默）。

签发钩子（写入点）：
  * `app/services/manifest_exec.py`：D5 裁决、`_save`/`_activate` 与 collect finding 物化之后
    调 `issue_for_result()`（只读 finding/证据，只写证书表，不改判定）；
  * `app/services/project.py::materialize_manifest_run`：manifest → finding 物化完成后
    调 `issue_for_manifest()`（覆盖非 collect 主链）；
  * 历史/测试入口：`issue_for_case(case_id, run_id=None)`。

诚实边界（与 71 号规格 §10 一致）：
  * 本 lane 只做 advisory；REQUIRED 默认 0，不改变报告输出；
  * 生产 food pack finding 当前没有 executor `recompute` 载荷 → 默认签**证据型证书**
    （`evidence_presence`: 只证明逐字引文/span 存在，不伪造数值复算通过）；
    有 `recompute` 载荷时（executor/未来 P2c）自动走对应确定性 verifier；
  * 证书 digest 不是签名：P2c 才加 hash-chain；
  * 多实例 partial：主实例复算/证据成立即签，失败实例单列 `partial_instances`，
    证书正文标注覆盖不完整（沿用 L70/L71 把 partial 计入可证书化的口径）。
"""
from __future__ import annotations

import hashlib
import json
import logging
import os

from .. import db
from .. import repositories as R
from ..engine import certificate as ck

log = logging.getLogger(__name__)

ENV_KERNEL = "RULEPROOF_CERTIFICATE_KERNEL"
ENV_REQUIRED = "RULEPROOF_CERTIFICATE_REQUIRED"
TABLE = "finding_certificate"
VERIFIER_VERSION = ck.VERIFIER_VERSION

_TRUTHY = ("1", "true", "yes", "on")
_FALSY = ("0", "false", "no", "off", "")

# inputs_digest 绑定的判定开关子集（全量会过度 stale；与 71 号规格 §6.2 白名单一致）
_SWITCH_WHITELIST = (
    # 只绑「判定口径」开关：门禁开关（KERNEL/REQUIRED）本身不进 digest，
    # 否则把 REQUIRED 从 0→1 会把全部证书判成 stale（自指）。
    "RULEPROOF_EVIDENCE_BACKFILL",
    "RULEPROOF_EVIDENCE_BACKFILL_REQUIRED",
    "RULEPROOF_EVIDENCE_CELL_EXACT_SHORT",
    "RULEPROOF_MULTI_INSTANCE",
    "RULEPROOF_EVIDENCE_CHECK",
)

_DOC_CACHE: dict = {}
_MAX_DOC_CACHE = 8

# 证书状态分类（存活口径，和 71 号规格 §5.1 reason code 一一对应）
CLS_PASS = "certified_pass"
CLS_MISSING = "missing"
CLS_FAILED = "cert_failed"
CLS_INSUFFICIENT = "cert_insufficient"
CLS_STALE = "stale"
CLS_INVALID = "invalid"

_REASON_BY_CLASS = {
    CLS_MISSING: "certificate_missing",
    CLS_FAILED: "certificate_failed",
    CLS_INSUFFICIENT: "certificate_insufficient",
    CLS_STALE: "certificate_stale",
    CLS_INVALID: "certificate_invalid",
}

_CLASS_DETAIL = {
    CLS_MISSING: "为 fail 但无证书，禁止签发",
    CLS_FAILED: "证书复算与 fail 结论矛盾，禁止签发并降级 insufficient",
    CLS_INSUFFICIENT: "证书证据不足（unknown→insufficient），需补证/人工复核",
    CLS_STALE: "证书 inputs_digest 与当前快照不一致（stale），需重签",
    CLS_INVALID: "证书 schema/摘要非法（fail-closed）",
}


# ================================================================ 开关
def _flag_value(raw) -> bool:
    return str(raw if raw is not None else "0").strip().lower() in _TRUTHY


def kernel_enabled() -> bool:
    """证书签发/读表/门禁总开关（默认 0 = 与接入前逐字节一致）。"""
    return _flag_value(os.environ.get("RULEPROOF_CERTIFICATE_KERNEL", "0"))


def required_enabled() -> bool:
    """报告门禁是否阻断（默认 0 = advisory 只统计/告警；=1 需 KERNEL=1）。"""
    return _flag_value(os.environ.get("RULEPROOF_CERTIFICATE_REQUIRED", "0"))


def config_error() -> str:
    """非法开关组合显式返回错误码（空串 = 合法）。"""
    if required_enabled() and not kernel_enabled():
        return "certificate_required_without_kernel"
    return ""


def _switch_values() -> dict:
    return {name: str(os.environ.get(name, "") or "") for name in _SWITCH_WHITELIST}


# ================================================================ 文档视图 / 运行上下文
def _document_row(case_id: str) -> dict:
    try:
        docs = R.cases.documents(case_id) or []
    except Exception:
        log.debug("certificate document lookup failed case=%s", case_id, exc_info=True)
        return {}
    for d in docs:
        path = str((d or {}).get("path") or "")
        if path and os.path.isfile(path):
            return dict(d)
    return dict(docs[0]) if docs else {}


def document_view(case_id: str):
    """case 的确定性原文视图（deepparse canonical text；按 path+mtime+size 缓存）。

    失败返回 None（调用方 fail-closed → 证书 insufficient，不伪造 pass）。
    """
    row = _document_row(case_id)
    path = str(row.get("path") or "")
    if not path or not os.path.isfile(path):
        return None
    try:
        st = os.stat(path)
        key = (os.path.abspath(path), int(st.st_mtime), int(st.st_size))
    except OSError:
        key = (os.path.abspath(path), 0, 0)
    cached = _DOC_CACHE.get(key)
    if cached is not None:
        return cached
    try:
        from ..engine import deepparse
        parsed = deepparse.parse_document(path)
        text = str(getattr(parsed, "text", "") or "")
    except Exception:
        log.warning("certificate document parse failed path=%s", path, exc_info=True)
        return None
    if not text:
        return None
    view = ck.document_from_text(text, profile="deepparse-canonical/v1",
                                 path_hint=os.path.relpath(path))
    if len(_DOC_CACHE) >= _MAX_DOC_CACHE:
        _DOC_CACHE.clear()
    _DOC_CACHE[key] = view
    return view


def _iso_time(raw) -> str:
    s = str(raw or "").strip()
    if not s:
        return ""
    if "T" in s:
        return s
    if len(s) == 19 and s[4] == "-" and s[13] == ":":
        return s.replace(" ", "T") + "+08:00"
    return s


def run_issued_at(case_id: str, run_id: str = "") -> str:
    """确定性签发时间：优先 run 的冻结 created_at（重签字节一致）；无 run 时返回空串。"""
    rid = str(run_id or "")
    try:
        c = db.connect()
        try:
            if rid:
                row = c.execute("SELECT created_at FROM audit_run WHERE id=?", (rid,)).fetchone()
            else:
                row = c.execute(
                    "SELECT created_at FROM audit_run WHERE case_id=? "
                    "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
        finally:
            c.close()
        if row:
            return _iso_time(row["created_at"] if isinstance(row, dict) else row[0])
    except Exception:
        log.debug("certificate issued_at lookup failed case=%s", case_id, exc_info=True)
    return ""


def _rule_version_sha(finding: dict) -> str:
    """规则已发布版本内容 sha；无内容指纹时用 (rule_code, version label) 派生（诚实标注）。"""
    raw = str(finding.get("rule_version_sha") or "").strip()
    if raw.startswith("sha256:"):
        return raw
    ver = str(finding.get("rule_version") or finding.get("rule_version_sha") or "").strip()
    code = str(finding.get("rule_id") or finding.get("rule_code") or "")
    return "sha256:" + hashlib.sha256(f"{code}:{ver or 'builtin'}".encode("utf-8")).hexdigest()[:32]


def build_inputs(case_id: str, run_id: str, finding: dict, view, issued_at: str) -> dict:
    """证书 inputs：优先复用 L53 快照字段；不可得时显式标 minimal_fallback（不伪造）。"""
    snapshot = {}
    try:
        from . import version_snapshot as _vs
        snap = _vs.load(case_id, str(run_id or "")) if case_id else {}
        if snap:
            cf = snap.get("content_fingerprint") or {}
            snapshot = {
                "schema_version": str(snap.get("schema_version") or snap.get("schema") or "run_snapshot_v2"),
                "content_fingerprint": (cf.get("sha256") if isinstance(cf, dict) else str(cf)) or "",
                "parser_version": str(snap.get("parser_version") or ""),
                "engine_mode": str(snap.get("engine_mode") or ""),
            }
    except Exception:
        log.debug("certificate snapshot reuse skipped case=%s", case_id, exc_info=True)
    if not snapshot:
        snapshot = {
            "schema_version": "run_snapshot_v3",
            "content_fingerprint": "sha256:" + (view.sha256 if view is not None else ""),
            "parser_version": str(finding.get("text_profile") or "deepparse-canonical/v1"),
            "engine_mode": "deterministic",
            "source": "minimal_fallback",
        }
    return {"snapshot": snapshot, "switch_values": _switch_values(),
            "issued_at": str(issued_at or "")}


def _finding_ref(finding: dict) -> dict:
    return {"finding_id": finding.get("id") or finding.get("finding_id") or "",
            "rule_code": finding.get("rule_id") or finding.get("rule_code") or "",
            "rule_version_sha": _rule_version_sha(finding),
            "severity": finding.get("severity") or "",
            "result_id": finding.get("manifest_result_id") or "",
            "manifest_id": finding.get("manifest_id") or ""}


def _finding_recompute(finding: dict):
    """读取 executor/复算载荷（只读；没有就返回 None → 走证据型证书）。"""
    for key in ("recompute", "recompute_json", "cert_recompute"):
        raw = finding.get(key)
        if raw:
            break
    else:
        return None
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return None
    if not isinstance(raw, dict):
        return None
    kind = str(raw.get("kind") or "")
    if kind not in ck.VERIFIERS:
        return None
    operands = raw.get("operands")
    if not isinstance(operands, dict):
        operands = {k: v for k, v in raw.items() if k != "kind"}
    return {"kind": kind, "operands": operands}


def _quote_of(finding: dict) -> str:
    """证据引文口径：只认 L71 回填的 verbatim_quote（摘要不得冒充逐字引文）。"""
    return str(finding.get("verbatim_quote") or "").strip()


def _anchor_span(finding: dict, quote: str):
    try:
        cs = int(finding.get("char_start", -1))
        ce = int(finding.get("char_end", -1))
    except (TypeError, ValueError):
        return None
    if cs < 0 or ce <= cs or not quote:
        return None
    return (cs, ce)


def _locator_of(finding: dict) -> str:
    ident = str(finding.get("issue_identity") or "")
    if ident:
        return ident
    return "finding:%s" % (finding.get("id") or "")


# ================================================================ 签发
def build_certificate(finding: dict, view, *, case_id: str = "", run_id: str = "",
                      issued_at: str = "", inputs: dict | None = None) -> dict:
    """为一条 fail finding 组装并签发证书（纯组装；不落库）。非 fail 返回 skipped 标记。"""
    state = str(finding.get("state") or "")
    if state != "fail":
        return {"skipped": True, "finding_id": finding.get("id") or "",
                "reason": "state_not_fail", "state": state}
    if view is None:
        # 文档不可得 → 仍签发 insufficient 证书（fail-closed：不伪造 pass/不静默跳过）
        view = ck.document_from_text("", profile="deepparse-canonical/v1")
    ref = _finding_ref(finding)
    quote = _quote_of(finding)
    span = _anchor_span(finding, quote)
    recompute = _finding_recompute(finding)
    if recompute is not None:
        verifier_kind = recompute["kind"]
        operands = recompute["operands"]
    else:
        # 本 lane 生产 finding 无 executor recompute 载荷 → 证据型证书（非伪造复算）
        verifier_kind = ck.EVIDENCE_CERT_KIND
        operands = {"required": [{"locator": _locator_of(finding), "quote": quote}]}
    if inputs is None:
        inputs = build_inputs(case_id, run_id, finding, view,
                              issued_at or run_issued_at(case_id, run_id))
    cert = ck.issue_certificate(
        ref, view, verifier_kind, operands, inputs=inputs, quote=quote,
        issued_at=str(issued_at or inputs.get("issued_at") or ""), anchor_span=span,
        context={"engine": "production-certificate-service"})
    # 生产元数据（在正文外只读附加，不参与 digest；落表有独立列）
    cert["_production"] = {
        "case_id": str(case_id or ""),
        "run_id": str(run_id or finding.get("run_id") or ""),
        "result_id": str(finding.get("manifest_result_id") or ""),
        "certificate_type": ("recompute" if recompute is not None else "evidence_only"),
        "backfill_status": str(finding.get("backfill_status") or ""),
        "anchor_strength": str(finding.get("anchor_strength") or ""),
        "partial_instances": _partial_instances(finding),
        "verifier_version": VERIFIER_VERSION,
    }
    return cert


def _partial_instances(finding: dict) -> list:
    """多实例部分回填：失败实例单列（不进入 source_refs、不拖累已证实例）。"""
    if str(finding.get("backfill_status") or "") != "multi_instance_partial":
        return []
    raw = finding.get("backfill_reason") or ""
    if not raw:
        return []
    try:
        parsed = json.loads(raw) if str(raw).strip().startswith(("{", "[")) else None
    except Exception:
        parsed = None
    if isinstance(parsed, list):
        return parsed
    return [str(raw)[:200]]


def _row_payload(cert: dict, *, case_id: str = "") -> dict:
    prod = cert.get("_production") or {}
    try:
        checks_json = json.dumps(cert.get("checks") or [], ensure_ascii=False,
                                 sort_keys=True, separators=(",", ":"))
        recompute_json = json.dumps(cert.get("recompute") or {}, ensure_ascii=False,
                                    sort_keys=True, separators=(",", ":"))
    except Exception:
        checks_json, recompute_json = "[]", "{}"
    return {
        "id": str(cert.get("certificate_id") or ""),
        "finding_id": str(cert.get("finding_id") or ""),
        "case_id": str(case_id or prod.get("case_id") or ""),
        "rule_code": str(cert.get("rule_code") or ""),
        "rule_version_sha": str(cert.get("rule_version_sha") or ""),
        "status": str(cert.get("status") or ""),
        "verifier_version": VERIFIER_VERSION,
        "verifier_kind": str((cert.get("verifier") or {}).get("kind") or ""),
        "quote": str(cert.get("quote") or ""),
        "char_start": int(cert.get("char_start", -1)),
        "char_end": int(cert.get("char_end", -1)),
        "recompute_json": recompute_json,
        "checks_json": checks_json,
        "inputs_digest": str(cert.get("inputs_digest") or ""),
        "issued_at": str(cert.get("issued_at") or ""),
        "digest": str(cert.get("digest") or ""),
        "certificate_type": str(prod.get("certificate_type") or ""),
        "result_id": str(prod.get("result_id") or ""),
        "certificate_json": ck.canonical_json(cert),
        "created_at": db.now(),
    }


_COLS = ("id", "finding_id", "case_id", "rule_code", "rule_version_sha", "status",
         "verifier_version", "verifier_kind", "quote", "char_start", "char_end",
         "recompute_json", "checks_json", "inputs_digest", "issued_at", "digest",
         "certificate_type", "result_id", "certificate_json", "created_at")


def save_certificate(cert: dict, *, case_id: str = "", persist: bool = True) -> dict:
    """幂等落表：UNIQUE(finding_id, verifier_version)；同输入重签 → 同一行、idempotent=True。"""
    payload = _row_payload(cert, case_id=case_id)
    if not persist:
        return {"saved": False, "idempotent": False, "row": payload}
    existing = load_by_finding(payload["finding_id"])
    idempotent = bool(existing) and str(existing.get("digest") or "") == payload["digest"] \
        and str(existing.get("verifier_version") or "") == payload["verifier_version"]
    c = db.connect()
    try:
        if existing and str(existing.get("verifier_version") or "") == payload["verifier_version"]:
            sets = ",".join(f"{k}=?" for k in _COLS if k != "created_at")
            c.execute(
                f"UPDATE {TABLE} SET {sets} WHERE finding_id=? AND verifier_version=?",
                [payload[k] for k in _COLS if k != "created_at"]
                + [payload["finding_id"], payload["verifier_version"]])
        else:
            ph = ",".join("?" * len(_COLS))
            c.execute(f"INSERT OR REPLACE INTO {TABLE} ({','.join(_COLS)}) VALUES ({ph})",
                      [payload[k] for k in _COLS])
        c.commit()
    finally:
        c.close()
    return {"saved": True, "idempotent": idempotent, "row": payload}


def _audit(action: str, finding_id: str, payload: dict) -> None:
    try:
        R.audit_logs.log(actor="system", action=action, object=str(finding_id or ""),
                         after=json.dumps(payload, ensure_ascii=False, default=str)[:400])
    except Exception:
        log.debug("certificate audit skipped finding=%s", finding_id, exc_info=True)


def issue_findings(findings, *, case_id: str = "", run_id: str = "",
                   persist: bool = True, view=None) -> dict:
    """对一批 finding 签发证书（只读 finding/证据；只写证书表 + 审计；不改判定）。"""
    if not kernel_enabled():
        return {"enabled": False, "issued": 0, "pass": 0, "insufficient": 0,
                "failed": 0, "skipped": 0, "errors": [], "items": []}
    findings = list(findings or [])
    if view is None and case_id:
        view = document_view(case_id)
    issued_at = run_issued_at(case_id, run_id) if case_id else ""
    out = {"enabled": True, "issued": 0, "pass": 0, "insufficient": 0, "failed": 0,
           "skipped": 0, "errors": [], "items": []}
    for finding in findings:
        fid = str((finding or {}).get("id") or "")
        try:
            cert = build_certificate(finding, view, case_id=case_id, run_id=run_id,
                                     inputs=(build_inputs(case_id, run_id, finding, view, issued_at)
                                             if view is not None else None))
            if cert.get("skipped"):
                out["skipped"] += 1
                continue
            saved = save_certificate(cert, case_id=case_id, persist=persist)
            status = str(cert.get("status") or "")
            out["issued"] += 1
            out["pass" if status == "pass" else
                ("failed" if status == "fail" else "insufficient")] += 1
            out["items"].append({
                "finding_id": fid, "rule_code": cert.get("rule_code") or "",
                "certificate_id": cert.get("certificate_id") or "",
                "status": status, "status_reason": cert.get("status_reason") or "",
                "certificate_type": (cert.get("_production") or {}).get("certificate_type"),
                "idempotent": bool(saved.get("idempotent")),
                "state": str(finding.get("state") or ""),
            })
            _audit("certificate.issued" if not saved.get("idempotent")
                   else "certificate.reissued",
                   fid, {"certificate_id": cert.get("certificate_id"),
                         "status": status, "status_reason": cert.get("status_reason"),
                         "verifier_version": VERIFIER_VERSION})
        except Exception as exc:  # 铁律 2：异常留痕，不静默、不阻断主链
            log.warning("certificate issue failed finding=%s", fid, exc_info=True)
            out["errors"].append({"finding_id": fid,
                                  "error": f"{type(exc).__name__}: {str(exc)[:200]}"})
    return out


def _case_run_id(case_id: str) -> str:
    try:
        case = R.cases.get(case_id) or {}
        return str(case.get("last_run_id") or "")
    except Exception:
        return ""


def issue_for_case(case_id: str, *, run_id: str = "", persist: bool = True,
                   findings=None) -> dict:
    """按项目签发（测试/历史数据回填入口；正式钩子见 issue_for_result/issue_for_manifest）。"""
    if not kernel_enabled():
        return {"enabled": False, "issued": 0, "pass": 0, "insufficient": 0,
                "failed": 0, "skipped": 0, "errors": [], "items": []}
    if findings is None:
        try:
            findings = R.findings.by_case(case_id)
        except Exception:
            findings = []
    rid = str(run_id or _case_run_id(case_id))
    out = issue_findings(findings, case_id=case_id, run_id=rid, persist=persist)
    _audit("certificate.issue_batch", case_id,
           {"run_id": rid, "issued": out["issued"], "pass": out["pass"],
            "insufficient": out["insufficient"], "failed": out["failed"],
            "errors": len(out["errors"])})
    return out


def _result_case_id(result_id: str) -> str:
    try:
        c = db.connect()
        try:
            row = c.execute(
                "SELECT m.case_id FROM manifest_result r "
                "JOIN audit_manifest m ON r.manifest_id=m.id WHERE r.id=?",
                (result_id,)).fetchone()
        finally:
            c.close()
        if row:
            return str(row["case_id"] if isinstance(row, dict) else row[0] or "")
    except Exception:
        log.debug("certificate result->case lookup failed result=%s", result_id, exc_info=True)
    return ""


def issue_for_result(result_id: str, *, case_id: str = "", persist: bool = True) -> dict:
    """D5 裁决后按 manifest_result 签发（manifest_exec 钩子：只读 finding/证据，不改判定）。"""
    if not kernel_enabled():
        return {"enabled": False, "issued": 0, "items": []}
    try:
        c = db.connect()
        try:
            rows = c.execute("SELECT * FROM finding WHERE manifest_result_id=?",
                             (result_id,)).fetchall()
        finally:
            c.close()
        findings = [dict(r) for r in rows]
    except Exception:
        log.warning("certificate issue_for_result query failed result=%s", result_id,
                    exc_info=True)
        return {"enabled": True, "issued": 0, "items": [], "errors": ["query_failed"]}
    cid = str(case_id or _result_case_id(result_id))
    return issue_findings(findings, case_id=cid, persist=persist)


def issue_for_manifest(case_id: str, manifest_id: str, *, persist: bool = True) -> dict:
    """manifest → finding 物化后按清单签发（project.materialize_manifest_run 钩子）。"""
    if not kernel_enabled():
        return {"enabled": False, "issued": 0, "items": []}
    findings = []
    try:
        c = db.connect()
        try:
            rows = c.execute(
                "SELECT f.* FROM finding f "
                "JOIN manifest_result mr ON f.manifest_result_id=mr.id "
                "WHERE mr.manifest_id=? AND f.state='fail'",
                (manifest_id,)).fetchall()
            run_row = c.execute(
                "SELECT id FROM audit_run WHERE manifest_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1", (manifest_id,)).fetchone()
        finally:
            c.close()
        findings = [dict(r) for r in rows]
        run_id = str((run_row["id"] if isinstance(run_row, dict) else run_row[0]) or "") \
            if run_row else ""
    except Exception:
        log.warning("certificate issue_for_manifest query failed manifest=%s",
                    manifest_id, exc_info=True)
        run_id = ""
    return issue_findings(findings, case_id=case_id, run_id=run_id, persist=persist)


# ================================================================ 读取 / 独立复核
def _row_to_cert(row: dict) -> dict:
    try:
        cert = json.loads(str((row or {}).get("certificate_json") or "{}"))
    except Exception:
        cert = {}
    return cert if isinstance(cert, dict) else {}


def load_by_finding(finding_id: str) -> dict:
    try:
        c = db.connect()
        try:
            row = c.execute(
                f"SELECT * FROM {TABLE} WHERE finding_id=? ORDER BY created_at DESC LIMIT 1",
                (str(finding_id or ""),)).fetchone()
        finally:
            c.close()
        return dict(row) if row else {}
    except Exception:
        log.debug("certificate load failed finding=%s", finding_id, exc_info=True)
        return {}


def load_certificates(finding_ids) -> dict:
    ids = [str(x) for x in (finding_ids or []) if str(x)]
    if not ids:
        return {}
    out = {}
    try:
        c = db.connect()
        try:
            ph = ",".join("?" * len(ids))
            for row in c.execute(
                    f"SELECT * FROM {TABLE} WHERE finding_id IN ({ph})", ids):
                d = dict(row)
                out[str(d.get("finding_id") or "")] = d
        finally:
            c.close()
    except Exception:
        log.debug("certificate bulk load failed", exc_info=True)
    return out


def all_certificates(case_id: str) -> list:
    try:
        c = db.connect()
        try:
            rows = c.execute(f"SELECT * FROM {TABLE} WHERE case_id=? ORDER BY rowid",
                             (str(case_id or ""),)).fetchall()
        finally:
            c.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


def current_inputs_for(cert: dict, finding: dict, view) -> dict | None:
    """构造“当前快照” inputs（沿用证书自己的 issued_at，使同 run 重算 digest 可比较）。"""
    if view is None:
        return None
    stored_inputs = dict((cert or {}).get("inputs") or {})
    issued_at = str(stored_inputs.get("issued_at") or cert.get("issued_at") or "")
    inputs = build_inputs(str((cert.get("_production") or {}).get("case_id") or ""),
                          str((cert.get("_production") or {}).get("run_id") or ""),
                          finding, view, issued_at)
    return inputs


def verify_stored(row: dict, finding: dict, view) -> dict:
    """独立复核一张已落库证书：digest/引文/span/source_refs/复算/输入绑定（含 stale）。"""
    cert = _row_to_cert(row)
    base = {"finding_id": str((row or {}).get("finding_id") or ""),
            "stored_status": str((row or {}).get("status") or ""),
            "valid": False, "usable": False, "status": "insufficient",
            "mismatches": [], "stale": False, "classification": CLS_INVALID,
            "certificate_id": str((row or {}).get("id") or ""),
            "verifier_kind": str((row or {}).get("verifier_kind") or "")}
    if view is None:
        base["mismatches"] = ["document_unavailable"]
        return base
    if not cert:
        base["mismatches"] = ["certificate_json_missing"]
        return base
    try:
        cur_inputs = current_inputs_for(cert, finding or {}, view)
        vr = ck.verify_certificate(cert, view, current_inputs=cur_inputs)
    except Exception as exc:  # 铁律 2
        log.warning("certificate independent verify failed finding=%s",
                    base["finding_id"], exc_info=True)
        base["mismatches"] = [f"verify_error:{type(exc).__name__}"]
        return base
    mismatches = list(vr.get("mismatches") or [])
    stale = "inputs_digest_mismatch" in mismatches
    base.update({"valid": bool(vr.get("valid")), "usable": bool(vr.get("usable")),
                 "status": str(vr.get("status") or ""),
                 "mismatches": mismatches, "stale": stale,
                 "checks": list(vr.get("checks") or [])})
    # 篡改类 mismatch（摘要/span/source_ref/status/schema）才判 invalid；
    # 合法的 insufficient 证书（引文缺失/证据不足，issuer 也标 insufficient）≠ 篡改。
    _integrity = [m for m in mismatches
                  if m in ("digest_mismatch", "span_tampered", "status_mismatch",
                           "schema_version_unsupported", "recompute_kind_mismatch",
                           "unknown_verifier", "empty_certificate")
                  or m.startswith("source_ref_")]
    if stale:
        base["classification"] = CLS_STALE
    elif _integrity or not vr.get("valid"):
        base["classification"] = CLS_INVALID
    elif str(vr.get("status") or "") == "pass":
        base["classification"] = CLS_PASS
    elif str(vr.get("status") or "") == "fail":
        base["classification"] = CLS_FAILED
    else:
        base["classification"] = CLS_INSUFFICIENT
    return base


# ================================================================ 覆盖统计 / 报告门禁节
def formal_fail_findings(findings) -> list:
    """正式口径 fail finding：排除 shadow/discarded(superseded)/false_positive（调用方已滤 shadow 时幂等）。"""
    out = []
    for f in (findings or []):
        if str((f or {}).get("state") or "") != "fail":
            continue
        if str((f or {}).get("status") or "") in ("false_positive", "superseded", "discarded"):
            continue
        out.append(f)
    return out


def coverage(case_id: str = "", *, findings=None, view=None, verify: bool = True) -> dict:
    """fail finding 证书覆盖：pass/missing/failed/insufficient/stale/invalid + 阻断清单。"""
    if findings is None:
        try:
            findings = R.findings.by_case(case_id)
        except Exception:
            findings = []
    fails = formal_fail_findings(findings)
    if view is None and case_id:
        view = document_view(case_id)
    certs = load_certificates([str(f.get("id") or "") for f in fails])
    stats = {"fail_total": len(fails), "certified_pass": 0, "missing": 0,
             "cert_failed": 0, "cert_insufficient": 0, "stale": 0, "invalid": 0,
             "non_fail_skipped": sum(1 for f in (findings or [])
                                     if str((f or {}).get("state") or "") != "fail")}
    items, blocked, accepted, downgraded = [], [], [], []
    for f in fails:
        fid = str(f.get("id") or "")
        rule = str(f.get("rule_id") or "")
        row = certs.get(fid)
        if not row:
            stats["missing"] += 1
            items.append({"finding_id": fid, "rule_code": rule, "classification": CLS_MISSING,
                          "reason": "certificate_missing"})
            blocked.append(fid)
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": "certificate_missing"})
            continue
        if verify:
            vr = verify_stored(row, f, view)
            cls = vr["classification"]
            item = {"finding_id": fid, "rule_code": rule,
                    "classification": cls, "cert_status": vr.get("stored_status"),
                    "recomputed_status": vr.get("status"),
                    "certificate_id": vr.get("certificate_id"),
                    "mismatches": vr.get("mismatches") or [],
                    "verifier_kind": vr.get("verifier_kind") or "",
                    "stale": vr.get("stale")}
        else:
            st = str(row.get("status") or "")
            cls = (CLS_PASS if st == "pass" else
                   (CLS_FAILED if st == "fail" else CLS_INSUFFICIENT))
            item = {"finding_id": fid, "rule_code": rule, "classification": cls,
                    "cert_status": st, "recomputed_status": st,
                    "certificate_id": str(row.get("id") or ""),
                    "mismatches": [], "verifier_kind": str(row.get("verifier_kind") or "")}
        stats[cls] = int(stats.get(cls) or 0) + 1
        item["reason"] = _REASON_BY_CLASS.get(cls, "")
        items.append(item)
        if cls == CLS_PASS:
            accepted.append(fid)
        else:
            blocked.append(fid)
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": _REASON_BY_CLASS.get(cls, cls)})
    stats["blocked"] = len(blocked)
    stats["advisory_only"] = not required_enabled()
    return {"stats": stats, "items": items, "blocked": blocked,
            "accepted": accepted, "downgraded": downgraded,
            "coverage_rate": (round(stats["certified_pass"] / stats["fail_total"], 4)
                              if stats["fail_total"] else 1.0)}


def gate_section(case_id: str, *, findings=None, view=None, required=None) -> dict:
    """报告门禁证书节（只读）：REQUIRED=0 只给 stats/warnings；=1 时 reasons 阻断。"""
    req = required_enabled() if required is None else bool(required)
    cov = coverage(case_id, findings=findings, view=view, verify=True)
    reasons, warnings = [], []
    for item in cov["items"]:
        cls = item["classification"]
        if cls == CLS_PASS:
            continue
        code = _REASON_BY_CLASS.get(cls, "certificate_invalid")
        detail = _CLASS_DETAIL.get(cls, "证书 schema/摘要非法（fail-closed）")
        msg = (f"[{code}] finding {item['finding_id']}（{item['rule_code']}）" + detail
               + (f"；mismatches={item['mismatches'][:3]}" if item.get("mismatches") else ""))
        (reasons if req else warnings).append(msg)
    return {"enabled": True, "required": req,
            "mode": "blocking" if req else "advisory",
            "ok": (not reasons) if req else True,
            "stats": cov["stats"], "coverage_rate": cov["coverage_rate"],
            "reasons": reasons, "warnings": warnings,
            "blocked": cov["blocked"], "accepted": cov["accepted"],
            "downgraded": cov["downgraded"],
            "items": cov["items"][:200],
            "config_error": config_error()}


# ================================================================ 降级（唯一写点）
def enforce_certificates(case_id: str, *, persist: bool = False, findings=None,
                         view=None) -> dict:
    """按门禁语义降级 fail→insufficient（唯一写点；默认只读预演 persist=False）。"""
    if not kernel_enabled():
        return {"enabled": False, "checked": 0, "downgraded": [], "persisted": False}
    cov = coverage(case_id, findings=findings, view=view, verify=True)
    downgrades = list(cov["downgraded"])
    applied = []
    if persist and downgrades:
        for d in downgrades:
            fid = str(d.get("finding_id") or "")
            row = None
            try:
                row = R.findings.get(fid)
            except Exception:
                row = None
            if not row or str(row.get("state") or "") != "fail":
                continue
            reason = str(d.get("reason") or "certificate_insufficient")
            summary = str(row.get("summary") or "")
            marker = f"（证书门禁：{reason}）"
            if marker not in summary:
                summary = (summary + marker) if summary else marker
            try:
                R.findings.update(fid, state="insufficient", status="need_evidence",
                                  summary=summary[:500])
                _audit("certificate.downgraded", fid,
                       {"from": "fail", "to": "insufficient", "reason": reason,
                        "case_id": str(case_id or "")})
                applied.append(d)
            except Exception:
                log.warning("certificate downgrade failed finding=%s", fid, exc_info=True)
                continue
        cov = coverage(case_id, findings=findings, view=view, verify=True)
    return {"enabled": True, "checked": int(cov["stats"]["fail_total"] + len(applied)),
            "downgraded": downgrades, "applied": applied,
            "persisted": bool(persist),
            "stats": cov["stats"]}


def summary(case_id: str, *, findings=None) -> dict:
    """报告/CLI 可用的证书摘要（只读；不改变门禁）。"""
    if not kernel_enabled():
        return {"enabled": False, "required": required_enabled()}
    cov = coverage(case_id, findings=findings)
    return {"enabled": True, "required": required_enabled(),
            "config_error": config_error(),
            "kernel_version": VERIFIER_VERSION, "schema_version": ck.SCHEMA_VERSION,
            **cov["stats"]}
