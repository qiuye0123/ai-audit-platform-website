# -*- coding: utf-8 -*-
"""双轨可见性策略：直连结果接受/拒绝 + 平台问题展示/隐藏 + 置信度校准门禁。

V3.2 口径修复版（Qoder W-01/W-02/W-04/W-06/W-07/W-08/W-09/W-19，2026-11-17）：
- **Phase 1 自动抑制结构性关闭**：PolicyConfig.auto_suppression 默认 False；
  calibration_gate(None) → auto_suppress_allowed=False（fail-closed）；
- normalized_ws 不再判 unverifiable → visible_weak_locator（可见弱定位）；
- risk 改 rule_version 静态声明，未声明默认 high，severity 只作 suggested；
- 反证必须逐字/可复算 + 输入来源，执行器名不算证据；
- 同一引文跨规则码复用 → visible_conflict/待核验（W-19）。

依据（按优先级）：
- docs/delivery/审核策略_v3.2_双评审修订_20261117.md（V3.2 修订，最高优先级）
- docs/delivery/V3评审逐条回应_Qoder_20261117.md（W-01…W-19 逐条回应）
- docs/delivery/直连与平台可见性策略_20261117.md（判定顺序与决策表，操作口径）
- docs/delivery/置信图与分层裁决_20261117.md（抑制台账/分层/校准，原则）
- docs/delivery/双轨直连草稿与交叉复核_20261117.md（直连是基线不是真值）

本模块是**纯策略函数**（不落库、不读展示态），把“某条候选该不该给审核员看”拆成
可单独测试的决策分支，同时提供 confidence_calibration 表的读写与校准门禁：

直连判定顺序（顺序不能反）：
    D0 权限/范围 → D1 证据可核验 → D2 重复合并 → D3 确定性反证 → D4 风险 → D5 置信度排序
平台判定顺序：
    P0 范围 → P1 证据契约 → P2 重复 → P3 确定性反证/冲突 → P4 来源类型 → P5 风险 → P6 置信度

硬性策略（测试逐条覆盖）：
1. Phase 1 不自动隐藏任何 in-scope 候选（auto_suppression=OFF）：
   不可核验 → visible_need_evidence（可见、待补证，不判误报）；
2. critical/高风险永不自动隐藏（最多展示为冲突/待核验）；
3. 低置信度**不单独**构成隐藏理由（只做排序/标注）；
4. 隐藏必须可恢复，且 recover 必须同步 comparison_item.visibility=visible（W-08）；
5. 任何自动抑制都必须：显式 auto_suppression=True + 显式校准样本>=阈值 + 独立裁定；
   未传 calibration 一律 fail-closed（W-06）；
6. 反证必须是逐字引文或可复算计算轨迹 + 输入来源；执行器名/标签不算证据（W-07）；
7. scope 优先于桶：scope_status != in_scope → rejected_scope，任何桶不得覆盖（W-09）；
8. 直连不是 gold：接受展示 ≠ 确认成立，任何自动结果都不写人工结论。

## T-202 唯一主链与唯一入口（2026-11-20）
本模块是双轨主链的**第 3 步：仅策略**——只把“证据/反证/风险/校准”拆成可测试分支，
输出**策略决策**；它不再自己决定分区（formal/shadow/discarded 由
:mod:`app.services.shadow_pool` 唯一仲裁），也不落库可见性。产品代码只能经
``app.services.dual_track_gateway.resolve_visibility``（等）调用本模块；职责边界见
``docs/qa/双轨唯一入口约束_20261120.md``。
"""
from __future__ import annotations

import datetime as _dt
import json
import uuid
from dataclasses import dataclass

from ..severity import normalize as sev_normalize

# V3.2 口径修复：策略版本变化（旧回放 visibility/v1 不作为 V3.2 结论引用）
POLICY_VERSION = "visibility/v2"

# --------------------------------------------------------------------------- 词表
RISK_LEVELS = ("critical", "high", "medium", "low")
RISK_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

# W-02：quote 匹配状态独立记录（exact / exact_after_trim / normalized_ws / not_found）
QUOTE_MATCH_STATUSES = ("exact", "exact_after_trim", "normalized_ws", "not_found")
VERBATIM_QUOTE_STATUSES = ("exact", "exact_after_trim")
WEAK_LOCATOR_QUOTE_STATUSES = ("normalized_ws",)
EVIDENCE_KINDS = ("quote", "missing", "calculation", "relation", "human")

# Phase 1：自动抑制结构性关闭（任何默认路径都不得自动隐藏 in-scope 候选）
PHASE1_AUTO_SUPPRESSION = False

# 文档 §6 原因码 + 本实现补充的内部原因码（都是可查询字符串，只增不改）
REASON_CODES = {
    # 拒绝 / 隐藏（不可核验类）
    "rejected_scope": "超出授权对象/租户/规则范围，硬拒绝（不入抑制台账）",
    "rejected_security": "安全边界拒绝（越权/注入/不可信来源）",
    "unverifiable_quote": "引文不能逐字命中，不可核验",
    "unverifiable_computation": "计算/复算证据不成立",
    "unverifiable_relation": "关系/锚点证据不成立",
    "missing_locator": "缺少可定位锚点/坐标",
    "duplicate": "与已有问题重复，合并（不是删除）",
    "deterministic_refuted": "被确定性执行器/逐字证据明确反证（非高风险 → 抑制台账）",
    "low_evidence_noncritical": "低证据强度且非高风险（仅在不可核验时进台账；置信度本身不单独隐藏）",
    # 展示（含高风险例外）
    "evidence_verified": "证据逐字/可复算/可回放，接受展示",
    "evidence_verified_weak_locator": "引文空白归一后命中（normalized_ws）：可核验但标弱定位",
    "low_confidence_visible": "低置信但证据可核验，仍展示并标注低置信",
    "visible_weak_locator": "normalized_ws 弱定位：可见、标弱定位，不判不可核验（W-02）",
    "visible_need_evidence": "不可核验/无定位但 Phase 1 不自动隐藏：可见、待补证，不判误报",
    "visible_lead_highrisk": "不可核验但 critical/高风险 → 展示为线索/待核验",
    "conflict_requires_human": "两边结论/证据冲突，强制人工裁决",
    "quote_reuse_conflict": "同一引文被多个规则码复用（同引文跨码）→ conflict/待核验，逐字命中不等于成立（W-19）",
    "quote_issue_unrelated": "引文与问题/规则判据无相关性线索，逐字命中不足以支撑结论（W-19 相关性校验）",
    "platform_only_visible": "平台独有且证据可核验，必须展示（平台增量能力证据）",
    "visible_deterministic": "确定性执行器 fail + 逐字证据/可复算",
    "visible_semantic": "语义 fail + 逐字证据",
    "visible_highrisk": "critical/高风险，必须展示",
    # 反证/抑制门禁
    "critical_conflict_visible": "被反证但 critical/高风险，展示为冲突，不得自动隐藏",
    "high_risk_refute_conflict": "被反证但高风险，展示为冲突",
    "refute_unverified": "反证本身不可核验（无逐字/无复算/无输入来源），不作为隐藏依据，展示为冲突",
    "suppression_disabled": "Phase 1 自动抑制关闭，不可核验/被反证项展示为待核验/冲突交人工（W-06）",
    "suppression_gated_by_calibration": "未提供/样本不足/可靠性不够的校准 → 禁止自动抑制（fail-closed）",
}

HIDDEN_REASON_CODES = ("unverifiable_quote", "unverifiable_computation",
                       "unverifiable_relation", "missing_locator",
                       "deterministic_refuted", "low_evidence_noncritical")
REJECTED_REASON_CODES = ("rejected_scope", "rejected_security")
DUPLICATE_REASON_CODES = ("duplicate",)

# 状态：每个状态明确 是否展示 / 是否进抑制台账 / 是否必须人工
DIRECT_STATUSES = {
    "accepted_visible": {"visible": True, "ledger": False},
    "accepted_visible_lowconf": {"visible": True, "ledger": False},
    "visible_weak_locator": {"visible": True, "ledger": False},
    "visible_need_evidence": {"visible": True, "ledger": False},
    "visible_conflict": {"visible": True, "ledger": False},
    "visible_lead_highrisk": {"visible": True, "ledger": False},
    "duplicate": {"visible": False, "ledger": False},
    "suppressed_refuted": {"visible": False, "ledger": True},
    "suppressed_unverifiable": {"visible": False, "ledger": True},
    "unverifiable": {"visible": False, "ledger": True},
    "rejected_scope": {"visible": False, "ledger": False},
}
PLATFORM_STATUSES = {
    "visible_deterministic": {"visible": True, "ledger": False},
    "visible_semantic": {"visible": True, "ledger": False},
    "visible_platform_only": {"visible": True, "ledger": False},
    "visible_conflict": {"visible": True, "ledger": False},
    "visible_lowconf": {"visible": True, "ledger": False},
    "visible_need_evidence": {"visible": True, "ledger": False},
    "visible_weak_locator": {"visible": True, "ledger": False},
    "visible_highrisk": {"visible": True, "ledger": False},
    "duplicate": {"visible": False, "ledger": False},
    "suppressed_refuted": {"visible": False, "ledger": True},
    "suppressed_unverifiable": {"visible": False, "ledger": True},
    "rejected_scope": {"visible": False, "ledger": False},
}
VISIBLE_STATUSES = tuple(s for s, v in {**DIRECT_STATUSES, **PLATFORM_STATUSES}.items()
                         if v["visible"])
HIDDEN_STATUSES = tuple(s for s, v in {**DIRECT_STATUSES, **PLATFORM_STATUSES}.items()
                        if v["ledger"])

# W-04：旧关键词表**不再参与 risk 计算**（保留常量只为兼容既有 import；
# 历史上它把“资格→资质”一个字映射成 medium→high，Qoder W-04 已证伪）。
_HIGH_RISK_KEYWORDS = ("金额", "法务", "底线", "版本", "替代", "资质", "安全")
_RULE_RISK_META_FIELDS = ("rule_version_meta", "rule_meta", "rule_risk_meta")
LOW_RISK_SEVERITIES = ("info", "suspected")

# 校准阈值（预注册；改阈值需新政策版本）
CONFIRM_MIN_RELIABILITY = 0.90
SUPPRESS_REFUTE_MIN_RELIABILITY = 0.90
DEFAULT_MIN_CALIBRATION_SAMPLES = 30
DEFAULT_LOW_CONFIDENCE_THRESHOLD = 0.5


@dataclass(frozen=True)
class PolicyConfig:
    """策略配置（冻结；不同阈值 = 不同策略版本，便于回放）。

    auto_suppression 默认 False（V3.2 Phase 1 自动抑制结构性关闭）；
    只有离线实验/未来阶段显式开启且带有效校准样本时才允许自动抑制。
    """
    auto_suppression: bool = PHASE1_AUTO_SUPPRESSION
    quote_reuse_conflict: bool = True
    low_confidence_threshold: float = DEFAULT_LOW_CONFIDENCE_THRESHOLD
    min_calibration_samples: int = DEFAULT_MIN_CALIBRATION_SAMPLES
    version: str = POLICY_VERSION

    def as_dict(self) -> dict:
        return {"version": self.version, "auto_suppression": self.auto_suppression,
                "phase": "phase1_auto_suppression_off" if not self.auto_suppression else "auto",
                "quote_reuse_conflict": self.quote_reuse_conflict,
                "low_confidence_threshold": self.low_confidence_threshold,
                "min_calibration_samples": self.min_calibration_samples,
                "confirm_min_reliability": CONFIRM_MIN_RELIABILITY,
                "suppress_refute_min_reliability": SUPPRESS_REFUTE_MIN_RELIABILITY}


# --------------------------------------------------------------------------- 风险 / 证据
def declared_risk(candidate: dict) -> dict:
    """从候选携带的 rule_version 静态声明 / 人工覆盖读取风险等级（W-04，Alt-C）。

    取值优先级：
    1. ``risk_level``：调用方显式传入的规则级声明/人工覆盖（最优先）；
    2. ``rule_risk_level`` / ``declared_risk_level``：规则级静态声明；
    3. ``rule_version_meta`` / ``rule_meta`` / ``rule_risk_meta`` 内的 risk_level；
    4. 未声明 → 默认 high（保守；不得再按关键词/模型 severity 推导）。
    """
    declared, source = "", ""
    explicit = str(candidate.get("risk_level") or "").strip().lower()
    if explicit in RISK_LEVELS:
        declared, source = explicit, "explicit_override"
    if not declared:
        for field in ("rule_risk_level", "declared_risk_level"):
            val = str(candidate.get(field) or "").strip().lower()
            if val in RISK_LEVELS:
                declared, source = val, "rule_version_declared"
                break
    if not declared:
        for field in _RULE_RISK_META_FIELDS:
            meta = candidate.get(field)
            if isinstance(meta, dict):
                val = str(meta.get("risk_level") or "").strip().lower()
                if val in RISK_LEVELS:
                    declared, source = val, "rule_version_declared"
                    break
    rule_version = candidate.get("rule_version")
    if not declared and isinstance(rule_version, dict):
        val = str(rule_version.get("risk_level") or "").strip().lower()
        if val in RISK_LEVELS:
            declared, source = val, "rule_version_declared"
    return {"declared": bool(declared), "risk_level": declared, "source": source}


def resolve_risk(candidate: dict) -> dict:
    """候选风险等级（W-04，Alt-C）：规则级静态声明优先，未声明默认 high。

    - **不再**用关键词表推导 high，**不再**用模型自报 severity 决定 critical；
    - 模型 severity 只作为 ``suggested_severity`` 展示/排序，不进入 risk；
    - 人工可覆盖（显式 risk_level 视为人工/规则声明）。
    """
    sev = sev_normalize(str(candidate.get("severity") or ""))
    declared = declared_risk(candidate)
    if declared["declared"]:
        level = declared["risk_level"]
        why = declared["source"]
    else:
        level, why = "high", "default_high_undeclared"
    return {"risk_level": level, "derived_from": why, "declared": declared["declared"],
            "high_risk": level in ("critical", "high"),
            "suggested_severity": (sev or None),
            "note": (None if declared["declared"] else
                     "rule_version 未静态声明 risk_level → 默认 high（不得由关键词/模型 severity 决定）")}


def is_high_risk(candidate: dict) -> bool:
    return resolve_risk(candidate)["high_risk"]


def quote_match_status_of(qc: dict | None) -> str:
    """quote_check → V3.2 四态 quote_match_status（exact/exact_after_trim/normalized_ws/not_found）。"""
    qc = qc or {}
    explicit = str(qc.get("quote_match_status") or "").strip()
    if explicit in QUOTE_MATCH_STATUSES:
        return explicit
    status = str(qc.get("status") or "").strip()
    if status in VERBATIM_QUOTE_STATUSES:
        return status
    if status in WEAK_LOCATOR_QUOTE_STATUSES:
        return "normalized_ws"
    return "not_found"


def evidence_state(candidate: dict) -> dict:
    """证据契约判定：逐字/可复算/可回放 + 可定位，不依赖模型自报置信度。

    W-02：normalized_ws **不再判 unverifiable**——空白归一是弱定位（可核验但非逐字），
    要求已回写真实 offset/line；无法回写坐标 → 按待补证（visible_need_evidence）处理。
    """
    kind = str(candidate.get("evidence_kind") or "quote")
    qc = candidate.get("quote_check") or {}
    qms = quote_match_status_of(qc)
    explicit = candidate.get("evidence_verified")
    weak_locator = False
    if explicit is not None:
        verified = bool(explicit)
        src = "explicit"
    elif kind == "quote":
        if qms in VERBATIM_QUOTE_STATUSES:
            verified, src = True, "quote_check"
        elif qms == "normalized_ws":
            # 弱定位：可核验但非逐字；坐标必须由 locate_quote 回写
            has_coord = (qc.get("offset") is not None and qc.get("line") is not None)
            verified, src = bool(has_coord), ("quote_check_normalized_ws" if has_coord
                                              else "quote_check_normalized_ws_no_coord")
            weak_locator = bool(has_coord)
        else:
            verified, src = False, "quote_check"
    elif kind == "missing":
        verified = bool(candidate.get("missing_proof_verified"))
        src = "missing_proof"
    elif kind == "calculation":
        verified = bool(candidate.get("computation_verified"))
        src = "computation"
    elif kind == "relation":
        verified = bool(candidate.get("relation_verified"))
        src = "relation"
    elif kind == "human":
        verified = True
        src = "human"
    else:
        verified = False
        src = "unknown_kind"
    locator = candidate.get("locator_present")
    if locator is None:
        locator = bool(qc.get("offset") is not None or qc.get("line") is not None
                       or candidate.get("anchor_ids") or candidate.get("locator")
                       or candidate.get("location_hint")
                       or (verified and kind != "quote"))
    locator = bool(locator)
    if not verified:
        if qms == "normalized_ws":
            # 空白归一但坐标未回写 → 不判不可核验，按待补证（可见）
            code = "unverifiable_quote"
        else:
            code = {"quote": "unverifiable_quote",
                    "calculation": "unverifiable_computation",
                    "relation": "unverifiable_relation",
                    "missing": "missing_locator"}.get(kind, "missing_locator")
    elif not locator:
        code = "missing_locator"
    elif weak_locator:
        code = "evidence_verified_weak_locator"
    else:
        code = "evidence_verified"
    return {"kind": kind, "verified": verified and locator, "evidence_src": src,
            "quote_status": str(qc.get("status") or ""), "quote_match_status": qms,
            "weak_locator": bool(weak_locator and verified and locator),
            "offset": qc.get("offset"), "line": qc.get("line"),
            "locator_present": locator, "reason_code": code}


def refutation_state(candidate: dict) -> dict:
    """反证是否可核验（W-07）：反证必须有逐字引文/可复算轨迹 + 输入来源。

    - **执行器名/标签不算证据**（旧实现只要 ``deterministic_executor`` 非空就采信）；
    - 计算类反证必须同时有 computation_verified + 计算轨迹 + 输入来源；
    - 调用方自报 ``refute_verified`` 只作留档，不作为验证依据（由本校验器判定）。
    """
    if not candidate.get("deterministic_refuted"):
        return {"attempted": False, "verified": False}
    ref = dict(candidate.get("refute_evidence") or {})
    rqc = ref.get("quote_check") or {}
    qstatus = str(rqc.get("status") or "")
    quote_text = str(ref.get("quote") or "").strip()
    quote_verbatim = bool(quote_text) and qstatus in VERBATIM_QUOTE_STATUSES
    computation_verified = bool(ref.get("computation_verified"))
    computation_trace = ref.get("computation_trace") or ref.get("computation") or ref.get("steps")
    input_source = ref.get("input_source") or ref.get("input_ref") or ref.get("inputs")
    computation_ok = bool(computation_verified and computation_trace and input_source)
    executor = str(ref.get("deterministic_executor") or candidate.get("deterministic_executor")
                   or "")
    evidence_version = str(ref.get("evidence_version") or ref.get("rule_version")
                           or candidate.get("rule_version") or "")
    if quote_verbatim:
        evidence_type = "verbatim_quote"
    elif computation_ok:
        evidence_type = "recomputable_computation"
    else:
        evidence_type = ""
    verified = bool(evidence_type)
    unverified_reason = ""
    if not verified:
        if executor and not quote_verbatim and not computation_ok:
            unverified_reason = "executor_name_is_not_evidence"
        elif computation_verified and not (computation_trace and input_source):
            unverified_reason = "computation_missing_trace_or_input_source"
        elif not quote_verbatim:
            unverified_reason = "missing_verbatim_quote_or_computation"
    return {"attempted": True, "verified": verified, "evidence_type": evidence_type,
            "evidence_version": evidence_version, "input_source": input_source,
            "computation_trace_present": bool(computation_trace),
            "executor_metadata": executor,   # 仅元数据，不参与验证
            "claimed_refute_verified": candidate.get("refute_verified"),
            "unverified_reason": unverified_reason,
            "evidence": ref, "refuter": candidate.get("refuter") or "platform"}



def is_low_confidence(candidate: dict, policy: PolicyConfig) -> bool:
    conf = candidate.get("confidence")
    try:
        return conf is not None and float(conf) < float(policy.low_confidence_threshold)
    except (TypeError, ValueError):
        return False


# --------------------------------------------------------------------------- 校准门禁
def calibration_gate(calibration: dict | None, policy: PolicyConfig | None = None) -> dict:
    """校准门禁（W-06，fail-closed）：未提供/样本不足/可靠性不够 → 不允许自动抑制。

    calibration 形如 {"n_samples": 40, "min_samples": 30, "reliability": 0.95,
                      "auto_suppress_allowed": True}（通常来自 calibration_gate_for）。
    **未传 calibration（None/空）→ auto_suppress_allowed=False**：
    冷启动/离线阶段不得默认允许自动抑制（V3.2 §9.3：只有显式校准 + 样本>=阈值
    + 独立裁定 → 才允许自动抑制）。
    """
    policy = policy or PolicyConfig()
    if not calibration:
        return {"provided": False, "n_samples": None, "min_samples": policy.min_calibration_samples,
                "sufficient": False, "reliability": None, "reliability_ok": False,
                "auto_suppress_allowed": False,
                "note": "未提供校准数据：fail-closed，禁止自动抑制（W-06）"}
    n = int(calibration.get("n_samples") or 0)
    min_n = int(calibration.get("min_samples") or policy.min_calibration_samples)
    sufficient = n >= min_n
    rel = calibration.get("reliability")
    rel_ok = (rel is not None) and (float(rel) >= SUPPRESS_REFUTE_MIN_RELIABILITY)
    if "auto_suppress_allowed" in calibration:
        allowed = bool(calibration.get("auto_suppress_allowed")) and sufficient and rel_ok
    else:
        allowed = bool(sufficient and rel_ok)
    return {"provided": True, "n_samples": n, "min_samples": min_n,
            "sufficient": sufficient, "reliability": rel, "reliability_ok": rel_ok,
            "auto_suppress_allowed": allowed,
            "note": "样本充足且可靠性达标" if allowed else "样本不足/可靠性不够，禁止自动抑制"}


def suppression_gate(calibration: dict | None,
                     policy: PolicyConfig | None = None) -> dict:
    """自动抑制总门禁：Phase 1 关闭 或 校准 fail-closed → 不允许隐藏（任何代码路径一致）。"""
    policy = policy or PolicyConfig()
    gate = calibration_gate(calibration, policy)
    allowed = bool(policy.auto_suppression and gate.get("auto_suppress_allowed"))
    return {"auto_suppression": bool(policy.auto_suppression),
            "phase1_auto_suppression_off": not bool(policy.auto_suppression),
            "calibration": gate, "auto_suppress_allowed": allowed,
            "note": ("Phase 1 自动抑制关闭" if not policy.auto_suppression else gate["note"])}



# --------------------------------------------------------------------------- 决策构造
def _decision(source: str, status: str, *, reason_code: str, reason: str, risk: dict,
              evidence: dict | None = None, confidence=None, low_confidence: bool = False,
              requires_human: bool = True, merged_into: str = "", extra: dict | None = None,
              steps: list | None = None) -> dict:
    table = DIRECT_STATUSES if source == "direct" else PLATFORM_STATUSES
    rule = table[status]
    evidence = evidence or {}
    out = {
        "source": source, "status": status,
        "visible": bool(rule["visible"]), "ledger": bool(rule["ledger"]),
        "hidden": not bool(rule["visible"]),
        "reason_code": reason_code, "reason": reason,
        "risk_level": risk.get("risk_level"), "risk_derived_from": risk.get("derived_from"),
        "risk_declared": bool(risk.get("declared")),
        "suggested_severity": risk.get("suggested_severity"),
        "high_risk": bool(risk.get("high_risk")),
        "confidence": confidence, "low_confidence": bool(low_confidence),
        "requires_human": bool(requires_human),
        "merged_into": merged_into,
        "evidence": evidence,
        "quote_match_status": evidence.get("quote_match_status") or "",
        "weak_locator": bool(evidence.get("weak_locator")),
        "quote_reuse": {},
        "policy_version": POLICY_VERSION,
        "steps": steps or [],
        "not_gold": True,      # 接受展示 ≠ 确认成立；直连/自动结果都不是真值
    }
    out.update(extra or {})
    return out


def _step(steps: list, point: str, check: str, outcome: str, note: str = "",
          reason_code: str = "") -> None:
    steps.append({"decision_point": point, "check": check, "outcome": outcome,
                  "reason_code": reason_code, "note": note})


def _scope_refused(candidate: dict, risk: dict) -> tuple:
    code = str(candidate.get("scope_reason") or "rejected_scope")
    if code not in REJECTED_REASON_CODES:
        code = "rejected_scope"
    return code


# --------------------------------------------------------------------------- 直连策略
def _quote_reuse_extra(candidate: dict) -> dict:
    """W-19：同引文跨规则码复用 → conflict/待核验（引用相关性一并留档）。"""
    reuse = dict(candidate.get("quote_reuse") or {})
    if not (candidate.get("quote_reuse_conflict") or reuse.get("conflict")):
        return {}
    codes = list(candidate.get("quote_reuse_codes") or reuse.get("codes") or [])
    return {"quote_reuse": {
                "conflict": True, "codes": codes,
                "count": int(candidate.get("quote_reuse_count")
                             or reuse.get("count") or len(codes)),
                "side": candidate.get("quote_reuse_side") or reuse.get("side") or "",
                "quote_norm": reuse.get("quote_norm") or "",
                "relevance": candidate.get("quote_relevance") or reuse.get("relevance") or {}},
            "quote_reuse_conflict": True}


def _not_verified_verdict(source: str, ev: dict, risk: dict, policy: PolicyConfig,
                          calibration: dict | None, steps: list, base: dict) -> dict:
    """证据不可核验的处置（W-02/W-06）：Phase 1 一律可见待补证；仅显式抑制开+校准通过才进台账。"""
    extra = {"unverifiable_reason": ev["reason_code"],
             "quote_match_status": ev.get("quote_match_status") or ""}
    gate = suppression_gate(calibration, policy)
    if gate["auto_suppress_allowed"] and not risk["high_risk"]:
        status = "suppressed_unverifiable"
        _step(steps, "D1", "evidence", "hidden", reason_code=ev["reason_code"],
              note="自动抑制显式开启且校准通过")
        return _decision(source, status, reason_code=ev["reason_code"],
                         reason=(f"{REASON_CODES[ev['reason_code']]} → 自动抑制（显式开关+"
                                 "校准通过）进抑制台账（不是删除，可恢复）"),
                         extra={**extra, "suppression_gate": gate}, **base)
    if risk["high_risk"]:
        source_status = ("visible_lead_highrisk" if source == "direct"
                         else "visible_need_evidence")
    else:
        source_status = "visible_need_evidence"
    _step(steps, "D1", "evidence", "visible_need_evidence",
          reason_code="visible_need_evidence",
          note=("Phase 1 自动抑制关闭" if gate["phase1_auto_suppression_off"]
                else "校准门禁拦截/高风险例外"))
    return _decision(source, source_status, reason_code="visible_need_evidence",
                     reason=(f"{REASON_CODES[ev['reason_code']]}；Phase 1 自动抑制关闭/"
                             "未通过校准门禁 → 可见、待补证，不判误报（W-02/W-06）"),
                     extra={**extra, "suppression_gate": gate}, **base)


def evaluate_direct(candidate: dict, policy: PolicyConfig | None = None,
                    calibration: dict | None = None) -> dict:
    """D0–D5：直连结果接受/拒绝（返回可序列化决策；不落库）。

    V3.2：D1 不可核验不再自动隐藏（Phase 1 视图）；normalized_ws → 弱定位可见；
    同引文跨码复用 → conflict/待核验（W-19）。
    """
    policy = policy or PolicyConfig()
    risk = resolve_risk(candidate)
    ev = evidence_state(candidate)
    conf = candidate.get("confidence")
    low = is_low_confidence(candidate, policy)
    steps: list = []
    base = dict(risk=risk, evidence=ev, confidence=conf, low_confidence=low, steps=steps)

    # D0 权限/范围（最高优先级，任何桶不得覆盖）
    if not candidate.get("scope_ok", True):
        code = _scope_refused(candidate, risk)
        _step(steps, "D0", "scope", "reject", reason_code=code)
        return _decision("direct", "rejected_scope", reason_code=code,
                         reason=f"{REASON_CODES[code]}（硬拒绝，不入抑制台账）",
                         requires_human=False, **base)
    _step(steps, "D0", "scope", "pass")

    # W-19：同一引文跨规则码复用 → 先标 conflict/待核验（与证据是否逐字无关；
    # 逐字命中不等于该引文支持本规则结论，不能因修复 W-02 就放行“无关证据”）
    if policy.quote_reuse_conflict and (candidate.get("quote_reuse_conflict")
                                        or (candidate.get("quote_reuse") or {}).get("conflict")):
        reuse = _quote_reuse_extra(candidate)
        _step(steps, "D0b", "quote_reuse", "visible_conflict",
              reason_code="quote_reuse_conflict",
              note=",".join(reuse["quote_reuse"]["codes"]))
        return _decision("direct", "visible_conflict", reason_code="quote_reuse_conflict",
                         reason=(f"同一引文被 {reuse['quote_reuse']['count']} 个规则码复用"
                                 f"（{','.join(reuse['quote_reuse']['codes'])}）→ conflict/待核验；"
                                 "逐字命中不等于该引文支持本规则结论（W-19）"),
                         extra=reuse, **base)

    # D1 证据可核验（normalized_ws 属弱定位可见，不是 unverifiable）
    if not ev["verified"]:
        return _not_verified_verdict("direct", ev, risk, policy, calibration, steps, base)
    _step(steps, "D1", "evidence", "pass",
          note=f"{ev['quote_status']}/{ev.get('quote_match_status')}")

    # D2 重复合并
    dup_of = str(candidate.get("duplicate_of") or "")
    if dup_of:
        _step(steps, "D2", "duplicate", "merge", reason_code="duplicate")
        return _decision("direct", "duplicate", reason_code="duplicate",
                         reason="与已有问题重复，合并展示（不是删除，也不单独记误报）",
                         requires_human=False, merged_into=dup_of, **base)
    _step(steps, "D2", "duplicate", "pass")

    # D3 确定性反证（W-07：逐字/可复算 + 输入来源；执行器名不算）
    refute = refutation_state(candidate)
    if refute["attempted"]:
        if not refute["verified"]:
            _step(steps, "D3", "deterministic_refute", "visible_conflict",
                  reason_code="refute_unverified",
                  note=refute.get("unverified_reason") or "")
            return _decision("direct", "visible_conflict", reason_code="refute_unverified",
                             reason=("反证不可核验（无逐字引文/无可复算轨迹/无输入来源；"
                                     "执行器名不算证据）→ 不作为隐藏依据，展示为冲突交人工"),
                             extra={"refute": refute}, **base)
        if risk["high_risk"]:
            code = ("critical_conflict_visible" if risk["risk_level"] == "critical"
                    else "high_risk_refute_conflict")
            _step(steps, "D3", "deterministic_refute", "visible_conflict", reason_code=code)
            return _decision("direct", "visible_conflict", reason_code=code,
                             reason="被确定性反证，但 critical/高风险不得自动隐藏 → 展示为冲突",
                             extra={"refute": refute}, **base)
        gate = suppression_gate(calibration, policy)
        if not gate["auto_suppress_allowed"]:
            code = ("suppression_disabled" if gate["phase1_auto_suppression_off"]
                    else "suppression_gated_by_calibration")
            _step(steps, "D3", "deterministic_refute", "visible_conflict", reason_code=code)
            return _decision("direct", "visible_conflict", reason_code=code,
                             reason=REASON_CODES[code],
                             extra={"refute": refute, "suppression_gate": gate}, **base)
        _step(steps, "D3", "deterministic_refute", "hidden", reason_code="deterministic_refuted")
        return _decision("direct", "suppressed_refuted", reason_code="deterministic_refuted",
                         reason="被逐字/可复算反证且非高风险 → 进抑制台账（不是删除，可恢复）",
                         extra={"refute": refute, "suppression_gate": gate}, **base)
    _step(steps, "D3", "deterministic_refute", "pass")

    # 冲突标记（由四桶比对带入）：强制人工
    if candidate.get("conflict"):
        _step(steps, "D3", "conflict", "visible_conflict", reason_code="conflict_requires_human")
        return _decision("direct", "visible_conflict", reason_code="conflict_requires_human",
                         reason="与平台 finding 结论/证据冲突，强制人工裁决", **base)

    # W-02：空白归一弱定位 → 可见但标弱定位（不是 unverifiable）
    if ev.get("weak_locator"):
        _step(steps, "D3", "quote_match", "visible_weak_locator",
              reason_code="visible_weak_locator")
        return _decision("direct", "visible_weak_locator", reason_code="visible_weak_locator",
                         reason=(f"引文空白归一后命中（quote_match_status=normalized_ws，"
                                 f"offset={ev.get('offset')}, line={ev.get('line')}）→ 可见并标弱定位，"
                                 "不判不可核验（W-02）"),
                         extra={"low_confidence_only": bool(low)}, **base)

    # D4 风险：高风险仍是展示（只影响复核优先级/强制人工）
    _step(steps, "D4", "risk", "visible", note=risk["risk_level"])

    # D5 置信度：只影响标注/排序，不单独隐藏
    if low:
        _step(steps, "D5", "confidence", "visible_lowconf",
              reason_code="low_confidence_visible")
        return _decision("direct", "accepted_visible_lowconf",
                         reason_code="low_confidence_visible",
                         reason="证据可核验但置信度低 → 仍展示并标注低置信（低置信不单独隐藏）",
                         extra={"low_confidence_only": True}, **base)
    _step(steps, "D5", "confidence", "visible")
    return _decision("direct", "accepted_visible", reason_code="evidence_verified",
                     reason="证据可核验 + 范围内 + 非重复 + 无确定性反证 → 接受展示（仍需人工复核）",
                     **base)


# --------------------------------------------------------------------------- 平台策略
def _is_deterministic_evidence(candidate: dict) -> bool:
    if candidate.get("deterministic_evidence") is not None:
        return bool(candidate.get("deterministic_evidence"))
    if str(candidate.get("evidence_source") or "") in ("deterministic", "executor"):
        return True
    if str(candidate.get("origin") or "") in ("deterministic", "ruleexec"):
        return True
    return str(candidate.get("certainty") or "") == "certain"


def evaluate_platform(candidate: dict, policy: PolicyConfig | None = None,
                      calibration: dict | None = None) -> dict:
    """P0–P6：平台 finding 展示/隐藏（返回可序列化决策；不落库）。

    V3.2：P1 不可核验不再自动隐藏（Phase 1 视图）；normalized_ws → 弱定位可见；
    同引文跨码复用 → conflict/待核验（W-19）。
    """
    policy = policy or PolicyConfig()
    risk = resolve_risk(candidate)
    ev = evidence_state(candidate)
    conf = candidate.get("confidence")
    low = is_low_confidence(candidate, policy)
    steps: list = []
    base = dict(risk=risk, evidence=ev, confidence=conf, low_confidence=low, steps=steps)

    # P0 范围
    if not candidate.get("scope_ok", True):
        code = _scope_refused(candidate, risk)
        _step(steps, "P0", "scope", "reject", reason_code=code)
        return _decision("platform", "rejected_scope", reason_code=code,
                         reason=f"{REASON_CODES[code]}（硬拒绝，不入抑制台账）",
                         requires_human=False, **base)
    _step(steps, "P0", "scope", "pass")

    # W-19：同一引文跨规则码复用 → 先标 conflict/待核验（不因修复 W-02 而放行无关证据）
    if policy.quote_reuse_conflict and (candidate.get("quote_reuse_conflict")
                                        or (candidate.get("quote_reuse") or {}).get("conflict")):
        reuse = _quote_reuse_extra(candidate)
        _step(steps, "P0b", "quote_reuse", "visible_conflict",
              reason_code="quote_reuse_conflict",
              note=",".join(reuse["quote_reuse"]["codes"]))
        return _decision("platform", "visible_conflict", reason_code="quote_reuse_conflict",
                         reason=(f"同一引文被 {reuse['quote_reuse']['count']} 个规则码复用"
                                 f"（{','.join(reuse['quote_reuse']['codes'])}）→ conflict/待核验；"
                                 "逐字命中不等于该引文支持本规则结论（W-19）"),
                         extra=reuse, **base)

    # P1 证据契约（W-02/W-06：normalized_ws 弱定位可见；不可核验 Phase 1 不隐藏）
    if not ev["verified"]:
        return _not_verified_verdict("platform", ev, risk, policy, calibration, steps, base)
    _step(steps, "P1", "evidence", "pass",
          note=f"{ev['quote_status']}/{ev.get('quote_match_status')}")

    # P2 重复
    dup_of = str(candidate.get("duplicate_of") or "")
    if dup_of:
        _step(steps, "P2", "duplicate", "merge", reason_code="duplicate")
        return _decision("platform", "duplicate", reason_code="duplicate",
                         reason="与已有 finding 重复，合并（不是删除）",
                         requires_human=False, merged_into=dup_of, **base)
    _step(steps, "P2", "duplicate", "pass")

    # P3 确定性反证 / 冲突（W-07：执行器名不算证据）
    refute = refutation_state(candidate)
    if refute["attempted"]:
        if not refute["verified"]:
            _step(steps, "P3", "deterministic_refute", "visible_conflict",
                  reason_code="refute_unverified",
                  note=refute.get("unverified_reason") or "")
            return _decision("platform", "visible_conflict", reason_code="refute_unverified",
                             reason=("反证不可核验（无逐字引文/无可复算轨迹/无输入来源；"
                                     "执行器名不算证据）→ 不作隐藏依据，展示为冲突交人工"),
                             extra={"refute": refute}, **base)
        if risk["high_risk"]:
            code = ("critical_conflict_visible" if risk["risk_level"] == "critical"
                    else "high_risk_refute_conflict")
            _step(steps, "P3", "deterministic_refute", "visible_conflict", reason_code=code)
            return _decision("platform", "visible_conflict", reason_code=code,
                             reason="被确定性反证，但 critical/高风险不得自动隐藏 → 展示为冲突",
                             extra={"refute": refute}, **base)
        gate = suppression_gate(calibration, policy)
        if not gate["auto_suppress_allowed"]:
            code = ("suppression_disabled" if gate["phase1_auto_suppression_off"]
                    else "suppression_gated_by_calibration")
            _step(steps, "P3", "deterministic_refute", "visible_conflict", reason_code=code)
            return _decision("platform", "visible_conflict", reason_code=code,
                             reason=REASON_CODES[code],
                             extra={"refute": refute, "suppression_gate": gate}, **base)
        _step(steps, "P3", "deterministic_refute", "hidden", reason_code="deterministic_refuted")
        return _decision("platform", "suppressed_refuted", reason_code="deterministic_refuted",
                         reason="平台 finding 被逐字/可复算反证且非高风险 → 进抑制台账",
                         extra={"refute": refute, "suppression_gate": gate}, **base)
    if candidate.get("conflict"):
        _step(steps, "P3", "conflict", "visible_conflict", reason_code="conflict_requires_human")
        return _decision("platform", "visible_conflict", reason_code="conflict_requires_human",
                         reason="与直连结论/证据冲突，强制人工裁决", **base)
    _step(steps, "P3", "deterministic_refute", "pass")

    # W-02：空白归一弱定位 → 可见但标弱定位（不是 unverifiable）
    if ev.get("weak_locator"):
        _step(steps, "P3", "quote_match", "visible_weak_locator",
              reason_code="visible_weak_locator")
        return _decision("platform", "visible_weak_locator",
                         reason_code="visible_weak_locator",
                         reason=(f"引文空白归一后命中（quote_match_status=normalized_ws，"
                                 f"offset={ev.get('offset')}, line={ev.get('line')}）→ 可见并标弱定位，"
                                 "不判不可核验（W-02）"),
                         extra={"low_confidence_only": bool(low)}, **base)

    # P4 来源类型：平台独有必须展示；确定性/语义有证据展示
    platform_only = bool(candidate.get("platform_only"))
    deterministic = _is_deterministic_evidence(candidate)
    if platform_only:
        base_status, base_code = "visible_platform_only", "platform_only_visible"
        _step(steps, "P4", "source", "visible", note="platform_only")
    elif deterministic:
        base_status, base_code = "visible_deterministic", "visible_deterministic"
        _step(steps, "P4", "source", "visible", note="deterministic")
    else:
        base_status, base_code = "visible_semantic", "visible_semantic"
        _step(steps, "P4", "source", "visible", note="semantic")

    # P5 风险：critical/高风险必须展示（状态标 highrisk，仍 100% 人工复核）
    if risk["high_risk"]:
        _step(steps, "P5", "risk", "visible_highrisk", note=risk["risk_level"])
        return _decision("platform", "visible_highrisk", reason_code="visible_highrisk",
                         reason="critical/高风险必须展示，不得自动隐藏",
                         extra={"base_status": base_status, "base_reason_code": base_code}, **base)
    _step(steps, "P5", "risk", "visible", note=risk["risk_level"])

    # P6 置信度：只标注不隐藏
    if low:
        _step(steps, "P6", "confidence", "visible_lowconf",
              reason_code="low_confidence_visible")
        return _decision("platform", "visible_lowconf", reason_code="low_confidence_visible",
                         reason="低置信但证据完整 → 展示并标注低置信（低置信不单独隐藏）",
                         extra={"base_status": base_status, "base_reason_code": base_code,
                                "low_confidence_only": True}, **base)
    _step(steps, "P6", "confidence", "visible")
    return _decision("platform", base_status, reason_code=base_code,
                     reason=REASON_CODES[base_code], **base)


# --------------------------------------------------------------------------- 候选适配
def candidate_from_direct_item(item: dict, **overrides) -> dict:
    """cross_review.normalize_direct_item / direct_item 行 → 策略候选。"""
    item = dict(item or {})
    qc = item.get("quote_check") or {}
    cand = {
        "source": "direct",
        "id": item.get("id") or item.get("direct_item_id") or "",
        "case_id": item.get("case_id") or "",
        "rule_code": item.get("code") or item.get("rule_code") or "",
        "quote": item.get("quote") or "",
        "quote_check": qc,
        "quote_match_status": item.get("quote_match_status") or "",
        "evidence_kind": item.get("evidence_kind") or "quote",
        "issue": item.get("issue") or "",
        "reason": item.get("reason") or "",
        "subject": item.get("subject") or "",
        "issue_type": item.get("issue_type") or "",
        "location_hint": item.get("location_hint") or "",
        "confidence": item.get("confidence"),
        "severity": item.get("severity") or "",
        "evidence_verified": item.get("evidence_verified"),
        "locator_present": item.get("locator_present"),
        "scope_ok": item.get("scope_ok", True),
        "scope_reason": item.get("scope_reason") or "",
        "deterministic_refuted": bool(item.get("deterministic_refuted")),
        "refute_evidence": item.get("refute_evidence") or {},
        "refute_verified": item.get("refute_verified"),
        "duplicate_of": item.get("duplicate_of") or "",
        "conflict": bool(item.get("conflict")),
        # W-04：rule_version 静态声明 / 人工覆盖
        "risk_level": item.get("risk_level") or "",
        "rule_risk_level": item.get("rule_risk_level") or "",
        "rule_version_meta": item.get("rule_version_meta") or {},
        "rule_meta": item.get("rule_meta") or {},
        "rule_version": item.get("rule_version") or "",
        # W-19：同引文跨码复用（由 cross_review 检测后注入）
        "quote_reuse_conflict": bool(item.get("quote_reuse_conflict")),
        "quote_reuse_codes": list(item.get("quote_reuse_codes") or []),
        "quote_reuse_count": item.get("quote_reuse_count"),
        "quote_reuse_side": item.get("quote_reuse_side") or "direct",
        "quote_reuse": item.get("quote_reuse") or {},
        "quote_relevance": item.get("quote_relevance") or {},
    }
    cand.update(overrides)
    return cand


def candidate_from_platform_finding(finding: dict, bucket: str = "", **overrides) -> dict:
    """cross_review.normalize_finding 输出 / platform_finding 视图行 → 策略候选。"""
    finding = dict(finding or {})
    raw = finding.get("raw_finding") or finding.get("row") or {}
    qc = finding.get("quote_check") or {}
    cand = {
        "source": "platform",
        "id": finding.get("id") or "",
        "case_id": finding.get("case_id") or "",
        "rule_code": finding.get("code") or finding.get("rule_code") or "",
        "quote": finding.get("quote") or "",
        "quote_check": qc,
        "quote_match_status": finding.get("quote_match_status") or "",
        "evidence_kind": finding.get("evidence_kind") or "quote",
        "issue": finding.get("summary") or finding.get("issue") or "",
        "subject": finding.get("subject") or "",
        "issue_type": finding.get("issue_type") or "",
        "confidence": finding.get("confidence"),
        "severity": finding.get("severity") or "",
        "certainty": finding.get("certainty") or raw.get("certainty") or "",
        "origin": finding.get("origin") or raw.get("engine") or raw.get("origin") or "",
        "evidence_verified": finding.get("evidence_verified"),
        "locator_present": finding.get("locator_present"),
        "anchor_ids": list(finding.get("anchor_ids") or []),
        "scope_ok": finding.get("scope_ok", True),
        "scope_reason": finding.get("scope_reason") or "",
        "deterministic_refuted": bool(finding.get("deterministic_refuted")),
        "refute_evidence": finding.get("refute_evidence") or {},
        "refute_verified": finding.get("refute_verified"),
        "duplicate_of": finding.get("duplicate_of") or "",
        "conflict": bool(finding.get("conflict")),
        "platform_only": bool(bucket == "platform_only" or finding.get("platform_only")),
        # W-04：rule_version 静态声明 / 人工覆盖
        "risk_level": finding.get("risk_level") or "",
        "rule_risk_level": finding.get("rule_risk_level") or "",
        "rule_version_meta": finding.get("rule_version_meta") or {},
        "rule_meta": finding.get("rule_meta") or {},
        "rule_version": finding.get("rule_version") or "",
        # W-19：同引文跨码复用（由 cross_review 检测后注入）
        "quote_reuse_conflict": bool(finding.get("quote_reuse_conflict")),
        "quote_reuse_codes": list(finding.get("quote_reuse_codes") or []),
        "quote_reuse_count": finding.get("quote_reuse_count"),
        "quote_reuse_side": finding.get("quote_reuse_side") or "platform",
        "quote_reuse": finding.get("quote_reuse") or {},
        "quote_relevance": finding.get("quote_relevance") or {},
    }
    cand.update(overrides)
    return cand


# --------------------------------------------------------------------------- 四桶整合
def _side_decisions(record: dict, policy: PolicyConfig, calibration_map: dict,
                    context: dict) -> tuple:
    bucket = str(record.get("bucket") or "")
    d_raw = record.get("direct")
    p_raw = record.get("platform")
    d_ctx = dict((context or {}).get("direct") or {})
    p_ctx = dict((context or {}).get("platform") or {})
    d_cal = (calibration_map or {}).get("direct")
    p_cal = (calibration_map or {}).get("platform") or (calibration_map or {}).get("refuter")

    direct = platform = None
    if d_raw is not None:
        merged = p_raw is not None
        overrides = dict(d_ctx)
        if merged and bucket == "both":
            overrides.setdefault("duplicate_of",
                                 str((p_raw or {}).get("id") or "platform_finding"))
        if bucket == "conflict":
            overrides.setdefault("conflict", True)
        cand = candidate_from_direct_item(d_raw, **overrides)
        direct = evaluate_direct(cand, policy, d_cal)
    if p_raw is not None:
        overrides = dict(p_ctx)
        if bucket == "conflict":
            overrides.setdefault("conflict", True)
        cand = candidate_from_platform_finding(p_raw, bucket=bucket, **overrides)
        platform = evaluate_platform(cand, policy, p_cal)
    return direct, platform


def evaluate_comparison(record: dict, policy: PolicyConfig | None = None,
                        calibration_map: dict | None = None,
                        context: dict | None = None) -> dict:
    """对一条四桶比对记录给出双方可见性决策与记录级可见性。

    context 可传 {"direct": {...}, "platform": {...}} 覆盖候选字段
    （范围门禁、确定性反证、证据契约、引文复用等由调用方按真实数据注入）。

    W-09：**scope 优先级高于桶**——一侧 scope_status != in_scope 时该侧 rejected_scope，
    两侧都 rejected（含 conflict 桶）时记录级 rejected_scope，任何桶都不得覆盖。
    """
    policy = policy or PolicyConfig()
    bucket = str(record.get("bucket") or "")
    if bucket not in ("both", "direct_only", "platform_only", "conflict"):
        raise ValueError(f"非法四桶：{bucket}")
    direct, platform = _side_decisions(record, policy, calibration_map or {}, context or {})
    present = [d for d in (direct, platform) if d]
    in_scope = [d for d in present if d["status"] != "rejected_scope"]
    visible_sides = [d for d in present if d["visible"]]
    # W-09：范围优先。所有出现侧都 rejected_scope → 记录级 rejected_scope
    if present and not in_scope:
        visibility = "rejected_scope"
    elif bucket == "conflict" and visible_sides:
        visibility = "visible"
    elif visible_sides:
        visibility = "visible"
    elif any(d["status"] == "duplicate" for d in present):
        visibility = "duplicate"
    elif any(d["ledger"] for d in present):
        visibility = "suppressed"
    elif any(d["hidden"] for d in present):
        visibility = "hidden"
    else:
        visibility = "visible"
    reason_codes = []
    for d in present:
        rc = d["reason_code"]
        if rc not in reason_codes:
            reason_codes.append(rc)
    merged_into = ""
    for d in present:
        if d.get("merged_into"):
            merged_into = d["merged_into"]
    quote_reuse_conflict = any(bool(d.get("quote_reuse_conflict")) for d in present)
    weak_locator = any(bool(d.get("weak_locator")) for d in present)
    quote_match_status = {d["source"]: d.get("quote_match_status") or "" for d in present}
    return {"case_id": record.get("case_id") or "",
            "bucket": bucket, "direct": direct, "platform": platform,
            "visibility": visibility, "reason_codes": reason_codes,
            "merged_into": merged_into, "quote_reuse_conflict": quote_reuse_conflict,
            "weak_locator": weak_locator, "quote_match_status": quote_match_status,
            "policy": policy.as_dict(),
            "policy_version": POLICY_VERSION, "not_gold": True}


# ===========================================================================
# confidence_calibration 表：按 来源/规则/文档类型/风险/置信分箱 聚合人工裁决样本
#
# 用途（置信图 §6）：
#   1 没有足够样本的规则/来源组合 → 不允许自动确认/抑制，只能人工；
#   2 用人工裁决集做 reliability 图 / ECE；
#   3 模型自报 confidence 只做分箱排序特征，不直接当概率。
# ===========================================================================
CALIBRATION_TABLE = "confidence_calibration"


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def confidence_bin(confidence, n_bins: int = 5) -> str:
    """0..1 置信度 → 等宽分箱标签（如 0.8-1.0）。"""
    try:
        v = float(confidence)
    except (TypeError, ValueError):
        return "unknown"
    v = max(0.0, min(1.0, v))
    n_bins = max(1, int(n_bins))
    idx = min(n_bins - 1, int(v * n_bins))
    lo, hi = idx / n_bins, (idx + 1) / n_bins
    return f"{lo:.1f}-{hi:.1f}"


def bin_center(label: str) -> float:
    if not label or label == "unknown" or "-" not in label:
        return 0.0
    lo, hi = label.split("-", 1)
    try:
        return round((float(lo) + float(hi)) / 2, 4)
    except ValueError:
        return 0.0


def upsert_calibration(conn, *, source: str, rule_code: str = "", doc_type: str = "",
                       risk_level: str = "medium", confidence_bin_label: str = "",
                       n_samples: int, n_correct: int, min_samples: int = 30,
                       tenant_id: str = "", workspace_id: str = "") -> dict:
    """按分组分箱写入/更新校准聚合（幂等 upsert）。"""
    if source not in ("direct", "platform"):
        raise ValueError(f"未知来源：{source}")
    if risk_level not in RISK_LEVELS:
        risk_level = "medium"
    n_samples, n_correct = max(0, int(n_samples)), max(0, int(n_correct))
    n_correct = min(n_correct, n_samples)
    reliability = round(n_correct / n_samples, 4) if n_samples else None
    auto_confirm = int(bool(n_samples >= min_samples and (reliability or 0) >= CONFIRM_MIN_RELIABILITY))
    auto_suppress = int(bool(n_samples >= min_samples and
                             (reliability or 0) >= SUPPRESS_REFUTE_MIN_RELIABILITY))
    stamp = _now_iso()
    hit = conn.execute(
        f"SELECT id FROM {CALIBRATION_TABLE} WHERE source=? AND rule_code=? AND doc_type=? "
        "AND risk_level=? AND confidence_bin=?", (source, rule_code, doc_type, risk_level,
                                                 confidence_bin_label)).fetchone()
    if hit:
        conn.execute(
            f"UPDATE {CALIBRATION_TABLE} SET n_samples=?, n_correct=?, reliability=?, "
            "min_samples=?, auto_confirm_allowed=?, auto_suppress_allowed=?, updated_at=? "
            "WHERE id=?", (n_samples, n_correct, reliability, int(min_samples), auto_confirm,
                           auto_suppress, stamp, hit[0]))
        row_id = hit[0]
    else:
        row_id = "cc_" + uuid.uuid4().hex[:16]
        conn.execute(
            f"INSERT INTO {CALIBRATION_TABLE}(id, tenant_id, workspace_id, source, rule_code, "
            "doc_type, risk_level, confidence_bin, n_samples, n_correct, reliability, ece, "
            "min_samples, auto_confirm_allowed, auto_suppress_allowed, created_at, updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (row_id, tenant_id, workspace_id, source, rule_code, doc_type, risk_level,
             confidence_bin_label, n_samples, n_correct, reliability, None, int(min_samples),
             auto_confirm, auto_suppress, stamp, stamp))
    return get_calibration_row(conn, row_id)


def get_calibration_row(conn, row_id: str) -> dict:
    row = conn.execute(f"SELECT * FROM {CALIBRATION_TABLE} WHERE id=?", (row_id,)).fetchone()
    return dict(row) if row else None


def record_calibration_sample(conn, *, source: str, correct: bool, confidence,
                              rule_code: str = "", doc_type: str = "", risk_level: str = "medium",
                              min_samples: int = 30, n_bins: int = 5,
                              tenant_id: str = "", workspace_id: str = "") -> dict:
    """人工裁决回填一条校准样本：命中已有分箱则累加。"""
    label = confidence_bin(confidence, n_bins)
    row = query_calibration(conn, source=source, rule_code=rule_code, doc_type=doc_type,
                            risk_level=risk_level, confidence_bin_label=label)
    n0 = int(row[0]["n_samples"]) if row else 0
    c0 = int(row[0]["n_correct"]) if row else 0
    return upsert_calibration(conn, source=source, rule_code=rule_code, doc_type=doc_type,
                              risk_level=risk_level, confidence_bin_label=label,
                              n_samples=n0 + 1, n_correct=c0 + (1 if correct else 0),
                              min_samples=min_samples, tenant_id=tenant_id,
                              workspace_id=workspace_id)


def query_calibration(conn, *, source: str = "", rule_code: str = "", doc_type: str = "",
                      risk_level: str = "", confidence_bin_label: str = "") -> list:
    where, params = [], []
    for col, val in (("source", source), ("rule_code", rule_code), ("doc_type", doc_type),
                     ("risk_level", risk_level), ("confidence_bin", confidence_bin_label)):
        if val:
            where.append(f"{col}=?")
            params.append(val)
    sql = f"SELECT * FROM {CALIBRATION_TABLE}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY source, rule_code, doc_type, risk_level, confidence_bin"
    return [dict(r) for r in conn.execute(sql, tuple(params)).fetchall()]


def reliability_report(conn, *, source: str = "", rule_code: str = "", doc_type: str = "") -> dict:
    """按来源/规则/文档类型汇总 reliability + ECE（分箱加权）。"""
    rows = query_calibration(conn, source=source, rule_code=rule_code, doc_type=doc_type)
    groups: dict = {}
    for r in rows:
        key = (r.get("source"), r.get("rule_code"), r.get("doc_type"))
        g = groups.setdefault(key, {"source": key[0], "rule_code": key[1],
                                    "doc_type": key[2], "n_samples": 0, "n_correct": 0,
                                    "bins": []})
        n = int(r.get("n_samples") or 0)
        c = int(r.get("n_correct") or 0)
        g["n_samples"] += n
        g["n_correct"] += c
        g["bins"].append({"confidence_bin": r.get("confidence_bin"), "n_samples": n,
                          "n_correct": c, "reliability": r.get("reliability"),
                          "auto_suppress_allowed": bool(r.get("auto_suppress_allowed"))})
    out = []
    for g in groups.values():
        n = g["n_samples"]
        g["accuracy"] = round(g["n_correct"] / n, 4) if n else None
        ece = 0.0
        for b in g["bins"]:
            bn = int(b["n_samples"] or 0)
            if not bn or not n:
                continue
            acc = (int(b["n_correct"] or 0) / bn) if bn else 0.0
            ece += (bn / n) * abs(acc - bin_center(str(b.get("confidence_bin") or "")))
        g["ece"] = round(ece, 4) if n else None
        g["auto_suppress_allowed"] = bool(n and
                                          (g["accuracy"] or 0) >= SUPPRESS_REFUTE_MIN_RELIABILITY
                                          and n >= DEFAULT_MIN_CALIBRATION_SAMPLES)
        out.append(g)
    out.sort(key=lambda x: (str(x["source"]), str(x["rule_code"]), str(x["doc_type"])))
    return {"groups": out, "group_count": len(out),
            "total_samples": sum(g["n_samples"] for g in out)}


def calibration_gate_for(conn, *, source: str, rule_code: str = "", doc_type: str = "",
                         risk_level: str = "", min_samples: int | None = None,
                         policy: PolicyConfig | None = None) -> dict:
    """从 confidence_calibration 表读取该分组是否允许自动抑制。"""
    policy = policy or PolicyConfig()
    min_n = int(min_samples or policy.min_calibration_samples)
    rows = query_calibration(conn, source=source, rule_code=rule_code, doc_type=doc_type,
                             risk_level=risk_level)
    n = sum(int(r.get("n_samples") or 0) for r in rows)
    c = sum(int(r.get("n_correct") or 0) for r in rows)
    reliability = round(c / n, 4) if n else None
    gate = calibration_gate({"n_samples": n, "min_samples": min_n,
                             "reliability": reliability}, policy)
    gate.update({"source": source, "rule_code": rule_code, "doc_type": doc_type,
                 "n_correct": c, "rows": len(rows)})
    return gate


__all__ = [
    "POLICY_VERSION", "RISK_LEVELS", "RISK_ORDER", "REASON_CODES", "HIDDEN_REASON_CODES",
    "REJECTED_REASON_CODES", "DIRECT_STATUSES", "PLATFORM_STATUSES", "VISIBLE_STATUSES",
    "HIDDEN_STATUSES", "PolicyConfig", "EVIDENCE_KINDS", "VERBATIM_QUOTE_STATUSES",
    "QUOTE_MATCH_STATUSES", "WEAK_LOCATOR_QUOTE_STATUSES", "PHASE1_AUTO_SUPPRESSION",
    "resolve_risk", "declared_risk", "is_high_risk", "quote_match_status_of",
    "evidence_state", "refutation_state", "is_low_confidence", "calibration_gate",
    "suppression_gate", "evaluate_direct", "evaluate_platform",
    "candidate_from_direct_item", "candidate_from_platform_finding",
    "evaluate_comparison", "CALIBRATION_TABLE", "confidence_bin", "bin_center",
    "upsert_calibration", "get_calibration_row", "record_calibration_sample",
    "query_calibration", "reliability_report", "calibration_gate_for",
    "CONFIRM_MIN_RELIABILITY", "SUPPRESS_REFUTE_MIN_RELIABILITY",
    "DEFAULT_MIN_CALIBRATION_SAMPLES", "DEFAULT_LOW_CONFIDENCE_THRESHOLD",
]
