# -*- coding: utf-8 -*-
"""Policy Compiler 服务层 facade（L73 接入 lane；铁律 7 / 82 号规格 §7）。

把引擎层四个纯函数模块（policy_ir / policy_templates / ir_render / policy_plan）
编排成**可审计、可串行化、开关可回退**的发布前置门：

- `evaluate(text)`：编译 → 结构校验 → 反译互证 → 执行计划 → 4 关，返回 JSON 可序列化结果；
- `compile_text / validate / back_translate / semantic_diff / plan / detect_conflicts`：
  与规格 §2/§3/§4/§5/§6 同名的最小接口（CLI/HTTP 后续接入只调这里，不另写逻辑）；
- `gate_publish_policy(...)`：发布前置第 4 道（`_pre_lifecycle_gates` 用）；
- `advisory_candidate_policy(...)`：RSI 候选释放前 advisory 校验（**不改变结论**）；
- 开关：
  - `RULEPROOF_POLICY_COMPILER` 默认 `0`：0 → 全部调用点短路 `decision=bypass`，
    与现状逐字节等价（不写 `_policy`、不写审计）；
  - `RULEPROOF_POLICY_COMPILER_MODE` 默认 `advisory`：advisory 只提示/写审计不阻断，
    `blocking` 时发布门未过 → HTTP 422（`policy_backtranslation_mismatch` 等）；
  - `RULEPROOF_POLICY_COMPILER_EVIDENCE` 默认 `allow_default`：`blocking` 时
    `evidence.derived` 不再放行（P4 阶段，本 lane 只预留）。
- 审计事件：`policy.compile` / `policy.backtranslation`（含 compiler_version / ir_digest /
  coverage；`renderer_version` / `gate_version` / source_sha256 一并留痕）。

诚实边界（不得当 PASS 宣称；详见 L63/L73 报告）：
反译一致率是「确定性 renderer + shadow 抽取器」自洽率，不是人工 faithful 率；
执行器可达性 partial 不伪装成 yes；本模块不参与 D1–D5 判定，只决定「规则能否进发布」。
"""
from __future__ import annotations

import json
import logging
import os

from ..engine import ir_render, policy_ir, policy_plan, policy_templates

_LOG = logging.getLogger(__name__)

SWITCH_ENV = "RULEPROOF_POLICY_COMPILER"
MODE_ENV = "RULEPROOF_POLICY_COMPILER_MODE"
EVIDENCE_ENV = "RULEPROOF_POLICY_COMPILER_EVIDENCE"
META_VERSION = "policy-meta/v1"
AUDIT_PAYLOAD_VERSION = "policy-audit/v1"
ALLOWED_MODES = ("advisory", "blocking")
ALLOWED_EVIDENCE = ("allow_default", "blocking")
GATE_NAMES = ("compile_validate", "back_translation", "evidence_requirement",
              "executor_reachable")
ERROR_COMPILE = "policy_compile_rejected"
ERROR_MISMATCH = "policy_backtranslation_mismatch"
ERROR_EVIDENCE = "policy_evidence_missing"
ERROR_REACH = "policy_executor_unreachable"

# 公开的最小接口（引擎层同名函数；服务层调用方只依赖本 facade）
compile_text = policy_templates.compile_rule
validate = policy_ir.validate_ir
back_translate = ir_render.back_translate
semantic_diff = ir_render.semantic_diff
plan = policy_plan.plan
detect_conflicts = policy_plan.detect_conflicts
to_platform_slots = policy_plan.to_platform_slots


# ---------------------------------------------------------------------------
# 开关
# ---------------------------------------------------------------------------
def enabled(env=None) -> bool:
    """`RULEPROOF_POLICY_COMPILER`：默认 0（关）。"""
    value = (os.environ.get("RULEPROOF_POLICY_COMPILER", "0")
             if env is None else env)
    return str(value).strip() == "1"


def current_mode(env=None) -> str:
    """`RULEPROOF_POLICY_COMPILER_MODE`：默认 advisory；非法值回退 advisory。"""
    value = (os.environ.get("RULEPROOF_POLICY_COMPILER_MODE", "advisory")
             if env is None else env)
    mode = str(value or "").strip().lower()
    return mode if mode in ALLOWED_MODES else "advisory"


def evidence_mode(env=None) -> str:
    """`RULEPROOF_POLICY_COMPILER_EVIDENCE`：默认 allow_default；非法值回退。"""
    value = (os.environ.get("RULEPROOF_POLICY_COMPILER_EVIDENCE", "allow_default")
             if env is None else env)
    mode = str(value or "").strip().lower()
    return mode if mode in ALLOWED_EVIDENCE else "allow_default"


def switch_state() -> dict:
    return {"switch": SWITCH_ENV, "enabled": enabled(), "mode": current_mode(),
            "evidence": evidence_mode(), "mode_env": MODE_ENV,
            "evidence_env": EVIDENCE_ENV,
            "compiler_version": policy_ir.COMPILER_VERSION,
            "renderer_version": policy_ir.RENDERER_VERSION,
            "gate_version": policy_ir.GATE_VERSION}


# ---------------------------------------------------------------------------
# 串行化工具
# ---------------------------------------------------------------------------
def _jsonable(obj):
    """转成纯 JSON 可序列化结构（审计/落库前统一口径；失败返回 None 而非抛错）。"""
    try:
        return json.loads(json.dumps(obj, ensure_ascii=False, sort_keys=True))
    except (TypeError, ValueError):
        return None


def _empty_coverage() -> dict:
    return {"declared_count": 0, "total": 9, "ratio": 0.0, "gaps": []}


def _source_of(text) -> dict:
    raw = str(text or "")
    return {"text": raw, "sha256": policy_ir.sha256_text(raw), "chars": len(raw),
            "span": policy_ir.canonical_source_span(raw)}


def _bypass(mode: str) -> dict:
    gates = [{"gate": name, "status": "skipped",
              "detail": SWITCH_ENV + "=0（默认关，逐字节回退）"} for name in GATE_NAMES]
    return {"enabled": False, "mode": mode, "switch": SWITCH_ENV, "status": "skipped",
            "decision": "bypass", "rule_type": "", "ir": None, "ir_id": "", "ir_digest": "",
            "source": _source_of(""), "coverage": _empty_coverage(),
            "validation": {"ok": False, "errors": [], "checks_count": 0},
            "backtranslation": None, "plan": None,
            "compiler_version": policy_ir.COMPILER_VERSION,
            "renderer_version": policy_ir.RENDERER_VERSION,
            "gate_version": policy_ir.GATE_VERSION, "gates": gates,
            "blocking_reasons": [], "advisory": [], "warnings": [], "reject": None}


def _error_code(result: dict) -> str:
    """blocking 拒绝时映射可操作错误码（G1..G4 顺序取首个阻断）。"""
    if str(result.get("status") or "") != "compiled":
        return ERROR_COMPILE
    validation = result.get("validation") or {}
    if not validation.get("ok", True):
        return ERROR_COMPILE
    backtranslation = result.get("backtranslation") or {}
    if (backtranslation.get("consistent") is False
            or backtranslation.get("needs_human") is True
            or backtranslation.get("roundtrip_ok") is False):
        return ERROR_MISMATCH
    for reason in (result.get("blocking_reasons") or []):
        gate = str((reason or {}).get("gate") or "")
        if gate == "compile_validate":
            return ERROR_COMPILE
        if gate == "back_translation":
            return ERROR_MISMATCH
        if gate == "evidence_requirement":
            return ERROR_EVIDENCE
        if gate == "executor_reachable":
            return ERROR_REACH
    return ERROR_MISMATCH


def _error_message(result: dict, code: str) -> str:
    if code == ERROR_COMPILE:
        reject = result.get("reject") or {}
        detail = reject.get("message") or "；".join(
            str(e.get("message") or e.get("code") or "") for e in
            (result.get("validation") or {}).get("errors") or [])
        return ("策略编译器拒绝该规则（fail-closed，未知类型/缺单位/不可映射算子不得发布）："
                + (str(detail) or str(reject.get("code") or "compile_rejected")))
    if code == ERROR_MISMATCH:
        return "策略反译互证未通过（IR 与原文槽位不一致或审计 IR 漂移），不得发布"
    if code == ERROR_EVIDENCE:
        return "策略证据要求未在原文声明（derived），blocking 策略下不得发布"
    return "策略执行器不可达（换算/取整等不在 platform rule IR 内），不得发布"


# ---------------------------------------------------------------------------
# 4 关发布前置门
# ---------------------------------------------------------------------------
def _assemble(ir: dict, source_text: str, *, mode: str, llm_votes=None,
              allow_default_evidence=None, allow_partial_executor=None,
              compile_warnings=None) -> dict:
    """编排 4 关 + 反译/校验/计划明细；返回 JSON 可序列化结果（不含 ir 本体）。"""
    validation = validate(ir)
    back_translation = back_translate(ir, llm_votes=llm_votes)
    diff = semantic_diff(ir, source_text)
    planning = plan(ir)
    if allow_default_evidence is None:
        allow_default_evidence = evidence_mode() != "blocking"
    if allow_partial_executor is None:
        allow_partial_executor = True

    gates = []
    g1_ok = bool(validation.get("ok"))
    gates.append({"gate": "compile_validate", "status": "pass" if g1_ok else "blocked",
                  "detail": {"errors": [e.get("code") for e in
                                        (validation.get("errors") or [])],
                             "checks": len(validation.get("checks") or [])}})
    g2_ok = bool(diff.get("consistent")) and not back_translation.get("needs_human")
    gates.append({"gate": "back_translation", "status": "pass" if g2_ok else "blocked",
                  "detail": {"consistent": diff.get("consistent"),
                             "ratio": diff.get("ratio"),
                             "roundtrip_ok": diff.get("roundtrip_ok"),
                             "span_ok": diff.get("span_ok"),
                             "needs_human": back_translation.get("needs_human"),
                             "critical_diffs": [d.get("slot") for d in
                                                (diff.get("critical_diffs") or [])]}})
    evidence = ir.get("evidence") or {}
    if evidence.get("declared"):
        g3_status, g3_detail = "pass", "证据要求已声明"
    elif allow_default_evidence:
        g3_status, g3_detail = "pass", "证据要求 derived，策略允许默认证据路径（留痕）"
    else:
        g3_status, g3_detail = "blocked", "证据要求未在原文声明（derived），blocking 策略不放行"
    gates.append({"gate": "evidence_requirement", "status": g3_status,
                  "detail": g3_detail})
    reach = planning.get("executor_reachable")
    if reach == "yes":
        g4_status, g4_detail = "pass", "执行器全部可达"
    elif reach == "partial":
        if allow_partial_executor:
            g4_status = "pass"
            g4_detail = "部分可达（策略允许，留痕）：" + str(
                planning.get("reachability_note") or "")
        else:
            g4_status, g4_detail = "blocked", "部分可达：" + str(
                planning.get("reachability_note") or "")
    else:
        g4_status, g4_detail = "blocked", "不可达：" + str(
            planning.get("reachability_note") or "")
    gates.append({"gate": "executor_reachable", "status": g4_status,
                  "detail": g4_detail, "reachability": reach})

    blocked = [g for g in gates if g["status"] == "blocked"]
    if blocked and mode == "blocking":
        decision = "rejected"
    elif blocked:
        decision = "advisory_pass"
    else:
        decision = "pass"
    coverage = ir.get("coverage") or {}
    diff_summary = {"text": back_translation.get("text"),
                    "consistent": diff.get("consistent"),
                    "ratio": diff.get("ratio"),
                    "matched": diff.get("matched"), "total": diff.get("total"),
                    "roundtrip_ok": diff.get("roundtrip_ok"),
                    "span_ok": diff.get("span_ok"),
                    "needs_human": back_translation.get("needs_human"),
                    "renderer_version": back_translation.get("renderer_version"),
                    "critical_diffs": [d.get("slot") for d in (diff.get("critical_diffs") or [])]}
    plan_summary = {"executor": planning.get("executor"),
                    "verifier": planning.get("verifier"),
                    "executor_reachable": planning.get("executor_reachable"),
                    "reachability_note": planning.get("reachability_note"),
                    "warnings": [w.get("code") for w in (planning.get("warnings") or [])],
                    "deterministic": planning.get("deterministic"),
                    "model_calls": planning.get("model_calls")}
    warnings = [str(w.get("code") if isinstance(w, dict) else w)
                for w in (ir.get("compile") or {}).get("warnings") or []]
    if compile_warnings:
        for w in compile_warnings:
            code = str(w.get("code") if isinstance(w, dict) else w)
            if code and code not in warnings:
                warnings.append(code)
    return {"enabled": True, "mode": mode, "switch": SWITCH_ENV,
            "compiler_version": policy_ir.COMPILER_VERSION,
            "renderer_version": policy_ir.RENDERER_VERSION,
            "gate_version": policy_ir.GATE_VERSION,
            "decision": decision, "gates": gates,
            "blocking_reasons": [{"gate": g["gate"], "detail": g["detail"]}
                                 for g in blocked],
            "advisory": [g["gate"] for g in blocked] if mode == "advisory" else [],
            "validation": {"ok": g1_ok,
                           "errors": _jsonable(validation.get("errors") or []),
                           "checks_count": len(validation.get("checks") or [])},
            "backtranslation": diff_summary, "plan": plan_summary,
            "coverage": _jsonable({"declared_count": coverage.get("declared_count", 0),
                                   "total": coverage.get("total", 9),
                                   "ratio": coverage.get("ratio", 0.0),
                                   "gaps": [g.get("slot") for g in
                                            (coverage.get("gaps") or [])]}) or _empty_coverage(),
            "warnings": warnings}


def precheck(ir: dict, source_text: str, *, mode=None, switch_on=None,
             llm_votes=None, allow_default_evidence=None,
             allow_partial_executor=None) -> dict:
    """4 关发布前置门（对应原型 publish_precheck；开关关 → bypass 4 关 skipped）。"""
    mode = current_mode() if mode is None else str(mode or "").strip().lower()
    if mode not in ALLOWED_MODES:
        mode = "advisory"
    on = enabled() if switch_on is None else bool(switch_on)
    if not on:
        return _bypass(mode)
    out = _assemble(ir, source_text, mode=mode, llm_votes=llm_votes,
                    allow_default_evidence=allow_default_evidence,
                    allow_partial_executor=allow_partial_executor)
    return out


# ---------------------------------------------------------------------------
# 文本级全流程
# ---------------------------------------------------------------------------
def evaluate(text, *, mode=None, switch_on=None, llm_votes=None,
             allow_default_evidence=None, allow_partial_executor=None) -> dict:
    """文本 → 编译/校验/反译/计划/4 关，返回 JSON 可序列化审计结果。"""
    mode = current_mode() if mode is None else str(mode or "").strip().lower()
    if mode not in ALLOWED_MODES:
        mode = "advisory"
    on = enabled() if switch_on is None else bool(switch_on)
    if not on:
        return _bypass(mode)
    compiled = compile_text(text)
    source = _source_of(text)
    base = {"enabled": True, "mode": mode, "switch": SWITCH_ENV,
            "compiler_version": policy_ir.COMPILER_VERSION,
            "renderer_version": policy_ir.RENDERER_VERSION,
            "gate_version": policy_ir.GATE_VERSION,
            "source": source}
    if compiled.get("status") != "compiled":
        reject = dict((compiled.get("errors") or [{}])[0] or {})
        blocked_detail = {"errors": [str(reject.get("code") or "compile_rejected")],
                          "message": str(reject.get("message") or "")}
        decision = "rejected" if mode == "blocking" else "advisory_pass"
        blocked = [{"gate": "compile_validate", "detail": blocked_detail}]
        base.update({
            "status": "rejected", "rule_type": str(compiled.get("rule_type") or ""),
            "ir": None, "ir_id": "", "ir_digest": "",
            "coverage": _empty_coverage(),
            "validation": {"ok": False, "errors": [reject], "checks_count": 0},
            "backtranslation": None, "plan": None,
            "decision": decision,
            "gates": [{"gate": "compile_validate", "status": "blocked",
                       "detail": blocked_detail}],
            "blocking_reasons": blocked,
            "advisory": ["compile_validate"] if mode == "advisory" else [],
            "warnings": [str(w.get("code") if isinstance(w, dict) else w)
                         for w in (compiled.get("warnings") or [])],
            "reject": {"code": str(reject.get("code") or "compile_rejected"),
                       "message": str(reject.get("message") or "")},
        })
        if decision == "rejected":
            base["error_code"] = ERROR_COMPILE
            base["message"] = _error_message(base, ERROR_COMPILE)
        return base
    ir = compiled["ir"]
    assembled = _assemble(ir, ir["source"]["text"], mode=mode, llm_votes=llm_votes,
                          allow_default_evidence=allow_default_evidence,
                          allow_partial_executor=allow_partial_executor,
                          compile_warnings=compiled.get("warnings"))
    base.update(assembled)
    base.update({"status": "compiled", "rule_type": ir.get("rule_type") or "",
                 "ir": _jsonable(ir), "ir_id": ir.get("ir_id") or "",
                 "ir_digest": policy_ir.ir_digest(ir), "reject": None})
    if base["decision"] == "rejected":
        base["error_code"] = _error_code(base)
        base["message"] = _error_message(base, base["error_code"])
    return base


# ---------------------------------------------------------------------------
# 规则来源文本 / _policy 记录
# ---------------------------------------------------------------------------
def text_from_slots(slots, scope=None) -> str:
    """从规则槽位/作用域取「规则来源原文」（create_rule 的 criterion 优先）。"""
    s = slots if isinstance(slots, dict) else {}
    for key in ("criterion", "text", "source_text", "rule_text", "description"):
        value = s.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    sc = scope if isinstance(scope, dict) else {}
    for key in ("criterion", "text"):
        value = sc.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    metric = str(s.get("metric") or s.get("parameter") or "").strip()
    op = str(s.get("op") or s.get("operator") or "").strip()
    value = s.get("value", s.get("threshold"))
    unit = str(s.get("unit") or "").strip()
    if metric and op and value not in (None, ""):
        return f"{metric} {op} {value}{unit}".strip()
    return ""


def text_from_candidate(after) -> str:
    """RSI 候选快照 → 可编译的规则文本（slots 优先，其次 params/pending/behavior）。"""
    a = after if isinstance(after, dict) else {}
    candidates = [a.get("slots") or {}, a.get("params") or {},
                  a.get("pending") or {}, a.get("behavior") or {}, a]
    for item in candidates:
        text = text_from_slots(item)
        if text:
            return text
    return ""


def policy_record(result: dict) -> dict:
    """评估结果 → `slots_json["_policy"]` 精简记录（只增字段，旧代码忽略）。"""
    source = dict((result or {}).get("source") or {})
    record = {
        "version": META_VERSION,
        "enabled": bool((result or {}).get("enabled")),
        "mode": str((result or {}).get("mode") or "advisory"),
        "switch": SWITCH_ENV,
        "compiler_version": (result or {}).get("compiler_version")
        or policy_ir.COMPILER_VERSION,
        "renderer_version": (result or {}).get("renderer_version")
        or policy_ir.RENDERER_VERSION,
        "gate_version": (result or {}).get("gate_version") or policy_ir.GATE_VERSION,
        "status": str((result or {}).get("status") or "skipped"),
        "decision": str((result or {}).get("decision") or "bypass"),
        "rule_type": str((result or {}).get("rule_type") or ""),
        "ir_id": str((result or {}).get("ir_id") or ""),
        "ir_digest": str((result or {}).get("ir_digest") or ""),
        "source": {"text": str(source.get("text") or ""),
                   "sha256": str(source.get("sha256") or ""),
                   "chars": int(source.get("chars") or 0),
                   "span": _jsonable(source.get("span") or {}) or {}},
        "coverage": _jsonable((result or {}).get("coverage") or _empty_coverage())
        or _empty_coverage(),
        "backtranslation": _jsonable((result or {}).get("backtranslation") or {}) or {},
        "plan": _jsonable((result or {}).get("plan") or {}) or {},
        "gates": [{"gate": str(g.get("gate") or ""), "status": str(g.get("status") or "")}
                  for g in ((result or {}).get("gates") or [])],
        "blocking_reasons": _jsonable((result or {}).get("blocking_reasons") or []) or [],
        "advisory": list((result or {}).get("advisory") or []),
        "warnings": list((result or {}).get("warnings") or []),
        "reject": _jsonable((result or {}).get("reject") or None),
    }
    return _jsonable(record) or record


# ---------------------------------------------------------------------------
# 调用点 1：create_rule 保存期（advisory 只记录，不改创建结论）
# ---------------------------------------------------------------------------
def evaluate_for_create(slots, scope=None, *, mode=None) -> dict:
    """规则创建保存期评估（永不拒绝创建；开关关 → bypass）。"""
    text = text_from_slots(slots, scope)
    return evaluate(text, mode=mode)


# ---------------------------------------------------------------------------
# 调用点 2：发布前置第 4 道（advisory 只告警；blocking → 422）
# ---------------------------------------------------------------------------
def gate_publish_policy(rule_id: str = "", slots=None, version=None,
                        actor: str = "system") -> dict:
    """发布前置门第 4 道：重编译 + 反译互证 + IR 记录漂移检测。

    返回 ``{enabled, mode, decision, error_code, message, ...}``；
    ``decision=rejected`` 只在 blocking 模式出现（advisory → advisory_pass）；
    无 `_policy` 记录且无非结构化文本 → ``decision=skipped_legacy``（旧规则不回溯阻断）。
    """
    del version  # 预留：版本级指纹后续接入（本 lane 只读 slots）
    mode = current_mode()
    s = slots if isinstance(slots, dict) else {}
    stored = s.get("_policy") if isinstance(s.get("_policy"), dict) else None
    text = text_from_slots(s)
    stored_text = str(((stored or {}).get("source") or {}).get("text") or "")
    if not text and stored_text:
        text = stored_text
    legacy = stored is None
    if not text:
        return {"enabled": True, "mode": mode, "decision": "skipped_legacy",
                "status": "not_applicable", "legacy": True, "rule_id": rule_id,
                "error_code": "legacy_no_policy_ir",
                "message": "无结构化判据文本（旧规则），登记 legacy_no_policy_ir，不回溯阻断",
                "compiler_version": policy_ir.COMPILER_VERSION,
                "renderer_version": policy_ir.RENDERER_VERSION,
                "gate_version": policy_ir.GATE_VERSION, "ir_id": "", "ir_digest": "",
                "coverage": _empty_coverage(), "backtranslation": {},
                "blocking_reasons": [], "advisory": [], "reject": None,
                "source_sha256": "", "stale": False, "drift": False}
    if legacy:
        # 旧规则（开关开启前创建，无 _policy 记录）不回溯阻断：只做 advisory 观测，
        # 登记 legacy_no_policy_ir（规格 82 号 §10.7；P3 blocking 只作用于新规则）。
        observed = evaluate(text, mode="advisory")
        summary = {"enabled": True, "mode": mode,
                   "decision": "skipped_legacy",
                   "status": str(observed.get("status")), "legacy": True,
                   "stale": False, "drift": False, "rule_id": rule_id,
                   "ir_id": str(observed.get("ir_id") or ""),
                   "ir_digest": str(observed.get("ir_digest") or ""),
                   "rule_type": str(observed.get("rule_type") or ""),
                   "compiler_version": policy_ir.COMPILER_VERSION,
                   "renderer_version": policy_ir.RENDERER_VERSION,
                   "gate_version": policy_ir.GATE_VERSION,
                   "coverage": observed.get("coverage") or _empty_coverage(),
                   "backtranslation": observed.get("backtranslation") or {},
                   "plan": observed.get("plan") or {},
                   "blocking_reasons": observed.get("blocking_reasons") or [],
                   "advisory": (list(observed.get("advisory") or [])
                                + ["legacy_no_policy_ir"]),
                   "reject": observed.get("reject"),
                   "source_sha256": (observed.get("source") or {}).get("sha256") or "",
                   "error_code": "legacy_no_policy_ir",
                   "message": "旧规则无 _policy 记录（开关开启前创建），登记 "
                              "legacy_no_policy_ir，不回溯阻断发布"}
        return summary
    result = evaluate(text, mode=mode)
    drift = False
    stale = False
    if stored is not None:
        stored_sha = str(((stored.get("source") or {}).get("sha256") or ""))
        current_sha = policy_ir.sha256_text(text)
        if stored_sha and stored_sha == current_sha:
            recomputed = str(result.get("ir_digest") or "")
            if (stored.get("ir_digest") and recomputed
                    and str(stored.get("ir_digest")) != recomputed):
                drift = True
            if str(stored.get("status") or "") == "compiled" and \
                    str(result.get("status") or "") != "compiled":
                drift = True
        elif stored_text and stored_text != text:
            stale = True
    if drift:
        result = dict(result)
        drift_reason = {"gate": "policy_record_drift",
                        "detail": "slots_json['_policy'].ir_digest 与按原文重编译结果不一致"
                                  "（疑似人工改 IR / 审计漂移）"}
        result["blocking_reasons"] = list(result.get("blocking_reasons") or []) + [drift_reason]
        result["decision"] = "rejected" if mode == "blocking" else "advisory_pass"
        if mode == "advisory":
            result["advisory"] = list(result.get("advisory") or []) + ["policy_record_drift"]
    summary = {"enabled": True, "mode": mode, "decision": str(result.get("decision")),
               "status": str(result.get("status")), "legacy": legacy,
               "stale": stale, "drift": drift, "rule_id": rule_id,
               "ir_id": str(result.get("ir_id") or ""),
               "ir_digest": str(result.get("ir_digest") or ""),
               "rule_type": str(result.get("rule_type") or ""),
               "compiler_version": policy_ir.COMPILER_VERSION,
               "renderer_version": policy_ir.RENDERER_VERSION,
               "gate_version": policy_ir.GATE_VERSION,
               "coverage": result.get("coverage") or _empty_coverage(),
               "backtranslation": result.get("backtranslation") or {},
               "plan": result.get("plan") or {},
               "blocking_reasons": result.get("blocking_reasons") or [],
               "advisory": result.get("advisory") or [],
               "reject": result.get("reject"),
               "source_sha256": (result.get("source") or {}).get("sha256") or "",
               "error_code": "", "message": ""}
    if summary["decision"] == "rejected":
        code = _error_code(result) if not drift else ERROR_MISMATCH
        if drift:
            code = ERROR_MISMATCH
        summary["error_code"] = code
        summary["message"] = _error_message(result, code)
    return summary


# ---------------------------------------------------------------------------
# 调用点 3：RSI 候选释放前 advisory 校验（不改变结论）
# ---------------------------------------------------------------------------
def advisory_candidate_policy(candidate_id: str = "", rule_code: str = "",
                              action: str = "", after=None,
                              actor: str = "system") -> dict:
    """RSI 候选快照的 advisory 校验：只产出 `policy` 明细 + 审计，绝不改门禁结论。"""
    mode = current_mode()
    text = text_from_candidate(after)
    note = {"enabled": True, "mode": mode, "stage": "rsi_candidate",
            "candidate_id": candidate_id, "rule_code": rule_code, "action": action,
            "legacy": True, "decision": "not_applicable", "status": "not_applicable",
            "ir_id": "", "ir_digest": "", "coverage": _empty_coverage(),
            "backtranslation": {}, "blocking_reasons": [], "advisory": [],
            "compiler_version": policy_ir.COMPILER_VERSION,
            "renderer_version": policy_ir.RENDERER_VERSION,
            "gate_version": policy_ir.GATE_VERSION, "reject": None,
            "error_code": "no_structured_criterion",
            "message": "候选快照无可编译的判据文本，advisory 校验不适用（不改结论）"}
    if not text:
        return note
    result = evaluate(text, mode="advisory")  # 候选门始终 advisory（P1/P2 白名单未开）
    note.update({"legacy": False,
                 "decision": str(result.get("decision")),
                 "status": str(result.get("status")),
                 "error_code": str(result.get("error_code") or ""),
                 "message": str(result.get("message") or ""),
                 "ir_id": str(result.get("ir_id") or ""),
                 "ir_digest": str(result.get("ir_digest") or ""),
                 "rule_type": str(result.get("rule_type") or ""),
                 "coverage": result.get("coverage") or _empty_coverage(),
                 "backtranslation": result.get("backtranslation") or {},
                 "plan": result.get("plan") or {},
                 "blocking_reasons": result.get("blocking_reasons") or [],
                 "advisory": result.get("advisory") or [],
                 "reject": result.get("reject"),
                 "source_sha256": (result.get("source") or {}).get("sha256") or ""})
    return note


# ---------------------------------------------------------------------------
# 审计
# ---------------------------------------------------------------------------
def _audit_payload(result: dict, *, stage: str, rule_id: str = "",
                   candidate_id: str = "", legacy: bool = False,
                   stale: bool = False, drift: bool = False) -> dict:
    coverage = (result or {}).get("coverage") or _empty_coverage()
    backtranslation = (result or {}).get("backtranslation") or {}
    payload = {
        "payload_version": AUDIT_PAYLOAD_VERSION,
        "stage": stage,
        "switch": SWITCH_ENV,
        "enabled": bool((result or {}).get("enabled", True)),
        "mode": str((result or {}).get("mode") or current_mode()),
        "compiler_version": (result or {}).get("compiler_version")
        or policy_ir.COMPILER_VERSION,
        "renderer_version": (result or {}).get("renderer_version")
        or policy_ir.RENDERER_VERSION,
        "gate_version": (result or {}).get("gate_version") or policy_ir.GATE_VERSION,
        "status": str((result or {}).get("status") or ""),
        "decision": str((result or {}).get("decision") or ""),
        "rule_id": str(rule_id or ""),
        "candidate_id": str(candidate_id or ""),
        "rule_type": str((result or {}).get("rule_type") or ""),
        "ir_id": str((result or {}).get("ir_id") or ""),
        "ir_digest": str((result or {}).get("ir_digest") or ""),
        "source_sha256": str((result or {}).get("source_sha256")
                             or ((result or {}).get("source") or {}).get("sha256") or ""),
        "coverage": {"ratio": coverage.get("ratio", 0.0),
                     "declared_count": coverage.get("declared_count", 0),
                     "total": coverage.get("total", 9),
                     "gaps": list(coverage.get("gaps") or [])},
        "backtranslation": {"consistent": backtranslation.get("consistent"),
                            "ratio": backtranslation.get("ratio"),
                            "roundtrip_ok": backtranslation.get("roundtrip_ok"),
                            "span_ok": backtranslation.get("span_ok"),
                            "needs_human": backtranslation.get("needs_human")},
        "executor_reachable": ((result or {}).get("plan") or {}).get("executor_reachable"),
        "blocking_reasons": _jsonable((result or {}).get("blocking_reasons") or []) or [],
        "advisory": list((result or {}).get("advisory") or []),
        "error_code": str((result or {}).get("error_code") or ""),
        "legacy": bool(legacy or (result or {}).get("legacy")),
        "stale": bool(stale or (result or {}).get("stale")),
        "drift": bool(drift or (result or {}).get("drift")),
        "reject": _jsonable((result or {}).get("reject") or None),
    }
    return _jsonable(payload) or payload


def audit_events(result: dict, *, stage: str, rule_id: str = "",
                 candidate_id: str = "", actor: str = "system",
                 legacy: bool = False, stale: bool = False,
                 drift: bool = False) -> list:
    """构造审计事件列表 ``[(action, payload), ...]``；由调用点负责写库。

    - create：编译事件 `policy.compile` + （编译成功时）反译事件 `policy.backtranslation`；
    - publish：门禁事件 `policy.backtranslation`；编译失败时记 `policy.compile`；
    - rsi：编译失败 `policy.compile`，否则 `policy.backtranslation`。
    """
    payload = _audit_payload(result, stage=stage, rule_id=rule_id,
                             candidate_id=candidate_id, legacy=legacy,
                             stale=stale, drift=drift)
    status = str((result or {}).get("status") or "")
    events = []
    if stage == "create":
        events.append(("policy.compile", payload))
        if status == "compiled":
            events.append(("policy.backtranslation", dict(payload)))
    elif stage == "publish":
        events.append(("policy.compile" if status == "rejected"
                       else "policy.backtranslation", payload))
    else:  # rsi / 其他
        events.append(("policy.compile" if status == "rejected"
                       else ("policy.backtranslation" if status == "compiled"
                             else "policy.compile"), payload))
    return events


def write_audit(action: str, payload: dict, *, actor: str = "system",
                object_id: str = "") -> bool:
    """独立事务写审计（policy 审计为旁路留痕；失败只返回 False，由调用点记日志）。"""
    try:
        from .. import repositories as _R
        after = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        _R.audit_logs.log(actor=str(actor or "system"), action=str(action),
                          object=str(object_id or ""), after=after[:4000])
        return True
    except Exception:  # noqa: BLE001 - 审计失败由调用点 warning 留痕，不静默
        _LOG.warning("policy compiler audit write failed action=%s", action,
                     exc_info=True)
        return False
