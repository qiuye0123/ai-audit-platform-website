"""规则 IR（统一中间表示）与可执行性度量。

IR 字段（可选但推荐）：
  object 对象 / metric 指标 / operator 算子 / threshold 阈值 / range {lo,hi}
  unit 单位 / scope 作用范围 / evidence_required 证据要求[]
  exceptions 例外[] / applicable_types 适用文件类型[] / severity 严重度
  criterion 文字判据 / keywords[] / pattern / require / forbid / require_any

R3/R4/R5 typed 条件（见 rule_ir2）：
  R3 evidence_contract[] + semantic{...}
  R4 relations[]{left,right,compare,across,self_consistency}
  R5 procedure{kind,requirements[]}
  execution_mode / executable / contract_error_details

可执行性等级：
  deterministic 可判定（有结构化阈值/关键词/正则）
  semantic      半可判定（自然语言判据，需模型判定 + 引文核验）
  unjudgeable   不可判定（无判据/纯主观/模糊）
"""
import re
from typing import Any

# L5 段1（2026-11-21）区间解析新增 op="range"（value="lo-hi"，辅助字段 lo/hi/range）。
# 该算子语义为**闭区间** lo <= x <= hi；执行侧复用既有比较（ruleexec.judge_limit），
# 不新增执行器（见 ruleexec.py::_range_bounds / judge_limit）。
OPS = {"<=", ">=", "=", "<", ">", "!=", "in", "not_in", "contains", "not_contains",
       "range"}
# interval 算子错误码：消费方（前端/CLI/测试）按 code 区分具体非法原因。
ERR_RANGE_BOUNDS_MISSING = "range_bounds_missing"
ERR_RANGE_LO_GT_HI = "range_lo_gt_hi"
ERR_RANGE_VALUE_INVALID = "range_value_invalid"
# 段1 区间值归一口径：`lo-hi`（也接受 ~ ～ 至 到 — – － 分隔）
_RANGE_VALUE_RE = re.compile(
    r"^\s*(-?\d+(?:\.\d+)?)\s*[-~～〜至到—–－]\s*(-?\d+(?:\.\d+)?)\s*$")
VAGUE = ("合理", "适当", "尽量", "必要时", "酌情", "原则上", "良好", "足够", "美观", "合适")
ACTION_WORDS = ("必须", "不得", "禁止", "应当", "应", "至少", "不超过", "不得超过", "需", "须")
IMPLICIT_KEYS = ("require", "forbid", "require_any", "pattern", "keywords",
                 "required_docs", "required_documents", "record_field", "record_fields",
                 "fields", "steps", "operations", "format", "format_rules", "relations",
                 "relation", "left", "right", "objects", "action", "frequency", "terms",
                 "procedure", "requirements",
                 # P0-7：生成判据的结构化承接字段（criteria_text/checkpoints 不得被当成
                 # 「缺少文字判据与结构化条件」丢弃；编译器显式承接，交 semantic_stub/人工）
                 "criteria_text", "checkpoints", "criteria_checkpoints")
_KNOWN_EXT = {"xlsx", "xls", "docx", "doc", "pdf", "txt", "csv", "md", "json"}


def _num(v: Any) -> float | None:
    try:
        return float(str(v).replace(",", "").strip())
    except Exception:
        return None


def _range_pair(value: Any) -> tuple:
    """`value="lo-hi"`（段1 区间归一口径）→ (lo, hi)；不可解析 → (None, None)。"""
    m = _RANGE_VALUE_RE.match(str(value if value is not None else ""))
    if not m:
        return (None, None)
    return (float(m.group(1)), float(m.group(2)))


def resolve_range_bounds(slots: dict) -> dict:
    """统一解析区间上下限（兼容段1 的三种写法，任一可解析即可）。

    - `range`: {"lo": 10, "hi": 20}（段1 辅助字段）
    - `lo` / `hi`（段1 辅助字段平铺）
    - `value` / `threshold` = "10-20"（段1 归一字符串；也接受 ~ ～ 至 到 等分隔）

    返回 {lo, hi, ok, source}；ok 表示上下限都解析成功且 lo <= hi。执行侧
    （ruleexec.judge_limit）复用同一解析口径，避免校验与执行两套规则。
    """
    slots = dict(slots or {})
    rng = slots.get("range") if isinstance(slots.get("range"), dict) else {}
    lo = _num(rng.get("lo")) if rng.get("lo") not in (None, "") else None
    hi = _num(rng.get("hi")) if rng.get("hi") not in (None, "") else None
    source = "range" if (lo is not None or hi is not None) else ""
    if lo is None and slots.get("lo") not in (None, ""):
        lo = _num(slots.get("lo"))
        source = source or "lo"
    if hi is None and slots.get("hi") not in (None, ""):
        hi = _num(slots.get("hi"))
        source = source or "hi"
    if lo is None or hi is None:
        v_lo, v_hi = _range_pair(slots.get("value", slots.get("threshold")))
        if lo is None:
            lo = v_lo
        if hi is None:
            hi = v_hi
        if v_lo is not None or v_hi is not None:
            source = source or "value"
    ok = lo is not None and hi is not None and lo <= hi
    return {"lo": lo, "hi": hi, "ok": ok, "source": source}


def _enum_values(slots: dict) -> list:
    """枚举取值集合（values/enum/options）——与引擎 rule_ir2 同源的 typed 客体。"""
    raw = slots.get("values")
    if raw is None:
        raw = slots.get("enum")
    if raw is None:
        raw = slots.get("options")
    if isinstance(raw, dict):
        raw = list(raw.keys())
    elif isinstance(raw, str):
        raw = [raw]
    if not isinstance(raw, (list, tuple, set)):
        return []
    return [str(x).strip() for x in raw if str(x).strip()]


def validate_ir(slots: dict) -> dict:
    """校验并规范化规则 IR；返回 {ok, errors, warnings, normalized}。"""
    slots = dict(slots or {})
    errors, warnings = [], []
    norm = {}

    metric = str(slots.get("metric") or "").strip()
    op = str(slots.get("operator") or slots.get("op") or "").strip()
    try:
        from ..engine import rule_ir2 as _ri2
        op = _ri2.normalize_operator(op) or op
    except Exception:
        pass
    value = slots.get("threshold", slots.get("value"))
    rng = slots.get("range") or {}
    crit = str(slots.get("criterion") or slots.get("criteria_text") or "").strip()
    unit = str(slots.get("unit") or "").strip()

    if metric:
        norm["metric"] = metric
    if op:
        if op not in OPS:
            errors.append(f"算子不支持：{op}（可用 {', '.join(sorted(OPS))}）")
        else:
            norm["operator"] = op
    if value not in (None, ""):
        num = _num(value)
        if num is None and op in {"<=", ">=", "=", "<", ">"}:
            errors.append("阈值必须是数字")
        else:
            norm["threshold"] = value
    if isinstance(rng, dict) and op != "range" and (
            rng.get("lo") is not None or rng.get("hi") is not None):
        lo, hi = _num(rng.get("lo")), _num(rng.get("hi"))
        if lo is None and hi is None:
            errors.append("范围上下限都不是数字")
        elif lo is not None and hi is not None and lo > hi:
            errors.append("范围下限大于上限")
        else:
            norm["range"] = {"lo": lo if lo is not None else None, "hi": hi if hi is not None else None}
    if op == "range":
        # L5 段1 区间算子：闭区间 lo <= x <= hi；上下限可来自 range{lo,hi}/lo+hi/value="lo-hi"。
        # 非法形态给稳定错误码，便于前端/CLI/测试区分「缺上下限 / 下限>上限 / 值不可解析」。
        _rb = resolve_range_bounds(slots)
        if _rb["lo"] is None or _rb["hi"] is None:
            _raw_value = slots.get("value", slots.get("threshold"))
            if not _rb["source"] and _raw_value not in (None, ""):
                errors.append(
                    f"范围算子 range 的 value 无法解析为 lo-hi：{_raw_value!r}"
                    f"[{ERR_RANGE_VALUE_INVALID}]")
            else:
                errors.append(
                    "范围算子 range 缺少可解析的上下限："
                    "需 range.lo/hi、lo/hi 或 value='lo-hi'（闭区间 lo<=x<=hi）"
                    f"[{ERR_RANGE_BOUNDS_MISSING}]")
        elif _rb["lo"] > _rb["hi"]:
            errors.append(
                f"范围算子 range 下限大于上限（lo={_rb['lo']:g} > hi={_rb['hi']:g}）"
                f"[{ERR_RANGE_LO_GT_HI}]")
        else:
            norm["range"] = {"lo": _rb["lo"], "hi": _rb["hi"]}
            norm["lo"], norm["hi"] = _rb["lo"], _rb["hi"]
            if norm.get("threshold") in (None, ""):
                norm["threshold"] = f"{_rb['lo']:g}-{_rb['hi']:g}"
    if metric and not (norm.get("threshold") is not None or norm.get("range")):
        warnings.append("有指标但缺少阈值/范围，无法做确定性判定")
    if metric and not unit:
        warnings.append("有指标但未填单位，可能造成量纲误判")
    if crit:
        norm["criterion"] = crit
    elif not any(k in slots for k in IMPLICIT_KEYS):
        warnings.append("缺少文字判据与结构化条件")
    for k in ("object", "scope", "severity"):
        if str(slots.get(k) or "").strip():
            norm[k] = str(slots[k]).strip()
    er = slots.get("evidence_required")
    if isinstance(er, str):
        er = [x.strip() for x in er.split(",") if x.strip()]
    if isinstance(er, list):
        norm["evidence_required"] = [str(x).strip() for x in er if str(x).strip()]
    exc = slots.get("exceptions")
    if isinstance(exc, str):
        exc = [x.strip() for x in exc.split(",") if x.strip()]
    if isinstance(exc, list):
        norm["exceptions"] = [str(x).strip() for x in exc if str(x).strip()]
    types = slots.get("applicable_types")
    if isinstance(types, str):
        types = [x.strip() for x in types.split(",") if x.strip()]
    if isinstance(types, list):
        norm["applicable_types"] = [str(x).strip() for x in types if str(x).strip()]
    for k in IMPLICIT_KEYS:
        if slots.get(k):
            norm[k] = slots[k]
    for w in VAGUE:
        if w in crit and not (norm.get("threshold") is not None or norm.get("range")):
            warnings.append(f"判据含模糊词「{w}」，且没有阈值，可能不可判定")
            break
    return {"ok": not errors, "errors": errors, "warnings": warnings, "normalized": norm}


def classify_executability(slots: dict) -> dict:
    """A1：可执行性度量。返回 {level, score, missing_evidence, reasons, suggestions}。"""
    slots = dict(slots or {})
    crit = str(slots.get("criterion") or slots.get("criteria_text") or "").strip()
    metric = str(slots.get("metric") or "").strip()
    op = str(slots.get("operator") or slots.get("op") or "").strip()
    try:
        from ..engine import rule_ir2 as _ri2
        op = _ri2.normalize_operator(op) or op
    except Exception:
        pass
    value = slots.get("threshold", slots.get("value"))
    rng = slots.get("range") or {}
    impl = any(slots.get(k) for k in ("require", "forbid", "require_any", "pattern", "keywords"))
    missing, reasons, suggestions = [], [], []

    structured = bool(metric and op in OPS and (
        value not in (None, "") or rng
        or (op in ("in", "not_in") and _enum_values(slots))))
    partial = bool(metric and op in OPS and not (value not in (None, "") or rng))
    _vague_only = bool(crit) and any(w in crit for w in VAGUE) and not structured and not partial and not impl
    if structured:
        level, score = "deterministic", 0.9
        reasons.append("有指标+算子+阈值/范围，可确定性执行")
        if not slots.get("unit"):
            missing.append("单位")
            suggestions.append("补充单位（如 ℃/元/%）")
        if not slots.get("evidence_required"):
            missing.append("证据要求")
            suggestions.append("补充证据要求（如报价表/合同条款）")
    elif partial:
        level, score = "semantic", 0.5
        reasons.append("有指标+算子但缺阈值/范围，暂无法确定性判定")
        missing.append("阈值/范围")
        suggestions.append("补充阈值或范围；否则只能按语义判定")
    elif impl:
        level, score = "deterministic", 0.8
        reasons.append("有结构化条件（关键词/正则/必需项），可确定性执行")
    elif _vague_only:
        level, score = "unjudgeable", 0.3
        reasons.append("判据含模糊词且无阈值，无法判定")
        missing.append("可判定要素")
        suggestions.append("把模糊表述换成可核对的条件或阈值")
    elif crit and (any(w in crit for w in ACTION_WORDS) or len(crit) >= 12 or any(k in crit for k in ("判据", "核查", "比对", "是否"))):
        level, score = "semantic", 0.6
        reasons.append("自然语言判据（含义务性表述），需模型判定+引文核验")
        if not slots.get("evidence_required"):
            missing.append("证据要求")
            suggestions.append("补充证据要求，减少模型臆断")
        if any(w in crit for w in VAGUE):
            suggestions.append("判据含模糊词，建议量化")
    elif crit:
        level, score = "unjudgeable", 0.3
        reasons.append("判据缺少可判定要素（对象/阈值/义务性表述）")
        missing.append("可判定要素")
        suggestions.append("补充对象、阈值或明确判据；或用关键词/正则表达")
    else:
        level, score = "unjudgeable", 0.1
        reasons.append("无判据、无结构化条件")
        missing.append("判据")
        suggestions.append("至少提供文字判据或结构化条件")

    ir = validate_ir(slots)
    if ir["errors"]:
        suggestions.append("IR 校验错误：" + "；".join(ir["errors"]))
    return {"level": level, "score": score, "missing_evidence": missing,
            "reasons": reasons, "suggestions": suggestions,
            "ir": ir}


# ================= RuleIR v2：自然语言规则也编译，不再只做“可执行性标签” =================
import re as _re

from .rule_taxonomy import nature_of as _nature_of
from . import rule_ir2 as _typed


def _infer_subject(crit: str, slots: dict) -> str:
    for k in ("subject", "object", "role", "metric", "record_field"):
        v = str(slots.get(k) or "").strip()
        if v:
            return v[:120]
    m = _re.match(r"\s*([^，。；;]{2,30}?)(?:必须|应当|应|不得|禁止|需|须|至少|不超过)", crit or "")
    return (m.group(1).strip() if m else (crit or "")[:30])


def _scope_tokens(value) -> list:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        raw = [str(x).strip() for x in value if str(x).strip()]
    else:
        raw = [x.strip() for x in str(value).replace("，", ",").replace("、", ",")
               .replace("；", ";").replace(";", ",").split(",") if x.strip()]
    return list(dict.fromkeys(raw))


def _applicability(slots: dict) -> dict:
    """文件/业务适用范围：只认 applicable_types/applicable_when。

    ``slots.scope`` 是执行口径（如“中心温度”），不能当适用范围；这与
    rule.scope_route 的口径一致，避免“未声明作用域”的规则被当成全量。
    """
    types = _scope_tokens(slots.get("applicable_types")) + _scope_tokens(slots.get("doc_types"))
    when = _scope_tokens(slots.get("applicable_when")) + _scope_tokens(slots.get("applicability"))
    types = list(dict.fromkeys(types))
    when = list(dict.fromkeys(when))
    return {"types": types, "when": when, "declared": bool(types or when)}


def _tax_errors(slots: dict, subs: list) -> list:
    errors = []
    _tax_subs = list(subs) if subs else [slots]
    for _sub in _tax_subs:
        if isinstance(_sub, dict) and str(_sub.get("tool") or "") in ("tax_convert", "tax_compare"):
            if not str(_sub.get("rate_source") or slots.get("rate_source") or "").strip():
                errors.append("税额工具缺少税率来源 rate_source")
            if not str(_sub.get("tax_status_source") or slots.get("tax_status_source") or "").strip():
                errors.append("税额工具缺少含税口径来源 tax_status_source")
            if not str(_sub.get("direction_source") or slots.get("direction_source") or "").strip():
                errors.append("税额工具缺少方向来源 direction_source")
            if not str(_sub.get("currency_source") or slots.get("currency_source") or "").strip():
                errors.append("税额工具缺少币种来源 currency_source")
    return list(dict.fromkeys(errors))


def _checkpoints_of(slots: dict) -> list:
    """生成判据的结构化检查点（checkpoints/criteria_checkpoints）显式承接，不丢信息。

    P0-7：checkpoints 是 LLM 生成判据的「结构化检查点」，旧编译器不消费也不承接，
    导致信息只留在 slots 里。这里原样承接（只做 list 归一，不改写内容）。
    """
    raw = None
    for key in ("checkpoints", "criteria_checkpoints", "checks"):
        if slots.get(key) not in (None, "", []):
            raw = slots.get(key)
            break
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return [x for x in raw if x not in (None, "")]
    if isinstance(raw, dict):
        return [raw]
    return [raw]


def _typed_predicate(relations: list, procedure: dict, requirements: list) -> str:
    """没有 criterion 时，用 typed 条件生成可读 predicate（不回写自由文本）。"""
    parts = []
    for rel in relations or []:
        parts.append(f"{rel.get('left') or '?'} 与 {rel.get('right') or '?'} {rel.get('compare') or 'equal'}")
    reqs = list(procedure.get("requirements") or []) + list(requirements or [])
    for req in reqs:
        kind = str(req.get("kind") or "")
        if kind in ("field_present", "term_present"):
            parts.append(f"必须包含{req.get('field') or req.get('term') or ''}")
        elif kind in ("signature", "approval"):
            signer = str(req.get("signer") or "")
            parts.append(f"{signer + '必须' if signer else '必须'}{req.get('field') or '签字'}")
        elif kind == "frequency":
            parts.append(f"{req.get('period') or req.get('frequency') or ''}"
                         f"至少{req.get('min_count') or 1}次{req.get('action') or ''}")
        elif kind == "step_present":
            parts.append("步骤：" + "、".join(req.get("steps") or []))
        elif kind == "sequence":
            parts.append(f"{req.get('field') or ''}必须连续")
        elif kind == "format":
            parts.append("格式：" + str(req.get("format") or req.get("pattern") or ""))
        elif kind == "pattern":
            parts.append("格式：" + str(req.get("pattern") or ""))
        elif kind == "required_terms":
            parts.append("必须包含：" + "、".join(req.get("terms") or []))
        elif kind == "required_any_terms":
            parts.append("至少包含：" + "、".join(req.get("terms") or []))
        elif kind == "forbidden_terms":
            parts.append("禁止出现：" + "、".join(req.get("terms") or []))
        elif kind == "no_empty":
            parts.append(f"{req.get('field') or ''}不得为空")
    return "；".join([p for p in parts if p.strip("； ")])[:500]


def compile_rule(slots: dict, category: str = "", rclass: str = "", name: str = "") -> dict:
    """把自然语言/半结构化规则编译为 typed IR。

    R3/R4/R5 不能只留 criterion 自由文本：
    - R3 语义/证据：evidence_contract + semantic payload + 确定性要素
    - R4 关系/一致：relations（left/right/compare/across）
    - R5 记录/程序：procedure.requirements（字段/签字/频次/步骤/格式）

    ``contract_errors`` 是可读阻断说明；``contract_error_details`` 带 code/field/hint。
    ``executable=False`` 的 IR 不允许直接执行自由文本。
    """
    slots = dict(slots or {})
    crit = str(slots.get("criterion") or slots.get("criteria_text") or "").strip()
    metric = str(slots.get("metric") or "").strip()
    value = slots.get("value", slots.get("threshold"))
    op = str(slots.get("op") or slots.get("operator") or "").strip()
    try:
        from ..engine import rule_ir2 as _ri2
        op = _ri2.normalize_operator(op) or op
    except Exception:
        pass
    nature = _nature_of(category, "threshold" if metric and value not in (None, "") else "obligation")
    effect = "require"
    if any(k in crit for k in ("不得", "禁止", "严禁")):
        effect = "forbid"
    elif any(k in crit for k in ("建议", "优先", "宜")):
        effect = "recommend"
    subject = _infer_subject(crit, slots)
    app = _applicability(slots)
    scope = str(slots.get("scope") or slots.get("applicable_when") or "")
    trigger = str(slots.get("trigger") or slots.get("applicable_when") or scope)
    exceptions = slots.get("exceptions") or []
    if isinstance(exceptions, str):
        exceptions = [exceptions]
    tests = slots.get("tests") if isinstance(slots.get("tests"), dict) else {}
    subs = slots.get("subrequirements") or slots.get("criteria_list") or []
    if isinstance(subs, list):
        subs = [dict(x) for x in subs if isinstance(x, dict)]
    else:
        subs = []

    # ---------------------------------------------------------- 证据（typed）
    _ev_scopes = _scope_tokens(slots.get("evidence_scope") or slots.get("evidence_scopes"))
    evidence = _typed.parse_evidence(
        slots.get("required_evidence") or slots.get("evidence_required")
        or slots.get("evidence") or "",
        default_scope=(_ev_scopes[0] if _ev_scopes else "document"))
    evidence_text = _typed.evidence_string(evidence)
    evidence_ok = bool(evidence)

    # ---------------------------------------------------------- 旧口径（兼容）
    cls_slots = dict(slots)
    if evidence_text and not cls_slots.get("evidence_required"):
        cls_slots["evidence_required"] = evidence_text
    executable_old = classify_executability(cls_slots)
    structured = bool(
        any(slots.get(k) for k in ("require", "forbid", "require_any", "pattern", "keywords"))
        or (metric and op in OPS and (value not in (None, "") or bool(slots.get("range"))))
        # T-112：enum(values) 是 typed 结构化客体，不是自由文本
        or (metric and op in ("in", "not_in") and _enum_values(slots))
    )
    complete = bool(
        crit or (metric and value not in (None, "")) or structured or subs
        or slots.get("relations") or slots.get("relation")
        or (slots.get("left") and slots.get("right")) or slots.get("objects")
        or slots.get("record_field") or slots.get("record_fields")
        or slots.get("required_docs") or slots.get("steps")
        or slots.get("operations") or slots.get("process_steps")
        or slots.get("required_steps") or slots.get("format_rules") or slots.get("format")
        or slots.get("role") or slots.get("qualification")
        or slots.get("equipment") or slots.get("item") or slots.get("label_required")
        or slots.get("cited") or (str(category or "") == "citation" and slots.get("source"))
        or (isinstance(slots.get("procedure"), dict)
            and (slots.get("procedure") or {}).get("requirements"))
        or (isinstance(slots.get("procedure"), list) and slots.get("procedure"))
        or slots.get("requirements")
    )
    # T-112：enum(values)/keyword(require/forbid) 是有确定判据的结构化条件，
    # 与「metric+阈值」同为 deterministic，不再被误判 needs_structure 而无法发布。
    deterministic = bool((metric and value not in (None, "")) or (structured and metric))
    scope_ok_old = bool(scope or slots.get("applicable_types") or slots.get("applicable_when"))
    if deterministic:
        old_level = "deterministic"
    elif (subs or crit) and evidence_ok and scope_ok_old:
        old_level = "semantic_complete"
    else:
        old_level = "needs_structure"

    # ---------------------------------------------------------- typed 条件
    family = _typed.family_of(category, nature)
    _rc_hint = str(rclass or "").strip()
    if (str(category or "").strip() not in _typed.CATEGORY_FAMILY
            and _rc_hint in ("R3", "R4", "R5")):
        # 自定义类别没有 12 类映射时，允许用显式执行等级声明 R3/R4/R5。
        family = _rc_hint
        nature = {"R3": "evidence", "R4": "relational", "R5": "procedural"}[_rc_hint]
    requirements = []
    semantic = {}
    relations = []
    procedure = {}
    typed_warnings = []
    relation_info = None
    try:
        if family == "R3":
            requirements = _typed.parse_requirements(slots, category, crit)
            semantic = _typed.parse_semantic(
                crit, subject, effect, evidence,
                str(slots.get("on_insufficient") or slots.get("fallback") or "abstain"))
        elif family == "R4":
            # P0-7：严格口径解析 typed relations；解析不出合法关系 → relations=[] +
            # 结构化警告，由下面显式标 semantic_stub（绝不静默伪造 1 条碎片 relation）。
            relation_info = _typed.parse_relations_info(slots, category, crit)
            relations = list(relation_info.get("relations") or [])
            # L2 structured_promotable 自一致关系（2026-11-23，FB-19/20）：
            # 显式 relations 声明 self_consistency=True（同一对象跨出现比对）时，typed 解析层
            # 的合法性过滤只保留 left/right/compare/across，不透传该标记；执行器拿不到标记会
            # 把 left==right 退化成「取同一 fact 比较」（恒真）。这里按显式声明回填，仅影响
            # 自行声明该标记的规则，未声明者行为不变。
            _sc_raw = slots.get("relations")
            if _sc_raw is None:
                _sc_raw = slots.get("relation")
            if isinstance(_sc_raw, dict):
                _sc_raw = [_sc_raw]
            if slots.get("self_consistency") or any(
                    isinstance(x, dict) and x.get("self_consistency")
                    for x in (_sc_raw or [])):
                for _rel in relations:
                    if _rel.get("left") and _rel.get("left") == _rel.get("right"):
                        _rel["self_consistency"] = True
            typed_warnings = list(relation_info.get("warnings") or [])
        elif family == "R5":
            procedure = _typed.parse_procedure(slots, category, crit)
            typed_warnings = list(procedure.get("warnings") or [])
        else:
            requirements = _typed.parse_requirements(slots, category, crit)
            # R1/R2 没有确定性条件但有语义判据：也生成 typed semantic payload，
            # 保证 execution_mode=semantic 的 IR 真的可执行，而不是空壳。
            if crit and not (metric and value not in (None, "")) and not structured:
                semantic = _typed.parse_semantic(
                    crit, subject, effect, evidence,
                    str(slots.get("on_insufficient") or slots.get("fallback") or "abstain"))
    except Exception as exc:  # noqa: BLE001  typed 编译失败不能让规则静默变成可执行
        typed_warnings.append(f"typed_compile_failed:{type(exc).__name__}")

    if family == "R3":
        execution_mode = "semantic" if semantic else ("deterministic" if requirements else "none")
    elif family == "R4":
        if relations:
            execution_mode = "relational"
        else:
            # 不可确定性执行：criteria_text/checkpoints 显式承接，交 agent-judge/人工；
            # 不得因为「有 criterion 文本」就伪造 relations 接错执行器。
            execution_mode = "semantic_stub"
            typed_warnings.append(
                "semantic_stub：未解析出合法 typed relations（判据为散文/缺 left-right 对象），"
                "该规则不可确定性执行；relations=[] 不伪造，需 agent-judge 或人工执行")
    elif family == "R5":
        execution_mode = "procedural" if (procedure.get("requirements")) else "none"
    elif family in ("R1", "R2", ""):
        execution_mode = ("deterministic"
                          if (metric and value not in (None, "")) or structured
                          else ("semantic" if semantic else "none"))
    else:
        execution_mode = "deterministic" if requirements else "none"

    on_insufficient = str(slots.get("on_insufficient") or slots.get("fallback") or "abstain")
    contract = _typed.build_contract({
        "family": family,
        "criterion": crit,
        "evidence": evidence,
        "scope_declared": app["declared"],
        "relations": relations,
        "procedure": procedure,
        "semantic": semantic,
        "requirements": requirements,
        "structured": structured,
        "metric": metric,
        "has_value": bool(value not in (None, "") or slots.get("range")),
        "complete": complete or bool(subs),
        "on_insufficient": on_insufficient,
        "old_level": old_level,
        "tax_errors": _tax_errors(slots, subs),
        "warnings": typed_warnings,
    })

    # T-112：enum/keyword 的 typed 三段式与数值三类同源编译（引擎 rule_ir2 单一事实源），
    # 供 predicate/operator/typed 字段留痕；编译失败不影响既有数值规则。
    three_segment = None
    try:
        from ..engine import rule_ir2 as _ri2_seg
        _seg = _ri2_seg.compile_three_segment(slots)
        if _seg.get("ok"):
            three_segment = _seg.get("ir")
    except Exception:
        three_segment = None
    if not op and three_segment:
        op = str(three_segment.get("operator") or op)

    predicate = crit
    if not predicate and metric and value not in (None, "") and op:
        predicate = f"{metric} {op} {value}"
    if not predicate and three_segment:
        _seg_obj = three_segment.get("object") or {}
        _seg_dt = (three_segment.get("subject") or {}).get("datatype")
        if _seg_dt == "enum":
            predicate = f"{metric} {op or three_segment.get('operator') or 'in'} " \
                        f"{'、'.join(_seg_obj.get('values') or [])}"
        elif _seg_obj.get("keywords"):
            _mode = "必须包含" if three_segment.get("operator") == "contains" else "禁止出现"
            predicate = f"{metric} {_mode}{'、'.join(_seg_obj.get('keywords') or [])}"
    if not predicate:
        predicate = _typed_predicate(relations, procedure, requirements)

    if family == "R4" and relations and not subject:
        subject = str(relations[0].get("left") or "")
    if family == "R5" and procedure.get("subject") and not subject:
        subject = str(procedure.get("subject") or "")

    validation = validate_ir(slots)
    _norm_ir = validation.get("normalized") or {}
    _ir_range = _norm_ir.get("range") or (
        slots.get("range") if isinstance(slots.get("range"), dict) else {})
    warnings = list(dict.fromkeys(
        list(validation.get("warnings") or []) + list(contract.get("warnings") or [])))
    missing = list(dict.fromkeys(
        list(executable_old.get("missing_evidence") or []) + list(contract.get("missing") or [])))
    suggestions = list(dict.fromkeys(
        list(executable_old.get("suggestions") or []) + list(contract.get("suggestions") or [])))

    checkpoints = _checkpoints_of(slots)
    semantic_stub = bool(family == "R4" and not relations)
    if family == "R4":
        if contract.get("executable"):
            evaluation_kind = "deterministic"
            executability = "deterministic"
        elif semantic_stub and (crit or checkpoints):
            # 语义可判定（Tier-S）：无 typed relation、不可确定性执行，但判据/检查点已承接，
            # 交 agent-judge 或人工；不是 unjudgeable（有判据就不该说「不可判定」）。
            evaluation_kind = "semantic"
            executability = "semantic"
        else:
            evaluation_kind = "semantic"
            executability = "unjudgeable"
    elif family == "R5":
        evaluation_kind = "deterministic" if contract.get("executable") else "semantic"
        executability = "deterministic" if contract.get("executable") else "unjudgeable"
    elif family == "R3":
        evaluation_kind = "semantic" if semantic else "deterministic"
        executability = "semantic" if semantic else (
            "deterministic" if requirements else executable_old.get("level"))
    else:
        evaluation_kind = str(slots.get("evaluation_kind") or (
            "deterministic" if (metric and value not in (None, "")) or structured
            else "semantic"))
        executability = executable_old.get("level")

    ir = {
        "version": "ir-v2",
        "code": str(slots.get("rule_code") or slots.get("code") or ""),
        "name": name or "",
        "category": str(category or ""),
        "rclass": str(rclass or slots.get("rclass") or ""),
        "rule_family": family,
        "nature": nature,
        "effect": effect,
        "subject": subject,
        "predicate": predicate,
        "metric": metric,
        "operator": op,
        "threshold": value,
        # L5 段1 区间算子：IR 显式携带归一后的 range/lo/hi（闭区间 lo<=x<=hi）。
        # 执行侧 rule_ir2._eval_limit → ruleexec.judge_limit 直接消费；旧算子不受影响。
        "range": ({"lo": _ir_range.get("lo"), "hi": _ir_range.get("hi")}
                  if _ir_range and (_ir_range.get("lo") is not None
                                    or _ir_range.get("hi") is not None) else None),
        "lo": _ir_range.get("lo") if _ir_range else None,
        "hi": _ir_range.get("hi") if _ir_range else None,
        "unit": str(slots.get("unit") or ""),
        # T-112 typed 三段式：enum 值集合 / keyword 关键字与数值阈值同为结构化客体
        "values": _enum_values(slots),
        "keywords": [str(x) for x in
                     (((three_segment or {}).get("object") or {}).get("keywords") or [])],
        "three_segment": three_segment,
        "scope": scope,
        "scope_declared": app["declared"],
        "applicable_types": app["types"],
        "applicable_when": app["when"],
        "trigger": trigger,
        "subject_type": str(slots.get("subject_type") or subject),
        "combination": str(slots.get("combination") or slots.get("combine") or "all"),
        "evaluation_kind": evaluation_kind,
        "on_insufficient": on_insufficient,
        "terms": slots.get("terms") or [],
        "exceptions": [str(x) for x in exceptions if str(x).strip()],
        "evidence_required": evidence_text,
        "evidence_contract": evidence,
        "semantic": semantic,
        # P0-7：criteria_text/checkpoints 显式承接（生成判据的结构化信息不丢；即使不可
        # 确定性执行，也保留判据文本/检查点供 agent-judge/人工执行与审计）。
        "criteria_text": crit,
        "checkpoints": checkpoints,
        "semantic_stub": semantic_stub,
        "compile_warnings": list(dict.fromkeys(typed_warnings)),
        "relations": relations,
        "procedure": procedure,
        "requirements": requirements,
        "execution_mode": execution_mode,
        "executable": bool(contract.get("executable")),
        "free_text_only": bool(contract.get("free_text_only")),
        "severity": str(slots.get("severity") or rclass or ""),
        "tests": tests,
        "subrequirements": subs,
        "complete": complete or bool(subs),
        "execution_level": contract.get("execution_level"),
        "publishable": bool(contract.get("publishable")),
        "contract_errors": list(contract.get("errors") or []),
        "contract_error_details": list(contract.get("issues") or []),
        "missing": missing,
        "suggestions": suggestions,
        "warnings": warnings,
        "executability": executability,
        "typed_ir": {
            "family": family,
            "family_label": _typed.family_label(family),
            "execution_mode": execution_mode,
            "executable": bool(contract.get("executable")),
            "free_text_only": bool(contract.get("free_text_only")),
            "evidence_count": len(evidence),
            "relation_count": len(relations),
            "requirement_count": len(requirements) + len(procedure.get("requirements") or []),
            "checkpoint_count": len(checkpoints),
            "semantic_stub": semantic_stub,
            "criteria_carried": bool(crit),
            "kind": str(procedure.get("kind") or ("relational" if family == "R4"
                                                  else ("semantic" if semantic else ""))),
        },
        "execution_hints": __import__('app.services.execution_plan', fromlist=['derive']).derive(slots),
    }
    return ir


def execute_ir(ir: dict, text: str = "", facts=None, judge=None) -> dict:
    """执行 typed IR（R3 语义/证据、R4 关系/一致、R5 记录/程序、R1 数值）。"""
    return _typed.execute_ir(ir, text=text, facts=facts, judge=judge)


def execute_rule(slots: dict, text: str = "", facts=None, judge=None,
                 category: str = "", rclass: str = "", name: str = "") -> dict:
    """编译并执行一条规则槽位；便于 CLI/测试在不落库时验证可执行性。"""
    return execute_ir(compile_rule(slots, category, rclass, name),
                      text=text, facts=facts, judge=judge)


def semantic_payload(ir: dict) -> dict:
    """agent-judge 的 typed payload；不含可被误当确定性条件的自由文本执行逻辑。"""
    return _typed.semantic_payload(ir)


def prompt_of(ir: dict) -> str:
    """给 agent-judge 的 typed IR 文本。"""
    parts = [f"性质：{ir.get('nature')}", f"要求：{ir.get('effect')}"]
    if ir.get("rule_family"):
        parts.append(f"规则族：{ir['rule_family']}")
    if ir.get("execution_mode"):
        parts.append(f"执行：{ir['execution_mode']}")
    if ir.get("subject"):
        parts.append(f"对象：{ir['subject']}")
    if ir.get("predicate"):
        parts.append(f"判据：{ir['predicate']}")
    if ir.get("metric"):
        parts.append(f"指标：{ir['metric']} {ir.get('operator') or ''} {ir.get('threshold') if ir.get('threshold') is not None else ''}{ir.get('unit') or ''}".strip())
    rels = ir.get("relations") or []
    if rels:
        parts.append("关系：" + "；".join(
            f"{r.get('left')} {r.get('compare')} {r.get('right')}" for r in rels))
    proc = ir.get("procedure") or {}
    if proc.get("requirements"):
        parts.append("程序：" + _typed_predicate([], proc, ir.get("requirements") or []))
    elif ir.get("requirements"):
        parts.append("要素：" + _typed_predicate([], {}, ir.get("requirements") or []))
    if ir.get("scope"):
        parts.append(f"范围：{ir['scope']}")
    if ir.get("exceptions"):
        parts.append("例外：" + "、".join(ir["exceptions"]))
    if ir.get("evidence_required"):
        parts.append(f"证据：{ir['evidence_required']}")
    sem = ir.get("semantic") or {}
    if sem.get("instructions"):
        parts.append(f"约束：{sem['instructions']}")
    return "；".join(parts)


# ===========================================================================
# D2（P0-5 / T-191）：可执行判据 schema v1（typed）
#
# 背景：D1（T-178）证明「散文判据 + checkpoints」虽然能过可执行校验，但
# ruleexec 确定性解析 0/8（Tier-D=0）——生成侧没有 typed 结构，执行侧无从下手。
# 本节给生成器定义一份**可编译为平台执行器槽位**的 typed 契约：
#
#   {
#     "schema": "ruleproof.rulegen_schema/v1",
#     "point_code": "D02-001",
#     "category": "limit|date|consistency|record|sum",
#     "method": "deterministic",              # 非 deterministic 一律 reject（散文）
#     "slots": {                              # 规则元数据（非判定逻辑）
#        "applicable_types": ["md", "docx"],
#        "applicable_when": "...",
#        "evidence_scope": "document",
#        "required_evidence": ["原文数值"],
#        "severity": "warning"
#     },
#     "rules": [                              # ≥1 条 typed 判定谓词（真正可执行的判据）
#        {"kind":"limit","metric":"投标有效期","op":">=","value":90,"unit":"天"},
#        {"kind":"forbid","terms":["个工作日"]},
#        {"kind":"require_any","terms":["电子投标","电子递交"]},
#        {"kind":"not_in","metric":"投标有效期","values":["个工作日"]}
#     ],
#     "criteria_text": "（给 LLM 的人话版判据，≥20 字）"
#   }
#
# 与平台执行器的对应关系（app/engine/ruleexec.py）：
#   limit      → judge_limit（metric+op+value[+unit]，原文取数，多处全满足）
#   forbid     → judge_keyword forbid（出现即不满足）
#   require    → judge_keyword require（缺失即不满足）
#   require_any→ judge_keyword require_any（同义表述至少一个成立）
#   not_in     → judge_enum not_in（出现禁止取值即不满足）
#   多条谓词 → all_of 表达式（最小三值逻辑，未知不当作假）
# ===========================================================================
SCHEMA_VERSION = "ruleproof.rulegen_schema/v1"
SCHEMA_CATEGORIES = ("limit", "date", "consistency", "record", "sum")
SCHEMA_PREDICATE_KINDS = ("limit", "forbid", "require", "require_any", "not_in",
                          # P0-5 D2 修复第 1 项：require 两类模板（缺失 vs 被改），
                          # 都要带 anchors（适用上下文/负证据守卫），否则 clean-control 误报。
                          "require_present", "require_unchanged",
                          # P0-5 D2 修复第 2 项：文本级关系/算术算子（执行器已实现）
                          #   cross_position：同一事实跨位置取值归一后比对（D02-001 类）
                          #   sum_check     ：分项求和与合计比较（含绝对/相对容差，C01-001 类）
                          "cross_position", "sum_check",
                          # P0-5 D2 修复第 3 项：ALTER 类型算子（外部应有值比对）
                          # 与跨角色关系算子（分项vs合计/乘积vs总量/比例构成/日期链）。
                          #   两个缺口的共同点：它们判定的是**不同角色之间**的关系，
                          #   不依赖「同一事实在单文档重复出现」，因此在正确态文本上同样可判。
                          "alter_detect", "cross_role_limit")
# 说明：require_any 在 ruleexec.judge_keyword 中是「逐项同义匹配」语义（不是 OR），
# 生成器只在「同一个必修概念的多个别名」时使用；一般 OR 请用 not_in/forbid 表达禁止项。
_SCHEMA_META_KEYS = {"applicable_types", "applicable_when", "evidence_scope",
                     "required_evidence", "exceptions", "severity", "description",
                     # 适用上下文（负证据守卫）：判据只在原文命中 anchors 时生效，
                     # 否则执行器返回「不适用」而不是「不满足」——这是 require 型不再
                     # 把「本来没有」误判成「被改掉」的执行器侧承接点。
                     "applicability"}
_SCHEMA_TOP_KEYS = {"schema", "code", "point_code", "category", "method", "slots",
                    "rules", "criteria_text", "exceptions", "examples", "mechanism"}
_SCHEMA_PRED_KEYS = {"kind", "metric", "op", "value", "unit", "terms", "values",
                     "tolerance",
                     # require_present / require_unchanged 专用字段
                     "expected", "changed", "expected_source", "anchors", "mechanism",
                     # cross_position / sum_check 专用字段
                     "rel_tolerance", "label_heads", "discovery", "min_values",
                     "min_label_len", "total_anchor", "part_anchors", "part_heads",
                     "window", "min_parts", "compare_scope", "structure",
                     "exclude_units", "part_scope",
                     # alter_detect 专用（应有值必须给外部来源；conflict_units 显式声明
                     # 「同一量纲下的错误口径」白名单，避免把日期里的 年/月 当单位漂移）
                     "expected_source", "conflict_units",
                     # cross_role_limit 专用（模式 + 两个角色的位置）
                     "mode", "lhs_anchors", "lhs_heads", "rhs_anchor", "total_ratio",
                     "lhs_scope", "min_days", "min_hits", "min_label_len",
                     # 第 4 项取数原语专用：负语境词表（区间取数时排除「工期/近N年」等
                     # 别的角色标签）与窗口月数上限
                     "exclude_ctx", "max_gap_months"}
# 关系/算术算子类别的默认归类（schema.category 仍是审核点大类）
_XOP_CATEGORY = {"cross_position": "consistency", "sum_check": "sum",
                 "alter_detect": "consistency", "cross_role_limit": "sum"}
# ALTER/跨角色算子允许的外部应有值来源（与 ruleexec.judge_alter_detect 同源白名单）
_ALTER_EXTERNAL_SOURCES = ("spec", "contract", "list", "clean_consensus",
                           "clean_instance", "unit_lexicon")
_CROSS_ROLE_MODES = ("part_le_total", "sum_le_total", "sum_eq_total", "sum_ratio_eq",
                     "product_eq_total", "product_le_total", "date_le", "date_lt",
                     "date_eq", "date_gap_ge", "date_gap_stated", "date_span_stated",
                     "date_range_le", "count_eq_stated", "lhs_le_rhs", "lhs_eq_rhs",
                     # P0-5 D2 修复第 4 项：四个取数原语承接的模式
                     #   range_overlap    区间/编号集合重叠（资质档位 vs 标段编号）
                     #   interval_end_le  无标签时间区间（「日期 至 日期」）终点 ≤ 后序时点
                     #   window_gap_le    同类人员时间窗口（社保）最晚月份距递交截止的月数
                     #   date_span_relative 自述「近N年（自 A 至…截止…止）」相对终点换算
                     "range_overlap", "interval_end_le", "window_gap_le",
                     "date_span_relative")
# 「应有值」来源（require_unchanged 必填）：规格 / 合同 / 清单 / 多文档共识 /
# 单文档正确态 / 计量单位词表。单文档数值（含数字且非 spec/consensus）一律视为
# 单文档数值过拟合，生成器在自校准前置检查中拒绝。
_SCHEMA_EXPECTED_SOURCES = ("spec", "contract", "list", "clean_consensus",
                            "clean_instance", "unit_lexicon")
_NUM_OPS = {"<=", ">=", "=", "<", ">", "!=", "range"}
_TEXT_OPS = {"contains", "not_contains", "in", "not_in"}


def _schema_num(v):
    try:
        return float(str(v).replace(",", "").strip())
    except Exception:
        return None


def _terms_of(raw, field="terms"):
    """谓词 terms/values → 干净字符串列表（去空、限长、去重）。"""
    if isinstance(raw, str):
        raw = [x for x in raw.replace("；", ",").replace(";", ",").split(",")]
    if not isinstance(raw, (list, tuple)):
        return []
    out = []
    for x in raw:
        s = str(x).strip().strip("“”\"'")
        if not s or len(s) > 40:
            continue
        if s not in out:
            out.append(s)
    return out


def validate_schema_v1(obj) -> dict:
    """校验 typed 判据 schema v1；散文/缺失可执行谓词 → ok=False。

    返回 {ok, errors, warnings, normalized}；normalized 可直接给
    ``schema_v1_to_slots`` 编译成平台槽位。
    """
    errors, warnings = [], []
    if not isinstance(obj, dict):
        return {"ok": False, "errors": ["输出不是 JSON 对象"], "warnings": [],
                "normalized": {}}
    for k in obj:
        if k not in _SCHEMA_TOP_KEYS:
            warnings.append(f"忽略未知顶层字段：{k}")
    schema = str(obj.get("schema") or "").strip()
    if schema and schema != SCHEMA_VERSION:
        errors.append(f"schema 版本不支持：{schema}（应为 {SCHEMA_VERSION}）")
    point_code = str(obj.get("point_code") or "").strip()
    if not point_code:
        errors.append("缺少 point_code（判据必须绑定审核点）")
    category = str(obj.get("category") or "").strip()
    if category not in SCHEMA_CATEGORIES:
        errors.append(f"category 非法：{category!r}（可用 {'/'.join(SCHEMA_CATEGORIES)}）")
    method = str(obj.get("method") or "").strip().lower()
    if method != "deterministic":
        errors.append("method 必须是 deterministic（散文/语义判据一律 reject）")
    slots_in = obj.get("slots")
    if not isinstance(slots_in, dict):
        slots_in = {}
        errors.append("slots 必须是对象")
    slots = {}
    for k, v in slots_in.items():
        if k in _SCHEMA_META_KEYS:
            slots[k] = v
        elif k in ("metric", "op", "value", "unit"):  # 兼容单谓词平铺写法
            slots.setdefault("_flat", {})[k] = v
        else:
            errors.append(f"slots 含非法字段：{k}")
    # 规则元数据归一
    if "applicable_types" in slots:
        raw_types = slots["applicable_types"]
        if isinstance(raw_types, str):
            raw_types = [raw_types]
        if not isinstance(raw_types, (list, tuple)):
            errors.append("applicable_types 必须是字符串或字符串列表")
            raw_types = []
        slots["applicable_types"] = [str(x).strip().lower() for x in raw_types if str(x).strip()]
    if "required_evidence" in slots:
        ev = slots["required_evidence"]
        if isinstance(ev, str):
            ev = [x.strip() for x in ev.replace("；", ";").split(";") if x.strip()]
        if not isinstance(ev, (list, tuple)):
            errors.append("required_evidence 必须是字符串或字符串列表")
            ev = []
        slots["required_evidence"] = [str(x).strip() for x in ev if str(x).strip()][:10]
    if "evidence_scope" in slots and slots["evidence_scope"] not in (
            "document", "block", "row", "sheet", "document_set"):
        errors.append("evidence_scope 只能是 document/block/row/sheet/document_set")
    # typed 谓词
    rules_in = obj.get("rules")
    if not isinstance(rules_in, (list, tuple)) or not rules_in:
        errors.append("rules 必须是非空数组（至少 1 条 typed 判定谓词）")
        rules_in = []
    rules = []
    for i, pred in enumerate(rules_in):
        tag = f"rules[{i}]"
        if not isinstance(pred, dict):
            errors.append(f"{tag} 不是对象")
            continue
        bad = [k for k in pred if k not in _SCHEMA_PRED_KEYS]
        if bad:
            errors.append(f"{tag} 含非法字段：{','.join(bad)}")
        kind = str(pred.get("kind") or "").strip()
        if kind not in SCHEMA_PREDICATE_KINDS:
            errors.append(f"{tag}.kind 非法：{kind!r}（可用 {'/'.join(SCHEMA_PREDICATE_KINDS)}）")
            continue
        norm_pred = {"kind": kind}
        if kind == "limit":
            metric = str(pred.get("metric") or "").strip()
            op = str(pred.get("op") or "").strip()
            value = pred.get("value")
            unit = str(pred.get("unit") or "").strip()
            if not metric:
                errors.append(f"{tag} limit 缺少 metric")
            if op not in _NUM_OPS:
                errors.append(f"{tag} limit.op 非法：{op!r}（可用 {'/'.join(sorted(_NUM_OPS))}）")
            if _schema_num(value) is None:
                errors.append(f"{tag} limit.value 必须是数字（阈值不得虚构/留空）")
            norm_pred.update({"metric": metric, "op": op, "value": value, "unit": unit})
        elif kind in ("forbid", "require", "require_any"):
            terms = _terms_of(pred.get("terms"))
            if not terms:
                errors.append(f"{tag} {kind} 至少需要 1 个 2–40 字的字面串 terms")
            if not any(len(t) >= 2 for t in terms):
                errors.append(f"{tag} {kind} 字面串长度必须 ≥2")
            norm_pred["terms"] = terms[:8]
        elif kind == "not_in":
            metric = str(pred.get("metric") or "").strip()
            values = _terms_of(pred.get("values"))
            if not values:
                errors.append(f"{tag} not_in 至少需要 1 个禁止取值 values")
            norm_pred.update({"metric": metric, "values": values[:8]})
        elif kind in ("require_present", "require_unchanged"):
            # 两类 require 模板都必须有 anchors：执行器用 anchors 做「适用上下文」守卫，
            # 原文没有该上下文 → 不适用（不是不满足），从而消除「本来没有 vs 被改掉」误报。
            anchors = _terms_of(pred.get("anchors"))
            if not anchors:
                errors.append(f"{tag} {kind} 必须提供 anchors（应有内容的出现位置/上下文，"
                              f"否则无法区分「本来没有」与「被改掉」）")
            if len(anchors) > 8:
                errors.append(f"{tag} anchors 最多 8 个")
            norm_pred["anchors"] = anchors[:8]
            if kind == "require_present":
                terms = _terms_of(pred.get("terms"))
                if not terms:
                    errors.append(f"{tag} require_present 至少需要 1 个应有内容字面串 terms")
                norm_pred["terms"] = terms[:8]
            else:
                expected = _terms_of(pred.get("expected"))
                changed = _terms_of(pred.get("changed"))
                src = str(pred.get("expected_source") or "").strip()
                if not expected:
                    errors.append(f"{tag} require_unchanged 至少需要 1 个应有值 expected")
                if not changed:
                    errors.append(f"{tag} require_unchanged 至少需要 1 个被改值 changed")
                if src not in _SCHEMA_EXPECTED_SOURCES:
                    errors.append(
                        f"{tag} require_unchanged.expected_source 非法：{src!r}"
                        f"（可用 {'/'.join(_SCHEMA_EXPECTED_SOURCES)}；"
                        f"应有值必须有来源，不得凭单文档数值臆造）")
                norm_pred.update({"expected": expected[:8], "changed": changed[:8],
                                  "expected_source": src})
        elif kind == "cross_position":
            # 同一事实跨位置一致性：必须有出现位置锚点（或发现模式的名词头），
            # 否则「哪些位置该一致」无依据，执行器会直接拒绝。
            anchors = _terms_of(pred.get("anchors"))
            heads = _terms_of(pred.get("label_heads"))
            discovery = bool(pred.get("discovery"))
            if not discovery and not anchors:
                errors.append(f"{tag} cross_position 必须提供 anchors（出现位置/上下文），"
                              f"或用 discovery=true + label_heads 做发现模式")
            if discovery and not heads:
                errors.append(f"{tag} cross_position discovery 模式必须提供 label_heads")
            if len(anchors) > 8:
                errors.append(f"{tag} anchors 最多 8 个")
            if discovery and anchors:
                errors.append(f"{tag} cross_position 的 anchors 与 discovery 不能同时使用"
                              f"（两种取数口径互斥）")
            min_values = pred.get("min_values")
            if min_values is not None and (_schema_num(min_values) or 0) < 2:
                errors.append(f"{tag} cross_position.min_values 必须 ≥2")
            scope = str(pred.get("compare_scope") or "per_anchor").strip().lower()
            if scope not in ("per_anchor", "pool"):
                errors.append(f"{tag} cross_position.compare_scope 只能是 "
                              f"per_anchor（同一措辞多处一致）/ pool（不同措辞同一事实一致）")
            norm_pred.update({
                "anchors": anchors[:8], "label_heads": heads[:8], "discovery": discovery,
                "compare_scope": scope,
                "unit": str(pred.get("unit") or "").strip(),
                "tolerance": _schema_num(pred.get("tolerance")) or 0.0,
                "rel_tolerance": _schema_num(pred.get("rel_tolerance")) or 0.0,
                "min_values": int(_schema_num(min_values) or 2),
            })
        elif kind == "sum_check":
            # 分项合计算术：合计项 + ≥2 分项（或分项头词）；容差为绝对值或相对值。
            total_anchor = str(pred.get("total_anchor") or "").strip()
            part_anchors = _terms_of(pred.get("part_anchors"))
            part_heads = _terms_of(pred.get("part_heads"))
            structure = str(pred.get("structure") or "").strip().lower()
            if structure and structure != "qizhong":
                errors.append(f"{tag} sum_check.structure 只支持 qizhong（合计项，其中分项…）")
            if structure == "qizhong":
                if total_anchor or part_anchors or part_heads:
                    errors.append(f"{tag} structure=qizhong 不能同时给 total_anchor/"
                                  f"part_anchors/part_heads（结构与锚点口径互斥）")
            else:
                if not total_anchor:
                    errors.append(f"{tag} sum_check 必须提供 total_anchor（合计项位置）")
                if len(part_anchors) < 2 and not part_heads:
                    op = str(pred.get("op") or pred.get("operator") or "=").strip()
                    if op in ("=", "==", "!=") or not part_anchors:
                        errors.append(f"{tag} sum_check 至少需要 2 个 part_anchors"
                                      f"（或 part_heads）；上下界核对可用 op 并给 1 个分项")
                if part_heads and len(part_anchors) >= 2:
                    errors.append(f"{tag} sum_check 的 part_anchors 与 part_heads 不能同时使用"
                                  f"（两种取数口径互斥）")
            excl = pred.get("exclude_units")
            if excl is not None and not isinstance(excl, (list, tuple)):
                errors.append(f"{tag} sum_check.exclude_units 必须是字符串数组")
            tol = _schema_num(pred.get("tolerance"))
            rel = _schema_num(pred.get("rel_tolerance"))
            if tol is not None and tol < 0:
                errors.append(f"{tag} sum_check.tolerance 不能为负")
            if rel is not None and rel < 0:
                errors.append(f"{tag} sum_check.rel_tolerance 不能为负")
            min_parts = int(_schema_num(pred.get("min_parts")) or 2)
            if min_parts < 2:
                errors.append(f"{tag} sum_check.min_parts 必须 ≥2（单项无需求和）")
            norm_pred.update({
                "total_anchor": total_anchor[:40],
                "part_anchors": part_anchors[:8], "part_heads": part_heads[:8],
                "unit": str(pred.get("unit") or "").strip(),
                "tolerance": tol if tol is not None else 0.01,
                "rel_tolerance": rel if rel is not None else 0.0,
                "window": int(_schema_num(pred.get("window")) or 240),
                "min_parts": min_parts,
            })
            if structure:
                norm_pred["structure"] = structure
            if pred.get("part_scope"):
                norm_pred["part_scope"] = str(pred.get("part_scope")).strip().lower()
            if pred.get("op") or pred.get("operator"):
                norm_pred["op"] = str(pred.get("op") or pred.get("operator")).strip()
            if isinstance(pred.get("exclude_units"), (list, tuple)):
                norm_pred["exclude_units"] = [
                    str(x).strip() for x in pred["exclude_units"] if str(x or "").strip()][:8]
        elif kind == "alter_detect":
            # ALTER 类型：anchors（定位）+ expected（外部应有值）+ expected_source（来源）
            anchors = _terms_of(pred.get("anchors"))
            expected = _terms_of(pred.get("expected"))
            src = str(pred.get("expected_source") or "").strip().lower()
            mode = str(pred.get("mode") or "").strip().lower()
            if not anchors:
                errors.append(f"{tag} alter_detect 必须提供 anchors（应有值所在位置/上下文）")
            if len(anchors) > 8:
                errors.append(f"{tag} anchors 最多 8 个")
            if not expected:
                errors.append(f"{tag} alter_detect 必须提供 expected（外部应有值 ≥1 条）")
            if not src:
                errors.append(f"{tag} alter_detect 必须提供 expected_source（应有值来源；"
                              f"禁止同一文档自证）")
            elif src not in _ALTER_EXTERNAL_SOURCES:
                errors.append(f"{tag} alter_detect.expected_source 非法：{src!r}"
                              f"（可用 {'/'.join(_ALTER_EXTERNAL_SOURCES)}；"
                              f"同一文档自证/单实例来源一律拒绝）")
            if mode and mode not in ("value", "date", "unit"):
                errors.append(f"{tag} alter_detect.mode 只能是 value/date/unit")
            tol = _schema_num(pred.get("tolerance"))
            rel = _schema_num(pred.get("rel_tolerance"))
            if (tol is not None and tol < 0) or (rel is not None and rel < 0):
                errors.append(f"{tag} alter_detect 的 tolerance/rel_tolerance 不能为负")
            norm_pred.update({
                "anchors": anchors[:8], "expected": expected[:8],
                "expected_source": src,
                "mode": mode or "",
                "unit": str(pred.get("unit") or "").strip(),
                "tolerance": tol if tol is not None else 0.0,
                "rel_tolerance": rel if rel is not None else 0.0,
                "window": int(_schema_num(pred.get("window")) or 80),
                "min_hits": max(1, int(_schema_num(pred.get("min_hits")) or 1)),
            })
            if isinstance(pred.get("conflict_units"), (list, tuple)):
                norm_pred["conflict_units"] = [
                    str(x).strip() for x in pred["conflict_units"]
                    if str(x or "").strip()][:8]
        elif kind == "cross_role_limit":
            mode = str(pred.get("mode") or "part_le_total").strip().lower()
            lhs = _terms_of(pred.get("lhs_anchors"))
            rhs_raw = pred.get("rhs_anchor")
            rhs_list = ([str(x).strip() for x in rhs_raw] if isinstance(rhs_raw, (list, tuple))
                        else [str(rhs_raw or "").strip()])
            rhs_list = [x for x in rhs_list if x][:4]
            if mode not in _CROSS_ROLE_MODES:
                errors.append(f"{tag} cross_role_limit.mode 非法：{mode!r}"
                              f"（可用 {'/'.join(_CROSS_ROLE_MODES)}）")
            if not lhs:
                errors.append(f"{tag} cross_role_limit 必须提供 lhs_anchors"
                              f"（分项/前序角色，≥1 条）")
            # 第 4 项四个原语可自行取后序时点/角色（区间终点、窗口截止、相对终点），
            # 因此 rhs_anchor 允许留空；其余模式仍必须给。
            if mode not in ("sum_ratio_eq", "date_span_stated", "date_span_relative",
                            "range_overlap", "interval_end_le", "window_gap_le") \
                    and not rhs_list:
                errors.append(f"{tag} cross_role_limit 必须提供 rhs_anchor"
                              f"（合计/后序角色）")
            tol = _schema_num(pred.get("tolerance"))
            rel = _schema_num(pred.get("rel_tolerance"))
            if (tol is not None and tol < 0) or (rel is not None and rel < 0):
                errors.append(f"{tag} cross_role_limit 的 tolerance/rel_tolerance 不能为负")
            ratio = _schema_num(pred.get("total_ratio"))
            if ratio is not None and not (0 < ratio <= 100):
                errors.append(f"{tag} cross_role_limit.total_ratio 必须在 (0,100] 内")
            _excl = pred.get("exclude_ctx")
            norm_pred.update({
                "mode": mode, "lhs_anchors": lhs[:12],
                "lhs_heads": _terms_of(pred.get("lhs_heads"))[:8],
                "rhs_anchor": rhs_list,
                "total_ratio": ratio if ratio is not None else 100.0,
                "lhs_scope": str(pred.get("lhs_scope") or "first").strip().lower(),
                "min_days": max(0, int(_schema_num(pred.get("min_days")) or 0)),
                "unit": str(pred.get("unit") or "").strip(),
                "tolerance": tol if tol is not None else 0.01,
                "rel_tolerance": rel if rel is not None else 0.0,
                "window": int(_schema_num(pred.get("window")) or 240),
            })
            if isinstance(_excl, (list, tuple)):
                norm_pred["exclude_ctx"] = [
                    str(x).strip() for x in _excl if str(x or "").strip()][:12]
            _mg = _schema_num(pred.get("max_gap_months"))
            if _mg is not None:
                norm_pred["max_gap_months"] = int(_mg)
        rules.append(norm_pred)
    if not any(r.get("kind") in SCHEMA_PREDICATE_KINDS for r in rules):
        errors.append("没有任何可执行谓词（散文判据 reject）")
    # 平台平铺写法兜底（slots.metric/op/value/unit 且无 rules）
    flat = dict(slots.pop("_flat", {}) or {})
    if not rules and flat.get("metric") and flat.get("value") is not None:
        op = str(flat.get("op") or "")
        if op in _NUM_OPS:
            rules.append({"kind": "limit", "metric": str(flat.get("metric")),
                          "op": op, "value": flat.get("value"),
                          "unit": str(flat.get("unit") or "")})
        else:
            errors.append(f"slots.op 非法：{op!r}")
    crit = str(obj.get("criteria_text") or "").strip()
    if len(crit) < 20:
        errors.append("criteria_text 必须 ≥20 字（给人读的完整判据，不能只有标题）")
    if crit and any(w in crit for w in ("合理", "适当", "酌情", "尽量", "必要时")):
        warnings.append("criteria_text 含主观模糊词，执行器不依赖它，但人工审阅需注意")
    for k in ("exceptions",):
        if k in obj:
            exc = obj[k]
            if isinstance(exc, str):
                exc = [exc]
            if not isinstance(exc, (list, tuple)):
                errors.append(f"{k} 必须是数组")
                exc = []
            slots["exceptions"] = [str(x).strip() for x in exc if str(x).strip()][:5]
    normalized = {"schema": SCHEMA_VERSION,
                  "code": str(obj.get("code") or "").strip(),
                  "point_code": point_code, "category": category,
                  "method": "deterministic", "slots": slots,
                  "rules": rules, "criteria_text": crit[:1500],
                  "mechanism": str(obj.get("mechanism") or "").strip()}
    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "normalized": normalized}


def _predicate_conditions(pred: dict) -> list:
    """typed 谓词 → ruleexec 可消费的条件 dict 列表（judge_rule/_eval_expr 同源）。

    注意：``judge_keyword`` 的 require/forbid 是**单个字符串**，多字面串必须拆成
    多条子条件（require 用 all_of、forbid 用 all_of），不能把 list 塞进去。
    """
    kind = pred.get("kind")
    if kind == "limit":
        return [{"metric": pred.get("metric"), "op": pred.get("op"),
                 "value": pred.get("value")}]
    if kind == "forbid":
        return [{"forbid": str(t)} for t in (pred.get("terms") or []) if str(t).strip()]
    if kind == "require":
        return [{"require": str(t)} for t in (pred.get("terms") or []) if str(t).strip()]
    if kind == "require_any":
        terms = [str(t) for t in (pred.get("terms") or []) if str(t).strip()]
        return [{"require_any": terms}] if terms else []
    if kind == "not_in":
        return [{"metric": pred.get("metric"), "op": "not_in",
                 "values": pred.get("values") or []}]
    if kind == "require_present":
        # 「应有未有（缺失）」：应有内容缺失 → 不满足；由 slots.applicability 守卫
        # 保证「原文根本没有该条款」时返回不适用，而不是误报缺失。
        return [{"require": str(t)} for t in (pred.get("terms") or []) if str(t).strip()]
    if kind == "require_unchanged":
        # 「有但被改（改动）」：应有值必须在 + 被改值不得出现；二者缺一即不满足。
        leaves = [{"require": str(t)} for t in (pred.get("expected") or []) if str(t).strip()]
        leaves += [{"forbid": str(t)} for t in (pred.get("changed") or []) if str(t).strip()]
        return leaves
    if kind == "cross_position":
        # 文本级跨位置一致性：anchors=出现位置；discovery 模式用 label_heads 发现分组。
        leaf = {"cross_position": {k: pred.get(k) for k in
                                  ("anchors", "label_heads", "discovery", "unit",
                                   "tolerance", "rel_tolerance", "min_values",
                                   "min_label_len", "compare_scope")
                                  if pred.get(k) not in (None, "", [], 0.0)}}
        return [leaf]
    if kind == "alter_detect":
        leaf = {"alter_detect": {k: pred.get(k) for k in
                                 ("anchors", "expected", "expected_source", "mode",
                                  "unit", "tolerance", "rel_tolerance", "window",
                                  "min_hits", "conflict_units")
                                 if pred.get(k) not in (None, "", [], 0.0)}}
        return [leaf]
    if kind == "cross_role_limit":
        leaf = {"cross_role_limit": {k: pred.get(k) for k in
                                     ("mode", "lhs_anchors", "lhs_heads", "rhs_anchor",
                                      "unit", "tolerance", "rel_tolerance", "window",
                                      "total_ratio", "lhs_scope", "min_days",
                                      "exclude_ctx", "max_gap_months")
                                     if pred.get(k) not in (None, "", [])}}
        return [leaf]
    if kind == "sum_check":
        leaf = {"sum_check": {k: pred.get(k) for k in
                              ("total_anchor", "part_anchors", "part_heads", "unit",
                               "tolerance", "rel_tolerance", "window", "min_parts",
                               "structure", "exclude_units", "part_scope", "op")
                              if pred.get(k) not in (None, "", [])}}
        return [leaf]
    return []


def schema_v1_to_slots(obj) -> dict:
    """typed schema v1 → 平台规则槽位（create_rule / ruleexec.judge_rule 直接消费）。

    - 单谓词：平铺为 limit/keyword/enum 槽位；
    - 多谓词：``all_of`` 表达式（子条件同样可被 judge_rule 解析）；
    - 单位、模板、证据、适用范围一并带上，保证 create_rule 与审核主链同源。
    """
    norm = obj if (isinstance(obj, dict) and obj.get("rules")) else \
        validate_schema_v1(obj).get("normalized") or {}
    meta = dict(norm.get("slots") or {})
    rules = list(norm.get("rules") or [])
    category = str(norm.get("category") or "")
    _has_mech = any(r.get("kind") in ("require_present", "require_unchanged") for r in rules)
    _xop = next((r for r in rules if r.get("kind") in (
        "cross_position", "sum_check", "alter_detect", "cross_role_limit")), None)
    slots = {}
    if _xop is not None:
        # 关系/算术算子：不进 limit 模板（否则执行器走数值解析），由 _xop_kind 分派。
        # 模板名必须落在既有发布门禁白名单里（rule_schema.EXECUTOR_BY_TEMPLATE，
        # 属共享模块、不在本项写权限内）：cross_position→consistency（语义即一致性）、
        # sum_check→record（通用载体，与第 1 项机制判据同一做法）；执行器显式声明 rule。
        # 模板一律落在既有白名单值上（rule_schema.EXECUTOR_BY_TEMPLATE 是共享模块、
        # 不在本项写权限内）：关系/一致性类→consistency、算术/记录类→record；
        # 执行器显式声明 rule，分派由 _xop_kind 完成（judge_rule 已接）
        slots["_template"] = ("consistency"
                              if _xop["kind"] in ("cross_position", "alter_detect")
                              else "record")
        slots["_executor"] = "rule"
        slots["_xop_kind"] = _xop["kind"]
        slots["_xop_spec"] = _predicate_conditions(_xop)[0][_xop["kind"]]
    elif _has_mech:
        # require 两类模板走 keyword 路径：不能进 limit 模板（否则执行器走数值解析）。
        slots["_template"] = "record"
    elif category in ("limit", "date"):
        slots["_template"] = "limit"
    elif category == "record":
        slots["_template"] = "record"
    slots.update(meta)
    slots["criterion"] = norm.get("criteria_text") or ""
    slots["criteria_text"] = norm.get("criteria_text") or ""
    slots["point_code"] = norm.get("point_code") or ""
    slots["source_schema"] = norm.get("schema") or SCHEMA_VERSION
    slots["method"] = "deterministic"
    if norm.get("mechanism"):
        slots["mechanism"] = str(norm["mechanism"])[:120]
    leaves = []
    anchors = []
    for pred in rules:
        leaves.extend(_predicate_conditions(pred))
        if pred.get("kind") in ("require_present", "require_unchanged"):
            for a in pred.get("anchors") or []:
                a = str(a).strip()
                if a and a not in anchors:
                    anchors.append(a)
            slots.setdefault("_mechanism_kind", pred.get("kind"))
    if len(rules) == 1 and len(leaves) == 1:
        pred, leaf = rules[0], dict(leaves[0])
        kind = pred.get("kind")
        if kind in ("limit", "not_in"):
            if leaf.get("unit") is None and pred.get("unit"):
                leaf["unit"] = pred.get("unit")
            slots.update(leaf)
        elif kind == "require_any":
            slots["require_any"] = list(leaf.get("require_any") or [])
        else:
            slots.update(leaf)
    elif leaves:
        slots["all_of"] = leaves
    if anchors:
        slots["applicability"] = anchors
        # 负证据守卫的执行器承接：rule_schema.applicable 只在 applicability 非空时
        # 生效；而它当前会把「metric/subject 为空」时的 applicability 全部过滤掉
        # （空串 in 任意串 恒真）。这里用一个不参与判定的哨兵 metric 让 guards 生效，
        # 不改变 judge_keyword / all_of 的判定语义（metric 无 value，不触发 limit/字段路径）。
        if not slots.get("metric"):
            slots["metric"] = "规则适用性"
            slots["subject"] = str(slots.get("subject") or "规则适用性")
            slots["_applicability_guard"] = True
    return slots


def schema_v1_summary(slots: dict) -> dict:
    """静态可执行性摘要（不执行；执行验证在 ruleexec / 调用方）。"""
    slots = dict(slots or {})
    has_limit = bool(slots.get("metric") and slots.get("value") is not None
                     and slots.get("op") in _NUM_OPS)
    has_kw = bool(slots.get("require") or slots.get("forbid")
                  or slots.get("require_any") or slots.get("forbidden"))
    has_enum = bool(slots.get("values") is not None and slots.get("op") in ("in", "not_in"))
    mech_kind = str(slots.get("_mechanism_kind") or "")
    xop_kind = str(slots.get("_xop_kind") or "")
    if xop_kind:
        has_rel = bool(slots.get("_xop_spec"))
    else:
        has_rel = False
    expr_leaves = 0
    for key in ("all_of", "any_of"):
        for leaf in (slots.get(key) or []):
            if not isinstance(leaf, dict):
                continue
            if (leaf.get("metric") and leaf.get("value") is not None) or \
                    leaf.get("values") is not None:
                expr_leaves += 1
            elif leaf.get("require") or leaf.get("forbid") or leaf.get("require_any"):
                expr_leaves += 1
    return {"has_limit": has_limit, "has_keyword": has_kw, "has_enum": has_enum,
            "has_relation": bool(has_rel), "xop_kind": xop_kind,
            "expression_leaves": expr_leaves,
            "mechanism_kind": mech_kind,
            "applicability_guard": list(slots.get("applicability") or []),
            "executable_static": bool(has_limit or has_kw or has_enum or expr_leaves
                                      or has_rel),
            "predicate_count": 1 if (has_limit or has_kw or has_enum or has_rel)
                               else expr_leaves}
