"""后台调度：自动消费反馈队列，驱动误报归因智能体，实现真正的闭环。

职责：
  1. 扫描待处理反馈（rsi_status=pending），按规则聚合
  2. 单条规则反向反馈达到阈值 → 自动跑「误报归因智能体」
  3. 归因结果写回反馈台账，并通知管理员
"""
import json
import logging
import os
import threading
import time
from contextlib import nullcontext

from .. import db
from .. import repositories as R
from . import ctx

_INTERVAL = int(os.environ.get("RULEPROOF_SCHEDULER_SECONDS", "120") or 120)
_THRESHOLD = int(os.environ.get("RULEPROOF_AGENT_THRESHOLD", "3") or 3)
_started = False
_lock = threading.Lock()
_last_run = {"at": "", "analyzed": 0, "rules": 0}


def _acquire_lock(name: str, ttl_seconds: int = 300) -> bool:
    """数据库级互斥：多实例部署时只有一个节点能跑本轮。"""
    import datetime as _dt
    owner = f"{os.getpid()}-{int(time.time())}"
    now = _dt.datetime.now()
    exp = (now + _dt.timedelta(seconds=ttl_seconds)).strftime("%Y-%m-%d %H:%M:%S")
    now_s = now.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with db.session() as c:
            # 先清理过期锁，再原子插入：只有插入成功的实例拿到锁
            c.execute("DELETE FROM job_lock WHERE name=? AND (expires_at IS NULL OR expires_at <= ?)",
                      (name, now_s))
            cur = c.execute("INSERT OR IGNORE INTO job_lock(name,owner,acquired_at,expires_at) "
                            "VALUES(?,?,?,?)", (name, owner, now_s, exp))
            return cur.rowcount == 1
    except Exception:
        return False


def _release_lock(name: str) -> None:
    try:
        with db.session() as c:
            c.execute("DELETE FROM job_lock WHERE name=?", (name,))
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)


def scan_once(force: bool = False) -> dict:
    if not _acquire_lock("feedback_scan"):
        return {"rules": 0, "analyzed": 0, "skipped": "locked"}
    try:
        out = _scan_locked(force)
    finally:
        _release_lock("feedback_scan")
    # L169/HW-19：同一轮顺带盘点数据留存到期量（只读；失败不影响反馈扫描结果）
    try:
        out["retention"] = retention_watch(force=force)
    except Exception:  # noqa: BLE001 - 盘点失败不得让主调度变更成 FAIL
        logging.getLogger(__name__).debug("retention watch skipped", exc_info=True)
        out["retention"] = {"skipped": "error"}
    return out


def _scan_locked(force: bool = False) -> dict:
    """按租户/空间分组跑：禁止跨租户聚合、通知和审计。"""
    from . import evolution as ev
    try:
        rows = R.feedback.list("rsi_status=?", ("pending",), order="created_at DESC")
    except Exception:
        rows = []
    groups = {}
    for r in rows:
        if (r.get("kind") or "") not in ("false_positive", "manual"):
            continue
        code = r.get("rule_code") or ""
        if not code:
            continue
        key = (r.get("tenant_id") or "t-default", r.get("workspace_id") or "ws-default")
        groups.setdefault(key, {}).setdefault(code, []).append(r)

    analyzed, touched = 0, 0
    for (tid, wid), by_rule in groups.items():
        with (ctx.scoped(tid, wid) if (tid or wid) else nullcontext()):
            analyzed_t, touched_t = 0, 0
            for code, items in by_rule.items():
                if not force and len(items) < _THRESHOLD:
                    continue
                touched_t += 1
                for it in items[:10]:
                    try:
                        res = ev.analyze_feedback(it.get("finding_id") or "", "scheduler")
                        root = res.get("root_cause") or ""
                        sugg = res.get("suggestion") or ""
                        try:
                            _old_payload = json.loads(it.get("payload") or "{}")
                        except Exception:
                            _old_payload = {}
                        if not isinstance(_old_payload, dict):
                            _old_payload = {}
                        _old_payload.update({"root_cause": root, "suggestion": sugg,
                                             "source": res.get("source", "heuristic"),
                                             "reason": _old_payload.get("reason", "")})
                        R.feedback.update(it["id"], rsi_status="analyzed",
                                          payload=json.dumps(_old_payload, ensure_ascii=False))
                        analyzed_t += 1
                    except Exception:
                        continue
            if touched_t:
                try:
                    from . import notify
                    notify.notify_role("admin", "agent.fp_auto",
                                       f"自动归因完成：{touched_t} 条规则 / {analyzed_t} 条反馈",
                                       "结果已写入「规则进化 → 反馈台账」，可确认沉淀")
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
                R.audit_logs.log(actor="scheduler", action="agent.fp_auto",
                                 after=f"tenant={tid} rules={touched_t} analyzed={analyzed_t}")
            touched += touched_t
            analyzed += analyzed_t
    _last_run.update({"at": db.now(), "analyzed": analyzed, "rules": touched})
    return {"rules": touched, "analyzed": analyzed, **{"at": _last_run["at"]}}


# ---------------------------------------------------------------------------
# HW-19（L169）：数据留存策略的周期盘点（只读；到期写审计，不删除任何行）
# ---------------------------------------------------------------------------
_RETENTION_INTERVAL = int(os.environ.get("RULEPROOF_RETENTION_WATCH_SECONDS", "3600") or 3600)
_last_retention = {"at": "", "due": 0, "tenants": 0, "checked": 0, "skipped": ""}
_last_retention_ts = [0.0]


def retention_watch(force: bool = False) -> dict:
    """按数据边界策略的 ``retention_*_days`` 盘点到期数据（只读）。

    L169/HW-19 接线：策略里的 cases/logs/cache/reports 留存天数此前只回显、无产品侧
    消费方；本任务由既有后台调度周期消费（默认 1 小时一次，``RULEPROOF_RETENTION_WATCH_SECONDS``
    可调），按租户算「已超期行数」，有到期数据时写审计 ``data.retention.due`` 供核对。
    **不删除任何行**：真实删除仍走 data-policy purge（预览→二次确认→审计；
    audit_log 只读不可删、llm_cache 无租户列不按租户删除）。
    """
    out = {"checked": 0, "due": 0, "tenants": 0, "skipped": ""}
    now = time.time()
    if not force and (now - _last_retention_ts[0]) < max(60, _RETENTION_INTERVAL):
        out["skipped"] = "interval"
        return out
    try:
        from . import sysconfig
        pol = sysconfig.get_data_policy()
        values = (pol or {}).get("values") or {}
        if not any(values.get(k) not in (None, "", 0, "0") for k in (
                "retention_cases_days", "retention_logs_days",
                "retention_cache_days", "retention_reports_days")):
            out["skipped"] = "policy_unconfigured"
            _last_retention_ts[0] = now
            return out
    except Exception:  # noqa: BLE001 - 策略读取失败不阻断主调度
        logging.getLogger(__name__).debug("retention policy read skipped", exc_info=True)
        out["skipped"] = "policy_unavailable"
        return out
    tenants = []
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT DISTINCT tenant_id FROM audit_case "
                "WHERE COALESCE(tenant_id,'')<>'' LIMIT 200").fetchall()
            tenants = [str(r[0]) for r in rows]
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("retention tenant scan skipped", exc_info=True)
    try:
        cur_ctx = ctx.get_context() or {}
        _tid_ctx = str(cur_ctx.get("tenant_id") or "")
        if _tid_ctx and _tid_ctx not in tenants:
            tenants.append(_tid_ctx)
    except Exception:  # noqa: BLE001
        pass
    out["tenants"] = len(tenants)
    for tid in tenants:
        try:
            plan = sysconfig.retention_plan(tid)
        except Exception:  # noqa: BLE001 - 单租户失败不影响其他租户
            logging.getLogger(__name__).debug("retention plan failed tenant=%s", tid,
                                              exc_info=True)
            continue
        out["checked"] += 1
        due = int(plan.get("total_due") or 0)
        if due <= 0:
            continue
        out["due"] += due
        try:
            R.audit_logs.log(actor="scheduler", action="data.retention.due",
                             object="tenant:" + tid,
                             after=json.dumps({"tenant_id": tid, "total_due": due,
                                               "categories": {
                                                   k: {"days": v.get("retention_days"),
                                                       "cutoff": v.get("cutoff"),
                                                       "due": v.get("due"),
                                                       "executable": v.get("executable")}
                                                   for k, v in (plan.get("categories") or {}).items()}},
                                              ensure_ascii=False))
        except Exception:  # noqa: BLE001 - 审计失败不阻断盘点
            logging.getLogger(__name__).debug("retention audit skipped", exc_info=True)
    _last_retention_ts[0] = now
    _last_retention.update({"at": db.now(), "due": out["due"], "tenants": out["tenants"],
                            "checked": out["checked"], "skipped": ""})
    return out


def _loop():
    while True:
        try:
            scan_once()
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        time.sleep(max(30, _INTERVAL))


def start() -> bool:
    """启动后台调度（幂等）。多实例部署时由 DB 锁保证同轮只跑一次。"""
    global _started
    if (os.environ.get("RULEPROOF_SCHEDULER", "on") or "on").lower() in ("off", "0", "false"):
        return False
    with _lock:
        if _started:
            return False
        _started = True
        t = threading.Thread(target=_loop, name="feedback-scheduler", daemon=True)
        t.start()
        return True


def status() -> dict:
    return {"running": _started, "interval_seconds": _INTERVAL,
            "threshold": _THRESHOLD, **(_last_run or {}),
            "retention": dict(_last_retention or {})}
