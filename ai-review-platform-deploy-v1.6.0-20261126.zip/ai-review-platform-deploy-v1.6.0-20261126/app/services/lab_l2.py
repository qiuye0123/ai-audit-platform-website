"""L2：客户规则优先 + 决定性要素校验 + 跨规则同引文去重。"""
import json, re
from .. import repositories as R
from . import lab_l1


def _decisive(criterion: str) -> list:
    nums = re.findall(r"\d+(?:\.\d+)?%?", criterion or "")
    kws = re.findall(r"[\u4e00-\u9fa5]{3,6}(?:天|日|万|元|%)", criterion or "")
    return list(dict.fromkeys(nums + kws))[:6]


def l2_judge(path: str, limit: int = 20) -> dict:
    r = lab_l1.l1_judge(path, limit=limit)
    fs = r["findings"]
    crit_map = {}
    for rule in R.rules.list("status=?", ("published",)):
        vs = R.rule_versions.list("rule_id=?", (rule["id"],), order="id DESC")
        try:
            slots = json.loads((vs[0].get("slots_json") if vs else "") or "{}")
        except Exception:
            slots = {}
        crit_map[rule.get("code")] = str(slots.get("criterion") or rule.get("name") or "")
    kept, dropped = [], 0
    seen_quote = {}
    for f in fs:
        q = str(((f.get("locations") or [{}])[0] or {}).get("quote") or "")
        toks = _decisive(crit_map.get(f["rule_code"], ""))
        # 决定性要素：规则判据里有数字/单位时，引文必须包含其中之一
        if toks and not any(t in q for t in toks):
            # 不丢弃（避免伤召回）：降级为 warning，保留在待人工里
            f["level"] = "warning"
            f["decisive_missing"] = True
        key = re.sub(r"\s+", "", q)[:50]
        if key and key in seen_quote:
            base = seen_quote[key]
            # 同引文重复：保留更严重等级，并合并来源
            if "critical" in (str(base.get("level")), str(f.get("level"))):
                base["level"] = "critical"
            base.setdefault("merged_rules", [base.get("rule_code") or ""]).append(f.get("rule_code") or "")
            dropped += 1
            continue
        # 引文为空：降级为 warning（不丢弃，但不作为高置信）
        if not q:
            f["level"] = "warning"
            f["empty_quote"] = True
        if key:
            seen_quote[key] = f
        kept.append(f)
    r["findings"] = kept
    r["dropped"] = dropped
    return r
