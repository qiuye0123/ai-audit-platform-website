# -*- coding: utf-8 -*-
"""T-43 人工复核闭环（Phase 2/3 主链接线）。

把 T-39 的双轨数据/可见性策略（direct_draft / cross_review / visibility_policy /
suppression_ledger）接入产品主链与人工工作台：

1. **展示项 100% 复核**：``comparison_item.visibility='visible'`` 的每一条差异都必须
   由审核员给出 ``human_status`` 裁决；严重/一般/提示（critical/warning/info）全部
   必须裁决，未裁决的展示项由报告门禁硬阻断。
2. **人工独立填写漏报**：审核员按「位置 / 问题 / 证据 / actor」独立登记系统漏报，
   提交前接口**不返回任何隐藏项（抑制台账）内容**，避免锚定；登记只写
   ``human_omission``（status=pending），不在提交时对账。
3. **后台四类对账**：复用 ``suppression_ledger.reconcile_omission``：
   - 命中展示项 → matched_visible（已报，重复，不恢复）；
   - 命中隐藏项 → matched_hidden（恢复 suppress→recovered + suppression_error 反馈，
     并写回主链 finding 供报告引用）；
   - 命中直连草稿 → matched_direct_draft（平台漏掉直连真 TP）；
   - 未命中 → new_missing（全新漏报进入规则/提示词/执行器候选）。
4. **报告门禁**：``report_gate.check`` 通过 :func:`gate_check` 接入。仅当该 case 有
   双轨数据（comparison_item/direct_draft/human_omission/suppression_ledger 任一非空）
   时生效，无数据的历史链路行为零变化。
5. **CLI/HTTP 同源**：``app/api/server.py`` 路由与 ``app/cli.py`` 命令都只调用本模块；
   权限/租户统一走 ``review.authorize_case``（审核员本人项目可复核；业务管理员只读；
   系统管理员/平台运营禁止访问审核业务），写操作统一写 ``audit_log``（含租户/空间）。

边界（如实标注，不伪造）：
- 直连草稿的**生成**仍离线（需要 LLM 调用）。本模块提供 :func:`prepare_case`：
  当直连草稿已经通过 ``direct_draft.persist_draft/persist_runs`` 不可变落库后，
  由上游管线/运维入口调用，把「直连草稿 + 平台 finding」比对成 comparison_item 并
  应用可见性策略（四桶→visible/suppressed/duplicate）。测试用 ``context_overrides``
  注入上游已知的风险/范围上下文（与 ``visibility_policy.evaluate_comparison`` 的
  ``context`` 接口同义），HTTP 工作台不提供任意注入入口。
- 恢复项写回 ``finding`` 表使用 engine=``manual_recovered``（人工确认的 TP，且
  ``manual*`` 引擎不参与自动证据门禁降级）；original 抑制台账行不删除，只改状态。
- ``report.py`` 的渲染层不在 T-43 写作用域：报告正文的「另有 N 条已抑制」文案由
  报告渲染层后续接线；本模块在 gate/status 中提供 ``hidden_summary`` 同源文案。
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import logging
from contextlib import contextmanager

from .. import db
from . import cross_review as CR
from . import dual_track_gateway as GW

LOGGER = logging.getLogger(__name__)

COMPARISON_TABLE = CR.COMPARISON_TABLE
# T-202：五套双轨机制的**唯一对外入口**是 dual_track_gateway；本模块不再直接
# import direct_draft / visibility_policy 做可见性决策，台账只保留读/写（非决策）。
LEDGER_TABLE = GW.LEDGER_TABLE
OMISSION_TABLE = GW.OMISSION_TABLE
DIRECT_DRAFT_TABLE = GW.DIRECT_DRAFT_TABLE

SEVERITIES = ("critical", "warning", "info")
SEVERITY_LABELS = {"critical": "严重", "warning": "一般", "info": "提示"}
RISK_TO_SEVERITY = {"critical": "critical", "high": "warning", "medium": "warning",
                    "low": "info"}
RISK_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}
SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2}

# 人工裁决取值 = T-39 cross_review 的唯一写入口取值（unreviewed 只表示未裁决）
REVIEW_DECISIONS = tuple(s for s in CR.HUMAN_STATUSES if s != "unreviewed")
CONFIRM_DECISIONS = ("confirmed_direct_true", "confirmed_platform_true",
                     "confirmed_both_true", "recovered_from_suppressed")
NEGATIVE_DECISIONS = ("direct_false_positive", "platform_false_positive", "both_false",
                      "evidence_insufficient", "rule_or_route_error")
REASON_REQUIRED_DECISIONS = NEGATIVE_DECISIONS
DECISION_LABELS = dict(CR.HUMAN_STATUS_LABELS)

# 漏报必填（位置/问题/证据/actor 缺一不可）
OMISSION_REQUIRED_FIELDS = ("locator", "issue", "quote", "actor")
_LOCATOR_KEYS = ("document", "document_id", "filename", "sheet", "row", "col", "cell",
                 "line", "page", "locator", "text", "offset")

_MAX_REASON = 500
_MAX_TEXT = 2000


# --------------------------------------------------------------------------- 基础工具
def _now() -> str:
    return db.now()


def _sha256_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


def _ok(**payload) -> dict:
    return {"ok": True, **payload}


def _err(status, code: str, message: str, **payload) -> dict:
    return {"ok": False, "status": int(status), "code": str(code or "error"),
            "error": str(message or "请求失败"), **payload}


def _loads(value, default):
    if isinstance(value, (dict, list)):
        return value
    try:
        out = json.loads(value or "")
        return out if out is not None else default
    except Exception:
        return default


def _table_exists(conn, table: str) -> bool:
    try:
        return bool(conn.execute("SELECT count(*) FROM sqlite_master WHERE type='table' "
                                 "AND name=?", (table,)).fetchone()[0])
    except Exception:
        return False


def _insert_row(conn, table: str, **cols) -> None:
    """按表实际列过滤后 INSERT（兼容老库/迁移差异，不猜列）。"""
    actual = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    data = {k: v for k, v in cols.items() if k in actual}
    if not data:
        raise ValueError(f"{table} 无可写列")
    keys = list(data.keys())
    sql = (f"INSERT INTO {table} ({','.join(keys)}) "
           f"VALUES ({','.join('?' * len(keys))})")
    conn.execute(sql, [data[k] for k in keys])


@contextmanager
def _conn():
    """独立连接 + 显式事务；内部只做本模块记录（避免与仓储层的二次连接互相等锁）。"""
    c = db.connect()
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _audit(conn, *, actor: str, action: str, obj: str = "", before="", after="",
           case: dict | None = None) -> None:
    """写产品审计日志（audit_log 表；带租户/空间，HTTP/CLI 读取同源）。"""
    case = case or {}
    try:
        _insert_row(
            conn, "audit_log",
            id=db.new_id("log"), actor=str(actor or ""), action=str(action or ""),
            object=str(obj or ""),
            before_json=before if isinstance(before, str) else json.dumps(
                before or {}, ensure_ascii=False),
            after_json=after if isinstance(after, str) else json.dumps(
                after or {}, ensure_ascii=False),
            request_id="", ip="", created_at=_now(),
            tenant_id=str(case.get("tenant_id") or ""),
            workspace_id=str(case.get("workspace_id") or ""))
    except Exception:  # noqa: BLE001
        LOGGER.warning("human_review audit write skipped action=%s", action,
                       exc_info=True)


def _case(case_id: str) -> dict | None:
    from .. import repositories as R
    try:
        return R.cases.get(str(case_id or ""))
    except Exception:  # noqa: BLE001
        return None


def _authorize(case_id: str, action: str, actor: str = "", role: str = "") -> dict:
    """权限/租户唯一事实源：review.authorize_case（HTTP/CLI/服务层同源）。

    无 actor/role 的内部调用（脚本/测试）不做角色校验；只要传了身份就严格校验，
    防止 HTTP/CLI 各自实现一套权限。
    """
    from . import review as _review
    if not str(actor or "").strip() and not str(role or "").strip():
        return {"ok": True, "actor": "", "role": "", "read_only": False,
                "can_review": False, "resolved": False}
    try:
        return _review.authorize_case(case_id, action, actor, role)
    except Exception:  # noqa: BLE001
        LOGGER.warning("human_review authorize skipped", exc_info=True)
        return {"ok": False, "status": 403, "code": "forbidden",
                "message": "无权限"}


def _deny(access: dict) -> dict:
    return _err(int(access.get("status") or 403), access.get("code") or "forbidden",
                access.get("message") or "无权限")


# --------------------------------------------------------------------------- 可见性/严重度
def _risk_levels(item: dict) -> list:
    decisions = item.get("visibility_detail")
    if isinstance(decisions, str):
        decisions = _loads(decisions, {})
    decisions = decisions if isinstance(decisions, dict) else {}
    risks = []
    for side in ("direct", "platform"):
        side_dec = decisions.get(side) or {}
        if isinstance(side_dec, dict) and side_dec.get("risk_level"):
            risks.append(str(side_dec["risk_level"]))
    return risks


def severity_of_item(item: dict, view: dict | None = None) -> tuple:
    """展示项严重度：visible 决策的风险等级 → 严重/一般/提示。

    优先用可见性策略落库的 decisions.risk_level（T-39 口径）；没有时回退到平台
    finding severity / 直接条目的高风险类别（visibility_policy.resolve_risk 同义），
    仍无法判断时按“一般”处理（宁可多复核，不静默降级）。
    """
    risks = [r for r in _risk_levels(item) if r in RISK_ORDER]
    if not risks:
        view = view or {}
        platform = view.get("platform") or {}
        sev = str(platform.get("severity") or "").strip().lower()
        if sev in RISK_ORDER:
            risks.append(sev)
        elif sev in ("critical", "warning", "info"):
            risks.append({"critical": "critical", "warning": "medium",
                          "info": "low"}[sev])
    if not risks:
        direct = (view or {}).get("direct") or {}
        text = " ".join(str(direct.get(k) or "") for k in
                        ("issue_type", "subject", "rule_code", "issue"))
        if GW.is_high_risk_text(text):
            risks.append("high")
    risk = min(risks, key=lambda r: RISK_ORDER.get(r, 9)) if risks else "medium"
    return RISK_TO_SEVERITY.get(risk, "warning"), risk


def _split_sides(item: dict, view: dict | None) -> dict:
    """一条 comparison_item → 工作台双栏展示（只展示可见差异，不含隐藏项内容）。"""
    view = view or {}
    status = str(item.get("human_status") or "unreviewed")
    decisions = item.get("visibility_detail")
    if isinstance(decisions, str):
        decisions = _loads(decisions, {})
    decisions = decisions if isinstance(decisions, dict) else {}
    reason_codes = []
    for side in ("direct", "platform"):
        dec = decisions.get(side) or {}
        if isinstance(dec, dict) and dec.get("reason_code"):
            reason_codes.append(str(dec["reason_code"]))
    return {
        "item_id": str(item.get("id") or ""),
        "bucket": str(item.get("bucket") or ""),
        "bucket_label": CR.BUCKET_LABELS.get(str(item.get("bucket") or ""),
                                             str(item.get("bucket") or "")),
        "rule_code": str(item.get("match_key_code") or ""),
        "subject": str(item.get("match_key_subject") or ""),
        "issue_type": str(item.get("match_key_issue_type") or ""),
        "clause": str(item.get("match_key_clause") or ""),
        "direct": (view.get("direct") or None),
        "platform": (view.get("platform") or None),
        "human_status": status,
        "human_label": DECISION_LABELS.get(status, status),
        "human_actor": str(item.get("human_actor") or ""),
        "human_reason": str(item.get("human_reason") or ""),
        "needs_review": status == "unreviewed",
        "visibility": str(item.get("visibility") or ""),
        "reason_codes": reason_codes,
        "auto_similarity": item.get("auto_similarity"),
        "auto_note": str(item.get("auto_note") or ""),
        "auto_is_hint_only": True,
        "not_gold": True,
    }


# --------------------------------------------------------------------------- 复核队列 / 计数
def review_queue(conn, case_id: str) -> list:
    """展示项队列：只有 visibility='visible' 的差异需要人工 100% 复核。"""
    out = []
    for item in CR.list_comparison_items(conn, case_id=case_id, visibility="visible"):
        view = CR.item_view(conn, item["id"])
        row = _split_sides(item, view)
        row["severity"], row["risk_level"] = severity_of_item(item, view)
        row["severity_label"] = SEVERITY_LABELS[row["severity"]]
        out.append(row)
    out.sort(key=lambda x: (SEVERITY_ORDER.get(x["severity"], 9),
                            x.get("item_id") or ""))
    return out


def review_progress(conn, case_id: str) -> dict:
    items = review_queue(conn, case_id)
    by_sev = {s: {"total": 0, "reviewed": 0, "pending": 0} for s in SEVERITIES}
    pending = reviewed = 0
    for it in items:
        b = by_sev.setdefault(it["severity"],
                              {"total": 0, "reviewed": 0, "pending": 0})
        b["total"] += 1
        if it["human_status"] == "unreviewed":
            pending += 1
            b["pending"] += 1
        else:
            reviewed += 1
            b["reviewed"] += 1
    return {"visible_total": len(items), "visible_reviewed": reviewed,
            "visible_pending": pending,
            "by_severity": {k: v for k, v in by_sev.items() if v["total"]},
            "items": items}


def hidden_stats(conn, case_id: str) -> dict:
    """抑制台账统计（后台对账/审计用；不进入审核员展示队列）。"""
    if not _table_exists(conn, LEDGER_TABLE):
        return {"total": 0, "suppressed": 0, "recovered": 0, "sampled": 0,
                "by_reason": {}, "by_source": {}, "hidden_summary": ""}
    rows = GW.ledger_list(conn, case_id=case_id)
    suppressed = [r for r in rows if r.get("visibility_status") == "suppressed"]
    recovered = [r for r in rows if r.get("visibility_status") == "recovered"]
    by_reason, by_source = {}, {}
    for r in rows:
        by_reason[str(r.get("suppression_reason") or "")] = \
            by_reason.get(str(r.get("suppression_reason") or ""), 0) + 1
        by_source[str(r.get("source") or "")] = \
            by_source.get(str(r.get("source") or ""), 0) + 1
    return {"total": len(rows), "suppressed": len(suppressed),
            "recovered": len(recovered), "sampled": len([r for r in rows if r.get("sampled")]),
            "by_reason": by_reason, "by_source": by_source,
            "hidden_summary": GW.ledger_hidden_summary(conn, case_id)}


def omission_stats(conn, case_id: str) -> dict:
    rows = GW.omission_list(conn, case_id=case_id)
    by_status = {}
    for r in rows:
        by_status[str(r.get("status") or "")] = \
            by_status.get(str(r.get("status") or ""), 0) + 1
    pending = len([r for r in rows if r.get("status") == "pending"])
    return {"total": len(rows), "pending": pending,
            "by_status": by_status,
            "reconciled": len(rows) - pending}


def _presence(conn, case_id: str) -> dict:
    """该 case 是否已有双轨数据；无数据 → 门禁不生效（老链路零变化）。"""
    out = {"comparison_items": 0, "direct_drafts": 0, "omissions": 0,
           "ledger": 0, "visibility_unset": 0}
    for key, table in (("comparison_items", COMPARISON_TABLE),
                       ("direct_drafts", DIRECT_DRAFT_TABLE),
                       ("omissions", OMISSION_TABLE), ("ledger", LEDGER_TABLE)):
        if _table_exists(conn, table):
            try:
                out[key] = int(conn.execute(
                    f"SELECT count(*) FROM {table} WHERE case_id=?", (case_id,)
                ).fetchone()[0] or 0)
            except Exception:
                out[key] = 0
    if out["comparison_items"] and _table_exists(conn, COMPARISON_TABLE):
        try:
            out["visibility_unset"] = int(conn.execute(
                f"SELECT count(*) FROM {COMPARISON_TABLE} WHERE case_id=? AND "
                "(visibility IS NULL OR visibility='')", (case_id,)).fetchone()[0] or 0)
        except Exception:
            out["visibility_unset"] = 0
    out["enabled"] = bool(out["comparison_items"] or out["direct_drafts"]
                          or out["omissions"] or out["ledger"])
    return out


# --------------------------------------------------------------------------- 报告门禁
def gate_check(case_id: str) -> dict:
    """报告门禁的双轨/人工复核条件（report_gate.check 调用；无数据时 ok=True）。"""
    out = {"enabled": False, "ok": True, "reasons": [],
           "stats": {"visible_total": 0, "visible_reviewed": 0, "visible_pending": 0,
                     "visibility_unset": 0, "omission_pending": 0,
                     "hidden_suppressed": 0, "hidden_recovered": 0,
                     "by_severity": {}, "hidden_summary": ""},
           "not_gold": True}
    cid = str(case_id or "").strip()
    if not cid:
        return out
    try:
        with _conn() as conn:
            presence = _presence(conn, cid)
            out["stats"].update({k: presence[k] for k in
                                 ("visibility_unset",)})
            if not presence["enabled"]:
                return out
            progress = review_progress(conn, cid)
            hidden = hidden_stats(conn, cid)
            omissions = omission_stats(conn, cid)
            reasons = []
            if presence["visibility_unset"]:
                reasons.append(
                    f"仍有 {presence['visibility_unset']} 条双轨差异未应用可见性策略"
                    "（差异未处理，不能出报告）")
            if progress["visible_pending"]:
                sev = progress["by_severity"]
                reasons.append(
                    f"仍有 {progress['visible_pending']} 条展示项未复核"
                    f"（严重 {sev.get('critical', {}).get('pending', 0)} / "
                    f"一般 {sev.get('warning', {}).get('pending', 0)} / "
                    f"提示 {sev.get('info', {}).get('pending', 0)}）："
                    "展示项必须 100% 裁决")
            if omissions["pending"]:
                reasons.append(
                    f"仍有 {omissions['pending']} 条人工漏报未对账"
                    "（差异未处理，不能出报告）")
            out.update({
                "enabled": True, "ok": not reasons, "reasons": reasons,
                "stats": {
                    "visible_total": progress["visible_total"],
                    "visible_reviewed": progress["visible_reviewed"],
                    "visible_pending": progress["visible_pending"],
                    "visibility_unset": presence["visibility_unset"],
                    "omission_pending": omissions["pending"],
                    "omission_total": omissions["total"],
                    "hidden_suppressed": hidden["suppressed"],
                    "hidden_recovered": hidden["recovered"],
                    "hidden_sampled": hidden["sampled"],
                    "by_severity": progress["by_severity"],
                    "hidden_summary": hidden["hidden_summary"],
                    "comparison_items": presence["comparison_items"],
                    "direct_drafts": presence["direct_drafts"],
                },
            })
    except Exception:  # noqa: BLE001
        LOGGER.warning("human_review gate skipped case=%s", cid, exc_info=True)
        return {"enabled": False, "ok": True, "reasons": [],
                "stats": out["stats"], "skipped_error": True, "not_gold": True}
    return out


def _redact_hidden_gate(gate: dict | None) -> dict:
    """工作台门禁视图：隐藏项数量/文案对审核员不可见（防锚定）。

    隐藏项只在后台对账入口 ``backend_view`` / 报告口径 ``hidden_summary`` 中出现；
    工作台（case_payload/decide/submit/prepare）一律脱敏。
    """
    gate = dict(gate or {})
    stats = dict(gate.get("stats") or {})
    for key in ("hidden_suppressed", "hidden_recovered", "hidden_sampled",
                "hidden_summary"):
        stats.pop(key, None)
    stats["hidden_visible_to_role"] = False
    gate["stats"] = stats
    return gate


# --------------------------------------------------------------------------- 公共读接口
def case_payload(case_id: str, actor: str = "", role: str = "",
                 include_hidden: bool = False, via: str = "http") -> dict:
    """工作台数据（展示项队列 + 漏报 + 门禁 + 权限 + 隐藏开关摘要）。

    **默认不返回隐藏项内容**（开关默认关闭；防锚定）：隐藏池只返回独立
    ``hidden`` 摘要（production 显示 N；evaluation 提交独立复核前连 N 都不返回）。
    ``include_hidden=True`` 是显式打开动作（HTTP ?include_hidden=1 / CLI
    --include-hidden），会写 reveal 审计并返回独立 ``hidden.items`` 区，
    **绝不混入 ``review.items`` 主列表**。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "view", actor, role)
    if not access.get("ok"):
        return _deny(access)
    access_actor = str(access.get("actor") or actor or "")
    access_role = str(access.get("role") or role or "")
    hidden_reveal = None
    if include_hidden:
        hidden_reveal = hidden_items(cid, actor=access_actor, role=access_role,
                                     include_hidden=True, via=via)
        if not hidden_reveal.get("ok"):
            return hidden_reveal
    with _conn() as conn:
        presence = _presence(conn, cid)
        progress = review_progress(conn, cid) if presence["enabled"] else {
            "visible_total": 0, "visible_reviewed": 0, "visible_pending": 0,
            "by_severity": {}, "items": []}
        omissions = GW.omission_list(conn, case_id=cid) if presence["enabled"] else []
        omission_counts = omission_stats(conn, cid) if presence["enabled"] else {
            "total": 0, "pending": 0, "by_status": {}, "reconciled": 0}
    gate = gate_check(cid)
    _product_gate = product_gate(cid)
    gate["gates"] = dict(_product_gate.get("gates") or {})
    case_info = {k: case.get(k) for k in
                 ("id", "name", "status", "created_by", "tenant_id", "workspace_id",
                  "last_run_id", "audit_type", "document_type")}
    # T-51：隐藏疑似问题开关摘要（默认关闭；内容不进 review.items 主列表）
    if hidden_reveal is not None:
        hidden_block = dict(hidden_reveal.get("hidden") or {})
        hidden_block["items"] = hidden_reveal.get("items") or []
        hidden_block["visible_targets"] = hidden_reveal.get("visible_targets") or []
        hidden_block["visible_to_role"] = True
        hidden_items_list = hidden_reveal.get("items") or []
        review_mode = str(hidden_reveal.get("mode") or REVIEW_MODE_DEFAULT)
        hidden_independent = bool(
            (hidden_reveal.get("hidden") or {}).get("locked") is False
            and (hidden_reveal.get("mode") == "evaluation"))
    else:
        _hidden_info = hidden_toggle_info(cid, actor=access_actor, role=access_role,
                                          via="case_payload")
        hidden_block = dict(_hidden_info.get("hidden") or {}) \
            if _hidden_info.get("ok") else {"visible_to_role": False}
        hidden_items_list = []
        review_mode = str(hidden_block.get("mode") or REVIEW_MODE_DEFAULT)
        hidden_independent = bool(_hidden_info.get("independent_submitted")) \
            if _hidden_info.get("ok") else False
    hidden_block.setdefault("visible_to_role", False)
    hidden_block["items"] = hidden_block.get("items") or []
    can_reveal = bool(hidden_block.get("can_reveal"))
    return _ok(
        case_id=cid, case=case_info, enabled=presence["enabled"],
        review=progress,
        decisions={"allowed": list(REVIEW_DECISIONS),
                   "labels": DECISION_LABELS,
                   "reason_required": list(REASON_REQUIRED_DECISIONS)},
        omissions={"total": len(omissions),
                   "pending": omission_counts["pending"],
                   "by_status": omission_counts["by_status"],
                   "items": [_public_omission(o) for o in omissions]},
        # T-51：隐藏区与可见区物理分开；默认只给摘要（production 显示 N；
        # evaluation 提交独立复核前不返回 N/内容），打开后才给独立 items。
        hidden=hidden_block,
        hidden_items=hidden_items_list,
        review_mode=review_mode,
        mode_label=MODE_LABELS.get(review_mode, review_mode),
        independent_submitted=hidden_independent,
        gate=_redact_hidden_gate(gate),
        gates=dict(_product_gate.get("gates") or {}),
        gate_reasons=list(_product_gate.get("reasons") or []),
        permissions={"can_review": bool(access.get("can_review")),
                     "read_only": bool(access.get("read_only")),
                     "can_reveal": can_reveal,
                     "read_only_hidden_pool": bool(access_role == "admin"),
                     "role": access_role,
                     "actor": access_actor},
        not_gold=True)


def _public_omission(row: dict) -> dict:
    out = {k: row.get(k) for k in
           ("id", "case_id", "actor", "quote", "issue", "rule_hint", "object_id",
            "subject", "status", "match_type", "matched_ref", "recovered_ledger_id",
            "note", "created_at", "reconciled_at")}
    out["locator"] = row.get("locator") or {}
    out["feedback_candidate"] = row.get("feedback_candidate") or {}
    return out


def backend_view(case_id: str, actor: str = "", role: str = "") -> dict:
    """后台对账/审计视图：抑制台账（隐藏项原始主张）+ 漏报反馈候选。

    仅业务管理员（只读）可查看：隐藏项对审核员完全不可见（防锚定，提交漏报前
    更不能看到隐藏项内容）；后台对账由服务在漏报提交后自动执行，结果在
    reconcile 响应中返回（此时人工漏报已提交，不再有锚定风险）。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "view", actor, role)
    if not access.get("ok"):
        return _deny(access)
    if not access.get("read_only") or str(access.get("role") or role) != "admin":
        return _err(403, "forbidden",
                    "后台对账/审计入口仅业务管理员只读查看；审核员工作台不显示隐藏项")
    with _conn() as conn:
        hidden = hidden_stats(conn, cid)
        ledger = GW.ledger_list(conn, case_id=cid)
        omissions = GW.omission_list(conn, case_id=cid)
        feedback = GW.feedback_candidates(conn, case_id=cid)
        presence = _presence(conn, cid)
    return _ok(case_id=cid, enabled=presence["enabled"], hidden=hidden,
               ledger=[_ledger_public(r) for r in ledger],
               omissions=[_public_omission(o) for o in omissions],
               feedback_candidates=feedback,
               permissions={"read_only": bool(access.get("read_only")),
                            "can_review": bool(access.get("can_review")),
                            "role": str(access.get("role") or role or "")},
               not_gold=True)


def _ledger_public(row: dict) -> dict:
    return {k: row.get(k) for k in
            ("id", "case_id", "source", "rule_code", "subject", "issue_type",
             "risk_level", "suppression_reason", "visibility_status", "sampled",
             "human_result", "recovered_finding_ref", "created_at")} | {
        "raw_claim": row.get("raw_claim") or {},
        "evidence": row.get("evidence") or {},
        "refute_evidence": row.get("refute_evidence") or {},
        "raw_claim_sha256": row.get("raw_claim_sha256") or "",
    }


# --------------------------------------------------------------------------- 人工裁决
def decide_item(case_id: str, item_id: str, decision: str, *, actor: str = "",
                role: str = "", reason: str = "", label: str = "",
                evidence: dict | None = None) -> dict:
    """展示项人工裁决（唯一写入口 = cross_review.set_human_decision + 审计）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(400, "actor_required", "人工裁决必须记录 actor，禁止匿名")
    decision = str(decision or "").strip()
    if decision in ("", "unreviewed"):
        return _err(400, "invalid_decision",
                    "必须给出有效裁决（unreviewed 不是裁决结果）",
                    allowed=list(REVIEW_DECISIONS))
    if decision not in REVIEW_DECISIONS:
        return _err(400, "invalid_decision",
                    f"非法裁决：{decision}（可选：{', '.join(REVIEW_DECISIONS)}）",
                    allowed=list(REVIEW_DECISIONS))
    reason = str(reason or "").strip()[:_MAX_REASON]
    if decision in REASON_REQUIRED_DECISIONS and not reason:
        return _err(400, "reason_required",
                    f"裁决 {DECISION_LABELS.get(decision, decision)} 必须填写原因")
    with _conn() as conn:
        item = CR.get_comparison_item(conn, str(item_id or ""))
        if not item:
            return _err(404, "not_found", "双轨差异项不存在")
        if str(item.get("case_id") or "") != cid:
            return _err(404, "not_found", "双轨差异项不属于该项目")
        if str(item.get("visibility") or "") != "visible":
            return _err(
                409, "item_not_visible",
                "该差异项不在展示队列（隐藏/重复项不进入人工裁决）；隐藏项被人工漏报命中后会自动恢复",
                item_id=item.get("id"), visibility=item.get("visibility") or "")
        try:
            out = CR.set_human_decision(
                conn, item["id"], decision, actor=human_actor, reason=reason,
                label=label or DECISION_LABELS.get(decision, decision),
                evidence={"via": "human_review", "case_id": cid,
                          **(evidence or {})})
        except CR.HumanDecisionConflict as e:
            # C5：并发裁决已被他人改判 → 409，禁止静默覆盖（本次不写 event/审计）。
            return _err(409, "decision_conflict",
                        "裁决冲突：该差异项结论已被他人修改，请刷新后按当前结论重新裁决",
                        item_id=str(item.get("id") or ""), **e.payload())
        except (ValueError, KeyError) as e:
            return _err(400, "decision_failed", str(e))
        _audit(conn, actor=human_actor, action="human_review.decide",
               obj=str(item["id"]), case=case,
               before=str(item.get("human_status") or "unreviewed"),
               after=json.dumps({"decision": decision, "reason": reason,
                                 "case_id": cid}, ensure_ascii=False))
    progress = None
    try:
        with _conn() as conn:
            progress = review_progress(conn, cid)
    except Exception:  # noqa: BLE001
        LOGGER.warning("review progress skipped", exc_info=True)
    return _ok(case_id=cid, item_id=str(item["id"]), decision=decision,
               decision_label=DECISION_LABELS.get(decision, decision),
               before_status=out.get("before_status"),
               after_status=out.get("after_status"),
               review=progress, gate=_redact_hidden_gate(gate_check(cid)),
               not_gold=True)


# --------------------------------------------------------------------------- 人工漏报
def _normalize_locator(locator) -> dict:
    if isinstance(locator, dict):
        return {str(k): v for k, v in locator.items() if v not in (None, "", [])}
    if isinstance(locator, str) and locator.strip():
        return {"text": locator.strip()}
    return {}


def _locator_text(locator: dict) -> str:
    if not locator:
        return ""
    if str(locator.get("text") or "").strip():
        return str(locator["text"]).strip()
    parts = []
    for k in _LOCATOR_KEYS:
        v = locator.get(k)
        if v not in (None, "", []):
            parts.append(f"{k}:{v}" if k != "locator" else str(v))
    return " · ".join(parts)


def submit_omission(case_id: str, *, actor: str = "", role: str = "", quote: str = "",
                    issue: str = "", locator=None, rule_hint: str = "",
                    subject: str = "", object_id: str = "", note: str = "") -> dict:
    """人工独立填写漏报（位置/问题/证据/actor 缺一不可；提交时不显示隐藏项）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(400, "actor_required", "漏报登记必须记录 actor")
    loc = _normalize_locator(locator)
    quote = str(quote or "").strip()[:_MAX_TEXT]
    issue = str(issue or "").strip()[:_MAX_TEXT]
    missing = []
    if not _locator_text(loc):
        missing.append("位置")
    if not issue:
        missing.append("问题")
    if not quote:
        missing.append("证据")
    if not human_actor:
        missing.append("actor")
    if missing:
        return _err(400, "omission_incomplete",
                    f"人工漏报必须填写：{'、'.join(missing)}（位置/问题/证据/actor 缺一不可）",
                    missing=missing)
    with _conn() as conn:
        rec = GW.omission_record(
            conn, case_id=cid, quote=quote, issue=issue,
            rule_hint=str(rule_hint or "").strip()[:200],
            object_id=str(object_id or "").strip()[:200],
            subject=str(subject or "").strip()[:200],
            actor=human_actor, locator={**loc, "text": _locator_text(loc)},
            run_id=str(case.get("last_run_id") or ""),
            tenant_id=str(case.get("tenant_id") or ""),
            workspace_id=str(case.get("workspace_id") or ""),
            note=str(note or "").strip()[:_MAX_REASON])
        _audit(conn, actor=human_actor, action="human_omission.recorded",
               obj=str(rec.get("id") or ""), case=case,
               after=json.dumps({"case_id": cid, "issue": issue,
                                 "locator": _locator_text(loc),
                                 "quote_sha256": _sha256_text(quote)},
                                ensure_ascii=False))
    return _ok(case_id=cid, omission=_public_omission(rec),
               # 提交阶段绝不对账、绝不返回隐藏项内容（防锚定）
               reconciled=False, auto_reconcile=False,
               hidden_visible_to_role=False,
               gate=_redact_hidden_gate(gate_check(cid)), not_gold=True)


def list_omissions(case_id: str, *, actor: str = "", role: str = "", status: str = "") -> dict:
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "view", actor, role)
    if not access.get("ok"):
        return _deny(access)
    with _conn() as conn:
        rows = GW.omission_list(conn, case_id=cid, status=str(status or ""))
        stats = omission_stats(conn, cid)
    return _ok(case_id=cid, omissions=[_public_omission(r) for r in rows],
               counts=stats, hidden_visible_to_role=False,
               permissions={"read_only": bool(access.get("read_only"))},
               not_gold=True)


# --------------------------------------------------------------------------- 后台对账
def _first_document_id(conn, case_id: str) -> str:
    try:
        row = conn.execute(
            "SELECT document_id FROM case_document WHERE case_id=? LIMIT 1",
            (case_id,)).fetchone()
        return str((row["document_id"] if row else "") or "")
    except Exception:
        return ""


def _write_recovered_finding(conn, case: dict, ledger: dict, omission: dict,
                             actor: str) -> str:
    """隐藏项命中人工漏报 → 恢复并写回主链 finding（报告可见，台账行保留）。"""
    raw = ledger.get("raw_claim") or {}
    risk = str(ledger.get("risk_level") or "medium")
    severity = RISK_TO_SEVERITY.get(risk, "warning")
    parts = []
    for value in (raw.get("issue"), raw.get("summary"), raw.get("reason"),
                  omission.get("issue")):
        text = str(value or "").strip()
        if text and text not in parts:
            parts.append(text)
    claim_issue = " / ".join(parts)
    rule_code = str(raw.get("rule_code") or ledger.get("rule_code") or "RECOVERED")
    title = f"[漏报恢复] {claim_issue or rule_code}"[:_MAX_TEXT]
    quote = str(omission.get("quote") or raw.get("quote") or "").strip()
    locator = _locator_text(omission.get("locator") or {})
    finding_id = db.new_id("fnd")
    _insert_row(
        conn, "finding",
        id=finding_id, case_id=str(case.get("id") or ""), rule_id=rule_code,
        rule_version="dual_track_recovered", severity=severity, certainty="probable",
        confidence=None, state="fail", status="confirmed", title=title,
        summary=("人工漏报命中被抑制项，已按 suppression_error 恢复为可见问题；"
                 "抑制原因/反证/阈值需复核。")[:_MAX_TEXT],
        suggestion="复核该抑制原因与反证证据，必要时调整可见性策略/阈值。",
        grade="", engine="manual_recovered",
        run_id=str(case.get("last_run_id") or ""),
        tenant_id=str(case.get("tenant_id") or ""),
        workspace_id=str(case.get("workspace_id") or ""),
        object_id=str(raw.get("object_id") or ledger.get("object_id") or ""))
    doc_id = _first_document_id(conn, str(case.get("id") or ""))
    if doc_id and quote:
        anchor_id = db.new_id("anc")
        _insert_row(conn, "anchor", id=anchor_id, document_id=doc_id, sheet="",
                    row=None, col="", locator=locator, quote=quote[:500],
                    hash=_sha256_text(f"{doc_id}|{locator}|{quote}"))
        _insert_row(conn, "evidence", id=db.new_id("evd"), finding_id=finding_id,
                    document_id=doc_id, anchor_id=anchor_id, excerpt=quote[:500],
                    label="人工漏报恢复")
    try:
        conn.execute(f"UPDATE {LEDGER_TABLE} SET recovered_finding_ref=? WHERE id=?",
                     (finding_id, str(ledger.get("id") or "")))
    except Exception:  # noqa: BLE001
        LOGGER.warning("ledger recovered_finding_ref update skipped", exc_info=True)
    _audit(conn, actor=actor, action="human_review.recovered_finding",
           obj=finding_id, case=case,
           before=str(ledger.get("id") or ""),
           after=json.dumps({"finding_id": finding_id, "severity": severity,
                             "rule_code": rule_code,
                             "ledger_id": str(ledger.get("id") or "")},
                            ensure_ascii=False))
    return finding_id


def reconcile_case(case_id: str, *, actor: str = "", role: str = "",
                   doc_text: str = "") -> dict:
    """后台对账本轮 pending 漏报（展示项/隐藏项/直连草稿/新问题四分支）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(400, "actor_required", "后台对账必须记录 actor")
    with _conn() as conn:
        # T-51：恢复前先确保隐藏项已入进化池（无动作/未打开也要进池）
        try:
            _enqueue_evolution(conn, case, GW.ledger_list(conn, case_id=cid),
                               actor=human_actor, via="reconcile")
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution enqueue on reconcile skipped case=%s", cid,
                           exc_info=True)
        pending = GW.omission_list(conn, case_id=cid, status="pending")
        results = []
        recovered_findings = []
        for omission in pending:
            try:
                res = GW.omission_reconcile(conn, omission["id"],
                                            actor=human_actor, doc_text=doc_text)
            except Exception as e:  # noqa: BLE001
                LOGGER.warning("omission reconcile failed id=%s", omission.get("id"),
                               exc_info=True)
                results.append({"omission_id": omission.get("id"), "status": "error",
                                "error": f"{type(e).__name__}: {e}"})
                continue
            row = {"omission_id": omission["id"],
                   "status": res.get("status"), "match_type": res.get("match_type"),
                   "matched_ref": res.get("matched_ref") or "",
                   "changed": bool(res.get("changed"))}
            if res.get("status") == "matched_hidden" and res.get("recovered_ledger_id"):
                ledger = GW.ledger_get(conn, res["recovered_ledger_id"])
                if ledger:
                    fid = _write_recovered_finding(conn, case, ledger,
                                                   res.get("omission") or omission,
                                                   human_actor)
                    row["recovered_finding_id"] = fid
                    recovered_findings.append(fid)
            results.append(row)
            _audit(conn, actor=human_actor, action="human_omission.reconciled",
                   obj=str(omission["id"]), case=case,
                   before="pending", after=str(res.get("status") or ""))
        # T-51：对账命中隐藏项 → 进化弱人工标签（来源 omission_reconcile）
        for row in results:
            if row.get("status") != "matched_hidden" or not row.get("matched_ref"):
                continue
            ledger_row = GW.ledger_get(conn, str(row["matched_ref"]))
            if not ledger_row:
                continue
            try:
                _record_evolution_label(
                    conn, case, ledger_row, action="confirm", actor=human_actor,
                    reason="人工漏报对账命中隐藏项（恢复 + suppression_error）",
                    source="omission_reconcile")
            except Exception:  # noqa: BLE001
                LOGGER.warning("evolution label on reconcile skipped", exc_info=True)
        stats = omission_stats(conn, cid)
        hidden = hidden_stats(conn, cid)
        feedback = GW.feedback_candidates(conn, case_id=cid)
    by_status = {}
    for r in results:
        by_status[str(r.get("status") or "")] = \
            by_status.get(str(r.get("status") or ""), 0) + 1
    return _ok(case_id=cid, reconciled=len(results), by_status=by_status,
               results=results, recovered_findings=recovered_findings,
               omissions=stats, hidden=hidden,
               feedback_candidates=feedback, gate=gate_check(cid), not_gold=True)


# --------------------------------------------------------------------------- 双轨数据接入
def _build_context_map(comparison: dict, item_ids: list, direct_items: list,
                       overrides: dict | None) -> dict:
    """上游上下文注入（风险/范围/反证）→ 按 comparison_item 聚合 context。

    overrides 形如 {direct_item_id|platform_finding_id: {...candidate fields...}}；
    值里含 ``direct``/``platform`` 键时视为分侧覆盖。
    """
    overrides = overrides or {}
    if not isinstance(overrides, dict):
        return {}
    direct_ids = [str(it.get("id") or "") for it in (direct_items or [])]
    out = {}
    for rec, item_id in zip(list(comparison.get("records") or []), item_ids):
        direct = rec.get("direct") or {}
        platform = rec.get("platform") or {}
        d_idx = rec.get("direct_index")
        d_item_id = ""
        if d_idx is not None and 0 <= int(d_idx) < len(direct_ids):
            d_item_id = direct_ids[int(d_idx)]
        p_item_id = str(platform.get("id") or "")
        ctx = {}
        for oid in (d_item_id, p_item_id):
            ov = overrides.get(str(oid)) if oid else None
            if not isinstance(ov, dict) or not ov:
                continue
            explicit = {k: v for k, v in ov.items() if k in ("direct", "platform")}
            if explicit:
                for side, val in explicit.items():
                    if isinstance(val, dict):
                        ctx.setdefault(side, {}).update(val)
            else:
                if d_item_id and str(d_item_id) == str(oid):
                    ctx.setdefault("direct", {}).update(ov)
                if p_item_id and str(p_item_id) == str(oid):
                    ctx.setdefault("platform", {}).update(ov)
        if ctx:
            out[str(item_id)] = ctx
    return out


def prepare_case(case_id: str, *, actor: str = "", role: str = "",
                 doc_text: str = "", context_overrides: dict | None = None) -> dict:
    """把已落库直连草稿 + 平台 finding 生成四桶差异并应用可见性策略（Phase 2 接入点）。

    不生成直连草稿（直连调用仍属离线准确率链路）；只消费 ``direct_draft`` 不可变数据。
    幂等：重复调用不会重复落库/改人工结论（persist_comparison 按 item_key 幂等，
    apply_case_visibility 只处理未设置可见性的条目）。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(400, "actor_required", "生成双轨差异必须记录 actor")
    with _conn() as conn:
        # T-202 主链第 1 步（唯一入口）：直连原件只经 gateway 读取
        source = GW.direct_draft_source(conn, cid)
        drafts = source["drafts"]
        if not drafts:
            return _err(400, "no_direct_draft",
                        "该项目没有已落库的直连草稿（direct_draft），无法生成双轨差异")
        direct_items, run_id = list(source["items"]), str(source["run_id"] or "")
        if not direct_items:
            return _err(400, "no_direct_item",
                        "直连草稿没有解析出的问题条目，无法生成双轨差异")
        platform = CR.platform_findings(conn, case_id=cid)
        findings = [p.get("normalized") or {} for p in platform]
        comparison = CR.compare_case(cid, doc_text or "", direct_items, findings)
        direct_item_ids = [str(it.get("id") or "") for it in direct_items]
        persisted = CR.persist_comparison(
            conn, comparison, run_id=run_id,
            tenant_id=str(case.get("tenant_id") or ""),
            workspace_id=str(case.get("workspace_id") or ""),
            direct_draft_id=str(drafts[-1].get("id") or ""),
            direct_item_ids=direct_item_ids)
        context_map = _build_context_map(comparison, persisted["item_ids"],
                                         direct_items, context_overrides)
        # T-202 主链第 3→4 步（唯一入口）：策略裁决 + 台账落库只经 gateway
        applied = GW.apply_case_visibility(
            conn, cid, context_map=context_map, only_unset=True,
            tenant_id=str(case.get("tenant_id") or ""),
            workspace_id=str(case.get("workspace_id") or ""),
            actor=f"system:human_review:{human_actor}")
        _audit(conn, actor=human_actor, action="human_review.prepare",
               obj=cid, case=case,
               after=json.dumps({"drafts": len(drafts),
                                 "direct_items": len(direct_items),
                                 "platform_findings": len(findings),
                                 "comparison": comparison.get("buckets") or {},
                                 "created": persisted.get("created"),
                                 "existing": persisted.get("existing"),
                                 "visibility": {k: applied.get(k) for k in
                                                ("applied", "visible", "suppressed",
                                                 "duplicate")}},
                                ensure_ascii=False))
        # T-51：隐藏项创建即进入进化池（feedback + evolution_enqueued 事件，幂等）
        try:
            _enqueue_evolution(conn, case, GW.ledger_list(conn, case_id=cid),
                               actor=f"system:human_review:{human_actor}",
                               via="prepare")
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution enqueue on prepare skipped case=%s", cid,
                           exc_info=True)
        visibility = {k: applied.get(k) for k in
                      ("applied", "visible", "suppressed", "duplicate")}
    return _ok(case_id=cid, prepared=visibility,
               drafts=len(drafts), direct_items=len(direct_items),
               platform_findings=len(findings),
               comparison={"buckets": comparison.get("buckets") or {},
                           "created": persisted.get("created"),
                           "existing": persisted.get("existing"),
                           "total": persisted.get("total")},
               visibility=visibility,
               gate=_redact_hidden_gate(gate_check(cid)), not_gold=True)


# ===========================================================================
# T-50（Qoder W-14）V3.2 产品接线：双轨数据只读面 + 四项报告门禁
#
# 背景（W-14 原文）：direct_draft / cross_review / visibility_policy /
# suppression_ledger 已有 167/167 服务层测试，但 app/api、cli.py、project.py、
# review.py、report_gate.py 零引用 → 不能算产品能力。
#
# 本段把四块数据以「同一批服务函数」暴露给 HTTP 与 CLI（禁止入口各写一套）：
#   direct-draft list/show    直连草稿（不可变原始输出 + 条目 + quote 回查）
#   compare list/show         四桶差异（提示性比对，不是裁决）
#   visibility show           可见性策略应用状态（visible/duplicate/suppressed...）
#   ledger list/show/recover  抑制台账（抑制≠删除；恢复只改状态 + 写回主链 finding）
#   omission add/list         人工漏报（位置/问题/证据/actor；提交前不返回隐藏项）
#   human-review show         工作台 + 四项报告门禁汇总（同 T-43 服务函数）
#
# V3.2 §15 四项报告门禁（全部为 0 才允许出正式报告）：
#   visible_unreviewed = 0
#   unresolved_critical_conflict = 0
#   incomplete_applicable_requirement = 0
#   suppressed_risk_decision_missing = 0
#
# 权限口径（与 T-43 一致，HTTP/CLI/report_gate 同源）：
# - 审核员：本人项目；直连草稿/比对/可见性/漏报可读，抑制台账只读「脱敏」
#   （不含 raw_claim/证据正文，防锚定；原因码/风险/状态可见），恢复=人工写动作；
# - 业务管理员：本租户只读（台账完整、可核对）；不能恢复/裁决；
# - 系统管理员/平台运营：禁止审核业务数据（由入口角色门禁拦截）；
# - 跨租户：404（不泄露存在性）；他人项目：403。
# ===========================================================================
PRODUCT_LIMIT_DEFAULT = 200
PRODUCT_LIMIT_MAX = 500

GATE_FLAG_NAMES = ("visible_unreviewed", "unresolved_critical_conflict",
                   "incomplete_applicable_requirement",
                   "suppressed_risk_decision_missing")
GATE_FLAG_LABELS = {
    "visible_unreviewed": "展示项未复核",
    "unresolved_critical_conflict": "关键冲突未裁决",
    "incomplete_applicable_requirement": "适用要求未完成执行",
    "suppressed_risk_decision_missing": "抑制项缺少风险裁决",
}
_COMPARISON_PUBLIC_FIELDS = (
    "id", "item_key", "case_id", "run_id", "bucket", "match_key_code",
    "match_key_clause", "match_key_subject", "match_key_issue_type",
    "direct_draft_id", "direct_item_id", "platform_finding_id",
    "auto_similarity", "auto_note", "human_status", "human_actor",
    "human_reason", "human_label", "visibility", "visibility_reason",
    "created_at", "updated_at")


def _slice(items: list, limit, offset) -> list:
    try:
        n = int(limit if limit not in (None, "") else PRODUCT_LIMIT_DEFAULT)
    except Exception:
        n = PRODUCT_LIMIT_DEFAULT
    n = max(0, min(n, PRODUCT_LIMIT_MAX))
    try:
        off = max(0, int(offset or 0))
    except Exception:
        off = 0
    return list(items)[off:off + n] if n else []


def _tenant_ctx(actor: str = "", role: str = "", tenant_id: str = "") -> str:
    """当前作用域租户：显式参数 > ctx（HTTP/CLI 每请求设置）> 账号所属租户。"""
    tid = str(tenant_id or "").strip()
    if tid:
        return tid
    try:
        from . import ctx as _ctx
        tid = str((_ctx.get_context() or {}).get("tenant_id") or "").strip()
    except Exception:
        tid = ""
    if tid:
        return tid
    if str(actor or "").strip():
        from .. import repositories as _R
        try:
            row = _R.users.get(str(actor)) or {}
        except Exception:
            row = {}
        tid = str(row.get("tenant_id") or "").strip()
    return tid


def _visible_cases(actor: str = "", role: str = "", tenant_id: str = "") -> list:
    """当前角色可见 case 列表（列表接口的数据范围事实源）。

    - 审核员：本人项目（跨空间汇总，与项目列表一致，空间只影响规则引擎）；
    - 业务管理员：本租户全部项目；
    - 系统管理员/平台运营/无身份：空（入口角色门禁已拒绝，这里再兜底）。
    """
    from .. import repositories as R
    role = str(role or "")
    if role not in ("reviewer", "admin") or not str(actor or "").strip():
        return []
    tid = _tenant_ctx(actor, role, tenant_id)
    if not tid:
        return []
    from . import ctx as _ctx
    # L98 P1：完整状态快照/恢复（旧写法只回 tenant/workspace，审核模式/system 丢失）
    saved = _ctx.snapshot()
    try:
        # 项目列表不跟工作空间走（AGENTS.md）：显式清空 workspace 再查，避免被
        # 当前请求空间过滤掉跨空间项目。
        _ctx.set_context(tid, "")
        cases = R.cases.list(order="created_at DESC")
    finally:
        try:
            _ctx.restore(saved)
        except Exception:
            LOGGER.debug("ctx restore skipped", exc_info=True)
    out = []
    for case in cases:
        ct = str(case.get("tenant_id") or "")
        if ct and ct != tid:
            continue
        if role == "reviewer" and str(case.get("created_by") or "") != str(actor):
            continue
        out.append(case)
    return out


def _case_access(case_id: str, actor: str = "", role: str = "",
                 action: str = "view") -> tuple:
    """case 读/写入口：返回 (case, None) 或 (None, err)（HTTP/CLI/report_gate 同源）。"""
    cid = str(case_id or "").strip()
    if not cid:
        return None, _err(400, "invalid_request", "需要 case_id")
    case = _case(cid)
    if not case:
        return None, _err(404, "not_found", "项目不存在")
    access = _authorize(cid, action, actor, role)
    if not access.get("ok"):
        return None, _deny(access)
    if str(actor or "").strip() or str(role or "").strip():
        tid = _tenant_ctx(actor, role)
        ct = str(case.get("tenant_id") or "")
        if tid and ct and tid != ct:
            # 跨租户不泄露存在性
            return None, _err(404, "not_found", "项目不存在")
    return case, None


def _case_brief(case: dict) -> dict:
    return {k: case.get(k) for k in
            ("id", "name", "status", "created_by", "tenant_id", "workspace_id",
             "last_run_id", "audit_type", "document_type")}


def _draft_summary(draft: dict, case: dict, items: list) -> dict:
    qc = draft.get("quote_check") or {}
    return {
        "id": draft.get("id"), "run_id": draft.get("run_id"),
        "case_id": draft.get("case_id"), "case_name": case.get("name") or "",
        "tenant_id": draft.get("tenant_id") or case.get("tenant_id") or "",
        "workspace_id": draft.get("workspace_id") or case.get("workspace_id") or "",
        "draft_index": int(draft.get("draft_index") or 0),
        "model": draft.get("model") or "",
        "model_source": draft.get("model_source") or "",
        "parse_status": draft.get("parse_status") or "",
        "items_count": len(items),
        "quote_check": qc,
        "error": draft.get("error") or "",
        "created_at": draft.get("created_at") or "",
        "raw_sha256": draft.get("raw_sha256") or "",
        "prompt_sha256": draft.get("prompt_sha256") or "",
        "ruleset_sha256": draft.get("ruleset_sha256") or "",
        "doc_sha256": draft.get("doc_sha256") or "",
        "latency_ms": int(draft.get("latency_ms") or 0),
        "tokens_in": int(draft.get("tokens_in") or 0),
        "tokens_out": int(draft.get("tokens_out") or 0),
        "immutable": bool(draft.get("immutable")),
    }


def direct_draft_list(*, actor: str = "", role: str = "", case_id: str = "",
                      tenant_id: str = "", run_id: str = "",
                      limit=PRODUCT_LIMIT_DEFAULT, offset=0) -> dict:
    """直连草稿列表（不可变原始输出落库可查；评审不能只看内存）。"""
    cid = str(case_id or "").strip()
    if cid:
        case, err = _case_access(cid, actor, role)
        if err:
            return err
        cases = [case]
    else:
        cases = _visible_cases(actor, role, tenant_id)
        if not cases:
            return _err(403, "forbidden", "无可见项目（或缺少租户作用域），不能列出直连草稿")
    rows, with_items = [], {}
    with _conn() as conn:
        for case in cases:
            for draft in GW.direct_draft_list(conn, case_id=str(case["id"])):
                if run_id and str(draft.get("run_id") or "") != str(run_id):
                    continue
                items = GW.direct_draft_items(conn, draft["id"])
                rows.append(_draft_summary(draft, case, items))
                with_items[str(draft.get("id"))] = len(items)
    rows.sort(key=lambda x: str(x.get("created_at") or ""), reverse=True)
    total = len(rows)
    scope = {"role": role, "tenant_id": _tenant_ctx(actor, role, tenant_id),
             "cases": len(cases), "case_id": cid}
    return _ok(items=_slice(rows, limit, offset), total=total, case_id=cid,
               scope=scope, limits={"limit": PRODUCT_LIMIT_MAX, "offset": int(offset or 0)},
               not_gold=True)


def direct_draft_show(*, draft_id: str = "", run_id: str = "",
                      actor: str = "", role: str = "") -> dict:
    """直连草稿详情（含原始响应/条目/quote 回查；不可变凭证）。"""
    did, rid = str(draft_id or "").strip(), str(run_id or "").strip()
    if not did and not rid:
        return _err(400, "invalid_request", "需要 draft_id 或 run_id")
    with _conn() as conn:
        try:
            draft = GW.direct_draft_get(conn, draft_id=did, run_id=rid)
        except ValueError as e:
            return _err(400, "invalid_request", str(e))
        if not draft:
            return _err(404, "not_found", "直连草稿不存在")
        case, err = _case_access(str(draft.get("case_id") or ""), actor, role)
        if err:
            return err
        items = GW.direct_draft_items(conn, draft["id"])
        stats = GW.direct_draft_stats(conn, case_id=str(case["id"]))
    summary = _draft_summary(draft, case, items)
    summary["raw_response"] = draft.get("raw_response") or ""
    summary["sampling"] = draft.get("sampling") or {}
    summary["parsed_items_count"] = len(draft.get("parsed_items") or [])
    return _ok(draft=summary, items=items, case=_case_brief(case),
               quote_check=draft.get("quote_check") or {}, stats=stats,
               not_gold=True)


def _comparison_public(item: dict, case: dict, role: str = "") -> dict:
    out = {k: item.get(k) for k in _COMPARISON_PUBLIC_FIELDS}
    out["case_name"] = case.get("name") or ""
    out["bucket_label"] = CR.BUCKET_LABELS.get(str(item.get("bucket") or ""),
                                               str(item.get("bucket") or ""))
    out["human_status_label"] = CR.HUMAN_STATUS_LABELS.get(
        str(item.get("human_status") or "unreviewed"),
        str(item.get("human_status") or "unreviewed"))
    decisions = item.get("visibility_detail") or {}
    reasons = []
    for side in ("direct", "platform"):
        dec = (decisions or {}).get(side) or {}
        if isinstance(dec, dict) and dec.get("reason_code"):
            code = str(dec["reason_code"])
            if code not in reasons:
                reasons.append(code)
    out["reason_codes"] = reasons
    severity, risk = severity_of_item(item)
    out["severity"] = severity
    out["severity_label"] = SEVERITY_LABELS.get(severity, severity)
    out["risk_level"] = risk if not decisions else (
        min([str((decisions.get(s) or {}).get("risk_level") or "")
             for s in ("direct", "platform")], key=lambda r: RISK_ORDER.get(r, 9))
        or risk)
    out["auto_similarity_only_hint"] = True
    out["not_gold"] = True
    return out


def comparison_list(*, actor: str = "", role: str = "", case_id: str = "",
                    bucket: str = "", visibility: str = "", human_status: str = "",
                    tenant_id: str = "", limit=PRODUCT_LIMIT_DEFAULT,
                    offset=0) -> dict:
    """四桶差异列表（提示性比对，不是裁决；审核员只返回可见项）。"""
    cid = str(case_id or "").strip()
    if cid:
        case, err = _case_access(cid, actor, role)
        if err:
            return err
        cases = [case]
    else:
        cases = _visible_cases(actor, role, tenant_id)
        if not cases:
            return _err(403, "forbidden", "无可见项目（或缺少租户作用域），不能列出比对项")
    rows, by_bucket, by_visibility, by_status = [], {}, {}, {}
    with _conn() as conn:
        for case in cases:
            for item in CR.list_comparison_items(
                    conn, case_id=str(case["id"]), bucket=bucket,
                    human_status=human_status, visibility=visibility):
                vis = str(item.get("visibility") or "")
                if role == "reviewer" and vis != "visible":
                    # 防锚定：审核员只看到展示项；隐藏/未应用项不出现在列表
                    continue
                row = _comparison_public(item, case, role)
                rows.append(row)
                key = str(item.get("bucket") or "")
                by_bucket[key] = by_bucket.get(key, 0) + 1
                vkey = vis or "unset"
                by_visibility[vkey] = by_visibility.get(vkey, 0) + 1
                st = str(item.get("human_status") or "unreviewed")
                by_status[st] = by_status.get(st, 0) + 1
    rows.sort(key=lambda x: str(x.get("created_at") or ""), reverse=True)
    return _ok(items=_slice(rows, limit, offset), total=len(rows), case_id=cid,
               buckets=CR.BUCKET_LABELS, counts={"by_bucket": by_bucket,
                                                 "by_visibility": by_visibility,
                                                 "by_human_status": by_status,
                                                 "total": len(rows)},
               filtered_by_role=(role == "reviewer"),
               scope={"role": role, "cases": len(cases),
                      "tenant_id": _tenant_ctx(actor, role, tenant_id)},
               not_gold=True)


def comparison_show(*, item_id: str, actor: str = "", role: str = "",
                    doc_text: str = "") -> dict:
    """四桶差异详情（直连条目 + 平台 finding 并排视图）。"""
    iid = str(item_id or "").strip()
    if not iid:
        return _err(400, "invalid_request", "需要 item_id")
    with _conn() as conn:
        item = CR.get_comparison_item(conn, iid)
        if not item:
            return _err(404, "not_found", "比对项不存在")
        case, err = _case_access(str(item.get("case_id") or ""), actor, role)
        if err:
            return err
        if role == "reviewer" and str(item.get("visibility") or "") != "visible":
            return _err(403, "item_not_visible",
                        "隐藏/未展示项对审核员不可见（防锚定；恢复请走抑制台账/漏报对账）")
        view = CR.item_view(conn, iid, doc_text) or {}
    return _ok(item=_comparison_public(item, case, role),
               comparison=view.get("comparison") or {},
               direct=view.get("direct"), platform=view.get("platform"),
               visibility_detail=item.get("visibility_detail") or {},
               case=_case_brief(case), not_gold=True)


def visibility_show(*, case_id: str, actor: str = "", role: str = "",
                    tenant_id: str = "") -> dict:
    """可见性策略应用状态（Phase 1：隐藏=视图过滤，不是删除/状态丢失）。"""
    cid = str(case_id or "").strip()
    case, err = _case_access(cid, actor, role)
    if err:
        return err
    policy = GW.policy_snapshot()
    with _conn() as conn:
        items = CR.list_comparison_items(conn, case_id=cid)
        buckets = CR.bucket_counts(conn, cid)
        presence = _presence(conn, cid)
        ledger_rows = (GW.ledger_list(conn, case_id=cid)
                       if _table_exists(conn, LEDGER_TABLE) else [])
        progress = review_progress(conn, cid) if items else {
            "visible_total": 0, "visible_reviewed": 0, "visible_pending": 0,
            "by_severity": {}}
    by_vis, unset, item_rows = {}, 0, []
    for item in items:
        vis = str(item.get("visibility") or "")
        if not vis:
            unset += 1
        by_vis[vis or "unset"] = by_vis.get(vis or "unset", 0) + 1
        if role == "reviewer" and vis != "visible":
            continue
        severity, risk = severity_of_item(item)
        item_rows.append({
            "item_id": item.get("id"), "bucket": item.get("bucket"),
            "bucket_label": CR.BUCKET_LABELS.get(str(item.get("bucket") or ""), ""),
            "rule_code": item.get("match_key_code") or "",
            "visibility": vis, "visibility_reason": item.get("visibility_reason") or "",
            "severity": severity, "risk_level": risk,
            "human_status": item.get("human_status") or "unreviewed",
        })
    hidden_public = {"hidden_visible_to_role": False} if role == "reviewer" else {
        "hidden_visible_to_role": True, "ledger_total": len(ledger_rows),
        "suppressed": len([r for r in ledger_rows
                           if r.get("visibility_status") == "suppressed"]),
        "recovered": len([r for r in ledger_rows
                          if r.get("visibility_status") == "recovered"]),
    }
    return _ok(case_id=cid, case=_case_brief(case),
               enabled=bool(items or presence.get("enabled")),
               policy=policy, policy_version=GW.policy_version(),
               counts={"total": len(items) if role != "reviewer" else len(item_rows),
                       "by_visibility": by_vis if role != "reviewer" else {
                           k: v for k, v in by_vis.items() if k in ("visible", "unset")},
                       "visibility_unset": unset,
                       "visible": by_vis.get("visible", 0) if role != "reviewer"
                       else len(item_rows)},
               buckets=buckets,
               review={"visible_total": progress["visible_total"],
                       "visible_reviewed": progress["visible_reviewed"],
                       "visible_pending": progress["visible_pending"],
                       "by_severity": progress.get("by_severity") or {}},
               ledger=hidden_public,
               gates=product_gate(cid).get("gates") or {},
               items=item_rows, not_gold=True)


def _ledger_redacted(row: dict) -> dict:
    """审核员可见的脱敏台账（不含 raw_claim/证据正文；防锚定）。"""
    out = {k: row.get(k) for k in
           ("id", "case_id", "source", "rule_code", "subject", "issue_type",
            "risk_level", "suppression_reason", "visibility_status", "sampled",
            "human_result", "human_actor", "recovered_finding_ref", "created_at",
            "recovered_at", "confidence")}
    out["raw_claim_sha256"] = row.get("raw_claim_sha256") or ""
    out["is_suppressed"] = str(row.get("visibility_status") or "") == "suppressed"
    out["is_recovered"] = str(row.get("visibility_status") or "") == "recovered"
    out["content_redacted"] = True
    out["hidden_visible_to_role"] = False
    return out


def _ledger_public_full(row: dict) -> dict:
    out = dict(row)
    out.pop("raw_claim_json", None)
    out.pop("evidence_json", None)
    out.pop("refute_evidence_json", None)
    out["raw_claim"] = row.get("raw_claim") or {}
    out["evidence"] = row.get("evidence") or {}
    out["refute_evidence"] = row.get("refute_evidence") or {}
    out["hidden_visible_to_role"] = True
    return out


def _ledger_counts(rows: list) -> dict:
    by_status, by_source, by_reason, by_risk = {}, {}, {}, {}
    for row in rows:
        st = str(row.get("visibility_status") or "")
        by_status[st] = by_status.get(st, 0) + 1
        src = str(row.get("source") or "")
        by_source[src] = by_source.get(src, 0) + 1
        rc = str(row.get("suppression_reason") or "")
        by_reason[rc] = by_reason.get(rc, 0) + 1
        rk = str(row.get("risk_level") or "")
        by_risk[rk] = by_risk.get(rk, 0) + 1
    return {"total": len(rows), "by_status": by_status, "by_source": by_source,
            "by_reason": by_reason, "by_risk": by_risk,
            "suppressed": by_status.get("suppressed", 0),
            "recovered": by_status.get("recovered", 0),
            "risk_decision_missing": len([
                r for r in rows
                if str(r.get("visibility_status") or "") == "suppressed"
                and str(r.get("risk_level") or "") in ("critical", "high")
                and not str(r.get("human_result") or "").strip()])}


def ledger_list(*, actor: str = "", role: str = "", case_id: str = "",
                status: str = "", source: str = "", tenant_id: str = "",
                limit=PRODUCT_LIMIT_DEFAULT, offset=0) -> dict:
    """抑制台账列表（抑制≠删除；业务管理员完整只读，审核员脱敏只读）。"""
    cid = str(case_id or "").strip()
    if cid:
        case, err = _case_access(cid, actor, role)
        if err:
            return err
        cases = [case]
    else:
        cases = _visible_cases(actor, role, tenant_id)
        if not cases:
            return _err(403, "forbidden", "无可见项目（或缺少租户作用域），不能列出抑制台账")
    rows, counts, stats_rows = [], {}, []
    with _conn() as conn:
        for case in cases:
            ledger = GW.ledger_list(conn, case_id=str(case["id"]),
                                    source=source, status=status)
            stats_rows.extend(ledger)
            for row in ledger:
                out = (_ledger_public_full(row) if role == "admin"
                       else _ledger_redacted(row))
                out["case_name"] = case.get("name") or ""
                rows.append(out)
    rows.sort(key=lambda x: str(x.get("created_at") or ""), reverse=True)
    counts = _ledger_counts(stats_rows)
    if role != "admin":
        counts = {k: counts[k] for k in
                  ("total", "by_status", "by_source", "by_reason", "by_risk")}
    hidden_summary = ""
    if role == "admin":
        try:
            with _conn() as conn:
                hidden_summary = GW.ledger_hidden_summary(conn, cid) if cid else ""
        except Exception:
            hidden_summary = ""
    return _ok(items=_slice(rows, limit, offset), total=len(rows), case_id=cid,
               counts=counts, hidden_summary=hidden_summary,
               hidden_visible_to_role=(role == "admin"),
               scope={"role": role, "cases": len(cases),
                      "tenant_id": _tenant_ctx(actor, role, tenant_id)},
               not_gold=True)


def ledger_show(*, ledger_id: str, actor: str = "", role: str = "") -> dict:
    """抑制台账详情（业务管理员完整；审核员脱敏）。"""
    lid = str(ledger_id or "").strip()
    if not lid:
        return _err(400, "invalid_request", "需要 ledger_id")
    with _conn() as conn:
        row = GW.ledger_get(conn, lid)
        if not row:
            return _err(404, "not_found", "抑制台账不存在")
        case, err = _case_access(str(row.get("case_id") or ""), actor, role)
        if err:
            return err
        counts = _ledger_counts(GW.ledger_list(conn, case_id=str(case["id"])))
    out = _ledger_public_full(row) if role == "admin" else _ledger_redacted(row)
    return _ok(ledger=out, case=_case_brief(case), counts=counts,
               hidden_visible_to_role=(role == "admin"), not_gold=True)


def ledger_recover(*, ledger_id: str, actor: str = "", role: str = "",
                   reason: str = "") -> dict:
    """人工从抑制池恢复（写动作：仅项目审核员；业务管理员只读拒绝；写审计+写回 finding）。

    抑制≠删除：原台账行保留，只改 visibility_status=recovered，并恢复为主链 finding。
    """
    lid = str(ledger_id or "").strip()
    if not lid:
        return _err(400, "invalid_request", "需要 ledger_id")
    if not str(reason or "").strip():
        return _err(400, "reason_required", "恢复必须填写原因（人工动作需审计）")
    human_actor = str(actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "恢复必须记录 actor")
    with _conn() as conn:
        row = GW.ledger_get(conn, lid)
        if not row:
            return _err(404, "not_found", "抑制台账不存在")
        case, err = _case_access(str(row.get("case_id") or ""), human_actor, role,
                                 action="review")
        if err:
            return err
        # T-51：恢复前先确保隐藏项已入进化池 + 恢复后写弱人工标签（来源 ledger_recover）
        try:
            _enqueue_evolution(conn, case, [row], actor=human_actor,
                               via="ledger_recover")
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution enqueue on ledger recover skipped",
                           exc_info=True)
        rec = GW.ledger_recover(conn, lid, actor=human_actor, reason=reason)
        ledger = rec.get("ledger") or row
        finding_id = ""
        if rec.get("recovered"):
            finding_id = _write_recovered_finding(
                conn, case, ledger, {"issue": reason}, human_actor)
            ledger = GW.ledger_get(conn, lid) or ledger
        try:
            _record_evolution_label(conn, case, ledger, action="confirm",
                                    actor=human_actor, reason=reason,
                                    source="ledger_recover")
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution label on ledger recover skipped", exc_info=True)
        _audit(conn, actor=human_actor, action="suppression_ledger.recovered",
               obj=lid, case=case, before="suppressed",
               after=json.dumps({"recovered": bool(rec.get("recovered")),
                                 "already_recovered": bool(rec.get("already_recovered")),
                                 "finding_id": finding_id,
                                 "reason": reason}, ensure_ascii=False))
        cid = str(case.get("id") or "")
    out = _ledger_public_full(ledger) if role == "admin" else _ledger_redacted(ledger)
    return _ok(ledger_id=lid, case_id=cid,
               recovered=bool(rec.get("recovered")),
               already_recovered=bool(rec.get("already_recovered")),
               finding_id=finding_id, ledger=out,
               gate=_redact_hidden_gate(gate_check(cid)), not_gold=True)


def omission_list(*, actor: str = "", role: str = "", case_id: str = "",
                  status: str = "", tenant_id: str = "",
                  limit=PRODUCT_LIMIT_DEFAULT, offset=0) -> dict:
    """人工漏报列表（位置/问题/证据/actor；对账状态与反馈候选）。"""
    cid = str(case_id or "").strip()
    if cid:
        case, err = _case_access(cid, actor, role)
        if err:
            return err
        cases = [case]
    else:
        cases = _visible_cases(actor, role, tenant_id)
        if not cases:
            return _err(403, "forbidden", "无可见项目（或缺少租户作用域），不能列出人工漏报")
    rows, counts = [], {"total": 0, "pending": 0, "by_status": {}}
    with _conn() as conn:
        for case in cases:
            omissions = GW.omission_list(conn, case_id=str(case["id"]),
                                          status=status)
            for row in omissions:
                pub = _public_omission(row)
                pub["case_name"] = case.get("name") or ""
                rows.append(pub)
            st = omission_stats(conn, case["id"])
            counts["total"] += st.get("total", 0)
            counts["pending"] += st.get("pending", 0)
            for key, n in (st.get("by_status") or {}).items():
                counts["by_status"][key] = counts["by_status"].get(key, 0) + int(n)
    rows.sort(key=lambda x: str(x.get("created_at") or ""), reverse=True)
    return _ok(items=_slice(rows, limit, offset), total=len(rows), case_id=cid,
               counts=counts, hidden_visible_to_role=False,
               scope={"role": role, "cases": len(cases),
                      "tenant_id": _tenant_ctx(actor, role, tenant_id)},
               not_gold=True)


def omission_show(*, omission_id: str, actor: str = "", role: str = "") -> dict:
    """人工漏报单条详情（位置/问题/证据/对账结果；对审核员不返回隐藏项内容）。"""
    oid = str(omission_id or "").strip()
    if not oid:
        return _err(400, "invalid_request", "需要 omission_id")
    with _conn() as conn:
        row = GW.omission_get(conn, oid)
        if not row:
            return _err(404, "not_found", "人工漏报不存在")
        case, err = _case_access(str(row.get("case_id") or ""), actor, role)
        if err:
            return err
        counts = omission_stats(conn, str(case.get("id") or ""))
    return _ok(omission=_public_omission(row), case=_case_brief(case),
               counts=counts, hidden_visible_to_role=False, not_gold=True)


# --------------------------------------------------------------------------- 四项报告门禁
def _manifest_incomplete_applicable(case_id: str) -> dict:
    """适用要求未完成：最新 run 的冻结清单中「无执行结果」或「非 pass/fail/na」的条数。

    数据源 = audit_run(manifest_id) + audit_manifest.items_json + manifest_result.d5_json。
    无 manifest（legacy/未跑清单）→ 0，由既有 report_gate 口径负责（不重复阻断）。
    """
    out = {"count": 0, "missing": 0, "incomplete": 0, "items": 0, "results": 0,
           "run_id": "", "manifest_id": "", "detail": [], "note": ""}
    try:
        with db.session() as c:
            ar = c.execute(
                "SELECT id,manifest_id FROM audit_run WHERE case_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                (case_id,)).fetchone()
            if not ar:
                out["note"] = "无审核 run"
                return out
            out["run_id"] = str(ar["id"] or "")
            mid = str(ar["manifest_id"] or "")
            out["manifest_id"] = mid
            if not mid:
                out["note"] = "该 run 无冻结清单（legacy 路径）"
                return out
            m = c.execute("SELECT items_json FROM audit_manifest WHERE id=?",
                          (mid,)).fetchone()
            if not m:
                out["note"] = "冻结清单缺失"
                return out
            try:
                items = json.loads(m["items_json"] or "[]")
            except Exception:
                items = []
            out["items"] = len(items)
            rows = c.execute(
                "SELECT id,item_key,d5_json FROM manifest_result WHERE manifest_id=?",
                (mid,)).fetchall()
            out["results"] = len(rows)
            bad = []
            for r in rows:
                try:
                    d5 = json.loads(r["d5_json"] or "{}")
                except Exception:
                    d5 = {}
                status = str((d5 or {}).get("status") or "")
                if status not in ("pass", "fail", "na"):
                    bad.append({"result_id": str(r["id"] or ""),
                                "item_key": str(r["item_key"] or ""),
                                "status": status or "unknown"})
            # 2026-11-17 最终包（T-56 / task-52）修复：已按对象级例外显式接受的
            # unknown/证据不足结果不得再计入 incomplete——accept-unknown 是产品既有
            # 放行闭环（result_id+hash+run_id+双人/过期/不可豁免由 report_gate 校验）；
            # T-50 计数若忽略授权，会导致“显式接受后仍阻断出报告”。未接受/不可豁免
            # 的结果仍照常计入（本修复不放宽门禁，仅避免与例外授权闭环自相矛盾）。
            try:
                from . import report_gate as _rg
                _u = _rg.collect_unknown(case_id)
                _unacc = {str((x.get("binding") or {}).get("result_id") or "")
                          for x in (_u.get("manifest_unaccepted") or [])}
                _accepted_rids = {
                    str((x.get("binding") or {}).get("result_id") or "")
                    for x in (_u.get("manifest") or [])
                } - _unacc
                if _u.get("accepted_keys") and _accepted_rids:
                    bad = [b for b in bad
                           if str(b.get("result_id") or "") not in _accepted_rids]
            except Exception:  # noqa: BLE001
                LOGGER.warning("incomplete accepted-unknown filter skipped case=%s",
                               case_id, exc_info=True)
            out["incomplete"] = len(bad)
            out["missing"] = max(0, out["items"] - out["results"])
            out["count"] = out["missing"] + out["incomplete"]
            out["detail"] = bad[:50]
    except Exception:  # noqa: BLE001
        LOGGER.warning("manifest incomplete check skipped case=%s", case_id,
                       exc_info=True)
        out["note"] = "检查异常（按 0 处理，既有门禁仍生效）"
    return out


def _unresolved_critical_conflicts(conn, case_id: str) -> list:
    """未裁决的关键冲突：bucket=conflict + human_status=unreviewed + risk critical/high。"""
    out = []
    for item in CR.list_comparison_items(conn, case_id=case_id, bucket="conflict"):
        status = str(item.get("human_status") or "unreviewed")
        if status != "unreviewed":
            continue
        severity, risk = severity_of_item(item)
        if risk in ("critical", "high") or severity == "critical":
            out.append({"item_id": item.get("id"),
                        "rule_code": item.get("match_key_code") or "",
                        "risk_level": risk, "severity": severity,
                        "visibility": item.get("visibility") or ""})
    return out


def _suppressed_risk_missing(conn, case_id: str) -> list:
    """抑制台账中 critical/高风险的隐藏项缺少人工风险裁决（human_result 为空）。"""
    out = []
    if not _table_exists(conn, LEDGER_TABLE):
        return out
    for row in GW.ledger_list(conn, case_id=case_id, status="suppressed"):
        if str(row.get("risk_level") or "") not in ("critical", "high"):
            continue
        if str(row.get("human_result") or "").strip():
            continue
        out.append({"ledger_id": row.get("id"), "source": row.get("source") or "",
                    "rule_code": row.get("rule_code") or "",
                    "risk_level": row.get("risk_level") or "",
                    "suppression_reason": row.get("suppression_reason") or ""})
    return out


def product_gate(case_id: str) -> dict:
    """V3.2 §15 四项报告门禁（0=通过）。report_gate / CLI / HTTP 唯一事实源。

    返回 ``{"gates": {...}, "reasons": [...], "enabled": bool, "detail": {...}}``；
    不抛权限错误（调用方先做 case 访问校验），异常时按 0 处理并标记 skipped。
    """
    cid = str(case_id or "").strip()
    out = {"gates": {name: 0 for name in GATE_FLAG_NAMES},
           "reasons": [], "enabled": False, "detail": {},
           "manifest": {"count": 0, "note": "未检查"}, "not_gold": True}
    if not cid:
        return out
    try:
        with _conn() as conn:
            presence = _presence(conn, cid)
            items = CR.list_comparison_items(conn, case_id=cid)
            out["enabled"] = bool(presence.get("enabled") or items)
            visible_unreviewed = len([
                x for x in items
                if str(x.get("visibility") or "") == "visible"
                and str(x.get("human_status") or "unreviewed") == "unreviewed"])
            conflicts = _unresolved_critical_conflicts(conn, cid)
            suppressed = _suppressed_risk_missing(conn, cid)
        manifest = _manifest_incomplete_applicable(cid)
        gates = out["gates"]
        gates["visible_unreviewed"] = visible_unreviewed
        gates["unresolved_critical_conflict"] = len(conflicts)
        gates["incomplete_applicable_requirement"] = int(manifest.get("count") or 0)
        gates["suppressed_risk_decision_missing"] = len(suppressed)
        out["detail"] = {"visible_unreviewed": [
            {"item_id": x.get("id")} for x in items
            if str(x.get("visibility") or "") == "visible"
            and str(x.get("human_status") or "unreviewed") == "unreviewed"][:50],
            "unresolved_critical_conflict": conflicts[:50],
            "suppressed_risk_decision_missing": suppressed[:50]}
        out["manifest"] = manifest
        reasons = out["reasons"]
        if gates["unresolved_critical_conflict"]:
            reasons.append(
                f"仍有 {gates['unresolved_critical_conflict']} 条未裁决关键冲突"
                f"（unresolved_critical_conflict={gates['unresolved_critical_conflict']}）："
                "冲突项必须逐条裁决，不能只标展示")
        if gates["incomplete_applicable_requirement"]:
            reasons.append(
                f"仍有 {gates['incomplete_applicable_requirement']} 条适用要求未完成执行"
                f"（incomplete_applicable_requirement="
                f"{gates['incomplete_applicable_requirement']}）：执行失败/证据不足/"
                "结果缺失不得出正式报告")
        if gates["suppressed_risk_decision_missing"]:
            reasons.append(
                f"仍有 {gates['suppressed_risk_decision_missing']} 条抑制项缺少人工风险裁决"
                f"（suppressed_risk_decision_missing="
                f"{gates['suppressed_risk_decision_missing']}）："
                "“另有 N 条抑制项”不能替代风险裁决")
    except Exception:  # noqa: BLE001
        LOGGER.warning("product gate skipped case=%s", cid, exc_info=True)
        out["skipped_error"] = True
        out["reasons"] = []
        out["gates"] = {name: 0 for name in GATE_FLAG_NAMES}
    return out


# ===========================================================================
# T-51（V3.3 增补 20261117）人工“显示隐藏疑似问题 (N)”开关：可逆视图 + 裁决闭环
# + 进化池最小持久钩子（完整进化引擎属 T-52，本段只做钩子，报告如实标注）
#
# 设计口径（docs/delivery/V3.3人工隐藏开关_增补_20261117.md）：
# 1. 隐藏 = 默认视图过滤，不是删除/不可逆状态；数据源 = suppression_ledger
#    （抑制≠删除，原始行永不物理删除）。开关每次进入复核默认关闭，不记忆。
# 2. production 模式显示“另有 N 条隐藏/疑似项”；evaluation（盲审）模式在提交
#    独立复核前：不显示 N、不返回内容、API 403（防人工 gold 污染）。
# 3. 打开 = 二次确认（浏览器 confirm；API/CLI 显式 include/reveal）+ 审计
#    audit_log action=human_review.hidden_reveal（actor/time/case/mode/hidden_count/
#    item_ids），并把逐条“已展示未动作”写入 adjudication_event（evolution_revealed）。
# 4. 隐藏区与可见项区物理分开：本模块只返回独立 hidden/items 结构，绝不混入
#    review.items（report_gate 只认 visible 队列）。
# 5. 权限/范围：复用 review.authorize_case + 租户/空间/project 行级过滤；
#    跨租户 404、他人项目 403、业务管理员只读（不可打开隐藏池、不可裁决）、
#    系统管理员/平台运营禁止访问审核业务。隐藏项内容白名单输出，绝不含
#    gold_hit / gold_issue_id / auto_label（含嵌套清洗）。
# 6. 裁决闭环：confirm/recover → visible + recovered + suppression_error（强标签）；
#    reject → 保留隐藏（弱人工标签）；request-evidence → 保持待补证；
#    merge → 与可见项重复（弱人工标签 + comparison_item.visibility=duplicate）；
#    rule-error → 规则/路由反馈（写 feedback 反向样本）。
# 7. 进化池（用户追加要求，最小实现）：所有隐藏项（不论是否被点开/动作）都进入
#    feedback（kind=hidden_item）+ adjudication_event evolution_enqueued；输出
#    evolution_status / feedback_enqueued；无动作 TTL 默认处置只能是
#    default_disposition=suspected_false_positive + label_strength=weak_default，
#    禁止当 gold、禁止直接调阈值、禁止自动训练（事件里显式写死三个 false/true 标记）。
# 指标：hidden_count / reveal_rate / hidden TP/FP/recovery / reveal_to_decide_seconds /
#       feedback_coverage，分 production/evaluation/source/reason。
# ===========================================================================
REVIEW_MODES = ("production", "evaluation")
REVIEW_MODE_DEFAULT = "production"
MODE_LABELS = {"production": "生产模式", "evaluation": "评测/盲审模式"}
# X-14 P0-3：evaluation 锁定后果与解锁方式必须显式下发（项目详情/切换提示同源）。
EVALUATION_LOCK_HINT = (
    "评测/盲审模式：提交独立复核前，隐藏疑似问题（N）不可见、审核员不能自行切回生产模式。"
    "解锁方式：① 审核员提交独立复核后可切回 production；"
    "② 业务管理员可强制回退（POST /api/v1/projects/{case_id}/review-mode "
    "携带 force=true + reason，写审计）。")
_REVIEW_MODE_UNLOCK = {
    "locked": True,
    "unlock_actions": [
        {"by": "reviewer", "action": "提交独立复核", "api": "POST /api/v1/projects/{case_id}/human-review/independent"},
        {"by": "admin", "action": "强制回退 production（写审计）",
         "api": "POST /api/v1/projects/{case_id}/review-mode",
         "body": {"mode": "production", "force": True, "confirm": True,
                  "reason": "必填：强制回退原因"}},
    ],
    "hint": EVALUATION_LOCK_HINT,
}
_CFG_MODE_PREFIX = "human_review.review_mode."
_CFG_INDEPENDENT_PREFIX = "human_review.independent_submitted."

HIDDEN_ACTION_SLUGS = ("confirm", "reject", "request-evidence", "recover", "merge",
                       "rule-error")
HIDDEN_ACTION_LABELS = {
    "confirm": "确认真问题并恢复", "recover": "恢复为可见问题",
    "reject": "判为误报（保留隐藏）", "request-evidence": "请求补证",
    "merge": "与可见项重复合并", "rule-error": "规则/路由错误反馈",
}
# 裁决动作 → (adjudication, 标签强度, evolution_status)
_HIDDEN_ACTION_LABEL = {
    "confirm": ("confirmed", "strong_human", "labeled_strong"),
    "recover": ("confirmed", "strong_human", "labeled_strong"),
    "reject": ("rejected", "weak_human", "labeled_weak"),
    "merge": ("duplicate", "weak_human", "labeled_weak"),
    "rule-error": ("rule_error", "weak_human", "labeled_weak"),
    "request-evidence": ("evidence_insufficient", "none_pending", "pending"),
}
_HIDDEN_EVENT_TO_ADJUDICATION = {
    "hidden_confirm": "confirmed", "hidden_recover": "confirmed",
    "hidden_reject": "rejected", "hidden_request_evidence": "evidence_insufficient",
    "hidden_duplicate": "duplicate", "hidden_rule_error": "rule_error",
}
_HIDDEN_ACTION_EVENT = {
    "confirm": "hidden_confirm", "recover": "hidden_recover",
    "reject": "hidden_reject", "request-evidence": "hidden_request_evidence",
    "merge": "hidden_duplicate", "rule-error": "hidden_rule_error",
}
HIDDEN_ADJUDICATIONS = ("unreviewed", "confirmed", "rejected",
                        "evidence_insufficient", "duplicate", "rule_error")
HIDDEN_ADJUDICATION_LABELS = {
    "unreviewed": "未裁决", "confirmed": "已确认真问题",
    "rejected": "人工判为误报", "evidence_insufficient": "待补证",
    "duplicate": "与可见项重复", "rule_error": "规则/路由错误",
}
HIDDEN_OPEN_ADJUDICATIONS = ("unreviewed", "evidence_insufficient")
HIDDEN_REASON_CATEGORIES = ("unverifiable_quote", "weak_locator", "low_confidence",
                            "display_policy_filtered", "evidence_insufficient")
HIDDEN_REASON_CATEGORY_LABELS = {
    "unverifiable_quote": "不可核验", "weak_locator": "弱定位",
    "low_confidence": "低置信", "display_policy_filtered": "策略过滤",
    "evidence_insufficient": "证据不足",
}
# 原始抑制原因码（suppression_ledger.suppression_reason）→ 设计 §2.4 五类口径
HIDDEN_REASON_DISPLAY = {
    "unverifiable_quote": ("unverifiable_quote", "引文不可逐字命中（不可核验）"),
    "unverifiable_computation": ("unverifiable_quote", "计算/复算证据不成立"),
    "unverifiable_relation": ("unverifiable_quote", "关系/锚点证据不成立"),
    "missing_locator": ("weak_locator", "缺少可定位锚点"),
    "low_evidence_noncritical": ("low_confidence", "低证据强度且非高风险"),
    "deterministic_refuted": ("display_policy_filtered", "被确定性反证（策略过滤）"),
    "evidence_insufficient": ("evidence_insufficient", "证据不足"),
}
EVOLUTION_KIND = "hidden_item"
EVOLUTION_REASON_CODES = ("evolution_enqueued", "evolution_revealed",
                          "evolution_label", "evolution_default_disposition")
EVOLUTION_DEFAULT_TTL_DAYS = 30
EVOLUTION_DEFAULT_DISPOSITION = "suspected_false_positive"
EVOLUTION_TARGET_FEEDBACK_COVERAGE = 100.0
_FORBIDDEN_HIDDEN_KEYS = frozenset({
    "gold", "gold_hit", "gold_hits", "gold_issue_id", "gold_issue", "gold_label",
    "gold_standard", "gold_ref", "gold_answer", "auto_label", "auto_suggested_label",
    "label_auto", "auto_gold"})


def _parse_time(value):
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return _dt.datetime.fromisoformat(text)
    except Exception:  # noqa: BLE001
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return _dt.datetime.strptime(text, fmt)
        except Exception:  # noqa: BLE001
            continue
    return None


def _epoch(value):
    parsed = _parse_time(value)
    if not parsed:
        return None
    try:
        if parsed.tzinfo is None:
            parsed = parsed.astimezone()
        return float(parsed.timestamp())
    except Exception:  # noqa: BLE001
        return None


def _age_days(value):
    stamp = _epoch(value)
    if stamp is None:
        return None
    return max(0.0, round((_dt.datetime.now().timestamp() - stamp) / 86400.0, 3))


def _cfg_get(conn, key: str, default: str = "") -> str:
    try:
        row = conn.execute("SELECT value FROM sys_config WHERE key=?",
                           (str(key or ""),)).fetchone()
    except Exception:  # noqa: BLE001
        return default
    if not row:
        return default
    return str(row[0]) if row[0] is not None else default


def _cfg_set(conn, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO sys_config(key,value,updated_at) VALUES(?,?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
        "updated_at=excluded.updated_at",
        (str(key or ""), str(value or ""), _now()))


def _review_mode(conn, case_id: str) -> str:
    raw = str(_cfg_get(conn, _CFG_MODE_PREFIX + str(case_id or ""),
                       REVIEW_MODE_DEFAULT) or "").strip().lower()
    return raw if raw in REVIEW_MODES else REVIEW_MODE_DEFAULT


def _independent_info(conn, case_id: str) -> dict:
    raw = _cfg_get(conn, _CFG_INDEPENDENT_PREFIX + str(case_id or ""), "")
    if not raw:
        return {}
    try:
        info = json.loads(raw)
    except Exception:  # noqa: BLE001
        return {}
    return info if isinstance(info, dict) else {}


def review_mode_get(case_id: str, *, actor: str = "", role: str = "") -> dict:
    """复核模式读取（project.review_mode：production | evaluation；sys_config 持久化）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "view", actor, role)
    if not access.get("ok"):
        return _deny(access)
    with _conn() as conn:
        mode = _review_mode(conn, cid)
        independent = _independent_info(conn, cid)
        try:
            reveal_events = int(conn.execute(
                "SELECT count(*) FROM audit_log WHERE action=? AND object=?",
                ("human_review.hidden_reveal", cid)).fetchone()[0] or 0)
        except Exception:  # noqa: BLE001
            reveal_events = 0
    role_eff = str(access.get("role") or role or "")
    evaluation_locked = bool(mode == "evaluation" and not independent)
    can_force = bool(evaluation_locked and role_eff == "admin")
    return _ok(
        case_id=cid, case=_case_brief(case), mode=mode,
        mode_label=MODE_LABELS.get(mode, mode), default_mode=REVIEW_MODE_DEFAULT,
        independent_submitted=bool(independent), independent=independent,
        evaluation_locked=evaluation_locked,
        unlock_conditions=(_REVIEW_MODE_UNLOCK if evaluation_locked else {}),
        lock_hint=(EVALUATION_LOCK_HINT if mode == "evaluation" else ""),
        can_force_rollback=can_force,
        reveal_events=reveal_events,
        can_set=bool(access.get("can_review") and role_eff == "reviewer"),
        permissions={"role": role_eff, "actor": str(access.get("actor") or actor or ""),
                     "read_only": bool(access.get("read_only")),
                     "can_review": bool(access.get("can_review"))},
        not_gold=True)


def review_mode_set(case_id: str, mode: str, *, actor: str = "", role: str = "",
                    reason: str = "", force: bool = False) -> dict:
    """设置复核模式（仅项目审核员；写审计；evaluation 一旦有 reveal 历史则拒绝）。

    X-14 P0-3：evaluation 锁定不是死锁。除「提交独立复核后审核员可自行切回」外，
    业务管理员可用 ``force=True`` **强制回退 production**（必须填原因 + 二次确认，
    写 ``human_review.review_mode_force_set`` 审计）。审核员 force 仍 403。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    force_flag = bool(force)
    declared_role = str(role or "").strip()
    # 强制回退 = 管理动作（业务管理员），按 view 校验项目可见性；普通设置仍按 review 校验。
    access_action = "view" if (force_flag and declared_role == "admin") else "review"
    access = _authorize(cid, access_action, actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "设置复核模式必须记录 actor（写审计）")
    role_eff = str(access.get("role") or declared_role or "")
    new_mode = str(mode or "").strip().lower()
    if new_mode not in REVIEW_MODES:
        return _err(400, "invalid_mode",
                    f"非法复核模式：{mode}（可选：{', '.join(REVIEW_MODES)}）",
                    allowed=list(REVIEW_MODES))
    if force_flag and new_mode != "production":
        return _err(400, "invalid_force_mode",
                    "强制回退只用于 evaluation→production；切 evaluation 请走普通入口",
                    mode=new_mode)
    why = str(reason or "").strip()[:500]
    if force_flag and len(why) < 2:
        return _err(400, "force_reason_required",
                    "强制回退必须填写原因（写入审计，用于事后对账）", mode=new_mode)
    with _conn() as conn:
        previous = _review_mode(conn, cid)
        independent = _independent_info(conn, cid)
        try:
            reveal_events = int(conn.execute(
                "SELECT count(*) FROM audit_log WHERE action=? AND object=?",
                ("human_review.hidden_reveal", cid)).fetchone()[0] or 0)
        except Exception:  # noqa: BLE001
            reveal_events = 0
        forced = False
        # P1-03：evaluation→production 不得由被评测审核员自助完成。隐藏池门禁
        # (`_hidden_gate`) 依据当前 mode；若允许切回 production，审核员可在未提交
        # 独立复核前看到隐藏项并裁决，评测/blind 口径被自证污染。锁生效期间拒绝；
        # 提交独立复核后隐藏项已解锁，此时允许回到 production（保留独立复核记录）。
        # X-14：锁生效期间业务管理员可 force 强制回退（受审计），审核员 force 仍拒绝。
        if new_mode == "production" and previous == "evaluation" and not independent:
            if not force_flag:
                return _err(
                    403, "evaluation_mode_locked",
                    "评测/盲审模式不能由审核员自助切回 production：提交独立复核前"
                    "会绕过隐藏项门禁。请先提交独立复核；如确需生产模式，请新建项目。"
                    "（业务管理员可强制回退：force=true + reason，写审计）",
                    mode=previous, evaluation_locked=True,
                    unlock_by_admin=True)
            if role_eff != "admin":
                return _err(
                    403, "evaluation_mode_force_forbidden",
                    "强制回退复核模式仅业务管理员可操作", mode=previous,
                    evaluation_locked=True, declared_role=role_eff)
            # 租户边界：业务管理员只能强制回退本租户项目
            try:
                from .. import repositories as _R14
                _urow14 = _R14.users.get(human_actor) or {}
            except Exception:  # noqa: BLE001
                _urow14 = {}
            _pt = str((_urow14 or {}).get("tenant_id") or "t-default")
            if str(case.get("tenant_id") or "t-default") != _pt:
                return _err(403, "cross_tenant_forbidden",
                            "业务管理员只能回退本租户项目", mode=previous)
            forced = True
        if new_mode == "evaluation" and reveal_events > 0:
            return _err(
                409, "reveal_history_exists",
                "该项目已有隐藏项打开历史，不能切换为评测/盲审模式"
                "（会污染独立复核口径）；请用新项目设置 evaluation", mode=new_mode,
                reveal_events=reveal_events)
        unchanged = bool(previous == new_mode)
        if not unchanged:
            _cfg_set(conn, _CFG_MODE_PREFIX + cid, new_mode)
            if new_mode == "production":
                # 切回 production 时保留独立复核记录（审计可追溯），不删除。
                pass
        if forced:
            _audit(conn, actor=human_actor, action="human_review.review_mode_force_set",
                   obj=cid, case=case, before=previous,
                   after=json.dumps({"mode": new_mode, "reason": why,
                                     "force": True, "previous_locked": True,
                                     "independent_submitted": bool(independent),
                                     "reveal_events_before": reveal_events,
                                     "unchanged": unchanged}, ensure_ascii=False))
        else:
            _audit(conn, actor=human_actor, action="human_review.review_mode_set",
                   obj=cid, case=case, before=previous,
                   after=json.dumps({"mode": new_mode, "reason": why,
                                     "reveal_events_before": reveal_events,
                                     "unchanged": unchanged}, ensure_ascii=False))
    return _ok(case_id=cid, mode=new_mode, mode_label=MODE_LABELS.get(new_mode),
               previous_mode=previous, unchanged=unchanged, forced=forced,
               independent_submitted=bool(independent),
               evaluation_locked=bool(new_mode == "evaluation" and not independent),
               lock_hint=EVALUATION_LOCK_HINT if new_mode == "evaluation" else "",
               not_gold=True)


def submit_independent_review(case_id: str, *, actor: str = "", role: str = "",
                              note: str = "") -> dict:
    """评测/盲审模式：审核员提交“独立复核”（提交后才允许打开隐藏项）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "提交独立复核必须记录 actor（写审计）")
    note = str(note or "").strip()[:_MAX_TEXT]
    with _conn() as conn:
        mode = _review_mode(conn, cid)
        existing = _independent_info(conn, cid)
        if existing:
            return _ok(case_id=cid, mode=mode, already_submitted=True,
                       independent_submitted=True, independent=existing,
                       evaluation_locked=False, not_gold=True)
        stamp = _now()
        payload = {"at": stamp, "actor": human_actor, "mode": mode,
                   "note": note, "not_gold": True}
        _cfg_set(conn, _CFG_INDEPENDENT_PREFIX + cid,
                 json.dumps(payload, ensure_ascii=False))
        _audit(conn, actor=human_actor, action="human_review.independent_submitted",
               obj=cid, case=case, before="",
               after=json.dumps({"mode": mode, "at": stamp, "note": note},
                                ensure_ascii=False))
    return _ok(case_id=cid, mode=mode, already_submitted=False,
               independent_submitted=True, independent=payload,
               evaluation_locked=False,
               note=("production 模式下仅记录独立复核时间；盲审门禁只在 evaluation 模式生效"
                     if mode != "evaluation" else "已提交独立复核，允许打开隐藏项用于仲裁/差异分析"),
               not_gold=True)


# --------------------------------------------------------------------------- 进化池钩子
def _hidden_reason(reason_code: str) -> tuple:
    code = str(reason_code or "").strip()
    return HIDDEN_REASON_DISPLAY.get(code, ("display_policy_filtered", "策略过滤"))


def _evidence_status(row: dict) -> dict:
    claim = row.get("raw_claim") or {}
    evidence = row.get("evidence") or {}
    qc = claim.get("quote_check") if isinstance(claim.get("quote_check"), dict) else {}
    quote = str(claim.get("quote") or "").strip()
    status = str((qc or {}).get("status") or claim.get("quote_match_status") or "").strip()
    out = {"evidence_status": status or ("quote_present" if quote else "missing_evidence"),
           "locator_status": "weak_locator" if claim.get("weak_locator") else "",
           "quote_present": bool(quote), "evidence_present": bool(evidence),
           "evidence_keys": sorted(str(k) for k in (evidence or {}).keys())[:10]}
    out["status_label"] = {
        "exact": "逐字命中", "normalized_ws": "空白归一命中（弱定位）",
        "verified": "证据可核验", "quote_present": "有引文但未核验",
        "missing_evidence": "无引文/无证据",
    }.get(out["evidence_status"], out["evidence_status"])
    return out


def _row_in_case_scope(case: dict, row: dict) -> bool:
    """行级 IDOR 兜底：台账行租户/空间必须与 case 一致（空值兼容老数据）。"""
    for key in ("tenant_id", "workspace_id"):
        case_val = str(case.get(key) or "")
        row_val = str(row.get(key) or "")
        if case_val and row_val and case_val != row_val:
            return False
    return True


def _strip_forbidden(value):
    """递归剔除 gold/auto_label 类字段（隐藏项绝对禁止泄漏 gold 标签）。"""
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            k = str(key)
            low = k.lower()
            if k in _FORBIDDEN_HIDDEN_KEYS or low.startswith("gold") \
                    or low.startswith("auto_suggested") or low == "auto_label":
                continue
            out[k] = _strip_forbidden(item)
        return out
    if isinstance(value, list):
        return [_strip_forbidden(x) for x in value]
    return value


def _evolution_enqueued_ids(conn, case_id: str) -> set:
    out = set()
    try:
        rows = conn.execute("SELECT payload FROM feedback WHERE case_id=? AND kind=?",
                            (case_id, EVOLUTION_KIND)).fetchall()
    except Exception:  # noqa: BLE001
        return out
    for row in rows:
        try:
            payload = json.loads(row[0] or "{}")
        except Exception:  # noqa: BLE001
            payload = {}
        hid = str((payload or {}).get("hidden_item_id") or "")
        if hid:
            out.add(hid)
    return out


def _enqueue_evolution(conn, case: dict, ledger_rows: list, *, actor: str = "",
                       via: str = "") -> dict:
    """所有隐藏项进入进化池：feedback(kind=hidden_item) + evolution_enqueued 事件。

    幂等：按 hidden_item_id 检查已有 feedback 行；不重复写。此钩子只做“入池 +
    弱默认标记”，不判真伪、不当 gold、不调阈值、不训练。
    """
    case_id = str(case.get("id") or "")
    existing = _evolution_enqueued_ids(conn, case_id)
    created = []
    for row in ledger_rows or []:
        lid = str(row.get("id") or "")
        if not lid or lid in existing:
            continue
        claim = row.get("raw_claim") or {}
        hidden_reason, hidden_label = _hidden_reason(row.get("suppression_reason"))
        payload = {
            "source": "human_review.hidden_pool",
            "hidden_item_id": lid,
            "case_id": case_id,
            "rule_code": str(row.get("rule_code") or ""),
            "subject": str(row.get("subject") or ""),
            "source_side": str(row.get("source") or ""),
            "suppression_reason": str(row.get("suppression_reason") or ""),
            "hidden_reason": hidden_reason,
            "hidden_reason_label": hidden_label,
            "risk_level": str(row.get("risk_level") or "medium"),
            "hidden_at": str(row.get("created_at") or ""),
            "evolution_status": "pending",
            "feedback_enqueued": True,
            "label": "",
            "label_strength": "none_pending",
            "label_source": "",
            "proposed_default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
            "default_disposition": "",
            "ttl_days": EVOLUTION_DEFAULT_TTL_DAYS,
            "no_gold": True,
            "auto_threshold_change": False,
            "auto_training": False,
            "tenant_id": str(case.get("tenant_id") or ""),
            "workspace_id": str(case.get("workspace_id") or ""),
        }
        feedback_id = db.new_id("fb")
        _insert_row(
            conn, "feedback", id=feedback_id, case_id=case_id, finding_id="",
            kind=EVOLUTION_KIND, rule_code=str(row.get("rule_code") or ""),
            title=f"[隐藏项进化候选] "
                  f"{str(row.get('rule_code') or row.get('subject') or lid)[:80]}",
            payload=json.dumps(payload, ensure_ascii=False),
            actor=str(actor or "system:human_review"), created_at=_now(),
            rsi_status="pending")
        try:
            CR.append_event(
                conn, "human_decision", case_id=case_id,
                run_id=str(row.get("run_id") or ""),
                comparison_item_id=str(row.get("comparison_item_id") or ""),
                ledger_id=lid, tenant_id=str(case.get("tenant_id") or ""),
                workspace_id=str(case.get("workspace_id") or ""),
                actor=str(actor or "system:human_review"),
                before_status="", after_status="pending",
                reason_code="evolution_enqueued",
                reason="隐藏项进入进化池（待处置；弱默认；非 gold；不调阈值/不自动训练）",
                evidence={**payload, "feedback_id": feedback_id, "via": str(via or "")})
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution enqueue event skipped ledger=%s", lid,
                           exc_info=True)
        created.append({"hidden_item_id": lid, "feedback_id": feedback_id})
        existing.add(lid)
    return {"created": created, "created_count": len(created),
            "existing_count": len(existing) - len(created)}


def _record_evolution_revealed(conn, case: dict, ledger_rows: list, *, actor: str,
                               mode: str, via: str = "") -> None:
    """打开隐藏区 → 逐条记录“已展示未动作”（reveal 无动作也留痕）。"""
    for row in (ledger_rows or [])[:50]:
        lid = str(row.get("id") or "")
        if not lid:
            continue
        payload = {
            "source": "human_review.hidden_pool",
            "hidden_item_id": lid,
            "evolution_status": "pending",
            "feedback_enqueued": True,
            "label": "",
            "label_strength": "none_pending",
            "label_source": "reveal_no_action",
            "default_disposition": "",
            "proposed_default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
            "mode": mode,
            "no_gold": True,
            "auto_threshold_change": False,
            "auto_training": False,
        }
        try:
            CR.append_event(
                conn, "human_decision", case_id=str(case.get("id") or ""),
                run_id=str(row.get("run_id") or ""),
                comparison_item_id=str(row.get("comparison_item_id") or ""),
                ledger_id=lid, tenant_id=str(case.get("tenant_id") or ""),
                workspace_id=str(case.get("workspace_id") or ""),
                actor=str(actor or ""), before_status="", after_status="pending",
                reason_code="evolution_revealed",
                reason="隐藏项被打开查看（尚未裁决，弱默认待处置）",
                evidence={**payload, "via": str(via or "")})
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution revealed event skipped ledger=%s", lid,
                           exc_info=True)


def _record_evolution_label(conn, case: dict, row: dict, *, action: str,
                            actor: str, reason: str = "", source: str = "") -> dict:
    """人工动作 → 进化标签事件（confirm=强标签；reject 等=弱人工标签且记录来源）。"""
    lid = str(row.get("id") or "")
    adjudication, strength, status = _HIDDEN_ACTION_LABEL.get(action, ("", "", "pending"))
    payload = {
        "source": "human_review.hidden_pool",
        "hidden_item_id": lid,
        "evolution_status": status,
        "feedback_enqueued": True,
        "label": adjudication,
        "label_strength": strength,
        "label_source": str(source or f"human_reveal_{action.replace('-', '_')}"),
        "default_disposition": "",
        "proposed_default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
        "decision_action": str(action or ""),
        "human_reason": str(reason or "")[:_MAX_REASON],
        "no_gold": True,
        "auto_threshold_change": False,
        "auto_training": False,
    }
    event = None
    try:
        event = CR.append_event(
            conn, "human_decision", case_id=str(case.get("id") or ""),
            run_id=str(row.get("run_id") or ""),
            comparison_item_id=str(row.get("comparison_item_id") or ""),
            ledger_id=lid, tenant_id=str(case.get("tenant_id") or ""),
            workspace_id=str(case.get("workspace_id") or ""),
            actor=str(actor or ""), before_status="pending",
            after_status=str(adjudication or status),
            reason_code="evolution_label",
            reason=str(reason or "")[:_MAX_REASON] or "人工隐藏项裁决",
            evidence=payload)
    except Exception:  # noqa: BLE001
        LOGGER.warning("evolution label event skipped ledger=%s", lid, exc_info=True)
    return {"payload": payload, "event": event}


def _evolution_public(event: dict | None, enqueued: bool,
                      default_due: bool = False) -> dict:
    base = {
        "evolution_status": "pending" if enqueued else "not_enqueued",
        "feedback_enqueued": bool(enqueued),
        "label": "",
        "label_strength": "none_pending" if enqueued else "",
        "label_source": "",
        "default_disposition": "",
        "proposed_default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
        "default_due": bool(default_due),
        "ttl_days": EVOLUTION_DEFAULT_TTL_DAYS,
        "event_at": "",
        "event_actor": "",
        "no_gold": True,
        "auto_threshold_change": False,
        "auto_training": False,
    }
    if not event:
        return base
    evidence = event.get("evidence") or {}
    for key in ("evolution_status", "label", "label_strength", "label_source",
                "default_disposition"):
        value = evidence.get(key)
        if value not in (None, ""):
            base[key] = value
    base["event_at"] = str(event.get("created_at") or "")
    base["event_actor"] = str(event.get("actor") or "")
    if base["evolution_status"] not in ("pending", "labeled_strong", "labeled_weak",
                                        "default_suspected_false_positive",
                                        "not_enqueued"):
        base["evolution_status"] = "pending"
    return base


def _evolution_aggregate(publics: list) -> dict:
    out = {"pending": 0, "labeled_strong": 0, "labeled_weak": 0,
           "default_suspected_false_positive": 0, "feedback_enqueued": 0,
           "total": 0, "default_due": 0, "evidence_insufficient": 0}
    for item in publics or []:
        out["total"] += 1
        status = str(item.get("evolution_status") or "")
        if status in out:
            out[status] += 1
        if item.get("feedback_enqueued"):
            out["feedback_enqueued"] += 1
        if item.get("evolution", {}).get("default_due"):
            out["default_due"] += 1
        if str(item.get("adjudication") or "") == "evidence_insufficient":
            out["evidence_insufficient"] += 1
    total = out["total"]
    out["feedback_coverage"] = round(out["feedback_enqueued"] * 100.0 / total, 2) \
        if total else 100.0
    out["target_feedback_coverage"] = EVOLUTION_TARGET_FEEDBACK_COVERAGE
    out["default_disposition"] = EVOLUTION_DEFAULT_DISPOSITION
    out["label_strength"] = "weak_default"
    out["ttl_days"] = EVOLUTION_DEFAULT_TTL_DAYS
    out["no_gold"] = True
    out["auto_threshold_change"] = False
    out["auto_training"] = False
    return out


# --------------------------------------------------------------------------- 可见性/权限门禁
def _hidden_gate(conn, case: dict, *, actor: str = "", role: str = "") -> dict | None:
    """隐藏池打开/裁决门禁：业务管理员不可开、evaluation 提交前不可开、actor 必填。"""
    cid = str(case.get("id") or "")
    role_eff = str(role or "")
    if role_eff == "admin":
        return _err(403, "read_only_hidden_pool",
                    "业务管理员只读：不可打开隐藏池、不可裁决隐藏项")
    mode = _review_mode(conn, cid)
    independent = _independent_info(conn, cid)
    if mode == "evaluation" and not independent:
        return _err(
            403, "evaluation_locked",
            "评测/盲审模式：提交独立复核前不显示隐藏项数量与内容，也不允许裁决"
            "（防止把隐藏项当成自己发现的，污染人工 gold）", mode=mode)
    if not str(actor or "").strip():
        return _err(401, "unauthenticated", "打开/裁决隐藏项必须记录 actor（写审计）")
    return None


def _actor_revealed(conn, case_id: str, actor: str) -> bool:
    try:
        row = conn.execute(
            "SELECT count(*) FROM audit_log WHERE action=? AND object=? AND actor=?",
            ("human_review.hidden_reveal", str(case_id or ""),
             str(actor or ""))).fetchone()
    except Exception:  # noqa: BLE001
        return False
    return bool(int(row[0] or 0)) if row else False


def _reveal_index(conn, case_id: str) -> tuple:
    """audit_log 打开事件 → ({hidden_item_id: {reveal_count,...}}, events list)。"""
    index, events = {}, []
    try:
        rows = conn.execute(
            "SELECT id,actor,after_json,created_at FROM audit_log WHERE action=? "
            "AND object=? ORDER BY created_at, rowid",
            ("human_review.hidden_reveal", str(case_id or ""))).fetchall()
    except Exception:  # noqa: BLE001
        rows = []
    for row in rows:
        try:
            payload = json.loads(row[2] or "{}")
        except Exception:  # noqa: BLE001
            payload = {}
        payload = payload if isinstance(payload, dict) else {}
        item_ids = [str(x) for x in (payload.get("item_ids") or []) if str(x)]
        event = {"event_id": str(row[0] or ""), "actor": str(row[1] or ""),
                 "at": str(row[3] or ""), "mode": str(payload.get("mode") or ""),
                 "hidden_count": int(payload.get("hidden_count") or 0),
                 "item_ids": item_ids, "action": str(payload.get("action") or "open"),
                 "via": str(payload.get("via") or "")}
        events.append(event)
        for item_id in item_ids:
            slot = index.setdefault(item_id, {"reveal_count": 0,
                                              "last_revealed_by": "",
                                              "last_revealed_at": ""})
            slot["reveal_count"] += 1
            slot["last_revealed_by"] = event["actor"]
            slot["last_revealed_at"] = event["at"]
    return index, events


def _hidden_states(conn, case_id: str) -> dict:
    try:
        events = CR.list_events(conn, case_id=str(case_id or "")) or []
    except Exception:  # noqa: BLE001
        events = []
    adjudication, evolution = {}, {}
    for event in events:
        ledger_id = str(event.get("ledger_id") or "")
        code = str(event.get("reason_code") or "")
        if not ledger_id:
            continue
        if code in _HIDDEN_EVENT_TO_ADJUDICATION:
            adjudication[ledger_id] = event
        if code in EVOLUTION_REASON_CODES:
            evolution[ledger_id] = event
    reveals, reveal_events = _reveal_index(conn, case_id)
    return {"adjudication": adjudication, "evolution": evolution,
            "reveals": reveals, "reveal_events": reveal_events}


def _hidden_adjudication(states: dict, ledger_id: str) -> str:
    event = (states.get("adjudication") or {}).get(str(ledger_id or ""))
    if not event:
        return "unreviewed"
    code = str(event.get("reason_code") or "")
    return _HIDDEN_EVENT_TO_ADJUDICATION.get(code, "unreviewed")


def _default_due(row: dict, states: dict, ttl_days: int) -> bool:
    if str(row.get("visibility_status") or "") != "suppressed":
        return False
    ledger_id = str(row.get("id") or "")
    if _hidden_adjudication(states, ledger_id) != "unreviewed":
        return False
    event = (states.get("evolution") or {}).get(ledger_id)
    if event and str(event.get("reason_code") or "") == "evolution_default_disposition":
        return False
    age = _age_days(row.get("created_at"))
    return bool(age is not None and age >= float(ttl_days or EVOLUTION_DEFAULT_TTL_DAYS))


# --------------------------------------------------------------------------- 隐藏项输出
def _hidden_item_public(case: dict, row: dict, states: dict,
                        enqueued: bool, ttl_days: int) -> dict:
    """单条隐藏项展示（白名单字段，含进化状态；绝不含 gold/auto_label）。"""
    ledger_id = str(row.get("id") or "")
    claim = row.get("raw_claim") or {}
    hidden_reason, hidden_reason_label = _hidden_reason(row.get("suppression_reason"))
    evidence = _evidence_status(row)
    adjudication = _hidden_adjudication(states, ledger_id)
    adjudication_event = (states.get("adjudication") or {}).get(ledger_id) or {}
    reveal = (states.get("reveals") or {}).get(ledger_id) or {}
    evolution_event = (states.get("evolution") or {}).get(ledger_id)
    default_due = _default_due(row, states, ttl_days)
    evolution = _evolution_public(evolution_event, enqueued, default_due)
    risk = str(row.get("risk_level") or "medium")
    severity = RISK_TO_SEVERITY.get(risk, "warning")
    data = {
        "hidden_item_id": ledger_id,
        "case_id": str(row.get("case_id") or case.get("id") or ""),
        "source": str(row.get("source") or ""),
        "source_label": {"direct": "直连", "platform": "平台",
                         "both": "直连+平台"}.get(str(row.get("source") or ""), ""),
        "original_item_id": str(row.get("direct_item_id")
                                or row.get("platform_finding_id") or ""),
        "comparison_item_id": str(row.get("comparison_item_id") or ""),
        "object_id": str(row.get("object_id") or ""),
        "rule_code": str(row.get("rule_code") or ""),
        "subject": str(row.get("subject") or ""),
        "issue_type": str(row.get("issue_type") or ""),
        "risk_level": risk,
        "severity": severity,
        "severity_label": SEVERITY_LABELS.get(severity, severity),
        "hidden_reason": hidden_reason,
        "hidden_reason_label": HIDDEN_REASON_CATEGORY_LABELS.get(hidden_reason,
                                                                hidden_reason),
        "hidden_reason_detail": hidden_reason_label,
        "suppression_reason": str(row.get("suppression_reason") or ""),
        "suppression_reason_label": GW.reason_codes().get(
            str(row.get("suppression_reason") or ""),
            str(row.get("suppression_reason") or "")),
        "reason_note": str(row.get("reason_note") or "")[:500],
        "evidence_status": evidence["evidence_status"],
        "evidence_status_label": evidence["status_label"],
        "locator_status": evidence["locator_status"],
        "evidence": {"quote_present": evidence["quote_present"],
                     "evidence_present": evidence["evidence_present"],
                     "keys": evidence["evidence_keys"]},
        "quote": str(claim.get("quote") or "")[:500],
        "issue": str(claim.get("issue") or claim.get("summary") or "")[:500],
        "reason": str(claim.get("reason") or "")[:500],
        "confidence": claim.get("confidence"),
        "hidden_at": str(row.get("created_at") or ""),
        "reveal_count": int(reveal.get("reveal_count") or 0),
        "last_revealed_by": str(reveal.get("last_revealed_by") or ""),
        "last_revealed_at": str(reveal.get("last_revealed_at") or ""),
        "adjudication": adjudication,
        "adjudication_label": HIDDEN_ADJUDICATION_LABELS.get(adjudication, adjudication),
        "adjudicated_by": str(adjudication_event.get("actor") or ""),
        "adjudicated_at": str(adjudication_event.get("created_at") or ""),
        "adjudication_reason": str(adjudication_event.get("reason") or "")[:500],
        "recovered_finding_id": str(row.get("recovered_finding_ref") or ""),
        "is_open": bool(str(row.get("visibility_status") or "") == "suppressed"
                        and adjudication in HIDDEN_OPEN_ADJUDICATIONS),
        "is_recovered": bool(str(row.get("visibility_status") or "") == "recovered"),
        "visible": False,
        "hidden": True,
        # 进化池最小钩子（T-52 完整引擎前的持久状态）
        "evolution_status": evolution["evolution_status"],
        "feedback_enqueued": evolution["feedback_enqueued"],
        "evolution": evolution,
        "default_disposition_proposed": EVOLUTION_DEFAULT_DISPOSITION,
        "not_gold": True,
        "l2_disclaimer": ("隐藏=默认视图过滤，不是删除；默认处置 suspected_false_positive"
                          "（weak_default）不是 gold，不直接调阈值、不自动训练"),
    }
    return _strip_forbidden(data)


def _visible_targets(conn, case_id: str) -> list:
    out = []
    try:
        items = CR.list_comparison_items(conn, case_id=case_id, visibility="visible")
    except Exception:  # noqa: BLE001
        return out
    for item in items[:50]:
        severity, risk = severity_of_item(item)
        out.append({"item_id": str(item.get("id") or ""),
                    "rule_code": str(item.get("match_key_code") or ""),
                    "subject": str(item.get("match_key_subject") or ""),
                    "severity": severity, "risk_level": risk,
                    "human_status": str(item.get("human_status") or "")})
    return out


def _hidden_snapshot(conn, case: dict, *, actor: str = "", role: str = "",
                     include_items: bool = False, audit_reveal: bool = True,
                     via: str = "", ensure_evolution: bool = True) -> dict:
    """隐藏池快照：只查/只拼装；include_items 时写打开审计（默认）。"""
    cid = str(case.get("id") or "")
    rows = [row for row in GW.ledger_list(conn, case_id=cid)
            if _row_in_case_scope(case, row)]
    if ensure_evolution:
        try:
            _enqueue_evolution(conn, case, rows,
                               actor=actor or "system:human_review", via=via)
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution enqueue skipped case=%s", cid, exc_info=True)
    enqueued = _evolution_enqueued_ids(conn, cid)
    mode = _review_mode(conn, cid)
    independent = _independent_info(conn, cid)
    locked = bool(mode == "evaluation" and not independent)
    gate_err = None
    if include_items:
        gate_err = _hidden_gate(conn, case, actor=actor, role=role)
        if gate_err:
            return {"ok": False, "error": gate_err}
    # 打开审计 + 逐条“已展示未动作”事件（必须先写，再回读 reveal_count）
    if include_items and audit_reveal:
        try:
            open_ids = [str(row.get("id") or "") for row in rows
                        if str(row.get("visibility_status") or "") == "suppressed"]
            # 打开时只审计当前待裁决项（证据不足仍算待裁决；已裁决关闭项不再返回）
            prelim = _hidden_states(conn, cid)
            open_ids = [ledger_id for ledger_id in open_ids
                        if _hidden_adjudication(prelim, ledger_id)
                        in HIDDEN_OPEN_ADJUDICATIONS]
            _audit(conn, actor=str(actor or ""),
                   action="human_review.hidden_reveal", obj=cid, case=case,
                   after=json.dumps({"case_id": cid, "mode": mode,
                                     "hidden_count": len(open_ids),
                                     "item_ids": open_ids[:50],
                                     "action": "open",
                                     "via": str(via or ""),
                                     "no_gold": True}, ensure_ascii=False))
            by_id = {str(row.get("id") or ""): row for row in rows}
            _record_evolution_revealed(
                conn, case, [by_id[i] for i in open_ids if i in by_id],
                actor=str(actor or ""), mode=mode, via=via)
        except Exception:  # noqa: BLE001
            LOGGER.warning("hidden reveal audit skipped case=%s", cid, exc_info=True)
    states = _hidden_states(conn, cid)
    publics = [_hidden_item_public(case, row, states,
                                   str(row.get("id") or "") in enqueued,
                                   EVOLUTION_DEFAULT_TTL_DAYS) for row in rows]
    open_items = [item for item in publics if item["is_open"]]
    recovered_items = [item for item in publics if item["is_recovered"]]
    count = len(open_items)
    admin = bool(str(role or "") == "admin")
    count_visible = bool(not locked)
    can_reveal = bool(not locked and not admin and str(actor or "").strip())
    evolution = _evolution_aggregate(publics) if count_visible else {}
    summary = {
        "mode": mode,
        "mode_label": MODE_LABELS.get(mode, mode),
        "default_mode": REVIEW_MODE_DEFAULT,
        "locked": locked,
        "lock_reason": ("提交独立复核前不显示隐藏项数量与内容（评测/盲审防锚定）"
                        if locked else ""),
        "can_reveal": can_reveal,
        "visible_to_role": bool(include_items),
        "count": count if count_visible else None,
        "count_visible": count_visible,
        "open_count": count if count_visible else None,
        "hidden_total": len(publics) if count_visible else None,
        "recovered_total": len(recovered_items) if count_visible else None,
        "closed_total": (len(publics) - count) if count_visible else None,
        "evolution": evolution,
        "evolution_status": ("pending" if count else ""),
        "feedback_enqueued": bool(evolution.get("feedback_enqueued"))
        if count_visible else None,
        "feedback_coverage": evolution.get("feedback_coverage")
        if count_visible else None,
        "default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
        "ttl_days": EVOLUTION_DEFAULT_TTL_DAYS,
        "no_gold": True,
        "note": ("隐藏项默认不在主列表展示（视图过滤，不是删除）；打开动作与逐条裁决"
                 "均写审计；确认真问题才恢复为可见问题并进入报告"),
    }
    return {
        "ok": True,
        "mode": mode,
        "mode_label": MODE_LABELS.get(mode, mode),
        "locked": locked,
        "independent": independent,
        "can_reveal": can_reveal,
        "summary": summary,
        "items": open_items if include_items else [],
        "recovered_items": recovered_items if include_items else [],
        "visible_targets": _visible_targets(conn, cid) if include_items else [],
        "evolution": evolution if count_visible else {},
        "visible_to_role": bool(include_items),
        "not_gold": True,
    }


def hidden_toggle_info(case_id: str, *, actor: str = "", role: str = "",
                       via: str = "summary") -> dict:
    """工作台顶部开关摘要（默认关闭：不含隐藏项内容）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "view", actor, role)
    if not access.get("ok"):
        return _deny(access)
    with _conn() as conn:
        snap = _hidden_snapshot(conn, case, actor=str(access.get("actor") or actor or ""),
                                role=str(access.get("role") or role or ""),
                                include_items=False, via=via)
    if not snap.get("ok"):
        return snap.get("error") or _err(500, "hidden_snapshot_failed", "隐藏项摘要失败")
    return _ok(case_id=cid, case=_case_brief(case), hidden=snap["summary"],
               mode=snap["mode"], review_mode=snap["mode"],
               mode_label=snap["mode_label"], locked=snap["locked"],
               independent_submitted=bool(snap.get("independent")),
               independent=snap.get("independent") or {},
               can_reveal=snap["can_reveal"],
               permissions={"can_reveal": snap["can_reveal"],
                            "read_only": bool(access.get("read_only")),
                            "role": str(access.get("role") or role or "")},
               not_gold=True)


def hidden_items(case_id: str, *, actor: str = "", role: str = "",
                 include_hidden: bool = False, via: str = "http") -> dict:
    """隐藏项列表（默认只返回计数/进化摘要；include_hidden=1 打开并写审计）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "view", actor, role)
    if not access.get("ok"):
        return _deny(access)
    actor_eff = str(access.get("actor") or actor or "").strip()
    role_eff = str(access.get("role") or role or "")
    with _conn() as conn:
        snap = _hidden_snapshot(conn, case, actor=actor_eff, role=role_eff,
                                include_items=bool(include_hidden),
                                audit_reveal=True, via=via)
    if not snap.get("ok"):
        return snap.get("error") or _err(500, "hidden_snapshot_failed", "隐藏项读取失败")
    out = _ok(case_id=cid, case=_case_brief(case), mode=snap["mode"],
              mode_label=snap["mode_label"], locked=snap["locked"],
              hidden=snap["summary"], hidden_visible_to_role=bool(include_hidden),
              items=snap["items"], visible_targets=snap["visible_targets"],
              evolution=snap["evolution"],
              # T-83（D-FLOW-01）：权限口径与 human-review 等端点同源，必须返回
              # can_review——工作台隐藏区（workbench_view.js `_wbHiddenRender`）以
              # permissions.can_review 判定逐条裁决按钮；缺该字段时审核员打开隐藏区
              # 后按钮恒不渲染，“隐藏项→恢复”UI 闭环不可用（服务层能力本身正常）。
              permissions={"can_reveal": snap["can_reveal"],
                           "can_review": bool(access.get("can_review")),
                           "read_only": bool(access.get("read_only")),
                           "actor": actor_eff, "role": role_eff},
              not_gold=True)
    out["hidden"]["items"] = snap["items"] if include_hidden else []
    return out


def reveal_hidden(case_id: str, *, actor: str = "", role: str = "",
                  note: str = "", via: str = "http") -> dict:
    """打开隐藏区（二次确认后的显式动作）：审计 reveal_event + 返回独立隐藏区列表。"""
    out = hidden_items(case_id, actor=actor, role=role, include_hidden=True, via=via)
    if out.get("ok"):
        out["action"] = "reveal"
        out["reveal_note"] = str(note or "")[:500]
        out["requires_confirm"] = True
        out["items"] = out.get("items") or []
        out["hidden"]["items"] = out["items"]
    return out


def _hidden_action_deny(conn, case: dict, action: str, *, actor: str = "",
                        role: str = "") -> dict | None:
    role_eff = str(role or "")
    if role_eff == "admin":
        return _err(403, "read_only_hidden_pool",
                    "业务管理员只读：不可打开隐藏池、不可裁决隐藏项")
    err = _hidden_gate(conn, case, actor=actor, role=role_eff)
    if err:
        return err
    if not _actor_revealed(conn, str(case.get("id") or ""), actor):
        return _err(409, "reveal_required",
                    "裁决隐藏项前必须先打开隐藏区（打开动作写审计；禁止无查看直接裁决）",
                    action=str(action or ""))
    return None


def hidden_item_action(case_id: str, item_id: str, action: str, *,
                       actor: str = "", role: str = "", reason: str = "",
                       merge_into: str = "", evidence: dict | None = None,
                       via: str = "http") -> dict:
    """隐藏项裁决唯一写入口（HTTP/CLI 同源）：confirm/reject/request-evidence/
    recover/merge/rule-error。全部写 audit_log + adjudication_event + 进化标签。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "隐藏项裁决必须记录 actor（写审计）")
    slug = str(action or "").strip().lower().replace("_", "-")
    if slug not in HIDDEN_ACTION_SLUGS:
        return _err(400, "invalid_hidden_action",
                    f"非法隐藏项操作：{action}（可选：{', '.join(HIDDEN_ACTION_SLUGS)}）",
                    allowed=list(HIDDEN_ACTION_SLUGS))
    lid = str(item_id or "").strip()
    if not lid:
        return _err(400, "invalid_request", "需要隐藏项 ID（hidden_item_id / suppression_ledger id）")
    reason = str(reason or "").strip()[:_MAX_REASON]
    if slug in ("reject", "request-evidence", "recover", "merge", "rule-error") \
            and not reason:
        return _err(400, "reason_required",
                    f"{HIDDEN_ACTION_LABELS.get(slug, slug)}必须填写原因（人工动作需审计）")
    merge_into = str(merge_into or "").strip()
    if slug == "merge" and not merge_into:
        return _err(400, "merge_target_required",
                    "合并必须指定 --into/merge_into（可见项 comparison_item id）")
    ledger = None
    with _conn() as conn:
        deny = _hidden_action_deny(conn, case, slug, actor=human_actor,
                                   role=str(access.get("role") or role or ""))
        if deny:
            return deny
        ledger = GW.ledger_get(conn, lid)
        if not ledger:
            return _err(404, "not_found", "隐藏项不存在")
        if str(ledger.get("case_id") or "") != cid or not _row_in_case_scope(case, ledger):
            return _err(404, "not_found", "隐藏项不属于该项目")
        try:
            _enqueue_evolution(conn, case, [ledger], actor=human_actor, via=via)
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution enqueue before action skipped", exc_info=True)
        states = _hidden_states(conn, cid)
        adjudication = _hidden_adjudication(states, lid)
        status = str(ledger.get("visibility_status") or "")
        event_code = _HIDDEN_ACTION_EVENT[slug]
        claim = ledger.get("raw_claim") or {}
        recovered_finding_id = ""
        feedback_id = ""
        suppression_error = None
        merge_target = ""
        already = False
        unchanged = False
        if slug in ("confirm", "recover"):
            if status == "recovered":
                already = True
            elif adjudication in ("rejected", "duplicate", "rule_error"):
                return _err(409, "already_adjudicated",
                            f"隐藏项已裁决为 {HIDDEN_ADJUDICATION_LABELS.get(adjudication)}，"
                            "不能恢复；如确需纠正请走规则/证据反馈",
                            adjudication=adjudication)
            else:
                try:
                    # W-10/W-11：recover 不再默认记 TP；人工 confirm/recover 必须显式
                    # 先写人工结论（true_positive，强标签来源），再由 recover 保留。
                    GW.ledger_record_human_result(
                        conn, lid, "true_positive", actor=human_actor,
                        reason=reason or "人工打开隐藏池确认隐藏项为真问题")
                    rec = GW.ledger_recover(
                        conn, lid, actor=human_actor,
                        reason=reason or "人工打开隐藏池确认隐藏项为真问题，恢复为可见问题")
                    if rec.get("recovered"):
                        refreshed = GW.ledger_get(conn, lid) or ledger
                        recovered_finding_id = _write_recovered_finding(
                            conn, case, refreshed,
                            {"issue": reason or str(claim.get("issue") or ""),
                             "quote": str(claim.get("quote") or ""),
                             "locator": {}}, human_actor)
                        if refreshed.get("comparison_item_id"):
                            try:
                                CR.set_human_decision(
                                    conn, refreshed["comparison_item_id"],
                                    "recovered_from_suppressed", actor=human_actor,
                                    reason=(reason or "隐藏项确认真问题（开门确认）")[:500],
                                    label="隐藏项确认真（已恢复可见）",
                                    evidence={"hidden_item_id": lid,
                                              "recovered_finding_id": recovered_finding_id,
                                              "suppression_error": True})
                            except Exception:  # noqa: BLE001
                                LOGGER.warning("hidden confirm comparison sync skipped",
                                               exc_info=True)
                        suppression_error = {
                            "kind": "suppression_error", "hidden_item_id": lid,
                            "suppression_reason": str(ledger.get("suppression_reason") or ""),
                            "source": str(ledger.get("source") or ""),
                            "risk_level": str(ledger.get("risk_level") or ""),
                            "feedback": "隐藏项被人工确认为真问题：需复核抑制原因/反证/阈值",
                            "recovered_finding_id": recovered_finding_id,
                        }
                    else:
                        already = bool(rec.get("already_recovered"))
                except (KeyError, ValueError) as exc:
                    return _err(409, "recover_failed", str(exc))
            adjudication = "confirmed"
            strength = "strong_human"
            evolution_status = "labeled_strong"
        elif slug == "reject":
            if adjudication == "rejected":
                already = True
            elif status == "recovered" or adjudication in ("confirmed", "duplicate",
                                                           "rule_error"):
                return _err(409, "already_adjudicated",
                            f"隐藏项已裁决/已恢复（{HIDDEN_ADJUDICATION_LABELS.get(adjudication)}），"
                            "不能判为误报", adjudication=adjudication)
            else:
                try:
                    GW.ledger_record_human_result(conn, lid, "false_positive",
                                           actor=human_actor, reason=reason)
                except (KeyError, ValueError) as exc:
                    return _err(409, "reject_failed", str(exc))
            adjudication = "rejected"
            strength = "weak_human"
            evolution_status = "labeled_weak"
        elif slug == "request-evidence":
            if adjudication == "evidence_insufficient":
                already = True
            elif adjudication in ("confirmed", "rejected", "duplicate", "rule_error") \
                    or status == "recovered":
                return _err(409, "already_adjudicated",
                            f"隐藏项已裁决（{HIDDEN_ADJUDICATION_LABELS.get(adjudication)}），"
                            "不能重复请求补证", adjudication=adjudication)
            else:
                try:
                    GW.ledger_record_human_result(conn, lid, "unclear",
                                           actor=human_actor, reason=reason)
                except (KeyError, ValueError) as exc:
                    return _err(409, "request_evidence_failed", str(exc))
            adjudication = "evidence_insufficient"
            strength = "none_pending"
            evolution_status = "pending"
        elif slug == "merge":
            if adjudication == "duplicate":
                already = True
                merge_target = str((((states.get("adjudication") or {}).get(lid)
                                     or {}).get("evidence") or {}).get("merge_into") or "")
            elif status == "recovered" or adjudication in ("confirmed", "rejected",
                                                           "rule_error"):
                return _err(409, "already_adjudicated",
                            f"隐藏项已裁决/已恢复（{HIDDEN_ADJUDICATION_LABELS.get(adjudication)}），"
                            "不能合并", adjudication=adjudication)
            else:
                target = CR.get_comparison_item(conn, merge_into)
                if not target:
                    return _err(404, "merge_target_not_found", "合并目标比对项不存在")
                if str(target.get("case_id") or "") != cid:
                    return _err(404, "merge_target_not_found", "合并目标不属于该项目")
                if str(target.get("visibility") or "") != "visible":
                    return _err(400, "merge_target_not_visible",
                                "合并目标必须是展示项（visible）；隐藏项之间不能互相合并")
                if str(ledger.get("comparison_item_id") or "") == merge_into:
                    return _err(400, "merge_target_invalid", "不能与自身合并")
                try:
                    GW.ledger_record_human_result(conn, lid, "unclear", actor=human_actor,
                                           reason=reason)
                except (KeyError, ValueError) as exc:
                    return _err(409, "merge_failed", str(exc))
                if ledger.get("comparison_item_id"):
                    try:
                        CR.set_visibility(
                            conn, str(ledger["comparison_item_id"]), "duplicate",
                            f"duplicate_merged_into:{merge_into}",
                            {"merged_into": merge_into, "hidden_item_id": lid,
                             "merged_by": human_actor})
                    except Exception:  # noqa: BLE001
                        LOGGER.warning("hidden merge visibility skipped", exc_info=True)
                merge_target = merge_into
            adjudication = "duplicate"
            strength = "weak_human"
            evolution_status = "labeled_weak"
        else:  # rule-error
            if adjudication in ("confirmed", "rejected", "duplicate") \
                    or status == "recovered":
                return _err(409, "already_adjudicated",
                            f"隐藏项已裁决/已恢复（{HIDDEN_ADJUDICATION_LABELS.get(adjudication)}），"
                            "不能重复反馈", adjudication=adjudication)
            try:
                GW.ledger_record_human_result(conn, lid, "false_positive", actor=human_actor,
                                       reason=reason)
            except (KeyError, ValueError) as exc:
                return _err(409, "rule_error_failed", str(exc))
            try:
                # 直接写 feedback 行（同一连接/事务；避免嵌套 db.session 写锁）。
                # kind=false_positive：规则/路由错误进入规则进化反向样本；
                # 不自动调阈值、不自动训练（payload 显式标记）。
                feedback_id = db.new_id("fb")
                _insert_row(
                    conn, "feedback", id=feedback_id, case_id=cid, finding_id="",
                    kind="false_positive",
                    rule_code=str(ledger.get("rule_code") or ""),
                    title=f"[隐藏项规则/路由错误] {ledger.get('rule_code') or lid}",
                    payload=json.dumps({
                        "hidden_item_id": lid, "case_id": cid,
                        "suppression_reason": str(ledger.get("suppression_reason")
                                                  or ""),
                        "source": str(ledger.get("source") or ""),
                        "reason": reason, "no_gold": True,
                        "auto_threshold_change": False,
                        "auto_training": False}, ensure_ascii=False),
                    actor=human_actor, created_at=_now(), rsi_status="pending")
            except Exception:  # noqa: BLE001
                feedback_id = ""
                LOGGER.warning("hidden rule-error feedback write skipped", exc_info=True)
            adjudication = "rule_error"
            strength = "weak_human"
            evolution_status = "labeled_weak"
        # 追加隐藏项裁决事件（adjudication_event 追加式；reason_code=hidden_*）
        event_payload = {
            "action": slug, "hidden_item_id": lid,
            "adjudication": adjudication, "label_strength": strength,
            "evolution_status": evolution_status,
            "suppression_reason": str(ledger.get("suppression_reason") or ""),
            "source_side": str(ledger.get("source") or ""),
            "merge_into": merge_target,
            "recovered_finding_id": recovered_finding_id,
            "feedback_id": feedback_id,
            "evidence": evidence if isinstance(evidence, dict) else {},
            "no_gold": True, "auto_threshold_change": False, "auto_training": False,
        }
        if not already:
            try:
                CR.append_event(
                    conn, "human_decision", case_id=cid,
                    run_id=str(ledger.get("run_id") or ""),
                    comparison_item_id=str(ledger.get("comparison_item_id") or ""),
                    ledger_id=lid, tenant_id=str(case.get("tenant_id") or ""),
                    workspace_id=str(case.get("workspace_id") or ""),
                    actor=human_actor, before_status=status,
                    after_status=adjudication, reason_code=event_code,
                    reason=reason or HIDDEN_ACTION_LABELS.get(slug, slug),
                    evidence=event_payload)
            except Exception:  # noqa: BLE001
                LOGGER.warning("hidden adjudication event skipped", exc_info=True)
            _record_evolution_label(conn, case, ledger, action=slug,
                                    actor=human_actor, reason=reason,
                                    source=f"human_reveal_{slug.replace('-', '_')}")
            _audit(conn, actor=human_actor,
                   action=f"human_review.hidden_{slug.replace('-', '_')}",
                   obj=lid, case=case, before=status,
                   after=json.dumps(event_payload, ensure_ascii=False))
        else:
            unchanged = True
        refreshed_ledger = GW.ledger_get(conn, lid) or ledger
        snap = _hidden_snapshot(conn, case, actor=human_actor,
                                role=str(access.get("role") or role or ""),
                                include_items=True, audit_reveal=False,
                                via=via, ensure_evolution=False)
        if not snap.get("ok"):
            snap = {"ok": True, "summary": {}, "items": [], "visible_targets": []}
        # 关闭项不一定在 open items 中：从全量隐藏状态重算该条进化状态
        evolution = {}
        try:
            states2 = _hidden_states(conn, cid)
            evolution = _evolution_public(
                (states2.get("evolution") or {}).get(lid),
                lid in _evolution_enqueued_ids(conn, cid),
                _default_due(refreshed_ledger, states2, EVOLUTION_DEFAULT_TTL_DAYS))
        except Exception:  # noqa: BLE001
            LOGGER.warning("hidden action evolution state skipped", exc_info=True)
    gate = _redact_hidden_gate(gate_check(cid))
    return _ok(
        case_id=cid, hidden_item_id=lid, action=slug,
        action_label=HIDDEN_ACTION_LABELS.get(slug, slug),
        adjudication=adjudication,
        adjudication_label=HIDDEN_ADJUDICATION_LABELS.get(adjudication, adjudication),
        already=bool(already), unchanged=bool(unchanged),
        recovered=bool(recovered_finding_id or adjudication == "confirmed"),
        recovered_finding_id=recovered_finding_id,
        suppression_error=suppression_error,
        merge_into=merge_target, feedback_id=feedback_id,
        label_strength=evolution.get("label_strength") or (
            _HIDDEN_ACTION_LABEL.get(slug) or ("", "", ""))[1],
        evolution_status=evolution.get("evolution_status") or "",
        feedback_enqueued=bool(evolution.get("feedback_enqueued")),
        evolution=evolution,
        hidden=snap.get("summary") or {},
        items=snap.get("items") or [],
        visible_targets=snap.get("visible_targets") or [],
        hidden_visible_to_role=True,
        gate=gate, not_gold=True)


# --------------------------------------------------------------------------- 指标
def _case_hidden_stats(conn, case: dict, ttl_days: int) -> dict:
    cid = str(case.get("id") or "")
    rows = [row for row in GW.ledger_list(conn, case_id=cid)
            if _row_in_case_scope(case, row)]
    enqueued = _evolution_enqueued_ids(conn, cid)
    states = _hidden_states(conn, cid)
    mode = _review_mode(conn, cid)
    independent = bool(_independent_info(conn, cid))
    stats = {"case_id": cid, "mode": mode, "independent_submitted": independent,
             "hidden_total": len(rows), "open": 0, "recovered": 0,
             "confirmed": 0, "rejected": 0, "evidence_insufficient": 0,
             "duplicate": 0, "rule_error": 0, "default_suspected_false_positive": 0,
             "evolution_pending": 0, "labeled_strong": 0, "labeled_weak": 0,
             "feedback_enqueued": 0, "default_due": 0,
             "by_source": {}, "by_reason": {}, "reveal_events": len(
                 states.get("reveal_events") or []),
             "revealed_items": 0, "revealed_cases": 0, "items_revealed": set(),
             "reveal_to_decide": [], "decisions": 0, "notes": []}
    if rows:
        stats["revealed_cases"] = 1 if stats["reveal_events"] else 0
    for row in rows:
        lid = str(row.get("id") or "")
        adjudication = _hidden_adjudication(states, lid)
        status = str(row.get("visibility_status") or "")
        evolution_event = (states.get("evolution") or {}).get(lid)
        evolution_status = _evolution_public(
            evolution_event, lid in enqueued,
            _default_due(row, states, ttl_days))["evolution_status"]
        reason = _hidden_reason(row.get("suppression_reason"))[0]
        source = str(row.get("source") or "")
        source_slot = stats["by_source"].setdefault(
            source, {"hidden_total": 0, "confirmed": 0, "rejected": 0,
                     "evidence_insufficient": 0, "duplicate": 0,
                     "rule_error": 0, "recovered": 0})
        source_slot["hidden_total"] += 1
        slot = stats["by_reason"].setdefault(
            reason, {"hidden_total": 0, "confirmed": 0, "rejected": 0,
                     "evidence_insufficient": 0, "duplicate": 0, "rule_error": 0,
                     "recovered": 0})
        slot["hidden_total"] += 1
        if status == "recovered":
            stats["recovered"] += 1
            source_slot["recovered"] += 1
            slot["recovered"] += 1
        if adjudication in HIDDEN_OPEN_ADJUDICATIONS and status == "suppressed":
            stats["open"] += 1
        if adjudication in ("confirmed", "rejected", "evidence_insufficient",
                            "duplicate", "rule_error"):
            stats["decisions"] += 1
        if adjudication == "confirmed":
            stats["confirmed"] += 1
        elif adjudication == "rejected":
            stats["rejected"] += 1
        elif adjudication == "evidence_insufficient":
            stats["evidence_insufficient"] += 1
        elif adjudication == "duplicate":
            stats["duplicate"] += 1
        elif adjudication == "rule_error":
            stats["rule_error"] += 1
        if adjudication in ("confirmed", "rejected", "evidence_insufficient",
                            "duplicate", "rule_error"):
            source_slot[adjudication] = source_slot.get(adjudication, 0) + 1
            slot[adjudication] = slot.get(adjudication, 0) + 1
        evo = _evolution_public(evolution_event, lid in enqueued,
                                _default_due(row, states, ttl_days))
        key = evo["evolution_status"]
        if key == "pending":
            stats["evolution_pending"] += 1
        elif key == "labeled_strong":
            stats["labeled_strong"] += 1
        elif key == "labeled_weak":
            stats["labeled_weak"] += 1
        elif key == "default_suspected_false_positive":
            stats["default_suspected_false_positive"] += 1
        if lid in enqueued:
            stats["feedback_enqueued"] += 1
        if evo.get("default_due"):
            stats["default_due"] += 1
        reveal = (states.get("reveals") or {}).get(lid) or {}
        if reveal:
            stats["revealed_items"] += 1
            stats["items_revealed"].add(lid)
            decision_event = (states.get("adjudication") or {}).get(lid)
            if decision_event:
                first_reveal_at = None
                for event in (states.get("reveal_events") or []):
                    if lid in (event.get("item_ids") or []):
                        first_reveal_at = event.get("at")
                        break
                start = _epoch(first_reveal_at)
                end = _epoch(decision_event.get("created_at"))
                if start is not None and end is not None and end >= start:
                    stats["reveal_to_decide"].append(round(end - start, 3))
    total = stats["hidden_total"]
    stats["feedback_coverage"] = round(
        stats["feedback_enqueued"] * 100.0 / total, 2) if total else 100.0
    stats["recovery_rate"] = round(stats["recovered"] * 100.0 / total, 2) \
        if total else 0.0
    stats["item_reveal_rate"] = round(stats["revealed_items"] * 100.0 / total, 2) \
        if total else 0.0
    values = stats.pop("items_revealed", set())
    stats["revealed_item_ids"] = sorted(values)[:50]
    deltas = stats.pop("reveal_to_decide", [])
    stats["reveal_to_decide_seconds"] = round(sum(deltas) / len(deltas), 2) \
        if deltas else None
    stats["decision_count"] = stats.pop("decisions", 0)
    return stats


def hidden_metrics(*, case_id: str = "", actor: str = "", role: str = "",
                   tenant_id: str = "", ttl_days: int = EVOLUTION_DEFAULT_TTL_DAYS) -> dict:
    """隐藏开关/进化池指标（分 production/evaluation/source/reason）。

    口径（避免夸大）：
    - reveal_rate = 有打开审计的 case 数 / 有隐藏项的 case 数（自愿行为，选择偏差）；
    - item_reveal_rate = 被打开过的隐藏项 / 隐藏项总数；
    - recovery_rate = 已恢复为可见 / 隐藏项总数；
    - hidden_confirmed_tp / hidden_false_positive 只统计人工裁决事件；
    - feedback_coverage = 已入进化池隐藏项 / 隐藏项总数（目标 100%，最小钩子口径）；
    - 默认处置（TTL）只能是 suspected_false_positive + weak_default，非 gold。
    """
    cid = str(case_id or "").strip()
    if cid:
        case, err = _case_access(cid, actor, role, "view")
        if err:
            return err
        cases = [case]
    else:
        cases = _visible_cases(actor, role, tenant_id)
        if not cases:
            return _err(403, "forbidden",
                        "无可见项目（或缺少租户作用域），不能读取隐藏项指标")
    ttl_defaults = {"ttl_days": int(ttl_days or EVOLUTION_DEFAULT_TTL_DAYS),
                    "default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
                    "label_strength": "weak_default", "no_gold": True,
                    "auto_threshold_change": False, "auto_training": False}
    agg = {
        "hidden_count": 0, "hidden_total": 0, "open": 0, "recovered": 0,
        "confirmed": 0, "rejected": 0, "evidence_insufficient": 0,
        "duplicate": 0, "rule_error": 0,
        "hidden_confirmed_tp": 0, "hidden_false_positive": 0,
        "hidden_evidence_insufficient": 0, "hidden_duplicate": 0,
        "hidden_rule_error": 0, "default_suspected_false_positive": 0,
        "evolution_pending": 0, "labeled_strong": 0, "labeled_weak": 0,
        "feedback_enqueued": 0, "default_due": 0,
        "reveal_events": 0, "revealed_items": 0, "cases_with_hidden": 0,
        "cases_revealed": 0, "reveal_to_decide": [], "decision_count": 0,
        "by_mode": {"production": {}, "evaluation": {}},
        "by_source": {}, "by_reason": {},
    }
    with _conn() as conn:
        case_stats = [_case_hidden_stats(conn, case, ttl_defaults["ttl_days"])
                      for case in cases]
    for stat in case_stats:
        if stat["hidden_total"]:
            agg["cases_with_hidden"] += 1
        if stat["reveal_events"]:
            agg["cases_revealed"] += 1
        for key in ("hidden_total", "open", "recovered", "confirmed", "rejected",
                    "evidence_insufficient", "duplicate", "rule_error",
                    "default_suspected_false_positive", "evolution_pending",
                    "labeled_strong", "labeled_weak", "feedback_enqueued",
                    "default_due", "reveal_events", "revealed_items",
                    "decision_count"):
            agg[key] += int(stat.get(key) or 0)
        if stat.get("reveal_to_decide_seconds") is not None:
            agg["reveal_to_decide"].append(stat["reveal_to_decide_seconds"])
        mode = str(stat.get("mode") or REVIEW_MODE_DEFAULT)
        slot = agg["by_mode"].setdefault(mode, {})
        for key in ("hidden_total", "open", "recovered", "confirmed", "rejected",
                    "evidence_insufficient", "duplicate", "rule_error",
                    "reveal_events", "revealed_items", "feedback_enqueued"):
            slot[key] = int(slot.get(key) or 0) + int(stat.get(key) or 0)
        for source, data in (stat.get("by_source") or {}).items():
            slot = agg["by_source"].setdefault(source, {})
            for key, value in (data or {}).items():
                slot[key] = int(slot.get(key) or 0) + int(value or 0)
        for reason, data in (stat.get("by_reason") or {}).items():
            slot = agg["by_reason"].setdefault(reason, {})
            for key, value in (data or {}).items():
                slot[key] = int(slot.get(key) or 0) + int(value or 0)
        if stat.get("revealed_item_ids"):
            agg.setdefault("revealed_item_sample", []).extend(
                stat["revealed_item_ids"])
            agg["revealed_item_sample"] = agg["revealed_item_sample"][:50]
    total = agg["hidden_total"]
    agg["hidden_count"] = agg["open"]
    agg["hidden_confirmed_tp"] = agg["confirmed"]
    agg["hidden_false_positive"] = agg["rejected"]
    agg["hidden_evidence_insufficient"] = agg["evidence_insufficient"]
    del agg["confirmed"], agg["rejected"], agg["evidence_insufficient"]
    del agg["duplicate"], agg["rule_error"]
    agg["feedback_coverage"] = round(
        agg["feedback_enqueued"] * 100.0 / total, 2) if total else 100.0
    agg["feedback_coverage_target"] = EVOLUTION_TARGET_FEEDBACK_COVERAGE
    agg["reveal_rate"] = round(
        agg["cases_revealed"] * 100.0 / agg["cases_with_hidden"], 2) \
        if agg["cases_with_hidden"] else 0.0
    agg["item_reveal_rate"] = round(agg["revealed_items"] * 100.0 / total, 2) \
        if total else 0.0
    agg["recovery_rate"] = round(agg["recovered"] * 100.0 / total, 2) \
        if total else 0.0
    deltas = agg.pop("reveal_to_decide", [])
    agg["reveal_to_decide_seconds"] = round(sum(deltas) / len(deltas), 2) \
        if deltas else None
    agg.update(ttl_defaults)
    agg["scope"] = {"case_id": cid, "cases": len(cases),
                    "tenant_id": _tenant_ctx(actor, role, tenant_id),
                    "role": str(role or "")}
    agg["generated_at"] = _now()
    agg["notes"] = [
        "reveal 是自愿行为 → 有选择偏差；不能只用 reveal 样本估计全部隐藏 TP，"
        "仍需独立分层抽样",
        "隐藏项默认不在报告正文出现；只有人工 confirm 恢复为 visible 后才进入报告",
        "进化池为最小持久钩子（feedback kind=hidden_item + adjudication_event）；"
        "完整进化引擎 T-52，本项不自动调阈值/不自动训练/不把弱默认当 gold",
    ]
    agg["no_gold"] = True
    agg["not_gold"] = True
    return _ok(case_id=cid, metrics=agg, cases=[_case_brief(c) for c in cases],
               hidden_visible_to_role=str(role or "") != "admin" or bool(cid),
               not_gold=True)


# --------------------------------------------------------------------------- TTL 默认处置
def apply_evolution_defaults(*, case_id: str = "", actor: str = "", role: str = "",
                             tenant_id: str = "",
                             ttl_days: int = EVOLUTION_DEFAULT_TTL_DAYS,
                             dry_run: bool = False) -> dict:
    """无动作隐藏项 TTL 默认处置（最小钩子，非 gold）。

    只对“未裁决且超过 TTL”的隐藏项写 default_disposition=suspected_false_positive
    + label_strength=weak_default 事件；**不改变可见性、不写 finding、不调阈值、
    不自动训练、不当 gold**。完整调度由 T-52 进化引擎负责。
    """
    cid = str(case_id or "").strip()
    if cid:
        case, err = _case_access(cid, actor, role, "review")
        if err:
            return err
        cases = [case]
    else:
        cases = _visible_cases(actor, role, tenant_id)
        if not cases:
            return _err(403, "forbidden",
                        "无可见项目（或缺少租户作用域），不能应用隐藏项默认处置")
        if str(role or "") != "reviewer":
            return _err(403, "forbidden", "默认处置只允许项目审核员执行（业务管理员只读）")
    human_actor = str(actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "默认处置必须记录 actor（写审计）")
    ttl = int(ttl_days or EVOLUTION_DEFAULT_TTL_DAYS)
    if ttl <= 0:
        return _err(400, "invalid_ttl", "ttl_days 必须为正整数")
    due, applied, skipped_human, per_case = [], [], [], {}
    with _conn() as conn:
        for case in cases:
            stats = _case_hidden_stats(conn, case, ttl)
            rows = [row for row in GW.ledger_list(conn, case_id=str(case.get("id")))]
            rows = [row for row in rows if _row_in_case_scope(case, row)]
            try:
                _enqueue_evolution(conn, case, rows, actor=human_actor,
                                   via="evolution_defaults")
            except Exception:  # noqa: BLE001
                LOGGER.warning("evolution enqueue before default skipped",
                               exc_info=True)
            states = _hidden_states(conn, str(case.get("id") or ""))
            case_due = []
            for row in rows:
                lid = str(row.get("id") or "")
                if not _default_due(row, states, ttl):
                    adjudication = _hidden_adjudication(states, lid)
                    if adjudication not in (None, "", "unreviewed"):
                        skipped_human.append(lid)
                    continue
                case_due.append(lid)
            due.extend(case_due)
            if dry_run or not case_due:
                per_case[str(case.get("id"))] = {"due": case_due,
                                                 "applied": [] if dry_run else case_due,
                                                 "dry_run": bool(dry_run)}
                continue
            for lid in case_due:
                row = next((r for r in rows if str(r.get("id")) == lid), None)
                if not row:
                    continue
                payload = {
                    "source": "human_review.hidden_pool", "hidden_item_id": lid,
                    "evolution_status": "default_suspected_false_positive",
                    "feedback_enqueued": True, "label": "suspected_false_positive",
                    "label_strength": "weak_default",
                    "label_source": "ttl_default",
                    "default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
                    "ttl_days": ttl,
                    "hidden_at": str(row.get("created_at") or ""),
                    "no_gold": True, "auto_threshold_change": False,
                    "auto_training": False,
                    "note": "无人工动作超 TTL 默认处置：仅弱标签，非 gold，"
                            "不改可见性、不调阈值、不自动训练",
                }
                try:
                    CR.append_event(
                        conn, "human_decision",
                        case_id=str(case.get("id") or ""),
                        run_id=str(row.get("run_id") or ""),
                        comparison_item_id=str(row.get("comparison_item_id") or ""),
                        ledger_id=lid,
                        tenant_id=str(case.get("tenant_id") or ""),
                        workspace_id=str(case.get("workspace_id") or ""),
                        actor=human_actor, before_status="unreviewed",
                        after_status="default_suspected_false_positive",
                        reason_code="evolution_default_disposition",
                        reason="无动作超 TTL：默认处置 suspected_false_positive"
                               "（weak_default，非 gold）",
                        evidence=payload)
                except Exception:  # noqa: BLE001
                    LOGGER.warning("evolution default event skipped ledger=%s", lid,
                                   exc_info=True)
                applied.append(lid)
            if len(cases) == 1:
                _audit(conn, actor=human_actor,
                       action="human_review.evolution_defaults",
                       obj=str(case.get("id") or ""), case=case, before="",
                       after=json.dumps({"ttl_days": ttl, "due": len(case_due),
                                         "applied": len(case_due),
                                         "default_disposition":
                                             EVOLUTION_DEFAULT_DISPOSITION,
                                         "label_strength": "weak_default"},
                                        ensure_ascii=False))
            per_case[str(case.get("id"))] = {"due": case_due,
                                             "applied": list(case_due),
                                             "dry_run": False}
    if not dry_run and cases:
        try:
            with _conn() as conn:
                for case in cases:
                    if len(cases) == 1:
                        continue
                    _audit(conn, actor=human_actor,
                           action="human_review.evolution_defaults",
                           obj=str(case.get("id") or ""), case=case, before="",
                           after=json.dumps({"ttl_days": ttl,
                                             "default_disposition":
                                                 EVOLUTION_DEFAULT_DISPOSITION,
                                             "label_strength": "weak_default"},
                                            ensure_ascii=False))
        except Exception:  # noqa: BLE001
            LOGGER.warning("evolution defaults audit skipped", exc_info=True)
    return _ok(ttl_days=ttl, dry_run=bool(dry_run),
               default_disposition=EVOLUTION_DEFAULT_DISPOSITION,
               label_strength="weak_default", due=due, applied=applied,
               due_count=len(due), applied_count=len(applied),
               skipped_human_count=len(skipped_human),
               case_id=cid, cases=per_case, by_case=per_case,
               no_gold=True, auto_threshold_change=False, auto_training=False,
               visibility_changed=False,
               note="默认处置只写弱标签事件，不改变可见性、不写 finding、不调阈值、"
                    "不自动训练；完整调度属 T-52",
               not_gold=True)


def enqueue_evolution_for_case(case_id: str, *, actor: str = "", role: str = "",
                               via: str = "cli") -> dict:
    """显式补齐：把该项目全部隐藏项写入进化池（幂等；运维/回填入口）。"""
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _authorize(cid, "review", actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "进化池回填必须记录 actor（写审计）")
    with _conn() as conn:
        rows = [row for row in GW.ledger_list(conn, case_id=cid)
                if _row_in_case_scope(case, row)]
        result = _enqueue_evolution(conn, case, rows, actor=human_actor, via=via)
        _audit(conn, actor=human_actor, action="human_review.evolution_enqueue",
               obj=cid, case=case, before="",
               after=json.dumps({"hidden_total": len(rows),
                                 "created": result["created_count"],
                                 "existing": result["existing_count"]},
                                ensure_ascii=False))
        enqueued = _evolution_enqueued_ids(conn, cid)
        stats = _case_hidden_stats(conn, case, EVOLUTION_DEFAULT_TTL_DAYS)
    return _ok(case_id=cid, hidden_total=len(rows),
               enqueued_total=len(enqueued),
               created=result["created_count"],
               existing=result["existing_count"],
               feedback_coverage=stats["feedback_coverage"],
               evolution_pending=stats["evolution_pending"],
               h_id_sample=[x["hidden_item_id"] for x in result["created"]][:50],
               no_gold=True, not_gold=True)


def hidden_report_stats(case_id: str, *, actor: str = "", role: str = "") -> dict:
    """report_gate/报告状态用聚合（无内容；evaluation 提交前不返回 N）。"""
    cid = str(case_id or "").strip()
    out = {"enabled": False, "mode": REVIEW_MODE_DEFAULT, "locked": False,
           "hidden_count": None, "evolution": {}, "no_gold": True,
           "note": ""}
    if not cid:
        return out
    case = _case(cid)
    if not case:
        out["note"] = "项目不存在"
        return out
    try:
        with _conn() as conn:
            snap = _hidden_snapshot(conn, case, actor=str(actor or ""),
                                    role=str(role or ""), include_items=False,
                                    via="report", ensure_evolution=False)
        if not snap.get("ok"):
            out["note"] = "隐藏项摘要不可用"
            return out
        summary = snap.get("summary") or {}
        out.update({"enabled": bool(summary.get("hidden_total")),
                    "mode": summary.get("mode") or REVIEW_MODE_DEFAULT,
                    "locked": bool(summary.get("locked")),
                    "hidden_count": summary.get("count"),
                    "evolution": summary.get("evolution") or {},
                    "default_disposition": EVOLUTION_DEFAULT_DISPOSITION,
                    "ttl_days": EVOLUTION_DEFAULT_TTL_DAYS,
                    "note": summary.get("note") or ""})
    except Exception:  # noqa: BLE001
        LOGGER.warning("hidden report stats skipped case=%s", cid, exc_info=True)
        out["note"] = "隐藏项统计跳过（异常）"
    return out


__all__ = [
    "SEVERITIES", "SEVERITY_LABELS", "RISK_TO_SEVERITY", "REVIEW_DECISIONS",
    "CONFIRM_DECISIONS", "NEGATIVE_DECISIONS", "REASON_REQUIRED_DECISIONS",
    "DECISION_LABELS", "OMISSION_REQUIRED_FIELDS",
    "severity_of_item", "review_queue", "review_progress", "hidden_stats",
    "omission_stats", "gate_check", "case_payload", "backend_view",
    "decide_item", "submit_omission", "list_omissions", "reconcile_case",
    "prepare_case",
    # T-50 V3.2 产品接线
    "GATE_FLAG_NAMES", "GATE_FLAG_LABELS", "PRODUCT_LIMIT_DEFAULT",
    "PRODUCT_LIMIT_MAX", "direct_draft_list", "direct_draft_show",
    "comparison_list", "comparison_show", "visibility_show",
    "ledger_list", "ledger_show", "ledger_recover", "omission_list",
    "omission_show",
    "product_gate", "_manifest_incomplete_applicable",
    # T-51（V3.3 增补）人工隐藏开关 + 进化池最小钩子
    "REVIEW_MODES", "REVIEW_MODE_DEFAULT", "MODE_LABELS",
    "HIDDEN_ACTION_SLUGS", "HIDDEN_ACTION_LABELS", "HIDDEN_ADJUDICATIONS",
    "HIDDEN_ADJUDICATION_LABELS", "HIDDEN_REASON_CATEGORIES",
    "EVOLUTION_KIND", "EVOLUTION_DEFAULT_TTL_DAYS",
    "EVOLUTION_DEFAULT_DISPOSITION", "EVOLUTION_TARGET_FEEDBACK_COVERAGE",
    "review_mode_get", "review_mode_set", "submit_independent_review",
    "hidden_toggle_info", "hidden_items", "reveal_hidden", "hidden_item_action",
    "hidden_metrics", "apply_evolution_defaults", "enqueue_evolution_for_case",
    "hidden_report_stats",
]
