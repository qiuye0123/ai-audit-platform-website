"""扫描件低置信标记（口径层，复用 TL-5 page provenance，不改解析/判定链路）。

背景：扫描件/传真件的数值事实来自视觉模型或混合解析时，判定置信度天然低于
可信文本层。TL-5（``app/engine/hooks.py``）已把页级 provenance 归一为
trusted / vision / unknown / mixed。本模块只做**标注**：给这些页产生的 finding
打 ``needs_human=true`` + 原因，供人工复核优先处理；不改变 D1-D5 结论、不改
finding 五态、不写数据库。

口径（与 TL-5 一致，fail-closed 方向）：
- 只有 vision / mixed 来源的 finding 才标 ``needs_human``（unknown 不在此处标，
  它由报告门禁/证据链按原有口径处理，避免二次重复标记）；
- ``page_provenance`` 为空/None 时不标任何 finding（老数据/未接线不得被误标）；
- 找不到 finding 的文档归属时不标（无法归因的标记会制造噪声，宁可不标并留字段
  ``low_confidence_unattributed=True`` 供 Phase 2 统计）；
- 返回 **副本**，不修改调用方入参（避免污染 finding 台账）。
"""
from __future__ import annotations

from ..engine import hooks as _hooks

VISION_STATES = ("vision", "mixed")
TRUSTED_STATES = ("trusted",)


def _prov_state(prov) -> str:
    """单文档 provenance → trusted/vision/unknown/mixed。

    dict/list 走 TL-5 唯一归一函数（B5/B6 的 fail-closed 规则不改写）；
    显式状态字符串只接受 4 个已知态，其余一律 unknown。
    """
    if prov is None:
        return "unknown"
    if isinstance(prov, str):
        s = prov.strip().lower()
        return s if s in ("trusted", "vision", "mixed", "unknown") else "unknown"
    if isinstance(prov, (dict, list, tuple)):
        try:
            return str(_hooks.provenance_state(prov) or "unknown")
        except Exception:  # noqa: BLE001 - 归一失败按未知，不静默当可信
            return "unknown"
    return "unknown"


def _prov_map(page_provenance) -> dict:
    """page_provenance → {doc_id: raw_provenance}。

    支持三种入参：
    - {doc_id: provenance}（页级 dict / 文档摘要 dict / 状态字符串）；
    - [{document_id: ..., ...provenance}]（列表形态，取 document_id/doc 作键）；
    - 其它/空 → {}。
    """
    if not page_provenance:
        return {}
    if isinstance(page_provenance, dict):
        return {str(k): v for k, v in page_provenance.items() if str(k).strip()}
    if isinstance(page_provenance, (list, tuple)):
        out = {}
        for item in page_provenance:
            if not isinstance(item, dict):
                continue
            key = item.get("document_id") or item.get("doc") or item.get("doc_id") or ""
            if str(key).strip():
                out[str(key)] = item.get("provenance") if "provenance" in item else item
        return out
    return {}


def _doc_ids(finding: dict) -> list:
    """从 finding 里取文档归属（兼容 evidence 列表/单字段/文档列表）。"""
    out = []

    def _add(value):
        if isinstance(value, dict):
            value = value.get("document_id") or value.get("doc") or value.get("id") or ""
        for token in (value if isinstance(value, (list, tuple)) else [value]):
            s = str(token or "").strip()
            if s and s not in out:
                out.append(s)

    for key in ("document_id", "documentId", "doc_id", "doc"):
        if finding.get(key):
            _add(finding.get(key))
    for key in ("document_ids", "documents", "doc_ids"):
        if finding.get(key):
            _add(finding.get(key))
    evidence = finding.get("evidence") or []
    if isinstance(evidence, (list, tuple)):
        for ev in evidence:
            if isinstance(ev, dict):
                _add(ev.get("document_id") or ev.get("doc") or ev.get("documentId"))
    return out


def mark_low_confidence(findings, page_provenance=None) -> list:
    """给 vision/mixed 页相关的 finding 标 ``needs_human=true`` + 原因。

    参数：
        findings: finding dict 列表（可为空）。
        page_provenance: 文档级/页级 provenance（见 ``_prov_map`` 支持的形态）。

    返回：finding 副本列表；命中 vision/mixed 的项新增/覆盖：
        needs_human=True
        low_confidence=True
        low_confidence_reason=<中文原因，含文档与来源状态>
        low_confidence_docs=[...]
        low_confidence_states={doc_id: state}
        （若原 finding 无 ``reason`` 字段，同时写 ``reason`` 便于旧展示兼容）
    """
    marks = _prov_map(page_provenance)
    out = []
    for finding in (findings or []):
        if not isinstance(finding, dict):
            out.append(finding)
            continue
        item = dict(finding)
        if not marks:
            out.append(item)
            continue
        doc_ids = _doc_ids(item)
        attributed = [d for d in doc_ids if d in marks]
        if not attributed:
            # 有 provenance 但 finding 无法归因：不标记，只留可统计标记（不误标）
            if doc_ids:
                item.setdefault("low_confidence_unattributed", True)
            out.append(item)
            continue
        hit_states = {d: _prov_state(marks[d]) for d in attributed}
        bad = {d: st for d, st in hit_states.items() if st in VISION_STATES}
        if not bad:
            out.append(item)
            continue
        detail = "、".join(f"{d}={st}" for d, st in bad.items())
        reason = f"扫描件/混合来源（vision/mixed）页证据，需人工复核：{detail}"
        item["needs_human"] = True
        item["low_confidence"] = True
        item["low_confidence_reason"] = reason
        item["low_confidence_docs"] = sorted(bad)
        item["low_confidence_states"] = hit_states
        if not item.get("reason"):
            item["reason"] = reason
        out.append(item)
    return out
