# -*- coding: utf-8 -*-
"""自然语言判据 → 保守 TypedRule AST；解析文本 → TypedFact。

只支持明确可识别的数值比较（可选 AND），不猜测自由文本语义。
默认不接入；由 RULEPROOF_TYPED_POINTS=1 显式开启。
"""
from __future__ import annotations
import re
from ..engine import typed_semantics as ts

_UNIT = r"(℃|°C|°F|g|kg|mg|min|分钟|s|秒)"
_OPS = {
    ">=": "gte", "≥": "gte", "不得低于": "gte", "不低于": "gte", "不少于": "gte", "不得少于": "gte",
    "<=": "lte", "≤": "lte", "不得超过": "lte", "不超过": "lte", "不得高于": "lte",
    ">": "gt", "高于": "gt", "<": "lt", "低于": "lt", "=": "eq", "等于": "eq",
}
# 指标名：中文/英文、允许“保温”匹配“保温时间”
_PAT = re.compile(r"([\u4e00-\u9fa5A-Za-z][\u4e00-\u9fa5A-Za-z0-9_]{1,20})\s*"
                  r"(>=|<=|≥|≤|>|<|=|不得低于|不低于|不少于|不得少于|不得超过|不超过|不得高于|高于|低于|等于)\s*"
                  r"([0-9]+(?:\.[0-9]+)?)\s*" + _UNIT)


def _clause(part: str):
    m = _PAT.search(part or "")
    if not m:
        return None
    metric, op, val, unit = m.groups()
    # 去掉“均须/必须/应”等残留在指标名尾部
    metric = re.sub(r"(均须|必须|应当|应|须|实测|记录|本页|每个|各执行批次)$", "", metric).strip()
    if not metric or len(metric) < 2:
        return None
    return {"op": _OPS.get(op, "eq"),
            "left": {"metric": metric, "unit": unit},
            "value": float(val)}


def _compliance(text: str) -> bool:
    """判据是“必须满足”的合规条件（须/应/不得/不低/不超），需取反成违规条件。

    R11 这种“<85 且 <10 时记不满足”本身已是违规条件，不能取反。
    """
    if re.search(r"(记不满足|视为不满足|属于不满足|即不满足)", text or ""):
        return False
    return bool(re.search(r"(须|应|必须|不得|不低于|不超过|不少于|不得少于|不得高于)", text or ""))


def compile_criterion(criterion: str):
    """只编译 1 个或 AND 连接的多个明确数值比较；否则 None。"""
    text = str(criterion or "")
    if not text:
        return None
    parts = re.split(r"且|并且|同时|以及", text)
    nodes = []
    for p in parts:
        n = _clause(p)
        if not n:
            return None
        nodes.append(n)
    if not nodes:
        return None
    expr = nodes[0] if len(nodes) == 1 else {"op": "and", "args": nodes}
    # “必须/不得/不低于”是合规条件；确定性 AST 表达违规条件，需要取反。
    if _compliance(text):
        return {"op": "not", "arg": expr}
    return expr


def facts_from_text(text: str) -> list:
    """deepparse 事实 → TypedFact；只保留数值；批次先记为单个文档批次。"""
    from ..engine import facts as fw
    out = []
    for f in fw.extract(text or ""):
        v = f.get("value")
        try:
            num = float(str(v).replace(",", ""))
        except Exception:
            continue
        metric = str(f.get("metric") or f.get("object") or "")
        unit = str(f.get("unit") or "")
        if not metric or not unit:
            continue
        out.append(ts.TypedFact(subject=str(f.get("object") or metric), metric=metric,
                                value=num, unit=unit, batch_id="doc",
                                row_id=str(f.get("anchor") or ""), status="present",
                                source="deepparse"))
    return out


def match_facts(ast: dict, facts: list) -> list:
    """把判据指标与事实指标按包含关系对齐（保温 ↔ 保温时间）。"""
    if not isinstance(ast, dict):
        return facts
    if ast.get("op") == "not":
        return match_facts(ast.get("arg") or {}, facts)
    if ast.get("op") in ("and", "or"):
        out = list(facts)
        for a in ast.get("args") or []:
            out = match_facts(a, out)
        return out
    left = ast.get("left") if isinstance(ast.get("left"), dict) else ast
    metric = str(left.get("metric") or ast.get("metric") or "")
    if not metric:
        return facts
    out = []
    for f in facts:
        fm = str(getattr(f, "metric", "") or "")
        if fm == metric or metric in fm or fm in metric:
            c = ts.TypedFact(subject=f.subject, metric=metric, value=f.value, unit=f.unit,
                             dimension=f.dimension, batch_id=f.batch_id, row_id=f.row_id,
                             span=f.span, status=f.status, source=f.source)
            out.append(c)
        else:
            out.append(f)
    return out


