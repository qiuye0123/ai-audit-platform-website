"""类型化标识与信任边界：rule_id→rule_code、上传路径白名单。"""
from __future__ import annotations
import os

from .. import db
from .. import repositories as R


def resolve_rule_code(value: str) -> str:
    """规则参数/路由统一只接受 rule_code；兼容 rule_id 时解析成 code。

    找不到返回空串，调用方必须返回 404，不能把输入当 code 写入。
    """
    v = str(value or "").strip()
    if not v:
        return ""
    try:
        r = R.rules.get(v)
        if r:
            return str(r.get("code") or "")
        rows = R.rules.list("code=?", (v,))
        if rows:
            return str(rows[0].get("code") or "")
    except Exception:
        return ""
    return ""


def upload_root() -> str:
    return os.path.realpath(os.path.join(os.path.dirname(str(db.DB_PATH)), "uploads"))


def is_uploaded_path(path: str, root: str | None = None) -> bool:
    """HTTP 审核只允许 uploads 目录内的真实文件，拒绝 .. 与符号链接越界。"""
    try:
        root = os.path.realpath(root or upload_root())
        p = os.path.realpath(str(path or ""))
        return bool(p) and p.startswith(root + os.sep) and os.path.isfile(p)
    except Exception:
        return False
