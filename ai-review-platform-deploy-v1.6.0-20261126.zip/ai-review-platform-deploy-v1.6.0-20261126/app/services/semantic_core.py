# -*- coding: utf-8 -*-
"""确定性语义闭环服务（P0/P1）。

本模块把已有的三块能力接成一条可审计的闭环：

    文档/解析产物
      -> TypedFact（事实层，保留 batch/row/unit/quote/status）
      -> TypedRuleIR（规则层，优先 criterion_ast，其次保守编译器）
      -> 三值执行（true/false/unknown）
      -> 结构化根因（unit/conflict/missing/logic/evidence/model）
      -> 同案例重审（保留旧 run/finding，创建新 run，返回 old/new/diff）

边界
----
- 纯服务层：不新增表、不改默认审核路径、不调用模型。
- ``reaudit_same_case`` 是显式入口；默认审核链完全不受影响。
- 不根据期望答案反推状态；结论只来自事实与规则 AST 的三值执行。
- 冲突/缺失不静默：``build_typed_facts`` 原样保留 status，
  ``inspect_facts`` 显式给出同批次多值、缺值、单位问题。
"""
from __future__ import annotations

import copy
import json
import logging
import os
import re
from contextlib import contextmanager
from typing import Any, Iterable, Mapping

from .. import db
from .. import repositories as R
from ..engine import typed_semantics as ts
from . import pstates
from . import typed_points as conservative


_LOG = logging.getLogger(__name__)

ROOT_CAUSE_CATEGORIES = ("unit", "conflict", "missing", "logic", "evidence", "model")
AUDIT_STATES = ("pass", "fail", "insufficient", "unknown", "na")
_STATE_ALIASES = {
    "true": "fail", "false": "pass", "满足": "pass", "不满足": "fail",
    "不适用": "na", "证据不足": "insufficient", "无法判断": "unknown",
    "failed": "insufficient", "执行失败": "insufficient", "blocked": "insufficient",
}


def _normalize_state(value: Any) -> str:
    key = str(value or "unknown").strip()
    key = _STATE_ALIASES.get(key, key)
    return key if key in AUDIT_STATES else "unknown"

# 保守编译器可能把“应/须/均须”等情态词并入指标名；这里只做可证明安全的清理。
_MODAL_SUFFIX = re.compile(r"(?:各执行批次|均须|必须|应当|实测|记录|本页|每个|应|须)$")
_BATCH_RE = re.compile(
    r"(?:生产批号|产品批号|批号|批次号|批次)\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9._/\-]{1,40})")
_TEXT_KINDS = {"date", "version", "code", "placeholder", "compare", "range"}
# “≥85℃”“5~10℃”是判据/限值表达，不是实测事实；放进数值比较会把整组拖成
# non_numeric。事实层不收集它们（判据应由规则 AST 表达）。
_IGNORED_FACT_KINDS = {"compare", "range"}
_THRESHOLD_OP = r"(?:≥|≤|>|<|不小于|不大于|不低于|不高于|不得超过|不得低于)"
_NUM_RE = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?")


def _is_threshold_value(quote: str, value: Any) -> bool:
    """“≥85℃ / 不低于85℃”里的 85 是判据阈值，不是实测事实。

    只做“运算符紧邻该数值”的判断，避免把同一上下文里后面的实测值误伤。
    """
    text = str(quote or "")
    number = _NUM_RE.search("" if value is None else str(value))
    if not text or not number:
        return False
    raw = number.group(0)
    pattern = _THRESHOLD_OP + r"\s*" + re.escape(raw) + r"(?![0-9.])"
    return bool(re.search(pattern, text))


# ---------------------------------------------------------------------------
# 1. 事实层：parsed / text -> TypedFact[]
# ---------------------------------------------------------------------------
def _mapping(value: Any) -> dict:
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "to_dict"):
        try:
            got = value.to_dict()
            return dict(got) if isinstance(got, Mapping) else {}
        except Exception:  # noqa: BLE001
            return {}
    return {}


def _json_mapping(raw: Any) -> dict:
    if isinstance(raw, Mapping):
        return dict(raw)
    if not isinstance(raw, str) or not raw.strip():
        return {}
    try:
        got = json.loads(raw)
        return dict(got) if isinstance(got, Mapping) else {}
    except Exception:  # noqa: BLE001
        return {}


def _single_batch_values(text: str) -> list:
    out = []
    for match in _BATCH_RE.finditer(text or ""):
        value = match.group(1).strip().rstrip(".,;；。")
        if value and value not in out:
            out.append(value)
    return out


def _locate_span(text: str, quote: str) -> tuple:
    if not quote or not text:
        return ()
    pos = text.find(quote)
    if pos < 0:
        # 抽取器常把上下文截成半句；定位不到就不猜 span。
        return ()
    return (pos, pos + len(quote))


def _span_from_raw(raw: Mapping, text: str) -> tuple:
    span = raw.get("span")
    if isinstance(span, (list, tuple)) and len(span) == 2:
        try:
            return (int(span[0]), int(span[1]))
        except Exception:  # noqa: BLE001
            return ()
    start = raw.get("start")
    if isinstance(start, (int, float)) and not isinstance(start, bool):
        quote = str(raw.get("quote") or raw.get("context") or "")
        return (int(start), int(start) + len(quote))
    return _locate_span(text, str(raw.get("quote") or raw.get("context") or ""))


def _coerce_value(value: Any, kind: str = "") -> Any:
    """数值事实转 float；文本/日期/编号保持原样。bool 不当数值。"""
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        number = ts.to_number(value)
        return number if number is not None else value
    if isinstance(value, str) and str(kind or "").lower() not in _TEXT_KINDS:
        number = ts.to_number(value)
        if number is not None:
            return number
    return value


def _fact_from_raw(raw: Any, *, text: str = "", default_batch: str = "",
                   source: str = "") -> ts.TypedFact | None:
    """把一条 legacy/解析事实转成 TypedFact；保留 status/quote/row/unit。

    返回 None 表示：连指标名都没有且没有值的分隔行、compare/range
    （判据/限值表达），或“≥85℃/不低于85℃”这类阈值里的数字。有指标但
    无值的事实会以 ``missing`` 状态保留，不静默丢弃。
    """
    if isinstance(raw, ts.TypedFact):
        fact = raw
        if not fact.batch_id and default_batch:
            fact = ts.TypedFact.from_dict({**fact.to_dict(), "batch_id": default_batch})
        return fact
    obj = _mapping(raw)
    if not obj:
        return None
    if str(obj.get("kind") or "").strip().lower() in _IGNORED_FACT_KINDS:
        return None
    status = str(obj.get("status") or "present").strip().lower()
    if status == "ambiguous":
        status = "conflict"
    metric = ts.normalize_metric(obj.get("metric") or obj.get("object") or obj.get("kind"))
    value = obj.get("value")
    if not metric and value is None:
        return None
    if not metric:
        metric = ts.normalize_metric(obj.get("kind") or "value")
    batch = str(obj.get("batch_id") or obj.get("batch") or "").strip() or default_batch
    row = str(obj.get("row_id") or obj.get("anchor") or obj.get("cell") or "").strip()
    quote = str(obj.get("quote") or obj.get("context") or "")
    kind = str(obj.get("kind") or "").strip()
    if status == "present" and _is_threshold_value(quote, value):
        return None
    return ts.TypedFact(
        subject=obj.get("subject") or obj.get("object") or metric,
        metric=metric,
        value=_coerce_value(value, kind),
        unit=obj.get("unit") or "",
        dimension=obj.get("dimension") or "",
        batch_id=batch,
        row_id=row,
        status=status,
        span=_span_from_raw(obj, text),
        confidence=obj.get("confidence", 1.0),
        source=obj.get("source") or source or "parsed",
        quote=quote,
    )


def build_typed_facts(parsed: Any = None, text: str = "", default_batch: str = "",
                      source: str = "", use_ontology: bool = True) -> list:
    """从解析产物或文本构造 TypedFact 列表。

    支持：
    - ``parsed`` 为 ``{"doc": {"text": ...}, "facts": [...]}`` / fact 列表 / TypedFact 列表；
    - ``parsed`` 为 str（等同于 ``text``）；
    - 只有文本时走 deepparse 的确定性抽取，不调用模型。

    批次：
    - 单批次文档：自动从“生产批号/批号/批次”识别唯一批次；
    - 多批次且没有逐条 batch：不猜，保持空（组合规则会显式返回 batch_missing）；
    - 调用方可传 ``default_batch`` 表示文档级作用域（不会覆盖逐条 batch）。
    """
    doc_text = str(text or "")
    rows = None
    if isinstance(parsed, str):
        doc_text = parsed
        parsed = None
    if isinstance(parsed, (list, tuple)):
        rows = list(parsed)
    elif isinstance(parsed, Mapping):
        doc_text = doc_text or str((parsed.get("doc") or {}).get("text") or "")
        if "facts" in parsed:
            rows = list(parsed.get("facts") or [])
        elif isinstance(parsed.get("doc"), Mapping) and "facts" in parsed["doc"]:
            rows = list(parsed["doc"].get("facts") or [])
        else:
            # 只有 doc.text、没有 facts 键：按文本抽取，而不是静默返回空事实。
            rows = None
    elif parsed is not None:
        # 未知类型不静默变成“空事实”，交给调用方看到 no_facts。
        _LOG.debug("build_typed_facts 收到未知类型：%s", type(parsed).__name__)

    if not default_batch and doc_text:
        default_batch = ts.single_batch_from_text(doc_text)

    out = []
    if rows is not None:
        for raw in rows:
            fact = _fact_from_raw(raw, text=doc_text, default_batch=default_batch,
                                  source=source or "parsed")
            if fact is not None:
                out.append(fact)
        return _apply_ontology_aliases(out) if use_ontology else out

    # 纯文本：使用确定性抽取；不调用模型。
    from ..engine import facts as facts_engine
    for raw in facts_engine.extract(doc_text):
        fact = _fact_from_raw(raw, text=doc_text, default_batch=default_batch,
                              source=source or "text")
        if fact is not None:
            out.append(fact)
    return _apply_ontology_aliases(out) if use_ontology else out


def _apply_ontology_aliases(facts: list) -> list:
    """用已生效词典/本体同义词归一事实指标；不等同/冲突词不会被 terms 归并。

    只改 metric 名，不改 value/unit/batch/row/quote/status；本体服务不可用时
    保留原事实，绝不让别名查询失败变成空事实。
    """
    if not facts:
        return facts
    try:
        from . import terms as _terms
        pairs = _terms.confirmed_alias_pairs() or {}
    except Exception:
        return facts
    if not pairs:
        return facts
    out = []
    for fact in facts:
        target = pairs.get(fact.metric) or pairs.get(fact.subject)
        if target and target != fact.metric:
            fact = ts.TypedFact.from_dict({**fact.to_dict(), "metric": str(target)})
        out.append(fact)
    return out


def _fact_brief(fact: ts.TypedFact) -> dict:
    return {"metric": fact.metric, "value": fact.value, "unit": fact.unit,
            "batch_id": fact.batch_id, "row_id": fact.row_id, "status": fact.status,
            "quote": fact.quote, "source": fact.source}


def inspect_facts(facts: Iterable) -> dict:
    """显式检查事实缺口：missing / conflict / 单位问题，不静默。"""
    typed = []
    for fact in facts or ():
        if isinstance(fact, ts.TypedFact):
            typed.append(fact)
        else:
            got = _fact_from_raw(fact)
            if got is not None:
                typed.append(got)

    missing, explicit, derived, units = [], [], [], []
    groups = {}
    for fact in typed:
        if fact.status == "missing" or (fact.status == "present" and fact.value is None):
            missing.append(_fact_brief(fact))
            continue
        if fact.status == "conflict":
            explicit.append(_fact_brief(fact))
            continue
        if fact.value is None:
            continue
        groups.setdefault((fact.batch_id, ts.normalize_metric(fact.metric)), []).append(fact)

    for (batch, metric), group in groups.items():
        numbers = []
        for fact in group:
            number = ts.to_number(fact.value)
            if number is not None:
                numbers.append(number)
        unique = []
        for number in numbers:
            if not any(ts.to_number(x) is not None and abs(float(x) - number) < 1e-12
                       for x in unique):
                unique.append(number)
        if len(unique) > 1:
            derived.append({
                "metric": metric, "batch_id": batch,
                "values": unique[:8],
                "rows": [f.row_id or f.batch_id or "" for f in group][:8],
                "quotes": [f.quote for f in group if f.quote][:3],
                "note": "同 batch+metric 多值；规则未声明聚合时执行层返回 conflict/unknown",
            })
        unit_set = {ts.normalize_unit(f.unit) for f in group if f.unit}
        dim_set = {ts.unit_dimension(f.unit) for f in group if f.unit}
        if len(unit_set) > 1:
            units.append({
                "metric": metric, "batch_id": batch, "units": sorted(unit_set),
                "dimensions": sorted(x for x in dim_set if x),
                "rows": [f.row_id or f.batch_id or "" for f in group][:8],
                "kind": "unit_ambiguous" if len(dim_set) <= 1 else "unit_dimension_mismatch",
            })
        elif any(f.unit for f in group) and any(not f.unit for f in group):
            units.append({
                "metric": metric, "batch_id": batch, "units": sorted(unit_set),
                "dimensions": sorted(x for x in dim_set if x),
                "rows": [f.row_id or f.batch_id or "" for f in group][:8],
                "kind": "unit_missing",
            })

    return {
        "total": len(typed),
        "missing": missing,
        "explicit_conflicts": explicit,
        "derived_conflicts": derived,
        "unit_issues": units,
        "batches": sorted({f.batch_id for f in typed if f.batch_id}),
        "rows": sum(1 for f in typed if f.row_id or f.quote or f.span),
        "note": "missing/conflict 是显式状态；derived_conflicts 由同批次多值推导，"
                "是否合法取决于规则是否声明聚合",
    }


# ---------------------------------------------------------------------------
# 2. 规则层：rule/point -> 可执行 TypedRuleIR
# ---------------------------------------------------------------------------
def _coerce_rule(rule: Any) -> dict:
    payload = _mapping(rule)
    if not payload:
        return {}
    slots = payload.get("slots") if isinstance(payload.get("slots"), Mapping) else None
    if slots is None:
        slots = _json_mapping(payload.get("slots_json"))
    if slots:
        payload["_slots"] = dict(slots)
        for key in ("criterion_ast", "typed_rule", "typed_rule_ir", "criterion",
                    "quantifier", "group_by", "on_missing", "on_conflict",
                    "tolerance", "conclusion", "scope", "aliases", "criteria"):
            if payload.get(key) in (None, "", [], {}) and slots.get(key) not in (None, "", [], {}):
                payload[key] = slots[key]
    scope = _json_mapping(payload.get("scope_json"))
    if scope:
        payload["_scope"] = scope
        if payload.get("criterion") in (None, "") and scope.get("criterion"):
            payload["criterion"] = scope["criterion"]
        if payload.get("criterion_ast") in (None, "") and scope.get("criterion_ast"):
            payload["criterion_ast"] = scope["criterion_ast"]
    return payload


def _rule_key(payload: Mapping) -> str:
    for key in ("code", "rule_code", "id", "point_id", "rule_id"):
        value = str((payload or {}).get(key) or "").strip()
        if value:
            return value
    return ""


def _extract_ast(payload: Mapping) -> dict | None:
    for key in ("criterion_ast", "typed_rule", "typed_rule_ir"):
        value = payload.get(key)
        if isinstance(value, str):
            value = _json_mapping(value) if value.strip().startswith("{") else None
        if isinstance(value, Mapping) and value:
            return dict(value)
    # 调用方可以直接传一条 AST（含 expr 或叶子比较）。
    if isinstance(payload.get("expr"), Mapping):
        return dict(payload)
    if payload.get("op") and (payload.get("left") or payload.get("ref") or payload.get("metric")):
        return dict(payload)
    return None


def _extract_criterion(payload: Mapping) -> tuple:
    criterion = payload.get("criterion") or payload.get("requirement")
    if not criterion:
        criteria = payload.get("criteria")
        if isinstance(criteria, str):
            criterion = criteria
        elif isinstance(criteria, (list, tuple)):
            values = [str(x).strip() for x in criteria if str(x).strip()]
            if len(values) == 1:
                criterion = values[0]
            elif len(values) > 1:
                return "", "multiple_criteria_unsupported"
    text = str(criterion or "").strip()
    if not text:
        return "", "no_criterion"
    return text, ""


def _build_ir(ast: Mapping, payload: Mapping) -> dict:
    base = dict(ast or {})
    expr = base.get("expr") if isinstance(base.get("expr"), Mapping) else base
    ir = {"expr": copy.deepcopy(expr)}

    rule_id = str(base.get("id") or _rule_key(payload) or "").strip()
    if rule_id:
        ir["id"] = rule_id

    scope = base.get("scope") if isinstance(base.get("scope"), Mapping) else None
    if scope is None and isinstance(payload.get("scope"), Mapping):
        scope = payload.get("scope")
    if scope is None and isinstance(payload.get("_scope"), Mapping):
        scope = payload.get("_scope")
    if isinstance(scope, Mapping) and scope:
        ir["scope"] = dict(scope)

    for key in ("quantifier", "group_by", "on_missing", "on_conflict",
                "tolerance", "conclusion"):
        if base.get(key) is not None:
            ir[key] = copy.deepcopy(base[key])
        elif payload.get(key) is not None:
            ir[key] = copy.deepcopy(payload[key])
    if "group_by" not in ir and isinstance(scope, Mapping) and scope.get("group_by"):
        ir["group_by"] = scope["group_by"]
    if "quantifier" not in ir and isinstance(scope, Mapping) and scope.get("quantifier"):
        ir["quantifier"] = scope["quantifier"]
    if "conclusion" in ir and not isinstance(ir["conclusion"], Mapping):
        ir["conclusion"] = {}
    return ir


def _clean_metric(metric: Any) -> tuple:
    text = ts.normalize_metric(metric)
    changed = False
    while text:
        new_text = _MODAL_SUFFIX.sub("", text).strip()
        if new_text == text:
            break
        text, changed = new_text, True
    return text, changed


def _sanitize_conservative_ast(ast: Mapping, criterion: str) -> tuple:
    """保守编译器的输出安全清理。

    只做两类处理：
    1. 去掉可证明不会改变语义的情态词尾（“必须/应/须”等）；
    2. 识别编译器把否定词并入指标名/算子的已知歧义，拒绝执行而不是猜。

    返回 ``(ast|None, warnings, reason)``；reason 非空表示不可安全执行。
    """
    if not isinstance(ast, Mapping):
        return None, [], "compiler_output_invalid"
    tree = copy.deepcopy(dict(ast))
    warnings = []
    bad_metric = []

    def walk(node):
        if isinstance(node, list):
            for item in node:
                walk(item)
            return
        if not isinstance(node, Mapping):
            return
        for ref_key in ("left", "ref"):
            ref = node.get(ref_key)
            if isinstance(ref, Mapping) and ref.get("metric"):
                cleaned, changed = _clean_metric(ref["metric"])
                if changed:
                    warnings.append(f"指标名去除情态词尾：{ref['metric']!r} -> {cleaned!r}")
                    ref["metric"] = cleaned
                if not cleaned:
                    bad_metric.append(str(ref.get("metric") or ""))
        if node.get("metric") and not isinstance(node.get("left"), Mapping):
            cleaned, changed = _clean_metric(node["metric"])
            if changed:
                warnings.append(f"指标名去除情态词尾：{node['metric']!r} -> {cleaned!r}")
                node["metric"] = cleaned
            if not cleaned:
                bad_metric.append(str(node.get("metric") or ""))
        for key in ("args",):
            if isinstance(node.get(key), (list, tuple)):
                walk(node[key])
        for key in ("arg", "expr"):
            if isinstance(node.get(key), Mapping):
                walk(node[key])

    walk(tree)
    if bad_metric:
        return None, warnings, "compiler_output_invalid_metric"

    suffixes = [str(_mapping(x).get("metric") or "") for x in _iter_metric_nodes(tree)]
    if any(m.endswith("不") or m.endswith("不得") for m in suffixes):
        return None, warnings, (
            "compiler_output_ambiguous：否定词被并入指标名（如“中心温度不”），"
            "保守编译器无法保证阈值方向，拒绝执行")

    if tree.get("op") == "not":
        inner = tree.get("arg") if isinstance(tree.get("arg"), Mapping) else {}
        inner_op = str(inner.get("op") or "")
        text = str(criterion or "")
        if inner_op in ("lt", "lte") and any(x in text for x in ("不低于", "不得低于", "不少于", "不得少于")):
            return None, warnings, (
                "compiler_output_ambiguous：否定词“不低于/不少于”与算子方向冲突，"
                "保守编译器输出不可信，拒绝执行")
        if inner_op in ("gt", "gte") and any(x in text for x in ("不高于", "不得高于")):
            return None, warnings, (
                "compiler_output_ambiguous：否定词“不高于/不得高于”与算子方向冲突，"
                "保守编译器输出不可信，拒绝执行")
    return tree, warnings, ""


def _iter_metric_nodes(node):
    if isinstance(node, Mapping):
        if node.get("metric") and not isinstance(node.get("left"), Mapping):
            yield node
        if isinstance(node.get("left"), Mapping) and node["left"].get("metric"):
            yield node["left"]
        if isinstance(node.get("ref"), Mapping) and node["ref"].get("metric"):
            yield node["ref"]
        for key in ("args", "arg", "expr"):
            value = node.get(key)
            if isinstance(value, (list, tuple)):
                for item in value:
                    yield from _iter_metric_nodes(item)
            elif isinstance(value, Mapping):
                yield from _iter_metric_nodes(value)


def compile_rule_ir(rule: Any) -> dict:
    """编译规则/点位为可执行 TypedRuleIR。

    返回稳定结构：
    - 成功：``{"ok": True, "source": "criterion_ast"|"conservative_compiler",
      "ir": {...}, "rule_id": ..., "warnings": [...]}``
    - 失败：``{"ok": False, "source": ..., "ir": None,
      "reason_code": "...", "reason": "明确原因", "rule_id": ...}``

    优先使用 ``criterion_ast``；没有 AST 时只使用 ``typed_points.compile_criterion``
    这一既有保守编译器，不猜测自由文本语义。
    """
    payload = _coerce_rule(rule)
    rule_id = _rule_key(payload)
    if not payload:
        return {"ok": False, "source": "none", "ir": None, "rule_id": rule_id,
                "reason_code": "invalid_rule", "reason": "规则必须是对象（dict）"}

    ast = _extract_ast(payload)
    if ast:
        ir = _build_ir(ast, payload)
        try:
            ts.compile_rule(ir)
        except ts.RuleError as exc:
            return {"ok": False, "source": "criterion_ast", "ir": None,
                    "rule_id": rule_id, "reason_code": "invalid_criterion_ast",
                    "reason": f"criterion_ast 结构错误：{exc}"}
        return {"ok": True, "source": "criterion_ast", "ir": ir,
                "rule_id": rule_id, "warnings": []}

    criterion, why = _extract_criterion(payload)
    if why:
        return {"ok": False, "source": "none", "ir": None, "rule_id": rule_id,
                "reason_code": why,
                "reason": ("规则/点位没有可执行判据（criterion）" if why == "no_criterion"
                           else "存在多条判据，保守编译器不支持多判据组合")}
    ast = conservative.compile_criterion(criterion)
    if not ast:
        return {"ok": False, "source": "conservative_compiler", "ir": None,
                "rule_id": rule_id, "reason_code": "criterion_uncompilable",
                "reason": f"保守编译器无法把判据编译为明确数值比较：{criterion[:200]}"}
    ast, warnings, reason = _sanitize_conservative_ast(ast, criterion)
    if reason:
        return {"ok": False, "source": "conservative_compiler", "ir": None,
                "rule_id": rule_id, "reason_code": "compiler_output_ambiguous",
                "reason": reason, "criterion": criterion[:300], "warnings": warnings}
    ir = _build_ir(ast, payload)
    try:
        ts.compile_rule(ir)
    except ts.RuleError as exc:
        return {"ok": False, "source": "conservative_compiler", "ir": None,
                "rule_id": rule_id, "reason_code": "rule_compile_error",
                "reason": f"编译后 AST 仍不可执行：{exc}", "warnings": warnings}
    return {"ok": True, "source": "conservative_compiler", "ir": ir,
            "rule_id": rule_id, "warnings": warnings}


# ---------------------------------------------------------------------------
# 3. 执行层：evaluate_rule
# ---------------------------------------------------------------------------
def _coerce_facts(facts: Iterable) -> list:
    out = []
    for fact in facts or ():
        if isinstance(fact, ts.TypedFact):
            out.append(fact)
        else:
            got = _fact_from_raw(fact)
            if got is not None:
                out.append(got)
    return out


def _iter_ir_refs(node: Any):
    if isinstance(node, Mapping):
        if isinstance(node.get("left"), Mapping) or isinstance(node.get("ref"), Mapping):
            ref = node.get("left") if isinstance(node.get("left"), Mapping) else node.get("ref")
            if ref.get("metric"):
                yield ref
        elif node.get("metric") and node.get("op") not in ("and", "or", "not"):
            yield node
        for key in ("args", "arg", "expr"):
            value = node.get(key)
            if isinstance(value, (list, tuple)):
                for item in value:
                    yield from _iter_ir_refs(item)
            elif isinstance(value, Mapping):
                yield from _iter_ir_refs(value)


def _align_facts(ir: Mapping, facts: Iterable) -> list:
    """把事实指标与规则指标做保守包含对齐（保温 ↔ 保温时长）。

    只做“名称包含”对齐，不改值/单位/批次/证据；为每个事实选最具体的规则指标。
    ``typed_points.match_facts`` 会丢 quote/confidence，这里复制全部字段。
    """
    typed = _coerce_facts(facts)
    refs = []
    for ref in _iter_ir_refs(ir.get("expr")):
        metric = ts.normalize_metric(ref.get("metric"))
        if not metric:
            continue
        aliases = ref.get("aliases") or ()
        if isinstance(aliases, str):
            aliases = [aliases]
        names = [metric] + [ts.normalize_metric(x) for x in aliases if str(x).strip()]
        refs.append((metric, names))

    out = []
    for fact in typed:
        fact_names = {ts.normalize_metric(fact.metric), ts.normalize_metric(fact.subject)}
        fact_names.discard("")
        best = None
        for metric, names in refs:
            if fact_names & set(names):
                best = metric
                break
            if any((name and (name in fname or fname in name))
                   for name in names for fname in fact_names if len(name) >= 2 and len(fname) >= 2):
                if best is None or len(metric) > len(best):
                    best = metric
        if best and best != fact.metric:
            fact = ts.TypedFact.from_dict({**fact.to_dict(), "metric": best})
        out.append(fact)
    return out


def _reason_text(result: ts.EvalResult) -> str:
    if result.detail:
        return f"{result.reason}: {result.detail}"
    return str(result.reason or "")


def evaluate_rule(rule: Any, parsed: Any = None, text: str = "",
                  default_batch: str = "", facts: Iterable | None = None) -> dict:
    """执行规则：``parsed`` 可为文本/解析产物/事实列表；也可直接传 ``facts``。

    返回 ``{state, reason, evidence, ir, ...}``。``state`` 使用平台五态口径
    （pass/fail/insufficient），同时用 ``tri`` 保留原始三值 true/false/unknown。
    """
    info = compile_rule_ir(rule)
    if not info.get("ok"):
        return {
            "ok": False,
            "rule_id": info.get("rule_id") or "",
            "state": "insufficient",
            "verdict": "insufficient",
            "tri": "unknown",
            "reason": info.get("reason") or "规则不可编译",
            "reason_code": info.get("reason_code") or "not_compilable",
            "detail": "",
            "evidence": [],
            "ir": None,
            "ir_source": info.get("source") or "none",
            "facts_count": 0,
            "fact_issues": {},
            "compile": {k: info.get(k) for k in ("source", "reason_code", "reason", "warnings")},
        }

    ir = info["ir"]
    if facts is None:
        facts = build_typed_facts(parsed, text=text, default_batch=default_batch,
                                  source="evaluate")
    typed = _coerce_facts(facts)
    aligned = _align_facts(ir, typed)
    result = ts.evaluate_safe(ir, aligned)
    evidence = [dict(item) for item in (result.evidence or ()) if isinstance(item, Mapping)]
    issues = inspect_facts(typed)
    return {
        "ok": True,
        "rule_id": info.get("rule_id") or result.rule_id or "",
        "state": result.verdict,
        "verdict": result.verdict,
        "tri": result.state.value,
        "reason": _reason_text(result),
        "reason_code": str(result.reason or ""),
        "detail": str(result.detail or ""),
        "evidence": evidence,
        "ir": ir,
        "ir_source": info.get("source") or "",
        "facts_count": len(typed),
        "fact_issues": issues,
        "compile": {"source": info.get("source"), "warnings": info.get("warnings") or []},
    }


# ---------------------------------------------------------------------------
# 4. 根因：结构化 unit/conflict/missing/logic/evidence/model
# ---------------------------------------------------------------------------
_CAUSE_PATTERNS = (
    (("unit_dimension_mismatch", "unit_conversion_failed", "unit_missing",
      "unknown_unit", "unit_ambiguous", "unit_mismatch"), "unit", "unit"),
    (("conflict_multi_value", "conflict_policy", "conflict"), "conflict", "conflict"),
    (("model_unavailable", "model_timeout", "model_empty_result",
      "model_no_conclusion", "agent-judge"), "model", "model"),
    (("quote_missing", "quote_not_verified", "evidence_missing",
      "evidence_gap", "evidence"), "evidence", "evidence"),
    (("no_facts", "batch_missing", "row_missing", "missing_policy",
      "empty_scope", "non_numeric", "missing"), "missing", "missing"),
    (("invalid_rule", "invalid_node", "invalid_logical", "execution_error",
      "executor_error", "logic", "and_", "or_", "not", "compare_"),
     "logic", "logic"),
)
_CAUSE_KEYWORDS = (
    (("量纲", "单位不匹配", "单位缺失", "单位未注册", "单位错误", "质量单位", "g 当温度",
      "℃ 与 g", "换算失败"), "unit", "unit_keyword"),
    (("冲突", "矛盾", "多值", "多个读数", "同批次多个", "自选一条"), "conflict", "conflict_keyword"),
    (("模型不可用", "模型超时", "未配置模型", "模型未返回", "agent-judge", "llm 不可用"),
     "model", "model_keyword"),
    (("引文", "证据不足", "证据缺失", "找不到原文", "quote_not_verified"), "evidence", "evidence_keyword"),
    (("缺失", "缺值", "缺少", "未找到", "无数据", "为空", "no_facts"), "missing", "missing_keyword"),
    (("单低", "双低", "组合", "逻辑", "条件不成立", "AND", "且"), "logic", "logic_keyword"),
)
_CAUSE_SUMMARY = {
    "unit": "单位/量纲不匹配，事实不能直接与规则阈值比较",
    "conflict": "同批次同指标多值冲突，需要人工裁决或补证",
    "missing": "关键事实缺失或未对齐，不能当作 0/false",
    "logic": "规则条件/逻辑组合导致当前结论",
    "evidence": "证据不足或引文未通过回查，不能据此下结论",
    "model": "模型不可用/超时/未返回可核验结论",
}
_CAUSE_LAYER = {
    "unit": "fact", "conflict": "fact", "missing": "fact",
    "logic": "rule", "evidence": "evidence", "model": "model",
}
_CAUSE_ACTION = {
    "unit": "统一单位/量纲或补录正确单位后重审",
    "conflict": "请人工裁决同批次多值或补充唯一读数后重审",
    "missing": "补充缺失事实，或确认该指标不适用",
    "logic": "检查规则 AST/量纲/组合语义，必要时重建 criterion_ast",
    "evidence": "补充可逐字回查的证据后重审",
    "model": "检查模型配置/可用性后重试；模型不可用时保持证据不足",
}


def _classify_code(reason: Any) -> dict | None:
    text = str(reason or "").strip().lower()
    if not text:
        return None
    for patterns, category, base in _CAUSE_PATTERNS:
        for pattern in patterns:
            if pattern in text:
                return {"category": category, "code": pattern, "base": base,
                        "weight": 0.95, "source": "reason_code",
                        "text": str(reason or "")[:500]}
    return None


def _classify_text(text: Any, source: str) -> list:
    raw = str(text or "").strip()
    if not raw:
        return []
    out = []
    for keywords, category, code in _CAUSE_KEYWORDS:
        for keyword in keywords:
            if keyword and keyword in raw:
                out.append({"category": category, "code": code, "weight": 0.55,
                            "source": source, "text": raw[:500], "keyword": keyword})
                break
    return out


def _finding_evidence(finding_id: str) -> list:
    out = []
    if not finding_id:
        return out
    try:
        for ev in R.evidences.list("finding_id=?", (finding_id,)):
            anchor = {}
            try:
                anchor = R.anchors.get(ev.get("anchor_id") or "") or {}
            except Exception:  # noqa: BLE001
                anchor = {}
            out.append({
                "kind": "finding_evidence",
                "excerpt": str(ev.get("excerpt") or anchor.get("quote") or "")[:500],
                "locator": anchor.get("locator") or "",
                "sheet": anchor.get("sheet") or "",
                "row": anchor.get("row"),
                "col": anchor.get("col") or "",
            })
    except Exception:  # noqa: BLE001
        _LOG.debug("根因读取 finding 证据失败", exc_info=True)
    return out


def _raw_run(run_id: str) -> dict:
    if not run_id:
        return {}
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM audit_run WHERE id=?", (run_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:  # noqa: BLE001
        return {}


def _raw_latest_run(case_id: str) -> dict:
    if not case_id:
        return {}
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM audit_run WHERE case_id=? "
                            "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:  # noqa: BLE001
        return {}


def _point_states_for_finding(finding: Mapping) -> list:
    """读取同批次 point_state 的 reason；根因优先用显式 reason code。"""
    point_id = str((finding or {}).get("point_id") or (finding or {}).get("rule_id") or "")
    if not point_id:
        return []
    run = _raw_run(str((finding or {}).get("run_id") or "")) or \
        _raw_latest_run(str((finding or {}).get("case_id") or ""))
    batches = [x for x in str(run.get("batch_ids") or "").split(",") if x]
    if not batches:
        return []
    placeholders = ",".join("?" for _ in batches)
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT * FROM point_state WHERE batch_id IN (" + placeholders + ") "
                "AND point_id=? ORDER BY rowid DESC LIMIT 20",
                (*batches, point_id)).fetchall()
        return [dict(row) for row in rows]
    except Exception:  # noqa: BLE001
        return []


def _target_kind(target: Any) -> str:
    if isinstance(target, str):
        return "finding_id"
    data = _mapping(target)
    if not data:
        return "unknown"
    if "d4_json" in data or "d5_json" in data:
        return "manifest_result"
    if "reason_code" in data or ("ir" in data and "state" in data and "evidence" in data):
        return "evaluation"
    if "point_id" in data and "reason" in data and "case_id" not in data:
        return "point_state"
    if ("state" in data and "reason" in data
            and any(key in data for key in ("evidence", "facts_count", "tri"))):
        return "evaluation"
    return "finding"


def _target_texts(target: Mapping, kind: str) -> list:
    if kind == "evaluation":
        return [
            ("reason_code", target.get("reason_code") or target.get("reason")),
            ("reason", target.get("reason")),
            ("detail", target.get("detail")),
        ]
    if kind == "point_state":
        return [("point_state.reason", target.get("reason")),
                ("point_state.state", target.get("state"))]
    if kind == "manifest_result":
        d5 = _json_mapping(target.get("d5_json"))
        d4 = _json_mapping(target.get("d4_json"))
        out = [("d5.reason", d5.get("reason") or d5.get("status")),
               ("result.conclusion", target.get("conclusion"))]
        for sub in (d4.get("subs") or []):
            if isinstance(sub, Mapping):
                out.append(("sub.detail", sub.get("detail") or sub.get("status")))
        return out
    return [
        ("finding.summary", target.get("summary")),
        ("finding.title", target.get("title")),
        ("finding.rationale", target.get("rationale")),
        ("finding.state", target.get("state")),
        ("finding.engine", target.get("engine")),
        ("finding.issue_type", target.get("issue_type") or target.get("description")),
    ]


def root_cause(target: Any, *, case_id: str = "", run_id: str = "",
               facts: Iterable | None = None) -> dict:
    """把 finding / point_state / manifest_result / evaluate_rule 结果转为结构化根因。

    返回至少包含：``category``（unit/conflict/missing/logic/evidence/model）、
    ``code``、``layer``、``signals``、``evidence``、``summary``、``recommended_action``。
    不只返回一句自然语言。
    """
    kind = _target_kind(target)
    data = _mapping(target)
    if kind == "finding_id":
        loaded = R.findings.get(str(target)) or {}
        if not loaded:
            return {"ok": False, "code": "not_found", "category": None,
                    "reason": "发现不存在", "signals": [], "evidence": []}
        data, kind = loaded, "finding"

    if not data:
        return {"ok": False, "code": "invalid_target", "category": None,
                "reason": "根因输入必须是 finding/结果对象或 finding id",
                "signals": [], "evidence": []}

    cid = str(case_id or data.get("case_id") or "")
    rid = str(run_id or data.get("run_id") or "")
    signals = []
    evidence = []
    point_states = []

    if kind == "finding":
        point_states = _point_states_for_finding(data)
        for row in point_states:
            found = _classify_code(row.get("reason"))
            if found:
                found["source"] = "point_state.reason"
                found["text"] = str(row.get("reason") or "")[:500]
                signals.append(found)
            quote = str(row.get("quote") or "")
            if quote:
                evidence.append({"kind": "point_state", "excerpt": quote[:500],
                                 "state": row.get("state") or "",
                                 "batch_id": row.get("batch_id") or "",
                                 "point_id": row.get("point_id") or ""})
        evidence.extend(_finding_evidence(str(data.get("id") or "")))
        texts = _target_texts(data, kind)
    elif kind == "manifest_result":
        texts = _target_texts(data, kind)
        d5 = _json_mapping(data.get("d5_json"))
        if d5:
            evidence.append({"kind": "d5", "status": d5.get("status") or "",
                             "reason": d5.get("reason") or ""})
    elif kind == "point_state":
        texts = _target_texts(data, kind)
        quote = str(data.get("quote") or "")
        if quote:
            evidence.append({"kind": "point_state", "excerpt": quote[:500],
                             "state": data.get("state") or "",
                             "batch_id": data.get("batch_id") or ""})
    else:
        texts = _target_texts(data, kind)
        for item in data.get("evidence") or ():
            if isinstance(item, Mapping):
                evidence.append(dict(item))

    for source, value in texts:
        found = _classify_code(value)
        if found:
            found["source"] = source
            found["text"] = str(value or "")[:500]
            signals.append(found)
        for item in _classify_text(value, source):
            signals.append(item)

    if facts:
        issues = inspect_facts(facts)
        for item in issues.get("explicit_conflicts") or []:
            signals.append({"category": "conflict", "code": "explicit_conflict",
                            "weight": 0.9, "source": "facts",
                            "text": f"{item.get('metric')} batch={item.get('batch_id')}",
                            "fact": item})
        for item in issues.get("derived_conflicts") or []:
            signals.append({"category": "conflict", "code": "conflict_multi_value",
                            "weight": 0.85, "source": "facts",
                            "text": f"{item.get('metric')} 多值 {item.get('values')}",
                            "fact": item})
        for item in issues.get("missing") or []:
            signals.append({"category": "missing", "code": "missing",
                            "weight": 0.9, "source": "facts",
                            "text": f"{item.get('metric')} batch={item.get('batch_id')}",
                            "fact": item})
        for item in issues.get("unit_issues") or []:
            signals.append({"category": "unit", "code": item.get("kind") or "unit",
                            "weight": 0.85, "source": "facts",
                            "text": f"{item.get('metric')} units={item.get('units')}",
                            "fact": item})

    # 去重 + 选主因：显式 reason code 优先，其次关键词；同类保留最高权重。
    best = {}
    for sig in signals:
        category = sig.get("category")
        if category not in ROOT_CAUSE_CATEGORIES:
            continue
        current = best.get(category)
        if current is None or float(sig.get("weight") or 0) > float(current.get("weight") or 0):
            best[category] = sig
    ordered = sorted(best.values(), key=lambda x: (-float(x.get("weight") or 0),
                                                   ROOT_CAUSE_CATEGORIES.index(x["category"])))
    if ordered:
        primary = dict(ordered[0])
        primary["code"] = primary.get("code") or primary["category"]
        category = primary["category"]
        confidence = max(0.1, min(0.99, float(primary.get("weight") or 0.5)))
        layer = _CAUSE_LAYER.get(category, "unknown")
        if category == "logic" and str(primary.get("code") or "").startswith("execution"):
            layer = "execution"
    else:
        category = "logic"
        primary = {"category": "logic", "code": "unclassified", "weight": 0.1,
                   "source": "fallback", "text": "没有可识别的根因信号"}
        confidence = 0.1
        layer = "unknown"

    state = str(data.get("state") or data.get("status") or "")
    return {
        "ok": True,
        "target": kind,
        "category": category,
        "code": str(primary.get("code") or category),
        "layer": layer,
        "confidence": confidence,
        "summary": _CAUSE_SUMMARY.get(category, "未分类根因"),
        "detail": str(primary.get("text") or "")[:500],
        "recommended_action": _CAUSE_ACTION.get(category, "人工复核"),
        "needs_review": bool(category in ("unit", "conflict", "evidence", "model")
                             or state in ("insufficient", "unknown")),
        "state": state,
        "case_id": cid,
        "run_id": rid,
        "finding_id": str(data.get("id") or "") if kind == "finding" else "",
        "rule_id": str(data.get("rule_id") or data.get("point_id") or ""),
        "point_id": str(data.get("point_id") or ""),
        "signals": ordered,
        "evidence": evidence[:20],
        "point_states": point_states[:10],
        "source": "semantic_core.root_cause",
    }


# ---------------------------------------------------------------------------
# 5. 同案例重审：保留旧 run/finding，新建 run，返回 old/new/diff
# ---------------------------------------------------------------------------
def _raw_case(case_id: str) -> dict:
    if not case_id:
        return {}
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM audit_case WHERE id=?", (case_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:  # noqa: BLE001
        return {}


def _raw_case_documents(case_id: str) -> list:
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT d.* FROM document d JOIN case_document cd ON cd.document_id=d.id "
                "WHERE cd.case_id=? ORDER BY d.rowid", (case_id,)).fetchall()
        return [dict(row) for row in rows]
    except Exception:  # noqa: BLE001
        return []


def _raw_runs(case_id: str) -> list:
    try:
        with db.session() as c:
            rows = c.execute("SELECT * FROM audit_run WHERE case_id=? "
                             "ORDER BY created_at DESC, rowid DESC", (case_id,)).fetchall()
        return [dict(row) for row in rows]
    except Exception:  # noqa: BLE001
        return []


def _raw_findings(case_id: str, run_id: str = "") -> list:
    try:
        with db.session() as c:
            if run_id:
                rows = c.execute("SELECT * FROM finding WHERE case_id=? AND run_id=? "
                                 "ORDER BY rowid", (case_id, run_id)).fetchall()
            else:
                rows = c.execute("SELECT * FROM finding WHERE case_id=? ORDER BY rowid",
                                 (case_id,)).fetchall()
        return [dict(row) for row in rows]
    except Exception:  # noqa: BLE001
        return []


def _raw_finding(finding_id: str) -> dict:
    if not finding_id:
        return {}
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM finding WHERE id=?", (finding_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:  # noqa: BLE001
        return {}


def _point_state_snapshot(batches: Iterable[str]) -> list:
    out = []
    for batch in batches or ():
        if not batch:
            continue
        try:
            with db.session() as c:
                rows = c.execute("SELECT * FROM point_state WHERE batch_id=? ORDER BY rowid",
                                 (batch,)).fetchall()
            out.extend(dict(row) for row in rows)
        except Exception:  # noqa: BLE001
            _LOG.debug("重审读取 point_state 失败 batch=%s", batch, exc_info=True)
    return out


def _snapshot(run: Mapping, findings: Iterable[Mapping], point_states: Iterable[Mapping],
              batches: Iterable[str]) -> dict:
    fs = list(findings or ())
    sev = {"critical": 0, "warning": 0, "info": 0}
    for finding in fs:
        key = str(finding.get("severity") or "warning")
        sev[key] = sev.get(key, 0) + 1
    states = {state: 0 for state in AUDIT_STATES}
    for row in point_states or ():
        st = _normalize_state(row.get("state"))
        states[st] = states.get(st, 0) + 1
    return {
        "run_id": str(run.get("id") or ""),
        "created_at": str(run.get("created_at") or ""),
        "batch_ids": [x for x in str(run.get("batch_ids") or "").split(",") if x]
                     if run else [x for x in (batches or ()) if x],
        "total_findings": len(fs),
        "severity": sev,
        "states": states,
        "findings": [{
            "id": f.get("id"), "rule_id": f.get("rule_id"), "title": f.get("title"),
            "severity": f.get("severity"), "state": _normalize_state(f.get("state")),
            "status": f.get("status"), "run_id": f.get("run_id"),
            "summary": f.get("summary"), "engine": f.get("engine"),
        } for f in fs],
        "point_states": [{
            "point_id": row.get("point_id"), "state": _normalize_state(row.get("state")),
            "reason": row.get("reason"), "quote": row.get("quote"),
            "file_id": row.get("file_id"),
        } for row in (point_states or ())],
    }


def _state_map(snapshot: Mapping) -> dict:
    out = {}
    for row in snapshot.get("point_states") or ():
        pid = str(row.get("point_id") or "")
        if pid and pid not in out:
            out[pid] = _normalize_state(row.get("state"))
    for finding in snapshot.get("findings") or ():
        rid = str(finding.get("rule_id") or "")
        if rid and rid not in out:
            out[rid] = _normalize_state(finding.get("state") or "fail")
    return out


def _state_reason_map(snapshot: Mapping) -> dict:
    out = {}
    for row in snapshot.get("point_states") or ():
        pid = str(row.get("point_id") or "")
        if pid and pid not in out:
            out[pid] = str(row.get("reason") or "")
    for finding in snapshot.get("findings") or ():
        rid = str(finding.get("rule_id") or "")
        if rid and rid not in out:
            out[rid] = str(finding.get("summary") or "")
    return out


def _all_case_findings(case_id: str) -> list:
    """旧 findings（所有 run）用于保留快照；不按当前 run 过滤。"""
    return _raw_findings(case_id)


def _docs_batch_defaults(text: str, doc_id: str) -> tuple:
    values = _single_batch_values(text)
    if len(values) == 1:
        return values[0], ""
    if not values:
        # 单文档没有批号：用文档级作用域，而不是猜一个真实批号。
        return f"doc:{doc_id or 'unknown'}", "document_scope_no_batch"
    return "", "multi_batch_scope_unresolved"


def _parse_case_documents(docs: list) -> tuple:
    from ..engine import deepparse
    facts, documents, errors = [], [], []
    for doc in docs or ():
        doc_id = str(doc.get("id") or "")
        path = str(doc.get("path") or "")
        item = {"document_id": doc_id, "filename": doc.get("filename") or "", "path": path}
        if not path:
            item["error"] = "文件没有落盘路径"
            errors.append(item)
            continue
        # 先只解析路径：解析失败必须显式进入 errors，不伪装成“无问题”。
        try:
            parsed = deepparse.parse_and_extract(path)
        except Exception as exc:  # noqa: BLE001
            item["error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
            errors.append(item)
            continue
        text = str((parsed.get("doc") or {}).get("text") or "")
        raw_facts = parsed.get("facts") or []
        if not text.strip() and not raw_facts:
            item["error"] = "未解析到文本或事实（不创建重审运行来伪装证据不足）"
            errors.append(item)
            continue
        batch, note = _docs_batch_defaults(text, doc_id)
        item.update({"chars": len(text), "batch_scope": batch,
                     "batch_note": note, "fact_count": len(raw_facts)})
        documents.append(item)
        facts.extend(build_typed_facts(parsed, text=text, default_batch=batch,
                                      source=f"reaudit:{doc_id}"))
    return facts, documents, errors


def _case_context(case: Mapping):
    """临时把 Repository 读作用域切到项目所属租户/空间，退出恢复。"""
    from . import ctx as _ctx
    # L98 P1：单次快照/恢复（旧写法逐字段回填，新增字段容易漏；restore 六字段原子还原）
    prev = _ctx.snapshot()

    @contextmanager
    def _scope():
        # 老数据可能没有隔离键：回落到平台默认作用域，避免重审读到其它租户规则。
        _ctx.set_context(str(case.get("tenant_id") or "t-default"),
                         str(case.get("workspace_id") or "ws-default"))
        if prev.get("system"):
            _ctx.set_system(True)
        try:
            yield
        finally:
            _ctx.restore(prev)

    return _scope()


def _rule_slots(rule: Mapping) -> dict:
    slots = _json_mapping((rule or {}).get("slots_json"))
    if not slots and isinstance((rule or {}).get("slots"), Mapping):
        slots = dict(rule["slots"])
    return slots


def _merge_rule(rule: Mapping) -> dict:
    merged = dict(rule or {})
    slots = _rule_slots(rule)
    for key in ("criterion_ast", "typed_rule", "typed_rule_ir", "criterion",
                "criteria", "quantifier", "group_by", "on_missing", "on_conflict",
                "tolerance", "conclusion", "scope", "aliases"):
        if merged.get(key) in (None, "", [], {}) and slots.get(key) not in (None, "", [], {}):
            merged[key] = slots[key]
    scope = _json_mapping((rule or {}).get("scope_json"))
    if not merged.get("criterion_ast") and scope.get("criterion_ast"):
        merged["criterion_ast"] = scope["criterion_ast"]
    if not merged.get("criterion") and scope.get("criterion"):
        merged["criterion"] = scope["criterion"]
    return merged


def _severity_of(rule: Mapping) -> str:
    from ..severity import from_rclass, normalize
    rclass = str((rule or {}).get("rclass") or "").strip()
    if rclass.upper() in ("R0", "R1", "R2", "R3", "R4", "R5"):
        return from_rclass(rclass)
    return normalize(str((rule or {}).get("severity") or ""), rclass)


def _first_quote(evidence: Iterable[Mapping]) -> str:
    for item in evidence or ():
        if isinstance(item, Mapping):
            quote = str(item.get("quote") or item.get("excerpt") or "").strip()
            if quote:
                return quote
    return ""


def _has_locator(evidence: Iterable[Mapping]) -> bool:
    for item in evidence or ():
        if not isinstance(item, Mapping):
            continue
        if str(item.get("quote") or item.get("excerpt") or "").strip():
            return True
        if str(item.get("row_id") or item.get("row") or item.get("locator") or "").strip():
            return True
        if item.get("span"):
            return True
    return False


def _insert_finding_evidence(finding_id: str, document_id: str, title: str,
                             evidence: Iterable[Mapping]) -> int:
    import hashlib
    count = 0
    for item in evidence or ():
        if not isinstance(item, Mapping) or count >= 5:
            break
        quote = str(item.get("quote") or item.get("excerpt") or "").strip()
        locator = str(item.get("row_id") or item.get("locator") or "").strip()
        if not quote and not locator:
            continue
        anchor_id = db.new_id("anc")
        try:
            R.anchors.insert(
                id=anchor_id, document_id=document_id or "",
                sheet="", row=item.get("row") or "",
                col=item.get("col") or "",
                locator=locator, quote=quote,
                hash=hashlib.sha256(quote.encode("utf-8")).hexdigest()[:16])
            R.evidences.insert(id=db.new_id("evd"), finding_id=finding_id,
                               document_id=document_id or "", anchor_id=anchor_id,
                               excerpt=quote or locator, label=title)
            count += 1
        except Exception:  # noqa: BLE001
            _LOG.debug("重审证据落库失败", exc_info=True)
    return count


# ---------------------------------------------------------------------------
# 定向复审：优先读 manifest 冻结 slots，只跑受影响的 rule/object
# ---------------------------------------------------------------------------
_CONCLUSION_TEXT = {"pass": "满足", "fail": "不满足", "na": "不适用",
                    "insufficient": "证据不足", "unknown": "无法判断"}
_MANIFEST_SCORE = {"满足": "pass", "不满足": "fail", "不适用": "na",
                   "证据不足": "insufficient", "无法判断": "unknown"}


def _json_items(raw) -> list:
    try:
        got = json.loads(raw or "[]")
    except Exception:  # noqa: BLE001
        return []
    return got if isinstance(got, list) else []


# L58 ①：语义重审唯一执行路径开关（默认 1 = 走 manifest_exec.run；=0 回退旧第二执行器）
_REAUDIT_SINGLE_PATH_ENV = "RULEPROOF_SEMANTIC_REAUDIT_SINGLE_PATH"


def _reaudit_single_path_enabled() -> bool:
    raw = str(os.environ.get(_REAUDIT_SINGLE_PATH_ENV, "1") or "").strip().lower()
    return raw not in ("0", "false", "no", "off", "disabled")




def _manifest_item_pairs(case_id: str, manifest_id: str = "",
                         single_manifest: bool = False) -> tuple:
    """读取「复审基准」：manifest 冻结 item + 当前 active 结果（只读）。

    优先级：显式 manifest_id > manifest_active 当前结果 > 最近一次 run 的 manifest
    （与 ``audit_ledger`` 同一 active 口径）。返回 (pairs, manifest_ids)；
    pair = {manifest_id, manifest, item, result}。旧 manifest 没有冻结 slots 的
    item 也会返回，由调用方决定是否回退到 published 口径。

    L58/H09：``single_manifest=True`` 时按 run/manifest 维度收口复审基准——只从
    「最近一次全量审核 manifest」取冻结 item（不把 manifest_active 里跨轮次的结果
    混成一个基准）；当前 active 结果只作为「旧结论」对照，并记录其来源 manifest，
    供审计回答「这次复审的基准是哪一份清单」。
    """
    pairs, mids = [], []
    try:
        with db.session() as c:
            acts = [dict(r) for r in c.execute(
                "SELECT * FROM manifest_active WHERE case_id=? ORDER BY object_id,rule_code",
                (case_id,)).fetchall()]
            wanted = str(manifest_id or "").strip()
            man_cache = {}

            def _manifest(mid):
                if mid not in man_cache:
                    row = c.execute("SELECT * FROM audit_manifest WHERE id=?", (mid,)).fetchone()
                    man_cache[mid] = dict(row) if row else {}
                return man_cache[mid]

            if wanted:
                man = _manifest(wanted)
                if not man or str(man.get("case_id") or "") != str(case_id):
                    return [], []
                items = _json_items(man.get("items_json"))
                res = {}
                for a in acts:
                    mr = c.execute("SELECT * FROM manifest_result WHERE id=?",
                                   (a.get("result_id"),)).fetchone()
                    if mr:
                        mr = dict(mr)
                        res[(str(mr.get("object_id") or ""), str(mr.get("rule_code") or ""))] = mr
                for item in items:
                    key = (str(item.get("object_id") or ""), str(item.get("code") or ""))
                    pairs.append({"manifest_id": wanted, "manifest": man, "item": item,
                                  "result": res.get(key) or {}})
                return pairs, [wanted]
            if single_manifest:
                # L58/H09：复审基准 = 最近一次「全量审核」manifest（source != reaudit）；
                # 只有全量清单时才回落到最近清单（反复定向复审不会把基准越缩越小）。
                row = c.execute(
                    "SELECT id FROM audit_manifest WHERE case_id=? "
                    "AND COALESCE(source,'')!='reaudit' "
                    "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                    (case_id,)).fetchone()
                if not row:
                    row = c.execute(
                        "SELECT id FROM audit_manifest WHERE case_id=? "
                        "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                        (case_id,)).fetchone()
                mid = str((row["id"] if row else "") or "")
                if not mid:
                    return [], []
                man = _manifest(mid)
                items = _json_items(man.get("items_json"))
                active_by_key = {}
                for a in acts:
                    mr = c.execute("SELECT * FROM manifest_result WHERE id=?",
                                   (a.get("result_id"),)).fetchone()
                    if mr:
                        mr = dict(mr)
                        active_by_key[(str(mr.get("object_id") or ""),
                                       str(mr.get("rule_code") or ""))] = mr
                base_results = {}
                for rr in c.execute("SELECT * FROM manifest_result WHERE manifest_id=?",
                                    (mid,)):
                    rr = dict(rr)
                    base_results[(str(rr.get("object_id") or ""),
                                  str(rr.get("rule_code") or ""))] = rr
                for item in items:
                    key = (str(item.get("object_id") or ""), str(item.get("code") or ""))
                    act_res = active_by_key.get(key) or {}
                    base_res = base_results.get(key) or {}
                    pairs.append({
                        "manifest_id": mid, "manifest": man, "item": item,
                        "result": act_res or base_res,
                        "base_result": base_res,
                        "active_result_manifest_id": str(act_res.get("manifest_id") or ""),
                        "base_manifest_single": True,
                    })
                return pairs, [mid] if pairs else []
            if acts:
                for a in acts:
                    mr = c.execute("SELECT * FROM manifest_result WHERE id=?",
                                   (a.get("result_id"),)).fetchone()
                    if not mr:
                        continue
                    mr = dict(mr)
                    mid = str(mr.get("manifest_id") or "")
                    man = _manifest(mid)
                    items = _json_items(man.get("items_json"))
                    item = next((x for x in items
                                 if str(x.get("object_id") or "") == str(mr.get("object_id") or "")
                                 and str(x.get("code") or "") == str(mr.get("rule_code") or "")), None)
                    if item is None:
                        continue
                    pairs.append({"manifest_id": mid, "manifest": man, "item": item,
                                  "result": mr})
                    if mid and mid not in mids:
                        mids.append(mid)
                if pairs:
                    return pairs, mids
            # 旧库：没有 active 指针时回退最近一次 run 的 manifest
            ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                           "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
            mid = (ar["manifest_id"] if ar else "") or ""
            if not mid:
                return [], []
            man = _manifest(mid)
            items = _json_items(man.get("items_json"))
            results = {}
            for row in c.execute("SELECT * FROM manifest_result WHERE manifest_id=?", (mid,)):
                row = dict(row)
                results[(str(row.get("object_id") or ""), str(row.get("rule_code") or ""))] = row
            for item in items:
                key = (str(item.get("object_id") or ""), str(item.get("code") or ""))
                pairs.append({"manifest_id": mid, "manifest": man, "item": item,
                              "result": results.get(key) or {}})
            return pairs, [mid] if pairs else []
    except Exception:  # noqa: BLE001
        _LOG.debug("定向复审读取 manifest 冻结项失败 case=%s", case_id, exc_info=True)
        return [], []


def _frozen_pair_stale(pair: Mapping) -> dict:
    """冻结版本 vs 当前发布版本：不一致（或规则已下线）才是“受影响”。"""
    item = pair.get("item") or {}
    code = str(item.get("code") or "")
    rid = str(item.get("rule_id") or "")
    frozen_ver = str(item.get("version") or "")
    try:
        row = R.rules.get(rid) if rid else None
        if not row:
            row = next((r for r in R.rules.list("code=?", (code,)) if code), None)
    except Exception:  # noqa: BLE001
        row = None
    if not row:
        return {"code": code, "object_id": str(item.get("object_id") or ""),
                "frozen_version": frozen_ver, "current_version": "",
                "reason": "rule_missing", "stale": True}
    cur_ver = ""
    try:
        cur_ver = str((R.rules.published_version(str(row.get("id") or "")) or {}).get("version") or "")
    except Exception:  # noqa: BLE001
        cur_ver = ""
    status = str(row.get("status") or "")
    if status != "published":
        return {"code": code, "object_id": str(item.get("object_id") or ""),
                "frozen_version": frozen_ver, "current_version": cur_ver,
                "current_status": status, "reason": "rule_unpublished", "stale": True}
    if frozen_ver and cur_ver and frozen_ver != cur_ver:
        return {"code": code, "object_id": str(item.get("object_id") or ""),
                "frozen_version": frozen_ver, "current_version": cur_ver,
                "reason": "rule_version_changed", "stale": True}
    return {"code": code, "object_id": str(item.get("object_id") or ""),
            "frozen_version": frozen_ver, "current_version": cur_ver,
            "reason": "", "stale": False}


def _parse_document_bundle(docs: list) -> dict:
    """按对象解析（只解析本次受影响对象）；返回 doc_id -> {text, facts, meta, error}。"""
    from ..engine import deepparse
    out = {}
    for doc in docs or ():
        doc_id = str(doc.get("id") or "")
        path = str(doc.get("path") or "")
        meta = {"document_id": doc_id, "filename": doc.get("filename") or "", "path": path}
        if not path:
            meta["error"] = "文件没有落盘路径"
            out[doc_id] = {"meta": meta, "text": "", "facts": [], "error": meta["error"]}
            continue
        try:
            parsed = deepparse.parse_and_extract(path)
        except Exception as exc:  # noqa: BLE001
            meta["error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
            out[doc_id] = {"meta": meta, "text": "", "facts": [], "error": meta["error"]}
            continue
        text = str((parsed.get("doc") or {}).get("text") or "")
        raw_facts = parsed.get("facts") or []
        if not text.strip() and not raw_facts:
            meta["error"] = "未解析到文本或事实（不创建重审运行来伪装证据不足）"
            out[doc_id] = {"meta": meta, "text": "", "facts": [], "error": meta["error"]}
            continue
        batch, note = _docs_batch_defaults(text, doc_id)
        meta.update({"chars": len(text), "batch_scope": batch, "batch_note": note,
                     "fact_count": len(raw_facts)})
        out[doc_id] = {"meta": meta, "text": text, "error": "",
                       "facts": build_typed_facts(parsed, text=text, default_batch=batch,
                                                  source=f"reaudit:{doc_id}")}
    return out


def _frozen_result_row(new_mid: str, item: dict, result: dict, doc_meta: dict,
                       finding_ids: list) -> dict:
    """把一次冻结项执行结果组装成 manifest_result 行（报告/台账同源结构）。"""
    import hashlib
    obj = str(item.get("object_id") or "")
    code = str(item.get("code") or str(result.get("rule_id") or ""))
    key = f"{obj}|{item.get('rule_id') or code}"
    rid = "mres-" + hashlib.sha1((new_mid + key).encode()).hexdigest()[:12]
    state = str(result.get("state") or "unknown")
    text = str((doc_meta or {}).get("text") or "")
    ev = list(result.get("evidence") or [])
    has_locator = any(str((x or {}).get("quote") or "").strip()
                      or str((x or {}).get("row_id") or (x or {}).get("row") or "").strip()
                      for x in ev)
    d1 = {"status": "applicable", "reason": "清单冻结项（对象已在原 manifest 路由）",
          "scope_kind": (item.get("audit_route") or {}).get("scope_kind") or ""}
    d2 = {"status": "bound", "rule_code": code,
          "version": item.get("version") or "",
          "frozen_snapshot": True,
          "requirement": item.get("requirement") or "",
          "slots_sha": hashlib.sha256(
              json.dumps(item.get("slots") or {}, ensure_ascii=False, sort_keys=True)
              .encode()).hexdigest()[:16]}
    d3 = {"status": "bound" if (text.strip() and (has_locator or state == "pass")) else "insufficient",
          "reason": "bound" if text.strip() else "document_empty",
          "document": (doc_meta or {}).get("filename") or "",
          "required": item.get("evidence_required") or "",
          "chars": len(text), "evidence_scope": ["document"],
          "available_scopes": ["document"] if text.strip() else [],
          "missing_scopes": [] if text.strip() else ["document"]}
    d5 = {"status": state, "reason": str(result.get("reason") or "")[:500],
          "fallback": item.get("on_insufficient") or "abstain",
          "reaudit": True,
          "frozen_rule_version": item.get("version") or "",
          "ir_source": result.get("ir_source") or ""}
    d4 = {"status": state, "subs": [], "reason": str(result.get("reason") or "")[:500],
          "evidence": ev[:5], "tri": result.get("tri") or ""}
    return {"id": rid, "manifest_id": new_mid, "item_key": key, "object_id": obj,
            "rule_id": str(item.get("rule_id") or ""), "rule_code": code,
            "d1_json": json.dumps(d1, ensure_ascii=False),
            "d2_json": json.dumps(d2, ensure_ascii=False),
            "d3_json": json.dumps(d3, ensure_ascii=False),
            "d4_json": json.dumps(d4, ensure_ascii=False),
            "d5_json": json.dumps(d5, ensure_ascii=False),
            "conclusion": _CONCLUSION_TEXT.get(state, "无法判断"),
            "execution": "completed" if state in ("pass", "fail", "na") else "incomplete",
            "updated_at": db.now(), "review_status": "pending",
            "review_reason": "", "reviewer": "", "reviewed_at": "",
            "finding_ids": finding_ids}


def _frozen_finding_payload(case_id: str, item: dict, result: dict, new_run_id: str,
                            result_id: str, doc_meta: dict) -> dict:
    """一次 fail 结论 → finding 行 + 证据行（在收口事务里写入）。"""
    import hashlib
    obj = str(item.get("object_id") or "")
    code = str(item.get("code") or result.get("rule_id") or "")
    sev = _severity_of({"rclass": (item.get("rclass") or ""),
                        "severity": (item.get("severity") or "")})
    title = str(item.get("name") or code or "语义复审")
    ev_rows, anchor_rows = [], []
    for e in list(result.get("evidence") or [])[:5]:
        if not isinstance(e, Mapping):
            continue
        quote = str(e.get("quote") or e.get("excerpt") or "").strip()
        locator = str(e.get("row_id") or e.get("locator") or "").strip()
        if not quote and not locator:
            continue
        aid = db.new_id("anc")
        anchor_rows.append({"id": aid, "document_id": obj, "sheet": "",
                            "row": e.get("row") or "", "col": e.get("col") or "",
                            "locator": locator, "quote": quote,
                            "hash": hashlib.sha256(quote.encode("utf-8")).hexdigest()[:16]})
        ev_rows.append({"id": db.new_id("evd"), "document_id": obj, "anchor_id": aid,
                        "excerpt": quote or locator, "label": title})
    finding_id = db.new_id("fnd")
    return {"row": {
                "id": finding_id, "case_id": case_id, "rule_id": code,
                "rule_version": str(item.get("version") or ""), "severity": sev,
                "certainty": "deterministic", "confidence": 1.0, "state": "fail",
                "status": "pending", "title": title[:200],
                "summary": str(result.get("reason") or "")[:500], "suggestion": "",
                "grade": "", "engine": "semantic_core", "run_id": new_run_id,
                "point_id": code, "object_id": obj,
                "manifest_result_id": result_id, "subrequirement_id": "",
                "tenant_id": "", "workspace_id": ""},
            "evidence": ev_rows, "anchors": anchor_rows}


def _tx_insert_finding(c, row: dict, case: Mapping) -> None:
    c.execute("INSERT INTO finding(id,case_id,rule_id,rule_version,severity,certainty,"
              "confidence,state,status,title,summary,suggestion,grade,engine,run_id,"
              "point_id,object_id,manifest_result_id,subrequirement_id,tenant_id,workspace_id) "
              "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
              (row.get("id"), row.get("case_id"), row.get("rule_id"),
               row.get("rule_version") or "", row.get("severity"), row.get("certainty"),
               row.get("confidence"), row.get("state"), row.get("status"),
               row.get("title"), row.get("summary"), row.get("suggestion") or "",
               row.get("grade") or "", row.get("engine"), row.get("run_id"),
               row.get("point_id") or "", row.get("object_id") or "",
               row.get("manifest_result_id") or "", row.get("subrequirement_id") or "",
               case.get("tenant_id") or "", case.get("workspace_id") or ""))


def _tx_insert_evidence(c, finding_id: str, rows: dict) -> None:
    for a in rows.get("anchors") or []:
        c.execute("INSERT INTO anchor(id,document_id,sheet,row,col,locator,quote,hash) "
                  "VALUES(?,?,?,?,?,?,?,?)",
                  (a.get("id"), a.get("document_id") or "", a.get("sheet") or "",
                   a.get("row"), a.get("col") or "", a.get("locator") or "",
                   a.get("quote") or "", a.get("hash") or ""))
    for e in rows.get("evidence") or []:
        c.execute("INSERT INTO evidence(id,finding_id,document_id,anchor_id,excerpt,label) "
                  "VALUES(?,?,?,?,?,?)",
                  (e.get("id"), finding_id, e.get("document_id") or "",
                   e.get("anchor_id") or "", e.get("excerpt") or "", e.get("label") or ""))


def _tx_insert_point_state(c, rows: list) -> None:
    for r in rows or []:
        c.execute("INSERT INTO point_state(id,batch_id,point_id,state,confidence,created_at,"
                  "reason,quote,title,file_id) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (db.new_id("ps"), r.get("batch") or "", r.get("point_id") or "",
                   r.get("state") or "unknown", r.get("confidence"), db.now(),
                   str(r.get("reason") or "")[:300], str(r.get("quote") or "")[:200],
                   str(r.get("title") or "")[:60], str(r.get("file_id") or "")))


def _select_reaudit_scope(frozen: list, base_mids: list, requested: list,
                          requested_objects: list, mode: str,
                          manifest_scope: str = "legacy_active_union") -> dict:
    """定向复审范围选择（唯一实现，旧第二执行器与 L58 单路径共用）。

    与既有契约逐字段一致：显式 rule/object > mode=full 全量 > 默认只跑 stale 项；
    skipped/scope 口径不变（gate ``rsi_reaudit_closure_test`` 锁定）。
    """
    todo_codes = {str(c) for c in (requested or [])}
    todo_objects = {str(o) for o in (requested_objects or [])}
    use_full = str(mode or "").strip().lower() in ("full", "all")
    selected = list(frozen)
    scope_mode = "stale"
    if todo_codes:
        selected = [p for p in selected
                    if str((p.get("item") or {}).get("code") or "") in todo_codes]
    if todo_objects:
        selected = [p for p in selected
                    if str((p.get("item") or {}).get("object_id") or "") in todo_objects]
    if not (todo_codes or todo_objects):
        if use_full:
            scope_mode = "full"
        else:
            scope_mode = "stale"
            selected = [p for p in selected if _frozen_pair_stale(p).get("stale")]
    else:
        scope_mode = "explicit"
    selected_keys = {(str((p.get("item") or {}).get("object_id") or ""),
                      str((p.get("item") or {}).get("code") or "")) for p in selected}
    skipped = [{"object_id": str((p.get("item") or {}).get("object_id") or ""),
                "rule_code": str((p.get("item") or {}).get("code") or ""),
                "reason": "not_affected" if scope_mode == "stale" else "out_of_scope"}
               for p in frozen
               if (str((p.get("item") or {}).get("object_id") or ""),
                   str((p.get("item") or {}).get("code") or "")) not in selected_keys]
    scope = {"mode": scope_mode, "base_manifest_ids": list(base_mids or []),
             "manifest_scope": str(manifest_scope or "legacy_active_union"),
             "frozen_pairs": len(frozen), "affected_pairs": len(selected),
             "skipped_pairs": len(skipped), "explicit_rule_codes": sorted(todo_codes),
             "explicit_object_ids": sorted(todo_objects),
             "rule_codes": sorted({str((p.get("item") or {}).get("code") or "")
                                   for p in selected}),
             "object_ids": sorted({str((p.get("item") or {}).get("object_id") or "")
                                   for p in selected})}
    frozen_versions = {}
    for p in frozen:
        item = p.get("item") or {}
        frozen_versions[str(item.get("code") or "")] = str(item.get("version") or "")
    return {"selected": selected, "scope": scope, "skipped": skipped,
            "frozen_versions": frozen_versions, "scope_mode": scope_mode}


def _reaudit_from_manifest(case: Mapping, docs: list, requested: list,
                           requested_objects: list, *, actor: str = "", role: str = "",
                           activate: bool = False, reason: str = "",
                           manifest_id: str = "", mode: str = "auto",
                           default_batch: str = ""):
    """定向复审主路径：读 manifest 冻结 slots，只跑受影响 rule/object。

    返回 None 表示“没有可用的冻结清单”，调用方回退到 published 规则口径。
    """
    case_id = str(case.get("id") or "")
    pairs, base_mids = _manifest_item_pairs(case_id, manifest_id)
    if not pairs:
        return None
    frozen = [p for p in pairs
              if isinstance((p.get("item") or {}).get("slots"), dict)
              and (p.get("item") or {}).get("slots")]
    if not frozen:
        return None
    _scope_sel = _select_reaudit_scope(frozen, base_mids, requested,
                                       requested_objects, mode)
    selected = _scope_sel["selected"]
    scope = _scope_sel["scope"]
    skipped = _scope_sel["skipped"]
    frozen_versions = _scope_sel["frozen_versions"]
    if not selected:
        return {"ok": True, "mode": "manifest_frozen", "case_id": case_id,
                "old_run_id": str(case.get("last_run_id") or ""), "new_run_id": "",
                "batch_id": "", "activated": False, "changed": 0,
                "old": {}, "new": {}, "evaluated": [], "uncompiled": [],
                "diff": {"items": [], "changed": [], "added": [], "not_compared": [],
                         "unchanged": [], "counts": {}, "total": 0},
                "scope": scope, "skipped": skipped, "manifest_id": "",
                "base_manifest_ids": base_mids, "frozen_versions": frozen_versions,
                "ledger": {}, "new_finding_ids": [], "old_preserved": True,
                "fabricated": False,
                "note": "无受影响项：冻结版本与当前发布版本一致，未创建重审运行（可传 "
                        "mode=full 或 rule_codes 强制复审）"}

    doc_index = {str(d.get("id") or ""): d for d in (docs or [])}
    need_docs = []
    for p in selected:
        obj = str((p.get("item") or {}).get("object_id") or "")
        if obj and obj in doc_index and doc_index[obj] not in need_docs:
            need_docs.append(doc_index[obj])
    bundles = _parse_document_bundle(need_docs)
    parse_errors = [b.get("meta") for b in bundles.values() if b.get("error")]
    docs_meta = [b.get("meta") for b in bundles.values()]

    new_mid = db.new_id("man")
    new_run_id = db.new_id("run")
    batch_id = db.new_id("psb")
    evaluated, uncompiled, findings_payload, point_rows = [], [], [], []
    result_rows, new_items = [], []
    for p in selected:
        item = dict(p.get("item") or {})
        new_items.append(item)
        obj = str(item.get("object_id") or "")
        code = str(item.get("code") or "")
        version = str(item.get("version") or "")
        bundle = bundles.get(obj) or {"meta": {"document_id": obj}, "text": "", "facts": [],
                                      "error": "对象不在项目内"}
        facts = list(bundle.get("facts") or [])
        if default_batch:
            facts = [ts.TypedFact.from_dict({**f.to_dict(),
                                            "batch_id": f.batch_id or default_batch})
                     for f in facts]
        rule_row = {}
        try:
            rule_row = R.rules.get(str(item.get("rule_id") or "")) or {}
        except Exception:  # noqa: BLE001
            rule_row = {}
        seeded = dict(rule_row)
        seeded["slots"] = item.get("slots") or {}
        merged = _merge_rule(seeded)
        try:
            result = evaluate_rule(merged, facts=facts)
        except Exception as exc:  # noqa: BLE001
            result = {"ok": False, "rule_id": code, "state": "insufficient",
                      "verdict": "insufficient", "tri": "unknown",
                      "reason": f"execution_error: {type(exc).__name__}: {str(exc)[:200]}",
                      "reason_code": "execution_error", "detail": "", "evidence": [],
                      "ir": None, "ir_source": "none", "facts_count": len(facts),
                      "fact_issues": {}}
        if bundle.get("error") and result.get("ok"):
            result = dict(result)
            result.update({"state": "insufficient", "verdict": "insufficient",
                           "reason": f"对象解析失败：{bundle.get('error')}",
                           "reason_code": "parse_failed", "evidence": []})
        if not result.get("ok"):
            uncompiled.append({"rule_code": code, "object_id": obj, "version": version,
                               "reason_code": result.get("reason_code") or "not_compilable",
                               "reason": result.get("reason") or "",
                               "source": result.get("ir_source") or ""})
            state = "unknown"
        else:
            state = str(result.get("state") or "unknown")
        if state == "fail" and not _has_locator(result.get("evidence")):
            result = dict(result)
            result.update({"state": "insufficient", "verdict": "insufficient",
                           "reason_code": "evidence_missing",
                           "reason": "evidence_missing: 结论缺少 quote/row/span，按证据不足处理"})
            state = "insufficient"
        result_row = _frozen_result_row(new_mid, item, result, bundle.get("meta") or {}, [])
        fp = {}
        if state == "fail":
            fp = _frozen_finding_payload(case_id, item, result, new_run_id,
                                         result_row["id"], bundle.get("meta") or {})
            result_row["finding_ids"] = [fp["row"]["id"]]
            findings_payload.append(fp)
        result_rows.append(result_row)
        point_rows.append({"batch": batch_id, "point_id": code, "state": state,
                           "confidence": None,
                           "reason": str(result.get("reason") or "")[:300],
                           "quote": _first_quote(result.get("evidence"))[:200],
                           "title": str(item.get("name") or code),
                           "file_id": obj})
        evaluated.append({"rule_code": code, "object_id": obj,
                          "rule_id": str(item.get("rule_id") or ""),
                          "rule_name": str(item.get("name") or ""),
                          "version": version, "frozen": True,
                          "state": state, "tri": result.get("tri"),
                          "reason_code": result.get("reason_code"),
                          "reason": result.get("reason"),
                          "evidence": result.get("evidence") or [],
                          "ir_source": result.get("ir_source"),
                          "finding_ids": result_row.get("finding_ids") or []})

    # old / new 快照与 diff（按 rule×object）
    old_items = {}
    for p in selected:
        item = p.get("item") or {}
        key = (str(item.get("object_id") or ""), str(item.get("code") or ""))
        res = p.get("result") or {}
        old_items[key] = {"result_id": str(res.get("id") or ""),
                          "conclusion": str(res.get("conclusion") or ""),
                          "state": _MANIFEST_SCORE.get(str(res.get("conclusion") or ""), "unknown"),
                          "execution": str(res.get("execution") or ""),
                          "review_status": str(res.get("review_status") or "")}
    _all_fs_before = _raw_findings(case_id)
    old_finding_ids = {}
    for f in _all_fs_before:
        fkey = (str(f.get("object_id") or ""), str(f.get("rule_id") or ""))
        if fkey in old_items and (f.get("status") or "") != "superseded":
            old_finding_ids.setdefault(fkey, []).append(f.get("id"))
    new_state = {(str(x.get("object_id") or ""), str(x.get("rule_code") or "")): x.get("state")
                 for x in evaluated}
    new_finding_map = {(str(x.get("object_id") or ""), str(x.get("rule_code") or "")):
                       list(x.get("finding_ids") or []) for x in evaluated}
    diff_items = []
    for key in sorted(set(old_items) | set(new_state)):
        o = old_items.get(key) or {"state": "not_audited", "conclusion": ""}
        old_state = str(o.get("state") or "not_audited")
        n_state = str(new_state.get(key) or "not_audited")
        if old_state == "not_audited" and n_state != "not_audited":
            change = "new"
        elif old_state != n_state:
            change = "changed"
        else:
            change = "unchanged"
        diff_items.append({"object_id": key[0], "rule_code": key[1],
                           "old_state": old_state, "new_state": n_state,
                           "old_conclusion": o.get("conclusion") or "",
                           "new_conclusion": _CONCLUSION_TEXT.get(n_state, "无法判断"),
                           "change_type": change, "changed": change == "changed",
                           "old_result_id": o.get("result_id") or "",
                           "old_finding_ids": old_finding_ids.get(key) or [],
                           "new_finding_ids": new_finding_map.get(key) or []})
    diff_counts = {}
    for item in diff_items:
        diff_counts[item["change_type"]] = diff_counts.get(item["change_type"], 0) + 1
    diff = {"items": diff_items,
            "changed": [x for x in diff_items if x["change_type"] == "changed"],
            "added": [x for x in diff_items if x["change_type"] == "new"],
            "not_compared": [], "unchanged": [x for x in diff_items
                                             if x["change_type"] == "unchanged"],
            "counts": diff_counts, "total": len(diff_items)}
    old_snapshot = {"manifest_ids": base_mids,
                    "results": [{"object_id": k[0], "rule_code": k[1], **v}
                                for k, v in sorted(old_items.items())],
                    "findings": [f.get("id") for f in _all_fs_before
                                 if (str(f.get("object_id") or ""),
                                     str(f.get("rule_id") or "")) in old_items]}
    sev = {"critical": 0, "warning": 0, "info": 0}
    for fp in findings_payload:
        sev[str(fp["row"].get("severity") or "warning")] = \
            sev.get(str(fp["row"].get("severity") or "warning"), 0) + 1
    manifest_payload = {
        "id": new_mid, "run_id": new_run_id,
        "tenant_id": str(case.get("tenant_id") or ""),
        "workspace_id": str(case.get("workspace_id") or ""),
        "source": "reaudit", "status": "reaudit",
        "objects_json": json.dumps([{"object_id": str(d.get("id") or ""),
                                     "filename": d.get("filename"),
                                     "doc_type": d.get("doc_type")}
                                    for d in (docs or [])], ensure_ascii=False),
        "rules_json": json.dumps([{"rule_id": str((it.get("item") or {}).get("rule_id") or ""),
                                   "code": str((it.get("item") or {}).get("code") or ""),
                                   "version": str((it.get("item") or {}).get("version") or ""),
                                   "name": (it.get("item") or {}).get("name")}
                                  for it in selected], ensure_ascii=False),
        "items_json": json.dumps(new_items, ensure_ascii=False),
        "hash": "",
        "created_at": db.now(), "created_by": actor or ""}
    import hashlib as _hl
    manifest_payload["hash"] = _hl.sha256(json.dumps(
        {k: manifest_payload[k] for k in ("objects_json", "rules_json", "items_json")},
        ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
    trace = {"reaudit_manifest": {
        "mode": "manifest_frozen", "scopeMode": scope.get("mode"),
        "base_manifest_ids": base_mids, "manifest_id": new_mid,
        "old_run_id": str(case.get("last_run_id") or ""), "new_run_id": new_run_id,
        "activated": bool(activate), "reason": str(reason or "")[:300],
        "frozen_versions": frozen_versions, "scope": scope, "skipped": skipped,
        "evaluated": evaluated, "uncompiled": uncompiled, "diff": diff,
        "old": old_snapshot, "documents": docs_meta, "parse_errors": parse_errors}}
    run_payload = {"id": new_run_id, "case_id": case_id, "created_at": db.now(),
                   "created_by": str(case.get("created_by") or actor or ""),
                   "audit_type": str(case.get("audit_type") or ""),
                   "focus": str(case.get("focus") or ""),
                   "total": len(findings_payload),
                   "critical": sev.get("critical", 0), "warning": sev.get("warning", 0),
                   "suspected": sev.get("info", 0),
                   "trace_json": json.dumps(trace, ensure_ascii=False),
                   "plan_json": json.dumps(
                       [{"point_id": x.get("rule_code") or "",
                         "object_id": x.get("object_id") or "",
                         "team": "manifest_frozen"}
                        for x in evaluated], ensure_ascii=False),
                   "batch_ids": batch_id, "manifest_id": new_mid}
    case_updates = {}
    if activate:
        case_updates = {"last_run_id": new_run_id, "last_audit_at": db.now(),
                        "status": "completed"}
    ledger = {}
    old_rows_before = {k: dict(v) for k, v in old_items.items()}
    try:
        with db.session() as c:
            for fp in findings_payload:
                _tx_insert_finding(c, fp["row"], case)
                _tx_insert_evidence(c, fp["row"]["id"], fp)
            _tx_insert_point_state(c, point_rows)
            ledger = _apply_reaudit_closure(
                c, case_id, manifest=manifest_payload, results=result_rows,
                activate=bool(activate), case_updates=case_updates,
                run=run_payload, audit={
                    "actor": actor or "system",
                    "action": "review.semantic_case_reaudited",
                    "object": case_id,
                    "before": json.dumps({"old_run_id": str(case.get("last_run_id") or ""),
                                          "scope": scope}, ensure_ascii=False),
                    "after": json.dumps({"new_run_id": new_run_id,
                                         "manifest_id": new_mid,
                                         "activated": bool(activate),
                                         "affected_pairs": len(selected),
                                         "changed": len(diff["changed"])},
                                        ensure_ascii=False)})
    except Exception as exc:  # noqa: BLE001 - 同一事务整体回滚，不留半套变更
        _LOG.exception("定向复审收口失败 case=%s run=%s", case_id, new_run_id)
        return {"ok": False, "mode": "manifest_frozen", "case_id": case_id,
                "code": "reaudit_closure_failed", "status": 500,
                "message": f"定向复审收口失败（已整体回滚）：{type(exc).__name__}: {str(exc)[:200]}",
                "new_run_id": "", "manifest_id": ""}
    # 收口后校验旧结果是否原样保留
    old_preserved = True
    try:
        with db.session() as c:
            for p in selected:
                old_res = p.get("result") or {}
                if not old_res.get("id"):
                    continue
                row = c.execute("SELECT * FROM manifest_result WHERE id=?",
                                (old_res.get("id"),)).fetchone()
                if not row:
                    old_preserved = False
                    break
                if str(dict(row).get("conclusion") or "") != str(old_res.get("conclusion") or ""):
                    old_preserved = False
                    break
        for f in _all_fs_before:
            if f.get("id") in [x for ids in old_finding_ids.values() for x in ids]:
                now = _raw_finding(str(f.get("id") or ""))
                if not now or str(now.get("status") or "") != str(f.get("status") or ""):
                    old_preserved = False
                    break
    except Exception:  # noqa: BLE001
        _LOG.debug("定向复审旧结果保留校验跳过", exc_info=True)
    all_findings_after = _raw_findings(case_id, new_run_id)
    new_snapshot = {"run_id": new_run_id, "manifest_id": new_mid,
                    "total_findings": len(all_findings_after),
                    "findings": [{"id": f.get("id"), "rule_id": f.get("rule_id"),
                                  "state": _normalize_state(f.get("state")),
                                  "status": f.get("status"),
                                  "object_id": f.get("object_id")}
                                 for f in all_findings_after],
                    "results": [{"result_id": r.get("id"), "object_id": r.get("object_id"),
                                 "rule_code": r.get("rule_code"),
                                 "conclusion": r.get("conclusion"),
                                 "execution": r.get("execution")}
                                for r in result_rows]}
    return {"ok": True, "mode": "manifest_frozen", "case_id": case_id,
            "old_run_id": str(case.get("last_run_id") or ""),
            "new_run_id": new_run_id, "batch_id": batch_id,
            "activated": bool(activate), "manifest_id": new_mid,
            "base_manifest_ids": base_mids,
            "case_last_run_id_before": str(case.get("last_run_id") or ""),
            "case_last_run_id_after": str((_raw_case(case_id) or {}).get("last_run_id") or ""),
            "old": old_snapshot, "new": new_snapshot, "diff": diff,
            "evaluated": evaluated, "uncompiled": uncompiled,
            "scope": scope, "skipped": skipped, "frozen_versions": frozen_versions,
            "documents": docs_meta, "parse_errors": parse_errors,
            "facts_count": sum(len(b.get("facts") or []) for b in bundles.values()),
            "fact_issues": inspect_facts([f for b in bundles.values() for f in (b.get("facts") or [])]),
            "new_finding_ids": [fp["row"]["id"] for fp in findings_payload],
            "ledger": {"before": {"total": (ledger.get("ledger_before") or {}).get("total"),
                                  "counts": (ledger.get("ledger_before") or {}).get("counts")},
                       "after": {"total": (ledger.get("ledger_after") or {}).get("total"),
                                 "counts": (ledger.get("ledger_after") or {}).get("counts")},
                       "active_switched": ledger.get("active_switched"),
                       "result_ids": ledger.get("result_ids")},
            "old_preserved": old_preserved, "fabricated": False,
            "note": ("定向复审只执行受影响 rule/object，读取 manifest 冻结 slots；"
                     + ("active/台账/报告已同事务切到新结论" if activate
                        else "未 activate：新结果作为候选保留，active/报告仍为旧结论"))}


def _apply_reaudit_closure(c, case_id: str, **kwargs) -> dict:
    """收口委托给 audit_ledger（延迟导入，避免模块循环依赖）。"""
    from . import audit_ledger as _ledger
    return _ledger.apply_reaudit(c, case_id, **kwargs)


def _l87_reaudit_state_hook(case_id: str, out, prior: dict, *, actor: str = ""):
    """L87：语义重审写入点的审计状态一致性收口（与 project.audit / report_gate 同源）。

    - 审计写失败（audit_write_failed）→ case=audit_failed（durable 失败标记；新 run 按
      L58 契约已被清理，case 状态是唯一持久标记；report_gate 读同一事实源阻断签发）；
    - 成功且 activate → 失败态恢复时写**恰好一条** audit.recovered（幂等）；写失败
      → fail-closed 返回 audit_write_failed（不冒充恢复成功）；
    - 开关 RULEPROOF_AUDIT_STATE_CONSISTENCY=0 → 零动作（回退 L77 行为）。
    """
    if not isinstance(out, dict):
        return out
    try:
        from . import audit_ledger as _alg
    except Exception:  # noqa: BLE001 - 审计状态模块不可用：保持既有返回（门禁另有兜底）
        _LOG.warning("L87 reaudit audit_ledger unavailable", exc_info=True)
        return out
    if not _alg.audit_state_consistency_enabled():
        return out
    failed = bool(out.get("audit_failed")) or \
        str(out.get("code") or "") == "audit_write_failed"
    if failed:
        try:
            mark = _alg.mark_audit_failure(
                case_id, actor=actor,
                reason=str(out.get("message") or out.get("code") or ""),
                run_id=str(out.get("manifest_id") or ""),
                source="semantic_core.reaudit_same_case")
            out.setdefault("audit_state", {
                "marked_failed": bool(mark.get("marked")),
                "case_status": str(mark.get("case_status") or "")})
        except Exception:  # noqa: BLE001 - 标记失败不改变既有 409 返回（日志留痕）
            _LOG.warning("L87 reaudit mark_audit_failure skipped case=%s", case_id,
                         exc_info=True)
        return out
    if out.get("ok") and out.get("activated") and str(out.get("new_run_id") or ""):
        try:
            rec = _alg.record_recovery(
                case_id, str(out["new_run_id"]), prior=prior,
                actor=str(actor or "system"),
                source="semantic_core.reaudit_same_case",
                manifest_id=str(out.get("manifest_id") or ""))
            if rec.get("recovered"):
                out["audit_recovery"] = {
                    k: rec.get(k) for k in
                    ("enabled", "recovered", "written", "event_id", "request_id", "epoch")}
        except Exception as exc:  # noqa: BLE001 - 恢复事件写失败必须 fail-closed
            _LOG.error("L87 reaudit audit.recovered write failed case=%s", case_id,
                       exc_info=True)
            try:
                _alg.mark_audit_failure(
                    case_id, actor=actor,
                    reason=f"audit.recovered 写入失败：{type(exc).__name__}: {str(exc)[:200]}",
                    run_id=str(out.get("new_run_id") or ""),
                    source="semantic_core.reaudit_same_case")
            except Exception:  # noqa: BLE001
                _LOG.warning("L87 reaudit fail-closed mark skipped", exc_info=True)
            return {"ok": False, "code": "audit_write_failed", "status": 409,
                    "case_id": case_id, "blocked": True, "audit_failed": True,
                    "execution_path": str(out.get("execution_path") or "manifest_exec.run"),
                    "manifest_exec_run": True,
                    "detail": {"action": "audit.recovered",
                               "reason": f"{type(exc).__name__}: {str(exc)[:300]}"},
                    "message": "复审恢复事件（audit.recovered）写入失败：本次恢复无法"
                               "自证，按 fail-closed 判定失败，不得签发报告；请修复审计库"
                               "写入后重跑。"}
    return out


def reaudit_same_case(case_id: str, *, actor: str = "", role: str = "",
                      rule_codes=None, object_ids=None, activate: bool = False,
                      reason: str = "", default_batch: str = "",
                      manifest_id: str = "", mode: str = "auto") -> dict:
    """同案例定向复审：优先读 manifest 冻结 slots，只跑受影响的 rule/object。

    路径选择：
    - 有 manifest 冻结清单（active 结果或最近 run 的 manifest）→ 冻结路径：
      版本/判据/适用范围全部取清单快照，只执行受影响的 rule×object；
      结果写新 manifest_result，``activate=True`` 时同一事务切 active + case 当前 run，
      台账/报告立即读到新结论，旧结果原样保留；
    - 没有冻结清单（旧项目/未跑过 manifest）→ 回退 published 规则口径（兼容旧测试）。
    """
    case = _raw_case(case_id)
    if not case:
        return {"ok": False, "code": "not_found", "status": 404, "message": "项目不存在"}
    if actor or role:
        try:
            from . import review as _review
            access = _review.authorize_case(case_id, "review", actor, role)
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "code": "forbidden", "status": 403,
                    "message": f"权限校验失败：{type(exc).__name__}"}
        if not access.get("ok"):
            return {"ok": False, "code": access.get("code") or "forbidden",
                    "status": int(access.get("status") or 403),
                    "message": access.get("message") or "无权重审该项目"}
    docs = _raw_case_documents(case_id)
    if not docs:
        return {"ok": False, "code": "no_documents", "status": 400,
                "message": "项目内没有可重审文件"}
    requested = []
    if isinstance(rule_codes, str):
        requested = [x.strip() for x in rule_codes.split(",") if x.strip()]
    elif rule_codes:
        requested = [str(x).strip() for x in rule_codes if str(x).strip()]
    requested_objects = []
    if isinstance(object_ids, str):
        requested_objects = [x.strip() for x in object_ids.split(",") if x.strip()]
    elif object_ids:
        requested_objects = [str(x).strip() for x in object_ids if str(x).strip()]
    # L87（2026-11-24，审计状态跨写入点一致性）：在任何执行/写库之前捕获恢复上下文
    # （失败态/失败纪元）。失败→case=audit_failed；成功恢复→写唯一 audit.recovered。
    _l87_prior = {}
    try:
        from . import audit_ledger as _l87_alg0
        _l87_prior = _l87_alg0.recovery_context(case_id)
    except Exception:  # noqa: BLE001 - 读模型失败不阻断复审（状态门禁另行 fail-closed）
        _LOG.warning("L87 reaudit recovery context capture skipped case=%s", case_id,
                     exc_info=True)
    with _case_context(case):
        out = None
        _single_path = _reaudit_single_path_enabled()
        if str(mode or "").strip().lower() != "published":
            try:
                if _single_path:
                    # L58 ①：唯一执行路径（manifest_exec.run）；无冻结清单 → None → published 兼容
                    out = _reaudit_single_path(
                        case, docs, requested, requested_objects,
                        actor=actor, role=role, activate=activate,
                        reason=reason, manifest_id=manifest_id,
                        mode=mode, default_batch=default_batch)
                else:
                    out = _reaudit_from_manifest(
                        case, docs, requested, requested_objects,
                        actor=actor, role=role, activate=activate,
                        reason=reason, manifest_id=manifest_id,
                        mode=mode, default_batch=default_batch)
            except Exception:  # noqa: BLE001
                _LOG.exception("定向复审冻结路径失败 case=%s", case_id)
                if _single_path:
                    _l58_audit("reaudit.single_path_failed", case_id, {
                        "entry": "semantic_core.reaudit_same_case",
                        "execution_path": "manifest_exec.run",
                        "note": "单路径异常：fail-closed，不回退第二执行器",
                    })
                    return {"ok": False, "code": "reaudit_single_path_failed",
                            "status": 500, "case_id": case_id,
                            "execution_path": "manifest_exec.run",
                            "manifest_exec_run": True,
                            "message": "定向复审单路径执行失败（fail-closed，未回退第二执行器）"}
                out = None
        if out is not None:
            if not out.get("execution_path"):
                out["execution_path"] = ("published_rules_fallback"
                                         if not out.get("manifest_id")
                                         else "semantic_core.manual_executor(second executor)")
            if not out.get("manifest_exec_run"):
                out.setdefault("manifest_exec_run", False)
            out = _l87_reaudit_state_hook(case_id, out, _l87_prior, actor=actor)
            return _l52_annotate_reaudit(case_id, out, activate=activate,
                                         actor=actor)
        out = _reaudit_from_published(case_id, actor=actor, role=role,
                                      rule_codes=rule_codes, activate=activate,
                                      reason=reason, default_batch=default_batch)
        # L58：无冻结清单的旧项目兼容路径也要显式标注（不冒充 manifest_exec.run）
        if isinstance(out, dict):
            out.setdefault("execution_path", "published_rules_fallback")
            out.setdefault("manifest_exec_run", False)
            out.setdefault("second_executor", True)
            out.setdefault("note", "无冻结清单（旧项目）→ published 规则口径重审"
                                   "（by-design 兼容路径，未走 manifest_exec.run）")
        out = _l87_reaudit_state_hook(case_id, out, _l87_prior, actor=actor)
        return _l52_annotate_reaudit(case_id, out, activate=activate, actor=actor)


def _run_item_evidence_entries(item_out: Mapping) -> list:
    """manifest_exec.run 输出项 → 复审证据行（逐字引文/定位），供 finding 物化与 diff。"""
    rows = []
    d4 = item_out.get("d4") if isinstance(item_out, Mapping) else None
    if isinstance(d4, Mapping):
        for sub in d4.get("subs") or []:
            if not isinstance(sub, Mapping):
                continue
            quote = str(sub.get("quote") or "").strip()
            locator = str(sub.get("source_locator") or sub.get("locator") or "").strip()
            if quote or locator:
                rows.append({"quote": quote, "locator": locator})
        for ev in d4.get("evidence") or []:
            if not isinstance(ev, Mapping):
                continue
            quote = str(ev.get("quote") or ev.get("excerpt") or "").strip()
            locator = str(ev.get("locator") or ev.get("source_locator") or "").strip()
            if quote or locator:
                rows.append({"quote": quote, "locator": locator})
    return rows


def _run_item_fail_groups(item_out: Mapping) -> dict:
    """run 输出项 → {子要求 id: [fail 子要求行]}（无 fail 子要求时用空 id 一组）。"""
    d4 = item_out.get("d4") if isinstance(item_out, Mapping) else None
    d5 = item_out.get("d5") if isinstance(item_out, Mapping) else None
    groups = {}
    if isinstance(d4, Mapping):
        for sub in d4.get("subs") or []:
            if not isinstance(sub, Mapping):
                continue
            if str(sub.get("status") or "") != "fail":
                continue
            sid = str(sub.get("id") or "").split("#", 1)[0]
            groups.setdefault(sid, []).append(dict(sub))
    if not groups:
        reason = str((d5 or {}).get("reason") or "") if isinstance(d5, Mapping) else ""
        groups[""] = [{"id": "", "status": "fail", "detail": reason, "quote": ""}]
    return groups


def _l58_temp_run(case_id: str, base_mid: str, *, actor: str = "",
                  created_by: str = "") -> str:
    """L58：为单路径执行建一个临时 run 行（执行期「当前 run manifest」隔离用）。

    仅承载本次 `manifest_exec.run` 期间的「当前 run / 版本快照」判定；执行结束立即
    删除（不进入审计轨迹、不改变 case.last_run_id）。失败返回空串（调用方按无隔离
    继续执行，行为退化为旧口径，但不影响判定）。
    """
    tid = ""
    try:
        tid = db.new_id("run-tmp")
        R.audit_runs.insert(id=tid, case_id=str(case_id or ""),
                            created_at=db.now(),
                            created_by=str(created_by or actor or ""),
                            audit_type="", focus="", total=0, critical=0,
                            warning=0, suspected=0, trace_json="{}",
                            plan_json="[]", batch_ids="",
                            manifest_id=str(base_mid or ""))
    except Exception:  # noqa: BLE001 - 隔离 run 建失败：不阻断执行（留日志）
        _LOG.warning("L58 reaudit temp run insert skipped case=%s", case_id,
                     exc_info=True)
        return ""
    return tid


def _l58_drop_temp_run(case_id: str, temp_run_id: str) -> None:
    """删除执行期临时 run 及其版本快照键（尽力而为；失败留日志）。"""
    tid = str(temp_run_id or "")
    if not tid:
        return
    try:
        from . import version_snapshot as _vs_tmp
        from . import sysconfig as _sc_tmp
        _sc_tmp.delete_keys([_vs_tmp._key(str(case_id or ""), tid)])
    except Exception:  # noqa: BLE001
        _LOG.debug("L58 reaudit temp snapshot cleanup skipped", exc_info=True)
    try:
        with db.session() as c:
            c.execute("DELETE FROM audit_run WHERE id=?", (tid,))
    except Exception:  # noqa: BLE001
        _LOG.warning("L58 reaudit temp run cleanup failed case=%s run=%s",
                     case_id, tid, exc_info=True)


def _cleanup_reaudit_single(case_id: str, new_mid: str, new_run_id: str,
                            selected_keys: list, old_active: dict,
                            closure_cloned: bool, batch_key: str = "",
                            temp_run_id: str = "") -> None:
    """L58 ①：单路径执行/收口失败后的补偿清理。

    目的：manifest_exec.run 自身会提交 manifest_result/active（不在调用方事务内），
    因此收口失败时必须显式撤销，避免「失败复审留下新 manifest/finding/active 半套」
    （gate ``rsi_reaudit_closure_test`` 的原子性断言）。审计日志不可删（审计轨迹）。
    """
    if temp_run_id:
        # run 期间（collect 决策表路径）可能已物化 finding 并挂到临时 run 上 → 撤销
        try:
            with db.session() as c:
                _fids = [r[0] for r in c.execute(
                    "SELECT id FROM finding WHERE run_id=?", (temp_run_id,)).fetchall()]
                for _fid in _fids:
                    c.execute("DELETE FROM anchor WHERE id IN "
                              "(SELECT anchor_id FROM evidence WHERE finding_id=?)",
                              (_fid,))
                    c.execute("DELETE FROM evidence WHERE finding_id=?", (_fid,))
                    c.execute("DELETE FROM finding WHERE id=?", (_fid,))
        except Exception:  # noqa: BLE001 - 补偿清理失败留日志
            _LOG.warning("L58 reaudit collect finding cleanup failed case=%s",
                         case_id, exc_info=True)
        _l58_drop_temp_run(case_id, temp_run_id)
    try:
        with db.session() as c:
            c.execute("DELETE FROM manifest_evidence WHERE result_id IN "
                      "(SELECT id FROM manifest_result WHERE manifest_id=?)", (new_mid,))
            c.execute("DELETE FROM manifest_result WHERE manifest_id=?", (new_mid,))
            c.execute("DELETE FROM audit_manifest WHERE id=?", (new_mid,))
            c.execute("DELETE FROM audit_run WHERE id=?", (new_run_id,))
            if batch_key:
                c.execute("DELETE FROM point_state WHERE batch_id=?", (batch_key,))
            for (obj, code) in selected_keys:
                row = old_active.get((obj, code)) or {}
                if row.get("id"):
                    c.execute(
                        "INSERT INTO manifest_active(case_id,object_id,rule_code,result_id,updated_at) "
                        "VALUES(?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code) "
                        "DO UPDATE SET result_id=excluded.result_id, "
                        "updated_at=excluded.updated_at",
                        (case_id, obj, code, row["id"], db.now()))
                    try:
                        subs = (json.loads(row.get("d4_json") or "{}")).get("subs") or []
                    except Exception:  # noqa: BLE001
                        subs = []
                    if not subs:
                        subs = [{"id": "", "status": ""}]
                    for sub in subs:
                        c.execute(
                            "INSERT INTO manifest_active_sub(case_id,object_id,rule_code,"
                            "sub_id,result_id,status,updated_at) VALUES(?,?,?,?,?,?,?) "
                            "ON CONFLICT(case_id,object_id,rule_code,sub_id) DO UPDATE SET "
                            "result_id=excluded.result_id,status=excluded.status,"
                            "updated_at=excluded.updated_at",
                            (case_id, obj, code, str(sub.get("id") or ""), row["id"],
                             str(sub.get("status") or ""), db.now()))
                else:
                    c.execute("DELETE FROM manifest_active WHERE case_id=? AND "
                              "object_id=? AND rule_code=?", (case_id, obj, code))
                    c.execute("DELETE FROM manifest_active_sub WHERE case_id=? AND "
                              "object_id=? AND rule_code=?", (case_id, obj, code))
    except Exception:  # noqa: BLE001 - 补偿清理失败必须留日志（不得静默）
        _LOG.warning("L58 reaudit single-path cleanup failed case=%s manifest=%s",
                     case_id, new_mid, exc_info=True)
    if closure_cloned:
        try:
            from . import manifest as _mf
            from . import sysconfig as _sc
            _sc.delete_keys([_mf.CLOSURE_PREFIX + new_mid,
                             _mf.ARTIFACT_PREFIX + new_mid])
        except Exception:  # noqa: BLE001
            _LOG.debug("L58 reaudit closure cleanup skipped", exc_info=True)


def _reaudit_single_path(case: Mapping, docs: list, requested: list,
                         requested_objects: list, *, actor: str = "", role: str = "",
                         activate: bool = False, reason: str = "",
                         manifest_id: str = "", mode: str = "auto",
                         default_batch: str = ""):
    """L58 ①：定向复审唯一执行路径。

    与旧第二执行器的差别：复审清单（只含本次受影响冻结项）落库后，执行**统一交给
    ``manifest_exec.run``**（D1–D5/证据门禁/active 收口/``manifest.executed`` 审计同主链），
    复审侧只负责：组装清单、读回执行结果、生成 old/new/diff、物化 finding（带去重）、
    收口 active/台账/报告口径。

    契约（gate 锁定）：
    - 旧 manifest/result/finding/run 不删不改；
    - ``activate=False`` 时候选结果不切 active、不改 case.last_run_id；
    - 收口失败整体回滚（manifest_exec.run 的已提交副作用由补偿清理撤销）。

    返回 ``None`` 表示没有可用冻结清单（调用方回退 published 口径，属于旧项目兼容路径）。
    """
    case_id = str(case.get("id") or "")
    pairs, base_mids = _manifest_item_pairs(case_id, manifest_id,
                                            single_manifest=True)
    if not pairs:
        return None
    frozen = [p for p in pairs
              if isinstance((p.get("item") or {}).get("slots"), dict)
              and (p.get("item") or {}).get("slots")]
    if not frozen:
        return None
    _scope_sel = _select_reaudit_scope(frozen, base_mids, requested,
                                       requested_objects, mode,
                                       manifest_scope="single_manifest")
    selected = _scope_sel["selected"]
    scope = _scope_sel["scope"]
    skipped = _scope_sel["skipped"]
    frozen_versions = _scope_sel["frozen_versions"]
    if not selected:
        return {"ok": True, "mode": "manifest_frozen", "case_id": case_id,
                "execution_path": "manifest_exec.run", "manifest_exec_run": True,
                "second_executor": False,
                "old_run_id": str(case.get("last_run_id") or ""), "new_run_id": "",
                "batch_id": "", "activated": False, "changed": 0,
                "old": {}, "new": {}, "evaluated": [], "uncompiled": [],
                "diff": {"items": [], "changed": [], "added": [], "not_compared": [],
                         "unchanged": [], "counts": {}, "total": 0},
                "scope": scope, "skipped": skipped, "manifest_id": "",
                "base_manifest_ids": base_mids, "frozen_versions": frozen_versions,
                "ledger": {}, "new_finding_ids": [], "reused_finding_ids": [],
                "old_preserved": True, "fabricated": False,
                "note": "无受影响项：冻结版本与当前发布版本一致，未创建重审运行（可传 "
                        "mode=full 或 rule_codes 强制复审）"}
    # 复审基准必须是「单一份清单」（L58/H09：不允许跨 manifest 混轮基准）
    _base_set = {str(p.get("manifest_id") or "") for p in selected}
    if len(_base_set) != 1:
        _l58_audit("reaudit.scope_rejected_mixed_manifests", case_id, {
            "entry": "semantic_core.reaudit_same_case",
            "base_manifest_ids": sorted(_base_set),
            "reason": "复审基准跨多份 manifest：按 run/manifest 维度收口，拒绝 mixed-active 基准",
        })
        return {"ok": False, "code": "reaudit_mixed_base_manifests", "status": 409,
                "case_id": case_id, "execution_path": "manifest_exec.run",
                "manifest_exec_run": True,
                "message": "复审基准跨多份冻结清单（mixed active），已拒绝；"
                           "请显式传 manifest_id 或先做一次全量审核"}
    base_mid = next(iter(_base_set))
    # 捕获旧 active 指针（activate=False / 收口失败时恢复）
    selected_keys = [(str((p.get("item") or {}).get("object_id") or ""),
                      str((p.get("item") or {}).get("code") or "")) for p in selected]
    old_active = {}
    old_findings_before = _raw_findings(case_id)
    try:
        with db.session() as c:
            for obj, code in selected_keys:
                row = c.execute(
                    "SELECT result_id FROM manifest_active WHERE case_id=? "
                    "AND object_id=? AND rule_code=?", (case_id, obj, code)).fetchone()
                rid = str((row["result_id"] if row else "") or "")
                if not rid:
                    continue
                rr = c.execute("SELECT * FROM manifest_result WHERE id=?", (rid,)).fetchone()
                if rr:
                    old_active[(obj, code)] = dict(rr)
    except Exception:  # noqa: BLE001
        _LOG.debug("L58 reaudit old active capture skipped", exc_info=True)
    # 组装复审清单（items 逐字复制冻结 item；slots/version 不变 → 读冻结口径）
    new_mid = db.new_id("man")
    new_run_id = db.new_id("run")
    batch_id = db.new_id("psb")
    new_items = [dict(p.get("item") or {}) for p in selected]
    import hashlib as _hl
    manifest_payload = {
        "id": new_mid, "run_id": new_run_id,
        "tenant_id": str(case.get("tenant_id") or ""),
        "workspace_id": str(case.get("workspace_id") or ""),
        "source": "reaudit", "status": "reaudit",
        "objects_json": json.dumps([{"object_id": str(d.get("id") or ""),
                                     "filename": d.get("filename"),
                                     "doc_type": d.get("doc_type")}
                                    for d in (docs or [])], ensure_ascii=False),
        "rules_json": json.dumps([{"rule_id": str((p.get("item") or {}).get("rule_id") or ""),
                                   "code": str((p.get("item") or {}).get("code") or ""),
                                   "version": str((p.get("item") or {}).get("version") or ""),
                                   "name": (p.get("item") or {}).get("name")}
                                  for p in selected], ensure_ascii=False),
        "items_json": json.dumps(new_items, ensure_ascii=False),
        "hash": "",
        "created_at": db.now(), "created_by": actor or ""}
    manifest_payload["hash"] = _hl.sha256(json.dumps(
        {k: manifest_payload[k] for k in ("objects_json", "rules_json", "items_json")},
        ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
    try:
        with db.session() as c:
            c.execute(
                "INSERT INTO audit_manifest(id,case_id,run_id,tenant_id,workspace_id,"
                "source,status,objects_json,rules_json,items_json,hash,created_at,created_by) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (new_mid, case_id, new_run_id, manifest_payload["tenant_id"],
                 manifest_payload["workspace_id"], "reaudit", "reaudit",
                 manifest_payload["objects_json"], manifest_payload["rules_json"],
                 manifest_payload["items_json"], manifest_payload["hash"],
                 manifest_payload["created_at"], manifest_payload["created_by"]))
    except Exception as exc:  # noqa: BLE001
        _LOG.warning("L58 reaudit manifest insert failed case=%s", case_id, exc_info=True)
        return {"ok": False, "code": "reaudit_manifest_insert_failed", "status": 500,
                "case_id": case_id, "execution_path": "manifest_exec.run",
                "message": f"{type(exc).__name__}: {str(exc)[:200]}"}
    # 复制基准闭包 → 复审执行同样受冻结完整性/解析产物/绑定边界守卫（fail-closed）。
    closure_cloned = False
    try:
        from . import manifest as _mf_l58
        _closure = _mf_l58.load_closure(base_mid) or {}
        if _closure:
            _mf_l58._save_closure(new_mid, _closure,
                                  _mf_l58.load_artifact(base_mid) or {})
            closure_cloned = True
    except Exception:  # noqa: BLE001 - 闭包复制失败不阻断（执行按旧清单口径走 legacy 守卫）
        _LOG.warning("L58 reaudit closure clone skipped case=%s base=%s",
                     case_id, base_mid, exc_info=True)
    # 执行：唯一执行体 manifest_exec.run（含 manifest.executed 审计）
    from . import manifest_exec as _me_l58
    # 执行期隔离（不用进程级 env 开关，避免并发审核互相影响）：
    # 1) 临时 audit_run 行把「当前 run 的 manifest」指向 base_mid —— run 内的跨轮
    #    active 清理（_expire_out_of_scope_active）只对全量轮次生效；复审清单只含
    #    受影响项，若被当成当前全量轮次会把未受影响项的 active 指针误删（gate 锁定
    #    「未受影响规则 active 指针不变」）。temp run 的 manifest=base_mid ≠ new_mid →
    #    增量路径跳过清理。
    # 2) 该 temp run 也承接 run 内的版本快照 v2 落库（否则会挂到旧 run 上、覆盖旧 run
    #    的快照）；执行结束后删除 temp run 与其快照键，收口成功后按正式 new_run_id
    #    重新落一次快照（不修改 version_snapshot.py）。
    temp_run_id = _l58_temp_run(case_id, base_mid, actor=actor,
                                created_by=str(case.get("created_by") or ""))
    exec_out = {}
    try:
        exec_out = _me_l58.run(new_mid)
    except Exception as exc:  # noqa: BLE001
        exec_out = {"error": f"{type(exc).__name__}: {str(exc)[:300]}"}
    finally:
        _l58_drop_temp_run(case_id, temp_run_id)
    # L77：manifest.executed 下沉审计写失败 → 复审同样硬阻断（与 project.audit 同口径；
    # run() 返回 audit_failed=True，默认 RULEPROOF_AUDIT_HARD_FAIL=1）。
    _reaudit_audit_failed = bool(isinstance(exec_out, dict)
                                 and exec_out.get("audit_failed"))
    if (not isinstance(exec_out, dict) or exec_out.get("blocked")
            or exec_out.get("error") or _reaudit_audit_failed):
        _audit_err = {}
        if _reaudit_audit_failed:
            _audit_err = dict(exec_out.get("audit_error") or {})
        _l58_audit("reaudit.audit_write_failed" if _reaudit_audit_failed
                   else "reaudit.execution_blocked", case_id, {
            "entry": "semantic_core.reaudit_same_case",
            "manifest_id": new_mid, "base_manifest_id": base_mid,
            "error": str((exec_out or {}).get("error") or "")[:300],
            "audit_error": _audit_err,
            "closure_cloned": closure_cloned,
        })
        _cleanup_reaudit_single(case_id, new_mid, new_run_id, selected_keys,
                                old_active, closure_cloned, "mid:" + new_mid,
                                temp_run_id)
        if _reaudit_audit_failed:
            return {"ok": False, "code": "audit_write_failed", "status": 409,
                    "case_id": case_id, "manifest_id": new_mid,
                    "execution_path": "manifest_exec.run", "manifest_exec_run": True,
                    "blocked": True, "audit_failed": True,
                    "detail": _audit_err,
                    "message": "复审执行审计写入失败（manifest.executed 未能落库）："
                               "本次复审无法自证，按 fail-closed 判定失败；"
                               "请修复审计库写入后重跑。"}
        return {"ok": False, "code": "reaudit_execution_blocked", "status": 409,
                "case_id": case_id, "manifest_id": new_mid,
                "execution_path": "manifest_exec.run", "manifest_exec_run": True,
                "blocked": True,
                "message": "复审冻结清单执行被阻断/失败："
                           + str((exec_out or {}).get("error") or "")[:300]}
    out_items = {}
    for it in exec_out.get("items") or []:
        if not isinstance(it, Mapping):
            continue
        out_items[(str(it.get("object_id") or ""), str(it.get("rule") or ""))] = dict(it)
    # 执行结果 → evaluated / diff（new 状态来自 manifest_exec.run，不是第二执行器）
    evaluated = []
    for p in selected:
        item = p.get("item") or {}
        obj = str(item.get("object_id") or "")
        code = str(item.get("code") or "")
        it = out_items.get((obj, code))
        if it is None:
            state, reason, reason_code, tri = ("unknown",
                                               "冻结项未产出执行结果（输出守卫丢弃/未执行）",
                                               "missing_output", "")
            evidence = []
        else:
            d5 = it.get("d5") if isinstance(it.get("d5"), Mapping) else {}
            state = _normalize_state(d5.get("status") or it.get("conclusion"))
            reason = str(d5.get("reason") or "")
            reason_code = str(d5.get("fail_kind") or d5.get("raw_state") or "")
            tri = str(d5.get("tri") or (it.get("d4") or {}).get("tri") or "")
            evidence = _run_item_evidence_entries(it)
        if state == "fail" and not _has_locator(evidence):
            state = "insufficient"
            reason_code = "evidence_missing"
            reason = "evidence_missing: 结论缺少 quote/row/span，按证据不足处理"
        evaluated.append({"rule_code": code, "object_id": obj,
                          "rule_id": str(item.get("rule_id") or ""),
                          "rule_name": str(item.get("name") or ""),
                          "version": str(item.get("version") or ""), "frozen": True,
                          "state": state, "tri": tri, "reason_code": reason_code,
                          "reason": reason, "evidence": evidence,
                          "ir_source": "manifest_exec.run",
                          "result_id": str(it.get("result_id") or "") if it else "",
                          "finding_ids": []})
    old_items = {}
    for p in selected:
        item = p.get("item") or {}
        key = (str(item.get("object_id") or ""), str(item.get("code") or ""))
        res = p.get("result") or {}
        old_items[key] = {"result_id": str(res.get("id") or ""),
                          "conclusion": str(res.get("conclusion") or ""),
                          "state": _MANIFEST_SCORE.get(str(res.get("conclusion") or ""),
                                                       "unknown"),
                          "execution": str(res.get("execution") or ""),
                          "result_manifest_id": str(res.get("manifest_id") or ""),
                          "review_status": str(res.get("review_status") or "")}
    old_finding_ids = {}
    for f in old_findings_before:
        fkey = (str(f.get("object_id") or ""), str(f.get("rule_id") or ""))
        if fkey in old_items and (f.get("status") or "") != "superseded":
            old_finding_ids.setdefault(fkey, []).append(f.get("id"))
    new_state = {(str(x.get("object_id") or ""), str(x.get("rule_code") or "")): x.get("state")
                 for x in evaluated}
    new_finding_map = {(str(x.get("object_id") or ""), str(x.get("rule_code") or "")):
                       list(x.get("finding_ids") or []) for x in evaluated}
    diff_items = []
    for key in sorted(set(old_items) | set(new_state)):
        o = old_items.get(key) or {"state": "not_audited", "conclusion": ""}
        old_state = str(o.get("state") or "not_audited")
        n_state = str(new_state.get(key) or "not_audited")
        if old_state == "not_audited" and n_state != "not_audited":
            change = "new"
        elif old_state != n_state:
            change = "changed"
        else:
            change = "unchanged"
        diff_items.append({"object_id": key[0], "rule_code": key[1],
                           "old_state": old_state, "new_state": n_state,
                           "old_conclusion": o.get("conclusion") or "",
                           "new_conclusion": _CONCLUSION_TEXT.get(n_state, "无法判断"),
                           "change_type": change, "changed": change == "changed",
                           "old_result_id": o.get("result_id") or "",
                           "old_finding_ids": old_finding_ids.get(key) or [],
                           "new_finding_ids": new_finding_map.get(key) or []})
    diff_counts = {}
    for item in diff_items:
        diff_counts[item["change_type"]] = diff_counts.get(item["change_type"], 0) + 1
    diff = {"items": diff_items,
            "changed": [x for x in diff_items if x["change_type"] == "changed"],
            "added": [x for x in diff_items if x["change_type"] == "new"],
            "not_compared": [], "unchanged": [x for x in diff_items
                                              if x["change_type"] == "unchanged"],
            "counts": diff_counts, "total": len(diff_items)}
    old_snapshot = {"manifest_ids": base_mids,
                    "results": [{"object_id": k[0], "rule_code": k[1], **v}
                                for k, v in sorted(old_items.items())],
                    "findings": [f.get("id") for f in old_findings_before
                                 if (str(f.get("object_id") or ""),
                                     str(f.get("rule_id") or "")) in old_items]}
    # finding 物化（去重：同 (case, rule, object[, 子要求]) 已有非 superseded finding → 复用，
    # 不再新增重复 finding；旧 finding 不删不改 → 这是 L46a H09「重复 finding」的关闭点。
    _existing_all = [f for f in old_findings_before
                     if str(f.get("status") or "") != "superseded"]

    def _find_existing_finding(rule_id: str, obj: str, sid: str):
        cands = [f for f in _existing_all
                 if str(f.get("rule_id") or "") == rule_id
                 and str(f.get("object_id") or "") == obj]
        exact = [f for f in cands if str(f.get("subrequirement_id") or "") == sid]
        if exact:
            return exact[0]
        if not sid:
            return cands[0] if cands else None
        loose = [f for f in cands if not str(f.get("subrequirement_id") or "")]
        return loose[0] if loose else None

    _used_finding_ids = set()
    findings_payload = []
    reused_finding_ids = []
    for entry in evaluated:
        if entry.get("state") != "fail":
            continue
        obj = str(entry.get("object_id") or "")
        code = str(entry.get("rule_code") or "")
        item = next((p.get("item") or {} for p in selected
                     if str((p.get("item") or {}).get("object_id") or "") == obj
                     and str((p.get("item") or {}).get("code") or "") == code), {})
        it = out_items.get((obj, code)) or {}
        groups = _run_item_fail_groups(it)
        for sid, rows_b in groups.items():
            prev = _find_existing_finding(code, obj, sid)
            if prev is not None and str(prev.get("id") or "") not in _used_finding_ids:
                _used_finding_ids.add(str(prev.get("id") or ""))
                reused_finding_ids.append(str(prev.get("id") or ""))
                entry["finding_ids"].append(str(prev.get("id") or ""))
                continue
            quotes = [str((x or {}).get("quote") or "") for x in rows_b
                      if str((x or {}).get("quote") or "").strip()]
            detail = "；".join(str((x or {}).get("detail") or "")
                               for x in rows_b if (x or {}).get("detail"))
            if not detail:
                detail = str((it.get("d5") or {}).get("reason") or "")
            ev_rows = [{"quote": q} for q in quotes]
            if not ev_rows:
                loc = ""
                for x in rows_b:
                    loc = str((x or {}).get("source_locator") or "").strip()
                    if loc:
                        break
                ev_rows = [{"locator": loc}] if loc else []
            synth = {"state": "fail", "reason": detail, "evidence": ev_rows,
                     "tri": entry.get("tri") or ""}
            fp = _frozen_finding_payload(case_id, item, synth, new_run_id,
                                         str(it.get("result_id") or ""), {})
            if len(groups) > 1 and sid:
                fp["row"]["title"] = (str(fp["row"].get("title") or "") + f"（{sid}）")[:80]
            fp["row"]["subrequirement_id"] = sid
            fp["row"]["engine"] = "manifest_exec.run"
            findings_payload.append(fp)
            entry["finding_ids"].append(fp["row"]["id"])
            new_finding_map[(obj, code)] = list(entry["finding_ids"])
            _used_finding_ids.add(str(fp["row"]["id"]))
    for item in diff_items:
        item["new_finding_ids"] = new_finding_map.get(
            (item.get("object_id") or "", item.get("rule_code") or ""), [])
    sev = {"critical": 0, "warning": 0, "info": 0}
    for fp in findings_payload:
        sev[str(fp["row"].get("severity") or "warning")] =             sev.get(str(fp["row"].get("severity") or "warning"), 0) + 1
    point_rows = [{"batch": batch_id, "point_id": str(x.get("rule_code") or ""),
                   "state": str(x.get("state") or "unknown"), "confidence": None,
                   "reason": str(x.get("reason") or "")[:300],
                   "quote": _first_quote(x.get("evidence"))[:200],
                   "title": str(x.get("rule_name") or x.get("rule_code") or ""),
                   "file_id": str(x.get("object_id") or "")} for x in evaluated]
    trace = {"reaudit_manifest": {
        "mode": "manifest_frozen", "execution_path": "manifest_exec.run",
        "manifest_exec_run": True, "scopeMode": scope.get("mode"),
        "base_manifest_ids": [base_mid], "manifest_id": new_mid,
        "old_run_id": str(case.get("last_run_id") or ""), "new_run_id": new_run_id,
        "activated": bool(activate), "reason": str(reason or "")[:300],
        "frozen_versions": frozen_versions, "scope": scope, "skipped": skipped,
        "evaluated": evaluated, "uncompiled": [], "diff": diff,
        "old": old_snapshot, "documents": [], "parse_errors": [],
        "closure_cloned": closure_cloned,
        "executed_audit": str(exec_out.get("executed_audit") or ""),
        "active_scope": exec_out.get("active_scope") or {},
        "finding_dedup": {"created": len(findings_payload),
                          "reused": len(reused_finding_ids)}}}
    run_payload = {"id": new_run_id, "case_id": case_id, "created_at": db.now(),
                   "created_by": str(case.get("created_by") or actor or ""),
                   "audit_type": str(case.get("audit_type") or ""),
                   "focus": str(case.get("focus") or ""),
                   "total": len(findings_payload),
                   "critical": sev.get("critical", 0),
                   "warning": sev.get("warning", 0),
                   "suspected": sev.get("info", 0),
                   "trace_json": json.dumps(trace, ensure_ascii=False, default=str),
                   "plan_json": json.dumps(
                       [{"point_id": str(x.get("rule_code") or ""),
                         "object_id": str(x.get("object_id") or ""),
                         "team": "manifest_frozen"} for x in evaluated],
                       ensure_ascii=False),
                   "batch_ids": batch_id, "manifest_id": new_mid}
    case_updates = {}
    if activate:
        case_updates = {"last_run_id": new_run_id, "last_audit_at": db.now(),
                        "status": "completed"}
    # 结果行：复用既有复审 manifest_result 口径（同 id 覆盖 run 写入行）——保留
    # gate 锁定的「每个 (object, rule) 一条结果、无子要求拆分」台账/报告可见口径，
    # 同时仍由 run 产出判定；执行证据（逐字引文）从 run 输出回填。
    results_rows = []
    for entry in evaluated:
        key = (str(entry.get("object_id") or ""), str(entry.get("rule_code") or ""))
        item = next((p.get("item") or {} for p in selected
                     if (str((p.get("item") or {}).get("object_id") or ""),
                         str((p.get("item") or {}).get("code") or "")) == key), {})
        synth = {"state": entry.get("state"),
                 "reason": entry.get("reason"),
                 "evidence": entry.get("evidence") or [],
                 "tri": entry.get("tri"), "ir_source": entry.get("ir_source")}
        results_rows.append(_frozen_result_row(new_mid, item, synth, {},
                                               list(entry.get("finding_ids") or [])))
    restore_rows = []
    for (_obj, _code) in selected_keys:
        row = old_active.get((_obj, _code)) or {}
        if row.get("id"):
            restore_rows.append({"id": row["id"], "object_id": _obj,
                                 "rule_code": _code,
                                 "d4_json": row.get("d4_json") or "{}"})
    clear_keys = [[_obj, _code] for (_obj, _code) in selected_keys
                  if not (old_active.get((_obj, _code)) or {}).get("id")]
    ledger = {}
    try:
        with db.session() as c:
            # 执行期临时 run 上已物化的 finding（collect 决策表路径）在收口事务内
            # 归属到正式复审 run，避免指向已删除的 temp run。
            if temp_run_id:
                c.execute("UPDATE finding SET run_id=? WHERE run_id=?",
                          (new_run_id, temp_run_id))
            for fp in findings_payload:
                _tx_insert_finding(c, fp["row"], case)
                _tx_insert_evidence(c, fp["row"]["id"], fp)
            try:
                if not _me_l58.d5_point_log_enabled():
                    _tx_insert_point_state(c, point_rows)
            except Exception:  # noqa: BLE001 - 降级：点态表不可写不阻断收口
                _LOG.debug("L58 reaudit point_state insert skipped", exc_info=True)
            ledger = _apply_reaudit_closure(
                c, case_id, manifest=manifest_payload, results=results_rows,
                activate=bool(activate), case_updates=case_updates,
                run=run_payload,
                manifest_exists=True, results_exist=False,
                restore_results=restore_rows, clear_active_keys=clear_keys,
                replace_sub_keys=[list(k) for k in selected_keys],
                audit={
                    "actor": actor or "system",
                    "action": "review.semantic_case_reaudited",
                    "object": case_id,
                    "before": json.dumps({"old_run_id": str(case.get("last_run_id") or ""),
                                          "scope": scope}, ensure_ascii=False),
                    "after": json.dumps({"new_run_id": new_run_id,
                                         "manifest_id": new_mid,
                                         "execution_path": "manifest_exec.run",
                                         "activated": bool(activate),
                                         "affected_pairs": len(selected),
                                         "changed": len(diff["changed"])},
                                        ensure_ascii=False),
                })
    except Exception as exc:  # noqa: BLE001 - 同一事务整体回滚 + 撤销 run 已提交副作用
        _LOG.exception("L58 定向复审收口失败 case=%s run=%s", case_id, new_run_id)
        _cleanup_reaudit_single(case_id, new_mid, new_run_id, selected_keys,
                                old_active, closure_cloned, "mid:" + new_mid,
                                temp_run_id)
        return {"ok": False, "mode": "manifest_frozen", "case_id": case_id,
                "code": "reaudit_closure_failed", "status": 500,
                "execution_path": "manifest_exec.run", "manifest_exec_run": True,
                "message": f"定向复审收口失败（已整体回滚）：{type(exc).__name__}: "
                           f"{str(exc)[:200]}",
                "new_run_id": "", "manifest_id": ""}
    # 收口成功后按新 run_id 落版本快照 v2（run 内已关闭，避免挂到旧 run）
    try:
        from . import version_snapshot as _vs_l58
        _vs_l58.save(case_id, new_run_id, actor=actor or "system")
    except Exception:  # noqa: BLE001 - 快照失败不改变已完成的复审结论
        _LOG.warning("L58 reaudit version snapshot skipped run=%s", new_run_id,
                     exc_info=True)
    old_preserved = True
    try:
        with db.session() as c:
            for p in selected:
                old_res = p.get("result") or {}
                if not old_res.get("id"):
                    continue
                row = c.execute("SELECT * FROM manifest_result WHERE id=?",
                                (old_res.get("id"),)).fetchone()
                if not row:
                    old_preserved = False
                    break
                if str(dict(row).get("conclusion") or "") != str(
                        old_res.get("conclusion") or ""):
                    old_preserved = False
                    break
    except Exception:  # noqa: BLE001
        _LOG.debug("L58 定向复审旧结果保留校验跳过", exc_info=True)
    all_findings_after = _raw_findings(case_id, new_run_id)
    new_snapshot = {"run_id": new_run_id, "manifest_id": new_mid,
                    "total_findings": len(all_findings_after),
                    "findings": [{"id": f.get("id"), "rule_id": f.get("rule_id"),
                                  "state": _normalize_state(f.get("state")),
                                  "status": f.get("status"),
                                  "object_id": f.get("object_id")}
                                 for f in all_findings_after],
                    "results": [{"result_id": r.get("id"), "object_id": r.get("object_id"),
                                 "rule_code": r.get("rule_code"),
                                 "conclusion": r.get("conclusion"),
                                 "execution": r.get("execution")}
                                for r in results_rows]}
    _l58_audit("reaudit.single_path_executed", case_id, {
        "entry": "semantic_core.reaudit_same_case",
        "execution_path": "manifest_exec.run",
        "manifest_id": new_mid, "base_manifest_id": base_mid,
        "new_run_id": new_run_id, "activated": bool(activate),
        "closure_cloned": closure_cloned,
        "active_scope": exec_out.get("active_scope") or {},
        "finding_dedup": {"created": len(findings_payload),
                          "reused": len(reused_finding_ids)},
        "executed_audit": str(exec_out.get("executed_audit") or ""),
    })
    return {"ok": True, "mode": "manifest_frozen", "case_id": case_id,
            "execution_path": "manifest_exec.run", "manifest_exec_run": True,
            "second_executor": False,
            "executed_audit": str(exec_out.get("executed_audit") or ""),
            "active_scope": exec_out.get("active_scope") or {},
            "old_run_id": str(case.get("last_run_id") or ""),
            "new_run_id": new_run_id, "batch_id": batch_id,
            "activated": bool(activate), "manifest_id": new_mid,
            "base_manifest_ids": [base_mid], "base_manifest_id": base_mid,
            "closure_cloned": closure_cloned,
            "case_last_run_id_before": str(case.get("last_run_id") or ""),
            "case_last_run_id_after": str(
                (_raw_case(case_id) or {}).get("last_run_id") or ""),
            "old": old_snapshot, "new": new_snapshot, "diff": diff,
            "evaluated": evaluated, "uncompiled": [],
            "scope": scope, "skipped": skipped, "frozen_versions": frozen_versions,
            "documents": [], "parse_errors": [], "facts_count": 0,
            "fact_issues": [],
            "new_finding_ids": [fp["row"]["id"] for fp in findings_payload],
            "reused_finding_ids": reused_finding_ids,
            "duplicate_findings": 0,
            "finding_dedup": {"created": len(findings_payload),
                              "reused": len(reused_finding_ids)},
            "ledger": {"before": {"total": (ledger.get("ledger_before") or {}).get("total"),
                                  "counts": (ledger.get("ledger_before") or {}).get("counts")},
                       "after": {"total": (ledger.get("ledger_after") or {}).get("total"),
                                 "counts": (ledger.get("ledger_after") or {}).get("counts")},
                       "active_switched": ledger.get("active_switched"),
                       "result_ids": ledger.get("result_ids")},
            "old_preserved": old_preserved, "fabricated": False,
            "note": ("定向复审走唯一执行体 manifest_exec.run（D1–D5/证据门禁/active 收口/"
                     "manifest.executed 审计同主链）；基准清单=" + base_mid
                     + ("；active/报告已同事务切到本轮结论" if activate
                        else "；未 activate：新结果作为候选保留，active/报告仍为旧结论"))}


def _l58_audit(action: str, object_: str, payload: dict) -> bool:
    """L58 审计（尽力而为；失败只 warning，不改变业务结果）。"""
    try:
        from . import single_entry as _se_l58
        return _se_l58.audit(action, object_, payload)
    except Exception:  # noqa: BLE001
        _LOG.warning("L58 audit skipped action=%s", action, exc_info=True)
        return False


def _l52_annotate_reaudit(case_id: str, out: dict, *, activate: bool = False,
                          actor: str = "") -> dict:
    """L52 ④/L58 ①：定向复审显式标注执行口径 + 审计（不改旧 finding/active 契约）。

    旧 manifest/result/finding/run 不删不改（gate `semantic_core_test` /
    `rsi_reaudit_closure_test` 锁定），``activate=True`` 时 active 只按本次选中的
    rule×object 切换。标注口径按实际执行路径区分：
    - L58 默认：``execution_path=manifest_exec.run`` / ``manifest_exec_run=True`` /
      ``second_executor=False``（唯一执行体）；
    - 回退杆 ``RULEPROOF_SEMANTIC_REAUDIT_SINGLE_PATH=0``：旧第二执行器
      ``second_executor=True`` / ``manifest_exec_run=False``；
    - 无冻结清单的旧项目：``execution_path=published_rules_fallback``（by-design）。
    开关 RULEPROOF_SINGLE_ENTRY_FIX=0 时不加任何标注（回退杆）。
    """
    if not isinstance(out, dict):
        return out
    try:
        from . import single_entry as _se
        if not _se.enabled():
            return out
        _scope = out.get("scope") or {}
        _ledger = out.get("ledger") or {}
        _exec_path = str(out.get("execution_path") or "")
        _single = bool(out.get("manifest_exec_run"))
        if not _exec_path:
            _exec_path = ("manifest_exec.run" if _single
                          else "semantic_core.manual_executor(second executor)")
        _se.annotate(
            out, execution_entry="semantic_core.reaudit_same_case",
            second_executor=not _single,
            manifest_exec_run=_single,
            execution_path=_exec_path,
            active_scope={"mode": ("manifest_scope_single" if _single
                                   else "selected_pairs_only") if activate
                          else "not_activated",
                          "activated": bool(activate),
                          "affected_pairs": int(_scope.get("affected_pairs") or 0),
                          "active_switched": _ledger.get("active_switched")})
        _se.audit("manifest.reaudit_executed", str(case_id or ""), {
            "entry": "semantic_core.reaudit_same_case",
            "mode": str(out.get("mode") or ""),
            "new_run_id": str(out.get("new_run_id") or ""),
            "manifest_id": str(out.get("manifest_id") or ""),
            "activated": bool(activate),
            "second_executor": not _single,
            "manifest_exec_run": _single,
            "execution_path": _exec_path,
            "base_manifest_id": str(out.get("base_manifest_id") or ""),
            "affected_pairs": int(_scope.get("affected_pairs") or 0),
            "changed": int((out.get("diff") or {}).get("counts", {}).get("changed") or 0)
            if isinstance(out.get("diff"), dict) else 0,
            "note": ("定向复审通过唯一执行体 manifest_exec.run 执行（含 manifest.executed "
                     "审计），active 按本次清单/run 收口；旧 manifest/result/finding/run "
                     "不删不改" if _single else
                     "定向复审读冻结清单直接执行（第二执行器；RULEPROOF_SEMANTIC_REAUDIT_"
                     "SINGLE_PATH=0 回退杆）；旧 manifest/result/finding/run 不删不改"),
        }, actor=actor or "system")
    except Exception:  # noqa: BLE001 - 标注失败不影响复审结果（但写日志）
        _LOG.warning("L52 reaudit annotation skipped case=%s", case_id, exc_info=True)
    return out


def _reaudit_from_published(case_id: str, *, actor: str = "", role: str = "",
                            rule_codes=None, activate: bool = False,
                            reason: str = "", default_batch: str = "") -> dict:
    """同一案例重审：旧 run/finding 只读保留，新建 run + 新 finding/point_state。

    - 重审范围：该租户/空间已发布规则；``rule_codes`` 可显式收窄。
    - 结论只来自 TypedFact + TypedRuleIR + 三值执行，不调用模型。
    - ``activate`` 默认 False：新 run 作为候选重审结果写入历史，不覆盖
      ``case.last_run_id``，因此默认报告/当前视图仍是旧结论。
      显式 ``activate=True`` 才把新 run 设为当前（旧 run/finding 仍在库）。
    - 返回 ``old/new/diff``；``old_preserved`` 由重审后回读旧行计算。
    """
    case = _raw_case(case_id)
    if not case:
        return {"ok": False, "code": "not_found", "status": 404,
                "message": "项目不存在"}
    if actor or role:
        try:
            from . import review as _review
            access = _review.authorize_case(case_id, "review", actor, role)
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "code": "forbidden", "status": 403,
                    "message": f"权限校验失败：{type(exc).__name__}"}
        if not access.get("ok"):
            return {"ok": False, "code": access.get("code") or "forbidden",
                    "status": int(access.get("status") or 403),
                    "message": access.get("message") or "无权重审该项目"}

    docs = _raw_case_documents(case_id)
    if not docs:
        return {"ok": False, "code": "no_documents", "status": 400,
                "message": "项目内没有可重审文件"}

    requested = []
    if isinstance(rule_codes, str):
        requested = [x.strip() for x in rule_codes.split(",") if x.strip()]
    elif rule_codes:
        requested = [str(x).strip() for x in rule_codes if str(x).strip()]

    with _case_context(case):
        old_runs = _raw_runs(case_id)
        old_run = (_raw_run(str(case.get("last_run_id") or ""))
                   or (old_runs[0] if old_runs else {}))
        old_run_id = str(old_run.get("id") or "")
        old_findings = _raw_findings(case_id, old_run_id) if old_run_id \
            else _all_case_findings(case_id)
        if old_run_id:
            # 旧链路可能留下 run_id='' 的历史结论；重审必须把它们纳入 old 快照，
            # 否则“旧结论保留”会只保留一部分。
            old_findings += [f for f in _all_case_findings(case_id)
                             if not str(f.get("run_id") or "")]
        old_batches = [x for x in str(old_run.get("batch_ids") or "").split(",") if x]
        old_point_states = _point_state_snapshot(old_batches)
        old_snapshot = _snapshot(old_run, old_findings, old_point_states, old_batches)
        old_states = _state_map(old_snapshot)
        old_reasons = _state_reason_map(old_snapshot)

        facts, document_meta, parse_errors = _parse_case_documents(docs)
        if not document_meta:
            return {"ok": False, "code": "parse_failed", "status": 400,
                    "message": "项目文件全部解析失败，未创建重审运行",
                    "documents": document_meta, "errors": parse_errors}
        if default_batch:
            facts = [ts.TypedFact.from_dict({**f.to_dict(), "batch_id": f.batch_id or default_batch})
                     for f in facts]
        fact_issues = inspect_facts(facts)

        from . import rule as _rule_scope
        rules = _rule_scope.effective_rule_rows(order="code")  # T-171 生效口径（默认 0=旧行为）
        if requested:
            wanted = set(requested)
            rules = [r for r in rules if str(r.get("code") or r.get("id") or "") in wanted]
        # B1（2026-11-20 外部对抗审查）：运行时重审与发布门禁/冻结同一作用域派生，
        # 无适用范围（且无显式历史 legacy 标记）的规则不得被执行。
        _scope_kept = []
        _scope_skipped = []
        try:
            _scope_pairs = _rule_scope.effective_rule_scopes(rules)
        except Exception:
            logging.getLogger(__name__).warning(
                "reaudit effective rule scope derive failed; execute none", exc_info=True)
            _scope_pairs = []
        for _pair in _scope_pairs:
            try:
                _r0, _der0, _sc0 = _pair
            except Exception:
                continue
            if _der0.get("declared") or _der0.get("legacy_scope_missing"):
                _scope_kept.append(_r0)
            else:
                _scope_skipped.append(str(_r0.get("code") or ""))
        if _scope_skipped:
            logging.getLogger(__name__).warning(
                "RUNTIME_SCOPE_SKIPPED(reaudit) rules=%s（未声明适用范围，不执行）",
                ",".join(_scope_skipped[:20]))
        rules = _scope_kept
        if not rules:
            return {"ok": False, "code": "no_published_rules", "status": 400,
                    "message": ("没有匹配的已发布规则，未创建重审运行"
                                if requested else "工作空间内没有已发布规则，未创建重审运行"),
                    "rule_codes": requested}

        batch_id = db.new_id("psb")
        new_run_id = db.new_id("run")
        R.audit_runs.insert(
            id=new_run_id, case_id=case_id, created_at=db.now(),
            created_by=str(case.get("created_by") or actor or ""),
            audit_type=str(case.get("audit_type") or ""),
            focus=str(case.get("focus") or ""), total=0,
            critical=0, warning=0, suspected=0)

        evaluated, uncompiled = [], []
        new_findings, state_rows = [], []
        document_id_for_evidence = str((document_meta[0] or {}).get("document_id") or "")
        try:
            for rule in rules:
                version_row = R.rules.published_version(str(rule.get("id") or "")) or {}
                version = str(version_row.get("version") or "")
                # 规则主体不含判据；判据在 rule_version.slots_json。先合并最新版本。
                seeded = dict(rule)
                slots = _json_mapping(version_row.get("slots_json"))
                if slots:
                    seeded["slots"] = slots
                merged = _merge_rule(seeded)
                code = str(merged.get("code") or merged.get("id") or "")
                try:
                    result = evaluate_rule(merged, facts=facts)
                except Exception as exc:  # noqa: BLE001
                    result = {
                        "ok": False, "rule_id": code, "state": "insufficient",
                        "verdict": "insufficient", "tri": "unknown",
                        "reason": f"execution_error: {type(exc).__name__}: {str(exc)[:200]}",
                        "reason_code": "execution_error", "detail": "", "evidence": [],
                        "ir": None, "ir_source": "none", "facts_count": len(facts),
                        "fact_issues": fact_issues,
                    }
                if not result.get("ok"):
                    uncompiled.append({
                        "rule_code": code, "rule_id": str(rule.get("id") or ""),
                        "version": version,
                        "reason_code": result.get("reason_code") or "not_compilable",
                        "reason": result.get("reason") or "",
                        "source": result.get("ir_source") or "",
                    })
                    state_rows.append({
                        "point_id": code, "state": "unknown",
                        "reason": f"不可编译：{result.get('reason_code') or ''} "
                                  f"{result.get('reason') or ''}"[:300],
                        "title": str(rule.get("name") or code),
                        "quote": "", "file_id": "",
                    })
                    continue

                # fail 必须有可回查定位；找不到证据时降为证据不足，不硬判失败。
                if result.get("state") == "fail" and not _has_locator(result.get("evidence")):
                    result = dict(result)
                    result.update({
                        "state": "insufficient", "verdict": "insufficient",
                        "reason_code": "evidence_missing",
                        "reason": "evidence_missing: 结论缺少 quote/row/span，按证据不足处理",
                    })
                state_rows.append({
                    "point_id": code, "state": result.get("state") or "unknown",
                    "reason": str(result.get("reason") or "")[:300],
                    "title": str(rule.get("name") or code),
                    "quote": _first_quote(result.get("evidence"))[:200],
                    "file_id": "",
                })
                finding_ids = []
                if result.get("state") == "fail":
                    finding_id = db.new_id("fnd")
                    title = str(merged.get("name") or code or "语义重审")
                    conclusion = (result.get("ir") or {}).get("conclusion") or {}
                    if isinstance(conclusion, Mapping) and conclusion.get("fail"):
                        title = f"{title}：{conclusion['fail']}"
                    R.findings.insert(
                        id=finding_id, case_id=case_id, rule_id=code,
                        rule_version=version, severity=_severity_of(merged),
                        certainty="deterministic", confidence=1.0, state="fail",
                        status="pending", title=title[:200],
                        summary=str(result.get("reason") or "")[:500],
                        suggestion="", grade="", engine="semantic_core",
                        run_id=new_run_id, point_id=code,
                        object_id=document_id_for_evidence or "")
                    _insert_finding_evidence(finding_id, document_id_for_evidence,
                                             title, result.get("evidence"))
                    new_findings.append(finding_id)
                    finding_ids.append(finding_id)
                evaluated.append({
                    "rule_code": code, "rule_id": str(rule.get("id") or ""),
                    "rule_name": str(merged.get("name") or ""),
                    "version": version,
                    "state": result.get("state"), "tri": result.get("tri"),
                    "reason_code": result.get("reason_code"),
                    "reason": result.get("reason"),
                    "evidence": result.get("evidence") or [],
                    "ir_source": result.get("ir_source"),
                    "ir": result.get("ir"),
                    "finding_ids": finding_ids,
                })
        except Exception as exc:  # noqa: BLE001
            _LOG.exception("同案例重审执行失败 case=%s run=%s", case_id, new_run_id)
            R.audit_runs.update(new_run_id, trace_json=json.dumps(
                {"semantic_reaudit": {"error": f"{type(exc).__name__}: {str(exc)[:300]}"}},
                ensure_ascii=False))
            return {"ok": False, "code": "reaudit_failed", "status": 500,
                    "message": f"重审执行失败：{type(exc).__name__}: {str(exc)[:200]}",
                    "new_run_id": new_run_id}

        pstates.record(batch_id, state_rows)
        new_snapshot = _snapshot(
            {"id": new_run_id, "created_at": db.now(), "batch_ids": batch_id},
            _raw_findings(case_id, new_run_id), _point_state_snapshot([batch_id]), [batch_id])
        new_states = {item["rule_code"]: item["state"] for item in evaluated}
        new_reasons = {item["rule_code"]: item["reason"] for item in evaluated}
        new_finding_map = {}
        for item in evaluated:
            if item.get("finding_ids"):
                new_finding_map[item["rule_code"]] = list(item["finding_ids"])
        uncompiled_map = {item["rule_code"]: item for item in uncompiled}

        all_codes = sorted(set(old_states) | set(new_states) | set(uncompiled_map))
        diff_items = []
        for code in all_codes:
            old_state = old_states.get(code, "not_audited")
            if code in uncompiled_map:
                new_state = "not_evaluated"
            else:
                new_state = new_states.get(code, "not_audited")
            if old_state == "not_audited" and new_state not in ("not_audited", "not_evaluated"):
                change_type = "new"
            elif new_state == "not_evaluated":
                change_type = "not_compared"
            elif old_state != new_state:
                change_type = "changed"
            else:
                change_type = "unchanged"
            changed = bool(change_type == "changed")
            diff_items.append({
                "rule_code": code,
                "old_state": old_state,
                "new_state": new_state,
                "change_type": change_type,
                "changed": changed,
                "old_reason": old_reasons.get(code, "")[:300],
                "new_reason": (new_reasons.get(code)
                               or (uncompiled_map.get(code) or {}).get("reason") or "")[:300],
                "reason_code": (next((x.get("reason_code") for x in evaluated
                                      if x.get("rule_code") == code), "")
                                or (uncompiled_map.get(code) or {}).get("reason_code") or ""),
                "old_finding_ids": [f.get("id") for f in (old_snapshot.get("findings") or [])
                                    if str(f.get("rule_id") or "") == code],
                "new_finding_ids": new_finding_map.get(code, []),
            })

        diff_counts = {}
        for item in diff_items:
            diff_counts[item["change_type"]] = diff_counts.get(item["change_type"], 0) + 1
        diff = {
            "items": diff_items,
            "changed": [x for x in diff_items if x["change_type"] == "changed"],
            "added": [x for x in diff_items if x["change_type"] == "new"],
            "not_compared": [x for x in diff_items if x["change_type"] == "not_compared"],
            "unchanged": [x for x in diff_items if x["change_type"] == "unchanged"],
            "counts": diff_counts,
            "total": len(diff_items),
        }

        # 新 run 的统计与 trace：旧行不写、不删、不 supersede。
        sev = {"critical": 0, "warning": 0, "info": 0}
        for finding in _raw_findings(case_id, new_run_id):
            key = str(finding.get("severity") or "warning")
            sev[key] = sev.get(key, 0) + 1
        trace = {
            "semantic_reaudit": {
                "mode": "semantic_core",
                "old_run_id": old_run_id,
                "new_run_id": new_run_id,
                "batch_id": batch_id,
                "activated": bool(activate),
                "reason": str(reason or "")[:300],
                "rule_codes": [str(r.get("code") or "") for r in rules],
                "evaluated": evaluated,
                "uncompiled": uncompiled,
                "diff": diff,
                "old": old_snapshot,
                "new": new_snapshot,
                "facts_count": len(facts),
                "fact_issues": fact_issues,
                "documents": document_meta,
                "parse_errors": parse_errors,
            }
        }
        R.audit_runs.update(
            new_run_id, total=len(new_findings), critical=sev.get("critical", 0),
            warning=sev.get("warning", 0), suspected=sev.get("info", 0),
            trace_json=json.dumps(trace, ensure_ascii=False),
            batch_ids=batch_id,
            plan_json=json.dumps({
                "mode": "semantic_core",
                "rules": [{"code": str(x.get("code") or ""),
                           "version": str((R.rules.published_version(str(x.get("id") or "")) or {})
                                          .get("version") or ""),
                           "ir_source": next((e.get("ir_source") for e in evaluated
                                              if e.get("rule_code") == str(x.get("code") or "")), ""),
                           } for x in rules],
            }, ensure_ascii=False))

        case_last_before = str(case.get("last_run_id") or "")
        if activate:
            R.cases.update(case_id, last_run_id=new_run_id, last_audit_at=db.now(),
                           status="completed")
        case_after = _raw_case(case_id)
        old_run_after = _raw_run(old_run_id) if old_run_id else {}
        old_findings_after = [_raw_finding(str(f.get("id") or "")) for f in old_findings]
        old_preserved = bool(
            (not old_run_id or old_run_after == old_run)
            and all(after == before for before, after in
                    zip(old_findings, old_findings_after)))
        try:
            R.audit_logs.log(
                actor=actor or "system", action="review.semantic_case_reaudited",
                object=case_id,
                before=json.dumps({"old_run_id": old_run_id,
                                   "last_run_id": case_last_before}, ensure_ascii=False),
                after=json.dumps({"new_run_id": new_run_id, "activated": bool(activate),
                                  "changed": len(diff["changed"]),
                                  "added": len(diff["added"]),
                                  "uncompiled": len(uncompiled)}, ensure_ascii=False))
        except Exception:  # noqa: BLE001
            _LOG.debug("重审审计日志写入失败", exc_info=True)

        return {
            "ok": True,
            "mode": "semantic_core",
            "case_id": case_id,
            "old_run_id": old_run_id,
            "new_run_id": new_run_id,
            "batch_id": batch_id,
            "activated": bool(activate),
            "case_last_run_id_before": case_last_before,
            "case_last_run_id_after": str(case_after.get("last_run_id") or ""),
            "old": old_snapshot,
            "new": new_snapshot,
            "diff": diff,
            "evaluated": evaluated,
            "uncompiled": uncompiled,
            "fact_issues": fact_issues,
            "facts_count": len(facts),
            "documents": document_meta,
            "parse_errors": parse_errors,
            "new_finding_ids": new_findings,
            "old_preserved": old_preserved,
            "fabricated": False,
            "note": "旧 run/finding 保留；新 run 默认不设为当前，除非 activate=True",
        }
