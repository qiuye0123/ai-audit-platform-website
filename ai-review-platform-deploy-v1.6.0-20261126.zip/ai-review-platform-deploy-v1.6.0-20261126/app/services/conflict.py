"""冲突提醒：规则之间的一致性检测、裁决与留痕。

检测类型：
  numeric_conflict  同一作用域同一指标，约束区间无交集        → 严重
  duplicate         同一作用域同一指标同一约束（完全重复）    → 一般
  unit_mismatch     同一指标单位不一致，无法比较              → 一般（无法判定）
  scope_conflict    同指标同约束但作用域相交（可能重复约束）  → 提示

冲突在规则发布时自动检测（实时提醒），也可手动全量检测。

T-63（20261117）冲突详情与裁决：
  - GET 聚合详情：冲突头 / A、B 规则完整快照（六组字段）/ 差异 / 证据影响 /
    裁决与历史 / 关联冲突；规则快照与规则库详情同源读取，不另造字段。
  - 裁决 6 路径：rule_a / rule_b / both_wrong / both_valid / need_more / ignored。
  - both_wrong = 两条规则都下线（archived；保留规则/版本/审计，不物理删除），
    生成「重新新建规则」待办与预填上下文；新规则必须重新草稿→审批→发布。
  - need_more 保持 open；both_valid 关闭冲突但不动规则；ignored 保留原因。
  - 每次裁决写审计；同一裁决重复提交幂等（不重复写审计/重复关规则）。
  - 服务端强制权限：admin 本租户+本空间；reviewer 仅本人规则/本人项目/
    本人反馈相关；super_admin / platform_op 不可裁决。
"""
import hashlib
import json
import logging
import os

from .. import db
from .. import repositories as R
from . import audit as _audit_svc
from ..engine import conflict as C

TYPE_LABEL = {
    "numeric_conflict": "限值矛盾", "duplicate": "重复规则",
    "unit_mismatch": "单位不一致", "scope_conflict": "作用域重叠",
    "priority_conflict": "优先级冲突",
}
SEVERITY_LABEL = {"critical": "严重", "warning": "一般", "info": "提示"}
STATUS_LABEL = {"open": "待处理", "resolved": "已裁决", "ignored": "已忽略"}

# 6 条裁决路径（用户确认口径）。expected action 是旧 API 的兼容动作：
# rule_a/rule_b/both_wrong/both_valid → resolved；need_more → open（保持 open）；
# ignored → ignored。
RESOLUTIONS = ("rule_a", "rule_b", "both_wrong", "both_valid", "need_more", "ignored")
RESOLUTION_LABEL = {
    "rule_a": "规则 A 正确（B 需修订）",
    "rule_b": "规则 B 正确（A 需修订）",
    "both_wrong": "两者都不对（关闭两条规则，重新新建）",
    "both_valid": "两者都对（约束可同时成立）",
    "need_more": "证据不足（保持待处理）",
    "ignored": "忽略（保留原因，不关闭规则）",
}
RESOLUTION_DESC = {
    "rule_a": "确认 A 的判据正确；B 判据错误，需另行修订/下线（本次不自动改动 B）。",
    "rule_b": "确认 B 的判据正确；A 判据错误，需另行修订/下线（本次不自动改动 A）。",
    "both_wrong": "确认两条规则判据都错误：两条规则按现有生命周期下线（archived，保留版本/审计，不物理删除），并生成重新新建规则入口。",
    "both_valid": "确认两条规则可同时成立（如作用域/期间不同），关闭冲突但不修改规则状态。",
    "need_more": "证据/制度依据不足，暂不裁决；冲突保持待处理，后续可再次裁决。",
    "ignored": "确认该冲突无需处理（误报/重复检测），保留原因并关闭冲突；规则状态不变。",
}
RESOLUTION_ACTION = {"rule_a": "resolved", "rule_b": "resolved",
                     "both_wrong": "resolved", "both_valid": "resolved",
                     "need_more": "open", "ignored": "ignored"}
ACTION_TO_RESOLUTION = {"ignored": "ignored", "open": "need_more"}

# 「两者都不对」影响面确认覆盖：项目（case）/点位/引用（规则版本与命中证据）
IMPACT_DIGEST_FIELDS = ("projects", "points", "findings", "feedback", "references")

RECREATE_SOURCE = "conflict_recreate"

ROLE_LABEL = {"admin": "业务管理员", "reviewer": "审核员",
              "super_admin": "系统管理员", "platform_op": "平台管理员"}


class ConflictError(ValueError):
    """带 HTTP 状态码的裁决/详情错误；server.py 据此返回 400/403/404/409。"""

    def __init__(self, status: int, message: str, code: str = "invalid_conflict"):
        super().__init__(message)
        self.status = status
        self.message = message
        self.code = code


def _user_role(user: dict | None) -> str:
    return str((user or {}).get("role") or "")


def _user_sub(user: dict | None) -> str:
    return str((user or {}).get("sub") or "")


def _user_names(user: dict | None) -> set:
    u = user or {}
    return {str(x) for x in (u.get("sub"), u.get("name"), u.get("username")) if str(x or "").strip()}


def _ctx_ids() -> tuple[str, str]:
    try:
        from . import ctx as _ctx
        c = _ctx.get_context() or {}
        return c.get("tenant_id") or "", c.get("workspace_id") or ""
    except Exception:
        return "", ""


def _scope_of(user: dict | None = None, all_spaces: bool = False) -> tuple[str, str]:
    """请求作用域：优先线程上下文（HTTP 会话已按当前空间设置），再用会话兜底。"""
    tenant, workspace = _ctx_ids()
    u = user or {}
    tenant = tenant or str(u.get("tenant_id") or "")
    workspace = "" if all_spaces else (workspace or str(u.get("workspace_id") or ""))
    return tenant, workspace


def _digest(payload) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _raw_conflict(conflict_id: str) -> dict | None:
    cid = str(conflict_id or "").strip()
    if not cid:
        return None
    with db.session() as c:
        row = c.execute("SELECT * FROM conflict WHERE id=?", (cid,)).fetchone()
        return dict(row) if row else None


def _json_load(value, default):
    try:
        if isinstance(value, (dict, list)):
            return value
        v = json.loads(value or "")
        return v if isinstance(v, type(default)) else default
    except Exception:
        return default


def _row_closed_ids(row: dict) -> list:
    raw = (row or {}).get("closed_rule_ids") or ""
    ids = _json_load(raw, [])
    return [str(x) for x in ids if str(x or "").strip()] if isinstance(ids, list) else []


def _row_recreate(row: dict) -> dict:
    task = _json_load((row or {}).get("recreate_task") or "", {})
    return task if isinstance(task, dict) else {}


def _conflict_rules(codes: list) -> list:
    """把冲突两侧的 rule_a/rule_b 解析成规则行；决策表行编码（如 DT#1）不解析为规则。"""
    out = []
    for code in codes:
        code = str(code or "").strip()
        row = None
        if code and "#" not in code:
            try:
                rows = R.rules.list("code=?", (code,))
                row = rows[0] if rows else None
            except Exception:
                row = None
        out.append(row)
    return out



def _slots(rule_row: dict) -> dict:
    try:
        v = R.rule_versions.list("rule_id=?", (rule_row["id"],), order="id DESC")
        if not v:
            return {}
        return json.loads(v[0].get("slots_json") or "{}")
    except Exception:
        return {}


def _period_overlap(a, b) -> bool:
    """粗略判断两个生效期间是否重叠；缺省视为重叠（不因此放过冲突）。"""
    def rng(x):
        try:
            if isinstance(x, (list, tuple)) and len(x) == 2:
                return str(x[0]), str(x[1])
            return str(x), str(x)
        except Exception:
            return "", ""
    a0, a1 = rng(a); b0, b1 = rng(b)
    if not a0 or not b0:
        return True
    return not (a1 < b0 or b1 < a0)


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _bounds(slots: dict):
    op = str(slots.get("op") or "").strip()
    val = _num(slots.get("value"))
    if val is None:
        return None
    if op in (">=", "≥", ">="):
        return (val, None)
    if op in ("<=", "≤"):
        return (None, val)
    if op in (">",):
        return (val, None)
    if op in ("<",):
        return (None, val)
    if op in ("=", "=="):
        return (val, val)
    return None


def _bounds_strict(slots: dict):
    """返回 (lo, hi, lo_open, hi_open)，保留严格比较的端点开闭。"""
    b = _bounds(slots)
    if b is None:
        return None
    op = str(slots.get("op") or "").strip()
    return b[0], b[1], op == ">", op == "<"


def _metric_key(slots: dict) -> str:
    return str(slots.get("metric") or slots.get("parameter") or "").strip()


def _scope_key(slots: dict) -> str:
    return str(slots.get("scope") or slots.get("process") or "").strip()


def analyze_rules(rule_rows: list, persist: bool = False) -> list:
    """纯函数入口：对给定规则列表做两两检测，返回「每对规则」的结论列表。

    每项含 type：已证明冲突 / 未发现冲突 / 需人工确认（供报告与测试使用）。
    """
    rules = []
    for _r0 in rule_rows:
        r = dict(_r0)
        if not (r.get("code") or r.get("name")):
            r["code"] = r.get("rule_id") or r.get("code") or "?"
            r["name"] = r.get("name") or r["code"]
        if isinstance(r.get("slots"), dict):
            slots = r["slots"]
        elif r.get("metric") or r.get("op") or r.get("require") or r.get("forbid"):
            slots = r            # 直接传入槽位
        else:
            slots = _slots(r)
        if not slots:
            continue
        rules.append({"rule": r, "slots": slots})
    res = _detect_pairs(rules, False)
    hit = {(c["a"], c["b"]): c for c in res.get("conflicts", [])}
    out = []
    for i in range(len(rules)):
        for j in range(i + 1, len(rules)):
            a, b = rules[i], rules[j]
            ca = a["rule"].get("code") or a["rule"].get("rule_id") or ""
            cb = b["rule"].get("code") or b["rule"].get("rule_id") or ""
            c = hit.get((ca, cb)) or hit.get((cb, ca))
            if c:
                label = {"numeric_conflict": "互斥冲突",
                         "duplicate": "重复冗余",
                         "unit_mismatch": "疑似重叠", "scope_conflict": "疑似重叠",
                         "priority_conflict": "疑似重叠"}.get(
                             c["type"], "疑似重叠")
                out.append({**c, "type": label, "_raw_type": c["type"]})
            else:
                out.append({"a": ca, "b": cb, "type": "未发现冲突", "severity": "info",
                            "detail": "两条规则约束无交集冲突"})
    return out


def check_rule(rule_id_or_code: str) -> list:
    """新规则入库时，与当前工作空间内所有已有规则做一次即时冲突检查。

    只提醒、不阻断入库；返回与当前规则相关的冲突项，供创建接口/UI 提示。
    """
    try:
        from . import ctx as _cx
        _cur = _cx.get_context() or {}
        _wid = _cur.get("workspace_id") or ""
    except Exception:
        _wid = ""
    row = R.rules.get(rule_id_or_code) if hasattr(R, "rules") else None
    if not row:
        try:
            row = next((x for x in R.rules.list("code=?", (rule_id_or_code,)) if not _wid or (x.get("workspace_id") or "") == _wid), None)
        except Exception:
            row = None
    if not row:
        return []
    mine = dict(row)
    mine["slots"] = _slots(row)
    if not mine["slots"]:
        return []
    items = [mine]
    try:
        for other in R.rules.list():
            if other.get("id") == mine.get("id") or other.get("code") == mine.get("code"):
                continue
            if _wid and (other.get("workspace_id") or "") != _wid:
                continue
            slots = _slots(other)
            if not slots:
                continue
            o = dict(other); o["slots"] = slots; items.append(o)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    if len(items) < 2:
        return []
    res = analyze_rules(items)
    code = mine.get("code") or mine.get("id")
    return [x for x in res if x.get("type") in ("已证明冲突", "重复冗余", "疑似重叠")
            and code in (x.get("a"), x.get("b"))]


# ------------------------------------------------- 检测状态（T-164 / 评审 C-4）---
# 评审 C-4：detect() 异常被吞后，「未检完/检测失败」与「检完无冲突」都返回 0 条，
# 报告门禁只查已登记冲突 → 「无冲突」不可证。每次检测在这里落一行状态（conflict_check），
# 报告门禁按最新状态区分：
#   最新 = ok                         → 检测已完成（放行；冲突是否已裁决由原门禁另管）
#   最新 ∈ failed / partial / running → 检测未完成（阻断，需重跑）
#   无任何记录                        → 从未检测（阻断；老库升级后首次报告即此情况，
#                                       执行一次 ./rp conflict-check run 后解除）
CONFLICT_CHECK_ENV = "RULEPROOF_CONFLICT_GATE_REQUIRE_CHECK"
CONFLICT_CHECK_HINT = ("执行一次全量冲突检测：`./rp conflict-check run`"
                       "（HTTP：POST /api/v1/conflicts/detect）")
# L109（2026-11-25）：conflict_check 表/索引 DDL 单一事实源 = app/db.py 的
# CONFLICT_CHECK_SCHEMA（init_db 建基线、运行期 ensure 同源），本模块不再内联副本。
_CHECK_TABLE_READY = False


def _check_table_exists() -> bool:
    try:
        with db.session() as c:
            row = c.execute("SELECT name FROM sqlite_master WHERE type='table' "
                            "AND name='conflict_check'").fetchone()
        return bool(row)
    except Exception:
        return False


def _ensure_check_table() -> bool:
    """init_db 会建表（旧库幂等补表）；这里再兜一次底，保证长期运行进程/临时库也能落状态。"""
    global _CHECK_TABLE_READY
    if _CHECK_TABLE_READY:
        return True
    try:
        with db.session() as c:
            db.ensure_runtime_schema(c, "conflict_check")
        _CHECK_TABLE_READY = True
        return True
    except Exception:
        logging.getLogger(__name__).warning("conflict_check schema init failed", exc_info=True)
        return False


def _gate_require_check() -> bool:
    """报告门禁是否要求「本工作空间有成功的冲突检测记录」。默认 1（修复口径）。

    回滚：RULEPROOF_CONFLICT_GATE_REQUIRE_CHECK=0 → 回到旧行为（只查已登记
    unresolved_critical_conflict，「无检测记录」不阻断）。
    """
    raw = (os.environ.get(CONFLICT_CHECK_ENV) or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


def _check_scope_defaults() -> tuple:
    try:
        from . import ctx as _cx
        _c0 = _cx.get_context() or {}
        _tid = str(_c0.get("tenant_id") or "")
        _wid = str(_c0.get("workspace_id") or "")
    except Exception:
        _tid, _wid = "", ""
    return (_tid or "t-default", _wid or "ws-default")


def _insert_check(scope: str, status: str = "running", rule_id: str = "",
                  rule_version_id: str = "", error: str = "",
                  conflicts_found: int = 0, conflicts_new: int = 0,
                  detail: dict | None = None,
                  tenant_id: str = "", workspace_id: str = "") -> str:
    """落一行检测状态；留痕失败不抛（检测主流程不能因留痕失败而中断），返回行 id。

    租户/空间可显式覆盖（报告门禁惰性检测时按案例归属落库，不依赖请求上下文）。
    """
    if not _ensure_check_table():
        return ""
    tid, wid = _check_scope_defaults()
    tid = str(tenant_id or tid)
    wid = str(workspace_id or wid)
    cid = db.new_id("cfchk")
    try:
        with db.session() as c:
            c.execute(
                "INSERT INTO conflict_check(id,scope,rule_id,rule_version_id,status,error,"
                "checked_at,conflicts_found,conflicts_new,detail_json,tenant_id,workspace_id) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (cid, str(scope or "full"), str(rule_id or ""), str(rule_version_id or ""),
                 str(status or "running"), str(error or "")[:2000], db.now(),
                 int(conflicts_found or 0), int(conflicts_new or 0),
                 json.dumps(detail or {}, ensure_ascii=False), tid, wid))
        return cid
    except Exception:
        logging.getLogger(__name__).warning("conflict_check record insert failed scope=%s",
                                            scope, exc_info=True)
        return ""


def _finish_check(check_id: str, status: str, error: str = "",
                  conflicts_found: int = 0, conflicts_new: int = 0,
                  detail: dict | None = None, audit: dict | None = None) -> None:
    """更新检测状态行；``audit`` 非空时在同一事务内写审计（P1-B4-01）。

    为什么审计写在 conflict_check 的同一事务：评审要求「检测是业务写操作，必须留痕」，
    把状态行最终状态与「谁跑了检测/扫了多少规则/新增几条冲突」放在一起提交，避免出现
    「状态已更新但审计丢失」或反之。冲突行本身由 _detect_pairs 各自事务写入（既有实现），
    这里保证「检测结果状态 + 审计」原子。
    """
    if not check_id:
        return
    try:
        with db.session() as c:
            c.execute(
                "UPDATE conflict_check SET status=?, error=?, checked_at=?, "
                "conflicts_found=?, conflicts_new=?, detail_json=? WHERE id=?",
                (str(status or "ok"), str(error or "")[:2000], db.now(),
                 int(conflicts_found or 0), int(conflicts_new or 0),
                 json.dumps(detail or {}, ensure_ascii=False), check_id))
            if audit:
                _audit_svc.log_in_tx(c, str(audit.get("actor") or "system"),
                                     str(audit.get("action") or "conflict.detect"),
                                     object_=check_id,
                                     before=str(audit.get("before") or ""),
                                     after=str(audit.get("after") or ""))
    except Exception:
        logging.getLogger(__name__).warning("conflict_check record update failed id=%s",
                                            check_id, exc_info=True)


def record_check_failure(scope: str = "publish", rule_id: str = "",
                         rule_version_id: str = "", error=None,
                         detail: dict | None = None) -> dict:
    """检测入口之外发生异常时的兜底留痕（发布路径调用；不许只写 debug 日志）。"""
    msg = (f"{type(error).__name__}: {error}" if isinstance(error, BaseException)
           else str(error or ""))
    cid = _insert_check(scope, "failed", rule_id=rule_id,
                        rule_version_id=rule_version_id, error=msg, detail=detail)
    logging.getLogger(__name__).warning(
        "conflict_check failed recorded scope=%s rule=%s error=%s", scope, rule_id, msg)
    # P1-B4-01：失败也要留痕（谁在何时跑的检测 + 失败原因），否则「没冲突」不可证。
    try:
        with db.session() as c:
            _audit_svc.log_in_tx(
                c, "system", "conflict.detect_failed", object_=cid,
                after=json.dumps({"scope": scope, "rule_id": rule_id,
                                  "rule_version_id": rule_version_id,
                                  "status": "failed", "error": msg[:300]},
                                 ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).warning(
            "conflict.detect_failed audit skipped id=%s", cid, exc_info=True)
    return {"id": cid, "scope": scope, "status": "failed", "error": msg}


def _latest_check_row(tenant_id: str = "", workspace_id: str = "") -> dict:
    if not _ensure_check_table():
        return {}
    tid = str(tenant_id or "")
    wid = str(workspace_id or "")
    try:
        with db.session() as c:
            if tid and wid:
                row = c.execute(
                    "SELECT * FROM conflict_check WHERE tenant_id=? AND workspace_id=? "
                    "ORDER BY checked_at DESC, rowid DESC LIMIT 1", (tid, wid)).fetchone()
            else:
                row = c.execute("SELECT * FROM conflict_check "
                                "ORDER BY checked_at DESC, rowid DESC LIMIT 1").fetchone()
        return dict(row) if row else {}
    except Exception:
        logging.getLogger(__name__).warning("conflict_check latest query failed", exc_info=True)
        return {}


def list_checks(limit: int = 20) -> list:
    if not _ensure_check_table():
        return []
    try:
        with db.session() as c:
            rows = c.execute("SELECT * FROM conflict_check ORDER BY checked_at DESC, "
                             "rowid DESC LIMIT ?", (max(1, int(limit)),)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def report_gate_status(case_id: str = "", tenant_id: str = "",
                       workspace_id: str = "") -> dict:
    """报告门禁的「冲突检测状态」口径（唯一事实源，report_gate / CLI 共用）。

    **惰性检测（T-164 / 评审 C-4，口径按 lead 2026-11-19 决策）**：
      ① 开关 RULEPROOF_CONFLICT_GATE_REQUIRE_CHECK=0 → 不启用（完全回到旧行为，仅查
         unresolved_critical_conflict）；
      ② 本工作空间有最新记录且 status=ok → 放行；
      ③ 最新记录 status ∈ failed / partial / running → 阻断（带 error 文案，不许当成已满足）；
      ④ 本工作空间**无记录**（老库升级后首次/全新空间）→ **先自动跑一次
         detect(persist=True) 并落状态**，再按结果判定：
           成功 → status=ok → 放行（out['lazy_detect'] 标记「本次报告前已自动检测」）；
           异常 → status=failed → 阻断（错误可读）。
         即「未检测」被变成「真的检一次」，而不是把「未检完」当「无冲突」。
    """
    out = {"enabled": _gate_require_check(), "ok": True, "status": "",
           "reason": "", "checked_at": "", "scope": "", "conflicts_found": 0,
           "error": "", "record": {}, "command": "rp conflict-check run",
           "switch": CONFLICT_CHECK_ENV, "lazy_detect": None,
           "hint": CONFLICT_CHECK_HINT}
    if not out["enabled"]:
        out["note"] = (f"开关 {CONFLICT_CHECK_ENV}=0：冲突检测状态门禁未启用"
                       "（回滚口径，仅保留旧门禁：已登记 unresolved_critical_conflict）")
        return out
    tid, wid = str(tenant_id or ""), str(workspace_id or "")
    if case_id and not (tid and wid):
        try:
            case = R.cases.get(case_id) or {}
            tid = tid or str(case.get("tenant_id") or "")
            wid = wid or str(case.get("workspace_id") or "")
        except Exception:  # noqa: BLE001 —— 取不到项目归属时回落到上下文/默认租户，不静默
            logging.getLogger(__name__).warning(
                "conflict_check gate case scope lookup failed case=%s", case_id,
                exc_info=True)
    if not tid or not wid:
        _dtid, _dwid = _check_scope_defaults()
        tid, wid = tid or _dtid, wid or _dwid
    out["tenant_id"], out["workspace_id"] = tid, wid
    if not _check_table_exists():
        # 旧库未建表时先幂等补表（与 init_db 同一 DDL），再走惰性检测；补表失败才阻断。
        if not _ensure_check_table():
            out.update(ok=False, status="missing_table", reason=(
                "冲突检测状态表 conflict_check 不存在且自动建表失败（数据库不可写/未初始化），"
                "「无冲突」不可证，正式报告已阻断。请先执行 `./rp --db <库> init` 完成建表，"
                "再执行一次全量冲突检测：`./rp conflict-check run`。"))
            return out
    row = _latest_check_row(tid, wid)
    if not row:
        # ④ 惰性检测：无记录 → 报告前真检一次（「未检测」变「检完」，不是放行也不是硬拦）
        out["lazy_detect"] = {"executed": True, "ok": None, "status": "",
                              "note": "报告门禁发现本工作空间无冲突检测记录，已自动执行一次全量检测"}
        try:
            detect(persist=True, scope="full", tenant_id=tid, workspace_id=wid)
        except Exception as _exc:  # noqa: BLE001 —— 检测失败落 failed 状态并阻断（错误可读）
            _err = f"{type(_exc).__name__}: {_exc}"
            out.update(ok=False, status="failed", error=_err,
                       lazy_detect={"executed": True, "ok": False, "status": "failed",
                                    "error": _err},
                       reason=(
                           f"报告前自动冲突检测失败（{_err}）：无法证明「无冲突」，"
                           "正式报告已阻断。请修复检测报错后重跑：`./rp conflict-check run`"
                           "（查看最近记录：`./rp conflict-check status`）。"))
            return out
        row = _latest_check_row(tid, wid)
        if not row:
            out.update(ok=False, status="missing",
                       lazy_detect={"executed": True, "ok": False, "status": "missing"},
                       reason=(
                           "报告前自动冲突检测未留下状态记录（数据库写入异常），"
                           "「无冲突」不可证，正式报告已阻断；请执行 `./rp conflict-check run` 排查。"))
            return out
        out["lazy_detect"] = {
            "executed": True, "ok": str(row.get("status") or "") == "ok",
            "status": str(row.get("status") or ""),
            "conflicts_found": int(row.get("conflicts_found") or 0),
            "checked_at": str(row.get("checked_at") or ""),
            "note": ("本次报告前已自动执行一次全量冲突检测并记录状态"
                     f"（status={row.get('status')}，conflicts_found={row.get('conflicts_found') or 0}）")}
        out["note"] = out["lazy_detect"]["note"]
    out["record"] = {k: row.get(k) for k in (
        "id", "scope", "rule_id", "rule_version_id", "status", "error",
        "checked_at", "conflicts_found", "conflicts_new", "tenant_id", "workspace_id")}
    out.update(checked_at=str(row.get("checked_at") or ""),
               scope=str(row.get("scope") or ""),
               conflicts_found=int(row.get("conflicts_found") or 0),
               error=str(row.get("error") or ""))
    status = str(row.get("status") or "")
    out["status"] = status
    if status == "ok":
        return out
    if status == "failed":
        out["ok"] = False
        out["reason"] = (
            f"冲突检测失败（conflict_check.status=failed，时间 {out['checked_at'] or '未知'}）："
            f"{out['error'] or '未记录错误'} → 无法证明「无冲突」，正式报告已阻断。"
            "请修复检测报错后重跑：`./rp conflict-check run`"
            "（查看最近记录：`./rp conflict-check status`）。")
        return out
    if status == "partial":
        out["ok"] = False
        out["reason"] = (
            f"冲突检测未检完（conflict_check.status=partial，时间 {out['checked_at'] or '未知'}）："
            "部分规则未被检测 → 无法证明「无冲突」，正式报告已阻断。"
            "请重跑：`./rp conflict-check run`。")
        return out
    if status == "running":
        out["ok"] = False
        out["reason"] = (
            f"冲突检测仍在进行中（conflict_check.status=running，开始 {out['checked_at'] or '未知'}）："
            "检测未完成前不能证明「无冲突」，正式报告已阻断；请等待检测结束后重试。")
        return out
    out["ok"] = False
    out["reason"] = (f"冲突检测状态异常（conflict_check.status={status or '空'}）："
                     "无法证明「无冲突」，正式报告已阻断。请重跑：`./rp conflict-check run`。")
    return out


def detect(persist: bool = True, *, rule_id: str = "",
           rule_version_id: str = "", scope: str = "full",
           tenant_id: str = "", workspace_id: str = "", actor: str = "") -> dict:
    """只对当前工作空间已发布规则做两两检测，不跨空间比较。

    T-164 / 评审 C-4：每次检测都落 conflict_check 状态（running → ok/failed/partial），
    成功与失败都可证；异常不再只留在 debug 日志里（继续上抛，调用方可感知）。
    ``tenant_id``/``workspace_id`` 可选覆盖上下文（报告门禁惰性检测按案例归属落库）。
    ``actor``：P1-B4-01 审计要求——检测是业务写（可能新增 conflict 行并影响报告门禁），
    必须回答「谁在何时跑的检测、扫了多少规则、新增几条冲突」；HTTP/CLI 传真实用户，
    服务内部调用（发布后自动检测）传规则发布人，系统任务传 'system'。
    """
    _check_id = _insert_check(scope, "running", rule_id=rule_id,
                              rule_version_id=rule_version_id,
                              tenant_id=tenant_id, workspace_id=workspace_id)
    _load_errors = 0
    rules: list = []
    try:
        try:
            from . import ctx as _cx
            _c0 = _cx.get_context() or {}
            _tid, _wid = _c0.get("tenant_id") or "", _c0.get("workspace_id") or ""
        except Exception:
            _tid, _wid = "", ""
        if tenant_id:
            _tid = str(tenant_id)
        if workspace_id:
            _wid = str(workspace_id)
        for r in R.rules.list():
            # T-107：发布后提醒只比较「当前生效规则」（current_version_id 且 published），
            # 与 manifest/执行同口径；草稿/已下线不参与，避免把未生效内容误报为冲突。
            try:
                v = R.rules.published_version(r.get("id") or "") or {}
            except Exception:
                _load_errors += 1
                v = {}
            if not v:
                continue
            if _wid and (r.get("workspace_id") or "") != _wid:
                continue
            if _tid and (r.get("tenant_id") or "") not in ("", _tid):
                continue
            slots = {}
            try:
                slots = json.loads(v.get("slots_json") or "{}")
            except Exception:
                slots = {}
            if not isinstance(slots, dict) or not slots:
                continue
            rule_row = dict(r)
            rule_row["effective_version"] = v.get("version") or ""
            rule_row["effective_version_id"] = v.get("id") or ""
            rules.append({"rule": rule_row, "slots": slots})
        res = _detect_pairs(rules, persist)
    except Exception as _exc:
        _finish_check(_check_id, "failed", error=f"{type(_exc).__name__}: {_exc}",
                      detail={"rules_scanned": len(rules), "persist": bool(persist),
                              "scope": scope},
                      audit=_detect_audit(actor, "conflict.detect_failed", scope,
                                          len(rules), 0, 0, bool(persist),
                                          error=f"{type(_exc).__name__}: {_exc}"))
        raise
    _status = "partial" if _load_errors else "ok"
    _detail = {"rules_scanned": len(rules), "persist": bool(persist), "scope": scope,
               "rules_unreadable": _load_errors,
               "critical": int(res.get("critical") or 0)}
    _err = ""
    if _load_errors:
        _err = f"{_load_errors} 条规则的生效版本读取失败，检测不完整（partial）"
        _detail["error"] = _err
    _found = len(res.get("conflicts") or [])
    _finish_check(_check_id, _status, error=_err,
                  conflicts_found=_found,
                  detail=_detail,
                  audit=_detect_audit(actor, "conflict.detect", scope, len(rules),
                                      _found, _found if persist else 0, bool(persist),
                                      error=_err))
    return res


def _detect_audit(actor: str, action: str, scope: str, rules_scanned: int,
                  found: int, new: int, persist: bool, error: str = "") -> dict:
    """检测审计载荷（P1-B4-01）：谁 / 范围 / 扫了多少 / 找到/新增几条 / 是否落库。"""
    try:
        from . import ctx as _cx
        _c0 = _cx.get_context() or {}
        _tid, _wid = _c0.get("tenant_id") or "", _c0.get("workspace_id") or ""
    except Exception:
        _tid, _wid = "", ""
    _after = {"rules_scanned": int(rules_scanned or 0), "found": int(found or 0),
              "new": int(new or 0), "scope": str(scope or ""),
              "persist": bool(persist),
              "tenant": _tid, "workspace": _wid}
    if error:
        _after["error"] = str(error)[:300]
    logging.getLogger(__name__).info("conflict %s actor=%s %s", action, actor or "system", _after)
    return {"actor": actor or "system", "action": action,
            "after": json.dumps(_after, ensure_ascii=False)}


def _detect_pairs(rules: list, persist: bool = False) -> dict:
    found = []
    for i in range(len(rules)):
        for j in range(i + 1, len(rules)):
            a, b = rules[i], rules[j]
            sa, sb = a["slots"], b["slots"]
            # 文本类条件（require/forbid）：同对象一要求一禁止 → 冲突
            ra_txt, rb_txt = str(sa.get("require") or sa.get("forbid") or ""), str(sb.get("require") or sb.get("forbid") or "")
            if ra_txt and ra_txt == rb_txt:
                pa = "require" if sa.get("require") else ("forbid" if sa.get("forbid") else "")
                pb = "require" if sb.get("require") else ("forbid" if sb.get("forbid") else "")
                if pa and pb and pa != pb:
                    found.append({"type": "numeric_conflict", "severity": "critical",
                                  "a": a["rule"]["code"], "b": b["rule"]["code"],
                                  "detail": f"文本条件互斥：一条要求「{ra_txt}」，另一条禁止同一内容",
                                  "suggestion": "确认该内容应被要求还是禁止"})
                    continue
            ma, mb = _metric_key(sa), _metric_key(sb)
            if not ma or ma != mb:
                continue
            # 生效期间不重叠 → 两条规则不会同时适用，不构成冲突
            if not _period_overlap(sa.get("effective_period"), sb.get("effective_period")):
                continue
            # 优先级不同 → 由优先级裁决，不判“已证明”，仅提示人工确认
            if sa.get("priority") and sb.get("priority") and sa.get("priority") != sb.get("priority"):
                found.append({"type": "priority_conflict", "severity": "warning",
                              "a": a["rule"]["code"], "b": b["rule"]["code"],
                              "detail": f"指标「{ma}」优先级不同（{sa.get('priority')} vs {sb.get('priority')}），需按优先级裁决",
                              "suggestion": "确认优先级设置是否符合制度"})
                continue
            ra, rb = a["rule"], b["rule"]
            item = None
            if _scope_key(sa) != _scope_key(sb):
                # 作用域不同：只有指标与约束完全相同才算重叠提示
                if _bounds_strict(sa) == _bounds_strict(sb) and _bounds_strict(sa) is not None:
                    item = {"type": "scope_conflict", "severity": "info",
                            "detail": f"指标「{ma}」在两个作用域（{_scope_key(sa) or '未限定'} / {_scope_key(sb) or '未限定'}）"
                                      f"上约束相同，可能存在重复约束",
                            "suggestion": "确认两条规则是否覆盖不同场景；若相同请合并或停用其一"}
                else:
                    continue
            elif str(sa.get("unit") or "") != str(sb.get("unit") or ""):
                item = {"type": "unit_mismatch", "severity": "warning",
                        "detail": f"同一指标「{ma}」单位不一致（{sa.get('unit') or '未标注'} vs {sb.get('unit') or '未标注'}），无法比较",
                        "suggestion": "统一单位后重新检测"}
            elif str(sa.get("op") or "") == "in" and str(sb.get("op") or "") == "in":
                sa_set = {str(x) for x in (sa.get("values") or [])}
                sb_set = {str(x) for x in (sb.get("values") or [])}
                if sa_set and sb_set:
                    if sa_set == sb_set:
                        item = {"type": "duplicate", "severity": "warning",
                                "detail": f"「{ma}」取值集合完全相同：{sorted(sa_set)}",
                                "suggestion": "两条规则等价，建议停用其一"}
                    elif not (sa_set & sb_set):
                        item = {"type": "numeric_conflict", "severity": "critical",
                                "detail": f"「{ma}」允许集合互斥：{sorted(sa_set)} vs {sorted(sb_set)}",
                                "suggestion": "确认正确的取值集合，修订其中一条"}
                else:
                    continue
            else:
                ba, bb = _bounds_strict(sa), _bounds_strict(sb)
                if ba is None or bb is None:
                    continue
                same_op = str(sa.get("op") or "").strip() == str(sb.get("op") or "").strip()
                same_val = _num(sa.get("value")) is not None and _num(sa.get("value")) == _num(sb.get("value"))
                if same_op and same_val:
                    item = {"type": "duplicate", "severity": "warning",
                            "detail": f"「{ma}」约束完全重复：{sa.get('op')}{sa.get('value')}{sa.get('unit') or ''}",
                            "suggestion": "两条规则等价，建议停用其一"}
                else:
                    lo = max(ba[0] if ba[0] is not None else -float("inf"),
                             bb[0] if bb[0] is not None else -float("inf"))
                    hi = min(ba[1] if ba[1] is not None else float("inf"),
                             bb[1] if bb[1] is not None else float("inf"))
                    if lo > hi or (lo == hi and (ba[2] or ba[3] or bb[2] or bb[3])):
                        item = {"type": "numeric_conflict", "severity": "critical",
                                "detail": f"同一作用域「{_scope_key(sa)}」指标「{ma}」约束矛盾："
                                          f"{ra['code']} {sa.get('op')}{sa.get('value')}{sa.get('unit') or ''} "
                                          f"与 {rb['code']} {sb.get('op')}{sb.get('value')}{sb.get('unit') or ''} 无交集",
                                "suggestion": "确认哪个阈值正确，修订或停用其中一条规则"}
            if not item:
                continue
            key = "-".join(sorted([ra["code"], rb["code"]])) + "|" + item["type"]
            cid = "cf-" + str(abs(hash(key)) % (10 ** 12))
            item.update({"id": cid, "a": ra["code"], "b": rb["code"], "a_name": ra["name"], "b_name": rb["name"],
                         "slots_a": sa, "slots_b": sb})
            found.append(item)

    # 决策表冲突：同为数值条件且区间互斥、或完全重复
    dt_found = []
    try:
        from . import decision_table as _dt
        tables = [t for t in _dt.list_tables() if t.get("status") == "published"]
        conds = []
        for t in tables:
            row = _dt.get(t["code"])
            for i, r in enumerate(json.loads(row.get("rules_json") or "[]")):
                for c in r.get("when") or []:
                    if c.get("op") in (">=", "<=", ">", "<", "range", "=") and c.get("metric"):
                        conds.append({"table": t["code"], "row": i + 1, "cond": c,
                                      "msg": r.get("message", "")})
        for i in range(len(conds)):
            for j in range(i + 1, len(conds)):
                a, b = conds[i], conds[j]
                ca, cb = a["cond"], b["cond"]
                if ca.get("metric") != cb.get("metric"):
                    continue
                ba, bb = _bounds_strict(ca), _bounds_strict(cb)
                if not ba or not bb:
                    continue
                if ba == bb:
                    dt_found.append({"a": f"{a['table']}#{a['row']}", "b": f"{b['table']}#{b['row']}",
                                     "type": "duplicate", "severity": "warning",
                                     "detail": f"决策表条件重复：{ca.get('metric')} {ca.get('op')}{ca.get('value')}",
                                     "suggestion": "两条决策行等价，建议合并"})
                else:
                    lo = max(ba[0] if ba[0] is not None else -1e18, bb[0] if bb[0] is not None else -1e18)
                    hi = min(ba[1] if ba[1] is not None else 1e18, bb[1] if bb[1] is not None else 1e18)
                    if lo > hi or (lo == hi and (ba[2] or ba[3] or bb[2] or bb[3])):
                        dt_found.append({"a": f"{a['table']}#{a['row']}", "b": f"{b['table']}#{b['row']}",
                                         "type": "numeric_conflict", "severity": "critical",
                                         "detail": f"决策表条件互斥：{ca.get('metric')} 区间无交集",
                                         "suggestion": "确认哪个阈值正确，修订其中一行"})
    except Exception:
        dt_found = []
    found = found + dt_found
    # 统一补全：决策表冲突条目没有 id / 名称 / slots，这里补齐，避免落库时 KeyError
    for x in found:
        if not x.get("id"):
            key = f"{x.get('a','')}-{x.get('b','')}|{x.get('type','')}"
            x["id"] = "cf-" + str(abs(hash(key)) % (10 ** 12))
        x.setdefault("a_name", "")
        x.setdefault("b_name", "")
        x.setdefault("slots_a", {})
        x.setdefault("slots_b", {})
        x.setdefault("suggestion", "")
        x.setdefault("severity", "warning")

    if persist:
        try:
            from . import ctx as _ctx
            _c0 = _ctx.get_context() or {}
            _tid0, _wid0 = _c0.get("tenant_id") or "", _c0.get("workspace_id") or ""
        except Exception:
            _tid0, _wid0 = "", ""
        for x in found:
            with db.session() as c:
                row = c.execute("SELECT status, COALESCE(resolution,'') AS resolution "
                                "FROM conflict WHERE id=?", (x["id"],)).fetchone()
                if row and (row["status"] in ("resolved", "ignored")
                            or str(row["resolution"] or "") == "need_more"):
                    continue  # 已裁决/已记录证据不足的不重复打开、不覆盖裁决记录
                payload = (x["detail"] + (f"（{x['a_name']} / {x['b_name']}）" if x["a_name"] else ""),
                           x["type"], x["severity"], x["suggestion"],
                           json.dumps(x["slots_a"], ensure_ascii=False),
                           json.dumps(x["slots_b"], ensure_ascii=False))
                if row:
                    # 已存在且未裁决：只刷新检测描述，保留 resolution/note/历史（T-63）
                    c.execute("UPDATE conflict SET rule_a=?, rule_b=?, detail=?, type=?, "
                              "severity=?, suggestion=?, slots_a=?, slots_b=? WHERE id=?",
                              (x["a"], x["b"], payload[0], payload[1], payload[2],
                               payload[3], payload[4], payload[5], x["id"]))
                else:
                    c.execute(
                        "INSERT INTO conflict(id,rule_a,rule_b,type,detail,status,created_at,"
                        "severity,suggestion,slots_a,slots_b,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (x["id"], x["a"], x["b"], payload[1], payload[0], "open", db.now(),
                         payload[2], payload[3], payload[4], payload[5], _tid0, _wid0))
        if found:
            try:
                from . import notify
                n_crit = sum(1 for x in found if x["severity"] == "critical")
                if n_crit:
                    notify.notify_role("admin", "rule.conflict",
                                       f"检测到 {n_crit} 条规则限值矛盾",
                                       "请在「规则引擎 → 冲突提醒」中裁决")
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"rules": len(rules), "conflicts": found,
            "critical": sum(1 for x in found if x["severity"] == "critical")}


def detect_after_publish(rule_id: str, rule_version_id: str = "", actor: str = "") -> dict:
    """规则发布后自动检测（实时提醒）。

    T-164 / 评审 C-4：成功与失败都落 conflict_check 状态（scope='publish'，带规则/版本定位）。
    失败时显式告警并继续上抛，由发布方（rule.publish）记录可见状态，不再只写 debug 日志。
    P1-B4-01：``actor`` 透传给 detect 写审计（发布人 = 触发检测的人）。
    """
    try:
        return detect(persist=True, rule_id=rule_id,
                      rule_version_id=rule_version_id, scope="publish", actor=actor)
    except Exception as _exc:  # noqa: BLE001 —— 记录失败状态后原样上抛
        record_check_failure(scope="publish", rule_id=rule_id,
                             rule_version_id=rule_version_id, error=_exc)
        raise


# ---------------------------------------------------------------- 规则快照（六组字段）
# 与规则库详情同源：rule 行 + 生效/最新 rule_version(scope_json/slots_json/evidence_json)
# + findings/feedback/版本/审计；不另造“冲突专用规则字段”，保证 A/B 快照与规则库一致。

def _latest_version(rule_row: dict) -> dict:
    try:
        rows = R.rule_versions.list("rule_id=?", (rule_row.get("id"),), order="id DESC")
        return rows[0] if rows else {}
    except Exception:
        return {}


def _effective_version(rule_row: dict) -> dict:
    """生效版本口径（P0-01）：current_version_id 且 published 优先。

    与 manifest/执行/规则库同口径：**不看 rule.status**——编辑已发布规则后
    rule.status=draft，但旧 published 版本继续生效；archived 规则
    ``published_version`` 返回 None，回退最新版本仅用于快照展示（并标注无生效版本）。
    """
    try:
        v = R.rules.published_version((rule_row or {}).get("id") or "")
        if v:
            return v
    except Exception:
        logging.getLogger(__name__).debug('published version lookup failed', exc_info=True)
    return _latest_version(rule_row)


def _version_rows(rule_row: dict) -> list:
    try:
        rows = R.rule_versions.list("rule_id=?", (rule_row.get("id"),), order="id DESC")
    except Exception:
        rows = []
    out = []
    for v in rows:
        out.append({
            "id": v.get("id") or "",
            "version": v.get("version") or "",
            "status": v.get("status") or "",
            "published_at": v.get("published_at") or "",
            "approved_at": v.get("approved_at") or "",
            "approved_by": v.get("approved_by") or "",
            "superseded_at": v.get("superseded_at") or "",
        })
    return out


def _tax_label() -> dict:
    try:
        from . import rule_taxonomy as _rt
        return dict(_rt.CATEGORY_LABELS or {})
    except Exception:
        return {}


def _field(label: str, value) -> dict:
    """六组字段的通用字段项：空值不隐藏（前端显示“未填写/未配置”，与规则库口径一致）。"""
    if isinstance(value, (list, tuple)):
        value = "、".join(str(x) for x in value if str(x or "").strip())
    if isinstance(value, dict):
        value = json.dumps(value, ensure_ascii=False)
    text = "" if value is None else str(value).strip()
    return {"label": label, "value": text, "empty": not bool(text)}


def _rule_findings(codes: list) -> list:
    out = []
    if not codes:
        return out
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT f.*, cs.name AS case_name, cs.created_by AS case_created_by, "
                "cs.tenant_id AS case_tenant_id, cs.workspace_id AS case_workspace_id "
                "FROM finding f LEFT JOIN audit_case cs ON cs.id=f.case_id "
                "WHERE f.rule_id IN (?,?) ORDER BY f.rowid DESC LIMIT 500",
                (str(codes[0] or ""), str(codes[1] or ""))).fetchall()
            out = [dict(r) for r in rows]
    except Exception:
        logging.getLogger(__name__).debug('rule findings lookup failed', exc_info=True)
    return out


def _rule_feedback(codes: list) -> list:
    out = []
    for code in codes:
        if not str(code or "").strip():
            continue
        try:
            rows = R.feedback.list("rule_code=?", (str(code),), order="created_at DESC", limit=100)
        except Exception:
            rows = []
        for r in rows:
            out.append({"id": r.get("id") or "", "rule_code": r.get("rule_code") or "",
                        "kind": r.get("kind") or "", "title": r.get("title") or "",
                        "actor": r.get("actor") or "", "case_id": r.get("case_id") or "",
                        "created_at": r.get("created_at") or ""})
    return out


def _rule_points(rule_row: dict, scope: dict) -> list:
    out = []
    mapping = (scope or {}).get("point_mapping") or {}
    if mapping.get("point_id"):
        out.append({"point_id": mapping.get("point_id") or "",
                    "point_name": mapping.get("point_name") or "",
                    "source": "rule_scope_mapping"})
    # P2-17：点位映射按 rule_id 主键读取，并带租户/空间隔离条件；不再只按
    # rule_code 全库读取（多租户同码规则会串用）。旧兼容行仅在当前规则作用域内匹配。
    rid = str(rule_row.get("id") or "")
    tid = str(rule_row.get("tenant_id") or "")
    wid = str(rule_row.get("workspace_id") or "")
    try:
        with db.session() as c:
            if rid:
                rows = [dict(r) for r in c.execute(
                    "SELECT * FROM rule_point_mapping WHERE rule_id=? "
                    "AND (?='' OR COALESCE(tenant_id,'')=?) "
                    "AND (?='' OR COALESCE(workspace_id,'')=?) "
                    "ORDER BY rowid DESC LIMIT 50",
                    (rid, tid, tid, wid, wid)).fetchall()]
                code = str(rule_row.get("code") or "")
                if code and tid:
                    rows += [dict(r) for r in c.execute(
                        "SELECT * FROM rule_point_mapping WHERE rule_id='' AND rule_code=? "
                        "AND COALESCE(tenant_id,'')=? AND COALESCE(workspace_id,'')=? "
                        "ORDER BY rowid DESC LIMIT 50", (code, tid, wid)).fetchall()]
            else:
                rows = []
    except Exception:
        rows = []
    for r in rows or []:
        pid = r.get("point_id") or ""
        if pid and not any(x["point_id"] == pid for x in out):
            out.append({"point_id": pid, "point_name": r.get("point_name") or "",
                        "source": "rule_point_mapping"})
    return out


def _rule_audits(rule_row: dict, limit: int = 10) -> list:
    out = []
    try:
        rows = R.audit_logs.list("object=?", (rule_row.get("id") or "",),
                                 order="created_at DESC", limit=limit)
    except Exception:
        rows = []
    for r in rows:
        out.append({"action": r.get("action") or "", "actor": r.get("actor") or "",
                    "at": r.get("created_at") or "", "detail": (r.get("after_json") or "")[:300]})
    return out


def rule_snapshot(value) -> dict:
    """规则完整快照（六组字段）：RuleDefinition / Scope / ExecutionPlan / Evidence /
    Lifecycle / Usage。value 可以是 rule 行、rule id 或 code；找不到返回 found=False。"""
    row = value if isinstance(value, dict) and value.get("id") else None
    code = str(value or "") if not isinstance(value, dict) else str(value.get("code") or "")
    if row is None and code:
        try:
            rows = R.rules.list("code=?", (code,))
            row = rows[0] if rows else None
            if not row and "#" not in code:
                row = R.rules.get(code)
        except Exception:
            row = None
    if not row:
        return {"found": False, "code": code, "reason": "规则不存在或不在当前范围",
                "groups": [], "flat": {}}
    version = _effective_version(row)
    slots = _json_load(version.get("slots_json") or "", {})
    if not isinstance(slots, dict):
        slots = {}
    evidence_json = _json_load(version.get("evidence_json") or "", [])
    scope = _json_load(row.get("scope_json") or "", {})
    if not isinstance(scope, dict):
        scope = {}
    mapping = scope.get("point_mapping") or {}
    try:
        from .execution_plan import derive as _derive
        plan = _derive(slots)
    except Exception:
        plan = {}
    try:
        from . import rule_ir as _ir
        exec_check = _ir.classify_executability(slots) if slots else {}
    except Exception:
        exec_check = {}
    labels = _tax_label()
    category = str(row.get("category") or "")
    findings = _rule_findings([row.get("code") or "", ""])
    feedback = _rule_feedback([row.get("code") or ""])
    points = _rule_points(row, scope)
    versions = _version_rows(row)
    form = str(scope.get("form") or ("decision_table" if slots.get("when") or slots.get("conditions") else "single"))
    form_label = "决策表组合多条件" if form == "decision_table" else "单条参数规则"
    required_evidence = (slots.get("required_evidence") or slots.get("required_evidence_list")
                         or slots.get("evidence") or scope.get("evidence") or "")
    if isinstance(required_evidence, (list, tuple)):
        required_evidence = "、".join(str(x) for x in required_evidence if str(x or "").strip())
    exceptions = slots.get("exceptions") or []
    if isinstance(exceptions, str):
        exceptions = [exceptions]
    tags = scope.get("tags") or []
    if not isinstance(tags, list):
        tags = [tags] if tags else []
    applicable_types = slots.get("applicable_types") or scope.get("applicable_types") or []
    if not isinstance(applicable_types, (list, tuple)):
        applicable_types = [applicable_types] if applicable_types else []
    def _label(kind: str, value: str) -> str:
        try:
            from . import rule as _rule_lbl
            return (_rule_lbl.status_label(value) if kind == "rule"
                    else _rule_lbl.version_status_label(value))
        except Exception:
            fallback = ({"draft": "草稿", "pending": "待审批", "approved": "已批准",
                         "published": "已发布", "archived": "已下线"} if kind == "rule" else
                        {"draft": "草稿", "pending": "待审批", "approved": "已批准",
                         "published": "已发布", "superseded": "已被替代"})
            return fallback.get(str(value or ""), str(value or ""))

    _eff_status = ("published" if str(version.get("status") or "") == "published"
                   else "archived" if str(row.get("status") or "") == "archived"
                   else "none")
    flat = {
        "id": row.get("id") or "",
        "code": row.get("code") or "",
        "name": row.get("name") or "",
        "category": category,
        "category_label": labels.get(category, category),
        "template": str(scope.get("template") or slots.get("_template") or category),
        "rclass": row.get("rclass") or "",
        "severity": str(scope.get("severity") or (slots.get("severity") or "")),
        "source": row.get("source") or "",
        "owner": row.get("owner") or "",
        "owner_id": row.get("owner_id") or "",
        "department": "",
        "status": row.get("status") or "",
        "status_label": _label("rule", row.get("status") or ""),
        "rule_status": row.get("status") or "",
        "effective_version": version.get("version") if _eff_status == "published" else "",
        "effective_version_id": version.get("id") if _eff_status == "published" else "",
        "effective_status": _eff_status,
        "effective_status_label": {"published": "已发布（生效中）",
                                   "archived": "已下线（不执行）",
                                   "none": "无生效版本"}.get(_eff_status, ""),
        "form": form,
        "form_label": form_label,
        "form_reason": str(scope.get("form_reason") or ""),
        "description": str(scope.get("description") or scope.get("desc") or ""),
        "tags": [str(x) for x in tags if str(x or "").strip()],
        "scope_text": str(slots.get("scope") or slots.get("process") or scope.get("scope") or ""),
        "scope": str(slots.get("scope") or slots.get("process") or scope.get("scope") or ""),
        "applicable_when": str(slots.get("applicable_when") or scope.get("applicable_when") or ""),
        "applicable_types": [str(x) for x in applicable_types if str(x or "").strip()],
        "workspace_id": row.get("workspace_id") or "",
        "tenant_id": row.get("tenant_id") or "",
        "point_id": str(mapping.get("point_id") or ""),
        "point_name": str(mapping.get("point_name") or ""),
        "point_mapping": ("人工指定" if mapping.get("override") else
                          "自动映射" if mapping.get("mapped") else "未映射"),
        "criterion": str(slots.get("criterion") or slots.get("text") or ""),
        "metric": str(slots.get("metric") or slots.get("parameter") or ""),
        "op": str(slots.get("op") or slots.get("operator") or ""),
        "value": ("" if slots.get("value") is None else str(slots.get("value"))),
        "unit": str(slots.get("unit") or ""),
        "priority": ("" if slots.get("priority") is None else str(slots.get("priority"))),
        "effective_period": slots.get("effective_period") or "",
        "aggregation": str(plan.get("aggregation") or slots.get("aggregation") or ""),
        "evaluation_kind": str(plan.get("evaluation_kind") or slots.get("evaluation_kind")
                               or slots.get("method") or ""),
        "fallback": str(plan.get("fallback") or slots.get("fallback") or ""),
        "evidence_scope": plan.get("evidence_scope") or [],
        "required_evidence": str(required_evidence or ""),
        "evidence_list": [str(x) for x in (
            slots.get("required_evidence_list") or scope.get("evidence_list") or [])
            if str(x or "").strip()],
        "positive_example": str(scope.get("positive_example") or ""),
        "negative_example": str(scope.get("negative_example") or ""),
        "exceptions": [str(x) for x in exceptions if str(x or "").strip()],
        "combination": str(slots.get("combination") or slots.get("combine") or "all"),
        "nature": str(scope.get("nature") or ""),
        "version": version.get("version") or "",
        "version_id": version.get("id") or "",
        "version_status": version.get("status") or "",
        "version_status_label": _label("version", version.get("status") or ""),
        "current_version_id": row.get("current_version_id") or "",
        "created_at": row.get("created_at") or "",
        "hit_count": len(findings),
        "override_count": sum(1 for f in findings if str(f.get("status") or "") == "false_positive"),
        "feedback_count": len(feedback),
        "versions": versions,
    }
    structured = []
    for k, v in slots.items():
        if str(k).startswith("_") or k in ("criterion", "text", "when", "conditions"):
            continue
        if isinstance(v, (dict, list)):
            text = json.dumps(v, ensure_ascii=False)
        else:
            text = str(v)
        if text.strip():
            structured.append({"key": k, "value": text})
    groups = [
        {"key": "definition", "label": "规则定义", "fields": [
            _field("规则名称", flat["name"]), _field("规则编码", flat["code"]),
            _field("判定模板", flat["category_label"]), _field("规则形式", flat["form_label"]),
            _field("形式判断依据", flat["form_reason"]), _field("风险等级", flat["rclass"]),
            _field("规则性质", flat["nature"]), _field("来源", flat["source"]),
            _field("负责人", flat["owner"] or flat["owner_id"]),
            _field("所属空间", flat["workspace_id"]),
        ]},
        {"key": "scope", "label": "适用范围", "fields": [
            _field("规则说明", flat["description"]),
            _field("检索/路由标签", flat["tags"]),
            _field("作用域", flat["scope_text"]),
            _field("适用条件", flat["applicable_when"]),
            _field("适用文档类型", flat["applicable_types"]),
            _field("指定点位", (flat["point_id"] + (" · " + flat["point_name"]
                                                    if flat["point_name"] else ""))),
            _field("点位映射方式", flat["point_mapping"]),
            _field("正例", flat["positive_example"]),
            _field("反例", flat["negative_example"]),
        ]},
        {"key": "execution_plan", "label": "执行计划", "fields": [
            _field("判据", flat["criterion"]),
            _field("指标", flat["metric"]),
            _field("比较符", flat["op"]),
            _field("目标值", (flat["value"] + (" " + flat["unit"] if flat["unit"] else ""))),
            _field("单位", flat["unit"]),
            _field("优先级", flat["priority"]),
            _field("生效期间", flat["effective_period"]),
            _field("证据范围", flat["evidence_scope"]),
            _field("汇总方式", flat["aggregation"]),
            _field("判定方式", flat["evaluation_kind"]),
            _field("证据不足处理", flat["fallback"]),
            _field("组合方式", flat["combination"]),
            _field("例外", flat["exceptions"]),
        ], "slots": structured, "plan": plan},
        {"key": "evidence", "label": "证据要求", "fields": [
            _field("必需证据", flat["required_evidence"]),
            _field("结构化证据清单", flat["evidence_list"]),
            _field("结构化证据记录", (evidence_json if isinstance(evidence_json, list) else [])),
            _field("可执行性", (exec_check.get("level") or "")),
            _field("可执行性缺口", exec_check.get("missing") or exec_check.get("missing_evidence") or []),
        ]},
        {"key": "lifecycle", "label": "生命周期与版本", "fields": [
            _field("当前状态", flat["status_label"]),
            _field("当前生效版本", flat["version"]),
            _field("版本状态", flat["version_status"]),
            _field("版本数", len(versions)),
            _field("创建时间", flat["created_at"]),
            _field("最近审计", "；".join(
                f"{x['action']}@{x['at'][:16]}" for x in _rule_audits(row, limit=3))),
        ], "versions": versions},
        {"key": "usage", "label": "关联与使用", "fields": [
            _field("命中问题数", flat["hit_count"]),
            _field("人工 override 数", flat["override_count"]),
            _field("反馈数", flat["feedback_count"]),
            _field("引用点位", [f"{p['point_id']} {p['point_name']}".strip() for p in points]),
        ], "points": points, "feedback": feedback[:20]},
    ]
    return {"found": True, "code": flat["code"], "id": flat["id"],
            "groups": groups, "flat": flat, "slots": slots, "scope": scope,
            "plan": plan, "versions": versions, "points": points}


def _diff_items(snap_a: dict, snap_b: dict) -> list:
    """A/B 差异对比（阈值/op/单位/作用域/优先级/版本 + 判据/类别/证据/状态）。"""
    a = (snap_a or {}).get("flat") or {}
    b = (snap_b or {}).get("flat") or {}
    specs = [
        ("metric", "指标"), ("op", "比较符"), ("value", "阈值"), ("unit", "单位"),
        ("scope", "作用域"), ("priority", "优先级"),
        ("effective_period", "生效期间"), ("criterion", "判据"),
        ("category_label", "判定模板"), ("form_label", "规则形式"),
        ("rclass", "风险等级"), ("source", "来源"), ("status_label", "规则状态"),
        ("version", "当前版本"), ("point_id", "指定点位"),
        ("aggregation", "汇总方式"), ("evaluation_kind", "判定方式"),
        ("fallback", "证据不足处理"), ("required_evidence", "必需证据"),
        ("applicable_when", "适用条件"),
    ]
    seen, out = set(), []
    for key, label in specs:
        if key in seen:
            continue
        seen.add(key)
        va, vb = a.get(key), b.get(key)
        if isinstance(va, (list, tuple)):
            va = "、".join(str(x) for x in va)
        if isinstance(vb, (list, tuple)):
            vb = "、".join(str(x) for x in vb)
        sa, sb = ("" if va is None else str(va)).strip(), ("" if vb is None else str(vb)).strip()
        if not sa and not sb:
            continue
        out.append({"key": key, "label": label, "a": sa, "b": sb,
                    "same": sa == sb, "diff": sa != sb})
    return out


# ---------------------------------------------------------------- 权限与关联

def _reviewer_relations(codes: list, user: dict | None) -> dict:
    """审核员「本人规则/本人项目/本人反馈」关联；admin 不调用（其范围=本租户+本空间）。"""
    sub = _user_sub(user)
    names = _user_names(user)
    codes = [str(c or "") for c in codes if str(c or "").strip()]
    owned = []
    rule_rows = _conflict_rules(codes)
    for row in rule_rows:
        if not row:
            continue
        oid = str(row.get("owner_id") or "").strip()
        if oid and sub and oid == sub:
            owned.append(row.get("code") or "")
        elif not oid and names & {str(row.get("owner") or "").strip()}:
            owned.append(row.get("code") or "")
    owned = [x for x in owned if x]
    # 本人项目：这些规则在“本人创建的项目”里产生过 finding（真实审核引用）
    projects = {}
    for f in _rule_findings(codes):
        if str(f.get("case_created_by") or "") != sub:
            continue
        cid = str(f.get("case_id") or "")
        if cid and cid not in projects:
            projects[cid] = {"case_id": cid, "name": f.get("case_name") or "",
                             "status": f.get("case_status") or "",
                             "rule_codes": [str(f.get("rule_id") or "")]}
        elif cid:
            rc = str(f.get("rule_id") or "")
            if rc and rc not in projects[cid]["rule_codes"]:
                projects[cid]["rule_codes"].append(rc)
    feedback = []
    for fb in _rule_feedback(codes):
        if str(fb.get("actor") or "") in names:
            feedback.append(fb)
    return {"is_related": bool(owned or projects or feedback),
            "owned_rules": owned,
            "projects": list(projects.values()),
            "feedback": feedback,
            "checked_rules": [r.get("code") for r in rule_rows if r]}


def _reviewer_relations_batch(all_codes: list, user: dict | None):
    """批量版 ``_reviewer_relations``：一次取齐全部冲突的关系判定数据。

    背景（P1-B8-01 首页）：``list_conflicts`` 对每个冲突调 ``_can_resolve`` →
    ``_reviewer_relations``，每条冲突再各查 ~5 次 SQL（规则行/本人项目 finding/
    本人反馈）。1000 冲突时 reviewer 首页 6.4s 里 4.3s 来自这里。
    本函数把规则行、finding、feedback 按全部 code 一次性批量取回后在内存组装；
    返回 ``resolve(rule_a, rule_b)``，逐字段结构与 ``_reviewer_relations`` 完全一致：
      · 规则行：``R.rules.list("code IN (...)")``，每 code 取 rowid 最早一行 = 旧
        ``R.rules.list("code=?" )[0]``（含租户/全局规则隔离，走同一 repository）；
      · finding：全量 code 一次查询按 rowid DESC，再按每个 pair 截前 500 条
        （等价于旧 ``WHERE rule_id IN (?,?) ... LIMIT 500``）；
      · feedback：逐 code 各查 1 次（旧实现每条冲突查 2 次），按 created_at DESC
        取前 100，再按 pair 顺序拼接；actor 命中口径不变。
    仅当调用方整体只读一致快照时才使用（list_conflicts 单次调用内）。
    """
    sub = _user_sub(user)
    names = _user_names(user)
    codes, seen = [], set()
    for c in all_codes or []:
        c = str(c or "").strip()
        if c and c not in seen:
            seen.add(c)
            codes.append(c)

    # 1) 规则行（含 tenant/global 隔离，与 _conflict_rules → R.rules.list 同源）
    row_by_code = {}
    if codes:
        try:
            ph = ",".join("?" * len(codes))
            rows = R.rules.list(f"code IN ({ph})", tuple(codes))
        except Exception:
            logging.getLogger(__name__).debug('batch conflict rules lookup failed', exc_info=True)
            rows = []
        for r in rows:  # R.rules.list 未指定 ORDER：SQLite 自然 rowid 序 → 首行=最早
            code = str(r.get("code") or "")
            if code and code not in row_by_code:
                row_by_code[code] = r
    owned_by_code = {}
    for code in codes:
        row = row_by_code.get(code)
        if not row:
            continue
        oid = str(row.get("owner_id") or "").strip()
        if oid and sub and oid == sub:
            owned_by_code[code] = True
        elif not oid and names & {str(row.get("owner") or "").strip()}:
            owned_by_code[code] = True

    # 2) finding：全量 code 一次查询（rowid DESC 全局序，按 pair 归并后截 500）
    findings_by_code = {}
    order_index = {}
    if codes:
        try:
            ph = ",".join("?" * len(codes))
            with db.session() as c:
                rows = [dict(r) for r in c.execute(
                    "SELECT f.*, cs.name AS case_name, cs.created_by AS case_created_by, "
                    "cs.tenant_id AS case_tenant_id, cs.workspace_id AS case_workspace_id "
                    "FROM finding f LEFT JOIN audit_case cs ON cs.id=f.case_id "
                    f"WHERE f.rule_id IN ({ph}) ORDER BY f.rowid DESC",
                    tuple(codes)).fetchall()]
        except Exception:
            logging.getLogger(__name__).debug('batch conflict findings lookup failed', exc_info=True)
            rows = []
        for idx, f in enumerate(rows):
            code = str(f.get("rule_id") or "")
            findings_by_code.setdefault(code, []).append(f)
            order_index[str(f.get("id") or "")] = idx

    # 3) feedback：逐 code 缓存 1 次查询（旧实现每条冲突查 2 次）
    feedback_by_code = {}
    for code in codes:
        try:
            fb_rows = R.feedback.list("rule_code=?", (code,), order="created_at DESC", limit=100)
        except Exception:
            fb_rows = []
        feedback_by_code[code] = [{"id": r.get("id") or "", "rule_code": r.get("rule_code") or "",
                                   "kind": r.get("kind") or "", "title": r.get("title") or "",
                                   "actor": r.get("actor") or "", "case_id": r.get("case_id") or "",
                                   "created_at": r.get("created_at") or ""} for r in fb_rows]

    cache = {}

    def resolve(rule_a, rule_b) -> dict:
        key = (str(rule_a or ""), str(rule_b or ""))
        if key in cache:
            return cache[key]
        codes2 = [str(c or "") for c in key if str(c or "").strip()]
        owned = [c for c in codes2 if owned_by_code.get(c)]
        # 本人项目：pair 内 finding 合并后按全局 rowid DESC 排序，截前 500（旧 LIMIT 500）
        merged = findings_by_code.get(codes2[0] if len(codes2) > 0 else "", []) +             (findings_by_code.get(codes2[1], []) if len(codes2) > 1 else [])
        merged.sort(key=lambda x: order_index.get(str(x.get("id") or ""), 0))
        merged = merged[:500]
        projects = {}
        for f in merged:
            if str(f.get("case_created_by") or "") != sub:
                continue
            cid = str(f.get("case_id") or "")
            if cid and cid not in projects:
                projects[cid] = {"case_id": cid, "name": f.get("case_name") or "",
                                 "status": f.get("case_status") or "",
                                 "rule_codes": [str(f.get("rule_id") or "")]}
            elif cid:
                rc = str(f.get("rule_id") or "")
                if rc and rc not in projects[cid]["rule_codes"]:
                    projects[cid]["rule_codes"].append(rc)
        feedback = []
        for code in codes2:
            for fb in feedback_by_code.get(code, []):
                if str(fb.get("actor") or "") in names:
                    feedback.append(fb)
        rel = {"is_related": bool(owned or projects or feedback),
               "owned_rules": owned,
               "projects": list(projects.values()),
               "feedback": feedback,
               "checked_rules": [row_by_code[c].get("code") for c in codes2
                                 if row_by_code.get(c)]}
        cache[key] = rel
        return rel

    return resolve


def _can_resolve(row: dict, user: dict | None, rel_resolver=None) -> dict:
    """服务端裁决权判定（前端只做展示，不依赖）。

    ``rel_resolver``：可选的批量关系解析器（见 ``_reviewer_relations_batch``）；
    list_conflicts 传入后避免对每条冲突重复查规则/finding/feedback（结果结构一致）。
    """
    role = _user_role(user)
    if not user:
        return {"can_resolve": True, "role": "", "reason": "", "relations": {}}
    if role == "admin":
        return {"can_resolve": True, "role": role, "reason": "", "relations": {}}
    if role == "reviewer":
        if rel_resolver is not None:
            rel = rel_resolver(row.get("rule_a") or "", row.get("rule_b") or "")
        else:
            rel = _reviewer_relations([row.get("rule_a") or "", row.get("rule_b") or ""], user)
        if rel["is_related"]:
            return {"can_resolve": True, "role": role, "reason": "", "relations": rel}
        return {"can_resolve": False, "role": role,
                "reason": "仅本人项目/本人规则/本人反馈相关的冲突可裁决",
                "relations": rel}
    if role in ("super_admin", "platform_op"):
        return {"can_resolve": False, "role": role,
                "reason": "系统管理员/平台运营只读，不参与业务冲突裁决", "relations": {}}
    return {"can_resolve": False, "role": role or "unknown",
            "reason": "当前角色无冲突裁决权限", "relations": {}}


def _scope_check(row: dict, user: dict | None, all_spaces: bool = False) -> tuple[str, str]:
    """租户/空间边界：跨租户 404（不泄露存在性）、同租户跨空间 403。"""
    tenant, workspace = _scope_of(user, all_spaces)
    rt = str(row.get("tenant_id") or "")
    rw = str(row.get("workspace_id") or "")
    if user and tenant and rt and rt != tenant:
        raise ConflictError(404, "冲突不存在", "not_found")
    if user and not all_spaces and workspace and rw and rw != workspace:
        role = _user_role(user)
        raise ConflictError(403 if role != "super_admin" else 403,
                            "无权访问其他工作空间的冲突", "forbidden")
    return tenant, workspace




# ---------------------------------------------------------------- 证据影响

def _impact(row: dict, user: dict | None, relations: dict | None = None) -> dict:
    """both_wrong 影响面：项目（case）/点位/引用（版本、命中、反馈、关联证据）。"""
    codes = [row.get("rule_a") or "", row.get("rule_b") or ""]
    role = _user_role(user)
    sub = _user_sub(user)
    snap_rows = _conflict_rules(codes)
    findings = _rule_findings(codes)
    feedback = _rule_feedback(codes)
    projects = {}
    other_projects = set()
    for f in findings:
        cid = str(f.get("case_id") or "")
        if not cid:
            continue
        created_by = str(f.get("case_created_by") or "")
        if role == "reviewer" and created_by != sub:
            other_projects.add(cid)
            continue
        if cid not in projects:
            projects[cid] = {"case_id": cid, "name": f.get("case_name") or "",
                             "status": f.get("case_status") or "",
                             "created_by": created_by,
                             "created_at": f.get("case_created_at") or "",
                             "rule_codes": []}
        rc = str(f.get("rule_id") or "")
        if rc and rc not in projects[cid]["rule_codes"]:
            projects[cid]["rule_codes"].append(rc)
    if role == "reviewer":
        feedback = [x for x in feedback if str(x.get("actor") or "") in _user_names(user)]
    points = []
    references = []
    for idx, rr in enumerate(snap_rows):
        code = codes[idx]
        if not rr:
            references.append({"side": "a" if idx == 0 else "b", "code": code,
                               "found": False, "reason": "规则不存在或不在当前范围"})
            continue
        scope = _json_load(rr.get("scope_json") or "", {})
        pts = _rule_points(rr, scope if isinstance(scope, dict) else {})
        for p in pts:
            if not any(x["point_id"] == p["point_id"] for x in points):
                points.append(p)
        ref_findings = [f for f in findings if str(f.get("rule_id") or "") == code]
        references.append({
            "side": "a" if idx == 0 else "b",
            "rule_id": rr.get("id") or "", "code": code, "found": True,
            "status": rr.get("status") or "", "current_version_id": rr.get("current_version_id") or "",
            "version": (_effective_version(rr).get("version") or ""),
            "findings": len(ref_findings),
            "feedback": sum(1 for x in feedback if str(x.get("rule_code") or "") == code),
            "points": [p["point_id"] for p in pts],
        })
    projects_list = sorted(projects.values(), key=lambda x: (x.get("created_at") or "", x["case_id"]))
    impact = {
        "scope": "reviewer_related" if role == "reviewer" else "admin_all",
        "projects": projects_list,
        "project_count": len(projects_list),
        "other_project_count": len(other_projects),
        "points": points,
        "point_count": len(points),
        "findings": {
            "total": (len(findings) if role != "reviewer" else
                      sum(1 for f in findings if str(f.get("case_created_by") or "") == sub)),
            "by_status": {},
            "by_severity": {},
            "sample": [{"id": f.get("id") or "", "case_id": f.get("case_id") or "",
                        "rule_id": f.get("rule_id") or "", "title": (f.get("title") or "")[:80],
                        "severity": f.get("severity") or "", "status": f.get("status") or ""}
                       for f in findings[:20]
                       if role != "reviewer" or str(f.get("case_created_by") or "") == sub],
        },
        "feedback": {"total": len(feedback),
                     "sample": [{"id": x["id"], "kind": x["kind"], "rule_code": x["rule_code"],
                                 "title": x["title"][:80], "actor": x["actor"]}
                                for x in feedback[:10]]},
        "references": references,
    }
    for f in findings:
        if role == "reviewer" and str(f.get("case_created_by") or "") != sub:
            continue
        st = str(f.get("status") or "pending")
        sev = str(f.get("severity") or "")
        impact["findings"]["by_status"][st] = impact["findings"]["by_status"].get(st, 0) + 1
        if sev:
            impact["findings"]["by_severity"][sev] = impact["findings"]["by_severity"].get(sev, 0) + 1
    impact["digest"] = _impact_digest(impact)
    return impact


def _impact_digest(impact: dict) -> str:
    payload = {
        "projects": sorted([str(p.get("case_id") or "") for p in (impact.get("projects") or [])]),
        "other_project_count": int(impact.get("other_project_count") or 0),
        "points": sorted([str(p.get("point_id") or "") for p in (impact.get("points") or [])]),
        "findings_total": int(((impact.get("findings") or {}).get("total") or 0)),
        "finding_ids": sorted([str(f.get("id") or "")
                               for f in ((impact.get("findings") or {}).get("sample") or [])]),
        "feedback_total": int(((impact.get("feedback") or {}).get("total") or 0)),
        "references": sorted([f"{r.get('side')}:{r.get('code')}:{r.get('status')}"
                              for r in (impact.get("references") or [])]),
    }
    return _digest(payload)


# ---------------------------------------------------------------- 历史/关联

HISTORY_LABEL = {
    "conflict.rule_a": "裁决：规则 A 正确",
    "conflict.rule_b": "裁决：规则 B 正确",
    "conflict.both_wrong": "裁决：两者都不对（已下线两条规则）",
    "conflict.both_valid": "裁决：两者都对",
    "conflict.need_more": "记录：证据不足（保持待处理）",
    "conflict.ignored": "忽略冲突",
    "conflict.recreate": "重新新建规则（生成草稿）",
    "conflict.recreate_link": "关联重新新建的规则",
    "conflict.resolved": "裁决冲突",
}


def _history(row: dict) -> list:
    out = []
    cid = row.get("id") or ""
    try:
        logs = R.audit_logs.list("object=?", (cid,), order="created_at DESC", limit=50)
    except Exception:
        logs = []
    for lg in logs:
        action = lg.get("action") or ""
        after = lg.get("after_json") or ""
        out.append({"action": action, "label": HISTORY_LABEL.get(action, action),
                    "actor": lg.get("actor") or "", "at": lg.get("created_at") or "",
                    "detail": after[:500]})
    # 关联规则下线审计（both_wrong）
    closed = _row_closed_ids(row)
    if closed:
        try:
            logs2 = R.audit_logs.list(
                "object IN (%s) AND action='rule.archived'" % ",".join("?" * len(closed)),
                tuple(closed), order="created_at DESC", limit=20)
        except Exception:
            logs2 = []
        for lg in logs2:
            out.append({"action": "rule.archived", "label": "关联规则下线",
                        "actor": lg.get("actor") or "", "at": lg.get("created_at") or "",
                        "detail": (lg.get("after_json") or "")[:300], "related_rule_id": lg.get("object")})
    # 旧冲突（无审计记录）按已存储字段补一条，保证历史不空
    if not out and row.get("status") in ("resolved", "ignored"):
        out.append({"action": "conflict.legacy",
                    "label": "历史裁决记录（旧数据）", "actor": row.get("resolved_by") or "",
                    "at": row.get("resolved_at") or "",
                    "detail": str(row.get("note") or "")[:300]})
    try:
        out.sort(key=lambda x: x.get("at") or "", reverse=True)
    except Exception:
        pass
    return out


def _related_conflicts(row: dict) -> list:
    codes = {str(row.get("rule_a") or ""), str(row.get("rule_b") or "")}
    codes.discard("")
    out = []
    try:
        rows = R.conflicts.list(order="created_at DESC", limit=200)
    except Exception:
        rows = []
    for r in rows:
        if r.get("id") == row.get("id"):
            continue
        if codes & {str(r.get("rule_a") or ""), str(r.get("rule_b") or "")}:
            out.append({"id": r.get("id") or "", "type": r.get("type") or "",
                        "type_label": TYPE_LABEL.get(r.get("type") or "", r.get("type") or ""),
                        "severity": r.get("severity") or "",
                        "status": r.get("status") or "",
                        "status_label": STATUS_LABEL.get(r.get("status") or "", r.get("status") or ""),
                        "resolution": r.get("resolution") or "",
                        "resolution_label": RESOLUTION_LABEL.get(r.get("resolution") or "", ""),
                        "rule_a": r.get("rule_a") or "", "rule_b": r.get("rule_b") or "",
                        "detail": (r.get("detail") or "")[:200],
                        "created_at": r.get("created_at") or ""})
    return out[:20]


def _conflict_public(row: dict) -> dict:
    """冲突头（列表/详情共用），含裁决字段与标签。

    P1：旧数据 resolution 为空但 status 已是 resolved/ignored 时，不再显示成
    “已裁决 + 裁决结果 —”的矛盾：返回 ``resolution_legacy=True`` 与
    “历史裁决（未记录路径）”，并展示历史口径（关闭规则数/裁决备注/时间）。
    """
    closed = _row_closed_ids(row)
    recreate = _row_recreate(row)
    _res = str(row.get("resolution") or "")
    _status = str(row.get("status") or "")
    _legacy = bool(not _res and _status in ("resolved", "ignored"))
    if _res:
        _res_label = RESOLUTION_LABEL.get(_res, _res)
    elif _legacy:
        _res_label = "历史裁决（未记录路径）"
    else:
        _res_label = ""
    return {
        "id": row.get("id") or "",
        "rule_a": row.get("rule_a") or "",
        "rule_b": row.get("rule_b") or "",
        "type": row.get("type") or "",
        "type_label": TYPE_LABEL.get(row.get("type") or "", row.get("type") or ""),
        "detail": row.get("detail") or "",
        "suggestion": row.get("suggestion") or "",
        "severity": row.get("severity") or "",
        "severity_label": SEVERITY_LABEL.get(row.get("severity") or "",
                                             row.get("severity") or ""),
        "status": _status,
        "status_label": STATUS_LABEL.get(_status, _status),
        "created_at": row.get("created_at") or "",
        "resolution": _res,
        "resolution_label": _res_label,
        "resolution_legacy": _legacy,
        "resolution_display": (_res_label or "—"),
        "resolution_note": str(row.get("resolution_detail") or row.get("note") or "")
        if _legacy else "",
        "resolution_history": ({"status": _status, "closed_rule_count": len(closed),
                                "resolved_at": row.get("resolved_at") or "",
                                "resolved_by": row.get("resolved_by") or "",
                                "legacy": _legacy} if _legacy else {}),
        "resolution_detail": _json_load(row.get("resolution_detail") or "", {})
        if str(row.get("resolution_detail") or "").startswith("{")
        else str(row.get("resolution_detail") or ""),
        "closed_rule_ids": closed,
        "closed_rule_count": len(closed),
        "recreate_rule_id": row.get("recreate_rule_id") or "",
        "recreate_task": recreate,
        "recreate_pending": bool(recreate and not (row.get("recreate_rule_id") or "")),
        "impact": _json_load(row.get("impact_json") or "", {}),
        "note": row.get("note") or "",
        "resolved_at": row.get("resolved_at") or "",
        "resolved_by": row.get("resolved_by") or "",
        "tenant_id": row.get("tenant_id") or "",
        "workspace_id": row.get("workspace_id") or "",
    }


# ---------------------------------------------------------------- 冲突清单

def _conflict_stats(rows: list) -> dict:
    """冲突统计（P1-04）：与列表使用同一 filter/同一可见范围，need_more 不重复计数。

    - total = 本次可见范围（reviewer 可裁范围 / 管理员本租户本空间）内条目数；
    - open 已包含 need_more（need_more 是 open 的子状态，不是独立第四态）；
    - open_awaiting = open - need_more（待实际裁决数），两者相加仍等于 open；
    - stats 由调用方按「同一 filter 后的 rows」计算，保证 KPI 与列表条数同源。
    """
    open_rows = [x for x in rows if (x.get("status") or "open") == "open"]
    need_more = sum(1 for x in open_rows if (x.get("resolution") or "") == "need_more")
    return {
        "total": len(rows),
        "critical": sum(1 for x in rows if x.get("severity") == "critical"),
        "open": len(open_rows),
        "open_awaiting": len(open_rows) - need_more,
        "need_more": need_more,
        "need_more_is_subset": True,
        "need_more_note": "need_more 是 open 的子状态，不额外计入 total/open，避免重复计数",
        "resolved": sum(1 for x in rows if (x.get("status") or "") == "resolved"),
        "ignored": sum(1 for x in rows if (x.get("status") or "") == "ignored"),
        "pending_recreate": sum(1 for x in rows
                                if _row_recreate(x) and not (x.get("recreate_rule_id") or "")),
        "legacy_unresolved": sum(1 for x in rows
                                 if (x.get("status") or "") in ("resolved", "ignored")
                                 and not (x.get("resolution") or "")),
    }


def list_conflicts(status: str = "", raw: bool = False, all_spaces: bool = False,
                   user: dict | None = None):
    """冲突清单（默认返回全部可见状态，与 KPI 同一 filter）。

    T-63：审核员只看到“本人项目/本人规则/本人反馈相关”的冲突（可裁范围）；
    管理员看本租户+当前空间全部；条目带 can_resolve 供前端隐藏裁决入口。

    T-107（P1-04）：
    - 列表默认“全部状态”（与页面「全部状态」筛选项一致），不再默认只看 open；
    - ``stats`` 与 items 用**同一 filter / 同一 reviewer 可见范围**计算，
      不再出现“KPI 总数=5、列表共 3 条、reviewer 列表 0 但 KPI 5”；
    - need_more 作为 open 的子状态统计（``need_more_is_subset=True``），不重复计数。
    """
    rows = R.conflicts.list(order="created_at DESC") if hasattr(R, "conflicts") else []
    if not rows:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM conflict ORDER BY created_at DESC").fetchall()]
    visible = list(rows)
    try:
        from . import ctx as _ctx2
        _c2 = _ctx2.get_context() or {}
        _t2, _w2 = _c2.get("tenant_id") or "", _c2.get("workspace_id") or ""
        if _t2:
            visible = [r for r in visible
                       if not (r.get("tenant_id") or "") or r.get("tenant_id") == _t2]
        if _w2 and not all_spaces:
            # 冲突只在当前工作空间内看，管理员也不能跨空间查看
            visible = [r for r in visible if (r.get("workspace_id") or "") == _w2]
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    role = _user_role(user)
    scope = "all"
    rel_resolver = None
    if role == "reviewer":
        # 审核员：只展示可裁范围（与 detail/resolve 同一 _can_resolve 判定）。
        # P1-B8-01：先用批量关系解析器一次取数（旧实现每条冲突查 ~5 次 SQL）。
        _all_codes = []
        for _r in visible:
            _all_codes.append(_r.get("rule_a") or "")
            _all_codes.append(_r.get("rule_b") or "")
        rel_resolver = _reviewer_relations_batch(_all_codes, user)
        visible = [r for r in visible
                   if _can_resolve(r, user, rel_resolver).get("can_resolve")]
        scope = "reviewer_related"
    filtered = visible
    if status:
        filtered = [r for r in filtered if (r.get("status") or "") == status]
    out = []
    for r in filtered:
        item = _conflict_public(r)
        perm = _can_resolve(r, user, rel_resolver)
        item["permissions"] = {"can_resolve": bool(perm.get("can_resolve")),
                               "role": perm.get("role") or "",
                               "reason": perm.get("reason") or ""}
        out.append(item)
    if raw:
        return out
    # KPI 与列表同源：stats 基于同一 filter 后的 filtered（不是未过滤 visible）
    return {"items": out,
            "scope": scope,
            "filter": {"status": status or "all"},
            "status_options": ["open", "resolved", "ignored"],
            # P2-B4-01（本次修复）：后端一直允许 admin **与 reviewer** 执行全量检测
            # （/api/v1/conflicts/detect 只校验登录，见 server.py），但这里曾只对 admin
            # 返回 can_detect=true，前端据此隐藏「全量检测」按钮 → 「UI 说不能，API 能做」。
            # 现在与 API 实际可达性同源：reviewer 也可检测（检测是只读扫描 + 落检测状态，
            # 冲突裁决仍限 admin/可裁审核员，权限未放宽），并已补 conflict.detect 审计。
            "permissions": {"can_detect": role in ("admin", "reviewer") or not role},
            "stats": _conflict_stats(filtered),
            "scope_totals": _conflict_stats(visible)}


# ---------------------------------------------------------------- 旧数据回填
# 旧冲突（seed/历史库）只有 status=resolved/ignored、resolution 为空，导致列表出现
# “已裁决 + 裁决结果 —”。历史裁决路径无法凭空恢复：这里只回填**可确定性推断**的
# 路径（ignored；resolved 且已关闭规则 → both_wrong；备注里明确的路径词），其余保留
# 空值并由 _conflict_public 显示“历史裁决（未记录路径）”，不伪造。

_LEGACY_RESOLUTION_HINTS = (
    ("both_wrong", ("两者都不对", "both_wrong", "都错误", "都判错")),
    ("both_valid", ("两者都成立", "both_valid", "均成立")),
    ("need_more", ("证据不足", "need_more", "需补充证据")),
    ("rule_b", ("规则B", "规则 B", "rule_b", "B 正确", "B正确")),
    ("rule_a", ("规则A", "规则 A", "rule_a", "A 正确", "A正确")),
)


def infer_legacy_resolution(row: dict) -> str:
    """旧冲突 resolution 的可确定性推断；推断不出返回空串（不猜）。"""
    status = str((row or {}).get("status") or "")
    if status == "ignored":
        return "ignored"
    if _row_closed_ids(row):
        return "both_wrong"
    blob = " ".join(str((row or {}).get(k) or "")
                    for k in ("note", "resolution_detail", "detail", "suggestion"))
    for res, tokens in _LEGACY_RESOLUTION_HINTS:
        if any(tok in blob for tok in tokens):
            return res
    return ""


def backfill_legacy_resolutions(dry_run: bool = True, actor: str = "system") -> dict:
    """旧冲突 resolution 空值回填（默认 dry-run，不写库；显式 dry_run=False 才落库）。

    返回 {dry_run, candidates(逐条推断), filled, unresolved(无法确定性推断),
          legacy_display}。无法推断的条目保持空值，由列表显示历史裁决口径。
    """
    rows = []
    try:
        rows = R.conflicts.list(order="created_at DESC")
    except Exception:
        logging.getLogger(__name__).debug("legacy conflict list failed", exc_info=True)
    candidates, unresolved = [], []
    for r in rows:
        status = str(r.get("status") or "")
        if status not in ("resolved", "ignored"):
            continue
        if str(r.get("resolution") or ""):
            continue
        guess = infer_legacy_resolution(r)
        item = {"id": r.get("id") or "", "status": status,
                "closed_rule_count": len(_row_closed_ids(r)),
                "inferred_resolution": guess,
                "inferred_label": RESOLUTION_LABEL.get(guess) or ""}
        if guess:
            candidates.append(item)
        else:
            item["display"] = "历史裁决（未记录路径）"
            unresolved.append(item)
    filled = 0
    if not dry_run and candidates:
        stamp = db.now()
        with db.session() as c:
            for item in candidates:
                cur = c.execute(
                    "UPDATE conflict SET resolution=?, resolution_detail=? "
                    "WHERE id=? AND COALESCE(resolution,'')=''",
                    (item["inferred_resolution"],
                     json.dumps({"legacy_backfill": True, "resolution": item["inferred_resolution"],
                                 "inferred_from": "deterministic_rule", "backfilled_at": stamp,
                                 "backfilled_by": actor}, ensure_ascii=False),
                     item["id"]))
                if cur.rowcount == 1:
                    filled += 1
                    _audit_svc.log_in_tx(
                        c, actor=actor or "system", action="conflict.resolution_backfilled",
                        object_=item["id"],
                        after=json.dumps({"resolution": item["inferred_resolution"],
                                          "legacy": True}, ensure_ascii=False))
    return {"dry_run": bool(dry_run), "candidates": candidates,
            "filled": filled, "unresolved": unresolved,
            "legacy_display": "历史裁决（未记录路径）",
            "note": "仅回填可确定性推断的路径；无法推断的保持空值并显示历史口径，不伪造"}


# ---------------------------------------------------------------- 冲突详情

def _resolution_options() -> list:
    return [{"value": r, "label": RESOLUTION_LABEL[r], "description": RESOLUTION_DESC[r],
             "action": RESOLUTION_ACTION[r],
             "requires_note": True,
             "requires_corrected_criterion": r == "both_wrong",
             "requires_impact_confirm": r == "both_wrong",
             "closes_rules": r == "both_wrong",
             "keeps_open": r == "need_more"} for r in RESOLUTIONS]


def get_detail(conflict_id: str, user: dict | None = None, all_spaces: bool = False) -> dict:
    """冲突聚合详情：冲突头 / A、B 完整规则快照（六组字段）/ 差异 / 证据影响 /
    裁决与历史 / 关联冲突 / 当前用户可裁范围。"""
    row = _raw_conflict(conflict_id)
    if not row:
        raise ConflictError(404, "冲突不存在", "not_found")
    _scope_check(row, user, all_spaces)
    role = _user_role(user)
    if role == "reviewer" and not _can_resolve(row, user).get("can_resolve"):
        raise ConflictError(403, "仅本人项目/本人规则/本人反馈相关的冲突可查看",
                            "forbidden")
    snap_a = rule_snapshot(row.get("rule_a") or "")
    snap_b = rule_snapshot(row.get("rule_b") or "")
    perm = _can_resolve(row, user)
    impact = _impact(row, user, perm.get("relations") or {})
    public = _conflict_public(row)
    if not public.get("impact"):
        public["impact"] = impact
    detail = {
        "conflict": public,
        "rules": {"a": snap_a, "b": snap_b},
        "differences": _diff_items(snap_a, snap_b),
        "impact": impact,
        "impact_digest": impact.get("digest") or "",
        "history": _history(row),
        "related": _related_conflicts(row),
        "permissions": {
            "can_resolve": bool(perm.get("can_resolve")),
            "can_view": True,
            "role": role,
            "role_label": ROLE_LABEL.get(role, role),
            "reason": perm.get("reason") or "",
            "relations": {
                "owned_rules": (perm.get("relations") or {}).get("owned_rules") or [],
                "projects": [p.get("case_id") for p in
                             ((perm.get("relations") or {}).get("projects") or [])],
                "feedback_ids": [x.get("id") for x in
                                 ((perm.get("relations") or {}).get("feedback") or [])],
            },
        },
        "resolution_options": _resolution_options(),
        "recreate": _recreate_public(row, snap_a, snap_b),
        "six_groups": [
            {"key": "definition", "label": "规则定义 RuleDefinition"},
            {"key": "scope", "label": "适用范围 Scope"},
            {"key": "execution_plan", "label": "执行计划 ExecutionPlan"},
            {"key": "evidence", "label": "证据要求 Evidence"},
            {"key": "lifecycle", "label": "生命周期 Lifecycle"},
            {"key": "usage", "label": "关联与使用 Usage"},
        ],
    }
    return detail


def _recreate_public(row: dict, snap_a: dict, snap_b: dict) -> dict:
    task = _row_recreate(row)
    rule_id = row.get("recreate_rule_id") or ""
    linked = {}
    if rule_id:
        try:
            rr = R.rules.get(rule_id)
        except Exception:
            rr = None
        if rr:
            linked = {"rule_id": rr.get("id") or "", "code": rr.get("code") or "",
                      "name": rr.get("name") or "", "status": rr.get("status") or "",
                      "status_label": {"draft": "草稿", "pending": "待审批",
                                       "approved": "已批准", "published": "已发布",
                                       "archived": "已下线"}.get(rr.get("status") or "", "")}
    if not task and not rule_id:
        return {"available": False, "reason": "仅「两者都不对」裁决会生成重新新建规则入口"}
    return {"available": True, "task": task, "rule_id": rule_id, "linked_rule": linked,
            "prefill": (task or {}).get("prefill") or {},
            "lifecycle_hint": "新规则必须重新走 草稿 → 提交审批 → 批准 → 发布生效，不会自动发布；"
                              "旧规则已下线但版本/审计/命中记录全部保留。"}


# ---------------------------------------------------------------- 裁决

def _require_note(note: str) -> str:
    text = str(note or "").strip()
    if not text:
        raise ConflictError(400, "请填写裁决原因（note）", "note_required")
    return text


def _validate_resolution(action: str, resolution: str) -> tuple[str, str]:
    res = str(resolution or "").strip()
    act = str(action or "").strip()
    if not res:
        if act in ACTION_TO_RESOLUTION:
            res = ACTION_TO_RESOLUTION[act]
        else:
            raise ConflictError(400, "请选择裁决结果（rule_a/rule_b/both_wrong/"
                                     "both_valid/need_more/ignored）", "resolution_required")
    if res not in RESOLUTIONS:
        raise ConflictError(400, f"非法裁决结果：{res}", "invalid_resolution")
    expected = RESOLUTION_ACTION[res]
    if act and act != expected:
        raise ConflictError(400, f"action 与 resolution 不一致：{act} ≠ {expected}",
                            "action_resolution_mismatch")
    return expected, res


def _payload_digest(resolution: str, note: str, corrected: str, closed_ids: list) -> str:
    return _digest({"resolution": resolution, "note": str(note or "").strip(),
                    "corrected_criterion": str(corrected or "").strip(),
                    "closed_rule_ids": sorted(str(x) for x in (closed_ids or []))})


def _stored_payload_digest(row: dict) -> str:
    detail = _json_load(row.get("resolution_detail") or "", {})
    return str((detail or {}).get("payload_digest") or "")


def _new_rules_version_snapshot(rule_rows: list) -> list:
    out = []
    for rr in rule_rows:
        out.append({"rule_id": rr.get("id") or "", "code": rr.get("code") or "",
                    "status": rr.get("status") or "",
                    "current_version_id": rr.get("current_version_id") or "",
                    "versions": _version_rows(rr)})
    return out


class _ConflictClaimLost(Exception):
    """并发裁决时冲突行 CAS 抢占失败（内部信号；事务已整体回滚）。"""


def _close_rules_both_wrong_tx(c, rule_rows: list, actor: str, conflict_id: str) -> list:
    """在调用方事务连接 ``c`` 内下线两条规则（P2-01 both_wrong 原子化）。

    与 ``rule.archive_many`` 同口径：status→archived、current_version_id 清空、
    published/approved/pending 版本→superseded、逐规则写审计；区别是本函数
    **不自行开事务/不 commit**，任一步失败由调用方回滚。这样「冲突行 CAS 抢占 +
    规则下线 + 冲突落库 + 审计」在同一事务内，不会出现“规则已下线、冲突仍 open”。
    """
    stamp = db.now()
    closed = []
    for rr in rule_rows:
        rid = str((rr or {}).get("id") or "")
        row = c.execute("SELECT id, code, status FROM rule WHERE id=?", (rid,)).fetchone()
        if not row:
            raise ConflictError(409, f"规则不存在或不在当前范围：{rid}", "rule_not_found")
        code = str(row["code"] or (rr or {}).get("code") or "")
        status = str(row["status"] or "")
        if status == "archived":
            closed.append({"rule_id": rid, "code": code, "status": "archived",
                           "already": True})
            continue
        cur = c.execute("UPDATE rule SET status='archived', current_version_id='' "
                        "WHERE id=? AND status=?", (rid, status))
        if cur.rowcount != 1:
            raise ConflictError(409, "规则状态已被其他操作修改，请刷新后重试",
                                "rule_state_changed")
        c.execute("UPDATE rule_version SET status='superseded', superseded_at=? "
                  "WHERE rule_id=? AND status IN ('published','approved','pending')",
                  (stamp, rid))
        closed.append({"rule_id": rid, "code": code, "status": "archived",
                       "from": status, "already": False})
        _audit_svc.log_in_tx(
            c, actor=actor or "system", action="rule.archived", object_=rid,
            after=json.dumps({"from_status": status, "batch": "archive_many",
                              "reason": f"冲突 {conflict_id} 裁决：两者都不对"},
                             ensure_ascii=False))
    return closed


def _make_recreate_task(row: dict, actor: str, note: str, corrected: str,
                        closed: list, snap_a: dict, snap_b: dict) -> dict:
    """「重新新建规则」待办 + 预填上下文（判定模板/范围/正确判据/来源）。"""
    fa = (snap_a or {}).get("flat") or {}
    fb = (snap_b or {}).get("flat") or {}
    metric = fa.get("metric") or fb.get("metric") or ""
    unit = fa.get("unit") or fb.get("unit") or ""
    category = (fa.get("template") or fb.get("template") or fa.get("category")
                or fb.get("category") or "limit")
    known = {"limit", "consistency", "completeness", "format", "preprocess", "record",
             "prohibited", "frequency", "personnel", "equipment", "label", "citation"}
    if category not in known:
        category = "limit"
    rclass = fa.get("rclass") or fb.get("rclass") or "R1"
    evidence = []
    for x in (fa.get("evidence_list") or []) + (fb.get("evidence_list") or []):
        if x and x not in evidence:
            evidence.append(x)
    if fa.get("required_evidence") and fa["required_evidence"] not in evidence:
        evidence.append(fa["required_evidence"])
    if fb.get("required_evidence") and fb["required_evidence"] not in evidence:
        evidence.append(fb["required_evidence"])
    tags = []
    for x in (fa.get("tags") or []) + (fb.get("tags") or []):
        if x and x not in tags:
            tags.append(x)
    if "冲突重建" not in tags:
        tags.append("冲突重建")
    parsed = {}
    try:
        from . import rule as _rule
        parsed = _rule._numeric_limit_slots_from_text(corrected) or {}
    except Exception:
        parsed = {}
    slots = {}
    if parsed:
        slots.update(parsed)
    else:
        slots.update({"criterion": corrected, "metric": metric, "unit": unit})
    slots["criterion"] = corrected or str(slots.get("criterion") or "")
    if metric and not slots.get("metric"):
        slots["metric"] = metric
    if unit and not slots.get("unit"):
        slots["unit"] = unit
    if evidence:
        slots["required_evidence"] = evidence
        slots["required_evidence_list"] = evidence
    if fa.get("scope_text") or fb.get("scope_text"):
        slots["scope"] = fa.get("scope_text") or fb.get("scope_text")
    if fa.get("applicable_when") or fb.get("applicable_when"):
        slots["applicable_when"] = fa.get("applicable_when") or fb.get("applicable_when")
    applicable_types = []
    for x in (fa.get("applicable_types") or []) + (fb.get("applicable_types") or []):
        if x and x not in applicable_types:
            applicable_types.append(x)
    if applicable_types:
        slots["applicable_types"] = applicable_types
    name_metric = metric or "该指标"
    prefill = {
        "name": f"重建规则：{name_metric}（冲突 {row.get('id') or ''}）",
        "category": category,
        "rclass": rclass,
        "source": RECREATE_SOURCE,
        "slots": slots,
        "scope": {
            "description": f"由冲突 {row.get('id') or ''} 重建：{row.get('detail') or ''}"[:500],
            "tags": tags,
            "evidence": "；".join(evidence),
            "applicable_when": fa.get("applicable_when") or fb.get("applicable_when") or "",
            "source": RECREATE_SOURCE,
            "conflict_id": row.get("id") or "",
            "original_rules": [row.get("rule_a") or "", row.get("rule_b") or ""],
            "corrected_criterion": corrected,
        },
        "context": {
            "conflict_id": row.get("id") or "",
            "conflict_type": row.get("type") or "",
            "conflict_detail": row.get("detail") or "",
            "rule_a": row.get("rule_a") or "", "rule_b": row.get("rule_b") or "",
            "a": {"code": fa.get("code") or "", "name": fa.get("name") or "",
                  "criterion": fa.get("criterion") or "", "status": fa.get("status") or ""},
            "b": {"code": fb.get("code") or "", "name": fb.get("name") or "",
                  "criterion": fb.get("criterion") or "", "status": fb.get("status") or ""},
            "corrected_criterion": corrected,
            "note": note,
            "closed_rule_ids": [x.get("rule_id") or "" for x in closed],
            "closed_rule_codes": [x.get("code") or "" for x in closed],
        },
    }
    return {
        "task_id": "rt-" + str(row.get("id") or "cf"),
        "type": "recreate_rule",
        "status": "open",
        "title": f"重新新建规则：{name_metric}",
        "detail": "两条规则均已下线；新规则先落草稿，确认后直接发布生效（无需审批，不自动发布）。",
        "conflict_id": row.get("id") or "",
        "created_at": db.now(),
        "created_by": actor,
        "prefill": prefill,
    }


def resolve(conflict_id: str, action: str = "resolved", note: str = "", user: str = "",
            all_spaces: bool = False, resolution: str = "",
            corrected_criterion: str = "", impact=None, confirm_impact: bool = False,
            impact_digest: str = "", user_ctx: dict | None = None,
            idempotency_key: str = "") -> dict:
    """裁决冲突（T-63 六路径）。HTTP 层传 user_ctx（会话用户）做服务端权限强制；
    兼容旧调用 ``resolve(cid, "ignored", note, actor)``。"""
    actor = str(user or _user_sub(user_ctx) or "").strip()
    act, res = _validate_resolution(action, resolution)
    text = _require_note(note)
    corrected = str(corrected_criterion or "").strip()
    if res == "both_wrong" and not corrected:
        raise ConflictError(400, "「两者都不对」必须填写正确的判据（corrected_criterion）",
                            "corrected_criterion_required")
    row = _raw_conflict(conflict_id)
    if not row:
        raise ConflictError(404, "冲突不存在", "not_found")
    _scope_check(row, user_ctx, all_spaces)
    perm = _can_resolve(row, user_ctx)
    if not perm.get("can_resolve"):
        raise ConflictError(403, perm.get("reason") or "无权裁决该冲突", "forbidden")
    cur_res = str(row.get("resolution") or "")
    cur_status = str(row.get("status") or "")
    cur_closed = _row_closed_ids(row)
    # 修复裁决：已 resolved 的 both_wrong + 尚未生成重建规则 → 允许更新正确判据后重试重建
    repairable = bool(cur_status == "resolved" and cur_res == "both_wrong"
                      and res == "both_wrong"
                      and not str(row.get("recreate_rule_id") or ""))
    payload_digest = _payload_digest(res, text, corrected, cur_closed)
    # 幂等：同一裁决重复提交 → 原样返回，不重复审计/重复下线
    if cur_status in ("resolved", "ignored") or (cur_status == "open" and cur_res == "need_more"):
        same = (cur_res == res and _stored_payload_digest(row) == payload_digest)
        if same:
            fresh = _raw_conflict(conflict_id) or row
            return {"conflict": _conflict_public(fresh), "resolution": res, "status": cur_status,
                    "idempotent": True, "closed_rules": [], "recreate": None,
                    "impact_digest": (fresh.get("impact_json") and
                                      _json_load(fresh.get("impact_json") or "", {}).get("digest"))
                    or "", "message": "重复提交：已按首次裁决结果处理，未重复写审计/重复下线"}
        if cur_status in ("resolved", "ignored"):
            # P1/死锁修复：both_wrong 已裁决但重建规则尚未生成时，允许「修复裁决」——
            # 用新的正确判据重试重建，而不是永久锁死（规则已下线无法再改预填）。
            _repairable = bool(cur_status == "resolved" and cur_res == "both_wrong"
                               and res == "both_wrong"
                               and not str(row.get("recreate_rule_id") or ""))
            if not _repairable:
                raise ConflictError(409, f"冲突已裁决（{RESOLUTION_LABEL.get(cur_res, cur_res)}），"
                                         "不能重复修改；如需变更请重新发起冲突流程",
                                    "already_resolved")
    # 影响面 + 规则预解析（both_wrong 必须先确认影响面，再关闭规则）
    rule_rows = _conflict_rules([row.get("rule_a") or "", row.get("rule_b") or ""])
    snap_a = rule_snapshot(row.get("rule_a") or "")
    snap_b = rule_snapshot(row.get("rule_b") or "")
    impact_data = _impact(row, user_ctx, perm.get("relations") or {})
    if res == "both_wrong" and not repairable:
        if not confirm_impact:
            raise ConflictError(409, "「两者都不对」必须确认影响面（项目/点位/引用）后再提交",
                                "impact_confirm_required")
        sent_digest = str(impact_digest or "").strip() or str(
            (impact or {}).get("digest") if isinstance(impact, dict) else "").strip()
        if not sent_digest:
            raise ConflictError(409, "缺少影响面确认摘要（impact_digest），请刷新详情后重试",
                                "impact_digest_required")
        if sent_digest != impact_data.get("digest"):
            raise ConflictError(409, "影响面已变化（项目/点位/引用发生变化），请刷新详情后重新确认",
                                "impact_stale")
    # 死锁修复：先校验 corrected_criterion 能否生成可执行规则，再关闭规则/改状态。
    # 校验失败直接 400，冲突与规则均不变，用户修正后可重试（不会出现“规则已下线、
    # 冲突已 resolved、重建永远 400”的死锁）。
    if res == "both_wrong":
        from . import rule as _rule_pre
        _probe_task = _make_recreate_task(row, actor, text, corrected, [],
                                          snap_a, snap_b)
        _probe_pre = _probe_task.get("prefill") or {}
        _chk = _rule_pre.validate_draft_slots(
            _probe_pre.get("slots") or {}, name=_probe_pre.get("name") or "",
            category=_probe_pre.get("category") or "")
        if not _chk.get("ok"):
            raise ConflictError(
                400,
                "「两者都不对」的正确判据无法生成可执行规则："
                + "；".join(str(x) for x in (_chk.get("errors") or ["判据不可执行"]))
                + "。" + (_chk.get("hint") or "")
                + " 本次裁决未生效（冲突仍为待处理、规则未下线），修正判据后可重试",
                "corrected_criterion_invalid")
    status_map = {"resolved": "resolved", "ignored": "ignored", "open": "open"}
    new_status = status_map[act]
    resolved_at = db.now()
    closed_rule_ids, closed_rules, rule_snapshots = [], [], []
    if res == "both_wrong":
        if not all(rule_rows):
            raise ConflictError(
                409, "该冲突的 A/B 无法都解析为当前空间内的规则（可能是决策表行冲突或旧数据），"
                     "不能按「两者都不对」下线规则，请改用其他裁决或修订决策表",
                "not_rule_conflict")
        rule_snapshots = _new_rules_version_snapshot(rule_rows)
    recreate_task = {}
    detail_payload, audit_after = {}, {}
    try:
        with db.session() as c:
            # P2-01：先以 CAS 抢占冲突行（同一事务内）；抢占失败不触碰规则，
            # 因此不会出现“规则已 archived、冲突仍 open”。抢占成功后规则下线、
            # 冲突落库、审计全部在同一事务提交/回滚。
            claim = c.execute(
                "UPDATE conflict SET status=? WHERE id=? AND status=? AND COALESCE(resolution,'')=?",
                (new_status, conflict_id, cur_status, cur_res))
            if claim.rowcount != 1:
                raise _ConflictClaimLost()
            if res == "both_wrong" and not repairable:
                closed_rules = _close_rules_both_wrong_tx(c, rule_rows, actor, conflict_id)
                closed_rule_ids = [str(x.get("rule_id") or "") for x in closed_rules]
                recreate_task = _make_recreate_task(row, actor, text, corrected,
                                                    closed_rules, snap_a, snap_b)
            elif res == "both_wrong" and repairable:
                # 修复：规则已在首次裁决下线，不重复关闭；只更新重建待办里的正确判据
                closed_rule_ids = list(cur_closed)
                recreate_task = _make_recreate_task(row, actor, text, corrected,
                                                    [], snap_a, snap_b)
            detail_payload = {
                "note": text,
                "repaired": bool(repairable),
                "corrected_criterion": corrected,
                "impact_digest": impact_data.get("digest") or "",
                "payload_digest": _payload_digest(res, text, corrected, closed_rule_ids),
                "closed_rules": closed_rules,
                "rule_snapshots": rule_snapshots,
                "recreate_task_id": recreate_task.get("task_id") or "",
            }
            c.execute(
                "UPDATE conflict SET resolution=?, resolution_detail=?, closed_rule_ids=?, "
                "recreate_rule_id=?, recreate_task=?, impact_json=?, note=?, resolved_at=?, resolved_by=? "
                "WHERE id=?",
                (res, json.dumps(detail_payload, ensure_ascii=False),
                 json.dumps(closed_rule_ids, ensure_ascii=False),
                 str(row.get("recreate_rule_id") or ""),
                 json.dumps(recreate_task, ensure_ascii=False) if recreate_task else "",
                 json.dumps(impact_data, ensure_ascii=False),
                 text, resolved_at if new_status != "open" else (row.get("resolved_at") or ""),
                 actor, conflict_id))
            audit_after = {
                "resolution": res, "resolution_label": RESOLUTION_LABEL[res],
                "status": new_status, "note": text,
                "corrected_criterion": corrected,
                "closed_rule_ids": closed_rule_ids,
                "impact_digest": impact_data.get("digest") or "",
                "recreate_task_id": recreate_task.get("task_id") or "",
                "idempotency_key": str(idempotency_key or "")[:120],
            }
            # P2-04：裁决审计与冲突/规则状态同事务，审计写失败→整体回滚并报错。
            _audit_svc.log_in_tx(
                c, actor=actor or "system",
                action=("conflict.both_wrong_repaired" if repairable else f"conflict.{res}"),
                object_=conflict_id,
                before=json.dumps({"status": cur_status, "resolution": cur_res},
                                  ensure_ascii=False),
                after=json.dumps(audit_after, ensure_ascii=False))
    except _ConflictClaimLost:
        fresh = _raw_conflict(conflict_id)
        same = bool(fresh and str(fresh.get("resolution") or "") == res
                    and _stored_payload_digest(fresh)
                    == _payload_digest(res, text, corrected, _row_closed_ids(fresh)))
        if same:
            return {"conflict": _conflict_public(fresh), "resolution": res,
                    "status": (fresh or {}).get("status") or "", "idempotent": True,
                    "closed_rules": [], "recreate": None,
                    "impact_digest": impact_data.get("digest") or "",
                    "message": "并发重复提交：已按首次裁决结果处理"}
        raise ConflictError(409, "冲突状态已被其他操作修改，请刷新后重试",
                            "conflict_state_changed")
    fresh = _raw_conflict(conflict_id) or row
    return {"conflict": _conflict_public(fresh), "resolution": res,
            "resolution_label": RESOLUTION_LABEL[res], "status": new_status,
            "idempotent": False, "repaired": repairable,
            "closed_rules": closed_rules, "closed_rule_ids": closed_rule_ids,
            "recreate": recreate_task or None,
            "impact_digest": impact_data.get("digest") or "",
            "retryable": bool(recreate_task),
            "message": ("已修复「两者都不对」重建判据，规则未重复下线，可重试重新新建规则"
                        if repairable else
                        "已记录证据不足，冲突保持待处理" if res == "need_more"
                        else f"已裁决：{RESOLUTION_LABEL[res]}")}


# ---------------------------------------------------------------- 重新新建规则

def _unique_rule_code(base: str) -> str:
    code = str(base or "").strip() or "RBLD"
    try:
        for n in range(1, 100):
            cand = code if n == 1 else f"{code}-{n}"
            if not R.rules.list("code=?", (cand,)):
                return cand
    except Exception:
        pass
    return f"{code}-{db.new_id('x')[-6:]}"


def recreate(conflict_id: str, action: str = "create_draft", rule_id: str = "",
             user: dict | None = None, user_sub: str = "", all_spaces: bool = False,
             corrected_criterion: str = "") -> dict:
    """「两者都不对」之后：生成预填规则草稿（create_draft）或关联已新建规则（link）。

    T-107 产品口径：
    - 新规则不需要审批：create_draft 只落 draft，之后直接 publish 生效（不自动发布）。
    - 重建判据先做与 create_rule 同源的 IR 校验；不合法返回可操作错误
      ``recreate_rule_invalid``（状态不变、可修改 corrected_criterion 后重试），
      不再“规则已下线 + 重建永远 400”的死锁。
    """
    actor = str(user_sub or _user_sub(user) or "").strip()
    row = _raw_conflict(conflict_id)
    if not row:
        raise ConflictError(404, "冲突不存在", "not_found")
    _scope_check(row, user, all_spaces)
    perm = _can_resolve(row, user)
    if not perm.get("can_resolve"):
        raise ConflictError(403, perm.get("reason") or "无权处理该冲突", "forbidden")
    if str(row.get("resolution") or "") != "both_wrong":
        raise ConflictError(409, "仅「两者都不对」裁决支持重新新建规则", "recreate_requires_both_wrong")
    task = _row_recreate(row)
    if not task:
        task = _make_recreate_task(row, actor, str(row.get("note") or ""),
                                   "", [], rule_snapshot(row.get("rule_a") or ""),
                                   rule_snapshot(row.get("rule_b") or ""))
    act = str(action or "create_draft").strip()
    if act == "link":
        rid = str(rule_id or "").strip()
        if not rid:
            raise ConflictError(400, "缺少 rule_id", "rule_id_required")
        target = None
        try:
            target = R.rules.get(rid)
            if not target:
                rows = R.rules.list("code=?", (rid,))
                target = rows[0] if rows else None
        except Exception:
            target = None
        if not target:
            raise ConflictError(404, "规则不存在或不在当前范围", "not_found")
        existing = str(row.get("recreate_rule_id") or "")
        if existing:
            if existing == target.get("id"):
                return {"conflict": _conflict_public(_raw_conflict(conflict_id) or row),
                        "rule_id": existing, "idempotent": True,
                        "rule": {"id": target.get("id") or "", "code": target.get("code") or "",
                                 "name": target.get("name") or "",
                                 "status": target.get("status") or ""},
                        "message": "已关联同一规则，未重复写入"}
            raise ConflictError(409, "该冲突已关联其他重建规则", "already_linked")
        task["rule_id"] = target.get("id") or ""
        task["status"] = "linked"
        task["linked_at"] = db.now()
        with db.session() as c:
            cur = c.execute(
                "UPDATE conflict SET recreate_rule_id=?, recreate_task=? "
                "WHERE id=? AND (COALESCE(recreate_rule_id,'')='')",
                (target.get("id") or "", json.dumps(task, ensure_ascii=False), conflict_id))
            if cur.rowcount != 1:
                raise ConflictError(409, "关联状态已变化，请刷新后重试", "conflict_state_changed")
            _audit_svc.log_in_tx(
                c, actor=actor or "system", action="conflict.recreate_link",
                object_=conflict_id,
                after=json.dumps({"rule_id": target.get("id"), "code": target.get("code")},
                                 ensure_ascii=False))
        return {"conflict": _conflict_public(_raw_conflict(conflict_id) or row),
                "rule_id": target.get("id") or "", "rule": {
                    "id": target.get("id") or "", "code": target.get("code") or "",
                    "name": target.get("name") or "", "status": target.get("status") or ""},
                "idempotent": False, "recreate": task,
                "message": "已关联重新新建的规则"}
    # create_draft：预填冲突上下文，只生成草稿（不发布）
    existing = str(row.get("recreate_rule_id") or "")
    if existing:
        try:
            rr = R.rules.get(existing)
        except Exception:
            rr = None
        if rr:
            return {"conflict": _conflict_public(_raw_conflict(conflict_id) or row),
                    "rule_id": existing, "idempotent": True,
                    "rule": {"id": rr.get("id") or "", "code": rr.get("code") or "",
                             "name": rr.get("name") or "", "status": rr.get("status") or ""},
                    "recreate": _row_recreate(_raw_conflict(conflict_id) or row),
                    "message": "已生成过重建规则草稿，未重复创建"}
    prefill = (task or {}).get("prefill") or {}
    cut = str(corrected_criterion or "").strip()
    if cut:
        # 允许在重建接口直接修正判据（HTTP 路由可后续透传；服务层先支持，避免死锁）
        prefill = _make_recreate_task(row, actor, str(row.get("note") or ""), cut, [],
                                      rule_snapshot(row.get("rule_a") or ""),
                                      rule_snapshot(row.get("rule_b") or "")).get("prefill") or prefill
        task = task or {}
        task["prefill"] = prefill
        task["corrected_criterion"] = cut
    slots = prefill.get("slots") or {"criterion": ""}
    scope = prefill.get("scope") or {}
    name = prefill.get("name") or f"重建规则（冲突 {conflict_id}）"
    category = prefill.get("category") or "limit"
    rclass = prefill.get("rclass") or "R1"
    from . import rule as _rule
    _chk = _rule.validate_draft_slots(slots, name=name, category=category, rclass=rclass)
    if not _chk.get("ok"):
        raise ConflictError(
            400,
            "重建判据无法生成可执行规则：" + "；".join(_chk.get("errors") or ["判据不可执行"])
            + "。" + (_chk.get("hint") or "")
            + " 本次未生成草稿（冲突状态不变），可修改 corrected_criterion 后重试："
              "对已 resolved 的 both_wrong 冲突再次调用 resolve（同一 resolution + 新判据）可更新预填。",
            "recreate_rule_invalid")
    code = _unique_rule_code("RBLD-" + str(conflict_id).replace("cf-", "")[-6:].upper())
    try:
        created = _rule.create_rule(code=code, name=name, category=category, rclass=rclass,
                                    slots=slots, source=RECREATE_SOURCE, scope=scope)
    except ValueError as exc:
        raise ConflictError(400, f"生成重建规则草稿失败：{exc}；冲突状态不变，可调整判据后重试",
                            "recreate_rule_invalid")
    except Exception as exc:  # noqa: BLE001
        raise ConflictError(500, f"生成重建规则草稿失败：{type(exc).__name__}；冲突状态不变，可重试",
                            "recreate_failed")
    new_rule_id = created.get("rule_id") or ""
    try:
        R.rules.update(new_rule_id, owner=actor, owner_id=actor)
    except Exception:
        logging.getLogger(__name__).debug('recreate owner stamp skipped', exc_info=True)
    task["rule_id"] = new_rule_id
    task["rule_code"] = code
    task["status"] = "created"
    task["created_rule_at"] = db.now()
    with db.session() as c:
        cur = c.execute(
            "UPDATE conflict SET recreate_rule_id=?, recreate_task=? "
            "WHERE id=? AND (COALESCE(recreate_rule_id,'')='')",
            (new_rule_id, json.dumps(task, ensure_ascii=False), conflict_id))
        if cur.rowcount != 1:
            fresh = _raw_conflict(conflict_id) or row
            if str(fresh.get("recreate_rule_id") or "") == new_rule_id:
                pass
            else:
                raise ConflictError(409, "重建规则状态已变化，请刷新后重试",
                                    "conflict_state_changed")
        _audit_svc.log_in_tx(
            c, actor=actor or "system", action="conflict.recreate", object_=conflict_id,
            after=json.dumps({"rule_id": new_rule_id, "rule_code": code,
                              "status": "draft", "auto_published": False},
                             ensure_ascii=False))
    return {"conflict": _conflict_public(_raw_conflict(conflict_id) or row),
            "rule_id": new_rule_id, "idempotent": False,
            "rule": {"id": new_rule_id, "code": code, "name": name, "status": "draft",
                     "status_label": "草稿"},
            "recreate": task,
            "lifecycle_hint": "已生成草稿；新流程无需审批，请在规则库直接发布生效（不自动发布）",
            "message": f"已生成重建规则草稿 {code}（状态：草稿，未自动发布）"}



def coverage_conflict(mine: dict, other: dict) -> dict | None:
    """同一指标、同向限值且一个区间被另一个完全覆盖，视为重复/冗余。

    例：<=100 已发布，再发布 <=50；>=200 已发布，再发布 >=300。
    这类规则不会增加判定能力，反而让阈值来源不唯一，应阻断并要求合并。
    """
    a = (mine or {}).get("slots") or {}
    b = (other or {}).get("slots") or {}
    if str(a.get("metric") or "") != str(b.get("metric") or ""):
        return None
    ua, ub = a.get("unit") or "", b.get("unit") or ""
    if ua and ub and ua != ub:
        return None
    try:
        va, vb = float(a.get("value")), float(b.get("value"))
    except Exception:
        return None
    oa, ob = str(a.get("op") or ""), str(b.get("op") or "")
    upper = {"<", "<=", "≤", "不超过", "不得高于", "不大于"}
    lower = {">", ">=", "≥", "不低于", "不得低于", "不少于"}
    if oa in upper and ob in upper and va < vb:
        return {"a": other.get("code"), "b": mine.get("code"), "type": "重复冗余",
                "severity": "warning",
                "detail": f"{mine.get('code')} {oa}{va:g} 被已发布 {other.get('code')} {ob}{vb:g} 覆盖"}
    if oa in lower and ob in lower and va > vb:
        return {"a": other.get("code"), "b": mine.get("code"), "type": "重复冗余",
                "severity": "warning",
                "detail": f"{mine.get('code')} {oa}{va:g} 被已发布 {other.get('code')} {ob}{vb:g} 覆盖"}
    return None
