"""规则参数：把内置规则里写死的阈值搬到 DB，使内置规则也能被真正修订。

执行器仍由代码提供（解析/比对逻辑），但**阈值、单位、作用域**从参数表读取；
RSI 沉淀修订时写入新参数值，下一次审核立即生效。

生命周期口径（方案 B：运行参数旁路，显式不纳入规则状态机）：
- 参数表有自己的两段式「草稿→发布」：``update/set_behavior/set_option`` 只写
  ``pending_json``（不生效），``publish()`` 才写入 ``params_json``（生效）；
- 该旁路**不参与** rule/rule_version 的 pending/approved/published 状态机，也不改变
  规则版本号；发布审计为 ``rule.param_published`` / ``rule.param_blocked_conflict``；
- 之所以旁路（选 B 而非 A）：参数作用于**内置规则**（rule 表中是已发布的内置资产，
  不随客户审批流走版本），改动即时影响下一轮执行；若纳入 rule_version 会把「阈值
  运行参数」与「客户规则内容版本」混为一谈，审批粒度错位。安全阀用
  pending→publish + 冲突复检 + 审计，而不是审批流；
- 旁路不等于「没有冻结」：每次运行快照 ``manifest.build()`` 的 ``params_sha`` 只取
  **生效值**（``snapshot()``，不含 pending/审批状态），因此草稿不影响下一次 manifest，
  ``publish()`` 后下一次 manifest 才变化，历史 manifest 的 ``params_sha`` 保持不变；
- 状态可经 ``state(code)`` 显式读取，供 API/测试确认「草稿未生效 / 已发布生效」；
  旧版本参数可经审计 ``history(code)`` 追溯（before/after + params_sha）。
"""
import hashlib
import json
import logging

from .. import db
from .. import repositories as R

# 内置阈值的出厂默认值（也是首次播种的来源）
DEFAULTS = {
    "RW20260525005": {"metric": "中心温度", "op": ">=", "value": 85, "unit": "℃", "scope": "加热"},
    "RW20260525006": {"metric": "消毒浓度", "op": ">=", "value": 200, "unit": "ppm", "scope": "消毒"},
    "RW20260525009": {"metric": "冷却终温", "op": "<=", "value": 10, "unit": "℃", "scope": "冷却"},
    "RW20260525010": {"metric": "冷藏温度", "op": "range", "lo": 0, "hi": 8, "unit": "℃", "scope": "冷藏"},
    "RW20260525011": {"metric": "解冻时长", "op": "<=", "value": 48, "unit": "h", "scope": "解冻"},
    "RW20260525012": {"metric": "重量单位", "op": "enum", "value": ["g", "kg"], "scope": "计量"},
}

# 行为参数对所有内置规则生效（不需要数值阈值也能调）
BEHAVIOR_DEFAULTS = {"enabled": True, "severity": "", "severity_scope": "",
                     "ignore_keywords": [], "scope_types": []}

# 非数值型规则的可调选项（判定逻辑仍由代码执行，但要素/阈值/白名单均可配置）
OPTION_DEFAULTS = {
    "RW20260525002": {"required_fields": ["工单号", "版本号", "产品名称", "实施日期", "签名"],
                      "allow_placeholder": []},
    "RW20260525003": {"name_aliases": [], "allow_short_name": False},
    "RW20260526004": {"date_tolerance_days": 0},
    "B-2": {"outsource_keywords": ["外购", "直接使用", "免加工"]},
    "B-4": {"weight_tolerance_pct": 5.0},
    "C-3": {"allow_gap": False, "start_from": 1},
    "E3": {"require_tool": True, "require_spec": True},
    "E4": {"require_wash": True, "require_spec": True},
}

LABEL = {
    "RW20260525005": "中心温度下限", "RW20260525006": "消毒浓度下限",
    "RW20260525009": "冷却终温上限", "RW20260525010": "冷藏温度区间",
    "RW20260525011": "解冻时长上限", "RW20260525012": "重量单位集合",
}


def ensure_seeded() -> int:
    """把出厂默认值写入参数表（幂等）。"""
    n = 0
    for code, params in DEFAULTS.items():
        cur = get(code)
        if cur:
            continue
        R.rule_params.insert(id=db.new_id("rp"), rule_code=code,
                             params_json=json.dumps(params, ensure_ascii=False),
                             source="builtin_default", updated_at=db.now())
        n += 1
    return n


def get(code: str) -> dict:
    try:
        rows = R.rule_params.list("rule_code=?", (code,))
        if rows:
            return json.loads(rows[0].get("params_json") or "{}")
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {}


def behavior(code: str) -> dict:
    p = dict(get(code) or {})
    if code in _OVERRIDE:
        p.update(_OVERRIDE[code])
    out = dict(BEHAVIOR_DEFAULTS)
    for k in BEHAVIOR_DEFAULTS:
        if k in p:
            out[k] = p[k]
    return out


def _published_behavior(code: str) -> dict:
    """生效中的行为参数（忽略 replay 的进程内 override）。

    manifest.params_sha 只能反映「已发布」状态：回放临时覆盖不能污染运行快照指纹。
    """
    p = dict(get(code) or {})
    out = dict(BEHAVIOR_DEFAULTS)
    for k in BEHAVIOR_DEFAULTS:
        if k in p:
            out[k] = p[k]
    return out


def set_behavior(code: str, by: str = "system", **changes) -> dict:
    """修改规则行为（草稿）：发布后生效。"""
    cur = get(code) or {}
    cur.update({k: v for k, v in changes.items() if k in BEHAVIOR_DEFAULTS})
    rows = R.rule_params.list("rule_code=?", (code,))
    if rows:
        R.rule_params.update(rows[0]["id"], pending_json=json.dumps(cur, ensure_ascii=False),
                             pending_by=by, pending_at=db.now())
    else:
        R.rule_params.insert(id=db.new_id("rp"), rule_code=code,
                             params_json=json.dumps({}, ensure_ascii=False),
                             pending_json=json.dumps(cur, ensure_ascii=False),
                             pending_by=by, pending_at=db.now(), source="rsi_behavior",
                             updated_at=db.now())
    R.audit_logs.log(actor=by, action="rule.behavior_drafted", object=code,
                     after=json.dumps(changes, ensure_ascii=False))
    return {"rule_code": code, "pending_behavior": cur, "published": False}


def option(code: str, key: str, default=None):
    """读取非数值型规则的可调选项（先看覆盖，再看已发布参数，最后默认）。"""
    if code in _OVERRIDE and key in _OVERRIDE[code]:
        return _OVERRIDE[code][key]
    p = get(code) or {}
    if key in p:
        return p[key]
    d = OPTION_DEFAULTS.get(code) or {}
    return d.get(key, default)


def set_option(code: str, by: str = "system", **changes) -> dict:
    """修改非数值型规则选项（草稿）。"""
    cur = get(code) or {}
    cur.update(changes)
    rows = R.rule_params.list("rule_code=?", (code,))
    if rows:
        R.rule_params.update(rows[0]["id"], pending_json=json.dumps(cur, ensure_ascii=False),
                             pending_by=by, pending_at=db.now())
    else:
        R.rule_params.insert(id=db.new_id("rp"), rule_code=code,
                             params_json=json.dumps({}, ensure_ascii=False),
                             pending_json=json.dumps(cur, ensure_ascii=False),
                             pending_by=by, pending_at=db.now(), source="rsi_option",
                             updated_at=db.now())
    R.audit_logs.log(actor=by, action="rule.option_drafted", object=code,
                     after=json.dumps(changes, ensure_ascii=False))
    return {"rule_code": code, "pending": cur, "published": False}


_OVERRIDE: dict = {}


class override:
    """进程内参数覆盖：用于「规则回放」在不改动生效值的前提下模拟新参数。"""

    def __init__(self, code: str, values: dict):
        self.code, self.values, self.old = code, dict(values or {}), None

    def __enter__(self):
        self.old = _OVERRIDE.get(self.code)
        _OVERRIDE[self.code] = self.values
        return self

    def __exit__(self, *a):
        if self.old is None:
            _OVERRIDE.pop(self.code, None)
        else:
            _OVERRIDE[self.code] = self.old
        return False


def value(code: str, key: str, default=None):
    if code in _OVERRIDE and key in _OVERRIDE[code]:
        return _OVERRIDE[code][key]
    p = get(code) or DEFAULTS.get(code) or {}
    return p.get(key, default)


def resolve_rule_code(value: str) -> str:
    from .identifiers import resolve_rule_code as _r
    return _r(value)


def update(code: str, by: str = "system", **changes) -> dict:
    """修订参数：写入「待发布」值，必须发布后才生效（生产安全阀）。"""
    cur = get(code) or dict(DEFAULTS.get(code) or {})
    merged = dict(cur)
    merged.update(changes)
    try:
        rows = R.rule_params.list("rule_code=?", (code,))
        if rows:
            R.rule_params.update(rows[0]["id"], pending_json=json.dumps(merged, ensure_ascii=False),
                                 pending_by=by, pending_at=db.now())
        else:
            R.rule_params.insert(id=db.new_id("rp"), rule_code=code,
                                 params_json=json.dumps(dict(DEFAULTS.get(code) or {}), ensure_ascii=False),
                                 pending_json=json.dumps(merged, ensure_ascii=False),
                                 pending_by=by, pending_at=db.now(), source="builtin_default",
                                 updated_at=db.now())
        R.audit_logs.log(actor=by, action="rule.param_drafted", object=code,
                         after=json.dumps(merged, ensure_ascii=False))
    except Exception as e:  # noqa
        return {"error": f"写入失败：{type(e).__name__}"}
    return {"rule_code": code, "pending": merged, "active": cur, "published": False}


def reset(code: str, by: str = "system") -> dict:
    """清除该规则的参数/行为覆盖，回到默认（回滚用）。"""
    rows = R.rule_params.list("rule_code=?", (code,))
    for r in rows:
        with db.session() as c:
            c.execute("DELETE FROM rule_param WHERE id=?", (r["id"],))
    R.audit_logs.log(actor=by, action="rule.param_reset", object=code)
    _OVERRIDE.pop(code, None)
    return {"rule_code": code, "reset": True}


def pending(code: str) -> dict:
    try:
        rows = R.rule_params.list("rule_code=?", (code,))
        if rows and rows[0].get("pending_json"):
            return json.loads(rows[0]["pending_json"])
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {}


def _effective_slots(rule: dict) -> dict:
    """规则槽位 + 参数覆盖（value/op/threshold/上限）。"""
    import json as _j
    v = R.rules.latest_version(rule["id"]) or {}
    try:
        slots = _j.loads(v.get("slots_json") or "{}")
    except Exception:
        slots = {}
    if not isinstance(slots, dict):
        slots = {}
    p = get(code=rule.get("code") or "")
    if isinstance(p, dict):
        for k in ("value", "threshold", "上限", "op"):
            if k in p and p[k] not in (None, ""):
                if k in ("value", "threshold", "上限"):
                    try:
                        slots["value"] = float(p[k])
                    except Exception:
                        logging.getLogger(__name__).debug('ignored', exc_info=True)
                elif k == "op":
                    slots["op"] = p[k]
    return slots


def _recheck_conflicts(code: str) -> list:
    """参数发布后重算冲突：只看同指标、已发布规则。"""
    from . import conflict
    me_rows = R.rules.list("code=?", (code,))
    if not me_rows:
        return []
    me = dict(me_rows[0]); me["slots"] = _effective_slots(me_rows[0])
    metric = str(me["slots"].get("metric") or "")
    if not metric:
        return []
    rows = []
    from . import rule as _rule_scope
    for r in _rule_scope.effective_rule_rows():  # T-171 生效口径（默认 0=旧行为）
        if r["id"] == me_rows[0]["id"]:
            continue
        sl = _effective_slots(r)
        if str(sl.get("metric") or "") != metric:
            continue
        d = dict(r); d["slots"] = sl
        rows.append(d)
    if not rows:
        return []
    res = conflict.analyze_rules([me] + rows)
    for _o in rows:
        _c = conflict.coverage_conflict(me, _o)
        if _c:
            res.append(_c)
    return [x for x in res if str(x.get("type") or "") == "互斥冲突"
            or (str(x.get("type") or "") == "重复冗余" and "完全重复" not in str(x.get("detail") or ""))]


def _params_sha(params: dict) -> str:
    """参数内容指纹：审计/回放可核对「发布了哪一版参数」。"""
    payload = json.dumps(params or {}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


# 参数旁路显式声明：rule_param 不进入 rule/rule_version 状态机（见模块 docstring）。
LIFECYCLE_BYPASS = "rule_param_bypass"


def state(code: str) -> dict:
    """参数生命周期状态（显式旁路）：无记录 / 待发布 / 已发布生效 / 已发布+待发布。

    该接口供 API/CLI/测试确认「草稿未生效、publish 后才生效」，不改变既有行为。
    """
    rows = []
    try:
        rows = R.rule_params.list("rule_code=?", (code,))
    except Exception:
        logging.getLogger(__name__).debug("rule_param state lookup skipped", exc_info=True)
    active = get(code)
    pend = pending(code)
    if not rows:
        st = "default"
    elif pend and active:
        st = "published_pending"
    elif pend:
        st = "pending"
    elif active or rows[0].get("params_json"):
        st = "published"
    else:
        st = "default"
    return {"rule_code": code, "state": st, "lifecycle_bypass": LIFECYCLE_BYPASS,
            "active": active, "pending": pend,
            "active_sha": _params_sha(active) if active else "",
            "pending_sha": _params_sha(pend) if pend else "",
            "pending_by": (rows[0].get("pending_by") if rows else "") or "",
            "pending_at": (rows[0].get("pending_at") if rows else "") or ""}


def publish(code: str, by: str = "system") -> dict:
    """发布参数：待发布值 → 生效值。"""
    p = pending(code)
    if not p:
        return {"error": "没有待发布的参数变更"}
    rows = R.rule_params.list("rule_code=?", (code,))
    before = get(code)
    # 先应用，再复检；冲突则回滚并写审计（P0-4）
    R.rule_params.update(rows[0]["id"], params_json=json.dumps(p, ensure_ascii=False),
                         pending_json="", pending_by="", pending_at="",
                         source="rsi_revised", updated_at=db.now())
    hits = _recheck_conflicts(code)
    if hits:
        R.rule_params.update(rows[0]["id"], params_json=json.dumps(before, ensure_ascii=False),
                             pending_json=json.dumps(p, ensure_ascii=False), pending_by=by,
                             pending_at=db.now(), source="rsi_pending", updated_at=db.now())
        R.audit_logs.log(actor=by, action="rule.param_blocked_conflict", object=code,
                         before=json.dumps(before, ensure_ascii=False),
                         after=json.dumps({"blocked": hits[:3]}, ensure_ascii=False))
        return {"rule_code": code, "published": False, "error": "conflict",
                "detail": (hits[0].get("detail") or "")[:160], "blocked": len(hits)}
    R.audit_logs.log(actor=by, action="rule.param_published", object=code,
                     before=json.dumps(before, ensure_ascii=False),
                     after=json.dumps({"active": p, "params_sha": _params_sha(p)},
                                      ensure_ascii=False))
    return {"rule_code": code, "published": True, "active": p,
            "lifecycle": LIFECYCLE_BYPASS, "params_sha": _params_sha(p),
            "previous_sha": _params_sha(before) if before else ""}


def history(code: str, limit: int = 20) -> list:
    """参数发布历史（只读，来自审计日志）：旧版本参数可追溯。

    每次 publish 的审计 before=旧生效值 / after={active, params_sha}，
    blocked_conflict 同样留痕；返回按时间倒序，供报告/回放核对「哪一版参数生效过」。
    """
    out = []
    try:
        rows = R.audit_logs.list(
            "object=? AND action IN ('rule.param_published','rule.param_blocked_conflict')",
            (code,), order="rowid DESC", limit=int(limit or 20))
    except Exception:
        return out
    for row in rows:
        try:
            before = json.loads(row.get("before_json") or "{}")
        except Exception:
            before = {}
        try:
            after = json.loads(row.get("after_json") or "{}")
        except Exception:
            after = {}
        out.append({"action": row.get("action"), "at": row.get("created_at"),
                    "by": row.get("actor"), "before": before, "after": after,
                    "before_sha": _params_sha(before) if before else "",
                    # publish 审计 after 里直接带 params_sha；阻断审计没有
                    "after_sha": str(after.get("params_sha") or "") if isinstance(after, dict)
                    else ""})
    return out


def snapshot() -> list:
    """生效参数快照（只读、确定性）：manifest 运行快照 ``params_sha`` 的唯一输入。

    - 只包含**已发布值**（params_json）与出厂默认，不含 pending/审批/状态等易变字段；
    - 因此保存草稿不会改变下一次 manifest.params_sha，``publish()`` 后才改变；
    - 顺序与内容稳定，``json.dumps(sort_keys=True)`` 后哈希可复现。
    """
    from ..engine.rules_meta import BUILTIN_RULES
    out, seen = [], set()
    for r in BUILTIN_RULES:
        code = r["code"]
        seen.add(code)
        d = dict(DEFAULTS.get(code) or {})
        active = get(code)
        out.append({"rule_code": code, "label": r.get("name", code),
                    "params": dict(active or d), "default": d,
                    "behavior": _published_behavior(code),
                    "has_threshold": bool(d), "revised": bool(active)})
    for code, d in DEFAULTS.items():
        if code in seen:
            continue
        active = get(code)
        out.append({"rule_code": code, "label": LABEL.get(code, code),
                    "params": dict(active or d), "default": dict(d),
                    "behavior": _published_behavior(code),
                    "has_threshold": True, "revised": bool(active)})
    return out


def list_all() -> list:
    """全部内置规则的参数视图（UI/API）：生效值 + 旁路生命周期标注。

    ``state`` 只表达生效口径（published/default），**不暴露 pending**；
    草稿状态由 ``state(code)`` 单独读取，避免草稿污染 manifest 指纹。
    """
    out = snapshot()
    for _item in out:
        _item["lifecycle_bypass"] = LIFECYCLE_BYPASS
        _item["state"] = "published" if _item.get("revised") else "default"
    return out


def params_sha() -> str:
    """生效参数指纹（12 位）：与 ``manifest.build()['params_sha']`` 同算法同输入。"""
    return hashlib.sha256(json.dumps(list_all(), ensure_ascii=False, sort_keys=True)
                          .encode("utf-8")).hexdigest()[:12]

