"""反馈台账：审核员的正向/反向反馈统一沉淀，供 RSI / 规则库 / 智能体实时联动。

六类信号：
  confirm        确认 AI 问题   → 正向样本（规则有效）
  false_positive 判为误报       → 反向样本（规则过严/作用域过大）
  need_evidence  要求补证       → 证据不足信号
  ignored        忽略该问题     → 中性处置（L148：保留记录、不进正/反向样本；
                                  L132 G3 的「忽略不落反馈」缺口在这里补齐）
  manual         人工新增问题   → 漏报信号（规则未覆盖）
  supplement     补充证据       → 证据链增强
"""
import json
import logging
import os

from .. import db
from .. import repositories as R

KIND_LABEL = {
    "confirm": "确认问题", "false_positive": "判为误报", "need_evidence": "要求补证",
    "ignored": "忽略", "manual": "人工新增", "supplement": "补充证据",
}
# P0-05：反馈沉淀/忽略是审核业务写操作。权限唯一口径：
#   - admin 永远允许；
#   - super_admin / platform_op 不允许（F-28 产品边界，系统管理员不写审核业务）；
#   - reviewer 默认只读（UI 也是只读），只有通过 `RULEPROOF_FEEDBACK_SETTLE_ROLES`
#     显式授权（逗号分隔角色码）后才允许；
#   - 查不到角色的内部/系统 actor（scheduler/RSI 脚本等）不视为越权（与
#     permissions.actor_write_denied 的既有约定一致）。
SETTLE_ROLES_ENV = "RULEPROOF_FEEDBACK_SETTLE_ROLES"
SETTLE_DEFAULT_ROLES = ("admin",)
SETTLE_DENY_ROLES = ("super_admin", "platform_op")
# 2026-11-22 外审整改（A 类）：候选写入失败的处置口径。
#   1（默认）= 严格：record_candidate 失败不得返回 ok:True；反馈状态落
#               ``candidate_pending``（规则变更已提交、候选待重试）并返回可恢复 payload；
#               相同 feedback 重试只补候选，不重复草稿/发布（幂等）。
#   0        = 旧行为（兼容回退）：吞掉候选异常、照常 settled、candidate_id=""。
# 旧行为会制造「用户看到处理成功、后台缺 反馈→候选 追溯记录」的静默成功路径，默认关闭。
STRICT_SETTLE_ENV = "RULEPROOF_FEEDBACK_STRICT_SETTLE"
SETTLE_PENDING_STATUS = "candidate_pending"
SETTLE_SEMANTICS_VERSION = 1
# 2026-11-23 LaneM（A 类缺陷 B1，依据 docs/qa/反馈闭环演练_20261123.md §5/§6）：
# 反馈结算「处置开始」write-ahead 标记 + 崩溃恢复。断点原状：规则写（fork/发布）先于
# 候选写、反馈状态最后才落库，进程在候选写入前被 kill 后重试会重新 fork+发布（重复草稿/
# 重复 rule.published 审计），幂等 FAIL。
#   1（默认）= 规则写之前先落 rsi_status=settling + payload.settle.state=settling
#              （含 started_at/action/before_rule_version/before_version_ids…），
#              崩溃重启后以相同 feedback/action 重试 → 走恢复路径：按标记核对规则侧/候选侧
#              已完成进度，缺什么补什么，不重复写规则、不重复发布。
#   0        = 旧行为（兼容回退）：不写标记、不识别恢复；崩溃后重试按首次成功路径重跑。
WAL_ENV = "RULEPROOF_FEEDBACK_WAL"
SETTLING_STATUS = "settling"
# 2026-11-23 LaneR（A 类缺陷 B2，依据 docs/qa/反馈闭环演练_20261123.md §4.2/§6）：
# 前端「手动新增问题（人工漏报）」旧实现把反馈 rule_code 固定 "MANUAL"，new_rule 只写
# criterion/point_id → 规则缺 required_evidence/applicable_types 等结构化字段，发布被
# ``ir_needs_structure`` 拒绝（400），人工漏报无法走完「草稿→发布→manifest」。
# 本常量是「规则库确实没有对应规则」的人工漏报标记：review.add_manual_finding 落此码，
# settle(new_rule) 据此走新规则沉淀通道并从 finding 描述/证据生成可发布的结构化 slots。
MANUAL_MISSING_RULE_CODE = "manual_missing"
# 人工漏报沉淀新规则时使用的类别/执行等级：R3=语义/证据（人工判据无确定性阈值）
NEW_RULE_CATEGORY = "客户沉淀"
NEW_RULE_RCLASS = "R3"
# 正/反向：confirm 正向；false_positive / manual 反向；其余中性（ignored 是中性处置，
# 既不证明规则有效也不证明规则过严，不进入正/反向样本计数）。
KIND_POLARITY = {"confirm": "positive", "false_positive": "negative", "manual": "negative",
                 "need_evidence": "neutral", "ignored": "neutral",
                 "supplement": "neutral"}


DECISION_TO_KIND = {"confirmed": "confirm", "false_positive": "false_positive",
                    "need_evidence": "need_evidence", "ignored": "ignored",
                    "reject": "false_positive"}


def authorized_settle_roles() -> set:
    """允许沉淀/忽略反馈的角色集合：admin 默认 + 环境显式授权角色。"""
    roles = set(SETTLE_DEFAULT_ROLES)
    raw = str(os.environ.get(SETTLE_ROLES_ENV) or "").strip()
    if raw:
        roles |= {x.strip() for x in raw.replace("，", ",").split(",") if x.strip()}
    return roles


def _actor_roles(actor: str) -> set:
    """回查账号真实角色；查不到（内部/系统 actor）返回空集合，不按越权处理。"""
    aid = str(actor or "").strip()
    if not aid:
        return set()
    try:
        from . import account as _account
        return {str(x) for x in (_account.roles_of(aid) or []) if str(x).strip()}
    except Exception:
        logging.getLogger(__name__).warning("actor role lookup failed", exc_info=True)
        return set()


def settle_permission(user: str = "") -> dict:
    """P0-05 反馈沉淀权限唯一口径；允许返回 {}，拒绝返回统一 forbidden payload。"""
    from . import permissions as _perms
    roles = _actor_roles(user)
    if not roles:
        # 查不到角色的内部/系统 actor（scheduler / RSI 脚本）沿用既有约定：不视为越权
        return {}
    if roles & set(SETTLE_DENY_ROLES):
        payload = _perms.deny_write_payload("feedback.settle")
        payload["roles"] = sorted(roles)
        return payload
    if roles & authorized_settle_roles():
        return {}
    payload = {"ok": False, "status": 403, "code": "forbidden",
               "error": "审核员对反馈只读：沉淀/忽略仅业务管理员（或经 "
                        f"{SETTLE_ROLES_ENV} 明确授权的角色）可执行",
               "roles": sorted(roles), "action": "feedback.settle"}
    return payload


def _audit_denied(feedback_id: str, user: str, payload: dict) -> None:
    try:
        R.audit_logs.log(actor=user or "system", action="feedback.settle_denied",
                         object=feedback_id,
                         after=json.dumps({"error": payload.get("error"),
                                           "roles": payload.get("roles") or []},
                                          ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("denied audit skipped", exc_info=True)


def record(case_id: str = "", finding_id: str = "", kind: str = "", rule_code: str = "",
           title: str = "", payload: dict = None, actor: str = "") -> dict:
    kind = DECISION_TO_KIND.get(kind, kind)
    if kind not in KIND_LABEL:
        # 铁律 2：未知类型不能静默吞（旧实现只返回 error，调用方 except 后无日志）。
        # 返回结构保持向后兼容（error），同时留结构化 warning 供排查。
        logging.getLogger(__name__).warning(
            "feedback.record 未知反馈类型 kind=%r（不落库；调用方必须处理 error）", kind)
        return {"error": f"未知反馈类型：{kind}"}
    fid = db.new_id("fb")
    R.feedback.insert(id=fid, case_id=case_id, finding_id=finding_id, kind=kind,
                      rule_code=rule_code or "", title=title or "",
                      payload=json.dumps(payload or {}, ensure_ascii=False),
                      actor=actor or "", created_at=db.now(), rsi_status="pending")
    _live_link(rule_code, kind, actor)
    return {"feedback_id": fid, "kind": kind}


def _live_link(rule_code: str, kind: str, actor: str) -> None:
    """实时联动：反向反馈累积到阈值 → 生成进化任务 + 通知管理员。"""
    if not rule_code or kind not in ("false_positive", "manual"):
        return
    try:
        rows = R.feedback.list("rule_code=?", (rule_code,), order="created_at DESC")
        neg = sum(1 for r in rows if r.get("kind") in ("false_positive", "manual"))
    except Exception:
        return
    if neg < 3:
        return
    try:
        from . import notify
        R.audit_logs.log(actor="system", action="feedback.threshold", object=rule_code,
                         after=f"近 {neg} 条反向反馈，建议复盘规则")
        notify.notify_role("admin", "rule.feedback", f"规则 {rule_code} 反向反馈累积 {neg} 条",
                           "建议在「规则进化」中查看并沉淀修订")
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 智能体联动：给误报归因智能体留一条待分析任务
    try:
        from . import agents
        a = R.agents.get("agent-fp")
        if a:
            R.audit_logs.log(actor="system", action="agent.queued", object="agent-fp", after=rule_code)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)


def _actor_name(uid: str) -> str:
    if not uid:
        return ""
    try:
        u = R.users.get(uid)
        return (u.get("name") or u.get("username") or uid) if u else uid
    except Exception:
        return uid


def _actor_names(uids) -> dict:
    """批量 actor 展示名（id→name/username/id），单查询替代逐条 _actor_name。

    P2 慢节点最小修（/api/v1/feedback）：原逐条 R.users.get 各建一次连接。
    逐字口径同 _actor_name；用户不存在时回退 uid。查询失败返回 {}，调用方
    回退旧逐条实现（不改变任何输出）。
    """
    ids = [str(u) for u in dict.fromkeys(uids or ()) if str(u or "")]
    if not ids:
        return {}
    try:
        rows = R.users.list("id IN (%s)" % ",".join("?" * len(ids)), tuple(ids))
    except Exception:
        return {}
    out = {}
    for u in rows:
        uid = str(u.get("id") or "")
        out[uid] = u.get("name") or u.get("username") or uid
    return out


def list_mine(user_id: str, limit: int = 100) -> list:
    """审核员自己的复核反馈（误报/确认/补证），不暴露他人反馈。"""
    from .. import db as _db
    try:
        with _db.session() as c:
            rows = c.execute("SELECT * FROM feedback WHERE actor=? ORDER BY created_at DESC LIMIT ?",
                             (user_id, limit)).fetchall()
        return [dict(x) for x in rows]
    except Exception:
        return []


def list_feedback(kind: str = "", status: str = "", limit: int = 200) -> list:
    out = []
    try:
        rows = R.feedback.list(order="created_at DESC", limit=limit)
    except Exception:
        return out
    _names = _actor_names([r.get("actor") for r in rows])
    for r in rows:
        if kind and r.get("kind") != kind:
            continue
        if status and r.get("rsi_status") != status:
            continue
        try:
            payload = json.loads(r.get("payload") or "{}")
        except Exception:
            payload = {}
        out.append({
            "id": r["id"], "case_id": r.get("case_id") or "", "finding_id": r.get("finding_id") or "",
            "kind": r.get("kind") or "", "kind_label": KIND_LABEL.get(r.get("kind"), r.get("kind") or ""),
            "rule_code": r.get("rule_code") or "", "title": r.get("title") or "",
            "reason": payload.get("reason") or payload.get("detail") or "",
            "actor": ((_names.get(str(r.get("actor") or "")) or str(r.get("actor") or ""))
                      if _names else _actor_name(r.get("actor") or "")), "created_at": r.get("created_at") or "",
            "rsi_status": r.get("rsi_status") or "pending",
            "rsi_action": r.get("rsi_action") or "", "rsi_rule_id": r.get("rsi_rule_id") or "",
            "root_cause": payload.get("root_cause") or "", "suggestion": payload.get("suggestion") or "",
            "attr_source": payload.get("source") or "",
            # 2026-11-22 A 类修复：沉淀语义（settled/draft_generated/published/
            # behavior_changed）落库回读；旧看板字段保持不变。
            "settle_result": (payload.get("settle") if isinstance(payload.get("settle"), dict)
                              else {}),
        })
    return out


def stats() -> dict:
    try:
        rows = R.feedback.list()
    except Exception:
        rows = []
    by = {}
    for r in rows:
        by[r.get("kind") or ""] = by.get(r.get("kind") or "", 0) + 1
    settled = sum(1 for r in rows if r.get("rsi_status") == "settled")
    by_status = {}
    for r in rows:
        st = r.get("rsi_status") or "pending"
        by_status[st] = by_status.get(st, 0) + 1
    # 2026-11-22 A 类修复：settled 语义拆分（只增字段）。
    # 旧口径 ``settled``（rsi_status=settled 计数）保持逐字不变；新增三个计数来自
    # 落库的 payload.settle：draft_generated=只生成未发布草稿、published=已发布、
    # behavior_changed=发布确实改变执行行为（数值 ×1.0 原值未变 → 不计入）。
    draft_generated = published = behavior_changed = 0
    for r in rows:
        try:
            rec = json.loads(r.get("payload") or "{}").get("settle") or {}
        except Exception:
            rec = {}
        if not isinstance(rec, dict):
            continue
        if rec.get("draft_generated"):
            draft_generated += 1
        if rec.get("published"):
            published += 1
        if rec.get("behavior_changed"):
            behavior_changed += 1
    return {"total": len(rows), "by_kind": by, "by_rsi_status": by_status,
            "positive": sum(v for k, v in by.items() if KIND_POLARITY.get(k) == "positive"),
            "negative": sum(v for k, v in by.items() if KIND_POLARITY.get(k) == "negative"),
            "pending": sum(1 for r in rows if r.get("rsi_status") == "pending"),
            "settled": settled,
            "settle_rate": round(settled / len(rows), 3) if rows else 0.0,
            # 新增（旧看板不使用则完全兼容）：已结案但只生成草稿 / 已发布 / 行为真的改变
            "draft_generated": draft_generated,
            "published": published,
            "behavior_changed": behavior_changed,
            "candidate_pending": sum(1 for r in rows
                                     if r.get("rsi_status") == SETTLE_PENDING_STATUS),
            # L98 P1：抽样偏差口径（exposure/reviewed/coverage/sampling_rate +
            # 未告警文档审查 + 影子观察分母）。附加键，旧看板字段逐字不变。
            "observation": sampling_bias_stats(),
            "source": "feedback", "authority": "feedback 表（单一反馈台账）"}


def ledger(limit: int = 200) -> dict:
    """单一反馈台账视图（P1-05）：/feedback 与 /evolution/feedback 的 ledger 同源。

    权威数据源只有 ``feedback`` 表；evolution_task 只作为沉淀动作记录，不再作为
    独立统计口径（避免 24/0 双台账）。调用方（HTTP 路由）直接返回本结构即可。
    """
    return {"source": "feedback",
            "authority": "feedback 表（单一反馈台账）",
            "items": list_feedback(limit=limit),
            "stats": stats(),
            "rules": rule_ledger()}




def status_labels() -> dict:
    """反馈 rsi_status 中文标签单一来源（P1-06：draft/frozen/blocked 也要有中文）。"""
    return {"pending": "待沉淀", "settled": "已沉淀", "ignored": "已忽略",
            "draft": "草稿（已保存参数/规则版本，未发布）", "frozen": "改进器冻结（未生效）",
            "blocked": "已阻断（沉淀物不可执行）",
            "settling": "处置中（write-ahead 标记；崩溃后重试走恢复路径）",
            "candidate_pending": "候选待重试（规则已变更，反馈→候选追溯记录写入失败）"}


def rule_ledger() -> list:
    """按规则聚合正反向反馈，供规则健康度与进化建议。"""
    rows = list_feedback()
    agg = {}
    for r in rows:
        code = r["rule_code"] or "MANUAL"
        a = agg.setdefault(code, {"rule_code": code, "confirm": 0, "false_positive": 0,
                                  "need_evidence": 0, "ignored": 0, "manual": 0,
                                  "supplement": 0, "total": 0})
        a[r["kind"]] = a.get(r["kind"], 0) + 1
        a["total"] += 1
    out = []
    for code, a in agg.items():
        neg = a["false_positive"] + a["manual"]
        a["override_rate"] = round(neg / a["total"], 3) if a["total"] else 0.0
        a["advice"] = ("从未被确认：规则可能过严或未覆盖" if a["confirm"] == 0 and neg > 0
                       else "override 偏高：建议修订条件或降级为疑似" if a["override_rate"] >= 0.4
                       else "健康")
        out.append(a)
    out.sort(key=lambda x: (-x["override_rate"], -x["total"]))
    return out


# P2-04 补全（T-116）：反馈沉淀/忽略的「反馈状态变更 + 审计」必须同一事务。
# 参考 T-115 `app/services/rule.py` 的 `audit.log_in_tx(c, ...)` 写法：
# 与 ``R.feedback.update`` / ``R.audit_logs.log`` 的区别是**不自行 commit、不吞异常**；
# 审计插入失败向上抛 → ``db.session()`` 回滚状态写，调用方请求失败（HTTP 路由未捕获
# 时为服务端异常/断连，不再是 200 假成功），绝不出现“反馈状态已变、审计缺失”的半写。
def _settle_write(feedback_id: str, status: str, action: str, user: str = "",
                  rule_id: str = "", after: str = "", audit_action: str = "",
                  suppression: tuple = None, extra_audits: list = None,
                  extra_updates: list = None, payload_patch: dict = None) -> None:
    """在同一事务内写反馈状态 + 审计（可选：误报抑制行 + 额外审计 + 台账同步）。

    - ``suppression``: (id, point_id, doc_type, reason, created_at)，ignore 分支的抑制写；
    - ``extra_audits``: [(action, object, after), ...]，如 point.suppressed；
    - ``extra_updates``: [(sql, params), ...]，如同步 evolution_task 台账（B6 两本账合一）；
    - ``payload_patch``: 追加/合并 ``feedback.payload`` 的顶层键（如 ``settle`` 语义），
      与状态/审计同一事务写；旧 payload 键不动（旧看板兼容）。
    - 隔离口径与 ``FeedbackRepo.update`` 一致（上下文存在时按租户过滤），不裸改他租户行。
    """
    from . import audit as _audit_svc
    where, wparams = R.feedback._scope_sql("id=?", (feedback_id,))
    with db.session() as c:
        if suppression is not None:
            c.execute("INSERT INTO point_suppression(id, point_id, doc_type, reason, created_at) "
                      "VALUES(?,?,?,?,?)", list(suppression))
        c.execute(f"UPDATE feedback SET rsi_status=?, rsi_action=?, rsi_rule_id=?, "
                  f"handled_at=?, handled_by=? WHERE {where}",
                  [status, action, rule_id, db.now(), user or "", *wparams])
        for _upd in (extra_updates or []):
            c.execute(_upd[0], list(_upd[1]) if len(_upd) > 1 else [])
        if payload_patch:
            # 旧 payload（reason/detail/source…）原样保留，只合并顶层键
            row = c.execute(f"SELECT payload FROM feedback WHERE {where}",
                            list(wparams)).fetchone()
            merged = {}
            if row is not None:
                try:
                    merged = json.loads(row["payload"] or "{}") or {}
                except Exception:
                    merged = {}
                if not isinstance(merged, dict):
                    merged = {}
            merged.update(payload_patch)
            c.execute(f"UPDATE feedback SET payload=? WHERE {where}",
                      [json.dumps(merged, ensure_ascii=False), *wparams])
        _audit_svc.log_in_tx(c, actor=user or "system",
                             action=audit_action or f"feedback.{action}",
                             object_=feedback_id, after=after)
        for _item in (extra_audits or []):
            _extra_after = _item[2] if len(_item) > 2 else ""
            _audit_svc.log_in_tx(c, actor=user or "system", action=_item[0],
                                 object_=_item[1], after=_extra_after)


def _evo_task_sync(finding_id: str, status: str, action: str, rule_id: str,
                   note: str, user: str) -> list:
    """B6 两本账合一（新账）：把同一条反馈对应的 evolution_task 状态同步到 feedback 状态。

    历史存量（53 条停在 analyzed）不在本函数处理，见落地报告 NOT DONE；
    这里只保证「本次沉淀之后两本账不再分叉」。返回 ``_settle_write`` 的 extra_updates。
    """
    if not finding_id:
        return []
    try:
        with db.session() as c:
            row = c.execute("SELECT id FROM evolution_task WHERE finding_id=? "
                            "ORDER BY rowid DESC LIMIT 1", (finding_id,)).fetchone()
        if not row:
            return []
        return [("UPDATE evolution_task SET status=?, action=?, rule_id=?, note=?, "
                 "handled_at=?, handled_by=? WHERE id=?",
                 (status, action, rule_id, note, db.now(), user or "", row["id"]))]
    except Exception:
        logging.getLogger(__name__).warning("evolution_task sync skipped", exc_info=True)
        return []


# ---------------------------------------------------------------------------
# 2026-11-22 A 类修复：候选失败可恢复 + settled 语义拆分 + 重试幂等
# 依据：docs/qa/外部评审_Codex独立工程评审_20261122.md §六（可具体定位的断点）
# ---------------------------------------------------------------------------
def strict_settle_enabled() -> bool:
    """``RULEPROOF_FEEDBACK_STRICT_SETTLE`` 开关：默认 1=严格；0=回退旧静默行为。"""
    raw = str(os.environ.get(STRICT_SETTLE_ENV) or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


def _payload_of(row: dict) -> dict:
    try:
        payload = json.loads((row or {}).get("payload") or "{}")
    except Exception:
        payload = {}
    return payload if isinstance(payload, dict) else {}


def _settle_record(row: dict) -> dict:
    """读取反馈行里已落库的沉淀语义（``payload.settle``）；无则空 dict（旧数据）。"""
    rec = _payload_of(row).get("settle")
    return rec if isinstance(rec, dict) and rec.get("v") == SETTLE_SEMANTICS_VERSION else {}




def _persisted_settle_payload(action: str, status: str, msg: str, rule_id: str,
                              semantics: dict, *, before: dict = None, after: dict = None,
                              candidate_id: str = "", candidate_note: str = "",
                              pending: bool = False, error: str = "",
                              attempts: int = 1) -> dict:
    """落库到 feedback.payload.settle 的结构；``pending=True`` 时供重试补齐候选。"""
    return {"settle": {"v": SETTLE_SEMANTICS_VERSION, "action": action,
                       "applied_status": status, "message": msg, "rule_id": rule_id,
                       "settled": bool(semantics.get("settled")),
                       "draft_generated": bool(semantics.get("draft_generated")),
                       "published": bool(semantics.get("published")),
                       "behavior_changed": bool(semantics.get("behavior_changed")),
                       "draft_version": semantics.get("draft_version") or "",
                       "effective_version": semantics.get("effective_version") or "",
                       "candidate_id": candidate_id or "",
                       "candidate_note": candidate_note or msg,
                       "before": before or {}, "after": after or {},
                       "pending": bool(pending), "last_error": error or "",
                       "attempts": int(attempts), "at": db.now()}}


def _candidate_pending_result(feedback_id: str, action: str, status: str, msg: str,
                              rule_id: str, semantics: dict, error: str,
                              attempts: int = 1) -> dict:
    """候选写入失败的返回契约：可恢复、可重试，且明确「规则变更已落库」。"""
    return {"ok": False, "status": SETTLE_PENDING_STATUS, "state": SETTLE_PENDING_STATUS,
            "retryable": True, "error": f"候选追溯记录写入失败：{error}",
            "message": (msg + "；规则变更已落库，但「反馈→候选」追溯记录缺失。"
                        "以相同 feedback/action 重试只会补候选，不会重复草稿或重复发布"),
            "feedback_id": feedback_id, "action": action, "rule_id": rule_id,
            "candidate_id": "",
            "settled": False, "draft_generated": bool(semantics.get("draft_generated")),
            "published": bool(semantics.get("published")),
            "behavior_changed": bool(semantics.get("behavior_changed")),
            "draft_version": semantics.get("draft_version") or "",
            "effective_version": semantics.get("effective_version") or "",
            "attempts": int(attempts)}


def _candidate_ids_for(feedback_id: str) -> list:
    """该反馈已落库的候选 id 列表（重试幂等：已存在则复用，不重复插入）。"""
    try:
        rows = R.rsi_candidates.list("feedback_id=?", (feedback_id,), order="rowid DESC")
    except Exception:
        try:
            rows = R.rsi_candidates.list("feedback_id=?", (feedback_id,))
        except Exception:
            return []
    return [str((x or {}).get("id") or "") for x in rows if (x or {}).get("id")]


# ---------------------------------------------------------------------------
# 2026-11-23 LaneM（A 类缺陷 B1）：处置开始标记（write-ahead）+ 崩溃恢复
# 依据：docs/qa/反馈闭环演练_20261123.md §5（kill -9 后 rsi_status=pending、payload 无
# settle、候选 0 行，但规则已 fork+发布；重试多出 2 个版本、rule.published 审计 3 条）。
# ---------------------------------------------------------------------------
def wal_enabled() -> bool:
    """``RULEPROOF_FEEDBACK_WAL`` 开关：默认 1=write-ahead + 崩溃恢复；0=旧行为。"""
    raw = str(os.environ.get(WAL_ENV) or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


def _wal_needed(action: str, row: dict) -> bool:
    """只有「反馈状态落库之前先写规则侧」的处置才需要处置开始标记。"""
    if action == "new_rule":
        return True
    if action != "revise":
        return False
    return bool((row.get("rule_code") or "").strip())


def _audit_max_rowid() -> int:
    """当前审计表最大 rowid（恢复时用来判断「标记之后」是否已写规则侧草稿/发布）。"""
    try:
        with db.session() as c:
            row = c.execute("SELECT COALESCE(MAX(rowid),0) AS m FROM audit_log").fetchone()
        return int((row or {})["m"] or 0)
    except Exception:
        return 0


def _audits_after(object_: str, actions, from_rowid: int) -> list:
    """取 object 在 from_rowid 之后落库的指定动作审计（恢复进度判据，只读）。"""
    allow = set(actions or ())
    if not object_ or not allow:
        return []
    try:
        rows = R.audit_logs.list("object=? AND rowid>?", (object_, int(from_rowid or 0)),
                                 order="rowid ASC", limit=500)
    except Exception:
        return []
    return [x for x in rows if str(x.get("action") or "") in allow]


def _param_num_changed(before_params: dict, after_params: dict) -> bool:
    """数值参数是否真的改变（×1.0 占位修订 → False，与首次成功路径同口径）。"""
    orig = (before_params or {}).get("value")
    newv = (after_params or {}).get("value")
    if orig is None or newv is None:
        return False
    try:
        return float(orig) != float(newv)
    except (TypeError, ValueError):
        return str(orig) != str(newv)


def _wal_begin(feedback_id: str, row: dict, action: str, user: str,
               auto_publish: bool, before: dict) -> dict:
    """规则写之前落「处置开始」标记（独立事务、先于规则写）。

    标记内容足以让崩溃后的进程判断规则侧/候选侧进度：
    - ``before_rule_version`` / ``before_version_ids`` / ``before_rule_status``：
      恢复时按「版本集合差」判断 fork 是否已提交、是否已发布；
    - ``audit_rowid``：内置参数/行为旁路无 rule_version，用标记之后的 rule.param_* 审计判断；
    - ``new_rule_code``：new_rule 路径预生成规则编码，恢复时按编码复用已建规则，不重复建；
    - ``before``：沉淀前 params/behavior 快照，恢复补候选时复用同一 before。
    """
    rc = (row.get("rule_code") or "").strip()
    ctx = {"state": SETTLING_STATUS, "started_at": db.now(), "action": action,
           "auto_publish": bool(auto_publish), "rule_code": rc,
           "audit_rowid": _audit_max_rowid(),
           "before_rule_version": "", "before_rule_status": "",
           "before_version_id": "", "before_version_ids": [], "before_marks": [],
           "new_rule_code": "", "before": before if isinstance(before, dict) else {}}
    rule_id = ""
    if action == "new_rule":
        ctx["new_rule_code"] = f"SED-{db.new_id('x')[:6].upper()}"
    elif rc:
        try:
            for r in R.rules.list("code=?", (rc,)):
                if r.get("id"):
                    rule_id = str(r["id"])
                    break
        except Exception:
            rule_id = ""
        if rule_id:
            ctx["rule_id"] = rule_id
            _rstatus = str((R.rules.get(rule_id) or {}).get("status") or "draft")
            ctx["before_rule_status"] = _rstatus
            try:
                _vers = R.rule_versions.list("rule_id=?", (rule_id,))
            except Exception:
                _vers = []
            ctx["before_version_ids"] = [str(v.get("id") or "") for v in _vers if v.get("id")]
            _base = ((R.rules.published_version(rule_id) if _rstatus == "published"
                      else R.rules.latest_version(rule_id)) or {})
            ctx["before_rule_version"] = str(_base.get("version") or "")
            ctx["before_version_id"] = str(_base.get("id") or "")
            try:
                _slots = json.loads(_base.get("slots_json") or "{}")
            except Exception:
                _slots = {}
            if isinstance(_slots, dict):
                ctx["before_marks"] = [str(x) for x in (_slots.get("false_positive_quotes") or [])
                                       if str(x).strip()]
    wal = {"v": SETTLE_SEMANTICS_VERSION, **ctx}
    _settle_write(feedback_id, status=SETTLING_STATUS, action=action, user=user,
                  rule_id=rule_id, after="处置开始（write-ahead 标记，规则写之前）",
                  audit_action="feedback.settle_started", payload_patch={"settle": wal})
    return wal


def _wal_rewind(feedback_id: str, action: str, user: str) -> None:
    """恢复兜底：标记存在但规则侧确认未写入 → 清标记回 pending，复用首次成功路径重跑。"""
    from . import audit as _audit_svc
    where, wparams = R.feedback._scope_sql("id=?", (feedback_id,))
    with db.session() as c:
        row = c.execute(f"SELECT payload FROM feedback WHERE {where}", list(wparams)).fetchone()
        merged = {}
        if row is not None:
            try:
                merged = json.loads(row["payload"] or "{}") or {}
            except Exception:
                merged = {}
            if not isinstance(merged, dict):
                merged = {}
        merged.pop("settle", None)
        c.execute(f"UPDATE feedback SET rsi_status='pending', rsi_action='', rsi_rule_id='', "
                  f"handled_at='', handled_by='', payload=? WHERE {where}",
                  [json.dumps(merged, ensure_ascii=False), *wparams])
        _audit_svc.log_in_tx(c, actor=user or "system", action="feedback.settle_rewind",
                             object_=feedback_id,
                             after="处置开始标记存在但规则侧未写入：回退 pending 并改走首次成功路径")


def _find_new_rule_for_feedback(wal: dict, feedback_id: str) -> str:
    """new_rule 恢复：按 WAL 预生成编码（兜底：slots.from_feedback）找已建规则。"""
    code = str((wal or {}).get("new_rule_code") or "").strip()
    if code:
        try:
            for r in R.rules.list("code=?", (code,)):
                if r.get("id"):
                    return str(r["id"])
        except Exception:  # noqa: BLE001 - 回查失败返回空，但必须留痕（铁律 2）
            logging.getLogger(__name__).warning(
                "反馈 WAL 回查规则失败（rule_code=%s）", code, exc_info=True)
    try:
        for v in R.rule_versions.list():
            try:
                slots = json.loads(v.get("slots_json") or "{}")
            except Exception:
                continue
            if isinstance(slots, dict) and str(slots.get("from_feedback") or "") == str(feedback_id):
                return str(v.get("rule_id") or "")
    except Exception:
        pass
    return ""


def _recover_settle(feedback_id: str, row: dict, action: str, note: str, user: str,
                    auto_publish: bool, wal: dict, _depth: int = 0) -> dict:
    """崩溃恢复：按 write-ahead 标记补齐缺失步骤，不重复写规则 / 不重复发布。

    - 规则版本路径：版本集合与 ``before_version_ids`` 求差判断 fork 是否已提交；
      已 published 直接复用（不再发布），已 fork 未发布则只补发布；
    - new_rule 路径：按 WAL 预生成编码复用已建规则，不重复 create；
    - 内置参数/行为旁路：用标记 ``audit_rowid`` 之后的 rule.param_* / rule.behavior_* 审计
      判断「已写草稿 / 已发布」，缺发布才补发布；
    - 若规则侧确认未写入：清标记回 pending 后复用首次成功路径（不重复任何已写步骤）。
    """
    from . import rsi_protocol as _proto
    from . import rule
    _strict = strict_settle_enabled()
    _attempts = int(wal.get("attempts") or 1) + 1
    rc = str(wal.get("rule_code") or (row.get("rule_code") or "")).strip()
    _before = wal.get("before") if isinstance(wal.get("before"), dict) else (
        # B3（2026-11-23 LaneY）：候选门禁快照必须含规则版本内容（见 rsi_protocol.gate_snapshot）
        _proto.gate_snapshot(rc) if rc else {"params": {}, "behavior": {}})
    _sem = {"settled": True, "draft_generated": False, "published": False,
            "behavior_changed": False, "draft_version": "", "effective_version": ""}
    rule_id = str(wal.get("rule_id") or "")
    status = "settled"
    msg = ""
    _redo = False

    if action == "new_rule":
        _rid = _find_new_rule_for_feedback(wal, feedback_id)
        if _rid:
            rule_id = _rid
            status = "settled"
            msg = "已生成新规则草稿（崩溃恢复：复用已写入规则，未重复创建）"
            _sem.update(draft_generated=True)
        else:
            _redo = True
    elif action == "revise" and rc:
        rid = rule_id
        if not rid:
            try:
                for r in R.rules.list("code=?", (rc,)):
                    if r.get("id"):
                        rid = str(r["id"])
                        break
            except Exception:
                rid = ""
        if rid:
            rule_id = rid
            _before_ids = [str(x) for x in (wal.get("before_version_ids") or [])]
            try:
                _vers = R.rule_versions.list("rule_id=?", (rid,))
            except Exception:
                _vers = []
            _new_vers = [v for v in _vers if str(v.get("id") or "") not in _before_ids]
            _new_ver = _new_vers[-1] if _new_vers else None
            if not _new_ver:
                _redo = True
            else:
                _before_status = str(wal.get("before_rule_status") or "")
                _forked = _before_status in ("approved", "published")
                _dv = str(_new_ver.get("version") or "")
                _quote = ""
                try:
                    from . import evolution as _evo
                    _quote = (_evo._finding_quote(row.get("finding_id") or "") or "").strip()
                except Exception:
                    logging.getLogger(__name__).warning(
                        "recovery finding quote lookup skipped", exc_info=True)
                _base_marks = [str(x) for x in (wal.get("before_marks") or [])]
                _quote_added = bool(_quote and _quote not in _base_marks)
                _note = ("含负例卡（误报引文）" if _quote else "无新增引文（仅生成修订草稿）")
                _eff_now = str((R.rules.published_version(rid) or {}).get("version") or "")
                if auto_publish:
                    if str(_new_ver.get("status") or "") == "published":
                        status = "settled"
                        msg = (f"已沉淀并发布 {rc} {_dv}（崩溃恢复：复用已发布版本，"
                               f"未重复发布；{_note}）")
                        _sem.update(published=True, draft_generated=False,
                                    effective_version=_dv,
                                    behavior_changed=bool(_quote_added or _forked))
                    else:
                        _pub = rule.publish(rid, actor=user or "system")
                        if _pub.get("error"):
                            status = "draft"
                            msg = (f"已生成 {rc} 修订草稿 {_dv}（规则进入修订中，旧生效版本 "
                                   f"{_eff_now or '无'} 继续执行）；崩溃恢复时自动发布失败："
                                   f"{_pub.get('message') or _pub.get('error')}")
                            _sem.update(draft_generated=_forked, draft_version=_dv,
                                        effective_version=_eff_now)
                        else:
                            status = "settled"
                            _eff_new = str(_pub.get("effective_version") or _dv)
                            msg = (f"已沉淀并发布 {rc} {_eff_new}"
                                   f"（崩溃恢复：补发布已写入草稿；{_note}）")
                            _sem.update(published=True, draft_generated=False,
                                        effective_version=_eff_new,
                                        behavior_changed=bool(_quote_added or _forked))
                else:
                    status = "settled"
                    msg = (f"已生成 {rc} 新版本草稿 {_dv}（崩溃恢复：复用已写入草稿）；"
                           f"规则进入修订中，旧生效版本 {_eff_now or '无'} 继续执行")
                    _sem.update(draft_generated=_forked, draft_version=_dv,
                                effective_version=_eff_now)
        else:
            # 内置规则：参数 / 行为旁路（无 rule_version，用标记之后的审计判断进度）
            _draft_acts = ("rule.param_drafted", "rule.behavior_drafted", "rule.option_drafted")
            _pub_acts = ("rule.param_published", "rule.param_blocked_conflict")
            _rows = _audits_after(rc, _draft_acts + _pub_acts, wal.get("audit_rowid") or 0)
            _actions = {str(x.get("action") or "") for x in _rows}
            _drafted = bool(_actions & set(_draft_acts))
            _published = "rule.param_published" in _actions
            if not _drafted:
                _redo = True
            else:
                from . import ruleparam as _rp
                _pending = {}
                try:
                    _pending = _rp.pending(rc) or {}
                except Exception:
                    _pending = {}
                _is_behavior = not (_pending.get("value") is not None
                                    or _pending.get("lo") is not None)
                if auto_publish and not _published:
                    try:
                        _pub_p = _rp.publish(rc, user or "system") or {}
                    except Exception as e:  # noqa: BLE001 - 如实降级为草稿，不声称已生效
                        _pub_p = {"error": f"{type(e).__name__}: {e}"}
                    _pub_ok = bool(_pub_p.get("published")) and not _pub_p.get("error")
                    if _pub_ok:
                        status = "settled"
                        if _is_behavior:
                            _sem.update(published=True, behavior_changed=True)
                            msg = (f"已调整并发布规则 {rc} 行为"
                                   f"（崩溃恢复：补发布已写入草稿），下一轮生效")
                        else:
                            _num_changed = _param_num_changed(
                                (_before.get("params") or {}), _pending)
                            _sem.update(published=True, behavior_changed=_num_changed)
                            msg = (f"已更新并发布内置规则参数 {rc}"
                                   f"（崩溃恢复：补发布已写入草稿，下一轮审核生效）")
                            if not _num_changed:
                                msg += "；但数值原值未变化（×1.0 占位修订），执行行为未改变"
                    else:
                        status = "draft"
                        _sem.update(draft_generated=True)
                        msg = (f"已写入 {rc} 参数草稿（崩溃恢复），但发布未成功"
                               f"（{_pub_p.get('error') or '未发布'}）；不声称已生效")
                elif auto_publish and _published:
                    status = "settled"
                    if _is_behavior:
                        _sem.update(published=True, behavior_changed=True)
                        msg = f"已调整并发布规则 {rc} 行为（崩溃恢复：复用已发布参数）"
                    else:
                        _num_changed = _param_num_changed(
                            (_before.get("params") or {}), _pending)
                        _sem.update(published=True, behavior_changed=_num_changed)
                        msg = f"已更新并发布内置规则参数 {rc}（崩溃恢复：复用已发布参数）"
                else:
                    status = "draft"
                    _sem.update(draft_generated=True)
                    msg = f"已保存参数草稿 {rc}（崩溃恢复：复用已写入草稿，未发布不生效）"
    else:
        _redo = True

    if _redo:
        if _depth >= 1:
            return {"ok": False, "status": SETTLING_STATUS, "state": SETTLING_STATUS,
                    "retryable": True,
                    "error": "崩溃恢复未完成（规则侧未写入且恢复递归过深），请再次以相同 action 重试",
                    "feedback_id": feedback_id, "action": action,
                    "candidate_id": "", "settled": False, "resumed": False}
        # 规则侧确认未写入：清标记回 pending 后复用首次成功路径（不重复任何已写步骤）
        _wal_rewind(feedback_id, action, user)
        logging.getLogger(__name__).warning(
            "feedback settle WAL rewind to first-run path feedback=%s action=%s",
            feedback_id, action)
        return settle(feedback_id, action=action, note=note, user=user,
                      auto_publish=auto_publish, _recovery_depth=_depth + 1)

    # ---- 候选补齐（已存在则复用；失败保持可恢复状态，不假成功）----
    # B3（LaneY）：after 快照同样走 gate_snapshot，保证候选记录含规则版本内容。
    _after = _proto.gate_snapshot(rc) if rc else {"params": {}, "behavior": {}}
    _existing = _candidate_ids_for(feedback_id)
    cand = _existing[0] if _existing else ""
    if not cand:
        try:
            cand = _proto.record_candidate(feedback_id, rc, action, _before, _after,
                                           note=msg, by=user or "system")
        except Exception as _ce:  # noqa: BLE001
            _err = f"{type(_ce).__name__}: {_ce}"
            logging.getLogger(__name__).error(
                "feedback candidate recovery write failed feedback=%s: %s",
                feedback_id, _err, exc_info=True)
            if not _strict:
                cand = ""       # =0 回旧行为：吞异常继续落终态
            else:
                _existing = _candidate_ids_for(feedback_id)
                if _existing:
                    cand = _existing[0]
                else:
                    _patch = _persisted_settle_payload(
                        action, status, msg, rule_id, _sem, before=_before, after=_after,
                        pending=True, error=_err, attempts=_attempts)
                    _settle_write(feedback_id, status=SETTLE_PENDING_STATUS, action=action,
                                  user=user, rule_id=rule_id,
                                  after=(msg + "；崩溃恢复时候选追溯记录写入失败，待重试"),
                                  audit_action="feedback.candidate_pending",
                                  extra_updates=_evo_task_sync(
                                      row.get("finding_id") or "", SETTLE_PENDING_STATUS,
                                      action, rule_id, "崩溃恢复候选写入失败", user),
                                  payload_patch=_patch)
                    return _candidate_pending_result(feedback_id, action, status, msg,
                                                     rule_id, _sem, _err, attempts=_attempts)
    # ---- 反馈终态落库（与首次成功路径同一结构：settled 语义 + 状态 + 审计同事务）----
    _final_sem = {**_sem, "settled": True}
    _settle_write(feedback_id, status=status, action=action, user=user, rule_id=rule_id,
                  after=msg, audit_action=f"feedback.{action}",
                  extra_updates=_evo_task_sync(row.get("finding_id") or "", status, action,
                                               rule_id, msg, user),
                  payload_patch=_persisted_settle_payload(
                      action, status, msg, rule_id, _final_sem, before=_before, after=_after,
                      candidate_id=cand, candidate_note=msg, attempts=_attempts))
    return {"ok": True, "status": status, "message": msg, "rule_id": rule_id,
            "candidate_id": cand, "settled": True,
            "draft_generated": bool(_sem.get("draft_generated")),
            "published": bool(_sem.get("published")),
            "behavior_changed": bool(_sem.get("behavior_changed")),
            "draft_version": _sem.get("draft_version") or "",
            "effective_version": _sem.get("effective_version") or "",
            "resumed": True, "idempotent_replay": True,
            "recovered_from": SETTLING_STATUS, "attempts": _attempts,
            "strict_settle": _strict}


def _retry_candidate_only(feedback_id: str, row: dict, action: str, user: str,
                          prev: dict) -> dict:
    """严格模式重试：规则/参数变更已落库，本次只补「反馈→候选」追溯记录。

    幂等保证：①不重跑任何规则/参数写（不重复草稿/发布）；②候选已存在则复用；
    ③成功后反馈状态按首次已应用的 status 落库，payload.settle.pending=False。
    """
    from . import rsi_protocol as _proto
    _attempts = int(prev.get("attempts") or 1)
    _existing = _candidate_ids_for(feedback_id)
    if _existing:
        cand = _existing[0]
    else:
        try:
            cand = _proto.record_candidate(
                feedback_id, (row.get("rule_code") or "").strip(), action,
                prev.get("before") or {}, prev.get("after") or {},
                note=str(prev.get("candidate_note") or prev.get("message") or ""),
                by=user or "system")
        except Exception as e:  # noqa: BLE001 - 重试仍失败：保持可恢复状态，不假成功
            logging.getLogger(__name__).warning(
                "feedback candidate retry failed feedback=%s", feedback_id, exc_info=True)
            _patch = _persisted_settle_payload(
                action, str(prev.get("applied_status") or "settled"),
                str(prev.get("message") or ""), str(prev.get("rule_id") or ""),
                {"draft_generated": bool(prev.get("draft_generated")),
                 "published": bool(prev.get("published")),
                 "behavior_changed": bool(prev.get("behavior_changed")),
                 "draft_version": prev.get("draft_version") or "",
                 "effective_version": prev.get("effective_version") or ""},
                before=prev.get("before") or {}, after=prev.get("after") or {},
                pending=True, error=f"{type(e).__name__}: {e}", attempts=_attempts + 1)
            _settle_write(feedback_id, status=SETTLE_PENDING_STATUS, action=action, user=user,
                          rule_id=str(prev.get("rule_id") or ""),
                          after=(str(prev.get("message") or "") + "；候选重试仍失败"),
                          audit_action="feedback.candidate_pending",
                          extra_updates=_evo_task_sync(
                              row.get("finding_id") or "", SETTLE_PENDING_STATUS, action,
                              str(prev.get("rule_id") or ""), "候选重试仍失败", user),
                          payload_patch=_patch)
            return _candidate_pending_result(
                feedback_id, action, str(prev.get("applied_status") or "settled"),
                str(prev.get("message") or ""), str(prev.get("rule_id") or ""),
                {"draft_generated": bool(prev.get("draft_generated")),
                 "published": bool(prev.get("published")),
                 "behavior_changed": bool(prev.get("behavior_changed")),
                 "draft_version": prev.get("draft_version") or "",
                 "effective_version": prev.get("effective_version") or ""},
                f"{type(e).__name__}: {e}", attempts=_attempts + 1)
    _status = str(prev.get("applied_status") or "settled")
    _sem = {"draft_generated": bool(prev.get("draft_generated")),
            "published": bool(prev.get("published")),
            "behavior_changed": bool(prev.get("behavior_changed")),
            "draft_version": prev.get("draft_version") or "",
            "effective_version": prev.get("effective_version") or ""}
    _msg = str(prev.get("message") or "")
    _rid = str(prev.get("rule_id") or "")
    _settle_write(feedback_id, status=_status, action=action, user=user, rule_id=_rid,
                  after=_msg + "；候选已补记", audit_action=f"feedback.{action}",
                  extra_updates=_evo_task_sync(row.get("finding_id") or "", _status, action,
                                               _rid, _msg, user),
                  payload_patch=_persisted_settle_payload(
                      action, _status, _msg, _rid, {**_sem, "settled": True},
                      before=prev.get("before") or {}, after=prev.get("after") or {},
                      candidate_id=cand, candidate_note=str(prev.get("candidate_note") or ""),
                      attempts=_attempts + 1))
    return {"ok": True, "status": _status, "message": _msg, "rule_id": _rid,
            "candidate_id": cand, "settled": True,
            "draft_generated": _sem["draft_generated"], "published": _sem["published"],
            "behavior_changed": _sem["behavior_changed"],
            "draft_version": _sem["draft_version"],
            "effective_version": _sem["effective_version"],
            "retried_candidate": True, "attempts": _attempts + 1}


def _nr_payload_of(row: dict) -> dict:
    """反馈 payload（new_rule 结构生成的输入；损坏/非 dict 时留痕并返回空）。"""
    try:
        out = json.loads((row or {}).get("payload") or "{}")
    except Exception:  # noqa: BLE001 - payload 损坏不阻断沉淀，但必须留痕（铁律 2）
        logging.getLogger(__name__).warning(
            "反馈 payload 不可解析（new_rule 结构生成降级）feedback=%s",
            (row or {}).get("id"), exc_info=True)
        return {}
    return out if isinstance(out, dict) else {}


def _nr_scope_types_from_doc(document_id: str) -> list:
    """从项目文档推导适用文件类型（doc_type / 扩展名），只保留服务端白名单 token。"""
    if not document_id:
        return []
    try:
        doc = R.documents.get(document_id) or {}
    except Exception:  # noqa: BLE001 - 文档回查失败不阻断，留痕后继续（铁律 2）
        logging.getLogger(__name__).warning(
            "人工漏报文档回查失败 document=%s", document_id, exc_info=True)
        return []
    from . import rule as _rule
    cands = [str(doc.get("doc_type") or "").strip()]
    _filename = str(doc.get("filename") or doc.get("path") or "")
    if "." in _filename:
        cands.append(_filename.rsplit(".", 1)[-1].strip())
    for token in cands:
        if not token:
            continue
        try:
            norm = _rule.normalize_scope_types([token])
        except ValueError:
            # 未知文档类型不是致命错误：继续尝试扩展名/其它来源，但留痕便于排查
            logging.getLogger(__name__).info(
                "new_rule scope type token 不在白名单，跳过：%s", token)
            continue
        if norm:
            return list(dict.fromkeys(norm))
    return []


def _nr_scope_types_from_case(case_id: str) -> list:
    """从项目/文档推导适用文件类型（项目文档类型/首份文档），作为文档级推导的补充。"""
    if not case_id:
        return []
    types: list = []
    try:
        case = R.cases.get(case_id) or {}
    except Exception:  # noqa: BLE001 - 回查失败留痕降级（铁律 2）
        logging.getLogger(__name__).warning(
            "人工漏报项目回查失败 case=%s", case_id, exc_info=True)
        case = {}
    from . import rule as _rule
    for token in (case.get("document_type"), case.get("audit_type")):
        token = str(token or "").strip()
        if not token:
            continue
        try:
            norm = _rule.normalize_scope_types([token])
        except ValueError:
            logging.getLogger(__name__).info(
                "new_rule case scope token 不在白名单，跳过：%s", token)
            continue
        types.extend(norm)
    if types:
        return list(dict.fromkeys(types))
    try:
        docs = R.cases.documents(case_id) or []
    except Exception:  # noqa: BLE001 - 文档列表回查失败留痕降级（铁律 2）
        logging.getLogger(__name__).warning(
            "人工漏报项目文档列表回查失败 case=%s", case_id, exc_info=True)
        docs = []
    for doc in docs[:3]:
        types.extend(_nr_scope_types_from_doc(str((doc or {}).get("id") or "")))
        if types:
            break
    return list(dict.fromkeys(types))


def _nr_rule_inheritance(rule_code: str) -> dict:
    """人工漏报若关联到既有规则：继承其证据/适用范围/执行口径（避免新规则空壳）。"""
    code = str(rule_code or "").strip()
    if not code:
        return {}
    try:
        row = next((x for x in R.rules.list("code=?", (code,)) if x.get("id")), None)
    except Exception:  # noqa: BLE001 - 规则回查失败留痕降级（铁律 2）
        logging.getLogger(__name__).warning(
            "new_rule 关联规则回查失败 rule_code=%s", code, exc_info=True)
        return {}
    if not row:
        return {}
    out: dict = {}
    try:
        scope = json.loads(row.get("scope_json") or "{}")
    except Exception:  # noqa: BLE001 - scope 损坏留痕降级（铁律 2）
        logging.getLogger(__name__).warning(
            "new_rule 关联规则 scope 不可解析 rule_code=%s", code, exc_info=True)
        scope = {}
    if isinstance(scope, dict):
        for key in ("applicable_types", "applicable_when", "evidence_scope",
                    "required_evidence"):
            if scope.get(key):
                out[key] = scope.get(key)
        pm = scope.get("point_mapping")
        if isinstance(pm, dict) and pm.get("point_id"):
            out["point_id"] = str(pm.get("point_id") or "")
    try:
        ver = R.rules.latest_version(row["id"]) or {}
        slots = json.loads(ver.get("slots_json") or "{}")
    except Exception:  # noqa: BLE001 - 版本槽位损坏留痕降级（铁律 2）
        logging.getLogger(__name__).warning(
            "new_rule 关联规则版本槽位不可解析 rule_code=%s", code, exc_info=True)
        slots = {}
    if isinstance(slots, dict):
        for key in ("required_evidence", "evidence_scope", "applicable_types",
                    "applicable_when", "scope", "point_id", "metric", "op", "value",
                    "unit", "range", "lo", "hi"):
            if slots.get(key) not in (None, "", [], {}) and not out.get(key):
                out[key] = slots.get(key)
    out["category"] = str(row.get("category") or "")
    out["rclass"] = str(row.get("rclass") or "")
    return out


def _nr_publish_gaps(slots: dict, scope: dict, name: str) -> dict:
    """发布前预检：与 rule._pre_lifecycle_gates 的 IR/scope 口径同源，返回缺口清单。

    返回 ``{ok, missing, suggestions, ir}``；``missing`` 是可操作的中文缺口名
    （判据/证据要求/适用范围…），用于 422 ``needs_structure`` 契约，避免把可补全的
    结构缺失伪装成发布期 400。
    """
    from .rule_ir import compile_rule as _ir_compile
    missing: list = []
    suggestions: list = []
    ir: dict = {}
    try:
        ir = _ir_compile(slots, NEW_RULE_CATEGORY, NEW_RULE_RCLASS, name) or {}
    except Exception as exc:  # noqa: BLE001 - 编译异常按“结构不可判定”处理并留痕（铁律 2）
        logging.getLogger(__name__).warning(
            "new_rule IR 预检编译失败（按 needs_structure 处理）: %s", type(exc).__name__,
            exc_info=True)
        return {"ok": False, "missing": ["判据"], "ir": {},
                "suggestions": ["判据无法编译为规则 IR，请补充可判定的业务要求"]}
    if not ir.get("complete"):
        missing.append("判据")
        suggestions.append("补充问题描述（至少一句可判定的业务要求）")
    for item in (ir.get("missing") or []):
        item = str(item or "").strip()
        if item and item not in missing:
            missing.append(item)
    for item in (ir.get("suggestions") or []):
        item = str(item or "").strip()
        if item and item not in suggestions:
            suggestions.append(item)
    # 规则级范围门禁（_scope_publish_gate 同口径）：scope_json 必须派生为已声明
    if not (scope.get("applicable_types") or scope.get("applicable_when")
            or slots.get("applicable_types") or slots.get("applicable_when")):
        if "适用范围" not in missing:
            missing.append("适用范围")
        suggestions.append("补充适用文档类型（document_id 可推导）或适用条件，避免默认全量执行")
    if not ir.get("publishable") and not missing:
        # IR 说不可发布但没给缺口名：按“判据/证据/范围”三类如实兜底，不静默
        for item in (ir.get("contract_errors") or []):
            code = str(item or "").split("：", 1)[0]
            name_map = {"evidence_missing": "证据要求", "scope_missing": "适用范围",
                        "requirement_missing": "判据", "free_text_not_typed": "typed 条件",
                        "tax_source_missing": "工具来源"}
            if name_map.get(code) and name_map[code] not in missing:
                missing.append(name_map[code])
        if not missing:
            missing.append("判据")
    return {"ok": bool(ir.get("publishable")) and not missing,
            "missing": list(dict.fromkeys(missing)),
            "suggestions": list(dict.fromkeys(suggestions))[:8],
            "ir": ir}


def _new_rule_structure(row: dict, finding: dict, payload: dict) -> dict:
    """人工漏报 → new_rule 的结构化 slots/scope + 缺口（A 类 B2 修复核心）。

    依据 docs/qa/反馈闭环演练_20261123.md §4.2：旧 new_rule 只写 criterion/point_id，
    R3 规则缺 required_evidence/applicable_types → ``ir_needs_structure`` 不可发布。
    本函数从 finding 的标题/描述/原文摘录/位置/文档类型派生发布必需结构；确实不足时
    返回非空 ``missing``（调用方回 422 ``needs_structure`` + 可操作清单，不静默 400）。
    """
    row = row or {}
    finding = finding or {}
    payload = payload or {}
    title = str(row.get("title") or finding.get("title") or "").strip()
    detail = str(payload.get("detail") or payload.get("reason") or "").strip()
    summary = str(finding.get("summary") or finding.get("description") or "").strip()
    desc = detail or summary
    if not desc and not title:
        desc = str(payload.get("note") or "").strip()
    suggestion = str(payload.get("suggestion") or finding.get("suggestion") or "").strip()
    quote = str(payload.get("quote") or "").strip()
    locator = str(payload.get("locator") or "").strip()
    document_id = str(payload.get("document_id") or "").strip()
    case_id = str(row.get("case_id") or finding.get("case_id") or "").strip()
    rule_code = str(row.get("rule_code") or "").strip()
    from . import rule as _rule

    missing: list = []
    suggestions: list = []

    # ---- 判据：标题 + 描述（人工漏报的业务要求）----
    criterion = f"{title}。{desc[:400]}" if (title and desc) else (title or desc)
    criterion = criterion.strip().strip("。 ").strip()[:500]
    if len([ch for ch in criterion if "\u4e00" <= ch <= "\u9fff"]) < 4:
        missing.append("判据")
        suggestions.append("补充问题描述（至少一句可判定的业务要求，如「冷藏温度不得高于8℃」）")

    # ---- 关联规则继承（人工漏报复核后关联到既有规则的场景）----
    inherit = _nr_rule_inheritance(rule_code) if rule_code not in ("", "MANUAL",
                                                                    MANUAL_MISSING_RULE_CODE) else {}

    # ---- 证据要求：引文 > 位置 > 描述句 > 关联规则继承 > 文档文件名 ----
    required_evidence = quote or str(inherit.get("required_evidence") or "").strip()
    if not required_evidence and locator:
        required_evidence = f"{locator}".strip()
    if not required_evidence and desc:
        # 描述里的首个分句作为“必需证据”载体（人工判据的证据载体是原文陈述）
        required_evidence = desc.split("，")[0].split("。")[0][:80].strip()
    if not required_evidence and document_id:
        try:
            doc = R.documents.get(document_id) or {}
            fname = str(doc.get("filename") or "").strip()
        except Exception:  # noqa: BLE001 - 回查失败留痕降级（铁律 2）
            logging.getLogger(__name__).warning(
                "new_rule 证据要求推导回查文档失败 document=%s", document_id, exc_info=True)
            fname = ""
        if fname:
            required_evidence = f"文件原文（{fname}）"
    if not required_evidence:
        missing.append("证据要求")
        suggestions.append("补充原文摘录/位置（quote/locator）或问题描述，作为必需证据")

    # ---- 证据范围：按位置形态选 document/row/block ----
    evidence_scope = list(inherit.get("evidence_scope") or [])
    if not evidence_scope:
        if any(k in locator for k in ("行", "line", "Line")):
            evidence_scope = ["row"]
        elif any(k in locator for k in ("单元格", "格", "列", "col")):
            evidence_scope = ["block"]
        else:
            evidence_scope = ["document"]
    try:
        evidence_scope = list(_rule.normalize_evidence_scope(evidence_scope))
    except ValueError:
        logging.getLogger(__name__).info(
            "new_rule 证据范围归一失败，回退 document：%s", evidence_scope)
        evidence_scope = ["document"]

    # ---- 适用范围：文档类型/扩展名 > 项目文档类型 > 关联规则继承 ----
    applicable_types = list(inherit.get("applicable_types") or [])
    if not applicable_types:
        applicable_types = _nr_scope_types_from_doc(document_id)
    if not applicable_types:
        applicable_types = _nr_scope_types_from_case(case_id)
    applicable_when = str(inherit.get("applicable_when") or "").strip()
    if not applicable_when:
        try:
            case = R.cases.get(case_id) or {} if case_id else {}
        except Exception:  # noqa: BLE001 - 项目回查失败留痕降级（铁律 2）
            logging.getLogger(__name__).warning(
                "new_rule 适用条件推导回查项目失败 case=%s", case_id, exc_info=True)
            case = {}
        applicable_when = str(case.get("focus") or case.get("audit_category")
                              or case.get("audit_type") or "").strip()[:200]
    if not applicable_types and not applicable_when:
        missing.append("适用范围")
        suggestions.append("补充适用文档类型（xlsx/docx/pdf/txt…）或适用条件，避免默认全量执行")

    # ---- 执行口径与点位 ----
    point_id = str(row.get("point_id") or payload.get("point_id")
                   or inherit.get("point_id") or finding.get("point_id") or "").strip()
    exec_scope = str(inherit.get("scope") or "").strip() or (quote or locator or title)[:200]

    slots: dict = {"criterion": criterion}
    if required_evidence:
        slots["required_evidence"] = required_evidence
    if evidence_scope:
        slots["evidence_scope"] = evidence_scope
    if applicable_types:
        slots["applicable_types"] = list(applicable_types)
    if applicable_when:
        slots["applicable_when"] = applicable_when
    if exec_scope:
        slots["scope"] = exec_scope
    if point_id:
        slots["point_id"] = point_id
    # 关联规则的确定性要素（若人工漏报是补既有规则的覆盖，可执行性更强的判据不丢）
    for key in ("metric", "op", "value", "unit", "range", "lo", "hi"):
        if inherit.get(key) not in (None, "", [], {}):
            slots[key] = inherit[key]
    # 从人工漏报的描述/摘录里抽取确定性数值判据（如「冷藏温度不得高于8℃」）：
    # 抽到 metric+op+(value|range) 时补 _template=limit，让新规则不仅能发布，还能立即确定性执行
    # （人工漏报的价值 = 补上漏检；纯语义 shell 只能走 agent-judge，演示/验收都弱）。
    if not (slots.get("metric") and (slots.get("value") not in (None, "")
                                     or slots.get("range"))):
        _limit_slots: dict = {}
        try:
            from ..engine import rule_schema as _rs
            _limit_tpls = [t for t in (_rs.TEMPLATES or [])
                           if str((t or {}).get("code") or "") == "limit"]
            if _limit_tpls:
                for _text in (detail, summary, title):
                    if not str(_text or "").strip():
                        continue
                    _fill = _rs.fill_slots(str(_text), _limit_tpls[0]) or {}
                    if (_fill.get("metric") and _fill.get("op")
                            and (_fill.get("value") not in (None, "")
                                 or _fill.get("range"))):
                        _limit_slots = _fill
                        break
        except Exception as exc:  # noqa: BLE001 - 抽取失败不影响“可发布”主目标，但要留痕
            logging.getLogger(__name__).warning(
                "new_rule 数值判据抽取失败（按语义规则沉淀）: %s", type(exc).__name__,
                exc_info=True)
        if _limit_slots.get("metric"):
            for key in ("metric", "op", "value", "unit", "range", "lo", "hi"):
                if _limit_slots.get(key) not in (None, "", [], {}):
                    slots[key] = _limit_slots[key]
            slots["_template"] = "limit"
            slots["_executor"] = "rule"
    if quote:
        slots["manual_quote"] = quote
    if locator:
        slots["manual_locator"] = locator
    if suggestion:
        slots["manual_suggestion"] = suggestion
    slots.update({"from_feedback": str(row.get("id") or ""),
                  "source_finding": str(row.get("finding_id") or finding.get("id") or ""),
                  "feedback_rule_code": rule_code,
                  "manual_missing": bool(not inherit),
                  "review_severity": str(payload.get("severity") or
                                         finding.get("severity") or "")})
    scope: dict = {"applicable_types": list(applicable_types),
                   "applicable_when": applicable_when,
                   "evidence_scope": list(evidence_scope),
                   "required_evidence": required_evidence}
    if point_id:
        scope["point_mapping"] = {"point_id": point_id}
    gaps = _nr_publish_gaps(slots, scope, title or str(row.get("title") or ""))
    all_missing = list(dict.fromkeys(missing + list(gaps.get("missing") or [])))
    all_suggestions = list(dict.fromkeys(suggestions + list(gaps.get("suggestions") or [])))
    # 缺口分两类：
    # - blocking（判据/证据要求/typed 条件/工具来源…）：无法从反馈内容补齐 → settle 返回
    #   422 needs_structure，不建“必然不可发布”的空壳规则；
    # - deferred（适用范围）：草稿箱有「补适用范围」既有流程，先建草稿并标记 publish_ready
    #   =false + missing，发布时 rule.py 仍返回 422 + missing（可操作，不静默 400）。
    _deferred = {"适用范围"}
    blocking_missing = [x for x in all_missing if x not in _deferred]
    deferred_missing = [x for x in all_missing if x in _deferred]
    return {"ok": not blocking_missing, "publishable": not all_missing,
            "slots": slots, "scope": scope,
            "missing": all_missing, "blocking_missing": blocking_missing,
            "deferred_missing": deferred_missing,
            "suggestions": all_suggestions[:8],
            "ir": gaps.get("ir") or {}, "criterion": criterion,
            "inherit_rule_code": rule_code if inherit else "",
            "sources": {"quote": bool(quote), "locator": bool(locator),
                        "document": bool(document_id), "description": bool(desc),
                        "applicable_types": list(applicable_types)}}


def settle(feedback_id: str, action: str = "revise", note: str = "", user: str = "",
           auto_publish: bool = False, _recovery_depth: int = 0) -> dict:
    """确认沉淀：把一条反馈落到规则库（新建/修订）或标记忽略。

    P0-05：写权限仅 admin（或经 ``RULEPROOF_FEEDBACK_SETTLE_ROLES`` 明确授权
    的角色）；super_admin/platform_op 按 F-28 拒绝；reviewer 与 UI 的“只读”一致，
    拒绝并写 ``feedback.settle_denied`` 审计。返回体带 ``status=403/code=forbidden``。

    T-116：反馈状态变更（settled/draft/ignored/frozen/blocked）与对应审计行经
    ``_settle_write`` 写在同一事务，审计失败整体回滚（无“状态已变、审计缺失”）；
    规则库写与 RSI 候选/门禁写仍为独立事务（写作用域不含 rule/ruleparam/
    rsi_protocol），残留与风险见 docs/qa/审计同事务补全_20261118.md。

    2026-11-22 A 类修复（Codex 外审 §六，``RULEPROOF_FEEDBACK_STRICT_SETTLE`` 默认 1）：
    - ``record_candidate`` 失败**不得返回 ok:True**：反馈状态落 ``candidate_pending``，
      返回 ``ok=False/state=candidate_pending/retryable=True/error``，规则变更已落库这一
      事实在 message/审计里写明；=0 回旧行为（吞异常、settled、candidate_id=""）。
    - 相同 feedback/action 重试：``candidate_pending`` 只补候选（复用已有候选、不重跑
      规则写 → 不重复草稿/发布）；已 settled/draft 的重复调用返回落库结果（幂等回放）。
    - 成功返回除旧 ``status`` 外新增 ``settled/draft_generated/published/
      behavior_changed``（只增字段；旧看板口径不变）。

    2026-11-23 LaneM（A 类缺陷 B1，``RULEPROOF_FEEDBACK_WAL`` 默认 1）：
    - 规则写（fork/发布/新建）**之前**先落 ``rsi_status=settling`` +
      ``payload.settle.state=settling``（write-ahead 标记，含 started_at/action/
      before_rule_version/before_version_ids…）；状态机：
      ``pending → settling → candidate_pending/draft_generated/published``。
    - 崩溃重启后以相同 feedback/action 重试 → 识别 settling 标记走恢复路径：
      规则版本集合/审计比对确认规则侧已写到哪一步，候选已写则复用，缺什么补什么，
      **不重复写规则、不重复发布**；规则侧确认未写入则回退 pending 复用首次路径。
    - ``RULEPROOF_FEEDBACK_WAL=0`` 回旧行为（无标记、无恢复，崩溃后重试从头跑）。
    """
    denied = settle_permission(user)
    if denied:
        _audit_denied(feedback_id, user, denied)
        return denied
    row = R.feedback.get(feedback_id)
    if not row:
        return {"error": "反馈不存在"}
    from . import rsi_protocol as _proto
    if _proto.frozen():
        # T-116：状态变更（frozen）与 feedback.frozen 审计同一事务；审计失败整体回滚。
        _settle_write(feedback_id, status="frozen", action=action, user=user,
                      audit_action="feedback.frozen")
        return {"ok": True, "status": "frozen",
                "message": "改进器已冻结（消融对照中），本次沉淀未生效"}
    from . import rule
    _strict = strict_settle_enabled()
    _prev = _settle_record(row)
    _prev_status = str(row.get("rsi_status") or "")
    # ---- 2026-11-23 LaneM（B1）：处置开始标记（write-ahead）→ 崩溃恢复入口 ----
    if wal_enabled() and (_prev_status == SETTLING_STATUS
                          or str(_prev.get("state") or "") == SETTLING_STATUS):
        if str(_prev.get("action") or "") != str(action):
            return {"ok": False, "status": SETTLING_STATUS, "state": SETTLING_STATUS,
                    "retryable": True,
                    "error": (f"该反馈存在未完成的处置（action={_prev.get('action')}），"
                              f"请以相同 action 重试以走崩溃恢复，避免重复规则变更"),
                    "feedback_id": feedback_id, "action": action,
                    "candidate_id": "", "settled": False, "resumed": False}
        return _recover_settle(feedback_id, row, action, note, user, auto_publish,
                               _prev, _recovery_depth)
    # ---- 2026-11-22 A 类：重试 / 幂等回放（严格模式；frozen 分支优先保持原语义）----
    if _strict:
        if _prev_status == SETTLE_PENDING_STATUS and _prev.get("pending"):
            if str(_prev.get("action") or action) != str(action):
                return {"ok": False, "status": SETTLE_PENDING_STATUS,
                        "state": SETTLE_PENDING_STATUS, "retryable": True,
                        "error": (f"该反馈存在待重试候选（action={_prev.get('action')}），"
                                  f"请以相同 action 重试，避免重复规则变更"),
                        "feedback_id": feedback_id, "action": action,
                        "candidate_id": "", "settled": False}
            return _retry_candidate_only(feedback_id, row, action, user, _prev)
        if (_prev and not _prev.get("pending") and _prev_status in ("settled", "draft")
                and str(_prev.get("action") or "") == str(action)):
            # 幂等回放：同一反馈同一动作已处置且已落库语义 → 直接返回，不重复草稿/发布
            return {"ok": True, "status": str(_prev.get("applied_status") or _prev_status),
                    "message": str(_prev.get("message") or ""),
                    "rule_id": str(_prev.get("rule_id") or ""),
                    "candidate_id": str(_prev.get("candidate_id") or ""),
                    "settled": True,
                    "draft_generated": bool(_prev.get("draft_generated")),
                    "published": bool(_prev.get("published")),
                    "behavior_changed": bool(_prev.get("behavior_changed")),
                    "draft_version": _prev.get("draft_version") or "",
                    "effective_version": _prev.get("effective_version") or "",
                    "idempotent_replay": True,
                    "attempts": int(_prev.get("attempts") or 1)}
    rule_id = ""
    _rc0 = (row.get("rule_code") or "").strip()
    # B3（2026-11-23 LaneY）：门禁快照 = 运行参数快照 + 规则版本内容快照。
    # 规则版本型 revise 的 before 因此包含「被 revise 的旧版本内容」（v0.1 等），
    # gate_publish 不再因快照缺内容把已发布动作误判 blocked（改记 uncertain）。
    _before = _proto.gate_snapshot(_rc0) if _rc0 else {"params": {}, "behavior": {}}
    _sem = {"settled": True, "draft_generated": False, "published": False,
            "behavior_changed": False, "draft_version": "", "effective_version": ""}
    # 2026-11-23 LaneR（B2）：new_rule 草稿的「可发布性回执」（只用于 new_rule 分支）。
    _nr_publish_meta: dict = {}
    # 2026-11-23 LaneM（B1）：规则写之前的「处置开始」write-ahead 标记。
    # 只对会先写规则侧的处置（revise 关联规则 / new_rule）落标记；ignore 类无规则写、
    # 状态与抑制同事务，不需要。标记写失败按旧行为继续（不阻断业务，留告警）。
    _wal = {}
    if wal_enabled() and _wal_needed(action, row):
        try:
            _wal = _wal_begin(feedback_id, row, action, user, auto_publish, _before)
        except Exception:  # noqa: BLE001 - 标记失败不阻断沉淀，降级旧行为并留结构化日志
            logging.getLogger(__name__).warning(
                "feedback settle WAL write failed feedback=%s action=%s; degrade to legacy path",
                feedback_id, action, exc_info=True)
            _wal = {}
    if action in ("ignore", "reject", "false_positive"):
        # T-116：原有「抑制写（独立连接 commit）成功/失败都继续 → 反馈状态再独立提交」，
        # 会留下“已 ignored 但抑制未生效”或“抑制已写但状态回滚”的半写。现在抑制行 +
        # point.suppressed 审计 + 反馈状态 + feedback.<action> 审计在同一事务；
        # 任一失败整体回滚（抑制写不再被 try/except 吞掉后假成功）。
        pid = (row.get("point_id") or "").strip()
        rc = (row.get("rule_code") or "").strip()
        _suppression = None
        _extra_audits = []
        if pid or rc:
            _suppression = (db.new_id("sup"), pid or rc, row.get("doc_type") or "",
                            note or "客户判误报", db.now())
            _extra_audits.append(("point.suppressed", pid or rc, ""))
        _msg = "已抑制该点位在该类型下的报告"
        _settle_write(feedback_id, status="ignored", action=action, user=user,
                      suppression=_suppression, extra_audits=_extra_audits,
                      extra_updates=_evo_task_sync(row.get("finding_id") or "", "ignored",
                                                   action, rule_id, note or "已忽略", user),
                      payload_patch=_persisted_settle_payload(
                          action, "ignored", _msg, rule_id, _sem))
        return {"ok": True, "status": "suppressed", "message": _msg,
                "candidate_id": "", "settled": True, "draft_generated": False,
                "published": False, "behavior_changed": False,
                "draft_version": "", "effective_version": ""}
    if action == "new_rule":
        # 2026-11-23 LaneR（A 类 B2）：人工漏报 → 新规则的结构化沉淀。
        # 旧实现只写 criterion/point_id → R3 规则缺 required_evidence/applicable_types，
        # 发布被 ir_needs_structure 拒绝（400），人工漏报无法闭环。现在：
        # ① 从 finding 的标题/描述/原文摘录/位置/文档类型/关联规则派生发布必需结构；
        # ② 结构确实不足 → 422 needs_structure + missing/suggestions（可操作清单），
        #    并在同一事务落反馈 blocked 状态 + audit（不静默 400、不建空壳规则）。
        _nr_payload = _nr_payload_of(row)
        _finding: dict = {}
        if row.get("finding_id"):
            try:
                _finding = R.findings.get(row["finding_id"]) or {}
            except Exception:  # noqa: BLE001 - 回查失败不阻断沉淀，但必须留痕（铁律 2）
                logging.getLogger(__name__).warning(
                    "反馈回查发现失败（new_rule 结构生成降级）feedback=%s finding=%s",
                    row.get("id"), row.get("finding_id"), exc_info=True)
                _finding = {}
        _structure = _new_rule_structure(row, _finding, _nr_payload)
        _criterion = str(_structure.get("criterion") or "").strip()
        _missing = list(_structure.get("blocking_missing") or [])
        _deferred = list(_structure.get("deferred_missing") or [])
        if _missing:
            _msg = ("人工漏报缺少可发布的规则结构（缺：" + "、".join(_missing + _deferred) + "），"
                    "已给出补齐项；补结构后重试即可生成可发布草稿")
            _nr_state = {"state": "needs_structure",
                         "missing": list(_missing + _deferred),
                         "blocking_missing": _missing,
                         "deferred_missing": _deferred,
                         "suggestions": list(_structure.get("suggestions") or []),
                         "sources": _structure.get("sources") or {},
                         "http_status": 422, "retryable": True}
            _settle_write(
                feedback_id, status="blocked", action=action, user=user,
                after=("人工漏报结构不足，待补：" + "、".join(_missing))[:300],
                audit_action="feedback.needs_structure",
                extra_updates=_evo_task_sync(row.get("finding_id") or "", "blocked", action,
                                             "", _msg, user),
                payload_patch={**_persisted_settle_payload(
                    action, "needs_structure", _msg, "",
                    {**_sem, "settled": False}), **_nr_state})
            return {"ok": False, "status": "needs_structure", **_nr_state,
                    "feedback_id": feedback_id, "action": action, "rule_id": "",
                    "candidate_id": "", "settled": False, "draft_generated": False,
                    "published": False, "behavior_changed": False,
                    "message": _msg}
        # 自进化门禁：沉淀物必须可执行，否则阻断（沿用本体/校准的校验→门禁方法）
        from . import rsi_protocol as _rsg
        _v = _rsg.validate_candidate(row.get("rule_code") or "",
                                     {"slots": {"criterion": _criterion,
                                                "point_id": _structure["slots"].get("point_id") or ""}})
        if not _v.get("ok"):
            _errors = _v.get("errors") or []
            # T-116：阻断状态 + feedback.blocked 审计同一事务（原实现状态独立写、且无审计）。
            _settle_write(feedback_id, status="blocked", action=action, user=user,
                          after="沉淀物不可执行，已阻断：" + ";".join(_errors)[:300],
                          audit_action="feedback.blocked",
                          extra_updates=_evo_task_sync(row.get("finding_id") or "", "blocked",
                                                       action, "", "沉淀物不可执行，已阻断", user))
            return {"ok": False, "blocked": True, "reason": "沉淀物不可执行，已阻断",
                    "state": "blocked", "missing": ["判据"], "errors": _errors,
                    "warnings": _v.get("warnings") or [],
                    "suggestions": list(_structure.get("suggestions") or [])}
        _new_rule_code = (str(_wal.get("new_rule_code") or "").strip()
                          or f"SED-{db.new_id('x')[:6].upper()}")
        try:
            r = rule.create_rule(code=_new_rule_code,
                                 name=(row.get("title")
                                       or str(_finding.get("title") or "")
                                       or "反馈沉淀规则"),
                                 category=NEW_RULE_CATEGORY, rclass=NEW_RULE_RCLASS,
                                 slots=_structure["slots"], source="sedimented",
                                 scope=_structure.get("scope") or None)
        except ValueError as _ce:
            # 结构在创建期的服务端二次校验被拒（如范围通配/类别非法）：按可补全结构返回 422，
            # 不把可操作的结构问题伪装成创建失败 400。
            _msg = f"人工漏报沉淀草稿被服务端校验拒绝：{_ce}"
            _settle_write(feedback_id, status="blocked", action=action, user=user,
                          after=_msg[:300], audit_action="feedback.needs_structure",
                          extra_updates=_evo_task_sync(row.get("finding_id") or "",
                                                       "blocked", action, "", _msg, user),
                          payload_patch={**_persisted_settle_payload(
                              action, "needs_structure", _msg, "",
                    {**_sem, "settled": False}),
                              "state": "needs_structure", "http_status": 422,
                              "missing": ["适用范围"], "retryable": True,
                              "suggestions": list(_structure.get("suggestions") or []),
                              "error_detail": f"{type(_ce).__name__}: {_ce}"})
            return {"ok": False, "status": "needs_structure", "state": "needs_structure",
                    "http_status": 422, "retryable": True, "missing": ["适用范围"],
                    "suggestions": list(_structure.get("suggestions") or []),
                    "feedback_id": feedback_id, "action": action, "rule_id": "",
                    "candidate_id": "", "settled": False,
                    "message": _msg}
        rule_id = r["rule_id"]; status, msg = "settled", "已生成新规则草稿"
        # 只生成未发布草稿：不算「已发布」，也不算「执行行为已改变」
        _sem.update(draft_generated=True)
        # 发布可操作性回执：草稿带齐结构（证据/范围）→ 明确告知可直接发布；仍缺则给补齐项
        _gaps = _nr_publish_gaps(_structure["slots"], _structure.get("scope") or {},
                                 str(r.get("name") or ""))
        _nr_publish_meta = {
            "publish_ready": bool(_gaps.get("ok")),
            "publish_missing": list(_gaps.get("missing") or []),
            "publish_suggestions": list(_gaps.get("suggestions") or [])[:8],
            "publish_state": ("ready" if _gaps.get("ok") else "needs_structure"),
        }
        if _gaps.get("ok"):
            msg += "；已带齐判据/证据要求/适用范围，可在草稿箱直接发布"
        else:
            msg += ("；仍缺发布结构（" + "、".join(_gaps.get("missing") or []) +
                    "），请补齐后发布")
    elif action == "revise":
        rid = ""
        _rc0_rule = (row.get("rule_code") or "").strip()
        for r in R.rules.list():
            if (r.get("code") or "") == _rc0_rule:
                rid = r["id"]; break
        if rid:
            # B1/B2/B3 修复（T-177）：沉淀 = 规则「修订中」的编辑动作，按 AGENTS §3 走
            # rule.update_slots()：published → _fork_draft 克隆新草稿版本、rule.status=draft、
            # 旧 published 版本继续生效（effective_version/current_version_id 不变）；
            # 同时把误报引文写进新草稿版本的 slots.false_positive_quotes（负例卡，B2）。
            # 不再直插 rule_version（旧实现：逐字复制 slots、不写负例、不动 rule.status，
            # 导致草稿箱不可见 + rule.publish() 返回 invalid_transition）。
            _quote = ""
            try:
                from . import evolution as _evo
                _quote = (_evo._finding_quote(row.get("finding_id") or "") or "").strip()
            except Exception:
                logging.getLogger(__name__).warning("finding quote lookup skipped", exc_info=True)
            _rstatus = str((R.rules.get(rid) or {}).get("status") or "draft")
            _base_ver = (R.rules.published_version(rid) if _rstatus == "published"
                         else R.rules.latest_version(rid)) or {}
            try:
                _base_slots = json.loads(_base_ver.get("slots_json") or "{}")
            except Exception:
                _base_slots = {}
            if not isinstance(_base_slots, dict):
                _base_slots = {}
            _base_marks = [str(x) for x in (_base_slots.get("false_positive_quotes") or [])
                           if str(x).strip()]
            _marks = list(_base_marks)
            if _quote and _quote not in _marks:
                _marks.append(_quote)
            _patch = {"false_positive_quotes": _marks[-50:]} if _marks else {}
            _quote_added = bool(_quote and _quote not in _base_marks)
            _upd = rule.update_slots(rid, _patch, actor=user or "system")
            if _upd.get("error"):
                # pending（旧审批遗留）/archived：不可编辑，如实返回，不改任何状态。
                return {"ok": False, "status": "blocked", "rule_id": rid,
                        "error": _upd.get("error"),
                        "message": _upd.get("message") or "规则当前状态不可修订（待审批请先回滚）"}
            rule_id = rid
            _forked = bool(_upd.get("forked"))
            _dv = _upd.get("draft_version") or ""
            _eff = _upd.get("effective_version") or ""
            _sem.update(draft_generated=_forked, draft_version=_dv, effective_version=_eff)
            _note = ("含负例卡（误报引文）" if _quote else "无新增引文（仅生成修订草稿）")
            if auto_publish:
                _pub = rule.publish(rid, actor=user or "system")
                if _pub.get("error"):
                    status = "draft"
                    msg = (f"已生成 {_rc0_rule} 修订草稿 {_dv}（规则进入修订中，旧生效版本 "
                           f"{_eff or '无'} 继续执行）；自动发布失败：{_pub.get('message') or _pub.get('error')}")
                else:
                    status = "settled"
                    _eff_new = _pub.get("effective_version") or ""
                    msg = (f"已沉淀并发布 {_rc0_rule} {_eff_new}"
                           f"（{_note}）；下一轮审核生效")
                    # 发布改变执行行为 = 新版本带负例卡（抑制误报）或确有副本差异
                    _sem.update(published=True, draft_generated=False,
                                effective_version=_eff_new or _eff,
                                behavior_changed=bool(_quote_added or _forked))
            else:
                status = "settled"
                msg = (f"已生成 {_rc0_rule} 新版本草稿 {_dv}（{_note}）；规则进入修订中，"
                       f"旧生效版本 {_eff or '无'} 继续执行，到草稿箱点「发布生效」后参与审核")
        else:
            # 内置规则：阈值参数真的写入参数表，下一次审核立即生效
            from . import ruleparam as _rp
            rc = (row.get("rule_code") or "").strip()
            if not rc:
                status, msg = "settled", "该反馈未关联规则，未做规则修订"
                # 已结案但既无草稿也无发布、更没改变行为：三面旗全 False（不假装改了）
            elif rc in _rp.DEFAULTS:
                cur = _rp.get(rc) or _rp.DEFAULTS[rc]
                _orig = cur.get("value")
                newv = _orig
                try:
                    newv = float(_orig) * 1.0
                except (TypeError, ValueError):
                    newv = None
                # 2026-11-22 A 类：×1.0 占位修订 → 原值未变化时 behavior_changed=False
                _num_changed = False
                try:
                    _num_changed = (_orig is not None and newv is not None
                                    and float(_orig) != float(newv))
                except (TypeError, ValueError):
                    _num_changed = (_orig is not None and newv is not None
                                    and str(_orig) != str(newv))
                changed = {"value": newv} if newv is not None else {}
                if changed or cur.get("op") == "range":
                    _rp.update(rc, **changed)
                    if auto_publish:
                        _pub_p = _rp.publish(rc, user or "system") or {}
                        _pub_ok = bool(_pub_p.get("published")) and not _pub_p.get("error")
                        status = "settled"
                        _sem.update(published=_pub_ok, behavior_changed=_pub_ok and _num_changed)
                        if _pub_ok:
                            msg = (f"已更新并发布内置规则参数 {rc}（下一轮审核生效）")
                            if not _num_changed:
                                msg += ("；但数值原值未变化（×1.0 占位修订），"
                                        "执行行为未改变（behavior_changed=false）")
                        else:
                            msg = (f"已写入 {rc} 参数，但发布未成功（{_pub_p.get('error') or '未发布'}）；"
                                   "不声称已生效")
                    else:
                        status = "draft"
                        _sem.update(draft_generated=True)
                        msg = f"已保存参数草稿 {rc}（未发布，不生效）"
                        if not _num_changed:
                            msg += "；数值原值未变化（×1.0），发布后行为也不会改变"
                else:
                    status, msg = "settled", "已记录修订建议"
            elif rc:
                # 非数值型内置规则：写行为参数（严重度降级 / 忽略关键词），执行立即生效
                title = (row.get("title") or "").strip()
                kw = title[:12] if title else ""
                beh = {"severity": "suspected"}
                if kw:
                    beh["ignore_keywords"] = [kw]
                _rp.set_behavior(rc, **beh)
                if auto_publish:
                    _pub_p = _rp.publish(rc, user or "system") or {}
                    _pub_ok = bool(_pub_p.get("published")) and not _pub_p.get("error")
                    status = "settled"
                    _sem.update(published=_pub_ok, behavior_changed=_pub_ok)
                    msg = (f"已调整并发布规则 {rc} 行为（降级为疑似 + 忽略关键词「{kw}」），下一轮生效"
                           if _pub_ok else
                           f"已写入规则 {rc} 行为草稿，但发布未成功（{_pub_p.get('error') or '未发布'}）；不声称已生效")
                else:
                    status = "draft"
                    _sem.update(draft_generated=True)
                    msg = f"已保存规则 {rc} 行为草稿（未发布，不生效）"
    else:
        status, msg = "ignored", "已忽略"
    # B3（LaneY）：after 快照含规则版本内容（新版本 latest / 旧生效版本 effective），
    # 与候选记录一起构成「候选 → 发布 → 有效版本」同一记录可追。
    _after = _proto.gate_snapshot(_rc0) if _rc0 else {"params": {}, "behavior": {}}
    # ---- 2026-11-22 A 类：候选落痕（严格模式下失败不得静默）----
    cand = ""
    if _strict:
        _existing = _candidate_ids_for(feedback_id)
        if _existing:
            cand = _existing[0]     # 重试幂等：已有候选则复用，不重复插入
    if not cand:
        try:
            cand = _proto.record_candidate(feedback_id, _rc0, action, _before, _after,
                                           note=msg, by=user or "system")
        except Exception as _ce:  # noqa: BLE001 - 严格模式：转可恢复状态，绝不假成功
            _err = f"{type(_ce).__name__}: {_ce}"
            if _strict:
                logging.getLogger(__name__).error(
                    "feedback candidate write failed feedback=%s action=%s: %s",
                    feedback_id, action, _err, exc_info=True)
                # 若异常发生在插入之后（部分写入），仍复用已落库候选，避免孤儿反馈
                _existing = _candidate_ids_for(feedback_id)
                if not _existing:
                    _patch = _persisted_settle_payload(
                        action, status, msg, rule_id, _sem, before=_before, after=_after,
                        pending=True, error=_err)
                    _settle_write(feedback_id, status=SETTLE_PENDING_STATUS, action=action,
                                  user=user, rule_id=rule_id,
                                  after=(msg + "；候选追溯记录写入失败，待重试"),
                                  audit_action="feedback.candidate_pending",
                                  extra_updates=_evo_task_sync(
                                      row.get("finding_id") or "", SETTLE_PENDING_STATUS,
                                      action, rule_id, "候选追溯记录写入失败，待重试", user),
                                  payload_patch=_patch)
                    return _candidate_pending_result(
                        feedback_id, action, status, msg, rule_id, _sem, _err)
                cand = _existing[0]
            else:
                # =0 回旧行为（兼容回退）：吞异常、照常 settled、candidate_id=""
                logging.getLogger(__name__).warning(
                    "feedback candidate write failed (strict=0 legacy) feedback=%s: %s",
                    feedback_id, _err)
                cand = ""
    # T-116：主成功路径（settled/draft/ignored）——反馈状态 + feedback.<action> 审计
    # 同一事务；审计写失败 → 状态回滚并向上抛。规则库/RSI 写仍为独立事务，见
    # `_settle_write` 上方注释与 docs/qa/审计同事务补全_20261118.md「仍多事务清单」。
    _final_sem = {**_sem, "settled": True}
    _settle_write(feedback_id, status=status, action=action, user=user, rule_id=rule_id,
                  after=msg, audit_action=f"feedback.{action}",
                  extra_updates=_evo_task_sync(row.get("finding_id") or "", status, action,
                                               rule_id, msg, user),
                  payload_patch={**_persisted_settle_payload(
                      action, status, msg, rule_id, _final_sem, before=_before, after=_after,
                      candidate_id=cand, candidate_note=msg), **_nr_publish_meta})
    return {"ok": True, "status": status, "message": msg, "rule_id": rule_id,
            "candidate_id": cand,
            # settled 语义拆分（只增字段；旧 status 含义不变）
            "settled": True,
            "draft_generated": bool(_sem.get("draft_generated")),
            "published": bool(_sem.get("published")),
            "behavior_changed": bool(_sem.get("behavior_changed")),
            "draft_version": _sem.get("draft_version") or "",
            "effective_version": _sem.get("effective_version") or "",
            # new_rule 草稿可发布性回执（只增字段；非 new_rule 为空 dict 不出现）
            **({"state": "draft_needs_structure"} if _nr_publish_meta
               and not _nr_publish_meta.get("publish_ready") else {}),
            **_nr_publish_meta,
            "strict_settle": _strict}


# ===========================================================================
# L98 P1（2026-11-24）：反馈/观察的抽样偏差口径（只读统计，不写库）
# ===========================================================================
# 问题（L47/L90 外审 P1）：
#   平台现有的“规则准确率/override 率”都从 feedback/decision 算，而这些记录只存在于
#   **已被告警的 finding** 上。用“已告警样本”当总体会系统性高估准确率、完全看不到
#   漏报（未告警文档没有被抽样的入口）。影子观察（shadow_item）同样只对候选落条，
#   若把 shadow_item 当分母，覆盖率也会偏向已告警文档。
#
# 本口径固定三件事：
#   1. 总体 = run×object（每轮审核的每份被审文档，来自 audit_manifest.objects_json，
#      回退 case_document/finding.object_id）；**包含未告警文档**；
#   2. 已告警 = 该 run×object 至少 1 条 finding；未告警 = 0 条 finding；
#   3. 审查证据 = decision / finding.status / feedback / qa_sample / shadow_item 的
#      人工裁决，以及 manifest_result.review_status（清单复核，可用于未告警文档）。
#   未告警文档审查数不足时，`false_negative_rate`/`overall_accuracy` 一律返回 None +
#   reason，禁止用“已告警样本”冒充总体。
SAMPLING_METRIC_VERSION = "l98-sampling-bias-1"


def _sb_cols(conn, table: str) -> set:
    try:
        return {r[1] for r in conn.execute("PRAGMA table_info(%s)" % table).fetchall()}
    except Exception:
        return set()


def _sb_tables(conn) -> set:
    try:
        return {str(r[0]) for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    except Exception:
        return set()


def _sb_scope(tenant_id=None, workspace_id=None) -> tuple:
    """作用域：显式参数优先，否则取 ctx；空 = 不过滤（平台级只读统计）。"""
    t, w = str(tenant_id or ""), str(workspace_id or "")
    if not t or not w:
        try:
            from . import ctx as _ctx
            cur = _ctx.get_context() or {}
            t = t or str(cur.get("tenant_id") or "")
            w = w or str(cur.get("workspace_id") or "")
        except Exception:
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    return t, w


def _sb_ratio(num: int, den: int):
    return round(float(num) / float(den), 6) if den else None


def _sb_chunks(items, size=500):
    items = list(items)
    for i in range(0, len(items), size):
        yield items[i:i + size]


def sampling_bias_stats(tenant_id: str = "", workspace_id: str = "",
                        run_limit: int = 2000) -> dict:
    """抽样偏差口径：暴露/已审查/覆盖率 + 未告警文档抽样率 + 影子观察分母。

    只读、幂等；表/列不存在或空库返回零值与 explicit reason，不抛异常、不编数字。
    返回键（报告模板直接引用）：
      exposure / reviewed / coverage / sampling_rate
      population{units,runs,docs,includes_unalerted,source}
      alerted{units,reviewed,review_coverage}
      unalerted{units,reviewed,sampling_rate,review_sources}
      feedback_conditional{...}   # 仅已告警样本的条件指标（禁止当总体）
      shadow{items, denominator, denominator_includes_unalerted, observed_rate, ...}
      bias_guard{...} / caveats[]
    """
    t_scope, w_scope = _sb_scope(tenant_id, workspace_id)
    out = {
        "ok": True, "metric": "feedback_sampling_bias",
        "metric_version": SAMPLING_METRIC_VERSION,
        "scope": {"tenant_id": t_scope, "workspace_id": w_scope,
                  "filtered": bool(t_scope or w_scope)},
        "population": {"units": 0, "runs": 0, "docs": 0,
                       "unit": "run×object(document)",
                       "includes_unalerted": True,
                       "source": "audit_manifest.objects_json",
                       "fallbacks": []},
        "exposure": 0, "reviewed": 0, "coverage": None, "sampling_rate": None,
        "alerted": {"units": 0, "reviewed": 0, "review_coverage": None},
        "unalerted": {"units": 0, "reviewed": 0, "sampling_rate": None,
                      "review_sources": {}},
        "feedback_conditional": {"basis": "alerted_reviewed_findings",
                                 "is_population_level": False,
                                 "confirmed": 0, "false_positive": 0,
                                 "samples": 0, "override_rate": None},
        "shadow": {"items": 0, "items_with_platform_finding": 0,
                   "items_without_platform_finding": 0,
                   "denominator": 0, "denominator_basis": "exposed_units",
                   "denominator_includes_unalerted": True,
                   "observed_rate": None,
                   "legacy_alerted_only": {"denominator": 0,
                                           "must_not_use_as_population": True}},
        "bias_guard": {"alerted_samples_used_as_population": False,
                       "unalerted_sampling_available": False,
                       "false_negative_rate": None,
                       "overall_accuracy": None,
                       "false_negative_rate_reason": "",
                       "overall_accuracy_reason": ""},
        "caveats": [],
    }
    try:
        with db.session() as c:
            tables = _sb_tables(c)
            if "audit_run" not in tables:
                out["caveats"].append("audit_run 表不存在：无审核暴露数据")
                out["bias_guard"]["false_negative_rate_reason"] = "no_audit_run_table"
                out["bias_guard"]["overall_accuracy_reason"] = "no_audit_run_table"
                return out
            run_cols = _sb_cols(c, "audit_run")
            case_cols = _sb_cols(c, "audit_case")
            finding_cols = _sb_cols(c, "finding")
            has_manifest = "audit_manifest" in tables
            has_mr = "manifest_result" in tables
            has_finding = bool(finding_cols)
            f_has_obj = "object_id" in finding_cols
            f_has_mr = "manifest_result_id" in finding_cols
            has_case_scope = bool(case_cols & {"tenant_id", "workspace_id"})

            # ---- 1) 暴露总体：run × object ----
            where, params = [], []
            case_join = ""
            if has_case_scope:
                case_join = " LEFT JOIN audit_case c ON c.id=r.case_id"
                if t_scope and "tenant_id" in case_cols:
                    where.append("COALESCE(c.tenant_id,'')=?")
                    params.append(t_scope)
                if w_scope and "workspace_id" in case_cols:
                    where.append("COALESCE(c.workspace_id,'')=?")
                    params.append(w_scope)
            mid_col = "COALESCE(r.manifest_id,'')" if "manifest_id" in run_cols else "''"
            sql = ("SELECT r.id AS run_id, COALESCE(r.case_id,'') AS case_id, "
                   + mid_col + " AS manifest_id FROM audit_run r" + case_join
                   + (" WHERE " + " AND ".join(where) if where else "")
                   + " ORDER BY r.created_at DESC, r.rowid DESC LIMIT ?")
            params.append(int(max(1, min(int(run_limit or 2000), 20000))))
            run_rows = [dict(r) for r in c.execute(sql, tuple(params)).fetchall()]
            out["population"]["runs"] = len(run_rows)
            if not run_rows:
                out["caveats"].append("作用域内没有审核 run：exposure/coverage 置 0，不伪造")
                out["bias_guard"]["false_negative_rate_reason"] = "no_exposed_runs"
                out["bias_guard"]["overall_accuracy_reason"] = "no_exposed_runs"
                return out

            # ---- 2) manifest objects（文档级暴露清单）----
            mids = sorted({str(r.get("manifest_id") or "") for r in run_rows
                           if str(r.get("manifest_id") or "")})
            manifest_objs = {}
            if has_manifest and mids:
                for chunk in _sb_chunks(mids):
                    q = ("SELECT id, objects_json FROM audit_manifest WHERE id IN (%s)"
                         % ",".join("?" * len(chunk)))
                    for mr in c.execute(q, tuple(chunk)).fetchall():
                        try:
                            objs = json.loads(mr["objects_json"] or "[]")
                        except Exception:
                            objs = []
                        ids = []
                        for o in objs or []:
                            oid = str((o or {}).get("object_id") or "") if isinstance(o, dict) else ""
                            if oid:
                                ids.append(oid)
                        manifest_objs[str(mr["id"])] = ids

            # ---- 3) findings → 已告警 run×object ----
            run_ids = [str(r["run_id"]) for r in run_rows]
            findings_by_run = {}
            finding_unit = {}      # finding_id -> (run_id, object_id)
            if has_finding and run_ids:
                fcols = ["id", "run_id"]
                fcols.append("COALESCE(object_id,'')" if f_has_obj else "''")
                fcols.append("COALESCE(manifest_result_id,'')" if f_has_mr else "''")
                fcols.append("COALESCE(status,'')" if "status" in finding_cols else "''")
                fcols.append("COALESCE(rule_id,'')" if "rule_id" in finding_cols else "''")
                for chunk in _sb_chunks(run_ids):
                    q = ("SELECT %s FROM finding WHERE run_id IN (%s)"
                         % (", ".join(fcols), ",".join("?" * len(chunk))))
                    for r in c.execute(q, tuple(chunk)).fetchall():
                        findings_by_run.setdefault(str(r[1] or ""), []).append(
                            {"id": str(r[0] or ""), "object_id": str(r[2] or ""),
                             "manifest_result_id": str(r[3] or ""),
                             "status": str(r[4] or ""), "rule_id": str(r[5] or "")})
            # finding.object_id 为空的旧数据：用 manifest_result.object_id 回填
            mr_obj = {}
            if has_mr and f_has_mr:
                mr_ids = sorted({f["manifest_result_id"] for rows in findings_by_run.values()
                                 for f in rows if f["manifest_result_id"]})
                for chunk in _sb_chunks(mr_ids):
                    q = ("SELECT id, COALESCE(object_id,'') FROM manifest_result WHERE id IN (%s)"
                         % ",".join("?" * len(chunk)))
                    for r in c.execute(q, tuple(chunk)).fetchall():
                        mr_obj[str(r[0] or "")] = str(r[1] or "")
            finding_by_unit = {}   # (run, obj) -> set(finding_id)
            for rid, rows in findings_by_run.items():
                for f in rows:
                    oid = f["object_id"] or mr_obj.get(f["manifest_result_id"], "")
                    finding_unit[f["id"]] = (rid, oid)
                    finding_by_unit.setdefault((rid, oid), set()).add(f["id"])

            # ---- 4) 文档级暴露集合 ----
            case_docs = {}
            need_case = sorted({str(r.get("case_id") or "") for r in run_rows
                                if not manifest_objs.get(str(r.get("manifest_id") or ""))})
            if need_case and "case_document" in tables:
                out["population"]["fallbacks"].append("case_document")
                for chunk in _sb_chunks(need_case):
                    q = ("SELECT case_id, document_id FROM case_document WHERE case_id IN (%s)"
                         % ",".join("?" * len(chunk)))
                    for r in c.execute(q, tuple(chunk)).fetchall():
                        case_docs.setdefault(str(r["case_id"] or ""), []).append(
                            str(r["document_id"] or ""))
            exposed_units = set()
            docs = set()
            for r in run_rows:
                rid = str(r["run_id"])
                objs = manifest_objs.get(str(r.get("manifest_id") or "")) or []
                if not objs:
                    objs = list(dict.fromkeys(
                        case_docs.get(str(r.get("case_id") or ""), [])
                        + [oid for (frid, oid), _ in finding_by_unit.items()
                           if frid == rid and oid]))
                if not objs:
                    objs = ["__run__:" + rid]
                    if "run_level_unknown_objects" not in out["population"]["fallbacks"]:
                        out["population"]["fallbacks"].append("run_level_unknown_objects")
                for oid in objs:
                    key = (rid, str(oid))
                    exposed_units.add(key)
                    if not str(oid).startswith("__run__:"):
                        docs.add(str(oid))
            out["population"]["units"] = len(exposed_units)
            out["population"]["docs"] = len(docs)
            out["exposure"] = len(exposed_units)

            # ---- 4b) finding → 文档归因（旧数据 finding.object_id 可能为空）----
            # 归因链：finding.object_id → manifest_result.object_id → 该 run 只有 1 份
            # 文档 → 同 manifest 同 rule 唯一 manifest_result；都不行 = 不可归因（单列，
            # 不硬塞给某份文档，避免把“已告警样本”错记到未告警文档）。
            run_objs = {}
            for rid, oid in exposed_units:
                if not str(oid).startswith("__run__"):
                    run_objs.setdefault(rid, set()).add(oid)
            run_manifest = {str(r["run_id"]): str(r.get("manifest_id") or "")
                            for r in run_rows}
            mr_by_rule = {}
            if has_mr and mids:
                try:
                    mr_cols2 = _sb_cols(c, "manifest_result")
                    if "rule_code" in mr_cols2 and "object_id" in mr_cols2:
                        for chunk in _sb_chunks(sorted({m for m in mids if m})):
                            q = ("SELECT manifest_id, rule_code, object_id, "
                                 "review_status FROM manifest_result WHERE manifest_id IN (%s)"
                                 % ",".join("?" * len(chunk)))
                            for r in c.execute(q, tuple(chunk)).fetchall():
                                mr_by_rule.setdefault(
                                    (str(r["manifest_id"] or ""), str(r["rule_code"] or "")),
                                    []).append({"object_id": str(r["object_id"] or ""),
                                                "review_status": str(r["review_status"] or "pending")})
                except Exception:
                    mr_by_rule = {}
            attr = {"findings_total": 0, "mapped": 0, "via_object_id": 0,
                    "via_manifest_result": 0, "via_single_object_run": 0,
                    "via_rule_unique_result": 0, "unattributed": 0}
            finding_by_unit = {}
            for rid, rows in findings_by_run.items():
                rid_objs = run_objs.get(rid) or set()
                for f in rows:
                    attr["findings_total"] += 1
                    oid = f["object_id"]
                    src = "via_object_id" if oid else ""
                    if not oid:
                        oid = mr_obj.get(f["manifest_result_id"], "")
                        src = "via_manifest_result" if oid else ""
                    if oid and (rid, oid) not in exposed_units:
                        oid = ""
                        src = ""
                    if not oid and len(rid_objs) == 1:
                        oid = next(iter(rid_objs))
                        src = "via_single_object_run"
                    if not oid:
                        cands = [x["object_id"] for x in
                                 mr_by_rule.get((run_manifest.get(rid, ""),
                                                 f["rule_id"]), [])
                                 if x["object_id"] in rid_objs]
                        cands = list(dict.fromkeys(cands))
                        if len(cands) == 1:
                            oid = cands[0]
                            src = "via_rule_unique_result"
                    if oid and (rid, oid) in exposed_units:
                        attr["mapped"] += 1
                        attr[src] = attr.get(src, 0) + 1
                        finding_unit[f["id"]] = (rid, oid)
                        finding_by_unit.setdefault((rid, oid), set()).add(f["id"])
                    else:
                        attr["unattributed"] += 1
            out["attribution"] = attr

            # ---- 5) 人工审查证据（finding 级）----
            all_finding_ids = [f["id"] for rows in findings_by_run.values()
                               for f in rows if f["id"]]
            finding_reviewed = set()
            review_sources = {}
            if all_finding_ids:
                for chunk in _sb_chunks(all_finding_ids):
                    ph = ",".join("?" * len(chunk))
                    probes = (
                        ("decision", "SELECT DISTINCT finding_id FROM decision "
                                     "WHERE finding_id IN (%s)"),
                        ("feedback", "SELECT DISTINCT finding_id FROM feedback "
                                     "WHERE finding_id IN (%s) AND kind IN "
                                     "('confirm','false_positive')"),
                        ("qa_sample", "SELECT DISTINCT finding_id FROM qa_sample "
                                      "WHERE finding_id IN (%s)"),
                    )
                    for src, tpl in probes:
                        if src not in tables:
                            continue
                        try:
                            for r in c.execute(tpl % ph, tuple(chunk)).fetchall():
                                finding_reviewed.add(str(r[0] or ""))
                                review_sources[src] = review_sources.get(src, 0) + 1
                        except Exception:
                            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
                for rows in findings_by_run.values():
                    for f in rows:
                        if f["status"] in ("confirmed", "false_positive"):
                            finding_reviewed.add(f["id"])
                            review_sources["finding_status"] =                                 review_sources.get("finding_status", 0) + 1
            reviewed_alerted = set()
            reviewed_unattributed = 0
            for fid in finding_reviewed:
                unit = finding_unit.get(fid)
                if not unit:
                    reviewed_unattributed += 1
                    continue
                rid, oid = unit
                if (rid, oid) in exposed_units:
                    reviewed_alerted.add((rid, oid))
                elif (rid, "__run__:" + rid) in exposed_units:
                    reviewed_alerted.add((rid, "__run__:" + rid))
            out["attribution"]["reviewed_findings"] = len(finding_reviewed)
            out["attribution"]["reviewed_unattributed_findings"] = reviewed_unattributed
            # 影子池人工裁决也计为已告警样本审查（不改变 formal 结论，只统计）
            if "shadow_item" in tables:
                try:
                    q = ("SELECT run_id, COALESCE(object_id,''), "
                         "COALESCE(platform_finding_id,''), COALESCE(shadow_status,'') "
                         "FROM shadow_item")
                    for r in c.execute(q).fetchall():
                        rid, oid = str(r[0] or ""), str(r[1] or "")
                        sst = str(r[3] or "")
                        if sst in ("", "pending"):
                            continue
                        for key in ((rid, oid), (rid, "__run__:" + rid)):
                            if key in exposed_units:
                                reviewed_alerted.add(key)
                                review_sources["shadow"] =                                     review_sources.get("shadow", 0) + 1
                except Exception:
                    logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)

            # ---- 6) 未告警文档审查：manifest_result.review_status（清单复核）----
            reviewed_unalerted = set()
            if has_mr and "review_status" in _sb_cols(c, "manifest_result"):
                run_by_manifest = {}
                for run in run_rows:
                    mid = str(run.get("manifest_id") or "")
                    if mid:
                        run_by_manifest.setdefault(mid, []).append(str(run["run_id"]))
                for mid, rids in run_by_manifest.items():
                    try:
                        q = ("SELECT COALESCE(object_id,'') FROM manifest_result "
                             "WHERE manifest_id=? AND "
                             "COALESCE(review_status,'pending') NOT IN ('pending','')")
                        for r in c.execute(q, (mid,)).fetchall():
                            oid = str(r[0] or "")
                            for rid in rids:
                                key = (rid, oid)
                                if key in exposed_units and key not in finding_by_unit:
                                    reviewed_unalerted.add(key)
                    except Exception:
                        logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            if reviewed_unalerted:
                review_sources["manifest_result_review"] = len(reviewed_unalerted)
            # finding 级审查来源是全量口径（含已归因/未归因 finding），放到 attribution；
            # unalerted.review_sources 只统计真正落在“未告警文档”上的审查证据，避免误读。
            out["attribution"]["finding_review_sources"] = dict(sorted(review_sources.items()))
            unalerted_sources = {}
            if reviewed_unalerted:
                unalerted_sources["manifest_result_review"] = len(reviewed_unalerted)

            # ---- 7) 影子观察（分母=暴露总体，含未告警文档）----
            shadow_items = shadow_with_finding = shadow_without_finding = 0
            if "shadow_item" in tables:
                try:
                    s_cols = _sb_cols(c, "shadow_item")
                    wheres, sparams = [], []
                    run_set = {str(r["run_id"]) for r in run_rows}
                    if "run_id" in s_cols and run_set:
                        # 只统计作用域内的 run；空 run_id 的历史行按租户列过滤
                        wheres.append("(COALESCE(run_id,'')='' OR run_id IN (%s))"
                                      % ",".join("?" * len(run_set)))
                        sparams.extend(sorted(run_set))
                    if t_scope and "tenant_id" in s_cols:
                        wheres.append("COALESCE(tenant_id,'')=?")
                        sparams.append(t_scope)
                    if w_scope and "workspace_id" in s_cols:
                        wheres.append("COALESCE(workspace_id,'')=?")
                        sparams.append(w_scope)
                    q = ("SELECT COALESCE(platform_finding_id,'') FROM shadow_item"
                         + (" WHERE " + " AND ".join(wheres) if wheres else ""))
                    for r in c.execute(q, tuple(sparams)).fetchall():
                        shadow_items += 1
                        if str(r[0] or ""):
                            shadow_with_finding += 1
                        else:
                            shadow_without_finding += 1
                except Exception:
                    logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            out["shadow"].update({
                "items": shadow_items,
                "items_with_platform_finding": shadow_with_finding,
                "items_without_platform_finding": shadow_without_finding,
                "denominator": len(exposed_units),
                "denominator_includes_unalerted": True,
                "observed_rate": _sb_ratio(shadow_items, len(exposed_units)),
                "legacy_alerted_only": {
                    "denominator": len(finding_by_unit),
                    "must_not_use_as_population": True,
                    "note": "只把已告警/候选当分母会系统性忽略未告警文档，"
                            "禁止用于覆盖率/准确率",
                },
            })

            # ---- 8) 汇总 ----
            alerted_units = {k for k in exposed_units if k in finding_by_unit}
            unalerted_units = exposed_units - alerted_units
            reviewed_alerted &= exposed_units
            reviewed_units = set(reviewed_alerted) | set(reviewed_unalerted)
            out["alerted"] = {
                "units": len(alerted_units),
                "reviewed": len(reviewed_alerted & alerted_units),
                "review_coverage": _sb_ratio(len(reviewed_alerted & alerted_units),
                                             len(alerted_units)),
                "unattributed_findings": out["attribution"]["unattributed"],
            }
            out["unalerted"] = {
                "units": len(unalerted_units),
                "reviewed": len(reviewed_unalerted & unalerted_units),
                "sampling_rate": _sb_ratio(len(reviewed_unalerted & unalerted_units),
                                           len(unalerted_units)),
                "review_sources": unalerted_sources,
            }
            out["reviewed"] = len(reviewed_units)
            out["coverage"] = _sb_ratio(len(reviewed_units), len(exposed_units))
            out["sampling_rate"] = out["unalerted"]["sampling_rate"]

            # 条件于已告警样本的反馈指标：只做对照，不冒充总体
            conf = fp = 0
            case_scope_ids = {str(r.get("case_id") or "") for r in run_rows}
            if "feedback" in tables:
                try:
                    fw, fparams = [], []
                    if t_scope or w_scope:
                        if case_scope_ids:
                            fw.append("case_id IN (%s)" % ",".join(
                                "?" * len(case_scope_ids)))
                            fparams.extend(sorted(case_scope_ids))
                        else:
                            fw.append("0=1")
                    q = ("SELECT kind, count(*) AS n FROM feedback "
                         + (" WHERE " + " AND ".join(fw) if fw else "")
                         + " GROUP BY kind")
                    for r in c.execute(q, tuple(fparams)).fetchall():
                        if str(r[0] or "") == "confirm":
                            conf = int(r[1] or 0)
                        elif str(r[0] or "") == "false_positive":
                            fp = int(r[1] or 0)
                except Exception:
                    logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
            out["feedback_conditional"].update({
                "confirmed": conf, "false_positive": fp, "samples": conf + fp,
                "override_rate": _sb_ratio(fp, conf + fp),
            })

            available = len(reviewed_unalerted & unalerted_units) > 0
            out["bias_guard"].update({
                "alerted_samples_used_as_population": False,
                "unalerted_sampling_available": bool(available),
                "false_negative_rate": None,
                "overall_accuracy": None,
                "false_negative_rate_reason": (
                    "未告警文档已有清单复核样本，但 review_status 不构成漏报金标，"
                    "漏报率仍不可估计（需对未告警文档做人工 gold 抽样）"
                    if available else
                    "未告警文档没有足够人工抽样复核：漏报率不可估计"
                    "（禁止用已告警样本当总体）"),
                "overall_accuracy_reason": (
                    "总体准确率 = 已告警正确率×告警率 + 未告警正确率×(1-告警率)，"
                    "缺未告警 gold 抽样，暂不可计算（当前 n(未告警已审查)=%d/%d）"
                    % (len(reviewed_unalerted & unalerted_units), len(unalerted_units))
                    if available else
                    "总体准确率需要未告警文档抽样；当前 n(未告警已审查)=%d/%d"
                    % (len(reviewed_unalerted & unalerted_units), len(unalerted_units))),
            })
            out["caveats"] = [x for x in [
                "分母 = run×object（每轮每份被审文档），包含未告警文档；"
                "不是 shadow_item/已告警 finding 数",
                "反馈条件指标（override_rate）只适用于已告警且被审查的 finding，"
                "不能当文档总体准确率",
                ("有 %d 条 finding 无法归因到具体文档（object_id/manifest_result 均缺失），"
                 "其审查证据不计入文档级 reviewed；见 attribution"
                 % out["attribution"]["unattributed"]) if out["attribution"]["unattributed"] else "",
                "" if available else
                "未告警文档抽样复核不足：false_negative_rate/overall_accuracy "
                "保持 None（不伪造）",
            ] if x]
            return out
    except Exception as exc:  # noqa: BLE001 - 统计失败不能拖垮反馈台账/报告
        logging.getLogger(__name__).warning("sampling bias stats failed", exc_info=True)
        out.update(ok=False, error=f"{type(exc).__name__}: {str(exc)[:200]}")
        out["bias_guard"]["false_negative_rate_reason"] = "stats_failed"
        out["bias_guard"]["overall_accuracy_reason"] = "stats_failed"
        return out
