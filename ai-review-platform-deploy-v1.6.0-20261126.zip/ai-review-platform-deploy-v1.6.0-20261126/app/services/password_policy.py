"""统一密码策略：强度、首登强制改密、放行路径。"""
import os
import re

ALLOWED_WHEN_CHANGE_REQUIRED = {
    "/api/v1/me",
    "/api/v1/me/password",
    "/api/v1/me/permissions",
    "/api/v1/auth/login",
    "/logout",
}


def enforcement_enabled() -> bool:
    """首登/临时密码强制改密是否生效。

    DU-09（2026-11-25）：生产环境恒为 True——旧实现只看 ``RULEPROOF_PASSWORD_ENFORCE``，
    生产误设 =0 就能整体关掉强制改密且无保护。非 prod 仍可用 =0 关闭（兼容演示/测试）。
    """
    if str(os.environ.get("RULEPROOF_ENV") or "").strip().lower() in ("prod", "production"):
        return True
    return str(os.environ.get("RULEPROOF_PASSWORD_ENFORCE", "1")).lower() not in ("0", "false", "no")


def must_change_block(user: dict, path: str) -> bool:
    return bool((user or {}).get("must_change_pwd")) and enforcement_enabled() \
        and path not in ALLOWED_WHEN_CHANGE_REQUIRED


def validate_new_password(password: str) -> str:
    """返回错误文案；空字符串表示通过。"""
    pwd = str(password or "")
    if len(pwd) < 8:
        return "密码至少 8 位"
    if pwd.strip() != pwd:
        return "密码首尾不能有空格"
    # 企业级最低复杂度：大小写、数字、符号各有其一；不做固定密码字典
    if not re.search(r"[A-Z]", pwd) or not re.search(r"[a-z]", pwd) \
            or not re.search(r"\d", pwd) or not re.search(r"[^A-Za-z0-9]", pwd):
        return "密码必须同时包含大写字母、小写字母、数字和符号"
    weak = {"password", "12345678", "admin123", "qwerty123", "abc12345",
            "password1", "admin@123", "123456789", "11111111"}
    if pwd.lower() in weak:
        return "密码过于常见，请更换"
    return ""
