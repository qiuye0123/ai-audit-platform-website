# -*- coding: utf-8 -*-
"""码归属治理：按证据 span 对**冻结规则清单**重推 rule_code（默认关，零行为变化）。

## 为什么需要它

P01 实测（docs/qa/L1三臂配对CI_P01_20261121.md、docs/qa/明确规则召回缺口归因_20261121.md ❌4）：
平台已经判出违规、引文也逐字命中，但 finding 的 rule_code 记在别的点位上 →
官方口径记 FP + 对应 gold 条目记 FN（A1 臂 FP 106 里 67 条内容命中其他 gold 条目；
FN 256 里 82 条「同码 finding 存在但内容不匹配」，其中 79 条的引文内容命中另一条 gold 条目）。
本模块把「码」从生成簇里解耦：只看 (引文 quote, 证据定位, 文档对象) + 冻结规则清单，
重推 span 真正支持的规则码。

## 输入纪律（防作弊，硬约束）

只允许读：
  · finding 本身：quote / summary / 已锚定的原文 span（不含 gold、不含评分结果）
  · 冻结规则清单：manifest items 的 code / name / 判据(criterion|requirement) /
    所需证据(required_evidence) / 常见错误机制(mechanisms，若规则包带)
  · 本轮冻结执行结果（可选）：每个码 D4/D5 判 fail 时自带的证据引文（同 span 支持）
**绝不读** gold / 标准答案 / 评分产物 / 评测结果。gold 只在 scripts/qa 的离线评测脚本里
用于判「改对/改错」，本模块不 import 任何评测模块。

## 重推算法（确定性优先 → 弱信号只排序 → 一证据多码 → 上限）

1. **确定性信号**（可改码的前提，三种，任一命中即为「该码判据被该 span 支持」）：
   a) ``executed_evidence``：同文档**另一个**码本轮 D4/D5 判 fail 时自带的证据引文，
      与 finding 的 span 归一后互相包含（≥6 字）→ 该码自己的判据已在同一 span 上执行过；
   b) ``mechanism_phrase``：规则包「常见错误机制」短语（归一后 ≥6 字）逐字出现在
      finding 的 quote/summary 中 → 该码的判据关键词被 span 支撑；
   c) ``arithmetic``：span 内确定性算错检测（含税重复加计 A×(1+p)=B、金额大小写不一致、
      同一标签两个互斥取值），且该码判据/机制文本含对应判定族关键词。
2. **弱信号**（只做候选排序，**永不直接改码**）：quote 二字组 Dice ↔ (name+criterion+
   required_evidence)。弱信号只写 ``attribution_suggested.weak``，供审计/人工复核。
3. **一证据多码**：同一违规事实确实同时满足多个码的判据 → 每个码独立满足自身判据时
   才各自进入候选（L2 先例：一条 finding 合法支撑 C09-001/002/003）；
4. **上限**：候选码 > ``MAX_CODES``(3) → 整体拒绝（防「判据放松 → FP 放大器」）。

## 开关（默认关，关时逐字段一致）

``RULEPROOF_CODE_ATTRIB``：
  · 未设置 / ``0`` / ``off``  → **off**：不调用、不写字段、不写审计（与现行为逐字段一致）
  · ``1`` / ``suggest`` / ``on`` → **suggest**：写 ``attribution_suggested`` + 审计，
                                  **不改 finding 主码**（「不强改」默认）
  · ``replace`` → **replace**：确定性单码/多码（≤3）时替换主码并留审计
关时行为不变由 ``scripts/qa/code_attribution_test.py`` 双向断言。

## 输出结构

``rederive()`` 返回::

    {"status": "none"|"deterministic"|"rejected_over_limit",
     "current_code": "C08-002",
     "proposed": [{"rule_code": "C08-003", "confidence": 0.9,
                   "kind": "executed_evidence",
                   "attribution_evidence": "...", "span": "..."}],
     "multi_code": false, "changed": true,
     "rejected_over_limit": false,
     "weak": [{"rule_code": ..., "score": 0.42}],   # 只排序，不采纳
     "attribution_evidence": "..."}
"""

from __future__ import annotations

import math
import os
import re

SIGNAL_VERSION = "code-attrib-span/1"
ENV_SWITCH = "RULEPROOF_CODE_ATTRIB"
MAX_CODES = 3          # 一证据多码上限（超过→整体拒绝）
MIN_SIGNAL_LEN = 6     # 确定性信号最短归一长度（太短的关键词不当判据）
CONTEXT_PAD = 240      # span 上下文回看/后看字符数（定位用，不放大为全文匹配）
MODE_OFF, MODE_SUGGEST, MODE_REPLACE = "off", "suggest", "replace"

# 弱信号里压掉「原码自回声」：只取 quote（模型写的 summary 天然带原码词面，会自我强化）
WEAK_QUERY_FIELDS = ("quote",)


# --------------------------------------------------------------------------- 开关
def mode() -> str:
    """当前码归属模式（默认 off；非法值按 off，不静默降级为改码）。"""
    raw = str(os.environ.get(ENV_SWITCH) or "").strip().lower()
    if raw in ("", "0", "off", "false", "no"):
        return MODE_OFF
    if raw in ("1", "on", "true", "yes", "suggest"):
        return MODE_SUGGEST
    if raw in ("replace", "2", "apply"):
        return MODE_REPLACE
    return MODE_OFF


def enabled() -> bool:
    return mode() != MODE_OFF


def switch_snapshot() -> dict:
    return {"env": ENV_SWITCH, "value": repr(os.environ.get(ENV_SWITCH) or ""),
            "mode": mode(), "signal_version": SIGNAL_VERSION, "max_codes": MAX_CODES}


# --------------------------------------------------- sweep 物化前置（E2）专用开关
# 与全局 RULEPROOF_CODE_ATTRIB **独立**：sweep 物化「先重推码、再落库」只看本开关。
# 默认 off（未设置），关时 sweep 物化路径一次都不进 → 与现行为逐字段一致。
ENV_SWEEP_SWITCH = "RULEPROOF_SWEEP_ATTRIB"
SWEEP_MODE_OFF, SWEEP_MODE_SUGGEST, SWEEP_MODE_REPLACE = "off", "suggest", "replace"
# 高置信确定性信号：机制短语**逐字命中** / 算术矛盾（判据族唯一最高分）
HIGH_CONFIDENCE_KINDS = ("mechanism_phrase", "arithmetic")


def sweep_mode() -> str:
    """sweep 物化前置开关（默认 off；非法值按 off，不静默降级为改码）。"""
    raw = str(os.environ.get(ENV_SWEEP_SWITCH) or "").strip().lower()
    if raw in ("", "0", "off", "false", "no"):
        return SWEEP_MODE_OFF
    if raw in ("suggest", "observe"):
        return SWEEP_MODE_SUGGEST
    if raw in ("1", "on", "true", "yes", "replace", "high", "2", "apply"):
        return SWEEP_MODE_REPLACE
    return SWEEP_MODE_OFF


def high_confidence(attr: dict) -> dict:
    """从 rederive() 结果里取「可替换主码」的高置信单码（sweep 物化前置用）。

    只认确定性信号：``mechanism_phrase``（机制短语逐字命中）或 ``arithmetic``
    （span 内确定性算错且判据族唯一最高分——唯一性已由 rederive 保证）。
    弱信号（``weak``）永不采纳；``executed_evidence*`` 在 sweep 无本轮执行结果时不产生；
    候选多码（>1）不替换（P01 实测「一证据多码」是 FP 放大器，见码归属治理报告 §4.5）。

    返回 ``{"ok", "rule_code", "kind", "reason"}``；ok=False 时 reason 说明为何不替换。
    """
    attr = attr or {}
    proposed = [p for p in (attr.get("proposed") or []) if isinstance(p, dict)]
    if attr.get("rejected_over_limit"):
        return {"ok": False, "rule_code": "", "kind": "", "reason": "rejected_over_limit"}
    if not proposed:
        return {"ok": False, "rule_code": "", "kind": "",
                "reason": "no_deterministic_signal"}
    if len(proposed) > 1:
        return {"ok": False, "rule_code": "", "kind": "",
                "reason": "multi_code:%d" % len(proposed)}
    p = proposed[0]
    kinds = [str(k) for k in (p.get("evidence_kinds") or [p.get("kind") or ""]) if k]
    hit = [k for k in kinds if k in HIGH_CONFIDENCE_KINDS]
    if not hit:
        return {"ok": False, "rule_code": str(p.get("rule_code") or ""), "kind": "",
                "reason": "kind_not_high_confidence:%s" % ",".join(kinds)}
    return {"ok": True, "rule_code": str(p.get("rule_code") or ""), "kind": hit[0],
            "reason": "", "confidence": float(p.get("confidence") or 0.0),
            "evidence": str(p.get("attribution_evidence") or "")}


# --------------------------------------------------------------------------- 文本归一（与评分/证据门禁同族口径）
_PUNCT = re.compile(r"[，,。；;：:、\"'“”‘’（）()\[\]【】《》<>…\.\-—_|/\s]+")


def norm(text) -> str:
    """去空白与标点（码归属内部口径；与 p01_reconcile.norm 同族，独立实现避免耦合）。"""
    return _PUNCT.sub("", str(text or ""))


def _bigrams(text: str) -> set:
    s = norm(text)
    if len(s) < 2:
        return set(s) if s else set()
    return {s[i:i + 2] for i in range(len(s) - 1)}


def _dice(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return 2.0 * len(a & b) / (len(a) + len(b))


# --------------------------------------------------------------------------- 规则目录
def _as_list(value) -> list:
    if value is None or value == "":
        return []
    if isinstance(value, dict):
        return [value]
    if isinstance(value, (list, tuple, set)):
        out = []
        for v in value:
            out.extend(_as_list(v))
        return out
    return [value]


def _criterion_of(item: dict) -> str:
    slots = item.get("slots") if isinstance(item.get("slots"), dict) else {}
    for v in (slots.get("criterion"), item.get("criterion"), item.get("requirement"),
              (item.get("pack_meta") or {}).get("criterion") if isinstance(
                  item.get("pack_meta"), dict) else ""):
        if str(v or "").strip():
            return str(v)
    return ""


def _evidence_of(item: dict) -> list:
    slots = item.get("slots") if isinstance(item.get("slots"), dict) else {}
    out = []
    for v in (item.get("required_evidence"), slots.get("required_evidence"),
              slots.get("evidence_required"), item.get("evidence_terms")):
        out.extend(_as_list(v))
    pm = slots.get("pack_meta") if isinstance(slots.get("pack_meta"), dict) else {}
    out.extend(_as_list(pm.get("evidence_categories")))
    return [x for x in out if str(x).strip()]


def _mechanisms_of(item: dict) -> list:
    """从**冻结规则清单 item** 读「常见错误机制 / 机制短语」。

    冻结链路：规则包导入（rule.import_rule_pack）→ slots.pack_meta.mechanisms →
    manifest.freeze 把 slots 原样写进 items_json → 本函数只读这份冻结快照。
    绝不读实时规则库/latest_version（执行期改规则不影响已冻结清单）。
    兼容字段名：mechanisms / mechanism_phrases / 常见错误机制 / 机制短语。
    """
    slots = item.get("slots") if isinstance(item.get("slots"), dict) else {}
    pm = slots.get("pack_meta") if isinstance(slots.get("pack_meta"), dict) else {}
    item_pm = item.get("pack_meta") if isinstance(item.get("pack_meta"), dict) else {}
    out = []
    for container in (item, slots, pm, item_pm):
        for key in ("mechanisms", "mechanism_phrases", "常见错误机制", "机制短语"):
            out.extend(_as_list(container.get(key)))
    return [x for x in out if str(x).strip()]


def build_catalog(items: list) -> dict:
    """冻结规则清单 → {code: meta}。items 可来自 manifest items_json 或 rules_json。"""
    catalog = {}
    for it in items or []:
        if not isinstance(it, dict):
            continue
        code = str(it.get("code") or it.get("rule_code") or "").strip()
        if not code:
            continue
        meta = catalog.setdefault(code, {"code": code, "name": "", "criterion": "",
                                         "required_evidence": [], "mechanisms": [],
                                         "nature": "", "object_id": ""})
        meta["name"] = meta["name"] or str(it.get("name") or it.get("rule_name") or "")
        meta["criterion"] = meta["criterion"] or _criterion_of(it)
        for ev in _evidence_of(it):
            if ev not in meta["required_evidence"]:
                meta["required_evidence"].append(ev)
        for mech in _mechanisms_of(it):
            if mech not in meta["mechanisms"]:
                meta["mechanisms"].append(mech)
        meta["nature"] = meta["nature"] or str(it.get("nature") or "")
        meta["object_id"] = meta["object_id"] or str(it.get("object_id") or "")
    return catalog


# --------------------------------------------------------------------------- span 与定位
def find_span(doc_text: str, quote: str) -> dict:
    """在原文中定位引文，返回 {ok, start, end, span, context, located_by}。"""
    doc = str(doc_text or "")
    q = str(quote or "").strip()
    if not doc or not q:
        return {"ok": False, "start": -1, "end": -1, "span": q, "context": q,
                "located_by": "missing"}
    i = doc.find(q)
    if i >= 0:
        span = q
        located_by = "verbatim"
    else:
        nq = norm(q)
        if len(nq) < MIN_SIGNAL_LEN:
            return {"ok": False, "start": -1, "end": -1, "span": q, "context": q,
                    "located_by": "not_found"}
        # 归一化定位：按非空白切分逐段回找（不改原文，只用于取上下文）
        probe = re.sub(r"\s+", "", q)[:24]
        i = -1
        for cand in ([probe, probe[:16], probe[:12]] if probe else []):
            j = re.sub(r"\s+", "", doc).find(cand)
            if j >= 0:
                i = j
                break
        if i < 0:
            return {"ok": False, "start": -1, "end": -1, "span": q, "context": q,
                    "located_by": "not_found"}
        span = q
        located_by = "normalized"
    start, end = i, min(len(doc), i + max(1, len(span)))
    ctx = doc[max(0, start - CONTEXT_PAD):end + CONTEXT_PAD]
    return {"ok": True, "start": start, "end": end, "span": span, "context": ctx,
            "located_by": located_by}


# --------------------------------------------------------------------------- 确定性算错检测（span 内）
_NUM = re.compile(r"\d[\d,，]*(?:\.\d+)?")
_PCT = re.compile(r"(\d+(?:\.\d+)?)\s*[%％]")
_CN_AMOUNT = re.compile(r"[零壹贰叁肆伍陆柒捌玖拾佰仟万亿元圆整角分]{2,}")


def _nums(text: str) -> list:
    out = []
    for m in _NUM.findall(str(text or "")):
        try:
            out.append(float(m.replace(",", "").replace("，", "")))
        except ValueError:
            continue
    return out


_CN_DIGITS = {"零": 0, "壹": 1, "贰": 2, "叁": 3, "肆": 4, "伍": 5, "陆": 6, "柒": 7,
              "捌": 8, "玖": 9}
_CN_UNITS = {"拾": 10, "佰": 100, "仟": 1000}


def _cn_to_number(cn: str):
    """中文大写金额 → 数值（支持 万/亿 进位与小数角分；解析不了返回 None）。"""
    s = str(cn or "").strip()
    if not s:
        return None
    total, section, number, seen = 0.0, 0.0, 0, False
    for ch in s:
        if ch in _CN_DIGITS:
            number = _CN_DIGITS[ch]
            seen = True
        elif ch in _CN_UNITS:
            number = (number or 1) * _CN_UNITS[ch]
            section += number
            number = 0
            seen = True
        elif ch == "万":
            section = (section + number) * 10000
            total += section
            section, number = 0, 0
            seen = True
        elif ch == "亿":
            total = (total + section + number) * 100000000
            section, number = 0, 0
            seen = True
        elif ch in ("元", "圆"):
            section += number
            total += section
            section, number = 0, 0
        elif ch in ("整", "正"):
            continue
        else:
            continue
    if not seen:
        return None
    return total + section + number


def _det_upper_lower_amount(span: str):
    """金额大小写不一致：同一句里「壹万元（¥1000）」大写值与数字值不符。"""
    cn = _CN_AMOUNT.search(span or "")
    if not cn:
        return None
    cn_value = _cn_to_number(cn.group(0))
    if not cn_value:
        return None
    tail = (span or "")[cn.end():cn.end() + 24]
    head = (span or "")[max(0, cn.start() - 24):cn.start()]
    nums = _nums(tail) or _nums(head)
    if not nums:
        return None
    for n in nums:
        if n <= 0:
            continue
        if abs(n - cn_value) > 1.0:
            return {"detector": "amount_upper_lower_mismatch",
                    "detail": "大写「%s」=%s 与数字 %s 不一致" % (
                        cn.group(0), _fmt(cn_value), _fmt(n)),
                    "family": "amount_consistency"}
    return None


def _det_tax_recompute(span: str):
    """含税重复加计：span 内同时有 p% 与两笔金额，且 B ≈ A×(1+p/100)（或反向）。"""
    s = str(span or "")
    pcts = [float(x) for x in _PCT.findall(s)]
    if not pcts:
        return None
    nums = [x for x in _nums(s) if x >= 1000]
    if len(nums) < 2:
        return None
    for p in pcts[:3]:
        factor = 1.0 + p / 100.0
        if factor <= 1.0:
            continue
        for a in nums:
            for b in nums:
                if a == b or a <= 0 or b <= 0:
                    continue
                if abs(b - a * factor) <= max(0.02, a * 1e-5):
                    return {"detector": "tax_recompute_duplicate",
                            "detail": "含税复算：%s×(1+%s%%)=%s≈%s（同一数量重复加计）" % (
                                _fmt(a), _fmt(p), _fmt(a * factor), _fmt(b)),
                            "family": "recompute_rate_base"}
    return None


def _det_label_duplicate(span: str):
    """同一标签出现两个互斥取值（合计/总价/最高限价 等标签后面跟不同数）。"""
    s = str(span or "")
    pat = re.compile(r"(合计[^0-9。；]{0,12}|总价[^0-9。；]{0,8}|最高(?:投标)?限价[^0-9。；]{0,8})"
                     r"[^0-9]{0,8}(\d[\d,，]*(?:\.\d+)?)")
    pairs = collections_pairs = {}
    for label, num in pat.findall(s):
        key = norm(label)[:6]
        if not key:
            continue
        try:
            val = float(num.replace(",", "").replace("，", ""))
        except ValueError:
            continue
        pairs.setdefault(key, []).append(val)
    del collections_pairs
    for key, vals in pairs.items():
        uniq = []
        for v in vals:
            if v not in uniq:
                uniq.append(v)
        if len(uniq) >= 2:
            return {"detector": "label_duplicate_value",
                    "detail": "「%s」出现 %d 个互斥取值：%s" % (
                        key, len(uniq), "/".join(_fmt(v) for v in uniq[:3])),
                    "family": "total_item_consistency"}
    return None


def _fmt(v: float) -> str:
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return ("%.4f" % v).rstrip("0").rstrip(".")


_AMBIGUOUS_LABELS = ("合计", "总价", "限价", "总额", "小计")


def _ambiguous_duplicate(span: str, doc_context: str = ""):
    """收紧版 label_duplicate：标签必须命中 _AMBIGUOUS_LABELS（防把普通表格误判）。"""
    hit = _det_label_duplicate(span)
    if not hit:
        return None
    label = hit["detail"].split("」")[0].lstrip("「")
    if not any(x in label for x in _AMBIGUOUS_LABELS):
        return None
    return hit


# 算错检测族 → 该族支持哪些码：用码**自身判据/机制文本**里的关键词做归属（不放宽到全文）
FAMILY_KEYS = {
    "amount_consistency": ("大小写", "大写", "金额", "一致", "保证金", "数字"),
    "recompute_rate_base": ("复算", "费率", "基数", "税率", "含税", "税额", "计价", "下浮", "比例"),
    "total_item_consistency": ("合计", "加总", "分项", "总价", "汇总", "汇总与总量", "复算"),
}


def _det_keyword_codes(catalog: dict, family: str) -> list:
    """[(code, score)] 按判定族关键词命中数降序；score<2 不进（单一关键词不当判据）。"""
    keys = FAMILY_KEYS.get(family) or ()
    out = []
    for code, meta in catalog.items():
        hay = " ".join([str(meta.get("name") or ""), str(meta.get("criterion") or "")]
                       + [str(x) for x in (meta.get("mechanisms") or [])])
        score = sum(1 for k in keys if k and k in hay)
        if score >= 2:
            out.append((code, score))
    out.sort(key=lambda x: (-x[1], x[0]))
    return out


# --------------------------------------------------------------------------- 执行证据支持
def _exec_evidence_by_code(execution: dict, catalog: dict) -> dict:
    """{code: [evidence quote/detail...]}（只取本轮判 fail 且自带引文的码）。"""
    out = {}
    for code, results in (execution or {}).items():
        if catalog and code not in catalog:
            continue
        quotes = []
        for r in _as_list(results):
            if not isinstance(r, dict):
                continue
            d5 = r.get("d5") if isinstance(r.get("d5"), dict) else {}
            if str(d5.get("status") or "") != "fail":
                continue
            d4 = r.get("d4") if isinstance(r.get("d4"), dict) else {}
            for sub in _as_list(d4.get("subs")):
                if not isinstance(sub, dict):
                    continue
                for q in (sub.get("quote"), (sub.get("raw_item") or {}).get("quote")):
                    if str(q or "").strip():
                        quotes.append(str(q))
                for d in (sub.get("detail"), (sub.get("raw_item") or {}).get("rationale")):
                    if str(d or "").strip():
                        quotes.append(str(d))
        if quotes:
            out[code] = quotes
    return out


def _overlap(a: str, b: str) -> bool:
    na, nb = norm(a), norm(b)
    if len(na) < MIN_SIGNAL_LEN or len(nb) < MIN_SIGNAL_LEN:
        return False
    return na in nb or nb in na


# --------------------------------------------------------------------------- 主入口
def rederive(finding: dict, doc_text: str, catalog: dict, *,
             execution: dict | None = None, max_codes: int = MAX_CODES) -> dict:
    """按 span 重推 finding 的 rule_code（纯函数，不落库、不改入参）。

    finding: {"code", "quote", "summary"(可选), "title"(可选), "object_id"(可选)}
    doc_text: 文档原文
    catalog: build_catalog() 结果（**只含本轮冻结清单**）
    execution: 可选 {code: [{"d4":..., "d5":...}]}（本轮冻结执行结论，用于同 span 支持）
    """
    finding = finding or {}
    catalog = catalog or {}
    current = str(finding.get("code") or finding.get("rule_code") or "")
    loc = find_span(doc_text, finding.get("quote") or "")
    span = loc.get("span") or str(finding.get("quote") or "")
    context = loc.get("context") or span
    finding_text = " ".join([str(finding.get("quote") or ""),
                             str(finding.get("summary") or ""),
                             str(finding.get("title") or "")]).strip()
    results = []

    # ---- a) 同 span 的执行证据支持（另一个码自己的判据已在该 span 上执行过）
    ev_by_code = _exec_evidence_by_code(execution or {}, catalog)
    current_supported = False
    for q in ev_by_code.get(current) or []:
        if _overlap(q, span) or _overlap(q, context):
            current_supported = True
            break
    for code, quotes in ev_by_code.items():
        if code == current:
            continue
        for q in quotes:
            if _overlap(q, span):
                results.append({"rule_code": code, "kind": "executed_evidence",
                                "confidence": 0.9 if loc.get("located_by") == "verbatim" else 0.75,
                                "attribution_evidence":
                                    "该码本轮 D4/D5 判 fail 的证据引文与 span 互相包含：%s"
                                    % _clip(q, 80),
                                "span": span})
                break
            if _overlap(q, context):
                results.append({"rule_code": code, "kind": "executed_evidence_context",
                                "confidence": 0.65,
                                "attribution_evidence":
                                    "该码本轮 D4/D5 判 fail 的证据引文落在 span 上下文内：%s"
                                    % _clip(q, 80),
                                "span": span})
                break

    # ---- b) 规则包「常见错误机制」短语逐字命中 finding 文本
    for code, meta in catalog.items():
        if code == current:
            continue
        for mech in meta.get("mechanisms") or []:
            nm = norm(mech)
            if len(nm) >= MIN_SIGNAL_LEN and nm in norm(finding_text):
                results.append({"rule_code": code, "kind": "mechanism_phrase",
                                "confidence": 0.85,
                                "attribution_evidence": "规则包常见错误机制逐字命中：%s" % mech,
                                "span": span})
                break

    # ---- c) span 上下文内确定性算错 → 该族关键词归属（单码才采纳；用 context 而非全文）
    det_span = context if loc.get("located_by") == "verbatim" else span
    for det in filter(None, (_det_upper_lower_amount(det_span),
                             _det_tax_recompute(det_span),
                             _ambiguous_duplicate(det_span))):
        ranked = [(c, n) for c, n in _det_keyword_codes(catalog, det["family"])
                  if c != current]
        if not ranked:
            continue
        # 唯一最高分才采纳（并列=判据族无法唯一定位 → 不进确定性集合，防放宽）
        if len(ranked) == 1 or ranked[0][1] > ranked[1][1]:
            results.append({"rule_code": ranked[0][0], "kind": "arithmetic",
                            "confidence": 0.8,
                            "attribution_evidence": "%s（判据族 %s 唯一最高分 %d vs 次高 %s）"
                                                    % (det["detail"], det["family"],
                                                       ranked[0][1],
                                                       ranked[1][1] if len(ranked) > 1 else "-"),
                            "span": span})

    # 现码已由本轮执行证据支撑同一 span → 只抑制「执行证据」类候选（斑马判据）；
    # 机制短语/算错检测是独立的「内容↔判据」检查，不受此抑制。
    if current_supported and results:
        results = [r for r in results
                   if r.get("kind") not in ("executed_evidence",
                                            "executed_evidence_context")]

    # 同码多信号合并（保留最高置信度并记录全部证据）
    merged = {}
    for r in results:
        cur = merged.get(r["rule_code"])
        if cur is None:
            merged[r["rule_code"]] = dict(r, evidence_kinds=[r["kind"]])
        else:
            cur["confidence"] = max(cur["confidence"], r["confidence"])
            cur["evidence_kinds"] = list(dict.fromkeys(
                cur.get("evidence_kinds", []) + [r["kind"]]))
            cur["attribution_evidence"] = cur["attribution_evidence"] + "；" + r["attribution_evidence"]
    proposed = sorted(merged.values(), key=lambda x: (-x["confidence"], x["rule_code"]))

    # ---- 弱信号排序（只写建议，不采纳）
    weak = weak_rank(finding, catalog, exclude=current, top=max(3, max_codes))

    over = len(proposed) > max(0, int(max_codes))
    out = {"signal_version": SIGNAL_VERSION, "current_code": current,
           "located_by": loc.get("located_by"), "span": span,
           "proposed": [] if over else proposed,
           "candidates_all": proposed,
           "multi_code": (not over) and len(proposed) > 1,
           "changed": bool(proposed) and not over and
                      ({p["rule_code"] for p in proposed} != {current}),
           "rejected_over_limit": over,
           "current_supported": current_supported,
           "max_codes": int(max_codes),
           "weak": weak,
           "attribution_evidence": "；".join(p["attribution_evidence"] for p in proposed)
                                    if proposed else "",
           "status": ("rejected_over_limit" if over else
                      ("deterministic" if proposed else "none"))}
    if over:
        out["attribution_evidence"] = (
            "候选码 %d > 上限 %d，拒绝改码（防判据放宽变 FP 放大器）：%s"
            % (len(proposed), max_codes, ",".join(p["rule_code"] for p in proposed)))
    return out


def weak_rank(finding: dict, catalog: dict, *, exclude: str = "", top: int = 3) -> list:
    """弱信号：quote 二字组 Dice ↔ (name+criterion+required_evidence)，只排序不采纳。"""
    q = " ".join(str(finding.get(f) or "") for f in WEAK_QUERY_FIELDS)
    qb = _bigrams(q)
    if not qb:
        return []
    rows = []
    for code, meta in catalog.items():
        if code == exclude:
            continue
        hay = " ".join([str(meta.get("name") or ""), str(meta.get("criterion") or ""),
                        " ".join(str(x) for x in (meta.get("required_evidence") or []))])
        score = _dice(qb, _bigrams(hay))
        if score > 0:
            rows.append({"rule_code": code, "score": round(score, 4),
                         "kind": "weak_lexical",
                         "attribution_evidence": "弱信号（仅排序，不改码）：quote 与 %s 的判据/证据二字组重合 %.3f"
                                                 % (code, score)})
    rows.sort(key=lambda x: (-x["score"], x["rule_code"]))
    return rows[:max(1, int(top))]


def _clip(text, n: int = 80) -> str:
    t = " ".join(str(text or "").split())
    return t if len(t) <= n else t[:n] + "…"


# --------------------------------------------------------------------------- 应用到 finding（开关门）
def apply(finding: dict, doc_text: str, catalog: dict, *,
          execution: dict | None = None, audit: callable = None) -> dict:
    """对单条 finding 应用码归属（**开关关闭时原样返回，逐字段不变**）。

    返回 ``{"mode","finding","attribution","changed","findings"}``：
      · off      : finding 原对象返回（不新增字段、不调 audit）
      · suggest  : finding 原样 + 新增 ``attribution_suggested``；调 audit
      · replace  : 单码 → 替换 code/rule_id；多码 → 每个码各一条（copy，≤3）；
                   弱信号永不改码
    """
    m = mode()
    if m == MODE_OFF:
        return {"mode": m, "finding": finding, "attribution": None,
                "changed": False, "findings": [finding]}
    attr = rederive(finding, doc_text, catalog, execution=execution)
    if not attr["proposed"] and not attr["weak"]:
        return {"mode": m, "finding": finding, "attribution": attr,
                "changed": False, "findings": [finding]}
    payload = {
        "schema": SIGNAL_VERSION, "current_code": attr["current_code"],
        "suggested": [p["rule_code"] for p in attr["proposed"]],
        "multi_code": attr["multi_code"],
        "rejected_over_limit": attr["rejected_over_limit"],
        "confidence": [p["confidence"] for p in attr["proposed"]],
        "evidence": attr["attribution_evidence"],
        "weak": [{"rule_code": w["rule_code"], "score": w["score"]} for w in attr["weak"]],
        "mode": m,
    }
    if audit is not None and (attr["proposed"] or attr["weak"]):
        try:
            audit({"action": "code_attribution", "case_id": finding.get("case_id") or "",
                   "finding_id": finding.get("id") or "",
                   "payload": payload})
        except Exception:  # noqa: BLE001 - 审计失败不静默改码：上抛由调用方处理
            raise
    if m == MODE_SUGGEST:
        out = dict(finding)
        out["attribution_suggested"] = payload
        return {"mode": m, "finding": out, "attribution": attr,
                "changed": False, "findings": [out]}
    # replace：多码 → 每码一条（各自独立满足判据）；单码 → 替换
    if not attr["proposed"]:
        return {"mode": m, "finding": finding, "attribution": attr,
                "changed": False, "findings": [finding]}
    outs = []
    for i, p in enumerate(attr["proposed"]):
        nf = dict(finding)
        nf["code"] = p["rule_code"]
        if "rule_id" in nf:
            nf["rule_id"] = p["rule_code"]
        if "point_id" in nf:
            nf["point_id"] = p["rule_code"]
        nf["attribution"] = dict(payload, applied_code=p["rule_code"])
        if i > 0:
            nf["id"] = "%s#attr%d" % (finding.get("id") or "", i)
        outs.append(nf)
    return {"mode": m, "finding": outs[0], "attribution": attr,
            "changed": bool(attr["proposed"]), "findings": outs}


def summarize(results: list) -> dict:
    """批量结果的机读汇总（供审计/报告用）。"""
    out = {"n": len(results or []), "changed": 0, "suggested": 0, "multi_code": 0,
           "rejected": 0, "none": 0, "mode": mode()}
    for r in results or []:
        a = (r or {}).get("attribution") or {}
        out["mode"] = (r or {}).get("mode") or out["mode"]
        if (r or {}).get("changed"):
            out["changed"] += 1
        if a.get("proposed"):
            out["suggested"] += 1
        if a.get("multi_code"):
            out["multi_code"] += 1
        if a.get("rejected_over_limit"):
            out["rejected"] += 1
        if a.get("status") == "none":
            out["none"] += 1
    return out


# ============================================================================
# BX 事项级锚定 + 同事项对码重推（2026-11-23，BXS2）
# ============================================================================
# 依据 docs/qa/BX缺口分析_20261123.md §2.1/§2.2：BX 合同盲测的违规全部以
# 「已批准商务条件 SW-xxxx / 拟定执行条款 TK-xxxx」**同号事项对**给出（每事项 1 对）；
# 「参考范本正文」里的空白占位符不是待签正文，不得作为 fail 证据。
# 本段只做确定性两件事，**不读 gold / 标准答案 / 评分产物**：
#   1) 引文锚定 ``bx_quote_anchor``：quote 是否落在 SW/TK 同号事项段内、是否模板空白；
#   2) 同事项对码重推 ``bx_materialize_adjust``：对 finding 已锚定的事项对做
#      「两侧取数 + 算术/条件对照」，高置信（机制短语命中/算错检测）才替换主码；
#      弱信号只记录建议（suggest）。
# 开关（2026-11-23 起默认开 = 已签署 RD-002；显式 0/false/no/off 关闭，关时逐字段不变）：
#   · ``RULEPROOF_BX_ANCHOR``：总开关。作用域 **BX 专属**（BX 码 / SW-TK 事项结构门控）：
#     未设置及其它值 → 生效；显式 0/false/no/off → 本段全部函数返回「保持不变」；
#   · ``RULEPROOF_CODE_ATTRIB``：复用既有 suggest/replace 两级——suggest 只建议不改码，
#     replace 才替换主码（off 时即便 BX_ANCHOR 开也不改码）。
#     **保持默认 off**（RD-002 §2.2：通用码归属重推历史实测 −1.18pp/−7.61pp 已证伪，
#     仅 BX 专属路径有效 → 不随 BX_ANCHOR 一起开）。
# 非 BX 文档（无 SW/TK 事项段）→ ``ok=True`` / 不改码，行为与现链路一致。
ENV_BX_ANCHOR = "RULEPROOF_BX_ANCHOR"
_BX_ANCHOR_OFF_VALUES = ("0", "false", "no", "off", "none", "disable", "disabled")
BX_ANCHOR_VERSION = "bx-item-anchor/1"
_BX_MODE_OFF, _BX_MODE_SUGGEST, _BX_MODE_REPLACE = "off", "suggest", "replace"
_BX_ITEM_HEAD = re.compile(r"(?m)^#{1,6}\s*((?:SW|TK)-([0-9A-Za-z]+))\s*(.*?)\s*$")
_BX_ANY_HEAD = re.compile(r"(?m)^(#{1,6})\s+(.+?)\s*$")
_BX_BLANK = re.compile(r"(_{2,}|＿{1,}|□{1,}|×{2,}|\s{2,}[%％])")
# 机制短语签名（BX 36 码中可确定性对照的 6 个「同事项对」机制；每条都是
# 「SW 侧取到已批准条件 + TK 侧取到执行值/条件」两侧齐备才命中，白名单式登记）。
_BX_MECH_RULES = (
    # (code, 机制名, SW/TK 联合正则（归一文本），说明)
    ("E03-003", "累计责任限额超限",
     r"合同总价([0-9]+(?:\.[0-9]+)?)万元的([0-9]+(?:\.[0-9]+)?)%"
     r".*?已赔付[^。；]{0,16}?([0-9]+(?:\.[0-9]+)?)万元"
     r".*?本次[^。；]{0,20}?([0-9]+(?:\.[0-9]+)?)万元",
     "limit=总价×比例；已赔付+本次 > limit → 累计责任限额被突破"),
    ("F10-004", "含税总价另加税",
     r"(?:含税总价[^。；]{0,30}?(?:包含|已含)[^。；]{0,20}?税款|已包含[^。；]{0,10}?全部税款)"
     r".*?另[^。；]{0,16}?加收[^。；]{0,12}?税款",
     "SW 声明含税总价已含全部税款，TK 另行加收税款 → 含税口径被追加"),
    ("C08-006", "固定金额被下浮",
     r"([0-9]+(?:\.[0-9]+)?)万元代垫行政收费[^。；]{0,24}?(?:固定金额|不参与[^。；]{0,12}?下浮)"
     r".*?代垫行政收费按([0-9]+(?:\.[0-9]+)?)万元计列",
     "SW 固定金额计入且不参与下浮，TK 按不同金额计列 → 固定金额被比例下浮"),
    ("F09-001", "付款触发脱离履约节点",
     r"(?:首付款)?以[^。；]{0,40}?(?:为条件|不构成付款节点)"
     r".*?(?:签约即支付|签约即)[^。；]{0,30}?(?:首付款|付款)",
     "SW 付款以履约事件为条件，TK 签约即付 → 付款触发脱离约定履约节点"),
)


def bx_anchor_enabled() -> bool:
    """BX 事项级锚定**总开关**（默认开 = 已签署 RD-002；显式 0/false/no/off 关闭 = 回滚杆）。

    作用域（**BX 专属，非全局**）：只影响 BX 路径 —— ``bx_quote_anchor`` / ``bx_rederive`` /
    ``bx_materialize_adjust``、C08 三码确定性判据（``BX_C08_DET_CODES``）与 S2 事项级锚定；
    代码按 BX 码 / SW-TK 事项结构门控，**非 BX 文档（无 SW/TK 事项段）零行为变化**
    （RD-002 G2 全量口径：P01 +1.16 / CT −0.30 / PROCESS −0.00pp，均 ≥ −0.5pp）。
    ``RULEPROOF_CODE_ATTRIB`` **保持默认 off**（不随本开关开启；通用码归属重推历史实测
    −1.18pp/−7.61pp 已证伪方向，仅 BX 专属路径有效 → BX 约 −1.28pp 残留损失在 RD-002 §2.2 接受）。

    签署依据（RD-002，2026-11-23，`docs/qa/发布决定_RD-002_BX锚定默认_20261123.md`）：
    - LaneG 漂移归因（`docs/qa/BX漂移归因2_20261123.md`）：BX 单集 4.83pp 漂移的 95.4% 来自
      「开关半开」——C08 三码 TP 37/37（历史 official pin 开）→ 10/37（默认关），占总 TP 差 96%；
    - LaneH 候选实测（build36 快照 ee415ea，COHORT-B `MANIFEST_TOTAL_SHA256 91aed48d…`，
      BX 20 份 A 臂；`docs/qa/RD候选实测_20261123.md`）：BX F1 **.9538**（门 ≥.885）、
      C08 三码 TP **恢复 37/37**（冻结为 10/37）→ RD-002 G1 PASS；G2 作用域隔离 PASS；
      G3 四集合并 L1 NI PASS（无单集 FAIL）。

    回滚：显式 ``RULEPROOF_BX_ANCHOR=0``（或 false/no/off）→ 本段全部函数返回「保持不变」，
    行为与历史默认关逐字段一致；回滚杆长期保留，无需改代码即可回退。
    再改默认须**另起发布决定**并重跑 BX 20 份 A 臂 + 重新冻结 cohort。
    """
    raw = str(os.environ.get(ENV_BX_ANCHOR) or "").strip().lower()
    return raw not in _BX_ANCHOR_OFF_VALUES


def _bx_norm(text) -> str:
    return re.sub(r"\s+", "", str(text or ""))


def _bx_norm_with_map(text: str):
    """归一空白后的文本 + 归一字符 → 原文下标 的映射（引文定位用）。"""
    chars, idx = [], []
    for i, ch in enumerate(str(text or "")):
        if ch.isspace():
            continue
        chars.append(ch)
        idx.append(i)
    return "".join(chars), idx


def bx_doc_items(doc_text: str) -> dict:
    """解析 BX「SW-xxxx/TK-xxxx 同号事项段」结构。

    返回 ``{"items": {num: {"sw": str, "tk": str}}, "has_items": bool}``；
    非 BX 文档（找不到 SW/TK 事项目录）→ ``has_items=False``（调用方保持原行为）。
    """
    text = str(doc_text or "")
    heads = []
    for m in _BX_ANY_HEAD.finditer(text):
        heads.append({"level": len(m.group(1)), "title": m.group(2).strip(),
                      "start": m.start(), "body_start": m.end()})
    item_heads = []
    for h in heads:
        mm = re.match(r"((?:SW|TK)-([0-9A-Za-z]+))\b\s*(.*)$", h["title"])
        if mm:
            item_heads.append({"tag": mm.group(1), "num": mm.group(2),
                               "kind": mm.group(1).split("-", 1)[0],
                               "start": h["start"], "body_start": h["body_start"],
                               "level": h["level"]})
    items = {}
    for i, ih in enumerate(item_heads):
        end = len(text)
        for h in heads:
            if h["start"] > ih["start"]:
                end = h["start"]
                break
        body = text[ih["body_start"]:end].strip()
        rec = items.setdefault(ih["num"], {"sw": "", "tk": "", "sw_span": None, "tk_span": None})
        key = "sw" if ih["kind"] == "SW" else "tk"
        if not rec.get(key):
            rec[key] = body
            rec[key + "_span"] = [ih["body_start"], end]
    return {"items": items, "has_items": bool(item_heads), "n_items": len(items)}


def bx_quote_anchor(quote, doc_text: str) -> dict:
    """引文锚定：quote 是否落在 SW/TK 同号事项段内（模板/前言/空白 → 不通过）。

    返回 ``{"ok","has_items","kind","item","blank","template","reason"}``：
      · 非 BX 文档（无事项段）→ ok=True（不改现链路）；
      · 空白占位符（__ / □ / ×× / 「    %」）或「参考范本正文」/前言 → ok=False。
    """
    q = str(quote or "")
    parsed = bx_doc_items(doc_text)
    if not parsed["has_items"]:
        return {"ok": True, "has_items": False, "kind": "", "item": "", "blank": False,
                "template": False, "reason": "no_bx_item_structure", "version": BX_ANCHOR_VERSION}
    blank = bool(_BX_BLANK.search(q))
    text = str(doc_text or "")
    nq = _bx_norm(q)
    # 引文自带事项标题（如 "TK-1190 事项1190 ..."）→ 直接按标题判定
    m0 = re.match(r"((?:SW|TK)-([0-9A-Za-z]+))", nq)
    if m0:
        kind, num = m0.group(1).split("-", 1)[0], m0.group(2)
        return {"ok": not blank, "has_items": True, "kind": kind, "item": num,
                "blank": blank, "template": False,
                "reason": ("blank_quote" if blank else "quote_starts_with_item_heading"),
                "version": BX_ANCHOR_VERSION}
    ndoc, imap = _bx_norm_with_map(text)
    pos = ndoc.find(nq) if nq else -1
    raw_idx = imap[pos] if pos >= 0 and pos < len(imap) else -1
    kind, num, template = "", "", False
    if raw_idx >= 0:
        last = None
        for m in _BX_ANY_HEAD.finditer(text):
            if m.start() > raw_idx:
                break
            last = m
        if last is not None:
            title = last.group(2).strip()
            mm = re.match(r"((?:SW|TK)-([0-9A-Za-z]+))\b", title)
            if mm:
                kind, num = mm.group(1).split("-", 1)[0], mm.group(2)
            elif "参考范本" in title:
                template = True
            elif last.group(1) not in ("#####", "######"):
                template = "参考范本" in title or "范本正文" in title
    in_item = bool(kind)
    ok = bool(in_item and not blank and not template)
    reason = ("ok" if ok else "blank_quote" if blank else
              "template_section" if template else "not_in_sw_tk_item")
    return {"ok": ok, "has_items": True, "kind": kind, "item": num, "blank": blank,
            "template": bool(template), "reason": reason, "located": raw_idx >= 0,
            "version": BX_ANCHOR_VERSION}


def _bx_item_pair_text(doc_text: str, anchor: dict) -> str:
    """取引文所锚事项的 SW-n + TK-n 两侧原文（同号事项对）。"""
    num = str((anchor or {}).get("item") or "")
    if not num:
        return ""
    rec = (bx_doc_items(doc_text).get("items") or {}).get(num) or {}
    return "\n".join(x for x in (rec.get("sw") or "", rec.get("tk") or "") if x)


def _bx_pair_mechanisms(pair_text: str) -> list:
    """同事项对机制检测（确定性判据，返回 [{code,kind,confidence,evidence}]）。"""
    t = _bx_norm(pair_text)
    out = []
    for code, name, pattern, why in _BX_MECH_RULES:
        m = re.search(pattern, t, re.S)
        if not m:
            continue
        detail = name
        if code == "E03-003":
            try:
                total, pct, paid, cur = (float(m.group(1)), float(m.group(2)),
                                         float(m.group(3)), float(m.group(4)))
                limit = total * pct / 100.0
                if paid + cur <= limit + 1e-6:
                    continue
                detail = "%s（限额 %.4g=%.4g×%.4g%%，已赔付 %.4g+本次 %.4g > 限额）" % (
                    name, limit, total, pct, paid, cur)
            except Exception:
                continue
        elif code == "C08-006":
            try:
                fixed, actual = float(m.group(1)), float(m.group(2))
                if abs(fixed - actual) < 1e-9:
                    continue
                detail = "%s（SW 固定 %.4g 万元 ≠ TK 计列 %.4g 万元）" % (name, fixed, actual)
            except Exception:
                continue
        out.append({"rule_code": code, "kind": "mechanism_phrase", "confidence": 0.9,
                    "mechanism": name, "detail": why,
                    "attribution_evidence": "同事项对确定性机制命中：%s" % detail})
    return out


def bx_rederive(quotes, doc_text: str) -> dict:
    """对已锚定的同号事项对重推码（纯确定性；无信号 → status=none）。

    返回 ``{"status","anchor","proposed":[{rule_code,kind,confidence,...}],"weak":[]}``。
    """
    quotes = [str(q or "") for q in (quotes if isinstance(quotes, (list, tuple)) else [quotes])]
    anchors = [bx_quote_anchor(q, doc_text) for q in quotes if str(q or "").strip()]
    anchor = next((a for a in anchors if a.get("item")), anchors[0] if anchors else {})
    # 多引文锚定一致性：同一 finding 的多条引文必须落在**同号事项**才重推码；
    # 引文跨多个事项（模型把 A 事项的问题挂到 B 事项码上）→ 无法唯一定位，只记建议不改码。
    items = sorted({str(a.get("item")) for a in anchors if a.get("item")})
    if len(items) > 1:
        return {"status": "ambiguous_anchor", "anchor": anchor, "pair_available": False,
                "proposed": [], "weak": [{"rule_code": "", "score": 0.0,
                                          "kind": "weak_anchor_ambiguous",
                                          "attribution_evidence":
                                          "同一 finding 的多条引文分属多个事项号 %s，不重推码" % ",".join(items)}],
                "signal_version": BX_ANCHOR_VERSION}
    pair = _bx_item_pair_text(doc_text, anchor)
    proposed = _bx_pair_mechanisms(pair) if pair else []
    return {"status": "deterministic" if proposed else "none",
            "anchor": anchor, "pair_available": bool(pair),
            "proposed": proposed, "weak": [],
            "signal_version": BX_ANCHOR_VERSION}


def bx_materialize_adjust(code, quotes, doc_text: str) -> dict:
    """物化前码调整入口（开关门；off 时**逐字段不变**，返回原 code）。

    返回 ``{"action": "keep"|"suggest"|"replace", "code", "changed",
              "anchor", "proposed", "mode", "version"}``：
      · 开关关 / RULEPROOF_CODE_ATTRIB=off → action=keep、code=入参；
      · suggest → action=suggest、code 不变（只记录建议，调用方不改码）；
      · replace → action=replace、code=确定性唯一候选码（高置信才替换）。
    """
    current = str(code or "")
    res = {"action": "keep", "code": current, "changed": False, "anchor": {},
           "proposed": [], "mode": mode(), "version": BX_ANCHOR_VERSION}
    if not bx_anchor_enabled():
        return res
    attr_mode = mode()
    if attr_mode == MODE_OFF:
        res["mode"] = attr_mode
        return res
    attr = bx_rederive(quotes, doc_text)
    res["anchor"] = attr.get("anchor") or {}
    res["proposed"] = attr.get("proposed") or []
    high = [p for p in res["proposed"] if p.get("kind") in HIGH_CONFIDENCE_KINDS]
    targets = sorted({str(p["rule_code"]) for p in high if str(p.get("rule_code") or "")})
    if not targets:
        return res
    if len(targets) > 1:
        # 多机制同时命中 → 判据族无法唯一定位，不替换（防放宽变 FP 放大器）
        res["action"] = "suggest"
        res["rejected_reason"] = "multi_mechanism"
        return res
    target = targets[0]
    if target == current:
        return res
    if attr_mode == MODE_SUGGEST:
        res["action"] = "suggest"
        return res
    res.update({"action": "replace", "code": target, "changed": True})
    return res


# ============================================================================
# BX C08 三码「进清单也不判」确定性兜底（2026-11-23，BXS1 配套）
# ============================================================================
# 实证（docs/qa/BX缺口分析_20261123.md §2.1 + 本轮真实重跑）：C08-002/003/006 补进
# DT-01 路由后,frozen_items 24/24、三码真实执行，但模型仍按「本文档不含报价表/报价计价」
# 判 **na**（首轮 A 臂 15/19 na）→ 路由收益被 DAG 旁路 customer_rule 通道消失抵消
# （旧臂 C08 16 TP 来自该旁路）。本段对 C08 三码做「同事项对两侧取数 + 算术复算」的
# 确定性判据：模型 na/pass 时，只要事项对满足机制即判 fail（fail-closed：取数不足→不判）。
# 只读文档原文，不读 gold/评分产物；开关 RULEPROOF_BX_ANCHOR 默认开（RD-002 已签署；显式 =0 回滚）。
BX_C08_DET_CODES = ("C08-002", "C08-003", "C08-006")


def _bx_det_c08002(pair_text: str) -> dict | None:
    """C08-002 报价总价与有效分项一致：分项已九折后又二次九折（未批准二次折扣）。

    取数：SW「分项合计X万元…已按九折…未批准第二次折扣」+ TK「再按九折收取Y万元」；
    复算：X×0.9×0.9 vs Y，不相等 → 二次折扣重复抵减（fail）。
    """
    t = _bx_norm(pair_text)
    if not re.search(r"(?:已按九折|已按九折计算)", t):
        return None
    if not re.search(r"(?:未批准第二次折扣|未批准二次折扣|不得重复折扣)", t):
        return None
    m_base = re.search(r"分项合计([0-9]+(?:\.[0-9]+)?)万元", t)
    m_tk = re.search(r"再按九折[^。；]{0,12}?收取([0-9]+(?:\.[0-9]+)?)万元", t)
    if not m_base or not m_tk:
        return None
    try:
        base, got = float(m_base.group(1)), float(m_tk.group(1))
    except Exception:
        return None
    expect = round(base * 0.9 * 0.9, 4)
    if abs(expect - got) < 1e-6:
        return None
    return {"code": "C08-002", "mechanism": "二次折扣重复抵减",
            "detail": "分项合计%.4g万元已九折，TK 再按九折收取%.4g万元；按未批准二次折扣复算应为%.4g万元"
                      "（%.4g×0.9×0.9≠%.4g）" % (base, got, expect, base, got),
            "fragment": m_tk.group(0)}


def _bx_det_c08003(pair_text: str) -> dict | None:
    """C08-003 费率基数及结果符合依据：分段累进基数被打折后复算。

    取数：SW「分段累进：前A万元计p1%，A至B部分计p2%，超B部分计p3%，基数X，仅对费率优惠q%、
    不对基数打折」+ TK「核定为Y万元，已执行九折」；复算：按 X 分段→×(1−q%) vs Y。
    """
    t = _bx_norm(pair_text)
    if not re.search(r"分段累进", t):
        return None
    if not re.search(r"(?:不对基数打折|仅对[^。；]{0,10}?优惠[0-9.]+%|不对基数)", t):
        return None
    m_t1 = re.search(r"前([0-9]+(?:\.[0-9]+)?)万元计([0-9]+(?:\.[0-9]+)?)%", t)
    m_t2 = re.search(r"([0-9]+(?:\.[0-9]+)?)万元至([0-9]+(?:\.[0-9]+)?)万元部分计([0-9]+(?:\.[0-9]+)?)%", t)
    m_t3 = re.search(r"超([0-9]+(?:\.[0-9]+)?)万元部分计([0-9]+(?:\.[0-9]+)?)%", t)
    m_base = re.search(r"基数([0-9]+(?:\.[0-9]+)?)万元", t)
    m_rate = re.search(r"优惠([0-9]+(?:\.[0-9]+)?)%", t)
    m_tk = re.search(r"核定为([0-9]+(?:\.[0-9]+)?)万元", t)
    if not (m_t1 and m_t2 and m_t3 and m_base and m_tk):
        return None
    try:
        x = float(m_base.group(1)); q = float(m_rate.group(1)) if m_rate else 10.0
        got = float(m_tk.group(1))
        t1_hi, t1_p = float(m_t1.group(1)), float(m_t1.group(2))
        t2_lo, t2_hi, t2_p = float(m_t2.group(1)), float(m_t2.group(2)), float(m_t2.group(3))
        t3_lo, t3_p = float(m_t3.group(1)), float(m_t3.group(2))
    except Exception:
        return None
    fee = 0.0
    fee += min(x, t1_hi) * t1_p / 100.0
    if x > t2_lo:
        fee += (min(x, t2_hi) - t2_lo) * t2_p / 100.0
    if x > t3_lo:
        fee += (x - t3_lo) * t3_p / 100.0
    expect = round(fee * (1 - q / 100.0), 6)
    if abs(expect - got) < 1e-5:
        return None
    return {"code": "C08-003", "mechanism": "费率基数被打折",
            "detail": "SW 分段累进基数%.4g万元且仅对费率优惠%.4g%%，TK 核定%.4g万元；"
                      "按不折基数复算应为%.4g万元（%.4g≠%.4g）"
                      % (x, q, got, expect, expect, got),
            "fragment": m_tk.group(0)}


def _bx_det_c08006(pair_text: str) -> dict | None:
    """C08-006 暂列或固定金额符合要求：固定金额被比例下浮。

    取数：SW「X万元代垫行政收费按批准固定金额计入，不参与…下浮」+ TK「代垫行政收费按Y万元计列」；
    复算/对照：X≠Y → 固定金额被下浮（fail）。
    """
    t = _bx_norm(pair_text)
    if not re.search(r"代垫行政收费", t):
        return None
    if not re.search(r"(?:固定金额|不参与[^。；]{0,14}?下浮)", t):
        return None
    m_sw = re.search(r"([0-9]+(?:\.[0-9]+)?)万元代垫行政收费", t)
    m_tk = re.search(r"代垫行政收费按([0-9]+(?:\.[0-9]+)?)万元计列", t)
    if not m_sw or not m_tk:
        return None
    try:
        fixed, got = float(m_sw.group(1)), float(m_tk.group(1))
    except Exception:
        return None
    if abs(fixed - got) < 1e-9:
        return None
    return {"code": "C08-006", "mechanism": "固定金额被下浮",
            "detail": "SW 固定金额%.4g万元不计入下浮，TK 按%.4g万元计列（差%.4g万元）"
                      % (fixed, got, fixed - got),
            "fragment": m_tk.group(0)}


_BX_C08_DETECTORS = {"C08-002": _bx_det_c08002, "C08-003": _bx_det_c08003,
                     "C08-006": _bx_det_c08006}


def bx_detect_code(code, doc_text: str) -> dict | None:
    """C08 三码确定性兜底：在文档的**全部同号事项对**里找该码机制的确定性命中。

    返回 ``{"code","mechanism","detail","quote","item"}`` 或 None（取数不足 → 不判，
    不伪造 fail）。quote 是命中的原文连续切片（TK 侧原文，供证据门禁核验）。
    """
    code = str(code or "")
    fn = _BX_C08_DETECTORS.get(code)
    text = str(doc_text or "")
    if not fn or not text.strip():
        return None
    parsed = bx_doc_items(text)
    if not parsed.get("has_items"):
        return None
    for num, rec in sorted(parsed["items"].items()):
        sw, tk = rec.get("sw") or "", rec.get("tk") or ""
        if not sw or not tk:
            continue
        hit = fn(sw + "\n" + tk)
        if not hit:
            continue
        quote = ""
        frag = str(hit.get("fragment") or "")
        for cand in (tk, sw):
            i = cand.find(frag) if frag else -1
            if i >= 0:
                start = max(0, cand.rfind("。", 0, i) + 1)
                quote = " ".join(cand[start:].split())[:200]
                break
        if not quote:
            quote = " ".join(tk.split())[:160]
        return {"code": code, "mechanism": hit["mechanism"],
                "detail": hit["detail"], "quote": quote, "item": num,
                "version": BX_ANCHOR_VERSION}
    return None
