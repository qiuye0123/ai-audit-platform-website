"""规则版本发布回归闸：历史 confirmed/false_positive 冻结集对比。

- 正例：历史 confirmed finding 的文件，要求新版本仍判“不满足”
- 负例：历史 false_positive finding 的文件，要求新版本不判“不满足”
- baseline：最近一个已发布版本；candidate：当前最新草稿
- 无历史样本时 skipped，不伪造通过
"""
from __future__ import annotations
import json
import logging
from .. import db, repositories as R


def _published_before(rule_id: str, latest_id: str) -> dict:
    rows = R.rule_versions.list("rule_id=?", (rule_id,), order="rowid DESC")
    for v in rows:
        if str(v.get("id") or "") == str(latest_id or ""):
            continue
        if str(v.get("status") or "") == "published":
            return v
    return {}


def _examples(rule_code: str) -> list:
    out = []
    try:
        fs = R.findings.list("rule_id=?", (rule_code,))
    except Exception:
        return out
    seen = set()
    for f in fs:
        status = str(f.get("status") or "")
        if status not in ("confirmed", "false_positive"):
            continue
        cid = str(f.get("case_id") or "")
        if not cid or (cid, status) in seen:
            continue
        seen.add((cid, status))
        try:
            docs = R.cases.documents(cid)
        except Exception:
            docs = []
        doc = next((d for d in docs if d.get("path")), None)
        if not doc:
            continue
        out.append({"case_id": cid, "path": doc.get("path"), "expected_fail": status == "confirmed",
                    "status": status, "finding_id": f.get("id")})
    return out


def _eval(slots: dict, text: str) -> str:
    from ..engine import ruleexec
    try:
        r = ruleexec.judge_rule(dict(slots or {}), text or "", [])
        return str((r or {}).get("state") or "unknown")
    except Exception as e:
        logging.getLogger(__name__).debug("regression eval failed", exc_info=True)
        return "error"


def check(rule_id: str, limit: int = 50) -> dict:
    r = R.rules.get(rule_id) or {}
    if not r:
        return {"checked": False, "reason": "rule not found"}
    latest = R.rules.latest_version(rule_id) or {}
    base = _published_before(rule_id, latest.get("id") or "")
    if not latest or not base:
        return {"checked": False, "reason": "没有上一已发布版本，跳过回归"}
    try:
        cand_slots = json.loads(latest.get("slots_json") or "{}")
        base_slots = json.loads(base.get("slots_json") or "{}")
    except Exception:
        return {"checked": False, "reason": "版本 slots 不可读"}
    examples = _examples(r.get("code") or "")[:limit]
    if not examples:
        return {"checked": False, "reason": "没有历史 confirmed/false_positive 样本"}
    from ..engine import deepparse
    pos = neg = 0
    base_det = cand_det = 0
    base_fire = cand_fire = 0
    details = []
    for ex in examples:
        try:
            text = deepparse.parse_document(ex["path"]).text or ""
        except Exception:
            continue
        b = _eval(base_slots, text) == "不满足"
        c = _eval(cand_slots, text) == "不满足"
        if ex["expected_fail"]:
            pos += 1; base_det += int(b); cand_det += int(c)
        else:
            neg += 1; base_fire += int(b); cand_fire += int(c)
        if b != c:
            details.append({"case_id": ex["case_id"], "status": ex["status"],
                            "baseline_fail": b, "candidate_fail": c})
    blockers = []
    if pos and cand_det < base_det:
        blockers.append(f"正例召回下降：{base_det}/{pos} → {cand_det}/{pos}")
    if neg and cand_fire > base_fire:
        blockers.append(f"负例误报增加：{base_fire}/{neg} → {cand_fire}/{neg}")
    out = {"checked": True, "ok": not blockers, "blockers": blockers,
           "baseline_version": base.get("version"), "candidate_version": latest.get("version"),
           "positives": pos, "negatives": neg,
           "baseline_detected": base_det, "candidate_detected": cand_det,
           "baseline_false_fire": base_fire, "candidate_false_fire": cand_fire,
           "changed": len(details), "details": details[:10]}
    try:
        R.audit_logs.log(actor="system", action="rule.regression",
                         object=rule_id, after=json.dumps(out, ensure_ascii=False)[:1000])
    except Exception:
        logging.getLogger(__name__).debug("regression audit skipped", exc_info=True)
    return out
