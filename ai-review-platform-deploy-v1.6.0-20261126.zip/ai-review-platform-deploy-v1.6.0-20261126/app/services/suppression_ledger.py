# -*- coding: utf-8 -*-
"""抑制台账（T-39）：抑制 ≠ 删除；可抽样审计、可人工恢复；人工漏报对账。

依据 docs/delivery/置信图与分层裁决_20261117.md §4、直连与平台可见性策略_20261117.md §4/§5。

核心约束（DB 触发器 + 服务层双重兜底）：
1. 隐藏项**不得物理删除**（suppression_ledger 触发器禁止 DELETE）；
2. 原始主张 raw_claim 不可变（触发器禁止 UPDATE raw_claim_json/raw_claim_sha256/来源/时间）；
3. critical/高风险不得自动进入抑制台账（服务层 ValueError）；
4. 恢复只改状态并追加 adjudication_event，历史行永远保留；
5. 抑制池抽样审计（sampled / human_result）与人工漏报对账：
     - 命中展示项 → 已报（重复，不恢复）
     - 命中隐藏项 → 恢复 + suppression_error（隐藏项其实是 TP）
     - 命中直连草稿 → 平台漏掉直连真 TP（反馈候选）
     - 未命中 → 全新漏报（反馈候选）
6. 本模块是离线数据底座，不接 server/cli/web/project/accuracy_shadow 主链。

## T-202 唯一主链与唯一入口（2026-11-20）
本模块是双轨主链的**第 4 步：仅台账**——只记录“已裁决抑制/恢复/抽样对账”，
不重新判断可见性（策略由 :mod:`app.services.visibility_policy` 给出、分区由
:mod:`app.services.shadow_pool` 唯一仲裁）。产品代码只能经
``app.services.dual_track_gateway``（``apply_case_visibility`` / ``ledger_*``）调用本模块；
职责边界见 ``docs/qa/双轨唯一入口约束_20261120.md``。
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import uuid

from . import cross_review, visibility_policy

LEDGER_TABLE = "suppression_ledger"
OMISSION_TABLE = "human_omission"

SAMPLE_RESULTS = ("true_positive", "false_positive", "unclear")
OMISSION_STATUSES = ("pending", "matched_visible", "matched_hidden",
                     "matched_direct_draft", "new_missing")
LEDGER_ALLOWED_REASONS = tuple(visibility_policy.HIDDEN_REASON_CODES)
MATCH_MIN_SIMILARITY = 0.6


# --------------------------------------------------------------------------- utils
def _canonical_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha256_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _row(row) -> dict:
    return dict(row) if row is not None else None


def _ledger_key(case_id: str, run_id: str, source: str, comparison_item_id: str,
                direct_item_id: str, platform_finding_id: str, raw_sha: str) -> str:
    return "|".join((str(case_id or ""), str(run_id or ""), str(source or ""),
                     str(comparison_item_id or ""), str(direct_item_id or ""),
                     str(platform_finding_id or ""), raw_sha))


# --------------------------------------------------------------------------- ledger 读
def _ledger_out(row: dict) -> dict:
    out = dict(row)
    for src, dst in (("raw_claim_json", "raw_claim"), ("evidence_json", "evidence"),
                     ("refute_evidence_json", "refute_evidence")):
        try:
            out[dst] = json.loads(out.get(src) or "{}")
        except Exception:
            out[dst] = {}
    out["sampled"] = bool(out.get("sampled"))
    out["immutable"] = bool(out.get("immutable"))
    out["is_suppressed"] = str(out.get("visibility_status") or "") == "suppressed"
    out["is_recovered"] = str(out.get("visibility_status") or "") == "recovered"
    return out


def get(conn, ledger_id: str) -> dict:
    row = conn.execute(f"SELECT * FROM {LEDGER_TABLE} WHERE id=?", (ledger_id,)).fetchone()
    return _ledger_out(row) if row else None


def list_ledger(conn, case_id: str = "", source: str = "", status: str = "",
                sampled: bool | None = None, run_id: str = "") -> list:
    where, params = [], []
    for col, val in (("case_id", case_id), ("source", source),
                     ("visibility_status", status), ("run_id", run_id)):
        if val:
            where.append(f"{col}=?")
            params.append(val)
    if sampled is not None:
        where.append("sampled=?")
        params.append(1 if sampled else 0)
    sql = f"SELECT * FROM {LEDGER_TABLE}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at, rowid"
    return [_ledger_out(r) for r in conn.execute(sql, tuple(params)).fetchall()]


def stats(conn, case_id: str = "") -> dict:
    rows = list_ledger(conn, case_id=case_id)
    suppressed = [r for r in rows if r["visibility_status"] == "suppressed"]
    recovered = [r for r in rows if r["visibility_status"] == "recovered"]
    sampled = [r for r in rows if r["sampled"]]
    tp = [r for r in rows if r.get("human_result") == "true_positive"]
    fp = [r for r in rows if r.get("human_result") == "false_positive"]
    unclear = [r for r in rows if r.get("human_result") == "unclear"]
    return {
        "case_id": case_id, "total": len(rows),
        "suppressed": len(suppressed), "recovered": len(recovered),
        "sampled": len(sampled), "pending_audit": len([r for r in suppressed if not r["sampled"]]),
        "human_true_positive": len(tp), "human_false_positive": len(fp),
        "human_unclear": len(unclear),
        "by_source": {s: len([r for r in rows if r["source"] == s]) for s in ("direct", "platform", "both")},
        "by_reason": _count_by(rows, "suppression_reason"),
        "suppression_text": hidden_summary_text(conn, case_id),
        "deleted": 0,  # 抑制≠删除：本模块不提供物理删除
    }


def _count_by(rows: list, key: str) -> dict:
    out: dict = {}
    for r in rows:
        out[str(r.get(key) or "")] = out.get(str(r.get(key) or ""), 0) + 1
    return out


def hidden_summary_text(conn, case_id: str = "") -> str:
    """报告口径：报告只展示 confirmed，但必须显示“另有 N 条已抑制，抽样审计中”。"""
    n = len([r for r in list_ledger(conn, case_id=case_id, status="suppressed")
             if not r["sampled"]])
    return f"另有 {n} 条已抑制，抽样审计中"


# --------------------------------------------------------------------------- 进台账
def suppress(conn, *, case_id: str, source: str, raw_claim: dict, reason_code: str,
             risk_level: str = "medium", evidence: dict | None = None,
             refute_evidence: dict | None = None, confidence=None,
             comparison_item_id: str = "", direct_item_id: str = "",
             platform_finding_id: str = "", rule_code: str = "", object_id: str = "",
             subject: str = "", issue_type: str = "", run_id: str = "",
             tenant_id: str = "", workspace_id: str = "",
             reason_note: str = "", actor: str = "system:visibility_policy") -> dict:
    """隐藏项写入不可变抑制台账（不是删除）。重复抑制幂等返回原行。"""
    if source not in ("direct", "platform", "both"):
        raise ValueError(f"非法抑制来源：{source}")
    if reason_code not in LEDGER_ALLOWED_REASONS:
        raise ValueError(f"原因码 {reason_code} 不允许进入抑制台账；可用："
                         f"{', '.join(LEDGER_ALLOWED_REASONS)}")
    if risk_level not in visibility_policy.RISK_LEVELS:
        raise ValueError(f"非法风险等级：{risk_level}")
    if risk_level in ("critical", "high"):
        raise ValueError("critical/高风险不得自动进入抑制台账（visibility_policy 应展示为冲突/待核验）")
    if not isinstance(raw_claim, dict) or not raw_claim:
        raise ValueError("raw_claim 必须是非空 dict（原始主张不可变留档）")
    if not str(case_id or "").strip():
        raise ValueError("case_id 不能为空")
    raw_json = _canonical_json(raw_claim)
    raw_sha = _sha256_text(raw_json)
    key = _ledger_key(case_id, run_id, source, comparison_item_id, direct_item_id,
                      platform_finding_id, raw_sha)
    hit = conn.execute(f"SELECT * FROM {LEDGER_TABLE} WHERE ledger_key=?", (key,)).fetchone()
    if hit:
        out = _ledger_out(hit)
        return {"created": False, "ledger": out, "ledger_id": out["id"],
                "already_recovered": out["visibility_status"] == "recovered"}
    ledger_id = "sl_" + uuid.uuid4().hex[:16]
    stamp = _now_iso()
    values = (
        ledger_id, key, case_id, run_id, tenant_id, workspace_id, source,
        comparison_item_id, direct_item_id, platform_finding_id, rule_code, object_id,
        subject, issue_type, raw_json, raw_sha,
        _canonical_json(evidence or {}), _canonical_json(refute_evidence or {}),
        confidence, risk_level, reason_code, reason_note, "suppressed", 0,
        "",   # sampled_at
        "",   # human_result
        "",   # human_actor
        "",   # human_reason
        "",   # human_at
        "",   # recovered_finding_ref
        "",   # recovered_at
        "",   # recovered_by
        stamp,
    )
    conn.execute(
        f"INSERT INTO {LEDGER_TABLE}(id, ledger_key, case_id, run_id, tenant_id, workspace_id, "
        "source, comparison_item_id, direct_item_id, platform_finding_id, rule_code, object_id, "
        "subject, issue_type, raw_claim_json, raw_claim_sha256, evidence_json, "
        "refute_evidence_json, confidence, risk_level, suppression_reason, reason_note, "
        "visibility_status, sampled, sampled_at, human_result, human_actor, human_reason, "
        "human_at, recovered_finding_ref, recovered_at, recovered_by, created_at, immutable) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
        values)
    event = cross_review.append_event(
        conn, "suppress_finding", case_id=case_id, run_id=run_id,
        comparison_item_id=comparison_item_id, ledger_id=ledger_id,
        actor=actor, before_status="visible", after_status="suppressed",
        reason_code=reason_code, reason=reason_note or "满足隐藏条件，进入抑制台账（非删除）",
        evidence={"raw_claim_sha256": raw_sha, "risk_level": risk_level,
                  "refute_evidence": refute_evidence or {}})
    return {"created": True, "ledger": get(conn, ledger_id), "ledger_id": ledger_id,
            "event": event, "raw_claim_sha256": raw_sha}


def _raw_claim_from_descriptor(descriptor: dict, side: str, decision: dict) -> dict:
    desc = descriptor or {}
    return {
        "source": side,
        "id": desc.get("id") or "",
        "case_id": desc.get("case_id") or "",
        "rule_code": desc.get("code") or desc.get("rule_code") or "",
        "quote": desc.get("quote") or "",
        "quote_check": desc.get("quote_check") or {},
        "quote_match_status": desc.get("quote_match_status") or "",
        "weak_locator": bool(desc.get("weak_locator")),
        "issue": desc.get("issue") or desc.get("summary") or "",
        "reason": desc.get("reason") or desc.get("detail") or "",
        "subject": desc.get("subject") or "",
        "issue_type": desc.get("issue_type") or "",
        "confidence": desc.get("confidence"),
        "visibility_status": decision.get("status"),
        "reason_code": decision.get("reason_code"),
        "risk_level": decision.get("risk_level"),
        "quote_reuse": desc.get("quote_reuse") or {},
        "quote_relevance": desc.get("quote_relevance") or {},
        "not_gold": True,
    }


def suppress_decision(conn, *, case_id: str, side: str, decision: dict, descriptor: dict,
                      comparison_item_id: str = "", run_id: str = "",
                      tenant_id: str = "", workspace_id: str = "",
                      actor: str = "system:visibility_policy") -> dict:
    """把 visibility_policy 的隐藏决策落进抑制台账（只对 ledger=True 的决策）。"""
    if not decision or not decision.get("ledger"):
        raise ValueError("该决策不是抑制决策（ledger=False），不应进入抑制台账")
    if side not in ("direct", "platform"):
        raise ValueError(f"非法来源侧：{side}")
    desc = descriptor or {}
    raw_claim = _raw_claim_from_descriptor(desc, side, decision)
    refute = (decision.get("refute") or {}).get("evidence") or {}
    return suppress(
        conn, case_id=case_id, source=side, raw_claim=raw_claim,
        reason_code=str(decision.get("reason_code") or ""),
        risk_level=str(decision.get("risk_level") or "medium"),
        evidence=decision.get("evidence") or {}, refute_evidence=refute,
        confidence=decision.get("confidence"),
        comparison_item_id=comparison_item_id,
        direct_item_id=str(desc.get("id") or "") if side == "direct" else "",
        platform_finding_id=str(desc.get("id") or "") if side == "platform" else "",
        rule_code=str(desc.get("code") or desc.get("rule_code") or ""),
        object_id=str(desc.get("object_id") or ""),
        subject=str(desc.get("subject") or ""),
        issue_type=str(desc.get("issue_type") or ""),
        run_id=run_id, tenant_id=tenant_id, workspace_id=workspace_id,
        reason_note=str(decision.get("reason") or ""), actor=actor)


# --------------------------------------------------------------------------- 抽样 / 恢复
def mark_sampled(conn, ledger_id: str, *, actor: str = "", note: str = "") -> dict:
    """抑制池抽样审计：标记已抽样（不改变抑制状态）。"""
    row = get(conn, ledger_id)
    if not row:
        raise KeyError(f"抑制台账不存在：{ledger_id}")
    if not row["sampled"]:
        conn.execute(f"UPDATE {LEDGER_TABLE} SET sampled=1, sampled_at=? WHERE id=?",
                     (_now_iso(), ledger_id))
        cross_review.append_event(
            conn, "sample_suppressed", case_id=row["case_id"], run_id=row["run_id"],
            comparison_item_id=row["comparison_item_id"], ledger_id=ledger_id,
            actor=actor, before_status="unsampled", after_status="sampled",
            reason_code="sample_audit", reason=note)
    return get(conn, ledger_id)


def record_human_result(conn, ledger_id: str, result: str, *, actor: str,
                        reason: str = "") -> dict:
    """记录抑制项人工审计结果（true_positive/false_positive/unclear），不自动恢复。"""
    if result not in SAMPLE_RESULTS:
        raise ValueError(f"非法抽样结果：{result}（可选：{', '.join(SAMPLE_RESULTS)}）")
    if not str(actor or "").strip():
        raise ValueError("必须记录 actor")
    row = get(conn, ledger_id)
    if not row:
        raise KeyError(f"抑制台账不存在：{ledger_id}")
    conn.execute(f"UPDATE {LEDGER_TABLE} SET human_result=?, human_actor=?, human_reason=?, "
                 "human_at=? WHERE id=?", (result, actor, reason, _now_iso(), ledger_id))
    cross_review.append_event(
        conn, "suppression_human_result", case_id=row["case_id"], run_id=row["run_id"],
        comparison_item_id=row["comparison_item_id"], ledger_id=ledger_id,
        actor=actor, before_status=row.get("human_result") or "", after_status=result,
        reason_code="sample_audit", reason=reason)
    return get(conn, ledger_id)


def recover(conn, ledger_id: str, *, actor: str, reason: str = "",
            recovered_finding_ref: str = "", sync_visibility: bool = True) -> dict:
    """人工从抑制池恢复为可见问题（抑制≠删除：原行保留，只改状态 + 追加事件）。

    W-08：恢复必须**同步 comparison_item.visibility=visible**（旧实现只 UPDATE 台账，
    记录仍非 visible）；并写 adjudication_event；重复恢复幂等（不重复记事件，
    但会把遗留的非 visible 状态重新同步为 visible）。
    """
    if not str(actor or "").strip():
        raise ValueError("恢复必须记录 actor（人工动作）")
    row = get(conn, ledger_id)
    if not row:
        raise KeyError(f"抑制台账不存在：{ledger_id}")

    def _sync_comparison_visible(before_status: str) -> dict:
        out = {"synced": False, "comparison_item_id": row.get("comparison_item_id") or "",
               "before_visibility": "", "after_visibility": "", "reason_code": ""}
        if not sync_visibility or not row.get("comparison_item_id"):
            return out
        try:
            item = cross_review.get_comparison_item(conn, row["comparison_item_id"])
        except Exception:  # noqa: BLE001 - 台账可能来自无 comparison_item 的离线路径
            item = None
        if not item:
            return out
        out["before_visibility"] = str(item.get("visibility") or "")
        if out["before_visibility"] == "visible":
            return out
        cross_review.set_visibility(
            conn, row["comparison_item_id"], "visible", "recovered_from_suppressed",
            {"recovered_from_ledger": ledger_id, "before_visibility": out["before_visibility"],
             "synced_by": "suppression_ledger.recover", "reason": reason})
        out["synced"] = True
        out["after_visibility"] = "visible"
        return out

    if row["visibility_status"] == "recovered":
        sync = _sync_comparison_visible("recovered")
        return {"recovered": False, "already_recovered": True, "ledger": row,
                "event": None, "visibility_synced": sync["synced"],
                "comparison_visibility": sync}
    stamp = _now_iso()
    # W-10/W-11：recover 不默认 TP（旧实现 human_result 默认 "true_positive" 是自动记 TP）；
    # 保持已有值不变，空值就是“待人工确认”，只能由 record_human_result（人工动作）写。
    human_result = str(row.get("human_result") or "")
    human_actor = str(row.get("human_actor") or "") or (actor if human_result else "")
    human_reason = str(row.get("human_reason") or "") or (reason if human_result else "")
    human_at = str(row.get("human_at") or "") or (stamp if human_result else "")
    conn.execute(
        f"UPDATE {LEDGER_TABLE} SET visibility_status='recovered', recovered_at=?, "
        "recovered_by=?, recovered_finding_ref=?, human_result=?, human_actor=?, "
        "human_reason=?, human_at=? WHERE id=?",
        (stamp, actor, recovered_finding_ref, human_result, human_actor, human_reason,
         human_at, ledger_id))
    sync = _sync_comparison_visible("suppressed")
    event = cross_review.append_event(
        conn, "recover_suppressed", case_id=row["case_id"], run_id=row["run_id"],
        comparison_item_id=row["comparison_item_id"], ledger_id=ledger_id,
        actor=actor, before_status="suppressed", after_status="recovered",
        reason_code="human_recover", reason=reason or "人工从抑制池恢复为可见问题",
        evidence={"recovered_finding_ref": recovered_finding_ref,
                  "raw_claim_sha256": row.get("raw_claim_sha256"),
                  "comparison_visibility_synced": sync["synced"],
                  "comparison_visibility_before": sync["before_visibility"],
                  "comparison_visibility_after": sync["after_visibility"]})
    return {"recovered": True, "already_recovered": False, "ledger": get(conn, ledger_id),
            "event": event, "visibility_synced": sync["synced"],
            "comparison_visibility": sync,
            "human_result_pending": not bool(human_result),
            "human_result": human_result,
            "note": "recover 不默认 TP：human_result 为空表示待人工确认"}


# --------------------------------------------------------------------------- 可见性应用
def _with_quote_reuse(view: dict, reuse: dict, context: dict | None) -> dict:
    """把 case 级“同引文跨码复用”标记（W-19）注入评估上下文（不覆盖调用方显式上下文）。"""
    ctx: dict = {}
    for side in ("direct", "platform"):
        merged = dict((reuse or {}).get(side) or {})
        merged.update((context or {}).get(side) or {})
        if merged:
            ctx[side] = merged
    return ctx


def apply_comparison_visibility(conn, comparison_item_id: str, *,
                                policy: visibility_policy.PolicyConfig | None = None,
                                calibration_map: dict | None = None,
                                context: dict | None = None, doc_text: str = "",
                                tenant_id: str = "", workspace_id: str = "",
                                quote_reuse: dict | None = None,
                                actor: str = "system:visibility_policy") -> dict:
    """对一条 comparison_item 计算可见性：写 visibility + 隐藏项自动进抑制台账。

    context 用于注入真实范围门禁/确定性反证等（见 visibility_policy.evaluate_comparison）。
    quote_reuse：case 级同引文跨码复用标记（W-19）；未给则按 case 现场聚合检测。
    返回 {"visibility", "decisions", "ledger_ids", ...}；不写任何人工结论。
    """
    view = cross_review.item_view(conn, comparison_item_id, doc_text)
    if not view:
        raise KeyError(f"comparison_item 不存在：{comparison_item_id}")
    item = view["comparison"]
    if quote_reuse is None:
        try:
            quote_reuse = cross_review.case_quote_reuse(
                conn, item.get("case_id") or "", doc_text)
        except Exception:  # noqa: BLE001 - 持久态检测失败不得阻断可见性应用
            quote_reuse = {}
    reuse_ctx = _with_quote_reuse(view, (quote_reuse or {}).get(comparison_item_id) or {},
                                  context)
    record = {"case_id": item.get("case_id") or "", "bucket": item.get("bucket") or "",
              "direct": view.get("direct"), "platform": view.get("platform")}
    decisions = visibility_policy.evaluate_comparison(
        record, policy=policy, calibration_map=calibration_map, context=reuse_ctx)
    cross_review.set_visibility(conn, comparison_item_id, decisions["visibility"],
                                ",".join(decisions["reason_codes"] or []), decisions)
    ledger_ids, created = [], 0
    for side in ("direct", "platform"):
        dec = decisions.get(side)
        desc = view.get(side)
        if not dec or not dec.get("ledger") or not desc:
            continue
        out = suppress_decision(conn, case_id=record["case_id"], side=side, decision=dec,
                                descriptor=desc,
                                comparison_item_id=comparison_item_id,
                                run_id=item.get("run_id") or "",
                                tenant_id=tenant_id or (item.get("tenant_id") or ""),
                                workspace_id=workspace_id or (item.get("workspace_id") or ""),
                                actor=actor)
        ledger_ids.append(out["ledger_id"])
        created += 1 if out.get("created") else 0
    return {"comparison_item_id": comparison_item_id,
            "case_id": record["case_id"], "bucket": record["bucket"],
            "visibility": decisions["visibility"],
            "reason_codes": decisions["reason_codes"],
            "quote_reuse_conflict": decisions.get("quote_reuse_conflict"),
            "weak_locator": decisions.get("weak_locator"),
            "decisions": decisions, "ledger_ids": ledger_ids,
            "ledger_created": created, "not_gold": True}


def apply_case_visibility(conn, case_id: str, *, doc_text: str = "",
                          policy: visibility_policy.PolicyConfig | None = None,
                          calibration_map: dict | None = None,
                          context_map: dict | None = None,
                          only_unset: bool = True, **kwargs) -> dict:
    """对一个 case 的全部 comparison_item 应用可见性策略（离线批量入口）。

    W-19：先对整个 case 做一次同引文跨码检测，再逐条应用（避免单条看不到全案）。
    """
    items = cross_review.list_comparison_items(conn, case_id=case_id)
    try:
        case_reuse = cross_review.case_quote_reuse(conn, case_id, doc_text)
    except Exception:  # noqa: BLE001
        case_reuse = {}
    results = []
    for item in items:
        if only_unset and item.get("visibility"):
            continue
        ctx = (context_map or {}).get(item["id"])
        results.append(apply_comparison_visibility(
            conn, item["id"], policy=policy, calibration_map=calibration_map,
            context=ctx, doc_text=doc_text, quote_reuse=case_reuse, **kwargs))
    visible = len([r for r in results if r["visibility"] == "visible"])
    return {"case_id": case_id, "applied": len(results), "visible": visible,
            "suppressed": len([r for r in results if r["visibility"] == "suppressed"]),
            "duplicate": len([r for r in results if r["visibility"] == "duplicate"]),
            "hidden": len([r for r in results if r["visibility"] == "hidden"]),
            "rejected_scope": len([r for r in results if r["visibility"] == "rejected_scope"]),
            "quote_reuse_conflict_items": len([r for r in results
                                               if r.get("quote_reuse_conflict")]),
            "results": results, "not_gold": True}


# --------------------------------------------------------------------------- 人工漏报对账
# V3.2 W-10/W-11：全局最佳匹配（不顺序贪心）+ 相似度 & 坐标双门槛 +
# 人工确认后才写 human_result + 对账池只取 visible candidates。
MATCH_MIN_SPAN_OVERLAP = 0.5      # 坐标门槛：span 重叠比（较短区间）
MATCH_MAX_SPAN_GAP = 80           # 坐标门槛：无重叠但邻近字符数
MATCH_MAX_LINE_DISTANCE = 2       # 坐标门槛：无 offset 时行号邻近
RECONCILE_TIERS = ("visible", "hidden", "direct_draft")
_TIER_RANK = {t: i for i, t in enumerate(RECONCILE_TIERS)}


def _omission_out(row: dict) -> dict:
    out = dict(row)
    for src, dst in (("locator_json", "locator"), ("feedback_candidate_json",
                                                   "feedback_candidate")):
        try:
            out[dst] = json.loads(out.get(src) or "{}")
        except Exception:
            out[dst] = {}
    return out


def get_omission(conn, omission_id: str) -> dict:
    row = conn.execute(f"SELECT * FROM {OMISSION_TABLE} WHERE id=?", (omission_id,)).fetchone()
    return _omission_out(row) if row else None


def list_omissions(conn, case_id: str = "", status: str = "") -> list:
    where, params = [], []
    if case_id:
        where.append("case_id=?")
        params.append(case_id)
    if status:
        where.append("status=?")
        params.append(status)
    sql = f"SELECT * FROM {OMISSION_TABLE}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at, rowid"
    return [_omission_out(r) for r in conn.execute(sql, tuple(params)).fetchall()]


def record_omission(conn, *, case_id: str, quote: str, issue: str = "",
                    rule_hint: str = "", object_id: str = "", subject: str = "",
                    actor: str = "", locator: dict | None = None, run_id: str = "",
                    tenant_id: str = "", workspace_id: str = "",
                    note: str = "") -> dict:
    """人工独立填写“系统漏报”的问题（人工看不到隐藏项，避免锚定）。"""
    if not str(case_id or "").strip():
        raise ValueError("case_id 不能为空")
    if not str(quote or "").strip() and not str(issue or "").strip():
        raise ValueError("漏报必须至少给 quote 或 issue 描述")
    if not str(actor or "").strip():
        raise ValueError("漏报登记必须记录 actor")
    omission_id = "ho_" + uuid.uuid4().hex[:16]
    stamp = _now_iso()
    conn.execute(
        f"INSERT INTO {OMISSION_TABLE}(id, case_id, run_id, tenant_id, workspace_id, actor, "
        "quote, issue, rule_hint, object_id, subject, locator_json, status, match_type, "
        "matched_ref, recovered_ledger_id, feedback_candidate_json, note, created_at, "
        "reconciled_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (omission_id, case_id, run_id, tenant_id, workspace_id, actor, quote, issue,
         rule_hint, object_id, subject, _canonical_json(locator or {}), "pending", "", "",
         "", "{}", note, stamp, ""))
    cross_review.append_event(
        conn, "record_omission", case_id=case_id, run_id=run_id, omission_id=omission_id,
        actor=actor, after_status="pending", reason_code="human_omission_recorded",
        reason=note or "人工登记系统漏报")
    return get_omission(conn, omission_id)


def _descriptor_text(desc: dict) -> str:
    if not desc:
        return ""
    return "\n".join(str(x) for x in (
        desc.get("quote"), desc.get("issue") or desc.get("summary"),
        desc.get("reason") or desc.get("detail"), desc.get("title")) if str(x or "").strip())


def _ledger_claim_text(row: dict) -> str:
    claim = row.get("raw_claim") or {}
    return _descriptor_text(claim)


def _descriptor_span(desc: dict):
    """描述符坐标（offset/length）；无坐标返回 None。"""
    desc = desc or {}
    qc = desc.get("quote_check") or {}
    off = qc.get("offset") if qc.get("offset") is not None else desc.get("offset")
    if off is None:
        return None
    length = qc.get("length") if qc.get("length") is not None else None
    if length is None:
        length = desc.get("length") if desc.get("length") is not None else \
            len(str(desc.get("quote") or ""))
    try:
        return (int(off), int(off) + int(length))
    except (TypeError, ValueError):
        return None


def _is_visible_comparison_item(item: dict) -> bool:
    """W-11：对账池只取 visible；rejected_scope/duplicate/suppressed 一律不进。"""
    vis = str((item or {}).get("visibility") or "").strip()
    detail = (item or {}).get("visibility_detail") or {}
    record = detail.get("record") if isinstance(detail, dict) else None
    if isinstance(record, dict) and str(record.get("status") or "").startswith("rejected"):
        return False
    if vis == "visible":
        return True
    if vis in ("suppressed", "duplicate", "rejected_scope", "hidden"):
        return False
    return vis == ""   # 未应用可见性的历史行视作可见（Phase 1 无隐藏态）


def _candidate_from_view(view: dict, item: dict, tier: str) -> dict:
    """comparison_item 并排视图 → 对账候选（带 span/line/quote/code 坐标证据）。"""
    sides = [s for s in (view.get("direct"), view.get("platform")) if s]
    texts = [_descriptor_text(s) for s in sides]
    quote = next((str(s.get("quote") or "") for s in sides
                  if str(s.get("quote") or "").strip()), "")
    span = next((_descriptor_span(s) for s in sides if _descriptor_span(s)), None)
    line = next((s.get("line") for s in sides if s.get("line") is not None), None)
    codes = [str(s.get("code") or "") for s in sides if str(s.get("code") or "").strip()]
    return {"ref": item.get("id") or "", "tier": tier,
            "bucket": item.get("bucket") or "",
            "text": "\n".join(t for t in texts if t),
            "quote": quote, "span": span, "line": line,
            "code": codes[0] if codes else "",
            "codes": codes}


def _hidden_candidate(row: dict) -> dict:
    claim = row.get("raw_claim") or {}
    qc = claim.get("quote_check") or {}
    span = _descriptor_span({"quote_check": qc, "quote": claim.get("quote") or "",
                             "offset": claim.get("offset")})
    return {"ref": row.get("id") or "", "tier": "hidden",
            "bucket": "suppressed",
            "text": _ledger_claim_text(row),
            "quote": str(claim.get("quote") or ""),
            "span": span, "line": qc.get("line"),
            "code": str(claim.get("rule_code") or claim.get("code") or ""),
            "source": row.get("source") or ""}


def _direct_candidate(item: dict) -> dict:
    from . import direct_draft
    desc = {"quote": item.get("quote") or "", "issue": item.get("issue") or "",
            "reason": item.get("reason") or ""}
    qc = item.get("quote_check") or {}
    if isinstance(qc, str):
        try:
            qc = json.loads(qc or "{}")
        except Exception:  # noqa: BLE001
            qc = {}
    span = _descriptor_span({"quote_check": qc, "quote": item.get("quote") or ""})
    return {"ref": item.get("id") or "", "tier": "direct_draft",
            "bucket": "direct_draft",
            "text": _descriptor_text(desc),
            "quote": str(item.get("quote") or ""),
            "span": span, "line": qc.get("line") or item.get("line"),
            "code": str(item.get("rule_code") or item.get("code") or ""),
            "quote_status": item.get("quote_status") or qc.get("status") or "",
            "_direct_draft": direct_draft.__name__}


def reconcile_pool(conn, case_id: str, doc_text: str = "") -> dict:
    """对账候选池（W-11）：visible candidates + 隐藏台账 + 直连草稿，三层分开。

    - visible 层只取 visibility == visible（rejected_scope/duplicate/suppressed 不污染）；
    - hidden 层只取 suppression_ledger status=suppressed 的行（抑制≠删除，可恢复）；
    - direct_draft 层是人工侧草稿（平台是否漏掉直连真 TP）。
    """
    visible = []
    for item in cross_review.list_comparison_items(conn, case_id=case_id):
        if not _is_visible_comparison_item(item):
            continue
        try:
            view = cross_review.item_view(conn, item["id"], doc_text)
        except Exception:  # noqa: BLE001
            view = {}
        if not view:
            continue
        cand = _candidate_from_view(view, item, "visible")
        if cand["text"]:
            visible.append(cand)
    hidden = [_hidden_candidate(r) for r in
              list_ledger(conn, case_id=case_id, status="suppressed")
              if _ledger_claim_text(r)]
    from . import direct_draft
    direct_items = [_direct_candidate(it) for it in
                    direct_draft.list_items(conn, case_id=case_id)]
    direct_items = [c for c in direct_items if c["text"]]
    return {"visible": visible, "hidden": hidden, "direct_draft": direct_items}


# ---------------------------------------------------------------------------
# T-53 对账池“同一问题实例”去重（1:N / N:1）
# 目的：同一个人工漏报对应的问题，可能被多轨重复报告（同一实例、不同规则码），或同时
#   出现在 visible/hidden/direct_draft 三层；对账时应把**同一问题实例**合并为一个复核
#   候选（保留全部 refs = 1:N），而不是让同一实例的重复报告互相竞争/占满候选槽。
# 边界：只做去重，不判真/判假、不改候选内容、不合并不同问题实例；码族来自
#   ``cross_review.codes_equivalent``（可解释码别名，粗/细粒度或近义规则码）。
# ---------------------------------------------------------------------------
INSTANCE_DEDUP_MIN_OVERLAP = MATCH_MIN_SPAN_OVERLAP   # 同一实例坐标门槛（只此一处）
INSTANCE_DEDUP_MAX_GAP = MATCH_MAX_SPAN_GAP


def _codes_compatible(codes_a: list, codes_b: list) -> dict:
    """两侧码集是否同族兼容。任一对 exact/同族 → compatible；两侧都有码但无同族 → 不兼容。"""
    ca = [str(c or "").strip() for c in (codes_a or []) if str(c or "").strip()]
    cb = [str(c or "").strip() for c in (codes_b or []) if str(c or "").strip()]
    if not ca or not cb:
        return {"compatible": True, "relation": "code_missing",
                "reason": "至少一侧没有规则码，码不阻断实例去重"}
    for x in ca:
        for y in cb:
            eq = cross_review.codes_equivalent(x, y)
            if eq.get("equivalent"):
                return {"compatible": True, "relation": eq["relation"],
                        "codes": [x, y], "family": eq.get("family") or "",
                        "family_label": eq.get("family_label") or "",
                        "reason": eq.get("rationale") or ""}
    return {"compatible": False, "relation": "different_family",
            "codes": [ca, cb],
            "reason": "两侧规则码不同族（可能是不同问题）→ 不合并"}


def _span_of(cand: dict):
    span = (cand or {}).get("span")
    if isinstance(span, (list, tuple)) and len(span) == 2 and span[0] is not None:
        try:
            return (int(span[0]), int(span[1]))
        except (TypeError, ValueError):
            return None
    return None


def _instance_same(cand_a: dict, cand_b: dict) -> dict:
    """两候选是否同一问题实例（仅去重用）；不判真值。

    同一性主键 = 坐标（与 V3.2 Alt-A 一致）：
      1) span 重叠比 >= 0.5 → 同一实例（不同规则码只记“同实例异码”，不阻断合并）；
      2) 无重叠时保守：span 邻近 <= 80 且码 exact/同族 → 同一实例；
         或逐字引文（norm 后 >=4 字相同）且码 exact/同族 → 同一实例；
         无坐标时仅逐字引文同一性可作依据。
    不同问题保护：无坐标重叠时，码不同族**不合并**（避免仅凭相似文本合并不同问题）；
    有坐标重叠时按项目既有“坐标主键”身份规则合并，码分歧进 merged_codes 与 basis 留痕。
    """
    a, b = cand_a or {}, cand_b or {}
    if not (a.get("text") and b.get("text")):
        return {"same": False, "basis": "missing_text"}
    codes = _codes_compatible(a.get("codes") or [a.get("code")], b.get("codes") or [b.get("code")])
    sa, sb = _span_of(a), _span_of(b)
    if sa and sb:
        inter = min(sa[1], sb[1]) - max(sa[0], sb[0])
        if inter > 0:
            ratio = inter / max(1, min(sa[1] - sa[0], sb[1] - sb[0]))
            if ratio >= INSTANCE_DEDUP_MIN_OVERLAP:
                return {"same": True, "basis": "span_overlap",
                        "detail": {"ratio": round(ratio, 4), "code": codes}}
            return {"same": False, "basis": "span_overlap_below_threshold",
                    "detail": {"ratio": round(ratio, 4)}}
        gap = max(0, max(sa[0], sb[0]) - min(sa[1], sb[1]))
        if gap <= INSTANCE_DEDUP_MAX_GAP and codes.get("relation") in ("exact", "same_family"):
            return {"same": True, "basis": "span_near_same_code",
                    "detail": {"gap": gap, "code": codes}}
        return {"same": False, "basis": "span_far", "detail": {"gap": gap}}
    # 无坐标：逐字引文同一性（归一化后完全相同）且码不冲突
    na = cross_review.norm(str(a.get("quote") or ""))
    nb = cross_review.norm(str(b.get("quote") or ""))
    if na and na == nb and len(na) >= 4 and codes.get("relation") in (
            "exact", "same_family", "code_missing"):
        return {"same": True, "basis": "verbatim_quote_identity",
                "detail": {"code": codes}}
    return {"same": False, "basis": "no_coordinate_evidence"}


def dedupe_pool_instances(pool: dict) -> dict:
    """对账池按“同一问题实例”去重（1:N 合并）。

    输入 ``reconcile_pool`` 结果的 {visible,hidden,direct_draft}; 输出:
      - ``pool``: 同结构但每层只保留代表候选（代表项带 merged_refs/merged_tiers/
        merged_codes/duplicate_count/instance_key）;
      - ``groups``: 每个实例组的审计明细（refs/tiers/codes/basis），逐条可复核;
      - ``stats``: 合并前后计数与码族依据计数。
    仅去重，不改候选内容、不判真假、不丢弃任何 ref（全部进 merged_refs）。
    """
    tiers = list(RECONCILE_TIERS)
    flat = []
    for tier in tiers:
        for cand in (pool or {}).get(tier) or []:
            flat.append({"tier": tier, "cand": cand})
    groups: list = []
    assigned = [False] * len(flat)
    for i, item in enumerate(flat):
        if assigned[i]:
            continue
        group = [i]
        assigned[i] = True
        changed = True
        while changed:   # 传递闭包（A~B, B~C → A,B,C 同组）
            changed = False
            for j, other in enumerate(flat):
                if assigned[j]:
                    continue
                if any(_instance_same(flat[k]["cand"], other["cand"]).get("same")
                       for k in group):
                    group.append(j)
                    assigned[j] = True
                    changed = True
        members = [flat[k] for k in group]
        # 代表：tier 优先级（visible > hidden > direct_draft），再按 ref 稳定排序
        members.sort(key=lambda m: (_TIER_RANK.get(m["tier"], 9),
                                    str(m["cand"].get("ref") or "")))
        rep = dict(members[0]["cand"])
        merged_refs = [str(m["cand"].get("ref") or "") for m in members]
        merged_tiers = sorted({m["tier"] for m in members},
                              key=lambda t: _TIER_RANK.get(t, 9))
        merged_codes = sorted({str(c or "") for m in members
                               for c in (m["cand"].get("codes") or [m["cand"].get("code")])
                               if str(c or "")})
        bases = []
        for a in range(len(members)):
            for b in range(a + 1, len(members)):
                rel = _instance_same(members[a]["cand"], members[b]["cand"])
                if rel.get("same"):
                    bases.append({"refs": [members[a]["cand"].get("ref"),
                                           members[b]["cand"].get("ref")],
                                  "basis": rel.get("basis"),
                                  "detail": rel.get("detail")})
        span = _span_of(rep)
        rep.update({"merged_refs": merged_refs, "merged_tiers": merged_tiers,
                    "merged_codes": merged_codes,
                    "duplicate_count": len(members) - 1,
                    "instance_key": "%s:%s:%s" % (
                        rep.get("tier") or "", span if span else "quote",
                        ",".join(merged_codes)),
                    "dedup_basis": bases})
        groups.append({"representative_ref": rep.get("ref"),
                       "representative_tier": members[0]["tier"],
                       "refs": merged_refs, "tiers": merged_tiers,
                       "codes": merged_codes, "size": len(members),
                       "span": span, "basis": bases})
    # 代表项按 tier 归属放回；refs 保留全部（1:N）
    out_pool = {t: [] for t in tiers}
    rep_by_ref = {}
    for g in groups:
        for m in flat:
            if str(m["cand"].get("ref") or "") == g["representative_ref"] \
                    and m["tier"] == g["representative_tier"]:
                rep_by_ref[g["representative_ref"]] = m["cand"]
    for tier in tiers:
        for g in groups:
            if g["representative_tier"] != tier:
                continue
            rep = rep_by_ref.get(g["representative_ref"])
            if rep is None:
                continue
            rep = dict(rep)
            rep["merged_refs"] = list(g["refs"])
            rep["merged_tiers"] = list(g["tiers"])
            rep["merged_codes"] = list(g["codes"])
            rep["duplicate_count"] = g["size"] - 1
            rep["instance_key"] = "%s:%s:%s" % (
                tier, g["span"], ",".join(g["codes"]))
            rep["dedup_basis"] = list(g["basis"])
            out_pool[tier].append(rep)
    before = sum(len((pool or {}).get(t) or []) for t in tiers)
    after = sum(len(v) for v in out_pool.values())
    return {
        "pool": out_pool,
        "groups": groups,
        "stats": {
            "before": before, "after": after,
            "merged_groups": sum(1 for g in groups if g["size"] > 1),
            "duplicates_removed": before - after,
            "by_basis": _count_values([b.get("basis") for g in groups for b in g["basis"]]),
            "by_tier": {t: {"before": len((pool or {}).get(t) or []),
                            "after": len(out_pool[t])} for t in tiers},
        },
        "policy": {"version": "instance-dedup/t53-v1",
                   "span_overlap_min": INSTANCE_DEDUP_MIN_OVERLAP,
                   "span_gap_max": INSTANCE_DEDUP_MAX_GAP,
                   "code_family": cross_review._code_family_version()["version"],
                   "note": "只合并同一问题实例的重复报告；不判真/假、不改候选内容"},
    }


def _count_values(values: list) -> dict:
    out: dict = {}
    for v in values:
        out[str(v)] = out.get(str(v), 0) + 1
    return out


def _coordinate_evidence(omission: dict, candidate: dict, doc_text: str = ""):
    """坐标门槛：span 重叠 / span 邻近 / 行号邻近 / 逐字引文同一性。None = 无坐标证据。"""
    omission = omission or {}
    o_quote = str(omission.get("quote") or "")
    locator = omission.get("locator") or {}
    o_span = None
    o_line = locator.get("line") if locator.get("line") is not None else locator.get("row")
    if locator.get("offset") is not None:
        try:
            ln = locator.get("length")
            if ln is None:
                ln = len(o_quote)
            o_span = (int(locator["offset"]), int(locator["offset"]) + int(ln))
        except (TypeError, ValueError):
            o_span = None
    if o_span is None and o_quote:
        qc = omission.get("quote_check") or {}
        o_span = _descriptor_span({"quote_check": qc, "quote": o_quote})
        if o_span is None and doc_text:
            from . import direct_draft
            try:
                qc = direct_draft.locate_quote(doc_text, o_quote)
            except Exception:  # noqa: BLE001
                qc = {}
            if qc.get("offset") is not None:
                o_span = (int(qc["offset"]), int(qc["offset"]) + int(qc.get("length") or 0))
                if o_line is None:
                    o_line = qc.get("line")
    c_span, c_line = candidate.get("span"), candidate.get("line")
    if o_span and c_span:
        inter = min(o_span[1], c_span[1]) - max(o_span[0], c_span[0])
        if inter > 0:
            ratio = inter / max(1, min(o_span[1] - o_span[0], c_span[1] - c_span[0]))
            if ratio >= MATCH_MIN_SPAN_OVERLAP:
                return {"kind": "span_overlap", "value": round(ratio, 4)}
            return None
        gap = max(0, max(o_span[0], c_span[0]) - min(o_span[1], c_span[1]))
        if gap <= MATCH_MAX_SPAN_GAP:
            return {"kind": "span_near", "value": gap}
        return None
    if o_line is not None and c_line is not None:
        try:
            diff = abs(int(o_line) - int(c_line))
        except (TypeError, ValueError):
            diff = None
        if diff is not None and diff <= MATCH_MAX_LINE_DISTANCE:
            return {"kind": "line_near", "value": diff}
    # 逐字引文同一性（W-18：仅“归一化后完全相同”才作坐标证据；包含/相似只作特征）
    o_norm = cross_review.norm(o_quote)
    c_norm = cross_review.norm(candidate.get("quote") or "")
    if o_norm and o_norm == c_norm and len(o_norm) >= 4:
        return {"kind": "verbatim_quote_identity", "value": 1.0}
    return None


def _score_candidate(omission: dict, candidate: dict, doc_text: str = "") -> dict | None:
    """相似度 + 坐标双门槛；命中返回打分（相似度/坐标/证据），否则 None。"""
    omission_text = _descriptor_text(omission) or str(omission.get("quote") or "")
    cand_text = candidate.get("text") or ""
    if not omission_text or not cand_text:
        return None
    text_sim = cross_review.similarity(omission_text, cand_text)
    o_quote = str(omission.get("quote") or "")
    c_quote = str(candidate.get("quote") or "")
    quote_sim = (cross_review.similarity(o_quote, c_quote)
                 if o_quote and c_quote else 0.0)
    # 相似度门槛：正文/描述相似或**引文证据同文**都算相似（引文只是特征，坐标另行双门槛）
    sim = max(text_sim, quote_sim)
    if sim < MATCH_MIN_SIMILARITY:
        return None
    coord = _coordinate_evidence(omission, candidate, doc_text)
    if coord is None:
        return None
    rule_hint = str(omission.get("rule_hint") or "").strip()
    code_bonus = 0.05 if rule_hint and rule_hint in (candidate.get("codes") or []) else 0.0
    coord_bonus = 0.0 if coord.get("kind") == "span_near" else 0.05 * float(
        coord.get("value") or 0)
    score = round(sim + code_bonus + coord_bonus, 4)
    return {"score": score, "similarity": round(sim, 4),
            "text_similarity": round(text_sim, 4),
            "quote_similarity": round(quote_sim, 4),
            "coordinate": coord, "code_bonus": code_bonus}


def _plan_reconcile(conn, case_id: str, doc_text: str = "",
                    dedupe_instances: bool = False) -> dict:
    """全局最佳匹配（W-10：不顺序贪心、可见池不抢先）。

    对所有 pending 漏报 × 所有候选（visible/hidden/direct_draft）计算双门槛打分，
    按分数降序做一次性全局分配（每个漏报最多 1 个候选、每个候选最多被 1 个漏报占用）；
    可见池与隐藏池同场竞争，避免“可见池弱匹配抢先”。

    T-53：``dedupe_instances=True`` 时先把对账池按“同一问题实例”去重（1:N 合并，
    可解释码族见 ``dedupe_pool_instances``），再分配；默认关闭保持既有行为可回归。
    去重只合并同一问题实例的重复报告，不判真/假、不改候选内容。
    """
    pool = reconcile_pool(conn, case_id, doc_text)
    dedup = None
    if dedupe_instances:
        dedup = dedupe_pool_instances(pool)
        pool = dedup["pool"]
    pending = list_omissions(conn, case_id=case_id, status="pending")
    candidates = []
    for tier in RECONCILE_TIERS:
        candidates.extend(pool.get(tier) or [])
    edges = []
    for om in pending:
        for ci, cand in enumerate(candidates):
            scored = _score_candidate(om, cand, doc_text)
            if not scored:
                continue
            edges.append({"omission_id": om["id"], "candidate_index": ci,
                          "tier": cand["tier"], "ref": cand["ref"],
                          "score": scored["score"],
                          "similarity": scored["similarity"],
                          "coordinate": scored["coordinate"],
                          "text": cand.get("text"), "quote": cand.get("quote"),
                          "span": cand.get("span"), "code": cand.get("code"),
                          "codes": cand.get("codes") or [],
                          "merged_refs": cand.get("merged_refs") or [cand["ref"]],
                          "merged_tiers": cand.get("merged_tiers") or [cand["tier"]],
                          "instance_key": cand.get("instance_key") or "",
                          "duplicate_count": cand.get("duplicate_count") or 0,
                          "source": cand.get("source") or ""})
    edges.sort(key=lambda e: (-e["score"], _TIER_RANK.get(e["tier"], 9),
                              e["omission_id"], e["ref"]))
    matched: dict = {}
    used_candidates: set = set()
    for e in edges:
        if e["omission_id"] in matched or e["candidate_index"] in used_candidates:
            continue
        matched[e["omission_id"]] = e
        used_candidates.add(e["candidate_index"])
    plan = {"case_id": case_id, "pending": [o["id"] for o in pending],
            "pool_counts": {t: len(pool.get(t) or []) for t in RECONCILE_TIERS},
            "edges": len(edges), "matches": matched,
            "algorithm": ("全局最佳匹配（相似度+坐标双门槛；按 score/tier/omission_id/ref "
                          "确定性排序；每漏报≤1 候选、每候选≤1 漏报）")}
    if dedup is not None:
        plan["instance_dedup"] = dedup["stats"]
        plan["instance_dedup_policy"] = dedup["policy"]
        plan["instance_groups"] = dedup["groups"]
        plan["algorithm"] += "；已按同一问题实例去重（T-53 1:N 合并，可解释码族）"
    return plan


def reconcile_omission(conn, omission_id: str, *, actor: str = "",
                       doc_text: str = "", human_confirmed: bool = False,
                       plan: dict | None = None) -> dict:
    """人工漏报对账（W-10/W-11）：展示项→已报；隐藏项→恢复+suppression_error；
    直连草稿→平台漏掉直连真 TP；未命中→全新漏报（反馈候选）。

    - 匹配：全局最佳匹配 + 相似度/坐标双门槛（不再“命中即自动 TP”）；
    - ``human_confirmed=True`` 才写 suppression_ledger.human_result（人工确认）；
      默认只恢复/标记，human_result 保持空 → 待人工复核；
    - 对账池只取 visible candidates（rejected_scope/duplicate/suppressed 不污染）。
    """
    omission = get_omission(conn, omission_id)
    if not omission:
        raise KeyError(f"漏报记录不存在：{omission_id}")
    if omission["status"] != "pending":
        return {"status": "already_reconciled", "omission": omission, "changed": False}
    case_id = omission["case_id"]
    actor = actor or omission.get("actor") or "human:reconciler"
    stamp = _now_iso()
    plan = plan or _plan_reconcile(conn, case_id, doc_text)
    matched = (plan.get("matches") or {}).get(omission_id)
    base_evidence = {"algorithm": plan.get("algorithm"),
                     "pool_counts": plan.get("pool_counts"),
                     "human_confirmed": bool(human_confirmed),
                     "human_result_written": False,
                     "needs_human_confirm": False}
    if not matched:
        return _finish_omission(
            conn, omission, status="new_missing", match_type="none", matched_ref="",
            actor=actor, stamp=stamp,
            feedback={"kind": "new_missing",
                      "note": "平台与直连均未报（或未过相似度+坐标双门槛）：进入规则/提示词/执行器候选"},
            note="未命中展示项/隐藏项/直连草稿：全新漏报（反馈候选）",
            evidence={**base_evidence, "similarity": None, "coordinate": None})
    tier = matched["tier"]
    evidence = {**base_evidence, "similarity": matched.get("similarity"),
                "coordinate": matched.get("coordinate"),
                "matched_quote": matched.get("quote"),
                "matched_span": matched.get("span"),
                "candidate_source": matched.get("source") or "",
                "merged_refs": matched.get("merged_refs") or [matched.get("ref")],
                "merged_tiers": matched.get("merged_tiers") or [tier],
                "instance_key": matched.get("instance_key") or "",
                "duplicate_count": matched.get("duplicate_count") or 0}
    if tier == "visible":
        return _finish_omission(
            conn, omission, status="matched_visible", match_type="visible",
            matched_ref=matched["ref"], actor=actor, stamp=stamp,
            feedback={}, note="命中展示项：已报（重复），不恢复、不计漏报",
            evidence=evidence)
    if tier == "hidden":
        ledger_id = matched["ref"]
        rec = recover(conn, ledger_id, actor=actor,
                      reason="人工漏报命中隐藏项：隐藏项其实是 TP → 恢复 + suppression_error",
                      recovered_finding_ref=f"omission:{omission_id}")
        human_result_written = False
        if human_confirmed:
            record_human_result(conn, ledger_id, "true_positive", actor=actor,
                                reason="人工确认后写回：隐藏项为真 TP")
            human_result_written = True
        evidence = {**evidence, "recovered": bool(rec.get("recovered")),
                    "human_result_written": human_result_written,
                    "needs_human_confirm": not human_result_written}
        return _finish_omission(
            conn, omission, status="matched_hidden", match_type="hidden",
            matched_ref=ledger_id, actor=actor, stamp=stamp,
            feedback={"kind": "suppression_error", "ledger_id": ledger_id,
                      "source": matched.get("source") or "",
                      "human_result_written": human_result_written,
                      "note": "被抑制项其实是真 TP：需复核抑制原因/反证/阈值；"
                              "human_result 需人工确认后才写"},
            recovered_ledger_id=ledger_id,
            note="命中隐藏项：恢复 + suppression_error（human_result 待人工确认）",
            evidence=evidence)
    # direct_draft：平台漏掉直连真 TP（反馈候选，不自动改真值）
    return _finish_omission(
        conn, omission, status="matched_direct_draft", match_type="direct_draft",
        matched_ref=matched["ref"], actor=actor, stamp=stamp,
        feedback={"kind": "platform_miss_direct_true",
                  "direct_item_id": matched["ref"],
                  "rule_code": matched.get("code") or "",
                  "note": "平台漏掉直连真 TP：补规则/修路由/修证据"},
        note="命中直连草稿：平台漏掉直连真 TP（反馈候选）",
        evidence=evidence)


def _finish_omission(conn, omission: dict, *, status: str, match_type: str,
                     matched_ref: str, actor: str, stamp: str, feedback: dict,
                     note: str, evidence: dict, recovered_ledger_id: str = "") -> dict:
    conn.execute(
        f"UPDATE {OMISSION_TABLE} SET status=?, match_type=?, matched_ref=?, "
        "recovered_ledger_id=?, feedback_candidate_json=?, note=?, reconciled_at=? WHERE id=?",
        (status, match_type, matched_ref, recovered_ledger_id, _canonical_json(feedback),
         note, stamp, omission["id"]))
    event = cross_review.append_event(
        conn, "reconcile_omission", case_id=omission["case_id"],
        run_id=omission.get("run_id") or "", omission_id=omission["id"],
        ledger_id=recovered_ledger_id, actor=actor, before_status="pending",
        after_status=status, reason_code=f"omission_{match_type}", reason=note,
        evidence=evidence)
    return {"status": status, "match_type": match_type, "matched_ref": matched_ref,
            "recovered_ledger_id": recovered_ledger_id, "changed": True,
            "similarity": evidence.get("similarity"),
            "coordinate": evidence.get("coordinate"),
            "human_result_written": bool(evidence.get("human_result_written")),
            "needs_human_confirm": bool(evidence.get("needs_human_confirm")),
            "omission": get_omission(conn, omission["id"]), "event": event}


def reconcile_pending(conn, case_id: str, *, actor: str = "", doc_text: str = "",
                      human_confirmed: bool = False) -> dict:
    """批量对账：先做**一次**全局最佳匹配，再逐条落库（不顺序贪心）。"""
    plan = _plan_reconcile(conn, case_id, doc_text)
    results = [reconcile_omission(conn, o["id"], actor=actor, doc_text=doc_text,
                                  human_confirmed=human_confirmed, plan=plan)
               for o in list_omissions(conn, case_id=case_id, status="pending")]
    counts: dict = {}
    for r in results:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    return {"case_id": case_id, "reconciled": len(results), "by_status": counts,
            "human_result_written": sum(1 for r in results if r.get("human_result_written")),
            "needs_human_confirm": sum(1 for r in results if r.get("needs_human_confirm")),
            "plan": {"pending": plan["pending"], "pool_counts": plan["pool_counts"],
                     "edges": plan["edges"], "algorithm": plan["algorithm"]},
            "results": results}


def list_feedback_candidates(conn, case_id: str = "") -> list:
    """由人工漏报对账产生的反馈候选（规则/路由/证据/提示词修正入口）。"""
    out = []
    for o in list_omissions(conn, case_id=case_id):
        fb = o.get("feedback_candidate") or {}
        if fb:
            out.append({"omission_id": o["id"], "case_id": o["case_id"],
                        "status": o["status"], "match_type": o["match_type"],
                        "matched_ref": o["matched_ref"], "candidate": fb})
    return out


__all__ = [
    "LEDGER_TABLE", "OMISSION_TABLE", "SAMPLE_RESULTS", "OMISSION_STATUSES",
    "LEDGER_ALLOWED_REASONS", "MATCH_MIN_SIMILARITY",
    "MATCH_MIN_SPAN_OVERLAP", "MATCH_MAX_SPAN_GAP", "MATCH_MAX_LINE_DISTANCE",
    "RECONCILE_TIERS",
    "get", "list_ledger", "stats", "hidden_summary_text",
    "suppress", "suppress_decision", "mark_sampled", "record_human_result", "recover",
    "apply_comparison_visibility", "apply_case_visibility",
    "get_omission", "list_omissions", "record_omission", "reconcile_omission",
    "reconcile_pending", "list_feedback_candidates",
    "reconcile_pool", "_plan_reconcile", "_coordinate_evidence", "_score_candidate",
    "INSTANCE_DEDUP_MIN_OVERLAP", "INSTANCE_DEDUP_MAX_GAP",
    "dedupe_pool_instances", "_instance_same", "_codes_compatible",
]
