"""执行 audit_manifest 的 D1–D5。

D1 适用范围 / D2 规则版本 / D3 证据绑定 / D4 执行 / D5 组合。
确定性规则用 ruleexec；语义规则缺执行器时明确 needs_model，不伪造通过。
sheet 限定：规则 slots 声明 sheet_name / evidence_scope_sheet 时，D3 校验该 sheet
真实存在，D4 只消费该 sheet 的文本/行；未声明时保持原 document 全量口径。
税额/金额来源：规则把 rate/tax_status/direction/currency 声明为 auto（或留空）时，
从合同/发票文本绑定实际值并写入 D4 trace；缺来源/候选冲突/坏表显式 insufficient。
汇总/比较：sheet 限定时只累计该 sheet 的值；多 sheet 未限定且值跨表时 insufficient。
"""
from __future__ import annotations
import json
import logging
import os
import re
from decimal import Decimal
from .. import db, repositories as R
from ..engine import deepparse, ruleexec
# DU-29：D5 六态别名/na 家族与台账/报告口径共用 state_machines 单一事实源。
from . import state_machines as _state_machines
# L80 / P0-C：裁决来源台账（唯一写入口/统计；模块自身只 import db，无循环依赖）。
# 开关默认 0：=0 时本模块只被 import（无 DDL/无查询/无写入）。
from . import adjudication_ledger


def _module_off(key: str, workspace_id: str = "") -> bool:
    """T-115：工作空间模块开关在主链执行点的统一口径。

    与 HTTP 层 ``server._module_off`` 同源（``workspaces.explicit_off``：仅显式 false
    才关闭，默认不改变旧行为）。优先用清单所属项目空间；拿不到空间时不判定关闭，
    保证 CLI/脚本/旧调用方行为不变。
    """
    try:
        from . import ctx as _ctx_m, workspaces as _ws_m
        wid = str(workspace_id or "").strip()
        if not wid:
            wid = str((_ctx_m.get_context() or {}).get("workspace_id") or "").strip()
        return bool(wid) and bool(_ws_m.explicit_off(wid, key))
    except Exception:
        logging.getLogger(__name__).debug("module switch lookup skipped", exc_info=True)
        return False


def _load_manifest(mid: str):
    c = db.connect()
    try:
        row = c.execute("SELECT * FROM audit_manifest WHERE id=?", (mid,)).fetchone()
        return dict(row) if row else None
    finally:
        c.close()


def _doc(case_id: str, object_id: str):
    for d in R.cases.documents(case_id):
        if d.get("id") == object_id:
            return d
    return None




def _item_onto_aliases(item: dict) -> dict:
    b = (item or {}).get("ontology_binding") or {}
    a = b.get("aliases") if isinstance(b, dict) else {}
    return a if isinstance(a, dict) else {}


def _item_onto_trace(item: dict, metric: str, text: str) -> dict:
    """Record which frozen ontology aliases actually hit the document."""
    b = (item or {}).get("ontology_binding") or {}
    aliases = _item_onto_aliases(item)
    hits = []
    for canon, names in aliases.items():
        if str(canon) != str(metric):
            continue
        for n in names or []:
            if str(n) and str(n) in (text or ""):
                hits.append({"canonical": str(canon), "alias": str(n), "source": "workspace_ontology"})
    return {"sha": b.get("sha") or "", "resolutions": hits} if b else {}


# D1 执行期只读 manifest 冻结的适用范围快照（applicable_when / scope.tags），
# 不再查实时规则/本体/词典。与 manifest.freeze 的 scope_route 分类保持一致。
_SCOPE_FILE_TOKENS = {"xlsx", "xls", "docx", "doc", "pdf", "txt", "csv", "md",
                      "markdown", "json", "xml", "html", "png", "jpg", "jpeg"}


def _scope_token_is_file(token) -> bool:
    return str(token or "").strip().lower().lstrip(".") in _SCOPE_FILE_TOKENS


def _type_token_match(token, doc: dict) -> bool:
    t = str(token or "").strip().lower().lstrip(".")
    if not t:
        return False
    dt = str((doc or {}).get("doc_type") or "").lower()
    fn = str((doc or {}).get("filename") or "").lower()
    return t == dt or t in fn or t in dt


def _scope_context_hay(item: dict, case: dict, doc: dict) -> str:
    """D1 适用性上下文：优先用冻结时记录的对象路由 haystack（与路由同快照）。"""
    route = (item or {}).get("audit_route") or {}
    parts = [route.get("object_haystack") or "",
             route.get("case_document_type") or "",
             route.get("case_audit_type") or "",
             str((case or {}).get("document_type") or ""),
             str((case or {}).get("audit_type") or ""),
             str((doc or {}).get("doc_type") or ""),
             str((doc or {}).get("filename") or "")]
    return " ".join(str(p) for p in parts if p).lower()


# ---------------------------------------------------------------------------
# D1 结构适用性（2026-11-22）：applicable_when / scope.tags 的**字面锚**匹配失败时，
# 不再直接判 not_applicable（na）。口径（外部评审建议 3，docs/qa/L1主机制外部评审_20261121.md）：
#   ① 先做编号/空白/全半角归一匹配（NFKC + 去空白/标点 + 小写）——措辞与数字形式差异不算不适用；
#   ② 仍未命中 → **结构适用性判定**：规则针对的对象类型/字段是否真实存在于文档/对象上下文；
#   ③ 仅「对象确实不存在」才 na；对象存在但锚点措辞不同 → 不判 na（标 anchor_unverified，
#      D4 把该 item 的 na 降为 insufficient 并带「锚点未命中」，交下游/人工复核）。
# 总开关 RULEPROOF_D1_STRUCTURAL 默认 0：关闭时本段代码不参与任何判断（不调用、不写 trace），
# 行为与改前逐字段一致（scripts/qa/d1_applicability_test.py 有双向断言）。
_D1_STRUCTURAL_ENV = "RULEPROOF_D1_STRUCTURAL"
_D1_STRUCTURAL_DEFAULT = "0"
_D1_ANCHOR_MISS_REASON = "applicable_when_anchor_unmatched"
# 归一匹配时从两侧剔除的标点/分隔符（只影响“是否命中”，不改变 token 语义）
_D1_ANCHOR_PUNCT_RE = re.compile(
    r"[\s\u3000，。、；：！？,.;:!?\"'“”‘’（）()【】\[\]{}《》〈〉<>·…—\-_/\\|~`]+")
# 结构适用性探测的 slot 字段名（不同规则来源的字段名可能不同；只读冻结快照）
_D1_OBJECT_SLOT_KEYS = ("metric", "field", "object", "object_type", "target", "subject")


def _d1_structural_enabled() -> bool:
    """D1 结构适用性总开关：默认关；只有显式 1/true/on/yes 才启用。"""
    return str(os.environ.get(_D1_STRUCTURAL_ENV, _D1_STRUCTURAL_DEFAULT)).strip().lower() in (
        "1", "true", "yes", "on")


def _d1_norm_text(value) -> str:
    """D1 锚点归一：NFKC（全角→半角、圈号→数字）+ 小写 + 去空白/标点分隔符。"""
    import unicodedata as _ud
    t = _ud.normalize("NFKC", str(value or "")).lower()
    return _D1_ANCHOR_PUNCT_RE.sub("", t)


def _d1_anchor_hit(token, *texts) -> bool:
    """归一后子串命中（token 归一为空 → 不命中；空 token 不得当通配）。"""
    t = _d1_norm_text(token)
    if not t:
        return False
    return any(t in _d1_norm_text(x) for x in texts if str(x or ""))


def _d1_structural_object_presence(item: dict, hay: str, body: str) -> dict:
    """结构适用性：规则针对的对象/字段是否真实存在于文档（不依赖锚点字面措辞）。

    三态：present（对象存在）/ absent（对象确实不存在）/ unknown（无法证明）。
    只看冻结 item 的 slots/本体绑定，不查实时规则库。
    调用方口径：absent 才允许 na；present/unknown 都不得以「不适用」下结论。
    """
    item = item if isinstance(item, dict) else {}
    slots = item.get("slots") if isinstance(item.get("slots"), dict) else {}
    body_low = str(body or "")[:200000].lower()
    probes = []
    seen = set()
    for key in _D1_OBJECT_SLOT_KEYS:
        val = str(slots.get(key) or "").strip()
        if val and (key, val) not in seen:
            seen.add((key, val))
            probes.append({"source": "slot_" + key, "name": val})
    _onto = _item_onto_aliases(item) or {}
    for canon, aliases in _onto.items():
        for alias in (aliases or []):
            alias = str(alias or "").strip()
            if alias and ("ontology", alias) not in seen:
                seen.add(("ontology", alias))
                probes.append({"source": "ontology_alias", "canonical": str(canon), "name": alias})
    hits = [p for p in probes
            if _d1_anchor_hit(p["name"], hay) or _d1_anchor_hit(p["name"], body_low)]
    out = {"state": "unknown", "probes": probes[:12], "hits": hits[:12]}
    if hits:
        out["state"] = "present"
    elif probes:
        # 规则声明了对象/字段，但文档与对象上下文里都归一命中不到 → 对象确实不存在
        out["state"] = "absent"
    return out


def _d1_scope_condition(item: dict, d1: dict, case: dict, doc: dict, text: str) -> dict:
    """D1 适用性补充判定：applicable_when 与 scope.tags 真正参与执行。

    - 文件类型类 token（txt/xlsx…）按对象类型/文件名判定；
    - 业务条件 / 标签 token 必须在冻结上下文或原文中真实出现；
    - 文档原文太短（<20 字）时无法验证触发条件，不硬判不适用，留 trace 供复核；
    - RULEPROOF_D1_STRUCTURAL=1 时：归一匹配 + 结构适用性（仅对象确实不存在才 na）。
    返回要合入 d1 的字段；调用方负责覆盖 status/reason。
    """
    aw = [str(x) for x in (item.get("applicable_when") or []) if str(x).strip()]
    tags = [str(x) for x in (item.get("scope_tags") or []) if str(x).strip()]
    if not aw and not tags:
        return {}
    hay = _scope_context_hay(item, case, doc)
    body = str(text or "")
    body_low = body[:20000].lower()
    file_tokens = [t for t in aw if _scope_token_is_file(t)]
    when_tokens = [t for t in aw if not _scope_token_is_file(t)]
    file_hits = [t for t in file_tokens if _type_token_match(t, doc)]
    when_hits = [t for t in when_tokens
                 if str(t).lower() in hay or str(t).lower() in body_low]
    tag_hits = [t for t in tags
                if str(t).lower() in hay or str(t).lower() in body_low]
    _d1s = _d1_structural_enabled()
    if _d1s:
        # ① 归一匹配：编号写法/空白/全半角/标点差异不得被当成“不适用”
        file_hits = [t for t in file_tokens if t in file_hits or _d1_anchor_hit(
            t, str((doc or {}).get("filename") or ""), str((doc or {}).get("doc_type") or ""))]
        when_hits = [t for t in when_tokens
                     if t in when_hits or _d1_anchor_hit(t, hay, body_low)]
        tag_hits = [t for t in tags
                    if t in tag_hits or _d1_anchor_hit(t, hay, body_low)]
    out = {"applicable_when": {"declared": aw, "matched": list(dict.fromkeys(file_hits + when_hits)),
                               "unmatched": [t for t in aw if t not in file_hits + when_hits],
                               "source": "manifest_freeze"},
           "scope_tags": {"declared": tags, "matched": tag_hits,
                          "source": "manifest_freeze"}}
    _missed_anchors = ([t for t in when_tokens if t not in when_hits]
                       + [t for t in tags if t not in tag_hits]) if _d1s else []
    if d1.get("status") != "applicable":
        return out
    reasons = []
    if file_tokens and not file_hits:
        reasons.append("applicable_when_type_mismatch")
    _verifiable = len(body.strip()) >= 20 or bool(hay.strip())
    if when_tokens and not when_hits and _verifiable:
        reasons.append("applicable_when_unmatched")
    if tags and not tag_hits and _verifiable:
        reasons.append("scope_tags_unmatched")
    # F-10：applicable_when.matched 非空且 unmatched 为空时，不得判 not_applicable
    _aw_matched = out["applicable_when"]["matched"]
    _aw_unmatched = out["applicable_when"]["unmatched"]
    if reasons and _aw_matched and not _aw_unmatched:
        reasons = [r for r in reasons if r != "applicable_when_unmatched"]
    if reasons and _d1s:
        # ② 结构适用性：字面锚未命中不再直接 na —— 先看规则对象是否真实存在。
        #    文件类型不匹配 = 对象类型不存在，保留 na（real structural absence）。
        #    when/tag 的锚点未命中：present/unknown → 不判 na，标 anchor_unverified；
        #    absent（规则声明的对象/字段在文档与对象上下文中确实找不到）→ na。
        _anchor_reasons = [r for r in reasons
                           if r in ("applicable_when_unmatched", "scope_tags_unmatched")]
        _hard_reasons = [r for r in reasons if r not in _anchor_reasons]
        if _anchor_reasons:
            _presence = _d1_structural_object_presence(item, hay, body)
            out["structural"] = {
                "enabled": True,
                "presence": _presence.get("state"),
                "hits": [h.get("name") for h in (_presence.get("hits") or [])][:5],
                "probes": [p.get("name") for p in (_presence.get("probes") or [])][:8],
                "anchor_missed": _missed_anchors,
            }
            if _presence.get("state") == "absent":
                reasons = ["structural_object_absent"] + _hard_reasons
            else:
                reasons = list(_hard_reasons)
                out["anchor_unverified"] = True
                out["anchor_unverified_reason"] = _D1_ANCHOR_MISS_REASON
                out["anchor_unverified_presence"] = _presence.get("state")
                out["anchor_missed"] = _missed_anchors
    if reasons:
        out["status"] = "not_applicable"
        out["reason"] = reasons[0]
        out["reason_chain"] = reasons
        out["scope_source"] = "manifest_freeze"
        # 冻结已纳入但执行期判不适用：显式 routed_out，不得静默 na
        out["routed_out"] = True
        out["routed_out_reason"] = reasons[0]
    return out


def _apply_d1_anchor_cap(d1: dict, d4: dict) -> dict:
    """D1 结构适用性（开关制）：锚点未命中但对象存在 → D4 的 na 不得生效。

    RULEPROOF_D1_STRUCTURAL=1 且 D1 标记 anchor_unverified 时，把 D4 子项
    not_applicable 降为 insufficient，并写明确原因「锚点未命中（不是不适用）」；
    不改 pass/fail/insufficient，不伪造结论。开关关闭/未标记时原样返回（逐字段一致）。
    """
    if not _d1_structural_enabled():
        return d4
    if not isinstance(d1, dict) or not d1.get("anchor_unverified"):
        return d4
    if not isinstance(d4, dict):
        return d4
    capped = 0
    for sub in (d4.get("subs") or []):
        if not isinstance(sub, dict):
            continue
        if str(sub.get("status") or "") != "not_applicable":
            continue
        sub["status"] = "insufficient"
        sub["downgraded_from"] = "not_applicable"
        sub["downgrade_reason"] = "applicable_when_anchor_miss"
        sub["d1_anchor_unverified"] = True
        sub["detail"] = ((str(sub.get("detail") or "") + "；") if sub.get("detail") else "") + (
            "适用性锚点未命中（规则对象在文档中存在，非不适用）：不判 na，"
            "降为 insufficient 交复核")
        capped += 1
    d4["anchor_unverified"] = True
    d4["anchor_cap"] = {"capped": capped, "reason": _D1_ANCHOR_MISS_REASON}
    if capped:
        d4["detail"] = (str(d4.get("detail") or "") +
                        f"（适用性锚点未命中：{capped} 个 na 降为 insufficient）")
    return d4


def _exec_type_token_matches(token, doc: dict) -> bool:
    """文件类型 token 的严格匹配（扩展名/库类型精确匹配，禁止业务类型裸子串）。

    token 只允许是已知文件扩展名（docx/xlsx/pdf…）或与 doc_type/文件名扩展名完全相等；
    不再用 ``t in filename`` 这类子串匹配，避免“业务类型出现在文件名 → 适用”的口径漂移。
    """
    t = str(token or "").strip().lower().lstrip(".")
    if not t:
        return False
    dt = str((doc or {}).get("doc_type") or "").strip().lower().lstrip(".")
    fn = str((doc or {}).get("filename") or "").strip().lower()
    if t == dt:
        return True
    ext = fn.rsplit(".", 1)[-1] if "." in fn else ""
    return bool(ext) and t == ext


def _frozen_business_hay(item: dict, case: dict, doc: dict) -> str:
    """冻结路由的业务类型 haystack（案例/对象业务类型上下文；文件名/扩展名不算业务类型）。"""
    route = (item or {}).get("audit_route") or {}
    case = case or {}
    return " ".join(str(x or "") for x in (
        route.get("object_haystack") or "",
        route.get("case_document_type") or "",
        route.get("case_audit_type") or "",
        route.get("audit_type") or "",
        case.get("document_type") or "",
        case.get("audit_type") or "",
        str((doc or {}).get("doc_type") or ""),
    )).strip().lower()


def _frozen_business_matched(item: dict, case: dict, doc: dict, business: list) -> bool:
    """F-10：业务类型是否命中冻结路由上下文。

    - 只读冻结 item 的 audit_route 快照 + case 的业务类型；不新增实时查询；
    - 业务 token 必须出现在「案例/对象业务类型」上下文中，文件名/扩展名不单独构成
      业务类型命中（与 manifest.freeze 的 _business 路由同源：business_resolved 时按
      对象 haystack 判定，解析不了时沿用冻结结论，不伪造路由）。
    """
    hay = _frozen_business_hay(item, case, doc)
    # 业务范围是“对象业务名称”（如 不合格/合格），必须对照对象 haystack；
    # 不能因为 business_resolved=false 就放行，否则好文件会被当坏文件审。
    # A9（2026-11-21）：haystack 为空时的“命中”无法证明适用性 → 由调用方写
    # scope_unverified=True，D4 对该 item 的 fail 上限降为 insufficient。
    if not hay.strip():
        return True
    return any(str(b or "").strip().lower() in hay for b in (business or []) if str(b or "").strip())


def _d1_from_frozen_route(item: dict, case: dict, doc: dict) -> dict:
    """D1 适用性：复用冻结路由结论，禁止执行期用扩展名/文件名裸子串重判业务类型。

    冻结清单只包含 freeze 判定为适用（或项目级/未声明 scope）的 规则×对象 组合，
    因此 D1 起点是 applicable；执行期只补两条真实约束：
    1) 显式文件扩展名 scope 必须与对象扩展名精确一致；
    2) 业务范围 scope 必须在冻结路由上下文中命中（business_resolved 时）；
    任何“已冻结但执行期判不适用”的情况都显式标记 routed_out + 原因，不得静默 na。
    """
    route = (item or {}).get("audit_route") or {}
    meta = item.get("scope_meta") or {}
    route_types = [str(x) for x in (meta.get("route_types") or []) if str(x).strip()]
    if not route_types:
        route_types = [str(x) for x in (item.get("applicable_types") or [])
                       if str(x).strip() and _scope_token_is_file(str(x))]
    # business_scope 里可能混入扩展名（历史冻结/表 wrapper 继承导致）；文件扩展名不是业务类型，
    # 交给 route_types 判定，避免 SB(无 scope) 被 ['md'] 误判 not_applicable。
    business = [str(x) for x in (meta.get("business_scope") or [])
                if str(x).strip() and not _scope_token_is_file(str(x))]
    d1 = {
        "status": "applicable",
        "reason": "冻结清单已路由该规则×对象",
        "source": "manifest_freeze",
        "scope_status": str(meta.get("status") or route.get("scope_status") or ""),
        "route": {
            "source": "manifest_freeze",
            "routed_from": "manifest_item",
            "routed": True,
            "scope_kind": str(route.get("scope_kind") or meta.get("status") or ""),
            "route_types": route_types,
            "business_scope": business,
            "business_resolved": bool(route.get("business_resolved")),
            "case_document_type": str(route.get("case_document_type") or ""),
            "case_audit_type": str(route.get("case_audit_type") or ""),
        },
    }
    if business:
        ok = _frozen_business_matched(item, case, doc, business)
        d1["reason"] = ("业务类型在规则范围（冻结路由）" if ok
                        else "业务类型不在规则范围（冻结路由冲突）")
        if not ok:
            d1.update({"status": "not_applicable", "routed_out": True,
                       "routed_out_reason": "frozen_route_business_mismatch"})
            return d1
        # A9（2026-11-21）：冻结路由 haystack 为空 → 业务范围“命中”无法验证。
        # D1 保持两态契约（仍 applicable），但显式标记未验证；D4 据此把 fail 上限
        # 压到 insufficient（适用性不可证明时不得输出确定 fail）。
        if not _frozen_business_hay(item, case, doc):
            d1["scope_unverified"] = True
            d1["scope_unverified_reason"] = "route_haystack_empty"
            d1["reason"] = (d1.get("reason") or "") + "；冻结路由 haystack 为空，适用性未验证"
    if route_types:
        ok = any(_exec_type_token_matches(t, doc) for t in route_types)
        d1["reason"] = ("文件类型在规则范围（冻结路由）" if ok
                        else "文件类型不在规则范围（冻结路由冲突）")
        if not ok:
            d1.update({"status": "not_applicable", "routed_out": True,
                       "routed_out_reason": "frozen_route_type_conflict"})
        return d1
    d1["reason"] = "规则为项目级/未声明文件类型限制"
    return d1


# ---------------- D4 冻结别名取数 ----------------
# 冻结快照之后追加/修改的实时别名不得改变本次审核结果：
# ruleexec._from_text 收到 aliases 快照时仍会合并实时本体别名（hooks/settings），
# 因此在 manifest_exec 侧用「冻结别名白名单」校验命中引文，实时别名命中一律丢弃。
_FROZEN_SUFFIXES = ("时间", "期限", "时长", "天数")
_FROZEN_SPECIAL_METRIC_KEYS = ("率", "比例", "违约金")


def _frozen_alias_names(metric: str, aliases: dict) -> list:
    """可由冻结快照 + ruleexec 固定后缀规则推出的取数名称；不含任何实时数据。"""
    metric_s = str(metric or "").strip()
    names = [metric_s] if metric_s else []
    for canon, als in (aliases or {}).items():
        canon_s = str(canon or "").strip()
        al_s = [str(x).strip() for x in (als or []) if str(x).strip()]
        if canon_s and (canon_s == metric_s or metric_s in al_s):
            names.append(canon_s)
            names.extend(al_s)
    for suf in _FROZEN_SUFFIXES:
        if metric_s.endswith(suf) and len(metric_s) > len(suf):
            names.append(metric_s[:-len(suf)])
    return list(dict.fromkeys([n for n in names if n]))


def _frozen_quote_allowed(quote, metric: str, aliases: dict) -> bool:
    q = str(quote or "").strip()
    if not q:
        return True
    metric_s = str(metric or "")
    if any(q.startswith(n) for n in _frozen_alias_names(metric_s, aliases)):
        return True
    # 与 ruleexec 里「按 0.08% 计 / 每日 0.03%」这类无指标名前缀的固定取数兼容
    if any(k in metric_s for k in _FROZEN_SPECIAL_METRIC_KEYS):
        return True
    return False


def _frozen_from_text(metric: str, text: str, aliases: dict):
    """冻结口径取数：实时别名命中的结果不采信（返回 None）。"""
    val, quote = ruleexec._from_text(metric, text, aliases=aliases)
    if val is None:
        return None, None
    if aliases is None or _frozen_quote_allowed(quote, metric, aliases):
        return val, quote
    return None, None


def _frozen_all_from_text(metric: str, text: str, aliases: dict) -> list:
    """逐行取数（多行/多批）：逐条按冻结别名白名单过滤。"""
    if aliases is None:
        return ruleexec.all_from_text(metric, text)
    if not metric or not text:
        return []
    out, seen = [], set()
    for line in str(text).splitlines():
        if not line.strip():
            continue
        val, quote = _frozen_from_text(metric, line, aliases)
        if val is None:
            continue
        key = (str(val), quote)
        if key in seen:
            continue
        seen.add(key)
        out.append({"value": val, "quote": quote or line[:60], "line": line})
    return out


def _frozen_judge_rule(sub: dict, text: str, aliases: dict) -> dict:
    """限值判定：取数引文必须来自冻结别名/指标本身，实时别名命中降级为证据不足。"""
    jr = ruleexec.judge_rule(sub, text, [], aliases=aliases)
    try:
        from ..engine import hooks as _hk_jr
        if isinstance(jr, dict):
            jr = _hk_jr.guard_judgement(jr, rule_code=str(sub.get("rule_code") or ""),
                                        source="manifest_exec.frozen_judge",
                                        numeric=_hk_jr.point_is_numeric(sub))
    except Exception:  # noqa: BLE001 - 守卫异常不得改变判定（与未接线时一致）
        logging.debug("frozen_judge provenance guard skipped", exc_info=True)
    if aliases is None or not isinstance(jr, dict):
        return jr
    try:
        if not ruleexec.is_limit_rule(sub):
            return jr
    except Exception:
        return jr
    metric = str((sub or {}).get("metric") or "")
    try:
        if ruleexec._entity_type(metric) in ("日期", "编号"):
            return jr
    except Exception:
        pass
    st = str(jr.get("state") or "")
    quote = str(jr.get("quote") or "")
    if st in ("满足", "不满足") and quote and not _frozen_quote_allowed(quote, metric, aliases):
        return {"state": "证据不足", "value": None, "quote": quote,
                "frozen_alias_blocked": True,
                "detail": f"原文只命中实时别名（不在冻结快照内），按冻结口径不采信：{quote[:60]}"}
    return jr



def _deterministic_consistency_result(rule: dict, text: str) -> dict | None:
    """跨 Sheet 一致性规则（版本号/实施日期/商品名）确定性执行（T-170）。"""
    if str(os.environ.get("RULEPROOF_DET_CONSISTENCY", "1")).strip() in ("0", "false", "off", "no"):
        return None
    code = str((rule or {}).get("code") or "")
    if not code:
        return None
    try:
        det = ruleexec.judge_consistency_rule(code, text)
    except Exception as e:
        logging.getLogger(__name__).warning("deterministic consistency failed code=%s: %s", code, e)
        return None
    if not det:
        return None
    st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
          "不适用": "not_applicable"}.get(str(det.get("state") or ""), "unknown")
    return {"status": st, "raw_state": str(det.get("state") or ""),
            "detail": str(det.get("detail") or ""),
            "quote": str(det.get("quote") or ""),
            "values": det.get("values") or []}


def _deterministic_consistency_text_result(sub: dict, text: str) -> dict | None:
    """L44 consistency 文本算子（编号/字符串跨位置一致性）确定性执行。

    场景（L32/L42 唯一残差）：规则声明字段锚点（slots.consistency={left,right} 或
    metric/value 字段对），D4 数值取数为空（编号/字符串不是「数值+单位」），历史路径直接
    落「未提取到指标数值 → 证据不足」。本函数在数值取数为空时把该子要求交给
    ``ruleexec.judge_consistency_text`` 判：一致 pass / 不一致 fail / 缺侧 insufficient。

    返回 None = 开关关（RULEPROOF_CONSISTENCY_TEXT=0）或非一致性规则 → 调用方保持旧路径。
    开关只在 ruleexec 侧读取一次（同一实现口径，避免两处不一致）。
    """
    if not isinstance(sub, dict):
        return None
    try:
        if not ruleexec._consistency_text_enabled():
            return None
        if not ruleexec._is_consistency_text_rule(sub):
            return None
        jr = ruleexec.judge_rule(dict(sub), text or "", [], aliases=None)
    except Exception as e:  # 铁律 2：执行异常不伪造结论，回落旧路径并留痕
        logging.getLogger(__name__).warning(
            "deterministic consistency text failed: %s: %s", type(e).__name__, e)
        return None
    st0 = str((jr or {}).get("state") or "")
    st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
          "不适用": "not_applicable"}.get(st0)
    if not st:
        return None
    return {"status": st, "raw_state": st0,
            "detail": str((jr or {}).get("detail") or ""),
            "quote": str((jr or {}).get("quote") or ""),
            "code": str((jr or {}).get("code") or ""),
            "values": (jr or {}).get("values") or [],
            "evidence": (jr or {}).get("evidence") or []}


def _deterministic_domain_result(rule: dict, text: str) -> dict | None:
    """领域型判据（E3/E4）确定性执行（T-170 判据适用范围）。"""
    if str(os.environ.get("RULEPROOF_DET_DOMAIN", "1")).strip() in ("0", "false", "off", "no"):
        return None
    code = str((rule or {}).get("code") or "")
    if not code:
        return None
    try:
        det = ruleexec.judge_domain_rule(code, text)
    except Exception as e:
        logging.getLogger(__name__).warning("deterministic domain failed code=%s: %s", code, e)
        return None
    if not det:
        return None
    st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
          "不适用": "not_applicable"}.get(str(det.get("state") or ""), "unknown")
    return {"status": st, "raw_state": str(det.get("state") or ""),
            "detail": str(det.get("detail") or ""),
            "quote": str(det.get("quote") or ""),
            "applicability": str(det.get("applicability") or "")}


def _deterministic_applicability_result(rule: dict, text: str) -> dict | None:
    """前提缺失型适用性判定（T-170 ①；B-4 等）。仅在确定性判定为「不适用」时返回结论。"""
    if str(os.environ.get("RULEPROOF_DET_APPLICABILITY", "1")).strip() in ("0", "false", "off", "no"):
        return None
    code = str((rule or {}).get("code") or "")
    if not code:
        return None
    try:
        det = ruleexec.judge_applicability_rule(code, text)
    except Exception as e:
        logging.getLogger(__name__).warning("deterministic applicability failed code=%s: %s", code, e)
        return None
    if not det:
        return None
    st = {"不适用": "not_applicable", "证据不足": "insufficient"}.get(
        str(det.get("state") or ""), "unknown")
    return {"status": st, "raw_state": str(det.get("state") or ""),
            "detail": str(det.get("detail") or ""),
            "applicability": str(det.get("applicability") or "")}


def _deterministic_placeholder_result(rule: dict, text: str) -> dict | None:
    """版本号/签名占位符确定性执行（T-170：RW20260525002 引文不可核验导致门禁阻断）。"""
    if str(os.environ.get("RULEPROOF_DET_PLACEHOLDER", "1")).strip() in ("0", "false", "off", "no"):
        return None
    code = str((rule or {}).get("code") or "")
    if not code:
        return None
    try:
        det = ruleexec.judge_placeholder_rule(code, text)
    except Exception as e:
        logging.getLogger(__name__).warning("deterministic placeholder failed code=%s: %s", code, e)
        return None
    if not det:
        return None
    st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
          "不适用": "not_applicable"}.get(str(det.get("state") or ""), "unknown")
    return {"status": st, "raw_state": str(det.get("state") or ""),
            "detail": str(det.get("detail") or ""),
            "quote": str(det.get("quote") or ""),
            "violations": [str(x) for x in (det.get("violations") or []) if str(x).strip()],
            "labels": det.get("labels") or []}


def _deterministic_limit_result(rule: dict, text: str) -> dict | None:
    """内置食品限值规则的确定性执行（T-170 数值比较/判据适用范围修复）。

    只在规则码命中 ``ruleexec.FOOD_LIMIT_SPECS`` 时返回结论（其余返回 None，
    调用方必须继续原 agent-judge 路径，不得把 None 当成通过）。
    开关：``RULEPROOF_DET_LIMIT_RULES=0`` 关闭（默认开启；回滚/A-B 用）。
    """
    if str(os.environ.get("RULEPROOF_DET_LIMIT_RULES", "1")).strip() in ("0", "false", "off", "no"):
        return None
    code = str((rule or {}).get("code") or "")
    if not code:
        return None
    try:
        det = ruleexec.judge_limit_rule(code, text)
    except Exception as e:  # 执行器异常必须显式暴露，不能伪装成证据不足
        logging.getLogger(__name__).warning("deterministic limit exec failed code=%s: %s", code, e)
        return {"status": "failed", "raw_state": "执行失败",
                "detail": f"确定性限值执行器异常：{type(e).__name__}: {str(e)[:120]}",
                "quote": "", "values": []}
    if det is None:
        return None
    # L28 输入类型守卫：执行器返回结果必须是 dict（L24 的中间态下结果/取数类型错位会让
    # 下面的 det.get 抛 AttributeError → D5 blocked）。非 dict → 「证据不足」并留痕。
    if not isinstance(det, dict):
        return {"status": "insufficient", "raw_state": "证据不足",
                "detail": (f"确定性限值执行器返回非 dict 结果（{type(det).__name__}），"
                           f"类型守卫拦截，转人工补证"),
                "quote": "", "values": [], "spec": {},
                "guard": "limit_result_type",
                "applicability": "malformed_input"}
    st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
          "不适用": "not_applicable"}.get(str(det.get("state") or ""), "unknown")
    # L28 类型守卫：结果各字段按落库/渲染契约归一（monkeypatch/中间态返回脏结构不得抛异常）
    _viol = det.get("violations")
    _violations = ([str(x) for x in _viol if str(x).strip()]
                   if isinstance(_viol, (list, tuple)) else [])
    _vals = det.get("values")
    _values = list(_vals) if isinstance(_vals, (list, tuple)) else []
    _spec = det.get("spec")
    out = {"status": st, "raw_state": str(det.get("state") or ""),
           "detail": str(det.get("detail") or ""),
           "quote": str(det.get("quote") or ""),
           "violations": _violations,
           "values": _values,
           "applicability": str(det.get("applicability") or ""),
           "spec": _spec if isinstance(_spec, dict) else {}}
    if isinstance(det.get("guard"), str) and det.get("guard"):
        out["guard"] = det["guard"]
    return out


def _semantic_provenance_guard(out: dict, point: dict, rule: dict) -> dict:
    """TL-5（L169 接线）：语义判定（agent-judge）结果也受数值 provenance 守卫约束。

    主链 D4 在 ``provenance_scope`` 内调用本函数（见 ``_semantic_eval`` 调用点）；
    仅当文档级 provenance = vision（视觉/OCR 兜底来源）且判据为数值类时，把
    pass/fail 降级为证据不足（证据来源=vision_advisory，可审计）。
    无 provenance 上下文 / 非 vision 来源 → 原样返回（不改变既有行为；未知来源
    仍按各自入口原有 fail-closed 口径处理，不在本函数二次扩大拦截面）。
    """
    try:
        from ..engine import hooks as _hk
        prov = _hk.current_provenance()
        if not prov or str((prov or {}).get("status") or "") != "vision":
            return out
        if str((out or {}).get("status") or "") not in ("pass", "fail"):
            return out
        if not _hk.point_is_numeric(point or {}):
            return out
        g = _hk.guard_judgement(
            {"state": str(out.get("status") or ""),
             "detail": str(out.get("detail") or ""),
             "quote": str(out.get("quote") or "")},
            provenance=prov,
            rule_code=str((rule or {}).get("code") or (point or {}).get("id") or ""),
            source="manifest_exec.semantic_eval", numeric=True)
        if not g.get("provenance_blocked"):
            return out
        res = dict(out)
        res.update({"status": "insufficient", "provenance_blocked": True,
                    "suppressed_by": "no_numeric_provenance",
                    "evidence_source": "vision_advisory",
                    "original_status": str(out.get("status") or ""),
                    "detail": str(g.get("detail") or out.get("detail") or "")[:400]})
        return res
    except Exception:  # noqa: BLE001 - 守卫异常不改判定（与未接线时一致），仅留痕
        logging.getLogger(__name__).debug(
            "semantic provenance guard skipped", exc_info=True)
        return out


def _semantic_eval(rule: dict, sub: dict, text: str, path: str = "",
                   extra_hint: str = "", batch_cache: dict | None = None) -> dict:
    """语义子要求：走 agent-judge；硬超时/无模型/失败都返回 needs_model，不伪造 pass。

    extra_hint: 追加到点位判据末尾的复核口径（仅 D5 na 复核使用，见 _NA_RECHECK_HINT）。
    batch_cache: 轮 C 聚合判定预判结果（{id(sub): judge_row}）；命中时直接映射为语义结论，
                 未命中回落旧逐点位 agent 调用。默认 None = 旧逐点位行为（逐字段不变）。
    """
    import os as _os, threading as _th
    crit = str(sub.get("criterion") or sub.get("requirement") or "")
    if not crit or not text:
        return {"status": "needs_model", "detail": "缺少语义判据或文本"}
    # T-115：空间显式关闭 mod_agents 时主链不再执行 agent-judge（返回可解释的
    # needs_model，不伪造 pass/fail，也不混同“模型异常”）。
    if _module_off("mod_agents"):
        return {"status": "needs_model", "module_disabled": "mod_agents",
                "detail": "工作空间关闭智能体模块（mod_agents=false），未执行 agent-judge"}
    try:
        from .rule_card import audit_point as _apc
        point = _apc(rule, dict(sub))
    except Exception:
        point = {"id": str(sub.get("id") or "SEM"), "name": crit[:80],
                 "criterion": crit, "required_evidence": "原文逐字证据", "level": "warning"}
    if extra_hint:
        point = dict(point or {})
        point["criterion"] = (str(point.get("criterion") or "") + str(extra_hint)).strip()
        point["review_mode"] = "na_recheck"
    # 轮 C（RULEPROOF_JUDGE_BATCH=1）：命中聚合判定预判结果 → 直接映射（与旧路径同一套五态映射）。
    # 带 extra_hint 的复核调用不命中缓存（复核口径不同，必须单独判定）。
    if batch_cache is not None and not extra_hint:
        try:
            _bitem = batch_cache.get(id(sub))
        except Exception:
            _bitem = None
        if isinstance(_bitem, dict) and _bitem:
            st = str(_bitem.get("state") or "")
            mst = {"满足": "pass", "pass": "pass", "不满足": "fail", "fail": "fail",
                   "证据不足": "insufficient", "insufficient": "insufficient",
                   "不适用": "not_applicable", "na": "not_applicable"}.get(st, "unknown")
            _out = {"status": mst, "raw_state": st,
                    "detail": str(_bitem.get("rationale") or _bitem.get("reason") or "")[:300],
                    "quote": str(_bitem.get("quote") or ""),
                    "raw_item": {k: _bitem.get(k) for k in (
                        "state", "rationale", "reason", "quote", "confidence",
                        "issue_type")}}
            if _bitem.get("_batch_protocol_error"):
                # 聚合判定解析失败/截断/缺 code → fail-closed 已降 insufficient，审计旗标随结论落库
                _out["batch_protocol_error"] = True
                _out["raw_item"]["batch_protocol_error"] = True
            return _semantic_provenance_guard(_out, point, rule)
    try:
        from . import agents as _ag
        _timeout = float(_os.environ.get("RULEPROOF_SEMANTIC_TIMEOUT", "60") or 60)
        _box = {}

        def _call():
            try:
                _box["r"] = _ag.run_agent("agent-judge", {"path": path, "text": text, "points": [point]})
            except Exception as _e:
                _box["e"] = _e
        _t = _th.Thread(target=_call, daemon=True)
        _t.start(); _t.join(max(0.1, _timeout))
        if _t.is_alive():
            return {"status": "needs_model", "detail": f"agent-judge 超时（{_timeout:.0f}s）"}
        if "e" in _box:
            return {"status": "needs_model", "detail": f"agent-judge 异常：{type(_box['e']).__name__}"}
        r = _box.get("r") or {}
        if r.get("status") != "ok":
            return {"status": "needs_model", "detail": str(r.get("error") or "agent-judge 不可用")}
        res = ((r.get("result") or {}).get("results") or [])
        item = res[0] if res else {}
        if not item:
            # execute_points 只回失败项；pass/insufficient 在 point_state 里
            try:
                from . import auditpoints as _ap, pstates as _ps
                _rows = _ps.detail(getattr(_ap, "_BATCH", ""), limit=100)
                _hit = next((x for x in _rows if str(x.get("point_id")) == str(point.get("id"))), None)
                if _hit:
                    item = {"state": _hit.get("state"), "rationale": _hit.get("reason"),
                            "quote": _hit.get("quote")}
            except Exception:
                item = {}
        st = str(item.get("state") or "")
        mst = {"满足": "pass", "pass": "pass", "不满足": "fail", "fail": "fail",
               "证据不足": "insufficient", "insufficient": "insufficient",
               "不适用": "not_applicable", "na": "not_applicable"}.get(st, "unknown")
        _out = {"status": mst, "raw_state": st,
                "detail": str(item.get("rationale") or item.get("reason") or "")[:300],
                "quote": str(item.get("quote") or ""),
                "raw_item": {k: item.get(k) for k in ("state", "rationale", "reason", "quote", "confidence", "issue_type")}}
        return _semantic_provenance_guard(_out, point, rule)
    except Exception as e:
        return {"status": "needs_model", "detail": f"{type(e).__name__}: {e}"}


# ---------------- D5 na 复核（T-42 / 2026-11-17） ----------------
# 背景（P01 真实归因）：D5 na 79 条全部来自 D4 语义子要求 not_applicable，D1 冻结路由为 applicable；
# 典型理由是"文档未提供注册证书/报表/清单等（所需证据类别）→ 业务未触发"，而规则包缺证处理明确
# "业务触发成立后缺材料不能判不适用"。即：模型把"证据载体缺失"误当"业务不适用"，属静默漏判。
# 修复口径：判 not_applicable 时带证据口径复核一次；只有复核给出 fail（引文仍走既有逐字 gate）才替换结论，
# 其余保持原判（不伪造 fail、不伪造 pass）。复核结论写进 D4 sub.tool_trace.na_recheck 供审计/报告。
# 2026-11-17 T-42 A/B（P01 5 份，两轮）：召回 +1/+2，误报 +0/+4（两轮均值 +2），未达"误报不恶化"，
# 因此该能力默认关闭（实验开关），待复核结论的码归属校验解决后再评估是否默认启用。
_NA_RECHECK_ENV = "RULEPROOF_NA_RECHECK"
_NA_RECHECK_DEFAULT = "0"
_NA_RECHECK_HINT = (
    "；不适用复核：本规则的缺证处理声明“业务触发成立后缺材料不能判不适用”。"
    "①适用范围/所需证据类别只是审查线索：文档中出现该业务主题的条款、要求、对象或数值"
    "（如资格要求、报价金额、日期期限、条编号、单位、提交要求）即视为业务触发成立；"
    "证据载体（证书、报表、清单、附件、审批记录）未以该形式出现，不构成不适用，应按判据判断"
    "（证据不足→insufficient）；"
    "②仅当整篇文档完全不含该业务主题时才保留 na；"
    "③若原文已能看出与判据不符的事实（同一事实/数值/日期/编号/单位在不同位置不一致、矛盾、越界），"
    "判 fail 并逐字引用原文；④复核结论必须引用原文逐字片段，不得编造。")


def _na_recheck_enabled(slots: dict) -> bool:
    """是否对该语义点位做 na 复核：规则包缺证处理口径 + 环境开关（默认关，实验/复测用）。"""
    if str(os.environ.get(_NA_RECHECK_ENV, _NA_RECHECK_DEFAULT)).strip().lower() in (
            "0", "false", "no", "off"):
        return False
    slots = slots if isinstance(slots, dict) else {}
    if slots.get("na_recheck"):
        return True
    # 兼容旧冻结清单：判据文本自带缺证处理口径时同样复核（不依赖新导入标记）
    return "不能判不适用" in str(slots.get("criterion") or "")


# D4 insufficient 复核（2026-11-22）：把 na 复核的触发面从 not_applicable 扩到 insufficient。
# 背景：P01 30 份无 finding FN 里 46/164 是 D4 判 insufficient（证据不足弃权），
# 其 rationale 46/46 是「未提供/未见/无…」= 把所需证据载体缺失当成结论；
# 而旧的 na 复核只对 not_applicable 触发，insufficient 一条都复核不到（实测 0 条）。
# 产品语义变更 → 必须默认关（RULEPROOF_NA_RECHECK_INSUFFICIENT=1 才生效），
# 且复核只允许把 insufficient 替换为 **fail**（不伪造 pass/na），其余保持原判。
_NA_RECHECK_INSUFFICIENT_ENV = "RULEPROOF_NA_RECHECK_INSUFFICIENT"
_NA_RECHECK_INSUFFICIENT_DEFAULT = "0"
_NA_RECHECK_INSUFFICIENT_HINT = (
    "；证据不足复核：上一轮该点位判「证据不足（insufficient）」。复核口径："
    "①规则对象/字段在文档中**存在**，只是所需数值/信息需要从正文、表格、附件清单、"
    "执行记录（TJ/JS/JL/BZ 等编号行）或计算过程里逐处查找——必须回原文检索后再下结论，"
    "不得停留在“未提供/未见/无该载体”；"
    "②若原文已存在与判据不符的事实（数值越界、前后矛盾、版本/编号/日期/单位不一致、缺步骤、"
    "同一事实不同取值），判 fail 并逐字引用原文；"
    "③确实找不到任何可判依据 → 保留 insufficient 并说明已检索的位置；"
    "④复核只允许输出 fail 或 insufficient，不得判 pass/na。")


def _na_recheck_insufficient_enabled() -> bool:
    """insufficient 复核开关：默认关；仅显式 1/true/on/yes 生效（产品语义变更）。"""
    return str(os.environ.get(_NA_RECHECK_INSUFFICIENT_ENV,
                              _NA_RECHECK_INSUFFICIENT_DEFAULT)).strip().lower() in (
        "1", "true", "yes", "on")


def _maybe_recheck_insufficient(se: dict, rule: dict, sub: dict, text: str,
                                path: str = "") -> dict:
    """D4 insufficient → 证据口径复核一次；只有复核给出 fail 才替换结论。

    开关关闭时**不调用模型**、不改 se（逐字段一致）；开关打开且首判 insufficient 时
    *_semantic_eval* 带 _NA_RECHECK_INSUFFICIENT_HINT 复核，结论写 se["na_recheck_insufficient"]。
    """
    if not isinstance(se, dict):
        return se
    if str(se.get("status") or "") != "insufficient":
        return se
    if not _na_recheck_insufficient_enabled():
        return se
    se2 = _semantic_eval(rule, sub, text, path, extra_hint=_NA_RECHECK_INSUFFICIENT_HINT)
    nr = {"attempted": True, "first": "insufficient",
          "second": str(se2.get("status") or ""),
          "accepted": str(se2.get("status")) == "fail",
          "source": "manifest_exec.na_recheck_insufficient"}
    if str(se2.get("status")) == "fail":
        se = dict(se2)
    return {**se, "na_recheck_insufficient": nr}


# ===========================================================================
# 轮 C（2026-11-22）：单文档聚合判定（batch judging，RULEPROOF_JUDGE_BATCH，默认 0）
#
# 背景（docs/qa/L11成本削减归因_20261122.md，实测）：A 臂每文档 12.92 次点位判定调用，
# 其中 1,230/1,447（85.0%）是「同文档 + 单点位 + 整篇全文」调用，占 tokens_in 95.4%；
# 而 `auditpoints._judge_points(points: list)` / `_build_judge_messages` 原生支持一次判多点位。
#
# 本段是**调用方**改造（最小改动）：
#   · 主循环之前预判：把本 manifest 全部「可能走 agent-judge 的语义子要求」按可见文本分组，
#     每组经既有 agent-judge（`agents.run_agent`，保留 agent_run/llm_trace 落库）一次判定
#     最多 N 个点位（auditpoints 内部分片 ≤24）；结果按 id(sub) 缓存；
#   · 主循环 `_semantic_eval` 命中缓存 → 直接映射（同一套五态映射），未命中 → 回落旧逐点位路径；
#   · 开关=0（默认）→ 本段完全不执行，旧路径逐字段不变。
#   · 预判只覆盖「D1 适用 + D2 绑定 + D3 可评估 + A1 闭包内」的 item×子要求；预判不到的
#     item/子要求仍走旧逐点位调用 → 只可能少省 token，不可能改变结论口径。
# ===========================================================================
_JUDGE_BATCH_ENV = "RULEPROOF_JUDGE_BATCH"
_JUDGE_BATCH_TIMEOUT_ENV = "RULEPROOF_JUDGE_BATCH_TIMEOUT"


def _judge_batch_enabled() -> bool:
    """RULEPROOF_JUDGE_BATCH 主链门控（P0-5 单一事实源：直接委托 auditpoints.judge_batch_enabled()）。

    2026-11-23 修复「默认值分裂」：此前本模块独立默认 0、auditpoints 默认 1，导致未设置 env 时
    「主链逐点位 / 直接多点位调用方聚合」两种轨迹并存，无法用单一声明背书。
    现只保留一个解析点（auditpoints.judge_batch_enabled），本函数不保留自己的默认值分支：
    显式 0 / 显式 1 / 未设置三种环境下两处解析一致；默认 0 = 主链现行逐点位，零行为变化。
    若改默认 1 须单独发布决定 + 重跑 L1 全量（见 auditpoints.judge_batch_enabled docstring）。
    """
    from .auditpoints import judge_batch_enabled
    return judge_batch_enabled()


# BX 操作数复用（2026-11-23 实验开关，默认 0 = 现行为；=1 时在 auditpoints 判定层启用）：
# 实现全部在 auditpoints（操作数表抽取 + 模板化输出 + 引文物化）；manifest_exec 只做
# 开关门控与 meta 记账（单一事实源，本函数不读 os.environ）。
def _bx_operand_reuse_enabled() -> bool:
    """RULEPROOF_BX_OPERAND_REUSE 主链门控（委托 auditpoints.bx_operand_reuse_enabled）。"""
    from .auditpoints import bx_operand_reuse_enabled
    return bx_operand_reuse_enabled()


def _judge_batch_document(mid: str, case_id: str, items: list, docs_by_id: dict,
                          case_row: dict, parse_cache: dict, sheet_cache: dict,
                          binding_by_rid: dict | None = None) -> tuple:
    """单文档聚合判定预判：返回 ({id(sub): judge_row}, meta)。

    只做「收集 + 一次批量判定 + 结果缓存」，不落结论；协议异常点位由 auditpoints 层 fail-closed
    降级 insufficient 并带 `_batch_protocol_error` 标记，本函数汇总后写审计（judge.batch*）。
    """
    meta = {"enabled": True, "used": False, "groups": 0, "points": 0, "cached": 0,
            "calls": 0, "protocol_errors": 0, "degraded_points": [],
            "run_failures": 0, "timeouts": 0, "fallback": ""}
    # BX 操作数复用实验（默认 0）：仅在开关=1 时记账，关闭时 meta 逐字段不变。
    if _bx_operand_reuse_enabled():
        meta["bx_operand_reuse"] = True
    cache = {}
    if not items:
        meta["fallback"] = "no_items"
        return cache, meta
    # 无模型 / 模块关闭 → 不预判（主循环旧路径返回 needs_model，行为不变）
    try:
        from .extract import _provider
        if _provider() is None:
            meta["fallback"] = "no_model"
            return cache, meta
    except Exception:
        meta["fallback"] = "provider_error"
        return cache, meta
    if _module_off("mod_agents"):
        meta["fallback"] = "mod_agents_disabled"
        return cache, meta
    groups = {}
    for item in items:
        try:
            obj = str(item.get("object_id") or "")
            doc = docs_by_id.get(obj) or _doc(case_id, obj)
            # A1 冻结闭包：越界对象在主循环会被丢弃，不预判
            if binding_by_rid:
                _bind = (binding_by_rid.get(str(item.get("rule_id") or ""))
                         or binding_by_rid.get("code:" + str(item.get("code") or "")))
                _allowed = {str(x) for x in (_bind or {}).get("allowed_object_ids") or []}
                if _allowed and obj not in _allowed:
                    continue
            d1 = _d1_from_frozen_route(item, case_row, doc)
            if str(d1.get("status") or "") != "applicable":
                continue
            r = R.rules.get(item.get("rule_id") or "") or {}
            slots = item.get("slots") if isinstance(item.get("slots"), dict) else None
            if slots is None:
                v = R.rules.latest_version(item.get("rule_id") or "") or {}
                try:
                    slots = json.loads(v.get("slots_json") or "{}")
                except Exception:
                    slots = {}
            if not (r and (slots or item.get("version"))):
                continue
            path = (doc or {}).get("path") or ""
            text, parsed, parse_error = _parse_document_cached(doc, parse_cache)
            if parse_error or not str(text or "").strip():
                continue
            subs = item.get("subrequirements") or []
            _sheet = _sheet_scope(doc, text, parsed, sheet_cache)
            _sheet_rule_spec = _rule_sheet_limit(item, slots)
            _sheet_sub_specs = []
            for _si, _sub0 in enumerate(subs or []):
                _sp = (_sheet_limit_spec(_sub0) if isinstance(_sub0, dict)
                       else _sheet_limit_spec({}))
                if _sp.get("requested"):
                    _sheet_sub_specs.append((_si, _sp))
            _sheet_limit = _sheet_limit_summary(doc, parsed, _sheet, _sheet_rule_spec,
                                                _sheet_sub_specs, parse_error)
            if not _sheet_limit.get("available"):
                continue
            _rule_sheet = (_norm_sheet(_sheet_limit.get("sheet"))
                           if _sheet_limit.get("requested") else "")
            _scopes_req = list((item.get("execution_hints") or {}).get("evidence_scope")
                               or ["document"])
            _dtp = str((doc or {}).get("doc_type") or "").lower()
            _has_rows = _dtp in ("xlsx", "xls") or "\n" in text
            _avail = {"document": bool(text.strip()), "block": bool(text.strip()),
                      "row": bool(text.strip()) and _has_rows,
                      "sheet": bool(_sheet.get("available"))
                      and bool(_sheet_limit.get("available")),
                      "document_set": "document_set" not in _scopes_req}
            if any(not _avail.get(x, False) for x in _scopes_req):
                continue
            _sub_sheet_map = dict(_sheet_limit.get("sub_sheets") or {})
            for i, sub in enumerate(subs or [slots]):
                sub = sub or {}
                _sub_sheet = _norm_sheet(_sub_sheet_map.get(f"sub:{i}")) or _rule_sheet
                _sub_text = (_sheet_text_for(parsed, _sub_sheet) if _sub_sheet else text)
                if not str(_sub_text or "").strip():
                    continue
                try:
                    from .rule_card import audit_point as _apc
                    point = _apc(r, dict(sub))
                except Exception:
                    _crit = str(sub.get("criterion") or sub.get("requirement") or "")
                    point = {"id": str(sub.get("id") or "SEM"), "name": _crit[:80],
                             "criterion": _crit,
                             "required_evidence": "原文逐字证据", "level": "warning"}
                if not str(point.get("criterion") or "").strip():
                    continue
                _g = groups.get(_sub_text)
                if _g is None:
                    _g = groups[_sub_text] = {"text": _sub_text, "path": path, "reqs": []}
                _g["reqs"].append((sub, point))
        except Exception:
            # 预判是纯优化路径：任何单 item 异常都跳过（主循环旧路径兜底），不得影响结论
            logging.getLogger(__name__).debug("judge batch collect skipped", exc_info=True)
            continue
    meta["groups"] = len(groups)
    meta["points"] = sum(len(g["reqs"]) for g in groups.values())
    if not groups:
        meta["fallback"] = "no_group"
        return cache, meta
    _timeout = float(os.environ.get(_JUDGE_BATCH_TIMEOUT_ENV, "300") or 300)
    for g in groups.values():
        _reqs = g["reqs"]
        pts, _idmap = [], {}
        for sub, p in _reqs:
            pid = str(p.get("id") or "SEMANTIC")
            if pid in _idmap:
                n = 1
                while f"{pid}#{n}" in _idmap:
                    n += 1
                pid = f"{pid}#{n}"
            q = dict(p)
            q["id"] = pid
            pts.append(q)
            _idmap[pid] = id(sub)
        _box = {}

        def _call(_pts=pts, _path=g.get("path") or "", _text=g["text"]):
            try:
                from . import agents as _ag
                _box["r"] = _ag.run_agent("agent-judge",
                                          {"path": _path, "text": _text, "points": _pts})
            except Exception as _e:  # noqa: BLE001 - 由下方统一转为回落
                _box["e"] = _e

        import threading as _th
        _t = _th.Thread(target=_call, daemon=True)
        _t.start()
        _t.join(max(1.0, _timeout))
        if _t.is_alive():
            meta["timeouts"] += 1
            logging.getLogger(__name__).warning(
                "聚合判定超时（%.0fs，%d 点位）→ 回落逐点位", _timeout, len(pts))
            continue
        if "e" in _box:
            meta["run_failures"] += 1
            logging.getLogger(__name__).warning(
                "聚合判定异常 %s → 回落逐点位", type(_box["e"]).__name__)
            continue
        _r = _box.get("r") or {}
        _res = ((_r.get("result") or {}).get("results") or [])
        if _r.get("status") != "ok" or not _res:
            meta["run_failures"] += 1
            logging.getLogger(__name__).warning(
                "聚合判定不可用（status=%s, results=%d）→ 回落逐点位",
                _r.get("status"), len(_res))
            continue
        meta["used"] = True
        meta["calls"] += 1
        _by_code = {}
        for row in _res:
            if not isinstance(row, dict):
                continue
            _code = str(row.get("code") or "")
            if not _code or _code in _by_code:
                continue
            _by_code[_code] = row
        _ok = 0
        for _pid, _subkey in _idmap.items():
            _row = _by_code.get(_pid)
            if _row is None:
                # agent 层已 fail-closed 该点位；此处只兜底（正常不应发生）
                _row = {"code": _pid, "state": "insufficient", "confidence": None,
                        "quote": "", "_batch_protocol_error": True,
                        "rationale": "聚合判定未返回该点位结果（fail-closed 降级，转人工）"}
            if _row.get("_batch_protocol_error"):
                meta["protocol_errors"] += 1
                meta["degraded_points"].append(_pid)
            cache[_subkey] = _row
            _ok += 1
        meta["cached"] += _ok
    # 协议异常 → 留审计（fail-closed 降级的点位数、涉及点位、批次/分组信息）
    try:
        if meta["used"]:
            R.audit_logs.log(
                actor="system", action="judge.batch", object=str(mid or ""),
                after=json.dumps({k: meta[k] for k in (
                    "groups", "points", "cached", "calls", "protocol_errors",
                    "run_failures", "timeouts")}, ensure_ascii=False))
        if meta["protocol_errors"]:
            R.audit_logs.log(
                actor="system", action="judge.batch_protocol_error",
                object=str(mid or ""),
                after=json.dumps({"degraded_points": meta["degraded_points"][:50],
                                  "protocol_errors": meta["protocol_errors"],
                                  "policy": "fail_closed_insufficient",
                                  "cause": "JSON解析失败/截断/输出缺code（重试缺失项后仍缺）"},
                                 ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("judge batch audit skipped", exc_info=True)
    return cache, meta


def _dmn_cond_metrics(when) -> list:
    """递归提取决策表行条件里的 metric（all/any/not），保持声明顺序。"""
    out = []

    def _walk(cond):
        if isinstance(cond, (list, tuple)):
            for one in cond:
                _walk(one)
            return
        if not isinstance(cond, dict):
            return
        if cond.get("metric"):
            out.append(str(cond["metric"]))
        for key in ("all", "any"):
            if isinstance(cond.get(key), (list, tuple)):
                _walk(cond[key])
        if isinstance(cond.get("not"), dict):
            _walk(cond["not"])

    _walk(when)
    return list(dict.fromkeys([x for x in out if x]))


def _dmn_rules_for_hit(code: str, version: str, fallback: list) -> list:
    """命中行条件以实际求值版本为准：冻结版本优先取版本快照，避免当前表漂移。"""
    rules = list(fallback or [])
    if not version:
        return rules
    try:
        rows = R.decision_tables.list("code=?", (str(code),))
        if rows:
            hist = R.decision_table_versions.list("table_id=?", (rows[0]["id"],), order="id DESC")
            ver = next((x for x in hist if str(x.get("version") or "") == str(version)), None)
            if ver:
                got = json.loads(ver.get("rules_json") or "[]")
                if isinstance(got, list):
                    return got
    except Exception:
        logging.getLogger(__name__).debug("dmn version rules lookup skipped", exc_info=True)
    return rules


def _line_no_of(text: str, line: str) -> int:
    """原文行号（1-based）；找不到返回 0，不猜。"""
    for i, raw in enumerate(str(text or "").splitlines(), 1):
        if raw == line:
            return i
    return 0


def _section_for_line(parsed, line: str, line_no: int):
    """把原文行映射回 deepparse section（复用其既有 anchor：段落/页/sheet）。"""
    secs = list(getattr(parsed, "sections", None) or [])
    if not secs or not line:
        return None
    if 0 < line_no <= len(secs):
        sec = secs[line_no - 1]
        st = str(getattr(sec, "text", "") or "")
        if st == line or (line in st) or (st and st in line):
            return sec
    for sec in secs:
        st = str(getattr(sec, "text", "") or "")
        if st and (st == line or line in st or st in line):
            return sec
    return None


_SOURCE_CELL_RE = re.compile(r"^(.+?)!([A-Za-z]{1,3})(\d+)$")


def _existing_quote_location(path: str, quote: str) -> dict:
    """复用既有锚点定位：xlsx→Sheet!单元格，docx/pdf→第 N 段/页。"""
    if not path or not quote:
        return {}
    try:
        from . import auditpoints as _ap
        loc = _ap.locate_quote(path, quote)
        return loc if isinstance(loc, dict) else {}
    except Exception:
        logging.getLogger(__name__).debug("existing quote location skipped", exc_info=True)
        return {}


def _norm_sheet(name) -> str:
    return str(name or "").strip()


def _locate_in_sheet(path: str, sheet: str, quote: str) -> dict:
    """只在指定 sheet 内定位原文：返回 Sheet!单元格，绝不跨 sheet 兜底。"""
    target = _norm_sheet(sheet)
    q = str(quote or "").strip()
    if not path or not target or not q:
        return {}
    try:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = next((w for w in wb.worksheets if _norm_sheet(w.title) == target), None)
            if ws is None:
                return {}
            for row in ws.iter_rows():
                for cell in row:
                    v = cell.value
                    if v is None:
                        continue
                    sv = str(v)
                    # 与既有一致：整段命中或单元格文本出现在引用里；但仅限目标 sheet。
                    if (q[:20] and q[:20] in sv) or (sv and sv in q):
                        return {"locator": f"{ws.title}!{cell.coordinate}",
                                "quote": sv[:80], "sheet": ws.title}
        finally:
            try:
                wb.close()
            except Exception:
                pass
    except Exception:
        logging.getLogger(__name__).debug("sheet-limited quote location skipped", exc_info=True)
    return {}


def _source_trace_fields(hit: dict) -> dict:
    """把命中行对应的原文定位写进 D4 tool_trace（供报告/复核读取）。"""
    hit = hit or {}
    return {
        "source_location_missing": bool(hit.get("source_location_missing")),
        "source_locator": str(hit.get("source_locator") or ""),
        "source_quote": str(hit.get("source_quote") or ""),
        "source_row": int(hit.get("source_row") or 0),
        "source_sheet": str(hit.get("source_sheet") or ""),
        "source_col": str(hit.get("source_col") or ""),
        "source_metric": str(hit.get("source_metric") or ""),
        "source_reason": str(hit.get("source_reason") or ""),
    }


def _fact_value_matches(value, fact) -> bool:
    """原文里取到的值必须与实际参与求值的 fact 一致，避免拿同指标不同值的行冒充证据。"""
    vals = fact if isinstance(fact, (list, tuple, set)) else [fact]
    for one in vals:
        try:
            if abs(float(value) - float(one)) < 1e-9:
                return True
        except Exception:
            if str(value).strip() == str(one).strip():
                return True
    return False


def _source_location_for_hit(hit: dict, rules: list, text: str, parsed,
                              path: str = "", facts: dict = None,
                              sheet_limit: str = "", aliases: dict = None) -> dict:
    """用命中行的条件 metric 从原文定位行/单元格；定位失败显式标记，不伪造。

    sheet_limit 非空时只允许返回该 sheet 的坐标：定位到别的 sheet 视为未定位，
    避免拿同一文本在其它 sheet 的单元格冒充限定证据。
    """
    row_no = int((hit or {}).get("row") or 0)
    when = []
    if 0 < row_no <= len(rules or []):
        when = (rules[row_no - 1] or {}).get("when") or []
    metrics = _dmn_cond_metrics(when)
    base = {
        "source_location_missing": True, "source_locator": "", "source_quote": "",
        "source_row": 0, "source_sheet": "", "source_col": "",
        "source_metric": metrics[0] if metrics else "",
        "source_reason": "no_condition_metric" if not metrics else "not_found",
    }
    if not metrics or not text:
        return base
    doc_type = str(getattr(parsed, "doc_type", "") or "").lower()
    if not doc_type and path and "." in path:
        doc_type = path.rsplit(".", 1)[-1].lower()
    for metric in metrics:
        if not facts or metric not in facts:
            continue
        fact = facts.get(metric)
        try:
            occs = _frozen_all_from_text(metric, text, aliases)
        except Exception:
            occs = []
        for occ in (occs or [])[:5]:
            if not _fact_value_matches((occ or {}).get("value"), fact):
                continue
            line = str((occ or {}).get("line") or (occ or {}).get("quote") or "")
            if not line:
                continue
            quote = line[:300]
            line_no = _line_no_of(text, line)
            if doc_type in ("xlsx", "xls"):
                _lookup = str((occ or {}).get("quote") or line)
                got = (_locate_in_sheet(path, sheet_limit, _lookup)
                       if sheet_limit else _existing_quote_location(path, _lookup))
                loc = str((got or {}).get("locator") or "")
                cell = _SOURCE_CELL_RE.match(loc)
                if cell:
                    if sheet_limit and _norm_sheet(cell.group(1)) != _norm_sheet(sheet_limit):
                        continue
                    return {**base, "source_location_missing": False,
                            "source_locator": loc, "source_quote": quote,
                            "source_row": int(cell.group(3)), "source_sheet": cell.group(1),
                            "source_col": cell.group(2), "source_metric": metric,
                            "source_reason": "cell"}
            sec = _section_for_line(parsed, line, line_no)
            anchor = str(getattr(sec, "anchor", "") or "").strip() if sec else ""
            if doc_type in ("xlsx", "xls"):
                # 只有 sheet、没有真实单元格时不把解析序当 Excel 行
                if anchor and not base["source_sheet"]:
                    base["source_sheet"] = anchor
                    base["source_reason"] = "sheet_only"
                continue
            if doc_type in ("txt", "md", "markdown") or not doc_type:
                _row = line_no or (int(re.search(r"(\d+)", anchor).group(1))
                                   if anchor and re.search(r"(\d+)", anchor) else 0)
                if _row:
                    return {**base, "source_location_missing": False,
                            "source_locator": f"第 {_row} 行", "source_quote": quote,
                            "source_row": _row, "source_metric": metric,
                            "source_reason": "line"}
                continue
            if anchor:
                _m = re.search(r"(\d+)", anchor)
                return {**base, "source_location_missing": False,
                        "source_locator": anchor, "source_quote": quote,
                        "source_row": int(_m.group(1)) if _m else line_no,
                        "source_metric": metric, "source_reason": "parsed_anchor"}
    return base


def _business_audit_types(item: dict, case: dict = None) -> list:
    """F-22：决策表/业务 scope 的 audit_type 只能是业务文件类型，不能是文件扩展名。

    优先取冻结路由里的业务类型上下文（audit_route.case_document_type /
    case_audit_type / business_scope），再回退到 case 的 document_type/audit_type；
    扩展名（docx/xlsx…）不进入候选，避免 evaluate_frozen 用 ``doc_type='docx'``
    与决策表 scope_types=['食品工艺书'] 比较必然 not in → 假 skipped。
    """
    route = (item or {}).get("audit_route") or {}
    case = case or {}
    cands = []

    def _push(v):
        v = str(v or "").strip()
        if v and not _scope_token_is_file(v) and v not in cands:
            cands.append(v)

    for key in ("case_document_type", "case_audit_type"):
        _push(route.get(key))
    for token in (route.get("business_scope") or []):
        _push(token)
    for key in ("document_type", "audit_type"):
        _push(case.get(key))
    return cands


def _eval_decision_tables(item: dict, text: str, case_id: str = "", external_facts: dict = None,
                          parsed=None, path: str = "", sheet_limit: str = "",
                          case: dict = None) -> dict:
    """执行规则声明的 DMN 决策表；支持外部 facts 与多表策略。

    命中行同时用条件 metric 回原文定位行/单元格，写入 hit 供 D4/报告消费；
    定位不到时置 source_location_missing=True，保留决策表 locator，不伪造。
    sheet_limit 非空时 facts/定位都只用该 sheet 的文本，且定位不得跨 sheet。
    """
    codes = item.get("decision_tables") or []
    if isinstance(codes, str):
        codes = [codes]
    out = []
    for _spec in codes:
        try:
            from . import decision_table as _dt
            snap = _spec if isinstance(_spec, dict) else {}
            code = str((snap or {}).get("code") or _spec)
            if snap.get("status"):
                out.append({"code": code, "state": snap.get("status"),
                            "version": snap.get("version") or ""}); continue
            d = _dt.detail(str(code))
            if not d:
                out.append({"code": code, "state": "missing"}); continue
            facts = dict(external_facts or {})
            for row in d.get("rules") or []:
                for cond in row.get("when") or []:
                    metric = str((cond or {}).get("metric") or "")
                    if metric and metric not in facts:
                        try:
                            from ..engine import ruleexec as _re
                            val, quote = _frozen_from_text(metric, text,
                                                           _item_onto_aliases(item))
                            if val is not None:
                                facts[metric] = val
                        except Exception:
                            pass
            # F-22：audit_type 传业务文档类型（case.document_type / 冻结路由），
            # 不传文件扩展名；多个候选业务类型逐个求值，取第一个非 skipped 结果。
            _atypes = _business_audit_types(item, case) or [""]
            res = {}
            for _at in _atypes:
                if snap.get("version"):
                    res = _dt.evaluate_frozen(snap, facts, audit_type=_at, case_id=case_id)
                    _hit_rules = _dmn_rules_for_hit(code, snap.get("version"), d.get("rules") or [])
                else:
                    res = _dt.evaluate(str(code), facts, audit_type=_at, case_id=case_id)
                    _hit_rules = d.get("rules") or []
                if _dt._result_state(res) != "skipped":
                    break
            for _h in (res.get("hits") or []):
                try:
                    _h.update(_source_location_for_hit(_h, _hit_rules, text, parsed, path, facts,
                                                       sheet_limit=sheet_limit,
                                                       aliases=_item_onto_aliases(item)))
                except Exception:
                    logging.getLogger(__name__).debug("dmn source location skipped", exc_info=True)
                    _h.update(_source_trace_fields({"source_location_missing": True,
                                                    "source_reason": "locate_error"}))
            _rstate = _dt._result_state(res)
            out.append({"code": str(code), "version": snap.get("version") or d.get("version"),
                        "hit_policy": snap.get("hit_policy") or d.get("hit_policy"),
                        "state": _rstate,
                        "skipped": res.get("skipped") or "",
                        "hits": res.get("hits") or [], "facts": facts,
                        "error": res.get("error") or ""})
        except Exception as e:
            out.append({"code": str(code), "state": "error", "error": f"{type(e).__name__}: {str(e)[:160]}"})
    matches = [x for x in out if x.get("state") == "match" and x.get("hits")]
    conflict = next((x for x in out if x.get("state") == "conflict"), None)
    # 决策表不可用/版本缺失/执行错误不得落回 ruleexec 或语义分支，直接 fail-closed。
    _bad = next((x for x in out if x.get("state") in
                 ("error", "missing", "missing_or_unpublished", "unpublished")), None)
    if _bad and not conflict:
        conflict = {"code": _bad.get("code") or "", "version": _bad.get("version") or "",
                    "hit_policy": "error", "hits": [], "facts": {},
                    "result": "error", "error": _bad.get("error") or _bad.get("state")}
    policy = str(item.get("decision_policy") or "conflict")
    if len(matches) > 1 and policy == "conflict":
        conflict = {"code": ",".join(str(x.get("code")) for x in matches),
                    "version": "", "hit_policy": "multi",
                    "hits": [h for x in matches for h in (x.get("hits") or [])],
                    "facts": {}, "result": "conflict",
                    "error": "多张决策表同时命中且未声明优先级"}
    match = matches[0] if matches else None
    return {"results": out, "match": match, "matches": matches,
            "conflict": conflict, "decision_policy": policy}


def _evidence_terms(req) -> list:
    """required_evidence 归一：str / list / tuple / set / dict 一律展开为词列表。

    F-11：数组写法不得被 ``str(list)`` 成 "['原文']" 字面量再去正文匹配；
    D3 与 D4 必须读同一份归一化证据词（本函数是唯一入口）。
    """
    import re as _re
    raw = req
    if raw is None or raw == "":
        return []
    if isinstance(raw, dict):
        raw = (raw.get("terms") or raw.get("required_evidence")
               or raw.get("evidence_required") or raw.get("items") or [])
    if isinstance(raw, (list, tuple, set)):
        items = list(raw)
    else:
        items = [raw]
    out = []
    for item in items:
        if isinstance(item, (list, tuple, set)):
            # 嵌套数组（如 [{terms:[...]}]）继续展开
            out.extend(_evidence_terms(item))
            continue
        if isinstance(item, dict):
            out.extend(_evidence_terms(item))
            continue
        for term in _re.split(r"[、,，;；/]", str(item or "")):
            term = term.strip()
            if term and term not in out:
                out.append(term)
    return out


def _required_evidence_text(req) -> str:
    """归一化证据词的稳定文本（D3 展示/快照与 D4 校验同源）。"""
    return "、".join(_evidence_terms(req))


def _evidence_ok(req, text: str) -> tuple[bool, str]:
    """子要求证据检查：宽松匹配；只检查显式 required_evidence，不猜。

    F-11：入口先归一化容器（list/tuple/dict），逐项匹配；禁止对容器 str()。
    数组与字符串两种写法对同一文档必须得到一致结论。
    """
    terms = _evidence_terms(req)
    if not terms:
        return True, ""
    t = text or ""
    for term in terms:
        base = term
        for suf in ("分析", "说明", "记录", "报告", "材料", "文件"):
            base = base.replace(suf, "")
        # 过短/泛化的证据名（如“名单”）不当字面证据，避免整份表都被误判缺证
        if len(term) <= 2:
            continue
        if term not in t and (not base or base not in t):
            return False, term
    return True, ""


def _item_evidence_required(item: dict):
    """规则级 required_evidence 唯一读取口径（D3 展示与 D4 回退同一份，F-11）。"""
    item = item or {}
    slots = item.get("slots") if isinstance(item.get("slots"), dict) else {}
    return (item.get("evidence_required") or slots.get("required_evidence")
            or slots.get("evidence_required") or "")


# ---------------------------------------------------------------- fail 引文逐字门禁（P0）
# 规则（用户优先级 5）：fail 结论的 evidence quote 必须**逐字**在归属于该 finding 的
# 对象原文/目标单元格内命中；不命中（缺失/改写/跨 sheet/跨文件串位）一律降级
# insufficient + 人工复核，不得以 fail 落 finding，不得 certainty=certain。
# 允许空白差异（与平台既有引文核验口径 _rea_norm_text 一致），不允许改写或拼接。
_QUOTE_WS = re.compile(r"\s+")
# A4（2026-11-21）：空白只折叠、不删除 —— 仅 CJK 字符 **之间** 的空白可删。
# 修前 `_QUOTE_WS.sub("")` 去全部空白，导致 "1 2" 与 "12" 归一后相等：
# 错误数值引文（多/少一个空格）可凭空白差异通过逐字核验，进而支撑 fail。
_CJK_RANGE = (r"\u2e80-\u2eff\u3000-\u303f\u3040-\u30ff\u3400-\u4dbf"
              r"\u4e00-\u9fff\uf900-\ufaff\ufe30-\ufe4f\uff00-\uffef")
_CJK_WS_RE = re.compile(rf"(?<=[{_CJK_RANGE}])\s+(?=[{_CJK_RANGE}])")
_QUOTE_WRAPS = "“”\"'「」『』`"
_QUOTE_CELL_RE = re.compile(r"^(.+?)!([A-Za-z]{1,3})(\d+)$")
_QUOTE_MIN_LEN = 4
_QUOTE_GATE_DETAIL = "证据门禁：引文未逐字命中归属对象的原文/单元格，降级为证据不足，转人工复核"


def _collapse_quote_ws(text) -> str:
    """引文/原文统一空白口径：CJK 之间的空白删除，其余连续空白折叠为**单空格**。

    与平台既有 ``_rea_norm_text`` 的“允许空白差异”同源，但不再把非 CJK 空白吞掉，
    保证 "1 2" ≠ "12"、"25 CFU/g" ≠ "25CFU/g"（数值/单位必须按原样核验）。
    """
    s = _CJK_WS_RE.sub("", str(text or ""))
    return _QUOTE_WS.sub(" ", s).strip()


def _norm_quote(text) -> str:
    s = _collapse_quote_ws(text)
    return s.strip(_QUOTE_WRAPS)


def _quote_verbatim(quote, text, min_len: int = _QUOTE_MIN_LEN) -> bool:
    """引文逐字命中：归一空白/包裹引号后必须为原文子串（过短引文不算证据）。

    ``min_len`` 仅由多段引文的「短数值/比较符段」核验路径下调（A4：这类段必须强制
    核验，不能因长度 <4 被当作 trivial 跳过）；单段引文仍用默认阈值。
    """
    q = _norm_quote(quote)
    t = _collapse_quote_ws(text)
    return bool(q) and len(q) >= int(min_len) and q in t


# P0-6（T-181）：多段引文按「；」切分后，纯标点段（如「；。」切出的「。」）永远锚不上，
# 会把整条真引文降 insufficient。修法：逐段校验前跳过**纯标点/过短**段；非平凡段仍保持
# 「全部命中」语义（不放宽），真不在原文的段照旧使整条引文失败。开关用于回滚/A-B。
_P0_QUOTE_SEG_ENV = "RULEPROOF_P0_QUOTE_SEG_SKIP"
_QUOTE_WORD_RE = re.compile(r"[0-9A-Za-z\u4e00-\u9fff]")
# A4（2026-11-21）：含数字/比较运算符的段 = 有可核验的数值语义，**不得**以“太短”跳过。
# 修前 `"≤5"`、`"3%"` 这类段因长度 <4 被当 trivial 跳过 → 编造的数值段从不核验。
_QUOTE_SEG_SIGNAL_RE = re.compile(r"[0-9０-９≥≤<>%＜＞]")


def _quote_segment_has_signal(seg) -> bool:
    """段内是否含数字或比较运算符（这类段必须逐字核验，不可 trivial 跳过）。"""
    return bool(_QUOTE_SEG_SIGNAL_RE.search(_norm_quote(seg)))


def _quote_segment_min_len(seg) -> int:
    """短数值/比较符段的核验最小长度：降到 1（内容由数字/符号本身锚定）。"""
    return 1 if _quote_segment_has_signal(seg) else _QUOTE_MIN_LEN


def _quote_seg_skip_enabled() -> bool:
    """P0-6 开关：默认开启；=0 恢复旧行为（纯标点段参与校验 → 整条降级）。"""
    return str(os.environ.get(_P0_QUOTE_SEG_ENV, "1")).strip() not in (
        "0", "false", "off", "no")


def _quote_segment_trivial(seg) -> bool:
    """多段引文里「没有可锚定内容」的段：归一去空白/包裹引号后长度<4，或纯标点/符号。

    A4（2026-11-21）：含数字或比较运算符（≥≤<>%）的段**不视为 trivial**，必须强制核验，
    否则 `"≤5"`、`"3%"` 这类编造的短数值段会被默认跳过。其余段仍按长度阈值与词字符判定。
    只用于**跳过**无内容段，不用于把短引文当成证据。
    """
    s = _norm_quote(seg)
    if _QUOTE_SEG_SIGNAL_RE.search(s):
        return False
    if len(s) < _QUOTE_MIN_LEN:
        return True
    return not bool(_QUOTE_WORD_RE.search(s))


def _workbook_sheet_names(path: str, sheet_cache: dict = None) -> list:
    """工作簿 sheet 名（供跨 sheet 串位判定）；读不到返回空列表，不猜。"""
    key = f"quote_gate:{path}"
    cache = sheet_cache if sheet_cache is not None else {}
    if key not in cache:
        cache[key] = _read_workbook_sheets(path)
    meta = cache[key] or {}
    return [str(x) for x in (meta.get("sheet_names") or [])] if meta.get("ok") else []


def _cell_exact_short_enabled() -> bool:
    """RULEPROOF_EVIDENCE_CELL_EXACT_SHORT（默认 1）：cell_verbatim 且 quote==cell 原文豁免 min_len。"""
    from . import auditpoints as _ap_short
    return _ap_short.evidence_cell_exact_short_enabled()


def _sheet_cell_quote_hit(path: str, sheet: str, quote: str, sheet_cache: dict = None,
                          *, min_len: int = None, exact_only: bool = False) -> dict:
    """限定 sheet 内逐字命中单元格文本（引文 ⊆ 单元格文本），返回首个命中的单元格坐标。

    ``min_len``/``exact_only`` 仅用于 §9.3 cell_exact 短引文豁免：此时降为
    “quote == 单元格原文”（归一空白/包裹引号后全等），证据强度由单元格坐标 + 全等保证。
    """
    target = _norm_sheet(sheet)
    q = _norm_quote(quote)
    if not path or not target or not q:
        return {}
    _min_len = _QUOTE_MIN_LEN if min_len is None else int(min_len)
    if exact_only and len(q) < _min_len:
        _min_len = 1
    try:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = next((w for w in wb.worksheets if _norm_sheet(w.title) == target), None)
            if ws is None:
                return {}
            for row in ws.iter_rows():
                for cell in row:
                    v = cell.value
                    if v is None:
                        continue
                    sv = _collapse_quote_ws(str(v))
                    if exact_only and len(q) < _QUOTE_MIN_LEN:
                        hit = (sv == q)
                    else:
                        hit = (len(q) >= _min_len and q in sv)
                    if hit:
                        return {"locator": f"{ws.title}!{cell.coordinate}",
                                "cell_quote": str(v)[:200], "sheet": ws.title,
                                "row": int(cell.row), "col": cell.column_letter}
        finally:
            try:
                wb.close()
            except Exception:
                pass
    except Exception:
        logging.getLogger(__name__).debug("quote cell lookup skipped", exc_info=True)
    return {}


def _cell_quote_hit(path: str, sheet: str, row, col, quote: str,
                    *, allow_short_exact: bool = False) -> bool:
    """指定单元格值是否包含引文（逐字）。定位坐标失效时返回 False，不跨格伪装命中。

    ``allow_short_exact``（§9.3 短引文豁免）：归一后 quote == 单元格原文时允许 min_len=1。
    """
    if not path or not _norm_sheet(sheet):
        return False
    r = int(row or 0)
    if r <= 0:
        return False
    try:
        from openpyxl import load_workbook
        from openpyxl.utils import column_index_from_string
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = next((w for w in wb.worksheets if _norm_sheet(w.title) == _norm_sheet(sheet)), None)
            if ws is None:
                return False
            cell = ws[f"{str(col or 'A').upper()}{r}"]
            val = getattr(cell, "value", "")
            if allow_short_exact and _cell_exact_short_enabled():
                qn = _norm_quote(quote)
                if qn and qn == _norm_quote(val):
                    return True
            return _quote_verbatim(quote, val)
        finally:
            try:
                wb.close()
            except Exception:
                pass
    except Exception:
        logging.getLogger(__name__).debug("quote cell hit skipped", exc_info=True)
    return False


def _verify_quote_in_object(quote, *, text: str, parsed, path: str, doc: dict,
                            sheet: str = "", sheet_cache: dict = None,
                            min_len: int = _QUOTE_MIN_LEN,
                            allow_short_exact: bool = False) -> dict:
    """校验一条 fail 引文是否逐字命中对象的原文/目标 sheet/单元格。

    返回 {ok, scope, locator, reason, sheets, quote}；ok=False 时 reason 区分
    quote_missing / quote_not_found / quote_wrong_sheet，供审计与降级理由使用。
    """
    q = str(quote or "").strip()
    if not q:
        return {"ok": False, "reason": "quote_missing", "quote": ""}
    # 多来源证据（汇总/多行命中）常用“；”拼接：逐段分别逐字校验，全部命中才算命中
    _segs = [s.strip() for s in q.split("；") if s.strip()]
    if len(_segs) > 1:
        # P0-6（T-181）：先剔除纯标点/过短段（如「合同估算价：3910.95万元；。」里的「。」），
        # 否则该段永远锚不上 → 整条真引文被降 insufficient（T-174 实测 2/465，其中 1 条 TP）。
        # 非平凡段仍是「全部命中」语义：只命中部分段 → quote_segment_not_found（不放宽）。
        _skipped_segs = []
        _anchored = list(_segs)
        if _quote_seg_skip_enabled():
            _anchored = []
            for _s in _segs:
                if _quote_segment_trivial(_s):
                    _skipped_segs.append(_s[:40])
                else:
                    _anchored.append(_s)
        if not _anchored:
            return {"ok": False, "reason": "quote_not_found",
                    "detail": "多段引文全部为纯标点/过短段，无可锚定内容",
                    "skipped_segments": _skipped_segs, "quote": q[:200]}
        if len(_anchored) == 1:
            # 剔除纯标点段后只剩 1 段：与单段引文同口径校验（不能因为原本带「；」就必失败）
            _got = _verify_quote_in_object(_anchored[0], text=text, parsed=parsed, path=path,
                                           doc=doc, sheet=sheet, sheet_cache=sheet_cache,
                                           min_len=_quote_segment_min_len(_anchored[0]),
                                           allow_short_exact=allow_short_exact)
            if _got.get("ok"):
                _got = dict(_got)
                _got.update({"scope": "multi_quote", "segments": 1,
                             "skipped_segments": _skipped_segs, "quote": q[:200]})
                return _got
            return {"ok": False, "reason": "quote_segment_not_found",
                    "failed_segments": [{"segment": _anchored[0][:120],
                                         "reason": _got.get("reason")}],
                    "skipped_segments": _skipped_segs, "quote": q[:200]}
        _bad = []
        for _seg in _anchored:
            _got = _verify_quote_in_object(_seg, text=text, parsed=parsed, path=path,
                                           doc=doc, sheet=sheet, sheet_cache=sheet_cache,
                                           min_len=_quote_segment_min_len(_seg),
                                           allow_short_exact=allow_short_exact)
            if not _got.get("ok"):
                _bad.append({"segment": _seg[:120], "reason": _got.get("reason")})
        if _bad:
            return {"ok": False, "reason": "quote_segment_not_found",
                    "failed_segments": _bad, "skipped_segments": _skipped_segs,
                    "quote": q[:200]}
        return {"ok": True, "scope": "multi_quote", "segments": len(_anchored),
                "skipped_segments": _skipped_segs, "quote": q[:200]}
    if _is_spreadsheet(doc):
        target = _norm_sheet(sheet)
        names = _workbook_sheet_names(path, sheet_cache)
        if target:
            hit = _sheet_cell_quote_hit(path, target, q, sheet_cache,
                                        min_len=min_len, exact_only=allow_short_exact)
            if hit:
                return {"ok": True, "scope": "cell", **hit}
            stext = _sheet_text_for(parsed, target)
            if _quote_verbatim(q, stext, min_len=min_len):
                return {"ok": True, "scope": "sheet_text", "sheet": target}
            for other in names:
                if _norm_sheet(other) == target:
                    continue
                if _sheet_cell_quote_hit(path, other, q, sheet_cache):
                    return {"ok": False, "reason": "quote_wrong_sheet",
                            "sheet": target, "found_sheet": other, "quote": q[:200]}
                if _quote_verbatim(q, _sheet_text_for(parsed, other), min_len=min_len):
                    return {"ok": False, "reason": "quote_wrong_sheet",
                            "sheet": target, "found_sheet": other, "quote": q[:200]}
            if _quote_verbatim(q, text, min_len=min_len):
                # 全文能命中但限定 sheet 内不命中：按串位处理，不能当作该 sheet 证据
                return {"ok": False, "reason": "quote_wrong_sheet", "sheet": target,
                        "found_sheet": "", "quote": q[:200]}
            return {"ok": False, "reason": "quote_not_found", "sheet": target, "quote": q[:200]}
        # 未限定 sheet：全文命中即可（单元格级命中优先，便于报告定位）
        if _quote_verbatim(q, text, min_len=min_len):
            hit = _sheet_cell_quote_hit(path, names[0], q, sheet_cache) if names else {}
            return {"ok": True, "scope": "document", **(hit or {})}
        for other in names:
            if _sheet_cell_quote_hit(path, other, q, sheet_cache):
                return {"ok": True, "scope": "cell",
                        **_sheet_cell_quote_hit(path, other, q, sheet_cache)}
        return {"ok": False, "reason": "quote_not_found", "quote": q[:200]}
    if _quote_verbatim(q, text, min_len=min_len):
        return {"ok": True, "scope": "document"}
    return {"ok": False, "reason": "quote_not_found", "quote": q[:200]}


def _classify_quote_miss(quote, target_doc_id: str, docs_by_id: dict, parse_cache: dict) -> str:
    """引文不在归属对象：区分“跨文件串位”与“原文不存在”（审核/报告审计口径）。"""
    q = str(quote or "").strip()
    if not q:
        return "quote_missing"
    for did, d in (docs_by_id or {}).items():
        if str(did) == str(target_doc_id):
            continue
        try:
            text, parsed, _err = _parse_document_cached(d or {}, parse_cache)
        except Exception:
            continue
        if _quote_verbatim(q, text):
            return "quote_other_object"
    return "quote_not_found"


def _sub_quote_candidates(sub: dict) -> list:
    """fail 子要求可核验的引文候选（含决策表命中行原文/取数引文/多来源清单），去重保序。"""
    sub = sub or {}
    tt = sub.get("tool_trace") or {}
    out = []
    _quotes = sub.get("quotes")
    if isinstance(_quotes, (list, tuple)):
        for q in _quotes:
            s = str(q or "").strip()
            if s and s not in out:
                out.append(s)
    for cand in (sub.get("quote"), tt.get("quote"), tt.get("source_quote"),
                 tt.get("raw"), sub.get("source_quote")):
        s = str(cand or "").strip()
        if s and s not in out:
            out.append(s)
    return out


# 缺失型证据关键词：这类 fail 是“字段/对象缺失”，不能用 quote 表达（架构约束 2）
_MISSING_CLAIM_RE = re.compile(
    r"缺失|未提供|未附|未标注|未注明|无规格|缺少|未包含|未写明|未找到|未见|未签字|未盖章")


def _is_missing_claim(sub: dict) -> bool:
    return bool(_MISSING_CLAIM_RE.search(str((sub or {}).get("detail") or "")))


def _item_evidence_type(item: dict, slots: dict = None) -> str:
    """规则级证据四分类：relation > computation > missing > quote（冻结快照口径）。"""
    item = item or {}
    slots = slots if isinstance(slots, dict) else (item.get("slots") or {})
    if item.get("decision_tables") or slots.get("decision_tables") or slots.get("decision_table"):
        return "relation"
    hints = item.get("execution_hints") or {}
    subs = item.get("subrequirements") or slots.get("subrequirements") or []
    if isinstance(subs, list) and any(isinstance(s, dict) and s.get("tool") for s in subs):
        return "computation"
    if any(slots.get(k) for k in ("require", "forbid", "forbidden", "require_any")):
        return "missing"
    if str(hints.get("evaluation_kind") or "") in ("semantic", "deterministic", "ruleexec") or \
            any(isinstance(s, dict) and (s.get("criterion") or s.get("metric")) for s in subs):
        return "quote"
    if str(slots.get("_template") or "") in ("completeness", "personnel", "label", "citation",
                                             "record", "frequency"):
        return "missing"
    return "quote"


# ---------------- 计算/关系类证据最小可复核集（T-136 C-5）
# 原门禁过宽：计算类只要 tool_trace 出现 result/value/total 任一字段即 passed；
# 关系类声明 source_location_missing 即 passed（缺失被当成“关系证据成立”）。
# 现口径：证据必须能被第三方按“操作数行 / 公式 / 单位 / 复算结果”与“关系两端
# 锚点 + 连接依据”复核，缺项降级 insufficient（转人工），不得作为 fail 出闸。
_COMPUTATION_EVIDENCE_KEYS = {
    "operands": ("input", "inputs", "extracted", "normalized", "values", "occurrences",
                 "amount_sources", "tax_sources", "operands", "start", "end",
                 "date_sources"),
    "formula": ("formula", "expression", "operator", "op", "aggregation", "compare",
                "tool", "calendar", "calendar_basis", "selector", "direction"),
    "unit": ("unit", "unit_label", "currency", "calendar", "calendar_basis"),
    "result": ("result_value", "value", "total", "days", "diff", "converted",
               "normalized", "computed", "amount"),
}
_RELATION_RULE_ANCHOR_KEYS = ("code", "relation_id", "table_code")
_RELATION_LINK_KEYS = ("facts", "source_quote", "message", "link_basis", "relation_basis")
# T-142（修 T-136 C-5 回归）：单位/币种在部分工具轨迹里不是顶层字段，而在
# amount_sources / tax_sources / tax_sources.fields.* 等嵌套层；只查顶层会把
# “已有 CNY”误判为缺 unit（税额工具 tax_compare 即嵌套形态）。
_COMPUTATION_NESTED_GROUPS = {
    "unit": ("unit", "unit_label", "currency"),
}


def _non_empty_evidence_value(value) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def _nested_computation_hits(tt: dict, group: str) -> list:
    """单位/币种的结构化嵌套层查找（T-142，修 T-136 C-5 回归）。

    部分工具轨迹不把 unit/currency 放在 tool_trace 顶层，而在
    amount_sources / tax_sources / tax_sources.fields.* 里（税额工具 tax_compare
    就是这种形态：currency 位于 tool_trace.amount_sources.currency 与
    tool_trace.tax_sources.fields.currency.value）。只查顶层会把“币种已存在”
    误判为 missing=['unit']，把真实违规降级成 insufficient。
    """
    keys = _COMPUTATION_NESTED_GROUPS.get(group) or ()
    if not keys:
        return []
    containers = []
    for name in ("amount_sources", "tax_sources"):
        val = tt.get(name)
        if isinstance(val, dict):
            containers.append((name, val))
            fields = val.get("fields")
            if isinstance(fields, dict):
                containers.append((name + ".fields", fields))
                for fname, fval in fields.items():
                    if isinstance(fval, dict):
                        containers.append((name + ".fields." + str(fname), fval))
        elif isinstance(val, (list, tuple)):
            for i, one in enumerate(val):
                if isinstance(one, dict):
                    containers.append((name + "[" + str(i) + "]", one))
    hits = []
    for cname, cdata in containers:
        for key in keys:
            if _non_empty_evidence_value(cdata.get(key)):
                hits.append(cname + "." + key)
    return hits


def _computation_evidence_set(tt: dict) -> dict:
    """计算类最小可复核集：操作数行 + 公式/算子 + 单位 + 复算结果。"""
    tt = tt if isinstance(tt, dict) else {}
    present, missing = {}, []
    for group, keys in _COMPUTATION_EVIDENCE_KEYS.items():
        hit = [k for k in keys if _non_empty_evidence_value(tt.get(k))]
        if not hit:
            # T-142：unit/currency 允许来自结构化嵌套层（顶层优先，嵌套兜底）
            hit = _nested_computation_hits(tt, group)
        present[group] = hit
        if not hit:
            missing.append(group)
    return {"ok": not missing, "missing": missing, "present": present}


def _relation_evidence_set(tt: dict, sub: dict = None) -> dict:
    """关系类最小可复核集：规则端锚点 + 对象端锚点 + 连接依据（两端都要可回查）。"""
    tt = tt if isinstance(tt, dict) else {}
    sub = sub if isinstance(sub, dict) else {}
    present, missing = {}, []
    # 规则端锚点：来自哪条决策表/关系规则（code 且带 version/row/hit_policy）
    rule_keys = [k for k in _RELATION_RULE_ANCHOR_KEYS if _non_empty_evidence_value(tt.get(k))]
    rule_meta = [k for k in ("version", "row", "hit_policy") if _non_empty_evidence_value(tt.get(k))]
    if rule_keys and rule_meta:
        present["rule_anchor"] = rule_keys + rule_meta
    else:
        missing.append("rule_anchor")
    # 对象端锚点：原文行/单元格坐标；显式 source_location_missing=True 视为缺失
    _loc = (str(tt.get("source_locator") or "") or str(sub.get("source_locator") or "")
            or (str(tt.get("source_row") or "") if tt.get("source_row") else ""))
    if tt.get("source_location_missing"):
        _loc = ""
    if _loc:
        present["object_anchor"] = [k for k in ("source_locator", "source_row", "source_sheet")
                                    if _non_empty_evidence_value(tt.get(k))] or ["locator"]
    else:
        missing.append("object_anchor")
    # 连接依据：关系两端如何对上（facts/原文引文/命中说明）
    link = [k for k in _RELATION_LINK_KEYS if _non_empty_evidence_value(tt.get(k))]
    if link:
        present["link_basis"] = link
    else:
        missing.append("link_basis")
    return {"ok": not missing, "missing": missing, "present": present}


def _parse_gap_presence(doc: dict, text: str, search_scope: str = "document") -> dict:
    """缺失类证据的解析完整性：必须读 document.parse_status，不能只用 bool(text)。

    T-136 TL-6：解析缺口（parse_status=partial/failed）与 missing 类证据的搜索范围
    （document/block）相交时，“没找到”不能证明“不存在”，只能转人工/补证。
    """
    status = str((doc or {}).get("parse_status") or "").strip().lower() or "unknown"
    parse_incomplete = status in ("partial", "failed", "error", "parse_failed",
                                  "truncated", "incomplete")
    return {"found": False, "search_scope": search_scope or "document",
            "parse_completeness": {
                "parsed": bool(str(text or "").strip()) and not parse_incomplete,
                "chars": len(str(text or "")),
                "parse_status": status,
                "parse_incomplete": parse_incomplete,
                "source": "document.parse_status",
            },
            "parse_gap": parse_incomplete}


# ---------------------------------------------------------------------------
# L42 执行器对象绑定/证据门禁修复（2026-11-24，统一开关 RULEPROOF_EXEC_FIXES_V3）
#   ② quote_short：逐字短引文（含数字/计数单位）只按「是否逐字命中」判定证据门禁，
#      不因 <4 字被一刀切降级（L32 报告 §6.3：多实例 fail 子要求引文「复核1」被降级）。
#   ③ date_det：criterion 有值但无 metric 的结构化关系算子（含 date 链）走确定性执行，
#      不进语义分支（0-LLM 下 agent-judge 不可用 → 全量放弃；§6.4）。
#   ④ mi_generic：非白名单码逐行实例物化（按 L19 独立实例口径，逐行引文扩到该行原文）。
# =0 时逐项回退到历史行为。
# ---------------------------------------------------------------------------
_V3_STRUCTURED_OPS = ("cross_role_limit", "cross_position", "sum_check", "alter_detect")
_V3_SHORT_QUOTE_SIGNAL = re.compile(r"[0-9０-９≥≤<>%＜＞件次秒个]")


def _fix3_on(item: str = "") -> bool:
    """L42 执行器对象绑定修复统一开关（ruleexec 的本地别名）。"""
    try:
        return bool(ruleexec._fix3_on(item))
    except Exception:  # 铁律 2：开关异常留痕并按关闭处理（不改变历史行为）
        logging.getLogger(__name__).warning("exec_fix_v3 lookup failed", exc_info=True)
        return False


def _v3_quote_gate_min_len(quote) -> int:
    """L42 ② fail 引文逐字核验的最小长度：含数值/计数单位的短引文降到 2 字。

    依据任务口径「仅无逐字引文才降级」：`复核1`/`计数15件` 这类引文由数字锚定，
    逐字命中即成立；=0 时返回历史阈值 _QUOTE_MIN_LEN（4）。
    """
    if not _fix3_on("quote_short"):
        return _QUOTE_MIN_LEN
    q = _norm_quote(quote)
    if len(q) >= 2 and _V3_SHORT_QUOTE_SIGNAL.search(q):
        return 2
    return _QUOTE_MIN_LEN


def _v3_instance_quote(code: str, status: str, line: str, sub_text: str,
                       occ_quote: str = "") -> str:
    """L42 ④ 非白名单码逐行实例引文：把短引文扩到该行原文紧切片（仍逐字）。

    返回空串 = 不启用/不适用（调用方保留原引文）。仅当：
    - V3 mi_generic 开启；
    - 该子要求为 fail；
    - 规则码不在多实例生成器白名单（白名单码由 judge_cross_ref_rule_all 产出，语义不同）；
    - 行原文确实是当前执行文本的逐字切片。
    目的：同一 (doc, code) 的多行值相同时，短引文归一后互相包含会被 L19 实例判据
    （mi_instance_reject）当成同一实例 → 只物化 1 条 finding；逐行实例引文带行上下文后
    归一引文互不包含 + span 不重叠，L19 物化口径即可逐实例各落一条 finding。
    """
    if status != "fail" or not _fix3_on("mi_generic"):
        return ""
    try:
        if str(code or "") in set(ruleexec._MI_ALL_CODES):
            return ""
    except Exception:
        logging.getLogger(__name__).warning("MI whitelist lookup failed", exc_info=True)
        return ""
    line_q = str(line or "").strip()
    if not line_q or line_q not in str(sub_text or ""):
        return ""
    # 短行直接取整行；长行（如表格整行 290+ 字符）取「原引文 ±60 字」窗口，
    # 避免行首截断把数值/单位裁掉（食品35 ×CFU/g 科学计数法行实测 3/8 丢值）。
    if len(line_q) <= 240:
        return line_q[:240]
    oq = str(occ_quote or "").strip()
    pos = line_q.find(oq) if oq else -1
    if pos < 0:
        return ""
    start = max(0, pos - 60)
    end = min(len(line_q), pos + len(oq) + 60)
    return line_q[start:end]


def _v3_verbatim_quote(text: str, jr: dict) -> str:
    """从确定性关系结论里挑一条**逐字**且尽量长的引文（供 finding 落盘/定位）。

    背景：跨角色日期链的结论引文是「；」拼接的两个原文切片，拼接串不是原文连续切片，
    finding 落盘（snap_quote_to_document）会判 unanchored → 定位字段为空。关系两端
    各自逐字，且都在同一行/同一分句时取整行更利于复核定位（仍逐字）。
    """
    body = str(text or "")
    if not body.strip():
        return ""
    cands = []
    raw = str((jr or {}).get("quote") or "")
    cands.extend([x.strip() for x in raw.split("；") if x.strip()])
    for ev in (jr or {}).get("evidence") or []:
        q = str((ev or {}).get("quote") or "").strip()
        if q:
            cands.append(q)
    cands.extend([ln.strip() for ln in body.splitlines() if ln.strip()])
    best = ""
    for c in cands:
        if c and c in body and len(c) > len(best):
            best = c
    return best[:240]


def _v3_structured_det_result(sub: dict, text: str, aliases) -> dict | None:
    """L42 ③ 结构化关系算子的确定性执行结果（D4 criterion-无-metric 分支用）。

    None = 不是结构化算子（保持原语义分支/其它确定性分支）；否则返回 D4 子要求结构。
    """
    if not _fix3_on("date_det") or not isinstance(sub, dict):
        return None
    op = ""
    try:
        if ruleexec._is_cross_role_limit_rule(sub):
            op = "cross_role_limit"
        elif ruleexec._is_cross_position_rule(sub):
            op = "cross_position"
        elif ruleexec._is_sum_check_rule(sub):
            op = "sum_check"
        elif ruleexec._is_alter_detect_rule(sub):
            op = "alter_detect"
    except Exception:  # 铁律 2：算子识别异常按「非结构化」处理，留痕不猜
        logging.getLogger(__name__).warning("structured det detect failed", exc_info=True)
        return None
    if not op:
        return None
    try:
        jr = _frozen_judge_rule(sub, text, aliases)
    except Exception as _e:  # 铁律 2：执行异常不伪造结论，回落原语义分支
        logging.getLogger(__name__).warning(
            "structured det judge failed（回落语义分支）op=%s: %s", op, _e, exc_info=True)
        return None
    st0 = str((jr or {}).get("state") or "unknown")
    if st0 not in ("满足", "不满足", "证据不足", "不适用"):
        return None
    st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
          "不适用": "not_applicable"}[st0]
    quote = str((jr or {}).get("quote") or "")
    # 关系类引文是「；」拼接的多段原文：拼接串不是连续原文切片，落盘时无法定位。
    # date_det 修复里改取其中最长的一条逐字切片（优先整行），供 finding 逐字回查。
    if op == "cross_role_limit" and (not quote or "；" in quote or quote not in str(text or "")):
        _vq = _v3_verbatim_quote(text, jr)
        if _vq:
            quote = _vq
    detail = str((jr or {}).get("detail") or "")
    return {"status": st, "raw_state": st0, "raw_item": {},
            "detail": detail, "quote": quote, "evidence_ok": True,
            "tool_trace": {"executor": "ruleexec." + op, "operator": op,
                           "result": st, "state": st0, "detail": detail,
                           "quote": quote,
                           "deterministic": True,
                           "criterion_without_metric": True}}


def _apply_fail_quote_gate(sub_out: list, *, item: dict, text: str, parsed, path: str,
                           doc: dict, rule_sheet: str = "", docs_by_id: dict = None,
                           parse_cache: dict = None, sheet_cache: dict = None) -> dict:
    """D4 子要求出口门禁：fail 引文必须逐字命中归属对象原文/目标单元格。

    命中：sub["evidence_gate"]={passed:true,...}
    不命中：sub 降级 insufficient（转人工），不得进入 finding/fail 结论。
    """
    docs_by_id = docs_by_id or {}
    parse_cache = parse_cache if parse_cache is not None else {}
    sheet_cache = sheet_cache if sheet_cache is not None else {}
    stat = {"checked": 0, "passed": 0, "blocked": 0, "blocked_subs": [],
            "evidence_types": {"quote": 0, "missing": 0, "computation": 0, "relation": 0}}
    for sub in sub_out or []:
        if str((sub or {}).get("status") or "") != "fail":
            continue
        stat["checked"] += 1
        # BX 事项级锚定（2026-11-23，docs/qa/BX缺口分析_20261123.md §2.2）：
        # 引文落在「参考范本正文」空白占位符（__ / □ / ×× / 空格%）→ 不是待签正文，
        # 不得作为 fail 证据：降 insufficient 转人工（不物化为 fail）。
        # 引文落在模板/前言但非空白 → 仅标注 anchor_unverified，不改变结论（不误伤 TP）。
        # 开关 RULEPROOF_BX_ANCHOR 默认关；非 BX 文档（无 SW/TK 事项段）→ 一次都不进。
        try:
            from . import rule_code_attrib as _rca_anchor
            if _rca_anchor.bx_anchor_enabled():
                _bxq = " ".join(str(x or "") for x in (
                    sub.get("quote"), (sub.get("raw_item") or {}).get("quote")) if str(x or "").strip())
                if _bxq:
                    _bxa = _rca_anchor.bx_quote_anchor(_bxq, text)
                    if _bxa.get("has_items"):
                        if not _bxa.get("ok") and _bxa.get("blank"):
                            _mark_blocked(sub, {
                                "ok": False, "reason": "bx_anchor_unverified",
                                "detail": "引文落在参考范本正文空白占位符（非待签正文），"
                                          "不得作为 fail 证据，降级转人工",
                                "quote": _bxq[:120], "anchor": _bxa}, None, stat)
                            continue
                        sub["bx_anchor"] = _bxa
        except Exception:  # 铁律 2：锚定异常留痕；放行原结论，不改变判定
            logging.getLogger(__name__).warning(
                "bx anchor gate failed（保留原结论）", exc_info=True)
        tt = sub.get("tool_trace") or {}
        sheet = _norm_sheet(sub.get("sheet") or tt.get("sheet")
                            or tt.get("source_sheet") or rule_sheet)
        quotes = _sub_quote_candidates(sub)
        _etype = _evidence_type_of_sub(sub)
        sub["evidence_type"] = _etype
        stat["evidence_types"][_etype] = stat["evidence_types"].get(_etype, 0) + 1
        # 计算类证据：必须满足最小可复核集（操作数行/公式/单位/复算结果），
        # quote 只是辅助（不要求逐字）。T-136 C-5：仅出现 result/value 不够。
        if _etype == "computation":
            _comp = _computation_evidence_set(tt)
            if _comp["ok"]:
                stat["passed"] += 1
                sub["evidence_gate"] = {"passed": True,
                                        "reason": "computation_min_evidence_set",
                                        "evidence_type": "computation",
                                        "evidence_set": _comp["present"],
                                        "trace_fields": [k for k in
                                                         ("executor", "input", "result", "value",
                                                          "aggregation", "occurrences",
                                                          "amount_sources", "tax_sources",
                                                          "unit", "currency")
                                                         if tt.get(k) not in (None, "", {}, [])]}
                continue
            gate = {"ok": False, "reason": "computation_evidence_incomplete",
                    "evidence_type": "computation",
                    "missing": _comp["missing"],
                    "detail": "计算类证据缺少最小可复核集：" + "、".join(_comp["missing"]) +
                              "（需操作数行/公式/单位/复算结果）", "quote": ""}
            stat["blocked"] += 1
            _mark_blocked(sub, gate, sheet, stat)
            continue
        # 关系类证据（T-136 C-5）：必须有「规则端锚点 + 对象端锚点 + 连接依据」，
        # 声明 source_location_missing 不再等于证据成立——关系无法两端回查时降级转人工。
        if _etype == "relation":
            _rel = _relation_evidence_set(tt, sub)
            if not _rel["ok"]:
                _reason = ("relation_source_anchor_missing"
                           if "object_anchor" in _rel["missing"]
                           else "relation_rule_anchor_missing"
                           if "rule_anchor" in _rel["missing"]
                           else "relation_link_basis_missing")
                _presence = _parse_gap_presence(
                    doc, text, ("sheet" if sheet else "document"))
                _presence.update({"source_reason": str(tt.get("source_reason") or "not_found"),
                                  "two_ended": False,
                                  "missing_anchors": list(_rel["missing"]),
                                  "facts": bool(tt.get("facts"))})
                gate = {"ok": False, "reason": _reason,
                        "evidence_type": "relation",
                        "missing": _rel["missing"],
                        "detail": "关系类证据缺少最小可复核集：" + "、".join(_rel["missing"]) +
                                  "（需规则端锚点 + 对象端锚点 + 连接依据）", "quote": ""}
                stat["blocked"] += 1
                # T-142（修 T-136 C-5 回归）：关系类子项全部来自 decision_table，
                # 这里只做“子项级降级”，**不得**调用 _mark_blocked 覆盖 raw_state：
                #   * decision_table_collect 子项的 finding 物化门禁
                #     _materialize_collect_findings 只认 raw_state==decision_table_collect；
                #     被覆盖成 evidence_quote_gate 后物化链路直接断掉，行锚点
                #     decision_table:CODE:row:N 与台账「原文定位缺失」全部丢失
                #     （collect_coord / decision_collect_policy 的定位缺失分支回归）；
                #   * 保留 raw_state / source_locator / source_quote 原值；C-5 的
                #     insufficient 降级由下游 finding 级门禁完成（finding state=insufficient、
                #     status=need_evidence，同时保留行锚点与「原文定位缺失」标签）。
                sub["status"] = "insufficient"
                sub["evidence_gate"] = {
                    "passed": False, "reason": _reason,
                    "evidence_type": "relation",
                    "scope": sheet or "document",
                    "locator": (gate or {}).get("locator") or "",
                    "quote": "",
                    "detail": gate["detail"],
                    "missing": list(_rel["missing"]),
                    "presence": _presence,
                }
                sub["presence"] = _presence
                sub["evidence_ok"] = False
                sub["source_location_missing"] = bool(tt.get("source_location_missing"))
                stat["blocked_subs"].append({
                    "sub_id": str(sub.get("id") or ""), "reason": _reason,
                    "evidence_type": "relation",
                    "missing": list(_rel["missing"]), "quote": ""})
                continue
        # 关系类证据带决策表命中坐标 + 原文：直接核验该单元格，不要求子要求另带 quote。
        # 决策表 relation sub 的 quote 可能为空，source_quote 才是命中单元格原文。
        if _etype == "relation":
            _rloc = str(tt.get("source_locator") or "")
            _rq = str(tt.get("source_quote") or sub.get("quote") or "")
            _rm = _QUOTE_CELL_RE.match(_rloc)
            if _rloc and tt.get("facts"):
                # 关系证据由结构化 facts + 命中行坐标支撑；source_quote 可能是
                # “温度 | 120℃”这类展示串，不要求逐字等于单元格文本。
                stat["passed"] += 1
                sub["evidence_gate"] = {"passed": True,
                                        "reason": "relation_fact_and_locator",
                                        "evidence_type": "relation",
                                        "scope": _rm.group(1) if _rm else sheet,
                                        "locator": _rloc,
                                        "quote": _rq[:200]}
                continue
            if _rm and _is_spreadsheet(doc) and _rq and "；" not in _rq:
                if _cell_quote_hit(path, _rm.group(1), _rm.group(3), _rm.group(2), _rq):
                    stat["passed"] += 1
                    sub["evidence_gate"] = {"passed": True,
                                            "reason": "relation_cell_quote_verbatim",
                                            "evidence_type": "relation",
                                            "scope": _rm.group(1),
                                            "locator": _rloc,
                                            "quote": _rq[:200]}
                    continue
                gate = {"ok": False, "reason": "quote_cell_mismatch",
                        "locator": _rloc, "quote": _rq[:200]}
                stat["blocked"] += 1
                _mark_blocked(sub, gate, _rm.group(1), stat)
                continue

        # 缺失型证据：字段/对象缺失不能用 quote 表达（架构约束 2）。T-136 TL-6：
        # 必须读 document.parse_status——解析缺口与搜索范围相交时，“没找到”不能证明
        # “不存在”，只能降级 insufficient + 明确原因（转人工补证/复核解析）。
        if not quotes and (_is_missing_claim(sub) or _etype == "missing"):
            _presence = _parse_gap_presence(doc, text, ("sheet" if sheet else "document"))
            _presence["searched_terms"] = [
                str(tt.get("metric") or sub.get("detail") or "")[:120]]
            if _presence.get("parse_gap"):
                _parse_status = str((_presence.get("parse_completeness") or {})
                                    .get("parse_status") or "")
                gate = {"ok": False, "reason": "parse_gap_search_scope",
                        "evidence_type": "missing",
                        "parse_status": _parse_status,
                        "detail": (f"文档解析状态={_parse_status or 'unknown'}（解析不完整），"
                                   f"缺失类结论不可成立：搜索范围 {_presence['search_scope']} "
                                   "与解析缺口相交，转人工补证/复核解析"),
                        "quote": ""}
                stat["blocked"] += 1
                _mark_blocked(sub, gate, sheet, stat, presence=_presence)
                sub["raw_state"] = "parse_gap_missing_evidence"
                continue
            stat["passed"] += 1
            sub["evidence_gate"] = {"passed": True,
                                    "reason": "evidence_type_missing_presence",
                                    "evidence_type": "missing",
                                    "presence": _presence}
            sub["presence"] = _presence
            continue
        gate = None
        if not quotes:
            gate = {"ok": False, "reason": "quote_missing", "quote": ""}
        else:
            missing = []
            for q in quotes:
                got = _verify_quote_in_object(q, text=text, parsed=parsed, path=path,
                                              doc=doc, sheet=sheet, sheet_cache=sheet_cache,
                                              min_len=_v3_quote_gate_min_len(q))
                if not got.get("ok"):
                    missing.append(got)
                    continue
                gate = got
                break
            if gate is None:
                gate = max(missing, key=lambda x: 0 if x.get("reason") == "quote_wrong_sheet" else 1)
                # 归属该 finding：引文不在本对象但出现在其它文件 = 跨文件串位
                if gate.get("reason") in ("quote_not_found", "quote_wrong_sheet",
                                          "quote_segment_not_found"):
                    miss = _classify_quote_miss(gate.get("quote") or (quotes[0] if quotes else ""),
                                                str(item.get("object_id") or ""),
                                                docs_by_id, parse_cache)
                    if miss in ("quote_other_object",):
                        gate = {**gate, "reason": miss,
                                "detail": "引文命中其它文件内容（跨文件串位），不属于本对象"}
        # 决策表命中行自带 source_locator 时，额外核验该单元格确含原文（串位专项）
        if gate and gate.get("ok"):
            loc = str(tt.get("source_locator") or "")
            m = _QUOTE_CELL_RE.match(loc)
            if m and _is_spreadsheet(doc):
                _sq = str(tt.get("source_quote") or sub.get("quote") or "")
                if _sq and "；" not in _sq and not _cell_quote_hit(
                        path, m.group(1), m.group(3), m.group(2), _sq):
                    gate = {"ok": False, "reason": "quote_cell_mismatch",
                            "locator": loc, "quote": _sq[:200]}
            elif not loc and tt.get("executor") == "decision_table" and str(tt.get("result") or "") == "fail":
                gate = {"ok": False, "reason": "source_location_missing",
                        "quote": str(tt.get("source_quote") or "")[:200]}
        if gate and gate.get("ok"):
            stat["passed"] += 1
            sub["evidence_gate"] = {"passed": True, "reason": "quote_verbatim_in_source",
                                    "evidence_type": _etype,
                                    "scope": gate.get("scope") or "document",
                                    "locator": gate.get("locator") or "",
                                    "quote": (gate.get("quote") or gate.get("cell_quote") or "")[:200]}
            continue
        stat["blocked"] += 1
        _mark_blocked(sub, gate or {"ok": False, "reason": "quote_not_found"}, sheet, stat)
    return stat


def _mark_blocked(sub: dict, gate: dict, sheet: str, stat: dict, presence: dict = None) -> None:
    """fail 证据不成立：降级 insufficient（转人工），写门禁轨迹与 presence（如适用）。"""
    reason = (gate or {}).get("reason") or "quote_not_found"
    sub["evidence_gate"] = {"passed": False, "reason": reason,
                            "evidence_type": sub.get("evidence_type") or "quote",
                            "scope": sheet or "document",
                            "locator": (gate or {}).get("locator") or "",
                            "quote": ((gate or {}).get("quote") or "")[:200],
                            "detail": (gate or {}).get("detail") or _QUOTE_GATE_DETAIL}
    # T-136 C-5：计算/关系类缺项必须显式可见（min evidence set 未满足的组别）
    if (gate or {}).get("missing"):
        sub["evidence_gate"]["missing"] = list(gate.get("missing") or [])
    if (gate or {}).get("parse_status"):
        sub["evidence_gate"]["parse_status"] = str(gate.get("parse_status") or "")
    if presence:
        sub["evidence_gate"]["presence"] = presence
        sub["presence"] = presence
    sub["status"] = "insufficient"
    sub["raw_state"] = "evidence_quote_gate"
    _detail = str(sub.get("detail") or "")
    if _QUOTE_GATE_DETAIL not in _detail:
        sub["detail"] = (_detail + "；" if _detail else "") + _QUOTE_GATE_DETAIL
    sub["evidence_ok"] = False
    stat["blocked_subs"].append({"sub_id": str(sub.get("id") or ""),
                                 "reason": reason,
                                 "evidence_type": sub.get("evidence_type") or "quote",
                                 **({"missing": list(gate.get("missing") or [])}
                                    if (gate or {}).get("missing") else {}),
                                 "quote": str((gate or {}).get("quote") or "")[:160]})


# ---------------------------------------------------------------- D3 证据范围能力
# sheet 必须来自真实工作簿解析结果/多 sheet 元数据；document_set 必须同时满足
# 「manifest 对象数>1」和「确实存在跨文件证据」。能力不足时只报 insufficient，
# 不把文本里的 "Sheet"、对象数或文件名当成可用。
_SHEET_EXTS = {"xlsx", "xlsm", "xls"}
_SHEET_DOC_TYPES = {"xlsx", "xls", "xlsm", "excel", "spreadsheet", "workbook"}
_SCOPE_REASON_DETAILS = {
    "not_spreadsheet": "非 spreadsheet 文件，正文出现 Sheet 不构成 sheet 证据",
    "openpyxl_unavailable": "缺少 openpyxl，无法读取工作簿元数据",
    "workbook_unreadable": "工作簿不可解析，不能确认 sheet",
    "legacy_xls_unsupported": "旧版 xls 无可用解析器，不能确认 sheet",
    "document_path_missing": "文档路径缺失，无法解析",
    "document_empty": "文档无可解析正文，sheet 证据不成立",
    "sheet_anchor_missing": "解析结果没有可定位的 sheet 锚点",
    "parsed_sheet_anchors": "解析结果含真实 sheet 锚点，但未读到工作簿元数据",
    "sheet_metadata_and_content": "工作簿元数据与解析 sheet 锚点均可用",
    "manifest_object_count_le_1": "manifest 对象数≤1，document_set 至少需要 2 个文件",
    "no_evidence_terms": "规则未声明 required_evidence，无法核验跨文件证据",
    "fewer_than_two_parsed_objects": "可解析出正文的 manifest 文件不足 2 个",
    "no_cross_file_evidence": "required_evidence 未出现在 ≥2 个 manifest 文件中",
    "cross_file_evidence_found": "required_evidence 已出现在 ≥2 个 manifest 文件中",
    "not_requested": "本轮未要求 document_set，未做跨文件证据核验",
    "sheet_not_found": "工作簿不存在指定 sheet",
    "sheet_empty": "指定 sheet 存在但没有可解析文本",
    "sheet_unverified": "工作簿元数据不可用，解析锚点未包含指定 sheet",
    "sheet_limit_multiple": "一次只支持限定一个 sheet",
    "sheet_limit_invalid": "sheet 限定声明不合法",
    "sheet_found": "指定 sheet 存在且可解析",
}


def _ext_of(doc: dict) -> str:
    raw = str((doc or {}).get("path") or (doc or {}).get("filename") or "")
    return raw.rsplit(".", 1)[-1].lower() if "." in raw else ""


def _is_spreadsheet(doc: dict) -> bool:
    """优先按真实文件扩展名判断；只有无扩展名时才看明确的 doc_type。"""
    ext = _ext_of(doc)
    if ext:
        return ext in _SHEET_EXTS
    return str((doc or {}).get("doc_type") or "").strip().lower() in _SHEET_DOC_TYPES


def _parsed_sheet_anchors(parsed) -> list:
    """deepparse 解析 xlsx 时 section.anchor 就是 sheet 名；只认表格 section。"""
    out = []
    for sec in (getattr(parsed, "sections", None) or []):
        if str(getattr(sec, "kind", "") or "") != "table":
            continue
        anchor = str(getattr(sec, "anchor", "") or "").strip()
        if anchor and anchor not in out:
            out.append(anchor)
    return out


def _read_workbook_sheets(path: str, doc_type: str = "") -> dict:
    """读取工作簿多 sheet 元数据；缺依赖/坏文件/旧 xls 都明确返回不可用。"""
    try:
        from openpyxl import load_workbook
    except Exception as e:
        return {"ok": False, "capability": "missing", "reason": "openpyxl_unavailable",
                "error": f"{type(e).__name__}: {e}"}
    if not path:
        return {"ok": False, "capability": "missing", "reason": "document_path_missing"}
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            names = [str(ws.title) for ws in wb.worksheets]
        finally:
            try:
                wb.close()
            except Exception:
                pass
        return {"ok": True, "capability": "openpyxl", "source": "workbook_metadata",
                "sheet_names": names}
    except Exception as e:
        ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
        return {"ok": False, "capability": "unavailable",
                "reason": "legacy_xls_unsupported" if ext == "xls" else "workbook_unreadable",
                "error": f"{type(e).__name__}: {e}"}


def _sheet_scope(doc: dict, text: str, parsed, cache: dict) -> dict:
    """sheet 可用性：真实 spreadsheet + 可解析文本 + 能定位到 sheet 的解析锚点/元数据。"""
    info = {"scope": "sheet", "applicable": _is_spreadsheet(doc),
            "available": False, "reason": "", "sheet_count": 0,
            "multi_sheet": False, "sheet_names": [], "content_sheets": []}
    if not info["applicable"]:
        info.update({"reason": "not_spreadsheet", "capability": "not_applicable"})
        return info
    path = str((doc or {}).get("path") or "")
    key = str((doc or {}).get("id") or path)
    if key not in cache:
        cache[key] = _read_workbook_sheets(path, str((doc or {}).get("doc_type") or ""))
    meta = cache[key] or {}
    anchors = _parsed_sheet_anchors(parsed)
    if meta.get("ok"):
        names = [str(x) for x in (meta.get("sheet_names") or [])]
        content_sheets = [x for x in anchors if x in names] or anchors
        info.update({"capability": "openpyxl", "sheet_count": len(names),
                     "sheet_names": names, "multi_sheet": len(names) > 1,
                     "content_sheets": content_sheets,
                     "source": "workbook_metadata+parsed"})
        if not text.strip():
            info.update({"available": False, "reason": "document_empty"})
        elif not content_sheets:
            info.update({"available": False, "reason": "sheet_anchor_missing"})
        else:
            info.update({"available": True, "reason": "sheet_metadata_and_content"})
        return info
    # 元数据读不到：只有解析结果里确实有 sheet 锚点且有正文时才可用；
    # 否则保留能力/解析失败原因，绝不因扩展名是 xlsx 就放行。
    info.update({"capability": meta.get("capability") or "unavailable",
                 "metadata_error": meta.get("error") or "",
                 "sheet_count": len(anchors), "sheet_names": anchors,
                 "multi_sheet": len(anchors) > 1, "content_sheets": anchors,
                 "source": "parsed_anchors"})
    if anchors and text.strip():
        info.update({"available": True, "reason": "parsed_sheet_anchors"})
    elif not text.strip():
        info.update({"available": False,
                     "reason": meta.get("reason") or "document_unparsed"})
    else:
        info.update({"available": False, "reason": "sheet_anchor_missing"})
    return info


# ---------------------------------------------------------------- sheet 限定执行
# 规则 slots 可声明 sheet_name / evidence_scope_sheet（单个 sheet 名）：D3 用工作簿
# 元数据/解析锚点校验该 sheet 真实存在，D4 只用该 sheet 的解析文本与行判定。
# 未声明时完全保持原 document 口径；声明但缺 sheet/坏工作簿时明确 insufficient。
_SHEET_LIMIT_KEYS = ("sheet_name", "evidence_scope_sheet")


def _sheet_limit_names(container) -> tuple[list, list, list]:
    """读取 sheet 限定声明；返回 (名称, 非法值, 来源字段)，不猜、不拆分名字。"""
    names, invalid, sources = [], [], []
    if not isinstance(container, dict):
        return names, invalid, sources
    for key in _SHEET_LIMIT_KEYS:
        if key not in container:
            continue
        sources.append(key)
        raw = container.get(key)
        if raw is None:
            continue
        if isinstance(raw, str):
            vals = [raw]
        elif isinstance(raw, (list, tuple, set)):
            vals = list(raw)
        else:
            invalid.append({key: repr(raw)[:80]})
            continue
        for one in vals:
            if one is None:
                continue
            if isinstance(one, (dict, list, tuple, set)):
                invalid.append({key: repr(one)[:80]})
                continue
            name = _norm_sheet(one)
            if name and name not in names:
                names.append(name)
    return names, invalid, sources


def _sheet_limit_spec(container) -> dict:
    """单条规则/子要求的 sheet 限定；多个不同 sheet 明确不支持，不静默取第一个。"""
    names, invalid, sources = _sheet_limit_names(container)
    spec = {"requested": False, "valid": True, "sheet": "", "sheets": [],
            "source": "", "reason": "not_requested", "detail": ""}
    if not invalid and not names:
        return spec
    spec.update({"requested": True, "source": ",".join(sources)})
    if invalid:
        return {**spec, "valid": False, "reason": "sheet_limit_invalid",
                "detail": "sheet 限定必须是单个 sheet 名称"}
    if len(names) > 1:
        return {**spec, "valid": False, "sheet": names[0], "sheets": names,
                "reason": "sheet_limit_multiple",
                "detail": "一次只支持限定一个 sheet；请拆分为多条规则/子要求"}
    return {**spec, "sheet": names[0], "sheets": names,
            "reason": "sheet_limit_declared", "detail": f"限定 sheet {names[0]}"}


def _rule_sheet_limit(item: dict, slots: dict) -> dict:
    """冻结对象优先，其次规则 slots；只有显式声明才算限定。"""
    for container, where in ((item or {}, "manifest_item"), (slots or {}, "rule_slots")):
        spec = _sheet_limit_spec(container)
        if spec.get("requested"):
            return {**spec, "declared_in": where}
    return _sheet_limit_spec({})


def _sheet_text_for(parsed, sheet: str) -> str:
    """从解析 sections 取指定 sheet 的文本；deepparse 对 xlsx 以 sheet 名作 anchor。"""
    target = _norm_sheet(sheet)
    if not target or parsed is None:
        return ""
    lines = []
    for sec in (getattr(parsed, "sections", None) or []):
        if _norm_sheet(getattr(sec, "anchor", "")) != target:
            continue
        text = str(getattr(sec, "text", "") or "")
        if text.strip():
            lines.append(text)
    return "\n".join(lines)


def _parsed_for_sheet(parsed, sheet: str):
    """把 parsed 收窄到指定 sheet 的 sections，供行号/锚点定位使用。"""
    target = _norm_sheet(sheet)
    if not target or parsed is None:
        return parsed
    secs = [s for s in (getattr(parsed, "sections", None) or [])
            if _norm_sheet(getattr(s, "anchor", "")) == target]
    if not secs:
        return parsed
    try:
        return deepparse.ParsedDoc(
            source=str(getattr(parsed, "source", "") or ""),
            doc_type=str(getattr(parsed, "doc_type", "") or ""),
            sections=list(secs),
            text="\n".join(str(getattr(s, "text", "") or "") for s in secs))
    except Exception:
        return parsed


def _sheet_limit_check(doc, parsed, sheet: str, sheet_info: dict,
                       parse_error: str = "") -> dict:
    """指定 sheet 是否真实存在且有可解析内容；只认元数据/解析锚点，不猜。"""
    target = _norm_sheet(sheet)
    info = {"sheet": target, "available": False, "reason": "", "detail": "",
            "source": "", "sheet_names": [], "content_sheets": [], "chars": 0,
            "metadata_ok": False, "metadata_error": "",
            "parse_error": str(parse_error or "")[:200]}
    text = _sheet_text_for(parsed, target)
    info["chars"] = len(text)
    if not _is_spreadsheet(doc):
        info.update({"reason": "not_spreadsheet",
                     "detail": "非 spreadsheet 文件，不能按 sheet 限定执行"})
        return info
    path = str((doc or {}).get("path") or "")
    if not path:
        info.update({"reason": "document_path_missing", "detail": "文档路径缺失"})
        return info
    sheet_info = sheet_info or {}
    names = [_norm_sheet(x) for x in (sheet_info.get("sheet_names") or [])]
    anchors = [_norm_sheet(x) for x in (sheet_info.get("content_sheets") or [])]
    info["sheet_names"] = names
    info["content_sheets"] = anchors
    info["metadata_error"] = str(sheet_info.get("metadata_error") or "")
    if sheet_info.get("capability") == "openpyxl":
        info["metadata_ok"] = True
        info["source"] = "workbook_metadata"
        if target not in names:
            info.update({"reason": "sheet_not_found",
                         "detail": f"工作簿不含 sheet {target}"})
            return info
        if text.strip():
            info.update({"available": True, "reason": "sheet_found",
                         "detail": f"sheet {target} 存在且有可解析文本"})
        elif info["parse_error"]:
            info.update({"reason": "document_unparsed",
                         "detail": f"sheet {target} 存在，但文档解析失败："
                                   f"{info['parse_error']}"})
        else:
            info.update({"reason": "sheet_empty",
                         "detail": f"sheet {target} 存在但没有可解析文本"})
        return info
    info["source"] = "parsed_anchors"
    if target in anchors and text.strip():
        info.update({"available": True,
                     "reason": "sheet_found_from_parsed_anchors",
                     "detail": "工作簿元数据不可用，但解析锚点确认该 sheet 有正文"})
        return info
    if anchors:
        info.update({"reason": "sheet_unverified",
                     "detail": f"工作簿元数据不可用，解析锚点未包含 sheet {target}"})
        return info
    reason = str(sheet_info.get("reason") or "")
    if reason not in ("workbook_unreadable", "openpyxl_unavailable",
                      "legacy_xls_unsupported", "document_path_missing"):
        reason = "document_unparsed"
    info.update({"reason": reason,
                 "detail": _SCOPE_REASON_DETAILS.get(reason)
                           or info["metadata_error"] or "文档无法解析"})
    return info


def _sheet_limit_summary(doc, parsed, sheet_info, rule_spec: dict,
                         sub_specs: list, parse_error: str = "") -> dict:
    """汇总规则级/子要求级 sheet 限定：所有声明都必须可验证，再供 D4 分 sheet 取文本。"""
    summary = {"requested": False, "available": True, "sheet": "", "sheets": [],
               "reason": "not_requested", "detail": "", "checks": [],
               "sub_sheets": {}, "chars": 0}
    specs = []
    if (rule_spec or {}).get("requested"):
        specs.append(("rule", rule_spec))
    for idx, spec in (sub_specs or []):
        if (spec or {}).get("requested"):
            specs.append((f"sub:{idx}", spec))
    if not specs:
        return summary
    summary["requested"] = True
    summary["reason"] = "sheet_limit_declared"
    _declared_sources = []
    _declared_ins = []
    for _owner, _spec in specs:
        for _key in str((_spec or {}).get("source") or "").split(","):
            if _key and _key not in _declared_sources:
                _declared_sources.append(_key)
        _in = str((_spec or {}).get("declared_in") or "")
        if _in and _in not in _declared_ins:
            _declared_ins.append(_in)
    summary["declared_source"] = ",".join(_declared_sources)
    summary["declared_in"] = ",".join(_declared_ins)
    invalid = None
    for owner, spec in specs:
        _names = list(spec.get("sheets") or [])
        if not _names and _norm_sheet(spec.get("sheet")):
            _names = [_norm_sheet(spec.get("sheet"))]
        for sheet in _names:
            sheet = _norm_sheet(sheet)
            if sheet and sheet not in summary["sheets"]:
                summary["sheets"].append(sheet)
        if _norm_sheet(spec.get("sheet")):
            summary["sub_sheets"][owner] = _norm_sheet(spec.get("sheet"))
        if not spec.get("valid") and invalid is None:
            invalid = spec
    summary["sheet"] = _norm_sheet((rule_spec or {}).get("sheet"))
    checks = {}
    for owner, spec in specs:
        _names = list(spec.get("sheets") or [])
        if not _names and _norm_sheet(spec.get("sheet")):
            _names = [_norm_sheet(spec.get("sheet"))]
        for sheet in _names:
            sheet = _norm_sheet(sheet)
            if not sheet:
                continue
            if sheet not in checks:
                checks[sheet] = _sheet_limit_check(doc, parsed, sheet, sheet_info, parse_error)
                checks[sheet]["declared_by"] = [owner]
            elif owner not in checks[sheet]["declared_by"]:
                checks[sheet]["declared_by"].append(owner)
    summary["checks"] = list(checks.values())
    summary["chars"] = (len(_sheet_text_for(parsed, summary["sheet"]))
                        if summary["sheet"] else 0)
    bad = next((c for c in summary["checks"] if not c.get("available")), None)
    if invalid is not None:
        summary.update({"available": False,
                        "reason": invalid.get("reason") or "sheet_limit_invalid",
                        "detail": invalid.get("detail") or ""})
    elif bad is not None:
        summary.update({"available": False,
                        "reason": bad.get("reason") or "sheet_unavailable",
                        "detail": bad.get("detail") or ""})
    else:
        summary.update({"available": True, "reason": "sheet_found",
                        "detail": (f"指定 sheet 存在，D4 只使用 sheet {summary['sheet']} 的文本"
                                   if summary["sheet"] else
                                   "子要求指定 sheet 均存在，D4 按各子要求 sheet 文本判定")})
    return summary


def _sheet_limit_trace(summary: dict) -> dict:
    """D3 trace 中的 sheet 限定条目：缺 sheet/坏工作簿都带明确 reason/detail。"""
    summary = summary or {}
    checks = list(summary.get("checks") or [])
    primary = next((c for c in checks
                    if _norm_sheet(c.get("sheet")) == _norm_sheet(summary.get("sheet"))), {})
    return {
        "scope": "sheet_limit", "requested": True,
        "available": bool(summary.get("available")),
        "sheet": summary.get("sheet") or "",
        "sheets": list(summary.get("sheets") or []),
        "reason": summary.get("reason") or "",
        "detail": summary.get("detail") or "",
        "chars": int(summary.get("chars") or 0),
        "source": str(primary.get("source") or ""),
        "declared_source": str(summary.get("declared_source") or ""),
        "declared_in": str(summary.get("declared_in") or ""),
        "sheet_names": list(primary.get("sheet_names") or []),
        "metadata_error": str(primary.get("metadata_error") or ""),
        "checks": [{"sheet": c.get("sheet"), "available": bool(c.get("available")),
                    "reason": c.get("reason") or "", "detail": c.get("detail") or "",
                    "chars": int(c.get("chars") or 0),
                    "source": c.get("source") or "",
                    "declared_by": list(c.get("declared_by") or [])}
                   for c in checks],
    }


# ---------------------------------------------------------------- 税额/金额来源自动绑定
# 税额四来源（rate/tax_status/direction/currency）在规则声明 auto（或留空）时，
# 从当前证据文本绑定实际值；sheet 限定时只读该 sheet 的文本，绝不跨表兜底。
# 绑定结果写入 tool_trace.tax_sources / amount_sources；缺来源、候选冲突、坏表
# 一律显式 insufficient，不猜测默认税率/币种/方向。
_TAX_SOURCE_FIELDS = ("direction", "currency", "tax_status", "rate")
_TAX_SOURCE_KEYS = {"rate": "rate_source", "tax_status": "tax_status_source",
                    "direction": "direction_source", "currency": "currency_source"}
_TAX_SOURCE_LABELS = {"rate": "税率", "tax_status": "含税口径",
                      "direction": "方向", "currency": "币种"}
_AUTO_SOURCE_MARKERS = {"auto", "auto_text", "text", "bind", "自动", "文本",
                        "绑定", "自动绑定"}
_RATE_LABEL_RE = re.compile(
    r"(?:增值税)?(?:税率|征收率|税点)\s*(?:为|是|按|适用)?\s*[|｜:：=]?\s*"
    r"(\d+(?:\.\d+)?)\s*(?:%|％|个点)?")
_RATE_VALUE_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(?:%|％|个点)\s*(?:的)?\s*(?:增值税|税率|税点)")
_DIRECTION_ALIASES = {
    "net_to_gross": ("net_to_gross", "不含税转含税", "未税转含税", "不含税到含税",
                     "不含税→含税", "不含税->含税", "不含税换算为含税",
                     "exclusive_to_inclusive", "按不含税", "以不含税", "不含税计"),
    "gross_to_net": ("gross_to_net", "含税转不含税", "含税到不含税",
                     "含税→不含税", "含税->不含税", "含税换算为不含税",
                     "inclusive_to_exclusive", "按含税", "以含税", "含税计"),
}
_CURRENCY_ALIASES = {
    "美元": "USD", "US$": "USD", "USD": "USD", "港币": "HKD", "HK$": "HKD",
    "HKD": "HKD", "欧元": "EUR", "EUR": "EUR", "英镑": "GBP", "GBP": "GBP",
    "日元": "JPY", "JPY": "JPY", "人民币": "CNY", "CNY": "CNY", "RMB": "CNY",
    "￥": "CNY", "¥": "CNY", "元": "CNY",
}
_CURRENCY_RE = re.compile("|".join(
    sorted((re.escape(k) for k in _CURRENCY_ALIASES), key=len, reverse=True)))
_AMOUNT_TOKEN_RE = re.compile(
    r"([¥￥$]?)\s*([0-9][0-9,，]*(?:\.[0-9]+)?)\s*"
    r"(万元|万|元|CNY|USD|HKD|EUR|RMB)?")


def _text_line_items(text: str) -> list:
    return [(i, line) for i, line in enumerate(str(text or "").splitlines(), 1)
            if line.strip()]


def _source_spec(raw) -> dict:
    """来源声明：普通字符串是溯源标签；auto/自动/留空要求从文本绑定实际值。"""
    if isinstance(raw, dict):
        label = str(raw.get("label") or raw.get("source") or raw.get("text") or
                    raw.get("value") or "").strip()
        mode = str(raw.get("mode") or "").strip().lower()
        auto = bool(raw.get("auto")) or mode in ("auto", "text", "bind") \
            or label.lower() in _AUTO_SOURCE_MARKERS
        return {"label": label, "auto": auto, "declared": bool(label or raw)}
    label = str(raw or "").strip()
    low = label.lower()
    auto = (not label) or low in _AUTO_SOURCE_MARKERS or low.startswith("auto:")
    return {"label": label, "auto": auto, "declared": bool(label)}


def _norm_currency(value) -> str:
    s = str(value or "").strip()
    if not s:
        return ""
    if s.upper() in ("CNY", "RMB"):
        return "CNY"
    if s.upper() in ("USD", "HKD", "EUR", "GBP", "JPY"):
        return s.upper()
    return _CURRENCY_ALIASES.get(s) or s.upper()


def _norm_tax_status(value) -> str:
    if isinstance(value, bool):
        return "included" if value else "excluded"
    s = str(value or "").strip().lower()
    if s in ("true", "1", "yes", "y", "含税", "included", "inclusive", "含税价"):
        return "included"
    if s in ("false", "0", "no", "n", "不含税", "未税", "excluded", "exclusive", "净价"):
        return "excluded"
    return ""


def _line_tax_status(line) -> str:
    """单行含税口径；“不含税/未税”必须先于“含税”判断。"""
    s = re.sub(r"\s+", "", str(line or "")).lower()
    if not s:
        return ""
    if any(t in s for t in ("不含税", "不含增值税", "未税", "净价",
                            "excl", "exclusive")):
        return "excluded"
    if any(t in s for t in ("含税", "含增值税", "价税合计", "税价合计",
                            "incl", "inclusive")):
        return "included"
    return ""


def _canon_direction(value) -> str:
    s = str(value or "").strip()
    if not s:
        return ""
    low = s.lower()
    for canon, aliases in _DIRECTION_ALIASES.items():
        for alias in aliases:
            if low == alias.lower() or alias in s:
                return canon
    if s in ("不含税", "未税", "net"):
        return "net_to_gross"
    if s in ("含税", "gross"):
        return "gross_to_net"
    return ""


def _rate_fraction(value):
    """税率统一成小数；13%/13 都视为 0.13，0.13% 保留 0.0013。"""
    try:
        v = Decimal(str(value).strip().replace("%", "").replace("％", ""))
    except Exception:
        return None
    if v <= 0:
        return None
    if v <= 1:
        return v
    if v <= 100:
        return v / Decimal("100")
    return None


def _fmt_decimal(value) -> str:
    try:
        return format(Decimal(str(value)).normalize(), "f")
    except Exception:
        return str(value)


def _rate_tool_value(fraction) -> str:
    """tax_convert/tax_compare 的入参口径：>1% 传百分数，≤1% 传小数。"""
    pct = fraction * Decimal("100")
    return _fmt_decimal(pct if pct > 1 else fraction)


def _rate_candidates(text: str) -> list:
    out, seen = [], set()
    for line_no, line in _text_line_items(text):
        if "税" not in line:
            continue
        for rx in (_RATE_LABEL_RE, _RATE_VALUE_RE):
            for match in rx.finditer(line):
                fraction = _rate_fraction(match.group(1))
                if fraction is None:
                    continue
                key = (str(fraction), line_no)
                if key in seen:
                    continue
                seen.add(key)
                out.append({"value": str(match.group(1)), "fraction": fraction,
                            "quote": line.strip()[:160], "line_no": line_no})
    return out


def _status_candidates(text: str, amount_label: str = "") -> tuple:
    hits, label_hits = [], []
    for line_no, line in _text_line_items(text):
        status = _line_tax_status(line)
        if not status:
            continue
        item = {"status": status, "quote": line.strip()[:160], "line_no": line_no}
        hits.append(item)
        if amount_label and amount_label in line:
            label_hits.append(item)
    use = label_hits or hits
    return use, {x["status"] for x in use}


def _currencies_in(line: str) -> list:
    out = []
    for match in _CURRENCY_RE.finditer(str(line or "")):
        cur = _CURRENCY_ALIASES.get(match.group(0)) or _norm_currency(match.group(0))
        if cur and cur not in out:
            out.append(cur)
    return out


def _currency_candidates(text: str, amount_label: str = "") -> tuple:
    hits, label_hits = [], []
    for line_no, line in _text_line_items(text):
        curs = _currencies_in(line)
        if not curs:
            continue
        item = {"currencies": curs, "quote": line.strip()[:160], "line_no": line_no}
        hits.append(item)
        if amount_label and amount_label in line:
            label_hits.append(item)
    use = label_hits or hits
    all_cur = []
    for item in use:
        for cur in item["currencies"]:
            if cur not in all_cur:
                all_cur.append(cur)
    return use, all_cur


def _direction_candidates(text: str) -> tuple:
    hits = []
    for line_no, line in _text_line_items(text):
        low = line.lower()
        for canon, aliases in _DIRECTION_ALIASES.items():
            if any(alias.lower() in low for alias in aliases):
                hits.append({"direction": canon, "quote": line.strip()[:160],
                             "line_no": line_no})
                break
    return hits, {x["direction"] for x in hits}


def _source_entry(field: str, value="", quote: str = "", line_no: int = 0,
                  declared: str = "", auto: bool = False, bound_from: str = "",
                  reason: str = "", parsed=None, path: str = "",
                  sheet: str = "") -> dict:
    sheet_name = _norm_sheet(sheet)
    quote = str(quote or "").strip()
    locator = ""
    if sheet_name and path and quote:
        got = _locate_in_sheet(path, sheet_name, quote)
        locator = str((got or {}).get("locator") or "")
    if not locator and line_no:
        locator = f"第 {int(line_no)} 行"
    if not sheet_name and parsed is not None and quote:
        sec = _section_for_line(parsed, quote, int(line_no or 0))
        anchor = _norm_sheet(getattr(sec, "anchor", "") if sec else "")
        if anchor and not re.match(r"^(段|第|表|原文)", anchor):
            sheet_name = anchor
    if bound_from == "auto_text":
        source_text = f"自动绑定：{quote[:80]}"
    elif declared:
        source_text = declared
    else:
        source_text = quote[:80]
    return {"field": field, "source_key": _TAX_SOURCE_KEYS.get(field, ""),
            "declared_source": declared, "auto": bool(auto),
            "value": str(value if value is not None else ""),
            "quote": quote[:160], "line": int(line_no or 0),
            "sheet": sheet_name, "locator": locator,
            "bound_from": bound_from, "reason": reason,
            "source_text": source_text}


def _source_conflict(field: str, reason: str, values, quotes, detail: str) -> dict:
    return {"field": field, "reason": reason,
            "values": [str(x) for x in (values or []) if str(x) != ""],
            "quotes": [str(x) for x in (quotes or []) if str(x) != ""],
            "detail": detail}


def _bind_tax_sources(sub: dict, text: str, parsed=None, path: str = "",
                      sheet: str = "", amount_label: str = "",
                      selector: str = "") -> dict:
    """绑定税额四来源；返回 fields/missing/conflicts/values/trace，不写库。"""
    sub = sub or {}
    text = str(text or "")
    fields, missing, conflicts, values = {}, [], [], {}
    rate_cands = _rate_candidates(text)
    rate_fracs = {str(x["fraction"]) for x in rate_cands}
    status_cands, status_set = _status_candidates(text, amount_label)
    direction_cands, direction_set = _direction_candidates(text)
    currency_cands, currency_list = _currency_candidates(text, amount_label)
    explicit_status = _norm_tax_status(sub.get("tax_status"))
    if not explicit_status and "tax_included" in sub:
        explicit_status = _norm_tax_status(sub.get("tax_included"))
    explicit_dir_raw = str(sub.get("direction") or "").strip()
    explicit_dir = _canon_direction(explicit_dir_raw) or explicit_dir_raw
    explicit_cur = _norm_currency(sub.get("currency"))

    # 方向可由“含税口径 + 金额标签”推出；引用同一行原文作为文本证据。
    if not direction_cands:
        status0 = status_cands[0] if status_cands else {}
        derived = ""
        if status0.get("status") == "excluded":
            derived = "net_to_gross"
        elif status0.get("status") == "included":
            derived = "gross_to_net"
        elif amount_label and ("不含税" in amount_label or "未税" in amount_label):
            derived = "net_to_gross"
        elif amount_label and ("含税" in amount_label or "价税" in amount_label):
            derived = "gross_to_net"
        if derived:
            direction_cands = [{"direction": derived,
                                "quote": status0.get("quote") or amount_label,
                                "line_no": int(status0.get("line_no") or 0)}]
            direction_set = {derived}

    # ---- rate
    spec = _source_spec(sub.get("rate_source"))
    explicit_rate = sub.get("rate")
    explicit_frac = _rate_fraction(explicit_rate) if explicit_rate not in (None, "") else None
    cand = rate_cands[0] if rate_cands else None
    if len(rate_fracs) > 1:
        conflicts.append(_source_conflict(
            "rate", "multiple_candidates",
            [x["value"] for x in rate_cands], [x["quote"] for x in rate_cands],
            "税率在文本中出现多个不同取值，不能自动绑定"))
        fields["rate"] = _source_entry(
            "rate", "", rate_cands[0]["quote"], rate_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "multiple_candidates", parsed, path, sheet)
    elif cand is not None and explicit_frac is not None \
            and explicit_frac != cand["fraction"]:
        conflicts.append(_source_conflict(
            "rate", "declared_mismatch", [str(explicit_rate), cand["value"]],
            [cand["quote"]],
            f"规则税率 {explicit_rate} 与文本税率 {cand['value']} 不一致"))
        fields["rate"] = _source_entry(
            "rate", "", cand["quote"], cand["line_no"], spec["label"], spec["auto"],
            "", "declared_mismatch", parsed, path, sheet)
    elif spec["auto"]:
        if cand is not None:
            values["rate"] = _rate_tool_value(cand["fraction"])
            fields["rate"] = _source_entry(
                "rate", values["rate"], cand["quote"], cand["line_no"], spec["label"],
                True, "auto_text", "", parsed, path, sheet)
        else:
            missing.append("rate")
            fields["rate"] = _source_entry(
                "rate", "", "", 0, spec["label"], True, "", "auto_text_missing",
                parsed, path, sheet)
    elif explicit_rate not in (None, ""):
        values["rate"] = str(explicit_rate)
        fields["rate"] = _source_entry(
            "rate", values["rate"], cand["quote"] if cand else "",
            cand["line_no"] if cand else 0, spec["label"], False,
            "declared_text" if cand else "declared", "", parsed, path, sheet)
    elif cand is not None:
        values["rate"] = _rate_tool_value(cand["fraction"])
        fields["rate"] = _source_entry(
            "rate", values["rate"], cand["quote"], cand["line_no"], spec["label"],
            False, "declared_text", "", parsed, path, sheet)
    else:
        missing.append("rate")
        fields["rate"] = _source_entry(
            "rate", "", "", 0, spec["label"], False, "", "declared_text_missing",
            parsed, path, sheet)

    # ---- tax_status
    spec = _source_spec(sub.get("tax_status_source"))
    if len(status_set) > 1:
        conflicts.append(_source_conflict(
            "tax_status", "multiple_candidates",
            sorted(status_set), [x["quote"] for x in status_cands],
            "文本同时出现含税/不含税两种口径，不能自动绑定"))
        fields["tax_status"] = _source_entry(
            "tax_status", "", status_cands[0]["quote"], status_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "multiple_candidates", parsed, path, sheet)
    elif explicit_status and status_cands and explicit_status not in status_set:
        conflicts.append(_source_conflict(
            "tax_status", "declared_mismatch", [explicit_status],
            [status_cands[0]["quote"]],
            "规则含税口径与文本不一致"))
        fields["tax_status"] = _source_entry(
            "tax_status", "", status_cands[0]["quote"], status_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "declared_mismatch", parsed, path, sheet)
    elif spec["auto"]:
        if status_set:
            item = status_cands[0]
            values["tax_status"] = item["status"]
            fields["tax_status"] = _source_entry(
                "tax_status", item["status"], item["quote"], item["line_no"],
                spec["label"], True, "auto_text", "", parsed, path, sheet)
        else:
            missing.append("tax_status")
            fields["tax_status"] = _source_entry(
                "tax_status", "", "", 0, spec["label"], True, "", "auto_text_missing",
                parsed, path, sheet)
    elif explicit_status:
        values["tax_status"] = explicit_status
        fields["tax_status"] = _source_entry(
            "tax_status", explicit_status,
            status_cands[0]["quote"] if status_cands else "",
            status_cands[0]["line_no"] if status_cands else 0,
            spec["label"], False,
            "declared_text" if status_cands else "declared", "", parsed, path, sheet)
    elif status_set:
        item = status_cands[0]
        values["tax_status"] = item["status"]
        fields["tax_status"] = _source_entry(
            "tax_status", item["status"], item["quote"], item["line_no"],
            spec["label"], False, "declared_text", "", parsed, path, sheet)
    else:
        missing.append("tax_status")
        fields["tax_status"] = _source_entry(
            "tax_status", "", "", 0, spec["label"], False, "", "declared_text_missing",
            parsed, path, sheet)

    # ---- direction
    spec = _source_spec(sub.get("direction_source"))
    explicit_dir_canon = _canon_direction(explicit_dir_raw)
    if len(direction_set) > 1:
        conflicts.append(_source_conflict(
            "direction", "multiple_candidates", sorted(direction_set),
            [x["quote"] for x in direction_cands],
            "文本同时出现含税转不含税/不含税转含税两种方向"))
        fields["direction"] = _source_entry(
            "direction", "", direction_cands[0]["quote"], direction_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "multiple_candidates", parsed, path, sheet)
    elif explicit_dir_canon and direction_cands \
            and explicit_dir_canon not in direction_set:
        conflicts.append(_source_conflict(
            "direction", "declared_mismatch", [explicit_dir_canon],
            [direction_cands[0]["quote"]],
            "规则方向与文本方向不一致"))
        fields["direction"] = _source_entry(
            "direction", "", direction_cands[0]["quote"], direction_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "declared_mismatch", parsed, path, sheet)
    elif spec["auto"]:
        if direction_cands:
            item = direction_cands[0]
            values["direction"] = item["direction"]
            fields["direction"] = _source_entry(
                "direction", item["direction"], item["quote"], item["line_no"],
                spec["label"], True, "auto_text", "", parsed, path, sheet)
        else:
            missing.append("direction")
            fields["direction"] = _source_entry(
                "direction", "", "", 0, spec["label"], True, "", "auto_text_missing",
                parsed, path, sheet)
    elif explicit_dir:
        values["direction"] = explicit_dir
        fields["direction"] = _source_entry(
            "direction", explicit_dir,
            direction_cands[0]["quote"] if direction_cands else "",
            direction_cands[0]["line_no"] if direction_cands else 0,
            spec["label"], False,
            "declared_text" if direction_cands else "declared", "", parsed, path, sheet)
    elif direction_cands:
        item = direction_cands[0]
        values["direction"] = item["direction"]
        fields["direction"] = _source_entry(
            "direction", item["direction"], item["quote"], item["line_no"],
            spec["label"], False, "declared_text", "", parsed, path, sheet)
    else:
        missing.append("direction")
        fields["direction"] = _source_entry(
            "direction", "", "", 0, spec["label"], False, "", "declared_text_missing",
            parsed, path, sheet)

    # ---- currency
    spec = _source_spec(sub.get("currency_source"))
    if len(currency_list) > 1:
        conflicts.append(_source_conflict(
            "currency", "multiple_candidates", currency_list,
            [x["quote"] for x in currency_cands],
            "文本出现多个币种，不能自动绑定"))
        fields["currency"] = _source_entry(
            "currency", "", currency_cands[0]["quote"], currency_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "multiple_candidates", parsed, path, sheet)
    elif explicit_cur and currency_list and explicit_cur not in currency_list:
        conflicts.append(_source_conflict(
            "currency", "declared_mismatch", [explicit_cur], [currency_cands[0]["quote"]],
            f"规则币种 {explicit_cur} 与文本币种不一致"))
        fields["currency"] = _source_entry(
            "currency", "", currency_cands[0]["quote"], currency_cands[0]["line_no"],
            spec["label"], spec["auto"], "", "declared_mismatch", parsed, path, sheet)
    elif spec["auto"]:
        if len(currency_list) == 1:
            cur = currency_list[0]
            item = next((x for x in currency_cands if cur in x["currencies"]), {})
            values["currency"] = cur
            fields["currency"] = _source_entry(
                "currency", cur, item.get("quote") or "", item.get("line_no") or 0,
                spec["label"], True, "auto_text", "", parsed, path, sheet)
        else:
            missing.append("currency")
            fields["currency"] = _source_entry(
                "currency", "", "", 0, spec["label"], True, "", "auto_text_missing",
                parsed, path, sheet)
    elif explicit_cur:
        values["currency"] = explicit_cur
        item = next((x for x in currency_cands if explicit_cur in x["currencies"]), {})
        fields["currency"] = _source_entry(
            "currency", explicit_cur, item.get("quote") or "", item.get("line_no") or 0,
            spec["label"], False,
            "declared_text" if currency_cands else "declared", "", parsed, path, sheet)
    elif len(currency_list) == 1:
        cur = currency_list[0]
        item = next((x for x in currency_cands if cur in x["currencies"]), {})
        values["currency"] = cur
        fields["currency"] = _source_entry(
            "currency", cur, item.get("quote") or "", item.get("line_no") or 0,
            spec["label"], False, "declared_text", "", parsed, path, sheet)
    else:
        missing.append("currency")
        fields["currency"] = _source_entry(
            "currency", "", "", 0, spec["label"], False, "", "declared_text_missing",
            parsed, path, sheet)

    autos = [_source_spec(sub.get(_TAX_SOURCE_KEYS[f])).get("auto")
             for f in _TAX_SOURCE_FIELDS]
    if missing:
        detail = "缺少来源：" + "、".join(
            _TAX_SOURCE_LABELS.get(f, f) for f in _TAX_SOURCE_FIELDS if f in missing)
    elif conflicts:
        detail = "来源候选冲突：" + "、".join(
            _TAX_SOURCE_LABELS.get(str(c.get("field")), str(c.get("field")))
            for c in conflicts)
    else:
        detail = "四来源均已从文本/声明绑定"
    trace = {"mode": "auto" if any(autos) else "declared", "requested": True,
             "bound": not missing and not conflicts, "sheet": _norm_sheet(sheet),
             "fields": fields,
             "sources": [fields[f] for f in _TAX_SOURCE_FIELDS if f in fields],
             "missing": list(missing), "conflicts": list(conflicts),
             "values": dict(values), "detail": detail}
    return {"ok": trace["bound"], "fields": fields, "missing": missing,
            "conflicts": conflicts, "values": values, "trace": trace}


def _known_sheet_names(sheet_info: dict) -> list:
    info = sheet_info or {}
    out = []
    for key in ("sheet_names", "content_sheets"):
        for name in info.get(key) or []:
            name = _norm_sheet(name)
            if name and name not in out:
                out.append(name)
    return out


def _occurrence_sheet(occ: dict, parsed, text: str, known: list) -> str:
    if not known:
        return ""
    line = str((occ or {}).get("line") or "")
    line_no = _line_no_of(text, line)
    sec = _section_for_line(parsed, line, line_no)
    anchor = _norm_sheet(getattr(sec, "anchor", "") if sec else "")
    return anchor if anchor in known else ""


def _aggregation_sheet_scope(occs: list, parsed, text: str, known: list,
                             target_sheet: str = "") -> dict:
    """汇总/比较只能落在同一 sheet：未限定且跨 sheet 时显式 insufficient。"""
    known = [_norm_sheet(x) for x in (known or []) if _norm_sheet(x)]
    target = _norm_sheet(target_sheet)
    sheets = []
    for occ in occs or []:
        sheet = _occurrence_sheet(occ, parsed, text, known)
        if sheet and sheet not in sheets:
            sheets.append(sheet)
    info = {"ok": True, "sheets": sheets, "reason": "", "detail": ""}
    if target:
        bad = [x for x in sheets if x != target]
        if bad:
            info.update(ok=False, reason="aggregation_sheet_mismatch",
                        detail=f"汇总值跨出限定 sheet {target}：{'、'.join(bad)}")
        return info
    if len(sheets) > 1:
        info.update(ok=False, reason="aggregation_requires_sheet",
                    detail=("多 sheet 文档的汇总/比较必须显式限定 sheet；"
                            f"当前值分布：{'、'.join(sheets)}"))
    return info


def _labeled_amount_occurrences(text: str, label: str) -> tuple:
    """按金额标签逐行取数；标签行没有可解析金额时进 bad，供汇总拒绝伪造。"""
    occs, bad = [], []
    if not label:
        return occs, bad
    for line_no, line in _text_line_items(text):
        if label not in line:
            continue
        rest = line.split(label, 1)[1]
        match = _AMOUNT_TOKEN_RE.search(rest)
        if not match:
            if rest.strip() and (re.search(r"[:：=|｜]", rest) or re.search(r"\d", rest)):
                bad.append({"line": line.strip()[:160], "line_no": line_no,
                            "reason": "label_without_amount"})
            continue
        try:
            value = Decimal((match.group(2) or "").replace(",", "").replace("，", ""))
        except Exception:
            bad.append({"line": line.strip()[:160], "line_no": line_no,
                        "reason": "bad_amount"})
            continue
        unit = str(match.group(3) or "")
        if unit in ("万元", "万"):
            value *= Decimal("10000")
        currency = _norm_currency(match.group(1)) or _norm_currency(unit)
        occs.append({"value": _fmt_decimal(value), "line": line.strip()[:160],
                     "line_no": line_no, "currency": currency,
                     "tax_status": _line_tax_status(line)})
    return occs, bad


def _scan_amount_meta(text: str, amount_label: str) -> dict:
    status_cands, status_set = _status_candidates(text, amount_label)
    currency_cands, currency_list = _currency_candidates(text, amount_label)
    status_item = status_cands[0] if len(status_set) == 1 else {}
    currency = currency_list[0] if len(currency_list) == 1 else ""
    currency_item = next(
        (x for x in currency_cands if currency in (x.get("currencies") or [])), {})
    return {"currency": currency,
            "tax_status": status_item.get("status") if status_item else "",
            "quote": status_item.get("quote") or currency_item.get("quote") or "",
            "line_no": int(status_item.get("line_no")
                           or currency_item.get("line_no") or 0)}


def _bind_amount_sources(sub: dict, text: str, parsed, sheet_info: dict,
                         sheet: str, agg: str, amount_label: str) -> dict:
    """金额来源绑定：标签取数/汇总只在当前证据文本内，跨 sheet 未限定则 insufficient。"""
    sub = sub or {}
    text = str(text or "")
    agg = str(agg or "all")
    known = _known_sheet_names(sheet_info)
    out = {"ok": True, "amount": None, "values": None, "occurrences": [],
           "currency": "", "tax_status": "", "trace": {},
           "insufficient": "", "detail": "", "compare_fail": False}
    trace = {"tool": "amount_extract", "label": str(amount_label or ""),
             "aggregation": agg, "sheet": _norm_sheet(sheet), "bound": False,
             "occurrences": [], "reason": "", "value": "", "currency": "",
             "tax_status": ""}
    out["trace"] = trace
    explicit = sub.get("amount")
    if explicit not in (None, ""):
        meta = _scan_amount_meta(text, amount_label)
        trace.update({"bound": True, "bound_from": "declared", "value": str(explicit),
                      "currency": meta.get("currency") or "",
                      "tax_status": meta.get("tax_status") or "",
                      "quote": meta.get("quote") or "",
                      "line_no": int(meta.get("line_no") or 0)})
        out.update(amount=str(explicit), currency=meta.get("currency") or "",
                   tax_status=meta.get("tax_status") or "")
        return out
    if not amount_label:
        return out
    occs, bad = _labeled_amount_occurrences(text, amount_label)
    out["occurrences"] = occs
    trace["occurrences"] = [
        {"value": o.get("value"), "quote": o.get("quote") or o.get("line"),
         "line": o.get("line"), "line_no": o.get("line_no"),
         "currency": o.get("currency"), "tax_status": o.get("tax_status")}
        for o in occs]
    if not occs:
        if bad:
            out.update(ok=False, insufficient="aggregation_value_invalid",
                       detail="金额标签存在无法取数的行：" +
                              "；".join(x["line"] for x in bad[:3]))
            trace.update(reason="value_invalid")
        else:
            out.update(ok=False, insufficient="amount_unknown",
                       detail=f"未找到标签「{amount_label}」的金额")
            trace.update(reason="amount_not_found")
        return out
    first = occs[0]
    meta = _scan_amount_meta(text, amount_label)
    out.update(currency=first.get("currency") or meta.get("currency") or "",
               tax_status=first.get("tax_status") or meta.get("tax_status") or "")
    trace.update(currency=out.get("currency") or "",
                 tax_status=out.get("tax_status") or "")
    if agg in ("sum", "compare"):
        if bad:
            out.update(ok=False, insufficient="aggregation_value_invalid",
                       detail="金额标签存在无法取数的行：" +
                              "；".join(x["line"] for x in bad[:3]))
            trace.update(reason="value_invalid")
            return out
        scope = _aggregation_sheet_scope(occs, parsed, text, known, sheet)
        if not scope["ok"]:
            out.update(ok=False, insufficient=scope["reason"],
                       detail=scope["detail"])
            trace.update(sheets=scope["sheets"], reason=scope["reason"])
            return out
        currencies = sorted({o["currency"] for o in occs if o.get("currency")})
        if len(currencies) > 1:
            out.update(ok=False, insufficient="currency_mismatch",
                       detail="汇总金额币种不一致：" + "、".join(currencies))
            trace.update(reason="currency_mismatch", currencies=currencies)
            return out
        values = []
        for occ in occs:
            try:
                values.append(Decimal(str(occ["value"])))
            except Exception:
                out.update(ok=False, insufficient="aggregation_value_invalid",
                           detail=f"金额不可解析：{occ.get('value')}")
                trace.update(reason="value_invalid")
                return out
        if agg == "compare":
            distinct = []
            for value in values:
                if not any(abs(value - seen) < Decimal("1e-9") for seen in distinct):
                    distinct.append(value)
            distinct_text = [_fmt_decimal(v) for v in sorted(distinct)]
            trace.update({"bound": True, "bound_from": "aggregation_compare",
                          "values": [_fmt_decimal(v) for v in values],
                          "distinct": distinct_text,
                          "sheets": scope["sheets"]})
            if len(values) < 2:
                out.update(ok=False, insufficient="compare_insufficient",
                           detail="只有一个金额，无法比较")
                trace.update(reason="compare_insufficient")
                return out
            if len(distinct) > 1:
                out.update(compare_fail=True, amount=_fmt_decimal(values[0]),
                           detail="金额不一致：" + "、".join(distinct_text))
                trace.update(reason="compare_mismatch", result="fail")
            else:
                out.update(amount=_fmt_decimal(values[0]))
            return out
        total = sum(values, Decimal("0"))
        out.update(amount=_fmt_decimal(total),
                   values=[_fmt_decimal(v) for v in values])
        trace.update({"bound": True, "bound_from": "aggregation_sum",
                      "value": _fmt_decimal(total),
                      "values": [_fmt_decimal(v) for v in values],
                      "total": _fmt_decimal(total),
                      "sheets": scope["sheets"]})
        return out
    out.update(amount=str(first["value"]))
    trace.update({"bound": True, "bound_from": "text",
                  "value": str(first["value"]),
                  "currency": out.get("currency") or "",
                  "tax_status": out.get("tax_status") or "",
                  "quote": first.get("quote") or first.get("line") or "",
                  "line_no": int(first.get("line_no") or 0)})
    return out


def _aggregation_bad_lines(metric: str, text: str, occs: list) -> list:
    """指标标签存在但没有可解析数值的行；汇总时不得静默丢弃。"""
    metric = str(metric or "")
    if not metric:
        return []
    occ_lines = {str(o.get("line") or "") for o in (occs or [])}
    bad = []
    for line_no, line in _text_line_items(text):
        if metric not in line or line in occ_lines:
            continue
        rest = line.split(metric, 1)[1]
        if re.search(r"[:：=|｜]", rest) and not re.search(r"\d", rest):
            bad.append({"line": line.strip()[:160], "line_no": line_no,
                        "reason": "label_without_value"})
    return bad


def _judge_aggregation(sub: dict, occs: list, bad: list, agg: str, text: str,
                       parsed, sheet_info: dict, target_sheet: str):
    """sum/compare 两种汇总口径；跨 sheet 未限定、坏行都返回 insufficient。"""
    sub = sub or {}
    metric = str(sub.get("metric") or "")
    if not occs:
        if bad:
            return {"status": "insufficient", "raw_state": "aggregation_value_invalid",
                    "raw_item": {}, "detail": "指标行存在无法取数的值：" +
                    "；".join(x["line"] for x in bad[:3]), "quote": "",
                    "evidence_ok": True,
                    "tool_trace": {"executor": "ruleexec", "aggregation": agg,
                                   "code": "aggregation_value_invalid",
                                   "result": "insufficient",
                                   "bad_lines": bad[:10]}}
        return None
    known = _known_sheet_names(sheet_info)
    scope = _aggregation_sheet_scope(occs, parsed, text, known, target_sheet)
    if not scope["ok"]:
        return {"status": "insufficient", "raw_state": scope["reason"],
                "raw_item": {}, "detail": scope["detail"], "quote": "",
                "evidence_ok": True,
                "tool_trace": {"executor": "ruleexec", "aggregation": agg,
                               "code": scope["reason"], "result": "insufficient",
                               "sheets": scope["sheets"], "target_sheet": target_sheet}}
    if bad:
        return {"status": "insufficient", "raw_state": "aggregation_value_invalid",
                "raw_item": {}, "detail": "指标行存在无法取数的值：" +
                "；".join(x["line"] for x in bad[:3]), "quote": "",
                "evidence_ok": True,
                "tool_trace": {"executor": "ruleexec", "aggregation": agg,
                               "code": "aggregation_value_invalid",
                               "result": "insufficient", "bad_lines": bad[:10],
                               "sheets": scope["sheets"]}}
    values = []
    for occ in occs:
        try:
            values.append(float(occ.get("value")))
        except Exception:
            return {"status": "insufficient", "raw_state": "aggregation_value_invalid",
                    "raw_item": {}, "detail": f"指标不可解析：{occ.get('value')}",
                    "quote": str(occ.get("quote") or ""), "evidence_ok": True,
                    "tool_trace": {"executor": "ruleexec", "aggregation": agg,
                                   "code": "aggregation_value_invalid",
                                   "result": "insufficient", "sheets": scope["sheets"]}}
    currencies = []
    for occ in occs:
        for cur in _currencies_in(str(occ.get("line") or "")):
            if cur not in currencies:
                currencies.append(cur)
    if len(currencies) > 1:
        return {"status": "insufficient", "raw_state": "currency_mismatch",
                "raw_item": {},
                "detail": "汇总涉及的币种不一致：" + "、".join(currencies),
                "quote": "", "evidence_ok": True,
                "tool_trace": {"executor": "ruleexec", "aggregation": agg,
                               "code": "currency_mismatch", "result": "insufficient",
                               "currencies": currencies, "sheets": scope["sheets"]}}
    target = ruleexec._num(str(sub.get("value", sub.get("threshold"))))
    if target is None:
        return {"status": "failed", "raw_state": "aggregation_target_missing",
                "raw_item": {}, "detail": "汇总规则缺少可解析的阈值", "quote": "",
                "evidence_ok": True,
                "tool_trace": {"executor": "ruleexec", "aggregation": agg,
                               "code": "aggregation_target_missing", "result": "failed",
                               "sheets": scope["sheets"]}}
    unit = str(sub.get("unit") or "")
    target_scaled = target * ruleexec._UNIT_SCALE.get(unit, 1) \
        if unit in ruleexec._UNIT_SCALE else target
    op = str(sub.get("op") or sub.get("operator") or ">=")
    quotes = [str(o.get("quote") or o.get("line") or "") for o in occs]
    common = {"executor": "ruleexec", "aggregation": agg, "occurrences": len(values),
              "values": values, "sheets": scope["sheets"], "metric": metric,
              "input": {"metric": metric, "operator": op, "threshold": target,
                        "unit": unit}, "quote": "；".join(quotes[:3])[:300]}
    if agg == "compare":
        distinct = []
        for value in values:
            if not any(abs(value - seen) < 1e-9 for seen in distinct):
                distinct.append(value)
        distinct_text = [_fmt_decimal(v) for v in distinct]
        common["distinct"] = distinct_text
        if len(values) < 2:
            return {"status": "insufficient", "raw_state": "compare_insufficient",
                    "raw_item": {}, "detail": "只有一个值，无法比较", "quote": "",
                    "evidence_ok": True,
                    "tool_trace": {**common, "code": "compare_insufficient",
                                   "result": "insufficient"}}
        if len(distinct) > 1:
            return {"status": "fail", "raw_state": "aggregation_compare",
                    "raw_item": {},
                    "detail": f"{metric} 口径不一致：" + "、".join(distinct_text),
                    "quote": "；".join(quotes[:3])[:300], "evidence_ok": True,
                    "tool_trace": {**common, "code": "compare_mismatch",
                                   "result": "fail",
                                   "detail": f"口径不一致：{'、'.join(distinct_text)}"}}
        return {"status": "pass", "raw_state": "aggregation_compare",
                "raw_item": {},
                "detail": f"{metric} 在 {len(values)} 处取值一致：{distinct_text[0]}",
                "quote": "；".join(quotes[:3])[:300], "evidence_ok": True,
                "tool_trace": {**common, "code": "ok", "result": "pass",
                               "detail": f"取值一致：{distinct_text[0]}"}}
    total = sum(values)
    ok = ruleexec._cmp(total, op, target_scaled)
    if ok is None:
        return {"status": "failed", "raw_state": "aggregation_bad_operator",
                "raw_item": {}, "detail": f"不支持比较符 {op}", "quote": "",
                "evidence_ok": True,
                "tool_trace": {**common, "code": "aggregation_bad_operator",
                               "result": "failed"}}
    _scale = ruleexec._UNIT_SCALE.get(unit, 1) if unit in ruleexec._UNIT_SCALE else 1
    total_rule = (total / _scale) if _scale else total
    detail = (f"{metric} 汇总 {len(values)} 项 = {_fmt_decimal(total_rule)}{unit} "
              f"{op} {_fmt_decimal(target)}{unit}")
    return {"status": "pass" if ok else "fail", "raw_state": "aggregation_sum",
            "raw_item": {}, "detail": detail, "quote": "；".join(quotes[:3])[:300],
            "evidence_ok": True,
            "tool_trace": {**common, "code": "ok", "result": "pass" if ok else "fail",
                           "total": _fmt_decimal(total_rule),
                           "total_base": _fmt_decimal(total),
                           "normalized_total": _fmt_decimal(total),
                           "detail": detail}}


def _manifest_object_id_list(m: dict, items: list) -> tuple[list, str]:
    """manifest 冻结时的对象清单；旧数据缺 objects_json 才回退 items。"""
    ids, objs = [], []
    try:
        objs = json.loads(m.get("objects_json") or "[]")
    except Exception:
        objs = []
    if isinstance(objs, list):
        for obj in objs:
            oid = str((obj or {}).get("object_id") or "").strip() if isinstance(obj, dict) else ""
            if oid and oid not in ids:
                ids.append(oid)
    if ids:
        return ids, "objects_json"
    for item in (items or []):
        oid = str((item or {}).get("object_id") or "").strip()
        if oid and oid not in ids:
            ids.append(oid)
    return ids, ("items_json" if ids else "unknown")


def _required_evidence_terms(item: dict) -> list:
    """跨文件证据核验项：显式 required_evidence（含子要求），不拿整段判据猜。"""
    chunks = []

    def _add(value):
        if isinstance(value, (list, tuple, set)):
            for one in value:
                _add(one)
        elif isinstance(value, dict):
            _add(value.get("required_evidence") or value.get("evidence_required") or "")
        else:
            text = str(value or "").strip()
            if text:
                chunks.append(text)

    _add((item or {}).get("required_evidence") or (item or {}).get("evidence_required"))
    for sub in ((item or {}).get("subrequirements") or []):
        if isinstance(sub, dict):
            _add(sub.get("required_evidence") or sub.get("evidence_required"))
    terms = []
    for chunk in chunks:
        for term in re.split(r"[、,，;；/]", chunk):
            term = term.strip()
            if len(term) >= 2 and term not in terms:
                terms.append(term)
    return terms


def _parse_document_cached(doc: dict, cache: dict):
    """同一轮 D3 内复用解析结果，避免每条规则重复读盘。"""
    path = str((doc or {}).get("path") or "")
    key = str((doc or {}).get("id") or path or "_missing")
    if key in cache:
        return cache[key]
    text, parsed, error = "", None, ""
    if path:
        try:
            # L149：统一解析入口（内容寻址缓存）。agent-parse 已写入的产物命中时 0 次重解析；
            # RULEPROOF_PARSE_CACHE=0 时逐字回退为直连解析（异常语义与改前一致）。
            from . import parse_bridge as _pb_parse
            parsed = _pb_parse.parse_document(path)
            text = parsed.text or ""
        except Exception as e:
            error = f"{type(e).__name__}: {e}"
    cache[key] = (text, parsed, error)
    return cache[key]


def _document_set_scope(item: dict, object_ids: list, object_source: str,
                        docs_by_id: dict, parse_cache: dict) -> dict:
    """document_set 可用性：对象数>1 且 required_evidence 在 >=2 个 manifest 文件中可见。"""
    info = {"scope": "document_set", "available": False, "reason": "",
            "object_count": len(object_ids), "object_source": object_source,
            "evaluated": True, "evidence_terms": _required_evidence_terms(item),
            "parsed_objects": 0, "cross_file_evidence": [], "found_terms": [],
            "shared_terms": [], "evidence_object_ids": [], "parse_errors": []}
    if len(object_ids) <= 1:
        info["reason"] = "manifest_object_count_le_1"
        return info
    if not info["evidence_terms"]:
        info["reason"] = "no_evidence_terms"
        return info
    texts = {}
    for oid in object_ids:
        doc = docs_by_id.get(oid)
        if not doc:
            info["parse_errors"].append({"object_id": oid, "error": "document_missing"})
            continue
        text, _parsed, error = _parse_document_cached(doc, parse_cache)
        if text.strip():
            texts[oid] = text
        elif error:
            info["parse_errors"].append({"object_id": oid, "error": error})
    info["parsed_objects"] = len(texts)
    if len(texts) < 2:
        info["reason"] = "fewer_than_two_parsed_objects"
        return info
    found = []
    for term in info["evidence_terms"]:
        hit_ids = [oid for oid, text in texts.items() if term in text]
        if hit_ids:
            found.append({"term": term, "object_ids": hit_ids})
    info["found_terms"] = found
    # 跨文件证据：至少两个不同文件能看到 required_evidence 项（同项或互补项均可）。
    hit_ids = []
    for row in found:
        for oid in row["object_ids"]:
            if oid not in hit_ids:
                hit_ids.append(oid)
    info["evidence_object_ids"] = hit_ids
    info["shared_terms"] = [
        row for row in found if len(row.get("object_ids") or []) >= 2]
    # 跨文件证据可以是同一证据项出现在多个文件，也可以是不同证据项互补分布在多个文件。
    info["available"] = len(hit_ids) >= 2
    info["cross_file_evidence"] = found if info["available"] else []
    info["reason"] = "cross_file_evidence_found" if info["available"] else "no_cross_file_evidence"
    return info


def _save(mid, item, d1, d2, d3, d4, d5, conclusion, execution):
    import hashlib
    key = f'{item.get("object_id")}|{item.get("rule_id")}'
    rid = "mres-" + hashlib.sha1((mid + key).encode()).hexdigest()[:12]
    c = db.connect()
    try:
        c.execute("INSERT OR REPLACE INTO manifest_result(id,manifest_id,item_key,object_id,rule_id,rule_code,"
                  "d1_json,d2_json,d3_json,d4_json,d5_json,conclusion,execution,updated_at) "
                  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (rid, mid, key, item.get("object_id") or "", item.get("rule_id") or "",
                   item.get("code") or "", json.dumps(d1, ensure_ascii=False),
                   json.dumps(d2, ensure_ascii=False), json.dumps(d3, ensure_ascii=False),
                   json.dumps(d4, ensure_ascii=False), json.dumps(d5, ensure_ascii=False),
                   conclusion, execution, db.now()))
        c.commit()
    finally:
        c.close()
    return rid


# ===========================================================================
# LaneP（2026-11-23）：judge 逐点五态落盘（point_state）
#
# 背景（docs/qa/judge模拟校准_20261123.md §0③ / §1.2-1）：judge 的逐点五态结论此前只进
# manifest_result.d4_json/d5_json 与 llm_trace；A 臂评测库在 /tmp 且跑完即弃 →
# 「5 态 κ 不可计算」，人工校准只能读 2 态（该点位是否产出 finding）。本段在 `_save`
# 之后把 D1–D5 的**逐点位（文档 × 规则码）五态结论**同步写 point_state，供只读查询/
# 人工校准直接导出「逐文档逐点位五态表』（5 态 κ 需两条判定结果，见
# scripts/qa/d5_point_log_query.py）。
#
# 约束（LaneP 任务书）：
#   1) 纯落库：不读改写 d1–d5 任何字段、不新增 LLM 调用、不改执行/判定顺序；
#   2) 开关 RULEPROOF_D5_POINT_LOG 默认 1；显式 0/false/no/off → 回旧行为（0 行、0 DDL）；
#   3) 幂等 upsert：同一次审核（batch = audit_run.id）内同 (case, file, point) 只有一行，
#      id 由 (batch, case, file, point) 确定性派生 → INSERT ON CONFLICT(id) DO UPDATE；
#      两次独立审核 = 两个 audit_run = 两行 → 5 态 κ 可算；
#   4) 写失败不阻断主链：整段 try/except + LOG.warning（铁律 2：不得静默）。
#
# 回滚：开关=0；表结构无需回滚（新增 5 列均带 DEFAULT，只加列不回填不删数据；
#       pstates.record 旧写入路径与本段互不影响）。
# ===========================================================================
_D5_POINT_LOG_ENV = "RULEPROOF_D5_POINT_LOG"
_D5_POINT_LOG_OFF = ("0", "false", "no", "off")
_D5_POINT_LOG_SOURCE = "manifest_exec.d5"
# point_state 已有列：id/batch_id/point_id/state/confidence/created_at/file_id/reason/quote/title。
# 这里只补 judge 语义字段（老库首次落盘时幂等升级，与 direct_draft/password_reset 同模式）。
# L109（2026-11-25）：列定义单一事实源 = app/db.py
# RUNTIME_EXTENSION_COLUMNS["point_state"]；本模块只在运行期兜底（老库/最小夹具库）。
_D5_POINT_LOG_COLS = db.RUNTIME_EXTENSION_COLUMNS["point_state"]
_D5_POINT_LOG_COLS_READY = False


def d5_point_log_enabled() -> bool:
    """RULEPROOF_D5_POINT_LOG 唯一解析（默认 1；显式 0/false/no/off 回旧行为）。"""
    return str(os.environ.get(_D5_POINT_LOG_ENV, "1") or "").strip().lower() not in _D5_POINT_LOG_OFF


def d5_point_log_batch(mid: str) -> str:
    """一次审核的批次键 = 该 manifest 最新 audit_run.id（无 audit_run 时回落 manifest id）。

    口径：重跑同一 case 会新建 audit_run → 新批次（5 态 κ 需要两条判定）；
    同一次审核内重复执行同一 manifest → 同批次 → 按 id upsert，不产生重复行。
    """
    mid = str(mid or "")
    try:
        with db.session() as c:
            row = c.execute("SELECT id FROM audit_run WHERE manifest_id=? "
                            "ORDER BY created_at DESC, rowid DESC LIMIT 1", (mid,)).fetchone()
            if row is not None and str(row["id"] or ""):
                return str(row["id"])
    except Exception:  # 铁律 2：批次解析失败留痕，回落 manifest id（不阻断主链）
        logging.getLogger(__name__).warning(
            "D5 逐点五态落盘：批次解析失败，回落 manifest id=%s", mid, exc_info=True)
    return ("mid:" + mid) if mid else ""


def _d5_point_log_ensure_cols() -> bool:
    """幂等补齐 point_state 的 judge 字段（老库自动升级；只加列）。"""
    global _D5_POINT_LOG_COLS_READY
    if _D5_POINT_LOG_COLS_READY:
        return True
    try:
        with db.session() as c:
            cols = {str(r[1]) for r in c.execute("PRAGMA table_info(point_state)")}
            if not cols:
                return False
            db.ensure_runtime_columns(c, "point_state")
        _D5_POINT_LOG_COLS_READY = True
        return True
    except Exception:  # 铁律 2：升级失败留痕；本段整体不阻断主链
        logging.getLogger(__name__).warning(
            "D5 逐点五态落盘：point_state judge 字段升级失败（不阻断主链）", exc_info=True)
        return False


def _d5_point_five_state(raw_state: str) -> str:
    """D5 汇总态 → point_state 五态；执行失败不是业务结论，按 unknown 入账（不伪造 pass/fail）。"""
    normal = normalize_state(raw_state or "")
    return "unknown" if normal == "execution_failed" else normal


def _d5_point_judge_flags(d4: dict, d5: dict) -> tuple:
    """返回 (fail_closed, quote_ok)，口径见模块注释。

    fail_closed=1：该点位结论被保护性机制降级/阻断（批协议异常、引文门禁 fail-closed、
    执行失败、范围未核验封顶），不是模型直接五态结论。
    quote_ok：无 fail 结论 → -1（不涉及）；有 fail 结论且全部过引文门禁 → 1；否则 0。
    """
    d4 = d4 if isinstance(d4, dict) else {}
    d5 = d5 if isinstance(d5, dict) else {}
    subs = [s for s in (d4.get("subs") or []) if isinstance(s, dict)]
    raw_state = str(d5.get("status") or "")
    fail_subs = [s for s in subs if str(s.get("status") or "") == "fail"]
    blocked_gate = [s for s in subs
                    if (s.get("evidence_gate") or {}).get("passed") is False]
    fail_closed = 0
    if raw_state in ("blocked", "failed", "execution_failed"):
        fail_closed = 1
    if any((s.get("raw_item") or {}).get("batch_protocol_error") for s in subs):
        fail_closed = 1
    if any(str(s.get("downgraded_from") or "") == "fail" for s in subs):
        fail_closed = 1
    # 只算「保护性降级/阻断」；needs_model 是缺模型未执行（raw=unknown），不是 fail-closed。
    if any(str(s.get("status") or "") == "failed" for s in subs):
        fail_closed = 1
    if isinstance(d4.get("evidence_gate"), dict) and d4["evidence_gate"].get("error"):
        fail_closed = 1
    if fail_subs:
        quote_ok = 1 if all((s.get("evidence_gate") or {}).get("passed") is True
                            for s in fail_subs) else 0
    elif blocked_gate:
        quote_ok = 0
    else:
        quote_ok = -1
    return int(fail_closed), int(quote_ok)


def _d5_point_state_row(*, case_id: str, mid: str, batch: str, item: dict,
                        path: str, d4: dict, d5: dict) -> dict:
    """由单条 manifest item 的 D4/D5 结论构造 point_state 行（纯读，不改入参）。"""
    import hashlib as _hl
    item = item if isinstance(item, dict) else {}
    d4 = d4 if isinstance(d4, dict) else {}
    d5 = d5 if isinstance(d5, dict) else {}
    code = str(item.get("code") or "")
    file_id = os.path.basename(str(path or "") or "")
    raw_state = str(d5.get("status") or "")
    state = _d5_point_five_state(raw_state)
    fail_closed, quote_ok = _d5_point_judge_flags(d4, d5)
    subs = [s for s in (d4.get("subs") or []) if isinstance(s, dict)]
    fail_subs = [s for s in subs if str(s.get("status") or "") == "fail"]
    blocked_subs = [s for s in subs if (s.get("evidence_gate") or {}).get("passed") is False]
    reason = str(d5.get("reason") or d5.get("detail") or "").strip()
    if not reason:
        reason = {"pass": "判定满足（D5 汇总）", "fail": "判定不满足（D5 汇总）",
                  "na": "不适用（D5 汇总）", "insufficient": "证据不足（D5 汇总）",
                  "unknown": "无法判断（D5 汇总）"}.get(state, "无法判断（D5 汇总）")
    if raw_state in ("blocked", "failed", "execution_failed"):
        reason = "执行失败：" + reason
    quote = ""
    for _pool in (fail_subs, blocked_subs, subs):
        for _s in _pool:
            _q = str(_s.get("quote") or (_s.get("evidence_gate") or {}).get("quote") or "")
            if _q:
                quote = _q
                break
        if quote:
            break
    # L78（2026-11-24）：多实例 cap 截断可观测统一落 point_state（默认 0 列；
    # 只有确定性多实例规则且 TRUNCATION_VISIBLE=1 时才非 0，既有行/查询逐字段不变）。
    _mi = d5.get("multi_instance") if isinstance(d5.get("multi_instance"), dict) else {}
    return {
        "id": "psd5-" + _hl.sha1(
            f"{batch}|{case_id}|{file_id}|{code}".encode()).hexdigest()[:16],
        "batch_id": str(batch or ""),
        "case_id": str(case_id or ""),
        "point_id": code,
        "state": state,
        "confidence": None,
        "reason": reason[:300],
        "quote": quote[:200],
        "title": str(item.get("name") or code or "")[:60],
        "file_id": file_id,
        "source": _D5_POINT_LOG_SOURCE,
        "raw_state": raw_state[:40],
        "fail_closed": fail_closed,
        "quote_ok": quote_ok,
        "generated_count": int(_mi.get("generated_count") or 0) if _mi else 0,
        "kept_count": int(_mi.get("kept_count") or 0) if _mi else 0,
        "cap_truncated": 1 if _mi.get("cap_truncated") else 0,
        "mi_limit": int(_mi.get("limit") or 0) if _mi else 0,
        "created_at": db.now(),
    }


def _d5_point_state_upsert(row: dict) -> None:
    """按确定性 id upsert（同批次同点位重复执行只保留一行，不产生重复台账）。"""
    cols = list((row or {}).keys())
    if not cols:
        return
    sets = ",".join(f"{k}=excluded.{k}" for k in cols if k != "id")
    sql = (f"INSERT INTO point_state({','.join(cols)}) "
           f"VALUES({','.join('?' * len(cols))}) "
           f"ON CONFLICT(id) DO UPDATE SET {sets}")
    with db.session() as c:
        c.execute(sql, [row[k] for k in cols])


def log_d5_point_state(*, case_id: str = "", mid: str = "", batch: str = "",
                       item: dict = None, path: str = "",
                       d4: dict = None, d5: dict = None) -> bool:
    """judge 逐点五态落 point_state（开关默认 1；失败只 warning，绝不阻断主链）。"""
    if not d5_point_log_enabled():
        return False
    try:
        if not _d5_point_log_ensure_cols():
            return False
        row = _d5_point_state_row(case_id=case_id, mid=mid, batch=batch,
                                  item=item, path=path, d4=d4, d5=d5)
        if not row.get("point_id"):
            return False
        _d5_point_state_upsert(row)
        return True
    except Exception:  # 铁律 2：写库失败必须留结构化 warning，不阻断主链
        logging.getLogger(__name__).warning(
            "D5 逐点五态落盘失败（不阻断主链）case=%s manifest=%s point=%s batch=%s",
            case_id, mid, (item or {}).get("code"), batch, exc_info=True)
        return False


def _activate(mid: str, item: dict, result_id: str) -> None:
    """每个 (case, object, rule) 与每个子要求只保留一个 active result。"""
    c = None
    try:
        import json as _j
        c = db.connect()
        row = c.execute("SELECT case_id FROM audit_manifest WHERE id=?", (mid,)).fetchone()
        if not row:
            return
        _case = row["case_id"]; _obj = str(item.get("object_id") or ""); _code = str(item.get("code") or "")
        c.execute("INSERT INTO manifest_active(case_id,object_id,rule_code,result_id,updated_at) "
                  "VALUES(?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code) DO UPDATE SET "
                  "result_id=excluded.result_id, updated_at=excluded.updated_at",
                  (_case, _obj, _code, result_id, db.now()))
        _rr = c.execute("SELECT d4_json FROM manifest_result WHERE id=?", (result_id,)).fetchone()
        try:
            _subs = (_j.loads((_rr["d4_json"] if _rr else "") or "{}")).get("subs") or []
        except Exception:
            _subs = []
        if not _subs:
            _subs = [{"id": "", "status": ""}]
        for _sub in _subs:
            c.execute("INSERT INTO manifest_active_sub(case_id,object_id,rule_code,sub_id,result_id,status,updated_at) "
                      "VALUES(?,?,?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code,sub_id) DO UPDATE SET "
                      "result_id=excluded.result_id,status=excluded.status,updated_at=excluded.updated_at",
                      (_case, _obj, _code, str(_sub.get("id") or ""), result_id,
                       str(_sub.get("status") or ""), db.now()))
        c.commit()
    except Exception:
        logging.getLogger(__name__).debug("manifest active update skipped", exc_info=True)
    finally:
        if c is not None:
            try: c.close()
            except Exception: pass


_ACTIVE_SCOPE_ENV = "RULEPROOF_ACTIVE_RUN_SCOPE"


def _active_scope_enabled() -> bool:
    """P0-3 回退开关：RULEPROOF_ACTIVE_RUN_SCOPE=0/false/off/no 恢复旧行为（active 跨轮累积）。"""
    raw = str(os.environ.get(_ACTIVE_SCOPE_ENV, "1") or "").strip().lower()
    return raw not in ("0", "false", "off", "no")


def _latest_run_manifest_id(case_id: str) -> str:
    """案例最近一次 audit_run 的 manifest_id（run 轨迹是「本轮」的唯一权威入口）。"""
    c = None
    try:
        c = db.connect()
        ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                       "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
        return str((ar["manifest_id"] if ar else "") or "")
    except Exception:
        logging.getLogger(__name__).debug("latest run manifest lookup skipped", exc_info=True)
        return ""
    finally:
        if c is not None:
            try: c.close()
            except Exception: pass


def _expire_out_of_scope_active(case_id: str, mid: str, items: list) -> dict:
    """P0-3：run 结束后摘除「本 manifest 里不存在」的 case 级 active 指针（方案 A）。

    问题（架构审测确认，2026-11-21）：``manifest_active`` 主键是
    ``(case_id,object_id,rule_code)``，是 **case 级可变指针** 而非 run/manifest 级；
    ``run()`` 只对本轮 item 做 upsert，从不清理上一轮遗留。规则集收窄/对象删除后，
    报告（report._manifest_rows 只读 active）、台账（audit_ledger.summary）、门禁
    （report_gate 的 frozen/ledger 口径）依然会 JOIN 到 **旧 manifest** 的 rule×object
    结果 → 同一份报告混两个冻结清单：五态数 / finding 数 / 门禁数不同源，
    L1/L2 的 F1 无法归属单一清单（L7「可复算」不成立）。

    方案选择（A，不选 B）：本函数在 **写侧收口**——过期 = 摘除 active 指针，不新增
    run_id/manifest_id 列、不改表结构、不做迁移。理由：
      1. 读取 active 的消费者有 10+ 处（report / audit_ledger / review / project /
         audit_zone / semantic_*），其中多数不在本步允许改动的文件内；B 需要迁移 + 改
         全部读取方，风险中高；A 让所有读取方**无需加过滤**就天然同源。
      2. 旧结果不丢：manifest_result / audit_run / audit_manifest 原样保留，历史轮次
         仍可复算，只是不再作为「当前口径」被统计。
      3. 回退可逆：``RULEPROOF_ACTIVE_RUN_SCOPE=0`` 即恢复旧行为（不收口）；
         代码层 git revert 即可，无迁移残留。
    只对「本案例当前 run 的 manifest」收口（非当前/历史 manifest 重放不收口），避免
    定向复审、补证重判等增量路径被误清：这既覆盖 project.audit / manifest.execute 的
    正式轮次，又保留 reaudit_evidence 等「非当前轮」语义。

    :returns: 收口统计（expired/kept/skipped），供 run() 返回与审计追溯。
    """
    if not case_id:
        return {"enabled": _active_scope_enabled(), "skipped": "no_case"}
    if not _active_scope_enabled():
        # 回退开关：旧行为（active 跨轮累积）可复现
        return {"enabled": False, "skipped": "env_disabled", "env": _ACTIVE_SCOPE_ENV}
    current_mid = _latest_run_manifest_id(case_id)
    if current_mid and str(current_mid) != str(mid):
        # 本 manifest 不是案例当前 run 的清单（历史清单重放/增量路径）：不做跨轮清理
        return {"enabled": True, "skipped": "not_current_run_manifest",
                "manifest_id": mid, "current_manifest_id": current_mid}
    keep = set()
    for it in items or []:
        it = it or {}
        code = str(it.get("code") or it.get("rule_code") or "")
        if not code:
            continue
        keep.add((str(it.get("object_id") or ""), code))
    c = None
    try:
        c = db.connect()
        rows = [dict(r) for r in c.execute(
            "SELECT object_id,rule_code,result_id FROM manifest_active WHERE case_id=?",
            (case_id,))]
        stale = [(str(r.get("object_id") or ""), str(r.get("rule_code") or ""))
                 for r in rows
                 if (str(r.get("object_id") or ""),
                     str(r.get("rule_code") or "")) not in keep]
        if stale:
            c.executemany(
                "DELETE FROM manifest_active WHERE case_id=? AND object_id=? AND rule_code=?",
                [(case_id, o, code) for o, code in stale])
            c.executemany(
                "DELETE FROM manifest_active_sub WHERE case_id=? AND object_id=? AND rule_code=?",
                [(case_id, o, code) for o, code in stale])
            c.commit()
        out = {"enabled": True, "manifest_id": mid, "kept": len(rows) - len(stale),
               "expired": len(stale),
               "expired_keys": [{"object_id": o, "rule_code": code}
                                for o, code in stale[:50]],
               "env": _ACTIVE_SCOPE_ENV}
        if stale:
            try:
                R.audit_logs.log(
                    actor="system", action="manifest.active_scope_expired",
                    object=str(mid or ""),
                    after=json.dumps({"case_id": case_id, "manifest_id": mid,
                                      "kept": out["kept"], "expired": out["expired"],
                                      "expired_keys": out["expired_keys"],
                                      "env": _ACTIVE_SCOPE_ENV},
                                     ensure_ascii=False))
            except Exception:
                logging.getLogger(__name__).debug(
                    "active scope expiry audit skipped", exc_info=True)
        return out
    except Exception:
        # 收口失败不得影响已完成的执行结果：仅记录，下一轮会再次收口
        logging.getLogger(__name__).warning(
            "active run-scope cleanup failed case=%s manifest=%s", case_id, mid,
            exc_info=True)
        return {"enabled": True, "error": "cleanup_failed", "manifest_id": mid}
    finally:
        if c is not None:
            try: c.close()
            except Exception: pass


def _audit_parsed_reconcile(mid: str, recon: dict) -> None:
    """执行期解析对账审计：失配时落 manifest.parsed_input_mismatch（只记 sha/chars，不落全文）。"""
    try:
        mismatch = [x for x in (recon.get("items") or []) if not x.get("equal")]
        brief = mismatch[:100]
        n_mismatch = int(recon.get("n_mismatch") or 0)
        R.audit_logs.log(
            actor="system", action="manifest.parsed_input_mismatch", object=str(mid or ""),
            after=json.dumps({
                "manifest_id": str(mid or ""),
                "mode": recon.get("mode") or "",
                "blocked": bool(recon.get("blocked")),
                "n_checked": int(recon.get("n_checked") or 0),
                "n_mismatch": n_mismatch,
                "frozen_parsed_sha": recon.get("frozen_sha") or "",
                "items": [{"document_id": x.get("document_id"),
                           "filename": x.get("filename"),
                           "frozen_sha": x.get("frozen_sha"),
                           "live_sha": x.get("live_sha"),
                           "chars": x.get("chars"),
                           "frozen_chars": x.get("frozen_chars"),
                           "live_error": x.get("live_error")} for x in brief],
                "items_truncated": len(brief) < n_mismatch,
            }, ensure_ascii=False, default=str))
    except Exception:
        logging.getLogger(__name__).debug("parsed reconcile audit skipped", exc_info=True)


def _reconcile_parsed(mid: str, closure: dict, docs_by_id: dict,
                      parse_cache: dict) -> dict:
    """执行期解析对账（P0 准确率修复第 2 步）：live 重解析文本 vs 冻结 parsed_artifacts。

    守卫侧（manifest.execution_guard.verify_parsed）只能证明「闭包自洽 + 文件字节未变 +
    解析器配置未漂移」；执行期 D2/D3 仍会重新解析当前文件。本函数把「本次实际解析文本」
    与冻结 ``closure.parsed_artifacts.items[].text_sha256`` 逐份比对，让“同一 manifest_id
    两次解析不一致”留下显式证据（sha 级，不落全文）。

    - 复用 ``_parse_document_cached``：本函数即 run 内第一次解析（填 _parse_cache），
      后续 item 循环命中同一缓存，不产生第二次解析；
    - 冻结 parse 失败（空 sha）时，live 也空才算一致；
    - ``RULEPROOF_FREEZE_PARSE_RECONCILE``：observe（默认，只观测 + 失配落审计，不阻断）/
      block（失配时返回 blocked=True，由调用方 0 执行）/ 0|off（显式关闭）。
    """
    import hashlib
    mode = str(os.environ.get("RULEPROOF_FREEZE_PARSE_RECONCILE", "observe") or "").strip().lower()
    if mode in ("0", "off", "false", "no", "disabled"):
        return {"enabled": False, "reason": "reconcile_disabled"}
    block = mode == "block"
    try:
        parsed = (closure or {}).get("parsed_artifacts")
        if not isinstance(parsed, dict) or not parsed:
            return {"enabled": False, "reason": "no_frozen_parsed"}
        rows = parsed.get("items") if isinstance(parsed.get("items"), list) else []
        if parsed.get("skipped") or not rows:
            return {"enabled": False, "reason": "frozen_parsed_empty",
                    "frozen_sha": str(parsed.get("sha") or "")}
        items = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            oid = str(row.get("document_id") or "")
            frozen_sha = str(row.get("text_sha256") or "")
            doc = (docs_by_id or {}).get(oid)
            live_text, live_error = "", ""
            if doc:
                live_text, _live_parsed, live_error = _parse_document_cached(doc, parse_cache)
                live_text = str(live_text or "")
            else:
                live_error = "document_missing"
            live_sha = hashlib.sha256(live_text.encode("utf-8")).hexdigest() if live_text else ""
            items.append({"document_id": oid,
                          "filename": str(row.get("filename") or ""),
                          "frozen_sha": frozen_sha,
                          "live_sha": live_sha,
                          "chars": len(live_text),
                          "frozen_chars": int(row.get("chars") or 0),
                          "live_error": str(live_error or ""),
                          "equal": frozen_sha == live_sha})
        mismatch = [x for x in items if not x["equal"]]
        recon = {"enabled": True, "mode": "block" if block else "observe",
                 "n_checked": len(items), "n_mismatch": len(mismatch),
                 "frozen_sha": str(parsed.get("sha") or ""),
                 "items": items}
        if mismatch:
            if block:
                recon["blocked"] = True
                recon["error"] = "冻结解析输入不可复现：parsed_artifact_text_changed"
            _audit_parsed_reconcile(mid, recon)
        return recon
    except Exception as exc:
        # observe 语义：对账自身异常绝不阻断主链（也不许静默：run 返回值可见）
        return {"enabled": False, "reason": "reconcile_error",
                "error": f"{type(exc).__name__}: {str(exc)[:160]}"}


# ============================ P0-B（2026-11-24）清单完整性 fail-closed
# 依据 docs/CURRENT/81-引擎架构独立评审吸收_20261124.md §二 P0-B、外部评审 F2 / 十项稳定性检查 #1/#4：
#   - execution_guard 抛异常/返回不可验证 → 无法证明清单完整性 → **不执行**，0 正式写入
#     （manifest_result/manifest_active/finding），返回显式系统状态 + 审计；
#   - 新清单（guard.legacy=False）闭包加载失败/加载为空 → 同上阻断；合法新清单闭包必须可加载；
#   - 旧清单（无 closure 字段，guard 返回 legacy=True）允许执行，但显式标
#     legacy=True/closure_unverifiable=True 并审计，**不得与「已验证」混淆**；
#   - 只阻止「未验证清单」，不改任何规则判定语义。
# 开关 RULEPROOF_INTEGRITY_FAIL_CLOSED 默认 1；=0 逐字段回退旧行为
# （guard 异常 → {"ok":True,"skipped":True,"error":"guard_unavailable"} 继续；闭包异常 → {} 继续）。
_INTEGRITY_FAIL_CLOSED_ENV = "RULEPROOF_INTEGRITY_FAIL_CLOSED"
_INTEGRITY_BLOCKED_ERROR = "integrity_unverifiable"


def integrity_fail_closed_enabled() -> bool:
    """P0-B 开关：默认开；显式 0/false/no/off/disabled → 回退旧行为（回退杆）。"""
    raw = str(os.environ.get(_INTEGRITY_FAIL_CLOSED_ENV, "1") or "").strip().lower()
    return raw not in ("0", "false", "no", "off", "disabled")


def _audit_integrity_event(mid: str, action: str, payload: dict) -> bool:
    """写清单完整性事件审计（尽力而为；失败只 warning，不改变阻断/放行结论）。"""
    try:
        R.audit_logs.log(actor="system", action=str(action), object=str(mid or ""),
                         after=json.dumps(payload or {}, ensure_ascii=False, default=str))
        return True
    except Exception:  # noqa: BLE001 - 审计失败不得静默：写 warning
        logging.getLogger(__name__).warning(
            "manifest integrity audit failed action=%s manifest=%s", action, mid,
            exc_info=True)
        return False


def _integrity_blocked_result(mid: str, reason: str, guard_error: str = "",
                              guard: dict = None, **extra) -> dict:
    """未验证清单的统一阻断返回：items=[]，调用方在 _save/_activate 之前就返回。"""
    out = {"ok": False, "blocked": True, "manifest_id": mid, "items": [],
           "total": 0, "completed": 0, "incomplete": 0,
           "error": _INTEGRITY_BLOCKED_ERROR,
           "blocked_reason": str(reason or ""),
           "system_blocked": True,
           "integrity_fail_closed": 1,
           "guard_error": str(guard_error or "")[:300],
           "guard": guard or {}}
    out.update(extra)
    return out


def _run_core(mid: str, external_facts: dict = None) -> dict:
    m = _load_manifest(mid)
    if not m:
        return {"error": "审核清单不存在"}
    # T-29 冻结闭包（V01/V02）：执行前校验冻结完整性/绑定边界；违规时 0 执行并落审计。
    # manifest.execution_guard 负责写 manifest.integrity_verified / integrity_blocked 审计；
    # 旧清单（无 closure 字段）返回 ok=True+legacy=True，不误伤历史夹具。
    # P0-B：guard 异常/返回不可验证 = 完整性不可证明 → 不执行（开关默认开；=0 回退旧行为）。
    _integrity_fc = integrity_fail_closed_enabled()
    _guard_error = ""
    try:
        from . import manifest as _mf_guard
        _mguard = _mf_guard.execution_guard(mid)
    except Exception as _ge:  # noqa: BLE001 - fail-closed 分支在下方显式处理
        _mguard = None
        _guard_error = f"{type(_ge).__name__}: {str(_ge)[:240]}"
        logging.getLogger(__name__).warning(
            "manifest execution guard unavailable manifest=%s: %s", mid, _guard_error,
            exc_info=True)
    _guard_unavailable = not isinstance(_mguard, dict) or "ok" not in _mguard
    if _guard_unavailable:
        if not _guard_error:
            _guard_error = "guard_unverifiable_result:" + (
                type(_mguard).__name__ if _mguard is not None else "None")
        _mguard = {}
        if _integrity_fc:
            _payload = {"manifest_id": mid,
                        "error": _INTEGRITY_BLOCKED_ERROR,
                        "blocked_reason": "execution_guard_unavailable",
                        "guard_error": _guard_error,
                        "integrity_fail_closed": 1,
                        "executed": 0,
                        "note": "execution_guard 异常/返回不可验证 → 清单完整性不可证明："
                                "0 执行、0 manifest_result/manifest_active/finding"}
            _audit_integrity_event(mid, "manifest.execution_guard_unavailable", _payload)
            return _integrity_blocked_result(
                mid, "execution_guard_unavailable", _guard_error,
                guard={"ok": False, "skipped": True, "error": "guard_unavailable",
                       "guard_error": _guard_error})
        # 回退杆（RULEPROOF_INTEGRITY_FAIL_CLOSED=0）：旧行为 → guard_unavailable 继续执行
        _mguard = {"ok": True, "skipped": True, "error": "guard_unavailable"}
    if _mguard.get("ok") is False:
        _codes = ",".join(str(x.get("code") or "") for x in (_mguard.get("issues") or [])[:8])
        return {"ok": False, "blocked": True, "manifest_id": mid, "items": [],
                "error": "冻结完整性阻断：" + (_codes or "unknown"), "guard": _mguard}
    # ================================ A1（2026-11-21）输出侧两道守卫在 run 内收口
    # 原因（选「移进 run」而不是「两处入口改调 execute」）：
    #   1) 入口不止两处——project.audit、manifest.execute、HTTP /manifest/execute、
    #      复核/重审/CLI 增量路径都直接调 run；逐个改入口会漏（review_routes 已有
    #      except 回落 run 的兜底分支，改了入口也拦不住）；
    #   2) 守卫必须卡在 `_save/_activate` **之前**：先落库再过滤，manifest_result /
    #      manifest_active 里会残留越界判定，报告/台账仍能 JOIN 到它们；
    #   3) 只改调用方无法覆盖未来入口，收口到 run 后任何调用方天然受冻结边界约束。
    # 两道守卫：
    #   ① 外部实时值覆盖冻结值 → 0 执行（manifest.external_override_rejected）；
    #   ② item.object_id 不在闭包 binding.allowed_object_ids → 不落库/不激活/不进 out
    #      （manifest.scope_violation_dropped）。
    # P0-B：闭包加载异常/不可验证 → 0 执行（开关默认开；=0 回退旧行为）。
    # F-04（build56 外部独立审查 P1）：历史无闭包清单已由 execution_guard 显式阻断
    # （ok=False · code=closure_missing；legacy 只是诊断标记），run 侧不再存在
    # 「legacy 放行执行」分支 —— 能走到这里的清单闭包必须可加载。
    _closure_error = ""
    try:
        from . import manifest as _mf_a1
        _a1_closure = _mf_a1.load_closure(mid) or {}
        if not isinstance(_a1_closure, dict):
            _closure_error = ("closure_unverifiable_result:"
                              + type(_a1_closure).__name__)
            _a1_closure = {}
    except Exception as _ce:  # noqa: BLE001 - fail-closed 分支在下方显式处理
        _a1_closure = {}
        _closure_error = f"{type(_ce).__name__}: {str(_ce)[:240]}"
    _closure_unverifiable = False
    if _integrity_fc:
        _closure_unverifiable = bool(_closure_error) or not _a1_closure
        if _closure_unverifiable:
            _audit_integrity_event(mid, "manifest.execution_closure_unavailable", {
                "manifest_id": mid,
                "error": _INTEGRITY_BLOCKED_ERROR,
                "blocked_reason": "closure_unavailable",
                "closure_error": _closure_error,
                "integrity_fail_closed": 1,
                "executed": 0,
                "note": "新清单要求可校验闭包，但执行期闭包加载失败/为空 → "
                        "完整性不可证明：0 执行、0 manifest_result/manifest_active/finding",
            })
            return _integrity_blocked_result(
                mid, "closure_unavailable", _closure_error,
                guard=_mguard, legacy=False)
    _a1_external = external_facts
    _a1_binding_by_rid = None
    if _a1_closure:
        _a1_frozen_rows = (_a1_closure.get("external_results") or {}).get("items") or []
        _a1_frozen_ext = {str(x.get("key")): x.get("value") for x in _a1_frozen_rows}
        _a1_merged = dict(_a1_frozen_ext)
        _a1_overridden = []
        for _k, _v in (external_facts or {}).items():
            _k = str(_k)
            if _k in _a1_frozen_ext:
                try:
                    _same = _mf_a1._digest(_a1_frozen_ext[_k], 16) == _mf_a1._digest(_v, 16)
                except Exception:
                    _same = _a1_frozen_ext[_k] == _v
                if not _same:
                    _a1_overridden.append(_k)
            else:
                _a1_merged[_k] = _v
        if _a1_overridden:
            _a1_ext_payload = {"frozen_keys": sorted(_a1_frozen_ext),
                               "rejected_live_keys": _a1_overridden,
                               "boundary": "closure.external_results",
                               "note": "冻结闭包已固化外部查询结果，拒绝用实时值覆盖"}
            try:
                R.audit_logs.log(actor="system", action="manifest.external_override_rejected",
                                 object=mid,
                                 after=json.dumps(_a1_ext_payload, ensure_ascii=False))
            except Exception:
                logging.getLogger(__name__).debug("external override audit skipped",
                                                  exc_info=True)
            return {"ok": False, "blocked": True, "manifest_id": mid, "items": [],
                    "total": 0, "completed": 0, "incomplete": 0,
                    "error": "外部查询结果已在冻结闭包中固化，拒绝用实时值覆盖："
                             + ",".join(_a1_overridden),
                    "external": _a1_ext_payload, "guard": _mguard}
        _a1_external = _a1_merged or None
        _a1_binding_by_rid = {}
        for _b in (_a1_closure.get("binding") or {}).get("rules") or []:
            _a1_binding_by_rid[str(_b.get("rule_id") or "")] = _b
            _a1_binding_by_rid.setdefault("code:" + str(_b.get("rule_code") or ""), _b)
    _a1_dropped = []
    case_id = m.get("case_id") or ""
    try:
        _case_row = R.cases.get(case_id) or {}
    except Exception:
        _case_row = {}
    try:
        items = json.loads(m.get("items_json") or "[]")
    except Exception:
        items = []
    _object_ids, _object_source = _manifest_object_id_list(m, items)
    _docs_by_id = {str(d.get("id") or ""): d for d in R.cases.documents(case_id) if d.get("id")}
    _parse_cache = {}
    # P0 准确率修复第 2 步（执行期解析对账）：守卫之后、item 循环之前，把本次将被 D2/D3
    # 消费的解析文本与冻结 parsed_artifacts 逐份对账。默认 observe（只观测+落审计，不阻断）；
    # RULEPROOF_FREEZE_PARSE_RECONCILE=block 时才 0 执行。_parse_cache 由对账填充，item 循环
    # 命中同一缓存，不产生第二次解析。
    try:
        from . import manifest as _mf_recon
        _frozen_closure = _mf_recon.load_closure(mid)
    except Exception:
        _frozen_closure = {}
    _parsed_recon = _reconcile_parsed(mid, _frozen_closure, _docs_by_id, _parse_cache)
    if _parsed_recon.get("blocked"):
        return {"ok": False, "blocked": True, "manifest_id": mid, "items": [],
                "total": 0, "completed": 0, "incomplete": 0,
                "error": "冻结解析输入不可复现：parsed_artifact_text_changed",
                "parsed_reconciliation": _parsed_recon}
    _sheet_cache = {}
    _docset_cache = {}
    _evidence_gate_total = {"checked": 0, "passed": 0, "blocked": 0, "blocked_subs": []}
    # LaneP（2026-11-23）：judge 逐点五态落盘批次键。只在该开关打开时解析一次；
    # 关闭时零 DB 查询/零 DDL（= 旧行为逐字段不变）。
    _d5_point_batch = d5_point_log_batch(mid) if d5_point_log_enabled() else ""
    # L80 / P0-C（2026-11-24，89 号规格 / 87 号 D1 第③步）：裁决来源台账（默认关）。
    # 只在开关=1 时解析 run_id 并逐实例收集行；=0 时零查询/零 DDL/零内存增量，
    # 与接入前逐字段一致（逐字节回退）。写失败由服务层兜底，不阻断审核。
    _adj_on = adjudication_ledger.enabled()
    _adj_rows = [] if _adj_on else None
    _adj_run_id = ""
    if _adj_on:
        _adj_run_id = _d5_point_batch or d5_point_log_batch(mid) or ("mid:" + str(mid))
    # 轮 C（2026-11-22）：单文档聚合判定预判（RULEPROOF_JUDGE_BATCH=1 才执行；关闭时
    # _batch_cache=None，_semantic_eval 走旧逐点位路径，逐字段不变）。
    _batch_cache, _batch_meta = None, None
    if _judge_batch_enabled():
        try:
            _batch_cache, _batch_meta = _judge_batch_document(
                mid, case_id, items, _docs_by_id, _case_row, _parse_cache,
                _sheet_cache, _a1_binding_by_rid)
        except Exception:
            _batch_cache, _batch_meta = None, {"used": False, "fallback": "exception"}
            logging.getLogger(__name__).warning(
                "轮C 聚合判定预判异常 → 回落逐点位判定", exc_info=True)
        if _batch_meta:
            logging.getLogger(__name__).info(
                "轮C 聚合判定预判：groups=%s points=%s cached=%s calls=%s "
                "protocol_errors=%s timeouts=%s run_failures=%s fallback=%s",
                _batch_meta.get("groups"), _batch_meta.get("points"),
                _batch_meta.get("cached"), _batch_meta.get("calls"),
                _batch_meta.get("protocol_errors"), _batch_meta.get("timeouts"),
                _batch_meta.get("run_failures"), _batch_meta.get("fallback") or "-")
    out = []
    for item in items:
        code = item.get("code") or ""
        _item_obj = str(item.get("object_id") or "")
        doc = _docs_by_id.get(_item_obj) or _doc(case_id, _item_obj)
        # D1 适用范围：复用冻结路由结论（业务类型不得用扩展名/文件名裸子串重判）
        d1 = _d1_from_frozen_route(item, _case_row, doc)
        # D2 规则版本：优先使用清单冻结的 slots 快照；旧清单无 slots 才回退 latest。
        r = R.rules.get(item.get("rule_id") or "") or {}
        slots = item.get("slots") if isinstance(item.get("slots"), dict) else None
        _frozen_snapshot = isinstance(slots, dict)
        if slots is None:
            v = R.rules.latest_version(item.get("rule_id") or "") or {}
            try:
                slots = json.loads(v.get("slots_json") or "{}")
            except Exception:
                slots = {}
        d2 = {"status": "bound" if r and (slots or item.get("version")) else "missing",
              "rule_code": code, "version": item.get("version") or "",
              "frozen_snapshot": _frozen_snapshot,
              "requirement": item.get("requirement") or ""}
        # D3 证据绑定：document/block/row 口径保持不变；sheet/document_set 用真实能力判断
        path = (doc or {}).get("path") or ""
        text, parsed, parse_error = _parse_document_cached(doc, _parse_cache)
        required = _required_evidence_text(_item_evidence_required(item))
        _scopes_req = list((item.get("execution_hints") or {}).get("evidence_scope") or ["document"])
        _dtp = str((doc or {}).get("doc_type") or "").lower()
        _has_rows = _dtp in ("xlsx", "xls") or "\n" in text
        _sheet = _sheet_scope(doc, text, parsed, _sheet_cache)
        nature = str(item.get("nature") or "")
        subs = item.get("subrequirements") or []
        # sheet 限定：规则 slots / 子要求显式声明；未声明时保持原 document 口径
        _sheet_rule_spec = _rule_sheet_limit(item, slots)
        _sheet_sub_specs = []
        for _si, _sub in enumerate(subs or []):
            _sp = _sheet_limit_spec(_sub) if isinstance(_sub, dict) else _sheet_limit_spec({})
            if _sp.get("requested"):
                _sheet_sub_specs.append((_si, _sp))
        _sheet_limit = _sheet_limit_summary(
            doc, parsed, _sheet, _sheet_rule_spec, _sheet_sub_specs, parse_error)
        _ds_requested = "document_set" in _scopes_req
        if _ds_requested:
            _ds_key = (str(item.get("rule_id") or code), tuple(_required_evidence_terms(item)))
            if _ds_key not in _docset_cache:
                _docset_cache[_ds_key] = _document_set_scope(
                    item, _object_ids, _object_source, _docs_by_id, _parse_cache)
            _doc_set = _docset_cache[_ds_key]
        else:
            _doc_set = {"scope": "document_set", "available": False, "evaluated": False,
                        "reason": "not_requested", "object_count": len(_object_ids),
                        "object_source": _object_source,
                        "evidence_terms": _required_evidence_terms(item),
                        "parsed_objects": 0, "cross_file_evidence": [],
                        "found_terms": [], "shared_terms": [],
                        "evidence_object_ids": [], "parse_errors": []}
        _sheet["detail"] = _SCOPE_REASON_DETAILS.get(str(_sheet.get("reason") or ""), "")
        _doc_set["detail"] = _SCOPE_REASON_DETAILS.get(str(_doc_set.get("reason") or ""), "")
        # 声明了 sheet 限定时，D3 的 sheet 能力以“指定 sheet 是否真实可读”为准，
        # 使 sheet trace/d3.sheet 与 sheet_limit 结论一致，避免“scope 可用但 D3 不足”的矛盾。
        _sheet["limit"] = _sheet_limit
        if _sheet_limit.get("requested"):
            _sheet["requested_sheet"] = str(
                _sheet_limit.get("sheet") or "、".join(_sheet_limit.get("sheets") or []))
            _sheet["available"] = bool(_sheet_limit.get("available"))
            _sheet["reason"] = str(_sheet_limit.get("reason") or _sheet.get("reason") or "")
            _sheet["detail"] = str(_sheet_limit.get("detail") or
                                   _SCOPE_REASON_DETAILS.get(_sheet["reason"], ""))
        _avail = {"document": bool(text.strip()), "block": bool(text.strip()),
                  "row": bool(text.strip()) and _has_rows,
                  "sheet": bool(_sheet.get("available")) and bool(_sheet_limit.get("available")),
                  "document_set": bool(_doc_set.get("available"))}
        _missing = [x for x in _scopes_req if not _avail.get(x, False)]
        _doc_reason = ("text_present" if text.strip()
                       else ("document_path_missing" if not path
                             else ("document_unparsed" if parse_error else "document_empty")))
        _scope_trace = [
            {"scope": "document", "available": _avail["document"],
             "reason": _doc_reason, "chars": len(text), "parse_error": parse_error},
            {"scope": "block", "available": _avail["block"],
             "reason": "text_present" if _avail["block"] else _doc_reason},
            {"scope": "row", "available": _avail["row"],
             "reason": ("row_anchors_present" if _avail["row"]
                        else ("document_empty" if not text.strip() else "no_row_anchor"))},
            _sheet,
            _doc_set,
        ]
        if _sheet_limit.get("requested"):
            _scope_trace.append(_sheet_limit_trace(_sheet_limit))
        _d3_ok = (bool(text.strip()) and not _missing
                  and bool(_sheet_limit.get("available")))
        _d3_reason = "bound"
        if not text.strip():
            _d3_reason = _doc_reason
        elif not _sheet_limit.get("available"):
            _d3_reason = str(_sheet_limit.get("reason") or "sheet_limit_unavailable")
        elif _missing:
            _d3_reason = "missing_scopes"
        d3 = {"status": "bound" if _d3_ok else "insufficient",
              "reason": _d3_reason,
              "document": (doc or {}).get("filename") or "",
              "required": required, "chars": len(text),
              "evidence_scope": _scopes_req,
              "available_scopes": [k for k, v in _avail.items() if v],
              "missing_scopes": _missing,
              "sheet": _sheet, "document_set": _doc_set,
              "sheet_limit": _sheet_limit,
              "sheet_limited": bool(_sheet_limit.get("requested")),
              "evaluation_sheet": (str(_sheet_limit.get("sheet") or "")
                                   if _sheet_limit.get("requested") else ""),
              "evaluation_chars": (len(_sheet_text_for(parsed, _sheet_limit.get("sheet")))
                                   if _sheet_limit.get("requested")
                                   and _sheet_limit.get("sheet") else len(text)),
              "sheet_count": int(_sheet.get("sheet_count") or 0),
              "multi_sheet": bool(_sheet.get("multi_sheet")),
              "sheet_names": list(_sheet.get("sheet_names") or []),
              "document_set_objects": len(_object_ids),
              "cross_file_evidence": list(_doc_set.get("cross_file_evidence") or []),
              "trace": _scope_trace}
        # D3 证据四分类标注（架构约束 2）：D3 绑定什么类型的证据必须显式，
        # 供 D4 门禁/报告/审计选择正确核验方式（缺失/计算/关系不得按 quote 处理）。
        try:
            d3["evidence_type"] = _item_evidence_type(item, slots)
            d3["evidence_contract"] = {
                "quote": "原文/单元格逐字引文",
                "missing": "presence + 搜索范围 + 解析完整性（不以 quote 表达）",
                "computation": "tool_trace 输入/结果/聚合轨迹",
                "relation": "决策表命中行/对象关系 + 可回查坐标",
            }.get(d3["evidence_type"], "")
        except Exception:
            logging.getLogger(__name__).debug("D3 evidence type skipped", exc_info=True)
        # D1 补充：冻结的 applicable_when / scope.tags 在本次执行真正参与适用性判断
        # （只读 manifest item 快照，冻结后的实时规则/词典变更不改变本次结论）
        _d1_scope = _d1_scope_condition(item, d1, _case_row, doc, text)
        if _d1_scope:
            d1.update(_d1_scope)
        # D4 执行：支持一条规则多个子要求
        if d1["status"] != "applicable":
            d4 = {"status": "skipped", "detail": "不适用", "subs": []}
        elif d2["status"] != "bound":
            d4 = {"status": "blocked", "detail": "规则版本不存在", "subs": []}
        elif d3["status"] != "bound":
            _d4_reason = str(d3.get("reason") or "insufficient")
            if _sheet_limit.get("requested") and not _sheet_limit.get("available"):
                _lim_sheet = _sheet_limit.get("sheet") or "?"
                _lim_why = _sheet_limit.get("detail") or _sheet_limit.get("reason") or ""
                _d4_why = f"指定 sheet {_lim_sheet} 不可用：{_lim_why}"
                _d4_reason = str(_sheet_limit.get("reason") or _d4_reason)
            elif d3.get("missing_scopes"):
                _d4_why = "证据范围不可用：" + "、".join(d3.get("missing_scopes") or [])
            else:
                _d4_why = "文档无可用文本"
            d4 = {"status": "insufficient", "detail": _d4_why, "subs": [],
                  "reason": _d4_reason}
            if _sheet_limit.get("requested"):
                d4["sheet_limit"] = _sheet_limit
        else:
            # sheet 限定生效时，D4 的全部输入（DMN facts/子要求/工具取数）只用该 sheet 文本；
            # 未限定则继续用整份文档文本，保持原行为。
            _rule_sheet = (_norm_sheet(_sheet_limit.get("sheet"))
                           if _sheet_limit.get("requested") else "")
            _d4_text = _sheet_text_for(parsed, _rule_sheet) if _rule_sheet else text
            _d4_parsed = _parsed_for_sheet(parsed, _rule_sheet) if _rule_sheet else parsed
            # TL-5 接线：D4 判定作用域内提供文档级 provenance（数值判定不得用视觉/未知来源取数）
            from ..engine import hooks as _hk_prov
            _d4_prov = _hk_prov.provenance_of_parsed(_d4_parsed)
            _sub_sheet_map = dict(_sheet_limit.get("sub_sheets") or {})
            _dmn_all = _eval_decision_tables(item, _d4_text, case_id, _a1_external,
                                             parsed=_d4_parsed, path=path,
                                             sheet_limit=_rule_sheet, case=_case_row)
            # F-22：决策表作用域 skipped 必须显式归一为不适用，不得继续走语义/证据链
            # 被误判为“证据不足/未命中”。仅对「规则体就是决策表」的项目级回退项生效。
            _dmn_results = list((_dmn_all or {}).get("results") or [])
            _dmn_skipped = bool(_dmn_results) and all(
                str((x or {}).get("state") or "") == "skipped" for x in _dmn_results)
            _is_dmn_carrier = not bool(subs)
            # 决策表已求值但无命中：产品语义 no_match=pass（查过、无违反）、unknown=证据不足；
            # 不得落回 wrapper 的语义分支变成 needs_model/语义误判（业务有效性 task-22 反馈）。
            _dmn_states = [str((x or {}).get("state") or "") for x in _dmn_results]
            _dmn_evaluated = bool(_dmn_results) and not _dmn_skipped \
                and not (_dmn_all or {}).get("conflict") \
                and not (_dmn_all or {}).get("match")
            _dmn_no_match_pass = bool(_dmn_evaluated and _dmn_states
                                      and all(s == "no_match" for s in _dmn_states))
            _dmn_unknown = bool(_dmn_evaluated and any(
                s in ("unknown", "no_facts", "missing_facts") for s in _dmn_states))
            _dmn_bad = bool(_dmn_evaluated and any(
                s in ("error", "missing", "missing_or_unpublished", "unpublished")
                for s in _dmn_states))
            sub_out = []
            for i, sub in enumerate(subs or [slots]):
                sub = sub or {}
                sid = str(sub.get("id") or f"S{i+1}")
                _sub_sheet = _norm_sheet(_sub_sheet_map.get(f"sub:{i}")) or _rule_sheet
                _sub_text = _sheet_text_for(parsed, _sub_sheet) if _sub_sheet else text
                _tx = {"trace": {}}
                _amount_trace = {}
                _raw = ""
                _raw_item = {}
                # sheet 限定时不再把文件名当 sheet 证据；未限定时保持原“正文+文件名”口径
                _evidence_text = (_sub_text if _sub_sheet
                                  else text + "\n" + str((doc or {}).get("filename") or ""))
                if _dmn_skipped and _is_dmn_carrier:
                    sub_out.append({"id": sid, "status": "na",
                                    "raw_state": "decision_table_skipped",
                                    "raw_item": {}, "evidence_ok": False,
                                    "detail": "决策表作用域不适用（skipped）",
                                    "quote": "",
                                    "decision_tables": _dmn_results})
                    continue
                if _is_dmn_carrier and _dmn_no_match_pass:
                    sub_out.append({"id": sid, "status": "pass",
                                    "raw_state": "decision_table_no_match",
                                    "raw_item": {}, "evidence_ok": True,
                                    "detail": "决策表已求值：无命中行（不构成不满足）",
                                    "quote": "",
                                    "tool_trace": {"executor": "decision_table",
                                                   "state": "no_match",
                                                   "results": _dmn_results}})
                    continue
                if _is_dmn_carrier and _dmn_unknown:
                    sub_out.append({"id": sid, "status": "insufficient",
                                    "raw_state": "decision_table_unknown",
                                    "raw_item": {}, "evidence_ok": False,
                                    "detail": "决策表已求值但关键事实未知（证据不足），转人工",
                                    "quote": "",
                                    "presence": {"found": False, "search_scope": "document",
                                                 "parse_completeness":
                                                     {"parsed": bool(str(_d4_text or "").strip()),
                                                      "chars": len(str(_d4_text or ""))}},
                                    "tool_trace": {"executor": "decision_table",
                                                   "state": "unknown",
                                                   "results": _dmn_results}})
                    continue
                if _is_dmn_carrier and _dmn_bad:
                    sub_out.append({"id": sid, "status": "failed",
                                    "raw_state": "decision_table_unavailable",
                                    "raw_item": {}, "evidence_ok": False,
                                    "detail": "决策表不可用（未发布/版本缺失/执行错误），不能当作通过",
                                    "quote": "",
                                    "tool_trace": {"executor": "decision_table",
                                                   "state": "error",
                                                   "results": _dmn_results}})
                    continue
                _sub_ev = sub.get("required_evidence") or sub.get("evidence_required") or ""
                if not _sub_ev and not subs:
                    # 无 subrequirements 时回退整份 slots：证据与 D3 同源（F-11）
                    _sub_ev = _item_evidence_required(item)
                _ev_ok, _ev_missing = _evidence_ok(_sub_ev, _evidence_text)
                if not _ev_ok:
                    sub_out.append({"id": sid, "status": "insufficient",
                                    "raw_state": "evidence_missing", "raw_item": {},
                                    "detail": f"缺少子要求证据：{_ev_missing}",
                                    "quote": "", "evidence_ok": False,
                                    "missing_evidence": _ev_missing,
                                    **({"sheet": _sub_sheet} if _sub_sheet else {})})
                    continue
                if _dmn_all.get("conflict"):
                    _cf = _dmn_all["conflict"]
                    sub_out.append({"id": sid, "status": "insufficient",
                                    "raw_state": ("decision_table_error"
                                                  if _cf.get("result") == "error"
                                                  else "decision_table_conflict"), "raw_item": {},
                                    "detail": (f"决策表 {_cf.get('code')} 不可用：{_cf.get('error') or '未发布/版本缺失'}"
                                               if _cf.get("result") == "error"
                                               else f"决策表 {_cf.get('code')} {_cf.get('version') or ''} 命中多条且未定义优先级"),
                                    "quote": "", "evidence_ok": True,
                                    "tool_trace": {"executor": "decision_table",
                                                   "code": _cf.get("code"), "version": _cf.get("version"),
                                                   "hit_policy": _cf.get("hit_policy"),
                                                   "hits": _cf.get("hits") or [],
                                                   "result": "conflict",
                                                   "facts": _cf.get("facts") or {}}})
                    continue
                if _dmn_all.get("match"):
                    _hit = _dmn_all["match"]
                    _hits_all = _hit.get("hits") or []
                    if str(_hit.get("hit_policy") or "") == "collect" and len(_hits_all) > 1:
                        for _hi, _h in enumerate(_hits_all):
                            _src = _source_trace_fields(_h)
                            sub_out.append({"id": f"{sid}#{_hi+1}", "status": "fail",
                                            "raw_state": "decision_table_collect", "raw_item": {},
                                            "detail": f"决策表 {_hit.get('code')} 第{_hi+1}行命中：{_h.get('message') or ''}",
                                            "quote": "", "evidence_ok": True,
                                            "source_location_missing": bool(_src["source_location_missing"]),
                                            "source_locator": _src["source_locator"],
                                            "source_quote": _src["source_quote"],
                                            "tool_trace": {"executor": "decision_table",
                                                           "code": _hit.get("code"),
                                                           "version": _hit.get("version"),
                                                           "hit_policy": "collect",
                                                           "decision_policy": _dmn_all.get("decision_policy"),
                                                           "row": _h.get("row"),
                                                           "message": _h.get("message"),
                                                           "severity": _h.get("severity"),
                                                           "facts": _hit.get("facts") or {},
                                                           "result": "fail",
                                                           **_src}})
                        continue
                    _h0 = (_hit.get("hits") or [{}])[0]
                    _src0 = _source_trace_fields(_h0)
                    sub_out.append({"id": sid, "status": "fail",
                                    "raw_state": "decision_table_match", "raw_item": {},
                                    "detail": f"决策表 {_hit.get('code')} {_hit.get('version') or ''} 命中：{_h0.get('message') or ''}",
                                    "quote": "", "evidence_ok": True,
                                    "source_location_missing": bool(_src0["source_location_missing"]),
                                    "source_locator": _src0["source_locator"],
                                    "source_quote": _src0["source_quote"],
                                    "tool_trace": {"executor": "decision_table",
                                                   "code": _hit.get("code"),
                                                   "version": _hit.get("version"),
                                                   "hit_policy": _hit.get("hit_policy"),
                                                   "decision_policy": _dmn_all.get("decision_policy"),
                                                   "matches": len(_dmn_all.get("matches") or []),
                                                   "row": _h0.get("row"),
                                                   "message": _h0.get("message"),
                                                   "severity": _h0.get("severity"),
                                                   "facts": _hit.get("facts") or {},
                                                   "result": "fail",
                                                   **_src0}})
                    continue
                _trace = {"decision_tables": _dmn_all.get("results") or []}
                if sub.get("tool"):
                    from ..engine import tools as _tools
                    _sub2 = dict(sub)
                    _tool_name = str(_sub2.get("tool") or "")
                    _agg = str(_sub2.get("aggregation")
                               or (item.get("execution_hints") or {}).get("aggregation")
                               or "all")
                    _amount_label = str(_sub2.get("amount_label") or "").strip()
                    _src = []
                    if _tool_name in ("tax_convert", "tax_compare"):
                        _tx = _bind_tax_sources(
                            _sub2, _sub_text, parsed=_d4_parsed, path=path,
                            sheet=_sub_sheet or _rule_sheet,
                            amount_label=_amount_label,
                            selector=str(_sub2.get("selector") or "gross"))
                        if _tx.get("missing"):
                            _f = _tx["missing"][0]
                            _label = _TAX_SOURCE_LABELS.get(_f, _f)
                            sub_out.append({"id": sid, "status": "insufficient",
                                            "raw_state": f"{_f}_source_unknown",
                                            "raw_item": {},
                                            "detail": f"缺少{_label}来源 "
                                                      f"{_TAX_SOURCE_KEYS.get(_f, _f)}",
                                            "quote": "", "evidence_ok": True,
                                            "tax_sources": _tx.get("trace") or {},
                                            "tool_trace": {"tool": _tool_name,
                                                           "code": f"{_f}_source_unknown",
                                                           "result": "insufficient",
                                                           "tax_sources": _tx.get("trace") or {}}})
                            continue
                        if _tx.get("conflicts"):
                            _cf = (_tx.get("conflicts") or [{}])[0]
                            _f = str(_cf.get("field") or "rate")
                            sub_out.append({"id": sid, "status": "insufficient",
                                            "raw_state": f"{_f}_source_conflict",
                                            "raw_item": {},
                                            "detail": _cf.get("detail") or
                                                      f"{_TAX_SOURCE_LABELS.get(_f, _f)}来源冲突",
                                            "quote": "", "evidence_ok": True,
                                            "tax_sources": _tx.get("trace") or {},
                                            "tool_trace": {"tool": _tool_name,
                                                           "code": f"{_f}_source_conflict",
                                                           "result": "insufficient",
                                                           "tax_sources": _tx.get("trace") or {}}})
                            continue
                        _vals = _tx.get("values") or {}
                        if _sub2.get("rate") in (None, "") and _vals.get("rate"):
                            _sub2["rate"] = _vals["rate"]
                        if _sub2.get("direction") in (None, "") and _vals.get("direction"):
                            _sub2["direction"] = _vals["direction"]
                        if _sub2.get("currency") in (None, "") and _vals.get("currency"):
                            _sub2["currency"] = _vals["currency"]
                        if _sub2.get("tax_included") is None and _vals.get("tax_status"):
                            _sub2["tax_included"] = (_vals["tax_status"] == "included")
                        for _f in ("rate", "tax_status", "direction", "currency"):
                            _entry = (_tx.get("fields") or {}).get(_f) or {}
                            _key = _TAX_SOURCE_KEYS.get(_f, "")
                            if not _key:
                                continue
                            if _entry.get("bound_from") == "auto_text" \
                                    or not str(_sub2.get(_key) or "").strip():
                                _sub2[_key] = _entry.get("source_text") or _key
                    _agg_eff = ("sum" if _tool_name == "money_sum"
                                and not _sub2.get("values") else _agg)
                    if _tool_name in ("tax_convert", "tax_compare", "money_compare",
                                      "money_sum"):
                        _amount_info = _bind_amount_sources(
                            _sub2, _sub_text, _d4_parsed, _sheet,
                            _sub_sheet or _rule_sheet, _agg_eff, _amount_label)
                        _amount_trace = _amount_info.get("trace") or {}
                        if _amount_info.get("insufficient"):
                            _code = _amount_info["insufficient"]
                            sub_out.append({"id": sid, "status": "insufficient",
                                            "raw_state": _code, "raw_item": {},
                                            "detail": _amount_info.get("detail") or
                                                      "金额来源不可用",
                                            "quote": "", "evidence_ok": True,
                                            "amount_sources": _amount_trace,
                                            "tool_trace": {"executor": "tool",
                                                           "tool": _tool_name,
                                                           "code": _code,
                                                           "result": "insufficient",
                                                           "aggregation": _agg_eff,
                                                           "amount_sources": _amount_trace}})
                            continue
                        if _amount_info.get("compare_fail"):
                            _quote = "；".join(
                                str(x.get("quote") or "")
                                for x in (_amount_info.get("occurrences") or [])[:3])
                            sub_out.append({"id": sid, "status": "fail",
                                            "raw_state": "aggregation_compare",
                                            "raw_item": {},
                                            "detail": _amount_info.get("detail") or "金额不一致",
                                            "quote": _quote[:300], "evidence_ok": True,
                                            "amount_sources": _amount_trace,
                                            "tool_trace": {**(_amount_trace or {}),
                                                           "executor": "tool",
                                                           "tool": _tool_name,
                                                           "code": "compare_mismatch",
                                                           "result": "fail",
                                                           "detail": _amount_info.get("detail") or ""}})
                            continue
                        if _amount_info.get("amount") is not None \
                                and _sub2.get("amount") in (None, ""):
                            _sub2["amount"] = _amount_info["amount"]
                        if _amount_info.get("values") \
                                and _tool_name == "money_sum" \
                                and not _sub2.get("values"):
                            _sub2["values"] = list(_amount_info["values"])
                        if not _sub2.get("currency") and _amount_info.get("currency"):
                            _sub2["currency"] = _amount_info["currency"]
                        if _sub2.get("tax_included") is None \
                                and _amount_info.get("tax_status"):
                            _sub2["tax_included"] = (
                                _amount_info["tax_status"] == "included")
                        if _amount_info.get("occurrences"):
                            _src.append(_amount_trace)
                    if _tool_name == "date_diff":
                        if not _sub2.get("start") and _sub2.get("start_label"):
                            _x = _tools.extract_labeled_date(
                                _sub_text, _sub2.get("start_label") or "")
                            if _x.get("ok"):
                                _sub2["start"] = _x["value"]; _src.append(_x.get("trace"))
                        if not _sub2.get("end") and _sub2.get("end_label"):
                            _x = _tools.extract_labeled_date(
                                _sub_text, _sub2.get("end_label") or "")
                            if _x.get("ok"):
                                _sub2["end"] = _x["value"]; _src.append(_x.get("trace"))
                    _tr = _tools.run(_sub2)
                    _st = _tr.get("status") or "failed"
                    st = {"pass": "pass", "fail": "fail", "insufficient": "insufficient",
                          "failed": "failed"}.get(_st, "unknown")
                    detail = _tr.get("reason") or (f"{_tr.get('days')}天" if "days" in _tr else "")
                    quote = ""
                    _trace = {**_tr.get("trace", {}),
                              "decision_tables": _dmn_all.get("results") or [],
                              "executor": "tool", "code": _tr.get("code"),
                              "result": st,
                              "aggregation": _agg_eff,
                              "value": _tr.get("value", _tr.get("days", _tr.get("total", _tr.get("diff")))),
                              "date_sources": _src}
                    if _amount_trace:
                        _trace["amount_sources"] = _amount_trace
                    if _tx.get("trace"):
                        _trace["tax_sources"] = _tx["trace"]
                elif sub.get("criterion") and not sub.get("metric"):
                    # L42 ③：criterion 有值但无 metric 的结构化关系算子（含 date 日期链）
                    # 先走确定性执行；不能落入下面的语义分支（0-LLM 下 agent-judge 不可用，
                    # 会把「文档在、规则在、判据可算」的 date 规则整批放弃成 unknown/insufficient）。
                    if _fix3_on("date_det"):
                        _v3_det = _v3_structured_det_result(
                            sub, _sub_text, _item_onto_aliases(item))
                        if _v3_det is not None:
                            _v3_det["id"] = sid
                            if _sub_sheet:
                                _v3_det["tool_trace"]["sheet"] = _sub_sheet
                            sub_out.append(_v3_det)
                            continue
                    # T-170 ①：领域型判据（E3 蒜泥 / E4 鸡胸肉清洗）物料前提缺失 → 不适用，
                    # 不把「文档没有鸡胸肉」误判成肉类前处理不完整（clean-control 实测误报）。
                    _det_domain = _deterministic_domain_result(r, _sub_text)
                    if _det_domain is not None:
                        sub_out.append({"id": sid, "status": _det_domain["status"],
                                        "raw_state": _det_domain.get("raw_state") or "",
                                        "raw_item": {},
                                        "detail": _det_domain.get("detail") or "",
                                        "quote": _det_domain.get("quote") or "",
                                        "evidence_ok": True,
                                        "tool_trace": {
                                            "executor": "ruleexec.domain",
                                            "result": _det_domain["status"],
                                            "applicability":
                                                _det_domain.get("applicability") or "",
                                            "detail": _det_domain.get("detail") or ""}})
                        continue
                    # T-170 ①：前提缺失型判据（如 B-4「有半成品清单」）在前提不成立时判
                    # 不适用，不把「没有半成品清单」误判成投料量/总重不匹配（平台误报）。
                    _det_app = _deterministic_applicability_result(r, _sub_text)
                    if _det_app is not None:
                        st = _det_app["status"]
                        detail = _det_app.get("detail") or ""
                        sub_out.append({"id": sid, "status": st,
                                        "raw_state": _det_app.get("raw_state") or "",
                                        "raw_item": {}, "detail": detail, "quote": "",
                                        "evidence_ok": True,
                                        "tool_trace": {"executor": "ruleexec.applicability",
                                                       "result": st,
                                                       "applicability":
                                                           _det_app.get("applicability") or "",
                                                       "detail": detail}})
                        continue
                    # T-170：版本号/签名占位符（RW20260525002）确定性执行：模型能发现 X
                    # 但引文常不逐字（签名在表头值行）→ 引文不可核验降 insufficient → 门禁阻断。
                    _det_ph = _deterministic_placeholder_result(r, _sub_text)
                    if _det_ph is not None:
                        st = _det_ph["status"]
                        detail = _det_ph.get("detail") or ""
                        _viol = _det_ph.get("violations") or []
                        _rows = ([{"quote": q} for q in _viol]
                                 if st == "fail" and len(_viol) > 1
                                 else [{"quote": _det_ph.get("quote") or ""}])
                        for _pi, _prow in enumerate(_rows):
                            _sid_out = f"{sid}-P{_pi + 1}" if len(_rows) > 1 else sid
                            _quote_p = str(_prow.get("quote") or "")
                            sub_out.append({"id": _sid_out, "status": st,
                                            "raw_state": _det_ph.get("raw_state") or "",
                                            "raw_item": {}, "detail": detail,
                                            "quote": _quote_p, "evidence_ok": True,
                                            "tool_trace": {"executor": "ruleexec.placeholder",
                                                           "result": st,
                                                           "violations": len(_rows),
                                                           "detail": detail,
                                                           "quote": _quote_p}})
                        continue
                    # T-170：跨 Sheet 一致性规则（版本号/实施日期/商品名）确定性执行：
                    # 日期不一致只归因到「实施日期一致」，不再被模型重复算到「工单号/版本号一致性」。
                    _det_cons = _deterministic_consistency_result(r, _sub_text)
                    if _det_cons is not None:
                        st = _det_cons["status"]
                        detail = _det_cons.get("detail") or ""
                        quote = _det_cons.get("quote") or ""
                        sub_out.append({"id": sid, "status": st,
                                        "raw_state": _det_cons.get("raw_state") or "",
                                        "raw_item": {}, "detail": detail, "quote": quote,
                                        "evidence_ok": True,
                                        "tool_trace": {"executor": "ruleexec.consistency",
                                                       "result": st,
                                                       "values": _det_cons.get("values") or [],
                                                       "detail": detail, "quote": quote}})
                        continue
                    # L44：编号/字符串跨位置一致性（字段锚点对）确定性执行。criterion 有值、
                    # 无 metric 的形态（规则以 slots.consistency={left,right} 声明）在 D4 语义
                    # 分支前接管；判不了（非一致性规则/开关=0/异常）返回 None 保持原语义分支。
                    _det_ct = _deterministic_consistency_text_result(sub, _sub_text)
                    if _det_ct is not None:
                        st = _det_ct["status"]
                        detail = _det_ct.get("detail") or ""
                        _q_ct = _det_ct.get("quote") or ""
                        sub_out.append({"id": sid, "status": st,
                                        "raw_state": _det_ct.get("raw_state") or "",
                                        "raw_item": {}, "detail": detail,
                                        "quote": _q_ct, "evidence_ok": True,
                                        "tool_trace": {
                                            "executor": "ruleexec.consistency_text",
                                            "result": st,
                                            "state": _det_ct.get("raw_state") or "",
                                            "code": _det_ct.get("code") or "",
                                            "values": _det_ct.get("values") or [],
                                            "detail": detail, "quote": _q_ct}})
                        continue
                    # T-170 ②：内置食品限值规则有平台确定性判据（ruleexec.FOOD_LIMIT_SPECS），
                    # D4 必须用确定性执行器做数值比较，不能把「250ppm ≥ 200ppm」这类比较
                    # 交给 agent-judge（历史误报：模型把高于下限判成"不符"）。
                    _det_lim = _deterministic_limit_result(r, _sub_text)
                    if _det_lim is not None:
                        st = _det_lim["status"]
                        detail = _det_lim.get("detail") or ""
                        _raw = _det_lim.get("raw_state") or ""
                        _raw_item = {}
                        # 同规则多处违规：逐条落子要求（id 加 #n），finding 物化时保留多个证据锚点，
                        # 避免「两处消毒浓度都越界」只报第一处导致第二处证据丢失。
                        _violations = _det_lim.get("violations") or []
                        _rows = ([{"quote": q} for q in _violations]
                                 if st == "fail" and len(_violations) > 1
                                 else [{"quote": _det_lim.get("quote") or ""}])
                        for _vi, _vrow in enumerate(_rows):
                            # 每条违规一个独立子要求 id（不能只用 "#n"：finding 物化按 base id
                            # 分组合并后，证据门禁会拿 S1#1 的子要求引文集校验全部锚点 →
                            # 第二条违规引文被判“子要求串位”而整条 finding 降级）。
                            _sid_out = f"{sid}-V{_vi + 1}" if len(_rows) > 1 else sid
                            _quote_v = str(_vrow.get("quote") or "")
                            _trace = {"executor": "ruleexec.limit",
                                      "template": "food_limit",
                                      "result": st,
                                      "state": _raw,
                                      "quote": _quote_v,
                                      "detail": detail,
                                      "violation_index": _vi + 1 if len(_rows) > 1 else 0,
                                      "violations": len(_rows),
                                      "values": _det_lim.get("values") or [],
                                      "spec": _det_lim.get("spec") or {},
                                      "applicability": _det_lim.get("applicability") or ""}
                            sub_out.append({"id": _sid_out, "status": st,
                                            "raw_state": _raw, "raw_item": {},
                                            "detail": detail, "quote": _quote_v,
                                            "evidence_ok": True,
                                            "tool_trace": _trace})
                        continue
                    with _hk_prov.provenance_scope(_d4_prov):
                        se = _semantic_eval(r, sub, _sub_text, path,
                                            batch_cache=_batch_cache)
                    # D5 na 复核：不适用不得静默生效。规则包缺证处理声明"业务触发成立后缺材料
                    # 不能判不适用"时，带证据口径复核一次；只有复核给出 fail 才替换结论（不伪造）。
                    if str(se.get("status")) == "not_applicable" and _na_recheck_enabled(sub):
                        _se2 = _semantic_eval(r, sub, _sub_text, path,
                                              extra_hint=_NA_RECHECK_HINT)
                        _nr = {"attempted": True, "first": "not_applicable",
                               "second": str(_se2.get("status") or ""),
                               "accepted": str(_se2.get("status")) == "fail",
                               "source": "manifest_exec.na_recheck"}
                        if str(_se2.get("status")) == "fail":
                            se = dict(_se2)
                        se = {**se, "na_recheck": _nr}
                    elif str(se.get("status")) == "insufficient":
                        # D4 insufficient 复核（开关默认关；2026-11-22）：
                        # 「证据载体缺失≠结论」的同一口径扩到弃权项；只有复核 fail 才替换。
                        se = _maybe_recheck_insufficient(se, r, sub, _sub_text, path)
                    st, detail, quote = se.get("status") or "needs_model", se.get("detail") or "", se.get("quote") or ""
                    _raw = se.get("raw_state") or ""
                    _raw_item = se.get("raw_item") or {}
                    _trace = {"executor": "agent-judge", "decision_tables": _dmn_all.get("results") or [], "raw_state": _raw,
                              "quote": quote, "status": st}
                    if se.get("na_recheck"):
                        _trace["na_recheck"] = se["na_recheck"]
                    if se.get("na_recheck_insufficient"):
                        _trace["na_recheck_insufficient"] = se["na_recheck_insufficient"]
                else:
                    # 关键字/表达式型规则（require/forbid/require_any/all_of 等）走 ruleexec，
                    # 不能因缺 metric 被当成“未提取到指标数值”而永不执行（业务有效性 task-22 反馈）。
                    _kw_mode = (not str(sub.get("metric") or "")) and any(
                        (isinstance(sub, dict) and k in sub)
                        or (isinstance(slots, dict) and k in slots)
                        for k in ("require", "forbid", "forbidden", "require_any",
                                  "all_of", "any_of", "not", "_template"))
                    if _kw_mode:
                        try:
                            with _hk_prov.provenance_scope(_d4_prov):
                                _kw = _frozen_judge_rule(sub or slots, _sub_text,
                                                         _item_onto_aliases(item))
                        except Exception as _kw_e:  # noqa: BLE001
                            _kw = {"state": "执行失败",
                                   "detail": f"{type(_kw_e).__name__}: {_kw_e}"}
                        _kw_st = str((_kw or {}).get("state") or "unknown")
                        st = {"满足": "pass", "不满足": "fail",
                              "证据不足": "insufficient",
                              "不适用": "not_applicable"}.get(_kw_st, "unknown")
                        detail = str((_kw or {}).get("detail") or "")
                        quote = str((_kw or {}).get("quote") or "")
                        _raw = _kw_st
                        _trace = {"executor": "ruleexec", "template": "keyword",
                                  "state": _kw_st, "result": st,
                                  "quote": quote, "detail": detail}
                        if _sub_sheet:
                            _trace["sheet"] = _sub_sheet
                        sub_out.append({"id": sid, "status": st,
                                        "raw_state": ("keyword_missing"
                                                      if st == "fail" and not quote else ""),
                                        "raw_item": {}, "detail": detail,
                                        "quote": quote, "evidence_ok": True,
                                        "tool_trace": _trace})
                        continue
                    # 同指标多行/多批：逐行判定，不能只取第一行
                    _occs = _frozen_all_from_text(
                        str(sub.get("metric") or ""), _sub_text,
                        _item_onto_aliases(item))
                    _agg = str(sub.get("aggregation")
                               or (item.get("execution_hints") or {}).get("aggregation")
                               or "all")
                    # L44 consistency 文本算子：按字段锚点整体判定（算子内部自行处理多实例/
                    # 逐行配对），不能走下面的「同指标逐行多实例」路径（分册索引会被
                    # _from_text 当成数字取数、单行只有一侧锚点 → 逐行判定必缺侧）。
                    try:
                        _is_ct_rule = ruleexec._is_consistency_text_rule(sub)
                    except Exception:  # 铁律 2：识别异常按非一致性处理，留痕
                        logging.getLogger(__name__).warning(
                            "consistency text rule detect failed", exc_info=True)
                        _is_ct_rule = False
                    if _is_ct_rule:
                        _det_ct = _deterministic_consistency_text_result(sub, _sub_text)
                        if _det_ct is not None:
                            st = _det_ct["status"]
                            detail = _det_ct.get("detail") or ""
                            quote = _det_ct.get("quote") or ""
                            _trace = {"executor": "ruleexec.consistency_text",
                                      "result": st,
                                      "state": _det_ct.get("raw_state") or "",
                                      "code": _det_ct.get("code") or "",
                                      "values": _det_ct.get("values") or [],
                                      "detail": detail, "quote": quote}
                            sub_out.append({"id": sid, "status": st,
                                            "raw_state": _det_ct.get("raw_state") or "",
                                            "raw_item": {}, "detail": detail,
                                            "quote": quote, "evidence_ok": True,
                                            "tool_trace": _trace})
                            continue
                    if _agg in ("sum", "compare"):
                        _agg_bad = _aggregation_bad_lines(
                            str(sub.get("metric") or ""), _sub_text, _occs)
                        _agg_out = _judge_aggregation(
                            sub, _occs, _agg_bad, _agg, _sub_text, _d4_parsed,
                            _sheet, _sub_sheet or _rule_sheet)
                        if _agg_out is not None:
                            _agg_out["id"] = sid
                            if _sub_sheet:
                                _agg_out["tool_trace"]["sheet"] = _sub_sheet
                            if _rule_sheet:
                                _agg_out["tool_trace"]["sheet_limit"] = _rule_sheet
                            sub_out.append(_agg_out)
                            continue
                    if len(_occs) > 1 and _agg != "single":
                        _multi = []
                        for _oi, _occ in enumerate(_occs):
                            _line = str(_occ.get("line") or "")
                            with _hk_prov.provenance_scope(_d4_prov):
                                _jr = _frozen_judge_rule(sub, _line,
                                                         _item_onto_aliases(item))
                            _st0 = str(_jr.get("state") or "unknown")
                            _st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
                                   "不适用": "not_applicable"}.get(_st0, "unknown")
                            _det = _jr.get("detail") or ""
                            _q = _jr.get("quote") or _occ.get("quote") or ""
                            # L42 ④ 非白名单码逐行实例物化（按 L19 独立实例口径）：
                            # 多行 fail 若引文只截到「复核1」这类短片段，归一引文互相包含会被
                            # 上层实例判据当成同一实例（只物化 1 条 finding）。=1 时把逐行实例
                            # 引文扩到「该行原文」紧切片（仍逐字）：行位置不同 → 互不包含 +
                            # span 不重叠 → L19 实例身份成立，逐实例各落一条 finding。
                            _v3_line_q = _v3_instance_quote(code, _st, _line, _sub_text, _q)
                            _v3_expanded = False
                            if _v3_line_q and len(_v3_line_q) >= len(_q):
                                _q = _v3_line_q
                                _v3_expanded = True
                            _multi.append({"id": f"{sid}#{_oi+1}", "status": _st,
                                           "raw_state": "", "raw_item": {},
                                           "detail": f"第{_oi+1}行：{_det}", "quote": _q,
                                           "evidence_ok": True,
                                           "tool_trace": {"executor": "ruleexec",
                                                          "occurrence": _oi + 1,
                                                          "occurrences": len(_occs),
                                                          "aggregation": _agg,
                                                          "extracted": _occ.get("value"),
                                                          "normalized": _occ.get("value"),
                                                          "input": {"metric": sub.get("metric"),
                                                                    "operator": sub.get("op") or sub.get("operator"),
                                                                    "threshold": sub.get("value", sub.get("threshold")),
                                                                    "unit": sub.get("unit") or ""},
                                                          "result": _st,
                                                          "detail": _det, "quote": _q,
                                                          **({"instance_quote_expanded": True}
                                                             if _v3_expanded else {}),
                                                          "code": "ok" if _st in ("pass", "fail") else "evidence_insufficient"}})
                        if _sub_sheet:
                            for _x in _multi:
                                _x["tool_trace"]["sheet"] = _sub_sheet
                        sub_out.extend(_multi)
                        continue
                    try:
                        _raw_val, _raw_quote = _frozen_from_text(
                            str(sub.get("metric") or ""), _sub_text,
                            _item_onto_aliases(item))
                        _trace = {"executor": "ruleexec",
                                  "raw": _raw_quote or "",
                                  "extracted": _raw_val,
                                  "normalized": _raw_val,
                                  "input": {"metric": sub.get("metric"), "operator": sub.get("op") or sub.get("operator"),
                                            "threshold": sub.get("value", sub.get("threshold")),
                                            "unit": sub.get("unit") or ""},
                                  "code": "ok"}
                        if _raw_val is None:
                            # L44 consistency 文本算子：编号/字符串不是「数值+单位」，数值取数
                            # 为空时按字段锚点做跨位置一致性判定（一致 pass / 不一致 fail /
                            # 缺侧 insufficient）；非一致性规则/开关=0 → 保持旧「证据不足」路径。
                            _det_ct = _deterministic_consistency_text_result(sub, _sub_text)
                            if _det_ct is not None:
                                st = _det_ct["status"]
                                detail = _det_ct.get("detail") or ""
                                quote = _det_ct.get("quote") or ""
                                _trace.update({
                                    "executor": "ruleexec.consistency_text",
                                    "code": _det_ct.get("code") or "ok",
                                    "result": st,
                                    "detail": detail, "quote": quote,
                                    "normalized": _det_ct.get("values") or [],
                                    "extracted": _det_ct.get("values") or []})
                            else:
                                st, detail, quote = "insufficient", "未提取到指标数值", ""
                                _trace.update({"code": "missing_value", "result": st, "detail": detail, "quote": quote})
                        else:
                            _um = re.search(r"([A-Za-zμµ]+(?:/[0-9A-Za-zμµ]+)?)\s*$", _raw_quote or "")
                            _raw_unit = _um.group(1) if _um else ""
                            _want_unit = str(sub.get("unit") or "")
                            if _raw_unit and _raw_unit not in ruleexec._UNIT_SCALE and not ruleexec._unit_dim(_raw_unit):
                                _trace["code"] = "unit_unknown"
                            elif _raw_unit and _want_unit and ruleexec._unit_dim(_raw_unit) and ruleexec._unit_dim(_want_unit) and ruleexec._unit_dim(_raw_unit) != ruleexec._unit_dim(_want_unit):
                                _trace["code"] = "unit_mismatch"
                            with _hk_prov.provenance_scope(_d4_prov):
                                jr = _frozen_judge_rule(sub, _sub_text,
                                                        _item_onto_aliases(item))
                            st0 = str(jr.get("state") or "unknown")
                            st = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
                                  "不适用": "not_applicable"}.get(st0, "unknown")
                            detail, quote = jr.get("detail") or "", jr.get("quote") or ""
                            if st == "insufficient" and _trace.get("code") == "ok":
                                _trace["code"] = "evidence_insufficient"
                            _trace.update({"result": st, "detail": detail, "quote": quote})
                    except Exception as e:
                        st, detail, quote = "failed", f"{type(e).__name__}: {e}", ""
                        _trace = {"executor": "ruleexec", "result": "failed", "code": "tool_error",
                                  "error": str(e)[:200]}
                if _sub_sheet and isinstance(_trace, dict):
                    _trace["sheet"] = _sub_sheet
                sub_out.append({"id": sid, "status": st, "raw_state": locals().get("_raw", ""),
                                "raw_item": locals().get("_raw_item", {}),
                                "detail": detail, "quote": quote, "evidence_ok": True,
                                **({"tax_sources": _tx.get("trace")}
                                   if (_tx.get("trace") or {}).get("requested") else {}),
                                **({"amount_sources": _amount_trace}
                                   if _amount_trace else {}),
                                "tool_trace": _trace})
            # 同码多实例（开关默认关；关时 sub_out 原样）：为白名单码追加独立违规实例子要求，
            # 每个实例一条 fail 子要求 → project 层物化为独立 finding。必须在证据门禁之前，
            # 新增实例同样要过引文门禁（fail-closed）。
            if multi_instance_enabled():
                sub_out = _apply_multi_instance_subs(item, _d4_text, sub_out,
                                                     case_id=case_id, code=code)
                # 语义码同码多实例（RULEPROOF_SEMANTIC_MULTI_INSTANCE，默认 0；关时原样返回）：
                # 对已判 fail 的语义码做**实例抽取二次调用**，追加 S1#MI* fail 子要求。
                # 新增子要求同样要过下方的 _apply_fail_quote_gate（引文门禁 fail-closed）。
                sub_out = _apply_semantic_multi_instance_subs(
                    item, r, sub, _d4_text, sub_out, case_id=case_id, code=code)
            # P0-证据：fail 子要求引文必须逐字命中归属对象原文/目标单元格，否则降级转人工。
            try:
                _quote_gate = _apply_fail_quote_gate(
                    sub_out, item=item, text=text, parsed=parsed, path=path, doc=doc,
                    rule_sheet=_rule_sheet, docs_by_id=_docs_by_id,
                    parse_cache=_parse_cache, sheet_cache=_sheet_cache)
            except Exception:
                # 2026-11-20（gpt-5.2 评审 P0-4）：证据门禁异常此前 fail-open（只 warning，
                # 全部 fail 子要求原样通过 → 可能放过无引文支撑的 critical）。
                # 改为 fail-closed：所有 fail 子要求降级 insufficient（转人工），并标记 error。
                logging.getLogger(__name__).warning(
                    "fail quote gate error → fail-closed 降级", exc_info=True)
                _dq = 0
                for _s in (sub_out or []):
                    if str((_s or {}).get("status") or "") == "fail":
                        _prev = dict(_s)
                        _s["status"] = "insufficient"
                        _s["downgraded_from"] = "fail"
                        _s["downgrade_reason"] = "evidence_gate_error_fail_closed"
                        _s["evidence_gate"] = {"passed": False,
                                               "reason": "evidence_gate_error",
                                               "previous_status": _prev.get("status")}
                        _dq += 1
                _quote_gate = {"checked": _dq, "passed": 0, "blocked": _dq,
                               "blocked_subs": [], "error": True,
                               "policy": "fail_closed"}
            d4 = {"status": "mixed", "subs": sub_out,
                  "detail": f"{len(sub_out)} 个子要求"}
            if _quote_gate.get("checked"):
                d4["evidence_gate"] = _quote_gate
            if _dmn_skipped and _is_dmn_carrier:
                d4 = {"status": "skipped", "subs": sub_out,
                      "detail": "决策表作用域不适用（skipped），不参与通过判定",
                      "reason": "decision_table_scope_skipped",
                      "tool_trace": {"executor": "decision_table",
                                     "state": "skipped",
                                     "results": _dmn_results}}
                if _sheet_limit.get("requested"):
                    d4["sheet_limit"] = _sheet_limit
            if _sheet_limit.get("requested"):
                d4["sheet_limit"] = _sheet_limit
                d4["sheet"] = _rule_sheet
                d4["text_chars"] = len(_d4_text)
                if _rule_sheet:
                    d4["detail"] += f"（仅按 sheet {_rule_sheet} 的文本判定）"
        if item.get("ontology_binding"):
            _mt = str((subs or [{}])[0].get("metric") or slots.get("metric") or "")
            d4["ontology"] = _item_onto_trace(item, _mt, text)
        # D4 适用性归因：D1 冻结快照里的 applicable_when / scope.tags 命中情况
        if d1.get("applicable_when") or d1.get("scope_tags"):
            _aw_trace = d1.get("applicable_when") or {}
            _tag_trace = d1.get("scope_tags") or {}
            d4["applicability"] = {
                "source": "manifest_freeze",
                "applicable": d1.get("status") == "applicable",
                "d1_status": d1.get("status"),
                "d1_reason": d1.get("reason") or "",
                "applicable_when_declared": _aw_trace.get("declared") or [],
                "applicable_when_matched": _aw_trace.get("matched") or [],
                "scope_tags_declared": _tag_trace.get("declared") or [],
                "scope_tags_matched": _tag_trace.get("matched") or [],
            }
        # A9（2026-11-21）：D1 适用性未验证（冻结路由 haystack 为空）→ 该 item 的 fail
        # 上限为 insufficient：适用性证明不了时不得把“违反”当确定 fail 出闸。
        if d1.get("scope_unverified"):
            _su_capped = 0
            for _su in (d4.get("subs") or []):
                if str((_su or {}).get("status") or "") == "fail":
                    _su_prev = dict(_su)
                    _su["status"] = "insufficient"
                    _su["downgraded_from"] = "fail"
                    _su["downgrade_reason"] = "scope_unverified_fail_capped"
                    _su["scope_unverified"] = True
                    _su["scope_unverified_previous_status"] = _su_prev.get("status")
                    _su_capped += 1
            _su_d4_fail = str(d4.get("status") or "") in ("fail", "mixed")
            if _su_d4_fail:
                # D4 fail 上限 = insufficient：mixed 也降为 insufficient（不得以 mixed
                # 携带 fail 子项出闸；子项已在上方逐个降级）。
                d4["status"] = "insufficient"
            d4["scope_unverified"] = True
            d4["scope_cap"] = "fail_capped_insufficient"
            if _su_capped or _su_d4_fail:
                d4["detail"] = (str(d4.get("detail") or "") +
                                "（适用性未验证：失败结论上限 insufficient）")
        # D1 结构适用性（开关制，2026-11-22）：applicable_when 字面锚未命中但规则对象
        # 在文档中确实存在 → D4 的 not_applicable 不得生效，降为 insufficient 并带
        # 「锚点未命中」原因；开关关闭/未标记时本调用原样返回（逐字段一致）。
        d4 = _apply_d1_anchor_cap(d1, d4)
        # D5 用真实子项状态汇总；D1 不适用必须是 na，不能把 skipped 当 pass
        if d4.get("status") == "skipped":
            d5 = {"status": "na", "reason": "不适用的规则不参与通过判定",
                  "failed": [], "incomplete": []}
        elif d4.get("subs"):
            d5 = combine([x.get("status") for x in d4["subs"]], item.get("combination") or "all")
        else:
            d5 = combine([d4.get("status")], item.get("combination") or "all")
        d5["combination"] = item.get("combination") or "all"
        _fallback = str((item.get("execution_hints") or {}).get("fallback") or "abstain")
        # T-136 TL-1（P0 契约）：fail 必须分两类，不得把“证据不足/解析缺口”
        # 改写成“不满足”：
        #   * fail_by_violation：子要求真实判定为违反（有 fail 依据）→ 保持 fail；
        #   * fail_by_absence  ：缺口/缺失/不可判定（insufficient/unknown/needs_model）
        #                        → 保持 insufficient + 明确原因，转人工补证/复核。
        # 口径与复审路径 review.py 一致（复审同样不套用 fallback=fail）。
        if d5.get("status") in ("insufficient", "unknown", "needs_model"):
            if _fallback == "fail":
                _d5_reason = str(d5.get("reason") or "")
                d5 = {**d5, "fallback": "fail", "fallback_applied": False,
                      "fail_kind": "fail_by_absence",
                      "reason": ((_d5_reason + "；") if _d5_reason else "") +
                                "证据不足/解析缺口不得改写为不满足"
                                "（fail_by_absence：保留 insufficient，转人工补证/复核）"}
            elif _fallback == "ask":
                d5["fallback"] = "ask"; d5["fallback_applied"] = True
                d5["reason"] = (d5.get("reason") or "") + "；要求补证"
            else:
                d5["fallback"] = _fallback
        else:
            d5["fallback"] = _fallback
            if d5.get("status") == "fail":
                # 真实违规：D5=fail 由子要求 fail 汇总而来（无 fail 子项时 combine 不会给 fail）。
                d5["fail_kind"] = "fail_by_violation"
                d5["fallback_applied"] = False
        # 误报负例卡：只抑制同一规则、同一原文引文的重复出现；不是整条规则静默关闭。
        try:
            _marks = [str(x).strip() for x in ((slots or {}).get("false_positive_quotes") or []) if str(x).strip()]
            _quotes = [str((x or {}).get("quote") or "").strip() for x in (d4.get("subs") or [])]
            _hit = next((q for q in _quotes if q and any(q in m or m in q for m in _marks)), "")
            if _hit:
                d5 = {**d5, "status": "insufficient", "suppressed_by_feedback": True,
                      "reason": "该引文已被人工判为误报，按负例卡抑制；不重新落 finding",
                      "negative_quote": _hit[:200]}
        except Exception:
            logging.getLogger(__name__).debug("feedback suppression skipped", exc_info=True)
        # JEV：真实校准样本连续误报的规则，D5 弃权转人工；
        # 无样本/样本不足不弃权（保持原结论），只记录校准来源与阈值，供审计追溯。
        # T-115：空间显式关闭 mod_jev 时主链不执行该校准门禁，只记录 skipped 供追溯。
        if _module_off("mod_jev", str((_case_row or {}).get("workspace_id") or "")):
            d5["jev"] = {"abstain": False, "skipped": "mod_jev_disabled",
                         "source": "calibration.rule_gate"}
        else:
            try:
                from . import calibration as _cal_jev
                _jg = dict(_cal_jev.rule_gate(code) or {})
                _jg["source"] = "calibration.rule_gate"
                _jg["abstain_path"] = "d5_insufficient_to_manual"
                try:
                    _jg["calibration_hash"] = _cal_jev.contract_hash()
                except Exception:
                    _jg["calibration_hash"] = ""
                if _jg.get("abstain"):
                    d5 = {**d5, "status": "insufficient", "abstained_by": "jev",
                          "reason": f"JEV 规则校准准确率 {_jg.get('accuracy')} < {_jg.get('target')}，转人工",
                          "jev": _jg}
                else:
                    d5["jev"] = _jg
            except Exception:
                logging.getLogger(__name__).debug("JEV D5 gate skipped", exc_info=True)
        # L78（2026-11-24）：多实例 cap 截断可观测统一进 D5（point_state/run 返回/导出同源）。
        # 开关=0 或非多实例规则 → d5 逐字段不变（旧口径）。
        try:
            _mi_stats_d5 = item.pop("_mi_stats", None) if isinstance(item, dict) else None
            if isinstance(_mi_stats_d5, dict):
                d5["multi_instance"] = _mi_stats_d5
        except Exception:  # 铁律 2：挂载失败留痕，不改变判定
            logging.getLogger(__name__).warning(
                "D5 multi_instance stats attach skipped（不阻断主链）", exc_info=True)
        conclusion = {"pass": "满足", "fail": "不满足", "na": "不适用", "not_applicable": "不适用",
                      "insufficient": "证据不足", "needs_model": "无法判断",
                      "skipped": "不适用", "blocked": "执行失败", "failed": "执行失败",
                      "mixed": "见子要求", "unknown": "无法判断"}.get(d5.get("status"), "无法判断")
        # V03：verdict 与 completeness 分离——业务结论 pass/fail 不等于执行完整。
        # all(fail, execution_failed)/all(fail, insufficient) 仍是 fail，但 execution=incomplete。
        execution = d5_execution_state(d5)
        # A1：越界对象在落库/激活**之前**丢弃（先过滤再落库，manifest_result /
        # manifest_active 不留越界判定；所有 run 入口同受冻结边界约束）。
        if _a1_binding_by_rid is not None:
            _a1_bind = _a1_binding_by_rid.get(str(item.get("rule_id") or ""))
            if _a1_bind is None:
                _a1_bind = _a1_binding_by_rid.get("code:" + str(code or ""))
            _a1_allowed = {str(x) for x in (_a1_bind or {}).get("allowed_object_ids") or []}
            if _a1_allowed and _item_obj not in _a1_allowed:
                _a1_dropped.append({"rule_id": item.get("rule_id"), "rule": code,
                                    "object_id": _item_obj})
                continue
        _result_id = _save(mid, item, d1, d2, d3, d4, d5, conclusion, execution)
        # LaneP（2026-11-23）：在 _save 之后把逐点位五态落 point_state（纯落库；
        # 开关 RULEPROOF_D5_POINT_LOG 默认 1，=0 回旧行为；写失败只 warning 不阻断）。
        log_d5_point_state(case_id=case_id, mid=mid, batch=_d5_point_batch,
                           item=item, path=path, d4=d4, d5=d5)
        # L80 / P0-C：收集逐实例裁决来源行（纯读 d1–d5 + tool_trace，不写判定）。
        # 顺序在 _save 之后：证据门禁已在 d4.subs[].evidence_gate 定稿，
        # evidence_status/quote_sha256 与 finding 同源（不落原文）。
        if _adj_on:
            try:
                _adj_rows.extend(adjudication_ledger.rows_for_item(
                    run_id=_adj_run_id, case_id=case_id,
                    tenant_id=str((_case_row or {}).get("tenant_id") or ""),
                    workspace_id=str((_case_row or {}).get("workspace_id") or ""),
                    manifest_id=mid, item=item, d1=d1, d2=d2, d3=d3, d4=d4, d5=d5,
                    doc_type=str((doc or {}).get("doc_type") or ""), path=path))
            except Exception:  # 铁律 2：行构造失败只 warning，绝不阻断审核
                logging.getLogger(__name__).warning(
                    "adjudication_ledger row build skipped manifest=%s code=%s",
                    mid, code, exc_info=True)
        _eg = d4.get("evidence_gate") if isinstance(d4, dict) else None
        if _eg:
            _evidence_gate_total["checked"] += int(_eg.get("checked") or 0)
            _evidence_gate_total["passed"] += int(_eg.get("passed") or 0)
            _evidence_gate_total["blocked"] += int(_eg.get("blocked") or 0)
            for _bs in (_eg.get("blocked_subs") or []):
                _evidence_gate_total["blocked_subs"].append(
                    {**_bs, "rule_code": code, "object_id": _item_obj})
        try:
            _materialize_collect_findings(case_id, item, _result_id, d4)
        except Exception:
            logging.getLogger(__name__).debug("collect finding materialization skipped", exc_info=True)
        if d5.get("fallback") == "ask" and execution != "completed" and d5.get("status") in ("insufficient", "unknown"):
            try:
                _cl = []
                for _s in (d3.get("missing_scopes") or []):
                    _cl.append({"label": f"可定位到 {_s} 的证据", "reason": "当前文档没有该范围"})
                if required:
                    _cl.append({"label": f"补充证据：{required}", "reason": "required_evidence"})
                for _sub in (d4.get("subs") or []):
                    if _sub.get("status") == "insufficient":
                        _cl.append({"label": (_sub.get("missing_evidence") or _sub.get("detail") or "补充子要求证据"),
                                    "reason": f"子要求 {_sub.get('id') or ''}"})
                request_evidence(_result_id, d5.get("reason") or "证据不足，fallback=ask",
                                 reviewer="system", role="super_admin", checklist=_cl)
            except Exception:
                logging.getLogger(__name__).debug("auto evidence request skipped", exc_info=True)
        _activate(mid, item, _result_id)
        # L72 P2b（2026-11-24）：D5 裁决后、`_save`/`_activate` 与 collect 物化之后签发证书。
        # 只读 finding/证据（L71 回填的 verbatim_quote/char span），只写 finding_certificate，
        # 不改 state/title/summary/severity → 判定语义零变化；KERNEL=0（默认）不签发、零开销。
        try:
            from . import certificate_service as _cert_svc
            if _cert_svc.kernel_enabled():
                _cert_svc.issue_for_result(_result_id, case_id=case_id)
        except Exception:  # 铁律 2：不静默；advisory lane 不阻断主链
            logging.getLogger(__name__).warning(
                "certificate issue hook failed result=%s", _result_id, exc_info=True)
        out.append({"result_id": _result_id, "object_id": item.get("object_id"), "rule": code,
                    "d1": d1, "d2": d2, "d3": d3, "d4": d4, "d5": d5,
                    "conclusion": conclusion, "execution": execution})
    _a1_scope_guard = {}
    if _a1_dropped:
        _a1_scope_guard = {
            "dropped": len(_a1_dropped),
            "objects": sorted({str(d.get("object_id") or "") for d in _a1_dropped}),
            "items": _a1_dropped,
            "boundary": "allowed_object_ids",
            "note": "输出侧守卫：越界对象在 _save/_activate 之前丢弃，不进入 finding/报告",
        }
        try:
            R.audit_logs.log(actor="system", action="manifest.scope_violation_dropped",
                             object=mid,
                             after=json.dumps(_a1_scope_guard, ensure_ascii=False,
                                              default=str))
        except Exception:
            logging.getLogger(__name__).debug("scope drop audit skipped", exc_info=True)
    # L80 / P0-C：run 末一次事务写台账 + 一条 adjudication.ledger.written 审计。
    # 失败不阻断（服务层已 try/except 并写 write_failed 审计）；=0 时本段整体不存在。
    if _adj_on and _adj_rows:
        try:
            _adj_out = adjudication_ledger.emit_run(
                _adj_rows, run_id=_adj_run_id, case_id=case_id, manifest_id=mid)
            logging.getLogger(__name__).info(
                "adjudication_ledger run=%s rows=%s written=%s ok=%s",
                _adj_run_id, len(_adj_rows), _adj_out.get("written"),
                _adj_out.get("ok"))
        except Exception:  # 铁律 2：不得静默；台账写失败不阻断审核主链
            logging.getLogger(__name__).warning(
                "adjudication_ledger emit skipped manifest=%s run=%s",
                mid, _adj_run_id, exc_info=True)
    if _evidence_gate_total["checked"]:
        try:
            R.audit_logs.log(
                actor="system", action="manifest.evidence_gate", object=mid,
                after=json.dumps({k: _evidence_gate_total[k]
                                  for k in ("checked", "passed", "blocked")},
                                 ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("evidence gate audit skipped", exc_info=True)
    # P0-3（2026-11-21）：本清单执行结束 = 「当前口径」的边界。manifest_active 是 case 级
    # 可变指针，必须把「本 manifest 里不存在」的上一轮 rule×object 指针摘除，否则报告/
    # 台账/门禁会 JOIN 到旧清单结果，同一份报告混两个冻结清单（五态数/finding/门禁不同源）。
    # 回退：RULEPROOF_ACTIVE_RUN_SCOPE=0（旧行为可复现）；失败只告警不掩盖执行结果。
    _active_scope_out = _expire_out_of_scope_active(case_id, mid, items)
    # P1-6：扩展版本快照 v2（delivery-ready 的 version_snapshot）在审核执行时落一次；
    # 只读调用其 build/save API，不改 version_snapshot.py / project.py。报告/门禁据此显示
    # 快照一致/差异（配置漂移不阻断已执行审核，但必须可审计）。
    _snapshot_out = {}
    try:
        if case_id and os.environ.get("RULEPROOF_VERSION_SNAPSHOT", "1") != "0":
            _cv = db.connect()
            try:
                _ar = _cv.execute(
                    "SELECT id FROM audit_run WHERE case_id=? "
                    "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
            finally:
                _cv.close()
            _run_id = str((_ar["id"] if _ar else "") or "")
            if _run_id:
                from . import version_snapshot as _vs
                from . import ctx as _ctxv
                _case_meta = R.cases.get(case_id) or {}
                _tid = _case_meta.get("tenant_id") or "t-default"
                _wid = _case_meta.get("workspace_id") or "ws-default"
                # L98 P1：完整状态快照/恢复。旧写法恢复 tenant/workspace/mode 时仍会
                # 丢掉 system/doc_type/case；restore() 六字段一起还原（含审核模式）。
                _saved_ctx = _ctxv.snapshot()
                _switched = (_saved_ctx.get("tenant_id") or "") != _tid or \
                            (_saved_ctx.get("workspace_id") or "") != _wid
                try:
                    if _switched:
                        _ctxv.set_context(_tid, _wid)
                    _snap_v2 = _vs.build(case_id, _run_id, tenant_id=_tid,
                                         workspace_id=_wid)
                finally:
                    if _switched:
                        try:
                            _ctxv.restore(_saved_ctx)
                        except Exception:
                            logging.getLogger(__name__).debug("ctx restore skipped", exc_info=True)
                _snapshot_out = _vs.save(case_id, _run_id, snap=_snap_v2,
                                         actor="system") or {}
    except Exception:
        logging.getLogger(__name__).debug("run snapshot v2 save skipped", exc_info=True)
    # L53：把策略快照摘要显式放进 manifest 执行返回体，让「执行 trace」可直接回答
    # “这次是确定性/语义/辅助模式、缺哪些判定开关、内容指纹是什么”，不必再回查 sys_config。
    _strategy_snapshot_out = {}
    if isinstance(_snapshot_out, dict) and _snapshot_out.get("snapshot_id"):
        _strategy_snapshot_out = {
            "snapshot_id": _snapshot_out.get("snapshot_id") or "",
            "schema_version": _snapshot_out.get("schema_version") or "",
            "engine_mode": _snapshot_out.get("engine_mode") or "",
            "parser_version": _snapshot_out.get("parser_version") or "",
            "switches_coverage": _snapshot_out.get("switches_coverage") or "",
            "missing_switches": list(_snapshot_out.get("missing_switches") or []),
            "content_fingerprint": _snapshot_out.get("content_fingerprint") or "",
        }
    _guard_out = _mguard if isinstance(_mguard, dict) else {}
    # F-04：历史无闭包清单在守卫阶段即显式阻断（不会执行到这里）；legacy 字段保留为
    # 诊断输出（正常执行态恒 False），不得与 integrity_verified 混淆。
    _legacy_manifest = bool((_mguard or {}).get("legacy"))
    # P0-B：把「本次执行是否完整性已验证」显式写进返回体（旧清单不得冒充已验证）。
    _integrity_out = {"fail_closed": 1 if _integrity_fc else 0,
                      "legacy": bool(_legacy_manifest),
                      "closure_unverifiable": bool(_closure_unverifiable),
                      "closure_error": str(_closure_error or "")}
    # L72 P2b：run 收口补签（按 manifest 幂等重签；覆盖 run 期间新增/并行的 fail finding）。
    # KERNEL=0（默认）零开销、零读表；异常只告警不阻断（REQUIRED 门禁在 report_gate 侧）。
    try:
        from . import certificate_service as _cert_svc_end
        if _cert_svc_end.kernel_enabled():
            _cert_out = _cert_svc_end.issue_for_manifest(case_id, mid)
            if _cert_out.get("issued"):
                logging.getLogger(__name__).info(
                    "certificate issued manifest=%s issued=%s pass=%s",
                    mid, _cert_out.get("issued"), _cert_out.get("pass"))
    except Exception:
        logging.getLogger(__name__).warning(
            "certificate run-close hook failed manifest=%s", mid, exc_info=True)
    # L78（2026-11-24）：多实例 cap 截断可观测汇总（run 返回；报告/导出/L67 口径同源）。
    # 开关=0 → 不新增 key（旧返回体逐字段不变）。
    _mi_summary = {"enabled": bool(multi_instance_enabled()),
                   "no_base_fail_fix": bool(mi_no_base_fail_enabled()),
                   "truncation_visible": True,
                   "items": 0, "generated_count": 0, "kept_count": 0,
                   "cap_truncated": 0, "cap_truncated_items": []}
    for _it in out:
        _mi_it = ((_it.get("d5") or {}).get("multi_instance")
                  if isinstance(_it.get("d5"), dict) else None)
        if not isinstance(_mi_it, dict):
            continue
        _mi_summary["items"] += 1
        _mi_summary["generated_count"] += int(_mi_it.get("generated_count") or 0)
        _mi_summary["kept_count"] += int(_mi_it.get("kept_count") or 0)
        if _mi_it.get("cap_truncated"):
            _mi_summary["cap_truncated"] += 1
            _mi_summary["cap_truncated_items"].append({
                "rule": _mi_it.get("rule") or _it.get("rule") or "",
                "object_id": _mi_it.get("object_id") or _it.get("object_id") or "",
                "generated_count": int(_mi_it.get("generated_count") or 0),
                "kept_count": int(_mi_it.get("kept_count") or 0),
                "limit": int(_mi_it.get("limit") or 0)})
    _a1_payload = {"manifest_id": mid, "items": out, "total": len(out),
            "completed": sum(1 for x in out if x["execution"] == "completed"),
            "incomplete": sum(1 for x in out if x["execution"] != "completed"),
            "evidence_gate": _evidence_gate_total,
            "version_snapshot": _snapshot_out,
            # L53：策略快照摘要（snapshot_id + engine_mode + 缺失开关 + 内容指纹）
            "strategy_snapshot": _strategy_snapshot_out,
            # P0-3：本轮 active 收口统计（expired/kept/skipped），报告/审计可追溯
            "active_scope": _active_scope_out,
            "parsed_reconciliation": _parsed_recon,
            "guard": _guard_out,
            # P0-B：旧清单 = legacy=True + closure_unverifiable=True（可读但不可与已验证混淆）
            "legacy": bool(_legacy_manifest),
            "closure_unverifiable": bool(_closure_unverifiable),
            "integrity": _integrity_out}
    if mi_truncation_visible():
        _a1_payload["multi_instance"] = _mi_summary
    if _a1_dropped:
        # 越界输出不是“部分成功”：显式 blocked，报告/门禁不得把本轮当完整判定。
        _a1_payload.update({"ok": False, "blocked": True,
                            "scope_guard": _a1_scope_guard})
    return _a1_payload


# L52（2026-11-24）唯一执行出口：物理单点只保留 `_run_core`；对外 `run()` 是同一执行体
# + `manifest.executed` / `manifest.execution_blocked` 审计下沉。这样 project.audit、
# CLI、HTTP 回落、补证重判等所有直调点天然共享同一审计口径，不再「谁走 execute 谁有审计」。
# 回退杆：RULEPROOF_SINGLE_ENTRY_FIX=0 → 不写该审计、不做 zero_executed 标记（逐字段旧行为）。
#
# L77（build49 P0，90 号 §二-3 / 外部评审 Top3）：审计写失败不再静默——
# 结构化返回 {ok, code, reason, action, skipped}，run() 把 audit_failed=True 写进返回，
# 由 project.audit（HTTP 409/CLI 非 0）与 report_gate（audit_write_failed 阻断签发）
# 共同 fail-closed；RULEPROOF_AUDIT_HARD_FAIL=0 才回退旧“只 warning 不阻断”。
def _single_entry_execution_audit(mid: str, out: dict) -> dict:
    """写 ``manifest.executed`` / ``manifest.execution_blocked`` 下沉审计（结构化结果）。

    返回：
    - 成功：``{"ok": True, "code": "", "reason": "", "action": <事件名>, "skipped": False}``
    - 审计写失败：``{"ok": False, "code": "audit_write_failed", "reason": <类型+摘要>,
      "action": <事件名>}``（不再只返回 False；原因可被门禁/报告引用）
    - 回退杆（SINGLE_ENTRY_FIX=0）：``{"ok": True, "skipped": True, ...}``（旧行为：不写审计）
    """
    result = {"ok": True, "code": "", "reason": "", "action": "",
              "skipped": False, "manifest_id": str(mid or "")}
    try:
        from . import single_entry as _se
        if not _se.enabled():
            result["skipped"] = True
            result["reason"] = ("RULEPROOF_SINGLE_ENTRY_FIX=0（回退杆）："
                                "不写 manifest.executed 下沉审计（逐字段旧行为）")
            return result
        blocked = bool((out or {}).get("blocked")) or bool((out or {}).get("error"))
        action = ("manifest.execution_blocked" if blocked else "manifest.executed")
        result["action"] = action
        guard = (out or {}).get("guard") or {}
        closure = (out or {}).get("closure") or {}
        payload = {
            "manifest_id": str(mid or ""),
            "entry": "manifest_exec.run",
            "single_entry_fix": 1,
            "blocked": blocked,
            "error": str((out or {}).get("error") or "")[:300],
            "total": (out or {}).get("total"),
            "completed": (out or {}).get("completed"),
            "incomplete": (out or {}).get("incomplete"),
            "zero_executed": bool(not blocked and int((out or {}).get("total") or 0) == 0),
            "closure_digest": (closure.get("closure_digest")
                               or guard.get("closure_digest") or ""),
            "guard_ok": guard.get("ok"),
            "scope_dropped": ((out or {}).get("scope_guard") or {}).get("dropped", 0),
            "active_scope": (out or {}).get("active_scope") or {},
        }
        ok = _se.audit(action, str(mid or ""), payload)
        (out or {})["executed_audit"] = action if ok else ""
        (out or {})["single_entry_fix"] = True
        if not ok:
            result.update({"ok": False, "code": "audit_write_failed",
                           "reason": f"审计写入失败（action={action}）"})
        return result
    except Exception as exc:  # noqa: BLE001 - L77：异常必须结构化留痕，由门禁决定硬阻断
        logging.getLogger(__name__).warning(
            "single entry execution audit failed manifest=%s", mid, exc_info=True)
        result.update({"ok": False, "code": "audit_write_failed",
                       "reason": f"{type(exc).__name__}: {str(exc)[:300]}"})
        try:
            (out or {})["executed_audit"] = ""
        except Exception:  # noqa: BLE001 - out 非 dict 时忽略
            pass
        return result


def _finalize_downstream_audit(out, mid: str, *,
                               external_audit_requested: bool = True):
    """审计下沉收口：L77 审计失败结构化标记（audit_failed/audit_error）。"""
    if not isinstance(out, dict):
        return out
    if external_audit_requested is False:
        # L77 收口：外部调用 audit=False 不再能跳过审计，强制升级并显式标注。
        out["audit_skip_rejected"] = True
    audit_result = _single_entry_execution_audit(mid, out)
    hard_fail = True
    try:
        from . import single_entry as _se_hf
        hard_fail = bool(_se_hf.audit_hard_fail_enabled())
    except Exception:  # noqa: BLE001 - 开关不可用按默认硬阻断
        hard_fail = True
    if not audit_result.get("ok"):
        if hard_fail:
            out["audit_failed"] = True
            out["audit_error"] = {
                "code": str(audit_result.get("code") or "audit_write_failed"),
                "reason": str(audit_result.get("reason") or "")[:500],
                "action": str(audit_result.get("action") or "")[:100],
            }
        else:
            # =0 回退旧行为：不新增 audit_failed 字段（逐字段旧行为）
            out.pop("audit_failed", None)
            out.pop("audit_error", None)
    elif hard_fail:
        out["audit_failed"] = False
    return out


def _run_with_downstream_audit(mid: str, external_facts: dict = None, *,
                               external_audit_requested: bool = True) -> dict:
    """同一执行体 + 审计下沉（run() 与白名单冒用回落共用；不含公开签名）。"""
    out = _run_core(mid, external_facts)
    return _finalize_downstream_audit(
        out, mid, external_audit_requested=external_audit_requested)


def run(mid: str, external_facts: dict = None, *, audit: bool = True) -> dict:
    """冻结清单执行唯一出口。

    ``audit=True``（默认）时下沉写 ``manifest.executed`` / ``manifest.execution_blocked``
    审计。L77 起外部传入 ``audit=False`` 不再能跳过审计（会被强制升级，返回体标
    ``audit_skip_rejected=True``）；``manifest.execute`` 自己写更丰富的审计，唯一例外
    走私有入口 :func:`_run_delegated_audit`（静态扫描白名单只允许它）。
    """
    out = _run_core(mid, external_facts)
    return _finalize_downstream_audit(
        out, mid, external_audit_requested=bool(audit))


def _run_delegated_audit(mid: str, external_facts: dict = None, *,
                         delegate: str = "") -> dict:
    """L77 内部私有入口：仅 ``manifest.execute`` 可跳过下沉审计（它自己写完整审计）。

    白名单通过 ``delegate="manifest.execute"`` 显式声明；任何其它调用方（含内部代码）
    冒用都会退回 :func:`run` 的强制审计口径（fail-closed）。静态扫描（L77 专项测试）
    约束：除 ``app/services/manifest.py::execute`` 外不得出现本函数调用，也不得出现
    ``audit=False`` 的 ``manifest_exec.run`` 调用。
    """
    if str(delegate or "") != "manifest.execute":
        logging.getLogger(__name__).warning(
            "run_delegated_audit rejected non-whitelisted delegate=%r manifest=%s"
            "→ 强制审计", delegate, mid)
        return _run_with_downstream_audit(mid, external_facts)
    out = _run_core(mid, external_facts)
    if isinstance(out, dict):
        # 不写 audit_failed：本路径的下沉审计由 manifest.execute 自己负责（它写更丰富
        # 的 manifest.executed）；缺省字段表示“下沉审计不适用”，不冒充审计成功。
        out["audit_delegated_to"] = "manifest.execute"
    return out


# ---------------- 稳定性：同文件重审 N=3 多数投票 + pass↔fail 翻转 marker ----------------
# 票源 = 同一 case 最近 N 次（默认 3）带 manifest 的审核/重审；按 (对象, 规则) 对齐 D5
# 结论做严格多数决。关键规则（severity=critical）出现 pass 与 fail 并存 = 翻转 marker，
# 必须由 report_gate 硬阻断签发（不是 UI 提示）；满 N 次且全部稳定时落投票结果。
_STABILITY_CONCLUSION_STATES = ("pass", "fail")   # 有效结论票（pass/fail）
_STABILITY_NOT_APPLICABLE = {"na", "not_applicable", "not applicable", "skipped", "不适用"}
_STABILITY_N_DEFAULT = 3


def _stability_n() -> int:
    raw = (os.environ.get("RULEPROOF_STABILITY_VOTES")
           or os.environ.get("RULEPROOF_MANIFEST_VOTES")
           or os.environ.get("RULEPROOF_VOTES") or "")
    try:
        n = int(str(raw).strip()) if str(raw).strip() else _STABILITY_N_DEFAULT
    except Exception:
        n = _STABILITY_N_DEFAULT
    return max(1, min(n, 5))


_VOTE_STATE_MAP = {
    "pass": "pass", "满足": "pass", "通过": "pass",
    "fail": "fail", "不满足": "fail", "不通过": "fail",
    "na": "na", "not_applicable": "na", "skipped": "na", "不适用": "na",
    "insufficient": "insufficient", "needs_model": "insufficient", "弃权": "insufficient",
    "证据不足": "insufficient",
    "unknown": "unknown", "无法判断": "unknown",
    # V10：执行失败是独立票型，不再折成 unknown/弃权而“被多数消除”。
    "execution_failed": "execution_failed", "failed": "execution_failed",
    "blocked": "execution_failed", "执行失败": "execution_failed",
}


def _vote_state(raw, conclusion: str = "") -> str:
    """六状态归一：结论票只认 pass/fail；na=不适用（不是弃权）；execution_failed 独立保留。"""
    st = _VOTE_STATE_MAP.get(str(raw or "").strip())
    if st:
        return st
    c = str(conclusion or "").strip()
    if c in ("满足", "通过"):
        return "pass"
    if c in ("不满足", "不通过"):
        return "fail"
    if c in ("不适用",):
        return "na"
    if c in ("执行失败", "失败"):
        return "execution_failed"
    return "insufficient"


def _vote_states(states: list, planned=None) -> dict:
    """N 次投票口径（V10）：先固定适用性/投票资格，再报有效票 + 计划票。

    - 适用性先固定：na = 该次运行该实例“不适用”，不是弃权；不计入结论票分母，
      单独报 na_runs（不参与 pass/fail 多数）。
    - 分母 = 已观测适用票 eligible（含 insufficient/unknown/execution_failed）+
      计划票中未观测的 missing；不因弃权/证据不足缩小分母（旧实现用 voted=pass+fail
      当分母，pass,insufficient,insufficient 会错误凑出 pass）。
    - 严格多数 = eligible // 2 + 1；不足即 insufficient，不得用缩小分母制造多数。
    - execution_failed 独立票型：任一 execution_failed → majority=blocked，
      多数票不能把它消除；报告必须显式显示 execution_failed/计划票。
    - 全部 na → majority=na（确定的不适用，不是弃权，也不是未完成）。
    """
    ss = [_vote_state(x) for x in (states or [])]
    dist = {}
    for s in ss:
        dist[s] = dist.get(s, 0) + 1
    observed = len(ss)
    try:
        planned_n = int(planned) if planned is not None else observed
    except Exception:
        planned_n = observed
    planned_n = max(planned_n, observed)
    na_runs = dist.get("na", 0)
    exec_runs = dist.get("execution_failed", 0)
    insufficient_runs = dist.get("insufficient", 0)
    unknown_runs = dist.get("unknown", 0)
    eligible = observed - na_runs            # 已确定适用/应投票的观测票（分母固定）
    pass_n = dist.get("pass", 0)
    fail_n = dist.get("fail", 0)
    valid = pass_n + fail_n                  # 有效结论票
    invalid = insufficient_runs + unknown_runs
    missing = max(0, planned_n - observed)
    need = (eligible // 2 + 1) if eligible else 0
    blocked = exec_runs > 0
    if blocked:
        majority = "blocked"
    elif eligible == 0:
        majority = "na" if na_runs else "insufficient"
    elif fail_n >= need:
        majority = "fail"
    elif pass_n >= need:
        majority = "pass"
    else:
        majority = "insufficient"
    return {"dist": dist,
            "conclusion_dist": {"pass": pass_n, "fail": fail_n},
            "voted": valid, "need": need, "majority": majority,
            "flip": bool(pass_n and fail_n),
            "conclusion_states": sorted(s for s in _STABILITY_CONCLUSION_STATES
                                        if dist.get(s)),
            # V10 分母契约：计划票 / 观测票 / 适用资格 / 有效票 / 无效票 / na / 执行失败
            "planned": planned_n, "observed": observed, "applicable": eligible,
            "denominator": eligible, "valid_votes": valid, "invalid_votes": invalid,
            "na_runs": na_runs, "missing_runs": missing,
            "insufficient_runs_vote": insufficient_runs,
            "unknown_runs_vote": unknown_runs,
            "execution_failed_runs": exec_runs,
            "blocked": blocked,
            "majority_rule": "eligible=%d,need=%d,valid=%d,na=%d,exec=%d,missing=%d"
                             % (eligible, need, valid, na_runs, exec_runs, missing)}


def _rule_meta_index() -> dict:
    try:
        rows = R.rules.list()
    except Exception:
        rows = []
    from ..severity import normalize as _sev_norm
    out = {}
    for r in rows or []:
        code = str((r or {}).get("code") or "")
        if not code:
            continue
        out[code] = {"rule_code": code, "name": str(r.get("name") or ""),
                     "severity": _sev_norm(r.get("severity"), r.get("rclass")),
                     "rclass": str(r.get("rclass") or "")}
    return out


def _evidence_type_of_sub(sub: dict) -> str:
    """证据四分类（引文/缺失/计算/关系）：投票/审计口径必须显式，不能一律当引文。"""
    sub = sub or {}
    tt = sub.get("tool_trace") or {}
    ex = str(tt.get("executor") or "")
    if ex == "tool" or sub.get("amount_sources") or sub.get("tax_sources"):
        return "computation"
    if ex == "decision_table" or str(sub.get("raw_state") or "").startswith("decision_table"):
        return "relation"
    if not _sub_quote_candidates(sub):
        return "missing"
    return "quote"


def stability_votes(case_id: str, n: int = None, persist: bool = True) -> dict:
    """同文件重审 N=3 投票：按“问题实例”粒度对最近 N 次审核做多数决 + 翻转 marker。

    约束（主线程架构要求）：
    - 问题实例 = 对象 × 规则 × 子要求/命中行（sub_id 含 ``#行``），同一规则的两个独立
      条款分别是两条实例，不按 rule_code/引文前缀归并，避免吞掉定位；
    - 实例标识：run_id / rule_id / rule_version / subject / object_id /
      issue_type / occurrence_id（occurrence_id = sub_id）；
    - 证据类型按四分类标注（quote/missing/computation/relation），不把缺失字段
      当成“引文未命中”；
    - 规则级 D5 结论单独复核：子要求未翻转但 D5 翻转（组合/兜底导致）同样阻断；
    - 关键规则（severity=critical）pass↔fail 并存 → key_flips（report_gate 硬阻断）；
    - 满 N 次且全部稳定 → 落投票结果（sysconfig，与报告/门禁同源，可审计）。
    """
    n = int(n or _stability_n())
    c = db.connect()
    try:
        runs = [dict(r) for r in c.execute(
            "SELECT id, manifest_id, created_at FROM audit_run "
            "WHERE case_id=? AND COALESCE(manifest_id,'')<>'' "
            "ORDER BY created_at DESC, rowid DESC LIMIT ?",
            (case_id, n)).fetchall()]
        states_by_run = []
        for run in runs:
            mid = run.get("manifest_id") or ""
            objects = {}
            try:
                _mr = c.execute("SELECT objects_json FROM audit_manifest WHERE id=?",
                                (mid,)).fetchone()
                for _o in json.loads((_mr["objects_json"] if _mr else "") or "[]"):
                    objects[str(_o.get("object_id") or "")] = str(_o.get("filename") or "")
            except Exception:
                objects = {}
            rows = c.execute(
                "SELECT object_id, rule_code, rule_id, d2_json, d4_json, d5_json, "
                "conclusion, execution FROM manifest_result WHERE manifest_id=?", (mid,)).fetchall()
            per = {}
            for row in rows:
                try:
                    d4 = json.loads(row["d4_json"] or "{}")
                except Exception:
                    d4 = {}
                try:
                    d5 = json.loads(row["d5_json"] or "{}")
                except Exception:
                    d5 = {}
                try:
                    d2 = json.loads(row["d2_json"] or "{}")
                except Exception:
                    d2 = {}
                _obj = str(row["object_id"] or "")
                _code = str(row["rule_code"] or "")
                _base = {"object_id": _obj, "rule_code": _code,
                         "rule_id": str(row["rule_id"] or ""),
                         "rule_version": str((d2 or {}).get("version") or ""),
                         "subject": objects.get(_obj, "")}
                subs = (d4 or {}).get("subs") or []
                if subs:
                    for _si, _sub in enumerate(subs):
                        _sid = str((_sub or {}).get("id") or f"S{_si + 1}")
                        per[(_obj, _code, "instance", _sid)] = {
                            **_base, "level": "instance", "sub_id": _sid,
                            "occurrence_id": _sid,
                            "issue_type": str((_sub or {}).get("raw_state")
                                              or ((_sub or {}).get("tool_trace") or {}).get("executor")
                                              or "subrequirement"),
                            "evidence_type": _evidence_type_of_sub(_sub),
                            "state": _vote_state((_sub or {}).get("status")),
                            "conclusion": str((_sub or {}).get("detail") or "")[:200],
                            "execution": str(row["execution"] or ""),
                            "presence": ({"found": bool(_sub_quote_candidates(_sub)),
                                          "search_scope": "document",
                                          "parse_completeness": True}
                                         if _evidence_type_of_sub(_sub) == "missing" else None)}
                else:
                    per[(_obj, _code, "instance", "")] = {
                        **_base, "level": "instance", "sub_id": "", "occurrence_id": "",
                        "issue_type": "rule_conclusion",
                        "evidence_type": "rule",
                        "state": _vote_state((d5 or {}).get("status"), row["conclusion"]),
                        "conclusion": str(row["conclusion"] or ""),
                        "execution": str(row["execution"] or ""), "presence": None}
                # 规则级 D5 结论单独记录：子要求未翻转但组合/兜底导致翻转也必须检出
                per[(_obj, _code, "rule", "")] = {
                    **_base, "level": "rule", "sub_id": "", "occurrence_id": "",
                    "issue_type": "rule_conclusion", "evidence_type": "rule",
                    "state": _vote_state((d5 or {}).get("status"), row["conclusion"]),
                    "conclusion": str(row["conclusion"] or ""),
                    "execution": str(row["execution"] or ""), "presence": None}
            states_by_run.append({"run": run, "states": per})
    finally:
        c.close()
    # P0-3（2026-11-21）：稳定性投票只对「当前 active 口径」内的 rule×object 实例投票。
    # 规则集收窄/对象删除后，已被 run() 收口摘除的旧 manifest 结果不得借 N 轮投票视图
    # 重新混进报告（否则报告仍会展示已移除规则的历史结论，与「单一冻结清单」矛盾），
    # 也不得让已移除规则的 pass↔fail 翻转继续阻断本轮门禁。
    # reaudit 定向复审会同时保留其它在册 key 的 active 指针，不误伤这部分历史。
    try:
        _cs = db.connect()
        try:
            _scope_keys = {(str(r["object_id"] or ""), str(r["rule_code"] or ""))
                           for r in _cs.execute(
                               "SELECT object_id,rule_code FROM manifest_active WHERE case_id=?",
                               (case_id,))}
        finally:
            _cs.close()
        if _scope_keys:
            for _pack in states_by_run:
                _pack["states"] = {
                    _k: _v for _k, _v in _pack["states"].items()
                    if (str(_v.get("object_id") or ""),
                        str(_v.get("rule_code") or "")) in _scope_keys}
    except Exception:
        logging.getLogger(__name__).debug("stability scope filter skipped", exc_info=True)
    rule_meta = _rule_meta_index()
    keys = []
    for pack in states_by_run:
        for key in pack["states"]:
            if key not in keys:
                keys.append(key)

    def _build_item(key, level_filter: str) -> dict:
        object_id, rule_code = key[0], key[1]
        sub_id, issue_type, evidence_type = key[3], "", ""
        rule_id, rule_version, subject = "", "", ""
        seq = []
        for pack in states_by_run:
            hit = pack["states"].get(key) or {}
            if hit:
                issue_type = hit.get("issue_type") or issue_type
                evidence_type = hit.get("evidence_type") or evidence_type
                rule_id = hit.get("rule_id") or rule_id
                rule_version = hit.get("rule_version") or rule_version
                subject = hit.get("subject") or subject
            seq.append({"run_id": pack["run"].get("id"),
                        "manifest_id": pack["run"].get("manifest_id"),
                        "state": hit.get("state") or "missing",
                        "conclusion": hit.get("conclusion") or "",
                        "execution": hit.get("execution") or ""})
        _observed = [x["state"] for x in seq if x["state"] != "missing"]
        vote = _vote_states(_observed, planned=n)
        meta = rule_meta.get(rule_code) or {"name": "", "severity": "warning", "rclass": ""}
        key_rule = str(meta.get("severity") or "") == "critical"
        item = {"level": level_filter,
                "run_id": (seq[0].get("run_id") if seq else "") or "",
                "object_id": object_id, "rule_code": rule_code, "rule_id": rule_id,
                "rule_version": rule_version, "subject": subject,
                "sub_id": sub_id, "occurrence_id": sub_id, "issue_type": issue_type,
                "evidence_type": evidence_type, "rule_name": meta.get("name") or "",
                "severity": meta.get("severity") or "", "key_rule": key_rule,
                "states": seq, **vote,
                "runs_present": sum(1 for x in seq if x["state"] != "missing")}
        item["stable"] = bool(item["runs_present"] >= n and not item["flip"]
                              and item["majority"] in _STABILITY_CONCLUSION_STATES
                              and not item.get("blocked"))
        return item

    instance_items = [_build_item(k, "instance") for k in keys
                      if k[2] == "instance"]
    rule_items = [_build_item(k, "rule") for k in keys if k[2] == "rule"]
    rule_flips = [x for x in rule_items if x["flip"]]
    _inst_flip_keys = {(x["object_id"], x["rule_code"]) for x in instance_items
                       if x["flip"]}
    # 规则级翻转只保留“实例级未覆盖”的项，避免同一翻转在报告里重复列示
    extra_rule_items = [x for x in rule_flips
                        if (x["object_id"], x["rule_code"]) not in _inst_flip_keys]
    items = instance_items + extra_rule_items
    flips = []
    for item in items:
        if not item["flip"]:
            continue
        flips.append({"case_id": case_id,
                      "point": item["rule_code"],
                      "run_id": item.get("run_id") or "",
                      "rule_code": item["rule_code"],
                      "rule_id": item.get("rule_id") or "",
                      "rule_version": item.get("rule_version") or "",
                      "object_id": item["object_id"],
                      "sub_id": item.get("sub_id") or "",
                      "occurrence_id": item.get("occurrence_id") or "",
                      "issue_type": item.get("issue_type") or "",
                      "evidence_type": item.get("evidence_type") or "",
                      "subject": item.get("subject") or "",
                      "rule_name": item["rule_name"],
                      "severity": item["severity"], "key_rule": item["key_rule"],
                      "level": item.get("level") or "instance",
                      "states": item["conclusion_states"],
                      "run_ids": [x["run_id"] for x in item["states"]],
                      "manifest_ids": [x["manifest_id"] for x in item["states"]],
                      "handled": False})
    key_flips = [f for f in flips if f.get("key_rule")]
    other_flips = [f for f in flips if not f.get("key_rule")]
    _blocked_items = [x for x in items if x.get("blocked")]
    _na_items = [x for x in items if str(x.get("majority") or "") == "na"]
    _votes_summary = {
        "n": n, "planned_runs": n, "points": len(items),
        "instance_points": len(instance_items),
        "observed_votes": sum(int(x.get("observed") or 0) for x in items),
        "applicable_votes": sum(int(x.get("applicable") or 0) for x in items),
        "valid_votes": sum(int(x.get("valid_votes") or 0) for x in items),
        "invalid_votes": sum(int(x.get("invalid_votes") or 0) for x in items),
        "na_votes": sum(int(x.get("na_runs") or 0) for x in items),
        "insufficient_votes": sum(int(x.get("insufficient_runs_vote") or 0) for x in items),
        "unknown_votes": sum(int(x.get("unknown_runs_vote") or 0) for x in items),
        "execution_failed_votes": sum(int(x.get("execution_failed_runs") or 0) for x in items),
        "missing_votes": sum(int(x.get("missing_runs") or 0) for x in items),
        "blocked_items": len(_blocked_items),
        "not_applicable_items": len(_na_items),
    }
    _blocked_out = [{"rule_code": x.get("rule_code") or "",
                     "object_id": x.get("object_id") or "",
                     "sub_id": x.get("sub_id") or "",
                     "level": x.get("level") or "instance",
                     "majority": x.get("majority") or "",
                     "execution_failed_runs": int(x.get("execution_failed_runs") or 0),
                     "states": [s.get("state") for s in (x.get("states") or [])]}
                    for x in _blocked_items]
    res = {"case_id": case_id, "n": n, "runs_count": len(runs),
           "insufficient_runs": max(0, n - len(runs)),
           "runs": [{"run_id": r["run"].get("id"),
                     "manifest_id": r["run"].get("manifest_id"),
                     "created_at": r["run"].get("created_at")} for r in states_by_run],
           "points": len(items), "items": items, "rule_items": rule_items,
           "flips": flips, "key_flips": key_flips, "other_flips": other_flips,
           "evidence_types": {t: sum(1 for x in instance_items if x.get("evidence_type") == t)
                              for t in ("quote", "missing", "computation", "relation", "rule")},
           "votes_summary": _votes_summary, "blocked_items": _blocked_out,
           "stable": bool(items and len(runs) >= n and not flips
                          and all(x.get("stable") for x in items)),
           # 执行失败不能被多数消除：存在 blocked 实例时不落“稳定投票通过”
           "vote_recorded": bool(len(runs) >= n and not flips and not _blocked_items),
           "computed_at": db.now()}
    if persist and (flips or len(runs) >= n):
        res["marker"] = _persist_stability(case_id, res)
    return res


def _persist_stability(case_id: str, res: dict) -> dict:
    """落稳定性 marker/投票结果（sysconfig 单键；report_gate/report/case_report 同源读取）。"""
    from . import stability as _st
    payload = {"points": res.get("points") or 0,
               "flips": res.get("flips") or [],
               "evidence_types": res.get("evidence_types") or {},
               "votes": [{"object_id": x.get("object_id"),
                          "rule_code": x.get("rule_code"),
                          "rule_id": x.get("rule_id"),
                          "rule_version": x.get("rule_version"),
                          "subject": x.get("subject"),
                          "sub_id": x.get("sub_id"),
                          "occurrence_id": x.get("occurrence_id"),
                          "issue_type": x.get("issue_type"),
                          "evidence_type": x.get("evidence_type"),
                          "level": x.get("level"),
                          "rule_name": x.get("rule_name"),
                          "severity": x.get("severity"),
                          "key_rule": bool(x.get("key_rule")),
                          "conclusion_dist": x.get("conclusion_dist") or {},
                          "majority": x.get("majority"),
                          "flip": bool(x.get("flip")),
                          "stable": bool(x.get("stable")),
                          "planned": int(x.get("planned") or 0),
                          "applicable": int(x.get("applicable") or 0),
                          "denominator": int(x.get("denominator") or 0),
                          "valid_votes": int(x.get("valid_votes") or 0),
                          "invalid_votes": int(x.get("invalid_votes") or 0),
                          "na_runs": int(x.get("na_runs") or 0),
                          "execution_failed_runs": int(x.get("execution_failed_runs") or 0),
                          "blocked": bool(x.get("blocked")),
                          "states": [{k: s.get(k) for k in
                                      ("run_id", "manifest_id", "state", "conclusion")}
                                     for s in (x.get("states") or [])]}
                         for x in (res.get("items") or [])],
               "runs": res.get("runs") or [],
               "votes_summary": res.get("votes_summary") or {},
               "blocked_items": res.get("blocked_items") or [],
               "n": res.get("n"), "stable": bool(res.get("stable")),
               "vote_recorded": bool(res.get("vote_recorded")),
               "computed_at": res.get("computed_at") or db.now()}
    prev = _st.load(case_id) or {}
    keys = ("points", "flips", "runs", "n", "stable", "votes_summary", "blocked_items")
    try:
        changed = json.dumps({k: prev.get(k) for k in keys}, ensure_ascii=False,
                             sort_keys=True) != json.dumps(
            {k: payload.get(k) for k in keys}, ensure_ascii=False, sort_keys=True)
    except Exception:
        changed = True
    if changed:
        _st.save(case_id, payload)
        try:
            _runs = [r.get("manifest_id") for r in (payload.get("runs") or [])]
            if payload.get("blocked_items"):
                R.audit_logs.log(
                    actor="system", action="stability.execution_blocked", object=case_id,
                    after=json.dumps({"blocked": len(payload["blocked_items"]),
                                      "execution_failed_votes": int(
                                          (payload.get("votes_summary") or {}).get(
                                              "execution_failed_votes") or 0),
                                      "n": payload.get("n"),
                                      "items": payload["blocked_items"][:10]},
                                     ensure_ascii=False))
            if payload.get("flips"):
                R.audit_logs.log(
                    actor="system", action="stability.flip_marker", object=case_id,
                    after=json.dumps({"flips": len(payload["flips"]),
                                      "key_flips": len([f for f in payload["flips"]
                                                        if f.get("key_rule")]),
                                      "n": payload.get("n"), "runs": _runs},
                                     ensure_ascii=False))
            elif payload.get("vote_recorded"):
                R.audit_logs.log(
                    actor="system", action="stability.vote_record", object=case_id,
                    after=json.dumps({"points": payload.get("points"),
                                      "n": payload.get("n"),
                                      "stable": payload.get("stable"), "runs": _runs},
                                     ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("stability audit skipped", exc_info=True)
    return payload


# ---------------- D5 组合语义（AND / OR）：V03 六状态代数契约 ----------------
# 契约来源：工程证伪测试集_v1/state_algebra.json（72 组合只读契约，禁止改预期）。
#   六状态 = pass / fail / insufficient / unknown / na / execution_failed
#   1) verdict（业务结论）与 complete（执行完整性）分离，不得把未完成当通过或当不通过；
#   2) na 不参与结论票：全 na 是确定的“不适用”，verdict=na 且 complete=True；
#   3) all：任一 fail → fail；否则存在 incomplete 项 → undetermined；否则 pass；
#   4) any：任一 pass → pass；否则非 na 项全为 fail → fail；否则 undetermined；
#   5) complete = 不存在 insufficient/unknown/execution_failed（与组合算子无关）；
#   6) 关键反例：all(fail, execution_failed)=fail+incomplete；
#                any(pass, insufficient)=pass+incomplete；
#                any(pass, execution_failed)=pass+incomplete；
#   7) report_allowed_without_exception = complete；fail 仍走正常人工复核，
#      不代表可以凭例外授权直接签发（例外只能针对 unknown/证据不足，见 report_gate）。
_INCOMPLETE = {"insufficient", "unknown", "execution_failed"}
# DU-29（2026-11-25）：别名/na 家族单一事实源在 ``state_machines``（与 audit_ledger
# 台账/报告口径共用 VERDICT_ALIASES/NA_STATES），本模块只保留「规范态 → D5 契约六态」
# 的轴映射：missing 不在六态内 → unknown（fail-closed，D5 没有 missing 语义）。
_NA_STATES = _state_machines.NA_STATES
_MISSING_AXIS = {"missing": "unknown"}


def normalize_state(raw) -> str:
    """任意历史状态名 → 契约六状态之一（别名表在 state_machines；无法识别按 unknown）。"""
    canon = _state_machines.normalize_verdict(raw)
    return _MISSING_AXIS.get(canon, canon)


def combine_contract(states: list, combination: str = "all") -> dict:
    """六状态 × all/any 契约真值表（state_algebra.json）。返回 verdict/complete 分离结果。"""
    canon = [normalize_state(x) for x in (states or [])]
    comb = "any" if str(combination).lower() in ("any", "or") else "all"
    out = {"verdict": "undetermined", "complete": False,
           "report_allowed_without_exception": False, "combination": comb,
           "states": canon, "failed": [], "incomplete": [], "na_count": 0,
           "reason": ""}
    if not canon:
        out["reason"] = "没有子要求结果"
        return out
    failed = [i for i, x in enumerate(canon) if x == "fail"]
    incomplete = [i for i, x in enumerate(canon) if x in _INCOMPLETE]
    na_count = sum(1 for x in canon if x in _NA_STATES)
    non_na = [x for x in canon if x not in _NA_STATES]
    complete = not incomplete
    if not non_na:
        verdict, reason = "na", "全部不适用"
    elif comb == "all":
        if failed:
            verdict, reason = "fail", "至少一项子要求不满足"
        elif incomplete:
            verdict, reason = "undetermined", "存在无法判断/未完成的子要求"
        else:
            verdict, reason = "pass", "全部适用子要求满足"
    else:
        if any(x == "pass" for x in non_na):
            verdict, reason = "pass", "至少一项子要求满足"
        elif all(x == "fail" for x in non_na):
            verdict, reason = "fail", "非不适用子要求全部不满足"
        else:
            verdict, reason = "undetermined", "没有满足项，且存在无法判断/未完成的子要求"
    out.update({"verdict": verdict, "complete": bool(complete),
                "report_allowed_without_exception": bool(complete),
                "failed": failed, "incomplete": incomplete,
                "na_count": na_count, "reason": reason})
    return out


def combine(states: list, combination: str = "all") -> dict:
    """D5 汇总（兼容旧调用）：status 字段由契约 verdict 映射，另附 verdict/complete。

    status 旧口径映射：pass/fail/na 原样；undetermined 按子态细分（A2，2026-11-21）：
      1) 任一子态 execution_failed → ``blocked``（报告归“执行失败”，fallback=fail
         不得把执行失败改写成不满足）；
      2) 任一子态 unknown / needs_model → ``unknown``（不得吞成 insufficient：
         报告门禁 #13「unknown 未授权」与对象级例外授权依赖 manifest_active_sub
         里出现 unknown；缺模型/无法判断必须显式可见，不能伪装成证据不足）；
      3) 其余 undetermined → ``insufficient``。
    ``complete`` 与 verdict 分离，run() 据此写 execution=incomplete
    （all(fail,execution_failed) 不再算执行完成）。
    """
    c = combine_contract(states, combination)
    canon = c["states"]
    verdict = c["verdict"]
    # 子态原文：combine_contract 已归一为六状态，needs_model 会被归成 insufficient，
    # 因此必须回看调用方传入的原始状态名，否则「缺模型」在兼容层永远不可见。
    _raw = [str(x if x is not None else "").strip().lower() for x in (states or [])]
    _UNKNOWN_RAW = {"unknown", "needs_model", "无法判断", "未执行", "弃权"}
    _BLOCKED_RAW = {"execution_failed", "blocked", "failed", "执行失败", "executor_error"}
    if not canon:
        status = "unknown"
    elif verdict in ("pass", "fail", "na"):
        status = verdict
    elif "execution_failed" in canon or any(x in _BLOCKED_RAW for x in _raw):
        status = "blocked"
    elif "unknown" in canon or any(x in _UNKNOWN_RAW for x in _raw):
        status = "unknown"
    else:
        status = "insufficient"
    return {"status": status, "reason": c["reason"],
            "failed": c["failed"], "incomplete": c["incomplete"],
            "verdict": verdict, "complete": bool(c["complete"]),
            "report_allowed_without_exception": bool(c["complete"]),
            "canonical_states": canon, "combination": c["combination"],
            "na_count": int(c["na_count"] or 0)}


def d5_execution_state(d5: dict) -> str:
    """verdict/completeness 分离落库：只有 verdict 确定且 complete 才算执行完成。"""
    d5 = d5 or {}
    if not bool(d5.get("complete", True)):
        return "incomplete"
    return ("completed" if str(d5.get("status") or "") in ("pass", "fail", "na")
            else "incomplete")


def decide(result_id: str, status: str, reason: str = "", reviewer: str = "", role: str = "") -> dict:
    """子要求复核：只影响 规则×对象×子要求 对应结果，并保留历史。

    C5（评审 P0 第二批）：并发复核 CAS。修复前是「读到旧行 → 无条件 UPDATE」，
    两个审核员同时对同一 manifest_result 分别 confirmed / false_positive 时**都成功**、
    都追加 manifest_review + manifest.decided 审计，最终状态取决于最后提交者，
    先提交者的裁决被静默覆盖（审计里两条 before 都指向同一旧状态）。
    现在 UPDATE 带「写前值比对」（``COALESCE(review_status,'pending')=<读到的值>``），
    SQLite 单写锁保证只有一个 rowcount=1：
      - 抢不到且当前状态 == 目标状态 → 幂等成功（不重复写 manifest_review/审计）；
      - 抢不到且当前状态 != 目标状态 → 409 ``manifest_decision_conflict``，不写任何东西。
    """
    allowed = {"confirmed", "false_positive", "need_evidence", "ignored"}
    if status not in allowed:
        return {"error": "无效复核状态"}
    if role not in ("admin", "super_admin", "reviewer"):
        return {"error": "无复核权限", "code": "forbidden"}
    c = db.connect()
    try:
        row = c.execute("SELECT * FROM manifest_result WHERE id=?", (result_id,)).fetchone()
        if not row:
            return {"error": "结果不存在"}
        before = str(row["review_status"] or "pending") if "review_status" in row.keys() else "pending"
        if before == status:
            # 目标状态已是当前状态：幂等，不重复写 manifest_review / 审计
            return {"ok": True, "result_id": result_id, "review_status": status,
                    "reviewer": reviewer or "", "role": role or "", "reason": reason or "",
                    "before_status": before, "idempotent": True, "changed": False}
        cur = c.execute(
            "UPDATE manifest_result SET review_status=?, review_reason=?, reviewer=?, "
            "reviewed_at=? WHERE id=? AND COALESCE(review_status,'pending')=?",
            (status, reason or "", reviewer or "", db.now(), result_id, before))
        if int(cur.rowcount or 0) != 1:
            fresh = c.execute("SELECT review_status, reviewer FROM manifest_result WHERE id=?",
                              (result_id,)).fetchone()
            fresh_status = str((fresh["review_status"] if fresh else "") or "")
            if fresh_status == status:
                return {"ok": True, "result_id": result_id, "review_status": status,
                        "reviewer": reviewer or "", "role": role or "",
                        "reason": reason or "", "before_status": fresh_status,
                        "idempotent": True, "changed": False}
            return {"error": "复核冲突：该结果已被他人复核，请刷新后按当前结论重新复核",
                    "code": "manifest_decision_conflict", "status": 409,
                    "result_id": result_id,
                    "current": {"status": fresh_status or before,
                                "reviewer": str((fresh["reviewer"] if fresh else "") or "")}}
        c.execute("INSERT INTO manifest_review(id,result_id,status,reason,reviewer,role,created_at) "
                  "VALUES(?,?,?,?,?,?,?)",
                  (db.new_id("mrev"), result_id, status, reason or "", reviewer or "", role or "", db.now()))
        c.commit()
        m = dict(row)
    finally:
        c.close()
    try:
        from . import review as _rv
        f = next((x for x in R.findings.list("manifest_result_id=?", (result_id,))), None)
        if f:
            _rv.decide(f["id"], status, reason=reason, user=reviewer or "")
    except Exception:
        pass
    R.audit_logs.log(actor=reviewer or "system", action="manifest.decided", object=result_id,
                     after=status + "|" + str(reason or "")[:100] + "|role=" + (role or ""))
    # L80 / P0-C：复核写点留痕（append-only 台账不 UPDATE；人工归因由 ledger_stats 读
    # manifest_review 投影，本钩子只写一条 adjudication.ledger.human_decision 审计）。
    try:
        if adjudication_ledger.enabled():
            adjudication_ledger.append_human_decision(
                result_id=result_id, decision=status, reviewer=reviewer or "",
                role=role or "", reason=reason or "")
    except Exception:  # noqa: BLE001 - 留痕失败不改变复核结果
        logging.getLogger(__name__).warning(
            "adjudication human decision audit skipped result=%s", result_id, exc_info=True)
    return {"ok": True, "result_id": result_id, "review_status": status,
            "reviewer": reviewer or "", "role": role or "", "reason": reason or "",
            "before_status": before, "idempotent": False, "changed": True}


def history(result_id: str) -> dict:
    c = db.connect()
    try:
        rows = c.execute("SELECT * FROM manifest_review WHERE result_id=? ORDER BY created_at", (result_id,)).fetchall()
        return {"result_id": result_id, "items": [dict(x) for x in rows]}
    finally:
        c.close()


def _norm_checklist(checklist) -> list:
    out = []
    for x in (checklist or []):
        if isinstance(x, dict):
            label = str(x.get("label") or x.get("item") or "").strip()
            note = str(x.get("reason") or x.get("note") or "").strip()
            if label:
                out.append({"label": label, "reason": note})
        else:
            v = str(x or "").strip()
            if v:
                out.append({"label": v, "reason": ""})
    return out[:20]


# ---------------- A10（2026-11-21）：finding.certainty/confidence 唯一证据口径 ----------------
# 修前同一字段两套来源：普通路径按严重度（critical→certain、其它→probable、
# confidence=None），collect 路径按逐字核验写 deterministic/1.0。后果：certainty 无法从
# 证据复算，critical 规则天然绕过“Fail 置信门槛”门禁。
# 统一为证据驱动（本函数是 run / project.audit 两条链唯一的取值入口）：
#   computation / relation 的最小可复核集完整 → deterministic（confidence=1.0）
#   quote 逐字命中（无计算/关系复核集）      → probable（confidence=0.8）
#   仅有结论、无可复核证据                    → probable（confidence=0.5，强度分）
#   证据门禁失败                              → abstain（confidence=0.0）
_EVIDENCE_CONFIDENCE = {"deterministic": 1.0, "probable": 0.8, "abstain": 0.0}


def evidence_grade(*, quote_verified: bool = False, computation_complete: bool = False,
                   relation_complete: bool = False, evidence_ok: bool = True) -> dict:
    """证据强度 → {certainty, confidence, basis}（A10 唯一口径，不再看严重度）。"""
    if not evidence_ok:
        return {"certainty": "abstain", "confidence": 0.0,
                "basis": "evidence_gate_failed"}
    if computation_complete:
        return {"certainty": "deterministic", "confidence": 1.0,
                "basis": "computation_min_reproducible_set"}
    if relation_complete:
        return {"certainty": "deterministic", "confidence": 1.0,
                "basis": "relation_two_ended"}
    if quote_verified:
        return {"certainty": "probable", "confidence": 0.8, "basis": "quote_verbatim"}
    return {"certainty": "probable", "confidence": 0.5, "basis": "conclusion_only"}


def _materialize_collect_findings(case_id: str, item: dict, result_id: str, d4: dict) -> list:
    """collect 每个命中行物化为独立 finding + 锚点/证据；旧 pending 生成结果置 superseded。

    P0-证据：命中行的引文必须逐字命中归属对象的目标单元格；定位缺失/引文不命中时
    该行不得作为 fail/certain 落 finding，降级为 insufficient + need_evidence 人工复核。
    """
    subs = [x for x in (d4.get("subs") or []) if str(x.get("raw_state") or "") == "decision_table_collect"]
    if not subs:
        return []
    import hashlib
    from ..severity import normalize as _sev
    try:
        c = db.connect()
        ar = c.execute("SELECT id FROM audit_run WHERE case_id=? ORDER BY created_at DESC LIMIT 1", (case_id,)).fetchone()
        run_id = ar["id"] if ar else ""
        c.execute("UPDATE finding SET status='superseded' WHERE case_id=? AND rule_id=? "
                  "AND object_id=? AND engine='manifest:decision_table' AND status='pending'",
                  (case_id, str(item.get("code") or ""), str(item.get("object_id") or "")))
        c.commit(); c.close()
    except Exception:
        run_id = ""
    made = []
    _parse_cache_bk = {}     # L71：同一文档一次解析（证据回填 + 门禁共用）
    for sub in subs:
        sid = str(sub.get("id") or "").replace("#", "-")
        fid = f"mfc-{result_id}-{sid}"
        if R.findings.get(fid):
            made.append(fid); continue
        tr = sub.get("tool_trace") or {}
        sev = _sev(tr.get("severity") or "warning")
        _obj = str(item.get("object_id") or "")
        _src = _source_trace_fields(tr)
        _fdoc = _doc(case_id, _obj) or {}
        _hit_msg = str(tr.get("message") or "")
        _missing = bool(_src["source_location_missing"] or not _src["source_locator"])
        _locator = ("decision_table:%s:row:%s" % (tr.get("code"), tr.get("row"))
                    if _missing else _src["source_locator"])
        _quote = _hit_msg if _missing else _src["source_quote"]
        # 引文逐字命中 + 归属校验（单元格/对象原文），不命中则降级人工复核
        _gate = {"passed": False, "reason": "quote_missing", "quote": str(_quote or "")[:200]}
        if _missing:
            # T-136 C-5：关系类证据必须有对象端锚点（原文/单元格坐标）才算复核成立；
            # 定位缺失 = 证据不完整 → 降级 insufficient/need_evidence 转人工，
            # 不再把“找不到原文”当作 fail 依据出闸。定位缺失原因/解析完整性仍显式记录，
            # 报告与台账继续显示“原文定位缺失”。
            _parse_status = str((_fdoc or {}).get("parse_status") or "").strip().lower() or "unknown"
            _parse_gap = _parse_status in ("partial", "failed", "error", "parse_failed",
                                           "truncated", "incomplete")
            _presence = {"found": False, "search_scope": "document",
                         "source_reason": str(_src.get("source_reason") or "not_found"),
                         "two_ended": False,
                         "missing_anchors": ["object_anchor"],
                         "parse_completeness": {"parsed": not _parse_gap,
                                                "chars": 0,
                                                "parse_status": _parse_status,
                                                "parse_incomplete": _parse_gap,
                                                "source": "document.parse_status"}}
            _gate = {"passed": False, "reason": "relation_source_anchor_missing",
                     "evidence_type": "relation", "presence": _presence,
                     "detail": "关系类证据对象端锚点缺失（原文/单元格定位不到），"
                               "不能作为违规出闸；转人工补证/复核原文",
                     "quote": str(_quote or "")[:200]}
        elif _quote:
            try:
                _text, _parsed, _err = (_parse_document_cached(_fdoc, _parse_cache_bk)
                                        if _fdoc else ("", None, ""))
                _sheet = _norm_sheet(_src.get("source_sheet") or "")
                _got = _verify_quote_in_object(
                    _quote, text=_text, parsed=_parsed,
                    path=str(_fdoc.get("path") or ""), doc=_fdoc, sheet=_sheet)
                if _got.get("ok"):
                    _m = _QUOTE_CELL_RE.match(_locator)
                    if _m and _is_spreadsheet(_fdoc) and _src.get("source_quote"):
                        if _cell_quote_hit(str(_fdoc.get("path") or ""), _m.group(1),
                                           _m.group(3), _m.group(2), _src["source_quote"]):
                            _gate = {"passed": True, "reason": "quote_verbatim_in_cell",
                                     "locator": _locator,
                                     "quote": str(_src.get("source_quote") or "")[:200]}
                        else:
                            _gate = {"passed": False, "reason": "quote_cell_mismatch",
                                     "locator": _locator,
                                     "quote": str(_src.get("source_quote") or "")[:200]}
                    else:
                        _gate = {"passed": True, "reason": "quote_verbatim_in_source",
                                 "locator": _got.get("locator") or _locator,
                                 "quote": str(_quote or "")[:200]}
                else:
                    _gate = {"passed": False,
                             "reason": _got.get("reason") or "quote_not_found",
                             "locator": _locator, "quote": str(_quote or "")[:200]}
            except Exception:
                logging.getLogger(__name__).debug("collect quote gate skipped", exc_info=True)
        _failed = not _gate.get("passed")
        # A10：证据驱动。collect 的“fail”只完成了逐字引文命中（没有 computation/
        # relation 最小可复核集），因此 certainty=probable、confidence=核验强度分；
        # 证据门禁未通过 → abstain。修前写 deterministic/1.0 属同字段第二套来源。
        _eg_cert = evidence_grade(quote_verified=bool(_gate.get("passed")),
                                  evidence_ok=bool(_gate.get("passed")))
        _summary = str(sub.get("detail") or "")
        if _failed:
            _summary = (_summary + "；" if _summary else "") + _QUOTE_GATE_DETAIL
        # L71 P2a：落库前证据回填（source_locator/source_quote → verbatim_quote/char span）
        _bk_anchor = {}
        _bk_text, _bk_parsed = "", None
        _bk_fname = str((_fdoc or {}).get("filename") or "")
        _bk_state = {"state": ("insufficient" if _failed else "fail"),
                     "status": ("need_evidence" if _failed else "pending"),
                     "downgraded": False, "reason": "", "quote": ""}
        try:
            from . import auditpoints as _ap_bk
            if ((_ap_bk.evidence_backfill_enabled() or _ap_bk.finding_include_quote())
                    and _fdoc):
                _bk_text, _bk_parsed, _bk_err = _parse_document_cached(
                    _fdoc, _parse_cache_bk)
                _bk_locs = [{
                    "sheet": _src.get("source_sheet") or "",
                    "row": _src.get("source_row"),
                    "col": _src.get("source_col") or "",
                    "locator": _src.get("source_locator") or "",
                    "quote": _src.get("source_quote") or "",
                }]
                # L166：传 L154 结构 IR（xlsx 单元格坐标）+ 文件名（文本类 char span 定位文本），
                # 使 collect/D4 子要求 finding 的 anchor 也能落 Sheet!Cell / 第N段·字符a-b。
                _bk_anchor = _ap_bk.attach_finding_quote_fields(
                    {"quote": _quote or "", "code": str(item.get("code") or ""),
                     "object_id": _obj, "title": _hit_msg,
                     "description": str(sub.get("detail") or "")},
                    str(_bk_text or ""), locations=_bk_locs,
                    doc_path=str(_fdoc.get("path") or ""),
                    filename=_bk_fname, doc_parsed=_bk_parsed)
                _bk_state = _ap_bk.insert_state_for_backfill(
                    _bk_anchor,
                    state=("insufficient" if _failed else "fail"),
                    status=("need_evidence" if _failed else "pending"))
        except Exception:  # 铁律 2：回填异常留痕，不阻断 finding 物化
            logging.getLogger(__name__).warning(
                "collect evidence backfill failed row=%s", tr.get("row"), exc_info=True)
            _bk_anchor = {}
        _bk_cols = {}
        if _bk_anchor:
            try:
                from . import auditpoints as _ap_bk2
                if str(_bk_anchor.get("verbatim_quote") or ""):
                    _bk_cols = {
                        "verbatim_quote": str(_bk_anchor.get("verbatim_quote") or ""),
                        "char_start": int(_bk_anchor.get("char_start", -1)),
                        "char_end": int(_bk_anchor.get("char_end", -1)),
                        "anchor_mode": str(_bk_anchor.get("anchor_mode") or "unanchored"),
                        "issue_identity": str(_bk_anchor.get("issue_identity") or ""),
                    }
                _bk_cols.update(_ap_bk2.evidence_write_columns(_bk_anchor))
            except Exception:
                logging.getLogger(__name__).debug("collect backfill columns skipped",
                                                  exc_info=True)
        R.findings.insert(id=fid, case_id=case_id, rule_id=str(item.get("code") or ""),
                          rule_version=str(tr.get("version") or ""), severity=sev,
                          certainty=_eg_cert["certainty"],
                          confidence=_eg_cert["confidence"],
                          state=str(_bk_state.get("state") or ("insufficient" if _failed else "fail")),
                          status=str(_bk_state.get("status") or ("need_evidence" if _failed else "pending")),
                          title=_hit_msg or "决策表命中", summary=_summary,
                          suggestion="", grade="",
                          engine=("manifest:decision_table:evidence_gate" if _failed
                                  else "manifest:decision_table"),
                          run_id=run_id, object_id=_obj, manifest_result_id=result_id,
                          subrequirement_id=sid, **_bk_cols)
        if _obj:
            _aid = f"anc-{fid}"; _eid = f"ev-{fid}"
            try:
                if not R.anchors.get(_aid):
                    # L166：优先显式 source 坐标；缺失时用回填结果（xlsx IR -> Sheet!Cell /
                    # 文本 char span），最后才退回 locator 兜底，避免 anchor 只剩文件名。
                    _anc_sheet = "" if _missing else _src["source_sheet"]
                    _anc_row = 0 if _missing else int(_src["source_row"] or 0)
                    _anc_col = "" if _missing else _src["source_col"]
                    _anc_locator = _locator
                    _anc_quote = _quote
                    _acols = {}
                    if _bk_anchor and not _missing:
                        try:
                            from . import auditpoints as _ap_bk3
                            _acols = _ap_bk3.anchor_write_columns(
                                _bk_anchor, finding=_bk_anchor, doc_text=_bk_text,
                                filename=_bk_fname)
                        except Exception:
                            logging.getLogger(__name__).debug(
                                "collect anchor cols skipped", exc_info=True)
                    if _acols:
                        _anc_quote = str(_acols.get("quote") or _anc_quote)
                        if not (_anc_sheet and _anc_row and _anc_col):
                            _anc_sheet = str(_acols.get("sheet") or _anc_sheet or "")
                            _anc_row = (_acols.get("row") if _acols.get("row") is not None
                                        else _anc_row)
                            _anc_col = str(_acols.get("col") or _anc_col or "")
                        _anc_locator = str(_acols.get("locator") or _anc_locator)
                    R.anchors.insert(id=_aid, document_id=_obj,
                                     sheet=_anc_sheet, row=_anc_row, col=_anc_col,
                                     locator=_anc_locator, quote=_anc_quote,
                                     hash=hashlib.sha256(str(_anc_quote).encode()).hexdigest()[:16])
                if not R.evidences.get(_eid):
                    _label = f"决策表 {tr.get('code')} 第{tr.get('row')}行"
                    _label += (" · 原文定位缺失" if _missing else f" · 原文 {_locator}")
                    if _failed:
                        _label += " · 引文未逐字命中，转人工"
                    R.evidences.insert(id=_eid, finding_id=fid, document_id=_obj, anchor_id=_aid,
                                       excerpt=_quote, label=_label)
            except Exception:
                logging.getLogger(__name__).debug("collect anchor skipped", exc_info=True)
        try:
            # T-161 三区分层：影子空间标记（只读标记，不删 finding、不改结论）。
            # 收集行证据门禁失败 = 不可锚定/待人工核 → 影子空间，报告只展示、不计通过率分母。
            _zone_reasons = []
            try:
                from . import audit_zone as _az_mark
                if _az_mark.tagging_enabled():
                    _zone_reasons = _az_mark.shadow_reasons(
                        {"id": fid,
                         "status": ("need_evidence" if _failed else "pending"),
                         "state": ("insufficient" if _failed else "fail")},
                        item=item,
                        evidence_rows=[{"quote": _quote, "locator": _locator}])
            except Exception:
                logging.getLogger(__name__).debug("shadow zone mark skipped", exc_info=True)
            R.audit_logs.log(actor="system", action="evidence.quote_gate", object=fid,
                             after=json.dumps({"passed": bool(_gate.get("passed")),
                                               "reason": _gate.get("reason"),
                                               "locator": _locator,
                                               # 影子空间标记：有原因 = 进影子空间（只标记）
                                               "zone": ("shadow" if _zone_reasons else ""),
                                               "zone_reasons": _zone_reasons[:3]},
                                              ensure_ascii=False)[:300])
        except Exception:
            logging.getLogger(__name__).debug("collect quote gate log skipped", exc_info=True)
        made.append(fid)
    return made


# ---------------- 同码多实例（2026-11-23，multi-instance）----------------
# 背景（docs/qa/CT进了清单也不判_20261123.md §2.2/§6.5）：manifest 每个「文档 × 规则码」
# 只有 1 个 item / 1 个 D4 子要求 → 物化 1 条 finding，而 gold 同码常 9–11 条；
# CT 810 FN 中 570 条（70.4%）卡在「同码单实例上限」。
# 本段在 D4 子要求成型后、证据门禁之前，为白名单码追加**独立违规实例**子要求；
# 开关 RULEPROOF_MULTI_INSTANCE（2026-11-23 起默认 1；=0 回滚）：关闭时本函数原样返回，逐字段不变。
_MULTI_INSTANCE_ENV = "RULEPROOF_MULTI_INSTANCE"


def multi_instance_enabled() -> bool:
    return ruleexec.multi_instance_enabled()


def _log_multi_instance_audit(case_id: str, code: str, payload: dict) -> None:
    """多实例审计（不静默：新增/截断/拒绝都留痕；失败不阻断主链）。"""
    try:
        R.audit_logs.log(actor="system", action="multi_instance.materialize",
                         object=f"{case_id}|{code}",
                         after=json.dumps(payload, ensure_ascii=False)[:400])
    except Exception:
        logging.getLogger(__name__).debug("multi-instance audit skipped", exc_info=True)


def _log_multi_instance_truncated(case_id: str, code: str, payload: dict) -> None:
    """A 类缺陷修复（2026-11-23）：确定性 MI 生成器 cap 处静默截断 → 单独写截断审计。

    背景：``judge_cross_ref_rule_all`` 在 cap 处直接 break，调用方看到的 truncated
    恒为 0（假象）。现由生成器把「被丢弃候选数 + quote 摘要」回传，本函数写
    ``multi_instance.truncated``（含 case/code/上限/丢弃数/摘要），行为不变、只加审计。
    """
    try:
        R.audit_logs.log(actor="system", action="multi_instance.truncated",
                         object=f"{case_id}|{code}",
                         after=json.dumps(payload, ensure_ascii=False)[:500])
    except Exception:
        logging.getLogger(__name__).debug("multi-instance truncated audit skipped",
                                          exc_info=True)


def _mi_split_span_enabled() -> bool:
    """M1 开关：跨实例 base 引文拆分（``RULEPROOF_MI_SPLIT_SPAN``，默认 1；=0 完全回退旧行为）。

    背景（docs/qa/M臂与招采routing_20261123.md §2.5）：``judge_cross_ref_rule`` 的 base
    引文是「锚点片段 ±60/±120 字」的上下文窗口，同一行里常横跨 ≥2 个独立实例；旧实现
    按 span 重叠把窗口内的其他实例全部跳过 → 一条 finding 吞掉多个金标实例（A1/A2）。
    本开关=1 时：把 base 引文收窄到锚点实例的原文紧切片，再把其余独立实例物化。
    """
    try:
        return str(os.environ.get("RULEPROOF_MI_SPLIT_SPAN", "1")).strip().lower() not in (
            "0", "false", "no", "off")
    except Exception:
        return True


def _mi_materialize_limit() -> int:
    """每 (doc, code) 实例上限：``RULEPROOF_MI_LIMIT``（默认回退 ruleexec 的 5）。

    M2：上限语义按「实例数」计（见 ``_apply_multi_instance_subs``），默认仍 5；
    ``RULEPROOF_MULTI_INSTANCE_LIMIT`` 仍由 ruleexec 兼容读取（本函数默认值来自它）。
    """
    try:
        n = int(ruleexec.multi_instance_limit())
    except Exception:
        n = 5
    raw = os.environ.get("RULEPROOF_MI_LIMIT")
    if raw is not None and str(raw).strip() != "":
        try:
            n = int(float(str(raw).strip()))
        except (TypeError, ValueError):
            logging.getLogger(__name__).warning(
                "RULEPROOF_MI_LIMIT 非法（%r），回退默认 %s", raw, n)
    return max(1, min(int(n), 20))


# ---------------- 多实例可观测（2026-11-24，L78 / 90 号 §二-6）----------------
# 背景（外部评审缺口 #6 / 红队 #7；L67 §5/§9.2）：旧实现有两处「不静默」缺口：
#   ① 语义/跨引用多实例展开时，若 ``sub_out`` 中无既有 fail/insufficient（首个 pass /
#      无引文 insufficient），即使 ``judge_cross_ref_rule_all`` 检出确定性违规也直接
#      ``return sub_out``（只写 ``reason=no_base_fail`` 审计）→ 单点漏判放大成规则级 FN；
#   ② cap 截断只在审计里，point_state/run 返回/报告/台账看不到「已检出 N 处、仅展示前 K」。
# 两个开关（均默认 1；=0 回退旧口径，逐字节）：``RULEPROOF_MI_NO_BASE_FAIL_FIX``（无 base
# fail 时独立物化确定性违规）与 ``RULEPROOF_MI_TRUNCATION_VISIBLE``（cap 截断可观测）。
_MI_NO_BASE_FAIL_ENV = "RULEPROOF_MI_NO_BASE_FAIL_FIX"
_MI_TRUNCATION_VISIBLE_ENV = "RULEPROOF_MI_TRUNCATION_VISIBLE"


def mi_no_base_fail_enabled() -> bool:
    """L78 开关：无 base fail（首个 pass / 无引文 insufficient）时也独立物化确定性违规。

    默认 1（开）；=0 → 回到旧行为：只写 ``multi_instance.materialize`` 审计
    （``reason=no_base_fail``）并原样返回，不追加任何实例子要求/finding。
    开启时新增实例子要求仍走调用方既有 ``_apply_fail_quote_gate``（fail-closed：
    引文不逐字命中 → 降 insufficient 转人工，不得静默 pass）。
    """
    try:
        return str(os.environ.get("RULEPROOF_MI_NO_BASE_FAIL_FIX", "1")).strip().lower() not in (
            "0", "false", "no", "off")
    except Exception:  # 铁律 2：开关读取失败按默认开处理并留痕
        logging.getLogger(__name__).warning(
            "multi-instance no-base-fail switch read failed（按默认开处理）", exc_info=True)
        return True


def mi_truncation_visible() -> bool:
    """L78 开关：MI cap 截断可观测（默认 1；=0 不落 d5.multi_instance/point_state MI 列/提示）。"""
    try:
        return str(os.environ.get("RULEPROOF_MI_TRUNCATION_VISIBLE", "1")).strip().lower() not in (
            "0", "false", "no", "off")
    except Exception:  # 铁律 2：开关读取失败按默认开处理并留痕
        logging.getLogger(__name__).warning(
            "multi-instance truncation-visible switch read failed（按默认开处理）", exc_info=True)
        return True


def _mi_stats_payload(*, code: str, item: dict, cap: int, dets: int,
                      discarded: int, budget_exhausted: bool, fail_idx: int,
                      base_count: int, added: int, rejected: list,
                      no_base: bool, materialized_no_base: int,
                      split_span: bool, cap_cut: int = 0) -> dict:
    """MI cap 可观测字段（字段名与 L67 §9.2「实例级导出 lane」约定一致）。

    口径（三处落点统一：manifest item ``d5.multi_instance`` / point_state 行 /
    run 汇总）：
      generated_count = 生成器「检出」的独立违规数 = 已返回 dets + 生成器 cap 丢弃候选；
      kept_count      = 实际保留并进入 finding 的实例数 = 既有 base 实例 + 本次新增；
      cap_truncated   = 因 **cap** 未物化（生成器 cap 丢弃 / M2 上限/实例数上限截断）；
                        报告/台账必须提示人工复核（引文门禁拒绝只计 rejected，不算 cap 截断）；
      limit/max_instances = 每 (doc, code) 上限；budget_exhausted = 生成器扫描到安全上限。
    """
    generated = max(0, int(dets) + int(discarded))
    kept = max(0, int(base_count) + int(added))
    if generated < kept:
        generated = kept
    return {
        "enabled": 1,
        "rule": str(code or ""),
        "object_id": str((item or {}).get("object_id") or ""),
        "source": "ruleexec.judge_cross_ref_rule_all",
        "generated_count": generated,
        "kept_count": kept,
        "cap_truncated": bool(int(discarded) > 0 or int(cap_cut) > 0),
        "limit": int(cap),
        "max_instances": int(cap),
        "budget_exhausted": bool(budget_exhausted),
        "discarded_candidates": max(0, int(discarded)),
        "cap_cut": max(0, int(cap_cut)),
        "added": max(0, int(added)),
        "existing_fail": max(0, int(fail_idx)),
        "known_instances": max(0, int(base_count)),
        "materialized_no_base": max(0, int(materialized_no_base)),
        "no_base_fail": bool(no_base),
        "split_span": bool(split_span),
        "rejected": list(rejected or [])[:5],
        "rejected_count": len(rejected or []),
        "source_of_truth": "manifest_exec._apply_multi_instance_subs",
    }


def _mi_attach_stats(item: dict, stats: dict) -> None:
    """把 MI 可观测统计挂到 manifest item（私有键；_run_core 收进 d5.multi_instance）。

    =0（RULEPROOF_MI_TRUNCATION_VISIBLE）时不挂 → d5/point_state/run 返回逐字段旧口径。
    """
    if not mi_truncation_visible():
        return
    if not isinstance(item, dict) or not isinstance(stats, dict):
        return
    item["_mi_stats"] = stats


def _mi_build_sub(*, base_sid: str, idx: int, quote: str, detail: str, det: dict,
                  cap: int, item: dict, no_base: bool = False) -> dict:
    """构造一条 MI 实例子要求（fail；由调用方既有引文门禁二次兜底，不裸报）。"""
    sp = list(det.get("instance_span") or [])
    new_sub = {
        "id": f"{base_sid}#MI{idx}",
        "status": "fail",
        "raw_state": "multi_instance",
        "raw_item": {},
        "detail": str(detail or ""),
        "quote": str(quote or ""),
        "evidence_ok": True,
        "instance": {"index": idx, "source": "ruleexec.judge_cross_ref_rule_all",
                     "det_rule": det.get("rule") or "",
                     "operands": det.get("operands") or [],
                     "recompute": det.get("recompute") or "",
                     "span": sp, "limit": cap},
        "tool_trace": {"executor": "ruleexec.multi_instance",
                       "det_rule": det.get("rule") or "", "result": "fail",
                       "instance_index": idx, "limit": cap,
                       "quote": str(quote or ""),
                       "operands": det.get("operands") or [],
                       "recompute": det.get("recompute") or "",
                       "detail": str(detail or "")},
    }
    if no_base:
        # L78 留痕：该实例来自「无 base fail」独立物化（便于报告/导出区分来源）
        new_sub["instance"]["no_base_fail"] = True
        new_sub["instance"]["materialized_mode"] = "no_base_fail"
        new_sub["tool_trace"]["no_base_fail"] = True
    if isinstance((item or {}).get("_rule_sheet"), str) and item.get("_rule_sheet"):
        new_sub["tool_trace"]["sheet"] = item["_rule_sheet"]
    return new_sub


def _apply_multi_instance_subs(item: dict, text: str, sub_out: list,
                               *, case_id: str = "", code: str = "") -> list:
    """RULEPROOF_MULTI_INSTANCE=1：同一 (doc, code) 追加独立违规实例子要求。

    规则：
      ① 实例 = ruleexec.judge_cross_ref_rule_all 产出的确定性违规（quote 为原文紧切片）；
      ② M1（``RULEPROOF_MI_SPLIT_SPAN``，默认 1）：既有 fail 子要求的 base 引文若是
         「锚点 ± 上下文」窗口且横跨 ≥2 个独立实例，先收窄到锚点实例原文紧切片
         （``quote_split_from`` 留痕），窗口内其余实例不再因 span 重叠被跳过；
         开关=0 → 逐字段回退旧行为（重叠即跳过）；
      ③ M2：每 (doc, code) 上限按**实例数**计（同一实例的多条已有子要求只计 1 个），
         上限 ``RULEPROOF_MI_LIMIT``（默认 5）；超出写审计并截断，不静默；
         生成器内部 cap 截断另写 ``multi_instance.truncated``；
      ④ 新增子要求仍必须通过调用方既有的引文门禁（_apply_fail_quote_gate）；
      ⑤ L78（``RULEPROOF_MI_NO_BASE_FAIL_FIX``，默认 1）：**无 base fail**（首个 pass /
         无引文 insufficient）时，确定性违规也独立物化（fail 经引文门禁；门禁不过 →
         insufficient 转人工，不得静默 pass）；审计 ``multi_instance.no_base_materialized``
         留痕（rule/object/instances/limit）。=0 → 旧 no_base_fail 只审计并返回。
    关闭总开关 → 返回入参本身（逐字段不变）。
    """
    if not multi_instance_enabled():
        return sub_out
    try:
        body = str(text or "")
        code = str(code or item.get("code") or "")
        if not body or not code:
            return sub_out
        cap = _mi_materialize_limit()
        split_span = _mi_split_span_enabled()
        _trunc_sink: list = []
        dets = ruleexec.judge_cross_ref_rule_all(code, body, limit=cap,
                                                 truncation_sink=_trunc_sink)
        for _t in _trunc_sink:
            _log_multi_instance_truncated(case_id, code, _t)
        # L78：生成器 cap 截断候选数（报告「已检出 N 处」的 N 必须含被 cap 丢弃的候选）
        _discarded = sum(int((_t or {}).get("discarded_candidates") or 0)
                         for _t in _trunc_sink)
        _budget_exhausted = any(bool((_t or {}).get("scan_limit_reached"))
                                for _t in _trunc_sink)
        if not dets:
            return sub_out
        # 既有 fail/insufficient 子要求 = base 判定来源
        fail_idx, base_sid = [], "S1"
        for _i, _s in enumerate(sub_out or []):
            if (str((_s or {}).get("status") or "") in ("fail", "insufficient")
                    and str((_s or {}).get("quote") or "")):
                fail_idx.append(_i)
                _sid0 = str((_s or {}).get("id") or "")
                if _sid0 and base_sid == "S1":
                    base_sid = _sid0.split("#", 1)[0] or base_sid
        if not fail_idx:
            # ---- L78：无 base fail → 旧口径只审计并返回（=0）；默认独立物化（不得静默 pass）----
            if not mi_no_base_fail_enabled():
                _log_multi_instance_audit(case_id, code,
                                          {"added": 0, "existing_fail": 0,
                                           "instances": len(dets), "reason": "no_base_fail",
                                           "limit": cap, "split_span": split_span})
                return sub_out
            for _s in (sub_out or []):
                _sid0 = str((_s or {}).get("id") or "")
                if _sid0:
                    base_sid = _sid0.split("#", 1)[0] or "S1"
                    break
            no_base_added, no_base_rejected, no_base_spans = [], [], []
            no_base_cap_cut = 0
            for d in dets:
                q = str(d.get("quote") or "")
                if not q or q not in body:
                    no_base_rejected.append("quote_not_verbatim")
                    continue
                sp = d.get("instance_span") or []
                if len(sp) == 2 and any(sp[0] < e and s < sp[1]
                                        for (s, e) in no_base_spans):
                    no_base_rejected.append("same_instance_span")
                    continue
                if len(no_base_added) >= cap:
                    no_base_cap_cut += 1
                    continue
                new_sub = _mi_build_sub(base_sid=base_sid, idx=len(no_base_added) + 1,
                                        quote=q, detail=d.get("detail"),
                                        det=d, cap=cap, item=item, no_base=True)
                sub_out.append(new_sub)
                no_base_added.append(new_sub)
                if len(sp) == 2:
                    no_base_spans.append((sp[0], sp[1]))
            stats = _mi_stats_payload(
                code=code, item=item, cap=cap, dets=len(dets),
                discarded=_discarded, budget_exhausted=_budget_exhausted,
                fail_idx=0, base_count=0, added=len(no_base_added),
                rejected=no_base_rejected, no_base=True,
                materialized_no_base=len(no_base_added), split_span=split_span,
                cap_cut=no_base_cap_cut)
            _mi_attach_stats(item, stats)
            # L78 审计：无 base fail 独立物化（不静默；含 rule/object/instances/limit）
            try:
                R.audit_logs.log(actor="system",
                                 action="multi_instance.no_base_materialized",
                                 object=f"{case_id}|{code}",
                                 after=json.dumps(
                                     {"rule": code,
                                      "object": str(item.get("object_id") or ""),
                                      "instances": stats["generated_count"],
                                      "generator_returned": len(dets),
                                      "limit": cap,
                                      "added": len(no_base_added),
                                      "generated_count": stats["generated_count"],
                                      "kept_count": stats["kept_count"],
                                      "cap_truncated": stats["cap_truncated"],
                                      "discarded_candidates": _discarded,
                                      "gate": "pending_fail_quote_gate",
                                      "source": "ruleexec.judge_cross_ref_rule_all"},
                                     ensure_ascii=False)[:400])
            except Exception:  # 铁律 2：审计写失败留痕，不阻断物化
                logging.getLogger(__name__).warning(
                    "multi_instance.no_base_materialized audit skipped（不阻断主链）",
                    exc_info=True)
            return sub_out
        # ---- M1：跨实例 base 引文拆分（收窄到锚点实例，其余实例继续物化）----
        anchor_dets, narrowed = set(), []
        if split_span:
            for _i in fail_idx:
                _s = sub_out[_i]
                _oldq = str(_s.get("quote") or "")
                _spans = ruleexec._mi_offsets(body, _oldq)
                inside = [di for di, _d in enumerate(dets)
                          if len(_d.get("instance_span") or []) == 2 and any(
                              _d["instance_span"][0] < e and s < _d["instance_span"][1]
                              for (s, e) in _spans)]
                if len(inside) < 2:
                    continue
                _free = [di for di in inside if di not in anchor_dets]
                if not _free:
                    continue
                _anchor = _free[0]
                _newq = str(dets[_anchor].get("quote") or "")
                anchor_dets.add(_anchor)
                if not _newq or _newq not in body or _newq == _oldq:
                    continue
                _s["quote"] = _newq
                _s["quote_split_from"] = _oldq[:120]
                narrowed.append({"sub": str(_s.get("id") or ""),
                                 "before_chars": len(_oldq),
                                 "after_chars": len(_newq),
                                 "anchor_det": _anchor})
        # ---- M2：cap 按「实例数」计（同一实例的多条既有子要求只计 1）----
        known_spans, known_norm, known_instances = [], [], 0
        for _i in fail_idx:
            _q = str(sub_out[_i].get("quote") or "")
            if not _q:
                continue
            _nq = ruleexec._p01_norm(_q)
            _same = any(_nq and _x and (_nq in _x or _x in _nq) for _x in known_norm)
            if not _same:
                known_instances += 1
                if _nq:
                    known_norm.append(_nq)
            known_spans.extend(ruleexec._mi_offsets(body, _q))
        base_count = known_instances if split_span else len(fail_idx)
        if base_count >= cap:
            _log_multi_instance_audit(case_id, code,
                                      {"added": 0, "existing_fail": len(fail_idx),
                                       "known_instances": known_instances,
                                       "truncated": len(dets), "reason": "limit_reached",
                                       "limit": cap, "split_span": split_span})
            _mi_attach_stats(item, _mi_stats_payload(
                code=code, item=item, cap=cap, dets=len(dets),
                discarded=_discarded, budget_exhausted=_budget_exhausted,
                fail_idx=len(fail_idx), base_count=base_count, added=0,
                rejected=[], no_base=False, materialized_no_base=0,
                split_span=split_span))
            return sub_out
        added, truncated, rejected = [], 0, []
        for di, d in enumerate(dets):
            sp = d.get("instance_span") or []
            if split_span and di in anchor_dets:
                continue                      # 该实例已由（收窄后的）base 子要求承载
            if len(sp) == 2 and any(sp[0] < e and s < sp[1] for (s, e) in known_spans):
                if split_span:
                    rejected.append("same_instance_span")
                continue                      # 同一实例已被既有子要求覆盖（幂等）
            if base_count + len(added) >= cap:
                truncated += 1
                continue
            q = str(d.get("quote") or "")
            if not q or q not in body:
                rejected.append("quote_not_verbatim")
                continue
            new_sub = _mi_build_sub(base_sid=base_sid, idx=len(added) + 1,
                                    quote=q, detail=d.get("detail"),
                                    det=d, cap=cap, item=item, no_base=False)
            sub_out.append(new_sub)
            added.append(new_sub)
            if len(sp) == 2:
                known_spans.append((sp[0], sp[1]))
        stats = _mi_stats_payload(
            code=code, item=item, cap=cap, dets=len(dets),
            discarded=_discarded, budget_exhausted=_budget_exhausted,
            fail_idx=len(fail_idx), base_count=base_count, added=len(added),
            rejected=rejected, no_base=False, materialized_no_base=0,
            split_span=split_span, cap_cut=truncated)
        _mi_attach_stats(item, stats)
        _log_multi_instance_audit(case_id, code,
                                  {"added": len(added), "existing_fail": len(fail_idx),
                                   "known_instances": known_instances,
                                   "instances": len(dets), "truncated": truncated,
                                   "generated_count": stats["generated_count"],
                                   "kept_count": stats["kept_count"],
                                   "cap_truncated": stats["cap_truncated"],
                                   "rejected": rejected[:5], "limit": cap,
                                   "split_span": split_span,
                                   "split_narrowed": narrowed[:5],
                                   "det_rules": sorted({str(x.get("rule") or "")
                                                        for x in added})})
        return sub_out
    except Exception:  # 铁律 2：异常必须留痕；多实例失败不得阻断主链（原样返回）
        logging.getLogger(__name__).warning(
            "multi-instance expand failed（原样返回单实例）code=%s", code, exc_info=True)
        return sub_out


# ---------------- 语义码同码多实例（2026-11-23，RULEPROOF_SEMANTIC_MULTI_INSTANCE）----------------
# 背景：上面的 _apply_multi_instance_subs 只对确定性算子白名单码生效；CT 810 条 FN 里
# 语义码 deficit 245 条（D05-002 148 / G01-003 29 / G01-002 15 / G02-002 15 …）、
# P01 60 条（D02-001 25 / F02-006 8 …）仍只能出 1 条 finding（docs/qa/语义码多实例_20261123.md §1）。
# 本段在 D4 子要求成型后、证据门禁之前，对**已判 fail 的语义码**触发一次实例抽取调用
# （auditpoints.extract_violation_instances），把模型找出且通过实例判据的逐字引文追加为
# S1#MI* fail 子要求；物化/去重沿用既有 _multi_instance_batches（project.py 实例身份已参与去重键）。
# 开关 RULEPROOF_SEMANTIC_MULTI_INSTANCE（默认 0）：关闭时本函数不读模型、原样返回，零行为变化。
_SEMANTIC_MI_ENV = "RULEPROOF_SEMANTIC_MULTI_INSTANCE"
_SEMANTIC_MI_MAX_CALLS_ENV = "RULEPROOF_SEMANTIC_MI_MAX_CALLS_PER_DOC"
_SEMANTIC_MI_MAX_CALLS_DEFAULT = 6      # 每 (case, 文档) 实例抽取调用上限（成本闸门；0=不限制）
_SEMANTIC_MI_CODES_ENV = "RULEPROOF_SEMANTIC_MI_CODES"  # 可选语义码白名单（逗号分隔；空=全部语义码）
_SEMANTIC_MI_EXECUTOR = "agent-judge.semantic_multi_instance"
_SEMANTIC_MI_CALLS: dict = {}           # (case_id, object_id) -> 已调用次数（进程内；防成本爆炸）


def semantic_multi_instance_enabled() -> bool:
    """语义码多实例开关：总开关 RULEPROOF_MULTI_INSTANCE 与分项开关同时为 1 才生效。

    分项默认 0（每次实例抽取=一次额外全文档模型调用，成本上升）；
    两个开关任一关闭 → D4 不追加任何语义实例子要求（零行为变化）。
    """
    if not multi_instance_enabled():
        return False
    try:
        from . import auditpoints as _ap
        return _ap.semantic_multi_instance_enabled()
    except Exception:  # noqa: BLE001 - 开关读取失败按关闭处理
        logging.getLogger(__name__).warning(
            "semantic multi-instance switch read failed（按关闭处理）", exc_info=True)
        return False


def _semantic_mi_code_allowed(code: str) -> bool:
    """可选的语义码白名单（RULEPROOF_SEMANTIC_MI_CODES；空=全部语义码）。

    依据（docs/qa/语义码多实例_20261123.md §4）：10 份 CT 真实 A/B 新增 finding 的
    TP 率 76.6%（D05-002 32TP/42、A04-003 3TP/4），而 P01 10 份仅 5.2%（FP +129）
    → 生产开时建议用白名单限定到「同码多实例证据确凿」的码，避免在单实例码上造 FP。
    """
    # 2026-11-23：默认白名单 = D05-002（唯一经真实 A/B 验证精度 ≥70% 的语义码；
    # CT 44 份新增 48 条中 TP 37=77.1%）。其余码（G01-003/G01-002/G02-002）实测精度 8–28%，
    # 默认不开；需要时显式 RULEPROOF_SEMANTIC_MI_CODES 覆盖（逗号分隔，空串=全部语义码）。
    raw = str(os.environ.get(_SEMANTIC_MI_CODES_ENV, "D05-002") or "").strip()
    if raw == "*":
        return True
    allow = {x.strip() for x in raw.split(",") if x.strip()}
    return str(code or "").strip() in allow


def _semantic_mi_calls_limit() -> int:
    """每文档实例抽取调用上限：默认 6，0=不限制（成本闸门；截断写审计不静默）。"""
    try:
        return max(0, int(os.environ.get(_SEMANTIC_MI_MAX_CALLS_ENV,
                                         str(_SEMANTIC_MI_MAX_CALLS_DEFAULT)) or 0))
    except Exception:
        return _SEMANTIC_MI_MAX_CALLS_DEFAULT


def _apply_semantic_multi_instance_subs(item: dict, rule: dict, sub: dict, text: str,
                                        sub_out: list, *, case_id: str = "",
                                        code: str = "") -> list:
    """对已判 fail 的语义码做实例抽取并追加 S1#MI* 子要求（只由 D4 调用）。

    规则与 fail-closed：
      ① 只展开「当前语义子要求 base fail 且引文非空」的码——不给 pass/na 造 fail；
      ② 确定性白名单码跳过（已由 _apply_multi_instance_subs 展开，不重复）；
      ③ 候选引文必须经 auditpoints 回填为原文逐字切片，再由 ruleexec.mi_accept_instances
         做实例判据（归一化互不包含 + span 不重叠 + 与既有引文不同实例 + ≤5 上限）；
      ④ 模型空返回/调用失败 → **不追加**，原单条结论原样保留（不丢原结论）；
      ⑤ 同一 item 已展开过语义实例 → 不再二次调用（幂等）；每文档调用数超上限 → 跳过并写审计；
      ⑥ 新子要求仍要过调用方既有 _apply_fail_quote_gate（引文门禁二次兜底）。
    关闭开关 → 返回入参本身（逐字段不变）。
    """
    if not semantic_multi_instance_enabled():
        return sub_out
    try:
        from . import auditpoints as _ap
        body = str(text or "")
        code = str(code or item.get("code") or "")
        if not body.strip() or not code:
            return sub_out
        if code in set(ruleexec._MI_ALL_CODES):
            return sub_out              # 确定性白名单：前一个函数已处理
        if not _semantic_mi_code_allowed(code):
            _log_multi_instance_audit(case_id, code, {
                "action": "semantic_extract", "added": 0,
                "reason": "code_not_in_whitelist", "codes_env": _SEMANTIC_MI_CODES_ENV})
            return sub_out
        subs = list(sub_out or [])
        if any(str(((s or {}).get("tool_trace") or {}).get("executor") or "")
               == _SEMANTIC_MI_EXECUTOR for s in subs):
            return sub_out              # 幂等：该 item 已展开过语义实例
        sid = str((sub or {}).get("id") or "S1")
        base_sid = sid.split("#", 1)[0] or "S1"
        base_fail = [s for s in subs
                     if str((s or {}).get("status") or "") == "fail"
                     and str((s or {}).get("quote") or "").strip()
                     and "#MI" not in str((s or {}).get("id") or "")]
        # 只展开「当前子要求自己已判 fail」的码（多子要求 item 不串用别人判据）
        if not base_fail or str((base_fail[0] or {}).get("id") or "") != sid:
            return sub_out
        cap = ruleexec.multi_instance_limit()
        existing_fail = sum(1 for s in subs
                            if str((s or {}).get("status") or "") == "fail")
        if existing_fail >= cap:
            _log_multi_instance_audit(case_id, code, {
                "action": "semantic_extract", "added": 0, "existing_fail": existing_fail,
                "reason": "limit_reached", "limit": cap})
            return sub_out
        # 每文档实例抽取调用上限（成本闸门；截断写审计）
        key = (str(case_id or ""), str(item.get("object_id") or ""))
        lim_calls = _semantic_mi_calls_limit()
        used = int(_SEMANTIC_MI_CALLS.get(key) or 0)
        if lim_calls and used >= lim_calls:
            _log_multi_instance_audit(case_id, code, {
                "action": "semantic_extract", "added": 0, "reason": "doc_call_cap",
                "calls_used": used, "calls_limit": lim_calls})
            return sub_out
        accepted = [{"quote": str((s or {}).get("quote") or "")}
                    for s in subs
                    if str((s or {}).get("quote") or "").strip()
                    and str((s or {}).get("status") or "") in ("fail", "insufficient")]
        _SEMANTIC_MI_CALLS[key] = used + 1
        res = _ap.extract_violation_instances(
            rule, sub, body, base_quote=str((base_fail[0] or {}).get("quote") or ""),
            limit=cap)
        cand = list(res.get("instances") or [])
        if not cand:
            _log_multi_instance_audit(case_id, code, {
                "action": "semantic_extract", "added": 0,
                "error": str(res.get("error") or "no_instances"),
                "candidates": int(res.get("candidates") or 0),
                "rejected": list(res.get("rejected") or [])[:5], "limit": cap})
            return sub_out
        acc = ruleexec.mi_accept_instances(body, cand, accepted=accepted, limit=cap)
        added = []
        for row in acc["accepted"]:
            q = str((row or {}).get("quote") or "")
            if not q or q not in body:
                continue                # 二次 fail-closed：非逐字一律不物化
            idx = len(added) + 1
            _why = str((row or {}).get("rationale") or "")[:300]
            new_sub = {
                "id": f"{base_sid}#MI{idx}",
                "status": "fail",
                "raw_state": "semantic_multi_instance",
                "raw_item": {},
                "detail": _why or "同码多实例（语义实例抽取）",
                "quote": q,
                "evidence_ok": True,
                "instance": {"index": idx, "source": "auditpoints.extract_violation_instances",
                             "point_id": str(res.get("point_id") or ""),
                             "span": [s for s in ruleexec._mi_offsets(body, q)][:1],
                             "limit": cap},
                "tool_trace": {"executor": _SEMANTIC_MI_EXECUTOR, "result": "fail",
                               "quote": q, "instance_index": idx, "limit": cap,
                               "point_id": str(res.get("point_id") or ""),
                               "detail": _why,
                               "repair": str((row or {}).get("repair") or "")},
            }
            subs.append(new_sub)
            added.append(new_sub)
        _log_multi_instance_audit(case_id, code, {
            "action": "semantic_extract", "added": len(added),
            "existing_fail": existing_fail, "candidates": int(res.get("candidates") or 0),
            "accepted": len(acc.get("accepted") or []),
            "rejected": list(acc.get("rejected") or [])[:5],
            "truncated": int(acc.get("truncated") or 0),
            "model_rejected": list(res.get("rejected") or [])[:5],
            "limit": cap, "call_index": used + 1})
        return subs
    except Exception:  # 铁律 2：异常必须留痕；语义多实例失败不得阻断主链（原样返回）
        logging.getLogger(__name__).warning(
            "semantic multi-instance expand failed（原样返回单实例）code=%s",
            code, exc_info=True)
        return sub_out


# ---------------- T-161 三区分层：影子空间标记（只读，不改判定/结论） ----------------
def shadow_zone(finding: dict, result: dict | None = None, item: dict | None = None,
                evidence_rows: list | None = None) -> dict:
    """影子空间标记：满足「不可复算 / 不可锚定 / 跨文档无法归属」任一 → zone=shadow。

    **只标记**：不删除 finding、不改 finding 状态/结论/置信度、不写库。
    与 ``audit_zone.shadow_reasons`` 同一口径；RULEPROOF_ZONE_TAGGING=0 时恒返回空标记。
    """
    from . import audit_zone as _az
    if not _az.tagging_enabled():
        return {"zone": "", "reasons": [], "switch": False,
                "note": f"{_az.ENV_TAGGING}=0：影子空间标记关闭"}
    reasons = _az.shadow_reasons(finding, result=result, item=item,
                                 evidence_rows=evidence_rows)
    return {"zone": _az.ZONE_SHADOW if reasons else "", "reasons": reasons,
            "switch": True,
            "note": "进影子空间 = 只展示、不结论、不计通过率；人工裁决后回流" if reasons else ""}


def finding_zone_tags(case_id: str) -> dict:
    """case 内全部 finding 的三区标记（只读；报告与 QA 脚本共用 audit_zone 单一口径）。

    返回 ``audit_zone.classify_case_findings`` 的结构：``counts`` / ``total`` /
    ``findings``（每条带 zone / base_zone / shadow_reasons）。三区计数之和恒等于 total。
    """
    from . import audit_zone as _az
    return _az.classify_case_findings(case_id)


def request_evidence(result_id: str, reason: str = "", reviewer: str = "", role: str = "",
                     checklist=None) -> dict:
    if role not in ("admin", "super_admin", "reviewer"):
        return {"error": "无补证权限", "code": "forbidden"}
    reason = str(reason or "").strip()
    if not reason:
        return {"error": "补证必须填写缺口/理由", "code": "reason_required"}
    c = db.connect()
    try:
        row = c.execute("SELECT * FROM manifest_result WHERE id=?", (result_id,)).fetchone()
        if not row:
            return {"error": "结果不存在"}
        if str(row["review_status"] or "") not in ("pending", "need_evidence", "insufficient", ""):
            return {"error": "当前状态不允许补证", "code": "invalid_state"}
        eid = db.new_id("mev")
        _old = c.execute("SELECT id FROM manifest_evidence WHERE result_id=? AND status='open' LIMIT 1", (result_id,)).fetchone()
        if _old:
            return {"ok": True, "result_id": result_id, "evidence_id": _old["id"], "status": "need_evidence", "existing": True}
        _cl = _norm_checklist(checklist)
        c.execute("INSERT INTO manifest_evidence(id,result_id,reason,status,requested_by,created_at,checklist_json) "
                  "VALUES(?,?,?,'open',?,?,?)",
                  (eid, result_id, reason, reviewer or "", db.now(), json.dumps(_cl, ensure_ascii=False)))
        c.execute("UPDATE manifest_result SET review_status='need_evidence', review_reason=?, "
                  "reviewer=?, reviewed_at=? WHERE id=?", (reason, reviewer or "", db.now(), result_id))
        c.commit()
    finally:
        c.close()
    try:
        R.audit_logs.log(actor=reviewer or "system", action="manifest.evidence_requested",
                         object=result_id, after=reason[:200])
    except Exception:
        pass
    # 通知项目负责人（通知中心按事件配置决定是否落库/推送）
    try:
        c = db.connect()
        _owner = c.execute("SELECT ca.created_by FROM manifest_result mr JOIN audit_manifest m ON m.id=mr.manifest_id "
                           "JOIN audit_case ca ON ca.id=m.case_id WHERE mr.id=?", (result_id,)).fetchone()
        c.close()
        if _owner and _owner["created_by"]:
            from . import notify as _ntf
            _ntf.notify(_owner["created_by"], "evidence.requested",
                        "补证事项待处理", reason[:200])
    except Exception:
        logging.getLogger(__name__).debug("evidence notify skipped", exc_info=True)
    return {"ok": True, "result_id": result_id, "evidence_id": eid, "status": "need_evidence",
            "checklist": _cl}


def fulfill_evidence(evidence_id: str, evidence_ref: str = "", reviewer: str = "", role: str = "") -> dict:
    """补证材料登记：状态 fulfilled，结果进入 pending_reaudit；不自动改判。"""
    if role not in ("admin", "super_admin", "reviewer"):
        return {"error": "无补证权限", "code": "forbidden"}
    c = db.connect()
    try:
        row = c.execute("SELECT * FROM manifest_evidence WHERE id=?", (evidence_id,)).fetchone()
        if not row:
            return {"error": "补证事项不存在"}
        if str(row["status"] or "") != "open":
            return {"error": "补证事项已处理", "code": "invalid_state"}
        c.execute("UPDATE manifest_evidence SET status='fulfilled', fulfilled_at=?, evidence_ref=?, "
                  "requested_by=COALESCE(NULLIF(requested_by,''),?) WHERE id=?",
                  (db.now(), evidence_ref or "", reviewer or "", evidence_id))
        c.execute("UPDATE manifest_result SET review_status='pending', review_reason=?, reviewer=?, reviewed_at=? "
                  "WHERE id=?", ("已补证，待重判", reviewer or "", db.now(), row["result_id"]))
        c.commit()
    finally:
        c.close()
    try:
        R.audit_logs.log(actor=reviewer or "system", action="manifest.evidence_fulfilled",
                         object=evidence_id, after=(evidence_ref or "")[:200])
    except Exception:
        pass
    return {"ok": True, "evidence_id": evidence_id, "status": "fulfilled",
            "review_status": "pending_reaudit", "note": "补证已登记，需重新执行 D4 后才能改判"}


def reaudit_evidence(evidence_id: str, reviewer: str = "", role: str = "") -> dict:
    """补证后重判：将补证材料作为新文档，重新 freeze + D4；旧结果保留。"""
    if role not in ("admin", "super_admin", "reviewer"):
        return {"error": "无重判权限", "code": "forbidden"}
    c = db.connect()
    try:
        ev = c.execute("SELECT * FROM manifest_evidence WHERE id=?", (evidence_id,)).fetchone()
        old = c.execute("SELECT * FROM manifest_result WHERE id=?", (ev["result_id"],)).fetchone() if ev else None
        man = c.execute("SELECT * FROM audit_manifest WHERE id=?", (old["manifest_id"],)).fetchone() if old else None
    finally:
        c.close()
    if not ev or not old or not man:
        return {"error": "补证事项或原结果不存在"}
    if str(ev["status"] or "") not in ("fulfilled", "reaudited"):
        return {"error": "补证材料尚未登记完成", "code": "invalid_state"}
    case_id = man["case_id"]
    try:
        items = json.loads(man["items_json"] or "[]")
    except Exception:
        items = []
    item = next((x for x in items if str(x.get("code") or "") == str(old["rule_code"] or "")), None)
    if not item:
        return {"error": "找不到原审核项"}
    from . import project as _pj
    src = next((d for d in _pj.documents(case_id) if d.get("id") == item.get("object_id")), None)
    src_path = (src or {}).get("path") or ""
    base_text = ""
    if src_path and os.path.exists(src_path):
        try:
            # L149：统一解析入口（复用同一次解析产物；=0 时逐字回退直连）。
            from . import parse_bridge as _pb_rea
            base_text = _pb_rea.parse_document(src_path).text or ""
        except Exception:
            base_text = ""
    ref = str(ev["evidence_ref"] or "")
    extra = ""
    _d = R.documents.get(ref) if ref else None
    if _d and _d.get("path") and os.path.exists(_d["path"]):
        try:
            from . import parse_bridge as _pb_rea2
            extra = _pb_rea2.parse_document(_d["path"]).text or ""
        except Exception:
            extra = ""
    elif ref and os.path.exists(ref):
        try:
            extra = open(ref, encoding="utf-8").read()
        except Exception:
            extra = ""
    else:
        extra = ref
    import tempfile
    from pathlib import Path as _P
    p = _P(tempfile.mkdtemp()) / "补充证据.txt"
    p.write_text(base_text + "\n\n【补证材料】\n" + extra, encoding="utf-8")
    new_doc = db.new_id("doc")
    R.documents.insert(id=new_doc, filename=p.name, doc_type="txt", status="parsed", path=str(p))
    cx = db.connect()
    try:
        cx.execute("INSERT INTO case_document(case_id,document_id) VALUES(?,?)", (case_id, new_doc))
        cx.commit()
    finally:
        cx.close()
    from . import manifest as _mf
    nm = _mf.freeze(case_id, actor=reviewer or "", source="evidence_reaudit")
    if not nm.get("ok"):
        return {"error": nm.get("error") or "重判清单生成失败"}
    out = run(nm["manifest_id"])
    new = next((x for x in out.get("items") or []
                if str(x.get("rule") or "") == str(old["rule_code"] or "")
                and str(x.get("object_id") or "") == new_doc), None)
    if not new:
        new = next((x for x in out.get("items") or [] if str(x.get("rule") or "") == str(old["rule_code"] or "")), None)
    if not new:
        return {"error": "重判未产生新结果"}
    c = db.connect()
    try:
        # 重判以原逻辑对象为 active 键：旧对象的旧结果让位给新结果；新证据文档不单独占 active
        _old_obj = str(old["object_id"] or "")
        _code = str(old["rule_code"] or "")
        if _old_obj:
            c.execute("DELETE FROM manifest_active WHERE case_id=? AND object_id=? AND rule_code=?",
                      (case_id, str(new_doc), _code))
            c.execute("INSERT INTO manifest_active(case_id,object_id,rule_code,result_id,updated_at) "
                      "VALUES(?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code) DO UPDATE SET "
                      "result_id=excluded.result_id, updated_at=excluded.updated_at",
                      (case_id, _old_obj, _code, new["result_id"], db.now()))
            # 子要求级 active 同步迁移：旧对象每个子要求指向新 result
            c.execute("DELETE FROM manifest_active_sub WHERE case_id=? AND object_id=? AND rule_code=?",
                      (case_id, str(new_doc), _code))
            _nr = c.execute("SELECT d4_json FROM manifest_result WHERE id=?", (new["result_id"],)).fetchone()
            try:
                _nsubs = (__import__("json").loads((_nr["d4_json"] if _nr else "") or "{}")).get("subs") or []
            except Exception:
                _nsubs = []
            if not _nsubs:
                _nsubs = [{"id": "", "status": ""}]
            for _sub in _nsubs:
                c.execute("INSERT INTO manifest_active_sub(case_id,object_id,rule_code,sub_id,result_id,status,updated_at) "
                          "VALUES(?,?,?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code,sub_id) DO UPDATE SET "
                          "result_id=excluded.result_id,status=excluded.status,updated_at=excluded.updated_at",
                          (case_id, _old_obj, _code, str(_sub.get("id") or ""), new["result_id"],
                           str(_sub.get("status") or ""), db.now()))
        c.execute("UPDATE manifest_evidence SET status='reaudited', new_result_id=? WHERE id=?",
                  (new["result_id"], evidence_id))
        c.execute("UPDATE manifest_result SET review_status='pending', review_reason='补证后重判，待复核' WHERE id=?",
                  (new["result_id"],))
        c.commit()
    finally:
        c.close()
    before = {"result_id": old["id"], "conclusion": old["conclusion"], "execution": old["execution"],
              "d4": json.loads(old["d4_json"] or "{}")}
    after = {"result_id": new["result_id"], "conclusion": new["conclusion"], "execution": new["execution"],
             "d4": new.get("d4")}
    R.audit_logs.log(actor=reviewer or "system", action="manifest.reaudited", object=evidence_id,
                     after=json.dumps({"before": before.get("conclusion"), "after": after.get("conclusion")},
                                      ensure_ascii=False))
    return {"ok": True, "evidence_id": evidence_id, "before": before, "after": after,
            "manifest_id": nm["manifest_id"], "new_result_id": new["result_id"]}
