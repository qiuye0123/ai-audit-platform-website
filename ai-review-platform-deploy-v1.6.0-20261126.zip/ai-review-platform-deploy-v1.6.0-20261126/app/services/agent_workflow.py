"""7 智能体通用 DAG 工作流。

节点：parse → fact → rulegen → conflict → judge → fp → ruleminer
- 依赖由 agent_dag.run 执行，保留 trace
- handler 默认调用 agents.run_agent；测试可注入 fake handler
- 条件节点用 when 跳过，不伪造执行
"""
from __future__ import annotations
from . import agent_dag
from . import agents


def nodes(policy_text: str = "", feedback_id: str = "", rule_code: str = "") -> list:
    return [
        {"id": "parse", "name": "文档解析", "agent": "agent-parse", "depends_on": []},
        {"id": "fact", "name": "事实抽取", "agent": "agent-fact", "depends_on": ["parse"]},
        {"id": "rulegen", "name": "规则生成", "agent": "agent-rulegen", "depends_on": ["fact"],
         "when": (lambda c: bool(c.get("policy_text"))) if policy_text else (lambda c: False)},
        {"id": "conflict", "name": "冲突分析", "agent": "agent-conflict", "depends_on": ["fact", "rulegen"],
         "when": (lambda c: bool(c.get("rule_code"))) if rule_code else (lambda c: False)},
        {"id": "judge", "name": "点位判定", "agent": "agent-judge", "depends_on": ["fact", "conflict"]},
        {"id": "fp", "name": "误报归因", "agent": "agent-fp", "depends_on": ["judge"],
         "when": (lambda c: bool(c.get("feedback_id"))) if feedback_id else (lambda c: False)},
        {"id": "ruleminer", "name": "规则挖掘", "agent": "agent-ruleminer", "depends_on": ["judge"]},
    ]


def default_handlers(payload: dict, actor: str = "") -> dict:
    def _run(agent_id):
        def fn(node, ctx):
            arg = {"path": payload.get("path") or "", "text": payload.get("text") or ""}
            if node["id"] == "rulegen":
                arg["text"] = payload.get("policy_text") or ""
            elif node["id"] == "judge":
                arg["points"] = payload.get("points") or []
            elif node["id"] == "conflict":
                arg["rule_code"] = payload.get("rule_code") or ""
            elif node["id"] == "fp":
                arg["feedback_id"] = payload.get("feedback_id") or ""
            # L108：审计 actor 传真实操作人（HTTP 会话 uid），不再落成 system。
            r = agents.run_agent(agent_id, arg, actor=str(actor or ""))
            return {"agent": agent_id, "status": r.get("status"), "result": r.get("result")}
        return fn
    return {n["id"]: _run(n["agent"]) for n in nodes(payload.get("policy_text", ""), payload.get("feedback_id", ""), payload.get("rule_code", ""))}


def run(payload: dict, handlers: dict | None = None, actor: str = "") -> dict:
    """执行 7 智能体 DAG。

    actor：触发者 uid（HTTP/CLI 会话身份）。它会同时：
      1) 显式传给 default_handlers 的 run_agent（直接调用的节点）；
      2) 设置 agents 运行期 actor 上下文，让 handler 内部嵌套调用（orchestrator
         parse/fact、review.judge_findings 等）的 agent.run 审计也带真实操作人；
    不在任何入口把 actor 写成 system；system 只保留给无用户的系统自动化。
    """
    payload = dict(payload or {})
    ns = nodes(payload.get("policy_text", ""), payload.get("feedback_id", ""), payload.get("rule_code", ""))
    ctx = {"path": payload.get("path") or "", "text": payload.get("text") or "",
           "points": payload.get("points") or [], "policy_text": payload.get("policy_text") or "",
           "rule_code": payload.get("rule_code") or "", "feedback_id": payload.get("feedback_id") or ""}
    hs = handlers or default_handlers(payload, actor=actor)
    _tok = agents.set_actor(actor) if actor else None
    try:
        res = agent_dag.run(ns, hs, ctx, stop_on_error=False)
    finally:
        if _tok is not None:
            agents.reset_actor(_tok)
    _outputs = res.get("outputs") or {}
    # L108：节点级降级（如扫描件无 OCR）必须上卷到工作流响应，不能只看 ok=True。
    _degraded_nodes = [str(k) for k, v in _outputs.items()
                       if isinstance(v, dict) and v.get("degraded")]
    return {"ok": res.get("ok"), "trace": res.get("trace"), "order": res.get("order"),
            "outputs": res.get("outputs"), "failed": res.get("failed"),
            "degraded": bool(_degraded_nodes), "degraded_nodes": _degraded_nodes}
