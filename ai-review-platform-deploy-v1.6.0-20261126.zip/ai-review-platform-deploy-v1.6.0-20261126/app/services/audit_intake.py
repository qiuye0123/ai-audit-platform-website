"""审核入口：解析产物的唯一入口。

上传、审核、多文件合并都通过这里复用 agent-parse + parse_bridge；
避免每个调用方各自 run_agent/读取缓存。
"""
from __future__ import annotations

import logging


def ensure_parsed(path: str):
    """返回 agent-parse 的解析产物；失败抛出 RuntimeError。"""
    from . import parse_bridge
    got = parse_bridge.get(path)
    if got:
        return got
    from . import agents as _agents
    rr = _agents.run_agent("agent-parse", {"path": path})
    if rr.get("status") != "ok":
        raise RuntimeError(str((rr.get("result") or {}).get("error") or "agent-parse 不可用"))
    parsed = parse_bridge.get(path)
    if not parsed:
        raise RuntimeError("agent-parse 未返回解析产物")
    # 邮件/纯文本没有结构化解析器时，保留原文而不是返回空正文。
    try:
        _txt = (parsed.get("doc") or {}).get("text") or ""
        if not _txt and str(path).lower().endswith((".eml", ".txt", ".md")):
            _raw = open(path, encoding="utf-8", errors="replace").read()
            parsed.setdefault("doc", {})
            parsed["doc"]["text"] = _raw
            parsed["doc"]["format"] = str(path).rsplit(".", 1)[-1].lower()
    except Exception:
        pass
    return parsed
