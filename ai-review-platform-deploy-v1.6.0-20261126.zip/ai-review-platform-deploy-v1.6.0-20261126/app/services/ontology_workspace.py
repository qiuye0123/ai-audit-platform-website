"""工作空间本体建模：自动发现候选 + 人工维护 + 主链别名归一。

设计边界：
- 全局本体（seed + onto_entity）是共享类型/实例库；
- 工作空间只保存本空间的实体术语、别名和审核依据，不与其他空间混用；
- 达到阈值后才自动发现；未达到不自动启动；人工可随时添加；
- 自动发现只生成候选，业务管理员确认后才进入主链别名归一。
"""
import json
import logging
import re

from .. import db
from .. import repositories as R
from . import ctx as _ctx
from . import workspaces as W


DEFAULT_THRESHOLD = 10


def _cur():
    try:
        c = _ctx.get_context() or {}
        return c.get("tenant_id") or "", c.get("workspace_id") or ""
    except Exception:
        return "", ""


def _settings(ws_id: str) -> dict:
    try:
        return W.get_settings(ws_id) or {}
    except Exception:
        return {}


def _save_settings(ws_id: str, patch: dict) -> None:
    W.save_settings(ws_id, patch)


def _case_count(ws_id: str) -> int:
    try:
        with db.session() as c:
            return int(c.execute(
                "SELECT COUNT(*) FROM audit_case WHERE workspace_id=? AND status IN ('completed','reviewing','auditing','audit_failed')",
                (ws_id,)).fetchone()[0])
    except Exception:
        return 0


def _threshold(settings: dict) -> int:
    try:
        n = int(settings.get("ontology_auto_threshold") or DEFAULT_THRESHOLD)
    except Exception:
        n = DEFAULT_THRESHOLD
    return max(1, min(1000, n))


def _terms(settings: dict) -> list:
    raw = settings.get("ontology_terms")
    return raw if isinstance(raw, list) else []


def status() -> dict:
    tid, wid = _cur()
    st = _settings(wid)
    count = _case_count(wid)
    threshold = _threshold(st)
    terms = _terms(st)
    # T-197（P0-2）：本体消费开关的权威口径（默认关，按空间开；auto/manual）。
    # 页面必须能区分「模块开」和「消费开」：module_on 只挡 API/自动建模，
    # ontology.enabled 才决定 cross_doc / D4 别名是否读本体。
    try:
        from . import ontology_control as _oc
        switch = _oc.effective(wid) if wid else {}
    except Exception:
        switch = {}
    return {
        "tenant_id": tid, "workspace_id": wid,
        "project_count": count, "threshold": threshold,
        "eligible": count >= threshold,
        "module_on": bool(W.module_on(wid, "mod_ontology")) if wid else False,
        "ontology_switch": switch,
        "ontology_enabled": bool((switch or {}).get("enabled")),
        "ontology_mode": str((switch or {}).get("mode") or ""),
        "auto_last_count": int(st.get("ontology_auto_last_count") or 0),
        "terms": terms,
        "auto_count": sum(1 for x in terms if x.get("source") == "auto"),
        "manual_count": sum(1 for x in terms if x.get("source") == "manual"),
        "active_count": sum(1 for x in terms if x.get("status") == "active"),
        # T-197（P1-4）：带别名必须填依据（UI 与后端同一契约）
        "evidence_required_for_aliases": True,
        "evidence_max_len": 500,
    }


_TERM_SUFFIX = ("金额", "比例", "费率", "期限", "数量", "日期", "编号", "温度",
                "时间", "重量", "浓度", "时长", "单价", "报价", "限价", "价格",
                "名称", "单位", "条款", "签字", "许可")
_TERM_BAD = ("符合", "覆盖", "明确", "正确", "完整", "一致", "要求", "约束", "不得",
             "可以", "应当", "是否", "检查", "审核", "签署", "生效")


def _term_ok(term: str) -> bool:
    t = (term or "").strip()
    if not (2 <= len(t) <= 12) or t in _TERM_BAD:
        return False
    if any(x in t for x in _TERM_BAD):
        return False
    return t.endswith(_TERM_SUFFIX)


def _candidate_terms() -> list:
    """从当前空间规则的 metric/object 与复核发现中找候选术语；不跨空间。"""
    out = {}
    try:
        from . import rule as _rule_scope
        for r in _rule_scope.effective_rule_rows():  # T-171 生效口径（默认 0=旧行为）
            v = R.rules.latest_version(r["id"]) or {}
            try:
                slots = json.loads(v.get("slots_json") or "{}")
            except Exception:
                slots = {}
            for key in ("metric", "object", "subject"):
                term = str(slots.get(key) or "").strip()
                if _term_ok(term):
                    out[term] = out.get(term, 0) + 1
    except Exception:
        logging.getLogger(__name__).debug('ontology rule discovery skipped', exc_info=True)
    try:
        # 只取明确的“指标/字段”后缀，避免把规则标题/审核点名称当成本体实体
        for f in R.findings.list(order="created_at DESC", limit=500):
            for src in (f.get("title") or "", f.get("summary") or ""):
                for m in re.findall(r"[\u4e00-\u9fa5]{2,12}", str(src)):
                    if _term_ok(m):
                        out[m] = out.get(m, 0) + 1
    except Exception:
        pass
    idx = {}
    try:
        from . import ontology_v2
        idx = ontology_v2.alias_index() or {}
    except Exception:
        pass
    # 只做相似候选提示，不自动合并；工艺单号/工单号等不同概念会在这里显式提示
    try:
        from . import entity_resolution as _er
        known = list(idx.keys()) + [str(x.get("canonical") or "") for x in _terms(_settings(_cur()[1]))]
        known = [x for x in known if x]
    except Exception:
        known = []
    rows = []
    for k, v in sorted(out.items(), key=lambda kv: -kv[1]):
        if k in idx:
            continue
        similar = []
        for other in known:
            if other == k:
                continue
            sc = _er.similarity(k, other)
            if sc >= 0.86:
                similar.append({"term": other, "score": sc})
        rows.append({"canonical": k, "aliases": [], "count": v,
                     "similar_to": sorted(similar, key=lambda x: -x["score"])[:3]})
    return rows[:30]


def discover() -> dict:
    tid, wid = _cur()
    if not wid:
        return {"ok": False, "started": False, "reason": "没有当前工作空间"}
    st = _settings(wid)
    if not W.module_on(wid, "mod_ontology"):
        return {"ok": False, "started": False, "reason": "当前空间未启用本体模块"}
    count = _case_count(wid)
    threshold = _threshold(st)
    if count < threshold:
        return {"ok": True, "started": False, "reason": f"当前空间审核项目 {count} 份，未达到启动阈值 {threshold} 份",
                "project_count": count, "threshold": threshold, "created": 0}
    terms = _terms(st)
    existing = {str(x.get("canonical") or "") for x in terms}
    created = []
    for c in _candidate_terms():
        if c["canonical"] in existing:
            continue
        terms.append({
            "id": db.new_id("ot"), "canonical": c["canonical"], "aliases": [],
            "count": c.get("count") or 1, "source": "auto", "status": "candidate",
            "similar_to": c.get("similar_to") or [],
            "created_at": db.now(), "updated_at": db.now(),
        })
        created.append(c["canonical"])
        existing.add(c["canonical"])
    if created:
        _save_settings(wid, {"ontology_terms": terms, "ontology_auto_last_count": count})
        R.audit_logs.log(actor="system", action="ontology.auto_discover", object=wid,
                         after=f"项目 {count} 份，候选 {', '.join(created[:8])}")
    return {"ok": True, "started": True, "project_count": count, "threshold": threshold,
            "created": len(created), "terms": [x for x in terms if x.get("source") == "auto"]}


def maybe_auto_discover() -> dict:
    """审核完成后触发；未达到阈值不启动，达到后按项目增量触发一次。"""
    tid, wid = _cur()
    if not wid:
        return {"ok": False, "started": False}
    st = _settings(wid)
    if not W.module_on(wid, "mod_ontology"):
        return {"ok": True, "started": False, "reason": "本体模块未启用"}
    count = _case_count(wid)
    threshold = _threshold(st)
    if count < threshold:
        return {"ok": True, "started": False, "project_count": count, "threshold": threshold}
    if int(st.get("ontology_auto_last_count") or 0) >= count:
        return {"ok": True, "started": False, "project_count": count, "threshold": threshold,
                "reason": "项目数量无新增"}
    return discover()


def add_manual(canonical: str, aliases: list = None, type_: str = "", actor: str = "",
               evidence: str = "") -> dict:
    canonical = (canonical or "").strip()
    if len(canonical) < 2:
        return {"ok": False, "reason": "标准名至少 2 个字"}
    aliases = [str(x).strip() for x in (aliases or []) if str(x).strip() and str(x).strip() != canonical]
    # T-197（P1-4）：依据为「带别名」的必填项，长度上限 500；UI 与后端同一契约
    evidence = str(evidence or "").strip()
    if len(evidence) > 500:
        return {"ok": False, "code": "evidence_too_long",
                "reason": f"依据最多 500 字（当前 {len(evidence)} 字）"}
    if aliases and not evidence:
        return {"ok": False, "code": "alias_evidence_required",
                "reason": "添加别名必须填写依据；没有依据只能新增标准名"}
    tid, wid = _cur()
    if not wid:
        return {"ok": False, "reason": "没有当前工作空间"}
    st = _settings(wid)
    terms = _terms(st)
    hit = next((x for x in terms if x.get("canonical") == canonical), None)
    if hit:
        hit["aliases"] = list(dict.fromkeys((hit.get("aliases") or []) + aliases))
        hit["type"] = type_ or hit.get("type") or ""
        hit["evidence"] = str(evidence or hit.get("evidence") or "")[:500]
        hit["source"] = hit.get("source") or "manual"
        hit["status"] = "active"
        hit["updated_at"] = db.now()
    else:
        terms.append({"id": db.new_id("ot"), "canonical": canonical, "aliases": aliases,
                      "type": type_ or "", "count": 0, "source": "manual", "status": "active",
                      "evidence": str(evidence or "")[:500], "created_at": db.now(), "updated_at": db.now()})
    _save_settings(wid, {"ontology_terms": terms})
    R.audit_logs.log(actor=actor or "admin", action="ontology.manual_add", object=wid, after=canonical)
    return {"ok": True, "terms": terms, "canonical": canonical}


def set_term(term_id: str, status_: str, actor: str = "") -> dict:
    if status_ not in ("active", "ignored", "candidate"):
        return {"ok": False, "reason": "状态非法"}
    tid, wid = _cur()
    st = _settings(wid)
    terms = _terms(st)
    hit = next((x for x in terms if x.get("id") == term_id), None)
    if not hit:
        return {"ok": False, "reason": "术语不存在"}
    hit["status"] = status_
    hit["updated_at"] = db.now()
    _save_settings(wid, {"ontology_terms": terms})
    R.audit_logs.log(actor=actor or "admin", action=f"ontology.term_{status_}", object=wid,
                     after=hit.get("canonical") or "")
    return {"ok": True, "term": hit, "terms": terms}


def save_threshold(value: int, actor: str = "") -> dict:
    tid, wid = _cur()
    try:
        n = max(1, min(1000, int(value)))
    except Exception:
        return {"ok": False, "reason": "阈值必须是数字"}
    _save_settings(wid, {"ontology_auto_threshold": n})
    R.audit_logs.log(actor=actor or "admin", action="ontology.threshold", object=wid, after=str(n))
    return {"ok": True, "threshold": n}


def alias_pairs(ws_id: str = "") -> dict:
    """当前空间已启用术语 → 别名映射；主链事实归一使用。

    T-197（P0-2）：空间本体关闭时返回 {} —— 关闭后不读工作空间别名/词典投影，
    与「关 = 不读本体」一致；影子评估用 force_consumption 临时强制开。
    """
    wid = ws_id or _cur()[1]
    if not wid:
        return {}
    try:
        from . import ontology_control as _oc
        if not _oc.consumption_enabled_for(wid):
            return {}
    except Exception:
        logging.getLogger(__name__).debug("ontology switch lookup skipped", exc_info=True)
    st = _settings(wid)
    out = {}
    # 企业业务词典优先：已确认术语同义词进入同一别名归一；冲突不归一
    try:
        from . import terms as _tm
        for a, c in (_tm.confirmed_alias_pairs() or {}).items():
            out[a] = c
    except Exception:
        logging.getLogger(__name__).debug('business term aliases skipped', exc_info=True)
    for t in _terms(st):
        if t.get("status") != "active":
            continue
        canonical = str(t.get("canonical") or "").strip()
        if not canonical:
            continue
        for a in [canonical] + list(t.get("aliases") or []):
            a = str(a).strip()
            if a and a != canonical:
                out.setdefault(a, canonical)
    return out
