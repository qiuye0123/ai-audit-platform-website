"""对比审核：两份文档（如工艺书 v1 vs v2）的发现差异——新增问题 / 已解决 / 未变。

L121（2026-11-25）build51 深度评审批次修复：
  旧实现把 finding 压成 ``(rule_code, title)`` 集合后做纯集合差，一旦同一记录在文档里
  换了行号（F22→F23）且引文/身份不变，会因为「集合里没有」被判成 removed（已解决）——
  把「同一问题挪了位置」误报成「问题已修复」。修复：以 finding 身份（rule_code + title）
  为主键、以引文内容为副键做配对；同一记录只是定位（sheet/row/col/locator）变化的，
  计入 unchanged 并单列 moved 痕迹（附 A/B 两侧定位），**不再产生 removed/added**。
  纯集合差只用于真正消失/真正新增的 finding。
"""
from ..engine import engine


def _report(path: str) -> dict:
    return engine.build_report(path)


def _identity(f: dict) -> tuple:
    """finding 身份（同一条记录跨两版应保持稳定）：规则码 + 标题。"""
    return (str(f.get("rule_code") or f.get("id") or ""),
            str(f.get("title") or ""))


def _quotes(f: dict) -> tuple:
    """finding 引文集合（内容副键；去空、排序后比较）。"""
    return tuple(sorted({
        str(loc.get("quote") or "").strip()
        for loc in (f.get("locations") or [])
        if str(loc.get("quote") or "").strip()
    }))


def _locations(f: dict) -> tuple:
    """finding 定位签名（sheet / row / col / locator），用于识别「同记录移动」。"""
    out = []
    for loc in f.get("locations") or []:
        out.append((str(loc.get("sheet") or ""), loc.get("row"),
                    str(loc.get("col") or ""), str(loc.get("locator") or "")))
    return tuple(out)


def _same_issue(a: dict, b: dict) -> str:
    """判断两条 finding 是否同一记录：'identity' / 'content' / ''（不是）。"""
    if _identity(a) == _identity(b):
        return "identity"
    # 标题可能随违规条数变化（「1 处 <85℃」→「2 处 <85℃」）：
    # 规则码相同且引文有交集 → 仍视为同一记录（内容未变、只是计数/文案变化）
    if str(a.get("rule_code") or "") and a.get("rule_code") == b.get("rule_code"):
        qa, qb = set(_quotes(a)), set(_quotes(b))
        if qa and qb and (qa & qb):
            return "content"
    return ""


def compare(path_a: str, path_b: str) -> dict:
    """以 B 相对 A：added=新出现（需处理），removed=已解决，unchanged=仍未解决。

    同一记录只是定位变化（如行号 F22→F23）时计入 unchanged，并在 moved 中给出
    两侧定位痕迹；不会同时出现在 added/removed。summary 增加 moved 计数
    （moved 是 unchanged 的子集，仅用于审核员确认「问题位置变了」）。
    """
    ra = _report(path_a)
    rb = _report(path_b)
    fa = list(ra.get("findings") or [])
    fb = list(rb.get("findings") or [])

    pairs = []            # [(a_index, b_index)]
    matched_b = set()
    # 第一轮：身份（rule_code+title）配对；同身份多条时按顺序一一配对
    for i, a in enumerate(fa):
        for j, b in enumerate(fb):
            if j in matched_b:
                continue
            if _same_issue(a, b) == "identity":
                pairs.append((i, j))
                matched_b.add(j)
                break
    # 第二轮：身份变了但内容（规则码+引文交集）相同的，仍视为同一记录（文案/计数变化）
    matched_a = {i for i, _j in pairs}
    for i, a in enumerate(fa):
        if i in matched_a:
            continue
        for j, b in enumerate(fb):
            if j in matched_b:
                continue
            if _same_issue(a, b) == "content":
                pairs.append((i, j))
                matched_b.add(j)
                matched_a.add(i)
                break

    unchanged = [fa[i] for i, _j in pairs]
    moved = []
    for i, j in pairs:
        a, b = fa[i], fb[j]
        if _locations(a) != _locations(b):
            moved.append({
                "rule_code": a.get("rule_code") or b.get("rule_code") or "",
                "title": a.get("title") or b.get("title") or "",
                "locations_a": list(a.get("locations") or []),
                "locations_b": list(b.get("locations") or []),
            })
    added = [b for j, b in enumerate(fb) if j not in matched_b]
    removed = [a for i, a in enumerate(fa) if i not in matched_a]

    return {
        "a": ra.get("summary") or {},
        "b": rb.get("summary") or {},
        "added": added,
        "removed": removed,
        "unchanged": unchanged,
        "moved": moved,
        "summary": {
            "added": len(added),
            "removed": len(removed),
            "unchanged": len(unchanged),
            "moved": len(moved),
        },
    }
