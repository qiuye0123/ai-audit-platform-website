"""A2/B2：规则静态分析（冲突、冗余、覆盖空洞、不可判定）。
不调模型、不阻断；输出结构化结果供体检与页面使用。
"""
import json
import re
from functools import lru_cache

FACES = {"A": "主体资格", "B": "结构完备", "C": "事实数据", "D": "逻辑结论",
         "E": "权利义务", "F": "商务执行", "G": "披露申报"}


@lru_cache(maxsize=8192)
def _bg(t: str):
    """汉字二元组集合（纯函数）。

    P2 慢节点最小修（/rules/static-analysis）：_find_duplicates 两两比对时
    同一判据字符串会被重复构造上千次（570 条规则 → 12 万+ 次），缓存后
    结果逐字不变、只省重复计算。
    """
    t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fff")
    return frozenset(t[i:i + 2] for i in range(len(t) - 1))


def _sim(a: str, b: str) -> float:
    A, B = _bg(a), _bg(b)
    if not A or not B:
        return 0.0
    inter = len(A & B)
    jac = inter / max(1, len(A | B))
    cont = inter / max(1, min(len(A), len(B)))
    return max(jac, cont)


def _slots_of(r: dict, raw: dict | None = None) -> dict:
    if raw is not None:
        return raw
    try:
        return json.loads((r.get("slots_json") if isinstance(r, dict) else "") or "{}")
    except Exception:
        return {}


def _constraints(slots: dict):
    """提取数值约束：返回 (metric, kind, value) 列表，kind: lower/upper/eq。"""
    out = []
    metric = str(slots.get("metric") or "").strip()
    if not metric:
        return out
    op = str(slots.get("operator") or slots.get("op") or "").strip()
    v = slots.get("threshold", slots.get("value"))
    try:
        num = float(str(v).replace(",", ""))
    except Exception:
        num = None
    rng = slots.get("range") or {}
    if num is not None and op in (">=", ">"):
        out.append((metric, "lower", num))
    elif num is not None and op in ("<=", "<"):
        out.append((metric, "upper", num))
    elif num is not None and op == "=":
        out.append((metric, "eq", num))
    if isinstance(rng, dict):
        try:
            lo = float(rng["lo"]) if rng.get("lo") is not None else None
            hi = float(rng["hi"]) if rng.get("hi") is not None else None
        except Exception:
            lo = hi = None
        if lo is not None:
            out.append((metric, "lower", lo))
        if hi is not None:
            out.append((metric, "upper", hi))
    return out


def _find_conflicts(items: list) -> list:
    out = []
    by_metric = {}
    for it in items:
        for metric, kind, val in _constraints(it["slots"]):
            by_metric.setdefault(metric, []).append((it["code"], kind, val))
        # require vs forbid 同名要素
        req = it["slots"].get("require") or []
        forb = it["slots"].get("forbid") or []
        if isinstance(req, str): req = [req]
        if isinstance(forb, str): forb = [forb]
        for w in set(req) & set(forb):
            out.append({"type": "require_forbid", "metric": w,
                        "codes": [it["code"]], "message": f"同一规则同时要求与禁止「{w}」"})
    # 跨规则：同指标上下界矛盾 / 等值越界
    for metric, rows in by_metric.items():
        lows = [r for r in rows if r[1] == "lower"]
        ups = [r for r in rows if r[1] == "upper"]
        eqs = [r for r in rows if r[1] == "eq"]
        for lo in lows:
            for up in ups:
                if lo[2] > up[2]:
                    out.append({"type": "range", "metric": metric,
                                "codes": [lo[0], up[0]],
                                "message": f"「{metric}」要求 ≥{lo[2]} 且 ≤{up[2]}，区间为空"})
        for eq in eqs:
            if lows and eq[2] < max(l[2] for l in lows):
                out.append({"type": "range", "metric": metric, "codes": [eq[0], max(lows, key=lambda x: x[2])[0]],
                            "message": f"「{metric}」要求 ={eq[2]} 但另有下界更高"})
            if ups and eq[2] > min(u[2] for u in ups):
                out.append({"type": "range", "metric": metric, "codes": [eq[0], min(ups, key=lambda x: x[2])[0]],
                            "message": f"「{metric}」要求 ={eq[2]} 但另有上界更低"})
    return out


def _find_duplicates(items: list) -> list:
    out, seen, exact_pairs, exact_codes = [], {}, set(), set()
    for it in items:
        crit = re.sub(r"\s+", "", str(it["slots"].get("criterion") or ""))
        if not crit:
            continue
        if crit in seen:
            pair = frozenset((seen[crit], it["code"]))
            if pair not in exact_pairs:
                exact_pairs.add(pair)
                exact_codes.update(pair)
                out.append({"type": "exact", "codes": [seen[crit], it["code"]],
                            "message": "判据完全相同（冗余）"})
        else:
            seen[crit] = it["code"]
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, b = items[i], items[j]
            if a["code"] in exact_codes and b["code"] in exact_codes:
                pair = frozenset((a["code"], b["code"]))
                if pair in exact_pairs:
                    continue
            ca, cb = str(a["slots"].get("criterion") or ""), str(b["slots"].get("criterion") or "")
            if len(ca) >= 8 and len(cb) >= 8 and _sim(ca, cb) >= 0.75:
                if frozenset((a["code"], b["code"])) in exact_pairs:
                    continue
                out.append({"type": "similar", "codes": [a["code"], b["code"]],
                            "message": f"判据高度相似（{_sim(ca, cb):.2f}），建议合并"})
    return out


def _coverage(items: list) -> dict:
    covered = {}
    for it in items:
        pid = str(((it.get("mapping") or {}) or {}).get("point_id") or "")
        face = str(it.get("face") or (pid[0] if pid else ""))
        if face in FACES:
            covered.setdefault(face, []).append(it.get("code") or "")
    gaps = [{"face": f, "label": FACES[f], "message": f"没有任何规则映射到「{FACES[f]}」"} for f in FACES if f not in covered]
    faces = [{"face": f, "label": FACES[f], "count": len(covered.get(f, [])),
              "codes": sorted(set(covered.get(f, [])))[:20],
              "covered": f in covered,
              "message": "已覆盖" if f in covered else "没有规则映射"} for f in FACES]
    return {"covered_faces": sorted(covered), "faces": faces, "gaps": gaps}


def analyze(ws_id: str = "", rules: list | None = None) -> dict:
    """静态分析。rules 传入 [{'code','name','slots','mapping'}] 便于单测；否则读工作空间已发布规则。"""
    items = []
    if rules is None:
        from .. import repositories as R
        from . import rule_ir as _ir
        _seen_codes = set()
        _pub_rows = R.rules.list("status=?", ("published",))
        # P2 慢节点最小修：一次批量取最新版本，替代逐规则 latest_version() N+1。
        try:
            _vmap = R.rules.latest_versions([r.get("id") or "" for r in _pub_rows])
        except Exception:
            _vmap = {}
        for r in _pub_rows:
            if r.get("code") in _seen_codes:
                continue
            _seen_codes.add(r.get("code"))
            v = ((_vmap.get(r.get("id") or "") or {}) if _vmap
                 else (R.rules.latest_version(r["id"]) or {}))
            try:
                slots = json.loads(v.get("slots_json") or "{}")
            except Exception:
                slots = {}
            try:
                scope = json.loads(r.get("scope_json") or "{}")
            except Exception:
                scope = {}
            items.append({"code": r.get("code"), "name": r.get("name"),
                          "slots": slots, "mapping": scope.get("point_mapping") or {}})
        # 审核库点位本身也是规则库的一部分；必须纳入覆盖分析，否则页面会出现“319 条规则、0 条覆盖”的假空洞
        try:
            from . import auditpoints as _ap
            from . import ctx as _ctx0
            _lib = _ap.load()
            _cur = _ctx0.get_context() or {}
            for _p in (getattr(_lib, "points", []) or []):
                _d = _p.to_dict() if hasattr(_p, "to_dict") else dict(_p)
                _code = str(_d.get("id") or _d.get("code") or "")
                if not _code or _code in _seen_codes:
                    continue
                _seen_codes.add(_code)
                _face = str(_p.category_id if hasattr(_p, "category_id") else (_d.get("category_id") or ""))
                if not _face:
                    _face = _code[0] if _code else ""
                items.append({"code": _code, "name": _d.get("name") or "", "slots": {},
                              "mapping": {"point_id": _code}, "face": _face})
        except Exception:
            pass
    else:
        for r in rules:
            items.append({"code": r.get("code"), "name": r.get("name"),
                          "slots": r.get("slots") or {}, "mapping": r.get("mapping") or {}})
    conflicts = _find_conflicts(items)
    dups = _find_duplicates(items)
    cov = _coverage(items)
    unjudge, semantic = [], []
    try:
        from . import rule_ir as _ir
        for it in items:
            if not it["slots"]:
                continue  # 无结构化槽位的引擎规则不参与可执行性统计
            ex = _ir.classify_executability(it["slots"])
            if ex["level"] == "unjudgeable":
                unjudge.append({"code": it["code"], "level": ex["level"],
                                "missing": ex["missing_evidence"], "suggestions": ex["suggestions"][:2]})
            elif ex["level"] == "semantic":
                semantic.append({"code": it["code"], "missing": ex["missing_evidence"]})
    except Exception:
        pass
    _lib_count = sum(1 for x in items if x.get("face") and not x.get("slots"))
    return {"rules": len(items), "library_rules": _lib_count,
            "conflicts": conflicts, "duplicates": dups,
            "coverage": cov, "unjudgeable": unjudge, "semantic": semantic,
            "summary": {"conflicts": len(conflicts), "duplicates": len(dups),
                        "coverage_gaps": len(cov["gaps"]), "unjudgeable": len(unjudge),
                        "library_rules": _lib_count,
                        "semantic": len(semantic)}}
