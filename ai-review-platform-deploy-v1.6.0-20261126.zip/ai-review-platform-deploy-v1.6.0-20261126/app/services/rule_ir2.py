# -*- coding: utf-8 -*-
"""R3/R4/R5 typed IR：语义/证据、关系/一致、记录/程序。

本模块与 ``app/engine/rule_ir2.py``（数值三段式 IR）职责不同：这里负责把
``rule_ir.compile_rule`` 的 R3/R4/R5 规则编译成**可执行 typed 条件**，并提供
确定性的执行器。

编译目标：
- R3 语义/证据：``evidence_contract`` + ``semantic`` payload + 确定性证据/要素检查
- R4 关系/一致：``relations``（left/right/compare/across）+ 事实/原文比对
- R5 记录/程序：``procedure.requirements``（字段/签字/频次/步骤/格式）+ 原文检查

硬约束：
- 自由文本 ``criterion`` 不得被原样当作确定性条件执行：能保守解析的，必须落成
  typed 原子（relations/procedure.requirements）；不能解析的，只能进入
  ``semantic`` payload 交给 agent-judge，或标记 ``executable=False`` 拒绝执行。
- 所有发布阻断项写入 ``contract_errors``（字符串，兼容旧消费方）和
  ``contract_error_details``（结构化 code/message/hint/field），使前端/CLI
  可以解释“为什么不能发布”。
"""
from __future__ import annotations

import os
import re
import unicodedata
from typing import Any

# ---------------------------------------------------------------- 常量

CATEGORY_FAMILY = {
    # R3：语义/证据
    "completeness": "R3", "personnel": "R3", "equipment": "R3", "label": "R3",
    # R4：关系/一致
    "consistency": "R4", "citation": "R4",
    # R5：记录/程序
    "record": "R5", "format": "R5", "preprocess": "R5", "frequency": "R5",
    # 既有确定性族
    "limit": "R1", "prohibited": "R2",
}
NATURE_FAMILY = {
    "threshold": "R1", "obligation": "R2", "evidence": "R3",
    "relational": "R4", "procedural": "R5",
}
FAMILY_LABELS = {
    "R1": "数值/限值", "R2": "义务/禁止", "R3": "语义/证据",
    "R4": "关系/一致", "R5": "记录/程序",
}
RELATION_COMPARES = ("equal", "not_equal", "contains", "not_contains", "version_equal", "same")
RELATION_ACROSS = ("document", "document_set", "fields")
PROCEDURE_KINDS = ("record", "frequency", "format", "preprocess", "procedural")
FALLBACKS = ("single_block_first", "ask", "abstain", "fail")
STATES = ("满足", "不满足", "证据不足", "不适用", "执行失败")

# 证据/术语里常见的泛词：只做提示，不直接当证据
_GENERIC_TERMS = {"证据", "原文", "材料", "文件", "文档", "相关资料", "证明", "记录"}


# ---------------------------------------------------------------- 基础工具

def _text(value: Any) -> str:
    return str(value or "").strip()


def _compact(value: Any) -> str:
    """匹配用归一：全半角/大小写/空白/标点无关。"""
    s = unicodedata.normalize("NFKC", _text(value)).lower()
    return re.sub(r"[\s,，。;；:：、()（）\[\]【】\"'“”‘’/\\\-_]+", "", s)


def _num(value: Any) -> float | None:
    try:
        return float(str(value).replace(",", "").strip())
    except Exception:
        return None


def _split_terms(value: Any, *, split_and: bool = False) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        raw = [str(x).strip() for x in value if str(x).strip()]
    elif isinstance(value, dict):
        raw = [str(x).strip() for x in value.values()
               if isinstance(x, (str, int, float)) and str(x).strip()]
    else:
        raw = [x.strip() for x in re.split(r"[，,、;；\n\|]+", _text(value)) if x.strip()]
    out: list[str] = []
    for item in raw:
        item = item.strip(" \t\r\n，,。.;；:：、")
        if not item:
            continue
        if split_and and len(item) >= 6:
            parts = [p.strip(" \t\r\n，,。.;；:：、")
                     for p in re.split(r"(?:以及|与|和|及)", item)]
            parts = [p for p in parts if p]
            out.extend(parts if len(parts) > 1 else [item])
        else:
            out.append(item)
    # 去重保序
    seen, uniq = set(), []
    for x in out:
        k = _compact(x)
        if k and k not in seen:
            seen.add(k)
            uniq.append(x)
    return uniq


def _dedup(items: list[dict], keys: tuple[str, ...]) -> list[dict]:
    seen, out = set(), []
    for item in items:
        key = tuple(_compact(item.get(k) or "") for k in keys)
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def family_of(category: Any, nature: Any = "") -> str:
    cat = _text(category)
    if cat in CATEGORY_FAMILY:
        return CATEGORY_FAMILY[cat]
    return NATURE_FAMILY.get(_text(nature), "")


def family_label(family: Any) -> str:
    return FAMILY_LABELS.get(str(family or ""), "")


# ---------------------------------------------------------------- 证据

def parse_evidence(value: Any, default_scope: str = "document") -> list[dict]:
    """required_evidence → typed evidence_contract。"""
    out = []
    if isinstance(value, (list, tuple)):
        for item in value:
            if isinstance(item, dict):
                term = (item.get("term") or item.get("name") or item.get("label")
                        or item.get("field") or "")
                if _text(term):
                    out.append({
                        "term": _text(term),
                        "scope": _text(item.get("scope")) or default_scope,
                        "anchor": _text(item.get("anchor")),
                        "required": bool(item.get("required", True)),
                        "generic": _compact(term) in {_compact(x) for x in _GENERIC_TERMS},
                    })
            elif _text(item):
                out.append({"term": _text(item), "scope": default_scope, "anchor": "",
                            "required": True,
                            "generic": _compact(item) in {_compact(x) for x in _GENERIC_TERMS}})
    else:
        terms = _split_terms(value, split_and=True)
        for t in terms:
            out.append({"term": t, "scope": default_scope, "anchor": "",
                        "required": True,
                        "generic": _compact(t) in {_compact(x) for x in _GENERIC_TERMS}})
    return _dedup(out, ("term",))


def evidence_string(evidence: list[dict]) -> str:
    return "、".join(str(e.get("term") or "") for e in evidence if e.get("term"))


# ---------------------------------------------------------------- R4：关系

_MODALS = r"(?:必须|应当|应|须|需|需要|要|保证|确保)"
_REL_EQUAL_PAT = re.compile(
    r"(?P<left>[^，。；;:\n]{2,30}?)"
    + r"(?:" + _MODALS + r")?"
    + r"(?:与|和|跟|同)"
    + r"(?P<right>[^，。；;:\n]{2,30}?)"
    + r"(?:保持)?(?:一致|相符|相同|匹配|对应|统一|同步|相等)"
)
_REL_EQ_PAT = re.compile(
    r"(?P<left>[^，。；;:\n]{2,30}?)"
    + r"(?:" + _MODALS + r")?"
    + r"(?:等于|等同于)"
    + r"(?P<right>[^，。；;:\n]{2,30})"
)
_REL_SINGLE_PAT = re.compile(
    r"(?P<object>[^，。；;:\n]{2,30}?)"
    + r"(?:" + _MODALS + r")?"
    + r"(?:保持)?(?:一致|相符|相同|统一|同步)"
)


def _clean_operand(value: Any) -> str:
    s = _text(value).strip(" \t\r\n，,。.;；:：、")
    s = re.sub(r"^(?:其中|上述|该|本|其|并且|同时|且|须|需|应|应当|必须|要|保证|确保)+", "", s)
    s = re.sub(r"(?:必须|应当|应|须|需|需要|要|保证|确保|保持|的)+$", "", s)
    return s.strip(" 的")


def _clean_self_operand(value: Any) -> str:
    """单对象一致性：去掉“保持/前后/之间/彼此”等关系词。"""
    s = _clean_operand(value)
    s = re.split(r"(?:保持|前后|之间|彼此|相互|互相)", s)[0]
    return _clean_operand(s)


def _norm_compare(value: Any) -> str:
    s = _text(value).lower()
    aliases = {
        "=": "equal", "==": "equal", "eq": "equal", "equal": "equal", "same": "same",
        "一致": "equal", "相同": "equal", "相符": "equal", "匹配": "equal", "对应": "equal",
        "!=": "not_equal", "≠": "not_equal", "not_equal": "not_equal", "不等": "not_equal",
        "contains": "contains", "包含": "contains", "include": "contains",
        "not_contains": "not_contains", "不包含": "not_contains",
        "version_equal": "version_equal", "版本一致": "version_equal", "版本相同": "version_equal",
    }
    return aliases.get(s, s)


def _norm_across(value: Any) -> str:
    s = _text(value).lower()
    if s in ("document_set", "跨文档", "跨文件", "多文档", "document-set"):
        return "document_set"
    if s in ("fields", "字段", "跨字段", "field"):
        return "fields"
    return "document"


def _relation(left: Any, right: Any, compare: Any = "equal", across: Any = "document",
              source: str = "explicit", **extra) -> dict:
    rel = {
        "id": "",
        "left": _clean_operand(left),
        "right": _clean_operand(right),
        "compare": _norm_compare(compare) or "equal",
        "across": _norm_across(across),
        "source": source,
        "left_value": extra.get("left_value"),
        "right_value": extra.get("right_value"),
    }
    rel["complete"] = bool(
        rel["left"] and rel["right"]
        and rel["compare"] in RELATION_COMPARES
        and rel["across"] in RELATION_ACROSS
    )
    rel["self_consistency"] = bool(extra.get("self_consistency"))
    return rel


def _parse_relations_unguarded(slots: dict, category: str, criterion: str) -> list[dict]:
    """旧口径：判据文本可宽松兜底解析 relation（P0-7 前的行为，保留供开关回滚/A-B）。"""
    slots = dict(slots or {})
    rels: list[dict] = []

    def add(left, right, compare="equal", across="document", source="explicit", **extra):
        rel = _relation(left, right, compare, across, source, **extra)
        rel["id"] = f"rel-{len(rels) + 1}"
        rels.append(rel)

    # 1) 显式 relations / relation
    raw = slots.get("relations")
    if raw is None:
        raw = slots.get("relation")
    if isinstance(raw, dict):
        raw = [raw]
    elif isinstance(raw, str) and raw.strip():
        raw = [raw]
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, str):
                m = _REL_EQUAL_PAT.search(item) or _REL_EQ_PAT.search(item)
                if m:
                    add(m.group("left"), m.group("right"), "equal", "document", "explicit")
                continue
            if not isinstance(item, dict):
                continue
            left = (item.get("left") or item.get("a") or item.get("subject")
                    or item.get("source") or item.get("field"))
            right = (item.get("right") or item.get("b") or item.get("target")
                     or item.get("against") or item.get("source_of_truth"))
            add(left, right,
                item.get("compare") or item.get("op") or item.get("relation") or "equal",
                item.get("across") or item.get("scope") or "document",
                "explicit",
                left_value=item.get("left_value"), right_value=item.get("right_value"))

    # 2) 顶层 left/right
    if not rels and (slots.get("left") or slots.get("right")):
        add(slots.get("left"), slots.get("right"),
            slots.get("compare") or slots.get("relation_type") or "equal",
            slots.get("across") or "document", "explicit",
            left_value=slots.get("left_value"), right_value=slots.get("right_value"))

    # 3) objects 两个对象（第一个与第二个比较）
    if not rels:
        objs = slots.get("objects") or slots.get("compare_objects")
        if isinstance(objs, str):
            parts = [x.strip() for x in re.split(r"(?:与|和|及|、|,|，)", objs) if x.strip()]
        elif isinstance(objs, (list, tuple)):
            parts = [str(x).strip() for x in objs if str(x).strip()]
        else:
            parts = []
        if len(parts) >= 2:
            add(parts[0], parts[1],
                slots.get("compare") or slots.get("relation_type") or "equal",
                slots.get("across") or "document", "explicit")

    # 4) 引用一致：cited / source
    if not rels and str(category or "") == "citation":
        cited, source = slots.get("cited"), slots.get("source")
        if cited and source:
            add("引用标准", "标准文本", "equal", "document", "explicit")

    # 5) 从 criterion 解析（保守：必须同时识别到左右对象）
    if not rels and criterion:
        m = _REL_EQUAL_PAT.search(criterion)
        if m:
            # “A 与 B 不一致/不匹配”通常是缺陷描述或一致性要求，仍按“应一致”编译；
            # 真正的“必须不同”应显式写 compare=not_equal。
            add(m.group("left"), m.group("right"), "equal",
                slots.get("across") or "document", "criterion")
        else:
            m = _REL_EQ_PAT.search(criterion)
            if m:
                add(m.group("left"), m.group("right"), "equal",
                    slots.get("across") or "document", "criterion")

    # 6) 单对象一致性：“甲方名称必须一致”= 同一对象多次出现保持一致。
    #    这是 typed 的跨出现比对，不是把 criterion 原文当条件执行。
    if not rels and criterion:
        m_neg = re.search(
            r"(?P<object>[^，。；;:\n]{2,30}?)(?:不得|不应|禁止|严禁)"
            r"(?:出现|存在)?(?:不一致|不相符|不相同|不匹配)", criterion)
        if m_neg:
            obj = _clean_self_operand(m_neg.group("object"))
            if len(obj) >= 2:
                add(obj, obj, "equal", slots.get("across") or "document", "criterion", self_consistency=True)
    if not rels and criterion and not any(w in criterion for w in ("与", "和", "跟", "同")):
        m = _REL_SINGLE_PAT.search(criterion)
        if m:
            obj = _clean_self_operand(m.group("object"))
            if len(obj) >= 2 and obj not in ("保持", "一致", "统一", "相同"):
                add(obj, obj, "equal", slots.get("across") or "document", "criterion", self_consistency=True)
    return rels


# ---------------------------------------------------------------- R4：关系（P0-7 严格口径）
# T-181 P0-7：T-178 实测 8/8 生成规则被宽松正则把「判据句子碎片」静默编成 relations=1
# （如 left="③将评审条件中的范围、程序、数值" / right="采购需求中"；
#   left="比较不" / right="条款中的年限数值是否"）。
# 严格口径：解析不出**合法 typed relations** 时返回空，由 compile_rule 显式标
# execution_mode="semantic_stub" + relations=[] + compile_warnings，绝不伪造 relation。
# 开关 RULEPROOF_P0_IR_STRICT_RELATIONS 默认开；=0 恢复旧口径（供回滚/A-B）。
_P0_IR_STRICT_ENV = "RULEPROOF_P0_IR_STRICT_RELATIONS"
_REL_OPERAND_PROSE_WORDS = (
    "是否", "中的", "比较", "核对", "检查", "判断", "确认", "逐项", "提取",
    "定位", "步骤", "流程", "程序", "进行", "对于", "关于", "如果", "若",
    "以及", "或者", "其中", "上述", "并且", "同时", "将", "把",
)
_REL_OPERAND_BAD_TAIL = ("中", "时", "后", "前", "的", "里", "是否")


def _p0_ir_strict_enabled() -> bool:
    """P0-7 开关：默认开启严格口径；=0 回到旧口径（判据兜底宽松编 relation）。"""
    return str(os.environ.get(_P0_IR_STRICT_ENV, "1")).strip() not in (
        "0", "false", "off", "no")


def _relation_operand_ok(value) -> bool:
    """操作数是否像结构化对象名（而非判据句子碎片）。宁可拒绝，不得伪造。"""
    s = _clean_operand(value)
    if not s or len(s) < 2 or len(s) > 24:
        return False
    if s[0] in "①②③④⑤⑥⑦⑧⑨⑩（(【[「『“\"'":
        return False
    if re.match(r"^\d+\s*[.、）)]", s):
        return False
    if any(ch in s for ch in "、，；。：;\n"):
        return False
    if any(w in s for w in _REL_OPERAND_PROSE_WORDS):
        return False
    if s.endswith(_REL_OPERAND_BAD_TAIL):
        return False
    return True


def _relation_connector_ok(criterion: str, match) -> bool:
    """连接词不能是复合词的一部分（典型：「比较不同条款…」的「不同」被当「同」）。"""
    try:
        idx = match.start("right")
    except (IndexError, ValueError):
        return False
    if idx <= 0 or idx > len(criterion):
        return False
    ch = criterion[idx - 1]
    prev = criterion[idx - 2] if idx >= 2 else ""
    bad_prev = {"同": "不共相如会认赞同", "与": "参给赠",
                "和": "共总温缓", "跟": "脚后"}
    return prev not in bad_prev.get(ch, "")


def _criterion_relation_candidate(criterion: str):
    """从判据文本保守抽取 relation 候选；返回 (left, right) 或 None。"""
    for pat in (_REL_EQUAL_PAT, _REL_EQ_PAT):
        m = pat.search(criterion or "")
        if not m:
            continue
        if pat is _REL_EQUAL_PAT and not _relation_connector_ok(criterion, m):
            continue
        left, right = m.group("left"), m.group("right")
        if _relation_operand_ok(left) and _relation_operand_ok(right):
            return left, right
    return None


def _criterion_self_relation_candidate(criterion: str):
    """单对象一致性候选（跨出现比对）；返回 object 或 None。"""
    criterion = criterion or ""
    m_neg = re.search(
        r"(?P<object>[^，。；;:\n]{2,30}?)(?:不得|不应|禁止|严禁)"
        r"(?:出现|存在)?(?:不一致|不相符|不相同|不匹配)", criterion)
    if m_neg:
        obj = _clean_self_operand(m_neg.group("object"))
        if _relation_operand_ok(obj):
            return obj
    if criterion and not any(w in criterion for w in ("与", "和", "跟", "同")):
        m = _REL_SINGLE_PAT.search(criterion)
        if m:
            obj = _clean_self_operand(m.group("object"))
            if obj not in ("保持", "一致", "统一", "相同") and _relation_operand_ok(obj):
                return obj
    return None


def parse_relations_info(slots: dict, category: str, criterion: str,
                         strict: bool = None) -> dict:
    """解析 typed relations + 结构化警告（P0-7）。

    返回 ``{"relations": [...], "warnings": [...], "mode": ...}``（mode: typed/guarded/legacy/none）。
    严格口径（默认）：
      1) 显式 relations / left-right / objects / citation 是 typed 输入：只保留合法 part，
         不合法 part 丢弃并写警告（不静默、不伪造）；
      2) criterion 兜底只在「操作数像结构化对象名 + 连接词不是复合词碎片」时产出 relation；
         否则返回空 + 警告，由 compile_rule 标 ``semantic_stub``；
      3) 已有显式 relations 时不再从 criterion 兜底（避免混合/重复）。
    """
    slots = dict(slots or {})
    criterion = str(criterion or "")
    strict = _p0_ir_strict_enabled() if strict is None else bool(strict)
    warnings: list[str] = []
    if not strict:
        rels = _parse_relations_unguarded(slots, category, criterion)
        return {"relations": rels, "warnings": [], "mode": ("legacy" if rels else "none")}

    # 1) 显式 typed 输入（criterion 传空 → 只走 1–4 条显式路径）+ 合法性过滤
    explicit = _parse_relations_unguarded(slots, category, "")
    rels: list[dict] = []
    for rel in explicit:
        ok = bool(rel.get("complete")) and rel.get("compare") in RELATION_COMPARES \
            and rel.get("across") in RELATION_ACROSS
        if ok:
            rels.append(rel)
        else:
            warnings.append(
                "explicit_relation_invalid：%s|%s（缺左/右对象或比较方式非法，已丢弃，不伪造）"
                % (str(rel.get("left") or "")[:20], str(rel.get("right") or "")[:20]))
    if rels:
        for i, rel in enumerate(rels, 1):
            rel["id"] = f"rel-{i}"
        if criterion:
            warnings.append("criterion_relation_skipped：已有显式 relations，"
                            "未再从 criterion 兜底解析（避免混合/重复）")
        return {"relations": rels, "warnings": warnings, "mode": "typed"}

    # 2) criterion 兜底（保守：只认结构化片段）
    if criterion:
        cand = _criterion_relation_candidate(criterion)
        if cand:
            left, right = cand
            rel = _relation(left, right, "equal",
                            slots.get("across") or "document", "criterion")
            if rel.get("complete"):
                rel["id"] = "rel-1"
                return {"relations": [rel], "warnings": warnings, "mode": "guarded"}
        obj = _criterion_self_relation_candidate(criterion)
        if obj:
            rel = _relation(obj, obj, "equal",
                            slots.get("across") or "document", "criterion",
                            self_consistency=True)
            rel["id"] = "rel-1"
            return {"relations": [rel], "warnings": warnings, "mode": "guarded"}
        warnings.append(
            "criterion_relation_unstructured：判据为散文/未识别出合法的 left-right 对象，"
            "不伪造 relation（编译为 semantic_stub，交 agent-judge 或人工）")
    return {"relations": [], "warnings": warnings, "mode": "none"}


def parse_relations(slots: dict, category: str, criterion: str) -> list[dict]:
    """兼容旧 API：只返回 relations（严格口径下可能为空，调用方需处理空）。"""
    return list(parse_relations_info(slots, category, criterion).get("relations") or [])


# ---------------------------------------------------------------- R5：记录/程序

def _requirement(kind: str, **kw) -> dict:
    req = {"kind": str(kind or "").strip(), "supported": True}
    req.update({k: v for k, v in kw.items() if v not in (None, "", [], {})})
    return req


def _collect_fields(slots: dict) -> list[str]:
    out: list[str] = []
    for key in ("record_field", "record_fields", "required_fields", "fields",
                "date_field", "signature_field", "signer", "reviewer", "approver"):
        if key not in slots:
            continue
        val = slots.get(key)
        if isinstance(val, bool) or val in (None, ""):
            continue
        out.extend(_clean_term(x) for x in _split_terms(val))
    return list(dict.fromkeys([x for x in out if x]))


def _parse_record(slots: dict, criterion: str) -> list[dict]:
    reqs: list[dict] = []
    fields = _collect_fields(slots)
    for f in fields:
        if _compact(f) in {"是", "否", "true", "false"}:
            continue
        reqs.append(_requirement("field_present", field=f, required=True))
    signer = slots.get("signer")
    if signer and not isinstance(signer, bool):
        reqs.append(_requirement("signature", field="签字", signer=str(signer)))
    if slots.get("required") not in (None, "", True, False):
        for t in _split_terms(slots.get("required")):
            t = _clean_term(t)
            if t:
                reqs.append(_requirement("required_terms", terms=[t]))
    # criterion：由谁签字 / 必须签字
    if criterion:
        m = re.search(r"由(?P<signer>[^，。；;:\s]{2,12}?)(?:签字|签名|签署|复核|审核)", criterion)
        if m:
            reqs.append(_requirement("signature", field="签字", signer=m.group("signer").strip()))
        for action in ("签字", "签名", "签署", "盖章", "填写", "登记", "注明", "标注"):
            if action in criterion:
                if not any(r.get("kind") == "signature" and r.get("field") == action for r in reqs):
                    reqs.append(_requirement("field_present", field=action, required=True))
    return reqs


def _parse_frequency_text(criterion: str) -> dict:
    period = ""
    m = re.search(r"(每(?:一)?(?:批|天|日|周|月|次|班|小时|年|季度)|每日|每周|每月|每批|每班|每年|定期)", criterion)
    if m:
        period = m.group(1)
    count = None
    mc = re.search(r"(?:至少|不少于)?\s*(\d+)\s*次", criterion)
    if mc:
        count = int(mc.group(1))
    action = ""
    if period and m:
        pre = criterion[:m.start()]
        pre = re.sub(r"(?:必须|应当|应|需|须|要|保证|确保|要求)+$", "", pre.strip())
        am = re.search(r"([\u4e00-\u9fa5A-Za-z]{2,12})$", pre)
        if am:
            action = am.group(1)
        if not action:
            post = criterion[m.end():]
            am = re.search(r"^([\u4e00-\u9fa5A-Za-z]{2,12}?)(?:一次|1次|至少|不少于|[，。；;]|$)", post.strip())
            if am:
                action = am.group(1)
    return {"action": action, "period": period, "min_count": count}


def _parse_format(slots: dict, criterion: str) -> list[dict]:
    reqs: list[dict] = []
    pattern = slots.get("pattern") or slots.get("format_pattern") or slots.get("regex")
    if pattern:
        reqs.append(_requirement("pattern", pattern=str(pattern)))
    raw = slots.get("format_rules") or slots.get("format")
    if isinstance(raw, dict):
        raw = [raw]
    if isinstance(raw, str):
        raw = [raw]
    for item in raw or []:
        if isinstance(item, dict):
            reqs.append(_requirement(item.get("kind") or "format",
                                     format=item.get("format") or item.get("name"),
                                     pattern=item.get("pattern"), field=item.get("field")))
        elif str(item).strip():
            s = str(item).strip()
            if "序号" in s and any(w in s for w in ("连续", "顺序", "递增")):
                reqs.append(_requirement("sequence", field="序号"))
            elif any(w in s for w in ("不得为空", "不得留空", "不得空缺")):
                reqs.append(_requirement("no_empty", field="字段"))
            elif any(w in s for w in ("^", "$", "\\d", "\\w")):
                reqs.append(_requirement("pattern", pattern=s))
            else:
                reqs.append(_requirement("format", format=s))
    if criterion:
        m = re.search(r"格式(?:必须|应当|应|需)?(?:为|是)\s*(?P<fmt>[A-Za-z0-9\-年月日/\.]{3,20})", criterion)
        if m:
            reqs.append(_requirement("format", format=m.group("fmt").strip()))
        m = re.search(r"(?P<field>[\u4e00-\u9fa5A-Za-z0-9]{2,12})(?:必须|应当|应|需)?"
                      r"(?:连续|顺序递增|按顺序|不得跳号)", criterion)
        if m:
            reqs.append(_requirement("sequence", field=m.group("field").strip()))
        m = re.search(r"(?P<field>[\u4e00-\u9fa5A-Za-z0-9]{2,12})不得(?:为空|留空|空缺)", criterion)
        if m:
            reqs.append(_requirement("no_empty", field=m.group("field").strip()))
    return reqs


def _clean_term(value: Any) -> str:
    s = _text(value)
    s = re.sub(r"^(?:必须|应当|应|须|需|需要|要求)?"
               r"(?:包含|提交|提供|附上|附|出具|具备|含有)+", "", s)
    return s.strip(" 的，,。;；:：")


def _clean_step(value: str) -> str:
    s = _text(value)
    s = re.sub(r"^(?:进行|完成|经过|做好|开展|实施|先|再|然后|最后)+", "", s)
    s = re.sub(r"(?:处理|工作|操作)+$", "", s)
    return s.strip(" 的，,。;；")


def _parse_preprocess(slots: dict, criterion: str) -> list[dict]:
    reqs: list[dict] = []
    raw = (slots.get("steps") or slots.get("operations") or slots.get("required_steps")
           or slots.get("process_steps"))
    steps = _split_terms(raw)
    if len(steps) == 1 and any(w in steps[0] for w in ("并", "→", "->", "和", "及")):
        steps = [_clean_step(x) for x in
                 re.split(r"(?:并|、|和|及|→|->|；|;)+", steps[0])]
        steps = [x for x in steps if x]
    if not steps and criterion:
        m = re.search(r"(?:必须|应当|应|需|须)(?P<body>[^，。；;]{2,60})", criterion)
        body = m.group("body") if m else ""
        if body:
            steps = [_clean_step(x) for x in re.split(r"(?:并|、|和|及|→|->|；|;)+", body)]
            steps = [x for x in steps if 2 <= len(x) <= 16 and
                     x not in ("符合要求", "满足要求", "按规定", "按要求", "相关要求")]
    if steps:
        reqs.append(_requirement("step_present", steps=steps, ordered=True))
    return reqs


def _generic_requirements(slots: dict) -> list[dict]:
    reqs: list[dict] = []
    if slots.get("require"):
        reqs.append(_requirement("required_terms", terms=_split_terms(slots.get("require"))))
    if slots.get("require_any"):
        reqs.append(_requirement("required_any_terms", terms=_split_terms(slots.get("require_any"))))
    if slots.get("forbid") or slots.get("forbidden"):
        reqs.append(_requirement("forbidden_terms",
                                 terms=_split_terms(slots.get("forbid") or slots.get("forbidden"))))
    if slots.get("pattern"):
        reqs.append(_requirement("pattern", pattern=str(slots.get("pattern"))))
    if slots.get("keywords"):
        kws = _split_terms(slots.get("keywords"))
        if kws:
            reqs.append(_requirement("required_any_terms", terms=kws))
    if slots.get("terms"):
        reqs.append(_requirement("required_terms", terms=_split_terms(slots.get("terms"))))
    return reqs


def parse_procedure(slots: dict, category: str, criterion: str) -> dict:
    slots = dict(slots or {})
    category = _text(category) or "procedural"
    kind = category if category in PROCEDURE_KINDS else "procedural"
    reqs: list[dict] = []
    warnings: list[str] = []
    source = "explicit"

    # 1) 显式 procedure / requirements
    raw = slots.get("procedure")
    if isinstance(raw, dict):
        kind = _text(raw.get("kind") or raw.get("type")) or kind
        raw_reqs = raw.get("requirements") or raw.get("items") or []
    elif isinstance(raw, list):
        raw_reqs = raw
    else:
        raw_reqs = slots.get("procedure_requirements") or slots.get("requirements") or []
    if isinstance(raw_reqs, str):
        raw_reqs = _split_terms(raw_reqs)
    elif isinstance(raw_reqs, dict):
        raw_reqs = [raw_reqs]
    for item in raw_reqs or []:
        if isinstance(item, str):
            reqs.append(_requirement("required_terms", terms=[item]))
        elif isinstance(item, dict):
            k = _text(item.get("kind") or item.get("type") or "required_terms")
            payload = dict(item)
            payload.pop("kind", None)
            payload.pop("type", None)
            req = _requirement(k, **payload)
            req["supported"] = k in _SUPPORTED_REQUIREMENT_KINDS
            reqs.append(req)

    # 2) 分类模板字段
    if category == "record":
        reqs.extend(_parse_record(slots, criterion))
        if "每" in criterion:
            warnings.append("record_frequency_observed")
    elif category == "frequency":
        action = slots.get("action") or slots.get("task")
        period = slots.get("frequency") or slots.get("period")
        window = slots.get("window") or slots.get("time_window")
        count = slots.get("count") or slots.get("min_count")
        if action or period:
            reqs.append(_requirement("frequency", action=action, period=period,
                                     window=window, min_count=count))
        else:
            parsed = _parse_frequency_text(criterion)
            if parsed.get("action") or parsed.get("period"):
                reqs.append(_requirement("frequency", **parsed))
                source = "criterion"
    elif category == "format":
        reqs.extend(_parse_format(slots, criterion))
        if any(r.get("kind") in ("sequence", "no_empty", "format") and r.get("source") != "explicit"
               for r in reqs):
            source = "criterion"
    elif category == "preprocess":
        reqs.extend(_parse_preprocess(slots, criterion))
        if reqs and not (slots.get("steps") or slots.get("operations")
                         or slots.get("required_steps") or slots.get("process_steps")):
            source = "criterion"
    else:
        # 自定义/通用程序类：按显式槽位推断，不猜自由文本。
        if any(slots.get(k) for k in ("record_field", "record_fields", "required_fields",
                                      "fields", "signer", "reviewer", "approver")):
            kind = "record"
            reqs.extend(_parse_record(slots, criterion))
        elif any(slots.get(k) for k in ("action", "task", "frequency", "period",
                                        "window", "time_window")):
            kind = "frequency"
            action = slots.get("action") or slots.get("task")
            period = slots.get("frequency") or slots.get("period")
            window = slots.get("window") or slots.get("time_window")
            count = slots.get("count") or slots.get("min_count")
            if action or period:
                reqs.append(_requirement("frequency", action=action, period=period,
                                         window=window, min_count=count))
        elif any(slots.get(k) for k in ("steps", "operations", "required_steps", "process_steps")):
            kind = "preprocess"
            reqs.extend(_parse_preprocess(slots, criterion))
        elif any(slots.get(k) for k in ("format", "format_rules", "pattern",
                                        "format_pattern", "regex")):
            kind = "format"
            reqs.extend(_parse_format(slots, criterion))

    # 3) 通用结构化条件（显式 require/forbid/pattern/terms）
    reqs.extend(_generic_requirements(slots))
    reqs = _dedup(reqs, ("kind", "field", "pattern", "format"))
    for r in reqs:
        if r.get("kind") not in _SUPPORTED_REQUIREMENT_KINDS:
            r["supported"] = False
    if not reqs and slots.get("_terms"):
        # rule_schema 抽出的要素只在没有任何显式过程字段时兜底，并且是 typed terms，
        # 不是把 criterion 原文当条件。
        terms = _split_terms(slots.get("_terms"))
        if terms:
            reqs.append(_requirement("required_terms", terms=terms))
            source = "criterion"

    subject = ""
    for key in ("record_field", "equipment", "role", "item", "action", "subject", "object"):
        if _text(slots.get(key)):
            subject = _text(slots.get(key))
            break
    if not subject and criterion:
        m = re.match(r"\s*([^，。；;]{2,24}?)(?:必须|应当|应|须|需)", criterion)
        subject = (m.group(1).strip() if m else "")

    if category == "frequency" or slots.get("frequency") or slots.get("period"):
        freq_meta = _parse_frequency_text(criterion) if criterion else {}
    else:
        freq_meta = {}
    return {
        "kind": kind,
        "subject": subject,
        "requirements": reqs,
        "frequency": freq_meta if (freq_meta.get("action") or freq_meta.get("period")) else {},
        "source": source,
        "warnings": warnings,
    }


def parse_requirements(slots: dict, category: str, criterion: str) -> list[dict]:
    """R3/R1/R2 的确定性要素（不是 criterion 原文）。"""
    slots = dict(slots or {})
    reqs: list[dict] = []
    cat = _text(category)
    if cat == "completeness":
        for key in ("required_docs", "required_documents", "docs", "required"):
            if slots.get(key) not in (None, "", True, False):
                terms = [_clean_term(x) for x in _split_terms(slots.get(key), split_and=True)]
                terms = [x for x in terms if x]
                if terms:
                    reqs.append(_requirement("required_terms", terms=terms))
                    break
    elif cat == "personnel":
        vals = [slots.get("role"), slots.get("qualification"), slots.get("cert")]
        if any(v not in (None, "") for v in vals):
            reqs.append(_requirement("required_terms", terms=_split_terms([v for v in vals if v])))
    elif cat == "equipment":
        vals = [slots.get("equipment"), slots.get("state")]
        if any(v not in (None, "") for v in vals):
            reqs.append(_requirement("required_terms", terms=_split_terms([v for v in vals if v])))
    elif cat == "label":
        vals = [slots.get("item")]
        if slots.get("label_required") not in (None, "", True, False):
            lv = _text(slots.get("label_required"))
            if lv.lower() not in ("是", "否", "true", "false", "yes", "no"):
                vals.append(lv)
        if any(v not in (None, "") for v in vals):
            reqs.append(_requirement("required_terms", terms=_split_terms([v for v in vals if v])))
    reqs.extend(_generic_requirements(slots))
    if not reqs and slots.get("_terms"):
        terms = _split_terms(slots.get("_terms"))
        if terms:
            reqs.append(_requirement("required_terms", terms=terms))
    return _dedup(reqs, ("kind", "field", "pattern", "format"))


_SUPPORTED_REQUIREMENT_KINDS = {
    "field_present", "signature", "required_terms", "required_any_terms",
    "forbidden_terms", "pattern", "frequency", "sequence", "step_present",
    "no_empty", "format", "term_present", "approval",
}


# ---------------------------------------------------------------- 语义

def parse_semantic(criterion: str, subject: str, effect: str,
                   evidence: list[dict], on_insufficient: str) -> dict:
    crit = _text(criterion)
    if not crit:
        return {}
    return {
        "predicate": crit,
        "subject": _text(subject),
        "effect": _text(effect) or "require",
        "evidence_terms": [e.get("term") for e in evidence if e.get("term")],
        "quote_required": True,
        "judge": "agent-judge",
        "on_insufficient": _text(on_insufficient) or "abstain",
        "instructions": "只依据文档原文/引文判定；不得把自由文本当作确定性条件；"
                        "证据不足时返回 insufficient，不得臆断。",
    }


def semantic_payload(ir: dict) -> dict:
    ir = dict(ir or {})
    sem = dict(ir.get("semantic") or {})
    return {
        "task": "judge_rule",
        "code": ir.get("code") or "",
        "name": ir.get("name") or "",
        "nature": ir.get("nature") or "",
        "family": ir.get("rule_family") or "",
        "subject": sem.get("subject") or ir.get("subject") or "",
        "predicate": sem.get("predicate") or ir.get("predicate") or "",
        "effect": sem.get("effect") or ir.get("effect") or "",
        "scope": ir.get("scope") or "",
        "applicable_types": list(ir.get("applicable_types") or []),
        "applicable_when": list(ir.get("applicable_when") or []),
        "execution_mode": ir.get("execution_mode") or "",
        "evidence": [e.get("term") for e in (ir.get("evidence_contract") or []) if e.get("term")],
        "exceptions": list(ir.get("exceptions") or []),
        "on_insufficient": sem.get("on_insufficient") or ir.get("on_insufficient") or "abstain",
        "quote_required": bool(sem.get("quote_required", True)),
        "instructions": sem.get("instructions") or "",
    }


# ---------------------------------------------------------------- 合同/发布门禁

def _issue(code: str, field: str, message: str, hint: str = "", blocking: bool = True) -> dict:
    return {"code": code, "field": field, "message": message, "hint": hint, "blocking": bool(blocking)}


def _fmt_error(issue: dict) -> str:
    msg = f"{issue['code']}：{issue['message']}"
    if issue.get("hint"):
        msg += f"（建议：{issue['hint']}）"
    return msg


def build_contract(facts: dict) -> dict:
    """生成 contract_errors / publishable / executable / execution_level。

    facts 是 compile_rule 已编译出的共同字段与 typed 条件，不读数据库。
    """
    facts = dict(facts or {})
    family = _text(facts.get("family"))
    criterion = _text(facts.get("criterion"))
    evidence = list(facts.get("evidence") or [])
    scope_declared = bool(facts.get("scope_declared"))
    relations = list(facts.get("relations") or [])
    procedure = dict(facts.get("procedure") or {})
    semantic = dict(facts.get("semantic") or {})
    requirements = list(facts.get("requirements") or [])
    structured = bool(facts.get("structured"))
    metric = _text(facts.get("metric"))
    has_value = facts.get("has_value")
    complete = bool(facts.get("complete"))
    on_insufficient = _text(facts.get("on_insufficient") or "abstain")
    old_level = _text(facts.get("old_level"))
    tax_errors = list(facts.get("tax_errors") or [])
    warnings = list(facts.get("warnings") or [])

    issues: list[dict] = []

    if not complete:
        issues.append(_issue("requirement_missing", "criterion",
                             "缺少业务要求/判据，无法形成可执行规则",
                             "补充 criterion 或结构化条件（metric/op/value 等）"))

    if family in ("R3", "R4", "R5"):
        if not evidence:
            issues.append(_issue("evidence_missing", "required_evidence",
                                 f"{family_label(family)}规则缺少 required_evidence，无法绑定证据",
                                 "补充 required_evidence（如合同首部/签字页/表格字段）"))
        if not scope_declared:
            issues.append(_issue("scope_missing", "applicable_when",
                                 "规则未声明适用范围（applicable_types/applicable_when），不能发布",
                                 "补充适用文件类型或业务范围，避免默认全量执行"))
        if on_insufficient not in FALLBACKS:
            issues.append(_issue("on_insufficient_invalid", "on_insufficient",
                                 f"无法判断处理取值不支持：{on_insufficient}（可用 {', '.join(FALLBACKS)}）",
                                 "改为 abstain/ask/fail/single_block_first"))

    if family == "R3":
        executable = bool(criterion or requirements or semantic)
        if not executable:
            issues.append(_issue("requirement_missing", "criterion",
                                 "语义/证据规则没有判据或结构化要素",
                                 "补充 criterion 或 required_docs/role/equipment/label 等"))
        if criterion and not semantic:
            warnings.append("R3 语义判据未生成 semantic payload")
        if semantic:
            warnings.append("semantic_judge_required：R3 语义判据由 agent-judge 执行，"
                            "typed IR 只提供判据/证据/引文契约")
        level = ("needs_structure" if (not complete or not executable)
                 else ("semantic_complete" if criterion else "deterministic"))

    elif family == "R4":
        valid = [r for r in relations if r.get("complete")]
        unsupported = [r for r in relations if r.get("compare") not in RELATION_COMPARES
                       or r.get("across") not in RELATION_ACROSS]
        if not relations:
            issues.append(_issue("relation_operands_missing", "relations",
                                 "关系/一致规则只有自由文本，未识别到可比较的两个对象，不能直接执行",
                                 "补充 left/right（或 relations/objects=[左,右]）"))
            if criterion:
                issues.append(_issue("free_text_not_typed", "criterion",
                                     "自由文本判据未编译为关系 typed 条件",
                                     "把判据改写为“A 与 B 一致/等于”或显式 left/right"))
        elif len(valid) != len(relations):
            issues.append(_issue("relation_operands_missing", "relations",
                                 "关系条件缺少左/右对象或比较方式，无法执行",
                                 "补齐每个 relation 的 left/right/compare/across"))
        if unsupported:
            issues.append(_issue("relation_unsupported", "relations",
                                 "存在不支持的关系比较方式/范围",
                                 f"可用 {', '.join(RELATION_COMPARES)} / {', '.join(RELATION_ACROSS)}"))
        executable = bool(relations) and len(valid) == len(relations) and not unsupported
        level = "deterministic" if executable else "needs_structure"

    elif family == "R5":
        reqs = list(procedure.get("requirements") or [])
        bad = [r for r in reqs if not r.get("supported", True)]
        if not reqs:
            issues.append(_issue("procedure_requirements_missing", "procedure",
                                 "记录/程序规则只有自由文本，未编译出字段/频次/步骤/格式条件，不能直接执行",
                                 "补充 record_field/action+frequency/steps/pattern 等结构化要求"))
            if criterion:
                issues.append(_issue("free_text_not_typed", "criterion",
                                     "自由文本判据未编译为过程 typed 条件",
                                     "把判据改写为“每批记录由复核人签字”“序号连续”等可检查形式"))
        if bad:
            issues.append(_issue("procedure_kind_unsupported", "procedure",
                                 "存在不支持的过程条件类型",
                                 f"可用 {', '.join(sorted(_SUPPORTED_REQUIREMENT_KINDS))}"))
        executable = bool(reqs) and not bad
        level = "deterministic" if executable else "needs_structure"

    else:
        # R1/R2 保持既有发布口径：结构化阈值/关键词可发布；纯文本需证据+范围。
        executable = bool(
            (metric and has_value) or structured
            or (criterion and evidence and scope_declared)
            or old_level == "deterministic"
        )
        level = old_level or ("deterministic" if (metric and has_value) else "needs_structure")

    for msg in tax_errors:
        issues.append(_issue("tax_source_missing", "tool", str(msg), "补齐税额工具来源字段"))

    blocking = [i for i in issues if i.get("blocking")]
    if family in ("R3", "R4", "R5"):
        publishable = bool(complete and executable and not blocking)
        free_text_only = bool(criterion) and (
            (family == "R4" and not relations) or (family == "R5" and not (procedure.get("requirements")))
        )
    else:
        publishable = bool(complete and old_level in ("deterministic", "semantic_complete") and not blocking)
        free_text_only = False

    missing: list[str] = []
    if any(i["code"] == "requirement_missing" for i in issues):
        missing.append("判据")
    if any(i["code"] == "evidence_missing" for i in issues):
        missing.append("证据要求")
    if any(i["code"] == "scope_missing" for i in issues):
        missing.append("适用范围")
    if any(i["code"] == "relation_operands_missing" for i in issues):
        missing.append("关系对象")
    if any(i["code"] == "procedure_requirements_missing" for i in issues):
        missing.append("过程要求")
    if any(i["code"] == "free_text_not_typed" for i in issues):
        missing.append("typed 条件")
    if any(i["code"] == "on_insufficient_invalid" for i in issues):
        missing.append("无法判断处理")
    if any(i["code"] == "tax_source_missing" for i in issues):
        missing.append("工具来源")
    missing = list(dict.fromkeys(missing))

    suggestions = []
    for i in issues:
        if i.get("hint") and i["hint"] not in suggestions:
            suggestions.append(i["hint"])

    return {
        "issues": issues,
        "blocking": blocking,
        "errors": [_fmt_error(i) for i in issues],
        "publishable": publishable,
        "executable": executable,
        "execution_level": level,
        "free_text_only": free_text_only,
        "missing": missing,
        "suggestions": suggestions,
        "warnings": list(dict.fromkeys(warnings)),
    }


# ---------------------------------------------------------------- 执行器

def _res(state: str, code: str, detail: str = "", *, quote: str = "",
         value: Any = None, needs_model: bool = False, trace: dict | None = None) -> dict:
    if state not in STATES:
        state = "执行失败"
    return {"state": state, "code": code, "detail": detail, "quote": quote or "",
            "value": value, "needs_model": bool(needs_model), "trace": dict(trace or {})}


def _contains(text: Any, term: Any) -> bool:
    t, n = _compact(term), _compact(text)
    return bool(t) and t in n


def _find_quote(text: Any, term: Any) -> str:
    raw = str(text or "")
    hit = _compact(term)
    for line in raw.splitlines():
        if hit and hit in _compact(line):
            return line.strip()[:120]
    if hit and hit in _compact(raw):
        return raw.strip()[:120]
    return ""


def _extract_labeled_value(text: Any, label: Any) -> tuple[str, str]:
    raw = str(text or "")
    lab = _text(label)
    if not raw or not lab:
        return "", ""
    labels = [lab]
    base = re.sub(r"(?:名称|信息|主体|字段|编号|号码|内容)$", "", lab)
    if base and base != lab and len(base) >= 2:
        labels.append(base)
    for name in labels:
        esc = re.escape(name)
        patterns = [
            re.compile(rf"{esc}\s*(?:[（(][^）)]*[）)])?\s*[)）]?\s*[：:]\s*([^\n；;。]+)"),
            re.compile(rf"{esc}\s*(?:应为|必须为|为|是|等于)\s*([^\n；;。]+)"),
            re.compile(rf"{esc}\s*[\|｜\t]\s*([^\n；;。]+)"),
        ]
        for pat in patterns:
            m = pat.search(raw)
            if m:
                val = m.group(1).strip().strip("，,。.;；:： \t")
                if val:
                    return val, m.group(0).strip()[:120]
    return "", ""


def _extract_all_labeled_values(text: Any, label: Any) -> list[str]:
    """取同一标签的所有出现值（单对象一致性用）。"""
    raw = str(text or "")
    lab = _text(label)
    if not raw or not lab:
        return []
    labels = [lab]
    base = re.sub(r"(?:名称|信息|主体|字段|编号|号码|内容)$", "", lab)
    if base and base != lab and len(base) >= 2:
        labels.append(base)
    for name in labels:
        esc = re.escape(name)
        vals = []
        for m in re.finditer(
                rf"{esc}\s*(?:[（(][^）)]*[）)])?\s*[)）]?\s*[：:]\s*([^\n；;。]+)", raw):
            val = m.group(1).strip().strip("，,。.;；:： \t")
            if val:
                vals.append(val)
        if vals:
            return vals
    return []


def _fact_values(facts: Any, label: Any) -> list:
    """facts 里同一标签的所有值。"""
    if not facts:
        return []
    key = _compact(label)
    vals = []
    if isinstance(facts, dict):
        for k, v in facts.items():
            if _compact(k) == key:
                fv = _fact_value(v)
                if isinstance(fv, (list, tuple)):
                    vals.extend(fv)
                elif fv not in (None, ""):
                    vals.append(fv)
    elif isinstance(facts, (list, tuple)):
        for row in facts:
            d = row.to_dict() if hasattr(row, "to_dict") else row
            if not isinstance(d, dict):
                continue
            for k in ("label", "name", "field", "key", "object"):
                if k in d and _compact(d.get(k)) == key:
                    fv = _fact_value(d.get("value", d.get("text", "")))
                    if fv not in (None, ""):
                        vals.append(fv)
                    break
            else:
                for k, v in d.items():
                    if _compact(k) == key:
                        fv = _fact_value(v)
                        if fv not in (None, ""):
                            vals.append(fv)
    return vals


def _fact_value(value: Any) -> Any:
    if isinstance(value, dict):
        return value.get("value", value.get("text", value.get("normalized_value")))
    return value


def _fact_lookup(facts: Any, label: Any) -> tuple[Any, str]:
    if not facts:
        return None, ""
    key = _compact(label)
    if isinstance(facts, dict):
        for k, v in facts.items():
            if _compact(k) == key:
                return _fact_value(v), f"{k}={_fact_value(v)}"
    if isinstance(facts, (list, tuple)):
        for row in facts:
            d = row.to_dict() if hasattr(row, "to_dict") else row
            if not isinstance(d, dict):
                continue
            for k in ("label", "name", "field", "key", "object"):
                if k in d and _compact(d.get(k)) == key:
                    return _fact_value(d.get("value", d.get("text", ""))), f"{label}={d.get('value')}"
            for k, v in d.items():
                if _compact(k) == key:
                    return _fact_value(v), f"{k}={_fact_value(v)}"
    return None, ""


def _resolve_operand(rel: dict, side: str, text: Any, facts: Any) -> tuple[Any, str]:
    label = _text(rel.get(side))
    literal = rel.get(f"{side}_value")
    if literal not in (None, ""):
        return literal, f"规则给定 {label}={literal}"
    fv, fq = _fact_lookup(facts, label)
    if fv not in (None, ""):
        return fv, fq
    if text:
        val, quote = _extract_labeled_value(text, label)
        if val:
            return val, quote
    return None, ""


def _version_tuple(value: Any) -> tuple:
    nums = re.findall(r"\d+", str(value or ""))
    return tuple(int(x) for x in nums)


def _compare_values(left: Any, right: Any, compare: str) -> bool | None:
    if compare in ("equal", "same"):
        ln, rn = _num(left), _num(right)
        if ln is not None and rn is not None:
            return abs(ln - rn) < 1e-9
        return _compact(left) == _compact(right)
    if compare == "not_equal":
        eq = _compare_values(left, right, "equal")
        return None if eq is None else (not eq)
    if compare == "contains":
        return _compact(right) in _compact(left)
    if compare == "not_contains":
        return _compact(right) not in _compact(left)
    if compare == "version_equal":
        return _version_tuple(left) == _version_tuple(right)
    return None


def _combine_results(results: list[dict], combination: str = "all") -> dict:
    if not results:
        return _res("执行失败", "no_conditions", "没有可执行条件")
    states = [r.get("state") for r in results]
    if any(x == "执行失败" for x in states):
        first = next(r for r in results if r.get("state") == "执行失败")
        return _res("执行失败", first.get("code") or "condition_failed", first.get("detail") or "",
                    quote=first.get("quote") or "", trace={"results": results})
    if combination == "any":
        if any(x == "满足" for x in states):
            ok = next(r for r in results if r.get("state") == "满足")
            return _res("满足", ok.get("code") or "any_satisfied", ok.get("detail") or "",
                        quote=ok.get("quote") or "", trace={"results": results})
        if any(x == "证据不足" for x in states):
            first = next(r for r in results if r.get("state") == "证据不足")
            return _res("证据不足", first.get("code") or "evidence_insufficient",
                        first.get("detail") or "", quote=first.get("quote") or "",
                        trace={"results": results})
        return _res("不满足", "all_failed", "any 条件下全部不满足", trace={"results": results})
    bad = [r for r in results if r.get("state") == "不满足"]
    if bad:
        first = bad[0]
        reason = first.get("detail") or "条件不满足"
        if len(bad) > 1:
            reason += f"（另有 {len(bad) - 1} 项不满足）"
        return _res("不满足", first.get("code") or "condition_failed", reason,
                    quote=first.get("quote") or "", trace={"results": results})
    unknown = [r for r in results if r.get("state") == "证据不足"]
    if unknown:
        first = unknown[0]
        return _res("证据不足", first.get("code") or "evidence_insufficient",
                    first.get("detail") or "", quote=first.get("quote") or "",
                    trace={"results": results})
    first = results[0]
    return _res("满足", "all_satisfied", f"{len(results)} 项条件均满足",
                quote=first.get("quote") or "", trace={"results": results})


def _check_evidence(ir: dict, text: Any, facts: Any) -> list[str]:
    missing = []
    for item in ir.get("evidence_contract") or []:
        if isinstance(item, dict) and item.get("required") is False:
            continue
        term = _text(item.get("term") if isinstance(item, dict) else item)
        if not term:
            continue
        if text and _contains(text, term):
            continue
        fv, _ = _fact_lookup(facts, term)
        if fv not in (None, ""):
            continue
        missing.append(term)
    return missing


def _eval_limit(ir: dict, text: Any, facts: Any) -> dict:
    try:
        from ..engine import ruleexec
        slots = {
            "metric": ir.get("metric"), "op": ir.get("operator"),
            "value": ir.get("threshold"), "unit": ir.get("unit"),
            "scope": ir.get("scope") or "",
            # L5 段1 区间算子 op=range：把 IR 的 range/lo/hi 透传给执行器，执行侧仍复用
            # ruleexec.judge_limit 的既有比较（闭区间 lo<=x<=hi），不新增执行器。
            "range": ir.get("range"), "lo": ir.get("lo"), "hi": ir.get("hi"),
        }
        r = ruleexec.judge_rule(slots, str(text or ""),
                                facts if isinstance(facts, list) else [])
        state = str(r.get("state") or "执行失败")
        code = {"满足": "ok", "不满足": "limit_exceeded",
                "证据不足": "evidence_insufficient", "不适用": "not_applicable",
                "执行失败": "execution_failed"}.get(state, "execution_failed")
        return _res(state, code, str(r.get("detail") or ""), quote=str(r.get("quote") or ""),
                    value=r.get("value"), trace={"executor": "engine.ruleexec"})
    except Exception as exc:  # noqa: BLE001
        return _res("执行失败", "executor_error", f"{type(exc).__name__}: {exc}")


def _eval_requirement(req: dict, text: Any) -> dict:
    kind = _text(req.get("kind"))
    raw = str(text or "")
    if not raw.strip():
        return _res("证据不足", "empty_document", "没有可检查的文档文本")

    if kind in ("field_present", "term_present"):
        field = _text(req.get("field"))
        if not field:
            return _res("执行失败", "field_missing", "条件缺少 field")
        candidates = [field]
        if field in ("签字", "签名", "签署"):
            candidates = ["签字", "签名", "签署"]
        hit = next((x for x in candidates if _contains(raw, x)), "")
        if hit:
            return _res("满足", "present", f"包含「{hit}」", quote=_find_quote(raw, hit))
        return _res("不满足", "field_missing_value", f"缺少「{field}」")

    if kind in ("signature", "approval"):
        action = _text(req.get("field")) or "签字"
        signer = _text(req.get("signer"))
        actions = (["签字", "签名", "签署"] if action in ("签字", "签名", "签署")
                   else [action])
        hit = next((x for x in actions if _contains(raw, x)), "")
        if not hit:
            return _res("不满足", "signature_missing", f"缺少「{action}」")
        if signer and not _contains(raw, signer):
            return _res("不满足", "signer_missing", f"缺少签署人「{signer}」")
        quote = _find_quote(raw, signer or hit)
        who = f"签署人{signer}" if signer else f"「{hit}」"
        return _res("满足", "signature_ok", f"存在{who}", quote=quote)

    if kind == "required_terms":
        terms = _split_terms(req.get("terms"))
        if not terms:
            return _res("执行失败", "terms_missing", "条件缺少 terms")
        missing = [t for t in terms if not _contains(raw, t)]
        if missing:
            return _res("不满足", "terms_missing_value", "缺少：" + "、".join(missing))
        return _res("满足", "terms_ok", "要素齐全：" + "、".join(terms),
                    quote=_find_quote(raw, terms[0]))

    if kind == "required_any_terms":
        terms = _split_terms(req.get("terms"))
        if not terms:
            return _res("执行失败", "terms_missing", "条件缺少 terms")
        hit = next((t for t in terms if _contains(raw, t)), "")
        if hit:
            return _res("满足", "any_term_ok", f"命中「{hit}」", quote=_find_quote(raw, hit))
        return _res("不满足", "any_term_missing", "未命中任一：" + "、".join(terms))

    if kind == "forbidden_terms":
        terms = _split_terms(req.get("terms"))
        if not terms:
            return _res("执行失败", "terms_missing", "条件缺少 terms")
        hit = next((t for t in terms if _contains(raw, t)), "")
        if hit:
            return _res("不满足", "forbidden_present", f"出现禁止内容「{hit}」",
                        quote=_find_quote(raw, hit))
        return _res("满足", "forbidden_absent", "未出现禁止内容")

    if kind == "pattern":
        pattern = str(req.get("pattern") or "")
        if not pattern:
            return _res("执行失败", "pattern_missing", "条件缺少 pattern")
        try:
            m = re.search(pattern, raw, re.MULTILINE)
        except re.error as exc:
            return _res("执行失败", "pattern_invalid", f"正则非法：{exc}")
        if m:
            return _res("满足", "pattern_ok", "命中格式", quote=m.group(0)[:120])
        return _res("不满足", "pattern_missing_value", "未命中规定格式")

    if kind == "frequency":
        action = _text(req.get("action"))
        period = _text(req.get("period") or req.get("frequency"))
        window = _text(req.get("window"))
        min_count = req.get("min_count")
        if not action and not period:
            return _res("执行失败", "frequency_missing", "频次条件缺少 action/period")
        for label, term in (("频次", period), ("动作", action), ("周期窗口", window)):
            if term and not _contains(raw, term):
                return _res("不满足", "frequency_missing_value", f"缺少{label}「{term}」")
        try:
            need = int(min_count) if min_count not in (None, "") else 1
        except Exception:
            need = 1
        count = len(re.findall(re.escape(action or period), raw))
        if count < need:
            return _res("不满足", "frequency_count_short",
                        f"「{action or period}」仅出现 {count} 次，要求至少 {need} 次")
        return _res("满足", "frequency_ok", f"频次满足（{count} 次）",
                    quote=_find_quote(raw, action or period))

    if kind == "sequence":
        field = _text(req.get("field"))
        if not field:
            return _res("执行失败", "field_missing", "序号条件缺少 field")
        nums: list[int] = []
        for line in raw.splitlines():
            if _contains(line, field):
                nums.extend(int(x) for x in re.findall(r"\d+", line))
        if not nums:
            return _res("证据不足", "sequence_not_found", f"未找到「{field}」序号")
        expect = list(range(nums[0], nums[0] + len(nums)))
        if nums != expect:
            return _res("不满足", "sequence_broken", f"序号不连续：{nums}", value=nums)
        return _res("满足", "sequence_ok", f"序号连续：{nums}", value=nums)

    if kind == "step_present":
        steps = _split_terms(req.get("steps"))
        if not steps:
            return _res("执行失败", "steps_missing", "步骤条件缺少 steps")
        missing = [s for s in steps if not _contains(raw, s)]
        if missing:
            return _res("不满足", "step_missing_value", "缺少步骤：" + "、".join(missing))
        if req.get("ordered"):
            comp = _compact(raw)
            pos = [comp.find(_compact(s)) for s in steps]
            if any(p < 0 for p in pos) or pos != sorted(pos):
                return _res("不满足", "step_out_of_order", "步骤顺序不符合：" + "、".join(steps))
        return _res("满足", "steps_ok", "步骤齐全：" + "、".join(steps),
                    quote=_find_quote(raw, steps[0]))

    if kind == "no_empty":
        field = _text(req.get("field"))
        if not field:
            return _res("执行失败", "field_missing", "非空条件缺少 field")
        val, quote = _extract_labeled_value(raw, field)
        if val:
            return _res("满足", "not_empty", f"「{field}」非空", quote=quote)
        if _contains(raw, field):
            return _res("不满足", "empty_value", f"「{field}」为空")
        return _res("不满足", "field_missing_value", f"缺少「{field}」")

    if kind == "format":
        fmt = _text(req.get("format") or req.get("name"))
        pattern = _text(req.get("pattern"))
        formats = {
            "yyyy-mm-dd": r"\d{4}-\d{2}-\d{2}",
            "yyyy/mm/dd": r"\d{4}/\d{2}/\d{2}",
            "yyyy年mm月dd日": r"\d{4}年\d{1,2}月\d{1,2}日",
            "email": r"[\w.+-]+@[\w-]+\.[\w.-]+",
            "邮箱": r"[\w.+-]+@[\w-]+\.[\w.-]+",
            "phone": r"1[3-9]\d{9}",
            "手机号": r"1[3-9]\d{9}",
        }
        pat = pattern or formats.get(fmt.lower(), "")
        if not pat:
            return _res("执行失败", "format_unsupported", f"未知格式：{fmt or pattern}")
        try:
            m = re.search(pat, raw, re.MULTILINE)
        except re.error as exc:
            return _res("执行失败", "format_invalid", f"格式正则非法：{exc}")
        if m:
            return _res("满足", "format_ok", f"符合格式 {fmt or pat}", quote=m.group(0)[:120])
        return _res("不满足", "format_mismatch", f"不符合格式 {fmt or pat}")

    return _res("执行失败", "procedure_kind_unsupported", f"不支持的过程条件：{kind}")


def _eval_requirements(ir: dict, text: Any) -> dict:
    reqs = list(ir.get("requirements") or [])
    if not reqs:
        return _res("执行失败", "ir_not_executable", "没有可执行的 typed 要素")
    results = [_eval_requirement(r, text) for r in reqs]
    return _combine_results(results, str(ir.get("combination") or "all"))


def _eval_procedure(ir: dict, text: Any) -> dict:
    proc = dict(ir.get("procedure") or {})
    reqs = list(proc.get("requirements") or [])
    if not reqs:
        return _res("执行失败", "procedure_requirements_missing",
                    "记录/程序规则没有 typed 条件，不能执行自由文本")
    results = [_eval_requirement(r, text) for r in reqs]
    return _combine_results(results, str(proc.get("combination") or ir.get("combination") or "all"))


def _eval_relations(ir: dict, text: Any, facts: Any) -> dict:
    rels = list(ir.get("relations") or [])
    if not rels:
        return _res("执行失败", "relation_operands_missing",
                    "关系规则没有 typed 关系对象，不能执行自由文本")
    results = []
    for rel in rels:
        if not rel.get("complete"):
            results.append(_res("执行失败", "relation_incomplete", "关系条件不完整"))
            continue
        if rel.get("self_consistency"):
            label = rel.get("left") or rel.get("right")
            vals = _extract_all_labeled_values(text, label)
            if not vals:
                vals = _fact_values(facts, label)
            if len(vals) < 2:
                results.append(_res("证据不足", "self_consistency_single_value",
                                    f"「{label}」只取到 {len(vals)} 个值，无法核对一致性",
                                    quote=_find_quote(text, label)))
                continue
            first = vals[0]
            bad = next((v for v in vals[1:]
                        if _compare_values(first, v, str(rel.get("compare") or "equal")) is False), None)
            if bad is not None:
                results.append(_res("不满足", "self_consistency_mismatch",
                                    f"「{label}」出现不一致：{first} vs {bad}",
                                    quote=_find_quote(text, label),
                                    value={"values": vals}))
            else:
                results.append(_res("满足", "self_consistency_ok",
                                    f"「{label}」{len(vals)} 处取值一致",
                                    quote=_find_quote(text, label),
                                    value={"values": vals}))
            continue
        lv, lq = _resolve_operand(rel, "left", text, facts)
        rv, rq = _resolve_operand(rel, "right", text, facts)
        if lv in (None, "") or rv in (None, ""):
            miss = rel.get("left") if lv in (None, "") else rel.get("right")
            results.append(_res("证据不足", "relation_fact_missing",
                                f"未取到关系对象「{miss}」", quote=lq or rq))
            continue
        ok = _compare_values(lv, rv, str(rel.get("compare") or "equal"))
        detail = f"{rel.get('left')}={lv} {rel.get('compare')} {rel.get('right')}={rv}"
        if ok is None:
            results.append(_res("执行失败", "relation_unsupported", detail))
        elif ok:
            results.append(_res("满足", "relation_ok", detail, quote=lq or rq,
                                value={"left": lv, "right": rv}))
        else:
            results.append(_res("不满足", "relation_mismatch", detail, quote=lq or rq,
                                value={"left": lv, "right": rv}))
    return _combine_results(results, str(ir.get("combination") or "all"))


def _normalize_judge_result(raw: Any, semantic: dict) -> dict:
    if isinstance(raw, bool):
        state = "满足" if raw else "不满足"
        return _res(state, "semantic_judge", "agent-judge 布尔结论",
                    needs_model=False, trace={"quote_missing": True})
    if isinstance(raw, str):
        state = raw.strip()
        mapping = {"pass": "满足", "fail": "不满足", "insufficient": "证据不足",
                   "na": "不适用", "not_applicable": "不适用",
                   "failed": "执行失败", "error": "执行失败"}
        state = mapping.get(state.lower(), state)
        if state not in STATES:
            return _res("执行失败", "judge_contract_invalid", f"agent-judge 返回非法状态：{raw}")
        return _res(state, "semantic_judge", "agent-judge 文本结论",
                    trace={"quote_missing": state in ("满足", "不满足")})
    if not isinstance(raw, dict):
        return _res("执行失败", "judge_contract_invalid",
                    f"agent-judge 返回类型不支持：{type(raw).__name__}")
    state = raw.get("state") or raw.get("status") or raw.get("result") or ""
    state = str(state).strip()
    mapping = {"pass": "满足", "fail": "不满足", "insufficient": "证据不足",
               "na": "不适用", "not_applicable": "不适用",
               "failed": "执行失败", "error": "执行失败"}
    state = mapping.get(state.lower(), state)
    if state not in STATES:
        return _res("执行失败", "judge_contract_invalid", f"agent-judge 返回非法状态：{state}")
    quote = str(raw.get("quote") or raw.get("evidence") or "").strip()
    # 引文缺失不改变结论，但显式留痕；required_evidence 已在 _eval_semantic 中核验。
    quote_missing = bool(semantic.get("quote_required", True)) and not quote
    return _res(state, str(raw.get("code") or "semantic_judge"),
                str(raw.get("detail") or raw.get("reason") or ""),
                quote=quote, value=raw.get("value"),
                trace={"judge": raw.get("trace") or {}, "quote_missing": quote_missing})


def _eval_semantic(ir: dict, text: Any, facts: Any, judge: Any) -> dict:
    missing = _check_evidence(ir, text, facts)
    if missing:
        return _res("证据不足", "evidence_missing",
                    "缺少证据：" + "、".join(missing))
    sem = dict(ir.get("semantic") or {})
    reqs = list(ir.get("requirements") or [])
    if reqs and not sem.get("predicate"):
        return _eval_requirements(ir, text)
    if not sem.get("predicate"):
        return _res("执行失败", "semantic_predicate_missing", "语义规则缺少 predicate")
    # 先跑可确定性核验的要素；要素不满足时不必进入模型，要素通过后再交 agent-judge。
    deterministic_checks = {}
    if reqs:
        req_result = _eval_requirements(ir, text)
        deterministic_checks = {"state": req_result.get("state"), "code": req_result.get("code"),
                                "detail": req_result.get("detail")}
        if req_result.get("state") in ("不满足", "证据不足", "执行失败"):
            req_result["trace"] = {"deterministic_checks": deterministic_checks}
            return req_result
    if not callable(judge):
        return _res("证据不足", "semantic_judge_required",
                    "语义规则需 agent-judge；typed IR 已提供判据/证据/引文契约",
                    needs_model=True, trace={"deterministic_checks": deterministic_checks})
    payload = semantic_payload(ir)
    payload["text"] = str(text or "")
    try:
        try:
            raw = judge(payload, str(text or ""))
        except TypeError:
            raw = judge(payload)
    except Exception as exc:  # noqa: BLE001
        return _res("执行失败", "judge_error", f"{type(exc).__name__}: {exc}")
    out = _normalize_judge_result(raw, sem)
    out.setdefault("trace", {})["deterministic_checks"] = deterministic_checks
    return out


def execute_ir(ir: dict, text: Any = "", facts: Any = None, judge: Any = None) -> dict:
    """执行 typed IR，返回五态 + code/detail/quote/trace。

    - R3：先做证据绑定（缺证据→证据不足），再调用 agent-judge；未提供 judge 时
      返回 ``semantic_judge_required``，不会把自由文本直接判成满足/不满足。
    - R4：从 facts 或原文标签取值比较；取不到→证据不足。
    - R5：按 typed requirements 做确定性的字段/签字/频次/步骤/格式检查。
    """
    if not isinstance(ir, dict):
        return _res("执行失败", "ir_invalid", "IR 不是对象")
    if "executable" not in ir:
        # 兼容手工构造的 typed IR：有 typed 条件才放行，只有 predicate 仍拒绝。
        ir = dict(ir)
        ir["executable"] = bool(
            ir.get("relations") or ir.get("requirements")
            or (ir.get("procedure") or {}).get("requirements")
            or ir.get("semantic") or ir.get("metric"))
    mode = _text(ir.get("execution_mode"))
    if not mode:
        if ir.get("relations"):
            mode = "relational"
        elif (ir.get("procedure") or {}).get("requirements"):
            mode = "procedural"
        elif ir.get("semantic"):
            mode = "semantic"
        elif ir.get("requirements") or ir.get("metric"):
            mode = "deterministic"
    if not ir.get("executable") or mode in ("", "none"):
        typed = bool(ir.get("relations") or ir.get("requirements")
                     or (ir.get("procedure") or {}).get("requirements")
                     or ir.get("semantic") or ir.get("metric"))
        free_text = bool(ir.get("free_text_only")) or (
            not typed and bool(ir.get("predicate") or ir.get("criterion")))
        code = "free_text_not_executable" if free_text else "ir_not_executable"
        detail = ("IR 只有 criterion 自由文本，未编译出 typed 条件，不能直接执行"
                  if code == "free_text_not_executable"
                  else "IR 未声明可执行 typed 条件，不能执行")
        return _res("执行失败", code, detail, trace={"execution_mode": mode})
    if mode == "semantic":
        return _eval_semantic(ir, text, facts, judge)
    if mode == "relational":
        return _eval_relations(ir, text, facts)
    if mode == "procedural":
        return _eval_procedure(ir, text)
    if mode == "deterministic":
        if ir.get("metric") and ir.get("threshold") is not None and ir.get("operator"):
            return _eval_limit(ir, text, facts)
        if ir.get("requirements"):
            return _eval_requirements(ir, text)
        if ir.get("semantic"):
            return _eval_semantic(ir, text, facts, judge)
        return _res("执行失败", "ir_not_executable", "确定性 IR 没有可执行条件")
    return _res("执行失败", "execution_mode_unsupported", f"不支持的执行方式：{mode}")
