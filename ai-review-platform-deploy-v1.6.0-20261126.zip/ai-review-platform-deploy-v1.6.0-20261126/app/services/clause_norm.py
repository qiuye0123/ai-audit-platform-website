"""条款名归一（误报压制的核心）：同一要求的不同写法视为同一条款。"""
import re

CANON = {
    "验收标准": ["验收标准", "验收要求", "验收依据", "验收方式", "验收方法", "验收条件"],
    "交付期限": ["交付期限", "交货期", "交付时间", "交货时间", "交付日期", "交货日期"],
    "营业执照": ["营业执照", "工商执照", "执照副本"],
    "无重大违法记录": ["无重大违法记录", "无违法记录", "三年内无重大违法", "近3年无重大违法"],
    "争议管辖": ["管辖法院", "管辖", "争议解决", "仲裁", "诉讼管辖"],
    "质保金条款": ["质保金", "质量保证金"],
}
_INDEX = {n: c for c, names in CANON.items() for n in names}


def canonical(name: str) -> str:
    n = (name or "").strip()
    if n in _INDEX:
        return _INDEX[n]
    for alias, c in _INDEX.items():
        if alias and (alias in n or n in alias):
            return c
    return n


def synonyms(name: str) -> list:
    c = canonical(name)
    return CANON.get(c, [c])


NEG = r"未|无|缺|没有|尚未|未约定|未附|未收到|无法提供"


def find(name: str, text: str) -> dict:
    """在文中找条款：返回 {found, negated, matched}。"""
    t = text or ""
    for syn in synonyms(name):
        m = re.search(re.escape(syn), t)
        if not m:
            continue
        pre = t[max(0, m.start() - 12):m.start()]
        post = t[m.end():m.end() + 24]
        negated = bool(re.search(NEG, pre) or re.search(NEG, post))
        return {"found": True, "negated": negated, "matched": syn}
    return {"found": False, "negated": False, "matched": ""}
