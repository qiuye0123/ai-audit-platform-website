# -*- coding: utf-8 -*-
"""全文候选召回：完整文档 + 全部客户规则，一次 LLM 生成候选，再回填 finding/evidence。

定位：这是“高召回候选层”，不是绕过 D1-D5 的裁决层。默认关闭；候选必须能逐字
回查原文，否则丢弃。

build49 B1（L81 清理）：原隐藏评测开关 ``RULEPROOF_FULLDOC_RECALL`` 的读取点已删除
（本通道恒关闭，不再由环境变量启用）；快照 schema 仍保留该开关名作为历史 tombstone，
仅用于历史 run 的 verify 兼容，无任何运行时读取/分支。删除前证据见
docs/qa/L81_build49清理B0B1_20261124.md。
"""
from __future__ import annotations
import json, logging, os
from .. import db
from . import extract

log = logging.getLogger(__name__)


def enabled() -> bool:
    """全文召回通道是否启用。

    build49 B1：隐藏评测开关 ``RULEPROOF_FULLDOC_RECALL`` 读取点已删除 → 恒 False；
    保留函数签名供上层（project.py 编排）无改动调用，历史 run 行为可追溯。
    """
    return False


def _doc_text(docs) -> str:
    parts = []
    for d in docs or []:
        try:
            from . import audit_intake
            p = audit_intake.ensure_parsed(d.get("path") or "")
            txt = ((p or {}).get("doc") or {}).get("text") or ""
            if txt:
                parts.append(f"【文件：{d.get('filename') or d.get('name') or ''}】\n{txt}")
        except Exception:
            log.debug("full-doc text skipped", exc_info=True)
    return "\n\n".join(parts)


def _rule_brief(rule: dict, version: dict) -> str:
    slots = {}
    try:
        slots = json.loads((version or {}).get("slots_json") or "{}")
    except Exception:
        slots = {}
    crit = slots.get("criterion") or slots.get("condition") or slots.get("requirement") or ""
    return f"- {rule.get('code')}｜{rule.get('name')}｜判据：{str(crit)[:500]}"


def recall(case_id: str, docs: list, items: list, collected: list) -> dict:
    """调用一次全文 LLM，仅补“有精确原文引文且规则已冻结”的候选。"""
    if not enabled():
        return {"enabled": False, "added": 0}
    text = _doc_text(docs)
    if not text:
        return {"enabled": True, "added": 0, "error": "无解析文本"}
    from app import repositories as R
    from app.services import rule as _rule_scope
    rules_by_code = {}
    for r in _rule_scope.effective_rule_rows():  # T-171 生效口径（默认 0=旧行为）
        rules_by_code[str(r.get("code") or "")] = r
    item_codes = []
    item_states = {}
    for it in items or []:
        code = str(it.get("rule") or it.get("code") or "")
        if not code:
            continue
        item_states[code] = (str(it.get("d1") or ""), str(it.get("d5") or ""))
        if code not in item_codes:
            item_codes.append(code)
    briefs = []
    for code in item_codes:
        r = rules_by_code.get(code)
        if not r:
            continue
        v = R.rules.published_version(r["id"]) or {}
        briefs.append(_rule_brief(r, v))
    if not briefs:
        return {"enabled": True, "added": 0, "error": "无已发布规则"}
    prompt = (
        "你是合同审核候选召回器。下面给出完整文档和全部审核规则。\n"
        "任务：找出文档中与任一规则明确不符的具体条款，输出所有疑似问题（宁可多报候选，不要漏）。\n"
        "只输出 JSON 数组，每项：{\"rule\":\"规则编码\",\"quote\":\"从原文逐字复制的连续片段\","
        "\"reason\":\"一句话说明与规则哪里不符\",\"confidence\":0到1}。\n"
        "quote 必须是原文中逐字存在的文字，不得改写、拼接或加省略号；找不到逐字原文就不要输出。\n"
        "不要输出通过项，不要解释。\n\n规则：\n" + "\n".join(briefs) + "\n\n文档全文：\n" + text[:60000]
    )
    try:
        content = extract._chat([
            {"role": "system", "content": "你是严谨的合同审核候选召回器，只输出 JSON 数组。"},
            {"role": "user", "content": prompt},
        ], max_tokens=3000)
        cands = extract._json_of(content)
    except Exception as e:
        return {"enabled": True, "added": 0, "error": f"{type(e).__name__}: {str(e)[:200]}"}
    if not isinstance(cands, list):
        cands = []
    existing = set()
    existing_codes = set()
    for f in collected or []:
        _c = str(f.get("rule_code") or f.get("code") or "")
        existing.add((_c, str(f.get("summary") or "")[:80]))
        if _c:
            existing_codes.add(_c)
    added = 0
    dup = 0
    for c in cands[:80]:
        if not isinstance(c, dict):
            continue
        code = str(c.get("rule") or "").strip()
        quote = str(c.get("quote") or "").strip()
        reason = str(c.get("reason") or "").strip()
        if code not in item_codes or not quote or quote not in text or not reason:
            continue
        _d1, _d5 = item_states.get(code, ("", ""))
        # 平台已判 pass 的规则不接受候选；D1 明确不适用的也不接受。
        if _d5 == "pass" or _d1 == "not_applicable":
            continue
        # 同一规则已有平台 D5/客户规则 finding 时，不再用全文候选重复造一条：
        # 否则一个 gold 会被多条 finding 重复匹配，precision 崩掉。
        if code in existing_codes:
            dup += 1
            continue
        key = (code, reason[:80])
        if key in existing:
            dup += 1
            continue
        r = rules_by_code.get(code)
        if not r:
            continue
        try:
            fid = db.new_id("fnd")
            R.findings.insert(id=fid, case_id=case_id, rule_id=str(r["id"]), rule_version="full-doc-recall",
                              severity="warning", certainty="probable", confidence=float(c.get("confidence") or 0.7),
                              state="fail", status="pending", title=str(r.get("name") or code)[:80],
                              summary=reason[:500], suggestion="", engine="full_doc_recall",
                              run_id="", point_id=code, source_code=code)
            aid = db.new_id("anc"); eid = db.new_id("evd")
            R.anchors.insert(id=aid, document_id=(docs[0].get("id") if docs else ""), sheet="",
                             row=None, col="", locator="full-doc-recall", quote=quote[:500], hash="")
            R.evidences.insert(id=eid, finding_id=fid, document_id=(docs[0].get("id") if docs else ""),
                               anchor_id=aid, excerpt=quote[:500], label="全文候选召回")
            existing_codes.add(code)
            collected.append({"id": fid, "code": code, "rule_code": code, "point_id": code,
                              "rule_name": r.get("name") or "", "title": str(r.get("name") or code)[:80],
                              "summary": reason[:500], "state": "fail", "severity": "warning",
                              "evidence": [{"quote": quote[:500], "locator": "full-doc-recall"}],
                              "engine": "full_doc_recall"})
            added += 1
        except Exception:
            log.debug("full-doc candidate insert skipped", exc_info=True)
    return {"enabled": True, "added": added, "duplicate": dup, "candidates": len(cands)}
