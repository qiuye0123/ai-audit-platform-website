"""密码重置记录：保存管理员生成的临时密码，供授权管理员转交；首次改密后清除。

P2-B5-03（评审 B5-E3）：本表的 ``tenant_id`` 是**签发时快照**，不依赖 user 行存在。
旧实现 ``list_resets`` 用 ``LEFT JOIN user`` 取租户，账号被删除后 ``u.tenant_id`` 为
NULL → 系统管理员的 ``WHERE u.tenant_id=?`` 直接滤掉记录 → 「记录仍在表里却不可见」，
违反 §5「临时密码必须可被授权管理员在密码重置记录中查看」。
现在：签发时写 tenant_id 快照（user 行存在时取真实租户），列表按快照列过滤，
并对本模块自管的兼容迁移在首次使用时补齐列/回填（不依赖 db.py 迁移清单）。
"""
import datetime as _dt
from .. import db

# 兼容迁移只做一次；失败不阻断（旧库缺列时列表退回 JOIN 口径并标记 degraded）
_COL_READY = False


def _ensure_tenant_column() -> bool:
    """确保 password_reset 有 tenant_id 快照列，并用 user 行回填历史记录（幂等）。"""
    global _COL_READY
    if _COL_READY:
        return True
    try:
        with db.session() as c:
            # L109：列定义单一事实源 = app/db.py RUNTIME_EXTENSION_COLUMNS["password_reset"]
            # （新库 SCHEMA 已含 tenant_id；本兜底只服务未迁移老库）
            db.ensure_runtime_columns(c, "password_reset")
            # 回填：历史记录按 user 当前租户补齐（user 已删除的保持空，不伪造）
            c.execute("UPDATE password_reset SET tenant_id=("
                      " SELECT COALESCE(u.tenant_id,'') FROM user u WHERE u.id=password_reset.user_id"
                      ") WHERE COALESCE(tenant_id,'')='' AND EXISTS("
                      " SELECT 1 FROM user u2 WHERE u2.id=password_reset.user_id)")
            c.commit()
        _COL_READY = True
        return True
    except Exception:
        return False


def _now():
    return _dt.datetime.now()


def _tenant_of(user_id: str) -> str:
    try:
        with db.session() as c:
            row = c.execute("SELECT tenant_id FROM user WHERE id=?", (user_id,)).fetchone()
            return str((row["tenant_id"] if row else "") or "")
    except Exception:
        return ""


def issue(user_id: str, password: str, actor: str = "", source: str = "admin", days: int = 7) -> dict:
    """写入一次临时密码记录；同一用户旧的未使用记录立即失效。

    ``tenant_id`` 在此刻快照落库：账号随后被删除也不会丢租户归属（P2-B5-03）。
    """
    rid = db.new_id("pwr")
    now = _now()
    expires = (now + _dt.timedelta(days=max(1, int(days or 7)))).strftime("%Y-%m-%d %H:%M:%S")
    _has_col = _ensure_tenant_column()
    _tid = _tenant_of(user_id)
    with db.session() as c:
        c.execute("UPDATE password_reset SET temp_password='', used_at=?, used_by='superseded' "
                  "WHERE user_id=? AND COALESCE(used_at,'')=''", (now.strftime("%Y-%m-%d %H:%M:%S"), user_id))
        if _has_col:
            c.execute("INSERT INTO password_reset(id,user_id,actor,source,temp_password,created_at,"
                      "expires_at,tenant_id) VALUES(?,?,?,?,?,?,?,?)",
                      (rid, user_id, actor or "", source or "", password,
                       now.strftime("%Y-%m-%d %H:%M:%S"), expires, _tid))
        else:
            c.execute("INSERT INTO password_reset(id,user_id,actor,source,temp_password,created_at,expires_at) "
                      "VALUES(?,?,?,?,?,?,?)",
                      (rid, user_id, actor or "", source or "", password, now.strftime("%Y-%m-%d %H:%M:%S"), expires))
        c.commit()
    return {"id": rid, "expires_at": expires, "tenant_id": _tid}


def mark_used(user_id: str, actor: str = "") -> int:
    now = _now().strftime("%Y-%m-%d %H:%M:%S")
    with db.session() as c:
        cur = c.execute("UPDATE password_reset SET temp_password='', used_at=?, used_by=? "
                        "WHERE user_id=? AND COALESCE(used_at,'')=''",
                        (now, actor or "self", user_id))
        c.commit()
        return cur.rowcount or 0


def list_resets(tenant_id: str = "", limit: int = 100) -> list:
    """密码重置记录列表（P2-B5-03：租户按签发快照过滤，账号被删后记录仍可追溯）。"""
    limit = max(1, min(int(limit or 100), 200))
    _has_col = _ensure_tenant_column()
    if _has_col:
        sql = ("SELECT p.id,p.user_id,p.actor,p.source,p.temp_password,p.created_at,p.expires_at,"
               "p.used_at,p.used_by,p.tenant_id AS snapshot_tenant_id,"
               "u.name,u.phone,u.tenant_id,"
               "COALESCE(t.name, t2.name) AS tenant_name "
               "FROM password_reset p LEFT JOIN user u ON u.id=p.user_id "
               "LEFT JOIN tenant t ON t.id=u.tenant_id "
               "LEFT JOIN tenant t2 ON t2.id=p.tenant_id ")
        args = []
        if tenant_id:
            # 快照优先：账号已删除（u.tenant_id 为 NULL）时仍命中；历史无快照行回退 JOIN。
            sql += "WHERE COALESCE(NULLIF(p.tenant_id,''), u.tenant_id)=? "
            args.append(tenant_id)
    else:
        sql = ("SELECT p.id,p.user_id,p.actor,p.source,p.temp_password,p.created_at,p.expires_at,"
               "p.used_at,p.used_by,u.name,u.phone,u.tenant_id,t.name AS tenant_name "
               "FROM password_reset p LEFT JOIN user u ON u.id=p.user_id "
               "LEFT JOIN tenant t ON t.id=u.tenant_id ")
        args = []
        if tenant_id:
            sql += "WHERE u.tenant_id=? "
            args.append(tenant_id)
    sql += "ORDER BY p.created_at DESC LIMIT ?"
    args.append(limit)
    now = _dt.datetime.now()
    out = []
    with db.session() as c:
        for r in c.execute(sql, tuple(args)).fetchall():
            d = dict(r)
            used = bool(d.get("used_at"))
            expired = False
            try:
                expired = _dt.datetime.strptime((d.get("expires_at") or "")[:19], "%Y-%m-%d %H:%M:%S") < now
            except Exception:
                expired = False
            d["status"] = "已使用" if used else ("已过期" if expired else "待使用")
            if used or expired:
                d["temp_password"] = ""
            out.append(d)
    return out
