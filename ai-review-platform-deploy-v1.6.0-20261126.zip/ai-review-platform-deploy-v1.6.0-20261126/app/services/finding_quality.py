"""结论质量层：三类高发误报的直接拦截。

1) 证据不足被当成发现（desc 里自述“未提供/无法判断”）
2) schema 类发现与文档内容无关（价格类文档套检验日期）
3) 点位归属错误（理由与点位语义无关）
"""
import re

_WEAK = re.compile(r"未提供|无法判断|无法核对|未见|未附|未包含|无法确认|无法定位|证据不足")
_SCHEMA_HINT = re.compile(r"字段缺失|schema|必填", re.I)


def _bigrams(t: str):
    t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fff")
    return {t[i:i + 2] for i in range(len(t) - 1)}


def check(f: dict, doc_text: str, point_name: str = "", point_criterion: str = "") -> dict:
    desc = (f.get("description") or f.get("summary") or "")
    title = f.get("title") or ""
    quote = ((f.get("locations") or [{}])[0] or {}).get("quote") or ""

    # 1) 自述证据不足 → 不能作为发现
    if _WEAK.search(desc) and not _WEAK.search(quote):
        return {"ok": False, "reason": "Q1 自述证据不足，降级为待人工"}

    # 2) schema 类：字段名不在文档中且文档无检验/生产语境 → 不适用
    if _SCHEMA_HINT.search(title + desc):
        m = re.search(r"字段缺失[：:]\s*([^\s，。]+)", title + desc)
        field = m.group(1) if m else ""
        if field and field not in (doc_text or ""):
            if not re.search(r"检验|生产|批次|工序|食品", doc_text or ""):
                return {"ok": False, "reason": f"Q2 文档无该字段语境（{field}），不适用", "disposition": "na"}

    # 3) 点位归属：理由与点位语义需有交集
    if point_name or point_criterion:
        src = _bigrams(f"{point_name} {point_criterion}")
        if src:
            own = _bigrams(f"{title} {desc}")
            if own and not (own & src):
                return {"ok": False, "reason": "Q3 理由与点位语义无交集，疑似归属错误"}
    return {"ok": True}


def apply(findings: list, doc_text: str, point_lookup) -> tuple:
    kept, dropped = [], []
    for f in findings:
        pid = f.get("point_id") or f.get("rule_code") or ""
        p = point_lookup(pid) if point_lookup else None
        name = (getattr(p, "name", "") if p else "") or f.get("title") or ""
        crit = (getattr(p, "criterion", "") if p else "") or ""
        r = check(f, doc_text, name, crit)
        if r["ok"]:
            kept.append(f)
        else:
            f["quality_reason"] = r["reason"]
            if r.get("disposition"):
                f["disposition"] = r["disposition"]
                continue
            dropped.append(f)
    return kept, dropped
