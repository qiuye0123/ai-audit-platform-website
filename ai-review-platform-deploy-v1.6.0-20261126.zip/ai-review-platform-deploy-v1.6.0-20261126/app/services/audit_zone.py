# -*- coding: utf-8 -*-
"""三区分层（T-161）：点位 → 区的确定性映射 + manifest 冻结标记 + finding 分区统计。

架构依据（`docs/CURRENT/14-E1E4结论与混合模式定稿_20261119.md`、
`docs/CURRENT/15-最终架构定稿与技术引入门禁_20261119.md`）：

区 1 · 确定性区（deterministic）
    method ∈ {calculate（工具计算复核）, text（文字规则检查）, compare（文本数据比对）}
    平台确定性执行器直接出结论，输出五态 + 原文锚点（E1：V3B F1 1.0 vs 直连 .5570）。
区 2 · 证据区（evidence）
    method ∈ {semantic（语义审阅）, expert（专业辅助审阅）}
    直连/模型负责发现，平台做码归属校准 + 引文锚定 + 五态落账（E4：0/40 可过滤，
    41/41 引文可锚定）。
区 3 · 影子空间（shadow）
    **不在点位级分配**，是运行时进入的：不可复算（D5 = insufficient / unknown）、
    不可锚定（finding 无 anchor/quote）、跨文档 document_set 证据不可用（无对齐键）。
    只展示、不结论、不计入通过率；人工裁决后回流校准。

边界（本期硬约束，见 task-152）：
- 只做「标记 + 报告分区」，**不改任何执行/判定行为**：D1–D5 一行不动，
  本模块全部函数只读，不写 finding / manifest_result / 判定结论。
- 开关：
    ``RULEPROOF_ZONE_TAGGING``（默认 "1"）：manifest.freeze() 是否给 item 写 ``zone``；
    ``RULEPROOF_ZONE_REPORT``（默认 "1"）：报告是否输出「按区统计」。
  两个开关都可单独关闭，关闭后行为与改动前一致（只多几个被跳过的分支）。
- 未知 method 不猜确定性：``ZONE_UNKNOWN`` 单列、不混进确定性区。当前 302 基础点位
  0 unknown（152 确定性 / 150 证据，见 ``zone_coverage()``）。

数据来源（全部只读）：
- 点位库：``app.services.auditpoints.load()``（运行期被 RULEPROOF_AUDIT_LIBRARY 覆盖时的
  自定义点位库同样按 method 映射；P01 客户规则包导入的自定义点位全是 semantic）。
- 冻结清单：``audit_manifest.items_json``（§manifest.freeze 写入的 ``zone`` 优先）。
- 执行台账：``manifest_active`` / ``manifest_result``（D5 结论）。
- 发现：``finding`` + ``evidence`` / ``anchor``（锚点存在性）。
"""
from __future__ import annotations

import json
import logging
import os

# ---------------------------------------------------------------- 常量（写死，可审计）
ZONE_DETERMINISTIC = "deterministic"
ZONE_EVIDENCE = "evidence"
ZONE_SHADOW = "shadow"
ZONE_UNKNOWN = "unknown"          # 数据异常（method 缺失/无法识别），不混入确定性区

ZONES = (ZONE_DETERMINISTIC, ZONE_EVIDENCE, ZONE_SHADOW)
ZONE_LABELS = {
    ZONE_DETERMINISTIC: "确定性区",
    ZONE_EVIDENCE: "证据区",
    ZONE_SHADOW: "影子空间",
    ZONE_UNKNOWN: "未映射",
}

# 映射表依据（docs/CURRENT/15 §一）：
#   文字规则检查 44 + 工具计算复核 43 + 文本数据比对 65 = 152（区 1）
#   语义审阅 93 + 专业辅助审阅 57                     = 150（区 2）
# "d" 是 engine.auditpoints.AuditPoint.is_deterministic 兼容的旧确定性标记，按确定性区处理。
METHOD_TO_ZONE = {
    "calculate": ZONE_DETERMINISTIC,
    "text": ZONE_DETERMINISTIC,
    "compare": ZONE_DETERMINISTIC,
    "d": ZONE_DETERMINISTIC,
    "deterministic": ZONE_DETERMINISTIC,
    "semantic": ZONE_EVIDENCE,
    "expert": ZONE_EVIDENCE,
}
METHOD_LABELS = {
    "calculate": "工具计算复核",
    "text": "文字规则检查",
    "compare": "文本数据比对",
    "semantic": "语义审阅",
    "expert": "专业辅助审阅",
    "d": "确定性执行器（旧标记）",
    "deterministic": "确定性执行",
}
# 无点位映射时：item 的 D4 执行方式（rule_ir.evaluation_kind）作为兜底分区依据。
EXECUTION_KIND_TO_ZONE = {
    "deterministic": ZONE_DETERMINISTIC,
    "semantic": ZONE_EVIDENCE,
}

ENV_TAGGING = "RULEPROOF_ZONE_TAGGING"
ENV_REPORT = "RULEPROOF_ZONE_REPORT"

# D5 非结论态：不可复算 → 运行时进影子空间（只标记，不删除、不改结论）
SHADOW_D5_STATES = ("insufficient", "unknown")
# finding 状态里已经明确写「需要人工复核/补证」的，也属于影子空间（不可锚定的落库形态）
SHADOW_FINDING_STATUSES = ("need_evidence",)
SHADOW_FINDING_STATES = ("insufficient", "unknown")

_ZONE_VALUES = set(ZONES)


# ---------------------------------------------------------------- 开关
def _env_flag(name: str) -> bool:
    """默认开；只有显式 "0/false/no/off" 才关（与工作空间显式关闭口径一致）。"""
    raw = os.environ.get(name)
    if raw is None or not str(raw).strip():
        return True
    return str(raw).strip().lower() not in ("0", "false", "no", "off", "disable", "disabled")


def tagging_enabled() -> bool:
    """manifest.freeze() 是否给 item 写 zone（默认开）。"""
    return _env_flag(ENV_TAGGING)


def report_enabled() -> bool:
    """报告是否输出「按区统计」（默认开）。"""
    return _env_flag(ENV_REPORT)


# ---------------------------------------------------------------- 点位 → 区
def _mapping(value) -> dict:
    return value if isinstance(value, dict) else {}


def normalize_method(value) -> str:
    return str(value or "").strip().lower()


def method_of_point(point) -> str:
    """点位对象/字典 → method（小写）；缺失返回空串。"""
    if isinstance(point, dict):
        return normalize_method(point.get("method"))
    return normalize_method(getattr(point, "method", ""))


def zone_of_method(method) -> str:
    """method → 区；未知 method 返回 ZONE_UNKNOWN（不猜确定性）。"""
    return METHOD_TO_ZONE.get(normalize_method(method), ZONE_UNKNOWN)


def zone_of_point(point) -> str:
    """点位字典/对象 → 区（按 method 映射，写死在 METHOD_TO_ZONE）。"""
    return zone_of_method(method_of_point(point))


def zone_of_execution_kind(kind) -> str:
    """rule_ir.evaluation_kind → 区（仅用于无点位映射的清单项兜底）。"""
    return EXECUTION_KIND_TO_ZONE.get(normalize_method(kind), ZONE_UNKNOWN)


def zone_label(zone) -> str:
    return ZONE_LABELS.get(str(zone or ""), str(zone or ""))


def _library(lib=None):
    if lib is not None:
        return lib
    try:
        from . import auditpoints as _ap
        return _ap.load()
    except Exception:  # noqa: BLE001 —— 库不可用不应让报告/冻结报错
        logging.getLogger(__name__).debug("audit point library unavailable", exc_info=True)
        return None


def _point_index(lib=None) -> dict:
    lib = _library(lib)
    out = {}
    for p in (getattr(lib, "points", None) or []):
        pid = str(getattr(p, "id", "") or getattr(p, "code", "") or "")
        if pid:
            out[pid] = p
        pcode = str(getattr(p, "code", "") or "")
        if pcode and pcode not in out:
            out[pcode] = p
    return out


def zone_of_point_id(point_id, lib=None) -> str:
    """点位编号 → 区；库里没有该点位返回 ZONE_UNKNOWN。"""
    pid = str(point_id or "").strip()
    if not pid:
        return ZONE_UNKNOWN
    point = _point_index(lib).get(pid)
    return zone_of_point(point) if point is not None else ZONE_UNKNOWN


def point_method_by_id(point_id, lib=None) -> str:
    pid = str(point_id or "").strip()
    point = _point_index(lib).get(pid) if pid else None
    return method_of_point(point) if point is not None else ""


def zone_coverage(lib=None) -> dict:
    """点位库分区覆盖（可审计）：总数 / 各区计数 / unknown 明细 / method 分布。"""
    lib = _library(lib)
    points = list(getattr(lib, "points", None) or [])
    counts = {ZONE_DETERMINISTIC: 0, ZONE_EVIDENCE: 0, ZONE_SHADOW: 0, ZONE_UNKNOWN: 0}
    methods = {}
    unknown = []
    by_method_zone = {}
    for p in points:
        m = method_of_point(p)
        z = zone_of_method(m)
        counts[z] = counts.get(z, 0) + 1
        methods[m] = methods.get(m, 0) + 1
        by_method_zone.setdefault(m, z)
        if z == ZONE_UNKNOWN:
            unknown.append({"id": str(getattr(p, "id", "") or ""), "method": m})
    return {
        "total": len(points),
        "counts": counts,
        "method_counts": methods,
        "method_to_zone": by_method_zone,
        "unknown": unknown,
        "unknown_count": len(unknown),
    }


# ---------------------------------------------------------------- manifest item → 区
def zone_of_item(item) -> str:
    """manifest item → 区。

    优先级（与 docs/CURRENT/15 一致）：
    1. item 里冻结的 ``zone``（manifest.freeze 写入，最先权威）；
    2. 冻结的 ``audit_route.point_method`` / ``audit_route.point_id`` → 点位库 method；
    3. item 的 ``steps[D4].method``（rule_ir.evaluation_kind）兜底；
    4. 仍无法判定 → ZONE_UNKNOWN（报告单列，不混进确定性区）。
    """
    if not isinstance(item, dict):
        return ZONE_UNKNOWN
    frozen = normalize_method(item.get("zone"))
    if frozen in _ZONE_VALUES:
        return frozen
    route = _mapping(item.get("audit_route"))
    method = (normalize_method(route.get("point_method"))
              or normalize_method(item.get("point_method"))
              or normalize_method(item.get("method")))
    if method:
        zone = zone_of_method(method)
        if zone != ZONE_UNKNOWN:
            return zone
    point_id = str(route.get("point_id") or item.get("point_id") or "").strip()
    if point_id:
        zone = zone_of_point_id(point_id)
        if zone != ZONE_UNKNOWN:
            return zone
    for step in (item.get("steps") or []):
        if isinstance(step, dict) and str(step.get("id") or "").upper() == "D4":
            zone = zone_of_execution_kind(step.get("method"))
            if zone != ZONE_UNKNOWN:
                return zone
    return ZONE_UNKNOWN


def zone_tag(point_method="", point_id="", execution_kind="") -> dict:
    """冻结用：给 manifest item 算分区标记（不写库、不改执行）。

    优先级：点位 method → 点位编号 → D4 执行方式（rule_ir.evaluation_kind）；
    都识别不了给 ``ZONE_UNKNOWN``（报告单列，不猜确定性）。
    返回 ``{"zone", "zone_source", "point_method"}``，由 manifest.freeze 按开关写入 item。
    """
    method = normalize_method(point_method)
    zone = zone_of_method(method) if method else ZONE_UNKNOWN
    source = "point_method" if zone != ZONE_UNKNOWN else ""
    if zone == ZONE_UNKNOWN and str(point_id or "").strip():
        zone = zone_of_point_id(point_id)
        source = "point_id" if zone != ZONE_UNKNOWN else ""
    if zone == ZONE_UNKNOWN:
        zone = zone_of_execution_kind(execution_kind)
        source = "execution_kind" if zone != ZONE_UNKNOWN else ""
    if zone == ZONE_UNKNOWN:
        source = "unknown"
    return {"zone": zone, "zone_source": source, "point_method": method}


def item_zone_source(item) -> str:
    """item 的区来自哪里：frozen_zone / point_method / point_id / execution_kind / unknown。"""
    if not isinstance(item, dict):
        return "unknown"
    if normalize_method(item.get("zone")) in _ZONE_VALUES:
        return "frozen_zone"
    route = _mapping(item.get("audit_route"))
    if normalize_method(route.get("point_method") or item.get("point_method") or item.get("method")):
        return "point_method"
    if str(route.get("point_id") or item.get("point_id") or "").strip():
        return "point_id"
    for step in (item.get("steps") or []):
        if isinstance(step, dict) and str(step.get("id") or "").upper() == "D4":
            return "execution_kind"
    return "unknown"


def count_item_zones(items) -> dict:
    """清单 item 分区计数。"""
    counts = {ZONE_DETERMINISTIC: 0, ZONE_EVIDENCE: 0, ZONE_SHADOW: 0, ZONE_UNKNOWN: 0}
    for item in items or []:
        z = zone_of_item(item)
        counts[z] = counts.get(z, 0) + 1
    return counts


# ---------------------------------------------------------------- DB 只读索引
def _connect():
    from .. import db
    return db.connect()


def _query(sql: str, params=()) -> list:
    c = None
    try:
        c = _connect()
        return [dict(r) for r in c.execute(sql, params)]
    except Exception:  # noqa: BLE001 —— 分类是只读旁路，不得打断报告
        logging.getLogger(__name__).debug("audit zone query skipped: %s", sql[:80], exc_info=True)
        return []
    finally:
        if c is not None:
            try:
                c.close()
            except Exception:  # noqa: BLE001 —— 关闭只读连接失败不影响分类结果，留调试日志
                logging.getLogger(__name__).debug("audit zone conn close skipped", exc_info=True)


def _loads(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    try:
        out = json.loads(raw or "{}")
        return out if isinstance(out, dict) else {}
    except Exception:
        return {}


def load_manifest_items(manifest_id: str) -> list:
    """按 manifest_id 读冻结 item（只读；items_json 是冻结快照唯一来源）。"""
    mid = str(manifest_id or "").strip()
    if not mid:
        return []
    rows = _query("SELECT items_json FROM audit_manifest WHERE id=?", (mid,))
    if not rows:
        return []
    try:
        items = json.loads(rows[0].get("items_json") or "[]")
        return items if isinstance(items, list) else []
    except Exception:
        return []


def index_items(items) -> dict:
    """item 索引：``(rule_id, object_id)`` 与 ``(code, object_id)`` 双键。"""
    out = {}
    for item in items or []:
        if not isinstance(item, dict):
            continue
        obj = str(item.get("object_id") or "")
        rid = str(item.get("rule_id") or "")
        code = str(item.get("code") or "")
        if rid:
            out[(rid, obj)] = item
        if code and (code, obj) not in out:
            out[(code, obj)] = item
    return out


def _items_for_manifest(manifest_id: str, cache: dict):
    mid = str(manifest_id or "").strip()
    if not mid:
        return {}
    if mid not in cache:
        cache[mid] = index_items(load_manifest_items(mid))
    return cache[mid]


def load_case_findings(case_id: str) -> list:
    """当前批次 finding（只读；口径与 review.case_report 的可见 finding 一致）。"""
    cid = str(case_id or "").strip()
    if not cid:
        return []
    rows = _query("SELECT * FROM finding WHERE case_id=?", (cid,))
    out = [f for f in rows if str(f.get("status") or "") != "superseded"]
    cases = _query("SELECT last_run_id FROM audit_case WHERE id=?", (cid,))
    rid = str((cases[0].get("last_run_id") if cases else "") or "")
    if rid:
        keep, seen = [], set()
        for f in out:
            if str(f.get("run_id") or "") == rid or str(f.get("engine") or "") == "manual":
                keep.append(f)
                seen.add(f.get("id"))
        for f in out:
            if f.get("id") not in seen and str(f.get("status") or "pending") == "pending":
                keep.append(f)
        out = keep
    return out


def load_case_results(case_id: str) -> list:
    """当前 active manifest 结果（只读）。"""
    cid = str(case_id or "").strip()
    if not cid:
        return []
    return _query(
        "SELECT mr.* FROM manifest_active ma JOIN manifest_result mr ON mr.id=ma.result_id "
        "WHERE ma.case_id=? ORDER BY mr.rule_code, mr.object_id", (cid,))


def load_case_evidence(case_id: str) -> dict:
    """finding_id → [{quote, locator, document_id}]（只读，含 anchor 回退）。"""
    cid = str(case_id or "").strip()
    if not cid:
        return {}
    rows = _query(
        "SELECT e.finding_id AS finding_id, e.excerpt AS excerpt, e.document_id AS document_id, "
        "a.quote AS quote, a.locator AS locator FROM evidence e "
        "LEFT JOIN anchor a ON a.id=e.anchor_id "
        "WHERE e.finding_id IN (SELECT id FROM finding WHERE case_id=?)", (cid,))
    out = {}
    for r in rows:
        fid = str(r.get("finding_id") or "")
        if not fid:
            continue
        out.setdefault(fid, []).append({
            "quote": str(r.get("quote") or r.get("excerpt") or ""),
            "locator": str(r.get("locator") or ""),
            "document_id": str(r.get("document_id") or ""),
        })
    return out


def case_index(case_id: str) -> dict:
    """case 的分类索引：results / items / evidence（只读，可缓存到调用方）。"""
    results = {}
    item_cache = {}
    items_by_key = {}
    rows = load_case_results(case_id)
    for r in rows:
        rid = str(r.get("id") or "")
        if rid:
            results[rid] = r
        mid = str(r.get("manifest_id") or "")
        items = _items_for_manifest(mid, item_cache)
        if items:
            items_by_key.update({k: v for k, v in items.items() if k not in items_by_key})
    # 历史 finding 的 manifest_result 不在 active 指针里：补全 manifest_result 索引
    missing_rids = [str(f.get("manifest_result_id") or "") for f in load_case_findings(case_id)]
    missing_rids = [x for x in missing_rids if x and x not in results]
    if missing_rids:
        marks = ",".join("?" * len(missing_rids))
        for r in _query(f"SELECT * FROM manifest_result WHERE id IN ({marks})", tuple(missing_rids)):
            rid = str(r.get("id") or "")
            if rid:
                results[rid] = r
            items = _items_for_manifest(str(r.get("manifest_id") or ""), item_cache)
            if items:
                items_by_key.update({k: v for k, v in items.items() if k not in items_by_key})
    return {
        "case_id": str(case_id or ""),
        "results": results,
        "items_by_key": items_by_key,
        "evidence": load_case_evidence(case_id),
    }


# ---------------------------------------------------------------- finding → 区（含影子空间）
def _result_state(result) -> str:
    if not isinstance(result, dict):
        return ""
    d5 = result.get("d5") if isinstance(result.get("d5"), dict) else _loads(result.get("d5_json"))
    st = str(d5.get("status") or "").strip().lower()
    if st:
        return st
    return str(result.get("conclusion") or result.get("execution") or "").strip().lower()


def _evidence_anchorable(evidence_rows) -> bool:
    """有任一 anchor/quote（引文或定位）即视为可锚定；空列表 = 无证据行。"""
    for e in evidence_rows or []:
        if str(e.get("quote") or "").strip() or str(e.get("locator") or "").strip():
            return True
    return False


def shadow_reasons(finding, result=None, item=None, evidence_rows=None) -> list:
    """影子空间进入条件（满足任一即进；只返回原因，不改任何判定）。

    - 不可复算：D5 = insufficient / unknown；
    - 不可锚定：finding 无 anchor/quote（证据行为空或全部为空串）；
    - 跨文档无法归属：D3 声明 document_set 证据范围但不可用（无对齐键）；
    - 低置信：本期 calibration 样本数 0（从未校准），**不启用**单一置信度分流
      （docs/CURRENT/15 §1.1 明确「不用单一置信度」），故此处不产生原因。
    """
    reasons = []
    state = _result_state(result)
    if state in SHADOW_D5_STATES:
        reasons.append(f"不可复算:D5={state}")
    f_status = str((finding or {}).get("status") or "").strip().lower()
    f_state = str((finding or {}).get("state") or "").strip().lower()
    if f_status in SHADOW_FINDING_STATUSES or f_state in SHADOW_FINDING_STATES:
        reasons.append(f"待人工核:{f_status or f_state}")
    if evidence_rows is not None and not _evidence_anchorable(evidence_rows):
        reasons.append("不可锚定:无anchor/quote")
    if isinstance(result, dict):
        d3 = _loads(result.get("d3_json"))
        ds = _mapping(d3.get("document_set"))
        if ds.get("evaluated") and not ds.get("available"):
            reasons.append(
                f"跨文档无法归属:document_set不可用({ds.get('reason') or 'no_alignment_key'})")
    return reasons


def _item_for_finding(finding, results, items_by_key) -> dict:
    fid_result = str((finding or {}).get("manifest_result_id") or "").strip()
    result = results.get(fid_result) if fid_result else None
    if result:
        _robj = str(result.get("object_id") or "")
        for _key in (str(result.get("rule_id") or ""), str(result.get("rule_code") or "")):
            item = items_by_key.get((_key, _robj))
            if item is not None:
                return item
        return None
    # 无 manifest_result 的 finding：按 rule_id/object_id 猜 item（只用于分区展示）
    obj = str((finding or {}).get("object_id") or "")
    for key in (str((finding or {}).get("rule_id") or ""), str((finding or {}).get("point_id") or "")):
        if key and (key, obj) in items_by_key:
            return items_by_key[(key, obj)]
    return None


def base_zone_of_finding(finding, item=None) -> str:
    """finding 的点位级区（不含影子运行时判断）。"""
    if item is not None:
        zone = zone_of_item(item)
        if zone != ZONE_UNKNOWN:
            return zone
    for key in ("point_id", "rule_id", "rule_code"):
        pid = str((finding or {}).get(key) or "").strip()
        if pid:
            zone = zone_of_point_id(pid)
            if zone != ZONE_UNKNOWN:
                return zone
    return ZONE_UNKNOWN


def classify_findings(findings, results=None, items_by_key=None, evidence=None) -> dict:
    """纯函数：finding 列表 → 三区标记（不写库）。

    返回 ``{"counts": {zones + unknown}, "total", "findings": [{id, zone, base_zone,
    shadow_reasons, point_id, method, rule_code}]}``。
    三区计数之和恒等于 ``total``（影子是覆盖标签，不是新增条目）。
    """
    results = results or {}
    items_by_key = items_by_key or {}
    evidence = evidence or {}
    counts = {ZONE_DETERMINISTIC: 0, ZONE_EVIDENCE: 0, ZONE_SHADOW: 0, ZONE_UNKNOWN: 0}
    out = []
    for f in findings or []:
        fid = str((f or {}).get("id") or "")
        result = results.get(str((f or {}).get("manifest_result_id") or "")) if \
            str((f or {}).get("manifest_result_id") or "") else None
        item = _item_for_finding(f, results, items_by_key)
        ev = evidence.get(fid, [])
        base = base_zone_of_finding(f, item)
        reasons = shadow_reasons(f, result=result, item=item, evidence_rows=ev)
        zone = ZONE_SHADOW if reasons else base
        counts[zone] = counts.get(zone, 0) + 1
        out.append({
            "id": fid,
            "zone": zone,
            "base_zone": base,
            "shadow_reasons": reasons,
            "point_id": str((item or {}).get("audit_route", {}).get("point_id")
                            if isinstance((item or {}).get("audit_route"), dict)
                            else (f or {}).get("point_id") or ""),
            "method": method_of_point(_point_index().get(
                str(((item or {}).get("audit_route") or {}).get("point_id") or ""))) if item else "",
            "rule_code": str((f or {}).get("rule_id") or (f or {}).get("rule_code") or ""),
            "severity": str((f or {}).get("severity") or ""),
        })
    return {"counts": counts, "total": len(out), "findings": out}


def classify_case_findings(case_id: str, findings=None) -> dict:
    """只读：给一个 case 当前批次 finding 打三区标记并返回分布。

    与报告同源：默认 finding 口径 = review.case_report 的可见 finding；
    manifest item / D5 / 证据锚点从库只读。
    """
    idx = case_index(case_id)
    fs = findings if findings is not None else load_case_findings(case_id)
    out = classify_findings(fs, results=idx["results"], items_by_key=idx["items_by_key"],
                            evidence=idx["evidence"])
    out["case_id"] = str(case_id or "")
    out["switch_tagging"] = tagging_enabled()
    out["switch_report"] = report_enabled()
    return out


# ---------------------------------------------------------------- 报告用分区统计
def _row_zone(row, items_by_key) -> str:
    mid = str((row or {}).get("manifest_id") or "")
    rule_id = str((row or {}).get("rule_id") or "")
    code = str((row or {}).get("rule_code") or "")
    obj = str((row or {}).get("object_id") or "")
    item = items_by_key.get((rule_id, obj)) or items_by_key.get((code, obj)) if mid else None
    if item is None and mid:
        # rows 可能来自 review.case_report 的当前 active 结果；用 code 兜底
        item = items_by_key.get((code, obj))
    if item is not None:
        zone = zone_of_item(item)
        if zone != ZONE_UNKNOWN:
            return zone
    for pid in (code, rule_id):
        zone = zone_of_point_id(pid)
        if zone != ZONE_UNKNOWN:
            return zone
    return ZONE_UNKNOWN


def _row_state(row) -> str:
    if not isinstance(row, dict):
        return ""
    d5 = row.get("d5") if isinstance(row.get("d5"), dict) else _loads(row.get("d5_json"))
    st = str(d5.get("status") or "").strip().lower()
    if st:
        return st
    return str(row.get("conclusion") or row.get("execution") or "").strip().lower()


def _empty_judgment() -> dict:
    return {"judged": 0, "pass": 0, "fail": 0, "pass_rate": None, "not_judged": 0,
            "na": 0, "insufficient": 0, "unknown": 0, "other": 0}


def judgment_stats(rows, items_by_key) -> dict:
    """按区统计 manifest 执行结果：判定数 / fail / 通过率（分母只算本区判定）。

    判定 = 明确 pass/fail；na / insufficient / unknown / error 单列（不进通过率）。
    影子空间**不进通过率分母**：D5 insufficient/unknown 的结果只计数，不参与除法。
    """
    out = {ZONE_DETERMINISTIC: _empty_judgment(), ZONE_EVIDENCE: _empty_judgment(),
           ZONE_SHADOW: {"entries": 0, "excluded_from_denominator": True},
           ZONE_UNKNOWN: _empty_judgment()}
    for row in rows or []:
        zone = _row_zone(row, items_by_key)
        state = _row_state(row)
        if zone == ZONE_UNKNOWN:
            zone = ZONE_UNKNOWN
        if state in SHADOW_D5_STATES:
            out[ZONE_SHADOW]["entries"] += 1
            continue
        bucket = out[zone]
        if state == "pass":
            bucket["judged"] += 1
            bucket["pass"] += 1
        elif state == "fail":
            bucket["judged"] += 1
            bucket["fail"] += 1
        elif state == "na":
            bucket["not_judged"] += 1
            bucket["na"] += 1
        elif state == "insufficient":
            bucket["not_judged"] += 1
            bucket["insufficient"] += 1
        elif state == "unknown":
            bucket["not_judged"] += 1
            bucket["unknown"] += 1
        elif state:
            bucket["not_judged"] += 1
            bucket["other"] += 1
        else:
            bucket["not_judged"] += 1
            bucket["other"] += 1
    for zone in (ZONE_DETERMINISTIC, ZONE_EVIDENCE, ZONE_UNKNOWN):
        b = out[zone]
        b["pass_rate"] = (round(b["pass"] / b["judged"], 4) if b["judged"] else None)
    return out


def zone_view(findings, rows, case_id: str = "", cache: dict = None) -> dict:
    """报告/QA 共用：分区 finding 分布 + 分区判定统计 + 影子空间（只读）。

    - ``findings``：report 的 ``cr["findings"]``（或 classify_case_findings 的列表）
    - ``rows``：report 的 ``_manifest_rows``（含 manifest_id / d5 / rule_code）
    - 报告开关关闭时返回 ``{"enabled": False}``，调用方不渲染分区。
    """
    if not report_enabled():
        return {"enabled": False, "reason": f"{ENV_REPORT}=0"}
    cache = cache if cache is not None else {}
    cid = str(case_id or "")
    item_cache = cache.setdefault("items", {})
    items_by_key = {}
    for row in rows or []:
        mid = str((row or {}).get("manifest_id") or "")
        if not mid:
            continue
        items = _items_for_manifest(mid, item_cache)
        if items:
            for k, v in items.items():
                items_by_key.setdefault(k, v)
    results = {}
    for row in rows or []:
        rid = str((row or {}).get("id") or "")
        if rid:
            results[rid] = row
    evidence = cache.get("evidence")
    if evidence is None and cid:
        evidence = load_case_evidence(cid)
        cache["evidence"] = evidence
    if findings is None and cid:
        findings = load_case_findings(cid)
    classified = classify_findings(findings, results=results, items_by_key=items_by_key,
                                   evidence=evidence or {})
    judgments = judgment_stats(rows, items_by_key)
    # shadow 的「条数」以 finding 口径为准（每条形如：只展示、未计入通过率），
    # manifest 侧 D5 非法结论条目单独计（不重复计 finding）。
    reasons = {}
    for item in classified["findings"]:
        for reason in item["shadow_reasons"]:
            reasons[reason] = reasons.get(reason, 0) + 1
    return {
        "enabled": True,
        "case_id": cid,
        "findings": classified["counts"],
        "findings_total": classified["total"],
        "judgments": judgments,
        "shadow": {
            "finding_count": classified["counts"].get(ZONE_SHADOW, 0),
            "manifest_entries": judgments[ZONE_SHADOW]["entries"],
            "reasons": reasons,
            "excluded_from_denominator": True,
            "note": "影子空间只展示、不结论、不计入通过率；人工裁决后回流校准。",
        },
        "rollup": {
            "deterministic": classified["counts"].get(ZONE_DETERMINISTIC, 0),
            "evidence": classified["counts"].get(ZONE_EVIDENCE, 0),
            "shadow": classified["counts"].get(ZONE_SHADOW, 0),
            "unknown": classified["counts"].get(ZONE_UNKNOWN, 0),
            "total": classified["total"],
        },
    }


def zone_report_text(view: dict) -> str:
    """纯文本三区统计（CLI/日志/报告段落的单一文案来源）。"""
    if not view or not view.get("enabled"):
        return ""
    f = view.get("findings") or {}
    j = view.get("judgments") or {}
    lines = [
        f"按区统计（三分类）：确定性区 {f.get(ZONE_DETERMINISTIC, 0)} 条 / "
        f"证据区 {f.get(ZONE_EVIDENCE, 0)} 条 / 影子空间 {f.get(ZONE_SHADOW, 0)} 条 / "
        f"未映射 {f.get(ZONE_UNKNOWN, 0)} 条，合计 {view.get('findings_total', 0)} 条（finding 总数）",
    ]

    def _j(zone):
        b = j.get(zone) or {}
        rate = b.get("pass_rate")
        rate_s = "—" if rate is None else f"{rate:.1%}"
        return (f"{zone_label(zone)}：判定 {b.get('judged', 0)} 条 / fail {b.get('fail', 0)} 条 / "
                f"通过率 {rate_s}（分母只算本区判定）")

    lines.append(_j(ZONE_DETERMINISTIC))
    lines.append(_j(ZONE_EVIDENCE))
    sh = view.get("shadow") or {}
    lines.append(f"影子空间：{sh.get('finding_count', 0)} 条，仅展示，未计入通过率"
                 f"（manifest 非法结论 {sh.get('manifest_entries', 0)} 条单列）")
    return "\n".join(lines)


__all__ = [
    "ZONE_DETERMINISTIC", "ZONE_EVIDENCE", "ZONE_SHADOW", "ZONE_UNKNOWN",
    "ZONES", "ZONE_LABELS", "METHOD_TO_ZONE", "METHOD_LABELS",
    "EXECUTION_KIND_TO_ZONE", "ENV_TAGGING", "ENV_REPORT",
    "tagging_enabled", "report_enabled",
    "normalize_method", "method_of_point", "zone_of_method", "zone_of_point",
    "zone_of_execution_kind", "zone_of_point_id", "point_method_by_id",
    "zone_coverage", "zone_of_item", "item_zone_source", "count_item_zones",
    "load_manifest_items", "index_items", "load_case_findings", "load_case_results",
    "load_case_evidence", "case_index",
    "shadow_reasons", "base_zone_of_finding", "classify_findings",
    "classify_case_findings", "judgment_stats", "zone_view", "zone_report_text",
    "zone_label",
]
