"""本体消费开关 + 能力清单 + 影子评估/自动开关注册（T-197 / P0-1、P0-2、P1-1、P1-5）。

用户口径（2026-11-20）：「本体只对 3 类点位有价值，默认关 **按空间开**，有必要就自动开；
形态必须是结构化字典」。本模块把该口径落成可执行的产品能力：

1. **per-space 开关**：`workspace.settings_json["ontology"] = {"enabled", "mode", ...}`
   - `enabled` 默认 **False**（本模块上线前进程级 env 默认开 = 无治理强开）；
   - `mode` = `auto`（默认，允许按 ΔF1 CI 自动开/关）| `manual`（只记录不自动切换）；
   - 生效口径 = 空间 enabled ∧ env 未硬关（`RULEPROOF_ONTOLOGY_NORM=0`）∧ 模块未显式关
     （`mod_ontology=false`）。**关 = 不读本体**：
       · `cross_doc_consistency` 项目级执行器直接不执行（project.py 消费点）；
       · D4 冻结别名在冻结后被置空（`neutralize_manifest_ontology`）；
       · 实时消费钩子返回空（ontology_v2.alias_index/normalization_rules、
         ontology_workspace.alias_pairs、ontology_gate._load_overrides）。
2. **能力清单**：GET/POST `/api/v1/ontology/capabilities`。
   - 只把**真实接线**且能创建的执行能力列为 `status=wired`（当前只有跨文档一致性）；
   - 「分项合计 / 日期链」执行器虽存在但 0 处读本体 → 如实 `status=not_wired`
     （P1-1：不许假称支持），并从「本体能力」入口移除。
3. **影子评估**：审核完成后对项目级确定性执行器跑「开/关」双路（只记录不参与判定），
   落 `ontology_shadow_round`；`evaluate_round` 用带标签记录计算 ΔF1 + 95% CI（配对
   bootstrap，seed 固定），达到「CI 下界 ≥ +0.5pp」自动开、连续 2 轮「CI 上界 < 0」
   自动关，全部写审计（`ontology.auto_eval` / `ontology.switch_changed`）。
4. **能力契约**：`normalize_cross_doc_config` 校验规则槽位（键/两侧文件/标签/口径），
   给规则创建 API 与规则编辑器共用；`capabilities()` 输出创建入口契约字段。
"""
from __future__ import annotations

import json
import logging
import math
import os
import random
import threading
import time

from .. import db
from .. import repositories as R

LOG = logging.getLogger(__name__)

SETTINGS_KEY = "ontology"
DEFAULT_ENABLED = False
DEFAULT_MODE = "auto"
MODES = ("auto", "manual")

# 与 ruleexec 的 T-157 开关同源：进程级 env 仍是「硬回滚开关」，但不再是唯一开关。
ONTO_NORM_ENV = "RULEPROOF_ONTOLOGY_NORM"

# 自动评估门槛（预注册，写进 docs/qa/本体P0P1修复_20261120.md）
AUTO_ON_MIN_CI_LO = 0.005          # ΔF1 95% CI 下界 ≥ +0.5pp 才允许自动开
AUTO_OFF_CI_HI = 0.0               # CI 上界 < 0 记为一次负向轮次
AUTO_OFF_CONSECUTIVE = 2           # 连续 2 轮负向 → 自动关
EVAL_MIN_POINTS = 200              # 设计分辨率下限（评审 §5：累计点位 ≥200）
EVAL_MIN_POINTS_ENV = "RULEPROOF_ONTOLOGY_EVAL_MIN_POINTS"
BOOTSTRAP_N = 2000
BOOTSTRAP_SEED = 20261120
CACHE_TTL = 2.0

# 项目级执行器分类（P1-1 如实口径）
CROSS_DOC_CALC = "cross_doc_consistency"
AMOUNT_SUM_CALCS = ("unpaid_balance_cap", "segmented_fee_cap", "ledger_reconcile",
                    "invoice_payable", "inventory_snapshot")
DATE_CHAIN_CALCS = ("utc_deadline", "license_expiry_date", "delivery_deadline",
                    "certificate_validity", "batch_temperature_exception")
POINT_CLASSES = {
    CROSS_DOC_CALC: "same_fact_consistency",
    **{_c: "amount_sum" for _c in AMOUNT_SUM_CALCS},
    **{_c: "date_chain" for _c in DATE_CHAIN_CALCS},
}
POINT_CLASS_LABELS = {
    "same_fact_consistency": "同一事实前后一致（跨文档）",
    "amount_sum": "分项合计",
    "date_chain": "日期链",
}
CROSS_DOC_KEY_KINDS = ("entity", "label", "code")
CROSS_DOC_VALUE_TYPES = ("money", "quantity", "date", "code")

_TLS = threading.local()
_CACHE = {}
_CACHE_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _now() -> str:
    return db.now()


def _ctx() -> dict:
    try:
        from . import ctx as _ctx_mod
        return dict(_ctx_mod.get_context() or {})
    except Exception:
        return {}


def _tenant() -> str:
    return str(_ctx().get("tenant_id") or "")


def _ws_from_ctx() -> str:
    return str(_ctx().get("workspace_id") or "")


def env_enabled() -> bool:
    """进程级硬回滚开关（默认开；=0 时无论空间配置如何都不读本体）。"""
    v = str(os.environ.get(ONTO_NORM_ENV, "1") or "").strip().lower()
    return v not in ("", "0", "false", "no", "off")


def _workspace_row(ws_id: str) -> dict:
    ws_id = str(ws_id or "").strip()
    if not ws_id:
        return {}
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT id,tenant_id,name,status,settings_json FROM workspace WHERE id=?",
                (ws_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:
        LOG.debug("ontology workspace row lookup skipped", exc_info=True)
        return {}


def _settings(ws_id: str) -> dict:
    row = _workspace_row(ws_id)
    try:
        st = json.loads(row.get("settings_json") or "{}")
    except Exception:
        st = {}
    return st if isinstance(st, dict) else {}


def module_on(ws_id: str) -> bool:
    """`mod_ontology` 模块开关（默认开；显式 false 才关）。"""
    st = _settings(ws_id)
    if not st:
        return True
    if "mod_ontology" not in st:
        return True
    return bool(st.get("mod_ontology"))


def stored_control(ws_id: str) -> dict:
    """空间存储的原始开关（缺省 = enabled False / mode auto）。"""
    raw = _settings(ws_id).get(SETTINGS_KEY)
    raw = raw if isinstance(raw, dict) else {}
    enabled = raw.get("enabled")
    enabled = DEFAULT_ENABLED if enabled is None else bool(enabled)
    mode = str(raw.get("mode") or DEFAULT_MODE).strip().lower()
    if mode not in MODES:
        mode = DEFAULT_MODE
    return {"enabled": enabled, "mode": mode,
            "updated_at": str(raw.get("updated_at") or ""),
            "updated_by": str(raw.get("updated_by") or ""),
            "source": str(raw.get("source") or ""),
            "configured": bool(raw)}


def effective(ws_id: str) -> dict:
    """空间最终生效口径（不做缓存；API/审计/判定用）。"""
    ws_id = str(ws_id or "").strip()
    st = stored_control(ws_id) if ws_id else {"enabled": DEFAULT_ENABLED,
                                              "mode": DEFAULT_MODE, "configured": False,
                                              "updated_at": "", "updated_by": "", "source": ""}
    env = env_enabled()
    mod = module_on(ws_id) if ws_id else True
    enabled = bool(st["enabled"] and env and mod)
    reason = ""
    if not st["enabled"]:
        reason = "space_disabled"          # 空间开关默认关
    elif not env:
        reason = "env_hard_off"
    elif not mod:
        reason = "module_off"
    else:
        reason = "space_enabled"
    return {"workspace_id": ws_id, "enabled": enabled,
            "stored_enabled": bool(st["enabled"]), "mode": st["mode"],
            "configured": bool(st.get("configured")),
            "env_enabled": env, "module_on": bool(mod),
            "reason": reason, "stored": st}


def invalidate(ws_id: str = "") -> None:
    with _CACHE_LOCK:
        if ws_id:
            _CACHE.pop(str(ws_id), None)
        else:
            _CACHE.clear()


def _cached_enabled(ws_id: str) -> bool:
    key = str(ws_id or "")
    now = time.time()
    with _CACHE_LOCK:
        hit = _CACHE.get(key)
        if hit and now - hit[1] <= CACHE_TTL:
            return hit[0]
    val = effective(key)["enabled"] if key else env_enabled()
    with _CACHE_LOCK:
        _CACHE[key] = (val, now)
    return val


def _forced():
    return getattr(_TLS, "force", None)


class force_consumption:  # noqa: N801 - 小写 API 便于 with 语句
    """影子评估用：临时强制消费开/关（线程内，不落库、不写空间配置）。"""

    def __init__(self, enabled: bool):
        self.enabled = bool(enabled)
        self.prev = None

    def __enter__(self):
        self.prev = getattr(_TLS, "force", None)
        _TLS.force = self.enabled
        return self

    def __exit__(self, *a):
        _TLS.force = self.prev
        return False


def consumption_enabled(feature: str = "") -> bool:
    """判定链消费开关（引擎 hooks 调用）：影子强制 > 空间生效口径。

    - 无空间上下文（脚本/旧调用方）沿用 env 口径，保证既有实验脚本行为不变；
    - 有空间上下文（HTTP/审核/CLI --ws）一律按空间开关。
    """
    forced = _forced()
    if forced is not None:
        return bool(forced)
    if not env_enabled():
        return False
    ws_id = _ws_from_ctx()
    if not ws_id:
        return True     # 无空间上下文：保持旧行为（CLI/脚本显式 --ws 后走空间口径）
    return _cached_enabled(ws_id)


def consumption_enabled_for(workspace_id: str) -> bool:
    """按显式空间判定消费开关（冻结快照/服务层传 ws_id 的场景）。"""
    forced = _forced()
    if forced is not None:
        return bool(forced)
    if not env_enabled():
        return False
    ws_id = str(workspace_id or "").strip()
    if not ws_id:
        return consumption_enabled()
    return _cached_enabled(ws_id)


# ---------------------------------------------------------------------------
# 开关写入（同事务审计）
# ---------------------------------------------------------------------------
def _write_settings(ws_id: str, patch: dict, actor: str) -> dict:
    """把 patch 合入 workspace.settings_json（只合并，不覆盖其他设置）。"""
    from . import audit as _audit
    ws_id = str(ws_id or "").strip()
    with db.session() as c:
        row = c.execute("SELECT tenant_id,settings_json FROM workspace WHERE id=? AND status='active'",
                        (ws_id,)).fetchone()
        if not row:
            return {"ok": False, "code": "not_found", "reason": "工作空间不存在或已归档"}
        tenant = str(row["tenant_id"] or "")
        ctx_tenant = _tenant()
        try:
            from . import ctx as _ctx_mod
            system = bool(_ctx_mod.is_system())
        except Exception:
            system = False
        if ctx_tenant and tenant and tenant != ctx_tenant and not system:
            return {"ok": False, "code": "forbidden", "reason": "不能修改其他租户的空间"}
        try:
            st = json.loads(row["settings_json"] or "{}")
        except Exception:
            st = {}
        st = st if isinstance(st, dict) else {}
        before = json.dumps(st.get(SETTINGS_KEY) or {}, ensure_ascii=False, sort_keys=True)
        cur = st.get(SETTINGS_KEY) if isinstance(st.get(SETTINGS_KEY), dict) else {}
        cur = dict(cur)
        cur.update(patch)
        cur["updated_at"] = _now()
        cur["updated_by"] = str(actor or "system")
        st[SETTINGS_KEY] = cur
        c.execute("UPDATE workspace SET settings_json=? WHERE id=?",
                  (json.dumps(st, ensure_ascii=False), ws_id))
        after = json.dumps(cur, ensure_ascii=False, sort_keys=True)
        _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.switch_changed",
                         object_=ws_id, before=before, after=after)
    invalidate(ws_id)
    return {"ok": True, "workspace_id": ws_id, "after": after}


def set_control(ws_id: str, *, enabled=None, mode=None, actor: str = "",
                reason: str = "", source: str = "manual") -> dict:
    """人工/自动切换空间本体开关。返回切换前后 + 生效口径（全部写审计）。"""
    ws_id = str(ws_id or "").strip() or _ws_from_ctx()
    if not ws_id:
        return {"ok": False, "code": "workspace_required", "reason": "缺少工作空间上下文"}
    before = effective(ws_id)
    patch = {"source": str(source or "manual"), "reason": str(reason or "")[:300]}
    if enabled is not None:
        patch["enabled"] = bool(enabled)
    if mode is not None:
        mode_v = str(mode).strip().lower()
        if mode_v not in MODES:
            return {"ok": False, "code": "invalid_mode",
                    "reason": "mode 只能是 auto / manual"}
        patch["mode"] = mode_v
    if len(patch) == 2:      # 只有 source/reason → 没有实际变更
        return {"ok": False, "code": "no_change", "reason": "未提供 enabled / mode"}
    out = _write_settings(ws_id, patch, actor)
    if not out.get("ok"):
        return {**before, **out}
    after = effective(ws_id)
    return {"ok": True, "workspace_id": ws_id, "before": before, "after": after,
            "changed": {"enabled": before["stored_enabled"] != after["stored_enabled"],
                        "mode": before["mode"] != after["mode"]},
            "reason": str(reason or "")[:300], "source": source}


# ---------------------------------------------------------------------------
# 能力清单（P0-1 入口契约 / P1-1 如实标注）
# ---------------------------------------------------------------------------
def _capabilities_catalog() -> list:
    return [
        {
            "id": "cross_doc_consistency",
            "name": "同一事实前后一致（跨文档键对齐）",
            "status": "wired",
            "category": "same_fact_consistency",
            "execution_mode": CROSS_DOC_CALC,
            "calculation": CROSS_DOC_CALC,
            "consumes_ontology": True,
            "switch_key": "ontology.enabled",
            "summary": ("在同一项目的两份文档之间按显式键对齐（字面/归一/编号易混/本体别名），"
                        "对声明口径的值做确定性比较；键未对齐或取值失败记「证据不足」，"
                        "不猜、不按相似度自动合并。"),
            "key_kinds": list(CROSS_DOC_KEY_KINDS),
            "value_types": list(CROSS_DOC_VALUE_TYPES),
            "entry": {
                "ui": "规则详情 → 编辑规则 → 执行能力「跨文档一致性」→ 填键/字段/口径 → 保存 → 发布",
                "http_create": "POST /api/v1/rules/custom  body.slots.execution_mode=cross_doc_consistency + body.slots.cross_doc",
                "http_configure": "POST /api/v1/ontology/capabilities  {action: configure_rule, rule_id, execution_mode, cross_doc}",
                "cli": "rp rule create/import 的 slots JSON 带 execution_mode + cross_doc（CLI 无独立子命令，见交付说明）",
            },
            "contract": {
                "execution_mode": CROSS_DOC_CALC,
                "key_kind": "entity|label|code（默认 entity）",
                "owner_file": "结论归属文件名（默认=left.file）",
                "left": {"file": "左侧文件名（子串定位）", "key_label": "键标签",
                         "key": "显式键值（无标签场景）", "value_label": "值标签",
                         "value_type": "money|quantity|date|code"},
                "right": {"file": "右侧文件名（不得与 left.file 相同）", "key_label": "...",
                          "key": "...", "value_label": "...", "value_type": "..."},
            },
            "requires": ["项目内至少 2 份可解析文档", "两侧文件名可按子串定位",
                         "两侧键可对齐（字面/编号/本体别名）"],
        },
        {
            "id": "amount_sum",
            "name": "分项合计",
            "status": "not_wired",
            "category": "amount_sum",
            "execution_mode": "",
            "calculation": "",
            "consumes_ontology": False,
            "reason": ("分项合计类执行器（" + "、".join(AMOUNT_SUM_CALCS) + "）当前源码 0 处读本体；"
                       "按 P1-1 如实标注为「暂不支持本体能力」，不作为本体能力入口提供。"),
            "legacy_executors": list(AMOUNT_SUM_CALCS),
        },
        {
            "id": "date_chain",
            "name": "日期链",
            "status": "not_wired",
            "category": "date_chain",
            "execution_mode": "",
            "calculation": "",
            "consumes_ontology": False,
            "reason": ("日期链类执行器（" + "、".join(DATE_CHAIN_CALCS) + "）当前源码 0 处读本体；"
                       "按 P1-1 如实标注为「暂不支持本体能力」，不作为本体能力入口提供。"),
            "legacy_executors": list(DATE_CHAIN_CALCS),
        },
    ]


def _latest_eval(ws_id: str) -> dict:
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT * FROM ontology_switch_eval WHERE workspace_id=? "
                "ORDER BY created_at DESC, id DESC LIMIT 1", (ws_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:
        return {}


def _shadow_summary(ws_id: str, limit: int = 20) -> dict:
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT * FROM ontology_shadow_round WHERE workspace_id=? "
                "ORDER BY created_at DESC, id DESC LIMIT ?", (ws_id, int(limit))).fetchall()
    except Exception:
        rows = []
    rounds, labeled, changed = [], 0, 0
    for r in rows:
        d = dict(r)
        try:
            labels = json.loads(d.get("labels_json") or "[]")
        except Exception:
            labels = []
        if labels:
            labeled += 1
        changed += int(d.get("changed_count") or 0)
        rounds.append({"id": d.get("id"), "case_id": d.get("case_id"),
                       "created_at": d.get("created_at"),
                       "point_count": int(d.get("point_count") or 0),
                       "changed_count": int(d.get("changed_count") or 0),
                       "labeled": bool(labels)})
    return {"rounds": len(rows), "labeled_rounds": labeled,
            "changed_points": changed, "recent": rounds}


def _recent_evals(ws_id: str, limit: int = 10) -> list:
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT * FROM ontology_switch_eval WHERE workspace_id=? "
                "ORDER BY created_at DESC, id DESC LIMIT ?", (ws_id, int(limit))).fetchall()
    except Exception:
        return []
    out = []
    for r in rows:
        d = dict(r)
        out.append({"id": d.get("id"), "round_no": d.get("round_no"),
                    "action": d.get("action"), "n": d.get("n"),
                    "delta_pp": round(float(d.get("delta_f1") or 0) * 100, 3),
                    "ci_lo_pp": round(float(d.get("ci_lo") or 0) * 100, 3),
                    "ci_hi_pp": round(float(d.get("ci_hi") or 0) * 100, 3),
                    "f1_on": d.get("f1_on"), "f1_off": d.get("f1_off"),
                    "min_n": d.get("min_n"),
                    "enabled_before": bool(d.get("enabled_before")),
                    "enabled_after": bool(d.get("enabled_after")),
                    "created_at": d.get("created_at")})
    return out


def switch_report(ws_id: str = "") -> dict:
    """开关页/API 的统一状态：生效口径 + 自动评估门槛 + 最近评估 + 影子轮次。"""
    ws_id = str(ws_id or "").strip() or _ws_from_ctx()
    if not ws_id:
        return {"ok": False, "code": "workspace_required", "reason": "缺少工作空间"}
    ctl = effective(ws_id)
    return {"ok": True, "workspace_id": ws_id, "switch": ctl,
            "stored": stored_control(ws_id),
            "auto_evaluation": {
                "enabled": ctl["mode"] == "auto",
                "min_points": _min_points(),
                "auto_on_ci_lo_pp": AUTO_ON_MIN_CI_LO * 100,
                "auto_off_consecutive": AUTO_OFF_CONSECUTIVE,
                "bootstrap_n": BOOTSTRAP_N, "seed": BOOTSTRAP_SEED,
                "recent": _recent_evals(ws_id),
                "shadow": _shadow_summary(ws_id),
            },
            "decision_rule": "默认关；仅在 auto 模式下按 ΔF1 95%CI 自动开/关（下界≥+0.5pp 开；"
                             "连续 2 轮上界<0 关），每次切换写审计 ontology.switch_changed。"}


def capabilities(ws_id: str = "") -> dict:
    """能力清单 + 当前空间开关 + 自动评估状态（P0-1 产品入口的统一事实源）。"""
    ws_id = str(ws_id or "").strip() or _ws_from_ctx()
    ctl = effective(ws_id) if ws_id else {
        "workspace_id": "", "enabled": env_enabled(), "stored_enabled": DEFAULT_ENABLED,
        "mode": DEFAULT_MODE, "configured": False, "env_enabled": env_enabled(),
        "module_on": True, "reason": "no_workspace_context", "stored": {}}
    ev = _latest_eval(ws_id) if ws_id else {}
    return {
        "ok": True,
        "workspace_id": ws_id,
        "switch": ctl,
        "mode": ctl.get("mode"),
        "auto_evaluation": {
            "enabled": ctl.get("mode") == "auto",
            "min_points": _min_points(),
            "auto_on_ci_lo_pp": AUTO_ON_MIN_CI_LO * 100,
            "auto_off_consecutive": AUTO_OFF_CONSECUTIVE,
            "last_eval": ev,
            "shadow": _shadow_summary(ws_id) if ws_id else {"rounds": 0, "labeled_rounds": 0,
                                                            "changed_points": 0, "recent": []},
        },
        "capabilities": _capabilities_catalog(),
        "not_wired": ["amount_sum", "date_chain"],
        "requires_ontology_on": True,
    }


# ---------------------------------------------------------------------------
# 能力契约：cross_doc_consistency 配置校验 / 规则槽位归一（P0-1）
# ---------------------------------------------------------------------------
def _clean_side(side, label: str) -> dict:
    side = side if isinstance(side, dict) else {}
    out = {}
    for key in ("file", "key_label", "key", "value_label", "value_type"):
        out[key] = str(side.get(key) or "").strip()
    return out


def normalize_cross_doc_config(cfg: dict) -> dict:
    """校验并归一跨文档一致性槽位；非法输入抛 ValueError（HTTP 400 / UI 提示）。

    返回 ruleexec 认识的 ``project_compute`` 结构（见 ruleexec._calc_cross_doc_consistency）。
    """
    if not isinstance(cfg, dict):
        raise ValueError("cross_doc 配置必须是对象")
    key_kind = str(cfg.get("key_kind") or "entity").strip().lower()
    if key_kind not in CROSS_DOC_KEY_KINDS:
        raise ValueError("key_kind 只能是 %s（收到 %s）" % ("/".join(CROSS_DOC_KEY_KINDS), key_kind))
    left = _clean_side(cfg.get("left"), "left")
    right = _clean_side(cfg.get("right"), "right")
    errors = []
    for name, side in (("left", left), ("right", right)):
        if not side["file"]:
            errors.append(f"{name}.file 不能为空（用于定位文档）")
        if not side["value_label"]:
            errors.append(f"{name}.value_label 不能为空（要比较的值标签）")
        if side["value_type"] not in CROSS_DOC_VALUE_TYPES:
            errors.append(f"{name}.value_type 必须是 {'/'.join(CROSS_DOC_VALUE_TYPES)}"
                          f"（收到 {side['value_type'] or '空'}）")
        if key_kind == "label" and not (side["key_label"] or side["key"]):
            errors.append(f"{name} 的 key_kind=label 时必须给 key_label 或 key")
        if key_kind in ("entity", "code") and not (side["key_label"] or side["key"]):
            errors.append(f"{name} 必须声明 key_label（从文档取键）或 key（显式键值）")
    if left["file"] and right["file"] and left["file"] == right["file"]:
        errors.append("跨文档一致性要求 left.file ≠ right.file（同一文件请用单文档规则）")
    if left["value_type"] and right["value_type"] and left["value_type"] != right["value_type"]:
        errors.append("两侧 value_type 必须一致（%s vs %s）"
                      % (left["value_type"], right["value_type"]))
    owner = str(cfg.get("owner_file") or "").strip() or left["file"]
    if owner and owner not in (left["file"], right["file"]):
        errors.append("owner_file 必须是 left.file 或 right.file（结论归属执行文件）")
    if errors:
        raise ValueError("跨文档一致性配置不合法：" + "；".join(errors[:6]))
    vtype = left["value_type"] or right["value_type"]
    right["value_type"] = right["value_type"] or vtype
    left["value_type"] = vtype
    return {"calculation": CROSS_DOC_CALC, "owner_file": owner, "key_kind": key_kind,
            "left": left, "right": right}


def normalize_execution_slots(slots: dict) -> tuple:
    """规则创建/编辑入口统一口径：把 execution_mode + cross_doc 归一进 slots。

    宽松兼容三种入参：
      1. ``slots.execution_mode=cross_doc_consistency`` + ``slots.cross_doc={...}``
      2. ``slots.execution_mode=cross_doc_consistency`` + ``slots.project_compute={...}``
      3. 直接给 ``slots.project_compute.calculation=cross_doc_consistency``
    返回 (slots, capability_meta)；非本体能力返回原 slots + None。
    """
    slots = dict(slots or {})
    mode = str(slots.pop("execution_mode", "") or "").strip()
    raw = slots.pop("cross_doc", None)
    pc = slots.get("project_compute")
    calc = str((pc or {}).get("calculation") or "").strip() if isinstance(pc, dict) else ""
    if mode and mode not in (CROSS_DOC_CALC, "single", "default", "rule"):
        raise ValueError("execution_mode 只支持 %s（收到 %s）" % (CROSS_DOC_CALC, mode))
    wants = mode == CROSS_DOC_CALC or calc == CROSS_DOC_CALC or isinstance(raw, dict)
    if not wants:
        return slots, None
    cfg = raw if isinstance(raw, dict) else (pc if isinstance(pc, dict) else {})
    spec = normalize_cross_doc_config(cfg)
    slots["project_compute"] = spec
    # 不覆写 _template/_executor：执行器选择在 project.py 的「项目级补执行」阶段完成
    # （manifest 单文件 D4 不执行它）；发布门禁的 executor_reachable 会按普通模板放行。
    slots["execution_mode"] = CROSS_DOC_CALC
    # 发布门禁（rule_ir R4 关系规则）需要 typed relation：把跨文档比对声明成
    # 「左值 与 右值 跨文档一致」，这样 IR 契约可证明「有两个可比较对象」，
    # 而不是靠散文判据（禁止伪造：relation 直接来自用户填的 cross_doc 配置）。
    _l_ir = spec["left"].get("key_label") or spec["left"].get("value_label") or ""
    _r_ir = spec["right"].get("key_label") or spec["right"].get("value_label") or ""
    if _l_ir and _r_ir:
        slots["relations"] = [{"left": _l_ir, "right": _r_ir,
                               "compare": "equal", "across": "document_set",
                               "source": "ontology_capability"}]
        slots["left"] = _l_ir
        slots["right"] = _r_ir
        slots["across"] = "document_set"
    slots.setdefault("on_insufficient", "abstain")
    # 冻结/执行显示口径：判据文本（人不读则仍按 project_compute 执行）
    if not str(slots.get("criterion") or "").strip():
        slots["criterion"] = ("跨文档一致性：%s 的 %s（%s）与 %s 的 %s（%s）键对齐后比较"
                              % (spec["left"]["file"], spec["left"]["value_label"],
                                 spec["left"]["value_type"], spec["right"]["file"],
                                 spec["right"]["value_label"], spec["right"]["value_type"]))
    meta = {"execution_mode": CROSS_DOC_CALC, "project_compute": spec,
            "capability": "cross_doc_consistency"}
    return slots, meta


def clear_execution_capability(slots: dict) -> dict:
    """把规则执行能力恢复为普通规则（清掉 project_compute 与能力注入的 IR 口径）。"""
    slots = dict(slots or {})
    pc = slots.get("project_compute")
    if isinstance(pc, dict) and str(pc.get("calculation") or "") == CROSS_DOC_CALC:
        slots.pop("project_compute", None)
        slots.pop("execution_mode", None)
        # 能力注入的 typed relation/左右对象只用于发布门禁；清除能力时必须一起撤掉，
        # 避免“显示普通规则、发布门禁仍按关系规则”的口径分叉。
        rels = slots.get("relations")
        if isinstance(rels, list):
            keep = [r for r in rels if not (isinstance(r, dict)
                                            and r.get("source") == "ontology_capability")]
            if keep:
                slots["relations"] = keep
            else:
                slots.pop("relations", None)
        for key in ("left", "right", "across"):
            slots.pop(key, None)
    return slots


# ---------------------------------------------------------------------------
# 冻结清单的 D4 本体消费闸门（P0-2 / P1-5）
# ---------------------------------------------------------------------------
_SNAPSHOT_PREFIX = "manifest_ontology:"


def neutralize_manifest_ontology(manifest_id: str, *, reason: str = "",
                                 actor: str = "system") -> dict:
    """空间本体关闭时：把本次冻结清单里 D4 会消费的本体别名/实体/关系置空。

    只改该 manifest 的冻结快照（items_json + sys_config manifest_ontology:<id>），
    不动全局资产、不回写规则；并在同一事务写 `ontology.consumption_disabled` 审计。
    D4 后续只读 item.ontology_binding → 不读本体（关 = 不读）。
    """
    from . import audit as _audit
    mid = str(manifest_id or "").strip()
    if not mid:
        return {"ok": False, "reason": "manifest_id_required"}
    changed_items, alias_n = 0, 0
    try:
        with db.session() as c:
            row = c.execute("SELECT items_json FROM audit_manifest WHERE id=?", (mid,)).fetchone()
            if not row:
                return {"ok": False, "reason": "manifest_not_found"}
            try:
                items = json.loads(row["items_json"] or "[]")
            except Exception:
                items = []
            for it in items:
                if not isinstance(it, dict):
                    continue
                b = it.get("ontology_binding")
                if not isinstance(b, dict):
                    continue
                aliases = b.get("aliases") if isinstance(b.get("aliases"), dict) else {}
                n = sum(len(v or []) for v in aliases.values())
                if n or b.get("terms") or b.get("entities"):
                    it["ontology_binding"] = {
                        **b, "aliases": {}, "terms": [], "entities": [], "relations": [],
                        "switch_disabled": True, "original_alias_count": n,
                        "note": "空间本体能力未启用（ontology.enabled=false）：D4 不读本体别名/实体"}
                    changed_items += 1
                    alias_n += n
            c.execute("UPDATE audit_manifest SET items_json=? WHERE id=?",
                      (json.dumps(items, ensure_ascii=False), mid))
            key = _SNAPSHOT_PREFIX + mid
            snap = c.execute("SELECT value FROM sys_config WHERE key=?", (key,)).fetchone()
            if snap and snap["value"]:
                try:
                    data = json.loads(snap["value"])
                except Exception:
                    data = {}
                if isinstance(data, dict):
                    data["aliases"] = {}
                    data["terms"] = []
                    data["entities"] = []
                    data["relations"] = []
                    data["switch_disabled"] = True
                    data["note"] = "空间本体能力未启用（ontology.enabled=false）：D4 不读本体"
                    c.execute("INSERT OR REPLACE INTO sys_config(key,value,updated_at) VALUES(?,?,?)",
                              (key, json.dumps(data, ensure_ascii=False), _now()))
            _audit.log_in_tx(
                c, actor=str(actor or "system"), action="ontology.consumption_disabled",
                object_=mid,
                after=json.dumps({"reason": reason, "items_neutralized": changed_items,
                                  "aliases_removed": alias_n,
                                  "switch": {"enabled": False, "mode": stored_control(_ws_from_ctx())["mode"]}},
                                 ensure_ascii=False)[:2000])
    except Exception as exc:  # noqa: BLE001 - 闸门失败必须显式返回（审核调用方决定是否继续）
        LOG.warning("neutralize manifest ontology failed manifest=%s: %s", mid, exc)
        return {"ok": False, "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    return {"ok": True, "manifest_id": mid, "items_neutralized": changed_items,
            "aliases_removed": alias_n, "reason": reason}


# ---------------------------------------------------------------------------
# 影子记录（只记不判） + ΔF1 CI 自动评估（P0-2）
# ---------------------------------------------------------------------------
def _min_points() -> int:
    try:
        return max(2, int(os.environ.get(EVAL_MIN_POINTS_ENV) or EVAL_MIN_POINTS))
    except Exception:
        return EVAL_MIN_POINTS


def point_class(calc: str) -> str:
    return POINT_CLASSES.get(str(calc or "").strip(), "")


def _state_norm(state) -> str:
    s = str(state or "").strip()
    return {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
            "不适用": "na", "执行失败": "failed"}.get(s, s or "unknown")


def record_audit_shadow(workspace_id: str, *, case_id: str = "", run_id: str = "",
                        specs: list = None, documents: list = None) -> dict:
    """审核完成后跑「开/关」双路项目级确定性执行器，只记录差异（不写 finding/报告）。

    specs: [{"rule": code, "calc": project_compute.calculation, "slots": {...}}]
    返回 {recorded, point_count, changed_count, classes}。
    """
    from ..engine import ruleexec as _rex
    ws_id = str(workspace_id or "").strip() or _ws_from_ctx()
    if not ws_id or not specs:
        return {"ok": False, "reason": "no_workspace_or_specs", "recorded": 0}
    records, classes = [], {}
    for spec in specs:
        if not isinstance(spec, dict):
            continue
        calc = str(spec.get("calc") or "").strip()
        cls = point_class(calc)
        if not cls:
            continue
        slots = spec.get("slots") if isinstance(spec.get("slots"), dict) else {}
        try:
            with force_consumption(True):
                on = _rex.judge_project_compute(slots, documents or [])
            with force_consumption(False):
                off = _rex.judge_project_compute(slots, documents or [])
        except Exception as exc:  # noqa: BLE001 - 影子失败只记录，不影响审核
            LOG.warning("shadow arm failed calc=%s: %s", calc, exc)
            continue
        on_state = _state_norm(on.get("state"))
        off_state = _state_norm(off.get("state"))
        rec = {"class": cls, "calc": calc, "rule": str(spec.get("rule") or ""),
               "object_id": str(spec.get("owner_object_id") or ""),
               "on_state": on_state, "off_state": off_state,
               "changed": on_state != off_state,
               "on_detail": str(on.get("detail") or "")[:200],
               "off_detail": str(off.get("detail") or "")[:200],
               "align_on": str((on.get("trace") or {}).get("inputs", {}).get("align_source") or ""),
               "align_off": str((off.get("trace") or {}).get("inputs", {}).get("align_source") or "")}
        records.append(rec)
        st = classes.setdefault(cls, {"points": 0, "changed": 0})
        st["points"] += 1
        if rec["changed"]:
            st["changed"] += 1
    if not records:
        return {"ok": False, "reason": "no_records", "recorded": 0}
    rid = db.new_id("osh")
    with db.session() as c:
        c.execute(
            "INSERT INTO ontology_shadow_round(id,case_id,run_id,tenant_id,workspace_id,"
            "point_count,changed_count,classes_json,records_json,labels_json,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (rid, str(case_id or ""), str(run_id or ""), _tenant(), ws_id,
             len(records), sum(1 for r in records if r["changed"]),
             json.dumps(classes, ensure_ascii=False),
             json.dumps(records[:200], ensure_ascii=False), "[]", _now()))
    return {"ok": True, "round_id": rid, "recorded": len(records),
            "point_count": len(records),
            "changed_count": sum(1 for r in records if r["changed"]),
            "classes": classes}


def submit_shadow_labels(workspace_id: str, labels: list, *, actor: str = "") -> dict:
    """影子样本打标签（人工复核/QA 基准回填）：按 (class, rule, object_id) 匹配。"""
    ws_id = str(workspace_id or "").strip() or _ws_from_ctx()
    labels = [x for x in (labels or []) if isinstance(x, dict)]
    if not ws_id or not labels:
        return {"ok": False, "reason": "workspace_or_labels_required", "labeled": 0}
    labeled = 0
    with db.session() as c:
        rows = c.execute("SELECT id,records_json,labels_json FROM ontology_shadow_round "
                         "WHERE workspace_id=? ORDER BY created_at DESC LIMIT 50", (ws_id,)).fetchall()
        for row in rows:
            try:
                cur = json.loads(row["labels_json"] or "[]")
                recs = json.loads(row["records_json"] or "[]")
            except Exception:
                continue
            keys = {(str(r.get("class") or ""), str(r.get("rule") or ""),
                     str(r.get("object_id") or "")) for r in recs if isinstance(r, dict)}
            hit = []
            for lab in labels:
                key = (str(lab.get("class") or ""), str(lab.get("rule") or ""),
                       str(lab.get("object_id") or ""))
                gold = str(lab.get("gold") or lab.get("label") or "").strip()
                gold = {"满足": "pass", "不满足": "fail", "pass": "pass",
                        "fail": "fail", "true_problem": "fail",
                        "false_positive": "pass"}.get(gold, "")
                if not gold or key not in keys:
                    continue
                hit.append({"class": key[0], "rule": key[1], "object_id": key[2], "gold": gold})
            if not hit:
                continue
            cur.extend(hit)
            c.execute("UPDATE ontology_shadow_round SET labels_json=? WHERE id=?",
                      (json.dumps(cur, ensure_ascii=False), row["id"]))
            labeled += len(hit)
        from . import audit as _audit
        _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.shadow_labeled",
                         object_=ws_id,
                         after=json.dumps({"labeled": labeled, "workspace_id": ws_id},
                                          ensure_ascii=False))
    return {"ok": True, "labeled": labeled, "workspace_id": ws_id}


def _f1(tp: int, fp: int, fn: int) -> float:
    if tp <= 0:
        return 0.0
    p = tp / (tp + fp) if (tp + fp) else 0.0
    r = tp / (tp + fn) if (tp + fn) else 0.0
    return (2 * p * r / (p + r)) if (p + r) else 0.0


def _arm_counts(records: list, arm: str) -> tuple:
    """按 arm（on/off）状态 vs gold 计算混淆矩阵；正类=fail（检出问题）。"""
    tp = fp = fn = tn = 0
    for r in records:
        gold = str(r.get("gold") or "")
        pred = str(r.get(f"{arm}_state") or "")
        if gold not in ("pass", "fail"):
            continue
        pred_fail = pred == "fail"
        gold_fail = gold == "fail"
        if pred_fail and gold_fail:
            tp += 1
        elif pred_fail and not gold_fail:
            fp += 1
        elif not pred_fail and gold_fail:
            fn += 1
        elif not pred_fail and not gold_fail:
            tn += 1
    return tp, fp, fn, tn


def _paired_delta_ci(records: list, n_boot: int = BOOTSTRAP_N, seed: int = BOOTSTRAP_SEED):
    """配对 bootstrap：ΔF1 = F1_on - F1_off 的 95% CI（百分位法）。"""
    usable = [r for r in records if str(r.get("gold") or "") in ("pass", "fail")]
    n = len(usable)
    if n < 2:
        return {"n": n, "delta": 0.0, "ci_lo": 0.0, "ci_hi": 0.0, "f1_on": 0.0, "f1_off": 0.0}
    on_c = _arm_counts(usable, "on")
    off_c = _arm_counts(usable, "off")
    f1_on = _f1(*on_c[:3])
    f1_off = _f1(*off_c[:3])
    delta = f1_on - f1_off
    rng = random.Random(seed)
    deltas = []
    for _ in range(max(200, int(n_boot))):
        sample = [usable[rng.randrange(n)] for _ in range(n)]
        d = _f1(*_arm_counts(sample, "on")[:3]) - _f1(*_arm_counts(sample, "off")[:3])
        deltas.append(d)
    deltas.sort()
    lo = deltas[int(0.025 * (len(deltas) - 1))]
    hi = deltas[int(0.975 * (len(deltas) - 1))]
    return {"n": n, "delta": delta, "ci_lo": lo, "ci_hi": hi,
            "f1_on": f1_on, "f1_off": f1_off,
            "confusion": {"on": {"tp": on_c[0], "fp": on_c[1], "fn": on_c[2], "tn": on_c[3]},
                          "off": {"tp": off_c[0], "fp": off_c[1], "fn": off_c[2], "tn": off_c[3]}}}


def _negative_streak(ws_id: str, limit: int = 5) -> int:
    try:
        with db.session() as c:
            # 排序必须确定：id 是随机前缀 id（非自增），同一秒内多行用 id 排会乱序，
            # 导致「连续 2 轮」计数在测试/真实高频评估时抖动（2026-11-20 修）。
            # round_no 是单调轮次，优先用它，其次 created_at。
            rows = c.execute(
                "SELECT ci_hi,action FROM ontology_switch_eval WHERE workspace_id=? "
                "ORDER BY round_no DESC, created_at DESC LIMIT ?", (ws_id, int(limit))).fetchall()
    except Exception:
        return 0
    streak = 0
    for r in rows:
        try:
            ci_hi = float(r["ci_hi"])
        except Exception:
            break
        if ci_hi < AUTO_OFF_CI_HI:
            streak += 1
        else:
            break
    return streak


def evaluate_round(workspace_id: str, records: list, *, actor: str = "",
                   min_points: int = None, trigger: str = "manual") -> dict:
    """用带标签样本做一次 ΔF1 + 95%CI 评估，并按预注册门槛自动开/关。

    records: [{"class","rule","object_id","on_state","off_state","gold"}]
    gold: pass/fail（正类=fail）。无标签记录不参与 F1，只进覆盖率对照。
    返回报告（含 decision/action、before/after 开关、审计落库）。
    """
    from . import audit as _audit
    ws_id = str(workspace_id or "").strip() or _ws_from_ctx()
    if not ws_id:
        return {"ok": False, "reason": "workspace_required"}
    min_n = int(min_points or _min_points())
    ctl = effective(ws_id)
    labeled = [r for r in (records or [])
               if isinstance(r, dict) and str(r.get("gold") or "") in ("pass", "fail")]
    stat = _paired_delta_ci(labeled)
    # 覆盖率对照（无标签也能算，给人工参考；不参与自动开关）
    coverage = {"on_decidable": sum(1 for r in (records or [])
                                    if str((r or {}).get("on_state") or "") in ("pass", "fail")),
                "off_decidable": sum(1 for r in (records or [])
                                     if str((r or {}).get("off_state") or "") in ("pass", "fail")),
                "n": len(records or [])}
    classes = {}
    for r in labeled:
        cls = str(r.get("class") or "unknown")
        st = classes.setdefault(cls, [])
        st.append(r)
    per_class = {k: {"n": len(v), **_paired_delta_ci(v)} for k, v in classes.items()}
    action, reason, enabled_after = "hold", "", ctl["stored_enabled"]
    if ctl["mode"] != "auto":
        action, reason = "manual_mode", "空间为 manual 模式：只记录评估，不自动切换"
    elif stat["n"] < min_n:
        action, reason = "insufficient_sample", (
            f"带标签样本 {stat['n']} < 设计分辨率下限 {min_n}，不切换")
    elif not ctl["stored_enabled"] and stat["ci_lo"] >= AUTO_ON_MIN_CI_LO:
        action, reason = "auto_on", (
            f"ΔF1={stat['delta'] * 100:+.2f}pp，95%CI [{stat['ci_lo'] * 100:+.2f},"
            f" {stat['ci_hi'] * 100:+.2f}]pp，下界 ≥ +0.5pp → 自动开启")
        enabled_after = True
    elif ctl["stored_enabled"] and stat["ci_hi"] < AUTO_OFF_CI_HI:
        streak = _negative_streak(ws_id) + 1
        if streak >= AUTO_OFF_CONSECUTIVE:
            action, reason = "auto_off", (
                f"连续 {streak} 轮 ΔF1 95%CI 上界 < 0（本轮 [{stat['ci_lo'] * 100:+.2f},"
                f" {stat['ci_hi'] * 100:+.2f}]pp）→ 自动关闭")
            enabled_after = False
        else:
            action, reason = "observe_negative", (
                f"负向第 {streak}/{AUTO_OFF_CONSECUTIVE} 轮（CI 上界 < 0），继续观察")
    else:
        reason = (f"ΔF1={stat['delta'] * 100:+.2f}pp，95%CI "
                  f"[{stat['ci_lo'] * 100:+.2f}, {stat['ci_hi'] * 100:+.2f}]pp，未达开关门槛")
    # 自动动作先落库开关（含 ontology.switch_changed 审计），再写评估审计
    switch_out = None
    if action in ("auto_on", "auto_off"):
        switch_out = set_control(ws_id, enabled=enabled_after, actor=actor or "system",
                                 reason=reason, source="auto_eval")
    round_no = 0
    try:
        with db.session() as c:
            row = c.execute("SELECT COUNT(*) FROM ontology_switch_eval WHERE workspace_id=?",
                            (ws_id,)).fetchone()
            round_no = int(row[0] or 0) + 1
            c.execute(
                "INSERT INTO ontology_switch_eval(id,round_no,tenant_id,workspace_id,"
                "enabled_before,enabled_after,action,n,delta_f1,ci_lo,ci_hi,f1_on,f1_off,"
                "min_n,classes_json,detail_json,actor,created_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (db.new_id("oev"), round_no, _tenant(), ws_id,
                 1 if ctl["stored_enabled"] else 0, 1 if enabled_after else 0, action,
                 stat["n"], stat["delta"], stat["ci_lo"], stat["ci_hi"],
                 stat["f1_on"], stat["f1_off"], min_n,
                 json.dumps(per_class, ensure_ascii=False),
                 json.dumps({"coverage": coverage, "trigger": trigger,
                             "reason": reason,
                             "confusion": stat.get("confusion")}, ensure_ascii=False)[:4000],
                 str(actor or "system"), _now()))
            _audit.log_in_tx(
                c, actor=str(actor or "system"), action="ontology.auto_eval", object_=ws_id,
                after=json.dumps({"action": action, "n": stat["n"],
                                  "delta_pp": round(stat["delta"] * 100, 3),
                                  "ci_lo_pp": round(stat["ci_lo"] * 100, 3),
                                  "ci_hi_pp": round(stat["ci_hi"] * 100, 3),
                                  "min_n": min_n, "mode": ctl["mode"],
                                  "enabled_before": ctl["stored_enabled"],
                                  "enabled_after": enabled_after,
                                  "trigger": trigger}, ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        LOG.warning("ontology eval persist failed: %s", exc)
    out = {"ok": True, "workspace_id": ws_id, "round": round_no,
           "action": action, "reason": reason, "mode": ctl["mode"],
           "enabled_before": ctl["stored_enabled"], "enabled_after": enabled_after,
           "min_n": min_n, "n_labeled": stat["n"],
           "delta_f1": stat["delta"], "delta_pp": round(stat["delta"] * 100, 3),
           "ci_lo": stat["ci_lo"], "ci_hi": stat["ci_hi"],
           "ci_lo_pp": round(stat["ci_lo"] * 100, 3),
           "ci_hi_pp": round(stat["ci_hi"] * 100, 3),
           "f1_on": stat["f1_on"], "f1_off": stat["f1_off"],
           "bootstrap_n": BOOTSTRAP_N, "seed": BOOTSTRAP_SEED,
           "per_class": per_class, "coverage": coverage,
           "switch": switch_out,
           "decision_rule": {
               "auto_on": "enabled=false 且 ΔF1 95%CI 下界 ≥ +0.5pp",
               "auto_off": f"enabled=true 且连续 {AUTO_OFF_CONSECUTIVE} 轮 ΔF1 95%CI 上界 < 0",
               "min_points": min_n}}
    return out


def evaluate_from_shadow(workspace_id: str, *, actor: str = "", trigger: str = "shadow",
                         min_points: int = None) -> dict:
    """从已落库的影子轮次 + 标签生成评估（无标签 → 只给覆盖率，不自动切换）。"""
    ws_id = str(workspace_id or "").strip() or _ws_from_ctx()
    if not ws_id:
        return {"ok": False, "reason": "workspace_required"}
    records = []
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT records_json,labels_json FROM ontology_shadow_round "
                "WHERE workspace_id=? ORDER BY created_at DESC LIMIT 20", (ws_id,)).fetchall()
    except Exception:
        rows = []
    for row in rows:
        try:
            recs = json.loads(row["records_json"] or "[]")
            labels = json.loads(row["labels_json"] or "[]")
        except Exception:
            continue
        lab_map = {(str(x.get("class") or ""), str(x.get("rule") or ""),
                    str(x.get("object_id") or "")): str(x.get("gold") or "") for x in labels
                   if isinstance(x, dict)}
        for r in recs:
            if not isinstance(r, dict):
                continue
            key = (str(r.get("class") or ""), str(r.get("rule") or ""),
                   str(r.get("object_id") or ""))
            records.append({**r, "gold": lab_map.get(key, "")})
    if not records:
        return {"ok": False, "reason": "no_shadow_records", "workspace_id": ws_id}
    has_gold = any(str(r.get("gold") or "") for r in records)
    if not has_gold:
        return {"ok": True, "workspace_id": ws_id, "action": "insufficient_gold",
                "reason": "影子轮次还没有人工复核标签：只记录开/关差异，不自动切换",
                "n": len(records),
                "coverage": {"on_decidable": sum(1 for r in records
                                                 if r.get("on_state") in ("pass", "fail")),
                             "off_decidable": sum(1 for r in records
                                                  if r.get("off_state") in ("pass", "fail"))},
                "auto_toggle": False}
    return evaluate_round(ws_id, records, actor=actor, min_points=min_points, trigger=trigger)


def maybe_auto_evaluate(workspace_id: str, *, actor: str = "system",
                       trigger: str = "audit") -> dict:
    """审核完成后的自动评估入口（mode=auto 且已有带标签影子样本才真正评估）。

    无标签时**不做任何自动切换**（fail-safe），只返回 skipped 原因，避免"没证据就开"。
    """
    ws_id = str(workspace_id or "").strip() or _ws_from_ctx()
    if not ws_id:
        return {"ok": False, "reason": "workspace_required"}
    ctl = effective(ws_id)
    if ctl["mode"] != "auto":
        return {"ok": True, "auto_toggle": False, "skipped": "manual_mode",
                "reason": "空间 mode=manual：只记录影子差异，不自动切换"}
    summary = _shadow_summary(ws_id)
    if not summary.get("labeled_rounds"):
        return {"ok": True, "auto_toggle": False, "skipped": "no_labels",
                "reason": "影子样本还没有人工复核标签：不自动切换（先补录影子标签数据后再评估）",
                "shadow": summary}
    return evaluate_from_shadow(ws_id, actor=actor, trigger=trigger)


# ---------------------------------------------------------------------------
# 空间开关在审核链上的统一入口
# ---------------------------------------------------------------------------
def cross_doc_allowed(workspace_id: str) -> dict:
    ctl = effective(str(workspace_id or "").strip())
    return {"allowed": bool(ctl["enabled"]), "switch": ctl}


def d4_aliases_allowed(workspace_id: str) -> dict:
    return cross_doc_allowed(workspace_id)
