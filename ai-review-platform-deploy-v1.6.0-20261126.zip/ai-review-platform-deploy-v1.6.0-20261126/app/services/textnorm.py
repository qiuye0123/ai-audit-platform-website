# -*- coding: utf-8 -*-
"""引文文本归一化与定位（修 A：引文门禁归一化，2026-11-21）。

背景：``auditpoints._judge_points`` 的 fail 引文核验原先只用
``str(quote) not in text`` 做逐字判定；模型抄 quote 时经常把原文空白改写
（多空格 / NBSP / 换行 / 全角空格），导致**真引文**被判「引文不可核验」而
降级 insufficient。P01 30 份证据：8 条 FN 全部卡在这里，8/8 归一化后可救
（docs/qa/L1主机制_无finding根因_20261121.md §3.3）。

本模块只做「定位 + 回填原文切片」，**不放松**「fail 引文必须是原文连续切片」
这条铁律：任何被判为可核验的引文，最终都会回填为 ``text`` 的逐字切片。

口径（唯一实现来源）：``manifest_exec._collapse_quote_ws`` ——
CJK 字符之间的空白删除，其余连续空白折叠为**单空格**。该口径保证
``"1 2" != "12"``、``"25 CFU/g" != "25CFU/g"``（数值/单位不会因为吞空白而被拼合）。

manifest_exec 在本轮修复中是冻结文件（AGENTS 约束：不许改），因此这里不复制
实现，而是惰性委托它 —— 全平台仍只有一份空白口径实现。冻结解除后应把实现
搬进本模块，由 manifest_exec 反向引用。

新增的第二层「受限重锚」只用于严格口径仍不命中时，且规则比空白口径更保守：
- 仅当空白至少一侧是 CJK 字符时才允许删除（覆盖「。\\n5.2」「1 投标」这类
  中文标点/汉字与数字/字母之间的换行或空格差异）；
- 两个非 CJK 字符之间的空白**一律保留** → ``"1 2"`` 永远不会匹配 ``"12"``，
  ``"25 CFU/g"`` 永远不会匹配 ``"25CFU/g"``（A4 口径的安全边界）。
"""
from __future__ import annotations

import logging
import re

_LOG = logging.getLogger(__name__)

# 惰性缓存：空白口径实现（来自冻结的 manifest_exec）与 CJK 字符类
_COLLAPSE_IMPL = None
_CJK_ONE = None


def _collapse_impl():
    """取 ``manifest_exec._collapse_quote_ws`` 作为空白口径的唯一实现。"""
    global _COLLAPSE_IMPL
    if _COLLAPSE_IMPL is None:
        from .manifest_exec import _collapse_quote_ws as _impl
        _COLLAPSE_IMPL = _impl
    return _COLLAPSE_IMPL


def _cjk_one():
    """逐字符 CJK 判定（字符范围同样取自 manifest_exec，避免两份口径）。"""
    global _CJK_ONE
    if _CJK_ONE is None:
        from .manifest_exec import _CJK_RANGE
        _CJK_ONE = re.compile(rf"[{_CJK_RANGE}]")
    return _CJK_ONE


def collapse_quote_ws(text):
    """引文/原文统一空白口径：CJK 之间空白删除，其余连续空白折叠为单空格。"""
    return _collapse_impl()(text)


def _is_cjk(ch: str) -> bool:
    return bool(ch) and bool(_cjk_one().match(ch))


def canonical_with_map(text, relaxed: bool = False):
    """按空白口径归一 ``text``，返回 ``(归一化文本, 归一化下标 -> 原文下标)``。

    relaxed=False 与 ``_collapse_quote_ws`` 完全同口径（CJK 之间的空白删除，
    其余折叠为单空格）；relaxed=True 时「至少一侧是 CJK」的空白也删除，
    但两个非 CJK 字符之间的空白恒定保留（数值/单位不算被拼合）。
    """
    s = str(text or "")
    out, idx = [], []
    n = len(s)

    def _prev_nonws(j: int) -> int:
        while j >= 0 and s[j].isspace():
            j -= 1
        return j

    def _next_nonws(j: int) -> int:
        while j < n and s[j].isspace():
            j += 1
        return j

    i = 0
    while i < n:
        ch = s[i]
        if not ch.isspace():
            out.append(ch)
            idx.append(i)
            i += 1
            continue
        j = i
        while j < n and s[j].isspace():
            j += 1
        p, q = _prev_nonws(i - 1), _next_nonws(j)
        # 首尾空白：直接丢弃（与 strip 同义）
        if p < 0 or q >= n:
            i = j
            continue
        p_cjk, q_cjk = _is_cjk(s[p]), _is_cjk(s[q])
        drop = (p_cjk or q_cjk) if relaxed else (p_cjk and q_cjk)
        if not drop:
            out.append(" ")
            idx.append(i)
        i = j
    return "".join(out), idx


def _canon(text, relaxed: bool = False) -> str:
    return canonical_with_map(text, relaxed=relaxed)[0]


def _slice_from_canon(text: str, cq: str, ct: str, idx: list, relaxed: bool):
    """在归一化文本里找引文，映射回原文下标并返回逐字切片。"""
    pos = ct.find(cq) if cq else -1
    if pos < 0:
        return None
    start = idx[pos]
    end = idx[pos + len(cq) - 1] + 1
    piece = text[start:end]
    if not piece:
        return None
    # 双保险：回填的切片必须与引文同口径归一后一致（防止映射错位）
    if _canon(piece, relaxed=relaxed) != cq:
        return None
    return {"quote": piece, "start": start, "end": end}


def locate_quote(text, quote, anchor: str = ""):
    """定位引文并返回**原文逐字切片**；找不到返回 None。

    顺序：逐字命中 → 空白归一（严格口径）→ 模型 anchor（现网既有能力）→ 受限重锚。
    """
    text = str(text or "")
    q = str(quote or "").strip()
    if not q or not text:
        return None
    pos = text.find(q)
    if pos >= 0:
        return {"quote": q, "start": pos, "end": pos + len(q),
                "kind": "exact", "repaired": False}

    # 1) 空白归一（严格口径 = manifest_exec._collapse_quote_ws）
    cq = collapse_quote_ws(q)
    ct, idx = canonical_with_map(text, relaxed=False)
    hit = _slice_from_canon(text, cq, ct, idx, relaxed=False)
    if hit:
        return dict(hit, kind="normalized_ws", repaired=True)

    # 2) 模型给出的 anchor（现网既有回填能力，保持兼容）
    a = str(anchor or "").strip()
    if a:
        try:
            from . import structure as _st
            sp = _st.find_span(text, a)
        except Exception:  # noqa: BLE001 - 定位失败不应放大成判定失败
            _LOG.debug("anchor locate failed", exc_info=True)
            sp = None
        if sp and sp.get("quote"):
            return {"quote": sp["quote"], "start": sp.get("start"), "end": sp.get("end"),
                    "kind": "anchor", "repaired": True}

    # 3) 受限重锚：只允许删「至少一侧是 CJK」的空白；数字/字母间空白保留
    cqr = _canon(q, relaxed=True)
    ctr, idxr = canonical_with_map(text, relaxed=True)
    hit = _slice_from_canon(text, cqr, ctr, idxr, relaxed=True)
    if hit:
        return dict(hit, kind="reanchor", repaired=True)
    return None


def verify_or_repair_quote(text, quote, anchor: str = "") -> dict:
    """fail 引文核验（修 A）：可核验/可回填 → ok，真找不到 → miss。

    返回：
      {"ok": True, "quote": 原文切片, "repaired": bool,
       "source": "exact|normalized_ws|anchor|reanchor", "repair": ""|"whitespace"|"anchor"|"reanchor"}
      {"ok": False, "reason": "引文未命中"}
    """
    loc = locate_quote(text, quote, anchor=anchor)
    if not loc:
        return {"ok": False, "reason": "引文未命中"}
    return {"ok": True, "quote": loc["quote"], "repaired": bool(loc["repaired"]),
            "source": loc["kind"],
            "repair": "" if not loc["repaired"] else
            ("anchor" if loc["kind"] == "anchor" else
             ("reanchor" if loc["kind"] == "reanchor" else "whitespace"))}
