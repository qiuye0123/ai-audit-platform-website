# -*- coding: utf-8 -*-
"""7 节点真实 handler 契约：每个 handler 接收 (node, ctx)，返回 dict。

只包装现有服务，不复制业务逻辑；调用方可用 agent_dag.run 调度。
输出统一带 agent / run_id / agent_mode / degraded 证据；跳过节点必须写原因。
"""
from __future__ import annotations


def build(case_id: str = "", path: str = "", text: str = "", points: list | None = None,
          policy_text: str = "", save_rule: bool = False, rule_code: str = "",
          feedback_id: str = "", finding_id: str = "", limit: int = 20,
          actor: str = "") -> dict:
    """构建 7 节点 handler。

    actor：触发者 uid（HTTP/CLI 会话身份）；所有 agent.run 审计必须带真实操作人，
    不再落成 system（L108 G5）。嵌套调用由 agents 运行期 actor 上下文兜底。
    """
    from . import agents, audit_intake, rule_mining, evolution, orchestrator, review

    def _evidence(agent_id: str, r: dict, extra: dict | None = None) -> dict:
        res = (r or {}).get("result") or {}
        out = {"agent": agent_id, "status": (r or {}).get("status"),
               "run_id": str((r or {}).get("run_id") or ""),
               "agent_mode": str(res.get("agent_mode") or ""),
               "degraded": bool(res.get("degraded")),
               "result": res}
        out.update(extra or {})
        return out

    def parse(node, ctx):
        r = orchestrator.parse_document((ctx or {}).get("path") or path, case_id=case_id,
                                        ai_assist=True)
        # L108：扫描件无 OCR 等解析降级必须随节点输出上卷（原因 + skipped_reasons），
        # 不能只留 degraded=True 而丢掉可解释信息（L106 §1.5 静默降级）。
        return {"agent": "agent-parse", "text": r.get("text", ""),
                "unstructured": r.get("unstructured", False),
                "ext": r.get("ext", ""), "ok": r.get("ok", False),
                "run_id": str(r.get("run_id") or ""),
                "agent_mode": str(r.get("agent_mode") or ""),
                "degraded": bool(r.get("degraded")),
                "degraded_reason": str(r.get("degraded_reason") or ""),
                "skipped_reasons": r.get("skipped_reasons") or [],
                "ocr_used": bool(r.get("ocr_used")),
                "skipped": bool(r.get("skipped")),
                "reason": str(r.get("reason") or "")}

    def fact(node, ctx):
        r = orchestrator.extract_facts((ctx or {}).get("path") or path,
                                       (ctx or {}).get("text") or text, case_id=case_id)
        return {"agent": "agent-fact", "status": "ok" if r.get("ok") else "failed",
                "run_id": str(r.get("run_id") or ""),
                "agent_mode": str(r.get("agent_mode") or ""),
                "degraded": bool(r.get("degraded")),
                "degraded_reason": str(((r.get("result") or {}) or {}).get("degraded_reason") or ""),
                "result": r.get("result")}

    def rulegen(node, ctx):
        src = (ctx or {}).get("policy_text") or policy_text
        if not str(src or "").strip():
            return {"agent": "agent-rulegen", "status": "skipped",
                    "run_id": "", "skipped": True,
                    "reason": "本次未提供新制度/标准文本"}
        r = agents.run_agent("agent-rulegen", {"text": src, "save": bool(save_rule),
                                               "case_id": case_id}, actor=str(actor or ""))
        return _evidence("agent-rulegen", r)

    def conflict(node, ctx):
        r = agents.run_agent("agent-conflict", {"persist": False, "include_drafts": True,
                                                "rule_code": rule_code, "case_id": case_id},
                             actor=str(actor or ""))
        return _evidence("agent-conflict", r)

    def judge(node, ctx):
        _mark = orchestrator.trace_mark()
        fs = review.judge_findings((ctx or {}).get("path") or path)
        _judge = {"run_id": "", "agent_mode": "", "degraded": False}
        for e in orchestrator.trace_since(_mark):
            if str(e.get("stage") or "") == "judge":
                _det = e.get("detail") or {}
                _judge = {"run_id": str(_det.get("run_id") or ""),
                          "agent_mode": str(_det.get("agent_mode") or ""),
                          "degraded": bool(_det.get("degraded"))}
        return {"agent": "agent-judge", "status": "ok", "run_id": _judge["run_id"],
                "agent_mode": _judge["agent_mode"], "degraded": _judge["degraded"],
                "result": {"findings": fs}}

    def fp(node, ctx):
        fid = (ctx or {}).get("feedback_id") or feedback_id or finding_id
        if not fid:
            return {"agent": "agent-fp", "status": "skipped", "run_id": "",
                    "skipped": True,
                    "reason": "没有反馈 ID；误报归因在人工复核后触发"}
        # 复核后归因走 evolution.feedback_to_rule（与 post_decision 同一业务入口），
        # 不在这里重复起一个 agent-fp 运行；真实 agent-fp 调用见 orchestrator.post_decision。
        try:
            res = evolution.feedback_to_rule(fid, "false_positive")
            return {"agent": "agent-fp", "status": "ok", "run_id": "",
                    "agent_mode": "deterministic", "degraded": False,
                    "result": res, "note": "agent-fp 真实运行由 post_decision 触发"}
        except Exception as e:
            return {"agent": "agent-fp", "status": "failed", "run_id": "",
                    "agent_mode": "", "degraded": True,
                    "reason": f"{type(e).__name__}: {str(e)[:120]}"}

    def ruleminer(node, ctx):
        # 走真实 agent，保留 run_id/节点轨迹；不再直接调用确定性 mine。
        r = agents.run_agent("agent-ruleminer", {"limit": limit, "min_count": 2,
                                                 "case_id": case_id}, actor=str(actor or ""))
        return _evidence("agent-ruleminer", r)

    return {"parse": parse, "fact": fact, "rulegen": rulegen, "conflict": conflict,
            "judge": judge, "fp": fp, "ruleminer": ruleminer}
