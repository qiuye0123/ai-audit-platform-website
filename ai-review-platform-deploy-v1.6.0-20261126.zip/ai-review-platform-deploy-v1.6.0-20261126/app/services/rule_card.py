"""规则 → 智能体可执行卡片。

目标不是把自然语言原样塞给模型，而是把审核所需的适用边界、证据口径、
单位/聚合、例外和严重度一起纳入提示词，减少“规则看懂了但执行错”。

T6（2026-11-19）：新增实验开关 ``RULEPROOF_RULE_CARD_MODE=structured|raw``。
- ``structured``（默认，现状）：``audit_point()`` 的 criterion = ``prompt_text(card)``
  结构化紧凑文本（规则/性质/要求/判据/对象/指标/条件/范围/聚合/例外/证据/严重度/
  证据范围/执行约束）。
- ``raw``（实验 B 臂）：criterion = 判据槽原文（``slots["criterion"]``，即规则包
  「通过判据」+ 导入期追加的适用范围/例外/缺证处理/证据类别），不经过结构化拼装。
两臂唯一变量是交给 ``agent-judge`` 的判据文本表示；id/name/required_evidence/level
保持不变。默认值/未知值一律按 ``structured``，失败安全回退现状。
实验报告：``docs/qa/T6规则结构化AB_20261119.md``。
"""
from __future__ import annotations
import json
import os

RULE_CARD_MODES = ("structured", "raw")


def card_mode() -> str:
    """当前规则卡模式；未知值/空值回退 structured（现状）。"""
    mode = str(os.environ.get("RULEPROOF_RULE_CARD_MODE", "") or "").strip().lower()
    return mode if mode in RULE_CARD_MODES else "structured"


def raw_criterion(rule: dict, slots: dict | None = None) -> str:
    """B 臂「人话」判据：规则包判据槽原文，不做结构化拼装。"""
    slots = dict(slots or {})
    crit = str(slots.get("criterion") or slots.get("requirement")
               or slots.get("condition") or "").strip()
    if not crit:
        crit = str((rule or {}).get("criterion") or (rule or {}).get("description")
                   or (rule or {}).get("name") or "").strip()
    return crit


def build(rule: dict, slots: dict | None = None) -> dict:
    rule = rule or {}
    slots = dict(slots or {})
    # RuleIR v2 优先：自然语言规则也有 typed fields
    ir = {}
    try:
        import json as _j
        ir = (_j.loads(rule.get("scope_json") or "{}") or {}).get("ir") or {}
    except Exception:
        ir = {}
    scope = slots.get("scope") or slots.get("applicable_when") or ir.get("scope") or ""
    evidence = (slots.get("evidence") or slots.get("required_evidence")
                or ir.get("evidence_required") or "")
    exceptions = slots.get("exceptions") or []
    if isinstance(exceptions, str):
        exceptions = [exceptions]
    criteria = slots.get("criteria") or ([slots.get("criterion")] if slots.get("criterion") else [])
    if isinstance(criteria, str):
        criteria = [criteria]
    evidence_list = slots.get("required_evidence_list") or ([evidence] if evidence else [])
    if isinstance(evidence_list, str):
        evidence_list = [evidence_list]
    source_refs = slots.get("source_refs") or ([str(slots.get("source") or rule.get("source") or "")] if (slots.get("source") or rule.get("source")) else [])
    return {
        "code": str(rule.get("code") or rule.get("rule_code") or ""),
        "name": str(rule.get("name") or rule.get("rule_code") or ""),
        "category": str(rule.get("category") or ""),
        "severity": str(rule.get("rclass") or slots.get("rclass") or "R3"),
        "requirement": str(slots.get("requirement") or slots.get("criterion") or ir.get("predicate") or ""),
        "authority": str(slots.get("source") or rule.get("source") or ""),
        "subject_type": str(slots.get("subject_type") or slots.get("subject") or ir.get("subject") or ""),
        "trigger": str(slots.get("trigger") or slots.get("applicable_when") or ir.get("scope") or ""),
        "combination": str(slots.get("combination") or slots.get("combine") or "all"),
        "evaluation_kind": str(slots.get("evaluation_kind") or ir.get("nature") or ""),
        "on_insufficient": str(slots.get("on_insufficient") or "abstain"),
        "terms": slots.get("terms") or [],
        "version": str((rule.get("version") or "")),
        "status": str(rule.get("status") or ""),
        "criterion": str(slots.get("criterion") or ir.get("predicate") or ""),
        "criteria": [str(x) for x in criteria if str(x).strip()],
        "required_evidence": [str(x) for x in evidence_list if str(x).strip()],
        "source_refs": [str(x) for x in source_refs if str(x).strip()],
        "on_insufficient_evidence": str(slots.get("on_insufficient_evidence") or slots.get("on_insufficient") or "abstain"),
        "nature": str(ir.get("nature") or ""),
        "effect": str(ir.get("effect") or ""),
        "scope": str(scope),
        "subject": str(slots.get("subject") or ir.get("subject") or ""),
        "metric": str(slots.get("metric") or slots.get("parameter") or ""),
        "operator": str(slots.get("op") or slots.get("operator") or ""),
        "threshold": slots.get("value", slots.get("threshold")),
        "unit": str(slots.get("unit") or ""),
        "aggregation": str(slots.get("aggregation") or slots.get("batch_scope") or ""),
        "exceptions": [str(x) for x in exceptions if str(x).strip()],
        "evidence": str(evidence),
        "source": str(rule.get("source") or ""),
        "decision_tables": slots.get("decision_tables") or slots.get("decision_table") or [],
        "evidence_scope": (__import__('app.services.execution_plan', fromlist=['derive']).derive(slots).get('evidence_scope') or []),
        "aggregation": __import__('app.services.execution_plan', fromlist=['derive']).derive(slots).get('aggregation'),
        "evaluation_kind": __import__('app.services.execution_plan', fromlist=['derive']).derive(slots).get('evaluation_kind'),
        "fallback": __import__('app.services.execution_plan', fromlist=['derive']).derive(slots).get('fallback'),
        "execution_plan": __import__('app.services.execution_plan', fromlist=['derive']).derive(slots),
    }


def prompt_text(card: dict) -> str:
    """给 agent-judge 的紧凑文本；只含执行所需字段，避免整段制度噪声。"""
    bits = [f"规则：{card.get('name') or card.get('code')}"]
    if card.get("nature"):
        bits.append(f"性质：{card['nature']}；要求：{card.get('effect') or ''}")
    if card.get("requirement"):
        bits.append(f"业务要求：{card['requirement']}")
    if card.get("criterion"):
        bits.append(f"判据：{card['criterion']}")
    if card.get("subject"):
        bits.append(f"对象：{card['subject']}")
    if card.get("metric"):
        bits.append(f"指标：{card['metric']}")
    if card.get("operator") or card.get("threshold") is not None:
        bits.append(f"条件：{card.get('operator') or '='} {card.get('threshold') if card.get('threshold') is not None else ''}{card.get('unit') or ''}")
    if card.get("scope"):
        bits.append(f"适用范围：{card['scope']}")
    if card.get("aggregation"):
        bits.append(f"聚合/批次：{card['aggregation']}")
    if card.get("exceptions"):
        bits.append("例外：" + "、".join(card["exceptions"]))
    if card.get("evidence"):
        bits.append(f"证据要求：{card['evidence']}")
    bits.append(f"严重度：{card.get('severity')}")
    if card.get("evidence_scope"):
        bits.append("证据范围：" + "/".join(card.get("evidence_scope") or []))
    if card.get("aggregation"):
        bits.append("汇总方式：" + str(card.get("aggregation")))
    if card.get("fallback"):
        bits.append("证据不足：" + str(card.get("fallback")))
    bits.append("执行约束：只依据本规则已确认判据评价证据，不得增加新的强制要求；"
                "每个判断必须引用对应原文证据；证据不足或存在无法消解矛盾时明确列出缺口；"
                "不得用模型自评分代替业务判据")
    return "；".join(bits)


def audit_point(rule: dict, slots: dict | None = None) -> dict:
    """审核点（供 agent-judge）。

    T6 A/B：``RULEPROOF_RULE_CARD_MODE=raw`` 时 criterion 用判据槽原文（人话臂），
    其余情况保持结构化 ``prompt_text``（现状，默认）。required_evidence/level 两臂一致。
    """
    card = build(rule, slots)
    mode = card_mode()
    if mode == "raw":
        criterion = raw_criterion(rule, slots)[:1200]
    else:
        criterion = prompt_text(card)[:1200]
    return {"id": card["code"] or "SEMANTIC", "name": card["name"][:80],
            "criterion": criterion, "required_evidence": card["evidence"] or "原文逐字证据",
            "level": card["severity"], "rule_card_mode": mode}
