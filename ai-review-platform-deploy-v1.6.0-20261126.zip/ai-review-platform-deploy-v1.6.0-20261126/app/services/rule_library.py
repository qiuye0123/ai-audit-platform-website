"""统一规则库视图：DB 规则 + 只读审核库点位 + 决策表。

T-107（2026-11-18）口径修复：
- 单一计数入口 ``rule_counts(scope)``：客户规则 / 内置规则 / 审核库点位 /
  可执行版本 / 决策表分开计数，stats.dashboard、首页、规则库列表全部消费
  同一个函数，不再出现 32/335/16/16 四口径。
- 命中归因（P0-02）：finding 先按 ``manifest_result.rule_code``（manifest_result_id
  关联）归因，再按事实码（finding.rule_id / point_id / source_code）映射到规则或
  审核库点位；无法映射的计入 ``unattributed``，**不静默显示 0**；规则行
  ``health`` 只在有归因命中时计算，否则 ``health_state=unattributed/no_hit``，
  不伪造健康度。
- 生效版本（P0-01）：规则行返回 ``effective_version/effective_status``（取
  current_version_id 且版本 published，与 manifest/执行同口径）与
  ``latest_version/latest_status``（最新版本，可能是草稿），两者分开。
- 决策表包装规则（P1-09）：``source=decision_table_autobind`` 的内部包装规则
  不在规则库视图重复计数，命中归并到决策表行，``internal_rules`` 单独统计。
- 审核库点位（P1-08）：返回 base（302）/supplement（17）/merged（319）三口径。
"""
import json
import logging
import os

from .. import config
from .. import db
from .. import repositories as R

CAT_MAP = {"A": "completeness", "B": "completeness", "C": "consistency",
           "D": "consistency", "E": "completeness", "F": "limit", "G": "format"}
# 决策表发布时自动创建的内部包装规则（不进入规则库视图重复计数）
INTERNAL_SOURCE = "decision_table_autobind"
# 审核库点位来源的版本口径：点位库本身没有草稿/发布流转
LIBRARY_VERSION = "库"
LIBRARY_VERSION_STATUS = "published"
LIBRARY_STATUS = "published"

_SCOPES = ("tenant", "space", "global")

_TABLE_COLS = {}


def _table_cols(table: str) -> set:
    if table not in _TABLE_COLS:
        try:
            with db.session() as c:
                _TABLE_COLS[table] = {r[1] for r in c.execute(
                    "PRAGMA table_info(%s)" % table).fetchall()}
        except Exception:
            _TABLE_COLS[table] = set()
    return _TABLE_COLS[table]


# ---------------------------------------------------------------------------
# 作用域：tenant（本租户跨空间，默认）/ space（本租户本空间）/ global
# ---------------------------------------------------------------------------

def _ctx_ids() -> tuple:
    try:
        from . import ctx as _ctx
        cur = _ctx.get_context() or {}
    except Exception:
        cur = {}
    return str(cur.get("tenant_id") or ""), str(cur.get("workspace_id") or "")


def _scope_meta(scope: str = "tenant") -> dict:
    """归一化 scope 并返回 ({tenant, workspace}, scope, degraded 说明)。"""
    value = str(scope or "tenant").strip().lower()
    if value not in _SCOPES:
        raise ValueError("未知计数口径：%r（可选：%s）" % (scope, ", ".join(_SCOPES)))
    tenant, workspace = _ctx_ids()
    degraded = ""
    if value == "global":
        return {"scope": "global", "tenant": "", "workspace": "", "degraded": ""}
    if not tenant:
        # 上下文缺失：不做租户过滤（只在测试/系统任务里出现），但显式标注降级
        degraded = "上下文无租户，按全库统计（degraded）"
        return {"scope": value, "tenant": "", "workspace": workspace, "degraded": degraded}
    if value == "space" and not workspace:
        value = "tenant"
        degraded = "上下文无空间，按本租户全部空间统计"
    return {"scope": value, "tenant": tenant, "workspace": workspace, "degraded": degraded}


def _scoped_rows(table: str, scope_meta: dict, columns: str = "*",
                 extra: str = "", params: tuple = (), order: str = "") -> list:
    """按口径读取表行（只读）：租户/空间列存在时才过滤，NULL/空视为全局资产。"""
    cols = _table_cols(table)
    where, p = [], list(params or ())
    if extra:
        where.append(extra)
    if scope_meta["scope"] != "global" and scope_meta.get("tenant"):
        if "tenant_id" in cols:
            where.append("(COALESCE(tenant_id,'')=? OR COALESCE(tenant_id,'')='')")
            p.append(scope_meta["tenant"])
        if scope_meta["scope"] == "space" and scope_meta.get("workspace") \
                and "workspace_id" in cols:
            where.append("(COALESCE(workspace_id,'')=? OR COALESCE(workspace_id,'')='')")
            p.append(scope_meta["workspace"])
    sql = "SELECT %s FROM %s" % (columns, table)
    if where:
        sql += " WHERE " + " AND ".join(where)
    if order:
        sql += " ORDER BY " + order
    with db.session() as c:
        return [dict(r) for r in c.execute(sql, tuple(p)).fetchall()]


# ---------------------------------------------------------------------------
# 规则/版本/点位/决策表：基础读取
# ---------------------------------------------------------------------------

def _rule_rows(scope_meta: dict) -> list:
    return _scoped_rows("rule", scope_meta, order="created_at DESC")


def _versions_map(rule_ids: list) -> dict:
    """rule_id → {'latest': 最新版本行, 'published': 生效 published 版本行}（单次查询）。"""
    out = {rid: {"latest": {}, "published": []} for rid in rule_ids}
    if not rule_ids:
        return out
    ids = [str(x) for x in rule_ids if x]
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        ph = ",".join("?" * len(chunk))
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM rule_version WHERE rule_id IN (%s) ORDER BY rowid ASC" % ph,
                tuple(chunk)).fetchall()]
        for row in rows:
            rid = str(row.get("rule_id") or "")
            slot = out.setdefault(rid, {"latest": {}, "published": []})
            slot["latest"] = row
            if str(row.get("status") or "") == "published":
                slot["published"].append(row)
    return out


def _effective_of(rule: dict, versions: dict, rule_svc) -> dict:
    """与 ``rule.effective_snapshot`` 同口径的内存版本（避免逐规则 N+1 查询）。"""
    rid = str((rule or {}).get("id") or "")
    slot = versions.get(rid) or {}
    latest = slot.get("latest") or {}
    published = slot.get("published") or []
    chosen = {}
    if str(rule.get("status") or "") != "archived":
        cid = str(rule.get("current_version_id") or "")
        if cid:
            chosen = next((v for v in published if str(v.get("id") or "") == cid), None) or {}
        if not chosen and published:
            chosen = published[-1]  # 最新 published（rowid 升序取最后）
    return {
        "effective_version": (chosen or {}).get("version") or "",
        "effective_version_id": (chosen or {}).get("id") or "",
        "effective_status": ("published" if chosen else
                             "archived" if str(rule.get("status") or "") == "archived"
                             else "none"),
        "effective": bool(chosen),
        "latest_version": (latest or {}).get("version") or "",
        "latest_status": (latest or {}).get("status") or "",
    }


def _is_internal_rule(rule: dict, table_codes=None) -> bool:
    """决策表包装规则（系统自动创建/发布），规则库视图不重复计数。

    ``table_codes``：调用方已取好的决策表 code 集合（批量预计算用）。旧实现对
    每条规则各调一次 ``decision_table.list_tables()``（852 规则 ≈852 次 SQL，首页
    rule_counts 0.8s 的主因）；批量遍历时传一次快照，判定口径不变。
    """
    if str((rule or {}).get("source") or "") == INTERNAL_SOURCE:
        return True
    if table_codes is None:
        try:
            from . import decision_table as _dt
            table_codes = {str(t.get("code") or "") for t in _dt.list_tables()}
        except Exception:
            return False
    code = str((rule or {}).get("code") or "")
    return bool(code.startswith("DT-") and code[3:] in table_codes)


def _internal_target(rule: dict) -> str:
    """包装规则 → 决策表 code（命中归并到决策表行）。"""
    code = str((rule or {}).get("code") or "")
    if code.startswith("DT-"):
        return code[3:]
    try:
        scope = json.loads((rule or {}).get("scope_json") or "{}")
    except Exception:
        scope = {}
    for key in ("decision_tables", "decision_table"):
        value = scope.get(key)
        if isinstance(value, str) and value:
            return value.split(",")[0].strip()
        if isinstance(value, (list, tuple)) and value:
            return str(value[0]).strip()
    latest = {}
    return str(latest.get("code") or "") or ""


def _library_points() -> list:
    try:
        from . import auditpoints as _ap
        return list((_ap.load().points or []))
    except Exception:
        logging.getLogger(__name__).debug("audit point library unavailable", exc_info=True)
        return []


def _decision_tables() -> list:
    try:
        from . import decision_table as _dt
        return list(_dt.list_tables() or [])
    except Exception:
        logging.getLogger(__name__).debug("decision table list unavailable", exc_info=True)
        return []


def library_counts() -> dict:
    """审核库点位三口径：基础库 302 + 补充层 17 = 合并 319（P1-08）。

    以库文件为准读取，不把 302/319 任意一个写死成唯一口径；读取失败时退回
    已加载库对象的合并总数并显式 degraded。
    """
    out = {"base_points": 0, "base_audit_types": 0, "base_document_types": 0,
           "supplement_points": 0, "supplement_audit_types": 0,
           "supplement_document_types": 0, "merged_points": 0,
           "merged_audit_types": 0, "merged_document_types": 0,
           "source": "", "degraded": ""}
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    lib_dir = config.AUDIT_LIBRARY or os.environ.get("RULEPROOF_AUDIT_LIBRARY", "")
    if not (lib_dir and os.path.isdir(lib_dir)):
        bundled = os.path.join(root, "文件审核库")
        if os.path.isdir(bundled):
            lib_dir = bundled
    try:
        if lib_dir:
            data = json.load(open(os.path.join(lib_dir, "审核点库.json"), encoding="utf-8"))
            out["base_points"] = len(data.get("points") or [])
            out["base_audit_types"] = len(data.get("audit_types") or [])
            route = os.path.join(lib_dir, "文件类型与路由.json")
            if os.path.exists(route):
                rdata = json.load(open(route, encoding="utf-8"))
                out["base_document_types"] = len(rdata.get("document_types") or [])
            out["source"] = lib_dir
    except Exception:
        out["degraded"] = "基础库文件读取失败"
    try:
        sup_path = os.path.join(root, "seed", "library_supplement.json")
        if os.path.exists(sup_path):
            sup = json.load(open(sup_path, encoding="utf-8"))
            out["supplement_points"] = len(sup.get("points") or [])
            out["supplement_audit_types"] = len(sup.get("audit_types") or [])
            out["supplement_document_types"] = len(sup.get("document_types") or [])
    except Exception:
        out["degraded"] = (out["degraded"] + "；补充层读取失败").strip("；")
    try:
        lib = None
        from . import auditpoints as _ap
        lib = _ap.load()
        stats = lib.stats() if hasattr(lib, "stats") else {}
        out["merged_points"] = int(stats.get("total") or len(getattr(lib, "points", []) or []))
        out["merged_audit_types"] = int(stats.get("audit_types")
                                        or len(getattr(lib, "audit_types", {}) or {}))
        out["merged_document_types"] = int(stats.get("document_types")
                                           or len(getattr(lib, "document_types", []) or []))
    except Exception:
        out["degraded"] = (out["degraded"] + "；合并库读取失败").strip("；")
    if not out["merged_points"]:
        out["merged_points"] = out["base_points"] + out["supplement_points"]
    return out


# ---------------------------------------------------------------------------
# 命中归因（P0-02）：manifest_result.rule_code → 事实码 → unattributed
# ---------------------------------------------------------------------------

def _manifest_rule_codes(scope_meta: dict) -> dict:
    """manifest_result_id → rule_code；按口径经 audit_manifest 过滤租户/空间。"""
    rows = _scoped_rows("manifest_result", scope_meta, columns="id,manifest_id,rule_code,rule_id")
    if not rows:
        return {}, {}
    mids = sorted({str(r.get("manifest_id") or "") for r in rows if r.get("manifest_id")})
    manifest_scope = {}
    if scope_meta["scope"] != "global" and scope_meta.get("tenant") and mids:
        for i in range(0, len(mids), 400):
            chunk = mids[i:i + 400]
            ph = ",".join("?" * len(chunk))
            with db.session() as c:
                for m in c.execute("SELECT id,tenant_id,workspace_id FROM audit_manifest "
                                   "WHERE id IN (%s)" % ph, tuple(chunk)).fetchall():
                    manifest_scope[str(m["id"])] = (str(m["tenant_id"] or ""),
                                                    str(m["workspace_id"] or ""))
    by_id, by_code = {}, {}
    for r in rows:
        mid = str(r.get("manifest_id") or "")
        if manifest_scope:
            mt, mw = manifest_scope.get(mid, ("", ""))
            if mt and mt != scope_meta.get("tenant"):
                continue
            if scope_meta["scope"] == "space" and scope_meta.get("workspace") \
                    and mw and mw != scope_meta["workspace"]:
                continue
        code = str(r.get("rule_code") or "")
        if code:
            by_id[str(r.get("id") or "")] = code
            by_code[code] = by_code.get(code, 0) + 1
    return by_id, by_code


def _finding_rows(scope_meta: dict) -> list:
    return _scoped_rows(
        "finding", scope_meta,
        columns=("id,case_id,rule_id,status,tenant_id,workspace_id,"
                 "manifest_result_id,point_id,source_code"),
        extra="COALESCE(status,'')<>'superseded'")


def _point_hit_code(point) -> str:
    return str(getattr(point, "id", "") or (point.get("id") if isinstance(point, dict) else "") or "")


def attribute_hits(scope_meta: dict, points: list = None) -> dict:
    """把口径内 finding 归因到规则/审核库点位/决策表；无法归因 → unattributed。

    归因顺序（与 manifest 执行落库口径一致）：
    1. ``manifest_result_id`` → ``manifest_result.rule_code``（最权威，执行清单绑定）；
    2. 事实码：finding.rule_id / point_id / source_code 命中规则 code 或审核库点位 id；
    3. 都不命中 → unattributed（按事实码聚合，用于页面显示“未归因”而不是 0）。
    """
    points = _library_points() if points is None else points
    rules = _rule_rows(scope_meta)
    rule_by_code = {str(r.get("code") or ""): r for r in rules if r.get("code")}
    point_ids = {_point_hit_code(p) for p in points if _point_hit_code(p)}
    table_codes = {str(t.get("code") or "") for t in _decision_tables() if t.get("code")}
    internal = {code: _internal_target(r) for code, r in rule_by_code.items()
                if _is_internal_rule(r, table_codes)}
    mr_by_id, mr_by_code = _manifest_rule_codes(scope_meta)
    findings = _finding_rows(scope_meta)
    hits = {"total": len(findings), "attributed": 0, "unattributed": 0,
            "by_rule": {}, "by_point": {}, "by_decision_table": {},
            "override_by_rule": {}, "override_by_point": {},
            "override_by_decision_table": {},
            "unattributed_by_code": {}, "manifest_attributed": 0,
            "unattributed_override": 0}
    unattributed_codes = {}
    for f in findings:
        override = str(f.get("status") or "") == "false_positive"
        code = ""
        source = ""
        mr_code = mr_by_id.get(str(f.get("manifest_result_id") or ""))
        if mr_code:
            source = "manifest"
        else:
            candidates = [str(f.get(k) or "").strip()
                          for k in ("rule_id", "point_id", "source_code")]
            for cand in candidates:
                if cand and (cand in rule_by_code or cand in point_ids or cand in table_codes):
                    code = cand
                    break
        if source == "manifest":
            code = str(mr_code or "")
            hits["manifest_attributed"] += 1
        if code in rule_by_code:
            target = internal.get(code)
            if target:  # 决策表包装规则：命中归并到决策表行，不重复计规则
                hits["by_decision_table"][target] = hits["by_decision_table"].get(target, 0) + 1
                if override:
                    hits["override_by_decision_table"][target] = \
                        hits["override_by_decision_table"].get(target, 0) + 1
            else:
                hits["by_rule"][code] = hits["by_rule"].get(code, 0) + 1
                if override:
                    hits["override_by_rule"][code] = hits["override_by_rule"].get(code, 0) + 1
            hits["attributed"] += 1
        elif code in point_ids:
            hits["by_point"][code] = hits["by_point"].get(code, 0) + 1
            if override:
                hits["override_by_point"][code] = hits["override_by_point"].get(code, 0) + 1
            hits["attributed"] += 1
        elif code in table_codes:
            hits["by_decision_table"][code] = hits["by_decision_table"].get(code, 0) + 1
            if override:
                hits["override_by_decision_table"][code] = \
                    hits["override_by_decision_table"].get(code, 0) + 1
            hits["attributed"] += 1
        else:
            fact = str(f.get("rule_id") or f.get("point_id") or
                       f.get("source_code") or "UNKNOWN")
            unattributed_codes[fact] = unattributed_codes.get(fact, 0) + 1
            hits["unattributed"] += 1
            if override:
                hits["unattributed_override"] += 1
    hits["unattributed_by_code"] = dict(
        sorted(unattributed_codes.items(), key=lambda kv: (-kv[1], kv[0]))[:30])
    hits["unattributed_override_rate"] = (round(hits["unattributed_override"]
                                                / hits["unattributed"], 3)
                                          if hits["unattributed"] else 0.0)
    return {"hits": hits, "internal": internal,
            "mr_by_code": mr_by_code, "points": points}


# ---------------------------------------------------------------------------
# 统一计数 rule_counts(scope)
# ---------------------------------------------------------------------------

def _counts_conflicts(scope_meta: dict) -> dict:
    rows = _scoped_rows("conflict", scope_meta, columns="id,status,resolution,created_at")
    out = {"total": len(rows), "open": 0, "resolved": 0, "ignored": 0,
           "need_more": 0, "open_awaiting": 0}
    for r in rows:
        st = str(r.get("status") or "open")
        if st in out:
            out[st] += 1
        if st == "open":
            if str(r.get("resolution") or "") == "need_more":
                out["need_more"] += 1
            else:
                out["open_awaiting"] += 1
    return out


def rule_counts(scope: str = "tenant") -> dict:
    """规则域唯一计数口径（P0-03）：stats.dashboard / 首页 / 规则库页同源消费。

    scope=tenant（默认）：本租户跨空间；space：本租户当前空间；global：全库。
    计数分层（禁止相加混用）：
      - customer_rules / builtin_rules / rule_rows：DB 规则行（客户 vs 内置）；
      - executable_versions：current_version_id 且 published 的可执行版本数；
      - library_points：审核库点位（base 302 + supplement 17 = merged 319）；
      - decision_tables / internal_rules：决策表与系统包装规则（不双计）；
      - view_total = rule_rows + merged_points + decision_tables（规则库视图条目）；
      - hits：total / attributed / unattributed（manifest_result 或事实码归因）。
    """
    meta = _scope_meta(scope)
    rules = _rule_rows(meta)
    versions = _versions_map([r.get("id") for r in rules])
    try:
        from . import rule as _rule_svc
        labels = _rule_svc.status_labels()
        rule_svc = _rule_svc
    except Exception:
        labels = {"rule": {}}
        rule_svc = None
    try:
        from . import decision_table as _dt_rc
        _internal_table_codes = {str(t.get("code") or "") for t in _dt_rc.list_tables()}
    except Exception:
        _internal_table_codes = None   # 取不到时退回旧逐条查询口径（fail-soft 不变）
    by_status = {}
    builtin = customer = executable = editable = pending = internal_rules = 0
    for r in rules:
        status = str(r.get("status") or "")
        by_status[status] = by_status.get(status, 0) + 1
        if str(r.get("source") or "") in ("内置规则",) or \
                str(r.get("code") or "") in _builtin_codes():
            builtin += 1
        else:
            customer += 1
        if _is_internal_rule(r, _internal_table_codes):
            internal_rules += 1
        eff = _effective_of(r, versions, rule_svc)
        if eff["effective"]:
            executable += 1
        if status in ("draft", "approved", "published"):
            editable += 1
        if status == "pending":
            pending += 1
    lc = library_counts()
    tables = _decision_tables()
    attributed = attribute_hits(meta)
    hits = attributed["hits"]
    view_total = len(rules) + lc["merged_points"] + len(tables)
    return {
        "scope": meta["scope"],
        "scope_note": meta.get("degraded") or (
            "本租户全部空间" if meta["scope"] == "tenant"
            else "本租户当前空间" if meta["scope"] == "space" else "全库"),
        "customer_rules": customer,
        "builtin_rules": builtin,
        "rule_rows": len(rules),
        "editable_rules": editable,
        "pending_approval_rules": pending,
        "executable_versions": executable,
        "internal_rules": internal_rules,
        "library_points": lc,
        "decision_tables": len(tables),
        "view_total": view_total,
        "rules_by_status": by_status,
        "rules_by_status_label": {k: labels.get("rule", {}).get(k, k)
                                  for k in by_status},
        "hits": hits,
        "conflicts": _counts_conflicts(meta),
        "as_of": db.now(),
    }


_BUILTIN_CACHE = {}


def _builtin_codes() -> set:
    if "codes" not in _BUILTIN_CACHE:
        try:
            from ..engine.rules_meta import BUILTIN_RULES
            _BUILTIN_CACHE["codes"] = {str(r.get("code") or "") for r in BUILTIN_RULES}
        except Exception:
            _BUILTIN_CACHE["codes"] = set()
    return _BUILTIN_CACHE["codes"]


# ---------------------------------------------------------------------------
# 规则库列表视图（保持既有数组契约；新增有效版本/归因字段）
# ---------------------------------------------------------------------------

def stats(scope: str = "tenant", include_internal: bool = False) -> list:
    """规则库列表：DB 规则 + 审核库点位 + 决策表（默认隐藏决策表包装规则）。"""
    meta = _scope_meta(scope)
    out, seen_codes = [], set()
    rules = _rule_rows(meta)
    versions = _versions_map([r.get("id") for r in rules])
    attributed = attribute_hits(meta)
    hits = attributed["hits"]
    internal = attributed["internal"]
    try:
        from . import rule as _rule_svc
        labels = _rule_svc.status_labels()
    except Exception:
        labels = {"rule": {}, "version": {}}
    try:
        from . import decision_table as _dt_st
        _stats_table_codes = {str(t.get("code") or "") for t in _dt_st.list_tables()}
    except Exception:
        _stats_table_codes = None
    for r in rules:
        code = str(r.get("code") or "")
        is_internal = _is_internal_rule(r, _stats_table_codes)
        if is_internal and not include_internal:
            seen_codes.add(code)
            continue
        v = (versions.get(str(r.get("id") or "")) or {}).get("latest") or {}
        eff = _effective_of(r, versions, None)
        if is_internal:
            hit = hits["by_decision_table"].get(_internal_target(r), 0)
            hit_attributed = False  # 归并后的命中算在决策表行，规则行不再计
        else:
            hit = hits["by_rule"].get(code, 0)
            hit_attributed = hit > 0
        override = (hits["override_by_rule"].get(code, 0) if not is_internal
                    else 0)
        try:
            from . import rule_ir as _ri
            _ex = _ri.classify_executability(json.loads((v or {}).get("slots_json") or "{}"))
            _ex = {"level": _ex["level"], "missing": _ex["missing_evidence"],
                   "suggestions": _ex["suggestions"]}
        except Exception:
            _ex = None
        try:
            _scope0 = json.loads(r.get("scope_json") or "{}") or {}
        except Exception:
            _scope0 = {}
        _map0 = _scope0.get("point_mapping") or {}
        _smeta0 = _scope0.get("scope_meta") or {}
        point_id = _map0.get("point_id") or ""
        point_hit = hits["by_point"].get(str(point_id), 0) if point_id else 0
        out.append({
            "id": r["id"], "code": code, "name": r["name"], "category": r["category"],
            "rclass": r["rclass"], "status": r["status"],
            "status_label": labels.get("rule", {}).get(str(r["status"] or ""),
                                                       str(r["status"] or "")),
            "source": r["source"] or "内置规则",
            "source_label": "内置规则" if (str(r["source"] or "") in ("内置规则", "")
                                          or code in _builtin_codes()) else (r["source"] or ""),
            "mapped": bool(_map0.get("mapped")), "point_id": point_id,
            "version": (v or {}).get("version", "v0.1"),
            "version_status": (v or {}).get("status") or "",
            "version_status_label": labels.get("version", {}).get(
                str((v or {}).get("status") or ""), str((v or {}).get("status") or "")),
            "latest_version": eff["latest_version"],
            "latest_status": eff["latest_status"],
            "effective_version": eff["effective_version"],
            "effective_version_id": eff["effective_version_id"],
            "effective_status": eff["effective_status"],
            "effective_status_label": {"published": "已发布（生效中）",
                                       "archived": "已下线（不执行）",
                                       "none": "无生效版本"}.get(eff["effective_status"], ""),
            "hit_count": hit,
            "hit_count_attributed": hit,
            "hit_count_point": point_hit,
            "hit_attributed": hit_attributed,
            "hit_count_display": (hit if hit > 0 else
                                  ("未归因" if (hits["unattributed"] or point_hit) else 0)),
            "override_count": override,
            "health": (round(100 * (1 - override / hit)) if hit > 0 else None),
            "health_state": ("attributed" if hit > 0 else
                             "unattributed" if (hits["unattributed"] or point_hit)
                             else "no_hit"),
            "health_label": (("健康度 %d%%" % round(100 * (1 - override / hit))) if hit > 0
                             else ("未归因（不可计算）" if (hits["unattributed"] or point_hit)
                                   else "暂无归因命中")),
            "kind": "db", "internal": is_internal,
            "editable": str(r["status"] or "") in ("draft", "approved", "published"),
            "editable_reason": ("" if str(r["status"] or "") in
                                ("draft", "approved", "published")
                                else "待审批/已下线规则不可直接编辑"),
            "executability": _ex,
            "ir": _scope0.get("ir") or {},
            # T-185（KB 评审 P1-1）：草稿箱「可发布」必须与发布门禁同口径，
            # 否则会出现「完整度 40% 待补全 + 发布生效按钮」自相矛盾。
            # 作用域状态来自 scope.scope_meta（单一口径，与 _scope_publish_gate 同源）。
            "scope_status": str(_smeta0.get("status") or "missing"),
            "scope_declared": bool(_smeta0.get("declared")),
            "scope_required": bool(_scope0.get("scope_required")),
            "scope_missing": bool(_smeta0.get("missing")),
            "scope_inferred": bool(_scope0.get("scope_inferred")),
            "publishable": bool((_scope0.get("ir") or {}).get("publishable")),
            "owner": r.get("owner") or "", "owner_id": r.get("owner_id") or ""})
        seen_codes.add(code)
    points = attributed["points"]
    for p in points:
        pid = _point_hit_code(p)
        if pid in seen_codes:
            continue
        hit = hits["by_point"].get(pid, 0)
        override = hits["override_by_point"].get(pid, 0)
        out.append({"id": pid, "code": pid, "name": p.name,
                    "category": CAT_MAP.get(p.category_id, "consistency"),
                    "rclass": {"compare": "R0", "text": "R0", "calculate": "R1",
                               "semantic": "R4", "expert": "R4"}.get(p.method, "R4"),
                    "status": LIBRARY_STATUS,
                    "status_label": labels.get("rule", {}).get(LIBRARY_STATUS, "已发布"),
                    "source": f"审核库 · {p.category}",
                    "source_label": f"审核库 · {p.category}",
                    "version": LIBRARY_VERSION, "version_status": LIBRARY_VERSION_STATUS,
                    "version_status_label": "已发布",
                    "latest_version": LIBRARY_VERSION,
                    "latest_status": LIBRARY_VERSION_STATUS,
                    "effective_version": LIBRARY_VERSION,
                    "effective_version_id": "",
                    "effective_status": LIBRARY_VERSION_STATUS,
                    "effective_status_label": "已发布（生效中）",
                    "hit_count": hit, "hit_count_attributed": hit,
                    "hit_count_point": hit, "hit_attributed": hit > 0,
                    "hit_count_display": (hit if hit > 0 else
                                          ("未归因" if hits["unattributed"] else 0)),
                    "override_count": override,
                    "health": (round(100 * (1 - override / hit)) if hit > 0 else None),
                    "health_state": "attributed" if hit > 0 else
                                    ("unattributed" if hits["unattributed"] else "no_hit"),
                    "health_label": (("健康度 %d%%" % round(100 * (1 - override / hit))) if hit > 0 else
                                     ("未归因（不可计算）" if hits["unattributed"]
                                      else "暂无归因命中")),
                    "kind": "library", "internal": False,
                    "editable": False, "editable_reason": "审核库点位由平台点位库管理",
                    "mapped": True, "point_id": pid,
                    "method_name": p.method_name, "level": p.level_raw})
    for t in _decision_tables():
        code = str(t.get("code") or "")
        if code in seen_codes:
            continue
        hit = hits["by_decision_table"].get(code, 0)
        override = hits["override_by_decision_table"].get(code, 0)
        out.append({"id": code, "code": code, "name": t["name"], "category": "limit",
                    "rclass": "R1", "status": t["status"],
                    "status_label": {"draft": "草稿", "published": "已发布"}.get(
                        str(t["status"] or ""), str(t["status"] or "")),
                    "source": f"决策表 · {t['rows']} 行 / {t['hit_policy']}",
                    "source_label": f"决策表 · {t['rows']} 行 / {t['hit_policy']}",
                    "version": t["version"],
                    "version_status": LIBRARY_VERSION_STATUS if t["status"] == "published" else "draft",
                    "version_status_label": "已发布" if t["status"] == "published" else "草稿",
                    "latest_version": t["version"],
                    "latest_status": t["status"],
                    "effective_version": t["version"] if t["status"] == "published" else "",
                    "effective_version_id": "",
                    "effective_status": "published" if t["status"] == "published" else "none",
                    "effective_status_label": ("已发布（生效中）" if t["status"] == "published"
                                               else "无生效版本"),
                    "hit_count": hit, "hit_count_attributed": hit,
                    "hit_count_point": 0, "hit_attributed": hit > 0,
                    "hit_count_display": (hit if hit > 0 else
                                          ("未归因" if hits["unattributed"] else 0)),
                    "override_count": override,
                    "health": (round(100 * (1 - override / hit)) if hit > 0 else None),
                    "health_state": "attributed" if hit > 0 else
                                    ("unattributed" if hits["unattributed"] else "no_hit"),
                    "health_label": (("健康度 %d%%" % round(100 * (1 - override / hit))) if hit > 0 else
                                     ("未归因（不可计算）" if hits["unattributed"]
                                      else "暂无归因命中")),
                    "mapped": False, "point_id": "", "kind": "decision",
                    "internal": False,
                    "editable": str(t["status"] or "draft") == "draft",
                    "editable_reason": "" if str(t["status"] or "draft") == "draft"
                    else "已发布决策表不可直接编辑"})
    return out


def hit_summary(scope: str = "tenant") -> dict:
    """命中归因摘要（P0-02）：规则库页/首页/统计同源，禁止把 0 当“无问题”。"""
    counts = rule_counts(scope)
    hits = counts["hits"]
    return {
        "scope": counts["scope"],
        "total": hits["total"],
        "attributed": hits["attributed"],
        "unattributed": hits["unattributed"],
        "attributed_rate": (round(hits["attributed"] / hits["total"], 3)
                            if hits["total"] else 0.0),
        "unattributed_by_code": hits["unattributed_by_code"],
        "manifest_attributed": hits["manifest_attributed"],
        "note": ("命中按 manifest_result.rule_code / 事实码归因；无法归因计入 unattributed，"
                 "不把 0 当“无命中”"),
        "health_policy": "仅归因命中可计算健康度；unattributed 不伪造 0% 或 100%",
    }
