# -*- coding: utf-8 -*-
"""机制规则路由：只根据目标文本与点位的机制/证据/核查步骤做弱路由。

不是按答案选点，也不把具体原句写进路由；无法命中时保留全部点。
"""
from __future__ import annotations
import re

_TOKEN_RE = re.compile(r"[\u4e00-\u9fa5A-Za-z0-9]{2,12}")
_STOP = set("的了在和与及或对于以及其中进行是否应当必须需要可以本文件原文规定要求检查核对确认".replace(" ", ""))


def _tokens(text: str) -> list[str]:
    out = []
    for x in _TOKEN_RE.findall(str(text or "")):
        if len(x) >= 2 and x not in _STOP:
            out.append(x)
    return list(dict.fromkeys(out))


def terms(point: dict) -> list[str]:
    """点位可路由字段；不包含 expected answers。"""
    vals = []
    for k in ("route_terms", "mechanism_terms", "evidence_terms", "evidence", "criterion", "prompt", "name", "point"):
        v = (point or {}).get(k)
        if isinstance(v, (list, tuple)):
            vals.extend(str(x) for x in v)
        elif v:
            vals.append(str(v))
    out = []
    for s in vals:
        for t in _tokens(s):
            if t not in out:
                out.append(t)
        for seg in re.split(r"[、,，;；/\\s]+", s):
            seg = seg.strip()
            if 2 <= len(seg) <= 10 and seg not in out:
                out.append(seg)
    return out


def score(point: dict, text: str) -> int:
    doc = str(text or "")
    if not doc:
        return 0
    ts = terms(point)
    sc = sum(1 for t in ts if t in doc)
    name = str((point or {}).get("name") or (point or {}).get("point") or "")
    if name and name in doc:
        sc += 3
    return sc


def type_match(point: dict, text: str) -> int:
    """仅作为同分 tie-break：证据类型匹配，不压过基础相关度。"""
    typ = str((point or {}).get("mechanism_type") or "")
    doc = str(text or "")
    hints = {
        "qualification": ("资质", "资格", "许可", "证书", "执业", "准入"),
        "amount": ("金额", "报价", "限价", "单价", "总价", "费用", "税率", "费率"),
        "date": ("日期", "时间", "期限", "工期", "有效期", "截止", "时点"),
        "process": ("流程", "程序", "顺序", "评审", "开标", "投标", "审批", "签字", "报名"),
        "format": ("格式", "编号", "结构", "表格", "重复", "残缺", "可读"),
        "consistency": ("一致", "合计", "数量", "单位", "量纲", "核对", "错配"),
    }
    return 1 if typ in hints and any(k in doc for k in hints[typ]) else 0


def route(points: list[dict], text: str, top_k: int = 0, min_score: int = 0,
          min_per_type: int = 1) -> list[dict]:
    """按分数排序；top_k=0 返回全部（仍保持原顺序），否则取前 top_k。

    保留 ``score=0`` 的点只在 top_k=0 时发生；显式路由时不会为了凑数硬塞。
    """
    pts = list(points or [])
    if not top_k or top_k <= 0:
        return pts
    ranked = sorted(enumerate(pts), key=lambda x: (-score(x[1], text), -type_match(x[1], text), x[0]))
    picked = [p for i, p in ranked if score(p, text) >= min_score][:top_k]
    # 证据类型保底：避免 format/process 低分点被整体挤掉；不追加无证据分点。
    if min_per_type and top_k:
        chosen = {str(p.get("id") or p.get("code") or "") for p in picked}
        by_type = {}
        for _, p in ranked:
            typ = str(p.get("mechanism_type") or "")
            if not typ or typ == "generic":
                continue
            if score(p, text) < min_score:
                continue
            by_type.setdefault(typ, []).append(p)
        for typ, rows in by_type.items():
            have = sum(1 for p in picked if str(p.get("mechanism_type") or "") == typ)
            need = max(0, min_per_type - have)
            for p in rows:
                pid = str(p.get("id") or p.get("code") or "")
                if need <= 0: break
                if pid in chosen: continue
                if len(picked) >= top_k:
                    # 替换当前最低分、非同类型、非最后一名的点
                    replace = None
                    for q in reversed(picked):
                        if str(q.get("mechanism_type") or "") != typ and score(q, text) > 0:
                            replace = q; break
                    if replace is None: continue
                    picked.remove(replace)
                    chosen.discard(str(replace.get("id") or replace.get("code") or ""))
                picked.append(p); chosen.add(pid); need -= 1
    return picked
