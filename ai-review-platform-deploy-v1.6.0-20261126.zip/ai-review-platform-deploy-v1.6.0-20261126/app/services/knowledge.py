# -*- coding: utf-8 -*-
"""T-75 规则进化·知识库服务（最普通的文件库，只做用户要求的能力）。

产品口径（用户明确）：
- 以工作空间为单位：所有查询/写入都只落在当前 (tenant_id, workspace_id)；
- 工作空间内业务角色全部权限（业务管理员 + 审核员）：可建一级文件夹、上传、查看、
  重命名、移动、删除（进回收站）、恢复、彻底删除；不按上传人/文件做任何权限细分；
- 只有一级文件夹（不得嵌套；支持单层文件夹重命名/文件移动）；
- T-188（2026-11-20，用户确认产品能力扩展）：删除改为回收站软删 + 恢复 + 彻底删除；
  重命名/移动由服务端校验（名称长度/非法字符/目标文件夹归属/跨空间 404）并写审计；
- 文件实体落 ``data/knowledge/<tenant>/<workspace>/``，DB 只存相对存储名；
- 上传/删除/回收站/重命名/移动/建文件夹写审计日志；重复上传按 sha256 幂等去重。

安全边界：
- 文件名做 basename/控制字符/长度清洗，禁止路径分隔符与 ``..``；
- 租户/空间 id 白名单字符校验，落盘/读取路径必须落在知识库根目录内（commonpath）；
- 扩展名白名单 + 大小上限（默认 50MB，``RULEPROOF_KB_MAX_BYTES`` 可覆盖）；
- office/压缩等类型只允许安全下载，不以内联方式渲染；txt/图片/pdf 才 inline；
- 跨空间/跨租户访问一律 404（不泄露存在性）；回收站列表只返回当前空间。

边界说明：本模块不接审核/规则判定主链，只服务知识库自身与「新建规则上传文件」的
引用/默认同步；不修改任何既有表与既有业务逻辑。

回收站数据模型（T-188，幂等迁移见 ``app/db.py::_init_knowledge_schema``）：
- ``knowledge_file`` / ``knowledge_folder`` 新增 ``deleted_at``（空=存活）、
  ``deleted_by``、``deleted_via``（file/folder 记录删除来源）；
- 文件夹软删时保存 ``orig_name`` 并把 name 改成 ``__deleted__<id>`` 以释放同名唯一索引；
  恢复时若已有同名存活文件夹则 409（不覆盖用户数据）；
- 软删文件仍在同文件夹 sha 唯一索引内：重新上传同内容会自动从回收站恢复该行
  （不产生重复物理文件，也不丢用户历史）；
- 彻底删除才物理删除 DB 行+落盘文件（沿用原 DELETE 端点，保留既有 API 语义）。
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
import uuid
from pathlib import Path

from .. import db
from .. import repositories as R
from . import audit as _audit_svc

LOG = logging.getLogger(__name__)

# 文件根目录：默认 platform/data/knowledge；测试/部署可覆盖，不写死仓库路径。
ROOT = Path(os.environ.get("RULEPROOF_KNOWLEDGE_ROOT")
            or str(Path(__file__).resolve().parents[2] / "data" / "knowledge"))
DEFAULT_MAX_BYTES = 50 * 1024 * 1024
MAX_FOLDER_NAME = 40
MAX_FILENAME = 180
MAX_PARTS = 8
MAX_BATCH = 200  # 批量移动/回收站操作单次上限（防一次请求过大事务）
ALIVE = "COALESCE(deleted_at,'')=''"

# 允许上传的普通办公/文本/图片类型（不含可执行、脚本、宏文件）。
ALLOWED_EXT = {
    ".pdf", ".docx", ".xlsx", ".pptx", ".txt", ".md", ".csv", ".json",
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".eml",
}
OFFICE_EXT = {".docx", ".xlsx", ".pptx"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
TEXT_EXT = {".txt", ".md", ".csv", ".json"}
MIME_BY_EXT = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/plain; charset=utf-8",
    ".csv": "text/plain; charset=utf-8",
    ".json": "text/plain; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
    ".eml": "message/rfc822",
}
# 业务角色：工作空间内全权限；系统管理员/平台运营遵循平台既有业务边界（不可写审核业务）。
ALLOWED_ROLES = ("admin", "reviewer")
PLATFORM_ROLES = ("super_admin", "platform_op")

# 错误码 → HTTP 状态（HTTP 路由与服务同源，避免两边各写一份）。
ERROR_STATUS = {
    "forbidden": 403,
    "invalid_folder": 400,
    "invalid_filename": 400,
    "invalid_file_type": 400,
    "file_too_large": 413,
    "empty_file": 400,
    "not_found": 404,
    "duplicate_folder": 409,
    "duplicate_filename": 409,
    "folder_not_empty": 409,
    "confirm_required": 409,
    "scope_required": 403,
    "invalid_request": 400,
    "invalid_operation": 400,
    "not_in_recycle": 409,
    "nothing_to_do": 400,
    "recycle_name_conflict": 409,
}


class KnowledgeError(Exception):
    """知识库业务错误：带 HTTP 状态与机读 code，路由直接映射响应。"""

    def __init__(self, message: str, code: str = "invalid_request", **extra):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status = ERROR_STATUS.get(code, 400)
        self.extra = extra

    def payload(self) -> dict:
        out = {"ok": False, "error": self.message, "code": self.code}
        out.update(self.extra or {})
        return out


# ---------------------------------------------------------------------------
# 基础：上下文 / 角色 / 路径安全
# ---------------------------------------------------------------------------
def _ctx_scope(user: dict | None = None) -> tuple:
    """当前租户/空间：优先线程上下文（HTTP 会话已设置），回退到用户当前空间。

    P2-03：上下文与账号行都拿不到租户/空间时 **fail-closed 报错**，不再回退
    t-default/ws-default（否则异常路径可能把文件读写到默认租户空间）。
    """
    user = user or {}
    try:
        from . import ctx as _ctx
        cur = _ctx.get_context() or {}
    except Exception:
        cur = {}
    tenant_id = str(cur.get("tenant_id") or "").strip()
    workspace_id = str(cur.get("workspace_id") or "").strip()
    uid = str(user.get("sub") or "").strip()
    if (not tenant_id or not workspace_id) and uid:
        try:
            row = R.users.get(uid) or {}
            tenant_id = tenant_id or str(row.get("tenant_id") or "").strip()
            workspace_id = workspace_id or str(row.get("current_workspace_id") or "").strip()
        except Exception:
            LOG.debug("knowledge scope fallback failed", exc_info=True)
            tenant_id = tenant_id or ""
            workspace_id = workspace_id or ""
    if not tenant_id or not workspace_id:
        raise KnowledgeError(
            "无法确定当前租户/工作空间（缺少会话上下文），已拒绝知识库操作", "scope_required")
    return tenant_id, workspace_id


def _uid(user: dict | None) -> str:
    return str((user or {}).get("sub") or (user or {}).get("name") or "").strip()


def _ensure_role(user: dict | None) -> str:
    """工作空间内业务角色全权限；系统管理员/平台运营按平台边界拒绝。"""
    role = str((user or {}).get("role") or "").strip()
    if role in PLATFORM_ROLES:
        raise KnowledgeError("系统管理员/平台运营不访问审核业务", "forbidden")
    if role not in ALLOWED_ROLES:
        raise KnowledgeError("无权限：知识库仅限业务角色在所属空间使用", "forbidden")
    return role


def _safe_seg(value: str, what: str = "标识") -> str:
    """租户/空间 id 白名单校验（防路径穿越；DB 被污染也不越出根目录）。"""
    v = str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", v):
        raise KnowledgeError(f"{what}非法", "invalid_request")
    return v


def _safe_filename(raw: str) -> str:
    """文件名安全清洗：去目录、去控制字符、去首尾点/空格、控制长度。"""
    name = str(raw or "").replace("\\", "/").split("/")[-1]
    name = "".join(ch for ch in name if ord(ch) >= 32 and ord(ch) != 127)
    name = name.strip().strip(".").strip()
    if not name or name in (".", ".."):
        raise KnowledgeError("文件名非法（不能为空或仅含路径）", "invalid_filename")
    # 按 UTF-8 字节控制长度，保留扩展名
    ext = os.path.splitext(name)[1].lower()
    stem = name[: len(name) - len(ext)] if ext else name
    while len((stem + ext).encode("utf-8")) > MAX_FILENAME:
        stem = stem[:-1]
        if len(stem) <= 1:
            raise KnowledgeError("文件名过长", "invalid_filename")
    out = stem + ext
    if out.startswith("."):
        out = out.lstrip(".")
    if not out:
        raise KnowledgeError("文件名非法", "invalid_filename")
    return out


def _max_bytes() -> int:
    try:
        return max(1024, int(os.environ.get("RULEPROOF_KB_MAX_BYTES", DEFAULT_MAX_BYTES)))
    except Exception:
        return DEFAULT_MAX_BYTES


def max_bytes() -> int:
    """单文件大小上限（公开口径：HTTP 路由与 service 校验同源）。"""
    return _max_bytes()


def _root() -> Path:
    return Path(ROOT)


def _ensure_within(base: Path, target: Path) -> Path:
    """路径必须落在 base 内（拒绝 ../、软链逃逸之外的相对路径）。"""
    b = os.path.realpath(str(base))
    t = os.path.realpath(str(target))
    if t != b and not t.startswith(b + os.sep):
        raise KnowledgeError("非法文件路径", "invalid_request")
    return Path(t)


def _file_path(tenant_id: str, workspace_id: str, stored_name: str) -> Path:
    """知识库文件绝对路径；stored_name 只允许单层文件名，不接受目录。"""
    safe = str(stored_name or "")
    if (not safe or safe in (".", "..") or "/" in safe or "\\" in safe
            or "\x00" in safe or any(ord(ch) < 32 for ch in safe)):
        raise KnowledgeError("非法文件路径", "invalid_request")
    t = _safe_seg(tenant_id, "租户")
    w = _safe_seg(workspace_id, "空间")
    base = _root()
    target = base / t / w / safe
    return _ensure_within(base, target)


def _stored_name(sha256: str, safe_name: str) -> str:
    return f"{sha256[:16]}_{safe_name}"


def _stored_refs(tenant_id: str, workspace_id: str, stored_name: str,
                 exclude_ids=()) -> int:
    """同一物理存储名（stored_name）在本租户/空间内仍被多少条 DB 行引用。

    落盘名不含 folder_id，同一内容+同文件名上传到不同文件夹会共享一个物理文件；
    删除任一 DB 行前必须按引用计数判断，仍有其它行引用时不得 unlink（P1-02）。
    """
    name = str(stored_name or "")
    if not name:
        return 0
    sql = ("SELECT COUNT(*) AS n FROM knowledge_file "
           "WHERE tenant_id=? AND workspace_id=? AND stored_name=?")
    params = [tenant_id, workspace_id, name]
    exclude = [str(x) for x in (exclude_ids or []) if str(x or "")]
    if exclude:
        sql += " AND id NOT IN (" + ",".join("?" * len(exclude)) + ")"
        params.extend(exclude)
    row = _one(sql, tuple(params))
    try:
        return int((row or {}).get("n") or 0)
    except Exception:
        return 0


def _unlink_stored(tenant_id: str, workspace_id: str, stored_name: str,
                   exclude_ids=()) -> bool:
    """无其它 DB 行引用时才物理删除；返回是否真正删除。"""
    if _stored_refs(tenant_id, workspace_id, stored_name, exclude_ids) > 0:
        return False
    try:
        target = _file_path(tenant_id, workspace_id, str(stored_name or ""))
        if target.exists():
            target.unlink()
            return True
    except KnowledgeError:
        raise
    except OSError:
        LOG.warning("knowledge file unlink failed stored=%s", stored_name, exc_info=True)
    return False


# ---------------------------------------------------------------------------
# 数据读取（全部限定当前租户/空间）
# ---------------------------------------------------------------------------
def _rows(sql: str, params: tuple = ()) -> list:
    with db.session() as c:
        return [dict(r) for r in c.execute(sql, params).fetchall()]


def _one(sql: str, params: tuple = ()) -> dict | None:
    with db.session() as c:
        r = c.execute(sql, params).fetchone()
        return dict(r) if r else None


def get_folder(folder_id: str, tenant_id: str, workspace_id: str,
               include_deleted: bool = False) -> dict | None:
    """按 id 取文件夹；默认只取存活项（回收站项需显式 include_deleted=True）。"""
    if not folder_id:
        return None
    sql = "SELECT * FROM knowledge_folder WHERE id=? AND tenant_id=? AND workspace_id=?"
    if not include_deleted:
        sql += " AND " + ALIVE
    return _one(sql, (str(folder_id), tenant_id, workspace_id))


def get_file(file_id: str, tenant_id: str, workspace_id: str,
             include_deleted: bool = False) -> dict | None:
    """按 id 取文件；默认只取存活项（回收站项需显式 include_deleted=True）。"""
    if not file_id:
        return None
    sql = "SELECT * FROM knowledge_file WHERE id=? AND tenant_id=? AND workspace_id=?"
    if not include_deleted:
        sql += " AND " + ALIVE
    return _one(sql, (str(file_id), tenant_id, workspace_id))


def list_knowledge(user: dict | None = None, folder_id: str | None = None) -> dict:
    """知识库列表：一级文件夹 + 文件；folder_id 可选过滤（'root' 表示根目录）。

    只返回存活项；回收站计数随列表下发（供页面「回收站」入口展示，不含内容）。
    """
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    folders = _rows(
        "SELECT f.id, f.name, f.created_by, f.created_at, "
        "  (SELECT count(*) FROM knowledge_file k WHERE k.folder_id=f.id "
        "     AND k.tenant_id=f.tenant_id AND k.workspace_id=f.workspace_id "
        "     AND COALESCE(k.deleted_at,'')='') AS file_count "
        "FROM knowledge_folder f WHERE f.tenant_id=? AND f.workspace_id=? "
        "  AND COALESCE(f.deleted_at,'')='' "
        "ORDER BY f.created_at DESC, f.id DESC", (tenant_id, workspace_id))
    files = _rows(
        "SELECT * FROM knowledge_file WHERE tenant_id=? AND workspace_id=? "
        "  AND COALESCE(deleted_at,'')='' "
        "ORDER BY created_at DESC, id DESC", (tenant_id, workspace_id))
    names = {f["id"]: f["name"] for f in folders}
    for it in files:
        it["folder_name"] = names.get(it.get("folder_id") or "", "")
        it.pop("stored_name", None)  # 内部存储名不下发前端，前端只用 id 访问 view
        it.pop("deleted_at", None)
        it.pop("deleted_by", None)
        it.pop("deleted_via", None)
    total_files = len(files)
    total_bytes = sum(int(x.get("size") or 0) for x in files)
    recycle = _row_count(
        "SELECT COUNT(*) AS n FROM knowledge_file WHERE tenant_id=? AND workspace_id=? "
        "  AND COALESCE(deleted_at,'')<>''", (tenant_id, workspace_id))
    recycle_folders = _row_count(
        "SELECT COUNT(*) AS n FROM knowledge_folder WHERE tenant_id=? AND workspace_id=? "
        "  AND COALESCE(deleted_at,'')<>''", (tenant_id, workspace_id))
    # 可选按文件夹过滤：folder_id='root' 表示根目录（未归档），其余为一级文件夹 id。
    view_folder = str(folder_id or "").strip()
    shown = files
    if view_folder == "root":
        shown = [x for x in files if not str(x.get("folder_id") or "")]
    elif view_folder:
        shown = [x for x in files if str(x.get("folder_id") or "") == view_folder]
    out = {
        "ok": True,
        "tenant_id": tenant_id,
        "workspace_id": workspace_id,
        "workspace_name": workspace_label(tenant_id, workspace_id),
        "folders": folders,
        "files": shown,
        "stats": {"folders": len(folders), "files": total_files, "bytes": total_bytes,
                  "recycle_files": recycle, "recycle_folders": recycle_folders},
        "folder_id": view_folder,
    }
    return out


def _row_count(sql: str, params: tuple) -> int:
    row = _one(sql, params)
    try:
        return int((row or {}).get("n") or 0)
    except Exception:
        return 0


def list_recycle(user: dict | None = None) -> dict:
    """回收站：当前空间已软删的文件 + 文件夹（含删除人/时间，供恢复/彻底删除）。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    folders = _rows(
        "SELECT * FROM knowledge_folder WHERE tenant_id=? AND workspace_id=? "
        "  AND COALESCE(deleted_at,'')<>'' ORDER BY deleted_at DESC, id DESC",
        (tenant_id, workspace_id))
    files = _rows(
        "SELECT * FROM knowledge_file WHERE tenant_id=? AND workspace_id=? "
        "  AND COALESCE(deleted_at,'')<>'' ORDER BY deleted_at DESC, id DESC",
        (tenant_id, workspace_id))
    all_folders = _rows(
        "SELECT id, name, COALESCE(NULLIF(orig_name,''), name) AS display_name "
        "FROM knowledge_folder WHERE tenant_id=? AND workspace_id=?", (tenant_id, workspace_id))
    folder_names = {str(f["id"]): str(f.get("display_name") or f.get("name") or "")
                    for f in all_folders}
    for fo in folders:
        fo["display_name"] = str(fo.get("orig_name") or fo.get("name") or "")
        fo.pop("stored_name", None)
    for fi in files:
        fi["folder_name"] = folder_names.get(str(fi.get("folder_id") or ""), "")
        fi.pop("stored_name", None)
    return {"ok": True, "tenant_id": tenant_id, "workspace_id": workspace_id,
            "workspace_name": workspace_label(tenant_id, workspace_id),
            "files": files, "folders": folders,
            "stats": {"files": len(files), "folders": len(folders)}}



def workspace_label(tenant_id: str, workspace_id: str) -> str:
    # P2-03：workspace id 虽全局唯一，标签查询也必须带租户条件，避免异常/污染数据跨租户串名。
    row = _one("SELECT name FROM workspace WHERE id=? AND COALESCE(tenant_id,'')=?",
               (str(workspace_id or ""), str(tenant_id or "")))
    return str((row or {}).get("name") or "")


# ---------------------------------------------------------------------------
# 写操作：建文件夹 / 上传 / 删除
# ---------------------------------------------------------------------------
def _clean_folder_name(name: str) -> str:
    """文件夹名校验（创建/重命名共用同一口径）：非空、≤40 字、无路径分隔符。"""
    raw = "".join(ch for ch in str(name or "") if ord(ch) >= 32 and ord(ch) != 127).strip()
    if not raw:
        raise KnowledgeError("文件夹名称不能为空", "invalid_folder")
    if len(raw) > MAX_FOLDER_NAME:
        raise KnowledgeError(f"文件夹名称不能超过 {MAX_FOLDER_NAME} 个字", "invalid_folder")
    if raw in (".", "..") or "/" in raw or "\\" in raw:
        raise KnowledgeError("文件夹名称不能包含路径分隔符", "invalid_folder")
    return raw


def _clean_rename_name(raw: str) -> str:
    """文件重命名：复用上传的文件名清洗，并强制扩展名仍在白名单内（改名不改类型）。

    与上传共用 ``_safe_filename``（basename/控制字符/长度）；但重命名是用户显式输入，
    对「含路径分隔符 / 超过 180 字节」**拒绝而不是静默截断**（避免用户以为改成了
    目标名称、实际落库被截断）。额外拒绝把扩展名改成可执行/压缩包等非白名单类型，
    避免「上传 .txt → 改名成 .exe」绕过类型校验。
    """
    text = str(raw or "")
    if not text.strip():
        raise KnowledgeError("文件名称不能为空", "invalid_filename")
    if "/" in text or "\\" in text:
        raise KnowledgeError("文件名称不能包含路径分隔符", "invalid_filename")
    if len(text.strip().encode("utf-8")) > MAX_FILENAME:
        raise KnowledgeError(f"文件名称不能超过 {MAX_FILENAME} 字节（约 60 个汉字）", "invalid_filename")
    safe = _safe_filename(text)
    ext = os.path.splitext(safe)[1].lower()
    if ext not in ALLOWED_EXT:
        raise KnowledgeError(
            "重命名后的文件类型不在支持范围内（支持 pdf/docx/xlsx/pptx/txt/md/csv/json/图片/eml）",
            "invalid_file_type")
    return safe


def create_folder(user: dict | None, name: str) -> dict:
    """建一级文件夹；同空间同名明确拒绝（409 duplicate_folder，附已存在项）。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    raw = _clean_folder_name(name)
    exist = _one("SELECT * FROM knowledge_folder WHERE tenant_id=? AND workspace_id=? AND name=?",
                 (tenant_id, workspace_id, raw))
    if exist:
        raise KnowledgeError("该空间已存在同名文件夹", "duplicate_folder",
                             existing={"id": exist["id"], "name": exist["name"]})
    fid = db.new_id("kf_")
    try:
        with db.session() as c:
            c.execute("INSERT INTO knowledge_folder(id,tenant_id,workspace_id,name,created_by,created_at) "
                      "VALUES(?,?,?,?,?,?)",
                      (fid, tenant_id, workspace_id, raw, _uid(user), db.now()))
            # P2-04：业务写与审计同事务；审计写失败→整体回滚并报错（不再“成功但无轨迹”）。
            _audit_tx(c, user, "knowledge.folder_create", fid,
                      {"name": raw, "tenant_id": tenant_id, "workspace_id": workspace_id})
    except sqlite3.IntegrityError:
        # 并发建同名：唯一索引兜底，按“已存在”返回，不产生第二条
        exist = _one("SELECT * FROM knowledge_folder WHERE tenant_id=? AND workspace_id=? AND name=?",
                     (tenant_id, workspace_id, raw))
        raise KnowledgeError("该空间已存在同名文件夹", "duplicate_folder",
                             existing={"id": (exist or {}).get("id", ""),
                                       "name": (exist or {}).get("name", raw)})
    row = get_folder(fid, tenant_id, workspace_id) or {"id": fid, "name": raw}
    return {"ok": True, "folder": row}


def upload(user: dict | None, filename: str, data: bytes, folder_id: str = "",
           mime: str = "", source: str = "") -> dict:
    """上传文件：校验 → sha256 → 落盘 → 入 DB；重复（同空间同文件夹同 sha）幂等。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    _safe_seg(tenant_id, "租户")
    _safe_seg(workspace_id, "空间")
    safe_name = _safe_filename(filename)
    ext = os.path.splitext(safe_name)[1].lower()
    if ext not in ALLOWED_EXT:
        raise KnowledgeError(
            "不支持的文件类型（支持 pdf/docx/xlsx/pptx/txt/md/csv/json/图片/eml）",
            "invalid_file_type")
    body = data if isinstance(data, (bytes, bytearray)) else b""
    if not body:
        raise KnowledgeError("文件为空，拒绝上传", "empty_file")
    limit = _max_bytes()
    if len(body) > limit:
        raise KnowledgeError(f"文件超过 {limit // 1024 // 1024 or 1}MB 上限", "file_too_large",
                             limit_bytes=limit, received_bytes=len(body))
    fid_folder = str(folder_id or "").strip()
    if fid_folder:
        if not get_folder(fid_folder, tenant_id, workspace_id):
            raise KnowledgeError("文件夹不存在或不属于当前空间", "not_found")
    else:
        fid_folder = ""
    digest = hashlib.sha256(body).hexdigest()
    stored = _stored_name(digest, safe_name)
    # 同空间同文件夹同 sha 幂等去重：先查 DB，命中直接返回，避免为重复内容再写
    # 一份无人引用的物理文件（引用计数删除依赖“无 DB 行引用才清理”，孤儿文件会泄漏）。
    existing = _one(
        "SELECT * FROM knowledge_file WHERE tenant_id=? AND workspace_id=? AND folder_id=? AND sha256=?",
        (tenant_id, workspace_id, fid_folder, digest))
    if existing:
        revived = bool(str(existing.get("deleted_at") or ""))
        with db.session() as c:  # P2-04：去重/回收站恢复事件同样同事务留痕
            if revived:
                _revive_file_tx(c, user, existing)
            _audit_tx(c, user, "knowledge.file_upload_deduplicated", existing["id"],
                      {"filename": safe_name, "sha256": digest, "size": len(body),
                       "folder_id": fid_folder, "source": source or "",
                       "restored_from_recycle": revived})
        row = get_file(existing["id"], tenant_id, workspace_id) or existing
        return {"ok": True, "file": _public_file(row), "deduplicated": True,
                "restored_from_recycle": revived}
    target = _file_path(tenant_id, workspace_id, stored)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".part-" + uuid.uuid4().hex[:8])
    try:
        with open(tmp, "wb") as fh:
            fh.write(body)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        os.replace(tmp, target)  # 原子替换；并发同内容写同一路径也安全
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
    # MIME 以扩展名为准（客户端可伪造 Content-Type，不能让它决定 inline/attachment 语义）
    file_mime = MIME_BY_EXT.get(ext) or str(mime or "").strip() or "application/octet-stream"
    fid = db.new_id("kfile_")
    try:
        with db.session() as c:
            c.execute(
                "INSERT INTO knowledge_file(id,folder_id,tenant_id,workspace_id,filename,stored_name,"
                "size,sha256,mime,uploaded_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (fid, fid_folder, tenant_id, workspace_id, safe_name, stored, len(body),
                 digest, file_mime, _uid(user), db.now()))
            # P2-04：上传行与审计同事务；审计失败→回滚上传并报错。
            _audit_tx(c, user, "knowledge.file_upload", fid,
                      {"filename": safe_name, "sha256": digest, "size": len(body),
                       "folder_id": fid_folder, "mime": file_mime, "source": source or "",
                       "tenant_id": tenant_id, "workspace_id": workspace_id})
    except sqlite3.IntegrityError:
        # 并发重复：唯一索引成立，返回已存在记录（幂等）。若并发胜者的落盘名不同
        # （不同文件名同内容），清理本次刚写入、且无任何 DB 行引用的物理文件。
        existing = _one(
            "SELECT * FROM knowledge_file WHERE tenant_id=? AND workspace_id=? AND folder_id=? AND sha256=?",
            (tenant_id, workspace_id, fid_folder, digest))
        if existing:
            if str(existing.get("stored_name") or "") != stored:
                _unlink_stored(tenant_id, workspace_id, stored)
            with db.session() as c:
                _audit_tx(c, user, "knowledge.file_upload_deduplicated", existing["id"],
                          {"filename": safe_name, "sha256": digest, "size": len(body),
                           "folder_id": fid_folder, "source": source or ""})
            return {"ok": True, "file": _public_file(existing), "deduplicated": True}
        raise
    row = get_file(fid, tenant_id, workspace_id) or {"id": fid, "filename": safe_name,
                                                     "sha256": digest, "size": len(body),
                                                     "folder_id": fid_folder, "mime": file_mime}
    return {"ok": True, "file": _public_file(row), "deduplicated": False}


def _public_file(row: dict) -> dict:
    out = {k: v for k, v in (row or {}).items() if k != "stored_name"}
    return out


# ---------------------------------------------------------------------------
# T-188 文件管理：回收站（软删/恢复/彻底删除）+ 重命名 + 移动
# ---------------------------------------------------------------------------
def _revive_file_tx(c, user: dict | None, row: dict) -> None:
    """同事务内把回收站文件恢复为存活（重新上传同内容时自动恢复）。"""
    c.execute("UPDATE knowledge_file SET deleted_at='', deleted_by='', deleted_via='', "
              "uploaded_by=?, created_at=? WHERE id=?",
              (_uid(user), db.now(), str(row.get("id"))))
    _audit_tx(c, user, "knowledge.file_restore", str(row.get("id")),
              {"filename": row.get("filename") or "", "sha256": row.get("sha256") or "",
               "note": "重新上传同 sha256 文件，自动从回收站恢复"})


def _clean_ids(ids) -> list:
    """批量操作 ids 归一化：去空、去重、限个数；空则 400。"""
    if isinstance(ids, str):
        ids = [ids]
    out = []
    seen = set()
    for x in (ids or []):
        v = str(x or "").strip()
        if v and v not in seen:
            seen.add(v)
            out.append(v)
    if not out:
        raise KnowledgeError("缺少要操作的文件/文件夹 id", "invalid_request")
    if len(out) > MAX_BATCH:
        raise KnowledgeError(f"单次最多操作 {MAX_BATCH} 项", "invalid_request")
    return out


def _kind(kind: str) -> str:
    k = str(kind or "file").strip().lower()
    if k in ("file", "files", "文件"):
        return "file"
    if k in ("folder", "folders", "文件夹"):
        return "folder"
    raise KnowledgeError("不支持的对象类型（file/folder）", "invalid_operation")


def trash_files(user: dict | None, ids) -> dict:
    """把文件移入回收站（软删）：保留 DB 行与物理文件，可恢复。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    clean = _clean_ids(ids)
    rows = []
    for fid in clean:
        row = get_file(fid, tenant_id, workspace_id)
        if not row:
            raise KnowledgeError("文件不存在或不属于当前空间", "not_found",
                                 missing_ids=[fid])
        rows.append(row)
    ts = db.now()
    uid = _uid(user)
    with db.session() as c:
        for row in rows:
            c.execute("UPDATE knowledge_file SET deleted_at=?, deleted_by=?, deleted_via='file' "
                      "WHERE id=? AND tenant_id=? AND workspace_id=?",
                      (ts, uid, str(row["id"]), tenant_id, workspace_id))
            _audit_tx(c, user, "knowledge.file_trash", str(row["id"]),
                      {"filename": row.get("filename") or "", "sha256": row.get("sha256") or "",
                       "size": int(row.get("size") or 0), "folder_id": row.get("folder_id") or "",
                       "tenant_id": tenant_id, "workspace_id": workspace_id})
    return {"ok": True, "trashed": [str(r["id"]) for r in rows], "count": len(rows)}


def trash_folder(user: dict | None, folder_id: str) -> dict:
    """把一级文件夹连同其中存活文件移入回收站（软删）；物理文件保留，可整体恢复。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    folder = get_folder(folder_id, tenant_id, workspace_id)
    if not folder:
        raise KnowledgeError("文件夹不存在或不属于当前空间", "not_found")
    files = _rows("SELECT * FROM knowledge_file WHERE folder_id=? AND tenant_id=? "
                  "AND workspace_id=? AND " + ALIVE,
                  (str(folder_id), tenant_id, workspace_id))
    ts = db.now()
    uid = _uid(user)
    orig = str(folder.get("orig_name") or folder.get("name") or "")
    free_name = "__deleted__" + str(folder_id)
    with db.session() as c:
        for row in files:
            c.execute("UPDATE knowledge_file SET deleted_at=?, deleted_by=?, deleted_via='folder' "
                      "WHERE id=?", (ts, uid, str(row["id"])))
            _audit_tx(c, user, "knowledge.file_trash", str(row["id"]),
                      {"filename": row.get("filename") or "", "sha256": row.get("sha256") or "",
                       "folder_id": str(folder_id), "via": "folder",
                       "tenant_id": tenant_id, "workspace_id": workspace_id})
        c.execute("UPDATE knowledge_folder SET deleted_at=?, deleted_by=?, deleted_via='folder', "
                  "orig_name=?, name=? WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (ts, uid, orig, free_name, str(folder_id), tenant_id, workspace_id))
        _audit_tx(c, user, "knowledge.folder_trash", str(folder_id),
                  {"name": orig, "file_count": len(files),
                   "file_ids": [str(r["id"]) for r in files][:50],
                   "tenant_id": tenant_id, "workspace_id": workspace_id})
    return {"ok": True, "trashed": str(folder_id), "count": 1,
            "trashed_files": len(files)}


def restore_items(user: dict | None, kind: str, ids) -> dict:
    """从回收站恢复文件/文件夹（文件夹恢复时一并恢复随它一起删除的文件）。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    k = _kind(kind)
    clean = _clean_ids(ids)
    restored = []
    skipped = []
    if k == "file":
        rows = []
        for fid in clean:
            row = get_file(fid, tenant_id, workspace_id, include_deleted=True)
            if not row:
                raise KnowledgeError("回收站中不存在该文件", "not_found", missing_ids=[fid])
            if not str(row.get("deleted_at") or ""):
                raise KnowledgeError("该文件不在回收站中", "not_in_recycle", file_id=fid)
            rows.append(row)
        with db.session() as c:
            for row in rows:
                folder_id = str(row.get("folder_id") or "")
                moved_to_root = False
                if folder_id:
                    fol = get_folder(folder_id, tenant_id, workspace_id, include_deleted=True)
                    if not fol or str(fol.get("deleted_at") or ""):
                        # 原文件夹仍在回收站：恢复到根目录，避免恢复到不可见目录
                        folder_id = ""
                        moved_to_root = True
                c.execute("UPDATE knowledge_file SET deleted_at='', deleted_by='', "
                          "deleted_via='', folder_id=? WHERE id=?",
                          (folder_id, str(row["id"])))
                _audit_tx(c, user, "knowledge.file_restore", str(row["id"]),
                          {"filename": row.get("filename") or "", "folder_id": folder_id,
                           "moved_to_root": moved_to_root,
                           "tenant_id": tenant_id, "workspace_id": workspace_id})
                restored.append(str(row["id"]))
    else:
        for fid in clean:
            fol = get_folder(fid, tenant_id, workspace_id, include_deleted=True)
            if not fol:
                raise KnowledgeError("回收站中不存在该文件夹", "not_found", missing_ids=[fid])
            if not str(fol.get("deleted_at") or ""):
                raise KnowledgeError("该文件夹不在回收站中", "not_in_recycle", folder_id=fid)
            name = str(fol.get("orig_name") or fol.get("name") or "")
            conflict = _one("SELECT id FROM knowledge_folder WHERE tenant_id=? AND workspace_id=? "
                            "AND name=? AND id<>? AND COALESCE(deleted_at,'')=''",
                            (tenant_id, workspace_id, name, str(fid)))
            if conflict:
                raise KnowledgeError(
                    f"恢复失败：已存在同名文件夹「{name}」，请先重命名或删除现有文件夹",
                    "recycle_name_conflict", conflicting={"id": conflict["id"], "name": name})
            files = _rows("SELECT id FROM knowledge_file WHERE folder_id=? AND tenant_id=? "
                          "AND workspace_id=? AND COALESCE(deleted_at,'')<>'' "
                          "AND COALESCE(deleted_via,'')='folder'",
                          (str(fid), tenant_id, workspace_id))
            with db.session() as c:
                c.execute("UPDATE knowledge_folder SET name=?, orig_name='', deleted_at='', "
                          "deleted_by='', deleted_via='' WHERE id=? AND tenant_id=? AND workspace_id=?",
                          (name, str(fid), tenant_id, workspace_id))
                for f in files:
                    c.execute("UPDATE knowledge_file SET deleted_at='', deleted_by='', "
                              "deleted_via='' WHERE id=?", (str(f["id"]),))
                _audit_tx(c, user, "knowledge.folder_restore", str(fid),
                          {"name": name, "restored_files": len(files),
                           "tenant_id": tenant_id, "workspace_id": workspace_id})
            skipped.extend([])
            restored.append(str(fid))
    return {"ok": True, "kind": k, "restored": restored, "count": len(restored),
            "skipped": skipped}


def rename_file(user: dict | None, file_id: str, name: str) -> dict:
    """文件重命名：服务端清洗名称 + 类型白名单 + 同文件夹内重名拒绝 + 审计。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    row = get_file(file_id, tenant_id, workspace_id)
    if not row:
        raise KnowledgeError("文件不存在或不属于当前空间", "not_found")
    new_name = _clean_rename_name(name)
    old_name = str(row.get("filename") or "")
    if new_name == old_name:
        return {"ok": True, "file": _public_file(row), "changed": False}
    dup = _one("SELECT id FROM knowledge_file WHERE tenant_id=? AND workspace_id=? "
               "AND folder_id=? AND filename=? AND id<>? AND " + ALIVE,
               (tenant_id, workspace_id, str(row.get("folder_id") or ""), new_name,
                str(file_id)))
    if dup:
        raise KnowledgeError("当前文件夹已存在同名文件，请换一个名称", "duplicate_filename")
    with db.session() as c:
        c.execute("UPDATE knowledge_file SET filename=? WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (new_name, str(file_id), tenant_id, workspace_id))
        _audit_tx(c, user, "knowledge.file_rename", str(file_id),
                  {"old": old_name, "new": new_name,
                   "folder_id": row.get("folder_id") or "",
                   "tenant_id": tenant_id, "workspace_id": workspace_id})
    fresh = get_file(file_id, tenant_id, workspace_id) or dict(row, filename=new_name)
    return {"ok": True, "file": _public_file(fresh), "changed": True,
            "old": old_name, "new": new_name}


def rename_folder(user: dict | None, folder_id: str, name: str) -> dict:
    """一级文件夹重命名：服务端校验（长度/非法字符/同空间重名）+ 审计。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    folder = get_folder(folder_id, tenant_id, workspace_id)
    if not folder:
        raise KnowledgeError("文件夹不存在或不属于当前空间", "not_found")
    raw = _clean_folder_name(name)
    old_name = str(folder.get("name") or "")
    if raw == old_name:
        return {"ok": True, "folder": folder, "changed": False}
    dup = _one("SELECT id FROM knowledge_folder WHERE tenant_id=? AND workspace_id=? "
               "AND name=? AND id<>? AND COALESCE(deleted_at,'')=''",
               (tenant_id, workspace_id, raw, str(folder_id)))
    if dup:
        raise KnowledgeError("该空间已存在同名文件夹", "duplicate_folder")
    with db.session() as c:
        c.execute("UPDATE knowledge_folder SET name=? WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (raw, str(folder_id), tenant_id, workspace_id))
        _audit_tx(c, user, "knowledge.folder_rename", str(folder_id),
                  {"old": old_name, "new": raw,
                   "tenant_id": tenant_id, "workspace_id": workspace_id})
    fresh = get_folder(folder_id, tenant_id, workspace_id) or dict(folder, name=raw)
    return {"ok": True, "folder": fresh, "changed": True, "old": old_name, "new": raw}


def move_files(user: dict | None, ids, folder_id: str = "") -> dict:
    """移动文件到一级文件夹（folder_id='' / 'root' = 移到未归档）。

    校验：目标文件夹必须存在且属于当前空间（否则 404）；文件不存在/跨空间 404；
    已在目标位置的文件跳过；每文件写审计（from → to）。
    """
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    clean = _clean_ids(ids)
    target = str(folder_id or "").strip()
    if target in ("", "root", "0"):
        target = ""
    target_name = "未归档"
    if target:
        fol = get_folder(target, tenant_id, workspace_id)
        if not fol:
            raise KnowledgeError("目标文件夹不存在或不属于当前空间", "not_found",
                                 folder_id=target)
        target_name = str(fol.get("name") or "文件夹")
    rows = []
    for fid in clean:
        row = get_file(fid, tenant_id, workspace_id)
        if not row:
            raise KnowledgeError("文件不存在或不属于当前空间", "not_found", missing_ids=[fid])
        rows.append(row)
    moved, skipped = [], []
    with db.session() as c:
        for row in rows:
            old = str(row.get("folder_id") or "")
            if old == target:
                skipped.append(str(row["id"]))
                continue
            c.execute("UPDATE knowledge_file SET folder_id=? WHERE id=? AND tenant_id=? "
                      "AND workspace_id=?", (target, str(row["id"]), tenant_id, workspace_id))
            _audit_tx(c, user, "knowledge.file_move", str(row["id"]),
                      {"filename": row.get("filename") or "",
                       "from_folder": old, "to_folder": target,
                       "to_folder_name": target_name,
                       "tenant_id": tenant_id, "workspace_id": workspace_id})
            moved.append(str(row["id"]))
    return {"ok": True, "moved": moved, "skipped": skipped, "count": len(moved),
            "to_folder": target, "to_folder_name": target_name}


def command(user: dict | None, body: dict | None) -> dict:
    """知识库写命令统一入口（POST /api/v1/knowledge/files 的 JSON 分支）。

    op:
      - rename  {kind, id, name}
      - move    {ids, folder_id}
      - trash   {kind, ids}                 → 软删进回收站
      - restore {kind, ids}                 → 从回收站恢复
      - purge   {kind, ids, confirm=true}   → 彻底删除（必须二次确认）
    """
    b = body if isinstance(body, dict) else {}
    op = str(b.get("op") or "").strip().lower()
    kind = b.get("kind") or ("folder" if b.get("folder_id_only") else "file")
    if op == "rename":
        k = _kind(b.get("kind") or "file")
        oid = str(b.get("id") or "").strip()
        if not oid:
            raise KnowledgeError("缺少要重命名的 id", "invalid_request")
        return rename_file(user, oid, b.get("name") or "") if k == "file" \
            else rename_folder(user, oid, b.get("name") or "")
    if op == "move":
        return move_files(user, b.get("ids") or b.get("id"), b.get("folder_id") or "")
    if op == "trash":
        k = _kind(kind)
        if k == "folder":
            ids = _clean_ids(b.get("ids") or b.get("id"))
            if len(ids) != 1:
                raise KnowledgeError("文件夹回收站操作一次只支持一个文件夹", "invalid_request")
            return trash_folder(user, ids[0])
        return trash_files(user, b.get("ids") or b.get("id"))
    if op == "restore":
        return restore_items(user, kind, b.get("ids") or b.get("id"))
    if op == "purge":
        k = _kind(kind)
        if b.get("confirm") not in (True, 1, "1", "true", "yes"):
            raise KnowledgeError("彻底删除需要二次确认（confirm=true）", "confirm_required")
        ids = _clean_ids(b.get("ids") or b.get("id"))
        deleted = []
        if k == "folder":
            for fid in ids:
                out = delete_folder(user, fid, confirm=True, purged=True)
                deleted.append(out.get("deleted"))
            return {"ok": True, "kind": "folder", "deleted": deleted, "count": len(deleted)}
        for fid in ids:
            out = delete_file(user, fid, confirm=True, purged=True)
            deleted.append(out.get("deleted"))
        return {"ok": True, "kind": "file", "deleted": deleted, "count": len(deleted)}
    raise KnowledgeError("不支持的操作（rename/move/trash/restore/purge）", "invalid_operation")


def delete_file(user: dict | None, file_id: str, confirm: bool = False,
                purged: bool = False) -> dict:
    """彻底删除文件：必须带确认；物理删除 DB 行 + 落盘文件（回收站「彻底删除」用它）。

    P1-02：先删 DB 行，再按 stored_name 统计剩余引用；仅当无其它文件行共享同一
    物理文件时才 unlink，避免删除另一个文件夹中仍在使用的副本。
    软删（进回收站）用 ``trash_files``；本函数是**不可恢复**的彻底删除。
    """
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    row = get_file(file_id, tenant_id, workspace_id, include_deleted=True)
    if not row:
        raise KnowledgeError("文件不存在或不属于当前空间", "not_found")
    if not confirm:
        raise KnowledgeError("删除需要二次确认（confirm=1）", "confirm_required")
    stored = str(row.get("stored_name") or "")
    was_trashed = bool(str(row.get("deleted_at") or ""))
    with db.session() as c:
        c.execute("DELETE FROM knowledge_file WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (str(file_id), tenant_id, workspace_id))
        # P2-04：删除行与审计同事务；审计失败→回滚删除并报错。
        _audit_tx(c, user, "knowledge.file_delete", str(file_id),
                  {"filename": row.get("filename") or "", "sha256": row.get("sha256") or "",
                   "size": int(row.get("size") or 0), "folder_id": row.get("folder_id") or "",
                   "purged_from_recycle": bool(purged or was_trashed),
                   "tenant_id": tenant_id, "workspace_id": workspace_id})
    _unlink_stored(tenant_id, workspace_id, stored)
    return {"ok": True, "deleted": str(file_id)}


def delete_folder(user: dict | None, folder_id: str, confirm: bool = False,
                  purged: bool = False) -> dict:
    """彻底删除一级文件夹：非空必须确认，确认后连同文件一起删除（显式删，不级联）。

    P1-02：同一物理文件可能被其它文件夹/根目录的 DB 行共享，删除本文件夹行后
    必须按 stored_name 做引用计数，仅删除无其它引用的物理文件。
    软删（进回收站）用 ``trash_folder``；本函数是**不可恢复**的彻底删除。
    """
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    folder = get_folder(folder_id, tenant_id, workspace_id, include_deleted=True)
    if not folder:
        raise KnowledgeError("文件夹不存在或不属于当前空间", "not_found")
    files = _rows("SELECT * FROM knowledge_file WHERE folder_id=? AND tenant_id=? AND workspace_id=?",
                  (str(folder_id), tenant_id, workspace_id))
    if files and not confirm:
        raise KnowledgeError(
            f"文件夹内有 {len(files)} 个文件，确认后连同文件一起删除", "folder_not_empty",
            file_count=len(files))
    display_name = str(folder.get("orig_name") or folder.get("name") or "")
    deleted_files = [row["id"] for row in files]
    stored_names = {str(row.get("stored_name") or "") for row in files}
    stored_names.discard("")
    with db.session() as c:
        c.execute("DELETE FROM knowledge_file WHERE folder_id=? AND tenant_id=? AND workspace_id=?",
                  (str(folder_id), tenant_id, workspace_id))
        c.execute("DELETE FROM knowledge_folder WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (str(folder_id), tenant_id, workspace_id))
        # P2-04：文件夹删除与审计同事务；审计失败→回滚删除并报错。
        _audit_tx(c, user, "knowledge.folder_delete", str(folder_id),
                  {"name": display_name, "file_count": len(deleted_files),
                   "file_ids": deleted_files[:50],
                   "purged_from_recycle": bool(purged),
                   "tenant_id": tenant_id, "workspace_id": workspace_id})
    for stored in stored_names:
        _unlink_stored(tenant_id, workspace_id, stored, exclude_ids=deleted_files)
    return {"ok": True, "deleted": str(folder_id), "deleted_files": len(deleted_files)}


def _audit_tx(c, user: dict | None, action: str, obj: str, after: dict) -> None:
    """P2-04：在调用方事务连接内写审计（失败向上抛，由事务回滚业务写）。"""
    _audit_svc.log_in_tx(c, actor=_uid(user) or "system", action=action,
                         object_=str(obj or ""), after=json.dumps(after, ensure_ascii=False))


# ---------------------------------------------------------------------------
# 查看：inline / 安全下载
# ---------------------------------------------------------------------------
def resolve_view(user: dict | None, file_id: str) -> dict:
    """返回查看所需信息（路径/文件名/mime/是否 inline）；不存在/越权 404。"""
    _ensure_role(user)
    tenant_id, workspace_id = _ctx_scope(user)
    row = get_file(file_id, tenant_id, workspace_id)
    if not row:
        raise KnowledgeError("文件不存在或不属于当前空间", "not_found")
    name = str(row.get("filename") or "file")
    safe_name = _safe_filename(name)
    ext = os.path.splitext(safe_name)[1].lower()
    mime = str(row.get("mime") or "") or MIME_BY_EXT.get(ext, "application/octet-stream")
    path = _file_path(tenant_id, workspace_id, str(row.get("stored_name") or ""))
    if not path.exists() or not path.is_file():
        raise KnowledgeError("文件已丢失（存储中不存在）", "not_found")
    inline = ext == ".pdf" or ext in IMAGE_EXT or ext in TEXT_EXT
    return {"file": _public_file(row), "path": path, "filename": safe_name,
            "mime": mime, "inline": inline, "ext": ext}


def content_disposition(filename: str, inline: bool) -> str:
    """RFC 5987 安全 Content-Disposition，避免中文名/引号头注入。"""
    from urllib.parse import quote
    kind = "inline" if inline else "attachment"
    ascii_name = re.sub(r"[^A-Za-z0-9._-]", "_", filename) or "file"
    return f'{kind}; filename="{ascii_name}"; filename*=UTF-8\'\'{quote(filename)}'


# ---------------------------------------------------------------------------
# multipart/form-data 解析（stdlib，无第三方依赖；服务端其余上传走 base64 JSON）
# ---------------------------------------------------------------------------
def parse_multipart(raw: bytes, content_type: str) -> tuple:
    """解析 multipart/form-data；返回 (fields, files)。

    files: [{"name","filename","content_type","data"}]
    边界值/格式非法时抛 KnowledgeError(invalid_request)，不静默吞。
    """
    ct = str(content_type or "")
    if "multipart/form-data" not in ct.lower():
        raise KnowledgeError("上传需要 multipart/form-data", "invalid_request")
    m = re.search(r'boundary=(?:"([^"]+)"|([^;]+))', ct, re.I)
    boundary = (m.group(1) or m.group(2) or "").strip() if m else ""
    if not boundary or len(boundary) > 200:
        raise KnowledgeError("multipart boundary 缺失或非法", "invalid_request")
    delim = b"--" + boundary.encode("latin-1", "ignore")
    if delim not in raw:
        raise KnowledgeError("multipart 请求体格式非法", "invalid_request")
    fields, files = {}, []
    segments = raw.split(delim)
    if len(segments) > MAX_PARTS + 2:
        raise KnowledgeError("multipart 分片过多", "invalid_request")

    def _dec(value: bytes) -> str:
        """multipart 头默认 UTF-8；非 UTF-8 回退 latin-1（不静默丢字符）。"""
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("latin-1", "replace")

    for seg in segments[1:]:
        if seg.startswith(b"--"):
            break
        if seg.startswith(b"\r\n"):
            seg = seg[2:]
        if seg.endswith(b"\r\n"):
            seg = seg[:-2]
        head, sep, body = seg.partition(b"\r\n\r\n")
        if not sep:
            continue
        headers = {}
        for line in head.split(b"\r\n"):
            if b":" not in line:
                continue
            k, _, v = line.partition(b":")
            headers[k.decode("latin-1").strip().lower()] = _dec(v.strip())
        disp = headers.get("content-disposition", "")
        name_m = re.search(r'(?:^|;)\s*name="([^"]*)"', disp)
        fname_m = re.search(r'(?:^|;)\s*filename="([^"]*)"', disp)
        fname_star = re.search(r"filename\*=UTF-8''([^;]+)", disp, re.I)
        if not name_m:
            continue
        name = name_m.group(1)
        if fname_star:
            from urllib.parse import unquote
            fname = unquote(fname_star.group(1))
        else:
            fname = fname_m.group(1) if fname_m is not None else None
        if fname is not None:
            files.append({"name": name, "filename": fname,
                          "content_type": headers.get("content-type", ""),
                          "data": body})
        else:
            try:
                fields[name] = body.decode("utf-8", "replace")
            except Exception:
                fields[name] = ""
    return fields, files
