# -*- coding: utf-8 -*-
"""格式/流程类机制的确定性检查。

只对明确可判定的模式产出带原文的 fail；不代替模型做语义判断。
用于补足模型在日期、数量一致性、空字段上的漏判。
"""
from __future__ import annotations
import datetime as _dt
import re

DATE_RE = re.compile(r"(\d{4})年(\d{1,2})月(\d{1,2})日")
ISO_RE = re.compile(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})")
COUNT_RE = re.compile(r"共划分\s*(\d+)\s*个标段")
EMPTY_FIELD_RE = re.compile(r"(网址|地址|链接|联系方式|报价|投标保证金|保证金|付款方式|质保金|交货期|工期)\s*[:：]\s*(?:[。；;]|$)", re.M)

# 这些检查对应的机制点；未在本次点位集合中的不补。
DATE_POINTS = {"P01-O05", "P01-O08", "C09-001", "C09-002", "C09-003"}
COUNT_POINTS = {"P01-O01", "P01-O10", "F02-006", "C08-001", "C08-002"}
EMPTY_POINTS = {"P01-O02", "P01-O03", "P01-O07"}
A02_POINTS = {"A02-003", "A02-004", "A02-006"}
C0803_POINTS = {"C08-003"}
INVERT_POINTS = {"C09-002", "C09-003", "P01-O08"}


def _scope(point: dict | None, kind: str) -> bool:
    """检查必须由点位判据支持，不能只按 ID 全局触发。"""
    if not point:
        return True
    p = point or {}
    txt = " ".join(str(p.get(k) or "") for k in ("name", "point", "criterion", "required_evidence",
                                                  "check_steps", "prompt")).strip()
    if not txt:
        return True
    if kind == "date_invalid":
        return any(k in txt for k in ("日期和时间值", "有效且可解析", "公历", "闰年", "月份、日期"))
    if kind == "invert":
        return any(k in txt for k in ("期限", "时点", "日期", "工期", "有效期", "起算", "覆盖"))
    if kind == "count":
        return any(k in txt for k in ("重复内容", "标段数量", "同一文件出现多个标段", "重复项", "重复计数", "报价数量", "数量"))
    if kind == "empty":
        return any(k in txt for k in ("要素属性", "格式要素", "可读", "读取", "格式", "结构", "属性值", "获取值", "要素"))
    return True


def _date(y, m, d):
    try:
        return _dt.date(int(y), int(m), int(d))
    except Exception:
        return None


def _span(text, start, end, pad=18):
    return str(text)[max(0, start - pad):min(len(text), end + pad)].strip().replace("\n", " ")[:220]


def _mk(pid, quote, reason, review=False):
    return {"id": pid, "code": pid, "state": "insufficient" if review else "fail",
            "confidence": 1.0, "quote": quote,
            "rationale": "确定性检查：" + reason + ("；转人工复核" if review else ""),
            "engine": "mechanism_check",
            "gate": {"passed": False, "reason": "deterministic_check_requires_review" if review else "quote_in_document"}}


def run(text: str, point_ids: set[str] | list[dict] | None = None) -> dict:
    """返回 pid -> finding；只对本次选中点补结果。"""
    t = str(text or "")
    if isinstance(point_ids, (list, tuple)):
        pmap = {str((p or {}).get("id") or (p or {}).get("code") or ""): p for p in point_ids}
        want = set(pmap)
    else:
        pmap = {}
        want = set(point_ids or ())
    out = {}
    # 1) 非法日期 / 倒置区间
    for m in DATE_RE.finditer(t):
        d = _date(m.group(1), m.group(2), m.group(3))
        if d is None:
            for pid in (DATE_POINTS & want):
                if _scope(pmap.get(pid), "date_invalid"):
                    out.setdefault(pid, _mk(pid, _span(t, m.start(), m.end()), f"日期 {m.group(0)} 不是有效日历日期"))
    for m in ISO_RE.finditer(t):
        d = _date(m.group(1), m.group(2), m.group(3))
        if d is None:
            for pid in (DATE_POINTS & want):
                if _scope(pmap.get(pid), "date_invalid"):
                    out.setdefault(pid, _mk(pid, _span(t, m.start(), m.end()), f"日期 {m.group(0)} 不是有效日历日期"))
    for m in re.finditer(r"(\d{4}年\d{1,2}月\d{1,2}日)[^。；;\n]{0,18}(?:至|到|—|-)(\d{4}年\d{1,2}月\d{1,2}日)", t):
        a = DATE_RE.match(m.group(1)); b = DATE_RE.match(m.group(2))
        if not a or not b: continue
        da, db = _date(*a.groups()), _date(*b.groups())
        if da and db and da > db:
            for pid in (INVERT_POINTS & want):
                if _scope(pmap.get(pid), "invert"):
                    out.setdefault(pid, _mk(pid, _span(t, m.start(), m.end()), f"起止日期倒置：{m.group(1)} 晚于 {m.group(2)}"))
    # 2) 标段数量前后矛盾
    counts = [(int(m.group(1)), m) for m in COUNT_RE.finditer(t)]
    vals = {n for n, _ in counts}
    if len(vals) > 1:
        m = counts[0][1]
        for pid in (COUNT_POINTS & want):
            if _scope(pmap.get(pid), "count"):
                out.setdefault(pid, _mk(pid, _span(t, m.start(), m.end()), f"同一文件出现多个标段数量：{sorted(vals)}"))
    # 3) 空 URL/字段
    for m in EMPTY_FIELD_RE.finditer(t):
        for pid in (EMPTY_POINTS & want):
            if _scope(pmap.get(pid), "empty"):
                out.setdefault(pid, _mk(pid, _span(t, m.start(), m.end()), f"{m.group(1)}为空"))
    # 4) 安全生产许可证被延后到中标后（A02-003）
    if A02_POINTS & want:
        for m in re.finditer(r"安全生产许可证[^。；;\n]{0,50}(?:中标后|中标后再|无须投标时|不必投标时)", t):
            for pid in (A02_POINTS & want):
                if _scope(pmap.get(pid), "empty") or "安全生产许可证" in str((pmap.get(pid) or {}).get("name") or ""):
                    out.setdefault(pid, _mk(pid, _span(t, m.start(), m.end()), "安全生产许可证有效期被延后到中标后"))
    # 5) 同一 MW 对应多个 MWh（C08-002 分系统能量汇总不一致）
    if "C08-002" in want:
        pairs = re.findall(r"(\d+(?:\.\d+)?)\s*MW\s*/\s*(\d+(?:\.\d+)?)\s*MWh", t)
        by_mw = {}
        for mw, mwh in pairs:
            by_mw.setdefault(mw, set()).add(mwh)
        for mw, vals in by_mw.items():
            if len(vals) > 1:
                _m = re.search(r"\d+(?:\.\d+)?\s*MW\s*/\s*\d+(?:\.\d+)?\s*MWh", t)
                if _m:
                    out.setdefault("C08-002", _mk("C08-002", _span(t, _m.start(), _m.end()),
                                                  f"同一 {mw}MW 对应不同储能容量 {sorted(vals)}"))
    # 6) 保证金大写与数字金额不一致（C08-003）
    if C0803_POINTS & want:
        _cn = {"壹":1,"贰":2,"叁":3,"肆":4,"伍":5,"陆":6,"柒":7,"捌":8,"玖":9}
        for _m in re.finditer(r"保证金[^。；;\n]{0,80}?([壹贰叁肆伍陆柒捌玖])万元[^。；;\n]{0,40}?[¥￥]\s*([0-9][0-9,，]*)", t):
            _n = _cn.get(_m.group(1), 0) * 10000
            try: _num = int(_m.group(2).replace(",", "").replace("，", ""))
            except Exception: continue
            if _n and _num and _n != _num:
                for pid in (C0803_POINTS & want):
                    if _scope(pmap.get(pid), "count") or pid == "C08-003" or "保证金" in str((pmap.get(pid) or {}).get("name") or ""):
                        out.setdefault(pid, _mk(pid, _span(t, _m.start(), _m.end()),
                                               f"保证金大写 {_m.group(1)}万元 与数字 {_num} 不一致"))
    return out


def augment(results: list[dict], points: list[dict], text: str) -> tuple[list[dict], dict]:
    """把确定性 fail 合并进结果；只替换同 code，不添加本次未选中的点。"""
    got = run(text, list(points or []))
    if not got:
        return results, {"checked": 0, "added": 0}
    by = {str(r.get("code") or r.get("id") or ""): r for r in results or []}
    added = 0
    for pid, r in got.items():
        old = by.get(pid)
        if old:
            # 模型已经 fail 则保留模型的语义理由；否则用确定性证据替代 pass/insufficient
            if old.get("state") == "fail":
                continue
            old.update({k: v for k, v in r.items() if k not in ("name", "severity")})
        else:
            results.append(r); by[pid] = r
        added += 1
    return results, {"checked": len(got), "added": added}
