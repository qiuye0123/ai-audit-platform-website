"""解析产物单一缓存 + 统一解析入口：agent-parse 产出一次，主链其他环节复用。

不替代 deepparse；它负责把 agent-parse 的真实解析结果交给审核链路，
避免同一文件被 upload/preprocess/review 反复解析出不同结果。

L86（2026-11-24，外部复验报告 HEAD96eb3be §7 P0-1 事实身份丢失）：
- 事实合并键从「kind + value + object」升级为 **对象 + 单位 + 位置 + 来源**：
  同对象同值但不同单位（g vs kg）、不同页码、不同 sheet/行、不同字符区间或不同
  抽取来源的两条事实不再被静默合并成一条，事实身份（定位/单位/来源）得以保留；
- 缓存键从「真实路径 + mtime + size」升级为再加 **ctime/inode + 内容 sha256 +
  可选显式 version**：同路径、同尺寸、同秒重写不再命中旧解析产物（内容版本失效）。
统一开关 ``RULEPROOF_FACT_IDENTITY_FIX``（默认 1）；=0 时合并键与缓存键逐字节回退
到历史行为（旧键仅 path/mtime/size 与 kind/value/object），供 A/B 与回滚。

L145（2026-11-25，L134 六视角⑤ Top1「统一解析入口 + 内容寻址解析缓存」）：
- ``parse_document(path)`` 是 ``deepparse.parse_document`` 的**统一缓存入口**：
  键 = 真实路径 + size + mtime_ns + 内容 sha256 + 解析器指纹（+可选 version）；
- 内存 + 磁盘两级缓存。磁盘缓存在 ``/tmp`` 下、默认目录
  ``/tmp/ruleproof_parse_cache``，可用 ``RULEPROOF_PARSE_CACHE_DIR`` 改；
- 开关 ``RULEPROOF_PARSE_CACHE``（默认 1）；=0 时逐字节回退到直连
  ``deepparse.parse_document``（不读不写任何缓存）；
- 缓存命中返回**新建的 ParsedDoc**（不是共享可变对象）；命中内容与冷解析
  ``to_dict()`` 逐字段一致；
- 可清理：``clear(path)``（含该路径磁盘条目）、``clear_persistent()``（磁盘全部/
  指定路径）、写入时按条数/保留期自动裁剪；
- 可观测：``stats()`` 给 parse_calls / cache_hit / cache_miss / disk_hit / 内存命中
  / 磁盘写失败等计数；可选 ``RULEPROOF_PARSE_CACHE_STATS=<file>`` 在进程退出时
  落一份统计 JSON（只含计数/路径/哈希，**不含文件内容**）。
"""
import copy
import gzip
import hashlib
import json
import logging
import os
import tempfile
import threading
import time
import unicodedata

_log = logging.getLogger(__name__)

_LOCK = threading.RLock()
_CACHE = {}
_MAX = 64

# 内容版本指纹：按「stat 签名」记忆，同一文件版本只读一次；签名变化（含 ctime/inode）
# 即视为新版本重新计算，因此同尺寸同 mtime 的重写也能失效。
_HASH_MEMO = {}
_HASH_MEMO_MAX = 256
_HASH_CHUNK = 1024 * 1024

# 事实身份键的位置字段（L86 要求：sheet/page/row/char span + 来源）。
# 按真实抽取器的字段命名兼容：deepparse.Fact（anchor/char_start/char_end）、
# rexec.NumFact（sheet/row/anchor）、facts.make（anchor/start）、表格抽取（cell/table）。
_PAGE_KEYS = ("page", "page_no", "page_index", "page_number", "pdf_page")
_SHEET_KEYS = ("sheet", "sheet_name", "table", "table_name")
_ROW_KEYS = ("row", "row_no", "row_index", "line", "line_no", "cell", "cell_ref")
_SECTION_KEYS = ("section_kind", "section", "locator", "bbox", "rect")
_SPAN_PAIRS = (("char_start", "char_end"), ("start", "end"),
               ("span_start", "span_end"), ("offset", "offset_end"))
_SOURCE_KEYS = ("source", "evidence_source", "ocr_engine", "ocr_tier",
                "vision_advisory", "extractor", "agent", "unit_source")


def _fact_identity_fix_on() -> bool:
    """L86 开关：默认 1；=0/false/off/no 回退历史行为。"""
    try:
        return str(os.environ.get("RULEPROOF_FACT_IDENTITY_FIX", "1")).strip().lower() \
            not in ("0", "false", "off", "no")
    except Exception:
        return True


def _txt(v) -> str:
    return "" if v is None else str(v).strip()


def _norm_obj(v) -> str:
    """对象/指标名归一：NFKC + 去首尾空白（只归一写法，不做语义映射）。"""
    raw = _txt(v)
    if not raw:
        return ""
    try:
        return unicodedata.normalize("NFKC", raw).strip()
    except Exception:
        return raw


def _norm_unit(u) -> str:
    """单位写法归一（身份键用）：NFKC + 去首尾/内部空白。

    不做大小写折叠：``MPa``/``mPa`` 是不同量级单位，不能因为折叠而合并成一条事实。
    大小写不同的同一单位（kg/KG）保持两条 —— 宁可多留一条可定位事实，也不丢身份。
    """
    raw = _txt(u)
    if not raw:
        return ""
    try:
        return unicodedata.normalize("NFKC", raw).strip()
    except Exception:
        return raw


def _norm_value(v) -> str:
    """值归一（仅用于身份判断，不改变事实里的原始 value）。

    数值统一成最短十进制表示：``5`` 与 ``5.0`` 视为同一数值；NaN/Inf 保留字符串。
    非数值（日期/文本/百分比原样）保持原样。
    """
    if isinstance(v, bool):
        return str(v)
    try:
        f = float(str(v).replace(",", "")) if not isinstance(v, (int, float)) else float(v)
    except (TypeError, ValueError, OverflowError):
        return _txt(v)
    if f != f or f in (float("inf"), float("-inf")):
        return str(f)
    if f == int(f) and abs(f) < 1e15:
        return str(int(f))
    return format(f, ".17g")


def _norm_span(key: str, v) -> str:
    """位置字段归一：dict/list 用稳定 JSON（排序键），保证可哈希且可复算。"""
    if isinstance(v, dict):
        try:
            return json.dumps(v, sort_keys=True, ensure_ascii=False, default=str)
        except Exception:
            return str(sorted((str(k), str(x)) for k, x in v.items()))
    if isinstance(v, (list, tuple)):
        try:
            return json.dumps(list(v), sort_keys=True, ensure_ascii=False, default=str)
        except Exception:
            return "|".join(_txt(x) for x in v)
    return _txt(v)


def _fact_location(fact: dict) -> tuple:
    """事实位置标记：page/sheet/row/char span + 结构段位。

    返回形如 ``("page", "2", "sheet", "工艺参数", "row", "7", "anchor", "p2",
    "span", "12", "20", "section", "table")`` 的可哈希元组；没有位置信息的字段不出现。
    """
    parts = []

    def _pick(keys, label):
        for k in keys:
            if fact.get(k) not in (None, ""):
                parts.extend((label, _norm_span(k, fact.get(k))))
                return

    _pick(_PAGE_KEYS, "page")
    _pick(_SHEET_KEYS, "sheet")
    _pick(_ROW_KEYS, "row")
    _pick(("anchor",), "anchor")
    for start_k, end_k in _SPAN_PAIRS:
        if fact.get(start_k) not in (None, "") or fact.get(end_k) not in (None, ""):
            parts.extend(("span", _norm_span(start_k, fact.get(start_k)),
                          _norm_span(end_k, fact.get(end_k))))
            break
    _pick(_SECTION_KEYS, "section")
    return tuple(parts)


def _fact_source(fact: dict) -> tuple:
    """事实来源标记：抽取器/证据来源/OCR 档位/单位来源等（只收非空值）。"""
    parts = []
    for k in _SOURCE_KEYS:
        if fact.get(k) not in (None, ""):
            parts.extend((k, _norm_span(k, fact.get(k))))
    return tuple(parts)


def fact_identity(fact: dict) -> tuple:
    """L86 事实身份键：kind + value + 对象 + 单位 + 位置(sheet/page/row/char span) + 来源。

    同对象同值但单位不同（5 g / 5 kg）、页码不同、行/字符区间不同或抽取来源不同的
    两条事实，身份不同 → 不得合并；完全相同的重复抽取仍按同一身份去重。
    """
    if not isinstance(fact, dict):
        return ("", "", "", "", (), ())
    return (_norm_obj(fact.get("kind")), _norm_value(fact.get("value")),
            _norm_obj(fact.get("object")), _norm_unit(fact.get("unit")),
            _fact_location(fact), _fact_source(fact))


def _legacy_fact_identity(fact: dict) -> tuple:
    """历史合并键（L86 =0 回退口径）：仅 kind/value/object。"""
    if not isinstance(fact, dict):
        return ("", "", "")
    return (str(fact.get("kind") or ""), str(fact.get("value") or ""),
            str(fact.get("object") or ""))


def _fact_key(fact: dict) -> tuple:
    if _fact_identity_fix_on():
        return fact_identity(fact)
    return _legacy_fact_identity(fact)


def _stat_sig(path: str):
    """缓存 stat 签名：真实路径 + mtime/size + ctime/inode（同秒同尺寸重写可区分）。"""
    real = os.path.realpath(path)
    st = os.stat(real)
    return (real, int(st.st_mtime_ns), int(st.st_size),
            int(st.st_ctime_ns), int(getattr(st, "st_ino", 0) or 0))


def _content_sha256(real: str, sig: tuple) -> str:
    """文件内容 sha256（按 stat 签名记忆，同版本只读一次）；失败返回空串（不猜）。"""
    cached = _HASH_MEMO.get(sig)
    if cached is not None:
        return cached
    h = hashlib.sha256()
    try:
        with open(real, "rb") as f:
            for chunk in iter(lambda: f.read(_HASH_CHUNK), b""):
                h.update(chunk)
        digest = h.hexdigest()
    except OSError:
        digest = ""
    if len(_HASH_MEMO) >= _HASH_MEMO_MAX:
        _HASH_MEMO.clear()
    _HASH_MEMO[sig] = digest
    return digest


def _legacy_stat_key(path: str):
    """历史缓存键（L86 =0 回退口径）：仅 真实路径/mtime/size。"""
    try:
        real = os.path.realpath(path)
        st = os.stat(real)
        return real, int(st.st_mtime), int(st.st_size)
    except Exception:
        return os.path.realpath(path or ""), 0, 0


def _key(path: str, version=None):
    """缓存键。

    L86 修复开启（默认）：``(real, mtime_ns, size, ctime_ns, ino, version, sha256)``；
    ``version`` 为调用方可选的显式版本（如冻结 manifest 内容版本），缺省空串。
    L86 =0：历史 ``(real, mtime, size)``，逐字节回退旧缓存命中口径。
    """
    if not _fact_identity_fix_on():
        return _legacy_stat_key(path)
    ver = "" if version is None else str(version)
    try:
        sig = _stat_sig(path)
    except Exception:
        return (os.path.realpath(path or ""), 0, 0, 0, 0, ver, "")
    return sig + (ver, _content_sha256(sig[0], sig))


def put(path: str, parsed: dict, version=None) -> None:
    if not path or not isinstance(parsed, dict):
        return
    with _LOCK:
        _CACHE[_key(path, version)] = parsed
        if len(_CACHE) > _MAX:
            for k in list(_CACHE)[:max(1, len(_CACHE) - _MAX)]:
                _CACHE.pop(k, None)
    # L145：agent-parse 的 parsed dict 同步进统一解析缓存（内存 + 磁盘），使后续
    # parse_bridge.parse_document 复用同一次真实解析，而不是再完整解析一遍。
    # 失败只降级（不影响 agent-parse 主链），不吞业务异常。
    try:
        if not parse_cache_enabled():
            return
        doc_dict = parsed.get("doc")
        if not isinstance(doc_dict, dict):
            return
        if not (doc_dict.get("text") or doc_dict.get("sections")):
            return
        info = parse_cache_key(path, version)
        if info is None:
            return
        _memo_put(_parse_key_tuple(info), doc_dict)
        _disk_write(info, doc_dict)
        _bump("put_persisted")
    except Exception:
        _log.debug("parse_bridge.put 写统一解析缓存失败 path=%s", path, exc_info=True)


def get(path: str, version=None):
    with _LOCK:
        return _CACHE.get(_key(path, version))


def text(path: str, version=None) -> str:
    p = get(path, version)
    if not p:
        return ""
    try:
        return p.get("doc", {}).get("text", "") or ""
    except Exception:
        return ""


def merge_facts(path: str, facts: list, version=None) -> None:
    """把新抽取事实合并进缓存（L86：按「对象+单位+位置+来源」身份去重）。"""
    p = get(path, version)
    if not isinstance(p, dict) or not facts:
        return
    fix_on = _fact_identity_fix_on()
    old = list(p.get("facts") or [])
    seen = {_fact_key(x) for x in old if isinstance(x, dict)}
    added = 0
    for x in facts:
        if not isinstance(x, dict):
            continue
        k = _fact_key(x)
        if k not in seen:
            old.append(x); seen.add(k); added += 1
    p["facts"] = old
    p["fact_count"] = len(old)
    if fix_on:
        # 可复核标记：本缓存条目的合并口径版本（=0 不写，保持历史产物逐字节回退）。
        p["fact_identity"] = "object+unit+location+source/v1"
        p["fact_identity_added"] = int(p.get("fact_identity_added") or 0) + added


def facts(path: str, version=None) -> list:
    p = get(path, version)
    return (p.get("facts") or []) if isinstance(p, dict) else []


def clear(path: str = "", version=None) -> None:
    """清空缓存；给 path 时删除该路径的所有版本（内容/版本键都清）。

    L145：同一路径的 parsed-doc 内存/磁盘缓存一并清（给 path 时）。
    不给 path = 只清进程内缓存（磁盘用 ``clear_persistent()`` 显式清）。
    """
    with _LOCK:
        if path:
            real = os.path.realpath(path)
            for k in list(_CACHE):
                if isinstance(k, tuple) and k and k[0] == real:
                    _CACHE.pop(k, None)
        else:
            _CACHE.clear()
            _HASH_MEMO.clear()
    with _PARSE_LOCK:
        if path:
            real = os.path.realpath(path)
            for k in list(_PARSE_MEMO):
                if isinstance(k, tuple) and k and k[0] == real:
                    _PARSE_MEMO.pop(k, None)
        else:
            _PARSE_MEMO.clear()
    if path:
        try:
            clear_persistent(path)
        except Exception:
            _log.debug("parse_bridge.clear 清磁盘解析缓存失败 path=%s", path, exc_info=True)


# ================================================================ L145 统一解析入口
# 内容寻址持久化解析缓存：deepparse.parse_document 的唯一缓存入口（L134 Top1）。
# 设计口径见模块 docstring「L145」。

_PARSE_CACHE_FORMAT = 1
_PARSE_CACHE_DEFAULT_DIR = "ruleproof_parse_cache"
_PARSE_CACHE_MAX_ENTRIES = 256          # 磁盘条目上限（超出按 mtime 最旧裁剪）
_PARSE_CACHE_TTL_HOURS = 168            # 磁盘条目默认保留期（7 天）
_PARSE_MEMO_MAX = 32                    # 进程内 parsed-doc 缓存条数
# 影响解析结果的开关：任一变化 → 解析器指纹变化 → 磁盘缓存自动失效
_PARSE_SWITCHES = (
    "RULEPROOF_HIDDEN_TEXT_GUARD", "RULEPROOF_DOCX_HEADER_FACTS",
    "RULEPROOF_MD_ARTIFACT_CLEAN", "RULEPROOF_PDF_HEADER_FACTS",
    "RULEPROOF_XLSX_HEADER_FACTS", "RULEPROOF_PARSE_SKIP_HIDDEN_SHEET",
)
_PARSE_PARSER_MODULE = os.path.join("app", "engine", "deepparse.py")

_PARSE_LOCK = threading.RLock()
_PARSE_MEMO = {}
_PARSER_FP_CACHE = {}
_PARSE_STATS = {
    "parse_calls": 0,       # 真正执行 deepparse.parse_document 的次数
    "cache_hit": 0,
    "cache_miss": 0,
    "memory_hit": 0,
    "disk_hit": 0,
    "legacy_hit": 0,        # 复用同进程 agent-parse parsed dict（不重解析）
    "put_persisted": 0,     # put() 同步进统一解析缓存的次数
    "cache_bypass": 0,      # 文件不可读/空哈希：不进缓存直接交 deepparse
    "disabled": 0,          # RULEPROOF_PARSE_CACHE=0
    "disk_writes": 0,
    "disk_errors": 0,
    "disk_invalidations": 0,
    "pruned": 0,
    "parse_ms_total": 0.0,
    "hit_ms_total": 0.0,
}
_STATS_FILE_STATE = {"registered": False, "target": ""}


def _bump(name, delta=1):
    with _PARSE_LOCK:
        cur = _PARSE_STATS.get(name, 0)
        _PARSE_STATS[name] = (round(cur + delta, 3) if isinstance(cur, float)
                              else cur + delta)


def parse_cache_enabled() -> bool:
    """L145 开关 RULEPROOF_PARSE_CACHE（默认 1）；=0/false/off/no → 直连 deepparse。"""
    try:
        return str(os.environ.get("RULEPROOF_PARSE_CACHE", "1")).strip().lower() \
            not in ("0", "false", "off", "no")
    except Exception:
        return True


def parse_cache_dir() -> str:
    """磁盘缓存目录：RULEPROOF_PARSE_CACHE_DIR，默认 <临时目录>/ruleproof_parse_cache。"""
    try:
        d = str(os.environ.get("RULEPROOF_PARSE_CACHE_DIR") or "").strip()
    except Exception:
        d = ""
    return d or os.path.join(tempfile.gettempdir(), _PARSE_CACHE_DEFAULT_DIR)


def _effective_switch(name: str) -> str:
    """解析开关的**有效值**归一（未设置与显式默认值等价，避免无谓 cache miss）。"""
    try:
        return "1" if str(os.environ.get(name, "1")).strip().lower() \
            not in ("0", "false", "off", "no") else "0"
    except Exception:
        return "1"


def _parser_fingerprint() -> str:
    """解析器指纹：deepparse 源码 sha256 + 解析相关开关 + 可选后端可用性。

    解析器代码/开关/后端（docling/mineru/pymupdf/pypdf…）任一变化都改变指纹 →
    磁盘缓存 miss，避免用旧解析器的产物回答新解析器的问题。
    按「开关有效值组合」记忆（同进程运行期改开关也能立即反映到键上；
    未设置与显式 "1" 等价，不会因写法差异产生重复缓存）。
    """
    memo_key = tuple(_effective_switch(k) for k in _PARSE_SWITCHES)
    fp = _PARSER_FP_CACHE.get(memo_key)
    if fp:
        return fp
    h = hashlib.sha256()
    try:
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        with open(os.path.join(root, _PARSE_PARSER_MODULE), "rb") as f:
            h.update(f.read())
    except OSError:
        h.update(b"parser_module_unreadable")
    parts = ["%s=%s" % (k, v) for k, v in zip(_PARSE_SWITCHES, memo_key)]
    try:
        import importlib.util
        for mod in ("docling", "mineru", "fitz", "pypdf", "pypdfium2", "docx", "openpyxl"):
            try:
                parts.append("%s=%d" % (mod, 1 if importlib.util.find_spec(mod) else 0))
            except Exception:
                parts.append("%s=?" % mod)
    except Exception:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    h.update("|".join(parts).encode("utf-8", "replace"))
    fp = h.hexdigest()
    if len(_PARSER_FP_CACHE) >= 8:
        _PARSER_FP_CACHE.clear()
    _PARSER_FP_CACHE[memo_key] = fp
    return fp


def parse_cache_key(path, version=None):
    """内容寻址键（dict）：path/size/mtime_ns/sha256/parser/version；不可读返回 None。

    sha256 只进缓存键与日志前缀，**不缓存文件内容本身以外的任何原文**。
    """
    try:
        sig = _stat_sig(str(path))
    except Exception:
        return None
    sha = _content_sha256(sig[0], sig)
    if not sha:
        return None
    return {"path": sig[0], "size": int(sig[2]), "mtime_ns": int(sig[1]),
            "sha256": sha, "parser": _parser_fingerprint(),
            "version": "" if version is None else str(version)}


def _parse_key_tuple(info) -> tuple:
    return (info["path"], int(info["size"]), int(info["mtime_ns"]),
            info["sha256"], info["parser"], info["version"])


def _disk_name(info) -> str:
    raw = "%s|%s|%s|%s|%s|%s" % (info["path"], info["size"], info["mtime_ns"],
                                 info["sha256"], info["parser"], info["version"])
    return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest() + ".json.gz"


def _disk_path(info) -> str:
    return os.path.join(parse_cache_dir(), _disk_name(info))


def _doc_from_dict(doc_dict):
    """dict → **新建** ParsedDoc；每次命中都新建，不返回共享可变对象。失败返回 None。"""
    if not isinstance(doc_dict, dict):
        return None
    try:
        from dataclasses import fields as _fields

        from ..engine import deepparse as _dp
    except Exception:
        return None
    try:
        allowed = {f.name for f in _fields(_dp.ParsedDoc)}
        sec_allowed = {f.name for f in _fields(_dp.Section)}
        kw = {k: v for k, v in doc_dict.items() if k in allowed}
        secs = []
        for s in kw.get("sections") or []:
            if isinstance(s, _dp.Section):
                secs.append(s)
            elif isinstance(s, dict):
                secs.append(_dp.Section(**{k: v for k, v in s.items() if k in sec_allowed}))
        kw["sections"] = secs
        for k in ("page_provenance", "ocr_capability", "header_footer_evidence"):
            if k in kw and isinstance(kw[k], dict):
                kw[k] = copy.deepcopy(kw[k])
        for k in ("skipped_sheets", "skipped_hidden_text"):
            if k in kw and isinstance(kw[k], (list, tuple)):
                kw[k] = copy.deepcopy(list(kw[k]))
        return _dp.ParsedDoc(**kw)
    except Exception:
        _log.debug("parse_cache 重建 ParsedDoc 失败", exc_info=True)
        return None


def _memo_put(key, doc_dict):
    with _PARSE_LOCK:
        _PARSE_MEMO[key] = doc_dict
        if len(_PARSE_MEMO) > _PARSE_MEMO_MAX:
            for k in list(_PARSE_MEMO)[:max(1, len(_PARSE_MEMO) - _PARSE_MEMO_MAX)]:
                _PARSE_MEMO.pop(k, None)


def _record_hit(source: str, info: dict, t0: float) -> None:
    ms = (time.perf_counter() - t0) * 1000.0
    with _PARSE_LOCK:
        _PARSE_STATS["cache_hit"] += 1
        _PARSE_STATS[source + "_hit"] += 1
        _PARSE_STATS["hit_ms_total"] = round(_PARSE_STATS["hit_ms_total"] + ms, 3)
    # 日志只含文件名/大小/哈希前缀/耗时，不含正文（审计/日志不得含文件内容）
    _log.info("parse_cache hit source=%s file=%s bytes=%s sha=%s ms=%.1f",
              source, os.path.basename(info["path"]), info["size"],
              info["sha256"][:16], ms)


def _disk_write(info: dict, doc_dict) -> bool:
    """原子写磁盘缓存（gzip JSON）；失败只降级，不影响调用方。"""
    if not isinstance(doc_dict, dict):
        return False
    d = parse_cache_dir()
    try:
        os.makedirs(d, exist_ok=True)
        payload = {"format": _PARSE_CACHE_FORMAT, "key": info,
                   "created_at": time.time(), "doc": doc_dict}
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"),
                         default=str).encode("utf-8")
        blob = gzip.compress(raw, compresslevel=3)
        fd, tmp = tempfile.mkstemp(prefix=".tmp_parse_", dir=d)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(blob)
            os.replace(tmp, _disk_path(info))
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    except Exception:
        _bump("disk_errors")
        _log.debug("parse_cache 写磁盘失败 dir=%s", d, exc_info=True)
        return False
    _bump("disk_writes")
    _prune_disk(d)
    return True


def _disk_read(info: dict):
    """读磁盘缓存；键任一维度不匹配即视为 miss（不返回可疑内容）。"""
    fn = _disk_path(info)
    if not os.path.isfile(fn):
        return None
    try:
        with gzip.open(fn, "rt", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception:
        _bump("disk_errors")
        try:
            os.remove(fn)
        except OSError:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        return None
    if not isinstance(payload, dict) or payload.get("format") != _PARSE_CACHE_FORMAT:
        _bump("disk_invalidations")
        return None
    stored = payload.get("key")
    if not isinstance(stored, dict):
        _bump("disk_invalidations")
        return None
    for k in ("path", "size", "mtime_ns", "sha256", "parser", "version"):
        if stored.get(k) != info.get(k):
            _bump("disk_invalidations")
            return None
    doc = payload.get("doc")
    if not isinstance(doc, dict):
        _bump("disk_invalidations")
        return None
    try:
        os.utime(fn, None)  # LRU：命中刷新 mtime，条数裁剪时优先保留热条目
    except OSError:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    return doc


def _prune_disk(directory=None, max_entries=None, ttl_hours=None) -> int:
    """磁盘缓存裁剪：保留期 + 条数上限（写入时调用）。返回删除数。"""
    d = directory or parse_cache_dir()
    try:
        names = [n for n in os.listdir(d) if n.endswith(".json.gz")]
    except OSError:
        return 0
    try:
        cap = int(max_entries if max_entries is not None else
                  os.environ.get("RULEPROOF_PARSE_CACHE_MAX_ENTRIES", _PARSE_CACHE_MAX_ENTRIES))
    except (TypeError, ValueError):
        cap = _PARSE_CACHE_MAX_ENTRIES
    try:
        ttl_s = float(ttl_hours if ttl_hours is not None else
                      os.environ.get("RULEPROOF_PARSE_CACHE_TTL_HOURS", _PARSE_CACHE_TTL_HOURS)) * 3600
    except (TypeError, ValueError):
        ttl_s = _PARSE_CACHE_TTL_HOURS * 3600
    now = time.time()
    entries = []
    for n in names:
        fn = os.path.join(d, n)
        try:
            st = os.stat(fn)
        except OSError:
            continue
        entries.append((st.st_mtime, st.st_size, fn))
    entries.sort()
    removed = 0
    if ttl_s > 0:
        for mtime, _size, fn in entries:
            if now - mtime <= ttl_s:
                break  # 已按 mtime 升序，后面的都更新
            try:
                os.remove(fn)
                removed += 1
            except OSError:
                logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        entries = [e for e in entries if os.path.exists(e[2])]
    if cap > 0 and len(entries) > cap:
        for _mtime, _size, fn in entries[:len(entries) - cap]:
            try:
                os.remove(fn)
                removed += 1
            except OSError:
                logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    if removed:
        _bump("pruned", removed)
    return removed


def _legacy_doc_dict(path, version=None):
    """复用同进程 agent-parse 已写入的 parsed dict（含 doc），避免二次完整解析。"""
    if not _fact_identity_fix_on():
        # L86 =0 时旧 content 键不含 sha256，无法验证文档版本 → 不跨口径复用
        return None
    try:
        got = get(path, version)
    except Exception:
        return None
    if not isinstance(got, dict):
        return None
    doc = got.get("doc")
    if isinstance(doc, dict) and (doc.get("text") or doc.get("sections")):
        return doc
    return None


def parse_document(path, version=None):
    """统一解析入口：``deepparse.parse_document`` 的内容寻址缓存版（L145 Top1）。

    返回类型/异常语义与 ``deepparse.parse_document`` 一致；缓存命中返回**新建**
    ParsedDoc。开关 ``RULEPROOF_PARSE_CACHE=0`` 时逐字节回退到直连 deepparse。
    """
    _maybe_register_stats_file()
    if not parse_cache_enabled():
        _bump("disabled")
        from ..engine import deepparse as _dp
        return _dp.parse_document(path)
    try:
        p = str(path)
    except Exception:
        p = ""
    info = parse_cache_key(p, version) if p else None
    if info is None:
        # 不存在/不可读/空哈希：不缓存，直接交给 deepparse（保持旧异常语义）
        _bump("cache_bypass")
        from ..engine import deepparse as _dp
        return _dp.parse_document(path)
    key = _parse_key_tuple(info)
    t0 = time.perf_counter()
    with _PARSE_LOCK:
        memo = _PARSE_MEMO.get(key)
    if memo is not None:
        doc = _doc_from_dict(memo)
        if doc is not None:
            _record_hit("memory", info, t0)
            return doc
    disk_doc = _disk_read(info)
    if disk_doc is not None:
        doc = _doc_from_dict(disk_doc)
        if doc is not None:
            _memo_put(key, disk_doc)
            _record_hit("disk", info, t0)
            return doc
    legacy = _legacy_doc_dict(p, version)
    if legacy is not None:
        doc = _doc_from_dict(legacy)
        if doc is not None:
            _memo_put(key, legacy)
            _disk_write(info, legacy)
            _record_hit("legacy", info, t0)
            return doc
    _bump("cache_miss")
    from ..engine import deepparse as _dp
    t_parse = time.perf_counter()
    parsed = _dp.parse_document(path)
    ms = (time.perf_counter() - t_parse) * 1000.0
    with _PARSE_LOCK:
        _PARSE_STATS["parse_calls"] += 1
        _PARSE_STATS["parse_ms_total"] = round(_PARSE_STATS["parse_ms_total"] + ms, 3)
    _log.info("parse_cache miss file=%s bytes=%s sha=%s ms=%.1f",
              os.path.basename(p), info["size"], info["sha256"][:16], ms)
    try:
        doc_dict = parsed.to_dict()
        _memo_put(key, doc_dict)
        _disk_write(info, doc_dict)
    except Exception:
        _log.debug("parse_cache 写内存/磁盘失败 file=%s", os.path.basename(p),
                   exc_info=True)
    return parsed


def stats() -> dict:
    """解析缓存统计（可观测；只含计数/路径/哈希前缀，不含任何文件内容）。"""
    with _PARSE_LOCK:
        out = dict(_PARSE_STATS)
        out["memory_entries"] = len(_PARSE_MEMO)
    d = parse_cache_dir()
    files = []
    try:
        files = [n for n in os.listdir(d) if n.endswith(".json.gz")]
    except OSError:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    total = 0
    for n in files:
        try:
            total += os.path.getsize(os.path.join(d, n))
        except OSError:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    out["enabled"] = parse_cache_enabled()
    out["dir"] = d
    out["disk_entries"] = len(files)
    out["disk_bytes"] = total
    out["parser_fingerprint"] = _parser_fingerprint()[:16]
    return out


def reset_stats() -> None:
    with _PARSE_LOCK:
        for k in list(_PARSE_STATS):
            _PARSE_STATS[k] = 0.0 if isinstance(_PARSE_STATS[k], float) else 0



def clear_memory() -> None:
    """只清进程内 parsed-doc 缓存（保留磁盘缓存，用于验证“新进程”磁盘命中）。"""
    with _PARSE_LOCK:
        _PARSE_MEMO.clear()


def clear_persistent(path="") -> int:
    """清磁盘解析缓存：path 空=全部；给定 path=只删该真实路径条目。返回删除数。"""
    d = parse_cache_dir()
    if not os.path.isdir(d):
        return 0
    want = os.path.realpath(str(path)) if path else ""
    removed = 0
    for name in list(os.listdir(d)):
        if not name.endswith(".json.gz"):
            continue
        fn = os.path.join(d, name)
        if want:
            try:
                with gzip.open(fn, "rt", encoding="utf-8") as f:
                    payload = json.load(f)
            except Exception:
                continue
            if str(((payload or {}).get("key") or {}).get("path") or "") != want:
                continue
        try:
            os.remove(fn)
            removed += 1
        except OSError:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    return removed


def _maybe_register_stats_file() -> None:
    """可选：RULEPROOF_PARSE_CACHE_STATS=<file> → 进程退出时落统计 JSON（不含内容）。"""
    with _PARSE_LOCK:
        if _STATS_FILE_STATE.get("registered"):
            return
        _STATS_FILE_STATE["registered"] = True
        target = str(os.environ.get("RULEPROOF_PARSE_CACHE_STATS") or "").strip()
        _STATS_FILE_STATE["target"] = target
    if not target:
        return
    import atexit

    def _dump():
        try:
            snap = stats()
            snap["ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
            snap["pid"] = os.getpid()
            tgt = _STATS_FILE_STATE.get("target") or ""
            tdir = os.path.dirname(tgt)
            if tdir:
                os.makedirs(tdir, exist_ok=True)
            tmp = tgt + ".tmp.%d" % os.getpid()
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(snap, f, ensure_ascii=False)
            os.replace(tmp, tgt)
        except Exception:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)

    atexit.register(_dump)
