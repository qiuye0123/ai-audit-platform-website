"""L3：在 L2 规则结论上补充平台点位（不覆盖规则结论）。"""
import json, re
from .. import repositories as R
from . import lab_l2, auditpoints as AP, structure


def _bg(t: str):
    t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fff")
    return {t[i:i + 2] for i in range(len(t) - 1)}


def l3_judge(path: str, limit: int = 20, point_limit: int = 60, point_ids=None) -> dict:
    base = lab_l2.l2_judge(path, limit=limit)
    text = ""
    try:
        from .lab_l0 import _doc_text
        text = _doc_text(path)
    except Exception:
        pass
    clauses = structure.segment(text) or []
    lib = AP.load()
    _allow = {str(x) for x in (point_ids or []) if str(x).strip()}
    _lib_points = [p for p in lib.points if (not _allow or p.id in _allow)]
    picked = []
    for p in _lib_points:
        own = _bg(f"{p.name} {p.criterion}")
        best = max((len(own & _bg(c["text"])) for c in clauses), default=0)
        if best >= 2:
            picked.append({"id": p.id, "name": p.name, "criterion": p.criterion,
                           "required_evidence": p.required_evidence, "trigger": p.trigger,
                           "level": getattr(p, "severity", "warning"), "severity": getattr(p, "severity", "warning"),
                           "method": getattr(p, "method", ""), "prompt": getattr(p, "prompt", ""),
                           "category": p.category, "category_id": getattr(p, "category_id", ""),
                           "_score": best})
    picked = sorted(picked, key=lambda x: -x["_score"])[:point_limit]
    if not picked:
        # 短文本兜底：没有点位达到阈值时，取相关性最高的前 N 个（避免“点位补充完全空转”）
        scored = []
        for p in _lib_points:
            own = _bg(f"{p.name} {p.criterion}")
            best = max((len(own & _bg(c["text"])) for c in clauses), default=0)
            scored.append((best, p))
        scored.sort(key=lambda x: -x[0])
        picked = [{"id": p.id, "name": p.name, "criterion": p.criterion,
                   "required_evidence": p.required_evidence, "trigger": p.trigger,
                   "level": getattr(p, "severity", "warning"), "severity": getattr(p, "severity", "warning"),
                   "method": getattr(p, "method", ""), "prompt": getattr(p, "prompt", ""),
                   "category": p.category, "category_id": getattr(p, "category_id", ""),
                   "_score": sc} for sc, p in scored[:min(20, point_limit)] if sc > 0]
    extra = []
    if picked and text:
        try:
            extra = AP.execute_points(path, picked, "", text) or []
        except Exception:
            extra = []
    findings = list(base["findings"])
    seen = {re.sub(r"\s+", "", str(((f.get("locations") or [{}])[0] or {}).get("quote") or ""))[:50] for f in findings}
    for e in extra:
        q = re.sub(r"\s+", "", str(((e.get("locations") or [{}])[0] or {}).get("quote") or ""))[:50]
        if q and q in seen:
            continue
        e["origin"] = "platform_point"
        findings.append(e)
        if q:
            seen.add(q)
    base["findings"] = findings
    base["points_used"] = len(picked)
    base["points_findings"] = len(extra)
    return base
