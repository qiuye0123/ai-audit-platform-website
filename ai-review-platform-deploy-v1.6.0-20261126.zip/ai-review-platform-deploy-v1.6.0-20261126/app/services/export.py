"""数据导出（CSV，带 BOM 便于 Excel 打开）。"""
import csv
import io

from .. import repositories as R

# CSV 公式注入防护（评审 P2-B4-02 / B4-F1）：Excel / Google Sheets / WPS 打开 CSV 时，
# 以 = + - @ \t \r 开头的单元格会被当作公式解析（=cmd|'/C calc'!A0 这类可执行命令）。
# 导出件是给客户/审计外发的，必须在单元格层面统一转义：前置单引号 + 全文加引号。
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def safe_cell(value):
    """CSV 单元格安全化：公式前缀加单引号；其余原样（数字/None 归一成字符串）。"""
    if value is None:
        return ""
    text = value if isinstance(value, str) else str(value)
    if text and text[0] in _FORMULA_PREFIXES:
        return "'" + text
    return text


def _csv(rows: list, headers: list) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([safe_cell(h) for h in headers])
    for r in rows:
        w.writerow([safe_cell(r.get(h, "")) for h in headers])
    return ("\ufeff" + buf.getvalue()).encode("utf-8")


def row_count(content: bytes) -> int:
    """CSV 数据行数（不含表头；解析失败返回 -1）。

    仅供导出审计元数据使用（rows 字段）；单元格内含换行也不会误算。
    """
    try:
        text = (content or b"").decode("utf-8-sig")
        return max(0, len(list(csv.reader(io.StringIO(text)))) - 1)
    except Exception:  # noqa: BLE001 - 元数据统计失败不影响导出内容
        return -1




def findings_csv(case_id: str = "") -> bytes:
    where = "case_id=?" if case_id else "1=1"
    rows = []
    for f in R.findings.list(where, (case_id,) if case_id else ()):
        rows.append({"id": f["id"], "case_id": f.get("case_id") or "", "rule_id": f.get("rule_id") or "",
                     "severity": f.get("severity") or "", "status": f.get("status") or "",
                     "title": f.get("title") or "", "summary": f.get("summary") or "",
                     "suggestion": f.get("suggestion") or "", "created_at": ""})
    return _csv(rows, ["id", "case_id", "rule_id", "severity", "status", "title", "summary", "suggestion", "created_at"])




def audit_records_csv(date_from: str = "", date_to: str = "", reviewer_id: str = "") -> bytes:
    """审核记录导出（与审核记录页同源）。"""
    from . import review
    d = review.audit_records(date_from, date_to, reviewer_id, limit=5000)
    rows = [{"时间": r["created_at"], "审核员": r["reviewer"], "项目": r["case_name"],
             "问题": r["title"], "等级": r["severity_label"], "人工意见": r["decision"],
             "规则": r["rule_id"]} for r in d["items"]]
    return _csv(rows, ["时间", "审核员", "项目", "问题", "等级", "人工意见", "规则"])
