"""规则级确定性补检：语义判定容易漏的数值型要求。"""
import re
from .. import repositories as R


def doc_text(path: str) -> str:
    try:
        from ..engine import deepparse
        return deepparse.parse_and_extract(path)["doc"].get("text", "") or ""
    except Exception:
        return ""


def cooling_gap(path: str) -> dict:
    """冷却类规则：全文没有任何 ≤10℃ 的温度 → 缺冷却目标温度。"""
    text = doc_text(path)
    temps = [float(x) for x in re.findall(r"(\d{1,3}(?:\.\d+)?)\s*℃", text)]
    quote = ""
    for line in text.splitlines():
        if "冷却" in line:
            quote = line.strip()
            break
    return {"gap": bool(temps) and not any(t <= 10 for t in temps),
            "temps": temps[:8], "quote": quote}
