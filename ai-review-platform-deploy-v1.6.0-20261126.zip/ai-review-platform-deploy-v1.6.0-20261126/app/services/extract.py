"""模型抽取与语义执行（用统一 LLM provider / DeepSeek）。

- extract_facts(text)：从文本抽取结构化事实（工序/参数/数值/单位/对象），与行业无关。
- execute_audit_point(point, doc_text)：通用审核点语义执行——先判适用(applicable_when)→再判合格(criterion)→五态。
"""
import json
import logging
logger = logging.getLogger(__name__)
import re

from .. import config
from ..engine import llm


def _provider():
    # 不传显式 config：让 llm_router 先查 DB（管理员配置），再回落环境变量；
    # 显式关闭（RULEPROOF_LLM_ENABLED=0）时仍必须禁用，供确定性测试使用。
    import os as _os
    if str(_os.environ.get("RULEPROOF_LLM_ENABLED", "")).strip() in ("0", "false", "no"):
        return None
    return llm.openai_judge_provider()


def _chat(messages, max_tokens=512, schema=None, schema_hint="", text_for_quote=None):
    """统一对话汇口。

    schema 非空时走 T1 半约束 JSON 入口（llm.chat_json）：
    - 开关 RULEPROOF_LLM_JSON_MODE 关闭（默认）时 chat_json 直接委托
      llm.chat_completion，请求体与改动前逐字节一致，行为不变；
    - 开关开启时加 response_format=json_object + 内嵌 JSON Schema + 校验重试。
    """
    from ..engine import llm_router
    c = llm_router.resolve()
    if not c.get("enabled"):
        raise RuntimeError("未配置可用的模型（DB 与环境变量均无）")
    if schema is not None:
        return llm.chat_json(c["base_url"], c["api_key"], c["model"], messages,
                             schema=schema, schema_hint=schema_hint,
                             text_for_quote=text_for_quote,
                             timeout=c.get("timeout_seconds", 20),
                             max_tokens=max_tokens)
    return llm.chat_completion(c["base_url"], c["api_key"], c["model"], messages,
                               c.get("timeout_seconds", 20), max_tokens)


def _json_of(content):
    try:
        return json.loads(content)
    except Exception:
        # 容错：用 raw_decode 取第一个合法 JSON 对象/数组（忽略后续多余文本）
        dec = json.JSONDecoder()
        s = content.strip()
        for start in (0, s.find("["), s.find("{")):
            if start < 0:
                continue
            try:
                obj, _ = dec.raw_decode(s[start:])
                return obj
            except Exception:
                continue
        return {}


def _chunks(text: str, size: int = 1200) -> list:
    t = (text or "").strip()
    return [t[i:i + size] for i in range(0, len(t), size)] or [""]


def extract_facts(text: str, provenance=None) -> dict:
    """LLM 事实抽取：文本 → 结构化事实数组（工序/参数/数值/单位/对象/原文）。

    provenance（TL-5，可选）：来源解析产物的 provenance（文档摘要 dict / 'trusted' 等）。
    传入时给每条事实补 ocr_engine / ocr_tier / vision_advisory / evidence_source；
    不传 = 未知来源（老调用方行为不变；字段缺失按「未知」处理，不默认安全）。
    """
    if _provider() is None:
        return {"error": "未配置模型（RULEPROOF_LLM_*）"}
    messages = [
        {"role": "system", "content": (
            "你是文件事实抽取器。从给定文本抽取可核验的结构化事实，只输出 JSON 数组，"
            "每项形如 {\"step\":\"工序名\",\"param\":\"参数名\",\"value\":\"数值\","
            "\"unit\":\"单位\",\"object\":\"对象\",\"quote\":\"原文片段\"}。"
            "不确定就省略该项；不编造数值。")},
        {"role": "user", "content": text},
    ]
    # 分块抽取：长文本一次输出会被截断，导致 JSON 解析失败并静默返回空
    chunks = _chunks(text, 1200)[:20]
    all_facts, failed = [], 0
    for i, ck in enumerate(chunks):
        msgs = [messages[0], {"role": "user", "content": ck}]
        try:
            content = _chat(msgs)
            facts = _json_of(content)
            if isinstance(facts, list):
                all_facts.extend(facts)
            else:
                failed += 1
                logger.warning("fact chunk %s 解析失败（长度 %s）", i, len(ck))
        except Exception as e:  # noqa
            failed += 1
            logger.warning("fact chunk %s 调用失败：%s", i, type(e).__name__)
    if provenance is not None:
        try:
            from ..engine import hooks as _hk
            all_facts = [_hk.apply_fact_provenance(f, provenance)
                         for f in all_facts if isinstance(f, dict)]
        except Exception:  # noqa: BLE001 - 标注失败必须留痕，不能静默把未知来源当可信
            logger.warning("fact provenance annotate failed", exc_info=True)
    return {"facts": all_facts, "chunks": len(chunks), "failed_chunks": failed}


def execute_audit_point(point: dict, doc_text: str, provenance=None) -> dict:
    """通用审核点语义执行：先判适用 → 再判合格，输出五态 + 证据 + 理由。

    TL-5：provenance 为来源文档/页的 provenance（不传 = 未知）。数值类审核点若依赖
    vision/未知来源的数值事实，判定降级为「证据不足」（fail-closed，带
    evidence_source/suppressed_by 痕迹，写结构化审计日志）；开关
    RULEPROOF_NUMERIC_PROVENANCE_GUARD=0 时完全回滚到旧行为。
    """
    if _provider() is None:
        return {"state": "弃权(需人工)", "reason": "未配置模型"}
    messages = [
        {"role": "system", "content": (
            "你是通用文件审核点执行器。第一步判断本审核点是否适用于本文档，"
            "不适用输出 na；第二步按判定标准对照原文判断。"
            "只输出 JSON：{\"state\":\"满足|不满足|不适用|证据不足|需人工\","
            "\"quote\":\"逐字原文证据\",\"rationale\":\"一句话理由\"}。"
            "找不到原文证据时 state=证据不足；需要外部依据时 state=需人工。")},
        {"role": "user", "content": (
            f"审核点：{point.get('point', '')}\n动作：{point.get('action', '')}\n"
            f"判定标准：{point.get('criterion', '')}\n适用条件：{point.get('applicable_when', '')}\n"
            f"所需证据：{point.get('evidence', '')}\n\n文档文本：\n{doc_text[:3000]}")},
    ]
    try:
        content = _chat(messages)
        obj = _json_of(content)
        result = {
            "state": obj.get("state", "证据不足"),
            "quote": obj.get("quote", ""),
            "rationale": obj.get("rationale", ""),
        }
        try:
            from ..engine import hooks as _hk
            if _hk.point_is_numeric(point):
                result = _hk.guard_judgement(
                    result, provenance=provenance,
                    rule_code=str(point.get("id") or point.get("point_id") or
                                  point.get("code") or ""),
                    source="extract.execute_audit_point")
        except Exception:  # noqa: BLE001 - 守卫异常按未知来源拦截（fail-closed）
            logger.warning("numeric provenance guard failed; downgrade audit point",
                           exc_info=True)
            result = dict(result, state="证据不足", suppressed_by="no_numeric_provenance",
                          evidence_source="vision_advisory",
                          provenance_blocked=True)
        return result
    except Exception as e:  # noqa
        return {"state": "弃权(需人工)", "reason": f"{type(e).__name__}: {e}"}
