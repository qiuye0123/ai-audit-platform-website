"""强制必检项（红线项，不允许无理由 na）。

产品口径：规则包里的 ``mandatory: true`` 表示「红线必检」——该条必须给出 pass/fail
结论；若判不适用（na）必须留下**实质不适用理由**并留痕。本模块只提供
判定/拦截/统计三个纯服务函数，不改 ``rule.py``/``human_review.py``：
Phase 2 在复核入口（human_review 的裁决服务）调用 ``enforce_review``，
把拒绝结果作为 400 返回；本模块自身不写库（除可选的只读规则槽位查询）。

约定：
- ``mandatory`` 可写在规则包点位（point.mandatory，apply 时注入 slots 与 scope）、
  版本槽位 ``slots.mandatory``，或规则主记录 ``scope_json.mandatory``；
- 本模块对 ``rule.py`` 只做**只读**查询（规则行/最新版本 slots_json），不写；
- ``is_mandatory`` 对 runtime 输入宽松（bool / "true" / 1 等），
  但规则包校验器 ``rule_pack.validate_pack`` 要求严格布尔，避免 "false" 字符串
  被 Python 真值误判成强制项。
"""
from __future__ import annotations

import json
import logging

log = logging.getLogger(__name__)

# 判「不适用」的状态族（finding 五态里的 na；兼容中文展示态/旧别名）
NA_STATES = ("na", "n/a", "not_applicable", "not-applicable", "skip", "skipped",
             "不适用", "跳过")
# 尚未判定的状态族（用于 stats 的 mandatory_pending）
PENDING_STATES = ("", "pending", "unknown", "not_judged", "待定", "未知", "未判定")
# 判「不满足」的状态族（统计用；不参与拦截）
FAIL_STATES = ("fail", "false", "不满足", "违规", "confirmed")
PASS_STATES = ("pass", "true", "满足", "通过")
MANDATORY_TRUE = ("true", "1", "yes", "on", "是", "必须", "强制")
MANDATORY_FALSE = ("false", "0", "no", "off", "否", "", "none", "null")
# 「写了等于没写」的不适用理由（占位符）
_PLACEHOLDER_REASONS = frozenset({
    "", "-", "--", "---", "—", "——", "无", "无理由", "无说明", "不适用", "n/a", "na",
    "none", "null", "nil", "0", "待定", "略", "同上", "skip", "skipped",
})


def _flag(value) -> bool:
    """mandatory 取值 → bool（runtime 宽松；规则包校验用严格布尔）。"""
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    if isinstance(value, (int, float)):
        return bool(value)
    s = str(value).strip().lower()
    if s in MANDATORY_TRUE:
        return True
    if s in MANDATORY_FALSE:
        return False
    return bool(s)


def _norm_state(value) -> str:
    s = str(value or "").strip().lower()
    return s


def _parse_json_dict(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str) or not raw.strip():
        return {}
    try:
        obj = json.loads(raw)
    except Exception:  # noqa: BLE001 - 坏 JSON 按无数据处理，由调用方决定
        return {}
    return obj if isinstance(obj, dict) else {}


def _mandatory_in_mapping(obj: dict) -> bool:
    """在 slots/scope 结构中查 mandatory（含 slots 嵌套）。"""
    if not isinstance(obj, dict):
        return False
    for key in ("mandatory", "is_mandatory", "must_check", "redline"):
        if key in obj:
            return _flag(obj.get(key))
    nested = obj.get("slots")
    if isinstance(nested, dict) and _mandatory_in_mapping(nested):
        return True
    return False


def _rule_row_by_ref(ref: str) -> dict:
    """只读：按 rule.id 或 rule.code 取规则行（取不到返回 {}）。"""
    if not ref:
        return {}
    try:
        from .. import repositories as R
        row = R.rules.get(ref) or {}
        if row:
            return row
        rows = R.rules.list("code=?", (ref,), limit=1) or []
        return rows[0] if rows else {}
    except Exception:  # noqa: BLE001 - 查询失败应按「非强制」返回，不阻断复核
        log.warning("mandatory_rule: rule lookup failed ref=%s", ref, exc_info=True)
        return {}


def _slots_by_rule_row(row: dict) -> dict:
    """只读：取规则最新版本的 slots（取不到返回 {}）。"""
    rid = str((row or {}).get("id") or "")
    if not rid:
        return {}
    try:
        from .. import repositories as R
        version = R.rules.latest_version(rid) or {}
        return _parse_json_dict(version.get("slots_json"))
    except Exception:  # noqa: BLE001
        log.warning("mandatory_rule: latest version lookup failed rule_id=%s", rid,
                    exc_info=True)
        return {}


def is_mandatory(rule_or_slots=None, slots: dict = None, *, allow_db: bool = True) -> bool:
    """判断规则/槽位是否为强制必检项。

    接受：
        - None / 空 → False
        - slots dict（直接含 mandatory）；
        - 规则行 dict（scope_json / slots_json / nested slots），或
          ``{"rule_id": "..."}`` / ``{"code": "..."}``——给了 ``allow_db=True``
          时会只读查规则最新版本槽位（Phase 2 复核入口直接用 finding.rule_id 即可）；
        - JSON 字符串（slots_json/scope_json）。
    """
    if slots and isinstance(slots, dict) and _mandatory_in_mapping(slots):
        return True
    if rule_or_slots is None:
        return False
    obj = rule_or_slots
    ref_hint = ""
    if isinstance(obj, str):
        parsed = _parse_json_dict(obj)
        if parsed:
            obj = parsed
        else:
            # 非 JSON 字符串按「规则 id / 规则编码」处理（复核入口常直接传 finding.rule_id）
            ref_hint = obj.strip()
            obj = {}
    if not isinstance(obj, dict):
        return False
    if _mandatory_in_mapping(obj):
        return True
    # 规则主记录：scope_json 里由规则包 apply 注入的 mandatory
    scope = _parse_json_dict(obj.get("scope_json"))
    if _mandatory_in_mapping(scope):
        return True
    # 版本行：slots_json
    if _mandatory_in_mapping(_parse_json_dict(obj.get("slots_json"))):
        return True
    nested = obj.get("slots")
    if isinstance(nested, dict) and _mandatory_in_mapping(nested):
        return True
    nested_rule = obj.get("rule")
    if isinstance(nested_rule, dict) and is_mandatory(nested_rule, allow_db=False):
        return True
    if not allow_db:
        return False
    ref = str(obj.get("rule_id") or obj.get("code") or obj.get("id")
              or ref_hint or "").strip()
    if not ref:
        return False
    row = _rule_row_by_ref(ref)
    if not row:
        return False
    if _mandatory_in_mapping(_parse_json_dict(row.get("scope_json"))):
        return True
    return _mandatory_in_mapping(_slots_by_rule_row(row))


def _clean_note(note) -> str:
    if isinstance(note, dict):
        note = (note.get("reason") or note.get("note") or note.get("na_reason")
                or note.get("text") or "")
    return str(note or "").strip()


def reason_is_valid(note) -> tuple:
    """不适用理由是否实质有效 → (ok, cleaned_reason, why)。

    占位符（“无”“-”“n/a”“待定”…）与过短（<2 字）的理由不算有效留痕；
    这是拦截口径的一部分，可被复核 UI 直接复用来提示用户。
    """
    reason = _clean_note(note)
    if not reason:
        return False, reason, "未填写不适用理由"
    if reason.lower() in _PLACEHOLDER_REASONS:
        return False, reason, "不适用理由为占位符，需要实质原因"
    if len(reason) < 2:
        return False, reason, "不适用理由过短（至少 2 个字）"
    return True, reason, ""


def enforce_review(rule, finding_state, note="") -> dict:
    """复核入口拦截：强制项判 na/skip 且无实质理由 → 拒绝。

    返回 ``{ok, code, message, mandatory, state, reason}``：
        ok=False, code="mandatory_na_without_reason"  → 调用方应返回 400 并留痕；
        ok=True,  code="mandatory_na_reason_accepted" → 允许，理由进审计/台账；
        ok=True,  code="not_mandatory" / "state_ok" / "pending_state"
    本函数只读判断，不写库、不自动补理由。
    """
    mandatory = is_mandatory(rule)
    state = _norm_state(finding_state)
    reason = _clean_note(note)
    base = {"mandatory": mandatory, "state": state, "reason": reason}
    if state in NA_STATES:
        if not mandatory:
            return {**base, "ok": True, "code": "not_mandatory",
                    "message": "非强制项，判不适用不需要额外理由"}
        ok, cleaned, why = reason_is_valid(reason)
        if not ok:
            return {**base, "ok": False, "code": "mandatory_na_without_reason",
                    "error": "mandatory_na_without_reason",
                    "message": f"强制必检项不允许无理由判不适用（na）：{why}；"
                               f"请填写实质不适用理由并留痕"}
        return {**base, "ok": True, "code": "mandatory_na_reason_accepted",
                "reason": cleaned,
                "message": "强制必检项判不适用已附实质理由，放行并留痕"}
    if state in PENDING_STATES:
        return {**base, "ok": True, "code": "pending_state",
                "warning": "强制必检项尚未判定，报告门禁前必须给出 pass/fail/na 结论"}
    return {**base, "ok": True, "code": "state_ok",
            "message": "强制必检项已给出非 na 结论"}


def stats(findings) -> dict:
    """按 finding 列表统计强制项覆盖情况。

    返回：mandatory_total / mandatory_na / mandatory_pending / mandatory_fail /
    mandatory_pass / mandatory_na_without_reason / non_mandatory / total。
    finding 未显式带 mandatory 时，可按 ``rule_id``（规则编码）只读查规则槽位。
    """
    out = {"total": 0, "mandatory_total": 0, "mandatory_na": 0,
           "mandatory_pending": 0, "mandatory_fail": 0, "mandatory_pass": 0,
           "mandatory_na_without_reason": 0, "non_mandatory": 0}
    for f in (findings or []):
        if not isinstance(f, dict):
            continue
        out["total"] += 1
        mandatory = is_mandatory(f)
        if not mandatory:
            out["non_mandatory"] += 1
            continue
        out["mandatory_total"] += 1
        state = _norm_state(f.get("state") or f.get("finding_state") or f.get("status"))
        if state in NA_STATES:
            out["mandatory_na"] += 1
            note = f.get("note") or f.get("reason") or f.get("na_reason") or ""
            ok, _cleaned, _why = reason_is_valid(note)
            if not ok:
                out["mandatory_na_without_reason"] += 1
        elif state in PENDING_STATES:
            out["mandatory_pending"] += 1
        elif state in FAIL_STATES:
            out["mandatory_fail"] += 1
        elif state in PASS_STATES:
            out["mandatory_pass"] += 1
        else:
            out["mandatory_pending"] += 1
    return out
