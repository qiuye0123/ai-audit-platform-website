"""本体运营：快照版本化 + 发布门禁（健康度把关 + 统一术语门禁）。

术语门禁只有一个口径（``term_gate``）：词典里**真实存在但未确认**的术语
（状态不是 confirmed/active，或旧库迁移的 active）一律阻断「manifest 冻结」和
「本体版本发布」；词典里不存在的术语按本体/外部词放行，避免误伤。
冻结与发布都调用同一个函数，返回结构也相同，便于核对与追溯。
"""
import json

from .. import db
from .. import repositories as R
from ..engine import ontology as onto_mod
from ..engine import engine

# 术语生效状态：与 manifest 冻结别名归一（terms.confirmed_alias_pairs）保持一致
TERM_EFFECTIVE_STATUS = ("confirmed", "active")
TERM_GATE_POLICY = "unconfirmed_term_blocks_freeze_and_publish"


def effective_term_status(status) -> bool:
    return str(status or "").strip().lower() in TERM_EFFECTIVE_STATUS


def _term_index() -> dict:
    """术语名/键/ID → 术语行；只用于门禁判定。"""
    idx = {}
    try:
        from . import terms as _terms
        rows = _terms.list_terms() or []
    except Exception:
        return idx
    for t in rows:
        for key in (t.get("id"), t.get("term_id"), t.get("name"),
                    t.get("term_key")):
            key = str(key or "").strip()
            if not key:
                continue
            idx[key.lower()] = t
            idx["id:" + key.lower()] = t
    return idx


def term_gate(term_refs=None, term_index: dict = None, workspace: str = "") -> dict:
    """统一术语门禁：未确认术语阻断「本体发布」与「manifest 冻结」。

    term_refs 支持两种元素：
    - 字符串术语名/键：按名称或键在词典里查；
    - ``{"term": 名称, "term_id": ID}``：优先按 ID 查，兼容名称改名。

    只有**词典里真实存在且状态非 confirmed/active** 的术语才阻断；
    词典里不存在的术语（本体/外部词）只记 ``missing_in_dictionary``，不阻断。
    """
    refs = []
    for raw in term_refs or []:
        if isinstance(raw, dict):
            name = str(raw.get("term") or raw.get("name") or raw.get("canonical") or "").strip()
            tid = str(raw.get("term_id") or raw.get("id") or "").strip()
            if name or tid:
                refs.append({"term": name or tid, "term_id": tid})
        else:
            name = str(raw or "").strip()
            if name:
                refs.append({"term": name, "term_id": ""})
    if term_index is None:
        term_index = _term_index()
    checked, unconfirmed, missing = [], [], []
    for ref in refs:
        row = None
        if ref["term_id"]:
            row = (term_index or {}).get("id:" + ref["term_id"].lower())
        if row is None:
            row = (term_index or {}).get(ref["term"].lower())
        if row is None:
            missing.append(ref["term"])
            continue
        status = str(row.get("status") or "").lower()
        eff = effective_term_status(status)
        item = {"term": ref["term"], "term_id": row.get("id") or row.get("term_id") or "",
                "name": row.get("name") or ref["term"], "status": status,
                "effective": eff}
        checked.append(item)
        if not eff:
            unconfirmed.append(item)
    return {
        "ok": not unconfirmed,
        "policy": TERM_GATE_POLICY,
        "rule": "词典中存在但未确认（非 confirmed/active）的术语 → 阻断 manifest 冻结与本体发布；"
                "词典中不存在的术语按本体/外部词放行",
        "effective_statuses": list(TERM_EFFECTIVE_STATUS),
        "checked": checked,
        "checked_count": len(checked),
        "unconfirmed": unconfirmed,
        "unconfirmed_count": len(unconfirmed),
        "missing_in_dictionary": missing,
        "workspace": workspace or "",
    }


def _workspace_scope() -> tuple:
    try:
        from . import ctx as _ctx
        c = _ctx.get_context() or {}
        return c.get("tenant_id") or "", c.get("workspace_id") or ""
    except Exception:
        return "", ""


def _projected_term_refs(workspace: str = "") -> list:
    """工作空间本体里引用业务词典的术语 → 发布门禁检查对象。

    工作空间本体术语带 ``term_id``（由词典确认后投影）或用标准名引用；
    发布本体版本时，这些引用必须指向已确认术语。
    """
    refs = []
    try:
        from . import ontology_workspace as _ows
        st = _ows._settings(workspace or _workspace_scope()[1]) or {}
        rows = _ows._terms(st)
    except Exception:
        return refs
    for t in rows or []:
        if not isinstance(t, dict):
            continue
        canonical = str(t.get("canonical") or "").strip()
        tid = str(t.get("term_id") or "").strip()
        source = str(t.get("source") or "").strip().lower()
        if not (canonical or tid):
            continue
        # 自动发现候选还没进入正式术语，不参与发布门禁
        if str(t.get("status") or "active") == "candidate":
            continue
        refs.append({"term": canonical or tid, "term_id": tid, "source": source})
    return refs


def snapshot() -> dict:
    """把当前本体快照为一个草稿版本（T-197 P1-2：按租户隔离，workspace 级 NULL=租户共享）。

    - 先按当前 ctx 重载引擎本体（tenant 视图），快照只包含可见资产；
    - onto_version 行显式带 tenant_id（ctx 自动）、workspace_id=NULL。
    """
    onto = engine.reload_ontology()
    health = onto.health()
    vid = db.new_id("ov")
    R.onto_versions.insert(
        id=vid,
        version=f"v{db.now().replace('-','').replace(':','').replace(' ','')[:12]}",
        status="draft", snapshot_json=json.dumps(onto.to_dict(), ensure_ascii=False),
        health_json=json.dumps(health, ensure_ascii=False),
        workspace_id=None)
    return {"version_id": vid, "health": health,
            "scope": {"tenant_isolated": True, "workspace_id": None}}


def publish(version_id: str, min_score: int = 90, require_terms: bool = True) -> dict:
    """发布门禁：健康分达标且无 error 级问题才可发布；术语未确认同样阻断。

    与 ``manifest.freeze`` 共用 ``term_gate``，口径一致：未确认术语不发布/不冻结。
    """
    # T-197（P1-2）：跨租户/不存在的版本统一 404 口径（不泄露存在性）
    from . import ontology_assets as _assets
    v = _assets.version_visible(version_id)
    if not v:
        return {"error": "version not found", "http_status": 404, "code": "not_found"}
    health = json.loads(v["health_json"] or "{}")
    errors = [f for f in health.get("findings", []) if f.get("level") == "error"]
    if health.get("score", 0) < min_score or errors:
        return {"error": "发布门禁未通过", "score": health.get("score"), "findings": errors}
    _tid, _wid = _workspace_scope()
    gate = term_gate(_projected_term_refs(_wid), workspace=_wid) if require_terms else {
        "ok": True, "policy": TERM_GATE_POLICY, "checked": [], "checked_count": 0,
        "unconfirmed": [], "unconfirmed_count": 0, "missing_in_dictionary": []}
    if not gate.get("ok"):
        try:
            R.audit_logs.log(actor="system", action="ontology.publish_blocked", object=version_id,
                             after=json.dumps({"term_gate": gate}, ensure_ascii=False)[:2000])
        except Exception:
            pass
        return {"error": "术语门禁未通过", "code": "term_gate_blocked",
                "version_id": version_id, "score": health.get("score"),
                "term_gate": gate}
    # T-197（P1-3）：版本发布与 ontology.published 审计同事务；失败整体回滚。
    from . import audit as _audit
    with db.session() as _c:
        _c.execute("UPDATE onto_version SET status='published', published_at=? WHERE id=?",
                   (db.now(), version_id))
        _audit.log_in_tx(_c, actor="admin", action="ontology.published", object_=version_id,
                        after=f"score={health.get('score')} term_checked={gate.get('checked_count')} "
                              f"policy={gate.get('policy')}")
    return {"version_id": version_id, "status": "published", "score": health.get("score"),
            "term_gate": gate}


def list_versions() -> list:
    return R.onto_versions.list(order="created_at DESC")
