# -*- coding: utf-8 -*-
"""机制规则证据硬门禁：fail 必须有原文 quote，且 quote 支撑证据对象。

只对显式声明 evidence_gate=True 的点位生效；不改确定性规则/普通点位的旧行为。
"""
from __future__ import annotations
import re


def _terms(point: dict) -> list[str]:
    vals = []
    for k in ("evidence_terms", "required_evidence", "evidence", "mechanism_terms", "route_terms"):
        v = (point or {}).get(k)
        if isinstance(v, (list, tuple)):
            vals.extend(str(x) for x in v)
        elif v:
            vals.append(str(v))
    out = []
    for s in vals:
        for seg in re.split(r"[、,，;；/\\s]+", s):
            seg = seg.strip()
            if len(seg) >= 2 and seg not in out:
                out.append(seg)
    return out


def check(point: dict, result: dict, document_text: str | None = None) -> dict:
    """返回新 result；不修改入参。

    硬门禁优先级：
    1) fail 必须有 quote；
    2) 有 document_text 时，quote 必须能在原文找到（防模型幻觉）；
    3) 无 document_text 的离线调用才退化为证据词匹配。
    """
    out = dict(result or {})
    if not out.get("state") == "fail":
        return out
    if not (point or {}).get("evidence_gate"):
        return out
    quote = str(out.get("quote") or out.get("evidence") or out.get("excerpt") or "").strip()
    if not quote:
        out["state"] = "insufficient"
        out["gate"] = {"passed": False, "reason": "fail_without_quote"}
        out["rationale"] = (str(out.get("rationale") or "") + "（证据门禁：fail 无原文引用，转人工）").strip()
        return out
    if document_text is not None:
        _doc = str(document_text or "")
        _q = quote.strip().strip("“”\"'")
        if _q and _q not in _doc:
            out["state"] = "insufficient"
            out["gate"] = {"passed": False, "reason": "quote_not_in_document", "quote": quote[:160]}
            out["rationale"] = (str(out.get("rationale") or "") + "（证据门禁：引用无法在原文定位，转人工）").strip()
            return out
        out["gate"] = {"passed": True, "reason": "quote_in_document", "quote": quote[:160]}
        return out
    terms = _terms(point)
    if terms and not any(t in quote for t in terms):
        out["state"] = "insufficient"
        out["gate"] = {"passed": False, "reason": "quote_not_support_evidence", "quote": quote[:160]}
        out["rationale"] = (str(out.get("rationale") or "") + "（证据门禁：引用未支撑所需证据，转人工）").strip()
        return out
    out["gate"] = {"passed": True, "reason": "quote_supports_evidence", "quote": quote[:160]}
    return out
