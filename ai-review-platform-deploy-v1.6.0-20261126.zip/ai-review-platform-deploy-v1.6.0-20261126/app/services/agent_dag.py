"""通用 Agent DAG 调度：节点依赖、环检测、条件跳过、执行轨迹。

默认 project.audit 通过 audit_dag 使用本调度器；RULEPROOF_AUDIT_DAG=0
可回退旧 orchestrator 链路。本模块只负责调度，不承载业务执行。
"""
from __future__ import annotations
from collections import defaultdict, deque


class DAGError(ValueError):
    pass


def validate(nodes: list) -> dict:
    ids = []
    by_id = {}
    for n in nodes or []:
        nid = str(n.get("id") or "")
        if not nid:
            raise DAGError("节点缺少 id")
        if nid in by_id:
            raise DAGError(f"节点 id 重复：{nid}")
        ids.append(nid); by_id[nid] = n
    for nid, n in by_id.items():
        for dep in n.get("depends_on") or []:
            if dep not in by_id:
                raise DAGError(f"节点 {nid} 依赖不存在：{dep}")
    # Kahn 拓扑 + 环检测
    indeg = {nid: 0 for nid in ids}
    adj = defaultdict(list)
    for nid, n in by_id.items():
        for dep in set(n.get("depends_on") or []):
            indeg[nid] += 1
            adj[dep].append(nid)
    q = deque([nid for nid, d in indeg.items() if d == 0])
    order = []
    while q:
        cur = q.popleft(); order.append(cur)
        for nxt in adj[cur]:
            indeg[nxt] -= 1
            if indeg[nxt] == 0:
                q.append(nxt)
    if len(order) != len(ids):
        raise DAGError("工作流存在环")
    return {"ok": True, "order": order, "nodes": len(ids)}


def run(nodes: list, handlers: dict, context: dict = None, stop_on_error: bool = True) -> dict:
    """按依赖执行；handler 接收 (node, context) 返回 dict。

    返回 {ok, trace, outputs, order}。handler 抛错时节点 failed，
    依赖它的下游 skipped；stop_on_error=True 时立即中止。
    """
    plan = validate(nodes)
    by_id = {str(n["id"]): n for n in nodes}
    ctx = dict(context or {})
    outputs, trace, failed = {}, [], set()
    for nid in plan["order"]:
        n = by_id[nid]
        deps = n.get("depends_on") or []
        if any(d in failed for d in deps):
            trace.append({"id": nid, "name": n.get("name", nid), "status": "skipped",
                          "error": "上游失败"}); failed.add(nid); continue
        if n.get("when") is not None:
            try:
                if not bool(n["when"](ctx)):
                    trace.append({"id": nid, "name": n.get("name", nid), "status": "skipped",
                                  "error": "条件不满足"}); continue
            except Exception as e:
                trace.append({"id": nid, "name": n.get("name", nid), "status": "failed",
                              "error": f"条件异常：{e}"}); failed.add(nid)
                if stop_on_error: break
                continue
        fn = handlers.get(nid)
        if fn is None:
            trace.append({"id": nid, "name": n.get("name", nid), "status": "failed",
                          "error": "缺少 handler"}); failed.add(nid)
            if stop_on_error: break
            continue
        try:
            out = fn(n, ctx) or {}
            outputs[nid] = out
            trace.append({"id": nid, "name": n.get("name", nid), "status": "ok", "output": out})
            if isinstance(out, dict):
                ctx.update(out)
        except Exception as e:
            trace.append({"id": nid, "name": n.get("name", nid), "status": "failed",
                          "error": f"{type(e).__name__}: {e}"})
            failed.add(nid)
            if stop_on_error: break
    return {"ok": not failed, "trace": trace, "outputs": outputs,
            "order": plan["order"], "failed": sorted(failed)}


def validate_trace(nodes: list, trace: list) -> dict:
    """校验实际执行轨迹是否覆盖工作流节点，并检查失败/跳过是否可解释。"""
    plan = validate(nodes)
    expected = [str(n.get("id")) for n in nodes]
    got = {str(x.get("id")): x for x in (trace or [])}
    missing = [x for x in expected if x not in got]
    unexpected = [x for x in got if x not in expected]
    order = [str(x.get("id")) for x in (trace or []) if str(x.get("id")) in expected]
    expected_order = [x for x in plan["order"] if x in got]
    order_ok = order == expected_order
    failed = [x for x in expected if x in got and str(got[x].get("status")) == "failed"]
    skipped = [x for x in expected if x in got and str(got[x].get("status")) == "skipped"]
    return {"ok": not missing and not unexpected and order_ok,
            "missing": missing, "unexpected": unexpected, "order_ok": order_ok,
            "failed": failed, "skipped": skipped, "covered": len(got), "total": len(expected)}
