"""点位模板确认：302 预置点位先作为模板，确认后才成为当前空间的执行依据。

架构边界（P0-2，单一权威）：
- ``auditpoints`` 负责点位库、选项和「执行取点」。点位库版本/单点指纹只由
  ``auditpoints.library_version()`` / ``auditpoints.point_hash()`` 计算。
- 本模块负责 302 确认、旧空间迁移、失效（stale）标记、重确认和撤销状态。
- 状态读取只有一个权威函数链：``resolve_state()`` 判定单条记录，
  ``snapshot()`` 读取一个租户/空间并返回全部已判定记录；``status()`` /
  ``pending_reconfirm()`` / ``allowed_ids()`` / ``execution_gate()`` /
  ``revoke_stale()`` / ``activate_workspace()`` /
  ``auditpoints.execution_selection()`` 全部复用这一条链，禁止两边各算一套
  confirmed/stale。

旧接口（confirm / confirm_many / revoke / revoke_many / status /
pending_reconfirm / reconfirm / revoke_stale / revoke_stale_many /
prepare_migration / activate_workspace / recommended / allowed_ids /
filter_points / library_version）全部保留兼容；其中库身份与推荐点位只做
委托，不再在本地另算一份。

点位库升级（版本或单点判据变化）后，旧的 confirmed 记录不会继续静默执行：
读取/执行入口会把它自动落为 stale，并给出待重确认列表；管理员显式重确认
或用 revoke_stale 撤销 stale 确认后，才可能重新进入执行集合。
"""
from __future__ import annotations
import json
import logging
from .. import db
from . import ctx

_LOG = logging.getLogger(__name__)

_STALE_LIBRARY = "点位库版本已更新，请重新确认"
_STALE_POINT = "点位判据已变更，请重新确认"
_STALE_REMOVED = "点位已从当前点位库移除，不能再执行"
_STALE_UNVERIFIED = "当前点位库暂不可用，无法校验确认，暂不放行"
_STALE_MARKED = "该确认已失效，请重新确认或撤销"


# ---------------------------------------------------------------- 库身份委托
def _library() -> tuple[object, str, dict]:
    """兼容 shim：库对象/版本/索引全部由 auditpoints 提供。

    旧代码曾在本模块缓存库版本并计算 point_hash；P0-2 后不再保留第二套
    指纹实现，避免 point_confirm 与 auditpoints 对“点位库是否升级”判断不一。
    """
    from . import auditpoints
    lib = auditpoints.load()
    return lib, auditpoints.library_version(), auditpoints.point_index()


def library_version() -> str:
    """当前点位库版本；委托 auditpoints（确认记录 stale 判定的唯一版本源）。"""
    try:
        from . import auditpoints
        return auditpoints.library_version()
    except Exception:
        return ""


def _point_hash(p) -> str:
    """单点指纹；委托 auditpoints，保留旧私有名供内部/旧脚本兼容。"""
    from . import auditpoints
    return auditpoints.point_hash(p)


# ---------------------------------------------------------------- 作用域
def _scope() -> tuple[str, str]:
    c = ctx.get_context() or {}
    return c.get("tenant_id") or "", c.get("workspace_id") or ""


def _workspace_scope(workspace: str = "") -> tuple[str, str]:
    """工作空间 -> (tenant_id, workspace_id)；委托 auditpoints 统一解析。

    跨租户/跨空间操作必须先解析空间所属租户；不能只看 workspace_id，
    否则同 id 记录或参数空间会把别的租户数据算进来。
    """
    from . import auditpoints
    return auditpoints.workspace_scope(workspace)


def _required_strict(workspace: str = "") -> bool:
    """读取门禁设置；读取失败向上抛出，供执行入口 fail-closed。"""
    from . import workspaces
    w = workspace or _scope()[1]
    return bool((workspaces.get_settings(w) or {}).get("point_confirm_required"))


def _required(workspace: str = "") -> bool:
    try:
        return _required_strict(workspace)
    except Exception:
        return False


def gate_required(workspace: str = "") -> bool:
    """点位确认门禁是否启用（公开只读；仍走同一 settings 口径）。"""
    return _required(workspace)


def _clean_ids(point_ids) -> list:
    if isinstance(point_ids, str):
        point_ids = [point_ids]
    return [str(x).strip() for x in (point_ids or []) if str(x).strip()]


# ---------------------------------------------------------------- 唯一状态判定
def _stale_reason_for(row: dict, current_version: str, pmap: dict) -> str:
    """返回 stale 原因；空字符串表示记录仍然有效。

    兼容旧数据：升级前写入的空 library_version / point_hash 无法证明与当前库
    一致，但仍按旧行为视为有效（旧空间迁移/确认 API 不因本次改造被改判）。
    """
    pid = str(row.get("point_id") or "")
    stored_version = str(row.get("library_version") or "")
    stored_hash = str(row.get("point_hash") or "")
    if pmap and pid and pid not in pmap:
        return _STALE_REMOVED
    point = pmap.get(pid)
    current_hash = _point_hash(point) if point is not None else ""
    if stored_version and current_version and stored_version != current_version:
        return _STALE_LIBRARY
    if stored_hash and current_hash and stored_hash != current_hash:
        return _STALE_POINT
    if stored_version and not current_version:
        return _STALE_UNVERIFIED
    if str(row.get("status") or "") == "stale":
        return _STALE_MARKED
    return ""


def resolve_state(row: dict, libinfo=None) -> dict:
    """【唯一权威】判定一条确认记录相对当前点位库的状态。

    ``libinfo`` 可传入 ``(lib, version, pmap)`` 避免循环内重复取库。返回字段：
    ``status``（库内原始状态）、``effective_status``（对外唯一有效状态：
    template/pending_review/confirmed/stale）、``stale``、``valid``、
    ``executable``、``stale_reason``、``reconfirmable``、当前版本/指纹。
    """
    row = dict(row or {})
    if libinfo is None:
        try:
            libinfo = _library()
        except Exception:
            libinfo = (None, "", {})
    _lib, current_version, pmap = libinfo
    pid = str(row.get("point_id") or "")
    reason = _stale_reason_for(row, current_version, pmap)
    point = pmap.get(pid)
    exists = point is not None
    row["current_library_version"] = current_version
    row["current_point_hash"] = _point_hash(point) if exists else ""
    row["point_exists"] = exists
    row["stale"] = bool(reason)
    row["valid"] = not reason
    row["stale_reason"] = reason
    raw_status = str(row.get("status") or "")
    if raw_status == "pending_review":
        # 待确认记录仍需人工确认；即使库已升级也不归入“已确认后失效”，
        # 否则 pending_review 会被 revoke_stale 误删。
        effective = "pending_review"
    elif raw_status == "stale" or (raw_status == "confirmed" and reason):
        effective = "stale"
    elif raw_status == "confirmed":
        effective = "confirmed"
    else:
        effective = raw_status or "template"
    row["effective_status"] = effective
    row["executable"] = effective == "confirmed"
    row["reconfirmable"] = bool(reason and current_version and exists
                               and raw_status in ("confirmed", "stale"))
    return row


def _evaluate_confirmation(row: dict, current_version: str, pmap: dict) -> dict:
    """旧私有入口兼容：内部委托 resolve_state，不再保留第二套判定。"""
    return resolve_state(row, libinfo=(None, current_version, pmap))


def _sync_stale(tenant: str = "", workspace: str = "", actor: str = "system",
                libinfo=None) -> dict:
    """把库升级后仍为 confirmed 的记录自动落为 stale（幂等，只改一次）。"""
    if not tenant and not workspace:
        tenant, workspace = _scope()
    if libinfo is None:
        try:
            libinfo = _library()
        except Exception:
            return {"ok": False, "marked": 0, "error": "点位库不可用"}
    _lib, current_version, pmap = libinfo
    if not current_version:
        return {"ok": True, "marked": 0, "skipped": "current_library_version_empty"}
    marked_ids = []
    with db.session() as c:
        rows = c.execute("SELECT * FROM auditpoint_confirmation "
                         "WHERE tenant_id=? AND workspace_id=? AND status='confirmed'",
                         (tenant, workspace)).fetchall()
        for r in rows:
            d = dict(r)
            if resolve_state(d, libinfo=libinfo).get("effective_status") == "stale":
                marked_ids.append(str(d.get("point_id") or ""))
        if not marked_ids:
            return {"ok": True, "marked": 0, "library_version": current_version}
        q = ",".join("?" for _ in marked_ids)
        cur = c.execute(f"UPDATE auditpoint_confirmation SET status='stale' "
                        f"WHERE tenant_id=? AND workspace_id=? AND status='confirmed' "
                        f"AND point_id IN ({q})",
                        (tenant, workspace, *marked_ids))
        marked = cur.rowcount if (cur.rowcount or 0) > 0 else 0
        if marked:
            c.execute("INSERT INTO audit_log(id,actor,action,object,after_json,created_at,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,?,?,?)",
                      (db.new_id("log"), actor or "system", "point_confirm.stale_marked",
                       f"{tenant}/{workspace}",
                       json.dumps({"current_library_version": current_version,
                                   "count": marked, "point_ids": marked_ids[:50]},
                                  ensure_ascii=False), db.now(), tenant, workspace))
        c.commit()
    return {"ok": True, "marked": marked, "point_ids": marked_ids,
            "library_version": current_version}


def snapshot(tenant: str = "", workspace: str = "", libinfo=None) -> dict:
    """【唯一权威读取入口】读取一个租户/空间并返回全部已判定确认记录。

    所有读取/执行入口必须经过这里（或它的 state_index/state_of 包装），
    不允许调用方自己 SELECT auditpoint_confirmation 后另行判断 stale。
    """
    if not tenant and not workspace:
        tenant, workspace = _scope()
    if libinfo is None:
        try:
            libinfo = _library()
        except Exception:
            libinfo = (None, "", {})
    current_version = str(libinfo[1] or "")
    if current_version:
        try:
            _sync_stale(tenant, workspace, libinfo=libinfo)
        except Exception:
            # 自动落 stale 失败不阻断读取：下面仍会逐条按当前库判定 valid=False，
            # 执行入口因此不会把 stale 记录静默放行。
            _LOG.warning("point confirmation stale sync failed", exc_info=True)
    with db.session() as c:
        rows = c.execute("SELECT * FROM auditpoint_confirmation "
                         "WHERE tenant_id=? AND workspace_id=? ORDER BY point_id",
                         (tenant, workspace)).fetchall()
    states = []
    for r in rows:
        d = dict(r)
        try:
            d["scope"] = json.loads(d.get("scope_json") or "[]")
        except Exception:
            d["scope"] = []
        states.append(resolve_state(d, libinfo=libinfo))
    return {"tenant_id": tenant, "workspace_id": workspace,
            "required": _required(workspace),
            "current_library_version": current_version,
            "library_ok": bool(libinfo and libinfo[0] is not None and current_version),
            "rows": states}


def _list_confirmations_for(tenant: str, workspace: str) -> list:
    """旧私有入口兼容：返回 snapshot 的已判定记录。"""
    return snapshot(tenant, workspace)["rows"]


def list_confirmations() -> list:
    """旧公开入口兼容：当前租户/空间的已判定确认记录。"""
    return _list_confirmations_for(*_scope())


def state_index(tenant: str = "", workspace: str = "", libinfo=None) -> dict:
    """point_id -> 已判定状态；所有状态视图的统一数据源。"""
    return {str(x.get("point_id") or ""): x
            for x in snapshot(tenant, workspace, libinfo=libinfo)["rows"]}


def state_of(point_id: str, tenant: str = "", workspace: str = "") -> dict:
    """单点状态读取；未确认点位返回 template 状态而不是编造 confirmed。"""
    pid = str(point_id or "").strip()
    snap = snapshot(tenant, workspace)
    for row in snap["rows"]:
        if str(row.get("point_id") or "") == pid:
            return row
    point = None
    try:
        from . import auditpoints
        point = auditpoints.point_index().get(pid)
        current_hash = auditpoints.point_hash(point) if point is not None else ""
    except Exception:
        current_hash = ""
    return {"point_id": pid, "tenant_id": snap["tenant_id"],
            "workspace_id": snap["workspace_id"], "status": "template",
            "effective_status": "template", "stale": False, "valid": False,
            "executable": False, "stale_reason": "", "reconfirmable": False,
            "point_exists": point is not None,
            "current_library_version": snap["current_library_version"],
            "current_point_hash": current_hash, "criterion": "", "scope": []}


def is_executable(point_id: str) -> bool:
    try:
        return bool(state_of(point_id).get("executable"))
    except Exception:
        return False


# ---------------------------------------------------------------- 状态汇总
def status() -> dict:
    """当前空间确认状态汇总；confirmed/stale/pending 全部来自 snapshot。"""
    snap = snapshot()
    rows = snap["rows"]
    confirmed = [x for x in rows if x.get("effective_status") == "confirmed"]
    stale = [x for x in rows if x.get("effective_status") == "stale"]
    pending_review = [x for x in rows if x.get("effective_status") == "pending_review"]
    pending_reconfirm = [x for x in stale if x.get("reconfirmable")]
    return {"tenant_id": snap["tenant_id"], "workspace_id": snap["workspace_id"],
            "required": snap["required"],
            "current_library_version": snap["current_library_version"],
            "confirmed": confirmed,
            "pending_review": pending_review,
            "valid": [x for x in confirmed if x.get("valid")],
            "stale": stale,
            "pending_reconfirm": pending_reconfirm,
            "stale_count": len(stale),
            "reconfirm_required": bool(stale),
            "library_ok": snap["library_ok"],
            "executable_ids": [str(x.get("point_id") or "") for x in confirmed]}


# ---------------------------------------------------------------- 确认写入
def _upsert_confirmations(tenant: str, workspace: str, ids: list, criterion: str,
                          scope: list, actor: str, libinfo) -> dict:
    """确认/重确认的唯一写入实现；状态判定复用 snapshot。"""
    ids = _clean_ids(ids)
    if not ids:
        return {"error": "point_ids 不能为空"}
    _lib, ver, pmap = libinfo
    if pmap:
        missing = [x for x in ids if x not in pmap]
        if missing:
            return {"error": f"点位不存在：{', '.join(missing[:3])}"}
    prev = state_index(tenant, workspace, libinfo=libinfo)
    reconfirmed_ids = []
    point_hashes = {}
    now = db.now()
    with db.session() as c:
        for pid in ids:
            p = prev.get(pid) or {"point_id": pid, "status": "template"}
            crit = criterion or ""
            sc = scope
            was_stale = bool(p.get("stale") or str(p.get("status") or "") == "stale")
            if was_stale:
                # 重确认时未显式改判据/范围则沿用原确认，避免静默清空复核内容。
                if not crit:
                    crit = str(p.get("criterion") or "")
                if sc is None:
                    sc = p.get("scope") or []
            if sc is None:
                sc = []
            if p and p.get("stale"):
                reconfirmed_ids.append(pid)
            ph = _point_hash(pmap[pid]) if pid in pmap else ""
            point_hashes[pid] = ph
            c.execute("INSERT INTO auditpoint_confirmation(point_id,tenant_id,workspace_id,status,criterion,"
                      "scope_json,confirmed_by,confirmed_at,library_version,point_hash) VALUES(?,?,?,'confirmed',?,?,?,?,?,?) "
                      "ON CONFLICT(point_id,tenant_id,workspace_id) DO UPDATE SET status='confirmed',"
                      "criterion=excluded.criterion,scope_json=excluded.scope_json,"
                      "confirmed_by=excluded.confirmed_by,confirmed_at=excluded.confirmed_at,"
                      "library_version=excluded.library_version,point_hash=excluded.point_hash",
                      (pid, tenant, workspace, crit, json.dumps(sc, ensure_ascii=False),
                       actor or "", now, ver, ph))
        c.commit()
    return {"ok": True, "updated": len(ids), "status": "confirmed",
            "library_version": ver, "reconfirmed": len(reconfirmed_ids),
            "reconfirmed_ids": reconfirmed_ids, "previous": prev,
            "point_hashes": point_hashes}


def confirm(point_id: str, criterion: str = "", scope: list = None, actor: str = "") -> dict:
    point_id = str(point_id or "").strip()
    if not point_id:
        return {"error": "point_id 必填"}
    t, w = _scope()
    try:
        libinfo = _library()
    except Exception:
        # 写确认必须基于可读取的当前库；否则会写入空版本，后续升级无法识别。
        return {"error": "当前点位库不可用，暂不能确认"}
    _lib, ver, pmap = libinfo
    if pmap and point_id not in pmap:
        return {"error": f"点位不存在：{point_id}"}
    res = _upsert_confirmations(t, w, [point_id], criterion, scope, actor, libinfo)
    if res.get("error"):
        return res
    return {"ok": True, "point_id": point_id, "status": "confirmed",
            "library_version": ver, "point_hash": res["point_hashes"].get(point_id, ""),
            "previous_status": str((res["previous"].get(point_id) or {}).get("status")
                                   or "template"),
            "reconfirmed": point_id in res["reconfirmed_ids"]}


def confirm_many(point_ids: list, criterion: str = "", scope: list = None,
                 actor: str = "") -> dict:
    ids = _clean_ids(point_ids)
    if not ids:
        return {"error": "point_ids 不能为空"}
    t, w = _scope()
    try:
        libinfo = _library()
    except Exception:
        return {"error": "当前点位库不可用，暂不能确认"}
    res = _upsert_confirmations(t, w, ids, criterion, scope, actor, libinfo)
    if res.get("error"):
        return res
    return {"ok": True, "updated": res["updated"], "status": "confirmed",
            "library_version": res["library_version"],
            "reconfirmed": res["reconfirmed"]}


# ---------------------------------------------------------------- 撤销
def _revoke_rows(tenant: str, workspace: str, ids: list) -> tuple[list, list]:
    ids = _clean_ids(ids)
    if not ids:
        return [], []
    q = ",".join("?" for _ in ids)
    with db.session() as c:
        rows = c.execute(f"SELECT point_id FROM auditpoint_confirmation "
                         f"WHERE tenant_id=? AND workspace_id=? AND point_id IN ({q})",
                         (tenant, workspace, *ids)).fetchall()
        existing = {str(r["point_id"]) for r in rows}
        c.execute(f"DELETE FROM auditpoint_confirmation "
                  f"WHERE tenant_id=? AND workspace_id=? AND point_id IN ({q})",
                  (tenant, workspace, *ids))
        c.commit()
    deleted, skipped = [], []
    for pid in ids:
        if pid in existing and pid not in deleted:
            deleted.append(pid)
        elif pid not in existing and pid not in skipped:
            skipped.append(pid)
    return deleted, skipped


def revoke_many(point_ids: list, actor: str = "", workspace: str = "") -> dict:
    ids = _clean_ids(point_ids)
    if not ids:
        return {"error": "point_ids 不能为空"}
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    deleted, skipped = _revoke_rows(t, w, ids)
    return {"ok": True, "updated": len(ids), "revoked": len(deleted),
            "point_ids": deleted, "skipped": skipped, "status": "template"}


def revoke(point_id: str, actor: str = "", workspace: str = "") -> dict:
    pid = str(point_id or "")
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    deleted, _skipped = _revoke_rows(t, w, [pid])
    return {"ok": True, "point_id": point_id, "status": "template",
            "revoked": bool(deleted)}


def sync_stale(workspace: str = "", actor: str = "system") -> dict:
    """显式触发一次库升级 stale 扫描（幂等）；读取/执行入口也会自动触发。"""
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    return _sync_stale(t, w, actor=actor)


# ---------------------------------------------------------------- 待重确认/重确认
def pending_reconfirm(workspace: str = "") -> dict:
    """库升级后的待重确认列表（只读；不会自动确认，也不会放行执行）。"""
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    snap = snapshot(t, w)
    ver = snap["current_library_version"]
    items = [x for x in snap["rows"] if x.get("effective_status") == "stale"]
    try:
        from . import auditpoints
        pmap = auditpoints.point_index()
    except Exception:
        pmap = {}
    for x in items:
        p = pmap.get(str(x.get("point_id") or ""))
        if p is not None:
            x["name"] = getattr(p, "name", "") or ""
            x["category"] = getattr(p, "category", "") or ""
            x["type_id"] = getattr(p, "type_id", "") or ""
        x["reconfirmable"] = bool(ver and p is not None)
    reconfirmable = [x for x in items if x.get("reconfirmable")]
    return {"ok": True, "tenant_id": t, "workspace_id": w,
            "current_library_version": ver,
            "stale_count": len(items), "count": len(items),
            "reconfirmable_count": len(reconfirmable),
            "items": items,
            "pending_reconfirm": reconfirmable,
            "removed": [x for x in items if not x.get("reconfirmable")],
            "message": ("点位库已更新，以下已确认点位需重新确认后才可执行"
                        if items else "没有待重确认点位")}


def reconfirm(point_ids: list = None, criterion: str = "", scope: list = None,
              actor: str = "", workspace: str = "") -> dict:
    """显式重确认 stale 点位；不传 point_ids 时处理当前空间全部待重确认项。"""
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    requested = _clean_ids(point_ids)
    rows = snapshot(t, w)["rows"]
    stale = {str(x.get("point_id") or ""): x
             for x in rows if x.get("effective_status") == "stale"}
    if requested:
        targets = [pid for pid in requested
                   if pid in stale and stale[pid].get("reconfirmable")]
        skipped = [pid for pid in requested if pid not in targets]
    else:
        targets = [pid for pid, x in stale.items() if x.get("reconfirmable")]
        skipped = [pid for pid, x in stale.items() if not x.get("reconfirmable")]
    if not targets:
        return {"ok": True, "updated": 0, "reconfirmed": 0,
                "requested": len(requested), "skipped": skipped,
                "message": "没有待重确认点位"}
    try:
        libinfo = _library()
    except Exception:
        return {"ok": False, "error": "当前点位库不可用，暂不能重确认",
                "updated": 0, "reconfirmed": 0, "requested": len(requested),
                "skipped": skipped}
    res = _upsert_confirmations(t, w, targets, criterion, scope, actor, libinfo)
    if res.get("error"):
        return {**res, "requested": len(requested), "skipped": skipped}
    pending_after = len([x for x in snapshot(t, w)["rows"]
                         if x.get("effective_status") == "stale"
                         and x.get("reconfirmable")])
    return {"ok": True, "updated": res["updated"], "status": "confirmed",
            "library_version": res["library_version"],
            "reconfirmed": res["reconfirmed"], "requested": len(requested),
            "skipped": skipped, "pending_after": pending_after}


def revoke_stale(point_ids: list = None, actor: str = "", workspace: str = "") -> dict:
    """撤销 stale 确认：只删已失效记录；valid/pending_review 一律跳过。

    不传 point_ids 时撤销当前空间全部 stale 确认。撤销后记录回到 template
    （未确认），不会自动重新确认，也不会进入执行集合。
    """
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    requested = _clean_ids(point_ids)
    snap = snapshot(t, w)
    current_version = str(snap["current_library_version"] or "")
    stale = {str(x.get("point_id") or ""): x
             for x in snap["rows"] if x.get("effective_status") == "stale"}
    # 库不可用时只允许撤销此前已经落库的 stale，避免把“暂时无法校验”的确认删掉。
    if not current_version:
        stale = {pid: x for pid, x in stale.items()
                 if str(x.get("status") or "") == "stale"}
    if requested:
        targets = [pid for pid in requested if pid in stale]
        skipped = [pid for pid in requested if pid not in targets]
    else:
        targets = list(stale)
        skipped = []
    deleted = []
    with db.session() as c:
        for pid in targets:
            snap_row = stale[pid]
            cur = c.execute("DELETE FROM auditpoint_confirmation "
                            "WHERE point_id=? AND tenant_id=? AND workspace_id=? "
                            "AND status=? AND COALESCE(library_version,'')=? "
                            "AND COALESCE(point_hash,'')=?",
                            (pid, t, w, snap_row.get("status") or "",
                             snap_row.get("library_version") or "",
                             snap_row.get("point_hash") or ""))
            if (cur.rowcount or 0) > 0:
                deleted.append(pid)
            else:
                skipped.append(pid)
        if deleted:
            c.execute("INSERT INTO audit_log(id,actor,action,object,after_json,created_at,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,?,?,?)",
                      (db.new_id("log"), actor or "system", "point_confirm.stale_revoked",
                       f"{t}/{w}",
                       json.dumps({"current_library_version": current_version,
                                   "count": len(deleted), "point_ids": deleted[:50]},
                                  ensure_ascii=False), db.now(), t, w))
        c.commit()
    return {"ok": True, "revoked": len(deleted), "point_ids": deleted,
            "skipped": skipped, "status": "template",
            "current_library_version": current_version}


def revoke_stale_many(point_ids: list = None, actor: str = "",
                      workspace: str = "") -> dict:
    """revoke_stale 的批量命名别名（与 revoke_many 对称，供 API/CLI 接线）。"""
    return revoke_stale(point_ids, actor=actor, workspace=workspace)


# ---------------------------------------------------------------- 推荐/迁移/启用
def recommended(workspace: str = "") -> dict:
    """按当前空间主文件类型路由出的推荐点位；委托 auditpoints 做取点。"""
    from . import auditpoints
    return auditpoints.recommended_points(workspace)


def confirm_recommended(actor: str = "") -> dict:
    rec = recommended()
    ids = [x["id"] for x in (rec.get("items") or [])]
    if not ids:
        return {"ok": False, "error": "当前空间没有可推荐点位", "count": 0}
    return {**confirm_many(ids, "推荐确认", actor=actor), "recommended": len(ids)}


def stale_for_case(case_id: str, notify: bool = True) -> dict:
    """旧点位判据结果汇总；可发一次去重通知。"""
    from .. import repositories as R
    case = R.cases.get(case_id) or {}
    if not case:
        return {"error": "项目不存在"}
    cur = library_version()
    rid = str(case.get("last_run_id") or "")
    fs = R.findings.by_case(case_id)
    if rid:
        fs = [f for f in fs if str(f.get("run_id") or "") == rid or str(f.get("engine") or "") == "manual"]
    stale = [f for f in fs if str(f.get("point_library_version") or "") and cur and
             str(f.get("point_library_version") or "") != cur]
    out = {"ok": True, "case_id": case_id, "current_library_version": cur,
           "run_id": rid, "stale_count": len(stale),
           "points": sorted({str(f.get("point_id") or f.get("rule_id") or "") for f in stale if (f.get("point_id") or f.get("rule_id"))}),
           "finding_ids": [f.get("id") for f in stale]}
    if notify and stale:
        try:
            from . import notify as _n
            key = f"{case_id}|{cur}"
            logs = R.audit_logs.list("action=? AND object=?", ("point.stale_notified", key), limit=1)
            if not logs:
                owner = case.get("created_by") or ""
                title = f"点位判据已更新：{case.get('name') or case_id}"
                detail = f"{len(stale)} 条发现基于旧点位判据；请重新确认点位或重跑审核。"
                if owner:
                    _n.notify(owner, "point.stale", title, detail)
                try:
                    _n.notify_role("admin", "point.stale", title, detail,
                                   tenant_id=case.get("tenant_id") or "")
                except Exception:
                    pass
                R.audit_logs.log(actor="system", action="point.stale_notified", object=key,
                                 after=detail)
                out["notified"] = True
        except Exception:
            pass
    return out


def prepare_migration(workspace: str, actor: str = "") -> dict:
    """旧空间迁移：只生成 pending_review，不自动确认；启用门禁前不改变执行。"""
    from . import auditpoints, workspaces
    t, w = _workspace_scope(workspace)
    # 先经 snapshot 识别已过期确认并落 stale，避免把 stale 误报成 existing。
    snap = snapshot(t, w)
    rec = auditpoints.recommended_points(w)
    ids = [x["id"] for x in rec.get("items") or []]
    existing_rows = {str(x.get("point_id") or ""): x for x in snap["rows"]}
    ver = snap["current_library_version"]
    try:
        pmap = auditpoints.point_index()
    except Exception:
        pmap = {}
    created, existing, stale_existing = 0, 0, 0
    with db.session() as c:
        for pid in ids:
            row = existing_rows.get(pid)
            if row:
                existing += 1
                if row.get("effective_status") == "stale":
                    stale_existing += 1
                continue
            ph = auditpoints.point_hash(pmap[pid]) if pid in pmap else ""
            c.execute("INSERT INTO auditpoint_confirmation(point_id,tenant_id,workspace_id,status,criterion,"
                      "scope_json,confirmed_by,confirmed_at,library_version,point_hash) "
                      "VALUES(?,?,?,'pending_review','','[]',?,?,?,?)",
                      (pid, t, w, actor or "", db.now(), ver, ph))
            created += 1
        c.commit()
    return {"ok": True, "tenant_id": t, "workspace_id": w,
            "recommended": len(ids),
            "pending_created": created, "existing": existing,
            "stale_existing": stale_existing,
            "required": bool((workspaces.get_settings(w) or {}).get("point_confirm_required")),
            "message": "已生成待确认点位；确认后请显式启用门禁"}


def activate_workspace(workspace: str, actor: str = "") -> dict:
    """显式启用点位确认门禁；不自动确认任何 pending 点位。"""
    from . import workspaces
    if workspace:
        t, w = _workspace_scope(workspace)
    else:
        t, w = _scope()
    cur = workspaces.get_settings(w) or {}
    if not cur.get("point_confirm_required"):
        workspaces.save_settings(w, {"point_confirm_required": True})
    snap = snapshot(t, w)
    rows = snap["rows"]
    pending = sum(1 for x in rows if x.get("effective_status") == "pending_review")
    confirmed = sum(1 for x in rows if x.get("effective_status") == "confirmed")
    stale = sum(1 for x in rows if x.get("effective_status") == "stale")
    with db.session() as c:
        c.execute("INSERT INTO audit_log(id,actor,action,object,after_json,created_at,tenant_id,workspace_id) "
                  "VALUES(?,?,?,?,?,?,?,?)",
                  (db.new_id("log"), actor or "system", "point_confirm.activated", w,
                   f"pending={pending},confirmed={confirmed},stale={stale}", db.now(), t, w))
        c.commit()
    return {"ok": True, "workspace_id": w, "tenant_id": t, "required": True,
            "pending_review": pending, "confirmed": confirmed, "stale": stale}


# ---------------------------------------------------------------- 执行门禁
def allowed_ids() -> set:
    """已确认且未 stale 的点位；是否启用门禁由 filter_points 判断。

    读取失败时返回空集合（fail-closed）：门禁开启后宁可暂不执行，也不把
    无法校验的确认静默放行。
    """
    try:
        return {str(x.get("point_id") or "") for x in snapshot()["rows"]
                if x.get("effective_status") == "confirmed"}
    except Exception:
        _LOG.warning("point confirmation allowed_ids failed", exc_info=True)
        return set()


def execution_gate(points: list) -> dict:
    """【执行取点唯一权威】一次 snapshot 算出 selected/required/blocked。

    auditpoints.execution_selection() 必须调用本函数，不自行判断 confirmed/stale。
    读取确认状态失败时：有租户/空间上下文 → fail-closed；无上下文的历史脚本
    没有门禁可读 → 保持旧行为放行。
    """
    pts = list(points or [])
    if not pts:
        return {"ok": True, "points": [], "required": False, "blocked_ids": [],
                "library_version": library_version(), "error": ""}
    # 门禁关闭时保持旧行为：直接放行，不再读确认表（也避免无谓的 stale 扫描）。
    # 门禁设置读取失败：有上下文时 fail-closed，无上下文的历史脚本保持放行。
    try:
        required = _required_strict()
    except Exception:
        _LOG.warning("point confirmation gate read failed", exc_info=True)
        t, w = _scope()
        ids = [str(p.get("id") or "") for p in pts]
        if t or w:
            return {"ok": False, "points": [], "required": True, "blocked_ids": ids,
                    "library_version": "", "error": "确认状态不可用"}
        return {"ok": True, "points": pts, "required": False, "blocked_ids": [],
                "library_version": "", "error": ""}
    if not required:
        return {"ok": True, "points": pts, "required": False, "blocked_ids": [],
                "library_version": library_version(), "error": ""}
    try:
        snap = snapshot()
    except Exception:
        _LOG.warning("point confirmation gate read failed", exc_info=True)
        t, w = _scope()
        ids = [str(p.get("id") or "") for p in pts]
        if t or w:
            return {"ok": False, "points": [], "required": True, "blocked_ids": ids,
                    "library_version": "", "error": "确认状态不可用"}
        return {"ok": True, "points": pts, "required": False, "blocked_ids": [],
                "library_version": "", "error": ""}
    # 进入快照前已经确认门禁开启；读取期间 settings 抖动也不能回退为放行。
    required = True
    allowed = {str(x.get("point_id") or "") for x in snap["rows"]
               if x.get("effective_status") == "confirmed"}
    selected, blocked = [], []
    for p in pts:
        pid = str(p.get("id") or "")
        if pid in allowed:
            selected.append(p)
        else:
            blocked.append(pid)
    return {"ok": True, "points": selected, "required": required,
            "blocked_ids": blocked,
            "library_version": str(snap.get("current_library_version") or ""),
            "error": ""}


def filter_points(points: list) -> list:
    """仅在空间要求点确认时过滤；默认兼容旧行为，不静默改变。"""
    return execution_gate(points)["points"]
