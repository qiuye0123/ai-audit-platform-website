# -*- coding: utf-8 -*-
"""直接影子召回 + 候选验证 + 证据归并/定位修复 + 路由补齐（准确率线）。

为什么需要这一层
----------------
平台主链是「manifest 冻结 → D1~D5 逐点位判定 → finding」；在真实注入基准上暴露
三类系统性损失（不是“模型完全不判”）：

1. 路由损失：审核类型不在 69 类路由内时规则被 ``audit_type_not_routed`` 排除，
   manifest 根本不执行，且旧链路只写入 gate，属于“静默丢规则”。
2. 逐点判定的 na 误判：每个点位单独一次模型调用 + 固定系统提示，对“条款没有
   被点名但确实与批准条件不一致”的情况倾向判 na（注入基准 27 个冻结 item 中 8 条）。
3. 证据串位：码对、结论 fail，但 finding 引文引到相邻问题条款，按条目口径计 FN/FP。

本模块在产品链路末尾增加一个“直接影子召回层”（默认关闭，分级开启）：

* 召回：用与直连大模型同构的「全文 + 本轮允许规则判据」LLM 生成候选
  （JSON：point_code/location/evidence/issue/correction/confidence）。取数边界
  不是全库 published 规则，而是 ``_allowed_rule_set``：manifest 冻结允许集合
  （租户/空间/审核范围/有效版本）＋需要扩大范围时经 ``_create_manifest_supplement``
  登记的有审计补充版本。
* 验证：候选必须过 ``accuracy_validator`` 的“引文逐字回查 + 规则判据 + 已批准
  条件（同编号 SW 条款）对抗式双票复核”，两票一致才回填。
* 归并：同规则同事项已有 finding 时去重/补证；同规则不同事项或不同对象是两条
  独立 occurrence（finding 标识带 occurrence_id/object_id/rule_version），不按
  rule_code/引文前缀合并吞定位。
* 路由补齐：``audit_type_not_routed`` 的规则不再静默丢——显式记录、创建有审计的
  manifest 补充版本后交给影子层召回；同时从审核 DAG 的 customer_rule 补跑中排除
  这些码，避免 manifest/DAG 双跑产生重复或串位 finding。

裁决边界（2026-11-17 架构裁决，优先于覆盖率优化）
--------------------------------------------------
增强层可以“补充候选、提出复核、降低漏报”，不能“推翻主链结论、静默移出 finding、
绕过 manifest 冻结”。因此默认行为是：

* 影子层未覆盖的 D5 fail finding：保留主链结论，标 ``shadow_coverage=missing``
  并写 ``finding.shadow_coverage_missing`` 审计；语义来源再标 ``needs_review=true``，
  确定性执行器来源不标待复核；**不 demote、不移出清单、不删证据链**。
* 历史“影子未复现→降级 insufficient”行为已于 build49 B1 彻底删除（原隐藏 legacy demote 开关读取点移除），不再提供 legacy demote 通道。
* 同规则不同事项候选独立落条后，原 finding 只标 ``needs_review`` 与
  ``finding.shadow_split_conflict`` 审计，不改变原结论。

分级开关（环境变量）
--------------------
``RULEPROOF_ACCURACY_MODE``：0=关闭（默认）1=影子召回 2=+验证/归并/路由补齐/
覆盖标记 3=+同码多条款候选重判/第二轮召回（自建“超越直连”能力）。也可用
``RULEPROOF_ACCURACY_SHADOW=1`` 等价 MODE=1；单项覆盖：
``RULEPROOF_ACCURACY_VALIDATE/ANCHOR/ROUTE/RECLASSIFY/SPLIT/COVERAGE_MARK/RETAIN=0|1``；
``RULEPROOF_ACCURACY_RECALL_ROUNDS``（MODE>=3 默认 2）。

诚实边界
--------
本层是“高召回候选层 + 候选复核层”，不是绕过人工复核的裁决层：回填的 finding
状态仍是 pending，必须走人工复核；候选复核只使用规则判据、文档内已批准条件与
原文，不使用任何 gold/标准答案字段。模型不可用、JSON 解析失败、引文回查失败
一律 fail-closed（不产生 finding）。

## T-202 唯一主链与唯一入口（2026-11-20）
本模块在双轨主链中**降级为第 5 步：只读标注器**——只给 finding 标
``shadow_coverage=covered/missing``（及补候选/审计），**不参与分区决策**
（formal/shadow/discarded 由 :mod:`app.services.shadow_pool` 唯一仲裁）。
产品代码只能经 ``app.services.dual_track_gateway``（``shadow_recall`` /
``route_repair`` / ``coverage_mark_enabled``）调用本模块；职责边界见
``docs/qa/双轨唯一入口约束_20261120.md``。
"""
from __future__ import annotations

import json
import logging
import os
import re
import time

from .. import db
from .. import repositories as R
from ..severity import from_rclass as sev_from_rclass
from . import accuracy_validator as _val

log = logging.getLogger(__name__)

_ASSESS_VERSION = "accuracy-shadow-20261117"
_LAST_STATS = {}

# 候选决策口径：
# - 已验证并进入系统：added/anchored/duplicate/kept/reclassified（交叉一致性门的 corroborated）
# - 覆盖保留：retained_insufficient（低置信 finding）/ retained_supplementary（并入既有 finding）
_VERIFIED_DECISIONS = ("added", "anchored", "duplicate", "kept", "reclassified", "split_added")
_RETAINED_DECISIONS = ("retained_insufficient", "retained_supplementary")


# ---------------------------------------------------------------------------
# 一、开关
# ---------------------------------------------------------------------------
def _flag(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None or str(v).strip() == "":
        return bool(default)
    return str(v).strip().lower() in ("1", "true", "yes", "on", "y")


def mode() -> int:
    raw = os.environ.get("RULEPROOF_ACCURACY_MODE")
    if raw is not None and str(raw).strip() != "":
        try:
            return max(0, min(3, int(str(raw).strip())))
        except Exception:
            return 0
    return 1 if _flag("RULEPROOF_ACCURACY_SHADOW", False) else 0


def enabled() -> bool:
    return mode() >= 1


def validator_enabled() -> bool:
    return _flag("RULEPROOF_ACCURACY_VALIDATE", mode() >= 2)


def anchor_enabled() -> bool:
    return _flag("RULEPROOF_ACCURACY_ANCHOR", mode() >= 2)


def route_repair_enabled() -> bool:
    return _flag("RULEPROOF_ACCURACY_ROUTE", mode() >= 2)


def reclassify_enabled() -> bool:
    return _flag("RULEPROOF_ACCURACY_RECLASSIFY", mode() >= 3)


def retain_enabled() -> bool:
    """覆盖保留开关：MODE>=3 默认开，可单独用 RULEPROOF_ACCURACY_RETAIN=0 关闭。

    只对“双票不一致但正票已确认矛盾、反票仅给出可辩护解释”的被拒候选生效，且仍要求
    本轮 manifest D5=fail、引文逐字回查通过；保留结果是 state=insufficient 的低置信
    证据（等人工复核），不是放宽双票验证、不是把候选当已判定违规。
    """
    return _flag("RULEPROOF_ACCURACY_RETAIN", mode() >= 3)






def coverage_mark_enabled() -> bool:
    """影子覆盖标记（MODE>=2 默认开）：给 D5 fail finding 标 shadow_coverage。

    covered=影子层有已验证候选复现；missing=影子层未覆盖（不 demote，只标注并写
    审计）。这是默认裁决边界：主链结论保留，标出“增强层没有复现”供人工复核。
    """
    return _flag("RULEPROOF_ACCURACY_COVERAGE_MARK", mode() >= 2)


def split_enabled() -> bool:
    """同码不同条款独立落 finding（MODE>=2 默认开，可单独关闭）。

    架构裁决：同规则两个独立条款/对象违规必须保留两条 finding occurrence，不得
    按 rule_code/引文前缀合并吞定位（finding 标识带 object_id/rule_version）。
    归并层原来把“同规则、不同条款”的已验证候选一律并进既有 finding 补充证据；
    基准匹配是一对一 finding ↔ gold，一条 finding 只能命中一个 gold，第二个条款
    的定位会被吞掉（实测 Q13：E02-005 的 TK-1049 finding 先被 Q07 命中，TK-1091
    的定位覆盖丢失）。拆分以“证据事项（同编号 SW/TK）+ 对象（document_id）”为
    单位独立落条；只有“证据事项已被另一条不同规则码 finding 覆盖”的原 finding
    才按证据不足降级（D4 串位/同事项重复，不删除证据链、写审计）。
    """
    return _flag("RULEPROOF_ACCURACY_SPLIT", mode() >= 2)


def recall_rounds() -> int:
    """直接影子召回轮数（MODE>=3 默认 2 轮，可单独覆盖）。

    单次全文召回受采样影响会漏审核点（实测 G-NEW-01/F09-002 在部分轮次从未被
    生成）；第二轮只针对“第一轮没有任何候选”的残余审核点做逐条复核，补生成后
    与第一轮候选一起进入同一套逐字回查/双票验证/归并，不降低验证门槛。
    """
    raw = os.environ.get("RULEPROOF_ACCURACY_RECALL_ROUNDS")
    if raw is not None and str(raw).strip() != "":
        try:
            return max(1, min(3, int(str(raw).strip())))
        except Exception:
            pass
    return 2 if mode() >= 3 else 1


def mode_name() -> str:
    return {0: "off", 1: "shadow-recall", 2: "validated", 3: "reclassified"}.get(mode(), "off")


def _timeout(name: str, default: int) -> int:
    try:
        return max(5, int(os.environ.get(name) or default))
    except Exception:
        return default


# ---------------------------------------------------------------------------
# 二、文档与规则读取
# ---------------------------------------------------------------------------
def _doc_texts(docs: list) -> list:
    """读取每个文档的解析全文（复用 agent-parse 产物，不重复解析）。"""
    out = []
    for d in docs or []:
        path = d.get("path") or ""
        if not path:
            continue
        txt = ""
        try:
            from . import audit_intake
            p = audit_intake.ensure_parsed(path)
            txt = ((p or {}).get("doc") or {}).get("text") or ""
        except Exception:
            log.debug("accuracy shadow ensure_parsed skipped", exc_info=True)
        if not txt:
            # 结构化表格（xlsx 等）通常没有 agent-parse 文本，直接复用引擎解析结果，
            # 否则影子层会在多 Sheet 工艺书上静默跳过。
            try:
                from ..engine import deepparse
                txt = deepparse.parse_document(str(path)).text or ""
            except Exception:
                log.debug("accuracy shadow deepparse skipped", exc_info=True)
        if txt:
            out.append({"document_id": d.get("id") or "", "filename": d.get("filename") or
                        d.get("name") or str(path).rsplit("/", 1)[-1], "text": txt})
    return out


def _rule_record(row: dict) -> dict:
    """把一条规则行 + 已发布版本 slots 归一成影子层规则描述。"""
    code = str(row.get("code") or "")
    try:
        v = R.rules.published_version(row["id"]) or {}
        slots = json.loads(v.get("slots_json") or "{}")
    except Exception:
        slots, v = {}, {}
    crit = str(slots.get("criterion") or slots.get("requirement") or
               slots.get("description") or row.get("name") or "")
    subs = slots.get("subrequirements") if isinstance(slots, dict) else None
    return {"rule_id": row.get("id") or "", "code": code,
            "name": str(row.get("name") or code), "criterion": crit,
            "required_evidence": str(slots.get("required_evidence") or "原文"),
            "rclass": str(row.get("rclass") or ""),
            "category": str(row.get("category") or ""),
            "version": str((v or {}).get("version") or ""),
            "version_id": str((v or {}).get("id") or ""),
            "subrequirements": subs if isinstance(subs, list) else [],
            "scope_source": "manifest_frozen"}


def _rules_for_codes(codes: list) -> list:
    """只按“本轮允许的审核点集合”查规则，不直接全库 published 规则。

    影子层是增强层，取数必须与 manifest 冻结的租户/空间/审核范围一致；这里用
    ``code IN (...)`` 受控查询，并在返回里带 rule_version 供 finding 追溯。
    """
    codes = [str(c) for c in codes if str(c).strip()]
    if not codes:
        return []
    ph = ",".join("?" * len(codes))
    try:
        from . import rule as _rule_scope
        rows = _rule_scope.effective_rule_rows(f"code IN ({ph})", tuple(codes))
    except Exception:
        rows = []
    by_code = {str(r.get("code") or ""): r for r in rows}
    out = []
    for code in dict.fromkeys(codes):
        row = by_code.get(code)
        if not row:
            continue
        out.append(_rule_record(row))
    return out


def _published_rules() -> list:
    """兼容旧调用：当前空间全部已发布规则。

    .. deprecated:: 2026-11-17
       影子层不再使用全库规则；``recall`` 通过 ``_allowed_rule_set`` +
       ``_rules_for_codes`` 只取 manifest 冻结允许集合（+ 有审计的补充版本）。
    """
    try:
        from . import rule as _rule_scope_pub
        rows = _rule_scope_pub.effective_rule_rows()  # T-171 生效口径（默认 0=旧行为）
    except Exception:
        rows = []
    return [_rule_record(r) for r in rows if str(r.get("code") or "")]


def _manifest_item_codes(items: list) -> list:
    """manifest 冻结清单里的审核点 = 本次允许的基础规则集合。"""
    out, seen = [], set()
    for it in items or []:
        code = str(it.get("rule") or it.get("code") or "")
        rid = str(it.get("rule_id") or "")
        if not code or code in seen:
            continue
        seen.add(code)
        out.append({"code": code, "rule_id": rid, "source": "manifest_frozen"})
    return out


def _create_manifest_supplement(case_id: str, run_id: str, base: list,
                                extra: list, route_ctx: dict) -> dict:
    """为影子层“扩大审核范围”新建有审计的 manifest 补充版本。

    主 manifest 冻结快照不可变：影子层需要复核被路由出 manifest 的规则（例如
    ``audit_type_not_routed``）时，不直接读全库规则，而是把补充集合登记为一个
    明确带 base_manifest_id、规则版本、路由原因、操作者的补充版本，并写
    ``audit_logs(action=manifest.supplement)``；候选 finding 的证据与
    rule_version 均指向该补充集合中的具体规则版本，可回溯。
    """
    base_codes = {str(x.get("code") or "") for x in (base or [])}
    base_manifest_id = ""
    try:
        run_row = R.audit_runs.get(run_id) or {}
        base_manifest_id = str(run_row.get("manifest_id") or "")
    except Exception:
        base_manifest_id = ""
    codes = []
    for x in (extra or []):
        code = str(x.get("code") or "")
        if not code or code in base_codes:
            continue
        ver, rows = {}, []
        try:
            from . import rule as _rule_scope_sup
            rows = _rule_scope_sup.effective_rule_rows("code=?", (code,))
            if rows:
                ver = R.rules.published_version(rows[0]["id"]) or {}
        except Exception:
            ver, rows = {}, []
        codes.append({"code": code, "rule_id": str((rows[0] if rows else {}).get("id") or ""),
                      "version": str((ver or {}).get("version") or ""),
                      "version_id": str((ver or {}).get("id") or ""),
                      "route_reason": str(x.get("reason") or ""),
                      "source": "manifest_supplement"})
    if not codes:
        return {"created": False, "codes": []}
    import hashlib
    sig = hashlib.sha256(json.dumps(
        {"case": case_id, "run": run_id, "base": base_manifest_id,
         "codes": [c["code"] for c in codes]}, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    rec = {
        "supplement_id": f"msup-{sig}", "case_id": case_id, "run_id": run_id,
        "base_manifest_id": base_manifest_id,
        "created_at": db.now(), "actor": "system",
        "reason": "影子层增强召回需要显式扩大审核范围（路由丢失/路由外规则）",
        "source": "accuracy_shadow.route_repair",
        "mode": mode(), "version": _ASSESS_VERSION,
        "codes": codes,
    }
    try:
        from . import sysconfig as _sc
        _sc.set_many({f"manifest_supplement:{case_id}:{run_id}":
                      json.dumps(rec, ensure_ascii=False)})
    except Exception:
        log.debug("manifest supplement persist skipped", exc_info=True)
    try:
        R.audit_logs.log(
            actor="system", action="manifest.supplement",
            object=rec["supplement_id"],
            after=json.dumps({**{k: rec[k] for k in ("case_id", "run_id",
                                                     "base_manifest_id", "reason", "mode")},
                              "codes": codes}, ensure_ascii=False))
    except Exception:
        log.debug("manifest supplement audit skipped", exc_info=True)
    return {"created": True, **rec}


def _allowed_rule_set(case_id: str, run_id: str, items: list,
                      route_ctx: dict, stats: dict) -> tuple:
    """影子层取数边界：manifest 冻结允许集合 +（需要时）有审计的补充版本。

    返回 (rules, allow_meta)。不读全库 published 规则；manifest 之外的规则只有经
    ``_create_manifest_supplement`` 登记后才允许进入召回。
    """
    allow = _manifest_item_codes(items)
    lost = list((route_ctx or {}).get("codes") or [])
    supplement = {"created": False, "codes": []}
    if lost:
        try:
            supplement = _create_manifest_supplement(case_id, run_id, allow,
                                                     [{"code": c, "reason": "audit_type_not_routed"}
                                                      for c in lost], route_ctx)
        except Exception as e:
            log.warning("manifest supplement failed: %s", e)
            stats["errors"].append(f"supplement:{type(e).__name__}: {str(e)[:120]}")
    codes = [x["code"] for x in allow]
    for x in (supplement.get("codes") or []):
        if x["code"] not in codes:
            codes.append(x["code"])
    allow_meta = {
        "isolation": "manifest_allowed_rule_set",
        "manifest_items": len(allow),
        "manifest_codes": [x["code"] for x in allow],
        "supplement_created": bool(supplement.get("created")),
        "supplement_id": supplement.get("supplement_id") or "",
        "supplement_base_manifest_id": supplement.get("base_manifest_id") or "",
        "supplement_codes": [x["code"] for x in (supplement.get("codes") or [])],
        "allow_total": len(codes),
    }
    stats["allowed_rule_set"] = allow_meta
    if not codes:
        return [], allow_meta
    rules = _rules_for_codes(codes)
    # 补充集合（路由外）的规则标记来源，供 finding 证据/统计区分
    supp = set(allow_meta["supplement_codes"])
    for r in rules:
        if r["code"] in supp:
            r["scope_source"] = "manifest_supplement"
    return rules, allow_meta


def _brief_lines(rules: list) -> list:
    lines = []
    for r in rules:
        lines.append(f"【{r['code']}】{r['name']}\n规则描述：{r['criterion'][:600]}\n"
                     f"所需证据：{r['required_evidence']}")
    return lines


# ---------------------------------------------------------------------------
# 三、直接影子召回（与直连大模型同构的“全文+全部规则”一次生成）
# ---------------------------------------------------------------------------
_SHADOW_SYSTEM = (
    "你是文件商务条款审核器。给你一份文件的审核点规则清单和文件全文，"
    "请逐条核查文件中的拟定执行条款/具体约定是否与已批准条件或规则判据一致。\n"
    "要求：\n"
    "1. 只输出 JSON 数组，不要输出解释、Markdown 代码块或其它文字。\n"
    "2. 每个问题一项：{\"point_code\":\"审核点编号\",\"location\":\"条款编号（如 TK-1007；无编号留空）\","
    "\"evidence\":\"原文中真实存在的连续片段（逐字复制，不得改写）\","
    "\"issue\":\"问题一句话\",\"correction\":\"应如何修正一句话\",\"confidence\":0到1}。\n"
    "3. 只针对给定审核点清单判断，不得自行增加审核规则；没有问题就不输出该项。\n"
    "4. evidence 必须能在文件原文中逐字找到；找不到证据时不要输出该项。\n"
    "5. 文件可能包含“已批准商务条件”和“拟定执行条款”，同编号事项互相配套；"
    "最后可能有参考范本正文，正文仅作参考、不是被审对象。"
)


def _build_prompt(combined_text: str, rules: list) -> tuple:
    user = ("审核点规则清单（非结构化描述）：\n" + "\n\n".join(_brief_lines(rules)) +
            "\n\n文件全文：\n" + combined_text[:60000])
    return _SHADOW_SYSTEM, user


_RESIDUAL_SYSTEM = (
    "你是文件商务条款审核器的第二遍复核员。第一遍已按审核点清单扫描全文，但可能漏项。"
    "现在只给你第一遍未发现问题的审核点清单和文件全文，请逐条严格复核。\n"
    "要求：\n"
    "1. 只输出 JSON 数组，不要输出解释、Markdown 代码块或其它文字。\n"
    "2. 每个问题一项：{\"point_code\":\"审核点编号\",\"location\":\"条款编号（如 TK-1007；无编号留空）\","
    "\"evidence\":\"原文中真实存在的连续片段（逐字复制，不得改写）\","
    "\"issue\":\"问题一句话\",\"correction\":\"应如何修正一句话\",\"confidence\":0到1}。\n"
    "3. 只针对给定审核点清单判断，不要引用清单外的审核点；没有问题就不输出该项；"
    "找不到逐字证据时不要输出。\n"
    "4. 逐条核对：即使条款看起来正常，也要核对金额、比例、基数、期间、条件、"
    "计算结果是否与已批准条件/判据一致。\n"
    "5. 文件可能包含“已批准商务条件”和“拟定执行条款”，同编号事项互相配套；"
    "最后可能有参考范本正文，正文仅作参考、不是被审对象。"
)


def _build_residual_prompt(combined_text: str, rules: list) -> tuple:
    """第二遍召回的提示词：只给“第一轮未生成候选”的审核点，逐条复核。

    第一轮是“全文 + 全部规则”的一次生成，模型采样会整点漏项（实测 F09-002 在
    部分轮次完全没有候选）。第二轮把残余审核点单独列出再核一遍，生成结果仍要
    过同一套逐字回查 + 双票验证，不降低门槛、不直接回填 finding。
    """
    user = ("第一遍未发现问题的审核点清单：\n" + "\n\n".join(_brief_lines(rules)) +
            "\n\n文件全文：\n" + combined_text[:60000])
    return _RESIDUAL_SYSTEM, user


def _parse_raw_candidates(raw: str) -> list:
    txt = (raw or "").strip()
    if not txt:
        return []
    obj = None
    try:
        obj = json.loads(txt)
    except Exception:
        dec = json.JSONDecoder()
        for start in (txt.find("["), txt.find("{")):
            if start < 0:
                continue
            try:
                obj, _ = dec.raw_decode(txt[start:])
                break
            except Exception:
                continue
    if isinstance(obj, dict):
        for k in ("findings", "issues", "problems", "items", "results"):
            if isinstance(obj.get(k), list):
                obj = obj[k]
                break
        else:
            obj = [obj] if any(k in obj for k in ("point_code", "code", "issue")) else []
    return [x for x in obj if isinstance(x, dict)] if isinstance(obj, list) else []


_CODE_RE = re.compile(r"\b([A-Z]\d{2}-\d{3})\b")


def _code_token_re():
    return re.compile(r"[A-Za-z][A-Za-z0-9]*(?:[-_][A-Za-z0-9]+)*")


def _resolve_code(item: dict, rules: list) -> str:
    """把模型输出的 point_code/code 归一到已发布规则码。

    不同行业的规则码形态不同：BX 基准是 ``F09-001``，食品基准是 ``FB-01`` /
    ``FOOD01-001`` / 内置执行器 ``RW20260525005``、``B-2``。这里先用规则码集合
    做精确 token 匹配（避免只认一种编码形态导致候选全被判 invalid_code），
    再退回规则名称匹配。
    """
    codes = {str(r.get("code") or "") for r in rules if r.get("code")}
    raw = str(item.get("point_code") or item.get("code") or item.get("point_id") or "").strip()
    if raw in codes:
        return raw
    for tok in _code_token_re().findall(raw):
        if tok in codes:
            return tok
    blob = json.dumps(item, ensure_ascii=False)
    tag = str(item.get("point_code") or item.get("code") or "").strip()
    if tag and tag in codes:
        return tag
    for tok in _code_token_re().findall(blob):
        if tok in codes:
            return tok
    m = _CODE_RE.search(blob)
    if m and m.group(1) in codes:
        return m.group(1)
    for r in rules:
        name = str(r.get("name") or "")
        if name and len(name) >= 4 and name in blob:
            return r["code"]
    return ""


def _normalize_candidates(raw_items: list, combined_text: str, idx: dict,
                           rules: list, stats: dict) -> list:
    by_code = {r["code"]: r for r in rules}
    seen = set()
    out = []
    for it in raw_items:
        stats["raw_entries"] += 1
        code = _resolve_code(it, rules)
        if not code or code not in by_code:
            stats["rejected_invalid_code"] += 1
            continue
        quote = str(it.get("evidence") or it.get("quote") or
                    it.get("injected_text") or "").strip()
        hit = _val.locate_quote(combined_text, quote)
        if not hit:
            stats["rejected_quote_not_verbatim"] += 1
            continue
        canonical = hit["quote"]
        clause = _val.clause_of(idx, canonical)
        if clause and clause.get("kind") == "template":
            stats["rejected_template_body"] += 1
            continue
        location = str(it.get("location") or "").strip() or (clause.get("id") or "")
        if location and idx.get("by_id") and location not in idx["by_id"]:
            # 模型给的条款号在文档里不存在：不直接失败，保留引文可回查的候选，
            # 但记录为 location_unverified，避免把“编条款号”当定位证据。
            stats["location_unverified"] += 1
        key = (code, _val._nz(canonical)[:48])
        if key in seen:
            stats["rejected_duplicate"] += 1
            continue
        seen.add(key)
        rec = {
            "code": code, "rule_name": by_code[code]["name"],
            "location": location,
            "clause_id": (clause or {}).get("id") or "",
            "quote": canonical,
            "issue": str(it.get("issue") or it.get("description") or it.get("reason") or "")[:600],
            "correction": str(it.get("correction") or "")[:400],
            "confidence": _num(it.get("confidence"), 0.75),
            "raw": it,
        }
        if not rec["issue"]:
            rec["issue"] = by_code[code]["criterion"][:200]
        out.append(rec)
    return out


def _num(v, default: float) -> float:
    try:
        f = float(v)
        return max(0.0, min(1.0, f))
    except Exception:
        return default


# ---------------------------------------------------------------------------
# 四、finding 归并 / 证据补全
# ---------------------------------------------------------------------------
def _entry_code(f: dict) -> str:
    return str(f.get("rule_code") or f.get("code") or f.get("point_id") or "").strip()


def _entry_quotes(f: dict) -> list:
    out = []
    for ev in (f.get("evidence") or []):
        if isinstance(ev, dict):
            q = str(ev.get("quote") or ev.get("excerpt") or "")
        else:
            q = str(ev or "")
        if q:
            out.append(q)
    return out


def _quote_overlap(a: str, quotes: list) -> bool:
    na = _val._nz(a)
    if len(na) < 8:
        return False
    for q in quotes:
        nq = _val._nz(q)
        if not nq:
            continue
        if na in nq or nq in na:
            return True
        # 长公共片段（避免同一段文本不同截断被误判为不同条款）
        if len(na) >= 20:
            for i in range(0, len(na) - 19, 10):
                if na[i:i + 20] in nq:
                    return True
    return False


def _pick_doc(doc_texts: list, quote: str) -> dict:
    nq = _val._nz(quote)
    for d in doc_texts:
        if nq and nq in _val._nz(d["text"]):
            return d
    return doc_texts[0] if doc_texts else {}


def _insert_finding(case_id: str, run_id: str, rule: dict, cand: dict,
                    doc_texts: list) -> str:
    """落一条 finding。

    ``cand["retained"]`` 为真时是“覆盖保留”的低置信证据：state=insufficient、
    certainty=abstain、标题/摘要显式标注【低置信覆盖保留】并需人工复核，confidence
    不高于 0.45（不把候选包装成已判定违规）。默认路径行为不变（state=fail）。
    """
    fid = db.new_id("fnd")
    sev = sev_from_rclass(rule.get("rclass") or "")
    retained = bool(cand.get("retained"))
    title = str(rule.get("name") or cand.get("code") or "候选问题")[:80]
    loc = cand.get("clause_id") or cand.get("location") or ""
    body = (f"【定位 {loc}】" if loc else "") + str(cand.get("issue") or "")[:420]
    if cand.get("correction"):
        body += f"（建议：{str(cand['correction'])[:100]}）"
    if retained:
        title = ("【低置信覆盖保留】" + title)[:96]
        summary = ("【低置信覆盖保留|证据不足|需人工复核】双票不一致：正票已确认存在明确"
                   "矛盾，反票仅给出可辩护解释；按覆盖保留进入人工复核，不代表平台已判定违规。"
                   + body)[:500]
        certainty, state = "abstain", "insufficient"
        confidence = round(min(_num(cand.get("confidence"), 0.3), 0.45), 3)
    else:
        summary, certainty, state = body[:500], "probable", "fail"
        confidence = cand.get("confidence")
    doc = _pick_doc(doc_texts, cand.get("quote") or "")
    object_id = str(doc.get("document_id") or cand.get("object_id") or "")
    clause_id = str(cand.get("clause_id") or cand.get("location") or "")
    # 架构裁决：finding 标识必须带 occurrence/object/rule_version，同规则不同条款
    # 或不同对象是两条独立 occurrence，不按 rule_code/引文前缀合并吞定位。
    occurrence_id = f"{cand['code']}:{object_id or '-'}:{clause_id or '-'}"
    rule_version = str(rule.get("version") or cand.get("rule_version") or _ASSESS_VERSION)
    R.findings.insert(
        id=fid, case_id=case_id, rule_id=cand["code"], rule_version=rule_version,
        severity=sev, certainty=certainty, confidence=confidence,
        state=state, status="pending", title=title, summary=summary,
        suggestion="", engine="accuracy_shadow", run_id=run_id,
        object_id=object_id, occurrence_count=1,
        occurrence_ids_json=json.dumps([occurrence_id], ensure_ascii=False),
        point_library_version=str(rule.get("version_id") or ""),
    )
    cand["occurrence_id"] = occurrence_id
    cand["object_id"] = object_id
    cand["rule_version_id"] = str(rule.get("version_id") or rule_version)
    _attach_evidence(fid, cand, doc_texts,
                     label=("低置信覆盖保留候选（需人工复核）" if retained else "直接影子召回候选"))
    return fid


def _attach_evidence(fid: str, cand: dict, doc_texts: list, label: str = "") -> dict:
    doc = _pick_doc(doc_texts, cand.get("quote") or "")
    quote = str(cand.get("quote") or "")[:500]
    loc = cand.get("clause_id") or cand.get("location") or doc.get("filename") or "文档"
    aid = db.new_id("anc")
    R.anchors.insert(id=aid, document_id=doc.get("document_id") or "", sheet="",
                     row=None, col="", locator=str(loc), quote=quote, hash="")
    R.evidences.insert(id=db.new_id("evd"), finding_id=fid,
                       document_id=doc.get("document_id") or "", anchor_id=aid,
                       excerpt=quote, label=label or "候选复核证据")
    return {"locator": str(loc), "quote": quote, "sheet": ""}


def _clause_approved_id(idx: dict, quote: str) -> str:
    """引文所在条款配对的已批准条件编码（同一 SW 视为同一事项/同一问题）。"""
    if not idx or not quote:
        return ""
    clause = _val.clause_of(idx, quote)
    if not clause:
        return ""
    if clause.get("kind") == "approved":
        return clause.get("id") or ""
    apr = _val.paired_approved(idx, clause)
    return (apr or {}).get("id") or ""


def _same_issue_as_findings(idx: dict, cand: dict, findings: list) -> bool:
    """候选与既有 finding 是否同一事项（配对到同一个已批准条件）。"""
    cid = _clause_approved_id(idx, cand.get("quote") or "")
    if not cid:
        return False
    for f in findings or []:
        for q in _entry_quotes(f):
            if _clause_approved_id(idx, q) == cid:
                return True
    return False


def _matter_of(idx: dict, quote: str) -> str:
    """引文所属“事项号”：优先同编号已批准条件，退回归一后的条款编号数字。

    事项号是 SW-1049 / TK-1049 共用的 ``1049``：SW 是批准条件、TK 是拟定执行
    条款，同一编号才是“同一事项”。不同编号意味着两份独立的批准条件/执行条款，
    即使命中同一条规则也是两个问题，不能合并成一条 finding（否则一对一匹配吞定位）。
    """
    if not idx or not quote:
        return ""
    clause = _val.clause_of(idx, quote) or {}
    if not clause:
        return ""
    if clause.get("kind") == "approved":
        return str(clause.get("num") or "")
    apr = _val.paired_approved(idx, clause)
    if apr:
        return str(apr.get("num") or "")
    return str(clause.get("num") or "")


def _entry_matters(idx: dict, f: dict) -> set:
    """一条 finding 的证据覆盖了哪些事项号。"""
    out = set()
    for q in _entry_quotes(f):
        m = _matter_of(idx, q)
        if m:
            out.add(m)
    return out


def _cross_code_covered(idx: dict, cand: dict, collected: list,
                        doc_texts: list) -> list:
    """候选“事项”是否已被另一条不同规则码 finding 覆盖（同对象内比较）。

    影子层单次生成/第二轮补召回都可能把同一问题写成另一个规则码；若候选事项已经
    有另一规则码的 finding 覆盖，再按当前码落条只会制造“同事项多码重复”误报
    （实测 run1：E02-005/E02-001/C08-003/F09-004 交叉码候选导致 20 条重复 FP）。
    这里返回已覆盖的既有 finding 列表；调用方跳过新增/拆条，保留统计与 trace。
    """
    if not idx or not cand:
        return []
    code = str(cand.get("code") or "")
    quote = str(cand.get("quote") or "")
    if not quote:
        return []
    matter = _matter_of(idx, quote)
    if not matter:
        return []
    doc = _pick_doc(doc_texts, quote) if doc_texts else {}
    cand_obj = str((doc or {}).get("document_id") or cand.get("object_id") or "")
    out = []
    for g in collected or []:
        if _entry_code(g) == code:
            continue
        g_obj = str(g.get("object_id") or "")
        if cand_obj and g_obj and cand_obj != g_obj:
            continue
        if matter in _entry_matters(idx, g):
            out.append(g)
    return out


def _quote_is_approved_condition(idx: dict, quote: str) -> bool:
    """影子新增 finding 的证据引文是否来自“已批准条件”正文。

    新增/改码 finding 的证据应来自被审执行条款；拿批准条件正文自证违规在无
    文档结构或结构残缺时容易误报（实测干净底稿 E05-003 一条误报即
    reclassified 候选引文为 SW-1161 批准条件）。此类候选只保留统计，不落 finding。
    """
    if not idx or not quote:
        return False
    clause = _val.clause_of(idx, quote) or {}
    return clause.get("kind") == "approved"


def _skip_cross_or_approved(idx: dict, cand: dict, collected: list, doc_texts: list,
                            stats: dict) -> str:
    """新增/拆条前的精度守卫，返回跳过原因（空表示允许）。"""
    covered = _cross_code_covered(idx, cand, collected, doc_texts)
    if covered:
        code = str(cand.get("code") or "")
        stats["cross_code_covered"] = int(stats.get("cross_code_covered") or 0) + 1
        if code and code not in stats.setdefault("cross_code_covered_codes", []):
            stats["cross_code_covered_codes"].append(code)
        stats.setdefault("cross_code_trace", []).append({
            "code": code, "matter": _matter_of(idx, cand.get("quote") or ""),
            "covered_by": [str(g.get("id") or "") for g in covered],
            "covered_codes": [_entry_code(g) for g in covered],
            "quote": str(cand.get("quote") or "")[:120]})
        return "cross_code_covered"
    if _quote_is_approved_condition(idx, cand.get("quote") or ""):
        code = str(cand.get("code") or "")
        stats["approved_condition_evidence"] = int(
            stats.get("approved_condition_evidence") or 0) + 1
        if code and code not in stats.setdefault("approved_condition_evidence_codes", []):
            stats["approved_condition_evidence_codes"].append(code)
        return "approved_condition_evidence"
    return ""


def _cand_is_distinct_matter(idx: dict, cand: dict, existing: list) -> bool:
    """候选是否为“同规则、不同事项”的独立问题（拆分落条准入）。

    条件（缺一不可）：
    1. 候选引文与既有同码 finding 的证据都不重叠（重叠=同一问题，走去重/归并）；
    2. 候选引文能解析出事项号；
    3. 既有 finding 的证据事项号非空；
    4. 候选事项号不在既有事项号集合里。
    """
    quote = str(cand.get("quote") or "")
    if not quote:
        return False
    for f in existing or []:
        if _quote_overlap(quote, _entry_quotes(f)):
            return False
    cm = _matter_of(idx, quote)
    if not cm:
        return False
    fm = set()
    for f in existing or []:
        fm |= _entry_matters(idx, f)
    if not fm:
        return False
    return cm not in fm


def _merge_existing(f: dict, cand: dict, doc_texts: list, *, allow_anchor: bool) -> str:
    """同规则已有 finding：重复则去重；定位不同则把候选引文作为补充证据归并。"""
    if _quote_overlap(cand["quote"], _entry_quotes(f)):
        return "duplicate"
    if not allow_anchor:
        return "duplicate"
    fid = str(f.get("id") or "")
    if not fid:
        return "duplicate"
    ev = _attach_evidence(fid, cand, doc_texts, label="影子复核补充定位")
    if isinstance(f.get("evidence"), list):
        f["evidence"].append(ev)
    loc = cand.get("clause_id") or cand.get("location") or ""
    add = (f"；影子复核定位 {loc}：{str(cand.get('issue') or '')[:160]}") if loc else \
        (f"；影子复核补充：{str(cand.get('issue') or '')[:200]}")
    try:
        R.findings.update(fid, summary=(str(f.get("summary") or "") + add)[:500])
        f["summary"] = (str(f.get("summary") or "") + add)[:500]
    except Exception:
        log.debug("accuracy anchor summary update skipped", exc_info=True)
    return "anchored"


# ---------------------------------------------------------------------------
# 五、同码多条款候选重判（MODE=3：超越直连的自建能力）
# ---------------------------------------------------------------------------
_RECLASSIFY_SYSTEM = (
    "你是审核规则归属判定器。给你一条已确认存在问题的条款原文、原候选规则、"
    "以及审核点规则清单，请判断该条款最明确违反的是哪一条规则。"
    "只有在证据明确时选择；无法判断输出 null。只输出 JSON。"
)


def _reclassify_one(cand: dict, rules: list, taken_codes: set, *, timeout: int,
                    seq: int = 1) -> dict:
    cands = [r for r in rules if r["code"] not in taken_codes]
    if not cands:
        return {}
    lines = [f"{r['code']}｜{r['name']}｜判据：{r['criterion'][:220]}" for r in cands]
    orig = next((r for r in rules if r["code"] == cand["code"]), {})
    user = (f"条款原文（{cand.get('clause_id') or cand.get('location') or '未标注'}）：\n"
            f"{str(cand.get('quote') or '')[:800]}\n\n"
            f"原候选规则：{cand['code']}｜{orig.get('name') or ''}｜判据：{str(orig.get('criterion') or '')[:400]}\n"
            f"原候选理由：{str(cand.get('issue') or '')[:300]}\n\n"
            "审核点规则清单：\n" + "\n".join(lines) +
            "\n\n请从清单中选择该条款最明确违反的一条规则（可以是原候选规则，也可以不同；"
            "都不明确违反则输出 null）。\n"
            '只输出 JSON：{"point_code": "规则编码或 null", "reason": "一句话依据"}')
    try:
        from ..engine import llm, llm_router
        cfg = llm_router.resolve()
        if not cfg.get("enabled") or not cfg.get("api_key"):
            return {}
        llm.set_stage("accuracy_reclassify")
        llm.set_point_scope([cand["code"]])
        raw = llm.chat_completion(cfg["base_url"], cfg["api_key"], cfg["model"],
                                  [{"role": "system", "content": _RECLASSIFY_SYSTEM},
                                   {"role": "user", "content": user}],
                                  timeout=timeout, max_tokens=400, temperature=0)
        try:
            from . import extract as _ex
            obj = _ex._json_of(raw)
        except Exception:
            obj = {}
        if not isinstance(obj, dict):
            return {}
        code = _resolve_code({"point_code": str(obj.get("point_code") or "").strip()}, rules)
        if not code:
            return {}
        return {"code": code, "reason": str(obj.get("reason") or "")[:300]}
    except Exception as e:
        log.debug("accuracy reclassify skipped: %s", e)
        return {}


# ---------------------------------------------------------------------------
# 六、路由补齐（C08 类规则不被静默丢）
# ---------------------------------------------------------------------------
_ROUTE_LOSS_REASONS = ("audit_type_not_routed",)


def route_repair(manifest_out: dict) -> dict:
    """把 manifest 因审核类型路由失败的规则显式记录下来并交给影子层补召回。

    只处理“路由丢失”这一确定性原因；scope_missing/route_type_mismatch 等其它
    routed_out 原因可能是业务口径决定，不强行补跑（在 trace 里保留原因）。
    """
    out = {"enabled": bool(route_repair_enabled()), "codes": [], "routed": [],
           "non_route_loss": []}
    if not out["enabled"]:
        return out
    gate = (manifest_out or {}).get("gate") or {}
    for x in (gate.get("routed_out") or []):
        code = str(x.get("code") or "")
        reason = str(x.get("reason") or "")
        if not code:
            continue
        rec = {"code": code, "reason": reason, "name": x.get("name") or ""}
        if reason in _ROUTE_LOSS_REASONS:
            out["codes"].append(code)
            out["routed"].append(rec)
        else:
            out["non_route_loss"].append(rec)
    return out


# ---------------------------------------------------------------------------
# 七、主入口
# ---------------------------------------------------------------------------
def _shadow_model_cfg() -> dict:
    """影子层模型可用性（单独成函数，便于确定性反例测试注入固定实现）。"""
    try:
        from ..engine import llm_router
        cfg = llm_router.resolve()
        if cfg.get("enabled") and cfg.get("api_key"):
            return cfg
    except Exception:
        log.debug("accuracy shadow model resolve failed", exc_info=True)
    return {}


def _generate_raw_candidates(combined: str, rules: list, cfg: dict, timeout: int,
                             stats: dict, dump_dir: str,
                             *, round_no: int = 1, residual: list | None = None) -> list:
    """一次影子召回生成（可被测试替换为“强制空候选”的固定实现）。

    round_no=1：全文 + 允许审核点一次生成；round_no=2：只对第一轮未覆盖的残余
    审核点逐条复核。两轮生成结果都走同一套逐字回查 + 双票验证，不降低门槛。
    """
    from ..engine import llm
    if round_no == 2:
        system, user = _build_residual_prompt(combined, residual or [])
        stage, max_tokens = "accuracy_shadow_recall_round2", 4096
        prompt_name, response_name = "shadow_round2_prompt.txt", "shadow_round2_response.txt"
    else:
        system, user = _build_prompt(combined, rules)
        stage, max_tokens = "accuracy_shadow_recall", 8192
        prompt_name, response_name = "shadow_prompt.txt", "shadow_response.txt"
    if dump_dir:
        try:
            os.makedirs(dump_dir, exist_ok=True)
            with open(os.path.join(dump_dir, prompt_name), "w", encoding="utf-8") as f:
                f.write(system + "\n\n===== USER =====\n\n" + user)
        except Exception:
            log.debug("accuracy prompt dump skipped", exc_info=True)
    llm.set_stage(stage)
    raw = llm.chat_completion(cfg["base_url"], cfg["api_key"], cfg["model"],
                              [{"role": "system", "content": system},
                               {"role": "user", "content": user}],
                              timeout=timeout, max_tokens=max_tokens, temperature=0)
    if dump_dir:
        try:
            with open(os.path.join(dump_dir, response_name), "w", encoding="utf-8") as f:
                f.write(raw or "")
        except Exception:
            log.debug("accuracy response dump skipped", exc_info=True)
    return _parse_raw_candidates(raw)


def recall(case_id: str, docs: list, items: list, collected: list, *,
           run_id: str = "", route_ctx: dict | None = None) -> dict:
    """直接影子召回 → 候选验证/去重/归并 → 回填 finding。

    返回 stats（同时写入 audit 返回的 ``accuracy`` 字段，供基准/报告取证）。
    本函数不抛异常给主链：任何失败都记 failed 并返回（审核不因候选层失败而失败）。
    """
    t0 = time.time()
    stats = {
        "version": _ASSESS_VERSION, "mode": mode(), "mode_name": mode_name(),
        "enabled": bool(enabled()),
        "validator": bool(validator_enabled()), "anchor": bool(anchor_enabled()),
        "route_repair": bool(route_repair_enabled()),
        "reclassify": bool(reclassify_enabled()),
        "retain": bool(retain_enabled()),
        "generated": 0, "raw_entries": 0,
        "rejected_invalid_code": 0, "rejected_quote_not_verbatim": 0,
        "rejected_template_body": 0, "rejected_duplicate": 0,
        "location_unverified": 0,
        "validated_pass": 0, "validated_reject": 0,
        "reclassified": 0,
        "retain_eligible": 0, "retained": 0, "retained_evidence": 0,
        "retained_codes": [], "retain_trace": [],
        "added": 0, "anchored": 0, "duplicate": 0,
        "split": bool(split_enabled()),
        "split_added": 0, "split_codes": [], "split_trace": [],
        "split_conflict_flagged": 0, "split_conflict_codes": [],
        "cross_code_covered": 0, "cross_code_covered_codes": [], "cross_code_trace": [],
        "approved_condition_evidence": 0, "approved_condition_evidence_codes": [],
        "round2_dropped_offscope": 0,
        "recall_rounds": 1, "round1_generated": 0, "round2_generated": 0,
        "round2_rules": 0, "round2_rules_codes": [],
        "round2_kept": 0, "round2_dropped_offscope": 0,
        "coverage_mark": bool(coverage_mark_enabled()),
        "allowed_rule_set": {},
        "shadow_coverage_checked": 0, "shadow_coverage_covered": 0,
        "shadow_coverage_missing": 0, "shadow_coverage_missing_codes": [],
        "shadow_needs_review": 0, "needs_review_codes": [],
        "d5_source_by_code": {}, "deterministic_fail_codes": [], "semantic_fail_codes": [],
        "finding_gate_checked": 0, "finding_gate_demoted": 0, "finding_gate_demoted_codes": [],
        "finding_gate_kept": 0, "finding_gate_double_checked": 0,
        "candidates": [], "decision_by_code": {},
        "route_ctx": dict(route_ctx or {}),
        "errors": [], "prompt_chars": 0, "latency_ms": 0,
    }
    if not stats["enabled"]:
        return stats
    try:
        cfg = _shadow_model_cfg()
        if not cfg:
            stats["skipped"] = "model_unavailable"
            # 模型不可用不改变主链结论：仍标注“影子未覆盖”供复核（不 demote）。
            if coverage_mark_enabled():
                try:
                    _mark_shadow_coverage(case_id, run_id, collected, items,
                                          d5_sources=_d5_sources(items), stats=stats)
                except Exception:
                    log.debug("shadow coverage mark (no model) skipped", exc_info=True)
            return stats
    except Exception as e:
        stats["errors"].append(f"model:{type(e).__name__}: {str(e)[:120]}")
        return stats
    try:
        doc_texts = _doc_texts(docs)
        if not doc_texts:
            stats["skipped"] = "no_parsed_text"
            return stats
        combined = "\n\n".join(f"【文件：{d['filename']}】\n{d['text']}" for d in doc_texts)
        rules, _allow_meta = _allowed_rule_set(case_id, run_id, items,
                                               route_ctx or {}, stats)
        if not rules:
            stats["skipped"] = "empty_allowed_rule_set"
            if coverage_mark_enabled():
                _mark_shadow_coverage(case_id, run_id, collected, items,
                                      d5_sources=_d5_sources(items), stats=stats)
            return stats
        stats["rules_total"] = len(rules)
        stats["rules_codes"] = [r["code"] for r in rules]
        idx = _val.index_document(combined)
        stats["clauses_indexed"] = len(idx.get("clauses") or [])
        stats["has_approved_section"] = bool(idx.get("has_approved_section"))
        dump_dir = os.environ.get("RULEPROOF_ACCURACY_DUMP") or ""
        timeout = _timeout("RULEPROOF_ACCURACY_TIMEOUT", 240)
        raw_items = _generate_raw_candidates(combined, rules, cfg, timeout, stats,
                                             dump_dir, round_no=1)
        stats["round1_generated"] = len(raw_items)
        stats["recall_rounds"] = 1
        stats["prompt_chars"] = len(str(combined)) + sum(
            len(r.get("criterion") or "") for r in rules)
        # 第二轮：只对“第一轮没有任何候选”的残余审核点做一次逐条复核，补生成漏项
        # （单次全文召回受采样影响会整点漏项；第二轮生成结果仍要过同一套逐字回查
        #  + 双票验证，不降低门槛、不直接回填 finding）。
        rounds = recall_rounds()
        if rounds >= 2:
            covered_codes = {_resolve_code(it, rules) for it in raw_items}
            residual = [r for r in rules if r["code"] not in covered_codes]
            stats["round2_rules"] = len(residual)
            stats["round2_rules_codes"] = [r["code"] for r in residual]
            if residual:
                try:
                    raw_items2 = _generate_raw_candidates(
                        combined, rules, cfg, timeout, stats, dump_dir,
                        round_no=2, residual=residual)
                    # 第二轮只接受“残余审核点清单内”的候选：模型可能忽略清单、
                    # 把已覆盖审核点/其它码一起输出（实测 run1 只给 1 条残余规则
                    # 却输出 18 条跨码候选，制造大量同事项多码重复）。
                    _res_codes = {r["code"] for r in residual}
                    _kept2 = []
                    for _it in raw_items2:
                        _c = _resolve_code(_it, rules)
                        if _c in _res_codes:
                            _kept2.append(_it)
                        else:
                            stats["round2_dropped_offscope"] = int(
                                stats.get("round2_dropped_offscope") or 0) + 1
                    stats["round2_generated"] = len(raw_items2)
                    stats["round2_kept"] = len(_kept2)
                    stats["recall_rounds"] = 2
                    raw_items = list(raw_items) + list(_kept2)
                except Exception as e:
                    stats["errors"].append(f"round2:{type(e).__name__}: {str(e)[:120]}")
        stats["generated"] = len(raw_items)
        cands = _normalize_candidates(raw_items, combined, idx, rules, stats)
        by_code = {r["code"]: r for r in rules}
        d5_by_code = {}
        for it in items or []:
            code = str(it.get("rule") or it.get("code") or "")
            if not code:
                continue
            d5_by_code[code] = str((it.get("d5") or {}).get("status") or "")
        for c in cands:
            c["prior_d5"] = d5_by_code.get(c["code"], "not_in_manifest")

        rejected_pool = []
        # 1) 候选双票验证（MODE>=2）
        if validator_enabled():
            vto = _timeout("RULEPROOF_ACCURACY_VALIDATE_TIMEOUT", 60)
            kept = []
            for i, c in enumerate(cands, 1):
                r = _val.validate(c, by_code[c["code"]], idx, timeout=vto, seq=i)
                c["validation"] = {"ok": bool(r.get("ok")), "reject": r.get("reject") or "",
                                   "reason": r.get("reason") or "",
                                   "clause_id": r.get("clause_id") or c.get("clause_id") or "",
                                   "approved_id": r.get("approved_id") or "",
                                   "votes": r.get("votes") or {}}
                c["clause_id"] = c["validation"]["clause_id"] or c.get("clause_id") or ""
                if r.get("ok"):
                    c["quote"] = r.get("quote") or c["quote"]
                    stats["validated_pass"] += 1
                    kept.append(c)
                else:
                    stats["validated_reject"] += 1
                    c["decision"] = "rejected_validation"
                    st = _cand_stat(c)
                    c["_stat"] = st          # 覆盖保留后要回写同一条候选统计
                    stats["candidates"].append(st)
                    if (r.get("reject") or "") == "double_vote_disagree":
                        # 反票可辩护/码选错都会走到这里：MODE=3 时作为“码归属重判”
                        # 的输入再试一次（候选定位本身是可回查的，不应直接丢）。
                        votes = r.get("votes") or {}
                        pos = votes.get("positive") or {}
                        neg = votes.get("negative") or {}
                        if (pos.get("parsed") and pos.get("violate") is True
                                and neg.get("parsed") and neg.get("comply") is True):
                            # “一票成立 + 另一票仅可辩护”：覆盖保留候选（MODE>=3）
                            c["retain_eligible"] = True
                        rejected_pool.append(c)
            cands = kept
        else:
            rejected_pool = []

        # 2) 候选码归属重判（MODE>=3，自建“超越直连”能力）
        # 直接影子召回与直连模型一样，会出现“定位对了但码选错/同码多条款”：
        #   a) 同一规则出现多条不同条款候选（同码多条款）→ 保留最贴合的一条，其余重判归属；
        #   b) 候选码已有 finding 且候选引文与既有证据不同（可能条目串位/码错）→ 重判；
        #   c) 候选码没有 finding（新增召回）→ 让模型在全规则清单中复核一次归属，
        #      只有重判结果不同且能过双票验证才改码，避免把正确新召回改坏。
        if reclassify_enabled() and (cands or rejected_pool):
            rto = _timeout("RULEPROOF_ACCURACY_VALIDATE_TIMEOUT", 60)
            existing_by_code = {}
            for f in collected or []:
                existing_by_code.setdefault(_entry_code(f), []).append(f)
            # 2.0) 验证被拒但引文可回查的候选：先做码归属重判（定位对、码选错）
            for c in (rejected_pool if validator_enabled() else []):
                taken = set(existing_by_code.keys())
                got = _reclassify_one(c, rules, taken, timeout=rto,
                                      seq=len(stats["candidates"]) + 1)
                if not got or not got.get("code") or got["code"] == c["code"]:
                    continue
                if got["code"] in existing_by_code:
                    continue
                nc = dict(c)
                nc["code"] = got["code"]
                nc["rule_name"] = by_code[got["code"]]["name"]
                nc["reclassify"] = {"from": c["code"], "reason": got.get("reason") or "",
                                    "from_rejected": True}
                r2 = _val.validate(nc, by_code[nc["code"]], idx, timeout=rto,
                                   seq=len(stats["candidates"]) + 1)
                nc["validation"] = {"ok": bool(r2.get("ok")), "reject": r2.get("reject") or "",
                                    "reason": r2.get("reason") or "",
                                    "clause_id": r2.get("clause_id") or nc.get("clause_id") or "",
                                    "approved_id": r2.get("approved_id") or ""}
                if not r2.get("ok"):
                    c["reclassify_checked"] = "rejected_validation_still"
                    continue
                nc["quote"] = r2.get("quote") or nc["quote"]
                nc["decision"] = "reclassified"
                stats["reclassified"] += 1
                stats["candidates"].append(_cand_stat(nc))
                _merge(case_id, run_id, doc_texts, nc, by_code[nc["code"]], collected, stats,
                         idx=idx)
                c["reclassify_checked"] = "moved"
            groups = {}
            for c in cands:
                groups.setdefault(c["code"], []).append(c)
            ordered = []
            for code, group in groups.items():
                group.sort(key=lambda x: (-(x.get("confidence") or 0),
                                          -len(_val._nz(x.get("quote") or ""))))
                # 组内第一条保留原码（最贴合），其余重判
                ordered.append((group[0], False))
                for other in group[1:]:
                    ordered.append((other, True))
            for c, force in ordered:
                code = c["code"]
                ex = existing_by_code.get(code) or []
                need = force
                if need and ex and _same_issue_as_findings(idx, c, ex):
                    # 同码候选与既有 finding 配对同一已批准条件：同一问题，
                    # 重判只会把正确归属改走（实测丢 Q07/G-NEW-03），改为归并证据。
                    need = False
                    c["reclassify_checked"] = "same_issue_keep"
                if not need:
                    if not ex:
                        need = True            # 新召回：复核归属
                    elif not any(_quote_overlap(c["quote"], _entry_quotes(f)) for f in ex):
                        need = True            # 同码已有 finding 但引文不同条款：复核归属
                        if _same_issue_as_findings(idx, c, ex):
                            need = False
                            c["reclassify_checked"] = "same_issue_keep"
                if need:
                    taken = set(existing_by_code.keys()) | \
                        {str(x.get("code") or "") for x in stats.get("candidates") or []}
                    got = _reclassify_one(c, rules, taken, timeout=rto,
                                          seq=len(stats["candidates"]) + 1)
                    if (got and got.get("code") and got["code"] != code
                            and got["code"] not in existing_by_code):
                        nc = dict(c)
                        nc["code"] = got["code"]
                        nc["rule_name"] = by_code[got["code"]]["name"]
                        nc["reclassify"] = {"from": code, "reason": got.get("reason") or ""}
                        if validator_enabled():
                            r2 = _val.validate(nc, by_code[nc["code"]], idx, timeout=rto,
                                               seq=len(stats["candidates"]) + 1)
                            nc["validation"] = {
                                "ok": bool(r2.get("ok")), "reject": r2.get("reject") or "",
                                "reason": r2.get("reason") or "",
                                "clause_id": r2.get("clause_id") or nc.get("clause_id") or "",
                                "approved_id": r2.get("approved_id") or ""}
                            if not r2.get("ok"):
                                c["reclassify_checked"] = "kept_original_validation"
                            else:
                                nc["quote"] = r2.get("quote") or nc["quote"]
                        if nc.get("validation", {}).get("ok") or not validator_enabled():
                            nc["decision"] = "reclassified"
                            stats["reclassified"] += 1
                            stats["candidates"].append(_cand_stat(nc))
                            _merge(case_id, run_id, doc_texts, nc, by_code[nc["code"]],
                                   collected, stats, idx=idx)
                            c["reclassify_checked"] = "moved"
                            c["decision"] = "reclassified_away"
                            continue
                    else:
                        c["reclassify_checked"] = "kept_original"
                _merge(case_id, run_id, doc_texts, c, by_code[code], collected, stats, idx=idx)
                stats["candidates"].append(_cand_stat(c))
            cands = []  # 已在上面归并

        # 3) 归并/回填
        for c in cands:
            if c.get("decision"):
                continue
            _merge(case_id, run_id, doc_texts, c, by_code[c["code"]], collected, stats, idx=idx)
            stats["candidates"].append(_cand_stat(c))

        # 3.1) 拆条冲突标注（不降级、不删除）：同规则另一事项已独立落 finding 时，
        #      原主链 finding 保留结论与证据，只标 needs_review + 写审计，交人工复核。
        if split_enabled() and stats.get("split_codes"):
            _flag_split_conflicts(case_id, run_id, collected, idx, stats)

        # 3.2) 覆盖保留（MODE>=3）：双票不一致但正票确认矛盾、本轮 D5=fail 的被拒候选，
        #      按窄口径保留为低置信 insufficient finding，避免“引文可逐字回查的真实
        #      线索”因为反票的“可辩护解释”被直接丢弃，或被交叉一致性门降级后从清单消失。
        if retain_enabled() and rejected_pool:
            _retain_orphan_rejected(case_id, run_id, doc_texts, idx, rejected_pool,
                                    collected, stats, by_code, d5_by_code)

        # 3.5) 裁决边界（架构裁决 2026-11-17）：
        #   默认=保留主链 finding，只标 shadow_coverage（covered/missing）并写审计；
        #   语义 fail 标 needs_review=true，确定性执行器 fail 保留原结论不降级。
        #   build49 B1：legacy demote 通道（原隐藏评测开关）已删除，覆盖率不得以
        #   牺牲主链 finding 为代价。
        d5_sources = _d5_sources(items)
        stats["d5_source_by_code"] = {k: str(v.get("kind") or "") for k, v in d5_sources.items()}
        stats["deterministic_fail_codes"] = sorted(
            k for k, v in d5_sources.items()
            if str(v.get("d5") or "") == "fail" and v.get("kind") == "deterministic")
        stats["semantic_fail_codes"] = sorted(
            k for k, v in d5_sources.items()
            if str(v.get("d5") or "") == "fail" and v.get("kind") != "deterministic")
        if coverage_mark_enabled():
            _mark_shadow_coverage(case_id, run_id, collected, items,
                                  d5_sources=d5_sources, stats=stats)

        # 4) 路由补齐未召回时的显式记录（不静默丢）
        rctx = route_ctx or {}
        lost = list(rctx.get("codes") or [])
        if lost:
            found = {str(c.get("code")) for c in stats["candidates"]}
            stats["route_ctx"]["shadow_covered"] = [x for x in lost if x in found]
            stats["route_ctx"]["shadow_missing"] = [x for x in lost if x not in found]
    except Exception as e:
        log.exception("accuracy shadow failed case=%s", case_id)
        stats["errors"].append(f"{type(e).__name__}: {str(e)[:200]}")
    stats["latency_ms"] = int((time.time() - t0) * 1000)
    try:
        stats["decision_by_code"] = {c["code"]: c.get("decision") or ""
                                     for c in stats["candidates"]}
    except Exception:
        pass
    _LAST_STATS.clear()
    _LAST_STATS.update(stats)
    return stats


_DET_EXECUTORS = ("ruleexec", "decision_table", "tool", "regex", "fact", "dmn")
_SEM_EXECUTORS = ("agent-judge", "judge", "llm", "model")


def _d5_sources(items: list) -> dict:
    """每个 manifest 审核点的 D5 来源分类：确定性执行器 fail vs 语义 fail。

    - 确定性执行器（ruleexec/decision_table/tool 等）判 fail：结论可复算，主链
      finding 必须保留，影子层未覆盖只写 shadow_coverage=missing，不标待复核；
    - 语义判定（agent-judge 等）判 fail：主链结论保留，但标 needs_review=true，
      因为影子层未复现时缺少第二重证据确认。
    """
    out = {}
    for it in items or []:
        code = str(it.get("rule") or it.get("code") or "")
        if not code:
            continue
        d5 = str((it.get("d5") or {}).get("status") or "")
        d4 = it.get("d4") or {}
        subs = d4.get("subs") or []
        det, sem = False, False
        det_subs, sem_subs = [], []
        for sub in subs:
            st = str((sub or {}).get("status") or "")
            if st != "fail":
                continue
            ex = str(((sub or {}).get("tool_trace") or {}).get("executor") or "")
            if ex in _DET_EXECUTORS:
                det = True
                det_subs.append(str((sub or {}).get("id") or ""))
            else:
                sem = True
                sem_subs.append(str((sub or {}).get("id") or ""))
        if not subs:
            ex = str((d4.get("tool_trace") or {}).get("executor") or "")
            if d5 == "fail":
                if ex in _DET_EXECUTORS:
                    det = True
                else:
                    sem = True
        if d5 != "fail":
            kind = "no_fail"
        elif det:
            kind = "deterministic"
        elif sem:
            kind = "semantic"
        else:
            kind = "unknown"
        out[code] = {"code": code, "d5": d5, "kind": kind,
                     "d4_status": str(d4.get("status") or ""),
                     "deterministic_subs": det_subs, "semantic_subs": sem_subs,
                     "d4_executors": sorted({
                         str(((s2 or {}).get("tool_trace") or {}).get("executor") or "")
                         for s2 in subs
                         if ((s2 or {}).get("tool_trace") or {}).get("executor")})}
    return out


_SHADOW_COVERAGE_MARKERS = {
    "deterministic": "【主链确定性执行器 fail 保留；影子层未召回 shadow_coverage=missing，"
                     "不影响结论，供覆盖率统计】",
    "missing": "【待人工复核：影子层未覆盖 shadow_coverage=missing；主链语义结论保留】",
}


def _mark_shadow_coverage(case_id: str, run_id: str, collected: list, items: list,
                          *, d5_sources: dict | None = None, stats: dict | None = None) -> None:
    """影子覆盖标注：不改变主链结论，只标注 + 写审计（默认裁决边界）。

    - D5 fail 且影子层有已验证候选复现 → ``shadow_coverage=covered``；
    - D5 fail 但影子层未覆盖 → ``shadow_coverage=missing``；语义来源再标
      ``needs_review=true``，确定性来源保留原结论；均写 ``finding.shadow_coverage_missing``
      审计（含 rule/object/rule_version/证据引文），不 demote、不移出清单、不删证据链。
      该函数也是“影子召回为空”反例的断言入口：空候选时主链 fail finding 必须仍在。
    """
    if stats is None:
        return
    d5_sources = d5_sources if d5_sources is not None else _d5_sources(items)
    corroborated = {str(x) for x in (stats.get("retained_codes") or [])}
    for c in stats.get("candidates") or []:
        if (c.get("decision") or "") in _VERIFIED_DECISIONS + _RETAINED_DECISIONS:
            code = str(c.get("code") or "")
            if code:
                corroborated.add(code)
    for f in list(collected or []):
        code = _entry_code(f)
        info = d5_sources.get(code) or {}
        if str(info.get("d5") or "") != "fail":
            continue
        kind = str(info.get("kind") or "unknown")
        covered = code in corroborated
        f["d5_source"] = kind
        f["shadow_coverage"] = "covered" if covered else "missing"
        stats["shadow_coverage_checked"] += 1
        if covered:
            stats["shadow_coverage_covered"] += 1
            continue
        stats["shadow_coverage_missing"] += 1
        if code not in stats["shadow_coverage_missing_codes"]:
            stats["shadow_coverage_missing_codes"].append(code)
        needs_review = kind != "deterministic"
        if needs_review:
            f["needs_review"] = True
            stats["shadow_needs_review"] += 1
            if code not in stats["needs_review_codes"]:
                stats["needs_review_codes"].append(code)
        marker = (_SHADOW_COVERAGE_MARKERS["deterministic"] if not needs_review
                  else _SHADOW_COVERAGE_MARKERS["missing"])
        old = str(f.get("suggestion") or "")
        if "shadow_coverage=missing" not in old:
            f["suggestion"] = (marker + old)[:500]
        fid = str(f.get("id") or "")
        try:
            if fid:
                R.findings.update(fid, suggestion=f["suggestion"])
        except Exception:
            log.debug("shadow coverage suggestion persist skipped", exc_info=True)
        ev = max(_entry_quotes(f), key=len, default="") or ""
        try:
            R.audit_logs.log(
                actor="system", action="finding.shadow_coverage_missing", object=fid,
                after=json.dumps({
                    "case_id": case_id, "run_id": run_id, "rule": code,
                    "object_id": str(f.get("object_id") or ""),
                    "rule_version_id": str(f.get("rule_version") or ""),
                    "occurrence_ids": f.get("occurrence_ids") or [],
                    "d5_source": kind, "shadow_coverage": "missing",
                    "needs_review": bool(needs_review),
                    "evidence_quote": ev[:200],
                    "note": "增强层未覆盖不改变主链结论；语义结论按待复核处理",
                }, ensure_ascii=False))
        except Exception:
            log.debug("shadow coverage audit skipped", exc_info=True)




def _cand_stat(c: dict) -> dict:
    return {
        "code": c.get("code"), "rule_name": c.get("rule_name") or "",
        "location": c.get("location") or c.get("clause_id") or "",
        "clause_id": c.get("clause_id") or "",
        "quote": str(c.get("quote") or "")[:160],
        "issue": str(c.get("issue") or "")[:160],
        "confidence": c.get("confidence"),
        "prior_d5": c.get("prior_d5") or "",
        "decision": c.get("decision") or "",
        "validation": c.get("validation"),
        "approved_id": str((c.get("validation") or {}).get("approved_id") or ""),
        "reclassify": c.get("reclassify"),
        "retain_trace": c.get("retain_trace"),
        "split": bool(c.get("split")),
        "in_system": (c.get("decision") or "") in (
            "added", "anchored", "reclassified", "kept", "split_added",
            "retained_insufficient", "retained_supplementary"),
    }


def _materialize(case_id: str, run_id: str, doc_texts: list, cand: dict, rule: dict,
                 collected: list, stats: dict) -> str:
    """把候选落成一条新 finding：验证通过=state fail；覆盖保留=state insufficient。"""
    retained = bool(cand.get("retained"))
    try:
        fid = _insert_finding(case_id, run_id, rule, cand, doc_texts)
    except Exception as e:
        log.warning("accuracy shadow finding insert failed: %s", e)
        stats["errors"].append(f"insert:{type(e).__name__}: {str(e)[:120]}")
        cand["decision"] = "error"
        return "error"
    loc = cand.get("clause_id") or cand.get("location") or ""
    ev = [{"locator": loc or "", "quote": str(cand.get("quote") or "")[:500], "sheet": ""}]
    body = (f"【定位 {loc}】" if loc else "") + str(cand.get("issue") or "")[:420]
    if retained:
        body = ("【低置信覆盖保留|证据不足|需人工复核】" + body)
    collected.append({
        "id": fid, "code": cand["code"], "point_id": cand["code"], "rule_code": cand["code"],
        "rule_name": cand.get("rule_name") or "", "category": rule.get("category") or "",
        "rclass": rule.get("rclass") or "",
        "severity": sev_from_rclass(rule.get("rclass") or ""),
        "title": (("【低置信覆盖保留】" if retained else "")
                  + str(cand.get("rule_name") or cand["code"])[:80]),
        "summary": body,
        "suggestion": "", "state": "insufficient" if retained else "fail",
        "certainty": "abstain" if retained else "probable",
        "confidence": (round(min(_num(cand.get("confidence"), 0.3), 0.45), 3)
                       if retained else cand.get("confidence")),
        "evidence": ev, "engine": "accuracy_shadow",
        "origin": "accuracy_shadow",
        "low_confidence_retained": retained,
        "object_id": cand.get("object_id") or "",
        "occurrence_id": cand.get("occurrence_id") or "",
        "rule_version_id": cand.get("rule_version_id") or "",
    })
    if retained:
        stats["retained"] += 1
        cand["decision"] = "retained_insufficient"
        return "retained_insufficient"
    if cand.get("split"):
        stats["split_added"] = int(stats.get("split_added") or 0) + 1
        code = str(cand.get("code") or "")
        if code and code not in stats.setdefault("split_codes", []):
            stats["split_codes"].append(code)
        split_info = cand.get("split") if isinstance(cand.get("split"), dict) else {}
        stats.setdefault("split_trace", []).append({
            "code": code, "clause_id": cand.get("clause_id") or "",
            "matter": split_info.get("matter") or "",
            "from_finding_ids": split_info.get("from_decisions") or [],
            "existing_matters": split_info.get("existing_matters") or [],
            "quote": str(cand.get("quote") or "")[:120]})
        cand["decision"] = "split_added"
        return "split_added"
    stats["added"] += 1
    cand["decision"] = "added"
    return "added"


def _merge(case_id: str, run_id: str, doc_texts: list, cand: dict, rule: dict,
           collected: list, stats: dict, idx: dict | None = None) -> str:
    """候选归并：同码同事项→去重/补充证据；同码不同事项→独立 finding（MODE>=3）。

    为什么不能一律并入既有 finding：基准匹配是一对一 finding↔gold，一条 finding
    只能命中一个 gold。同码不同条款（不同已批准条件事项）的候选并入后，第二个
    条款的定位会被已命中的第一个 gold“用掉”，最终覆盖出现缺口（实测 Q13）。
    """
    code = cand.get("code") or ""
    # 同规则不同对象是两条独立 occurrence：归并只在“同对象（或对象未知）”内进行。
    _cdoc = _pick_doc(doc_texts, cand.get("quote") or "") if cand.get("quote") else {}
    cand_obj = str((_cdoc or {}).get("document_id") or cand.get("object_id") or "")
    if cand_obj:
        cand["object_id"] = cand_obj

    def _same_object(f: dict) -> bool:
        fo = str(f.get("object_id") or "")
        return not cand_obj or not fo or fo == cand_obj

    existing = [f for f in (collected or [])
                if _entry_code(f) == code and _same_object(f)]
    if existing:
        if split_enabled() and idx and _cand_is_distinct_matter(idx, cand, existing):
            why = _skip_cross_or_approved(idx, cand, collected, doc_texts, stats)
            if why:
                cand["decision"] = why
                return why
            cand["split"] = {
                "from_decisions": [str(f.get("id") or "") for f in existing],
                "matter": _matter_of(idx, cand.get("quote") or ""),
                "existing_matters": sorted(
                    set().union(*[_entry_matters(idx, f) for f in existing])) if existing else [],
            }
            return _materialize(case_id, run_id, doc_texts, cand, rule, collected, stats)
        decision = _merge_existing(existing[0], cand, doc_texts,
                                   allow_anchor=anchor_enabled())
        stats[decision if decision in ("anchored", "duplicate") else "duplicate"] += 1
        cand["decision"] = decision
        return decision
    why = _skip_cross_or_approved(idx, cand, collected, doc_texts, stats) if idx else ""
    if why:
        cand["decision"] = why
        return why
    return _materialize(case_id, run_id, doc_texts, cand, rule, collected, stats)


def _flag_split_conflicts(case_id: str, run_id: str, collected: list,
                           idx: dict, stats: dict) -> None:
    """同规则另一事项已独立落条时，给原 finding 标“待人工复核”，不降级、不删除。

    架构裁决：增强层不得因自己的召回/归并结果修改主链结论。同码不同事项候选独立
    落 finding 后，原 finding 的证据事项若已被另一条不同规则码 finding 覆盖（D4
    证据串位/同事项重复），这里只做两件事：
    1) ``needs_review=true`` + 建议字段标注“同规则另一事项已独立落条，需人工复核”；
    2) 写 ``finding.shadow_split_conflict`` 审计（规则/事项/关联 finding/版本）。
    原有 state、certainty、证据链、清单归属全部保留——覆盖率不得以牺牲主链
    finding 为代价，冲突留给人工复核裁决。
    """
    split_codes = {str(x) for x in (stats.get("split_codes") or []) if x}
    if not split_codes:
        return
    for f in list(collected or []):
        code = _entry_code(f)
        if code not in split_codes:
            continue
        if str(f.get("origin") or "") == "accuracy_shadow":
            continue
        if str(f.get("engine") or "") == "accuracy_shadow":
            continue
        fm = _entry_matters(idx, f)
        if not fm:
            continue
        f_obj = str(f.get("object_id") or "")
        related, dup_matters = [], []
        for m in fm:
            for g in (collected or []):
                if g is f:
                    continue
                if _entry_code(g) == code:
                    continue
                g_obj = str(g.get("object_id") or "")
                if f_obj and g_obj and f_obj != g_obj:
                    continue          # 不同对象：同事项号也不是重复
                if m in _entry_matters(idx, g):
                    if m not in dup_matters:
                        dup_matters.append(m)
                    related.append(str(g.get("id") or ""))
        if not dup_matters:
            continue
        f["needs_review"] = True
        f["shadow_split_conflict"] = True
        f["split_conflict_matters"] = sorted(dup_matters)
        marker = ("【待人工复核：同规则另一事项已独立落 finding；本 finding 证据事项 "
                  f"{'/'.join(sorted(dup_matters))} 与另一规则码 finding 重叠，"
                  "可能为 D4 证据串位，主链结论保留】")
        old_sug = str(f.get("suggestion") or "")
        if "同规则另一事项已独立落" not in old_sug:
            f["suggestion"] = (marker + old_sug)[:500]
        fid = str(f.get("id") or "")
        try:
            if fid:
                R.findings.update(fid, suggestion=f["suggestion"])
        except Exception:
            log.debug("split conflict suggestion persist skipped", exc_info=True)
        try:
            R.audit_logs.log(
                actor="system", action="finding.shadow_split_conflict", object=fid,
                after=json.dumps({
                    "case_id": case_id, "run_id": run_id, "rule": code,
                    "object_id": f_obj, "rule_version_id": str(f.get("rule_version") or ""),
                    "matters": sorted(dup_matters),
                    "related_finding_ids": list(dict.fromkeys(x for x in related if x)),
                    "needs_review": True,
                    "note": "同规则另一事项已独立落 finding；主链 finding 保留，不降级",
                }, ensure_ascii=False))
        except Exception:
            log.debug("split conflict audit skipped", exc_info=True)
        stats["split_conflict_flagged"] = int(stats.get("split_conflict_flagged") or 0) + 1
        if code not in stats.setdefault("split_conflict_codes", []):
            stats["split_conflict_codes"].append(code)
        stats.setdefault("split_trace", []).append({
            "code": code, "conflict_finding": fid, "mode": "split_conflict_flagged",
            "matters": sorted(dup_matters)})


def _retain_eligible(c: dict, idx: dict, d5_by_code: dict) -> tuple:
    """覆盖保留准入（窄口径，缺一不可），返回 (eligible, reason)。

    1. 必须有“一票成立 + 另一票仅可辩护”的双票痕迹（_val.validate 的 votes，
       fail-closed：两票都必须解析成功）；
    2. 候选码本轮 manifest D5 = fail（整份文档已被判该审核点存在问题）；
    3. 引文逐字回查通过，且引文落在拟定执行条款，而不是“已批准条件”正文本身
       （防止拿批准条件自证违规）。
    """
    votes = (c.get("validation") or {}).get("votes") or {}
    pos = votes.get("positive") or {}
    neg = votes.get("negative") or {}
    if not (pos.get("parsed") and pos.get("violate") is True):
        return False, "positive_not_confirmed"
    if not (neg.get("parsed") and neg.get("comply") is True):
        return False, "negative_not_defensible"
    if str(c.get("prior_d5") or "") != "fail":
        return False, "prior_d5_not_fail"
    quote = str(c.get("quote") or "").strip()
    if not quote or not idx.get("text"):
        return False, "quote_missing"
    if not _val.locate_quote(idx.get("text") or "", quote):
        return False, "quote_not_verbatim"
    clause = _val.clause_of(idx, quote) or {}
    if not clause:
        return False, "clause_unresolved"
    if clause.get("kind") == "approved":
        return False, "quote_is_approved_condition"
    return True, ""


def _retain_orphan_rejected(case_id: str, run_id: str, doc_texts: list, idx: dict,
                            rejected_pool: list, collected: list, stats: dict,
                            by_code: dict, d5_by_code: dict) -> None:
    """覆盖保留：双票不一致但正票确认矛盾、本轮 D5=fail 的被拒候选不直接丢。

    背景：双票机制的“反票=合规辩护人”会对真实违规给出“可辩护解释”而拒绝候选
    （注入基准 Q13：正票确认 600 元与批准的分段计算矛盾，反票理由自身结论也是
    “不符合”，但输出 comply=true）。这类候选的引文可逐字回查，若直接丢弃，
    “直连大模型能定位的问题”在平台最终 finding 里就丢了。

    做法（不改变匹配口径、不放宽双票主规则）：
    - 同码同事项（同编号已批准条件）已有 finding：只把候选作为补充证据并入既有
      finding（decision=retained_supplementary），不重复造第二条；
    - 同码但不同事项/无既有 finding：落一条 state=insufficient、certainty=abstain、
      标题带【低置信覆盖保留】的 finding（decision=retained_insufficient），进入人工
      复核；该 finding 计入“最终 finding 覆盖”，但**不代表平台已判定违规**。
    - 被保留的码进入 ``retained_codes``，交叉一致性门不再二次降级这些码的 finding。

    准入见 ``_retain_eligible``。默认 MODE>=3 才启用（tier3），可单独关闭。
    """
    if not rejected_pool:
        return
    pending = []
    for c in rejected_pool:
        if c.get("reclassify_checked") == "moved":
            continue  # 已被码归属重判迁移并落库，不再重复保留
        ok, why = _retain_eligible(c, idx, d5_by_code)
        c["retain_trace"] = {"eligible": bool(ok), "reason": why,
                             "prior_d5": c.get("prior_d5") or ""}
        if ok:
            pending.append(c)
    if not pending:
        return
    stats["retain_eligible"] = len(pending)
    for c in pending:
        code = str(c.get("code") or "")
        rule = by_code.get(code) or {"code": code, "name": code, "criterion": ""}
        _why = _skip_cross_or_approved(idx, c, collected, doc_texts, stats)
        if _why:
            c["retain_trace"].update({"retained": False, "reason": _why})
            stats.setdefault("retain_trace", []).append(dict(c["retain_trace"], code=code))
            continue
        existing = [f for f in (collected or []) if _entry_code(f) == code]
        same = [f for f in existing if _same_issue_as_findings(idx, c, [f])]
        if same:
            decision = _merge_existing(same[0], c, doc_texts, allow_anchor=True)
            c["decision"] = "retained_supplementary"
            stats["retained_evidence"] += 1
            c["retain_trace"].update({"retained": True, "mode": "supplementary",
                                      "merged_into": str(same[0].get("id") or ""),
                                      "merge_decision": decision})
        else:
            c["retained"] = True
            c["retain_trace"].update({"retained": True, "mode": "insufficient",
                                      "clause_id": c.get("clause_id") or ""})
            _materialize(case_id, run_id, doc_texts, c, rule, collected, stats)
            c["retain_trace"]["finding_id"] = str((collected[-1] or {}).get("id") or "") \
                if collected else ""
        if code and code not in stats["retained_codes"]:
            stats["retained_codes"].append(code)
        trace = dict(c["retain_trace"])
        trace.update({"code": code,
                      "clause_id": c.get("clause_id") or "",
                      "quote": str(c.get("quote") or "")[:120]})
        stats["retain_trace"].append(trace)
        st = c.get("_stat")
        if isinstance(st, dict):
            st["decision"] = c.get("decision") or ""
            st["in_system"] = True
            st["retain_trace"] = c.get("retain_trace")

