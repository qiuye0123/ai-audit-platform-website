"""实体解析（只产出候选证据，不自动合并）。

参考 ONTOS 的 entity-resolution 思路，裁剪到审核本体：
- 名称归一（NFKC、去空白/标点/括注）；
- 中文短名用 bigram Dice，辅以编辑距离；
- 标识字段（code/no）都有值且不同 → 直接判为不同实体，避免“工艺单号=工单号”这类错误；
- 结果只作为人工审核候选，绝不自动写别名。
"""
import re
import unicodedata


def norm_text(value) -> str:
    s = unicodedata.normalize("NFKC", str(value or "")).lower()
    s = re.sub(r"[\s\u3000]+", "", s)
    s = re.sub(r"[（(].*?[）)]", "", s)
    s = re.sub(r"[^\w\u4e00-\u9fff]", "", s)
    return s


def _bigrams(s: str) -> set:
    if len(s) <= 2:
        return {s} if s else set()
    return {s[i:i + 2] for i in range(len(s) - 1)}


def _lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def similarity(left, right) -> float:
    a, b = norm_text(left), norm_text(right)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    sa, sb = _bigrams(a), _bigrams(b)
    dice = (2 * len(sa & sb) / (len(sa) + len(sb))) if (sa or sb) else 0.0
    ratio = 1 - _lev(a, b) / max(len(a), len(b))
    return round(max(0.0, min(1.0, max(dice, ratio))), 4)


def compare_instances(left: dict, right: dict) -> dict:
    """返回匹配分数和证据；有冲突标识时分数直接为 0。"""
    lc = str(left.get("code") or left.get("no") or "").strip()
    rc = str(right.get("code") or right.get("no") or "").strip()
    if lc and rc and norm_text(lc) != norm_text(rc):
        return {"score": 0.0, "same_type": left.get("type_key") == right.get("type_key"),
                "evidence": [{"field": "code", "left": lc, "right": rc, "similarity": 0.0,
                              "reason": "标识不同，禁止仅按名称合并"}]}
    s = similarity(left.get("name"), right.get("name"))
    return {"score": s, "same_type": left.get("type_key") == right.get("type_key"),
            "evidence": [{"field": "name", "left": left.get("name"), "right": right.get("name"),
                          "similarity": s}]}


def candidates(items: list, threshold: float = 0.86) -> list:
    """同类型内找疑似重复；只返回候选，供人工看证据。"""
    out = []
    for i, a in enumerate(items):
        for b in items[i + 1:]:
            r = compare_instances(a, b)
            if r["same_type"] and r["score"] >= threshold:
                out.append({"left": a, "right": b, **r})
    return out
