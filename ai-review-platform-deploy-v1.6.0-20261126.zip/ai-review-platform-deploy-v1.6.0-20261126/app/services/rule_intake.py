"""规则挖掘对话入口：自然语言/制度片段 → 补问 ≤3 轮 → 规则草稿。

设计边界：
- 只落草稿，不自动提交/批准/发布；
- 规则必须先有可执行判据（criterion 或 metric/op/value），否则继续问；
- 第 3 轮仍不完整时允许保存为“待完善草稿”，但明确 warnings，不能参与审核。
"""
from __future__ import annotations
import json

from .. import db
from .. import repositories as R
from . import rule as _rule


def _slots(rule: dict) -> dict:
    return dict((rule or {}).get("slots") or {})


def assess(rule: dict) -> dict:
    """返回缺失字段和问题；不调用模型。"""
    slots = _slots(rule)
    missing, questions = [], []
    crit = str(slots.get("criterion") or "").strip()
    metric = str(slots.get("metric") or slots.get("parameter") or "").strip()
    op = str(slots.get("op") or slots.get("operator") or "").strip()
    value = slots.get("value", slots.get("threshold"))
    scope = (slots.get("scope") or slots.get("applicable_when")
             or (rule.get("scope") or {}).get("scope"))
    evidence = (slots.get("evidence") or (rule.get("scope") or {}).get("evidence"))
    # 判据里已经写明证据口径（以…为证据/证据不足判…）也视为完整，不再追问
    if not evidence and crit and any(k in crit for k in ("证据", "待补证", "以实测", "实测记录")):
        evidence = crit
    if not crit and not (metric and (value is not None or op)):
        missing.append("判定对象/判据")
        questions.append("这条规则要判断哪个对象或指标？满足/不满足的条件是什么？")
    elif metric and value is None and not crit:
        missing.append("阈值")
        questions.append(f"“{metric}”的阈值是多少？请同时给出单位。")
    if not scope:
        missing.append("适用范围")
        questions.append("这条规则适用于哪些文件、批次或业务范围？")
    if not evidence:
        missing.append("证据要求")
        questions.append("什么证据算充分？证据缺失时是判不通过还是待补证？")
    return {"complete": not missing, "missing": missing, "questions": questions[:3]}


def _user_text(messages: list) -> str:
    out = []
    for m in messages or []:
        if str(m.get("role") or "") == "user":
            c = str(m.get("content") or "").strip()
            if c:
                out.append(c)
    return "\n".join(out)


def chat(messages: list, save: bool = False, confirm: bool = False, user: str = "") -> dict:
    from . import agents
    messages = messages or []
    text = _user_text(messages)
    if not text:
        return {"error": "请输入规则描述", "status": "need_info"}
    try:
        rr = agents.run_agent("agent-rulegen", {"text": text, "save": False})
    except Exception as e:
        return {"error": f"规则生成智能体不可用：{type(e).__name__}", "status": "error"}
    # B3-01（评审 P1）：与 /rule/parse、/rule/decompose 同口径接受 degraded。
    # 修复前只接受 status=='ok'，而没接真实大模型时 agent-rulegen 走确定性回退、
    # 状态是 'degraded' → 一句话入口在无模型环境 100% 400（演示即失败）。
    # 现在：ok / degraded 都继续出草稿，并在响应里带 degraded=true +
    # agent_status（前端据此提示「确定性判据，非模型生成」）；fail 才报错。
    _agent_status = str(rr.get("status") or "")
    if _agent_status not in ("ok", "degraded"):
        return {"error": str((rr.get("result") or {}).get("error") or "规则生成智能体不可用"),
                "status": "error"}
    _degraded = (_agent_status == "degraded")
    parsed = rr.get("result") or {}
    slots = _slots(parsed)
    try:
        from . import rule_form as _rf
        _form = _rf.decide(text, slots)
    except Exception:
        _form = {"form": "single", "confidence": 0.5, "reasons": []}
    _representation = _form.get("form") or parsed.get("representation") or "single"
    _form_reason = "；".join(_form.get("reasons") or [])
    a = assess(parsed)
    rounds = sum(1 for m in messages if str(m.get("role") or "") == "assistant")
    # 第 3 轮不再追问，转为“待完善草稿”，但明确不能参与审核
    if not a["complete"] and rounds < 3:
        return {"status": "need_info", "round": rounds + 1, "max_rounds": 3,
                "questions": a["questions"], "missing": a["missing"],
                "degraded": _degraded, "agent_status": _agent_status,
                "draft": {"name": parsed.get("name") or "规则草稿",
                          "category": parsed.get("category") or "consistency",
                          "rclass": parsed.get("rclass") or "R4",
                          "slots": slots, "representation": _representation,
                          "form_reason": _form_reason}}
    warnings = [] if a["complete"] else [f"信息仍缺失：{'、'.join(a['missing'])}；保存后不能参与审核"]
    draft = {"name": parsed.get("name") or "规则草稿",
             "category": parsed.get("category") or "consistency",
             "rclass": parsed.get("rclass") or "R1",
             "slots": slots, "warnings": warnings,
             "representation": _representation, "form_reason": _form_reason,
             "ready": bool(a["complete"])}
    if _representation == "decision_table" and save and confirm:
        return {"status": "decision_table", "draft": draft,
                "message": "系统判定为决策表组合多条件；请用决策表编辑器，不按单条规则保存",
                "form_reason": _form_reason,
                "degraded": _degraded, "agent_status": _agent_status}
    if save and confirm and a["complete"]:
        try:
            scope = {"criterion": str(slots.get("criterion") or ""),
                     "description": str(slots.get("criterion") or ""),
                     "scope": str(slots.get("scope") or ""),
                     "evidence": str(slots.get("evidence") or ""),
                     "source": "conversation"}
            r = _rule.create_rule(code=f"RC-{db.new_id('x')[:6].upper()}",
                                  name=draft["name"], category=draft["category"],
                                  rclass=draft["rclass"], slots=slots,
                                  source="conversation", scope=scope)
            R.audit_logs.log(actor=user or "system", action="rule.draft_from_conversation",
                             object=r.get("rule_id") or "")
            return {"status": "saved", "rule_id": r.get("rule_id"), "draft": draft,
                    "degraded": _degraded, "agent_status": _agent_status,
                    "message": "已生成规则草稿，请到规则库草稿箱确认后再提交审批"}
        except Exception as e:
            return {"error": f"保存草稿失败：{type(e).__name__}: {str(e)[:120]}", "status": "error"}
    return {"status": "ready" if a["complete"] else "incomplete", "draft": draft,
            "missing": a["missing"], "warnings": warnings,
            "degraded": _degraded, "agent_status": _agent_status,
            "message": "信息已完整，请确认后保存为草稿" if a["complete"]
            else "信息仍不完整；已到 3 轮上限，可保存为待完善草稿，但不能参与审核"}
