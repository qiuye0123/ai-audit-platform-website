"""四件语义交付物导出：企业术语库 / 统一规则卡 / manifest+执行计划 / 可追溯结果。

DMN 决策表作为规则卡的显式依赖导出；是否执行仍由审核链的 decision_table 模块决定，
本导出不伪造“manifest 已执行 DMN”。
"""
from __future__ import annotations
import csv
import json
import os
from pathlib import Path
from .. import db, repositories as R
from . import rule_card


def _latest_manifest(case_id: str) -> dict:
    with db.session() as c:
        ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? AND manifest_id!='' "
                       "ORDER BY created_at DESC LIMIT 1", (case_id,)).fetchone()
        mid = (ar["manifest_id"] if ar else "") or ""
        if not mid:
            r = c.execute("SELECT id FROM audit_manifest WHERE case_id=? ORDER BY rowid DESC LIMIT 1",
                          (case_id,)).fetchone()
            mid = (r["id"] if r else "") or ""
        if not mid:
            return {}
        m = c.execute("SELECT * FROM audit_manifest WHERE id=?", (mid,)).fetchone()
        return dict(m) if m else {}


def _cards() -> list:
    out = []
    for r in R.rules.list("status=?", ("published",), order="code"):
        v = R.rules.latest_version(r["id"]) or {}
        try:
            slots = json.loads(v.get("slots_json") or "{}")
        except Exception:
            slots = {}
        card = rule_card.build({**r, "version": v.get("version") or ""}, slots)
        out.append(card)
    return out


def _terms() -> list:
    from . import terms
    return terms.list_terms()


def _dmn(cards: list) -> list:
    rows = []
    for t in R.decision_tables.list(order="code"):
        try:
            rules = json.loads(t.get("rules_json") or "[]")
            scope = json.loads(t.get("scope_types") or "[]")
        except Exception:
            rules, scope = [], []
        refs = [c["code"] for c in cards if t.get("code") in (c.get("decision_tables") or [])]
        rows.append({"code": t.get("code"), "name": t.get("name"), "version": t.get("version"),
                     "status": t.get("status"), "hit_policy": t.get("hit_policy"),
                     "scope_types": scope, "rows": len(rules),
                     "referenced_by_rules": refs,
                     "dependency": "explicit" if refs else "unreferenced"})
    return rows


def _trace(case_id: str) -> list:
    with db.session() as c:
        rows = [dict(x) for x in c.execute(
            "SELECT ma.case_id,ma.object_id,ma.rule_code,mr.id AS result_id,"
            "mr.d1_json,mr.d2_json,mr.d3_json,mr.d4_json,mr.d5_json,mr.conclusion,mr.execution,"
            "a.hash AS manifest_hash FROM manifest_active ma "
            "JOIN manifest_result mr ON mr.id=ma.result_id "
            "JOIN audit_manifest a ON a.id=mr.manifest_id WHERE ma.case_id=? "
            "ORDER BY ma.rule_code,ma.object_id", (case_id,))]
        if not rows:
            rows = [dict(x) for x in c.execute(
                "SELECT r.case_id,r.object_id,r.rule_code,r.id AS result_id,"
                "r.d1_json,r.d2_json,r.d3_json,r.d4_json,r.d5_json,r.conclusion,r.execution,"
                "a.hash AS manifest_hash FROM manifest_result r "
                "JOIN audit_manifest a ON a.id=r.manifest_id WHERE r.case_id=? "
                "ORDER BY r.rule_code,r.object_id", (case_id,))]
        objs, vers = {}, {}
        for a in c.execute("SELECT objects_json,rules_json FROM audit_manifest WHERE case_id=?", (case_id,)):
            try:
                for o in json.loads(a["objects_json"] or "[]"):
                    objs[o.get("object_id")] = o.get("filename")
                for r0 in json.loads(a["rules_json"] or "[]"):
                    if r0.get("code"):
                        vers[r0["code"]] = r0.get("version") or ""
            except Exception:
                pass
    out = []
    for r in rows:
        try:
            subs = (json.loads(r.get("d4_json") or "{}")).get("subs") or []
            d5 = json.loads(r.get("d5_json") or "{}")
            d1 = json.loads(r.get("d1_json") or "{}")
        except Exception:
            subs, d5, d1 = [], {}, {}
        base = {"case_id": r.get("case_id"), "object_id": r.get("object_id"),
                "filename": objs.get(r.get("object_id"), ""), "rule_code": r.get("rule_code"),
                "rule_version": vers.get(r.get("rule_code"), ""), "result_id": r.get("result_id"),
                "d1_status": d1.get("status"), "conclusion": r.get("conclusion"),
                "execution": r.get("execution"), "manifest_hash": r.get("manifest_hash"),
                "review_status": "pending"}
        if not subs:
            out.append({**base, "sub_id": "", "sub_status": "", "sub_quote": "",
                        "d5_status": d5.get("status", "")})
        else:
            for s in subs:
                out.append({**base, "sub_id": s.get("id") or "", "sub_status": s.get("status") or "",
                            "sub_quote": s.get("quote") or "", "d5_status": d5.get("status", "")})
    return out


def build(case_id: str, out_dir: str = "") -> dict:
    if not case_id:
        return {"error": "缺少 case_id"}
    out = Path(out_dir or os.path.join("docs", "artifacts", case_id))
    out.mkdir(parents=True, exist_ok=True)
    terms = _terms()
    cards = _cards()
    dmn = _dmn(cards)
    m = _latest_manifest(case_id)
    trace = _trace(case_id)

    (out / "企业术语库.json").write_text(json.dumps(terms, ensure_ascii=False, indent=1), encoding="utf-8")
    with (out / "企业术语库.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["term_key", "name", "definition", "synonyms", "not_equal", "entity_type",
                    "unit", "relations", "scope", "version", "status", "source"])
        for t in terms:
            w.writerow([t.get("key"), t.get("name"), t.get("definition"),
                        "|".join(t.get("synonyms") or []), "|".join(t.get("not_equal") or []),
                        t.get("entity_type"), t.get("unit"),
                        json.dumps(t.get("relations") or [], ensure_ascii=False),
                        t.get("scope"), t.get("version"), t.get("status"), t.get("source")])

    (out / "统一规则卡.json").write_text(json.dumps(cards, ensure_ascii=False, indent=1), encoding="utf-8")
    md = ["# 统一规则卡", "", f"共 {len(cards)} 条已发布规则。", ""]
    for c in cards:
        md += [f"## {c.get('code')} {c.get('name')}", "",
               f"- 版本：{c.get('version')}；风险等级：{c.get('severity')}",
               f"- 判据：{c.get('criterion')}",
               f"- 范围：{c.get('scope')}",
               f"- 证据：{c.get('evidence')}",
               f"- 例外：{'；'.join(c.get('exceptions') or []) or '无'}",
               f"- 决策表依赖：{', '.join(c.get('decision_tables') or []) or '无'}", ""]
    (out / "统一规则卡.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    manifest = {k: m.get(k) for k in ("id", "case_id", "tenant_id", "workspace_id", "source",
                                      "status", "hash", "created_at", "created_by")}
    manifest["objects"] = json.loads(m.get("objects_json") or "[]") if m else []
    manifest["rules"] = json.loads(m.get("rules_json") or "[]") if m else []
    manifest["items"] = json.loads(m.get("items_json") or "[]") if m else []
    (out / "audit_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    plan = {"manifest_id": manifest.get("id"), "hash": manifest.get("hash"),
            "policy": "frozen manifest is authoritative for customer rules",
            "objects": [{"object_id": o.get("object_id"), "filename": o.get("filename"),
                         "doc_type": o.get("doc_type")} for o in manifest["objects"]],
            "items": [{"rule": i.get("code"), "rule_version": i.get("version"),
                       "object_id": i.get("object_id"), "filename": i.get("filename"),
                       "steps": i.get("steps") or [], "combination": i.get("combination"),
                       "decision_tables": i.get("decision_tables") or [],
                       "evidence_required": i.get("evidence_required"),
                       "on_insufficient": i.get("on_insufficient")}
                      for i in manifest["items"]]}
    (out / "执行计划.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")

    cols = ["case_id", "object_id", "filename", "rule_code", "rule_version", "result_id",
            "d1_status", "sub_id", "sub_status", "sub_quote", "d5_status", "conclusion",
            "execution", "review_status", "manifest_hash"]
    with (out / "审核结果追溯.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in trace:
            w.writerow({k: r.get(k, "") for k in cols})

    (out / "DMN决策依赖.json").write_text(json.dumps(dmn, ensure_ascii=False, indent=1), encoding="utf-8")
    meta = {"case_id": case_id, "manifest_id": manifest.get("id"), "manifest_hash": manifest.get("hash"),
            "terms": len(terms), "cards": len(cards), "decision_tables": len(dmn),
            "trace_rows": len(trace),
            "files": sorted(p.name for p in out.iterdir() if p.is_file())}
    (out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"ok": True, **meta, "out_dir": str(out)}
