"""运行版本快照（P0-6）：让历史结论可复现、可追责。

记录：文件哈希、解析器、规则、参数、本体、提示词、模型、采样、执行器版本。
存储：sys_config key = manifest:<case_id>:<run_id>

审核清单冻结同时承担「全来源发布门禁」：

- 规则库 / 词典 / 决策表 / 挖掘 四个来源的已发布物走同一套检查：
  已发布、作用域已声明、引用的决策表已发布且有版本、引用的术语已确认、
  且能接入 A–G / 69 审核类型 / 302 审核点路由树；
- 未声明 scope 的规则默认只冻结为「项目级 1 条」，不按对象放大；
  显式 ``freeze_all=True``（或环境变量/空间配置）才逐对象全量；
- DB 规则按 point_mapping 接入 302 点位 → 69 审核类型 → A–G 大类；
  manifest item 数受文件类型/业务范围/审核类型路由约束。

说明：``freeze`` 的 ``ok`` 只表示清单已落库；门禁结果单独放在 ``gate``。
被门禁拦截的规则不会进入 items（``gate.blocked`` 可追溯），
路由不适用于本项目的规则进入 ``gate.routed_out``，不会静默丢规则。

冻结闭包（V01）与对象绑定（V02）：

- 冻结闭包：每次 ``freeze`` 除清单外还固化本次 run 真正依赖的**内容**——
  原始文件字节 sha256（不是 document_id）、解析产物哈希、解析器/OCR 配置指纹、
  业务参考时间/时区、外部查询结果（值+来源+获取时间戳）、单位字典、规则冲突
  优先级、规则版本内容哈希；``execution_guard`` 在执行前校验闭包，文件同
  document_id 换内容/解析器配置漂移/决策表同版本改内容 → 完整性阻断（0 执行）；
- 对象绑定：manifest item 从「规则集」升级为
  ``(rule_version, subject/object/relationship, subrequirement, scope_predicate)``
  绑定；``allowed_object_ids`` 是硬边界，``selected_object_ids ⊆ allowed``；
  越界对象在守卫层硬拒并写审计，不进入执行/不产出 finding；
- 兼容：本次改动前冻结的旧清单没有闭包，``execution_guard`` 返回 legacy 放行，
  不误伤历史 run；闭包构建失败会显式记录 ``closure.error`` 并把 manifest 标记
  ``closure.degraded``，不静默假装完整性已校验。
"""
import hashlib
import logging
import json
import os
from datetime import datetime, timezone

from .. import config, db
from .. import repositories as R
# T-161 三区分层：冻结时只给 item 加 zone 标记字段，不参与任何执行/判定
from . import audit_zone as _audit_zone
# L80 / P0-C：路由三列计数（mapped/builtin/actual/routed_out/unattributed）。
# 只在开关=1 时冻结 gate 写 extra 字段 + routed_out 明细加 object_count；=0 时
# gate 逐字段与接入前一致（本模块只 import，不产生任何读写）。
from . import adjudication_ledger as _adj_ledger

# manifest 路由只认明确的文件扩展名；扩展名之外一律按业务范围处理
_KNOWN_EXT = {"xlsx", "xls", "docx", "doc", "pdf", "txt", "csv", "md",
              "markdown", "json", "xml", "html", "png", "jpg", "jpeg"}
# 词典的「已发布」口径：人工确认或旧 ontology_terms 迁移后的 active
_EFFECTIVE_TERM_STATUS = ("confirmed", "active")
_SOURCE_LABELS = {
    "rule_library": "规则库",
    "dictionary": "词典",
    "decision_table": "决策表",
    "mining": "挖掘",
}
# 四来源同一门禁的检查项（顺序稳定，便于报告/测试比对）
_GATE_CHECKS = ("published", "scope_route", "decision_tables_published",
                "terms_effective", "route_resolved")
_GATE_VERSION = "all_sources_v1"

# ---------------------------------------------------------------- 冻结闭包常量
CLOSURE_SCHEMA = "manifest_closure_v1"
CLOSURE_PREFIX = "manifest_closure:"
ARTIFACT_PREFIX = "manifest_artifact:"
# A6（2026-11-21）：新清单「必须有可校验闭包」标记。与闭包分开落库：即使闭包落库
# 失败，execution_guard 也能识别这是新清单，不得按 legacy 放行（强制重冻）。
CLOSURE_REQUIRED_PREFIX = "manifest_closure_required:"
BINDING_SCHEMA = "manifest_binding_v1"
_CLOSURE_DIGEST_LEN = 24
# 每个文件的解析文本最多落库多少字符（哈希始终覆盖全文；文本只用于回放/证据）。
_ARTIFACT_TEXT_LIMIT = 200_000
# 影响解析结果的代码/依赖模块：任一变化都可能导致同一文件解析出不同文本。
_PARSER_CLOSURE_MODULES = (
    ("engine.deepparse", "app/engine/deepparse.py"),
    ("engine.docparse", "app/engine/docparse.py"),
    ("engine.pdf_render", "app/engine/pdf_render.py"),
    ("services.parse_bridge", "app/services/parse_bridge.py"),
    ("engine.ocr", "app/engine/ocr.py"),
    ("engine.baidu_ocr", "app/engine/baidu_ocr.py"),
    ("engine.paddleocr", "app/engine/paddleocr.py"),
)
# 规则槽位里属于「外部查询/外部输入」的键：冻结闭包逐项固化值，执行期不重查。
_EXTERNAL_INPUT_KEYS = frozenset({
    "rate", "rate_value", "rate_source", "rate_version", "rate_date", "rate_direction",
    "rate_pair", "valid_until", "as_of", "max_age_days", "calendar", "calendar_version",
    "calendar_source", "holidays", "makeup_workdays", "coverage_start", "coverage_end",
    "external_facts", "facts", "fx", "holiday_calendar",
})
# 冲突裁决顺序：先显式 priority，再决策表 priority/hit_policy，最后按清单顺序；
# 冻结后执行期不再读实时冲突表（本顺序随闭包一起固化）。
_CONFLICT_RESOLUTION_ORDER = ("rule_slots.priority", "decision_tables.priority",
                              "decision_tables.hit_policy", "manifest_item_order")



def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:12]


def _module_sha(path: str) -> str:
    try:
        p = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), path)
        return _sha(open(p, "rb").read())
    except Exception:
        return ""


def effective_rule_rows() -> list:
    """规则执行/冻结的单一来源（T-107 P0-01）：返回 [(rule_row, published_version)]。

    生效口径 = ``current_version_id`` 指向、且版本 status=published（旧库无指针时
    ``repositories.published_version`` 回退最新 published 版本）。**不看 rule.status**：
    编辑/回滚已发布规则会把 rule.status 置 draft 并 fork 草稿，但旧 published 版本
    继续生效，直到新版本发布；archived 规则无 published 版本 → 不再执行。
    """
    out = []
    try:
        rows = R.rules.list() or []
    except Exception:
        logging.getLogger(__name__).debug("effective rule list failed", exc_info=True)
        rows = []
    for r in rows:
        try:
            v = R.rules.published_version(r["id"]) or {}
        except Exception:
            v = {}
        if not v:
            continue
        out.append((r, v))
    return out


# ---------------------------------------------------------------- 版本级规则作用域快照
# T-136 C-1（P0）：作用域（scope）属于「版本内容」，不是规则主记录的可变属性。
# 原实现 update_draft 直接把草稿 scope 写回 ``rule.scope_json``，而 freeze 又从
# rule 主记录读 scope → 编辑未发布草稿会改变旧 published 版本（生效版本）的审核对象。
#
# 存储口径（不新增 schema 列；写作用域不含 app/db.py）：
#   sys_config key = ``rulever_scope:<rule_version.id>``，value = 该版本作用域的 JSON。
# 读口径：freeze 只经「生效 published 版本 id」读快照；旧库没有快照时双读回退
#   ``rule.scope_json``（见 ``version_scope``）。迁移：create/publish/编辑 fork 时
#   写快照；编辑已发布规则时先把「编辑前主记录 scope」补写进旧生效版本快照，
#   再改主记录，保证旧版本对象集合不漂移。旧数据在修复前的历史漂移不可追溯，
#   但自首次编辑/发布起以版本级快照为准。
RULE_SCOPE_SNAPSHOT_PREFIX = "rulever_scope:"


def rule_scope_snapshot_key(version_id: str) -> str:
    return RULE_SCOPE_SNAPSHOT_PREFIX + str(version_id or "")


def load_rule_scope_snapshots(version_ids, conn=None) -> dict:
    """批量读版本级作用域快照：{version_id: scope_dict}；无快照/读取失败返回空 dict。

    读取失败只影响旧数据双读回退（回退 rule 主记录），不阻断冻结——但会在 warning
    中显式暴露，不做静默吞掉。
    """
    ids = [str(x) for x in (version_ids or []) if str(x).strip()]
    if not ids:
        return {}
    keys = [rule_scope_snapshot_key(x) for x in ids]
    rows = []
    try:
        sql = "SELECT key,value FROM sys_config WHERE key IN (%s)" % ",".join("?" * len(keys))
        if conn is not None:
            rows = conn.execute(sql, keys).fetchall()
        else:
            with db.session() as c:
                rows = c.execute(sql, keys).fetchall()
    except Exception:
        logging.getLogger(__name__).warning(
            "rule scope snapshot read failed (fallback to rule.scope_json)", exc_info=True)
        return {}
    by_key = {rule_scope_snapshot_key(x): x for x in ids}
    out = {}
    for row in rows:
        vid = by_key.get(str(row[0] or ""))
        if not vid:
            continue
        try:
            scope = json.loads(row[1] or "{}")
        except Exception:
            scope = {}
        if isinstance(scope, dict):
            out[vid] = scope
    return out


def save_rule_scope_snapshot(version_id: str, scope: dict, conn=None) -> bool:
    """写版本级作用域快照（幂等覆盖；调用方可传入事务连接以与业务写同事务）。"""
    vid = str(version_id or "")
    if not vid or not isinstance(scope, dict):
        return False
    payload = json.dumps(scope, ensure_ascii=False, sort_keys=True)
    key = rule_scope_snapshot_key(vid)

    def _write(c):
        c.execute("INSERT INTO sys_config(key,value,updated_at) VALUES(?,?,?) "
                  "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
                  "updated_at=excluded.updated_at", (key, payload, db.now()))

    try:
        if conn is not None:
            _write(conn)
        else:
            with db.session() as c:
                _write(c)
        return True
    except Exception:
        logging.getLogger(__name__).warning(
            "rule scope snapshot save failed version=%s", vid, exc_info=True)
        return False


def ensure_rule_scope_snapshot(rule_id: str, version_id: str, scope: dict = None,
                               conn=None) -> bool:
    """旧数据迁移：版本缺快照时补写一次；已有快照不覆盖（版本内容不可变）。"""
    vid = str(version_id or "")
    if not vid:
        return False
    if load_rule_scope_snapshots([vid], conn=conn).get(vid) is not None:
        return False
    if scope is None:
        try:
            scope = json.loads((R.rules.get(str(rule_id or "")) or {}).get("scope_json") or "{}")
        except Exception:
            scope = {}
    if not isinstance(scope, dict):
        scope = {}
    return save_rule_scope_snapshot(vid, scope, conn=conn)


def version_scope(rule_row: dict, version_row: dict, snapshots: dict = None) -> tuple:
    """freeze/执行读取规则作用域的唯一口径：版本级快照优先，旧数据双读回退。

    返回 ``(scope_obj, source)``，source ∈ {"version_snapshot", "rule_legacy"}。
    rule_legacy 仅用于修复前的旧版本（无版本级快照）：首次编辑/发布时会被固化。
    """
    vid = str((version_row or {}).get("id") or "")
    scope = None
    if vid:
        if snapshots is not None:
            scope = snapshots.get(vid)
        else:
            scope = load_rule_scope_snapshots([vid]).get(vid)
    if isinstance(scope, dict) and scope:
        return scope, "version_snapshot"
    try:
        legacy = json.loads((rule_row or {}).get("scope_json") or "{}")
    except Exception:
        legacy = {}
    return (legacy if isinstance(legacy, dict) else {}), "rule_legacy"


def build(case_id: str) -> dict:
    docs = [d for d in (R.documents.list() or [])]
    from . import project as _pj
    try:
        docs = _pj.documents(case_id)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    files = []
    for d in docs:
        _content_sha, _size, _err = _file_content_digest(str(d.get("path") or ""))
        files.append({"name": d.get("filename"),
                      "hash": d.get("hash") or _sha(d.get("path") or ""),
                      "parse_status": d.get("parse_status"),
                      # V01：原始文件内容标识（字节 sha256）；document_id/hash 字段可被历史截断
                      "document_id": d.get("id") or "",
                      "content_sha256": _content_sha,
                      "size": _size,
                      "readable": bool(_content_sha),
                      "read_error": _err})

    rules = effective_rule_rows()
    rule_sig, rule_priority = [], []
    for r, _v in rules:
        rule_sig.append(f"{r.get('code')}:{_v.get('version','')}")
        try:
            _slots = json.loads(_v.get("slots_json") or "{}")
        except Exception:
            _slots = {}
        if not isinstance(_slots, dict):
            _slots = {}
        rule_priority.append({"code": r.get("code") or "",
                              "version": _v.get("version") or "",
                              "priority": _slots.get("priority"),
                              "decision_policy": _slots.get("decision_policy") or "conflict"})
    rule_sig = sorted(rule_sig)

    try:
        from . import ruleparam
        params = ruleparam.list_all() if hasattr(ruleparam, "list_all") else []
        param_sig = _sha(json.dumps(params, ensure_ascii=False, sort_keys=True))
    except Exception:
        param_sig = ""

    try:
        from . import ontology_service as _ontology
        onto_sig = _sha(json.dumps(_ontology.gate_overrides(), ensure_ascii=False, sort_keys=True))
    except Exception:
        onto_sig = ""

    try:
        from ..engine import llm_router
        cfg = llm_router.resolve()
        model = f"{cfg.get('model','')}@{cfg.get('base_url','')}"
    except Exception:
        model = os.environ.get("RULEPROOF_LLM_MODEL", "")

    prompt_sig = ""
    try:
        from . import auditpoints as ap
        prompt_sig = getattr(ap, "PROMPT_VERSION", "")
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)

    # V01：解析器 + OCR 配置指纹（同文件在不同解析/OCR 配置下会得到不同文本）
    try:
        _parser_ocr = _parser_ocr_closure()
    except Exception:
        _parser_ocr = {"sha": "", "ocr": {}, "modules": {}}
    # V01：业务参考时间/时区（v2 快照记录；冻结闭包以 freeze 时刻为准）
    try:
        _reference = _reference_closure()
    except Exception:
        _reference = {}
    # V01：单位字典（执行器换算表 + 量纲；规则实际使用单位见 freeze 闭包）
    try:
        from . import terms as _terms_b
        _terms_units = []
        for _t in (_terms_b.list_terms() or []):
            if str(_t.get("status") or "").lower() in _EFFECTIVE_TERM_STATUS:
                _terms_units.append({"name": _t.get("name") or "", "unit": _t.get("unit") or ""})
        _units = _unit_dictionary_closure(_terms_units, [])
    except Exception:
        _units = {"sha": "", "count": 0}
    # V01：规则冲突优先级（显式 priority；冲突检测在 freeze 闭包里做全量两两分析）
    _conflict = {"rules": rule_priority,
                 "resolution_order": list(_CONFLICT_RESOLUTION_ORDER),
                 "note": "build 快照只记录优先级口径；冻结闭包另存冻结时的冲突检测结论"}
    _conflict["sha"] = _digest(_conflict)

    return {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "case_id": case_id,
        "files": files,
        "parser": {"name": "deepparse", "sha": _module_sha("app/engine/deepparse.py"),
                   "modules_sha": _parser_ocr.get("modules_sha") or "",
                   "ocr": _parser_ocr.get("ocr") or {},
                   "sha_v01": _parser_ocr.get("sha") or ""},
        "rules": {"count": len(rules), "sha": _sha("|".join(rule_sig)),
                  "priority": rule_priority,
                  "mode": "effective_published_version",
                  "status_policy": "current_version_id+published（不看 rule.status）"},
        "params_sha": param_sig,
        "ontology_sha": onto_sig,
        "prompt_version": prompt_sig,
        "model": model,
        "sampling": {"votes": int(os.environ.get("RULEPROOF_VOTES", "1") or 1),
                     "cache": os.environ.get("RULEPROOF_LLM_CACHE", "1")},
        "executors": {"ruleexec": _module_sha("app/engine/ruleexec.py"),
                      "assertions": _module_sha("app/services/assertions.py")},
        # V01 闭包摘要（完整闭包随 freeze 落 manifest_closure:<manifest_id>）
        "reference": _reference,
        "units_sha": _units.get("sha") or "",
        "units_count": _units.get("count") or 0,
        "conflict_priority_sha": _conflict.get("sha") or "",
        "closure_schema": CLOSURE_SCHEMA,
    }


def save(case_id: str, run_id: str, m: dict = None) -> dict:
    m = m or build(case_id)
    key = f"manifest:{case_id}:{run_id}"
    from . import sysconfig
    sysconfig.set_many({key: json.dumps(m, ensure_ascii=False)})
    return {"key": key, "manifest": m}


def load(case_id: str, run_id: str) -> dict:
    from . import sysconfig
    raw = sysconfig.get(f"manifest:{case_id}:{run_id}", "")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def diff(a: dict, b: dict) -> list:
    out = []
    for k in ("parser", "rules", "params_sha", "ontology_sha", "prompt_version", "model", "sampling", "executors"):
        if a.get(k) != b.get(k):
            out.append({"field": k, "a": a.get(k), "b": b.get(k)})
    if [f.get("hash") for f in a.get("files", [])] != [f.get("hash") for f in b.get("files", [])]:
        out.append({"field": "files", "a": "different", "b": "different"})
    return out


# ---------------- 审核清单（对象 × 已发布规则版本），与“运行快照”分开 ----------------
def _decision_snapshots(codes) -> list:
    """冻结决策表版本，避免 manifest 锁了规则版本却让 DMN 漂移。"""
    out = []
    if isinstance(codes, str):
        codes = [codes]
    for _idx, code in enumerate(codes or []):
        try:
            from . import decision_table as _dt
            d = _dt.detail(str(code))
        except Exception:
            d = {}
        if not d or str(d.get("status") or "") != "published":
            out.append({"code": str(code), "status": "missing_or_unpublished"})
            continue
        import hashlib as _h
        rules_json = __import__("json").dumps(d.get("rules") or [], ensure_ascii=False)
        out.append({"code": d.get("code"), "version": d.get("version"),
                    "hit_policy": d.get("hit_policy"),
                    "rules_hash": _h.sha256(rules_json.encode("utf-8")).hexdigest(),
                    "scope_types": d.get("scope_types") or [],
                    "canary_percent": d.get("canary_percent", 100),
                    "priority": _idx})
    return out


# ---------------------------------------------------------------- 全来源发布门禁
def _as_tokens(value) -> list:
    """把 str / list / dict 形式的类型、业务范围、术语统一拆成去重列表。"""
    if value is None or value == "":
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple, set)):
        value = [value]
    out = []
    for item in value:
        if isinstance(item, dict):
            item = item.get("code") or item.get("name") or item.get("id") or ""
        for part in (str(item).replace("，", ",").replace("；", ",")
                     .replace("、", ",").replace(";", ",").split(",")):
            part = part.strip()
            if part:
                out.append(part)
    return list(dict.fromkeys(out))


def _source_kind(source: str) -> str:
    """规则的发布来源归类；未知来源按规则库处理（不能绕过门禁）。"""
    s = str(source or "").strip().lower()
    if "mining" in s or "挖掘" in s:
        return "mining"
    if "decision" in s or "决策" in s or "dmn" in s:
        return "decision_table"
    if "dict" in s or "term" in s or "词典" in s or "术语" in s:
        return "dictionary"
    return "rule_library"


def _load_library():
    try:
        from . import auditpoints as _ap
        return _ap.load()
    except Exception:
        logging.getLogger(__name__).debug("audit point library unavailable", exc_info=True)
        return None


def _match_document_type(lib, hint: str) -> dict:
    """案例/对象类型 → 文件审核库的文件类型（103 类）。"""
    hint = str(hint or "").strip()
    if not lib or len(hint) < 2:
        return {}
    for dt in getattr(lib, "document_types", []) or []:
        for name in [dt.get("name") or ""] + list(dt.get("aliases") or []):
            name = str(name or "").strip()
            if len(name) < 2:
                continue
            if name == hint or name in hint or hint in name:
                return dt
    return {}


# ---------------------------------------------------------------------------
# T06（2026-11-23 外部评审 F09 / 长任务 B1-L2）：条件审核类型按文档特征触发
#
# 断点：manifest 路由把文件类型的 default_audit_types + conditional_audit_types
# 一起纳入（条件类型无条件并入）。DT-65 的 conditional 贡献 50% 点位；补 scope 后
# 每文档选入 235/208/247 条 vs gold 7.2–24（10–33×，远超 ≤3× 门）。
#
# 新口径（默认 RULEPROOF_CONDITIONAL_TRIGGER=1）：
#   1) default_audit_types 始终路由；
#   2) conditional_audit_types 只有在文档正文命中该类型的「特征」时才追加；
#      特征来源 = 文件类型与路由.json 的 feature_additions + route_basis
#      （如「权利转让或分包」→ E12、「回扣」→ F11、「个人信息」→ C13…）；
#   3) 未触发的 conditional 类型规则 → 可选规则池（gate.optional_pool），
#      **不进入冻结 manifest**（可被路由器/人工显式选取，不改变被测对象）；
#   4) 每文档路由预算 RULEPROOF_ROUTE_DOC_BUDGET（默认 20）：选入超过预算时，
#      按规则文本与文档正文的确定性词面相关度排序保留前 N 条，其余进可选规则池
#      （reason=budget_cap）——让「每文档负担」有可测上界。=0 关闭预算（回旧行为）。
# 回滚：RULEPROOF_CONDITIONAL_TRIGGER=0（条件类型无条件并入）+ 预算=0。
# ---------------------------------------------------------------------------
_CONDITIONAL_TRIGGER_ENV = "RULEPROOF_CONDITIONAL_TRIGGER"
_ROUTE_DOC_BUDGET_ENV = "RULEPROOF_ROUTE_DOC_BUDGET"
_ROUTE_BUDGET_DEFAULT = 20
_ROUTE_FEATURE_TEXT_LIMIT = 60000


def conditional_trigger_enabled() -> bool:
    """条件审核类型是否按文档特征触发（默认开；=0 回旧的无条件并入）。"""
    raw = str(os.environ.get(_CONDITIONAL_TRIGGER_ENV, "1") or "1").strip().lower()
    return raw not in ("0", "false", "off", "no")


def route_doc_budget() -> int:
    """每文档路由预算（选入规则上限；默认 20，0=关闭预算）。"""
    raw = str(os.environ.get(_ROUTE_DOC_BUDGET_ENV, "") or "").strip()
    if not raw:
        return _ROUTE_BUDGET_DEFAULT
    try:
        val = int(float(raw))
    except (TypeError, ValueError):
        return _ROUTE_BUDGET_DEFAULT
    return max(0, val)


def _feature_trigger_map(lib) -> tuple:
    """构造「文档特征 → 条件审核类型」映射。

    返回 ``(pairs, by_type)``：
      pairs   = [(feature, {type_ids}), ...]（按配置顺序，确定性）；
      by_type = {type_id: [feature, ...]}（供可选规则池解释“缺哪个特征”）。
    来源：文件类型与路由.json 顶层 ``feature_additions`` + ``route_basis.audit_types``
    的 ``feature_additions`` 关键词（C13 个人信息/数据安全、F11 商业贿赂/回扣等）。
    """
    pairs, by_type = [], {}
    for fa in (getattr(lib, "feature_additions", []) or []):
        if not isinstance(fa, dict):
            continue
        feat = str(fa.get("feature") or "").strip()
        tids = {str(x) for x in (fa.get("type_ids") or []) if str(x).strip()}
        if feat and tids:
            pairs.append((feat, tids))
            for tid in tids:
                by_type.setdefault(tid, [])
                if feat not in by_type[tid]:
                    by_type[tid].append(feat)
    _rb = getattr(lib, "route_basis", {}) or {}
    for tid, meta in ((_rb.get("audit_types") or {}) if isinstance(_rb, dict) else {}).items():
        if not isinstance(meta, dict):
            continue
        for kw in (meta.get("feature_additions") or []):
            feat = str(kw or "").strip()
            if not feat:
                continue
            pairs.append((feat, {str(tid)}))
            by_type.setdefault(str(tid), [])
            if feat not in by_type[str(tid)]:
                by_type[str(tid)].append(feat)
    return pairs, by_type


def _triggered_conditional_types(lib, text: str, conditional_types) -> tuple:
    """按文档正文特征触发条件审核类型 → (triggered_types, triggers, feature_map)。"""
    cond = [str(x) for x in (conditional_types or []) if str(x).strip()]
    pairs, by_type = _feature_trigger_map(lib)
    cond_set = set(cond)
    triggers = {}
    body = str(text or "")
    for feat, tids in pairs:
        if feat and feat in body:
            for tid in tids:
                if tid in cond_set:
                    triggers.setdefault(tid, [])
                    if feat not in triggers[tid]:
                        triggers[tid].append(feat)
    return [t for t in cond if t in triggers], triggers, by_type


# ---------------------------------------------------------------------------
# T06-R1（2026-11-23 B5-L17 P0）：条件触发类型登记表 + 无钩子类型 legacy 并入
#
# 断点（B5-L16，docs/qa/条件触发路由回归_20261123.md）：
#   原 T06 实现把所有 conditional_audit_types 都当成「有正文特征钩子」；未命中就抑制。
#   但文件审核库 62 个 conditional 类型里只有 12 个在 feature_additions/route_basis
#   有钩子，其余 50 个无钩子 → 永远不可能命中 → 被结构性永久抑制：
#   CT 44 份真实冻结清单证据：=1 相对 =0 多挡 368/875=42.06% 金标实例，
#   ΔRecall −8.00pp（95%CI[−11.34,−4.81]，BLOCK）、ΔF1 −10.38pp。
#
# 新口径（R1，本段）：
#   1) **登记**：文件审核库中出现的每个 conditional 类型，必须满足其一：
#        a) 有 ≥1 个触发钩子 → 登记进 ``CONDITIONAL_HOOKS``（type → 钩子列表）；
#        b) 无钩子 → 显式登记进 ``LEGACY_CONDITIONAL_TYPES``（legacy：无条件并入）。
#      两者都没有 → ``validate_conditional_registry`` 抛 ``ConditionalRegistryError``，
#      冻结/启动即失败（不允许静默压成「永不触发」）。
#   2) **选择**：legacy 类型无条件并入（不抑制）；只有有钩子类型才按正文特征触发，
#      未命中 → 可选规则池（reason=conditional_type_untriggered，可解释/可显式选取）。
#   3) **回退**：``RULEPROOF_CONDITIONAL_TRIGGER=0`` → 全部 conditional 无条件并入（旧行为）。
#
# 维护约定：文件类型与路由.json 的 feature_additions / route_basis 变更时，
# 必须同步本登记表（新增钩子类型 → 从 legacy 移到 hooks），否则启动报错；
# 登记门禁「条件触发类型登记」会把该一致性固化进 gate。
# ---------------------------------------------------------------------------
class ConditionalRegistryError(RuntimeError):
    """条件触发类型登记表与文件审核库不一致（启动/冻结期 fail-closed）。"""


# 有特征钩子的 conditional 审核类型：类型 → 触发钩子（逐字来自
# 文件审核库/文件类型与路由.json 的 feature_additions + route_basis[*].feature_additions）。
# 只有登记在这里的类型才允许「未命中特征 → 抑制（进可选规则池）」。
CONDITIONAL_HOOKS = {
    # R1（B5-L19，2026-11-23）：招标/磋商文件签署用印与审批 —— 补 conditional + 触发词后
    # 按 L17 维护约定从 legacy 移入 hooks（登记表与 文件类型与路由.json 逐字一致）。
    "A04": ("签署", "用印", "盖章", "法定代表人签字", "授权委托书"),
    # R2（B5-L19，2026-11-23）：关键参数 —— DT-14 与 DT-11 对称补 conditional + 触发词。
    "C06": ("关键参数", "评标办法", "费率", "权重", "基准价"),
    "A03": ("代理行为",),
    "C05": ("第三方证据独立性",),
    "C12": ("第三方证据独立性",),
    "C13": ("个人信息", "数据安全"),
    "C14": ("多币种折算",),
    "E12": ("权利转让或分包",),
    "E13": ("保险需求",),
    "F07": ("交付验收业务",),
    "F09": ("现金流期间支撑",),
    "F11": ("反商业贿赂", "商业贿赂", "回扣"),
    "F12": ("用工社保工资责任",),
    "F13": ("环保义务",),
    # G08 在配置里有「对外申报」钩子，但当前 103 类文件类型没有把它列为 conditional；
    # 保留登记以便登记门禁与配置逐项对账（不影响运行时选择）。
    "G08": ("对外申报",),
}

# 无特征钩子的 conditional 审核类型：显式 legacy，**无条件并入**（不按特征抑制）。
# 为什么必须显式登记而不是「缺省当 legacy」：缺省静默会把「配置新增 conditional 类型
# 但忘了给钩子」变成永久漏检（B5-L16 CT 回归正是这个结构性缺陷）。缺登记 → 报错。
LEGACY_CONDITIONAL_TYPES = frozenset({
    # A04/C06 于 B5-L19 起有正文触发钩子（见上 CONDITIONAL_HOOKS），按 L17 维护约定
    # 注册为 hooks 而非 legacy；legacy 机制（无钩子类型无条件并入）本身不变。
    "A01", "A02", "A05", "A06",
    "B02", "B03", "B05",
    "C01", "C02", "C03", "C04", "C07", "C08", "C09", "C10",
    "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10",
    "E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08", "E09", "E10", "E11",
    "F03", "F04", "F05", "F06", "F08", "F10",
    "G01", "G02", "G03", "G04", "G05", "G06", "G07",
})


def _library_conditional_hooks(lib) -> tuple:
    """文件审核库实际 conditional 类型（按配置顺序去重）+ 配置钩子映射。

    返回 ``(conditional_types, config_hooks)``：config_hooks={type: [feature, ...]}，
    与运行时 ``_feature_trigger_map`` 同源（feature_additions + route_basis）。
    """
    cond = []
    for dt in getattr(lib, "document_types", []) or []:
        if not isinstance(dt, dict):
            continue
        for tid in _as_tokens(dt.get("conditional_audit_types") or []):
            if tid not in cond:
                cond.append(tid)
    _pairs, by_type = _feature_trigger_map(lib)
    config_hooks = {str(k): [str(x) for x in (v or [])]
                    for k, v in (by_type or {}).items()}
    return cond, config_hooks


def validate_conditional_registry(lib, strict: bool = True) -> dict:
    """校验「每个 conditional 类型必须有 ≥1 钩子 或 显式 legacy 标记」。

    判据（全部满足才算 ok）：
      1) 文件审核库 conditional 类型 ⊆ CONDITIONAL_HOOKS ∪ LEGACY_CONDITIONAL_TYPES；
      2) 同一类型不得同时是 hooks 与 legacy（二义登记）；
      3) CONDITIONAL_HOOKS 的钩子列表非空、元素非空字符串；
      4) 登记钩子与文件类型与路由.json 实际钩子逐项一致（防配置漂移/死钩子）；
      5) legacy 类型在配置里确实没有钩子（有钩子却登记 legacy = 漏抑制/配置错）。
    ``strict=True``（冻结/启动默认）且不满足 → 抛 ``ConditionalRegistryError``；
    ``strict=False``（诊断/门禁报告）只返回问题清单，不抛异常。
    """
    cond, config_hooks = _library_conditional_hooks(lib)
    missing, ambiguous, empty_hooks, hook_drift, legacy_with_hooks = [], [], [], [], []
    for tid in cond:
        _in_hooks = tid in CONDITIONAL_HOOKS
        _in_legacy = tid in LEGACY_CONDITIONAL_TYPES
        if _in_hooks and _in_legacy:
            ambiguous.append(tid)
        elif not _in_hooks and not _in_legacy:
            missing.append(tid)
    for tid, hooks in CONDITIONAL_HOOKS.items():
        _hooks = tuple(hooks or ())
        if not _hooks or any(not str(x).strip() for x in _hooks):
            empty_hooks.append(tid)
        _cfg = config_hooks.get(tid) or []
        if {str(x) for x in _hooks} != {str(x) for x in _cfg}:
            hook_drift.append({"type": tid, "registry": [str(x) for x in _hooks],
                               "config": list(_cfg)})
    for tid in LEGACY_CONDITIONAL_TYPES:
        if config_hooks.get(tid):
            legacy_with_hooks.append({"type": tid, "config": config_hooks[tid]})
    _audit_types = getattr(lib, "audit_types", {}) or {}
    unknown_hook_types = ([t for t in CONDITIONAL_HOOKS if t not in _audit_types]
                          if _audit_types else [])
    problems = []
    for _label, _items in (("missing", missing), ("ambiguous", ambiguous),
                           ("empty_hooks", empty_hooks), ("hook_drift", hook_drift),
                           ("legacy_with_hooks", legacy_with_hooks),
                           ("unknown_hook_types", unknown_hook_types)):
        if _items:
            problems.append("%s=%s" % (_label, _items))
    result = {
        "ok": not problems,
        "conditional_total": len(cond),
        "hook_types": len([t for t in cond if t in CONDITIONAL_HOOKS]),
        "legacy_types": len([t for t in cond if t in LEGACY_CONDITIONAL_TYPES]),
        "missing": missing, "ambiguous": ambiguous, "empty_hooks": empty_hooks,
        "hook_drift": hook_drift, "legacy_with_hooks": legacy_with_hooks,
        "unknown_hook_types": unknown_hook_types,
        "registry_version": "T06-R1-20261123",
        "source": "manifest.CONDITIONAL_HOOKS + manifest.LEGACY_CONDITIONAL_TYPES",
    }
    if problems and strict:
        raise ConditionalRegistryError(
            "条件触发类型登记表与文件审核库不一致（%d 项）：%s"
            % (len(problems), "；".join(str(p)[:500] for p in problems)))
    return result


def _select_conditional_types(lib, text: str, conditional_types) -> dict:
    """R1 条件类型选择：legacy 无条件并入；有钩子类型按正文特征触发。

    返回 ``{selected, triggered, legacy_merged, unregistered_fallback, optional,
    triggers, feature_map}``：
      selected = 本次进入（或维持）路由的 conditional 类型（保序）；
      legacy_merged = 无钩子 legacy 类型（无条件并入，**不抑制**）；
      optional = 有钩子但正文未命中的类型（进可选规则池，可解释）；
      unregistered_fallback = 既无钩子也未登记的类型（防御性：按 legacy 并入，
        不静默丢弃；正常情况下 ``validate_conditional_registry`` 已在冻结期报错）。
    """
    cond = [str(x) for x in (conditional_types or []) if str(x).strip()]
    triggered, triggers, feat_map = _triggered_conditional_types(lib, text, cond)
    legacy_merged = [t for t in cond if t in LEGACY_CONDITIONAL_TYPES]
    unregistered = [t for t in cond
                    if t not in CONDITIONAL_HOOKS and t not in LEGACY_CONDITIONAL_TYPES]
    _merge = set(legacy_merged) | set(unregistered) | set(triggered)
    return {
        "selected": [t for t in cond if t in _merge],
        "triggered": list(triggered),
        "legacy_merged": legacy_merged,
        "unregistered_fallback": unregistered,
        "optional": [t for t in cond if t not in _merge],
        "triggers": triggers,
        "feature_map": feat_map,
    }


def _route_feature_texts(docs) -> tuple:
    """读取/解析被审文档正文（仅供路由特征触发；不进入证据/判定链路）。

    返回 ``(texts, available)``：texts={document_id: text}；available=至少 1 份可解析。
    解析失败/占位文件不臆造特征（宁可回退旧口径并在 gate 留痕，也不默认触发）。
    """
    if os.environ.get("RULEPROOF_FREEZE_PARSE", "1") == "0":
        # 显式关闭解析产物闭包时也不额外解析（条件触发回退 legacy 合并，gate 留痕）
        return {}, False
    # L145：统一走 parse_bridge.parse_document（内容寻址缓存），不再直连解析器
    from . import parse_bridge as _parse_bridge
    texts, any_ok = {}, False
    for d in docs or []:
        did = str((d or {}).get("id") or "")
        path = str((d or {}).get("path") or "")
        text = ""
        if path and os.path.isfile(path):
            try:
                parsed = _parse_bridge.parse_document(path)
                text = str(getattr(parsed, "text", "") or "")
            except Exception:
                logging.getLogger(__name__).debug(
                    "route feature parse failed doc=%s", did, exc_info=True)
                text = ""
        texts[did] = text[:_ROUTE_FEATURE_TEXT_LIMIT]
        any_ok = any_ok or bool(text.strip())
    return texts, any_ok


def _route_text_score(text: str, rule_text: str) -> float:
    """确定性词面相关度（字符 4-gram 重合 / sqrt(规则长度)），不调用模型。"""
    def _grams(s: str) -> set:
        s = "".join(ch for ch in str(s or "") if not ch.isspace())
        if len(s) < 4:
            return {s} if s else set()
        return {s[i:i + 4] for i in range(len(s) - 3)}
    body = _grams(str(text or "")[:60000])
    rule = _grams(str(rule_text or "")[:4000])
    if not body or not rule:
        return 0.0
    return round(len(body & rule) / (len(rule) ** 0.5), 6)


def _gate_optional(gate: dict, rule: dict, kind: str, *, reason: str,
                   object_id: str = "", detail: dict = None) -> None:
    """记录一条「可选规则池」条目（不进入冻结清单，可追溯原因）。"""
    pool = gate.setdefault("optional_pool", {"counts": {}, "entries": []})
    counts = pool.setdefault("counts", {})
    counts[reason] = int(counts.get(reason, 0)) + 1
    entries = pool.setdefault("entries", [])
    if len(entries) < 500:  # 池条目上限，避免 manifest 膨胀；counts 始终为真值
        entries.append({
            "rule_id": rule.get("id"), "code": rule.get("code"),
            "name": rule.get("name"), "source": kind,
            "object_id": str(object_id or ""), "reason": reason,
            **(detail or {}),
        })
    else:
        pool["truncated"] = True


def _gate_routed_optional(gate: dict, rule: dict, kind: str, reason: str,
                          object_id: str = "", detail: dict = None) -> None:
    """可选池条目 + routed_out 双留痕（routed_out 保执行期可解释，可选池给路由器）。"""
    _gate_optional(gate, rule, kind, reason=reason, object_id=object_id,
                   detail=detail)
    _gate_routed_out(gate, rule, kind, reason,
                     object_count=1 if object_id else 0)


def _scope_inferred_pending(scope_obj: dict) -> dict:
    """迁移脚本写入的「自动推断、待人工确认」scope 标记 → 详情（否则返回 {}）。

    T07 scope_backfill dry-run 只产出计划不写库；apply 时写入
    ``scope.scope_inferred = {source, status:"pending_confirmation", confidence, ...}``。
    这类规则的 scope 虽可路由，但未经人工确认 → 只进可选规则池，不自动进入生产 manifest。
    """
    if not isinstance(scope_obj, dict):
        return {}
    si = scope_obj.get("scope_inferred")
    if not isinstance(si, dict):
        return {}
    status = str(si.get("status") or si.get("review_status") or "").strip().lower()
    confirmed = si.get("confirmed")
    pending = status in ("pending_confirmation", "pending", "inferred", "to_review") \
        or confirmed is False
    if not pending:
        return {}
    return {"status": status or "pending_confirmation",
            "source": str(si.get("source") or ""),
            "confidence": si.get("confidence")}


def _apply_route_budget(*, items, rules, rule_bindings, frozen_rule_versions,
                        inventory, gate, route_texts, budget) -> tuple:
    """T06 每文档路由预算：单文档选入超过 budget 时按确定性词面相关度保留前 N 条，
    其余进可选规则池（reason=budget_cap）。返回过滤后的
    ``(items, rules, rule_bindings, frozen_rule_versions)``；budget<=0 原样返回。

    设计口径（F09）：
      - 可选规则池里的规则**不进入冻结 manifest**（不改变被测对象/负担）；
      - 排序确定性（字符 4-gram 重合，同分按规则码），0 LLM、可复现；
      - 文档无可解析正文时按冻结顺序稳定排序（gate 已记 feature_texts_available=false）。
    """
    if budget <= 0 or not items:
        return items, rules, rule_bindings, frozen_rule_versions
    by_obj = {}
    for it in items:
        by_obj.setdefault(str(it.get("object_id") or ""), []).append(it)
    keep, dropped = set(), []
    for oid, its in by_obj.items():
        if len(its) <= budget:
            keep.update(id(x) for x in its)
            continue
        text = (route_texts or {}).get(oid, "")

        def _rank(it):
            rule_text = " ".join([str(it.get("name") or ""),
                                  str(it.get("requirement") or ""),
                                  str(it.get("code") or "")])
            return (-_route_text_score(text, rule_text), str(it.get("code") or ""))

        ranked = sorted(its, key=_rank)
        keep.update(id(x) for x in ranked[:budget])
        dropped.extend(ranked[budget:])
    if not dropped:
        return items, rules, rule_bindings, frozen_rule_versions
    kept_items = [it for it in items if id(it) in keep]
    keep_rule_ids = {str(it.get("rule_id") or "") for it in kept_items}
    dropped_rule_ids = {str(it.get("rule_id") or "") for it in dropped}
    fully_dropped = dropped_rule_ids - keep_rule_ids
    for it in dropped:
        _gate_optional(gate, {"id": it.get("rule_id"), "code": it.get("code"),
                              "name": it.get("name")},
                       str(it.get("source_kind") or "rule_library"),
                       reason="budget_cap", object_id=str(it.get("object_id") or ""),
                       detail={"doc_budget": budget,
                               "note": "超出每文档路由预算：进入可选规则池，"
                                       "由路由器/人工显式选取，不进入冻结清单"})
    kept_rules = [r for r in rules if str(r.get("rule_id") or "") in keep_rule_ids]
    # 库存记账纠正：整条规则被预算裁掉的，in_manifest 回退 1（ledger 与清单一致）
    if fully_dropped:
        _kind_by_rule = {str(r.get("rule_id") or ""):
                         str(r.get("source_kind") or "rule_library") for r in rules}
        for rid in fully_dropped:
            _k = _kind_by_rule.get(rid) or "rule_library"
            if _k in inventory and inventory[_k].get("in_manifest"):
                inventory[_k]["in_manifest"] = max(0, inventory[_k]["in_manifest"] - 1)
    kept_obj_by_rule = {}
    for it in kept_items:
        kept_obj_by_rule.setdefault(str(it.get("rule_id") or ""), set()).add(
            str(it.get("object_id") or ""))
    new_bindings = []
    for b in rule_bindings:
        rid = str(b.get("rule_id") or "")
        if rid not in keep_rule_ids:
            continue
        _allowed = {str(x) for x in (b.get("allowed_object_ids") or [])}
        _sel = [x for x in (b.get("selected_object_ids") or [])
                if str(x) in kept_obj_by_rule.get(rid, set())]
        nb = dict(b)
        nb["selected_object_ids"] = _sel
        nb["selected_subset_of_allowed"] = all(str(x) in _allowed for x in _sel)
        new_bindings.append(nb)
    new_frozen = [v for v in frozen_rule_versions
                  if str(v.get("rule_id") or "") in keep_rule_ids]
    try:
        gate["routing"]["budget"] = {
            "doc_budget": budget, "dropped_items": len(dropped),
            "dropped_rules": len(fully_dropped),
            "ranking": "char4gram_relevance+code" if any(
                str((route_texts or {}).get(k) or "").strip() for k in by_obj) else "stable_order",
            "note": "每文档选入上限；超预算规则进可选规则池（budget_cap）",
        }
    except Exception as _e:  # 静默兜底改为留痕（反补丁治理）
        logging.getLogger(__name__).debug("silent fallback: %s", _e)
    return kept_items, kept_rules, new_bindings, new_frozen


def _object_route(obj: dict, case: dict, lib, feature_text: str = "",
                  trigger_conditional: bool = True) -> dict:
    """对象 → 文件类型 → 69 审核类型 → 302 点位；同时给出文件扩展名路由。"""
    raw = str(obj.get("doc_type") or "").strip()
    filename = str(obj.get("filename") or "").strip()
    exts = set()
    for cand in (raw, filename.rsplit(".", 1)[-1] if "." in filename else ""):
        c = str(cand or "").strip().lower().lstrip(".")
        if c:
            exts.add(c)
    case_hint = str(case.get("document_type") or case.get("audit_type") or "").strip()
    dt = (_match_document_type(lib, case_hint) or
          _match_document_type(lib, raw) or
          _match_document_type(lib, filename))
    types, cats, points = [], [], []
    default_types, conditional_types = [], []
    triggered_types, optional_types, triggers, feat_map = [], [], {}, {}
    legacy_merged_types, unregistered_types = [], []
    trigger_policy = "legacy_merged"
    if dt:
        default_types = _as_tokens(dt.get("default_audit_types") or [])
        conditional_types = _as_tokens(dt.get("conditional_audit_types") or [])
        if trigger_conditional:
            # T06-R1（B5-L17）：legacy（无钩子）类型无条件并入；只有有钩子类型按特征触发。
            _cond_sel = _select_conditional_types(lib, feature_text, conditional_types)
            triggered_types = list(_cond_sel["triggered"])
            legacy_merged_types = list(_cond_sel["legacy_merged"])
            unregistered_types = list(_cond_sel["unregistered_fallback"])
            optional_types = list(_cond_sel["optional"])
            triggers = _cond_sel["triggers"] or {}
            feat_map = _cond_sel["feature_map"] or {}
            types = list(dict.fromkeys(default_types + _cond_sel["selected"]))
            trigger_policy = "conditional_trigger"
        else:
            types = list(dict.fromkeys(default_types + conditional_types))
            triggered_types = list(conditional_types)
            trigger_policy = "legacy_merged"
            legacy_merged_types = list(conditional_types)
        audit_types = getattr(lib, "audit_types", {}) or {}
        for tid in types:
            t = audit_types.get(tid) or {}
            cid = str(t.get("category_id") or "").strip()
            if cid and cid not in cats:
                cats.append(cid)
            for pid in (t.get("point_ids") or []):
                if pid not in points:
                    points.append(pid)
    optional_points = []
    _atlib = getattr(lib, "audit_types", {}) or {}
    for tid in optional_types:
        for pid in ((_atlib.get(tid) or {}).get("point_ids") or []):
            if pid not in optional_points:
                optional_points.append(pid)
    optional_features = {t: list((feat_map or {}).get(t) or []) for t in optional_types}
    aliases = " ".join(str(x) for x in (dt.get("aliases") or [])) if dt else ""
    return {
        "doc_type": raw,
        "extensions": sorted(exts),
        "case_hint": case_hint,
        "library_type": str(dt.get("id") or "") if dt else "",
        "library_type_name": str(dt.get("name") or "") if dt else "",
        "audit_types": types,
        "audit_categories": cats,
        "point_ids": points,
        # T06：条件类型触发审计（manifest 冻结/报告可解释“为什么少选/多选了”）
        "default_audit_types": default_types,
        "conditional_audit_types": conditional_types,
        "triggered_audit_types": list(triggered_types),
        # T06-R1：legacy（无钩子）类型无条件并入清单；未登记类型防御性并入（正常应启动报错）
        "legacy_merged_audit_types": list(legacy_merged_types),
        "unregistered_conditional_types": list(unregistered_types),
        "conditional_triggers": {k: list(v) for k, v in (triggers or {}).items()},
        "optional_audit_types": list(optional_types),
        "suppressed_conditional_types": list(optional_types),
        "optional_audit_features": optional_features,
        "optional_point_ids": optional_points,
        "conditional_trigger_policy": trigger_policy,
        "feature_text_chars": len(str(feature_text or "")),
        "resolved": bool(dt),
        "haystack": " ".join([case_hint, raw, filename,
                              str(dt.get("name") or "") if dt else "", aliases]).lower(),
    }


def _rule_point(rule: dict, scope_obj: dict, lib) -> dict:
    """DB 规则 → 302 审核点 → 69 审核类型 → A–G 大类。"""
    pm = scope_obj.get("point_mapping") or {}
    if not isinstance(pm, dict):
        pm = {}
    point_id = str(pm.get("point_id") or "").strip() if (pm.get("mapped") or pm.get("override")) else ""
    point_name = str(pm.get("point_name") or "")
    confidence = pm.get("score")
    if not point_id:
        # 兼容早期只落了 rule_point_mapping 表的规则
        try:
            c = db.connect()
            try:
                row = c.execute(
                    "SELECT point_id, point_name FROM rule_point_mapping "
                    "WHERE rule_id=? AND point_id<>'' ORDER BY rowid DESC LIMIT 1",
                    (rule.get("id") or "",)).fetchone()
            finally:
                c.close()
            if row:
                point_id = str(row["point_id"] or "").strip()
                point_name = point_name or str(row["point_name"] or "")
        except Exception:
            logging.getLogger(__name__).debug("rule point mapping lookup skipped", exc_info=True)
    point = None
    if lib and point_id:
        point = next((p for p in (getattr(lib, "points", []) or [])
                      if str(getattr(p, "id", "")) == point_id), None)
    # B2（2026-11-20 外部对抗审查）：point_mapping 里的伪造点位不得进入路由/归因。
    # 点位库可用时按库校验：未知 point_id → 不路由（fail-closed，保留证据字段供排查）。
    _point_invalid = False
    if point_id and lib and (getattr(lib, "points", []) or []) and point is None:
        _point_invalid = True
        point_id = ""
        point_name = ""
    return {
        "point_id": point_id,
        "point_name": point_name or (str(getattr(point, "name", "") or "") if point else ""),
        "audit_type": str(getattr(point, "type_id", "") or "") if point else "",
        "audit_type_name": str(getattr(point, "type_name", "") or "") if point else "",
        "audit_category": str(getattr(point, "category_id", "") or "") if point else "",
        "audit_category_name": str(getattr(point, "category", "") or "") if point else "",
        "confidence": confidence,
        "mapped": bool(point_id),
        "point_mapping_invalid": _point_invalid,
        # T-161：点位的执行方式（calculate/text/compare → 确定性区；semantic/expert → 证据区），
        # 冻结时由 audit_zone 映射为 zone；执行期不读该字段。
        "point_method": str(getattr(point, "method", "") or "") if point else "",
    }


def _scope_meta(scope_obj: dict, slots: dict, rule: dict = None) -> dict:
    """与 rule.derive_rule_scope 同口径（唯一派生函数）；规则服务不可用时保守兜底。

    B1（2026-11-20 外部对抗审查）：不再读 scope_meta/scope_required 等落库标记，
    改为从 scope_json + 生效版本 slots + tags + 规则来源派生（见 rule.derive_rule_scope）。
    """
    try:
        from . import rule as _rule
        return _rule.derive_rule_scope(scope_obj, slots, rule=rule)
    except Exception:
        logging.getLogger(__name__).warning(
            "derive_rule_scope unavailable; fallback to conservative scope meta", exc_info=True)
        types = _as_tokens(slots.get("applicable_types")) + _as_tokens(scope_obj.get("applicable_types"))
        when = (_as_tokens(slots.get("applicable_when")) +
                _as_tokens(scope_obj.get("applicable_when")) +
                _as_tokens(scope_obj.get("scope")))
        route_types = [x for x in types + when if x.lower().lstrip(".") in _KNOWN_EXT]
        business = [x for x in types + when if x.lower().lstrip(".") not in _KNOWN_EXT]
        route_types = list(dict.fromkeys(route_types))
        business = list(dict.fromkeys(business))
        tags = _scope_tag_tokens(scope_obj, slots)
        platform_scope = bool((scope_obj or {}).get("platform_scope") is True
                              or str((rule or {}).get("source") or "").strip() == "内置规则")
        declared = bool(types or when)
        status = ("missing" if not declared else
                  "mixed" if (route_types and business) else
                  "explicit_types" if route_types else "business")
        return {"declared": declared or bool(tags) or platform_scope,
                "status": ("platform" if platform_scope and not declared else
                           "tags" if tags and not declared else status),
                "missing": not (declared or bool(tags) or platform_scope),
                "route_types": route_types, "raw_types": types,
                "business_scope": business, "routable": bool(route_types),
                "manifest_types": route_types, "execution_scope": [],
                "tags": tags, "tags_only": bool(tags) and not declared,
                "platform_scope": platform_scope, "legacy_hint": ""}


def _applicability_tokens(scope_obj: dict, slots: dict) -> list:
    """冻结的适用条件（applicable_when / 旧 scope.scope）；D1 执行期只读该快照。"""
    vals = (_as_tokens(slots.get("applicable_when")) +
            _as_tokens(scope_obj.get("applicable_when")) +
            _as_tokens(scope_obj.get("scope")))
    return [v for v in dict.fromkeys(vals) if v]


def _scope_tag_tokens(scope_obj: dict, slots: dict) -> list:
    """冻结 scope.tags：作为规则检索/路由标签 + D1 执行期触发标签。"""
    vals = _as_tokens(scope_obj.get("tags")) + _as_tokens(slots.get("tags"))
    return [v for v in dict.fromkeys(vals) if v]


def _audit_category_gate(case: dict, rule: dict) -> tuple:
    """A–G 大类路由：与 review/engine 使用同一 allow_rule 口径。"""
    cat = str(case.get("audit_category") or "").strip().upper()
    if cat not in ("A", "B", "C", "D", "E", "F", "G"):
        return True, ""
    if str(rule.get("category") or "") == "客户沉淀":
        return True, ""
    try:
        from ..engine import audit_category as _ac
        allowed = bool(_ac.allow_rule(cat, rule.get("category") or ""))
    except Exception:
        allowed = True
    return allowed, ("" if allowed else f"audit_category_mismatch:{cat}")




_BINDING_SECTION_LIMIT = 500
_ONTO_SNAPSHOT_PREFIX = "manifest_ontology:"


def _term_snapshot() -> tuple:
    """已生效业务词典术语快照（冻结口径与 D4 别名归一一致）。

    未确认术语只计数、不进入冻结别名；词典快照与别名快照共享同一状态口径。
    """
    out = []
    stats = {"available": 0, "drafts": 0, "frozen": 0, "truncated": 0}
    try:
        from . import terms as _terms
        rows = _terms.list_terms() or []
    except Exception:
        logging.getLogger(__name__).debug("ontology term snapshot skipped", exc_info=True)
        return out, stats
    for t in rows:
        status = str(t.get("status") or "").lower()
        if status not in _EFFECTIVE_TERM_STATUS:
            stats["drafts"] += 1
            continue
        stats["available"] += 1
        if len(out) >= _BINDING_SECTION_LIMIT:
            stats["truncated"] += 1
            continue
        out.append({"name": str(t.get("name") or ""),
                    "term_key": str(t.get("term_key") or ""),
                    "status": status,
                    "synonyms": [str(x) for x in (t.get("synonyms") or []) if str(x).strip()],
                    "unit": str(t.get("unit") or ""),
                    "entity_type": str(t.get("entity_type") or "")})
    out.sort(key=lambda x: (x["name"], x["term_key"]))
    stats["frozen"] = len(out)
    return out, stats


def _graph_snapshot() -> tuple:
    """本体图实体/关系快照（只读冻结，供 D4 归因与本体检证）。"""
    entities, relations = [], []
    stats = {"entities": 0, "aliases": 0, "links": 0, "truncated": 0}
    with db.session() as c:
        for key, table, cols in (
                ("entities", "onto_entity", "id,type_key,name"),
                ("aliases", "onto_alias", "id,type_key,alias,entity_id"),
                ("links", "onto_link", "id,key,source_id,target_id")):
            try:
                total = int(c.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
            except Exception:
                stats[key] = 0
                continue
            stats[key] = total
            try:
                rows = c.execute(f"SELECT {cols} FROM {table} ORDER BY id LIMIT ?",
                                 (_BINDING_SECTION_LIMIT,)).fetchall()
            except Exception:
                rows = []
            record = {"entities": lambda r: {"id": r["id"], "type_key": r["type_key"],
                                             "name": r["name"]},
                      "aliases": lambda r: {"id": r["id"], "type_key": r["type_key"],
                                            "alias": r["alias"], "entity_id": r["entity_id"]},
                      "links": lambda r: {"id": r["id"], "key": r["key"],
                                          "source_id": r["source_id"],
                                          "target_id": r["target_id"]}}[key]
            values = [record(r) for r in rows]
            if total > len(values):
                stats["truncated"] += 1
            if key == "entities":
                entities = values
            elif key == "links":
                relations = values
            else:
                stats["alias_rows"] = len(values)
    return entities, relations, stats


def _binding_sha(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True)
                          .encode("utf-8")).hexdigest()[:16]


def _ontology_binding(workspace: str) -> dict:
    """冻结真正参与 D4 取数的本体/术语快照，而不是只哈希 gate override。

    来源：已确认业务词典、空间本体术语、ontology_gate overrides、本体图实体/别名/关系。
    - aliases 采用 canonical -> [alias...]：D4 取数只读该快照，冻结后追加/停用别名
      不影响本次审核；下一次 manifest 才生效；
    - terms：已生效词典术语快照（未确认术语不进入）；
    - entities/relations：onto_entity/onto_link 只读快照；
    - hashes：分段哈希 + 总 sha，便于核对“冻结前后是否被实时改动污染”。
    """
    aliases = {}
    sources = {"terms": 0, "workspace": 0, "gate": 0, "entities": 0,
               "aliases": 0, "links": 0}
    try:
        from . import terms as _terms
        for alias, canon in (_terms.confirmed_alias_pairs() or {}).items():
            alias, canon = str(alias or "").strip(), str(canon or "").strip()
            if alias and canon:
                aliases.setdefault(canon, set()).add(alias)
        sources["terms"] = len(aliases)
    except Exception:
        logging.getLogger(__name__).debug("ontology terms binding skipped", exc_info=True)
    try:
        from . import ontology_service as _ontology
        for alias, canon in (_ontology.workspace_alias_pairs(workspace) or {}).items():
            alias, canon = str(alias or "").strip(), str(canon or "").strip()
            if alias and canon:
                aliases.setdefault(canon, set()).add(alias)
        sources["workspace"] = sum(len(v) for v in aliases.values())
    except Exception:
        logging.getLogger(__name__).debug("workspace ontology binding skipped", exc_info=True)
    try:
        from . import ontology_service as _ontology
        for canon, names in (_ontology.gate_overrides() or {}).items():
            canon = str(canon or "").strip()
            for alias in names or []:
                if canon and str(alias or "").strip():
                    aliases.setdefault(canon, set()).add(str(alias).strip())
        sources["gate"] = sum(len(v) for v in aliases.values())
    except Exception:
        logging.getLogger(__name__).debug("ontology gate binding skipped", exc_info=True)
    try:
        # 本体 v2 的实体别名也是 D4 取数会用的实时来源，必须一并冻结，
        # 否则冻结后新增的本体别名仍会改变本次审核结果。
        from . import ontology_service as _ontology
        for alias, owners in (_ontology.alias_index() or {}).items():
            alias = str(alias or "").strip()
            for canon in owners or []:
                canon = str(canon or "").strip()
                if alias and canon:
                    aliases.setdefault(canon, set()).add(alias)
        sources["ontology_v2"] = sum(1 for v in (_ontology.alias_index() or {}).values() if v)
    except Exception:
        logging.getLogger(__name__).debug("ontology v2 alias binding skipped", exc_info=True)
    terms, term_stats = _term_snapshot()
    try:
        entities, relations, graph_stats = _graph_snapshot()
    except Exception:
        logging.getLogger(__name__).debug("ontology graph snapshot skipped", exc_info=True)
        entities, relations = [], []
        graph_stats = {"entities": 0, "aliases": 0, "links": 0, "truncated": 0}
    for key in ("entities", "aliases", "links"):
        sources[key] = int(graph_stats.get(key) or 0)
    try:
        from . import ontology_service as _ontology
        sources["contract_hash"] = str(_ontology.contract_hash() or "")[:16]
    except Exception:
        sources["contract_hash"] = ""
    sources["alias_pairs"] = sum(len(v) for v in aliases.values())
    normalized = {k: sorted(v) for k, v in aliases.items() if v}
    hashes = {
        "aliases": _binding_sha(normalized),
        "terms": _binding_sha(terms),
        "entities": _binding_sha(entities),
        "relations": _binding_sha(relations),
    }
    hashes["all"] = _binding_sha({"sources": sources, "hashes": hashes,
                                  "aliases": normalized, "terms": terms,
                                  "entities": entities, "relations": relations})
    return {"sha": hashes["all"], "hashes": hashes, "sources": sources,
            "aliases": normalized, "terms": terms,
            "entities": entities, "relations": relations,
            "limits": {"per_section": _BINDING_SECTION_LIMIT,
                       "truncated": int(term_stats.get("truncated") or 0) +
                                    int(graph_stats.get("truncated") or 0)},
            "term_stats": term_stats,
            "note": "D4 取数使用的冻结本体/术语快照；冻结后实时别名变更不影响本次审核"}


def _rule_metric_keys(slots: dict, scope_obj: dict, tables: dict) -> set:
    """规则执行时可能按名取数的指标集合：用于裁剪 item 里的冻结别名（避免清单膨胀）。"""
    out = set()

    def _add(value) -> None:
        for token in _as_tokens(value):
            token = str(token or "").strip()
            if token:
                out.add(token)

    for key in ("metric", "object", "subject", "parameter"):
        _add(slots.get(key))
        _add(scope_obj.get(key))
    for sub in (slots.get("subrequirements") or slots.get("criteria_list") or []):
        if isinstance(sub, dict):
            for key in ("metric", "object", "subject"):
                _add(sub.get(key))
    for code in _as_tokens(slots.get("decision_tables") or slots.get("decision_table") or []):
        row = (tables or {}).get(str(code)) or {}
        for rule in row.get("rules") or []:
            for cond in rule.get("when") or []:
                if isinstance(cond, dict):
                    _add(cond.get("metric"))
    return out


def _filter_binding_aliases(aliases: dict, metrics: set) -> dict:
    """只保留与本规则指标相关的冻结别名（canonical 命中或该指标是某个别名）。"""
    if not metrics:
        return {}
    out = {}
    for canon, names in (aliases or {}).items():
        names = list(names or [])
        if canon in metrics or any(str(n) in metrics for n in names):
            out[canon] = names
    return out


def _item_ontology_binding(binding: dict, slots: dict = None,
                           scope_obj: dict = None, tables: dict = None) -> dict:
    """item 内只放 D4 需要的轻量绑定（相关别名 + 哈希），避免清单膨胀。"""
    if not binding:
        return {}
    aliases = binding.get("aliases") or {}
    if slots is not None:
        aliases = _filter_binding_aliases(
            aliases, _rule_metric_keys(slots, scope_obj or {}, tables or {}))
    return {"sha": binding.get("sha") or "",
            "hashes": binding.get("hashes") or {},
            "sources": binding.get("sources") or {},
            "aliases": aliases,
            "note": binding.get("note") or ""}


def load_ontology_snapshot(manifest_id: str) -> dict:
    """读取某次冻结落库的完整本体/术语快照（含实体/关系）。"""
    from . import sysconfig
    raw = sysconfig.get(_ONTO_SNAPSHOT_PREFIX + str(manifest_id or ""), "")
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _save_ontology_snapshot(manifest_id: str, binding: dict) -> None:
    from . import sysconfig
    sysconfig.set_many({_ONTO_SNAPSHOT_PREFIX + str(manifest_id or ""):
                        json.dumps(binding or {}, ensure_ascii=False)})


# ================================================================ V01 冻结闭包
# 「版本号」只说明用了哪个配置，不说明这次计算读了什么内容。冻结闭包把一次审核真正
# 依赖的**内容**固化为可校验标识，执行前由 ``execution_guard`` 校验；冻结后发布新版本/
# 改参数/改别名/次日回放都不改变本次 run 的输入。
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _digest(obj, n: int = 16) -> str:
    """稳定内容指纹（JSON 规范化后 sha256 截断）。"""
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True,
                                     default=str).encode("utf-8")).hexdigest()[:n]


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data or b"").hexdigest()


def _sha256_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


def _file_content_digest(path: str) -> tuple:
    """原始文件字节 sha256（分块读，不整文件常驻内存）。返回 (sha256, size, error)。"""
    p = str(path or "")
    if not p:
        return "", 0, "path_empty"
    if not os.path.isfile(p):
        return "", 0, "file_missing"
    h = hashlib.sha256()
    size = 0
    try:
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
                size += len(chunk)
        return h.hexdigest(), size, ""
    except Exception as exc:  # 读不到就显式 unreadable，不拿 document_id 冒充内容
        return "", 0, f"{type(exc).__name__}: {exc}"


def _rule_version_content_sha(version_row: dict) -> str:
    """规则版本内容哈希：slots/evidence/tests 全量（同版本号改内容也能检出）。"""
    v = version_row or {}
    content = "\n".join(str(v.get(k) or "") for k in
                        ("slots_json", "evidence_json", "tests_json"))
    return _sha256_text(content)


def _hash_prefix_match(stored: str, full: str) -> bool:
    """历史 document.hash 有 16/32/40 位截断值：按完整 sha256 前缀兼容比较。"""
    s = str(stored or "").strip().lower()
    f = str(full or "").strip().lower()
    if not s or not f:
        return True
    return s == f or (len(s) in (16, 32, 40) and f.startswith(s))


def _file_closure(docs, content_cache: dict = None) -> dict:
    """原始文件内容闭包：sha256(原始字节) 才是内容标识，document_id 可复用/被覆盖。

    content_cache={document_id: sha256} 可复用 freeze 开始时已算好的内容哈希（只读一次盘）。
    """
    items = []
    for d in docs or []:
        _oid = str((d or {}).get("id") or "")
        _cached = (content_cache or {}).get(_oid)
        if _cached:
            sha, size, err = _cached, None, ""
            _p = str((d or {}).get("path") or "")
            try:
                size = os.path.getsize(_p) if _p and os.path.isfile(_p) else 0
            except Exception:
                size = 0
        else:
            sha, size, err = _file_content_digest(str((d or {}).get("path") or ""))
        recorded = str((d or {}).get("hash") or "").strip().lower()
        items.append({
            "document_id": str((d or {}).get("id") or ""),
            "filename": str((d or {}).get("filename") or ""),
            "doc_type": str((d or {}).get("doc_type") or ""),
            "sha256": sha,
            "hash_algo": "sha256-raw-bytes",
            "size": size,
            "readable": bool(sha),
            "read_error": err,
            "recorded_hash": recorded,
            "recorded_hash_matches": (not recorded) or (not sha) or _hash_prefix_match(recorded, sha),
        })
    items.sort(key=lambda x: (x["document_id"], x["filename"]))
    readable = [x for x in items if x["readable"]]
    return {"items": items, "count": len(items), "readable_count": len(readable),
            "unreadable_count": len(items) - len(readable),
            "sha": _digest([(x["document_id"], x["sha256"]) for x in items]),
            "note": "原始文件字节 sha256；document_id 不参与内容判定，"
                    "同 document_id 覆盖文件字节会在 execution_guard 中检出并阻断"}


def _parse_artifact_closure(docs) -> tuple:
    """解析产物闭包：文本 sha256 + 数量；文本按上限另存 manifest_artifact:<mid>。"""
    if os.environ.get("RULEPROOF_FREEZE_PARSE", "1") == "0":
        return ({"items": [], "count": 0, "parsed_count": 0, "sha": "",
                 "skipped": True,
                 "note": "RULEPROOF_FREEZE_PARSE=0：本次未计算解析产物哈希（显式降级）"},
                {})
    items, artifacts = [], {}
    # L145：统一走 parse_bridge.parse_document（内容寻址缓存），不再直连解析器
    try:
        from . import parse_bridge as _parse_bridge
    except Exception:
        _parse_bridge = None
    for d in docs or []:
        oid = str((d or {}).get("id") or "")
        path = str((d or {}).get("path") or "")
        text, err = "", ""
        if not path:
            err = "path_empty"
        elif not os.path.isfile(path):
            err = "file_missing"
        elif _parse_bridge is None:
            err = "parser_unavailable"
        else:
            try:
                parsed = _parse_bridge.parse_document(path)
                text = str(getattr(parsed, "text", "") or "")
            except Exception as exc:
                err = f"{type(exc).__name__}: {str(exc)[:160]}"
        sha = _sha256_text(text) if text else ""
        stored = text[:_ARTIFACT_TEXT_LIMIT]
        artifacts[oid] = {"text": stored, "stored_chars": len(stored),
                          "chars": len(text), "truncated": len(text) > len(stored),
                          "sha256": sha}
        items.append({"document_id": oid,
                      "filename": str((d or {}).get("filename") or ""),
                      "text_sha256": sha, "chars": len(text),
                      "parse_ok": bool(text), "parse_error": err,
                      "stored_chars": len(stored),
                      "truncated": len(text) > len(stored)})
    items.sort(key=lambda x: (x["document_id"], x["filename"]))
    parsed_count = sum(1 for x in items if x["parse_ok"])
    return ({"items": items, "count": len(items), "parsed_count": parsed_count,
             "sha": _digest([(x["document_id"], x["text_sha256"]) for x in items]),
             "limits": {"text_chars_per_doc": _ARTIFACT_TEXT_LIMIT},
             "note": "解析产物文本 sha256；执行前若解析器/OCR 配置指纹变化 "
                     "execution_guard 会阻断，不静默重解析成不同事实"},
            artifacts)


def _parser_ocr_closure() -> dict:
    """解析器 + OCR 配置指纹：同文件在不同解析/OCR 配置下会得到不同文本。"""
    modules = {}
    for name, rel in _PARSER_CLOSURE_MODULES:
        try:
            modules[name] = _module_sha(rel)
        except Exception:
            modules[name] = ""
    ocr_cmd = str(getattr(config, "OCR_CMD", "") or os.environ.get("RULEPROOF_OCR_CMD", "") or "")
    try:
        from ..engine import baidu_ocr as _baidu
        baidu = bool(_baidu.configured())
    except Exception:
        baidu = False
    try:
        from ..engine import paddleocr as _paddle
        paddle = bool(_paddle.configured())
    except Exception:
        paddle = False
    dedicated = {"configured": False}
    try:
        from ..engine import ocr as _ocr
        cfg = _ocr._dedicated_ocr_cfg() or {}
        if cfg:
            from urllib.parse import urlparse
            host = urlparse(str(cfg.get("base_url") or "")).hostname or ""
            dedicated = {"configured": True, "model": str(cfg.get("model") or ""),
                         "base_url_host": host}
    except Exception:
        dedicated = {"configured": False}
    backend = ("baidu" if baidu else
               "paddle" if paddle else
               "dedicated" if dedicated.get("configured") else
               "external_cmd" if ocr_cmd else "none")
    render_cmd = str(os.environ.get("RULEPROOF_PDF_RENDER_CMD") or "")
    ocr = {
        "backend": backend,
        "configured": backend != "none",
        "external_cmd_present": bool(ocr_cmd),
        "external_cmd_sha": _sha(ocr_cmd) if ocr_cmd else "",
        "baidu_configured": baidu,
        "paddle_configured": paddle,
        "dedicated_configured": bool(dedicated.get("configured")),
        "dedicated_model": str(dedicated.get("model") or ""),
        "dedicated_host": str(dedicated.get("base_url_host") or ""),
        "pdf_render_cmd_present": bool(render_cmd),
        "pdf_render_cmd_sha": _sha(render_cmd) if render_cmd else "",
        "flags": {"RULEPROOF_MAX_BODY_BYTES": str(os.environ.get("RULEPROOF_MAX_BODY_BYTES") or "")},
    }
    return {"parser": "deepparse", "modules": modules,
            "modules_sha": _digest(modules), "ocr": ocr,
            "sha": _digest({"modules": modules, "ocr": ocr}),
            "note": "OCR/解析器配置指纹；任一模块哈希或 OCR 后端配置变化 → 执行前阻断"}


def _timezone_meta(tzname: str) -> dict:
    name = str(tzname or "").strip()
    if not name:
        return {}
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo(name)
        now = datetime.now(tz)
        return {"timezone": name, "utc_offset_seconds": int(now.utcoffset().total_seconds()),
                "source": "zoneinfo"}
    except Exception:
        return {"timezone": name, "utc_offset_seconds": None,
                "source": "unresolved", "error": "ZoneInfo 无法解析该时区"}


def _reference_closure(reference_time: str = "", timezone_name: str = "") -> dict:
    """业务参考时间/时区：本次 run 的“现在”= 冻结时刻，回放不得用当天日期重解释。"""
    tzname = str(timezone_name or os.environ.get("RULEPROOF_BUSINESS_TIMEZONE")
                 or os.environ.get("TZ") or "").strip()
    explicit = bool(str(reference_time or "").strip())
    try:
        if explicit:
            raw = str(reference_time).strip().replace("Z", "+00:00")
            ref = datetime.fromisoformat(raw)
            if ref.tzinfo is None:
                ref = ref.replace(tzinfo=datetime.now().astimezone().tzinfo)
        else:
            ref = datetime.now().astimezone()
        utc = ref.astimezone(timezone.utc)
    except Exception:
        ref = datetime.now().astimezone()
        utc = ref.astimezone(timezone.utc)
        explicit = False
    biz_date = ref.date().isoformat()
    tzmeta = _timezone_meta(tzname)
    if tzmeta.get("timezone") and tzmeta.get("utc_offset_seconds") is not None:
        try:
            from zoneinfo import ZoneInfo
            biz_date = ref.astimezone(ZoneInfo(tzmeta["timezone"])).date().isoformat()
        except Exception as _e:  # 静默兜底改为留痕（反补丁治理）
            logging.getLogger(__name__).debug("silent fallback: %s", _e)
    off = ref.utcoffset()
    return {
        "reference_time": ref.isoformat(timespec="seconds"),
        "reference_time_utc": utc.isoformat(timespec="seconds"),
        "timezone": tzmeta.get("timezone") or "local",
        "utc_offset_seconds": tzmeta.get("utc_offset_seconds") if tzmeta.get("utc_offset_seconds") is not None
        else (int(off.total_seconds()) if off else None),
        "business_date": biz_date,
        "source": "explicit" if explicit else "freeze_wall_clock",
        "frozen": True,
        "note": "本次 run 的业务“现在”固定为冻结时刻；次日回放/重放不得按当天重新解释"
                "“有效期未过”，也不得用实时时间改变 D1–D5 输入",
    }


def _external_results_closure(results, reference: dict = None) -> dict:
    """外部查询结果固化：每条必须有来源 + 获取时间戳，执行期只用冻结值。

    无时间戳/无来源的外部结果不允许进入闭包（`ValueError`），避免“看起来查过了”。
    """
    items = []
    for key, raw in sorted((results or {}).items(), key=lambda kv: str(kv[0])):
        if not isinstance(raw, dict) or "value" not in raw:
            raise ValueError(f"external_results[{key}] 必须是含 value/source/fetched_at 的对象")
        value = raw.get("value")
        source = str(raw.get("source") or "").strip()
        fetched = str(raw.get("fetched_at") or raw.get("observed_at") or "").strip()
        if not source:
            raise ValueError(f"external_results[{key}] 缺 source 来源，禁止无来源外部结果进入闭包")
        if not fetched:
            raise ValueError(f"external_results[{key}] 缺 fetched_at 时间戳，禁止无时间外部结果进入闭包")
        try:
            fetched_dt = datetime.fromisoformat(fetched.replace("Z", "+00:00"))
        except Exception:
            raise ValueError(f"external_results[{key}].fetched_at 不是 ISO 时间：{fetched}")
        items.append({
            "key": str(key),
            "source": source,
            "fetched_at": fetched,
            "fetched_at_utc": fetched_dt.astimezone(timezone.utc).isoformat(timespec="seconds")
            if fetched_dt.tzinfo else fetched_dt.isoformat(timespec="seconds"),
            "value": value,
            "value_sha": _digest(value, 16),
            "note": str(raw.get("note") or ""),
        })
    return {"items": items, "count": len(items),
            "sha": _digest([(x["key"], x["source"], x["fetched_at"], x["value_sha"]) for x in items]),
            "fixed": True,
            "frozen_at": str((reference or {}).get("reference_time") or ""),
            "note": "外部查询结果固化：执行期只读本快照值与获取时间，不接受实时重查覆盖"}


def _declared_external_inputs(items) -> dict:
    """从冻结 slots 中提取规则自带的外部输入（汇率/日历/有效期等），随闭包固化。"""
    out = []

    def _walk(obj, path: str) -> None:
        if len(out) >= 200:
            return
        if isinstance(obj, dict):
            for k, v in obj.items():
                key = f"{path}.{k}"
                if str(k) in _EXTERNAL_INPUT_KEYS and not isinstance(v, (dict, list)):
                    out.append({"ref": key, "key": str(k), "value": v})
                elif isinstance(v, (dict, list)):
                    _walk(v, key)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                if isinstance(v, (dict, list)):
                    _walk(v, f"{path}[{i}]")

    for it in items or []:
        if isinstance(it.get("slots"), dict):
            _walk(it["slots"], f"rule:{it.get('code') or it.get('rule_id') or '?'}")
    deduped = []
    seen = set()
    for row in out:
        if row["ref"] in seen:
            continue
        seen.add(row["ref"])
        deduped.append(row)
    return {"items": deduped, "count": len(deduped),
            "sha": _digest([(x["ref"], str(x["value"])) for x in deduped]),
            "source": "frozen_rule_slots",
            "note": "规则槽位中声明/携带的外部输入值已随 slots 冻结，执行期不从外部重查"}


def _params_closure() -> dict:
    """规则参数（生效值）快照：冻结后改参数不影响本次 run；下一次 freeze 才变。"""
    try:
        from . import ruleparam
        rows = ruleparam.snapshot() if hasattr(ruleparam, "snapshot") else (
            ruleparam.list_all() if hasattr(ruleparam, "list_all") else [])
        sha = ruleparam.params_sha() if hasattr(ruleparam, "params_sha") else ""
        items = []
        for r in rows or []:
            try:
                items.append(json.loads(json.dumps(r, ensure_ascii=False, default=str)))
            except Exception:
                items.append({"raw": str(r)[:200]})
        return {"count": len(items), "items": items, "sha": str(sha or _digest(items)),
                "source": "ruleparam.snapshot（仅生效值，不含 pending）",
                "note": "冻结后的参数变更不改变本次 run；只有下一次 freeze 重新生成闭包"}
    except Exception as exc:
        return {"count": 0, "items": [], "error": f"{type(exc).__name__}: {str(exc)[:160]}"}


def _ontology_closure(binding: dict) -> dict:
    """冻结时真正参与 D4 取数的本体/术语快照指纹（完整快照另存 manifest_ontology）。"""
    b = binding or {}
    return {"sha": b.get("sha") or "",
            "hashes": b.get("hashes") or {},
            "sources": b.get("sources") or {},
            "alias_count": sum(len(v) for v in (b.get("aliases") or {}).values()),
            "term_count": len(b.get("terms") or []),
            "entity_count": len(b.get("entities") or []),
            "relation_count": len(b.get("relations") or []),
            "note": "冻结后追加/停用别名不改变本次 run（D4 只读 item.ontology_binding + 本快照）"}


def _unit_dictionary_closure(terms, items) -> dict:
    """单位字典：执行器换算表 + 单位量纲 + 词典单位 + 规则使用单位，全部固化。"""
    scale, dims = {}, {}
    err = ""
    try:
        from ..engine import ruleexec as _re
        scale = {str(k): v for k, v in (getattr(_re, "_UNIT_SCALE", {}) or {}).items()}
        for unit in sorted(set(scale) | set(_rule_units(items))):
            try:
                dim = _re._unit_dim(unit)
            except Exception:
                dim = ""
            if dim:
                dims[unit] = dim
    except Exception as exc:
        err = f"{type(exc).__name__}: {str(exc)[:120]}"
    term_units = {}
    for t in terms or []:
        unit = str((t or {}).get("unit") or "").strip()
        if unit:
            term_units[str((t or {}).get("name") or (t or {}).get("term_key") or "")] = unit
    payload = {"scale": scale, "dimensions": dims, "term_units": term_units,
               "rule_units": _rule_units(items)}
    units = sorted(set(scale) | set(dims) | set(term_units.values()) |
                   {u for us in payload["rule_units"].values() for u in us})
    return {"units": units, "count": len(units), **payload,
            "sha": _digest(payload), "error": err,
            "note": "单位字典随冻结固化；换主版本改换算表/量纲后同一 run 不得按新字典重算"}


def _rule_units(items) -> dict:
    out = {}
    for it in items or []:
        slots = (it or {}).get("slots") or {}
        if not isinstance(slots, dict):
            continue
        code = str(it.get("code") or it.get("rule_id") or "")
        units = []
        unit = str(slots.get("unit") or "").strip()
        if unit:
            units.append(unit)
        for sub in (slots.get("subrequirements") or slots.get("criteria_list") or []):
            if isinstance(sub, dict) and str(sub.get("unit") or "").strip():
                units.append(str(sub["unit"]).strip())
        if units:
            out[code] = sorted(dict.fromkeys(units))
    return out


def _conflict_priority_closure(rule_meta, items) -> dict:
    """规则冲突优先级：显式 priority / 决策表 priority / hit_policy / 清单顺序。"""
    rules = sorted([dict(x) for x in (rule_meta or [])], key=lambda x: str(x.get("code") or ""))
    dmn = {}
    for it in items or []:
        for row in (it or {}).get("decision_tables") or []:
            key = (str(row.get("code") or ""), str(row.get("version") or ""))
            if not key[0] or key in dmn:
                continue
            dmn[key] = {"code": key[0], "version": key[1],
                        "priority": row.get("priority"),
                        "hit_policy": str(row.get("hit_policy") or ""),
                        "rules_hash": str(row.get("rules_hash") or ""),
                        "scope_types": row.get("scope_types") or []}
    conflicts = []
    try:
        from . import conflict as _cf
        conflicts = _cf.analyze_rules(
            [{"code": m.get("code") or "", "name": m.get("name") or m.get("code") or "",
              "slots": m.get("slots") or {}} for m in rules], persist=False)
    except Exception:
        conflicts = [{"error": "conflict_analyze_unavailable"}]
    payload = {"rules": rules, "decision_tables": [dmn[k] for k in sorted(dmn)],
               "resolution_order": list(_CONFLICT_RESOLUTION_ORDER),
               "conflicts": conflicts}
    return {**payload, "sha": _digest(payload),
            "note": "冻结时冲突优先级与检测结论；执行期按本快照顺序裁决，不再读实时冲突表"}


def _binding_closure_summary(rule_bindings) -> dict:
    """V02 allowed/selected 校验：selected ⊆ allowed 是硬不变量。"""
    violations = []
    for b in rule_bindings or []:
        allowed = set(b.get("allowed_object_ids") or [])
        selected = set(b.get("selected_object_ids") or [])
        outside = sorted(selected - allowed)
        if outside:
            violations.append({"rule_id": b.get("rule_id"), "rule_code": b.get("rule_code"),
                               "object_ids": outside})
    allowed_total = sum(len(b.get("allowed_object_ids") or []) for b in rule_bindings or [])
    selected_total = sum(len(b.get("selected_object_ids") or []) for b in rule_bindings or [])
    return {"schema": BINDING_SCHEMA, "rules": list(rule_bindings or []),
            "rule_count": len(rule_bindings or []),
            "allowed_total": allowed_total, "selected_total": selected_total,
            "selected_subset_of_allowed": not violations,
            "violations": violations,
            "sha": _digest([(b.get("rule_id"), (b.get("rule_version") or {}).get("version"),
                             b.get("allowed_object_ids"), b.get("selected_object_ids"))
                            for b in rule_bindings or []]),
            "note": "allowed=规则作用域允许的对象全集（硬边界）；selected=本次清单实际冻结"
                    "的对象；selected ⊆ allowed"}


def _closure_digest(closure: dict) -> str:
    body = {k: v for k, v in (closure or {}).items()
            if k not in ("built_at", "digest", "snapshot_id")}
    return _digest(body, _CLOSURE_DIGEST_LEN)


def _build_closure(*, case_id: str, tenant_id: str, workspace_id: str,
                   manifest_id: str, docs, reference: dict, external_results,
                   terms, items, rule_versions, binding, gate: dict,
                   ontology_binding: dict = None) -> tuple:
    """构建完整冻结闭包（返回 closure, artifacts）；各子项独立容错，不静默造假。"""
    errors = {}
    try:
        files = _file_closure(docs)
    except Exception as exc:
        files = {"items": [], "count": 0, "sha": ""}
        errors["files"] = f"{type(exc).__name__}: {str(exc)[:160]}"
    try:
        parsed, artifacts = _parse_artifact_closure(docs)
    except Exception as exc:
        parsed, artifacts = {"items": [], "count": 0, "sha": ""}, {}
        errors["parsed_artifacts"] = f"{type(exc).__name__}: {str(exc)[:160]}"
    try:
        parser_ocr = _parser_ocr_closure()
    except Exception as exc:
        parser_ocr = {"sha": "", "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
        errors["parser_ocr"] = parser_ocr["error"]
    try:
        units = _unit_dictionary_closure(terms, items)
    except Exception as exc:
        units = {"sha": "", "units": [], "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
        errors["unit_dictionary"] = units["error"]
    try:
        conflict = _conflict_priority_closure(
            [{"code": r.get("code"), "name": r.get("name"),
              "slots": (it.get("slots") if isinstance(it.get("slots"), dict) else {})}
             for r, it in _rule_meta_pairs(items)],
            items)
    except Exception as exc:
        conflict = {"sha": "", "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
        errors["rule_conflict_priority"] = conflict["error"]
    external = _external_results_closure(external_results or {}, reference)
    external["declared_inputs"] = _declared_external_inputs(items)
    try:
        rule_params = _params_closure()
    except Exception as exc:
        rule_params = {"count": 0, "items": [],
                       "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
        errors["rule_params"] = rule_params["error"]
    closure = {
        "schema": CLOSURE_SCHEMA,
        "manifest_id": str(manifest_id or ""),
        "case_id": str(case_id or ""),
        "tenant_id": str(tenant_id or ""),
        "workspace_id": str(workspace_id or ""),
        "built_at": datetime.now().isoformat(timespec="seconds"),
        "files": files,
        "parsed_artifacts": parsed,
        "parser_ocr": parser_ocr,
        "business_reference": reference or {},
        "external_results": external,
        "rule_params": rule_params,
        "ontology": _ontology_closure(ontology_binding or {}),
        "unit_dictionary": units,
        "rule_conflict_priority": conflict,
        "rule_versions": list(rule_versions or []),
        "binding": binding or {},
        "gate": {"ok": bool((gate or {}).get("ok")), "gate": (gate or {}).get("gate"),
                 "blocked": len((gate or {}).get("blocked") or []),
                 "routed_out": len((gate or {}).get("routed_out") or [])},
        "limits": {"artifact_text_chars_per_doc": _ARTIFACT_TEXT_LIMIT,
                   "binding_section_limit": _BINDING_SECTION_LIMIT},
        "errors": errors,
        "degraded": bool(errors),
        # A6：新清单闭包必须可校验；execution_guard 据此拒绝 degraded/缺失的闭包执行。
        "closure_required": True,
        "note": "一次 run 的冻结闭包：执行前用 execution_guard 校验；闭包只读，不得事后改写",
    }
    closure["digest"] = _closure_digest(closure)
    return closure, artifacts


def _rule_meta_pairs(items) -> list:
    """(规则头, 首个 item) 对：用于闭包里按规则提取 slots。"""
    seen, out = set(), []
    for it in items or []:
        rid = str((it or {}).get("rule_id") or "")
        if not rid or rid in seen:
            continue
        seen.add(rid)
        out.append(({"code": it.get("code"), "name": it.get("name")}, it))
    return out


def _save_closure(manifest_id: str, closure: dict, artifacts: dict) -> None:
    from . import sysconfig
    sysconfig.set_many({
        CLOSURE_PREFIX + str(manifest_id or ""): json.dumps(
            closure or {}, ensure_ascii=False, default=str),
        ARTIFACT_PREFIX + str(manifest_id or ""): json.dumps(
            artifacts or {}, ensure_ascii=False, default=str),
    })


def load_closure(manifest_id: str) -> dict:
    """读取某次冻结的完整闭包；旧清单/未落库返回 {}。"""
    from . import sysconfig
    raw = sysconfig.get(CLOSURE_PREFIX + str(manifest_id or ""), "")
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def load_artifact(manifest_id: str) -> dict:
    """读取冻结的解析产物文本（按文件截断；哈希在闭包里）。"""
    from . import sysconfig
    raw = sysconfig.get(ARTIFACT_PREFIX + str(manifest_id or ""), "")
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def closure_keys_for_case(case_id: str) -> dict:
    """某项目所有 manifest 的冻结闭包键（供数据删除/留存盘点使用）。

    闭包与解析文本存在 sys_config（键不含租户前缀），因此项目删除时必须显式清理，
    避免“删了项目还留原文/解析文本”的数据留存缺口。
    """
    mids = []
    try:
        with db.session() as c:
            rows = c.execute("SELECT id FROM audit_manifest WHERE case_id=?",
                             (str(case_id or ""),)).fetchall()
        mids = [str(r["id"]) for r in rows if r and r["id"]]
    except Exception:
        mids = []
    keys = []
    for mid in mids:
        keys.extend([CLOSURE_PREFIX + mid, ARTIFACT_PREFIX + mid,
                     _ONTO_SNAPSHOT_PREFIX + mid, CLOSURE_REQUIRED_PREFIX + mid])
    return {"case_id": str(case_id or ""), "manifest_ids": mids,
            "keys": keys, "key_pairs": {"manifest_count": len(mids)}}


def purge_closures_for_case(case_id: str, actor: str = "system") -> dict:
    """清理某项目的冻结闭包/解析文本/本体快照键（数据删除请求用，只清本项目）。

    不删 audit_manifest 行本身（由项目级联删除/留存策略负责）；清理后历史 run 的
    execution_guard 会退化为 legacy（完整性不可证明），因此只应在数据删除/留存到期时调用。
    """
    info = closure_keys_for_case(case_id)
    deleted = 0
    if info.get("keys"):
        from . import sysconfig
        try:
            deleted = int(sysconfig.delete_keys(info["keys"]) or 0)
        except Exception:
            deleted = 0
    try:
        R.audit_logs.log(actor=actor or "system", action="manifest.closure_purged",
                         object=str(case_id or ""),
                         after=json.dumps({"manifest_count": len(info.get("manifest_ids") or []),
                                           "keys_requested": len(info.get("keys") or []),
                                           "keys_deleted": deleted},
                                          ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("closure purge audit skipped", exc_info=True)
    return {"ok": True, "case_id": str(case_id or ""),
            "manifest_count": len(info.get("manifest_ids") or []),
            "keys_deleted": deleted}


# 公共只读快照 API：version_snapshot / 报告 / 审计复用同一口径，避免两处算法漂移。
file_content_digest = _file_content_digest
parser_ocr_fingerprint = _parser_ocr_closure
business_reference = _reference_closure
unit_dictionary_snapshot = _unit_dictionary_closure


def closure_summary(closure: dict = None, manifest_id: str = "") -> dict:
    """给报告/审计/测试用的闭包摘要（不含解析全文）。"""
    closure = closure or (load_closure(manifest_id) if manifest_id else {})
    if not closure:
        return {"available": False, "manifest_id": str(manifest_id or ""),
                "note": "无冻结闭包（旧清单或未落库）"}
    files = closure.get("files") or {}
    parsed = closure.get("parsed_artifacts") or {}
    parser_ocr = closure.get("parser_ocr") or {}
    external = closure.get("external_results") or {}
    units = closure.get("unit_dictionary") or {}
    conflict = closure.get("rule_conflict_priority") or {}
    binding = closure.get("binding") or {}
    reference = closure.get("business_reference") or {}
    return {
        "available": True,
        "schema": closure.get("schema"),
        "manifest_id": closure.get("manifest_id") or str(manifest_id or ""),
        "digest": closure.get("digest"),
        "degraded": bool(closure.get("degraded")),
        "errors": closure.get("errors") or {},
        "files": {"count": files.get("count"), "readable_count": files.get("readable_count"),
                  "sha": files.get("sha")},
        "parsed_artifacts": {"count": parsed.get("count"),
                             "parsed_count": parsed.get("parsed_count"),
                             "sha": parsed.get("sha")},
        "parser_ocr": {"sha": parser_ocr.get("sha"),
                       "ocr_backend": (parser_ocr.get("ocr") or {}).get("backend")},
        "business_reference": {
            "reference_time": reference.get("reference_time"),
            "timezone": reference.get("timezone"),
            "business_date": reference.get("business_date"),
            "frozen": bool(reference.get("frozen")),
        },
        "external_results": {"count": external.get("count"), "sha": external.get("sha")},
        "rule_params": {"count": (closure.get("rule_params") or {}).get("count"),
                        "sha": (closure.get("rule_params") or {}).get("sha")},
        "ontology": {"sha": (closure.get("ontology") or {}).get("sha"),
                     "alias_count": (closure.get("ontology") or {}).get("alias_count")},
        "unit_dictionary": {"count": units.get("count"), "sha": units.get("sha")},
        "rule_conflict_priority": {"sha": conflict.get("sha"),
                                   "resolution_order": conflict.get("resolution_order") or []},
        "rule_versions": {"count": len(closure.get("rule_versions") or [])},
        "binding": {"sha": binding.get("sha"), "rules": binding.get("rule_count"),
                    "allowed_total": binding.get("allowed_total"),
                    "selected_total": binding.get("selected_total"),
                    "selected_subset_of_allowed": binding.get("selected_subset_of_allowed")},
        "built_at": closure.get("built_at"),
    }


def _source_inventory() -> dict:
    """四来源的可用/草稿库存，用于 gate 报告，不作为放行依据。"""
    inv = {k: {"label": _SOURCE_LABELS[k], "available": 0, "drafts": 0,
               "used": 0, "in_manifest": 0, "blocked": 0}
           for k in _SOURCE_LABELS}
    try:
        _eff_ids_inv = {str(x.get("id") or "") for x, _v in effective_rule_rows()}
        for r in R.rules.list() or []:
            cnt = inv[_source_kind(r.get("source"))]
            status = str(r.get("status") or "")
            if str(r.get("id") or "") in _eff_ids_inv:
                # 生效版本口径：published 版本存在即可执行，草稿状态但旧版生效也算 available
                cnt["available"] += 1
            elif status in ("draft", "pending", "approved"):
                cnt["drafts"] += 1
    except Exception:
        logging.getLogger(__name__).debug("rule inventory skipped", exc_info=True)
    try:
        for t in R.decision_tables.list() or []:
            cnt = inv["decision_table"]
            if str(t.get("status") or "") == "published":
                cnt["available"] += 1
            else:
                cnt["drafts"] += 1
    except Exception:
        logging.getLogger(__name__).debug("decision table inventory skipped", exc_info=True)
    try:
        from . import terms as _terms
        for t in _terms.list_terms() or []:
            cnt = inv["dictionary"]
            if str(t.get("status") or "").lower() in _EFFECTIVE_TERM_STATUS:
                cnt["available"] += 1
            else:
                cnt["drafts"] += 1
    except Exception:
        logging.getLogger(__name__).debug("business term inventory skipped", exc_info=True)
    return inv


def _term_index() -> dict:
    """术语名/键 → 术语行；用于判断规则引用的词典条目是否已确认。"""
    idx = {}
    try:
        from . import terms as _terms
        for t in _terms.list_terms() or []:
            for key in (t.get("name"), t.get("term_key"), t.get("term_id"), t.get("id")):
                key = str(key or "").strip().lower()
                if key:
                    idx[key] = t
    except Exception:
        logging.getLogger(__name__).debug("business term index skipped", exc_info=True)
    return idx


def _source_gate(rule: dict, slots: dict, scope_obj: dict,
                 tables: dict, term_idx: dict) -> tuple:
    """任一来源的已发布物都过同一门禁；返回 (来源, 使用来源, 失败项, 术语门禁)。

    术语检查与 ontology_ops.term_gate 同一口径（冻结与本体发布共用）。
    """
    kind = _source_kind(rule.get("source"))
    used = {kind}
    failures = []
    term_refs = _as_tokens(slots.get("terms") or scope_obj.get("terms") or [])
    term_gate = {}
    try:
        _pv = R.rules.published_version(rule.get("id") or "") or {}
    except Exception:
        _pv = {}
    if not _pv:
        failures.append({"source": kind, "reason": "no_published_version",
                         "status": rule.get("status"),
                         "detail": "无生效 published 版本（current_version_id 校验），不执行"})
    for code in _as_tokens(slots.get("decision_tables") or slots.get("decision_table") or []):
        used.add("decision_table")
        row = tables.get(str(code))
        if not row:
            failures.append({"source": "decision_table", "reason": "decision_table_missing",
                             "code": str(code)})
        elif str(row.get("status") or "") != "published":
            failures.append({"source": "decision_table", "reason": "decision_table_unpublished",
                             "code": str(code), "status": row.get("status")})
        elif not str(row.get("version") or "").strip():
            failures.append({"source": "decision_table", "reason": "decision_table_unversioned",
                             "code": str(code)})
    if term_refs:
        used.add("dictionary")
        try:
            from . import ontology_service as _ontology
            term_gate = _ontology.term_gate(term_refs, term_index=term_idx)
            for hit in term_gate.get("unconfirmed") or []:
                failures.append({"source": "dictionary", "reason": "term_unconfirmed",
                                 "term": hit.get("term"), "status": hit.get("status"),
                                 "term_id": hit.get("term_id") or ""})
        except Exception:
            logging.getLogger(__name__).debug("term gate unavailable", exc_info=True)
    return kind, used, failures, term_gate


def _type_matches(token: str, obj: dict, oroute: dict) -> bool:
    """文件类型 token 与对象扩展名 / 库文件类型 / 文件名匹配。"""
    t = str(token or "").strip().lower().lstrip(".")
    if not t:
        return False
    if t in oroute.get("extensions", []):
        return True
    if t in str(oroute.get("doc_type") or "").lower():
        return True
    if t == str(oroute.get("library_type") or "").lower():
        return True
    if t in str(oroute.get("library_type_name") or "").lower():
        return True
    if t in str(obj.get("filename") or "").lower():
        return True
    return False


def _gate_block(gate: dict, rule: dict, kind: str, failures: list) -> None:
    gate["blocked"].append({
        "rule_id": rule.get("id"), "code": rule.get("code"),
        "name": rule.get("name"), "source": kind,
        "reasons": failures,
    })


def _gate_routed_out(gate: dict, rule: dict, kind: str, reason: str,
                     object_count: int = 0) -> None:
    """记录一条 routed_out。L80：台账开启时额外记 object_count（doc×rule 对数），
    供裁决来源统计做「映射 = 真实 + 路由出 + 差账」守恒；=0 时 gate 逐字段不变。"""
    entry = {
        "rule_id": rule.get("id"), "code": rule.get("code"),
        "name": rule.get("name"), "source": kind, "reason": reason,
    }
    if _adj_ledger.enabled() and object_count:
        entry["object_count"] = int(object_count)
    gate["routed_out"].append(entry)


# A9（2026-11-21）：无 scope 的历史批准规则默认不消费；空间显式 opt-in 才按项目级执行。
# opt-in = 空间级显式配置（env 白名单 RULEPROOF_LEGACY_SCOPE_OPT_IN 或 workspace
# settings_json.legacy_scope_opt_in=true）；默认缺省 = routed_out(scope_missing_legacy)。
def _workspace_legacy_scope_opt_in(workspace_id: str) -> bool:
    """空间级 opt-in：默认关闭（缺省即 routed_out）；两种显式配置方式：

    1. ``RULEPROOF_LEGACY_SCOPE_OPT_IN``：逗号分隔的 workspace_id 白名单，
       或 ``1/true/all`` 表示所有空间显式开启（运维/迁移期显式动作，可审计）；
    2. ``workspace.settings_json.legacy_scope_opt_in=true``：空间配置项（若存储层
       允许该键，本函数同样识别）；两处都缺省 → 不消费 legacy 规则。
    """
    wid = str(workspace_id or "").strip()
    raw = str(os.environ.get("RULEPROOF_LEGACY_SCOPE_OPT_IN", "") or "").strip().lower()
    if raw in ("1", "true", "yes", "on", "all"):
        return True
    if raw and wid:
        _tokens = {x.strip().lower() for x in raw.split(",") if x.strip()}
        if wid.lower() in _tokens:
            return True
    if not wid:
        return False
    try:
        from . import workspaces as _ws
        st = _ws.get_settings(wid) or {}
        return (st.get("legacy_scope_opt_in") is True
                or str(st.get("legacy_scope_opt_in") or "").strip().lower()
                in ("1", "true", "yes", "on"))
    except Exception:
        logging.getLogger(__name__).debug("legacy scope opt-in lookup skipped", exc_info=True)
        return False


# L27 Phase0 Task 0.2（2026-11-23，0 LLM）：gate.routed_out 明细 → routing.routed_out_codes
# 精确码表 + 原因表 + 规范化原因桶。纯函数（只读 gate、只加 routing 字段），
# freeze 末尾调用一次；reason 桶：audit_type_not_routed | conditional_type_untriggered |
# scope_mismatch | budget_trimmed | other。code 表按首次出现顺序去重，长度可与
# gate.routed_out 计数逐文档对账（每个明细都带 code）。
def attach_routing_routed_out(gate: dict) -> dict:
    """把 gate.routed_out 明细汇总进 gate.routing（routed_out_codes/reasons/buckets）。"""
    gate = gate if isinstance(gate, dict) else {}
    routed = gate.get("routed_out") or []
    codes, reasons, buckets = [], {}, {}
    for ro in routed:
        code = str((ro or {}).get("code") or "")
        if not code:
            continue
        if code not in codes:
            codes.append(code)
        raw_reason = str((ro or {}).get("reason") or "")
        reasons[code] = raw_reason
        if "conditional" in raw_reason:
            bucket = "conditional_type_untriggered"
        elif "budget" in raw_reason:
            bucket = "budget_trimmed"
        elif "audit_type" in raw_reason:
            bucket = "audit_type_not_routed"
        elif any(k in raw_reason for k in ("scope", "route", "business", "tag",
                                          "no_objects", "type")):
            bucket = "scope_mismatch"
        else:
            bucket = "other"
        buckets[code] = bucket
    gate.setdefault("routing", {})
    gate["routing"]["routed_out_codes"] = codes
    gate["routing"]["routed_out_reasons"] = reasons
    gate["routing"]["routed_out_reason_buckets"] = buckets
    gate["routing"]["routed_out_codes_count"] = len(codes)
    return gate["routing"]


def freeze(case_id: str, actor: str = "", source: str = "published_rules",
           freeze_all: bool | None = None, rule_codes: list | None = None,
           reference_time: str = "", timezone_name: str = "",
           external_results: dict | None = None) -> dict:
    from . import ctx as _ctx
    from . import rule_ir as _ir
    case = R.cases.get(case_id)
    if not case:
        return {"error": "项目不存在"}
    # T-161：三区分层标记开关（默认开）。只决定 item 是否写 zone 字段；
    # 关闭时 items 与改动前完全一致，不改变冻结/执行/判定任何行为。
    _zone_tagging = _audit_zone.tagging_enabled()
    # V01：业务参考时间/时区在冻结开始就固定（后续所有子步骤共用，不各取一次 now()）；
    # 外部查询结果必须带来源 + 获取时间戳，格式非法直接拒绝冻结（fail-closed），
    # 不允许“看起来查过了”的无来源/无时间外部结果进入闭包。
    _reference = _reference_closure(reference_time, timezone_name)
    _external_validated = _external_results_closure(external_results or {}, _reference)
    tenant = case.get("tenant_id") or "t-default"
    workspace = case.get("workspace_id") or "ws-default"
    _saved_mode = {}
    try:
        _saved_mode = _ctx.get_audit_mode()
    except Exception:
        _saved_mode = {}
    # 先切到案例所属租户/空间再构建冻结快照：否则会串到调用方空间的本体/术语
    _ctx.set_context(tenant, workspace)
    _onto_binding = _ontology_binding(workspace)
    docs = R.cases.documents(case_id)
    # V01：原始文件内容哈希只读一次并复用到闭包与 item 绑定（避免多次读盘/解析）
    _doc_content = {}
    for _d in docs:
        _c_sha, _c_size, _c_err = _file_content_digest(str(_d.get("path") or ""))
        _doc_content[str(_d.get("id") or "")] = _c_sha
    objects = [{"object_id": d.get("id"), "filename": d.get("filename"),
                "doc_type": d.get("doc_type"), "role": "被审对象"} for d in docs]
    # 规则集收窄：空间显式配置 rule_codes 时，只冻结本次范围内的正式规则。
    # T-136 C-6（P0）：范围三态必须区分，禁止 fail-open 扩大审核范围：
    #   * rule_codes=None  → 未指定：沿用空间默认范围（空间也未配置 = 全量）；
    #   * rule_codes=[]    → 用户显式选择 0 条：拒绝冻结（显式 0 条 ≠ 全量）；
    #   * 空间规则集读取异常 → 拒绝冻结（fail-closed），不得退化为全量。
    # CLI 已把 ``--rules`` 的空列表归一为 None（app/cli.py），HTTP/定向复审若传 []，
    # 由此处显式拒绝，不再静默变成“全量审核”。
    _explicit_codes = None
    if rule_codes is not None:
        try:
            _explicit_codes = [str(x).strip() for x in rule_codes if str(x).strip()]
        except TypeError:
            return {"ok": False, "error": "invalid_rule_codes",
                    "code": "invalid_rule_codes",
                    "message": "rule_codes 必须是规则编码列表；未指定范围请传 None"}
        if not _explicit_codes:
            return {"ok": False, "error": "empty_rule_codes",
                    "code": "empty_rule_codes",
                    "message": "显式规则范围为空（0 条）：已拒绝冻结，不退化为全量审核；"
                               "如需沿用空间默认范围请传 None"}
    _allow_codes = set()
    try:
        from . import workspaces as _ws
        _st = _ws.get_settings(workspace) or {}
        _allow_codes = {str(x) for x in (_st.get("rule_codes") or []) if str(x).strip()}
    except Exception as _scope_exc:
        if _explicit_codes is None:
            # 空间规则集读取失败且调用方未显式给范围：无法证明审核范围 → 拒绝冻结。
            return {"ok": False, "error": "scope_read_failed",
                    "code": "scope_read_failed",
                    "message": "读取空间规则集失败，已拒绝冻结（fail-closed）："
                               f"{type(_scope_exc).__name__}: {str(_scope_exc)[:120]}"}
        logging.getLogger(__name__).warning(
            "workspace rule scope read failed; explicit rule_codes used", exc_info=True)
    # 定向复审：显式 rule_codes 优先于空间默认范围；None 表示沿用原范围。
    if _explicit_codes is not None:
        _allow_codes = set(_explicit_codes)
    _freeze_all = freeze_all
    if _freeze_all is None:
        _freeze_all = os.environ.get("RULEPROOF_FREEZE_ALL") == "1"
    if _freeze_all is False:
        try:
            from . import workspaces as _wsv
            _freeze_all = bool((_wsv.get_settings(workspace) or {}).get("freeze_all_rules"))
        except Exception:
            _freeze_all = False

    # 四来源库存 + 路由树 + 门禁状态
    lib = _load_library()
    # T06：条件类型按文档特征触发。解析正文仅供路由特征判断（不进入证据/判定链路）；
    # 全部文档解析失败时回退旧口径（无条件并入）并在 gate 留痕，避免“读不到正文就少选”。
    _trigger_on = conditional_trigger_enabled()
    # T06-R1（B5-L17 P0）：启动/冻结期登记校验——任何 conditional 类型既无钩子又无显式
    # legacy 标记 → 立即报错（fail-closed），不允许像 B5-L16 那样静默压成「永不触发」。
    # =0 回退（legacy 全量并入）不需要登记表，故不校验。
    _registry_info = {}
    if _trigger_on and lib is not None:
        try:
            _registry_info = validate_conditional_registry(lib)
        except ConditionalRegistryError as _reg_exc:
            logging.getLogger(__name__).error(
                "conditional registry invalid: %s", _reg_exc)
            return {"ok": False, "error": "conditional_registry_invalid",
                    "code": "conditional_registry_invalid",
                    "message": str(_reg_exc)[:800]}
    _route_texts, _texts_ok = _route_feature_texts(docs)
    _trigger_policy = "legacy_merged"
    if _trigger_on:
        if _texts_ok:
            _trigger_policy = "conditional_trigger"
        else:
            _trigger_on = False
            _trigger_policy = "unavailable_fallback"
    obj_meta = [{"object": o, "route": _object_route(
        o, case, lib,
        feature_text=_route_texts.get(str(o.get("object_id") or ""), ""),
        trigger_conditional=_trigger_on)} for o in objects]
    _opt_counts = {"default_types": 0, "triggered_types": 0, "optional_types": 0,
                   "legacy_merged_types": 0, "unregistered_conditional_types": 0}
    for _om in obj_meta:
        _rt = _om["route"]
        _opt_counts["default_types"] += len(_rt.get("default_audit_types") or [])
        _opt_counts["triggered_types"] += len(_rt.get("triggered_audit_types") or [])
        _opt_counts["optional_types"] += len(_rt.get("optional_audit_types") or [])
        _opt_counts["legacy_merged_types"] += len(
            _rt.get("legacy_merged_audit_types") or [])
        _opt_counts["unregistered_conditional_types"] += len(
            _rt.get("unregistered_conditional_types") or [])
    _routing_meta = {
        "conditional_trigger": bool(_trigger_on),
        "conditional_trigger_policy": _trigger_policy,
        "doc_budget": route_doc_budget(),
        "feature_texts": len([x for x in _route_texts.values() if str(x or "").strip()]),
        "feature_texts_available": bool(_texts_ok),
        "counts": _opt_counts,
        # T06-R1：登记表版本与校验结果（冻结留痕；未登记/漂移时已在上面 fail-closed）
        "registry": dict(_registry_info or {}),
        "env": {_CONDITIONAL_TRIGGER_ENV: os.environ.get(_CONDITIONAL_TRIGGER_ENV, ""),
                _ROUTE_DOC_BUDGET_ENV: os.environ.get(_ROUTE_DOC_BUDGET_ENV, "")},
    }
    tables = {}
    try:
        tables = {str(t.get("code")): t for t in (R.decision_tables.list() or [])}
    except Exception:
        tables = {}
    term_idx = _term_index()
    inventory = _source_inventory()
    gate = {
        "ok": True,
        "gate": _GATE_VERSION,
        "mode": "freeze_all" if _freeze_all else "routed",
        "freeze_all": bool(_freeze_all),
        "checks": list(_GATE_CHECKS),
        "sources": inventory,
        "blocked": [],
        "routed_out": [],
        "case_level": [],
        "included_rules": 0,
        "included_items": 0,
        "ontology_binding": _onto_binding,
        # 术语门禁统一口径：未确认术语阻断冻结（与 ontology_ops.publish 同一函数）
        "term_gate": {"ok": True, "policy": "unconfirmed_term_blocks_freeze_and_publish",
                      "checked": [], "checked_count": 0, "unconfirmed": [],
                      "unconfirmed_count": 0, "missing_in_dictionary": []},
        # V02：allowed（规则作用域允许的对象全集，硬边界）/ selected（本次清单实际冻结）
        "binding": {"ok": True, "schema": BINDING_SCHEMA, "allowed_total": 0,
                    "selected_total": 0, "selected_subset_of_allowed": True,
                    "violations": [], "rules": 0},
        # T06：条件类型触发 + 可选规则池（不进入冻结清单；供路由器/人工显式选取）
        "routing": {"conditional_trigger": False, "conditional_trigger_policy": "",
                    "doc_budget": 0, "feature_texts": 0, "feature_texts_available": False,
                    "counts": {"default_types": 0, "triggered_types": 0,
                               "optional_types": 0}},
        "optional_pool": {"counts": {}, "entries": [],
                          "note": "条件类型未触发/自动推断 scope 待确认/超路由预算的规则；"
                                  "不进入冻结清单（不改变被测对象），可被路由器显式选取"},
    }
    gate["routing"] = _routing_meta

    def _merge_term_gate(part: dict) -> None:
        if not part:
            return
        merged = gate["term_gate"]
        merged["checked"].extend(part.get("checked") or [])
        merged["checked_count"] = len(merged["checked"])
        merged["unconfirmed"].extend(part.get("unconfirmed") or [])
        merged["unconfirmed_count"] = len(merged["unconfirmed"])
        for miss in part.get("missing_in_dictionary") or []:
            if miss not in merged["missing_in_dictionary"]:
                merged["missing_in_dictionary"].append(miss)
        merged["ok"] = merged["ok"] and bool(part.get("ok"))
        merged["policy"] = part.get("policy") or merged.get("policy")
        if part.get("effective_statuses"):
            merged["effective_statuses"] = list(part["effective_statuses"])
        if part.get("rule"):
            merged["rule"] = part["rule"]

    # 数据一致性告警：rule.status=published 但没有 published 版本 → 不执行且 gate 可见。
    try:
        _eff_ids = {str(r.get("id") or "") for r, _v in effective_rule_rows()}
        for _r in R.rules.list("status=?", ("published",)):
            if str(_r.get("id") or "") in _eff_ids:
                continue
            _gate_block(gate, _r, _source_kind(_r.get("source")), [{
                "source": "rule_library", "reason": "no_published_version",
                "detail": "规则状态为已发布但缺少 published 版本（数据不一致），不进入清单；"
                          "请重新发布修复"}])
    except Exception:
        logging.getLogger(__name__).debug("published-no-version scan skipped", exc_info=True)
    rules, items = [], []
    _rule_bindings = []
    _frozen_rule_versions = []
    # manifest_id 提前生成：item 绑定/闭包在落库前就要引用它（但 item 内不写 id，保持哈希稳定）
    mid = db.new_id("man")
    # P0-01：规则集 = 有生效 published 版本的规则（current_version_id+published），
    # 不看 rule.status；编辑已发布规则（status=draft）后旧 published 继续生效。
    # T-136 C-1：作用域按「生效版本」读取——版本级快照优先，旧数据回退 rule 主记录；
    # 未发布草稿（fork 出的新版本）的 scope 不参与本清单，旧生效版本对象集合稳定。
    _eff_rows = effective_rule_rows()
    _scope_snapshots = load_rule_scope_snapshots(
        [str(v.get("id") or "") for _r, v in _eff_rows])
    for r, v in _eff_rows:
        if _allow_codes and str(r.get("code") or "") not in _allow_codes:
            continue
        try:
            slots = json.loads(v.get("slots_json") or "{}")
        except Exception:
            slots = {}
        if not isinstance(slots, dict):
            slots = {}
        scope_obj, _scope_source = version_scope(r, v, _scope_snapshots)
        # B1（2026-11-20 外部对抗审查）：适用范围状态从实际数据派生（scope_json +
        # 生效版本 slots + tags + 平台内置来源），不信任 scope_meta/scope_required 等
        # 入口标记；发布门禁/manifest/规则卡共用 rule.derive_rule_scope 唯一口径。
        meta = _scope_meta(scope_obj, slots, rule=r)
        kind = _source_kind(r.get("source"))
        _scope_tags = _scope_tag_tokens(scope_obj, slots)
        _applicable_when = _applicability_tokens(scope_obj, slots)
        _tags_only = bool(meta.get("tags_only"))

        # A–G 大类路由（freeze_all 是显式全量，不受大类裁剪）
        if not _freeze_all:
            _cat_ok, _cat_reason = _audit_category_gate(case, r)
            if not _cat_ok:
                _gate_routed_out(gate, r, kind, _cat_reason)
                continue

        # 词典型依赖：决策表版本 / 术语确认状态；任一来源同一门禁
        kind, used_sources, failures, _term_gate_part = _source_gate(
            r, slots, scope_obj, tables, term_idx)
        _merge_term_gate(_term_gate_part)
        if failures:
            _gate_block(gate, r, kind, failures)
            for f in failures:
                src = f.get("source")
                if src in inventory:
                    inventory[src]["blocked"] += 1
            continue
        inventory[kind]["used"] += 1
        for _src in used_sources:
            if _src != kind and _src in inventory:
                inventory[_src]["used"] += 1

        # B1（2026-11-20 外部对抗审查）：适用范围必须从实际数据派生为已声明才进入清单。
        #   - 数据声明 / tags-only / 平台内置来源（platform_scope）→ 正常；
        #   - 历史批准规则（升级前已 published）若显式带 legacy_scope_missing=True 标记：
        #     默认仍 **routed_out(scope_missing_legacy)**；只有空间显式 opt-in
        #     （RULEPROOF_LEGACY_SCOPE_OPT_IN 白名单 或 workspace.settings_json
        #     .legacy_scope_opt_in=true）才按历史「项目级单条」口径消费，
        #     并在 gate.legacy_scope_consumed 里留痕；
        #   - 其余无任何适用范围声明的规则 → **不再消费**：记 routed_out scope_missing +
        #     gate.legacy_scope_missing 提示，清单继续冻结其它规则（单条规则不炸整个审核）。
        _legacy_marked = scope_obj.get("legacy_scope_missing") is True
        _legacy_opt_in = _workspace_legacy_scope_opt_in(workspace)
        if not meta.get("declared") and not (_legacy_marked and _legacy_opt_in):
            _legacy_reason = ("scope_missing_legacy" if _legacy_marked
                              else "scope_missing")
            _gate_routed_out(gate, r, kind, _legacy_reason)
            gate.setdefault("legacy_scope_missing", []).append({
                "rule_id": r.get("id"), "code": r.get("code"), "name": r.get("name"),
                "source": kind, "scope_status": meta.get("status") or "missing",
                "reason": _legacy_reason,
                "workspace_id": str(workspace or ""),
                "opt_in": bool(_legacy_opt_in),
                "suggested_types": list(meta.get("suggested_types") or []),
                "hint": ((meta.get("legacy_hint") or "") +
                         ("；历史批准规则默认不消费（适用性无法证明）；需空间显式 "
                          "legacy_scope_opt_in 或人工补齐 applicable_types 并重新发布"
                          if _legacy_marked else
                          "；历史规则需人工补齐 applicable_types 并重新发布后才进入审核清单")),
            })
            continue
        if _legacy_marked and not meta.get("declared"):
            meta = {**meta, "declared": True, "missing": False, "status": "legacy",
                    "legacy_marked": True}
            gate.setdefault("legacy_scope_consumed", []).append({
                "rule_id": r.get("id"), "code": r.get("code"), "name": r.get("name"),
                "source": kind, "scope_status": "legacy",
                "workspace_id": str(workspace or ""),
                "opt_in": "workspace.legacy_scope_opt_in",
                "note": "历史批准规则（显式 legacy 标记 + 空间 opt-in）：按项目级单条口径"
                        "继续执行，请尽快补齐适用范围后重新发布",
            })

        # T07/T06：迁移脚本写入的「自动推断、待人工确认」scope → 只进可选规则池。
        # 依据：外部评审 F09 要求“自动推断/待人工”不得直接混入 output manifest；
        # 人工确认（去掉 scope_inferred 标记或 status=confirmed）后才参与自动路由。
        _inferred_pending = _scope_inferred_pending(scope_obj)
        if _inferred_pending:
            _gate_routed_optional(gate, r, kind, "scope_inferred_pending_confirmation",
                                  object_id="", detail={
                                      "scope_status": meta.get("status") or "",
                                      "inferred": _inferred_pending,
                                      "suggested_types": list(meta.get("suggested_types") or []),
                                      "note": "自动推断的适用范围待人工确认：确认前不进入生产冻结"
                                              "清单（可被路由器显式选取）"})
            continue

        point_route = _rule_point(r, scope_obj, lib)
        _scope_types = [str(x) for x in (meta.get("route_types") or []) if str(x).strip()]
        _business = [str(x) for x in (meta.get("business_scope") or []) if str(x).strip()]
        _declared = bool(meta.get("declared"))
        # T05：显式工作空间全量规则在清单里显式留痕（不静默全量；审计/报告可追溯原因）
        if _declared and meta.get("workspace_wide"):
            gate.setdefault("workspace_wide_rules", []).append({
                "rule_id": r.get("id"), "code": r.get("code"), "name": r.get("name"),
                "source": kind,
                "reason": str(meta.get("workspace_wide_reason") or "")[:200],
                "note": "显式工作空间全量声明（发布门禁要求 workspace_wide + reason）；"
                        "本次按全部被审对象路由，可在发布审计中追溯",
            })

        # 对象路由：显式类型 > 业务范围 > 触发标签（tags-only）> 无 scope（项目级单条）
        # V02：allowed=规则作用域允许的对象全集（硬边界）；selected=本次实际冻结的对象。
        # 未被 allowed 命中的对象（如附件 B）不会进入 items，执行守卫也会硬拒。
        _allowed = []
        _selected = []
        _audit_type_blocked = False
        _optional_type_blocked = False
        _business_resolved = False
        _scope_kind = "freeze_all" if _freeze_all else (
            "case" if not _declared else ("tags" if _tags_only else "routed"))
        if _freeze_all:
            _allowed = [x["object"] for x in obj_meta]
            _selected = list(_allowed)
        elif meta.get("platform_scope") or meta.get("legacy_marked"):
            # 平台内置来源（platform_scope）/显式 legacy 标记的历史规则：保持历史
            # 「项目级单条」口径（不按对象放大；freeze_all 才逐对象全量）
            _selected = [obj_meta[0]["object"]] if obj_meta else []
            _allowed = list(_selected)
            _scope_kind = "case"
            if _selected:
                gate["case_level"].append({
                    "rule_id": r.get("id"), "code": r.get("code"),
                    "name": r.get("name"), "source": kind,
                    "reason": ("platform_scope" if meta.get("platform_scope")
                               else "legacy_scope"),
                    "object_id": _selected[0].get("object_id"),
                    "note": ("平台级规则（内置来源），按项目级单条冻结；freeze_all 才逐对象全量"
                             if meta.get("platform_scope") else
                             "历史批准规则（显式 legacy 标记），按项目级单条冻结；"
                             "请补齐适用范围后重新发布"),
                })
        elif not _declared:
            # 无 scope 不得默认全量：项目级只冻结 1 条，显式 freeze_all 才逐对象展开。
            # 项目级口径下 allowed 只能等于本次冻结对象（没有声明可放大的作用域）。
            _selected = [obj_meta[0]["object"]] if obj_meta else []
            _allowed = list(_selected)
            if _selected:
                gate["case_level"].append({
                    "rule_id": r.get("id"), "code": r.get("code"),
                    "name": r.get("name"), "source": kind,
                    "reason": "scope_missing", "object_id": _selected[0].get("object_id"),
                    "note": "未声明适用范围，按项目级单条冻结；freeze_all 才逐对象全量",
                })
        else:
            _case_hint = str(case.get("document_type") or case.get("audit_type") or "").strip()
            _business_resolved = bool(_match_document_type(lib, _case_hint)) \
                or any(x["route"].get("resolved") for x in obj_meta)
            for _om in obj_meta:
                _o, _oroute = _om["object"], _om["route"]
                _matched = False
                if _tags_only:
                    # 标签是检索/路由条件：对象上下文（文件名/类型/库类型）命中任一标签才进入清单
                    _hay = str(_oroute.get("haystack") or "").lower()
                    _matched = any(str(t).strip().lower() in _hay for t in _scope_tags)
                    _scope_kind = "tags"
                elif _scope_types:
                    _matched = any(_type_matches(t, _o, _oroute) for t in _scope_types)
                    _scope_kind = "explicit_types"
                elif _business:
                    # 有案例/库类型可解析时才用业务范围裁剪；解析不了保持历史口径（不伪造路由）
                    _matched = True if not _business_resolved else any(
                        str(b).strip().lower() in (_oroute.get("haystack") or "")
                        for b in _business if str(b).strip())
                    _scope_kind = "business"
                else:
                    _matched = True
                if not _matched:
                    continue
                # 作用域命中 = allowed（允许被本规则审核）；审核类型不匹配只影响 selected。
                _allowed.append(_o)
                # 69 审核类型路由：规则映射点位所属类型必须在对象路由类型内。
                # T06：命中「未触发的 conditional 类型」→ 可选规则池（不是静默丢规则）。
                _ptype = str(point_route.get("audit_type") or "")
                if _ptype and _oroute.get("audit_types") \
                        and _ptype not in _oroute["audit_types"]:
                    _audit_type_blocked = True
                    if _ptype in (_oroute.get("optional_audit_types") or []):
                        _optional_type_blocked = True
                        _gate_optional(gate, r, kind,
                                       reason="conditional_type_untriggered",
                                       object_id=str(_o.get("object_id") or ""),
                                       detail={
                                           "audit_type": _ptype,
                                           "required_features": (_oroute.get(
                                               "optional_audit_features") or {}).get(_ptype) or [],
                                           "doc_type": _oroute.get("library_type") or "",
                                           "note": "该审核类型属文档类型的条件类型，正文未命中触发特征；"
                                                   "规则进入可选规则池，不进入冻结清单"})
                    continue
                _selected.append(_o)
            if _tags_only:
                _scope_kind = "tags"
            elif _scope_types:
                _scope_kind = "explicit_types"
            elif _business:
                _scope_kind = "business"
        if not _selected:
            if not _declared:
                _reason = "no_objects"
            elif _tags_only:
                _reason = "scope_tags_mismatch"
            elif _optional_type_blocked:
                _reason = "conditional_type_untriggered"
            elif _audit_type_blocked:
                _reason = "audit_type_not_routed"
            elif _scope_types:
                _reason = "route_type_mismatch"
            elif _business:
                _reason = "business_scope_mismatch" if _business_resolved else "route_unresolved"
            else:
                _reason = "audit_type_not_routed"
            _gate_routed_out(gate, r, kind, _reason,
                             object_count=len(_allowed) if _allowed else 0)
            continue

        _raw_types = _as_tokens(slots.get("applicable_types"))
        ir = _ir.compile_rule(slots, r.get("category") or "", r.get("rclass") or "",
                              r.get("name") or "")
        rid = {"rule_id": r["id"], "code": r.get("code"), "version": v.get("version") or "v0.1",
               "name": r.get("name"), "nature": ir.get("nature"),
               "requirement": ir.get("predicate"),
               "source": r.get("source") or "", "source_kind": kind,
               "scope_status": meta.get("status") or "missing",
               "scope_kind": _scope_kind,
               "publishable": ir.get("publishable")}
        _steps = [
            {"id": "D1", "name": "适用性", "depends_on": [],
             "input": ["doc_type", "scope", "trigger"], "method": "scope_match"},
            {"id": "D2", "name": "业务要求", "depends_on": ["D1"],
             "input": ["rule_version", "requirement"], "method": "rule_lookup"},
            {"id": "D3", "name": "证据绑定", "depends_on": ["D1"],
             "input": ["required_evidence", "document", "evidence_scope"], "method": "evidence_bind"},
            {"id": "D4", "name": "子要求判断", "depends_on": ["D2", "D3"],
             "input": ["criteria", "evidence", "aggregation"], "method": ir.get("evaluation_kind") or "semantic"},
            {"id": "D5", "name": "组合结论", "depends_on": ["D4"],
             "input": ["combination", "D4", "fallback"], "method": "combine"},
        ]
        # ---------------- V02 对象绑定（冻结时一次算好，执行期只读）
        _sub_reqs = (slots.get("subrequirements") or slots.get("criteria_list") or [])
        _sub_binding_list = []
        for _si, _sub in enumerate(_sub_reqs if isinstance(_sub_reqs, list) else []):
            if isinstance(_sub, dict):
                _sub_binding_list.append({
                    "index": _si,
                    "id": str(_sub.get("id") or f"sub-{_si + 1}"),
                    "metric": str(_sub.get("metric") or _sub.get("object") or ""),
                    "required_evidence": str(_sub.get("required_evidence")
                                              or _sub.get("evidence_required") or ""),
                    "unit": str(_sub.get("unit") or ""),
                })
            else:
                _sub_binding_list.append({"index": _si, "id": f"sub-{_si + 1}",
                                          "metric": str(_sub or ""),
                                          "required_evidence": "", "unit": ""})
        _scope_predicate = {
            "declared": _declared,
            "status": meta.get("status") or "missing",
            "kind": _scope_kind,
            "route_types": _scope_types,
            "business_scope": _business,
            "applicable_when": _applicable_when,
            "scope_tags": _scope_tags,
            "tags_only": bool(_tags_only),
            "business_resolved": bool(_business_resolved),
            "route_unresolved_allowed": bool(_business and not _business_resolved),
            "case": {"document_type": str(case.get("document_type") or ""),
                     "audit_type": str(case.get("audit_type") or ""),
                     "audit_category": str(case.get("audit_category") or "")},
            "audit_type": point_route.get("audit_type") or "",
            "audit_category": point_route.get("audit_category") or "",
            "point_id": point_route.get("point_id") or "",
            # T-136 C-1：作用域读取来源显式落快照（version_snapshot=版本级；
            # rule_legacy=旧数据双读回退），报告/审计可据此解释“审核对象为何这样取”。
            "scope_source": _scope_source,
            "policy": ("freeze_all" if _freeze_all else
                       "case_level_single" if not _declared else
                       "tags" if _tags_only else "scope_route"),
        }
        _subject_value = str(slots.get("subject") or slots.get("object")
                             or scope_obj.get("subject") or "").strip()
        _subject_source = ("rule_slots.subject" if slots.get("subject") else
                           "rule_slots.object" if slots.get("object") else
                           "scope.subject" if scope_obj.get("subject") else "unspecified")
        _subject_binding = {"value": _subject_value, "source": _subject_source,
                            "rule_category": str(r.get("category") or ""),
                            "rule_class": str(r.get("rclass") or ""),
                            "audit_type": point_route.get("audit_type") or "",
                            "point_id": point_route.get("point_id") or ""}
        _relationship_type = str(slots.get("relationship") or slots.get("relation")
                                 or scope_obj.get("relationship") or "").strip()
        _relationship_source = ("rule_slots.relationship" if slots.get("relationship")
                                else "rule_slots.relation" if slots.get("relation")
                                else "scope.relationship" if scope_obj.get("relationship")
                                else "case_document_role")
        _relationship_binding = {"type": _relationship_type or "audited_document",
                                 "source": _relationship_source,
                                 "case_id": str(case_id or ""),
                                 "multi_document": len(objects) > 1}
        _frozen_rule_versions.append({
            "rule_id": r["id"], "code": r.get("code") or "",
            "version": v.get("version") or "v0.1",
            "version_id": str(v.get("id") or ""),
            "content_sha": _rule_version_content_sha(v),
        })
        _binding_base = {
            "schema": BINDING_SCHEMA,
            "rule_version": {"rule_id": r["id"], "code": r.get("code") or "",
                             "version": v.get("version") or "v0.1",
                             "version_id": str(v.get("id") or ""),
                             "content_sha": _rule_version_content_sha(v)},
            "subject": _subject_binding,
            "relationship": _relationship_binding,
            "subrequirements": _sub_binding_list,
            "subrequirement_count": len(_sub_binding_list),
            "scope_predicate": _scope_predicate,
            "decision_policy": str(slots.get("decision_policy") or "conflict"),
            "allowed_object_ids": [str(x.get("object_id") or "") for x in _allowed],
            "selected_object_ids": [str(x.get("object_id") or "") for x in _selected],
            "selected_subset_of_allowed": True,
            "closure_ref": {"schema": CLOSURE_SCHEMA,
                            "lookup": "sys_config " + CLOSURE_PREFIX + "<manifest_id>",
                            "frozen": True},
        }
        _rule_bindings.append({**_binding_base,
                               "rule_id": r["id"],
                               "rule_code": r.get("code") or "",
                               "priority": slots.get("priority"),
                               "combination": ir.get("combination") or "all"})
        _rule_items = []
        _item_binding = _item_ontology_binding(_onto_binding, slots, scope_obj, tables)
        for o in _selected:
            _oroute = next((x["route"] for x in obj_meta
                            if x["object"].get("object_id") == o.get("object_id")), {})
            _audit_route = {
                "scope_kind": _scope_kind,
                "scope_status": meta.get("status") or "missing",
                "declared": _declared,
                "route_types": _scope_types,
                "business_scope": _business,
                "scope_tags": _scope_tags,
                "applicable_when": _applicable_when,
                "tags_only": bool(_tags_only),
                "business_resolved": bool(_business_resolved),
                # 冻结时的对象路由上下文：D1 执行期只读该快照，不再查实时本体/库
                "object_haystack": str(_oroute.get("haystack") or ""),
                "case_audit_category": str(case.get("audit_category") or ""),
                "case_document_type": str(case.get("document_type") or ""),
                "case_audit_type": str(case.get("audit_type") or ""),
                "audit_category": point_route.get("audit_category") or "",
                "audit_category_name": point_route.get("audit_category_name") or "",
                "audit_type": point_route.get("audit_type") or "",
                "audit_type_name": point_route.get("audit_type_name") or "",
                "point_id": point_route.get("point_id") or "",
                "point_name": point_route.get("point_name") or "",
                "object_library_type": _oroute.get("library_type") or "",
                "object_audit_types": _oroute.get("audit_types") or [],
                "object_audit_categories": _oroute.get("audit_categories") or [],
            }
            # T-161：给 item 冻结 zone（确定性区/证据区；影子空间不在点位级分配）。
            # 只加字段，执行路径不读；开关关闭时不写，item 与改动前一致。
            _zone_extra = {}
            if _zone_tagging:
                _zone_info = _audit_zone.zone_tag(
                    point_method=point_route.get("point_method") or "",
                    point_id=point_route.get("point_id") or "",
                    execution_kind=ir.get("evaluation_kind") or "")
                _audit_route = {**_audit_route,
                                "point_method": _zone_info.get("point_method") or ""}
                _zone_extra = {"zone": _zone_info.get("zone") or _audit_zone.ZONE_UNKNOWN,
                               "zone_source": _zone_info.get("zone_source") or "unknown"}
            _rule_items.append({
                **rid, "object_id": o["object_id"], "filename": o["filename"],
                "doc_type": o["doc_type"], "audit_route": _audit_route,
                "source_gate": {"ok": True, "gate": _GATE_VERSION,
                                "checks": list(_GATE_CHECKS),
                                "sources": sorted(used_sources)},
                "evidence_required": ir.get("evidence_required") or "",
                "on_insufficient": ir.get("on_insufficient") or "abstain",
                # 冻结规则的可执行槽位，执行时不得再读 latest_version
                "slots": slots,
                "applicable_types": _raw_types,
                # 冻结的适用条件/标签：D1 执行期只读快照，冻结后的实时变更不生效
                "applicable_when": _applicable_when,
                "scope_tags": _scope_tags,
                "scope_meta": {"status": meta.get("status") or "missing",
                               "declared": _declared,
                               "tags_only": bool(_tags_only),
                               "route_types": _scope_types,
                               "business_scope": _business,
                               "business_resolved": bool(_business_resolved)},
                "decision_tables": _decision_snapshots(
                    slots.get("decision_tables") or slots.get("decision_table") or []),
                "execution_hints": __import__('app.services.execution_plan',
                                              fromlist=['derive']).derive(slots),
                "decision_policy": str(slots.get("decision_policy") or "conflict"),
                "subrequirements": slots.get("subrequirements") or slots.get("criteria_list") or [],
                "combination": ir.get("combination") or "all",
                "ontology_binding": _item_binding,
                # V02：每个 item 绑定 (rule_version, subject/object/relationship,
                # subrequirement, scope_predicate)；allowed 是硬边界，selected 为本条对象
                "binding": {
                    **_binding_base,
                    "object": {"object_id": o["object_id"], "filename": o["filename"],
                               "doc_type": o["doc_type"], "role": "被审对象",
                               "content_sha256": _doc_content.get(
                                   str(o.get("object_id") or ""), "")},
                    "object_relationship": {
                        "type": _relationship_binding["type"],
                        "role": "被审对象",
                        "related_object_ids": [
                            str(x.get("object_id") or "") for x in objects
                            if str(x.get("object_id") or "") != str(o.get("object_id") or "")],
                    },
                    "selected_object_id": str(o["object_id"]),
                },
                "steps": _steps,
                **_zone_extra})
        if not _rule_items:
            continue
        rules.append(rid)
        items.extend(_rule_items)
        inventory[kind]["in_manifest"] += 1

    # T06 每文档路由预算（默认 20；=0 关闭）：选入超预算 → 其余进可选规则池。
    # 放在规则循环之后、hash/绑定汇总之前，保证 items/rules/binding/库存同源。
    try:
        _doc_budget = route_doc_budget()
    except Exception:
        _doc_budget = 0
    if _doc_budget > 0:
        items, rules, _rule_bindings, _frozen_rule_versions = _apply_route_budget(
            items=items, rules=rules, rule_bindings=_rule_bindings,
            frozen_rule_versions=_frozen_rule_versions, inventory=inventory,
            gate=gate, route_texts=_route_texts, budget=_doc_budget)

    # T-161：冻结清单的三区计数（只做标记结果汇总，不参与 gate 判定）
    _zone_counts = _audit_zone.count_item_zones(items) if _zone_tagging else {}

    gate["included_rules"] = len(rules)
    gate["included_items"] = len(items)
    # V02：allowed/selected 不变量（selected ⊆ allowed）；违反 = 冻结门禁不通过。
    _binding_summary = _binding_closure_summary(_rule_bindings)
    gate["binding"] = {"ok": _binding_summary["selected_subset_of_allowed"],
                       "schema": BINDING_SCHEMA,
                       "rules": _binding_summary["rule_count"],
                       "allowed_total": _binding_summary["allowed_total"],
                       "selected_total": _binding_summary["selected_total"],
                       "selected_subset_of_allowed":
                           _binding_summary["selected_subset_of_allowed"],
                       "violations": _binding_summary["violations"],
                       "sha": _binding_summary["sha"]}
    if _binding_summary["violations"]:
        for _viol in _binding_summary["violations"]:
            gate["blocked"].append({"rule_id": _viol["rule_id"],
                                    "code": _viol["rule_code"],
                                    "source": "binding",
                                    "reasons": [{"source": "binding",
                                                 "reason": "selected_outside_allowed",
                                                 "object_ids": _viol["object_ids"]}]})
    gate["ok"] = not gate["blocked"] and bool(gate["binding"]["ok"])
    # L80 / P0-C：冻结 gate 附路由三列（仅开关=1；=0 时 gate 逐字段不变）。
    # rules_mode：空间/调用方显式规则集收窄 = mapped；未收窄 = all。
    if _adj_ledger.enabled():
        try:
            _adj_mode = ("mapped"
                         if (_explicit_codes is not None or bool(_allow_codes)) else "all")
            gate.setdefault("routing", {})["adjudication_route"] = \
                _adj_ledger.route_counts(gate=gate, items=items, rules_mode=_adj_mode)
            gate["routing"]["rule_scope"] = {
                "mode": _adj_mode,
                "explicit_codes": len(_explicit_codes or []),
                "workspace_codes": len(_allow_codes or []),
                "freeze_all": bool(_freeze_all),
            }
        except Exception:  # 铁律 2：路由计数失败不改变冻结/判定
            logging.getLogger(__name__).warning(
                "adjudication_route counts failed（不阻断冻结）", exc_info=True)

    payload = {"case_id": case_id, "objects": objects, "rules": rules, "items": items,
               "ontology_binding": _onto_binding}
    digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
    # V01：冻结闭包（文件内容哈希/解析产物/OCR/业务参考时间/外部结果/单位/冲突优先级）
    # 不进入 manifest hash（闭包含时间戳），单独落 sys_config 供执行守卫校验。
    try:
        _closure, _artifacts = _build_closure(
            case_id=case_id, tenant_id=tenant, workspace_id=workspace, manifest_id=mid,
            docs=docs, reference=_reference,
            external_results=(_external_validated.get("items") and
                              {x["key"]: {"value": x["value"], "source": x["source"],
                                           "fetched_at": x["fetched_at"]}
                               for x in _external_validated["items"]}) or {},
            terms=_onto_binding.get("terms") or [], items=items,
            rule_versions=_frozen_rule_versions, binding=_binding_summary, gate=gate,
            ontology_binding=_onto_binding)
        _closure["files"] = _file_closure(docs, content_cache=_doc_content)
        _closure["digest"] = _closure_digest(_closure)
    except Exception as _ce:
        logging.getLogger(__name__).warning("manifest closure build failed: %s", _ce)
        _closure = {"schema": CLOSURE_SCHEMA, "manifest_id": mid, "case_id": case_id,
                    "built_at": datetime.now().isoformat(timespec="seconds"),
                    "degraded": True, "errors": {"closure": f"{type(_ce).__name__}: {str(_ce)[:200]}"},
                    "closure_required": True,
                    "business_reference": _reference, "binding": _binding_summary,
                    "note": "闭包构建失败（显式降级，不假装完整性已校验）"}
        _closure["digest"] = _closure_digest(_closure)
        _artifacts = {}
    c = db.connect()
    try:
        c.execute("INSERT INTO audit_manifest(id,case_id,tenant_id,workspace_id,source,status,"
                  "objects_json,rules_json,items_json,hash,created_at,created_by) "
                  "VALUES(?,?,?,?,?,'frozen',?,?,?,?,?,?)",
                  (mid, case_id, tenant, workspace, source,
                   json.dumps(objects, ensure_ascii=False), json.dumps(rules, ensure_ascii=False),
                   json.dumps(items, ensure_ascii=False), digest, db.now(), actor or ""))
        c.commit()
    finally:
        c.close()
    # 完整本体/术语快照（含实体与关系）落库：D4 只读 item 轻量绑定，
    # 报告/审计可按 manifest_id 追溯冻结时的完整快照与分段哈希。
    try:
        _save_ontology_snapshot(mid, _onto_binding)
    except Exception:
        logging.getLogger(__name__).debug("ontology snapshot persist skipped", exc_info=True)
    # V01：冻结闭包与解析产物快照落库（执行前 execution_guard 校验）
    # A6（2026-11-21）：先写「新清单必须有闭包」标记，再落闭包。标记独立于闭包：
    # 闭包落库失败（persist_error）时守卫仍可识别新清单 → 拒绝 legacy 放行、强制重冻。
    try:
        from . import sysconfig as _sc_req
        _sc_req.set_many({CLOSURE_REQUIRED_PREFIX + str(mid): "1"})
    except Exception as _re:
        logging.getLogger(__name__).warning(
            "manifest closure_required mark failed mid=%s: %s", mid, _re)
    try:
        _save_closure(mid, _closure, _artifacts)
    except Exception as _se:
        logging.getLogger(__name__).warning("manifest closure persist failed: %s", _se)
        try:
            _closure["persist_error"] = f"{type(_se).__name__}: {str(_se)[:200]}"
        except Exception as _e:  # 静默兜底改为留痕（反补丁治理）
            logging.getLogger(__name__).debug("silent fallback: %s", _e)
    try:
        _ctx.set_audit_mode(_saved_mode.get("mode") or "", _saved_mode.get("doc_type") or "")
    except Exception as _e:  # 静默兜底改为留痕（反补丁治理）
        logging.getLogger(__name__).debug("silent fallback: %s", _e)
    _blocked_codes = ",".join(str(x.get("code") or "") for x in gate["blocked"][:20])
    _case_codes = ",".join(str(x.get("code") or "") for x in gate["case_level"][:20])
    _closure_dg = str(_closure.get("digest") or "")
    R.audit_logs.log(actor=actor or "system", action="manifest.frozen", object=mid,
                     after=f"objects={len(objects)} rules={len(rules)} items={len(items)} "
                           f"gate={_GATE_VERSION} blocked={len(gate['blocked'])}"
                           f"{('[' + _blocked_codes + ']') if _blocked_codes else ''} "
                           f"routed_out={len(gate['routed_out'])} "
                           f"case_level={len(gate['case_level'])}"
                           f"{('[' + _case_codes + ('…' if len(gate['case_level']) > 20 else '') + ']') if _case_codes else ''} "
                           f"closure={_closure_dg[:12]} binding={gate['binding'].get('sha')}")
    try:
        R.audit_logs.log(actor=actor or "system", action="manifest.ontology_bound", object=mid,
                         after=f"sha={_onto_binding.get('sha')} "
                               f"hashes={_onto_binding.get('hashes')} "
                               f"terms={len(_onto_binding.get('terms') or [])} "
                               f"entities={len(_onto_binding.get('entities') or [])} "
                               f"relations={len(_onto_binding.get('relations') or [])} "
                               f"aliases={sum(len(v) for v in (_onto_binding.get('aliases') or {}).values())}")
    except Exception:
        logging.getLogger(__name__).debug("ontology binding audit skipped", exc_info=True)
    # V01/V02 显式审计：闭包内容标识 + 绑定边界（报告/测试可按 object=manifest_id 取）
    try:
        import json as _jlog
        R.audit_logs.log(
            actor=actor or "system", action="manifest.closure_frozen", object=mid,
            after=_jlog.dumps({
                "closure_schema": CLOSURE_SCHEMA,
                "closure_digest": _closure_dg,
                "degraded": bool(_closure.get("degraded")),
                "files_sha": (_closure.get("files") or {}).get("sha"),
                "files_count": (_closure.get("files") or {}).get("count"),
                "readable_files": (_closure.get("files") or {}).get("readable_count"),
                "parsed_sha": (_closure.get("parsed_artifacts") or {}).get("sha"),
                "parsed_count": (_closure.get("parsed_artifacts") or {}).get("parsed_count"),
                "parser_ocr_sha": (_closure.get("parser_ocr") or {}).get("sha"),
                "reference_time": (_closure.get("business_reference") or {}).get("reference_time"),
                "timezone": (_closure.get("business_reference") or {}).get("timezone"),
                "business_date": (_closure.get("business_reference") or {}).get("business_date"),
                "external_results": (_closure.get("external_results") or {}).get("count"),
                "external_sha": (_closure.get("external_results") or {}).get("sha"),
                "unit_dictionary_sha": (_closure.get("unit_dictionary") or {}).get("sha"),
                "conflict_priority_sha": (_closure.get("rule_conflict_priority") or {}).get("sha"),
                "rule_versions": len(_closure.get("rule_versions") or []),
            }, ensure_ascii=False, default=str))
    except Exception:
        logging.getLogger(__name__).debug("closure audit skipped", exc_info=True)
    try:
        import json as _jlog
        R.audit_logs.log(
            actor=actor or "system", action="manifest.bound", object=mid,
            after=_jlog.dumps({
                "binding_schema": BINDING_SCHEMA,
                "binding_sha": _binding_summary.get("sha"),
                "rule_count": _binding_summary.get("rule_count"),
                "allowed_total": _binding_summary.get("allowed_total"),
                "selected_total": _binding_summary.get("selected_total"),
                "selected_subset_of_allowed": _binding_summary.get("selected_subset_of_allowed"),
                "violations": _binding_summary.get("violations"),
                "routes": [{"code": b.get("rule_code"),
                            "allowed": b.get("allowed_object_ids"),
                            "selected": b.get("selected_object_ids")}
                           for b in _rule_bindings[:100]],
            }, ensure_ascii=False, default=str))
    except Exception:
        logging.getLogger(__name__).debug("binding audit skipped", exc_info=True)
    # L27 Phase0 Task 0.2（2026-11-23，0 LLM）：gate.routing 落「被过滤规则码 + 原因」精确清单。
    # 旧口径 gate.routed_out 只有明细计数（CT507 §4.3：233 条无法分清路由/判 na/判 pass），
    # 此处按 rule_code 去重落盘，并给出规范化原因桶（不改变任何路由/冻结判定语义）。
    attach_routing_routed_out(gate)
    return {"ok": True, "manifest_id": mid, "hash": digest, "objects": len(objects),
            "rules": len(rules), "items": len(items), "status": "frozen",
            "ontology_binding": {"sha": _onto_binding.get("sha"),
                                 "hashes": _onto_binding.get("hashes") or {},
                                 "sources": _onto_binding.get("sources") or {},
                                 "counts": {"aliases": sum(len(v) for v in
                                                           (_onto_binding.get("aliases") or {}).values()),
                                            "terms": len(_onto_binding.get("terms") or []),
                                            "entities": len(_onto_binding.get("entities") or []),
                                            "relations": len(_onto_binding.get("relations") or [])}},
            "closure": closure_summary(_closure),
            "binding": {"schema": BINDING_SCHEMA,
                        "sha": _binding_summary.get("sha"),
                        "rule_count": _binding_summary.get("rule_count"),
                        "allowed_total": _binding_summary.get("allowed_total"),
                        "selected_total": _binding_summary.get("selected_total"),
                        "selected_subset_of_allowed":
                            _binding_summary.get("selected_subset_of_allowed")},
            "term_gate": gate["term_gate"],
            # T-161：三区分区计数（item 级；开关关闭时为空 dict，与改动前一致）
            "zones": _zone_counts,
            "freeze_all": bool(_freeze_all), "gate": gate}


# ================================================================ V01/V02 执行期守卫
# 口径：执行前只读冻结闭包核对「这次执行读到的内容 = 冻结时读到的内容」。
# - 旧清单（无闭包）legacy 放行（完整性显式标注不可证明），不误伤历史 run；
# - 新清单只要出现内容漂移/绑定越界 → ok=False，调用方必须 0 执行并写审计；
# - 守卫本身不改任何业务数据、不重解析成新事实；解析器/OCR 配置漂移也只阻断。
def _manifest_row(manifest_id: str) -> dict:
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM audit_manifest WHERE id=?",
                            (str(manifest_id or ""),)).fetchone()
        return dict(row) if row else {}
    except Exception:
        return {}


def _manifest_items(row: dict) -> list:
    try:
        items = json.loads((row or {}).get("items_json") or "[]")
    except Exception:
        items = []
    return items if isinstance(items, list) else []


def _live_docs(case_id: str) -> dict:
    try:
        docs = R.cases.documents(case_id) or []
    except Exception:
        docs = []
    return {str(d.get("id") or ""): d for d in docs if d.get("id")}


def _check_files(closure: dict, live_docs: dict) -> dict:
    files = (closure.get("files") or {}).get("items") or []
    changed, missing, unverifiable = [], [], []
    for f in files:
        oid = str(f.get("document_id") or "")
        frozen_sha = str(f.get("sha256") or "")
        doc = (live_docs or {}).get(oid)
        if not doc:
            missing.append({"document_id": oid, "filename": f.get("filename"),
                            "reason": "document_missing"})
            continue
        live_sha, live_size, err = _file_content_digest(str(doc.get("path") or ""))
        if not frozen_sha:
            unverifiable.append({"document_id": oid, "reason": "frozen_hash_unavailable",
                                 "frozen_error": f.get("read_error") or ""})
            continue
        if not live_sha:
            missing.append({"document_id": oid, "filename": f.get("filename"),
                            "reason": "live_read_error", "error": err,
                            "frozen_sha256": frozen_sha})
            continue
        if live_sha != frozen_sha:
            changed.append({"document_id": oid, "filename": f.get("filename"),
                            "frozen_sha256": frozen_sha, "live_sha256": live_sha,
                            "frozen_size": f.get("size"), "live_size": live_size,
                            "recorded_hash_was": f.get("recorded_hash") or ""})
    issues = []
    if changed:
        issues.append({"code": "file_content_changed",
                       "detail": "同 document_id 的文件原始字节 sha256 与冻结时不一致；"
                                 "不得静默使用新文档执行本轮审核",
                       "documents": changed})
    if missing:
        issues.append({"code": "file_missing",
                       "detail": "冻结时存在的文件在执行时不可读/不存在，无法证明执行的是同一内容",
                       "documents": missing})
    return {"name": "files_content_sha256", "ok": not changed and not missing,
            "checked": len(files), "changed": changed, "missing": missing,
            "unverifiable": unverifiable, "issues": issues,
            "note": "document_id 不是内容标识；只比较原始文件字节 sha256"}


def _check_parsed_artifacts(closure: dict) -> dict:
    """冻结的解析产物指纹（P0 准确率修复）：执行期 D2/D3 会用当前文件重新解析，
    守卫必须能证明「重解析读到的是冻结时那一份判定输入」。

    只校验闭包自身携带的指纹是否完整、可复算（不重解析、不产生新事实）：
    - 旧清单/旧闭包无 parsed_artifacts → 无法证明，显式 degraded 放行（不判 fail，
      否则历史 run 全炸）；
    - 有 parsed_artifacts 但 sha 缺失/为空 → 硬阻断（parsed_artifacts_sha_missing）；
    - count 声明值 ≠ 实际 artifact 行数（items 条数）→ 硬阻断
      （parsed_artifacts_count_mismatch）；
    - sha 非空但与 items 重新计算的摘要不一致（闭包被改写/指纹不可复算）→ 硬阻断
      （parsed_artifacts_sha_mismatch）。
    """
    parsed = closure.get("parsed_artifacts")
    if not isinstance(parsed, dict) or not parsed:
        return {"name": "parsed_artifacts_sha256", "ok": True, "skipped": True,
                "degraded": True, "count": 0, "parsed_sha": "",
                "note": "旧清单无解析产物指纹（parsed_artifacts 缺失），本次无法证明"
                        "执行期重解析读到的是冻结判定输入；显式降级放行，不判 fail",
                "issues": []}
    items = parsed.get("items") if isinstance(parsed.get("items"), list) else []
    declared = parsed.get("count")
    sha = str(parsed.get("sha") or "")
    try:
        declared_n = int(declared)
    except (TypeError, ValueError):
        declared_n = None
    expected_sha = _digest([(str((x or {}).get("document_id") or ""),
                             str((x or {}).get("text_sha256") or ""))
                            for x in items if isinstance(x, dict)])
    issues = []
    if not sha:
        issues.append({"code": "parsed_artifacts_sha_missing",
                       "detail": "冻结闭包声明了 parsed_artifacts 却没有解析产物文本 sha256："
                                 "执行期重解析无法与冻结判定输入对账，本轮不得执行",
                       "frozen_sha": sha, "count": declared})
    elif sha != expected_sha:
        issues.append({"code": "parsed_artifacts_sha_mismatch",
                       "detail": "parsed_artifacts.sha 与闭包内 artifact 行重新计算的摘要不一致："
                                 "解析产物指纹被改写/不可复算，本轮不得执行",
                       "frozen_sha": sha, "expected_sha": expected_sha,
                       "count": declared})
    if declared_n is None or declared_n != len(items):
        issues.append({"code": "parsed_artifacts_count_mismatch",
                       "detail": "parsed_artifacts.count 声明值与实际 artifact 行数不一致："
                                 "解析产物闭包不完整（缺失或多出），本轮不得执行",
                       "declared_count": declared, "actual_count": len(items)})
    degraded = bool(parsed.get("skipped"))
    return {"name": "parsed_artifacts_sha256", "ok": not issues, "checked": len(items),
            "degraded": degraded,
            "parsed_sha": sha, "count": len(items), "declared_count": declared,
            "parsed_count": parsed.get("parsed_count"),
            "expected_sha": expected_sha,
            "note": ("冻结时显式跳过解析产物哈希（RULEPROOF_FREEZE_PARSE=0），"
                     "无法证明判定输入一致" if degraded else
                     "解析产物文本 sha256 闭包自洽可复算；执行期重解析必须与之一致"),
            "issues": issues}


RULE_PARAMS_CHECK = "rule_params_sha256"


def _check_rule_params(closure: dict) -> dict:
    """冻结规则参数（``rule_param`` 生效值）指纹校验（P0 准确率修复：判定不可复现）。

    冻结闭包已记录 ``rule_params.sha``（= ``ruleparam.params_sha()``，仅生效值、不含
    pending），但 D4 执行读的是**活值**（hooks.param_value → ruleparam.value），且
    ``rule_param`` 是独立可修订表、可单独 publish。冻结与执行之间改参数，同一
    manifest_id 重跑会得到不同判定，故把「冻结参数 == 执行期活参数」变成执行前置条件：
    - 闭包无 rule_params / sha 为空（旧清单）→ 无法证明，显式 degraded 放行（不判 fail，
      否则历史 run 全炸）；
    - 有 sha 且与执行期 ``ruleparam.params_sha()`` 一致 → ok=True；
    - 不一致 → ok=False，code=rule_params_changed（带 frozen/live 两个 sha）。
    """
    frozen = closure.get("rule_params")
    if not isinstance(frozen, dict) or not frozen:
        return {"name": RULE_PARAMS_CHECK, "ok": True, "skipped": True,
                "degraded": True, "frozen_sha": "", "live_sha": "", "count": 0,
                "note": "旧清单无参数指纹（rule_params 缺失），不可证明执行期参数"
                        "与冻结时一致；显式降级放行，不判 fail",
                "issues": []}
    frozen_sha = str(frozen.get("sha") or "")
    if not frozen_sha:
        return {"name": RULE_PARAMS_CHECK, "ok": True, "skipped": True,
                "degraded": True, "frozen_sha": "", "live_sha": "",
                "count": frozen.get("count"),
                "note": "旧清单无参数指纹（rule_params.sha 为空），不可证明执行期"
                        "参数与冻结时一致；显式降级放行，不判 fail",
                "issues": []}
    live_sha, error = "", ""
    try:
        from . import ruleparam
        live_sha = str(ruleparam.params_sha() or "")
    except Exception as exc:
        error = f"{type(exc).__name__}: {str(exc)[:160]}"
    if not live_sha:
        return {"name": RULE_PARAMS_CHECK, "ok": True, "skipped": True,
                "degraded": True, "frozen_sha": frozen_sha, "live_sha": "",
                "count": frozen.get("count"), "error": error,
                "note": "执行期无法计算活参数指纹，本次无法证明参数与冻结时一致；"
                        "显式降级放行（错误见 error）",
                "issues": []}
    issues = []
    if live_sha != frozen_sha:
        issues.append({"code": "rule_params_changed",
                       "detail": "规则参数（rule_param 生效值）与冻结时不一致：D4 执行读"
                                 "活值，同一 manifest_id 重跑会得到不同判定，本轮不得执行；"
                                 "须重新冻结生成新清单",
                       "frozen_sha": frozen_sha, "live_sha": live_sha,
                       "count": frozen.get("count")})
    return {"name": RULE_PARAMS_CHECK, "ok": not issues, "skipped": False,
            "degraded": False, "frozen_sha": frozen_sha, "live_sha": live_sha,
            "count": frozen.get("count"),
            "note": "冻结参数指纹与执行期活值一致；冻结后单独 publish 参数将使旧清单"
                    "拒绝执行（须重新冻结）",
            "issues": issues}


def _check_parser_ocr(closure: dict) -> dict:
    frozen = closure.get("parser_ocr") or {}
    if not frozen.get("sha"):
        return {"name": "parser_ocr_fingerprint", "ok": True, "skipped": True,
                "note": "闭包未记录解析器/OCR 指纹（显式降级），本次无法证明解析一致",
                "issues": []}
    current = _parser_ocr_closure()
    changed_modules = {}
    for name, sha in (frozen.get("modules") or {}).items():
        if str(current.get("modules", {}).get(name) or "") != str(sha or ""):
            changed_modules[name] = {"frozen": sha,
                                     "live": current.get("modules", {}).get(name) or ""}
    frozen_ocr = frozen.get("ocr") or {}
    current_ocr = current.get("ocr") or {}
    changed_ocr = {k: {"frozen": frozen_ocr.get(k), "live": current_ocr.get(k)}
                   for k in set(frozen_ocr) | set(current_ocr)
                   if frozen_ocr.get(k) != current_ocr.get(k)}
    issues = []
    if frozen.get("sha") != current.get("sha"):
        issues.append({"code": "parser_ocr_changed",
                       "detail": "解析器模块或 OCR 配置与冻结时不一致：同一文件可能解析出不同文本，"
                                 "本轮不得静默重解析执行",
                       "modules": changed_modules,
                       "ocr": changed_ocr,
                       "frozen_sha": frozen.get("sha"),
                       "live_sha": current.get("sha")})
    return {"name": "parser_ocr_fingerprint", "ok": not issues, "skipped": False,
            "frozen_sha": frozen.get("sha"), "live_sha": current.get("sha"),
            "modules_changed": changed_modules, "ocr_changed": changed_ocr,
            "issues": issues}


def _check_rule_versions(closure: dict) -> dict:
    """冻结规则版本内容不可变：同一 version_id 的 slots/evidence/tests 不得被改写。"""
    frozen_rows = closure.get("rule_versions") or []
    changed, missing = [], []
    for row in frozen_rows:
        vid = str(row.get("version_id") or "")
        frozen_sha = str(row.get("content_sha") or "")
        if not vid or not frozen_sha:
            continue
        try:
            live = R.rule_versions.get(vid) or {}
        except Exception:
            live = {}
        if not live:
            missing.append({"rule_id": row.get("rule_id"), "code": row.get("code"),
                            "version": row.get("version"), "version_id": vid})
            continue
        live_sha = _rule_version_content_sha(live)
        if live_sha != frozen_sha:
            changed.append({"rule_id": row.get("rule_id"), "code": row.get("code"),
                            "version": row.get("version"), "version_id": vid,
                            "frozen_content_sha": frozen_sha,
                            "live_content_sha": live_sha})
    issues = []
    if changed:
        issues.append({"code": "rule_version_content_changed",
                       "detail": "冻结规则版本的 slots/evidence/tests 被改写（同版本号改内容），"
                                 "本轮不得按新内容执行",
                       "rule_versions": changed})
    if missing:
        issues.append({"code": "rule_version_missing",
                       "detail": "冻结时的规则版本在执行时不存在，无法按冻结版本执行",
                       "rule_versions": missing})
    return {"name": "rule_versions_content", "ok": not changed and not missing,
            "checked": len(frozen_rows), "changed": changed, "missing": missing,
            "issues": issues}


def _decision_version_rules_hash(code: str, version: str) -> tuple:
    """从决策表版本快照取 rules_hash；版本不存在返回 (None, reason)。"""
    try:
        rows = R.decision_tables.list("code=?", (str(code),))
        if rows:
            hist = R.decision_table_versions.list("table_id=?", (rows[0]["id"],),
                                                  order="id DESC")
            ver = next((x for x in hist if str(x.get("version") or "") == str(version)), None)
            if ver:
                rules = json.loads(ver.get("rules_json") or "[]")
                return _sha256_text(json.dumps(rules, ensure_ascii=False)), ""
        return None, "version_snapshot_missing"
    except Exception as exc:
        return None, f"{type(exc).__name__}: {str(exc)[:120]}"


def _check_decision_tables(closure: dict) -> dict:
    frozen_rows = (closure.get("rule_conflict_priority") or {}).get("decision_tables") or []
    changed, missing = [], []
    for row in frozen_rows:
        code, version = str(row.get("code") or ""), str(row.get("version") or "")
        frozen_hash = str(row.get("rules_hash") or "")
        if not code or not version or not frozen_hash:
            continue
        live_hash, reason = _decision_version_rules_hash(code, version)
        if live_hash is None:
            missing.append({"code": code, "version": version, "reason": reason})
        elif live_hash != frozen_hash:
            changed.append({"code": code, "version": version,
                            "frozen_rules_hash": frozen_hash,
                            "live_rules_hash": live_hash})
    issues = []
    if changed:
        issues.append({"code": "decision_table_content_changed",
                       "detail": "决策表同一版本号内容与冻结时不一致（版本快照被改写），"
                                 "本轮不得按实时规则表重算",
                       "decision_tables": changed})
    if missing:
        issues.append({"code": "decision_table_version_missing",
                       "detail": "冻结时引用的决策表版本在执行时不存在，无法回放",
                       "decision_tables": missing})
    return {"name": "decision_tables_content", "ok": not changed and not missing,
            "checked": len(frozen_rows), "changed": changed, "missing": missing,
            "issues": issues}


def _binding_index(closure: dict) -> dict:
    idx = {}
    for b in (closure.get("binding") or {}).get("rules") or []:
        idx[str(b.get("rule_id") or "")] = b
    return idx


def _check_binding(closure: dict, items: list) -> dict:
    idx = _binding_index(closure)
    violations = []
    for it in items or []:
        rid = str(it.get("rule_id") or "")
        oid = str(it.get("object_id") or "")
        binding = it.get("binding") if isinstance(it.get("binding"), dict) else {}
        rule_binding = idx.get(rid) or binding or {}
        allowed = {str(x) for x in (rule_binding.get("allowed_object_ids") or [])}
        if not allowed:
            violations.append({"rule_id": rid, "rule_code": it.get("code"),
                               "object_id": oid, "reason": "binding_missing"})
            continue
        selected = {str(x) for x in (rule_binding.get("selected_object_ids") or [])}
        if selected and not selected <= allowed:
            violations.append({"rule_id": rid, "rule_code": it.get("code"),
                               "object_id": oid, "reason": "selected_outside_allowed",
                               "outside": sorted(selected - allowed)})
        if oid not in allowed:
            violations.append({"rule_id": rid, "rule_code": it.get("code"),
                               "object_id": oid, "reason": "object_outside_allowed",
                               "allowed_object_ids": sorted(allowed)})
    for v in (closure.get("binding") or {}).get("violations") or []:
        violations.append({"rule_id": v.get("rule_id"), "rule_code": v.get("rule_code"),
                           "reason": "closure_binding_invariant_violated",
                           "outside": v.get("object_ids")})
    issues = []
    if violations:
        issues.append({"code": "object_outside_allowed",
                       "detail": "清单 item 出现 allowed（规则作用域允许对象）之外的对象；"
                                 "越界对象硬拒，不执行/不输出",
                       "violations": violations})
    return {"name": "binding_allowed_selected", "ok": not violations,
            "checked": len(items or []), "violations": violations,
            "binding_sha": (closure.get("binding") or {}).get("sha") or "",
            "issues": issues}


def _audit_guard(actor: str, manifest_id: str, result: dict) -> None:
    try:
        # F-04：legacy 仅作为「无 closure_required 标记的历史清单」诊断标记；
        # 只有「历史清单 + 放行」才跳过审计。历史清单被 fail-closed 阻断时同样必须写
        # manifest.integrity_blocked（可归因），不得因 legacy=True 静默跳过。
        if result.get("legacy") and result.get("ok"):
            return
        payload = {"closure_digest": result.get("closure_digest") or "",
                   "closure_schema": result.get("closure_schema") or "",
                   "legacy": bool(result.get("legacy")),
                   "legacy_reason": str(result.get("legacy_reason") or ""),
                   "checks": [{"name": c.get("name"), "ok": c.get("ok"),
                               "checked": c.get("checked")}
                              for c in result.get("checks") or []],
                   "ok": bool(result.get("ok")),
                   "issue_codes": [i.get("code") for i in result.get("issues") or []]}
        action = ("manifest.integrity_verified" if result.get("ok")
                  else "manifest.integrity_blocked")
        R.audit_logs.log(actor=actor or "system", action=action, object=str(manifest_id or ""),
                         after=json.dumps(payload, ensure_ascii=False, default=str))
    except Exception:
        logging.getLogger(__name__).debug("manifest integrity audit skipped", exc_info=True)


def _closure_required(manifest_id: str, closure: dict = None) -> bool:
    """该清单是否带「必须有可校验闭包」的 A6 标记（新清单 True；历史清单 False）。

    F-04（build56 外部审查）后该标记**只用于诊断**：无论 True/False，闭包缺失一律
    显式阻断（fail-closed、0 执行）；历史清单无标记只决定 legacy 诊断字段取值，
    不再作为「legacy 放行」依据。
    """
    if isinstance(closure, dict) and closure.get("closure_required") is True:
        return True
    try:
        from . import sysconfig
        raw = str(sysconfig.get(CLOSURE_REQUIRED_PREFIX + str(manifest_id or ""), "") or "")
        return raw.strip().lower() in ("1", "true", "yes", "on")
    except Exception:
        logging.getLogger(__name__).debug("closure_required lookup skipped", exc_info=True)
        return False


def execution_guard(manifest_id: str, *, verify_files: bool = True,
                    verify_parsed: bool = True,
                    verify_params: bool = True,
                    verify_parser: bool = True, verify_tables: bool = True,
                    verify_rules: bool = True, verify_binding: bool = True,
                    actor: str = "system") -> dict:
    """执行前冻结完整性/对象绑定校验（manifest_exec.run 前置守卫）。

    返回 {"ok", "legacy", "issues", "checks", "closure_digest", ...}；
    ok=False 时调用方必须 0 执行（不得“先跑一遍再看”），并保留 issues 供审计/报告。
    """
    mid = str(manifest_id or "")
    now = datetime.now().isoformat(timespec="seconds")
    row = _manifest_row(mid)
    if not row:
        return {"ok": False, "legacy": False, "manifest_id": mid,
                "issues": [{"code": "manifest_missing",
                            "detail": "audit_manifest 不存在"}],
                "checks": [], "closure_digest": "", "checked_at": now}
    case_id = str(row.get("case_id") or "")
    closure = load_closure(mid)
    _closure_req = _closure_required(mid, closure)
    if not closure:
        # F-04（build56 外部独立审查 P1）：历史无闭包清单不再 legacy 放行。
        # 「无冻结闭包」= 完整性/绑定边界不可证明，与「已验证通过」不等价；历史清单
        # 同样必须显式阻断（fail-closed，0 执行）并强制重新冻结后再执行。
        # legacy 标记仅保留为**诊断标记**（历史清单无 closure_required 标记），
        # 供审计/报告区分「历史无闭包被阻断」与「新清单闭包缺失」，不再作为放行依据。
        _missing_detail = ("新清单要求冻结闭包，但闭包缺失（落库失败/被删）；"
                           "拒绝按 legacy 放行，必须重新冻结后再执行"
                           if _closure_req else
                           "历史清单无冻结闭包：完整性/绑定边界不可证明，按 fail-closed "
                           "显式阻断（不再 legacy 放行），必须重新冻结后再执行")
        result = {"ok": False, "legacy": not _closure_req, "manifest_id": mid,
                  "case_id": case_id,
                  "issues": [{"code": "closure_missing", "detail": _missing_detail}],
                  "closure_required": bool(_closure_req), "closure_degraded": False,
                  "issues_count": 1, "legacy_reason": "closure_missing",
                  "checks": [], "closure_digest": "", "closure_schema": "",
                  "checked_at": now}
        _audit_guard(actor, mid, result)
        return result
    checks, issues = [], []
    live_docs = _live_docs(case_id) if verify_files else {}
    if verify_files:
        check = _check_files(closure, live_docs)
        checks.append(check)
        issues.extend(check.get("issues") or [])
    if verify_parsed:
        # 解析产物指纹：执行期 D2/D3 会重新解析当前文件，必须先证明冻结判定输入可用。
        check = _check_parsed_artifacts(closure)
        checks.append(check)
        issues.extend(check.get("issues") or [])
    if verify_params:
        # 规则参数指纹：D4 读 ruleparam 活值，必须先证明冻结参数未被单独 publish 改掉。
        check = _check_rule_params(closure)
        checks.append(check)
        issues.extend(check.get("issues") or [])
    if verify_parser:
        check = _check_parser_ocr(closure)
        checks.append(check)
        issues.extend(check.get("issues") or [])
    if verify_rules:
        check = _check_rule_versions(closure)
        checks.append(check)
        issues.extend(check.get("issues") or [])
    if verify_tables:
        check = _check_decision_tables(closure)
        checks.append(check)
        issues.extend(check.get("issues") or [])
    if verify_binding:
        check = _check_binding(closure, _manifest_items(row))
        checks.append(check)
        issues.extend(check.get("issues") or [])
    warnings = []
    if closure.get("degraded"):
        warnings.append({"code": "closure_degraded",
                         "detail": "冻结闭包构建时存在显式降级项（errors 见闭包），"
                                   "对应维度未参与本次完整性校验",
                         "errors": closure.get("errors") or {}})
    degraded_checks = [c for c in checks if c.get("degraded")]
    for check in degraded_checks:
        _degraded_name = str(check.get("name") or "")
        warnings.append({"code": ("rule_params_unverifiable"
                                  if _degraded_name == RULE_PARAMS_CHECK
                                  else "parsed_artifacts_unverifiable"),
                         "detail": check.get("note") or
                                   "旧清单无解析产物指纹，判定输入一致性不可证明",
                         "check": _degraded_name})
    result = {"ok": not issues, "legacy": False, "manifest_id": mid,
              "case_id": case_id, "issues": issues, "checks": checks,
              "warnings": warnings,
              "closure_digest": closure.get("digest") or "",
              "closure_schema": closure.get("schema") or "",
              "degraded": bool(closure.get("degraded")) or bool(degraded_checks),
              "binding_sha": (closure.get("binding") or {}).get("sha") or "",
              "reference": (closure.get("business_reference") or {}).get("reference_time") or "",
              "closure_required": bool(_closure_req),
              "closure_degraded": bool(closure.get("degraded")) or bool(degraded_checks)
                                  or bool(closure.get("persist_error")),
              "checked_at": now}
    # A6：新清单闭包 degraded（构建降级 / 落库失败 / 子检查不可证明）→ 0 执行、强制重冻；
    # 历史清单（无 closure_required 标记）保持原行为（degraded 仅警告，不阻断）。
    if _closure_req and result.get("closure_degraded"):
        _deg_note = ("闭包落库失败：" + str(closure.get("persist_error"))) \
            if closure.get("persist_error") else \
            "闭包构建/子检查存在显式降级（degraded）：对应维度完整性不可证明"
        result = {**result, "ok": False,
                  "issues": [{"code": "closure_missing", "detail": _deg_note,
                              "reason": "closure_degraded",
                              "errors": closure.get("errors") or {}}]
                            + list(result.get("issues") or []),
                  "degraded": True,
                  "warnings": list(result.get("warnings") or []) + [{
                      "code": "closure_required_degraded",
                      "detail": "新清单要求可校验闭包，不得以 legacy/警告方式放行；"
                                "必须重新冻结"}]}
    _audit_guard(actor, mid, result)
    return result


def validate_selection(manifest_id: str, items: list = None,
                       closure: dict = None) -> dict:
    """selected ⊆ allowed / item 对象 ∈ allowed 的契约校验（冻结后/执行前均可调用）。"""
    mid = str(manifest_id or "")
    closure = closure if closure is not None else load_closure(mid)
    if not closure:
        return {"ok": True, "legacy": True, "manifest_id": mid, "checked": 0,
                "violations": [], "note": "无冻结闭包（旧清单），无法校验绑定边界"}
    if items is None:
        items = _manifest_items(_manifest_row(mid))
    check = _check_binding(closure, items)
    return {"ok": bool(check["ok"]), "legacy": False, "manifest_id": mid,
            "checked": check.get("checked") or 0,
            "violations": check.get("violations") or [],
            "binding_sha": check.get("binding_sha") or "",
            "issues": check.get("issues") or []}


def object_allowed(manifest_id: str, object_id: str, rule_id: str = "",
                   *, audit: bool = True, closure: dict = None) -> dict:
    """对象是否在冻结 allowed 边界内（全局扫描/补审入口必须先用它过滤）。

    返回 {"allowed", "rules_allowed", ...}；越界拒绝时显式写 manifest.scope_rejected 审计。
    """
    mid = str(manifest_id or "")
    oid = str(object_id or "")
    closure = closure if closure is not None else load_closure(mid)
    if not closure:
        return {"allowed": True, "legacy": True, "manifest_id": mid,
                "object_id": oid, "rule_id": str(rule_id or ""),
                "reason": "no_closure_legacy"}
    hits = []
    for b in (closure.get("binding") or {}).get("rules") or []:
        if rule_id and str(b.get("rule_id") or "") != str(rule_id):
            continue
        if oid in {str(x) for x in (b.get("allowed_object_ids") or [])}:
            hits.append({"rule_id": b.get("rule_id"),
                         "rule_code": b.get("rule_code")})
    result = {"allowed": bool(hits), "legacy": False, "manifest_id": mid,
              "object_id": oid, "rule_id": str(rule_id or ""),
              "rules_allowed": [h["rule_code"] for h in hits],
              "boundary": "manifest.binding.allowed_object_ids（冻结作用域硬边界）"}
    if not hits and audit:
        try:
            R.audit_logs.log(
                actor="system", action="manifest.scope_rejected", object=mid,
                after=json.dumps({"object_id": oid, "requested_rule_id": str(rule_id or ""),
                                  "reason": "object_not_in_allowed",
                                  "note": "全局扫描/补审对象不在冻结 allowed 边界内，硬拒"},
                                 ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("scope rejection audit skipped", exc_info=True)
    return result


def execute(manifest_id: str, external_facts: dict = None,
            actor: str = "system") -> dict:
    """带冻结守卫的清单执行入口（execution_guard → manifest_exec.run → 越界输出后置过滤）。

    与直接 ``manifest_exec.run`` 的区别：
    - 执行前校验冻结闭包：同 document_id 换内容/解析器漂移/决策表改内容/绑定越界 → 0 执行；
    - 外部查询结果只使用冻结值；实时值覆盖冻结值 → 硬拒（manifest.external_override_rejected）；
    - 执行后再次按 allowed 过滤输出（防御深度），越界 item 丢弃并审计；
    - 成功/阻断都写显式审计（manifest.executed / integrity_blocked / scope_violation_dropped）。
    """
    mid = str(manifest_id or "")
    guard = execution_guard(mid)
    if not guard.get("ok"):
        codes = ",".join(str(i.get("code") or "") for i in guard.get("issues") or [])
        try:
            R.audit_logs.log(
                actor=actor or "system", action="manifest.execution_blocked", object=mid,
                after=json.dumps({"issue_codes": codes,
                                  "issues": guard.get("issues") or [],
                                  "closure_digest": guard.get("closure_digest")},
                                 ensure_ascii=False, default=str))
        except Exception:
            logging.getLogger(__name__).debug("execution blocked audit skipped", exc_info=True)
        return {"ok": False, "blocked": True, "manifest_id": mid, "items": [], "total": 0,
                "error": "冻结完整性阻断：" + (codes or "unknown"), "guard": guard}
    closure = load_closure(mid) or {}
    frozen_rows = (closure.get("external_results") or {}).get("items") or []
    frozen_ext = {str(x.get("key")): x.get("value") for x in frozen_rows}
    merged, overridden, extra = dict(frozen_ext), [], []
    for key, val in (external_facts or {}).items():
        key = str(key)
        if key in frozen_ext:
            if _digest(frozen_ext[key], 16) != _digest(val, 16):
                overridden.append(key)
        else:
            extra.append(key)
            merged[key] = val
    if overridden:
        try:
            R.audit_logs.log(
                actor=actor or "system", action="manifest.external_override_rejected",
                object=mid,
                after=json.dumps({"frozen_keys": sorted(frozen_ext),
                                  "rejected_live_keys": overridden},
                                 ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("external override audit skipped", exc_info=True)
        return {"ok": False, "blocked": True, "manifest_id": mid, "items": [], "total": 0,
                "error": "外部查询结果已在冻结闭包中固化，拒绝用实时值覆盖："
                         + ",".join(overridden),
                "external": {"frozen_keys": sorted(frozen_ext),
                             "rejected_live_keys": overridden},
                "guard": guard}
    from . import manifest_exec
    # L52：run() 现在自带 manifest.executed 审计；execute 再写一次会造成同一次执行
    # 两条事件，故走私有白名单入口跳过下沉审计（execute 自己的审计包含 closure/binding
    # 信息）。L77 收口：不再允许任何调用方用 ``manifest_exec.run(..., audit=False)``
    # 关闭审计；唯一例外是本函数（静态扫描只允许此处出现 _run_delegated_audit）。
    out = manifest_exec._run_delegated_audit(
        mid, external_facts=merged or None, delegate="manifest.execute")
    # 防御深度：即使执行侧未过滤，越界对象输出也不得进入 finding/报告
    try:
        rule_rows = (closure.get("binding") or {}).get("rules") or []
        by_rid = {str(b.get("rule_id") or ""): b for b in rule_rows}
        kept, dropped = [], []
        for it in out.get("items") or []:
            rid = str(it.get("rule_id") or "")
            oid = str(it.get("object_id") or "")
            binding = by_rid.get(rid)
            if binding is None:
                code = str(it.get("rule") or "")
                binding = next((b for b in rule_rows
                                if str(b.get("rule_code") or "") == code), None)
            allowed = {str(x) for x in (binding or {}).get("allowed_object_ids") or []}
            if allowed and oid not in allowed:
                dropped.append({"rule_id": rid, "rule": it.get("rule"),
                                "object_id": oid})
            else:
                kept.append(it)
        if dropped:
            out["items"] = kept
            out["total"] = len(kept)
            out["ok"] = False
            out["blocked"] = True
            out["scope_guard"] = {
                "dropped": len(dropped),
                "objects": sorted({str(d.get("object_id") or "") for d in dropped}),
                "items": dropped,
                "boundary": "allowed_object_ids",
            }
            try:
                R.audit_logs.log(
                    actor=actor or "system", action="manifest.scope_violation_dropped",
                    object=mid, after=json.dumps(out["scope_guard"],
                                                 ensure_ascii=False, default=str))
            except Exception:
                logging.getLogger(__name__).debug("scope drop audit skipped", exc_info=True)
    except Exception:
        logging.getLogger(__name__).debug("scope post-filter skipped", exc_info=True)
    out["guard"] = guard
    out["closure"] = {
        "schema": closure.get("schema") or "",
        "closure_digest": closure.get("digest") or "",
        "binding_sha": (closure.get("binding") or {}).get("sha") or "",
        "reference_time": (closure.get("business_reference") or {}).get("reference_time") or "",
        "timezone": (closure.get("business_reference") or {}).get("timezone") or "",
        "external_used": sorted(merged),
        "external_frozen_count": len(frozen_ext),
        "external_unfrozen_live": extra,
    }
    try:
        R.audit_logs.log(
            actor=actor or "system", action="manifest.executed", object=mid,
            after=json.dumps({"total": out.get("total"),
                              "completed": out.get("completed"),
                              "incomplete": out.get("incomplete"),
                              "closure_digest": closure.get("digest") or "",
                              "binding_sha": (closure.get("binding") or {}).get("sha") or "",
                              "external_used": sorted(merged),
                              "scope_dropped": (out.get("scope_guard") or {}).get("dropped", 0),
                              "single_entry_fix": _single_entry_enabled()},
                             ensure_ascii=False, default=str))
    except Exception:
        logging.getLogger(__name__).debug("executed audit skipped", exc_info=True)
    try:
        if _single_entry_enabled():
            out["executed_audit"] = "manifest.executed"
            out["single_entry_fix"] = True
    except Exception:
        logging.getLogger(__name__).debug("executed audit mark skipped", exc_info=True)
    return out


def _single_entry_enabled() -> bool:
    """L52 开关（调用期读取；异常按默认开处理，保证 fail-closed 口径不因导入失败回退）。"""
    try:
        from . import single_entry as _se
        return _se.enabled()
    except Exception:
        return True


# L52 ③ 清单执行入口二选一：同一冻结清单已有执行结果时 = **只读重放**（幂等、不写
# active/finding）；首次执行由调用方走 execute + project.materialize_manifest_run 完整物化。
def replay_readonly(manifest_id: str, actor: str = "system") -> dict:
    """冻结清单只读重放：只返回该清单既有 manifest_result 行，不写 active/finding。

    返回 ``executed=False`` 表示该清单还没有执行结果 → 调用方应走首次执行 + 物化。
    本函数唯一写入是 ``manifest.replayed_readonly`` 审计（审计是“重放发生过”的证明）。
    """
    mid = str(manifest_id or "")
    mrow = None
    rows = []
    try:
        c = db.connect()
        try:
            _m = c.execute("SELECT id, case_id, status, items_json FROM audit_manifest "
                           "WHERE id=?", (mid,)).fetchone()
            mrow = dict(_m) if _m else None
            if mrow:
                rows = [dict(r) for r in c.execute(
                    "SELECT id, object_id, rule_id, rule_code, conclusion, execution, "
                    "review_status, updated_at FROM manifest_result WHERE manifest_id=? "
                    "ORDER BY rowid", (mid,))]
        finally:
            c.close()
    except Exception:
        logging.getLogger(__name__).warning(
            "replay readonly query failed manifest=%s", mid, exc_info=True)
        rows = []
    items = []
    for r in rows:
        items.append({
            "result_id": str(r.get("id") or ""),
            "object_id": str(r.get("object_id") or ""),
            "rule_id": str(r.get("rule_id") or ""),
            "rule": str(r.get("rule_code") or ""),
            "conclusion": str(r.get("conclusion") or ""),
            "execution": str(r.get("execution") or ""),
            "review_status": str(r.get("review_status") or ""),
            "updated_at": str(r.get("updated_at") or ""),
        })
    out = {
        "ok": bool(mrow) and bool(rows),
        "manifest_id": mid,
        "case_id": str((mrow or {}).get("case_id") or ""),
        "executed": bool(rows),
        "readonly": True,
        "materialized": False,
        "mode": "replay_readonly",
        "source": "manifest_result（冻结清单既有执行结果；只读重放，不写 active/finding）",
        "items": items,
        "total": len(items),
        "completed": sum(1 for x in items if x.get("execution") == "completed"),
        "incomplete": sum(1 for x in items if x.get("execution") != "completed"),
        "note": ("同一冻结清单已执行过 → 本次为只读重放（幂等）：不重跑 D1–D5、不写 "
                 "manifest_result/manifest_active/finding/audit_run；如需新结论请走审核入口"
                 "（project.audit manual/assisted）"),
    }
    if not mrow:
        out["error"] = "审核清单不存在"
        return out
    if not rows:
        out["note"] = ("该冻结清单尚无执行结果：首次执行会完整物化 finding/audit_run"
                       "（不再只写 active）")
    try:
        R.audit_logs.log(actor=actor or "system", action="manifest.replayed_readonly",
                         object=mid,
                         after=json.dumps({"manifest_id": mid,
                                           "results": len(rows),
                                           "mode": "replay_readonly",
                                           "writes": {"manifest_result": 0,
                                                      "manifest_active": 0,
                                                      "finding": 0,
                                                      "audit_run": 0}},
                                          ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("replay readonly audit skipped", exc_info=True)
    return out
