"""工作空间级问题分析（用于首页可视化，帮助前端优化文件生产环节）。
分类口径（通用，不绑定行业）：
1) 审核面 A-G：来自审核点编码前缀（A01→A），一眼看出问题集中在哪类要求
2) 高频规则/审核点：问题的具体来源，词云用
3) 文档位置（Sheet/章节）：问题出在文件生产的哪个环节
4) 趋势：按天统计，看是否在改善
5) 反复出现：同一规则跨多个项目复现 → 属于流程性/系统性问题
"""
import json
from .. import db

FACE_LABEL = {
    "A": "主体资格", "B": "结构完备", "C": "事实数据", "D": "逻辑结论",
    "E": "权利义务", "F": "商务执行", "G": "披露申报",
}


import re as _re

def _face(point_id: str) -> str:
    """只认审核点编码（A01/C08…）；规则编码不算审核面。"""
    p = (point_id or "").strip()
    m = _re.match(r"^([A-G])[0-9]", p)
    return m.group(1) if m else "其他"


def summary(workspace_id: str = "", tenant_id: str = "", days: int = 30, owner: str = "") -> dict:
    days = max(1, min(int(days or 30), 365))
    where = "WHERE date(c.created_at) >= date('now', ?)"
    params = [f"-{days} days"]
    if tenant_id:
        where += " AND c.tenant_id = ?"; params.append(tenant_id)
    if workspace_id:
        where += " AND c.workspace_id = ?"; params.append(workspace_id)
    if owner:
        where += " AND c.created_by = ?"; params.append(owner)
    sql_base = ("FROM finding f JOIN audit_case c ON c.id = f.case_id " + where)
    c = db.connect()
    try:
        total = c.execute("SELECT count(*) " + sql_base, params).fetchone()[0]
        by_sev = {r[0] or "unknown": r[1] for r in c.execute(
            "SELECT f.severity, count(*) " + sql_base + " GROUP BY f.severity", params).fetchall()}
        by_face = {}
        for pid, n in c.execute("SELECT f.point_id, count(*) " + sql_base +
                                " GROUP BY f.point_id", params).fetchall():
            k = _face(pid)
            by_face[k] = by_face.get(k, 0) + n
        faces = [{"face": k, "label": FACE_LABEL.get(k, "其他"), "count": v}
                 for k, v in sorted(by_face.items(), key=lambda x: -x[1])]
        top_rules = [{"code": r[0] or "", "title": r[1] or "", "count": r[2]}
                     for r in c.execute(
                         "SELECT f.rule_id, max(f.title), count(*) " + sql_base +
                         " GROUP BY f.rule_id ORDER BY count(*) DESC LIMIT 20", params).fetchall()]
        # 高频问题按 finding 标题聚合，供词云使用（不是按规则编码）
        top_issues = [{"title": r[0] or "", "count": r[1]} for r in c.execute(
            "SELECT COALESCE(NULLIF(f.title,''), f.rule_id), count(*) " + sql_base +
            " GROUP BY COALESCE(NULLIF(f.title,''), f.rule_id) ORDER BY count(*) DESC LIMIT 30",
            params).fetchall()]
        # 文档位置（Sheet/章节）：经 evidence → anchor 关联
        by_sheet = {}
        sql_sheet = ("SELECT coalesce(a.sheet,''), count(DISTINCT f.id) "
                     "FROM evidence e JOIN anchor a ON a.id = e.anchor_id "
                     "JOIN finding f ON f.id = e.finding_id "
                     "JOIN audit_case c ON c.id = f.case_id " + where +
                     " GROUP BY coalesce(a.sheet,'') ORDER BY 2 DESC LIMIT 15")
        for sheet, n in c.execute(sql_sheet, params).fetchall():
            by_sheet[sheet or "（未标注位置）"] = n
        sheets = [{"sheet": k, "count": v} for k, v in by_sheet.items()]
        trend = [{"date": r[0], "count": r[1]} for r in c.execute(
            "SELECT date(c.created_at) d, count(*) " + sql_base +
            " GROUP BY d ORDER BY d", params).fetchall()]
        # 反复出现：同一规则出现在 >=2 个项目 → 流程性问题
        # 规则类别维度（客户自己的管理分类：招标/保险/食品…，通用）
        by_cat = [{"category": r[0] or "未分类", "count": r[1]} for r in c.execute(
            "SELECT coalesce(r.category,''), count(*) " + sql_base.replace("FROM finding f", "FROM finding f LEFT JOIN rule r ON r.code = f.rule_id") +
            " GROUP BY coalesce(r.category,'') ORDER BY 2 DESC LIMIT 10", params).fetchall()]
        recurring = [{"code": r[0] or "", "title": r[1] or "", "cases": r[2], "count": r[3]}
                     for r in c.execute(
                         "SELECT f.rule_id, max(f.title), count(DISTINCT f.case_id), count(*) " + sql_base +
                         " GROUP BY f.rule_id HAVING count(DISTINCT f.case_id) >= 2 "
                         "ORDER BY count(DISTINCT f.case_id) DESC LIMIT 15", params).fetchall()]
        cases = c.execute("SELECT count(DISTINCT c.id) " + sql_base, params).fetchone()[0]
    finally:
        c.close()
    return {"window_days": days, "cases": cases, "findings": total,
            "severity": by_sev, "faces": faces, "top_rules": top_rules, "top_issues": top_issues,
            "sheets": sheets, "trend": trend, "recurring": recurring,
            "categories": by_cat,
            "face_labels": FACE_LABEL}
