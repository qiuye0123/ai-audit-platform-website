"""规则模型（P1-7）：从四元组扩展到可表达「适用条件 + 例外」。

字段：
  subject / applicability / conditions / exceptions / effective_period /
  source_anchor / evidence_requirement / severity / action
兼容旧四元组：metric / op / value / unit 保留原样。
"""
REQUIRED = ("subject", "action")
OPTIONAL = ("applicability", "conditions", "exceptions", "effective_period",
            "source_anchor", "evidence_requirement", "severity")


def normalize(slots: dict) -> dict:
    s = dict(slots or {})
    s.setdefault("subject", str(s.get("metric") or s.get("subject") or ""))
    # 过滤“伪适用条件”：把 metric/subject 本身当条件（如「单次采购」）会误伤全部文本
    _metric = str(s.get("metric") or "")
    _subj = str(s.get("subject") or "")
    _apps = []
    for a in (s.get("applicability") or []):
        a = str(a).strip()
        if not a:
            continue
        if a in _metric or a in _subj or _metric in a or _subj in a:
            continue
        _apps.append(a)
    s["applicability"] = _apps
    s.setdefault("conditions", [])
    s.setdefault("exceptions", [])
    s.setdefault("effective_period", None)
    s.setdefault("source_anchor", s.get("source_anchor") or "")
    s.setdefault("evidence_requirement", s.get("evidence_requirement") or "")
    s.setdefault("severity", s.get("severity") or "warning")
    s.setdefault("action", s.get("action") or "")
    return s


def validate(slots: dict) -> dict:
    s = normalize(slots)
    missing = [k for k in REQUIRED if not str(s.get(k) or "").strip()]
    return {"ok": not missing, "missing": missing}


def applicable(slots: dict, text: str) -> dict:
    """判断规则是否适用于本文本：命中任一例外 → 不适用；适用条件缺失 → 不适用。"""
    s = normalize(slots)
    t = text or ""
    for ex in s.get("exceptions") or []:
        if ex and str(ex) in t:
            return {"applicable": False, "reason": f"命中例外：{ex}"}
    apps = [a for a in (s.get("applicability") or []) if a]
    if apps and not any(str(a) in t for a in apps):
        return {"applicable": False, "reason": f"不满足适用条件：{'/'.join(map(str, apps))}"}
    return {"applicable": True, "reason": ""}
