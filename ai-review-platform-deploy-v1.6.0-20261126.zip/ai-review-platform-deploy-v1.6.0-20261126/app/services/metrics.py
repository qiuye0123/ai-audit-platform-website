# -*- coding: utf-8 -*-
"""进程内指标注册表（T-201 /metrics，纯内存、无第三方依赖、Prometheus 文本兼容）。

设计口径（为什么不引入 prometheus_client）：
- 交付/CI 环境要求离线可跑，不能为了 /metrics 增加第三方运行时依赖；
- 指标量小（< 100 个时间序列），一个 RLock + dict 足够；
- 输出严格遵循 Prometheus text exposition format 0.0.4：
  ``# HELP`` / ``# TYPE`` / ``name{label="value"} value``；直方图输出
  ``_bucket{le=...}`` 累积计数 + ``_sum`` + ``_count``。

两类数据源（都真实，不编数）：
1. **内存事件计数**：模型调用（engine.llm 埋点）、审核运行、报告门禁、HTTP 响应；
   由 :func:`llm_call` / :func:`review_run` / :func:`gate_check` /
   :func:`http_response` 递增。进程重启归零（进程级指标语义）。
2. **DB 只读快照**：审核 case/run/finding、报告记录、队列（task_job）、影子池
   （shadow_item）等业务存量在 :func:`scrape` 时只读聚合，不写库。

零成本失败：所有对外的记录函数都通过 ``log.warning(..., exc_info=True)`` 记录
自身异常（铁律 2：不静默失败），但不向上抛——指标故障绝不影响审核/模型/报告主链。
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 描述符：name -> (type, help, label_names)
# 未登记的名字按 counter 处理，HELP 缺失也能输出（合法但不完整，故内部只用登记名）。
# ---------------------------------------------------------------------------
_DESCRIPTORS = {
    "rp_model_calls_total": ("counter", "模型调用次数（status=ok|error）", ("model", "status")),
    "rp_model_tokens_total": ("counter", "模型 token 数（direction=in|out）", ("model", "direction")),
    "rp_model_latency_seconds": ("histogram", "模型调用耗时（秒）", ("model",)),
    "rp_model_consecutive_failures": ("gauge", "最近连续模型失败次数（0=健康）", ()),
    "rp_review_runs_total": ("counter", "审核运行次数（status=ok|failed）", ("status",)),
    "rp_review_failures_total": ("counter", "审核失败数（内存事件口径）", ()),
    "rp_review_duration_seconds": ("histogram", "审核运行耗时（秒）", ()),
    "rp_review_cases": ("gauge", "审核项目总数（DB 只读聚合）", ()),
    "rp_review_runs": ("gauge", "审核批次总数（DB 只读聚合）", ()),
    "rp_review_failed_cases": ("gauge", "失败/异常状态审核项目数（DB 只读聚合）", ()),
    "rp_review_findings": ("gauge", "审核发现数（DB 只读聚合，按严重度）", ("severity",)),
    "rp_report_records_total": ("gauge", "报告记录总数（DB 只读聚合）", ()),
    "rp_report_exports_total": ("counter", "报告导出/生成次数（内存事件口径）", ("format",)),
    "rp_report_gate_checks_total": ("counter", "报告门禁检查次数", ("result",)),
    "rp_gate_blocked_total": ("counter", "报告门禁拦截次数（按原因分类）", ("reason",)),
    "rp_gate_blocked_ratio": ("gauge", "报告门禁拦截比例（0-1）", ()),
    "rp_queue_tasks": ("gauge", "任务队列任务数（DB 只读聚合，按状态）", ("status",)),
    "rp_shadow_pool_pending": ("gauge", "影子池待裁决项数（DB 只读聚合）", ()),
    "rp_audit_log_rows": ("gauge", "审计日志行数（DB 只读聚合）", ()),
    "rp_db_up": ("gauge", "数据库可用性（1=可用）", ()),
    "rp_process_uptime_seconds": ("gauge", "进程运行时长（秒）", ()),
    "rp_process_requests_total": ("counter", "HTTP 响应数（按方法；由集中 _send 埋点采集）", ("method",)),
    "rp_process_http_5xx_total": ("counter", "HTTP 5xx 响应数", ()),
    "rp_process_http_responses": ("gauge", "HTTP 响应总数（进程内累计）", ()),
    "rp_alert_evaluations_total": ("counter", "告警规则评估次数", ("result",)),
    "rp_alert_fired_total": ("counter", "告警触发次数（按规则）", ("rule",)),
    "rp_alert_active": ("gauge", "当前活跃告警数", ()),
}

# 直方图默认桶（秒）；模型/审核耗时都能覆盖到 0.005s~600s。
DEFAULT_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0,
                   10.0, 30.0, 60.0, 120.0, 300.0, 600.0)
_BUCKETS = {
    "rp_model_latency_seconds": DEFAULT_BUCKETS,
    "rp_review_duration_seconds": DEFAULT_BUCKETS,
}

_START = time.time()
_LOCK = threading.RLock()
_COUNTERS: dict = {}   # (name, labels_tuple) -> float
_GAUGES: dict = {}     # (name, labels_tuple) -> float
_HISTS: dict = {}      # (name, labels_tuple) -> {"counts": [...], "sum": float, "count": int}

# 模型调用最近结果（供告警规则判断「连续失败」）；只保留布尔，不保存任何内容。
_LLM_RECENT = deque(maxlen=200)

_REASON_CLASSES = (
    ("unknown", ("unknown", "证据不足", "无法判断")),
    ("pending_review", ("待复核", "人工复核")),
    ("critical_unsigned", ("严重", "high_severity", "critical")),
    ("parse_gap", ("解析缺口", "解析")),
    ("conflict", ("冲突", "conflict")),
    ("execution_failed", ("执行失败", "失败", "execution_failed", "blocked")),
)

_LABEL_RE_NAME = __import__("re").compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------
def _labels_key(labels: dict) -> tuple:
    return tuple(sorted((str(k), str(v)) for k, v in (labels or {}).items()))


def _fmt_label_value(v) -> str:
    s = str(v).replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
    return s


def _render_labels(labels_tuple: tuple) -> str:
    if not labels_tuple:
        return ""
    parts = []
    for k, v in labels_tuple:
        if not _LABEL_RE_NAME.match(str(k)):
            continue
        parts.append('%s="%s"' % (k, _fmt_label_value(v)))
    return "{" + ",".join(parts) + "}" if parts else ""


def _fmt_value(v) -> str:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return "0"
    if f != f or f in (float("inf"), float("-inf")):  # NaN/Inf 不是合法 Prometheus 值
        return "0"
    if f.is_integer():
        return str(int(f))
    return "%g" % f


def _ensure_hist(name: str, labels_tuple: tuple) -> dict:
    key = (name, labels_tuple)
    h = _HISTS.get(key)
    if h is None:
        buckets = _BUCKETS.get(name, DEFAULT_BUCKETS)
        h = {"buckets": tuple(buckets), "counts": [0] * len(buckets), "sum": 0.0, "count": 0}
        _HISTS[key] = h
    return h


def _inc(name: str, labels: dict, value: float = 1) -> None:
    key = (name, _labels_key(labels))
    with _LOCK:
        _COUNTERS[key] = float(_COUNTERS.get(key) or 0) + float(value)


def counter(name: str, value: float = 1, **labels) -> None:
    """通用计数器 +value（未登记名也可用，按 counter 输出）。"""
    try:
        _inc(name, labels, value)
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def gauge_set(name: str, value: float, **labels) -> None:
    """通用 gauge 直接置值。"""
    try:
        with _LOCK:
            _GAUGES[(name, _labels_key(labels))] = float(value)
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def observe(name: str, value: float, **labels) -> None:
    """通用直方图观测。"""
    try:
        _observe(name, labels, value)
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def _observe(name: str, labels: dict, value: float) -> None:
    labels_tuple = _labels_key(labels)
    with _LOCK:
        h = _ensure_hist(name, labels_tuple)
        try:
            v = float(value)
        except (TypeError, ValueError):
            return
        if v < 0 or v != v:
            return
        for i, b in enumerate(h["buckets"]):
            if v <= b:
                h["counts"][i] += 1
        h["sum"] += v
        h["count"] += 1


def reset() -> None:
    """清空进程内指标（测试/埋点重载用；不影响 DB 聚合）。"""
    with _LOCK:
        _COUNTERS.clear()
        _GAUGES.clear()
        _HISTS.clear()
        _LLM_RECENT.clear()


# ---------------------------------------------------------------------------
# 语义化记录 API（真实调用点：engine.llm / report.check_gate / cli audit / server hook）
# ---------------------------------------------------------------------------
def llm_call(model: str = "", ok: bool = True, latency_ms: float = 0,
             tokens_in: int = 0, tokens_out: int = 0) -> None:
    """模型调用一次。llm.py 的 chat_completion 成功/失败两处调用（唯一外发口）。"""
    try:
        model = str(model or "unknown")[:80]
        status = "ok" if ok else "error"
        _inc("rp_model_calls_total", {"model": model, "status": status})
        _observe("rp_model_latency_seconds", {"model": model},
                 max(0.0, float(latency_ms or 0) / 1000.0))
        if tokens_in:
            _inc("rp_model_tokens_total", {"model": model, "direction": "in"}, int(tokens_in))
        if tokens_out:
            _inc("rp_model_tokens_total", {"model": model, "direction": "out"}, int(tokens_out))
        with _LOCK:
            _LLM_RECENT.append(bool(ok))
            gauge_set("rp_model_consecutive_failures", float(_consecutive_failures_locked()))
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def _consecutive_failures_locked() -> int:
    n = 0
    for ok in reversed(_LLM_RECENT):
        if ok:
            break
        n += 1
    return n


def llm_consecutive_failures() -> int:
    try:
        with _LOCK:
            return _consecutive_failures_locked()
    except Exception:
        return 0


def llm_recent(n: int = 50) -> list:
    try:
        with _LOCK:
            return list(_LLM_RECENT)[-int(n):]
    except Exception:
        return []


def review_run(duration_s: float | None = None, ok: bool = True) -> None:
    """一次审核运行完成（耗时可为 None=不观测耗时，仅计数）。"""
    try:
        status = "ok" if ok else "failed"
        _inc("rp_review_runs_total", {"status": status})
        if not ok:
            _inc("rp_review_failures_total", {})
        if duration_s is not None:
            _observe("rp_review_duration_seconds", {}, float(duration_s))
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def review_failure_rate() -> dict:
    """审核失败率（内存事件口径）；无样本时 ok=False。"""
    try:
        with _LOCK:
            ok = sum(v for (name, _), v in _COUNTERS.items()
                     if name == "rp_review_runs_total" and _label_of(_, "status") == "ok")
            failed = sum(v for (name, _), v in _COUNTERS.items()
                         if name == "rp_review_runs_total" and _label_of(_, "status") == "failed")
        total = ok + failed
        return {"total": int(total), "failed": int(failed),
                "rate": (failed / total) if total else 0.0}
    except Exception:
        return {"total": 0, "failed": 0, "rate": 0.0}


def report_exported(fmt: str = "") -> None:
    try:
        _inc("rp_report_exports_total", {"format": str(fmt or "unknown")})
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def gate_reason_class(reason) -> str:
    """门禁原因归一到有限集合（控制 Prometheus label 基数）。"""
    text = str(reason or "").lower()
    for code, keys in _REASON_CLASSES:
        if any(k.lower() in text for k in keys):
            return code
    return "other"


def gate_check(ok: bool, reasons=None) -> None:
    """报告门禁一次检查（report.check_gate 唯一调用点，CLI/HTTP/report_gate 同源）。"""
    try:
        _inc("rp_report_gate_checks_total", {"result": "pass" if ok else "blocked"})
        for r in (reasons or []):
            _inc("rp_gate_blocked_total", {"reason": gate_reason_class(r)})
        stats = gate_stats()
        gauge_set("rp_gate_blocked_ratio", float(stats.get("blocked_ratio") or 0))
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def gate_stats() -> dict:
    try:
        with _LOCK:
            checks_pass = 0.0
            checks_blocked = 0.0
            by_reason = {}
            for (name, labels), v in _COUNTERS.items():
                if name == "rp_report_gate_checks_total":
                    if _label_of(labels, "result") == "pass":
                        checks_pass += v
                    else:
                        checks_blocked += v
                elif name == "rp_gate_blocked_total":
                    by_reason[_label_of(labels, "reason") or "other"] = int(v)
        total = checks_pass + checks_blocked
        return {"checks": int(total), "blocked": int(checks_blocked),
                "pass": int(checks_pass),
                "blocked_ratio": (checks_blocked / total) if total else 0.0,
                "by_reason": by_reason}
    except Exception:
        return {"checks": 0, "blocked": 0, "pass": 0, "blocked_ratio": 0.0, "by_reason": {}}


def http_response(code, method: str = "") -> None:
    """一次 HTTP 响应（server.Handler._send 埋点，覆盖所有方法）。"""
    try:
        code_i = int(code or 0)
        method = str(method or "").upper() or "UNKNOWN"
        _inc("rp_process_requests_total", {"method": method})
        with _LOCK:
            total = sum(v for (name, _), v in _COUNTERS.items()
                        if name == "rp_process_requests_total")
            gauge_set("rp_process_http_responses", total)
        if code_i >= 500:
            _inc("rp_process_http_5xx_total", {})
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)


def http_5xx_rate() -> dict:
    try:
        with _LOCK:
            responses = sum(v for (name, _), v in _COUNTERS.items()
                            if name == "rp_process_requests_total")
            five = sum(v for (name, _), v in _COUNTERS.items()
                       if name == "rp_process_http_5xx_total")
        return {"responses": int(responses), "5xx": int(five),
                "rate": (five / responses) if responses else 0.0}
    except Exception:
        return {"responses": 0, "5xx": 0, "rate": 0.0}


def _label_of(labels_tuple: tuple, key: str) -> str:
    for k, v in labels_tuple or ():
        if k == key:
            return v
    return ""


# ---------------------------------------------------------------------------
# DB 只读聚合（/metrics 抓取时执行；任何查询失败都不影响其它指标）
# ---------------------------------------------------------------------------
def _db_counts() -> list:
    """返回 [(name, labels_dict|None, value)]；无法访问 DB 时返回 rp_db_up=0。"""
    out: list = []
    try:
        from .. import db
        with db.session() as c:
            out.append(("rp_db_up", None, 1))

            def count(sql: str) -> int:
                try:
                    return int(c.execute(sql).fetchone()[0] or 0)
                except Exception:
                    return 0

            out.append(("rp_review_cases", None, count("SELECT COUNT(*) FROM audit_case")))
            out.append(("rp_review_runs", None, count("SELECT COUNT(*) FROM audit_run")))
            out.append(("rp_review_failed_cases", None, count(
                "SELECT COUNT(*) FROM audit_case WHERE status IN "
                "('audit_failed','failed','error')")))
            for sev in ("critical", "warning", "suspected"):
                out.append(("rp_review_findings", {"severity": sev},
                            count(f"SELECT COUNT(*) FROM finding WHERE severity='{sev}'")))
            out.append(("rp_report_records_total", None,
                        count("SELECT COUNT(*) FROM report")))
            out.append(("rp_audit_log_rows", None, count("SELECT COUNT(*) FROM audit_log")))
            for status in ("queued", "running", "failed", "done", "cancelled"):
                out.append(("rp_queue_tasks", {"status": status},
                            count("SELECT COUNT(*) FROM task_job WHERE status='%s'" % status)))
            # 影子池：表存在才报（迁移前老库无此表，不能把“表不存在”伪造成 0）
            try:
                has_shadow = bool(c.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name='shadow_item'"
                ).fetchone())
            except Exception:  # noqa: BLE001
                has_shadow = False
                log.warning("metrics：shadow_item 表探测失败", exc_info=True)
            if has_shadow:
                out.append(("rp_shadow_pool_pending", None, count(
                    "SELECT COUNT(*) FROM shadow_item WHERE shadow_status='pending'")))
    except Exception:  # noqa: BLE001 - 指标失败不阻断主链，但必须留日志
        log.warning("metrics 记录失败（已忽略，不影响主链）", exc_info=True)
    return out


# ---------------------------------------------------------------------------
# 渲染
# ---------------------------------------------------------------------------
def _families() -> list:
    """聚合为 [(name, labels_tuple, value)] + 直方图族；供渲染/测试共用。"""
    with _LOCK:
        counters = [("counter", name, labels, value)
                    for (name, labels), value in sorted(_COUNTERS.items())]
        gauges = [("gauge", name, labels, value)
                  for (name, labels), value in sorted(_GAUGES.items())]
        hists = [("histogram", name, labels, dict(h))
                 for (name, labels), h in sorted(_HISTS.items())]
    return counters + gauges + hists


def _type_help(name: str, dflt_type: str) -> tuple:
    d = _DESCRIPTORS.get(name)
    if d:
        return d[0], d[1]
    return dflt_type, ""


def render() -> str:
    """Prometheus text exposition format 0.0.4 文本。"""
    lines: list = []
    families: dict = {}
    for typ, name, labels, value in _families():
        families.setdefault(name, {"type": typ, "items": []})["items"].append(
            (labels, value))
    # DB 只读聚合（gauge）
    for name, labels, value in _db_counts():
        labels_tuple = _labels_key(labels) if labels else ()
        families.setdefault(name, {"type": "gauge", "items": []})["items"].append(
            (labels_tuple, value))
    # 进程指标（运行时计算）
    with _LOCK:
        uptime = time.time() - _START
        consecutive = _consecutive_failures_locked()
    families.setdefault("rp_process_uptime_seconds",
                        {"type": "gauge", "items": []})["items"].append(((), uptime))
    # 连续失败 gauge 由 llm_call 维护（模块导入时初始化为 0），这里不重复写同一序列，
    # 避免出现重复 series（Prometheus 会判为非法）。
    families.setdefault("rp_model_consecutive_failures",
                        {"type": "gauge", "items": []})
    for name in sorted(families):
        fam = families[name]
        typ, help_text = _type_help(name, fam.get("type") or "gauge")
        lines.append("# HELP %s %s" % (name, help_text or name))
        lines.append("# TYPE %s %s" % (name, typ))
        if typ == "histogram":
            # 同一 name 可能有不同标签组合：逐个序列输出累积桶/sum/count
            for labels, h in fam["items"]:
                for i, b in enumerate(h.get("buckets") or ()):
                    le = _render_labels(labels + (("le", _fmt_value(b)),)) if labels \
                        else _render_labels((("le", _fmt_value(b)),))
                    lines.append("%s_bucket%s %s" % (name, le,
                                                     _fmt_value(h["counts"][i] if i < len(h["counts"]) else 0)))
                plus = _render_labels(labels + (("le", "+Inf"),)) if labels \
                    else _render_labels((("le", "+Inf"),))
                lines.append("%s_bucket%s %s" % (name, plus, _fmt_value(h.get("count") or 0)))
                lines.append("%s_sum%s %s" % (name, _render_labels(labels),
                                               _fmt_value(h.get("sum") or 0)))
                lines.append("%s_count%s %s" % (name, _render_labels(labels),
                                                 _fmt_value(h.get("count") or 0)))
        else:
            for labels, value in fam["items"]:
                lines.append("%s%s %s" % (name, _render_labels(labels), _fmt_value(value)))
    # 活跃告警 gauge（由 alert_rules 维护，这里不重复写）
    return "\n".join(lines) + "\n"


def scrape() -> bytes:
    try:
        return render().encode("utf-8")
    except Exception:
        # 渲染异常也必须输出合法（空）文本而不是 500：错误写 stderr 日志由调用方负责
        return b"# HELP rp_metrics_render_error 1\n# TYPE rp_metrics_render_error gauge\nrp_metrics_render_error 1\n"


def snapshot() -> dict:
    """告警规则使用的结构化快照（不解析文本）。"""
    return {
        "llm_consecutive_failures": llm_consecutive_failures(),
        "llm_recent": llm_recent(50),
        "review": review_failure_rate(),
        "gate": gate_stats(),
        "http": http_5xx_rate(),
        "uptime_seconds": max(0.0, time.time() - _START),
    }


# 进程启动即初始化 gauge 默认值（Prometheus 期望指标族在启动后即可抓取到）
gauge_set("rp_model_consecutive_failures", 0.0)
gauge_set("rp_alert_active", 0.0)
