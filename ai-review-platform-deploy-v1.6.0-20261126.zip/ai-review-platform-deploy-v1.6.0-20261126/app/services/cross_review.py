# -*- coding: utf-8 -*-
"""双轨审核 Phase 1：直连草稿 × 平台 finding 自动比对与差异清单（离线实验）。

只做“提示/分组”，不做最终裁决（见 docs/delivery/双轨直连草稿与交叉复核_20261117.md）：
- 四桶：both / direct_only / platform_only / conflict；
- 匹配键：对象（文档）+ 条款/单元格（quote 定位/位置提示）+ 主体 + 问题类型；
- 自动相似度只用于生成差异清单和分组建议，不得据此把 direct_only 判误报、
  也不得把 platform_only 判真问题；
- 人工裁决字段 human_status 默认为 unreviewed，且本模块不会自动写 human 结论。

本模块不被 server / cli / web / audit 主链引用；Phase 1 仅由
scripts/qa/dual_track_p01.py 离线调用。
"""
from __future__ import annotations

import collections
import difflib
import datetime as _dt
import json
import re
import uuid

BUCKETS = ("both", "direct_only", "platform_only", "conflict")
BUCKET_LABELS = {
    "both": "两边都有且证据一致",
    "direct_only": "只有直连报（平台未覆盖/漏报）",
    "platform_only": "只有平台报（直连未报）",
    "conflict": "两边都有但证据/归属冲突",
}
PAIR_SCORE_THRESHOLD = 0.5
CROSS_CODE_SIM_THRESHOLD = 0.55
LOCATION_NEAR = 500

# 人工裁决取值（默认 unreviewed；本模块不自动写入）
HUMAN_STATUSES = ("unreviewed", "confirmed_direct_true", "confirmed_platform_true",
                  "confirmed_both_true", "direct_false_positive",
                  "platform_false_positive", "evidence_insufficient", "rule_or_route_error")

_PUNCT = re.compile(r"[，,。；;：:、\"'“”‘’（）()\[\]【】《》<>…\.\-—_|/\s\u00a0\u3000]+")

# W-19：同引文跨码复用的判定参数（确定性、可回放；不做语义判真）
QUOTE_REUSE_MIN_CODES = 2          # 同一引文被 >=2 个规则码引用 → conflict/待核验
QUOTE_RELEVANCE_MIN_BIGRAMS = 2    # 问题描述与引文共享 >=2 个内容 bigram → strong
QUOTE_RELEVANCE_MIN_CHARS = 3      # 或共享 >=3 个内容汉字且 >=1 个 bigram（短引文场景）
QUOTE_RELEVANCE_WEAK_CHARS = 2     # 仅共享 >=2 个内容汉字（无 bigram）→ weak

# 工作单（人工复核视图）CSV 列：**不含任何 gold 字段与 auto_suggested_label**（W-05/Alt-D）
CSV_FIELDS = [
    "row_id", "case_id", "bucket", "match_key_code", "match_key_clause",
    "match_key_subject", "match_key_issue_type",
    "direct_run_ids", "direct_quote_check", "direct_quote_match_status",
    "direct_quote", "direct_issue", "direct_reason", "direct_confidence",
    "platform_finding_id", "platform_quote_check", "platform_quote_match_status",
    "platform_quote", "platform_summary", "platform_severity", "platform_rule_version",
    "platform_anchor", "auto_similarity", "platform_uncovered_reason",
    "quote_reuse_conflict", "quote_reuse_codes", "weak_locator",
    "match_relation", "match_confidence", "match_span", "instance_count",
    "human_status", "human_label", "human_actor", "human_reason",
]
# 后台 gold 账本列（只进后台文件/账本，不进人工工作单；W-05）
BACKEND_LEDGER_FIELDS = [
    "row_id", "case_id", "bucket", "match_key_code", "gold_hit", "gold_issue_id",
    "gold_primary", "auto_suggested_label", "auto_note", "direct_item_index",
    "platform_finding_id", "quote_verbatim", "visible",
]
WORKLIST_DIRECT_INDEX_FIELDS = ("direct_index", "platform_index")

QUOTE_MATCH_STATUSES = ("exact", "exact_after_trim", "normalized_ws", "not_found")

# V3.2 §8 Alt-A：匹配主键 = document_id + char_span 重叠 + issue_type；code 降特征。
# W-18：similarity（含包含奖励）只作候选特征，不单独决定同一性。
MATCH_GRAPH_VERSION = "match/alt-a/v1"
SPAN_OVERLAP_MIN = 0.5                 # 同一实例：较短区间重叠比 >= 0.5
SAME_CODE_EVIDENCE_MIN = 0.6           # 同码但无坐标重叠 → 仅弱候选（不同实例）
CROSS_CODE_CONFLICT_MIN_OVERLAP = 0.8  # 同位置跨码 → 归属冲突（conflict）
ISSUE_TYPE_UNKNOWN = ("", "其他", "unknown", "n/a", "none", "未分类")


# --------------------------------------------------------------------------- text utils
def norm(s: str) -> str:
    return _PUNCT.sub("", str(s or ""))


def similarity(a: str, b: str) -> float:
    """归一化文本相似度（0..1）：包含关系给强分，否则用最长公共子串占比。"""
    a2, b2 = norm(a), norm(b)
    if not a2 or not b2:
        return 0.0
    if a2 in b2 or b2 in a2:
        mn, mx = min(len(a2), len(b2)), max(len(a2), len(b2))
        if mn >= 6:
            return max(0.8, mn / mx)
        return 0.4
    sm = difflib.SequenceMatcher(None, a2, b2)
    m = sm.find_longest_match(0, len(a2), 0, len(b2))
    return round(m.size / max(1, min(len(a2), len(b2))), 4)


def text_overlap(answer_text: str, item_text: str, min_len: int = 8) -> bool:
    """答案证据片段与草稿/finding 文本的包含或高相似匹配（与既有评分口径一致的判定语义）。"""
    a = norm(answer_text)
    b = norm(item_text)
    if not a or not b:
        return False
    if (a in b or b in a) and len(a) >= 4:
        return True
    if len(a) < min_len:
        return False
    if len(a) <= 80:
        if len(b) < 4:
            return False
        sm = difflib.SequenceMatcher(None, a, b)
        best = sm.find_longest_match(0, len(a), 0, len(b))
        return best.size >= max(min_len, int(len(a) * 0.5))
    return difflib.SequenceMatcher(None, a, b).ratio() >= 0.6


def quote_match_status(qc: dict | None) -> str:
    """quote_check → V3.2 四态 quote_match_status（兼容旧 status 词表）。"""
    qc = qc or {}
    explicit = str(qc.get("quote_match_status") or "").strip()
    if explicit in QUOTE_MATCH_STATUSES:
        return explicit
    status = str(qc.get("status") or "").strip()
    if status in ("exact", "exact_after_trim"):
        return status
    if status == "normalized_ws":
        return "normalized_ws"
    return "not_found"


def _content_bigrams(text: str) -> set:
    t = norm(text)
    return {t[i:i + 2] for i in range(len(t) - 1)}


def quote_relevance_check(quote: str, issue_text: str) -> dict:
    """引文相关性校验（W-19）：逐字命中 ≠ 该引文支持该规则结论。

    确定性口径：引文与“问题描述/规则判据”（不含引文本身）共享的内容 bigram 数。
    strong（>=2 个）/ weak（1 个）/ none（0 个）/ unknown（缺引文或问题文本）。
    只作“是否需人工核验相关性”的提示，不单独判真/判假。
    """
    qn = norm(quote)
    tn = norm(issue_text)
    if not qn or not tn:
        return {"status": "unknown", "overlap_bigrams": 0, "shared": []}
    shared = sorted(_content_bigrams(quote) & _content_bigrams(issue_text))
    n = len(shared)
    shared_chars = sorted(set(qn) & set(tn))
    if n >= QUOTE_RELEVANCE_MIN_BIGRAMS or (
            n >= 1 and len(shared_chars) >= QUOTE_RELEVANCE_MIN_CHARS):
        status = "strong"
    elif n >= 1 or len(shared_chars) >= QUOTE_RELEVANCE_WEAK_CHARS:
        status = "weak"
    else:
        status = "none"
    return {"status": status, "overlap_bigrams": n,
            "shared": shared[:20], "shared_chars": shared_chars[:20],
            "note": ("引文与问题描述有明显相关性线索" if status == "strong" else
                     ("仅少量重叠，相关性需人工核验" if status == "weak" else
                      "问题描述与引文无重叠：逐字命中不足以支撑本规则结论，需人工核验相关性"))}


def _item_issue_text(desc: dict) -> str:
    return "\n".join(str(x) for x in (desc.get("issue"), desc.get("reason"),
                                      desc.get("summary"), desc.get("title"),
                                      desc.get("detail")) if str(x or "").strip())


def quote_reuse_groups(descriptors: list, side: str = "") -> dict:
    """同一引文跨规则码复用检测（W-19）：返回 {归一引文: {...}}。

    只在**同一侧同一 case** 内按归一化引文分组；不同规则码数 >= QUOTE_REUSE_MIN_CODES
    即视为“同引文跨码复用”，该组内每条都不能仅凭逐字命中 visible 为真。
    """
    groups: dict = {}
    for desc in descriptors or []:
        if not isinstance(desc, dict):
            continue
        quote = str(desc.get("quote") or "")
        code = str(desc.get("code") or desc.get("rule_code") or "")
        qkey = _strip_ws_norm(quote)
        if not qkey or not code:
            continue
        g = groups.setdefault(qkey, {"quote": quote, "side": side,
                                     "codes": [], "items": [], "id": ""})
        if code not in g["codes"]:
            g["codes"].append(code)
        g["items"].append({"id": str(desc.get("id") or desc.get("item_index") or ""),
                           "code": code, "relevance": quote_relevance_check(
                               quote, _item_issue_text(desc))})
    out = {}
    for qkey, g in groups.items():
        if len(g["codes"]) >= QUOTE_REUSE_MIN_CODES:
            g["codes"] = sorted(g["codes"])
            g["count"] = len(g["codes"])
            g["item_count"] = len(g["items"])
            g["conflict"] = True
            g["reason"] = (f"同一引文被 {g['count']} 个规则码复用"
                           f"（{','.join(g['codes'])}）→ conflict/待核验")
            out[qkey] = g
    return out


def annotate_quote_reuse(descriptors: list, side: str = "") -> tuple:
    """给一组描述符打上 W-19 quote_reuse 标记（就地返回新 list）。

    返回 (annotated, groups)。命中复用组的每条 descriptor 会带：
    quote_reuse_conflict / quote_reuse_codes / quote_reuse_count /
    quote_reuse_side / quote_relevance / relation=unresolved。
    """
    groups = quote_reuse_groups(descriptors, side)
    if not groups:
        return list(descriptors or []), {}
    by_qkey = {}
    for qkey, g in groups.items():
        for it in g["items"]:
            by_qkey.setdefault((qkey, it["id"], it["code"]), it)
    out = []
    for desc in descriptors or []:
        if not isinstance(desc, dict):
            out.append(desc)
            continue
        d = dict(desc)
        qkey = _strip_ws_norm(str(d.get("quote") or ""))
        code = str(d.get("code") or d.get("rule_code") or "")
        ident = str(d.get("id") or d.get("item_index") or "")
        g = groups.get(qkey)
        if g and code in g["codes"]:
            item_info = by_qkey.get((qkey, ident, code), {})
            d["quote_reuse_conflict"] = True
            d["quote_reuse_codes"] = list(g["codes"])
            d["quote_reuse_count"] = g["count"]
            d["quote_reuse_side"] = side
            d["quote_relevance"] = item_info.get("relevance") or quote_relevance_check(
                str(d.get("quote") or ""), _item_issue_text(d))
            d["quote_reuse"] = {"conflict": True, "codes": list(g["codes"]),
                                "count": g["count"], "side": side,
                                "quote": g["quote"],
                                "relevance": d["quote_relevance"]}
            d["relation"] = "unresolved"
        out.append(d)
    return out, groups


def _strip_ws_norm(text: str) -> str:
    return re.sub(r"[\s\u00a0\u3000]+", "", str(text or ""))


# --------------------------------------------------------------------------- occurrence 台账
def _occurrence_ids_of(obj: dict) -> list:
    """读取 occurrence 台账 ID 列表（occurrence_ids / occurrence_ids_json）。"""
    obj = obj or {}
    ids = obj.get("occurrence_ids")
    if not ids:
        raw = obj.get("occurrence_ids_json")
        if isinstance(raw, str):
            try:
                import json as _json
                ids = _json.loads(raw or "[]")
            except Exception:  # noqa: BLE001
                ids = []
        else:
            ids = raw or []
    if isinstance(ids, str):
        ids = [x.strip() for x in ids.replace("|", ",").split(",")]
    out = []
    for x in ids or []:
        x = str(x or "").strip()
        if x:
            out.append(x)
    return list(dict.fromkeys(out))


def _occurrence_spans_of(obj: dict) -> list:
    """读取 occurrence 台账里的字符区间（[{"start","end"}] 或 [[s,e]]）。"""
    obj = obj or {}
    raw = obj.get("occurrence_spans") or obj.get("occurrences") or []
    out = []
    for occ in raw if isinstance(raw, list) else []:
        try:
            if isinstance(occ, dict):
                span = occ.get("char_span") or occ
                st, en = span.get("start"), span.get("end")
                if st is None and span.get("offset") is not None:
                    st = int(span["offset"])
                    en = st + int(span.get("length") or 0)
                if st is not None and en is not None:
                    out.append({"start": int(st), "end": int(en)})
            elif isinstance(occ, (list, tuple)) and len(occ) == 2:
                out.append({"start": int(occ[0]), "end": int(occ[1])})
        except (TypeError, ValueError):
            continue
    return out


# --------------------------------------------------------------------------- descriptors
def normalize_direct_item(item: dict, case_id: str = "") -> dict:
    qc = item.get("quote_check") or {}
    quote = item.get("quote") or ""
    text = "\n".join(x for x in (quote, item.get("issue"), item.get("reason"),
                                 item.get("issue_type_raw")) if str(x or "").strip())
    return {
        "source": "direct",
        "case_id": case_id,
        "item_index": item.get("merged_index", item.get("item_index")),
        "run_ids": list(item.get("run_ids") or []),
        "runs_seen": item.get("runs_seen"),
        "runs_total": item.get("runs_total"),
        "stable": item.get("stable"),
        "draft_file_sha256": list(item.get("draft_file_sha256") or []),
        "code": str(item.get("rule_code") or "").strip(),
        "quote": quote,
        "quote_check": qc,
        "quote_match_status": quote_match_status(qc),
        "weak_locator": (quote_match_status(qc) == "normalized_ws"
                         and qc.get("offset") is not None),
        "offset": qc.get("offset"),
        "line": qc.get("line"),
        "issue": item.get("issue") or "",
        "reason": item.get("reason") or "",
        "subject": item.get("subject") or "",
        "issue_type": item.get("issue_type") or "",
        "issue_type_raw": item.get("issue_type_raw") or "",
        "location_hint": item.get("location_hint") or "",
        "confidence": item.get("confidence"),
        "text": text,
        "raw_item": item.get("raw_item") or {},
        # Alt-E（W-13）：instance_count 唯一来源 = occurrence 台账；缺失保留空，不补 1
        "occurrence_ids": (_occurrence_ids_of(item)
                           or _occurrence_ids_of(item.get("raw_item") or {})),
        "occurrence_spans": (_occurrence_spans_of(item)
                             or _occurrence_spans_of(item.get("raw_item") or {})),
    }


def normalize_finding(finding: dict, doc_text: str = "") -> dict:
    from . import direct_draft

    evidence = [e for e in (finding.get("evidence") or []) if isinstance(e, dict)]
    quotes = [str(e.get("quote") or "").strip() for e in evidence if str(e.get("quote") or "").strip()]
    if not quotes:
        for k in ("quote", "excerpt"):
            if str(finding.get(k) or "").strip():
                quotes = [str(finding.get(k)).strip()]
                break
    quote = quotes[0] if quotes else ""
    anchors = list(finding.get("anchor_ids") or [])
    if finding.get("anchor_id"):
        anchors.append(str(finding["anchor_id"]))
    for e in evidence:
        for k in ("anchor_id", "anchor"):
            if str(e.get(k) or "").strip():
                anchors.append(str(e[k]))
    text = "\n".join(x for x in [quote, finding.get("summary"), finding.get("title"),
                                 finding.get("detail")] + quotes if str(x or "").strip())
    qc = direct_draft.locate_quote(doc_text, quote) if doc_text else {}
    return {
        "source": "platform",
        "id": str(finding.get("id") or ""),
        "code": str(finding.get("code") or finding.get("rule_code") or
                    finding.get("point_id") or "").strip(),
        "quote": quote,
        "quotes": quotes,
        "quote_check": qc,
        "quote_match_status": quote_match_status(qc),
        "weak_locator": (quote_match_status(qc) == "normalized_ws"
                         and qc.get("offset") is not None),
        "offset": qc.get("offset"),
        "line": qc.get("line"),
        "summary": finding.get("summary") or "",
        "title": finding.get("title") or "",
        "detail": finding.get("detail") or "",
        "subject": finding.get("subject") or "",
        "issue_type": direct_draft.normalize_issue_type(finding.get("issue_type") or finding.get("category") or ""),
        "severity": finding.get("severity") or "",
        "state": finding.get("state") or "",
        "rule_version": finding.get("rule_version") or "",
        "risk_level": finding.get("risk_level") or "",
        "rule_risk_level": finding.get("rule_risk_level") or "",
        "rule_version_meta": finding.get("rule_version_meta") or {},
        "origin": finding.get("origin") or "",
        "object_id": finding.get("object_id") or "",
        "subrequirement_id": finding.get("subrequirement_id") or "",
        "occurrence_count": finding.get("occurrence_count"),
        # Alt-E（W-13）：instance_count 唯一来源 = occurrence 台账；缺失保留空，不补 1
        "occurrence_ids": _occurrence_ids_of(finding),
        "occurrence_spans": _occurrence_spans_of(finding),
        "anchor_ids": sorted(set(a for a in anchors if a)),
        "text": text,
        "raw_finding": finding,
    }


# --------------------------------------------------------------------------- matching (Alt-A)
# V3.2 §8（Alt-A）匹配主键：
#   document_id + char_span 重叠 + issue_type；code 降为特征，**不作硬门槛**；
#   允许 1:N / N:1（一条聚合 finding 覆盖多个实例 / 多条拆分 finding 对同一实例）；
#   输出 match_graph（每对带 span/相似度/码）与 split/merge lineage。
# W-18：相似度（含“包含关系”奖励）**只作特征**，不能单独决定同一性；
#       同一性由坐标（char_span 重叠）+ issue_type + code（特征）+ 人工确认决定。
RELATION_SAME_INSTANCE = "same_instance"                    # 同码 + 坐标重叠
RELATION_SAME_INSTANCE_CROSS_CODE = "same_instance_cross_code"  # 坐标重叠、规则码不同（归属冲突）
RELATION_SAME_INSTANCE_ALIAS_CODE = "same_instance_alias_code"  # 坐标重叠、规则码同族（可解释别名）
RELATION_SAME_CODE_OTHER_INSTANCE = "same_code_other_instance"  # 同码但坐标不重叠（不同实例）
RELATION_UNMATCHED = "unmatched"


# --------------------------------------------------------------------------- 可解释码别名 / 同问题簇（T-53 码归属层）
# 用途（严格限定）：只在**已由坐标确认是同一问题实例**的前提下，判断两侧“规则码不同”
#   是“归属冲突（conflict）”还是“同一缺陷维度的粗/细粒度或近义规则码（同族异码）”。
# 禁止用途：不用于合并问题实例、不用于放宽同一性门槛（实例仍由 char_span 重叠 + issue_type 决定）、
#   不参与预测/不改变候选内容、不读 gold。
# 码族表来源：P01 包级审核规则 83 条规则自身的“分类/二级类型/适用条件/核查步骤”语义
#   （规则库定义，非答案/gold 反推）；每族给出归类依据，可逐族复核。
# 注意：同族 ≠ 同一问题；不同族也不等于码错（只是“不能据此认定归属一致”）。
CODE_FAMILIES = (
    {"family": "duplicate", "label": "重复/冗余",
     "rationale": "同一事实被无意义重复或重复计入（核查对象=重复片段与清单关系）",
     "codes": ("P01-O01",)},
    {"family": "missing", "label": "要素/取值/响应缺失或不可执行",
     "rationale": "执行所需的对象、取值、算法或响应要素缺失/不可执行（不是数值算错，是要素不齐）",
     "codes": ("P01-O02", "P01-O03", "P01-O09", "F02-001", "F02-004",
               "F02-007", "D03-001")},
    {"family": "consistency", "label": "前后/跨位置一致性",
     "rationale": "同一事实、概念、数值或属性在不同位置表述不一致（核查=对齐后再比较）",
     "codes": ("P01-O04", "P01-O12", "D01-001", "D02-001", "D02-002",
               "D02-003", "D02-004", "F01-005", "C08-007", "C07-005")},
    {"family": "numeric", "label": "数值计算/勾稽/复算",
     "rationale": "数值本身按变量、运算、精度复算不成立，或分项合计勾稽不符",
     "codes": ("P01-O10", "C01-001", "C01-004", "C01-005", "C08-002",
               "C08-003", "F04-004")},
    {"family": "unit", "label": "单位/量纲/计量基准",
     "rationale": "计量单位、量纲或基准不可比/换算不一致（含单位与计量对象不匹配）",
     "codes": ("P01-O06", "C06-002", "C06-003", "C10-001", "C10-003")},
    {"family": "datetime", "label": "日期/期限/时点约束",
     "rationale": "日期值可解析性、时点先后与期限依赖、有效期覆盖（核查对象=时间表达与约束）",
     "codes": ("P01-O05", "P01-O08", "C09-001", "C09-002", "C09-003",
               "C09-004", "A04-002")},
    {"family": "qualification", "label": "资质/人员/资格",
     "rationale": "主体身份、资质类别等级、执业人员与资格要求的对应关系",
     "codes": ("A02-002", "A02-003", "A02-004", "A02-006", "A01-002",
               "A01-003", "A01-005", "F08-002", "F08-004")},
    {"family": "scope", "label": "范围/边界/需求清楚",
     "rationale": "采购或义务范围、责任边界、例外边界是否清楚可执行",
     "codes": ("F02-006", "D05-002", "D07-003", "D09-001", "D09-002")},
    {"family": "price", "label": "报价/限价/计价",
     "rationale": "报价数量、限价、暂列金额、计价口径与采购/限价要求的关系",
     "codes": ("C08-001", "C08-005", "C08-006", "F04-001", "F10-004")},
    {"family": "procedure", "label": "主体/签署/程序/合同条款",
     "rationale": "签署审批、决议权限、权利义务与合同条款的程序性/对等性要求",
     "codes": ("A04-001", "E01-002", "E01-004", "F09-002", "F12-001",
               "F06-004", "A05-001", "E04-001", "E07-001")},
    {"family": "format_ref", "label": "结构/格式/引用/术语",
     "rationale": "章节结构、格式可读性、交叉引用有效性与术语定义对应",
     "codes": ("P01-O07", "P01-O11", "B01-005", "B03-002", "B03-003",
               "B04-002", "B04-006", "B05-003", "B05-004", "C12-004")},
    {"family": "review", "label": "评审/否决/合规底线",
     "rationale": "评审条件、否决项认定与强制/建议属性的一致性",
     "codes": ("F01-001", "F01-002", "F01-006")},
    {"family": "argument", "label": "证据/论证/结论支撑",
     "rationale": "结论是否有事实对应、论证链无反例、证据时间/目录可支持结论",
     "codes": ("C12-003", "D04-003", "D08-004")},
    {"family": "disclosure", "label": "披露/绩效",
     "rationale": "披露形式渠道要求与绩效目标/考核指标关系",
     "codes": ("G03-001", "G04-003")},
)
CODE_FAMILY_BY_CODE = {code: fam for fam in CODE_FAMILIES for code in fam["codes"]}


def code_family(code: str) -> dict | None:
    """规则码 → 码族（未登记返回 None；不猜、不模糊匹配）。"""
    fam = CODE_FAMILY_BY_CODE.get(str(code or "").strip())
    return dict(fam) if fam else None


def _code_family_version() -> dict:
    """码族表版本/指纹（可审计：数量 + 全表 sha256）。"""
    import hashlib
    import json as _json
    payload = _json.dumps(CODE_FAMILIES, ensure_ascii=False, sort_keys=True)
    return {"version": "code-family/v1", "families": len(CODE_FAMILIES),
            "codes": len(CODE_FAMILY_BY_CODE),
            "sha256": hashlib.sha256(payload.encode("utf-8")).hexdigest()}


def codes_equivalent(code_a: str, code_b: str) -> dict:
    """两侧规则码的归属一致性（可解释）。

    - exact：字符串相同；
    - same_family：均已登记且同族（粗/细粒度或近义规则码，同一缺陷维度）；
    - different：其余（不据此判码错，只表示“不能认定归属一致”）。
    """
    a, b = str(code_a or "").strip(), str(code_b or "").strip()
    if a and a == b:
        return {"equivalent": True, "relation": "exact", "family": None,
                "family_label": "", "rationale": "规则码相同"}
    fa, fb = code_family(a), code_family(b)
    if fa and fb and fa["family"] == fb["family"]:
        return {"equivalent": True, "relation": "same_family",
                "family": fa["family"], "family_label": fa["label"],
                "rationale": fa["rationale"]}
    return {"equivalent": False, "relation": "different", "family": None,
            "family_label": "", "rationale": "未登记同族关系"}


def issue_type_known(desc: dict) -> bool:
    """issue_type 是否为可比类型（空/“其他”/unknown 视为未知，不参与冲突判定）。"""
    return str((desc or {}).get("issue_type") or "").strip() not in ISSUE_TYPE_UNKNOWN


def _span(desc: dict):
    """描述符主 quote span（offset/length），无坐标返回 None。"""
    off = desc.get("offset")
    length = (desc.get("quote_check") or {}).get("length") if isinstance(
        desc.get("quote_check"), dict) else None
    if length is None and desc.get("span_length") is not None:
        length = desc.get("span_length")
    length = length or len(desc.get("quote") or "")
    if off is None:
        return None
    try:
        return (int(off), int(off) + int(length))
    except (TypeError, ValueError):
        return None


def _span_pairs(desc: dict) -> list:
    """描述符全部 span：主 quote span + occurrence 台账 span（Alt-A 坐标证据）。"""
    spans = []
    s = _span(desc)
    if s is not None:
        spans.append(s)
    for occ in desc.get("occurrence_spans") or []:
        try:
            if isinstance(occ, dict):
                st, en = occ.get("start"), occ.get("end")
                if st is None and occ.get("offset") is not None:
                    st = int(occ["offset"])
                    en = st + int(occ.get("length") or 0)
                if st is not None and en is not None:
                    spans.append((int(st), int(en)))
            elif isinstance(occ, (list, tuple)) and len(occ) == 2:
                spans.append((int(occ[0]), int(occ[1])))
        except (TypeError, ValueError):
            continue
    return list(dict.fromkeys(spans))


def instance_count_from_occurrence_ledger(desc: dict) -> dict:
    """Alt-E（W-13）：instance_count 只从 occurrence 台账读；缺失 → None + reason。

    禁止 ``max(1, len(...))`` 之类补齐：台账缺失时输出 null 并写明原因，
    不猜、不补 1（详见 V3.2 §11.3 / Qoder W-13）。
    """
    uniq = _occurrence_ids_of(desc or {})
    if uniq:
        return {"instance_count": len(uniq), "source": "occurrence_ids",
                "occurrence_ids": uniq, "reason": ""}
    return {"instance_count": None, "source": "null", "occurrence_ids": [],
            "reason": "occurrence_ledger_missing"}


def instance_ledger(items: list) -> dict:
    """逐 item 输出 instance 台账（occurrence_ids 为准；缺失 null+reason）。"""
    rows, known_total, missing = [], 0, 0
    for i, it in enumerate(items or []):
        info = instance_count_from_occurrence_ledger(it)
        rows.append({"item_index": i, **info})
        if info["instance_count"] is not None:
            known_total += info["instance_count"]
        else:
            missing += 1
    return {"rows": rows, "items": len(rows),
            "known_instance_count": known_total,
            "missing_ledger_items": missing,
            "null_reason": "occurrence_ledger_missing" if missing else "",
            "policy": ("instance_count 读 occurrence_ids；缺失 null+reason；"
                       "禁止 max(1,...) 补 1")}


def _overlap_ratio(a, b) -> float:
    """两个 [start, end) 区间的重叠比（重叠长度 / 较短区间长度）。"""
    if not a or not b:
        return 0.0
    inter = min(a[1], b[1]) - max(a[0], b[0])
    if inter <= 0:
        return 0.0
    shortest = max(1, min(a[1] - a[0], b[1] - b[0]))
    return inter / shortest


def _span_gap(a, b) -> int:
    if not a or not b:
        return 10 ** 9
    return max(0, max(a[0], b[0]) - min(a[1], b[1]))


def _best_span_overlap(desc_a: dict, desc_b: dict) -> tuple:
    """两侧全部 span（主 quote span + occurrence 台账 span）中最佳重叠。"""
    best = (0.0, None, None, 10 ** 9)
    for sa in _span_pairs(desc_a):
        for sb in _span_pairs(desc_b):
            ratio = _overlap_ratio(sa, sb)
            gap = _span_gap(sa, sb)
            if ratio > best[0] or (ratio == best[0] and gap < best[3]):
                best = (ratio, sa, sb, gap)
    return best


def _pair_features(d: dict, p: dict, doc_text: str = "") -> dict:
    """一对 (direct, platform) 的匹配特征。

    注意：``quote_sim``/``text_sim``/``score`` 只用于排序与展示（特征），
    不单独决定“同一实例”；同一性看 ``same_instance``（char_span 重叠）。
    ``code_alias`` 是可解释码族判定（T-53），仅在已确认同一实例后用于区分
    “同族异码”与“归属冲突”，不参与同一性判定。
    """
    code_same = bool(d.get("code")) and d.get("code") == p.get("code")
    code_alias = codes_equivalent(d.get("code"), p.get("code"))
    q_sim = similarity(d.get("quote") or "", p.get("quote") or "")
    t_sim = similarity(d.get("text") or "", p.get("text") or "")
    overlap, d_span, p_span, gap = _best_span_overlap(d, p)
    d_span_primary, p_span_primary = _span(d), _span(p)
    same_instance = overlap >= SPAN_OVERLAP_MIN
    if d_span_primary and p_span_primary:
        span_source = "char_span"
    elif same_instance:
        span_source = "occurrence_ledger"
    else:
        span_source = "missing"
    issue_known = issue_type_known(d) and issue_type_known(p)
    issue_same = (d.get("issue_type") == p.get("issue_type")) if issue_known else None
    subject_same = None
    if str(d.get("subject") or "").strip() and str(p.get("subject") or "").strip():
        subject_same = norm(d["subject"]) == norm(p["subject"])
    evidence_aligned = bool(same_instance and (code_same or issue_same is True or
                                               q_sim >= 0.6 or t_sim >= 0.6))
    # confidence 仅用于排序/展示（不是真值概率）：坐标重叠为主，码/类型/文本为辅
    confidence = round(
        0.55 * (min(1.0, overlap) if same_instance else 0.0)
        + 0.15 * (1.0 if code_same else 0.0)
        + 0.10 * (1.0 if issue_same is True else 0.0)
        + 0.10 * q_sim
        + 0.05 * t_sim
        + 0.05 * (1.0 if issue_same is not False else 0.0), 4)
    return {
        "code_same": code_same, "code_alias": code_alias,
        "quote_sim": round(q_sim, 4),
        "text_sim": round(t_sim, 4), "span_overlap": round(overlap, 4),
        "span_gap": gap, "span_source": span_source,
        "direct_span": d_span, "platform_span": p_span,
        "same_instance": same_instance, "issue_known": issue_known,
        "issue_same": issue_same, "subject_same": subject_same,
        "evidence_aligned": evidence_aligned, "confidence": confidence,
        "score": confidence,   # 兼容旧键：仅特征分，不是真值
    }


def _edge_layers(graph_edges: list) -> dict:
    """把候选边分成分层匹配结果（不强制 1:1）。

    T-53：``code_alias`` 层 = 坐标确认同一实例且规则码同族（可解释别名）；
    与同码层一样按“同一实例”处理（both/归属一致），但**只在显式启用**
    ``alias_families`` 时才产生（默认关闭，保持既有行为可回归）。
    """
    same_instance = [e for e in graph_edges if e["same_instance"]]
    layer1 = [e for e in same_instance if e["code_same"]]
    alias_layer = [e for e in same_instance
                   if e["relation"] == RELATION_SAME_INSTANCE_ALIAS_CODE]
    # 跨码归属冲突：只处理“同码/同族层未匹配”的剩余节点（避免同引文跨码复用造成 N×M 爆炸）；
    # 允许 1:N/N:1（一个剩余平台 finding 可对多个剩余直连实例 ⇒ W-19 conflict 聚合）。
    used_d = {e["direct_index"] for e in layer1 + alias_layer}
    used_p = {e["platform_index"] for e in layer1 + alias_layer}
    cross_left = [e for e in same_instance
                  if e["relation"] == RELATION_SAME_INSTANCE_CROSS_CODE
                  and e["direct_index"] not in used_d and e["platform_index"] not in used_p
                  and e["span_overlap"] >= CROSS_CODE_CONFLICT_MIN_OVERLAP]
    # 每个剩余直连实例只保留一个“最佳跨码归属冲突”代表（同一平台 finding 可被多个直连
    # 实例复用 = N:1），避免同引文跨多码时产生 N×M 冲突行（W-19 已单独标 quote_reuse）。
    best_by_direct = {}
    for e in sorted(cross_left, key=lambda x: (-x["span_overlap"], -x["quote_sim"],
                                               -x["text_sim"], -x["confidence"],
                                               x["platform_index"])):
        best_by_direct.setdefault(e["direct_index"], e)
    layer2 = [best_by_direct[k] for k in sorted(best_by_direct)]
    weak = [e for e in graph_edges
            if e["relation"] == RELATION_SAME_CODE_OTHER_INSTANCE]
    return {"same_code_same_instance": layer1,
            "alias_code_same_instance": alias_layer,
            "cross_code_same_instance": layer2,
            "same_code_other_instance": weak}


def _lineage_for(D: list, P: list, matched_edges: list) -> dict:
    """显式记录 merge（聚合覆盖）与 split（拆分 finding 对同一实例）谱系。"""
    merge, split = [], []
    by_p, by_d = collections.defaultdict(list), collections.defaultdict(list)
    for e in matched_edges:
        by_p[e["platform_index"]].append(e["direct_index"])
        by_d[e["direct_index"]].append(e["platform_index"])
    for pi, d_idxs in sorted(by_p.items()):
        if len(d_idxs) > 1:
            info = instance_count_from_occurrence_ledger(P[pi])
            merge.append({"kind": "merge", "scope": "platform_aggregate",
                          "platform_index": pi,
                          "direct_indices": sorted(set(d_idxs)),
                          "occurrence_ids": info["occurrence_ids"],
                          "instance_count": info["instance_count"],
                          "source": info["source"],
                          "reason": "一条平台 finding（或 occurrence 台账）覆盖多个直连实例"})
    for di, p_idxs in sorted(by_d.items()):
        if len(p_idxs) > 1:
            merge.append({"kind": "merge", "scope": "direct_aggregate",
                          "direct_index": di,
                          "platform_indices": sorted(set(p_idxs)),
                          "reason": "一条直连 finding 覆盖多个平台 finding/实例"})
    for side, descs in (("direct", D), ("platform", P)):
        groups = collections.defaultdict(list)
        for i, desc in enumerate(descs):
            s = _span(desc)
            if s is not None:
                groups[(str(desc.get("code") or ""), s)].append(i)
        for (code, s), idxs in sorted(groups.items(), key=lambda kv: (str(kv[0]), kv[1])):
            if len(idxs) > 1:
                split.append({"kind": "split", "scope": f"{side}_split_same_instance",
                              "side": side, "indices": idxs, "code": code,
                              "char_span": {"start": s[0], "end": s[1]},
                              "reason": "同侧多条拆分 finding 指向同一实例（same code + char_span）"})
    return {"merge": merge, "split": split}


def build_match_graph(case_id: str, D: list, P: list, doc_text: str = "",
                      alias_families: bool = False) -> dict:
    """构造 Alt-A 匹配图：节点带 char_span，边带 relation/span/相似度/码/置信度。

    - 同一性（same_instance）= char_span 重叠 >= SPAN_OVERLAP_MIN（或 occurrence 台账覆盖）；
    - 同码且证据接近但坐标不重叠 → ``same_code_other_instance``（不同实例，不合并）；
    - 1:N/N:1 不强制一对一；merge/split 谱系单列；
    - ``alias_families=True`` 时，坐标确认同一实例、规则码同族（T-53 可解释码族）
      → ``same_instance_alias_code``（同族异码，归属一致而非冲突）；默认关闭。
    """
    edges = []
    for di, d in enumerate(D):
        for pi, p in enumerate(P):
            f = _pair_features(d, p, doc_text)
            if f["same_instance"]:
                if f["code_same"]:
                    relation = RELATION_SAME_INSTANCE
                elif alias_families and f.get("code_alias", {}).get("equivalent"):
                    relation = RELATION_SAME_INSTANCE_ALIAS_CODE
                else:
                    relation = RELATION_SAME_INSTANCE_CROSS_CODE
            elif f["code_same"] and (f["quote_sim"] >= SAME_CODE_EVIDENCE_MIN
                                     or f["text_sim"] >= 0.5):
                relation = RELATION_SAME_CODE_OTHER_INSTANCE
            else:
                continue
            edges.append({
                "direct_index": di, "platform_index": pi,
                "relation": relation, "same_instance": bool(f["same_instance"]),
                "code_same": f["code_same"], "issue_same": f["issue_same"],
                "span_overlap": f["span_overlap"], "span_gap": f["span_gap"],
                "span_source": f["span_source"],
                "quote_sim": f["quote_sim"], "text_sim": f["text_sim"],
                "confidence": f["confidence"], "evidence_aligned": f["evidence_aligned"],
                "code_alias": f.get("code_alias") or {},
                "direct_span": f["direct_span"], "platform_span": f["platform_span"],
                "evidence": {"direct_span": f["direct_span"],
                             "platform_span": f["platform_span"],
                             "span_overlap": f["span_overlap"],
                             "quote_sim": f["quote_sim"],
                             "direct_code": d.get("code") or "",
                             "platform_code": p.get("code") or "",
                             "code_alias": f.get("code_alias") or {},
                             "direct_quote": str(d.get("quote") or "")[:120],
                             "platform_quote": str(p.get("quote") or "")[:120]},
                "features": f,
            })
    layers = _edge_layers(edges)
    matched_edges = (layers["same_code_same_instance"]
                     + layers["alias_code_same_instance"]
                     + layers["cross_code_same_instance"])
    matched_d = {e["direct_index"] for e in matched_edges}
    matched_p = {e["platform_index"] for e in matched_edges}
    lineage = _lineage_for(D, P, matched_edges)
    nodes = {
        "direct": [{"index": i, "code": x.get("code") or "",
                    "issue_type": x.get("issue_type") or "",
                    "char_span": _span(x),
                    "span_source": ("char_span" if _span(x) else "missing"),
                    "quote": str(x.get("quote") or "")[:160],
                    "instance_count": instance_count_from_occurrence_ledger(x)["instance_count"],
                    "occurrence_ids": instance_count_from_occurrence_ledger(x)["occurrence_ids"]}
                   for i, x in enumerate(D)],
        "platform": [{"index": i, "code": x.get("code") or "",
                      "issue_type": x.get("issue_type") or "",
                      "char_span": _span(x),
                      "span_source": ("char_span" if _span(x) else "missing"),
                      "quote": str(x.get("quote") or "")[:160],
                      "instance_count": instance_count_from_occurrence_ledger(x)["instance_count"],
                      "occurrence_ids": instance_count_from_occurrence_ledger(x)["occurrence_ids"]}
                     for i, x in enumerate(P)],
    }
    stats = {
        "direct_items": len(D), "platform_findings": len(P),
        "edges": len(edges),
        "same_code_same_instance": len(layers["same_code_same_instance"]),
        "alias_code_same_instance": len(layers["alias_code_same_instance"]),
        "cross_code_same_instance": len(layers["cross_code_same_instance"]),
        "same_code_other_instance_edges": len(layers["same_code_other_instance"]),
        "matched_direct": len(matched_d), "matched_platform": len(matched_p),
        "direct_only": len(D) - len(matched_d),
        "platform_only": len(P) - len(matched_p),
        "merge_events": len(lineage["merge"]), "split_events": len(lineage["split"]),
    }
    return {
        "version": MATCH_GRAPH_VERSION,
        "case_id": case_id, "document_id": case_id, "span_unit": "char",
        "primary_key": ["document_id", "char_span_overlap", "issue_type"],
        "code_role": "feature_only",
        "multiplicity": "1:N/N:1 allowed",
        "nodes": nodes,
        "edges": edges,
        "matched_edges": matched_edges,
        "same_code_other_instance": layers["same_code_other_instance"],
        "alias_families": bool(alias_families),
        "code_families": _code_family_version(),
        "lineage": lineage,
        "stats": stats,
    }


def _classify_matched_edge(edge: dict) -> tuple:
    """匹配边 → (bucket, note)。坐标已确认同一实例，矛盾只在码/类型/证据对齐。"""
    f = edge.get("features") or {}
    if edge.get("relation") == RELATION_SAME_INSTANCE_ALIAS_CODE:
        alias = (edge.get("code_alias") or f.get("code_alias") or {})
        return "both", ("同一实例、规则码同族（同族异码；码族=%s，%s）"
                        % (alias.get("family_label") or alias.get("family") or "",
                           alias.get("rationale") or "可解释码别名"))
    if edge.get("relation") == RELATION_SAME_INSTANCE_CROSS_CODE:
        return "conflict", "同一位置/实例被归到不同规则码（归属冲突，code 仅特征）"
    if f.get("issue_same") is False:
        return "conflict", "同一实例下问题类型判定冲突（issue_type 不同）"
    if not f.get("evidence_aligned"):
        return "conflict", "同一实例但证据文本对齐不足（需人工核验）"
    return "both", "同一实例（坐标重叠 + 规则码一致）"


def _match_key(record: dict) -> dict:
    d = record.get("direct") or {}
    p = record.get("platform") or {}
    code = d.get("code") or p.get("code") or ""
    subject = d.get("subject") or p.get("subject") or ""
    issue_type = d.get("issue_type") or p.get("issue_type") or ""
    clause = d.get("location_hint") or (f"line:{d.get('line')}" if d.get("line") else "")
    if not clause and p.get("line"):
        clause = f"line:{p.get('line')}"
    return {"object": record.get("case_id") or d.get("case_id") or "",
            "clause_or_cell": clause, "subject": subject,
            "issue_type": issue_type, "rule_code": code}


def _record_match_evidence(edge: dict) -> dict:
    f = edge.get("features") or {}
    return {
        "char_span": {"direct": edge.get("direct_span"),
                      "platform": edge.get("platform_span")},
        "span_overlap": edge.get("span_overlap"),
        "span_source": edge.get("span_source"),
        "quote_similarity": edge.get("quote_sim"),
        "text_similarity": edge.get("text_sim"),
        "code_same": edge.get("code_same"),
        "code_alias": edge.get("code_alias") or {},
        "issue_same": edge.get("issue_same"),
        "rule": {"direct_code": (f.get("direct_code") or ""),
                 "platform_code": (f.get("platform_code") or "")},
    }


def compare_case(case_id: str, doc_text: str, direct_items: list, findings: list,
                 alias_families: bool = False) -> dict:
    """Alt-A 匹配 + 四桶分组（只提示，不写人工结论、不按 gold 调序）。

    相对旧实现（W-03/W-18 修复）：
    1. 匹配主键改 document_id + char_span 重叠 + issue_type；不再先按 code 过滤候选；
    2. 允许 1:N/N:1，不使用 1:1 贪心/增广路强行配对；
    3. 输出 match_graph（节点 span + 边 span/相似度/码）与 merge/split lineage；
    4. 同码但坐标不重叠 = 不同实例（direct_only/platform_only），不再伪造成“已匹配其他实例”。
    """
    D = [normalize_direct_item(x, case_id) for x in direct_items]
    P = [normalize_finding(x, doc_text) for x in findings]
    if doc_text:
        D = [_ensure_span(x, doc_text) for x in D]
        P = [_ensure_span(x, doc_text) for x in P]
    D, direct_reuse = annotate_quote_reuse(D, side="direct")
    P, platform_reuse = annotate_quote_reuse(P, side="platform")

    graph = build_match_graph(case_id, D, P, doc_text,
                              alias_families=alias_families)
    matched_edges = graph["matched_edges"]
    matched_d = {e["direct_index"] for e in matched_edges}
    matched_p = {e["platform_index"] for e in matched_edges}
    by_code_p = collections.defaultdict(list)
    by_code_d = collections.defaultdict(list)
    for pi, p in enumerate(P):
        by_code_p[str(p.get("code") or "")].append(pi)
    for di, d in enumerate(D):
        by_code_d[str(d.get("code") or "")].append(di)

    records = []
    # 1) 匹配到的实例对（both/conflict）；允许一节点出现在多条边（1:N/N:1）
    for e in matched_edges:
        di, pi = e["direct_index"], e["platform_index"]
        d, p = D[di], P[pi]
        bucket, note = _classify_matched_edge(e)
        rec = {"case_id": case_id, "bucket": bucket, "direct": d, "platform": p,
               "direct_index": di, "platform_index": pi, "features": e["features"],
               "auto_note": note,
               "match_relation": e["relation"],
               "match_confidence": e["confidence"],
               "match_evidence": _record_match_evidence(e),
               "same_instance": True, "human_confirmed": False,
               "char_span": {"direct": e["direct_span"],
                             "platform": e["platform_span"]},
               "occurrence_ids": (instance_count_from_occurrence_ledger(p)["occurrence_ids"]
                                  + instance_count_from_occurrence_ledger(d)["occurrence_ids"]),
               "instance_count": (instance_count_from_occurrence_ledger(p)["instance_count"]
                                  or instance_count_from_occurrence_ledger(d)["instance_count"])}
        rec["match_key"] = _match_key(rec)
        records.append(rec)
    # 2) 未匹配直连：用匹配图给出**真实**未覆盖原因（W-03：不再按 D5 状态猜“已匹配其他实例”）
    for di, d in enumerate(D):
        if di in matched_d:
            continue
        code = str(d.get("code") or "")
        same_p = list(by_code_p.get(code) or []) if code else []
        if same_p and any(pi in matched_p for pi in same_p):
            reason = "同码 finding 已匹配其他实例（证据/定位不同）"
            detail = "same_code_matched_other_instance"
        elif same_p:
            reason = "平台同码 finding 未匹配同一实例（证据/定位不同）"
            detail = "same_code_unmatched_evidence"
        else:
            reason = platform_uncovered_reason(code, None)
            detail = "no_same_code_finding"
        rec = {"case_id": case_id, "bucket": "direct_only", "direct": d,
               "platform": None, "direct_index": di, "platform_index": None,
               "features": {}, "auto_note": "无同实例平台 finding（坐标主键）",
               "match_relation": RELATION_UNMATCHED,
               "match_confidence": None, "same_instance": False,
               "human_confirmed": False, "platform_uncovered_reason": reason,
               "uncovered_detail": detail,
               "char_span": {"direct": _span(d), "platform": None},
               "occurrence_ids": instance_count_from_occurrence_ledger(d)["occurrence_ids"],
               "instance_count": instance_count_from_occurrence_ledger(d)["instance_count"]}
        rec["match_key"] = _match_key(rec)
        records.append(rec)
    # 3) 未匹配平台 finding
    for pi, p in enumerate(P):
        if pi in matched_p:
            continue
        code = str(p.get("code") or "")
        same_d = list(by_code_d.get(code) or []) if code else []
        if same_d:
            reason = "直连同码 finding 证据/定位不一致（未匹配同一实例）"
            detail = "same_code_unmatched_evidence"
        else:
            reason = "直连未报同码问题"
            detail = "no_same_code_finding"
        rec = {"case_id": case_id, "bucket": "platform_only", "direct": None,
               "platform": p, "direct_index": None, "platform_index": pi,
               "features": {}, "auto_note": "无同实例直连 finding（坐标主键）",
               "match_relation": RELATION_UNMATCHED,
               "match_confidence": None, "same_instance": False,
               "human_confirmed": False, "platform_uncovered_reason": reason,
               "uncovered_detail": detail,
               "char_span": {"direct": None, "platform": _span(p)},
               "occurrence_ids": instance_count_from_occurrence_ledger(p)["occurrence_ids"],
               "instance_count": instance_count_from_occurrence_ledger(p)["instance_count"]}
        rec["match_key"] = _match_key(rec)
        records.append(rec)
    return {"case_id": case_id, "doc_chars": len(doc_text),
            "direct_items": D, "platform_findings": P,
            "buckets": {b: int(collections.Counter(r["bucket"] for r in records).get(b, 0))
                        for b in BUCKETS},
            "records": records,
            "match_graph": graph,
            "match_graph_summary": graph["stats"],
            "lineage": graph["lineage"],
            "quote_reuse": {"direct": _reuse_summary(direct_reuse, "direct"),
                            "platform": _reuse_summary(platform_reuse, "platform"),
                            "conflict_count": _reuse_item_count(direct_reuse)
                                              + _reuse_item_count(platform_reuse)}}


def _ensure_span(desc: dict, doc_text: str) -> dict:
    """缺坐标时用 quote 回查文档补真实 span（W-02 locator；仅补坐标，不判真值）。"""
    if _span(desc) is not None or not doc_text:
        return desc
    quote = str(desc.get("quote") or "").strip()
    if not quote:
        return desc
    try:
        from . import direct_draft
        qc = direct_draft.locate_quote(doc_text, quote)
    except Exception:  # noqa: BLE001
        return desc
    if qc.get("offset") is None:
        return desc
    out = dict(desc)
    out["quote_check"] = qc
    out["offset"] = qc.get("offset")
    out["line"] = qc.get("line")
    out["quote_match_status"] = quote_match_status(qc)
    out["weak_locator"] = (quote_match_status(qc) == "normalized_ws"
                           and qc.get("offset") is not None)
    return out


def _reuse_summary(groups: dict, side: str) -> list:
    return [{"codes": g.get("codes") or [], "count": g.get("count") or 0,
             "item_count": g.get("item_count") or 0, "side": side,
             "quote": str(g.get("quote") or "")[:120], "conflict": True}
            for g in (groups or {}).values()]


def _reuse_item_count(groups: dict) -> int:
    return sum(int(g.get("item_count") or 0) for g in (groups or {}).values())


# --------------------------------------------------------------------------- gold reference (Alt-E)
def _match_value_first(value):
    """match_gold 的取值兼容：单 gold 为 int，聚合为 list（取首个作“主 gold”）。"""
    if isinstance(value, (list, tuple)):
        return value[0] if value else None
    return value


def _gold_evidence_score(item: dict, gold: dict) -> float:
    """item 证据与 gold snippets 的文本重合分（0..1，仅作候选排序特征）。"""
    text = str(item.get("text") or " ".join(item.get("quotes") or []) or "")
    best = 0.0
    for s in (gold.get("snippets") or []):
        s = str(s or "").strip()
        if not s:
            continue
        # 候选门槛沿用既有评分口径（逐字重叠/高相似）；相似度只用于排序特征，
        # 不因“短引文被长引文包含”就新增候选（W-18）
        if text_overlap(s, text):
            best = max(best, 1.0)
    return best


def match_gold(items: list, gold_entries: list, doc_text: str = "",
               *, max_instances: int | None = None) -> dict:
    """items ↔ gold 的**实例级**匹配（Alt-A/Alt-E，W-12）。

    - 允许 1:N：一条聚合 finding 覆盖多个实例（instance_count 从 occurrence 台账读）
      → 该 item 可匹配多个 gold（返回 list，TP 按实例计）；
    - 允许 N:1：多条拆分 finding 对同一 gold 实例 → 每个 item 都匹配该 gold
      （不再用 1:1 增广路强行拆开；TP 按 finding 计，FP=0）；
    - instance_count 必须来自 occurrence 台账（occurrence_ids），缺失不补 1：
      此时按单实例（1 个 gold）计，并在 scoring 里输出 null/reason。
    - 只用于统计口径（TP/FP/FN），不改 gold、不把直连输出当真值。
    """
    out: dict = {}
    for li, it in enumerate(items or []):
        code = str(it.get("code") or "")
        cands = []
        for gi, g in enumerate(gold_entries or []):
            if code and str(g.get("code") or "") != code:
                continue
            score = _gold_evidence_score(it, g)
            if score > 0:
                cands.append((score, gi))
        if not cands:
            continue
        cands.sort(key=lambda x: (-x[0], x[1]))
        info = instance_count_from_occurrence_ledger(it)
        cap = info["instance_count"]
        if max_instances is not None:
            cap = min(cap, max_instances) if cap is not None else max_instances
        chosen = [gi for _s, gi in (cands[:cap] if cap is not None else cands[:1])]
        if not chosen:
            continue
        out[li] = chosen if len(chosen) > 1 else chosen[0]
    return out


def score_gold_instances(items: list, gold_entries: list, doc_text: str = "") -> dict:
    """按实例计算 TP/FP/FN（W-12/EXP-3）。

    - TP = 匹配实例对数（聚合 item 覆盖 2 实例 → TP2；2 条拆分 finding 对 1 实例 → TP2）；
    - FP = 未匹配到任何 gold 的 item 数；
    - FN = gold 中未被任何 item 覆盖的实例数。
    禁止把“未匹配的聚合覆盖”用 max(1,...) 补齐。
    """
    mapping = match_gold(items, gold_entries, doc_text)
    pairs = []
    for li, val in mapping.items():
        for gi in (val if isinstance(val, (list, tuple)) else [val]):
            pairs.append((li, gi))
    covered = {gi for _li, gi in pairs}
    per_item = []
    for li, it in enumerate(items or []):
        info = instance_count_from_occurrence_ledger(it)
        val = mapping.get(li)
        idxs = list(val) if isinstance(val, (list, tuple)) else ([] if val is None else [val])
        per_item.append({"item_index": li, "gold_indices": idxs,
                         "tp": len(idxs),
                         "instance_count": info["instance_count"],
                         "instance_count_source": info["source"],
                         "instance_count_reason": info["reason"]})
    tp = len(pairs)
    fp = len([1 for li in range(len(items or [])) if li not in mapping])
    fn = len(gold_entries or []) - len(covered)
    return {"tp": tp, "fp": fp, "fn": fn,
            "covered_gold": sorted(covered), "pairs": pairs,
            "per_item": per_item, "mapping": mapping,
            "instance_policy": ("TP 按实例计（聚合 coverage=2 → TP2；拆分 N:1 → 每 finding TP）；"
                                "instance_count 读 occurrence 台账，缺失 null+reason，禁止 max(1,...)")}


# --------------------------------------------------------------------------- stats
def _quote_verbatim(qc: dict) -> bool:
    return str((qc or {}).get("status")) in ("exact", "exact_after_trim")


def platform_uncovered_reason(code: str, status: dict | None) -> str:
    if not status:
        return "平台未运行该规则（不在 manifest 冻结/路由范围）"
    if not status.get("item_present"):
        return "规则未进入 manifest（路由/适用性排除）"
    d5 = status.get("d5_status") or ""
    if d5 == "fail":
        if status.get("finding_count"):
            return "同码 finding 已匹配其他实例（证据/定位不同）"
        return "D5=fail 但未物化 finding（finding 门禁/证据不足）"
    if d5 == "pass":
        return "平台判通过（D5 pass），直连认为有问题"
    if d5 == "na":
        return "平台判不适用（D5 na）"
    if d5 in ("insufficient", "unknown", "needs_model", "blocked", "execution_failed"):
        return f"平台弃权/执行未完成（D5={d5}）"
    return f"平台结论未知（D5={d5 or 'missing'}）"


def _match_pair_list(mapping: dict) -> list:
    """match_gold 映射 → [(item_idx, gold_idx)]；聚合项返回多条（实例级）。"""
    pairs = []
    for li, val in (mapping or {}).items():
        for gi in (val if isinstance(val, (list, tuple)) else [val]):
            pairs.append((li, gi))
    return pairs


def _match_primary(mapping: dict, idx):
    """item 的主 gold 索引（聚合取首个）；无匹配 None。"""
    return _match_value_first((mapping or {}).get(idx))


def summarize_case(comparison: dict, merged_direct: dict, findings: list,
                   gold_entries: list, gold_primary_entries: list,
                   platform_status_by_code: dict | None = None,
                   policy=None, calibration_map: dict | None = None) -> dict:
    """围绕既有数据集标准答案统计（标准答案只作参照，不是最终真值）。

    W-01：直连“不丢”拆成两个指标，不得再用 gold ID 重合率冒充展示保留率：
      - direct_visible_retention = |{direct gold TP 且 evaluate_direct visible}| / |direct gold TP|
      - platform_agreement_rate  = |{direct gold TP 同时被平台命中}| / |direct gold TP|
    W-12/Alt-E：gold TP/FP/FN 按**实例**计（聚合 finding 覆盖 2 实例 → TP2；拆分 N:1 →
    每条 finding TP2/FP0）；instance_count 从 occurrence 台账读，缺失输出 null+reason。
    """
    from . import visibility_policy as VP

    policy = policy or VP.PolicyConfig()
    D = comparison["direct_items"]
    P = comparison["platform_findings"]
    d_match = match_gold(D, gold_entries, "")
    p_match = match_gold(P, gold_entries, "")
    d_match_primary = match_gold(D, gold_primary_entries, "")
    p_match_primary = match_gold(P, gold_primary_entries, "")
    d_score = score_gold_instances(D, gold_entries, "")
    p_score = score_gold_instances(P, gold_entries, "")
    d_score_primary = score_gold_instances(D, gold_primary_entries, "")
    p_score_primary = score_gold_instances(P, gold_primary_entries, "")

    # 直接项 / 平台 finding 的桶归属
    dbucket, pbucket = {}, {}
    for rec in comparison["records"]:
        d, p = rec.get("direct"), rec.get("platform")
        if d is not None:
            dbucket[rec["direct_index"]] = rec["bucket"]
        if p is not None:
            pbucket[rec["platform_index"]] = rec["bucket"]

    gold_by_id = {g.get("id"): g for g in gold_entries}
    primary_ids = {g.get("id") for g in gold_primary_entries}

    def _gold_hit(mapping, idx):
        gi = _match_primary(mapping, idx)
        if gi is None:
            return None
        return gold_entries[gi]

    # W-01：用 evaluate_direct 的真实 visible 计算展示保留率（不是 gold ID 重合）
    d_cal = (calibration_map or {}).get("direct")
    d_visibility = {}
    for i, item in enumerate(D):
        d_visibility[i] = VP.evaluate_direct(
            VP.candidate_from_direct_item(item), policy, d_cal)
    direct_visible_idx = {i for i, dec in d_visibility.items() if dec["visible"]}

    # Alt-E：direct gold TP 是“实例对”，不是 item 数（聚合 coverage=2 → 2 对）
    direct_tp_items = _match_pair_list(d_match)
    direct_tp_visible = [(i, gi) for i, gi in direct_tp_items if i in direct_visible_idx]
    direct_tp_by_bucket = collections.Counter(dbucket.get(i, "?") for i, _ in direct_tp_items)
    direct_tp_visible_by_bucket = collections.Counter(
        dbucket.get(i, "?") for i, _ in direct_tp_visible)
    direct_visible_retention = {
        "direct_gold_tp": len(direct_tp_items),
        "visible": len(direct_tp_visible),
        "not_visible": len(direct_tp_items) - len(direct_tp_visible),
        "rate": round(len(direct_tp_visible) / len(direct_tp_items), 4)
        if direct_tp_items else None,
        "by_bucket": dict(direct_tp_by_bucket),
        "visible_by_bucket": dict(direct_tp_visible_by_bucket),
        "items": [{"item_index": i, "gold_issue_id": gold_entries[gi].get("id"),
                   "gold_code": gold_entries[gi].get("code"),
                   "bucket": dbucket.get(i, "?"),
                   "status": d_visibility[i]["status"],
                   "visible": bool(d_visibility[i]["visible"]),
                   "ledger": bool(d_visibility[i]["ledger"]),
                   "quote_match_status": d_visibility[i].get("quote_match_status") or ""}
                  for i, gi in direct_tp_items],
        "formula": "|{direct_gold_tp 且 evaluate_direct visible}| / |direct_gold_tp|",
        "n_a": len(direct_tp_items) == 0,
    }
    # 旧口径（错误）：gold ID 重合率——只留作公开纠正，不作为展示保留率
    platform_gold_ids = {gold_entries[gi].get("id")
                         for _i, gi in _match_pair_list(p_match)}
    legacy_retained = [(i, gi) for i, gi in direct_tp_items
                       if gold_entries[gi].get("id") in platform_gold_ids]
    direct_gold_ids = {gold_entries[gi].get("id")
                       for _i, gi in _match_pair_list(d_match)}
    platform_agreement = {
        "direct_gold_tp": len(direct_gold_ids),
        "platform_agreed": len(direct_gold_ids & platform_gold_ids),
        "rate": round(len(direct_gold_ids & platform_gold_ids) / len(direct_gold_ids), 4)
        if direct_gold_ids else None,
        "agreed_ids": sorted(x for x in (direct_gold_ids & platform_gold_ids) if x),
        "formula": "|{direct_gold_tp 同时被平台命中}| / |direct_gold_tp|",
        "n_a": len(direct_gold_ids) == 0,
    }
    legacy_gold_overlap_rate = (
        round(len(legacy_retained) / len(direct_tp_items), 4) if direct_tp_items else None)
    platform_primary_ids = {gold_primary_entries[gi].get("id")
                            for _i, gi in _match_pair_list(p_match_primary)}
    retained_primary = [(i, gi) for i, gi in _match_pair_list(d_match_primary)
                        if gold_primary_entries[gi].get("id") in platform_primary_ids]

    # 仅运行一次直连的“稳定项”统计
    direct_total = len(D)
    stable = sum(1 for it in D if it.get("stable"))
    verbatim = sum(1 for it in D if _quote_verbatim(it.get("quote_check") or {}))
    qc_dist = collections.Counter(str((it.get("quote_check") or {}).get("status")) for it in D)

    # direct_only / platform_only 细分
    direct_only = [r for r in comparison["records"] if r["bucket"] == "direct_only"]
    platform_only = [r for r in comparison["records"] if r["bucket"] == "platform_only"]
    conflict = [r for r in comparison["records"] if r["bucket"] == "conflict"]
    both = [r for r in comparison["records"] if r["bucket"] == "both"]

    def _hit_direct(rec):
        d = rec["direct"]
        return _match_primary(d_match, d["item_index"])

    def _hit_platform(rec):
        return _match_primary(p_match, rec.get("platform_index"))

    def _hit_direct_primary(rec):
        gi = _hit_direct(rec)
        return gi is not None and gold_entries[gi].get("id") in primary_ids

    def _hit_platform_primary(rec):
        gi = _hit_platform(rec)
        return gi is not None and gold_entries[gi].get("id") in primary_ids

    do_hits = [_hit_direct(r) for r in direct_only]
    po_hits = [_hit_platform(r) for r in platform_only]
    co_hits = [(bool(_hit_direct(r) is not None), bool(_hit_platform(r) is not None))
               for r in conflict]

    direct_fp_ids = [D[i].get("code") or "" for i in range(len(D)) if i not in d_match]
    platform_fp_ids = [P[i].get("code") or "" for i in range(len(P)) if i not in p_match]

    platform_only_suspected_fp = sum(1 for h in po_hits if h is None)
    direct_only_unverified = sum(1 for h in do_hits if h is None)

    def _score_block(score: dict) -> dict:
        return {"tp": score["tp"], "fp": score["fp"], "fn": score["fn"],
                "covered_gold": len(score["covered_gold"]),
                "per_item": score["per_item"]}

    return {
        "case_id": comparison["case_id"],
        "doc_chars": comparison["doc_chars"],
        "direct": {
            "runs": merged_direct.get("runs"),
            "items": direct_total,
            "stable_items": stable,
            "quote_verbatim": verbatim,
            "quote_check_dist": dict(qc_dist),
            # Alt-E：TP/FP/FN 按实例计（不是 1:1 item 计数）
            "gold_tp_secondary": d_score["tp"],
            "gold_tp_primary": d_score_primary["tp"],
            "gold_fp": d_score["fp"],
            "gold_fn_secondary": d_score["fn"],
            "instance_scoring": _score_block(d_score),
            "fp_codes": direct_fp_ids,
        },
        "platform": {
            "findings": len(P),
            "gold_tp_secondary": p_score["tp"],
            "gold_tp_primary": p_score_primary["tp"],
            "gold_fp": p_score["fp"],
            "gold_fn_secondary": p_score["fn"],
            "instance_scoring": _score_block(p_score),
            "fp_codes": platform_fp_ids,
        },
        "buckets": {b: int(comparison["buckets"].get(b) or 0) for b in BUCKETS},
        # W-01：两个 retention 指标分开（公开纠正旧 retention=0.0 的归因错误）
        "direct_visible_retention": direct_visible_retention,
        "platform_agreement_rate": platform_agreement,
        "legacy_retention": {
            "legacy_gold_overlap_rate": legacy_gold_overlap_rate,
            "deprecated": True,
            "old_field": "direct_tp_retention.rate",
            "wrong_basis": "gold ID 重合率（平台是否命中同一 gold id）",
            "corrected_basis": "direct_visible_retention = evaluate_direct 的 visible",
            "note": ("旧 retention=0.0 是指标实现错误：算的是 gold ID 重合，不是展示保留；"
                     "唯一 direct gold TP 过 evaluate_direct 是 visible，见 V3.2"),
        },
        # 兼容旧离线脚本 dual_track_p01.py 的键名：语义已改为“visible 保留”（非 gold ID 重合）
        "direct_tp_retention": {
            "direct_tp": len(direct_tp_items),
            "retained": len(direct_tp_visible),
            "dropped": len(direct_tp_items) - len(direct_tp_visible),
            "rate": direct_visible_retention["rate"],
            "direct_tp_primary": d_score_primary["tp"],
            "retained_primary": len(retained_primary),
            "rate_primary": round(len(retained_primary) / d_score_primary["tp"], 4)
            if d_score_primary["tp"] else None,
            "by_bucket": dict(direct_tp_visible_by_bucket),
            "deprecated": True,
            "note": ("键名保留仅为兼容旧脚本；口径已改为 evaluate_direct visible"
                     "（旧 gold-ID 重合口径见 legacy_retention）"),
        },
        "direct_only": {
            "total": len(direct_only),
            "gold_hit": sum(1 for h in do_hits if h is not None),
            "gold_hit_primary": sum(1 for r in direct_only if _hit_direct_primary(r)),
            "unverified_not_gold": direct_only_unverified,
            "quote_verbatim": sum(1 for r in direct_only
                                  if _quote_verbatim((r["direct"].get("quote_check") or {}))),
        },
        "platform_only": {
            "total": len(platform_only),
            "gold_hit": sum(1 for h in po_hits if h is not None),
            "gold_hit_primary": sum(1 for r in platform_only if _hit_platform_primary(r)),
            "suspected_fp": platform_only_suspected_fp,
        },
        "conflict": {
            "total": len(conflict),
            "direct_gold_hit": sum(1 for a, b in co_hits if a),
            "platform_gold_hit": sum(1 for a, b in co_hits if b),
            "neither_gold_hit": sum(1 for a, b in co_hits if not a and not b),
        },
        "both": {"total": len(both)},
        # Alt-E：instance 台账口径（W-13/W-17：不伪造 instance_count，不 max(1,...)）
        "instances": {
            "unit": "occurrence（问题实例）为评分单位；聚合/拆分都按实例计分",
            "direct": instance_ledger(D),
            "platform": instance_ledger(P),
            "gold_instances": len(gold_entries),
            "direct_scoring": _score_block(d_score),
            "platform_scoring": _score_block(p_score),
            "policy": ("instance_count 只从 occurrence 台账（occurrence_ids）读；"
                       "缺失 → null + reason；禁止 max(1,...)"),
        },
        "_internal": {"d_match": d_match, "p_match": p_match,
                      "d_match_primary": d_match_primary, "p_match_primary": p_match_primary,
                      "d_score": d_score, "p_score": p_score,
                      "dbucket": dbucket, "pbucket": pbucket,
                      "direct_visibility": d_visibility,
                      "direct_visible_idx": direct_visible_idx,
                      "gold_by_id": gold_by_id, "primary_ids": primary_ids},
    }


def _suggest_label(rec: dict, gold_hit, quote_verbatim: bool, platform_status: dict | None) -> tuple:
    """脚本规则建议（仅提示，不是人工裁决）。"""
    bucket = rec["bucket"]
    if bucket == "conflict":
        feats = rec.get("features") or {}
        if feats.get("code_same") is False:
            return "rule_or_route_error", "两边指向同一证据但规则码不同（建议先查码归属/路由）"
        if feats.get("issue_same") is False:
            return "needs_evidence", "同码但问题类型不同，证据需人工核对"
        return "needs_evidence", "同码但证据/定位不一致，需人工判断是否同一实例"
    if bucket == "direct_only":
        if gold_hit is not None and quote_verbatim:
            return "likely_direct_true", "直连命中数据集标准答案且引文可逐字回查"
        if gold_hit is not None and not quote_verbatim:
            return "evidence_insufficient", "直连命中标准答案但引文不可逐字回查"
        if quote_verbatim:
            return "evidence_insufficient", "引文可逐字回查但标准答案无对应条目（可能直连多报/标注未覆盖）"
        return "likely_direct_false_positive", "引文不可逐字回查且标准答案无对应条目"
    if bucket == "platform_only":
        if gold_hit is not None:
            return "likely_platform_true", "平台 finding 命中数据集标准答案（直连未报）"
        return "likely_platform_false_positive", "平台 finding 未命中数据集标准答案（直连也未报）"
    return "unreviewed", ""


def _worklist_row(rec: dict, d: dict | None, p: dict | None,
                  platform_status_by_code: dict | None) -> dict:
    """一条差异 → 人工工作单行（W-05：**不含任何 gold 字段/auto_suggested_label**）。"""
    d = d or {}
    p = p or {}
    code = d.get("code") or p.get("code") or ""
    quote_reuse = bool(d.get("quote_reuse_conflict") or p.get("quote_reuse_conflict"))
    reuse_codes = list(d.get("quote_reuse_codes") or p.get("quote_reuse_codes") or [])
    return {
        "row_id": "",
        "case_id": rec.get("case_id") or "",
        "bucket": rec["bucket"],
        "match_key": rec.get("match_key") or {},
        "match_key_code": rec.get("match_key", {}).get("rule_code") or "",
        "match_key_clause": rec.get("match_key", {}).get("clause_or_cell") or "",
        "match_key_subject": rec.get("match_key", {}).get("subject") or "",
        "match_key_issue_type": rec.get("match_key", {}).get("issue_type") or "",
        "direct": d or None,
        "platform": p or None,
        "quote_match_status": {
            "direct": d.get("quote_match_status") or quote_match_status(d.get("quote_check")),
            "platform": p.get("quote_match_status")
            or quote_match_status(p.get("quote_check")),
        },
        "weak_locator": bool(d.get("weak_locator") or p.get("weak_locator")),
        "quote_reuse_conflict": quote_reuse,
        "quote_reuse_codes": reuse_codes,
        "quote_relevance": d.get("quote_relevance") or p.get("quote_relevance") or {},
        "auto_features": rec.get("features") or {},
        # W-03：direct_only 原因来自**实际匹配图**（不再按 D5 状态猜“已匹配其他实例”）
        "platform_uncovered_reason": (
            rec.get("platform_uncovered_reason")
            or platform_uncovered_reason(code, (platform_status_by_code or {}).get(code)))
        if rec["bucket"] == "direct_only" else "",
        # Alt-A 匹配证据（人工复核可见：关系/置信度/span/实例数；均不含 gold）
        "match_relation": rec.get("match_relation") or "",
        "match_confidence": rec.get("match_confidence"),
        "match_evidence": rec.get("match_evidence") or {},
        "match_span": rec.get("char_span") or {},
        "instance_count": rec.get("instance_count"),
        "occurrence_ids": list(rec.get("occurrence_ids") or []),
        "human_confirmed": bool(rec.get("human_confirmed")),
        # 人工裁决空位（工作单只显示 finding/evidence/rule/风险/来源/匹配证据）
        "human_status": "unreviewed",
        "human_label": "",
        "human_actor": "",
        "human_reason": "",
        "_direct_index": rec.get("direct_index"),
        "_platform_index": rec.get("platform_index"),
        "_direct_stable": bool(d.get("stable")),
        "_line": d.get("line") or p.get("line") or 10 ** 9,
    }


def _row_sorted(rows: list) -> list:
    """工作单排序：按桶 + 弱定位/引文复用等复核信号，**不使用 gold**（W-05）。"""
    bucket_rank = {"conflict": 0, "direct_only": 1, "platform_only": 2}
    for r in rows:
        # 复核优先级只由可解释的匹配/证据信号决定，与 gold 无关
        r["_rank"] = bucket_rank.get(r["bucket"], 9)
        signal = 0
        if r.get("quote_reuse_conflict"):
            signal = 0
        elif r.get("weak_locator"):
            signal = 1
        r["_signal"] = signal
    rows.sort(key=lambda r: (r["_rank"], r.get("_signal", 9),
                             0 if r.get("_direct_stable") else 1,
                             r.get("_line", 10 ** 9), r.get("case_id") or ""))
    for i, r in enumerate(rows, 1):
        r["row_id"] = f"{r['case_id']}-{i:03d}"
    return rows


def build_difference_rows(comparison: dict, summary: dict,
                          gold_entries: list | None = None,
                          platform_status_by_code: dict | None = None) -> list:
    """差异清单/人工工作单：conflict / direct_only / platform_only（both 不进）。

    W-05（Alt-D 双盲工作单）：**gold_hit / gold_issue_id(s) / gold_primary /
    auto_suggested_label / auto_note 不再进入工作单**；只显示 finding/evidence/rule/
    风险/来源/匹配证据。gold 只进后台账本（build_backend_gold_ledger）。
    参数 gold_entries 仅为兼容旧调用保留、工作单忽略（gold 不得影响人工视图与排序）。
    """
    records = [r for r in comparison["records"] if r["bucket"] != "both"]
    rows = [_worklist_row(rec, rec.get("direct"), rec.get("platform"),
                          platform_status_by_code) for rec in records]
    return _row_sorted(rows)


def build_backend_gold_ledger(comparison: dict, summary: dict, gold_entries: list,
                              gold_primary_entries: list | None = None,
                              platform_status_by_code: dict | None = None) -> list:
    """后台 gold 账本（只进后台文件/账本，**绝不进人工工作单**；W-05）。

    逐差异行给出 gold_hit/gold_issue_id/gold_primary/auto_suggested_label 等派生标签，
    使用与工作单相同的确定性排序/row_id 生成方式，便于与工作单按 row_id 关联。
    """
    d_match = summary["_internal"]["d_match"]
    p_match = summary["_internal"]["p_match"]
    gold_entries = list(gold_entries or [])
    gold_primary_entries = list(gold_primary_entries or [])
    primary_ids = {str(g.get("id") or "") for g in gold_primary_entries}
    records = [r for r in comparison["records"] if r["bucket"] != "both"]
    # 先生成工作单序列拿 row_id（顺序一致、不含 gold）；按 (direct_index, platform_index) 关联
    worklist = _row_sorted([_worklist_row(rec, rec.get("direct"), rec.get("platform"),
                                          platform_status_by_code) for rec in records])
    rows_by_key = {(r.get("_direct_index"), r.get("_platform_index")): r for r in worklist}
    ledger = []
    for rec in records:
        key = (rec.get("direct_index"), rec.get("platform_index"))
        row = rows_by_key.get(key) or {}
        d, p = rec.get("direct"), rec.get("platform")
        gold_entry = None
        gold_idxs = []
        if d is not None:
            val = d_match.get(rec.get("direct_index"))
            gold_idxs = list(val) if isinstance(val, (list, tuple)) else (
                [] if val is None else [val])
            gold_entry = gold_entries[gold_idxs[0]] if gold_idxs else None
        if gold_entry is None and p is not None:
            val = p_match.get(rec.get("platform_index"))
            gold_idxs = list(val) if isinstance(val, (list, tuple)) else (
                [] if val is None else [val])
            gold_entry = gold_entries[gold_idxs[0]] if gold_idxs else None
        qc = (d or {}).get("quote_check") or (p or {}).get("quote_check") or {}
        label, note = _suggest_label(
            rec, gold_entry, _quote_verbatim(qc),
            (platform_status_by_code or {}).get((d or p or {}).get("code")))
        gold_id = (gold_entry or {}).get("id")
        ledger.append({
            "row_id": row.get("row_id") or "",
            "case_id": rec.get("case_id") or comparison.get("case_id") or "",
            "bucket": rec.get("bucket") or "",
            "match_key_code": (rec.get("match_key") or {}).get("rule_code") or "",
            "gold_hit": gold_entry is not None,
            "gold_issue_id": gold_id,
            # Alt-E：聚合 finding 覆盖多实例时记录全部 gold id；gold_issue_id 保留主 gold 兼容旧账本
            "gold_issue_ids": [gold_entries[gi].get("id") for gi in gold_idxs],
            "instance_tp": len(gold_idxs),
            "gold_primary": bool(str(gold_id) in primary_ids) if gold_id else None,
            "auto_suggested_label": label,
            "auto_note": note,
            "direct_item_index": rec.get("direct_index"),
            "platform_finding_id": (p or {}).get("id") or "",
            "quote_verbatim": _quote_verbatim(qc),
            "visible": None,   # 由可见性策略另算；账本不篡改
            "backend_only": True,
            "worklist_visible": False,
        })
    return ledger


def _json_span(value) -> str:
    """match_span → JSON 字符串（CSV 单列，兼容 direct/platform 两侧）。"""
    if not value:
        return ""
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def to_csv_row(row: dict) -> dict:
    """人工工作单 CSV 行（W-05：字段集合 = CSV_FIELDS，绝不含 gold/auto_suggested_label）。"""
    d = row.get("direct") or {}
    p = row.get("platform") or {}
    qms = row.get("quote_match_status") or {}
    out = {
        "row_id": row.get("row_id"), "case_id": row.get("case_id"),
        "bucket": row.get("bucket"), "match_key_code": row.get("match_key_code"),
        "match_key_clause": row.get("match_key_clause"),
        "match_key_subject": row.get("match_key_subject"),
        "match_key_issue_type": row.get("match_key_issue_type"),
        "direct_run_ids": "|".join(d.get("run_ids") or []),
        "direct_quote_check": (d.get("quote_check") or {}).get("status", ""),
        "direct_quote_match_status": qms.get("direct", "") if isinstance(qms, dict) else "",
        "direct_quote": d.get("quote", ""), "direct_issue": d.get("issue", ""),
        "direct_reason": d.get("reason", ""), "direct_confidence": d.get("confidence", ""),
        "platform_finding_id": p.get("id", ""),
        "platform_quote_check": (p.get("quote_check") or {}).get("status", ""),
        "platform_quote_match_status": qms.get("platform", "") if isinstance(qms, dict) else "",
        "platform_quote": p.get("quote", ""), "platform_summary": p.get("summary", ""),
        "platform_severity": p.get("severity", ""),
        "platform_rule_version": p.get("rule_version", ""),
        "platform_anchor": "|".join(p.get("anchor_ids") or []),
        "auto_similarity": row.get("auto_similarity")
        or (row.get("auto_features") or {}).get("score"),
        "platform_uncovered_reason": row.get("platform_uncovered_reason"),
        "quote_reuse_conflict": row.get("quote_reuse_conflict"),
        "quote_reuse_codes": "|".join(row.get("quote_reuse_codes") or []),
        "weak_locator": row.get("weak_locator"),
        "match_relation": row.get("match_relation") or "",
        "match_confidence": row.get("match_confidence"),
        "match_span": _json_span(row.get("match_span")),
        "instance_count": row.get("instance_count"),
        "human_status": row.get("human_status"), "human_label": row.get("human_label"),
        "human_actor": row.get("human_actor"), "human_reason": row.get("human_reason"),
    }
    # 硬约束：输出键必须全部在 CSV_FIELDS 内，且不含任何 gold 字段
    assert set(out) == set(CSV_FIELDS), (set(out) ^ set(CSV_FIELDS))
    return out


def aggregate(case_summaries: list) -> dict:
    agg = {"cases": len(case_summaries), "per_case": case_summaries}
    sums = collections.Counter()
    for s in case_summaries:
        for b in BUCKETS:
            sums["bucket_" + b] += int(s["buckets"].get(b) or 0)
        for k in ("items", "gold_tp_secondary", "gold_tp_primary", "gold_fp"):
            sums["direct_" + k] += int(s["direct"].get(k) or 0)
        for k in ("findings", "gold_tp_secondary", "gold_tp_primary", "gold_fp"):
            sums["platform_" + k] += int(s["platform"].get(k) or 0)
        rt = s.get("direct_tp_retention") or {}
        sums["direct_tp"] += int(rt.get("direct_tp") or 0)
        sums["direct_tp_retained"] += int(rt.get("retained") or 0)
        sums["direct_tp_dropped"] += int(rt.get("dropped") or 0)
        sums["direct_tp_primary"] += int(rt.get("direct_tp_primary") or 0)
        sums["direct_tp_primary_retained"] += int(rt.get("retained_primary") or 0)
        # W-01 新口径（若 per_case 已带新指标则一并汇总）
        dv = s.get("direct_visible_retention") or {}
        if dv:
            sums["dv_gold_tp"] += int(dv.get("direct_gold_tp") or 0)
            sums["dv_visible"] += int(dv.get("visible") or 0)
        pa = s.get("platform_agreement_rate") or {}
        if pa:
            sums["pa_gold_tp"] += int(pa.get("direct_gold_tp") or 0)
            sums["pa_agreed"] += int(pa.get("platform_agreed") or 0)
        for k in ("total", "gold_hit", "unverified_not_gold", "quote_verbatim"):
            sums["direct_only_" + k] += int(s["direct_only"].get(k) or 0)
        for k in ("total", "gold_hit", "suspected_fp"):
            sums["platform_only_" + k] += int(s["platform_only"].get(k) or 0)
        for k in ("total", "direct_gold_hit", "platform_gold_hit", "neither_gold_hit"):
            sums["conflict_" + k] += int(s["conflict"].get(k) or 0)
        sums["both_total"] += int(s["both"].get("total") or 0)
        inst = s.get("instances") or {}
        for side in ("direct", "platform"):
            block = inst.get(side) or {}
            sums["inst_" + side + "_known"] += int(block.get("known_instance_count") or 0)
            sums["inst_" + side + "_missing"] += int(block.get("missing_ledger_items") or 0)
            scoring = inst.get(side + "_scoring") or {}
            sums["inst_" + side + "_tp"] += int(scoring.get("tp") or 0)
            sums["inst_" + side + "_fp"] += int(scoring.get("fp") or 0)
            sums["inst_" + side + "_fn"] += int(scoring.get("fn") or 0)
        sums["gold_instances"] += int(inst.get("gold_instances") or 0)
    agg["buckets"] = {b: sums["bucket_" + b] for b in BUCKETS}
    agg["direct"] = {"items": sums["direct_items"],
                     "gold_tp_secondary": sums["direct_gold_tp_secondary"],
                     "gold_tp_primary": sums["direct_gold_tp_primary"],
                     "gold_fp": sums["direct_gold_fp"]}
    agg["platform"] = {"findings": sums["platform_findings"],
                       "gold_tp_secondary": sums["platform_gold_tp_secondary"],
                       "gold_tp_primary": sums["platform_gold_tp_primary"],
                       "gold_fp": sums["platform_gold_fp"]}
    agg["direct_visible_retention"] = {
        "direct_gold_tp": sums["dv_gold_tp"],
        "visible": sums["dv_visible"],
        "not_visible": sums["dv_gold_tp"] - sums["dv_visible"],
        "rate": round(sums["dv_visible"] / sums["dv_gold_tp"], 4)
        if sums["dv_gold_tp"] else None,
        "formula": "|{direct_gold_tp 且 evaluate_direct visible}| / |direct_gold_tp|",
        "n_a": sums["dv_gold_tp"] == 0,
    }
    agg["platform_agreement_rate"] = {
        "direct_gold_tp": sums["pa_gold_tp"],
        "platform_agreed": sums["pa_agreed"],
        "rate": round(sums["pa_agreed"] / sums["pa_gold_tp"], 4)
        if sums["pa_gold_tp"] else None,
        "formula": "|{direct_gold_tp 同时被平台命中}| / |direct_gold_tp|",
        "n_a": sums["pa_gold_tp"] == 0,
    }
    agg["direct_tp_retention"] = {
        "direct_tp": sums["direct_tp"],
        "retained": sums["direct_tp_retained"],
        "dropped": sums["direct_tp_dropped"],
        "rate": round(sums["direct_tp_retained"] / sums["direct_tp"], 4) if sums["direct_tp"] else None,
        "direct_tp_primary": sums["direct_tp_primary"],
        "retained_primary": sums["direct_tp_primary_retained"],
        "rate_primary": round(sums["direct_tp_primary_retained"] / sums["direct_tp_primary"], 4)
        if sums["direct_tp_primary"] else None,
        "deprecated": True,
        "note": "键名兼容旧脚本；口径已改为 evaluate_direct visible，见 direct_visible_retention",
    }
    agg["direct_only"] = {"total": sums["direct_only_total"],
                          "gold_hit": sums["direct_only_gold_hit"],
                          "unverified_not_gold": sums["direct_only_unverified_not_gold"],
                          "quote_verbatim": sums["direct_only_quote_verbatim"]}
    agg["platform_only"] = {"total": sums["platform_only_total"],
                            "gold_hit": sums["platform_only_gold_hit"],
                            "suspected_fp": sums["platform_only_suspected_fp"]}
    agg["conflict"] = {"total": sums["conflict_total"],
                       "direct_gold_hit": sums["conflict_direct_gold_hit"],
                       "platform_gold_hit": sums["conflict_platform_gold_hit"],
                       "neither_gold_hit": sums["conflict_neither_gold_hit"]}
    agg["both"] = {"total": sums["both_total"]}
    # Alt-E：instance 台账汇总（缺失 instance_count 单列，不补 1）
    agg["instances"] = {
        "gold_instances": sums["gold_instances"],
        "direct": {"known_instance_count": sums["inst_direct_known"],
                   "missing_ledger_items": sums["inst_direct_missing"],
                   "tp": sums["inst_direct_tp"], "fp": sums["inst_direct_fp"],
                   "fn": sums["inst_direct_fn"]},
        "platform": {"known_instance_count": sums["inst_platform_known"],
                     "missing_ledger_items": sums["inst_platform_missing"],
                     "tp": sums["inst_platform_tp"], "fp": sums["inst_platform_fp"],
                     "fn": sums["inst_platform_fn"]},
        "policy": "instance_count 读 occurrence_ids；缺失 null+reason；禁止 max(1,...)",
    }
    return agg


# ===========================================================================
# T-39 双轨数据模型（离线底座）：comparison_item 四桶落库 / platform_finding 统一视图
#                          / adjudication_event 追加式裁决事件
#
# 硬约束（见 docs/delivery/直连与平台可见性策略_20261117.md、置信图与分层裁决_20261117.md）：
# - 自动比对只做分组提示：auto_similarity/auto_note 不构成真值，不写 human 结论；
# - comparison_item.human_status 只能由 set_human_decision（人工动作）修改，
#   且每次修改追加 adjudication_event，旧结论不改不删；
# - platform_finding 是既有 finding+evidence 的只读统一视图（DB view），本模块只读；
# - 直连不是 gold：comparison_item 不存 gold 字段，human 结论也不得由直连来源自动推导。
# ===========================================================================
COMPARISON_TABLE = "comparison_item"
ADJUDICATION_TABLE = "adjudication_event"
PLATFORM_FINDING_VIEW = "platform_finding"
COMPARISON_SCHEMA = "comparison_item/v1"


class HumanDecisionConflict(RuntimeError):
    """C5（评审 P0 第二批）：人工裁决并发 CAS 抢占失败（另一裁决已先提交）。

    业务含义：本次裁决**没有**生效，也没有留下任何 adjudication_event/审计。
    调用方（human_review.decide_item）必须转成 409 ``decision_conflict`` 让前端
    刷新后按当前结论重裁，禁止静默覆盖他人裁决。
    """

    def __init__(self, current_status: str = "", actor: str = "", reason: str = ""):
        super().__init__("裁决冲突：该差异项已被他人裁决")
        self.current_status = str(current_status or "")
        self.actor = str(actor or "")
        self.reason = str(reason or "")

    def payload(self) -> dict:
        return {"current": {"status": self.current_status,
                            "label": HUMAN_STATUS_LABELS.get(self.current_status,
                                                             self.current_status),
                            "actor": self.actor, "reason": self.reason}}


# 人工裁决取值（含 doc §6.2 全部选项 + 抑制恢复）
HUMAN_STATUSES = (
    "unreviewed",
    "confirmed_direct_true",       # 确认直连对、平台漏 → direct_only_true
    "confirmed_platform_true",     # 确认平台对、直连漏
    "confirmed_both_true",         # 两边都对但描述不同
    "direct_false_positive",
    "platform_false_positive",
    "both_false",                  # 两边都错 → 负例
    "evidence_insufficient",
    "rule_or_route_error",
    "recovered_from_suppressed",   # 从抑制池恢复
)
HUMAN_STATUS_LABELS = {
    "unreviewed": "待裁决",
    "confirmed_direct_true": "确认直连对、平台漏",
    "confirmed_platform_true": "确认平台对、直连漏",
    "confirmed_both_true": "两边都对但描述不同",
    "direct_false_positive": "直连误报",
    "platform_false_positive": "平台误报",
    "both_false": "两边都错",
    "evidence_insufficient": "证据不足",
    "rule_or_route_error": "规则/路由错误",
    "recovered_from_suppressed": "抑制池恢复",
}
NON_HUMAN_STATUSES = ("unreviewed",)

ADJUDICATION_ACTIONS = (
    "human_decision",          # 人工对 comparison_item 裁决
    "suppress_finding",        # 进入抑制台账（系统/策略动作）
    "recover_suppressed",      # 人工从抑制池恢复
    "sample_suppressed",       # 抑制池抽样
    "suppression_human_result",  # 抑制项人工审计结果
    "reconcile_omission",      # 人工漏报对账
    "record_omission",         # 人工登记漏报
)


def _cross_canonical_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _comparison_key(case_id: str, run_id: str, bucket: str, d_idx, p_idx) -> str:
    return "|".join((str(case_id or ""), str(run_id or ""), str(bucket or ""),
                     "-" if d_idx is None else str(d_idx),
                     "-" if p_idx is None else str(p_idx)))


def append_event(conn, action: str, *, case_id: str = "", run_id: str = "",
                 comparison_item_id: str = "", ledger_id: str = "", omission_id: str = "",
                 tenant_id: str = "", workspace_id: str = "", actor: str = "",
                 before_status: str = "", after_status: str = "", reason_code: str = "",
                 reason: str = "", evidence: dict | None = None) -> dict:
    """追加式裁决/审计事件（只 INSERT；DB 触发器禁止 UPDATE/DELETE）。"""
    if action not in ADJUDICATION_ACTIONS:
        raise ValueError(f"未知裁决事件动作：{action}")
    event_id = "ae_" + uuid.uuid4().hex[:16]
    stamp = _now_iso()
    conn.execute(
        f"INSERT INTO {ADJUDICATION_TABLE}(id, case_id, run_id, comparison_item_id, ledger_id, "
        "omission_id, tenant_id, workspace_id, action, actor, before_status, after_status, "
        "reason_code, reason, evidence_json, created_at, immutable) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
        (event_id, case_id, run_id, comparison_item_id, ledger_id, omission_id,
         tenant_id, workspace_id, action, actor, before_status, after_status,
         reason_code, reason, _cross_canonical_json(evidence or {}), stamp))
    return get_event(conn, event_id)


def get_event(conn, event_id: str) -> dict:
    row = conn.execute(f"SELECT * FROM {ADJUDICATION_TABLE} WHERE id=?", (event_id,)).fetchone()
    if not row:
        return None
    out = dict(row)
    try:
        out["evidence"] = json.loads(out.get("evidence_json") or "{}")
    except Exception:
        out["evidence"] = {}
    out["immutable"] = bool(out.get("immutable"))
    return out


def list_events(conn, case_id: str = "", comparison_item_id: str = "",
                ledger_id: str = "", omission_id: str = "") -> list:
    where, params = [], []
    for col, val in (("case_id", case_id), ("comparison_item_id", comparison_item_id),
                     ("ledger_id", ledger_id), ("omission_id", omission_id)):
        if val:
            where.append(f"{col}=?")
            params.append(val)
    sql = f"SELECT id FROM {ADJUDICATION_TABLE}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at, rowid"
    return [get_event(conn, r[0]) for r in conn.execute(sql, tuple(params)).fetchall()]


# ----------------------------------------------------------------- platform_finding 统一视图
def _split_pipe(value) -> list:
    return [x.strip() for x in str(value or "").split("|") if x.strip()]


def _view_row_to_finding(row: dict) -> dict:
    """platform_finding 视图行 → 既有 normalize_finding 可消费的 finding 形态。"""
    quotes = [q.strip() for q in str(row.get("evidence_text") or "").split("\n") if q.strip()]
    anchors = _split_pipe(row.get("anchor_ids"))
    finding = {
        "id": row.get("id"), "case_id": row.get("case_id"),
        "code": row.get("rule_code") or row.get("point_id") or "",
        "rule_id": row.get("rule_id") or "", "rule_version": row.get("rule_version") or "",
        "severity": row.get("severity") or "", "certainty": row.get("certainty") or "",
        "confidence": row.get("confidence"),
        "title": row.get("title") or "", "summary": row.get("summary") or "",
        "detail": row.get("suggestion") or "", "state": row.get("state") or "",
        "status": row.get("status") or "", "object_id": row.get("object_id") or "",
        "point_id": row.get("point_id") or "",
        "manifest_result_id": row.get("manifest_result_id") or "",
        "evidence": [{"quote": q, "anchor_id": anchors[i] if i < len(anchors) else ""}
                     for i, q in enumerate(quotes)],
        "quote": quotes[0] if quotes else "",
        "anchor_id": anchors[0] if anchors else "",
    }
    return finding


def platform_findings(conn, case_id: str = "", doc_text: str = "") -> list:
    """读 platform_finding 统一视图：既有 finding/evidence 的唯一读取口径。

    返回 [{"row": 视图行, "normalized": cross_review.normalize_finding(...)}]。
    视图不存在（老库未 init）时抛 RuntimeError，不静默返回空。
    """
    exists = conn.execute("SELECT count(*) FROM sqlite_master WHERE type='view' AND name=?",
                          (PLATFORM_FINDING_VIEW,)).fetchone()[0]
    if not exists:
        raise RuntimeError(f"缺少统一视图 {PLATFORM_FINDING_VIEW}：请先执行 db.init_db()")
    if case_id:
        rows = conn.execute(f"SELECT * FROM {PLATFORM_FINDING_VIEW} WHERE case_id=? "
                            "ORDER BY id", (case_id,)).fetchall()
    else:
        rows = conn.execute(f"SELECT * FROM {PLATFORM_FINDING_VIEW} "
                            "ORDER BY case_id, id").fetchall()
    out = []
    for r in rows:
        row = dict(r)
        finding = _view_row_to_finding(row)
        out.append({"row": row, "normalized": normalize_finding(finding, doc_text)})
    return out


def get_platform_finding(conn, finding_id: str, doc_text: str = "") -> dict:
    for item in platform_findings(conn):
        if str(item["row"].get("id")) == str(finding_id):
            if doc_text:
                item["normalized"] = normalize_finding(
                    _view_row_to_finding(item["row"]), doc_text)
            return item
    return None


def platform_finding_count(conn, case_id: str = "") -> int:
    if case_id:
        return conn.execute(f"SELECT count(*) FROM {PLATFORM_FINDING_VIEW} WHERE case_id=?",
                            (case_id,)).fetchone()[0]
    return conn.execute(f"SELECT count(*) FROM {PLATFORM_FINDING_VIEW}").fetchone()[0]


# ----------------------------------------------------------------- comparison_item 四桶落库
def persist_comparison(conn, comparison: dict, *, run_id: str = "", tenant_id: str = "",
                       workspace_id: str = "", direct_draft_id: str = "",
                       direct_item_ids: list | None = None) -> dict:
    """把 compare_case 的四桶结果持久化为 comparison_item（只分组提示，不写 human 结论）。

    direct_item_ids：与 comparison["direct_items"] 同序的直连条目 ID（来自 direct_draft 落库）；
    平台侧 id 直接取既有 finding id。
    """
    case_id = str(comparison.get("case_id") or "")
    if not case_id:
        raise ValueError("comparison.case_id 不能为空")
    d_ids = list(direct_item_ids or [])
    created, existing, item_ids = 0, 0, []
    stamp = _now_iso()
    for rec in comparison.get("records") or []:
        bucket = rec.get("bucket")
        if bucket not in BUCKETS:
            raise ValueError(f"非法四桶：{bucket}")
        d_idx = rec.get("direct_index")
        p_idx = rec.get("platform_index")
        key = _comparison_key(case_id, run_id, bucket, d_idx, p_idx)
        hit = conn.execute(f"SELECT id FROM {COMPARISON_TABLE} WHERE item_key=?",
                           (key,)).fetchone()
        if hit:
            existing += 1
            item_ids.append(hit[0])
            continue
        d = rec.get("direct") or {}
        p = rec.get("platform") or {}
        feats = rec.get("features") or {}
        item_id = "ci_" + uuid.uuid4().hex[:16]
        match_key = rec.get("match_key") or {}
        conn.execute(
            f"INSERT INTO {COMPARISON_TABLE}(id, item_key, case_id, run_id, tenant_id, "
            "workspace_id, bucket, match_key_json, match_key_code, match_key_clause, "
            "match_key_subject, match_key_issue_type, direct_draft_id, direct_item_id, "
            "direct_item_index, platform_finding_id, platform_index, auto_similarity, "
            "auto_note, auto_features_json, human_status, human_actor, human_reason, "
            "human_label, visibility, visibility_reason, visibility_json, created_at, updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (item_id, key, case_id, run_id, tenant_id, workspace_id, bucket,
             _cross_canonical_json(match_key), str(match_key.get("rule_code") or ""),
             str(match_key.get("clause_or_cell") or ""),
             str(match_key.get("subject") or ""), str(match_key.get("issue_type") or ""),
             direct_draft_id,
             str(d_ids[d_idx]) if d_idx is not None and 0 <= int(d_idx) < len(d_ids) else "",
             None if d_idx is None else int(d_idx),
             str(p.get("id") or ""), None if p_idx is None else int(p_idx),
             float(feats.get("score")) if feats.get("score") is not None else None,
             str(rec.get("auto_note") or ""), _cross_canonical_json(feats),
             "unreviewed", "", "", "", "", "", "{}", stamp, stamp))
        created += 1
        item_ids.append(item_id)
    return {"case_id": case_id, "run_id": run_id, "created": created,
            "existing": existing, "total": created + existing, "item_ids": item_ids,
            "schema": COMPARISON_SCHEMA,
            "human_status_written": "unreviewed",  # 显式声明：自动比对不产生人工结论
            "not_gold": True}


def _comparison_row(row) -> dict:
    if not row:
        return None
    out = dict(row)
    for src, dst in (("match_key_json", "match_key"), ("auto_features_json", "auto_features"),
                     ("visibility_json", "visibility_detail")):
        try:
            out[dst] = json.loads(out.get(src) or "{}")
        except Exception:
            out[dst] = {}
    out["auto_similarity_only_hint"] = True
    return out


def get_comparison_item(conn, item_id: str) -> dict:
    row = conn.execute(f"SELECT * FROM {COMPARISON_TABLE} WHERE id=?", (item_id,)).fetchone()
    return _comparison_row(row)


def get_comparison_item_by_key(conn, item_key: str) -> dict:
    row = conn.execute(f"SELECT * FROM {COMPARISON_TABLE} WHERE item_key=?",
                       (item_key,)).fetchone()
    return _comparison_row(row)


def list_comparison_items(conn, case_id: str = "", bucket: str = "",
                          human_status: str = "", visibility: str = "") -> list:
    where, params = [], []
    for col, val in (("case_id", case_id), ("bucket", bucket),
                     ("human_status", human_status), ("visibility", visibility)):
        if val:
            where.append(f"{col}=?")
            params.append(val)
    sql = f"SELECT * FROM {COMPARISON_TABLE}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at, rowid"
    return [_comparison_row(r) for r in conn.execute(sql, tuple(params)).fetchall()]


def bucket_counts(conn, case_id: str = "") -> dict:
    params, where = (), ""
    if case_id:
        where, params = " WHERE case_id=?", (case_id,)
    rows = conn.execute(f"SELECT bucket, count(*) FROM {COMPARISON_TABLE}{where} "
                        "GROUP BY bucket", params).fetchall()
    counts = {b: 0 for b in BUCKETS}
    for bucket, n in rows:
        counts[bucket] = int(n)
    counts["total"] = sum(counts[b] for b in BUCKETS)
    if case_id:
        counts["unreviewed"] = conn.execute(
            f"SELECT count(*) FROM {COMPARISON_TABLE} WHERE case_id=? AND "
            "human_status='unreviewed'", (case_id,)).fetchone()[0]
    else:
        counts["unreviewed"] = conn.execute(
            f"SELECT count(*) FROM {COMPARISON_TABLE} WHERE human_status='unreviewed'"
        ).fetchone()[0]
    return counts


def set_visibility(conn, item_id: str, visibility: str, reason_code: str = "",
                   decisions: dict | None = None) -> dict:
    """写入可见性策略结果（系统动作；不改人工结论）。"""
    row = conn.execute(f"SELECT id FROM {COMPARISON_TABLE} WHERE id=?", (item_id,)).fetchone()
    if not row:
        raise KeyError(f"comparison_item 不存在：{item_id}")
    conn.execute(f"UPDATE {COMPARISON_TABLE} SET visibility=?, visibility_reason=?, "
                 "visibility_json=?, updated_at=? WHERE id=?",
                 (visibility, reason_code, _cross_canonical_json(decisions or {}),
                  _now_iso(), item_id))
    return get_comparison_item(conn, item_id)


def set_human_decision(conn, item_id: str, status: str, *, actor: str, reason: str = "",
                       label: str = "", evidence: dict | None = None,
                       expected_status: str = "") -> dict:
    """人工裁决唯一写入口：更新当前 human_* 并追加 adjudication_event（before/after）。

    自动比对/策略不得调用本函数；actor 必填（不允许匿名裁决）。

    C5（评审 P0 第二批）：并发裁决必须可发现。
    修复前 UPDATE 只按 id 定位：两个审核员同时分别裁决同一 comparison_item，
    **两次都成功**、两条 adjudication_event 都记「before=原状态」，最终状态取决于
    最后提交者，先提交者的裁决被静默覆盖（审计里还看不出被覆盖）。
    现在用「写前值比对」CAS：``WHERE id=? AND human_status=<读到的 before>``，
    SQLite 单写锁保证只有一个 rowcount=1。抢不到 → 抛 :class:`HumanDecisionConflict`
    （不写事件、不改状态），调用方转 409。``expected_status`` 可选（显式期望更严）。
    """
    if status not in HUMAN_STATUSES:
        raise ValueError(f"非法人工裁决状态：{status}（可选：{', '.join(HUMAN_STATUSES)}）")
    if not str(actor or "").strip():
        raise ValueError("人工裁决必须记录 actor，禁止匿名")
    item = get_comparison_item(conn, item_id)
    if not item:
        raise KeyError(f"comparison_item 不存在：{item_id}")
    before = str(item.get("human_status") or "unreviewed")
    if str(expected_status or "").strip() and str(expected_status).strip() != before:
        raise HumanDecisionConflict(before, str(item.get("human_actor") or ""),
                                    str(item.get("human_reason") or ""))
    cur = conn.execute(
        f"UPDATE {COMPARISON_TABLE} SET human_status=?, human_actor=?, human_reason=?, "
        "human_label=?, updated_at=? WHERE id=? AND COALESCE(human_status,'unreviewed')=?",
        (status, actor, reason, label or HUMAN_STATUS_LABELS.get(status, status),
         _now_iso(), item_id, before))
    if int(cur.rowcount or 0) != 1:
        fresh = get_comparison_item(conn, item_id) or {}
        raise HumanDecisionConflict(str(fresh.get("human_status") or ""),
                                    str(fresh.get("human_actor") or ""),
                                    str(fresh.get("human_reason") or ""))
    event = append_event(
        conn, "human_decision", case_id=str(item.get("case_id") or ""),
        run_id=str(item.get("run_id") or ""), comparison_item_id=item_id,
        actor=actor, before_status=before, after_status=status,
        reason_code="human_adjudication", reason=reason, evidence=evidence)
    return {"item": get_comparison_item(conn, item_id), "event": event,
            "before_status": before, "after_status": status}


# ----------------------------------------------------------------- 差异清单视图（DB 侧）
def _direct_desc_from_row(item_row: dict) -> dict:
    qc = item_row.get("quote_check") or {}
    text = "\n".join(x for x in (item_row.get("quote"), item_row.get("issue"),
                                 item_row.get("reason")) if str(x or "").strip())
    return {"source": "direct", "id": item_row.get("id"),
            "case_id": item_row.get("case_id"), "code": item_row.get("rule_code") or "",
            "quote": item_row.get("quote") or "", "quote_check": qc,
            "offset": qc.get("offset"), "line": qc.get("line"),
            "issue": item_row.get("issue") or "", "reason": item_row.get("reason") or "",
            "subject": item_row.get("subject") or "",
            "issue_type": item_row.get("issue_type") or "",
            "location_hint": item_row.get("location_hint") or "",
            "confidence": item_row.get("confidence"), "text": text,
            "raw_item": item_row.get("raw_item") or {}}


def item_view(conn, item_id: str, doc_text: str = "") -> dict:
    """comparison_item + 直连条目 + platform_finding 归一化并排视图（人工复核用）。"""
    item = get_comparison_item(conn, item_id)
    if not item:
        return None
    direct = None
    if item.get("direct_item_id"):
        drow = conn.execute("SELECT * FROM direct_item WHERE id=?",
                            (item["direct_item_id"],)).fetchone()
        if drow:
            from . import direct_draft
            direct = _direct_desc_from_row(direct_draft._item_row(dict(drow)))
    platform = None
    if item.get("platform_finding_id"):
        got = get_platform_finding(conn, item["platform_finding_id"], doc_text)
        platform = got["normalized"] if got else None
    return {"comparison": item, "direct": direct, "platform": platform}


def case_quote_reuse(conn, case_id: str, doc_text: str = "") -> dict:
    """对已落库 case 的全部 comparison_item 做“同引文跨码复用”检测（W-19 持久态入口）。

    可见性应用（suppression_ledger.apply_comparison_visibility）在持久态下拿不到
    compare_case 的内存描述符，因此需要按 case 重新聚合两侧描述符后注入 quote_reuse。
    返回 {comparison_item_id: {"direct": flags, "platform": flags}}（仅命中项）。
    """
    items = list_comparison_items(conn, case_id=case_id)
    descs = {"direct": [], "platform": []}
    for item in items:
        view = item_view(conn, item["id"], doc_text)
        for side in ("direct", "platform"):
            desc = view.get(side)
            if not desc:
                continue
            d = dict(desc)
            d["_item_ref"] = item["id"]
            descs[side].append(d)
    out: dict = {}
    for side in ("direct", "platform"):
        annotated, _groups = annotate_quote_reuse(descs[side], side=side)
        for d in annotated:
            if not d.get("quote_reuse_conflict"):
                continue
            item_id = str(d.get("_item_ref") or "")
            if not item_id:
                continue
            out.setdefault(item_id, {})[side] = {
                k: d[k] for k in ("quote_reuse_conflict", "quote_reuse_codes",
                                  "quote_reuse_count", "quote_reuse_side",
                                  "quote_relevance", "quote_reuse") if k in d}
    return out


__all__ = ["BUCKETS", "BUCKET_LABELS", "HUMAN_STATUSES", "CSV_FIELDS",
           "BACKEND_LEDGER_FIELDS", "QUOTE_MATCH_STATUSES", "QUOTE_REUSE_MIN_CODES",
           "compare_case", "quote_match_status", "quote_relevance_check",
           "quote_reuse_groups", "annotate_quote_reuse", "case_quote_reuse",
           "normalize_direct_item", "normalize_finding", "match_gold", "summarize_case",
           "build_difference_rows", "build_backend_gold_ledger",
           "aggregate", "to_csv_row",
           "platform_uncovered_reason", "similarity", "text_overlap", "norm",
           "MATCH_GRAPH_VERSION", "SPAN_OVERLAP_MIN", "ISSUE_TYPE_UNKNOWN",
           "RELATION_SAME_INSTANCE", "RELATION_SAME_INSTANCE_CROSS_CODE",
           "RELATION_SAME_CODE_OTHER_INSTANCE", "build_match_graph",
           "issue_type_known", "instance_count_from_occurrence_ledger", "instance_ledger",
           "match_gold", "score_gold_instances", "compare_case",
           "COMPARISON_TABLE", "ADJUDICATION_TABLE", "PLATFORM_FINDING_VIEW",
           "COMPARISON_SCHEMA", "HUMAN_STATUS_LABELS", "ADJUDICATION_ACTIONS",
           "append_event", "get_event", "list_events",
           "platform_findings", "get_platform_finding", "platform_finding_count",
           "persist_comparison", "get_comparison_item", "get_comparison_item_by_key",
           "list_comparison_items", "bucket_counts", "set_visibility",
           "set_human_decision", "item_view"]

