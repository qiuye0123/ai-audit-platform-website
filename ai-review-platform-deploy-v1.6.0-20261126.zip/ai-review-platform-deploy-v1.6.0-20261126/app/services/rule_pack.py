"""行业规则包（schema v1）：校验 / 加载 / 预览 / 应用 / 统计。

产品背景（领域 A「开箱能用」）：新行业客户需要把「行业通用审核点位」一次性导入，
而不是从零口述规则。规则包是**行业骨架**（示例，不是行业全集）：
- 文件格式：``configs/rule_packs/<industry>/<pack>.json``（schema v1）；
- 每个 point 表达一个审核点位（code/name/category/rclass/mandatory/slots/scope），
  apply 时逐条复用现有 ``rule.create_rule``（只读调用，不改 rule.py），
  ``mandatory`` 同时写入版本槽位 ``slots.mandatory`` 与规则主记录 ``scope.mandatory``，
  供 ``mandatory_rule.is_mandatory`` 只读判定；
- ``dry_run=True``（默认）**只报告不落库**：不调用 create_rule、不写任何表；
- 本模块不做路由/CLI/UI 接线（Phase 2），见 docs/qa/领域A吸收_20261120.md。

格式（v1）::

    {
      "schema": "rule-pack/v1",
      "pack": "招标采购审核规则包（骨架）",
      "industry": "bid",
      "version": "1.0",
      "points": [
        {"code": "BID-001", "name": "...", "category": "limit", "rclass": "R1",
         "mandatory": true,
         "slots": {"criterion": "...", "metric": "...", "op": "<=", "value": 1,
                   "unit": "元", "required_evidence": "原文"},
         "scope": {"applicable_types": ["pdf", "docx", "xlsx"]}}
      ],
      "rules": []
    }

``rules`` 保留给 Phase 2 的组合规则/决策表（本轮 apply 只导入 points，不猜组合语义）。
"""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

PACK_SCHEMA = "rule-pack/v1"
PACK_ROOT = Path(__file__).resolve().parents[2] / "configs" / "rule_packs"

# 适用范围白名单：已知文件扩展名（与 rule.py 的 _KNOWN_EXT 同口径，显式列出避免依赖私有常量）
KNOWN_TYPES = frozenset({"pdf", "docx", "doc", "xlsx", "xls", "txt", "csv",
                         "md", "markdown", "json", "xml", "html", "png",
                         "jpg", "jpeg"})
# 12 类规范规则类别（rule_taxonomy.CATEGORY_LABELS 的唯一来源）
VALID_CATEGORIES = ("limit", "consistency", "completeness", "format", "preprocess",
                    "record", "prohibited", "frequency", "personnel", "equipment",
                    "label", "citation")
VALID_RCLASSES = ("R0", "R1", "R2", "R3", "R4", "R5")
_CODE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{1,39}$")
_WILDCARD_TYPES = frozenset({"*", "all", "全部", "any", "all_types"})
_GOVERNANCE_SLOT_KEYS = frozenset({"scope_meta", "scope_required", "scope_declared",
                                   "scope_missing", "platform_scope"})
# 判定「有可执行槽位」的键（仅用于预览提示，不改变 rule.create_rule 的判断）
_EXECUTABLE_KEYS = ("metric", "op", "operator", "value", "threshold", "range",
                    "require", "forbid", "require_any", "pattern", "keywords",
                    "required_docs", "record_field", "role", "qualification",
                    "equipment", "item", "labeled", "label_required", "cited",
                    "objects", "across", "action", "frequency", "format_rules",
                    "steps", "subrequirements", "criteria_list", "relations")


# ---------------------------------------------------------------- 加载 / 校验
def load_pack(path) -> dict:
    """读取规则包 JSON（不校验；校验用 validate_pack）。

    抛 FileNotFoundError / ValueError（JSON 坏或顶层不是对象），不静默返回空包。
    """
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"规则包不存在：{p}")
    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as exc:
        raise ValueError(f"规则包读取失败：{p}（{type(exc).__name__}: {exc}）") from exc
    try:
        pack = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"规则包 JSON 解析失败：{p}（{exc}）") from exc
    if not isinstance(pack, dict):
        raise ValueError(f"规则包顶层必须是 JSON 对象：{p}")
    return pack


def _norm_types(value) -> list:
    if value is None or value == "":
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple)):
        return []
    out = []
    for token in value:
        t = str(token or "").strip().lower().lstrip(".")
        if t and t not in out:
            out.append(t)
    return out


def _executable(point: dict) -> bool:
    slots = (point or {}).get("slots") if isinstance((point or {}).get("slots"), dict) else {}
    return any(slots.get(k) not in (None, "", [], {}) for k in _EXECUTABLE_KEYS)


def validate_pack(pack) -> dict:
    """规则包 schema v1 校验（纯计算，不落库）。

    校验项：顶层字段 / code 唯一与格式 / name / category（12 类）/ rclass（R0-R5）/
    mandatory 严格布尔 / slots 结构（且不得携带治理字段）/ scope 合法（applicable_types
    白名单 + 禁止隐式全量通配；或 applicable_when 非空）/ rules 引用存在。

    返回：{ok, errors, warnings, stats}；errors 为可读字符串列表（含 point code 前缀）。
    """
    errors, warnings = [], []
    if not isinstance(pack, dict):
        return {"ok": False, "errors": ["规则包必须是 JSON 对象"], "warnings": [],
                "stats": {}}
    schema = pack.get("schema")
    if schema not in (None, "") and str(schema) != PACK_SCHEMA:
        errors.append(f"schema 必须是「{PACK_SCHEMA}」：{schema!r}")
    for key, label in (("pack", "规则包名称"), ("industry", "行业标识")):
        if not str(pack.get(key) or "").strip():
            errors.append(f"缺少 {label}（{key}）")
    if not str(pack.get("version") or "").strip():
        errors.append("缺少版本（version）")
    points = pack.get("points")
    if not isinstance(points, list) or not points:
        errors.append("points 必须是非空数组（规则包至少 1 个审核点位）")
        points = []
    codes = {}
    for idx, point in enumerate(points):
        where = f"points[{idx}]"
        if not isinstance(point, dict):
            errors.append(f"{where} 必须是对象")
            continue
        code = str(point.get("code") or "").strip()
        if not code:
            errors.append(f"{where} 缺少 code")
        elif not _CODE_RE.match(code):
            errors.append(f"{where} code 格式非法（字母开头，字母/数字/_/-，2~40 位）：{code!r}")
        elif code in codes:
            errors.append(f"code 重复：{code}（points[{codes[code]}] 与 points[{idx}]）")
        else:
            codes[code] = idx
        tag = code or where
        if not str(point.get("name") or "").strip():
            errors.append(f"{tag}: 缺少 name")
        category = str(point.get("category") or "").strip()
        if category not in VALID_CATEGORIES:
            errors.append(f"{tag}: category「{category}」不在 12 类内"
                          f"（{'/'.join(VALID_CATEGORIES)}）")
        rclass = str(point.get("rclass") or "").strip().upper()
        if rclass not in VALID_RCLASSES:
            errors.append(f"{tag}: rclass「{point.get('rclass')}」不在 R0-R5 内")
        if "mandatory" in point and not isinstance(point.get("mandatory"), bool):
            errors.append(f"{tag}: mandatory 必须是布尔值（true/false），"
                          f"不接受 {point.get('mandatory')!r}")
        slots = point.get("slots")
        if slots is None:
            errors.append(f"{tag}: 缺少 slots（判据/槽位）")
            slots = {}
        elif not isinstance(slots, dict):
            errors.append(f"{tag}: slots 必须是对象")
            slots = {}
        else:
            bad_gov = sorted(k for k in slots if k in _GOVERNANCE_SLOT_KEYS)
            if bad_gov:
                errors.append(f"{tag}: slots 不得携带治理字段：{'、'.join(bad_gov)}"
                              f"（由服务端派生）")
            if "mandatory" in slots and not isinstance(slots.get("mandatory"), bool):
                errors.append(f"{tag}: slots.mandatory 必须是布尔值")
            try:
                json.dumps(slots, ensure_ascii=False)
            except (TypeError, ValueError):
                errors.append(f"{tag}: slots 必须可 JSON 序列化")
            if not str(slots.get("criterion") or "").strip() and not _executable(point):
                warnings.append(f"{tag}: 缺 criterion 且无可执行槽位，apply 后只能建草稿")
        scope = point.get("scope")
        types, when = [], ""
        if scope is None:
            errors.append(f"{tag}: 缺少 scope（适用范围）")
        elif not isinstance(scope, dict):
            errors.append(f"{tag}: scope 必须是对象")
        else:
            types = _norm_types(scope.get("applicable_types") or scope.get("doc_types"))
            when = str(scope.get("applicable_when") or scope.get("scope") or "").strip()
            if not types and not when:
                errors.append(f"{tag}: scope 必须声明 applicable_types 或 applicable_when"
                              f"（不允许隐式全量）")
            bad = [t for t in types if t in _WILDCARD_TYPES]
            if bad:
                errors.append(f"{tag}: scope.applicable_types 不得使用隐式全量通配："
                              f"{'、'.join(bad)}")
            unknown = [t for t in types if t not in KNOWN_TYPES]
            if unknown:
                errors.append(f"{tag}: scope.applicable_types 含未知类型："
                              f"{'、'.join(unknown)}（允许 {', '.join(sorted(KNOWN_TYPES))}）")
    rules = pack.get("rules")
    rule_codes = set()
    if rules is not None and not isinstance(rules, list):
        errors.append("rules 必须是数组（可为空）")
        rules = []
    for idx, rule in enumerate(rules or []):
        where = f"rules[{idx}]"
        if not isinstance(rule, dict):
            errors.append(f"{where} 必须是对象")
            continue
        rcode = str(rule.get("code") or "").strip()
        if not rcode:
            errors.append(f"{where} 缺少 code")
        elif rcode in rule_codes:
            errors.append(f"rules code 重复：{rcode}")
        else:
            rule_codes.add(rcode)
        refs = rule.get("points")
        if not isinstance(refs, list) or not refs:
            errors.append(f"{where} points 必须是非空数组（引用点位 code）")
        else:
            unknown_refs = [str(x) for x in refs if str(x) not in codes]
            if unknown_refs:
                errors.append(f"{where} 引用不存在的点位：{'、'.join(unknown_refs)}")
        logic = str(rule.get("logic") or "").strip()
        if logic and logic not in ("all", "any"):
            errors.append(f"{where} logic 只接受 all/any：{logic!r}")
    out_stats = stats(pack)
    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "stats": out_stats}


# ---------------------------------------------------------------- 统计 / 预览
def stats(pack) -> dict:
    """规则包计数：点位 / 强制项 / 组合规则 / 类别分布 / 命中文档类型。"""
    pack = pack if isinstance(pack, dict) else {}
    points = [p for p in (pack.get("points") or []) if isinstance(p, dict)]
    by_category, by_rclass, all_types = {}, {}, set()
    mandatory = 0
    executable = 0
    for point in points:
        cat = str(point.get("category") or "").strip()
        by_category[cat] = by_category.get(cat, 0) + 1
        rc = str(point.get("rclass") or "").strip().upper()
        by_rclass[rc] = by_rclass.get(rc, 0) + 1
        if point.get("mandatory") is True:
            mandatory += 1
        if _executable(point):
            executable += 1
        scope = point.get("scope") if isinstance(point.get("scope"), dict) else {}
        all_types |= set(_norm_types(scope.get("applicable_types")
                                     or scope.get("doc_types")))
    return {"schema": str(pack.get("schema") or PACK_SCHEMA),
            "pack": str(pack.get("pack") or ""),
            "industry": str(pack.get("industry") or ""),
            "version": str(pack.get("version") or ""),
            "points": len(points), "mandatory": mandatory,
            "executable": executable,
            "rules": len(pack.get("rules") or []),
            "by_category": dict(sorted(by_category.items())),
            "by_rclass": dict(sorted(by_rclass.items())),
            "applicable_types": sorted(all_types)}


def preview(pack) -> dict:
    """预览规则包（校验 + 逐点位摘要；**不落库**，不调用 create_rule）。"""
    validation = validate_pack(pack)
    points = []
    for point in (pack.get("points") or []) if isinstance(pack, dict) else []:
        if not isinstance(point, dict):
            continue
        steps = point.get("slots") if isinstance(point.get("slots"), dict) else {}
        scope = point.get("scope") if isinstance(point.get("scope"), dict) else {}
        points.append({
            "code": str(point.get("code") or ""),
            "name": str(point.get("name") or ""),
            "category": str(point.get("category") or ""),
            "rclass": str(point.get("rclass") or ""),
            "mandatory": point.get("mandatory") is True,
            "applicable_types": _norm_types(scope.get("applicable_types")
                                            or scope.get("doc_types")),
            "applicable_when": str(scope.get("applicable_when") or ""),
            "criterion": str(steps.get("criterion") or ""),
            "executable": _executable(point),
            "would_create": bool(str(point.get("code") or "").strip()),
        })
    return {"ok": validation["ok"], "dry_run": True,
            "note": "预览只做本地校验与统计，不写数据库",
            "validation": validation, "stats": validation["stats"],
            "points": points}


# ---------------------------------------------------------------- 应用（唯一写入口）
def _point_scope(point: dict) -> dict:
    scope = copy.deepcopy(point.get("scope") or {})
    scope["applicable_types"] = _norm_types(scope.get("applicable_types")
                                            or scope.get("doc_types"))
    scope.pop("doc_types", None)
    scope["mandatory"] = point.get("mandatory") is True
    return scope


def _point_slots(point: dict) -> dict:
    slots = copy.deepcopy(point.get("slots") or {})
    types = _norm_types((point.get("scope") or {}).get("applicable_types"))
    if types and not slots.get("applicable_types"):
        slots["applicable_types"] = types
    slots["mandatory"] = point.get("mandatory") is True
    slots["rule_pack"] = {
        "source": "rule_pack",
        "industry": str(point.get("_industry") or ""),
        "pack": str(point.get("_pack") or ""),
        "version": str(point.get("_version") or ""),
        "point_code": str(point.get("code") or ""),
    }
    return slots


def _existing_rule(code: str) -> dict:
    """只读查同编码规则（跨入口幂等；按当前 ctx 隔离）。"""
    try:
        from .. import repositories as R
        rows = R.rules.list("code=?", (code,), limit=1) or []
        return rows[0] if rows else {}
    except Exception:  # noqa: BLE001 - 查询失败按不存在处理，由 create_rule 决定是否重复
        return {}


def apply_pack(pack, actor: str = "system", dry_run: bool = True,
               publish=False, tenant_id: str = "", workspace_id: str = "",
               source: str = "rule_pack") -> dict:
    """应用规则包：默认 dry_run（只报告），``dry_run=False`` 时才逐条落库。

    参数：
        pack: 规则包 dict，或 JSON 文件路径。
        actor: 审计/创建人（传给 rule.create_rule 的 source 与 publish actor）。
        dry_run: 默认 True；True 时**不调用 create_rule、不写任何表**。
        publish: False（默认，只建草稿）/ True（全部发布）/ 规则编码集合（只发布这些）。
        tenant_id / workspace_id: 显式隔离上下文；不传则沿用调用方当前 ctx。
        source: 规则来源（默认 rule_pack；平台保留来源由 create_rule 拒绝）。

    返回：
        {ok, dry_run, pack, industry, version, stats, would_create,
         created: [{code, rule_id, status}], published: [{code, rule_id, status, error}],
         skipped: [{code, reason, rule_id}], errors: [{code, error}]}
    """
    if isinstance(pack, (str, Path)):
        try:
            pack = load_pack(pack)
        except (FileNotFoundError, ValueError) as exc:
            return {"ok": False, "dry_run": bool(dry_run), "errors": [{"code": "",
                                                                      "error": str(exc)}],
                    "stats": {}, "would_create": [], "created": [], "published": [],
                    "skipped": []}
    validation = validate_pack(pack)
    base = {"ok": False, "dry_run": bool(dry_run),
            "pack": str((pack or {}).get("pack") or ""),
            "industry": str((pack or {}).get("industry") or ""),
            "version": str((pack or {}).get("version") or ""),
            "stats": validation["stats"], "validation": validation,
            "would_create": [], "created": [], "published": [], "skipped": [],
            "errors": []}
    points = [p for p in ((pack or {}).get("points") or []) if isinstance(p, dict)]
    if not validation["ok"]:
        base["errors"] = [{"code": "", "error": e} for e in validation["errors"]]
        return base
    codes = [str(p.get("code") or "") for p in points]
    base["would_create"] = codes
    if dry_run:
        base["ok"] = True
        base["note"] = "dry_run：只报告将创建的点位，未调用 create_rule、未写数据库"
        return base

    # ---------------- 真落库：逐条复用 rule.create_rule（只读调用，不改 rule.py） ----------------
    from . import ctx as ctx_svc
    from . import rule as rule_svc

    # L98 P1：复用 ctx.scoped（嵌套安全 + 完整状态恢复），不再自带只会回
    # tenant/workspace 的 _Scoped。
    class _Scoped(ctx_svc.scoped):
        def __init__(self, tenant, workspace):
            super().__init__(tenant, workspace, allow_empty=True)

    publish_codes = None
    if publish is True:
        publish_codes = set(codes)
    elif isinstance(publish, (list, tuple, set)):
        publish_codes = {str(x) for x in publish}
    elif publish:
        base["errors"].append({"code": "", "error": f"publish 参数非法：{publish!r}"})
        return base

    created, published, skipped, errors = [], [], [], []
    try:
        with _Scoped(tenant_id, workspace_id):
            for point in points:
                code = str(point.get("code") or "")
                existing = _existing_rule(code)
                if existing:
                    skipped.append({"code": code, "reason": "duplicate_code",
                                    "rule_id": existing.get("id") or "",
                                    "message": f"规则编码已存在：{code}（跳过，不覆盖）"})
                    continue
                point = dict(point)
                point["_industry"] = base["industry"]
                point["_pack"] = base["pack"]
                point["_version"] = base["version"]
                try:
                    got = rule_svc.create_rule(
                        code=code, name=str(point.get("name") or code),
                        category=str(point.get("category") or ""),
                        rclass=str(point.get("rclass") or ""),
                        slots=_point_slots(point),
                        source=source, scope=_point_scope(point))
                except Exception as exc:  # noqa: BLE001 - 单条失败不静默：逐条返回
                    errors.append({"code": code,
                                   "error": f"{type(exc).__name__}: {exc}"})
                    continue
                rule_id = str(got.get("rule_id") or "")
                created.append({"code": code, "rule_id": rule_id,
                                "status": got.get("status") or "draft"})
                if publish_codes is not None and code in publish_codes and rule_id:
                    try:
                        pub = rule_svc.publish(rule_id, actor=actor)
                    except Exception as exc:  # noqa: BLE001
                        pub = {"error": f"{type(exc).__name__}: {exc}"}
                    published.append({"code": code, "rule_id": rule_id,
                                      "status": pub.get("status") or "",
                                      "error": pub.get("error") or "",
                                      "message": pub.get("message") or ""})
    except Exception as exc:  # noqa: BLE001 - 上下文/批量异常必须显式返回
        errors.append({"code": "", "error": f"{type(exc).__name__}: {exc}"})
    base.update({"created": created, "published": published,
                 "skipped": skipped, "errors": errors,
                 "ok": bool(created) and not errors})
    return base


# ---------------------------------------------------------------- 内置包发现
def list_packs(root=None) -> list:
    """列出 ``configs/rule_packs/<industry>/<pack>.json`` 下的规则包（读文件，不写库）。"""
    base = Path(root) if root else PACK_ROOT
    out = []
    if not base.is_dir():
        return out
    for path in sorted(base.glob("*/*.json")):
        item = {"path": str(path), "industry": path.parent.name,
                "file": path.name, "ok": False, "errors": [], "stats": {}}
        try:
            pack = load_pack(path)
            v = validate_pack(pack)
            item.update({"ok": v["ok"], "errors": v["errors"], "stats": v["stats"],
                         "pack": pack.get("pack") or path.stem})
        except (FileNotFoundError, ValueError) as exc:
            item["errors"] = [str(exc)]
        out.append(item)
    return out
