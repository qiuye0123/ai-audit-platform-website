# -*- coding: utf-8 -*-
"""主审核链编排：按需触发 OCR / 智能体 / 模型 / JEV / RSI，并记录触发与跳过原因。

原则：不是每份文件都跑所有能力；先判断是否需要，不需要就显式跳过并留痕。
"""
import os
from pathlib import Path

from . import agents

_TRACE = []


def _add(stage, status, reason="", detail=None):
    _TRACE.append({"stage": stage, "status": status, "reason": reason,
                   "detail": detail or {}})


def take_trace() -> list:
    out = list(_TRACE)
    _TRACE.clear()
    return out


def trace_mark() -> int:
    """记录轨迹水位：DAG 节点可据此提取「本节点内新增的智能体调用」。"""
    return len(_TRACE)


def trace_since(mark: int) -> list:
    """返回水位之后新增的轨迹（不清空全局轨迹，project.audit 仍可统一落库）。"""
    try:
        m = max(0, int(mark))
    except Exception:
        m = 0
    return list(_TRACE[m:])


def _ext(path):
    return (Path(path).suffix.lower().lstrip(".") if path else "")


def _parse_text(path):
    """取解析文本：优先复用 parse_bridge 产物，没有时由 agent-parse 生成一次。

    返回 dict：{text, run_id, ok, agent_mode, degraded, source, reason}。
    run_id 非空表示本次已经真实执行过 agent-parse，调用方不得重复解析。
    """
    try:
        from . import parse_bridge
        text = parse_bridge.text(path)
        if text:
            return {"text": text, "run_id": "", "ok": True, "agent_mode": "deterministic",
                    "degraded": False, "source": "cache", "reason": ""}
        # 没有解析产物时也由 agent-parse 生成，不再走直连解析；case 归因从线程上下文取
        _case = ""
        try:
            from . import ctx as _ctx_parse
            _case = _ctx_parse.get_case()
        except Exception:
            _case = ""
        r = agents.run_agent("agent-parse", {"path": path, "case_id": _case})
        _rr = r.get("result") or {}
        _ok = r.get("status") in ("ok", "degraded") and not _rr.get("error")
        return {"text": (parse_bridge.text(path) if _ok else ""),
                "run_id": r.get("run_id") or "", "ok": _ok,
                "agent_mode": _rr.get("agent_mode") or "deterministic",
                "degraded": bool(_rr.get("degraded")),
                "degraded_reason": str(_rr.get("degraded_reason") or ""),
                "skipped_reasons": _rr.get("skipped_reasons") or [],
                "source": "agent",
                "reason": "" if _ok else str(_rr.get("error") or r.get("status") or "")[:120]}
    except Exception as e:
        return {"text": "", "run_id": "", "ok": False, "agent_mode": "",
                "degraded": True, "source": "error",
                "degraded_reason": f"{type(e).__name__}: {str(e)[:120]}",
                "reason": f"{type(e).__name__}: {str(e)[:120]}"}


def _ocr_if_needed(path, text, ai_assist):
    """仅 PDF 且无文本层时触发；OCR 未配置则显式跳过，不假装执行。"""
    if _ext(path) != "pdf":
        _add("ocr", "skipped", "非 PDF，无需 OCR")
        return text, False
    try:
        from ..engine import ocr
        has_layer = ocr.detect_text_layer(path)
    except Exception as e:
        _add("ocr", "skipped", f"无法检测文本层：{type(e).__name__}")
        return text, False
    if has_layer and len((text or "").strip()) >= 20:
        _add("ocr", "skipped", "PDF 已有可提取文本层")
        return text, False
    try:
        from .. import config
        res = ocr.ocr_pdf_auto(path, config)
        ocr_text = (res or {}).get("text") if isinstance(res, dict) else ""
        if ocr_text:
            _add("ocr", "executed", "扫描件无文本层，已 OCR", {"chars": len(ocr_text)})
            return ocr_text, True
        _add("ocr", "skipped", "扫描件需要 OCR，但 OCR 引擎未配置")
        return text, False
    except Exception as e:
        _add("ocr", "failed", f"OCR 失败：{type(e).__name__}")
        return text, False


def parse_document(path: str, case_id: str = "", ai_assist: bool = True) -> dict:
    """单文件解析：OCR + agent-parse；返回 text/结构化标记，不执行 fact。

    同一文件在一次审核里只执行一次 agent-parse：命中 parse_bridge 缓存时补一次
    本轮 run_id；由 _parse_text 刚执行过时直接复用，避免一个文件两次解析。
    """
    if not path or not os.path.exists(path):
        _add("parse", "skipped", "文件不存在")
        return {"ok": False, "reason": "missing", "text": "", "unstructured": False,
                "ext": "", "agent": "agent-parse", "run_id": "",
                "agent_mode": "", "degraded": False, "skipped": True}
    _rp = _parse_text(path)
    if isinstance(_rp, str):  # 兼容旧测试/调用方注入的纯文本解析器
        _rp = {"text": _rp, "run_id": "", "ok": True, "agent_mode": "deterministic",
               "degraded": False, "source": "override", "reason": ""}
    if not isinstance(_rp, dict):
        _rp = {"text": "", "run_id": "", "ok": False, "agent_mode": "", "degraded": True,
               "source": "invalid", "reason": "解析器返回值非法"}
    text = _rp.get("text") or ""
    text, ocr_used = _ocr_if_needed(path, text, ai_assist)
    ext = _ext(path)
    unstructured = ext in ("pdf", "docx", "eml", "msg", "txt", "md")
    if not unstructured:
        _add("parse", "skipped", f"{ext or '未知'} 为结构化表格，使用确定性解析")
        return {"ok": True, "text": text, "unstructured": False, "ext": ext,
                "ocr_used": ocr_used, "agent": "agent-parse", "run_id": "",
                "agent_mode": "deterministic", "degraded": False,
                "skipped": True,
                "reason": f"{ext or '未知'} 为结构化表格，无需 agent-parse"}
    run_id = str(_rp.get("run_id") or "")
    mode = str(_rp.get("agent_mode") or "deterministic")
    degraded = bool(_rp.get("degraded"))
    degraded_reason = str(_rp.get("degraded_reason") or "")
    skipped_reasons = list(_rp.get("skipped_reasons") or [])
    try:
        if run_id:
            # 解析产物就是本轮 agent-parse 生成的：复用同一次执行，不再重复解析
            _add("parse", "executed" if _rp.get("ok") else "failed",
                 "" if _rp.get("ok") else str(_rp.get("reason") or ""),
                 {"agent": "agent-parse", "run_id": run_id, "agent_mode": mode,
                  "degraded": degraded})
        else:
            # 命中缓存：本轮仍需真实执行一次 agent-parse，留下可审计 run_id
            r = agents.run_agent("agent-parse", {"path": path, "text": text,
                                                 "case_id": case_id})
            _rr = r.get("result") or {}
            ok = r.get("status") in ("ok", "degraded") and not _rr.get("error")
            run_id = str(r.get("run_id") or "")
            mode = str(_rr.get("agent_mode") or "deterministic")
            degraded = bool(_rr.get("degraded"))
            degraded_reason = str(_rr.get("degraded_reason") or "")
            skipped_reasons = list(_rr.get("skipped_reasons") or [])
            _add("parse", "executed" if ok else "failed",
                 "" if ok else str(_rr.get("error") or r.get("status")),
                 {"agent": "agent-parse", "run_id": run_id, "agent_mode": mode,
                  "degraded": degraded})
    except Exception as e:
        _add("parse", "failed", f"agent-parse: {type(e).__name__}")
    return {"ok": True, "text": text, "unstructured": True, "ext": ext,
            "ocr_used": ocr_used, "agent": "agent-parse", "run_id": run_id,
            "agent_mode": mode, "degraded": degraded,
            # L108：解析降级原因随结果返回，调用方/DAG 轨迹不靠猜（扫描件无 OCR 等）
            "degraded_reason": degraded_reason,
            "skipped_reasons": skipped_reasons}


def extract_facts(path: str, text: str = "", case_id: str = "") -> dict:
    """单文件事实抽取：agent-fact，并把 facts 合并到 parse_bridge。"""
    try:
        r = agents.run_agent("agent-fact", {"path": path, "text": text, "case_id": case_id})
        res = r.get("result") or {}
        ok = r.get("status") in ("ok", "degraded") and not res.get("error")
        if ok:
            try:
                from . import parse_bridge as _pbf
                _pbf.merge_facts(path, res.get("facts") or [])
            except Exception:
                pass
        _add("extract", "executed" if ok else "failed",
             "" if ok else str(res.get("error") or r.get("status")),
             {"agent": "agent-fact", "run_id": r.get("run_id"),
              "agent_mode": res.get("agent_mode"), "degraded": res.get("degraded")})
        return {"ok": ok, "result": res, "run_id": r.get("run_id"),
                "agent": "agent-fact",
                "agent_mode": res.get("agent_mode") or "",
                "degraded": bool(res.get("degraded"))}
    except Exception as e:
        _add("extract", "failed", f"agent-fact: {type(e).__name__}")
        return {"ok": False, "result": {"error": type(e).__name__},
                "agent": "agent-fact", "run_id": "", "agent_mode": "", "degraded": True}


def preprocess(case_id: str, docs: list, ai_assist=True, doc_type="") -> list:
    """审核前置：逐文件 parse_document + extract_facts；返回 findings（通常空）。"""
    for d in docs or []:
        path = d.get("path") or ""
        parsed = parse_document(path, case_id=case_id, ai_assist=ai_assist)
        if not parsed.get("ok"):
            continue
        if not parsed.get("unstructured"):
            _add("extract", "skipped", "结构化表格字段由规则引擎直接读取")
            continue
        extract_facts(path, parsed.get("text") or "", case_id=case_id)
    _add("feedback", "skipped", "反馈归因/RSI 在人工复核后触发，不在审核阶段")
    return []


def annotate_jev() -> dict:
    """在主链路记录 JEV 状态：有校准样本才参与，否则显式跳过。"""
    try:
        from . import calibration
        n = len(calibration.samples())
        if n == 0:
            # 某些旧库/上下文下 scoped list 可能为空；用原始计数避免误报“无样本”
            try:
                from .. import db as _db
                with _db.session() as _c:
                    n = int(_c.execute("SELECT COUNT(*) FROM calibration").fetchone()[0])
            except Exception:
                pass
        _add("jev", "executed" if n else "skipped",
             f"校准样本 {n} 条" + ("，低置信弃权生效" if n else "，无法校准，保持原状态"))
        return {"samples": n}
    except Exception as e:
        _add("jev", "skipped", f"校准服务不可用：{type(e).__name__}")
        return {"samples": 0}


def judge_points(path: str, points: list, focus="", text="", case_id="") -> list:
    """主链路点位判定：先走 agent-judge；智能体不可用时才回退到 auditpoints。"""
    if not points:
        _add("judge", "skipped", "无待判定点位")
        return []
    try:
        r = agents.run_agent("agent-judge", {"path": path, "points": points, "focus": focus,
                                             "text": text, "case_id": case_id})
        res = (r.get("result") or {}).get("results")
        if r.get("status") == "ok" and isinstance(res, list):
            _rr = r.get("result") or {}
            _add("judge", "executed", "",
                 {"agent": "agent-judge", "run_id": r.get("run_id"), "count": len(res),
                  "agent_mode": _rr.get("agent_mode"), "degraded": _rr.get("degraded")})
            return res
        _add("judge", "failed", str((r.get("result") or {}).get("error") or r.get("status")))
    except Exception as e:
        _add("judge", "failed", f"agent-judge: {type(e).__name__}")
    # 回退：同一判定逻辑，不丢审核能力
    try:
        from . import auditpoints
        res = auditpoints.execute_points(path, points, focus, text=text)
        _add("judge", "executed", "agent-judge 不可用，回退确定性点位判定", {"count": len(res)})
        return res
    except Exception as e:
        _add("judge", "failed", f"fallback: {type(e).__name__}")
        return []


def policy_to_rules(policy_text: str, save: bool = False, case_id: str = "",
                    with_conflict: bool = True):
    """制度/标准 → 候选规则；默认随后做规则冲突分析。

    with_conflict=False 供 7 节点审核 DAG 使用：规则生成只跑 agent-rulegen，
    冲突分析交给 DAG 的 conflict 节点执行一次，避免同一轮重复调用 agent-conflict。
    """
    if not (policy_text or "").strip():
        _add("rulegen", "skipped", "本次未提供新制度/标准文本")
        _add("conflict", "skipped", "没有新候选规则")
        return {}
    out = {}
    try:
        r = agents.run_agent("agent-rulegen", {"text": policy_text, "save": bool(save), "case_id": case_id})
        _rg = r.get("result") or {}
        _rg.setdefault("agent", "agent-rulegen")
        _rg.setdefault("run_id", r.get("run_id") or "")
        out["rulegen"] = _rg
        _add("rulegen", "executed" if not _rg.get("degraded") else "degraded",
             "确定性回退" if _rg.get("degraded") else "",
             {"status": r.get("status"), "run_id": r.get("run_id"),
              "rule_id": _rg.get("rule_id"),
              "agent_mode": _rg.get("agent_mode"),
              "degraded": _rg.get("degraded"),
              "saved": bool(save)})
    except Exception as e:
        out["rulegen"] = {"error": f"{type(e).__name__}: {e}"}
        _add("rulegen", "failed", str(e)[:120])
    if not with_conflict:
        _add("conflict", "delegated", "冲突分析由审核 DAG 的 conflict 节点执行，避免重复分析")
        return out
    try:
        r = agents.run_agent("agent-conflict", {"persist": False, "include_drafts": True, "case_id": case_id})
        res = r.get("result") or {}
        out["conflict"] = res
        _add("conflict", "executed", "",
             {"status": r.get("status"), "run_id": r.get("run_id"),
              "agent_mode": res.get("agent_mode"), "degraded": res.get("degraded")})
    except Exception as e:
        out["conflict"] = {"error": f"{type(e).__name__}: {e}"}
        _add("conflict", "failed", str(e)[:120])
    return out


def audit_rule_health(case_id: str = "", include_drafts: bool = False):
    """每次审核都做一次当前空间规则健康检查（智能体必参与，不依赖新制度文本）。

    include_drafts=True 用于本次审核生成了新候选规则的场景（policy_text）：
    冲突分析要把草稿与已发布规则一起比较，且仍只调用 agent-conflict 一次。
    """
    try:
        r = agents.run_agent("agent-conflict", {"persist": False,
                                                "include_drafts": bool(include_drafts),
                                                "case_id": case_id})
        res = r.get("result") or {}
        n = len(res.get("conflicts") or [])
        _add("conflict", "executed",
             "新候选规则冲突分析" if include_drafts else "审核后规则健康检查",
             {"agent": "agent-conflict", "run_id": r.get("run_id"), "count": n,
              "include_drafts": bool(include_drafts),
              "agent_mode": res.get("agent_mode"), "degraded": res.get("degraded")})
        return {"conflicts": n, "run_id": r.get("run_id"), "agent": "agent-conflict",
                "include_drafts": bool(include_drafts),
                "agent_mode": res.get("agent_mode") or "",
                "degraded": bool(res.get("degraded"))}
    except Exception as e:
        _add("conflict", "failed", f"agent-conflict: {type(e).__name__}")
        return {"error": str(e)[:120], "agent": "agent-conflict", "run_id": ""}


def post_decision(finding_id: str, decision: str, feedback_id: str = ""):
    """复核后：误报归因智能体 + RSI 沉淀；不是每次审核都触发。"""
    if decision not in ("false_positive", "confirmed"):
        _add("feedback", "skipped", "决策类型不进入归因/RSI")
        return {}
    if decision != "false_positive":
        _add("feedback", "skipped", "确认项不触发误报归因")
        return {}
    out = {}
    try:
        _fp_case = ""
        try:
            from .. import repositories as _Rf
            _fp_case = str((_Rf.findings.get(finding_id) or {}).get("case_id") or "")
        except Exception:
            _fp_case = ""
        r = agents.run_agent("agent-fp", {"ai": True, "finding_id": finding_id,
                                          "feedback_id": feedback_id, "limit": 10,
                                          "case_id": _fp_case})
        out["feedback"] = r.get("result") or {}
        out["feedback_run_id"] = r.get("run_id") or ""
        _add("feedback", "executed", "", {"agent": "agent-fp", "run_id": r.get("run_id"),
                                           "count": (out["feedback"] or {}).get("count"),
                                           "agent_mode": (out["feedback"] or {}).get("agent_mode"),
                                           "degraded": (out["feedback"] or {}).get("degraded")})
    except Exception as e:
        _add("feedback", "failed", f"agent-fp: {type(e).__name__}")
    # RSI：误报反馈 → 归因/候选；只触发分析，不自动发布规则（留给 RSI 门禁/人工批准）
    if feedback_id and os.environ.get("RULEPROOF_RSI_AUTO", "1") != "0":
        try:
            from . import scheduler
            _sr = scheduler.scan_once(force=True)
            _add("rsi", "executed", "", {"trigger": "scan_once", "result": _sr})
            out["rsi"] = _sr
        except Exception as e:
            _add("rsi", "failed", f"rsi: {type(e).__name__}")
    else:
        _add("rsi", "skipped", "没有反馈 ID 或 RSI_AUTO=0")
    return out
