"""执行策略：不是“六选一模式”，而是证据范围/汇总/方法/缺失处理的组合计划。

本模块只做**计划**与**计划层校验**，不执行审核本身。计划必须区分“能力存在”
与“能力已接入 manifest D1–D5”：

- D3 证据绑定：document/block/row/sheet/document_set 均有真实校验路径；
  其中 document_set 只做“跨文件证据核验”，不做成对比较。
- D4 子要求判断：同对象内多个数值 occurrence 的 sum/compare 由 manifest_exec
  的 ruleexec 汇总路径执行；仍按单个 manifest 对象逐条执行。跨文件成对比较、
  跨文件 sum/compare 没有一级执行器，必须在计划里显式 unsupported。
- D5 组合：只做 all/any（由 manifest item 的 combination 驱动）；不要把这层
  说成能替代跨对象汇总。
- fallback=ask：计划给出带 ``format``/``required`` 的材料清单，并提供
  :func:`validate_ask_checklist`；manifest 补证记录当前只持久化 label/reason，
  因此同时提供 ``manifest_checklist``，把格式/必填写进 label，避免信息丢失。
"""
from __future__ import annotations

import json
import re

SCOPES = ("block", "row", "sheet", "document", "document_set")
AGGREGATIONS = ("single", "any", "all", "sum", "compare")
METHODS = ("deterministic", "semantic", "hybrid")
FALLBACKS = ("single_block_first", "ask", "abstain", "fail")
COMPARES = ("equal", "not_equal", "contains", "not_contains", "version_equal", "same")
CROSS_DOCUMENT_MODES = ("evidence", "pair", "aggregate")

# 材料格式的唯一口径；format 字段只接受这里的 code 或 aliases。
MATERIAL_FORMATS = {
    "pdf": {"label": "PDF", "extensions": [".pdf"]},
    "image": {"label": "图片", "extensions": [".jpg", ".jpeg", ".png", ".webp"]},
    "scanned": {"label": "扫描件", "extensions": [".pdf", ".jpg", ".jpeg", ".png"]},
    "docx": {"label": "Word", "extensions": [".docx", ".doc"]},
    "xlsx": {"label": "Excel", "extensions": [".xlsx", ".xls", ".xlsm"]},
    "csv": {"label": "CSV", "extensions": [".csv"]},
    "txt": {"label": "文本", "extensions": [".txt"]},
    "pptx": {"label": "PPT", "extensions": [".pptx", ".ppt"]},
    "zip": {"label": "压缩包", "extensions": [".zip", ".rar", ".7z"]},
    "any": {"label": "不限格式", "extensions": []},
}
_FORMAT_ALIASES = {
    "pdf": "pdf", "PDF": "pdf", "电子版": "pdf",
    "image": "image", "img": "image", "jpg": "image", "jpeg": "image",
    "png": "image", "图片": "image", "照片": "image", "截图": "image", "影像": "image",
    "scan": "scanned", "scanned": "scanned", "扫描": "scanned", "扫描件": "scanned",
    "doc": "docx", "docx": "docx", "word": "docx",
    "xls": "xlsx", "xlsx": "xlsx", "xlsm": "xlsx", "excel": "xlsx", "表格": "xlsx",
    "csv": "csv",
    "txt": "txt", "text": "txt", "文本": "txt",
    "ppt": "pptx", "pptx": "pptx", "幻灯片": "pptx",
    "zip": "zip", "rar": "zip", "7z": "zip", "压缩包": "zip",
    "any": "any", "不限": "any", "不限格式": "any", "任意": "any",
}
_EXT_FORMAT = {
    ".pdf": "pdf", ".jpg": "image", ".jpeg": "image", ".png": "image", ".webp": "image",
    ".gif": "image", ".bmp": "image", ".doc": "docx", ".docx": "docx",
    ".xls": "xlsx", ".xlsx": "xlsx", ".xlsm": "xlsx", ".csv": "csv",
    ".txt": "txt", ".ppt": "pptx", ".pptx": "pptx",
    ".zip": "zip", ".rar": "zip", ".7z": "zip",
}
_FORMAT_KEYWORDS = (
    ("扫描", "scanned"), ("照片", "image"), ("图片", "image"), ("截图", "image"),
    ("影像", "image"), ("pdf", "pdf"), ("电子版", "pdf"), ("excel", "xlsx"),
    ("xlsx", "xlsx"), ("工作表", "xlsx"), ("台账", "xlsx"), ("word", "docx"),
    ("docx", "docx"), ("csv", "csv"), ("txt", "txt"), ("文本", "txt"),
    ("ppt", "pptx"), ("压缩包", "zip"),
)
_COMPARE_ALIASES = {
    "=": "equal", "==": "equal", "eq": "equal", "equal": "equal", "same": "same",
    "一致": "equal", "相同": "equal", "相符": "equal", "匹配": "equal", "对应": "equal",
    "!=": "not_equal", "≠": "not_equal", "not_equal": "not_equal", "不等": "not_equal",
    "contains": "contains", "包含": "contains", "include": "contains",
    "not_contains": "not_contains", "不包含": "not_contains",
    "version_equal": "version_equal", "版本一致": "version_equal", "版本相同": "version_equal",
}
_CROSS_MODE_ALIASES = {
    "evidence": "evidence", "证据": "evidence", "证据核验": "evidence", "cross_file": "evidence",
    "pair": "pair", "pairs": "pair", "pairwise": "pair", "compare": "pair",
    "成对": "pair", "对比": "pair", "跨文件比较": "pair",
    "aggregate": "aggregate", "aggregation": "aggregate", "汇总": "aggregate",
    "sum": "aggregate", "合计": "aggregate", "统计": "aggregate",
}


# ---------------------------------------------------------------- 基础归一

def _text(value) -> str:
    return str(value or "").strip()


def _list(value) -> list:
    """证据范围/简单列表拆分；保留顺序、去空、不猜值。"""
    if isinstance(value, str):
        return [x.strip() for x in re.split(r"[,，;；、/\n]+", value) if x.strip()]
    if isinstance(value, (list, tuple, set)):
        return [str(x).strip() for x in value if str(x).strip()]
    return [str(value).strip()] if str(value or "").strip() else []


def _split_terms(value) -> list:
    """证据项拆分：括号内的逗号/斜线不拆（如“检验报告（PDF/扫描件）”）。"""
    if isinstance(value, (list, tuple, set)):
        out = []
        for item in value:
            out.extend(_split_terms(item))
        return out
    text = str(value or "")
    out, buf, depth = [], [], 0
    for ch in text:
        if ch in "（(【[":
            depth += 1
        elif ch in "）)】]":
            depth = max(0, depth - 1)
        if ch in "、,，;；/\n" and depth == 0:
            term = "".join(buf).strip()
            if term:
                out.append(term)
            buf = []
        else:
            buf.append(ch)
    term = "".join(buf).strip()
    if term:
        out.append(term)
    return out


def _unique(values) -> list:
    out = []
    for value in values or []:
        if value is None:
            continue
        value = str(value).strip()
        if value and value not in out:
            out.append(value)
    return out


def _as_bool(value, default=True):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    if text in ("true", "1", "yes", "y", "是", "必填", "required"):
        return True
    if text in ("false", "0", "no", "n", "否", "选填", "optional"):
        return False
    return default


def _as_count(value, default=1):
    if isinstance(value, bool):
        return default
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    try:
        number = int(str(value).strip())
    except Exception:
        return default
    return number if 1 <= number <= 99 else default


def _count_valid(value) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, float):
        return value.is_integer() and 1 <= int(value) <= 99
    try:
        number = int(str(value).strip())
    except Exception:
        return False
    return 1 <= number <= 99


def _norm_compare(value) -> str:
    text = _text(value).lower()
    if text in _COMPARE_ALIASES:
        return _COMPARE_ALIASES[text]
    return text if text in COMPARES else ""


def _norm_across(value) -> str:
    text = _text(value).lower()
    if text in ("document_set", "document-set", "跨文档", "跨文件", "多文档", "cross_document"):
        return "document_set"
    if text in ("fields", "字段", "跨字段", "field"):
        return "fields"
    return "document"


def _norm_cross_mode(value) -> str:
    text = _text(value).lower()
    return _CROSS_MODE_ALIASES.get(text, "")


def _norm_format(value) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple, set)):
        codes = [_norm_format(x) for x in value]
        codes = [x for x in codes if x]
        if not codes:
            return ""
        return codes[0] if len(set(codes)) == 1 else "any"
    text = _text(value).lower()
    if not text:
        return ""
    text = text.lstrip("*").strip()
    if text in _FORMAT_ALIASES:
        return _FORMAT_ALIASES[text]
    if text.startswith("."):
        return _EXT_FORMAT.get(text, "")
    parts = [p.strip(" .*") for p in re.split(r"[/,，、;；\s]+", text) if p.strip(" .*")]
    codes = {_FORMAT_ALIASES.get(part, "") for part in parts}
    codes.discard("")
    if len(codes) == 1:
        return codes.pop()
    if codes:
        return "any"
    return ""


def _infer_format(text: str, extensions=None) -> str:
    exts = list(extensions or [])
    codes = {_EXT_FORMAT.get(ext) for ext in exts}
    codes.discard(None)
    if len(codes) == 1:
        return codes.pop()
    low = str(text or "").lower()
    for token, code in _FORMAT_KEYWORDS:
        if token in low:
            return code
    return "any"


def _parse_extensions(value):
    """返回 (规范化扩展名, 非法项)。非法项交给调用方决定 warning/error。"""
    out, bad = [], []
    if value is None:
        return out, bad
    if isinstance(value, str):
        parts = re.split(r"[,，、;；\s]+", value)
    elif isinstance(value, (list, tuple, set)):
        parts = list(value)
    else:
        return out, [str(value)]
    for part in parts:
        raw = str(part).strip().lower()
        if not raw:
            continue
        raw = raw.lstrip("*")
        raw = raw if raw.startswith(".") else "." + raw
        if re.fullmatch(r"\.[a-z0-9]{1,8}", raw):
            if raw not in out:
                out.append(raw)
        else:
            bad.append(raw)
    return out, bad


def _format_label(code: str) -> str:
    return str((MATERIAL_FORMATS.get(code) or MATERIAL_FORMATS["any"])["label"])


def _display_label(material: dict) -> str:
    bits = []
    if int(material.get("min_count") or 1) > 1:
        bits.append(f"{material['min_count']}份")
    if material.get("format") and material["format"] != "any":
        bits.append(_format_label(material["format"]))
    bits.append("必填" if material.get("required") else "选填")
    label = _text(material.get("label"))
    suffix = "（" + "，".join(bits) + "）"
    if len(label) + len(suffix) > 200:
        label = label[: max(1, 200 - len(suffix) - 1)] + "…"
    return label + suffix


# ---------------------------------------------------------------- ask 材料清单

def _material_from_spec(spec, source: str, warnings: list):
    """把槽位里的材料声明归一为计划材料；名称缺失/类型不支持时返回 None。"""
    if isinstance(spec, str):
        label, reason = spec.strip(), ""
        required, raw_format, exts, min_count = True, "", [], 1
    elif isinstance(spec, dict):
        label = _text(spec.get("label") or spec.get("item") or spec.get("name") or spec.get("title"))
        reason = _text(spec.get("reason") or spec.get("note") or spec.get("why"))
        required = _as_bool(spec.get("required", spec.get("mandatory")), True)
        raw_format = spec.get("format") or spec.get("file_type") or spec.get("accept") or ""
        exts, bad = _parse_extensions(spec.get("extensions") or spec.get("accept") or spec.get("file_types"))
        for item in bad:
            warnings.append(f"材料扩展名不合法：{item}")
        raw_min = spec.get("min_count", spec.get("count"))
        min_count = _as_count(raw_min, 1)
        if raw_min not in (None, "") and not _count_valid(raw_min):
            warnings.append(f"材料份数不合法：{raw_min}（已按 1 份处理）")
    else:
        warnings.append("补证材料声明类型不支持，已忽略")
        return None
    if not label:
        warnings.append("补证材料缺少名称，已忽略")
        return None
    if len(label) > 180:
        label = label[:179] + "…"
        warnings.append("补证材料名称过长，已截断")
    fmt = _norm_format(raw_format) if raw_format else ""
    format_note = ""
    if raw_format and not fmt:
        format_note = _text(raw_format)
        fmt = _infer_format(label + " " + format_note, exts)
        warnings.append(f"未识别的材料格式：{format_note}（按 {_format_label(fmt)} 处理）")
    elif not fmt:
        fmt = _infer_format(label + " " + reason, exts)
    if not exts:
        exts = list((MATERIAL_FORMATS.get(fmt) or MATERIAL_FORMATS["any"])["extensions"])
    return {
        "label": label, "reason": reason or "补证材料",
        "required": bool(required), "format": fmt, "format_label": _format_label(fmt),
        "extensions": exts, "min_count": min_count, "source": source,
        "format_note": format_note,
    }


def _merge_material(materials: list, material: dict, warnings: list) -> None:
    for old in materials:
        if old["label"] != material["label"]:
            continue
        old["required"] = bool(old["required"] or material["required"])
        old["min_count"] = max(int(old["min_count"]), int(material["min_count"]))
        if old["format"] == "any" and material["format"] != "any":
            old["format"] = material["format"]
            old["format_label"] = material["format_label"]
        elif (old["format"] != material["format"]
              and "any" not in (old["format"], material["format"])):
            old["format"] = "any"
            old["format_label"] = _format_label("any")
            warnings.append(f"材料「{material['label']}」出现多种格式，已按不限格式处理")
        for ext in material.get("extensions") or []:
            if ext not in old["extensions"]:
                old["extensions"].append(ext)
        if not old.get("reason") and material.get("reason"):
            old["reason"] = material["reason"]
        return
    materials.append(material)


def _build_materials(slots: dict, warnings: list) -> list:
    specs = []

    def _add_specs(value, source):
        if value is None or value == "" or value == []:
            return
        if isinstance(value, dict):
            specs.append((value, source))
        elif isinstance(value, (list, tuple, set)):
            for item in value:
                specs.append((item, source))
        else:
            specs.append((value, source))

    for key in ("ask_materials", "required_materials", "evidence_materials",
                "ask_checklist", "materials"):
        _add_specs(slots.get(key), key)

    for key in ("required_evidence", "evidence_required", "evidence"):
        value = slots.get(key)
        if isinstance(value, str) or isinstance(value, (list, tuple, set)):
            for term in _split_terms(value):
                specs.append(({"label": term, "reason": "规则要求证据", "source": "required_evidence"},
                              "required_evidence"))

    subs = slots.get("subrequirements") or slots.get("criteria_list") or []
    if isinstance(subs, (list, tuple)):
        for sub in subs:
            if not isinstance(sub, dict):
                continue
            sid = _text(sub.get("id") or sub.get("sub_id") or "")
            value = (sub.get("required_evidence") or sub.get("evidence_required")
                     or sub.get("evidence"))
            if isinstance(value, (list, tuple, set)) or isinstance(value, str):
                for term in _split_terms(value):
                    reason = f"子要求 {sid} 要求证据" if sid else "子要求要求证据"
                    specs.append(({"label": term, "reason": reason,
                                   "source": f"subrequirement:{sid}"}, "subrequirement"))

    materials = []
    for spec, source in specs:
        material = _material_from_spec(spec, source, warnings)
        if material:
            _merge_material(materials, material, warnings)
    if len(materials) > 20:
        warnings.append("补证材料超过 20 项，已截断")
        materials = materials[:20]
    return materials


def _ask_checklist(materials: list) -> list:
    return [{
        "label": item["label"], "reason": item["reason"],
        "required": bool(item["required"]), "format": item["format"],
        "extensions": list(item["extensions"]), "min_count": int(item["min_count"]),
    } for item in materials]


def _manifest_checklist(materials: list) -> list:
    """兼容 manifest_evidence 当前只保留 label/reason 的清单形态。"""
    return [{"label": _display_label(item), "reason": item["reason"],
             "required": bool(item["required"]), "format": item["format"],
             "extensions": list(item["extensions"])} for item in materials]


def _norm_material_input(material) -> dict | None:
    if isinstance(material, str):
        label = material.strip()
        return {"label": label, "required": True, "format": "any",
                "extensions": [], "min_count": 1} if label else None
    if not isinstance(material, dict):
        return None
    label = _text(material.get("label") or material.get("item") or material.get("name"))
    if not label:
        return None
    fmt = _norm_format(material.get("format")) or "any"
    exts, _bad = _parse_extensions(material.get("extensions"))
    if not exts:
        exts = list((MATERIAL_FORMATS.get(fmt) or MATERIAL_FORMATS["any"])["extensions"])
    return {"label": label, "required": _as_bool(material.get("required"), True),
            "format": fmt, "extensions": exts,
            "min_count": _as_count(material.get("min_count", material.get("count")), 1)}


def validate_ask_checklist(checklist, materials=None, strict: bool = False) -> dict:
    """校验补证材料清单：名称必填、required 必须是布尔、format/扩展名合法、
    必需材料不得缺失。返回 ``{ok, errors, warnings, normalized}``。

    ``materials`` 为 :func:`derive` 生成的材料计划；提供时做“必填材料是否覆盖”
    校验。``strict=True`` 时字符串条目也视为错误（默认兼容旧清单，转成对象并 warning）。
    """
    errors, warnings, normalized = [], [], []

    def _error(index, field, code, message):
        errors.append({"index": index, "field": field, "code": code, "message": message})

    if checklist is None:
        _error(None, "checklist", "checklist_required", "补证清单不能为空")
        return {"ok": False, "errors": errors, "warnings": warnings, "normalized": normalized}
    if isinstance(checklist, dict) or not isinstance(checklist, (list, tuple)):
        _error(None, "checklist", "checklist_not_list", "补证清单必须是数组")
        return {"ok": False, "errors": errors, "warnings": warnings, "normalized": normalized}
    items = list(checklist)
    if not items:
        _error(None, "checklist", "checklist_empty", "补证清单至少需要一项材料")
    if len(items) > 20:
        _error(None, "checklist", "too_many_items", "补证清单最多 20 项")

    for index, raw in enumerate(items[:20]):
        if isinstance(raw, str):
            if strict:
                _error(index, "item", "item_not_object", "清单条目必须是对象")
                continue
            warnings.append(f"第 {index + 1} 项为旧版字符串，已按必填材料归一")
            item = {"label": raw}
        elif isinstance(raw, dict):
            item = dict(raw)
        else:
            _error(index, "item", "item_not_object", "清单条目必须是对象")
            continue

        label_raw = item.get("label", item.get("item", item.get("name")))
        if not isinstance(label_raw, str) or not label_raw.strip():
            _error(index, "label", "label_required", "材料名称不能为空")
            continue
        label = label_raw.strip()
        if len(label) > 200:
            _error(index, "label", "label_too_long", "材料名称不能超过 200 字")

        reason = item.get("reason", item.get("note", ""))
        if reason is None:
            reason = ""
        if not isinstance(reason, str):
            _error(index, "reason", "reason_not_text", "补证理由必须是字符串")
            reason = str(reason)
        if len(reason) > 500:
            _error(index, "reason", "reason_too_long", "补证理由不能超过 500 字")

        required_raw = item.get("required", None)
        required_explicit = required_raw is not None
        if required_raw is None:
            required = True
        elif isinstance(required_raw, bool):
            required = required_raw
        elif isinstance(required_raw, str) and required_raw.strip().lower() in (
                "true", "1", "yes", "y", "是", "必填", "required",
                "false", "0", "no", "n", "否", "选填", "optional"):
            required = _as_bool(required_raw, True)
            warnings.append(f"第 {index + 1} 项 required 使用字符串，已归一为布尔")
        else:
            _error(index, "required", "required_not_bool", "required 必须是布尔值")
            required = True

        fmt_raw = item.get("format")
        fmt = ""
        if fmt_raw is not None and str(fmt_raw).strip():
            if not isinstance(fmt_raw, str):
                _error(index, "format", "format_not_text", "format 必须是字符串")
            else:
                fmt = _norm_format(fmt_raw)
                if not fmt:
                    _error(index, "format", "format_unknown",
                           f"不支持的材料格式：{fmt_raw}；可用 "
                           + "/".join(sorted(MATERIAL_FORMATS)))
        exts, bad_exts = _parse_extensions(item.get("extensions"))
        for bad in bad_exts:
            _error(index, "extensions", "extension_invalid", f"扩展名不合法：{bad}")
        if not fmt and exts:
            fmt = _infer_format("", exts)

        min_raw = item.get("min_count", item.get("count", 1))
        if not _count_valid(min_raw):
            _error(index, "min_count", "min_count_invalid", "min_count 必须是 1–99 的整数")
        min_count = _as_count(min_raw, 1)

        if strict:
            for key in item:
                if key not in ("label", "item", "name", "reason", "note", "required",
                               "format", "extensions", "min_count", "count"):
                    warnings.append(f"第 {index + 1} 项存在未使用字段：{key}")

        normalized.append({
            "label": label, "reason": reason, "required": required,
            "format": fmt, "extensions": exts, "min_count": min_count,
            "_required_explicit": required_explicit,
        })

    material_map = {}
    for material in materials or []:
        norm = _norm_material_input(material)
        if norm:
            material_map[norm["label"]] = norm

    seen_labels = {}
    for index, item in enumerate(normalized):
        label = item["label"]
        material = material_map.get(label)
        if material:
            if not item["_required_explicit"]:
                item["required"] = material["required"]
            if material["required"] and not item["required"]:
                _error(index, "required", "required_material_optional",
                       f"必需材料「{label}」被标记为选填")
            if not item["format"]:
                item["format"] = material["format"]
            if not item["extensions"]:
                item["extensions"] = list(material["extensions"])
            if (item["format"] and material["format"] != "any"
                    and item["format"] != material["format"]):
                warnings.append(f"材料「{label}」格式与计划不一致："
                                f"{item['format']} != {material['format']}")
        elif material_map:
            warnings.append(f"清单材料「{label}」不在计划材料中")
        if label in seen_labels:
            warnings.append(f"材料「{label}」重复出现")
        seen_labels[label] = seen_labels.get(label, 0) + 1
        item.pop("_required_explicit", None)

    for label, material in material_map.items():
        if not material["required"]:
            continue
        matches = [x for x in normalized if x["label"] == label]
        if not matches:
            _error(None, "label", "required_material_missing",
                   f"缺少必需材料「{label}」")
            continue
        amount = max([int(x.get("min_count") or 1) for x in matches] + [len(matches)])
        if amount < int(material["min_count"]):
            _error(None, "min_count", "required_material_count",
                   f"必需材料「{label}」至少需要 {material['min_count']} 项")

    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "normalized": normalized}


# ---------------------------------------------------------------- 计划子块

def _exec(exec_id: str, step: str, capability: str, supported: bool,
          reason: str = "", mode: str = "", warnings=None) -> dict:
    return {"id": exec_id, "step": step, "capability": capability, "mode": mode,
            "supported": bool(supported), "reason": reason or "",
            "warnings": list(warnings or [])}


def _relations(slots: dict) -> list:
    raw = slots.get("relations")
    if raw is None:
        raw = slots.get("relation")
    if isinstance(raw, str):
        text = raw.strip()
        if text:
            try:
                raw = json.loads(text)
            except Exception:
                raw = []
        else:
            raw = []
    if isinstance(raw, dict):
        raw = [raw]
    out = []
    for item in (raw or []) if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            continue
        left = _text(item.get("left") or item.get("a") or item.get("lhs") or item.get("from"))
        right = _text(item.get("right") or item.get("b") or item.get("rhs") or item.get("to"))
        compare = _norm_compare(item.get("compare") or item.get("op") or item.get("operator"))
        across = _norm_across(item.get("across") or item.get("scope") or "document")
        if left or right:
            out.append({"left": left, "right": right, "compare": compare or "equal",
                        "across": across, "complete": bool(left and right),
                        "source": "relations"})
    if not out:
        left = _text(slots.get("left"))
        right = _text(slots.get("right"))
        if left or right:
            out.append({"left": left, "right": right,
                        "compare": _norm_compare(slots.get("compare") or slots.get("op")) or "equal",
                        "across": _norm_across(slots.get("across") or "document"),
                        "complete": bool(left and right), "source": "slots"})
    return out


def _object_name(value) -> str:
    if isinstance(value, dict):
        return _text(value.get("object_id") or value.get("id") or value.get("filename")
                     or value.get("name") or value.get("title") or value.get("label"))
    return _text(value)


def _objects(slots: dict, cross_spec: dict) -> list:
    raw = (cross_spec.get("objects") or cross_spec.get("object_ids")
           or slots.get("compare_objects") or slots.get("objects") or [])
    if isinstance(raw, (str, dict)):
        raw = [raw]
    out = []
    for item in raw if isinstance(raw, (list, tuple)) else []:
        name = _object_name(item)
        if name and name not in out:
            out.append(name)
    return out


def _pairs(slots: dict, cross_spec: dict, relations: list, objects: list) -> list:
    out = []

    def _add(left, right, compare, across, source):
        left, right = _text(left), _text(right)
        if not left or not right:
            return
        row = {"left": left, "right": right, "compare": _norm_compare(compare) or "equal",
               "across": _norm_across(across) or "document", "source": source}
        if not any(x["left"] == row["left"] and x["right"] == row["right"]
                   and x["compare"] == row["compare"] and x["across"] == row["across"]
                   for x in out):
            out.append(row)

    for rel in relations:
        if rel.get("complete"):
            _add(rel["left"], rel["right"], rel["compare"], rel["across"], "relations")

    explicit_pairs = []
    for source, value in (("cross_document", cross_spec.get("pairs")),
                          ("slots", slots.get("pairs")),
                          ("slots", slots.get("compare_pairs"))):
        if isinstance(value, (list, tuple)):
            explicit_pairs.extend(value)
        elif isinstance(value, dict):
            explicit_pairs.append(value)
    for pair in explicit_pairs:
        if isinstance(pair, dict):
            _add(pair.get("left") or pair.get("a"), pair.get("right") or pair.get("b"),
                 pair.get("compare") or pair.get("op"),
                 pair.get("across") or "document_set", "pairs")

    if not out and len(objects) == 2:
        _add(objects[0], objects[1], slots.get("compare") or slots.get("op") or "equal",
             "document_set", "objects")
    return out


def _sheet_limit_values(slots: dict) -> list:
    raw = []
    for key in ("sheet_name", "evidence_scope_sheet", "sheet_names", "evidence_scope_sheets"):
        value = slots.get(key)
        if value:
            raw.extend(_list(value))
    return _unique(raw)


def _cross_document_plan(slots: dict, scopes: list, agg: str,
                         relations: list, objects: list, warnings: list) -> dict:
    raw = slots.get("cross_document")
    spec = raw if isinstance(raw, dict) else {}
    explicit = bool(raw) and raw not in (False, "", {}, [])
    explicit_mode = ""
    if isinstance(raw, dict):
        explicit_mode = _norm_cross_mode(raw.get("mode") or raw.get("kind"))
    elif isinstance(raw, str):
        explicit_mode = _norm_cross_mode(raw)
    scope_requested = "document_set" in scopes
    pair_relations = [rel for rel in relations if rel.get("across") == "document_set"]
    # 裸 objects 可能只是 R4 关系操作数（同文档比较），不能据此打开跨文件模式；
    # 只认 document_set / 显式 cross_document / compare_objects / pairs 这些跨文件信号。
    pair_requested = bool(
        pair_relations
        or _norm_across(slots.get("across")) == "document_set"
        or explicit_mode == "pair"
        or spec.get("objects") or spec.get("object_ids") or spec.get("pairs")
        or slots.get("compare_objects") or slots.get("pairs")
        or slots.get("compare_pairs")
    )
    cross_base = bool(scope_requested or explicit or pair_requested)
    if not cross_base:
        return {"enabled": False, "scope": "", "requested_scope": False, "mode": "",
                "aggregation": "", "pair_requested": False,
                "min_objects": 2, "objects": [], "pairs": [],
                "evidence_supported": True, "pair_supported": False,
                "aggregate_supported": False, "supported": True, "executor": "",
                "reason": "", "unsupported": [], "warnings": [], "executors": []}

    if raw and not explicit_mode and not isinstance(raw, bool):
        raw_mode = raw.get("mode") or raw.get("kind") if isinstance(raw, dict) else raw
        raw_text = str(raw_mode or "").strip()
        if raw_text and raw_text not in ("document_set", "跨文件", "跨文档", "多文档", "cross_document"):
            warnings.append(f"未识别的 cross_document 模式：{raw_text}")

    mode = explicit_mode
    if not mode:
        if agg in ("compare", "sum"):
            mode = "aggregate"
        elif pair_requested:
            mode = "pair"
        elif scope_requested:
            mode = "evidence"
        else:
            mode = "pair"

    pairs = _pairs(slots, spec, relations, objects)
    local_warnings, unsupported, executors = [], [], []
    evidence_supported = bool(scope_requested)
    pair_supported = False
    aggregate_supported = False

    if evidence_supported:
        executors.append(_exec("cross_document.evidence", "D3", "cross_document",
                               True, "", "evidence"))
        if not _split_terms(slots.get("required_evidence") or slots.get("evidence_required")):
            local_warnings.append("document_set 已请求，但未声明 required_evidence，D3 无法核验跨文件证据")
    elif mode == "evidence":
        reason = "cross_document 声明为 evidence，但 evidence_scope 未包含 document_set"
        unsupported.append(reason)
        executors.append(_exec("cross_document.evidence", "D3", "cross_document",
                               False, reason, "evidence"))
    else:
        local_warnings.append("cross_document 未声明 document_set，D3 不会核验跨文件证据")

    mode_reason = ""
    if mode == "pair":
        mode_reason = ("跨文件成对比较没有一级 manifest 执行器；D3 只核验跨文件证据，"
                       "D4 仍逐文件判断")
        unsupported.append(mode_reason)
        executors.append(_exec("cross_document.pair", "D4", "cross_document",
                               False, mode_reason, "pair"))
        if not pairs:
            local_warnings.append("未提供跨文件成对比较的对象/关系，pair 模式无法形成比较对")
        if len(objects) > 2:
            local_warnings.append("跨文件成对比较一次只支持两个对象；当前声明了 "
                                  f"{len(objects)} 个对象")
        if pair_relations:
            local_warnings.append("检测到跨文件关系条件，但 manifest D1–D5 未消费 typed relations")
    elif mode == "aggregate":
        mode_reason = ("跨文件 compare/sum 汇总没有一级 manifest 执行器；"
                       "D4 只消费单个对象文本，不会跨文件求和或比较")
        unsupported.append(mode_reason)
        executors.append(_exec("cross_document.aggregate", "D5", "cross_document",
                               False, mode_reason, "aggregate"))
        local_warnings.append("document_set 证据核验仍可执行，但跨文件汇总会退化为逐文件判断")
    elif mode == "evidence":
        if pair_requested:
            local_warnings.append("检测到跨文件对象/关系，但 cross_document 模式为 evidence，"
                                  "成对比较不会执行")
    else:
        local_warnings.append(f"未识别的 cross_document 模式：{mode}")
        unsupported.append("cross_document 模式无法识别，不能按已支持能力执行")
        executors.append(_exec("cross_document.mode", "D3", "cross_document",
                               False, unsupported[-1], str(mode)))

    supported = (mode == "evidence" and evidence_supported)
    return {"enabled": True, "scope": "document_set" if scope_requested else "",
            "requested_scope": bool(scope_requested), "mode": mode,
            "aggregation": agg if mode == "aggregate" else "",
            "pair_requested": bool(pair_requested),
            "min_objects": 2, "objects": objects, "pairs": pairs,
            "evidence_supported": evidence_supported, "pair_supported": pair_supported,
            "aggregate_supported": aggregate_supported, "supported": supported,
            "executor": ("manifest.d3.document_set_evidence" if supported
                         else ("unsupported.cross_document_pair" if mode == "pair"
                               else "unsupported.cross_document_aggregate")),
            "reason": mode_reason or (unsupported[0] if unsupported else ""),
            "unsupported": _unique(unsupported), "warnings": _unique(local_warnings),
            "executors": executors}


def _aggregation_config(slots: dict, scopes: list, kind: str) -> dict:
    """sum/compare 的可执行性：只在 D4 的数值子要求（无 tool）上生效。

    与 manifest_exec 的真实执行路径对齐：没有 metric、没有 value/threshold、
    或所有子要求都被 tool 接管时，计划必须显式不可执行，不能只报“已支持”。
    """
    subs = slots.get("subrequirements") or slots.get("criteria_list") or []
    subs = [sub for sub in subs if isinstance(sub, dict)] if isinstance(subs, list) else []
    top_metric = _text(slots.get("metric") or slots.get("parameter"))
    top_threshold = slots.get("value", slots.get("threshold"))
    top_unit = _text(slots.get("unit"))
    numeric_subs = [sub for sub in subs
                    if _text(sub.get("metric") or sub.get("parameter")) and not sub.get("tool")]
    tool_subs = [sub for sub in subs if sub.get("tool")]
    ready_subs = [sub for sub in numeric_subs
                  if sub.get("value", sub.get("threshold")) not in (None, "")]
    metric, unit, threshold = top_metric, top_unit, top_threshold
    source = "slots" if top_metric else ""
    if subs:
        source = "subrequirements"
        if numeric_subs:
            metric = _text(numeric_subs[0].get("metric") or numeric_subs[0].get("parameter"))
            unit = _text(numeric_subs[0].get("unit")) or top_unit
            threshold = (ready_subs[0].get("value", ready_subs[0].get("threshold"))
                         if ready_subs else None)
        else:
            metric, unit, threshold = "", "", None
        ready = bool(ready_subs)
        if not numeric_subs:
            if tool_subs and len(tool_subs) == len(subs):
                reason = f"所有子要求都使用 tool，aggregation {kind} 不会执行"
            else:
                reason = f"subrequirements 中没有带 metric 的数值子要求，aggregation {kind} 不会执行"
        elif not ready:
            reason = f"数值子要求缺少 value/threshold，aggregation {kind} 无法判定"
        else:
            reason = ""
    else:
        ready = bool(top_metric) and top_threshold not in (None, "")
        reason = "" if ready else (
            f"{kind} 未声明 metric，无法确定汇总对象" if not top_metric
            else f"{kind} 未声明 value/threshold，无法判定汇总结果")
        if slots.get("tool"):
            ready = False
            reason = f"顶层 tool={slots.get('tool')} 优先执行，aggregation {kind} 不会执行"

    warnings = []
    if metric and not unit:
        warnings.append(f"{kind} 未声明 unit，无法校验汇总量纲")
    if subs and numeric_subs and len(ready_subs) < len(numeric_subs):
        warnings.append(f"部分数值子要求缺少 value/threshold，{kind} 会退回单项判断")
    if tool_subs and numeric_subs:
        warnings.append(f"存在 tool 子要求，aggregation {kind} 只作用于无 tool 的数值子要求")
    if "document_set" in scopes:
        warnings.append(f"aggregation {kind} 只在单个 manifest 对象内生效，跨文件汇总仍不支持")
    if "sheet" in scopes and not _sheet_limit_values(slots):
        warnings.append("多 sheet 文档的 sum/compare 必须限定单个 sheet，否则 D4 返回 insufficient")
    if kind == "compare":
        warnings.append("compare 需要至少两个 occurrence；只有一个值时 D4 返回 insufficient")
        if not (slots.get("compare") or slots.get("op")):
            warnings.append("compare 未声明比较方式，按 equal 比较 occurrence 值")
    return {"metric": metric, "unit": unit, "threshold": threshold,
            "source": source, "ready": bool(ready), "reason": reason,
            "warnings": _unique(warnings)}


def _compare_plan(slots: dict, scopes: list, agg: str, relations: list, cross: dict) -> dict:
    enabled = bool(agg == "compare" or cross.get("mode") == "pair")
    if not enabled:
        return {"enabled": False, "mode": "none", "scope": "", "operators": [], "pairs": [],
                "metric": "", "threshold": None, "supported": True, "executor": "",
                "reason": "", "unsupported": [], "warnings": [], "executors": []}
    mode = "pair" if cross.get("mode") == "pair" else "aggregate"
    operators = _unique([rel.get("compare") for rel in relations if rel.get("compare")])
    raw_op = _norm_compare(slots.get("compare") or slots.get("op") or slots.get("relation_type"))
    if raw_op and raw_op not in operators:
        operators.append(raw_op)
    pairs = list(cross.get("pairs") or [])
    if not pairs:
        pairs = [{"left": rel["left"], "right": rel["right"],
                  "compare": rel.get("compare") or "equal",
                  "across": rel.get("across") or "document"}
                 for rel in relations if rel.get("complete")]
    if mode == "aggregate":
        config = _aggregation_config(slots, scopes, "compare")
        local_warnings = list(config["warnings"])
    else:
        config = {"metric": "", "unit": "", "threshold": None,
                  "source": "", "ready": False, "reason": "", "warnings": []}
        local_warnings = []
    if mode == "aggregate":
        supported = bool(config["ready"])
        reason = "" if supported else config["reason"]
        executor = ("manifest_exec.ruleexec.aggregation_compare" if supported
                    else "unsupported.compare_config")
        executors = [_exec("aggregation.compare", "D4", "compare", supported,
                           reason, "occurrences", local_warnings)] if supported or reason else []
    else:
        supported = False
        reason = ("跨文件成对比较没有一级 manifest 执行器；D3 只核验跨文件证据，"
                  "D4 仍逐文件判断")
        executor = "unsupported.cross_document_pair"
        if not pairs:
            local_warnings.append("未提供跨文件成对比较的对象/关系，pair 模式无法形成比较对")
        if not operators:
            local_warnings.append("未声明比较方式 compare/op，无法确定比较语义")
        if agg == "compare":
            local_warnings.append("同时声明 aggregation=compare；它只能比较单个对象内的 "
                                  "occurrence，不能替代跨文件成对比较")
        executors = []
    return {"enabled": True, "mode": mode,
            "scope": "occurrences" if mode == "aggregate" else "objects",
            "operators": operators, "pairs": pairs,
            "metric": config["metric"], "threshold": config["threshold"],
            "supported": supported, "executor": executor, "reason": reason,
            "unsupported": [reason] if reason else [],
            "warnings": _unique(local_warnings), "executors": executors}


def _sum_plan(slots: dict, scopes: list, agg: str) -> dict:
    enabled = agg == "sum"
    if not enabled:
        return {"enabled": False, "mode": "none", "metric": "", "unit": "",
                "threshold": None, "over": "", "supported": True, "executor": "",
                "reason": "", "unsupported": [], "warnings": [], "executors": []}
    config = _aggregation_config(slots, scopes, "sum")
    supported = bool(config["ready"])
    reason = "" if supported else config["reason"]
    local_warnings = list(config["warnings"])
    return {"enabled": True, "mode": "aggregate", "metric": config["metric"],
            "unit": config["unit"], "threshold": config["threshold"],
            "over": "subrequirements" if config["source"] == "subrequirements"
                    else "metric_occurrences",
            "supported": supported,
            "executor": ("manifest_exec.ruleexec.aggregation_sum" if supported
                         else "unsupported.sum_config"),
            "reason": reason, "unsupported": [reason] if reason else [],
            "warnings": _unique(local_warnings),
            "executors": [_exec("aggregation.sum", "D4", "sum", supported,
                                reason, "occurrences", local_warnings)]}


def _ask_plan(slots: dict, fallback: str) -> dict:
    disabled = {"enabled": False, "executor": "", "supported": True,
                "materials": [], "checklist": [], "manifest_checklist": [],
                "required": [], "validator": "execution_plan.validate_ask_checklist",
                "persistence": {"executor": "", "fields": [],
                                "format_in_label": False},
                "validation": {"ok": True, "errors": [], "warnings": [], "checked": 0},
                "unsupported": [], "warnings": [], "executors": []}
    if fallback != "ask":
        return disabled

    local_warnings = []
    materials = _build_materials(slots, local_warnings)
    if not materials:
        materials = [{
            "label": "补充判据所需证据", "reason": "证据不足，需补充材料后重判",
            "required": True, "format": "any", "format_label": _format_label("any"),
            "extensions": [], "min_count": 1, "source": "default", "format_note": "",
        }]
        local_warnings.append("未声明 required_evidence，补证清单只有通用材料项")
    checklist = _ask_checklist(materials)
    manifest_checklist = _manifest_checklist(materials)
    validation = validate_ask_checklist(checklist, materials)
    if not validation["ok"]:
        local_warnings.append("补证清单未通过必填/格式校验")
    local_warnings.append("补证清单的 format/required 由 validate_ask_checklist 校验；"
                          "manifest_evidence 目前只持久化 label/reason"
                          "（manifest_checklist 已将格式/必填写入 label）")
    required = [item["label"] for item in materials if item["required"]]
    supported = bool(validation["ok"])
    unsupported = [] if supported else ["补证材料清单未通过必填/格式校验"]
    return {"enabled": True, "executor": "manifest.request_evidence",
            "supported": supported, "materials": materials,
            "checklist": checklist, "manifest_checklist": manifest_checklist,
            "required": required, "validator": "execution_plan.validate_ask_checklist",
            "persistence": {"executor": "manifest.request_evidence",
                            "fields": ["label", "reason"],
                            "format_in_label": True},
            "validation": {"ok": bool(validation["ok"]),
                           "errors": validation["errors"],
                           "warnings": validation["warnings"],
                           "checked": len(checklist)},
            "unsupported": unsupported, "warnings": _unique(local_warnings),
            "executors": [_exec("ask.materials", "D5", "ask_checklist", supported,
                                "" if supported else unsupported[0], "checklist",
                                local_warnings)]}


# ---------------------------------------------------------------- 主计划

def derive(slots: dict) -> dict:
    slots = dict(slots or {})
    scopes = _list(slots.get("evidence_scope") or slots.get("evidence_scopes") or ["document"])
    scopes = [x for x in scopes if x in SCOPES] or ["document"]
    agg = str(slots.get("aggregation") or slots.get("batch_scope") or "all")
    if agg not in AGGREGATIONS:
        agg = "all"
    method = str(slots.get("evaluation_kind") or "")
    if method not in METHODS:
        method = ("deterministic" if slots.get("metric")
                  and slots.get("value", slots.get("threshold")) not in (None, "")
                  else "semantic")
    fallback = str(slots.get("fallback") or slots.get("on_insufficient") or "abstain")
    if fallback not in FALLBACKS:
        fallback = {"abstain": "abstain", "ask": "ask", "fail": "fail"}.get(fallback, "abstain")

    relations = _relations(slots)
    cross_spec = slots.get("cross_document") if isinstance(slots.get("cross_document"), dict) else {}
    objects = _objects(slots, cross_spec)
    warnings = []
    cross = _cross_document_plan(slots, scopes, agg, relations, objects, warnings)
    compare = _compare_plan(slots, scopes, agg, relations, cross)
    sum_plan = _sum_plan(slots, scopes, agg)

    executors = [
        _exec("D3.evidence_bind", "D3", "evidence_scope", True,
              "", "/".join(scopes)),
        _exec("D4.judge", "D4", "evaluation_kind", True, "", method),
        _exec("D5.combine", "D5", "combination", True, "",
              str(slots.get("combination") or slots.get("combine") or "all")),
    ]
    executors.extend(cross.get("executors") or [])
    executors.extend(compare.get("executors") or [])
    executors.extend(sum_plan.get("executors") or [])

    ask = _ask_plan(slots, fallback)
    executors.extend(ask.get("executors") or [])

    if fallback == "single_block_first":
        reason = ("single_block_first 没有独立执行器，D5 按无法判断处理；"
                  "请改用 abstain/ask/fail")
        executors.append(_exec("fallback.single_block_first", "D5", "fallback",
                               False, reason, fallback))

    sheet_limits = _sheet_limit_values(slots)
    if len(sheet_limits) > 1:
        reason = "一次只支持限定一个 sheet（多 sheet 同时限定尚未实现）"
        executors.append(_exec("D3.sheet_limit", "D3", "sheet_limit", False,
                               reason, "、".join(sheet_limits)))
    elif "sheet" in scopes and method == "semantic":
        if len(sheet_limits) == 1:
            warnings.append(f"sheet 语义判断只消费指定 sheet（{sheet_limits[0]}）的文本")
        else:
            reason = "跨 Sheet 语义汇总为部分支持；未限定 sheet 时 D4 使用整份文档文本"
            executors.append(_exec("D4.sheet_semantic", "D4", "evidence_scope_semantic",
                                   False, reason, "semantic"))

    if agg == "any":
        combination = str(slots.get("combination") or slots.get("combine") or "all").lower()
        if combination != "any":
            warnings.append("aggregation=any 需配合 combination=any；"
                            "当前 D5 仍按 AND 组合")

    if scopes == ["document"] and agg != "single" and slots.get("subrequirements"):
        warnings.append("存在多个子要求时，document 范围不一定能定位每个子项证据")

    unsupported = _unique([e["reason"] for e in executors if not e["supported"]])
    all_warnings = list(unsupported)
    all_warnings.extend(warnings)
    for block in (cross, compare, sum_plan, ask):
        all_warnings.extend(block.get("warnings") or [])
    all_warnings = _unique(all_warnings)
    unsupported_executors = [{"id": e["id"], "step": e["step"],
                              "capability": e["capability"], "mode": e["mode"],
                              "reason": e["reason"]}
                             for e in executors if not e["supported"]]

    steps = [
        {"id": "D1", "name": "适用性", "depends_on": [],
         "input": ["doc_type", "scope", "trigger"], "method": "scope_match"},
        {"id": "D2", "name": "业务要求", "depends_on": ["D1"],
         "input": ["rule_version", "requirement"], "method": "rule_lookup"},
        {"id": "D3", "name": "证据绑定", "depends_on": ["D1"],
         "input": ["required_evidence", "evidence_scope", "cross_document"],
         "method": "evidence_bind"},
        {"id": "D4", "name": "子要求判断", "depends_on": ["D2", "D3"],
         "input": ["criteria", "evidence", "aggregation"], "method": method},
        {"id": "D5", "name": "组合结论", "depends_on": ["D4"],
         "input": ["combination", "D4", "fallback", "aggregation"], "method": "combine"},
    ]
    return {
        "version": "execution-plan-v2",
        "evidence_scope": scopes, "aggregation": agg, "evaluation_kind": method,
        "fallback": fallback, "steps": steps, "executors": executors,
        "cross_document": cross, "compare": compare, "sum": sum_plan, "ask": ask,
        "unsupported": unsupported, "unsupported_executors": unsupported_executors,
        "warnings": all_warnings, "supported": not unsupported,
        "label": f"证据范围 {'/'.join(scopes)} · 汇总 {agg} · 方法 {method} · 不足 {fallback}",
    }
