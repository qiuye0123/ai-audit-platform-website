"""Agent Runtime 基础模块：运行快照、提示词、节点模型、节点轨迹。

从 agents.py 抽出的纯运行时逻辑，避免管理 CRUD、业务执行器和运行时状态混在一起。
"""
from __future__ import annotations

import json
import logging

from .. import db
from .. import repositories as R


def prompt_list(value):
    """兼容 list[{node,prompt/content}] / JSON 字符串。"""
    if isinstance(value, list):
        raw = value
    else:
        try:
            raw = json.loads(value or "[]")
        except Exception:
            return []
    if not isinstance(raw, list):
        return []
    out = []
    for x in raw:
        if isinstance(x, str):
            out.append({"node": "默认", "prompt": x})
        elif isinstance(x, dict):
            p = x.get("prompt") or x.get("content") or ""
            if p:
                out.append({"node": str(x.get("node") or x.get("label") or "默认"),
                            "prompt": str(p), "model_id": str(x.get("model_id") or "")})
    return out


def runtime_snapshot(profile: dict, version: dict) -> dict:
    """把 profile + 已发布版本合并成一次运行快照。"""
    profile = dict(profile or {})
    version = version or {}
    prompts, node_models = {}, {}
    for x in prompt_list(profile.get("prompts_list")):
        if x.get("node") and x.get("prompt"):
            prompts[str(x["node"])] = str(x["prompt"])
            if x.get("model_id"):
                node_models[str(x["node"])] = str(x["model_id"])
    # 已发布版本优先，确保回滚/发布真实影响执行
    for x in prompt_list(version.get("prompt")):
        if x.get("node") and x.get("prompt"):
            prompts[str(x["node"])] = str(x["prompt"])
            if x.get("model_id"):
                node_models[str(x["node"])] = str(x["model_id"])
    params = {}
    for x in (profile.get("params_list") or []):
        if isinstance(x, dict) and x.get("name") is not None:
            params[str(x["name"])] = x.get("v")
    wf = profile.get("workflow") or []
    try:
        tv = json.loads(version.get("tools_json") or "{}") if version.get("tools_json") else {}
        if isinstance(tv.get("workflow"), list) and tv["workflow"]:
            wf = tv["workflow"]
        if isinstance(tv.get("params"), list) and tv["params"]:
            for x in tv["params"]:
                if isinstance(x, dict) and x.get("name") is not None:
                    params[str(x["name"])] = x.get("v")
    except Exception:
        logging.getLogger(__name__).debug("agent runtime snapshot parse skipped", exc_info=True)
    profile["_runtime"] = {
        "agent_id": profile.get("_agent_id") or profile.get("id", ""), "version": version.get("version", ""),
        "version_id": version.get("id", ""), "prompts": prompts,
        "params": params, "workflow": wf,
        "model": next(iter(node_models.values()), "") or version.get("model", ""),
        "node_models": node_models,
    }
    return profile


def set_node_model(profile: dict, names) -> str:
    """在模型节点执行前绑定该节点的模型；找不到则保持默认。"""
    rt = profile.get("_runtime") or {}
    nm = rt.get("node_models") or {}
    for name in (names if isinstance(names, (list, tuple)) else [names]):
        ref = str(nm.get(name) or "")
        if ref:
            try:
                from ..engine import llm_router as _lr
                _lr.set_agent_model(ref)
                return ref
            except Exception:
                logging.getLogger(__name__).debug("agent node model binding skipped", exc_info=True)
    return ""


def node_prompt(profile: dict, names, default: str = "") -> str:
    rt = profile.get("_runtime") or {}
    prompts = rt.get("prompts") or {}
    for name in (names if isinstance(names, (list, tuple)) else [names]):
        if name in prompts and str(prompts[name]).strip():
            return str(prompts[name])
    return default


def record_node_runs(run_id: str, agent_id: str, trace: list) -> None:
    """落库节点级执行轨迹；没有真实节点轨迹的智能体不伪造节点。"""
    if not trace:
        return
    try:
        with db.session() as c:
            for n in trace:
                c.execute(
                    "INSERT INTO agent_node_run(id,agent_run_id,agent_id,node_id,node_name,node_type,"
                    "status,latency_ms,input_json,output_json,error,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (db.new_id("anr"), run_id, agent_id, str(n.get("id") or ""),
                     str(n.get("name") or ""), str(n.get("type") or ""), str(n.get("status") or "ok"),
                     int(n.get("latency_ms") or 0),
                     json.dumps(n.get("input") or {}, ensure_ascii=False),
                     json.dumps(n.get("output") or {}, ensure_ascii=False),
                     str(n.get("error") or ""), db.now()))
    except Exception:
        logging.getLogger(__name__).debug("agent node trace insert skipped", exc_info=True)
