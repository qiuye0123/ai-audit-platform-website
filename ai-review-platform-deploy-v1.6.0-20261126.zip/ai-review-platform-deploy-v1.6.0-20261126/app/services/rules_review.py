"""规则体检：审核前检查规则冲突/不清晰/重复；不通过则阻止审核。
确定性检查（快、稳），模型检查留扩展点。"""
import hashlib, json, re
from .. import db, repositories as R

VAGUE = ("适当", "合理", "尽量", "必要时", "酌情", "原则上", "适当时候", "足够", "良好")


def _rules(ws_id: str):
    return R.rules.list("status=?", ("published",))


def _waivers(ws_id: str) -> dict:
    try:
        from . import workspaces as _w
        st = _w.get_settings(ws_id) or {}
        return {str(x.get("rule_id")): x for x in (st.get("rules_review_waivers") or []) if isinstance(x, dict)}
    except Exception:
        return {}


def waive(ws_id: str, rule_id: str, reason: str, actor: str = "",
          tenant_id: str = "", workspace_id: str = "") -> dict:
    """规则体检豁免（X-11 P0-1）：业务管理员权限 + 同事务写审计。

    旧实现只按 ``audit.review`` 校验（审核员也有），且不写审计 → 审核员可自助
    豁免主链门禁且无痕迹。现在：
      * 权限由 HTTP/CLI 层校验 ``ws.manage``（业务管理员），服务层再校验入参；
      * 豁免记录带 ``waived_by``/``tenant_id``/``workspace_id``，供 check() 返回
        ``applied_waivers`` 与审计页展示；
      * 业务写（workspace.settings_json）与审计 ``rules_review.waived`` **同事务**，
        审计失败 → 业务回滚（铁律 4）。
    """
    ws_id = str(ws_id or "").strip()
    rid = str(rule_id or "").strip()
    if not ws_id:
        return {"ok": False, "error": "workspace_required",
                "message": "缺少工作空间，无法豁免"}
    if not rid:
        return {"ok": False, "error": "rule_id_required",
                "message": "缺少规则 ID，无法豁免"}
    rule = R.rules.get(rid)
    if not rule:
        return {"ok": False, "error": "rule_not_found",
                "message": f"规则不存在：{rid}"}
    why = str(reason or "").strip()[:200]
    if not why:
        return {"ok": False, "error": "reason_required",
                "message": "豁免必须填写原因（写入审计，用于事后对账）"}
    from . import audit as _audit
    with db.session() as c:
        wrow = c.execute("SELECT tenant_id FROM workspace WHERE id=?", (ws_id,)).fetchone()
        if not wrow:
            return {"ok": False, "error": "workspace_not_found",
                    "message": f"工作空间不存在：{ws_id}"}
        row = c.execute("SELECT settings_json FROM workspace WHERE id=?", (ws_id,)).fetchone()
        try:
            st = json.loads((row[0] if row else "") or "{}")
        except Exception:
            st = {}
        if not isinstance(st, dict):
            st = {}
        ws = [x for x in (st.get("rules_review_waivers") or []) if isinstance(x, dict)]
        ws = [x for x in ws if str(x.get("rule_id")) != rid]
        entry = {"rule_id": rid, "code": str(rule.get("code") or ""),
                 "reason": why, "at": db.now(),
                 "waived_by": str(actor or "system"),
                 "tenant_id": str(tenant_id or wrow["tenant_id"] or ""),
                 "workspace_id": str(workspace_id or ws_id)}
        ws.append(entry)
        st["rules_review_waivers"] = ws
        c.execute("UPDATE workspace SET settings_json=? WHERE id=?",
                  (json.dumps(st, ensure_ascii=False), ws_id))
        _audit.log_in_tx(c, actor=entry["waived_by"], action="rules_review.waived",
                         object_=rid, after=json.dumps(entry, ensure_ascii=False))
    return {"ok": True, "waivers": len(ws), "waiver": entry, "audit": True}


EXEC_KEYS = ("metric", "op", "value", "unit", "require", "forbid", "require_any",
             "applicable_when", "pattern", "keywords")


def _executable(slots: dict) -> bool:
    return any(k in slots for k in EXEC_KEYS)


def check(ws_id: str) -> dict:
    _all = _rules(ws_id)
    # 同编码只算一条（历史上重复入库的规则不应重复计阻断）
    _seen = set()
    rules = []
    for r in _all:
        c = r.get("code") or r.get("id")
        if c in _seen:
            continue
        _seen.add(c)
        rules.append(r)
    issues = []
    seen = {}
    for r in rules:
        v = R.rules.latest_version(r["id"]) or {}
        try:
            slots = json.loads(v.get("slots_json") or "{}")
        except Exception:
            slots = {}
        crit = str(slots.get("criterion") or "").strip()
        rid, code = r["id"], r.get("code") or ""
        if not slots:
            # 无结构化判据的规则（历史/内置）由引擎或模型执行，不阻断
            issues.append({"rule_id": rid, "code": code, "type": "unclear",
                           "severity": "warning", "message": "无结构化判据（由引擎/模型执行）"})
            continue
        if not crit:
            if _executable(slots):
                # 结构化可执行（阈值/关键词），无文字判据不阻断
                continue
            issues.append({"rule_id": rid, "code": code, "type": "unclear",
                           "severity": "blocker", "message": "判据为空，无法执行"})
            continue
        if len(crit) < 6:
            issues.append({"rule_id": rid, "code": code, "type": "unclear",
                           "severity": "warning", "message": "判据过短，可能缺少对象或阈值"})
        for w in VAGUE:
            if w in crit:
                issues.append({"rule_id": rid, "code": code, "type": "unclear",
                               "severity": "warning", "message": f"包含模糊词「{w}」，建议量化"})
                break
        # A1：不可判定/IR 问题 → 提示（不阻断）
        try:
            from . import rule_ir as _ir3
            _ex3 = _ir3.classify_executability(slots)
            if _ex3["level"] == "unjudgeable":
                issues.append({"rule_id": rid, "code": code, "type": "executability",
                               "severity": "warning",
                               "message": "规则不可判定，建议补充：" + ("、".join(_ex3["missing_evidence"]) or "明确判据")})
            elif _ex3["level"] == "semantic" and _ex3.get("missing_evidence"):
                issues.append({"rule_id": rid, "code": code, "type": "executability",
                               "severity": "warning",
                               "message": "半可判定，建议补充：" + "、".join(_ex3["missing_evidence"])})
        except Exception:
            pass
        key = re.sub(r"\s+", "", crit)
        if key in seen:
            issues.append({"rule_id": rid, "code": code, "type": "duplicate",
                           "severity": "blocker", "message": f"与规则 {seen[key]} 判据重复"})
        else:
            seen[key] = code
    _wv = _waivers(ws_id)
    # X-11 P0-1：把「本次体检实际用了哪些豁免」显式下发（报告/审计页可展示），
    # 不再只做隐式过滤；applied_waivers 为空表示没有任何阻断被豁免。
    applied = []
    if _wv:
        _kept = []
        for x in issues:
            w = _wv.get(str(x.get("rule_id")))
            if not w:
                _kept.append(x)
                continue
            applied.append({"rule_id": str(x.get("rule_id")),
                            "code": x.get("code") or w.get("code") or "",
                            "type": x.get("type") or "",
                            "severity": x.get("severity") or "",
                            "message": x.get("message") or "",
                            "reason": w.get("reason") or "",
                            "waived_by": w.get("waived_by") or "",
                            "at": w.get("at") or ""})
        issues = _kept
    st = {"checked_at": db.now(), "rules": len(rules),
          "blockers": [x for x in issues if x["severity"] == "blocker"],
          "warnings": [x for x in issues if x["severity"] != "blocker"],
          "applied_waivers": applied,
          "waiver_count": len(_wv),
          "hash": hashlib.sha256(("|".join(sorted(str(r.get("code")) for r in rules))).encode()).hexdigest()[:16]}
    st["status"] = "blocked" if st["blockers"] else "passed"
    return st


def ensure(ws_id: str) -> dict:
    """审核前调用：有 blocker 则抛出（附规则编码），否则放行。"""
    st = check(ws_id)
    if st["blockers"]:
        codes = ", ".join(sorted({b["code"] for b in st["blockers"]})[:6])
        raise ValueError(f"规则体检未通过（{len(st['blockers'])} 项阻断）：{codes}；请先修正规则再审核")
    return st
