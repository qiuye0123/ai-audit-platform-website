"""规则详情读取：从 server.py 抽出，规则库点位只读 + DB 规则版本/发现。"""
import logging
from .. import repositories as R


def get(rule_id: str) -> dict:
    try:
        from . import auditpoints as _ap
        lib = _ap.load()
        pt = next((x for x in lib.points if x.id == rule_id), None)
        if pt:
            return {"rule": {"id": pt.id, "code": pt.id, "name": pt.name, "category": pt.category,
                             "rclass": getattr(pt, "rclass", getattr(pt, "method_name", "")),
                             "status": "published", "source": f"审核库 · {pt.category}", "version": "库"},
                    "condition": f"{pt.trigger}｜判据：{pt.criterion}", "versions": [],
                    "findings": [], "hit_count": R.findings.count("rule_id=?", (pt.id,)),
                    "override_count": R.findings.count("rule_id=? AND status='false_positive'", (pt.id,))}
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    r = R.rules.get(rule_id)
    if not r:
        return {}
    fs = R.findings.list("rule_id=?", (r["code"],))
    findings = []
    for f in fs:
        evs = R.evidences.list("finding_id=?", (f["id"],))
        anchors = []
        for e in evs:
            a = R.anchors.get(e["anchor_id"])
            if a:
                anchors.append(a)
        findings.append({**f, "evidence": anchors})
    versions = R.rule_versions.list("rule_id=?", (rule_id,), order="published_at DESC")
    return {"rule": r, "findings": findings, "versions": versions,
            "hit_count": len(fs), "override_count": sum(1 for f in fs if f["status"] == "false_positive")}
