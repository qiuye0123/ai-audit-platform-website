"""稳定性分析（P0-2）：同一点位在多次运行中出现 pass↔fail 翻转 → 必须转人工。

flip 定义：同一 (case, point) 在不同批次里状态同时出现过 pass 与 fail。
insufficient/unknown 不参与翻转判定（它们不是结论）。
"""
import json

from . import sysconfig


def analyze(batches: list) -> dict:
    """batches: [[{point, state}, ...], ...]（每次运行一组）"""
    seen = {}
    for rows in batches:
        for r in rows or []:
            key = (r.get("case_id") or "", r.get("point_id") or r.get("point"))
            seen.setdefault(key, set()).add(r.get("state"))
    flips = []
    for (case_id, point), states in seen.items():
        if "pass" in states and "fail" in states:
            flips.append({"case_id": case_id, "point": point,
                          "states": sorted(s for s in states if s in ("pass", "fail"))})
    total = len(seen)
    return {"points": total, "flips": flips,
            "flip_rate": round(len(flips) / total, 4) if total else 0.0}


def save(case_id: str, res: dict) -> None:
    sysconfig.set_many({f"flips:{case_id}": json.dumps(res, ensure_ascii=False)})


def load(case_id: str) -> dict:
    raw = sysconfig.get(f"flips:{case_id}", "")
    try:
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def unresolved(case_id: str) -> list:
    res = load(case_id)
    return [f for f in (res.get("flips") or []) if not f.get("handled")]
