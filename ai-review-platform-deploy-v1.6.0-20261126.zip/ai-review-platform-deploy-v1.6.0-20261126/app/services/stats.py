"""统计看板 + 审计回放 + 规则命中趋势：全局 KPI + 单案例审计事件时间线 + 规则时间序列。

另含「旧点位判据（stale）」聚合：项目列表/首页只新增字段，不改变既有 KPI 定义。
隔离规则：
- 租户：只统计当前上下文租户；上下文缺失时回退到用户所属租户，仍取不到则不统计。
- 角色：管理员看本租户全部审核员；审核员只看自己创建的项目。
- 空间：首页/项目列表始终跨空间汇总，空间只作为列表筛选条件。

stale 口径（stale_findings / stale_*_counts 的 scope 参数）：
- current（默认）：当前审核批次（run_id == audit_case.last_run_id）+ 人工发现；
                   首页/项目列表使用，保持既有口径。
- report         ：current + 历史批次中仍未处理（pending）的发现；与
                   review.case_report 的工作台窗口一致，报告侧接线后可直接复用。
- all            ：全部未作废（status != superseded）发现，含历史已复核；
                   供审计/导出等全量统计。
三档都只认「point_library_version 非空且 != 当前点位库版本」；
空版本、版本一致、superseded 一律不计。

报告侧接线状态：review.case_report 目前仍按自身 fs 窗口自行计算 point_stale_count
（含历史 pending），尚未调用本模块；接线前报告与首页 current 口径可能不一致。
建议报告侧改为：
    "point_stale_count": stats.stale_count(case_id, scope="report")
"""
import logging
import time

from .. import db
from .. import repositories as R


def dashboard() -> dict:
    """全局 KPI：规则/案例/发现/冲突/复核/override。

    T-107 P0-03：规则/冲突计数不再本地拼装（旧实现 ``16 内置 + 16 DB`` 同码重复
    计成 32），统一消费 ``rule_library.rule_counts(scope="tenant")``：
    - ``rules`` = 可执行规则版本数（current_version_id 且 published）；
    - ``rule_counts`` = 客户规则/内置规则/审核库点位/可执行版本/决策表分层计数；
    - ``rule_hits`` = 命中归因（total/attributed/unattributed），不把 0 当无命中；
    - ``conflicts`` 与冲突页同口径（同租户同空间可见范围）。
    """
    from . import rule_library as _rl
    rc = _rl.rule_counts(scope="tenant")
    hits = rc.get("hits") or {}
    n_cases = R.cases.count()
    n_findings = R.findings.count()
    n_conflicts = int((rc.get("conflicts") or {}).get("total") or 0)
    decisions = R.decisions.list()
    n_decided = len(decisions)
    n_fp = sum(1 for d in decisions if d["decision"] == "false_positive")
    crit = R.findings.count("severity=?", ("critical",))
    warn = R.findings.count("severity=?", ("warning",))
    return {
        "rules": rc.get("executable_versions", 0),
        "rules_total": rc.get("rule_rows", 0),
        "rule_counts": rc,
        "rule_hits": {
            "total": hits.get("total", 0),
            "attributed": hits.get("attributed", 0),
            "unattributed": hits.get("unattributed", 0),
            "attributed_rate": (round(hits.get("attributed", 0) / hits["total"], 3)
                                if hits.get("total") else 0.0),
            "unattributed_by_code": hits.get("unattributed_by_code") or {},
        },
        "cases": n_cases, "findings": n_findings,
        "conflicts": n_conflicts, "decided": n_decided,
        "false_positive": n_fp,
        "override_rate": round(n_fp / n_decided, 3) if n_decided else 0.0,
        "critical": crit, "warning": warn,
    }


def case_trail(case_id: str) -> list:
    """单案例审计事件时间线（复核 + 完成 + 规则发布），按时间排序。"""
    fids = [f["id"] for f in R.findings.by_case(case_id)]
    logs = []
    for o in [case_id] + fids:
        logs += R.audit_logs.list("object=?", (o,))
    logs.sort(key=lambda x: x["created_at"] or "")
    return logs


def audit_summary(case_id: str) -> dict:
    """回放该案例：从日志重建事件序列 + 当前复核状态。"""
    trail = case_trail(case_id)
    events = [{"time": t["created_at"], "actor": t["actor"], "action": t["action"],
               "object": t["object"], "detail": t["after_json"]} for t in trail]
    decided = [f for f in R.findings.by_case(case_id) if f["status"] != "pending"]
    return {"case_id": case_id, "events": events,
            "decided_count": len(decided),
            "replay_note": "审计日志可重建“谁在何时做了什么”，与重新执行引擎结果可对照，但不重跑引擎。"}


def snapshot_rules(case_id: str) -> int:
    """每次审核完成后，快照本案例每规则命中/误报，供趋势看板。"""
    n = 0
    for code in {f["rule_id"] for f in R.findings.by_case(case_id)}:
        fs = R.findings.list("rule_id=? AND case_id=?", (code, case_id))
        fp = sum(1 for f in fs if f["status"] == "false_positive")
        R.rule_snapshots.insert(id=db.new_id("rs"), case_id=case_id, rule_code=code,
                                hit=len(fs), override=fp, created_at=db.now())
        n += 1
    return n


def trend(rule_code: str) -> list:
    """某规则的时间序列（命中/误报随审核演进）。"""
    rows = R.rule_snapshots.list("rule_code=?", (rule_code,), order="created_at ASC")
    return [{"case_id": r["case_id"], "hit": r["hit"], "override": r["override"],
             "created_at": r["created_at"]} for r in rows]


# ---------------------------------------------------------------------------
# 旧点位判据（stale）聚合：项目列表 / 首页 / 报告统一口径
# ---------------------------------------------------------------------------
# 统一窗口与版本判定见模块头部说明；stale_findings 是单案例唯一口径入口，
# 批量聚合 _stale_by_case 与它共用 _case_window/_is_stale，避免首页与报告漂移。
# 其它消费方：point_confirm.stale_for_case（HTTP /point-stale、CLI）仍是独立实现，
# 未调用本函数（且未排除 superseded）；统一需其 owner 后续接线。

STALE_SCOPES = ("current", "report", "all")
STALE_SCOPE_DEFAULT = "current"


def _stale_scope(scope: str = STALE_SCOPE_DEFAULT) -> str:
    """校验并归一化 stale 口径；未知口径直接报错，不静默退化成 current。"""
    value = str(scope or "").strip().lower()
    if value not in STALE_SCOPES:
        raise ValueError("未知 stale 口径：%r（可选：%s）"
                         % (scope, ", ".join(STALE_SCOPES)))
    return value


def _finding_in_window(finding: dict, run_id: str, scope: str) -> bool:
    """发现是否落在指定口径的可见窗口内（不含版本判定）。"""
    status = str(finding.get("status") or "")
    if status == "superseded":
        return False
    if scope == "all" or not run_id:
        return True
    if str(finding.get("run_id") or "") == run_id or str(finding.get("engine") or "") == "manual":
        return True
    # report 口径：历史批次里仍未处理的发现不能从报告工作台消失
    # （review.case_report 同口径）
    return scope == "report" and (status or "pending") == "pending"


def _case_window(case: dict, findings: list, scope: str) -> list:
    """按口径截取单案例发现窗口；report 保持「当前批次在前、历史 pending 追加在后」。"""
    run_id = str((case or {}).get("last_run_id") or "")
    if scope == "all" or not run_id:
        return [f for f in findings if _finding_in_window(f, run_id, scope)]
    current = [f for f in findings if _finding_in_window(f, run_id, "current")]
    if scope == "current":
        return current
    seen = {str(f.get("id") or "") for f in current}
    historical = [f for f in findings
                  if str(f.get("id") or "") not in seen
                  and _finding_in_window(f, run_id, "report")]
    return current + historical


def _is_stale(finding: dict, library_version: str) -> bool:
    """旧点位判据：有版本、当前库版本可用且两者不同。"""
    point_version = str((finding or {}).get("point_library_version") or "")
    return bool(point_version and library_version and point_version != library_version)


def stale_findings(case_id: str, scope: str = STALE_SCOPE_DEFAULT) -> list:
    """单案例旧点位判据发现（统一口径，供首页/列表/报告共用）。

    scope=current（默认）：当前批次（last_run_id）+ 人工发现（engine=manual）；
    scope=report        ：再并入历史批次 pending（与 review.case_report 的 fs 窗口一致）；
    scope=all           ：全部未作废发现（含历史已复核）。
    返回的 finding 带 point_stale=True / point_stale_reason，计数语义为 len(...)。
    当前点位库版本取不到、案例不存在或跨租户不可见时返回 []（fail-closed）。
    """
    scope = _stale_scope(scope)
    case = R.cases.get(case_id) or {}
    if not case:
        return []
    library_version = _library_version()
    if not library_version:
        return []
    out = []
    for finding in _case_window(case, R.findings.by_case(case_id), scope):
        if _is_stale(finding, library_version):
            finding["point_stale"] = True
            finding["point_stale_reason"] = "点位库/判据已更新，该结果基于旧版本"
            out.append(finding)
    return out


def stale_count(case_id: str, scope: str = STALE_SCOPE_DEFAULT) -> int:
    """统一口径的 stale 发现数；报告侧接线后可直接替换 point_stale_count。"""
    return len(stale_findings(case_id, scope))


def _library_version() -> str:
    """当前点位库版本；判定口径与 review.case_report / point_confirm 一致。"""
    try:
        from . import point_confirm
        return str(point_confirm.library_version() or "")
    except Exception:
        logging.getLogger(__name__).debug("stale library version unavailable", exc_info=True)
        return ""


def _tenant_id(user: str = "", tenant_id: str = "") -> str:
    """租户优先级：显式参数 > 请求上下文 > 用户所属租户；都取不到则返回空（不跨租户）。"""
    if tenant_id:
        return str(tenant_id)
    try:
        from . import ctx
        cur = ctx.get_context() or {}
        if cur.get("tenant_id"):
            return str(cur["tenant_id"])
    except Exception:
        logging.getLogger(__name__).debug("stale context unavailable", exc_info=True)
    if user:
        try:
            with db.session() as conn:
                row = conn.execute("SELECT tenant_id FROM user WHERE id=?", (user,)).fetchone()
            if row and row["tenant_id"]:
                return str(row["tenant_id"])
        except Exception:
            logging.getLogger(__name__).debug("stale user tenant lookup failed", exc_info=True)
    return ""


def _visible_cases(tenant_id: str, user: str = "", is_admin: bool = False) -> list:
    """本租户可见项目：管理员=全租户；审核员=自己创建；跨空间汇总。"""
    if not tenant_id:
        return []
    sql = "SELECT id, created_by, last_run_id FROM audit_case WHERE COALESCE(tenant_id,'')=?"
    params = [tenant_id]
    if not is_admin:
        if not user:
            return []
        sql += " AND COALESCE(created_by,'')=?"
        params.append(user)
    try:
        with db.session() as conn:
            rows = conn.execute(sql + " ORDER BY created_at DESC", tuple(params)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        logging.getLogger(__name__).debug("stale visible cases query failed", exc_info=True)
        return []


def _stale_by_case(cases: list, library_version: str,
                   scope: str = STALE_SCOPE_DEFAULT) -> dict:
    """按项目批量统计口径内旧版本发现数；窗口/版本判定与 stale_findings 共用。"""
    scope = _stale_scope(scope)
    if not cases or not library_version:
        return {}
    run_of = {str(c.get("id")): str(c.get("last_run_id") or "") for c in cases}
    ids = [str(c.get("id")) for c in cases if c.get("id")]
    out = {}
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        ph = ",".join("?" * len(chunk))
        try:
            with db.session() as conn:
                rows = conn.execute(
                    "SELECT case_id, run_id, engine, status, point_library_version FROM finding "
                    f"WHERE case_id IN ({ph}) AND COALESCE(point_library_version,'')<>'' "
                    "AND COALESCE(status,'')<>'superseded'",
                    tuple(chunk)).fetchall()
        except Exception:
            logging.getLogger(__name__).debug("stale findings query failed", exc_info=True)
            continue
        for row in rows:
            cid = str(row["case_id"] or "")
            finding = dict(row)
            if not _finding_in_window(finding, run_of.get(cid, ""), scope):
                continue
            if _is_stale(finding, library_version):
                out[cid] = out.get(cid, 0) + 1
    return out


# 接线契约（home.py / project.py 由各自 owner 补；stats.py 不隐式改其它模块）：
#   首页：payload = stats.decorate_home(payload, user)          # scope 默认 current
#         或 payload.update(stats.stale_home_counts(sub, role == "admin", scope=...))
#   列表：payload = stats.decorate_project_list(payload, user, is_admin, scope=...)
#         或 _s = stats.stale_project_counts(user, is_admin, scope=...)，再按 items[*].id 取 _s["by_case"]
#   报告：stale_count(case_id, scope="report")（尚未接线，见模块头部说明）
# 期望字段：首页/列表顶层 stale_count（发现数）、stale_project_count（项目数）、
#           stale_library_version；项目列表 items[*] 另加 stale_count。
STALE_HOME_FIELDS = ("stale_count", "stale_project_count", "stale_library_version")
STALE_PROJECT_LIST_FIELDS = STALE_HOME_FIELDS


def stale_project_counts(user: str = "", is_admin: bool = False, tenant_id: str = "",
                         scope: str = STALE_SCOPE_DEFAULT) -> dict:
    """当前租户/角色可见的 stale 聚合（含逐项目计数），供项目列表使用。

    返回：{"by_case": {case_id: finding_count}, "stale_count": 发现数,
           "stale_project_count": 项目数, "stale_library_version": 当前库版本}
    scope 可选 current/report/all（见模块头部口径说明），默认 current。
    隔离：租户=当前上下文（缺失时回退用户所属租户，仍取不到则为空）；
          管理员=本租户全部；审核员=自己创建；跨空间汇总。
    """
    scope = _stale_scope(scope)
    tenant = _tenant_id(user, tenant_id)
    if not tenant:
        return {"by_case": {}, "stale_count": 0, "stale_project_count": 0,
                "stale_library_version": ""}
    current = _library_version()
    cases = _visible_cases(tenant, user, is_admin)
    by_case = _stale_by_case(cases, current, scope)
    return {"by_case": by_case, "stale_count": sum(by_case.values()),
            "stale_project_count": len(by_case), "stale_library_version": current}


def stale_home_counts(user: str = "", is_admin: bool = False, tenant_id: str = "",
                      scope: str = STALE_SCOPE_DEFAULT) -> dict:
    """首页只需计数的 stale 聚合，字段可直接合并进 home 响应；scope 默认 current。"""
    snap = stale_project_counts(user, is_admin, tenant_id, scope)
    return {k: snap[k] for k in STALE_HOME_FIELDS}


def decorate_home(payload: dict, user: dict = None,
                  scope: str = STALE_SCOPE_DEFAULT) -> dict:
    """首页响应追加 stale 字段；不修改既有 stats/KPI 定义，scope 默认 current。"""
    if not isinstance(payload, dict):
        return payload
    scope = _stale_scope(scope)
    role = str(payload.get("role") or "")
    if role == "super_admin":
        return payload
    sub = str((user or {}).get("sub") or "")
    payload.update(stale_home_counts(sub, role == "admin", scope=scope))
    return payload


def decorate_project_list(payload: dict, user: str = "", is_admin: bool = False,
                          scope: str = STALE_SCOPE_DEFAULT) -> dict:
    """项目列表响应追加 stale 字段：每个项目 stale_count + 列表级汇总。

    列表级 stale_count/stale_project_count 按当前租户/角色全量统计，
    不随关键词/状态/空间筛选或分页变化；逐项目字段只标注本页项目。
    scope 默认 current，可显式传 report/all 与统一口径对齐。
    """
    if not isinstance(payload, dict):
        return payload
    scope = _stale_scope(scope)
    snap = stale_project_counts(str(user or ""), bool(is_admin), scope=scope)
    by_case = snap["by_case"]
    for item in (payload.get("items") or []):
        if isinstance(item, dict):
            item["stale_count"] = by_case.get(str(item.get("id") or ""), 0)
    payload.update({k: snap[k] for k in STALE_PROJECT_LIST_FIELDS})
    return payload
