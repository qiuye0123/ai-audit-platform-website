"""统一 typed ID resolver：所有业务对象通过同一入口解析与鉴权。

目标不是替换所有路由，而是先固定：
  kind + id -> object | 403 | 404
禁止各路由自己决定“查不到”和“无权限”的边界。
"""
from __future__ import annotations

from .. import repositories as R
from . import ctx as _ctx


class IDLookupError(Exception):
    def __init__(self, status: int, message: str, code: str):
        super().__init__(message)
        self.status = status
        self.message = message
        self.code = code


KINDS = {"rule", "case", "project", "document", "doc", "finding", "point", "task", "report"}


def _ctx_ids() -> tuple[str, str]:
    try:
        c = _ctx.get_context() or {}
        return c.get("tenant_id") or "", c.get("workspace_id") or ""
    except Exception:
        return "", ""


def _same_scope(row: dict, tenant: str, workspace: str) -> bool:
    if tenant and row.get("tenant_id") and row["tenant_id"] != tenant:
        return False
    if workspace and row.get("workspace_id") and row["workspace_id"] != workspace:
        return False
    return True


def _case_allowed(case: dict, user: dict) -> bool:
    if not case:
        return False
    role = str((user or {}).get("role") or "")
    if role in ("super_admin", "platform_op"):
        return True
    tenant, workspace = _ctx_ids()
    ct = case.get("tenant_id") or ""
    cw = case.get("workspace_id") or ""
    if tenant and ct and ct != tenant:
        return False
    if workspace and cw and cw != workspace:
        return False
    if role == "reviewer":
        return (case.get("created_by") or "") in ((user or {}).get("sub") or "", (user or {}).get("id") or "")
    return role in ("admin", "reviewer", "")


def _document_cases(doc_id: str) -> list:
    from .. import db
    c = db.connect()
    try:
        rows = c.execute("SELECT case_id FROM case_document WHERE document_id=?", (doc_id,)).fetchall()
        return [r["case_id"] for r in rows]
    finally:
        c.close()


def _raw_case(case_id: str) -> dict | None:
    """按主键读取 case，不带当前上下文过滤。

    report 表没有 tenant_id/workspace_id 隔离列，只能通过所属 case 判权。
    R.cases.get() 会按上下文追加 tenant 条件，跨租户时返回 None，若直接把 None
    当作“case 不存在/无需校验”就会放行整条 report（历史泄漏点）。这里先取原始行，
    再显式区分“不存在/跨租户 → 404”和“同租户无权 → 403”。
    """
    cid = str(case_id or "").strip()
    if not cid:
        return None
    from .. import db
    c = db.connect()
    try:
        r = c.execute("SELECT * FROM audit_case WHERE id=?", (cid,)).fetchone()
        return dict(r) if r else None
    finally:
        c.close()


def _raw_user_tenant(uid: str) -> str:
    """按账号 ID 取所属租户（不带上下文过滤），用于 task 的跨租户判定。"""
    uid = str(uid or "").strip()
    if not uid:
        return ""
    from .. import db
    c = db.connect()
    try:
        r = c.execute("SELECT tenant_id FROM user WHERE id=?", (uid,)).fetchone()
        return str((r["tenant_id"] if r else "") or "")
    finally:
        c.close()


def resolve(kind: str, obj_id: str, user: dict | None = None) -> dict:
    kind = (kind or "").strip().lower()
    obj_id = (obj_id or "").strip()
    if kind not in KINDS:
        raise IDLookupError(404, "未知 ID 类型", "unknown_kind")
    if not obj_id:
        raise IDLookupError(404, "ID 不能为空", "not_found")
    if kind == "rule":
        row = R.rules.get(obj_id)
        if not row:
            raise IDLookupError(404, "规则不存在", "not_found")
        tenant, workspace = _ctx_ids()
        if not _same_scope(row, tenant, workspace):
            raise IDLookupError(404, "规则不存在", "not_found")
        return row
    if kind == "report":
        row = R.reports.get(obj_id)
        if not row:
            raise IDLookupError(404, "报告不存在", "not_found")
        # 报告自身没有隔离列：必须按所属 case 判权，且与 case resolver 状态码一致。
        # case 已删除/跨租户 → 404（对所有角色一致，不能因 platform 身份放行）；
        # 同租户他人/跨空间 → 403。
        case = _raw_case(row.get("case_id") or "")
        if not case:
            raise IDLookupError(404, "报告不存在", "not_found")
        tenant, _workspace = _ctx_ids()
        case_tenant = str(case.get("tenant_id") or "")
        if tenant and case_tenant and case_tenant != tenant:
            raise IDLookupError(404, "报告不存在", "not_found")
        if not _case_allowed(case, user or {}):
            raise IDLookupError(403, "无权访问该报告", "forbidden")
        return row
    if kind in ("case", "project"):
        row = R.cases.get(obj_id)
        if not row:
            raise IDLookupError(404, "项目不存在", "not_found")
        if not _case_allowed(row, user or {}):
            raise IDLookupError(403, "无权访问该项目", "forbidden")
        return row
    if kind in ("document", "doc"):
        row = R.documents.get(obj_id)
        if not row:
            raise IDLookupError(404, "文件不存在", "not_found")
        cases = [R.cases.get(x) for x in _document_cases(obj_id)]
        cases = [x for x in cases if x]
        if cases and not any(_case_allowed(x, user or {}) for x in cases):
            raise IDLookupError(403, "无权访问该文件", "forbidden")
        return row
    if kind == "finding":
        row = R.findings.get(obj_id)
        if not row:
            raise IDLookupError(404, "发现不存在", "not_found")
        case = R.cases.get(row.get("case_id") or "")
        if case and not _case_allowed(case, user or {}):
            raise IDLookupError(403, "无权访问该发现", "forbidden")
        return row
    if kind == "point":
        from . import auditpoints
        lib = auditpoints.load()
        row = next((p.to_dict() for p in lib.points if p.id == obj_id), None)
        if not row:
            raise IDLookupError(404, "审核点位不存在", "not_found")
        return row
    if kind == "task":
        from . import task
        row = task.get(obj_id)
        if row.get("error"):
            raise IDLookupError(404, "任务不存在", "not_found")
        role = str((user or {}).get("role") or "")
        owner = str(row.get("owner") or "")
        tenant, _workspace = _ctx_ids()
        # 跨租户一律 404：必须在 owner 403 / platform 放行之前判定，否则会暴露任务存在。
        if owner and tenant and _raw_user_tenant(owner) not in ("", tenant):
            raise IDLookupError(404, "任务不存在", "not_found")
        if role not in ("super_admin", "platform_op") and owner \
                and owner != (user or {}).get("sub"):
            raise IDLookupError(403, "无权访问该任务", "forbidden")
        return row
    raise IDLookupError(404, "对象不存在", "not_found")
