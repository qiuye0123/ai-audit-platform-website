"""报告服务：把审核 Case 渲染成正式报告（DOCX / HTML / PDF）。

职责分离：报告导出只允许项目所属审核员本人；业务管理员只读、系统管理员/
平台账号不得导出。严格入口为 :func:`export_report` / :func:`generate`，
渲染函数在传入 actor/role 时也会做同一套校验。
"""
import io
import json
import logging
import os
import re
import subprocess
import tempfile
import time
from copy import deepcopy

from docx import Document
from docx.shared import Pt, RGBColor

from .. import db
from .. import repositories as R
from . import audit as _audit_svc
from . import review
# M1（T-82）：报告渲染/分类的状态归一与台账/门禁同源（na 家族不折 unknown）
from . import audit_ledger as _audit_ledger


class ReportPermissionError(PermissionError, ValueError):
    """报告导出越权；同时是 ValueError，兼容既有路由的 409 映射。"""

    def __init__(self, message: str, code: str = "forbidden", status: int = 403):
        super().__init__(message)
        self.code = code
        self.status = status


class ReportGateError(ValueError):
    """报告门禁未通过。"""

    def __init__(self, message: str, reasons: list | None = None):
        super().__init__(message)
        self.code = "report_blocked"
        self.status = 409
        self.reasons = list(reasons or [])


def _strict_export_access(case_id: str, actor: str = "", role: str = ""):
    """传入身份即严格校验；未传身份的旧内部调用保持原行为（由上层鉴权）。"""
    if not (str(actor or "").strip() or str(role or "").strip()):
        return None
    access = review.authorize_case(case_id, "export", actor, role)
    if not access.get("ok"):
        raise ReportPermissionError(access.get("message") or "无权限导出报告",
                                    access.get("code") or "forbidden",
                                    int(access.get("status") or 403))
    return access


def _strict_view_access(case_id: str, actor: str = "", role: str = ""):
    if not (str(actor or "").strip() or str(role or "").strip()):
        return None
    return review.authorize_case(case_id, "view", actor, role)


def _l87_assert_audit_state(case_id: str) -> None:
    """L87（2026-11-24）：报告写入点二次读取审计状态唯一事实源。

    report_gate.check 已读同一事实源阻断；本函数在正式生成/导出**写点**再读一次，
    覆盖「门禁通过后并发出现审计失败/半状态」的 TOCTOU 窗口（失败 → 409 不签发）。
    开关 RULEPROOF_AUDIT_STATE_CONSISTENCY=0 → 零动作（回退 L77 行为）。
    """
    try:
        if not _audit_ledger.audit_state_consistency_enabled():
            return None
        st = _audit_ledger.audit_state(case_id)
    except Exception:  # noqa: BLE001 - 状态读取失败沿用途：门禁已阻断（此处不新增放行）
        logging.getLogger(__name__).warning(
            "L87 report audit state recheck skipped case=%s", case_id, exc_info=True)
        return None
    state = str((st or {}).get("state") or "")
    if state not in ("failed", "inconsistent"):
        return None
    code = ("audit_state_inconsistent" if state == "inconsistent"
            else "audit_state_failed")
    _ge = ReportGateError(
        "审核状态未收敛（" + (f"case.status={st.get('case_status')}"
                             if state == "failed" else "状态来源矛盾")
        + "）：禁止签发正式报告；请修复审计库写入后重跑审核",
        [f"[{code}] audit_state={state}; case_status={st.get('case_status')}; "
         f"failure_epoch={st.get('failure_epoch')}"])
    _ge.code = code
    raise _ge


def report_categories(case_id: str) -> dict:
    """四类报告口径：执行失败 / 不满足 / 未发现 / unknown。"""
    cr = review.case_report(case_id)
    if not cr:
        return {"execution": {"state": "not_run", "label": "未执行", "failed_count": 0,
                              "items": []},
                "nonconformity": {"count": 0, "pending_count": 0, "confirmed_count": 0,
                                  "items": []},
                "not_found": {"count": 0, "items": []},
                "unknown": {"count": 0, "classes": {}, "items": []},
                "not_applicable": {"count": 0, "items": []},
                "total": 0, "category": "not_run", "label": "未审核",
                "note": "项目不存在或不可见"}
    return _augment_categories(cr.get("categories") or {},
                               _manifest_expected_missing(case_id))


def check_gate(case_id: str) -> dict:
    """正式报告门禁：report_gate 基础规则 + 四类口径补强。

    补强针对 report_gate 只看 point_state 的盲区：manifest 的“执行失败/证据不足”
    也必须阻断正式报告，不能让一份“unknown 报告”被当作无问题导出。
    """
    from . import report_gate
    base = report_gate.check(case_id)
    reasons = list(base.get("reasons") or [])
    cats = report_categories(case_id)

    def _add(reason: str):
        if reason and not any(reason in x or x in reason for x in reasons):
            reasons.append(reason)

    execution = cats.get("execution") or {}
    if str(execution.get("state") or "") == "failed":
        _add("审核执行失败：存在执行失败/未跑成的规则，不能导出正式报告")
    unknown = cats.get("unknown") or {}
    # report_gate 已负责 point_state 的 unknown（含 legacy 平台点位例外）；
    # 这里只补它看不到的 manifest 执行/证据不足盲区，避免把平台附录误判为阻断。
    _compat = bool((base.get("stats") or {}).get("compat_mode"))
    _blocking_unknown = [
        x for x in (unknown.get("items") or [])
        if not _audit_ledger.is_na_state(x.get("state"))
        and (str(x.get("source") or "") == "manifest"
             or (not _compat and str(x.get("state") or "") in ("insufficient", "missing")))
    ]
    # F-05：接受入口与门禁必须同源。这里不再自己解析审计日志，统一走
    # report_gate.collect_unknown（平台 point_state + manifest active 并集），
    # 匹配规则也用 report_gate.unknown_key_candidates，保证 HTTP/CLI 接受的点位
    # 能被这里的门禁原样识别；重跑后旧接受自动失效。
    _unk = report_gate.collect_unknown(case_id, cats)
    _accepted = set(_unk.get("accepted_keys") or [])
    _remaining = [x for x in _blocking_unknown
                  if not (report_gate.unknown_key_candidates(x) & _accepted)]
    if _remaining and not any("unknown" in str(x).lower() for x in reasons):
        _add(f"manifest/证据不足仍有 {len(_remaining)} 个 unknown（证据不足/无法判断）")
    nonconf = cats.get("nonconformity") or {}
    if int(nonconf.get("pending_count") or 0) > 0 and not any("待复核" in str(x) for x in reasons):
        _add(f"仍有 {int(nonconf.get('pending_count') or 0)} 条待复核发现")
    stats = dict(base.get("stats") or {})
    stats.update({"unknown_manifest_rows": len(_unk.get("manifest") or []),
                  "unknown_platform_rows": len(_unk.get("platform") or []),
                  "unknown_accepted_count": len(_accepted),
                  "unknown_accepted_unknown": bool(_unk.get("accepted_unknown")),
                  "unknown_manifest_unaccepted": len(_remaining),
                  "unknown_blocking_total": len(_blocking_unknown)})
    # T-201 /metrics：报告门禁检查/拦截指标（报告门禁异常告警的数据源）。
    # 指标失败不影响门禁判定本身（铁律 2：不静默，写日志）。
    try:
        from . import metrics as _metrics
        _metrics.gate_check(not reasons, reasons)
    except Exception:  # noqa: BLE001 - 指标失败不阻断报告门禁
        logging.getLogger(__name__).warning("报告门禁指标埋点失败（已忽略）", exc_info=True)
    out = {"ok": not reasons, "reasons": reasons,
            "stats": stats, "categories": cats, "base": base,
            # P0-稳定性/证据/P1-快照：报告状态与门禁同源暴露（不重复计算）
            "stability": base.get("stability") or {},
            "evidence_gate": base.get("evidence_gate") or {},
            "version_snapshot": base.get("version_snapshot") or {}}
    # L77：门禁同时给出机读错误码（audit_write_failed）；未触发时不新增 key，
    # 保证与接入前输出逐字节一致（既有报告门禁契约不变）。
    if base.get("error_code"):
        out["error_code"] = base.get("error_code")
    # L93：报告签发事实（advisory，不阻断；无报告行时 base 不输出该 key）
    if base.get("report_issuance"):
        out["report_issuance"] = base.get("report_issuance")
        stats["report_issuance"] = (base.get("stats") or {}).get("report_issuance")
    return out


def _taxonomy_html(cats: dict, mrows: list | None = None) -> str:
    cats = cats or {}
    execution = cats.get("execution") or {}
    nonconf = cats.get("nonconformity") or {}
    not_found = cats.get("not_found") or {}
    unknown = cats.get("unknown") or {}
    classes = unknown.get("classes") or {}
    _by_rid = {str(x.get("id") or x.get("result_id") or ""): x for x in (mrows or [])}
    _idx = _category_index(cats)
    _class_parts, _seen_cls = [], set()
    for k, v in classes.items():
        if int(v or 0) <= 0:
            continue
        _label = _unknown_class_label(k)
        if _label not in _seen_cls:
            _seen_cls.add(_label)
            _class_parts.append(f"{_label} {int(v)}")
    _derived = {}
    for _row in (mrows or []):
        if "unknown" not in _row_category_keys(_row, _idx):
            continue
        for _c, _d in _manifest_unknown_classes(_row):
            _derived[_c] = _derived.get(_c, 0) + 1
    for _label, _count in _derived.items():
        if _label not in _seen_cls:
            _seen_cls.add(_label)
            _class_parts.append(f"{_label} {int(_count)}")
    cls_text = "；".join(_class_parts) if _class_parts else "—"
    rows = []
    for key, label in (("execution", "执行失败"), ("nonconformity", "不满足"),
                       ("not_found", "未发现"), ("unknown", "unknown")):
        for item in ((cats.get(key) or {}).get("items") or [])[:120]:
            item = item or {}
            _rid = str(item.get("result_id") or "")
            _row = _by_rid.get(_rid) or {}
            _cls = "—"
            if key == "unknown":
                if _row:
                    _classes = _manifest_unknown_classes(_row)
                    _cls = "；".join(c + (f"：{d}" if d else "") for c, d in _classes) or "—"
                elif str(item.get("state") or "") == "missing":
                    _cls = "结果缺失（missing）"
                elif str(item.get("source") or "") == "platform_point":
                    _cls = _unknown_class_label(
                        "insufficient" if str(item.get("state") or "") == "insufficient"
                        else ("missing" if str(item.get("state") or "") == "missing" else "unknown"))
                else:
                    _cls = _unknown_class_label(item.get("state") or "unknown")
            _state = str(item.get("state") or "")
            _why = (str(item.get("reason") or "")
                    or str(((_row.get("d5") or {}).get("reason")) or "")
                    or str(item.get("conclusion") or ""))
            if not _why and _state == "missing":
                _why = "应审未执行/结果缺失（missing）"
            if not _why and str(item.get("source") or "") == "platform_point":
                _why = str(item.get("title") or "")
            rows.append(
                f'<tr class="taxonomy-detail-row"><td>{_h(label)}</td>'
                f'<td>{_h(str(item.get("rule_code") or "—"))}</td>'
                f'<td>{_h(str(item.get("object") or item.get("object_id") or "—"))}</td>'
                f'<td>{_h(str(item.get("sub_id") or "—"))}</td>'
                f'<td>{_h(_status_label(_state))}</td>'
                f'<td>{_h(_cls)}</td>'
                f'<td>{_h(_short(_why, 140))}</td></tr>')
    if not rows:
        rows.append('<tr class="taxonomy-detail-row"><td colspan="7">无四类明细</td></tr>')
    return (
        f'<h2>报告口径（四类分离）</h2>'
        f'<table class="report-taxonomy">'
        f'<tr><th>口径</th><th>数量</th><th>说明</th></tr>'
        f'<tr><td>执行失败</td><td>{int(execution.get("failed_count") or 0)}</td>'
        f'<td>{_h(execution.get("label") or "未执行")}：没跑成/执行失败的规则不能算不满足</td></tr>'
        f'<tr><td>不满足</td><td>{int(nonconf.get("count") or 0)}</td>'
        f'<td>跑成且明确判失败；待复核 {int(nonconf.get("pending_count") or 0)} 条</td></tr>'
        f'<tr><td>未发现</td><td>{int(not_found.get("count") or 0)}</td>'
        f'<td>已执行且判满足（查过、没发现问题）</td></tr>'
        f'<tr><td>unknown</td><td>{int(unknown.get("count") or 0)}</td>'
        f'<td>证据不足/无法判断/缺失，不得算通过；分类：{_h(cls_text)}</td></tr>'
        + (f'<tr><td>不适用</td><td>{int((cats.get("not_applicable") or {}).get("count") or 0)}</td>'
           f'<td>D1 判不适用/决策表作用域跳过：既不是通过也不是 unknown，不计入四类；'
           f'若全部不适用则报告口径为“不适用”</td></tr>'
           if int((cats.get("not_applicable") or {}).get("count") or 0) else "")
        + f'</table>'
        f'<h3>四类口径明细（逐规则 / 逐子要求）</h3>'
        f'<table class="report-taxonomy-detail">'
        f'<tr><th>口径</th><th>规则</th><th>对象</th><th>子要求</th><th>状态</th>'
        f'<th>unknown 类别</th><th>说明</th></tr>'
        f'{"".join(rows)}</table>'
        f'<p class="dedupe-note"><b>口径说明</b>：{_h(cats.get("note") or "")}</p>'
    )


def _taxonomy_brief(cats: dict) -> str:
    cats = cats or {}
    execution = cats.get("execution") or {}
    nonconf = cats.get("nonconformity") or {}
    not_found = cats.get("not_found") or {}
    unknown = cats.get("unknown") or {}
    classes = unknown.get("classes") or {}
    _cls = "、".join(f"{_unknown_class_label(k)} {int(v)}"
                     for k, v in classes.items() if int(v or 0) > 0)
    _na = int((cats.get("not_applicable") or {}).get("count") or 0)
    return (f"报告口径：{cats.get('label') or '未审核'}　"
            f"执行：{execution.get('label') or '未执行'}（执行失败 "
            f"{int(execution.get('failed_count') or 0)} 项）　"
            f"不满足 {int(nonconf.get('count') or 0)} 项 / "
            f"未发现 {int(not_found.get('count') or 0)} 项 / "
            f"unknown {int(unknown.get('count') or 0)} 项"
            + (f" / 不适用 {_na} 项" if _na else "")
            + (f"（类别：{_cls}）" if _cls else ""))


# ---------------- D1–D5 判定链与 unknown/missing 分类 ----------------
_STATUS_LABELS = {
    "applicable": "适用", "not_applicable": "不适用",
    "bound": "已绑定", "missing": "缺失",
    "insufficient": "证据不足", "skipped": "已跳过",
    "blocked": "执行受阻", "failed": "执行失败",
    "mixed": "混合", "pass": "满足", "fail": "不满足",
    "na": "不适用", "unknown": "无法判断", "needs_model": "无法判断（需模型）",
    "completed": "已完成", "incomplete": "未完成",
}

_CATEGORY_LABELS = {
    "execution": "执行失败",
    "nonconformity": "不满足",
    "not_found": "未发现",
    "unknown": "unknown",
    "not_applicable": "不适用（不计入四类）",
}

_UNKNOWN_CLASS_LABELS = {
    "customer_rule": "客户规则",
    "customer_unexecuted": "客户规则未执行",
    "customer_insufficient": "客户规则证据不足",
    "customer_not_applicable": "客户规则不适用",
    "platform_builtin": "平台/内置规则",
    "not_applicable": "不适用",
    "missing": "结果缺失（missing）",
    "missing_scope": "证据范围缺失（missing scope）",
    "rule_version_missing": "规则版本缺失（missing）",
    "execution_failed": "执行失败",
    "insufficient": "证据不足",
    "unknown": "无法判断",
}

_SCOPE_REASON_LABELS = {
    "text_present": "正文可读",
    "document_empty": "文档无文本",
    "document_unparsed": "文档解析失败",
    "document_path_missing": "文档路径缺失",
    "no_row_anchor": "无行锚点（row 不可用）",
    "missing_scopes": "所需证据范围不可用",
    "not_requested": "未请求该范围",
    "manifest_object_count_le_1": "对象数≤1，无法做跨文件核验",
    "no_evidence_terms": "规则未声明证据项",
    "fewer_than_two_parsed_objects": "可解析对象少于 2 个",
    "no_cross_file_evidence": "未找到跨文件证据",
    "cross_file_evidence_found": "已找到跨文件证据",
    "sheet_anchor_missing": "未找到指定 sheet",
}

_SUB_STATUS_ORDER = ("pass", "fail", "insufficient", "failed", "blocked",
                     "unknown", "needs_model", "not_applicable", "na")


def _short(value, limit: int = 120) -> str:
    s = str(value or "").replace("\n", " ").strip()
    return s if len(s) <= limit else s[:max(1, limit - 1)] + "…"


def _status_label(status) -> str:
    s = str(status or "")
    return _STATUS_LABELS.get(s, s or "未记录")


def _scope_reason(reason) -> str:
    s = str(reason or "")
    return _SCOPE_REASON_LABELS.get(s, s or "未记录")


def _unknown_class_label(code) -> str:
    s = str(code or "")
    return _UNKNOWN_CLASS_LABELS.get(s, s or "未分类")


def _sub_counts(subs: list) -> dict:
    out = {}
    for x in subs or []:
        st = str((x or {}).get("status") or "unknown")
        out[st] = out.get(st, 0) + 1
    return out


def _sub_counts_text(subs: list) -> str:
    counts = _sub_counts(subs)
    return "、".join(f"{_status_label(k)} {counts[k]}" for k in _SUB_STATUS_ORDER if counts.get(k))


def _d1_text(row: dict) -> str:
    d1 = row.get("d1") or {}
    st = str(d1.get("status") or "")
    if not st:
        return "未记录（无 D1 数据）"
    reason = str(d1.get("reason") or "")
    return _status_label(st) + (f"：{_short(reason, 90)}" if reason else "")


def _d2_text(row: dict) -> str:
    d2 = row.get("d2") or {}
    st = str(d2.get("status") or "")
    if not st:
        return "未记录（无 D2 数据）"
    parts = [_status_label(st)]
    version = str(d2.get("version") or "")
    if version:
        parts.append(f"版本 {version}")
    req = str(d2.get("requirement") or "")
    if req:
        parts.append(f"要求：{_short(req, 70)}")
    if st == "missing":
        parts.append("规则版本不存在，规则无法执行")
    return "；".join(parts)


def _d3_text(row: dict) -> str:
    d3 = row.get("d3") or {}
    if not d3:
        return "未记录（无 D3 数据）"
    st = str(d3.get("status") or "")
    parts = [_status_label(st) if st else "未记录"]
    reason = str(d3.get("reason") or "")
    if reason and st != "bound":
        parts.append(f"原因：{_scope_reason(reason)}")
    avail = list(row.get("available_scopes") or d3.get("available_scopes") or [])
    missing = list(row.get("missing_scopes") or d3.get("missing_scopes") or [])
    parts.append("可用范围：" + ("、".join(avail) if avail else "无"))
    parts.append("缺失范围：" + ("、".join(missing) if missing else "无"))
    if d3.get("chars") is not None:
        parts.append(f"文本 {int(d3.get('chars') or 0)} 字")
    limit = d3.get("sheet_limit") or {}
    if isinstance(limit, dict) and limit.get("requested"):
        _sheet = limit.get("sheet") or "、".join(limit.get("sheets") or [])
        parts.append(f"指定 sheet：{_sheet or '未记录'}（{_status_label(limit.get('status') or ('bound' if limit.get('available') else 'missing'))}）")
    return "；".join(parts)


def _d4_text(row: dict) -> str:
    d4 = row.get("d4") or {}
    if not d4:
        return "未记录（无 D4 数据）"
    st = str(d4.get("status") or "")
    parts = [_status_label(st) if st else "未记录"]
    detail = str(d4.get("detail") or "")
    subs = list(row.get("d4_subs") or d4.get("subs") or [])
    if detail and not (subs and detail.startswith(f"{len(subs)} 个子要求")):
        parts.append(_short(detail, 90))
    if subs:
        counts_text = _sub_counts_text(subs)
        parts.append(f"{len(subs)} 个子要求" + (f"：{counts_text}" if counts_text else ""))
        bad = [x for x in subs
               if str((x or {}).get("status") or "") in
               ("insufficient", "failed", "blocked", "unknown", "needs_model")]
        for x in bad[:3]:
            _sid = str(x.get("id") or "")
            _tt = x.get("tool_trace")
            _why = (x.get("missing_evidence") or x.get("detail")
                    or (_tt.get("code") if isinstance(_tt, dict) else "") or "")
            parts.append(f"{_sid or '子要求'}：{_status_label(x.get('status'))}"
                         + (f"（{_short(_why, 60)}）" if _why else ""))
    return "；".join(parts)


def _d5_text(row: dict) -> str:
    d5 = row.get("d5") or {}
    if not d5:
        conclusion = str(row.get("conclusion") or "")
        return ("未记录（无 D5 数据）" + (f"；结论：{conclusion}" if conclusion else ""))
    st = str(d5.get("status") or "")
    parts = [_status_label(st) if st else "未记录"]
    reason = str(d5.get("reason") or "")
    if reason:
        parts.append(_short(reason, 100))
    if d5.get("combination"):
        parts.append(f"组合={d5.get('combination')}")
    if d5.get("fallback"):
        parts.append(f"fallback={d5.get('fallback')}")
    exec_state = str(row.get("execution") or "")
    if exec_state and exec_state not in ("completed",):
        parts.append(f"执行={_status_label(exec_state)}")
    return "；".join(parts)


def _category_index(cats: dict) -> dict:
    """(result_id, sub_id) → 四类口径 key；同一子项四类互斥。"""
    idx = {}
    for key in ("execution", "nonconformity", "not_found", "unknown"):
        for item in ((cats or {}).get(key) or {}).get("items") or []:
            rid = str((item or {}).get("result_id") or "")
            sid = str((item or {}).get("sub_id") or "")
            if rid:
                idx[(rid, sid)] = key
    return idx


def _derive_row_category(row: dict) -> str:
    d1 = row.get("d1") or {}
    d4 = row.get("d4") or {}
    d5 = row.get("d5") or {}
    subs = row.get("d4_subs") or d4.get("subs") or []
    # M1：na 家族（not_applicable / not applicable / skipped / na）统一归「不适用」，
    # 与 audit_ledger.normalize_state 同源；执行失败/未知语义保持独立。
    if _audit_ledger.is_na_state(d1.get("status")) or \
            _audit_ledger.is_na_state(d5.get("status")) or \
            _audit_ledger.is_na_state(d4.get("status")):
        return "not_applicable"
    if _audit_ledger.normalize_state(d4.get("status")) in ("blocked", "failed") or \
            _audit_ledger.normalize_state(d5.get("status")) in ("blocked", "failed") or \
            _audit_ledger.normalize_state(row.get("execution")) in ("blocked", "failed") or \
            any(_audit_ledger.normalize_state((x or {}).get("status")) in ("blocked", "failed")
                for x in subs):
        return "execution"
    st = _audit_ledger.normalize_state(d5.get("status")) if str(d5.get("status") or "") else ""
    if not st:
        st = {"满足": "pass", "不满足": "fail", "不适用": "na",
              "证据不足": "insufficient", "无法判断": "unknown"}.get(
                  str(row.get("conclusion") or ""), "")
    if st == "pass":
        return "not_found"
    if st == "fail":
        return "nonconformity"
    if st == "na":
        return "not_applicable"
    return "unknown"


def _row_category_keys(row: dict, idx: dict) -> list:
    rid = str(row.get("id") or row.get("result_id") or "")
    subs = list(row.get("d4_subs") or (row.get("d4") or {}).get("subs") or [])
    keys = []
    for x in subs:
        k = idx.get((rid, str((x or {}).get("id") or "")))
        if k and k not in keys:
            keys.append(k)
    if not keys:
        k = idx.get((rid, ""))
        if k:
            keys.append(k)
    if not keys:
        keys.append(_derive_row_category(row))
    return keys


def _row_category_text(row: dict, idx: dict) -> str:
    return " / ".join(_CATEGORY_LABELS.get(k, k) for k in _row_category_keys(row, idx))


def _manifest_unknown_classes(row: dict) -> list:
    """从 D1–D5 解释一条 manifest 结果为什么 unknown/missing。

    返回 ``[(类别, 细节)]``，类别用于“unknown 类别”列；D2 缺失、D3
    missing_scopes、D4 子要求证据不足/执行失败分别给出独立说明。
    """
    d2 = row.get("d2") or {}
    d3 = row.get("d3") or {}
    d4 = row.get("d4") or {}
    d5 = row.get("d5") or {}
    subs = list(row.get("d4_subs") or d4.get("subs") or [])
    missing_scopes = list(row.get("missing_scopes") or d3.get("missing_scopes") or [])
    out, seen = [], set()

    def _add(label: str, detail: str = ""):
        detail = _short(detail, 100)
        key = (label, detail)
        if key in seen:
            return
        seen.add(key)
        out.append((label, detail))

    if str(d2.get("status") or "") == "missing":
        _add("规则版本缺失（missing）", "D2 未绑定，规则无法执行（客户规则未执行）")
    if missing_scopes:
        _add("证据范围缺失（missing scope）",
             "缺失范围：" + "、".join(missing_scopes) + "（客户规则证据不足）")
    if str(d3.get("status") or "") == "insufficient" and not missing_scopes:
        _add("客户规则证据不足", "D3：" + _scope_reason(d3.get("reason")))
    if str(d4.get("status") or "") == "blocked":
        _add("规则执行受阻（blocked）", d4.get("detail") or "D4 被阻塞")
    for x in subs:
        st = str((x or {}).get("status") or "")
        sid = str(x.get("id") or "子要求")
        _tt = x.get("tool_trace")
        why = (x.get("missing_evidence") or x.get("detail")
               or (_tt.get("code") if isinstance(_tt, dict) else "") or "")
        if st == "failed":
            _add("子要求执行失败（execution_failed）", f"{sid}：{why or '执行异常'}")
        elif st == "insufficient":
            _add("客户规则证据不足", f"{sid}：{why or '证据不足'}")
        elif st in ("unknown", "needs_model", "blocked"):
            _add("客户规则未执行/无法判断", f"{sid}：{why or _status_label(st)}")
    if not out:
        d5s = str(d5.get("status") or "")
        if d5s in ("unknown", "needs_model"):
            _add("客户规则未执行/无法判断", d5.get("reason") or "D5 无法判断")
        elif d5s == "insufficient":
            _add("客户规则证据不足",
                 d5.get("reason") or f"fallback={d5.get('fallback') or 'abstain'}；证据不足")
        elif str(d4.get("status") or "") in ("insufficient", "blocked", "failed"):
            _add("客户规则证据不足", d4.get("detail") or _status_label(d4.get("status")))
        elif _derive_row_category(row) == "unknown":
            _add("unknown（D 链未记录分类）", "D1–D5 未提供可解释原因")
    return out


def _row_unknown_text(row: dict, idx: dict) -> str:
    classes = _manifest_unknown_classes(row)
    cats = _row_category_keys(row, idx)
    if not classes:
        return "—"
    if "unknown" not in cats and "execution" not in cats and \
            not any("missing" in c.lower() for c, _ in classes):
        return "—"
    return "；".join(c + (f"：{d}" if d else "") for c, d in classes)


def _missing_categories_items(cats: dict) -> list:
    out, seen = [], set()
    for item in ((cats or {}).get("unknown") or {}).get("items") or []:
        if str((item or {}).get("state") or "") != "missing":
            continue
        key = (str(item.get("rule_code") or ""), str(item.get("object_id") or ""),
               str(item.get("object") or ""), str(item.get("sub_id") or ""))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _manifest_expected_missing(case_id: str) -> list:
    """当前 manifest 里应审、但没有 active/结果行的规则（missing）。

    ``audit_ledger`` 在“manifest 一条 result 都没有”时拿不到 expected 清单，
    报告层补上这一盲区：missing 必须有解释，不能静默变成“未发现/通过”。
    """
    try:
        from .. import db as _db
        with _db.session() as c:
            # P0-3：latest run 必须确定可复算——created_at 只到秒，同秒多轮时按 rowid
            # 取最后写入的一轮（否则第二轮可能读到第一轮 manifest，把旧清单算进本轮）。
            ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                           "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
            if ar is not None:
                mid = str(ar["manifest_id"] or "")
                if not mid:
                    # 最近一次 run 不是 manifest 审核：不能拿旧 manifest 推断 missing
                    return []
            else:
                mrow = c.execute("SELECT id FROM audit_manifest WHERE case_id=? "
                                 "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                                 (case_id,)).fetchone()
                mid = str((mrow["id"] if mrow else "") or "")
            if not mid:
                return []
            m = c.execute("SELECT objects_json,items_json FROM audit_manifest WHERE id=?",
                          (mid,)).fetchone()
            if not m:
                return []
            try:
                items = json.loads(m["items_json"] or "[]")
            except Exception:
                items = []
            try:
                objs = {str(o.get("object_id") or ""): str(o.get("filename") or "")
                        for o in json.loads(m["objects_json"] or "[]")}
            except Exception:
                objs = {}
            seen = {(str(r["object_id"] or ""), str(r["rule_code"] or ""))
                    for r in c.execute("SELECT object_id,rule_code FROM manifest_active "
                                       "WHERE case_id=?", (case_id,))}
            if not seen:
                seen = {(str(r["object_id"] or ""), str(r["rule_code"] or ""))
                        for r in c.execute("SELECT object_id,rule_code FROM manifest_result "
                                           "WHERE manifest_id=?", (mid,))}
    except Exception:
        return []
    out, dup = [], set()
    for item in items or []:
        item = item or {}
        oid = str(item.get("object_id") or "")
        code = str(item.get("code") or item.get("rule_code") or "")
        if not code:
            continue
        key = (oid, code)
        if key in seen or key in dup:
            continue
        dup.add(key)
        out.append({"kind": "rule", "source": "manifest", "object_id": oid,
                    "object": objs.get(oid, oid), "rule_code": code, "sub_id": "",
                    "state": "missing", "conclusion": "", "execution": "",
                    "d5_status": "", "result_id": "", "review_status": "",
                    "title": "应审未执行/结果缺失（missing）"})
    return out


def _frozen_manifest_snapshot(case_id: str) -> dict:
    """F-08：报告版本快照的规则集必须取冻结清单实际条目，不取库内 published 总数。"""
    try:
        from .. import db as _db
        with _db.session() as c:
            ar = c.execute(
                "SELECT manifest_id FROM audit_run WHERE case_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
            mid = str((ar["manifest_id"] if ar else "") or "")
            if not mid:
                return {}
            m = c.execute("SELECT rules_json,items_json,hash FROM audit_manifest WHERE id=?",
                          (mid,)).fetchone()
            if not m:
                return {}
            try:
                rules = json.loads(m["rules_json"] or "[]")
            except Exception:
                rules = []
            try:
                items = json.loads(m["items_json"] or "[]")
            except Exception:
                items = []
            return {"manifest_id": mid, "rules": len(rules), "items": len(items),
                    "hash": str(m["hash"] or "")}
    except Exception:
        logging.getLogger(__name__).debug("frozen manifest snapshot skipped", exc_info=True)
        return {}


def _augment_categories(cats: dict, missing_rows: list) -> dict:
    """把 report 层补出的 missing 并入 unknown 桶，避免 missing 被算成未发现。"""
    missing_rows = list(missing_rows or [])
    if not missing_rows:
        return cats or {}
    cats = deepcopy(cats or {})
    unknown = cats.setdefault("unknown", {"count": 0, "classes": {}, "items": []})
    items = list(unknown.get("items") or [])
    seen = {(str(x.get("rule_code") or ""), str(x.get("object_id") or ""),
             str(x.get("sub_id") or "")) for x in items}
    added = 0
    for m in missing_rows:
        key = (str(m.get("rule_code") or ""), str(m.get("object_id") or ""), "")
        if key in seen:
            continue
        seen.add(key)
        items.append(m)
        added += 1
    if not added:
        return cats
    unknown["count"] = len(items)
    unknown["items"] = items
    classes = dict(unknown.get("classes") or {})
    classes["missing"] = int(classes.get("missing") or 0) + added
    unknown["classes"] = classes
    cats["total"] = (int(((cats.get("execution") or {}).get("failed_count")) or 0)
                     + int(((cats.get("nonconformity") or {}).get("count")) or 0)
                     + int(((cats.get("not_found") or {}).get("count")) or 0)
                     + int(unknown.get("count") or 0))
    if str(cats.get("category") or "") != "execution_failed":
        cats["category"] = "unknown"
        cats["label"] = "unknown"
    return cats


def _report_summary_view(summary: dict, cats: dict, base_cats: dict) -> dict:
    """渲染用 summary：missing 让报告口径变为 unknown 时，结论不能仍写“通过”。"""
    s = dict(summary or {})
    base_cat = str((base_cats or {}).get("category") or "")
    new_cat = str((cats or {}).get("category") or "")
    if new_cat and new_cat != base_cat:
        label = str((cats or {}).get("label") or new_cat)
        s["report_category"] = new_cat
        s["report_category_label"] = label
        s["report_verdict"] = label
        s["verdict"] = label
        s["category"] = new_cat
        s["category_label"] = label
        s["category_counts"] = {
            "execution_failed": int(((cats.get("execution") or {}).get("failed_count")) or 0),
            "nonconformity": int(((cats.get("nonconformity") or {}).get("count")) or 0),
            "not_found": int(((cats.get("not_found") or {}).get("count")) or 0),
            "unknown": int(((cats.get("unknown") or {}).get("count")) or 0),
        }
        s["execution_failed_count"] = s["category_counts"]["execution_failed"]
        s["nonconformity_count"] = s["category_counts"]["nonconformity"]
        s["not_found_count"] = s["category_counts"]["not_found"]
        s["unknown_category_count"] = s["category_counts"]["unknown"]
        if new_cat == "unknown":
            s["status"] = "待复核（含缺失结果）"
            s["conclusion"] = s["status"]
        elif new_cat == "not_applicable" and str(s.get("status") or "") == "通过":
            # F-08：全不适用不得显示“通过”
            s["status"] = "不适用"
            s["conclusion"] = "不适用"
    return s


def _missing_item_text(item: dict) -> str:
    return ("应审未执行/结果缺失（missing）：未产出 audit_manifest result"
            if str((item or {}).get("source") or "") == "manifest"
            else "应审未执行/结果缺失（missing）：无 point_state 或执行结果")


def _chain_table_rows(mrows: list, cats: dict) -> list:
    """D1–D5 表的行：每个规则×对象只出现一次 + 没有结果的 missing 行。"""
    rows, seen = [], set()
    for x in (mrows or []):
        key = (str(x.get("id") or x.get("result_id") or ""),
               str(x.get("rule_code") or ""), str(x.get("object_id") or ""))
        if key in seen:
            continue
        seen.add(key)
        rows.append({"kind": "manifest", "row": x})
    for item in _missing_categories_items(cats):
        rows.append({"kind": "missing", "item": item})
    return rows


def _unknown_missing_rows(case_id: str, mrows: list, cats: dict) -> list:
    """unknown / missing 明细（每条都有类别和原因，供 HTML/DOCX 共用）。"""
    idx = _category_index(cats)
    out, seen = [], set()

    def _add(cls: str, detail: str, source: str, rule: str, obj: str, reason: str):
        key = (cls, detail, source, rule, obj)
        if key in seen:
            return
        seen.add(key)
        out.append({"class": cls, "detail": detail, "source": source,
                    "rule": rule, "object": obj, "reason": _short(reason, 160)})

    for row in mrows or []:
        cats_keys = _row_category_keys(row, idx)
        classes = _manifest_unknown_classes(row)
        if not classes:
            continue
        if "unknown" in cats_keys or "execution" in cats_keys:
            d5 = row.get("d5") or {}
            _why = ((d5.get("reason") or "") + "；" if d5.get("reason") else "") + \
                "；".join(f"{c}：{d}" for c, d in classes)
            for c, d in classes:
                _add(c, d, "manifest", str(row.get("rule_code") or ""),
                     str(row.get("object") or row.get("object_id") or ""), _why)

    for item in _missing_categories_items(cats):
        _add("结果缺失（missing）", "", str(item.get("source") or "manifest"),
             str(item.get("rule_code") or ""),
             str(item.get("object") or item.get("object_id") or ""),
             _missing_item_text(item))

    _point_rows = _unknown_rows(case_id)
    _point_keys = set()
    for x in _point_rows:
        _pid = str(x.get("point_id") or "")
        _obj = str(x.get("object") or "")
        _point_keys.add((_pid, _obj))
        _add(str(x.get("_class") or "未分类"), "平台点位 unknown",
             "平台点位", _pid, _obj, str(x.get("reason") or "未执行"))
    for item in ((cats or {}).get("unknown") or {}).get("items") or []:
        if str((item or {}).get("source") or "") != "platform_point":
            continue
        _pid = str(item.get("rule_code") or "")
        _obj = str(item.get("object") or "")
        if (_pid, _obj) in _point_keys:
            continue
        _state = str(item.get("state") or "unknown")
        _add(_unknown_class_label("insufficient" if _state == "insufficient" else
                                  ("missing" if _state == "missing" else "unknown")),
             "", "平台点位", _pid, _obj,
             str(item.get("reason") or item.get("title") or _status_label(_state)))
    return out


def _unknown_class_summary(rows: list) -> str:
    counts = {}
    for x in rows or []:
        cls = str(x.get("class") or "未分类")
        counts[cls] = counts.get(cls, 0) + 1
    return "、".join(f"{k} {v}" for k, v in counts.items()) or "无"


def _chain_row_cells(entry: dict, idx: dict) -> dict:
    if entry.get("kind") == "missing":
        item = entry.get("item") or {}
        return {"rule": str(item.get("rule_code") or "—"),
                "object": str(item.get("object") or item.get("object_id") or "—"),
                "d1": "未产出（missing）", "d2": "未产出（missing）",
                "d3": "未产出（missing）", "d4": "未产出（missing）",
                "d5": "无结果，不能算通过（missing）",
                "category": "unknown",
                "unknown": "结果缺失（missing）"}
    row = entry.get("row") or {}
    return {"rule": str(row.get("rule_code") or "—"),
            "object": str(row.get("object") or row.get("object_id") or "—"),
            "d1": _d1_text(row), "d2": _d2_text(row), "d3": _d3_text(row),
            "d4": _d4_text(row), "d5": _d5_text(row),
            "category": _row_category_text(row, idx),
            "unknown": _row_unknown_text(row, idx)}


def _chain_html(mrows: list, cats: dict) -> str:
    idx = _category_index(cats)
    parts = []
    for entry in _chain_table_rows(mrows, cats):
        c = _chain_row_cells(entry, idx)
        parts.append(
            f'<tr class="chain-row"><td><b>{_h(c["rule"])}</b><br>'
            f'<span class="chain-object">{_h(c["object"])}</span></td>'
            f'<td>{_h(c["d1"])}</td><td>{_h(c["d2"])}</td><td>{_h(c["d3"])}</td>'
            f'<td>{_h(c["d4"])}</td><td>{_h(c["d5"])}</td>'
            f'<td>{_h(c["category"])}</td><td>{_h(c["unknown"])}</td></tr>')
    if not parts:
        parts.append('<tr class="chain-row"><td colspan="8">无 manifest 判定链</td></tr>')
    return (
        f'<h2>逐规则 D1–D5 判定链</h2>'
        f'<p class="dedupe-note"><b>阅读说明</b>：D1 适用范围 → D2 规则版本 → '
        f'D3 证据绑定（含 available / missing scopes）→ D4 子要求执行 → D5 组合结论；'
        f'四类口径与 unknown 类别逐规则标注，不把 unknown/missing 算作通过，也不与不满足混计。</p>'
        f'<table class="report-chain">'
        f'<tr><th>规则 / 对象</th><th>D1 适用范围</th><th>D2 规则版本</th>'
        f'<th>D3 证据绑定（available / missing scopes）</th><th>D4 子要求执行</th>'
        f'<th>D5 组合结论</th><th>四类口径</th><th>unknown 类别</th></tr>'
        f'{"".join(parts)}</table>')


def _unknown_missing_html(case_id: str, mrows: list, cats: dict,
                          rows: list | None = None) -> str:
    rows = _unknown_missing_rows(case_id, mrows, cats) if rows is None else rows
    body = "".join(
        f'<tr class="unknown-row"><td>{_h(str(x.get("class") or "未分类"))}</td>'
        f'<td>{_h(str(x.get("source") or ""))}</td>'
        f'<td>{_h(str(x.get("rule") or "—"))}</td>'
        f'<td>{_h(str(x.get("object") or "—"))}</td>'
        f'<td>{_h(str(x.get("detail") or "—"))}</td>'
        f'<td>{_h(str(x.get("reason") or "—"))}</td></tr>'
        for x in rows[:200])
    if not body:
        body = '<tr class="unknown-row"><td colspan="6">无 unknown / missing 项</td></tr>'
    return (
        f'<h2>unknown / missing 分类</h2>'
        f'<p class="dedupe-note"><b>unknown 类别汇总</b>：{_h(_unknown_class_summary(rows))}。'
        f'unknown=跑成但证据不足/无法判断；missing=应审未执行或无结果；两者都不得算通过。</p>'
        f'<table class="report-unknown">'
        f'<tr><th>unknown 类别</th><th>来源</th><th>规则 / 点位</th><th>对象</th>'
        f'<th>类别说明（D1–D5）</th><th>原因</th></tr>'
        f'{body}</table>')


def _docx_add_chain(doc, mrows: list, cats: dict) -> None:
    idx = _category_index(cats)
    doc.add_heading("二（续）、逐规则 D1–D5 判定链", level=1)
    doc.add_paragraph(
        "D1 适用范围 / D2 规则版本 / D3 证据绑定（available / missing scopes）/ "
        "D4 子要求执行 / D5 组合结论；四类口径与 unknown 类别逐规则标注，"
        "不以单一结论代替判定链。")
    table = doc.add_table(rows=1, cols=9)
    table.style = "Light Grid Accent 1"
    for i, t in enumerate(["规则", "对象", "D1 适用范围", "D2 规则版本",
                           "D3 证据绑定（available / missing scopes）",
                           "D4 子要求执行", "D5 组合结论", "四类口径", "unknown 类别"]):
        table.rows[0].cells[i].text = t
    entries = _chain_table_rows(mrows, cats)
    for entry in entries:
        c = _chain_row_cells(entry, idx)
        row = table.add_row().cells
        for i, key in enumerate(("rule", "object", "d1", "d2", "d3", "d4", "d5",
                                 "category", "unknown")):
            row[i].text = str(c.get(key) or "")
    if not entries:
        row = table.add_row().cells
        row[0].text = "无 manifest 判定链"


def _docx_add_unknown(doc, rows: list) -> None:
    doc.add_heading("二（续二）、unknown / missing 分类", level=1)
    doc.add_paragraph(
        f"unknown 类别汇总：{_unknown_class_summary(rows)}。"
        "unknown=跑成但证据不足/无法判断；missing=应审未执行或无结果；两者都不得算通过。")
    table = doc.add_table(rows=1, cols=6)
    table.style = "Light Grid Accent 1"
    for i, t in enumerate(["unknown 类别", "来源", "规则 / 点位", "对象",
                           "类别说明（D1–D5）", "原因"]):
        table.rows[0].cells[i].text = t
    for x in rows[:200]:
        row = table.add_row().cells
        row[0].text = str(x.get("class") or "未分类")
        row[1].text = str(x.get("source") or "")
        row[2].text = str(x.get("rule") or "—")
        row[3].text = str(x.get("object") or "—")
        row[4].text = str(x.get("detail") or "—")
        row[5].text = str(x.get("reason") or "—")


def _category_items_text(cats: dict, key: str) -> str:
    parts = []
    for item in ((cats or {}).get(key) or {}).get("items") or []:
        item = item or {}
        target = "/".join(x for x in (str(item.get("rule_code") or ""),
                                      str(item.get("object") or item.get("object_id") or ""),
                                      str(item.get("sub_id") or "")) if x)
        if target and target not in parts:
            parts.append(target)
        if len(parts) >= 80:
            break
    return "、".join(parts) or "无"


def _docx_add_category_details(doc, cats: dict) -> None:
    doc.add_paragraph("四类口径明细（逐规则，互不混计）：")
    for key, label in (("execution", "执行失败"), ("nonconformity", "不满足"),
                       ("not_found", "未发现"), ("unknown", "unknown")):
        count = int(((cats or {}).get(key) or {}).get(
            "failed_count" if key == "execution" else "count") or 0)
        doc.add_paragraph(f"{label}（{count}）：{_category_items_text(cats, key)}")


def _manifest_stale_detail(case_id: str) -> dict:
    """报告用 manifest stale 明细：与 ``project.manifest_stale`` 同一口径。

    只读：不写库、不改结果；项目不存在/查询失败时返回空明细，不阻断报告。
    stale 口径、冻结版本、当前版本、原因均直接取 project 的返回值，报告层
    不再自行比较版本，避免与台账/项目详情漂移。
    """
    try:
        from . import project as _project
        status = _project.manifest_stale(case_id) or {}
    except Exception:
        logging.getLogger(__name__).debug(
            "report manifest stale lookup skipped case=%s", case_id, exc_info=True)
        return {"rows": [], "status": {}}
    if not isinstance(status, dict) or not status.get("ok", True):
        return {"rows": [], "status": status if isinstance(status, dict) else {}}
    # stale_results 本身就是已判定 stale 的逐结果明细；仅在旧结构没有该字段时
    # 才回退到 results 里按 stale 标记过滤。
    rows = [x for x in (status.get("stale_results") or []) if isinstance(x, dict)]
    if not rows:
        rows = [x for x in (status.get("results") or [])
                if isinstance(x, dict) and x.get("stale")]
    return {"rows": rows, "status": status}


def _stale_rule_label(row: dict) -> str:
    """stale 行展示的规则/点位：优先规则码，规则码与内部 ID 不同时同时保留。"""
    code = str((row or {}).get("rule_code") or (row or {}).get("rule_id") or "").strip()
    rid = str((row or {}).get("rule_id") or "").strip()
    if not code:
        code = rid or "—"
    return f"{code}（{rid}）" if rid and rid != code else code


def _stale_version_text(value, empty_text: str) -> str:
    return str(value or "").strip() or empty_text


def _stale_reason_text(row: dict) -> str:
    reason = str((row or {}).get("stale_reason") or "").strip()
    if reason:
        return reason
    return "；".join(str(x) for x in ((row or {}).get("stale_reasons") or []) if x) or "版本不一致"


def _stale_current_rule_text(row: dict) -> str:
    """当前规则版本单元格：只有规则下线/不可用时才写“不可用”，避免误判空版本。"""
    version = str((row or {}).get("current_rule_version") or "").strip()
    if version:
        return version
    reason = _stale_reason_text(row)
    if "下线" in reason or "不可用" in reason:
        return "—（当前规则版本不可用）"
    return "—（未记录）"


def _stale_suggestion(row: dict) -> str:
    """按 stale 原因给出可执行的建议；始终明确“建议重跑”。"""
    reasons = [str(x) for x in ((row or {}).get("stale_reasons") or []) if x]
    if not reasons:
        reasons = [str((row or {}).get("stale_reason") or "")]
    joined = " ".join(reasons)
    steps = []
    if "下线" in joined or "不可用" in joined:
        steps.append("改用现行规则重跑")
    elif "规则版本" in joined:
        steps.append("按当前规则版本重跑")
    if "点位库" in joined:
        steps.append("按当前点位库重跑")
    if not steps:
        steps.append("按当前规则/点位库重跑")
    return "建议重跑：" + "；".join(steps) + "；重跑后再导出正式报告"


def _manifest_stale_html(case_id: str) -> str:
    """旧版本 manifest 结果提示（HTML）；没有 stale 时不输出任何内容。"""
    detail = _manifest_stale_detail(case_id)
    rows = detail.get("rows") or []
    if not rows:
        return ""
    status = detail.get("status") or {}
    frozen_lib = str(status.get("frozen_library_version") or "").strip()
    frozen_lib_text = "mixed（见下表）" if frozen_lib == "mixed" else (frozen_lib or "—")
    current_lib = str(status.get("current_library_version") or "").strip()
    current_lib_text = current_lib or "—（当前版本不可用）"
    body = []
    for row in rows[:200]:
        body.append(
            f'<tr class="stale-row" data-result-id="{_h(str(row.get("result_id") or ""))}">'
            f'<td>{_h(_stale_rule_label(row))}</td>'
            f'<td>{_h(str(row.get("object") or row.get("filename") or row.get("object_id") or "—"))}</td>'
            f'<td>{_h(_stale_version_text(row.get("frozen_rule_version"), "—（未记录）"))}</td>'
            f'<td>{_h(_stale_current_rule_text(row))}</td>'
            f'<td>{_h(_stale_version_text(row.get("frozen_library_version"), "—（无冻结快照）"))}</td>'
            f'<td>{_h(_stale_version_text(row.get("current_library_version"), current_lib_text))}</td>'
            f'<td>{_h(_stale_reason_text(row))}</td>'
            f'<td>{_h(_stale_suggestion(row))}</td></tr>')
    return (
        f'<h2>旧版本结果提示（stale）</h2>'
        f'<p class="stale-warn"><b>{len(rows)} 条 manifest 结果的规则/点位版本已滞后：'
        f'结果基于冻结版本，当前规则/点位库已更新或不可用；建议按当前版本重跑该批次后再导出正式报告。</b></p>'
        f'<p class="stale-versions"><b>版本差异（冻结版本 → 当前版本）</b>：'
        f'点位库 {_h(frozen_lib_text)} → {_h(current_lib_text)}；规则版本逐条见下表。</p>'
        f'<table class="report-stale">'
        f'<tr><th>规则/点位</th><th>对象</th><th>冻结规则版本</th><th>当前规则版本</th>'
        f'<th>冻结点位库版本</th><th>当前点位库版本</th><th>stale 原因</th><th>建议</th></tr>'
        f'{"".join(body)}</table>')


def _docx_add_manifest_stale(doc, case_id: str) -> None:
    """旧版本 manifest 结果提示（DOCX）；没有 stale 时不添加任何段落/表格。"""
    detail = _manifest_stale_detail(case_id)
    rows = detail.get("rows") or []
    if not rows:
        return
    status = detail.get("status") or {}
    frozen_lib = str(status.get("frozen_library_version") or "").strip()
    frozen_lib_text = "mixed（见下表）" if frozen_lib == "mixed" else (frozen_lib or "—")
    current_lib = str(status.get("current_library_version") or "").strip()
    current_lib_text = current_lib or "—（当前版本不可用）"
    doc.add_heading("旧版本结果提示（stale）", level=1)
    doc.add_paragraph(
        f"{len(rows)} 条 manifest 结果的规则/点位版本已滞后：结果基于冻结版本，"
        f"当前规则/点位库已更新或不可用；建议按当前版本重跑该批次后再导出正式报告。")
    doc.add_paragraph(
        f"版本差异（冻结版本 → 当前版本）：点位库 {frozen_lib_text} → {current_lib_text}；"
        f"规则版本逐条见下表。")
    table = doc.add_table(rows=1, cols=8)
    table.style = "Light Grid Accent 1"
    headers = ["规则/点位", "对象", "冻结规则版本", "当前规则版本",
               "冻结点位库版本", "当前点位库版本", "stale 原因", "建议"]
    for i, title in enumerate(headers):
        table.rows[0].cells[i].text = title
    for row in rows[:200]:
        cells = table.add_row().cells
        cells[0].text = _stale_rule_label(row)
        cells[1].text = str(row.get("object") or row.get("filename")
                            or row.get("object_id") or "—")
        cells[2].text = _stale_version_text(row.get("frozen_rule_version"), "—（未记录）")
        cells[3].text = _stale_current_rule_text(row)
        cells[4].text = _stale_version_text(row.get("frozen_library_version"),
                                            "—（无冻结快照）")
        cells[5].text = _stale_version_text(row.get("current_library_version"),
                                            current_lib_text)
        cells[6].text = _stale_reason_text(row)
        cells[7].text = _stale_suggestion(row)


def _platform_name_for_case(case_id: str) -> str:
    """报告品牌：跟随案例所属租户的 platform_name，未配置回退默认。"""
    try:
        from . import tenants as _tenants
        name = str((_tenants.branding_for_case(case_id) or {}).get("platform_name") or "").strip()
        return name or "AI 审核平台"
    except Exception:
        logging.getLogger(__name__).debug("report branding skipped", exc_info=True)
        return "AI 审核平台"


def _set_cjk(run, name="微软雅黑"):
    run.font.name = name
    run._element.rPr.rFonts.set("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia", name)


# ---------------- L78（2026-11-24）：多实例 cap 截断显式提示 ----------------
# 背景（90 号 §二-6 / L67 §9.2）：MI cap 截断此前只写审计，报告/台账看不到
# 「已检出 N 处，仅展示前 K」。数据源与台账/point_state 同源
# （pstates.multi_instance_notices → point_state 的 generated_count/kept_count/
# cap_truncated/mi_limit；point_state 未开时回退 manifest_result.d5_json）。
def _mi_truncation_info(case_id: str) -> dict:
    """读本次审核的多实例截断信息（失败返回空结构，不阻断报告生成）。"""
    try:
        from . import pstates as _ps
        return _ps.multi_instance_notices(case_id=case_id) or {}
    except Exception:  # 铁律 2：报告提示读取失败留痕，不阻断报告
        logging.getLogger(__name__).warning(
            "report multi-instance truncation notice skipped case=%s", case_id,
            exc_info=True)
        return {}


def _mi_notice_html(case_id: str) -> str:
    """HTML 报告截断提示块；无截断返回空串（不虚报，保证旧报告逐字段不变）。"""
    info = _mi_truncation_info(case_id)
    notices = info.get("notices") or []
    if not notices:
        return ""
    rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td>%s</td></tr>"
        % (_h(str(n.get("rule") or "")), _h(str(n.get("object") or "")),
           int(n.get("generated_count") or 0), int(n.get("kept_count") or 0),
           int(n.get("limit") or 0), _h(str(n.get("note") or "")))
        for n in notices)
    return ('<p class="mi-truncation-warn"><b>多实例截断提示（需人工复核）</b>：'
            + _h(str(info.get("note") or ""))
            + '</p><table class="report-mi-truncation"><tr><th>规则</th><th>对象</th>'
              '<th>已检出</th><th>已展示</th><th>上限</th><th>提示</th></tr>'
            + rows + '</table>')


def _docx_add_mi_notices(doc, case_id: str) -> None:
    """DOCX 报告截断提示；无截断不写任何段落（不虚报）。"""
    info = _mi_truncation_info(case_id)
    notices = info.get("notices") or []
    if not notices:
        return
    doc.add_paragraph(f"多实例截断提示（需人工复核）：{info.get('note') or ''}")
    for n in notices:
        doc.add_paragraph(f"{n.get('note') or ''}")


def build_report_docx(case_id: str, actor: str = "", role: str = "",
                      render_stamp: str = "") -> bytes:
    """渲染 DOCX 报告。

    L122：``render_stamp`` 为已签发报告冻结的正文时间戳（默认取当前分钟）。
    新签发流程用签发时冻结的时间戳重建 DOCX，保证“已签发正文可复现”
    （否则跨分钟导出会因报告头时间戳变化而无法证明同源）。
    """
    _strict_export_access(case_id, actor, role)
    cr = review.case_report(case_id)
    if not cr:
        return b""
    _pn = _platform_name_for_case(case_id)
    doc = Document()
    doc.add_heading(f"{_pn} · 审核报告", level=0)
    _base_cats = cr.get("categories") or {}
    _cats = _augment_categories(_base_cats, _manifest_expected_missing(case_id))
    s = _report_summary_view(cr["summary"], _cats, _base_cats)
    doc.add_paragraph(f"结论：{s['status']}    严重 {s['critical_count']} 项 / 一般 {s['warning_count']} 项 / 提示 {s.get('suspected_count', 0)} 项")
    doc.add_paragraph(_taxonomy_brief(_cats))
    _docx_add_mi_notices(doc, case_id)
    doc.add_paragraph(
        "四类口径：执行失败 "
        f"{int((_cats.get('execution') or {}).get('failed_count') or 0)} 项 / 不满足 "
        f"{int((_cats.get('nonconformity') or {}).get('count') or 0)} 项 / 未发现 "
        f"{int((_cats.get('not_found') or {}).get('count') or 0)} 项 / unknown "
        f"{int((_cats.get('unknown') or {}).get('count') or 0)} 项")
    _docx_add_category_details(doc, _cats)
    _render_stamp = render_stamp or time.strftime("%Y-%m-%d %H:%M")
    doc.add_paragraph(f"案例：{cr['case']['name']}    生成时间：{_render_stamp}")
    if s.get("point_stale_count"):
        doc.add_paragraph(f"注意：{s['point_stale_count']} 条发现基于旧点位判据，点位库已更新，需复核或重跑。")
    _docx_add_manifest_stale(doc, case_id)

    doc.add_heading("一、发现清单", level=1)
    _mid, _mrows = _manifest_rows(case_id)
    # T-161 三区分层：按区统计（只标记/展示，不改判定；RULEPROOF_ZONE_REPORT=0 时为空）
    _docx_add_zone(doc, _zone_section_view(case_id, cr.get("findings") or [], _mrows))
    _links, _row_links = _ledger_links(cr["findings"], _mrows)
    table = doc.add_table(rows=1, cols=6)
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    for i, t in enumerate(["级别", "发现", "规则", "台账", "证据定位", "建议"]):
        hdr[i].text = t
    for f in cr["findings"]:
        _fid = str(f.get("id") or "")
        _lk = _links.get(_fid)
        row = table.add_row().cells
        row[0].text = _sev(f.get("severity"))
        row[1].text = str(f.get("title") or "")
        row[2].text = f"{f.get('rule_code') or ''} {f.get('rule_name') or ''}"
        if _lk:
            row[3].text = f"台账内 · 已计入（第 {_lk['no']} 行）\n{_fid}"
            _srcp = _source_pointer(_lk.get("row"))
            row[4].text = f"见台账第 {_lk['no']} 行（明细不重复列示{('；' + _srcp) if _srcp else ''}）"
        else:
            row[3].text = "—"
            row[4].text = "；".join(a.get("locator", "") for a in f.get("evidence", []))
        row[5].text = str(f.get("suggestion") or "")
    if _links:
        doc.add_paragraph("去重说明：" + _dedupe_text(cr["findings"], _links))

    if _mrows:
        doc.add_heading("二、规则执行台账", level=1)
        mt = doc.add_table(rows=1, cols=13)
        mt.style = "Light Grid Accent 1"
        for i, t in enumerate(["规则", "对象", "子要求", "子结论", "规则结论", "证据", "执行", "复核", "决策表/行", "原文坐标", "D3/D5 策略", "计算轨迹", "发现ID"]):
            mt.rows[0].cells[i].text = t
        _last_dt_rule = None
        for x in _mrows:
            _rule = str(x.get("rule_code") or "")
            if _rule != _last_dt_rule:
                _g = mt.add_row().cells
                _g[0].merge(_g[-1])
                _g[0].text = "规则 " + _rule + ((" · 决策表 " + str(x.get("decision_table"))) if x.get("decision_table") else "")
                _last_dt_rule = _rule
            row = mt.add_row().cells
            row[0].text = str(x.get("rule_code") or "")
            row[1].text = str(x.get("object") or "")
            row[2].text = str(x.get("sub_id") or "")
            row[3].text = str(x.get("sub_status") or "")
            row[4].text = str(x.get("conclusion") or "")
            row[5].text = str(x.get("sub_quote") or x.get("sub_detail") or "")
            row[6].text = str(x.get("execution") or "")
            row[7].text = str(x.get("review_status") or "pending")
            row[8].text = (str(x.get("decision_table") or "") + ("/行" + str(x.get("hit_row")) if x.get("hit_row") else ""))
            row[9].text = _source_cell(x)
            row[10].text = str(x.get("strategy") or "")
            row[11].text = str(x.get("tool_trace") or "")
            row[12].text = _row_links.get((str(x.get("id") or ""), str(x.get("sub_id") or ""))) or "—"
    _unknown_missing = _unknown_missing_rows(case_id, _mrows, _cats)
    _docx_add_chain(doc, _mrows, _cats)
    _docx_add_stability(doc, case_id)
    _docx_add_version_snapshot(doc, case_id)
    _docx_add_unknown(doc, _unknown_missing)
    doc.add_heading("三、标准对照（三态）", level=1)
    for c in R.conflicts.list():
        doc.add_paragraph(f"{c['rule_b']}：{c['detail']}")

    _tl = _review_timeline(case_id)
    _docx_add_timeline(doc, _tl)
    _sec = 4
    _pgs = _parse_gaps(case_id)
    if _pgs:
        _sec += 1
        doc.add_heading(f"{_CN_NUM[_sec]}、解析缺口附录", level=1)
        for x in _pgs:
            doc.add_paragraph(f"{x.get('filename') or ''}：{x.get('parse_status') or ''} {x.get('parse_summary') or ''}")
    _unk = _unknown_rows(case_id)
    if _unk:
        _sec += 1
        doc.add_heading(f"{_CN_NUM[_sec]}、弃权/未执行附录", level=1)
        for x in _unk[:100]:
            doc.add_paragraph(f"{x.get('point_id') or ''}（{x.get('_class') or '未分类'}）：{x.get('reason') or '未执行'}")
    _sec += 1
    doc.add_heading(f"{_CN_NUM[_sec]}、人工复核", level=1)
    decided = [f for f in cr["findings"] if f["status"] != "pending"]
    if decided:
        for f in decided:
            _line = f"{f['title']} → {_timeline_status_text(f.get('status'))}"
            _by = str(f.get("reviewed_by") or f.get("reviewer") or "")
            _at = str(f.get("reviewed_at") or "")
            _why = _timeline_text(f.get("review_reason") or f.get("review_note") or "")
            if _by or _at or _why:
                _line += f"；复核人：{_by or '—'}；时间：{_at or '—'}；理由：{_why or '—'}"
            doc.add_paragraph(_line)
    else:
        doc.add_paragraph("尚未进行人工复核")

    _sec += 1
    doc.add_heading(f"{_CN_NUM[_sec]}、签名", level=1)
    doc.add_paragraph("审核人：________________    复核人：________________    日期：____________")

    _sec += 1
    doc.add_heading(f"{_CN_NUM[_sec]}、免责声明", level=1)
    doc.add_paragraph(f"本报告由 {_pn} 自动生成，仅输出差异/缺口/待人工确认项，不构成“合规/不合规”结论；"
                     "最终结论以具备资质的专业人员复核为准。")

    # 统一中文字体（_set_cjk 真正生效）
    for p in doc.paragraphs:
        for r in p.runs:
            _set_cjk(r)
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:
                        _set_cjk(r)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def pdf_available() -> bool:
    """当前环境是否配置了 LibreOffice PDF 转换。"""
    try:
        import shutil
        from .. import config
        return bool(
            (config.LO_CLI and config.LO_NODE and os.path.exists(config.LO_CLI) and os.path.exists(config.LO_NODE))
            or shutil.which("soffice") or shutil.which("libreoffice"))
    except Exception:
        return False


def build_report_pdf(case_id: str, actor: str = "", role: str = "") -> bytes:
    """DOCX → PDF（LibreOffice Kit）。返回 PDF 字节；导出失败返回空。"""
    from .. import config
    _strict_export_access(case_id, actor, role)
    docx = build_report_docx(case_id, actor=actor, role=role)
    if not docx:
        return b""
    tmp = tempfile.mkdtemp(prefix="ruleproof_pdf_")
    try:
        docx_path = os.path.join(tmp, "report.docx")
        pdf_path = os.path.join(tmp, "report.pdf")
        with open(docx_path, "wb") as f:
            f.write(docx)
        if not (config.LO_CLI and config.LO_NODE and os.path.exists(config.LO_CLI) and os.path.exists(config.LO_NODE)):
            # 再试系统 LibreOffice（Linux 常见 soffice），都没有则明确不可用
            import shutil as _sh
            soi = _sh.which("soffice") or _sh.which("libreoffice")
            if not soi:
                import logging as _lg
                _lg.getLogger(__name__).warning("PDF 导出不可用：未配置 LibreOffice（RULEPROOF_LO_NODE/LO_CLI）")
                return b""
            subprocess.run([soi, "--headless", "--convert-to", "pdf", "--outdir", tmp, docx_path],
                           capture_output=True, timeout=120)
            if os.path.exists(pdf_path):
                with open(pdf_path, "rb") as f:
                    return f.read()
            return b""
        subprocess.run([config.LO_NODE, config.LO_CLI, "convert",
                        "--input", docx_path, "--output", pdf_path],
                       capture_output=True, timeout=120)
        if os.path.exists(pdf_path):
            with open(pdf_path, "rb") as f:
                return f.read()
        return b""
    except Exception:
        return b""
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def _sev(v) -> str:
    return {"critical": "严重", "warning": "一般", "suspected": "提示", "info": "提示"}.get(v, "提示")


def _h(s) -> str:
    return (str(s or "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;"))


def _source_cell(x: dict) -> str:
    """台账原文坐标列：找到→原文行/sheet 单元格；找不到→显式缺失，不拿决策表行冒充。"""
    x = x or {}
    loc = str(x.get("source_locator") or "")
    quote = str(x.get("source_quote") or "")
    if loc and not x.get("source_location_missing"):
        return f"{loc}：{quote[:80]}" if quote else loc
    if x.get("source_location_missing"):
        return "原文定位缺失"
    return "—"


def _source_pointer(x: dict) -> str:
    """发现清单里的坐标指针（明细仍在台账，不重复展开引用）。"""
    x = x or {}
    loc = str(x.get("source_locator") or "")
    if loc and not x.get("source_location_missing"):
        return f"原文 {loc}"
    if x.get("source_location_missing"):
        return "原文定位缺失"
    return ""


def _manifest_rows(case_id: str) -> tuple[str, list]:
    """只读当前 active result；旧 manifest/旧重判结果保留但不聚合。

    P0-3（2026-11-21）：本轮口径的唯一事实源 = ``manifest_active``；写侧
    ``manifest_exec.run()`` 结束时已把「本清单里不存在」的活跃指针收口摘除
    （``_expire_out_of_scope_active``，回退开关 RULEPROOF_ACTIVE_RUN_SCOPE=0），
    所以这里不需要再按 run 过滤——否则会与台账/门禁的口径分叉。旧轮结果仍保留在
    ``manifest_result``/``audit_manifest`` 可复算，只是不参与「当前报告」聚合。
    """
    import json as _j
    from .. import db as _db
    try:
        with _db.session() as c:
            active = [dict(r) for r in c.execute(
                "SELECT ma.*, mr.*, m.hash AS manifest_hash, m.objects_json "
                "FROM manifest_active ma JOIN manifest_result mr ON mr.id=ma.result_id "
                "JOIN audit_manifest m ON m.id=mr.manifest_id WHERE ma.case_id=? "
                "ORDER BY mr.rule_code,mr.object_id", (case_id,))]
            if not active:
                # 兼容旧数据：没有 active 指针时退回最新 run 的 manifest
                ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                               "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                               (case_id,)).fetchone()
                mid = (ar["manifest_id"] if ar else "") or ""
                if not mid:
                    return "", []
                m = c.execute("SELECT objects_json, hash FROM audit_manifest WHERE id=?", (mid,)).fetchone()
                if not m:
                    return "", []
                active = []
                for r in c.execute("SELECT * FROM manifest_result WHERE manifest_id=? ORDER BY rule_code,object_id", (mid,)):
                    active.append({**dict(r), "manifest_hash": m["hash"], "objects_json": m["objects_json"]})
            if not active:
                return "", []
            objects = {}
            for _a in active:
                try:
                    for _o in _j.loads(_a.get("objects_json") or "[]"):
                        objects[_o.get("object_id")] = _o.get("filename")
                except Exception:
                    pass
            mid = str(active[0].get("manifest_id") or "")
            rows = []
            for d in active:
                subs = []
                try:
                    subs = (_j.loads(d.get("d4_json") or "{}")).get("subs") or []
                except Exception:
                    subs = []
                obj = objects.get(d.get("object_id") or "", d.get("object_id") or "")
                try:
                    _hist = [dict(x) for x in c.execute("SELECT * FROM manifest_review WHERE result_id=? ORDER BY created_at", (d.get("id"),))]
                except Exception:
                    _hist = []
                try:
                    _d1 = _j.loads(d.get("d1_json") or "{}") or {}
                    _d2 = _j.loads(d.get("d2_json") or "{}") or {}
                    _d3 = _j.loads(d.get("d3_json") or "{}") or {}
                    _d4 = _j.loads(d.get("d4_json") or "{}") or {}
                    _d5 = _j.loads(d.get("d5_json") or "{}") or {}
                except Exception:
                    _d1, _d2, _d3, _d4, _d5 = {}, {}, {}, {}, {}
                _strategy = f"D3 {_d3.get('status') or '-'} / D5 {_d5.get('status') or '-'} / 不足 {_d5.get('fallback') or '-'}"
                _chain = {"d1": _d1, "d2": _d2, "d3": _d3, "d4": _d4, "d5": _d5,
                          "available_scopes": list(_d3.get("available_scopes") or []),
                          "missing_scopes": list(_d3.get("missing_scopes") or []),
                          "d4_subs": list(_d4.get("subs") or []),
                          "d5_status": str(_d5.get("status") or ""),
                          "d5_fallback": str(_d5.get("fallback") or "")}
                _dmn_code = ""; _dmn_row = ""
                if not subs:
                    rows.append({**d, **{
                                 "object": obj, "sub_id": "", "sub_status": "", "strategy": _strategy,
                                 "decision_table": "", "hit_row": "",
                                 "sub_quote": "", "subs": [], "history": _hist,
                                 "source_locator": "", "source_quote": "",
                                 "source_location_missing": False,
                                 "hash": d.get("manifest_hash") or ""}, **_chain})
                else:
                    for _sub in subs:
                        _tt = _sub.get("tool_trace") or {}
                        rows.append({**d, **{
                                     "object": obj, "history": _hist, "strategy": _strategy,
                                     "decision_table": str(_tt.get("code") or ""),
                                     "hit_row": str(_tt.get("row") or ""),
                                     "sub_id": _sub.get("id") or "",
                                     "sub_status": _sub.get("status") or "",
                                     "sub_quote": _sub.get("quote") or "",
                                     "sub_detail": _sub.get("detail") or "",
                                     "tool_trace": _sub.get("tool_trace") or {},
                                     "source_locator": str(_tt.get("source_locator") or ""),
                                     "source_quote": str(_tt.get("source_quote") or ""),
                                     "source_location_missing": bool(
                                         _tt.get("source_location_missing")
                                         or _sub.get("source_location_missing")),
                                     "subs": subs, "hash": d.get("manifest_hash") or ""}, **_chain})
            return mid, rows
    except Exception:
        return "", []


# ---------------------------------------------------------------- 稳定性投票（P0-4）
# 报告不重新发明投票口径：直接读 manifest_exec.stability_votes（与 report_gate 同源）。
# 输出：N 次重审的多数结论 + 票型 + 翻转 marker；未满 N 次显式标注，不冒充稳定。
def _stability_view(case_id: str) -> dict:
    try:
        from . import manifest_exec as _mex
        return _mex.stability_votes(case_id, persist=False) or {}
    except Exception:
        logging.getLogger(__name__).debug("stability view skipped", exc_info=True)
        return {}


def _stability_state_text(item: dict) -> str:
    states = item.get("states") or []
    return " → ".join(str((s or {}).get("state") or "missing") for s in states) or "—"


def _stability_verdict(item: dict) -> str:
    if item.get("flip"):
        return "翻转（阻断签发）"
    if item.get("stable"):
        return "稳定"
    return "未满 N 次/未定"


def _stability_html(case_id: str) -> str:
    st = _stability_view(case_id)
    if not st:
        return ""
    n = int(st.get("n") or 3)
    runs = int(st.get("runs_count") or 0)
    flips = st.get("flips") or []
    key_flips = st.get("key_flips") or []
    if key_flips:
        head = (f'<p class="stability-block"><b>稳定性阻断</b>：关键规则判定翻转 '
                f'{len(key_flips)} 条（最近 {n} 次审核 pass↔fail 不一致）；'
                f'marker 已阻断正式报告签发，需人工确认后重审至稳定。</p>')
    elif flips:
        head = (f'<p class="stability-block"><b>稳定性阻断</b>：发现 {len(flips)} 条判定翻转'
                f'（pass↔fail），需人工确认后重审。</p>')
    elif runs >= n:
        head = (f'<p class="stability-ok"><b>稳定性投票</b>：最近 {n} 次审核一致率为 100%，'
                f'{int(st.get("points") or 0)} 个问题实例均未翻转；'
                f'投票结果已落库（vote_recorded={bool(st.get("vote_recorded"))}）。</p>')
    else:
        head = (f'<p class="stability-wait"><b>稳定性投票</b>：仅 {runs}/{n} 次审核记录，'
                f'未满 N={n}，暂不做稳定性结论（不构成阻断）。</p>')
    parts = []
    for item in st.get("items") or []:
        dist = item.get("conclusion_dist") or {}
        dist_text = " / ".join(f"{k}:{v}" for k, v in dist.items() if v) or "—"
        _sub = str(item.get("sub_id") or "")
        _occ = str(item.get("occurrence_id") or "")
        _name = str(item.get("rule_code") or "")
        if _sub:
            _name += f" · {_sub}"
        if _occ and _occ != _sub:
            _name += f" · {_occ}"
        parts.append(
            f'<tr class="stability-row"><td>{_h(_name)}<br>'
            f'<span class="chain-object">{_h(str(item.get("rule_name") or ""))}</span></td>'
            f'<td>{_h("关键规则" if item.get("key_rule") else "一般规则")}</td>'
            f'<td>{_h(_stability_state_text(item))}</td>'
            f'<td>{_h(dist_text)}</td><td>{_h(str(item.get("majority") or ""))}</td>'
            f'<td>{_h(_stability_verdict(item))}</td></tr>')
    table = ('<table class="report-stability"><tr><th>规则 / 问题实例</th><th>级别</th>'
             '<th>最近 N 次结论</th><th>票型</th><th>多数结论</th><th>稳定性</th></tr>'
             + "".join(parts) + '</table>')
    return (f'<h2>稳定性投票与翻转标记（N={n} 重审 · 问题实例级）</h2>{head}{table}')


def _docx_add_stability(doc, case_id: str) -> None:
    st = _stability_view(case_id)
    if not st:
        return
    n = int(st.get("n") or 3)
    runs = int(st.get("runs_count") or 0)
    flips = st.get("flips") or []
    key_flips = st.get("key_flips") or []
    doc.add_heading(f"稳定性投票与翻转标记（N={n} 重审 · 问题实例级）", level=1)
    if key_flips:
        doc.add_paragraph(
            f"稳定性阻断：关键规则判定翻转 {len(key_flips)} 条（最近 {n} 次审核 pass↔fail 不一致）；"
            "marker 已阻断正式报告签发，需人工确认后重审至稳定。")
    elif flips:
        doc.add_paragraph(f"稳定性阻断：发现 {len(flips)} 条判定翻转（pass↔fail），需人工确认后重审。")
    elif runs >= n:
        doc.add_paragraph(
            f"稳定性投票：最近 {n} 次审核一致率为 100%，{int(st.get('points') or 0)} 个问题实例"
            f"均未翻转；投票结果已落库（vote_recorded={bool(st.get('vote_recorded'))}）。")
    else:
        doc.add_paragraph(
            f"稳定性投票：仅 {runs}/{n} 次审核记录，未满 N={n}，暂不做稳定性结论（不构成阻断）。")
    table = doc.add_table(rows=1, cols=6)
    table.style = "Light Grid Accent 1"
    for i, t in enumerate(["规则 / 问题实例", "级别", "最近 N 次结论", "票型",
                           "多数结论", "稳定性"]):
        table.rows[0].cells[i].text = t
    for item in st.get("items") or []:
        row = table.add_row().cells
        _name = str(item.get("rule_code") or "") + (
            f" · {item.get('sub_id')}" if item.get("sub_id") else "")
        row[0].text = _name
        row[1].text = "关键规则" if item.get("key_rule") else "一般规则"
        row[2].text = _stability_state_text(item)
        dist = item.get("conclusion_dist") or {}
        row[3].text = " / ".join(f"{k}:{v}" for k, v in dist.items() if v) or "—"
        row[4].text = str(item.get("majority") or "")
        row[5].text = _stability_verdict(item)


# ---------------------------------------------------------------- 版本快照 v2（P1-6）
# 与门禁同源：直接读 version_snapshot（delivery-ready v2），报告/审计可显示一致/差异。
_VERIFY_SNAPSHOT_CACHE = {}


def _version_snapshot_current(case_id: str, run_id: str, case: dict) -> dict:
    """在 case 所属租户/空间构建当前快照（避免读到调用方空间的规则集）。"""
    from . import version_snapshot as _vs
    from . import ctx as _cx
    tid = str((case or {}).get("tenant_id") or "t-default")
    wid = str((case or {}).get("workspace_id") or "ws-default")
    # L98 P1：完整状态快照/恢复（系统作用域/审核模式/case 归因一并还原）
    saved = _cx.snapshot()
    switched = (saved.get("tenant_id") or "") != tid or (saved.get("workspace_id") or "") != wid
    try:
        if switched:
            _cx.set_context(tid, wid)
        return _vs.build(case_id, run_id, tenant_id=tid, workspace_id=wid)
    finally:
        if switched:
            try:
                _cx.restore(saved)
            except Exception:
                logging.getLogger(__name__).debug("ctx restore skipped", exc_info=True)


def _version_snapshot_view(case_id: str) -> dict:
    out = {"found": False, "note": "", "report": {}, "verify": {}}
    case = R.cases.get(case_id) or {}
    run_id = str(case.get("last_run_id") or "")
    if not run_id:
        out["note"] = "项目尚无审核 run，无运行版本快照"
        return out
    try:
        from . import version_snapshot as _vs
        snap = _vs.load(case_id, run_id)
        if not snap:
            out["note"] = "该 run 无 v2 扩展快照（旧 run 或审核执行未保存）；按不可回放处理"
            return out
        out["found"] = True
        out["report"] = _vs.report_block(snap) or {}
        _key = (case_id, run_id)
        if _key not in _VERIFY_SNAPSHOT_CACHE:
            _cur = _version_snapshot_current(case_id, run_id, case)
            _VERIFY_SNAPSHOT_CACHE[_key] = _vs.verify(case_id, run_id, current=_cur) or {}
        out["verify"] = _VERIFY_SNAPSHOT_CACHE[_key]
    except Exception as e:  # noqa: BLE001
        out["note"] = f"快照读取失败：{type(e).__name__}"
    return out


def _version_snapshot_html(case_id: str) -> str:
    vs = _version_snapshot_view(case_id)
    if not vs.get("found"):
        return (f'<p class="snapshot-wait"><b>运行版本快照（v2）</b>：'
                f'{_h(vs.get("note") or "无 v2 快照")}</p>')
    blk = vs.get("report") or {}
    ver = vs.get("verify") or {}
    rows = [
        ("快照 ID", blk.get("snapshot_id")), ("digest", blk.get("digest")),
        ("生成时间", blk.get("built_at")), ("模型", blk.get("model")),
        ("提示词", f"{blk.get('prompt_version') or ''} · {blk.get('prompt_sha') or ''}"),
        ("规则集", f"{blk.get('rules_count') or 0} 条 · {blk.get('rules') or ''}"),
        ("参数哈希", blk.get("params_sha")), ("本体哈希", blk.get("ontology_sha")),
        ("解析器", blk.get("parser_sha")), ("采样", blk.get("sampling_sha")),
        ("执行器", blk.get("executors_sha")), ("路由", blk.get("routing_sha")),
        ("缓存命名空间", blk.get("cache_namespace")),
    ]
    body = "".join(f"<tr><td>{_h(str(k))}</td><td>{_h(str(v or '—'))}</td></tr>"
                   for k, v in rows)
    if ver.get("found"):
        if ver.get("identical"):
            head = ('<p class="snapshot-ok"><b>一致性校验</b>：当前运行配置与审核时快照'
                    ' <b>一致</b>（replayable=True）。</p>')
        else:
            _changed = "、".join(str(x) for x in (ver.get("changed") or [])[:20]) or "—"
            head = (f'<p class="snapshot-diff"><b>一致性校验</b>：存在差异 '
                    f'{len(ver.get("changed") or [])} 项（{_h(_changed)}）；'
                    f'差异不阻断已执行审核的签发，但需审计关注/必要时重审。</p>')
    else:
        head = f'<p class="snapshot-wait"><b>一致性校验</b>：{_h(str(ver.get("error") or "不可用"))}</p>'
    return (f"<h2>运行版本快照（v2）与一致性</h2>{head}"
            f'<table class="report-snapshot">{body}</table>')


def _docx_add_version_snapshot(doc, case_id: str) -> None:
    vs = _version_snapshot_view(case_id)
    doc.add_heading("运行版本快照（v2）与一致性", level=1)
    if not vs.get("found"):
        doc.add_paragraph(str(vs.get("note") or "无 v2 快照"))
        return
    blk = vs.get("report") or {}
    ver = vs.get("verify") or {}
    if ver.get("found"):
        if ver.get("identical"):
            doc.add_paragraph("一致性校验：当前运行配置与审核时快照一致（replayable=True）。")
        else:
            doc.add_paragraph(
                "一致性校验：存在差异 "
                + "、".join(str(x) for x in (ver.get("changed") or [])[:20])
                + "；差异不阻断已执行审核的签发，但需审计关注/必要时重审。")
    table = doc.add_table(rows=1, cols=2)
    table.style = "Light Grid Accent 1"
    table.rows[0].cells[0].text = "字段"
    table.rows[0].cells[1].text = "值"
    for k, v in (("快照 ID", blk.get("snapshot_id")), ("digest", blk.get("digest")),
                 ("生成时间", blk.get("built_at")), ("模型", blk.get("model")),
                 ("提示词", f"{blk.get('prompt_version') or ''} · {blk.get('prompt_sha') or ''}"),
                 ("规则集", f"{blk.get('rules_count') or 0} 条 · {blk.get('rules') or ''}"),
                 ("参数哈希", blk.get("params_sha")), ("本体哈希", blk.get("ontology_sha")),
                 ("解析器", blk.get("parser_sha")), ("采样", blk.get("sampling_sha")),
                 ("执行器", blk.get("executors_sha")), ("路由", blk.get("routing_sha")),
                 ("缓存命名空间", blk.get("cache_namespace"))):
        row = table.add_row().cells
        row[0].text = str(k)
        row[1].text = str(v or "—")


def _ledger_links(findings: list, mrows: list) -> tuple[dict, dict]:
    """建立 manifest collect 发现与台账行的双向索引，用于报告去重展示。

    关联口径与物化口径一致：finding id = ``mfc-<manifest_result_id>-<sub_id>``
    （sub_id 中的 ``#`` 在物化时替换为 ``-``）。只关联本次报告实际渲染的
    finding；已被 superseded / 不在当前批次的历史 finding 不会被误标“已计入”。

    返回 ``(by_finding, by_row)``：
    - ``by_finding[fid] = {"no": 台账行序号(1-based), "result_id", "sub_id", "row"}``
    - ``by_row[(result_id, sub_id)] = fid``
    """
    fids = set()
    for f in (findings or []):
        _fid = str(f.get("id") or "")
        if not _fid:
            continue
        if str(f.get("engine") or "") == "manifest:decision_table" or _fid.startswith("mfc-"):
            fids.add(_fid)
    by_finding, by_row = {}, {}
    for no, row in enumerate(mrows or [], 1):
        _rid = str(row.get("id") or row.get("result_id") or "")
        _sid = str(row.get("sub_id") or "")
        if not _rid or not _sid:
            continue
        _fid = f"mfc-{_rid}-{_sid.replace('#', '-')}"
        if _fid not in fids:
            continue
        by_finding[_fid] = {"no": no, "result_id": _rid, "sub_id": _sid, "row": row}
        by_row[(_rid, _sid)] = _fid
    return by_finding, by_row


def _dedupe_text(findings: list, links: dict) -> str:
    """报告去重口径说明：发现计数按 finding 算，台账明细行不重复计入。"""
    _mirrored = len(links or {})
    _total = len(findings or [])
    _other = max(0, _total - _mirrored)
    return (f"{_mirrored} 条 manifest:decision_table 发现已计入《规则执行台账》，"
            f"发现清单仅保留可复核索引（标记为台账内、已计入）；"
            f"两表通过 finding_id 双向链接，台账明细行不重复计入发现数。"
            f"统计口径：发现总数 {_total} 条（台账内 {_mirrored} 条、其他 {_other} 条）。")


# ---------------------------------------------------------------- T-161 三区分层（只做报告分区）
def _zone_section_view(case_id: str, findings: list, mrows: list) -> dict:
    """T-161：报告用「按区统计」（三分类）。开关 RULEPROOF_ZONE_REPORT=0 时返回 {}。

    只读：不改 finding/结论/门禁；分区口径与 app/services/audit_zone.py 单一来源。
    """
    try:
        from . import audit_zone as _az
        return _az.zone_view(findings, mrows, case_id=case_id)
    except Exception:  # noqa: BLE001 —— 分区是报告增强，失败不得阻断报告原内容
        logging.getLogger(__name__).warning("audit zone view skipped", exc_info=True)
        return {}


def _zone_html(view: dict) -> str:
    """三区统计 HTML（确定性区 / 证据区 / 影子空间）。"""
    if not view or not view.get("enabled"):
        return ""
    from . import audit_zone as _az
    f = view.get("findings") or {}
    j = view.get("judgments") or {}
    sh = view.get("shadow") or {}
    det, evi = _az.ZONE_DETERMINISTIC, _az.ZONE_EVIDENCE
    unk = _az.ZONE_UNKNOWN

    def _rate(zone):
        b = j.get(zone) or {}
        r = b.get("pass_rate")
        return "—" if r is None else f"{r:.1%}"

    def _not_judged(zone):
        b = j.get(zone) or {}
        return int(b.get("not_judged") or 0)

    rows = [
        f"<tr><td>{_az.zone_label(det)}（calculate/text/compare）</td>"
        f"<td>{int(f.get(det, 0))}</td><td>{int((j.get(det) or {}).get('judged', 0))}</td>"
        f"<td>{int((j.get(det) or {}).get('fail', 0))}</td><td>{_rate(det)}</td>"
        f"<td>{_not_judged(det)}</td></tr>",
        f"<tr><td>{_az.zone_label(evi)}（semantic/expert）</td>"
        f"<td>{int(f.get(evi, 0))}</td><td>{int((j.get(evi) or {}).get('judged', 0))}</td>"
        f"<td>{int((j.get(evi) or {}).get('fail', 0))}</td><td>{_rate(evi)}</td>"
        f"<td>{_not_judged(evi)}</td></tr>",
        f"<tr><td>{_az.zone_label(_az.ZONE_SHADOW)}</td>"
        f"<td>{int(f.get(_az.ZONE_SHADOW, 0))}</td><td>—</td><td>—</td>"
        f"<td>未计入通过率</td><td>{int(sh.get('manifest_entries', 0))} 条 manifest 非结论</td></tr>",
    ]
    if int(f.get(unk, 0)):
        rows.append(
            f"<tr><td>{_az.zone_label(unk)}（数据异常，不猜确定性）</td>"
            f"<td>{int(f.get(unk, 0))}</td><td>{int((j.get(unk) or {}).get('judged', 0))}</td>"
            f"<td>{int((j.get(unk) or {}).get('fail', 0))}</td><td>{_rate(unk)}</td>"
            f"<td>{_not_judged(unk)}</td></tr>")
    total = int(view.get("findings_total") or 0)
    reasons = sh.get("reasons") or {}
    reasons_text = "；".join(f"{k} ×{v}" for k, v in sorted(reasons.items())) or "无"
    return (
        "<h2>按区统计（三分类 · 确定性区 / 证据区 / 影子空间）</h2>"
        "<p>分区只做标记与统计，<b>不改变任何判定与结论</b>："
        "区 1 由平台确定性执行器出结论，区 2 由模型发现 + 平台锚定落账，"
        "区 3 只展示、不结论、不计入通过率。</p>"
        "<table><tr><th>区</th><th>finding 数</th><th>判定数</th><th>fail</th>"
        "<th>通过率（分母只算本区）</th><th>未判定/弃权</th></tr>"
        + "".join(rows) + "</table>"
        f"<p><b>三区 finding 分布：确定性区 {int(f.get(det, 0))} 条 / "
        f"证据区 {int(f.get(evi, 0))} 条 / 影子空间 {int(f.get(_az.ZONE_SHADOW, 0))} 条"
        + (f" / 未映射 {int(f.get(unk, 0))} 条" if int(f.get(unk, 0)) else "")
        + f"，合计 {total} 条（= 原 finding 数）。</b></p>"
        f"<p class=\"stale-warn\"><b>影子空间：{int(sh.get('finding_count', 0))} 条 finding + "
        f"{int(sh.get('manifest_entries', 0))} 条 manifest 非结论，"
        "仅展示，未计入通过率</b>（人工裁决后回流校准）。进入原因："
        f"{reasons_text}</p>")


def _docx_add_zone(doc, view: dict) -> None:
    """三区统计写进 DOCX（与 HTML 同源）。"""
    if not view or not view.get("enabled"):
        return
    from . import audit_zone as _az
    f = view.get("findings") or {}
    j = view.get("judgments") or {}
    sh = view.get("shadow") or {}
    doc.add_heading("按区统计（三分类）", level=1)
    doc.add_paragraph(
        f"三区 finding 分布：确定性区 {int(f.get(_az.ZONE_DETERMINISTIC, 0))} 条 / "
        f"证据区 {int(f.get(_az.ZONE_EVIDENCE, 0))} 条 / 影子空间 {int(f.get(_az.ZONE_SHADOW, 0))} 条"
        + (f" / 未映射 {int(f.get(_az.ZONE_UNKNOWN, 0))} 条" if int(f.get(_az.ZONE_UNKNOWN, 0)) else "")
        + f"，合计 {int(view.get('findings_total') or 0)} 条（= 原 finding 数）。")
    for zone in (_az.ZONE_DETERMINISTIC, _az.ZONE_EVIDENCE):
        b = j.get(zone) or {}
        rate = b.get("pass_rate")
        doc.add_paragraph(
            f"{_az.zone_label(zone)}：判定 {int(b.get('judged', 0))} 条 / fail "
            f"{int(b.get('fail', 0))} 条 / 通过率 "
            f"{'—' if rate is None else f'{rate:.1%}'}（分母只算本区）；"
            f"未判定/弃权 {int(b.get('not_judged', 0))} 条")
    doc.add_paragraph(
        f"影子空间：{int(sh.get('finding_count', 0))} 条 finding + "
        f"{int(sh.get('manifest_entries', 0))} 条 manifest 非结论，仅展示，未计入通过率；"
        "人工裁决后回流校准。")


def _parse_gaps(case_id: str) -> list:
    try:
        from . import project as _pj
        case = R.cases.get(case_id) or {}
        if str(case.get("compat_mode") or "") != "legacy":
            return []
        # L52 ②：compat 只对「无 manifest 的纯 legacy 传输」放宽解析缺口附录；
        # 走了 manifest 主链的兼容案件不再附 legacy 缺口附录（可回退开关=0）。
        try:
            from . import single_entry as _se
            if _se.enabled() and _se.case_has_manifest(case_id):
                return []
        except Exception:  # noqa: BLE001 - 标注失败保持旧口径
            logging.getLogger(__name__).debug(
                "parse gaps compat tightening skipped", exc_info=True)
        return [d for d in _pj.documents(case_id)
                if (d.get("parse_status") or "ok") in ("partial", "failed")]
    except Exception:
        return []


def _unknown_rows(case_id: str) -> list:
    try:
        from .. import db as _db
        from . import pstates as _ps
        with _db.session() as c:
            ar = c.execute("SELECT batch_ids FROM audit_run WHERE case_id=? "
                           "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                           (case_id,)).fetchone()
        bs = [x for x in str((ar["batch_ids"] if ar else "") or "").split(",") if x]
        out = []
        cls = _ps.unknown_classes(case_id)
        labels = {}
        for k, label in (("customer_unexecuted", "客户规则未执行"),
                         ("customer_insufficient", "客户规则证据不足"),
                         ("customer_not_applicable", "客户规则不适用"),
                         ("platform_builtin", "平台/内置规则"),
                         ("not_applicable", "不适用")):
            for pid in cls.get(k) or []:
                labels[str(pid)] = label
        for b in bs:
            for r in _ps.detail(b, limit=5000):
                if str(r.get("state") or "") == "unknown":
                    r = dict(r)
                    r["_class"] = labels.get(str(r.get("point_id") or ""), "未分类")
                    out.append(r)
        return out
    except Exception:
        return []




# ---------------- 复核 / 补证 / 重判统一时间线 ----------------
_ROLE_LABELS = {
    "reviewer": "审核员",
    "admin": "业务管理员",
    "super_admin": "系统管理员",
    "platform_op": "平台运营",
}

_REVIEW_STATUS_LABELS = {
    "pending": "待复核",
    "confirmed": "已确认",
    "false_positive": "误报",
    "need_evidence": "需补证",
    "needs_evidence": "需补证",
    "ignored": "已忽略",
    "pending_reaudit": "待重判",
    "insufficient": "证据不足",
}

_TIMELINE_KIND_LABELS = {
    "review": "复核",
    "evidence_request": "补证申请",
    "evidence_fulfill": "补证登记",
    "reaudit": "重判",
}

_CN_NUM = ("零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十")

# 只识别明确的文件路径形态；业务文本里的“CFU/g”“证据/材料”不能被误伤。
_ABS_PATH_RE = re.compile(
    r"""(?<![A-Za-z0-9_.\-/])(?:file://)?(?:~|/)(?:[^\s<>"'，。；、）】/]+/)+[^\s<>"'，。；、）】/]+""")
_REL_PATH_RE = re.compile(
    r"""(?<![A-Za-z0-9_.\-/])(?:\.{1,2}/)(?:[^\s<>"'，。；、）】/]+/)*[^\s<>"'，。；、）】/]+""")
_WIN_PATH_RE = re.compile(
    r"""(?<![A-Za-z0-9_.\-\\])(?:[A-Za-z]:\\|\\\\)[^\s<>"'，。；、）】]+""")


def _timeline_basename(value) -> str:
    """取文件名（同时兼容 / 与 \\）；只用于展示，不保留目录。"""
    s = str(value or "").strip().replace("\\", "/").rstrip("/")
    return s.rsplit("/", 1)[-1] if s else ""


def _timeline_safe_paths(value) -> str:
    """把文本中的内部文件路径替换为文件名，避免报告泄露服务器目录。"""
    s = str(value or "")
    if not s:
        return ""
    for _pat in (_ABS_PATH_RE, _REL_PATH_RE, _WIN_PATH_RE):
        s = _pat.sub(lambda m: _timeline_basename(m.group(0)) or "补充材料", s)
    return s


def _timeline_safe_ref(value) -> str:
    """补证材料引用：纯路径只留文件名；普通业务文本原样保留。"""
    s = str(value or "").strip()
    if not s:
        return ""
    if (s.startswith(("/", "~/", "./", "../", "file://"))
            or re.match(r"^[A-Za-z]:[\\/]", s)
            or s.startswith("\\\\")):
        return _timeline_basename(s) or "补充材料"
    return _timeline_safe_paths(s)


def _timeline_text(value, limit: int = 2000) -> str:
    s = _timeline_safe_paths(value).strip()
    if limit and len(s) > limit:
        s = s[:max(1, limit - 1)] + "…"
    return s


def _timeline_role_label(role) -> str:
    role = str(role or "").strip()
    if not role:
        return "—"
    label = _ROLE_LABELS.get(role)
    return f"{label}（{role}）" if label and label != role else role


def _timeline_status_text(status) -> str:
    st = str(status or "").strip()
    if not st:
        return "—"
    label = _REVIEW_STATUS_LABELS.get(st, st)
    return f"{label}（{st}）" if label != st else st


def _timeline_counts(items: list) -> tuple:
    review = sum(1 for x in items if x.get("kind") == "review")
    evidence = sum(1 for x in items if x.get("kind") == "evidence_request")
    reaudit = sum(1 for x in items if x.get("kind") == "reaudit")
    return review, evidence, reaudit


def _timeline_summary_text(items: list) -> str:
    review, evidence, reaudit = _timeline_counts(items or [])
    return (f"复核时间线：共 {len(items or [])} 条：复核 {review} 次、补证 {evidence} 次、"
            f"重判 {reaudit} 次；按时间正序，旧结果保留可追溯；每条含理由、角色、"
            f"变更前（before）/ 变更后（after）。")


def _timeline_checklist(raw) -> str:
    try:
        items = json.loads(raw or "[]")
    except Exception:
        return ""
    if not isinstance(items, list):
        return ""
    labels = []
    for x in items[:8]:
        if isinstance(x, dict):
            label = str(x.get("label") or x.get("item") or "").strip()
        else:
            label = str(x or "").strip()
        if label:
            labels.append(_timeline_text(label, 200))
    return "；".join(labels)


def _review_timeline(case_id: str) -> list:
    """复核 / 补证 / 重判统一时间线（只读，按时间正序）。

    与 review / evidence 审计同源：
    - 复核：``manifest_review``（manifest_exec.decide 的完整复核历史）；
    - 补证：``manifest_evidence`` 的申请 / 登记 / 重判生命周期；
    - 操作者与重判时间：``audit_log`` 的 manifest.evidence_* / manifest.reaudited；
    - 对象只显示文件名，材料引用与理由中的内部路径会被脱敏。

    旧结果（重判前）的事件同样保留，避免“只反映新结果”导致复核轨迹丢失。
    """
    from .. import db as _db
    try:
        with _db.session() as c:
            reviews = [dict(r) for r in c.execute(
                "SELECT rv.id AS review_id, rv.result_id, rv.status, rv.reason, "
                "rv.reviewer, rv.role, rv.created_at, rv.rowid AS _ord, "
                "mr.rule_code, mr.object_id, "
                "m.objects_json "
                "FROM manifest_review rv "
                "JOIN manifest_result mr ON mr.id=rv.result_id "
                "JOIN audit_manifest m ON m.id=mr.manifest_id "
                "WHERE m.case_id=? ORDER BY rv.created_at, rv.rowid", (case_id,))]
            evidences = [dict(r) for r in c.execute(
                "SELECT e.id, e.result_id, e.reason, e.status, e.requested_by, "
                "e.created_at, e.fulfilled_at, e.evidence_ref, e.new_result_id, "
                "e.checklist_json, e.rowid AS _ord, "
                "old.rule_code, old.object_id, old.conclusion AS before_conclusion, "
                "new.conclusion AS after_conclusion, "
                "nm.created_at AS reaudit_manifest_at "
                "FROM manifest_evidence e "
                "JOIN manifest_result old ON old.id=e.result_id "
                "JOIN audit_manifest m ON m.id=old.manifest_id "
                "LEFT JOIN manifest_result new ON new.id=e.new_result_id "
                "LEFT JOIN audit_manifest nm ON nm.id=new.manifest_id "
                "WHERE m.case_id=? ORDER BY e.created_at, e.rowid", (case_id,))]
            # 对象名：所有 manifest（含历史重判批次），只显示文件名
            objects = {}
            for m in c.execute("SELECT objects_json FROM audit_manifest WHERE case_id=?", (case_id,)):
                try:
                    for o in json.loads(m["objects_json"] or "[]"):
                        oid = str((o or {}).get("object_id") or "")
                        if oid:
                            objects[oid] = (_timeline_basename((o or {}).get("filename") or "")
                                            or oid)
                except Exception:
                    continue
            # 复核审计：角色/时间兜底，并用于校验时间线顺序
            review_audits = {}
            result_ids = sorted({str(rv.get("result_id") or "") for rv in reviews
                                 if rv.get("result_id")})
            if result_ids:
                try:
                    ph = ",".join("?" for _ in result_ids)
                    for a in c.execute(
                            "SELECT object, actor, after_json, created_at FROM audit_log "
                            f"WHERE action='manifest.decided' AND object IN ({ph}) ORDER BY rowid",
                            result_ids):
                        review_audits.setdefault(str(a["object"] or ""), []).append(dict(a))
                except Exception:
                    logging.getLogger(__name__).debug("timeline review audit lookup skipped",
                                                      exc_info=True)
            # 补证登记 / 重判的操作者与时间（manifest_evidence 不保存这些审计字段）
            evidence_audits = {}
            evidence_ids = [str(e.get("id") or "") for e in evidences if e.get("id")]
            if evidence_ids:
                try:
                    ph = ",".join("?" for _ in evidence_ids)
                    for a in c.execute(
                            "SELECT action, object, actor, created_at FROM audit_log "
                            "WHERE action IN ('manifest.evidence_fulfilled','manifest.reaudited') "
                            f"AND object IN ({ph}) ORDER BY rowid", evidence_ids):
                        evidence_audits.setdefault(
                            (str(a["action"] or ""), str(a["object"] or "")), []).append(dict(a))
                except Exception:
                    logging.getLogger(__name__).debug("timeline evidence audit lookup skipped",
                                                      exc_info=True)
            # 角色：先取复核时记录的角色，再按账号真实角色补齐（补证/重判操作者）
            actor_roles = {}
            for rv in reviews:
                _actor = str(rv.get("reviewer") or "")
                _role = str(rv.get("role") or "")
                if _actor and _role and _actor not in actor_roles:
                    actor_roles[_actor] = _role
            actors = set(actor_roles)
            for e in evidences:
                actors.add(str(e.get("requested_by") or ""))
            for rows in evidence_audits.values():
                for a in rows:
                    actors.add(str(a.get("actor") or ""))
            actors.discard("")
            if actors:
                try:
                    ph = ",".join("?" for _ in actors)
                    for r in c.execute(
                            "SELECT ur.user_id, r.code, r.name FROM user_role ur "
                            "JOIN role r ON r.id=ur.role_id "
                            f"WHERE ur.user_id IN ({ph})", tuple(sorted(actors))):
                        actor_roles.setdefault(
                            str(r["user_id"] or ""),
                            str(r["code"] or r["name"] or ""))
                except Exception:
                    logging.getLogger(__name__).debug("timeline role lookup skipped", exc_info=True)
    except Exception:
        logging.getLogger(__name__).debug("report review timeline skipped", exc_info=True)
        return []

    def _role_for(actor) -> str:
        return _timeline_role_label(actor_roles.get(str(actor or ""), ""))

    def _audit_role(audit: dict) -> str:
        m = re.search(r"(?:^|\|)role=([A-Za-z_]+)",
                      str((audit or {}).get("after_json") or ""))
        return m.group(1) if m else ""

    def _object_of(object_id) -> str:
        oid = str(object_id or "")
        return objects.get(oid, oid)

    # 复核审计按结果配对：用于 created_at / reviewer / role 缺失时的兜底
    review_audit_queue = {k: list(v) for k, v in review_audits.items()}
    for rv in reviews:
        queue = review_audit_queue.get(str(rv.get("result_id") or ""), [])
        audit = {}
        if queue:
            _status = str(rv.get("status") or "")
            idx = next((i for i, a in enumerate(queue)
                        if not _status
                        or str(a.get("after_json") or "").startswith(_status + "|")), 0)
            audit = queue.pop(idx)
        rv["_audit"] = audit

    new_result_ids = {str(e.get("new_result_id") or "") for e in evidences
                      if e.get("new_result_id")}
    events = []
    for rv in reviews:
        _rid = str(rv.get("result_id") or "")
        _audit = rv.get("_audit") or {}
        _actor = str(rv.get("reviewer") or _audit.get("actor") or "")
        _role = str(rv.get("role") or _audit_role(_audit) or actor_roles.get(_actor, "") or "")
        _at = str(rv.get("created_at") or _audit.get("created_at") or "")
        events.append({
            "_kind": "review", "_result": _rid, "_at": _at,
            "_phase": 4 if _rid in new_result_ids else 1,
            "_ord": int(rv.get("_ord") or 0),
            "_id": str(rv.get("review_id") or ""),
            "at": _at,
            "kind": "review",
            "kind_label": _TIMELINE_KIND_LABELS["review"],
            "rule_code": str(rv.get("rule_code") or ""),
            "object": _object_of(rv.get("object_id")),
            "actor": _actor,
            "role": _role,
            "role_label": _timeline_role_label(_role),
            "reason": _timeline_text(rv.get("reason")),
            "note": "",
            "_after_status": str(rv.get("status") or ""),
            "result_id": _rid,
        })
    for e in evidences:
        _rid = str(e.get("result_id") or "")
        _eid = str(e.get("id") or "")
        _rule = str(e.get("rule_code") or "")
        _obj = _object_of(e.get("object_id"))
        _req_actor = str(e.get("requested_by") or "")
        _req_at = str(e.get("created_at") or "")
        _eff = _timeline_safe_ref(e.get("evidence_ref"))
        _raw_reason = str(e.get("reason") or "")
        _raw_ref = str(e.get("evidence_ref") or "")
        if _raw_ref and _raw_ref in _raw_reason:
            # 理由里完整引用了补证材料路径时，先替换为文件名，避免空格等截断后残留目录
            _raw_reason = _raw_reason.replace(_raw_ref, _eff or "补充材料")
        _req_reason = _timeline_text(_raw_reason)
        _check = _timeline_checklist(e.get("checklist_json"))
        events.append({
            "_kind": "evidence_request", "_result": _rid, "_at": _req_at,
            "_phase": 0, "_ord": int(e.get("_ord") or 0), "_id": _eid + "#req",
            "at": _req_at,
            "kind": "evidence_request",
            "kind_label": _TIMELINE_KIND_LABELS["evidence_request"],
            "rule_code": _rule,
            "object": _obj,
            "actor": _req_actor,
            "role": "",
            "role_label": _role_for(_req_actor),
            "reason": _req_reason,
            "note": ("补证清单：" + _check) if _check else "",
            "result_id": _rid,
        })
        _fulfilled = (bool(e.get("fulfilled_at"))
                      or str(e.get("status") or "") in ("fulfilled", "reaudited"))
        if _fulfilled:
            _fa_rows = evidence_audits.get(("manifest.evidence_fulfilled", _eid)) or []
            _fa = _fa_rows[0] if _fa_rows else {}
            _at = str(e.get("fulfilled_at") or "") or _req_at
            _actor = str(_fa.get("actor") or "") or _req_actor
            events.append({
                "_kind": "evidence_fulfill", "_result": _rid, "_at": _at,
                "_phase": 2, "_ord": int(e.get("_ord") or 0), "_id": _eid + "#fulfill",
                "at": _at,
                "kind": "evidence_fulfill",
                "kind_label": _TIMELINE_KIND_LABELS["evidence_fulfill"],
                "rule_code": _rule,
                "object": _obj,
                "actor": _actor,
                "role": "",
                "role_label": _role_for(_actor),
                "reason": "补证材料已登记" + (f"：{_eff}" if _eff else ""),
                "note": "补证登记后需重新执行 D4 才能改判",
                "result_id": _rid,
            })
        if e.get("new_result_id") or str(e.get("status") or "") == "reaudited":
            _ra_rows = evidence_audits.get(("manifest.reaudited", _eid)) or []
            _ra = _ra_rows[-1] if _ra_rows else {}
            _at = (str(_ra.get("created_at") or "")
                   or str(e.get("reaudit_manifest_at") or "")
                   or str(e.get("fulfilled_at") or "") or _req_at)
            _actor = str(_ra.get("actor") or "") or _req_actor
            _before_c = _timeline_text(e.get("before_conclusion")) or "—"
            _after_c = _timeline_text(e.get("after_conclusion")) or "待重判"
            _note = "补证材料：" + (_eff or "—") + "；新结果待复核（pending）"
            events.append({
                "_kind": "reaudit", "_result": _rid, "_at": _at,
                "_phase": 3, "_ord": int(e.get("_ord") or 0), "_id": _eid + "#reaudit",
                "at": _at,
                "kind": "reaudit",
                "kind_label": _TIMELINE_KIND_LABELS["reaudit"],
                "rule_code": _rule,
                "object": _obj,
                "actor": _actor,
                "role": "",
                "role_label": _role_for(_actor),
                "reason": "补证后重判" + (f"（依据：{_timeline_text(_req_reason, 120)}）"
                                           if _req_reason else ""),
                "note": _note,
                "conclusion_before": _before_c,
                "conclusion_after": _after_c,
                "result_id": _rid,
            })

    # 逐结果还原复核状态：复核/补证/登记/重判按时间推进，before=事件发生前状态
    by_result = {}
    for ev in events:
        by_result.setdefault(ev["_result"], []).append(ev)
    for evs in by_result.values():
        evs.sort(key=lambda x: (x["_at"], x["_phase"], x["_ord"], x["_id"]))
        state = "pending"
        for ev in evs:
            ev["status_before"] = state
            kind = ev["_kind"]
            if kind == "review":
                state = ev["_after_status"]
                ev["status_after"] = state
                ev["before"] = _timeline_status_text(ev["status_before"])
                ev["after"] = _timeline_status_text(state)
            elif kind == "evidence_request":
                state = "need_evidence"
                ev["status_after"] = state
                ev["before"] = _timeline_status_text(ev["status_before"])
                ev["after"] = _timeline_status_text(state)
            elif kind == "evidence_fulfill":
                state = "pending"
                ev["status_after"] = state
                ev["before"] = _timeline_status_text(ev["status_before"])
                ev["after"] = "待重判（pending）"
            elif kind == "reaudit":
                ev["status_after"] = "pending"
                ev["before"] = ev.get("conclusion_before") or "—"
                ev["after"] = ev.get("conclusion_after") or "待重判"
                state = "pending"
            else:
                ev["status_after"] = state
                ev["before"] = _timeline_status_text(ev["status_before"])
                ev["after"] = _timeline_status_text(state)

    events.sort(key=lambda x: (x["_at"], x["_phase"], x["_ord"], x["_id"]))
    out = []
    for ev in events:
        item = {k: ev.get(k) for k in (
            "at", "kind", "kind_label", "rule_code", "object", "actor", "role",
            "role_label", "before", "after", "reason", "note",
            "status_before", "status_after", "result_id")}
        if "conclusion_before" in ev:
            item["conclusion_before"] = ev.get("conclusion_before")
            item["conclusion_after"] = ev.get("conclusion_after")
        out.append(item)
    return out


def _timeline_html(items: list) -> str:
    head = "<h2>复核 / 补证 / 重判时间线（含复核历史与补证重判历史）</h2>"
    items = items or []
    if not items:
        return head + '<p class="timeline-empty">暂无复核 / 补证 / 重判记录（复核时间线为空）</p>'
    parts = []
    for x in items:
        reason = _h(x.get("reason") or "—")
        if x.get("note"):
            reason += f'<br><span class="timeline-note">{_h(x.get("note"))}</span>'
        rule_obj = _h(x.get("rule_code") or "—")
        if x.get("object"):
            rule_obj += f'<br><span class="timeline-object">{_h(x.get("object"))}</span>'
        parts.append(
            f'<tr class="timeline-row"><td>{_h(x.get("at") or "—")}</td>'
            f'<td>{_h(x.get("kind_label") or "")}</td>'
            f'<td>{rule_obj}</td>'
            f'<td>{_h(x.get("actor") or "—")}</td>'
            f'<td>{_h(x.get("role_label") or "—")}</td>'
            f'<td>{_h(x.get("before") or "—")}</td>'
            f'<td>{_h(x.get("after") or "—")}</td>'
            f'<td>{reason}</td></tr>')
    return (head + f'<p class="timeline-summary">{_h(_timeline_summary_text(items))}</p>'
            '<table class="report-timeline"><tr><th>时间</th><th>类型</th>'
            '<th>规则 / 对象</th><th>操作人 / 复核人</th><th>角色</th>'
            '<th>变更前</th><th>变更后</th><th>理由 / 说明</th></tr>'
            + "".join(parts) + "</table>")


def _docx_add_timeline(doc, items: list) -> None:
    doc.add_heading("四、复核 / 补证 / 重判时间线（含复核历史与补证重判历史）", level=1)
    items = items or []
    if not items:
        doc.add_paragraph("暂无复核 / 补证 / 重判记录（复核时间线为空）")
        return
    doc.add_paragraph(_timeline_summary_text(items))
    table = doc.add_table(rows=1, cols=8)
    table.style = "Light Grid Accent 1"
    for i, title in enumerate(["时间", "类型", "规则 / 对象", "操作人 / 复核人", "角色",
                               "变更前", "变更后", "理由 / 说明"]):
        table.rows[0].cells[i].text = title
    for x in items:
        row = table.add_row().cells
        row[0].text = str(x.get("at") or "—")
        row[1].text = str(x.get("kind_label") or "")
        row[2].text = str(x.get("rule_code") or "—")
        if x.get("object"):
            row[2].text += "\n" + str(x.get("object"))
        row[3].text = str(x.get("actor") or "—")
        row[4].text = str(x.get("role_label") or "—")
        row[5].text = str(x.get("before") or "—")
        row[6].text = str(x.get("after") or "—")
        reason = str(x.get("reason") or "—")
        if x.get("note"):
            reason += "\n" + str(x.get("note"))
        row[7].text = reason


def _exec_contract_note_html(case_id: str) -> str:
    """L52 ④/②：报告里显式标注执行口径（legacy-only 编排 / legacy 无冻结清单）。

    只做展示标注，不改报告判定；异常时返回空串（不阻断报告渲染）。
    """
    try:
        case = R.cases.get(case_id) or {}
        with db.session() as c:
            row = c.execute(
                "SELECT trace_json, manifest_id FROM audit_run WHERE case_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
        trace = {}
        try:
            trace = json.loads((row["trace_json"] if row else "") or "{}") or {}
        except Exception:
            trace = {}
        _style = ('style="background:#FFF7E8;border-left:3px solid #D97706;'
                  'padding:8px 12px;color:#92400E;font-size:13px"')
        if trace.get("legacy_orchestrator"):
            return (f'<p {_style}>执行口径（L52）：本次审核使用 legacy-only 编排'
                    '（RULEPROOF_AUDIT_DAG=0），不属于唯一 manifest 执行出口主链口径；'
                    '本报告结论不可与主链报告直接互比。</p>')
        _mid = str((row["manifest_id"] if row else "") or "").strip()
        if str(case.get("compat_mode") or "") == "legacy" and row is not None and not _mid:
            return (f'<p {_style}>执行口径（L52）：legacy 审核链路无冻结清单（manifest_id '
                    '为空），本报告按 fail-closed 口径不得作为正式签发依据。</p>')
    except Exception:  # noqa: BLE001 - 标注失败不阻断报告
        logging.getLogger(__name__).debug(
            "report exec contract note skipped case=%s", case_id, exc_info=True)
    return ""


def build_report_html(case_id: str, actor: str = "", role: str = "",
                      render_stamp: str = "") -> str:
    """渲染 HTML 报告。

    L122：``render_stamp`` 为已签发报告冻结的正文时间戳（默认取当前分钟）；
    签发时用它冻结正文，DOCX 导出时用它复算“当前正文 == 冻结正文”。
    """
    _strict_export_access(case_id, actor, role)
    cr = review.case_report(case_id)
    if not cr:
        return "<html><body>未找到案例</body></html>"
    _pn = _platform_name_for_case(case_id)
    _base_cats = cr.get("categories") or {}
    _cats = _augment_categories(_base_cats, _manifest_expected_missing(case_id))
    s = _report_summary_view(cr["summary"], _cats, _base_cats)
    _mid, _mrows = _manifest_rows(case_id)
    # T-161 三区分层：按区统计（只标记/展示，不改判定；RULEPROOF_ZONE_REPORT=0 时为空）
    _zonehtml = _zone_html(_zone_section_view(case_id, cr.get("findings") or [], _mrows))
    _taxonomy = _taxonomy_html(_cats, _mrows)
    def _review_cell(f):
        st = str(f.get("status") or "pending")
        label = {"pending": "待复核", "confirmed": "已确认", "false_positive": "误报",
                 "needs_evidence": "需补证"}.get(st, st)
        return label
    _links, _row_links = _ledger_links(cr["findings"], _mrows)
    _fparts = []
    for f in cr["findings"]:
        _fid = str(f.get("id") or "")
        _lk = _links.get(_fid)
        if _lk:
            _attrs = f' id="fd-{_h(_fid)}" class="finding-row ledger-mirror"'
            _ref = (f'<span class="badge-ledger">台账内 · 已计入</span> '
                    f'<a href="#lg-{_h(_fid)}">台账第 {_lk["no"]} 行</a>'
                    f'<br><code class="finding-id">{_h(_fid)}</code>')
            _srcp = _h(_source_pointer(_lk.get("row")))
            _loc = (f'<a href="#lg-{_h(_fid)}">见台账第 {_lk["no"]} 行'
                    f'（明细不重复列示{("；" + _srcp) if _srcp else ""}）</a>')
        else:
            _attrs = ' class="finding-row"'
            _ref = "—"
            _loc = _h("；".join(a.get("locator", "") for a in f.get("evidence", [])))
        _fparts.append(
            f'<tr{_attrs}><td>{_sev(f.get("severity"))}</td><td>{_h(f["title"])}</td>'
            f'<td>{_h(f["rule_code"])} {_h(f.get("rule_name", ""))}</td>'
            f'<td>{_ref}</td><td>{_loc}</td>'
            f'<td>{_review_cell(f)}</td>'
            f'<td>{_h(str(f.get("reviewed_by") or f.get("reviewer") or ""))}</td>'
            f'<td>{_h(str(f.get("reviewed_at") or ""))}</td>'
            f'<td>{_h(_timeline_text(f.get("review_reason") or f.get("review_note") or ""))}</td>'
            f'<td>{_h(f.get("suggestion", ""))}</td></tr>')
    rows = "".join(_fparts)
    _dnote = (f'<p class="dedupe-note"><b>去重说明</b>：{_h(_dedupe_text(cr["findings"], _links))}</p>'
              if _links else "")
    # P1：报告必须能追溯本次运行的规则/模型/文件快照
    snap = {}
    try:
        from . import manifest as _manifest
        snap = _manifest.load(case_id, cr["case"].get("last_run_id") or "") or {}
    except Exception:
        snap = {}
    _mhtml = ""
    if _mrows:
        _parts, _last_rule = [], None
        for x in _mrows:
            _rule = str(x.get('rule_code') or '')
            if _rule != _last_rule:
                _dt = str(x.get('decision_table') or '')
                _label = f"规则 {_rule}" + (f" · 决策表 {_dt}" if _dt else "")
                _parts.append(f'<tr><td colspan="14"><b>{_h(_label)}</b></td></tr>')
                _last_rule = _rule
            _fid = _row_links.get((str(x.get('id') or ''), str(x.get('sub_id') or '')))
            _row_attrs = f' id="lg-{_h(_fid)}" class="ledger-row ledger-mirror"' if _fid else ' class="ledger-row"'
            _fref = (f'<a href="#fd-{_h(_fid)}"><code>{_h(_fid)}</code></a>' if _fid else "—")
            _parts.append(
                f"<tr{_row_attrs}><td>{_h(_rule)}</td><td>{_h(str(x.get('object') or ''))}</td>"
                f"<td>{_h(str(x.get('sub_id') or ''))}</td>"
                f"<td>{_h(str(x.get('sub_status') or ''))}</td>"
                f"<td>{_h(str(x.get('conclusion') or ''))}</td>"
                f"<td>{_h(str(x.get('sub_quote') or x.get('sub_detail') or ''))}</td>"
                f"<td>{_h(str(x.get('execution') or ''))}</td>"
                f"<td>{_h(str(x.get('review_status') or 'pending'))}</td>"
                f"<td>{_h(_timeline_text(x.get('review_reason')))}</td>"
                f"<td>{_h(str(x.get('decision_table') or ''))}{('/行'+str(x.get('hit_row'))) if x.get('hit_row') else ''}</td>"
                f"<td>{_h(_source_cell(x))}</td>"
                f"<td>{_h(str(x.get('strategy') or ''))}</td>"
                f"<td>{_h(str(x.get('tool_trace') or {}))}</td>"
                f"<td>{_fref}</td></tr>")
        _mr = "".join(_parts)
        _mhtml = (f"<h2>规则执行台账（manifest {_h(_mid)}）</h2><table>"
                  "<tr><th>规则</th><th>对象</th><th>子要求</th><th>子结论</th><th>规则结论</th><th>证据</th><th>执行</th><th>复核</th><th>复核理由</th><th>决策表/行</th><th>原文坐标</th><th>D3/D5 策略</th><th>计算轨迹</th><th>发现ID</th></tr>"
                  f"{_mr}</table>")
    _tline_html = _timeline_html(_review_timeline(case_id))
    _unk = _unknown_rows(case_id)
    _pg = _parse_gaps(case_id)
    _pghtml = ""
    if _pg:
        _pr = "".join(f"<tr><td>{_h(str(x.get('filename') or ''))}</td><td>{_h(str(x.get('parse_status') or ''))}</td>"
                      f"<td>{_h(str(x.get('parse_summary') or ''))}</td></tr>" for x in _pg)
        _pghtml = (f"<h2>解析缺口附录（{len(_pg)} 份）</h2><table>"
                   "<tr><th>文件</th><th>状态</th><th>说明</th></tr>" + _pr + "</table>")
    _uhtml = ""
    if _unk:
        _ur = "".join(f"<tr><td>{_h(str(x.get('point_id') or ''))}</td><td>{_h(str(x.get('title') or ''))}</td>"
                      f"<td>{_h(str(x.get('reason') or ''))}</td>"
                      f"<td>{_h(str(x.get('_class') or ''))}</td></tr>" for x in _unk)
        _uhtml = (f"<h2>弃权/未执行附录（{len(_unk)} 条）</h2><table>"
                  "<tr><th>点位/规则</th><th>名称</th><th>原因</th><th>分类</th></tr>" + _ur + "</table>")
    _stale_html = (f'<p style="color:#B45309"><b>注意：{s.get("point_stale_count")} 条发现基于旧点位判据，'
                   f'点位库已更新，需复核或重跑。</b></p>') if s.get("point_stale_count") else ""
    _mi_html = _mi_notice_html(case_id)
    _manifest_stale_html_text = _manifest_stale_html(case_id)
    _model = snap.get("model")
    _model_name = _model.get("name") if isinstance(_model, dict) else _model
    _frozen = _frozen_manifest_snapshot(case_id)
    if _frozen:
        _ruleset_text = (f"冻结清单 {int(_frozen.get('items') or 0)} 条 / "
                         f"规则 {int(_frozen.get('rules') or 0)} 条"
                         f"（manifest {_frozen.get('manifest_id') or ''}"
                         f" · hash {_frozen.get('hash') or ''}）")
    else:
        _ruleset_text = "未找到本次审核的冻结清单（旧批次/旧库），不展示库内 published 总数"
    _snap_html = (
        f"<h2>运行版本快照</h2><table>"
        f"<tr><th>run_id</th><td>{_h(cr['case'].get('last_run_id') or '')}</td></tr>"
        f"<tr><th>模型</th><td>{_h(str(_model_name or ''))}</td></tr>"
        f"<tr><th>规则集</th><td>{_h(_ruleset_text)}</td></tr>"
        f"<tr><th>当前发布规则库（非本次冻结）</th><td>{_h(str(snap.get('rules') or ''))}</td></tr>"
        f"<tr><th>参数哈希</th><td>{_h(str(snap.get('params_sha') or ''))}</td></tr>"
        f"<tr><th>本体哈希</th><td>{_h(str(snap.get('ontology_sha') or ''))}</td></tr>"
        f"<tr><th>提示词版本</th><td>{_h(str(snap.get('prompt_version') or ''))}</td></tr>"
        f"<tr><th>文件数</th><td>{len(snap.get('files') or [])}</td></tr></table>")
    _chain = _chain_html(_mrows, _cats)
    _stab_html = _stability_html(case_id)
    _vs_html = _version_snapshot_html(case_id)
    _um_rows = _unknown_missing_rows(case_id, _mrows, _cats)
    _umhtml = _unknown_missing_html(case_id, _mrows, _cats, rows=_um_rows)
    _exec_contract_note = _exec_contract_note_html(case_id)
    _render_stamp = render_stamp or time.strftime("%Y-%m-%d %H:%M")
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>{_h(_pn)} · 审核报告</title>
<style>body{{font-family:-apple-system,'PingFang SC',sans-serif;max-width:960px;margin:24px auto;padding:0 20px;color:#1F2329}}
table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{border:1px solid #DEE0E3;padding:8px 10px;text-align:left}}th{{background:#F5F6F7}}
a{{color:#245BDB;text-decoration:none}}a:hover{{text-decoration:underline}}
.badge-ledger{{display:inline-block;padding:1px 6px;border-radius:4px;background:#E8F3FF;color:#1D4ED8;font-size:12px;white-space:nowrap}}
.finding-id{{font-size:11px;color:#8F959E}}
.dedupe-note{{background:#F7F8FA;border-left:3px solid #3370FF;padding:8px 12px;color:#4E5969;font-size:13px}}
.stability-block{{background:#FEF0F0;border-left:3px solid #D92D20;padding:8px 12px;color:#7A271A;font-size:13px}}
.stability-ok{{background:#ECFDF3;border-left:3px solid #12B76A;padding:8px 12px;color:#054F31;font-size:13px}}
.stability-wait{{background:#FFFAEB;border-left:3px solid #F79009;padding:8px 12px;color:#7A2E0E;font-size:13px}}
.report-stability td,.report-stability th{{font-size:12px;vertical-align:top}}
.snapshot-ok{{background:#ECFDF3;border-left:3px solid #12B76A;padding:8px 12px;color:#054F31;font-size:13px}}
.snapshot-diff{{background:#FFFAEB;border-left:3px solid #F79009;padding:8px 12px;color:#7A2E0E;font-size:13px}}
.snapshot-wait{{background:#F7F8FA;border-left:3px solid #98A2B3;padding:8px 12px;color:#475467;font-size:13px}}
.report-snapshot td,.report-snapshot th{{font-size:12px;vertical-align:top}}
.report-chain td,.report-taxonomy-detail td,.report-unknown td{{font-size:12px;vertical-align:top}}
.chain-object{{color:#8F959E;font-size:12px}}
.timeline-object,.timeline-note{{color:#8F959E;font-size:12px}}
.timeline-summary,.timeline-empty{{color:#4E5969;font-size:13px}}
.report-timeline td{{font-size:12px;vertical-align:top}}
.stale-warn{{background:#FFF7E8;border-left:3px solid #D97706;padding:8px 12px;color:#92400E;font-size:13px}}
.mi-truncation-warn{{background:#FEF0F0;border-left:3px solid #D92D20;padding:8px 12px;color:#7A271A;font-size:13px}}
.report-mi-truncation td,.report-mi-truncation th{{font-size:12px;vertical-align:top}}
.stale-versions{{color:#4E5969;font-size:13px}}
.report-stale td,.report-stale th{{font-size:12px;vertical-align:top}}
tr:target{{background:#FFF7E8}}</style></head>
<body><h1>{_h(_pn)} · 审核报告</h1>
<p><b>结论：{_h(s["status"])}</b>　严重 {s["critical_count"]} 项 / 一般 {s["warning_count"]} 项 / 提示 {s.get("suspected_count", 0)} 项</p>
<p><b>{_h(_taxonomy_brief(_cats))}</b></p>
<p>案例：{_h(cr["case"]["name"])}　生成时间：{_render_stamp}</p>{_exec_contract_note}{_taxonomy}{_stale_html}{_mi_html}{_manifest_stale_html_text}{_dnote}{_zonehtml}
<h2>发现清单</h2><table><tr><th>级别</th><th>发现</th><th>规则</th><th>台账</th><th>证据定位</th><th>复核</th><th>复核人</th><th>时间</th><th>理由</th><th>建议</th></tr>{rows}</table>{_chain}{_mhtml}{_tline_html}{_uhtml}{_umhtml}{_stab_html}{_pghtml}{_snap_html}{_vs_html}
<p style="color:#8F959E;font-size:12px;margin-top:24px">本报告由 {_h(_pn)} 自动生成，仅输出差异/缺口/待人工确认项，不构成“合规/不合规”结论；最终结论以具备资质的专业人员复核为准。</p>
</body></html>"""


# ---------------- 报告生命周期：状态 / 生成记录 ----------------
def status(case_id: str, actor: str = "", role: str = "") -> dict:
    """报告状态：是否可生成、待复核数、已生成版本、是否需要重新生成。

    业务管理员可读状态但 ``can_generate`` 恒为 False；审核员仅本人案例可见。
    """
    access = _strict_view_access(case_id, actor, role)
    if access is not None and not access.get("ok"):
        return {"case_id": case_id, "can_generate": False,
                "reasons": [access.get("message") or "无权查看报告状态"],
                "stats": {}, "latest": None, "generated": False, "stale": False,
                "pdf_available": False,
                "error": access.get("message") or "无权查看报告状态",
                "code": access.get("code") or "forbidden",
                "access": {k: access.get(k) for k in
                           ("actor", "role", "read_only", "can_review",
                            "can_export_report", "identity_verified")}}
    gate = check_gate(case_id)
    try:
        rows = R.reports.list("case_id=?", (case_id,), order="exported_at DESC")
        latest = dict(rows[0]) if rows else None
    except Exception:
        latest = None
    stale = False
    if latest:
        try:
            case = R.cases.get(case_id) or {}
            _sum = json.loads(latest.get("summary_json") or "{}")
            if _sum.get("_run_id") and _sum.get("_run_id") != case.get("last_run_id"):
                stale = True
            if str(case.get("last_audit_at") or "") >= str(latest.get("exported_at") or ""):
                # 同一秒也可能发生重跑；run_id 不同已在上方判定
                stale = stale or str(case.get("last_audit_at") or "") > str(latest.get("exported_at") or "")
        except Exception:
            logging.getLogger(__name__).debug("stale audit compare skipped", exc_info=True)
        try:
            from .. import db
            with db.session() as c:
                row = c.execute(
                    "SELECT MAX(d.created_at) FROM decision d JOIN finding f ON f.id=d.finding_id "
                    "WHERE f.case_id=?", (case_id,)).fetchone()
            stale = stale or bool(row and row[0] and str(row[0]) > str(latest.get("exported_at") or ""))
        except Exception:
            logging.getLogger(__name__).debug("stale decision compare skipped", exc_info=True)
    reasons = list(gate.get("reasons") or [])
    can_export = True
    access_out = None
    if access is not None:
        access_out = {k: access.get(k) for k in
                      ("actor", "role", "read_only", "can_review",
                       "can_export_report", "resolved", "identity_verified")}
        can_export = bool(access.get("can_export_report"))
        if not can_export:
            reasons.append("业务管理员只读：不能复核或导出报告")
    return {"case_id": case_id, "can_generate": bool(gate.get("ok")) and can_export,
            "can_export_report": bool(can_export and gate.get("ok")),
            "reasons": reasons, "stats": gate.get("stats") or {},
            "categories": gate.get("categories") or {},
            "report_category": (gate.get("categories") or {}).get("category") or "",
            "report_category_label": (gate.get("categories") or {}).get("label") or "",
            "latest": latest, "generated": bool(latest), "stale": stale,
            # L93：报告签发事实（0 行显式 available=False，不掩盖“0 报告”）
            "issuance": issuance_view(case_id),
            "pdf_available": pdf_available(), "access": access_out,
            # P0-稳定性/证据：报告状态直接暴露投票/翻转与证据门禁结果（与门禁同源）
            "stability": gate.get("stability") or {},
            "evidence_gate": gate.get("evidence_gate") or {},
            "version_snapshot": gate.get("version_snapshot") or {}}


# ---------------------------------------------------------------------------
# L93（2026-11-24）：报告签发模型（生成人/时间、签发人/时间、内容 hash、导出回执）
#
# 缺陷（L90 GP03）：report 表 0 行、无 created_by/signed_by/content_hash，
# signatures_json 从无写入方；报告“有流程无签批单据”。
# 修复口径：
#   * generate  → status=generated + created_by/created_at + content_hash
#                 （hash 覆盖 case_id/version/summary_json/disclaimer 的规范化 JSON）；
#   * sign      → status=signed + signed_by/signed_at + signatures_json；
#                 签前重算 content_hash，不一致拒绝（防签发后内容被改）；
#   * export    → status=exported + exported_at/exported_by/exported_hash（导出内容 hash）；
#                 无 report 行时落“导出回执”行（不伪装成已生成报告）；
#   * report_gate 只读事实（advisory，不阻断）；0 报告行由 docmodel_health_report 显式报告。
# ---------------------------------------------------------------------------
def _report_content_hash(case_id: str, version: str, summary_obj, disclaimer: str) -> str:
    import hashlib
    payload = json.dumps({"case_id": str(case_id or ""), "version": str(version or ""),
                          "summary": summary_obj or {}, "disclaimer": str(disclaimer or "")},
                         ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# L122（2026-11-25）：签发正文锁定（signed content lock）
#
# 外部证据 /tmp/build51_deep_review/deep_sign.py 复现的 P0/P1 缺陷：
#   生成内容 hash 只覆盖 case_id+version+summary_json+disclaimer，不含渲染后的
#   报告正文；签发时也未冻结正文。于是「先签发、后改 case name / 复核状态」，
#   再导出会把**新的** HTML/DOCX 交给使用方，而 content_hash 仍是旧值——
#   签发失去“内容不可变”语义（同 report ID 无法重现签发内容）。
# 修复口径（开关 RULEPROOF_REPORT_SIGNED_CONTENT_LOCK 默认 1，=0 回退旧行为）：
#   * sign  → 先按旧口径校验生成阶段 content_hash（防摘要被改后签发，兼容 L93/L94），
#             再渲染并冻结「当前 HTML 正文」，content_hash=sha256(冻结正文 UTF-8 字节)，
#             快照写入 signatures_json.snapshot（gzip+base64 压缩正文，避免报告列表/
#             状态接口把整篇正文放大；body_sha256 与 content_hash 互为复算）；
#   * export（已签发）→ HTML 直接返回冻结正文；DOCX 无法由 HTML 快照直接重建，
#             仅当「用冻结时间戳复算的当前正文 hash == 冻结正文 hash」才允许从当前
#             同源状态重建 DOCX，否则拒绝 report_stale/content_hash_mismatch
#             （不得静默输出新正文）；导出回执 hash 始终 = 实际返回字节 sha256；
#   * verify_content_hash → 有快照时校验快照（正文 sha256/字节数/生成阶段 hash），
#             无快照时保持 L94 旧口径（历史行/开关=0 回退）。
# ---------------------------------------------------------------------------
_SIGNED_BODY_SCHEMA = "l122.signed_body.v1"
_SIGNED_BODY_FORMAT = "html"
_SIGNED_BODY_ENCODING = "gzip+base64"
_SIGNED_CONTENT_LOCK_ENV = "RULEPROOF_REPORT_SIGNED_CONTENT_LOCK"
_OFF_VALUES = ("0", "false", "off", "no", "disabled")


def signed_content_lock_enabled() -> bool:
    """L122 开关：``RULEPROOF_REPORT_SIGNED_CONTENT_LOCK`` 默认 1；=0 回退旧行为。

    =0 时 sign 不冻结正文（content_hash 仍为生成阶段口径），export 按当前正文
    重新渲染——即 L94 之前的行为（回退杆，不删除代码）。
    """
    raw = os.environ.get(_SIGNED_CONTENT_LOCK_ENV)
    if raw is None or not str(raw).strip():
        return True
    return str(raw).strip().lower() not in _OFF_VALUES


def _sha256_bytes(raw: bytes) -> str:
    import hashlib
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _sha256_text(text: str) -> str:
    return _sha256_bytes(str(text).encode("utf-8"))


def pack_signed_body(text: str) -> dict:
    """把冻结正文压成可写入 signatures_json 的紧凑快照（gzip+base64）。

    正文本身是 HTML 文本；压缩只为避免 /reports 列表与 /report-status 返回整篇
    正文（一次几 KB→几十 KB 的放大），字段仍可无损还原并复算 sha256。
    """
    import base64
    import gzip
    raw = str(text).encode("utf-8")
    return {"body_encoding": _SIGNED_BODY_ENCODING,
            "body_gzip_b64": base64.b64encode(gzip.compress(raw, 6)).decode("ascii"),
            "body_bytes": len(raw),
            "body_sha256": _sha256_bytes(raw)}


def unpack_signed_body(snapshot: dict) -> str | None:
    """还原签发时冻结的正文；缺失/损坏返回 None（不伪造正文，不静默降级）。"""
    if not isinstance(snapshot, dict):
        return None
    payload = snapshot.get("body_gzip_b64")
    try:
        if (str(snapshot.get("body_encoding") or "") == _SIGNED_BODY_ENCODING
                and isinstance(payload, str)):
            import base64
            import gzip
            return gzip.decompress(base64.b64decode(payload.encode("ascii"))).decode("utf-8")
        # 兼容明文快照（人工修复/后续迁移格式）；不改变已落库行的 hash 口径
        if isinstance(snapshot.get("body"), str):
            return snapshot["body"]
    except Exception:  # noqa: BLE001 —— 快照损坏按“不可信”处理，日志可见
        logging.getLogger(__name__).warning("L122 signed body unpack failed", exc_info=True)
    return None


def signed_body_snapshot(report_row: dict) -> dict | None:
    """读取 report 行 signatures_json 中的 L122 冻结正文快照；无/损坏返回 None。"""
    try:
        sig = json.loads(str((report_row or {}).get("signatures_json") or "") or "{}")
    except Exception:  # noqa: BLE001 —— 签发单据损坏 → 无快照（上层按旧口径/拒绝）
        return None
    if not isinstance(sig, dict):
        return None
    snap = sig.get("snapshot")
    if not isinstance(snap, dict):
        return None
    if str(snap.get("schema") or "") != _SIGNED_BODY_SCHEMA:
        return None
    return snap


def _legacy_content_hash_matches(report_row: dict) -> bool | None:
    """L94 旧口径：case_id+version+summary_json+disclaimer 重算比对。"""
    row = dict(report_row or {})
    stored = str(row.get("content_hash") or "")
    if not stored:
        return None
    try:
        _sum = json.loads(row.get("summary_json") or "{}")
    except Exception:  # noqa: BLE001 —— 摘要损坏视为内容不可信
        return False
    expect = _report_content_hash(str(row.get("case_id") or ""),
                                  row.get("version") or "", _sum,
                                  row.get("disclaimer") or "")
    return stored == expect


def _signed_body_target(case_id: str, report_id: str = "") -> dict | None:
    """L122：已签发报告「冻结正文」目标（仅开关开启 + 最新生成行/指定行 + 有快照）。

    返回 ``{row, snapshot, body, content_hash, render_stamp}``；快照与 content_hash
    不一致（被篡改）→ content_hash_mismatch，不返回正文。
    """
    if not signed_content_lock_enabled():
        return None
    if report_id:
        row = R.reports.get(report_id) or {}
        if not row or str(row.get("case_id") or "") != str(case_id):
            return None
        row = dict(row)
    else:
        rows = _generated_report_rows(case_id)
        if not rows:
            return None
        row = dict(rows[0])
    if not (str(row.get("signed_by") or "").strip()
            and str(row.get("signed_at") or "").strip()):
        return None
    snap = signed_body_snapshot(row)
    if snap is None:
        return None
    body = unpack_signed_body(snap)
    stored = str(row.get("content_hash") or "")
    if body is None or not stored or verify_content_hash(row) is not True:
        _ge = ReportGateError(
            "已签发报告的冻结正文快照校验失败（正文/内容 hash 不一致），拒绝导出",
            ["[content_hash_mismatch] signed snapshot 不可复算"])
        _ge.code = "content_hash_mismatch"
        raise _ge
    return {"row": row, "snapshot": snap, "body": body,
            "content_hash": stored,
            "render_stamp": str(snap.get("render_stamp") or "")}


def _report_rows(case_id: str) -> list:
    """报告行（按插入顺序倒序：最新生成/回执行在前）。

    L94：改用 rowid 倒序而非 exported_at（旧排序会把历史导出回执行误当最新报告，
    多版本场景签发错行）；导出回执行由 :func:`_is_export_receipt` 在签发行选择时排除。
    """
    try:
        return R.reports.list("case_id=?", (case_id,), order="rowid DESC")
    except Exception:  # noqa: BLE001 —— 读取失败按 0 行处理（上层显式报告）
        logging.getLogger(__name__).warning("report rows read failed case=%s",
                                            case_id, exc_info=True)
        return []


def _is_export_receipt(row: dict) -> bool:
    """L93 的“导出回执行”（未生成即导出的可追溯记录）不是可签发报告。"""
    try:
        return str((json.loads((row or {}).get("summary_json") or "{}")
                    or {}).get("_kind") or "") == "export_receipt"
    except Exception:  # noqa: BLE001
        return False


def _generated_report_rows(case_id: str) -> list:
    """真实“生成的报告行”（排除导出回执行）；最新在前。"""
    return [dict(r) for r in _report_rows(case_id) if not _is_export_receipt(r)]


def _target_report_row(case_id: str, report_id: str = "") -> dict:
    """L94：签发/导出目标行（指定 id 必须属于本 case，且必须是当前最新**生成**报告行）。

    最新判定：``_generated_report_rows`` 首行（rowid 倒序，排除导出回执行）。对历史
    版本签发/导出会造成“同一项目两份生效单据”的歧义，故返回 report_stale（业务拒绝）。
    """
    rows = _generated_report_rows(case_id)
    if report_id:
        target = R.reports.get(report_id) or {}
        if not target:
            _ge = ReportGateError("报告不存在", ["[report_not_found] 指定 report_id 不存在"])
            _ge.code = "report_not_found"
            raise _ge
        if str(target.get("case_id") or "") != str(case_id):
            _ge = ReportGateError("报告不属于该项目", ["[report_not_found] report.case_id 不匹配"])
            _ge.code = "report_not_found"
            raise _ge
        if _is_export_receipt(target):
            _ge = ReportGateError("导出回执行不是正式报告，不能签发/按报告导出", [
                "[report_not_generated] 该行 summary_json._kind=export_receipt"])
            _ge.code = "report_not_generated"
            raise _ge
        latest = dict(rows[0]) if rows else {}
        if latest and str(latest.get("id") or "") != str(report_id):
            _ge = ReportGateError(
                "该报告不是最新版本（" + str(latest.get("version") or latest.get("id") or "")
                + "），请对最新报告签发/导出",
                ["[report_stale] target=" + str(report_id)
                 + " latest=" + str(latest.get("id"))])
            _ge.code = "report_stale"
            raise _ge
        return dict(target)
    return dict(rows[0]) if rows else {}


def _report_status_norm(status: str) -> str:
    try:
        from . import state_machines as _sm
        return _sm.normalize("report", status) or str(status or "")
    except Exception:  # noqa: BLE001
        return str(status or "")


def verify_content_hash(report_row: dict) -> bool | None:
    """校验单条 report 行的内容 hash（签发/导出入口与状态视图共用）。

    - L94 旧口径（无签名快照）：重算 case_id+version+summary_json+disclaimer；
    - L122 新口径（signatures_json 含冻结正文快照）：校验
      ``sha256(冻结正文) == content_hash`` + body_sha256/body_bytes 自洽 +
      生成阶段 legacy hash 仍成立（签发后 summary/version/disclaimer 被改 → 不可信）。
    返回 True/False；历史行没有 content_hash → None（不判定，不伪造“已校验”）。
    """
    row = dict(report_row or {})
    stored = str(row.get("content_hash") or "")
    if not stored:
        return None
    snap = signed_body_snapshot(row)
    if snap is None:
        return _legacy_content_hash_matches(row)
    body = unpack_signed_body(snap)
    if body is None:
        return False
    calc = _sha256_text(body)
    if stored != calc:
        return False
    body_sha = str(snap.get("body_sha256") or snap.get("sha256") or "")
    if body_sha and body_sha != calc:
        return False
    try:
        body_bytes = int(snap.get("body_bytes") or 0)
    except (TypeError, ValueError):
        return False
    if body_bytes and body_bytes != len(body.encode("utf-8")):
        return False
    gen_hash = str(snap.get("generated_content_hash") or "")
    if gen_hash:
        # 签发后 report 行元数据被改（summary/version/disclaimer）→ 内容不可信。
        # 注意：此时 row.content_hash 已是冻结正文 hash，只能与快照里的生成阶段 hash 比。
        try:
            _sum = json.loads(row.get("summary_json") or "{}")
        except Exception:  # noqa: BLE001
            return False
        _legacy_expect = _report_content_hash(
            str(row.get("case_id") or ""), row.get("version") or "", _sum,
            row.get("disclaimer") or "")
        if _legacy_expect != gen_hash:
            return False
    return True


def _issuance_lock_view(report_row: dict) -> dict:
    """L122：签发事实里的「正文锁定」只读子视图（0 行/回执行同样给默认值）。"""
    snap = signed_body_snapshot(report_row)
    try:
        frozen_bytes = int((snap or {}).get("body_bytes") or 0)
    except (TypeError, ValueError):
        frozen_bytes = 0
    return {"content_lock": signed_content_lock_enabled(),
            "content_locked": snap is not None,
            "snapshot_available": snap is not None,
            "frozen_content_hash": str((snap or {}).get("body_sha256")
                                       or (snap or {}).get("sha256") or ""),
            "frozen_body_bytes": frozen_bytes,
            "frozen_at": str((snap or {}).get("frozen_at") or ""),
            "snapshot_format": str((snap or {}).get("format") or "")}


def issuance_view(case_id: str) -> dict:
    """报告签发事实（只读）：0 行也显式返回 available=False，不掩盖。"""
    all_rows = _report_rows(case_id)
    rows = _generated_report_rows(case_id)
    if not rows:
        if all_rows:
            # 只有导出回执行（未生成即导出）：显式报告，不伪装成“已生成/可签发报告”
            return {"available": True, "report_rows": len(all_rows), "generated_rows": 0,
                    "receipt_rows": len(all_rows), "signed": False, "advisory": True,
                    "report_id": str((all_rows[0] or {}).get("id") or ""), "version": "",
                    "status": "export_receipt", "generated_by": "", "generated_at": "",
                    "signed_by": "", "signed_at": "", "content_hash": "",
                    "content_hash_verified": None, "exported_at": "",
                    "exported_by": "", "exported_hash": "",
                    "note": "仅导出回执行：0 行生成报告（签发模型不适用于回执行）",
                    **_issuance_lock_view({})}
        return {"available": False, "report_rows": 0, "signed": False,
                "advisory": True,
                "note": "0 行报告：尚无生成/签发单据（签发模型仅代码级验证）",
                **_issuance_lock_view({})}
    row = dict(rows[0])
    status_norm = _report_status_norm(str(row.get("status") or ""))
    signed = bool(str(row.get("signed_by") or "").strip()
                  and str(row.get("signed_at") or "").strip())
    content_hash = str(row.get("content_hash") or "")
    # L94/L122：hash 校验统一走 verify_content_hash（签发/导出入口与状态视图同源）
    hash_match = verify_content_hash(row) if content_hash else None
    return {"available": True, "report_rows": len(all_rows),
            "generated_rows": len(rows),
            "receipt_rows": len(all_rows) - len(rows),
            "report_id": row.get("id") or "", "version": row.get("version") or "",
            "status": status_norm or str(row.get("status") or ""),
            "generated_by": str(row.get("created_by") or ""),
            "generated_at": str(row.get("created_at") or ""),
            "signed": signed,
            "signed_by": str(row.get("signed_by") or ""),
            "signed_at": str(row.get("signed_at") or ""),
            "content_hash": content_hash,
            "content_hash_verified": hash_match,
            "exported_at": str(row.get("exported_at") or ""),
            "exported_by": str(row.get("exported_by") or ""),
            "exported_hash": str(row.get("exported_hash") or ""),
            "advisory": True,
            "note": "签发事实仅作 advisory，不参与报告门禁阻断",
            **_issuance_lock_view(row)}


def generate(case_id: str, actor: str = "", role: str = "") -> dict:
    """生成并落一条报告记录；未过门禁直接抛错，不生成空报告。

    生成报告必须带调用方身份：业务管理员只读、系统管理员平台层、
    审核员仅本人案例。
    """
    if not (str(actor or "").strip() or str(role or "").strip()):
        raise ReportPermissionError("生成报告需要认证身份", "unauthenticated", 401)
    _strict_export_access(case_id, actor, role)
    # P0-证据（唯一降级入口）：只有「正式生成报告」才允许把「fail 但引文未逐字命中
    # 归属对象原文/单元格」的 finding 落库降级为 insufficient/need_evidence。
    # 门禁 report_gate.check 与读取路径 review.case_report 都只做只读预演（persist=False）：
    # 避免仅查看门禁/工作台就改写 finding、造成出报告前后两套准确率口径。
    # 幂等保证：enforce_evidence_quotes 跳过已降级 finding（state != fail），重复生成不重复改；
    # 降级失败不静默放行——门禁仍会基于只读预演结果阻断签发。
    try:
        review.enforce_evidence_quotes(case_id, persist=True)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning(
            "formal report evidence downgrade skipped (gate preview will still block)",
            exc_info=True)
    gate = check_gate(case_id)
    if not gate.get("ok"):
        _ge = ReportGateError("；".join(gate.get("reasons") or ["报告门禁未通过"]),
                              gate.get("reasons") or [])
        # L77：审计写失败 → 错误码 audit_write_failed（HTTP 409 / CLI 非 0 同源）
        if gate.get("error_code"):
            _ge.code = str(gate["error_code"])
        raise _ge
    cr = review.case_report(case_id)
    if not cr:
        raise ValueError("项目不存在或无法读取")
    _pn = _platform_name_for_case(case_id)
    # 至少实际构建一次 HTML，确保报告内容可渲染
    build_report_html(case_id)
    try:
        rows = R.reports.list("case_id=?", (case_id,), order="exported_at DESC")
        version = f"v{len(rows) + 1}"
    except Exception:
        version = "v1"
    rid = db.new_id("rep")
    s = dict(cr.get("summary") or {})
    s["_run_id"] = cr.get("case", {}).get("last_run_id") or ""
    # T-161 三区分层：报告记录 summary_json 里带「按区统计」（影子空间不进通过率分母；
    # RULEPROOF_ZONE_REPORT=0 时不写，与改动前一致）。
    try:
        _zview = _zone_section_view(case_id, cr.get("findings") or [],
                                    _manifest_rows(case_id)[1])
        if _zview and _zview.get("enabled"):
            s["zones"] = _zview
    except Exception:  # noqa: BLE001 —— 分区增强失败不阻断正式报告生成
        logging.getLogger(__name__).warning("report zone summary skipped", exc_info=True)
    generated_at = time.strftime("%Y-%m-%d %H:%M:%S")
    disclaimer = f"本报告由 {_pn} 生成，结论以人工复核为准。"
    # L87：正式报告写点二次校验审计状态（门禁后并发失败/半状态 → 拒绝落报告行）
    _l87_assert_audit_state(case_id)
    # L93：生成即落「生成人/生成时间/内容 hash/持久化状态」（旧实现只写空 signatures_json）
    _content_hash = _report_content_hash(case_id, version, s, disclaimer)
    _generated_by = str(actor or "").strip() or "system"
    with db.session() as c:
        c.execute(
            "INSERT INTO report(id,case_id,version,summary_json,signatures_json,disclaimer,"
            "exported_at,status,created_by,created_at,content_hash) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (rid, case_id, version, json.dumps(s, ensure_ascii=False), "", disclaimer,
             generated_at, "generated", _generated_by, generated_at, _content_hash))
        # P2-04：报告记录与审计同一事务；审计写失败→回滚报告记录并向上抛 5xx，
        # 不再“报告已生成但无审计轨迹”。
        _audit_svc.log_in_tx(c, actor=actor or "system", action="report.generated",
                             object_=rid,
                             after=json.dumps({"case_id": case_id, "version": version,
                                               "content_hash": _content_hash,
                                               "generated_by": _generated_by},
                                              ensure_ascii=False))
    return {"ok": True, "id": rid, "version": version, "generated_at": generated_at,
            "status": "generated", "created_by": _generated_by,
            "content_hash": _content_hash}


def export_report(case_id: str, fmt: str = "html", actor: str = "",
                  role: str = "", report_id: str = "") -> bytes | str:
    """严格报告导出入口：先校验职责，再过正式报告门禁，最后渲染。

    - html  → str
    - docx  → bytes
    - pdf   → bytes（环境无 LibreOffice 时返回空 bytes，由调用方明确提示）
    - report_id（L94）：导出回执写到指定报告行（HTTP/CLI 按报告 ID 导出）。

    L122（默认开关=1）：已签发报告优先返回**签发时冻结的正文**——
    - html：原样返回冻结正文（同 report ID 改名/复核后仍重现签发内容）；
    - docx：无法由 HTML 快照直接重建，只有「用冻结时间戳复算的当前正文 hash ==
      冻结正文 hash」才从当前同源状态重建 DOCX；不一致 → report_stale（不静默
      输出新正文）；冻结正文快照损坏 → content_hash_mismatch。
    开关 =0 → 完全回到 L94 旧行为（按当前正文渲染）。
    """
    fmt = str(fmt or "html").strip().lower()
    if fmt not in ("html", "docx", "pdf"):
        raise ValueError(f"不支持的报告格式：{fmt}（可选 html/docx/pdf）")
    if not (str(actor or "").strip() or str(role or "").strip()):
        raise ReportPermissionError("报告导出需要认证身份", "unauthenticated", 401)
    _strict_export_access(case_id, actor, role)
    gate = check_gate(case_id)
    if not gate.get("ok"):
        _ge = ReportGateError("；".join(gate.get("reasons") or ["报告门禁未通过"]),
                              gate.get("reasons") or [])
        if gate.get("error_code"):
            _ge.code = str(gate["error_code"])
        raise _ge
    # L87：导出写点二次校验审计状态（与 report_gate / project / semantic 同一事实源）
    _l87_assert_audit_state(case_id)
    _locked = _signed_body_target(case_id, report_id)
    if _locked is not None and fmt == "html":
        # 只读返回冻结正文（不再渲染）；导出回执在下方按实际字节算 hash
        out = _locked["body"]
    elif _locked is not None and fmt == "docx":
        _render_stamp = _locked["render_stamp"]
        _current = build_report_html(case_id, actor=actor, role=role,
                                     render_stamp=_render_stamp)
        _cur_hash = _sha256_text(_current)
        if _cur_hash != _locked["content_hash"]:
            _ge = ReportGateError(
                "已签发报告正文已锁定：当前项目内容与签发时正文不一致，无法从冻结正文"
                "重建 DOCX（拒绝静默输出新正文）；请重新生成报告并重新签发后再导出",
                ["[report_stale] frozen=" + _locked["content_hash"][:24]
                 + " current=" + _cur_hash[:24],
                 "[content_hash_mismatch] DOCX 无法由冻结 HTML 快照直接重建，"
                 "且当前正文 hash 与签发时不一致"])
            _ge.code = "report_stale"
            raise _ge
        out = build_report_docx(case_id, actor=actor, role=role,
                                render_stamp=_render_stamp)
    elif fmt == "html":
        out = build_report_html(case_id, actor=actor, role=role)
    elif fmt == "docx":
        out = build_report_docx(case_id, actor=actor, role=role)
    else:
        out = build_report_pdf(case_id, actor=actor, role=role)
    # L93/L94：导出回执（导出人/时间/内容 hash）——写失败只告警，不回滚已生成内容
    try:
        _record_export(case_id, fmt, actor, out, report_id=report_id)
    except Exception:  # noqa: BLE001 —— 回执失败不得让已完成的导出变成失败响应
        logging.getLogger(__name__).warning(
            "L93 report export receipt skipped case=%s fmt=%s", case_id, fmt, exc_info=True)
    return out


def _record_export(case_id: str, fmt: str, actor: str, output,
                   report_id: str = "") -> dict:
    """L93/L94：导出回执行（导出人/时间/内容 hash；无生成行时落导出回执，不伪造摘要）。

    report_id 指定时优先把回执写到该报告行（按报告 ID 导出的 HTTP/CLI 入口），
    避免多版本时把回执写到另一条行；未指定时沿用“最新报告行/导出回执行”口径。
    """
    import hashlib
    raw = bytes(output) if isinstance(output, (bytes, bytearray)) else str(output).encode("utf-8")
    digest = "sha256:" + hashlib.sha256(raw).hexdigest()
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    _actor = str(actor or "").strip() or "system"
    rows = _generated_report_rows(case_id) or _report_rows(case_id)
    target = None
    if report_id:
        target = R.reports.get(report_id) or None
        if target and str(target.get("case_id") or "") != str(case_id):
            target = None
    with db.session() as c:
        if target is not None:
            row = dict(target)
            c.execute("UPDATE report SET status='exported', exported_at=?, exported_by=?, "
                      "exported_hash=? WHERE id=?",
                      (stamp, _actor, digest, row.get("id")))
            report_id = row.get("id")
            version = row.get("version") or ""
            receipt = False
        elif rows:
            row = dict(rows[0])
            c.execute("UPDATE report SET status='exported', exported_at=?, exported_by=?, "
                      "exported_hash=? WHERE id=?",
                      (stamp, _actor, digest, row.get("id")))
            report_id = row.get("id")
            version = row.get("version") or ""
            receipt = False
        else:
            # 未走 report.generate 的导出（旧 CLI/HTTP 直出）→ 落“导出回执”行：
            # summary_json 只标回执性质，不伪造报告摘要；status=exported。
            report_id = db.new_id("rep")
            version = "v0"
            _sum = {"_kind": "export_receipt", "format": fmt, "_case_id": case_id}
            _hash = _report_content_hash(case_id, version, _sum, "")
            c.execute(
                "INSERT INTO report(id,case_id,version,summary_json,signatures_json,"
                "disclaimer,exported_at,status,created_by,created_at,content_hash,"
                "exported_by,exported_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (report_id, case_id, version,
                 json.dumps(_sum, ensure_ascii=False), "", "", stamp, "exported",
                 _actor, stamp, _hash, _actor, digest))
            receipt = True
        _audit_svc.log_in_tx(
            c, actor=_actor, action="report.exported", object_=report_id,
            after=json.dumps({"case_id": case_id, "format": fmt, "version": version,
                              "exported_hash": digest, "receipt": receipt},
                             ensure_ascii=False))
    return {"ok": True, "report_id": report_id, "version": version,
            "exported_hash": digest, "export_receipt": receipt,
            "exported_at": stamp, "exported_by": _actor}


def sign_report(case_id: str, actor: str = "", role: str = "",
                note: str = "", report_id: str = "") -> dict:
    """L93/L94/L122：签发报告（唯一签发写点；reviewer 本人项目 / 门禁通过 / 内容 hash 未变）。

    - 身份：与生成/导出一致的严格职责分离（业务管理员只读、平台/系统账号 403）；
    - 前置：report_gate 通过 + 已有生成报告行（0 行拒绝，错误码 report_not_generated）；
    - 目标：report_id 指定时只签发该行（必须属于本 case 且为当前最新报告行，
      否则 report_not_found / report_stale）；缺省签发最新报告行；
    - 防篡改：先按 L94 口径重算生成阶段 content_hash 与存储值比对，不一致 →
      content_hash_mismatch（防摘要被改后签发）；
    - L122 正文锁定（开关默认 1）：渲染并冻结**当前 HTML 正文**，
      content_hash=sha256(冻结正文)，快照写入 signatures_json.snapshot；
      开关 RULEPROOF_REPORT_SIGNED_CONTENT_LOCK=0 → 回退 L94 行为（不冻结）；
    - 写点：report.status=signed + signed_by/signed_at/signatures_json，
      与 `report.signed` 审计同事务；重复签发幂等返回 already_signed=True。
    """
    if not (str(actor or "").strip() or str(role or "").strip()):
        raise ReportPermissionError("报告签发需要认证身份", "unauthenticated", 401)
    _strict_export_access(case_id, actor, role)
    gate = check_gate(case_id)
    if not gate.get("ok"):
        _ge = ReportGateError("；".join(gate.get("reasons") or ["报告门禁未通过，禁止签发"]),
                              gate.get("reasons") or [])
        if gate.get("error_code"):
            _ge.code = str(gate["error_code"])
        raise _ge
    if report_id:
        # L94：按报告 ID 签发（HTTP POST /reports/{id}/sign、CLI report sign --id）
        latest = _target_report_row(case_id, report_id)
    else:
        rows = _generated_report_rows(case_id)
        if not rows:
            _ge = ReportGateError(
                "尚未生成报告，不能签发：请先调用 report.generate 生成报告",
                ["[report_not_generated] 该项目 report 表 0 行（或仅导出回执行）"])
            _ge.code = "report_not_generated"
            raise _ge
        latest = dict(rows[0])
    status_norm = _report_status_norm(str(latest.get("status") or ""))
    signer = str(actor or "").strip() or "system"
    if str(latest.get("signed_by") or "").strip() and str(latest.get("signed_at") or "").strip():
        return {"ok": True, "already_signed": True, "report_id": latest.get("id"),
                "version": latest.get("version") or "",
                "signed_by": latest.get("signed_by"),
                "signed_at": latest.get("signed_at"),
                "content_hash": latest.get("content_hash") or "",
                "note": "报告已签发（重复调用幂等，不重复写审计）",
                **_issuance_lock_view(latest)}
    if status_norm == "revoked":
        _ge = ReportGateError("报告已撤销，不能签发", [
            "[report_revoked] 已撤销报告需重新生成后再签发"])
        _ge.code = "report_revoked"
        raise _ge
    if status_norm == "exported":
        _ge = ReportGateError(
            "报告已导出（exported 状态），不能在导出后签发；请重新生成报告再签发",
            ["[report_already_exported] L92 状态机：exported→signed 非法迁移"])
        _ge.code = "invalid_transition"
        raise _ge
    try:
        _sum = json.loads(latest.get("summary_json") or "{}")
    except Exception:  # noqa: BLE001 —— 摘要损坏视为内容不可信，拒绝签发
        _sum = None
    if _sum is None:
        _ge = ReportGateError("报告摘要损坏，不能签发", ["[content_hash_mismatch] summary_json 非法"])
        _ge.code = "content_hash_mismatch"
        raise _ge
    expect_hash = _report_content_hash(case_id, latest.get("version") or "",
                                       _sum, latest.get("disclaimer") or "")
    stored_hash = str(latest.get("content_hash") or "")
    if stored_hash and stored_hash != expect_hash:
        _ge = ReportGateError(
            "报告内容与生成时的 content_hash 不一致（可能被篡改），拒绝签发",
            [f"[content_hash_mismatch] stored={stored_hash[:24]}… expect={expect_hash[:24]}…"])
        _ge.code = "content_hash_mismatch"
        raise _ge
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    # L122：签发即冻结当前 HTML 正文；content_hash=sha256(冻结正文)
    content_lock = signed_content_lock_enabled()
    snapshot = None
    if content_lock:
        render_stamp = time.strftime("%Y-%m-%d %H:%M")
        try:
            frozen_body = build_report_html(case_id, actor=actor, role=role,
                                            render_stamp=render_stamp)
        except (ReportPermissionError, ReportGateError):
            raise
        except Exception as exc:  # noqa: BLE001 —— 冻结失败 → fail-closed，不签发无正文单据
            logging.getLogger(__name__).warning(
                "L122 sign frozen body render failed case=%s", case_id, exc_info=True)
            _ge = ReportGateError(
                "签发时冻结报告正文失败，拒绝签发（不得生成无正文的签发单据）",
                ["[report_blocked] frozen_body_render_failed: "
                 + type(exc).__name__ + ": " + str(exc)[:160]])
            _ge.code = "report_blocked"
            raise _ge
        packed = pack_signed_body(frozen_body)
        body_sha = str(packed.get("body_sha256") or _sha256_text(frozen_body))
        snapshot = {"schema": _SIGNED_BODY_SCHEMA,
                    "format": _SIGNED_BODY_FORMAT,
                    "sha256": body_sha,
                    "frozen_at": stamp,
                    "render_stamp": render_stamp,
                    "case_id": case_id,
                    "case_name": str((R.cases.get(case_id) or {}).get("name") or ""),
                    "report_id": str(latest.get("id") or ""),
                    "version": str(latest.get("version") or ""),
                    "generated_content_hash": expect_hash,
                    **packed}
        signed_hash = body_sha
        signatures_obj = {"signed_by": signer, "signed_at": stamp,
                          "content_hash": signed_hash,
                          "note": str(note or "")[:200],
                          "content_lock": 1,
                          "generated_content_hash": expect_hash,
                          "snapshot": snapshot}
    else:
        # 开关=0：回退 L94 旧行为（不冻结正文，content_hash 仍为生成阶段口径）
        signed_hash = expect_hash
        signatures_obj = {"signed_by": signer, "signed_at": stamp,
                          "content_hash": signed_hash,
                          "note": str(note or "")[:200],
                          "content_lock": 0}
    signatures = json.dumps(signatures_obj, ensure_ascii=False)
    audit_after = {"case_id": case_id, "version": latest.get("version") or "",
                   "signed_by": signer, "content_hash": signed_hash,
                   "content_lock": int(content_lock),
                   "note": str(note or "")[:200]}
    if snapshot is not None:
        audit_after.update({"frozen_body_sha256": snapshot.get("sha256") or "",
                            "frozen_body_bytes": int(snapshot.get("body_bytes") or 0),
                            "frozen_at": stamp})
    with db.session() as c:
        cur = c.execute(
            "UPDATE report SET status='signed', signed_by=?, signed_at=?, "
            "signatures_json=?, content_hash=? WHERE id=? AND "
            "COALESCE(signed_by,'')=''",
            (signer, stamp, signatures, signed_hash, latest.get("id")))
        if cur.rowcount != 1:
            fresh = c.execute("SELECT signed_by FROM report WHERE id=?",
                              (latest.get("id"),)).fetchone()
            if fresh and str(fresh[0] or "").strip():
                return {"ok": True, "already_signed": True,
                        "report_id": latest.get("id"),
                        "version": latest.get("version") or "",
                        "signed_by": str(fresh[0]),
                        "signed_at": stamp, "content_hash": signed_hash,
                        "note": "并发签发被幂等拦截（他处已签发）"}
            raise ReportGateError("报告签发写入失败（并发状态变化）", [
                "[report_sign_conflict] 请刷新后重试"])
        _audit_svc.log_in_tx(
            c, actor=signer, action="report.signed", object_=latest.get("id"),
            after=json.dumps(audit_after, ensure_ascii=False))
    out = {"ok": True, "already_signed": False, "report_id": latest.get("id"),
           "version": latest.get("version") or "", "status": "signed",
           "signed_by": signer, "signed_at": stamp,
           "content_hash": signed_hash, "content_lock": int(content_lock),
           "generated_content_hash": expect_hash,
           "signature": signatures}
    if snapshot is not None:
        out["frozen_body"] = {"format": _SIGNED_BODY_FORMAT,
                              "sha256": snapshot.get("sha256") or "",
                              "body_bytes": int(snapshot.get("body_bytes") or 0),
                              "frozen_at": stamp,
                              "render_stamp": snapshot.get("render_stamp") or ""}
    return out
