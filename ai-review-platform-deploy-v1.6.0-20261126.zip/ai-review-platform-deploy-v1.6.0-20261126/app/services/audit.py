"""审计日志（系统管理员）：全局操作/安全事件查询。"""
from .. import db
from .. import repositories as R

ACTION_LABEL = {
    "workspace.created": "创建工作空间",
    "auth.login": "登录成功", "auth.login_failed": "登录失败", "auth.logout": "退出登录",
    "user.password_changed": "修改密码", "account.created": "创建账号",
    "account.password_reset": "重置密码", "account.status_changed": "账号状态变更",
    "rule.published": "规则发布", "rule.submitted": "规则提交审批", "rule.approved": "规则批准",
    "rule.rollback": "规则回滚", "rule.archived": "规则下线",
    "rule.effective_select_checked": "生效口径一致性检查",
    "rule.effective_select_rollback_detected": "生效口径回退风险告警",
    "rule.effective_drift_repaired": "规则漂移修复",
    "rules_review.waived": "规则体检豁免",
    "rules_review.waivers_applied": "审核使用规则豁免",
    "human_review.review_mode_force_set": "强制回退复核模式",
    "decision_table.archived": "决策表下线",
    "project.created": "创建项目", "project.audited": "运行审核",
    # L108 智能体治理：运行/发布/回滚/版本修复/DAG 工作流入口（actor 必须是真实操作人）
    "agent.run": "运行智能体", "agent.published": "发布智能体版本",
    "agent.rollback": "回滚智能体版本", "agent.version_repaired": "修复智能体版本",
    "agent.workflow_run": "执行智能体 DAG 工作流", "agent.updated": "修改智能体",
    # 评审批次3-5 修复新增的关键写操作审计（P1-B4-01 / P1-B5-02 / P2-B4-03 / P2-B3-04）
    "conflict.detect": "冲突全量检测", "conflict.detect_failed": "冲突检测失败",
    "conflict.checked": "冲突检测完成", "decision_table.wrapper_archived": "决策表包装规则下线",
    "document.uploaded": "上传项目文件", "document.upload_rejected": "上传被拒",
    "report.exported": "导出正式报告",
    "review.completed": "审核完成", "finding.decided": "人工复核",
    "ontology.published": "本体发布", "open.app_created": "创建开放应用",
    "open.task_accepted": "外部推送任务", "open.webhook_failed": "回调失败",
    # T-201：审计导出（默认关闭、需二次确认、每次导出留痕）与告警规则事件
    "audit.exported": "审计导出", "audit_export.config_changed": "审计导出开关变更",
    # L169/HW-19：数据留存策略周期盘点（只读；到期量入审计供核对）
    "data.retention.due": "数据留存到期盘点",
    "alert.triggered": "告警触发", "alert.recovered": "告警恢复",
}




def actions() -> list:
    return [{"action": k, "label": v} for k, v in ACTION_LABEL.items()]


def log_in_tx(c, actor: str, action: str, object_: str = "", before: str = "",
              after: str = "", request_id: str = "", ip: str = "",
              tenant_id: str | None = None,
              workspace_id: str | None = None) -> str:
    """在调用方事务连接 ``c`` 内写审计行（P2-04：业务写与审计同事务）。

    与 ``R.audit_logs.log`` 的区别：**不自行 commit**、不吞异常。审计插入失败会
    向上抛，由调用方 ``db.session()`` 回滚业务写并返回 5xx —— 关键写操作不再
    “业务成功但审计丢失”。租户/空间默认取当前线程上下文，与 BaseRepo.insert 同源；
    显式传 ``tenant_id``/``workspace_id`` 用于「对象自身归属才是审计归属」的场景
    （如 L91 workspace.created：新空间不属于当前请求空间）。
    """
    if tenant_id is None or workspace_id is None:
        try:
            from . import ctx as _ctx
            cur = _ctx.get_context() or {}
            if tenant_id is None:
                tenant_id = str(cur.get("tenant_id") or "")
            if workspace_id is None:
                workspace_id = str(cur.get("workspace_id") or "")
        except Exception:
            if tenant_id is None:
                tenant_id = ""
            if workspace_id is None:
                workspace_id = ""
    tenant_id = str(tenant_id or "")
    workspace_id = str(workspace_id or "")
    row = {"id": db.new_id("log"), "actor": str(actor or "system"), "action": str(action or ""),
           "object": str(object_ or ""), "before_json": before or "", "after_json": after or "",
           "request_id": request_id or "", "ip": ip or "", "created_at": db.now(),
           "tenant_id": tenant_id, "workspace_id": workspace_id}
    keys = list(row.keys())
    c.execute("INSERT INTO audit_log(" + ",".join(keys) + ") VALUES("
              + ",".join("?" * len(keys)) + ")", [row[k] for k in keys])
    return row["id"]


def _log_required(actor: str, action: str, object_: str, after: str) -> None:
    """独立事务写审计，失败显式抛出（供必须留痕的写操作兜底）。"""
    with db.session() as c:
        log_in_tx(c, actor=actor, action=action, object_=object_, after=after)




def _where(q: str = "", result: str = "", action: str = "", actor: str = "",
           date_from: str = "", date_to: str = ""):
    where = "1=1"
    params = []
    if action:
        where += " AND a.action=?"; params.append(action)
    if actor:
        where += " AND (a.actor LIKE ? OR u.name LIKE ?)"; params += [f"%{actor}%", f"%{actor}%"]
    if date_from:
        where += " AND substr(a.created_at,1,10)>=?"; params.append(date_from)
    if date_to:
        where += " AND substr(a.created_at,1,10)<=?"; params.append(date_to)
    if q:
        where += (" AND (a.action LIKE ? OR a.actor LIKE ? OR u.name LIKE ? OR a.object LIKE ? "
                  "OR a.request_id LIKE ? OR COALESCE(a.after_json,'') LIKE ?)")
        params += [f"%{q}%"] * 6
    _case = ("CASE WHEN a.action LIKE '%failed%' OR a.action LIKE '%error%' THEN 'failed' "
             "WHEN a.action LIKE '%forbidden%' OR a.action LIKE '%denied%' THEN 'denied' ELSE 'success' END")
    if result in ("success", "failed", "denied"):
        where += f" AND {_case}=?"; params.append(result)
    return where, params, _case


def search_logs(q: str = "", result: str = "", action: str = "", actor: str = "",
                date_from: str = "", date_to: str = "", limit: int = 20, offset: int = 0,
                tenant_id: str = "", workspace_id: str = "") -> dict:
    where, params, case = _where(q, result, action, actor, date_from, date_to)
    # 显式租户过滤：HTTP 必须传当前用户租户；CLI/迁移不传时保持全局。
    if tenant_id:
        where += " AND a.tenant_id=?"; params.append(tenant_id)
    if workspace_id:
        where += " AND a.workspace_id=?"; params.append(workspace_id)
    with db.session() as c:
        total = c.execute(
            f"SELECT count(*) FROM audit_log a LEFT JOIN user u ON u.id=a.actor WHERE {where}",
            tuple(params)).fetchone()[0]
        summary = {"total": total}
        for key in ("success", "failed", "denied"):
            summary[key] = c.execute(
                f"SELECT count(*) FROM audit_log a LEFT JOIN user u ON u.id=a.actor WHERE {where} AND {case}=?",
                tuple(params + [key])).fetchone()[0]
        rows = c.execute(
            f"SELECT a.*, COALESCE(NULLIF(u.name,''),a.actor) AS actor_name, COALESCE(u.department,'') AS actor_department, {case} AS result "
            f"FROM audit_log a LEFT JOIN user u ON u.id=a.actor WHERE {where} "
            "ORDER BY a.created_at DESC, a.id DESC LIMIT ? OFFSET ?",
            tuple(params + [limit, offset])).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d["action_label"] = ACTION_LABEL.get(d.get("action") or "", d.get("action") or "")
        d["detail"] = (d.get("after_json") or "")[:300]
        d["reason"] = d.get("before_json") or ""
        items.append(d)
    return {"items": items, "total": total, "summary": summary}
