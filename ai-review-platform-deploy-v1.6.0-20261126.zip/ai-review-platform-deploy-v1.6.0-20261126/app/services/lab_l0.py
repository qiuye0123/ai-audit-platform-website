"""L0：纯大模型直审（不做类型路由/点位/校准）——分层实验基准。"""
import json, os, re
from pathlib import Path
from .. import repositories as R
from .extract import _provider, _chat, _json_of


def _doc_text(path: str) -> str:
    p = Path(path)
    if p.suffix.lower() in (".md", ".txt"):
        return p.read_text(encoding="utf-8", errors="ignore")
    try:
        from ..engine import deepparse
        return deepparse.parse_and_extract(path)["doc"].get("text", "") or ""
    except Exception:
        return ""


def l0_judge(path: str, max_rules: int = 40, max_chars: int = 12000) -> list:
    if _provider() is None:
        return []
    text = _doc_text(path)[:max_chars]
    rules = []
    for r in R.rules.list("status=?", ("published",))[:max_rules]:
        vs = R.rule_versions.list("rule_id=?", (r["id"],), order="id DESC")
        try:
            slots = json.loads((vs[0].get("slots_json") if vs else "") or "{}")
        except Exception:
            slots = {}
        crit = slots.get("criterion") or r.get("name") or ""
        rules.append({"code": r.get("code"), "criterion": str(crit)[:300]})
    if not rules:
        return []
    sys_msg = ("你是文件审核器。对每条规则逐条判断文档是否违反。只输出 JSON 数组，"
               "每项 {\"code\":\"规则编号\",\"verdict\":\"fail|pass|na\",\"quote\":\"原文逐字片段\","
               "\"reason\":\"一句话理由\"}。quote 必须是文档中连续逐字出现的文字；找不到就判 na。")
    user = "规则：\n" + "\n".join(f"- {x['code']}：{x['criterion']}" for x in rules) + "\n\n文档：\n" + text
    try:
        judged = _json_of(_chat([{"role": "system", "content": sys_msg},
                                 {"role": "user", "content": user}], max_tokens=2000))
    except Exception:
        return []
    out = []
    name = {x["code"]: x["criterion"][:40] for x in rules}
    for j in judged if isinstance(judged, list) else []:
        if str(j.get("verdict") or "").lower() != "fail":
            continue
        q = str(j.get("quote") or "")
        if q and q not in text:
            q2 = re.sub(r"\s+", "", q)
            if q2 not in re.sub(r"\s+", "", text):
                continue
        out.append({"rule_code": j.get("code"), "point_id": j.get("code"),
                    "level": "critical", "title": name.get(str(j.get("code")), ""),
                    "description": j.get("reason") or "", "locations": [{"quote": q}],
                    "state": "不满足", "confidence": None, "origin": "customer_rule"})
    return out
