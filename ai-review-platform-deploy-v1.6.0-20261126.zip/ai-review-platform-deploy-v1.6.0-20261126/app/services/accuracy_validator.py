# -*- coding: utf-8 -*-
"""准确率候选验证器：引文逐字校验 + 规则判据 + 已批准条件（SW）对抗式双票复核。

定位
----
这是“候选复核层”，不是新的裁决层：直接影子召回（accuracy_shadow）产出的每条候选，
只有同时满足下面三个条件才允许回填为 finding：

1. 引文可回查：候选 quote 必须能在文档原文中按“去空白归一”逐字定位；
   校验通过后用原文片段替换模型输出，避免模型改写/拼接引文。
2. 规则判据：正票要求模型给出“执行条款与规则判据明确矛盾”的理由；
   判据无法核验、仅表述不同、或存在合理解释时一律不成立。
3. 已批准条件：如果文档是“已批准商务条件（SW）+ 拟定执行条款（TK）”结构，
   自动按同编号配对取 SW 条款作为批准条件一起送审；没有该结构时退化为
   “规则判据单独复核”，不伪造不存在的批准条件。

双票一致性
----------
两票使用不同提示词角色（正票=严格复核员；反票=合规辩护），一票判成立、
另一票无法辩护出“符合”的理由，才视为双票一致。任一步 JSON 解析失败都按
“不成立”处理（fail-closed），绝不把解析失败当通过。

可复现
------
设置 RULEPROOF_ACCURACY_DUMP=<目录> 时，逐票落盘 prompt/response，供实验复算。
"""
from __future__ import annotations

import json
import logging
import os
import re

from ..engine import llm, llm_router

log = logging.getLogger(__name__)

# 条款标题：### SW-1014 事项1014 / ## TK-2001 / ### QT-31-1 等
_CLAUSE_RE = re.compile(r"^\s*#{0,6}\s*([A-Z][A-Z0-9]{1,5}-\d+(?:-\d+)?)\b\s*(.*)$")
# 一级/二级章节标题（不含条款编码）
_SECTION_RE = re.compile(r"^\s*#{1,6}\s+(?![A-Z][A-Z0-9]{1,5}-\d)(.+?)\s*$")

_APPROVED_KEYS = ("批准", "审批", "商务条件")
_EXEC_KEYS = ("执行", "拟定", "约定条款", "合同条款", "工艺")
_TEMPLATE_KEYS = ("范本", "参考", "正文")


def _nz(s: str) -> str:
    """归一：去掉全部空白字符，用于逐字回查（不改变文字内容）。"""
    return re.sub(r"\s+", "", str(s or ""))


def _dump(name: str, obj) -> None:
    d = os.environ.get("RULEPROOF_ACCURACY_DUMP") or ""
    if not d:
        return
    try:
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, name)
        with open(p, "w", encoding="utf-8") as f:
            if isinstance(obj, str):
                f.write(obj)
            else:
                json.dump(obj, f, ensure_ascii=False, indent=1)
    except Exception:
        log.debug("accuracy dump skipped", exc_info=True)


def _section_kind(title: str) -> str:
    t = str(title or "")
    if any(k in t for k in _TEMPLATE_KEYS):
        return "template"
    if any(k in t for k in _APPROVED_KEYS):
        return "approved"
    if any(k in t for k in _EXEC_KEYS):
        return "execution"
    return "other"


def index_document(text: str) -> dict:
    """把文档切成「条款实例」并标注所属章节，供引文定位/批准条件配对。

    返回：
      clauses: [{id, prefix, num, kind, section, title, text, start, end}]
      by_id:   {条款编码: clause}
      approved_text / execution_text: 整节文本（最多 4000 字符，供兜底送审）
    """
    text = str(text or "")
    lines = text.splitlines(keepends=True)
    clauses, by_id = [], {}
    cur_section, cur = "", None
    pos = 0
    for line in lines:
        raw = line.rstrip("\n")
        m_c = _CLAUSE_RE.match(raw)
        m_s = _SECTION_RE.match(raw) if not m_c else None
        if m_c:
            cid = m_c.group(1)
            prefix = re.match(r"([A-Z][A-Z0-9]{1,5})-", cid).group(1)
            num = cid.rsplit("-", 1)[-1]
            cur = {"id": cid, "prefix": prefix, "num": num,
                   "kind": _section_kind(cur_section),
                   "section": cur_section, "title": m_c.group(2).strip(),
                   "lines": [raw], "start": pos, "end": pos + len(line)}
            clauses.append(cur)
        elif m_s:
            # 新章节标题：结束当前条款，切换章节上下文
            cur_section = m_s.group(1).strip()
            cur = None
        elif cur is not None:
            cur["lines"].append(raw)
            cur["end"] = pos + len(line)
        pos += len(line)
    for c in clauses:
        c["text"] = "\n".join(c.pop("lines")).strip()
        by_id.setdefault(c["id"], c)
    approved = [c for c in clauses if c["kind"] == "approved"]
    execution = [c for c in clauses if c["kind"] == "execution"]
    return {
        "text": text,
        "clauses": clauses,
        "by_id": by_id,
        "approved_text": "\n".join(c["text"] for c in approved)[:4000],
        "execution_text": "\n".join(c["text"] for c in execution)[:4000],
        "has_approved_section": bool(approved),
    }


def locate_quote(text: str, quote: str) -> dict:
    """逐字回查引文：去空白归一后包含即通过，返回原文片段与所在条款。

    不做同义改写匹配：回查不到就拒绝（宁缺毋滥），避免“模型编的引文”落库。
    """
    q = str(quote or "").strip()
    if len(_nz(q)) < 6:
        return {}
    try:
        from . import structure as _st
        span = _st.find_span(text, q)
    except Exception:
        span = None
    if not span:
        return {}
    # find_span 返回的 quote 是带上下文的片段；start/end 是引文本身的位置，
    # 这里必须取“引文本身”，否则上下文会把条款标题/相邻条款带进来，定位串位。
    start, end = span.get("start"), span.get("end")
    exact = text[start:end] if isinstance(start, int) and isinstance(end, int) else span.get("quote") or ""
    if not _nz(exact):
        return {}
    return {"quote": exact, "start": start, "end": end}


def clause_of(idx: dict, quote: str) -> dict:
    """引文落在哪个条款：优先精确子串，其次归一化包含。"""
    if not idx or not quote:
        return {}
    for c in idx.get("clauses") or []:
        if quote in c["text"]:
            return c
    nq = _nz(quote)
    best = {}
    for c in idx.get("clauses") or []:
        if nq and nq in _nz(c["text"]):
            if not best or len(c["text"]) < len(best["text"]):
                best = c
    return best


def paired_approved(idx: dict, clause: dict) -> dict:
    """按同编号配对找“已批准条件”条款（SW-1007 ↔ TK-1007）；找不到返回 {}。"""
    if not idx or not clause:
        return {}
    num = str(clause.get("num") or "")
    if not num:
        return {}
    for c in idx.get("clauses") or []:
        if c["kind"] == "approved" and c.get("num") == num and c.get("id") != clause.get("id"):
            return c
    return {}


def paired_execution(idx: dict, clause: dict) -> dict:
    """按同编号配对找“拟定执行条款”（SW-1007 ↔ TK-1007）；找不到返回 {}。

    证据引用的是“已批准条件”正文时（manifest D1-D5 的 required_evidence 就是批准
    条件），必须再配对同编号执行条款，才能复核“执行是否违反批准条件”，否则会把
    批准条件本身当执行条款判成“无矛盾”。
    """
    if not idx or not clause:
        return {}
    num = str(clause.get("num") or "")
    if not num:
        return {}
    for c in idx.get("clauses") or []:
        if c["kind"] == "execution" and c.get("num") == num and c.get("id") != clause.get("id"):
            return c
    return {}


def _clip(s: str, n: int) -> str:
    s = str(s or "").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def _chat_json(system: str, user: str, *, timeout: int, max_tokens: int = 700,
               stage: str = "accuracy_validator", point_ids: list | None = None) -> dict:
    cfg = llm_router.resolve()
    if not cfg.get("enabled") or not cfg.get("api_key"):
        raise RuntimeError("模型未配置")
    llm.set_stage(stage)
    if point_ids:
        llm.set_point_scope(point_ids)
    raw = llm.chat_completion(cfg["base_url"], cfg["api_key"], cfg["model"],
                              [{"role": "system", "content": system},
                               {"role": "user", "content": user}],
                              timeout=timeout, max_tokens=max_tokens, temperature=0)
    try:
        from . import extract as _ex
        obj = _ex._json_of(raw)
    except Exception:
        obj = {}
    return {"raw": raw, "obj": obj if isinstance(obj, dict) else {}}


def _as_bool(v) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "y", "是", "成立")


def validate(candidate: dict, rule: dict, idx: dict, *, timeout: int = 60,
             seq: int = 1) -> dict:
    """对一条候选做“正票 + 反票”二次判定。

    candidate: {code, quote, location, issue, correction, confidence}
    rule:      {code, name, criterion}
    返回 {ok, votes:{positive, negative}, reason, quote, clause, approved}
    """
    quote = str(candidate.get("quote") or "").strip()
    code = str(candidate.get("code") or candidate.get("point_code") or "")
    issue = _clip(candidate.get("issue") or candidate.get("reason") or "", 500)
    loc = str(candidate.get("location") or "")
    hit = locate_quote(idx.get("text") or "", quote) if idx.get("text") else {}
    if not hit:
        return {"ok": False, "reject": "quote_not_verbatim", "quote": quote}
    quote = hit["quote"]
    clause = clause_of(idx, quote) or (idx.get("by_id") or {}).get(loc) or {}
    approved = paired_approved(idx, clause)
    exec_clause = clause
    if clause.get("kind") == "approved":
        # 证据引用的是已批准条件：配对同编号执行条款作为待核条款，批准条件本身作为判据
        approved = clause
        exec_clause = paired_execution(idx, clause) or {}
    if clause.get("kind") == "approved" and not exec_clause:
        # 只有已批准条件、配不到同编号执行条款：无法复核“执行是否违反批准条件”，
        # 直接拒审（不得拿批准条件本身当执行条款判成“无矛盾”）。
        return {"ok": False, "reject": "no_paired_execution", "quote": quote,
                "clause_id": clause.get("id") or loc, "approved_id": clause.get("id") or "",
                "reason": "证据为已批准条件且文档中无同编号执行条款，无法复核"}
    approved_text = approved.get("text") or "" if approved is not clause else (clause.get("text") or "")
    exec_text = exec_clause.get("text") or quote
    clause_id = exec_clause.get("id") or clause.get("id") or loc
    crit = str(rule.get("criterion") or rule.get("description") or rule.get("name") or "")
    header = (f"规则：{code} {rule.get('name') or ''}\n判据：{_clip(crit, 900)}\n")
    if approved_text:
        header += f"\n文档内已批准条件（{approved.get('id')}）：\n{_clip(approved_text, 1200)}\n"
    header += f"\n待核执行条款（{clause.get('id') or loc or '未标注条款'}）：\n{_clip(exec_text, 1400)}\n"
    header += f"\n候选认为的问题：{issue}\n"

    sys_a = ("你是严格的审核候选复核员。只判断该候选是否成立，只输出 JSON。"
             "判据无法核验、只是表述不同、或存在任何合理解释时，一律判不成立。")
    user_a = (header + "\n请判定：执行条款是否与规则判据"
              + ("/已批准条件" if approved_text else "")
              + "存在明确矛盾？\n"
              "仅当理由明确、且能从给出文本直接核验时输出 violate=true；否则 violate=false。\n"
              '只输出 JSON：{"violate": true|false, "reason": "依据（一句话）", '
              '"evidence_quote": "执行条款中逐字片段（可为空）"}')
    sys_b = ("你是合规辩护人。你的任务是尽力论证该条款符合规则判据；"
             "只有当任何合理解释都无法使其符合、且与判据明确矛盾时才承认不符合。只输出 JSON。")
    user_b = (header + "\n请为该执行条款辩护：它是否可能符合规则判据"
              + ("/已批准条件" if approved_text else "")
              + "？只要存在合理解释就输出 comply=true。\n"
              '只输出 JSON：{"comply": true|false, "reason": "辩护理由（一句话）"}')

    votes = {"positive": {}, "negative": {}}
    base = f"cand{seq:03d}"
    try:
        pa = _chat_json(sys_a, user_a, timeout=timeout, max_tokens=600,
                        stage="accuracy_validator_positive", point_ids=[code])
        _dump(f"{base}_positive_prompt.txt", sys_a + "\n\n===== USER =====\n\n" + user_a)
        _dump(f"{base}_positive_response.txt", pa["raw"])
        votes["positive"] = {"violate": _as_bool(pa["obj"].get("violate")),
                             "reason": str(pa["obj"].get("reason") or "")[:300],
                             "evidence_quote": str(pa["obj"].get("evidence_quote") or "")[:300],
                             "parsed": bool(pa["obj"])}
    except Exception as e:
        votes["positive"] = {"error": f"{type(e).__name__}: {str(e)[:120]}"}
    try:
        pb = _chat_json(sys_b, user_b, timeout=timeout, max_tokens=600,
                        stage="accuracy_validator_negative", point_ids=[code])
        _dump(f"{base}_negative_prompt.txt", sys_b + "\n\n===== USER =====\n\n" + user_b)
        _dump(f"{base}_negative_response.txt", pb["raw"])
        votes["negative"] = {"comply": _as_bool(pb["obj"].get("comply")),
                             "reason": str(pb["obj"].get("reason") or "")[:300],
                             "parsed": bool(pb["obj"])}
    except Exception as e:
        votes["negative"] = {"error": f"{type(e).__name__}: {str(e)[:120]}"}

    pos_ok = bool(votes["positive"].get("violate"))
    neg_ok = votes["negative"].get("comply") is False
    ok = pos_ok and neg_ok
    reason = ""
    if not pos_ok:
        reason = "正票未确认明确矛盾：" + (votes["positive"].get("reason") or
                                           votes["positive"].get("error") or "未判定")
    elif not neg_ok:
        reason = "反票仍可辩护为符合：" + (votes["negative"].get("reason") or
                                           votes["negative"].get("error") or "未判定")
    return {"ok": ok, "reject": "" if ok else "double_vote_disagree",
            "reason": reason[:300], "quote": quote,
            "clause_id": clause_id,
            "approved_id": approved.get("id") if approved is not clause else clause.get("id") or "",
            "votes": votes}
