"""L52 唯一执行出口与 fail-closed 收紧（2026-11-24）。

背景：L46a/L46c P0——主链直调 ``manifest_exec.run`` 缺 ``manifest.executed`` 审计、
legacy/points_path 可绕过 manifest、清单执行入口只写 active、``AUDIT_DAG=0`` 分叉、
``FREEZE_PARSE=0`` 时整条确定性执行静默归零。

本模块只提供「开关 + 审计 + 显式异常 + 案件口径查询」四类能力，不改判定语义：

- 开关：``RULEPROOF_SINGLE_ENTRY_FIX`` 默认 ``1``（开启 = 收紧后的唯一出口行为）；
  ``=0`` 逐入口回退到旧行为（回退杆）。
- 审计：``audit()`` 尽力写 ``audit_log``（失败只 warning，不静默吞异常原因）。
- 异常：``ManifestExecutionBlocked``（HTTP 409 / CLI 非 0 退出）。
- 案件口径：``case_has_manifest()`` / ``legacy_run_without_manifest()`` 供报告门禁使用。

注意：本模块不 import ``app.repositories``/``app.db`` 于模块顶层，避免把 DB 依赖
带进 report_gate 等被早期导入的模块；所有 DB 访问均在函数内延迟导入。
"""
from __future__ import annotations

import json
import logging
import os

# 唯一执行出口修复开关（默认开；=0 回退旧行为，逐入口可回退）
ENV = "RULEPROOF_SINGLE_ENTRY_FIX"
# 旧 points_path 兼容期回退开关（只有精确 "1" 才放行；与 review_legacy 同一语义）
LEGACY_POINTS_ENV = "RULEPROOF_ALLOW_LEGACY_POINTS"
# L58 ②：旧链放行的「部署级二次确认」标记。产品可写侧入口（HTTP /reviews 适配器）
# 必须 ALLOW_LEGACY_POINTS=1 + DEPLOYMENT=1 同时存在才执行旧链；单独 1 视为未部署
# 显式授权 → fail-closed（不再默认存在/不可由请求参数打开）。
LEGACY_POINTS_DEPLOY_ENV = "RULEPROOF_LEGACY_POINTS_DEPLOYMENT"
# L58 ①：语义重审唯一执行路径开关（默认 1：改走 manifest_exec.run；=0 回退旧第二执行器）
SEMANTIC_REAUDIT_ENV = "RULEPROOF_SEMANTIC_REAUDIT_SINGLE_PATH"

# ---------------------------------------------------------------------------
# L77（build49 P0，90 号 §二-3 / 外部评审 Top3）：审计写失败硬阻断 + 回退杆生产禁用
#
# 1) 审计硬阻断开关（默认 1）：manifest.executed 下沉审计写失败时 run() 返回
#    audit_failed=True，project.audit 按 fail-closed 阻断（HTTP 409/CLI 非 0），
#    report_gate 同样按 audit_failed 阻断签发（错误码 audit_write_failed）。
#    =0 回退旧行为（只 warning，不改变执行结果），仅用于排障/回退验证。
# 2) 回退杆生产禁用：RULEPROOF_ENV=prod/production 时，禁止 SINGLE_ENTRY_FIX=0 /
#    SNAPSHOT_V3=0（=0 即一键撤防）。启动期 fail-fast（ConfigError / 退出码非 0）；
#    非 prod 仅 warning + 审计 single_entry.rollback_lever_used。
# ---------------------------------------------------------------------------
AUDIT_HARD_FAIL_ENV = "RULEPROOF_AUDIT_HARD_FAIL"
SNAPSHOT_V3_ENV = "RULEPROOF_SNAPSHOT_V3"
PROD_ENV = "RULEPROOF_ENV"
_PROD_VALUES = ("prod", "production")
_PROD_FORBIDDEN_LEVERS = (
    ("RULEPROOF_SINGLE_ENTRY_FIX", "唯一执行出口修复（manifest.executed 下沉审计）"),
    ("RULEPROOF_SNAPSHOT_V3", "运行快照 v3（策略/开关可复现）"),
)
_ROLLBACK_WARNED = set()
_ROLLBACK_AUDITED = set()

_LOG = logging.getLogger(__name__)


class ConfigError(RuntimeError):
    """L77：生产环境启用了被禁用的回退杆（启动 fail-fast，退出码非 0）。"""

    code = "config_error"
    http_status = 500

    def __init__(self, message: str, detail: dict | None = None):
        self.detail = dict(detail or {})
        super().__init__(str(message))

    def to_dict(self) -> dict:
        return {"ok": False, "error": str(self), "code": self.code,
                "detail": self.detail}


def is_prod() -> bool:
    """当前进程是否生产环境（RULEPROOF_ENV=prod/production）。"""
    return (os.environ.get("RULEPROOF_ENV") or "").strip().lower() in _PROD_VALUES


def _single_entry_fix_raw() -> str:
    return str(os.environ.get("RULEPROOF_SINGLE_ENTRY_FIX", "1") or "").strip().lower()


def _snapshot_v3_raw() -> str:
    return str(os.environ.get("RULEPROOF_SNAPSHOT_V3", "1") or "").strip().lower()


def _raw_on(raw: str) -> bool:
    return str(raw or "").strip().lower() not in ("0", "false", "no", "off", "disabled")


def audit_hard_fail_enabled() -> bool:
    """L77：审计写失败是否硬阻断（默认 1；=0 回退旧“只告警不阻断”行为）。"""
    raw = str(os.environ.get("RULEPROOF_AUDIT_HARD_FAIL", "1") or "").strip().lower()
    return _raw_on(raw)


def snapshot_v3_enabled() -> bool:
    """运行快照 v3 是否启用（默认 1）。与 version_snapshot.v3_enabled() 同一语义。"""
    return _raw_on(_snapshot_v3_raw())


def rollback_lever_state() -> dict:
    """回退杆机读状态（供启动守卫/测试/报告）。不改变任何行为。"""
    levers = []
    for env, label in _PROD_FORBIDDEN_LEVERS:
        if env == "RULEPROOF_SINGLE_ENTRY_FIX":
            raw = _single_entry_fix_raw()
        else:
            raw = _snapshot_v3_raw()
        levers.append({
            "env": env, "label": label, "value": raw, "enabled": _raw_on(raw),
            "prod_forbidden": True, "rollback": f"{env}=0",
        })
    return {"prod_env": PROD_ENV, "is_prod": is_prod(), "levers": levers,
            "off": [x for x in levers if not x["enabled"]]}


def production_switch_violations() -> list:
    """生产环境下违反“回退杆禁用”的开关列表（非 prod 恒为空）。"""
    if not is_prod():
        return []
    return rollback_lever_state()["off"]


def _rollback_audit_payload(violations: list) -> dict:
    return {"is_prod": is_prod(), "prod_env": PROD_ENV,
            "violations": violations,
            "audit_hard_fail": audit_hard_fail_enabled(),
            "note": ("非生产环境使用回退杆（已警告并审计）；生产环境同等配置会启动 fail-fast"
                     if not is_prod() else "生产环境回退杆（不应出现：启动守卫已 fail-fast）")}


def emit_rollback_lever_audit() -> bool:
    """非 prod 回退杆使用留痕（每个进程每种组合只写一次；失败仅 warning）。"""
    state = rollback_lever_state()
    off = state.get("off") or []
    if not off:
        return False
    key = tuple(sorted(f"{x['env']}={x['value']}" for x in off))
    if key in _ROLLBACK_AUDITED:
        return False
    _ROLLBACK_AUDITED.add(key)
    try:
        audit("single_entry.rollback_lever_used", "single_entry",
              _rollback_audit_payload(off))
        return True
    except Exception:  # noqa: BLE001 - 审计取证失败不影响主链（已 warning）
        _LOG.warning("rollback lever audit failed", exc_info=True)
        return False


def _warn_rollback_lever(env: str, raw: str, label: str) -> None:
    """非 prod 回退杆：warning（每进程每开关一次）+ 审计。"""
    if env not in _ROLLBACK_WARNED:
        _ROLLBACK_WARNED.add(env)
        _LOG.warning(
            "回退杆已启用：%s=%s（%s）→ 该路径回退旧行为；生产环境（%s=prod）会拒绝启动。",
            env, raw or "(空)", label, PROD_ENV)
        emit_rollback_lever_audit()


def _guard_rollback_levers() -> None:
    """L77 回退杆守卫：prod → ConfigError（fail-fast）；非 prod → warning+审计。"""
    state = rollback_lever_state()
    off = state.get("off") or []
    if not off:
        return
    if is_prod():
        names = "；".join(f"{x['env']}={x['value'] or '(空)'}" for x in off)
        raise ConfigError(
            "生产环境（RULEPROOF_ENV=prod）禁止启用回退杆：" + names
            + "。回退杆会一键撤防唯一执行出口/运行快照收紧，生产不可用；"
              "请恢复默认值（各开关=1）后重启。",
            detail={"violations": off, "is_prod": True})
    for x in off:
        _warn_rollback_lever(x["env"], x["value"], x["label"])


def assert_production_switches(emit_audit: bool = True) -> list:
    """启动期守卫：prod 回退杆 → 抛 ConfigError（退出码非 0）；非 prod → warning+审计。

    返回违规列表（prod 无违规/非 prod 均返回；调用方可记录）。CLI/HTTP 启动时必须调用。
    """
    state = rollback_lever_state()
    off = list(state.get("off") or [])
    if off and is_prod():
        _guard_rollback_levers()
    if off:
        for x in off:
            _warn_rollback_lever(x["env"], x["value"], x["label"])
        if emit_audit:
            emit_rollback_lever_audit()
    return off


def enabled() -> bool:
    """唯一出口修复是否启用（调用期读取，默认开）。

    L77：同时执行回退杆守卫——prod + 本开关=0（或 SNAPSHOT_V3=0）→ ConfigError
    fail-fast；非 prod 仅 warning+审计后返回旧行为（回退杆仍可用）。
    """
    raw = _single_entry_fix_raw()
    on = _raw_on(raw)
    _guard_rollback_levers()
    return on


def legacy_points_enabled() -> bool:
    """旧 points_path 回退是否被显式放行（只有精确 "1"）。

    注意：这是「适配器/脚本层」判定；产品可写侧入口（audit_orchestrator）还必须
    同时满足 :func:`legacy_points_deployment_enabled`（部署级二次确认）。
    """
    return os.environ.get(LEGACY_POINTS_ENV) == "1"


def legacy_points_deployment_enabled() -> bool:
    """L58 ②：部署级二次确认是否显式开启（只有精确 "1"）。"""
    return os.environ.get(LEGACY_POINTS_DEPLOY_ENV) == "1"


def legacy_points_switch_state() -> dict:
    """旧链开关机读状态（用于审计/报告/测试断言，不改变任何行为）。"""
    switch_set = os.environ.get(LEGACY_POINTS_ENV) == "1"
    deploy_set = legacy_points_deployment_enabled()
    return {
        "env": LEGACY_POINTS_ENV,
        "switch_set": switch_set,
        "deployment_env": LEGACY_POINTS_DEPLOY_ENV,
        "deployment_set": deploy_set,
        "deployment_required": True,
        "enabled": bool(switch_set and deploy_set),
        "default": "absent/off",
        "note": ("默认不存在；只有部署环境同时显式设置 "
                 f"{LEGACY_POINTS_ENV}=1 与 {LEGACY_POINTS_DEPLOY_ENV}=1 才放行旧链；"
                 "产品 audit 入口不读取/不传播该开关"),
    }


def product_entry_legacy_points_ignored(case_id: str,
                                        entry: str = "project.audit") -> dict:
    """L58 ②：产品 audit 入口不传播 legacy points 开关（只审计取证，不改变路径）。

    只有在「部署级已显式放行旧链」（两个 env 都在）时才写审计：证明产品入口即使
    身处启用旧链的部署，也仍走 manifest 主链、不把开关传播给本次审核。
    返回开关状态（调用方可不使用；失败不阻断主链）。
    """
    state = legacy_points_switch_state()
    try:
        if state.get("enabled"):
            audit("legacy.points_path_switch_ignored", str(case_id or ""), {
                "entry": str(entry or ""),
                "switch_state": state,
                "ignored": True,
                "note": "产品 audit 入口不读取/不传播 RULEPROOF_ALLOW_LEGACY_POINTS；"
                        "本次仍走 manifest 主链（旧链只能经 review_legacy 显式 "
                        "legacy=True 适配器）",
            })
    except Exception:  # noqa: BLE001 - 审计取证失败不影响主链
        _LOG.debug("product entry legacy points ignore audit skipped", exc_info=True)
    return state


def semantic_reaudit_single_path() -> bool:
    """L58 ①：语义重审是否走唯一执行体 manifest_exec.run（默认开）。"""
    raw = str(os.environ.get(SEMANTIC_REAUDIT_ENV, "1") or "").strip().lower()
    return raw not in ("0", "false", "no", "off", "disabled")


def semantic_reaudit_switch_state() -> dict:
    """语义重审开关现状（供测试/报告机读）。"""
    on = semantic_reaudit_single_path()
    return {"env": SEMANTIC_REAUDIT_ENV, "value": os.environ.get(SEMANTIC_REAUDIT_ENV, "1"),
            "enabled": on, "default": "1", "rollback": f"{SEMANTIC_REAUDIT_ENV}=0",
            "execution_path": ("manifest_exec.run" if on
                               else "semantic_core.manual_executor(second executor)")}


def audit(action: str, object_: str, payload: dict | None = None,
          actor: str = "system") -> bool:
    """写一条显式审计（尽力而为；失败留日志，不改变调用方业务结果）。"""
    try:
        from .. import repositories as R
        R.audit_logs.log(actor=actor or "system", action=str(action or ""),
                         object=str(object_ or ""),
                         after=json.dumps(payload or {}, ensure_ascii=False, default=str))
        return True
    except Exception:  # noqa: BLE001 - 审计失败不得静默：写 warning 并返回 False
        _LOG.warning("single_entry audit failed action=%s object=%s",
                     action, object_, exc_info=True)
        return False


def annotate(out: dict, **fields) -> dict:
    """在返回结果上标注唯一出口口径（幂等；不覆盖调用方已给出的同名字段）。"""
    if isinstance(out, dict):
        out.setdefault("single_entry_fix", enabled())
        for k, v in fields.items():
            out.setdefault(k, v)
        if enabled():
            out.setdefault("execution_entry_contract",
                           "唯一执行出口：manifest.freeze → manifest_exec.run"
                           "（含 manifest.executed 审计）→ finding/报告")
    return out


class ManifestExecutionBlocked(RuntimeError):
    """冻结清单执行被阻断/0 执行：审核必须失败，不得静默归零为“待复核”。

    L77：``code``/``http_status``/``remediation`` 可按场景覆盖（例如 manifest.executed
    审计写失败 → code=audit_write_failed），HTTP/CLI 直接读实例字段，保证错误码同源。
    """

    code = "manifest_execution_blocked"
    http_status = 409
    remediation = ("检查冻结闭包/解析冻结产物（RULEPROOF_FREEZE_PARSE 等）后重试；"
                   "开启 RULEPROOF_SINGLE_ENTRY_FIX=0 可回退旧行为（不推荐）")

    def __init__(self, message: str, detail: dict | None = None, *,
                 code: str = "", http_status: int = 0, remediation: str = ""):
        self.detail = dict(detail or {})
        if code:
            self.code = str(code)
        if http_status:
            self.http_status = int(http_status)
        if remediation:
            self.remediation = str(remediation)
        super().__init__(str(message or "冻结清单执行被阻断"))

    def to_dict(self) -> dict:
        return {
            "ok": False,
            "error": str(self),
            "code": self.code,
            "status": int(self.http_status),
            "detail": self.detail,
            "remediation": self.remediation,
        }


def _last_run(case_id: str) -> dict:
    """案件最近一次审核批次行（只读；失败返回空 dict）。"""
    cid = str(case_id or "")
    if not cid:
        return {}
    try:
        from .. import db
        with db.session() as c:
            row = c.execute(
                "SELECT * FROM audit_run WHERE case_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1", (cid,)).fetchone()
        return dict(row) if row else {}
    except Exception:  # noqa: BLE001
        _LOG.debug("single_entry last_run query failed case=%s", cid, exc_info=True)
        return {}


def case_has_manifest(case_id: str) -> bool:
    """案件是否已有冻结清单（manifest 主链）；用于收紧 legacy compat 豁免。"""
    cid = str(case_id or "")
    if not cid:
        return False
    run = _last_run(cid)
    if str(run.get("manifest_id") or "").strip():
        return True
    try:
        from .. import db
        with db.session() as c:
            row = c.execute("SELECT 1 FROM audit_manifest WHERE case_id=? LIMIT 1",
                            (cid,)).fetchone()
        return bool(row)
    except Exception:  # noqa: BLE001
        _LOG.debug("single_entry manifest query failed case=%s", cid, exc_info=True)
        return False


def legacy_run_without_manifest(case_id: str) -> bool:
    """案件最近批次是 legacy 链路且没有 manifest（报告禁止签发口径）。

    判据（全部满足）：
    - case.compat_mode == legacy（legacy 适配器显式创建）；
    - 存在最近审核批次（last_run 不存在时不算，避免误伤纯夹具/门禁探针）；
    - 该批次 manifest_id 为空。
    """
    cid = str(case_id or "")
    if not cid:
        return False
    try:
        from .. import repositories as R
        case = R.cases.get(cid) or {}
    except Exception:  # noqa: BLE001
        return False
    if str(case.get("compat_mode") or "") != "legacy":
        return False
    run = _last_run(cid)
    if not run:
        return False
    return not str(run.get("manifest_id") or "").strip()


def fix_flag() -> dict:
    """开关现状（供测试/报告机读；L77 追加审计硬阻断与回退杆生产禁用状态）。"""
    return {"env": ENV, "value": _single_entry_fix_raw(), "enabled": enabled(),
            "default": "1", "rollback": f"{ENV}=0",
            "legacy_points_env": LEGACY_POINTS_ENV,
            "legacy_points_enabled": legacy_points_enabled(),
            # L77 新增
            "audit_hard_fail_env": AUDIT_HARD_FAIL_ENV,
            "audit_hard_fail": audit_hard_fail_enabled(),
            "snapshot_v3_env": SNAPSHOT_V3_ENV,
            "snapshot_v3": snapshot_v3_enabled(),
            "prod_env": PROD_ENV,
            "is_prod": is_prod(),
            "prod_rollback_forbidden": list(_PROD_FORBIDDEN_LEVERS),
            "rollback_lever_state": rollback_lever_state()}
