"""数据层只读体检：DB 大小 / WAL / 表行数 / JSON 字段一致性。

只读：不写库、不建表、不修数据。JSON 一致性检查使用 SQLite JSON1 的
``json_valid``；极老 SQLite 没有 JSON1 时退化为 Python ``json.loads``。
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path

# 已知 JSON 文本列。只检查实际存在的表/列；不存在的自动跳过。
JSON_COLUMNS = {
    "template": ("schema_json",),
    "rule": ("scope_json",),
    "rule_version": ("slots_json", "evidence_json", "tests_json"),
    "audit_run": ("trace_json", "plan_json"),
    "report": ("summary_json", "signatures_json"),
    "decision_table": ("rules_json", "scope_types"),
    "decision_table_version": ("rules_json",),
    "agent": ("profile_json",),
    "agent_version": ("tools_json",),
    "agent_run": ("result_json",),
    "agent_node_run": ("input_json", "output_json"),
    "eval_set": ("golden_json",),
    "eval_run": ("metrics_json",),
    "notify_setting": ("config_json",),
    "rsi_candidate": ("before_json", "after_json"),
    "rule_param": ("params_json", "pending_json"),
    "onto_entity": ("props_json",),
    "onto_version": ("snapshot_json", "health_json"),
    "open_task_queue": ("payload_json",),
    "open_event": ("payload",),
    "audit_log": ("before_json", "after_json"),
    "audit_manifest": ("objects_json", "rules_json", "items_json"),
    "auditpoint_confirmation": ("scope_json",),
    "manifest_result": ("d1_json", "d2_json", "d3_json", "d4_json", "d5_json"),
    "manifest_evidence": ("checklist_json",),
    "business_term": ("synonyms_json", "not_equal_json", "relations_json"),
    "doc_type_custom": ("aliases_json", "audit_types_json", "point_ids_json"),
    "workspace": ("settings_json",),
    "finding": ("occurrence_ids_json",),
    "llm_trace": ("messages_json", "evidence_ids"),
    "point_state": (),
}


def table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                                 (table,)).fetchone())
    except sqlite3.Error:
        return False


def columns(conn: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {str(r[1]) for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}
    except sqlite3.Error:
        return set()


def _json1(conn: sqlite3.Connection) -> bool:
    try:
        return conn.execute("SELECT json_valid('{}')").fetchone()[0] == 1
    except sqlite3.Error:
        return False


def json_consistency(conn: sqlite3.Connection, sample_limit: int = 3) -> dict:
    """检查 JSON 列能否被解析；空串/NULL 视为“无值”，不算坏数据。"""
    has_json1 = _json1(conn)
    checked_cols = 0
    checked_rows = 0
    invalid_count = 0
    samples: list[dict] = []
    errors: list[str] = []
    for table, cols in JSON_COLUMNS.items():
        if not cols or not table_exists(conn, table):
            continue
        have = columns(conn, table)
        for col in cols:
            if col not in have:
                continue
            checked_cols += 1
            qcol = '"' + col.replace('"', '""') + '"'
            qtable = '"' + table.replace('"', '""') + '"'
            try:
                checked_rows += int(conn.execute(
                    f"SELECT COUNT(*) FROM {qtable} WHERE {qcol} IS NOT NULL "
                    f"AND TRIM({qcol})<>''").fetchone()[0])
            except sqlite3.Error as exc:
                errors.append(f"{table}.{col}: {exc}")
                continue
            if has_json1:
                try:
                    bad = int(conn.execute(
                        f"SELECT COUNT(*) FROM {qtable} WHERE {qcol} IS NOT NULL "
                        f"AND TRIM({qcol})<>'' AND json_valid({qcol})=0").fetchone()[0])
                    invalid_count += bad
                    if bad and len(samples) < sample_limit * 5:
                        rows = conn.execute(
                            f"SELECT rowid AS _rowid, {qcol} AS _v FROM {qtable} "
                            f"WHERE {qcol} IS NOT NULL AND TRIM({qcol})<>'' "
                            f"AND json_valid({qcol})=0 LIMIT ?",
                            (sample_limit,)).fetchall()
                        for r in rows:
                            if len(samples) >= sample_limit * 5:
                                break
                            samples.append({"table": table, "column": col,
                                            "rowid": r["_rowid"],
                                            "preview": str(r["_v"])[:120]})
                except sqlite3.Error as exc:
                    errors.append(f"{table}.{col} count: {exc}")
            else:
                # 极老 SQLite 退化路径：只抽样检查，避免全表搬进 Python
                try:
                    rows = conn.execute(
                        f"SELECT rowid AS _rowid, {qcol} AS _v FROM {qtable} "
                        f"WHERE {qcol} IS NOT NULL AND TRIM({qcol})<>'' LIMIT 5000").fetchall()
                    for r in rows:
                        try:
                            json.loads(r["_v"])
                        except Exception:
                            invalid_count += 1
                            if len(samples) < sample_limit * 5:
                                samples.append({"table": table, "column": col,
                                                "rowid": r["_rowid"],
                                                "preview": str(r["_v"])[:120]})
                except sqlite3.Error as exc:
                    errors.append(f"{table}.{col} scan: {exc}")
    return {
        "available": True,
        "engine": "sqlite-json1" if has_json1 else "python-json",
        "checked_columns": checked_cols,
        "checked_rows": checked_rows,
        "invalid_count": invalid_count,
        "samples": samples,
        "errors": errors,
        "note": "空串/NULL 视为无值，不计入坏数据",
    }


def table_rows(conn: sqlite3.Connection) -> list[dict]:
    try:
        names = [str(r[0]) for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
    except sqlite3.Error:
        return []
    out = []
    for name in names:
        q = '"' + name.replace('"', '""') + '"'
        try:
            n = int(conn.execute(f"SELECT COUNT(*) FROM {q}").fetchone()[0])
            out.append({"name": name, "rows": n})
        except sqlite3.Error as exc:
            out.append({"name": name, "rows": None, "error": f"{type(exc).__name__}: {exc}"})
    return out


def db_stats(conn: sqlite3.Connection, db_path: str | Path) -> dict:
    path = Path(db_path).resolve()
    try:
        size = path.stat().st_size
    except OSError:
        size = None
    wal = Path(str(path) + "-wal")
    shm = Path(str(path) + "-shm")
    try:
        journal_mode = str(conn.execute("PRAGMA journal_mode").fetchone()[0]).lower()
    except sqlite3.Error:
        journal_mode = ""
    try:
        page_count = int(conn.execute("PRAGMA page_count").fetchone()[0])
    except sqlite3.Error:
        page_count = None
    try:
        page_size = int(conn.execute("PRAGMA page_size").fetchone()[0])
    except sqlite3.Error:
        page_size = None
    try:
        freelist = int(conn.execute("PRAGMA freelist_count").fetchone()[0])
    except sqlite3.Error:
        freelist = None
    try:
        index_count = int(conn.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='index' "
            "AND name NOT LIKE 'sqlite_autoindex%'").fetchone()[0])
    except sqlite3.Error:
        index_count = None
    tables = table_rows(conn)
    return {
        "path": str(path),
        "exists": path.exists(),
        "size_bytes": size,
        "wal_bytes": wal.stat().st_size if wal.exists() else 0,
        "shm_bytes": shm.stat().st_size if shm.exists() else 0,
        "journal_mode": journal_mode,
        "page_count": page_count,
        "page_size": page_size,
        "freelist_pages": freelist,
        "table_count": len(tables),
        "index_count": index_count,
        "tables": tables,
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
