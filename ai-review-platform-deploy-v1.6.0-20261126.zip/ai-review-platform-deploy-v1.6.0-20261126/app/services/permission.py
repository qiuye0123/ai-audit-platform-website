# -*- coding: utf-8 -*-
"""权限五层：菜单 / 路由 / 按钮 / 数据 / API（按角色输出）——**派生自单一事实源**。

T-199（2026-11-20）起本模块不再手写 ``ALL_MENUS``/``ROLE_PERMS``：
``app/services/permission_registry.py`` 是唯一 authoring 面；
``/api/v1/me/permissions``、前端菜单/按钮、CLI 动作校验全部从注册表派生。
DB 的 ``permission``/``role_permission`` 表是注册表的缓存/种子（见
``app/services/permissions.ensure_seed``），不是第二事实源。
"""
from . import permission_registry as _reg

# 左侧导航菜单 code（唯一事实源：permission_registry.VIEW_ITEMS kind=nav）
ALL_MENUS = list(_reg.menu_codes())

# 角色权限矩阵（唯一事实源：permission_registry.ROLE_POINTS / VIEW_ITEMS）
ROLE_PERMS = _reg.role_perms_matrix()


def permissions(role: str) -> dict:
    """角色权限视图（fail-closed）。

    L92（L88 G02/G08）：修复前未知/已删除角色回退 ``menus=["home"]``，等于给未知
    角色一个可见入口。现在未知角色只返回空菜单/空动作，并显式带 ``known_role=False``
    （查询态字段，不进入 ROLE_PERMS，门禁 B4 仍要求矩阵与注册表逐字段相等）。
    """
    r = str(role or "").strip()
    p = ROLE_PERMS.get(r)
    if p is None:
        return {"role": r, "menus": [], "actions": [], "known_role": False}
    return {"role": r, "menus": list(p["menus"]), "actions": list(p["actions"])}


def can(role: str, action: str) -> bool:
    """角色是否能执行动作；未知角色一律 False（super_admin 由通配 ``*`` 持有）。"""
    p = ROLE_PERMS.get(str(role or "").strip())
    if p is None:
        return False
    return "*" in p["actions"] or action in p["actions"]
