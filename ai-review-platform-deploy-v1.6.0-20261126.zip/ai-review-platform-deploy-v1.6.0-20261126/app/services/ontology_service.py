# -*- coding: utf-8 -*-
"""本体统一门面（T-200：本体 7 模块 → 1 门面）。

**唯一对外入口**：业务代码（review / manifest / manifest_exec / ruleexec / project / cli /
server 等）只允许 ``from app.services import ontology_service``，不得直接 import 下面
7 个内部实现模块。内部模块互相调用不受限制；本文件是它们与业务层之间唯一的适配层。

内部模块职责边界
----------------
=======  =====  ==========================================  =============================================
模块     行数   职责（唯一事实源）                            门面导出（业务可见）
=======  =====  ==========================================  =============================================
ontology_v2       464  全局本体图：实体/别名/关系/单位、归一化规则、    load_entities / alias_index / normalization_rules /
                       契约哈希、v2 图校验与发布、冲突/覆盖度/候选发现  contract_hash / validate / publish_graph /
                                                                    detect_conflicts / coverage / discover_candidates / resolve
ontology_assets   500  平台共享层 + 租户扩展层的资产读写（实体/别名/关系）， create_entity / update_entity / delete_entity /
                       跨租户 404、8 类写操作与业务同事务写审计           create_alias / update_alias / delete_alias /
                                                                    create_link / delete_link / admin_view / visible_* /
                                                                    version_visible / AUDIT_ACTIONS
ontology_control 1090  per-space 开关（默认关）、能力清单与创建契约、一致性  effective / set_control / switch_report /
                       能力（跨文档一致性）、影子评估与自动开关、审计       capabilities / consumption_enabled / module_on /
                       （ontology.auto_eval / ontology.switch_changed）    cross_doc_allowed / d4_aliases_allowed /
                                                                    normalize_* / clear_execution_capability /
                                                                    point_class / neutralize_manifest_ontology /
                                                                    record_audit_shadow / submit_shadow_labels /
                                                                    evaluate_round / evaluate_from_shadow /
                                                                    maybe_auto_evaluate
ontology_ops        195  版本快照 + 发布门禁（健康度/术语门禁）+ 术语门禁    snapshot / list_versions / publish_version / term_gate
                       单一口径（冻结与发布共用）
ontology_workspace  318  工作空间本体建模：候选自动发现、人工维护、阈值、   workspace_status / discover / maybe_auto_discover /
                       本空间别名归一（待确认不进入主链）                 add_manual / set_term / save_threshold /
                                                                    workspace_alias_pairs / workspace_settings /
                                                                    workspace_terms / save_workspace_settings
ontology_gate       120  别名门槛：客户表述 → 标准实体名归一并显式返回       gate_aliases / gate_overrides / gate_static_aliases /
                       未命中；已发布 override 读写                        normalize / normalize_many
ontology_impact      46  术语变更影响面：规则/决策表/智能体/审核点           impact
=======  =====  ==========================================  =============================================

口径与约束
----------
1. **开关**：本体消费默认关、按空间开（``workspace.settings_json["ontology"]``），
   所有消费点必须先经 ``effective()`` / ``consumption_enabled()``；门面不绕过开关。
2. **审计**：实体/别名/关系 8 类写操作在 ``ontology_assets`` 内用 ``audit.log_in_tx``
   **与业务写同一事务**落 ``audit_log``；动作名见 ``AUDIT_ACTIONS``，不得绕过门面直写。
3. **租户**：资产读写按当前 ctx 过滤（共享层 NULL + 本租户扩展层），跨租户统一 404；
   工作空间本体按工作空间隔离；门面不做任何跨租户聚合。
4. **冻结**：D4 冻结别名来自 ``manifest._ontology_binding``，读取面即本门面的
   ``gate_aliases`` / ``workspace_alias_pairs`` / ``alias_index``；冻结后实时变化不回流。
5. **约束测试**：``scripts/qa/ontology_facade_test.py`` 用 AST 断言 ``app/`` 内除本文件、
   7 个内部模块及其互调外，0 处直接 import 内部模块（``app/api/server.py`` 为并行任务
   占用、暂列豁免，见 ``docs/qa/本体门面与死代码清理_20261120.md``）。
"""

from __future__ import annotations

import json

# ---------------------------------------------------------------- 内部实现（仅门面可使用）
from . import ontology_assets as _assets
from . import ontology_control as _control
from . import ontology_gate as _gate
from . import ontology_v2 as _v2
from . import ontology_workspace as _workspace
from .ontology_impact import impact
from .ontology_ops import list_versions, snapshot, term_gate
from .ontology_ops import publish as publish_version
from .ontology_v2 import (
    alias_index,
    alias_index_raw,
    contract_hash,
    coverage,
    detect_conflicts,
    discover_candidates,
    normalization_rules,
    publish as publish_graph,
    resolve,
    validate,
)
from .ontology_gate import normalize, normalize_many
from .ontology_workspace import (
    add_manual,
    discover,
    maybe_auto_discover,
    save_threshold,
    set_term,
)
from .ontology_control import (
    capabilities,
    clear_execution_capability,
    consumption_enabled,
    cross_doc_allowed,
    d4_aliases_allowed,
    effective,
    env_enabled,
    evaluate_from_shadow,
    evaluate_round,
    maybe_auto_evaluate,
    module_on,
    neutralize_manifest_ontology,
    normalize_cross_doc_config,
    normalize_execution_slots,
    point_class,
    record_audit_shadow,
    set_control,
    stored_control,
    submit_shadow_labels,
    switch_report,
)
from .ontology_assets import (
    admin_view,
    create_alias,
    create_entity,
    create_link,
    delete_alias,
    delete_entity,
    delete_link,
    update_alias,
    update_entity,
    version_visible,
    visible_aliases,
    visible_entities,
    visible_links,
)

# ---------------------------------------------------------------- 审计口径
# 实体/别名/关系写操作的 audit_log.action 全集（ontology_assets 内同事务写入）。
AUDIT_ACTIONS = (
    "ontology.entity_created",
    "ontology.entity_updated",
    "ontology.entity_deleted",
    "ontology.alias_created",
    "ontology.alias_updated",
    "ontology.alias_deleted",
    "ontology.link_created",
    "ontology.link_deleted",
)


# ---------------------------------------------------------------- 组合读取（跨内部模块的单一取数口）
def load_entities() -> dict:
    """全局本体图实体表（ontology_v2 运行时快照的 entities 段；不读 DB 资产表）。"""
    return (_v2._load() or {}).get("entities") or {}


def gate_aliases() -> tuple:
    """(静态别名表, 已发布 override)，与 D4 冻结同一取数口径。"""
    return (dict(getattr(_gate, "ALIASES", {}) or {}), _gate._load_overrides() or {})


def gate_overrides() -> dict:
    """已发布别名 override（docs/blind/ontology_overrides.json；空间本体关闭时返回 {}）。"""
    return _gate._load_overrides() or {}


def gate_overrides_raw() -> dict:
    """已发布别名 override 原始文件（忽略空间开关；仅供受控回滚读取数据面）。"""
    path = str(getattr(_gate, "OVERRIDES", "") or "")
    if not path:
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.loads(fh.read() or "{}")
    except (OSError, TypeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def restore_gate_aliases(canonical: str, aliases: list) -> dict:
    """把指定 canonical 的别名集合恢复到 aliases（L131 自进化回滚专用；保留其它实体）。

    只经门面写 ontology_gate override 文件并重建索引，调用方负责审计/事务边界。
    """
    data = dict(gate_overrides_raw())
    canonical = str(canonical or "")
    desired = [str(x) for x in (aliases or []) if str(x).strip()]
    before = [str(x) for x in (data.get(canonical) or []) if str(x).strip()]
    if desired:
        data[canonical] = desired
    else:
        data.pop(canonical, None)
    _gate._save_overrides(data)
    _gate._rebuild()
    return {"canonical": canonical, "before": before, "after": desired}


def gate_static_aliases() -> dict:
    """静态最小别名集（ontology_gate.ALIASES 的拷贝，避免调用方改动全局常量）。"""
    return dict(getattr(_gate, "ALIASES", {}) or {})


def workspace_alias_pairs(ws_id: str = "") -> dict:
    """工作空间已确认术语别名对 alias -> canonical（未确认候选不进入）。"""
    return _workspace.alias_pairs(ws_id)


def workspace_status() -> dict:
    """工作空间本体建模状态（术语/候选/阈值/别名，供 CLI/HTTP 只读展示）。"""
    return _workspace.status()


def workspace_settings(ws_id: str) -> dict:
    """工作空间设置字典（只读用途；写请用 save_workspace_settings）。"""
    return _workspace._settings(ws_id)


def workspace_terms(settings: dict) -> list:
    """从工作空间设置中取本体术语列表（terms 投影读侧）。"""
    return _workspace._terms(settings)


def save_workspace_settings(ws_id: str, patch: dict) -> dict:
    """更新工作空间设置（词典投影写侧；调用方负责业务事务/审计口径）。"""
    return _workspace._save_settings(ws_id, patch)


__all__ = [
    # 读取 / 归一化 / 一致性能力
    "load_entities", "alias_index", "alias_index_raw", "normalization_rules",
    "contract_hash", "resolve", "detect_conflicts", "discover_candidates",
    "coverage", "validate", "publish_graph", "gate_aliases", "gate_overrides",
    "gate_static_aliases", "gate_overrides_raw", "restore_gate_aliases",
    "normalize", "normalize_many", "workspace_alias_pairs",
    # 工作空间本体（人工维护 / 自动发现 / 投影读写）
    "workspace_status", "discover", "maybe_auto_discover", "add_manual", "set_term",
    "save_threshold", "workspace_settings", "workspace_terms", "save_workspace_settings",
    # 实体/别名/关系 CRUD（租户隔离 + 同事务审计）
    "admin_view", "visible_entities", "visible_aliases", "visible_links",
    "version_visible", "create_entity", "update_entity", "delete_entity",
    "create_alias", "update_alias", "delete_alias", "create_link", "delete_link",
    "AUDIT_ACTIONS",
    # 开关 / 自动评估 / 一致性能力契约
    "env_enabled", "module_on", "stored_control", "effective", "set_control",
    "switch_report", "capabilities", "consumption_enabled", "cross_doc_allowed",
    "d4_aliases_allowed", "normalize_cross_doc_config",
    "normalize_execution_slots", "clear_execution_capability", "point_class",
    "neutralize_manifest_ontology", "record_audit_shadow", "submit_shadow_labels",
    "evaluate_round", "evaluate_from_shadow", "maybe_auto_evaluate",
    # 冻结快照 / 版本发布 / 术语门禁
    "snapshot", "list_versions", "publish_version", "term_gate",
    # 影响分析
    "impact",
]
