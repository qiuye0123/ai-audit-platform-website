# -*- coding: utf-8 -*-
"""L155 字段级置信度校准与分级路由（确定性 / 0 模型 / 纯标准库）。

依据：`/tmp/2026_99.txt` §"字段级置信度校准（Confidence Calibration）"——
大模型自报置信度不可靠，生产级校准需要综合确定性信号，并且**不同风险等级的字段
使用独立阈值**（示例：金额 / 账号 / 主体标识等核心字段 ≥0.98 才直通 STP，备注类
非核心字段可放宽到 0.85）。

本模块只使用「当前输入能拿到」的信号（不虚构 Logprobs / 独立校验模型）：

1. ``original_hit``        原文命中：抽取值是否为原文合法子串（来自 Verifier）；
2. ``locatable``           坐标可定位：span 校验通过 / 引文唯一出现（来自 Verifier）；
3. ``unit_range``          单位 / 范围：单位量纲与换算一致、数值在合法区间；
4. ``cross_field``         跨字段：明细合计=总额、日期先后、单位换算一致性断言通过；
5. ``sample_consistency``  多采样自洽：同一字段多次抽取值的一致率（**可选输入**；
   当前主链还没有多采样通道，缺省时该信号记为不可用并在覆盖率中折减，不假装有）。

校准方法（启发式、确定性、可复现；**未用标注数据训练**，不能宣称统计意义上的概率校准）：

1. 每个信号取值 ∈ [0,1]（``None`` = 该信号不可用，不参与加权也不当通过）；
2. ``evidence = Σ(w·s)/Σw``（仅可用信号）；``coverage = Σ(可用 w)/Σ(全部 w)``；
3. 覆盖率收缩：``calibrated = 0.5 + (evidence-0.5) * (0.4 + 0.6*coverage)``，
   即证据不足时向 0.5 收缩，证据齐全时才允许逼近 1.0；
4. verdict 上限（fail-closed）：``fail`` ≤ 0.10、``insufficient`` ≤ 0.45；
5. 分级路由：``confidence ≥ threshold[字段风险等级]`` → ``stp``（直通），
   否则 ``review``（人工复核）；``fail`` → ``review``；``insufficient`` → ``re_extract``。

阈值（与 2026_99 §4 同口径，可按业务配置覆盖）：
``core = 0.98``（金额 / 账号 / 主体标识 / 证件 / 合同编号等）、``normal = 0.85``。

契约（HTTP 层）：``POST /api/v1/extraction/verify`` 的响应 ``confidence`` 段即
:func:`score_extraction` 的返回；``GET /api/v1/extraction/confidence-policy`` 返回
:func:`confidence_policy`。两接口只读、不写库、不调模型。
"""
from __future__ import annotations

import re
import unicodedata

CONFIDENCE_POLICY_VERSION = "l155/v1"

#: 核心（高风险）字段阈值；与 2026_99 §4 示例一致
CORE_THRESHOLD = 0.98
#: 普通字段阈值
NORMAL_THRESHOLD = 0.85
THRESHOLDS = {"core": CORE_THRESHOLD, "normal": NORMAL_THRESHOLD}

#: 信号权重（总和 = 1.0）；多采样自洽权重最高，但当前主链拿不到时按覆盖率折减
SIGNAL_WEIGHTS = {
    "original_hit": 0.24,
    "locatable": 0.18,
    "unit_range": 0.16,
    "cross_field": 0.16,
    "sample_consistency": 0.26,
}
_TOTAL_WEIGHT = sum(SIGNAL_WEIGHTS.values())

#: 覆盖率收缩参数：evidence → calibrated 的斜率下限（coverage=0 时 0.4）
_COVERAGE_STRETCH = 0.4
_NEUTRAL = 0.5
#: verdict 上限：矛盾/不可验证的字段不得因为信号表面全绿而拿到高置信
VERDICT_CAPS = {"fail": 0.10, "insufficient": 0.45}

#: 核心字段清单（金额 / 账号 / 主体标识 / 证件 / 编号类）
CORE_FIELD_KEYS = frozenset({
    "amount", "contract_amount", "total_amount", "tax_amount", "budget", "price",
    "unit_price", "total_price", "account", "account_no", "bank_account",
    "bank_account_no", "subject_id", "subject_identifier", "credit_code",
    "unified_social_credit_code", "tax_no", "taxpayer_id", "id_card", "id_no",
    "contract_no", "certificate_no", "party_a", "party_b", "supplier",
    "customer", "company_name", "legal_person", "legal_representative",
})
#: 中文字段名/标签的关键词线索（命中即按核心字段处理）
CORE_FIELD_HINTS = (
    "金额", "总价", "合计", "价款", "单价", "账号", "卡号", "账户",
    "税号", "信用代码", "身份证", "证件", "编号", "号码",
    "主体", "甲方", "乙方", "供应商", "客户", "公司名称", "法人", "银行",
)
#: 明确按普通字段处理的备注/说明类（即使命中“金额”等词也不升级为核心）
NORMAL_FIELD_HINTS = ("备注", "说明", "描述", "摘要", "意见", "建议", "联系人", "联系电话")

_NUM_RE = re.compile(r"[+-]?(?:\d{1,3}(?:[,，]\d{3})+|\d+)(?:\.\d+)?")
_DATE_RE = re.compile(r"(\d{4})\s*[年\-/\.]\s*(\d{1,2})\s*[月\-/\.]\s*(\d{1,2})")


def _s(value) -> str:
    return "" if value is None else str(value)


def _norm_value(value, risk_type: str = ""):
    """样本/字段值归一（用于多采样自洽比较）：数值去千分位、日期统一 ISO、文本折叠空白。"""
    s = _s(value).strip()
    if not s:
        return ""
    if risk_type in ("number", "percent", "range", "limit"):
        m = _NUM_RE.search(s.replace("，", ""))
        if m:
            try:
                return round(float(m.group(0).replace(",", "")), 6)
            except (TypeError, ValueError):
                return s
        return unicodedata.normalize("NFKC", s)
    m = _DATE_RE.search(s)
    if m:
        try:
            return "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except (TypeError, ValueError):
            return s
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s)).strip()


def resolve_risk_class(field: dict, spec: dict | None = None) -> str:
    """字段风险等级：``core``（高风险 / 核心字段）或 ``normal``。

    优先级：spec.risk > field.risk > 核心键名清单 > 标签/键名关键词 > normal。
    备注/说明类标签可显式降级为 normal（避免“备注金额”这类误升级）。
    """
    spec = spec or {}
    for source in (spec, field):
        v = _s(source.get("risk") if isinstance(source, dict) else "")
        if v in ("core", "normal"):
            return v
    key = _s(field.get("key")).strip().lower()
    label = _s(field.get("label"))
    text = key + " " + label
    if any(h in text for h in NORMAL_FIELD_HINTS) and not any(
            h in key for h in ("amount", "account", "credit", "tax")):
        return "normal"
    if key in CORE_FIELD_KEYS:
        return "core"
    if any(h in text for h in CORE_FIELD_HINTS):
        return "core"
    return "normal"


def _sample_signal(samples, value, field_type: str) -> tuple:
    """多采样自洽度：抽取值在样本中的一致率 → (value|None, detail dict)。"""
    if not isinstance(samples, (list, tuple)) or len(samples) < 2:
        return None, {"available": False,
                      "reason": "样本 <2 条（当前主链无多采样通道，信号不可用）"}
    ref = _norm_value(value, field_type)
    norms = [_norm_value(s, field_type) for s in samples]
    n = len(norms)
    agree = sum(1 for x in norms if x == ref)
    # 参考值为空（空抽取值）时用众数一致率，避免把“全都空”当高自洽
    if ref == "":
        counts = {}
        for x in norms:
            counts[x] = counts.get(x, 0) + 1
        agree = max(counts.values()) if counts else 0
    score = round(agree / n, 4) if n else 0.0
    detail = {"available": True, "n_samples": n, "agree": agree,
              "score": score, "reference": _s(ref)[:120],
              "distribution": {_s(k)[:80]: v for k, v in
                               sorted(_distribution(norms).items())}}
    return score, detail


def _distribution(items: list) -> dict:
    out = {}
    for x in items:
        key = _s(x)
        out[key] = out.get(key, 0) + 1
    return out


def _locatable_signal(verification: dict) -> tuple:
    """坐标可定位信号：span 校验 / 引文唯一定位 → (value|None, detail)。"""
    ev = verification.get("evidence") or {}
    span_ok = ev.get("span_ok")
    quote = _s(ev.get("quote"))
    occurrences = ev.get("occurrences")
    quote_found = bool(ev.get("quote_found"))
    if span_ok is True:
        return 1.0, {"available": True, "reason": "span 校验通过",
                     "span_ok": True, "start": ev.get("start"), "end": ev.get("end")}
    if span_ok is False:
        return 0.0, {"available": True, "reason": "span 与引文/值不一致",
                     "span_ok": False}
    if quote and quote_found and occurrences == 1:
        return 1.0, {"available": True, "reason": "引文在原文唯一出现",
                     "occurrences": 1}
    if quote and quote_found:
        return 0.5, {"available": True, "reason": "引文多次出现，坐标不唯一",
                     "occurrences": occurrences}
    if quote and not quote_found:
        return 0.0, {"available": True, "reason": "引文在原文中找不到"}
    return None, {"available": False,
                  "reason": "未提供 quote/start/end，坐标可定位信号不可用"}


def _unit_range_signal(verification: dict) -> tuple:
    unit_ok = verification.get("unit_ok")
    range_ok = verification.get("range_ok")
    fails = [x for x in (unit_ok, range_ok) if x is False]
    if fails:
        return 0.0, {"available": True, "unit_ok": unit_ok, "range_ok": range_ok,
                     "reason": "单位或范围校验失败"}
    if unit_ok is True or range_ok is True:
        return 1.0, {"available": True, "unit_ok": unit_ok, "range_ok": range_ok,
                     "reason": "单位/范围校验通过"}
    return None, {"available": False, "unit_ok": unit_ok, "range_ok": range_ok,
                  "reason": "该字段无单位/范围约束（不适用）"}


def _cross_field_signal(verification: dict) -> tuple:
    """跨字段信号：断言通过=1；有断言但不可判定=0（数据缺口，不能算通过）。"""
    ok = verification.get("cross_field_ok")
    cross = verification.get("cross_field") or {}
    assertions = cross.get("assertions") or []
    if ok is True:
        return 1.0, {"available": True, "n_assertions": len(assertions),
                     "reason": "跨字段断言全部通过"}
    if ok is False:
        return 0.0, {"available": True, "n_assertions": len(assertions),
                     "reason": "跨字段断言存在冲突"}
    if assertions:
        return 0.0, {"available": True, "n_assertions": len(assertions),
                     "reason": "跨字段断言存在不可判定项（证据不足）"}
    return None, {"available": False, "n_assertions": 0,
                  "reason": "无跨字段断言（不适用）"}


def signals_from_verification(verification: dict, field: dict | None = None,
                              samples=None) -> dict:
    """Verifier 单字段结果 → 5 个校准信号（``{name: {"value","weight","detail"}}``）。"""
    field = field or {}
    field_type = _s(verification.get("type") or field.get("type"))
    value = verification.get("value", field.get("value"))
    hit = verification.get("is_substring")
    if hit is None and (value is None or _s(value).strip() == ""):
        hit = None
    hit_detail = {"available": hit is not None,
                  "reason": ("原文命中" if hit is True else
                             "未命中原文" if hit is False else "空值/无文档，原文命中不可用")}
    loc_val, loc_detail = _locatable_signal(verification)
    ur_val, ur_detail = _unit_range_signal(verification)
    cf_val, cf_detail = _cross_field_signal(verification)
    sm_val, sm_detail = _sample_signal(samples, value, field_type)
    return {
        "original_hit": {"value": None if hit is None else (1.0 if hit else 0.0),
                         "weight": SIGNAL_WEIGHTS["original_hit"],
                         "detail": hit_detail},
        "locatable": {"value": loc_val, "weight": SIGNAL_WEIGHTS["locatable"],
                      "detail": loc_detail},
        "unit_range": {"value": ur_val, "weight": SIGNAL_WEIGHTS["unit_range"],
                       "detail": ur_detail},
        "cross_field": {"value": cf_val, "weight": SIGNAL_WEIGHTS["cross_field"],
                        "detail": cf_detail},
        "sample_consistency": {"value": sm_val,
                               "weight": SIGNAL_WEIGHTS["sample_consistency"],
                               "detail": sm_detail},
    }


def calibrate(signals: dict, verdict: str = "pass",
              policy: dict | None = None) -> dict:
    """5 信号 → 校准后 0–1 置信度（确定性公式，见模块 docstring）。"""
    policy = policy or {}
    weights = policy.get("weights") or SIGNAL_WEIGHTS
    verdict_caps = policy.get("verdict_caps") or VERDICT_CAPS
    available = {k: v for k, v in signals.items()
                 if isinstance(v, dict) and v.get("value") is not None}
    total_w = sum(float(weights.get(k, SIGNAL_WEIGHTS.get(k, 0.0))) for k in signals) or 1.0
    if not available:
        return {"confidence": 0.0, "confidence_uncapped": 0.0,
                "evidence": 0.0, "coverage": 0.0,
                "cap_applied": None, "formula": "no-available-signal"}
    acc_w = sum(float(weights.get(k, SIGNAL_WEIGHTS.get(k, 0.0))) for k in available)
    acc = sum(float(weights.get(k, SIGNAL_WEIGHTS.get(k, 0.0))) * float(v["value"])
              for k, v in available.items())
    evidence = acc / acc_w if acc_w else 0.0
    coverage = acc_w / total_w
    raw = _NEUTRAL + (evidence - _NEUTRAL) * (
        _COVERAGE_STRETCH + (1.0 - _COVERAGE_STRETCH) * coverage)
    raw = max(0.0, min(1.0, raw))
    cap = verdict_caps.get(verdict)
    capped = min(raw, float(cap)) if cap is not None else raw
    return {
        "confidence": round(capped, 4),
        "confidence_uncapped": round(raw, 4),
        "evidence": round(evidence, 4),
        "coverage": round(coverage, 4),
        "cap_applied": None if cap is None or raw <= float(cap) else float(cap),
        "formula": ("0.5+(evidence-0.5)*(0.4+0.6*coverage)"
                    if not cap or raw <= float(cap) else
                    "min(公式值, verdict_cap)"),
    }


def score_field(field: dict, verification: dict, samples=None,
                spec: dict | None = None, policy: dict | None = None) -> dict:
    """单字段置信度 + 风险等级 + 建议动作（STP / 复核 / 重抽）。"""
    spec = spec or {}
    field = field or {}
    verification = verification or {}
    risk_class = resolve_risk_class(field, spec)
    thresholds = (policy or {}).get("thresholds") or THRESHOLDS
    threshold = float(thresholds.get(risk_class, NORMAL_THRESHOLD))
    signals = signals_from_verification(verification, field, samples)
    verdict = _s(verification.get("verdict") or "insufficient")
    cal = calibrate(signals, verdict=verdict, policy=policy)
    confidence = cal["confidence"]
    if verdict == "fail":
        recommendation = "review"
        risk_level = "high"
    elif verdict == "insufficient":
        recommendation = "re_extract"
        risk_level = "high"
    elif confidence >= threshold:
        recommendation = "stp"
        risk_level = "low"
    elif confidence >= NORMAL_THRESHOLD:
        recommendation = "review"
        risk_level = "medium"       # 普通字段阈值够、核心字段阈值不够
    else:
        recommendation = "review"
        risk_level = "high"
    reasons = []
    for name, sig in signals.items():
        if sig.get("value") is None:
            reasons.append("%s:unavailable" % name)
        elif float(sig["value"]) < 1.0:
            reasons.append("%s:%.2f" % (name, float(sig["value"])))
    if not reasons:
        reasons.append("all_signals_full")
    if cal.get("cap_applied") is not None:
        reasons.append("verdict_cap:%s" % verdict)
    return {
        "key": _s(verification.get("key") or field.get("key")),
        "label": _s(verification.get("label") or field.get("label")),
        "field_risk_class": risk_class,
        "stp_threshold": threshold,
        "confidence": confidence,
        "confidence_uncapped": cal["confidence_uncapped"],
        "evidence_strength": cal["evidence"],
        "signal_coverage": cal["coverage"],
        "risk_level": risk_level,
        "recommendation": recommendation,
        "needs_human": recommendation != "stp",
        "verdict": verdict,
        "signals": [
            {"name": name, "value": sig.get("value"),
             "weight": sig.get("weight"), "available":
                 sig.get("value") is not None,
             "detail": sig.get("detail") or {}}
            for name, sig in signals.items()
        ],
        "reasons": reasons,
        "reasons_zh": _zh_reasons(recommendation, risk_level, risk_class, reasons),
    }


def _zh_reasons(recommendation: str, risk_level: str, risk_class: str,
                reasons: list) -> list:
    out = []
    if recommendation == "stp":
        out.append("置信度达到%s字段直通阈值，可 STP 直通" % risk_class)
    elif recommendation == "re_extract":
        out.append("Verifier 判证据不足（空值/无文档/歧义），建议重抽或补证")
    else:
        out.append("未达%s字段直通阈值，转人工复核" % risk_class)
    if risk_level == "medium":
        out.append("普通字段阈值已过，但核心字段阈值未达")
    return out + list(reasons)


def score_extraction(verification_batch: dict, fields: list | None = None,
                     specs: dict | None = None, samples: dict | None = None,
                     policy: dict | None = None) -> dict:
    """批量置信度与分级路由统计。

    ``verification_batch``：:func:`app.services.extraction_verifier.verify_extraction`
    的返回（``{"fields":[...], "verdict":...}``）。
    ``samples``：``{field_key: [多次抽取值, ...]}``，可选（多采样自洽信号）。
    """
    verification_batch = verification_batch or {}
    specs = specs or {}
    samples = samples or {}
    fields_list = fields if isinstance(fields, list) else None
    fields_by_key = {}
    if fields_list:
        for f in fields_list:
            if isinstance(f, dict):
                fields_by_key[_s(f.get("key"))] = f
    scored = []
    for item in verification_batch.get("fields") or []:
        if not isinstance(item, dict):
            continue
        key = _s(item.get("key"))
        field = fields_by_key.get(key) or {
            "key": key, "label": item.get("label"),
            "value": item.get("value"), "type": item.get("type"),
            "raw": item.get("raw"), "unit": item.get("unit"),
        }
        spec = specs.get(key) or {}
        sample_values = samples.get(key)
        if sample_values is None and isinstance(samples, list):
            for run in samples:
                if isinstance(run, dict) and key in run:
                    sample_values = sample_values or []
                    sample_values.append(run[key])
        scored.append(score_field(field, item, samples=sample_values,
                                  spec=spec, policy=policy))
    summary = _summarize(scored)
    return {
        "policy_version": (policy or {}).get("version") or CONFIDENCE_POLICY_VERSION,
        "fields": scored,
        "summary": summary,
    }


def _summarize(scored: list) -> dict:
    out = {"n_fields": len(scored), "stp": 0, "review": 0, "re_extract": 0,
           "stp_rate": 0.0, "risk_levels": {"low": 0, "medium": 0, "high": 0},
           "by_risk_class": {"core": {"n": 0, "stp": 0, "review": 0, "re_extract": 0},
                             "normal": {"n": 0, "stp": 0, "review": 0,
                                        "re_extract": 0}},
           "thresholds": dict(THRESHOLDS)}
    for item in scored:
        rec = item.get("recommendation") or "review"
        out[rec] = out.get(rec, 0) + 1
        out["risk_levels"][item.get("risk_level") or "high"] = \
            out["risk_levels"].get(item.get("risk_level") or "high", 0) + 1
        cls = item.get("field_risk_class") or "normal"
        bucket = out["by_risk_class"].setdefault(
            cls, {"n": 0, "stp": 0, "review": 0, "re_extract": 0})
        bucket["n"] += 1
        bucket[rec] = bucket.get(rec, 0) + 1
    n = len(scored)
    out["stp_rate"] = round(out["stp"] / n, 4) if n else 0.0
    out["needs_human"] = out["review"] + out["re_extract"]
    return out


def confidence_policy(policy_overrides: dict | None = None) -> dict:
    """置信度策略（只读端点 / CLI / 测试读取的唯一口径）。"""
    policy = {
        "version": CONFIDENCE_POLICY_VERSION,
        "generated_by": "L155 Extractor-Verifier 字段级置信度",
        "thresholds": dict(THRESHOLDS),
        "threshold_notes": {
            "core": "金额/账号/主体标识/证件/编号等核心字段：≥0.98 才允许 STP 直通",
            "normal": "备注/说明/普通文本等非核心字段：≥0.85 可 STP 直通",
        },
        "weights": dict(SIGNAL_WEIGHTS),
        "calibration": {
            "method": "signal-coverage-shrinkage/v1",
            "formula": "confidence=0.5+(evidence-0.5)*(0.4+0.6*coverage)，再按 verdict 封顶",
            "neutral": _NEUTRAL,
            "coverage_stretch": _COVERAGE_STRETCH,
            "verdict_caps": dict(VERDICT_CAPS),
            "status": "heuristic-deterministic",
            "honest_note": ("公式参数为工程经验值，未用标注数据做过统计校准；"
                            "可用于分级路由与复核优先级，不能对外宣称是概率校准/准确率。"),
        },
        "signals": [
            {"name": "original_hit", "weight": SIGNAL_WEIGHTS["original_hit"],
             "source": "Verifier.is_substring（原文合法子串）",
             "available_when": "文档非空且抽取值非空"},
            {"name": "locatable", "weight": SIGNAL_WEIGHTS["locatable"],
             "source": "Verifier.evidence.span_ok / quote 唯一定位",
             "available_when": "提供 quote 或 start/end"},
            {"name": "unit_range", "weight": SIGNAL_WEIGHTS["unit_range"],
             "source": "Verifier.unit_ok / range_ok",
             "available_when": "字段存在单位或范围/类型约束"},
            {"name": "cross_field", "weight": SIGNAL_WEIGHTS["cross_field"],
             "source": "Verifier.cross_field_ok（合计/日期先后/单位一致性断言）",
             "available_when": "请求提供跨字段断言且字段被断言引用"},
            {"name": "sample_consistency",
             "weight": SIGNAL_WEIGHTS["sample_consistency"],
             "source": "请求 samples[key]=[多采样值...] 的一致率",
             "available_when": "同一字段样本 ≥2 条（当前主链无多采样通道，缺省不可用）"},
        ],
        "field_risk_classes": {
            "core_keys": sorted(CORE_FIELD_KEYS),
            "core_hints": list(CORE_FIELD_HINTS),
            "normal_hints": list(NORMAL_FIELD_HINTS),
            "resolution_order": ["spec.risk", "field.risk", "core_keys",
                                 "core_hints（排除 normal_hints）", "normal"],
        },
        "risk_levels": {
            "low": "置信度达到该字段等级阈值（可直通）",
            "medium": "过普通字段阈值但未过核心字段阈值",
            "high": "低于普通字段阈值，或 Verifier verdict=fail/insufficient",
        },
        "recommendations": {
            "stp": "高置信直通（无需人工）",
            "review": "转人工复核（低置信/冲突/标签夹带/单位错）",
            "re_extract": "证据不足（空值/无文档/歧义/坐标不可定位），建议重抽或补证",
        },
        "availability": {
            "logprobs": False,
            "logprobs_note": "当前 0-LLM 确定性校验链路拿不到 token logprobs，未使用",
            "independent_verifier_model": False,
            "independent_verifier_note": "使用确定性规则 Verifier 替代独立校验模型；未做异构模型交叉共识",
            "self_consistency": "optional",
            "self_consistency_note": "可经 samples 字段注入多次抽取值；主链默认无多采样通道",
            "calibration_data": False,
            "calibration_data_note": "未用标注数据训练；阈值 0.98/0.85 来自 2026_99 §4 的工程口径",
        },
        "endpoints": {
            "verify": {"method": "POST", "path": "/api/v1/extraction/verify",
                       "roles": ["reviewer", "admin"], "writes": False},
            "policy": {"method": "GET",
                       "path": "/api/v1/extraction/confidence-policy",
                       "roles": ["reviewer", "admin"], "writes": False},
        },
        "limits": {"max_samples_per_field": 20, "round_digits": 4},
    }
    if policy_overrides:
        policy["overrides"] = policy_overrides
    return policy


def score_request(payload: dict, policy: dict | None = None) -> dict:
    """HTTP 端点复用入口：校验 + 置信度（只读，不写库/不调模型）。"""
    from . import extraction_verifier as verifier
    verify_result = verifier.verify_extraction(payload)
    scores = score_extraction(
        verify_result,
        fields=payload.get("fields") or [],
        specs=payload.get("specs") or {},
        samples=payload.get("samples") or {},
        policy=policy,
    )
    return {"verify": verify_result, "confidence": scores}


__all__ = [
    "CONFIDENCE_POLICY_VERSION", "CORE_THRESHOLD", "NORMAL_THRESHOLD",
    "THRESHOLDS", "SIGNAL_WEIGHTS", "VERDICT_CAPS",
    "CORE_FIELD_KEYS", "CORE_FIELD_HINTS", "NORMAL_FIELD_HINTS",
    "resolve_risk_class", "signals_from_verification", "calibrate",
    "score_field", "score_extraction", "confidence_policy", "score_request",
]
