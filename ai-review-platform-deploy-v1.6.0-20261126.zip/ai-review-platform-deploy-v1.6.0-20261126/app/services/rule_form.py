"""规则形式判断：单条参数规则 vs 决策表组合多条件。

这是确定性启发式，不依赖模型；判断结果带证据，供规则生成/规则挖掘/详情展示复用。
"""
import re

MULTI_CUES = ("并且", "且", "同时", "而且", "以及", "或者", "或", "并", "任一", "全部", "组合", "分别")
METRIC_RE = re.compile(r"[\u4e00-\u9fa5]{2,12}(?:金额|比例|期限|温度|数量|日期|编号|名称|等级|天数|浓度|单价|总价|限价)")
COMPARE_RE = re.compile(r"(?:>=|<=|>|<|=|≥|≤|不得低于|不得高于|不得少于|不得多于|不低于|不高于|不少于|不多于|至少|至多|超过|低于|高于)")
CLAUSE_RE = re.compile(r"(?:必须|应当|须|不得|禁止|需要)[^。；;\n]{2,60}")


def _slot_conditions(slots):
    out = []
    s = slots or {}
    for key in ("when", "conditions", "all", "any"):
        v = s.get(key)
        if isinstance(v, list):
            out.extend([x for x in v if isinstance(x, dict)])
    if s.get("metric") and (s.get("value") is not None or s.get("op")):
        out.append({"metric": s.get("metric"), "op": s.get("op"), "value": s.get("value")})
    return out


def decide(text: str, slots: dict = None) -> dict:
    t = str(text or "")
    slots = slots or {}
    conditions = _slot_conditions(slots)
    metrics = list(dict.fromkeys(METRIC_RE.findall(t)))
    compares = COMPARE_RE.findall(t)
    clauses = CLAUSE_RE.findall(t)
    # 多条件显式标记
    cues = [c for c in MULTI_CUES if c in t]
    score = 0
    reasons = []
    if len(conditions) >= 2:
        score += 3
        reasons.append(f"槽位中包含 {len(conditions)} 个条件")
    if len(compares) >= 2:
        score += 3
        reasons.append(f"文本包含 {len(compares)} 个比较条件")
    if len(metrics) >= 2:
        score += 2
        reasons.append(f"文本包含多个指标：{'、'.join(metrics[:5])}")
    if len(clauses) >= 2 and cues:
        score += 2
        reasons.append(f"文本包含 {len(clauses)} 个并列要求")
    if cues:
        score += 1
        reasons.append(f"包含组合词：{'、'.join(cues[:3])}")
    if slots.get("require_any") and len(slots.get("require_any") or []) >= 2:
        score += 1
        reasons.append("条款类需要同时满足多个必备项")
    form = "decision_table" if score >= 3 else "single"
    return {"form": form, "confidence": round(min(0.95, 0.55 + score * 0.1), 2),
            "conditions": conditions, "metrics": metrics, "cues": cues,
            "reasons": reasons or ["单指标/单阈值，适合单条参数规则"]}
