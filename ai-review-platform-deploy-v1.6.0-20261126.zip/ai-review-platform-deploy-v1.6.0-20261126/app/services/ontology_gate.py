"""本体门槛：把客户表述里的指标名归一到本体实体，未命中则显式返回。

规则沉淀链的第一道闸：客户说「单次采购金额」，系统里若标准实体是「采购金额」，
必须归一后再建规则，否则规则永远匹配不到原文。
"""
import logging
import re

# 别名 → 标准实体（可由本体库动态扩展；当前为最小可用集）
# 只保留明确的标准名；其余同义词必须走“有依据的工作空间别名”。
# 不再硬编码“采购金额=合同金额/订单金额”这类跨口径猜测。
ALIASES = {
    "采购金额": ["采购金额"],
    "质保金比例": ["质保金比例"],
    "预付款比例": ["预付款比例"],
    "逾期天数": ["逾期天数"],
    "违约金费率": ["违约金费率"],
}

OVERRIDES = "docs/blind/ontology_overrides.json"


def _load_overrides() -> dict:
    """已发布别名 override；T-197（P0-2）：空间本体关闭时返回 {}（不读本体）。"""
    try:
        from . import ontology_control
        if not ontology_control.consumption_enabled("ontology_gate"):
            return {}
    except Exception:
        logging.getLogger(__name__).debug("ontology_gate 开关读取失败，按可读继续", exc_info=True)
    import json as _j
    try:
        return _j.loads(open(OVERRIDES, encoding="utf-8").read())
    except Exception:
        return {}


def _save_overrides(d: dict) -> None:
    import json as _j, os as _os
    _os.makedirs(_os.path.dirname(OVERRIDES), exist_ok=True)
    open(OVERRIDES, "w", encoding="utf-8").write(_j.dumps(d, ensure_ascii=False, indent=1))


def add_alias(canonical: str, alias: str) -> dict:
    """追加一条本体别名（进化链路可回滚）。"""
    d = _load_overrides()
    d.setdefault(canonical, [])
    if alias not in d[canonical]:
        d[canonical].append(alias)
        _save_overrides(d)
    _rebuild()
    return {"canonical": canonical, "alias": alias, "count": len(d[canonical])}


def remove_alias(canonical: str, alias: str) -> dict:
    d = _load_overrides()
    if alias in d.get(canonical, []):
        d[canonical].remove(alias)
        _save_overrides(d)
        _rebuild()
        return {"removed": True}
    return {"removed": False}


def record_patch(feedback_id: str, canonical: str, alias: str, note: str = "") -> dict:
    """把一次本体修订记成 rsi_candidate（before/after 可回滚）。"""
    from . import rsi_protocol
    before = {"aliases": list(_load_overrides().get(canonical, []))}
    res = add_alias(canonical, alias)
    after = {"aliases": list(_load_overrides().get(canonical, []))}
    cid = rsi_protocol.record_candidate(feedback_id, f"ONTO:{canonical}", "ontology.alias",
                                        before, after, note=note or f"新增别名 {alias}", by="system")
    return {"candidate_id": cid, "before": before, "after": after, "applied": res}


_INDEX = {}


def _rebuild():
    _INDEX.clear()
    for canon, names in ALIASES.items():
        for n in names:
            _INDEX[n] = canon
    for canon, names in _load_overrides().items():
        for n in names:
            _INDEX[n] = canon


for canon, names in ALIASES.items():
    for n in names:
        _INDEX[n] = canon


def normalize(name: str) -> dict:
    """返回 {input, canonical, matched, candidates}。"""
    raw = (name or "").strip()
    if not raw:
        return {"input": raw, "canonical": raw, "matched": False, "candidates": []}
    if raw in _INDEX:
        return {"input": raw, "canonical": _INDEX[raw], "matched": True, "candidates": [_INDEX[raw]]}
    # 包含式匹配（如「本次采购金额合计」）
    hits = [c for n, c in _INDEX.items() if n in raw or raw in n]
    hits = list(dict.fromkeys(hits))
    if len(hits) == 1:
        return {"input": raw, "canonical": hits[0], "matched": True, "candidates": hits}
    return {"input": raw, "canonical": raw, "matched": False, "candidates": hits}


def normalize_many(names: list) -> dict:
    """批量归一，返回 {mapped:{原词:标准}, unmatched:[...]}。"""
    mapped, unmatched = {}, []
    for n in names or []:
        r = normalize(n)
        if r["matched"]:
            mapped[r["input"]] = r["canonical"]
        else:
            unmatched.append(r["input"])
    return {"mapped": mapped, "unmatched": unmatched}

_rebuild()
