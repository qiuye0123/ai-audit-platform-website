"""P6.3 治理护栏：影子模式、转正门禁、自动回滚。

生产接线（不再是死代码）：
- ``shadow_start``：RSI 候选通过 ``rsi_protocol.gate_publish`` 后自动进入影子期；
- ``shadow_record``：人工复核（``review.decide`` 确认/误报）给影子规则累积真实样本；
- ``shadow_gate``：样本足够后判定能否转正；不达标则由 ``review.decide`` 触发
  ``auto_rollback`` 自动下线并留痕。
- ``auto_rollback``：修复了“查不存在的 finding.rule_code 字段 → 误判零发现”和
  “跨租户归档规则”两个线上缺陷；所有读写都按当前租户/空间口径（内置规则的
  NULL 租户视为平台全局资产，与仓储层 include_global 同口径）。
"""
import hashlib
import json
import logging
import os
import re

from .. import db
from .. import repositories as R

_LOG = logging.getLogger(__name__)

SHADOW_MIN_SAMPLES = 20
SHADOW_MIN_ACCURACY = 0.9
# 进程内只做一次建表/轻量迁移（复核主链路每次 decision 都会尝试采样）
# L109（2026-11-25）：DDL 单一事实源 = app/db.py 的 RUNTIME_EXTENSION_SCHEMA /
# RUNTIME_EXTENSION_COLUMNS；init_db 已建表（fresh=产品库），这里只做运行期兜底
# （老库/最小测试夹具缺表缺列时幂等补），不再内联 DDL 副本。
_TABLE_READY = False


def _c():
    return db.connect()


def _ctx_scope() -> tuple:
    try:
        from . import ctx as _ctx
        cur = _ctx.get_context() or {}
        return (str(cur.get("tenant_id") or ""), str(cur.get("workspace_id") or ""))
    except Exception:  # noqa: BLE001
        return ("", "")


def _ensure_shadow_table(c) -> None:
    """建表 + 轻量迁移：影子记录必须带租户/空间，否则无法按租户隔离。"""
    global _TABLE_READY
    if _TABLE_READY:
        return
    try:
        db.ensure_runtime_schema(c, "rsi_shadow")
        db.ensure_runtime_columns(c, "rsi_shadow")
    except Exception:  # noqa: BLE001 - 兜底失败留痕，不阻断主链
        _LOG.debug("rsi_shadow schema 兜底失败", exc_info=True)
        return
    _TABLE_READY = True


def _latest_shadow(c, rule_code: str, status: str = "shadow"):
    tenant, workspace = _ctx_scope()
    where = "rule_code=? AND status=?"
    params = [rule_code, status]
    if tenant:
        where += " AND (COALESCE(tenant_id,'')=? OR COALESCE(tenant_id,'')='')"
        params.append(tenant)
    if workspace:
        where += " AND (COALESCE(workspace_id,'')=? OR COALESCE(workspace_id,'')='')"
        params.append(workspace)
    return c.execute("SELECT * FROM rsi_shadow WHERE " + where +
                     " ORDER BY started_at DESC, rowid DESC LIMIT 1", tuple(params)).fetchone()


def shadow_start(rule_code: str, candidate_id: str = "", actor: str = "") -> dict:
    """让一条规则进入影子期；重复启动返回现有影子记录（幂等）。

    L117（2026-11-25）：进入影子期 = 候选进入「应用准备」阶段，先过候选安全门
    ``application_guard``（谱系/holdout/应用计划/防审核后篡改）。被阻断时返回
    ok=False + blocked=True，并写 ``evolution.blocked`` 审计；不创建影子记录。
    """
    if not str(rule_code or "").strip():
        return {"ok": False, "reason": "缺少 rule_code"}
    if str(candidate_id or "").strip():
        guard = application_guard(str(candidate_id), plan=None, by=actor or "system",
                                  shadow_rule_code=str(rule_code))
        if guard.get("blocked"):
            return {"ok": False, "blocked": True, "candidate_id": candidate_id,
                    "rule_code": rule_code, "stage": "application",
                    "reason": guard.get("reason") or "候选安全门（应用）阻断",
                    "violations": guard.get("violations") or [],
                    "audit_action": SAFETY_AUDIT_ACTION}
    tenant, workspace = _ctx_scope()
    c = _c()
    try:
        _ensure_shadow_table(c)
        row = _latest_shadow(c, rule_code, "shadow")
        if row is not None:
            c.commit()
            return {"ok": True, "shadow_id": row["id"], "existing": True,
                    "samples": row["samples"], "correct": row["correct"]}
        sid = db.new_id("sh")
        c.execute("INSERT INTO rsi_shadow(id,rule_code,candidate_id,status,samples,correct,"
                  "started_at,tenant_id,workspace_id,decision_note) "
                  "VALUES(?,?,?,'shadow',0,0,?,?,?,?)",
                  (sid, rule_code, candidate_id or "", db.now(), tenant, workspace,
                   "candidate:" + (candidate_id or "")))
        c.commit()
        R.audit_logs.log(actor=actor or "system", action="rsi.shadow_started",
                         object=rule_code,
                         after=json.dumps({"shadow_id": sid, "candidate_id": candidate_id,
                                           "tenant_id": tenant, "workspace_id": workspace},
                                          ensure_ascii=False))
        return {"ok": True, "shadow_id": sid, "existing": False}
    finally:
        c.close()


def shadow_record(rule_code: str, correct: bool, actor: str = "") -> dict:
    """给影子期规则累积一条真实人工复核样本。"""
    c = _c()
    try:
        _ensure_shadow_table(c)
        row = _latest_shadow(c, rule_code, "shadow")
        if not row:
            return {"ok": False, "reason": "该规则不在影子期"}
        c.execute("UPDATE rsi_shadow SET samples=samples+1, correct=correct+? WHERE id=?",
                  (1 if correct else 0, row["id"]))
        c.commit()
        return {"ok": True, "shadow_id": row["id"], "samples": int(row["samples"] or 0) + 1,
                "correct": int(row["correct"] or 0) + (1 if correct else 0)}
    finally:
        c.close()


def shadow_gate(rule_code: str, min_samples: int = SHADOW_MIN_SAMPLES,
                min_accuracy: float = SHADOW_MIN_ACCURACY) -> dict:
    """影子转正门禁：样本数 + 影子准确率，都达标才允许转正。"""
    c = _c()
    try:
        _ensure_shadow_table(c)
        row = _latest_shadow(c, rule_code, "shadow")
        if not row:
            return {"ok": False, "reason": "无影子记录，不允许转正", "samples": 0}
        samples, correct = int(row["samples"] or 0), int(row["correct"] or 0)
        acc = (correct / samples) if samples else 0.0
        base = {"samples": samples, "correct": correct, "accuracy": round(acc, 3),
                "shadow_id": row["id"]}
        if samples < min_samples:
            return {"ok": False, "reason": f"影子样本不足 {samples}/{min_samples}", **base,
                    "insufficient_samples": True}
        if acc < min_accuracy:
            return {"ok": False, "reason": f"影子期准确率 {acc:.2f} 低于 {min_accuracy}", **base,
                    "accuracy_below_target": True}
        # L131：影子样本达标 ≠ 可以自动上线 —— 必须人工审批 + 黄金集回归。
        # 生产自动转正链路 review._rsi_govern_after_decision 以 ``ok=True`` 作为
        # promoted 触发条件；这里返回 approval_required=True 即让自动转正**不成立**，
        # 影子记录保持 shadow，等管理员 approve_candidate 后再由 shadow_finish 上线。
        if hitl_enabled():
            shadow_row = dict(row)
            cid = str(shadow_row.get("candidate_id") or "")
            approval = approval_status(cid) if cid else {
                "approved": False, "status": "no_candidate",
                "reason": "影子记录未关联候选，无法完成人工审批/黄金集回归"}
            if not approval.get("approved"):
                return {"ok": False, "reason": "影子期达标，但候选上线前必须人工审批"
                                               "（黄金集回归）" + (
                              "：" + str(approval.get("reason") or "")
                              if approval.get("reason") else ""), **base,
                        "approval_required": True,
                        "approval_status": approval.get("status") or "",
                        "policy_version": HITL_POLICY_VERSION}
        return {"ok": True, "reason": "影子期达标", **base}
    finally:
        c.close()


def shadow_finish(rule_code: str, status: str, actor: str = "") -> dict:
    """关闭影子期：status=promoted（转正）/ rolled_back（因影子不达标回滚）。

    L117（2026-11-25）：``promoted`` = 候选真正应用到生产规则，先过
    ``application_guard``（回查影子记录关联候选：谱系/holdout/防审核后篡改）。

    L131（2026-11-25）：``promoted`` 还必须过 ``promotion_guard`` —— 管理员人工
    审批（``evolution.hitl_approved`` 证据，候选内容摘要绑定）+ 黄金集全量回归
    （退化不可被审批覆盖）；**没有审批的自动转正被拒**（``evolution.hitl_required``
    审计，影子记录保持 shadow，不写 published_at）。开关
    ``RULEPROOF_EVOLUTION_HITL_GOLDEN=0`` 时本段 no-op（旧行为逐字节回退）。
    """
    if status not in ("promoted", "rolled_back"):
        return {"ok": False, "reason": "非法影子状态"}
    if status == "promoted":
        cid = _shadow_candidate_id(rule_code)
        if cid:
            guard = application_guard(cid, plan=None, by=actor or "system",
                                      shadow_rule_code=str(rule_code))
            if guard.get("blocked"):
                return {"ok": False, "blocked": True, "candidate_id": cid,
                        "rule_code": rule_code, "stage": "application",
                        "reason": guard.get("reason") or "候选安全门（应用）阻断",
                        "violations": guard.get("violations") or [],
                        "audit_action": SAFETY_AUDIT_ACTION}
        # L131：人工审批 + 黄金集回归上线闸口（缺审批 → 拒绝自动 promoted）
        promotion = promotion_guard(cid, rule_code=str(rule_code))
        if not promotion.get("ok"):
            code = str(promotion.get("code") or "")
            action = (HITL_ACTION_REQUIRED if code in ("approval_required", "missing")
                      else HITL_ACTION_BLOCKED)
            audited = _audit_block_once(
                cid or str(rule_code or ""), action, {
                    "code": code or "hitl_required", "stage": "promotion",
                    "rule_code": str(rule_code or ""),
                    "reason": str(promotion.get("reason") or "")[:300],
                    "candidate_sha": promotion.get("candidate_sha") or "",
                    "golden": {"verdict": (promotion.get("golden") or {}).get("verdict"),
                               "set_id": ((promotion.get("golden") or {}).get("set_id")),
                               "regressions": [x.get("id") for x in
                                               ((promotion.get("golden") or {})
                                                .get("regressions") or [])][:20]}},
                actor=actor or "system")
            return {"ok": False, "blocked": True, "candidate_id": cid or "",
                    "rule_code": str(rule_code or ""), "stage": "promotion",
                    "hitl_required": True, "code": code or "hitl_required",
                    "reason": promotion.get("reason") or "候选上线前必须人工审批+黄金集回归",
                    "approval": promotion.get("approval") or {},
                    "golden": promotion.get("golden") or {},
                    "audit_action": action, "audited": audited}
    c = _c()
    try:
        _ensure_shadow_table(c)
        row = _latest_shadow(c, rule_code, "shadow")
        if not row:
            return {"ok": False, "reason": "该规则不在影子期"}
        c.execute("UPDATE rsi_shadow SET status=?, published_at=?, decided_at=? WHERE id=?",
                  (status, db.now() if status == "promoted" else "",
                   db.now(), row["id"]))
        c.commit()
        R.audit_logs.log(actor=actor or "system", action=f"rsi.shadow_{status}",
                         object=rule_code, after=json.dumps({"shadow_id": row["id"]},
                                                            ensure_ascii=False))
        return {"ok": True, "shadow_id": row["id"], "status": status,
                "samples": row["samples"], "correct": row["correct"]}
    finally:
        c.close()


def shadow_status(rule_code: str) -> dict:
    c = _c()
    try:
        _ensure_shadow_table(c)
        row = _latest_shadow(c, rule_code, "shadow")
        if not row:
            return {"ok": True, "in_shadow": False, "rule_code": rule_code}
        samples, correct = int(row["samples"] or 0), int(row["correct"] or 0)
        return {"ok": True, "in_shadow": True, "shadow_id": row["id"],
                "samples": samples, "correct": correct,
                "accuracy": round(correct / samples, 3) if samples else None,
                "started_at": row["started_at"]}
    finally:
        c.close()


def _published_rule_rows(c, rule_code: str) -> list:
    """当前租户/空间可见的已发布规则行（内置规则 tenant/workspace 为 NULL 视为全局）。"""
    tenant, workspace = _ctx_scope()
    where = "code=? AND status='published'"
    params = [rule_code]
    if tenant:
        where += " AND (COALESCE(tenant_id,'')=? OR COALESCE(tenant_id,'')='')"
        params.append(tenant)
    if workspace:
        where += " AND (COALESCE(workspace_id,'')=? OR COALESCE(workspace_id,'')='')"
        params.append(workspace)
    return [dict(r) for r in c.execute("SELECT id,code,status,tenant_id,workspace_id "
                                       "FROM rule WHERE " + where, tuple(params)).fetchall()]


def auto_rollback(rule_code: str, min_findings: int = 1, force: bool = False,
                  reason: str = "", by: str = "system") -> dict:
    """自动回滚/下线：修复 SQL 字段引用与租户隔离。

    - 默认口径「发布后长期零发现 → 自动下线」：``findings`` 用 finding.rule_id
      计数（租户/空间口径），不再查不存在的 finding.rule_code；
    - ``force=True``：影子期准确率不达标等已证伪场景，跳过零发现判断直接下线；
    - 只归档当前租户/空间可见的已发布规则；其它租户同编码规则不得被波及；
    - 归档前快照、归档后审计，返回实际归档行与租户信息。
    """
    from . import rsi_protocol as RSI
    eff = RSI.effectiveness(rule_code)
    if not force and eff.get("findings", 0) >= min_findings:
        return {"ok": False, "reason": "规则有效，无需回滚", "effective": eff}
    tenant, workspace = _ctx_scope()
    c = _c()
    try:
        rows = _published_rule_rows(c, rule_code)
        archived, skipped = [], []
        for row in rows:
            rid = row.get("id")
            c.execute("UPDATE rule SET status='archived' WHERE id=?", (rid,))
            archived.append({"id": rid, "tenant_id": row.get("tenant_id"),
                             "workspace_id": row.get("workspace_id")})
        c.commit()
    finally:
        c.close()
    if not archived:
        return {"ok": False, "reason": "没有当前租户/空间内可归档的已发布规则",
                "effective": eff, "tenant_id": tenant}
    detail = {"rule_code": rule_code, "archived": archived,
              "findings": eff.get("findings"), "force": bool(force),
              "reason": str(reason or "")[:200], "tenant_id": tenant,
              "workspace_id": workspace}
    try:
        R.audit_logs.log(actor=by or "system", action="rule.auto_rollback",
                         object=rule_code,
                         after=json.dumps(detail, ensure_ascii=False))
    except Exception:  # noqa: BLE001
        _LOG.debug("auto_rollback 审计写入失败", exc_info=True)
    return {"ok": True, "archived": len(archived), "rules": archived,
            "effective": eff, "tenant_id": tenant, "reason": str(reason or ""),
            "audit_action": "rule.auto_rollback"}


# ===========================================================================
# L117 自进化候选安全门（2026-11-25，L102 Top5 #14 / 自进化项 14）
#
# 目标：自进化/RSI 产生的候选**只能改规则行为层白名单代码**，禁止候选触碰
# 权限点/角色边界、开关默认值、DB schema/DDL、审计、证书、租户边界、报告门禁、
# 产品库与发布质量门禁本身。候选在三个真实生命周期点被拦截：
#
#   ① 候选生成  ``rsi_protocol.record_candidate`` → ``generation_guard``
#       （feedback.settle / ontology_gate.record_patch / RSI 候选的落痕入口）
#   ② 候选审核  ``rsi_protocol.gate_publish`` → ``review_guard``
#       （候选发布前置门禁；防「登记后/审核前」被篡改）
#       + ``enforce_rulegen_pool``：规则判据候选池（rulegen）在进化审阅视图
#         （``evolution.candidate_timeline``，HTTP/CLI 真实入口）读取时扫描阻断
#   ③ 候选应用  ``shadow_start``（进入影子/待转正）与 ``shadow_finish(promoted)``
#       → ``application_guard``（应用计划/谱系/holdout 复核 + 防审核后篡改）
#
# 回退杆：``RULEPROOF_RSI_SAFETY_GATE`` 默认 1=启用；显式 =0 时所有 guard 直接
# 返回 ``{"ok": True, "status": "disabled"}``，不写谱系、不写审计、不改变任何
# 既有候选状态机 —— 逐字节回退到本 lane 之前的行为（有测试锁定）。
# 审计：每次阻断写 ``evolution.blocked``（actor/stage/candidate_type/分类/策略版本），
# 同一候选同一阶段幂等，不重复刷审计。本模块**不做任何规则发布**：拦截只会把
# 候选标记 blocked/rejected，发布仍走既有 ``gate_publish``/``rulegen_publish`` 闸门。
# ===========================================================================
SAFETY_ENV = "RULEPROOF_RSI_SAFETY_GATE"
SAFETY_POLICY_VERSION = "l117.candidate_safety/v1"
SAFETY_AUDIT_ACTION = "evolution.blocked"
SAFETY_STAGES = ("generation", "review", "application")
SAFETY_MAX_LINEAGE_DEPTH = 20
SAFETY_MAX_VIOLATIONS = 20
SAFETY_LINEAGE_KEY = "_lineage"
SAFETY_AUDIT_MAX_CHARS = 4000

# 候选可改的产品代码白名单（最小集：规则参数/内置规则元数据/确定性算子实现）。
# 任何**不在**白名单的文件改动一律按越界处理（默认拒绝，宁严勿松）。
SAFE_CODE_WHITELIST = (
    "app/engine/ruleexec.py",
    "app/engine/rules_meta.py",
    "app/services/ruleparam.py",
)

# 文件路径黑名单：category / 人读原因 / 正则（对归一化相对路径做 search）。
FORBIDDEN_PATH_RULES = (
    ("permission", "权限点/角色单一事实源", r"(^|/)app/services/permission_registry\.py$"),
    ("permission", "权限包/角色判定", r"(^|/)app/services/permissions\.py$"),
    ("permission", "接口授权矩阵/ID 范围", r"(^|/)app/api/role_scope\.py$"),
    ("permission", "认证/会话/令牌", r"(^|/)app/auth\.py$"),
    ("permission", "账号开通/角色授予", r"(^|/)app/services/account\.py$"),
    ("gate", "发布质量门禁", r"(^|/)scripts/qa/gate\.py$"),
    ("gate", "候选安全门自身", r"(^|/)app/services/rsi_guard\.py$"),
    ("gate", "RSI 候选协议/发布门禁", r"(^|/)app/services/rsi_protocol\.py$"),
    ("gate", "候选账本/预注册", r"(^|/)app/services/evolution\.py$"),
    ("db_schema", "DB schema 单一事实源", r"(^|/)app/db\.py$"),
    ("db_schema", "迁移/DDL 目录", r"(^|/)migrations/"),
    ("db_schema", "仓储层/数据访问", r"(^|/)app/repositories\.py$"),
    ("audit", "审计日志事实源", r"(^|/)app/services/audit\.py$"),
    ("audit", "审计台账", r"(^|/)app/services/audit_ledger\.py$"),
    ("audit", "审计 DAG", r"(^|/)app/services/audit_dag\.py$"),
    ("audit", "审计导出/留痕", r"(^|/)app/services/audit_export\.py$"),
    ("certificate", "证书/签名服务", r"(^|/)app/services/certificate"),
    ("tenant", "租户边界", r"(^|/)app/services/(tenants|ctx|visibility_policy)\.py$"),
    ("tenant", "空间边界", r"(^|/)app/services/workspaces\.py$"),
    ("tenant", "租户/空间路由", r"(^|/)app/services/tenants\.py$"),
    ("report_gate", "报告门禁", r"(^|/)app/services/report_gate\.py$"),
    ("product_db", "产品库文件", r"(^|/)data/ruleproof\.db$"),
    ("product_db", "任何 SQLite 库文件", r"\.(db|sqlite|sqlite3)$"),
    ("product_db", "seed/演示数据生成", r"(^|/)seed(\.py|/)"),
    ("release", "开关默认模板", r"(^|/)\.env(\.example)?$"),
    ("release", "配置文件目录", r"(^|/)configs/"),
    ("web", "前端资源/页面", r"(^|/)web/"),
)

# 文本级黑名单（只对「变更意图字段」与 unified diff 生效；不对规则判据正文做泛扫，
# 避免误伤正常候选里的业务词）。category / 原因 / 正则。
FORBIDDEN_TEXT_RULES = (
    ("permission", "权限点/角色/授权定义变更",
     r"PermissionPoint\s*\(|BUSINESS_WRITE_CODES\s*=|ROLE_POLICY\s*=|"
     r"\brole_permissions?\b|\bGRANT\s+(ALL|ADMIN|SELECT|INSERT|UPDATE|DELETE)\b|"
     r"\bgrant_role\b|\bsuper_admin\b\s*(=>|=|:)"),
    ("switch", "开关默认值被下调/改写",
     r"RULEPROOF_[A-Z0-9_]+\s*=\s*[\"']?(0|false|off|no)\b"),
    ("db_ddl", "DB DDL（建/改/删表索引触发器）",
     r"\b(CREATE|ALTER|DROP)\s+(TABLE|INDEX|TRIGGER|VIEW|UNIQUE\s+INDEX)\b"),
    ("db_ddl", "删除表/清空数据",
     r"\b(DROP\s+TABLE|TRUNCATE\s+TABLE|DELETE\s+FROM\s+(audit_log|rsi_candidate|"
     r"permission|rule)\b)"),
    ("audit", "审计写被删除/停用",
     r"(audit_logs?\.log|audit\.log_in_tx|audit_log)[^\n]{0,80}"
     r"(删除|关闭|停用|移除|disable|remove|skip|bypass)"),
    ("product_db", "直接指定产品库路径",
     r"RULEPROOF_DB\s*=\s*[^\s\"']*data/ruleproof\.db"),
    ("tenant", "跨租户/租户边界改写",
     r"cross[_-]?tenant|tenant_id\s*=\s*[\"'][^\"']+[\"']\s*(OR|--)"),
    ("gate", "候选安全门被关闭/绕过",
     r"RULEPROOF_RSI_SAFETY_GATE\s*=\s*[\"']?(0|false|off|no)"),
)

# 「变更意图」字段名（递归匹配；命中即按变更内容做路径/文本扫描）。
CHANGE_FIELD_KEYS = frozenset({
    "files", "file", "file_path", "file_paths", "paths", "path", "touched_files",
    "code_change", "code_changes", "source_code", "patch", "diff", "unified_diff",
    "hunks", "apply", "apply_plan", "migrations", "migration", "sql", "ddl",
    "db_schema", "schema_sql", "database_change",
    "permissions", "permission_points", "permission", "permission_change",
    "roles", "role_change", "role_changes", "grant", "grants", "grant_role",
    "switch_defaults", "switch_change", "switch_changes", "switches",
    "env_defaults", "env_change", "default_switch",
    "audit", "audit_change", "audit_changes", "audit_remove", "audit_policy",
    "certificate", "certificates", "cert_change", "certificate_change",
    "tenant", "tenant_boundary", "tenant_scope", "tenant_change", "cross_tenant",
    "product_db", "db_path", "db_file", "report_gate", "release_gate",
    "gate_change", "deploy", "publish_config", "publish_policy",
})
CHANGE_FIELD_SUFFIXES = ("_change", "_changes", "_patch", "_diff", "_plan", "_sql")
_CHANGE_DIRECT_CATEGORY = {
    "permissions": "permission", "permission_points": "permission",
    "permission": "permission", "permission_change": "permission",
    "roles": "permission", "role_change": "permission", "role_changes": "permission",
    "grant": "permission", "grants": "permission", "grant_role": "permission",
    "switch_defaults": "switch", "switch_change": "switch",
    "switch_changes": "switch", "switches": "switch", "env_defaults": "switch",
    "env_change": "switch", "default_switch": "switch",
    "audit": "audit", "audit_change": "audit", "audit_changes": "audit",
    "audit_remove": "audit", "audit_policy": "audit",
    "certificate": "certificate", "certificates": "certificate",
    "cert_change": "certificate", "certificate_change": "certificate",
    "tenant": "tenant", "tenant_boundary": "tenant", "tenant_scope": "tenant",
    "tenant_change": "tenant", "cross_tenant": "tenant",
    "product_db": "product_db", "db_path": "product_db", "db_file": "product_db",
    "report_gate": "report_gate", "release_gate": "gate",
    "gate_change": "gate", "deploy": "gate", "publish_config": "gate",
    "publish_policy": "gate",
}
_CATEGORY_LABELS = {
    "permission": "权限/角色边界",
    "gate": "发布/安全门禁",
    "db_schema": "DB schema/DDL",
    "audit": "审计留痕",
    "certificate": "证书/签名",
    "tenant": "租户边界",
    "report_gate": "报告门禁",
    "product_db": "产品库/数据库文件",
    "switch": "开关默认值",
    "release": "发布配置/环境默认值",
    "web": "前端资源",
    "out_of_whitelist": "非白名单代码变更",
    "tamper": "候选内容跨阶段被篡改",
    "lineage": "候选谱系/holdout 违规",
}


def safety_enabled() -> bool:
    """候选安全门开关：默认 1=启用；``RULEPROOF_RSI_SAFETY_GATE=0`` 逐字节回退。

    字面量读取（不用变量间接）是刻意为之：开关注册表门禁的静态扫描按
    ``os.environ.get("RULEPROOF_*")`` 字面量识别开关，**新开关必须可被扫描/登记**，
    不允许用变量间接把它藏起来（N5「未文档化开关只减不增」）。
    """
    return str(os.environ.get("RULEPROOF_RSI_SAFETY_GATE", "1")).strip().lower() not in (
        "0", "false", "no", "off", "disabled")


def _permission_facts() -> dict:
    """受保护权限事实（单一事实源 = ``permission_registry``；取不到时 fail-closed 兜底）。"""
    try:
        from . import permission_registry as _pr
        return _pr.candidate_safety_facts()
    except Exception:  # noqa: BLE001 - 注册表不可用时按四角色/权限名录兜底
        return {"roles": ("super_admin", "admin", "reviewer", "platform_op"),
                "permission_codes": (), "business_write_codes": (),
                "role_policy_keys": (), "policy_source": "fallback"}


def safety_policy() -> dict:
    """机读策略（供审核视图/报告/门禁断言；不含任何可执行逻辑）。"""
    facts = _permission_facts()
    return {
        "policy_version": SAFETY_POLICY_VERSION,
        "enabled": safety_enabled(),
        "env": SAFETY_ENV,
        "env_default": "1",
        "stages": list(SAFETY_STAGES),
        "audit_action": SAFETY_AUDIT_ACTION,
        "lineage_key": SAFETY_LINEAGE_KEY,
        "max_lineage_depth": SAFETY_MAX_LINEAGE_DEPTH,
        "auto_publish": False,
        "never_auto_publish": True,
        "safe_code_whitelist": list(SAFE_CODE_WHITELIST),
        "forbidden_path_categories": [x[0] for x in FORBIDDEN_PATH_RULES],
        "forbidden_text_categories": [x[0] for x in FORBIDDEN_TEXT_RULES],
        "protected_roles": list(facts.get("roles") or ()),
        "protected_permission_codes": list(facts.get("permission_codes") or ()),
        "protected_business_write_codes": list(facts.get("business_write_codes") or ()),
        "permission_policy_source": facts.get("policy_source") or "",
        "rollback": "显式 RULEPROOF_RSI_SAFETY_GATE=0 → guard 全部 no-op（旧行为逐字节回退）",
    }


def _canonical(obj) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except (TypeError, ValueError):
        return repr(obj)


def _sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _text_of(value) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    except (TypeError, ValueError):
        return repr(value)


def _iter_fields(obj, prefix=""):
    """递归产出 (字段路径, 归一化字段名, 值)。dict/list 都展开。"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = str(k)
            norm = key.lstrip("_").strip().lower()
            yield (prefix + "/" + key if prefix else key), norm, v
            yield from _iter_fields(v, prefix + "/" + key if prefix else key)
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            yield from _iter_fields(v, "%s[%d]" % (prefix, i))


def _is_change_key(norm: str) -> bool:
    if norm in CHANGE_FIELD_KEYS:
        return True
    return any(norm.endswith(sfx) for sfx in CHANGE_FIELD_SUFFIXES)


def _normalize_path(raw) -> str:
    p = str(raw or "").strip().strip("\"'`").replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    # unified diff 头 a/xxx b/xxx → 去掉一段前缀（仅当第二段看着像仓库路径）
    for pre in ("a/", "b/", "+++ ", "--- "):
        if p.startswith(pre):
            p = p[len(pre):].strip()
    if p.startswith(("a/", "b/")) and "/" in p[2:]:
        p = p[2:]
    return p.strip("/") if p.endswith("/") else p


def _looks_like_repo_path(text: str) -> bool:
    p = _normalize_path(text)
    if not p or any(ch in p for ch in "\n\r\t ") or len(p) > 240:
        return False
    if p.startswith(("app/", "scripts/", "tests/", "migrations/", "data/", "seed/",
                     "web/", "configs/", "docs/", "dist/", "sdk/", "tools/")):
        return True
    return bool(re.search(r"\.(py|sql|sqlite|sqlite3|db|js|html|css|sh|json)$", p))


def _check_path(raw, violations: list) -> None:
    """单路径策略：先黑名单（优先），再白名单，最后「看着像仓库代码路径」默认拒绝。"""
    p = _normalize_path(raw)
    if not p or any(ch in p for ch in "\n\r\t"):
        return
    for cat, reason, rx in FORBIDDEN_PATH_RULES:
        if re.search(rx, p, re.IGNORECASE):
            _add_violation(violations, cat, "%s（%s）" % (reason, p), path=p)
            return
    for safe in SAFE_CODE_WHITELIST:
        if p == safe:
            return
    if _looks_like_repo_path(p):
        _add_violation(violations, "out_of_whitelist",
                       "候选改动了非白名单文件（%s）" % p, path=p)


def _add_violation(violations: list, category: str, detail: str, **extra) -> None:
    key = (category, detail[:160])
    for v in violations:
        if (v.get("category"), str(v.get("detail") or "")[:160]) == key:
            return
    item = {"category": category,
            "label": _CATEGORY_LABELS.get(category, category),
            "detail": str(detail)[:300]}
    item.update({k: v for k, v in extra.items() if v})
    violations.append(item)


def _extract_diff_paths(text: str) -> list:
    """从 unified diff 文本抽取被改动文件路径（+++ b/x、--- a/x、diff --git a/x b/y）。"""
    out = []
    for line in str(text or "").splitlines():
        m = re.match(r"^\+\+\+\s+(?:b/)?(\S+)", line)
        if m and m.group(1) != "/dev/null":
            out.append(m.group(1))
            continue
        m = re.match(r"^---\s+(?:a/)?(\S+)", line)
        if m and m.group(1) != "/dev/null":
            out.append(m.group(1))
            continue
        m = re.match(r"^diff --git\s+a/(\S+)\s+b/(\S+)", line)
        if m:
            out.extend([m.group(1), m.group(2)])
    return out


def _scan_diff_text(text: str, violations: list) -> None:
    """unified diff 语义扫描：被删审计写 / 开关默认值变更 / 路径 / 文本黑名单。"""
    raw = str(text or "")
    for p in _extract_diff_paths(raw):
        _check_path(p, violations)
    for line in raw.splitlines():
        if not line or line.startswith(("+++", "---", "@@", "diff --git", "index ")):
            continue
        body = line[1:] if line[:1] in "+-" else line
        changed = line[:1] in "+-"
        if changed and re.search(r"RULEPROOF_[A-Z0-9_]+\s*=\s*[\"']?(0|1|true|false)\b",
                                 body, re.IGNORECASE):
            _add_violation(violations, "switch", "diff 修改了开关默认值：%s" % body.strip()[:160])
        if changed and re.search(r"(audit_logs?\.log|audit\.log_in_tx)", body):
            if line.startswith("-"):
                _add_violation(violations, "audit", "diff 删除了审计写：%s" % body.strip()[:160])
            else:
                _add_violation(violations, "audit",
                               "diff 改写了审计写：%s" % body.strip()[:160])
        if changed and re.search(r"\b(CREATE|ALTER|DROP)\s+(TABLE|INDEX|TRIGGER)\b",
                                 body, re.IGNORECASE):
            _add_violation(violations, "db_ddl", "diff 含 DDL：%s" % body.strip()[:160])
        if changed and re.search(r"(tenant_id|workspace_id)\s*=\s*[\"'][^\"']+[\"']",
                                 body) and "OR" in body.upper():
            _add_violation(violations, "tenant", "diff 改写租户/空间边界：%s" % body.strip()[:160])


def _scan_change_text(text: str, violations: list, source: str = "") -> None:
    """对变更文本跑文本黑名单 + 路径（diff/代码/sql 统一入口）。"""
    raw = str(text or "")
    if not raw:
        return
    for cat, reason, rx in FORBIDDEN_TEXT_RULES:
        m = re.search(rx, raw, re.IGNORECASE)
        if m:
            _add_violation(violations, cat, "%s：%s" % (reason, m.group(0)[:160]),
                           source=source)
    if "@@ " in raw or raw.lstrip().startswith(("diff --git", "--- ", "+++ ")):
        _scan_diff_text(raw, violations)
    for token in re.findall(r"(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+\.py", raw):
        _check_path(token, violations)


def _scan_change_fields(obj, violations: list, depth: int = 0) -> None:
    """递归扫描「变更意图字段」：路径/权限/开关/DDL/审计/证书/租户/产品库。"""
    if depth > 6:
        return
    if isinstance(obj, dict):
        for raw_key, value in obj.items():
            norm = str(raw_key).lstrip("_").strip().lower()
            if _is_change_key(norm):
                _handle_change_field(norm, value, violations, depth)
        for value in obj.values():
            _scan_change_fields(value, violations, depth + 1)
    elif isinstance(obj, (list, tuple)):
        for value in obj:
            _scan_change_fields(value, violations, depth + 1)


def _handle_change_field(norm: str, value, violations: list, depth: int) -> None:
    cat = _CHANGE_DIRECT_CATEGORY.get(norm)
    if cat:
        _add_violation(violations, cat,
                       "候选声明变更受保护内容（字段 %s）：%s" % (norm, _text_of(value)[:200]))
        return
    if norm in ("files", "file", "file_path", "file_paths", "paths", "path",
                "touched_files"):
        items = value if isinstance(value, (list, tuple)) else [value]
        for it in items:
            if isinstance(it, dict):
                for k2 in ("path", "file", "name", "target"):
                    if it.get(k2):
                        _check_path(it[k2], violations)
                if it.get("patch") or it.get("diff"):
                    _scan_change_text(_text_of(it.get("patch") or it.get("diff")),
                                      violations, source=norm)
            else:
                _check_path(it, violations)
        return
    if norm in ("migrations", "migration"):
        items = value if isinstance(value, (list, tuple)) else [value]
        for it in items:
            if isinstance(it, dict):
                for k2 in ("path", "file", "name", "sql", "ddl"):
                    if it.get(k2):
                        hit = _text_of(it[k2])
                        _add_violation(violations, "db_schema",
                                       "候选声明数据库迁移/DDL（%s）" % hit[:160])
            else:
                p = _normalize_path(it)
                if p:
                    _add_violation(violations, "db_schema",
                                   "候选声明数据库迁移文件（%s）" % p)
        return
    # patch/diff/sql/ddl/code_change/apply/plan/...：文本扫描
    text = _text_of(value)
    _scan_change_text(text, violations, source=norm)
    if isinstance(value, (dict, list)):
        _scan_change_fields(value, violations, depth + 1)


def scan_candidate_change(payload, candidate_type: str = "rsi",
                          stage: str = "generation", candidate_id: str = "") -> dict:
    """候选变更静态扫描（纯函数，不写库）：返回 blocked/violations/policy 元信息。

    ``stage`` 只影响审计语义与返回字段，扫描规则三阶段共用（纵深防御）。
    """
    violations: list = []
    checked = []
    if not safety_enabled():
        return {"ok": True, "blocked": False, "status": "disabled", "violations": [],
                "policy_version": SAFETY_POLICY_VERSION, "candidate_type": candidate_type,
                "stage": stage, "note": "RULEPROOF_RSI_SAFETY_GATE=0：安全门已回退"}
    obj = payload if isinstance(payload, (dict, list)) else {"value": payload}
    # ① 变更意图字段（结构化）→ 路径/权限/开关/DDL/审计/证书/租户/产品库
    _scan_change_fields(obj, violations)
    checked.append("change_fields")
    # ② 全量文本：只跑高精度、业务正文不会碰的硬标记（产品库/权限源文件/DDL）
    canonical = _canonical(obj)
    for cat, reason, rx in (
            ("product_db", "产品库/数据库文件路径", r"data/ruleproof\.db|\b\S+\.sqlite3?\b"),
            ("permission", "权限事实源文件", r"(permission_registry|permissions|"
                                           r"role_scope)\.py"),
            ("db_ddl", "DB DDL", r"\b(CREATE|ALTER|DROP)\s+(TABLE|INDEX|TRIGGER)\b")):
        m = re.search(rx, canonical, re.IGNORECASE)
        if m:
            _add_violation(violations, cat, "%s：%s" % (reason, m.group(0)[:160]))
    checked.append("hard_text_markers")
    # ③ 权限事实源交叉断言：策略里的受保护权限点若被候选「授予/撤销」也拦
    facts = _permission_facts()
    if facts.get("permission_codes") and re.search(r"\b(permission|授权|role)\b", canonical,
                                                   re.IGNORECASE):
        for code in facts.get("business_write_codes") or ():
            if re.search(r"(?<![A-Za-z0-9_.])%s(?![A-Za-z0-9_.])" % re.escape(str(code)),
                         canonical):
                _add_violation(violations, "permission",
                               "候选触及审核业务写权限点 %s" % code)
                break
    checked.append("permission_facts_cross_check")
    return {"ok": not violations, "blocked": bool(violations), "status": "enabled",
            "violations": violations[:SAFETY_MAX_VIOLATIONS],
            "violation_count": len(violations),
            "categories": sorted({v["category"] for v in violations}),
            "checked": checked, "policy_version": SAFETY_POLICY_VERSION,
            "candidate_type": str(candidate_type or ""), "stage": str(stage or ""),
            "candidate_id": str(candidate_id or ""),
            "payload_sha256": _sha256_text(canonical)}


# ---------------- 谱系 / holdout（最小落地：写进候选快照的 _lineage 段） ----------------
def _lineage_of(snapshot) -> dict:
    if not isinstance(snapshot, dict):
        return {}
    lin = snapshot.get(SAFETY_LINEAGE_KEY)
    return dict(lin) if isinstance(lin, dict) else {}


def _strip_lineage(snapshot):
    if not isinstance(snapshot, dict):
        return snapshot
    out = {k: v for k, v in snapshot.items() if k != SAFETY_LINEAGE_KEY}
    return out


def _scan_digest(before, after, candidate_type: str, action: str, rule_code: str) -> str:
    return _sha256_text(_canonical({"before": _strip_lineage(before),
                                   "after": _strip_lineage(after),
                                   "candidate_type": str(candidate_type or ""),
                                   "action": str(action or ""),
                                   "rule_code": str(rule_code or "")}))


def _parent_generation(parent_candidate_id: str) -> int:
    pid = str(parent_candidate_id or "").strip()
    if not pid:
        return 0
    try:
        row = R.rsi_candidates.get(pid) or {}
    except Exception:  # noqa: BLE001 - 谱系读取失败按 0 处理（不阻断正常候选）
        return 0
    try:
        after = json.loads(row.get("after_json") or "{}")
    except Exception:  # noqa: BLE001
        after = {}
    try:
        return int(_lineage_of(after).get("generation") or 0)
    except (TypeError, ValueError):
        return 0


def build_lineage(candidate_type: str = "", rule_code: str = "", action: str = "",
                  feedback_id: str = "", before=None, after=None, by: str = "",
                  parent_candidate_id: str = "", holdout=None,
                  holdout_slice: str = "") -> dict:
    """构造候选谱系段：来源/父候选/代数/holdout 标记/生成者/扫描摘要。

    ``holdout``（留出集）标记为 True 的候选不得直接应用：应用阶段必须带
    ``reviewed=True``（人工复核留痕），否则 application_guard 阻断。
    """
    src_lin = _lineage_of(after) or _lineage_of(before)
    parent = str(parent_candidate_id or src_lin.get("parent_candidate_id") or "").strip()
    parent_gen = _parent_generation(parent) if parent else 0
    try:
        gen = max(int(src_lin.get("generation") or 0), parent_gen + (1 if parent else 0), 1)
    except (TypeError, ValueError):
        gen = 1
    if holdout is None:
        holdout = bool(src_lin.get("holdout") or (after or {}).get("holdout")
                       if isinstance(after, dict) else src_lin.get("holdout"))
    return {
        "policy_version": SAFETY_POLICY_VERSION,
        "candidate_type": str(candidate_type or src_lin.get("candidate_type") or "rsi"),
        "source": {"rule_code": str(rule_code or ""), "action": str(action or ""),
                   "feedback_id": str(feedback_id or "")},
        "parent_candidate_id": parent,
        "generation": gen,
        "holdout": bool(holdout),
        "holdout_slice": str(holdout_slice or src_lin.get("holdout_slice") or ""),
        "reviewed": bool(src_lin.get("reviewed")),
        "reviewed_by": str(src_lin.get("reviewed_by") or ""),
        "reviewed_at": str(src_lin.get("reviewed_at") or ""),
        "created_by": str(by or ""),
        "created_at": db.now(),
        "scan_sha256": _scan_digest(before, after, candidate_type, action, rule_code),
        "blocked": False, "blocked_stage": "", "blocked_reasons": [],
    }


def decorate_candidate_after(after, lineage: dict):
    """把谱系段写进候选 after 快照（保留调用方原对象；候选预注册 hash 覆盖该段）。"""
    out = dict(after) if isinstance(after, dict) else {"value": after}
    out[SAFETY_LINEAGE_KEY] = dict(lineage or {})
    return out


# ---------------- 审计：evolution.blocked（幂等） ----------------
def _audit_blocked(candidate_id: str, candidate_type: str, stage: str,
                   violations: list, actor: str = "", extra: dict = None) -> bool:
    """写 ``evolution.blocked`` 审计（同一候选同一阶段幂等，不重复刷）。失败只告警。"""
    cid = str(candidate_id or "")
    if not cid or _already_audited(cid, stage):
        return False
    payload = {"candidate_id": cid, "candidate_type": str(candidate_type or ""),
               "stage": str(stage or ""), "policy_version": SAFETY_POLICY_VERSION,
               "blocked": True, "audit_action": SAFETY_AUDIT_ACTION,
               "violations": [{"category": v.get("category"),
                               "label": v.get("label"),
                               "detail": str(v.get("detail") or "")[:200]}
                              for v in (violations or [])][:SAFETY_MAX_VIOLATIONS],
               "categories": sorted({v.get("category") for v in (violations or [])})}
    if extra:
        payload.update({k: v for k, v in extra.items() if v is not None})
    try:
        R.audit_logs.log(actor=actor or "system", action=SAFETY_AUDIT_ACTION,
                         object=cid,
                         after=json.dumps(payload, ensure_ascii=False,
                                          sort_keys=True)[:SAFETY_AUDIT_MAX_CHARS])
        return True
    except Exception:  # noqa: BLE001 - 审计失败留日志，不阻断主链（不伪造成功）
        _LOG.warning("候选安全门审计写入失败 cid=%s stage=%s", cid, stage, exc_info=True)
        return False


def _already_audited(candidate_id: str, stage: str) -> bool:
    try:
        rows = R.audit_logs.list("action=? AND object=?",
                                 (SAFETY_AUDIT_ACTION, str(candidate_id or "")),
                                 order="created_at DESC", limit=50)
    except Exception:  # noqa: BLE001
        return False
    for row in rows or []:
        try:
            detail = json.loads(row.get("after_json") or "{}")
        except (TypeError, ValueError):
            continue
        if str(detail.get("stage") or "") == str(stage or ""):
            return True
    return False


def _infer_candidate_type(action: str = "", rule_code: str = "",
                          feedback_id: str = "", declared=None) -> str:
    if declared:
        return str(declared)
    a = str(action or "")
    rc = str(rule_code or "")
    if a.startswith("ontology.") or rc.startswith("ONTO:"):
        return "ontology"
    if str(feedback_id or "").strip():
        return "feedback"
    return "rsi"


# ---------------- 三处拦截（generation / review / application） ----------------
def generation_guard(candidate_id: str, feedback_id: str = "", rule_code: str = "",
                     action: str = "", before=None, after=None, note: str = "",
                     by: str = "", candidate_type: str = "",
                     parent_candidate_id: str = "", holdout=None,
                     holdout_slice: str = "") -> dict:
    """① 候选生成拦截：扫描候选快照并生成谱系段；阻断时写 evolution.blocked。"""
    ctype = _infer_candidate_type(action, rule_code, feedback_id, candidate_type)
    if not safety_enabled():
        return {"ok": True, "blocked": False, "status": "disabled",
                "candidate_type": ctype, "stage": "generation",
                "lineage": {}, "after": after,
                "note": "RULEPROOF_RSI_SAFETY_GATE=0：安全门已回退（不写谱系/不阻断）"}
    payload = {"candidate_type": ctype, "feedback_id": str(feedback_id or ""),
               "rule_code": str(rule_code or ""), "action": str(action or ""),
               "before": before or {}, "after": after or {},
               "note": str(note or "")}
    scan = scan_candidate_change(payload, candidate_type=ctype, stage="generation",
                                 candidate_id=candidate_id)
    lineage = build_lineage(ctype, rule_code, action, feedback_id, before, after, by,
                            parent_candidate_id, holdout, holdout_slice)
    if scan.get("blocked"):
        lineage.update({"blocked": True, "blocked_stage": "generation",
                        "blocked_at": db.now(),
                        "blocked_reasons": [v.get("detail") for v in scan["violations"][:5]]})
        audited = _audit_blocked(candidate_id, ctype, "generation", scan["violations"],
                                 actor=by)
        return {"ok": False, "blocked": True, "status": "blocked", "candidate_type": ctype,
                "stage": "generation", "violations": scan["violations"],
                "categories": scan["categories"], "lineage": lineage,
                "after": decorate_candidate_after(after, lineage),
                "audited": audited, "policy_version": SAFETY_POLICY_VERSION,
                "reason": "候选安全门阻断：%s" % "；".join(
                    v.get("detail") or "" for v in scan["violations"][:3])}
    lineage["scan_stage"] = "generation"
    return {"ok": True, "blocked": False, "status": "passed", "candidate_type": ctype,
            "stage": "generation", "violations": [], "lineage": lineage,
            "after": decorate_candidate_after(after, lineage),
            "policy_version": SAFETY_POLICY_VERSION}


def _candidate_payload(candidate_id: str, row: dict = None) -> tuple:
    row = dict(row or {})
    if not row:
        try:
            row = R.rsi_candidates.get(str(candidate_id or "")) or {}
        except Exception:  # noqa: BLE001
            row = {}
    try:
        before = json.loads(row.get("before_json") or "{}")
    except (TypeError, ValueError):
        before = {}
    try:
        after = json.loads(row.get("after_json") or "{}")
    except (TypeError, ValueError):
        after = {}
    return row, (before if isinstance(before, dict) else {}), \
        (after if isinstance(after, dict) else {})


def review_guard(candidate_id: str, row: dict = None, by: str = "") -> dict:
    """② 候选审核拦截：重扫已落库快照 + 校验生成阶段扫描摘要（防跨阶段篡改）。"""
    if not safety_enabled():
        return {"ok": True, "blocked": False, "status": "disabled", "stage": "review",
                "note": "RULEPROOF_RSI_SAFETY_GATE=0：安全门已回退"}
    row, before, after = _candidate_payload(candidate_id, row)
    if not row:
        return {"ok": False, "blocked": False, "status": "not_found", "stage": "review",
                "reason": "候选不存在"}
    lineage = _lineage_of(after) or _lineage_of(before)
    ctype = str(lineage.get("candidate_type")
                or _infer_candidate_type(row.get("action"), row.get("rule_code"),
                                         row.get("feedback_id")))
    scan = scan_candidate_change({"before": before, "after": after,
                                  "note": row.get("note") or "",
                                  "action": row.get("action") or "",
                                  "rule_code": row.get("rule_code") or "",
                                  "candidate_type": ctype},
                                 candidate_type=ctype, stage="review",
                                 candidate_id=candidate_id)
    violations = list(scan.get("violations") or [])
    if lineage.get("scan_sha256"):
        expect = str(lineage.get("scan_sha256"))
        actual = _scan_digest(before, after, ctype, row.get("action") or "",
                              row.get("rule_code") or "")
        if actual != expect:
            _add_violation(violations, "tamper",
                           "候选 after/before 在生成后、审核前被篡改（扫描摘要不一致）",
                           expected=expect[:16], actual=actual[:16])
    if violations:
        audited = _audit_blocked(candidate_id, ctype, "review", violations, actor=by)
        return {"ok": False, "blocked": True, "status": "blocked", "stage": "review",
                "candidate_type": ctype, "violations": violations,
                "categories": sorted({v.get("category") for v in violations}),
                "audited": audited, "lineage": lineage,
                "policy_version": SAFETY_POLICY_VERSION,
                "reason": "候选安全门（审核）阻断：%s" % "；".join(
                    v.get("detail") or "" for v in violations[:3])}
    return {"ok": True, "blocked": False, "status": "passed", "stage": "review",
            "candidate_type": ctype, "violations": [], "lineage": lineage,
            "policy_version": SAFETY_POLICY_VERSION}


def _shadow_candidate_id(rule_code: str) -> str:
    """影子记录当前关联的候选 id（用于应用阶段 guard）。"""
    c = _c()
    try:
        _ensure_shadow_table(c)
        row = _latest_shadow(c, rule_code, "shadow")
        return str(dict(row).get("candidate_id") or "") if row else ""
    finally:
        c.close()


def application_guard(candidate_id: str, row: dict = None, plan=None, by: str = "",
                      shadow_rule_code: str = "") -> dict:
    """③ 候选应用拦截：应用计划扫描 + 谱系/holdout 复核 + 防审核后篡改。

    - ``plan``：应用方声明要落地的文件/补丁/迁移（可为空，空=应用候选快照本身）；
    - holdout 候选必须带 ``reviewed=True``（人工复核留痕）才允许应用；
    - 谱系代数超过 ``SAFETY_MAX_LINEAGE_DEPTH`` 视为自进化失控，阻断；
    - 父候选 blocked 时，子候选不得应用（阻断谱系传播）。
    """
    if not safety_enabled():
        return {"ok": True, "blocked": False, "status": "disabled", "stage": "application",
                "note": "RULEPROOF_RSI_SAFETY_GATE=0：安全门已回退"}
    cid = str(candidate_id or "")
    row, before, after = _candidate_payload(cid, row)
    if not row:
        return {"ok": True, "blocked": False, "status": "no_candidate",
                "stage": "application",
                "note": "无候选关联（旧行为：不阻断）"}
    lineage = _lineage_of(after) or _lineage_of(before)
    ctype = str(lineage.get("candidate_type")
                or _infer_candidate_type(row.get("action"), row.get("rule_code"),
                                         row.get("feedback_id")))
    scan = scan_candidate_change({"before": before, "after": after,
                                  "apply_plan": plan or {},
                                  "note": row.get("note") or "",
                                  "candidate_type": ctype},
                                 candidate_type=ctype, stage="application",
                                 candidate_id=cid)
    violations = list(scan.get("violations") or [])
    # 防审核后篡改：生成阶段扫描摘要不一致
    if lineage.get("scan_sha256"):
        actual = _scan_digest(before, after, ctype, row.get("action") or "",
                              row.get("rule_code") or "")
        if actual != str(lineage.get("scan_sha256")):
            _add_violation(violations, "tamper",
                           "候选在审核后、应用前被篡改（扫描摘要不一致）")
    # holdout：留出集候选不得未复核直接应用
    if bool(lineage.get("holdout")) and not bool(lineage.get("reviewed")):
        _add_violation(violations, "lineage",
                       "holdout 候选缺少人工复核留痕（reviewed=False），不得直接应用")
    # 谱系代数失控
    try:
        gen = int(lineage.get("generation") or 0)
    except (TypeError, ValueError):
        gen = 0
    if gen > SAFETY_MAX_LINEAGE_DEPTH:
        _add_violation(violations, "lineage",
                       "候选谱系代数 %d 超过上限 %d（自进化失控）"
                       % (gen, SAFETY_MAX_LINEAGE_DEPTH))
    parent = str(lineage.get("parent_candidate_id") or "")
    if parent:
        try:
            prow = R.rsi_candidates.get(parent) or {}
        except Exception:  # noqa: BLE001
            prow = {}
        if prow and str(prow.get("decision") or "") == "blocked":
            _add_violation(violations, "lineage",
                           "父候选 %s 已被阻断，子候选不得应用（谱系传播）" % parent)
    if violations:
        audited = _audit_blocked(cid, ctype, "application", violations, actor=by,
                                 extra={"rule_code": shadow_rule_code or
                                        str(row.get("rule_code") or "")})
        return {"ok": False, "blocked": True, "status": "blocked", "stage": "application",
                "candidate_type": ctype, "violations": violations,
                "categories": sorted({v.get("category") for v in violations}),
                "lineage": lineage, "audited": audited,
                "policy_version": SAFETY_POLICY_VERSION,
                "reason": "候选安全门（应用）阻断：%s" % "；".join(
                    v.get("detail") or "" for v in violations[:3])}
    return {"ok": True, "blocked": False, "status": "passed", "stage": "application",
            "candidate_type": ctype, "violations": [], "lineage": lineage,
            "policy_version": SAFETY_POLICY_VERSION}


def mark_candidate_blocked(candidate_id: str, reason: str = "", by: str = "") -> bool:
    """把候选状态落为 blocked（保留既有状态机：blocked 仍是「真实违规」语义）。"""
    try:
        row = R.rsi_candidates.get(str(candidate_id or "")) or {}
    except Exception:  # noqa: BLE001
        row = {}
    note = str(row.get("note") or "")
    for r in (reason, "L117 安全门阻断"):
        if r and r not in note:
            note = (note + " | " + r).strip(" |")
    try:
        R.rsi_candidates.update(str(candidate_id or ""), decision="blocked",
                                note=note[:4000], decided_at=db.now(),
                                decided_by=str(by or "safety-gate")[:80])
        return True
    except Exception:  # noqa: BLE001
        _LOG.warning("候选安全门落 blocked 失败 cid=%s", candidate_id, exc_info=True)
        return False


# ---------------- rulegen 候选池（覆盖 rulegen 生成/审阅面） ----------------
def _rulegen_payload(row: dict) -> dict:
    row = dict(row or {})

    def _j(text, default):
        try:
            v = json.loads(text or "")
        except (TypeError, ValueError):
            return default
        return v if isinstance(v, (dict, list)) else default

    return {"candidate_type": "rulegen", "id": row.get("id") or "",
            "point_code": row.get("point_code") or "",
            "name": row.get("name") or "", "category": row.get("category") or "",
            "source_kind": row.get("source_kind") or "",
            "source_ref": _j(row.get("source_ref_json"), {}),
            "schema": _j(row.get("schema_json"), {}),
            "slots": _j(row.get("slots_json"), {}),
            "criteria_text": row.get("criteria_text") or "",
            "shadow_cases": _j(row.get("shadow_cases_json"), []),
            "note": row.get("note") or ""}


def scan_rulegen_candidate(row: dict) -> dict:
    """扫描单条 rulegen 候选（规则判据候选池）是否越界。"""
    payload = _rulegen_payload(row)
    return scan_candidate_change(payload, candidate_type="rulegen", stage="review",
                                 candidate_id=str(payload.get("id") or ""))


def enforce_rulegen_pool(limit: int = 200, actor: str = "safety-sweep") -> dict:
    """扫描规则判据候选池（rulegen）：越界候选置 rejected + 写 evolution.blocked。

    覆盖 rulegen 候选的「审核」面：进入有效状态（suggested/confirmed/shadow_*）之前
    在进化审阅视图（``evolution.candidate_timeline``）读取时强制扫描，阻断越界候选
    继续走 confirm/shadow/publish。幂等：已 rejected 的不重复处理/不重复审计。
    """
    out = {"ok": True, "scanned": 0, "blocked": 0, "blocked_ids": [],
           "policy_version": SAFETY_POLICY_VERSION}
    if not safety_enabled():
        out.update({"status": "disabled",
                    "note": "RULEPROOF_RSI_SAFETY_GATE=0：rulegen 池安全扫描已回退"})
        return out
    try:
        limit = max(1, min(int(limit or 200), 1000))
    except (TypeError, ValueError):
        limit = 200
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT * FROM rulegen_candidate WHERE status IN "
                "('suggested','confirmed','shadow_passed','shadow_failed') "
                "ORDER BY rowid DESC LIMIT ?", (limit,)).fetchall()
    except Exception:  # noqa: BLE001 - 表缺失（极简夹具库）→ 无可扫描，不阻断视图
        out["scanned"] = 0
        return out
    blocked_rows = []
    for row in rows or []:
        work = dict(row)
        out["scanned"] += 1
        scan = scan_rulegen_candidate(work)
        if not scan.get("blocked"):
            continue
        cid = str(work.get("id") or "")
        out["blocked"] += 1
        out["blocked_ids"].append(cid)
        try:
            with db.session() as c:
                cur = c.execute(
                    "UPDATE rulegen_candidate SET status='rejected', decided_by=?, "
                    "decided_at=?, note=? WHERE id=? AND status<>'rejected'",
                    (str(actor or "safety-sweep")[:80], db.now(),
                     (str(work.get("note") or "") +
                      " | L117 安全门阻断：" +
                      ";".join(v.get("detail") or "" for v in scan["violations"][:3])
                      ).strip(" |")[:1000], cid))
                changed = cur.rowcount == 1
        except Exception:  # noqa: BLE001
            changed = False
        _audit_blocked(cid, "rulegen", "review", scan["violations"], actor=actor,
                       extra={"rule_code": str(work.get("point_code") or ""),
                              "status_before": str(work.get("status") or ""),
                              "rulegen_candidate": True, "status_after": "rejected",
                              "changed": changed})
        blocked_rows.append({"id": cid, "categories": scan.get("categories") or [],
                             "status_after": "rejected" if changed else
                                             str(work.get("status") or ""),
                             "detail": "；".join(v.get("detail") or ""
                                                for v in scan["violations"][:2])})
    out["blocked_rows"] = blocked_rows
    return out


def _rulegen_sweep_summary(limit: int = 200) -> dict:
    """给读视图用的 rulegen 扫描摘要（吞异常：读视图降级不得 500）。"""
    try:
        res = enforce_rulegen_pool(limit=limit, actor="candidate-review")
        return {k: res.get(k) for k in
                ("ok", "status", "scanned", "blocked", "blocked_ids", "policy_version")}
    except Exception:  # noqa: BLE001
        _LOG.warning("rulegen 候选池安全扫描失败（视图降级）", exc_info=True)
        return {"ok": False, "status": "error", "scanned": 0, "blocked": 0,
                "blocked_ids": []}


def blocked_events(limit: int = 100) -> list:
    """``evolution.blocked`` 审计事件（时间新→旧；供审核视图/报告）。"""
    try:
        limit = max(1, min(int(limit or 100), 500))
    except (TypeError, ValueError):
        limit = 100
    try:
        rows = R.audit_logs.list("action=?", (SAFETY_AUDIT_ACTION,),
                                 order="created_at DESC", limit=limit)
    except Exception:  # noqa: BLE001
        return []
    out = []
    for row in rows or []:
        try:
            detail = json.loads(row.get("after_json") or "{}")
        except (TypeError, ValueError):
            detail = {"raw": str(row.get("after_json") or "")[:200]}
        out.append({"at": row.get("created_at") or "", "actor": row.get("actor") or "",
                    "candidate_id": row.get("object") or "",
                    "candidate_type": detail.get("candidate_type") or "",
                    "stage": detail.get("stage") or "",
                    "categories": detail.get("categories") or [],
                    "violations": detail.get("violations") or [],
                    "policy_version": detail.get("policy_version") or "",
                    "audit_action": SAFETY_AUDIT_ACTION})
    return out


def candidate_safety_summary(limit: int = 100) -> dict:
    """候选安全门运行摘要（策略 + blocked 审计 + rulegen 扫描），供审阅/门禁。"""
    return {"ok": True, "policy": safety_policy(), "blocked_events": blocked_events(limit),
            "rulegen_sweep": _rulegen_sweep_summary(limit=200)}


# ===========================================================================
# L131（2026-11-25）自进化防污染 / 防退化护栏
#
# 目标（L117 安全门之外的上线闸口）：候选（规则 / 本体 / Prompt）在**真正上线前**
# 必须同时满足：
#   ① **HITL 人工审批**：管理员（admin / 显式 evo.manage 授权角色）显式批准，
#      审批是带候选内容摘要的独立审计事件；没有审批 → ``promoted`` 被拒
#      （不再出现「门禁阈值自动转正」的无人批准上线）。
#   ② **黄金集全量回归**：用管理员指定的黄金集（``evolution.golden_set``）对候选
#      before/after 快照做全量逐例回归；任一用例由通过退化为不通过 / 召回下降 /
#      误报上升 → 阻断（管理员审批也不能覆盖退化）；没有黄金集 / 无法评估 →
#      ``insufficient_evidence``，必须管理员显式 acknowledge 才可批准（不默认放行）。
#   ③ **污染防护**：候选来源/训练数据标记（``_lineage`` 来源段 + label_strength）、
#      脏数据/重复/冲突检测（黄金集用例校验、候选快照摘要去重、候选基线过期）、
#      黄金集隔离（黄金集绑定租户/空间；候选自带黄金集一律不得作为自证证据）。
#   ④ **一键回滚**（rsi_protocol.rollback 的 L131 增强，本模块只提供审计动作常量）：
#      规则版本 / 本体别名 / 运行参数恢复到候选 before 快照，事务 + 审计 + 幂等。
#
# 回退杆：``RULEPROOF_EVOLUTION_HITL_GOLDEN`` 默认 1=启用；显式 =0 时本段全部 no-op
# （approval_status 返回 disabled、promotion_guard 放行、不写任何 L131 审计），
# gate/shadow 行为逐字节回到本 lane 之前（有测试锁定）。
#
# 证据存放（不新增 DB 表/列，遵守本 lane 写作用域）：
#   - 审批 / 拒绝 / 阻断 / 黄金集结果全部写**只读审计** ``audit_log``
#     （object=候选 id，after_json=机读证据，含 policy_version 与候选内容摘要）；
#   - 黄金集本体存 ``sys_config``（key=``evolution.golden_set``），带租户/空间作用域；
#   - 审批与候选内容摘要绑定：审批后候选被改 → 摘要不一致 → ``approval_stale`` 阻断。
# ===========================================================================
HITL_ENV = "RULEPROOF_EVOLUTION_HITL_GOLDEN"
HITL_POLICY_VERSION = "l131.evolution_guard/v1"
HITL_ACTION_APPROVED = "evolution.hitl_approved"
HITL_ACTION_REJECTED = "evolution.hitl_rejected"
HITL_ACTION_BLOCKED = "evolution.hitl_blocked"
HITL_ACTION_REQUIRED = "evolution.hitl_required"
GOLDEN_ACTION = "evolution.golden_gate"
ROLLBACK_ACTION = "evolution.rollback"
HITL_ACTIONS = (HITL_ACTION_APPROVED, HITL_ACTION_REJECTED,
                HITL_ACTION_BLOCKED, HITL_ACTION_REQUIRED)
GUARD_ACTIONS = HITL_ACTIONS + (GOLDEN_ACTION, ROLLBACK_ACTION)
GOLDEN_CONFIG_KEY = "evolution.golden_set"
GOLDEN_MAX_CASES = 2000
GUARD_AUDIT_MAX_CHARS = 4000
GOLDEN_VERDICT_PASS = "pass"
GOLDEN_VERDICT_DEGRADED = "degraded"
GOLDEN_VERDICT_INSUFFICIENT = "insufficient_evidence"
GOLDEN_VERDICT_DISABLED = "disabled"
GOLDEN_TOLERANCE = 0.0
# 污染防护：黄金/训练用途只允许强人工标记（与 hidden_evolution.USAGE_POLICY 同口径）
_STRONG_LABEL_STRENGTHS = ("strong_human", "weak_human")


def hitl_enabled() -> bool:
    """L131 开关：默认 1=启用人工审批+黄金集回归；显式 =0 逐字节回退旧 gate/shadow 行为。

    字面量读取（不用变量间接）刻意为之：开关注册表/一致性扫描门禁按
    ``os.environ.get("RULEPROOF_*")`` 字面量识别开关，新开关必须可被扫描/登记。
    """
    return str(os.environ.get("RULEPROOF_EVOLUTION_HITL_GOLDEN", "1")).strip().lower() not in (
        "0", "false", "no", "off", "disabled")


def hitl_policy() -> dict:
    """机读策略（供审批视图/报告/门禁断言；不含可执行逻辑）。"""
    return {
        "policy_version": HITL_POLICY_VERSION,
        "enabled": hitl_enabled(),
        "env": HITL_ENV,
        "env_default": "1",
        "approval_required": True,
        "auto_promote_allowed": False,
        "approval_roles": ["admin", "evo.manage 授权角色"],
        "golden_regression_required": True,
        "golden_no_set_policy": "insufficient_evidence → 管理员显式 acknowledge 才可批准",
        "golden_degradation_policy": "任一用例退化/召回下降/误报上升 → 阻断（不可被审批覆盖）",
        "golden_config_key": GOLDEN_CONFIG_KEY,
        "audit_actions": list(GUARD_ACTIONS),
        "rollback_actions": ["rule_version", "ontology_alias", "rule_param_behavior"],
        "rollback_audit_action": ROLLBACK_ACTION,
        "rollback_guard": "rsi_protocol.rollback（事务 + 审计 + 幂等；旧版本/旧别名保留可恢复）",
        "pollution_checks": ["source_mark", "training_mark", "duplicate", "stale_base",
                             "candidate_supplied_golden", "golden_scope", "empty_snapshot"],
        "rollback": "显式 RULEPROOF_EVOLUTION_HITL_GOLDEN=0 → 审批/黄金集/污染复检全部 no-op"
                    "（gate/shadow 旧行为逐字节回退）",
    }


# ---------------- 审计证据（只读 audit_log，不新增表） ----------------
def _guard_audit(action: str, object_id: str, payload: dict, actor: str = "") -> str:
    """写一条 L131 护栏审计（object=候选/规则 id）；失败只告警，不伪造成功。"""
    try:
        body = dict(payload or {})
        body.setdefault("policy_version", HITL_POLICY_VERSION)
        body.setdefault("audit_action", action)
        audit_id = R.audit_logs.log(
            actor=actor or "system", action=str(action or ""),
            object=str(object_id or ""),
            after=json.dumps(body, ensure_ascii=False, sort_keys=True,
                             default=str)[:GUARD_AUDIT_MAX_CHARS])
        return str(audit_id or "")
    except Exception:  # noqa: BLE001 - 审计失败留日志，不阻断主链（不伪造成功）
        _LOG.warning("L131 护栏审计写入失败 action=%s object=%s", action, object_id,
                     exc_info=True)
        return ""


def _guard_events(candidate_id: str, actions=None, limit: int = 100) -> list:
    """读取某候选的 L131 审计事件（时间新→旧），解析 after_json 为机读证据。"""
    cid = str(candidate_id or "")
    if not cid:
        return []
    actions = tuple(actions or GUARD_ACTIONS)
    try:
        rows = R.audit_logs.list("object=?", (cid,),
                                 order="created_at DESC, rowid DESC",
                                 limit=max(int(limit or 100), 40))
    except Exception:  # noqa: BLE001
        return []
    out = []
    for row in rows or []:
        action = str(row.get("action") or "")
        if action not in actions:
            continue
        try:
            detail = json.loads(row.get("after_json") or "{}")
        except (TypeError, ValueError):
            detail = {"raw": str(row.get("after_json") or "")[:200]}
        if not isinstance(detail, dict):
            detail = {"value": detail}
        out.append({"at": row.get("created_at") or "", "action": action,
                    "actor": row.get("actor") or "", "detail": detail})
        if len(out) >= max(1, int(limit or 100)):
            break
    return out


def _guard_event_exists(candidate_id: str, action: str, code: str = "") -> bool:
    """同一候选同一动作同一 code 的审计幂等检查（避免审核循环反复刷审计）。"""
    for ev in _guard_events(candidate_id, (action,), limit=200):
        if not code or str(ev["detail"].get("code") or "") == str(code):
            return True
    return False


def _audit_block_once(candidate_id: str, action: str, payload: dict,
                      actor: str = "") -> bool:
    """阻断类审计：同候选同动作同 code 只写一次（幂等），返回是否新写入。"""
    cid = str(candidate_id or "")
    code = str((payload or {}).get("code") or "")
    if _guard_event_exists(cid, action, code):
        return False
    return bool(_guard_audit(action, cid, payload, actor=actor))


# ---------------- 人工审批身份校验（管理员动作，拒绝系统自动化） ----------------
def hitl_actor_check(by: str = "", user=None) -> dict:
    """人工审批/拒绝/上线动作的身份校验：只接受真实审核业务管理员。

    规则（fail-closed）：
    - 优先用 DB 角色（``account.roles_of``）：系统管理员/平台运营（业务写拒绝角色）→ 403；
      ``admin`` → 允许；其它角色需实际持有 ``evo.manage`` 权限点；
    - DB 查不到角色时，允许调用方传入已鉴权的会话 ``user.role``（HTTP ``_guard`` 已认证），
      但只接受 ``admin``（不接受 super_admin/platform_op/空角色）；
    - 无角色 / 系统自动化 actor（system / scheduler / gate-read 等）→ 403：
      人工审批不接受自动化 actor 冒充。
    """
    u = dict(user or {})
    uid = str(by or u.get("sub") or u.get("id") or "").strip()
    roles = []
    if uid:
        try:
            from . import account as _account
            roles = [str(x) for x in (_account.roles_of(uid) or [])]
        except Exception:  # noqa: BLE001 - 角色回查失败 fail-closed
            _LOG.warning("L131 审批角色回查失败（fail-closed）actor=%s", uid, exc_info=True)
            roles = []
    declared = str(u.get("role") or "").strip()
    try:
        from . import permissions as _perm_lazy
    except Exception:  # noqa: BLE001
        _perm_lazy = None
    if roles:
        if _perm_lazy is not None and any(_perm_lazy.write_denied(r) for r in roles):
            return {"ok": False, "status": 403, "code": "forbidden",
                    "error": "系统管理员/平台运营不写审核业务，不能审批自进化候选",
                    "actor": uid, "roles": roles}
        if "admin" in roles:
            return {"ok": True, "actor": uid, "role": "admin", "roles": roles}
        if _perm_lazy is not None and uid:
            try:
                if _perm_lazy.has(uid, "evo.manage"):
                    return {"ok": True, "actor": uid, "role": "custom_evo_manage",
                            "roles": roles}
            except Exception:  # noqa: BLE001
                pass
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "人工审批需要 admin 或 evo.manage 授权角色",
                "actor": uid, "roles": roles}
    if declared:
        if _perm_lazy is not None and _perm_lazy.write_denied(declared):
            return {"ok": False, "status": 403, "code": "forbidden",
                    "error": "系统管理员/平台运营不写审核业务，不能审批自进化候选",
                    "actor": uid or "system", "roles": [declared]}
        if declared == "admin":
            return {"ok": True, "actor": uid or "system", "role": "admin",
                    "roles": [declared]}
        return {"ok": False, "status": 403, "code": "forbidden",
                "error": "人工审批需要 admin 角色（当前声明角色不可审批）",
                "actor": uid or "system", "roles": [declared]}
    return {"ok": False, "status": 403, "code": "forbidden",
            "error": "人工审批必须由已鉴权管理员执行（拒绝无角色/系统自动化 actor）",
            "actor": uid or "system", "roles": []}


# ---------------- 候选内容摘要（审批绑定，防审批后篡改） ----------------
def candidate_content_sha(candidate_id: str) -> dict:
    """候选内容摘要：与 L117 跨阶段防篡改同一口径（before/after 去谱系段）。"""
    cid = str(candidate_id or "")
    row, before, after = _candidate_payload(cid)
    if not row:
        return {"candidate_id": cid, "found": False, "sha": ""}
    lineage = _lineage_of(after) or _lineage_of(before)
    ctype = str(lineage.get("candidate_type")
                or _infer_candidate_type(row.get("action"), row.get("rule_code"),
                                         row.get("feedback_id")))
    return {"candidate_id": cid, "found": True,
            "sha": _scan_digest(before, after, ctype, row.get("action") or "",
                                row.get("rule_code") or ""),
            "candidate_type": ctype,
            "rule_code": str(row.get("rule_code") or ""),
            "action": str(row.get("action") or ""),
            "decision": str(row.get("decision") or "")}


# ---------------- 黄金集：校验 / 存取 / 隔离 ----------------
def _ctx_scope_l131() -> dict:
    tenant, workspace = _ctx_scope()
    return {"tenant_id": tenant, "workspace_id": workspace}


def _scope_matches(set_meta: dict, scope: dict = None) -> bool:
    """黄金集作用域校验：空作用域=全局；显式作用域必须与当前上下文一致（隔离）。"""
    meta = dict(set_meta or {})
    scope = dict(scope or _ctx_scope_l131())
    for key in ("tenant_id", "workspace_id"):
        want = str(meta.get(key) or "")
        have = str(scope.get(key) or "")
        if want and want != have:
            return False
    return True


def golden_cases_norm(cases, kind: str = "rule") -> dict:
    """黄金集用例校验（防脏数据/重复/冲突）：返回归一化用例 + issues。"""
    issues = []
    norm = []
    seen_ids = set()
    seen_inputs = {}
    kind = str(kind or "rule")
    for idx, raw in enumerate(list(cases or [])):
        if not isinstance(raw, dict):
            issues.append({"code": "dirty_case",
                           "detail": "第 %d 条用例不是对象：%s" % (idx + 1, type(raw).__name__)})
            continue
        cid = str(raw.get("id") or "").strip() or "case-%02d" % (idx + 1)
        if cid in seen_ids:
            issues.append({"code": "duplicate_case_id",
                           "detail": "黄金集用例 id 重复：%s" % cid})
            continue
        seen_ids.add(cid)
        text = raw.get("text") if raw.get("text") is not None else raw.get("input")
        if not isinstance(text, str) or not text.strip():
            issues.append({"code": "missing_case_input",
                           "detail": "用例 %s 缺少 text/input" % cid})
            continue
        exp = raw.get("expected")
        exp_state = raw.get("expected_state")
        exp_canonical = raw.get("expected_canonical")
        exp_contains = raw.get("expected_contains")
        forb_contains = raw.get("forbidden_contains")
        has_any = any(x is not None for x in (exp, exp_state, exp_canonical,
                                             exp_contains, forb_contains))
        if not has_any:
            issues.append({"code": "missing_case_expectation",
                           "detail": "用例 %s 缺少期望（expected/expected_state/"
                                     "expected_canonical/expected_contains）" % cid})
            continue
        if kind != "ontology" and exp is not None:
            if str(exp) not in ("confirmed", "false_positive", "fail", "pass"):
                issues.append({"code": "dirty_expected",
                               "detail": "用例 %s expected 非法：%r（合法：confirmed/"
                                         "false_positive/fail/pass）" % (cid, exp)})
                continue
        if kind == "ontology":
            if exp_canonical is None and exp is None:
                issues.append({"code": "missing_case_expectation",
                               "detail": "本体用例 %s 需要 expected_canonical" % cid})
                continue
        if kind == "prompt" and not (exp_contains or forb_contains):
            issues.append({"code": "missing_case_expectation",
                           "detail": "Prompt 用例 %s 需要 expected_contains/"
                                     "forbidden_contains" % cid})
            continue
        sig = json.dumps({k: raw.get(k) for k in
                          ("expected", "expected_state", "expected_canonical",
                           "expected_contains", "forbidden_contains")},
                         ensure_ascii=False, sort_keys=True)
        key = str(text).strip()
        if key in seen_inputs and seen_inputs[key] != sig:
            issues.append({"code": "conflicting_cases",
                           "detail": "同一输入出现冲突期望：%r（%s vs %s）"
                                     % (key[:60], seen_inputs[key][:80], sig[:80])})
            continue
        seen_inputs[key] = sig
        norm.append({"id": cid, "text": str(text), "expected": exp,
                     "expected_state": exp_state, "expected_canonical": exp_canonical,
                     "expected_contains": exp_contains,
                     "forbidden_contains": forb_contains,
                     "source": str(raw.get("source") or "")})
    if len(norm) > GOLDEN_MAX_CASES:
        issues.append({"code": "too_many_cases",
                       "detail": "黄金集用例 %d > 上限 %d" % (len(norm), GOLDEN_MAX_CASES)})
    digest = _sha256_text(_canonical(norm))[:32] if norm else ""
    return {"ok": not issues, "issues": issues, "kind": kind,
            "cases": norm, "count": len(norm), "digest": digest}


def set_golden_set(cases, name: str = "", kind: str = "rule",
                   tenant_id: str = None, workspace_id: str = None,
                   by: str = "", require_admin: bool = False) -> dict:
    """登记管理员指定的黄金集（存 sys_config，带租户/空间隔离作用域）。

    - 脏数据/重复/冲突期望 → 拒绝登记（不落库），返回 ``blocked=True``；
    - 作用域缺省 = 当前上下文；显式传入用于 CI/运营登记；
    - ``require_admin=True`` 时校验 ``by`` 为管理员（服务入口用；默认 False 供
      CI/迁移/测试以受控 actor 登记，登记本身仍写审计）。
    """
    kind = str(kind or "rule")
    if kind not in ("rule", "ontology", "prompt"):
        return {"ok": False, "blocked": True, "code": "invalid_kind",
                "error": "黄金集类型只支持 rule/ontology/prompt", "issues": []}
    norm = golden_cases_norm(cases, kind=kind)
    if not norm.get("ok"):
        return {"ok": False, "blocked": True, "status": "invalid_golden_set",
                "code": "dirty_golden_set",
                "error": "黄金集未通过脏数据/重复/冲突校验，未登记",
                "issues": norm.get("issues") or [], "kind": kind}
    if require_admin:
        actor = hitl_actor_check(by, None) if by else {"ok": False, "status": 403}
        if not actor.get("ok"):
            return {"ok": False, **{k: actor.get(k) for k in
                                    ("status", "code", "error", "actor", "roles")}}
    scope = _ctx_scope_l131()
    meta = {"set_id": "gs-" + norm["digest"][:12],
            "name": str(name or "默认黄金集")[:80],
            "kind": kind,
            "cases": norm["cases"],
            "count": norm["count"],
            "digest": norm["digest"],
            "tenant_id": str(tenant_id if tenant_id is not None else scope["tenant_id"]),
            "workspace_id": str(workspace_id if workspace_id is not None
                                else scope["workspace_id"]),
            "created_by": str(by or ""),
            "created_at": db.now(),
            "policy_version": HITL_POLICY_VERSION}
    try:
        from . import sysconfig as _sysconfig
        _sysconfig.set_many({GOLDEN_CONFIG_KEY: json.dumps(meta, ensure_ascii=False)})
    except Exception as e:  # noqa: BLE001 - 落库失败必须可见
        return {"ok": False, "status": "storage_unavailable",
                "error": "黄金集落库失败：%s" % type(e).__name__, "kind": kind}
    _guard_audit(GOLDEN_ACTION, "golden_set",
                 {"op": "set_updated", "set_id": meta["set_id"], "kind": kind,
                  "count": meta["count"], "digest": meta["digest"],
                  "scope": {"tenant_id": meta["tenant_id"],
                            "workspace_id": meta["workspace_id"]}},
                 actor=by)
    return {"ok": True, "set": {k: meta[k] for k in
                                ("set_id", "name", "kind", "count", "digest",
                                 "tenant_id", "workspace_id", "created_at")},
            "scope": {"tenant_id": meta["tenant_id"],
                      "workspace_id": meta["workspace_id"]}}


def load_golden_set(with_cases: bool = True) -> dict:
    """读取已登记黄金集 + 当前上下文作用域校验（隔离失败按「无可用黄金集」处理）。"""
    try:
        from . import sysconfig as _sysconfig
        raw = _sysconfig.get(GOLDEN_CONFIG_KEY, "")
    except Exception:  # noqa: BLE001
        raw = ""
    if not raw:
        return {"available": False, "reason": "未登记黄金集（%s 为空）" % GOLDEN_CONFIG_KEY,
                "isolation_ok": True, "meta": {}}
    try:
        meta = json.loads(raw) if isinstance(raw, str) else dict(raw)
    except (TypeError, ValueError):
        return {"available": False, "reason": "黄金集内容不可解析（脏数据，需管理员重登记）",
                "isolation_ok": False, "meta": {}}
    if not isinstance(meta, dict):
        return {"available": False, "reason": "黄金集格式非法（需对象）",
                "isolation_ok": False, "meta": {}}
    norm = golden_cases_norm(meta.get("cases") or [], kind=str(meta.get("kind") or "rule"))
    if not norm.get("ok"):
        return {"available": False,
                "reason": "黄金集校验未通过（脏数据/重复/冲突）：%s"
                          % "；".join(x.get("detail") or "" for x in norm.get("issues") or []),
                "isolation_ok": False, "meta": meta}
    isolation_ok = _scope_matches(meta)
    if not isolation_ok:
        return {"available": False, "isolation_ok": False, "meta": meta,
                "reason": "黄金集作用域隔离：黄金集属于 tenant=%s/workspace=%s，"
                          "与当前上下文 tenant=%s/workspace=%s 不一致"
                          % (meta.get("tenant_id") or "全局", meta.get("workspace_id") or "全局",
                             _ctx_scope_l131()["tenant_id"] or "全局",
                             _ctx_scope_l131()["workspace_id"] or "全局")}
    out = {"available": True, "isolation_ok": True, "meta": meta,
           "kind": str(meta.get("kind") or "rule"),
           "set_id": str(meta.get("set_id") or ""),
           "digest": str(meta.get("digest") or norm.get("digest") or ""),
           "count": int(meta.get("count") or norm.get("count") or 0),
           "reason": ""}
    if with_cases:
        out["cases"] = norm["cases"]
    return out


def clear_golden_set(by: str = "") -> dict:
    """清除已登记黄金集（回退/重登记用；写审计）。"""
    try:
        from . import sysconfig as _sysconfig
        _sysconfig.delete_keys([GOLDEN_CONFIG_KEY])
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": "清除黄金集失败：%s" % type(e).__name__}
    _guard_audit(GOLDEN_ACTION, "golden_set", {"op": "cleared"}, actor=by)
    return {"ok": True, "cleared": True}


# ---------------- 黄金集全量回归：逐例 before/after 评估 ----------------
def _rule_slots_of(snapshot) -> tuple:
    """取候选快照中可执行判据（版本 latest→effective→slots→pending→params）。"""
    snap = snapshot if isinstance(snapshot, dict) else {}
    version = snap.get("version") if isinstance(snap.get("version"), dict) else {}
    for key in ("latest", "effective"):
        row = version.get(key) if isinstance(version.get(key), dict) else {}
        slots = row.get("slots") if isinstance(row, dict) else None
        if isinstance(slots, dict) and slots:
            return dict(slots), "version.%s" % key
    slots = snap.get("slots")
    if isinstance(slots, dict) and slots:
        return dict(slots), "slots"
    for key in ("pending", "params"):
        data = snap.get(key)
        if isinstance(data, dict) and data:
            return dict(data), key
    return {}, ""


def _rule_case_eval(slots: dict, case: dict) -> dict:
    """单条规则黄金用例：judge_rule(不满足=命中)。返回 {ok, fired, state, reason}。"""
    from ..engine import ruleexec
    state = ""
    try:
        res = ruleexec.judge_rule(dict(slots or {}), str(case.get("text") or ""), []) or {}
        state = str(res.get("state") or "")
    except Exception as e:  # noqa: BLE001 - 执行失败=无法评估，不伪装成命中/未命中
        return {"ok": None, "fired": None, "state": "执行失败",
                "reason": "%s: %s" % (type(e).__name__, str(e)[:120])}
    if state not in ("满足", "不满足", "证据不足", "不适用"):
        return {"ok": None, "fired": None, "state": state or "unknown",
                "reason": "规则执行失败，无法作为黄金集证据"}
    fired = state == "不满足"
    exp_state = case.get("expected_state")
    if exp_state is not None:
        return {"ok": state == str(exp_state), "fired": fired, "state": state,
                "reason": "expected_state=%s actual=%s" % (exp_state, state)}
    expected = str(case.get("expected") or "")
    if expected in ("confirmed", "fail"):
        return {"ok": fired, "fired": fired, "state": state, "reason": ""}
    if expected in ("false_positive", "pass"):
        return {"ok": not fired, "fired": fired, "state": state, "reason": ""}
    return {"ok": None, "fired": fired, "state": state,
            "reason": "用例缺少可判定的 expected"}


def _ontology_case_eval(snapshot, canonical: str, case: dict) -> dict:
    aliases = []
    if isinstance(snapshot, dict):
        raw = snapshot.get("aliases")
        if isinstance(raw, list):
            aliases = [str(x).strip() for x in raw if str(x).strip()]
    text = str(case.get("text") or "").strip()
    matched = canonical if text in aliases else ""
    expected = case.get("expected_canonical")
    if expected is None:
        expected = case.get("expected")
    expected = "" if expected is None else str(expected).strip()
    if expected and expected != canonical:
        return {"ok": None, "matched": matched,
                "reason": "本体用例期望 %r 与候选 canonical %r 不一致" % (expected, canonical)}
    return {"ok": matched == expected, "matched": matched, "state": matched or "未命中",
            "reason": ""}


def _prompt_text_of(snapshot) -> str:
    snap = snapshot if isinstance(snapshot, dict) else {}
    for key in ("prompt", "prompt_text", "_prompt", "content", "text"):
        val = snap.get(key)
        if isinstance(val, str) and val.strip():
            return val
    return ""


def _prompt_case_eval(snapshot, case: dict) -> dict:
    text = _prompt_text_of(snapshot)
    if not text:
        return {"ok": None, "state": "", "reason": "候选快照无 Prompt 文本，无法评估"}
    req = case.get("expected_contains")
    forb = case.get("forbidden_contains")
    req = [req] if isinstance(req, str) else list(req or [])
    forb = [forb] if isinstance(forb, str) else list(forb or [])
    missing = [str(x) for x in req if str(x) not in text]
    present = [str(x) for x in forb if str(x) in text]
    ok = not missing and not present
    return {"ok": ok, "state": "通过" if ok else "不通过",
            "reason": ("缺少必须内容：%s" % missing if missing else "")
                      + ("；出现禁止内容：%s" % present if present else "")}


def evaluate_golden_snapshot(kind: str, before, after, cases) -> dict:
    """黄金集全量回归（纯函数，不写库）：逐例 before/after 对比 → 退化判定。

    kind：rule（judge_rule 判据）/ ontology（别名映射）/ prompt（提示词内容断言）。
    任一用例「before 通过、after 不通过」→ 退化；召回下降/误报上升/准确率下降
    同样判退化。无法评估的用例计入 unevaluable（不按通过处理）。
    """
    kind = str(kind or "rule")
    cases = list(cases or [])
    slots_b, basis_b = _rule_slots_of(before)
    slots_a, basis_a = _rule_slots_of(after)
    canonical = ""
    if kind == "ontology":
        for snap in (after, before):
            if isinstance(snap, dict) and isinstance(snap.get("canonical"), str):
                canonical = snap["canonical"].strip()
                if canonical:
                    break
    rows, regressions, improvements = [], [], []
    stats = {"before": {"evaluated": 0, "pass": 0, "tp": 0, "fn": 0, "fp": 0, "tn": 0},
             "after": {"evaluated": 0, "pass": 0, "tp": 0, "fn": 0, "fp": 0, "tn": 0}}
    for case in cases:
        cid = str(case.get("id") or "")
        if kind == "rule":
            if not slots_b and not slots_a:
                rb = ra = {"ok": None, "fired": None, "state": "",
                           "reason": "候选 before/after 均无可用判据"}
            else:
                rb = _rule_case_eval(slots_b, case) if slots_b else {
                    "ok": None, "fired": None, "state": "", "reason": "before 无判据"}
                ra = _rule_case_eval(slots_a, case) if slots_a else {
                    "ok": None, "fired": None, "state": "", "reason": "after 无判据"}
        elif kind == "ontology":
            rb = _ontology_case_eval(before, canonical, case)
            ra = _ontology_case_eval(after, canonical, case)
        elif kind == "prompt":
            rb = _prompt_case_eval(before, case)
            ra = _prompt_case_eval(after, case)
        else:
            rb = ra = {"ok": None, "reason": "未知黄金集类型 %r" % kind}
        row = {"id": cid, "input": str(case.get("text") or "")[:120],
               "before": rb.get("ok"), "after": ra.get("ok"),
               "before_state": str(rb.get("state") or ""),
               "after_state": str(ra.get("state") or ""),
               "reason": str(ra.get("reason") or rb.get("reason") or "")[:200]}
        for side, r in (("before", rb), ("after", ra)):
            if r.get("ok") is None:
                continue
            stats[side]["evaluated"] += 1
            if r["ok"]:
                stats[side]["pass"] += 1
            if kind == "rule":
                expected = str(case.get("expected") or "")
                fired = bool(r.get("fired"))
                if expected in ("confirmed", "fail"):
                    key = "tp" if fired else "fn"
                elif expected in ("false_positive", "pass"):
                    key = "fp" if fired else "tn"
                else:
                    key = ""
                if key:
                    stats[side][key] += 1
        if rb.get("ok") is True and ra.get("ok") is False:
            regressions.append(row)
        elif rb.get("ok") is False and ra.get("ok") is True:
            improvements.append(row)
        elif rb.get("ok") is None and ra.get("ok") is True:
            improvements.append(row)
        rows.append(row)
    metrics = {}
    for side in ("before", "after"):
        st = stats[side]
        ev = st["evaluated"]
        metrics[side] = {
            "evaluated": ev, "pass": st["pass"],
            "accuracy": (round(st["pass"] / ev, 4) if ev else None),
            "recall": (round(st["tp"] / (st["tp"] + st["fn"]), 4)
                       if (st["tp"] + st["fn"]) else None),
            "false_positive_rate": (round(st["fp"] / (st["fp"] + st["tn"]), 4)
                                    if (st["fp"] + st["tn"]) else None),
            "confusion": {k: st[k] for k in ("tp", "fn", "fp", "tn")},
        }
    evaluated = min(stats["before"]["evaluated"], stats["after"]["evaluated"])
    total = len(cases)
    after_only = (stats["before"]["evaluated"] == 0
                  and stats["after"]["evaluated"] > 0)
    reasons = []
    if total == 0:
        verdict = GOLDEN_VERDICT_INSUFFICIENT
        reasons.append("黄金集为空，证据不足")
    elif evaluated == 0 and after_only:
        # 无 before 基线（典型：Prompt 候选只带新提示词）：按黄金集绝对期望评估，
        # 任一用例不满足 → 不作为退化，而是直接阻断（无法证明不退化）。
        a_st = stats["after"]
        if a_st["pass"] < a_st["evaluated"]:
            verdict = GOLDEN_VERDICT_DEGRADED
            reasons.append("无 before 基线且黄金集绝对期望未全通过"
                           "（%d/%d 通过）" % (a_st["pass"], a_st["evaluated"]))
            for _row in rows:
                if _row.get("after") is False:
                    regressions.append({**_row, "before": None,
                                        "reason": "无 before 基线：绝对期望未通过"})
        else:
            verdict = GOLDEN_VERDICT_PASS
            reasons.append("无 before 基线：按黄金集绝对期望评估，after 全部通过")
            reasons = []
    elif evaluated == 0:
        verdict = GOLDEN_VERDICT_INSUFFICIENT
        reasons.append("黄金集全部用例不可评估（候选快照无可用判据/期望不匹配）")
    else:
        if regressions:
            reasons.append("逐例退化 %d 条：%s" % (
                len(regressions), "、".join(x["id"] for x in regressions[:5])))
        b, a = metrics["before"], metrics["after"]
        if (b["accuracy"] is not None and a["accuracy"] is not None
                and a["accuracy"] < b["accuracy"] - GOLDEN_TOLERANCE):
            reasons.append("准确率下降 %.4f → %.4f" % (b["accuracy"], a["accuracy"]))
        if (b["recall"] is not None and a["recall"] is not None
                and a["recall"] < b["recall"] - GOLDEN_TOLERANCE):
            reasons.append("召回下降 %.4f → %.4f" % (b["recall"], a["recall"]))
        if (b["false_positive_rate"] is not None and a["false_positive_rate"] is not None
                and a["false_positive_rate"] > b["false_positive_rate"] + GOLDEN_TOLERANCE):
            reasons.append("误报率上升 %.4f → %.4f"
                           % (b["false_positive_rate"], a["false_positive_rate"]))
        verdict = GOLDEN_VERDICT_DEGRADED if reasons else GOLDEN_VERDICT_PASS
    return {"kind": kind, "verdict": verdict, "total": total,
            "evaluated": (evaluated if not after_only
                          else stats["after"]["evaluated"]),
            "unevaluable": total - (evaluated if not after_only
                                     else stats["after"]["evaluated"]),
            "after_only": after_only,
            "regressions": regressions[:20], "improvements": improvements[:20],
            "reasons": reasons,
            "metrics": metrics,
            "basis": {"before": basis_b, "after": basis_a},
            "case_results": rows[:100],
            "degraded": verdict == GOLDEN_VERDICT_DEGRADED,
            "sufficient": verdict != GOLDEN_VERDICT_INSUFFICIENT}


def golden_regression(candidate_id: str, golden=None) -> dict:
    """候选黄金集全量回归门（读候选快照 + 管理员指定/已登记黄金集）。

    - golden 参数：显式指定（dict {cases,set_id,...} 或 cases 列表）= 管理员本次指定；
    - 未显式指定 → 读已登记黄金集（``set_golden_set``，带作用域隔离）；
    - 候选自带 ``_golden``/golden 字段**不得作为自证证据**（污染防护：仅记 issue）；
    - 无黄金集 / 作用域隔离不符 / 脏黄金集 / 无法评估 → insufficient_evidence
      （调用方必须要求管理员显式 acknowledge，不得默认放行）。
    """
    cid = str(candidate_id or "")
    if not hitl_enabled():
        return {"ok": True, "enabled": False, "verdict": GOLDEN_VERDICT_DISABLED,
                "candidate_id": cid, "reasons": ["RULEPROOF_EVOLUTION_HITL_GOLDEN=0：回退"],
                "degraded": False, "sufficient": True, "regressions": []}
    row, before, after = _candidate_payload(cid)
    if not row:
        return {"ok": False, "enabled": True, "verdict": GOLDEN_VERDICT_INSUFFICIENT,
                "candidate_id": cid, "reasons": ["候选不存在"], "degraded": False,
                "sufficient": False, "regressions": []}
    hashes = candidate_content_sha(cid)
    ctype = hashes.get("candidate_type") or ""
    action = hashes.get("action") or ""
    code = hashes.get("rule_code") or ""
    if str(action).startswith("ontology.") or str(code).startswith("ONTO:") or ctype == "ontology":
        kind = "ontology"
    elif ctype == "prompt" or str(action).startswith("prompt.") or (
            not _rule_slots_of(after)[0] and _prompt_text_of(after)):
        kind = "prompt"
    else:
        kind = "rule"
    scope = _ctx_scope_l131()
    set_meta = {"set_id": "", "name": "显式指定", "digest": "", "count": 0,
                "scope": scope}
    resolved = {"available": False, "reason": "未指定黄金集"}
    if isinstance(golden, dict) or isinstance(golden, list):
        raw_cases = golden.get("cases") if isinstance(golden, dict) else golden
        norm = golden_cases_norm(raw_cases, kind=kind)
        if not norm.get("ok"):
            resolved = {"available": False, "isolation_ok": False,
                        "reason": "显式黄金集校验失败（脏数据/重复/冲突）：%s"
                                  % "；".join(x.get("detail") or ""
                                             for x in norm.get("issues") or [])}
        elif not _scope_matches(golden if isinstance(golden, dict) else {}, scope):
            resolved = {"available": False, "isolation_ok": False,
                        "reason": "显式黄金集作用域隔离：不属于当前上下文"}
        else:
            resolved = {"available": True, "isolation_ok": True, "cases": norm["cases"],
                        "kind": kind, "digest": norm["digest"],
                        "set_id": str((golden or {}).get("set_id") or
                                      ("explicit-" + norm["digest"][:8]))
                        if isinstance(golden, dict) else
                        ("explicit-" + norm["digest"][:8]),
                        "count": norm["count"]}
            set_meta.update({"set_id": resolved["set_id"], "digest": norm["digest"],
                             "count": norm["count"]})
    else:
        resolved = load_golden_set(with_cases=True)
        if resolved.get("available"):
            set_meta = {"set_id": resolved.get("set_id") or "",
                        "name": str((resolved.get("meta") or {}).get("name") or ""),
                        "digest": resolved.get("digest") or "",
                        "count": resolved.get("count") or 0,
                        "scope": {"tenant_id": (resolved.get("meta") or {}).get("tenant_id") or "",
                                  "workspace_id": (resolved.get("meta") or {}).get("workspace_id") or ""}}
            # 黄金集类型与候选类型不一致 → 不能作为该候选的证据
            if str(resolved.get("kind") or "rule") != kind:
                resolved = {"available": False, "isolation_ok": True,
                            "reason": "黄金集类型 %s 与候选类型 %s 不匹配"
                                      % (resolved.get("kind"), kind)}
    base = {"ok": True, "enabled": True, "candidate_id": cid,
            "candidate_sha": hashes.get("sha"), "kind": kind,
            "candidate_type": ctype, "action": action, "rule_code": code,
            "set": set_meta, "evaluated_at": db.now(),
            "scope": scope}
    if not resolved.get("available"):
        return {**base, "verdict": GOLDEN_VERDICT_INSUFFICIENT, "degraded": False,
                "sufficient": False, "evaluated": 0, "total": 0,
                "reasons": [str(resolved.get("reason") or "无可用黄金集")],
                "regressions": [], "metrics": {},
                "isolation_ok": bool(resolved.get("isolation_ok", True))}
    b_snap, a_snap = before, after
    if kind == "ontology":
        canonical = str(code.split("ONTO:", 1)[1] if "ONTO:" in code else "").strip()
        b_snap = dict(before) if isinstance(before, dict) else {}
        a_snap = dict(after) if isinstance(after, dict) else {}
        if canonical:
            b_snap["canonical"] = canonical
            a_snap["canonical"] = canonical
    result = evaluate_golden_snapshot(kind, b_snap, a_snap,
                                      resolved.get("cases") or [])
    return {**base, **result,
            "isolation_ok": True, "cases_digest": resolved.get("digest") or ""}


def record_golden_evidence(candidate_id: str, result: dict, actor: str = "") -> str:
    """把一次黄金集回归结果写审计（审批/上线前的机读证据；同证据幂等不重复刷）。"""
    res = dict(result or {})
    _sha = str(res.get("candidate_sha") or "")
    _verdict = str(res.get("verdict") or "")
    _set_digest = str((res.get("set") or {}).get("digest")
                      or res.get("cases_digest") or "")
    for _ev in _guard_events(str(candidate_id or ""), (GOLDEN_ACTION,), limit=20):
        _d = _ev.get("detail") or {}
        if (str(_d.get("candidate_sha") or "") == _sha
                and str(_d.get("verdict") or "") == _verdict
                and str((_d.get("set") or {}).get("digest") or "") == _set_digest
                and str(_d.get("op") or "") == "regression"):
            return ""  # 相同证据已落库：幂等返回，不重复写审计
    payload = {"op": "regression", "candidate_id": str(candidate_id or ""),
               "candidate_sha": res.get("candidate_sha") or "",
               "verdict": res.get("verdict") or "",
               "kind": res.get("kind") or "",
               "evaluated": res.get("evaluated"), "total": res.get("total"),
               "regressions": [x.get("id") for x in (res.get("regressions") or [])][:20],
               "reasons": (res.get("reasons") or [])[:10],
               "metrics": res.get("metrics") or {},
               "set": {k: (res.get("set") or {}).get(k) for k in
                       ("set_id", "name", "digest", "count")},
               "isolation_ok": res.get("isolation_ok")}
    return _guard_audit(GOLDEN_ACTION, str(candidate_id or ""), payload, actor=actor)


# ---------------- 污染防护：来源/训练数据标记 + 脏/重/冲突 + 黄金集隔离 ----------------
def _live_effective_version(rule_code: str) -> dict:
    """规则库当前生效版本（只读；用于候选基线过期检测）。"""
    code = str(rule_code or "").strip()
    if not code:
        return {}
    try:
        rows = R.rules.list("code=?", (code,), order="rowid DESC", limit=1)
    except Exception:  # noqa: BLE001
        return {}
    if not rows:
        return {}
    rid = str(rows[0].get("id") or "")
    try:
        pub = R.rules.published_version(rid)
    except Exception:  # noqa: BLE001
        pub = None
    if not pub:
        try:
            for ver in reversed(R.rule_versions.list("rule_id=?", (rid,))):
                if str(ver.get("status") or "") == "published":
                    pub = ver
                    break
        except Exception:  # noqa: BLE001
            pub = None
    if not pub:
        return {}
    return {"rule_id": rid, "version": str(pub.get("version") or ""),
            "version_id": str(pub.get("id") or "")}


def pollution_scan(candidate_id: str, golden=None) -> dict:
    """候选污染防护扫描（只读）：来源/训练数据标记 + 脏/重/冲突 + 黄金集隔离。"""
    cid = str(candidate_id or "")
    row, before, after = _candidate_payload(cid)
    issues = []
    checked = []
    if not row:
        return {"ok": False, "candidate_id": cid,
                "issues": [{"code": "candidate_missing",
                            "detail": "候选不存在，无法做污染复检"}],
                "checked": [], "policy_version": HITL_POLICY_VERSION}
    hash_info = candidate_content_sha(cid)
    ctype = hash_info.get("candidate_type") or ""
    code = hash_info.get("rule_code") or ""
    action = hash_info.get("action") or ""
    lineage = _lineage_of(after) or _lineage_of(before)
    src = lineage.get("source") if isinstance(lineage.get("source"), dict) else {}
    source_marked = bool(lineage) and bool(
        src.get("rule_code") or src.get("feedback_id") or src.get("action"))
    if not source_marked:
        issues.append({"code": "unmarked_source",
                       "detail": "候选来源未标记（缺 _lineage.source：rule_code/action/"
                                 "feedback_id），无法追溯训练/反馈来源"})
    checked.append("source_mark")
    if lineage and source_marked and not str(lineage.get("scan_sha256") or ""):
        issues.append({"code": "lineage_digest_missing",
                       "detail": "候选谱系缺扫描摘要（scan_sha256），无法防跨阶段篡改"})
    # 训练/黄金数据标记：出现在候选快照里的训练集/黄金集必须带来源与强人工标签
    for key in ("training", "training_data", "gold", "golden", "labels", "annotation"):
        if not isinstance(after, dict) or key not in after:
            continue
        raw = after.get(key)
        items = raw if isinstance(raw, list) else ([raw] if isinstance(raw, dict) else [])
        for item in items:
            if not isinstance(item, dict):
                issues.append({"code": "unmarked_training",
                               "detail": "候选 %r 段含未结构化数据：%s"
                                         % (key, type(item).__name__)})
                continue
            if not str(item.get("source") or "").strip():
                issues.append({"code": "unmarked_training",
                               "detail": "候选 %r 段数据缺少 source 标记（训练数据来源不可追）"
                                         % key})
            strength = str(item.get("label_strength") or "").strip()
            if strength and strength not in _STRONG_LABEL_STRENGTHS:
                issues.append({"code": "weak_label_contamination",
                               "detail": "候选 %r 段使用弱标签 label_strength=%r "
                                         "进入黄金/训练用途（必须强人工标签）"
                                         % (key, strength)})
            if item.get("auto") is True and key in ("gold", "golden", "training",
                                                    "training_data"):
                issues.append({"code": "auto_label_contamination",
                               "detail": "候选 %r 段使用自动标签进入黄金/训练用途" % key})
        checked.append("training_mark:" + key)
    # 候选自带黄金集/黄金集引用：不得自证（黄金集必须外部管理员指定）
    for key in ("_golden", "golden", "golden_set", "golden_cases", "golden_config"):
        if isinstance(after, dict) and after.get(key):
            issues.append({"code": "candidate_supplied_golden",
                           "detail": "候选自带 %r 黄金集/配置，不得作为自身回归证据"
                                     "（黄金集必须由管理员外部指定并隔离）" % key})
            checked.append("candidate_golden")
            break
    # 重复候选：同 rule_code/action 且 before/after 内容摘要一致（排除已回滚）
    try:
        others = (R.rsi_candidates.list("rule_code=?", (code,), order="rowid DESC", limit=200)
                  if code else [])
    except Exception:  # noqa: BLE001
        others = []
    for other in others or []:
        oid = str(other.get("id") or "")
        if not oid or oid == cid:
            continue
        if str(other.get("action") or "") != action:
            continue
        if str(other.get("decision") or "") in ("rolled_back",):
            continue
        _o_row, o_before, o_after = _candidate_payload(oid, row=dict(other))
        o_ctype = str((_lineage_of(o_after) or _lineage_of(o_before)).get("candidate_type")
                      or ctype)
        o_sha = _scan_digest(o_before, o_after, o_ctype,
                             str(other.get("action") or ""),
                             str(other.get("rule_code") or ""))
        if o_sha == hash_info.get("sha"):
            issues.append({"code": "duplicate_candidate",
                           "detail": "与候选 %s 内容摘要完全一致（重复候选，疑似重复沉淀/污染）"
                                     % oid})
            break
    checked.append("duplicate")
    # 基线过期：版本型候选的 before 生效版本已不是当前生效版本（基于旧底稿的修订）
    version = before.get("version") if isinstance(before.get("version"), dict) else {}
    eff = version.get("effective") if isinstance(version.get("effective"), dict) else {}
    if eff.get("id") or eff.get("version"):
        live = _live_effective_version(code)
        if live and live.get("version_id") and str(eff.get("id") or "") \
                and str(live["version_id"]) != str(eff.get("id")):
            issues.append({"code": "stale_base",
                           "detail": "候选基于旧生效版本 %s（当前生效 %s），修订基线已过期"
                                     % (eff.get("version") or eff.get("id"),
                                        live.get("version") or live.get("version_id"))})
        checked.append("stale_base")
    # 空快照：before/after 均无内容 → 无法追溯改动
    if not before and not after:
        issues.append({"code": "empty_snapshot",
                       "detail": "候选 before/after 快照均为空，无法做污染/回归复检"})
    checked.append("empty_snapshot")
    # 黄金集隔离：显式传入的黄金集作用域与当前上下文不一致 → 泄漏/越权证据
    if isinstance(golden, dict) and not _scope_matches(golden):
        issues.append({"code": "golden_scope_leak",
                       "detail": "黄金集作用域与当前上下文不一致（跨租户/空间使用被拒）"})
        checked.append("golden_scope")
    dedup = []
    seen = set()
    for issue in issues:
        code_key = (issue.get("code"), issue.get("detail"))
        if code_key in seen:
            continue
        seen.add(code_key)
        dedup.append(issue)
    return {"ok": not dedup, "candidate_id": cid,
            "candidate_type": ctype, "rule_code": code, "action": action,
            "candidate_sha": hash_info.get("sha") or "",
            "issues": dedup, "checked": checked,
            "source_marked": source_marked,
            "policy_version": HITL_POLICY_VERSION}


# ---------------- 人工审批：记录 / 状态 / 上线闸口 ----------------
def approval_status(candidate_id: str) -> dict:
    """候选审批状态（最新审批/拒绝证据 + 内容摘要绑定校验）。"""
    cid = str(candidate_id or "")
    hashes = candidate_content_sha(cid)
    out = {"candidate_id": cid, "hitl_enabled": hitl_enabled(),
           "policy_version": HITL_POLICY_VERSION,
           "candidate_sha": hashes.get("sha") or "",
           "approved": False, "status": "disabled" if not hitl_enabled() else "missing",
           "reason": "", "approval": {}, "golden": {}, "ack_insufficient_evidence": False}
    if not hitl_enabled():
        out["approved"] = True  # =0 回退：不要求审批（旧行为）
        out["reason"] = "RULEPROOF_EVOLUTION_HITL_GOLDEN=0：人工审批门已回退"
        return out
    if not cid or not hashes.get("found"):
        out.update({"status": "candidate_missing", "reason": "候选不存在"})
        return out
    events = _guard_events(cid, (HITL_ACTION_APPROVED, HITL_ACTION_REJECTED), limit=50)
    if not events:
        out["reason"] = "候选上线前必须人工审批：尚无管理员审批记录"
        return out
    latest = events[0]
    detail = latest.get("detail") or {}
    out["approval"] = detail
    if latest.get("action") == HITL_ACTION_REJECTED:
        out.update({"status": "rejected",
                    "reason": "管理员已拒绝该候选：%s" % (detail.get("reason") or "")})
        return out
    if str(detail.get("candidate_sha") or "") != str(hashes.get("sha") or ""):
        out.update({"status": "stale",
                    "reason": "审批后候选内容被修改（摘要不一致，需重新审批）"})
        return out
    if str(detail.get("policy_version") or "") != HITL_POLICY_VERSION:
        out.update({"status": "stale", "reason": "审批策略版本已变更，需重新审批"})
        return out
    golden = detail.get("golden") if isinstance(detail.get("golden"), dict) else {}
    out.update({"approved": True, "status": "approved",
                "approver": latest.get("actor") or detail.get("actor") or "",
                "approved_at": latest.get("at") or detail.get("approved_at") or "",
                "role": detail.get("role") or "",
                "golden": golden,
                "ack_insufficient_evidence": bool(detail.get("ack_insufficient_evidence")),
                "reason": ""})
    verdict = str(golden.get("verdict") or "")
    if verdict == GOLDEN_VERDICT_DEGRADED:
        out.update({"approved": False, "status": "golden_degraded",
                    "reason": "黄金集回归退化，审批不得覆盖阻断"})
    elif verdict == GOLDEN_VERDICT_INSUFFICIENT and not out["ack_insufficient_evidence"]:
        out.update({"approved": False, "status": "golden_insufficient",
                    "reason": "黄金集证据不足且审批未显式确认"})
    elif verdict not in (GOLDEN_VERDICT_PASS, GOLDEN_VERDICT_INSUFFICIENT):
        out.update({"approved": False, "status": "golden_missing",
                    "reason": "审批缺少黄金集回归证据"})
    return out


def record_approval(candidate_id: str, by: str = "", user=None, note: str = "",
                    golden=None, ack_insufficient_evidence: bool = False) -> dict:
    """记录一次人工审批（管理员动作；先污染复检 + 黄金集回归，退化不可覆盖）。

    返回：ok/approved/code/reason/approval/golden；幂等：同候选同内容摘要的重复
    审批直接返回既有证据，不重复写审计。
    """
    cid = str(candidate_id or "")
    if not hitl_enabled():
        return {"ok": True, "status": "disabled", "hitl": "disabled",
                "approved": False,
                "note": "RULEPROOF_EVOLUTION_HITL_GOLDEN=0：按旧 gate/shadow 行为，无需审批"}
    actor = hitl_actor_check(by, user)
    if not actor.get("ok"):
        return {"ok": False, "status": actor.get("status") or 403,
                "code": actor.get("code") or "forbidden",
                "error": actor.get("error") or "无权限审批",
                "actor": actor.get("actor") or ""}
    row, _before, _after = _candidate_payload(cid)
    if not row:
        return {"ok": False, "status": 404, "code": "not_found", "error": "候选不存在"}
    decision = str(row.get("decision") or "")
    if decision in ("blocked", "rejected"):
        return {"ok": False, "status": 409, "code": "candidate_blocked",
                "error": "被阻断候选不得审批上线", "decision": decision}
    if decision == "rolled_back":
        return {"ok": False, "status": 409, "code": "candidate_rolled_back",
                "error": "已回滚候选不得再审批上线", "decision": decision}
    hashes = candidate_content_sha(cid)
    current = approval_status(cid)
    if current.get("approved") and str(
            (current.get("approval") or {}).get("candidate_sha") or "") \
            == str(hashes.get("sha") or ""):
        return {"ok": True, "status": "approved", "idempotent": True,
                "approved": True, "actor": actor.get("actor"),
                "role": current.get("role") or actor.get("role"),
                "approval": current.get("approval") or {},
                "golden": current.get("golden") or {},
                "note": "同候选同内容摘要已有审批证据，幂等返回"}
    pollution = pollution_scan(cid, golden=golden)
    if not pollution.get("ok"):
        code = (pollution.get("issues") or [{}])[0].get("code") or "pollution"
        _audit_block_once(cid, HITL_ACTION_BLOCKED, {
            "code": "pollution_blocked", "stage": "approval",
            "reasons": [str(x.get("detail") or "")[:200]
                        for x in pollution.get("issues") or []][:10],
            "issues": pollution.get("issues") or [],
            "candidate_sha": hashes.get("sha") or "",
            "actor": actor.get("actor") or ""}, actor=actor.get("actor") or "")
        return {"ok": False, "status": 409, "code": code, "blocked": True,
                "error": "候选污染防护复检未通过，拒绝审批",
                "pollution": pollution}
    golden = golden_regression(cid, golden=golden)
    record_golden_evidence(cid, golden, actor=actor.get("actor") or "")
    payload = {"op": "approve", "candidate_id": cid,
               "candidate_sha": hashes.get("sha") or "",
               "candidate_type": hashes.get("candidate_type") or "",
               "rule_code": hashes.get("rule_code") or "",
               "action": hashes.get("action") or "",
               "actor": actor.get("actor") or "", "role": actor.get("role") or "",
               "note": str(note or "")[:500],
               "ack_insufficient_evidence": bool(ack_insufficient_evidence),
               "golden": {"verdict": golden.get("verdict") or "",
                          "kind": golden.get("kind") or "",
                          "set_id": (golden.get("set") or {}).get("set_id") or "",
                          "digest": golden.get("cases_digest")
                          or (golden.get("set") or {}).get("digest") or "",
                          "evaluated": golden.get("evaluated"),
                          "total": golden.get("total"),
                          "regressions": [x.get("id") for x in
                                          (golden.get("regressions") or [])][:20],
                          "reasons": (golden.get("reasons") or [])[:10],
                          "isolation_ok": golden.get("isolation_ok")},
               "pollution": {"ok": True, "checked": pollution.get("checked") or []}}
    verdict = str(golden.get("verdict") or "")
    if verdict == GOLDEN_VERDICT_DEGRADED:
        _audit_block_once(cid, HITL_ACTION_BLOCKED, {
            "code": "golden_degraded", "stage": "approval",
            "candidate_sha": hashes.get("sha") or "",
            "reasons": (golden.get("reasons") or [])[:10],
            "regressions": payload["golden"]["regressions"],
            "actor": actor.get("actor") or ""}, actor=actor.get("actor") or "")
        return {"ok": False, "status": 409, "code": "golden_degraded", "blocked": True,
                "error": "黄金集回归发现退化，阻断上线（审批不可覆盖退化）",
                "golden": golden}
    if verdict == GOLDEN_VERDICT_INSUFFICIENT and not ack_insufficient_evidence:
        _audit_block_once(cid, HITL_ACTION_BLOCKED, {
            "code": "golden_insufficient_evidence", "stage": "approval",
            "candidate_sha": hashes.get("sha") or "",
            "reasons": (golden.get("reasons") or [])[:10],
            "isolation_ok": golden.get("isolation_ok"),
            "actor": actor.get("actor") or ""}, actor=actor.get("actor") or "")
        return {"ok": False, "status": 409, "blocked": True,
                "code": "golden_insufficient_evidence", "needs_ack": True,
                "error": "黄金集证据不足（无黄金集/不可评估/作用域隔离），"
                         "不得默认放行；请管理员显式 ack_insufficient_evidence=True 承担风险",
                "golden": golden}
    if verdict not in (GOLDEN_VERDICT_PASS, GOLDEN_VERDICT_INSUFFICIENT):
        return {"ok": False, "status": 409, "blocked": True,
                "code": "golden_not_evaluated", "error": "黄金集未完成回归评估",
                "golden": golden}
    payload["approved_at"] = db.now()
    _guard_audit(HITL_ACTION_APPROVED, cid, payload, actor=actor.get("actor") or "")
    return {"ok": True, "approved": True, "status": "approved",
            "candidate_id": cid, "approval": payload, "golden": golden,
            "actor": actor.get("actor") or "", "role": actor.get("role") or "",
            "idempotent": False}


def record_rejection(candidate_id: str, by: str = "", user=None,
                     reason: str = "") -> dict:
    """记录一次人工拒绝（管理员动作）；后续上线必须重新审批。"""
    cid = str(candidate_id or "")
    if not hitl_enabled():
        return {"ok": True, "status": "disabled", "hitl": "disabled",
                "note": "RULEPROOF_EVOLUTION_HITL_GOLDEN=0：按旧行为，无需人工拒绝"}
    actor = hitl_actor_check(by, user)
    if not actor.get("ok"):
        return {"ok": False, "status": actor.get("status") or 403,
                "code": actor.get("code") or "forbidden",
                "error": actor.get("error") or "无权限拒绝"}
    row, _before, _after = _candidate_payload(cid)
    if not row:
        return {"ok": False, "status": 404, "code": "not_found", "error": "候选不存在"}
    hashes = candidate_content_sha(cid)
    payload = {"op": "reject", "candidate_id": cid,
               "candidate_sha": hashes.get("sha") or "",
               "actor": actor.get("actor") or "", "role": actor.get("role") or "",
               "reason": str(reason or "")[:500], "rejected_at": db.now()}
    _guard_audit(HITL_ACTION_REJECTED, cid, payload, actor=actor.get("actor") or "")
    return {"ok": True, "rejected": True, "status": "rejected",
            "candidate_id": cid, "rejection": payload,
            "actor": actor.get("actor") or ""}


def promotion_guard(candidate_id: str, rule_code: str = "") -> dict:
    """上线（shadow_finish promoted）闸口：审批证据 + 黄金集证据 + 防审批后篡改。"""
    cid = str(candidate_id or "")
    if not hitl_enabled():
        return {"ok": True, "status": "disabled",
                "note": "RULEPROOF_EVOLUTION_HITL_GOLDEN=0：按旧 gate/shadow 行为"}
    if not cid:
        return {"ok": False, "blocked": True, "code": "no_candidate",
                "reason": "影子记录未关联候选：无法完成人工审批/黄金集回归，"
                          "证据不足不得默认上线"}
    status = approval_status(cid)
    if status.get("approved"):
        return {"ok": True, "approval": status.get("approval") or {},
                "golden": status.get("golden") or {},
                "approver": status.get("approver") or "",
                "code": "approved"}
    code = str(status.get("status") or "")
    reason = str(status.get("reason") or "候选未通过 L131 上线闸口")
    return {"ok": False, "blocked": True, "code": code, "reason": reason,
            "approval": status.get("approval") or {},
            "golden": status.get("golden") or {},
            "candidate_sha": status.get("candidate_sha") or "",
            "rule_code": str(rule_code or "")}


def hitl_status(candidate_id: str, deep: bool = False) -> dict:
    """审批/黄金集只读状态（供候选时间线/报告/HTTP；权限由调用方判定）。

    ``deep=False``（默认，视图用）：只读审批证据与**已落库的**黄金集审计结果，
    不重跑回归（避免列表页逐候选跑判据）；``deep=True``（审批详情/报告用）：
    重新做污染复检 + 黄金集全量回归，返回当前真实结论。
    """
    status = approval_status(candidate_id)
    if deep:
        pollution = pollution_scan(candidate_id)
        golden = golden_regression(candidate_id)
    else:
        ev = _guard_events(candidate_id, (GOLDEN_ACTION,), limit=5)
        detail = (ev[0].get("detail") if ev else {}) or {}
        golden = {"verdict": detail.get("verdict") or "",
                  "kind": detail.get("kind") or "",
                  "evaluated": detail.get("evaluated"),
                  "total": detail.get("total"),
                  "regressions": detail.get("regressions") or [],
                  "reasons": detail.get("reasons") or [],
                  "isolation_ok": detail.get("isolation_ok"),
                  "set": detail.get("set") or {},
                  "evaluated_at": ev[0].get("at") if ev else "",
                  "cached": bool(ev)}
        pollution = {"ok": None, "issues": [], "checked": []}
    return {"ok": True, "candidate_id": str(candidate_id or ""),
            "policy": hitl_policy(), "status": status.get("status") or "",
            "approved": bool(status.get("approved")),
            "approver": status.get("approver") or "",
            "approved_at": status.get("approved_at") or "",
            "reason": status.get("reason") or "",
            "approval": status.get("approval") or {},
            "golden": {k: golden.get(k) for k in
                       ("verdict", "kind", "evaluated", "total", "regressions",
                        "reasons", "isolation_ok", "set", "evaluated_at")},
            "pollution": {"ok": pollution.get("ok"),
                          "issues": pollution.get("issues") or [],
                          "checked": pollution.get("checked") or []},
            "can_promote": bool(status.get("approved"))}


def guard_summary(limit: int = 100) -> dict:
    """L131 护栏运行摘要（策略 + 黄金集状态 + 最近审计事件计数）。"""
    try:
        limit = max(1, min(int(limit or 100), 500))
    except (TypeError, ValueError):
        limit = 100
    events = {action: [] for action in GUARD_ACTIONS}
    try:
        rows = R.audit_logs.list(
            "action IN (?,?,?,?,?,?)", GUARD_ACTIONS,
            order="created_at DESC", limit=limit)
    except Exception:  # noqa: BLE001
        rows = []
    for row in rows or []:
        action = str(row.get("action") or "")
        if action not in events:
            continue
        try:
            detail = json.loads(row.get("after_json") or "{}")
        except (TypeError, ValueError):
            detail = {}
        events[action].append({"at": row.get("created_at") or "",
                               "actor": row.get("actor") or "",
                               "object": row.get("object") or "",
                               "op": (detail or {}).get("op") or "",
                               "verdict": (detail or {}).get("verdict") or "",
                               "code": (detail or {}).get("code") or ""})
    gs = load_golden_set(with_cases=False)
    return {"ok": True, "policy": hitl_policy(),
            "golden_set": {"available": gs.get("available"),
                           "set_id": gs.get("set_id") or "",
                           "kind": gs.get("kind") or "",
                           "count": gs.get("count") or 0,
                           "digest": gs.get("digest") or "",
                           "isolation_ok": gs.get("isolation_ok"),
                           "reason": gs.get("reason") or ""},
            "events": {k: len(v) for k, v in events.items()},
            "recent": {k: v[:10] for k, v in events.items() if v},
            "audit_actions": list(GUARD_ACTIONS),
            "note": ("HITL 人工审批 + 黄金集全量回归 + 污染防护；"
                     "阻断/审批/回滚全部写只读审计（object=候选 id）")}
