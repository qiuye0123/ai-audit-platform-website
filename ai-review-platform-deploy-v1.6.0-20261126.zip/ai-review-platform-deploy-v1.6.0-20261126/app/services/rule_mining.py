"""规则挖掘候选：历史发现/复核/反馈 → 规则候选 + 质量评分 + 点位编码候选。

边界：
- 只产出候选/草稿，不自动落库为已发布规则；
- 候选质量来自历史审核记录（finding.status、decision、feedback、项目完成情况），
  质量只影响排序/建议与展示，最终仍必须人工确认；
- 未映射规则的点位编码候选由 rule.create_rule 自动生成，但只进
  rule_point_mapping(status='candidate')，必须人工审核，绝不写审核库。
"""
import json
import logging
import math
from datetime import datetime

from .. import db
from .. import repositories as R
from . import rule_form

# 历史审核结果 → 候选质量桶
_OUTCOME_BUCKETS = {
    "confirm": "confirmed", "confirmed": "confirmed",
    "false_positive": "false_positive",
    "need_evidence": "need_evidence",
    "manual": "manual", "supplement": "supplement",
    "ignored": "ignored", "ignore": "ignored",
    # 复核“退回重审”不是误报，质量上按中性处理，避免误伤候选
    "reject": "ignored", "rejected": "ignored", "deny": "ignored",
}
_QUALITY_BANDS = {"high": "高", "medium": "中", "low": "低"}


def _empty_outcomes() -> dict:
    return {k: 0 for k in ("confirmed", "false_positive", "manual",
                           "need_evidence", "supplement", "ignored", "pending")}


def _outcome_bucket(value) -> str:
    return _OUTCOME_BUCKETS.get(str(value or "").strip().lower(), "")


def _load_findings(limit: int) -> list:
    """finding 表没有 created_at 列；按 rowid 倒序，避免整段挖掘因排序字段缺失静默为空。"""
    attempts = [("rowid DESC", True), ("id DESC", True), ("", False)]
    for order, use_order in attempts:
        try:
            if use_order:
                return R.findings.list(order=order, limit=limit)
            return R.findings.list(limit=limit)
        except Exception:
            logging.getLogger(__name__).debug("rule mining findings order fallback", exc_info=True)
    return []


def _load_reviews() -> tuple:
    """读取最近的人工复核/反馈。每个 finding 只取最近一次结果，避免重复计数。"""
    fb_by_finding, fb_by_title, fb_rows = {}, {}, []
    try:
        fb_rows = R.feedback.list(order="created_at DESC", limit=5000)
    except Exception:
        fb_rows = []
    for row in fb_rows:
        fid = str(row.get("finding_id") or "")
        if fid:
            fb_by_finding.setdefault(fid, row)
        else:
            title = str(row.get("title") or "").strip()
            if title:
                fb_by_title.setdefault(title, []).append(row)
    dec_by_finding = {}
    try:
        for row in R.decisions.list(order="created_at DESC", limit=5000):
            fid = str(row.get("finding_id") or "")
            if fid:
                dec_by_finding.setdefault(fid, row)
    except Exception:
        logging.getLogger(__name__).debug("rule mining decisions skipped", exc_info=True)
    return fb_by_finding, fb_by_title, dec_by_finding


def _case_index() -> dict:
    """case_id → 状态 / 租户 / 空间；挖掘候选必须跟随当前租户上下文，不能跨租户。"""
    try:
        return {str(c.get("id") or ""): {
            "status": str(c.get("status") or ""),
            "tenant_id": str(c.get("tenant_id") or ""),
            "workspace_id": str(c.get("workspace_id") or ""),
        } for c in R.cases.list()}
    except Exception:
        return {}


def _new_group(title: str, rule_id: str = "") -> dict:
    return {"rule_id": rule_id, "title": title, "count": 0, "summaries": [],
            "cases": set(), "finding_ids": [], "rules": set(),
            "severities": {}, "statuses": {}, "case_statuses": {},
            "completed_cases": 0, "outcomes": _empty_outcomes(), "last_review_at": ""}


def collect_groups(limit: int = 1000, tenant_id: str = None,
                   workspace_id: str = None) -> dict:
    """节点 1/2：读取历史发现，按标题聚类，并汇总复核/反馈/项目完成情况。

    默认使用当前请求上下文做租户/空间隔离；脚本可显式传空字符串关闭过滤。
    """
    if tenant_id is None or workspace_id is None:
        try:
            from . import ctx as _ctx
            cur = _ctx.get_context() or {}
            if tenant_id is None:
                tenant_id = str(cur.get("tenant_id") or "")
            if workspace_id is None:
                workspace_id = str(cur.get("workspace_id") or "")
        except Exception:
            tenant_id = tenant_id or ""
            workspace_id = workspace_id or ""
    groups = {}
    findings = _load_findings(limit)
    fb_by_finding, _fb_by_title, dec_by_finding = _load_reviews()
    case_status = _case_index()
    for f in findings:
        title = str(f.get("title") or "").strip()
        if not title:
            continue
        _cid = str(f.get("case_id") or "")
        _case = case_status.get(_cid) or {}
        if tenant_id and str(_case.get("tenant_id") or "") != tenant_id:
            continue
        if workspace_id and str(_case.get("workspace_id") or "") != workspace_id:
            continue
        fid = str(f.get("id") or "")
        g = groups.get(title)
        if g is None:
            g = groups[title] = _new_group(title, str(f.get("rule_id") or ""))
        g["count"] += 1
        if not g["rule_id"]:
            g["rule_id"] = str(f.get("rule_id") or "")
        if f.get("summary"):
            if len(g["summaries"]) < 20:
                g["summaries"].append(str(f["summary"])[:200])
        if fid:
            g["finding_ids"].append(fid)
        if f.get("case_id"):
            cid = str(f["case_id"])
            g["cases"].add(cid)
            st = (case_status.get(cid) or {}).get("status", "")
            g["case_statuses"][st or "unknown"] = g["case_statuses"].get(st or "unknown", 0) + 1
        rule_code = str(f.get("rule_id") or "")
        if rule_code:
            g["rules"].add(rule_code)
        sev = str(f.get("severity") or "")
        g["severities"][sev] = g["severities"].get(sev, 0) + 1
        st = str(f.get("status") or "")
        g["statuses"][st or "pending"] = g["statuses"].get(st or "pending", 0) + 1
        fb = fb_by_finding.get(fid)
        dec = dec_by_finding.get(fid)
        if fb:
            outcome = fb.get("kind")
            reviewed_at = fb.get("created_at") or ""
        elif dec:
            outcome = dec.get("decision")
            reviewed_at = dec.get("created_at") or ""
        else:
            outcome = st
            reviewed_at = ""
        bucket = _outcome_bucket(outcome) or "pending"
        g["outcomes"][bucket] = g["outcomes"].get(bucket, 0) + 1
        if reviewed_at and str(reviewed_at) > str(g["last_review_at"]):
            g["last_review_at"] = str(reviewed_at)
    # 标题级反馈（无 finding_id，例如人工沉淀时直接写的反馈）也并入候选
    for title, rows in (_fb_by_title or {}).items():
        g = groups.get(title)
        if not g:
            continue
        for fb in rows:
            bucket = _outcome_bucket(fb.get("kind"))
            if bucket and bucket != "pending":
                g["outcomes"][bucket] = g["outcomes"].get(bucket, 0) + 1
            when = fb.get("created_at") or ""
            if when and str(when) > str(g["last_review_at"]):
                g["last_review_at"] = str(when)
    for g in groups.values():
        g["completed_cases"] = sum(1 for cid in g["cases"]
                                   if (case_status.get(cid) or {}).get("status") == "completed")
        g["decided"] = sum(g["outcomes"].get(k, 0) for k in
                           ("confirmed", "false_positive", "manual", "need_evidence"))
    return groups


def _recency(value: str) -> float:
    """最近一次人工复核的新鲜度：180 天内 1.0，1 年内 0.6，更早 0.3，未知 0.5。"""
    try:
        if not value:
            return 0.5
        dt = datetime.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")
        days = max(0, (datetime.now() - dt).days)
        if days <= 180:
            return 1.0
        if days <= 365:
            return 0.6
        return 0.3
    except Exception:
        return 0.5


def candidate_quality(group: dict) -> dict:
    """历史审核记录 → 候选质量分（0~1）。质量只做建议/排序，不代替人工确认。"""
    g = group or {}
    out = g.get("outcomes") or {}
    confirmed = int(out.get("confirmed") or 0)
    false_positive = int(out.get("false_positive") or 0)
    manual = int(out.get("manual") or 0)
    need_evidence = int(out.get("need_evidence") or 0)
    supplement = int(out.get("supplement") or 0)
    ignored = int(out.get("ignored") or 0)
    pending = int(out.get("pending") or 0)
    n = int(g.get("count") or 0)
    cases = g.get("cases") or set()
    completed = int(g.get("completed_cases") or 0)
    case_count = len(cases)
    open_cases = max(0, case_count - completed)
    rule_count = len(g.get("rules") or [])
    denom = confirmed + manual + false_positive
    precision = round((confirmed + manual) / denom, 3) if denom else None
    volume = min(1.0, math.log1p(max(0, n)) / math.log1p(8)) if n > 0 else 0.0
    coverage = min(1.0, (completed + 0.5 * open_cases) / 3.0) if case_count else 0.0
    agreement = precision if precision is not None else 0.5
    diversity = min(1.0, rule_count / 2.0)
    recency = _recency(g.get("last_review_at") or "")
    score = (0.32 * volume + 0.28 * coverage + 0.28 * agreement +
             0.07 * diversity + 0.05 * recency)
    reasons, blockers = [], []
    if case_count:
        reasons.append(f"历史发现 {n} 条，覆盖 {case_count} 个项目（完成 {completed} 个）")
    else:
        reasons.append(f"历史发现 {n} 条，未关联项目")
    if denom:
        reasons.append(f"人工确认 {confirmed} 次、人工新增 {manual} 次、误报 {false_positive} 次")
    else:
        reasons.append("尚无人工复核/反馈样本，质量按先验估计")
    if manual:
        reasons.append(f"人工新增 {manual} 次，说明现有规则覆盖不足")
    if need_evidence or supplement:
        reasons.append(f"补证信号 {need_evidence + supplement} 次，证据口径仍需细化")
    if n < 3:
        score = min(score, 0.55)
        reasons.append("样本量不足 3 条，建议继续观察")
    if denom == 0:
        score = min(score, 0.60)
    if false_positive and precision is not None and precision < 0.5:
        score = min(score, 0.45)
        blockers.append("历史误报占比偏高，建议先补判据/收窄范围")
    if false_positive >= 2 and (confirmed + manual) == 0:
        score = min(score, 0.30)
        blockers.append("仅有误报、没有确认样本，不建议沉淀")
    if completed == 0 and case_count:
        reasons.append("项目尚未完成复核，历史结论仅作参考")
    score = round(max(0.0, min(1.0, score)), 3)
    band = "high" if score >= 0.70 else "medium" if score >= 0.48 else "low"
    reliable = n >= 3 and denom >= 1
    if band == "high" and not reliable:
        band = "medium"
    eligible = band in ("high", "medium") and reliable and not blockers
    return {"score": score, "band": band, "label": _QUALITY_BANDS.get(band, band),
            "eligible": eligible, "reliable": reliable,
            "sample_size": n, "case_count": case_count, "completed_cases": completed,
            "rule_count": rule_count, "confirmed": confirmed,
            "false_positive": false_positive, "manual": manual,
            "need_evidence": need_evidence, "supplement": supplement,
            "ignored": ignored, "pending": pending, "decided": denom,
            "precision": precision,
            "reasons": reasons, "blockers": blockers,
            "requires_human_confirm": True, "auto_publish": False}



def groups_from_text(text: str, min_count: int = 2) -> dict:
    """历史审核材料文件模式：按行/分句聚类。

    只用于新建规则时显式上传的历史审核记录，不读库、不跨租户。
    重复出现的记录才进入候选；单条记录不强行生成规则。
    """
    import re as _re
    groups = {}
    for raw in _re.split(r"[\r\n]+", str(text or "")):
        line = _re.sub(r"^[\s\-*•\d.、)）]+", "", str(raw or "")).strip()
        line = _re.sub(r"\s+", " ", line)
        if len(line) < 6:
            continue
        key = line[:160]
        g = groups.get(key)
        if g is None:
            g = groups[key] = _new_group(key, "")
            g["text_mode"] = True
        g["count"] += 1
        if len(g["summaries"]) < 20:
            g["summaries"].append(line[:200])
    return {k: v for k, v in groups.items() if int(v.get("count") or 0) >= max(1, int(min_count or 1))}

def build_candidates(groups: dict, limit: int = 20, min_count: int = 2) -> list:
    """节点 3/4：聚类 → 质量评分 → 候选；不落库、不发布。"""
    scored = []
    for g in (groups or {}).values():
        if int(g.get("count") or 0) < min_count:
            continue
        scored.append((candidate_quality(g), g))
    scored.sort(key=lambda x: (-x[0]["score"], -int(x[1].get("count") or 0)))
    items = []
    for quality, g in scored:
        text = f"{g['title']} {' '.join((g.get('summaries') or [])[:6])}"
        try:
            form = rule_form.decide(text, {})
        except Exception:
            form = {"form": "single", "confidence": 0.5, "reasons": []}
        form_label = "决策表组合规则" if form.get("form") == "decision_table" else "单条参数规则"
        if quality["eligible"]:
            suggestion = f"建议沉淀为{form_label}（质量{quality['label']}，需人工确认）"
        else:
            _why = "；".join(quality.get("blockers") or quality.get("reasons") or [])
            suggestion = f"暂不建议直接沉淀为{form_label}：{_why[:120]}"
        items.append({
            "rule_id": g.get("rule_id") or "", "title": g["title"], "count": g["count"],
            "case_count": len(g.get("cases") or set()),
            "rule_count": len(g.get("rules") or set()),
            "summary": ((g.get("summaries") or [""])[0]),
            "form": form.get("form", "single"),
            "form_reason": "；".join(form.get("reasons") or []),
            "form_confidence": form.get("confidence"),
            "quality": quality,
            "quality_score": quality["score"], "quality_band": quality["band"],
            "quality_label": quality["label"], "quality_reasons": quality["reasons"],
            "eligible": quality["eligible"], "requires_human_confirm": True,
            "confirmed": quality["confirmed"], "false_positive": quality["false_positive"],
            "manual": quality["manual"], "sample_size": quality["sample_size"],
            "history_backed": quality["sample_size"] > 0,
            "auto_publish": False,
            "suggestion": suggestion,
        })
        if len(items) >= limit:
            break
    return items


def _quality_for_title(title: str) -> dict:
    try:
        groups = collect_groups()
        for item in build_candidates(groups, limit=500, min_count=2):
            if str(item.get("title") or "") == str(title or ""):
                return {"quality": item.get("quality") or {},
                        "history": {k: item.get(k) for k in
                                    ("count", "case_count", "rule_count", "confirmed",
                                     "false_positive", "manual", "sample_size",
                                     "quality_score", "quality_band", "history_backed")}}
    except Exception:
        logging.getLogger(__name__).debug("rule mining quality lookup skipped", exc_info=True)
    return {"quality": {}, "history": {}}


def _quality_summary(items: list) -> dict:
    counts = {"high": 0, "medium": 0, "low": 0}
    eligible = 0
    for it in items or []:
        band = (it.get("quality") or {}).get("band") or "low"
        counts[band] = counts.get(band, 0) + 1
        if it.get("eligible"):
            eligible += 1
    return {"total": len(items or []), "high": counts["high"],
            "medium": counts["medium"], "low": counts["low"],
            "eligible": eligible, "requires_human_confirm": True,
            "auto_publish": False}


def mine(limit: int = 20, min_count: int = 2) -> dict:
    limit = max(1, min(100, int(limit or 20)))
    min_count = max(2, min(20, int(min_count or 2)))
    groups = collect_groups()
    items = build_candidates(groups, limit=limit, min_count=min_count)
    # 同一候选已生成草稿时回填 rule_id/点位映射/点位候选，避免界面重复“生成草稿”
    try:
        _drafts = [r for r in R.rules.list("source=?", ("rule_mining",))]
        _by_ref = {}
        for _r in _drafts:
            try:
                _sc = json.loads(_r.get("scope_json") or "{}")
            except Exception:
                _sc = {}
            _ref = str(_sc.get("source_ref") or "")
            if _ref:
                _by_ref[_ref] = (_r, _sc)
        for _it in items:
            _ref = f"rule:{_it.get('rule_id') or ''}:{_it.get('title') or ''}"
            _draft, _sc = _by_ref.get(_ref, ({}, {}))
            _it["draft_rule_id"] = (_draft or {}).get("id") or ""
            _mapping = (_sc or {}).get("point_mapping") or {}
            _it["point_id"] = _mapping.get("point_id") or ""
            _it["point_candidate"] = _mapping.get("candidate") or None
            if _it["draft_rule_id"]:
                _it["draft_status"] = (_draft or {}).get("status") or ""
    except Exception:
        logging.getLogger(__name__).debug("rule mining draft lookup skipped", exc_info=True)
    qs = _quality_summary(items)
    return {"ok": True, "items": items, "count": len(items),
            "groups": len(groups), "quality": qs,
            "note": "只产出候选；质量来自历史发现/复核/反馈，需人工确认后创建草稿；"
                    "不会自动发布，候选点位也需人工审核"}


def create_draft(title: str, summary: str = "", form: str = "single", by: str = "",
                 rule_code: str = "", category: str = "") -> dict:
    """从挖掘候选生成一条可审批的规则草稿；不自动发布。同一候选幂等。

    与 12→5 全链一致：类别由历史候选文本收敛到规范码（不再一律 completeness）；
    历史质量随 scope 保存；未映射时自动生成待人工审核的点位编码候选。
    """
    from . import rule as _rule
    title = (title or "").strip()
    if not title:
        return {"error": "候选缺少标题"}
    source_ref = f"rule:{rule_code or ''}:{title}"
    quality_info = _quality_for_title(title)
    quality = quality_info.get("quality") or {}
    history = quality_info.get("history") or {}
    # 同一候选重复点击：返回已存在的草稿，不重复落库
    try:
        for _r in R.rules.list("source=?", ("rule_mining",)):
            try:
                _sc = json.loads(_r.get("scope_json") or "{}")
            except Exception:
                _sc = {}
            if str(_sc.get("source_ref") or "") == source_ref:
                _mapping = _sc.get("point_mapping") or {}
                return {"ok": True, "rule_id": _r.get("id"), "existing": True,
                        "mapping": _mapping,
                        "point_candidate": _mapping.get("candidate") or None,
                        "quality": _sc.get("mining_quality") or {},
                        "auto_published": False, "requires_human_confirm": True,
                        "form": form or "single",
                        "message": "该候选已有规则草稿，未重复创建；仍不会自动发布"}
    except Exception:
        logging.getLogger(__name__).debug("rule mining dedupe lookup skipped", exc_info=True)
    criterion = (summary or title).strip()[:500]
    # 类别：显式入参优先；否则按候选文本走 12→5 唯一收敛（空类别仍可人工后续补）
    _category = str(category or "").strip()
    if not _category:
        try:
            _conv = _rule.converge_rulegen("", "", {"criterion": f"{title} {summary}"})
            _category = _conv.get("category") or ""
        except Exception:
            _category = ""
    if not _category:
        _category = "completeness"
    _rclass = "R3"
    try:
        from ..engine import rule_schema as _rs
        _rclass = next((t.get("rclass") for t in _rs.TEMPLATES if t.get("code") == _category), "R3")
    except Exception:
        _rclass = "R3"
    slots = {"criterion": criterion, "description": summary or title,
             "source": "rule_mining", "source_ref": source_ref, "rule_code": rule_code,
             # 挖掘草稿没有用户声明的作用域：标记 scope_required，发布必须显式补范围
             "_scope_missing": True}
    try:
        from . import ctx as _ctx
        _cur = _ctx.get_context() or {}
    except Exception:
        _cur = {}
    scope = {"criterion": criterion, "description": summary or title,
             "source_ref": source_ref, "rule_code": rule_code,
             "form": form or "single",
             "form_reason": "规则挖掘候选，需人工确认判据",
             "mining_source": {"title": title, "rule_code": rule_code,
                               "created_by": by or "", **history},
             "mining_quality": quality}
    try:
        out = _rule.create_rule(code=f"RM-{db.new_id('x')[:8].upper()}",
                                name=title[:80], category=_category, rclass=_rclass,
                                slots=slots, source="rule_mining", scope=scope)
    except Exception as e:
        return {"error": f"{type(e).__name__}: {str(e)[:160]}"}
    _r = R.rules.get(out.get("rule_id") or "") or {}
    try:
        _sc = json.loads(_r.get("scope_json") or "{}")
    except Exception:
        _sc = {}
    _mapping = out.get("mapping") or _sc.get("point_mapping") or {}
    _ir = _sc.get("ir") or {}
    _scope_missing = bool(_sc.get("scope_missing")) or _sc.get("scope_required") is True
    if _ir.get("publishable") and _scope_missing:
        message = "已生成草稿；未声明适用范围，发布会被阻断，请补充作用域并人工确认"
    elif _ir.get("publishable"):
        message = "已生成规则草稿；需补判据/证据并提交审批，不会自动发布"
    else:
        message = "已生成草稿；该候选缺证据/适用范围，暂不能提交或发布"
    return {"ok": True, "rule_id": out.get("rule_id"), "mapping": _mapping,
            "point_candidate": _mapping.get("candidate") or out.get("point_candidate") or None,
            "ir": _ir, "category": out.get("category") or _r.get("category") or "",
            "nature": out.get("nature") or _sc.get("nature") or "",
            "rclass": out.get("rclass") or _r.get("rclass") or "",
            "severity": out.get("severity") or _sc.get("severity") or "",
            "quality": quality, "mining_history": history,
            "publishable": bool(_ir.get("publishable")),
            "scope_required": bool(_sc.get("scope_required")),
            "scope_missing": _scope_missing,
            "auto_published": False, "requires_human_confirm": True,
            "form": form or "single", "message": message}
