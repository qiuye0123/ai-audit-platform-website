"""工作空间：建/列/切换/归档 + 成员关系。所有查询按租户隔离。"""
import logging

from .. import db
from .. import repositories as R
from . import permissions as P

LOG = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# T-105 文件类型适用性（新建空间时判断能否共用同一批规则库）
# ---------------------------------------------------------------------------
# “其他（未列入标准类型）”是新建空间文件类型选择框的最后一项：
# - 前端原样提交该值，后端原样落库（不伪造专用规则）；
# - 路由按通用审核类型（general）处理，审核时需要人工确认；
# - 它不构成“跨业务域混用”，不能因为选了它而把空间判成不适用。
OTHER_DOC_TYPE = "其他（未列入标准类型）"
# 跨业务域类型“默认审核类型重叠足够”的判定阈值（Jaccard）。
DOC_TYPE_OVERLAP_MIN = 0.5
# 业务域（与 app/api/point_routes.py 共用同一份定义，避免前后端口径分叉）。
DOMAIN_LABELS = {
    "food": "食品/工艺域",
    "contract": "合同/采购域",
    "application": "申报/资质域",
    "general": "通用/未归类",
}
_DOMAIN_KEYWORDS = (
    ("food", ("食品", "工艺", "配方", "检验", "标签", "生产")),
    ("contract", ("合同", "招标", "投标", "报价", "采购", "销售")),
    ("application", ("申报", "许可", "资质", "执照", "审批", "备案")),
)


def base_type_of(name: str) -> str:
    """文件类型 → 业务域（food/contract/application/general）。

    口径沿用平台既有点位路由的命名启发式；域名本身不进入规则判定，只做空间适用性提示。
    """
    n = str(name or "")
    for base, keywords in _DOMAIN_KEYWORDS:
        if any(k in n for k in keywords):
            return base
    return "general"


def document_type_profiles() -> dict:
    """平台标准文件类型 → 业务域 + 默认审核类型（唯一数据源：审核点库）。

    返回 ``{"types": {name: {...}}, "aliases": {alias: name}, "other": {...}}``。
    审核点库不可用时 types 为空（调用方按“无法判断”处理，不伪造）。
    """
    out = {"types": {}, "aliases": {},
           "other": {"name": OTHER_DOC_TYPE, "base_type": "general",
                     "default_audit_types": [], "aliases": [], "other": True}}
    try:
        from . import auditpoints as _ap
        lib = _ap.load()
    except Exception:
        LOG.warning("document_type_profiles: 审核点库不可用，类型适用性无法判断", exc_info=True)
        return out
    for d in (getattr(lib, "document_types", None) or []):
        if not isinstance(d, dict):
            continue
        name = str(d.get("name") or d.get("id") or "").strip()
        if not name or name == OTHER_DOC_TYPE:
            continue
        aliases = [str(a).strip() for a in (d.get("aliases") or []) if str(a).strip()]
        item = {
            "name": name,
            "id": str(d.get("id") or ""),
            "base_type": base_type_of(name),
            "default_audit_types": [str(x).strip() for x in (d.get("default_audit_types") or [])
                                    if str(x).strip()],
            "aliases": aliases,
            "other": False,
        }
        out["types"][name] = item
        candidates = aliases + ([str(d.get("id") or "").strip()] if d.get("id") else [])
        for a in candidates:
            if a:
                out["aliases"].setdefault(a, name)
    return out


def _resolve_profile(profiles: dict, raw: str) -> dict:
    """按名称/别名解析文件类型档案；“其他”返回通用档案；未知返回空档案。"""
    name = str(raw or "").strip()
    if not name:
        return {}
    if name == OTHER_DOC_TYPE:
        return dict(profiles["other"])
    item = profiles["types"].get(name)
    if item:
        return item
    canonical = profiles["aliases"].get(name, "")
    return profiles["types"].get(canonical, {})


def judge_doc_types(doc_types) -> dict:
    """判断一组主文件类型能否共用同一批规则库（新建空间前置判断）。

    用户口径（2026-11-18）：判断依据 = 业务域（base_type）+ 默认审核类型重叠。
    - 同一业务域 → 允许；
    - 跨业务域时，按域聚合 default_audit_types，Jaccard 重叠 >= DOC_TYPE_OVERLAP_MIN → 允许；
    - 不够重叠 → 不允许，返回原因 + 建议拆分（按业务域分组）；
    - “其他（未列入标准类型）”按通用类型处理，不伪造专用规则，也不作为跨域冲突来源。
    """
    selected = [str(x).strip() for x in (doc_types or []) if str(x).strip()]
    profiles = document_type_profiles()
    unknown = []
    items = []
    for raw in selected:
        prof = _resolve_profile(profiles, raw)
        if not prof:
            unknown.append(raw)
            continue
        items.append({"type": raw, "canonical": prof.get("name") or raw,
                      "base_type": prof.get("base_type") or "general",
                      "default_audit_types": list(prof.get("default_audit_types") or []),
                      "other": bool(prof.get("other"))})
    other_selected = any(x["other"] for x in items)
    # 按业务域聚合默认审核类型集合（general 不参与跨域冲突判断）
    domain_types = {}
    for it in items:
        bt = it["base_type"] if it["base_type"] != "general" else "general"
        domain_types.setdefault(bt, set()).update(it["default_audit_types"])
    specific_domains = sorted(d for d in domain_types if d != "general")
    result = {
        "ok": True,
        "selected": selected,
        "other_selected": other_selected,
        "unknown": unknown,
        "overlap_min": DOC_TYPE_OVERLAP_MIN,
        "domains": [{"key": d, "label": DOMAIN_LABELS.get(d, d),
                     "types": [x["type"] for x in items if x["base_type"] == d]}
                    for d in specific_domains],
        "by_domain": {d: sorted(v) for d, v in domain_types.items()},
        "domain_count": len(specific_domains),
        "compatible": True,
        "overlap": None,
        "reason": "",
        "suggestion": "",
        "groups": [],
    }
    if not items:
        result.update({"compatible": False,
                       "reason": "请选择 1~5 个主文件类型后再判断是否适合同一批规则库",
                       "suggestion": ""})
        return result
    if other_selected and not specific_domains:
        result.update({
            "compatible": True,
            "reason": "所选类型为通用/未归类（含“其他（未列入标准类型）”）：按通用规则执行，"
                      "不会伪造专用规则；审核时需人工确认。",
            "suggestion": "",
        })
        return result
    if len(specific_domains) <= 1:
        label = DOMAIN_LABELS.get(specific_domains[0], "同一业务域") if specific_domains else "通用/未归类"
        if specific_domains:
            result.update({"compatible": True,
                           "reason": f"所选文件类型同属「{label}」，适合共用同一批规则库。",
                           "suggestion": ""})
        else:
            result.update({"compatible": True,
                           "reason": "所选类型均为通用/未归类，适合共用通用规则库。",
                           "suggestion": ""})
        return result
    # 跨业务域：逐对计算域级默认审核类型 Jaccard 重叠
    pairs = []
    for i, a in enumerate(specific_domains):
        for b in specific_domains[i + 1:]:
            A, B = domain_types.get(a) or set(), domain_types.get(b) or set()
            score = (len(A & B) / len(A | B)) if (A | B) else 1.0
            pairs.append((a, b, round(score, 4), sorted(A & B)))
    min_pair = min(pairs, key=lambda x: x[2]) if pairs else ("", "", 0.0, [])
    result["overlap"] = min_pair[2]
    result["pairs"] = [{"a": a, "b": b, "overlap": s, "shared": shared}
                       for a, b, s, shared in pairs]
    if min_pair[2] >= DOC_TYPE_OVERLAP_MIN:
        result.update({
            "compatible": True,
            "reason": f"所选文件类型跨 {len(specific_domains)} 个业务域，但默认审核类型重叠足够"
                      f"（最低 {min_pair[2]:.2f} ≥ {DOC_TYPE_OVERLAP_MIN:.2f}），"
                      f"适合共用同一批规则库。",
            "suggestion": "",
        })
        return result
    # 不适用：按业务域给出建议拆分（通用类型可并入任一分组）
    groups = []
    for d in specific_domains:
        groups.append({"key": d, "label": DOMAIN_LABELS.get(d, d),
                       "types": [x["type"] for x in items if x["base_type"] == d]})
    general_types = [x["type"] for x in items if x["base_type"] == "general"]
    if general_types:
        groups.append({"key": "general", "label": DOMAIN_LABELS["general"], "types": general_types})
    split_txt = "；".join(
        f"{g['label']}：{'、'.join(g['types'])}" for g in groups if g["types"])
    domain_labels = "、".join(DOMAIN_LABELS.get(d, d) for d in specific_domains)
    result.update({
        "compatible": False,
        "groups": groups,
        "reason": f"所选 {len(selected)} 个文件类型跨 {len(specific_domains)} 个业务域（{domain_labels}），"
                  f"且默认审核类型重叠不足（最低 {min_pair[2]:.2f} < {DOC_TYPE_OVERLAP_MIN:.2f}）。"
                  f"同一批规则库无法同时覆盖这些类型，直接创建会让部分类型的规则/点位失效。",
        "suggestion": f"建议拆分为 {len(groups)} 个空间分别创建：{split_txt}。"
                      f"同一空间只放同一业务域的文件类型；如确需混用，请先补齐覆盖两类业务的同一批规则库/点位。",
    })
    return result


def _c():
    return db.connect()


def setup_required(ws_id: str) -> bool:
    """通用空间是否还没被客户编辑配置；未配置不可建项目/审核。"""
    return bool((get_settings(ws_id) or {}).get("setup_required"))


def ready(ws_id: str) -> bool:
    return not setup_required(ws_id)


def rename(ws_id: str, name: str) -> dict:
    name = (name or "").strip()
    if len(name) < 2:
        return {"ok": False, "reason": "空间名称至少 2 个字"}
    c = _c()
    try:
        row = c.execute("SELECT tenant_id FROM workspace WHERE id=? AND status='active'", (ws_id,)).fetchone()
        if not row:
            return {"ok": False, "reason": "空间不存在或已归档"}
        dup = c.execute("SELECT id FROM workspace WHERE tenant_id=? AND name=? AND status='active' AND id<>?",
                        (row["tenant_id"], name, ws_id)).fetchone()
        if dup:
            return {"ok": False, "reason": "该租户下已有同名空间"}
        c.execute("UPDATE workspace SET name=? WHERE id=?", (name, ws_id)); c.commit()
        return {"ok": True, "name": name}
    finally:
        c.close()


def create(name: str, user_id: str, tenant_id: str = "t-default", settings: dict = None) -> dict:
    name = (name or "").strip()
    # 审核员只能选择分配给自己的工作空间，不能新建
    try:
        from . import account as _acc
        _roles = set(_acc.roles_of(user_id))
    except Exception:
        _roles = set()
    if not (_roles & {"admin", "super_admin"}):
        return {"ok": False, "reason": "审核员不能新建空间，只能选择已分配空间", "code": "forbidden"}
    if len(name) < 2:
        return {"ok": False, "reason": "空间名称至少 2 个字"}
    # 可见性 / 文件类型（通用字段，不绑定行业）
    _st = dict(settings or {})
    # 全局调整：空间统一对同租户所有人可见，不再创建私有/指定成员空间
    vis = "tenant"
    _st["members"] = []
    dts = [str(x).strip() for x in (_st.get("doc_types") or []) if str(x).strip()]
    # 工作空间创建时必须声明文件类型范围，后续项目的类型只能从中选择
    if not (1 <= len(dts) <= 5):
        return {"ok": False, "reason": "请选择 1~5 个主文件类型"}
    if dts:
        # 校验必须来自标准文件类型库（名称或别名），避免自由文本导致路由失效；
        # “其他（未列入标准类型）”是允许的兜底类型，不要求出现在标准类型库里。
        try:
            _profiles = document_type_profiles()
            _valid = set(_profiles["types"].keys()) | set(_profiles["aliases"].keys())
            _bad = [x for x in dts if x != OTHER_DOC_TYPE and x not in _valid]
            if _bad and _valid:
                return {"ok": False,
                        "reason": f"未知文件类型：{'、'.join(_bad[:3])}（请从标准类型库选择，"
                                  f"未列入的类型请选「{OTHER_DOC_TYPE}」）"}
        except Exception:
            LOG.debug("doctype validation skipped", exc_info=True)
        # T-105：判断所选类型能否共用同一批规则库（业务域 + 默认审核类型重叠）；
        # 不适用时服务端同样拒绝创建（与前端禁用按钮同源，防止只绕前端）。
        try:
            _judge = judge_doc_types(dts)
            if _judge.get("ok") and _judge.get("selected") and not _judge.get("compatible"):
                return {"ok": False, "code": "doc_types_incompatible",
                        "reason": _judge.get("reason") or "所选文件类型不适合同一批规则库",
                        "suggestion": _judge.get("suggestion") or "",
                        "judge": _judge}
        except Exception:
            LOG.warning("doc_types compatibility judge skipped", exc_info=True)
    _st["visibility"] = vis
    _st["doc_types"] = dts
    _st.setdefault("setup_required", False)
    # 新建空间默认走“点位模板先确认”；旧空间缺省仍 false，避免静默改变历史行为
    _st.setdefault("point_confirm_required", True)
    settings = _st
    c = _c()
    try:
        dup = c.execute("SELECT id FROM workspace WHERE tenant_id=? AND name=? AND status='active'",
                        (tenant_id, name)).fetchone()
        if dup:
            return {"ok": False, "reason": "该租户下已有同名空间"}
        wid = db.new_id("ws")
        import json as _j
        c.execute("INSERT INTO workspace(id,tenant_id,name,status,created_by,created_at,settings_json) "
                  "VALUES(?,?,?,'active',?,?,?)",
                  (wid, tenant_id, name, user_id, db.now(), _j.dumps(settings or {}, ensure_ascii=False)))
        c.execute("INSERT OR IGNORE INTO user_workspace(user_id, workspace_id) VALUES(?,?)", (user_id, wid))
        # L91（P1，L89 CLI-3）：创建工作空间必须与业务写**同一事务**落审计（HTTP 与 CLI
        # 共用本函数 → 两个入口同时补齐）。actor=创建人；tenant/workspace 显式传本空间，
        # 不依赖请求上下文（CLI 无 per-request ctx 时也不会写错归属）。审计失败整体回滚，
        # 不允许“空间建了但审计丢了”。
        try:
            from . import audit as _audit
            _audit.log_in_tx(
                c, actor=str(user_id or "system"), action="workspace.created",
                object_=wid,
                after=_j.dumps({"id": wid, "name": name, "tenant_id": tenant_id,
                                "doc_types": dts, "visibility": vis},
                               ensure_ascii=False),
                tenant_id=str(tenant_id or ""), workspace_id=wid)
        except Exception:
            c.rollback()
            raise
        c.commit()
        return {"ok": True, "id": wid, "name": name}
    finally:
        c.close()


def list_for(user_id: str, tenant_id: str = "t-default") -> list:
    c = _c()
    try:
        rows = c.execute(
            "SELECT w.*, u.name AS creator_name, "
            "(SELECT 1 FROM user_workspace uw WHERE uw.workspace_id=w.id AND uw.user_id=?) AS joined "
            "FROM workspace w LEFT JOIN user u ON u.id=w.created_by "
            "WHERE w.tenant_id=? AND w.status='active' ORDER BY w.created_at DESC", (user_id, tenant_id)).fetchall()
        cur = c.execute("SELECT current_workspace_id FROM user WHERE id=?", (user_id,)).fetchone()
        cur_id = cur[0] if cur else ""
        # 可见性过滤：自己创建 / 全员可见 / 指定成员 / 已加入
        _rows = []
        for r in rows:
            try:
                _st = __import__("json").loads(r["settings_json"] or "{}")
            except Exception:
                _st = {}
            vis = str(_st.get("visibility") or "tenant")
            members = [str(x) for x in (_st.get("members") or [])]
            uid = user_id
            _is_admin = False
            try:
                from . import account as _acc
                _is_admin = bool(set(_acc.roles_of(uid)) & {"admin", "super_admin"})
            except Exception:
                _is_admin = False
            # 全局调整：同租户所有空间对所有人可见；仍保留租户隔离
            _rows.append({"id": r["id"], "name": r["name"], "joined": bool(r["joined"]),
                          "current": r["id"] == cur_id,
                          "visibility": "tenant", "members": [],
                          "doc_types": _st.get("doc_types") or [],
                          "setup_required": bool(_st.get("setup_required")),
                          "usable": not bool(_st.get("setup_required")),
                          "created_by": r["created_by"] or "",
                          "creator_name": r["creator_name"] or r["created_by"] or "—",
                          "created_at": r["created_at"] or ""})
        return _rows
    finally:
        c.close()


def join(user_id: str, ws_id: str) -> dict:
    c = _c()
    try:
        if not c.execute("SELECT 1 FROM workspace WHERE id=? AND status='active'", (ws_id,)).fetchone():
            return {"ok": False, "reason": "空间不存在或已归档"}
        c.execute("INSERT OR IGNORE INTO user_workspace(user_id, workspace_id) VALUES(?,?)", (user_id, ws_id))
        c.commit()
        return {"ok": True}
    finally:
        c.close()


def archive(ws_id: str, user_id: str) -> dict:
    if not P.has(user_id, "ws.manage"):
        return {"ok": False, "reason": "无权归档"}
    if ws_id == "ws-default":
        return {"ok": False, "reason": "通用空间不可归档"}
    c = _c()
    try:
        row = c.execute("SELECT tenant_id FROM workspace WHERE id=? AND status='active'", (ws_id,)).fetchone()
        if not row:
            return {"ok": False, "reason": "空间不存在或已归档"}
        cnt = c.execute("SELECT COUNT(*) FROM workspace WHERE tenant_id=? AND status='active'", (row["tenant_id"],)).fetchone()[0]
        if cnt <= 1:
            return {"ok": False, "reason": "至少保留一个工作空间，不能全部归档"}
        c.execute("UPDATE workspace SET status='archived' WHERE id=?", (ws_id,)); c.commit()
        return {"ok": True, "archived": ws_id}
    finally:
        c.close()


def switch(user_id: str, ws_id: str) -> dict:
    c = _c()
    try:
        row = c.execute("SELECT created_by, settings_json, tenant_id FROM workspace WHERE id=? AND status='active'", (ws_id,)).fetchone()
        if not row:
            return {"ok": False, "reason": "空间不存在或已归档"}
        try:
            _st0 = __import__("json").loads(row["settings_json"] or "{}")
        except Exception:
            _st0 = {}
        _vis = str(_st0.get("visibility") or "tenant")
        _mem = [str(x) for x in (_st0.get("members") or [])]
        # 跨租户和私有空间都必须在服务端拒绝；不能只看 ws.manage 权限
        try:
            _urow = c.execute("SELECT tenant_id FROM user WHERE id=?", (user_id,)).fetchone()
            _uroles = {r[0] for r in c.execute(
                "SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?",
                (user_id,)).fetchall()}
        except Exception:
            _urow, _uroles = None, set()
        if _urow and row["tenant_id"] and _urow[0] != row["tenant_id"]:
            return {"ok": False, "reason": "不能切换到其他租户的空间", "code": "forbidden"}
        # 全局调整：同租户内所有空间可切换；私有/成员白名单限制已取消
        joined = c.execute("SELECT 1 FROM user_workspace WHERE user_id=? AND workspace_id=?",
                           (user_id, ws_id)).fetchone()
        if not joined:
            c.execute("INSERT OR IGNORE INTO user_workspace(user_id, workspace_id) VALUES(?,?)", (user_id, ws_id))
        c.execute("UPDATE user SET current_workspace_id=? WHERE id=?", (ws_id, user_id))
        c.commit()
        return {"ok": True, "current": ws_id}
    finally:
        c.close()


def get(ws_id: str) -> dict:
    c = _c()
    try:
        r = c.execute("SELECT w.*, u.name AS creator_name FROM workspace w "
                      "LEFT JOIN user u ON u.id=w.created_by WHERE w.id=? AND w.status='active'",
                      (ws_id,)).fetchone()
        return dict(r) if r else {}
    finally:
        c.close()


def member_options(tenant_id: str = "t-default") -> list:
    """空间成员选择器：只返回本租户可加入空间的人员，不暴露密码等敏感字段。"""
    c = _c()
    try:
        rows = c.execute(
            "SELECT u.id, u.name, u.phone, MIN(r.code) AS role "
            "FROM user u LEFT JOIN user_role ur ON ur.user_id=u.id "
            "LEFT JOIN role r ON r.id=ur.role_id "
            "WHERE u.tenant_id=? AND COALESCE(u.status,'active')='active' "
            "GROUP BY u.id, u.name, u.phone ORDER BY u.name, u.phone", (tenant_id,)).fetchall()
        return [{"id": r["id"], "name": r["name"] or r["phone"] or r["id"],
                 "phone": r["phone"] or "", "role": r["role"] or ""} for r in rows]
    finally:
        c.close()


def current(user_id: str, tenant_id: str = "t-default") -> dict:
    c = _c()
    try:
        r = c.execute("SELECT current_workspace_id FROM user WHERE id=?", (user_id,)).fetchone()
        wid = (r[0] if r else "") or ""
        if not wid:
            any_ws = c.execute("SELECT id FROM workspace WHERE tenant_id=? AND status='active' ORDER BY created_at LIMIT 1",
                               (tenant_id,)).fetchone()
            wid = any_ws[0] if any_ws else "ws-default"
        row = c.execute("SELECT name,settings_json FROM workspace WHERE id=?", (wid,)).fetchone()
        name = row[0] if row else wid
        try:
            st = __import__("json").loads((row[1] if row else "") or "{}")
        except Exception:
            st = {}
        return {"id": wid, "name": name, "doc_types": st.get("doc_types") or []}
    finally:
        c.close()


MODULE_DEFAULTS = {
    "mod_ai_assist": True,      # AI 辅助规则能力可用（每次审核仍需显式勾选）
    "mod_agents": True,         # 智能体（解析/抽取/规则执行）
    "mod_evolution": True,      # 规则进化/候选生成（主链能力默认开启）
    "mod_jev": True,            # Jev 置信度排序
    "mod_ontology": True,       # 本体别名/类型化（默认启用，自动建模按阈值启动）
    "mod_decision_table": True, # 决策表
}

# ---------------------------------------------------------------------------
# 空间设置写白名单（唯一事实源）：``save_settings`` 只持久化这里的键。
# 其它键（如任意业务写过来的未知字段）一律忽略，避免 settings_json 被注入。
# ``mod_direct_discovery`` 是「影子池 Phase3 直连发现源」的空间开关：
#   - 默认不写 = 关（生产默认关，由 project._direct_discovery_switch 判定）；
#   - 只有布尔 True 才开；字符串/None/未知值一律归一为 False（关闭，不抛错）。
# ``mod_sweep_channel`` 是「全文 sweep 候选通道」的空间开关（2026-11-21）：
#   - 默认不写 = 关；显式 False = 关（可覆盖环境开关）；True = 开。
#   - 与 ``mod_direct_discovery`` 同口径：不进 MODULE_DEFAULTS（默认关，语义不同）。
# 注意：**不加入 MODULE_DEFAULTS**——模块默认全开是既有门禁口径（module_defaults_test），
# 本开关默认关，语义不同，不能混用“模块默认”字典。
# ---------------------------------------------------------------------------
SETTINGS_KEYS = (
    "doc_types", "audit_faces", "rule_codes", "point_ids", "ontology_aliases",
    "ontology_terms", "ontology_auto_threshold", "ontology_auto_last_count",
    "alpha", "members", "face_unknown", "audit_layer", "point_supplement",
    "point_confirm_required",
    "mod_ai_assist", "mod_agents", "mod_evolution", "mod_jev",
    "mod_ontology", "mod_decision_table",
    "mod_direct_discovery",
    "mod_sweep_channel",
    "rules_review_waivers",
)
#: 布尔设置键：写入时归一化，读取必须走 :func:`setting_bool`（同一口径）。
BOOL_SETTING_KEYS = frozenset({
    "mod_ai_assist", "mod_agents", "mod_evolution", "mod_jev",
    "mod_ontology", "mod_decision_table", "mod_direct_discovery",
    "mod_sweep_channel",
    "face_unknown", "point_supplement", "point_confirm_required",
})
_TRUTHY_SETTING_STRINGS = frozenset({"1", "true", "yes", "on", "enable", "enabled"})


def coerce_setting_bool(value) -> bool:
    """布尔设置值归一：只有 ``True``/1/常见真值字符串为 True，其余（含 None、未知字符串）→ False。

    这是 save_settings 写入与 setting_bool 读取的**同一口径**；非法值按“关闭”处理，
    不抛错（fail-closed：开关类配置宁可不生效也不能误开）。
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value) and float(value) == 1.0
    if isinstance(value, str):
        return value.strip().lower() in _TRUTHY_SETTING_STRINGS
    return False


def setting_bool(ws_id: str, key: str) -> dict:
    """读取单个布尔空间设置（与 save_settings 白名单同源口径）。

    返回 ``{key, present, raw, value}``：
    - ``present=False``：空间从未显式配置过该键（``value=None``，调用方按默认值处理）；
    - ``present=True``：``value`` 是归一后的 bool（非法值 → False，不抛错）。
    """
    if key not in BOOL_SETTING_KEYS:
        raise ValueError(f"{key} 不是布尔空间设置（白名单：{sorted(BOOL_SETTING_KEYS)}）")
    st = get_settings(ws_id) or {}
    present = key in st
    raw = st.get(key)
    return {"key": key, "present": present, "raw": raw,
            "value": coerce_setting_bool(raw) if present else None}


def modules(ws_id: str) -> dict:
    """工作空间模块开关（存储值覆盖默认值）。"""
    st = get_settings(ws_id) or {}
    out = dict(MODULE_DEFAULTS)
    for k in MODULE_DEFAULTS:
        if k in st:
            out[k] = bool(st[k])
    return out


def module_on(ws_id: str, key: str) -> bool:
    return bool(modules(ws_id).get(key, False))


def explicit_off(ws_id: str, key: str) -> bool:
    """仅当工作空间显式配置为 false 时才视为关闭（默认不改旧行为）。"""
    st = get_settings(ws_id) or {}
    return (key in st) and (not bool(st.get(key)))


def get_settings(ws_id: str) -> dict:
    import json as _j
    c = _c()
    try:
        r = c.execute("SELECT settings_json FROM workspace WHERE id=?", (ws_id,)).fetchone()
        try:
            return _j.loads((r[0] if r else "") or "{}")
        except Exception:
            return {}
    finally:
        c.close()


def save_settings(ws_id: str, patch: dict) -> dict:
    import json as _j
    cur = get_settings(ws_id)
    if cur.get("setup_required"):
        _dts = [str(x).strip() for x in ((patch or {}).get("doc_types") or []) if str(x).strip()]
        if not (1 <= len(_dts) <= 5):
            return {"ok": False, "reason": "通用空间必须先选择 1~5 个主文件类型才能生效"}
        cur.pop("setup_required", None)
        cur["configured_at"] = __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for k in SETTINGS_KEYS:
        if k in (patch or {}):
            cur[k] = (coerce_setting_bool(patch[k]) if k in BOOL_SETTING_KEYS
                      else patch[k])
    c = _c()
    try:
        c.execute("UPDATE workspace SET settings_json=? WHERE id=?",
                  (_j.dumps(cur, ensure_ascii=False), ws_id))
        c.commit()
        return {"ok": True, "settings": cur}
    finally:
        c.close()
