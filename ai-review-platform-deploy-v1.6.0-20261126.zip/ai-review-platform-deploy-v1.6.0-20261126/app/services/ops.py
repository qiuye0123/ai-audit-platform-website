"""运营看板只读数据源。

不伪造数据：任何表/字段缺失、没有调用记录、没有任务，都返回 0 / null，
并在 ``notes`` 里写明原因；前端只展示接口返回值。
"""
from __future__ import annotations

import time
from pathlib import Path

from .. import config, db
from ..engine import llm_router
from . import db_backup, db_health, permissions, sysconfig


def can_view_overview(user: dict | None) -> tuple[bool, str]:
    """运维看板仅系统管理员；平台运营不进入运维看板。"""
    u = user or {}
    role = str(u.get("role") or "")
    uid = str(u.get("sub") or "")
    if role != "super_admin":
        return False, "无权限（运维看板仅系统管理员）"
    try:
        if not permissions.has(uid, "platform.tenant.view"):
            return False, "无权限（缺少平台层查看权限）"
    except Exception:
        return False, "无权限（权限查询失败）"
    return True, ""


def _table_exists(conn, table: str) -> bool:
    try:
        return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                                 (table,)).fetchone())
    except Exception:
        return False


def _columns(conn, table: str) -> set[str]:
    try:
        return {str(r[1]) for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}
    except Exception:
        return set()


def _model(conn, notes: list[str]) -> dict:
    out = {
        "configured": False,
        "available": False,
        "source": None,
        "model": None,
        "enabled_models": 0,
        "total_models": 0,
        "calls_total": 0,
        "calls_24h": 0,
        "failed_24h": 0,
        "success_rate_24h": None,
        "avg_latency_ms": None,
        "last_call_at": None,
        "recent": [],
        "note": "",
    }
    try:
        st = llm_router.status() or {}
        out["source"] = st.get("source")
        out["model"] = st.get("model") or None
        out["configured"] = bool(st.get("enabled") and st.get("model"))
        # 只按配置/启用状态判断“可用”，不主动发网络请求伪造连通性
        out["available"] = bool(out["configured"])
    except Exception as exc:
        notes.append(f"模型配置读取失败：{type(exc).__name__}")
    if _table_exists(conn, "model_config"):
        try:
            cols = _columns(conn, "model_config")
            if "enabled" in cols:
                out["total_models"] = int(conn.execute(
                    "SELECT COUNT(*) FROM model_config").fetchone()[0])
                out["enabled_models"] = int(conn.execute(
                    "SELECT COUNT(*) FROM model_config WHERE enabled=1").fetchone()[0])
        except Exception as exc:
            notes.append(f"model_config 读取失败：{type(exc).__name__}")
    else:
        notes.append("model_config 表不存在，模型配置数按 0 返回")
    if _table_exists(conn, "llm_trace"):
        try:
            out["calls_total"] = int(conn.execute(
                "SELECT COUNT(*) FROM llm_trace").fetchone()[0])
            cutoff = time.strftime("%Y-%m-%d %H:%M:%S",
                                   time.localtime(time.time() - 86400))
            out["calls_24h"] = int(conn.execute(
                "SELECT COUNT(*) FROM llm_trace WHERE created_at>=?", (cutoff,)).fetchone()[0])
            out["failed_24h"] = int(conn.execute(
                "SELECT COUNT(*) FROM llm_trace WHERE created_at>=? "
                "AND COALESCE(response_text,'')=''", (cutoff,)).fetchone()[0])
            if out["calls_24h"]:
                out["success_rate_24h"] = round(
                    (out["calls_24h"] - out["failed_24h"]) / out["calls_24h"], 4)
            row = conn.execute(
                "SELECT AVG(latency_ms) AS lat, MAX(created_at) AS last FROM llm_trace"
            ).fetchone()
            if row:
                out["avg_latency_ms"] = (round(float(row["lat"]), 1)
                                         if row["lat"] is not None else None)
                out["last_call_at"] = row["last"] or None
            out["recent"] = [dict(r) for r in conn.execute(
                "SELECT model,created_at,latency_ms,tokens_in,tokens_out,"
                "CASE WHEN COALESCE(response_text,'')<>'' THEN 1 ELSE 0 END AS ok "
                "FROM llm_trace ORDER BY created_at DESC LIMIT 8").fetchall()]
        except Exception as exc:
            notes.append(f"llm_trace 读取失败：{type(exc).__name__}")
    else:
        notes.append("llm_trace 表不存在，模型调用统计按 0 返回")
    if out["calls_total"] == 0:
        out["note"] = "无模型调用记录（llm_trace 为空）"
        notes.append(out["note"])
    if not out["configured"]:
        notes.append("模型未配置/未启用（按当前 llm_router 配置判断，未发起连通性测试）")
    return out


def _queue(conn, notes: list[str]) -> dict:
    out = {
        "task_job": {
            "total": 0, "backlog": 0, "by_status": {},
            "queued": 0, "running": 0, "done": 0, "failed": 0,
            "cancelled": 0, "timeout": 0, "oldest_queued_at": None,
        },
        "open_task_queue": {"total": 0, "by_status": {}, "accepted": 0,
                            "processing": 0, "completed": 0, "failed": 0},
        "open_event_undelivered": 0,
        "note": "",
    }
    if _table_exists(conn, "task_job"):
        try:
            rows = conn.execute(
                "SELECT COALESCE(status,'') AS status, COUNT(*) AS n FROM task_job "
                "GROUP BY COALESCE(status,'')").fetchall()
            for r in rows:
                out["task_job"]["by_status"][str(r["status"] or "")] = int(r["n"])
                if str(r["status"] or "") in out["task_job"]:
                    out["task_job"][str(r["status"] or "")] = int(r["n"])
            out["task_job"]["total"] = sum(out["task_job"]["by_status"].values())
            out["task_job"]["backlog"] = (out["task_job"]["queued"]
                                          + out["task_job"]["running"])
            row = conn.execute(
                "SELECT MIN(started) AS oldest FROM task_job WHERE status='queued'").fetchone()
            out["task_job"]["oldest_queued_at"] = (row["oldest"] if row else None) or None
            try:
                _age = conn.execute("SELECT CAST((julianday('now','localtime')-julianday(MIN(started)))*1440 AS INTEGER) AS m "
                                    "FROM task_job WHERE status='queued'").fetchone()
                out["task_job"]["oldest_queued_minutes"] = int(_age["m"] or 0) if _age else 0
            except Exception:
                out["task_job"]["oldest_queued_minutes"] = None
            out["task_job"]["recent_failed"] = [dict(r) for r in conn.execute(
                "SELECT id,status,error,updated_at,started FROM task_job "
                "WHERE status IN ('failed','timeout','cancelled') "
                "ORDER BY COALESCE(updated_at,finished,started,'') DESC LIMIT 5").fetchall()]
        except Exception as exc:
            notes.append(f"task_job 读取失败：{type(exc).__name__}")
    else:
        notes.append("task_job 表不存在，任务队列按 0 返回")
    if _table_exists(conn, "open_task_queue"):
        try:
            for r in conn.execute(
                    "SELECT COALESCE(status,'') AS status, COUNT(*) AS n "
                    "FROM open_task_queue GROUP BY COALESCE(status,'')").fetchall():
                out["open_task_queue"]["by_status"][str(r["status"] or "")] = int(r["n"])
                key = str(r["status"] or "")
                if key in out["open_task_queue"]:
                    out["open_task_queue"][key] = int(r["n"])
            out["open_task_queue"]["total"] = sum(
                out["open_task_queue"]["by_status"].values())
        except Exception as exc:
            notes.append(f"open_task_queue 读取失败：{type(exc).__name__}")
    else:
        notes.append("open_task_queue 表不存在，开放平台队列按 0 返回")
    if _table_exists(conn, "open_event"):
        try:
            out["open_event_undelivered"] = int(conn.execute(
                "SELECT COUNT(*) FROM open_event WHERE COALESCE(delivered,0)=0").fetchone()[0])
        except Exception as exc:
            notes.append(f"open_event 读取失败：{type(exc).__name__}")
    if out["task_job"]["total"] == 0 and out["open_task_queue"]["total"] == 0:
        out["note"] = "暂无任务/队列记录"
        notes.append(out["note"])
    return out


def _errors(conn, notes: list[str]) -> dict:
    items: list[dict] = []
    if _table_exists(conn, "task_job"):
        try:
            for r in conn.execute(
                    "SELECT id,status,error,started,finished,updated_at FROM task_job "
                    "WHERE status IN ('failed','timeout','cancelled') "
                    "AND (COALESCE(error,'')<>'' OR status='timeout') "
                    "ORDER BY COALESCE(updated_at,finished,started,'') DESC LIMIT 10").fetchall():
                items.append({
                    "source": "task_job",
                    "module": "task",
                    "at": r["updated_at"] or r["finished"] or r["started"] or "",
                    "event": "task." + str(r["status"] or ""),
                    "title": r["id"],
                    "detail": str(r["error"] or r["status"] or "")[:300],
                })
        except Exception as exc:
            notes.append(f"task_job 错误读取失败：{type(exc).__name__}")
    if _table_exists(conn, "audit_log"):
        try:
            for r in conn.execute(
                    "SELECT id,actor,action,object,after_json,created_at FROM audit_log "
                    "WHERE action LIKE '%failed%' OR action LIKE '%error%' "
                    "ORDER BY created_at DESC LIMIT 10").fetchall():
                items.append({
                    "source": "audit_log",
                    "module": "audit",
                    "at": r["created_at"] or "",
                    "event": r["action"] or "",
                    "title": r["object"] or r["actor"] or "",
                    "detail": str(r["after_json"] or "")[:300],
                })
        except Exception as exc:
            notes.append(f"audit_log 错误读取失败：{type(exc).__name__}")
    if _table_exists(conn, "open_event"):
        try:
            for r in conn.execute(
                    "SELECT id,type,last_error,created_at FROM open_event "
                    "WHERE COALESCE(last_error,'')<>'' "
                    "ORDER BY created_at DESC LIMIT 5").fetchall():
                items.append({
                    "source": "open_event",
                    "module": "open",
                    "at": r["created_at"] or "",
                    "event": r["type"] or "",
                    "title": r["id"],
                    "detail": str(r["last_error"])[:300],
                })
        except Exception as exc:
            notes.append(f"open_event 错误读取失败：{type(exc).__name__}")
    if _table_exists(conn, "open_task_queue"):
        try:
            for r in conn.execute(
                    "SELECT id,error,updated_at FROM open_task_queue "
                    "WHERE COALESCE(error,'')<>'' "
                    "ORDER BY updated_at DESC LIMIT 5").fetchall():
                items.append({
                    "source": "open_task_queue",
                    "module": "open",
                    "at": r["updated_at"] or "",
                    "event": "open_task.failed",
                    "title": r["id"],
                    "detail": str(r["error"])[:300],
                })
        except Exception as exc:
            notes.append(f"open_task_queue 错误读取失败：{type(exc).__name__}")
    items.sort(key=lambda x: str(x.get("at") or ""), reverse=True)
    items = items[:20]
    groups = {}
    for it in items:
        key = (it.get("source") or "") + "::" + (it.get("event") or "")
        g = groups.setdefault(key, {"source": it.get("source") or "", "event": it.get("event") or "",
                                    "count": 0, "first_at": it.get("at") or "",
                                    "last_at": it.get("at") or "", "sample": it.get("detail") or ""})
        g["count"] += 1
        g["last_at"] = max(g["last_at"], it.get("at") or "")
        if not g["sample"]:
            g["sample"] = it.get("detail") or ""
    if not items:
        notes.append("无错误记录（task_job/audit_log/open_event/open_task_queue 均无失败项）")
    return {"count": len(items), "recent": items, "groups": list(groups.values()),
            "note": "" if items else "无错误记录"}


def _upgrade(conn, notes: list[str]) -> dict:
    out = {
        "current_version": config.APP_VERSION,
        "schema_version": None,
        "latest_migration": None,
        "migrations": [],
        "last_upgrade": None,
    }
    if _table_exists(conn, "schema_migration"):
        try:
            rows = [dict(r) for r in conn.execute(
                "SELECT version,name,applied_at FROM schema_migration "
                "ORDER BY applied_at,version").fetchall()]
            out["schema_version"] = len(rows)
            out["migrations"] = rows
            out["latest_migration"] = rows[-1] if rows else None
            if not rows:
                notes.append("schema_migration 表为空（尚无迁移记录）")
        except Exception as exc:
            notes.append(f"schema_migration 读取失败：{type(exc).__name__}")
    else:
        notes.append("schema_migration 表不存在（尚未执行数据层迁移）")
    if _table_exists(conn, "platform_upgrade"):
        try:
            row = conn.execute(
                "SELECT from_version,to_version,package,package_sha256,files_count,"
                "applied_at,applied_by FROM platform_upgrade "
                "ORDER BY applied_at DESC LIMIT 1").fetchone()
            out["last_upgrade"] = dict(row) if row else None
        except Exception as exc:
            notes.append(f"platform_upgrade 读取失败：{type(exc).__name__}")
        if out["last_upgrade"] is None:
            notes.append("platform_upgrade 表为空（尚无增量升级记录）")
    else:
        notes.append("platform_upgrade 表不存在（尚无增量升级记录）")
    return out



def _backup(notes: list[str]) -> dict:
    """最近备份只读事实：有/无、时间、大小、文件数；不触发备份。

    X2 修复：看板必须识别 CLI/迁移产出的真实备份，不能因 NameError 或路径约定
    不一致而恒报“没有可用数据库备份”（false critical）。识别口径：
    - 规范目录 ``<db目录>/backups/``（HTTP/迁移前备份与 ``rp db backup --backup-dir`` 产物）；
    - 兼容旧版 CLI 默认产物：``<db目录>/backup*.db`` 与启动目录 ``backup*.db``
      （旧 ``rp db backup`` 未给 --out 时会写当前目录，看板曾查不到）。
    """
    out = {"dir": "", "exists": False, "count": 0, "latest": None,
           "latest_at": None, "age_hours": None, "size_bytes": None,
           "latest_path": "", "legacy_locations": []}
    try:
        db_path = Path(db.DB_PATH).resolve()
        bdir = db_backup.default_backup_dir(db_path)
        out["dir"] = str(bdir)
        out["exists"] = bdir.is_dir()
        candidates: list[Path] = []
        if bdir.is_dir():
            candidates.extend(x for x in bdir.iterdir() if x.is_file() and x.stat().st_size > 0)
        for legacy_dir in (db_path.parent, Path.cwd()):
            try:
                if not legacy_dir.is_dir():
                    continue
                for x in legacy_dir.glob("backup*.db"):
                    if not x.is_file() or x.stat().st_size <= 0:
                        continue
                    if x.resolve() == db_path:
                        continue
                    candidates.append(x)
            except OSError:
                continue
        uniq: dict[str, Path] = {}
        for x in candidates:
            try:
                uniq[str(x.resolve())] = x
            except OSError:
                continue
        files = sorted(uniq.values(), key=lambda x: x.stat().st_mtime, reverse=True)
        out["count"] = len(files)
        if files:
            f = files[0]
            out["latest"] = f.name
            out["latest_path"] = str(f)
            out["size_bytes"] = f.stat().st_size
            out["latest_at"] = time.strftime("%Y-%m-%d %H:%M:%S",
                                             time.localtime(f.stat().st_mtime))
            out["age_hours"] = round((time.time() - f.stat().st_mtime) / 3600, 1)
            # 非规范目录内的备份单独列出，提示运维统一归档；不影响“可用备份存在”判定。
            legacy = [str(x) for x in files if str(x.parent) != str(bdir)]
            out["legacy_locations"] = legacy[:5]
            if legacy:
                notes.append("检测到非规范目录中的备份产物（CLI 旧默认位置）；"
                             "建议 `rp db backup --backup-dir <db目录>/backups` 统一归档")
            if not bdir.is_dir():
                notes.append("备份目录不存在，但已检测到旧默认位置的备份文件")
        elif not bdir.is_dir():
            notes.append("尚未创建备份目录（可用 rp db backup --backup-dir 生成首个备份）")
        else:
            notes.append("备份目录为空（尚无可用备份文件）")
    except Exception as exc:
        notes.append(f"备份信息读取失败：{type(exc).__name__}")
    return out


def _actions(view: dict) -> dict:
    """把真实指标转成 IT 管理员可执行的处置清单，而不是装饰性 KPI。"""
    actions: list[dict] = []
    checks: list[dict] = []

    def add(aid, severity, area, title, detail, evidence, action, command="", view_name="", tab=""):
        actions.append({"id": aid, "severity": severity, "area": area, "title": title,
                        "detail": detail, "evidence": evidence, "action": action,
                        "command": command, "target_view": view_name, "target_tab": tab})

    def chk(cid, label, status, value, action=""):
        checks.append({"id": cid, "label": label, "status": status,
                       "value": value, "action": action})

    d = view.get("db") or {}; j = view.get("json") or {}; m = view.get("model") or {}
    q = view.get("queue") or {}; e = view.get("errors") or {}; u = view.get("upgrade") or {}
    b = view.get("backup") or {}; tj = q.get("task_job") or {}; otq = q.get("open_task_queue") or {}

    # 数据库
    if not d.get("exists"):
        chk("db_exists", "数据库文件", "critical", "不存在", "检查 RULEPROOF_DB / 启动目录")
        add("db_missing", "critical", "数据库", "数据库文件不存在",
            "服务当前无法保证数据持久化。", str(d.get("path") or ""),
            "先确认 RULEPROOF_DB 配置和启动目录，再重启服务。")
    else:
        chk("db_exists", "数据库文件", "ok", f"{d.get('size_bytes') or 0} bytes")
    if (j.get("invalid_count") or 0) > 0:
        chk("json", "JSON 一致性", "critical", f"{j.get('invalid_count')} 个坏值",
            "先备份，再按 sample 定位；不要直接批量改写生产库")
        add("json_invalid", "critical", "数据一致性", f"发现 {j.get('invalid_count')} 个无法解析的 JSON 字段",
            "坏 JSON 会导致读取失败、规则/运行记录不可用。",
            "、".join([f"{x.get('table')}.{x.get('column')}#{x.get('rowid')}" for x in (j.get("samples") or [])[:3]]) or "见数据库页 samples",
            "先执行数据库备份；再按 samples 逐条核对，禁止无备份批量修复。",
            "rp db backup", "", "db")
    else:
        chk("json", "JSON 一致性", "ok", "0 坏值")
    wal = d.get("wal_bytes") or 0; size = d.get("size_bytes") or 0
    if size > 0 and wal > max(64 * 1024 * 1024, size * 0.25):
        chk("wal", "WAL 体积", "warn", f"{wal} bytes", "确认长事务/连接未释放；不要手工删 -wal")
        add("wal_large", "warning", "数据库", "WAL 文件偏大",
            "可能存在长事务、未关闭连接或高频写入未检查点。", f"WAL {wal} / DB {size} bytes",
            "检查长事务和进程连接；在低峰期由 DBA 执行 checkpoint，禁止直接删除 -wal。",
            "rp db check", "auditlogs", "db")
    if (d.get("freelist_pages") or 0) > 1000:
        chk("freelist", "空闲页", "info", f"{d.get('freelist_pages')} pages", "评估 VACUUM，需窗口期")
        add("freelist_large", "info", "数据库", "空闲页偏多",
            "历史删除较多，文件空间未回收；不影响正确性。", f"freelist {d.get('freelist_pages')} pages",
            "在维护窗口备份后评估 VACUUM；不要在线直接操作生产库。", "rp db backup", "auditlogs", "db")

    # 备份
    if not b.get("latest"):
        chk("backup", "可用备份", "critical", "无", "先建首个备份")
        add("backup_missing", "critical", "备份", "没有可用数据库备份",
            "升级、迁移、修复坏数据前必须先有可恢复备份。", str(b.get("dir") or "backups 目录为空"),
            "立即执行一次在线备份并校验产物；备份完成前不要做 schema 变更。",
            "rp db backup", "", "upgrade")
    else:
        age = b.get("age_hours")
        if age is not None and age > 24 * 7:
            chk("backup", "备份新鲜度", "warn", f"{age:.1f} 小时前", "按 RPO 重新备份")
            add("backup_stale", "warning", "备份", "最近备份超过 7 天",
                "数据恢复点过旧；升级/迁移前风险高。", f"{b.get('latest')} · {b.get('latest_at')}",
                "重新执行备份，并保留至少一份异地/只读副本。", "rp db backup", "", "upgrade")
        else:
            chk("backup", "备份新鲜度", "ok", f"{age or 0:.1f} 小时前")

    # 队列
    failed = int(tj.get("failed") or 0) + int(otq.get("failed") or 0)
    if failed:
        chk("queue_failed", "队列失败", "critical", f"{failed} 个", "逐条看错误并决定重试/取消")
        add("queue_failed", "critical", "队列", f"{failed} 个任务失败",
            "失败任务可能阻塞审核或回调；先看错误，再决定重试/取消。",
            f"task_job failed={tj.get('failed')} · open_task failed={otq.get('failed')}",
            "进入队列页看失败明细；确认是暂时性错误再重试，权限/数据错误不要盲目重试。",
            "rp ops overview", "openplatform", "queue")
    else:
        chk("queue_failed", "队列失败", "ok", "0")
    backlog = int(tj.get("backlog") or 0); oldest = tj.get("oldest_queued_minutes")
    if backlog and (oldest is None or oldest >= 15):
        chk("queue_backlog", "队列积压", "warn", f"{backlog} 个 / 最久 {oldest or '—'} 分钟", "检查 worker/任务锁")
        add("queue_backlog", "warning", "队列", f"队列积压 {backlog} 个",
            "有任务排队但长时间未消费，可能是 worker 停止、锁竞争或模型超时。",
            f"最久排队 {oldest or '—'} 分钟",
            "先看模型延迟和 worker 状态；确认没有重复消费/死锁后再扩容或重启 worker。",
            "rp ops overview", "openplatform", "queue")
    if (q.get("open_event_undelivered") or 0) > 0:
        chk("open_event", "开放平台回调", "warn", f"{q.get('open_event_undelivered')} 未投递", "检查订阅/重试/对端")
        add("open_undelivered", "warning", "开放平台", f"{q.get('open_event_undelivered')} 个事件未投递",
            "可能是对端不可达、签名失败或重试耗尽。",
            "open_event delivered=0",
            "看回调错误与下次重试时间；确认 URL/签名/网络，再决定重试。",
            "", "openplatform", "queue")

    # 模型
    if not m.get("available"):
        chk("model", "模型可用性", "critical", "未配置/未启用", "配置 provider/key 后再审核")
        add("model_unavailable", "critical", "模型", "模型未启用",
            "依赖模型的语义审核会 abstain/unknown，不等于通过。",
            f"configured={m.get('configured')} source={m.get('source')}",
            "到模型配置检查 provider、Key、启用状态和默认模型；不要用假调用填充看板。",
            "", "model", "model")
    else:
        chk("model", "模型可用性", "ok", str(m.get("model") or "已配置"))
    rate = m.get("success_rate_24h")
    if rate is not None and rate < 0.9:
        chk("model_success", "模型成功率", "warn", f"{rate:.1%}", "看失败调用与 provider 限流")
        add("model_fail_rate", "warning", "模型", f"模型 24h 成功率 {rate:.1%}",
            "失败调用会造成审核弃权或重试成本。",
            f"calls={m.get('calls_24h')} failed={m.get('failed_24h')}",
            "按最近失败调用看错误码；区分 Key/限流/超时/内容拒绝，再调整重试或路由。",
            "", "model", "model")
    if m.get("calls_24h") == 0:
        chk("model_calls", "模型调用", "info", "24h 无调用", "跑一次受控连通性/审核")
        add("model_no_calls", "info", "模型", "24 小时没有模型调用",
            "没有调用记录无法判断模型质量；不是故障，但不能据此说模型健康。",
            "llm_trace 24h empty",
            "跑一次受控审核或模型连通性测试，确认调用链和计费正常。",
            "", "model", "model")
    else:
        chk("model_calls", "模型调用", "ok", f"{m.get('calls_24h')} 次/24h")

    # 错误
    if (e.get("count") or 0) > 0:
        groups = e.get("groups") or []
        chk("errors", "最近错误", "warn", f"{e.get('count')} 条 / {len(groups)} 类", "按错误组排优先级")
        add("errors_present", "warning", "错误", f"最近有 {e.get('count')} 条错误",
            "重复错误组优先处理；单次错误看是否自愈。",
            "；".join(f"{g.get('source')}/{g.get('event')} ×{g.get('count')}" for g in groups[:3]),
            "进入错误页按组查看首次/最近时间；先处理高频组，再处理单次异常。",
            "rp ops overview", "auditlogs", "errors")
    else:
        chk("errors", "最近错误", "ok", "0")

    # 升级/schema
    if u.get("schema_version") is None:
        chk("schema", "数据层迁移", "warn", "未记录", "执行迁移前先备份")
        add("schema_missing", "warning", "升级", "schema_migration 未建立/为空",
            "无法确认数据层版本，升级包不能安全判断。", "schema_version=None",
            "先备份，再执行受控迁移并记录版本；不要在未备份时升级。",
            "rp db migrate", "auditlogs", "upgrade")
    else:
        chk("schema", "数据层迁移", "ok", f"v{u.get('schema_version')}")

    # 空数据：不伪造健康，给可执行起点
    if int(tj.get("total") or 0) == 0 and int(otq.get("total") or 0) == 0 and m.get("calls_24h") == 0:
        add("no_runtime_data", "info", "运行数据", "当前没有任务/调用记录",
            "空库不能证明系统健康；先跑一个受控项目/审核。", "task_job=0 · llm_trace_24h=0",
            "在测试租户跑一次最小项目审核，再回来看看板；不要用空指标当健康证明。",
            "", "projects", "")

    rank = {"critical": 0, "warning": 1, "info": 2}
    actions.sort(key=lambda x: (rank.get(x["severity"], 9), x["id"]))
    crit = sum(1 for x in actions if x["severity"] == "critical")
    warn = sum(1 for x in actions if x["severity"] == "warning")
    status = "critical" if crit else ("warning" if warn else "healthy")
    if not actions:
        status = "healthy"
    return {
        "status": status,
        "critical": crit,
        "warning": warn,
        "action_count": len(actions),
        "actions": actions,
        "checks": checks,
        "summary": (f"{crit} 个高优先级问题" if crit else
                    (f"{warn} 个需要关注项" if warn else "当前未发现高优先级异常")),
    }


def overview() -> dict:
    """只读运营视图；所有统计来自当前 SQLite 与真实调用记录。"""
    notes: list[str] = []
    started = time.time()
    conn = db.connect()
    try:
        stats = db_health.db_stats(conn, db.DB_PATH)
        json_check = db_health.json_consistency(conn)
        model = _model(conn, notes)
        backup = _backup(notes)
        try:
            queue = _queue(conn, notes)
            errors = _errors(conn, notes)
            upgrade = _upgrade(conn, notes)
        except Exception as exc:
            notes.append(f"队列/错误/升级信息读取失败：{type(exc).__name__}")
            queue = {"task_job": {"total": 0, "backlog": 0, "by_status": {}},
                     "open_task_queue": {"total": 0, "by_status": {}},
                     "open_event_undelivered": 0, "note": "读取失败，按空返回"}
            errors = {"count": 0, "recent": [], "note": "读取失败，按空返回"}
            upgrade = {"current_version": config.APP_VERSION, "schema_version": None,
                       "latest_migration": None, "migrations": [], "last_upgrade": None}
    finally:
        conn.close()
    if json_check.get("invalid_count"):
        notes.append(f"发现 {json_check['invalid_count']} 个 JSON 字段无法解析（只读报告，不自动修改）")
    try:
        policy = sysconfig.data_policy_status()
        manual = []
        for w in policy.get("warnings") or []:
            manual.append({"kind": "policy", "text": w})
        conflict = bool((policy.get("external_model") or {}).get("conflict"))
        if conflict:
            manual.append({"kind": "external_model",
                           "text": "外发策略与当前模型配置冲突，需要系统管理员判断"})
        data_policy = {
            "configured": policy.get("configured"),
            "warnings": policy.get("warnings") or [],
            "external_model": policy.get("external_model") or {},
            "retention": policy.get("retention") or {},
            "deletion": policy.get("deletion") or {},
            "manual_items": manual,
            "note": "数据边界默认后台静默处理；只有需要人工判断的例外进入本看板。",
        }
    except Exception as exc:
        data_policy = {"configured": None, "warnings": [], "manual_items": [],
                       "note": f"数据边界状态读取失败：{type(exc).__name__}"}
        notes.append(data_policy["note"])
    sources = {
        "db": {"source": "SQLite 文件 + PRAGMA", "window": "当前快照",
               "note": "路径/大小/WAL/页数来自真实文件与 PRAGMA，不估算"},
        "json": {"source": "逐表 JSON 列扫描", "window": "当前库全量",
                 "note": "坏值只报告不自动修改"},
        "model": {"source": "model_config + llm_trace", "window": "累计 + 近 24 小时",
                  "note": "成功率/失败数来自 llm_trace 真实调用；无调用显示无数据"},
        "queue": {"source": "task_job + open_task_queue", "window": "当前状态",
                  "note": "积压=queued/running；oldest 为最久排队时间"},
        "errors": {"source": "task_job/audit_log/open_event/open_task_queue",
                   "window": "最近 20 条 + 分组", "note": "失败项按来源分组"},
        "backup": {"source": "db备份目录 + 旧 CLI 默认位置",
                   "window": "最近备份文件 mtime",
                   "basis": "判定依据：存在 size>0 的 .db 文件按 mtime 取最新；只做文件级只读检查，"
                            "不校验内容哈希/可恢复性（可用 rp db check 进一步验证）"},
        "upgrade": {"source": "VERSION + schema_migration + platform_upgrade", "window": "当前",
                    "note": "无迁移记录时明确显示无记录"},
        "data_policy": {"source": "sys_config 数据边界策略 + 引擎状态", "window": "当前",
                        "note": "未配置会显式警告，不静默套用默认值"},
    }
    return {
        "ok": True,
        "readonly": True,
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "duration_ms": int((time.time() - started) * 1000),
        "sources": sources,
        "time_window": {"generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "model_24h": "近 24 小时", "errors": "最近 20 条/分组",
                        "queue": "当前", "backup": "最近备份文件",
                        "db": "当前快照"},
        "db": stats,
        "json": json_check,
        "model": model,
        "queue": queue,
        "errors": errors,
        "upgrade": upgrade,
        "backup": backup,
        "data_policy": data_policy,
        "actions": _actions({
            "db": stats, "json": json_check, "model": model, "queue": queue,
            "errors": errors, "upgrade": upgrade, "backup": backup,
        }),
        "notes": notes,
    }
