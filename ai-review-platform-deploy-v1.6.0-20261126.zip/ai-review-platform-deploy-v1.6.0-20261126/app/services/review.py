"""审核服务：文档导入 → 解析 → 规则执行 → 五态/证据/锚点持久化 → 标准对照 → 报告。

入口契约（P0-1，见 ``review_entry_contract``）：

- 唯一产品入口是 ``project.audit`` 的 manual / assisted 两模式；
- ``review.run_review``、``review_legacy.run_review``、``review_compat.run_review_api``
  只做历史兼容适配，不定义第三套 full 语义，返回值统一走 :func:`normalize_result`。
"""
import hashlib
import logging
from html import escape as _esc_html
import json
import os
import re

from .. import config
from .. import db
from .. import repositories as R
from ..engine import engine, stdcheck, docparse
from ..engine import llm
from . import audit_ledger as _audit_ledger
# DU-29（2026-11-25）：状态/结论别名唯一事实源（manifest_exec / audit_ledger / review 共用）。
from . import state_machines as _state_machines


def _module_off(key: str, workspace_id: str = "") -> bool:
    """T-115：工作空间模块开关在主链执行点的统一口径。

    与 HTTP 层 ``server._module_off`` 同源（``workspaces.explicit_off``：仅显式 false
    才关闭，默认不改变旧行为）。传入项目空间优先，否则取当前线程上下文；拿不到
    空间（CLI/脚本/旧调用方）时不判定关闭，保持兼容。
    """
    try:
        from . import ctx as _ctx_m, workspaces as _ws_m
        wid = str(workspace_id or "").strip()
        if not wid:
            wid = str((_ctx_m.get_context() or {}).get("workspace_id") or "").strip()
        return bool(wid) and bool(_ws_m.explicit_off(wid, key))
    except Exception:
        logging.getLogger(__name__).debug("module switch lookup skipped", exc_info=True)
        return False


# ---------------------------------------------------------------------------
# 职责分离（报告 / 复核）：业务管理员只读、审核员只本人、系统管理员平台层
# ---------------------------------------------------------------------------
REVIEW_ROLES = ("super_admin", "admin", "reviewer", "platform_op")
REVIEW_ACTIONS = ("view", "review", "export")
_PLATFORM_ROLES = ("super_admin", "platform_op")


class ReviewPermissionError(PermissionError):
    """复核/报告越权；携带 code/status，供 CLI、HTTP、测试统一映射。"""

    http_status = 403

    def __init__(self, message: str, code: str = "forbidden", status: int = 403):
        super().__init__(message)
        self.code = code
        self.status = status
        self.http_status = int(status)

    def to_dict(self) -> dict:
        return {"ok": False, "error": self.code, "code": self.code,
                "message": str(self), "http_status": int(self.status)}


def _roles_of_actor(actor: str) -> list:
    """查账号真实角色；查不到或异常时返回空（fail-closed）。"""
    actor = str(actor or "").strip()
    if not actor:
        return []
    try:
        from . import account
        return [str(x) for x in (account.roles_of(actor) or []) if x]
    except Exception:
        logging.getLogger(__name__).debug("actor role lookup skipped", exc_info=True)
        return []


def _primary_role(roles: list) -> str:
    for code in REVIEW_ROLES:
        if code in (roles or []):
            return code
    return str((roles or [""])[0] or "")


def resolve_actor(actor: str = "", role: str = "") -> dict:
    """解析操作者身份。

    有账号时以数据库真实角色为准，``role`` 声明值不能覆盖（防伪造提权）。
    无账号但有显式 actor + role 时，把 role 视为调用方（HTTP/CLI 层）已鉴权的
    会话角色；没有 actor 的裸 role 一律拒绝。这样服务层既能做职责硬校验，
    也不要求每个内部调用都先落一个 user 行。
    """
    actor = str(actor or "").strip()
    declared = str(role or "").strip()
    roles = _roles_of_actor(actor)
    if roles:
        effective = _primary_role(roles)
        return {"actor": actor, "role": effective, "roles": roles,
                "resolved": True, "declared_role": declared,
                "role_mismatch": bool(declared and declared not in roles),
                "identity_verified": True}
    if actor and declared in REVIEW_ROLES:
        return {"actor": actor, "role": declared, "roles": [declared],
                "resolved": True, "declared_role": declared, "role_mismatch": False,
                "identity_verified": False}
    return {"actor": actor, "role": "", "roles": [], "resolved": False,
            "declared_role": declared, "role_mismatch": bool(declared),
            "identity_verified": False}


def _access_result(ok: bool, ident: dict, *, code: str = "", status: int = 0,
                   message: str = "", read_only: bool = False) -> dict:
    return {"ok": bool(ok), "code": code, "status": status, "message": message,
            "actor": ident.get("actor") or "", "role": ident.get("role") or "",
            "roles": list(ident.get("roles") or []), "read_only": bool(read_only),
            "can_review": bool(ok and not read_only and ident.get("role") == "reviewer"),
            "can_export_report": bool(ok and not read_only and ident.get("role") == "reviewer"),
            "resolved": bool(ident.get("resolved")),
            "identity_verified": bool(ident.get("identity_verified")),
            "declared_role": ident.get("declared_role") or "",
            "role_mismatch": bool(ident.get("role_mismatch"))}


def authorize_case(case_id: str, action: str = "view", actor: str = "",
                   role: str = "") -> dict:
    """案例级职责校验（严格模式）。

    - 系统管理员 / 平台运营：只能平台层，业务审核/复核/报告一律拒绝
    - 业务管理员：只能 view（只读），review / export 拒绝
    - 审核员：只能本人 created_by 的案例，view / review / export 允许
    """
    action = str(action or "view").strip().lower()
    ident = resolve_actor(actor, role)
    if action not in REVIEW_ACTIONS:
        return _access_result(False, ident, code="invalid_action", status=400,
                              message=f"未知操作：{action}")
    case = R.cases.get(case_id) if case_id else None
    if not case:
        return _access_result(False, ident, code="not_found", status=404,
                              message="项目不存在")
    if not ident.get("resolved"):
        return _access_result(False, ident, code="unauthenticated", status=401,
                              message="未认证或账号不存在，不能访问审核数据")
    effective = ident.get("role") or ""
    if effective in _PLATFORM_ROLES:
        return _access_result(False, ident, code="forbidden", status=403,
                              message="系统管理员/平台账号仅限平台层，不能访问业务审核、复核或报告")
    if effective == "admin":
        if action == "view":
            return _access_result(True, ident, read_only=True)
        return _access_result(False, ident, code="forbidden", status=403,
                              message="业务管理员只读：不能复核、编辑或导出报告")
    if effective == "reviewer":
        owner = str(case.get("created_by") or "")
        if owner != str(ident.get("actor") or ""):
            return _access_result(False, ident, code="forbidden", status=403,
                                  message="审核员只能访问本人项目")
        return _access_result(True, ident)
    return _access_result(False, ident, code="forbidden", status=403,
                          message="当前身份不能访问审核数据")


def authorize_finding(finding_id: str, action: str = "review", actor: str = "",
                      role: str = "") -> dict:
    """发现级职责校验：先定位 finding，再复用案例级规则。"""
    finding = R.findings.get(finding_id) if finding_id else None
    if not finding:
        return _access_result(False, resolve_actor(actor, role), code="not_found",
                              status=404, message="问题不存在")
    result = authorize_case(finding.get("case_id") or "", action, actor, role)
    result["finding_id"] = str(finding.get("id") or "")
    result["case_id"] = str(finding.get("case_id") or "")
    return result


def _verified_actor_id(value: str) -> str:
    """user_id 能解析出真实角色时返回该 ID，用于旧路由的兼容职责校验。"""
    aid = str(value or "").strip()
    return aid if aid and _roles_of_actor(aid) else ""


def _deny_payload(result: dict) -> dict:
    return {"error": result.get("message") or "无权限",
            "code": result.get("code") or "forbidden",
            "status": int(result.get("status") or 403)}


def check_case_access(case_id: str, action: str = "view", actor: str = "",
                      role: str = "") -> dict:
    """公开别名：供报告/复核/测试统一调用。"""
    return authorize_case(case_id, action, actor, role)


def can_review(case_id: str, actor: str = "", role: str = "") -> bool:
    return bool(authorize_case(case_id, "review", actor, role).get("ok"))


def can_export_report(case_id: str, actor: str = "", role: str = "") -> bool:
    return bool(authorize_case(case_id, "export", actor, role).get("ok"))


# ---------------------------------------------------------------------------
# 审核入口契约（P0-1）：唯一产品入口是 project.audit 的 manual / assisted
# ---------------------------------------------------------------------------
# 三个历史入口只允许做「传输 / 参数适配」，不得再定义第三套 full 语义：
#   review.run_review           旧一次性调用 → review_legacy 适配器（显式 legacy=True）
#   review_legacy.run_review    legacy 适配器实现；调用方必须显式 legacy=True
#   review_compat.run_review_api /reviews、/upload、/demo 兼容入口 → project 两模式
# 产品入口（唯一）：project.audit(case_id, ai_assist=True/False)
REVIEW_ENTRY_CONTRACT = "review-entry.v1"
REVIEW_PRODUCT_ENTRY = "project.audit"
REVIEW_PRODUCT_MODES = ("manual", "assisted")
REVIEW_PIPELINES = ("project", "legacy")
REVIEW_ENTRY_PIPELINES = {"project": "project", "review_compat": "project",
                          "review": "legacy", "review_legacy": "legacy"}
REVIEW_ENVELOPE_KEYS = ("case_id", "summary", "findings", "orchestration", "dag",
                        "conflicts", "review_contract")
REVIEW_SUMMARY_KEYS = ("status", "critical_count", "warning_count", "total_findings",
                       "abstain_count", "unknown_count", "manifest_unknown_count",
                       "exec_failed_count", "na_count", "manifest_items",
                       "jev_low_confidence",
                       # DU-27（2026-11-25/红线 4）：unknown 聚合桶三态分列，
                       # 不把 insufficient/missing 混成一个未知数
                       "insufficient_count", "unknown_state_count", "missing_count",
                       "state_counts")
REVIEW_FINDING_KEYS = ("id", "code", "rule_code", "rule_name", "category", "rclass",
                       "severity", "title", "summary", "suggestion", "state", "origin",
                       "evidence")
REVIEW_STATUS_VALUES = ("通过", "不通过", "待复核", "待复核（含弃权）", "不适用",
                        "审核失败", "未审核")
LEGACY_ENTRY_EXPLICIT_ERROR = "legacy_entry_requires_explicit_flag"


def review_entry_contract() -> dict:
    """三入口边界的正式说明（测试与文档共用，避免口头约定）。"""
    return {
        "version": REVIEW_ENTRY_CONTRACT,
        "product_entry": REVIEW_PRODUCT_ENTRY,
        "product_modes": list(REVIEW_PRODUCT_MODES),
        "pipelines": list(REVIEW_PIPELINES),
        "entries": {
            "review": {"module": "app.services.review", "function": "run_review",
                       "kind": "compat_adapter", "pipeline": "legacy",
                       "explicit": "legacy=True（由适配器转发，调用方不声明语义）",
                       "calls": "review_legacy.run_review(..., legacy=True)"},
            "review_legacy": {"module": "app.services.review_legacy",
                              "function": "run_review", "kind": "legacy_adapter",
                              "pipeline": "legacy",
                              "explicit": "legacy=True（唯一进入旧链的方式）",
                              "calls": "project.create → project.audit(legacy=True)"},
            "review_compat": {"module": "app.services.review_compat",
                              "function": "run_review_api", "kind": "compat_adapter",
                              "pipeline": "project",
                              "explicit": "ai_assist=True/False（None→assisted；full 不允许）",
                              "calls": "project.create → project.audit(ai_assist=...)"},
        },
        "result": {"envelope": list(REVIEW_ENVELOPE_KEYS),
                   "summary": list(REVIEW_SUMMARY_KEYS),
                   "finding": list(REVIEW_FINDING_KEYS)},
        "status_values": list(REVIEW_STATUS_VALUES),
        "legacy_explicit_error": LEGACY_ENTRY_EXPLICIT_ERROR,
        "unknown_policy": {
            "product": "summary.unknown_count 是 fail-closed 聚合（unknown+insufficient+missing）；"
                       "三态分列见 summary.insufficient_count/unknown_state_count/missing_count "
                       "与 summary.state_counts，报告四类口径的 unknown 桶内分态见 "
                       "categories.unknown.state_counts；compat_mode=legacy 时报告门禁把"
                       "平台/内置 unknown 列入附录",
            "legacy": "legacy 链不规划平台点位，summary.unknown_count = 0；分态计数同口径为 0",
            "cross_entry": "三入口共享报告门禁阻断 unknown 口径；原始 summary.unknown_count "
                           "按各自链路真实台账计数，不互相伪造/抹平；分态字段与聚合同源",
        },
        "permission": "仅 reviewer 可发起审核写入；admin/super_admin/platform_op 403",
        "audit": "每个入口完成后写 review.completed（object=case_id，after={entry,pipeline,mode,summary}）",
    }




def assert_entry_writable(actor: str = "", role: str = "", *, entry: str = "") -> dict:
    """三入口共享的写权限口径。

    - 账号真实角色为 reviewer：允许；
    - admin / super_admin / platform_op：只读，抛 ReviewPermissionError(403)；
    - 解析不到账号的 actor（空 / 旧脚本 / 测试占位）：放行并标记
      identity_verified=False —— HTTP/CLI 层已先做认证，服务层不另造一套身份。
    """
    ident = resolve_actor(actor, role)
    out = {"ok": True, "actor": ident.get("actor") or "", "role": ident.get("role") or "",
           "roles": list(ident.get("roles") or []), "entry": str(entry or ""),
           "resolved": bool(ident.get("resolved")),
           "identity_verified": bool(ident.get("identity_verified")),
           "declared_role": ident.get("declared_role") or "",
           "role_mismatch": bool(ident.get("role_mismatch"))}
    if not ident.get("resolved"):
        return out
    if ident.get("role") != "reviewer":
        raise ReviewPermissionError(
            f"{entry or '审核入口'}：{ident.get('role') or '未知角色'} 只读/平台身份，"
            "不能发起审核写入（仅审核员可执行审核）", code="forbidden", status=403)
    return out


def _persisted_audit_summary(case_id: str) -> dict:
    """F-08：读取最近一次审核落库的判定结论（audit_run.trace_json.summary）。

    旧库/旧 run 无落库结论时返回 {}，调用方退回既有派生逻辑（不伪造状态）。
    """
    try:
        case = R.cases.get(case_id) or {}
        run_id = str(case.get("last_run_id") or "")
        if not run_id:
            return {}
        row = R.audit_runs.get(run_id) or {}
        try:
            trace = json.loads(row.get("trace_json") or "{}")
        except Exception:
            trace = {}
        if isinstance(trace, dict):
            summary = trace.get("summary")
            if isinstance(summary, dict) and summary:
                out = dict(summary)
                out.setdefault("run_id", run_id)
                return out
        return {}
    except Exception:
        logging.getLogger(__name__).debug("persisted audit summary skipped", exc_info=True)
        return {}


def _contract_finding(finding: dict, pipeline: str) -> dict:
    """把不同链路的 finding 归一成同一字段集合；只补默认值，不改已有业务值。"""
    f = dict(finding or {})
    f["id"] = str(f.get("id") or "")
    if not f.get("code"):
        f["code"] = str(f.get("rule_code") or f.get("rule_id") or f.get("id") or "")
    if not f.get("rule_code"):
        f["rule_code"] = str(f.get("rule_id") or f.get("code") or "")
    for key in ("rule_name", "category", "rclass", "title", "summary", "suggestion"):
        value = f.get(key)
        f[key] = value if isinstance(value, str) else str(value or "")
    severity = f.get("severity")
    f["severity"] = str(severity or "warning").strip().lower()
    # legacy 链只产出「需要人工看的问题」，没有项目链的 pass/unknown 物化；
    # 这里显式标记 fail，避免调用方把缺字段误读成「无结论」。
    state = f.get("state")
    if not state:
        f["state"] = "fail" if pipeline == "legacy" else "unknown"
    else:
        f["state"] = str(state)
    origin = f.get("origin")
    if not origin:
        f["origin"] = "legacy" if pipeline == "legacy" else "unknown"
    else:
        f["origin"] = str(origin)
    if not isinstance(f.get("evidence"), list):
        f["evidence"] = []
    f.setdefault("confidence", None)
    return f


def _contract_summary(summary: dict, findings: list, pipeline: str) -> dict:
    """统一 summary：计数以 findings 为准，缺省字段补 0，状态沿用既有结论。"""
    s = dict(summary or {})
    # F-08：空清单（manifest_items=0 且无 finding）不得因计数为 0 落回“通过”
    _raw_manifest_items = s.get("manifest_items")
    total = len(findings)
    critical = sum(1 for f in findings if f.get("severity") == "critical")
    s["critical_count"] = critical
    # 与 project 链同口径：非 critical 全部计入 warning（含 info/提示）
    s["warning_count"] = max(0, total - critical)
    s["total_findings"] = total
    # DU-27（2026-11-25）：unknown 聚合（unknown+insufficient+missing）保留为 fail-closed
    # 旧口径；三态必须同时分列，不得只给一个聚合数（红线 4：五态不可合并）。
    _state_counts = {"pass": 0, "fail": 0, "na": 0, "insufficient": 0,
                     "unknown": 0, "missing": 0, "execution_failed": 0}
    for _f in findings:
        _st = str((_f or {}).get("state") or "")
        if _st in _state_counts:
            _state_counts[_st] += 1
    _derived_insufficient = _state_counts["insufficient"]
    _derived_unknown_only = _state_counts["unknown"]
    _derived_missing = _state_counts["missing"]
    _derived_unknown = _derived_insufficient + _derived_unknown_only + _derived_missing

    def _fill_int(key: str, default: int) -> None:
        try:
            s[key] = int(s[key]) if s.get(key) is not None else int(default)
        except (TypeError, ValueError):
            s[key] = int(default)

    _fill_int("unknown_count", _derived_unknown)
    _fill_int("abstain_count", s.get("unknown_count", _derived_unknown))
    _fill_int("insufficient_count", _derived_insufficient)
    _fill_int("unknown_state_count", _derived_unknown_only)
    _fill_int("missing_count", _derived_missing)
    if not isinstance(s.get("state_counts"), dict):
        s["state_counts"] = dict(_state_counts)
    _fill_int("manifest_unknown_count", 0)
    _fill_int("exec_failed_count", 0)
    _fill_int("na_count", 0)
    _fill_int("manifest_items", 0)
    _fill_int("jev_low_confidence", 0)
    if not s.get("status"):
        _empty_manifest = (_raw_manifest_items is not None
                           and str(_raw_manifest_items).strip() not in ("", "None")
                           and int(s.get("manifest_items") or 0) == 0)
        if critical:
            s["status"] = "不通过"
        elif s.get("unknown_count"):
            s["status"] = "待复核（含弃权）"
        elif total:
            s["status"] = "待复核"
        elif _empty_manifest:
            # fail-closed：清单为空/无适用规则时禁止写“通过”
            s["status"] = "待复核（无适用规则）"
        else:
            s["status"] = "通过"
    s["status"] = str(s["status"])
    return s


def normalize_result(result: dict, *, entry: str, pipeline: str = "", mode: str = "",
                     case_id: str = "") -> dict:
    """三入口统一返回值：同 envelope / summary / finding schema + 入口元数据。"""
    src = dict(result or {})
    pipe = pipeline or REVIEW_ENTRY_PIPELINES.get(entry) or "project"
    findings = [_contract_finding(f, pipe) for f in (src.get("findings") or [])]
    out = dict(src)
    orchestration = src.get("orchestration")
    if not isinstance(orchestration, list):
        orchestration = []
    conflicts = src.get("conflicts")
    if not isinstance(conflicts, list):
        conflicts = []
    out.update({
        "case_id": str(src.get("case_id") or case_id or ""),
        "summary": _contract_summary(src.get("summary") or {}, findings, pipe),
        "findings": findings,
        "orchestration": orchestration,
        "dag": src.get("dag"),
        "conflicts": conflicts,
        "review_contract": {
            "version": REVIEW_ENTRY_CONTRACT,
            "entry": str(entry or ""),
            "pipeline": pipe,
            "mode": str(mode or ("legacy" if pipe == "legacy" else "")),
            "product_entry": REVIEW_PRODUCT_ENTRY,
            "product_modes": list(REVIEW_PRODUCT_MODES),
            "legacy_explicit": bool(pipe == "legacy"),
            "schema": {"envelope": list(REVIEW_ENVELOPE_KEYS),
                       "summary": list(REVIEW_SUMMARY_KEYS),
                       "finding": list(REVIEW_FINDING_KEYS)},
        },
    })
    return out


def log_entry_completion(case_id: str, summary: dict, *, entry: str, pipeline: str,
                         mode: str = "", actor: str = "system") -> None:
    """三入口共享审计口径：完成后统一写 review.completed + {entry,pipeline,mode,summary}。"""
    try:
        R.audit_logs.log(
            actor=actor or "system", action="review.completed", object=str(case_id or ""),
            after=json.dumps({"entry": str(entry or ""), "pipeline": str(pipeline or ""),
                              "mode": str(mode or ""), "summary": dict(summary or {})},
                             ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).warning("review completion audit log failed case=%s",
                                            case_id, exc_info=True)


def resolve_compat_ai_assist(value) -> bool:
    """兼容入口的 ai_assist 归一：None→assisted；拒绝 full/legacy 第三语义。"""
    if value is None:
        return True
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "on", "assisted"):
        return True
    if text in ("0", "false", "no", "off", "manual", ""):
        return False
    raise ValueError(f"非法审核模式：{value}（仅 manual/assisted；full/legacy 不再作为入口模式）")


def _file_hash(path: str) -> str:
    """文件内容 hash：统一完整 sha256（F-03）。

    历史上上传路径截断为 16 位、seed 路径写完整 64 位，跨路径比对永不相等。
    统一完整 sha256 后，用 :func:`_hash_matches` 做历史 16/32/40 位前缀的双读兼容。
    """
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _hash_matches(stored, full_hash) -> bool:
    """hash 双读兼容：完整 sha256 相等，或历史截断值（16/32/40）是完整值前缀。"""
    s = str(stored or "").strip().lower()
    f = str(full_hash or "").strip().lower()
    if not s or not f:
        return False
    if s == f:
        return True
    if len(s) in (16, 32, 40) and len(f) > len(s) and f.startswith(s):
        return True
    return False


def import_document(path: str, doc_type: str = "process_sheet", source: str = "upload") -> str:
    doc_id = db.new_id("doc")
    R.documents.insert(id=doc_id, filename=os.path.basename(path), doc_type=doc_type,
                       hash=_file_hash(path), source_system=source, status="parsed")
    return doc_id


def apply_decision_tables(path: str, text: str, type_hint: str = "", facts: dict = None) -> list:
    """决策表联动（可独立测试）：条件指标直接从原文取数，不依赖 LLM 事实命名。"""
    from . import decision_table as _dtb
    from ..engine import ruleexec as _re
    facts = dict(facts or {})
    out, seen_codes, seen_hits = [], set(), set()
    for t in _dtb.list_tables():
        code = t.get("code") or ""
        if code in seen_codes:
            continue
        seen_codes.add(code)
        cur = (_dtb.get(code) or {})
        if (cur.get("status") or t.get("status")) != "published":
            continue
        try:
            import json as _j
            for r in _j.loads(cur.get("rules_json") or t.get("rules_json") or "[]"):
                for c in (r.get("when") or []):
                    m = c.get("metric")
                    if m and str(m) not in facts:
                        v, _q = _re._from_text(str(m), text)
                        if v is not None:
                            facts[str(m)] = [float(v)]
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        res = _dtb.evaluate(code, facts, type_hint, "")
        for h in (res.get("hits") or []):
            _k = (code, h.get("row"))
            if _k in seen_hits:
                continue
            seen_hits.add(_k)
            out.append({"id": f"DT-{code}-{h['row']}", "rule_code": code, "point_id": "",
                        "source_code": "", "level": h.get("severity", "warning"),
                        "title": f"决策表命中：{cur.get('name') or code}", "rule_name": cur.get("name") or code,
                        "category": "limit", "description": h.get("message", ""),
                        "suggestion": h.get("suggestion", ""),
                        "locations": [{"locator": os.path.basename(path), "quote": "", "sheet": ""}],
                        "criterion": f"{code} 第 {h['row']} 行", "level_label": ""})
    return out


import threading as _th

_MODEL_TLS = _th.local()


def _model_down() -> bool:
    return bool(getattr(_MODEL_TLS, "down", False))


def _set_model_down() -> None:
    _MODEL_TLS.down = True


def _diag_rules(text: str) -> dict:
    """规则执行诊断：不调用模型，低成本统计每条规则为何没执行（用于发现静默 0 条）。"""
    import json as _jd
    from ..engine import ruleexec as _re
    out = {"total": 0, "no_slots": 0, "prefiltered": 0, "applicable_skip": 0,
           "clause_skip": 0, "judged": 0}
    try:
        from . import rule as _rule_scope
        rules = _rule_scope.effective_rule_rows()  # T-171 生效口径（开关默认 0=旧行为）
    except Exception:
        return out
    def _bg(t):
        t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fa5")
        return {t[i:i + 2] for i in range(len(t) - 1)}
    doc_terms = _bg(text[:20000])
    for r in rules:
        out["total"] += 1
        try:
            v = R.rules.published_version(r["id"])
            slots = _jd.loads((v or {}).get("slots_json") or "{}")
        except Exception:
            slots = {}
        if not slots:
            out["no_slots"] += 1
            continue
        crit = str(slots.get("criterion") or "")
        terms = _bg(f"{r.get('name') or ''} {crit}")
        if len(terms & doc_terms) < 2:
            out["applicable_skip"] += 1
            continue
        out["judged"] += 1
    return out


def _parsed_cached(path: str):
    from . import audit_intake
    return audit_intake.ensure_parsed(path)


def _semantic_rule_fail(rule: dict, crit: str, text: str, path: str = "", slots: dict | None = None):
    """通用语义规则判定：规则卡片（范围/证据/单位/例外）随提示词进入 agent-judge。"""
    if not crit or not text:
        return None
    # T-115：空间关闭 mod_agents 时主链不再执行智能体判定（fail-safe，不伪造结论）。
    if _module_off("mod_agents"):
        logging.getLogger(__name__).info(
            "mod_agents=false：跳过语义规则判定（rule=%s）", rule.get("code") or rule.get("id"))
        return None
    try:
        from .rule_card import audit_point as _apc
        point = _apc(rule, slots or {})
    except Exception:
        code = str(rule.get("code") or rule.get("rule_code") or "SEMANTIC")
        point = {"id": code, "name": str(rule.get("name") or code)[:80],
                 "criterion": str(crit)[:600], "required_evidence": "原文逐字证据",
                 "level": str(rule.get("rclass") or "R3")}
    try:
        from . import agents as _ag
        r = _ag.run_agent("agent-judge", {"path": path, "text": text, "points": [point]})
        if r.get("status") != "ok":
            return None
        res = ((r.get("result") or {}).get("results") or [])
        item = res[0] if res else {}
        state = str(item.get("state") or "")
        if state not in ("不满足", "fail"):
            return None
        q = str(item.get("quote") or "").strip()
        return {"reason": str(item.get("rationale") or "")[:200], "quote": q}
    except Exception:
        return None



def _multi_table_claimed_metrics(facts=None, category: str = "") -> set:
    """多条件决策表优先：只有实际适用且命中的表才接管单条规则。

    旧实现按“所有已发布多条件表”的指标无条件屏蔽单条规则，导致一张仅适用
    contract、且未命中的表可以让 food 的温度违规消失。现在先求值，scope 跳过/
    无命中的表都不参与接管。
    """
    if os.environ.get("RULEPROOF_TABLE_PRECEDENCE", "multi") == "0":
        return set()
    try:
        from . import decision_table as _dt, ctx as _ctx_dt, workspaces as _ws_dt
        _cur = _ctx_dt.get_context() or {}
        if _cur.get("workspace_id") and not _ws_dt.module_on(_cur.get("workspace_id"), "mod_decision_table"):
            return set()
        claimed = set()
        fmap = {}
        for f in (facts or []):
            if isinstance(f, dict) and f.get("object") is not None:
                fmap[str(f["object"])] = f.get("value")
        if not fmap:
            return set()
        for t in _dt.list_tables():
            if (t.get("status") or "") != "published":
                continue
            try:
                _full = _dt.get(t.get("code") or "") or t
                rows = json.loads(_full.get("rules_json") or "[]")
                if not any(isinstance(c, dict) and str(c.get("metric") or "") in fmap
                           for row in rows for c in (row.get("when") or [])):
                    continue
                res = _dt.evaluate(t.get("code") or "", fmap, category or "")
            except Exception:
                continue
            if res.get("skipped") or not res.get("matched"):
                continue
            for row in rows:
                when = row.get("when") or []
                metrics = [c.get("metric") for c in when if isinstance(c, dict) and c.get("metric")]
                if len(metrics) >= 2:
                    claimed.update(str(x) for x in metrics)
        return claimed
    except Exception:
        return set()


# 文件类型 token 与 manifest/manifest_exec 的 `_SCOPE_FILE_TOKENS` 保持同一口径：
# applicable_when 里这些 token 是“硬性适用范围”，不是业务语义触发词。
_SCOPE_FILE_TOKENS = frozenset({
    "xlsx", "xls", "docx", "doc", "pdf", "txt", "csv", "md", "markdown",
    "json", "xml", "html", "png", "jpg", "jpeg",
})


def _as_scope_tokens(value) -> list:
    """scope/applicable_when 允许 str / list / 逗号分隔串；统一成去重 token 列表。"""
    if not value:
        return []
    if isinstance(value, str):
        raw = [x.strip() for x in value.replace("、", ",").split(",")]
    elif isinstance(value, (list, tuple, set)):
        raw = []
        for x in value:
            if isinstance(x, str):
                raw.extend(y.strip() for y in x.replace("、", ",").split(","))
            elif x is not None:
                raw.append(str(x).strip())
    else:
        raw = [str(value).strip()]
    return [x for x in dict.fromkeys(raw) if x]


def rule_file_scope_mismatch(slots: dict, scope_obj: dict, path: str) -> str:
    """动态规则执行前的「文件类型适用范围」判定，与 manifest D1 同口径。

    manifest 冻结时 applicable_when/applicable_types 里的 pdf/xlsx/docx 等文件类型
    会参与对象路由：不在范围内的规则被 ``gate.routed_out``，不属于 “未执行”。
    动态规则路径（manifest 未收编/被路由排除的规则）此前只检查 applicable_types，
    导致 applicable_when=pdf 的规则在 xlsx 项目上仍被执行并落 unknown，报告门禁
    被额外阻断（F-04）。这里补齐同一判定：文件类型不匹配 → 返回原因（调用方记 na）。

    只有缓存白名单内的文件类型 token 才做硬性判定；业务 token（如“合同”）
    留给执行期语义，避免误伤。返回空字符串表示未发现文件类型不匹配。
    """
    file_tokens = []
    for src in (_as_scope_tokens((slots or {}).get("applicable_types")),
                _as_scope_tokens((slots or {}).get("applicable_when")),
                _as_scope_tokens((scope_obj or {}).get("applicable_types")),
                _as_scope_tokens((scope_obj or {}).get("applicable_when")),
                _as_scope_tokens((scope_obj or {}).get("scope"))):
        for tok in src:
            if tok.lower().lstrip(".") in _SCOPE_FILE_TOKENS:
                file_tokens.append(tok)
    file_tokens = [x for x in dict.fromkeys(file_tokens) if x]
    if not file_tokens:
        return ""
    fn = str(path or "").lower().replace("\\", "/").rsplit("/", 1)[-1]
    ext = fn.rsplit(".", 1)[-1] if "." in fn else ""
    for tok in file_tokens:
        t = str(tok).lower().lstrip(".")
        if t == ext or t in fn:
            return ""
    return "文件不在规则适用范围（applicable_when=" + "、".join(file_tokens) + "）"


def dynamic_rule_findings(path: str, category: str = "", exclude_codes=None) -> list:
    """执行「已发布的数据库规则」——让规则管理的发布真正生效。"""
    import json as _json
    from ..engine import deepparse, ruleexec
    from ..engine.rules_meta import RULE_META
    out = []
    states = {}
    try:
        from . import pstates as _pst
        _batch = _pst.new_batch()
    except Exception:
        _pst = None
        _batch = ""
    def _mark(code, state, title="", reason=""):
        states[str(code or "")] = {"point_id": str(code or ""), "state": state,
                                   "title": title, "reason": reason}
    try:
        from . import rule as _rule_scope
        rules = _rule_scope.effective_rule_rows()  # T-171 生效口径（开关默认 0=旧行为）
        # 空间规则集：配置了 rule_codes 就只跑这些规则
        try:
            from . import ctx as _cx2, workspaces as _wx2
            _cur2 = _cx2.get_context()
            _st2 = _wx2.get_settings(_cur2.get("workspace_id") or "") if _cur2.get("workspace_id") else {}
            _allow2 = set(_st2.get("rule_codes") or [])
            if _allow2:
                rules = [r for r in rules if (r.get("code") or "") in _allow2]
            if exclude_codes:
                _ex = {str(x) for x in exclude_codes}
                rules = [r for r in rules if (r.get("code") or "") not in _ex]
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        # B1（2026-11-20 外部对抗审查）：运行时执行与发布门禁/冻结用**同一作用域派生**
        # （rule.effective_rule_scopes）。无适用范围的规则不得被消费——否则「发布 400 +
        # 冻结不消费」收紧了、执行期仍执行，绕过依然存在。
        # 允许执行：数据声明 / tags-only / 平台内置来源 / 显式 legacy_scope_missing 历史标记。
        _runtime_kept, _runtime_skipped = [], []
        try:
            _scope_pairs = _rule_scope.effective_rule_scopes(rules)
        except Exception:
            logging.getLogger(__name__).warning(
                "effective rule scope derive failed; runtime execute none", exc_info=True)
            _scope_pairs = []
        for _pair in _scope_pairs:
            try:
                _r0, _der0, _sc0 = _pair
            except Exception:
                continue
            if _der0.get("declared") or _der0.get("legacy_scope_missing"):
                _runtime_kept.append(_r0)
            else:
                _runtime_skipped.append(str(_r0.get("code") or ""))
        if _runtime_skipped:
            logging.getLogger(__name__).warning(
                "RUNTIME_SCOPE_SKIPPED rules=%s（未声明适用范围，执行期不消费；"
                "请补 applicable_types/applicable_when 后重新发布）",
                ",".join(_runtime_skipped[:20]))
        rules = _runtime_kept
    except Exception:
        return out
    if not rules:
        return out
    try:
        parsed = _parsed_cached(path)
        text = parsed["doc"].get("text", "")
        facts = parsed.get("facts", [])
    except Exception:
        return out
    from ..engine import audit_category as _ac
    _claimed_metrics = _multi_table_claimed_metrics(facts, category)
    try:
        from .ctx import get_audit_mode as _gam0
        _manual_rule_mode = (_gam0().get("mode") or "") == "manual"
    except Exception:
        _manual_rule_mode = False
    for r in rules:
        code = r.get("code") or ""
        # T-P0-01：手动模式不是“模型不可用”，客户规则仍要确定性执行；
        # 未执行/空槽位记 na，不得伪造成 unknown 阻断报告。
        _mark(code, "na" if _manual_rule_mode else "unknown",
              str(r.get("name") or code),
              "手动模式不调用模型" if _manual_rule_mode else "模型不可用，未执行")
        if _model_down() and not _manual_rule_mode:
            out.append({"id": code, "rule_code": code, "origin": "model_unavailable",
                        "level": "unknown", "title": f"模型不可用，未执行：{r.get('name') or code}",
                        "description": "本轮已熔断，剩余规则未执行", "suggestion": "",
                        "category": r.get("category") or "", "locations": []})
            continue
        if code in RULE_META:
            continue  # 内置规则已由引擎执行，避免重复
        if not _ac.allow_rule(category, r.get("category", "")) and \
                r.get("category") != "客户沉淀":
            _mark(code, "na", str(r.get("name") or code), "不符合所选审核大类")
            continue  # 不符合所选一级大类（客户自沉规则不参与大类过滤）
        try:
            v = R.rules.published_version(r["id"])
            slots = _json.loads((v or {}).get("slots_json") or "{}")
        except Exception:
            _mark(code, "na" if _manual_rule_mode else "unknown", str(r.get("name") or code),
                  "规则版本不可读（手动模式跳过）" if _manual_rule_mode else "规则版本不可读")
            continue
        if not slots:
            _mark(code, "na" if _manual_rule_mode else "unknown", str(r.get("name") or code),
                  "规则缺少可执行槽位（手动模式跳过）" if _manual_rule_mode else "规则缺少可执行槽位")
            continue
        # 规则作用域：applicable_types/applicable_when 里的文件类型是硬性适用范围，
        # 动态判定必须与 manifest D1 同口径——不匹配记 na，不得执行成 unknown 阻断报告。
        try:
            _scope_obj = json.loads(r.get("scope_json") or "{}")
        except Exception:
            _scope_obj = {}
        if not isinstance(_scope_obj, dict):
            _scope_obj = {}
        _scope_miss = rule_file_scope_mismatch(slots, _scope_obj, path)
        if _scope_miss:
            _mark(code, "na", str(r.get("name") or code), _scope_miss)
            continue
        # 多条件决策表优先：同一指标由决策表负责，避免单条规则重复命中
        if str(slots.get("metric") or "") in _claimed_metrics:
            logging.getLogger(__name__).warning("TABLE_PRECEDENCE skip rule %s metric=%s",
                                                code, slots.get("metric"))
            _mark(code, "na", str(r.get("name") or code), "由适用决策表接管")
            continue
        # 规则预筛：判据与文档无足够字面重叠时跳过（避免 83 条规则全跑，单份耗时数分钟）
        if os.environ.get("RULEPROOF_RULE_PREFILTER", "0") == "1":
            _crit = str(slots.get("criterion") or slots.get("name") or "")
            _t = "".join(ch for ch in text if "\u4e00" <= ch <= "\u9fff")
            _c = "".join(ch for ch in _crit if "\u4e00" <= ch <= "\u9fff")
            _bg = {_t[i:i+2] for i in range(len(_t)-1)}
            _cb = {_c[i:i+2] for i in range(len(_c)-1)}
            if _cb and len(_cb & _bg) < 2:
                continue
        try:
            res = ruleexec.judge_rule(slots, text, facts)
            try:
                from ..engine import hooks as _hk_rv
                res = _hk_rv.guard_judgement(
                    res, provenance=_hk_rv.provenance_of_parsed(parsed),
                    rule_code=str(code), source="review.dynamic_rule_findings",
                    numeric=_hk_rv.point_is_numeric(slots))
            except Exception:  # noqa: BLE001 - 守卫异常不改变判定，但留痕（铁律 2）
                logging.debug("dynamic rule provenance guard skipped", exc_info=True)

        except Exception as e:  # noqa
            res = {"state": "执行失败", "detail": f"{type(e).__name__}"}
        _st = str((res or {}).get("state") or "unknown")
        _map = {"满足": "pass", "不满足": "fail", "证据不足": "insufficient",
                "不适用": "na", "执行失败": "unknown", "弃权": "insufficient"}
        _mark(code, _map.get(_st, "unknown"), str(r.get("name") or code), str((res or {}).get("detail") or ""))
        from ..severity import from_rclass as _sev_from_rclass2
        level = _sev_from_rclass2(r.get("rclass"))
        # 通用语义兜底：模板引擎不支持的自然语言判据，用模型判定（客户规则最常见形态）
        if str((res or {}).get("state") or "") == "不适用":
            _crit = str(slots.get("criterion") or slots.get("name") or "")
            _sf = _semantic_rule_fail(r, _crit, text, path, slots)
            if _sf:
                out.append({
                    "id": code, "rule_code": code, "origin": "customer_rule",
                    "level": level, "title": (r.get("name") or code)[:40],
                    "description": _sf["reason"] or f"不符合：{_crit[:80]}",
                    "suggestion": "",
                    "locations": [{"quote": _sf["quote"], "locator": os.path.basename(path), "sheet": ""}],
                })
                continue
        # 确定性结果为"不满足"时，直接落库，绝不再被点位适用性过滤丢弃
        if str((res or {}).get("state") or "") == "不满足":
            try:
                _map0 = (_json.loads(r.get("scope_json") or "{}") or {}).get("point_mapping") or {}
            except Exception:
                _map0 = {}
            out.append({
                "id": code, "rule_code": code, "point_id": _map0.get("point_id") or "",
                "mapped_confidence": _map0.get("score"), "level": level,
                "title": r.get("name") or code, "description": res.get("detail", ""),
                "suggestion": "", "origin": "customer_rule",
                "locations": [{"locator": os.path.basename(path), "quote": res.get("quote", ""), "sheet": ""}],
            })
            continue
        # 映射点位语义执行：高置信映射时即使数值判据无法取数，也按点位判据做一次判定
        _handled = False
        try:
            import json as _jm2
            _m2 = (_jm2.loads(r.get("scope_json") or "{}") or {}).get("point_mapping") or {}
            # 适用性预判：规则关键词与文档二元组重合不足 → 不调用模型（避免“万事皆可报”）
            import re as _r3
            def _big3(t):
                t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fa5")
                return {t[i:i + 2] for i in range(len(t) - 1)}
            _rule_terms = _big3(f"{r.get('name') or ''} {(_m2.get('point_name') or '')}")
            _doc_terms = _big3(text[:20000])
            _applicable = len(_rule_terms & _doc_terms) >= 2
            # 条款级适用性：选出与该规则最相关的条款；无相关条款 → 不适用，不调模型
            _best_clause, _best_score = "", 0
            try:
                from . import structure as _st2
                for _c in _st2.segment(text):
                    _sc = len(_rule_terms & _big3(_c["text"]))
                    if _sc > _best_score:
                        _best_clause, _best_score = _c["text"], _sc
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
            if not _applicable or _best_score < 1:
                continue
            if _m2.get("mapped") and float(_m2.get("score") or 0) >= 0.8 and _applicable:
                from ..engine import llm as _llm, llm_router as _lr
                from . import auditpoints as _apx
                _cfg = _lr.resolve()
                _libx = _apx.load()
                _pt = next((pp for pp in _libx.points if pp.id == _m2.get("point_id")), None)
                if _pt and _cfg.get("api_key"):
                    _ctx = _best_clause if len(_best_clause) >= 20 else text[:3000]
                    _q = (f"客户规则：{r.get('name')}；阈值：{_jm2.dumps(slots, ensure_ascii=False)}\n"
                          f"点位判据：{_pt.criterion}\n待核条款（只审这一段）：\n{_ctx}")
                    _msgs = [{"role": "system", "content": "按客户规则与点位判据判断文档是否违规。只输出 JSON："
                              "{\"violate\":true|false,\"reason\":\"依据\",\"quote\":\"原文片段\"}"},
                             {"role": "user", "content": _q}]
                    _raw = None
                    from ..engine import llm as _llm2
                    for _attempt in range(2):
                        try:
                            _raw = _llm.chat_completion(_cfg["base_url"], _cfg["api_key"], _cfg["model"],
                                                        _msgs, timeout=45, max_tokens=300)
                            break
                        except Exception as _e2:
                            if _llm2.is_fatal(_e2):
                                raise   # 余额/鉴权问题：不重试
                            if _attempt == 1:
                                raise
                            logging.getLogger(__name__).warning("客户规则判定超时重试：%s", type(_e2).__name__)
                    import json as _jj, re as _rr
                    _mjson = _rr.search(r"\{.*\}", _raw or "", _rr.S)
                    _handled = True
                    if not _mjson:
                        # 模型未按规定输出结构：记计数，不产出发现，也不算执行失败
                        try:
                            from . import metrics as _mt
                            _mt.bump("rule_no_json")
                        except Exception:
                            pass
                        logging.getLogger(__name__).debug("客户规则无 JSON 输出")
                        continue
                    try:
                        _o = _jj.loads(_mjson.group(0))
                    except Exception:
                        logging.getLogger(__name__).debug("客户规则 JSON 解析失败")
                        continue
                    if _o.get("violate"):
                        out.append({"id": code, "rule_code": code, "point_id": _m2.get("point_id") or "",
                                    "mapped_confidence": _m2.get("score"), "origin": "customer_rule",
                                    "level": level, "title": r.get("name") or code,
                                    "description": str(_o.get("reason") or "")[:120],
                                    "suggestion": "", "category": r.get("category") or "",
                                    "locations": [{"locator": os.path.basename(path),
                                                   "quote": str(_o.get("quote") or "")[:80], "sheet": ""}]})
        except Exception as _e3:
            if _llm2.is_fatal(_e3):
                _set_model_down()
                out.append({"id": code, "rule_code": code, "origin": "model_unavailable",
                            "level": "unknown", "title": f"模型不可用，未执行：{r.get('name') or code}",
                            "description": f"{type(_e3).__name__}: {str(_e3)[:60]}", "suggestion": "",
                            "category": r.get("category") or "", "locations": []})
                continue
            logging.getLogger(__name__).exception("客户规则执行失败")
            out.append({"id": code, "rule_code": code, "origin": "customer_rule_failed",
                        "level": "unknown", "title": f"规则执行失败：{r.get('name') or code}",
                        "description": f"{type(_e3).__name__}: {str(_e3)[:60]}", "suggestion": "",
                        "category": r.get("category") or "", "locations": []})
            continue
        if _handled:
            continue
        if res["state"] != "不满足":
            continue
        _map = {}
        try:
            import json as _jm
            _map = (_jm.loads(r.get("scope_json") or "{}") or {}).get("point_mapping") or {}
        except Exception:
            _map = {}
        out.append({
            "id": code, "rule_code": code, "point_id": _map.get("point_id") or "",
            "mapped_confidence": _map.get("score"), "level": level,
            "title": r.get("name") or code, "description": res["detail"], "suggestion": "",
            "locations": [{"locator": os.path.basename(path), "quote": res.get("quote", ""), "sheet": ""}],
        })
    if _pst and states:
        # P1-8：失败的 batch 仍要挂到本次 run（否则 run 看不到该 batch 的
        # ledger_incomplete 标记，门禁无法 fail-closed）；写失败本身由标记 + 抛错表达。
        _BATCH_TLS.batches = list(getattr(_BATCH_TLS, "batches", [])) + [_batch]
        try:
            _pst.record(_batch, list(states.values()),
                        source="review.dynamic_rule_findings")
        except Exception as _e:  # noqa: BLE001
            # P1-8：点位台账写失败必须显性化（不得只看 debug 日志就吞掉）：
            # 该 batch 标记 ledger_incomplete → report_gate 阻断签发；门禁据此不复算残缺台账。
            logging.getLogger(__name__).error(
                "rule ledger record FAILED batch=%s（标记 ledger_incomplete）", _batch,
                exc_info=True)
            try:
                _pst.mark_ledger_incomplete(
                    _batch, getattr(_e, "failed", None) or [],
                    total=int(getattr(_e, "total", 0) or 0),
                    source="review.dynamic_rule_findings")
            except Exception:  # noqa: BLE001
                logging.getLogger(__name__).error(
                    "ledger_incomplete mark failed batch=%s", _batch, exc_info=True)
    return out



def _loc_of(loc: dict, path: str) -> dict:
    """统一修补定位：优先 locator，其次由 sheet+row/col 拼，最后回退文件名。"""
    loc = loc or {}
    locator = loc.get("locator") or ""
    sheet = loc.get("sheet") or ""
    if not locator and sheet:
        col = str(loc.get("col") or "")
        row = loc.get("row")
        locator = f"{sheet}!{col}{row}" if (col and row) else sheet
    if not locator:
        locator = os.path.basename(path)
    return {"locator": locator, "quote": loc.get("quote", ""), "sheet": sheet}


def _route_via_library(path: str, text: str, audit_type: str, audit_category: str) -> dict:
    """统一路由：文件类型识别 → 审核类型 → 点位（含食品补充层）。"""
    from . import auditpoints as _ap
    lib = _ap.load()
    try:
        from . import doctypes as _dtc
        for _e in _dtc.as_library_entries():
            if not any((x.get("name") == _e["name"]) for x in lib.document_types):
                lib.document_types.append(_e)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    dt = _ap._route_by_hint(lib, text, audit_type)
    type_ids = lib.apply_feature_additions(text, dt.get("default_audit_types") or [])
    # 低置信兜底：类型识别得分过低时，不用它裁剪点位（否则一步错、后面全错）
    # 兜底默认关闭：实测「解封全部点位」发现 +51%、命中 -1、耗时 ×3，属净损失
    try:
        _thr = float(os.environ.get("RULEPROOF_DOCTYPE_MIN_SCORE", "0"))
    except Exception:
        _thr = 0.0
    # 按类型兜底：宽泛/低区分度的文档类型不裁点位（实测管理办法召回 21.2%→34.6%）
    _broad = [x for x in os.environ.get(
        "RULEPROOF_DOCTYPE_BROAD", "").split(",") if x]   # 默认空：类型名单缺数据支撑，暂不启用
    _low = (not audit_type) and (
        (_thr > 0 and float(dt.get("score") or 0) <= _thr)
        or (dt.get("name") or "") in _broad)
    if _low:
        type_ids = sorted({getattr(p, "type_id", "") for p in lib.points} - {""}) or type_ids
        dt = dict(dt, low_confidence=True, fallback="全量点位")

    # 多标签类型：低置信时并集启用前 K 个候选类型的审核面（放宽口径，避免误杀）
    try:
        _topk = int(os.environ.get("RULEPROOF_DOCTYPE_TOPK", "3") or 3)
    except Exception:
        _topk = 0
    if _topk > 1 and not audit_type and not _low:
        _head = text[:4000]
        _scored = []
        for t in lib.document_types:
            names = [t.get("name") or ""] + list(t.get("aliases") or [])
            hits = sum(1 for n in names if n and n in _head)
            hits += sum(1 for e in (t.get("recognition_elements") or []) if e and e in text)
            if hits:
                _scored.append((hits, t))
        _scored.sort(key=lambda x: -x[0])
        if _scored and _scored[0][0] <= int(os.environ.get("RULEPROOF_DOCTYPE_TOPK_MIN", "20")):
            _picked = [t for _, t in _scored[:_topk]]
            _ids = []
            for t in _picked:
                _ids.extend(lib.apply_feature_additions(text, t.get("default_audit_types") or []))
            type_ids = sorted(set(type_ids) | set(_ids))
            dt = dict(dt, multi_label=[t.get("name") for t in _picked],
                      multi_label_scores=[s for s, _ in _scored[:_topk]])
    # 未知类型兜底：识别不出类型时给“通用审核面”，而不是 0 个点位
    try:
        _unk = os.environ.get("RULEPROOF_UNKNOWN_FACE",
                              "A01,B01,B03,C01,C06,C08,D02,F02")
        if (dt.get("name") or "") in ("未知类型", "") or float(dt.get("score") or 0) <= 1:
            _unk_ids = [x for x in _unk.split(",") if x]
            type_ids = sorted(set(type_ids) | set(_unk_ids))
            dt = dict(dt, unknown_face=True, face=_unk_ids)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)

    # 补足未被任何类型引用的“死大类”（默认 D05，可用环境变量覆盖）
    _extra = [x for x in os.environ.get("RULEPROOF_EXTRA_AUDIT_TYPES", "D05").split(",") if x]
    if _extra:
        type_ids = sorted(set(type_ids) | set(_extra))
    points = [p.to_dict() for p in lib.route_points(type_ids)]
    if audit_category:
        points = [p for p in points if (p.get("category_id") or "").upper() == audit_category.upper()]
    return {"doc_type": dt, "type_ids": type_ids, "points": points}




_PLAN_TLS = _th.local()


def add_plan(items: list) -> list:
    """记录本轮应审计划；只做去重追加，不改变执行。"""
    cur = list(getattr(_PLAN_TLS, "items", []))
    seen = {(str(x.get("point_id") or ""), str(x.get("title") or "")) for x in cur}
    for x in items or []:
        k = (str((x or {}).get("point_id") or ""), str((x or {}).get("title") or ""))
        if k not in seen:
            cur.append(dict(x or {})); seen.add(k)
    _PLAN_TLS.items = cur
    return cur


def reset_plan() -> None:
    _PLAN_TLS.items = []




_LAST_BATCHES: list = []
_BATCH_TLS = _th.local()




def peek_batches() -> list:
    """只读当前批次（不清空），供摘要/覆盖率统计。"""
    return list(getattr(_BATCH_TLS, "batches", []))


def clear_batches() -> None:
    _BATCH_TLS.batches = []


def _fingerprint(f: dict) -> str:
    """指纹：规则版本 + 业务对象 + 证据位置 + 事实指纹（P1-9）。"""
    import hashlib as _h
    rule = str(f.get("rule_code") or f.get("point_id") or "")
    ver = str(f.get("rule_version") or "")
    obj = str(f.get("object") or f.get("subject") or f.get("point_id") or "")
    locs = f.get("locations") or []
    loc_key = "|".join(
        str(l.get("sheet") or l.get("locator") or "") + "#" + str(l.get("cell") or l.get("paragraph") or "")
        for l in locs) or str(f.get("quote") or "")[:24]
    fact = _h.sha1(str(f.get("summary") or f.get("quote") or "").encode("utf-8")).hexdigest()[:8]
    title = str(f.get("title") or "")
    return f"{rule}@{ver}|{obj}|{loc_key}|{fact}|{title}"


def _title_sim(a: str, b: str) -> float:
    """中文标题相似度（字符 bigram Jaccard）。"""
    def bg(t):
        t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fff")
        return {t[i:i + 2] for i in range(len(t) - 1)}
    A, B = bg(a), bg(b)
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)


def dedupe_findings(findings: list) -> tuple:
    """按指纹去重：保留全部位置；同一指纹但结论等级相反 → 记冲突，不丢弃。
    另做跨规则合并：同一引文且标题高度相似（>=0.6）→ 合并为一条并标注两条来源。"""
    _seen_quote = {}
    _seen_sig = {}
    # 生成期注册表：issue_type + 实体相同 → 同一问题（实验：DEDUPE_V2）
    try:
        if os.environ.get("RULEPROOF_DEDUPE_V2") != "1":
            raise RuntimeError("dedupe_v2 off")
        _reg = {}
        _reg_out = []
        for f in out:
            it = str(f.get("issue_type") or "").strip()
            if it:
                k = (it, _issue_signature(f)[1])
                if k in _reg:
                    base = _reg[k]
                    base.setdefault("merged_rules", [base.get("rule_code") or ""]).append(f.get("rule_code") or "")
                    for loc in (f.get("locations") or []):
                        if loc not in base.setdefault("locations", []):
                            base["locations"].append(dict(loc))
                    continue
                _reg[k] = f
            _reg_out.append(f)
        out = _reg_out
    except Exception:
        logging.getLogger(__name__).debug('issue registry failed', exc_info=True)
    # （已移除关键词族合并：会把不同点位的问题误合并，见 2026-11-11 复盘）
    merged = []
    for f in findings or []:
        q = ((f.get("locations") or [{}])[0] or {}).get("quote") or ""
        q = str(q).strip()[:60]
        key = q
        # 同一点位（或同一规则）+ 同一文档 → 视为同一问题，合并证据（实验：DEDUPE_V2）
        _pid = str(f.get("point_id") or f.get("rule_code") or "") if os.environ.get("RULEPROOF_DEDUPE_V2") == "1" else ""
        _sig2 = _issue_signature(f)
        if _pid:
            _b = _seen_sig.get(("pid", _pid))
            if _b is not None:
                _e1 = set(_sig2[1]); _e0 = set(_issue_signature(_b)[1])
                if not _e1 or not _e0 or (_e1 & _e0):
                    _b.setdefault("merged_rules", [_b.get("rule_code") or ""]).append(f.get("rule_code") or "")
                    for loc in (f.get("locations") or []):
                        if loc not in _b.setdefault("locations", []):
                            _b["locations"].append(dict(loc))
                    continue
            else:
                _seen_sig[("pid", _pid)] = f
        sig = _issue_signature(f)
        # 关键词相同 + 标题相近（或实体一致）→ 合并；覆盖“无数值”的名称/清单类问题
        if sig[0]:
            base_kw = _seen_sig.get(("kw", sig[0]))
            if base_kw is not None:
                sim = _title_sim(base_kw.get("title") or "", f.get("title") or "")
                ent_ok = (not sig[1]) or (not _issue_signature(base_kw)[1]) or bool(set(sig[1]) & set(_issue_signature(base_kw)[1]))
                if sim >= 0.25 and ent_ok:
                    base_kw.setdefault("merged_rules", [base_kw.get("rule_code") or ""]).append(f.get("rule_code") or "")
                    for loc in (f.get("locations") or []):
                        if loc not in base_kw.setdefault("locations", []):
                            base_kw["locations"].append(dict(loc))
                    continue
            else:
                _seen_sig[("kw", sig[0])] = f
        if sig[0] and sig[1] and sig in _seen_sig:
            base = _seen_sig[sig]
            base.setdefault("merged_rules", [base.get("rule_code") or ""]).append(f.get("rule_code") or "")
            for loc in (f.get("locations") or []):
                if loc not in base.setdefault("locations", []):
                    base["locations"].append(dict(loc))
            continue
        if sig[0] and sig[1]:
            _seen_sig[sig] = f
        if q and key in _seen_quote:
            base = _seen_quote[key]
            if (str(base.get("level")) == str(f.get("level"))
                    and _title_sim(base.get("title") or "", f.get("title") or "") >= 0.45):
                base.setdefault("merged_rules", [base.get("rule_code") or ""]).append(f.get("rule_code") or "")
                for loc in (f.get("locations") or []):
                    if loc not in base.setdefault("locations", []):
                        base["locations"].append(dict(loc))
                continue
        if q:
            _seen_quote[key] = f
        merged.append(f)
    findings = merged
    merged, order, conflicts = {}, [], []
    for f in findings or []:
        k = _fingerprint(f)
        if f.get("source_code"):
            # 确定性结论用完整标题区分，避免“同前缀不同问题”被合并
            k = (k, str(f.get("title") or ""))
        if k in merged:
            base = merged[k]
            if True:
                logging.getLogger(__name__).warning("DEDUPE_MERGE [%s] <= [%s]", str(base.get("title"))[:20], str(f.get("title"))[:20])
            base.setdefault("locations", [])
            for loc in (f.get("locations") or []):
                if loc not in base["locations"]:
                    base["locations"].append(dict(loc))
            if str(base.get("level")) != str(f.get("level")):
                conflicts.append({"fingerprint": k, "a": base.get("level"), "b": f.get("level"),
                                  "title": f.get("title") or base.get("title") or ""})
                base["engine_conflict"] = True
                # 合并时保留更严重的等级，避免确定性 critical 被模型 warning 覆盖
                if "critical" in (str(base.get("level")), str(f.get("level"))):
                    base["level"] = "critical"
            continue
        merged[k] = {**f, "locations": [dict(x) for x in (f.get("locations") or [])]}
        order.append(k)
    return [merged[k] for k in order], conflicts


def _apply_behavior(findings: list, type_hint: str = "") -> list:
    """唯一的行为参数出口：停用 / 文档类型灰度 / 忽略词 / 严重度降级。

    事实层、引擎、模型点位、决策表、schema 等所有产出路径最终都必须经过这里。
    """
    from . import ruleparam as _rp
    out = []
    for f in findings:
        code = f.get("rule_code") or f.get("source_code") or ""
        beh = _rp.behavior(code) if code else {}
        if beh.get("enabled") is False:
            continue
        st = beh.get("scope_types") or []
        if st:
            # 灰度：类型已知且不在范围 → 跳过；类型未知 → 保守保留（但要可追溯）
            if type_hint and type_hint not in st:
                continue
        kws = beh.get("ignore_keywords") or []
        blob = f"{f.get('title') or ''} {f.get('description') or ''}"
        if kws and any(k and k in blob for k in kws):
            continue
        scoped = str(beh.get("severity_scope") or "").strip()
        sev = beh.get("severity") or ""
        if sev in ("critical", "warning", "info", "suspected"):
            pid = f.get("point_id") or ""
            rc = f.get("source_code") or f.get("rule_code") or ""
            if not scoped or scoped == (f.get("category") or "") or scoped in pid \
               or scoped == rc or pid.startswith(scoped) or rc.startswith(scoped):
                f = dict(f)
                f["level"] = sev
        out.append(f)
    return out

def _pack_pipeline(path: str, focus: str, audit_category: str, type_hint: str = "",
                   exclude_points: set = None, include_decision_tables: bool = True) -> tuple:
    """场景包执行：按库路由点位，有确定性执行器的用程序跑，其余走模型。

    场景包（如食品工艺书）只通过「审核点库 + supplement」声明能力，核心不感知具体行业。
    """
    from . import auditpoints as _ap
    from ..engine import deepparse
    out = []
    try:
        parsed = _parsed_cached(path)
        text = parsed["doc"].get("text", "")
    except Exception:
        text = ""
    routed = _route_via_library(path, text, type_hint, audit_category)
    points = routed["points"]
    # 实验开关：关闭“类型闸门”，改为按文本相关性选点位（路由只做事后标签）
    # 审核模式（线程局部）：assisted 且用户未显式选文档类型 → 不做预路由，跑全部点位
    try:
        from .ctx import get_audit_mode as _gam
        _am = _gam()
    except Exception:
        _am = {"mode": "manual", "doc_type": ""}
    if _am.get("mode") == "assisted":
        _nr_mode = "0" if _am.get("doc_type") else "all"
    else:
        _nr_mode = os.environ.get("RULEPROOF_NO_ROUTE", "0")
    if _nr_mode in ("1", "all"):
        try:
            from . import auditpoints as _ap2
            _lib = _ap2.load()
            def _bg(t):
                t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fff")
                return {t[i:i+2] for i in range(len(t) - 1)}
            _doc = _bg(text[:60000])
            _sel = []
            _full = _nr_mode == "all"
            for _p in _lib.points:
                _own = _bg(f"{_p.name} {_p.criterion}")
                if _full or len(_own & _doc) >= 2:
                    _sel.append({"id": _p.id, "name": _p.name, "criterion": _p.criterion,
                                 "required_evidence": _p.required_evidence, "trigger": _p.trigger,
                                 "level": getattr(_p, "level", None) or getattr(_p, "severity", "warning"),
                                 "severity": getattr(_p, "severity", "warning"),
                                 "method": getattr(_p, "method", ""),
                                 "prompt": getattr(_p, "prompt", ""), "category": _p.category,
                                 "category_id": getattr(_p, "category_id", "")})
            points = _sel
            logging.getLogger(__name__).info("NO_ROUTE 选点 %s（原路由 %s）", len(points), len(routed["points"]))
        except Exception:
            logging.getLogger(__name__).debug('no-route select failed', exc_info=True)
    add_plan(points)
    if not points:
        # 没有点位时仍要跑“批准摘录 vs 正文”确定性差异；否则 /reviews 适配器会丢这类发现
        try:
            from ..engine import approved_diff as _ad0
            _txt0 = (open(path, encoding="utf-8", errors="ignore").read()
                     if path.lower().rsplit(".", 1)[-1] in ("md", "txt")
                     else deepparse.parse_document(path).text or "")
            return _apply_behavior(list(_ad0.findings(_txt0, os.path.basename(path))), type_hint), True
        except Exception:
            logging.getLogger(__name__).debug('approved_diff no-point fallback skipped', exc_info=True)
            return [], False
    # 确定性后端：引擎 + 事实层各跑一次
    det = []
    try:
        det.extend(engine.build_report(path)["findings"])
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    try:
        from ..engine import factreview
        for f in factreview.review_document(path)["findings"]:
            _q = (f.get("evidence") or [""])[0]
            try:
                _loc = _ap.locate_quote(path, str(_q))
            except Exception:
                _loc = {"locator": os.path.basename(path), "quote": str(_q)[:80], "sheet": ""}
            det.append({"rule_code": f["id"], "title": f["title"], "description": f["detail"],
                        "level": f["level"], "locations": [_loc]})
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 行为参数：对引擎与事实层结论统一生效（停用 / 严重度覆盖 / 忽略关键词）
    try:
        from . import ruleparam as _rp
        kept = []
        for f in det:
            code = f.get("rule_code") or ""
            beh = _rp.behavior(code) if code else {}
            if beh.get("enabled") is False:
                continue
            _st = beh.get("scope_types") or []
            if _st and type_hint and type_hint not in _st:
                continue   # 规则灰度：限定文档类型
            kws = beh.get("ignore_keywords") or []
            _blob = f"{f.get('title') or ''} {f.get('description') or ''}"
            _scope = (f.get("category") or "")
            _scoped = str(beh.get("severity_scope") or "").strip()
            if kws and any(k and k in _blob for k in kws):
                continue
            # 严重度降级作用域：支持一级分类（A-G / consistency…）、点位前缀（FOOD01）、规则码
            if _scoped:
                _pid = f.get("point_id") or ""
                _rc = f.get("source_code") or f.get("rule_code") or ""
                if not (_scoped == _scope or _scoped in _pid or _scoped == _rc
                        or _pid.startswith(_scoped) or _rc.startswith(_scoped)):
                    sev = ""
            sev = beh.get("severity") or ""
            if sev in ("critical", "warning", "info", "suspected"):
                f["level"] = sev
            kept.append(f)
        det = kept
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    used = set()
    for p in points:
        ex = p.get("executor") or ""
        if not ex:
            continue
        codes = [c.strip() for c in ex.split(",") if c.strip()]
        kw = p.get("match") or ""
        hits = [f for f in det if f.get("rule_code") in codes and (not kw or kw in (f.get("title") or ""))]
        for f in hits:
            used.add(id(f))
            loc = (f.get("locations") or [{}])[0]
            out.append({"id": p["id"], "rule_code": p["id"], "point_id": p["id"],
                        "source_code": f.get("rule_code") or "",
                        "level": f.get("level", "warning"),
                        "title": f.get("title") or p.get("name"),
                        "rule_name": p.get("name", ""),
                        "category": p.get("category", ""),
                        "description": f.get("description", ""), "suggestion": "",
                        "locations": [_loc_of(loc, path)],
                        "criterion": p.get("criterion", ""), "level_label": p.get("level", "")})
    # 场景包的确定性引擎结论是权威结果：未被点位覆盖的也要保留（避免按点位裁剪丢结论）
    if any(p.get("executor") for p in points):
        for f in det:
            if id(f) in used:
                continue
            loc = (f.get("locations") or [{}])[0]
            out.append({"id": f.get("rule_code") or "", "rule_code": f.get("rule_code") or "",
                        "point_id": "", "level": f.get("level", "warning"),
                        "title": f.get("title") or "", "rule_name": f.get("rule_name") or "",
                        "category": f.get("category") or "",
                        "description": f.get("description", ""), "suggestion": "",
                        "locations": [_loc_of(loc, path)],
                        "criterion": "", "level_label": ""})
    # 决策表联动：统一走 apply_decision_tables（条件指标直接取数 + 去重）
    # 模块未启用时不参与审核，避免“已发布决策表偷偷生效”
    try:
        if include_decision_tables and _ws0.module_on(_case_w0, "mod_decision_table"):
            out.extend(apply_decision_tables(path, text, type_hint, {}))
    except Exception:
        logging.getLogger(__name__).debug('decision table runtime check skipped', exc_info=True)

    # 字段级 schema 校验：仅对“像工艺/检验类文档”的文本启用，避免公司简介等被误报字段缺失
    _looks_process = any(k in (text or "") for k in ("工序", "检验日期", "工艺", "配料", "生产"))
    try:
        from . import schema_check as _sc
        for iss in (_sc.check_document(path, type_hint) if _looks_process else []):
            out.append({"id": f"SCHEMA-{iss['field']}", "rule_code": "SCHEMA", "point_id": "",
                        "source_code": "", "level": iss["level"], "title": iss["title"],
                        "rule_name": "字段 schema 校验", "category": "format",
                        "description": iss.get("detail", ""), "suggestion": "",
                        "locations": [{"locator": "全文（字段缺失）" if "缺失" in iss["title"] else "全文",
                                       "quote": "", "sheet": ""}],
                        "criterion": "字段类型/必填/范围", "level_label": ""})
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 非确定性点位：走模型批量判定（未配模型则跳过，覆盖率在汇总里体现）
    try:
        # 空间配置：文档类型范围 + 审核面（未配置则不过滤，保持兼容）
        try:
            from . import ctx as _ctx_t, workspaces as _w_t
            _cur_t = _ctx_t.get_context()
            _st_t = _w_t.get_settings(_cur_t.get("workspace_id") or "") if _cur_t.get("workspace_id") else {}
            _types = set(_st_t.get("doc_types") or [])
            if _types:
                _dt_code = str((routed.get("doc_type") or {}).get("code")
                               or (routed.get("doc_type") or {}).get("name") or "")
                if _dt_code and _dt_code not in _types:
                    logging.getLogger(__name__).info("文档类型 %s 不在空间范围 %s 内，跳过点位", _dt_code, _types)
                    points = []
        except Exception:
            logging.getLogger(__name__).debug("doc type scope check failed", exc_info=True)
        try:
            from . import ctx as _ctx_s, workspaces as _w_s
            _cur = _ctx_s.get_context()
            _ws_set = _w_s.get_settings(_cur.get("workspace_id") or "") if _cur.get("workspace_id") else {}
            _faces = set(_ws_set.get("audit_faces") or [])
            if _faces:
                _before = len(points)
                points = [p for p in points if str(p.get("category_id") or "") in _faces]
                logging.getLogger(__name__).debug("空间审核面过滤 %s → %s", _before, len(points))
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        if exclude_points:
            _before = len(points)
            points = [p for p in points if p.get("id") not in exclude_points]
            logging.getLogger(__name__).debug("残集两轮：点位 %s → %s", _before, len(points))
        # T-115：空间关闭 mod_agents 时主链不再跑 agent-judge（也不走 orchestrator 的
        # agent 优先路径）；确定性规则/事实层结论保持原样，不伪造模型结论。
        if _module_off("mod_agents"):
            logging.getLogger(__name__).info("mod_agents=false：跳过 agent-judge 批量判定")
        else:
            from . import orchestrator as _orch
            _jfs = _orch.judge_points(path, points, focus, text)
            # unknown/insufficient 是覆盖率结果，不是“发现”；未配模型时不能把全部点位当问题
            out.extend([f for f in _jfs
                        if str(f.get("state") or "") not in ("unknown", "insufficient")
                        and str(f.get("level") or "") != "unknown"])
            if _ap.last_batch():
                _BATCH_TLS.batches = list(getattr(_BATCH_TLS, "batches", [])) + [_ap.last_batch()]
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 去重：同一点位下若引擎（非 F-*）已有结论，则丢弃事实层的同概念结论；
    # 同一标题只保留一条，避免引擎与事实层重复计数。
    by_point = {}
    for f in out:
        pid = f.get("point_id") or ""
        if pid:
            by_point.setdefault(pid, []).append(f)
    drop = set()
    for pid, group in by_point.items():
        if any(not str(f.get("source_code") or "").startswith("F-") for f in group):
            for f in group:
                if str(f.get("source_code") or "").startswith("F-"):
                    drop.add(id(f))
    kept = [f for f in out if id(f) not in drop]
    # 来源标注：客户规则 / 平台补齐 / 沉淀规则（两轮制的结果合并后必须可区分）
    for f in kept:
        code = str(f.get("rule_code") or "")
        src = str(f.get("source") or "")
        if src:
            f["origin"] = src
        elif code.startswith("CUST-") or code.startswith("RW"):
            f["origin"] = "customer_rule"
        elif code.startswith("SED-"):
            f["origin"] = "sedimented_rule"
        elif "-" in code and code[:1].isalpha():
            f["origin"] = "platform_point"
        else:
            f["origin"] = "platform_rule"
    # 两轮合并去重：同一点位 + 同一证据，只保留客户规则来源
    _prio = {"customer_rule": 0, "sedimented_rule": 1, "platform_point": 2, "platform_rule": 3}
    _seen = {}
    for f in sorted(kept, key=lambda x: _prio.get(x.get("origin"), 9)):
        q = ""
        loc = (f.get("locations") or [{}])[0] or {}
        q = str(loc.get("quote") or "")[:40]
        key = (f.get("point_id") or f.get("rule_code") or "", q or str(f.get("title") or ""))
        if key in _seen:
            logging.getLogger(__name__).warning("RR_DEDUPE [%s] <= [%s] key=%s",
                                                str(_seen[key].get("title"))[:20], str(f.get("title"))[:20], str(key)[:46])
            continue
        _seen[key] = f
    kept = list(_seen.values())
    if os.environ.get("RULEPROOF_DEDUPE", "1") == "0":
        dedup, engine_conflicts = kept, []
    else:
        dedup, engine_conflicts = dedupe_findings(kept)
    if engine_conflicts:
        try:
            from .. import repositories as _R
            _R.audit_logs.log(actor="system", action="finding.engine_conflict",
                              object=type_hint or "",
                              after=__import__("json").dumps(engine_conflicts[:5], ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 批准摘录 vs 正文确定性差异（补原生改写/编号篡改，不依赖模型）
    try:
        from ..engine import approved_diff as _ad
        from ..engine import deepparse as _dp2
        if path.lower().rsplit(".", 1)[-1] in ("md", "txt"):
            _txt2 = open(path, encoding="utf-8", errors="ignore").read()
        else:
            _txt2 = _parsed_cached(path)["doc"].get("text", "")
        _extra = _ad.findings(_txt2, os.path.basename(path))
        if _extra:
            dedup = list(dedup) + _extra
        if os.environ.get("RULEPROOF_RECORD_PAIRS", "1") != "0":
            from ..engine import record_pairs as _rp
            _pairs = _rp.check(_txt2)
            if _pairs:
                dedup = list(dedup) + _pairs
    except Exception:
        logging.getLogger(__name__).debug('approved_diff skipped', exc_info=True)
    return _apply_behavior(dedup, type_hint), True


_AUDIT_LOCK = __import__('threading').RLock()


def _findings_for(path: str, focus: str = "", audit_type: str = "", audit_category: str = "",
                  exclude_codes=None, include_decision_tables: bool = True) -> list:
    """按扩展名分派，返回统一的 finding 结构。
    xlsx：黄金结构走规则引擎；所有格式再走事实层通用审核（任意文件都能审）。
    """
    if not path or not os.path.exists(path):
        # 不再静默返回空：路径错误必须显式暴露，避免“审了 0 条”被误当正常结果
        raise FileNotFoundError(f"待审核文件不存在：{path}")
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    # 进程内串行化审核：避免共享状态导致并发结果不一致（正确性优先）
    _lock = _AUDIT_LOCK if os.environ.get("RULEPROOF_AUDIT_SERIAL", "1") == "1" else None
    if _lock is not None:
        _lock.acquire()
        if os.environ.get("RULEPROOF_DEBUG_LOCK") == "1":
            import time as _t, threading as _th
            logging.getLogger(__name__).warning("LOCK_IN tid=%s t=%.3f", _th.get_ident() % 10000, _t.time() % 1000)
    try:
        _out = _findings_for_inner(path, focus, audit_type, audit_category, exclude_codes)
        # P0-证据：fail 引文必须逐字命中本对象原文/单元格；不命中在这里就降级，不进入落库主链
        try:
            _out = _apply_fail_quote_gate_to_findings(_out, path)
        except Exception:
            logging.getLogger(__name__).warning("fail quote gate skipped: %s", path, exc_info=True)
        return _out
    finally:
        if _lock is not None:
            if os.environ.get("RULEPROOF_DEBUG_LOCK") == "1":
                import time as _t, threading as _th
                logging.getLogger(__name__).warning("LOCK_OUT tid=%s t=%.3f", _th.get_ident() % 10000, _t.time() % 1000)
            _lock.release()


def judge_findings(path: str, focus: str = "", audit_type: str = "", audit_category: str = "",
                   exclude_codes=None, include_decision_tables: bool = True) -> list:
    """DAG/主链共用的单次 judge；exclude_codes 用于让 manifest 独占客户规则。"""
    return _findings_for(path, focus, audit_type, audit_category, exclude_codes,
                         include_decision_tables=include_decision_tables)


def _findings_for_inner(path: str, focus: str = "", audit_type: str = "", audit_category: str = "",
                       exclude_codes=None, include_decision_tables: bool = True) -> list:
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    # T-P0-01：手动模式必须优先于 L2/L3 点位补充，否则会先跑平台点位产生 unknown
    try:
        from .ctx import get_audit_mode as _gam0
        if (_gam0().get("mode") or "") == "manual":
            try:
                from . import rule as _rule_scope_m
                add_plan([{"point_id": r.get("code"), "title": r.get("name")}
                          for r in _rule_scope_m.effective_rule_rows()])
            except Exception:
                pass
            _manual = dynamic_rule_findings(path, audit_category, exclude_codes) or []
            for _f0 in _manual:
                _f0["origin"] = "customer_rule"
            return dedupe_sources(_manual) if os.environ.get("RULEPROOF_DEDUPE", "1") != "0" else _manual
    except Exception:
        logging.getLogger(__name__).debug("manual-first check skipped", exc_info=True)
    # 分层主线开关：L2=客户规则优先；L3=再加点位补充（空间可配 point_supplement）
    _layer = os.environ.get("RULEPROOF_AUDIT_LAYER", "")
    if not _layer:
        # 未显式指定时读空间配置；都没有则 legacy（保持旧行为）
        try:
            from . import ctx as _ctx_l0, workspaces as _w_l0
            _cur0 = _ctx_l0.get_context()
            _st0 = _w_l0.get_settings(_cur0.get("workspace_id") or "") if _cur0.get("workspace_id") else {}
            _layer = (_st0.get("audit_layer") or "legacy").upper() if isinstance(_st0.get("audit_layer"), str) else "legacy"
        except Exception:
            _layer = "legacy"
    if _layer in ("L2", "L3"):
        try:
            from . import lab_l2, lab_l3, ctx as _ctx_l, workspaces as _w_l
            _limit = int(os.environ.get("RULEPROOF_LAYER_RULES", "60") or 60)
            _cur_l = _ctx_l.get_context()
            _st_l = _w_l.get_settings(_cur_l.get("workspace_id") or "") if _cur_l.get("workspace_id") else {}
            _l3 = _layer == "L3" or bool(_st_l.get("point_supplement"))
            _plim = int(os.environ.get("RULEPROOF_L3_POINT_LIMIT", "60") or 60)
            _pids = _st_l.get("point_ids") or []
            _r = lab_l3.l3_judge(path, limit=_limit, point_limit=_plim, point_ids=_pids) if _l3 else lab_l2.l2_judge(path, limit=_limit)
            # 把 lab_l2/l3 内部 auditpoints 产生的批次绑到当前 run，否则报告门禁看不到 unknown
            try:
                from . import auditpoints as _apx
                _b = _apx.last_batch()
                if _b:
                    _BATCH_TLS.batches = list(getattr(_BATCH_TLS, "batches", [])) + [_b]
            except Exception:
                logging.getLogger(__name__).debug("layer batch bind skipped", exc_info=True)
            return _r.get("findings") or []
        except Exception as _e:
            logging.getLogger(__name__).error("分层主线失败：%s", _e, exc_info=True)
            if os.environ.get("RULEPROOF_LAYER_DEBUG") == "1":
                raise
            from ..safe import note as _note_l
            _note_l("分层主线", _e)
    # 模式一：仅客户规则（AI 辅助未勾选）——不跑平台点位/引擎，不产生 AI 噪声
    try:
        from .ctx import get_audit_mode as _gam2
        _mode2 = _gam2().get("mode") or ""
    except Exception:
        _mode2 = "manual"
    if _mode2 == "manual":
        _mf = []
        try:
            _mf = dynamic_rule_findings(path, audit_category, exclude_codes) or []
        except Exception as _e2:
            logging.getLogger(__name__).error("手动规则执行失败：%s", _e2, exc_info=True)
        if not _mf:
            try:
                _dg = _diag_rules(open(path, encoding="utf-8", errors="ignore").read())
                logging.getLogger(__name__).warning("手动模式 0 条产出，规则诊断=%s", _dg)
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
        for _f0 in _mf:
            # 手动模式 = 只执行客户规则，来源统一标记为客户规则（编码相似不代表平台点位）
            _f0["origin"] = "customer_rule"
        return dedupe_sources(_mf) if os.environ.get("RULEPROOF_DEDUPE", "1") != "0" else _mf
    out = []
    matched = False
    # 轮一：客户规则先执行，得到已覆盖点位（用于轮二残集）
    _rule_findings = []
    _covered = set()
    if os.environ.get("RULEPROOF_RESIDUAL_ROUNDS", "1") != "0":
        try:
            _rule_findings = dynamic_rule_findings(path, audit_category, exclude_codes) or []
            for _f in _rule_findings:
                _pid = _f.get("point_id") or _f.get("rule_code")
                if _pid:
                    _covered.add(_pid)
        except Exception as _e:
            from ..safe import note as _note_r
            _note_r("轮一客户规则", _e)
    # 统一入口：按「文件审核库」路由点位（不区分行业），点位决定执行哪些规则。
    # 具体行业能力全部来自场景包（supplement），核心代码不感知行业。
    try:
        routed, ok = _pack_pipeline(path, focus, audit_category, audit_type, _covered,
                                    include_decision_tables=include_decision_tables)
        if ok:
            # 第一轮之外的平台点位结果：并入后继续跑客户规则与事实层（不再早退）
            out.extend(routed or [])
            matched = True
    except Exception as e:  # 不再静默：记日志（严格模式下抛出）
        from ..safe import note
        note("库路由审核", e)
    if ext in ("xlsx", "xls"):
        try:
            # 只有匹配到黄金结构（有表头）才用专用引擎，否则走事实层
            doc = engine.parse_xlsx(path)
            pk = getattr(doc, "packaging", {}) or {}
            # 真正匹配黄金结构：有工序名称/产品名/版本 或 有半成品/总重
            has_structure = any(getattr(h, "process_name", None) or getattr(h, "product_name", None)
                                or getattr(h, "version", None) for h in (getattr(doc, "headers", {}) or {}).values())
            if has_structure or pk.get("half_products") or pk.get("design_total"):
                _eng_fs = engine.build_report(path, audit_category)["findings"]
                for _ef in _eng_fs:
                    # 引擎产出的确定性结论必须带 source_code，否则会被当作模型结论统计/合并
                    if not _ef.get("source_code"):
                        _ef["source_code"] = _ef.get("id") or _ef.get("rule_code") or ""
                out.extend(_eng_fs)
                matched = True
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 通用事实层：非黄金结构的任意文件（含 docx/pdf/xlsx）
    if not matched:
        try:
            from ..engine import factreview
            for f in factreview.review_document(path, audit_category)["findings"]:
                out.append({
                    "id": f["id"], "rule_code": f["id"], "level": f["level"],
                    "title": f["title"], "description": f["detail"], "suggestion": "",
                    "locations": [{"locator": os.path.basename(path),
                                   "quote": (f.get("evidence") or [""])[0], "sheet": ""}],
                })
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 已发布的数据库规则（含管理员新建/审批发布的规则）
    # 确定性补检：冷却类规则要求出现低温数值（语义判定易漏，用数值兜底）
    try:
        from . import rule_checks as _rc
        if os.environ.get("RULEPROOF_COOLING_CHECK", "0") != "1":
            raise RuntimeError("cooling check off")
        _gap = _rc.cooling_gap(path)
        if _gap.get("gap"):
            out.append({"id": "COOL-TEMP", "rule_code": "FOOD-A-3", "level": "critical",
                        "title": "冷却工序未标注目标温度",
                        "description": f"全文温度值 {_gap.get('temps')} 中无 ≤10℃ 的冷却温度",
                        "suggestion": "补充冷却目标温度（如 0-5℃ 或 ≤10℃）",
                        "locations": [{"locator": os.path.basename(path),
                                       "quote": (_gap.get("quote") or "")[:60], "sheet": ""}]})
    except Exception:
        logging.getLogger(__name__).debug('cooling check failed', exc_info=True)
    if os.environ.get("RULEPROOF_DEBUG_PIPE") == "1":
        logging.getLogger(__name__).warning("STAGE n=%s has_wl=%s", len(out),
            any("味林" in str(x.get("title")) for x in out))
    if _rule_findings:
        out.extend(_rule_findings)
    elif os.environ.get("RULEPROOF_RESIDUAL_ROUNDS", "1") == "0":
        out.extend(dynamic_rule_findings(path, audit_category, exclude_codes))
    # docx/pdf 通用文档检查
    if ext in ("docx", "pdf"):
        dr = docparse.parse_document(path)
        for i, c in enumerate(dr.checks, 1):
            state = c.get("state", "")
            level = "pass" if state == "满足" else "warning"
            if level == "pass":
                continue
            if os.environ.get("RULEPROOF_STRUCT_CHECKS", "0") != "1":
                continue  # 结构检查默认不进 findings（避免“排版检查冒充合规发现”）
            out.append({
                "id": f"DOC{i}", "rule_code": "DOC-GENERAL", "level": level,
                "title": c["name"], "description": c.get("detail", ""), "suggestion": "",
                "locations": [{"locator": os.path.basename(path), "quote": c.get("detail", ""), "sheet": ""}],
            })
    # 验证层：条款切分 → 证据四关 → 噪声预算（默认开启，可用环境变量关闭）
    try:
        # 默认关闭：实验性验证层须经 A/B 证明后再改默认，避免改变主链路既有行为
        if os.environ.get("RULEPROOF_EVIDENCE_GATE", "0") == "1":
            from . import structure as _st, evidence_gate as _eg
            _text = ""
            try:
                from ..engine import deepparse as _dp
                _text = _parsed_cached(path)["doc"].get("text", "")
            except Exception:
                _text = ""
            _clauses = _st.segment(_text) if _text else []
            if _clauses:
                _ok, _blocked = _eg.apply(out, _text, _clauses, _st.locate)
                # 质量层：拦高发误报（证据不足/ schema 不适用/ 归属错误）
                try:
                    from . import finding_quality as _fq
                    from . import auditpoints as _ap_q
                    _libq = _ap_q.load()
                    _pl = lambda pid: next((p for p in _libq.points if p.id == pid), None)
                    _ok2, _dropped = _fq.apply(_ok, _text, _pl)
                    for _d in _dropped:
                        _d["deferred"] = True
                    _blocked = list(_blocked) + list(_dropped)
                    _ok = _ok2
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
                for _b in _blocked:
                    _b["deferred"] = True
                out = _ok
    except Exception:
        logging.getLogger(__name__).debug('evidence gate ignored', exc_info=True)

    # 统一来源标注（出口处一次性完成，避免多条分支各自遗漏）
    for f in out:
        if f.get("origin"):
            continue
        code = str(f.get("rule_code") or "")
        if code.startswith("CUST-"):
            f["origin"] = "customer_rule"
        elif code.startswith("SED-"):
            f["origin"] = "sedimented_rule"
        elif code in ("SCHEMA", "DOC-GENERAL"):
            f["origin"] = "platform_rule"
        elif "-" in code and code[:1].isalpha() and code[1:2].isdigit():
            f["origin"] = "platform_point"
        else:
            f["origin"] = "platform_rule"
    # 翻转点位：同一文件同一点位两次结论相反 → 强制人工复核
    try:
        from . import pstates as _ps2
        _fl = set(_ps2.flips(os.path.basename(path)))
        if _fl:
            for f in out:
                if (f.get("point_id") or "") in _fl:
                    f["requires_manual"] = True
                    f["manual_reason"] = "该点位历史上判定翻转（pass↔fail），需人工确认"
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 误报抑制：客户判过误报的点位/规则，不再出现在结果里
    try:
        from .. import db as _db2
        _c2 = _db2.connect()
        _sup = {r[0] for r in _c2.execute("SELECT point_id FROM point_suppression")}
        if _sup:
            out = [f for f in out
                   if (f.get("point_id") or "") not in _sup and (f.get("rule_code") or "") not in _sup]
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    if os.environ.get("RULEPROOF_DEBUG_FINDINGS") == "1":
        _titles = [str(x.get("title"))[:16] for x in out]
        logging.getLogger(__name__).warning("PRE_DEDUPE n=%s %s", len(out), _titles)
    if os.environ.get("RULEPROOF_DEBUG_PIPE") == "1":
        _pre = [str(x.get("title"))[:14] for x in out]
        _res = dedupe_sources(out) if os.environ.get("RULEPROOF_DEDUPE", "1") != "0" else out
        _post = [str(x.get("title"))[:14] for x in _res]
        if len(_pre) != len(_post):
            logging.getLogger(__name__).warning("PIPE_DEDUPE %s -> %s | before=%s | after=%s",
                                                len(_pre), len(_post), _pre, _post)
        return _res
    if os.environ.get("RULEPROOF_DEBUG_PIPE") == "1":
        logging.getLogger(__name__).warning("STAGE n=%s has_wl=%s", len(out),
            any("味林" in str(x.get("title")) for x in out))
    for _f1 in out:
        if not _f1.get("origin"):
            _f1["origin"] = "platform_point" if (_f1.get("point_id") or _f1.get("source_code")) else "customer_rule"
    return dedupe_sources(out) if os.environ.get("RULEPROOF_DEDUPE", "1") != "0" else out


def dedupe_sources(out: list) -> list:
    """跨来源去重：同意保留一条（客户规则优先）；结论相反则都保留并标 engine_conflict。"""
    _prio = {"customer_rule": 0, "sedimented_rule": 1, "platform_point": 2, "platform_rule": 3}
    _uniq = {}
    for f in sorted(out, key=lambda x: _prio.get(x.get("origin"), 9)):
        loc = (f.get("locations") or [{}])[0] or {}
        _q = str(loc.get("quote") or "").strip()
        # 引文为空时不做跨来源合并（否则同一点位的不同问题会互相吞掉）
        key = ((str(f.get("title") or "").strip(), str(f.get("id") or "")) if not _q
               else (str(f.get("title") or "").strip()[:24], _q[:30]))
        if os.environ.get("RULEPROOF_DEBUG_PIPE") == "1" and ("味林" in str(f.get("title")) or "酱油饭" in str(f.get("title"))):
            logging.getLogger(__name__).warning("WL_KEY title=%s key=%s", str(f.get("title"))[:18], str(key)[:80])
        if key in _uniq:
            _prev = _uniq[key]
            logging.getLogger(__name__).warning("SRC_DEDUPE [%s] <= [%s]",
                                                str(_prev.get("title"))[:22], str(f.get("title"))[:22])
            if str(_prev.get("level")) != str(f.get("level")) or str(_prev.get("state")) != str(f.get("state")):
                _prev["engine_conflict"] = True
                f["engine_conflict"] = True
                _uniq[(key[0], key[1], f.get("origin") or "", str(f.get("level")))] = f
                continue
            continue
        _uniq[key] = f
    return list(_uniq.values())


def semantic_enrich(collected: list) -> list:
    """R4 语义复核：统一走 agent-judge；低置信度由 JEV 弃权转人工。

    T-115：工作空间显式关闭 ``mod_agents`` 时不再执行 agent-judge（标记“模块已关闭”，
    不伪造执行失败/不落 confidence）；关闭 ``mod_jev`` 时不做低置信弃权判定。
    """
    _agents_off = _module_off("mod_agents")
    _jev_off = _module_off("mod_jev")
    for f in collected:
        if f.get("rclass") != "R4":
            continue
        if _agents_off:
            f["semantic_review"] = {"state": "模块已关闭", "confidence": None,
                                    "rationale": "工作空间关闭智能体模块（mod_agents=false），"
                                                 "未执行 agent-judge",
                                    "provider": "agent-judge",
                                    "module_disabled": "mod_agents"}
            continue
        evidence = [e.get("quote", "") for e in f.get("evidence", []) if e.get("quote")]
        text = "\n".join(evidence)
        point = {"id": str(f.get("code") or f.get("id") or "R4"), "name": str(f.get("title") or "")[:80],
                 "criterion": str(f.get("summary") or f.get("title") or "")[:600],
                 "required_evidence": "原文逐字证据", "level": "R4"}
        try:
            from . import agents as _ag
            rr = _ag.run_agent("agent-judge", {"text": text, "points": [point]})
            if rr.get("status") != "ok":
                raise RuntimeError(str((rr.get("result") or {}).get("error") or "agent-judge 失败"))
            item = ((rr.get("result") or {}).get("results") or [{}])[0]
            state_map = {"不满足": "不成立", "满足": "成立", "证据不足": "需人工",
                         "未知": "需人工", "弃权(需人工)": "需人工"}
            conf = item.get("confidence")
            f["semantic_review"] = {"state": state_map.get(str(item.get("state") or ""), "需人工"),
                                    "confidence": conf, "rationale": str(item.get("rationale") or ""),
                                    "provider": "agent-judge"}
            if conf is not None and not _jev_off:
                from . import calibration
                sel = calibration.selective(conf)
                if sel.get("abstain"):
                    f["semantic_review"]["state"] = "需人工（低置信弃权）"
                    f["semantic_review"]["abstained"] = True
            if conf is not None:
                R.findings.update(f["id"], confidence=conf)
        except Exception as e:  # noqa
            f["semantic_review"] = {"state": "执行失败", "confidence": None,
                                    "rationale": str(e)[:200], "provider": "agent-judge"}
            try:
                from . import notify  # noqa
                notify.notify_admins("system.llm_fail", "语义判断调用失败", f"{type(e).__name__}: {str(e)[:80]}")
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
    return collected



def run_review(case_name: str, doc_paths: list, points_path: str = "",
               pack_version: str = "food.process.v1", model_version: str = "det-0.1",
               semantic: bool = False, created_by: str = "") -> dict:
    """兼容旧调用（不是产品入口）：只做参数适配，实现全部在 review_legacy。

    唯一产品入口是 ``project.audit`` 的 manual / assisted 两模式；本函数保留旧
    一次性调用的兼容语义，显式转发 legacy=True，不在此定义第二套审核逻辑。
    """
    assert_entry_writable(created_by, entry="review")
    from .review_legacy import run_review as _legacy
    out = _legacy(case_name, doc_paths, points_path, pack_version, model_version,
                  semantic, created_by, legacy=True)
    return normalize_result(out, entry="review", pipeline="legacy", mode="legacy",
                            case_id=str((out or {}).get("case_id") or ""))


def my_cases(created_by: str) -> list:
    """某用户创建的案例（审核员「我的工作台」），附待复核/已复核计数。"""
    cases = R.cases.list("created_by=?", (created_by,), order="created_at DESC")
    out = []
    for c in cases:
        fs = R.findings.by_case(c["id"])
        pending = sum(1 for f in fs if f["status"] == "pending")
        decided = len(fs) - pending
        _cst = str(c.get("status") or "")
        if _cst in ("auditing", "reviewing"):
            status = "审核中"
        elif _cst == "audit_failed":
            status = "审核失败"
        elif not fs:
            status = "待审核"
        elif pending:
            status = "待复核"
        else:
            status = "已确认"
        out.append({**c, "pending_count": pending, "decided_count": decided,
                    "total_count": len(fs), "status_label": status})
    return out


def _llm_traces(run_id: str) -> list:
    if not run_id:
        return []
    try:
        with db.session() as c:
            rows = c.execute("SELECT * FROM llm_trace WHERE run_id=? ORDER BY created_at", (run_id,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["point_ids"] = __import__("json").loads(d.get("point_ids") or "[]")
            except Exception:
                d["point_ids"] = []
            out.append(d)
        return out
    except Exception:
        return []


def _orchestration(run_id: str) -> list:
    """读取一次审核运行的编排轨迹（只读归一，不新增计算）。

    run.trace_json 有两种历史格式：
      - 新格式（project.audit 落库）：整个轨迹对象 {"orchestration": [...], "dag": [...]}
      - 旧格式/空占位：裸 orchestration 列表（seed 演示行为 "[]"）
    读取侧统一返回 orchestration 列表，避免项目详情接口把 dict 下发给前端
    （E-10：前端拿不到列表就无法展示「语义路径未执行/降级」）。
    """
    if not run_id:
        return []
    try:
        row = R.audit_runs.get(run_id) or {}
        data = __import__("json").loads(row.get("trace_json") or "[]")
        if isinstance(data, dict):
            return list(data.get("orchestration") or [])
        return list(data) if isinstance(data, list) else []
    except Exception:
        return []


def _report_stale_count(case_id: str, fs: list) -> int:
    """报告 stale 口径：与 stats scope=report 对齐；stats 不可用时回退 fs 标记。"""
    try:
        from . import stats as _stats
        return int(_stats.stale_count(case_id, scope="report"))
    except Exception:
        return sum(1 for f in fs if f.get("point_stale"))


# ---------------------------------------------------------------------------
# 报告口径：执行失败 / 不满足 / 未发现 / unknown 四类分离
# ---------------------------------------------------------------------------
CATEGORY_LABELS = {
    "execution_failed": "执行失败",
    "nonconformity": "不满足",
    "not_found": "未发现",
    "unknown": "unknown",
    "not_applicable": "不适用",
    "not_run": "未审核",
}
EXECUTION_LABELS = {
    "failed": "执行失败",
    "partial": "部分执行",
    "completed": "执行完成",
    "not_run": "未执行",
}


def _active_result_meta(case_id: str) -> dict:
    """当前 active 的 manifest 结果元数据：execution / conclusion / d5。"""
    out = {}
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT mr.id, mr.execution, mr.conclusion, mr.d5_json, mr.review_status "
                "FROM manifest_active ma JOIN manifest_result mr ON mr.id=ma.result_id "
                "WHERE ma.case_id=? ORDER BY mr.rule_code,mr.object_id", (case_id,))]
            if not rows:
                ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                               "ORDER BY created_at DESC LIMIT 1", (case_id,)).fetchone()
                mid = str((ar["manifest_id"] if ar else "") or "")
                if mid:
                    rows = [dict(r) for r in c.execute(
                        "SELECT id, execution, conclusion, d5_json, review_status "
                        "FROM manifest_result WHERE manifest_id=? ORDER BY rule_code,object_id",
                        (mid,))]
        for row in rows:
            try:
                d5 = json.loads(row.pop("d5_json", "") or "{}")
            except Exception:
                d5 = {}
            _d5s = str((d5 or {}).get("status") or "")
            row["d5_status"] = (_audit_ledger.normalize_state(_d5s) if _d5s else "")
            out[str(row.get("id") or "")] = row
    except Exception:
        logging.getLogger(__name__).debug("active result meta skipped", exc_info=True)
    return out


def _report_categories(case_id: str, case: dict, findings: list,
                       persisted: dict = None) -> dict:
    """把当前报告窗口拆成四类互斥口径。

    - 执行失败：审核整体失败、规则执行 blocked/failed、以及因执行失败而 unknown 的项
    - 不满足：规则明确判不满足的项（含 manifest 台账失败与未被台账覆盖的 finding）
    - 未发现：已执行且判满足的项（pass），即“查过、没发现问题”
    - unknown：已执行但证据不足/无法判断/缺失，不能算通过，也不能算不满足
    """
    case = case or {}
    records = []
    try:
        records = ((_audit_ledger.summary(case_id) or {}).get("records") or [])
    except Exception:
        logging.getLogger(__name__).debug("report taxonomy ledger skipped", exc_info=True)
        records = []
    meta = _active_result_meta(case_id)
    persisted = persisted or {}

    execution_failed, nonconformity, not_found, unknown = [], [], [], []
    na_items = []
    nonconformity_by_key = {}
    nonconformity_by_result = {}
    nonconformity_by_rule = {}

    def _pack(rec: dict, source: str) -> dict:
        rec = rec or {}
        rid = str(rec.get("result_id") or "")
        m = meta.get(rid) or {}
        return {"kind": source, "source": rec.get("source") or source,
                "object_id": str(rec.get("object_id") or ""),
                "object": str(rec.get("object") or ""),
                "rule_code": str(rec.get("code") or ""),
                "sub_id": str(rec.get("sub_id") or ""),
                # M1：台账已是归一状态（audit_ledger.normalize_state 为唯一事实源），
                # 这里再做一次幂等归一，禁止只认字面 "na" 而把 not_applicable 折成 unknown。
                "state": _audit_ledger.normalize_state(rec.get("state") or "unknown"),
                "conclusion": str(m.get("conclusion") or ""),
                "execution": str(m.get("execution") or ""),
                "d5_status": str(m.get("d5_status") or ""),
                "result_id": rid,
                "review_status": str(m.get("review_status") or ""),
                "title": str(rec.get("title") or "")}

    # F-08：全部规则不适用时，同一规则在平台点位侧的重复 unknown 记录不得改判口径
    _na_codes = {str((rec or {}).get("code") or "")
                 for rec in records
                 if _audit_ledger.is_na_state((rec or {}).get("state"))
                 and str((rec or {}).get("source") or "") == "manifest"}
    for rec in records:
        if (str((rec or {}).get("source") or "") == "platform_point"
                and _audit_ledger.normalize_state((rec or {}).get("state")) in
                ("unknown", "insufficient", "missing")
                and str((rec or {}).get("code") or "") in _na_codes):
            continue
        item = _pack(rec, "rule")
        state = item["state"]
        d5 = item["d5_status"]
        execution = item["execution"]
        conclusion = item["conclusion"]
        failed_execution = (state in ("failed", "blocked")
                            or conclusion == "执行失败"
                            or execution in ("failed", "blocked")
                            or d5 in ("failed", "blocked"))
        if state == "fail":
            nonconformity.append(item)
            nonconformity_by_key[(item["object_id"], item["rule_code"], item["sub_id"])] = item
            if item["result_id"]:
                nonconformity_by_result[item["result_id"]] = item
            nonconformity_by_rule.setdefault(item["rule_code"], []).append(item)
        elif state == "pass":
            not_found.append(item)
        elif state == "na":
            # 不适用既不是通过也不是 unknown，不进入四类计数；
            # 全 na 项目单独记 not_applicable 口径（F-08：不得显示“未发现/通过”）
            na_items.append(item)
            continue
        elif state in ("unknown", "insufficient", "missing"):
            if failed_execution:
                execution_failed.append({**item, "reason": conclusion or d5 or "执行失败"})
            else:
                unknown.append(item)
        elif failed_execution:
            execution_failed.append({**item, "reason": conclusion or d5 or "执行失败"})
        else:
            unknown.append(item)

    # DU-08：finding 与台账同 result 的 insufficient/unknown/missing 去重（不重复计数）
    _unknown_by_result = {str(x.get("result_id") or ""): x
                          for x in unknown if x.get("result_id")}
    pending = confirmed = 0
    for f in findings or []:
        fid = str(f.get("id") or "")
        rid = str(f.get("manifest_result_id") or "")
        if not rid and fid.startswith("mfc-"):
            # result id 自身含连字符（mres-xxxx），按 active 结果 ID 精确匹配
            rid = next((x for x in meta if x and fid.startswith(f"mfc-{x}-")), "")
        key = (str(f.get("object_id") or ""), str(f.get("rule_id") or ""),
               str(f.get("subrequirement_id") or ""))
        covered = nonconformity_by_key.get(key)
        if covered is None and rid:
            covered = nonconformity_by_result.get(rid)
        if covered is None and key[1]:
            # 旧 finding 可能没有 object_id/manifest_result_id：同一规则仅一条失败时归并
            candidates = nonconformity_by_rule.get(key[1]) or []
            if len(candidates) == 1:
                covered = candidates[0]
        status = str(f.get("status") or "pending")
        # P0-证据：引文未逐字命中被降级的 finding 不得计成“不满足/已确认”，归 unknown 待人工
        _ev_blocked = (status == "need_evidence"
                       and _EVIDENCE_GATE_MARK in str(f.get("summary") or ""))
        if _ev_blocked:
            if covered is not None:
                covered["review_status"] = "need_evidence"
                covered["evidence_gate"] = "downgraded"
                covered["finding_id"] = fid
            else:
                unknown.append({"kind": "finding", "source": "finding",
                                "object_id": key[0], "object": "", "rule_code": key[1],
                                "sub_id": key[2], "state": "insufficient",
                                "conclusion": "证据不足", "execution": "completed",
                                "d5_status": "insufficient", "result_id": rid,
                                "review_status": "need_evidence",
                                "severity": str(f.get("severity") or ""),
                                "evidence_gate": "downgraded",
                                "title": str(f.get("title") or ""), "finding_id": fid})
            continue
        # DU-08/红线 5：finding 只物化 fail 与 insufficient；读取侧必须按 finding.state
        # 分类，不得把 insufficient/unknown/missing 重算成 fail（否则无证据也会算不满足）。
        _fstate = _audit_ledger.normalize_state(f.get("state") or "fail")
        if _fstate in ("insufficient", "unknown", "missing"):
            if covered is not None:
                # 台账已判 fail 但 finding 侧证据不足：交给下方“证据门禁降级”逻辑
                # 从“不满足”口径移入 unknown（不在两处各计一次）。
                covered["review_status"] = "need_evidence"
                covered["evidence_gate"] = "downgraded"
                covered["finding_id"] = fid
            else:
                _u = {"kind": "finding", "source": "finding",
                      "object_id": key[0], "object": "", "rule_code": key[1],
                      "sub_id": key[2], "state": _fstate,
                      "conclusion": ("证据不足" if _fstate == "insufficient"
                                     else ("结果缺失" if _fstate == "missing" else "无法判断")),
                      "execution": "completed", "d5_status": _fstate, "result_id": rid,
                      "review_status": status,
                      "severity": str(f.get("severity") or ""),
                      "title": str(f.get("title") or ""), "finding_id": fid}
                _dup = _unknown_by_result.get(rid) if rid else None
                if _dup is not None:
                    _dup["finding_id"] = fid
                    _dup["review_status"] = status
                else:
                    unknown.append(_u)
            continue
        if covered is not None:
            # 台账已计过这一条：只补人工复核状态，不重复计数
            covered["finding_id"] = fid
            covered["review_status"] = status
            covered["severity"] = str(f.get("severity") or "")
            covered["title"] = covered.get("title") or str(f.get("title") or "")
        else:
            item = {"kind": "finding", "source": "finding",
                    "object_id": key[0], "object": "", "rule_code": key[1],
                    "sub_id": key[2], "state": "fail",
                    "conclusion": "不满足", "execution": "completed",
                    "d5_status": "fail", "result_id": rid,
                    "review_status": status,
                    "severity": str(f.get("severity") or ""),
                    "title": str(f.get("title") or ""), "finding_id": fid}
            nonconformity.append(item)
        if status == "false_positive":
            # 人工判误报：对应台账失败不再计入“不满足”，但仍保留复核痕迹
            if covered is not None:
                covered["review_status"] = "false_positive"
                covered["finding_id"] = fid
            continue
        if status == "pending":
            pending += 1
        elif status != "false_positive":
            confirmed += 1

    nonconformity = [x for x in nonconformity
                     if str(x.get("review_status") or "") != "false_positive"]
    # 证据门禁降级的台账失败行不留在“不满足”口径，转 unknown 待人工核验
    _ev_downgraded_rows = [x for x in nonconformity
                           if str(x.get("review_status") or "") == "need_evidence"]
    if _ev_downgraded_rows:
        nonconformity = [x for x in nonconformity if x not in _ev_downgraded_rows]
        for _x in _ev_downgraded_rows:
            unknown.append({**_x, "state": "insufficient", "conclusion": "证据不足",
                            "d5_status": "insufficient", "evidence_gate": "downgraded"})

    case_status = str(case.get("status") or "").lower()
    case_failed = case_status in ("audit_failed", "failed", "error")
    if case_failed:
        execution_failed.insert(0, {
            "kind": "case", "source": "case", "object_id": "", "object": "",
            "rule_code": "", "sub_id": "", "state": "failed",
            "conclusion": "执行失败", "execution": "failed", "d5_status": "failed",
            "result_id": "", "review_status": "", "reason": "审核执行失败",
            "title": "审核执行失败"})
    _no_applicable_rules = bool(persisted) and not records and \
        int(persisted.get("manifest_items") or 0) == 0
    if not str(case.get("last_run_id") or "").strip() and not records:
        execution_state = "not_run" if not execution_failed else "failed"
    elif _no_applicable_rules:
        # F-08：冻结清单为空 = 没有任何适用规则真正执行，不能算“执行完成/通过”
        execution_state = "not_run" if not execution_failed else "failed"
    elif execution_failed:
        execution_state = "failed"
    elif any(str(x.get("execution") or "") == "incomplete" for x in meta.values()) or unknown:
        execution_state = "partial"
    else:
        execution_state = "completed"

    if execution_failed:
        category = "execution_failed"
    elif unknown:
        category = "unknown"
    elif nonconformity:
        category = "nonconformity"
    elif not_found:
        category = "not_found"
    elif na_items or _no_applicable_rules:
        # F-08：全 na / 空清单 显示“不适用”，不得显示“未发现/通过”
        category = "not_applicable"
    elif execution_state == "not_run":
        category = "not_run"
    else:
        category = "not_found"

    classes = {}
    try:
        from . import pstates as _ps
        _cls = _ps.unknown_classes(case_id) or {}
        for label, ids in _cls.items():
            if ids:
                classes[str(label)] = len(ids)
    except Exception:
        logging.getLogger(__name__).debug("report taxonomy unknown classes skipped", exc_info=True)

    # DU-27（红线 4）：报告顶层四类口径保留 fail-closed 的 unknown 聚合（门禁靠它阻断），
    # 但**五态计数必须分列**（pass/fail/na/insufficient/unknown/missing），
    # insufficient/missing 不得只以聚合数出现（不得混入 unknown 一个数字了事）。
    _unknown_state_counts = {"insufficient": 0, "unknown": 0, "missing": 0}
    _unknown_state_items = {"insufficient": [], "unknown": [], "missing": []}
    for _it in unknown:
        _st = _audit_ledger.normalize_state((_it or {}).get("state") or "unknown")
        _bucket = _st if _st in _unknown_state_counts else "unknown"
        _unknown_state_counts[_bucket] += 1
        _unknown_state_items[_bucket].append(_it)

    return {
        "execution": {"state": execution_state,
                      "label": EXECUTION_LABELS.get(execution_state, execution_state),
                      "failed_count": len(execution_failed),
                      "items": execution_failed[:100]},
        "nonconformity": {"count": len(nonconformity),
                          "pending_count": pending,
                          "confirmed_count": confirmed,
                          "items": nonconformity[:200]},
        "not_found": {"count": len(not_found), "items": not_found[:200]},
        "unknown": {"count": len(unknown), "classes": classes,
                    "items": unknown[:200],
                    # DU-27：unknown 聚合桶内的分态计数/明细（insufficient/missing 单列）
                    "state_counts": dict(_unknown_state_counts),
                    "state_items": {k: v[:100] for k, v in _unknown_state_items.items()}},
        "not_applicable": {"count": len(na_items), "items": na_items[:200]},
        # DU-27/红线 4：五态分列（+执行失败）。pass=未发现、fail=不满足、na=不适用，
        # 与四类口径同源；unknown 聚合 = insufficient + unknown + missing（fail-closed）。
        "state_counts": {
            "pass": len(not_found),
            "fail": len(nonconformity),
            "na": len(na_items),
            "insufficient": _unknown_state_counts["insufficient"],
            "unknown": _unknown_state_counts["unknown"],
            "missing": _unknown_state_counts["missing"],
            "execution_failed": len(execution_failed),
        },
        "total": len(execution_failed) + len(nonconformity) + len(not_found) + len(unknown),
        "category": category,
        "label": CATEGORY_LABELS.get(category, category),
        "note": "四类互斥：执行失败=没跑成；不满足=跑成且判失败；未发现=跑成且判满足；"
                "unknown=跑成但证据不足/无法判断/结果缺失，不得算通过。"
                "五态分列（红线 4）：pass/fail/na 见 state_counts 与四类计数同源；"
                "unknown 聚合桶内 insufficient/missing/unknown 分态计数见 "
                "unknown.state_counts，不得只报聚合数。",
    }


def case_report(case_id: str, actor: str = "", role: str = "") -> dict:
    access = None
    if str(actor or "").strip() or str(role or "").strip():
        access = authorize_case(case_id, "view", actor, role)
        if not access.get("ok"):
            # 只读/归属校验失败：与“项目不存在”同一空结果，不泄露存在性
            return {}
    c = R.cases.get(case_id)
    if not c:
        return {}
    # P0-证据：读取/报告渲染前只做**只读预演**的 fail 引文逐字核验（persist=False），
    # 不落库改写 finding——否则「出报告前/后两套准确率口径」，且读取有副作用、非幂等。
    # 真正降级收敛到唯一入口 report.generate（正式生成报告时显式调用一次，幂等）。
    _evidence_gate_report = {"checked": 0, "verified": 0, "downgraded": [], "skipped_legacy": 0}
    try:
        _evidence_gate_report = enforce_evidence_quotes(case_id, persist=False)
    except Exception:
        logging.getLogger(__name__).warning("evidence quote enforcement skipped", exc_info=True)
    # 只看最近一次审核批次（历史批次保留在库，不删除）
    rid = c.get("last_run_id") or ""
    _all_fs = [f for f in R.findings.by_case(case_id) if (f.get("status") or "") != "superseded"]
    fs = list(_all_fs)
    if rid:
        fs = [f for f in _all_fs if (f.get("run_id") or "") == rid or (f.get("engine") or "") == "manual"]
        # 历史轮次里仍未处理的发现不能从工作台消失：重跑产生新 run 后仍要可见
        _seen = {f.get("id") for f in fs}
        for f in _all_fs:
            if f.get("id") not in _seen and (f.get("status") or "pending") == "pending":
                f["_historical"] = True
                fs.append(f)
    _cur_plib = ""
    try:
        from . import point_confirm as _pcv
        _cur_plib = _pcv.library_version()
    except Exception:
        _cur_plib = ""
    for _f in fs:
        _pv = str(_f.get("point_library_version") or "")
        if _pv and _cur_plib and _pv != _cur_plib:
            _f["point_stale"] = True
            _f["point_stale_reason"] = "点位库/判据已更新，该结果基于旧版本"
    critical = [f for f in fs if f["severity"] == "critical"]
    warning = [f for f in fs if f["severity"] == "warning"]
    suspected = [f for f in fs if f["severity"] == "suspected"]
    # 点位名/分类回填：让 UI 显示"依据 = 点位名"而不是编号
    try:
        from . import auditpoints as _ap
        _lib = _ap.load()
        _pts = {p["id"]: p for p in _lib.points_dict()} if hasattr(_lib, "points_dict") else {}
        if not _pts:
            _pts = {p.id: {"name": p.name, "category": p.category} for p in _lib.points}
        for f in fs:
            pid = f.get("rule_id") or f.get("rule_code") or f.get("code") or ""
            if pid in _pts:
                f["rule_name"] = _pts[pid].get("name", "")
                f["category"] = _pts[pid].get("category", "")
                f["point_id"] = pid
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # A5：结论分层（确定性规则 / 语义判定 / 点位补查）
    _rule_slots, _lib_ids = {}, set()
    try:
        for _r in R.rules.list():
            _v = R.rules.published_version(_r["id"]) or {}
            try:
                _rule_slots[_r["code"]] = json.loads(_v.get("slots_json") or "{}")
            except Exception:
                _rule_slots[_r["code"]] = {}
        from . import auditpoints as _ap5
        _lib_ids = {p.id for p in _ap5.load().points}
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)

    def _layer_of(f):
        rid = f.get("rule_id") or ""
        eng = str(f.get("engine") or "")
        if rid in _lib_ids or eng.startswith("platform"):
            return "point", "点位补查"
        slots = _rule_slots.get(rid)
        if slots:
            try:
                from .rule_ir import classify_executability
                lv = classify_executability(slots)["level"]
                if lv == "deterministic":
                    return "deterministic", "确定性规则"
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
        if slots:
            return "semantic", "语义判定"
        return ("semantic", "语义判定") if ("model" in eng or "llm" in eng) else ("deterministic", "确定性规则")

    # 附证据锚点 + 规则元数据（rules_meta 单一事实源）+ 历史误报负例
    from ..engine.rules_meta import RULE_META
    from . import evolution
    for f in fs:
        f["rule_code"] = f["rule_id"]
        m = RULE_META.get(f["rule_id"])
        if m:
            f["rule_name"] = m["name"]
            f["category"] = m["category"]
            f["rclass"] = m["rclass"]
            f["criterion"] = m.get("condition", "")
        else:
            # 事实层规则（F-*）补类型与依据（映射表在场景包里维护）
            code = f.get("rule_id") or ""
            if code.startswith("F-"):
                from ..engine import audit_category as _acx
                cat = _acx.FACT_RULE_LABEL.get(code, "通用检查")
                f["category"] = f.get("category") or cat
                f["criterion"] = f.get("criterion") or code.replace("F-", "") + " 判定"
                f["rule_name"] = f.get("rule_name") or code
        from ..severity import label as _sev_label
        f["severity_label"] = _sev_label(f.get("severity"))
        f["historical_fp"] = evolution.historical_false_positive(f["rule_id"], f["title"])
        f["layer"], f["layer_label"] = _layer_of(f)
        evs = R.evidences.list("finding_id=?", (f["id"],))
        anchors = []
        for e in evs:
            a = R.anchors.get(e["anchor_id"])
            if not a:
                # 历史数据可能只有 evidence 没有 anchor：读侧补文件级定位，不丢证据。
                _d0 = R.documents.get(e.get("document_id") or "") or {}
                a = {"id": "", "document_id": e.get("document_id") or "",
                     "locator": (str(_d0.get("filename") or _d0.get("name") or "").strip()
                                 or str(f.get("title") or "文档")[:40]),
                     "quote": e.get("excerpt") or "", "sheet": ""}
            if a:
                a = dict(a)
                if not str(a.get("locator") or "").strip():
                    _d = R.documents.get(a.get("document_id") or "") or {}
                    a["locator"] = (str(_d.get("filename") or _d.get("name") or "").strip()
                                    or str(f.get("title") or "文档")[:40])
                anchors.append(a)
        if not anchors:
            # 发现本身没有证据行时，读侧至少给文件级定位，不能把空定位留给 UI。
            f["evidence"] = [{"locator": str(f.get("rule_name") or f.get("title") or "文档")[:40],
                              "quote": "", "sheet": ""}]
        else:
            f["evidence"] = anchors
    # P0-证据：引文未逐字命中被降级的 finding（need_evidence + 门禁标记）单独计数
    _ev_need = [f for f in fs
                if str(f.get("status") or "") == "need_evidence"
                and _EVIDENCE_GATE_MARK in str(f.get("summary") or "")]
    # P0-稳定性：跨重审 N=3 投票/翻转 marker（读取口径；落 marker 由 report_gate 负责）
    _stability = {}
    try:
        from . import manifest_exec as _mex_st
        _stability = _mex_st.stability_votes(case_id, persist=False)
    except Exception:
        logging.getLogger(__name__).debug("stability votes read skipped", exc_info=True)
    confirmed = [f for f in fs if f.get("status") == "confirmed"]
    pending = [f for f in fs if f.get("status") == "pending"]
    confirmed_critical = [f for f in confirmed if f["severity"] == "critical"]
    confirmed_warning = [f for f in confirmed if f["severity"] == "warning"]
    confirmed_suspected = [f for f in confirmed if f["severity"] in ("info", "suspected")]
    _abstain = _unknown = _missing = 0
    try:
        from . import audit_ledger as _alg
        _lg = _alg.summary(case_id)
        _unknown = int(_lg.get("state_unknown_count", 0) or 0)
        _abstain = int(_lg.get("state_insufficient_count", 0) or 0)
        _missing = int(_lg.get("state_missing_count", 0) or 0)
    except Exception:
        logging.getLogger(__name__).debug('unified ledger skipped', exc_info=True)
    _persisted = _persisted_audit_summary(case_id)
    _persisted_all_na = bool(_persisted.get("all_na"))
    if _persisted_all_na:
        # F-08：全部规则不适用时，台账同规则的平台点位重复 unknown 不改判口径
        _abstain = _unknown = _missing = 0
    # F-08：审核落库结论（含 fail-closed 的 待复核/不适用）是读取/报告口径的第一优先，
    # 不得在无 finding 时用计数反推成“通过”。
    _conclusion_source = "derived"
    # 结论：以「人工确认」的问题为准（人工意见优先于 AI）
    if str(c.get("status") or "") == "audit_failed":
        conclusion = "审核失败"
        _conclusion_source = "case_status"
    elif not str(c.get("last_run_id") or "").strip() and not fs:
        conclusion = "未审核"
        _conclusion_source = "not_run"
    elif pending:
        conclusion = "待复核"
    elif _ev_need:
        # 引文未逐字命中 → 人工复核（不能以“不通过/通过”签发）
        conclusion = "待复核（证据未核验）"
    elif confirmed_critical:
        conclusion = "不通过"
    elif confirmed_warning:
        conclusion = "有条件通过"
    elif confirmed_suspected:
        conclusion = "建议关注"
    elif _abstain or _unknown or _missing:
        conclusion = "待复核（含弃权/未执行）"
    elif not fs and str(_persisted.get("status") or "") not in ("", "通过"):
        # 无任何 finding 时只用落库结论，禁止重算为“通过”（空清单/全不适用）
        conclusion = str(_persisted.get("status"))
        _conclusion_source = "persisted"
    else:
        conclusion = "通过"
    from . import project as _proj
    _runs = _proj.runs(case_id)
    _layers = {"deterministic": 0, "semantic": 0, "point": 0}
    for _f in fs:
        _layers[_f.get("layer") or "deterministic"] = _layers.get(_f.get("layer") or "deterministic", 0) + 1
    categories = _report_categories(case_id, c, fs, _persisted)
    summary = {
        "status": conclusion, "conclusion": conclusion,
        "critical_count": len(critical), "warning_count": len(warning),
        "suspected_count": len(suspected), "total": len(fs),
        # DU-27（2026-11-25/红线 4）：unknown 聚合（unknown+insufficient+missing）保留
        # 为旧口径（fail-closed 门禁读它）；三态必须分列，不得只给聚合数。
        "abstain_count": _abstain + _unknown + _missing, "unknown_count": _unknown + _missing,
        "insufficient_count": _abstain,       # 纯证据不足（原 state_insufficient_count）
        "unknown_state_count": _unknown,      # 纯无法判断（不含 missing）
        "missing_count": _missing,            # 应审未执行/结果缺失
        "state_counts": dict(categories.get("state_counts") or {}),
        "pending_count": len(pending),
        "reviewed_count": len(fs) - len(pending),
        "confirmed_critical": len(confirmed_critical),
        "confirmed_warning": len(confirmed_warning),
        "confirmed_suspected": len(confirmed_suspected),
        "point_stale_count": _report_stale_count(case_id, fs),
        "all_reviewed": len(pending) == 0 and not _ev_need,
        # P0-证据/稳定性：证据未核验与跨重审翻转必须对上层可见（门禁另有硬阻断）
        "evidence_gate_need_review": len(_ev_need),
        "evidence_gate_downgraded": len(_ev_need),
        "stability_n": int(_stability.get("n") or 0),
        "stability_runs": int(_stability.get("runs_count") or 0),
        "stability_insufficient_runs": int(_stability.get("insufficient_runs") or 0),
        "stability_vote_recorded": bool(_stability.get("vote_recorded")),
        "stability_stable": bool(_stability.get("stable")),
        "stability_flips": len(_stability.get("flips") or []),
        "stability_key_flips": len(_stability.get("key_flips") or []),
        # F-08：把落库判定与清单口径暴露给读取/报告，避免上层再按 findings 反推
        "persisted_status": str(_persisted.get("status") or ""),
        "conclusion_source": _conclusion_source,
        "manifest_items": (int(_persisted.get("manifest_items"))
                           if _persisted.get("manifest_items") is not None else None),
        "na_count": int((categories.get("not_applicable") or {}).get("count") or 0),
        # 四类报告口径：旧 status 保持兼容，新增字段显式区分
        "report_category": categories.get("category") or "",
        "report_category_label": categories.get("label") or "",
        "report_verdict": categories.get("label") or "",
        "verdict": categories.get("label") or "",
        "category": categories.get("category") or "",
        "category_label": categories.get("label") or "",
        "category_counts": {
            "execution_failed": int((categories.get("execution") or {}).get("failed_count") or 0),
            "nonconformity": int((categories.get("nonconformity") or {}).get("count") or 0),
            "not_found": int((categories.get("not_found") or {}).get("count") or 0),
            "unknown": int((categories.get("unknown") or {}).get("count") or 0),
        },
        "execution_status": (categories.get("execution") or {}).get("label") or "",
        "execution_failed_count": int((categories.get("execution") or {}).get("failed_count") or 0),
        "nonconformity_count": int((categories.get("nonconformity") or {}).get("count") or 0),
        "not_found_count": int((categories.get("not_found") or {}).get("count") or 0),
        "unknown_category_count": int((categories.get("unknown") or {}).get("count") or 0),
    }
    out = {
        "case": c,
        "runs": {"count": len(_runs), "current": _runs[0] if _runs else None},
        "layers": _layers,
        "summary": summary,
        "categories": categories,
        "report_category": categories.get("category") or "",
        "report_category_label": categories.get("label") or "",
        "findings": fs,
        "documents": R.cases.documents(case_id),
        "orchestration": _orchestration(rid),
        "llm_traces": _llm_traces(rid),
        # P0-证据：本轮证据门禁结果（降级条目）
        "evidence_gate": {
            "checked": int(_evidence_gate_report.get("checked") or 0),
            "verified": int(_evidence_gate_report.get("verified") or 0),
            "downgraded": list(_evidence_gate_report.get("downgraded") or []),
            "need_review": len(_ev_need),
            "detail": _EVIDENCE_GATE_DETAIL if _ev_need else "",
        },
        # P0-稳定性：跨重审 N=3 投票/翻转 marker（报告与门禁同源）
        "stability": {
            "n": int(_stability.get("n") or 0),
            "runs": list(_stability.get("runs") or []),
            "runs_count": int(_stability.get("runs_count") or 0),
            "insufficient_runs": int(_stability.get("insufficient_runs") or 0),
            "vote_recorded": bool(_stability.get("vote_recorded")),
            "stable": bool(_stability.get("stable")),
            "flips": list(_stability.get("flips") or []),
            "key_flips": list(_stability.get("key_flips") or []),
            "items": [{"object_id": x.get("object_id"), "rule_code": x.get("rule_code"),
                       "rule_name": x.get("rule_name"), "severity": x.get("severity"),
                       "key_rule": bool(x.get("key_rule")),
                       "conclusion_dist": x.get("conclusion_dist") or {},
                       "majority": x.get("majority"), "flip": bool(x.get("flip")),
                       "stable": bool(x.get("stable")),
                       "states": [{k: s.get(k) for k in ("run_id", "state", "conclusion")}
                                  for s in (x.get("states") or [])]}
                      for x in (_stability.get("items") or [])],
            "blocked": bool(_stability.get("flips")),
        },
    }
    # L80 / P0-C（2026-11-24）：裁决来源统计块（89 号 §6.2）。
    # 开关 RULEPROOF_ADJUDICATION_LEDGER=0 → stats_for_case 返回 None，报告 JSON 不新增
    # 任何键（逐字节回退）；=1 时只读投影，advisory 不阻断报告（STRICT=1 才 blocking）。
    try:
        from . import adjudication_ledger as _adj_ledger
        _adj_stats = _adj_ledger.stats_for_case(case_id)
        if _adj_stats is not None:
            out["adjudication_stats"] = _adj_stats
    except Exception:  # 铁律 2：报告块失败只 warning，不改变报告其余输出
        logging.getLogger(__name__).warning(
            "adjudication_stats report block skipped case=%s", case_id, exc_info=True)
    if access is not None:
        out["access"] = {k: access.get(k) for k in
                         ("actor", "role", "roles", "read_only", "can_review",
                          "can_export_report", "resolved", "identity_verified")}
        out["permissions"] = {"read_only": bool(access.get("read_only")),
                              "can_review": bool(access.get("can_review")),
                              "can_export_report": bool(access.get("can_export_report"))}
    return out


DECISIONS = {"confirmed": "已确认", "false_positive": "误报", "need_evidence": "需补证", "ignored": "已忽略"}


def _rsi_govern_after_decision(rule_code: str, decision: str, actor: str = "") -> dict:
    """RSI 影子期治理（生产链路，不是死代码）。

    人工复核是影子期唯一真实样本来源：
    确认/误报 → shadow_record 累积样本 → shadow_gate 判转正 →
    达标转正（promoted）；样本足够但准确率不达标 → auto_rollback 下线规则。

    只对「处于影子期」的规则生效；无影子记录时 shadow_record 立即返回
    not_in_shadow，不写任何数据，因此默认审核链零影响。
    """
    if not str(rule_code or "").strip() or decision not in ("confirmed", "false_positive"):
        return {}
    try:
        from . import rsi_guard as _rg
        rec = _rg.shadow_record(rule_code, correct=(decision == "confirmed"),
                                actor=actor or "system")
        if not rec.get("ok"):
            return {"recorded": False, "reason": rec.get("reason") or ""}
        gate = _rg.shadow_gate(rule_code)
        if gate.get("ok"):
            _rg.shadow_finish(rule_code, "promoted", actor=actor or "system")
            return {"recorded": True, "promoted": True,
                    "samples": gate.get("samples"), "accuracy": gate.get("accuracy")}
        if gate.get("accuracy_below_target"):
            rb = _rg.auto_rollback(
                rule_code, force=True,
                reason="影子期准确率 %.3f 低于目标（样本 %s）" % (
                    float(gate.get("accuracy") or 0), gate.get("samples")),
                by=actor or "system")
            _rg.shadow_finish(rule_code, "rolled_back", actor=actor or "system")
            return {"recorded": True, "promoted": False, "rolled_back": bool(rb.get("ok")),
                    "samples": gate.get("samples"), "accuracy": gate.get("accuracy"),
                    "archived": rb.get("archived"), "rollback": rb.get("reason") or ""}
        return {"recorded": True, "promoted": False, "samples": gate.get("samples"),
                "reason": gate.get("reason") or ""}
    except Exception:  # noqa: BLE001 - 治理旁路失败不得影响人工复核主链路
        logging.getLogger(__name__).debug(
            "RSI 影子治理失败 rule=%s", rule_code, exc_info=True)
        return {"recorded": False, "reason": "govern_error"}


DECISION_CONFLICT_CODE = "decision_conflict"
BATCH_MAX_ITEMS = 200


def _decision_rows(finding_id: str) -> list:
    """该 finding 的历史裁决行（新→旧）。用于 revision 与「改判 before」取证。"""
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT * FROM decision WHERE finding_id=? "
                "ORDER BY created_at DESC, rowid DESC", (finding_id,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:  # noqa: BLE001 - 历史读取失败不得阻断裁决主链路
        logging.getLogger(__name__).debug("decision history lookup skipped", exc_info=True)
        return []


def _current_finding_status(finding_id: str) -> str:
    try:
        with db.session() as c:
            row = c.execute("SELECT status FROM finding WHERE id=?", (finding_id,)).fetchone()
        return str((row["status"] if row else "") or "pending")
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("finding status lookup skipped", exc_info=True)
        return ""


def _cas_finding_status(finding_id: str, new_status: str, expected_status: str) -> int:
    """原子 CAS：仅当当前状态仍等于 expected_status 时才写入。

    SQLite 的写锁保证并发请求中只有一个能把 status 从旧值改成新值（rowcount=1），
    另一个拿到 rowcount=0，由调用方转成幂等或 409 冲突——不用给 finding 加列。
    """
    with db.session() as c:
        cur = c.execute("UPDATE finding SET status=? WHERE id=? AND status=?",
                        (new_status, finding_id, expected_status))
        return int(cur.rowcount or 0)


def _decision_conflict_payload(finding_id: str, current_status: str) -> dict:
    rows = _decision_rows(finding_id)
    latest = rows[0] if rows else {}
    return {"ok": False,
            "error": "裁决冲突：该问题结论已被他人修改，请刷新后按当前结论重新裁决",
            "code": DECISION_CONFLICT_CODE, "status": 409,
            "current": {"status": current_status,
                        "label": DECISIONS.get(current_status) or current_status,
                        "decision": latest.get("decision") or "",
                        "reason": latest.get("reason") or "",
                        "actor": latest.get("user_id") or "",
                        "at": latest.get("created_at") or ""}}


def _audit_identity(user: str = "审核员", user_id: str = "", actor: str = "",
                    display_name=None, audit_actor: str = "") -> tuple:
    """裁决身份口径（P0-1）：审计 actor 一律取会话账号，显示名只进 after_json。"""
    account = str(audit_actor or actor or user_id or user or "").strip()
    if display_name is None:
        display = str(user or "").strip()
    else:
        display = str(display_name or "").strip()
    if not display:
        display = account
    return account, display


def decide(finding_id: str, decision: str, reason: str = "", note: str = "",
           user: str = "审核员", user_id: str = "", role: str = "",
           actor: str = "", expected_status: str = "", display_name=None,
           audit_actor: str = "", batch_id: str = "") -> dict:
    """人工复核：确认/误报/补证，落库 + 审计。

    P0-1：审计 actor 只接受服务端会话身份（``actor``/``user_id``/``audit_actor``），
    请求体里的 ``user`` 仅作为显示名写进 ``after_json.display_name``，无法伪造 actor。
    P1-4：重复同结论裁决 → 幂等（不重复写审计）；携带 ``expected_status`` 且已被
    他人改成不同结论 → 409 ``decision_conflict``；改判审计写 before_json。
    """
    import json as _json
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "finding not found", "code": "not_found", "status": 404}
    # L92：finding 裁决走状态机单一事实源（FINDING_DECISION_ACTIONS）。当前状态若
    # 不在 finding 五态内（历史/DB 写坏）→ fail-closed 拒绝裁决，不再静默接受任意旧值。
    from . import state_machines as _sm_dec
    _cur = str(f.get("status") or "pending")
    if not _sm_dec.is_state("finding", _cur):
        return {"error": "finding 状态非法，拒绝裁决", "code": "invalid_transition",
                "status": 409, "current": _cur}
    _target = _sm_dec.FINDING_DECISION_ACTIONS.get(str(decision or ""))
    if _target is None:
        return {"error": "未知裁决动作", "code": "invalid_decision", "status": 400}
    if not _sm_dec.can_transition("finding", _cur, _target):
        return {"error": "非法裁决迁移", "code": "invalid_transition", "status": 409,
                "from": _cur, "to": _target}
    account, display = _audit_identity(user, user_id, actor, display_name, audit_actor)
    # P0-1 安全语义：请求声称了角色（role）却没有任何**服务端会话身份**
    # （actor/audit_actor/user_id）→ 未登录，直接拒绝。注意不能把 legacy `user`
    # 显示名当身份（默认值是"审核员"），否则匿名请求 body 声明 role 就能过。
    # 内部服务调用不带 role，保持可用；HTTP 路由由 server 注入真实 user/actor。
    _explicit_identity = (str(actor or "").strip() or str(audit_actor or "").strip()
                          or str(user_id or "").strip())
    if str(role or "").strip() and not _explicit_identity:
        return {"error": "未登录", "code": "unauthenticated", "status": 401}
    if str(actor or "").strip() or str(audit_actor or "").strip() or str(role or "").strip():
        _ident_actor = account or (actor or user_id or "")
        access = authorize_finding(finding_id, "review", _ident_actor, role)
        if not access.get("ok"):
            return _deny_payload(access)
    if decision not in DECISIONS:
        return {"error": "invalid decision", "code": "invalid_decision", "status": 400}
    current_status = str(f.get("status") or "pending")
    expected = str(expected_status or "").strip()
    history = _decision_rows(finding_id)
    revision = len(history)
    # 幂等：目标结论已在库中 → 不重复写 decision/审计，返回 idempotent=true
    if current_status == decision:
        return {"ok": True, "finding_id": finding_id, "status": current_status,
                "label": DECISIONS.get(current_status) or current_status,
                "decision": decision, "idempotent": True, "revision": revision,
                "audit_written": False}
    # 并发冲突：请求基于的旧状态已不是当前状态（且当前状态也不是目标结论）
    if expected and current_status != expected:
        return _decision_conflict_payload(finding_id, current_status)
    base_expected = expected or current_status
    if _cas_finding_status(finding_id, decision, base_expected) <= 0:
        after_status = _current_finding_status(finding_id)
        if after_status == decision:
            return {"ok": True, "finding_id": finding_id, "status": after_status,
                    "label": DECISIONS.get(after_status) or after_status,
                    "decision": decision, "idempotent": True, "revision": revision,
                    "audit_written": False}
        return _decision_conflict_payload(finding_id, after_status or current_status)
    before = {"status": current_status,
              "label": DECISIONS.get(current_status) or current_status}
    if history:
        prev = history[0]
        before.update({"decision": prev.get("decision") or "",
                       "reason": prev.get("reason") or "",
                       "actor": prev.get("user_id") or "",
                       "at": prev.get("created_at") or ""})
    R.decisions.insert(id=db.new_id("d"), finding_id=finding_id, decision=decision,
                       reason=reason, note=note, user_id=(account or display), created_at=db.now())
    f_row = R.findings.get(finding_id) or f
    # 校准路由：记录 LLM 置信度 + 人工复核是否正确（confirmed=对，false_positive=错）
    if decision in ("confirmed", "false_positive"):
        conf = f_row.get("confidence") if f_row else None
        # 样本来源扩大：所有带置信度的结论都记（confidence=None 的确定性结论无需校准）
        # T-115：空间显式关闭 mod_jev 时不再写 Jev 校准样本（主链不执行该模块）。
        _jev_ws = ""
        try:
            _jev_ws = str((R.cases.get(f.get("case_id") or "") or {}).get("workspace_id") or "")
        except Exception:
            _jev_ws = ""
        if conf is not None and not _module_off("mod_jev", _jev_ws):
            from . import calibration
            calibration.record(conf, correct=(decision == "confirmed"),
                               rule_code=(f_row.get("rule_id") or ""),
                               point_id=(f_row.get("point_id") or ""))
    audit_after = {"decision": decision, "reason": reason, "note": note,
                   "account": account, "display_name": display,
                   "revision": revision + 1}
    if batch_id:
        audit_after["batch_id"] = batch_id
    R.audit_logs.log(actor=account, action="finding.decided", object=finding_id,
                     before=_json.dumps(before, ensure_ascii=False),
                     after=_json.dumps(audit_after, ensure_ascii=False))
    # 反馈台账：正向/反向统一沉淀（RSI 实时联动入口）
    try:
        from . import feedback as _fb
        from . import orchestrator as _orch_d
        _fbr = _fb.record(case_id=f.get("case_id") or "", finding_id=finding_id, kind=decision,
                          rule_code=(f_row.get("rule_id") if f_row else "") or f.get("rule_id") or "",
                          title=(f_row.get("title") if f_row else "") or f.get("title") or "",
                          payload={"reason": reason, "note": note}, actor=account)
        _orch_d.post_decision(finding_id, decision, feedback_id=(_fbr or {}).get("feedback_id", ""))
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # RSI 影子期治理：复核反馈 → 影子样本 → 转正门禁/自动回滚（生产调用点）
    govern = _rsi_govern_after_decision(
        (f_row.get("rule_id") if f_row else "") or f.get("rule_id") or "",
        decision, actor=account)
    out = {"ok": True, "finding_id": finding_id, "status": decision,
           "label": DECISIONS[decision], "idempotent": False, "revision": revision + 1,
           "before_status": current_status,
           "audit": {"action": "finding.decided", "actor": account, "display_name": display}}
    if batch_id:
        out["batch_id"] = batch_id
    if govern.get("recorded"):
        out["rsi_governance"] = govern
    return out


def batch_decide(finding_ids, decision: str, reason: str = "", note: str = "",
                 user: str = "审核员", user_id: str = "", role: str = "",
                 actor: str = "", expected_status: str = "pending",
                 display_name=None, audit_actor: str = "") -> dict:
    """P2-2 批量裁决：逐条复用 ``decide``（逐条写审计），附批量汇总审计与 batch_id。

    返回逐条结果（成功/跳过/失败），供前端做逐条反馈与撤销；服务端不做「全有或全无」
    的假原子——单条冲突（已被他人改判）只影响该条，其余照常。
    """
    import json as _json
    ids = []
    for x in (finding_ids or []):
        s = str(x or "").strip()
        if s and s not in ids:
            ids.append(s)
    if not ids:
        return {"ok": False, "error": "请选择要批量裁决的问题", "code": "empty_selection", "status": 400}
    if len(ids) > BATCH_MAX_ITEMS:
        return {"ok": False, "error": "单次批量最多 %d 条，请分批处理" % BATCH_MAX_ITEMS,
                "code": "too_many_items", "status": 400}
    if decision not in DECISIONS:
        return {"ok": False, "error": "invalid decision", "code": "invalid_decision", "status": 400}
    # 批量误报必须给出统一原因（逐条与批量都写审计；允许一条统一原因弱化逐条填写）。
    if decision == "false_positive" and not str(reason or "").strip():
        return {"ok": False, "error": "批量误报必须填写原因（统一原因会逐条写入审计）",
                "code": "reason_required", "status": 400}
    account, display = _audit_identity(user, user_id, actor, display_name, audit_actor)
    batch_id = db.new_id("bat")
    succeeded, skipped, failed = [], [], []
    case_ids = set()
    for fid in ids:
        row = R.findings.get(fid) or {}
        if row.get("case_id"):
            case_ids.add(str(row.get("case_id")))
        r = decide(fid, decision, reason=reason, note=note, user=user, user_id=user_id,
                   role=role, actor=actor, expected_status=expected_status,
                   display_name=display_name, audit_actor=audit_actor, batch_id=batch_id)
        if r.get("ok") and r.get("idempotent"):
            skipped.append({"finding_id": fid, "status": r.get("status"),
                            "idempotent": True,
                            "title": str(row.get("title") or "")})
        elif r.get("ok"):
            succeeded.append({"finding_id": fid, "status": r.get("status"),
                              "before_status": r.get("before_status") or "",
                              "revision": r.get("revision"),
                              "title": str(row.get("title") or "")})
        else:
            failed.append({"finding_id": fid, "error": r.get("error") or "裁决失败",
                           "code": r.get("code") or "", "status": r.get("status"),
                           "title": str(row.get("title") or "")})
    payload = {"batch_id": batch_id, "action": "batch_decide", "decision": decision,
               "label": DECISIONS.get(decision) or decision, "reason": reason,
               "account": account, "display_name": display,
               "case_ids": sorted(case_ids),
               "requested": ids,
               "succeeded": succeeded, "skipped": skipped,
               "failed": failed}
    R.audit_logs.log(actor=account, action="finding.batch_decided", object=batch_id,
                     after=_json.dumps(payload, ensure_ascii=False))
    return {"ok": True, "batch_id": batch_id, "action": "batch_decide",
            "decision": decision, "label": DECISIONS.get(decision) or decision,
            "total": len(ids), "succeeded": succeeded, "succeeded_count": len(succeeded),
            "skipped": skipped, "skipped_count": len(skipped),
            "failed": failed, "failed_count": len(failed),
            "audit": {"action": "finding.batch_decided", "actor": account,
                      "display_name": display}}


def batch_undo(batch_id: str, user: str = "审核员", user_id: str = "", role: str = "",
               actor: str = "", display_name=None, audit_actor: str = "") -> dict:
    """P2-2 撤销最近一次批量裁决：逐条恢复批量前状态，并逐条写撤销审计。

    安全边界：
    - 只能撤销「该 finding 最近一次裁决仍属于本批次」的项（之后又被人工改判的项跳过，
      绝不用撤销覆盖更新的人工结论）；
    - 必须仍具备该条 finding 的 review 权限；本人批量（除非管理员）才能撤销。
    """
    import json as _json
    from datetime import datetime
    account, display = _audit_identity(user, user_id, actor, display_name, audit_actor)
    batch_id = str(batch_id or "").strip()
    if not batch_id:
        return {"ok": False, "error": "缺少 batch_id", "code": "invalid_request", "status": 400}
    rows = []
    try:
        with db.session() as c:
            rs = c.execute("SELECT * FROM audit_log WHERE action='finding.batch_decided' "
                           "AND object=? ORDER BY rowid DESC LIMIT 1", (batch_id,)).fetchall()
            rows = [dict(r) for r in rs]
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("batch audit lookup skipped", exc_info=True)
    if not rows:
        return {"ok": False, "error": "批量操作不存在或已过期，无法撤销",
                "code": "batch_not_found", "status": 404}
    raw = rows[0]
    try:
        payload = _json.loads(raw.get("after_json") or "{}")
    except Exception:  # noqa: BLE001
        payload = {}
    batch_actor = str(payload.get("account") or raw.get("actor") or "")
    if batch_actor and account and batch_actor != account and (role or "") not in ("admin", "super_admin"):
        return {"ok": False, "error": "只能撤销本人的批量裁决", "code": "forbidden", "status": 403}
    created = str(raw.get("created_at") or "")
    if created:
        try:
            if (datetime.now() - datetime.strptime(created, "%Y-%m-%d %H:%M:%S")).total_seconds() > 86400:
                return {"ok": False, "error": "批量裁决已超过 24 小时，不能再撤销",
                        "code": "undo_expired", "status": 409}
        except Exception:  # noqa: BLE001
            logging.getLogger(__name__).debug("batch undo ttl parse skipped", exc_info=True)
    decision = str(payload.get("decision") or "")
    restored, skipped, failed = [], [], []
    for item in (payload.get("succeeded") or []):
        fid = str(item.get("finding_id") or "")
        if not fid:
            continue
        before_status = str(item.get("before_status") or "pending")
        f = R.findings.get(fid) or {}
        if not f:
            failed.append({"finding_id": fid, "error": "问题不存在"})
            continue
        if account or role:
            access = authorize_finding(fid, "review", account, role)
            if not access.get("ok"):
                failed.append({"finding_id": fid, "error": access.get("message") or "无权限撤销"})
                continue
        # 只有「该 finding 最近一次裁决仍属于本批次」才允许撤销
        latest = {}
        try:
            with db.session() as c:
                row = c.execute(
                    "SELECT after_json FROM audit_log WHERE action='finding.decided' "
                    "AND object=? ORDER BY rowid DESC LIMIT 1", (fid,)).fetchone()
            latest = _json.loads((row["after_json"] if row else "") or "{}")
        except Exception:  # noqa: BLE001
            latest = {}
        if str(latest.get("batch_id") or "") != batch_id:
            skipped.append({"finding_id": fid, "status": f.get("status"),
                            "reason": "该问题在批量之后又被改判，撤销不会覆盖更新结论"})
            continue
        if _cas_finding_status(fid, before_status, decision) <= 0:
            skipped.append({"finding_id": fid, "status": _current_finding_status(fid),
                            "reason": "当前状态与批量结论不一致，未撤销"})
            continue
        R.audit_logs.log(
            actor=account, action="finding.batch_undone", object=fid,
            before=_json.dumps({"status": decision, "batch_id": batch_id}, ensure_ascii=False),
            after=_json.dumps({"status": before_status, "batch_id": batch_id,
                               "account": account, "display_name": display},
                              ensure_ascii=False))
        restored.append({"finding_id": fid, "status": before_status,
                         "title": str(f.get("title") or "")})
    summary = {"batch_id": batch_id, "action": "batch_undo",
               "account": account, "display_name": display,
               "restored": restored, "skipped": skipped, "failed": failed,
               "decision": decision}
    R.audit_logs.log(actor=account, action="finding.batch_undone", object=batch_id,
                     after=_json.dumps(summary, ensure_ascii=False))
    return {"ok": True, "batch_id": batch_id, "action": "batch_undo",
            "restored": restored, "restored_count": len(restored),
            "skipped": skipped, "skipped_count": len(skipped),
            "failed": failed, "failed_count": len(failed),
            "audit": {"action": "finding.batch_undone", "actor": account,
                      "display_name": display}}


def _preview_doc_html(text: str, filename: str = "", multi: bool = False) -> str:
    """解析文本预览：带文件头、章节层级和正文排版，不是裸 pre。"""
    import re as _re
    lines = (text or "").splitlines()
    body, para = [], []
    def flush():
        if para:
            body.append('<p class="doc-p">' + "<br>".join(_esc_html(x) for x in para) + '</p>')
            para.clear()
    for line in lines:
        t = line.strip()
        if not t:
            flush(); body.append('<div class="doc-gap"></div>'); continue
        if _re.match(r'^[一二三四五六七八九十]+[、.．]', t) or _re.match(r'^第[一二三四五六七八九十]+[章节]', t):
            flush(); body.append('<h2 class="doc-h2">' + _esc_html(t) + '</h2>'); continue
        if _re.match(r'^[（(][一二三四五六七八九十]+[）)]', t):
            flush(); body.append('<h3 class="doc-h3">' + _esc_html(t) + '</h3>'); continue
        para.append(line)
    flush()
    title = _esc_html(filename or "文档原文")
    sub = "合并预览" if multi else "解析文本预览"
    css = ("<style>body{margin:0;background:#F1F3F5;font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;color:#1F2329}"
           ".doc-wrap{max-width:860px;margin:0 auto;padding:20px 20px 50px}.doc-paper{background:#fff;border:1px solid #E5E6E8;border-radius:8px;padding:34px 42px;box-shadow:0 2px 10px rgba(31,35,41,.04)}"
           ".doc-kicker{font-size:10px;color:#8F959E;letter-spacing:.12em;text-transform:uppercase;margin-bottom:10px}.doc-title{font-size:22px;line-height:1.4;font-weight:600;margin:0 0 7px;word-break:break-word}"
           ".doc-meta{font-size:11px;color:#8F959E;padding-bottom:16px;border-bottom:1px solid #EFF0F1;margin-bottom:20px}.doc-body{font-size:14px;line-height:1.95;letter-spacing:.01em}"
           ".doc-p{margin:0 0 9px;white-space:pre-wrap;word-break:break-word}.doc-h2{font-size:15px;font-weight:600;margin:24px 0 10px;padding-left:8px;border-left:3px solid #3370FF;line-height:1.5}.doc-h3{font-size:13px;font-weight:600;margin:15px 0 7px}.doc-gap{height:7px}"
           ".wb-loc-highlight{background:#FFF3B0 !important;box-shadow:none !important;border-radius:2px}"
           "html{overflow:auto!important}body{overflow:visible!important}"
           "@media(max-width:600px){.doc-wrap{padding:10px}.doc-paper{padding:20px 18px}.doc-title{font-size:18px}.doc-body{font-size:13px;line-height:1.85}}</style>")
    return ("<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><title>" + title +
            "</title>" + css + "</head><body><div class='doc-wrap'><div class='doc-paper'><div class='doc-kicker'>AI 审核平台 · 原文预览</div><h1 class='doc-title'>" +
            title + "</h1><div class='doc-meta'>" + sub + " · " + str(len(text or "")) + " 字</div><div class='doc-body'>" + "".join(body) + "</div></div></div></body></html>")


def _preview_notice_html(title: str, message: str, detail: str = "") -> str:
    """预览空态/错误态：给出明确原因，绝不渲染空白页冒充成功。"""
    _title, _msg, _detail = _esc_html(title or ""), _esc_html(message or ""), _esc_html(detail or "")
    return ("<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><style>"
            "body{margin:0;background:#F1F3F5;font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;color:#1F2329}"
            ".nbox{max-width:680px;margin:40px auto;background:#fff;border:1px solid #E5E6E8;border-radius:10px;padding:28px 32px;box-shadow:0 2px 10px rgba(31,35,41,.04)}"
            "h2{font-size:16px;margin:0 0 10px}.nmsg{font-size:13px;line-height:1.8;color:#4E5969}.ndetail{margin-top:12px;font-size:11px;line-height:1.7;color:#8F959E;word-break:break-word}"
            ".nhint{margin-top:14px;padding:9px 12px;border-radius:6px;background:#FFF8E6;border:1px solid #FFE7A3;color:#8F5E00;font-size:12px;line-height:1.7}</style>"
            "</head><body><div class='nbox'><h2>" + _title + "</h2><div class='nmsg'>" + _msg + "</div>" +
            ("<div class='ndetail'>" + _detail + "</div>" if _detail else "") +
            "</div></body></html>")


def document_preview(case_id: str, doc_id: str = "") -> dict:
    """文档预览：xlsx 渲染 sheet 高亮；docx/pdf 渲染解析文本。

    T-94：PDF 额外返回真实页数 ``page_count`` 与 ``is_pdf``，前端据此提供
    原始页图/解析文本双视图与翻页；PDF 解析文本为空时给出明确空态（不渲染空白页）。
    """
    docs = R.cases.documents(case_id)
    if not docs:
        return {"html": _preview_notice_html("暂无文档", "当前项目还没有上传文件。"),
                "filename": "", "doc_id": "", "is_pdf": False, "page_count": 0, "text_len": 0}
    if not doc_id and len(docs) > 1:
        # 多文件：合并预览（当一份处理）
        from ..engine import deepparse
        parts = []
        for x in docs:
            pth = x.get("path") or ""
            if pth and os.path.exists(pth):
                try:
                    parts.append(f"【文件：{x.get('filename', '')}】\n" + _parsed_cached(pth)["doc"].get("text", ""))
                except Exception:
                    continue
        text = "\n\n".join(parts)
        html = _preview_doc_html(text, "、".join(x.get("filename", "") for x in docs), multi=True)
        return {"html": html, "filename": "、".join(x.get("filename", "") for x in docs),
                "doc_id": "", "is_pdf": False, "page_count": 0, "text_len": len(text)}
    d = next((x for x in docs if x["id"] == doc_id), docs[0])
    path = d.get("path") or ""
    ext = (d.get("doc_type") or "").lower()
    _fname = str(d.get("filename") or "")
    _fext = _fname.rsplit(".", 1)[-1].lower() if "." in _fname else ""
    is_pdf = ext == "pdf" or _fext == "pdf"
    out = {"html": "", "filename": d.get("filename", ""), "doc_id": d.get("id", ""),
           "is_pdf": is_pdf, "page_count": 0, "text_len": 0}
    if not path or not os.path.exists(path):
        out["html"] = _preview_notice_html(
            "文件不存在", "数据库中有该文件记录，但磁盘上的原始文件已丢失，无法预览。",
            f"文件名：{d.get('filename', '')}")
        return out
    if is_pdf:
        try:
            from . import pdf_preview as _pp
            _cnt = _pp.page_count(path)
            out["page_count"] = int(_cnt.get("count") or 0)
        except Exception:
            out["page_count"] = 0
    if ext in ("xlsx", "xls"):
        try:
            rep = engine.build_report(path)
            out["html"] = engine.render_workbook_html(path, rep["findings"])
        except Exception as e:  # noqa
            out["html"] = _preview_notice_html("预览失败", "表格解析失败，无法渲染 Sheet 预览。",
                                               f"{type(e).__name__}: {str(e)[:300]}")
    else:
        try:
            from ..engine import deepparse
            parsed = _parsed_cached(path)
            text = parsed["doc"].get("text", "")
            out["text_len"] = len(text or "")
            if is_pdf and not (text or "").strip():
                out["html"] = _preview_notice_html(
                    "PDF 未解析出文本",
                    "该 PDF 可能是扫描件/图片型文件，当前解析结果没有文本层。",
                    "请点上方「原始文件」查看逐页页图；如需文本审核，需先完成 OCR。")
            else:
                html = _preview_doc_html(text, d.get("filename", ""))
                out["html"] = html
        except Exception as e:  # noqa
            out["html"] = _preview_notice_html(
                "预览失败", "解析文本加载失败。", f"{type(e).__name__}: {str(e)[:300]}")
    if not out["html"]:
        out["html"] = _preview_notice_html("暂无预览", "该文件没有可渲染的解析结果。",
                                           f"文件名：{_fname}")
    return out


def audit_records(date_from: str = "", date_to: str = "", reviewer_id: str = "", limit: int = 300) -> dict:
    """审核记录（只读）：按日期/审核员筛选所有复核动作。"""
    from .. import db as _db
    sql = ("SELECT d.id, d.decision, d.created_at, d.user_id, "
           "f.id AS finding_id, f.title, f.severity, f.rule_id, "
           "c.id AS case_id, c.name AS case_name, "
           "u.name AS reviewer_name, u.username AS reviewer_username "
           "FROM decision d LEFT JOIN finding f ON f.id=d.finding_id "
           "LEFT JOIN audit_case c ON c.id=f.case_id "
           "LEFT JOIN user u ON u.id=d.user_id WHERE 1=1")
    args = []
    # L140/P0-1（build54）：审核记录/导出必须按当前租户隔离；旧 SQL 裸查全表会跨租户泄漏
    # 项目名/问题标题/规则码/复核人。无租户上下文时 fail-closed（不返回任何行），
    # 与 BaseRepo 的“有 ctx 才过滤”不同——这是安全只读接口，不能靠调用方记得加 ctx。
    try:
        from . import ctx as _ctx
        _tid = str((_ctx.get_context() or {}).get("tenant_id") or "")
    except Exception:
        _tid = ""
    if not _tid:
        sql += " AND 1=0"
    else:
        sql += " AND c.tenant_id=?"; args.append(_tid)
    if date_from:
        sql += " AND substr(d.created_at,1,10) >= ?"; args.append(date_from)
    if date_to:
        sql += " AND substr(d.created_at,1,10) <= ?"; args.append(date_to)
    if reviewer_id:
        sql += " AND d.user_id = ?"; args.append(reviewer_id)
    sql += " ORDER BY d.created_at DESC LIMIT ?"; args.append(limit)
    rows = []
    try:
        with _db.session() as c:
            rows = [dict(r) for r in c.execute(sql, args).fetchall()]
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    from ..severity import label as _sev_label
    DEC = {"confirmed": "确认", "false_positive": "误报", "need_evidence": "补证"}
    out = []
    for r in rows:
        out.append({
            "id": r.get("id"), "decision": DEC.get(r.get("decision"), r.get("decision")),
            "decision_raw": r.get("decision"),
            "title": r.get("title", ""), "severity": r.get("severity"),
            "severity_label": _sev_label(r.get("severity")),
            "rule_id": r.get("rule_id", ""), "case_id": r.get("case_id", ""),
            "case_name": r.get("case_name", ""),
            "reviewer": r.get("reviewer_name") or r.get("reviewer_username") or "—",
            "reviewer_id": r.get("user_id", ""), "created_at": r.get("created_at", ""),
        })
    return {"total": len(out), "items": out}


def reject_decision(finding_id: str, actor: str = "管理员", actor_id: str = "",
                    reason: str = "", role: str = "") -> dict:
    """复核退回：把已复核的发现打回待复核，并通知项目负责人。

    职责分离后业务管理员只读，退回/重开必须由项目所属审核员本人发起。
    """
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "finding not found"}
    _verified = _verified_actor_id(actor_id or "")
    _strict = bool(str(role or "").strip() or _verified
                   or str(actor or "").strip() not in ("", "管理员"))
    if _strict:
        _ident_actor = (actor_id or ("" if str(actor or "").strip() == "管理员" else actor))
        access = authorize_finding(finding_id, "review", _ident_actor, role)
        if not access.get("ok"):
            return _deny_payload(access)
    if f.get("status") == "pending":
        return {"error": "该问题已是待复核状态"}
    R.findings.update(finding_id, status="pending")
    R.decisions.insert(id=db.new_id("d"), finding_id=finding_id, decision="rejected",
                       reason=reason or "复核退回", note="", user_id=(actor_id or actor), created_at=db.now())
    R.audit_logs.log(actor=actor_id or actor, action="review.rejected", object=finding_id)
    try:
        case = R.cases.get(f.get("case_id"))
        owner = (case or {}).get("created_by") or ""
        if owner:
            from . import notify
            notify.notify_project_pending(owner,
                          f"复核退回：「{(case or {}).get('name', '项目')}」的问题「{f.get('title', '')}」需重新复核",
                          reason or "管理员退回")
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"finding_id": finding_id, "status": "pending"}


def add_manual_finding(case_id: str, severity: str, title: str, detail: str = "",
                       category: str = "", user: str = "", user_id: str = "",
                       locator: str = "", quote: str = "", document_id: str = "",
                       suggestion: str = "", role: str = "", actor: str = "",
                       rule_code: str = "") -> dict:
    """人工新增问题：支持文件+位置+原文摘录，作为漏报信号进入反馈/规则进化。

    2026-11-23 LaneR（A 类 B2 修复，依据 docs/qa/反馈闭环演练_20261123.md §4.2/§6）：
    旧实现把反馈 ``rule_code`` 固定为 ``"MANUAL"``，沉淀 new_rule 时既拿不到可关联的真实
    规则，又无法与「关联既有规则的人工漏报」区分。现在按业务语义映射：
    - ``rule_code`` 显式给出且命中既有规则 → 反馈 ``rule_code=该码``，通道 ``revise``
      （人工漏报复核后关联到既有规则，可走规则修订）；
    - 其余（真实漏报 = 规则库没有对应规则）→ ``rule_code=manual_missing``，payload 标
      ``manual_missing=true``/``channel=new_rule``，明确走「新规则」沉淀通道；
      **不再落无意义的 ``MANUAL`` 伪编码**。finding.rule_id 仍保留 ``MANUAL`` 供工作台
      展示（引擎=人工），反馈侧是可沉淀的真实语义。
    """
    if not R.cases.get(case_id):
        return {"error": "项目不存在"}
    _verified = _verified_actor_id(user_id or actor)
    if str(role or "").strip() or str(actor or "").strip() or _verified:
        access = authorize_case(case_id, "review", actor or _verified or user, role)
        if not access.get("ok"):
            return _deny_payload(access)
    if not title.strip():
        return {"error": "问题标题不能为空"}
    from ..severity import normalize as _sev_norm
    severity = _sev_norm(severity)
    if severity not in ("critical", "warning", "info"):
        severity = "warning"
    fid = db.new_id("fnd")
    _case = R.cases.get(case_id) or {}
    R.findings.insert(id=fid, case_id=case_id, rule_id="MANUAL", rule_version="manual", run_id=_case.get("last_run_id") or "",
                      severity=severity, certainty="certain", confidence=None, state="fail", status="pending",
                      title=title.strip(), summary=detail.strip(), suggestion=suggestion.strip(), engine="manual")
    # 人工问题也建立证据锚点，保证工作台能定位、报告能引用
    _doc_id = str(document_id or "").strip()
    if not _doc_id:
        try:
            _docs = R.cases.documents(case_id)
            _doc_id = (_docs[0].get("id") or "") if _docs else ""
        except Exception:
            _doc_id = ""
    _locator = str(locator or "").strip() or "人工新增"
    _quote = str(quote or "").strip()
    if _doc_id:
        try:
            aid = db.new_id("anc")
            R.anchors.insert(id=aid, document_id=_doc_id, sheet="", row="", col="",
                             locator=_locator, quote=_quote[:500], hash="")
            R.evidences.insert(id=db.new_id("evd"), finding_id=fid, document_id=_doc_id,
                               anchor_id=aid, excerpt=_quote[:500] or _locator, label="人工新增")
        except Exception:
            logging.getLogger(__name__).debug('manual evidence skipped', exc_info=True)
    R.audit_logs.log(actor=user_id or user, action="finding.manual_added", object=fid,
                     after=f"{title.strip()} · {_locator}")
    # 2026-11-23 LaneR（B2）：人工漏报 → 规则码映射（关联既有规则 or manual_missing 新规则通道）
    _linked_code = str(rule_code or "").strip()
    if _linked_code:
        try:
            _hit = [x for x in R.rules.list("code=?", (_linked_code,)) if x.get("id")]
        except Exception:  # noqa: BLE001 - 回查失败按“未关联”处理，但要留痕（铁律 2）
            logging.getLogger(__name__).warning(
                "manual finding rule_code lookup failed case=%s code=%s",
                case_id, _linked_code, exc_info=True)
            _hit = []
        if not _hit:
            # 不落“看似关联”的伪编码：未知规则码按真实漏报处理
            logging.getLogger(__name__).warning(
                "manual finding rule_code not found, fallback to manual_missing case=%s code=%s",
                case_id, _linked_code)
            _linked_code = ""
    try:
        from . import feedback as _fb
        _manual_code = (getattr(_fb, "MANUAL_MISSING_RULE_CODE", "manual_missing")
                        if not _linked_code else _linked_code)
        _fb.record(case_id=case_id, finding_id=fid, kind="manual", rule_code=_manual_code,
                   title=title.strip(),
                   payload={"detail": detail, "severity": severity,
                            "locator": _locator, "quote": _quote,
                            "document_id": _doc_id, "suggestion": suggestion,
                            "manual_missing": not _linked_code,
                            "channel": "revise" if _linked_code else "new_rule",
                            "linked_rule_code": _linked_code},
                   actor=user_id or user)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"id": fid, "severity": severity, "title": title.strip(),
            "locator": _locator, "document_id": _doc_id,
            "feedback_rule_code": (_linked_code or "manual_missing")}


def add_evidence(finding_id: str, text: str = "", filename: str = "", content: bytes = None,
                 user: str = "", user_id: str = "", role: str = "", actor: str = "") -> dict:
    """单独入口：给问题补充证据（文字/文件），并记入反馈台账。"""
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "问题不存在"}
    _verified = _verified_actor_id(user_id or actor)
    if str(role or "").strip() or str(actor or "").strip() or _verified:
        access = authorize_finding(finding_id, "review", actor or _verified or user, role)
        if not access.get("ok"):
            return _deny_payload(access)
    if not (text or "").strip() and not filename:
        return {"error": "请填写证据说明或上传文件"}
    # 引文核验：文字证据必须能在项目文档原文中找到；找不到/无法解析 → 拒绝
    if (text or "").strip() and not content:
        from . import project as _pjv
        from ..engine import deepparse as _dpv
        _docs = _pjv.documents(f.get("case_id") or "")
        if not _docs:
            try:
                _docs = R.cases.documents(f.get("case_id") or "")
            except Exception:
                _docs = []
        if not _docs:
            _docs = []  # 无文档时视为外部证据（无法核验，放行但留痕）
        _corpus = []
        for _d in _docs:
            try:
                _corpus.append(_parsed_cached(_d.get("path") or "")["doc"].get("text", ""))
            except Exception:
                # agent-parse 不可用时退回确定性解析，不让补证核验因解析器缺失而失败
                try:
                    from ..engine import deepparse as _dpv2
                    _pth = _d.get("path") or ""
                    _corpus.append(str(_dpv2.parse_document(_pth).text or "")
                                   if _pth and os.path.exists(_pth) else "")
                except Exception:
                    continue
        _all = "\n".join(_corpus)
        if _docs and not _all.strip():
            return {"error": "项目文档无法解析，引文无法核验，不能作为证据", "code": "quote_unverifiable"}
        if _all.strip() and re.sub(r"\s+", "", text) not in re.sub(r"\s+", "", _all):
            return {"error": "引文在项目文档原文中找不到，不能作为证据", "code": "quote_not_found"}
    stored = ""
    if content:
        import hashlib
        from . import project as _proj
        up = os.path.join(_proj._upload_dir(), f"evd_{db.new_id('x')}_{filename}")
        with open(up, "wb") as fh:
            fh.write(content)
        stored = filename
    # 锚点必须挂到已存在的文档上（外键约束）
    doc_id = ""
    try:
        from . import project as _proj2
        docs = _proj2.documents(f.get("case_id") or "")
        doc_id = (docs[0]["id"] if docs else "")
    except Exception:
        doc_id = ""
    aid = db.new_id("anc")
    R.anchors.insert(id=aid, document_id=doc_id, sheet="", row="", col="",
                     quote=(text or filename)[:500], locator=stored or "人工补证")
    R.evidences.insert(id=db.new_id("evd"), finding_id=finding_id, document_id=doc_id,
                       anchor_id=aid, excerpt=(text or filename)[:500], label="补充证据")
    R.findings.update(finding_id, status="need_evidence")
    try:
        from . import feedback as _fb
        _fb.record(case_id=f.get("case_id") or "", finding_id=finding_id, kind="supplement",
                   rule_code=f.get("rule_id") or "",
                   title=f.get("title") or "",
                   payload={"text": text, "filename": filename}, actor=user_id or user)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    R.audit_logs.log(actor=user_id or user or "reviewer", action="finding.evidence_added", object=finding_id,
                     after=(stored or text)[:120])
    return {"ok": True, "finding_id": finding_id, "evidence_id": aid, "file": stored}


def update_finding(finding_id: str, title: str = "", severity: str = "", detail: str = "",
                   user_id: str = "", role: str = "", actor: str = "") -> dict:
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "finding not found"}
    _verified = _verified_actor_id(user_id or actor)
    if str(role or "").strip() or str(actor or "").strip() or _verified:
        access = authorize_finding(finding_id, "review", actor or _verified, role)
        if not access.get("ok"):
            return _deny_payload(access)
    upd = {}
    if title.strip():
        upd["title"] = title.strip()
    if str(severity or "").strip():
        from ..severity import normalize as _sev_norm2
        upd["severity"] = _sev_norm2(severity, strict=True)
    if detail.strip():
        upd["summary"] = detail.strip()
    if upd:
        R.findings.update(finding_id, **upd)
        R.audit_logs.log(actor=actor or user_id or "admin", action="finding.updated", object=finding_id)
        # 补证/改写 → 反馈台账（证据链增强）
        try:
            from . import feedback as _fb
            _fb.record(case_id=f.get("case_id") or "", finding_id=finding_id, kind="supplement",
                       rule_code=str(f.get("rule_id") or ""),
                       title=str(f.get("title") or ""),
                       payload={"detail": detail, "severity": severity}, actor=actor or user_id or "")
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"id": finding_id, "updated": list(upd.keys())}


DELETE_SUPPRESS_REASON = "manual_delete_suppressed"
"""P1-5（2026-11-21 外部交叉复测 A3）：删除默认=抑制，不是物理抹除。

旧行为三条 DELETE（finding + evidence + decision）把真问题无痕抹掉、decision 标签断链，
不可复算。现在：
  · 默认：``finding.status='ignored'`` + ``suppression_ledger`` 记录（reason/actor/时间），
    evidence / decision 全部保留；
  · 例外：``engine='manual'`` 且该 finding **无任何 decision 记录**（人工新增、从未裁决）
    → 允许物理删除（清掉误加的空壳，不产生审计断链）。
"""

# 严重度 → 抑制台账风险等级（台账 service 层禁止 critical/high 自动抑制；本路径是
# 有权限的人工删除动作，显式记录风险等级供抽样审计，不改变可见性策略判定）。
_DELETE_RISK = {"critical": "critical", "warning": "medium", "info": "low"}


def _finding_decision_rows(finding_id: str) -> list:
    try:
        return R.decisions.list("finding_id=?", (finding_id,), limit=50)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning("decision lookup for delete failed",
                                            exc_info=True)
        return []


def _suppress_finding_instead_of_delete(f: dict, finding_id: str, actor: str,
                                        reason: str) -> dict:
    """把「删除」降级为「抑制」：状态位 + 不可变 suppression_ledger 记录。"""
    import hashlib as _hl
    import json as _js
    case_id = str(f.get("case_id") or "")
    now = db.now()
    raw_claim = {
        "source": "platform", "id": finding_id, "case_id": case_id,
        "rule_code": str(f.get("rule_id") or f.get("rule_code") or ""),
        "title": str(f.get("title") or ""), "issue": str(f.get("summary") or ""),
        "severity": str(f.get("severity") or ""), "engine": str(f.get("engine") or ""),
        "status_before": str(f.get("status") or ""), "state": str(f.get("state") or ""),
        "action": "delete_finding", "reason": str(reason or "")[:500],
        "actor": str(actor or ""), "at": now, "not_gold": True,
    }
    raw_json = _js.dumps(raw_claim, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"))
    raw_sha = _hl.sha256(raw_json.encode("utf-8")).hexdigest()
    ledger_id = "sl_" + __import__("uuid").uuid4().hex[:16]
    ledger_key = "|".join((case_id, "", "platform", "", "", finding_id, raw_sha))
    reason_note = (f"删除动作降级为抑制（保留证据/裁决可复算）："
                   f"actor={actor or 'unknown'} reason={str(reason or '')[:300]}")
    with db.session() as c:
        c.execute("UPDATE finding SET status='ignored' WHERE id=?", (finding_id,))
        c.execute(
            "INSERT INTO suppression_ledger(id,ledger_key,case_id,run_id,tenant_id,"
            "workspace_id,source,comparison_item_id,direct_item_id,platform_finding_id,"
            "rule_code,object_id,subject,issue_type,raw_claim_json,raw_claim_sha256,"
            "evidence_json,refute_evidence_json,confidence,risk_level,suppression_reason,"
            "reason_note,visibility_status,sampled,sampled_at,human_result,human_actor,"
            "human_reason,human_at,recovered_finding_ref,recovered_at,recovered_by,"
            "created_at,immutable) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"
            "?,?,?,?,?,?,?,?,?,?,?)",
            (ledger_id, ledger_key, case_id, str(f.get("run_id") or ""),
             str(f.get("tenant_id") or ""), str(f.get("workspace_id") or ""),
             "platform", "", "", finding_id,
             str(f.get("rule_id") or f.get("rule_code") or ""), "",
             str(f.get("title") or "")[:120], "delete_finding",
             raw_json, raw_sha, "{}", "{}", f.get("confidence"),
             _DELETE_RISK.get(str(f.get("severity") or ""), "medium"),
             DELETE_SUPPRESS_REASON, reason_note, "suppressed", 0,
             "", "", "", "", "", "", "", "", now, 1))
    R.audit_logs.log(
        actor=actor or "admin", action="finding.suppressed", object=finding_id,
        before=_js.dumps({"status": f.get("status"), "state": f.get("state")},
                         ensure_ascii=False),
        after=_js.dumps({"status": "ignored", "mode": "suppressed",
                         "ledger_id": ledger_id, "reason": str(reason or ""),
                         "reason_code": DELETE_SUPPRESS_REASON}, ensure_ascii=False))
    return {"id": finding_id, "deleted": False, "mode": "suppressed",
            "suppressed": True, "status": "ignored", "ledger_id": ledger_id,
            "reason_code": DELETE_SUPPRESS_REASON,
            "evidence_retained": True, "decision_retained": True,
            "note": "删除已降级为抑制：finding 状态=ignored，证据/裁决保留，"
                    "可在抑制台账审计；不做物理删除"}


def delete_finding(finding_id: str, user_id: str = "", role: str = "",
                   actor: str = "", reason: str = "") -> dict:
    """删除发现：默认=抑制（可审计、可复算）；仅 manual 且无裁决记录允许物理删。"""
    f = R.findings.get(finding_id)
    if not f:
        return {"error": "finding not found"}
    _verified = _verified_actor_id(user_id or actor)
    _actor = actor or user_id or _verified or "admin"
    if str(role or "").strip() or str(actor or "").strip() or _verified:
        access = authorize_finding(finding_id, "review", actor or _verified, role)
        if not access.get("ok"):
            return _deny_payload(access)
    decisions = _finding_decision_rows(finding_id)
    engine = str(f.get("engine") or "")
    if engine == "manual" and not decisions:
        # 例外：人工新增、从未裁决的空壳问题 → 保留旧物理删语义
        with db.session() as c:
            c.execute("DELETE FROM evidence WHERE finding_id=?", (finding_id,))
            c.execute("DELETE FROM decision WHERE finding_id=?", (finding_id,))
            c.execute("DELETE FROM finding WHERE id=?", (finding_id,))
        R.audit_logs.log(actor=_actor, action="finding.deleted", object=finding_id,
                         after=__import__("json").dumps(
                             {"mode": "physical", "engine": engine,
                              "decision_count": 0, "reason": str(reason or "")},
                             ensure_ascii=False))
        return {"id": finding_id, "deleted": True, "mode": "physical",
                "suppressed": False, "evidence_retained": False,
                "note": "manual 且无裁决记录：物理删除（旧语义保留）"}
    return _suppress_finding_instead_of_delete(f, finding_id, _actor, reason)






_KW = ("日期", "名称", "版本", "签名", "温度", "工序", "半成品", "序号", "占位符", "限价", "报价", "编号")


def _issue_signature(f: dict) -> tuple:
    """问题签名：问题关键词 + 数值/日期集合（排序后）。用于跨规则去重。"""
    import re as _re
    text = " ".join([str(f.get("title") or ""), str(f.get("description") or ""),
                     str(((f.get("locations") or [{}])[0] or {}).get("quote") or "")])
    kws = tuple(sorted({k for k in _KW if k in text}))
    ents = tuple(sorted(set(_re.findall(r"\d{4}-\d{2}-\d{2}|\d+(?:\.\d+)?", text)))[:8])
    return (kws, ents)


# ---------------------------------------------------------------------------
# 语义补证重判 / 独立子要求重判 / 复核时间线
# ---------------------------------------------------------------------------
# 约束：
# - 只改本文件、不新增表；历史事件落在既有 decision / manifest_evidence /
#   manifest_review / audit_log 上，旧 manifest_result 永不覆盖。
# - 语义结论只来自真实 agent-judge 返回；无模型、空结果、引文回查失败一律
#   insufficient，不把“没跑成”写成 pass/fail，也不回填任何默认结论。
# - 独立子要求重判只替换目标子要求，兄弟子要求逐字段原样保留；
#   manifest_active_sub 只移动目标子要求，不批量改写其它子要求指针。
# ---------------------------------------------------------------------------

_REAUDIT_STATUS_MAP = {
    "pass": "pass", "fail": "fail", "na": "na",
    "满足": "pass", "不满足": "fail", "不适用": "na",
    "insufficient": "insufficient", "证据不足": "insufficient",
    "needs_model": "insufficient", "无法判断": "insufficient",
    "unknown": "insufficient", "未知": "insufficient",
    "failed": "failed", "执行失败": "failed",
    "blocked": "failed", "skipped": "na",
}

_REAUDIT_CONCLUSION = {
    "pass": "满足", "fail": "不满足", "na": "不适用",
    "insufficient": "证据不足", "failed": "执行失败", "unknown": "无法判断",
}

_REAUDIT_KIND_LABEL = {
    "review.semantic_reaudited": "语义补证重判",
    "review.semantic_case_reaudited": "同案例语义重审",
    "review.sub_reaudited": "子要求独立重判",
    "review.evidence_added": "补证",
    "review.finding_changed": "重判后问题状态变更",
    "manifest.reaudited": "补证后重判",
    "manifest.evidence_requested": "申请补证",
    "manifest.evidence_fulfilled": "补证完成",
    "manifest.decided": "清单复核",
    "manifest.frozen": "生成审核清单",
    "finding.decided": "人工复核",
    "finding.evidence_added": "人工补证",
    "finding.updated": "编辑问题",
    "finding.manual_added": "人工新增问题",
    "finding.deleted": "删除问题",
}

_DECISION_LABEL = {
    "confirmed": "已确认", "false_positive": "误报",
    "need_evidence": "需补证", "ignored": "已忽略", "rejected": "复核退回",
}


def _rea_json(raw, default):
    """宽松解析 JSON 列：解析不了返回默认值，不把坏数据当结论。"""
    if isinstance(raw, (dict, list)):
        return raw
    try:
        return json.loads(raw or "")
    except Exception:
        return default


def _rea_dict(raw) -> dict:
    value = _rea_json(raw, {})
    return value if isinstance(value, dict) else {}


def _rea_status(value: str) -> str:
    return _REAUDIT_STATUS_MAP.get(str(value or "").strip(), "insufficient")


def _rea_norm_text(value: str) -> str:
    return re.sub(r"\s+", "", str(value or ""))


def _rea_quote_verified(quote: str, text: str) -> bool:
    """引文必须能在本次证据文本中逐字找到（允许空白差异）。"""
    q, t = _rea_norm_text(quote), _rea_norm_text(text)
    return bool(q) and bool(t) and q in t


def _rea_quote_tokens(text: str) -> list:
    """证据文本的结构化分段（单元格 ` | `、多段 `；`、换行均可切分；空白归一去空）。"""
    return [t for t in (re.sub(r"\s+", "", x)
                        for x in re.split(r"[|｜；;\n\r]+", str(text or "")))
            if t]


def _rea_quote_matches_sub(quote: str, allowed: list) -> bool:
    """引文是否属于该 finding 所属子要求（L167 子要求串位校验 + L178 扩展）。

    历史口径：引文与子要求引文互为子串。L178 补「整行回填」口径：主链 finding 级
    ``verbatim_quote`` 是整行原文（签名角色表头行 + 值行，单元格用 `` | `` 拼接），
    子要求引文是它的子集，直接互为子串会误判 quote_sub_mismatch（L167 D12 修复后暴露）。
    修法：子要求引文可切成 ≥2 个实质分段时，要求**每个分段都出现在 finding 引文中**
    （同一子要求的证据内容全含）；单段引文仍按原「互为子串」口径，真正串位的引文
    （如 S1 的 finding 引 S2 内容）依旧拒绝，不放宽。
    """
    qn = _rea_norm_text(quote)
    if not qn:
        return False
    for a in allowed or []:
        an = _rea_norm_text(a)
        if not an:
            continue
        if qn in an or an in qn:
            return True
        a_segs = _rea_quote_tokens(a)
        if len(a_segs) >= 2 and all(seg in qn for seg in a_segs):
            return True
    return False


# ---------------------------------------------------------------------------
# P0-证据真实性（用户优先级 5）：fail 发现引文必须逐字命中归属对象原文/单元格
#
# 口径：
#   1) fail 结论必须带引文；引文经空白归一后必须是“该 finding 归属对象”原文子串；
#   2) xlsx 必须命中目标 sheet/单元格（锚点带 row/col 时按单元格逐字核验）；
#   3) 引文只在其它文件命中 = 跨文件串位；只在其它 sheet 命中 = 跨 sheet 串位；
#      与 manifest_result 子要求的引文不一致 = 子要求串位；
#   4) 不命中 → 降级 insufficient + certainty=abstain + status=need_evidence（人工复核），
#      不得保留 certainty=certain 的 fail 结论；report_gate 据此硬阻断签发。
# 人工新增 finding（engine=manual）由人工署名负责，不做自动降级。
# ---------------------------------------------------------------------------
_EVIDENCE_PARSE_CACHE = {}
_EVIDENCE_VERIFY_CACHE = {}
_EVIDENCE_GATE_MARK = "证据门禁"
_EVIDENCE_GATE_DETAIL = "证据门禁：引文未逐字命中归属对象原文/单元格，已降级证据不足，转人工复核"
_EVIDENCE_EXEMPT_ENGINES = ("manual",)
# DU-08（2026-11-25）：主链 finding 引擎**显式白名单**（此前 fact-merged 未在列：
# 多文件事实层合并结果无引文时按 skipped_legacy 跳过二次降级 → 无证据 fail 可留存）。
# 新增主链引擎必须在此登记，不允许再用“字段/子串碰巧命中”推断。
_EVIDENCE_MAIN_CHAIN_ENGINE_PREFIXES = ("manifest", "fact-merged")
_EVIDENCE_MAIN_CHAIN_ENGINE_KEYS = ("customer_rule", "platform", "dag")


def _is_main_chain_engine(engine: str) -> bool:
    e = str(engine or "").strip().lower()
    if not e:
        return False
    if e.startswith(_EVIDENCE_MAIN_CHAIN_ENGINE_PREFIXES):
        return True
    return any(k in e for k in _EVIDENCE_MAIN_CHAIN_ENGINE_KEYS)


def _evidence_parse(path: str):
    """解析证据归属对象原文；按 (路径, mtime, size) 缓存，避免门禁重复读盘。"""
    try:
        _st = os.stat(path)
        key = (path, int(_st.st_mtime), int(_st.st_size))
    except Exception:
        key = (path, 0, 0)
    if key not in _EVIDENCE_PARSE_CACHE:
        try:
            from ..engine import deepparse as _dp
            parsed = _dp.parse_document(path)
            _EVIDENCE_PARSE_CACHE[key] = (str(getattr(parsed, "text", "") or ""), parsed, "")
        except Exception as e:  # noqa: BLE001
            _EVIDENCE_PARSE_CACHE[key] = ("", None, f"{type(e).__name__}: {e}")
    return _EVIDENCE_PARSE_CACHE[key]


def _evidence_check_quote(quote: str, doc: dict, sheet: str = "", row=None,
                          col: str = "", *, anchor_strength: str = "",
                          anchor_mode: str = "") -> dict:
    """校验单条引文是否逐字命中归属对象的原文/目标单元格。

    多来源证据（汇总/多行命中）生产端可能用“；”拼接：逐段分别校验，全部命中才算命中。
    L71/83 号规格 §9.3：``anchor_strength=cell_verbatim`` 且 quote 严格等于 locator
    单元格原文时允许 min_len=1（开关 RULEPROOF_EVIDENCE_CELL_EXACT_SHORT 默认 1，可回退）。

    L178（2026-11-26）外部 build56 评审 P1③：主链回填的 anchor 会把逐字引文细化到具体
    单元格（Sheet!Cell，如签名占位「X」），但 finding 级 ``anchor_strength`` 可能是
    ``normalized``、``anchor_mode=cell_exact``；历史口径只对 ``cell_verbatim`` 豁免短引文，
    「X」因 min_len=4 被判 quote_not_found → 签名 finding 已检出却被报告门禁降级
    （L167 D12 实测）。修法：显式声明了单元格坐标（sheet+row+col）且定位档为
    ``cell_exact`` 时，短引文按「与声明单元格原文全等」核验（坐标必须真实存在）。
    仅豁免 min_len，不改变「引文必须逐字命中/单元格不得串位」的 fail-closed 口径，
    非单元格证据与不相等引文照旧拒绝。
    """
    from . import manifest_exec as _mex
    _cell_exact = (str(anchor_strength or "") == "cell_verbatim")
    _waiver = False
    if _cell_exact:
        try:
            from . import auditpoints as _ap_w
            _waiver = _ap_w.evidence_cell_exact_short_enabled()
        except Exception:
            _waiver = False
    # L178 P1③：cell_exact 结构化锚点（Sheet!Cell 坐标齐全）的短单元格引文豁免
    if (not _waiver) and sheet and row and col \
            and str(anchor_mode or "") == "cell_exact":
        try:
            from . import auditpoints as _ap_w2
            _waiver = _ap_w2.evidence_cell_exact_short_enabled()
        except Exception:
            _waiver = False
    segs = [s.strip() for s in str(quote or "").split("；") if s.strip()]
    # 多行单元格/整行证据：换行分隔的每行都必须能在同一原文中逐字命中（不跨行拼接）。
    _lines = [ln.strip() for ln in str(quote or "").splitlines() if ln.strip()]
    if len(_lines) > 1 and len(segs) <= 1:
        _doc = doc or {}
        _path = str(_doc.get("path") or "")
        _text, _parsed, _err = _evidence_parse(_path) if _path else ("", None, "missing")
        if _err:
            return {"ok": False, "reason": "quote_unverifiable", "detail": _err}
        _bad = []
        for _ln in _lines:
            _g = _mex_none = None
            from . import manifest_exec as _mex2
            _g = _mex2._verify_quote_in_object(_ln, text=_text, parsed=_parsed,
                                               path=_path, doc=_doc, sheet="",
                                               min_len=1)
            if not _g.get("ok"):
                _bad.append({"line": _ln[:80], "reason": _g.get("reason")})
        if _bad:
            return {"ok": False, "reason": "quote_multiline_not_found", "failed": _bad,
                    "quote": str(quote or "")[:200]}
        return {"ok": True, "scope": "multi_line", "lines": len(_lines),
                "quote": str(quote or "")[:200]}
    if len(segs) > 1:
        _bad = []
        for seg in segs:
            got = _evidence_check_quote(seg, doc, sheet, row, col,
                                        anchor_strength=anchor_strength,
                                        anchor_mode=anchor_mode)
            if not got.get("ok"):
                _bad.append({"segment": seg[:120], "reason": got.get("reason")})
        if _bad:
            return {"ok": False, "reason": "quote_segment_not_found",
                    "segments": len(segs), "failed_segments": _bad,
                    "quote": str(quote or "")[:200]}
        return {"ok": True, "scope": "multi_quote", "segments": len(segs),
                "quote": str(quote or "")[:200]}
    doc = doc or {}
    path = str(doc.get("path") or "")
    text, parsed, err = _evidence_parse(path) if path else ("", None, "document_path_missing")
    if err:
        return {"ok": False, "reason": "quote_unverifiable", "detail": err}
    # 多行整行证据（例如 xlsx 签名标签行+值行）：逐单元格 token 均须在原文出现；
    # 这比整段跨行字符串匹配更符合“原文可复核”，同时不伪造不存在的 token。
    if "\n" in str(quote or ""):
        _toks = [t.strip() for t in str(quote).replace("\n", "|").split("|") if t.strip()]
        if len(_toks) >= 2 and all(t in text for t in _toks):
            return {"ok": True, "scope": "multi_line_tokens", "tokens": len(_toks),
                    "quote": str(quote or "")[:200]}
    got = _mex._verify_quote_in_object(
        quote, text=text, parsed=parsed, path=path, doc=doc, sheet=str(sheet or ""),
        min_len=(1 if (_waiver and sheet and row) else _mex._QUOTE_MIN_LEN),
        allow_short_exact=bool(_waiver and sheet and row))
    if not got.get("ok"):
        return got
    # 锚点声明了单元格坐标时，必须在该单元格内逐字命中（防“同 sheet 不同格串位”）
    if sheet and row:
        if not _mex._cell_quote_hit(path, str(sheet), row, str(col or ""), quote,
                                    allow_short_exact=bool(_waiver)):
            return {"ok": False, "reason": "quote_cell_mismatch",
                    "locator": f"{sheet}!{str(col or '')}{row}",
                    "quote": str(quote or "")[:200]}
    return got


def _evidence_finding_quotes(f: dict) -> list:
    """finding 的证据引文明细（evidence+anchor；同一引文去重）。"""
    out, seen = [], set()
    try:
        evs = R.evidences.list("finding_id=?", (((f or {}).get("id") or ""),))
    except Exception:
        evs = []
    _strength = str((f or {}).get("anchor_strength") or "")
    for ev in evs or []:
        a = {}
        try:
            a = R.anchors.get(ev.get("anchor_id") or "") or {}
        except Exception:
            a = {}
        q = str(ev.get("excerpt") or a.get("quote") or "").strip()
        item = {"quote": q, "sheet": str(a.get("sheet") or ""),
                "row": a.get("row"), "col": str(a.get("col") or ""),
                "locator": str(a.get("locator") or ""),
                "document_id": str(ev.get("document_id") or a.get("document_id") or ""),
                "anchor_strength": _strength,
                "anchor_mode": str((f or {}).get("anchor_mode") or "")}
        sig = (item["quote"], item["sheet"], item["row"], item["col"], item["document_id"])
        if sig in seen:
            continue
        seen.add(sig)
        out.append(item)
    # L71：finding 级 verbatim_quote 优先参与核验（回填成功但 anchor 仍写摘要的旧数据）
    fv = str((f or {}).get("verbatim_quote") or "").strip()
    if fv and not any(q["quote"] == fv for q in out):
        out.insert(0, {"quote": fv, "sheet": "", "row": None, "col": "",
                       "locator": "", "document_id": str((f or {}).get("object_id") or ""),
                       "anchor_strength": _strength,
                       "anchor_mode": str((f or {}).get("anchor_mode") or "")})
    return out


def _evidence_manifest_sub(f: dict) -> tuple:
    """该 finding 在 manifest_result 中对应的子要求记录与合法引文集合。

    返回 (sub_dict, allowed_quotes, sub_id)；无法判定返回 ({}, [], "")。
    归属按 subrequirement_id（含 occurrence 后缀）精确匹配，不按 rule_code/引文前缀归并。
    """
    rid = str((f or {}).get("manifest_result_id") or "")
    if not rid:
        return {}, [], ""
    try:
        c = db.connect()
        try:
            row = c.execute("SELECT d4_json FROM manifest_result WHERE id=?", (rid,)).fetchone()
        finally:
            c.close()
    except Exception:
        return {}, [], ""
    if not row:
        return {}, [], ""
    try:
        d4 = json.loads(row["d4_json"] or "{}")
    except Exception:
        d4 = {}
    subs = d4.get("subs") or []
    sub_id = str((f or {}).get("subrequirement_id") or "")
    base = sub_id.split("#", 1)[0]
    hit = None
    for s in subs:
        sid = str((s or {}).get("id") or "")
        if sub_id and (sid == sub_id or sid.split("#", 1)[0] == base):
            hit = s
            break
    if hit is None and len(subs) == 1:
        hit = subs[0]
    if hit is None:
        return {}, [], ""

    def _quotes(s: dict) -> list:
        out = []
        tt = (s or {}).get("tool_trace") or {}
        for q in ((s or {}).get("quote"), tt.get("quote"), tt.get("source_quote"),
                  tt.get("raw")):
            v = str(q or "").strip()
            if v and v not in out:
                out.append(v)
        return out

    return hit, _quotes(hit), str(hit.get("id") or "")


def _evidence_manifest_sub_quotes(f: dict) -> tuple:
    """兼容旧调用：返回 (合法引文集合, sub_id)。"""
    _sub, quotes, sid = _evidence_manifest_sub(f)
    return quotes, sid


# ---------------------------------------------------------------------------
# L167（2026-11-25）证据门禁「引文支撑结论」类型化校验（build56 §4 D2 假证据）
#
# 缺陷：证据门禁只校验「引文在原文逐字出现」（quote_verbatim_in_source），不校验
#   引文是否**支撑该子要求结论**。D2 实测：RW20260525002 判「签名 为 X/空」，
#   引文却是版本号行（与签名无关）→ 门禁 passed=true，假证据掩盖误报。
# 修复：对签名/版本号/占位符类结论做类型化校验——
#   · 签名占位结论：引文必须含签名/签署/签文字段，或对应签名角色（研发经理/生产经理/
#     品管经理/研发）——只有版本号、日期等无关文本 → 拒绝；
#   · 版本号占位结论：引文必须含版本号/版本字段；
#   · 通用占位符结论：引文必须含对应字段/角色或空值标记（X/空/待填/未填…）。
# 不满足 → 降级 insufficient（need_evidence，转人工），不再伪装 fail 证据。
# 开关 RULEPROOF_EVIDENCE_SUPPORT_GATE（默认 1；=0 逐字回退旧口径，A/B 与回滚）。
# 只影响签名/版本号/占位符类引文型 fail 证据；其它规则（数值/限值/一致性…）不进入
# 本校验（claim 为空直接放行），不改变判定语义。
# ---------------------------------------------------------------------------
_EVIDENCE_SUPPORT_ENV = "RULEPROOF_EVIDENCE_SUPPORT_GATE"
_SUPPORT_SIG_ROLES = ("研发经理", "生产经理", "品管经理", "研发")
_SUPPORT_SIG_FIELD_WORDS = ("签名", "签署", "签字")
_SUPPORT_VERSION_WORDS = ("版本号", "版本")
# claim 关键值提示（占位/空/未填/X 等）
_SUPPORT_VALUE_HINT = r"(?:占位|为空|空值|空|未填|未签|待填|待签|[XxＸⅩ])"
_CLAIM_SIG_RE = re.compile(
    r"(?:签名|签署|签字)[^。；\n]{0,16}" + _SUPPORT_VALUE_HINT +
    r"|" + _SUPPORT_VALUE_HINT + r"[^。；\n]{0,16}(?:签名|签署|签字)")
_CLAIM_VERSION_RE = re.compile(
    r"(?:版本号|版本)[^。；\n]{0,16}" + _SUPPORT_VALUE_HINT +
    r"|" + _SUPPORT_VALUE_HINT + r"[^。；\n]{0,16}(?:版本号|版本)")
_CLAIM_GENERIC_RE = re.compile(r"占位符|占位|待填|未填|空值")
# 引文中的签名角色（角色必须是独立词：前/后不能紧跟中英文字母，防正文"研发部"误命中）
_SUPPORT_SIG_ROLE_RE = re.compile(
    r"(?:^|[^A-Za-z\u4e00-\u9fff])"
    r"(研发经理|生产经理|品管经理|研发(?!经理))"
    r"(?=$|[^A-Za-z\u4e00-\u9fff])")
_SUPPORT_MARKER_RE = re.compile(
    r"(?:^|[^A-Za-z0-9])(?:X|Ｘ|Ⅹ|待填|待签|未填|未签|空|空白|N/A)(?:$|[^A-Za-z0-9])")


def _evidence_support_gate_on() -> bool:
    """L167 引文支撑结论门禁开关（默认 1；=0 逐字回退旧口径）。"""
    return str(os.environ.get(_EVIDENCE_SUPPORT_ENV, "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _evidence_claim_kind(f: dict, sub: dict) -> str:
    """结论类型：signature / version / placeholder / ""（不属这些类→不做支撑校验）。

    只读取**结论文本**（D4 子要求 detail / finding summary/description），不读规则名/
    title（规则名「版本号/签名非占位符」同时含两类字段，会把两类结论都误判为 placeholder）。
    """
    parts = []
    if isinstance(sub, dict):
        parts.append(str(sub.get("detail") or ""))
        tt = sub.get("tool_trace") or {}
        if isinstance(tt, dict):
            parts.append(str(tt.get("detail") or ""))
            labels = tt.get("labels") or sub.get("labels") or []
            if isinstance(labels, (list, tuple)):
                parts.extend(str(x or "") for x in labels)
    for key in ("summary", "description"):
        parts.append(str((f or {}).get(key) or ""))
    text = " ".join(p for p in parts if p)
    sig = bool(_CLAIM_SIG_RE.search(text))
    ver = bool(_CLAIM_VERSION_RE.search(text))
    if sig and ver:
        return "placeholder"
    if sig:
        return "signature"
    if ver:
        return "version"
    if _CLAIM_GENERIC_RE.search(text):
        return "placeholder"
    return ""


def _evidence_quote_supporting(claim: str, quotes: list) -> dict:
    """类型化校验引文是否支撑结论；返回 {ok, claim, reason, detail, quote}。"""
    qs = [str(q or "").strip() for q in (quotes or []) if str(q or "").strip()]
    if not claim or not qs:
        return {"ok": True, "claim": claim, "checked": 0}
    if claim == "signature":
        for q in qs:
            if any(k in q for k in _SUPPORT_SIG_FIELD_WORDS) \
                    or bool(_SUPPORT_SIG_ROLE_RE.search(q)):
                return {"ok": True, "claim": claim, "quote": q[:200],
                        "reason": "quote_supports_signature"}
        return {"ok": False, "claim": claim,
                "reason": "quote_not_supporting_signature",
                "detail": "签名占位结论的引文未包含签名/签署/签字字段或签名角色，"
                          "只有版本号/日期等无关文本不能作为签名结论证据",
                "quote": qs[0][:200]}
    if claim == "version":
        for q in qs:
            if any(k in q for k in _SUPPORT_VERSION_WORDS):
                return {"ok": True, "claim": claim, "quote": q[:200],
                        "reason": "quote_supports_version"}
        return {"ok": False, "claim": claim,
                "reason": "quote_not_supporting_version",
                "detail": "版本号占位结论的引文未包含版本号/版本字段，不能作为版本结论证据",
                "quote": qs[0][:200]}
    # placeholder：字段/角色/空值标记任一即可
    for q in qs:
        if any(k in q for k in _SUPPORT_SIG_FIELD_WORDS) \
                or bool(_SUPPORT_SIG_ROLE_RE.search(q)) \
                or any(k in q for k in _SUPPORT_VERSION_WORDS) \
                or bool(_SUPPORT_MARKER_RE.search(q)):
            return {"ok": True, "claim": claim, "quote": q[:200],
                    "reason": "quote_supports_placeholder"}
    return {"ok": False, "claim": claim,
            "reason": "quote_not_supporting_conclusion",
            "detail": "占位符结论的引文未包含对应字段/角色或空值标记，不能作为证据",
            "quote": qs[0][:200]}


def _evidence_support_gate(f: dict, sub: dict, quotes: list) -> dict:
    """L167 证据门禁支持性判断（开关关闭时恒放行）。

    返回 {ok, claim, reason, detail, quote}；ok=False 由调用方降级 insufficient。
    """
    if not _evidence_support_gate_on():
        return {"ok": True, "claim": "", "checked": 0, "reason": "support_gate_off"}
    claim = _evidence_claim_kind(f, sub)
    got = _evidence_quote_supporting(claim, quotes)
    got["checked"] = len([q for q in (quotes or []) if str(q or "").strip()])
    return got


# 缺失型证据关键词：这类 fail 的“证据”是字段/对象是否存在，不能要求 quote
_MISSING_EVIDENCE_HINTS = re.compile(
    r"缺失|未提供|未附|未标注|未注明|无规格|缺少|未包含|未写明|无相关|未找到|未见|未签字|未盖章")


def _finding_evidence_type(f: dict, quotes: list) -> str:
    """证据四分类：quote / missing / computation / relation。

    优先级：manifest 子要求执行器 > 缺失型语义 > 有引文=quote > 无引文=missing。
    """
    sub, _allowed, _sid = _evidence_manifest_sub(f)
    tt = (sub or {}).get("tool_trace") or {}
    ex = str(tt.get("executor") or "")
    if ex == "tool" or (sub or {}).get("amount_sources") or (sub or {}).get("tax_sources"):
        return "computation"
    if ex == "decision_table" or str((sub or {}).get("raw_state") or "").startswith("decision_table"):
        return "relation"
    title_desc = f"{f.get('title') or ''} {f.get('summary') or ''}"
    if _MISSING_EVIDENCE_HINTS.search(title_desc):
        return "missing"
    if quotes:
        return "quote"
    return "missing"


def _evidence_computation_trace(f: dict) -> dict:
    """计算证据：必须能拿到可复核的输入/结果轨迹（不能拿 quote 表达计算）。"""
    sub, _allowed, _sid = _evidence_manifest_sub(f)
    tt = (sub or {}).get("tool_trace") or {}
    trace = {k: tt.get(k) for k in
             ("executor", "tool", "input", "extracted", "normalized", "value", "result",
              "occurrences", "amount_sources", "tax_sources", "aggregation", "code")
             if tt.get(k) not in (None, "", {}, [])}
    has_result = any(tt.get(k) not in (None, "", {}, []) for k in
                     ("result", "value", "extracted", "normalized", "amount", "days",
                      "total", "diff"))
    return {"found": bool(has_result), "trace": trace}


def _evidence_relation_ref(f: dict) -> dict:
    """关系证据：决策表命中行/跨对象关系。

    定位缺失是结构化 presence（架构约束 2：缺失字段不以 quote 表达），
    保留 fail 结论并在报告显示“原文定位缺失”；声明已定位时才校验原文/单元格。
    """
    sub, _allowed, _sid = _evidence_manifest_sub(f)
    tt = (sub or {}).get("tool_trace") or {}
    loc = str(tt.get("source_locator") or "")
    src_quote = str(tt.get("source_quote") or "")
    row = tt.get("source_row")
    missing = bool(tt.get("source_location_missing"))
    presence = None
    if missing:
        presence = {"found": False,
                    "search_scope": ("sheet" if tt.get("source_sheet") else "document"),
                    "source_reason": str(tt.get("source_reason") or "not_found"),
                    "parse_completeness": {"parsed": True},
                    "facts": bool(tt.get("facts"))}
    return {"found": bool(loc or row or src_quote or missing or tt.get("facts")),
            "locator_missing": missing, "presence": presence,
            "locator": loc, "row": row, "sheet": tt.get("source_sheet") or "",
            "quote": src_quote[:200]}


def _evidence_presence(f: dict, ex_type: str) -> dict:
    """缺失型证据结构化字段：presence / 搜索范围 / 解析完整性（禁止用空 quote 表达缺失）。"""
    docs = []
    try:
        docs = [d for d in R.cases.documents(str(f.get("case_id") or "")) if (d or {}).get("id")]
    except Exception:
        docs = []
    path = ""
    if len(docs) == 1:
        path = str(docs[0].get("path") or "")
    parse_ok, parse_err = False, ""
    if path:
        try:
            _text, _parsed, parse_err = _evidence_parse(path)
            parse_ok = not parse_err
        except Exception as e:  # noqa: BLE001
            parse_err = f"{type(e).__name__}: {e}"
    return {"evidence_type": ex_type,
            "presence": {"found": False, "search_scope": "document"},
            "search_scope": "document" if docs else "no_document",
            "parse_completeness": {"parsed": bool(parse_ok),
                                   "format": (path.rsplit(".", 1)[-1].lower()
                                              if "." in path else ""),
                                   "error": str(parse_err or "")[:200]},
            "searched_object_count": len(docs)}


def _evidence_verify_finding(f: dict, docs_by_id: dict, docs: list) -> dict:
    """校验一条 fail finding 的证据（按证据四分类分别核验，不把缺失当引文）。"""
    quotes = _evidence_finding_quotes(f)
    nonempty = [q for q in quotes if q["quote"]]
    ex_type = _finding_evidence_type(f, nonempty)
    # 归属对象：finding.object_id 优先；否则证据/锚点 document_id；单文档兜底
    _obj = str(f.get("object_id") or "")
    if _obj:
        doc = docs_by_id.get(_obj) or {}
    else:
        doc = {}
        for q in quotes:
            did = str(q.get("document_id") or "")
            if did and did in docs_by_id:
                doc = docs_by_id[did]
                break
        if not doc and len(docs or []) == 1:
            doc = docs[0] or {}
    if ex_type == "missing":
        # 缺失型：不以 quote 表达；保留 fail 但 certainty 不得超过 probable，
        # 并写入 presence/搜索范围/解析完整性，供人工复核。
        return {"ok": True, "reason": "evidence_type_missing_presence",
                "evidence_type": "missing", "quotes": [q["quote"] for q in nonempty],
                "presence": _evidence_presence(f, "missing"),
                "document": str((doc or {}).get("filename") or "")}
    if ex_type == "computation":
        got = _evidence_computation_trace(f)
        if got.get("found"):
            return {"ok": True, "reason": "computation_trace_present",
                    "evidence_type": "computation", "trace": got["trace"],
                    "quotes": [q["quote"] for q in nonempty],
                    "document": str((doc or {}).get("filename") or "")}
        return {"ok": False, "reason": "computation_evidence_missing",
                "evidence_type": "computation",
                "quotes": [q["quote"] for q in nonempty],
                "presence": _evidence_presence(f, "computation"),
                "document": str((doc or {}).get("filename") or "")}
    if ex_type == "relation":
        rel = _evidence_relation_ref(f)
        if not rel.get("found"):
            return {"ok": False, "reason": "relation_evidence_missing",
                    "evidence_type": "relation",
                    "quotes": [q["quote"] for q in nonempty],
                    "presence": _evidence_presence(f, "relation"),
                    "document": str((doc or {}).get("filename") or "")}
        # 定位缺失：结构化 presence 证据，保留 fail（报告显式“原文定位缺失”）
        if rel.get("locator_missing"):
            return {"ok": True, "reason": "relation_source_missing_presence",
                    "evidence_type": "relation", "presence": rel.get("presence"),
                    "locator": "", "quotes": [q["quote"] for q in nonempty],
                    "document": str((doc or {}).get("filename") or "")}
        # 关系证据若带原文，引文仍需逐字命中
        if nonempty:
            for q in nonempty:
                got = _evidence_check_quote(q["quote"], doc, q.get("sheet") or "",
                                            q.get("row"), q.get("col") or "",
                                            anchor_strength=q.get("anchor_strength") or "",
                                            anchor_mode=q.get("anchor_mode") or "")
                if not got.get("ok"):
                    return {"ok": False, "reason": got.get("reason") or "quote_not_found",
                            "evidence_type": "relation",
                            "quotes": [q["quote"] for q in nonempty],
                            "locator": rel.get("locator") or "",
                            "document": str((doc or {}).get("filename") or "")}
        return {"ok": True, "reason": "relation_located",
                "evidence_type": "relation", "locator": rel.get("locator") or "",
                "quotes": [q["quote"] for q in nonempty],
                "document": str((doc or {}).get("filename") or "")}
    # quote 型：必须逐字命中归属对象原文/单元格
    if not nonempty:
        return {"ok": False, "reason": "quote_missing", "evidence_type": "quote",
                "quotes": [], "document": ""}
    if not doc:
        return {"ok": False, "reason": "attribution_missing", "evidence_type": "quote",
                "quotes": [q["quote"] for q in nonempty], "document": ""}
    target_path = str(doc.get("path") or "")
    _failed_instances = []
    for q in nonempty:
        got = _evidence_check_quote(q["quote"], doc, q.get("sheet") or "",
                                    q.get("row"), q.get("col") or "",
                                    anchor_strength=q.get("anchor_strength") or "",
                                    anchor_mode=q.get("anchor_mode") or "")
        if got.get("ok"):
            continue
        _failed_instances.append({"quote": str(q.get("quote") or "")[:200],
                                  "locator": str(q.get("locator") or ""),
                                  "reason": got.get("reason") or "quote_not_found"})
    # L71/83 号 §7 多实例：失败实例不得拖累已证实例（finding 保留 fail + multi_instance_partial，
    # 逐实例证据/证书；失败实例单列供报告标注“部分实例证据不足”）。仅对已标记 partial 的
    # finding 生效，其余仍保持“全部引文必须逐字命中”的原有 fail-closed 口径（不普遍放宽）。
    if (_failed_instances
            and str((f or {}).get("backfill_status") or "") == "multi_instance_partial"
            and len(_failed_instances) < len(nonempty)):
        return {"ok": True, "reason": "quote_partial_instances_verified",
                "evidence_type": "quote", "partial_instances": _failed_instances,
                "verified_instances": len(nonempty) - len(_failed_instances),
                "quotes": [q["quote"] for q in nonempty],
                "document": str(doc.get("filename") or target_path)}
    if _failed_instances:
        got = {"reason": _failed_instances[0].get("reason") or "quote_not_found"}
        q = next((x for x in nonempty
                  if str(x.get("quote") or "") == _failed_instances[0].get("quote")),
                 nonempty[0])
        # 串位分类：其它对象能命中 → 跨文件串位；否则原文不存在
        other = ""
        for did, d in (docs_by_id or {}).items():
            if str(did) == str(doc.get("id") or ""):
                continue
            try:
                if _evidence_check_quote(q["quote"], d).get("ok"):
                    other = str((d or {}).get("filename") or did)
                    break
            except Exception:
                continue
        return {"ok": False,
                "reason": ("quote_other_object" if other
                           else (got.get("reason") or "quote_not_found")),
                "evidence_type": "quote",
                "found_in": other, "quotes": [q["quote"] for q in nonempty],
                "document": str(doc.get("filename") or target_path)}
    # 归属子要求：与 manifest_result 该子要求引文一致，防“同对象不同子要求串位”
    allowed, sub_id = _evidence_manifest_sub_quotes(f)
    if allowed:
        for q in nonempty:
            if not _rea_quote_matches_sub(q["quote"], allowed):
                return {"ok": False, "reason": "quote_sub_mismatch",
                        "evidence_type": "quote",
                        "expected_sub": sub_id, "quotes": [q["quote"] for q in nonempty],
                        "document": str(doc.get("filename") or target_path)}
    # L167：引文逐字 ≠ 引文支撑结论。签名/版本号/占位符类结论做类型化支撑校验：
    # 引文不含对应字段/角色/空值标记（如签名结论却引版本号行）→ 拒绝，降级转人工。
    _sup_sub = _evidence_manifest_sub(f)[0]
    _sup = _evidence_support_gate(f, _sup_sub, [q["quote"] for q in nonempty])
    if not _sup.get("ok"):
        return {"ok": False, "reason": _sup.get("reason"),
                "evidence_type": "quote", "claim": _sup.get("claim"),
                "detail": _sup.get("detail"),
                "quotes": [q["quote"] for q in nonempty],
                "document": str(doc.get("filename") or target_path)}
    return {"ok": True, "reason": "quote_verbatim_in_source", "evidence_type": "quote",
            "locator": (nonempty[0].get("locator") or ""),
            "document": str(doc.get("filename") or target_path),
            "quotes": [q["quote"] for q in nonempty]}


def enforce_evidence_quotes(case_id: str, persist: bool = True) -> dict:
    """报告/工作台读取前的证据门禁：fail finding 引文不逐字命中 → 降级人工复核。

    - 幂等：已降级（summary 带“证据门禁”且 status=need_evidence）不重复写；
    - persist=False 仅检查不落库（用于只读展示）；
    - 返回 {checked, verified, downgraded:[{id,rule_code,reason,quote}], skipped_legacy}
    """
    case = R.cases.get(case_id) or {}
    if not case:
        return {"checked": 0, "verified": 0, "downgraded": [], "skipped_legacy": 0}
    docs = [d for d in R.cases.documents(case_id) if (d or {}).get("id")]
    docs_by_id = {str(d.get("id")): d for d in docs}
    try:
        rows = [f for f in R.findings.by_case(case_id)
                if str(f.get("status") or "") not in ("superseded", "false_positive")]
    except Exception:
        rows = []
    out = {"checked": 0, "verified": 0, "downgraded": [], "skipped_legacy": 0,
           "certainty_capped": 0, "evidence_types": {}, "presence": []}
    for f in rows:
        if str(f.get("state") or "") != "fail":
            continue
        engine = str(f.get("engine") or "")
        if engine in _EVIDENCE_EXEMPT_ENGINES or engine.startswith("manual"):
            continue
        # 主链 finding（manifest/客户规则/平台点位/多文件 fact-merged）才强制；
        # 无任何证据的旧链路数据跳过并计数（DU-08：fact-merged 已显式进白名单）。
        main_chain = bool(
            str(f.get("manifest_result_id") or "") or str(f.get("object_id") or "")
            or _is_main_chain_engine(engine))
        quotes = _evidence_finding_quotes(f)
        if not quotes and not main_chain:
            out["skipped_legacy"] += 1
            continue
        out["checked"] += 1
        if not quotes and str(engine or "").strip().lower().startswith("fact-merged"):
            # DU-08：fact-merged 写入路径不持久化任何证据行（引文只存在于返回 dict）。
            # 无证据即不得判 fail：直接按 quote_missing 降级 insufficient，
            # 不能走 _finding_evidence_type 的“缺失型证据”分支把无证据 fail 放行。
            got = {"ok": False, "reason": "quote_missing", "evidence_type": "quote",
                   "quotes": [], "document": ""}
        else:
            got = _evidence_verify_finding(f, docs_by_id, docs)
        _etype = str(got.get("evidence_type") or "quote")
        out["evidence_types"][_etype] = out["evidence_types"].get(_etype, 0) + 1
        if got.get("ok"):
            out["verified"] += 1
            if _etype == "missing":
                # 缺失型证据不以 quote 表达：保留主链 fail 结论，但 certainty 不得超过 probable
                if str(f.get("certainty") or "") == "certain" and persist:
                    try:
                        R.findings.update(
                            f.get("id"), certainty="probable",
                            summary=(str(f.get("summary") or "")
                                     + "；证据类型：missing（字段/对象缺失，不以引文表达；"
                                       "presence/搜索范围/解析完整性已结构化记录）")[:2000])
                        out["certainty_capped"] += 1
                    except Exception:
                        logging.getLogger(__name__).debug("missing certainty cap skipped",
                                                          exc_info=True)
                out["presence"].append({"id": str(f.get("id") or ""),
                                        **_evidence_presence(f, "missing")})
            continue
        item = {"id": str(f.get("id") or ""), "rule_code": str(f.get("rule_id") or ""),
                "reason": got.get("reason") or "quote_not_found",
                "evidence_type": _etype,
                "quote": ((got.get("quotes") or [""])[0] or "")[:200],
                "document": got.get("document") or "",
                "found_in": got.get("found_in") or "",
                "presence": got.get("presence") or None}
        out["downgraded"].append(item)
        if not persist:
            continue
        _summary = str(f.get("summary") or "")
        if _EVIDENCE_GATE_MARK in _summary and str(f.get("status")) == "need_evidence":
            continue
        _why = {
            "quote_missing": "fail 结论没有逐字引文",
            "quote_not_found": "引文在归属对象原文中找不到",
            "quote_other_object": "引文命中其它文件内容（跨文件串位）",
            "quote_wrong_sheet": "引文命中其它 sheet（跨 sheet 串位）",
            "quote_cell_mismatch": "引文未命中声明的单元格",
            "quote_sub_mismatch": "引文与所属子要求不一致（子要求串位）",
            "attribution_missing": "无法确认引文归属对象",
            "quote_unverifiable": "归属对象无法解析，引文无法核验",
            "computation_evidence_missing": "计算类证据缺少可复核的输入/结果轨迹",
            "relation_evidence_missing": "关系类证据缺少可回查的定位/对象关系",
            "quote_not_supporting_signature": "签名结论的引文不含签名/签署字段或签名角色",
            "quote_not_supporting_version": "版本号结论的引文不含版本号/版本字段",
            "quote_not_supporting_conclusion": "引文不支撑该占位符结论（字段/角色/空值标记均缺失）",
        }.get(item["reason"], "引文未逐字命中归属对象原文/单元格")
        _new_summary = (_summary + "；" if _summary else "") + \
            f"{_EVIDENCE_GATE_DETAIL}（{_why}）"
        try:
            R.findings.update(f.get("id"), state="insufficient", certainty="abstain",
                              confidence=None, status="need_evidence", summary=_new_summary[:2000])
        except Exception:
            logging.getLogger(__name__).warning("evidence quote downgrade failed", exc_info=True)
            continue
        try:
            R.audit_logs.log(
                actor="system", action="evidence.quote_downgraded", object=str(f.get("id") or ""),
                after=json.dumps({"reason": item["reason"],
                                  "evidence_type": item.get("evidence_type") or "",
                                  "quote": item["quote"],
                                  "document": item["document"], "found_in": item["found_in"],
                                  "presence": item.get("presence"),
                                  "from_certainty": str(f.get("certainty") or "")},
                                 ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("evidence downgrade audit skipped", exc_info=True)
    return out


def _apply_fail_quote_gate_to_findings(findings: list, path: str) -> list:
    """审核出口门禁：fail 证据按四分类核验（引文/缺失/计算/关系），不把缺失当引文。

    - 引文型：必须逐字命中本对象原文/单元格，不命中 → insufficient + 人工复核；
    - 缺失型（字段/对象缺失）：不以 quote 表达，附 presence/搜索范围/解析完整性；
    - 计算/关系型：由 manifest D4 tool_trace 在读取侧核验（此处只标注类型）；
    不命中 → state=insufficient + 证据门禁标记（阻断 certainty=certain 的 fail 结论），
    由报告门禁二次阻断，不允许“模型幻觉引文”直接成为正式发现。
    """
    if not findings or not path:
        return findings or []
    doc = {"path": path, "id": "", "filename": os.path.basename(path)}
    doc["doc_type"] = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    _parsed_ok = False
    try:
        _text, _parsed, _err = _evidence_parse(path)
        _parsed_ok = not _err
    except Exception:
        _parsed_ok = False
    # L71 P2a：读取侧先按 locations[] 回填逐字证据（写入路径同一函数，读取=写入口径），
    # 回填成功后门禁读 verbatim_quote/locations[] 而非摘要，避免 16/16 误杀。
    try:
        from . import auditpoints as _ap_bk_gate
        _bk_gate_on = _ap_bk_gate.evidence_backfill_enabled()
    except Exception:
        _ap_bk_gate = None
        _bk_gate_on = False
    for f in findings:
        if not isinstance(f, dict):
            continue
        lvl = str(f.get("level") or "")
        org = str(f.get("origin") or "")
        if lvl in ("unknown", "info") or org in ("model_unavailable", "customer_rule_failed"):
            # DU-08（2026-11-25）：这些不是“已核验失败”结论（unknown=未执行/无结论），
            # 不显式标 fail；缺省 state 由持久层 ``_norm_finding_state`` 归一为
            # insufficient（fail-safe），不得再依赖旧“空值→fail”回退。
            continue
        # DU-08（2026-11-25）：通过证据四分类核验的 finding 在审核出口**显式**标注
        # state=fail。旧实现依赖 ``project._norm_finding_state`` 的空值回退默认 fail；
        # DU-08 把该回退改为 fail-safe insufficient 后，必须由本出口显式声明结论，
        # 否则真实不满足会被误物化为“证据不足”。证据不达标者在下文改标 insufficient。
        if not str(f.get("state") or "").strip():
            f["state"] = "fail"
        if _bk_gate_on:
            try:
                _bk = _ap_bk_gate.attach_finding_quote_fields(
                    f, _text, locations=f.get("locations") or [], doc_path=path)
                if str(_bk.get("backfill_status") or "") in ("ok", "multi_instance_partial"):
                    f.update({k: _bk.get(k) for k in (
                        "verbatim_quote", "char_start", "char_end", "anchor_mode",
                        "anchor_source", "anchor_strength", "text_profile",
                        "quote_summary", "backfill_status", "backfill_reason",
                        "backfill_version", "locations", "primary_locator",
                        "primary_sheet", "primary_row", "primary_col",
                        "issue_identity")})
                    f["quote"] = str(_bk.get("verbatim_quote") or "")
                elif str(_bk.get("backfill_status") or "") == "failed":
                    f["backfill_status"] = "failed"
                    f["backfill_reason"] = str(_bk.get("backfill_reason") or "")
                _ap_bk_gate.downgrade_finding_for_backfill(f, _bk)
            except Exception:  # 铁律 2：回填异常不阻断既有门禁逻辑
                logging.getLogger(__name__).warning(
                    "quote gate evidence backfill failed: %s", path, exc_info=True)
        locs = list(f.get("locations") or [])
        quotes = [str((loc or {}).get("quote") or "").strip() for loc in locs]
        quotes = [q for q in quotes if q]
        # 缺失型证据：不以引文表达，保留结论并记录 presence/搜索范围/解析完整性
        _title_desc = f"{f.get('title') or f.get('description') or ''}"
        if not quotes and _MISSING_EVIDENCE_HINTS.search(_title_desc):
            f["evidence_type"] = "missing"
            f["evidence_gate"] = {"passed": True, "reason": "evidence_type_missing_presence",
                                  "evidence_type": "missing"}
            f["presence"] = {"found": False, "search_scope": "document",
                             "parse_completeness": {"parsed": bool(_parsed_ok),
                                                    "format": doc.get("doc_type") or ""},
                             "searched_object_count": 1}
            continue
        if quotes and _MISSING_EVIDENCE_HINTS.search(_title_desc) and org == "platform_point":
            f["evidence_type"] = "missing"
        gate = None
        if not quotes:
            gate = {"ok": False, "reason": "quote_missing", "quote": ""}
        else:
            for i, q in enumerate(quotes):
                loc = locs[i] if i < len(locs) else {}
                got = _evidence_check_quote(
                    q, doc, str(loc.get("sheet") or ""),
                    loc.get("row"), str(loc.get("col") or ""),
                    anchor_strength=str(f.get("anchor_strength") or ""),
                    anchor_mode=str(f.get("anchor_mode") or ""))
                if got.get("ok"):
                    gate = got
                    break
                gate = got
        if gate and gate.get("ok"):
            # L167：逐字命中后仍需校验「引文支撑结论」（签名/版本号/占位符类）。
            # 例：签名占位结论引版本号行 —— 文本存在但不是该结论的证据 → 降级转人工。
            try:
                _sup_sub = _evidence_manifest_sub(f)[0]
            except Exception:  # noqa: BLE001 - 子要求读取失败不阻断旧门禁（仅跳过支撑校验）
                _sup_sub = {}
            _sup = _evidence_support_gate(f, _sup_sub, quotes)
            if not _sup.get("ok"):
                gate = {"ok": False, "reason": _sup.get("reason"),
                        "claim": _sup.get("claim"), "detail": _sup.get("detail"),
                        "quote": str((_sup.get("quote") or (quotes[0] if quotes else "")))[:200]}
            else:
                f.setdefault("evidence_type", "quote")
                f["evidence_gate"] = {"passed": True, "reason": "quote_verbatim_in_source",
                                      "locator": gate.get("locator") or "",
                                      "scope": gate.get("scope") or "document"}
                if _sup.get("claim"):
                    f["evidence_gate"]["claim"] = _sup.get("claim")
                continue
        gate = gate or {"ok": False, "reason": "quote_not_found"}
        f["evidence_type"] = f.get("evidence_type") or "quote"
        f["state"] = "insufficient"
        f["evidence_gate"] = {"passed": False, "reason": gate.get("reason") or "quote_not_found",
                              "evidence_type": f.get("evidence_type"),
                              "claim": gate.get("claim") or "",
                              "quote": str(gate.get("quote") or (quotes[0] if quotes else ""))[:200],
                              "detail": gate.get("detail") or _EVIDENCE_GATE_DETAIL}
        f["evidence_ok"] = False
        f["requires_manual"] = True
        _desc = str(f.get("description") or f.get("detail") or "")
        if _EVIDENCE_GATE_MARK not in _desc:
            f["description"] = (_desc + "；" if _desc else "") + _EVIDENCE_GATE_DETAIL
    return findings


def _rea_access(case_id: str, actor: str = "", role: str = "", action: str = "review"):
    """重判/时间线职责校验；未显式传身份时保持服务层兼容调用。

    返回 None 表示放行，否则返回统一 deny payload。
    """
    actor = str(actor or "").strip()
    role = str(role or "").strip()
    if not actor and not role:
        return None
    if role in ("super_admin", "platform_op"):
        return {"error": "系统管理员/平台账号仅限平台层，不能进入业务重判或报告",
                "code": "forbidden", "status": 403}
    if role == "admin" and str(action or "") != "view":
        return {"error": "业务管理员只读：不能重判", "code": "forbidden", "status": 403}
    if not case_id:
        # 没有 manifest→案例映射的合成结果：只允许 reviewer 声明继续，无法做归属校验
        if str(action or "") == "review" and role == "reviewer":
            return None
        return {"error": "项目不存在", "code": "not_found", "status": 404}
    access = authorize_case(case_id, action, actor, role)
    if not access.get("ok"):
        return _deny_payload(access)
    return None


def _rea_load_result(result_id: str) -> dict:
    """读取 manifest_result，并带出所属案例；找不到返回空。"""
    if not result_id:
        return {}
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT mr.*, m.case_id AS _case_id, m.items_json AS _items_json, "
                "m.objects_json AS _objects_json, m.rules_json AS _rules_json "
                "FROM manifest_result mr LEFT JOIN audit_manifest m ON m.id=mr.manifest_id "
                "WHERE mr.id=?", (result_id,)).fetchone()
        return dict(row) if row else {}
    except Exception:
        logging.getLogger(__name__).debug("reaudit result lookup skipped", exc_info=True)
        return {}


def _rea_load_finding(finding_id: str) -> dict:
    try:
        return R.findings.get(finding_id) or {}
    except Exception:
        return {}


def _rea_case_documents(case_id: str) -> list:
    try:
        return R.cases.documents(case_id) or []
    except Exception:
        return []


def _rea_doc_text(doc: dict) -> str:
    """解析单个文档；解析失败返回空串（由调用方显式记 insufficient）。"""
    path = str((doc or {}).get("path") or "")
    if not path or not os.path.exists(path):
        return ""
    try:
        return str(_parsed_cached(path)["doc"].get("text") or "")
    except Exception:
        try:
            from ..engine import deepparse
            return str(deepparse.parse_document(path).text or "")
        except Exception:
            return ""


def _rea_base_text(case_id: str, object_id: str = "") -> tuple:
    """取被审对象原文；优先 object_id 对应文档，找不到再退回项目首文档。"""
    docs = _rea_case_documents(case_id)
    if not docs:
        return "", {}
    chosen = next((d for d in docs if str(d.get("id") or "") == str(object_id or "")), {})
    if not chosen:
        chosen = docs[0]
    text = _rea_doc_text(chosen)
    return text, {"document_id": str(chosen.get("id") or ""),
                  "filename": str(chosen.get("filename") or ""),
                  "path": str(chosen.get("path") or "")}


def _rea_evidence_text(evidence_text: str = "", evidence_ref: str = "",
                       case_id: str = "", object_id: str = "") -> tuple:
    """拼装补证材料：支持原文、document_id、文件路径；ref 无文件时按文本处理。"""
    chunks, sources = [], []
    raw = str(evidence_text or "").strip()
    if raw:
        chunks.append(raw)
        sources.append({"kind": "text", "chars": len(raw)})
    ref = str(evidence_ref or "").strip()
    if ref and ref != raw:
        doc = None
        try:
            doc = R.documents.get(ref)
        except Exception:
            doc = None
        if doc and str(doc.get("path") or ""):
            body = _rea_doc_text(doc)
            if body.strip():
                chunks.append(body)
                sources.append({"kind": "document", "document_id": ref,
                                "filename": doc.get("filename") or "",
                                "chars": len(body)})
            else:
                sources.append({"kind": "document_unparsed", "document_id": ref,
                                "chars": 0})
        elif os.path.exists(ref):
            body = ""
            try:
                with open(ref, "r", encoding="utf-8", errors="ignore") as fh:
                    body = fh.read()
            except Exception:
                body = ""
            if body.strip():
                chunks.append(body)
                sources.append({"kind": "file", "path": ref, "chars": len(body)})
            else:
                sources.append({"kind": "file_unparsed", "path": ref, "chars": 0})
        else:
            # 没有对应文档/文件时按“外部补证文本”处理；是否可信由后续引文核验判定。
            chunks.append(ref)
            sources.append({"kind": "external_text", "chars": len(ref)})
    supplement = "\n\n".join(chunks).strip()
    combined = ""
    base_text, base_meta = _rea_base_text(case_id, object_id)
    if base_text.strip():
        combined = base_text
    if supplement:
        combined = (combined + "\n\n【补证材料】\n" + supplement).strip() if combined else supplement
    return combined, {"supplement": supplement, "base_chars": len(base_text),
                      "supplement_chars": len(supplement), "chars": len(combined),
                      "sources": sources, "base": base_meta,
                      "ref": ref[:500], "has_supplement": bool(supplement)}


def _rea_rule_for_result(result: dict) -> dict:
    rid = str((result or {}).get("rule_id") or "")
    code = str((result or {}).get("rule_code") or "")
    try:
        rule = R.rules.get(rid) if rid else None
        if not rule and code:
            rule = next((x for x in R.rules.list() if str(x.get("code") or "") == code), None)
        return rule or {}
    except Exception:
        return {}


def _rea_rule_slots(rule: dict) -> dict:
    if not rule:
        return {}
    try:
        v = R.rules.published_version(rule.get("id") or "") or {}
        return _rea_dict(v.get("slots_json"))
    except Exception:
        return {}


def _rea_sub_spec(result: dict, sub_id: str, sub_row: dict) -> tuple:
    """找到子要求原始判据；优先 manifest item，其次规则版本 slots。"""
    items = _rea_json((result or {}).get("_items_json"), [])
    item = {}
    obj = str((result or {}).get("object_id") or "")
    code = str((result or {}).get("rule_code") or "")
    for one in (items or []):
        if not isinstance(one, dict):
            continue
        _o = str(one.get("object_id") or "")
        if str(one.get("code") or "") == code and (not _o or _o == obj):
            item = one
            break
    sub_id = str(sub_id or "")
    base_id = sub_id.split("#", 1)[0]
    specs = ((item.get("subrequirements") or item.get("criteria_list")
              or item.get("sub_requirements") or item.get("subs")
              or item.get("requirements") or []) if item else [])
    if not sub_id and len(specs) == 1 and isinstance(specs[0], dict):
        return dict(specs[0]), item
    for one in specs:
        if isinstance(one, dict) and str(one.get("id") or "") == sub_id:
            return dict(one), item
    if base_id and base_id != sub_id:
        for one in specs:
            if isinstance(one, dict) and str(one.get("id") or "") == base_id:
                return dict(one), item
    # 规则版本里的子要求（兼容直接构造 result 的调用方）
    slots = _rea_rule_slots(_rea_rule_for_result(result))
    for key in ("subrequirements", "criteria_list", "sub_requirements", "subs",
                "requirements"):
        for one in (slots.get(key) or []):
            if isinstance(one, dict) and str(one.get("id") or "") in (sub_id, base_id):
                return dict(one), item or {"subrequirements": slots.get(key) or []}
    # result 自身已经带判据时直接用
    if any(k in (sub_row or {}) for k in ("criterion", "requirement", "metric", "tool")):
        return dict(sub_row or {}), item
    # 单子要求规则：规则卡片本身就是判据
    if not specs and not sub_id:
        spec = dict(slots or {})
        if spec.get("criterion") or spec.get("requirement") or spec.get("metric"):
            return spec, item
    return {}, item


def _rea_semantic_judge(rule: dict, spec: dict, text: str, path: str = "",
                        sub_id: str = "") -> dict:
    """真实 agent-judge 单子要求判定；任何不可用/未回验都返回 insufficient。"""
    crit = str((spec or {}).get("criterion") or (spec or {}).get("requirement") or "").strip()
    model_meta = {"provider": "agent-judge", "available": False, "returned": False,
                  "model": "", "reason": ""}
    if not crit:
        return {"status": "insufficient", "detail": "缺少语义判据",
                "reason": "criterion_missing", "quote": "", "confidence": None,
                "model": model_meta, "executor": "agent-judge"}
    if not str(text or "").strip():
        return {"status": "insufficient", "detail": "没有可用于判定的原文/补证文本",
                "reason": "text_missing", "quote": "", "confidence": None,
                "model": model_meta, "executor": "agent-judge"}
    # T-115：空间关闭 mod_agents 时主链不再执行 agent-judge（返回可解释的 insufficient，
    # 与“执行失败”区分，避免报告把模块关闭当成模型异常）。
    if _module_off("mod_agents"):
        model_meta["reason"] = "module_disabled"
        return {"status": "insufficient",
                "detail": "工作空间关闭智能体模块（mod_agents=false），未执行 agent-judge",
                "reason": "module_disabled", "quote": "", "confidence": None,
                "model": model_meta, "executor": "agent-judge"}
    try:
        point = None
        try:
            from .rule_card import audit_point as _apc
            point = _apc(rule or {}, dict(spec or {}))
        except Exception:
            point = None
        if not isinstance(point, dict):
            point = {}
        point.setdefault("name", crit[:80])
        point["id"] = str(sub_id or (spec or {}).get("id") or point.get("id")
                        or (rule or {}).get("code") or "SEMANTIC")
        point["criterion"] = crit[:600]
        if (spec or {}).get("required_evidence") or (spec or {}).get("evidence_required"):
            point["required_evidence"] = str(
                (spec or {}).get("required_evidence") or (spec or {}).get("evidence_required"))
        point.setdefault("required_evidence", "原文逐字证据")
        point.setdefault("level", str((spec or {}).get("level")
                                      or (rule or {}).get("rclass") or "R3"))
        from . import agents as _ag
        import threading as _th
        try:
            _timeout = float(os.environ.get("RULEPROOF_SEMANTIC_TIMEOUT", "60") or 60)
        except Exception:
            _timeout = 60.0
        _box = {}

        def _call_judge():
            try:
                _box["r"] = _ag.run_agent("agent-judge", {
                    "path": path or "", "text": text, "points": [point]})
            except Exception as _e:
                _box["e"] = _e

        _t = _th.Thread(target=_call_judge, daemon=True)
        _t.start()
        _t.join(max(0.1, _timeout))
        if _t.is_alive():
            model_meta["reason"] = f"agent-judge 超时（{_timeout:g}s）"
            return {"status": "insufficient",
                    "detail": f"模型判定超时（{_timeout:g}s），按证据不足处理",
                    "reason": "model_timeout", "quote": "", "confidence": None,
                    "model": model_meta, "executor": "agent-judge"}
        if "e" in _box:
            raise _box["e"]
        rr = _box.get("r")
    except Exception as e:
        model_meta["reason"] = f"{type(e).__name__}: {str(e)[:160]}"
        return {"status": "insufficient", "detail": f"agent-judge 不可用：{model_meta['reason']}",
                "reason": "model_unavailable", "quote": "", "confidence": None,
                "model": model_meta, "executor": "agent-judge"}
    if not isinstance(rr, dict) or rr.get("status") != "ok":
        err = ""
        if isinstance(rr, dict):
            err = str((rr.get("result") or {}).get("error") or rr.get("error") or "")
        model_meta["reason"] = err[:200] or "agent-judge 未返回 ok"
        return {"status": "insufficient", "detail": f"模型不可用：{model_meta['reason']}",
                "reason": "model_unavailable", "quote": "", "confidence": None,
                "model": model_meta, "executor": "agent-judge"}
    model_meta["available"] = True
    model_meta["run_id"] = str((rr or {}).get("run_id") or "")
    try:
        from .. import config as _cfg
        model_meta["model"] = str((_cfg.LLM or {}).get("model") or "")
    except Exception:
        model_meta["model"] = ""
    result_obj = rr.get("result") or {}
    if isinstance(result_obj, list):
        results = result_obj
    else:
        results = result_obj.get("results") or []
    results = [x for x in (results or []) if isinstance(x, dict)]
    item = next((x for x in results
                 if str(x.get("point_id") or "") == str(point.get("id") or "")), None)
    if item is None and results:
        item = results[0]
    if not item:
        model_meta["reason"] = "模型返回空结果"
        return {"status": "insufficient", "detail": "模型未返回该子要求的判定结果",
                "reason": "model_empty_result", "quote": "", "confidence": None,
                "model": model_meta, "executor": "agent-judge"}
    model_meta["returned"] = True
    raw_state = str(item.get("state") or item.get("status")
                    or item.get("conclusion") or "")
    state = _rea_status(raw_state)
    quote = str(item.get("quote") or "").strip()
    detail = str(item.get("rationale") or item.get("reason") or "").strip()[:300]
    conf = item.get("confidence")
    try:
        conf = float(conf) if conf is not None and str(conf).strip() != "" else None
    except Exception:
        conf = None
    if state in ("pass", "fail"):
        if not quote:
            return {"status": "insufficient", "detail": "模型给出结论但未提供逐字引文，按证据不足处理",
                    "reason": "quote_missing", "quote": "", "confidence": conf,
                    "model": model_meta, "executor": "agent-judge",
                    "raw_state": raw_state}
        if not _rea_quote_verified(quote, text):
            return {"status": "insufficient", "detail": "模型引文在本次证据文本中找不到，按证据不足处理",
                    "reason": "quote_not_verified", "quote": quote[:500], "confidence": conf,
                    "model": model_meta, "executor": "agent-judge",
                    "raw_state": raw_state}
        return {"status": state, "detail": detail or ("模型判定满足" if state == "pass"
                                                      else "模型判定不满足"),
                "reason": "model_judged", "quote": quote[:500], "confidence": conf,
                "model": model_meta, "executor": "agent-judge",
                "raw_state": raw_state}
    # 模型返回 unknown/insufficient/na：只接受 insufficient/na，不能换算成 pass/fail
    reason = "model_no_conclusion"
    if ("模型不可用" in detail or "未配置模型" in detail or "未执行" in detail):
        # 执行器把“没有 provider”包装成 unknown；这里如实标记不可用，避免假可用
        model_meta["available"] = False
        model_meta["returned"] = False
        model_meta["model"] = ""
        model_meta["reason"] = detail or "模型不可用"
        reason = "model_unavailable"
    return {"status": state if state in ("insufficient", "na") else "insufficient",
            "detail": detail or "模型未给出可用结论，按证据不足处理",
            "reason": reason, "quote": quote[:500], "confidence": conf,
            "model": model_meta, "executor": "agent-judge",
            "raw_state": raw_state}


def _rea_deterministic_judge(spec: dict, text: str) -> dict:
    """确定性/数值子要求重判；工具子要求缺依赖时显式 insufficient。"""
    model_meta = {"provider": "ruleexec", "available": False, "returned": False,
                  "model": "", "reason": ""}
    spec = dict(spec or {})
    # 兼容 operator/threshold 等常见别名，避免调用方因键名差异被判 insufficient
    if not spec.get("op") and spec.get("operator"):
        spec["op"] = spec.get("operator")
    if spec.get("value") in (None, "") and spec.get("threshold") not in (None, ""):
        spec["value"] = spec.get("threshold")
    if spec.get("value") in (None, "") and spec.get("target") not in (None, ""):
        spec["value"] = spec.get("target")
    if spec.get("tool"):
        return {"status": "insufficient", "detail": f"重判暂不支持工具子要求：{spec.get('tool')}",
                "reason": "unsupported_executor", "quote": "", "confidence": None,
                "model": model_meta, "executor": "tool"}
    if not spec.get("metric"):
        return {"status": "insufficient", "detail": "缺少可执行判据（metric/criterion）",
                "reason": "criterion_missing", "quote": "", "confidence": None,
                "model": model_meta, "executor": "ruleexec"}
    try:
        from ..engine import ruleexec
        jr = ruleexec.judge_rule(spec, text, []) or {}
        state = _rea_status(jr.get("state"))
        quote = str(jr.get("quote") or "").strip()
        detail = str(jr.get("detail") or "").strip()[:300]
        if state in ("pass", "fail"):
            if quote and not _rea_quote_verified(quote, text):
                return {"status": "insufficient",
                        "detail": "确定性判据引文与原文不一致，按证据不足处理",
                        "reason": "quote_not_verified", "quote": quote[:500],
                        "confidence": None, "model": model_meta,
                        "executor": "ruleexec"}
            return {"status": state, "detail": detail or "确定性判据已执行",
                    "reason": "deterministic_judged", "quote": quote[:500],
                    "confidence": None, "model": model_meta, "executor": "ruleexec",
                    "raw_state": str(jr.get("state") or "")}
        return {"status": "insufficient", "detail": detail or "确定性判据未得到可用结论",
                "reason": "deterministic_no_conclusion", "quote": quote[:500],
                "confidence": None, "model": model_meta, "executor": "ruleexec",
                "raw_state": str(jr.get("state") or "")}
    except Exception as e:
        return {"status": "insufficient", "detail": f"确定性判据执行失败：{type(e).__name__}",
                "reason": "executor_error", "quote": "", "confidence": None,
                "model": model_meta, "executor": "ruleexec"}


def _rea_guard(out: dict, spec: dict, provenance) -> dict:
    """TL-5：复核重判结果过数值 provenance 守卫（只拦 pass/fail；无 provenance 不改变行为）。"""
    try:
        from ..engine import hooks as _hk_rea2
        return _hk_rea2.guard_judgement(
            out, provenance=provenance, rule_code=str((spec or {}).get("rule_code") or ""),
            source="review.reaudit", numeric=_hk_rea2.point_is_numeric(spec or {}))
    except Exception:  # noqa: BLE001
        logging.debug("reaudit provenance guard skipped", exc_info=True)
        return out


def _rea_judge(result: dict, sub_id: str, sub_row: dict, text: str, path: str = "") -> dict:
    spec, _item = _rea_sub_spec(result, sub_id, sub_row)
    if not spec:
        return {"status": "insufficient", "detail": "找不到该子要求的判据，无法重判",
                "reason": "criterion_missing", "quote": "", "confidence": None,
                "model": {"provider": "", "available": False, "returned": False,
                          "model": "", "reason": "criterion_missing"},
                "executor": ""}
    # TL-5 接线：复核重判的数值判定同样受「数值不得来自视觉/未知来源」约束
    _rea_prov = None
    if path:
        try:
            from ..engine import hooks as _hk_rea
            _rea_prov = _hk_rea.provenance_of_parsed(_parsed_cached(path))
        except Exception:  # noqa: BLE001 - 解析不可用时退回"未提供 provenance"（不误降级）
            _rea_prov = None
    if spec.get("tool"):
        return _rea_guard(_rea_deterministic_judge(spec, text), spec, _rea_prov)
    if spec.get("criterion") and not spec.get("metric"):
        return _rea_semantic_judge(_rea_rule_for_result(result), spec, text, path, sub_id)
    return _rea_guard(_rea_deterministic_judge(spec, text), spec, _rea_prov)


def _rea_combine(states: list, combination: str = "all") -> dict:
    """复用 manifest_exec 的 V03 组合语义；导入失败时用同一六状态契约的最小实现。"""
    try:
        from . import manifest_exec as _mex
        return _mex.combine(states, combination)
    except Exception:
        # DU-29（2026-11-25）：兜底组合的别名归一也走 ``state_machines`` 单一事实源，
        # 禁止在本模块再维护第三份状态别名表（此前 弃权→insufficient 与主链
        # manifest_exec 的 弃权→unknown 口径已漂移；现在两处同源）。
        ss = [_state_machines.normalize_verdict(_x) for _x in (states or [])]
        if not ss:
            return {"status": "unknown", "reason": "没有子要求结果", "failed": [],
                    "incomplete": [], "verdict": "undetermined", "complete": False,
                    "report_allowed_without_exception": False}
        comb = "any" if str(combination).lower() in ("any", "or") else "all"
        failed = [i for i, x in enumerate(ss) if x == "fail"]
        incomplete = [i for i, x in enumerate(ss) if x in ("insufficient", "unknown",
                                                           "execution_failed")]
        nonna = [x for x in ss if x != "na"]
        if not nonna:
            verdict = "na"
        elif comb == "all":
            verdict = "fail" if failed else ("undetermined" if incomplete else "pass")
        elif "pass" in nonna:
            verdict = "pass"
        elif all(x == "fail" for x in nonna):
            verdict = "fail"
        else:
            verdict = "undetermined"
        complete = not incomplete
        if not ss:
            status = "unknown"
        elif verdict in ("pass", "fail", "na"):
            status = verdict
        elif "execution_failed" in ss:
            status = "blocked"
        else:
            status = "insufficient"
        reason = {"pass": "全部适用子要求满足", "fail": "至少一项子要求不满足",
                  "na": "全部不适用", "undetermined": "存在无法判断/未完成的子要求"}[verdict]
        return {"status": status, "reason": reason, "failed": failed,
                "incomplete": incomplete, "verdict": verdict, "complete": bool(complete),
                "report_allowed_without_exception": bool(complete),
                "canonical_states": ss, "combination": comb,
                "na_count": sum(1 for x in ss if x == "na")}


def _rea_manifest_item(result: dict) -> dict:
    items = _rea_json((result or {}).get("_items_json"), [])
    code = str((result or {}).get("rule_code") or "")
    obj = str((result or {}).get("object_id") or "")
    for one in (items or []):
        if not isinstance(one, dict):
            continue
        _o = str(one.get("object_id") or "")
        if str(one.get("code") or "") == code and (not _o or _o == obj):
            return one
    return {}




def _rea_finding_snapshot(f: dict) -> dict:
    f = f or {}
    return {"id": str(f.get("id") or ""), "status": str(f.get("status") or ""),
            "state": str(f.get("state") or ""), "summary": str(f.get("summary") or ""),
            "manifest_result_id": str(f.get("manifest_result_id") or ""),
            "subrequirement_id": str(f.get("subrequirement_id") or "")}


def _rea_linked_findings(result: dict, sub_id: str, all_subs: list) -> list:
    """定位与该结果/子要求关联的 finding；不扫描其它子要求。"""
    case_id = str((result or {}).get("_case_id") or "")
    code = str((result or {}).get("rule_code") or "")
    obj = str((result or {}).get("object_id") or "")
    rid = str((result or {}).get("id") or "")
    base_id = str(sub_id or "").split("#", 1)[0]
    allow_empty = len(all_subs or []) <= 1
    out = []
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM finding WHERE case_id=? AND rule_id=? "
                "AND (manifest_result_id=? OR (COALESCE(object_id,'')=? AND "
                "(subrequirement_id=? OR subrequirement_id=? OR (? AND COALESCE(subrequirement_id,'')=''))))",
                (case_id, code, rid, obj, sub_id, base_id,
                 1 if allow_empty else 0)).fetchall()]
        out = rows
    except Exception:
        logging.getLogger(__name__).debug("reaudit linked findings skipped", exc_info=True)
    # 只保留本结果/本子要求，防止同规则其它对象被串改
    return [f for f in out
            if str(f.get("manifest_result_id") or "") == rid
            or (str(f.get("subrequirement_id") or "") in
                ({sub_id, base_id} if sub_id else {""}))]


def _rea_sync_findings(result: dict, new_result_id: str, sub_id: str, all_subs: list,
                       status: str, detail: str, reaudit_id: str, reviewer: str) -> list:
    """重判后同步 finding：fail 进入待复核；其余状态让旧 fail 失效但保留行。"""
    changes = []
    for f in _rea_linked_findings(result, sub_id, all_subs):
        before = _rea_finding_snapshot(f)
        upd = {"state": "fail" if status == "fail" else status,
               "summary": (detail or before.get("summary") or "")[:500]}
        if status == "fail":
            upd["status"] = "pending"
            upd["manifest_result_id"] = new_result_id
        else:
            upd["status"] = "superseded"
        try:
            R.findings.update(f["id"], **upd)
        except Exception:
            logging.getLogger(__name__).debug("reaudit finding update skipped", exc_info=True)
            continue
        after = _rea_finding_snapshot(R.findings.get(f["id"]) or {**f, **upd})
        changes.append({"finding_id": f["id"], "before": before, "after": after})
        try:
            R.audit_logs.log(actor=reviewer or "system", action="review.finding_changed",
                             object=f["id"], before=json.dumps(before, ensure_ascii=False),
                             after=json.dumps({"reaudit_id": reaudit_id,
                                               "result_id": new_result_id,
                                               "sub_id": sub_id,
                                               "before": before, "after": after},
                                              ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("reaudit finding audit skipped", exc_info=True)
    return changes


def _rea_insert_result(result: dict, subs: list, d4_meta: dict, d5: dict,
                       conclusion: str, execution: str, reviewer: str) -> str:
    """新增重判结果行；旧结果只读保留，active 指针另行迁移。"""
    old = result or {}
    new_id = db.new_id("mres")
    d1 = _rea_dict(old.get("d1_json"))
    d2 = _rea_dict(old.get("d2_json"))
    d3 = _rea_dict(old.get("d3_json"))
    d3 = dict(d3)
    d3["reaudit"] = {"reaudit_id": d4_meta.get("reaudit_id"),
                     "target_sub_id": d4_meta.get("target_sub_id"),
                     "from_result_id": old.get("id"),
                     "evidence": d4_meta.get("evidence") or {},
                     "model": d4_meta.get("model") or {}}
    d4 = _rea_dict(old.get("d4_json"))
    d4 = dict(d4)
    d4["subs"] = subs
    d4["status"] = "mixed" if subs else "unknown"
    d4["detail"] = f"{len(subs)} 个子要求" if subs else "没有子要求结果"
    d4["reaudit"] = d4_meta
    d5 = dict(d5 or {})
    d5["reaudit"] = {"reaudit_id": d4_meta.get("reaudit_id"),
                     "target_sub_id": d4_meta.get("target_sub_id"),
                     "from_result_id": old.get("id")}
    key = str(old.get("item_key") or "")
    cols = {
        "id": new_id, "manifest_id": old.get("manifest_id") or "",
        "item_key": (key + "|reaudit:" + str(d4_meta.get("reaudit_id") or ""))[:500],
        "object_id": old.get("object_id") or "", "rule_id": old.get("rule_id") or "",
        "rule_code": old.get("rule_code") or "",
        "d1_json": json.dumps(d1, ensure_ascii=False),
        "d2_json": json.dumps(d2, ensure_ascii=False),
        "d3_json": json.dumps(d3, ensure_ascii=False),
        "d4_json": json.dumps(d4, ensure_ascii=False),
        "d5_json": json.dumps(d5, ensure_ascii=False),
        "conclusion": conclusion, "execution": execution, "updated_at": db.now(),
    }
    with db.session() as c:
        available = {r[1] for r in c.execute("PRAGMA table_info(manifest_result)")}
        for _col, _val in (("review_status", "pending"),
                           ("review_reason", "补证后重判，待复核"),
                           ("reviewer", reviewer or ""),
                           ("reviewed_at", db.now())):
            if _col in available:
                cols[_col] = _val
        keys = list(cols.keys())
        c.execute("INSERT INTO manifest_result(" + ",".join(keys) + ") VALUES("
                  + ",".join("?" for _ in keys) + ")", [cols[k] for k in keys])
    return new_id


def _rea_move_active(result: dict, new_result_id: str, sub_id: str, status: str) -> None:
    """只移动结果级 active 与目标子要求 active；兄弟子要求指针不动。"""
    case_id = str((result or {}).get("_case_id") or "")
    obj = str((result or {}).get("object_id") or "")
    code = str((result or {}).get("rule_code") or "")
    if not case_id:
        return
    with db.session() as c:
        c.execute("INSERT INTO manifest_active(case_id,object_id,rule_code,result_id,updated_at) "
                  "VALUES(?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code) DO UPDATE SET "
                  "result_id=excluded.result_id,updated_at=excluded.updated_at",
                  (case_id, obj, code, new_result_id, db.now()))
        c.execute("INSERT INTO manifest_active_sub(case_id,object_id,rule_code,sub_id,result_id,status,updated_at) "
                  "VALUES(?,?,?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code,sub_id) DO UPDATE SET "
                  "result_id=excluded.result_id,status=excluded.status,updated_at=excluded.updated_at",
                  (case_id, obj, code, sub_id, new_result_id, status, db.now()))


def _rea_record_evidence(result: dict, sub_id: str, evidence_meta: dict,
                         evidence_id: str, new_result_id: str, reviewer: str,
                         reason: str) -> str:
    """补证材料登记：复用既有 manifest_evidence 表，形成可查询的补证历史。"""
    old_id = str((result or {}).get("id") or "")
    case_id = str((result or {}).get("_case_id") or "")
    ref = str((evidence_meta or {}).get("ref") or "")
    sup = str((evidence_meta or {}).get("supplement") or "")
    ref_text = (ref or sup or "")[:500]
    now = db.now()
    if evidence_id:
        with db.session() as c:
            row = c.execute("SELECT * FROM manifest_evidence WHERE id=?", (evidence_id,)).fetchone()
            if row and str(row["result_id"] or "") == old_id:
                c.execute("UPDATE manifest_evidence SET status='reaudited', fulfilled_at=?, "
                          "evidence_ref=?, new_result_id=?, requested_by=COALESCE(NULLIF(requested_by,''),?) "
                          "WHERE id=?", (now, ref_text, new_result_id,
                                         reviewer or "", evidence_id))
                return evidence_id
    eid = db.new_id("mev")
    with db.session() as c:
        c.execute("INSERT INTO manifest_evidence(id,result_id,reason,status,requested_by,created_at,"
                  "fulfilled_at,evidence_ref,new_result_id,checklist_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (eid, old_id, (reason or "补证后重判")[:500], "reaudited",
                   reviewer or "", now, now, ref_text, new_result_id, "[]"))
    try:
        if case_id:
            R.audit_logs.log(actor=reviewer or "system", action="manifest.evidence_requested",
                             object=old_id,
                             after=json.dumps({"evidence_id": eid, "result_id": old_id,
                                               "reason": (reason or "补证后重判")[:300],
                                               "detail": (reason or "补证后重判")[:300]},
                                              ensure_ascii=False))
            R.audit_logs.log(actor=reviewer or "system", action="review.evidence_added",
                             object=old_id,
                             after=json.dumps({"evidence_id": eid, "result_id": old_id,
                                               "sub_id": sub_id,
                                               "new_result_id": new_result_id,
                                               "detail": (sup or ref_text)[:300],
                                               "chars": len(sup), "ref": ref[:200]},
                                              ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("reaudit evidence audit skipped", exc_info=True)
    return eid


def reaudit_subrequirement(result_id: str, sub_id: str = "", evidence_text: str = "",
                           evidence_ref: str = "", reviewer: str = "", role: str = "",
                           reason: str = "", evidence_id: str = "",
                           subrequirement_id: str = "", user_id: str = "",
                           actor: str = "", text: str = "",
                           evidence: str = "") -> dict:
    """独立只重判某个子要求；兄弟子要求状态与 active 指针原样保留。

    - 语义子要求：真实调用 agent-judge；无模型/空结果/引文未回验 → insufficient。
    - 数值子要求：走 ruleexec；工具子要求缺少重判依赖时显式 insufficient。
    - 旧 manifest_result 不覆盖；新结果写 manifest_result，并迁移结果级 active 与
      目标子要求 active，历史写 manifest_evidence + audit_log。
    """
    sub_id = str(sub_id or subrequirement_id or "")
    evidence_text = evidence_text or text or evidence
    reviewer = str(reviewer or actor or user_id or "").strip()
    old = _rea_load_result(result_id)
    if not old:
        return {"error": "审核结果不存在", "code": "not_found", "status": 404}
    case_id = str(old.get("_case_id") or "")
    if case_id and not R.cases.get(case_id):
        return {"error": "项目不存在或无权限", "code": "not_found", "status": 404}
    deny = _rea_access(case_id, reviewer, role, "review")
    if deny:
        return deny
    old_subs = _rea_dict(old.get("d4_json")).get("subs") or []
    if not isinstance(old_subs, list):
        old_subs = []
    if sub_id:
        idx = next((i for i, s in enumerate(old_subs)
                    if isinstance(s, dict) and str(s.get("id") or "") == sub_id), -1)
        if idx < 0:
            # 多行子要求 S1#2：只有唯一基号时才允许落到基号
            base = sub_id.split("#", 1)[0]
            cand = [i for i, s in enumerate(old_subs)
                    if isinstance(s, dict) and str(s.get("id") or "") == base]
            idx = cand[0] if len(cand) == 1 else -1
        if idx < 0:
            return {"error": f"子要求不存在：{sub_id}", "code": "subrequirement_not_found",
                    "status": 404}
    else:
        if len(old_subs) > 1:
            return {"error": "该结果有多个子要求，必须指定 sub_id，不能整条重判",
                    "code": "sub_id_required", "status": 400}
        idx = 0
    import copy as _copy
    if old_subs:
        old_sub = _copy.deepcopy(dict(old_subs[idx] or {}))
        target_id = str(old_sub.get("id") or sub_id or "")
    else:
        # 没有 D4 子要求的旧结果：把规则级结论视为唯一子要求重判
        target_id = sub_id
        old_sub = {"id": "", "status": _rea_status(old.get("conclusion") or ""),
                   "detail": str(_rea_dict(old.get("d5_json")).get("reason") or ""),
                   "quote": "", "evidence_ok": False}
        old_subs = [old_sub]
        idx = 0
    item = _rea_manifest_item(old)
    combined, ev_meta = _rea_evidence_text(evidence_text, evidence_ref, case_id,
                                           str(old.get("object_id") or ""))
    judged = _rea_judge(old, target_id, old_sub, combined,
                        str((ev_meta.get("base") or {}).get("path") or ""))
    status = str(judged.get("status") or "insufficient")
    detail = str(judged.get("detail") or "")
    quote = str(judged.get("quote") or "")
    reaudit_id = db.new_id("ra")
    old_status = str(old_sub.get("status") or "")
    new_sub = _copy.deepcopy(old_sub)
    new_sub.update({
        "status": status,
        "detail": detail,
        "quote": quote,
        "evidence_ok": bool(combined.strip()),
        "raw_state": str(judged.get("raw_state") or old_sub.get("raw_state") or ""),
        "reaudit": {
            "reaudit_id": reaudit_id,
            "from_result_id": str(old.get("id") or ""),
            "previous_status": old_status,
            "previous_detail": str(old_sub.get("detail") or ""),
            "evidence_ref": str(ev_meta.get("ref") or ""),
            "evidence_chars": int(ev_meta.get("supplement_chars") or 0),
            "reason": str(judged.get("reason") or ""),
            "judged_at": db.now(),
            "model": judged.get("model") or {},
            "executor": str(judged.get("executor") or ""),
        },
        "tool_trace": {**_rea_dict(old_sub.get("tool_trace")),
                       "executor": str(judged.get("executor") or "unknown"),
                       "result": status,
                       "reaudited": True,
                       "reaudit_id": reaudit_id,
                       "model": judged.get("model") or {},
                       "reason": str(judged.get("reason") or ""),
                       "quote": quote[:500]},
    })
    new_subs = [_copy.deepcopy(dict(x)) if isinstance(x, dict) else {} for x in old_subs]
    new_subs[idx] = new_sub
    siblings = []
    for i, s in enumerate(new_subs):
        if i == idx:
            continue
        siblings.append({"id": str((s or {}).get("id") or ""),
                         "status": str((s or {}).get("status") or ""),
                         "unchanged": True})
    combination = str(item.get("combination") or "all")
    d5 = _rea_combine([_rea_status((x or {}).get("status") or "unknown")
                       for x in new_subs], combination)
    d5["combination"] = combination
    fallback = str((item.get("execution_hints") or {}).get("fallback") or "abstain")
    d5["fallback"] = fallback
    if fallback == "fail" and str(d5.get("status") or "") == "insufficient":
        # 重判不能把“模型不可用”静默升级为不满足；只标注原始策略，保持 insufficient。
        d5["fallback_note"] = "重判不自动套用 fallback=fail，证据不足仍按 insufficient 处理"
    conclusion = _REAUDIT_CONCLUSION.get(str(d5.get("status") or ""), "无法判断")
    execution = ("completed" if str(d5.get("status") or "") in ("pass", "fail", "na")
                 else "incomplete")
    d4_meta = {
        "reaudit_id": reaudit_id, "mode": "subrequirement",
        "target_sub_id": target_id, "from_result_id": str(old.get("id") or ""),
        "preserved_sub_ids": [x["id"] for x in siblings],
        "evidence": ev_meta, "model": judged.get("model") or {},
        "judge": {"executor": str(judged.get("executor") or ""),
                  "reason": str(judged.get("reason") or ""),
                  "confidence": judged.get("confidence")},
        "fallback": fallback, "fallback_applied": False,
        "judged_at": db.now(),
    }
    new_result_id = _rea_insert_result(old, new_subs, d4_meta, d5, conclusion,
                                       execution, reviewer)
    _rea_move_active(old, new_result_id, target_id, status)
    eid = _rea_record_evidence(old, target_id, ev_meta, evidence_id, new_result_id,
                               reviewer, reason)
    changes = _rea_sync_findings(old, new_result_id, target_id, old_subs, status,
                                 detail, reaudit_id, reviewer)
    before = {"result_id": str(old.get("id") or ""), "status": old_status,
              "detail": str(old_sub.get("detail") or ""),
              "quote": str(old_sub.get("quote") or ""),
              "conclusion": str(old.get("conclusion") or ""),
              "execution": str(old.get("execution") or ""),
              "d5": _rea_dict(old.get("d5_json"))}
    sub_conclusion = _REAUDIT_CONCLUSION.get(status, "无法判断")
    after = {"result_id": new_result_id, "status": status,
             "sub_conclusion": sub_conclusion, "detail": detail,
             "quote": quote, "conclusion": conclusion, "execution": execution,
             "d5": d5}
    payload = {"reaudit_id": reaudit_id, "mode": "subrequirement",
               "case_id": case_id, "manifest_id": str(old.get("manifest_id") or ""),
               "result_id": str(old.get("id") or ""), "new_result_id": new_result_id,
               "object_id": str(old.get("object_id") or ""),
               "rule_code": str(old.get("rule_code") or ""),
               "sub_id": target_id, "before": before, "after": after,
               "siblings": siblings, "evidence": ev_meta,
               "model": judged.get("model") or {},
               "judge": {"executor": str(judged.get("executor") or ""),
                         "reason": str(judged.get("reason") or ""),
                         "confidence": judged.get("confidence")},
               "findings": changes, "reviewer": reviewer,
               "fabricated": False}
    # 兼容既有补证台账/报告时间线：manifest_evidence 的生命周期审计
    try:
        R.audit_logs.log(actor=reviewer or "system", action="manifest.evidence_fulfilled",
                         object=eid,
                         after=json.dumps({"evidence_id": eid,
                                           "result_id": str(old.get("id") or ""),
                                           "sub_id": target_id,
                                           "detail": (str(ev_meta.get("supplement") or "")
                                                      or str(ev_meta.get("ref") or ""))[:300]},
                                          ensure_ascii=False))
        R.audit_logs.log(actor=reviewer or "system", action="manifest.reaudited",
                         object=eid,
                         after=json.dumps({"reaudit_id": reaudit_id,
                                           "result_id": str(old.get("id") or ""),
                                           "new_result_id": new_result_id,
                                           "sub_id": target_id,
                                           "before": before.get("conclusion") or "",
                                           "after": after.get("conclusion") or "",
                                           "conclusion_before": before.get("conclusion") or "",
                                           "conclusion_after": after.get("conclusion") or "",
                                           "role": role or ""},
                                          ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("reaudit compat audit skipped", exc_info=True)
    action = ("review.semantic_reaudited"
              if str(judged.get("executor") or "") == "agent-judge"
              else "review.sub_reaudited")
    try:
        R.audit_logs.log(actor=reviewer or "system", action=action,
                         object=str(old.get("id") or ""),
                         before=json.dumps(before, ensure_ascii=False),
                         after=json.dumps(payload, ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("reaudit audit skipped", exc_info=True)
    out = {"ok": True, "reaudit_id": reaudit_id, "mode": "subrequirement",
           "result_id": str(old.get("id") or ""), "new_result_id": new_result_id,
           "manifest_id": str(old.get("manifest_id") or ""), "case_id": case_id,
           "object_id": str(old.get("object_id") or ""),
           "rule_code": str(old.get("rule_code") or ""),
           "sub_id": target_id, "status": status, "sub_conclusion": sub_conclusion,
           "conclusion": conclusion,
           "before": before, "after": after, "siblings": siblings,
           "changed": bool(old_status != status
                           or str(old_sub.get("detail") or "") != detail),
           "evidence": ev_meta, "evidence_id": eid,
           "model": judged.get("model") or {},
           "judge": {"executor": str(judged.get("executor") or ""),
                     "reason": str(judged.get("reason") or ""),
                     "confidence": judged.get("confidence")},
           "findings": changes, "fabricated": False,
           "active": {"object_id": str(old.get("object_id") or ""),
                      "rule_code": str(old.get("rule_code") or ""),
                      "sub_id": target_id, "result_id": new_result_id}}
    return out


def _rea_add_finding_evidence(finding: dict, text: str, ref: str,
                              reaudit_id: str) -> str:
    """把补证材料挂到 finding 证据链；项目没有文档时仍保留引文行。"""
    fid = str((finding or {}).get("id") or "")
    if not fid:
        return ""
    excerpt = (str(text or "").strip() or str(ref or "").strip() or "重判补证")[:500]
    doc_id = ""
    try:
        docs = _rea_case_documents(str(finding.get("case_id") or ""))
        if docs:
            doc_id = str(docs[0].get("id") or "")
    except Exception:
        doc_id = ""
    aid = db.new_id("anc")
    try:
        R.anchors.insert(id=aid, document_id=doc_id, sheet="", row="", col="",
                         locator="补证材料", quote=excerpt,
                         hash=hashlib.sha256(excerpt.encode("utf-8")).hexdigest()[:16])
        eid = db.new_id("evd")
        R.evidences.insert(id=eid, finding_id=fid, document_id=doc_id, anchor_id=aid,
                           excerpt=excerpt, label="语义重判补证")
        return eid
    except Exception:
        logging.getLogger(__name__).debug("reaudit finding evidence skipped", exc_info=True)
        return ""


def _rea_active_result_for_finding(finding: dict) -> str:
    """finding 没有 manifest_result_id 时按 case/object/rule 找当前 active。"""
    if not finding:
        return ""
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT result_id FROM manifest_active WHERE case_id=? AND rule_code=? "
                "AND (object_id=? OR ?='') ORDER BY updated_at DESC LIMIT 1",
                (str(finding.get("case_id") or ""), str(finding.get("rule_id") or ""),
                 str(finding.get("object_id") or ""), str(finding.get("object_id") or ""))).fetchone()
        return str(row["result_id"] or "") if row else ""
    except Exception:
        return ""


def reaudit_finding_semantic(finding_id: str, evidence_text: str = "",
                             evidence_ref: str = "", reviewer: str = "",
                             role: str = "", reason: str = "",
                             actor: str = "", user_id: str = "",
                             text: str = "", evidence: str = "") -> dict:
    """语义补证重判入口：优先走关联的 manifest 子要求，否则按规则卡片直接重判。

    无模型时返回 insufficient；不把 finding 直接改成 pass，也不伪造模型结论。
    """
    evidence_text = evidence_text or text or evidence
    reviewer = str(reviewer or actor or user_id or "").strip()
    finding = _rea_load_finding(finding_id)
    if not finding:
        return {"error": "问题不存在", "code": "not_found", "status": 404}
    case_id = str(finding.get("case_id") or "")
    deny = _rea_access(case_id, reviewer, role, "review")
    if deny:
        return deny
    result_id = str(finding.get("manifest_result_id") or "")
    if not result_id:
        result_id = _rea_active_result_for_finding(finding)
    if result_id:
        result = _rea_load_result(result_id)
        if result:
            subs = _rea_dict(result.get("d4_json")).get("subs") or []
            sub_id = str(finding.get("subrequirement_id") or "")
            if not sub_id and len(subs) == 1:
                sub_id = str((subs[0] or {}).get("id") or "")
            if not sub_id and len(subs) > 1:
                return {"error": "该问题未标注子要求，无法独立重判，避免串改其它子要求",
                        "code": "sub_id_required", "status": 400}
            out = reaudit_subrequirement(result_id, sub_id, evidence_text,
                                         evidence_ref, reviewer, role, reason)
            if out.get("ok"):
                out["mode"] = "finding"
                out["finding_id"] = finding_id
            return out
    # 无 manifest 结果：按规则卡片判据直接重判 finding（不生成 manifest 结果）
    combined, ev_meta = _rea_evidence_text(evidence_text, evidence_ref, case_id,
                                           str(finding.get("object_id") or ""))
    pseudo = {"rule_id": finding.get("rule_id") or "",
              "rule_code": finding.get("rule_id") or "",
              "object_id": finding.get("object_id") or "",
              "_items_json": []}
    old_sub = {"id": str(finding.get("subrequirement_id") or ""),
               "status": _rea_status(finding.get("state") or "fail"),
               "detail": str(finding.get("summary") or ""),
               "quote": ""}
    judged = _rea_judge(pseudo, old_sub["id"], old_sub, combined,
                        str((ev_meta.get("base") or {}).get("path") or ""))
    status = str(judged.get("status") or "insufficient")
    detail = str(judged.get("detail") or "")
    quote = str(judged.get("quote") or "")
    reaudit_id = db.new_id("ra")
    before = {"finding_id": finding_id, "status": str(finding.get("status") or ""),
              "state": str(finding.get("state") or ""),
              "summary": str(finding.get("summary") or "")}
    upd = {"state": "fail" if status == "fail" else status,
           "summary": (detail or before.get("summary") or "")[:500]}
    upd["status"] = "pending" if status == "fail" else "superseded"
    R.findings.update(finding_id, **upd)
    after = _rea_finding_snapshot(R.findings.get(finding_id) or {})
    sub_conclusion = _REAUDIT_CONCLUSION.get(status, "无法判断")
    after["sub_conclusion"] = sub_conclusion
    eid = _rea_add_finding_evidence(finding, str(ev_meta.get("supplement") or ""),
                                    str(ev_meta.get("ref") or ""), reaudit_id)
    if eid:
        try:
            R.audit_logs.log(actor=reviewer or "system", action="review.evidence_added",
                             object=finding_id,
                             after=json.dumps({"evidence_id": eid,
                                               "reaudit_id": reaudit_id,
                                               "detail": str(ev_meta.get("supplement")
                                                             or "")[:300],
                                               "excerpt": str(ev_meta.get("supplement")
                                                              or "")[:200]},
                                              ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("direct reaudit evidence audit skipped",
                                              exc_info=True)
    changes = [{"finding_id": finding_id, "before": before, "after": after}]
    try:
        R.audit_logs.log(actor=reviewer or "system", action="review.finding_changed",
                         object=finding_id,
                         before=json.dumps(before, ensure_ascii=False),
                         after=json.dumps({"reaudit_id": reaudit_id,
                                           "before": before, "after": after},
                                          ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("direct reaudit finding audit skipped", exc_info=True)
    payload = {"reaudit_id": reaudit_id, "mode": "finding", "case_id": case_id,
               "finding_id": finding_id, "result_id": "", "new_result_id": "",
               "sub_id": old_sub["id"], "before": before, "after": after,
               "evidence": ev_meta, "model": judged.get("model") or {},
               "judge": {"executor": str(judged.get("executor") or ""),
                         "reason": str(judged.get("reason") or ""),
                         "confidence": judged.get("confidence")},
               "findings": changes, "reviewer": reviewer, "fabricated": False}
    action = ("review.semantic_reaudited"
              if str(judged.get("executor") or "") == "agent-judge"
              else "review.sub_reaudited")
    try:
        R.audit_logs.log(actor=reviewer or "system", action=action,
                         object=finding_id,
                         before=json.dumps(before, ensure_ascii=False),
                         after=json.dumps(payload, ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("direct reaudit audit skipped", exc_info=True)
    return {"ok": True, "reaudit_id": reaudit_id, "mode": "finding",
            "finding_id": finding_id, "result_id": "", "new_result_id": "",
            "case_id": case_id, "sub_id": old_sub["id"], "status": status,
            "sub_conclusion": sub_conclusion,
            "conclusion": _REAUDIT_CONCLUSION.get(status, "无法判断"),
            "before": before, "after": after,
            "changed": bool(before.get("state") != status
                            or before.get("summary") != detail),
            "evidence": ev_meta, "evidence_id": eid,
            "model": judged.get("model") or {},
            "judge": {"executor": str(judged.get("executor") or ""),
                      "reason": str(judged.get("reason") or ""),
                      "confidence": judged.get("confidence")},
            "findings": changes, "fabricated": False}


def _rea_sql_in(ids) -> tuple:
    vals = [str(x) for x in (ids or []) if str(x)]
    if not vals:
        return "('')", ()
    return "(" + ",".join("?" for _ in vals) + ")", tuple(vals)


def _rea_audit_event(row: dict) -> dict:
    action = str(row.get("action") or "")
    after_text = str(row.get("after_json") or "")
    before_text = str(row.get("before_json") or "")
    after_raw = _rea_json(after_text, None)
    before_raw = _rea_json(before_text, None)
    after_obj = after_raw if isinstance(after_raw, dict) else {}
    before_obj = before_raw if isinstance(before_raw, dict) else {}
    inner_after = after_obj.get("after") if isinstance(after_obj.get("after"), dict) else {}
    detail = ""
    for src in (inner_after, after_obj):
        detail = str(src.get("detail") or src.get("reason") or src.get("summary") or "")
        if detail:
            break
    if not detail and isinstance(after_raw, str):
        detail = after_raw[:300]
    if not detail and after_text.strip():
        detail = after_text[:300]
    if not detail and after_obj.get("before") is not None and after_obj.get("after") is not None:
        detail = f"{after_obj.get('before')} → {after_obj.get('after')}"
    sub_id = str(after_obj.get("sub_id") or inner_after.get("sub_id") or "")
    result_id = str(after_obj.get("result_id") or inner_after.get("result_id") or "")
    new_result_id = str(after_obj.get("new_result_id") or "")
    if not result_id and str(row.get("object") or "").startswith("mres"):
        result_id = str(row.get("object") or "")
    obj = str(row.get("object") or "")
    finding_id = obj if obj.startswith("fnd") else str(after_obj.get("finding_id") or "")
    kind = ("reaudit" if "reaudit" in action
            else ("evidence" if "evidence" in action
                  else ("review" if action.startswith(("review.", "manifest.decided",
                                                       "finding.decided"))
                        else "audit")))
    event = {"time": str(row.get("created_at") or ""), "kind": kind,
             "action": action, "label": _REAUDIT_KIND_LABEL.get(action, action),
             "actor": str(row.get("actor") or ""), "object": obj,
             "finding_id": finding_id, "result_id": result_id,
             "new_result_id": new_result_id, "sub_id": sub_id,
             "detail": detail[:500], "source": "audit_log",
             "before": before_obj or (after_obj.get("before") or {}),
             "after": inner_after or after_obj.get("after") or {},
             "model": after_obj.get("model") or {},
             "reaudit_id": str(after_obj.get("reaudit_id") or "")}
    if action == "review.finding_changed":
        event["finding_id"] = obj
        event["result_id"] = str((after_obj or {}).get("result_id") or "")
        event["sub_id"] = str((after_obj or {}).get("sub_id") or "")
        event["before"] = after_obj.get("before") or {}
        event["after"] = after_obj.get("after") or {}
    return event


def review_timeline(case_id: str = "", finding_id: str = "", result_id: str = "",
                    limit: int = 200, actor: str = "", role: str = "") -> dict:
    """复核/补证/重判时间线：按时间正序返回可追溯事件。

    任一作用域可用：case_id、finding_id、result_id。只读；未显式传身份时保持
    服务层兼容调用，显式传身份时按项目查看权限校验。
    """
    try:
        limit = max(1, min(int(limit or 200), 1000))
    except Exception:
        limit = 200
    case_id = str(case_id or "").strip()
    finding_id = str(finding_id or "").strip()
    result_id = str(result_id or "").strip()
    # 位置参数兼容：只传一个 id 时自动识别 finding/result/case
    if case_id and not finding_id and not result_id:
        if _rea_load_finding(case_id):
            finding_id, case_id = case_id, ""
        elif _rea_load_result(case_id):
            result_id, case_id = case_id, ""
    finding = _rea_load_finding(finding_id) if finding_id else {}
    if finding_id and not finding:
        return {"error": "问题不存在", "code": "not_found", "status": 404}
    result = _rea_load_result(result_id) if result_id else {}
    if result_id and not result:
        return {"error": "审核结果不存在", "code": "not_found", "status": 404}
    if finding:
        case_id = case_id or str(finding.get("case_id") or "")
    if result:
        case_id = case_id or str(result.get("_case_id") or "")
    if not case_id:
        return {"error": "必须提供 case_id、finding_id 或 result_id",
                "code": "missing_scope", "status": 400}
    case = R.cases.get(case_id)
    if not case:
        return {"error": "项目不存在", "code": "not_found", "status": 404}
    if str(actor or "").strip() or str(role or "").strip():
        deny = _rea_access(case_id, actor, role, "view")
        if deny:
            return deny
    finding_ids, result_ids = set(), set()
    object_ids, sub_ids, manifest_ids, evidence_ids = set(), set(), set(), set()
    case_scope = not finding_id and not result_id
    if finding_id:
        finding_ids.add(finding_id)
        object_ids.add(str(finding.get("object_id") or ""))
        sub_ids.add(str(finding.get("subrequirement_id") or ""))
        if finding.get("manifest_result_id"):
            result_ids.add(str(finding.get("manifest_result_id") or ""))
    if result_id:
        result_ids.add(result_id)
        object_ids.add(str(result.get("object_id") or ""))
        sub_ids.add(str(finding.get("subrequirement_id") or "") if finding else "")
        manifest_ids.add(str(result.get("manifest_id") or ""))
    if case_scope:
        # 项目级时间线：纳入本项目全部 finding / manifest 结果
        with db.session() as c:
            for row in c.execute("SELECT * FROM finding WHERE case_id=?", (case_id,)).fetchall():
                f = dict(row)
                finding_ids.add(str(f.get("id") or ""))
                if f.get("manifest_result_id"):
                    result_ids.add(str(f.get("manifest_result_id") or ""))
                if f.get("object_id"):
                    object_ids.add(str(f.get("object_id") or ""))
                if f.get("subrequirement_id"):
                    sub_ids.add(str(f.get("subrequirement_id") or ""))
            for row in c.execute(
                    "SELECT mr.*, m.case_id AS _case_id FROM manifest_result mr "
                    "JOIN audit_manifest m ON m.id=mr.manifest_id WHERE m.case_id=? "
                    "ORDER BY mr.updated_at", (case_id,)).fetchall():
                r = dict(row)
                result_ids.add(str(r.get("id") or ""))
                if r.get("object_id"):
                    object_ids.add(str(r.get("object_id") or ""))
                if r.get("manifest_id"):
                    manifest_ids.add(str(r.get("manifest_id") or ""))
    elif result_id:
        # 单结果时间线：先纳入该结果关联的 finding，不扩散到同项目其它规则
        with db.session() as c:
            for row in c.execute("SELECT * FROM finding WHERE manifest_result_id=?",
                                 (result_id,)).fetchall():
                f = dict(row)
                finding_ids.add(str(f.get("id") or ""))
                if f.get("object_id"):
                    object_ids.add(str(f.get("object_id") or ""))
                if f.get("subrequirement_id"):
                    sub_ids.add(str(f.get("subrequirement_id") or ""))
    # 沿 manifest_evidence / 重判审计把旧结果链补全
    for _ in range(3):
        before_n = len(result_ids)
        ins, vals = _rea_sql_in(result_ids)
        if result_ids:
            with db.session() as c:
                for row in c.execute(
                        "SELECT * FROM manifest_evidence WHERE result_id IN " + ins
                        + " OR new_result_id IN " + ins, vals + vals).fetchall():
                    ev = dict(row)
                    if ev.get("id"):
                        evidence_ids.add(str(ev.get("id") or ""))
                    if ev.get("result_id"):
                        result_ids.add(str(ev.get("result_id") or ""))
                    if ev.get("new_result_id"):
                        result_ids.add(str(ev.get("new_result_id") or ""))
                for row in c.execute(
                        "SELECT * FROM audit_log WHERE action LIKE '%reaudit%' AND object IN "
                        + ins, vals).fetchall():
                    log = dict(row)
                    obj = _rea_dict(log.get("after_json"))
                    if isinstance(obj, dict):
                        for key in ("result_id", "new_result_id"):
                            if obj.get(key):
                                result_ids.add(str(obj.get(key) or ""))
                    if str(log.get("object") or "").startswith("mres"):
                        result_ids.add(str(log.get("object") or ""))
        if len(result_ids) == before_n:
            break
    ins, vals = _rea_sql_in(result_ids)
    if result_ids:
        with db.session() as c:
            for row in c.execute(
                    "SELECT * FROM finding WHERE manifest_result_id IN " + ins,
                    vals).fetchall():
                f = dict(row)
                finding_ids.add(str(f.get("id") or ""))
                if f.get("object_id"):
                    object_ids.add(str(f.get("object_id") or ""))
                if f.get("subrequirement_id"):
                    sub_ids.add(str(f.get("subrequirement_id") or ""))
            for row in c.execute("SELECT * FROM manifest_result WHERE id IN " + ins,
                                 vals).fetchall():
                r = dict(row)
                object_ids.add(str(r.get("object_id") or ""))
                manifest_ids.add(str(r.get("manifest_id") or ""))
    events = []
    # 1) 人工复核 decision 表
    if finding_ids:
        f_ins, f_vals = _rea_sql_in(finding_ids)
        with db.session() as c:
            for row in c.execute("SELECT * FROM decision WHERE finding_id IN " + f_ins
                                 + " ORDER BY created_at,rowid", f_vals).fetchall():
                d = dict(row)
                dec = str(d.get("decision") or "")
                events.append({
                    "time": str(d.get("created_at") or ""), "kind": "review",
                    "action": "decision." + dec,
                    "label": "人工复核：" + _DECISION_LABEL.get(dec, dec),
                    "actor": str(d.get("user_id") or ""), "object": str(d.get("finding_id") or ""),
                    "finding_id": str(d.get("finding_id") or ""), "result_id": "",
                    "new_result_id": "", "sub_id": "",
                    "detail": str(d.get("reason") or d.get("note") or "")[:500],
                    "source": "decision", "before": {},
                    "after": {"decision": dec, "reason": d.get("reason") or "",
                              "note": d.get("note") or ""}, "model": {}})
    # 2) manifest 复核记录
    if result_ids:
        r_ins, r_vals = _rea_sql_in(result_ids)
        with db.session() as c:
            for row in c.execute("SELECT * FROM manifest_review WHERE result_id IN " + r_ins
                                 + " ORDER BY created_at,rowid", r_vals).fetchall():
                m = dict(row)
                events.append({
                    "time": str(m.get("created_at") or ""), "kind": "review",
                    "action": "manifest_review." + str(m.get("status") or ""),
                    "label": "清单复核：" + str(m.get("status") or ""),
                    "actor": str(m.get("reviewer") or ""), "object": str(m.get("result_id") or ""),
                    "finding_id": "", "result_id": str(m.get("result_id") or ""),
                    "new_result_id": "", "sub_id": "",
                    "detail": str(m.get("reason") or "")[:500],
                    "source": "manifest_review",
                    "before": {},
                    "after": {"status": m.get("status") or "",
                              "reason": m.get("reason") or ""}, "model": {}})
            for row in c.execute("SELECT * FROM manifest_evidence WHERE result_id IN " + r_ins
                                 + " OR new_result_id IN " + r_ins,
                                 r_vals + r_vals).fetchall():
                ev = dict(row)
                rid = str(ev.get("result_id") or "")
                events.append({
                    "time": str(ev.get("created_at") or ""), "kind": "evidence",
                    "action": "manifest.evidence_requested",
                    "label": "申请补证", "actor": str(ev.get("requested_by") or ""),
                    "object": rid, "finding_id": "", "result_id": rid,
                    "new_result_id": str(ev.get("new_result_id") or ""), "sub_id": "",
                    "detail": str(ev.get("reason") or "")[:500],
                    "source": "manifest_evidence",
                    "before": {}, "after": {"status": ev.get("status") or "",
                                            "evidence_ref": ev.get("evidence_ref") or ""},
                    "model": {}})
                if ev.get("fulfilled_at"):
                    events.append({
                        "time": str(ev.get("fulfilled_at") or ""), "kind": "evidence",
                        "action": "manifest.evidence_fulfilled",
                        "label": "补证完成", "actor": str(ev.get("requested_by") or ""),
                        "object": rid, "finding_id": "", "result_id": rid,
                        "new_result_id": str(ev.get("new_result_id") or ""), "sub_id": "",
                        "detail": str(ev.get("evidence_ref") or "")[:500],
                        "source": "manifest_evidence",
                        "before": {}, "after": {"status": ev.get("status") or ""},
                        "model": {}})
    # 3) 审计日志：重判/补证/编辑/清单事件
    objects = {case_id}
    objects.update(x for x in finding_ids if x)
    objects.update(x for x in result_ids if x)
    objects.update(x for x in manifest_ids if x)
    objects.update(x for x in evidence_ids if x)
    o_ins, o_vals = _rea_sql_in(objects)
    with db.session() as c:
        logs = [dict(r) for r in c.execute(
            "SELECT * FROM audit_log WHERE object IN " + o_ins
            + " ORDER BY created_at,rowid", o_vals).fetchall()]
    _covered_actions = {"manifest.evidence_requested", "manifest.evidence_fulfilled",
                        "manifest.decided", "finding.decided"}
    for row in logs:
        action = str(row.get("action") or "")
        if action in _covered_actions:
            continue
        if not (action.startswith("review.") or action.startswith("manifest.")
                or action.startswith("finding.") or action.startswith("decision.")):
            continue
        events.append(_rea_audit_event(row))
    # 先按时间/来源排序，再去重：同一 reaudit_id 优先保留 review.* 主事件，
    # 兼容审计 manifest.reaudited 只作为报告侧兜底，不重复占用时间线。
    _kind_order = {"review": 0, "evidence": 1, "reaudit": 2, "audit": 3}
    events.sort(key=lambda e: (str(e.get("time") or ""), _kind_order.get(e.get("kind"), 9),
                               0 if str(e.get("action") or "").startswith("review.") else 1,
                               str(e.get("source") or ""), str(e.get("action") or "")))
    seen, uniq, seen_reaudit = set(), [], set()
    for ev in events:
        if ev.get("kind") == "reaudit" and ev.get("reaudit_id"):
            _rid = str(ev.get("reaudit_id") or "")
            if _rid in seen_reaudit:
                continue
            seen_reaudit.add(_rid)
        key = (ev.get("time"), ev.get("kind"), ev.get("action"),
               ev.get("finding_id"), ev.get("result_id"), ev.get("new_result_id"),
               ev.get("sub_id"), str(ev.get("detail") or "")[:80])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(ev)
    for i, ev in enumerate(uniq):
        ev["seq"] = i + 1
    counts = {}
    for ev in uniq:
        counts[ev.get("kind") or "audit"] = counts.get(ev.get("kind") or "audit", 0) + 1
    items = uniq[:limit]
    return {"ok": True, "case_id": case_id,
            "scope": {"case_id": case_id,
                      "finding_ids": sorted(x for x in finding_ids if x),
                      "result_ids": sorted(x for x in result_ids if x),
                      "object_ids": sorted(x for x in object_ids if x),
                      "sub_ids": sorted(x for x in sub_ids if x),
                      "evidence_ids": sorted(x for x in evidence_ids if x)},
            "total": len(uniq), "counts": counts, "items": items,
            "events": items, "truncated": len(uniq) > len(items),
            "note": "按时间正序；复核=decision/manifest_review，补证=evidence，"
                    "重判=review.*（含补证前后结论与模型可用性）"}


def reaudit(result_id: str = "", sub_id: str = "", finding_id: str = "",
            evidence_text: str = "", evidence_ref: str = "", reviewer: str = "",
            role: str = "", reason: str = "", evidence_id: str = "",
            user_id: str = "", actor: str = "", text: str = "",
            evidence: str = "") -> dict:
    """统一重判入口：result_id + sub_id 走子要求重判；finding_id 走语义重判。"""
    if result_id:
        return reaudit_subrequirement(result_id, sub_id, evidence_text, evidence_ref,
                                      reviewer, role, reason, evidence_id,
                                      user_id=user_id, actor=actor, text=text,
                                      evidence=evidence)
    if finding_id:
        return reaudit_finding_semantic(finding_id, evidence_text, evidence_ref,
                                        reviewer, role, reason, actor=actor,
                                        user_id=user_id, text=text,
                                        evidence=evidence)
    return {"error": "必须提供 result_id 或 finding_id", "code": "missing_target",
            "status": 400}


def reaudit_semantic(*args, **kwargs) -> dict:
    """语义重判兼容入口：finding_id 或 result_id + sub_id 两种调用都支持。

    常见别名 evidence/text/supplement 统一映射到 evidence_text，避免调用方因
    参数名差异误以为“没有补证材料”。
    """
    evidence_text = str(kwargs.pop("evidence_text", "") or kwargs.pop("evidence", "")
                        or kwargs.pop("text", "") or kwargs.pop("supplement", "") or "")
    result_id = str(kwargs.pop("result_id", "") or "")
    sub_id = str(kwargs.pop("sub_id", kwargs.pop("subrequirement_id", "")) or "")
    finding_id = str(kwargs.pop("finding_id", "") or "")
    evidence_ref = str(kwargs.pop("evidence_ref", "") or "")
    reviewer = str(kwargs.pop("reviewer", "") or "")
    user_id = str(kwargs.pop("user_id", "") or "")
    actor = str(kwargs.pop("actor", "") or "")
    role = str(kwargs.pop("role", "") or "")
    reason = str(kwargs.pop("reason", "") or "")
    evidence_id = str(kwargs.pop("evidence_id", "") or "")
    if kwargs:
        return {"error": "未知参数：" + ",".join(sorted(kwargs.keys())),
                "code": "unexpected_argument", "status": 400}
    if args:
        first = str(args[0])
        if not result_id and not finding_id:
            if _rea_load_result(first):
                result_id = first
            elif _rea_load_finding(first):
                finding_id = first
            else:
                return {"error": "重判目标不存在", "code": "not_found", "status": 404}
        if len(args) > 1:
            if result_id and not sub_id:
                sub_id = str(args[1])
            elif finding_id and not evidence_text:
                evidence_text = str(args[1])
        if len(args) > 2 and result_id and not evidence_text:
            evidence_text = str(args[2])
    return reaudit(result_id, sub_id, finding_id, evidence_text, evidence_ref,
                   reviewer, role, reason, evidence_id, user_id=user_id,
                   actor=actor)


# P0/P1 语义闭环：review 作为既有服务层入口，内部委托 semantic_core。
# 这两个函数不改变默认审核链；只有显式调用才会读写语义重审数据。
def semantic_root_cause(target, **kwargs) -> dict:
    """读取 finding/结果的结构化根因（unit/conflict/missing/logic/evidence/model）。"""
    from . import semantic_core
    return semantic_core.root_cause(target, **kwargs)


def reaudit_same_case(case_id: str, **kwargs) -> dict:
    """同案例语义重审：保留旧 run/finding，新建 run，返回 old/new/diff。"""
    from . import semantic_core
    return semantic_core.reaudit_same_case(case_id, **kwargs)


# 兼容别名：调用方可用更短/更直白的名字，行为完全一致。
reaudit_semantic_finding = reaudit_finding_semantic
semantic_reaudit = reaudit_semantic
reaudit_sub = reaudit_subrequirement
subrequirement_reaudit = reaudit_subrequirement
case_review_timeline = review_timeline
finding_timeline = review_timeline
review_history = review_timeline
review_trail = review_timeline
timeline = review_timeline
rejudge = reaudit
rejudge_semantic = reaudit_semantic
semantic_rejudge = reaudit_semantic
