"""统一审核请求契约（阶段 A 的入口层）。

说明：当前内部仍有 project 与 legacy 两套实现；本模块只把入口参数、
模式默认值和调度收敛到一个 AuditRequest，后续再把内部 pipeline 合并。
不把“已统一入口”夸大为“双链已彻底合并”。
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class AuditRequest:
    case_id: str = ""
    source: str = "project"          # project | legacy
    mode: str = "assisted"           # manual | assisted | legacy
    doc_type: str = ""
    policy_text: str = ""
    semantic: bool = False
    doc_paths: tuple[str, ...] = ()
    points_path: str = ""
    name: str = ""
    created_by: str = ""
    # DU-17（2026-11-25）：本次审核的真实发起人（HTTP 会话 / CLI --user）；
    # 透传到 project.audit(actor=...) 供 project.audited 等审计归因。
    actor: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    def ai_assist(self):
        if self.mode == "legacy":
            return None
        return self.mode != "manual"

    def normalized(self):
        # legacy 只是来源/传输适配器，不改变产品两模式；旧 full 不再是公共模式
        mode = self.mode if self.mode in ("manual", "assisted") else "assisted"
        return AuditRequest(**{**self.__dict__, "mode": mode})


def run(req: AuditRequest) -> dict:
    req = req.normalized()
    if req.source == "legacy":
        _pp = str(req.points_path or "")
        # L52 ②：points_path 默认 fail-closed，不再静默丢弃（L46a H03/H04）。
        # L58 ②：旧链放行再加一道「部署级二次确认」——只有部署环境同时显式设置
        #   RULEPROOF_ALLOW_LEGACY_POINTS=1 与 RULEPROOF_LEGACY_POINTS_DEPLOYMENT=1
        #   才执行旧链（默认不存在 / 请求参数不能打开该开关）。单独 ALLOW=1 视为
        #   未部署授权 → 显式审计 legacy.points_path_deployment_blocked 并走项目主链。
        #   三条分支：
        #   - 两个 env 都在 → 旧链执行 + 审计 legacy.points_path_enabled + legacy_only 标注；
        #   - 仅 ALLOW=1（无部署标记）→ 显式审计 deployment_blocked，fail-closed 走主链；
        #   - 默认（无开关）→ 显式审计 legacy.points_path_rejected，fail-closed 走主链。
        # 回退杆 RULEPROOF_SINGLE_ENTRY_FIX=0 → 逐字段回退旧行为（静默丢弃）。
        try:
            from . import single_entry as _se
            _fix_on = _se.enabled()
        except Exception:  # noqa: BLE001
            _se, _fix_on = None, False
        _points_ok = os.environ.get("RULEPROOF_ALLOW_LEGACY_POINTS") == "1"
        _deploy_ok = True
        _switch_state = {}
        if _fix_on and _se is not None:
            try:
                _deploy_ok = _se.legacy_points_deployment_enabled()
                _switch_state = _se.legacy_points_switch_state()
            except Exception:  # noqa: BLE001 - 部署标记不可读时按未部署收紧
                _deploy_ok = False
        _legacy_allowed = bool(_pp and _points_ok and _deploy_ok)
        if _legacy_allowed:
            from . import review
            out = review.run_review(
                req.name or req.case_id or "legacy", list(req.doc_paths),
                points_path=req.points_path, semantic=req.semantic, created_by=req.created_by)
            if _fix_on:
                _se.audit("legacy.points_path_enabled", req.name or req.case_id or "legacy", {
                    "entry": "audit_orchestrator.run(legacy)",
                    "points_path": _pp[:300],
                    "legacy_only": True,
                    "manifest_id": "",
                    "report_signing_blocked": True,
                    "deployment_confirmed": True,
                    "switch_state": _switch_state,
                    "note": "显式开关 + 部署级二次确认放行旧版标准对照；"
                            "legacy 链无 manifest，报告禁止签发",
                })
                _se.annotate(out, execution_entry="audit_orchestrator.run(legacy)",
                             legacy_only=True, manifest_id="",
                             report_signing="blocked_without_manifest",
                             legacy_points={"requested": True, "executed": True,
                                            "fail_closed": False,
                                            "deployment_confirmed": True,
                                            "allow_env": "RULEPROOF_ALLOW_LEGACY_POINTS=1",
                                            "deployment_env":
                                                "RULEPROOF_LEGACY_POINTS_DEPLOYMENT=1"})
            return out
        if _pp and _fix_on and _points_ok and not _deploy_ok:
            # L58 ②：开关被设置但缺部署级二次确认 → 显式阻断（不是静默忽略）。
            _se.audit("legacy.points_path_deployment_blocked",
                      req.name or req.case_id or "legacy", {
                          "entry": "audit_orchestrator.run(legacy)",
                          "points_path": _pp[:300],
                          "executed": False,
                          "fail_closed": True,
                          "deployment_marker_required_check": "missing",
                          "switch_state": _switch_state,
                          "reason": "ALLOW_LEGACY_POINTS 已设置但缺少部署级二次确认 "
                                    "RULEPROOF_LEGACY_POINTS_DEPLOYMENT=1；"
                                    "判定为未部署授权，旧链不执行（请求走 project 主链）",
                          "allow_env": "RULEPROOF_ALLOW_LEGACY_POINTS=1",
                          "deployment_env": "RULEPROOF_LEGACY_POINTS_DEPLOYMENT=1",
                      })
        elif _pp and _fix_on:
            _se.audit("legacy.points_path_rejected", req.name or req.case_id or "legacy", {
                "entry": "audit_orchestrator.run(legacy)",
                "points_path": _pp[:300],
                "executed": False,
                "fail_closed": True,
                "reason": "points_path 已日落：默认拒绝旧点位直传（不再静默丢弃；"
                          "请求已走 project 主链，points_path 未生效）",
                "allow_env": "RULEPROOF_ALLOW_LEGACY_POINTS=1",
                "deployment_env": "RULEPROOF_LEGACY_POINTS_DEPLOYMENT=1",
            })
        from . import review_compat
        out = review_compat.run_review_api(
            req.name or req.case_id or "legacy", list(req.doc_paths),
            user=req.created_by, ai_assist=req.ai_assist(), compat_mode="legacy")
        if _pp and _fix_on:
            _deploy_blocked = bool(_points_ok and not _deploy_ok)
            _se.annotate(
                out, execution_entry="audit_orchestrator.run(legacy)",
                legacy_points={"requested": True, "executed": False,
                               "fail_closed": True,
                               "deployment_marker_required": True,
                               "deployment_marker_missing": _deploy_blocked,
                               "reason": ("ALLOW_LEGACY_POINTS 已设置但缺部署级二次确认："
                                          "未部署授权，旧链不执行，已显式审计"
                                          if _deploy_blocked else
                                          "points_path 默认日落拒绝：未生效，已显式审计"),
                               "allow_env": "RULEPROOF_ALLOW_LEGACY_POINTS=1",
                               "deployment_env":
                                   "RULEPROOF_LEGACY_POINTS_DEPLOYMENT=1"})
        return out
    from . import project
    if not req.case_id:
        raise ValueError("project 审核缺少 case_id")
    # L58 ②：产品 audit 入口不传播旧链 points 开关；env 即使被设置也只留审计取证，
    # 不改变执行路径（旧链只能经 review_legacy 显式 legacy=True 适配器）。
    try:
        from . import single_entry as _se_prod
        _st_prod = _se_prod.legacy_points_switch_state()
        if _se_prod.enabled() and (_st_prod.get("switch_set")
                                   or _st_prod.get("deployment_set")):
            _se_prod.audit("legacy.points_path_switch_ignored", req.case_id or "", {
                "entry": "audit_orchestrator.run(project)",
                "switch_state": _st_prod,
                "ignored": True,
                "note": "产品 audit 入口不读取/不传播 legacy points 开关；"
                        "本次仍走 manifest 主链",
            })
    except Exception:  # noqa: BLE001 - 审计取证失败不影响主链
        pass
    return project.audit(req.case_id, semantic=req.semantic,
                         ai_assist=req.ai_assist(), doc_type=req.doc_type,
                         policy_text=req.policy_text, actor=req.actor)


def from_project(case_id: str, ai_assist=True, doc_type: str = "", policy_text: str = "",
                 semantic: bool = False, actor: str = "") -> AuditRequest:
    return AuditRequest(case_id=case_id, source="project",
                        mode="assisted" if ai_assist else "manual",
                        doc_type=doc_type, policy_text=policy_text, semantic=semantic,
                        actor=actor)


def from_legacy(name: str, doc_paths, points_path: str = "", semantic: bool = False,
                created_by: str = "", mode: str = "assisted") -> AuditRequest:
    if mode not in ("manual", "assisted"):
        mode = "assisted"
    return AuditRequest(case_id="", source="legacy", mode=mode,
                        doc_paths=tuple(doc_paths or ()), points_path=points_path,
                        name=name, semantic=semantic, created_by=created_by)
