"""统一审核台账：manifest（客户规则）与平台点位 point_state 的唯一汇总入口。

只做汇总，不替换执行器。每个 (object, code, sub) 只保留一条，manifest 优先。

定向复审收口（本轮新增 ``apply_reaudit``）：
- 复审结果行（manifest_result）、新 manifest、active 指针切换、case 当前 run、
  audit_run 轨迹、审计日志、台账前后快照全部在**调用方同一个事务**内完成；
- ``manifest_active`` 是台账与报告的唯一 active 来源：切换后 ``summary()``、
  ``report._manifest_rows`` 立刻读到复审新结论，旧 result 行原样保留可追溯；
- 失败即整体回滚，不会出现“台账/报告/active 各说各话”。
"""
from __future__ import annotations
import json
import logging
import os
from .. import db
from . import state_machines as _state_machines

_LOG = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 统一状态归一（T-82 / M1，2026-11-18）
#
# 背景（T-80 §3.6 / §5-M1）：manifest D4 子要求会把「不适用」按字面状态
# ``not_applicable`` 落库（manifest_exec 冻结判据/决策表 skipped 路径），平台点位
# 历史数据也可能写 ``not applicable``/``skipped``。报告分类层原先只认 ``state == "na"``，
# 这些**确定的“不适用”**被折成 unknown，导致报告门禁误阻断（首次放行 1/94；
# 429 个阻断对象中 150 个来自 D5 na）。
#
# 本函数是台账 / 报告四类口径 / 报告门禁 / 报告渲染的唯一归一事实源：
# - 只归一同义状态（na 家族 / pass / fail / insufficient / unknown / missing /
#   execution 家族），**绝不把 na 折成 pass/fail，也不把未知折成 na**；
# - 无法识别的取值原样返回（调用方仍按 unknown 处理，保持 fail-closed）。
# ``review._report_categories``、``report_gate``、``report`` 必须调用本函数，
# 禁止各自再维护一套 na 字面量。
# DU-29（2026-11-25）：别名/na 家族单一事实源已集中到 ``state_machines``
# （``NA_STATES`` / ``VERDICT_ALIASES`` / ``normalize_verdict``），由 manifest D5
# 六态组合与本节台账/报告口径**共用**，不再各自维护第二份别名表。
# 本模块只保留「规范态 → 台账/报告域取值」的轴映射（execution_failed 记为 failed；
# 历史口径 blocked 与 failed 分列保留），不是第二份别名表。
NA_STATES = _state_machines.NA_STATES
_LEDGER_AXIS = {"execution_failed": "failed"}
_LEDGER_RAW_KEEP = {"blocked": "blocked"}


def normalize_state(raw) -> str:
    """任意落库状态 → 统一规范状态（别名表在 state_machines；只归一同义状态）。

    - 无法识别的取值原样返回（调用方仍按 unknown 处理，保持 fail-closed）；
    - 空值 → unknown（不得当 pass/fail）。
    """
    s = str(raw if raw is not None else "").strip()
    if not s:
        return "unknown"
    low = s.lower()
    if low in _LEDGER_RAW_KEEP:
        return _LEDGER_RAW_KEEP[low]
    canon = _state_machines.normalize_verdict(s, passthrough_unknown=True)
    return _LEDGER_AXIS.get(canon, canon)


def is_na_state(raw) -> bool:
    """是否为「不适用」同义状态（not_applicable/not applicable/skipped/na…）。"""
    return normalize_state(raw) == "na"


def _state_of_conclusion(c: str) -> str:
    """落库结论中文 → 规范状态；只认明确的五态结论，其余按 unknown（fail-closed）。"""
    s = str(c or "").strip()
    mapped = {"满足": "pass", "不满足": "fail", "不适用": "na",
              "证据不足": "insufficient", "无法判断": "unknown"}.get(s)
    if mapped:
        return mapped
    canon = normalize_state(s)
    return canon if canon in ("pass", "fail", "na", "insufficient", "unknown") else "unknown"


def _active_results_on(c, case_id: str) -> list:
    """在给定连接（可为事务连接）上读取当前 active 结果。"""
    rows = [dict(r) for r in c.execute(
        "SELECT mr.*, m.objects_json, m.items_json FROM manifest_active ma "
        "JOIN manifest_result mr ON mr.id=ma.result_id "
        "JOIN audit_manifest m ON m.id=mr.manifest_id WHERE ma.case_id=? "
        "ORDER BY mr.rule_code,mr.object_id", (case_id,))]
    if rows:
        return rows
    ar = c.execute("SELECT manifest_id FROM audit_run WHERE case_id=? "
                   "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
    mid = (ar["manifest_id"] if ar else "") or ""
    if not mid:
        return []
    m = c.execute("SELECT objects_json,items_json FROM audit_manifest WHERE id=?", (mid,)).fetchone()
    objs = m["objects_json"] if m else "[]"
    its = m["items_json"] if m else "[]"
    return [{**dict(r), "objects_json": objs, "items_json": its} for r in c.execute(
        "SELECT * FROM manifest_result WHERE manifest_id=? ORDER BY rule_code,object_id", (mid,))]


def _active_results(case_id: str) -> list:
    with db.session() as c:
        return _active_results_on(c, case_id)


def _summary_on(c, case_id: str) -> dict:
    """在给定连接上计算台账摘要（不提交、不新建连接）。"""
    if not case_id:
        return {"error": "缺少 case_id"}
    records, seen = [], set()
    expected = []
    objs = {}
    for r in _active_results_on(c, case_id):
        try:
            for o in json.loads(r.get("objects_json") or "[]"):
                objs[o.get("object_id")] = o.get("filename") or ""
        except Exception:
            pass
        try:
            for _it in json.loads(r.get("items_json") or "[]"):
                expected.append((str(_it.get("object_id") or ""), str(_it.get("code") or "")))
        except Exception:
            pass
        code = str(r.get("rule_code") or "")
        obj = str(r.get("object_id") or "")
        try:
            subs = (json.loads(r.get("d4_json") or "{}")).get("subs") or []
        except Exception:
            subs = []
        base_state = _state_of_conclusion(r.get("conclusion") or "")
        if not subs:
            key = (obj, code, "")
            if key not in seen:
                seen.add(key)
                records.append({"source": "manifest", "object_id": obj,
                                "object": objs.get(obj, ""), "code": code, "sub_id": "",
                                "state": base_state, "result_id": r.get("id")})
            continue
        for s in subs:
            sid = str(s.get("id") or "")
            key = (obj, code, sid)
            if key in seen:
                continue
            seen.add(key)
            records.append({"source": "manifest", "object_id": obj,
                            "object": objs.get(obj, ""), "code": code, "sub_id": sid,
                            "state": normalize_state(s.get("status") or base_state),
                            "result_id": r.get("id")})
    for _obj, _code in expected:
        if (_obj, _code, "") in seen or any(x[0] == _obj and x[1] == _code for x in seen):
            continue
        seen.add((_obj, _code, ""))
        records.append({"source": "manifest", "object_id": _obj, "object": objs.get(_obj, ""),
                        "code": _code, "sub_id": "", "state": "missing", "result_id": ""})
    # 平台点位 actual：最近一次 run 的 batch
    ar = c.execute("SELECT batch_ids FROM audit_run WHERE case_id=? "
                   "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
    bids = [x for x in str((ar["batch_ids"] if ar else "") or "").split(",") if x]
    if bids:
        q = ",".join("?" for _ in bids)
        ps = [dict(r) for r in c.execute(
            "SELECT point_id,file_id,state,batch_id FROM point_state WHERE batch_id IN (" + q + ")",
            tuple(bids))]
    else:
        ps = []
    _point_seen = set()
    for r in ps:
        _pid = str(r.get("point_id") or "")
        _point_seen.add(_pid)
        key = (str(r.get("file_id") or ""), _pid, "")
        if key in seen:
            continue
        seen.add(key)
        records.append({"source": "platform_point", "object_id": "", "object": str(r.get("file_id") or ""),
                        "code": _pid, "sub_id": "",
                        "state": normalize_state(r.get("state") or "unknown"), "result_id": ""})
    # 平台点位 plan 的 expected：没有 point_state 记为 missing
    ar2 = c.execute("SELECT plan_json FROM audit_run WHERE case_id=? "
                    "ORDER BY created_at DESC, rowid DESC LIMIT 1", (case_id,)).fetchone()
    try:
        _plan = json.loads((ar2["plan_json"] if ar2 else "") or "[]")
    except Exception:
        _plan = []
    if isinstance(_plan, dict):
        _plan = [_plan]
    for e in _plan or []:
        _pid = str((e or {}).get("point_id") or "")
        if not _pid or _pid in _point_seen:
            continue
        records.append({"source": "platform_point", "object_id": "", "object": "",
                        "code": _pid, "sub_id": "", "state": "missing", "result_id": ""})
    counts = {}
    for r in records:
        counts[r["state"]] = counts.get(r["state"], 0) + 1
    return {"ok": True, "case_id": case_id, "total": len(records),
            "counts": counts, "records": records,
            # 不适用（na 家族归一同源）既不是 pass/fail，也不得计入 unknown；
            # 真实 unknown/insufficient/missing 仍单列并计入 unknown_count（fail-closed）
            "state_pass_count": counts.get("pass", 0),
            "state_fail_count": counts.get("fail", 0),
            "state_na_count": counts.get("na", 0),
            "state_not_applicable_count": counts.get("na", 0),
            "unknown_count": sum(counts.get(k, 0) for k in ("unknown", "insufficient", "missing")),
            "state_unknown_count": counts.get("unknown", 0),
            "state_insufficient_count": counts.get("insufficient", 0),
            "state_missing_count": counts.get("missing", 0),
            "missing_count": counts.get("missing", 0),
            "source": "manifest+platform_point"}


def summary(case_id: str) -> dict:
    if not case_id:
        return {"error": "缺少 case_id"}
    with db.session() as c:
        return _summary_on(c, case_id)


def _insert_manifest_result(c, row: dict) -> str:
    c.execute("INSERT OR REPLACE INTO manifest_result(id,manifest_id,item_key,object_id,rule_id,"
              "rule_code,d1_json,d2_json,d3_json,d4_json,d5_json,conclusion,execution,updated_at,"
              "review_status,review_reason,reviewer,reviewed_at) "
              "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
              (row.get("id"), row.get("manifest_id"), row.get("item_key") or "",
               row.get("object_id") or "", row.get("rule_id") or "",
               row.get("rule_code") or "", row.get("d1_json") or "{}",
               row.get("d2_json") or "{}", row.get("d3_json") or "{}",
               row.get("d4_json") or "{}", row.get("d5_json") or "{}",
               row.get("conclusion") or "", row.get("execution") or "",
               row.get("updated_at") or db.now(), row.get("review_status") or "pending",
               row.get("review_reason") or "", row.get("reviewer") or "",
               row.get("reviewed_at") or ""))
    return row.get("id")


def _switch_active(c, case_id: str, results: list) -> int:
    """把 (object, rule) 的 active 指针切到复审新结果；子要求级同步。"""
    switched = 0
    for row in results:
        obj = str(row.get("object_id") or "")
        code = str(row.get("rule_code") or "")
        rid = str(row.get("id") or "")
        if not code or not rid:
            continue
        c.execute("INSERT INTO manifest_active(case_id,object_id,rule_code,result_id,updated_at) "
                  "VALUES(?,?,?,?,?) ON CONFLICT(case_id,object_id,rule_code) DO UPDATE SET "
                  "result_id=excluded.result_id, updated_at=excluded.updated_at",
                  (case_id, obj, code, rid, db.now()))
        try:
            subs = (json.loads(row.get("d4_json") or "{}")).get("subs") or []
        except Exception:
            subs = []
        if not subs:
            subs = [{"id": "", "status": ""}]
        for sub in subs:
            c.execute("INSERT INTO manifest_active_sub(case_id,object_id,rule_code,sub_id,"
                      "result_id,status,updated_at) VALUES(?,?,?,?,?,?,?) "
                      "ON CONFLICT(case_id,object_id,rule_code,sub_id) DO UPDATE SET "
                      "result_id=excluded.result_id,status=excluded.status,updated_at=excluded.updated_at",
                      (case_id, obj, code, str(sub.get("id") or ""), rid,
                       str(sub.get("status") or ""), db.now()))
        switched += 1
    return switched


def apply_reaudit(conn, case_id: str, *, manifest: dict, results: list,
                  activate: bool = True, case_updates: dict | None = None,
                  run: dict | None = None, audit: dict | None = None,
                  manifest_exists: bool = False, results_exist: bool = False,
                  restore_results: list | None = None,
                  clear_active_keys: list | None = None,
                  replace_sub_keys: list | None = None) -> dict:
    """定向复审收口（必须在调用方 ``db.session()`` 事务连接内调用）。

    同一事务内完成：
    1. 写新 manifest + 复审 result 行（旧 manifest/result 不删不改）；
    2. ``activate=True`` 时切换 manifest_active / manifest_active_sub 到新结果；
    3. 更新 case 当前 run（报告口径）+ 写 audit_run 轨迹 + 审计日志；
    4. 回读台账 before/after（同一连接，含未提交变更），作为「台账已更新」的证据。

    L58 ①（单路径）：复审执行已交给 ``manifest_exec.run``（它自己提交 manifest_result /
    active），收口事务只需补齐 finding/run/审计，因此：
    - ``manifest_exists=True``：新 manifest 已由调用方写入，不重复 INSERT；
    - ``results_exist=True``：result 行已由 run 写入，只取既有 id，不重复 INSERT；
    - ``activate=False``：把 ``restore_results``（旧 active 行）切回去，并删除
      ``clear_active_keys`` 中「旧状态本无 active」的指针（候选模式不改变 active）；
    - ``activate=True``：按本次 result 行切 active（run 已切过，幂等重切）。
    默认参数保持旧行为（旧第二执行器收口路径逐字段不变）。

    返回 ``{ledger_before, ledger_after, active_switched, result_ids}``。
    """
    ledger_before = _summary_on(conn, case_id)
    m = manifest or {}
    if not manifest_exists:
        conn.execute("INSERT INTO audit_manifest(id,case_id,run_id,tenant_id,workspace_id,source,"
                     "status,objects_json,rules_json,items_json,hash,created_at,created_by) "
                     "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (m.get("id"), case_id, m.get("run_id") or "", m.get("tenant_id") or "",
                      m.get("workspace_id") or "", m.get("source") or "reaudit",
                      m.get("status") or "reaudit",
                      m.get("objects_json") or "[]", m.get("rules_json") or "[]",
                      m.get("items_json") or "[]", m.get("hash") or "",
                      m.get("created_at") or db.now(), m.get("created_by") or ""))
    result_ids = []
    if results_exist:
        result_ids = [str((row or {}).get("id") or "") for row in (results or [])]
    else:
        for row in results or []:
            row = dict(row)
            row.setdefault("manifest_id", m.get("id"))
            result_ids.append(_insert_manifest_result(conn, row))
    if run:
        cols = ("id", "case_id", "created_at", "created_by", "audit_type", "focus",
                "total", "critical", "warning", "suspected", "trace_json", "plan_json",
                "batch_ids", "manifest_id", "point_library_version")
        present = [k for k in cols if k in run]
        conn.execute("INSERT INTO audit_run(" + ",".join(present) + ") VALUES(" +
                     ",".join("?" for _ in present) + ")",
                     tuple(run.get(k) for k in present))
    switched = 0
    if activate:
        # L58 ①：active 子要求按本轮结果收口（避免 run 写入的 active_sub 与本轮
        # 结果行的子要求口径混在一起）。
        for key in replace_sub_keys or []:
            obj, code = str((key or [""])[0]), str((key or ["", ""])[1]) if len(key or []) > 1 else ""
            if not code:
                continue
            conn.execute("DELETE FROM manifest_active_sub WHERE case_id=? AND object_id=? "
                         "AND rule_code=?", (case_id, obj, code))
        switched = _switch_active(conn, case_id, results)
    elif restore_results or clear_active_keys:
        # L58 ①：候选模式（不 activate）→ 撤销 run 期间对 active 的切换，保持旧指针。
        for key in clear_active_keys or []:
            obj, code = str((key or [""])[0]), str((key or ["", ""])[1]) if len(key or []) > 1 else ""
            if not code:
                continue
            conn.execute("DELETE FROM manifest_active WHERE case_id=? AND object_id=? "
                         "AND rule_code=?", (case_id, obj, code))
            conn.execute("DELETE FROM manifest_active_sub WHERE case_id=? AND object_id=? "
                         "AND rule_code=?", (case_id, obj, code))
        _switch_active(conn, case_id, restore_results or [])
    if activate and case_updates:
        sets = ",".join(f"{k}=?" for k in case_updates)
        conn.execute(f"UPDATE audit_case SET {sets} WHERE id=?",
                     tuple(case_updates.values()) + (case_id,))
    if audit:
        conn.execute("INSERT INTO audit_log(id,actor,action,object,before_json,after_json,created_at) "
                     "VALUES(?,?,?,?,?,?,?)",
                     (db.new_id("log"), audit.get("actor") or "system",
                      audit.get("action") or "case.reaudited", audit.get("object") or case_id,
                      audit.get("before") or "{}", audit.get("after") or "{}", db.now()))
    ledger_after = _summary_on(conn, case_id)
    return {"ledger_before": ledger_before, "ledger_after": ledger_after,
            "active_switched": switched, "result_ids": result_ids,
            "activated": bool(activate), "manifest_id": m.get("id")}


# ===========================================================================
# L87（2026-11-24）审计状态跨写入点一致性：状态机 / 恢复事件 / 对账
# ===========================================================================
# 背景（外部复验 §7 P0-3；L77 后续）：L77 已让「manifest.executed 审计写失败」传播为
# run.audit_failed → project.audit 409 / 语义重审 409 / report_gate 阻断签发。但
# case / run / 正式报告 / 语义重审四个写入点各自维护状态，失败-恢复后的状态一致性、
# 「恢复事件唯一（幂等）」「无重复事件 / 无半状态」仍缺可验证的单一事实源。
#
# 本段是审计状态的**唯一读模型 + 唯一恢复写点**（report_gate / report / project /
# semantic_core 全部调用它，不得各写一套）：
#
# 1) 状态定义（由三个持久事实推导，不新增表/列）：
#    - `audit_case.status`：durable 案件状态（audit_failed 是失败唯一持久标记之一）；
#    - `audit_case.last_run_id`：当前**成功**批次指针（报告/台账口径）；
#    - `audit_run.trace_json.manifest_audit.audit_failed` / `trace_json.audit_failed`：
#      单批次「manifest.executed 审计是否落库」标记（L77 写点）；
#    - `audit_log`：不可变事件（失败留痕 / 唯一 audit.recovered 恢复事件）。
#
#    合法状态：
#      clean         : case=completed 且当前 run 无 audit_failed 标记、无更新失败批次
#      running       : case=auditing/reviewing（执行中；不可签发，但非失败结论）
#      failed        : case=audit_failed（失败持久标记；即使 run 标记缺失也不得签发）
#      inconsistent  : 来源互相矛盾（case=completed 但当前/更新批次 audit_failed；
#                      last_run_id 悬空等）→ fail-closed，不可签发，对账可修
#      not_run       : 未审核（由既有门禁原因阻断，不是审计状态问题）
#
# 2) 合法/非法迁移（四写点必须一致）：
#      completed/running --(审计写失败)--> failed + run 标记 + 失败事件（各写点一份）
#      failed --(成功重跑/成功重审 activate)--> completed + **恰好一条** audit.recovered
#      failed --(再次失败)--> failed（同一失败纪元不重复写恢复事件；失败事件按批次各一条）
#      completed --(再次成功)--> completed（非恢复，不写 audit.recovered）
#      非法：completed + 当前 run audit_failed；audit_failed + 无任何失败证据（只告警）；
#            恢复事件无对应失败纪元 / 同纪元重复恢复事件 / 失败态下已签发报告。
#
# 3) 恢复事件幂等：request_id = ``audit-recovery:<case>:<failure_epoch>``，以
#    ``INSERT ... SELECT ... WHERE NOT EXISTS`` 单语句原子落库（跨线程/进程并发唯一）；
#    重复恢复（同纪元）不新增事件。失败纪元优先取失败 run id（保留有 trace 的失败批次），
#    其次取最近失败事件 id，最后回退 last_run_id（语义重审失败批次按 L58 契约被清理）。
#
# 4) 回退开关：``RULEPROOF_AUDIT_STATE_CONSISTENCY``（默认 1）。=0 时：
#    不写恢复事件、不把重审失败升级为 case=audit_failed、report_gate 不做状态一致性
#    门禁（L77 标记门禁保持不变）→ 逐字段回到 L77 行为，供排障/回退验证。
AUDIT_STATE_ENV = "RULEPROOF_AUDIT_STATE_CONSISTENCY"
RECOVERY_ACTION = "audit.recovered"
# 失败事件（用于跨写点对账与恢复纪元识别；均为不可变 audit_log 行）
_FAILURE_ACTIONS = ("manifest.audit_write_failed", "reaudit.audit_write_failed",
                    "audit_write_failed", "project.audit_failed", "audit.failed")
_OFF_VALUES = frozenset({"0", "false", "no", "off", "disabled"})


def audit_state_consistency_enabled() -> bool:
    """L87 审计状态一致性开关（默认开；=0 回退 L77 行为）。"""
    # 字面量读取（开关注册表门禁要求可静态发现的产品读取点；AUDIT_STATE_ENV 为文档常量）
    raw = os.environ.get("RULEPROOF_AUDIT_STATE_CONSISTENCY", "1")
    if raw is None:
        return True
    try:
        return str(raw).strip().lower() not in _OFF_VALUES
    except Exception:  # noqa: BLE001 - 取值异常按默认开（fail-closed）
        return True


def _l87_case_row(c, case_id: str) -> dict:
    r = c.execute("SELECT * FROM audit_case WHERE id=?", (str(case_id or ""),)).fetchone()
    return dict(r) if r else {}


def _l87_run_marker(trace_json) -> dict:
    """run trace → 审计标记（唯一解析口径；兼容 L77 顶层与 manifest_audit 嵌套两种写法）。"""
    try:
        trace = json.loads(trace_json or "{}")
    except Exception:
        trace = {}
    if not isinstance(trace, dict):
        trace = {}
    ma = trace.get("manifest_audit")
    ma = ma if isinstance(ma, dict) else {}
    failed = (trace.get("audit_failed") is True
              or ma.get("audit_failed") is True)
    return {"audit_failed": bool(failed), "manifest_audit": ma, "trace": trace}


def _l87_runs(c, case_id: str) -> list:
    rows = c.execute(
        "SELECT id,case_id,created_at,manifest_id,trace_json FROM audit_run "
        "WHERE case_id=? ORDER BY created_at, rowid", (str(case_id or ""),)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["marker"] = _l87_run_marker(d.get("trace_json"))
        out.append(d)
    return out


def _l87_failure_events(c, case_id: str, limit: int = 50) -> list:
    """案件相关失败事件（object=case 或 after_json 内嵌 case_id；L77 写点 object 为 manifest）。"""
    q = ("SELECT id,action,object,created_at,rowid FROM audit_log WHERE action IN ("
         + ",".join("?" for _ in _FAILURE_ACTIONS) + ") AND (object=? OR after_json LIKE ?) "
         "ORDER BY rowid DESC LIMIT ?")
    params = tuple(_FAILURE_ACTIONS) + (str(case_id or ""), f"%{case_id}%", int(limit))
    try:
        return [dict(r) for r in c.execute(q, params).fetchall()]
    except Exception:  # noqa: BLE001 - 对账口径失败不阻断主链（状态仍以 case/run 为准）
        _LOG.warning("L87 failure event query skipped case=%s", case_id, exc_info=True)
        return []


def _l87_failure_epoch(c, case_id: str, case: dict, runs: list) -> dict:
    """失败纪元标识（恢复事件幂等键）：优先失败 run id，其次最近失败事件 id。"""
    failed_runs = [r for r in runs if (r.get("marker") or {}).get("audit_failed")]
    events = _l87_failure_events(c, case_id)
    run_epoch = ""
    run_time = ""
    if failed_runs:
        latest = failed_runs[-1]
        run_epoch = "run:" + str(latest.get("id") or "")
        run_time = str(latest.get("created_at") or "")
    evt_epoch, evt_time = "", ""
    if events:
        evt = events[0]
        evt_epoch = "evt:" + str(evt.get("id") or "")
        evt_time = str(evt.get("created_at") or "")
    epoch, source = "", ""
    if run_epoch and evt_epoch:
        if evt_time >= run_time:       # 事件与 run 同秒/更晚 → 事件纪元（写点留痕优先）
            epoch, source = evt_epoch, "event"
        else:
            epoch, source = run_epoch, "run"
    elif run_epoch:
        epoch, source = run_epoch, "run"
    elif evt_epoch:
        epoch, source = evt_epoch, "event"
    else:
        epoch = "case:" + str(case.get("last_run_id") or "no-run")
        source = "case"
    return {"epoch": epoch, "source": source,
            "failed_run_id": str((failed_runs[-1] or {}).get("id") or "") if failed_runs else "",
            "event_id": str((events[0] or {}).get("id") or "") if events else ""}


def audit_state(case_id: str) -> dict:
    """审计状态唯一读模型（case.status + 当前/最新 run 标记 + 恢复事件）。

    report_gate / report / project / semantic_core 共用；只读、不写库、无副作用。
    """
    cid = str(case_id or "")
    out = {"ok": False, "case_id": cid, "enabled": audit_state_consistency_enabled(),
           "state": "unknown", "signable": False, "blocking": False,
           "case_status": "", "last_run_id": "", "current_run_id": "",
           "current_run_audit_failed": False, "latest_run_id": "",
           "latest_run_audit_failed": False, "failed_run_ids": [],
           "failure_epoch": "", "failure_epoch_source": "",
           "recovered_event_count": 0, "last_recovery": {},
           "reasons": [], "inconsistent_reasons": []}
    if not cid:
        out["reasons"].append("缺少 case_id")
        return out
    try:
        with db.session() as c:
            case = _l87_case_row(c, cid)
            if not case:
                out["state"] = "missing"
                out["reasons"].append("项目不存在")
                return out
            runs = _l87_runs(c, cid)
            rec_rows = c.execute(
                "SELECT id,actor,object,action,after_json,request_id,created_at FROM audit_log "
                "WHERE action=? AND object=? ORDER BY rowid", (RECOVERY_ACTION, cid)).fetchall()
            reports = c.execute(
                "SELECT id,version,exported_at,signatures_json FROM report "
                "WHERE case_id=?", (cid,)).fetchall()
            # 失败纪元：有失败 run 标记时按 run/事件取；语义重审失败（L58 清理后无
            # run 标记）但 case=audit_failed 时也必须给出（回退 last_run_id 纪元），
            # 否则恢复事件无法幂等落库。正常 clean 案件不做事件扫描（性能）。
            if (any((r.get("marker") or {}).get("audit_failed") for r in runs)
                    or str(case.get("status") or "") == "audit_failed"):
                epoch = _l87_failure_epoch(c, cid, case, runs)
            else:
                epoch = {"epoch": "", "source": "", "failed_run_id": "", "event_id": ""}
    except Exception as exc:  # noqa: BLE001 - 读模型失败 → 不可签发（fail-closed）
        out["state"] = "unavailable"
        out["reasons"].append(f"审计状态读取失败：{type(exc).__name__}: {str(exc)[:160]}")
        out["blocking"] = True
        return out
    status = str(case.get("status") or "")
    last_run_id = str(case.get("last_run_id") or "")
    run_ids = [str(r.get("id") or "") for r in runs]
    latest = runs[-1] if runs else None
    cur_idx = -1
    dangling = False
    if last_run_id:
        if last_run_id in run_ids:
            cur_idx = run_ids.index(last_run_id)
        else:
            dangling = True
    elif runs:
        cur_idx = len(runs) - 1
    current = runs[cur_idx] if cur_idx >= 0 else None
    newer = runs[cur_idx + 1:] if cur_idx >= 0 else []
    failed_runs = [r for r in runs if (r.get("marker") or {}).get("audit_failed")]
    newer_failed = [r for r in newer if (r.get("marker") or {}).get("audit_failed")]
    current_failed = bool((current or {}).get("marker", {}).get("audit_failed"))
    latest_failed = bool((latest or {}).get("marker", {}).get("audit_failed"))
    out.update({
        "ok": True, "case_status": status, "last_run_id": last_run_id,
        "current_run_id": str((current or {}).get("id") or ""),
        "current_run_audit_failed": current_failed,
        "latest_run_id": str((latest or {}).get("id") or ""),
        "latest_run_audit_failed": latest_failed,
        "current_manifest_id": str((current or {}).get("manifest_id") or ""),
        "latest_manifest_id": str((latest or {}).get("manifest_id") or ""),
        "failed_run_ids": [str(r.get("id") or "") for r in failed_runs],
        "failure_epoch": epoch.get("epoch") or "",
        "failure_epoch_source": epoch.get("source") or "",
        "recovered_event_count": len(rec_rows),
        "last_recovery": (dict(rec_rows[-1]) if rec_rows else {}),
        "reports_issued": [dict(r) for r in reports],
        "run_count": len(runs),
    })
    reasons = out["reasons"]
    inconsistent = []
    out["dangling_last_run_id"] = bool(dangling)
    if dangling:
        # 只告警不阻断：last_run_id 悬空不是审计失败证据（历史案件/测试夹具可能存在），
        # 报告门禁的 F-08/无批次原因会按既有口径处理；对账可单独提示。
        reasons.append(f"last_run_id 指向不存在的 run（{last_run_id}；只告警不阻断）")
    if status == "audit_failed":
        out["state"] = "failed"
        reasons.append("case.status=audit_failed（失败持久标记）")
        if failed_runs:
            reasons.append(f"失败批次 {len(failed_runs)} 个（最早失败 run 标记可追溯）")
        elif not epoch.get("event_id"):
            inconsistent.append("case_failed_without_evidence")
            reasons.append("audit_failed 但无失败批次标记/失败事件（失败证据缺失）")
    elif current_failed:
        out["state"] = "inconsistent"
        inconsistent.append("current_run_audit_failed")
        reasons.append("当前 run 标记 manifest.executed 审计失败（last_run_id 指向失败批次）")
    elif newer_failed:
        out["state"] = "inconsistent"
        inconsistent.append("failed_run_after_current")
        reasons.append("存在晚于当前 run 的失败批次（case 状态未收敛）")
    elif status in ("auditing", "reviewing"):
        out["state"] = "running"
        reasons.append(f"case.status={status}（审核执行中，状态未收敛）")
    elif status in ("completed", "done", "confirmed"):
        out["state"] = "clean"
    else:
        out["state"] = "not_run"
        reasons.append(f"case.status={status or '空'}（未完成审核）")
    # 签发面：只有 clean 可签发；failed/inconsistent 一律阻断（fail-closed）
    out["blocking"] = out["state"] in ("failed", "inconsistent")
    out["signable"] = out["state"] == "clean" and not inconsistent
    out["inconsistent_reasons"] = inconsistent
    return out


def recovery_context(case_id: str) -> dict:
    """审计入口前的恢复上下文（必须在写 reviewing / 新 run 之前调用）。

    返回 ``was_failed``：本次审计是否处于「失败待恢复」态（failed/inconsistent）；
    供成功收口写唯一 ``audit.recovered`` 事件（幂等键 = failure_epoch）。
    """
    st = audit_state(case_id)
    return {"enabled": bool(st.get("enabled")), "case_id": str(case_id or ""),
            "available": bool(st.get("ok")),
            "state": str(st.get("state") or ""),
            "case_status": str(st.get("case_status") or ""),
            "last_run_id": str(st.get("last_run_id") or ""),
            "latest_run_id": str(st.get("latest_run_id") or ""),
            "failure_epoch": str(st.get("failure_epoch") or ""),
            "was_failed": bool(st.get("state") in ("failed", "inconsistent"))}


def audit_failure_evidence(case_id: str) -> dict:
    """只读对账证据：失败批次 / 失败事件 / 恢复事件（供 reconcile 与排障）。"""
    cid = str(case_id or "")
    out = {"case_id": cid, "failed_runs": [], "failure_events": [],
           "recovery_events": []}
    try:
        with db.session() as c:
            case = _l87_case_row(c, cid)
            runs = _l87_runs(c, cid)
            out["failed_runs"] = [
                {"id": r.get("id"), "created_at": r.get("created_at"),
                 "manifest_id": r.get("manifest_id")} for r in runs
                if (r.get("marker") or {}).get("audit_failed")]
            out["failure_events"] = _l87_failure_events(c, cid)
            out["recovery_events"] = [dict(r) for r in c.execute(
                "SELECT id,actor,object,after_json,request_id,created_at FROM audit_log "
                "WHERE action=? AND object=? ORDER BY rowid", (RECOVERY_ACTION, cid))]
            if case:
                out["failure_epoch"] = _l87_failure_epoch(c, cid, case, runs)
    except Exception as exc:  # noqa: BLE001
        out["error"] = f"{type(exc).__name__}: {str(exc)[:200]}"
    return out


def _l87_recovery_exists(c, case_id: str, request_id: str) -> dict:
    r = c.execute("SELECT id,created_at FROM audit_log WHERE action=? AND object=? "
                  "AND request_id=?", (RECOVERY_ACTION, case_id, request_id)).fetchone()
    return dict(r) if r else {}


def _l87_write_recovery_event(c, case_id: str, run_id: str, prior: dict, *,
                              actor: str = "", source: str = "",
                              manifest_id: str = "") -> dict:
    """在事务连接内写唯一 audit.recovered（单语句原子去重；不 commit）。"""
    epoch = str((prior or {}).get("failure_epoch") or "")
    if not epoch:
        return {"written": False, "event_id": "", "request_id": "",
                "epoch": "", "reason": "缺少失败纪元（failure_epoch 为空）"}
    request_id = f"audit-recovery:{case_id}:{epoch}"
    old = _l87_recovery_exists(c, case_id, request_id)
    if old:
        return {"written": False, "event_id": str(old.get("id") or ""),
                "request_id": request_id, "epoch": epoch, "reason": "已存在（幂等）"}
    case = _l87_case_row(c, case_id)
    detail = {"case_id": case_id,
              "from_status": str((prior or {}).get("case_status") or ""),
              "from_state": str((prior or {}).get("state") or ""),
              "from_run_id": str((prior or {}).get("last_run_id")
                                 or (prior or {}).get("latest_run_id") or ""),
              "to_run_id": str(run_id or ""),
              "manifest_id": str(manifest_id or ""),
              "failure_epoch": epoch,
              "recovered_at": db.now(),
              "source": str(source or ""),
              "switch": 1,
              "idempotency_key": request_id}
    before = json.dumps({"case_status": str((prior or {}).get("case_status") or ""),
                         "state": str((prior or {}).get("state") or ""),
                         "last_run_id": str((prior or {}).get("last_run_id") or "")},
                        ensure_ascii=False)
    after = json.dumps(detail, ensure_ascii=False)
    lid = db.new_id("log")
    cur = c.execute(
        "INSERT INTO audit_log(id,actor,action,object,before_json,after_json,request_id,"
        "ip,created_at,tenant_id,workspace_id) "
        "SELECT ?,?,?,?,?,?,?,?,?,?,? WHERE NOT EXISTS ("
        "SELECT 1 FROM audit_log WHERE action=? AND object=? AND request_id=?)",
        (lid, str(actor or "system"), RECOVERY_ACTION, case_id, before, after,
         request_id, "", db.now(), str(case.get("tenant_id") or ""),
         str(case.get("workspace_id") or ""),
         RECOVERY_ACTION, case_id, request_id))
    written = int(cur.rowcount or 0) > 0
    return {"written": bool(written), "event_id": lid if written else "",
            "request_id": request_id, "epoch": epoch, "detail": detail,
            "reason": "" if written else "并发/重复调用未新增（幂等）"}


def record_recovery(case_id: str, run_id: str, *, prior: dict | None = None,
                    actor: str = "", source: str = "",
                    manifest_id: str = "") -> dict:
    """成功收口唯一恢复写点：失败态 → completed 时写**恰好一条** audit.recovered。

    - 幂等：同 case+失败纪元重复调用/并发调用只落一条（request_id 原子去重）；
    - 未处于失败态（prior.was_failed=False）→ 不写事件（正常重复审核不是恢复）；
    - 写失败直接抛异常，由调用方 fail-closed（审计不可自证 → case=audit_failed）。
    """
    out = {"ok": True, "enabled": audit_state_consistency_enabled(),
           "recovered": False, "written": False, "event_id": "",
           "request_id": "", "epoch": "", "reason": ""}
    cid, rid = str(case_id or ""), str(run_id or "")
    if not out["enabled"]:
        out["reason"] = f"{AUDIT_STATE_ENV}=0（回退 L77 行为：不写恢复事件）"
        return out
    ctx = prior
    if ctx is None:
        ctx = recovery_context(cid)
    if not (ctx or {}).get("was_failed"):
        out["reason"] = "非失败态（正常审核/重复审核不写恢复事件）"
        return out
    if not rid:
        out["ok"] = False
        out["reason"] = "缺少成功 run_id，无法写恢复事件"
        return out
    with db.session() as c:
        res = _l87_write_recovery_event(c, cid, rid, ctx, actor=actor,
                                        source=source or "audit_ledger.record_recovery",
                                        manifest_id=manifest_id)
    out.update(recovered=True, written=bool(res.get("written")),
               event_id=str(res.get("event_id") or ""),
               request_id=str(res.get("request_id") or ""),
               epoch=str(res.get("epoch") or ""),
               reason=str(res.get("reason") or ""))
    return out


def mark_audit_failure(case_id: str, *, actor: str = "", reason: str = "",
                       run_id: str = "", source: str = "") -> dict:
    """失败写入点统一收口：case.status=audit_failed（durable 失败标记，幂等）。

    L87 开关=0 → 不动作（回退 L77 行为）。用于语义重审失败（其新 run 按 L58 契约
    被清理、无 run 可标记 → case 状态是唯一持久失败标记；report_gate 读同一事实源阻断）。
    """
    out = {"ok": True, "enabled": audit_state_consistency_enabled(),
           "marked": False, "case_status": "", "switch": AUDIT_STATE_ENV}
    cid = str(case_id or "")
    if not out["enabled"] or not cid:
        return out
    with db.session() as c:
        cur = c.execute(
            "UPDATE audit_case SET status='audit_failed', progress=0 "
            "WHERE id=? AND status<>'audit_failed'", (cid,))
        out["marked"] = int(cur.rowcount or 0) > 0
        row = c.execute("SELECT status FROM audit_case WHERE id=?", (cid,)).fetchone()
        out["case_status"] = str((row["status"] if row else "") or "")
    out["reason"] = str(reason or "")[:300]
    out["run_id"] = str(run_id or "")
    out["source"] = str(source or "")
    return out


def _l87_reconcile_event(c, case_id: str, repairs: list, actor: str) -> dict:
    """对账修复留痕（同一次修复只写一条；不删除/不改写任何审计行）。"""
    if not repairs:
        return {}
    key = "audit-reconcile:" + case_id + ":" + ",".join(
        sorted(str(x.get("code") or "") for x in repairs))
    old = c.execute("SELECT id FROM audit_log WHERE action='audit.state_reconciled' "
                    "AND object=? AND request_id=?", (case_id, key)).fetchone()
    if old:
        return {"written": False, "event_id": str(old["id"] or "")}
    lid = db.new_id("log")
    case = _l87_case_row(c, case_id)
    c.execute(
        "INSERT INTO audit_log(id,actor,action,object,before_json,after_json,request_id,ip,"
        "created_at,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (lid, str(actor or "system"), "audit.state_reconciled", case_id, "",
         json.dumps({"case_id": case_id, "repairs": repairs,
                     "at": db.now()}, ensure_ascii=False, default=str),
         key, "", db.now(), str(case.get("tenant_id") or ""),
         str(case.get("workspace_id") or "")))
    return {"written": True, "event_id": lid}


def reconcile_audit_state(case_id: str, *, repair: bool = False,
                          actor: str = "") -> dict:
    """审计状态对账（只读检测 + 可选幂等修复）。

    检测项：
      - ``case_completed_but_run_failed``：case 非 audit_failed 但存在当前/更新失败批次
        → 修复：case=audit_failed（fail-closed，失败证据优先）；
      - ``case_failed_without_evidence``：audit_failed 但无失败批次/失败事件（只告警）；
      - ``recovery_event_missing``：已恢复为 clean 但失败纪元没有 audit.recovered
        （成功收口写完 run trace 后崩溃）→ 修复：补写唯一恢复事件（幂等）；
      - ``report_issued_while_not_signable``：失败/矛盾态下已有签发报告（只告警，审计不可改）；
      - ``duplicate_recovery_event``：同幂等键重复恢复事件（只告警，理论不可达）。
    """
    cid = str(case_id or "")
    st = audit_state(cid)
    enabled = audit_state_consistency_enabled()
    disc, repairs = [], []
    state = str(st.get("state") or "")
    if state == "inconsistent":
        code = "case_completed_but_run_failed" if st.get("case_status") != "audit_failed" \
            else "case_failed_but_state_contradictory"
        disc.append({"code": code, "severity": "error", "repairable": bool(enabled),
                     "detail": "；".join(st.get("reasons") or [])[:400]})
    elif state == "failed":
        evidence = audit_failure_evidence(cid)
        if not (evidence.get("failed_runs") or evidence.get("failure_events")):
            disc.append({"code": "case_failed_without_evidence", "severity": "warning",
                         "repairable": False,
                         "detail": "case=audit_failed 但无失败批次/失败事件（可读但无法自动修复）"})
    if st.get("dangling_last_run_id"):
        disc.append({"code": "last_run_id_dangling", "severity": "warning",
                     "repairable": False,
                     "detail": f"last_run_id={st.get('last_run_id')} 指向不存在的 run"
                               "（只告警：非审计失败证据，报告门禁按既有口径处理）"})
    if st.get("state") in ("failed", "inconsistent") and st.get("reports_issued"):
        disc.append({"code": "report_issued_while_not_signable", "severity": "warning",
                     "repairable": False,
                     "detail": f"不可签发态下存在 {len(st['reports_issued'])} 份已签发报告"
                               "（历史不可改，后续签发已阻断）"})
    # 恢复事件缺失（成功收口 crash 半状态）：clean + 失败证据存在 + 无对应恢复事件
    if state == "clean":
        evidence = audit_failure_evidence(cid)
        epoch = str((evidence.get("failure_epoch") or {}).get("epoch") or "")
        has_failure = bool(evidence.get("failed_runs") or evidence.get("failure_events"))
        req = f"audit-recovery:{cid}:{epoch}" if epoch else ""
        if has_failure and req:
            try:
                with db.session() as c:
                    exists = _l87_recovery_exists(c, cid, req) if req else {}
            except Exception:  # noqa: BLE001
                exists = {}
            if not exists:
                disc.append({"code": "recovery_event_missing", "severity": "error",
                             "repairable": bool(enabled),
                             "detail": f"失败纪元 {epoch} 已恢复（state=clean）但缺少唯一"
                                       " audit.recovered 事件（成功收口崩溃窗口）"})
    # 重复恢复事件（同幂等键）：理论不可达；只告警，审计日志不可删改
    try:
        with db.session() as c:
            dup = c.execute(
                "SELECT request_id, COUNT(*) AS n FROM audit_log WHERE action=? AND object=? "
                "AND COALESCE(request_id,'')<>'' GROUP BY request_id HAVING n>1",
                (RECOVERY_ACTION, cid)).fetchall()
        if dup:
            disc.append({"code": "duplicate_recovery_event", "severity": "warning",
                         "repairable": False,
                         "detail": "重复恢复事件：" + ",".join(str(x["request_id"]) for x in dup)})
    except Exception:  # noqa: BLE001 - 对账辅助查询失败不改变主判定（留痕）
        _LOG.warning("L87 duplicate recovery event scan skipped case=%s", cid,
                     exc_info=True)
    # 修复（仅开关开、显式 repair=True）：失败证据优先 → case=audit_failed；缺恢复事件 → 补写
    if repair and enabled:
        for d in list(disc):
            if not d.get("repairable"):
                continue
            if d["code"] in ("case_completed_but_run_failed",
                             "case_failed_but_state_contradictory"):
                res = mark_audit_failure(cid, actor=actor or "audit_ledger.reconcile",
                                         reason=d["detail"],
                                         run_id=str(st.get("latest_run_id") or ""),
                                         source="audit_ledger.reconcile")
                if res.get("marked") or res.get("case_status") == "audit_failed":
                    repairs.append({"code": "case_marked_audit_failed",
                                     "detail": d["code"]})
                    d["repaired"] = True
            elif d["code"] == "recovery_event_missing":
                evidence = audit_failure_evidence(cid)
                epoch = str((evidence.get("failure_epoch") or {}).get("epoch") or "")
                prior = {"was_failed": True, "state": "failed",
                         "case_status": "audit_failed",
                         "last_run_id": str(st.get("last_run_id") or ""),
                         "latest_run_id": str(st.get("latest_run_id") or ""),
                         "failure_epoch": epoch}
                try:
                    res = record_recovery(cid, str(st.get("current_run_id") or ""),
                                          prior=prior,
                                          actor=actor or "audit_ledger.reconcile",
                                          source="audit_ledger.reconcile.crash_repair",
                                          manifest_id=str(st.get("current_manifest_id") or ""))
                    if res.get("written"):
                        repairs.append({"code": "recovery_event_written",
                                        "event_id": res.get("event_id"),
                                        "request_id": res.get("request_id")})
                        d["repaired"] = True
                except Exception as exc:  # noqa: BLE001 - 修复失败如实回报
                    repairs.append({"code": "recovery_event_write_failed",
                                    "error": f"{type(exc).__name__}: {str(exc)[:160]}"})
    if repairs:
        try:
            with db.session() as c:
                _l87_reconcile_event(c, cid, repairs, actor or "audit_ledger.reconcile")
        except Exception:  # noqa: BLE001 - 留痕失败不改变修复结果（必须留日志）
            _LOG.warning("L87 reconcile event write skipped case=%s", cid, exc_info=True)
    st_after = audit_state(cid) if repairs else st
    remaining = [d for d in disc if not d.get("repaired")]
    ok = not [d for d in remaining if d.get("severity") == "error"]
    return {"ok": ok, "enabled": enabled, "case_id": cid,
            "state_before": state, "state_after": str(st_after.get("state") or ""),
            "signable_after": bool(st_after.get("signable")),
            "discrepancies": disc, "repairs": repairs,
            "remaining": remaining, "switch": AUDIT_STATE_ENV}


def recovery_events(case_id: str) -> list:
    """案件全部 audit.recovered 事件（测试/运维只读）。"""
    with db.session() as c:
        return [dict(r) for r in c.execute(
            "SELECT id,actor,object,after_json,request_id,created_at FROM audit_log "
            "WHERE action=? AND object=? ORDER BY rowid", (RECOVERY_ACTION, str(case_id or "")))]
