"""历史重复问题检测（版本/批次对比的轻量版，只读）。

产品背景（领域 A「不漏」）：同一规则命中同一对象（同一份文件内容）在多个项目/
批次反复出现，是「历史重复问题」。复核/报告应能回答：
「这条问题在哪些历史项目里出现过？」「本项目重复问题占比多少？」

本模块是**轻量版**：不做版本 diff、不调模型、不建表，只基于现有
``finding`` / ``evidence`` / ``document`` / ``audit_case`` 表做只读查询：
- 对象口径 = 文档内容 sha256（``document.hash``）优先；同时兼容 document_id /
  filename 精确匹配，便于历史数据没有 hash 的场景；
- 命中口径 = 同一规则编码 + 同一对象 + 状态属于 fail 家族（默认只看 fail，
  不把 pass/na 当历史问题）；
- 隔离口径 = 两函数都支持 tenant/workspace 过滤；``repeat_stats`` 用当前 case
  的租户/空间做历史过滤（不给外租户历史，避免跨租户泄露）；
- 找不到对象归属（finding 没有 evidence/document）的按「无法判断」计入
  ``no_object``，不计入重复也不伪造 first_time 依据。

Phase 2 接线：复核抽屉/报告的问题明细调用 ``same_rule_history`` 展示历史项目；
项目详情/报告摘要调用 ``repeat_stats`` 展示重复占比。本模块自身只读。
"""
from __future__ import annotations

import json
import logging

log = logging.getLogger(__name__)

import sqlite3  # noqa: E402  （显式声明只读查询的异常类型）

# finding 五态 + 旧中文展示态的 fail 家族
FAIL_STATES = ("fail", "不满足", "confirmed", "违规")
_STATE_ALIASES = {
    "满足": "pass", "不满足": "fail", "证据不足": "insufficient",
    "弃权(需人工)": "insufficient", "需人工": "insufficient",
    "不适用": "na", "未知": "unknown", "执行失败": "unknown",
}
_HISTORY_COLUMNS = {}


def normalize_state(value) -> str:
    """finding 状态归一（与 project._FINDING_STATE_MAP 同口径，供本模块只读判断）。"""
    s = str(value or "").strip()
    return _STATE_ALIASES.get(s, s.lower())


def _is_fail(state) -> bool:
    s = normalize_state(state)
    return s in FAIL_STATES or str(state or "").strip() in FAIL_STATES


def _cols(conn, table: str) -> set:
    if table not in _HISTORY_COLUMNS:
        try:
            _HISTORY_COLUMNS[table] = {r[1] for r in conn.execute(
                f"PRAGMA table_info({table})").fetchall()}
        except sqlite3.Error:
            _HISTORY_COLUMNS[table] = set()
    return _HISTORY_COLUMNS[table]


def _connect():
    from .. import db
    return db.connect()


def _doc_ids_for_key(conn, object_key: str, tenant_id: str = "",
                     workspace_id: str = "") -> list:
    """object_key（内容 hash / document_id / 文件名）→ 匹配的 document_id 列表。"""
    key = str(object_key or "").strip()
    if not key:
        return []
    dcols = _cols(conn, "document")
    where = ["(hash=? OR id=? OR filename=?)"]
    params = [key, key, key]
    if tenant_id and "tenant_id" in dcols:
        where.append("tenant_id=?")
        params.append(tenant_id)
    if workspace_id and "workspace_id" in dcols:
        where.append("workspace_id=?")
        params.append(workspace_id)
    try:
        rows = conn.execute(
            f"SELECT id FROM document WHERE {' AND '.join(where)}", tuple(params)).fetchall()
    except sqlite3.Error:
        log.warning("repeat_issue: document lookup failed key=%s", key, exc_info=True)
        return []
    return [str(r[0]) for r in rows]


def _norm_states(states) -> tuple:
    if states is None:
        return FAIL_STATES
    if isinstance(states, str):
        states = [states]
    out = []
    for st in states or []:
        s = str(st or "").strip()
        if s and s not in out:
            out.append(s)
    # 保证中文/英文 fail 家族都覆盖
    for s in FAIL_STATES:
        if s not in out:
            out.append(s)
    return tuple(out)


def same_rule_history(rule_code: str, object_key: str, tenant_id: str = "",
                      workspace_id: str = "", exclude_case_id: str = "",
                      limit: int = 200) -> list:
    """同一规则 + 同一对象的历史命中（跨 case，只读）。

    参数：
        rule_code: 规则编码（finding.rule_id 在平台里存规则编码；兼容 rule.id）。
        object_key: 对象标识：文档内容 sha256（推荐）/ document_id / 文件名。
        tenant_id / workspace_id: 可选隔离过滤（Phase 2 从 ctx 取，显式传入）。
        exclude_case_id: 排除当前项目（查「其他项目」历史）。

    返回列表（按项目创建时间倒序）：
        [{finding_id, case_id, case_name, case_created_at, rule_code, state,
          document_id, document_hash, filename, tenant_id, workspace_id}]
        同一 finding × 同一文档去重；对象不存在/无历史返回 []。
    """
    code = str(rule_code or "").strip()
    key = str(object_key or "").strip()
    if not code or not key:
        return []
    conn = _connect()
    try:
        doc_ids = _doc_ids_for_key(conn, key, tenant_id, workspace_id)
        if not doc_ids:
            return []
        fcols = _cols(conn, "finding")
        states = _norm_states(None)
        ph = ",".join("?" * len(states))
        dph = ",".join("?" * len(doc_ids))
        where = [f"(f.rule_id=? OR r.code=?)", f"f.state IN ({ph})",
                 f"e.document_id IN ({dph})"]
        params = [code, code, *states, *doc_ids]
        if exclude_case_id:
            where.append("f.case_id<>?")
            params.append(str(exclude_case_id))
        if tenant_id and "tenant_id" in fcols:
            where.append("f.tenant_id=?")
            params.append(str(tenant_id))
        if workspace_id and "workspace_id" in fcols:
            where.append("f.workspace_id=?")
            params.append(str(workspace_id))
        if limit and int(limit) > 0:
            params.append(int(limit))
            tail = " LIMIT ?"
        else:
            tail = ""
        sql = ("SELECT f.id AS finding_id, f.case_id AS case_id, f.state AS state, "
               "COALESCE(r.code, f.rule_id) AS rule_code, "
               "f.title AS title, e.document_id AS document_id, "
               "d.hash AS document_hash, d.filename AS filename, "
               "ac.name AS case_name, ac.created_at AS case_created_at "
               "FROM finding f "
               "LEFT JOIN rule r ON r.id=f.rule_id "
               "JOIN audit_case ac ON ac.id=f.case_id "
               "JOIN evidence e ON e.finding_id=f.id "
               "JOIN document d ON d.id=e.document_id "
               f"WHERE {' AND '.join(where)} "
               "ORDER BY ac.created_at DESC, f.id" + tail)
        try:
            rows = conn.execute(sql, tuple(params)).fetchall()
        except sqlite3.Error:
            log.warning("repeat_issue: history query failed code=%s", code, exc_info=True)
            return []
        out, seen = [], set()
        for row in rows:
            row = dict(row)
            dedupe = (row.get("finding_id"), row.get("document_id"))
            if dedupe in seen:
                continue
            seen.add(dedupe)
            out.append(row)
        return out
    finally:
        conn.close()


def _case_scope(case_id: str) -> dict:
    """case 行 → {tenant_id, workspace_id, last_run_id}（无隔离列时为空）。"""
    empty = {"tenant_id": "", "workspace_id": "", "last_run_id": ""}
    conn = _connect()
    try:
        ccols = _cols(conn, "audit_case")
        if not ccols:
            return empty
        want = [c for c in ("tenant_id", "workspace_id", "last_run_id") if c in ccols]
        if not want:
            return empty
        row = conn.execute(
            f"SELECT {', '.join(want)} FROM audit_case WHERE id=?", (case_id,)).fetchone()
        if not row:
            return empty
        got = dict(row)
        return {"tenant_id": str(got.get("tenant_id") or ""),
                "workspace_id": str(got.get("workspace_id") or ""),
                "last_run_id": str(got.get("last_run_id") or "")}
    except sqlite3.Error:
        log.warning("repeat_issue: case scope lookup failed case=%s", case_id, exc_info=True)
        return empty
    finally:
        conn.close()


def _case_findings(conn, case_id: str, last_run_id: str = "") -> list:
    """当前 case 的 finding（全态；只取最近一次审核批次，与项目详情同口径）。"""
    where = "f.case_id=?"
    params = [case_id]
    fcols = _cols(conn, "finding")
    if last_run_id and "run_id" in fcols:
        where += " AND f.run_id=?"
        params.append(last_run_id)
    try:
        rows = conn.execute(
            "SELECT f.id, f.case_id, f.rule_id, f.state, f.title, "
            "COALESCE(r.code, f.rule_id) AS rule_code "
            "FROM finding f LEFT JOIN rule r ON r.id=f.rule_id "
            f"WHERE {where}", tuple(params)).fetchall()
    except sqlite3.Error:
        log.warning("repeat_issue: case findings failed case=%s", case_id, exc_info=True)
        return []
    return [dict(r) for r in rows]


def _finding_docs(conn, finding_ids) -> dict:
    """finding_id → [{document_id, document_hash, filename}]（只读 evidence 关联）。"""
    ids = [str(x) for x in (finding_ids or []) if str(x)]
    if not ids:
        return {}
    ph = ",".join("?" * len(ids))
    try:
        rows = conn.execute(
            f"SELECT e.finding_id AS finding_id, e.document_id AS document_id, "
            f"d.hash AS document_hash, d.filename AS filename "
            f"FROM evidence e LEFT JOIN document d ON d.id=e.document_id "
            f"WHERE e.finding_id IN ({ph})", tuple(ids)).fetchall()
    except sqlite3.Error:
        log.warning("repeat_issue: finding docs failed", exc_info=True)
        return {}
    out = {}
    for row in rows:
        row = dict(row)
        out.setdefault(row["finding_id"], []).append(
            {k: row.get(k) for k in ("document_id", "document_hash", "filename")})
    return out


def _history_index(conn, rule_codes, tenant_id="", workspace_id="",
                   exclude_case_id="") -> dict:
    """一次性取历史 fail finding 的对象索引：{code: {key: [case_id,...]}}。"""
    codes = [str(c) for c in (rule_codes or []) if str(c)]
    if not codes:
        return {}
    fcols = _cols(conn, "finding")
    states = _norm_states(None)
    cph = ",".join("?" * len(codes))
    sph = ",".join("?" * len(states))
    where = [f"(f.rule_id IN ({cph}) OR r.code IN ({cph}))", f"f.state IN ({sph})"]
    params = [*codes, *codes, *states]
    if exclude_case_id:
        where.append("f.case_id<>?")
        params.append(str(exclude_case_id))
    if tenant_id and "tenant_id" in fcols:
        where.append("f.tenant_id=?")
        params.append(str(tenant_id))
    if workspace_id and "workspace_id" in fcols:
        where.append("f.workspace_id=?")
        params.append(str(workspace_id))
    sql = ("SELECT COALESCE(r.code, f.rule_id) AS rule_code, f.case_id AS case_id, "
           "d.hash AS document_hash, d.id AS document_id, d.filename AS filename "
           "FROM finding f LEFT JOIN rule r ON r.id=f.rule_id "
           "JOIN evidence e ON e.finding_id=f.id "
           "JOIN document d ON d.id=e.document_id "
           f"WHERE {' AND '.join(where)}")
    try:
        rows = conn.execute(sql, tuple(params)).fetchall()
    except sqlite3.Error:
        log.warning("repeat_issue: history index failed", exc_info=True)
        return {}
    index = {}
    for row in rows:
        row = dict(row)
        code = str(row.get("rule_code") or "")
        entry = index.setdefault(code, {})
        for key in (row.get("document_hash"), row.get("document_id"),
                    row.get("filename")):
            if not key:
                continue
            cases = entry.setdefault(str(key), [])
            if row.get("case_id") not in cases:
                cases.append(row.get("case_id"))
    return index


def repeat_stats(case_id: str) -> dict:
    """本项目重复问题统计（与历史项目对比）。

    返回：
        {case_id, total_findings, fail_total, repeat_total, first_time,
         by_rule: {code: {total, repeat, first_time}}, no_object,
         history_case_ids, basis}
    - 只统计 fail 家族（不把 pass/na 当问题）；
    - 对象 = 文档 hash / document_id / filename 任一命中；
    - finding 无文档归属 → ``no_object``（既不算重复也不算首次，如实告知）；
    - 历史过滤当前 case 的租户/空间，避免跨租户泄露。
    """
    cid = str(case_id or "").strip()
    out = {"case_id": cid, "total_findings": 0, "fail_total": 0,
           "repeat_total": 0, "first_time": 0, "no_object": 0,
           "by_rule": {}, "history_case_ids": [], "basis": ""}
    if not cid:
        out["basis"] = "empty_case_id：未提供项目 id"
        return out
    scope = _case_scope(cid)
    conn = _connect()
    try:
        findings = _case_findings(conn, cid, scope.get("last_run_id") or "")
        out["total_findings"] = len(findings)
        fails = [f for f in findings if _is_fail(f.get("state"))]
        out["fail_total"] = len(fails)
        if not fails:
            out["basis"] = ("no_fail_findings：本项目当前没有不满足类问题"
                            if findings else "no_findings：本项目尚无可统计的 finding")
            return out
        docs = _finding_docs(conn, [f["id"] for f in fails])
        codes = sorted({str(f.get("rule_code") or f.get("rule_id") or "")
                        for f in fails if str(f.get("rule_code") or f.get("rule_id") or "")})
        index = _history_index(conn, codes, scope["tenant_id"],
                               scope["workspace_id"], exclude_case_id=cid)
        history_cases = []
        by_rule = {}
        repeat_total = 0
        no_object = 0
        for f in fails:
            code = str(f.get("rule_code") or f.get("rule_id") or "")
            bucket = by_rule.setdefault(code, {"total": 0, "repeat": 0, "first_time": 0})
            bucket["total"] += 1
            keys = set()
            for doc in docs.get(f["id"], []):
                for key in (doc.get("document_hash"), doc.get("document_id"),
                            doc.get("filename")):
                    if key:
                        keys.add(str(key))
            if not keys:
                no_object += 1
                bucket["first_time"] += 1
                continue
            hit_cases = set()
            for key in keys:
                for case_id_hit in (index.get(code) or {}).get(key, []):
                    if case_id_hit and case_id_hit != cid:
                        hit_cases.add(case_id_hit)
            if hit_cases:
                repeat_total += 1
                bucket["repeat"] += 1
                for case_id_hit in hit_cases:
                    if case_id_hit not in history_cases:
                        history_cases.append(case_id_hit)
            else:
                bucket["first_time"] += 1
        out.update({"repeat_total": repeat_total,
                    "first_time": len(fails) - repeat_total - no_object,
                    "no_object": no_object,
                    "history_case_ids": sorted(history_cases),
                    "by_rule": dict(sorted(by_rule.items())),
                    "basis": ("fail 家族 finding × 同规则编码 × 同对象（文档 hash/"
                              "document_id/filename）；历史跨 case、按本 case 租户/空间隔离")})
        return out
    finally:
        conn.close()
