"""系统配置（key-value，优先于环境变量）+ 数据边界策略（P1-8）。

两层职责：

1. 基础 KV：``get`` / ``set_many``（原有能力，保持行为不变，auth/manifest 等在用）。
2. 数据边界策略（数据出境 / 留存 / 删除）：``get_data_policy`` / ``set_data_policy`` /
   ``data_policy_status`` / ``data_inventory`` / ``purge_preview`` /
   ``create_purge_preview`` / ``purge_execute``。

设计口径（交付诚实性）：
- DB 的 ``data.policy.*`` 优先于环境变量默认值；两者都空 = **未配置**，必须显式提示，
  不得静默套用“看似合理”的默认值；
- 删除执行走 **预览（签发一次性预览凭证）→ 二次确认（confirm=确认删除）→ 审计 → 执行**
  的流程；默认 dry-run（不传 dry_run=false 不会删除任何行）；没有预览凭证不得 DELETE；
- 删除**只按会话账号所属租户执行**（跨租户 403），审计日志（只读合规）与无租户列的
  llm_cache 显式排除在执行范围之外，并在预览/状态里写明原因；
- 状态/清单/预览都是只读计算，不编造数据：表不存在或未初始化时返回 ``None`` 并附说明。
"""
import json
import logging
import os
import time
from datetime import datetime, timedelta

from .. import config, db

# ================================================================ 基础 KV


def get(key: str, default: str = "") -> str:
    try:
        with db.session() as c:
            r = c.execute("SELECT value FROM sys_config WHERE key=?", (key,)).fetchone()
        return r["value"] if r and r["value"] is not None else default
    except Exception:
        return default


def set_many(kv: dict) -> None:
    with db.session() as c:
        for k, v in kv.items():
            c.execute("INSERT INTO sys_config(key,value,updated_at) VALUES(?,?,?) "
                      "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                      (k, v, db.now()))


def delete_keys(keys) -> int:
    keys = [str(k) for k in (keys or []) if str(k)]
    if not keys:
        return 0
    with db.session() as c:
        cur = c.execute("DELETE FROM sys_config WHERE key IN (%s)" % ",".join("?" * len(keys)),
                        tuple(keys))
    return int(cur.rowcount or 0)


# ================================================================ 数据边界策略
POLICY_PREFIX = "data.policy."
POLICY_META_KEY = "data.policy_meta"

# 字段定义是唯一事实源：校验、状态、文档、页面（待接线）共用。
# required=True 表示「必须显式配置」；未配置时状态里给出显式 warning。
POLICY_FIELDS = (
    {"key": "region", "label": "数据处理/存储所在区域", "type": "str", "required": True,
     "hint": "如 cn、cn-shanghai、客户机房；用于判断数据是否出境"},
    {"key": "external_model", "label": "是否允许文件全文发送外部模型 API",
     "type": "enum", "choices": ("allow", "deny"), "required": True,
     "hint": "allow=允许（需合同/隐私条款确认）；deny=禁止，应部署私有化模型"},
    {"key": "retention_cases_days", "label": "审核项目与上传原文件保留天数",
     "type": "int", "min": 0, "required": True, "hint": "0 表示不自动删除（需合同明确）"},
    {"key": "retention_logs_days", "label": "审计日志保留天数",
     "type": "int", "min": 0, "required": True},
    {"key": "retention_cache_days", "label": "模型判定缓存（llm_cache）保留天数",
     "type": "int", "min": 0, "required": True},
    {"key": "retention_reports_days", "label": "审核报告保留天数",
     "type": "int", "min": 0, "required": True},
    {"key": "deletion_request_window_days", "label": "删除/导出申请响应时限（天）",
     "type": "int", "min": 1, "required": False},
    {"key": "deletion_contact", "label": "数据删除/导出申请联系人",
     "type": "str", "required": False},
    {"key": "disclosure_ack", "label": "客户已书面确认数据外发与留存口径",
     "type": "bool", "required": True,
     "hint": "true=已完成书面确认；未确认不得按“已披露”交付"},
    {"key": "note", "label": "交付口径补充说明（合同条款编号等）",
     "type": "str", "required": False},
)
_FIELD_BY_KEY = {f["key"]: f for f in POLICY_FIELDS}


def _env_value(field: dict):
    """环境变量默认值（部署方 .env）；空串视为未配置。"""
    try:
        if field["key"] == "region":
            return config.DATA_REGION
        if field["key"] == "external_model":
            return config.DATA_EXTERNAL_MODEL
        if field["key"] == "deletion_contact":
            return config.DATA_DELETION_CONTACT
        if field["key"] == "note":
            return config.DATA_POLICY_NOTE
        if field["key"].startswith("retention_") and field["key"].endswith("_days"):
            short = field["key"][len("retention_"):-len("_days")] + "_days"
            return (getattr(config, "RETENTION", {}) or {}).get(short, "")
    except Exception:
        return ""
    return ""


def _coerce(field: dict, value):
    """按字段定义归一/校验；非法值抛 ValueError（调用方不得静默写入）。"""
    typ = field.get("type")
    if typ == "str":
        s = str(value if value is not None else "").strip()
        return s or None
    if typ == "int":
        if value is None or str(value).strip() == "":
            return None
        try:
            n = int(str(value).strip())
        except Exception:
            raise ValueError(f"{field['label']}必须是整数：{value!r}")
        if n < int(field.get("min", 0)):
            raise ValueError(f"{field['label']}不能小于{field.get('min', 0)}：{n}")
        return n
    if typ == "enum":
        s = str(value if value is not None else "").strip().lower()
        if not s:
            return None
        if s not in tuple(field.get("choices") or ()):
            raise ValueError(f"{field['label']}只能是 {'/'.join(field.get('choices') or ())}：{value!r}")
        return s
    if typ == "bool":
        if isinstance(value, bool):
            return value
        s = str(value if value is not None else "").strip().lower()
        if not s:
            return None
        if s in ("1", "true", "yes", "on"):
            return True
        if s in ("0", "false", "no", "off"):
            return False
        raise ValueError(f"{field['label']}必须是布尔值（true/false）：{value!r}")
    return value


def _raw(value) -> str:
    """写入 sys_config 的字符串形态。"""
    if isinstance(value, bool):
        return "1" if value else "0"
    return "" if value is None else str(value)


def _load_policy_rows() -> tuple:
    """返回 ({field_key: raw_value}, meta)。表不存在/未初始化时返回空。"""
    out = {}
    try:
        with db.session() as c:
            prefix = POLICY_PREFIX + "%"
            for r in c.execute("SELECT key,value FROM sys_config WHERE key LIKE ?", (prefix,)).fetchall():
                out[str(r["key"])[len(POLICY_PREFIX):]] = r["value"]
    except Exception:
        return {}, {}
    meta = {}
    try:
        raw = get(POLICY_META_KEY, "")
        meta = json.loads(raw) if raw else {}
    except Exception:
        meta = {}
    return out, meta


def get_data_policy() -> dict:
    """当前生效的数据边界策略（DB 优先，环境变量兜底，两者皆空=未配置）。"""
    rows, meta = _load_policy_rows()
    values, field_meta, missing, warnings = {}, {}, [], []
    source_count = {"db": 0, "env": 0, "unset": 0}
    for f in POLICY_FIELDS:
        key = f["key"]
        dbv = rows.get(key)
        if dbv is not None and str(dbv).strip() != "":
            try:
                value = _coerce(f, dbv)
            except ValueError:
                value = None
                warnings.append(f"数据库中的「{f['label']}」取值非法：{dbv!r}（需重新配置）")
            source = "db"
        else:
            envv = _env_value(f)
            try:
                value = _coerce(f, envv)
            except ValueError:
                value = None
                warnings.append(f"环境变量中的「{f['label']}」取值非法：{envv!r}")
                source = "env_invalid"
            else:
                source = "env" if value is not None else "unset"
        if source in source_count:
            source_count[source] += 1
        values[key] = value
        field_meta[key] = {"label": f["label"], "type": f["type"], "source": source,
                           "required": bool(f.get("required")),
                           "hint": f.get("hint", "")}
        if f.get("required") and value is None:
            missing.append(key)
            warnings.append(f"「{f['label']}」未配置（{POLICY_PREFIX}{key} 或对应环境变量）")
    configured = not missing
    if configured:
        top = "db" if source_count["db"] else "env"
    elif source_count["db"] or source_count["env"]:
        top = "partial"
    else:
        top = "unset"
    # 外发与留存交叉提示（不改变值，只提示风险）
    if values.get("external_model") == "allow":
        warnings.append("已声明允许外发：送审文件全文会发送到当前配置的外部模型 API，"
                        "需确保合同/隐私条款与客户书面确认（disclosure_ack）一致")
    elif values.get("external_model") == "deny":
        enabled = False
        try:
            from ..engine import llm_router
            enabled = bool((llm_router.resolve() or {}).get("enabled"))
        except Exception:
            enabled = False
        if enabled:
            warnings.append("策略声明禁止外发，但当前默认模型已启用（可能把全文发送到外部 API）："
                            "请改为私有化/本地模型或关闭模型")
    return {"configured": configured, "source": top, "values": values,
            "meta": field_meta, "missing_required": missing,
            "warnings": warnings,
            "updated_at": str(meta.get("updated_at") or ""),
            "updated_by": str(meta.get("updated_by") or "")}


def set_data_policy(fields: dict, actor: str = "") -> dict:
    """显式配置数据边界策略（部分更新）。非法键/值抛 ValueError，不做半写。"""
    fields = dict(fields or {})
    unknown = [k for k in fields if k not in _FIELD_BY_KEY]
    if unknown:
        raise ValueError("未知数据策略字段：" + "、".join(sorted(unknown)))
    normalized = {}
    for k, v in fields.items():
        normalized[k] = _coerce(_FIELD_BY_KEY[k], v)
    before = get_data_policy()["values"]
    changed = {k: normalized[k] for k in normalized
               if before.get(k) != normalized[k]}
    if not changed:
        return {"ok": True, "changed": {}, "policy": get_data_policy()}
    kv = {POLICY_PREFIX + k: _raw(v) for k, v in changed.items()}
    kv[POLICY_META_KEY] = json.dumps(
        {"updated_at": db.now(), "updated_by": actor or "system"}, ensure_ascii=False)
    set_many(kv)
    try:
        from .. import repositories as R
        R.audit_logs.log(actor=actor or "system", action="data.policy.updated", object="",
                         before=json.dumps({k: before.get(k) for k in changed}, ensure_ascii=False),
                         after=json.dumps({k: normalized[k] for k in changed}, ensure_ascii=False))
    except Exception:
        # 审计写入失败不能掩盖策略已保存；由调用方状态接口暴露 updated_at 供核对
        import logging
        logging.getLogger(__name__).warning("data.policy.updated 审计写入失败", exc_info=True)
    return {"ok": True, "changed": {k: normalized[k] for k in changed}, "policy": get_data_policy()}


# ---------------------------------------------------------------- 留存执行现状（只读盘点）
def retention_enforcement() -> dict:
    """已有留存/清理机制的真实状态。只读，不触发清理。

    只描述代码里已存在、可被调用的清理入口；没有清理入口的类别明确标“未实现”，
    不得把“建议方案”写成“已实现”。
    """
    def _env_float(name, default):
        try:
            return float(os.environ.get(name) or default)
        except Exception:
            return default

    return {
        "task_result": {
            "status": "已实现",
            "mechanism": "app/services/task.py:cleanup_results（终态任务大结果/过期结果清理）",
            "retention_days": _env_float("RULEPROOF_TASK_RESULT_RETENTION_DAYS", 7.0),
            "keep_last": int(_env_float("RULEPROOF_TASK_RESULT_KEEP_LAST", 20)),
            "max_bytes": int(_env_float("RULEPROOF_TASK_RESULT_MAX_BYTES", 5 * 1024 * 1024)),
        },
        "open_sandbox": {
            "status": "已实现",
            "mechanism": "app/services/open.py:cleanup_sandbox（签名沙箱记录按天/行数清理）",
            "retention_days": _env_float("RULEPROOF_SANDBOX_RETENTION_DAYS", 7.0),
            "max_rows": int(_env_float("RULEPROOF_SANDBOX_MAX_ROWS", 1000)),
        },
        "llm_cache": {"status": "未实现（自动）",
                      "mechanism": "llm_cache 表只增不删且无租户列；按 retention_cache_days 的自动清理需运维任务，"
                                   "按租户手动删除会跨租户，本接口不执行"},
        "audit_log": {"status": "不可删除",
                      "mechanism": "审计日志只读、不可编辑、不可删除（合规要求）；删除执行接口显式排除，"
                                   "按 retention_logs_days 的归档需部署方运维流程"},
        "cases_documents": {"status": "未实现（自动）",
                            "mechanism": "无定时自动清理任务；已提供按策略的删除执行接口（预览凭证+二次确认+审计，"
                                         "默认 dry-run，见 deletion/scripts/qa）"},
        "reports": {"status": "未实现（自动）",
                    "mechanism": "无定时自动清理任务；已提供按策略的删除执行接口（同上）"},
        "backup": {"status": "依赖部署方",
                   "mechanism": "app/services/db_backup.py 提供在线备份；备份文件保留/加密/销毁由部署方流程负责"},
    }


def data_policy_status() -> dict:
    """交付/管理端可读的数据边界总状态：策略 + 外发 + 留存 + 删除 + 接入面。"""
    policy = get_data_policy()
    try:
        from ..engine import llm_router
        llm = llm_router.status()
    except Exception:
        llm = {"source": "NONE", "model": "", "enabled": False, "base_url": ""}
    warnings = list(policy["warnings"])
    enforcement = retention_enforcement()
    unimplemented = [k for k, v in enforcement.items()
                     if str(v.get("status") or "").startswith("未实现")]
    if unimplemented:
        warnings.append("以下数据类别没有定时自动留存/清理任务，需运维流程兜底（手动删除执行接口见 deletion）："
                        + "、".join(unimplemented))
    if not policy["configured"]:
        warnings.append("数据边界策略未配置完整：对外交付前必须显式配置并通过客户书面确认，"
                        "不得按“已披露”交付")
    return {
        "configured": bool(policy["configured"]),
        "policy": policy,
        "external_model": {
            "enabled": bool(llm.get("enabled")),
            "source": llm.get("source") or "",
            "model": llm.get("model") or "",
            "base_url": llm.get("base_url") or "",
            "policy": policy["values"].get("external_model"),
            "conflict": bool(llm.get("enabled")) and policy["values"].get("external_model") == "deny",
        },
        "retention": enforcement,
        "deletion": {
            "preview_supported": True,
            "executed_supported": True,
            "dry_run_default": True,
            "requires_preview_token": True,
            "requires_confirm": PURGE_CONFIRM_TEXT,
            "preview_token_ttl_seconds": PURGE_PREVIEW_TTL,
            "executable_categories": list(PURGE_EXECUTABLE),
            "excluded_categories": dict(PURGE_EXCLUDED_REASONS),
            "tenant_scoped": True,
            "cross_tenant": "拒绝：目标租户必须等于会话账号所属租户，显式传其他租户返回 403",
            "roles": {"read": list(DATA_POLICY_READ_ROLES),
                      "preview": list(DATA_POLICY_READ_ROLES),
                      "dry_run": list(DATA_POLICY_READ_ROLES),
                      "execute": list(DATA_POLICY_EXECUTE_ROLES)},
            "role_policy": "仅系统管理员；业务管理员/审核员/平台运营无数据边界入口（403）",
            "audit_events": list(PURGE_AUDIT_EVENTS),
            "note": "删除执行 = 预览签发凭证 → confirm=确认删除 → 审计 → 按策略 cutoff 级联删除；"
                    "默认 dry-run 0 删除；审计日志与 llm_cache 不删除（原因见 excluded_categories）",
        },
        "api": {
            "service": "app.services.sysconfig.data_policy_status / get_data_policy / set_data_policy / "
                       "create_purge_preview / purge_execute",
            "http": "已接线：GET/PUT /api/v1/data-policy；POST /api/v1/data-policy/purge/preview|execute；"
                    "DELETE /api/v1/data-policy/purge（必须带预览凭证）",
            "cli": "已接线：rp data-policy status|get|set|purge-preview|purge-execute",
            "page": DATA_POLICY_PAGE_DESC,
        },
        "warnings": warnings,
    }


# ---------------------------------------------------------------- 数据清单 / 删除预览（只读）
def _count(table: str, where: str = "1=1", params: tuple = ()):
    try:
        with db.session() as c:
            return int(c.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}", params).fetchone()[0])
    except Exception:
        return None


def data_inventory(tenant_id: str = "", workspace_id: str = "") -> dict:
    """当前库内数据类别计数（只读）。部分表无租户列，按全局统计并显式标注。"""
    tid = str(tenant_id or "").strip()
    wid = str(workspace_id or "").strip()
    case_where, case_params = "1=1", ()
    if tid:
        case_where += " AND tenant_id=?"
        case_params += (tid,)
    if wid:
        case_where += " AND workspace_id=?"
        case_params += (wid,)
    case_sub = f"SELECT id FROM audit_case WHERE {case_where}"
    doc_where, doc_params = "1=1", ()
    if tid:
        doc_where += " AND tenant_id=?"
        doc_params += (tid,)
    if wid:
        doc_where += " AND workspace_id=?"
        doc_params += (wid,)
    counts = {
        "audit_case": _count("audit_case", case_where, case_params),
        "document": _count("document", doc_where, doc_params),
        "finding": _count("finding", f"case_id IN ({case_sub})", case_params),
        "evidence": _count("evidence", f"finding_id IN (SELECT id FROM finding WHERE case_id IN ({case_sub}))", case_params),
        "audit_log": _count("audit_log", "tenant_id=?" if tid else "1=1", (tid,) if tid else ()),
        "llm_trace": _count("llm_trace", f"case_id IN ({case_sub})", case_params),
        "llm_cache": _count("llm_cache"),
        "feedback": _count("feedback", "tenant_id=?" if tid else "1=1", (tid,) if tid else ()),
        "report": _count("report", f"case_id IN ({case_sub})", case_params),
        "open_sandbox": _count("open_sandbox", "tenant_id=?" if tid else "1=1", (tid,) if tid else ()),
    }
    notes = []
    if counts.get("llm_cache") is not None:
        notes.append("llm_cache 无租户列：计数为全局，租户级清理由缓存键隔离（见 version_snapshot）")
    if counts.get("document") is not None:
        notes.append("document 的租户过滤只在有 tenant_id 时生效；旧库 NULL 视为未归属")
    upload_bytes = 0
    files = 0
    try:
        with db.session() as c:
            rows = c.execute("SELECT path FROM document WHERE COALESCE(path,'')!='' LIMIT 10000").fetchall()
        for r in rows:
            p = str(r["path"] or "")
            try:
                if p and os.path.isfile(p):
                    upload_bytes += int(os.path.getsize(p))
                    files += 1
            except Exception:
                continue
    except Exception:
        pass
    return {"tenant_id": tid, "workspace_id": wid, "generated_at": db.now(),
            "counts": counts, "upload_files": files, "upload_bytes": upload_bytes,
            "notes": notes}


# ---------------------------------------------------------------- 删除预览 / 执行（预览→确认→审计）
def _cutoff(days: int) -> str:
    return (datetime.now() - timedelta(days=max(0, int(days)))).strftime("%Y-%m-%d %H:%M:%S")


# 删除执行类别口径：唯一事实源（预览/状态/HTTP/CLI/页面共用）。
# 只执行能按租户精确隔离的类别；审计日志（只读合规）与 llm_cache（无租户列）明确排除。
PURGE_EXECUTABLE = ("audit_case", "document", "report")
PURGE_EXCLUDED_REASONS = {
    "audit_log": "审计日志只读、不可编辑、不可删除（合规要求）；按 retention_logs_days 的归档由部署方运维流程处理",
    "llm_cache": "llm_cache 无租户列，按租户执行会跨租户误删；本接口不执行，需部署方全局运维清理",
}
PURGE_CONFIRM_TEXT = "确认删除"
PURGE_PREVIEW_TTL = 600
PURGE_AUDIT_EVENTS = ("data.purge.preview", "data.purge.dry_run", "data.purge.executed",
                      "data.purge.rejected")
_PURGE_TOKEN_PURPOSE = "data.purge.preview"
_PURGE_TOP_LEVEL = ("audit_case", "document", "report", "audit_log", "llm_cache")
# P2-13：数据边界权限口径唯一事实源（sysconfig / data_policy_routes / CLI / 文档同源）。
# 业务管理员已按《数据边界入口调整_20261117》移出数据边界；仅系统管理员可读/预览/
# dry-run/真实删除。修改这里必须同步复跑 data_policy 专项与 UI 基线。
DATA_POLICY_READ_ROLES = ("super_admin",)
DATA_POLICY_EXECUTE_ROLES = ("super_admin",)
DATA_POLICY_PAGE_DESC = (
    "已接线：仅系统管理员管理端「数据边界」视图（只读状态 + 保存配置 + 预览/dry-run）；"
    "业务管理员/审核员/平台运营无入口（HTTP/CLI 403）")


def _policy_sha(policy: dict = None) -> str:
    """策略值指纹：预览后策略被改动 → 执行必须重新预览（409）。"""
    import hashlib
    pol = policy if isinstance(policy, dict) else get_data_policy()
    raw = json.dumps({"configured": bool(pol.get("configured")),
                      "values": pol.get("values") or {}},
                     ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _plan_sha(preview: dict) -> str:
    import hashlib
    brief = {k: [v.get("retention_days"), v.get("cutoff"), v.get("would_delete")]
             for k, v in (preview.get("cutoffs") or {}).items()}
    return hashlib.sha256(json.dumps(brief, ensure_ascii=False,
                                     sort_keys=True).encode()).hexdigest()[:16]


def _plan_brief(preview: dict) -> dict:
    return {k: {"retention_days": v.get("retention_days"), "cutoff": v.get("cutoff"),
                "would_delete": v.get("would_delete"),
                "executable": bool(v.get("executable"))}
            for k, v in (preview.get("cutoffs") or {}).items()}


def _write_purge_audit(actor: str, action: str, object_: str, before: str, after: str,
                       tenant_id: str, workspace_id: str = "", request_id: str = "",
                       ip: str = "") -> str:
    """删除相关审计：显式写 tenant_id（不依赖请求上下文），失败不掩盖执行结果。"""
    rid = db.new_id("log")
    try:
        with db.session() as c:
            c.execute(
                "INSERT INTO audit_log(id,actor,action,object,before_json,after_json,request_id,ip,"
                "created_at,tenant_id,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (rid, actor or "system", action, object_ or "", before or "", after or "",
                 request_id or "", ip or "", db.now(), tenant_id or "", workspace_id or ""))
    except Exception:
        logging.getLogger(__name__).warning("data purge 审计写入失败 action=%s", action,
                                            exc_info=True)
        return ""
    return rid


def _scalar(sql: str, params=()):
    try:
        with db.session() as c:
            r = c.execute(sql, params).fetchone()
        return int(r[0]) if r is not None and r[0] is not None else 0
    except Exception:
        return None


def _workspace_belongs(tenant_id: str, workspace_id: str) -> bool:
    """工作空间是否属于目标租户（P1-08：workspace 范围必须显式校验，不能跨租户）。"""
    wid = str(workspace_id or "").strip()
    if not wid:
        return True
    try:
        with db.session() as c:
            row = c.execute("SELECT 1 FROM workspace WHERE id=? AND tenant_id=?",
                            (wid, str(tenant_id or "").strip())).fetchone()
        return row is not None
    except Exception:  # noqa: BLE001 - 校验失败不得放行 workspace 范围删除
        logging.getLogger(__name__).warning(
            "purge workspace scope check failed", exc_info=True)
        return False


def _purge_plan(tenant_id: str = "", values: dict = None,
                workspace_id: str = "") -> dict:
    """按策略计算删除影响面（只读）。

    P1-08：``workspace_id`` 非空时，所有可执行类别的统计与执行都按该工作空间
    限定（此前只回显参数、实际仍按整租户计算）；``tenant_id`` 为空 = 全局口径
    （仅兼容旧调用，HTTP/CLI 执行链路一律显式传租户）。
    """
    values = values if isinstance(values, dict) else (get_data_policy().get("values") or {})
    tid = str(tenant_id or "").strip()
    wid = str(workspace_id or "").strip()
    plan = {}

    def _entry(key, label, field_key, count, *, executable, reason="", note=""):
        days = values.get(field_key)
        base = {"field": field_key, "label": label, "executable": bool(executable),
                "reason": reason}
        if days is None:
            base.update({"status": "未配置", "retention_days": None, "cutoff": "",
                         "would_delete": None})
            return base
        if int(days) <= 0:
            base.update({"status": "不自动删除（0）", "retention_days": int(days),
                         "cutoff": "", "would_delete": 0})
            return base
        base.update({"status": "可清理（预览）" if executable else "仅预览（本接口不执行）",
                     "retention_days": int(days), "cutoff": _cutoff(int(days)),
                     "would_delete": count})
        if note:
            base["note"] = note
        return base

    def _case_scope(alias: str = "") -> tuple:
        """audit_case 作用域 where + 参数（租户必填；workspace 可选）。"""
        a = (alias + ".") if alias else ""
        where, params = a + "tenant_id=?", [tid]
        if wid:
            where += " AND " + a + "workspace_id=?"
            params.append(wid)
        return where, params

    # 1) 审核项目：租户/空间内超过 cases 留存天数的项目
    days = values.get("retention_cases_days")
    case_count = None
    if days is not None and int(days) > 0:
        cutoff = _cutoff(int(days))
        if tid:
            where, params = _case_scope()
            case_count = _scalar(
                "SELECT COUNT(*) FROM audit_case WHERE " + where
                + " AND created_at IS NOT NULL AND created_at!='' AND created_at < ?",
                tuple(params + [cutoff]))
        else:
            case_count = _scalar(
                "SELECT COUNT(*) FROM audit_case WHERE created_at IS NOT NULL "
                "AND created_at!='' AND created_at < ?", (cutoff,))
    plan["audit_case"] = _entry("audit_case", "审核项目", "retention_cases_days",
                                case_count, executable=True)

    # 2) 上传文档：与项目同口径；执行口径 = 随被删项目删除且未被保留项目引用的文档
    doc_count = None
    doc_note = ""
    if days is not None and int(days) > 0:
        cutoff = _cutoff(int(days))
        if tid:
            where, params = _case_scope("ac")
            # 保留项目引用：文档仍被“不在本次删除范围内”的项目引用（NOT(租户/空间+超期)）
            _retained = "ac2.tenant_id=? AND ac2.created_at < ?"
            _retained_params = [tid, cutoff]
            if wid:
                _retained += " AND ac2.workspace_id=?"
                _retained_params.append(wid)
            doc_count = _scalar(
                "SELECT COUNT(*) FROM document d WHERE COALESCE(d.tenant_id,'')=? "
                "AND EXISTS (SELECT 1 FROM case_document cd JOIN audit_case ac ON ac.id=cd.case_id "
                "            WHERE cd.document_id=d.id AND " + where
                + " AND ac.created_at < ?) "
                "AND NOT EXISTS (SELECT 1 FROM case_document cd2 JOIN audit_case ac2 "
                "                ON ac2.id=cd2.case_id WHERE cd2.document_id=d.id "
                "                AND NOT (" + _retained + "))",
                tuple([tid] + params + [cutoff] + _retained_params))
            doc_note = ("只删除随被删项目一起删除、且未被保留项目引用的文档；"
                        "仍被保留项目引用的不删除"
                        + ("（范围：工作空间 " + wid + "）" if wid else ""))
        else:
            doc_count = _scalar(
                "SELECT COUNT(*) FROM document WHERE created_at IS NOT NULL "
                "AND created_at!='' AND created_at < ?", (cutoff,))
            doc_note = "全局口径为上限；按租户执行时只删除随被删项目一起删除、且未被保留项目引用的文档"
    plan["document"] = _entry("document", "上传文档", "retention_cases_days",
                              doc_count, executable=True, note=doc_note)

    # 3) 审核报告：报告自身留存天数
    days = values.get("retention_reports_days")
    report_count = None
    if days is not None and int(days) > 0:
        cutoff = _cutoff(int(days))
        if tid:
            where, params = _case_scope("ac")
            report_count = _scalar(
                "SELECT COUNT(*) FROM report r JOIN audit_case ac ON ac.id=r.case_id "
                "WHERE " + where + " AND r.exported_at IS NOT NULL AND r.exported_at!='' "
                "AND r.exported_at < ?", tuple(params + [cutoff]))
        else:
            report_count = _scalar(
                "SELECT COUNT(*) FROM report WHERE exported_at IS NOT NULL "
                "AND exported_at!='' AND exported_at < ?", (cutoff,))
    plan["report"] = _entry("report", "审核报告", "retention_reports_days",
                            report_count, executable=True)

    # 4) 审计日志：只读合规，不删除（计数仅用于披露）
    days = values.get("retention_logs_days")
    log_count = None
    if days is not None and int(days) > 0:
        cutoff = _cutoff(int(days))
        if tid:
            where, params = _case_scope()
            log_count = _scalar(
                "SELECT COUNT(*) FROM audit_log WHERE " + where
                + " AND created_at IS NOT NULL AND created_at!='' AND created_at < ?",
                tuple(params + [cutoff]))
        else:
            log_count = _scalar(
                "SELECT COUNT(*) FROM audit_log WHERE created_at IS NOT NULL "
                "AND created_at!='' AND created_at < ?", (cutoff,))
    plan["audit_log"] = _entry("audit_log", "审计日志", "retention_logs_days",
                               log_count, executable=False,
                               reason=PURGE_EXCLUDED_REASONS["audit_log"])

    # 5) llm_cache：无租户/空间列，不按租户删除（计数全局，仅披露）
    days = values.get("retention_cache_days")
    cache_count = None
    if days is not None and int(days) > 0:
        cutoff = _cutoff(int(days))
        cache_count = _scalar(
            "SELECT COUNT(*) FROM llm_cache WHERE created_at IS NOT NULL "
            "AND created_at!='' AND created_at < ?", (cutoff,))
    plan["llm_cache"] = _entry(
        "llm_cache", "模型判定缓存", "retention_cache_days", cache_count, executable=False,
        reason=PURGE_EXCLUDED_REASONS["llm_cache"],
        note="计数为全局（表无租户/空间列），仅用于披露，不进入执行"
             + ("；workspace 范围清理不适用" if wid else ""))
    return plan


def retention_plan(tenant_id: str = "", workspace_id: str = "") -> dict:
    """按已配置的 ``retention_*_days`` 计算「到期应清理」影响面（只读，不删除）。

    HW-19 接线（L169）：留存天数此前只在策略页回显「天数」与实际生效说明；本函数把
    ``retention_cases_days / logs_days / cache_days / reports_days`` 真实换算为
    cutoff + 到期行数（cases / logs / cache / reports 四类），供数据边界读取面核对。
    执行面仍走既有 purge 预览→凭证→二次确认→审计链路（audit_log 只读不可删、
    llm_cache 无租户列），不在此函数内自动删除任何行。
    """
    tid = str(tenant_id or "").strip()
    if not tid:
        return {"ok": False, "status": 400, "error": "tenant_required",
                "categories": {}, "total_due": 0}
    wid = str(workspace_id or "").strip()
    try:
        plan = _purge_plan(tid, get_data_policy().get("values") or {}, wid)
    except Exception:  # noqa: BLE001 - 读取失败不得伪造成 0 到期（fail-loud 返回错误）
        logging.getLogger(__name__).warning("retention plan failed tenant=%s", tid,
                                            exc_info=True)
        return {"ok": False, "status": 500, "error": "retention_plan_failed",
                "categories": {}, "total_due": 0}
    mapping = (("cases", "audit_case"), ("logs", "audit_log"),
               ("cache", "llm_cache"), ("reports", "report"))
    cats = {}
    for short, key in mapping:
        ent = plan.get(key) or {}
        cats[short] = {
            "field": "retention_%s_days" % short,
            "label": ent.get("label") or short,
            "retention_days": ent.get("retention_days"),
            "cutoff": ent.get("cutoff") or "",
            "due": ent.get("would_delete"),
            "executable": bool(ent.get("executable")),
            "status": ent.get("status") or "未配置",
            "reason": ent.get("reason") or "",
        }
    total_due = sum(int(v.get("due") or 0) for v in cats.values())
    auto = [k for k, v in cats.items() if v.get("due") and not v.get("executable")]
    return {"ok": True, "tenant_id": tid, "workspace_id": wid,
            "generated_at": db.now(), "categories": cats, "total_due": total_due,
            "auto_enforced": False,
            "enforce_note": ("本系统不自动删除数据：真实删除走 data-policy purge "
                             "预览→二次确认→审计；audit_log 只读不可删除、llm_cache "
                             "无租户列不按租户删除"),
            "blocked_categories": auto}


def purge_preview(policy: dict = None, now: str = "", tenant_id: str = "",
                  workspace_id: str = "") -> dict:
    """按策略计算“若执行清理将涉及多少数据”——**只读预览，不删除任何行**。

    tenant_id 为空时保持旧行为（全局统计）；HTTP/CLI 执行链路一律显式传会话账号租户。
    workspace_id 非空时统计范围仅限该工作空间（P1-08：预览范围必须等于执行范围）。
    """
    values = (policy or {}).get("values") if isinstance(policy, dict) else None
    tid = str(tenant_id or "").strip()
    wid = str(workspace_id or "").strip()
    plan = _purge_plan(tid, values, wid)
    total_all = sum(int(v.get("would_delete") or 0) for v in plan.values())
    total_exec = sum(int(v.get("would_delete") or 0) for v in plan.values()
                     if v.get("executable"))
    scope_label = ("工作空间 " + wid) if wid else "整租户"
    blockers = [
        "执行范围仅限可租户精确隔离的类别：" + "、".join(PURGE_EXECUTABLE)
        + "；audit_log 与 llm_cache 不执行（原因见 excluded_categories）",
        "没有预览凭证不得执行（DELETE 未预览返回 428）；默认 dry-run 删除 0 行",
        "涉及客户数据的删除需合同授权、备份确认与操作留痕；执行前先 rp db backup",
        "上传文件只物理删除数据库目录 uploads/ 下的文件；外部路径文件不删除（由部署方处理）",
        "本次范围：" + scope_label + ("；同租户其它工作空间数据不在本次预览/执行范围内"
                                       if wid else "（未指定 workspace_id）"),
    ]
    return {
        "preview_only": True,
        "executed": False,
        "tenant_id": tid,
        "workspace_id": wid,
        "scope": "workspace" if wid else "tenant",
        "scope_label": scope_label,
        "generated_at": now or db.now(),
        "cutoffs": plan,
        "total_would_delete": total_all,
        "total_executable": total_exec,
        "executable_categories": list(PURGE_EXECUTABLE),
        "excluded_categories": dict(PURGE_EXCLUDED_REASONS),
        "requires_tenant_scope": True,
        "blockers": blockers,
    }


def create_purge_preview(tenant_id: str, workspace_id: str = "", actor: str = "",
                         request_id: str = "", ip: str = "") -> dict:
    """签发一次性预览凭证（绑定租户/策略/影响面），供二次确认后的执行使用。"""
    from .. import auth
    tid = str(tenant_id or "").strip()
    if not tid:
        raise ValueError("删除预览必须显式指定租户（禁止无租户范围的删除）")
    wid = str(workspace_id or "").strip()
    if wid and not _workspace_belongs(tid, wid):
        raise ValueError("工作空间不存在或不属于目标租户：" + wid)
    preview = purge_preview(tenant_id=tid, workspace_id=wid)
    pol = get_data_policy()
    jti = db.new_id("pt")
    payload = {"purpose": _PURGE_TOKEN_PURPOSE, "jti": jti, "tenant_id": tid,
               "workspace_id": wid,
               "policy_sha": _policy_sha(pol), "plan_sha": _plan_sha(preview),
               "actor": str(actor or ""), "exp": int(time.time()) + PURGE_PREVIEW_TTL}
    token = auth.sign_jwt(payload, auth.session_secret())
    audit_id = _write_purge_audit(
        actor=actor, action="data.purge.preview", object_="tenant:" + tid, before="",
        after=json.dumps({"jti": jti, "tenant_id": tid, "workspace_id": wid,
                          "scope": preview.get("scope"),
                          "total_would_delete": preview["total_would_delete"],
                          "total_executable": preview["total_executable"],
                          "policy_sha": payload["policy_sha"],
                          "plan_sha": payload["plan_sha"]}, ensure_ascii=False),
        tenant_id=tid, workspace_id=wid, request_id=request_id, ip=ip)
    return {**preview, "preview_token": token, "token_jti": jti,
            "token_expires_in": PURGE_PREVIEW_TTL, "actor": str(actor or ""),
            "audit_id": audit_id}


def _verify_purge_token(token: str, tenant_id: str, workspace_id: str = ""):
    """校验预览凭证：过期/伪造 → 428；跨租户/跨空间 → 403。返回 (payload, deny)。"""
    from .. import auth
    payload = auth.verify_jwt(str(token or ""), auth.session_secret())
    if not payload or payload.get("purpose") != _PURGE_TOKEN_PURPOSE:
        return None, {"ok": False, "status": 428, "code": "preview_required",
                      "error": "删除执行必须先预览：缺少有效 preview_token（过期或伪造），请重新预览"}
    if str(payload.get("tenant_id") or "") != str(tenant_id or ""):
        return payload, {"ok": False, "status": 403, "code": "tenant_mismatch",
                         "error": "跨租户删除被拒绝：预览凭证所属租户与当前账号租户不一致"}
    if str(payload.get("workspace_id") or "") != str(workspace_id or ""):
        return payload, {"ok": False, "status": 403, "code": "workspace_mismatch",
                         "error": "删除范围被拒绝：预览凭证的工作空间与本次执行目标不一致"
                                  "（预览与执行范围必须一致，请重新预览）"}
    return payload, None


def _purge_token_used(jti: str) -> bool:
    if not jti:
        return False
    n = _scalar("SELECT COUNT(*) FROM audit_log WHERE action='data.purge.executed' "
                "AND after_json LIKE ?", ("%" + jti + "%",))
    if n:
        return True
    # P2-02：兼容旧库（升级前已执行过的凭证没有 purge_execution 行，只有审计可查）。
    try:
        n2 = _scalar("SELECT COUNT(*) FROM purge_execution WHERE jti=?", (jti,))
        return bool(n2)
    except Exception:
        return False


def _claim_purge_jti(jti: str, tenant_id: str, workspace_id: str, actor: str) -> bool:
    """P2-02：以 ``purge_execution.jti`` 主键 INSERT 抢占一次性执行权。

    返回 True=本次抢到（允许执行删除）；False=已被执行过（重放/并发双执行）。
    SQLite 主键冲突是原子的：并发两个请求只有一个 INSERT 成功，另一个失败。
    异常不吞（表缺失/DB 故障由调用方按 fail-closed 处理）。
    """
    if not jti:
        return False
    try:
        with db.session() as c:
            c.execute("INSERT INTO purge_execution(jti, tenant_id, workspace_id, actor, executed_at) "
                      "VALUES(?,?,?,?,?)", (jti, str(tenant_id or ""),
                                            str(workspace_id or ""), str(actor or ""), db.now()))
        return True
    except Exception as exc:  # noqa: BLE001
        text = f"{type(exc).__name__}: {exc}".lower()
        if "unique" in text or "primary key" in text or "constraint" in text:
            return False
        raise


def _record_purge_result(jti: str, result: dict) -> None:
    """记录执行结果摘要（尽最大努力；jti 行本身已保证凭证不可重放）。"""
    try:
        with db.session() as c:
            c.execute("UPDATE purge_execution SET result_json=? WHERE jti=?",
                      (json.dumps(result, ensure_ascii=False)[:4000], str(jti or "")))
    except Exception:
        logging.getLogger(__name__).warning("purge result record failed jti=%s", jti,
                                            exc_info=True)


def _deny(status: int, code: str, error: str, **extra) -> dict:
    return {"ok": False, "status": int(status), "code": code, "error": error, **extra}


def _chunks(seq, size=400):
    seq = list(seq or [])
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


def _table_exists(c, name: str) -> bool:
    try:
        return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                         (name,)).fetchone() is not None
    except Exception:
        return False


def _delete(c, table: str, sql: str, params=()) -> int:
    if not _table_exists(c, table):
        return 0
    try:
        cur = c.execute(sql, params)
        return int(cur.rowcount or 0)
    except Exception as exc:  # noqa: BLE001 - 删除失败必须回滚并显式报错
        raise RuntimeError(f"删除 {table} 失败：{type(exc).__name__}: {exc}") from exc


# 项目级联删除顺序（叶子 → 父）：finding 子表在前，finding/audit_run/report 在 audit_case 前
_CASE_CHILD_SQL = (
    ("evidence", "DELETE FROM evidence WHERE finding_id IN "
                 "(SELECT id FROM finding WHERE case_id IN ({ph}))"),
    ("decision", "DELETE FROM decision WHERE finding_id IN "
                 "(SELECT id FROM finding WHERE case_id IN ({ph}))"),
    ("evolution_task", "DELETE FROM evolution_task WHERE finding_id IN "
                       "(SELECT id FROM finding WHERE case_id IN ({ph}))"),
    ("qa_sample", "DELETE FROM qa_sample WHERE case_id IN ({ph})"),
    ("manifest_review", "DELETE FROM manifest_review WHERE result_id IN "
                        "(SELECT id FROM manifest_result WHERE manifest_id IN "
                        "(SELECT id FROM audit_manifest WHERE case_id IN ({ph})))"),
    ("manifest_evidence", "DELETE FROM manifest_evidence WHERE result_id IN "
                          "(SELECT id FROM manifest_result WHERE manifest_id IN "
                          "(SELECT id FROM audit_manifest WHERE case_id IN ({ph})))"),
    ("manifest_result", "DELETE FROM manifest_result WHERE manifest_id IN "
                        "(SELECT id FROM audit_manifest WHERE case_id IN ({ph}))"),
    ("manifest_active_sub", "DELETE FROM manifest_active_sub WHERE case_id IN ({ph})"),
    ("manifest_active", "DELETE FROM manifest_active WHERE case_id IN ({ph})"),
    ("rule_snapshot", "DELETE FROM rule_snapshot WHERE case_id IN ({ph})"),
    ("feedback", "DELETE FROM feedback WHERE case_id IN ({ph})"),
    ("audit_manifest", "DELETE FROM audit_manifest WHERE case_id IN ({ph})"),
    ("report", "DELETE FROM report WHERE case_id IN ({ph})"),
    ("llm_trace", "DELETE FROM llm_trace WHERE case_id IN ({ph})"),
    ("agent_node_run", "DELETE FROM agent_node_run WHERE agent_run_id IN "
                       "(SELECT id FROM agent_run WHERE case_id IN ({ph}))"),
    ("agent_run", "DELETE FROM agent_run WHERE case_id IN ({ph})"),
    ("finding", "DELETE FROM finding WHERE case_id IN ({ph})"),
    ("audit_run", "DELETE FROM audit_run WHERE case_id IN ({ph})"),
    ("case_document", "DELETE FROM case_document WHERE case_id IN ({ph})"),
    ("audit_case", "DELETE FROM audit_case WHERE id IN ({ph})"),
)


def _execute_purge(tenant_id: str, workspace_id: str = "") -> tuple:
    """执行一次按策略的级联删除（调用方已校验预览凭证/二次确认/角色）。

    P1-08：``workspace_id`` 非空时只删除该工作空间内的超期项目/文档/报告，
    与预览范围严格一致；否则为整租户范围。

    返回 (deleted_counts, cascade_counts, file_paths_before_delete)。
    """
    values = get_data_policy().get("values") or {}
    tid = str(tenant_id or "").strip()
    wid = str(workspace_id or "").strip()
    deleted = {k: 0 for k in _PURGE_TOP_LEVEL}
    cascade = {}
    file_paths = []
    cases_days = values.get("retention_cases_days")
    with db.session() as c:
        case_ids = []
        doc_rows = []
        if cases_days is not None and int(cases_days) > 0:
            cutoff = _cutoff(int(cases_days))
            _case_where = "tenant_id=?"
            _case_params = [tid]
            if wid:
                _case_where += " AND workspace_id=?"
                _case_params.append(wid)
            case_ids = [str(r["id"]) for r in c.execute(
                "SELECT id FROM audit_case WHERE " + _case_where
                + " AND created_at IS NOT NULL AND created_at!='' AND created_at < ?",
                tuple(_case_params + [cutoff])).fetchall()]
            # 文档候选必须在项目级联删除前算出（删除 case_document 后就查不到归属）
            if case_ids:
                in_ph = ",".join("?" * len(case_ids))
                doc_rows = c.execute(
                    "SELECT d.id, COALESCE(d.path,'') AS path FROM document d "
                    "WHERE COALESCE(d.tenant_id,'')=? "
                    "AND EXISTS (SELECT 1 FROM case_document cd WHERE cd.document_id=d.id "
                    "            AND cd.case_id IN (" + in_ph + ")) "
                    "AND NOT EXISTS (SELECT 1 FROM case_document cd2 WHERE cd2.document_id=d.id "
                    "                AND cd2.case_id NOT IN (" + in_ph + "))",
                    tuple([tid] + case_ids + case_ids)).fetchall()
        for chunk in _chunks(case_ids):
            ph = ",".join("?" * len(chunk))
            params = tuple(chunk)
            for table, sql in _CASE_CHILD_SQL:
                n = _delete(c, table, sql.format(ph=ph), params)
                if n:
                    cascade[table] = int(cascade.get(table) or 0) + n
        deleted["audit_case"] = len(case_ids)

        # 上传文档：随被删项目删除、且未被保留项目引用
        doc_ids = [str(r["id"]) for r in doc_rows]
        file_paths = [str(r["path"] or "") for r in doc_rows if str(r["path"] or "")]
        for chunk in _chunks(doc_ids):
            ph = ",".join("?" * len(chunk))
            params = tuple(chunk)
            n_anchor = _delete(c, "anchor",
                                f"DELETE FROM anchor WHERE document_id IN ({ph})", params)
            if n_anchor:
                cascade["anchor"] = int(cascade.get("anchor") or 0) + n_anchor
            deleted["document"] += _delete(
                c, "document", f"DELETE FROM document WHERE id IN ({ph})", params)

        # 审核报告：报告自身留存（被删项目的报告已随级联删除，这里只剩保留项目的旧报告）
        reports_days = values.get("retention_reports_days")
        if reports_days is not None and int(reports_days) > 0:
            cutoff = _cutoff(int(reports_days))
            _rep_where = "tenant_id=?"
            _rep_params = [tid]
            if wid:
                _rep_where += " AND workspace_id=?"
                _rep_params.append(wid)
            deleted["report"] += _delete(
                c, "report",
                "DELETE FROM report WHERE exported_at IS NOT NULL AND exported_at!='' "
                "AND exported_at < ? AND case_id IN "
                "(SELECT id FROM audit_case WHERE " + _rep_where + ")",
                tuple([cutoff] + _rep_params))
    # audit_log / llm_cache：显式不删除（合规/跨租户），计数保持 0
    return deleted, cascade, file_paths


def _delete_upload_files(paths: list) -> dict:
    """只删除数据库目录 uploads/ 内的文件；外部路径（种子/演示文件等）不删除。"""
    try:
        root = os.path.realpath(os.path.join(os.path.dirname(str(db.DB_PATH)), "uploads"))
    except Exception:
        root = ""
    deleted, skipped = 0, 0
    for p in paths or []:
        try:
            rp = os.path.realpath(str(p))
        except Exception:
            skipped += 1
            continue
        if not root or not os.path.isfile(rp) or not rp.startswith(root + os.sep):
            skipped += 1
            continue
        try:
            os.remove(rp)
            deleted += 1
        except Exception:
            skipped += 1
    return {"files_deleted": deleted, "files_skipped": skipped, "uploads_root": root}


def purge_execute(tenant_id: str, preview_token: str, actor: str = "", confirm: str = "",
                  dry_run: bool = True, workspace_id: str = "", request_id: str = "",
                  ip: str = "", role: str = "", actor_tenant: str = "") -> dict:
    """删除执行：预览凭证校验 → 二次确认 → 审计 → 执行。

    安全约束（与 HTTP/CLI 同一实现）：
    - 没有有效预览凭证 → 428，不删除任何行（不得未预览直接 DELETE）；
    - 跨租户（凭证租户 != 目标租户）→ 403；
    - 预览后策略被改动 → 409，要求重新预览；
    - 默认 dry_run=True：只返回计划，不删除任何行、不消耗凭证；
    - 真实执行（dry_run=False）必须 confirm=PURGE_CONFIRM_TEXT 且 role=super_admin；
    - 审计日志与 llm_cache 显式不删除。
    """
    tid = str(tenant_id or "").strip()
    if not tid:
        return _deny(400, "invalid_tenant", "删除执行必须指定租户（禁止无租户范围的删除）")
    wid = str(workspace_id or "").strip()
    # P1-08：执行范围必须与预览凭证绑定范围一致（租户 + 工作空间），不得忽略或放大。
    payload, deny = _verify_purge_token(preview_token, tid, wid)
    if deny:
        # 拒绝审计写到操作者自己的租户（不向目标租户跨租户写审计行）
        _audit_tid = str(actor_tenant or (payload or {}).get("tenant_id") or "")
        if _audit_tid:
            _write_purge_audit(
                actor=actor, action="data.purge.rejected", object_="tenant:" + tid, before="",
                after=json.dumps({"reason": deny.get("code"), "tenant_id": tid,
                                  "workspace_id": wid, "dry_run": bool(dry_run)},
                                 ensure_ascii=False),
                tenant_id=_audit_tid, workspace_id=wid,
                request_id=request_id, ip=ip)
        else:
            logging.getLogger(__name__).warning(
                "data purge rejected（无有效预览凭证，未写审计）：actor=%s target=%s code=%s",
                actor, tid, deny.get("code"))
        return {**deny, "workspace_id": wid, "deleted": {}, "total_deleted": 0,
                "executed": False}
    if wid and not _workspace_belongs(tid, wid):
        return _deny(404, "workspace_not_found",
                     "工作空间不存在或不属于目标租户：" + wid,
                     deleted={}, total_deleted=0, executed=False)
    if str(payload.get("policy_sha") or "") != _policy_sha():
        return _deny(409, "policy_changed",
                     "数据策略在预览后已变更，请重新预览后再执行（防止按过期影响面删除）")
    jti = str(payload.get("jti") or "")
    if _purge_token_used(jti):
        return _deny(409, "token_used", "该预览凭证已执行过删除，不能重放；请重新预览")
    preview = purge_preview(tenant_id=tid, workspace_id=wid)
    if dry_run:
        audit_id = _write_purge_audit(
            actor=actor, action="data.purge.dry_run", object_="tenant:" + tid, before="",
            after=json.dumps({"jti": jti, "tenant_id": tid, "workspace_id": wid,
                              "scope": preview.get("scope"),
                              "planned": _plan_brief(preview),
                              "total_deleted": 0}, ensure_ascii=False),
            tenant_id=tid, workspace_id=wid, request_id=request_id, ip=ip)
        return {"ok": True, "executed": False, "dry_run": True, "tenant_id": tid,
                "workspace_id": wid, "scope": preview.get("scope"),
                "scope_label": preview.get("scope_label"),
                "planned": _plan_brief(preview),
                "deleted": {k: 0 for k in _PURGE_TOP_LEVEL},
                "total_deleted": 0, "total_rows_deleted": 0,
                "preview_token_consumed": False,
                "excluded_categories": dict(PURGE_EXCLUDED_REASONS),
                "audit_id": audit_id,
                "message": "dry-run：未删除任何行。真实执行需 dry_run=false + confirm="
                           + PURGE_CONFIRM_TEXT + "，且仅系统管理员可执行"}
    if str(confirm or "") != PURGE_CONFIRM_TEXT:
        return _deny(400, "confirm_required",
                     f"二次确认失败：confirm 必须为「{PURGE_CONFIRM_TEXT}」",
                     deleted={}, total_deleted=0, executed=False)
    if str(role or "") != "super_admin":
        return _deny(403, "forbidden", "实际删除仅系统管理员执行（业务管理员可预览/dry-run）",
                     deleted={}, total_deleted=0, executed=False)
    # P2-02：一次性凭证由 DB 主键原子抢占，替代“执行后查审计 LIKE”的竞态判定；
    # 抢不到 = 已执行过/并发请求，直接 409 且不删除任何行。
    try:
        claimed = _claim_purge_jti(jti, tid, wid, actor)
    except Exception as exc:  # noqa: BLE001 - 抢占异常必须 fail-closed（不删数据）
        logging.getLogger(__name__).error("data purge claim failed: %s", exc, exc_info=True)
        return _deny(500, "purge_claim_failed",
                     "删除执行权抢占失败（数据库异常），本次未删除任何行，请稍后重试",
                     deleted={}, total_deleted=0, executed=False)
    if not claimed:
        return _deny(409, "token_used", "该预览凭证已执行过删除，不能重放；请重新预览",
                     deleted={}, total_deleted=0, executed=False)
    # 占位成功后才真正删除；若删除中途异常，凭证已消费（fail-safe：不能重放/重复删）。
    deleted, cascade, file_paths = _execute_purge(tid, wid)
    files = _delete_upload_files(file_paths)
    top_total = sum(int(v or 0) for v in deleted.values())
    rows_total = top_total + sum(int(v or 0) for v in cascade.values())
    _record_purge_result(jti, {"tenant_id": tid, "workspace_id": wid,
                               "deleted": deleted, "cascade": cascade, "files": files})
    audit_id = _write_purge_audit(
        actor=actor, action="data.purge.executed", object_="tenant:" + tid, before="",
        after=json.dumps({"jti": jti, "tenant_id": tid, "workspace_id": wid,
                          "scope": "workspace" if wid else "tenant",
                          "deleted": deleted, "cascade": cascade,
                          "files": files}, ensure_ascii=False),
        tenant_id=tid, workspace_id=wid, request_id=request_id, ip=ip)
    return {"ok": True, "executed": True, "dry_run": False, "tenant_id": tid,
            "workspace_id": wid, "scope": "workspace" if wid else "tenant",
            "deleted": deleted, "cascade": cascade, "files": files,
            "total_deleted": top_total, "total_rows_deleted": rows_total,
            "preview_token_consumed": True,
            "excluded_categories": dict(PURGE_EXCLUDED_REASONS),
            "audit_id": audit_id,
            "message": "删除完成（范围：" + (("工作空间 " + wid) if wid else "整租户")
                       + "）；audit_log / llm_cache 未删除（原因见 excluded_categories）"}
