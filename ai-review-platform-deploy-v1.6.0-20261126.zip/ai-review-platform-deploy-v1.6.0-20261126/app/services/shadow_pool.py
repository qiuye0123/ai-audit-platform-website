# -*- coding: utf-8 -*-
"""T-194 影子池产品化 Phase 1：三区仲裁 + 影子池服务层（后端唯一事实源）。

## 用户要的影子池（原话，设计依据）
> 直连 70–80% 疑似的放影子；平台 70–80% 拿不准的也放影子；
> 审核员可选择自己开启查看这种疑似问题（要提示可能误报也可能真问题）；
> 人工审核完了进入自进化；就算不判断也不丢弃，要二次复核。

## 本模块解决的问题
产品里零件都在（``human_review.hidden_items`` / ``visibility_policy`` 四桶 /
``suppression_ledger`` 抑制台账 / ``accuracy_shadow`` 影子覆盖标记 / ``report_gate``），
但**没有串成一条链**：谁进正式报告、谁进影子池、谁被确定性证伪丢弃，以及影子项的
裁决/自进化/二次复核/权限/审计/报告口径。本模块是这条链的**服务层单一事实源**。

Phase 1（本文件）只做服务层 + 报告口径 + 审计权限 + 测试；HTTP/CLI/前端接线
（Phase 2）在 ``docs/qa/影子池产品化_20261120.md`` 写契约，等 p05-d2d3 / kb-fix2
收口后实现（本文件不 import 任何 HTTP/CLI 模块）。

## 三区（报告口径）与 audit_zone 的区别（重要）
- 本模块 ``zone`` ∈ ``formal | shadow | discarded`` = **报告口径分区**（谁进正式报告）；
- ``audit_zone`` 的 ``deterministic | evidence | shadow`` = **执行层三区分层**（只读统计）；
- 两者不是同一概念，因此**没有**给 ``finding.zone`` 加字段（避免同名异义），
  而是新增独立 ``shadow_item`` 表（见 :func:`ensure_schema` 与文档 §2）。

## 数据模型（独立 shadow_item 表，db.py SHADOW_POOL_SCHEMA）
- ``zone``：``shadow``（疑似待裁决）| ``discarded``（确定性证伪留痕）；
  ``formal`` 不是存储值——**不在本表 = formal**，正式报告只读 finding 表即天然隔离。
- ``zone_source``：``direct | platform | both | arbiter``（哪一侧/仲裁产生）。
- ``shadow_reason``：``direct_suspect | platform_unsure | conflict | direct_false_positive``
  （+ ``ttl_purged`` 仅供归档留痕）。
- ``shadow_confidence`` / ``shadow_round`` / ``shadow_status``（pending/confirmed/
  false_positive/unsure/skipped/escalated）/ 裁决人/时间/升级时间/默认处置。
- 原始 claim 与归属、zone 不可 UPDATE（触发器），禁止物理 DELETE（影子不是删除）。

## 仲裁规则（R1–R4，对齐用户设计）
- R1 平台确定性执行器 fail + 引文锚定 → formal（source=platform；双方都产出则 both）
- R2 直连 finding 被平台确定性 pass + 证据锚定证伪 → discarded（reason=direct_false_positive，
  **留痕不静默**）；高风险直连项不直接丢弃（降为 shadow/conflict，沿用“critical 不自动隐藏”）
- R3 任一方产出但无法确定性确认 → shadow
  （reason 区分 direct_suspect / platform_unsure / conflict）
- R4 平台确定性 pass 且直连无 finding → formal（pass）

## 报告口径（硬约束）
- 正式报告只统计 formal；``report_gate.check`` 通过 :func:`formal_excluded_finding_ids`
  把已被仲裁进 shadow/discarded 的既有平台 finding 从正式口径剔除；
- shadow 单列「疑似问题（未裁决）N 条」，**不阻断**正式报告，**不进通过率分母**；
- discarded 不出现于报告，只进审计（含 reason/来源/claim sha256）；
- ``shadow.export``（默认 admin）才可导出影子清单；reviewer 403。

## 审计事件（全部写 audit_log，业务写与审计同连接同事务）
``shadow.added / shadow.revealed / shadow.decided / shadow.escalated / shadow.purged``

## 权限（服务层强制，不依赖前端；越权 403/404）
- ``shadow.view``：reviewer 本人项目；admin 本租户只读；super_admin/platform_op 403。
- ``shadow.decide``：仅 reviewer 本人项目；admin 403（业务管理员只读）。
- ``shadow.export``：仅 admin（业务管理员）可导出影子清单，且写审计。
- 跨租户 404（不泄露存在性）；无 actor 的裁决/打开 401。
- 内部调用（无 actor/role，report_gate/迁移脚本）只允许只读汇总；
  reveal/decide/escalate/purge/export 必须有身份。

## 自进化（不判也不丢）
- 裁决写 ``feedback``（confirm=正例；false_positive=**反例卡**；unsure=待补证）；
  feedback 由现有 RSI/进化链路消费（本模块不自动调阈值/不自动训练：写死
  ``no_gold=1 / auto_threshold_change=0 / auto_training=0``）；
- ``skip`` 不判也不丢：状态 ``skipped`` 仍属未裁决，进入 :func:`escalate_pending` 二次复核；
- 超过 ``rounds`` 轮仍无法确认 → 默认处置 ``suspected_false_positive``（weak，非 gold）。

## Phase 2（不在本文件实现）
API 路由 / CLI 命令 / 工作台开关接线 / report.py 渲染 hook：见
``docs/qa/影子池产品化_20261120.md`` §Phase 2 契约。

## T-202 唯一主链与唯一入口（2026-11-20）
本模块是三区**唯一仲裁**（双轨主链第 2 步）：``classify`` 是唯一把候选判成
formal/shadow/discarded 的入口；``visibility_policy`` 只提供策略、``suppression_ledger``
只记账、``accuracy_shadow`` 只做只读标注，都不得自行分区。产品代码只能经
``app.services.dual_track_gateway``（``classify`` / ``record_arbitration`` /
``report_partition``）调用本模块；职责边界见 ``docs/qa/双轨唯一入口约束_20261120.md``。
"""
from __future__ import annotations

import hashlib
import json
import logging

from .. import db
from .. import repositories as R
from . import visibility_policy as VP

LOGGER = logging.getLogger(__name__)

SHADOW_TABLE = "shadow_item"

# --------------------------------------------------------------------------- 常量
ZONE_FORMAL = "formal"          # 不落库：不在 shadow_item = formal
ZONE_SHADOW = "shadow"
ZONE_DISCARDED = "discarded"
ZONES = (ZONE_FORMAL, ZONE_SHADOW, ZONE_DISCARDED)

ZONE_SOURCES = ("direct", "platform", "both", "arbiter")
ZONE_SOURCE_LABELS = {
    "direct": "直连侧", "platform": "平台侧", "both": "双方",
    "arbiter": "仲裁器（确定性证伪）",
}

# 进入影子的理由（与用户设计一一对应）
REASON_DIRECT_SUSPECT = "direct_suspect"            # 直连 70–80% 疑似、平台不足以确认
REASON_PLATFORM_UNSURE = "platform_unsure"          # 平台 70–80% 拿不准（非确定性/无锚定）
REASON_CONFLICT = "conflict"                        # 双方产出但结论冲突（含高风险反证保护）
REASON_DIRECT_FALSE_POSITIVE = "direct_false_positive"  # 直连被平台确定性证伪 → discarded
REASON_TTL_PURGED = "ttl_purged"                    # 归档留痕（仅 purge 记录）
SHADOW_REASONS = (REASON_DIRECT_SUSPECT, REASON_PLATFORM_UNSURE, REASON_CONFLICT,
                  REASON_DIRECT_FALSE_POSITIVE, REASON_TTL_PURGED)
REASON_LABELS = {
    REASON_DIRECT_SUSPECT: "直连疑似（平台未能确定性确认）",
    REASON_PLATFORM_UNSURE: "平台拿不准（非确定性/证据不足）",
    REASON_CONFLICT: "双方冲突（需人工裁决）",
    REASON_DIRECT_FALSE_POSITIVE: "直连误报（被平台确定性证伪）",
    REASON_TTL_PURGED: "归档留痕",
}

# 影子项状态机
STATUS_PENDING = "pending"
STATUS_CONFIRMED = "confirmed"
STATUS_FALSE_POSITIVE = "false_positive"
STATUS_UNSURE = "unsure"
STATUS_SKIPPED = "skipped"
STATUS_ESCALATED = "escalated"
SHADOW_STATUSES = (STATUS_PENDING, STATUS_CONFIRMED, STATUS_FALSE_POSITIVE,
                   STATUS_UNSURE, STATUS_SKIPPED, STATUS_ESCALATED)
STATUS_LABELS = {
    STATUS_PENDING: "待裁决", STATUS_CONFIRMED: "已确认真问题",
    STATUS_FALSE_POSITIVE: "已判误报", STATUS_UNSURE: "存疑（待二次复核）",
    STATUS_SKIPPED: "跳过（不判断，仍会二次复核）",
    STATUS_ESCALATED: "已升级二次复核",
}
# 未裁决（含跳过/存疑/已升轮）：报告 N 计数口径 + 二次复核候选
OPEN_STATUSES = (STATUS_PENDING, STATUS_SKIPPED, STATUS_UNSURE, STATUS_ESCALATED)
RESOLVED_STATUSES = (STATUS_CONFIRMED, STATUS_FALSE_POSITIVE)

# 四动作（真 / 误报 / 存疑 / 跳过）→ (影子状态, feedback kind)
DECIDE_ACTIONS = ("confirm", "false_positive", "unsure", "skip")
ACTION_ALIASES = {
    "confirm": "confirm", "confirmed": "confirm", "true": "confirm",
    "true_positive": "confirm", "确认": "confirm", "真问题": "confirm",
    "false_positive": "false_positive", "false-positive": "false_positive",
    "fp": "false_positive", "reject": "false_positive", "误报": "false_positive",
    "unsure": "unsure", "undecided": "unsure", "doubt": "unsure", "存疑": "unsure",
    "skip": "skip", "skipped": "skip", "pass": "skip", "跳过": "skip",
}
ACTION_LABELS = {"confirm": "确认真问题", "false_positive": "确认为误报",
                 "unsure": "存疑（转二次复核）", "skip": "跳过（不判断，仍会二次复核）"}
_ACTION_TO_STATUS = {"confirm": STATUS_CONFIRMED,
                     "false_positive": STATUS_FALSE_POSITIVE,
                     "unsure": STATUS_UNSURE, "skip": STATUS_SKIPPED}
_ACTION_TO_FEEDBACK = {"confirm": "confirm", "false_positive": "false_positive",
                       "unsure": "need_evidence", "skip": ""}

EVENT_ADDED = "shadow.added"
EVENT_REVEALED = "shadow.revealed"
EVENT_DECIDED = "shadow.decided"
EVENT_ESCALATED = "shadow.escalated"
EVENT_PURGED = "shadow.purged"
AUDIT_EVENTS = (EVENT_ADDED, EVENT_REVEALED, EVENT_DECIDED, EVENT_ESCALATED, EVENT_PURGED)

# “要提示可能误报也可能真问题”（用户原话）——所有展示/裁决入口统一文案
SHADOW_WARNING = "疑似问题：可能误报，也可能真问题；默认不计入正式报告与通过率。"
SHADOW_HINT_TPL = "疑似问题（未裁决）{n} 条"
SHADOW_NO_GOLD_NOTE = "影子项不是 gold；裁决仅写 feedback 候选，不自动调阈值/不自动训练。"
DEFAULT_ESCALATION_ROUNDS = 2
DEFAULT_ESCALATION_HOURS = 72
DEFAULT_DISPOSITION = "suspected_false_positive"   # weak 默认处置（非 gold）
EXPORT_PERMISSION = "shadow.export"
EXPORT_DEFAULT_ROLES = ("admin",)

# 确定性执行器（与 accuracy_shadow._DET_EXECUTORS / audit_zone.method 映射同源口径）
DETERMINISTIC_EXECUTORS = frozenset({
    "ruleexec", "decision_table", "manifest:decision_table", "tool", "regex",
    "fact", "dmn", "deterministic", "calculate", "text", "compare",
    "rule_engine", "rule_ir"})
SEMANTIC_EXECUTORS = frozenset({
    "agent-judge", "judge", "llm", "model", "semantic", "expert", "agent"})

# manifest-dag 是 D5 汇总门（把 D4 各子判据结论合成一条 finding），**不是单执行器**：
# 它既可能全部由 ruleexec/decision_table 等确定性算子得出，也可能含 agent-judge 等
# 语义判据。因此不能一刀切放进 DETERMINISTIC_EXECUTORS，也不能一律当语义：
# 判定口径 = 「本次 DAG 结果里实际执行的子判据执行器全部是确定性算子」才算确定性；
# 任一条语义/未知执行器 → 非确定性（fail-closed，仍走 R3 影子）。
# 子判据执行器的真实字段：``manifest_result.d4_json.subs[].tool_trace.executor``
# （实测值形如 ruleexec.limit / ruleexec.applicability / decision_table / agent-judge）。
MANIFEST_DAG_ENGINE = "manifest-dag"

# 读取输出永不返回 gold 类字段（与 human_review._FORBIDDEN_HIDDEN_KEYS 同口径）
_FORBIDDEN_KEYS = frozenset({
    "gold", "gold_hit", "gold_hits", "gold_issue_id", "gold_issue", "gold_label",
    "gold_standard", "gold_ref", "gold_answer", "auto_label", "auto_suggested_label",
    "label_auto", "auto_gold"})

_MAX_TEXT = 2000
_MAX_NOTE = 500
_MAX_ITEMS = 500


# --------------------------------------------------------------------------- 基础工具
def _now() -> str:
    return db.now()


def _sha256_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


def _canonical_json(obj) -> str:
    return json.dumps(obj if obj is not None else {}, ensure_ascii=False,
                      sort_keys=True, separators=(",", ":"))


def _ok(**payload) -> dict:
    return {"ok": True, **payload}


def _err(status, code: str, message: str, **payload) -> dict:
    return {"ok": False, "status": int(status), "code": str(code or "error"),
            "error": str(message or "请求失败"), **payload}


def _loads(value, default=None):
    if isinstance(value, (dict, list)):
        return value
    try:
        out = json.loads(value or "")
        return out if out is not None else (default if default is not None else {})
    except Exception:  # noqa: BLE001
        return default if default is not None else {}


def _norm(value) -> str:
    return str(value or "").strip().lower()


def _clamp_confidence(value):
    try:
        val = float(value)
    except (TypeError, ValueError):
        return None
    if val != val:  # NaN
        return None
    return round(min(1.0, max(0.0, val)), 4)


def _table_exists(conn, table: str = SHADOW_TABLE) -> bool:
    try:
        return bool(conn.execute(
            "SELECT count(*) FROM sqlite_master WHERE type='table' AND name=?",
            (table,)).fetchone()[0])
    except Exception:  # noqa: BLE001
        return False


def _insert_row(conn, table: str, **cols) -> None:
    """按表实际列过滤后 INSERT（兼容老库/迁移差异，不猜列）。"""
    actual = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    data = {k: v for k, v in cols.items() if k in actual}
    if not data:
        raise ValueError(f"{table} 无可写列")
    keys = list(data.keys())
    conn.execute(f"INSERT INTO {table} ({','.join(keys)}) "
                 f"VALUES ({','.join('?' * len(keys))})", [data[k] for k in keys])


def _case(case_id: str) -> dict | None:
    try:
        return R.cases.get(str(case_id or ""))
    except Exception:  # noqa: BLE001
        LOGGER.warning("shadow_pool case lookup failed case=%s", case_id, exc_info=True)
        return None


def _row_in_case_scope(case: dict, row: dict) -> bool:
    """行级 IDOR 兜底：影子行租户/空间必须与 case 一致（空值兼容老数据）。"""
    for key in ("tenant_id", "workspace_id"):
        case_val = str(case.get(key) or "")
        row_val = str(row.get(key) or "")
        if case_val and row_val and case_val != row_val:
            return False
    return True


def _resolve_actor(actor: str = "", role: str = "") -> dict:
    from . import review as _review
    try:
        return _review.resolve_actor(actor, role)
    except Exception:  # noqa: BLE001
        LOGGER.warning("shadow_pool resolve_actor failed", exc_info=True)
        return {"actor": str(actor or ""), "role": str(role or ""), "roles": [],
                "resolved": False, "identity_verified": False, "declared_role": "",
                "role_mismatch": False}


def _internal(actor: str = "", role: str = "") -> bool:
    return not str(actor or "").strip() and not str(role or "").strip()


def _authorize_case(case_id: str, action: str, actor: str = "", role: str = "") -> dict:
    from . import review as _review
    try:
        return _review.authorize_case(case_id, action, actor, role)
    except Exception:  # noqa: BLE001
        LOGGER.warning("shadow_pool authorize failed case=%s", case_id, exc_info=True)
        return {"ok": False, "status": 403, "code": "forbidden", "message": "无权限"}


def _deny(access: dict) -> dict:
    return _err(int(access.get("status") or 403), access.get("code") or "forbidden",
                access.get("message") or "无权限")


def _audit(conn, *, actor: str, action: str, obj: str = "", case: dict | None = None,
           before="", after="") -> None:
    """写产品审计（audit_log；与业务写同事务）。"""
    case = case or {}
    try:
        _insert_row(
            conn, "audit_log", id=db.new_id("log"), actor=str(actor or "system"),
            action=str(action or ""), object=str(obj or ""),
            before_json=(before if isinstance(before, str) else json.dumps(before or {},
                                                                         ensure_ascii=False)),
            after_json=(after if isinstance(after, str) else json.dumps(after or {},
                                                                       ensure_ascii=False)),
            request_id="", ip="", created_at=_now(),
            tenant_id=str(case.get("tenant_id") or ""),
            workspace_id=str(case.get("workspace_id") or ""))
    except Exception:  # noqa: BLE001
        # 铁律 4：审计写失败必须上抛（关键写操作不得“业务成功但审计丢失”）
        raise


def _strip_forbidden(value):
    """递归剔除 gold/auto_label 类字段（影子项输出绝不泄露 gold 标签）。"""
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            k = str(key)
            low = k.lower()
            if k in _FORBIDDEN_KEYS or low.startswith("gold") \
                    or low.startswith("auto_suggested") or low == "auto_label":
                continue
            out[k] = _strip_forbidden(item)
        return out
    if isinstance(value, list):
        return [_strip_forbidden(x) for x in value]
    return value


# --------------------------------------------------------------------------- schema
def ensure_schema(conn=None) -> dict:
    """幂等创建 shadow_item 表/索引/触发器（可重复调用；老库自动补表）。"""
    own = conn is None
    c = conn or db.connect()
    try:
        stats = db._init_shadow_pool_schema(c)
        if own:
            c.commit()
        return stats
    finally:
        if own:
            c.close()


def rollback_schema(conn=None) -> dict:
    """回滚影子池迁移（仅人工/迁移脚本显式调用，产品主链不调用）。"""
    own = conn is None
    c = conn or db.connect()
    try:
        out = db.drop_shadow_pool_schema(c)
        if own:
            c.commit()
        return out
    finally:
        if own:
            c.close()


def _ensure_ready(conn) -> None:
    if not _table_exists(conn):
        ensure_schema(conn)


# --------------------------------------------------------------------------- 仲裁 R1–R4
_VERDICT_ALIASES = {
    "fail": "fail", "failed": "fail", "violation": "fail", "violated": "fail",
    "nonconformity": "fail", "non_conformity": "fail", "不满足": "fail",
    "pass": "pass", "passed": "pass", "comply": "pass", "compliant": "pass",
    "satisfied": "pass", "通过": "pass",
    "na": "na", "n/a": "na", "not_applicable": "na", "notapplicable": "na",
    "不适用": "na",
    "insufficient": "insufficient", "evidence_insufficient": "insufficient",
    "证据不足": "insufficient",
    "unknown": "unknown", "unexecuted": "unknown", "未执行": "unknown",
    "无法判断": "unknown",
}
_NON_VERDICT_STATUS = frozenset({"pending", "reviewed", "confirmed", "superseded",
                                 "published", "draft"})


def five_state_of(finding: dict | None) -> str:
    """平台 finding → 五态结论（fail/pass/na/insufficient/unknown；无结论返回 ''）。

    先读 ``state``（五态唯一事实源），再读 ``d5_status``/``verdict``/``status``；
    ``status='pending'`` 等流程状态不当作判定。
    """
    if not isinstance(finding, dict):
        return ""
    for key in ("state", "d5_status", "verdict", "conclusion", "status"):
        raw = _norm(finding.get(key))
        if not raw:
            continue
        if raw in _VERDICT_ALIASES:
            return _VERDICT_ALIASES[raw]
        if raw in _NON_VERDICT_STATUS:
            continue
    return ""


def executor_kind(executor) -> str:
    """D4 子判据执行器名 → ``deterministic | semantic | unknown``（fail-closed）。

    真实 ``tool_trace.executor`` 不是裸名而是「族名.算子」（如 ``ruleexec.limit`` /
    ``ruleexec.applicability`` / ``decision_table`` / ``agent-judge``），因此按
    「完全相同 或 以 <白名单名>. / <白名单名>: 开头」匹配；两套白名单都未命中 →
    ``unknown``（未知执行器不得当作确定性）。
    """
    ex = _norm(executor)
    if not ex:
        return "unknown"
    for name in SEMANTIC_EXECUTORS:
        if ex == name or ex.startswith(name + ".") or ex.startswith(name + ":"):
            return "semantic"
    for name in DETERMINISTIC_EXECUTORS:
        if ex == name or ex.startswith(name + ".") or ex.startswith(name + ":"):
            return "deterministic"
    return "unknown"


def _finding_d4_subs(finding: dict) -> list:
    """finding 内嵌的 D4 子判据（调用方已带证据时优先用，免查库；兼容多种形状）。"""
    f = finding if isinstance(finding, dict) else {}
    for key in ("d4_subs", "d4subs"):
        val = f.get(key)
        if isinstance(val, list) and val:
            return val
    d4 = f.get("d4")
    if isinstance(d4, dict) and isinstance(d4.get("subs"), list) and d4.get("subs"):
        return list(d4["subs"])
    val = f.get("subs")
    if isinstance(val, list) and val:
        return list(val)
    # 单子判据形态：finding 本身带 tool_trace（例如直连/诊断载荷）
    if isinstance(f.get("tool_trace"), dict) and f["tool_trace"].get("executor"):
        return [f]
    return []


def _load_manifest_d4_subs(finding: dict) -> dict:
    """只读回查本轮 D4 子判据：finding.manifest_result_id → manifest_result.d4_json。

    只读、不写库；任何异常都 fail-closed（``ok=False``），不抛到仲裁调用方。
    """
    f = finding if isinstance(finding, dict) else {}
    rid = str(f.get("manifest_result_id") or f.get("result_id") or "")
    if not rid:
        fid = str(f.get("id") or "")
        if not fid:
            return {"ok": False, "reason": "no_finding_id", "result_id": ""}
        try:
            row = R.findings.get(fid) or {}
        except Exception:  # noqa: BLE001 - 查不到 finding 只影响确定性判定
            LOGGER.warning("shadow_pool manifest finding lookup failed id=%s", fid,
                           exc_info=True)
            return {"ok": False, "reason": "finding_lookup_error", "result_id": ""}
        rid = str((row or {}).get("manifest_result_id") or "")
    if not rid:
        return {"ok": False, "reason": "no_manifest_result_id", "result_id": ""}
    try:
        conn = db.connect()
        try:
            row = conn.execute("SELECT d4_json FROM manifest_result WHERE id=?",
                               (rid,)).fetchone()
        finally:
            conn.close()
    except Exception:  # noqa: BLE001 - 结果表不可读 → 不能判确定性
        LOGGER.warning("shadow_pool manifest_result lookup failed id=%s", rid,
                       exc_info=True)
        return {"ok": False, "reason": "manifest_result_lookup_error", "result_id": rid}
    if not row:
        return {"ok": False, "reason": "manifest_result_missing", "result_id": rid}
    d4 = _loads(row["d4_json"], {})
    subs = d4.get("subs") if isinstance(d4, dict) else []
    return {"ok": True, "reason": "loaded", "result_id": rid,
            "d4_status": str((d4 or {}).get("status") or "") if isinstance(d4, dict) else "",
            "subs": list(subs or [])}


def manifest_dag_determinism(finding: dict | None) -> dict:
    """manifest-dag finding 的确定性判定（唯一口径，供 deterministic_of/测试复用）。

    口径（不可放宽）：本次 DAG 结果里**所有实际执行的子判据**执行器都必须是确定性
    算子；只要有一条语义判据（或无法识别执行器）→ 非确定性。空子判据 = 无法证明
    确定性（fail-closed）。
    """
    f = finding if isinstance(finding, dict) else {}
    subs = _finding_d4_subs(f)
    source = "finding"
    result_id = str(f.get("manifest_result_id") or f.get("result_id") or "")
    if not subs:
        loaded = _load_manifest_d4_subs(f)
        result_id = str(loaded.get("result_id") or result_id or "")
        if not loaded.get("ok"):
            return {"deterministic": False, "reason": "manifest_dag_unverified:" +
                    str(loaded.get("reason") or ""), "source": "none",
                    "result_id": result_id, "sub_count": 0, "executors": [],
                    "deterministic_executors": [], "semantic_executors": [],
                    "unknown_executors": []}
        subs = loaded.get("subs") or []
        source = "manifest_result"
    executors, det, sem, unk = [], [], [], []
    for sub in subs:
        sub = sub if isinstance(sub, dict) else {}
        tt = sub.get("tool_trace") if isinstance(sub.get("tool_trace"), dict) else {}
        ex = str(tt.get("executor") or tt.get("tool")
                 or sub.get("executor") or sub.get("method") or "").strip()
        kind = executor_kind(ex)
        executors.append(ex)
        if kind == "deterministic":
            det.append(ex)
        elif kind == "semantic":
            sem.append(ex)
        else:
            unk.append(ex)
    is_det = bool(det) and not sem and not unk
    if not subs:
        reason = "manifest_dag_no_subs"
    elif sem:
        reason = "manifest_dag_has_semantic:" + ",".join(sorted(set(sem)))
    elif unk:
        reason = "manifest_dag_unknown_executor:" + ",".join(sorted(set(str(x) for x in unk)))
    elif is_det:
        reason = "manifest_dag_all_deterministic"
    else:
        reason = "manifest_dag_no_deterministic_executor"
    return {"deterministic": bool(is_det), "reason": reason, "source": source,
            "result_id": result_id, "sub_count": len(subs),
            "executors": executors,
            "deterministic_executors": sorted(set(det)),
            "semantic_executors": sorted(set(sem)),
            "unknown_executors": sorted(set(str(x) for x in unk))}


def deterministic_of(finding: dict | None) -> dict:
    """平台 finding 是否确定性执行器给出（对齐 audit_zone/accuracy_shadow 口径）。

    ``engine=manifest-dag`` 额外走 :func:`manifest_dag_determinism`：DAG 子判据全确定性
    才算确定性；含语义/未知执行器或无 D4 证据 → 非确定性（不得一刀切）。
    """
    f = finding if isinstance(finding, dict) else {}
    engine = _norm(f.get("engine") or f.get("executor")
                   or f.get("deterministic_executor"))
    method = _norm(f.get("method") or f.get("execution_kind"))
    explicit = f.get("deterministic")
    evidence_source = _norm(f.get("evidence_source") or f.get("origin"))
    certainty = _norm(f.get("certainty"))
    manifest_dag = None
    if explicit is not None:
        det = bool(explicit)
        why = "explicit"
    elif engine or method:
        det = (engine in DETERMINISTIC_EXECUTORS or method in DETERMINISTIC_EXECUTORS)
        why = f"engine={engine or '-'}/method={method or '-'}"
    else:
        det = bool(evidence_source in ("deterministic", "executor", "ruleexec")
                   or certainty == "certain")
        why = f"evidence_source={evidence_source or '-'}/certainty={certainty or '-'}"
    if engine == MANIFEST_DAG_ENGINE or method == MANIFEST_DAG_ENGINE:
        # manifest-dag 是聚合门：显式 deterministic 标记不采信，只认 D4 子判据执行器集合。
        manifest_dag = manifest_dag_determinism(f)
        det = bool(manifest_dag["deterministic"])
        why = "manifest-dag:" + str(manifest_dag["reason"])
        _dag_ex = manifest_dag.get("deterministic_executors") or []
        if det and _dag_ex:
            # 把实际执行器集合写进理由（仲裁审计/复核可追溯，不只看一个布尔）
            why += "(" + ",".join(str(x) for x in _dag_ex) + ")"
    if det and (engine in SEMANTIC_EXECUTORS or method in SEMANTIC_EXECUTORS):
        det = False
        why = f"semantic_executor={engine or method}"
    out = {"deterministic": bool(det), "engine": engine, "method": method,
           "certainty": certainty, "why": why}
    if manifest_dag is not None:
        out["manifest_dag"] = manifest_dag
    return out


def anchor_state(finding: dict | None) -> dict:
    """引文锚定状态（复用 visibility_policy.evidence_state 的证据契约判定）。

    - 显式 ``quote_check`` / ``evidence_verified`` / ``anchor_ids`` 直接采信；
    - 计算/关系/缺失类证据按 evidence_kind 走既有契约；
    - 无法核验/无定位 → anchored=False（只能进影子，不能进正式结论）。
    """
    f = finding if isinstance(finding, dict) else {}
    kind = str(f.get("evidence_kind") or "quote")
    quote = str(f.get("quote") or f.get("excerpt") or "").strip()
    candidate = {
        "evidence_kind": kind,
        "quote_check": f.get("quote_check") or {},
        "evidence_verified": f.get("evidence_verified"),
        "missing_proof_verified": f.get("missing_proof_verified"),
        "computation_verified": f.get("computation_verified"),
        "relation_verified": f.get("relation_verified"),
        "anchor_ids": f.get("anchor_ids") or [],
        "locator": f.get("locator") or f.get("location_hint") or "",
        "locator_present": f.get("locator_present"),
    }
    if not candidate["quote_check"] and f.get("quote"):
        # 调用方只给了 quote 文本：有 quote + anchor/offset 才算锚定（不默认命中）
        if f.get("offset") is not None or f.get("line") is not None:
            candidate["quote_check"] = {"status": "exact",
                                        "offset": f.get("offset"),
                                        "line": f.get("line")}
        elif f.get("anchor_ids"):
            candidate["quote_check"] = {"status": "exact"}
    if not candidate["quote_check"] and not quote and not candidate["anchor_ids"]:
        if not any(f.get(k) is not None for k in ("evidence_verified", "missing_proof_verified",
                                                  "computation_verified", "relation_verified")):
            return {"anchored": False, "verified": False, "reason_code": "no_evidence",
                    "evidence_src": "missing", "quote_match_status": "",
                    "weak_locator": False}
    try:
        ev = VP.evidence_state(candidate)
    except Exception:  # noqa: BLE001
        LOGGER.warning("shadow_pool evidence_state failed", exc_info=True)
        return {"anchored": False, "verified": False, "reason_code": "evidence_state_error",
                "evidence_src": "", "quote_match_status": "", "weak_locator": False}
    return {"anchored": bool(ev.get("verified")), "verified": bool(ev.get("verified")),
            "reason_code": ev.get("reason_code") or "",
            "evidence_src": ev.get("evidence_src") or "",
            "quote_match_status": ev.get("quote_match_status") or "",
            "weak_locator": bool(ev.get("weak_locator"))}


def _direct_risk(direct_finding: dict | None) -> dict:
    if not isinstance(direct_finding, dict):
        return {"risk_level": "", "high_risk": False, "derived_from": "none"}
    try:
        return VP.resolve_risk(direct_finding)
    except Exception:  # noqa: BLE001
        return {"risk_level": "", "high_risk": False, "derived_from": "error"}


def _pick_confidence(platform_finding: dict | None, direct_finding: dict | None):
    """影子置信度：优先取“70–80% 拿不准”的中等置信；无值返回 None。"""
    for side in (direct_finding, platform_finding):
        if not isinstance(side, dict):
            continue
        conf = _clamp_confidence(side.get("confidence"))
        if conf is not None:
            return conf
        suspicion = _clamp_confidence(side.get("suspicion_confidence"))
        if suspicion is not None:
            return suspicion
    return None


def _looks_platform(finding: dict) -> bool:
    if not isinstance(finding, dict) or not finding:
        return False
    return any(k in finding for k in ("state", "engine", "certainty", "rule_id",
                                      "rule_code", "executor", "d5_status"))


def _as_platform_candidate(finding: dict | None) -> dict:
    f = finding if isinstance(finding, dict) else {}
    return {
        "rule_code": f.get("rule_code") or f.get("rule_id") or "",
        "engine": f.get("engine") or f.get("executor") or "",
        "method": f.get("method") or "",
        "certainty": f.get("certainty") or "",
        "confidence": f.get("confidence"),
        "severity": f.get("severity"),
        "risk_level": f.get("risk_level"),
        "evidence_kind": f.get("evidence_kind") or "quote",
        "quote_check": f.get("quote_check") or {},
        "quote": f.get("quote") or f.get("excerpt") or "",
        "anchor_ids": f.get("anchor_ids") or [],
        "locator_present": f.get("locator_present"),
        "deterministic": f.get("deterministic"),
        # 反证证据随候选传递（refutation_state 需要，执行器名不算证据）
        "deterministic_refuted": f.get("deterministic_refuted"),
        "refute_evidence": f.get("refute_evidence") or {},
        "refuter": f.get("refuter") or "platform",
    }


def _classification(*, zone: str, zone_source: str, rule: str, reason: str = "",
                    formal_verdict: str = "", confidence=None, rationale: str = "",
                    platform: dict | None = None, direct: dict | None = None,
                    extra: dict | None = None) -> dict:
    out = {
        "ok": True,
        "zone": zone,
        "zone_source": zone_source,
        "shadow_reason": reason,
        "shadow_reason_label": REASON_LABELS.get(reason, reason),
        "shadow_confidence": _clamp_confidence(confidence),
        "rule": rule,
        "formal_verdict": formal_verdict,
        "enters_formal": zone == ZONE_FORMAL,
        "enters_shadow": zone == ZONE_SHADOW,
        "discarded": zone == ZONE_DISCARDED,
        "needs_review": zone in (ZONE_SHADOW, ZONE_DISCARDED),
        "rationale": rationale,
        "platform": platform or {},
        "direct": direct or {},
        "no_gold": True,
        "not_gold": True,
        "report": {
            "in_formal_report": zone == ZONE_FORMAL,
            "counted_in_pass_rate_denominator": zone == ZONE_FORMAL,
            "shown_as_shadow_hint": zone == ZONE_SHADOW,
            "audit_only": zone == ZONE_DISCARDED,
        },
    }
    out.update(extra or {})
    return out


def classify(finding_like: dict | None, platform_finding: dict | None = None,
             direct_finding: dict | None = None) -> dict:
    """三区仲裁（纯函数，不落库、不写审计）：输入候选 → 分区结论。

    参数
    ----
    finding_like : dict|None
        待仲裁的候选。若未显式给 ``platform_finding`` 且它“像平台 finding”
        （含 state/engine/certainty/rule_* 之一），则视为平台侧候选。
    platform_finding : dict|None
        平台侧 finding（五态 + 引文/执行器信息；``state`` 为五态事实源）。
    direct_finding : dict|None
        直连侧 finding（rule_code/quote/confidence/risk_level…）。

    规则（R1–R4）
    -----------
    R1 平台确定性执行器 fail 且引文锚定 → formal（source=platform；直连也产出则 both）。
    R2 直连有 finding，而平台确定性 pass 且证据锚定 → discarded（direct_false_positive，
       留痕）；**高风险直连项不直接丢弃**，降为 shadow(conflict)（critical 不自动隐藏）。
    R3 任一方产出但无法确定性确认 → shadow（direct_suspect / platform_unsure / conflict）。
    R4 平台确定性 pass 且直连无 finding（或双方都无产出）→ formal(pass)。

    返回
    ----
    dict：``zone``/``zone_source``/``shadow_reason``/``shadow_confidence``/``rule``/
    ``formal_verdict``/``enters_formal``/... + ``report`` 报告口径标记 + ``no_gold``。
    **本函数不是 gold 判定**：shadow/discarded 都需要人工/确定性复核闭环。
    """
    finding_like = dict(finding_like or {}) if isinstance(finding_like, dict) else {}
    platform_finding = (dict(platform_finding) if isinstance(platform_finding, dict)
                        else None)
    direct_finding = (dict(direct_finding) if isinstance(direct_finding, dict) else None)
    if platform_finding is None and _looks_platform(finding_like):
        platform_finding = finding_like

    p_verdict = five_state_of(platform_finding) if platform_finding else ""
    p_det = deterministic_of(platform_finding) if platform_finding else {
        "deterministic": False, "why": "no_platform_finding"}
    p_anchor = anchor_state(platform_finding) if platform_finding else {
        "anchored": False, "reason_code": "no_platform_finding"}
    d_risk = _direct_risk(direct_finding)
    platform_info = {"verdict": p_verdict, "deterministic": bool(p_det["deterministic"]),
                     "deterministic_why": p_det["why"],
                     "anchored": bool(p_anchor["anchored"]),
                     "anchor_reason": p_anchor.get("reason_code") or ""}
    if p_det.get("manifest_dag"):
        # manifest-dag 的确定性证据（D4 子判据执行器集合）随仲裁结论留痕，便于复核。
        platform_info["manifest_dag"] = p_det["manifest_dag"]
    direct_info = {"present": bool(direct_finding),
                   "risk_level": d_risk.get("risk_level") or "",
                   "high_risk": bool(d_risk.get("high_risk")),
                   "risk_derived_from": d_risk.get("derived_from") or ""}
    confidence = _pick_confidence(platform_finding, direct_finding)

    # ---- R1：平台确定性 fail + 引文锚定 → 正式结论（不因直连没报而丢）
    if platform_finding and p_det["deterministic"] and p_verdict == "fail" and p_anchor["anchored"]:
        zone_source = "both" if direct_finding else "platform"
        return _classification(
            zone=ZONE_FORMAL, zone_source=zone_source, rule="R1",
            formal_verdict="fail", confidence=confidence,
            rationale=("R1：平台确定性执行器 fail（" + p_det["why"] + "）且引文锚定（"
                       + str(p_anchor.get("reason_code") or "") + "）→ 正式结论 fail"
                       + ("；直连亦产出（both）" if direct_finding else "")),
            platform=platform_info, direct=direct_info)

    # ---- R2：直连 finding 被平台确定性 pass 证伪 → discarded（留痕）
    if (direct_finding and platform_finding and p_det["deterministic"]
            and p_verdict == "pass" and p_anchor["anchored"]):
        if direct_info["high_risk"]:
            return _classification(
                zone=ZONE_SHADOW, zone_source="both", rule="R2",
                reason=REASON_CONFLICT, confidence=confidence,
                rationale=("R2 保护：直连项被平台确定性 pass 证伪，但直连风险="
                           + str(direct_info["risk_level"])
                           + "（高风险不自动丢弃，critical 不自动隐藏）→ 影子/冲突待人工"),
                platform=platform_info, direct=direct_info,
                extra={"discard_blocked_reason": "high_risk_refute_guard"})
        return _classification(
            zone=ZONE_DISCARDED, zone_source="arbiter", rule="R2",
            reason=REASON_DIRECT_FALSE_POSITIVE, confidence=confidence,
            rationale=("R2：平台确定性执行器 pass（" + p_det["why"] + "）且证据锚定（"
                       + str(p_anchor.get("reason_code") or "")
                       + "）证伪直连 finding → discarded 留痕（direct_false_positive，"
                         "不静默删除；审计可查）"),
            platform=platform_info, direct=direct_info)

    # ---- R4：平台确定性 pass 且直连无 finding → formal(pass)
    if platform_finding and p_det["deterministic"] and p_verdict == "pass" and not direct_finding:
        return _classification(
            zone=ZONE_FORMAL, zone_source="platform", rule="R4",
            formal_verdict="pass", confidence=confidence,
            rationale=("R4：平台确定性执行器 pass（" + p_det["why"] + "）且直连无 finding "
                       "→ 正式结论 pass"),
            platform=platform_info, direct=direct_info)
    if not platform_finding and not direct_finding:
        return _classification(
            zone=ZONE_FORMAL, zone_source="platform", rule="R4",
            formal_verdict="pass", rationale="R4：平台无 finding 且直连无 finding → pass",
            platform=platform_info, direct=direct_info)

    # ---- R3：任一方产出但无法确定性确认 → shadow
    if platform_finding and direct_finding:
        if p_verdict == "pass":
            reason = REASON_CONFLICT
            why = "平台给出 pass（非确定性/无锚定），直连有 finding → 双方冲突"
        elif p_verdict == "fail":
            reason = REASON_PLATFORM_UNSURE
            why = "双方都产出，但平台非确定性执行器 → 平台拿不准"
        else:
            reason = REASON_DIRECT_SUSPECT
            why = ("平台结论=" + (p_verdict or "无/待定")
                   + "（不足以锚定），直连有 finding → 直连疑似")
        zone_source = "both"
    elif platform_finding:
        reason = REASON_PLATFORM_UNSURE
        why = ("平台产出但无法确定性确认（verdict=" + (p_verdict or "无")
               + "，deterministic=" + str(bool(p_det["deterministic"]))
               + "，anchored=" + str(bool(p_anchor["anchored"])) + "）")
        zone_source = "platform"
    else:
        reason = REASON_DIRECT_SUSPECT
        why = "直连产出 finding，平台无 finding/无确定性确认 → 直连疑似"
        zone_source = "direct"
    # 已尝试反证但不可核验 → 明确 conflict（反证不可核验不得作丢弃/隐藏依据）
    if platform_finding and platform_finding.get("deterministic_refuted"):
        try:
            refute = VP.refutation_state(_as_platform_candidate(platform_finding))
        except Exception:  # noqa: BLE001
            refute = {"attempted": True, "verified": False}
        if refute.get("attempted") and not refute.get("verified"):
            reason = REASON_CONFLICT
            why = ("反证不可核验（" + str(refute.get("unverified_reason") or "")
                   + "；执行器名不算证据）→ 影子/冲突待人工")
    return _classification(
        zone=ZONE_SHADOW, zone_source=zone_source, rule="R3", reason=reason,
        confidence=confidence,
        rationale="R3：" + why + " → 影子池（可能误报也可能真问题，需人工裁决/二次复核）",
        platform=platform_info, direct=direct_info)


# --------------------------------------------------------------------------- to_shadow
def _finding_payload(finding: dict, conn=None) -> tuple[dict, dict]:
    """平台 finding 行 → (claim, evidence)（含 evidence 锚点，用于引文锚定/留痕）。"""
    fid = str(finding.get("id") or "")
    evidence = {"anchor_ids": [], "items": []}
    if conn is not None and fid and _table_exists(conn, "evidence"):
        try:
            rows = conn.execute(
                "SELECT anchor_id, excerpt, label, document_id FROM evidence "
                "WHERE finding_id=?", (fid,)).fetchall()
            rows = [dict(r) for r in rows]
            evidence["items"] = [{"anchor_id": str(r.get("anchor_id") or ""),
                                  "excerpt": str(r.get("excerpt") or "")[:500],
                                  "label": str(r.get("label") or "")[:120],
                                  "document_id": str(r.get("document_id") or "")}
                                 for r in rows][:20]
            evidence["anchor_ids"] = [r["anchor_id"] for r in rows
                                      if str(r.get("anchor_id") or "")]
            evidence["excerpt"] = (str(rows[0].get("excerpt") or "")[:500] if rows else "")
        except Exception:  # noqa: BLE001
            LOGGER.warning("shadow_pool evidence load failed finding=%s", fid, exc_info=True)
    claim = {
        "rule_code": finding.get("rule_code") or finding.get("rule_id") or "",
        "object_id": str(finding.get("object_id") or finding.get("point_id") or ""),
        "subject": str(finding.get("title") or "")[:300],
        "issue_type": str(finding.get("category") or finding.get("type") or "")[:120],
        "severity": str(finding.get("severity") or ""),
        "risk_level": str(finding.get("risk_level") or ""),
        "quote": str(finding.get("quote") or evidence.get("excerpt") or "")[:500],
        "confidence": finding.get("confidence"),
        "engine": str(finding.get("engine") or ""),
        "state": str(finding.get("state") or ""),
        "status": str(finding.get("status") or ""),
        "run_id": str(finding.get("run_id") or ""),
        "finding_id": fid,
    }
    return _strip_forbidden(claim), evidence


def _direct_payload(item: dict) -> tuple[dict, dict]:
    claim = {
        "rule_code": item.get("rule_code") or "",
        "object_id": str(item.get("object_id") or ""),
        "subject": str(item.get("subject") or "")[:300],
        "issue_type": str(item.get("issue_type") or "")[:120],
        "quote": str(item.get("quote") or "")[:500],
        "confidence": item.get("confidence"),
        "engine": "direct",
        "source": "direct",
        "direct_item_id": str(item.get("id") or ""),
    }
    evidence = {"anchor_ids": [], "items": [],
                # 证据归属（P1-7）：直连引文来自哪一份文档必须随证据留痕，不能缺省成第一份。
                "document_id": str(item.get("document_id") or item.get("object_id") or ""),
                "filename": str(item.get("filename") or item.get("document_filename") or "")[:200],
                "offset": item.get("quote_offset"), "line": item.get("quote_line"),
                "quote_match_status": item.get("quote_match_status") or ""}
    return _strip_forbidden(claim), evidence


def _shadow_item_key(*, case_id: str, zone: str, source: str, ref: str,
                     rule_code: str, quote: str, reason: str,
                     claim_key: str = "") -> str:
    """影子项幂等键（唯一约束）。

    P1-7 Phase3 收尾：直连发现传入 ``claim_key``（sha256(case|rule|归一quote)，
    不含 run_id）时用它替代会随轮次变化的 ``ref``（direct_item id），
    从而同一问题跨轮**可复算**地命中同一 item_key → 不会重复留痕。
    """
    raw = "|".join([str(case_id or ""), str(zone or ""), str(source or ""),
                    str(claim_key or ref or ""), str(rule_code or ""),
                    _sha256_text(str(quote or "")), str(reason or "")])
    return _sha256_text(raw)


def _public_item(row: dict) -> dict:
    """单条影子项输出（白名单；绝不含 gold/auto_label）。"""
    claim = _loads(row.get("claim_json"), {})
    evidence = _loads(row.get("evidence_json"), {})
    purged = bool(str(row.get("purged_at") or "").strip())
    status = str(row.get("shadow_status") or STATUS_PENDING)
    return {
        "id": str(row.get("id") or ""),
        "case_id": str(row.get("case_id") or ""),
        "zone": str(row.get("zone") or ""),
        "zone_source": str(row.get("zone_source") or ""),
        "zone_source_label": ZONE_SOURCE_LABELS.get(str(row.get("zone_source") or ""),
                                                    str(row.get("zone_source") or "")),
        "shadow_reason": str(row.get("shadow_reason") or ""),
        "shadow_reason_label": REASON_LABELS.get(str(row.get("shadow_reason") or ""),
                                                 str(row.get("shadow_reason") or "")),
        "shadow_confidence": row.get("shadow_confidence"),
        "shadow_round": int(row.get("shadow_round") or 1),
        "shadow_status": status,
        "shadow_status_label": STATUS_LABELS.get(status, status),
        "is_open": status in OPEN_STATUSES,
        "is_resolved": status in RESOLVED_STATUSES,
        "rule_code": str(row.get("rule_code") or ""),
        "object_id": str(row.get("object_id") or ""),
        "subject": str(row.get("subject") or claim.get("subject") or ""),
        "issue_type": str(row.get("issue_type") or ""),
        "severity": str(row.get("severity") or ""),
        "risk_level": str(row.get("risk_level") or "medium"),
        "platform_finding_id": str(row.get("platform_finding_id") or ""),
        "direct_item_id": str(row.get("direct_item_id") or ""),
        "comparison_item_id": str(row.get("comparison_item_id") or ""),
        "ledger_id": str(row.get("ledger_id") or ""),
        "claim": claim,
        "evidence": evidence,
        "claim_sha256": str(row.get("claim_sha256") or ""),
        "shadow_reviewed_by": str(row.get("shadow_reviewed_by") or ""),
        "shadow_reviewed_at": str(row.get("shadow_reviewed_at") or ""),
        "decision_note": str(row.get("decision_note") or ""),
        "shadow_escalated_at": str(row.get("shadow_escalated_at") or ""),
        "escalation_count": int(row.get("escalation_count") or 0),
        "default_disposition": str(row.get("default_disposition") or ""),
        "feedback_id": str(row.get("feedback_id") or ""),
        "revealed_before_decide": bool(row.get("revealed_before_decide")),
        "purged_at": str(row.get("purged_at") or ""),
        "purged_by": str(row.get("purged_by") or ""),
        "purged": purged,
        "created_at": str(row.get("created_at") or ""),
        "updated_at": str(row.get("updated_at") or ""),
        "warning": SHADOW_WARNING,
        "no_gold": True,
        "not_gold": True,
        "auto_threshold_change": False,
        "auto_training": False,
    }


def _load_item(conn, case_id: str, item_id: str) -> dict | None:
    if not item_id:
        return None
    try:
        row = conn.execute("SELECT * FROM shadow_item WHERE id=? AND case_id=?",
                           (str(item_id), str(case_id))).fetchone()
        return dict(row) if row else None
    except Exception:  # noqa: BLE001
        return None


def _insert_shadow(conn, *, case: dict, zone: str, zone_source: str, reason: str,
                   claim: dict, evidence: dict, claim_sha256: str, confidence,
                   source_ref: str, platform_finding_id: str = "",
                   direct_item_id: str = "", comparison_item_id: str = "",
                   ledger_id: str = "", run_id: str = "", actor: str = "",
                   created_at: str = "", claim_key: str = "") -> tuple[str, bool]:
    """INSERT OR IGNORE 影子行；返回 (item_id, created)。"""
    cid = str(case.get("id") or "")
    rule_code = str(claim.get("rule_code") or "")
    if claim_key:
        try:
            evidence = {**dict(evidence or {}), "claim_key": str(claim_key)}
        except Exception:  # noqa: BLE001
            pass
    item_key = _shadow_item_key(case_id=cid, zone=zone, source=zone_source,
                                ref=source_ref, rule_code=rule_code,
                                quote=str(claim.get("quote") or ""), reason=reason,
                                claim_key=str(claim_key or ""))
    exists = conn.execute("SELECT id FROM shadow_item WHERE item_key=?",
                          (item_key,)).fetchone()
    if exists:
        return str(exists["id"]), False
    item_id = db.new_id("shi_")
    stamp = created_at or _now()
    _insert_row(
        conn, SHADOW_TABLE,
        id=item_id, item_key=item_key, case_id=cid,
        run_id=str(run_id or case.get("last_run_id") or ""),
        tenant_id=str(case.get("tenant_id") or ""),
        workspace_id=str(case.get("workspace_id") or ""),
        zone=zone, zone_source=zone_source, shadow_reason=reason,
        shadow_confidence=_clamp_confidence(confidence),
        shadow_round=1, shadow_status=STATUS_PENDING,
        platform_finding_id=str(platform_finding_id or ""),
        direct_item_id=str(direct_item_id or ""),
        comparison_item_id=str(comparison_item_id or ""),
        ledger_id=str(ledger_id or ""),
        rule_code=rule_code,
        object_id=str(claim.get("object_id") or ""),
        subject=str(claim.get("subject") or ""),
        issue_type=str(claim.get("issue_type") or ""),
        severity=str(claim.get("severity") or ""),
        risk_level=str(claim.get("risk_level") or "medium"),
        claim_json=_canonical_json(claim),
        claim_sha256=claim_sha256,
        evidence_json=_canonical_json(evidence),
        refute_json="{}",
        no_gold=1, auto_threshold_change=0, auto_training=0,
        created_at=stamp, updated_at=stamp, immutable=1)
    return item_id, True


def to_shadow(finding_id, reason: str, confidence="", source: str = "", *,
              case_id: str = "", item: dict | None = None, run_id: str = "",
              actor: str = "system:shadow_pool", role: str = "",
              platform_finding: dict | None = None,
              direct_finding: dict | None = None,
              claim_key: str = "") -> dict:
    """把候选落库进影子池（shadow）或证伪留痕（discarded）+ 写审计。

    参数
    ----
    finding_id : str|dict
        平台 finding id / ``direct_item`` id / 或直接传候选 dict（配合 ``case_id``）。
    reason : str
        ``direct_suspect``/``platform_unsure``/``conflict`` → zone=shadow；
        ``direct_false_positive`` → zone=discarded（直连误报留痕）。
    confidence : float|""
    source : str
        ``direct|platform|both|arbiter``；缺省按数据来源推断。
    item / platform_finding / direct_finding : dict
        直连候选/平台候选显式载荷（无库里行时使用；仲裁链路推荐）。
    actor / role : str
        内部/系统调用默认 ``system:shadow_pool``；带人类角色时要求 ``shadow.decide``。

    幂等：同一 (case, zone, source, 引用, 规则码, 引文, reason) 重复调用返回已存在
    行且 ``created=False``，不重复写审计。直连发现传入 ``claim_key``（跨轮可复算
    的 (case, rule, 归一 quote) 哈希，不含 run_id）时，幂等键以 claim_key 取代
    会随轮次变化的 direct_item id。
    """
    reason = str(reason or "").strip()
    if reason not in SHADOW_REASONS:
        return _err(400, "invalid_shadow_reason",
                    f"非法影子理由：{reason}（可选：{', '.join(SHADOW_REASONS)}）",
                    allowed=list(SHADOW_REASONS))
    zone = ZONE_DISCARDED if reason == REASON_DIRECT_FALSE_POSITIVE else ZONE_SHADOW
    source_given = str(source or "").strip()
    if source_given and source_given not in ZONE_SOURCES:
        return _err(400, "invalid_zone_source",
                    f"非法来源：{source_given}（可选：{', '.join(ZONE_SOURCES)}）",
                    allowed=list(ZONE_SOURCES))
    resolved = _resolve_actor(actor, role)
    human = bool(str(actor or "").strip() and str(role or "").strip())
    if human and not _internal(actor, role):
        if not resolved.get("resolved"):
            return _err(401, "unauthenticated", "写影子项需要可解析的操作人身份")
        if str(resolved.get("role") or "") not in ("reviewer", "admin"):
            return _err(403, "forbidden", "当前角色不能写影子项")
        if str(resolved.get("role") or "") == "admin":
            return _err(403, "read_only_shadow_pool",
                        "业务管理员只读：不能写/裁决影子项（服务层强制）")

    with db.session() as conn:
        _ensure_ready(conn)
        base: dict = {}
        ref = ""
        platform_row = None
        direct_row = None
        target_case_id = str(case_id or "")
        # 1) 显式 item 载荷
        if item is not None and isinstance(item, dict):
            base = dict(item)
            if platform_finding is None and str(item.get("source") or "") == "platform":
                platform_finding = item
            if direct_finding is None and str(item.get("source") or "") == "direct":
                direct_finding = item
        # 2) finding 行（平台）
        fid = str(finding_id or "") if not isinstance(finding_id, dict) else ""
        if isinstance(finding_id, dict):
            base = dict(finding_id)
            if platform_finding is None:
                platform_finding = finding_id
        if fid:
            try:
                platform_row = R.findings.get(fid)
            except Exception:  # noqa: BLE001
                platform_row = None
            if platform_row:
                base = dict(platform_row)
                target_case_id = target_case_id or str(platform_row.get("case_id") or "")
                ref = fid
            else:
                direct_row = _load_direct_item(conn, fid)
                if direct_row:
                    base = dict(direct_row)
                    target_case_id = target_case_id or str(direct_row.get("case_id") or "")
                    ref = fid
                elif not base:
                    return _err(404, "not_found",
                                f"finding/direct_item 不存在：{finding_id}")
        if platform_finding is not None:
            base = {**base, **dict(platform_finding)}
        elif direct_finding is not None:
            base = {**base, **dict(direct_finding)}
        target_case_id = target_case_id or str(base.get("case_id") or "")
        if not target_case_id:
            return _err(400, "case_id_required", "写影子项必须能确定 case_id")
        case = R.cases.get(target_case_id)
        if not case:
            return _err(404, "not_found", "项目不存在")
        if human and not _internal(actor, role):
            case_access = _authorize_case(target_case_id, "review", actor, role)
            if not case_access.get("ok"):
                return _deny(case_access)
        # 组织 claim/evidence
        if platform_row:
            claim, evidence = _finding_payload(platform_row, conn)
            platform_fid = str(platform_row.get("id") or "")
            direct_item_id = ""
            if source_given in ("direct", "both") and direct_finding:
                d_claim, d_ev = _direct_payload(direct_finding)
                claim = {**claim, "direct": _strip_forbidden(d_claim)}
                evidence = {**evidence, "direct": _strip_forbidden(d_ev)}
        elif direct_row:
            # P1-7：直连条目落库行不带文档归属（direct_item 无 object_id 列），
            # 调用方显式传入 direct_finding 时用其覆盖（真实来源文档/quote_check 不回退）。
            claim, evidence = _direct_payload(
                {**dict(direct_row), **dict(direct_finding or {})})
            platform_fid = str(base.get("platform_finding_id") or "")
            direct_item_id = str(direct_row.get("id") or "")
        else:
            # 显式载荷（无库里行）
            if direct_finding is not None and platform_finding is None:
                claim, evidence = _direct_payload(direct_finding)
                platform_fid, direct_item_id = "", str(direct_finding.get("id") or "")
            else:
                payload = platform_finding or direct_finding or base
                claim, evidence = _finding_payload({**base, **dict(payload)}, conn)
                platform_fid = str(payload.get("id") or "") if platform_finding else ""
                direct_item_id = str(payload.get("id") or "") if (
                    platform_finding is None and direct_finding is not None) else ""
        source_eff = source_given or ("both" if (platform_finding and direct_finding)
                                      else "platform" if (platform_finding or platform_row)
                                      else "direct" if (direct_finding or direct_row)
                                      else "arbiter")
        if zone == ZONE_DISCARDED and not source_given:
            source_eff = "arbiter"
        if confidence in ("", None):
            confidence = _pick_confidence(platform_finding or base, direct_finding)
        claim_sha = _sha256_text(_canonical_json(claim))
        item_id, created = _insert_shadow(
            conn, case=case, zone=zone, zone_source=source_eff, reason=reason,
            claim=claim, evidence=evidence, claim_sha256=claim_sha,
            confidence=confidence, source_ref=ref or platform_fid or direct_item_id,
            platform_finding_id=platform_fid, direct_item_id=direct_item_id,
            comparison_item_id=str(base.get("comparison_item_id") or ""),
            ledger_id=str(base.get("ledger_id") or ""), run_id=run_id,
            actor=actor, claim_key=str(claim_key or ""))
        if created:
            _audit(conn, actor=actor or "system:shadow_pool", action=EVENT_ADDED,
                   obj=item_id, case=case,
                   after=json.dumps({"shadow_item_id": item_id, "case_id": target_case_id,
                                     "zone": zone, "zone_source": source_eff,
                                     "reason": reason,
                                     "platform_finding_id": platform_fid,
                                     "direct_item_id": direct_item_id,
                                     "claim_key": str(claim_key or ""),
                                     "claim_sha256": claim_sha,
                                     "no_gold": True}, ensure_ascii=False))
        row = conn.execute("SELECT * FROM shadow_item WHERE id=?", (item_id,)).fetchone()
        return _ok(item_id=item_id, item=_public_item(dict(row)) if row else {},
                   created=bool(created), idempotent=not bool(created),
                   zone=zone, zone_source=source_eff, reason=reason,
                   warning=SHADOW_WARNING, no_gold=True)


def _load_direct_item(conn, item_id: str) -> dict | None:
    if not item_id:
        return None
    try:
        if not _table_exists(conn, "direct_item"):
            return None
        row = conn.execute("SELECT * FROM direct_item WHERE id=?", (item_id,)).fetchone()
        return dict(row) if row else None
    except Exception:  # noqa: BLE001
        return None


# --------------------------------------------------------------------------- 权限 / 复核模式
def _view_access(case_id: str, actor: str = "", role: str = "") -> dict:
    if _internal(actor, role):
        return {"ok": True, "internal": True, "read_only": False,
                "can_review": False, "role": "", "actor": ""}
    access = _authorize_case(case_id, "view", actor, role)
    access["internal"] = False
    return access


def _decide_access(case_id: str, actor: str = "", role: str = "") -> dict:
    if _internal(actor, role):
        return {"ok": False, "status": 401, "code": "unauthenticated",
                "message": "裁决影子项必须记录 actor（写审计）"}
    access = _authorize_case(case_id, "review", actor, role)
    access["internal"] = False
    return access


def _export_access(case_id: str, actor: str = "", role: str = "") -> dict:
    if _internal(actor, role):
        return {"ok": False, "status": 401, "code": "unauthenticated",
                "message": "导出影子清单必须认证并具备 shadow.export 权限"}
    access = _authorize_case(case_id, "view", actor, role)
    if not access.get("ok"):
        return access
    role_eff = str(access.get("role") or role or "")
    if role_eff not in EXPORT_DEFAULT_ROLES:
        return {"ok": False, "status": 403, "code": "shadow_export_forbidden",
                "message": f"仅 {EXPORT_PERMISSION} 权限（默认业务管理员）可导出影子清单",
                "actor": access.get("actor") or actor, "role": role_eff}
    access["internal"] = False
    return access


def _review_mode_info(case_id: str) -> dict:
    """复用 human_review 复核模式（production/evaluation）与盲审锁定口径。"""
    try:
        from . import human_review as HR
        info = HR.review_mode_get(str(case_id or ""))
    except Exception:  # noqa: BLE001
        LOGGER.warning("shadow_pool review_mode_get failed case=%s", case_id,
                       exc_info=True)
        return {"mode": "production", "locked": False, "independent": {}}
    if not info.get("ok"):
        return {"mode": "production", "locked": False, "independent": {},
                "note": info.get("error") or ""}
    return {"mode": info.get("mode") or "production",
            "locked": bool(info.get("evaluation_locked")),
            "independent": info.get("independent") or {},
            "lock_hint": info.get("lock_hint") or ""}


# --------------------------------------------------------------------------- 读取
def _case_rows(conn, case: dict, *, include_purged: bool = False,
               include_discarded: bool = True) -> list[dict]:
    cid = str(case.get("id") or "")
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM shadow_item WHERE case_id=? ORDER BY created_at, rowid",
            (cid,)).fetchall()]
    except Exception:  # noqa: BLE001
        return []
    out = []
    for row in rows:
        if not _row_in_case_scope(case, row):
            continue
        if not include_purged and str(row.get("purged_at") or "").strip():
            continue
        if not include_discarded and str(row.get("zone") or "") == ZONE_DISCARDED:
            continue
        out.append(row)
    return out


def _summary(rows: list[dict]) -> dict:
    by_reason, by_source, by_status = {}, {}, {}
    shadow_rows = [r for r in rows if str(r.get("zone") or "") == ZONE_SHADOW]
    discarded = [r for r in rows if str(r.get("zone") or "") == ZONE_DISCARDED]
    for row in shadow_rows:
        reason = str(row.get("shadow_reason") or "")
        by_reason[reason] = by_reason.get(reason, 0) + 1
        source = str(row.get("zone_source") or "")
        by_source[source] = by_source.get(source, 0) + 1
        status = str(row.get("shadow_status") or STATUS_PENDING)
        by_status[status] = by_status.get(status, 0) + 1
    open_rows = [r for r in shadow_rows
                 if str(r.get("shadow_status") or STATUS_PENDING) in OPEN_STATUSES]
    high_open = [r for r in open_rows if str(r.get("risk_level") or "") in
                 ("critical", "high")]
    return {
        "total": len(shadow_rows),
        "zone_counts": {ZONE_SHADOW: len(shadow_rows), ZONE_DISCARDED: len(discarded),
                        ZONE_FORMAL: 0},
        "discarded": len(discarded),
        "open": len(open_rows),
        "pending": len(open_rows),
        "resolved": len([r for r in shadow_rows
                         if str(r.get("shadow_status") or "") in RESOLVED_STATUSES]),
        "confirmed": int(by_status.get(STATUS_CONFIRMED) or 0),
        "false_positive": int(by_status.get(STATUS_FALSE_POSITIVE) or 0),
        "unsure": int(by_status.get(STATUS_UNSURE) or 0),
        "skipped": int(by_status.get(STATUS_SKIPPED) or 0),
        "escalated": int(by_status.get(STATUS_ESCALATED) or 0),
        "high_risk_open": len(high_open),
        "by_reason": by_reason,
        "by_source": by_source,
        "by_status": by_status,
        "default_closed": len([r for r in shadow_rows
                               if str(r.get("default_disposition") or "")]),
    }


def shadow_items(case_id: str, *, reveal: bool = False, role: str = "", actor: str = "",
                 reason: str = "", status: str = "", include_purged: bool = False,
                 via: str = "service") -> dict:
    """影子项列表（默认只返回 N/汇总；reveal=True 才返回明细并写审计）。

    权限/盲审语义与 ``human_review.hidden_items`` 一致：
    - 默认关闭：只给 N 与提示（“可能误报也可能真问题”），不下发明细；
    - reveal=True：需 ``shadow.view`` + actor（写 ``shadow.revealed`` 审计）；
    - evaluation（盲审）模式提交独立复核前：N 也不显示，reveal 返回 403
      ``evaluation_locked``（防止把影子项当成自己发现的，污染人工 gold）。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _view_access(cid, actor, role)
    if not access.get("ok"):
        return _deny(access)
    actor_eff = str(access.get("actor") or actor or "").strip()
    role_eff = str(access.get("role") or role or "")
    internal = bool(access.get("internal"))
    mode_info = _review_mode_info(cid)
    locked = bool(mode_info.get("locked"))
    if reveal and locked:
        return _err(403, "evaluation_locked",
                    "评测/盲审模式：提交独立复核前不显示影子项数量与内容，也不允许裁决"
                    "（防止把影子项当成自己发现的，污染人工 gold）",
                    mode=mode_info.get("mode"))
    if reveal and internal:
        return _err(401, "unauthenticated",
                    "打开影子池必须记录 actor（打开动作写审计）")
    status_filter = _norm(status)
    with db.session() as conn:
        _ensure_ready(conn)
        rows = _case_rows(conn, case, include_purged=include_purged)
        if reason:
            rows = [r for r in rows if str(r.get("shadow_reason") or "") == reason]
        if status_filter:
            rows = [r for r in rows if str(r.get("shadow_status") or "") == status_filter]
        summary = _summary(rows)
        revealed_count = 0
        if reveal:
            open_ids = [str(r.get("id") or "") for r in rows
                        if str(r.get("zone") or "") == ZONE_SHADOW
                        and str(r.get("shadow_status") or "") in OPEN_STATUSES]
            revealed_count = len(open_ids)
            _audit(conn, actor=actor_eff, action=EVENT_REVEALED, obj=cid, case=case,
                   after=json.dumps({"case_id": cid, "mode": mode_info.get("mode"),
                                     "reveal": True, "hidden_count": revealed_count,
                                     "item_ids": open_ids[:_MAX_ITEMS],
                                     "via": str(via or ""), "role": role_eff,
                                     "no_gold": True}, ensure_ascii=False))
            # 逐条“已展示未裁决”标记，供裁决耗时/展示率指标
            if open_ids:
                try:
                    conn.executemany(
                        "UPDATE shadow_item SET revealed_before_decide=1, updated_at=? "
                        "WHERE id=? AND shadow_status IN ('pending','skipped','unsure','escalated')",
                        [(_now(), i) for i in open_ids])
                except Exception:  # noqa: BLE001
                    LOGGER.warning("shadow reveal mark skipped case=%s", cid, exc_info=True)
        count_visible = not locked
        out_items = []
        if reveal:
            publics = [_public_item(r) for r in rows]
            out_items = [p for p in publics
                         if p["zone"] == ZONE_SHADOW and p["is_open"]]
            out_items += [p for p in publics
                          if p["zone"] == ZONE_SHADOW and p["is_resolved"]]
            out_items += [p for p in publics if p["zone"] == ZONE_DISCARDED]
        pending_n = summary["open"] if count_visible else None
    return _ok(case_id=cid, mode=mode_info.get("mode"),
               mode_label=("评测/盲审模式" if mode_info.get("mode") == "evaluation"
                           else "生产模式"),
               locked=locked,
               lock_reason=("评测/盲审模式提交独立复核前不显示影子项（防锚定）"
                            if locked else ""),
               reveal=bool(reveal), count_visible=count_visible,
               count=pending_n,
               hint=(SHADOW_HINT_TPL.format(n=pending_n) if count_visible else None),
               warning=SHADOW_WARNING,
               summary=({**summary, "pending": summary["open"]} if count_visible
                        else {**summary, "open": None, "pending": None,
                              "hidden_count": None}),
               items=out_items if reveal else [],
               permissions={"can_reveal": bool(not locked and not internal and actor_eff),
                            "can_decide": bool(not locked
                                               and str(role_eff) == "reviewer"
                                               and access.get("can_review")),
                            "can_export": str(role_eff) in EXPORT_DEFAULT_ROLES,
                            "read_only": bool(access.get("read_only")),
                            "role": role_eff, "actor": actor_eff,
                            "export_permission": EXPORT_PERMISSION},
               not_gold=True, no_gold=True)


def shadow_item(case_id: str, item_id: str, *, actor: str = "", role: str = "") -> dict:
    """单条影子项（需打开语义：读明细写 reveal 审计；权限同 shadow_items）。"""
    out = shadow_items(case_id, reveal=True, actor=actor, role=role, via="single")
    if not out.get("ok"):
        return out
    for item in out.get("items") or []:
        if str(item.get("id") or "") == str(item_id or ""):
            return _ok(case_id=str(case_id), item=item, warning=SHADOW_WARNING,
                       not_gold=True)
    return _err(404, "not_found", "影子项不存在或已归档")


# --------------------------------------------------------------------------- 裁决
def decide(case_id: str, item_id: str, action: str, *, actor: str = "",
           role: str = "", note: str = "") -> dict:
    """影子项人工裁决唯一写入口：确认真 / 确认误报 / 存疑 / 跳过。

    - 四动作 → 新状态 + feedback（confirm=正例；false_positive=反例卡；
      unsure=待补证；skip 不写 feedback 但**不丢弃**，仍进二次复核）；
    - 幂等：重复同动作返回 ``idempotent=True``，不重复写 feedback/审计，不 500；
    - 审计：``shadow.decided``（业务写与审计同事务）；
    - discarded 项只留痕不可裁决（409）；跨 case/不存在 404；
    - 权限：``shadow.decide`` = reviewer 本人项目；admin 403（服务层强制）。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _decide_access(cid, actor, role)
    if not access.get("ok"):
        return _deny(access)
    human_actor = str(access.get("actor") or actor or "").strip()
    if not human_actor:
        return _err(401, "unauthenticated", "裁决影子项必须记录 actor（写审计）")
    mode_info = _review_mode_info(cid)
    if mode_info.get("locked"):
        return _err(403, "evaluation_locked",
                    "评测/盲审模式：提交独立复核前不允许裁决影子项"
                    "（防止把影子项当成自己发现的，污染人工 gold）",
                    mode=mode_info.get("mode"))
    slug = ACTION_ALIASES.get(str(action or "").strip().lower())
    if not slug:
        return _err(400, "invalid_shadow_action",
                    f"非法影子项动作：{action}（可选：{', '.join(DECIDE_ACTIONS)}）",
                    allowed=list(DECIDE_ACTIONS))
    target_status = _ACTION_TO_STATUS[slug]
    feedback_kind = _ACTION_TO_FEEDBACK[slug]
    note = str(note or "").strip()[:_MAX_NOTE]
    with db.session() as conn:
        _ensure_ready(conn)
        row = _load_item(conn, cid, item_id)
        if not row:
            return _err(404, "not_found", "影子项不存在或不属于该项目")
        if not _row_in_case_scope(case, row):
            return _err(404, "not_found", "影子项不存在或不属于该项目")
        zone = str(row.get("zone") or "")
        if zone != ZONE_SHADOW:
            return _err(409, "discarded_not_decidable",
                        "已被确定性证伪（discarded）的项只留痕、不可裁决")
        current = str(row.get("shadow_status") or STATUS_PENDING)
        if current == target_status:
            return _ok(case_id=cid, item_id=str(row.get("id") or ""),
                       action=slug, status=current, idempotent=True,
                       changed=False, feedback_id=str(row.get("feedback_id") or ""),
                       message="重复裁决（幂等）：状态未变，未重复写审计/反馈",
                       item=_public_item(row), no_gold=True)
        # 打开后才能裁决（与 hidden 语义一致）：记录 reveal 台账基线
        revealed_before = bool(row.get("revealed_before_decide")) or _actor_revealed(
            conn, cid, human_actor)
        stamp = _now()
        round_no = int(row.get("shadow_round") or 1)
        # C5（评审 P0 第二批）：并发裁决 CAS。修复前 UPDATE 只按 id+case_id 定位，
        # 两个审核员同时分别 confirm / false_positive 时**都会成功**（都写 feedback、
        # 都写 shadow.decided），最终状态取决于最后提交者，先提交者的裁决被静默覆盖
        # 且无法发现。现在先做「写前值比对」抢占状态行（SQLite 单写锁保证只有一个
        # rowcount=1），抢不到就不写任何 feedback/审计，按事实返回幂等或 409。
        claim = conn.execute(
            "UPDATE shadow_item SET shadow_status=?, shadow_reviewed_by=?, "
            "shadow_reviewed_at=?, decision_note=?, "
            "revealed_before_decide=?, updated_at=? "
            "WHERE id=? AND case_id=? AND shadow_status=?",
            (target_status, human_actor, stamp, note,
             1 if revealed_before else 0, stamp, str(row.get("id") or ""), cid, current))
        if int(claim.rowcount or 0) != 1:
            fresh_row = _load_item(conn, cid, str(row.get("id") or "")) or {}
            fresh_status = str(fresh_row.get("shadow_status") or "")
            if fresh_status == target_status:
                return _ok(case_id=cid, item_id=str(row.get("id") or ""),
                           action=slug, status=fresh_status, idempotent=True,
                           changed=False,
                           feedback_id=str(fresh_row.get("feedback_id") or ""),
                           message="并发重复裁决（幂等）：状态已是目标值，未重复写审计/反馈",
                           item=_public_item(fresh_row or row), no_gold=True)
            return _err(409, "decision_conflict",
                        "裁决冲突：该影子项结论已被他人修改，请刷新后按当前结论重新裁决",
                        current={"status": fresh_status or current,
                                 "reviewed_by": str(fresh_row.get("shadow_reviewed_by") or ""),
                                 "note": str(fresh_row.get("decision_note") or "")})
        feedback_id = ""
        feedback_kind_eff = ""
        if feedback_kind:
            feedback_kind_eff = feedback_kind
            existing_fb = ""
            try:
                fb_rows = conn.execute(
                    "SELECT id FROM feedback WHERE case_id=? AND kind=? AND rule_code=? "
                    "AND payload LIKE ? ORDER BY created_at DESC LIMIT 5",
                    (cid, feedback_kind, str(row.get("rule_code") or ""),
                     f"%{str(row.get('id') or '')}%")).fetchall()
                for fb in fb_rows:
                    existing_fb = str(fb["id"] or "")
                    break
            except Exception:  # noqa: BLE001
                existing_fb = ""
            if existing_fb:
                feedback_id = existing_fb
            else:
                feedback_id = db.new_id("fb")
                payload = {
                    "source": "shadow_pool",
                    "shadow_item_id": str(row.get("id") or ""),
                    "case_id": cid,
                    "zone_source": str(row.get("zone_source") or ""),
                    "shadow_reason": str(row.get("shadow_reason") or ""),
                    "rule_code": str(row.get("rule_code") or ""),
                    "object_id": str(row.get("object_id") or ""),
                    "quote": str((_loads(row.get("claim_json"), {}) or {}).get("quote")
                                 or "")[:300],
                    "shadow_confidence": row.get("shadow_confidence"),
                    "human_action": slug,
                    "note": note,
                    "direct_item_id": str(row.get("direct_item_id") or ""),
                    "platform_finding_id": str(row.get("platform_finding_id") or ""),
                    # 自进化口径（不判也不丢；weak/非 gold；不自动调阈值/训练）
                    "to_evolution": True,
                    "label": ("true_positive" if slug == "confirm"
                              else "false_positive" if slug == "false_positive"
                              else "evidence_insufficient"),
                    "label_strength": ("strong_human" if slug in ("confirm",
                                                                  "false_positive")
                                       else "none_pending"),
                    "no_gold": True,
                    "auto_threshold_change": False,
                    "auto_training": False,
                    "via": "shadow_pool.decide",
                }
                _insert_row(
                    conn, "feedback", id=feedback_id, case_id=cid,
                    finding_id=str(row.get("platform_finding_id") or ""),
                    kind=feedback_kind, rule_code=str(row.get("rule_code") or ""),
                    title=f"影子池裁决：{ACTION_LABELS.get(slug, slug)}",
                    payload=json.dumps(payload, ensure_ascii=False),
                    actor=human_actor, created_at=_now(), rsi_status="pending")
            conn.execute("UPDATE shadow_item SET feedback_id=? WHERE id=? AND case_id=?",
                         (feedback_id, str(row.get("id") or ""), cid))
        _audit(conn, actor=human_actor, action=EVENT_DECIDED,
               obj=str(row.get("id") or ""), case=case,
               before=json.dumps({"status": current}, ensure_ascii=False),
               after=json.dumps({"case_id": cid, "action": slug,
                                 "before_status": current,
                                 "after_status": target_status,
                                 "shadow_round": round_no,
                                 "feedback_id": feedback_id,
                                 "feedback_kind": feedback_kind_eff,
                                 "role": str(access.get("role") or role or ""),
                                 "note": note,
                                 "no_gold": True}, ensure_ascii=False))
        fresh = conn.execute("SELECT * FROM shadow_item WHERE id=?",
                             (str(row.get("id") or ""),)).fetchone()
        item_public = _public_item(dict(fresh)) if fresh else _public_item(row)
    # 进化实时联动（阈值通知）在提交后调用，失败不影响裁决结果
    if feedback_kind_eff == "false_positive" and str(row.get("rule_code") or ""):
        try:
            from . import feedback as _fb
            _fb._live_link(str(row.get("rule_code") or ""), "false_positive",
                           human_actor)
        except Exception:  # noqa: BLE001
            LOGGER.warning("shadow decide live_link skipped", exc_info=True)
    formal_after = bool(
        feedback_kind_eff == "confirm"
        and str(row.get("platform_finding_id") or ""))
    return _ok(case_id=cid, item_id=str(row.get("id") or ""), action=slug,
               status=target_status, idempotent=False, changed=True,
               feedback_id=feedback_id, feedback_kind=feedback_kind_eff,
               shadow_round=round_no, item=item_public,
               formal_after=formal_after,
               report_excluded=not formal_after,
               message=("已确认真问题：平台 finding 回到正式口径；直连项待 Phase 2 "
                        "晋升为 finding" if slug == "confirm"
                        else "已判误报：写反例卡，进入自进化候选（不自动改阈值）"
                        if slug == "false_positive"
                        else "已存疑：进入二次复核队列（不丢弃）"
                        if slug == "unsure"
                        else "已跳过：不判断也不丢弃，仍进入二次复核队列"),
               warning=SHADOW_WARNING, no_gold=True, not_gold=True)


def _actor_revealed(conn, case_id: str, actor: str) -> bool:
    """该 actor 是否打开过影子池（审计基线；用于展示→裁决耗时指标）。"""
    try:
        row = conn.execute(
            "SELECT count(*) FROM audit_log WHERE action=? AND object=? AND actor=?",
            (EVENT_REVEALED, str(case_id or ""), str(actor or ""))).fetchone()
        return bool(int(row[0] or 0)) if row else False
    except Exception:  # noqa: BLE001
        return False


# --------------------------------------------------------------------------- 二次复核 / 归档
def escalate_pending(case_ids, rounds: int = DEFAULT_ESCALATION_ROUNDS,
                     older_than_hours: int = DEFAULT_ESCALATION_HOURS, *,
                     actor: str = "system:shadow_pool", role: str = "",
                     dry_run: bool = False) -> dict:
    """未裁决影子项 → 二次复核队列（不判也不丢；跑满轮次给 weak 默认处置）。

    - 候选：zone=shadow 且状态 ∈ pending/skipped/unsure/escalated（已裁决不转）；
    - 时间：距上次动作（创建/裁决/升级）≥ ``older_than_hours`` 才转（防止刷轮次）；
    - 轮次：``shadow_round < rounds`` → 轮次+1、状态 escalated、写 ``shadow.escalated``；
      已达 ``rounds`` → 给 weak 默认处置 ``suspected_false_positive``
      （``default_disposition``，非 gold、不自动改阈值/训练）并留痕，不删除；
    - 幂等：刚升级过的项时间基线刷新，连续调用不会重复升级/重复默认；
    - 权限：系统动作（内部 actor）；人类角色 403。
    """
    try:
        rounds = max(1, int(rounds))
        older_than_hours = max(0, int(older_than_hours))
    except (TypeError, ValueError):
        return _err(400, "invalid_escalation_config", "rounds/older_than_hours 必须为整数")
    if str(role or "").strip():
        return _err(403, "forbidden",
                    "二次复核升级是系统动作：不接受人类角色调用（服务层强制）",
                    role=str(role))
    if not str(actor or "").strip():
        return _err(401, "unauthenticated", "升级二次复核必须记录 actor（写审计）")
    if isinstance(case_ids, str):
        ids = [case_ids]
    else:
        ids = [str(x) for x in (case_ids or []) if str(x or "").strip()]
    if not ids:
        return _err(400, "case_ids_required", "必须提供至少一个 case_id")
    result = {"ok": True, "rounds": rounds, "older_than_hours": older_than_hours,
              "dry_run": bool(dry_run), "scanned": 0, "escalated": 0,
              "defaulted": 0, "skipped_recent": 0, "skipped_resolved": 0,
              "skipped_missing_case": [], "by_case": {}, "items": [],
              "no_gold": True, "default_disposition": DEFAULT_DISPOSITION}
    for cid in ids:
        case = _case(cid)
        if not case:
            result["skipped_missing_case"].append(cid)
            continue
        per = {"scanned": 0, "escalated": 0, "defaulted": 0,
               "skipped_recent": 0, "skipped_resolved": 0, "item_ids": []}
        with db.session() as conn:
            _ensure_ready(conn)
            rows = _case_rows(conn, case)
            now_epoch = _epoch(_now())
            for row in rows:
                if str(row.get("zone") or "") != ZONE_SHADOW:
                    continue
                status = str(row.get("shadow_status") or STATUS_PENDING)
                per["scanned"] += 1
                if status in RESOLVED_STATUSES:
                    per["skipped_resolved"] += 1
                    continue
                if status not in OPEN_STATUSES:
                    continue
                last_touch = str(row.get("shadow_escalated_at") or "") \
                    or str(row.get("shadow_reviewed_at") or "") \
                    or str(row.get("created_at") or "")
                stamp = _epoch(last_touch)
                age_hours = (0.0 if stamp is None else
                             max(0.0, (now_epoch - stamp) / 3600.0))
                if age_hours < older_than_hours:
                    per["skipped_recent"] += 1
                    continue
                round_no = int(row.get("shadow_round") or 1)
                item_id = str(row.get("id") or "")
                if round_no < rounds:
                    if not dry_run:
                        conn.execute(
                            "UPDATE shadow_item SET shadow_round=?, "
                            "shadow_escalated_at=?, escalation_count=escalation_count+1, "
                            "shadow_status=?, updated_at=? WHERE id=? AND case_id=?",
                            (round_no + 1, _now(), STATUS_ESCALATED, _now(),
                             item_id, cid))
                        _audit(conn, actor=actor, action=EVENT_ESCALATED, obj=item_id,
                               case=case,
                               before=json.dumps({"status": status,
                                                  "shadow_round": round_no},
                                                 ensure_ascii=False),
                               after=json.dumps({
                                   "case_id": cid, "action": "escalate",
                                   "shadow_round": round_no + 1,
                                   "max_rounds": rounds,
                                   "reason": "未裁决→二次复核（不判也不丢）",
                                   "no_gold": True}, ensure_ascii=False))
                    per["escalated"] += 1
                    per["item_ids"].append(item_id)
                else:
                    already_default = str(row.get("default_disposition") or "")
                    if already_default:
                        per["skipped_resolved"] += 1
                        continue
                    if not dry_run:
                        conn.execute(
                            "UPDATE shadow_item SET default_disposition=?, "
                            "shadow_escalated_at=?, updated_at=? "
                            "WHERE id=? AND case_id=?",
                            (DEFAULT_DISPOSITION, _now(), _now(), item_id, cid))
                        _audit(conn, actor=actor, action=EVENT_ESCALATED, obj=item_id,
                               case=case,
                               after=json.dumps({
                                   "case_id": cid, "action": "default_disposition",
                                   "shadow_round": round_no,
                                   "default_disposition": DEFAULT_DISPOSITION,
                                   "label_strength": "weak_default",
                                   "reason": ("二次复核轮次内仍无法确认：weak 默认处置"
                                              "（非 gold，不自动调阈值/训练，不删除）"),
                                   "no_gold": True}, ensure_ascii=False))
                    per["defaulted"] += 1
                    per["item_ids"].append(item_id)
        for key in ("scanned", "escalated", "defaulted", "skipped_recent",
                    "skipped_resolved"):
            result[key] += int(per.get(key) or 0)
        result["by_case"][cid] = per
        result["items"].extend(per["item_ids"])
    result["items"] = result["items"][:_MAX_ITEMS]
    return result


def purge(case_id: str = "", *, item_ids=None, actor: str = "system:shadow_pool",
          role: str = "", reason: str = "") -> dict:
    """影子项归档（shadow.purged）：只允许已裁决/丢弃项；不物理删除、不留静默丢弃。

    - pending 影子项**不允许归档**（未裁决不许消失，只能走二次复核）；
    - discarded / confirmed / false_positive 可归档（purged_at/purged_by 留痕，
      默认列表不再展示，审计可查）；
    - 权限：系统/运维动作；人类角色 403（服务层强制）。
    """
    if str(role or "").strip():
        return _err(403, "forbidden", "影子项归档是系统动作：不接受人类角色调用", role=str(role))
    if not str(actor or "").strip():
        return _err(401, "unauthenticated", "归档影子项必须记录 actor（写审计）")
    cid = str(case_id or "").strip()
    if not cid:
        return _err(400, "case_id_required", "必须提供 case_id")
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    ids = [str(x) for x in (item_ids or []) if str(x or "").strip()]
    stamps = _now()
    purged, blocked = [], []
    with db.session() as conn:
        _ensure_ready(conn)
        rows = _case_rows(conn, case, include_purged=True)
        for row in rows:
            item_id = str(row.get("id") or "")
            if ids and item_id not in ids:
                continue
            if str(row.get("purged_at") or "").strip():
                continue
            zone = str(row.get("zone") or "")
            status = str(row.get("shadow_status") or "")
            if zone == ZONE_SHADOW and status not in RESOLVED_STATUSES:
                blocked.append(item_id)
                continue
            conn.execute("UPDATE shadow_item SET purged_at=?, purged_by=?, updated_at=? "
                         "WHERE id=? AND case_id=?",
                         (stamps, actor, stamps, item_id, cid))
            purged.append(item_id)
            _audit(conn, actor=actor, action=EVENT_PURGED, obj=item_id, case=case,
                   after=json.dumps({"case_id": cid, "reason": str(reason or "")[:300],
                                     "zone": zone, "status": status,
                                     "no_gold": True}, ensure_ascii=False))
    return _ok(case_id=cid, purged=len(purged), purged_ids=purged,
               blocked_pending=len(blocked), blocked_ids=blocked[:_MAX_ITEMS],
               note=("未裁决影子项不可归档（不判也不丢，需二次复核）"
                     if blocked else ""), no_gold=True)


# --------------------------------------------------------------------------- 导出 / 指标 / 报告口径
def shadow_export(case_id: str, *, actor: str = "", role: str = "",
                  include_discarded: bool = True) -> dict:
    """导出影子清单（含 discarded 留痕）：``shadow.export`` 默认仅 admin。

    报告「导出附影子清单」的唯一服务入口；reviewer/super_admin/platform_op 403。
    每次导出写 ``shadow.revealed`` 审计（via=export）。
    """
    cid = str(case_id or "").strip()
    case = _case(cid)
    if not case:
        return _err(404, "not_found", "项目不存在")
    access = _export_access(cid, actor, role)
    if not access.get("ok"):
        return _deny(access)
    mode_info = _review_mode_info(cid)
    if mode_info.get("locked"):
        return _err(403, "evaluation_locked",
                    "评测/盲审模式：提交独立复核前不允许导出影子清单（盲审防泄漏）",
                    mode=mode_info.get("mode"))
    actor_eff = str(access.get("actor") or actor or "").strip()
    with db.session() as conn:
        _ensure_ready(conn)
        rows = _case_rows(conn, case)
        if not include_discarded:
            rows = [r for r in rows if str(r.get("zone") or "") == ZONE_SHADOW]
        items = [_public_item(r) for r in rows]
        _audit(conn, actor=actor_eff, action=EVENT_REVEALED, obj=cid, case=case,
               after=json.dumps({"case_id": cid, "via": "export",
                                 "export_permission": EXPORT_PERMISSION,
                                 "role": str(access.get("role") or role or ""),
                                 "items_count": len(items),
                                 "includes_discarded": bool(include_discarded),
                                 "no_gold": True}, ensure_ascii=False))
    return _ok(case_id=cid, permission=EXPORT_PERMISSION,
               role=str(access.get("role") or role or ""),
               items=items, total=len(items),
               summary=_summary(rows),
               warning=SHADOW_WARNING,
               note="影子清单仅供人工复核/自进化，不是正式报告结论",
               no_gold=True)


def shadow_metrics(case_id: str = "", *, actor: str = "", role: str = "") -> dict:
    """影子池指标：大小 / 真问题比例 / 裁决耗时 / 升级率 / 默认处置（不伪装 gold）。"""
    cid = str(case_id or "").strip()
    rows = []
    with db.session() as conn:
        _ensure_ready(conn)
        if cid:
            case = _case(cid)
            if not case:
                return _err(404, "not_found", "项目不存在")
            access = _view_access(cid, actor, role)
            if not access.get("ok"):
                return _deny(access)
            mode_info = _review_mode_info(cid)
            if mode_info.get("locked"):
                return _err(403, "evaluation_locked",
                            "评测/盲审模式：提交独立复核前不返回影子池指标（盲审防泄漏）",
                            mode=mode_info.get("mode"))
            rows = _case_rows(conn, case, include_purged=True)
        else:
            if str(role or "").strip() and str(role or "") != "admin":
                return _err(403, "forbidden", "跨项目影子指标仅业务管理员可读")
            try:
                all_rows = [dict(r) for r in conn.execute(
                    "SELECT * FROM shadow_item ORDER BY created_at, rowid").fetchall()]
            except Exception:  # noqa: BLE001
                all_rows = []
            rows = all_rows
    summary = _summary(rows)
    decided = summary["confirmed"] + summary["false_positive"]
    tp_ratio = (round(summary["confirmed"] / decided, 4) if decided else None)
    fp_ratio = (round(summary["false_positive"] / decided, 4) if decided else None)
    decision_hours = []
    for row in rows:
        if str(row.get("shadow_status") or "") not in RESOLVED_STATUSES:
            continue
        start = _epoch(str(row.get("created_at") or ""))
        end = _epoch(str(row.get("shadow_reviewed_at") or ""))
        if start is not None and end is not None and end >= start:
            decision_hours.append(round((end - start) / 3600.0, 3))
    avg_hours = (round(sum(decision_hours) / len(decision_hours), 3)
                 if decision_hours else None)
    escalated_n = summary["escalated"] + len([r for r in rows
                                              if int(r.get("shadow_round") or 1) > 1])
    base_n = len([r for r in rows if str(r.get("zone") or "") == ZONE_SHADOW])
    return _ok(enabled=True, case_id=cid or "all",
               pool_size=summary["total"],
               shadow=summary["total"], discarded=summary["discarded"],
               zone_counts=summary["zone_counts"],
               open=summary["open"], pending=summary["open"],
               confirmed=summary["confirmed"],
               false_positive=summary["false_positive"],
               unsure=summary["unsure"], skipped=summary["skipped"],
               escalated=summary["escalated"],
               true_positive_ratio=tp_ratio,
               false_positive_ratio=fp_ratio,
               decided=decided,
               avg_decision_hours=avg_hours,
               escalation_rate=(round(escalated_n / base_n, 4) if base_n else None),
               default_closed=summary["default_closed"],
               by_reason=summary["by_reason"],
               by_source=summary["by_source"],
               by_status=summary["by_status"],
               warning=SHADOW_WARNING,
               note=("真问题比例/裁决耗时只统计已裁决项；升级率=发生过升级的项/影子项数；"
                     "默认处置为 weak（非 gold）"),
               not_gold=True, no_gold=True)


def formal_excluded_finding_ids(case_id: str) -> list[str]:
    """被仲裁进 shadow/discarded 的平台 finding id（report_gate 正式口径剔除用）。

    确认（confirmed）的平台 finding 回到正式口径，因此不剔除。
    """
    cid = str(case_id or "").strip()
    if not cid:
        return []
    try:
        with db.session() as conn:
            if not _table_exists(conn):
                return []
            rows = conn.execute(
                "SELECT platform_finding_id, zone, shadow_status FROM shadow_item "
                "WHERE case_id=? AND platform_finding_id<>''",
                (cid,)).fetchall()
    except Exception:  # noqa: BLE001
        LOGGER.warning("shadow formal exclusion skipped case=%s", cid, exc_info=True)
        return []
    out = []
    for row in rows:
        fid = str(row[0] or "")
        if not fid:
            continue
        zone = str(row[1] or "")
        status = str(row[2] or "")
        if zone == ZONE_DISCARDED or status != STATUS_CONFIRMED:
            if fid not in out:
                out.append(fid)
    return out


def formal_finding_ids(case_id: str) -> list[str]:
    """正式口径 finding id（finding 表 - 被影子/丢弃剔除），供报告/Phase 2 渲染过滤。"""
    cid = str(case_id or "").strip()
    if not cid:
        return []
    try:
        findings = R.findings.by_case(cid) or []
    except Exception:  # noqa: BLE001
        findings = []
    excluded = set(formal_excluded_finding_ids(cid))
    return [str(f.get("id") or "") for f in findings
            if str(f.get("id") or "") not in excluded]


def finding_zone(finding_id: str) -> str:
    """单条 finding 的报告口径分区（formal/shadow/discarded）。"""
    fid = str(finding_id or "").strip()
    if not fid:
        return ZONE_FORMAL
    try:
        with db.session() as conn:
            if not _table_exists(conn):
                return ZONE_FORMAL
            row = conn.execute(
                "SELECT zone, shadow_status FROM shadow_item WHERE platform_finding_id=? "
                "ORDER BY created_at DESC, rowid DESC LIMIT 1", (fid,)).fetchone()
    except Exception:  # noqa: BLE001
        return ZONE_FORMAL
    if not row:
        return ZONE_FORMAL
    if str(row[0] or "") == ZONE_DISCARDED:
        return ZONE_DISCARDED
    if str(row[1] or "") == STATUS_CONFIRMED:
        return ZONE_FORMAL
    return ZONE_SHADOW


def report_stats(case_id: str) -> dict:
    """报告口径统计（report_gate 接入；内部只读，无 actor 也可调用）。

    返回正式口径 finding 数、影子 N 提示、discarded 审计数、通过率分母（不含 shadow）、
    剔除 id 列表、导出权限要求。**shadow 不阻断正式报告**，只做 N 提示。
    """
    cid = str(case_id or "").strip()
    base = {
        "enabled": False, "case_id": cid, "formal": {}, "shadow": {},
        "discarded": {}, "hint": None, "count_visible": False, "locked": False,
        "pass_rate": {"denominator": 0, "passed": 0, "failed": 0, "rate": None,
                      "shadow_excluded": True, "note": "影子池未接入/无数据"},
        "export": {"permission": EXPORT_PERMISSION,
                   "default_roles": list(EXPORT_DEFAULT_ROLES),
                   "required_for_shadow_appendix": True},
        "formal_excluded_finding_ids": [],
        "no_gold": True, "not_in_formal_report": True,
        "note": "影子池表未初始化：口径零变化",
    }
    if not cid:
        return base
    case = _case(cid)
    if not case:
        base["note"] = "项目不存在"
        return base
    mode_info = _review_mode_info(cid)
    locked = bool(mode_info.get("locked"))
    with db.session() as conn:
        if not _table_exists(conn):
            return base
        rows = _case_rows(conn, case)
    summary = _summary(rows)
    excluded = formal_excluded_finding_ids(cid)
    try:
        findings = R.findings.by_case(cid) or []
    except Exception:  # noqa: BLE001
        findings = []
    formal_ids = [str(f.get("id") or "") for f in findings
                  if str(f.get("id") or "") not in set(excluded)]
    formal_findings = [f for f in findings if str(f.get("id") or "") in set(formal_ids)]
    five_state = {}
    for f in formal_findings:
        key = str(f.get("state") or f.get("status") or "unknown")
        five_state[key] = five_state.get(key, 0) + 1
    failed = int(five_state.get("fail") or 0)
    passed = int(five_state.get("pass") or 0)
    judged = passed + failed
    count_visible = not locked
    hint = SHADOW_HINT_TPL.format(n=summary["open"]) if count_visible else None
    return {
        "enabled": True,
        "case_id": cid,
        "mode": mode_info.get("mode") or "production",
        "locked": locked,
        "count_visible": count_visible,
        "formal": {
            "findings": len(formal_ids),
            "finding_ids": formal_ids[:_MAX_ITEMS],
            "five_state": five_state,
            "excluded_finding_ids": excluded,
            "excluded_count": len(excluded),
            "note": "正式报告只统计 formal（不在 shadow_item 的 finding）",
        },
        "shadow": {
            "count": summary["total"],
            "open": summary["open"],
            "pending": summary["open"],
            "hint": hint,
            "count_visible": count_visible,
            "by_reason": summary["by_reason"],
            "by_source": summary["by_source"],
            "by_status": summary["by_status"],
            "high_risk_open": summary["high_risk_open"],
            "blocks_formal_report": False,
            "in_formal_report": False,
            "in_pass_rate_denominator": False,
            "warning": SHADOW_WARNING,
            "note": ("疑似问题（未裁决）单列提示，不影响放行；人工裁决后进入自进化/二次复核"
                     if count_visible else "评测/盲审模式提交独立复核前不显示 N"),
        },
        "discarded": {
            "count": summary["discarded"],
            "in_formal_report": False,
            "in_pass_rate_denominator": False,
            "audit_only": True,
            "note": "discarded 不出现于报告，但审计可查（reason/来源/claim sha256）",
        },
        "hint": hint,
        "warning": SHADOW_WARNING,
        "pass_rate": {
            "denominator": judged,
            "formal_findings": len(formal_ids),
            "passed": passed,
            "failed": failed,
            "rate": (round(passed / judged, 4) if judged else None),
            "shadow_excluded": True,
            "shadow_count_not_counted": summary["total"],
            "discarded_not_counted": summary["discarded"],
            "note": ("通过率/五态分母只含 formal 判定；影子池项"
                     f"{summary['total']} 条与 discarded {summary['discarded']} 条不在分母"),
        },
        "export": {"permission": EXPORT_PERMISSION,
                   "default_roles": list(EXPORT_DEFAULT_ROLES),
                   "required_for_shadow_appendix": True,
                   "note": "导出附影子清单需 shadow.export（默认仅业务管理员）"},
        "formal_excluded_finding_ids": excluded,
        "no_gold": True,
        "not_in_formal_report": True,
        "note": "影子池报告口径（Phase 1 服务层单一事实源）",
    }


# --------------------------------------------------------------------------- 时间工具
def _epoch(value) -> float | None:
    text = str(value or "").strip()
    if not text:
        return None
    import datetime as _dt
    try:
        parsed = _dt.datetime.fromisoformat(text)
    except Exception:  # noqa: BLE001
        parsed = None
    if parsed is None:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
            try:
                parsed = _dt.datetime.strptime(text, fmt)
                break
            except Exception:  # noqa: BLE001
                continue
    if parsed is None:
        return None
    try:
        if parsed.tzinfo is None:
            parsed = parsed.astimezone()
        return float(parsed.timestamp())
    except Exception:  # noqa: BLE001
        return None


__all__ = [
    "SHADOW_TABLE", "ZONE_FORMAL", "ZONE_SHADOW", "ZONE_DISCARDED", "ZONES",
    "ZONE_SOURCES", "ZONE_SOURCE_LABELS", "SHADOW_REASONS", "REASON_LABELS",
    "SHADOW_STATUSES", "STATUS_LABELS", "OPEN_STATUSES", "RESOLVED_STATUSES",
    "DECIDE_ACTIONS", "ACTION_LABELS", "AUDIT_EVENTS",
    "SHADOW_WARNING", "SHADOW_HINT_TPL", "DEFAULT_ESCALATION_ROUNDS",
    "DEFAULT_ESCALATION_HOURS", "DEFAULT_DISPOSITION", "EXPORT_PERMISSION",
    "DETERMINISTIC_EXECUTORS", "SEMANTIC_EXECUTORS", "MANIFEST_DAG_ENGINE",
    "ensure_schema", "rollback_schema", "five_state_of", "deterministic_of",
    "executor_kind", "manifest_dag_determinism",
    "anchor_state", "classify", "to_shadow", "shadow_items", "shadow_item",
    "decide", "escalate_pending", "purge", "shadow_export", "shadow_metrics",
    "formal_excluded_finding_ids", "formal_finding_ids", "finding_zone",
    "report_stats",
]
