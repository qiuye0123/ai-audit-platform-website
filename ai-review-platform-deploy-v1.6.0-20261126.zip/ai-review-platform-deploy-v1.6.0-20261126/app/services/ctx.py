"""上下文：当前租户/工作空间（线程局部）。

L98 P1（2026-11-24，外部复验「ctx 嵌套/租户隔离」）修复说明
============================================================
修复前的三个真实问题（都能复现，均有测试）：

1. ``scoped().__exit__`` 把上下文清成空，而不是恢复外层 —— 嵌套 ``with scoped``
   退出后外层身份/租户/空间丢失，后续仓储读写退化为“无隔离”（跨租户可见）。
2. ``set_context`` 是**全量重置**：写 tenant/workspace 的同时清空
   ``system`` / ``mode`` / ``doc_type`` / ``case``；各处手写的
   ``saved = get_context() ... finally: set_context(saved)`` 因此丢掉审核模式与
   case 归因（manifest_exec 曾有注释确认“set_context 会清空审核模式”）。
3. 后台任务/线程复用：worker 线程不继承提交者作用域（新建线程从空上下文开始，
   写入不带 tenant_id），线程池复用又可能残留上一个任务的作用域。

修复口径（开关 ``RULEPROOF_CTX_NESTED_SCOPE``，默认 1；=0 整体回退旧行为）：

* **完整状态快照**：``snapshot()`` / ``restore(snap)`` 覆盖
  tenant/workspace/system/mode/doc_type/case 六个字段；``get_state()`` 同名只读；
* **嵌套作用域**：``scoped`` 进入时压栈快照，退出（含异常）恢复外层完整状态；
* **空上下文拒绝语义**：外层已有租户/空间时，``scoped("", "")`` 抛
  ``EmptyScopeError``，不允许用空作用域静默清掉外层隔离（显式 ``allow_empty=True``
  才放行）；顶层（无外层作用域）的空作用域仍允许，兼容历史脚本；
* **线程/后台任务隔离**：``clear()`` 显式清空、``inherited(snap)`` 让后台线程继承
  提交者作用域并在退出后恢复该线程原有状态（新线程=空），``empty()`` 提供
  “无隔离”显式区间（写操作应避免）；
* 旧行为保留：``set_context`` 仍是“设置 + 清空模式/system/case”的入口（CLI/HTTP
  每请求都靠它做全量重置）；需要恢复完整状态请用 ``restore()``。

诚实边界：线程局部存储只保证**同线程**语义；真正跨线程继承由 ``task.submit`` 等
后台入口显式调用 ``snapshot()/inherited()`` 完成（见 app/services/task.py）。
"""
import os
import threading
from contextlib import contextmanager

_TLS = threading.local()

NESTED_SCOPE_ENV = "RULEPROOF_CTX_NESTED_SCOPE"
_OFF = ("0", "false", "no", "off", "n")
_FIELDS = ("tenant", "workspace", "system", "mode", "doc_type", "case")


class EmptyScopeError(ValueError):
    """嵌套作用域下用空上下文覆盖外层作用域：拒绝（避免静默失去租户隔离）。"""


def nested_scope_enabled() -> bool:
    """嵌套作用域/空上下文拒绝语义开关：默认开；=0 完全回退旧行为。"""
    # 直接读字面量：开关注册表门禁（L59）按字面量静态扫描，常量间接读会被记为“未读取”
    raw = os.environ.get("RULEPROOF_CTX_NESTED_SCOPE", "1")
    if raw is None or str(raw).strip() == "":
        return True
    return str(raw).strip().lower() not in _OFF


# ---------------------------------------------------------------------------
# 内部状态：单字典 + 嵌套栈（都在 threading.local 上，天然按线程隔离）
# ---------------------------------------------------------------------------
def _defaults() -> dict:
    return {"tenant": "", "workspace": "", "system": False,
            "mode": "", "doc_type": "", "case": ""}


def _state() -> dict:
    st = getattr(_TLS, "state", None)
    if not isinstance(st, dict):
        st = _defaults()
        _TLS.state = st
    # 兼容老代码直接写 _TLS.tenant 的场景：以 state 为准（本模块之外无写入点）
    return st


def _stack() -> list:
    st = getattr(_TLS, "stack", None)
    if not isinstance(st, list):
        st = []
        _TLS.stack = st
    return st


def _set_field(name: str, value) -> None:
    _state()[name] = value


# ---------------------------------------------------------------------------
# 基础读写（保持旧 API 语义：set_context 仍是“设置 + 重置其余字段”）
# ---------------------------------------------------------------------------
def set_context(tenant_id: str = "", workspace_id: str = "") -> None:
    st = _state()
    st["tenant"] = tenant_id or ""
    st["workspace"] = workspace_id or ""
    st["system"] = False
    st["mode"] = ""
    st["doc_type"] = ""
    st["case"] = ""


def set_system(flag: bool = True) -> None:
    """显式系统作用域：允许脚本/迁移跨租户读写（必须显式声明）。"""
    _set_field("system", bool(flag))


def is_system() -> bool:
    return bool(_state()["system"])


def set_audit_mode(mode: str = "manual", doc_type: str = "") -> None:
    """本次审核模式（线程局部）：manual=仅客户规则；assisted=客户规则+未覆盖点位。
    doc_type 仅在用户显式选择时非空，用于按适用点位过滤（不做事前推断路由）。"""
    st = _state()
    st["mode"] = mode or ""
    st["doc_type"] = doc_type or ""


def get_audit_mode() -> dict:
    # 未显式设置时返回空模式 = 旧完整链路（保证脚本/测试行为不变）
    st = _state()
    return {"mode": st["mode"] or "", "doc_type": st["doc_type"] or ""}


def set_case(case_id: str) -> None:
    """当前审核 case（线程局部）：用于 agent_run 归因，不参与权限判断。"""
    _set_field("case", case_id or "")


def get_case() -> str:
    return _state()["case"] or ""


def get_context() -> dict:
    st = _state()
    return {"tenant_id": st["tenant"], "workspace_id": st["workspace"]}


# ---------------------------------------------------------------------------
# L98 新增：完整状态快照/恢复（替代各处手写 get_context + set_context 的丢字段恢复）
# ---------------------------------------------------------------------------
def snapshot() -> dict:
    """返回当前线程的完整上下文状态（六字段；可直接喂给 restore/inherited）。"""
    st = _state()
    return {"tenant_id": st["tenant"], "workspace_id": st["workspace"],
            "system": bool(st["system"]), "mode": st["mode"],
            "doc_type": st["doc_type"], "case": st["case"]}


def get_state() -> dict:
    """snapshot() 的别名（只读语义）。"""
    return snapshot()


def restore(snap: dict) -> None:
    """恢复 snapshot() 的完整状态；缺字段按默认值处理（不保留当前值，避免脏读）。"""
    st = _state()
    snap = snap if isinstance(snap, dict) else {}
    st["tenant"] = str(snap.get("tenant_id") or "")
    st["workspace"] = str(snap.get("workspace_id") or "")
    st["system"] = bool(snap.get("system") or False)
    st["mode"] = str(snap.get("mode") or "")
    st["doc_type"] = str(snap.get("doc_type") or "")
    st["case"] = str(snap.get("case") or "")


def clear() -> None:
    """清空当前线程全部上下文（含嵌套栈）；后台任务结束/线程复用前调用。"""
    _TLS.state = _defaults()
    _TLS.stack = []


# ---------------------------------------------------------------------------
# L98 新增：嵌套作用域 / 继承 / 空作用域拒绝
# ---------------------------------------------------------------------------
class scoped:
    """with scoped(t, w): ... 退出恢复外层完整上下文（嵌套安全）。

    * ``RULEPROOF_CTX_NESTED_SCOPE=1``（默认）：进入时压栈快照，退出恢复；
      外层已有作用域时 ``scoped("", "")`` 抛 ``EmptyScopeError``；
    * ``RULEPROOF_CTX_NESTED_SCOPE=0``：旧行为——进入 set_context(t, w)，
      退出 set_context("", "")（清空而非恢复），空作用域不拒绝。
    """

    def __init__(self, tenant_id: str, workspace_id: str, allow_empty: bool = False):
        self.t = tenant_id or ""
        self.w = workspace_id or ""
        self.allow_empty = bool(allow_empty)
        self._legacy = not nested_scope_enabled()
        self._prev = None
        self._pushed = False

    def __enter__(self):
        if self._legacy:
            set_context(self.t, self.w)
            return self
        prev = snapshot()
        outer = prev["tenant_id"] or prev["workspace_id"]
        if not (self.t or self.w) and outer and not self.allow_empty:
            # 空作用域会静默清掉外层隔离 → 拒绝（不压栈、不改状态）
            raise EmptyScopeError(
                "拒绝用空上下文覆盖外层作用域：当前 tenant=%r workspace=%r；"
                "如需显式无隔离请传 allow_empty=True 或先调用 clear()"
                % (prev["tenant_id"], prev["workspace_id"]))
        self._prev = prev
        _stack().append(prev)
        self._pushed = True
        set_context(self.t, self.w)
        return self

    def __exit__(self, *a):
        if self._legacy:
            set_context("", "")
            return False
        stack = _stack()
        if self._pushed:
            # 防御：栈被异常代码破坏时仍恢复进入时快照，不残留内层身份
            saved = stack.pop() if stack else self._prev
            restore(saved)
            self._pushed = False
        return False

    def __repr__(self):
        return "scoped(tenant=%r, workspace=%r, legacy=%r)" % (
            self.t, self.w, self._legacy)


@contextmanager
def inherited(snap: dict):
    """后台线程/线程池：继承提交者快照，退出恢复该线程原状态（新线程=空）。

    用途：``task.submit`` 之类跨线程入口。常规 ``with scoped`` 已经足够，
    但 worker 线程没有外层上下文可继承，必须显式传入提交者快照。
    """
    prev = snapshot()
    restore(snap)
    try:
        yield snapshot()
    finally:
        restore(prev)


@contextmanager
def empty():
    """显式“无租户隔离”区间（迁移/平台运维脚本用）；退出恢复原状态。

    业务读写禁止套本上下文（本函数只提供显式语义，不做权限判断）。
    """
    prev = snapshot()
    clear()
    try:
        yield get_context()
    finally:
        restore(prev)


def scoped_snapshot():
    """当前嵌套栈快照（调试/测试用；不暴露可变内部对象）。"""
    return [dict(x) for x in _stack()]
