"""结构化断言求值（确定性部分，不调用模型）。

判据 v6 里每条 assertion 都可独立求值；数值类完全由代码判定，不受模型采样影响。
取值来源：values 字典（由抽取层提供），键为断言里 left/right 的表达式名。
"""


def _num(v):
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def _fuzzy_key(expr, values):
    """精确匹配失败时的语义近似：expr 与某个键互相包含则认为是同一变量。"""
    e = str(expr).replace(" ", "")
    if not e:
        return None
    best = None
    for k in values:
        kk = str(k).replace(" ", "")
        if not kk or kk.endswith("_单位") or kk.endswith("_来源"):
            continue
        if kk in e or e in kk:
            if best is None or len(kk) > len(best):
                best = k
    return best


def _resolve(expr, values):
    """表达式求值：支持变量、+ - * / × ÷ 与百分号。

    变量名按最长优先替换，避免 "已付" 抢先匹配 "已支付"。
    """
    import re as _re
    if expr in values:
        return values[expr]
    fk = _fuzzy_key(expr, values)
    if fk and str(expr).strip() == str(fk).strip():
        return values[fk]
    text = str(expr)
    if not text:
        return None
    for part in [x.strip() for x in str(expr).replace("×", "*").replace("÷", "/").split("+") + []]:
        pass
    names = sorted(values.keys(), key=len, reverse=True)
    for part in [p.strip() for p in str(expr).split("+")]:
        if part and part not in values:
            fk = _fuzzy_key(part, values)
            if fk:
                values = dict(values); values[part] = values[fk]
    for n in names:
        if n in text:
            v = values[n]
            try:
                num = float(str(v).replace(",", ""))
            except (TypeError, ValueError):
                return None
            text = text.replace(n, f"({num})")
    if _re.search(r"[^0-9\.\+\-\*/\(\)\s%]", text):
        return None           # 仍有未解析的变量名或非法字符
    text = text.replace("×", "*").replace("÷", "/").replace("%", "/100")
    try:
        return eval(text, {"__builtins__": {}}, {})  # 已过字符白名单
    except Exception:
        return None


def evaluate(a: dict, values: dict) -> dict:
    """返回 {ok, type, detail}。无法求值时 ok=None（证据不足），不是失败。"""
    t = (a.get("type") or "").strip()
    left = _resolve(a.get("left"), values)
    right = _resolve(a.get("right"), values)
    tol = a.get("tolerance") or 0

    def need(*xs):
        return all(x is not None for x in xs)

    if t == "range":
        ln, rn = _num(left), _num(right)
        if not need(ln, rn):
            return {"ok": None, "type": t, "detail": "取值缺失，无法比较"}
        op = a.get("op") or "<="
        ok = {">": ln > rn, ">=": ln >= rn, "<": ln < rn, "<=": ln <= rn, "=": abs(ln - rn) <= tol}.get(op, False)
        return {"ok": ok, "type": t, "detail": f"{ln} {op} {rn} → {'满足' if ok else '不满足'}"}

    if t == "equality":
        ln, rn = _num(left), _num(right)
        if not need(ln, rn):
            return {"ok": None, "type": t, "detail": "取值缺失"}
        ok = abs(ln - rn) <= max(tol, 1e-9)
        return {"ok": ok, "type": t, "detail": f"{ln} ≈ {rn}（容差 {tol}）"}

    if t == "sum_consistency":
        ln, rn = _num(left), _num(right)
        if not need(ln, rn):
            return {"ok": None, "type": t, "detail": "合计项缺失"}
        ok = abs(ln - rn) <= max(tol, 1e-9)
        return {"ok": ok, "type": t, "detail": f"合计 {ln} vs 应为 {rn}（容差 {tol}）"}

    if t == "set_membership":
        vals = values.get(a.get("left"))
        allowed = values.get(a.get("right")) or []
        if vals is None or not allowed:
            return {"ok": None, "type": t, "detail": "集合取值缺失"}
        vals = vals if isinstance(vals, (list, tuple, set)) else [vals]
        bad = [v for v in vals if v not in allowed]
        return {"ok": not bad, "type": t, "detail": f"越界取值 {bad}" if bad else "全部在允许集合内"}

    if t == "ordering":
        lv, rv = values.get(a.get("left")), values.get(a.get("right"))
        if lv is None or rv is None:
            return {"ok": None, "type": t, "detail": "顺序比较取值缺失"}
        ok = str(lv) < str(rv) if a.get("op") == "before" else str(lv) <= str(rv)
        return {"ok": ok, "type": t, "detail": f"{lv} vs {rv}"}

    if t == "presence":
        key = a.get("left")
        op = a.get("op") or "required"
        if key not in values:
            # 键不在抽取结果里：可能原文没有，也可能抽取器没抽到 —— 不能据此判 fail
            return {"ok": None, "type": t, "detail": f"未抽取到「{key}」，无法判定存在性"}
        v = values.get(key)
        present = v not in (None, "", [], {})
        ok = present if op == "required" else (not present)
        return {"ok": ok, "type": t, "detail": f"{'有' if present else '无'}：{key}"}

    if t == "contiguity":
        ranges = values.get(a.get("left")) or []
        try:
            spans = sorted((float(x[0]), float(x[1])) for x in ranges)
        except Exception:
            return {"ok": None, "type": t, "detail": "区间格式无法解析"}
        for i in range(len(spans) - 1):
            if spans[i][1] > spans[i + 1][0]:
                return {"ok": False, "type": t, "detail": f"区间重叠：{spans[i]} 与 {spans[i+1]}"}
        return {"ok": True, "type": t, "detail": "区间无重叠"}

    return {"ok": None, "type": t, "detail": f"未知断言类型：{t}"}


def evaluate_all(assertions: list, values: dict) -> dict:
    """对一组断言求值：任一 False → 判 fail；全 True → pass；否则 insufficient。"""
    results = [evaluate(a, values) for a in assertions or []]
    if any(r["ok"] is False for r in results):
        state = "fail"
    elif results and all(r["ok"] is True for r in results):
        state = "pass"
    else:
        state = "insufficient"
    return {"state": state, "results": results}
