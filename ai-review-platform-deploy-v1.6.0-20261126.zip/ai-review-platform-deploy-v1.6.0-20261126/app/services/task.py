"""异步任务：线程执行 + DB 持久化 + 幂等键 + 重启恢复 + 硬取消 + 结果保留期。

边界：Python 线程不能被强杀；取消/超时只终止调度状态，worker 线程可能
继续跑到函数返回。为此提供协作取消检查点 checkpoint(tid)：worker 在安全
点调用后，若任务已取消会抛出 TaskCancelled，从而尽快停止计算。结果写入
有 DB 级守卫——取消状态永远不会被 done/failed/timeout 覆盖，取消后大对象
也不会序列化进 result_json。进程重启后遗留 queued/running 一律标记
failed/interrupted，绝不恢复成 done；被中断任务关联的“审核中”项目同步
回落为 audit_failed，避免项目永远停在审核中。

结果保留期（cleanup_results / maybe_cleanup）：
- 终态任务（done/failed/cancelled/timeout）的大结果按 max_bytes 清理；
- 超过 retention_days 的历史结果按项目保留最近 keep_last 份后清理；
- 只清空 result_json，不改变任务状态；取消/运行中任务永不清理；
- 内存 TASKS 同步丢弃已清理结果并做条数上限回收，避免长进程内存膨胀。
"""
import json
import logging
import os
import threading
import time

from .. import db, obs
from . import ctx as _app_ctx

TASKS = {}
_LOCK = threading.RLock()
_HOOKS = {}          # tid -> on_cancel(tid) 取消回调；只在本进程有效
_T0 = {}             # tid -> 提交时刻，仅内存，用于结构化日志 latency
_CLEANUP_LOCK = threading.Lock()
_LAST_CLEANUP = 0.0
TERMINAL_STATUSES = ("done", "failed", "cancelled", "timeout")
MAX_ACTIVE = int(os.environ.get("RULEPROOF_TASK_MAX_ACTIVE", "20") or 20)
DEFAULT_TIMEOUT = int(os.environ.get("RULEPROOF_TASK_TIMEOUT", "1800") or 1800)

_UPSERT = ("INSERT INTO task_job(id,name,status,owner,case_id,timeout,started,finished,error,"
           "result_json,cancel_requested,deadline,idem_key,updated_at,instance_id,heartbeat) "
           "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET "
           "status=excluded.status,finished=excluded.finished,error=excluded.error,"
           "result_json=excluded.result_json,cancel_requested=excluded.cancel_requested,"
           "deadline=excluded.deadline,updated_at=excluded.updated_at,"
           "instance_id=excluded.instance_id,heartbeat=excluded.heartbeat")
# 取消优先：已取消（或已请求取消）的行不允许再被其它状态覆盖。
_GUARD = " WHERE task_job.status <> 'cancelled' AND task_job.cancel_requested=0"


class TaskCancelled(Exception):
    """协作取消信号：worker 在安全点调用 checkpoint(tid) 时抛出。"""


def _row(r) -> dict:
    if not r:
        return {}
    d = dict(r)
    d["cancel_requested"] = bool(d.get("cancel_requested"))
    d["result_available"] = bool(d.get("status") == "done" and d.get("result_json"))
    if d.get("status") == "done":
        if d.get("result_json"):
            try:
                d["result"] = json.loads(d["result_json"])
            except Exception:
                d["result"] = None
        else:
            # 已按保留期清理：保留 result 键但为 None，调用方不需要区分“无此键”。
            d["result"] = None
    d.pop("result_json", None)
    return d


def _audit(action: str, object_id: str, after: str = "", actor: str = "system") -> None:
    """任务维护动作写审计；审计失败不能影响清理/取消主流程。"""
    try:
        from .. import repositories as R
        R.audit_logs.log(actor=actor or "system", action=action,
                         object=object_id or "", after=after or "")
    except Exception:
        logging.getLogger(__name__).debug("task audit log skipped action=%s", action, exc_info=True)


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, str(default)) or default)
    except Exception:
        return float(default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(os.environ.get(name, str(default)) or default))
    except Exception:
        return int(default)


# ---------------- 多实例归属 / 心跳（recover 只恢复本实例或已过期任务）----------------
INSTANCE_ID = (os.environ.get("RULEPROOF_INSTANCE_ID") or "").strip() or \
    f"{(os.uname().nodename if hasattr(os, 'uname') else 'host')}:{os.getpid()}:{db.new_id('i')[-6:]}"
HEARTBEAT_INTERVAL = max(1, _env_int("RULEPROOF_TASK_HEARTBEAT_INTERVAL", 15))
LEASE_SECONDS = max(HEARTBEAT_INTERVAL * 3, _env_int("RULEPROOF_TASK_LEASE_SECONDS", 120))
_HEARTBEAT_STARTED = False
_HEARTBEAT_LAST = 0.0


def _heartbeat_once() -> int:
    """给本实例仍在 queued/running 的任务续心跳；多实例共享 DB 时用于区分“别的实例还活着”。"""
    global _HEARTBEAT_LAST
    with _LOCK:
        ids = [tid for tid, t in TASKS.items() if t.get("status") in ("queued", "running")]
    if not ids:
        return 0
    now_ts = time.time()
    updated = 0
    with db.session() as c:
        for tid in ids:
            cur = c.execute(
                "UPDATE task_job SET heartbeat=? WHERE id=? AND instance_id=? "
                "AND status IN ('queued','running')",
                (now_ts, tid, INSTANCE_ID))
            updated += int(cur.rowcount or 0)
        c.commit()
    with _LOCK:
        for tid in ids:
            if tid in TASKS:
                TASKS[tid]["heartbeat"] = now_ts
    _HEARTBEAT_LAST = now_ts
    return updated


def _heartbeat_worker() -> None:
    while True:
        time.sleep(HEARTBEAT_INTERVAL)
        try:
            _heartbeat_once()
        except Exception:
            logging.getLogger(__name__).warning("task heartbeat failed", exc_info=True)


def _ensure_heartbeat() -> None:
    global _HEARTBEAT_STARTED
    with _LOCK:
        if _HEARTBEAT_STARTED:
            return
        _HEARTBEAT_STARTED = True
    threading.Thread(target=_heartbeat_worker, daemon=True, name="task-heartbeat").start()


def _load(tid: str) -> dict:
    with db.session() as c:
        r = c.execute("SELECT * FROM task_job WHERE id=?", (tid,)).fetchone()
    return _row(r)


def _is_cancelled_row(r) -> bool:
    return bool(r) and (bool(r["cancel_requested"]) or r["status"] == "cancelled")


def _cancelled_in_db(tid: str) -> bool:
    """用独立短连接读取取消状态，避免读写事务升级触发 WAL busy snapshot。"""
    with db.session() as c:
        r = c.execute("SELECT status,cancel_requested FROM task_job WHERE id=?", (tid,)).fetchone()
    return _is_cancelled_row(r)


def _params(t: dict, payload: str) -> tuple:
    return (t["id"], t.get("name") or "", t.get("status") or "queued", t.get("owner") or "",
            t.get("case_id") or "", int(t.get("timeout") or DEFAULT_TIMEOUT),
            t.get("started") or "", t.get("finished") or "", t.get("error") or "",
            payload, 1 if t.get("cancel_requested") else 0, t.get("deadline"),
            t.get("idem_key") or "", db.now(),
            t.get("instance_id") or INSTANCE_ID, time.time())


def _persist(t: dict) -> bool:
    """写入任务状态。返回 False 表示 DB 中该任务已取消，本次终态写入被拒绝。

    done 写入前先查一次 DB，避免跨进程取消时把大结果序列化；真正落库的
    SQL 仍带取消守卫，因此即使查询后发生并发取消，也不会覆盖 cancelled。
    """
    status = t.get("status") or "queued"
    if status == "cancelled":
        with db.session() as c:
            c.execute(_UPSERT, _params(t, ""))
        return True
    if status == "done":
        if t.get("cancel_requested"):
            return False
        # 先独立连接确认取消状态，避免跨进程取消时把大结果序列化；
        # 写事务是新开的，落库 SQL 仍带取消守卫。
        if _cancelled_in_db(t["id"]):
            return False
        payload = json.dumps(t.get("result"), ensure_ascii=False, default=str)
        with db.session() as c:
            cur = c.execute(_UPSERT + _GUARD, _params(t, payload))
            return cur.rowcount > 0
    with db.session() as c:
        cur = c.execute(_UPSERT + _GUARD, _params(t, ""))
        return cur.rowcount > 0


def _active() -> int:
    try:
        with db.session() as c:
            return int(c.execute("SELECT COUNT(*) FROM task_job WHERE status IN ('queued','running')").fetchone()[0])
    except Exception:
        return sum(1 for t in TASKS.values() if t.get("status") in ("queued", "running"))


def _find_idem(key: str) -> str:
    """同一幂等键取最近一次任务：失败/取消后重试不会被更早的旧行抢占。"""
    if not key:
        return ""
    try:
        with db.session() as c:
            r = c.execute("SELECT id FROM task_job WHERE idem_key=? ORDER BY rowid DESC LIMIT 1",
                          (key,)).fetchone()
        return r["id"] if r else ""
    except Exception:
        return ""


def find_by_idem(key: str) -> dict:
    """按幂等键查任务（不加载 result_json，避免幂等重放时反序列化大结果）。"""
    if not key:
        return {}
    try:
        with db.session() as c:
            r = c.execute(
                "SELECT id,name,status,owner,case_id,started,finished,error,"
                "cancel_requested,deadline,idem_key,updated_at FROM task_job "
                "WHERE idem_key=? ORDER BY rowid DESC LIMIT 1", (key,)).fetchone()
        if not r:
            return {}
        d = dict(r)
        d["cancel_requested"] = bool(d.get("cancel_requested"))
        return d
    except Exception:
        return {}


def active_for_case(case_id: str) -> dict:
    """项目当前是否有 queued/running 任务（DB 视角，跨进程也能看到）。"""
    if not case_id:
        return {}
    try:
        with db.session() as c:
            r = c.execute(
                "SELECT id,name,status,owner,case_id,started,finished,error,"
                "cancel_requested,deadline,idem_key,updated_at FROM task_job "
                "WHERE case_id=? AND status IN ('queued','running') ORDER BY rowid DESC LIMIT 1",
                (case_id,)).fetchone()
        if not r:
            return {}
        d = dict(r)
        d["cancel_requested"] = bool(d.get("cancel_requested"))
        return d
    except Exception:
        # DB 不可用时回落到本进程内存，至少拦住同进程重复提交
        for t in TASKS.values():
            if t.get("case_id") == case_id and t.get("status") in ("queued", "running"):
                return {k: v for k, v in t.items() if k != "result"}
        return {}


def _fire_cancel_hook(tid: str) -> None:
    """取消回调只执行一次；回调异常不能影响取消状态落库。"""
    fn = _HOOKS.pop(tid, None)
    if not fn:
        return
    try:
        fn(tid)
    except Exception:
        logging.getLogger(__name__).warning("task on_cancel hook failed tid=%s", tid, exc_info=True)


def _drop_hook(tid: str) -> None:
    _HOOKS.pop(tid, None)


def _auto_cleanup_due() -> bool:
    if os.environ.get("RULEPROOF_TASK_AUTO_CLEANUP", "1") == "0":
        return False
    try:
        interval = max(1, _env_int("RULEPROOF_TASK_CLEANUP_INTERVAL", 3600))
    except Exception:
        interval = 3600
    with _CLEANUP_LOCK:
        return (time.time() - _LAST_CLEANUP) >= interval


def _kick_auto_cleanup() -> None:
    """终态写入后异步触发一次保留期清理（受间隔节流，失败不影响任务）。"""
    if not _auto_cleanup_due():
        return
    threading.Thread(target=_auto_cleanup_worker, daemon=True).start()


def _auto_cleanup_worker() -> None:
    try:
        maybe_cleanup()
    except Exception:
        logging.getLogger(__name__).warning("task auto cleanup failed", exc_info=True)


def submit(name: str, fn, *args, owner: str = "", case_id: str = "",
           timeout: int | None = None, max_active: int | None = None,
           idem_key: str = "", on_cancel=None, **kwargs) -> str:
    """提交任务。

    idem_key 非空时同一键永远返回同一个任务 id（含已失败/已取消的历史任务）；
    需要重跑请使用新的幂等键。on_cancel(tid) 在本进程观察到取消时回调一次，
    用于把“审核中”项目及时回滚到审核前状态。
    """
    tid = db.new_id("task")
    limit = MAX_ACTIVE if max_active is None else int(max_active)
    with _LOCK:
        if idem_key:
            old = _find_idem(idem_key)
            if old:
                return old
        if _active() >= limit:
            raise RuntimeError(f"任务并发已达上限（{limit}），请稍后重试")
        t = {"id": tid, "name": name, "status": "queued", "result": None,
             "error": None, "started": db.now(), "finished": None,
             "owner": owner or "", "case_id": case_id or "",
             "timeout": int(timeout if timeout is not None else DEFAULT_TIMEOUT),
             "cancel_requested": False, "deadline": None, "idem_key": idem_key or "",
             "instance_id": INSTANCE_ID, "heartbeat": time.time()}
        TASKS[tid] = t
        _T0[tid] = time.time()
        if on_cancel:
            _HOOKS[tid] = on_cancel
        try:
            _persist(t)
        except Exception:
            TASKS.pop(tid, None)
            _T0.pop(tid, None)
            _drop_hook(tid)
            raise

    _ensure_heartbeat()
    # 统一结构化日志：提交即留痕（不记录参数/结果内容，避免敏感数据入日志）
    obs.log_event("task.submit", module="services.task", status="queued",
                  user=owner or None, task_id=tid, name=name,
                  case_id=case_id or "", timeout=int(timeout if timeout is not None
                                                     else DEFAULT_TIMEOUT))

    def _finish(status: str, error: str = "", result=None):
        notify = False
        latency = None
        task_name = ""
        task_case = ""
        task_owner = ""
        with _LOCK:
            cur = TASKS.get(tid) or {}
            if cur.get("status") not in ("queued", "running"):
                _drop_hook(tid)
                return cur.get("status")
            if status != "cancelled" and (cur.get("cancel_requested") or cur.get("status") == "cancelled"):
                status, error, result = "cancelled", "", None
            cur.update({"status": status, "finished": db.now(),
                        "error": error or None, "result": result})
            if status == "cancelled":
                cur["cancel_requested"] = True
                notify = True
            TASKS[tid] = cur
            persisted = _persist(cur)
            if not persisted and status != "cancelled":
                # DB 行已被取消（可能是另一个进程发起的取消）：取消优先，丢弃结果。
                cur.update({"status": "cancelled", "finished": cur.get("finished") or db.now(),
                            "error": None, "result": None, "cancel_requested": True})
                TASKS[tid] = cur
                notify = True
            if not notify:
                _drop_hook(tid)
            out = cur.get("status")
            task_name = str(cur.get("name") or "")
            task_case = str(cur.get("case_id") or "")
            task_owner = str(cur.get("owner") or "")
            latency = obs.elapsed_ms(_T0.pop(tid, None))
        if notify:
            _fire_cancel_hook(tid)
        if out in TERMINAL_STATUSES:
            _kick_auto_cleanup()
        obs.log_event("task.finish", module="services.task", status=out,
                      latency=latency, error=error or None,
                      user=task_owner or None, task_id=tid,
                      name=task_name, case_id=task_case)
        return out

    def _run():
        early_cancel = False
        timeout = DEFAULT_TIMEOUT
        task_name = ""
        task_case = ""
        task_owner = ""
        with _LOCK:
            cur = TASKS.get(tid)
            if not cur:
                _T0.pop(tid, None)
                return
            timeout = max(1, int(cur.get("timeout") or DEFAULT_TIMEOUT))
            task_name = str(cur.get("name") or "")
            task_case = str(cur.get("case_id") or "")
            task_owner = str(cur.get("owner") or "")
            if cur.get("cancel_requested") or cur.get("status") == "cancelled":
                early_cancel = True
            else:
                cur["status"] = "running"
                cur["deadline"] = time.time() + timeout
                if not _persist(cur):
                    cur.update({"status": "cancelled", "finished": db.now(),
                                "error": None, "result": None, "cancel_requested": True})
                    TASKS[tid] = cur
                    early_cancel = True
        if early_cancel:
            # 回调必须在 task 锁外执行：route 的回调会取 _SUBMIT_LOCK，而提交路径
            # 持有 _SUBMIT_LOCK 时又会调用 task.submit 取 task 锁，锁内回调会死锁。
            _T0.pop(tid, None)
            _fire_cancel_hook(tid)
            _kick_auto_cleanup()
            return
        obs.log_event("task.start", module="services.task", status="running",
                      latency=obs.elapsed_ms(_T0.get(tid)),
                      user=task_owner or None, task_id=tid,
                      name=task_name, case_id=task_case)
        holder = {}
        _worker_ctx = obs.snapshot()
        # L98 P1：后台线程必须显式继承提交者租户/空间上下文 —— 新线程 TLS 为空，
        # 旧实现以“无租户作用域”执行任务（写库 tenant_id 为空/读全租户）；
        # 任务结束恢复该线程原状态（新线程=空），线程复用不会残留上一个任务作用域。
        _worker_app_ctx = _app_ctx.snapshot()

        def _work():
            obs.restore(_worker_ctx)
            _app_ctx.restore(_worker_app_ctx)
            try:
                holder["result"] = fn(*args, **kwargs)
            except TaskCancelled:
                holder["cancelled"] = True
            except Exception as e:  # noqa
                holder["error"] = f"{type(e).__name__}: {e}"
            finally:
                _app_ctx.clear()

        worker = threading.Thread(target=_work, daemon=True)
        worker.start()
        worker.join(timeout)
        with _LOCK:
            cur = TASKS.get(tid)
            if not cur:
                return
            cancelled = (cur.get("cancel_requested") or cur.get("status") == "cancelled"
                         or holder.get("cancelled"))
            alive = worker.is_alive()
            case_id = str(cur.get("case_id") or "")
            if cancelled:
                holder.clear()  # 取消后丢弃 worker 已产生的大结果，不写入内存/DB
        if cancelled:
            _finish("cancelled")
            return
        if alive:
            if _finish("timeout", "timeout") == "timeout":
                _audit("task.timeout", tid, case_id)
            return
        if "error" in holder:
            _finish("failed", holder["error"])
        else:
            _finish("done", result=holder.get("result"))

    _audit("task.submitted", tid,
           f"{name}|case={case_id or ''}|timeout={int(timeout if timeout is not None else DEFAULT_TIMEOUT)}",
           actor=owner or "system")
    _ctx0 = obs.snapshot()
    # L98 P1：提交线程的租户/空间快照 → worker 线程继承（with 退出恢复线程原状态）
    _app_ctx0 = _app_ctx.snapshot()

    def _run_with_ctx():
        obs.restore(_ctx0)
        with _app_ctx.inherited(_app_ctx0):
            _run()

    threading.Thread(target=_run_with_ctx, daemon=True).start()
    return tid


def get(tid: str) -> dict:
    t = TASKS.get(tid)
    if t:
        out = {k: v for k, v in t.items() if k != "result"}
        out["result_available"] = bool(t.get("status") == "done" and t.get("result") is not None)
        if t.get("status") == "done":
            out["result"] = t.get("result")
        return out
    d = _load(tid)
    return d or {"error": "任务不存在"}


def is_cancelled(tid: str) -> bool:
    """任务是否已请求取消（内存优先，未知任务回落到 DB）。"""
    t = TASKS.get(tid)
    if t:
        return bool(t.get("cancel_requested")) or t.get("status") == "cancelled"
    return _is_cancelled_row(_load(tid))


def checkpoint(tid: str) -> None:
    """worker 协作取消检查点：任务已取消时抛出 TaskCancelled。

    同一进程内的取消立即生效；任务不在本进程 TASKS 时回落到 DB 判断。
    跨进程取消的最终硬保证由 _persist 的取消守卫完成。不会强杀线程，仅让
    长任务在安全点尽快退出，避免取消后继续计算和产出结果。
    """
    if is_cancelled(tid):
        raise TaskCancelled(tid)


def cancel(tid: str, actor: str = "") -> dict:
    notify = False
    newly = False
    with _LOCK:
        t = TASKS.get(tid) or _load(tid)
        if not t:
            return {"error": "任务不存在"}
        already = t.get("status") == "cancelled" or bool(t.get("cancel_requested"))
        if already:
            # 重复取消幂等：返回同样的成功结果，保留首次 finished 时间，不重复审计。
            t = dict(t)
            t.update({"status": "cancelled", "cancel_requested": True, "result": None})
            if not t.get("finished"):
                t["finished"] = db.now()
            TASKS[tid] = t
            _persist(t)
            notify = True
            out = {"ok": True, "task_id": tid, "status": "cancelled"}
        elif t.get("status") not in ("queued", "running"):
            return {"error": "任务已结束，不能取消"}
        else:
            t = dict(t)
            t.update({"status": "cancelled", "cancel_requested": True,
                      "finished": db.now(), "result": None})
            TASKS[tid] = t
            _persist(t)
            notify = True
            newly = True
            out = {"ok": True, "task_id": tid, "status": "cancelled"}
    if notify:
        _fire_cancel_hook(tid)
    if newly:
        _audit("task.cancelled", tid, str(t.get("case_id") or ""), actor=actor or "system")
    return out


def list_tasks(limit: int = 30, owner: str = "") -> list:
    try:
        with db.session() as c:
            if owner:
                rows = c.execute("SELECT * FROM task_job WHERE owner=? ORDER BY started DESC LIMIT ?",
                                 (owner, limit)).fetchall()
            else:
                rows = c.execute("SELECT * FROM task_job ORDER BY started DESC LIMIT ?", (limit,)).fetchall()
        items = [_row(r) for r in rows]
        for x in items:
            x.pop("result", None)
        return items
    except Exception:
        items = [t for t in TASKS.values() if not owner or t.get("owner") == owner]
        items.sort(key=lambda x: x.get("started") or "", reverse=True)
        return [{k: v for k, v in t.items() if k != "result"} for t in items[:limit]]


def recover(instance_id: str = "", stale_seconds: float | None = None) -> dict:
    """进程启动时调用：只恢复“本实例残留”或“心跳已过期”的任务，不杀其他实例。

    修复点（20261117）：旧实现把 DB 中所有 queued/running 直接置 failed。多实例
    共用一个库时，实例 B 启动会把实例 A 正在跑的任务全部杀掉。现在 task_job 带
    instance_id + heartbeat：
    - 本实例 ID 的遗留行（进程重启）→ recovered；
    - 其他实例且心跳新鲜（默认 120s 租约）→ 跳过，保持 running；
    - 其他实例但心跳超过租约（进程死亡）→ recovered；
    - instance_id 为空的历史行（旧版本/手工插入）→ 沿用启动恢复语义，避免旧库任务
      永远卡在 running；
    - 本进程内存里仍存活的任务永不恢复（不会被手工 recover 误杀）。
    恢复时同样把关联项目从 auditing/reviewing 回落 audit_failed。
    """
    me = str(instance_id or INSTANCE_ID)
    lease = float(stale_seconds if stale_seconds is not None else LEASE_SECONDS)
    now_ts = time.time()
    now = db.now()
    with db.session() as c:
        rows = [dict(r) for r in c.execute(
            "SELECT id,case_id,status,instance_id,heartbeat,updated_at,started "
            "FROM task_job WHERE status IN ('queued','running')").fetchall()]
    with _LOCK:
        live = {tid for tid, t in TASKS.items()
                if t.get("status") in ("queued", "running")}
    doomed, skipped_other, skipped_live = [], 0, 0
    for r in rows:
        tid = str(r.get("id") or "")
        if tid in live:
            skipped_live += 1
            continue
        inst = str(r.get("instance_id") or "")
        hb = r.get("heartbeat")
        if inst == "":
            # 旧版本写入/手工插入：无归属 = 不可能是当前任何一个新实例，沿用启动恢复
            doomed.append(r)
        elif inst == me:
            # 同实例 ID 重启前残留
            doomed.append(r)
        else:
            if hb is None:
                ts = _parse_ts(r.get("updated_at")) or _parse_ts(r.get("started"))
                if ts is not None and (now_ts - ts) > lease:
                    doomed.append(r)
                else:
                    skipped_other += 1
            elif float(hb) < now_ts - lease:
                doomed.append(r)
            else:
                skipped_other += 1
    recovered_rows = []
    with db.session() as c:
        for r in doomed:
            cur = c.execute(
                "UPDATE task_job SET status='failed', error='interrupted_by_restart', "
                "finished=?, updated_at=? WHERE id=? AND status IN ('queued','running')",
                (now, now, r["id"]))
            if cur.rowcount:
                recovered_rows.append(r)
        c.commit()
    with _LOCK:
        # 本进程内仍存活的旧 worker 也不能再把 failed 写回 done：移除内存条目后
        # _finish 会因找不到 queued/running 行而直接返回，DB 终态以 recover 为准。
        for r in recovered_rows:
            TASKS.pop(r["id"], None)
            _drop_hook(r["id"])
    restored = []
    for r in recovered_rows:
        _audit("task.recovered_failed", r["id"], "interrupted_by_restart")
        cid = str(r["case_id"] or "")
        if not cid:
            continue
        try:
            with db.session() as c:
                cur = c.execute(
                    "UPDATE audit_case SET status='audit_failed', progress=0 "
                    "WHERE id=? AND status IN ('auditing','reviewing')", (cid,))
                changed = cur.rowcount > 0
                c.commit()
            if changed:
                restored.append(cid)
                _audit("project.audit_interrupted", cid, f"task={r['id']}")
        except Exception:
            logging.getLogger(__name__).warning(
                "recover restore case failed case=%s task=%s", cid, r["id"], exc_info=True)
    return {"recovered": len(recovered_rows), "status": "failed",
            "restored_projects": len(restored),
            "skipped_other_instances": skipped_other,
            "skipped_live_tasks": skipped_live,
            "instance_id": me, "lease_seconds": lease}


def _parse_ts(ts) -> float | None:
    s = str(ts or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            return time.mktime(time.strptime(s, fmt))
        except Exception:
            continue
    return None


def purge_result(tid: str, reason: str = "manual", actor: str = "system") -> bool:
    """清理单个终态任务的大结果：只清空 result_json，保留任务状态与时间。"""
    with _LOCK:
        mem = TASKS.get(tid) or {}
        if mem.get("status") in ("queued", "running"):
            return False
    try:
        with db.session() as c:
            r = c.execute("SELECT status, length(result_json) AS size FROM task_job WHERE id=?",
                          (tid,)).fetchone()
            if not r or r["status"] not in TERMINAL_STATUSES or not int(r["size"] or 0):
                return False
            cur = c.execute(
                "UPDATE task_job SET result_json='', updated_at=? WHERE id=? AND status=?",
                (db.now(), tid, r["status"]))
            purged = cur.rowcount > 0
    except Exception:
        logging.getLogger(__name__).warning("purge task result failed tid=%s", tid, exc_info=True)
        return False
    if not purged:
        return False
    with _LOCK:
        if tid in TASKS:
            TASKS[tid]["result"] = None
    _audit("task.result_purged", tid,
           f"reason={reason}|bytes={int(r['size'] or 0)}|status={r['status']}", actor=actor)
    return True


def _gc_memory_locked(keep: int | None = None) -> int:
    """内存 TASKS 回收：运行中任务永不删除，只保留最近 keep 个终态任务。"""
    keep = _env_int("RULEPROOF_TASK_MEMORY_KEEP", 200) if keep is None else int(keep)
    keep = max(1, keep)
    finished = [(t.get("started") or "", tid) for tid, t in TASKS.items()
                if t.get("status") in TERMINAL_STATUSES]
    finished.sort(reverse=True)
    removed = 0
    for _started, tid in finished[keep:]:
        if TASKS.pop(tid, None) is not None:
            _HOOKS.pop(tid, None)
            removed += 1
    return removed


def cleanup_results(retention_days: float | None = None, max_bytes: int | None = None,
                    keep_last: int | None = None, grace_seconds: int | None = None,
                    now_ts: float | None = None, dry_run: bool = False,
                    gc_memory: bool = True) -> dict:
    """清理异步任务大结果 / 过期结果，返回可审计的汇总。

    - retention_days：终态结果超过该天数后清理；<=0 关闭按时间清理。
    - max_bytes：单条 result_json 超过该字节数即视为大结果；<=0 关闭。
    - keep_last：每个项目至少保留最近 N 份结果（只保护时间清理，不保护超大结果）。
    - grace_seconds：大结果至少保留该秒数，避免刚完成的大结果立刻取不到。
    - dry_run：只统计将要清理的行，不写库。
    """
    now = float(now_ts if now_ts is not None else time.time())
    rd = _env_float("RULEPROOF_TASK_RESULT_RETENTION_DAYS", 7.0) if retention_days is None \
        else float(retention_days)
    mb = _env_int("RULEPROOF_TASK_RESULT_MAX_BYTES", 5 * 1024 * 1024) if max_bytes is None \
        else int(max_bytes)
    kl = _env_int("RULEPROOF_TASK_RESULT_KEEP_LAST", 20) if keep_last is None else int(keep_last)
    grace = _env_int("RULEPROOF_TASK_RESULT_LARGE_GRACE", 3600) if grace_seconds is None \
        else int(grace_seconds)
    rd, mb, kl, grace = max(0.0, rd), max(0, mb), max(0, kl), max(0, grace)

    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT rowid AS _rid, id, name, status, case_id, finished, started, updated_at, "
                "length(result_json) AS size FROM task_job "
                "WHERE status IN ('done','failed','cancelled','timeout') "
                "AND COALESCE(length(result_json),0) > 0").fetchall()
    except Exception:
        logging.getLogger(__name__).warning("task cleanup scan failed", exc_info=True)
        return {"scanned": 0, "purged": 0, "freed_bytes": 0, "purged_ids": [],
                "error": "scan_failed"}

    recs = []
    for r in rows:
        d = dict(r)
        ts = _parse_ts(d.get("finished")) or _parse_ts(d.get("updated_at")) or _parse_ts(d.get("started"))
        d["ts"] = ts
        d["age"] = None if ts is None else max(0.0, now - ts)
        d["size"] = int(d.get("size") or 0)
        recs.append(d)

    protected = set()
    if kl > 0:
        by_case = {}
        for rec in recs:
            by_case.setdefault(str(rec.get("case_id") or ""), []).append(rec)
        for items in by_case.values():
            items.sort(key=lambda x: ((x.get("ts") or 0.0), int(x.get("_rid") or 0)), reverse=True)
            protected.update(x["id"] for x in items[:kl])

    planned = []
    for rec in recs:
        age = rec.get("age")
        reason = ""
        # 大结果：超过硬上限，过 grace 后即使是最新结果也清理（keep_last 不保护）
        if mb > 0 and rec["size"] > mb and (grace <= 0 or age is None or age >= grace):
            reason = "oversize"
        # 过期结果：按项目保留最近 keep_last 份
        elif rd > 0 and rec["id"] not in protected and (age is None or age > rd * 86400):
            reason = "expired"
        if reason:
            planned.append((rec, reason))

    freed = sum(rec["size"] for rec, _reason in planned)
    purged_ids = []
    if planned and not dry_run:
        try:
            with db.session() as c:
                for rec, _reason in planned:
                    cur = c.execute(
                        "UPDATE task_job SET result_json='', updated_at=? WHERE id=? AND status=?",
                        (db.now(), rec["id"], rec["status"]))
                    if cur.rowcount > 0:
                        purged_ids.append(rec["id"])
        except Exception:
            logging.getLogger(__name__).warning("task cleanup update failed", exc_info=True)
            return {"scanned": len(recs), "purged": 0, "freed_bytes": 0, "purged_ids": [],
                    "error": "update_failed"}
        with _LOCK:
            for tid in purged_ids:
                if tid in TASKS:
                    TASKS[tid]["result"] = None
        for rec, reason in planned:
            if rec["id"] in purged_ids:
                _audit("task.result_purged", rec["id"],
                       f"reason={reason}|bytes={rec['size']}|status={rec['status']}")
        if len(planned) > len(purged_ids):
            _audit("task.results_purged", "cleanup",
                   f"requested={len(planned)}|purged={len(purged_ids)}|freed={freed}")
    elif dry_run:
        purged_ids = [rec["id"] for rec, _reason in planned]

    removed_mem = 0
    if gc_memory and not dry_run:
        with _LOCK:
            removed_mem = _gc_memory_locked()
    return {"scanned": len(recs), "purged": len(purged_ids), "freed_bytes": freed,
            "purged_ids": purged_ids, "protected": len(protected), "dry_run": bool(dry_run),
            "memory_gc": removed_mem, "reasons": [r for _rec, r in planned]}


# 便于运维/测试使用的短别名
cleanup = cleanup_results


def maybe_cleanup(force: bool = False, **kwargs) -> dict:
    """节流清理：默认每小时最多执行一次；force=True 立即执行（运维/测试）。"""
    global _LAST_CLEANUP
    interval = max(1, _env_int("RULEPROOF_TASK_CLEANUP_INTERVAL", 3600))
    now = time.time()
    with _CLEANUP_LOCK:
        if not force and (now - _LAST_CLEANUP) < interval:
            return {"skipped": True, "reason": "throttled", "purged": 0}
        _LAST_CLEANUP = now
    return cleanup_results(**kwargs)
