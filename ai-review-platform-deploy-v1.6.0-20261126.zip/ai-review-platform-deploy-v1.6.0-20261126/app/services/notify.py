"""站内通知/告警 + 分渠道（站内/邮件/企微，配置门控）。"""
import json
import re

from .. import db
from .. import repositories as R


# ---------------- 可区分的业务异常（路由据此映射 400/403/404） ----------------
class NotifyConfigError(ValueError):
    """通知配置入参非法（非对象等）→ HTTP 400 invalid_config。"""
    code = "invalid_config"


class NotifyTemplateError(ValueError):
    """模板含 HTML/脚本或非法占位符 → HTTP 400 invalid_template。"""
    code = "invalid_template"


class NotificationNotFound(ValueError):
    """消息不存在 → HTTP 404 not_found（与越权 403 区分）。"""
    code = "not_found"


class NotificationForbidden(ValueError):
    """无权操作他人消息 → HTTP 403 forbidden。"""
    code = "forbidden"


# 模板只允许这三个占位符 + 纯文本；HTML 标签一律拒绝（不把清洗责任推给每个消费端）
_TEMPLATE_FIELDS = ("title_template", "detail_template")
_TEMPLATE_PLACEHOLDERS = ("title", "detail", "event")
_HTML_TAG_RE = re.compile(r"</?[A-Za-z][^>]*>")


# ---------------- SSE 实时推送（秒级） ----------------
import queue as _queue
import logging
import threading as _threading

_SUBS = {}          # actor -> list[queue.Queue]
_SUBS_LOCK = _threading.Lock()


def subscribe(actor: str):
    q = _queue.Queue(maxsize=100)
    with _SUBS_LOCK:
        _SUBS.setdefault(actor, []).append(q)
    return q


def unsubscribe(actor: str, q) -> None:
    with _SUBS_LOCK:
        lst = _SUBS.get(actor) or []
        if q in lst:
            lst.remove(q)
        if not lst:
            _SUBS.pop(actor, None)


def _push(actor: str, payload: dict) -> None:
    with _SUBS_LOCK:
        subs = list(_SUBS.get(actor) or [])
    for q in subs:
        try:
            q.put_nowait(payload)
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)


_ROLE_CODES = ("reviewer", "admin", "super_admin")
# T-115：未登记事件的可见角色回退（不得回退全角色；配置页事件以 NOTIFY_EVENTS 为唯一口径）。
_UNKNOWN_EVENT_AUDIENCES = ["admin"]
_UNKNOWN_EVENT_WARNED = set()


def _roles_of(uid: str) -> set:
    if not uid:
        return set()
    try:
        with db.session() as c:
            rows = c.execute("SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?", (uid,)).fetchall()
        return {r["code"] for r in rows}
    except Exception:
        logging.getLogger(__name__).debug("notification role lookup skipped", exc_info=True)
        return set()


def _delivery_for(type_: str, actor: str = ""):
    """返回 (enabled, channels, audiences)。按事件配置和接收人角色做双重门控。

    配置读取按“接收人所属租户”而不是当前线程上下文，避免后台 worker 串租户。
    """
    enabled, channels, audiences = _route_for(type_, _tenant_of(actor) if actor else None)
    if not enabled:
        return False, channels, audiences
    if actor:
        roles = _roles_of(actor)
        if roles and audiences and not (roles & set(audiences)):
            return False, channels, audiences
        if not roles:
            return False, channels, audiences
    return True, channels, audiences


def _render_text(type_: str, title: str, detail: str, tenant_id: str | None = None) -> tuple:
    """按事件配置渲染标题/正文模板；模板只允许 title/detail/event 变量。"""
    try:
        cfg = (get_config(tenant_id).get("config") or {}).get(type_) or {}
        class _Safe(dict):
            def __missing__(self, key): return "{" + key + "}"
        ctx = _Safe(title=title or "", detail=detail or "", event=type_ or "")
        t = str(cfg.get("title_template") or "{title}").format_map(ctx)
        d = str(cfg.get("detail_template") or "{detail}").format_map(ctx)
        return (t or title or "通知")[:120], (d or detail or "")[:2000]
    except Exception:
        return title or "通知", detail or ""


def notify(actor: str, type_: str, title: str, detail: str = "") -> dict:
    enabled, _channels, _aud = _delivery_for(type_, actor)
    if not enabled:
        return {}
    _u = R.users.get(actor) or {}
    tenant_id = _tenant_of(actor)
    if not tenant_id:
        # 后台/无上下文场景兜底取当前请求租户；仍为空则显式告警（该行只对无租户角色可见）
        try:
            from . import ctx as _ctx
            tenant_id = str((_ctx.get_context() or {}).get("tenant_id") or "")
        except Exception:
            tenant_id = ""
    if not tenant_id:
        logging.getLogger(__name__).warning(
            "notification tenant unresolved：actor=%s type=%s；按空租户落库，仅对无租户角色可见",
            actor, type_)
    title, detail = _render_text(type_, title, detail, tenant_id)
    nid = db.new_id("ntf")
    R.notifications.insert(id=nid, actor=actor, type=type_, title=title,
                           detail=detail, read=0, created_at=db.now(),
                           tenant_id=tenant_id,
                           workspace_id=_u.get("current_workspace_id") or _u.get("workspace_id") or "")
    _push(actor, {"id": nid, "type": type_, "title": title, "detail": detail})
    return {"id": nid}


def _tenant_of(uid: str) -> str:
    """系统作用域读取账号真实租户（SQL 直查，不经 ctx 租户隔离）。

    旧实现用 R.users.get(uid)，受当前请求上下文强制隔离：跨租户 actor 查不到 →
    tenant_id 落空串 → 空租户行被所有租户当成本租户数据（B7-E1 泄漏根因）。
    """
    if not uid:
        return ""
    try:
        with db.session() as c:
            row = c.execute("SELECT tenant_id FROM user WHERE id=?", (uid,)).fetchone()
        return str((row["tenant_id"] if row is not None else "") or "")
    except Exception:
        logging.getLogger(__name__).warning(
            "notification tenant lookup failed actor=%s", uid, exc_info=True)
        return ""


def notify_project_pending(owner: str, title: str, detail: str = "") -> list:
    """项目审核完成/退回：通知项目审核员；本租户业务管理员按事件配置接收汇总提醒。"""
    sent = []
    tenant_id = _tenant_of(owner)
    if owner:
        r = notify(owner, "project.pending_review", title, detail)
        if r.get("id"):
            sent.append(owner)
    # 业务管理员只接收本租户汇总，不发给其他租户，也不重复发给 owner
    for uid in notify_role("admin", "project.pending_review", title, detail, exclude=owner, tenant_id=tenant_id):
        sent.append(uid)
    return sent

def list_for(actor: str, unread_only: bool = False, limit: int = 50) -> list:
    where = "actor=?" + (" AND read=0" if unread_only else "")
    return R.notifications.list(where, (actor,), order="created_at DESC", limit=limit)


def unread_count(actor: str) -> int:
    return R.notifications.count("actor=? AND read=0", (actor,))


def mark_read(notification_id: str, actor: str = "") -> dict:
    n = R.notifications.get(notification_id)
    if not n:
        # 不存在 ≠ 越权：路由必须映射 404，而不是用 403 混淆两种语义
        raise NotificationNotFound("消息不存在")
    if actor and (n.get("actor") or "") != actor:
        raise NotificationForbidden("无权操作该消息")
    R.notifications.update(notification_id, read=1)
    return {"id": notification_id, "read": 1}


def mark_all_read(actor: str) -> dict:
    """把当前用户的所有未读消息标为已读。"""
    if not actor:
        return {"updated": 0}
    with db.session() as c:
        cur = c.execute("UPDATE notification SET read=1 WHERE actor=? AND read=0", (actor,))
        c.commit()
        return {"updated": cur.rowcount or 0}


def alerts() -> list:
    """主动告警：override 率超阈值的规则。"""
    from .. import config
    from .evolution import evolution_suggestions
    th = config.ALERT_OVERRIDE_THRESHOLD
    out = []
    for s in evolution_suggestions():
        # 告警口径：必须有已复核样本，且误报率超阈值；「从未命中」只算未使用，不算告警
        if s.get("decided", 0) > 0 and s["override_rate"] >= th:
            out.append({"rule_code": s["rule_code"], "name": s["name"],
                        "override_rate": s["override_rate"], "decided": s["decided"],
                        "false_positive": s["false_positive"], "suggestion": s["suggestion"]})
    return out



def notify_role(role_code: str, type_: str, title: str, detail: str = "", exclude: str = "",
                tenant_id: str = "") -> list:
    """给本租户某角色下的用户发通知；事件配置的可见角色优先。"""
    if not tenant_id:
        try:
            from . import ctx as _ctx
            tenant_id = (_ctx.get_context() or {}).get("tenant_id", "")
        except Exception:
            tenant_id = ""
    enabled, channels, audiences = _route_for(type_, tenant_id)
    if not enabled or role_code not in audiences:
        return []
    sql = ("SELECT u.id FROM user u JOIN user_role ur ON ur.user_id=u.id "
           "JOIN role r ON r.id=ur.role_id WHERE r.code=? AND COALESCE(u.status,'active')='active'")
    params = [role_code]
    if tenant_id:
        # P1-B7-01 ③：super_admin 也按「事件来源租户」投递，不再向所有租户超管广播。
        # 兼容历史种子账号：默认租户下 tenant_id 为空的旧账号仍属默认租户。
        if tenant_id == "t-default":
            sql += " AND (u.tenant_id=? OR u.tenant_id IS NULL OR u.tenant_id='')"
        else:
            sql += " AND u.tenant_id=?"
        params.append(tenant_id)
    with db.session() as c:
        rows = c.execute(sql, tuple(params)).fetchall()
    ids = [r["id"] for r in rows if r["id"] != exclude]
    sent = []
    for uid in ids:
        if notify(uid, type_, title, detail).get("id"):
            sent.append(uid)
    return sent

_LAST_INCIDENT = {}
def notify_system_incident(title: str, detail: str = "") -> list:
    """系统级异常通知：直接通知系统管理员，按事件配置去重。"""
    import hashlib as _hl, time as _t
    key = _hl.sha1(f"{title}|{detail[:120]}".encode("utf-8")).hexdigest()
    now = _t.time()
    if now - float(_LAST_INCIDENT.get(key) or 0) < 60:
        return []
    _LAST_INCIDENT[key] = now
    try:
        return notify_role("super_admin", "system.incident", title, detail[:500])
    except Exception:
        logging.getLogger(__name__).debug('system incident notify skipped', exc_info=True)
        return []


def notify_admins(type_: str, title: str, detail: str = "", tenant_id: str = "") -> list:
    """按事件可见角色通知管理员；只发本租户，系统管理员事件不跨租户。"""
    ids = set(notify_role("admin", type_, title, detail, tenant_id=tenant_id))
    ids |= set(notify_role("super_admin", type_, title, detail, tenant_id=tenant_id))
    return list(ids)


def channel_status() -> list:
    """当前产品只发送站内消息；保留接口用于前端兼容。"""
    return [{"key": "inapp", "name": "站内消息", "enabled": True, "desc": "登录后在消息中心查看"}]


def test_channel() -> dict:
    return {"ok": False, "detail": "当前版本只支持站内消息，无需外部渠道配置"}


# ---------------- 消息配置 / 事件订阅 ----------------
NOTIFY_EVENTS = [
    {"key": "evidence.requested", "name": "补证事项待处理", "priority": "必推",
     "desc": "fallback=ask 自动生成补证事项后通知项目负责人",
     "trigger": "D5 证据不足且 fallback=ask", "audiences": ["reviewer", "admin"],
     "default_enabled": True, "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "project.pending_review", "name": "项目待复核", "priority": "必推",
     "desc": "项目审核完成或复核退回后，通知项目审核员和业务管理员",
     "trigger": "审核完成且存在待复核发现；管理员退回复核", "audiences": ["reviewer", "admin"],
     "default_enabled": True, "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "project.timeout", "name": "项目超时", "priority": "必推",
     "desc": "项目超过约定时长仍未完成", "trigger": "定时扫描达到超时阈值",
     "audiences": ["reviewer", "admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "rule_pending", "name": "规则待审批", "priority": "必推",
     "desc": "审核员提交规则后通知业务管理员", "trigger": "规则提交审批",
     "audiences": ["admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "rule_created", "name": "新规则待复核", "priority": "建议",
     "desc": "新规则生成后通知业务管理员", "trigger": "创建规则草稿",
     "audiences": ["admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "rule.feedback", "name": "规则反向反馈", "priority": "建议",
     "desc": "审核员误报/补证反馈累积后通知业务管理员", "trigger": "反馈达到阈值",
     "audiences": ["admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "rule.updated", "name": "规则更新", "priority": "建议",
     "desc": "规则发布后通知审核员", "trigger": "规则批准并发布",
     "audiences": ["reviewer"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    # T-115：rule.forked 是真实投递事件（rule.update_draft 编辑已发布规则后通知审核员
    # “旧生效版本继续执行到新版本发布”），此前未登记 → 配置页不可见、可见角色不受控。
    {"key": "rule.forked", "name": "规则编辑待重审", "priority": "建议",
     "desc": "编辑已发布/已批准规则生成待发布草稿后，通知审核员旧版本继续生效、新版本发布后替换",
     "trigger": "编辑已发布/已批准规则（fork 新草稿）",
     "audiences": ["reviewer"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    # T-115：point.stale 由 point_confirm.stale_for_case 真实投递（项目负责人 + 业务管理员）。
    {"key": "point.stale", "name": "点位判据更新", "priority": "必推",
     "desc": "项目已有发现基于旧点位库版本时，通知项目负责人与业务管理员复核/重跑",
     "trigger": "点位库版本升级后扫描到过期发现（同项目同版本去重）",
     "audiences": ["reviewer", "admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "rule.conflict", "name": "规则冲突", "priority": "必推", "center_visible": False,
     "desc": "规则之间出现冲突后通知业务管理员", "trigger": "发布或检测到规则冲突",
     "audiences": ["admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "type_created", "name": "文档类型待复核", "priority": "可选",
     "desc": "新增文档类型后通知业务管理员", "trigger": "创建文档类型",
     "audiences": ["admin"], "default_enabled": False,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "system.llm_fail", "name": "模型调用失败", "priority": "必推",
     "desc": "语义判断或模型调用异常时通知系统管理员", "trigger": "模型调用异常",
     "audiences": ["super_admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "system.incident", "name": "系统异常", "priority": "必推",
     "desc": "服务请求、智能体执行、开放回调等出现异常时通知系统管理员", "trigger": "未处理异常或执行失败",
     "audiences": ["super_admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
    {"key": "jev.alert", "name": "JEV 低置信提醒", "priority": "建议",
     "desc": "审核出现需要人工确认的低置信判定时，提醒审核员和业务管理员",
     "trigger": "批次判定置信度低于 JEV 阈值", "audiences": ["reviewer", "admin"],
     "default_enabled": True, "title_template": "【JEV 低置信】{title}", "detail_template": "{detail}"},
    {"key": "agent.fp_auto", "name": "智能体自动归因", "priority": "可选",
     "desc": "智能体完成误报自动归因后通知业务管理员", "trigger": "反馈自动归因完成",
     "audiences": ["admin"], "default_enabled": False,
     "title_template": "{title}", "detail_template": "{detail}"},
    # T-115：通知配置页“测试发送”专用事件。只发操作人本人，不在配置页事件列表中展示
    # （center_visible=False），避免测试消息被当成业务事件；同时从“未登记事件”里移出。
    {"key": "system.test", "name": "通知测试", "priority": "可选", "center_visible": False,
     "desc": "通知配置页测试发送：仅向当前操作人本人写一条真实站内消息",
     "trigger": "通知配置页手动测试发送",
     "audiences": ["super_admin"], "default_enabled": True,
     "title_template": "{title}", "detail_template": "{detail}"},
]
# 每个事件预置一套可读模板；管理员可以在此基础上修改，不能从空白开始。
_TEMPLATE_DEFAULTS = {
    "project.pending_review": ("【项目待复核】{title}", "{detail}\n请进入项目列表完成复核。"),
    "project.timeout": ("【项目超时】{title}", "{detail}\n请检查项目进度并及时处理。"),
    "rule_pending": ("【规则待审批】{title}", "{detail}\n请进入规则库完成审批。"),
    "rule_created": ("【新规则待复核】{title}", "{detail}\n请核对规则内容后审批。"),
    "rule.feedback": ("【规则反馈】{title}", "{detail}\n请查看反馈并评估是否需要修订规则。"),
    "evidence.requested": ("【补证待处理】{title}", "{detail}\n请补齐材料后登记补证。"),
    "rule.updated": ("【规则更新】{title}", "{detail}\n规则已更新，请在下一次审核前确认。"),
    "rule.forked": ("【规则编辑待重审】{title}", "{detail}\n请确认新版本内容，发布后替换旧生效版本。"),
    "point.stale": ("【点位判据更新】{title}", "{detail}\n请重新确认点位或重跑审核后再出报告。"),
    "rule.conflict": ("【规则冲突】{title}", "{detail}\n请进入冲突提醒处理。"),
    "type_created": ("【文档类型待复核】{title}", "{detail}\n请确认该文档类型是否启用。"),
    "system.llm_fail": ("【模型异常】{title}", "{detail}\n请检查模型配置与调用日志。"),
    "system.incident": ("【系统异常】{title}", "{detail}\n请检查服务日志与运行状态。"),
    "agent.fp_auto": ("【智能体归因】{title}", "{detail}\n请查看智能体归因建议。"),
    "jev.alert": ("【JEV 低置信】{title}", "{detail}\n请到审核工作台确认低置信判定。"),
}
for _e in NOTIFY_EVENTS:
    _tt, _dt = _TEMPLATE_DEFAULTS.get(_e["key"], ("{title}", "{detail}"))
    _e["title_template"], _e["detail_template"] = _tt, _dt

_DEFAULT_AUD = {e["key"]: e.get("audiences") or ["admin"] for e in NOTIFY_EVENTS}
_DEFAULT_ENABLED = {e["key"]: e.get("default_enabled", True) for e in NOTIFY_EVENTS}

def _clean_audiences(v, key: str) -> list:
    vals = [x for x in (v if isinstance(v, list) else []) if x in _ROLE_CODES]
    return vals if vals else list(_DEFAULT_AUD.get(key) or ["admin"])


def _setting_tenant(tenant_id: str | None = None) -> str:
    """解析通知配置所属租户：显式参数 > 当前请求上下文 > 空（=平台默认 global）。"""
    if tenant_id is not None:
        return str(tenant_id or "")
    try:
        from . import ctx as _ctx
        return str((_ctx.get_context() or {}).get("tenant_id") or "")
    except Exception:
        return ""


def _config_scope(tenant_id: str = "") -> str:
    """notify_setting 主键：租户级 id=tenant:<tid>；平台默认单例保留 id=global。"""
    return f"tenant:{tenant_id}" if tenant_id else "global"


def _load_saved_config(tenant_id: str = "") -> dict:
    """读取配置：优先本租户行，缺失时回退平台 global（只读默认，不会跨租户写）。"""
    ids = [_config_scope(tenant_id)]
    if tenant_id:
        ids.append("global")
    for _id in ids:
        try:
            with db.session() as c:
                row = c.execute("SELECT config_json FROM notify_setting WHERE id=?", (_id,)).fetchone()
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
            return {}
        if row and row["config_json"]:
            try:
                return __import__("json").loads(row["config_json"] or "{}") or {}
            except Exception:
                return {}
    return {}


def get_config(tenant_id: str | None = None) -> dict:
    default = {}
    for e in NOTIFY_EVENTS:
        default[e["key"]] = {
            "enabled": bool(e.get("default_enabled", True)),
            "audiences": list(e.get("audiences") or ["admin"]),
            "title_template": e.get("title_template") or "{title}",
            "detail_template": e.get("detail_template") or "{detail}",
        }
    tid = _setting_tenant(tenant_id)
    for k, v in (_load_saved_config(tid) or {}).items():
        if k in default and isinstance(v, dict):
            default[k]["enabled"] = bool(v.get("enabled", default[k]["enabled"]))
            default[k]["audiences"] = _clean_audiences(v.get("audiences"), k)
            _tt = str(v.get("title_template") or "").strip()
            _dt = str(v.get("detail_template") or "").strip()
            _base = _TEMPLATE_DEFAULTS.get(k, (default[k]["title_template"], default[k]["detail_template"]))
            default[k]["title_template"] = (_base[0] if _tt in ("", "{title}") else _tt)[:200]
            default[k]["detail_template"] = (_base[1] if _dt in ("", "{detail}") else _dt)[:2000]
    return {"events": NOTIFY_EVENTS, "config": default, "channel": "inapp",
            "scope": _config_scope(tid), "tenant_id": tid}


def _validate_template_text(text: str, event_key: str, field: str) -> None:
    """模板只允许纯文本 + {title}/{detail}/{event}；HTML/脚本一律 400。"""
    raw = str(text or "")
    m = _HTML_TAG_RE.search(raw)
    if m:
        raise NotifyTemplateError(
            f"事件 {event_key} 的 {field} 含 HTML/脚本片段「{m.group(0)[:40]}」；"
            "模板只允许纯文本与 {title}/{detail}/{event} 占位符")
    for token in re.findall(r"\{([^{}]*)\}", raw):
        if token and token not in _TEMPLATE_PLACEHOLDERS:
            raise NotifyTemplateError(
                f"事件 {event_key} 的 {field} 含非法占位符 {{{token}}}；"
                f"只允许 {list(_TEMPLATE_PLACEHOLDERS)}")


def save_config(config: dict, actor: str = "", tenant_id: str | None = None,
                actor_role: str = "") -> dict:
    """保存通知配置（P1-B7-02：配置变更必须留审计）。

    作用域：租户级（id=tenant:<tid>）；上下文无租户时写平台默认单例 global。
    权限：HTTP/CLI 路由只允许系统管理员调用；此处做服务层兜底——显式传入
    actor_role 且不是 super_admin 时直接拒绝（业务管理员不得改全局配置）。
    入参/模板校验失败抛 NotifyConfigError / NotifyTemplateError（路由映射 400）。
    无实际变更不刷审计；变更写 notify.config_updated（before/after 只记变更键）。
    """
    if actor_role and actor_role != "super_admin":
        raise PermissionError("仅系统管理员可配置消息")
    # P2-B7-05：非对象入参不再触发未捕获 AttributeError → 断连
    if not isinstance(config, dict):
        raise NotifyConfigError(
            f"通知配置必须是 JSON 对象，收到 {type(config).__name__}；"
            '请求体形如 {"config": {"事件key": {...}}}')
    clean = {}
    for e in NOTIFY_EVENTS:
        v = config.get(e["key"]) or {}
        if not isinstance(v, dict):
            raise NotifyConfigError(f"事件 {e['key']} 的配置必须是对象，收到 {type(v).__name__}")
        title_t = str(v.get("title_template") or e.get("title_template") or "{title}")[:200]
        detail_t = str(v.get("detail_template") or e.get("detail_template") or "{detail}")[:2000]
        # P2-B7-04：模板清洗（不把 XSS 清洗责任推给每个消费端）
        _validate_template_text(title_t, e["key"], "title_template")
        _validate_template_text(detail_t, e["key"], "detail_template")
        clean[e["key"]] = {
            "enabled": bool(v.get("enabled", e.get("default_enabled", True))),
            "audiences": _clean_audiences(v.get("audiences"), e["key"]),
            "title_template": title_t, "detail_template": detail_t,
        }
    tid = _setting_tenant(tenant_id)
    rid = _config_scope(tid)
    # diff：只记用户可见的真实变更（enabled/audiences/模板），保存前值用于审计 before
    try:
        before = (get_config(tid) or {}).get("config") or {}
    except Exception:  # noqa: BLE001 - 读旧配置失败不阻断保存，但 audit 里标明
        before = {}
    changes, before_changed, after_changed = {}, {}, {}
    for key, new in clean.items():
        old = before.get(key) if isinstance(before.get(key), dict) else {}
        diff, dold, dnew = {}, {}, {}
        for field in ("enabled", "audiences", "title_template", "detail_template"):
            if old.get(field) != new.get(field):
                diff[field] = {"before": old.get(field), "after": new.get(field)}
                dold[field] = old.get(field)
                dnew[field] = new.get(field)
        if diff:
            changes[key] = diff
            before_changed[key] = dold
            after_changed[key] = dnew
    with db.session() as c:
        c.execute("INSERT INTO notify_setting(id,config_json,updated_at,updated_by,tenant_id) VALUES(?,?,?,?,?) "
                  "ON CONFLICT(id) DO UPDATE SET config_json=excluded.config_json,updated_at=excluded.updated_at,"
                  "updated_by=excluded.updated_by,tenant_id=excluded.tenant_id",
                  (rid, json.dumps(clean, ensure_ascii=False), db.now(), actor or "", tid))
        c.commit()
    audit_payload = {"scope": rid, "tenant_id": tid, "actor_role": actor_role or "",
                     "changed_keys": sorted(changes), "changes": changes,
                     "note": "只记录发生变更的事件/字段；无变更不写审计"}
    if changes:
        try:
            R.audit_logs.log(
                actor=actor or "system", action="notify.config_updated", object=rid,
                before=json.dumps(before_changed, ensure_ascii=False)[:4000],
                after=json.dumps(audit_payload, ensure_ascii=False)[:4000])
        except Exception as e:  # noqa: BLE001 - 铁律 4：配置已生效但留痕失败必须显式
            logging.getLogger(__name__).error(
                "notify config audit failed scope=%s", rid, exc_info=True)
            raise RuntimeError(
                f"通知配置已保存并生效，但审计留痕失败：{type(e).__name__}: "
                f"{str(e)[:120]}；请重试保存以补审计") from e
    return {"ok": True, "config": clean, "channel": "inapp", "scope": rid,
            "tenant_id": tid, "changed_keys": sorted(changes),
            "audit_written": bool(changes)}


def _route_for(type_: str, tenant_id: str | None = None):
    """事件路由：按接收方租户配置读取，缺失回退平台默认；只保留站内渠道。

    T-115：**未登记事件不再回退全角色**。历史行为是 `list(_ROLE_CODES)`（reviewer/
    admin/super_admin 全可见），导致“代码里新发的事件没登记 NOTIFY_EVENTS → 配置页
    看不到、可见角色不受控”。现在回退为仅业务管理员（admin）+ warning，且只告警一次；
    需要更宽/更窄可见面的真实事件必须显式登记到 NOTIFY_EVENTS。
    """
    try:
        cfg = get_config(tenant_id).get("config", {}).get(type_)
        if cfg is None:
            if type_ not in _UNKNOWN_EVENT_WARNED:
                _UNKNOWN_EVENT_WARNED.add(type_)
                logging.getLogger(__name__).warning(
                    "通知事件未登记 NOTIFY_EVENTS：%s（可见角色回退为 admin；请显式登记）", type_)
            return True, ["inapp"], list(_UNKNOWN_EVENT_AUDIENCES)
        return bool(cfg.get("enabled", True)), ["inapp"], (cfg.get("audiences") or [])
    except Exception:
        logging.getLogger(__name__).warning("通知事件路由读取失败：%s", type_, exc_info=True)
        return True, ["inapp"], list(_UNKNOWN_EVENT_AUDIENCES)
