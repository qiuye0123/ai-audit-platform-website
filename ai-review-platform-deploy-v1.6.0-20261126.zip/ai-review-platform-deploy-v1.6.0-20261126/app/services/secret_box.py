"""应用密钥静态加密（至少保证 DB dump 不出现明文 AppSecret / model_config.api_key）。

实现：HMAC-SHA256 计数器流 + HMAC 完整性标签，格式 `enc1:<base64(nonce|tag|cipher)>`。
主密钥来自 RULEPROOF_SECRET_KEY，未设置时回退 session secret；生产必须显式设置。

L147（2026-11-25，P0-2/P0-3 最小整改）在本模块追加：
1. **主密钥就绪判定**（``master_key_status``/``assert_master_ready``）：模型 API Key
   加密/迁移要求显式 ``RULEPROOF_SECRET_KEY``（或显式允许派生主密钥），否则
   fail-closed，不再静默使用弱派生密钥；
2. **双读兼容**（``open_api_key``）：新格式 ``enc1:`` 解密，历史明文原样返回，
   允许滚动迁移；
3. **model_config.api_key 迁移/回滚**（``migrate_model_api_keys`` /
   ``rollback_model_api_keys``）：单事务 + VACUUM，迁移后 DB 文件不留明文；
4. **上传附件加密开关骨架**（``RULEPROOF_FILE_ENCRYPT`` + ``seal_bytes`` /
   ``open_bytes``）：只做密码学接口与状态，不接入上传落盘（见
   ``docs/qa/安全整改_20261125.md`` §P0-2 附件加密设计与未实现范围）。

限制（如实）：model.py / llm_router.py 的**运行时读路径**不在本 lane 写作用域，
因此默认开关为 0；迁移入口在 ``RULEPROOF_MODEL_KEY_READPATH`` 未置 1 时拒绝执行，
避免“加密后模型调用 401”的半成品状态。
"""
from __future__ import annotations

import logging

import base64
import hashlib
import hmac
import os
import sqlite3
import sys
import tempfile
import time
from pathlib import Path

_PREFIX = "enc1:"
_FILE_MAGIC = b"RPF1\x00"
_ALLOWED_DB_PREFIX = ("/tmp/", "/private/tmp/", "/var/folders/", "/private/var/folders/")
_PRODUCT_DB = Path(__file__).resolve().parents[2] / "data" / "ruleproof.db"


class SecretKeyNotConfigured(RuntimeError):
    """加密主密钥缺失/未就绪时 fail-closed 抛出（禁止用弱默认密钥静默加密）。"""


def _truthy(value) -> bool:
    return str(value or "").strip().lower() in ("1", "true", "yes", "on")


# ---------------------------------------------------------------------------
# 主密钥
# ---------------------------------------------------------------------------
def _master() -> bytes:
    raw = os.environ.get("RULEPROOF_SECRET_KEY") or ""
    if not raw:
        try:
            from .. import auth
            raw = auth.session_secret()
        except Exception:
            raw = "ruleproof-local-secret-box"
    return hashlib.sha256(b"ruleproof-secret-box:" + raw.encode()).digest()


def master_key_status() -> dict:
    """主密钥就绪状态（不返回密钥本身，可安全进状态接口/日志）。

    - ready=True：有显式 RULEPROOF_SECRET_KEY，或显式允许派生
      （RULEPROOF_ALLOW_DERIVED_MASTER=1 且会话密钥可用）；
    - ready=False：加密/迁移必须 fail-closed，返回明确指引。
    """
    explicit = (os.environ.get("RULEPROOF_SECRET_KEY") or "").strip()
    allow_derived = _truthy(os.environ.get("RULEPROOF_ALLOW_DERIVED_MASTER"))
    session_secret = ""
    try:
        from .. import auth
        session_secret = str(auth.session_secret() or "")
    except Exception:
        session_secret = ""
    if explicit:
        source = "env"
    elif allow_derived and session_secret:
        source = "session-derived"
    else:
        source = "none"
    ready = source != "none"
    note = ""
    if not ready:
        note = ("缺少加密主密钥：请配置 RULEPROOF_SECRET_KEY（≥32 字节随机串，独立托管）；"
                "如确需复用会话密钥派生，需显式设置 RULEPROOF_ALLOW_DERIVED_MASTER=1")
    elif source == "session-derived":
        note = ("当前主密钥由会话密钥派生：轮换 RULEPROOF_SESSION_SECRET 将导致已加密数据"
                "无法解密，仅建议临时/测试使用")
    return {"ready": ready, "source": source, "explicit": bool(explicit),
            "derived_allowed": allow_derived, "note": note}


def assert_master_ready(context: str = "静态加密") -> dict:
    """主密钥未就绪时 fail-closed（调用方不得吞异常后继续明文落盘）。"""
    st = master_key_status()
    if not st["ready"]:
        raise SecretKeyNotConfigured(f"{context} 已 fail-closed：{st['note']}")
    return st


# ---------------------------------------------------------------------------
# 字符串密钥加解密（enc1: 格式；兼容历史明文）
# ---------------------------------------------------------------------------
def _keystream(key: bytes, nonce: bytes, n: int) -> bytes:
    out = bytearray()
    ctr = 0
    while len(out) < n:
        out.extend(hmac.new(key, b"stream" + nonce + ctr.to_bytes(4, "big"), hashlib.sha256).digest())
        ctr += 1
    return bytes(out[:n])


def seal(secret: str) -> str:
    raw = str(secret or "").encode()
    nonce = os.urandom(16)
    key = _master()
    enc = bytes(a ^ b for a, b in zip(raw, _keystream(key, nonce, len(raw))))
    tag = hmac.new(key, b"tag" + nonce + enc, hashlib.sha256).digest()[:16]
    return _PREFIX + base64.urlsafe_b64encode(nonce + tag + enc).decode()


def open_secret(value: str) -> str:
    text = str(value or "")
    if not text.startswith(_PREFIX):
        # 兼容历史明文；调用方应在新写入时密封
        return text
    try:
        blob = base64.urlsafe_b64decode(text[len(_PREFIX):].encode())
        nonce, tag, enc = blob[:16], blob[16:32], blob[32:]
        key = _master()
        want = hmac.new(key, b"tag" + nonce + enc, hashlib.sha256).digest()[:16]
        if not hmac.compare_digest(tag, want):
            raise ValueError("secret integrity check failed")
        raw = bytes(a ^ b for a, b in zip(enc, _keystream(key, nonce, len(enc))))
        return raw.decode()
    except Exception as e:
        raise ValueError("secret decrypt failed") from e


def is_sealed(value) -> bool:
    return str(value or "").startswith(_PREFIX)


def open_api_key(value) -> str:
    """model_config.api_key 双读：加密值解密；历史明文原样返回。"""
    return open_secret(str(value or ""))


def mask_secret(value) -> str:
    """展示脱敏：绝不解密、绝不返回密文片段/明文字符。"""
    text = str(value or "")
    if not text:
        return "未配置"
    if is_sealed(text):
        return "已加密（不可显示）"
    return "已配置（已脱敏）"


# ---------------------------------------------------------------------------
# model_config.api_key：加密存储开关 / 迁移 / 回滚 / 状态
# ---------------------------------------------------------------------------
def model_key_encrypt_enabled() -> bool:
    return _truthy(os.environ.get("RULEPROOF_MODEL_KEY_ENCRYPT"))


def model_key_readpath_wired() -> bool:
    """运行时读路径（model.py/llm_router.py）是否已接入 ``open_api_key``。

    未接线时禁止迁移：否则 DB 中是密文，模型调用会把密文当 Bearer Token，必然 401。
    本 lane 不改这两个文件（写作用域外），故默认拒绝；接线完成后再置 1。
    """
    return _truthy(os.environ.get("RULEPROOF_MODEL_KEY_READPATH"))


def seal_model_api_key(value: str) -> str:
    """写入 model_config 前的加密（开关开启时调用；空值/已加密原样返回）。"""
    raw = str(value or "")
    if not raw or is_sealed(raw):
        return raw
    assert_master_ready("model_config.api_key 加密存储")
    return seal(raw)


def _open_db(db_path) -> sqlite3.Connection:
    p = Path(str(db_path)).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"数据库不存在：{p}")
    conn = sqlite3.connect(str(p), timeout=30)
    return conn


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _vacuum_quiet(conn: sqlite3.Connection) -> None:
    """迁移/回滚后清掉 free page 中的旧明文（SQLite UPDATE 不会擦除旧页）。"""
    try:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    try:
        conn.execute("VACUUM")
    except Exception:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)


def model_key_crypto_status(db_path) -> dict:
    """只读状态：开关/主密钥/读路径接线/库内明文与密文行数。不抛密钥缺失。"""
    out = {
        "ok": True,
        "db": str(Path(str(db_path)).expanduser()),
        "encrypt_switch": model_key_encrypt_enabled(),
        "readpath_wired": model_key_readpath_wired(),
        "master_key": master_key_status(),
        "total": 0, "plaintext_rows": 0, "sealed_rows": 0, "empty_rows": 0,
        "risk_note": "",
    }
    if not out["encrypt_switch"]:
        out["risk_note"] = "RULEPROOF_MODEL_KEY_ENCRYPT=0（默认）：model_config.api_key 仍明文入库"
    elif not out["readpath_wired"]:
        out["risk_note"] = ("加密开关已开但运行时读路径未接线（model.py/llm_router.py）："
                            "禁止迁移，否则模型调用会 401")
    conn = _open_db(db_path)
    try:
        try:
            rows = conn.execute("SELECT api_key FROM model_config").fetchall()
        except sqlite3.OperationalError as e:
            raise RuntimeError(f"model_config 表不存在：{db_path}") from e
    finally:
        conn.close()
    for (key,) in rows:
        out["total"] += 1
        text = str(key or "").strip()
        if not text:
            out["empty_rows"] += 1
        elif is_sealed(text):
            out["sealed_rows"] += 1
        else:
            out["plaintext_rows"] += 1
    return out


def _safety_copy(db_path: Path) -> str:
    """迁移前在线备份明文库到临时目录（返回路径；失败抛错，不静默）。"""
    tmpdir = Path(tempfile.mkdtemp(prefix="rp_key_migration_"))
    target = tmpdir / (db_path.stem + "-pre-key-migration.db")
    src = sqlite3.connect(str(db_path), timeout=30)
    dst = sqlite3.connect(str(target), timeout=30)
    try:
        src.backup(dst)
        dst.commit()
    finally:
        try:
            dst.close()
        finally:
            src.close()
    try:
        os.chmod(target, 0o600)
    except Exception:
        logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
    return str(target)


def _migrate_common(db_path, direction: str, dry_run: bool, force: bool,
                    backup: bool) -> dict:
    """direction='seal'|'open'：把 model_config.api_key 在明文/密文之间整体迁移。"""
    if direction == "seal":
        master = assert_master_ready("model_config.api_key 加密迁移")
        if not model_key_readpath_wired() and not force:
            raise SecretKeyNotConfigured(
                "model_config.api_key 加密迁移已拒绝：运行时读路径未接线"
                "（model.py/llm_router.py 需先接入 open_api_key），迁移后模型调用会把密文当 "
                "Bearer Token 返回 401。确认已完成接线/仅做离线演练时用 force=True "
                "或 RULEPROOF_MODEL_KEY_READPATH=1")
    else:
        master = master_key_status()
        if not master["ready"] and not force:
            raise SecretKeyNotConfigured("回滚解密需要可用主密钥；" + master["note"])
    p = Path(str(db_path)).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"数据库不存在：{p}")
    if p == _PRODUCT_DB.resolve() and not _truthy(os.environ.get("RULEPROOF_ALLOW_PRODUCT_DB_KEY_MIGRATION")):
        raise PermissionError(
            f"拒绝对产品库 {p} 做密钥迁移（铁律6）；请先 cp 到 /tmp 副本再操作，"
            "或显式 RULEPROOF_ALLOW_PRODUCT_DB_KEY_MIGRATION=1")
    conn = _open_db(p)
    try:
        try:
            rows = conn.execute("SELECT id, api_key FROM model_config").fetchall()
        except sqlite3.OperationalError as e:
            raise RuntimeError(f"model_config 表不存在：{p}") from e
        todo, already, empty = [], 0, 0
        for rid, key in rows:
            text = str(key or "").strip()
            if not text:
                empty += 1
            elif direction == "seal" and is_sealed(text):
                already += 1
            elif direction == "open" and not is_sealed(text):
                already += 1
            else:
                todo.append((rid, text))
        result = {
            "ok": True, "db": str(p), "direction": direction, "dry_run": bool(dry_run),
            "total": len(rows),
            ("would_migrate" if dry_run else "migrated"): len(todo),
            "already": already, "empty": empty,
            "master_key_source": (master or {}).get("source", ""),
            "readpath_wired": model_key_readpath_wired(),
            "safety_backup": "",
            "sha256_before": _sha256_file(p),
            "sha256_after": "",
            "vacuumed": False,
        }
        if dry_run or not todo:
            result["sha256_after"] = result["sha256_before"]
            return result
        if backup:
            result["safety_backup"] = _safety_copy(p)
        try:
            conn.execute("BEGIN IMMEDIATE")
            for rid, text in todo:
                new = seal(text) if direction == "seal" else open_secret(text)
                conn.execute("UPDATE model_config SET api_key=? WHERE id=?", (new, rid))
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        _vacuum_quiet(conn)
        result["vacuumed"] = True
        # 迁移后自检：目标状态条数必须与预期一致，否则抛错（fail-closed）
        after = conn.execute("SELECT api_key FROM model_config").fetchall()
        sealed_after = sum(1 for (k,) in after if is_sealed(str(k or "").strip()))
        plain_after = sum(1 for (k,) in after if str(k or "").strip() and not is_sealed(str(k or "")))
        result["sealed_rows_after"] = sealed_after
        result["plaintext_rows_after"] = plain_after
        if direction == "seal" and plain_after != 0:
            raise RuntimeError(f"迁移后仍有 {plain_after} 行明文 api_key，已 fail-closed")
        if direction == "open" and sealed_after != 0:
            raise RuntimeError(f"回滚后仍有 {sealed_after} 行密文 api_key，已 fail-closed")
        result["sha256_after"] = _sha256_file(p)
        result["plaintext_removed"] = direction == "seal"
        return result
    finally:
        conn.close()


def migrate_model_api_keys(db_path, *, dry_run: bool = False, force: bool = False,
                           backup: bool = True) -> dict:
    """把 model_config.api_key 明文 → enc1: 密文（单事务 + VACUUM + 迁移前安全副本）。

    默认需要：① 主密钥就绪；② 运行时读路径已接线（RULEPROOF_MODEL_KEY_READPATH=1）
    或显式 force=True（仅离线演练）。返回真实计数/哈希/安全副本路径。
    """
    return _migrate_common(db_path, "seal", dry_run, force, backup)


def rollback_model_api_keys(db_path, *, dry_run: bool = False, force: bool = False,
                            backup: bool = True) -> dict:
    """回滚：enc1: 密文 → 明文（离线应急；同样单事务 + VACUUM）。"""
    return _migrate_common(db_path, "open", dry_run, force, backup)


# ---------------------------------------------------------------------------
# 上传附件加密开关骨架（P0-2 设计部分；不接入上传落盘）
# ---------------------------------------------------------------------------
def file_encrypt_enabled() -> bool:
    return _truthy(os.environ.get("RULEPROOF_FILE_ENCRYPT"))


def file_crypto_status() -> dict:
    ready = master_key_status()
    return {
        "switch": "RULEPROOF_FILE_ENCRYPT",
        "enabled": file_encrypt_enabled(),
        "master_key_ready": ready["ready"],
        "format": "RPF1 + enc1-style nonce|tag|cipher（与 AppSecret 同一套原语）",
        "wired": False,
        "wired_note": ("骨架阶段：仅提供 seal_bytes/open_bytes 密码学接口；"
                       "app/services/project.py 上传落盘路径未接入（写作用域外），"
                       "禁止宣称上传附件已加密"),
        "migration_steps": [
            "1) 停写并备份 data/uploads/ 与 DB（含 -wal/-shm）；",
            "2) 配置主密钥 RULEPROOF_SECRET_KEY（独立托管，≥32 字节）；",
            "3) 接入上传落盘：project.py 写入前 seal_bytes，读取/解析前 open_bytes，"
            "保留原文件 sha256 与大小元数据；",
            "4) 历史文件批量迁移：逐文件 加密→写新文件→校验→替换→更新存储路径，"
            "失败则回退该文件（单文件事务，不整批回滚）；",
            "5) 灰度：RULEPROOF_FILE_ENCRYPT=1 仅新文件加密，读路径双读兼容旧明文；",
            "6) 验收：随机抽 10 份文件 round-trip SHA256 一致、明文关键字搜索落盘目录 0 命中；",
            "7) 回滚：关开关 + 运行反向迁移（密文→明文），保留加密前安全备份。",
        ],
    }


def _seal_bytes(data: bytes) -> bytes:
    key = _master()
    nonce = os.urandom(16)
    enc = bytes(a ^ b for a, b in zip(data, _keystream(key, nonce, len(data))))
    tag = hmac.new(key, b"tag" + nonce + enc, hashlib.sha256).digest()[:16]
    return nonce + tag + enc


def _open_bytes(blob: bytes) -> bytes:
    if len(blob) < 32:
        raise ValueError("ciphertext too short")
    nonce, tag, enc = blob[:16], blob[16:32], blob[32:]
    key = _master()
    want = hmac.new(key, b"tag" + nonce + enc, hashlib.sha256).digest()[:16]
    if not hmac.compare_digest(tag, want):
        raise ValueError("file ciphertext integrity check failed")
    return bytes(a ^ b for a, b in zip(enc, _keystream(key, nonce, len(enc))))


def seal_bytes(data: bytes) -> bytes:
    """附件加密骨架：bytes → 自描述信封（RPF1 magic + 完整性标签）。开关关闭时拒绝。"""
    if not file_encrypt_enabled():
        raise RuntimeError("RULEPROOF_FILE_ENCRYPT=0：附件加密开关未开启，拒绝加密写入")
    assert_master_ready("上传附件加密")
    return _FILE_MAGIC + _seal_bytes(bytes(data))


def open_bytes(blob: bytes) -> bytes:
    """附件解密骨架：双读兼容——带 RPF1 信封则解密，否则视为历史明文原样返回。"""
    raw = bytes(blob)
    if not raw.startswith(_FILE_MAGIC):
        return raw
    return _open_bytes(raw[len(_FILE_MAGIC):])


def file_roundtrip_selftest() -> dict:
    """附件加密骨架自检（测试/运维用；不落盘、不读业务文件）。"""
    enabled = file_encrypt_enabled()
    prev = os.environ.get("RULEPROOF_FILE_ENCRYPT")
    os.environ["RULEPROOF_FILE_ENCRYPT"] = "1"
    try:
        sample = b"ruleproof-file-encrypt-skeleton:" + os.urandom(8)
        sealed = seal_bytes(sample)
        opened = open_bytes(sealed)
        status = file_crypto_status()
    finally:
        if prev is None:
            os.environ.pop("RULEPROOF_FILE_ENCRYPT", None)
        else:
            os.environ["RULEPROOF_FILE_ENCRYPT"] = prev
    return {"ok": opened == sample and sealed.startswith(_FILE_MAGIC),
            "enabled_at_rest_switch": enabled, "status": status,
            "plaintext_in_ciphertext": sample in sealed}


# ---------------------------------------------------------------------------
# 运维入口（迁移脚本）：python3 -m app.services.secret_box ...
# ---------------------------------------------------------------------------
def _main(argv: list[str] | None = None) -> int:
    import argparse
    import json as _json
    ap = argparse.ArgumentParser(
        prog="python3 -m app.services.secret_box",
        description="model_config.api_key 静态加密迁移/回滚/状态（L147 P0-3）")
    ap.add_argument("action", choices=("status", "migrate", "rollback", "selftest"))
    ap.add_argument("--db", required=False, help="目标 SQLite 路径（status/migrate/rollback 必填）")
    ap.add_argument("--dry-run", action="store_true", help="只报告将迁移行数，不写库")
    ap.add_argument("--force", action="store_true",
                    help="离线演练：跳过“运行时读路径未接线”检查（生产禁止）")
    ap.add_argument("--no-backup", action="store_true", help="跳过迁移前安全副本（不推荐）")
    a = ap.parse_args(argv)
    try:
        if a.action == "selftest":
            out = file_roundtrip_selftest()
        elif a.action == "status":
            if not a.db:
                ap.error("status 需要 --db")
            out = model_key_crypto_status(a.db)
        elif a.action == "migrate":
            if not a.db:
                ap.error("migrate 需要 --db")
            out = migrate_model_api_keys(a.db, dry_run=a.dry_run, force=a.force,
                                         backup=not a.no_backup)
        else:
            if not a.db:
                ap.error("rollback 需要 --db")
            out = rollback_model_api_keys(a.db, dry_run=a.dry_run, force=a.force,
                                          backup=not a.no_backup)
    except Exception as e:  # noqa: BLE001 - CLI 失败必须 stderr + 非 0
        print(_json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"},
                          ensure_ascii=False), file=sys.stderr)
        return 1
    print(_json.dumps(out, ensure_ascii=False, indent=1))
    return 0 if out.get("ok", True) else 1


if __name__ == "__main__":
    raise SystemExit(_main())
