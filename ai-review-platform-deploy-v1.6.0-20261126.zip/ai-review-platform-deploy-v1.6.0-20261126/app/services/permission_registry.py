# -*- coding: utf-8 -*-
"""权限点 / 角色 / 菜单的**单一事实源**（T-199，2026-11-20）。

设计约定（违反即回退到「双事实源」）：

1. **只依赖标准库**，不 import ``app.*``、不连库。QA 静态扫描器可以按文件路径加载本
   模块来审计权限，不需要为了读一张权限表去连数据库或起服务。
2. ``PERMISSION_POINTS``（权限点）、``VIEW_ITEMS``（视图/菜单）、``ROLE_POLICY``
   （角色边界策略）是唯一的 authoring 面。以下全部从这里派生：
   - DB 种子：``permissions.ensure_seed()``（``permission`` / ``role_permission`` 表只是
     **缓存/种子**，不是第二事实源）；
   - 服务端与 CLI 校验：``permissions.has`` / ``permission.can``；
   - 菜单与按钮：``/api/v1/me/permissions`` → ``web/app.js``；
   - 门禁：``scripts/qa/permission_single_source_test.py``（四方一致断言）。
3. 每个 ``PermissionPoint.enforced`` 必须列出**真实存在**的校验面证据
   （``surface:path``：``server`` / ``service`` / ``cli`` / ``ui``），门禁脚本会逐条
   到文件里核对权限点字符串确实出现——本字段不允许写「计划接线」，只写已接线。
4. 新增/删除权限点、菜单、角色可见性，只改本文件；改 DB 种子行/前端硬编码会被
   ``permission_single_source_test.py`` 判 FAIL。
"""
from __future__ import annotations

from dataclasses import dataclass

# ---------------------------------------------------------------------------
# 角色
# ---------------------------------------------------------------------------
ROLE_CODES = ("super_admin", "admin", "reviewer", "platform_op")
ROLE_LABELS = {
    "super_admin": "系统管理员",
    "admin": "业务管理员",
    "reviewer": "审核员",
    "platform_op": "平台运营",
}
WILDCARD = "*"

# 角色边界策略（原 app/services/permissions.py 顶部常量迁入；唯一事实源）
ROLE_POLICY = {
    # 只读角色：系统管理员只做平台/IT，平台运营只做平台层；二者都不得写审核业务。
    "business_write_deny_roles": ("super_admin", "platform_op"),
    # 本体域（读/写同口径）：仅业务管理员与系统管理员；审核员/平台运营 403。
    "ontology_access_roles": ("admin", "super_admin"),
    # 企业词典与本体同属规则配置层：仅业务管理员与系统管理员。
    "terms_access_roles": ("admin", "super_admin"),
    # 系统管理员业务只读白名单由 app/api/role_scope.py 维护（F-28），不在本表。
}

# 账号开通白名单（原 app/services/account.py::CREATE_ROLE_ALLOWED 的唯一事实源）：
# 系统管理员可开本租户内系统管理员/业务管理员/审核员；业务管理员无开号权限；
# platform_op 只能经平台租户接口开通（不在本表）。L92：role.create 白名单与
# ROLE_CODES/权限注册表同源，禁止再手写第二份角色名单。
CREATABLE_ROLES = {
    "super_admin": ("super_admin", "admin", "reviewer"),
    "admin": (),
}


def is_known_role(role) -> bool:
    """角色是否在注册表四角色内（未知/悬空角色一律 False → 调用方 fail-closed）。"""
    return str(role or "").strip() in ROLE_CODES


# 审核业务写权限点（F-28：business_write_deny_roles 不得持有这些点）
BUSINESS_WRITE_CODES = (
    "project.create", "project.upload", "finding.decide", "audit.run", "audit.review",
    "ws.manage", "rule.manage", "rule.publish", "rule.create", "rule.submit",
    "dt.manage", "onto.manage", "evo.manage", "report.export", "data.export",
)


# 权限点所属域 → 展示名（DB permission.module / 前端模块名共用）
DOMAIN_TITLES = {
    "ws": "工作空间",
    "audit": "审核",
    "report": "报告",
    "rule": "规则库",
    "dt": "决策表",
    "onto": "本体",
    "agent": "智能体",
    "jev": "校准",
    "evo": "进化",
    "user": "账号",
    "msg": "消息",
    "log": "审计日志",
    "schema": "数据字典",
    "model": "模型配置",
    "platform": "平台层",
    "project": "项目",
    "finding": "发现",
    "data": "数据",
    "config": "配置",
}


@dataclass(frozen=True)
class PermissionPoint:
    """一个权限点：code 形如 ``<domain>.<action>``；roles 是**显式**持有角色。"""

    code: str
    name: str
    domain: str
    roles: tuple
    enforced: tuple
    note: str = ""

    @property
    def action(self) -> str:
        return self.code.split(".", 1)[1]


@dataclass(frozen=True)
class ViewItem:
    """一个视图/菜单项。

    kind=``nav``：左侧导航项（``data-view``），由 ``/api/v1/me/permissions`` 的
    ``menus`` 控制显隐；kind=``subview``：二级页/子视图（不进左侧导航），只做角色
    可见性登记，用于「每个菜单/视图至少 1 个角色可见」断言。
    perm：该入口要求的权限点（空串=无权限点要求）；portal：该导航项出现的门户页面。
    """

    code: str
    title: str
    kind: str
    roles: tuple
    perm: str = ""
    portals: tuple = ()
    parent: str = ""
    note: str = ""


# ---------------------------------------------------------------------------
# 权限点（36 个：旧 31 个 module.action 里保留 31 个 + 新增 5 个动作点）
# enforced 证据格式 surface:path；T-199 门禁逐条核对字符串存在性。
# ---------------------------------------------------------------------------
PERMISSION_POINTS = (
    # ---- 工作空间 ----
    PermissionPoint("ws.view", "工作空间查看", "ws", ("admin", "reviewer"),
                    ("cli:app/cli.py",),
                    "审核员只使用已分配空间，可列出空间；空间维护归业务管理员"),
    PermissionPoint("ws.manage", "工作空间维护", "ws", ("admin",),
                    ("cli:app/cli.py", "server:app/api/server.py"),
                    "HTTP POST /workspaces/create 与 CLI ws create/settings 同口径"),
    # ---- 审核 ----
    PermissionPoint("audit.view", "审核数据查看", "audit", ("admin", "reviewer"),
                    ("ui:web/reviewer.html",),
                    "项目列表/看板读取；业务管理员看本租户汇总，审核员看自己的"),
    PermissionPoint("audit.run", "发起审核", "audit", ("reviewer",),
                    ("server:app/api/server.py", "ui:web/reviewer.html"),
                    "server._guard 动作表：admin/super 不可发起审核"),
    PermissionPoint("audit.review", "人工复核裁决", "audit", ("admin", "reviewer"),
                    ("cli:app/cli.py",),
                    "CLI finding decide/add 与 HTTP 复核裁决同权限点"),
    # ---- 报告 ----
    PermissionPoint("report.view", "报告查看", "report", ("admin", "reviewer"),
                    ("cli:app/cli.py",),
                    "报告属于项目只读详情；查看可、生成/导出另需 report.export"),
    PermissionPoint("report.export", "报告导出（HTML/DOCX/CSV）", "report", ("reviewer",),
                    ("cli:app/cli.py", "server:app/api/report_routes.py"),
                    "F-23：仅审核员可导出；业务管理员/系统管理员/平台运营 403"),
    # ---- 规则 ----
    PermissionPoint("rule.view", "规则查看", "rule", ("admin", "reviewer"),
                    ("ui:web/index.html", "cli:app/cli.py")),
    PermissionPoint("rule.manage", "规则维护", "rule", ("admin",),
                    ("cli:app/cli.py",),
                    "参数/规则编辑；审核员只能建/提交草稿"),
    PermissionPoint("rule.publish", "规则发布", "rule", ("admin",),
                    ("cli:app/cli.py",),
                    "T-110：草稿直发；审核员不可发布"),
    PermissionPoint("rule.create", "规则创建（草稿）", "rule", ("admin", "reviewer"),
                    ("ui:web/index.html", "server:app/api/finding_routes.py"),
                    "F4：审核员可建/提交草稿（不可发布）"),
    PermissionPoint("rule.submit", "规则提交", "rule", ("admin", "reviewer"),
                    ("cli:app/cli.py",)),
    # ---- 决策表（规则形式，无独立菜单——AGENTS.md §3）----
    PermissionPoint("dt.view", "决策表查看", "dt", ("admin", "reviewer"),
                    ("cli:app/cli.py",),
                    "决策表读接口对登录角色开放；CLI decision list/show/evaluate 接线"),
    PermissionPoint("dt.manage", "决策表维护", "dt", ("admin",),
                    ("cli:app/cli.py", "server:app/api/decision_routes.py"),
                    "HTTP decision_routes 角色守卫 + 权限点第二道；审核员只读"),
    # ---- 本体 ----
    PermissionPoint("onto.view", "本体查看", "onto", ("admin",),
                    ("ui:web/index.html",),
                    "T-122：审核员不看本体（HTTP/CLI 读也 403）"),
    PermissionPoint("onto.manage", "本体维护", "onto", ("admin",),
                    ("cli:app/cli.py",),
                    "CLI ontology discover/add-term/threshold；HTTP 由 ONTOLOGY_ACCESS_ROLES 守卫"),
    # ---- 智能体 ----
    PermissionPoint("agent.view", "智能体查看", "agent", ("super_admin",),
                    ("ui:web/admin.html", "cli:app/cli.py"),
                    "L108：CLI agent list/show/versions 与 HTTP 同源，仅持 agent.view 角色"),
    PermissionPoint("agent.manage", "智能体维护", "agent", ("super_admin",),
                    ("server:app/api/agent_routes.py", "server:app/api/server.py",
                     "cli:app/cli.py"),
                    "L108：run/publish/workflow.run 与 HTTP 同源（agent.manage；admin 被 IT 隔离）"),
    # ---- 置信校准 JEV（进化页子页签）----
    PermissionPoint("jev.view", "置信校准查看", "jev", ("admin", "reviewer"),
                    ("ui:web/index.html", "ui:web/reviewer.html"),
                    "JEV 页签在规则进化页；写侧 HTTP 仅 admin（server 角色守卫）"),
    PermissionPoint("jev.manage", "置信校准配置", "jev", ("admin",),
                    ("ui:web/index.html",),
                    "保存目标准确率按钮 data-perm；服务端 POST /calibration/config 亦仅 admin"),
    # ---- 进化 ----
    PermissionPoint("evo.view", "进化/知识库查看", "evo", ("admin", "reviewer"),
                    ("service:app/services/evolution.py", "ui:web/index.html"),
                    "reviewer 知识库菜单 data-perm=evo.view（T-105）"),
    PermissionPoint("evo.manage", "进化建议维护", "evo", ("admin",),
                    ("service:app/services/evolution.py",),
                    "evolution.py：请求回滚建议需 evo.manage"),
    # ---- 账号 ----
    PermissionPoint("user.view", "账号查看", "user", ("super_admin",),
                    ("ui:web/admin.html",)),
    PermissionPoint("user.manage", "账号维护", "user", ("super_admin",),
                    ("cli:app/cli.py",)),
    # ---- 消息 ----
    PermissionPoint("msg.view", "消息查看", "msg", ("admin", "reviewer"),
                    ("server:app/api/message_routes.py", "cli:app/cli.py"),
                    "消息中心/待确认反馈；系统管理员由通配持有"),
    # ---- 审计日志 ----
    PermissionPoint("log.view", "审计日志查看", "log", ("super_admin",),
                    ("ui:web/admin.html", "cli:app/cli.py"),
                    "审计日志只读、不导出（AGENTS.md §5）"),
    # ---- 数据字典 ----
    PermissionPoint("schema.view", "数据字典查看", "schema", ("admin",),
                    ("server:app/api/server.py",),
                    "X-07：后台能力，审核员 403"),
    # ---- 模型配置 ----
    PermissionPoint("model.view", "模型查看", "model", ("super_admin",),
                    ("ui:web/admin.html", "cli:app/cli.py")),
    PermissionPoint("model.manage", "模型维护", "model", ("super_admin",),
                    ("cli:app/cli.py",)),
    # ---- 平台层 ----
    PermissionPoint("platform.tenant.view", "租户查看", "platform", ("platform_op",),
                    ("server:app/api/platform_routes.py", "cli:app/cli.py")),
    PermissionPoint("platform.tenant.manage", "租户维护", "platform", ("platform_op",),
                    ("server:app/api/platform_routes.py", "cli:app/cli.py")),
    # ---- 项目 / 发现（写动作守卫）----
    PermissionPoint("project.create", "新建项目", "project", ("reviewer",),
                    ("server:app/api/server.py",),
                    "server._guard 动作表：业务管理员不能新建项目（T-111）"),
    PermissionPoint("project.upload", "上传文档", "project", ("reviewer",),
                    ("server:app/api/server.py",)),
    PermissionPoint("finding.decide", "发现裁决", "finding", ("reviewer",),
                    ("server:app/api/server.py", "cli:app/cli.py"),
                    "业务管理员不能复核（只读项目详情）"),
    # ---- 数据导出 / 通知配置 ----
    PermissionPoint("data.export", "报告/数据导出按钮", "data", ("reviewer",),
                    ("ui:web/index.html",),
                    "导出 HTML/Word 按钮 data-perm；与 report.export 同角色口径"),
    PermissionPoint("config.notify", "通知配置", "config", ("super_admin",),
                    ("ui:web/index.html", "server:app/api/message_routes.py"),
                    "通知配置为平台级全局单例，仅系统管理员可读写"),
)


# ---------------------------------------------------------------------------
# 视图/菜单（nav=左侧导航；subview=二级页/子视图，只登记可见角色）
# 说明：T-199 前 ALL_MENUS 里的 dashboard/eval/audit 三个菜单没有视图容器、
# 没有 data-view、没有 showView/哈希可达路径（TITLES 无此三键）→ 属失效菜单，
# 已删除；project/sediment/tenant/errorbook 是真实二级页 → 降级为 subview 并显式
# 分配角色（不再以「顶层菜单」名义悬空）。
# ---------------------------------------------------------------------------
VIEW_ITEMS = (
    ViewItem("home", "首页", "nav", ("super_admin", "admin", "reviewer", "platform_op"),
             portals=("index", "reviewer", "admin")),
    ViewItem("projects", "项目列表", "nav", ("admin", "reviewer"), "audit.view",
             ("index", "reviewer")),
    ViewItem("newproject", "新建项目", "nav", ("reviewer",), "audit.run", ("reviewer",)),
    ViewItem("wssettings", "空间列表", "nav", ("admin",), "ws.manage", ("index",)),
    ViewItem("rules", "规则库", "nav", ("admin", "reviewer"), "rule.view",
             ("index", "reviewer")),
    ViewItem("drafts", "规则草稿箱", "nav", ("admin", "reviewer"), "rule.view",
             ("index", "reviewer"),
             note="T-109：草稿箱与规则库同菜单权限，前端映射 drafts→rules"),
    ViewItem("newrule", "新建规则", "nav", ("admin", "reviewer"), "rule.create",
             ("index", "reviewer")),
    ViewItem("conflict", "冲突提醒", "nav", ("admin", "reviewer"), "rule.view",
             ("index", "reviewer")),
    ViewItem("evolution", "规则进化", "nav", ("admin", "reviewer"), "evo.view",
             ("index", "reviewer")),
    ViewItem("knowledge", "知识库", "nav", ("admin", "reviewer"), "evo.view",
             ("index", "reviewer"),
             note="T-105：知识库仅 admin/reviewer；与 evo.view 同权限点"),
    ViewItem("ontology", "本体建模", "nav", ("admin",), "onto.view", ("index",)),
    ViewItem("messages", "消息中心", "nav", ("super_admin", "admin", "reviewer"),
             portals=("shared",)),
    ViewItem("model", "模型", "nav", ("super_admin",), "model.view", ("admin",)),
    ViewItem("agents", "智能体", "nav", ("super_admin",), "agent.view", ("admin",)),
    ViewItem("users", "账号列表", "nav", ("super_admin",), "user.view", ("admin",)),
    ViewItem("openplatform", "开放平台", "nav", ("super_admin", "platform_op"),
             "platform.tenant.view", ("admin", "platform")),
    ViewItem("auditlogs", "审计日志", "nav", ("super_admin",), "log.view", ("admin",)),
    ViewItem("notifyconfig", "通知配置", "nav", ("super_admin",), "config.notify",
             ("index", "admin")),
    ViewItem("ops", "运维看板", "nav", ("super_admin",), portals=("admin",)),
    ViewItem("datapolicy", "数据边界", "nav", ("super_admin",), portals=("admin",)),
    # ---- 二级页/子视图：不进左侧导航，角色可见性显式登记（原未分配菜单 4/7）----
    ViewItem("project", "项目详情", "subview", ("admin", "reviewer"), "audit.view",
             parent="projects"),
    ViewItem("sediment", "标准导入", "subview", ("admin",), "rule.view",
             parent="rules",
             note="T-111：标准导入由业务管理员执行，审核员不提供该入口"),
    ViewItem("tenant", "租户配置", "subview", ("admin",), parent="home",
             note="租户品牌/Logo 仅本租户 admin 可写（tenant_branding_test）"),
    ViewItem("errorbook", "错误书", "subview", ("admin", "reviewer"), "evo.view",
             parent="evolution"),
)


# ---------------------------------------------------------------------------
# 派生接口（DB 种子 / 服务端 / CLI / 菜单 / 门禁 共用）
# ---------------------------------------------------------------------------
def active_points() -> tuple:
    """全部启用中的权限点（本版本无停用点；保留接口供后续废弃流程）。"""
    return PERMISSION_POINTS


def permission_codes() -> tuple:
    """全部权限点 code（排序稳定）。"""
    return tuple(sorted(p.code for p in active_points()))


def point_map() -> dict:
    return {p.code: p for p in active_points()}


def point_holders(code: str) -> tuple:
    """显式持有该权限点的业务角色（不含 super_admin 通配展开）。"""
    p = point_map().get(code)
    return tuple(p.roles) if p else ()


def business_action_allowed(role, code: str) -> bool:
    """该角色是否允许执行某个业务动作（HTTP/CLI/服务层共用，fail-closed）。

    与 ``permission.can`` 的差别：``can`` 对 super_admin 展开通配 ``*``（用于 IT/平台
    域与菜单布尔表）；审核业务写必须按 **显式持有角色** 判定，且系统管理员/平台运营
    属 business_write_deny_roles 一律拒绝（F-28 第二道）。未知角色一律 False。
    """
    r = str(role or "").strip()
    if r not in ROLE_CODES:
        return False
    action = str(code or "").strip()
    if action in BUSINESS_WRITE_CODES and r in ROLE_POLICY["business_write_deny_roles"]:
        return False
    if action in BUSINESS_WRITE_CODES:
        return r in point_holders(action)
    if r == "super_admin":
        return True
    return r in point_holders(action)


def module_actions() -> dict:
    """domain → [action, ...]（等价旧 permissions.MODULES 的构成）。"""
    out = {}
    for p in active_points():
        out.setdefault(p.domain, []).append(p.action)
    for acts in out.values():
        acts.sort()
    return out


def modules() -> tuple:
    """(domain, 展示名, [action]) 元组列表（稳定顺序：按 domain 首次出现）。"""
    order = []
    for p in active_points():
        if p.domain not in order:
            order.append(p.domain)
    grouped = module_actions()
    return tuple((d, DOMAIN_TITLES.get(d, d), grouped[d]) for d in order)


def expand_bundle(bundle) -> tuple:
    """角色 bundle → 完整 code 列表（``*`` 展开为全部权限点）。"""
    codes = list(bundle or ())
    if WILDCARD in codes:
        return permission_codes()
    return tuple(sorted(codes))


def role_bundles() -> dict:
    """role → 显式 bundle（super_admin 为 ``["*"]``，DB 种子里展开）。"""
    holder = {r: [] for r in ROLE_CODES}
    for p in active_points():
        for r in p.roles:
            if r in holder:
                holder[r].append(p.code)
    for r in holder:
        holder[r] = sorted(holder[r]) or []
    holder["super_admin"] = [WILDCARD]
    return {r: tuple(v) for r, v in holder.items()}


def role_actions(role: str) -> list:
    """前端动作表（等价旧 ROLE_PERMS[role]["actions"]）。"""
    if role == "super_admin":
        return [WILDCARD]
    return sorted(expand_bundle(role_bundles().get(role, ())))


def role_perms_matrix() -> dict:
    """等价旧 permission.ROLE_PERMS（menus 只含 nav 菜单，actions 为动作表）。"""
    return {r: {"menus": list(menus_for_role(r)), "actions": role_actions(r)}
            for r in ROLE_CODES}


def menu_codes() -> tuple:
    """左侧导航菜单 code（= 旧 ALL_MENUS 的可执行语义）。"""
    return tuple(v.code for v in VIEW_ITEMS if v.kind == "nav")


def all_view_codes() -> tuple:
    """全部登记视图 code（nav + subview），供完整性/角色断言。"""
    return tuple(v.code for v in VIEW_ITEMS)


def menu_roles() -> dict:
    """view/menu code → 可见角色（每个菜单/视图都必须 ≥1 角色）。"""
    return {v.code: v.roles for v in VIEW_ITEMS}


def view_by_code(code: str):
    for v in VIEW_ITEMS:
        if v.code == code:
            return v
    return None


def menus_for_role(role: str) -> tuple:
    """该角色可见的左侧导航菜单。"""
    return tuple(v.code for v in VIEW_ITEMS if v.kind == "nav" and role in v.roles)


def views_for_role(role: str) -> tuple:
    """该角色可见的全部视图（nav + subview）。"""
    return tuple(v.code for v in VIEW_ITEMS if role in v.roles)


def role_policy(key: str = ""):
    """角色边界策略：取单个 key 返回元组；空 key 返回整表副本。"""
    if key:
        return tuple(ROLE_POLICY[key])
    return dict(ROLE_POLICY)


def seed_rows() -> dict:
    """给 DB 种子用的纯数据：权限行 + 角色权限包（DB 只是缓存/种子）。"""
    perms = []
    for p in active_points():
        perms.append((p.code, p.domain, p.action, f"{DOMAIN_TITLES.get(p.domain, p.domain)}-{p.name}"))
    bundles = {}
    for role, bundle in role_bundles().items():
        bundles[role] = list(expand_bundle(bundle)) if WILDCARD in bundle else list(bundle)
    return {"permissions": tuple(perms), "role_bundles": bundles}


def validate() -> list:
    """注册表自洽校验；返回错误列表（空=通过）。门禁脚本调用。"""
    errors = []
    codes = [p.code for p in active_points()]
    if len(codes) != len(set(codes)):
        errors.append("权限点 code 重复")
    for p in active_points():
        if p.domain not in DOMAIN_TITLES:
            errors.append(f"{p.code}: 未登记 domain 展示名")
        if p.code.split(".", 1)[0] != p.domain:
            errors.append(f"{p.code}: code 前缀与 domain 不一致")
        if not p.roles:
            errors.append(f"{p.code}: 没有任何角色持有")
        for r in p.roles:
            if r not in ROLE_CODES:
                errors.append(f"{p.code}: 未知角色 {r}")
        if not p.enforced:
            errors.append(f"{p.code}: 死权限点（无 enforced 校验面）")
    pm = point_map()
    menu_codes_seen = [v.code for v in VIEW_ITEMS]
    if len(menu_codes_seen) != len(set(menu_codes_seen)):
        errors.append("菜单 code 重复")
    for v in VIEW_ITEMS:
        if v.kind not in ("nav", "subview"):
            errors.append(f"{v.code}: 未知菜单 kind")
        if not v.roles:
            errors.append(f"{v.code}: 未分配任何角色（unassigned menu）")
        for r in v.roles:
            if r not in ROLE_CODES:
                errors.append(f"{v.code}: 未知角色 {r}")
        if v.perm and v.perm not in pm:
            errors.append(f"{v.code}: 引用未定义权限点 {v.perm}")
        if v.parent and v.parent not in menu_codes_seen:
            errors.append(f"{v.code}: parent {v.parent} 未定义")
    # 审核业务写权限点不得授予「业务写拒绝角色」（super_admin/platform_op）；
    # IT/平台域权限点（账号/模型/智能体/平台租户）不受此限。
    deny = set(ROLE_POLICY["business_write_deny_roles"])
    for code in BUSINESS_WRITE_CODES:
        p = pm.get(code)
        if p is None:
            errors.append(f"BUSINESS_WRITE_CODES 含未定义权限点 {code}")
            continue
        if set(p.roles) & deny:
            errors.append(f"{code}: 审核业务写权限点与 business_write_deny_roles 交叉")
    return errors

# ---------------------------------------------------------------------------
# L117（2026-11-25）自进化候选安全门：受保护权限事实导出
#
# 候选（rulegen / feedback / RSI）不得增删、收紧或改写任何权限点、角色边界与
# 审核业务写权限。安全门 ``app/services/rsi_guard.py::scan_candidate_change``
# 从这里取「权限事实」做黑名单断言，**不在安全门里复制第二份权限清单**——
# 权限注册表仍是唯一事实源（permission_single_source_test 四方一致不变）。
# 本函数只读、无副作用，供安全门/审核视图/门禁脚本共用。
# ---------------------------------------------------------------------------
def candidate_safety_facts() -> dict:
    """候选安全门（L117）可消费的受保护权限事实（单一事实源派生）。"""
    return {
        "roles": tuple(ROLE_CODES),
        "permission_codes": permission_codes(),
        "business_write_codes": tuple(BUSINESS_WRITE_CODES),
        "role_policy_keys": tuple(sorted(ROLE_POLICY.keys())),
        "creatable_roles": {k: tuple(v) for k, v in CREATABLE_ROLES.items()},
        "policy_source": "app/services/permission_registry.py",
    }
