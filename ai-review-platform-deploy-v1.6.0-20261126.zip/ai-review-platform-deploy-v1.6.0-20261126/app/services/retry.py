"""定向重跑：只重跑上一批“执行失败/未判定”的点位，避免整份重审。
幂等：已有同点位发现的跳过；无失败点位返回 0。"""
import json
import logging
from .. import db, repositories as R


def _failed_point_ids(doc_ids: list) -> list:
    if not doc_ids:
        return []
    q = ",".join("?" * len(doc_ids))
    with db.session() as c:
        rows = c.execute(
            f"SELECT DISTINCT point_id FROM point_state WHERE file_id IN ({q}) "
            "AND state IN ('执行失败','unknown') AND point_id!=''", doc_ids).fetchall()
    return [r[0] for r in rows]


def retry_failed(case_id: str) -> dict:
    case = R.cases.get(case_id)
    if not case:
        raise ValueError("项目不存在")
    docs = R.cases.documents(case_id) or []
    import os
    # point_state.file_id 由审核写入 basename(path)，这里必须用同一口径；用 document_id 会 0 命中
    doc_ids = [os.path.basename(d.get("path") or "") for d in docs if d.get("path")]
    pids = _failed_point_ids(doc_ids)
    result = {"case_id": case_id, "failed_points": len(pids), "retried": 0,
              "new_findings": 0, "skipped_existing": 0}
    if not pids:
        return result
    from . import auditpoints as AP
    lib = AP.load()
    by_id = {p.id: p for p in lib.points}
    picked = [{"id": by_id[i].id, "name": by_id[i].name, "criterion": by_id[i].criterion,
               "required_evidence": by_id[i].required_evidence, "trigger": by_id[i].trigger,
               "level": getattr(by_id[i], "severity", "warning"),
               "severity": getattr(by_id[i], "severity", "warning"),
               "method": getattr(by_id[i], "method", ""), "prompt": getattr(by_id[i], "prompt", ""),
               "category": by_id[i].category, "category_id": getattr(by_id[i], "category_id", "")}
              for i in pids if i in by_id]
    if not picked:
        return result
    run_id = db.new_id("run")
    with db.session() as c:
        existing = {r[0] for r in c.execute(
            "SELECT point_id FROM finding WHERE case_id=?", (case_id,)).fetchall() if r[0]}
    from .lab_l0 import _doc_text
    for d in docs:
        path = d.get("path")
        if not path:
            continue
        try:
            text = _doc_text(path)
        except Exception:
            continue
        todo = [p for p in picked if p["id"] not in existing]
        if not todo:
            result["skipped_existing"] += len(picked)
            continue
        try:
            fs = AP.execute_points(path, todo, "", text) or []
        except Exception:
            continue
        # 同步五态：把该文件/点位旧的 unknown 更新为本次结果，否则 report_gate 永远看到 unknown
        try:
            with db.session() as _c:
                for f in fs:
                    _pid = f.get("point_id") or f.get("rule_code") or ""
                    _st = f.get("state") or ("fail" if f.get("level") in ("critical", "warning") else "unknown")
                    if not _pid:
                        continue
                    _c.execute("UPDATE point_state SET state=?, confidence=?, reason=? "
                               "WHERE file_id=? AND point_id=? AND state IN ('unknown','执行失败')",
                               (_st, f.get("confidence"), str(f.get("reason") or "")[:300],
                                os.path.basename(path), _pid))
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        for f in fs:
            pid = f.get("point_id") or f.get("rule_code") or ""
            if not pid or pid in existing:
                continue
            R.findings.insert(
                id=db.new_id("fnd"), case_id=case_id, rule_id=f.get("rule_code") or pid,
                point_id=pid, source_code=f.get("source_code") or "",
                rule_version="builtin", severity=f.get("level") or "warning",
                certainty="probable", confidence=1.0, status="pending",
                title=f.get("title") or pid, summary=f.get("description") or "",
                suggestion=f.get("suggestion") or "",
                engine="retry" + ("|" + str(f.get("_model") or "") if f.get("_model") else ""),
                run_id=run_id)
            existing.add(pid)
            result["new_findings"] += 1
        result["retried"] += len(todo)
    return result
