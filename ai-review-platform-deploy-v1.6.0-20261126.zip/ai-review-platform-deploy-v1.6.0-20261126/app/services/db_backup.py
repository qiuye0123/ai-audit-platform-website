"""SQLite 备份 / 恢复（在线 backup API，不复制 -wal 半成品）。

原则：
- 备份使用 ``sqlite3.Connection.backup``，生成一致性快照；
- 备份完成后做 ``PRAGMA integrity_check``，失败直接抛错，不返回“假成功”；
- 恢复前默认再备份当前库（safety backup），防止误操作；
- 只操作显式传入的 db 路径，绝不默认碰 data/ 下的生产库。

L147（2026-11-25，P0-2 最小整改）追加**可选备份静态加密**：
- 开关 ``RULEPROOF_BACKUP_ENCRYPT``：默认 0（不改历史行为）；生产建议 1；
  取值 ``1``=自动选择（age→gpg→openssl 第一个可用）；也可显式 ``age``/``gpg``/``openssl``；
- 加密命令/输出校验任何失败都 fail-closed：删除半成品密文与临时明文，抛错，
  绝不静默回落为明文备份，也绝不返回 ok=True；
- 明文快照只存在于进程临时目录（``tempfile.mkdtemp``，文件 0600），加密成功后立即删除；
- 恢复支持识别 ``.age``/``.gpg``/``.enc`` 备份，先解密到临时文件再走既有 restore 流程。

密钥托管（详见 docs/qa/安全整改_20261125.md）：
- age：``RULEPROOF_BACKUP_AGE_RECIPIENT``（公钥）+ 解密身份 ``RULEPROOF_BACKUP_AGE_IDENTITY``；
- gpg：``RULEPROOF_BACKUP_GPG_RECIPIENT``（公钥指纹/邮箱）+ 部署方私钥环；
- openssl：``RULEPROOF_BACKUP_OPENSSL_PASSPHRASE``（或 ``..._FILE``，生产建议走 KMS/HSM
  注入，不要把口令和备份放同一块盘）。
备份与密钥必须分离托管：备份可放对象存储，解密私钥/口令放 KMS/HSM/离线介质。
"""
from __future__ import annotations

import hashlib
import logging
import os
import shutil
import sqlite3
import subprocess
import tempfile
import time
from pathlib import Path

_ENCRYPT_SWITCH = "RULEPROOF_BACKUP_ENCRYPT"
_TOOL_SUFFIX = {"age": ".age", "gpg": ".gpg", "openssl": ".enc"}
_TOOL_ORDER = ("age", "gpg", "openssl")
_TOOL_BIN_ENV = {"age": "RULEPROOF_BACKUP_AGE_BIN",
                 "gpg": "RULEPROOF_BACKUP_GPG_BIN",
                 "openssl": "RULEPROOF_BACKUP_OPENSSL_BIN"}
_TOOL_DEFAULT_BIN = {"age": "age", "gpg": "gpg", "openssl": "openssl"}
_OPENSSL_PASS_ENV = "RULEPROOF_BACKUP_OPENSSL_PASSPHRASE"


def _truthy(value) -> bool:
    return str(value or "").strip().lower() in ("1", "true", "yes", "on")


def _is_prod() -> bool:
    return (os.environ.get("RULEPROOF_ENV") or "").strip().lower() in ("prod", "production")


def backup_encrypt_setting() -> str:
    """原始开关值（归一化小写）。空/0/false = 关闭。"""
    return (os.environ.get(_ENCRYPT_SWITCH) or "").strip().lower()


def backup_encrypt_enabled() -> bool:
    raw = backup_encrypt_setting()
    return raw not in ("", "0", "false", "no", "off")


def _explicit_tool() -> str:
    raw = backup_encrypt_setting()
    return raw if raw in _TOOL_ORDER else ""


def _tool_binary(tool: str) -> str:
    return (os.environ.get(_TOOL_BIN_ENV.get(tool, "")) or "").strip() or _TOOL_DEFAULT_BIN[tool]


def _tool_available(tool: str) -> bool:
    return bool(shutil.which(_tool_binary(tool)))


def select_backup_encrypt_tool() -> str:
    """返回将使用的加密工具；显式指定不可用/自动模式无工具时返回 ''（调用方 fail-closed）。"""
    explicit = _explicit_tool()
    if explicit:
        return explicit if _tool_available(explicit) else ""
    for tool in _TOOL_ORDER:
        if _tool_available(tool):
            return tool
    return ""


def backup_encryption_status() -> dict:
    """备份加密状态（启动 WARN / 运维检查用，不含任何密钥/口令）。"""
    enabled = backup_encrypt_enabled()
    tool = select_backup_encrypt_tool() if enabled else ""
    warnings = []
    if _is_prod() and not enabled:
        warnings.append("生产环境未开启备份加密（RULEPROOF_BACKUP_ENCRYPT=0）："
                        "备份库含明文密钥/业务数据，建议置 1（age/gpg/openssl）")
    if enabled and not tool:
        warnings.append("已开启备份加密但找不到可用工具（age/gpg/openssl 均不可用）："
                        "备份将 fail-closed 拒绝执行")
    if enabled and tool:
        if tool == "age" and not (os.environ.get("RULEPROOF_BACKUP_AGE_RECIPIENT") or "").strip():
            warnings.append("age 加密缺少收件人 RULEPROOF_BACKUP_AGE_RECIPIENT：备份将 fail-closed")
        if tool == "gpg" and not (os.environ.get("RULEPROOF_BACKUP_GPG_RECIPIENT") or "").strip():
            warnings.append("gpg 加密缺少收件人 RULEPROOF_BACKUP_GPG_RECIPIENT：备份将 fail-closed")
        if tool == "openssl":
            pw, _src = _openssl_passphrase()
            if not pw:
                warnings.append("openssl 加密缺少口令 RULEPROOF_BACKUP_OPENSSL_PASSPHRASE/"
                                "..._FILE：备份将 fail-closed")
            elif len(pw) < 12:
                warnings.append("openssl 备份口令长度 <12：建议使用 KMS 生成的 ≥32 字节口令")
    log = logging.getLogger(__name__)
    for w in warnings:
        log.warning("backup-encryption: %s", w)
    return {"enabled": enabled, "tool": tool, "prod": _is_prod(),
            "suffix": _TOOL_SUFFIX.get(tool, ""), "warnings": warnings}


def _openssl_passphrase() -> tuple[str, str]:
    """openssl 口令来源：优先环境变量，其次口令文件（权限应为 600）。"""
    pw = str(os.environ.get(_OPENSSL_PASS_ENV) or "")
    if pw:
        return pw, "env"
    fp = str(os.environ.get(_OPENSSL_PASS_ENV + "_FILE") or "").strip()
    if fp:
        try:
            return Path(fp).read_text(encoding="utf-8").strip(), "file"
        except Exception:
            return "", "file-error"
    return "", "none"


def _crypto_env(extra: dict | None = None) -> dict:
    env = dict(os.environ)
    if extra:
        env.update({k: str(v) for k, v in extra.items()})
    return env


def _run_crypto(cmd: list[str], *, env: dict, tool: str, action: str) -> None:
    """执行加/解密命令；非 0 退出、超时、异常一律 RuntimeError（fail-closed）。"""
    try:
        p = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=900)
    except FileNotFoundError as e:
        raise RuntimeError(f"备份加密失败（{action}/{tool}）：找不到命令 {cmd[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f"备份加密失败（{action}/{tool}）：命令超时（900s）") from e
    except Exception as e:  # noqa: BLE001 - 任何执行异常都必须上升为 fail-closed
        raise RuntimeError(f"备份加密失败（{action}/{tool}）：{type(e).__name__}: {e}") from e
    if p.returncode != 0:
        tail = (p.stderr or p.stdout or "").strip().replace("\n", " ")[:300]
        raise RuntimeError(f"备份加密失败（{action}/{tool}，exit={p.returncode}）：{tail}")


def _encrypt_file(src: Path, dst: Path, tool: str) -> dict:
    """把明文快照加密到 dst；返回工具元信息（不含密钥）。失败抛错且删除 dst 半成品。"""
    binpath = _tool_binary(tool)
    if not _tool_available(tool):
        raise RuntimeError(f"备份加密失败：工具不可用 {tool}（{binpath}）")
    try:
        if tool == "age":
            recipient = (os.environ.get("RULEPROOF_BACKUP_AGE_RECIPIENT") or "").strip()
            if not recipient:
                raise RuntimeError("备份加密失败：age 缺少收件人 RULEPROOF_BACKUP_AGE_RECIPIENT")
            _run_crypto([binpath, "-r", recipient, "-o", str(dst), str(src)],
                        env=_crypto_env(), tool=tool, action="encrypt")
        elif tool == "gpg":
            recipient = (os.environ.get("RULEPROOF_BACKUP_GPG_RECIPIENT") or "").strip()
            if not recipient:
                raise RuntimeError("备份加密失败：gpg 缺少收件人 RULEPROOF_BACKUP_GPG_RECIPIENT")
            _run_crypto([binpath, "--batch", "--yes", "--trust-model", "always",
                         "-r", recipient, "-e", "-o", str(dst), str(src)],
                        env=_crypto_env(), tool=tool, action="encrypt")
        elif tool == "openssl":
            pw, src_kind = _openssl_passphrase()
            if not pw:
                raise RuntimeError("备份加密失败：openssl 缺少口令 "
                                   f"RULEPROOF_BACKUP_OPENSSL_PASSPHRASE（来源={src_kind}）")
            if not pw.strip() or "\n" in pw:
                raise RuntimeError("备份加密失败：openssl 口令为空或含换行")
            _run_crypto([binpath, "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "200000",
                         "-salt", "-in", str(src), "-out", str(dst),
                         "-pass", f"env:{_OPENSSL_PASS_ENV}"],
                        env=_crypto_env({_OPENSSL_PASS_ENV: pw}), tool=tool, action="encrypt")
        else:
            raise RuntimeError(f"备份加密失败：未知工具 {tool}")
        if not dst.exists() or dst.stat().st_size <= 0:
            raise RuntimeError(f"备份加密失败（{tool}）：输出文件缺失或为空")
        with open(dst, "rb") as f:
            head = f.read(16)
        if head == b"SQLite format 3\x00":
            raise RuntimeError(f"备份加密失败（{tool}）：输出仍是明文 SQLite（fail-closed）")
        return {"tool": tool, "suffix": _TOOL_SUFFIX[tool], "bytes": dst.stat().st_size}
    except Exception:
        try:
            dst.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def is_encrypted_backup(path) -> bool:
    return Path(str(path)).suffix.lower() in tuple(_TOOL_SUFFIX.values())


def decrypt_backup_to_temp(backup_path) -> dict:
    """把加密备份解密到临时文件（0600），返回路径/工具/明文哈希；调用方负责删除。"""
    src = Path(str(backup_path)).resolve()
    if not src.exists():
        raise FileNotFoundError(f"备份不存在：{src}")
    suffix = src.suffix.lower()
    tool = next((t for t, s in _TOOL_SUFFIX.items() if s == suffix), "")
    if not tool:
        raise RuntimeError(f"无法识别加密备份格式：{src.name}")
    if not _tool_available(tool):
        raise RuntimeError(f"解密失败：工具不可用 {tool}")
    tmpdir = Path(tempfile.mkdtemp(prefix="rp_backup_decrypt_"))
    out = tmpdir / "restore.db"
    try:
        binpath = _tool_binary(tool)
        if tool == "age":
            identity = (os.environ.get("RULEPROOF_BACKUP_AGE_IDENTITY") or "").strip()
            if not identity:
                raise RuntimeError("解密失败：age 缺少身份文件 RULEPROOF_BACKUP_AGE_IDENTITY")
            _run_crypto([binpath, "-d", "-i", identity, "-o", str(out), str(src)],
                        env=_crypto_env(), tool=tool, action="decrypt")
        elif tool == "gpg":
            _run_crypto([binpath, "--batch", "--yes", "-d", "-o", str(out), str(src)],
                        env=_crypto_env(), tool=tool, action="decrypt")
        else:
            pw, src_kind = _openssl_passphrase()
            if not pw:
                raise RuntimeError("解密失败：openssl 缺少口令 "
                                   f"RULEPROOF_BACKUP_OPENSSL_PASSPHRASE（来源={src_kind}）")
            _run_crypto([binpath, "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-iter", "200000",
                         "-in", str(src), "-out", str(out),
                         "-pass", f"env:{_OPENSSL_PASS_ENV}"],
                        env=_crypto_env({_OPENSSL_PASS_ENV: pw}), tool=tool, action="decrypt")
        if not out.exists() or out.stat().st_size <= 0:
            raise RuntimeError(f"解密失败（{tool}）：输出缺失或为空")
        check = integrity_check(out)
        if not check.get("ok"):
            raise RuntimeError(f"解密后完整性校验失败：{check.get('result')}")
        try:
            os.chmod(out, 0o600)
        except Exception:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        return {"ok": True, "tool": tool, "plaintext": str(out), "tmpdir": str(tmpdir),
                "bytes": out.stat().st_size, "sha256": _sha256(out),
                "integrity": check.get("result")}
    except Exception:
        shutil.rmtree(tmpdir, ignore_errors=True)
        raise


def _stamp() -> str:
    return time.strftime("%Y%m%d-%H%M%S")


def _sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def default_backup_dir(db_path: str | Path) -> Path:
    return Path(db_path).resolve().parent / "backups"


def _unique(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    for i in range(1, 1000):
        cand = path.with_name(f"{stem}-{i}{suffix}")
        if not cand.exists():
            return cand
    raise RuntimeError(f"无法生成唯一备份文件名：{path}")


def integrity_check(path: str | Path) -> dict:
    """对指定 SQLite 文件做完整校验（只读）。"""
    p = str(path)
    conn = sqlite3.connect(f"file:{_uri_path(p)}?mode=ro&immutable=1", uri=True, timeout=30)
    try:
        row = conn.execute("PRAGMA integrity_check").fetchone()
        result = row[0] if row else "unknown"
        ok = str(result).lower() == "ok"
        return {"ok": ok, "result": result}
    finally:
        conn.close()


def _uri_path(path: str) -> str:
    # sqlite URI 对空格/中文路径需要 percent-encode
    import urllib.parse
    return urllib.parse.quote(os.path.abspath(path))


def _resolve_target(src_path: Path, out_path, backup_dir, label: str,
                    encrypt_suffix: str = "") -> Path:
    if out_path:
        target = Path(out_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        if encrypt_suffix and not target.name.lower().endswith(encrypt_suffix):
            target = target.with_name(target.name + encrypt_suffix)
        return _unique(target)
    bdir = Path(backup_dir) if backup_dir else default_backup_dir(src_path)
    bdir.mkdir(parents=True, exist_ok=True)
    return _unique(bdir / f"{src_path.stem}-{label}-{_stamp()}.db{encrypt_suffix}")


def _sqlite_snapshot(src_path: Path, dst: Path) -> None:
    src = sqlite3.connect(str(src_path), timeout=30)
    dst_conn = sqlite3.connect(str(dst), timeout=30)
    try:
        src.backup(dst_conn)
        dst_conn.commit()
    finally:
        try:
            dst_conn.close()
        finally:
            src.close()


def backup(db_path: str | Path, out_path: str | Path | None = None,
           backup_dir: str | Path | None = None, label: str = "backup") -> dict:
    """在线备份到 ``out_path`` 或 ``backup_dir``，返回真实路径/sha256/字节数。

    开启 ``RULEPROOF_BACKUP_ENCRYPT`` 时先输出到临时明文快照（0600），加密成功后
    立即删除明文，只保留密文；任何加密失败都 fail-closed（无明文/半成品落盘）。
    """
    src_path = Path(db_path).resolve()
    if not src_path.exists():
        raise FileNotFoundError(f"数据库不存在：{src_path}")
    if src_path.stat().st_size == 0:
        raise ValueError(f"数据库文件为空，拒绝备份：{src_path}")

    if not backup_encrypt_enabled():
        target = _resolve_target(src_path, out_path, backup_dir, label)
        _sqlite_snapshot(src_path, target)
        check = integrity_check(target)
        if not check.get("ok"):
            # 备份不可用：删除半成品并显式失败
            try:
                target.unlink(missing_ok=True)
            except Exception:
                logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
            raise RuntimeError(f"备份完整性校验失败：{check.get('result')}")
        if _is_prod():
            logging.getLogger(__name__).warning(
                "backup-encryption: 生产环境生成明文备份 %s；建议 RULEPROOF_BACKUP_ENCRYPT=1", target)
        return {
            "ok": True,
            "db": str(src_path),
            "backup": str(target),
            "bytes": target.stat().st_size,
            "sha256": _sha256(target),
            "integrity": check.get("result"),
            "encrypted": False,
            "encryption": None,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }

    tool = select_backup_encrypt_tool()
    if not tool:
        raise RuntimeError(
            "备份加密已开启（RULEPROOF_BACKUP_ENCRYPT）但找不到可用工具（age/gpg/openssl）："
            "fail-closed 拒绝生成明文备份")
    signature = _TOOL_SUFFIX[tool]
    target = _resolve_target(src_path, out_path, backup_dir, label, encrypt_suffix=signature)
    tmpdir = Path(tempfile.mkdtemp(prefix="rp_backup_plain_"))
    plain = tmpdir / "snapshot.db"
    try:
        os.chmod(plain if plain.exists() else tmpdir, 0o700)
        _sqlite_snapshot(src_path, plain)
        try:
            os.chmod(plain, 0o600)
        except Exception:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        check = integrity_check(plain)
        if not check.get("ok"):
            raise RuntimeError(f"备份完整性校验失败：{check.get('result')}")
        plain_bytes = plain.stat().st_size
        plain_sha = _sha256(plain)
        enc_meta = _encrypt_file(plain, target, tool)
    except Exception:
        try:
            target.unlink(missing_ok=True)
        except Exception:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        raise
    finally:
        try:
            plain.unlink(missing_ok=True)
        except Exception:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        shutil.rmtree(tmpdir, ignore_errors=True)
    return {
        "ok": True,
        "db": str(src_path),
        "backup": str(target),
        "bytes": target.stat().st_size,
        "sha256": _sha256(target),
        "integrity": check.get("result"),
        "encrypted": True,
        "encryption": {**enc_meta, "plaintext_bytes": plain_bytes,
                       "plaintext_sha256": plain_sha},
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def _restore_plain(db_path: str | Path, backup_path: str | Path,
                   safety_backup: bool = True, backup_dir: str | Path | None = None,
                   original_path: str | Path | None = None) -> dict:
    target = Path(db_path).resolve()
    src_path = Path(backup_path).resolve()
    if not src_path.exists():
        raise FileNotFoundError(f"备份不存在：{src_path}")
    check = integrity_check(src_path)
    if not check.get("ok"):
        raise RuntimeError(f"备份文件损坏，拒绝恢复：{check.get('result')}")

    safety = None
    if safety_backup and target.exists() and target.stat().st_size > 0:
        safety = backup(target, backup_dir=backup_dir or default_backup_dir(target),
                        label="pre-restore")

    target.parent.mkdir(parents=True, exist_ok=True)
    src = sqlite3.connect(str(src_path), timeout=30)
    dst = sqlite3.connect(str(target), timeout=30)
    try:
        src.backup(dst)
        dst.commit()
    finally:
        try:
            dst.close()
        finally:
            src.close()

    after = integrity_check(target)
    if not after.get("ok"):
        raise RuntimeError(f"恢复后完整性校验失败：{after.get('result')}")
    return {
        "ok": True,
        "db": str(target),
        "from": str(original_path or src_path),
        "safety_backup": (safety or {}).get("backup"),
        "bytes": target.stat().st_size,
        "sha256": _sha256(target),
        "integrity": after.get("result"),
    }


def restore(db_path: str | Path, backup_path: str | Path,
            safety_backup: bool = True, backup_dir: str | Path | None = None) -> dict:
    """从备份恢复数据库；默认先把当前库另存一份，便于二次回滚。

    支持明文 ``.db`` 与加密备份 ``.age``/``.gpg``/``.enc``：加密备份先解密到
    0600 临时文件，校验后恢复，结束后删除临时明文。
    """
    src_path = Path(backup_path).resolve()
    if is_encrypted_backup(src_path):
        dec = decrypt_backup_to_temp(src_path)
        try:
            return _restore_plain(db_path, dec["plaintext"], safety_backup=safety_backup,
                                  backup_dir=backup_dir, original_path=src_path)
        finally:
            shutil.rmtree(dec.get("tmpdir") or "", ignore_errors=True)
    return _restore_plain(db_path, src_path, safety_backup=safety_backup,
                          backup_dir=backup_dir)
