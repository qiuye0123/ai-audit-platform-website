"""企业业务词典：术语定义、同义词、不等同、来源、版本、确认状态。

只管理“会改变审核结论的词”；概念属于规则体系，本次事实属于证据。

本模块另外承担四个最小闭环：

1. 旧 ``workspace.settings_json.ontology_terms`` → ``business_term`` + ``onto_alias``
   的幂等迁移：保留租户/空间/来源/状态，不覆盖已确认术语，空数据显式失败；
2. not_equal 的可查询入口与冲突检测，并阻止“不等同”词对被别名归一；
3. 已生效业务术语 → ``onto_entity`` 的幂等投影：保留类型/单位/关系/租户/空间/来源，
   不覆盖人工维护或已确认的本体实体，冲突逐条记录，空数据显式失败；
4. ``business_term`` 增删改/确认/降级时同步或反投影 ``onto_alias``/``onto_entity``，
   冲突（别名占用、人工实体、not_equal、孤儿投影）写入 ``conflict`` 表并可查询；
   重复 create/update/confirm 幂等，旧确认人与时间不被覆盖。

迁移到 ``onto_alias`` 的别名与投影出的 ``onto_entity`` 实体统一使用
``BusinessTerm:<workspace_id>`` 命名空间，避免与引擎本体（Metric/Field 等）
的类型和实体混用；同一别名/实体在引擎载入后按同一作用域解析，跨空间同名概念
不会互相覆盖。
"""
from __future__ import annotations
import logging
import hashlib
import json
import re
from .. import db, repositories as R
from . import ctx as _ctx

# 已生效状态：confirmed 是人工确认；active 是旧 ontology_terms 的“已启用”语义。
EFFECTIVE_STATUSES = ("confirmed", "active")
_LEGACY_ALIAS_TYPE_PREFIX = "BusinessTerm:"
_NOT_EQUAL_TYPES = {"不等同", "not_equal", "not-equal", "不等于", "!=", "≠"}


_TERM_STATUSES = ("draft", "candidate", "confirmed", "active", "ignored")
_EFFECTIVE_STATUS_SET = {"confirmed", "active"}
_STALE_ALIAS_SOURCE = "business_term:stale"
_CONFLICT_TYPE_PREFIX = "term_"
_CONFLICT_KIND_TO_TYPE = {
    "alias_conflict": "term_alias_conflict",
    "term_key_conflict": "term_key_conflict",
    "term_name_conflict": "term_name_conflict",
    "entity_id_conflict": "term_entity_conflict",
    "business_term_entity_conflict": "term_entity_conflict",
    "confirmed_entity_conflict": "term_confirmed_entity_conflict",
    "manual_entity_conflict": "term_manual_entity_conflict",
    "not_equal_self": "term_not_equal_self",
    "not_equal_alias_merge": "term_not_equal_alias_merge",
    "not_equal_alias_shared": "term_not_equal_alias_shared",
    "reverse_orphan": "term_reverse_orphan",
    "reverse_entity_skipped": "term_reverse_entity_skipped",
}
_CONFLICT_SUGGESTION = {
    "term_alias_conflict": "保留既有归属；先解除旧术语的同义关系或改为不等同，再重新确认",
    "term_key_conflict": "修改术语 key/标准名后重试；不要复用其他术语的 key",
    "term_name_conflict": "同一空间存在同标准名的其他术语，先改名或合并",
    "term_entity_conflict": "本体中已有同主键/同名实体，先处理本体冲突再投影",
    "term_confirmed_entity_conflict": "同名本体实体已确认，词典投影不会覆盖；请人工确认是否合并",
    "term_manual_entity_conflict": "同名本体实体为人工维护，词典投影不会覆盖；请人工确认是否合并",
    "term_not_equal_self": "删除与自身名称/同义词冲突的“不等同”声明",
    "term_not_equal_alias_merge": "解除会把互斥概念合并的别名声明",
    "term_not_equal_alias_shared": "同一别名只能归属一个已生效术语；调整别名或声明",
    "term_reverse_orphan": "清理已指向不存在/已降级术语的别名或实体投影",
    "term_reverse_entity_skipped": "该实体不是词典投影，删除术语时保留；由本体管理员单独处理",
}


def _fail(error: str, code: str, http_status: int = 400, **extra) -> dict:
    """统一的失败返回：HTTP 层可用 ``http_status`` 映射 400/404/409，不伪装成功。"""
    return {"ok": False, "error": error, "code": code,
            "http_status": int(http_status), **extra}


def _not_found(term_id: str = "") -> dict:
    return _fail(f"术语不存在：{term_id}" if _text(term_id) else "术语 ID 不能为空",
                 "term_not_found", 404)


def _scope() -> tuple[str, str]:
    c = _ctx.get_context() or {}
    return c.get("tenant_id") or "", c.get("workspace_id") or ""



def _term_in_scope(c, term_id: str) -> dict | None:
    """只允许读取当前租户/空间内的术语；跨空间一律视为不存在（404）。"""
    t, w = _scope()
    row = c.execute("SELECT * FROM business_term WHERE id=? AND tenant_id=? AND workspace_id=?",
                    (_text(term_id), t, w)).fetchone()
    return dict(row) if row else None


def _status(value, default: str = "draft") -> str:
    return _text(value).lower() or default


def _row(x: dict) -> dict:
    d = dict(x)
    d["term_id"] = d.get("id")
    for k in ("synonyms_json", "not_equal_json", "relations_json"):
        try:
            d[k.replace("_json", "")] = json.loads(d.get(k) or "[]")
        except Exception:
            d[k.replace("_json", "")] = []
    d["not_equal_count"] = len(d.get("not_equal") or [])
    d["effective"] = _is_effective_status(d.get("status"))
    return d


def _text(value) -> str:
    return str(value or "").strip()


def _name(value) -> str:
    """术语比较用规范化：去首尾空白、全角空格和内部空格，不做大小写折叠（中文为主）。"""
    return _text(value).replace("\u3000", "").replace(" ", "")


def _term_key(name: str) -> str:
    """与 create_term 保持同一 term_key 规则。"""
    return _text(name).upper().replace(" ", "-")


def _as_list(value) -> list:
    """兼容历史设置里的 list / JSON 字符串 / 逗号分隔字符串 / 单值。"""
    if value is None:
        return []
    if isinstance(value, dict):
        for k in ("alias", "name", "value", "term"):
            if value.get(k):
                return [str(value[k])]
        return []
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return []
        try:
            parsed = json.loads(s)
        except Exception:
            parsed = None
        if parsed is not None and not isinstance(parsed, str):
            return _as_list(parsed)
        return [x.strip() for x in re.split(r"[,，;；|、\n]+", s) if x.strip()]
    if isinstance(value, (list, tuple, set)):
        out = []
        for x in value:
            if isinstance(x, dict):
                for k in ("alias", "name", "value", "term"):
                    if x.get(k):
                        out.append(str(x[k]))
                        break
            elif x is not None and str(x).strip():
                out.append(str(x))
        return out
    return []


def _clean_names(values) -> list:
    """去空、去重，保持首次出现顺序。"""
    out, seen = [], set()
    for x in values or []:
        s = _text(x)
        k = _name(s)
        if not s or not k or k in seen:
            continue
        seen.add(k)
        out.append(s)
    return out


def _load_json_list(value) -> list:
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value or "[]")
        except Exception:
            return []
        return parsed if isinstance(parsed, list) else []
    return []


def _as_relations(value) -> list:
    return [x for x in _load_json_list(value) if isinstance(x, dict)]


def _dedupe_relations(values) -> list:
    out, seen = [], set()
    for r in values or []:
        if not isinstance(r, dict):
            continue
        sig = json.dumps(r, ensure_ascii=False, sort_keys=True)
        if sig in seen:
            continue
        seen.add(sig)
        out.append(r)
    return out


def _legacy_item_aliases(item: dict) -> list:
    canonical = item.get("canonical") or item.get("name")
    raw = []
    for key in ("aliases", "synonyms", "synonyms_json", "alias"):
        raw.append(item.get(key))
    out = []
    for v in raw:
        out.extend(_as_list(v))
    return [x for x in _clean_names(out) if _name(x) != _name(canonical)]


def _legacy_item_not_equal(item: dict) -> list:
    raw = []
    for key in ("not_equal", "not_equal_json", "notEquals", "not_equal_list"):
        raw.append(item.get(key))
    out = []
    for v in raw:
        out.extend(_as_list(v))
    # 新版词典投影到旧本体时，not_equal 会写成 relations 里的“不等同”；迁移时还原。
    for rel in _as_relations(item.get("relations")):
        if _text(rel.get("type")) in _NOT_EQUAL_TYPES:
            out.extend(_as_list(rel.get("to") or rel.get("target") or rel.get("value")))
    return _clean_names(out)


def _legacy_item_relations(item: dict) -> list:
    """保留非“不等同”的关系；not_equal 单独入 not_equal_json，避免投影时重复。"""
    return [r for r in _as_relations(item.get("relations"))
            if _text(r.get("type")) not in _NOT_EQUAL_TYPES]


def _settings_dict(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    try:
        d = json.loads(raw or "{}")
    except Exception:
        return {}
    return d if isinstance(d, dict) else {}


def _legacy_terms_in_settings(settings: dict) -> list:
    raw = settings.get("ontology_terms") if isinstance(settings, dict) else None
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return []
    if isinstance(raw, dict):
        # 兼容 {canonical: {...}} 的极早期设置形态。
        raw = [dict(v, canonical=(v.get("canonical") if isinstance(v, dict) else k)
                    or k) if isinstance(v, dict) else {"canonical": k}
               for k, v in raw.items()]
    if not isinstance(raw, list):
        return []
    out = []
    for x in raw:
        if isinstance(x, dict):
            out.append(x)
        elif x is not None and _text(x):
            out.append({"canonical": _text(x)})
    return out


def _legacy_workspaces(tenant_id: str = "", workspace_id: str = "") -> list:
    c = db.connect()
    try:
        sql = "SELECT id,tenant_id,name,status,settings_json FROM workspace WHERE 1=1"
        args = []
        if tenant_id:
            sql += " AND tenant_id=?"
            args.append(tenant_id)
        if workspace_id:
            sql += " AND id=?"
            args.append(workspace_id)
        sql += " ORDER BY tenant_id,id"
        return [dict(r) for r in c.execute(sql, args).fetchall()]
    finally:
        c.close()


def _find_existing_term(c, tenant_id: str, workspace_id: str, key: str, name: str):
    row = c.execute(
        "SELECT * FROM business_term WHERE tenant_id=? AND workspace_id=? "
        "AND (term_key=? OR name=?) "
        "ORDER BY CASE WHEN status='confirmed' THEN 0 ELSE 1 END, rowid LIMIT 1",
        (tenant_id, workspace_id, key, name)).fetchone()
    return dict(row) if row else None


def _alias_owner_index(c) -> dict:
    idx = {}
    for r in c.execute("SELECT id,type_key,alias,entity_id,source,status FROM onto_alias"):
        d = dict(r)
        idx.setdefault(_name(d.get("alias")), []).append(d)
    return idx


def _insert_alias(c, workspace_id: str, term_id: str, alias: str, evidence: str,
                  source: str, status: str, created_at: str) -> dict:
    type_key = _LEGACY_ALIAS_TYPE_PREFIX + (workspace_id or "default")
    aid = db.new_id("oa")
    try:
        c.execute("INSERT INTO onto_alias(id,type_key,alias,entity_id,evidence,source,status,created_at) "
                  "VALUES(?,?,?,?,?,?,?,?)",
                  (aid, type_key, alias, term_id, evidence, source, status, created_at))
    except Exception as e:
        if "no column" not in str(e).lower():
            raise
        c.execute("INSERT INTO onto_alias(id,type_key,alias,entity_id) VALUES(?,?,?,?)",
                  (aid, type_key, alias, term_id))
    return {"id": aid, "type_key": type_key, "alias": alias, "entity_id": term_id,
            "source": source, "status": status}


def _term_json_list(term: dict, base: str) -> list:
    """兼容 DB 原始行（*_json）与 _row() 后的 list 字段。"""
    raw = term.get(base + "_json")
    if raw is None or raw == "":
        raw = term.get(base)
    return _load_json_list(raw)


def _alias_projection_status(term: dict) -> str:
    st = _status(term.get("status"), "draft")
    return st if _is_effective_status(st) else "stale"


def _alias_projection_evidence(term: dict) -> str:
    return (_text(term.get("definition")) or _text(term.get("source")) or "业务词典确认")[:500]


def _alias_projection_source(term: dict) -> str:
    return _text(term.get("source")) or _ENTITY_PROJECTION_SOURCE


def _owner_term_row(c, entity_id: str) -> dict | None:
    row = c.execute("SELECT id,name,status,tenant_id,workspace_id FROM business_term WHERE id=?",
                    (_text(entity_id),)).fetchone()
    return dict(row) if row else None


def _mark_alias_stale(c, row: dict) -> bool:
    """把别名落成可审计的 stale 墓碑；清空 evidence 使运行时本体不再载入它。"""
    if _text(row.get("status")) == "stale" and _text(row.get("source")) == _STALE_ALIAS_SOURCE:
        return False
    c.execute("UPDATE onto_alias SET status='stale',source=?,evidence='' WHERE id=?",
              (_STALE_ALIAS_SOURCE, row.get("id")))
    row.update({"status": "stale", "source": _STALE_ALIAS_SOURCE, "evidence": ""})
    return True


def _reactivate_alias(c, row: dict, term: dict) -> bool:
    status = _alias_projection_status(term)
    stale = _text(row.get("status")) == "stale" or _text(row.get("source")) == _STALE_ALIAS_SOURCE
    if stale:
        source = _alias_projection_source(term)
        evidence = _alias_projection_evidence(term)
    else:
        # 既有活动别名保留迁移/人工来源与依据，只同步状态。
        source = _text(row.get("source")) or _alias_projection_source(term)
        evidence = _text(row.get("evidence")) or _alias_projection_evidence(term)
    if (_text(row.get("status")) == status and _text(row.get("source")) == source
            and _text(row.get("evidence")) == evidence):
        return False
    c.execute("UPDATE onto_alias SET status=?,source=?,evidence=? WHERE id=?",
              (status, source, evidence, row.get("id")))
    row.update({"status": status, "source": source, "evidence": evidence})
    return True


def _sync_term_aliases(c, term: dict, actor: str = "", conflicts: list | None = None,
                       create: bool = True) -> dict:
    """把术语同义词同步到 onto_alias（确认/更新时调用，降级时只落 stale）。

    - 已确认/生效术语：补齐缺失别名、恢复 stale 别名、删除已移除的同义词；
    - draft/candidate：不新建别名，只把本术语名下仍为 active 的别名落 stale；
    - 其他已生效术语占用的别名不覆盖（旧确认优先），写 alias 冲突；
    - 指向不存在/未生效术语的陈旧别名视为可回收，先清理再归属当前术语。
    """
    conflicts = conflicts if conflicts is not None else []
    tid = _text(term.get("id") or term.get("term_id"))
    tenant_id = _text(term.get("tenant_id"))
    workspace_id = _text(term.get("workspace_id"))
    type_key = _LEGACY_ALIAS_TYPE_PREFIX + (workspace_id or "default")
    name = _text(term.get("name"))
    effective = _is_effective_status(term.get("status"))
    syn = _clean_names([x for x in _as_list(_term_json_list(term, "synonyms"))
                        if _name(x) != _name(name)])
    forbidden = {_name(x) for x in _clean_names(_as_list(_term_json_list(term, "not_equal")))}
    desired = [x for x in syn if _name(x) not in forbidden]
    res = {"created": 0, "existing": 0, "reactivated": 0, "updated": 0,
           "deleted": 0, "staled": 0, "replaced": 0, "conflicts": conflicts}
    if not tid:
        return res
    own_rows = [dict(r) for r in c.execute(
        "SELECT id,type_key,alias,entity_id,evidence,source,status,created_at "
        "FROM onto_alias WHERE entity_id=? ORDER BY created_at,alias", (tid,)).fetchall()]
    if not effective:
        for row in own_rows:
            if _mark_alias_stale(c, row):
                res["staled"] += 1
        return res
    # 同义词与 not_equal 自相矛盾时不静默投影别名（否则归一链会违背“不等同”声明）；
    # 冲突照常写入冲突表，等待人工修正后重新确认/更新。
    self_conflict = sorted({_name(x) for x in syn} & forbidden)
    if self_conflict and create:
        create = False
        for value in self_conflict:
            conflicts.append({
                "kind": "not_equal_self", "severity": "critical",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": tid, "name": name, "value": value,
                "detail": "术语的同义词同时被声明为 not_equal，未投影该组别名",
            })

    status = _alias_projection_status(term)
    source = _alias_projection_source(term)
    evidence = _alias_projection_evidence(term)
    created_at = db.now()
    alias_index = _alias_owner_index(c)
    owner_cache = {}
    entity_names = {}
    for r in c.execute("SELECT id,type_key,name FROM onto_entity WHERE type_key=?",
                       (type_key,)).fetchall():
        nm = _name(r["name"])
        if nm:
            entity_names.setdefault(nm, dict(r))
    matched_ids = set()
    for alias in desired:
        an = _name(alias)
        if not an:
            continue
        rows_here = alias_index.get(an, [])
        mine = next((r for r in rows_here if _text(r.get("entity_id")) == tid), None)
        if mine is not None:
            matched_ids.add(_text(mine.get("id")))
            if _reactivate_alias(c, mine, term):
                res["updated"] += 1
            else:
                res["existing"] += 1
            continue
        entity = entity_names.get(an)
        if entity is not None and _text(entity.get("id")) != tid:
            conflicts.append({
                "kind": "alias_conflict", "severity": "warning",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": tid, "name": name, "alias": alias,
                "existing_entity_id": _text(entity.get("id")),
                "existing_type_key": _text(entity.get("type_key")),
                "existing_name": _text(entity.get("name")),
                "detail": "同义词与同命名空间内的其他本体实体标准名冲突，未写入别名（不覆盖既有实体）",
            })
            continue
        blocking, free = [], []
        for r in rows_here:
            if _text(r.get("entity_id")) == tid:
                continue
            if _text(r.get("type_key")) != type_key:
                continue
            oid = _text(r.get("entity_id"))
            if oid not in owner_cache:
                owner_cache[oid] = _owner_term_row(c, oid)
            owner = owner_cache[oid]
            if owner is not None and _is_effective_status(owner.get("status")):
                blocking.append((r, owner))
            else:
                free.append(r)
        if blocking:
            row, owner = blocking[0]
            conflicts.append({
                "kind": "alias_conflict", "severity": "warning",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": tid, "name": name, "alias": alias,
                "existing_entity_id": _text(row.get("entity_id")),
                "existing_type_key": _text(row.get("type_key")),
                "existing_name": _text(owner.get("name")),
                "existing_status": _text(owner.get("status")),
                "detail": "别名已被同空间内其他已生效术语占用，保留旧归属（旧确认不覆盖）",
            })
            continue
        for row in free:
            c.execute("DELETE FROM onto_alias WHERE id=?", (row.get("id"),))
            try:
                alias_index[an].remove(row)
            except ValueError:
                logging.getLogger(__name__).debug("ignored", exc_info=True)
            res["replaced"] += 1
        if not create:
            continue
        row = _insert_alias(c, workspace_id, tid, alias, evidence, source, status, created_at)
        alias_index.setdefault(an, []).append(row)
        res["created"] += 1

    for row in own_rows:
        if _text(row.get("id")) in matched_ids:
            continue
        c.execute("DELETE FROM onto_alias WHERE id=?", (row.get("id"),))
        try:
            alias_index[_name(row.get("alias"))].remove(row)
        except (KeyError, ValueError):
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        res["deleted"] += 1
    return res


def _ensure_alias(c, alias_index: dict, tenant_id: str, workspace_id: str, term_id: str,
                  alias: str, evidence: str, source: str, status: str, created_at: str,
                  conflicts: list) -> tuple[int, int]:
    """返回 (新增, 已存在)；别名已被其他实体占用时只报告冲突，不覆盖。"""
    an = _name(alias)
    if not an:
        return 0, 0
    rows = alias_index.get(an, [])
    for r in rows:
        if _text(r.get("entity_id")) == term_id:
            return 0, 1
    # 只在同一工作空间命名空间内判定“别名已被占用”；不同空间可各自持有同一别名。
    type_key = _LEGACY_ALIAS_TYPE_PREFIX + (workspace_id or "default")
    same_scope = [r for r in rows if _text(r.get("type_key")) == type_key]
    if same_scope:
        conflicts.append({
            "kind": "alias_conflict", "severity": "warning",
            "tenant_id": tenant_id, "workspace_id": workspace_id,
            "term_id": term_id, "alias": alias,
            "existing_type": same_scope[0].get("type_key"),
            "existing_entity": same_scope[0].get("entity_id"),
            "detail": "同一工作空间内别名已被其他术语占用，未迁移该别名（不覆盖既有归属）",
        })
        return 0, 0
    row = _insert_alias(c, workspace_id, term_id, alias, evidence, source, status, created_at)
    alias_index.setdefault(an, []).append(row)
    return 1, 0


# ---------------------------------------------------------------- 冲突表（词典专用）

def _conflict_type_for(kind: str) -> str:
    raw = _text(kind)
    mapped = _CONFLICT_KIND_TO_TYPE.get(raw)
    if mapped:
        return mapped
    if raw.startswith(_CONFLICT_TYPE_PREFIX):
        return raw
    return _CONFLICT_TYPE_PREFIX + raw.replace(" ", "_")


def _conflict_severity(kind: str, fallback: str = "") -> str:
    if _text(kind) in ("not_equal_self", "not_equal_alias_merge"):
        return "critical"
    if _text(kind) in ("reverse_orphan",):
        return "info"
    return _text(fallback) or "warning"


def _term_conflict_id(conflict_type: str, tenant_id: str, workspace_id: str,
                      term_id: str = "", other: str = "", value: str = "") -> str:
    raw = "|".join((_text(conflict_type), _text(tenant_id), _text(workspace_id),
                    _text(term_id), _text(other), _text(value)))
    return "cf-term-" + hashlib.sha1(raw.encode("utf-8")).hexdigest()[:20]


def _term_conflict_payload(conflict: dict) -> dict:
    """把服务层冲突（kind）规整成 conflict 表的一行；id 稳定，重复检测不重复插入。"""
    kind = _text(conflict.get("kind") or conflict.get("conflict_type") or "term_conflict")
    ctype = _conflict_type_for(kind)
    tenant_id = _text(conflict.get("tenant_id"))
    workspace_id = _text(conflict.get("workspace_id"))
    if not tenant_id or not workspace_id:
        t, w = _scope()
        tenant_id = tenant_id or t
        workspace_id = workspace_id or w
    term_id = _text(conflict.get("term_id"))
    other = _text(conflict.get("existing_entity_id") or conflict.get("existing_term_id")
                  or conflict.get("other_term_id") or conflict.get("existing_id")
                  or conflict.get("alias") or conflict.get("name"))
    value = _text(conflict.get("alias") or conflict.get("value") or conflict.get("name"))
    cid = _term_conflict_id(ctype, tenant_id, workspace_id, term_id, other, value)
    slots_a = {
        "kind": kind, "term_id": term_id, "term_name": _text(conflict.get("name")),
        "term_status": _text(conflict.get("term_status") or conflict.get("status")),
        "alias": _text(conflict.get("alias")), "value": _text(conflict.get("value")),
        "term_ids": list(conflict.get("term_ids") or []),
        "names": list(conflict.get("names") or []),
    }
    slots_b = {
        "existing_entity_id": _text(conflict.get("existing_entity_id")),
        "existing_type_key": _text(conflict.get("existing_type_key")),
        "existing_name": _text(conflict.get("existing_name")),
        "existing_source": _text(conflict.get("existing_source")),
        "existing_status": _text(conflict.get("existing_status")),
        "existing_tenant_id": _text(conflict.get("existing_tenant_id")),
        "existing_workspace_id": _text(conflict.get("existing_workspace_id")),
        "other_term_id": _text(conflict.get("other_term_id")),
        "other_name": _text(conflict.get("other_name")),
        "detail": _text(conflict.get("detail")),
    }
    detail = _text(conflict.get("detail")) or f"{kind}: 词典投影冲突"
    if conflict.get("existing_name"):
        detail += f"（既有：{_text(conflict.get('existing_name'))}）"
    return {
        "id": cid, "kind": kind, "type": ctype,
        "rule_a": term_id, "rule_b": other,
        "detail": detail,
        "severity": _conflict_severity(kind, _text(conflict.get("severity"))),
        "suggestion": _text(conflict.get("suggestion")) or _CONFLICT_SUGGESTION.get(ctype, ""),
        "slots_a": json.dumps(slots_a, ensure_ascii=False),
        "slots_b": json.dumps(slots_b, ensure_ascii=False),
        "tenant_id": tenant_id, "workspace_id": workspace_id,
    }


def _upsert_term_conflict(c, conflict: dict, actor: str = "") -> dict:
    """写入/刷新一条词典冲突；已裁决（resolved/ignored）的记录不重开。"""
    row = _term_conflict_payload(conflict)
    old = c.execute("SELECT status,note FROM conflict WHERE id=?", (row["id"],)).fetchone()
    if old is not None and _text(old["status"]) in ("resolved", "ignored"):
        # 人工裁决（resolved/ignored）不重开；自动关闭的冲突再次出现时恢复 open。
        if _text(old["status"]) == "resolved" and "自动关闭" in _text(old["note"]):
            c.execute("UPDATE conflict SET rule_a=?,rule_b=?,type=?,detail=?,severity=?,"
                      "suggestion=?,slots_a=?,slots_b=?,tenant_id=?,workspace_id=?,"
                      "status='open',resolved_at='',resolved_by='',note='' WHERE id=?",
                      (row["rule_a"], row["rule_b"], row["type"], row["detail"],
                       row["severity"], row["suggestion"], row["slots_a"], row["slots_b"],
                       row["tenant_id"], row["workspace_id"], row["id"]))
            return {"id": row["id"], "action": "reopened"}
        return {"id": row["id"], "action": "kept"}
    if old is not None:
        c.execute("UPDATE conflict SET rule_a=?,rule_b=?,type=?,detail=?,severity=?,suggestion=?,"
                  "slots_a=?,slots_b=?,tenant_id=?,workspace_id=? WHERE id=?",
                  (row["rule_a"], row["rule_b"], row["type"], row["detail"],
                   row["severity"], row["suggestion"], row["slots_a"], row["slots_b"],
                   row["tenant_id"], row["workspace_id"], row["id"]))
        return {"id": row["id"], "action": "updated"}
    c.execute(
        "INSERT INTO conflict(id,rule_a,rule_b,type,detail,status,created_at,severity,"
        "suggestion,slots_a,slots_b,resolved_at,resolved_by,note,tenant_id,workspace_id) "
        "VALUES(?,?,?,?,?,'open',?,?,?,?,?,'','','',?,?)",
        (row["id"], row["rule_a"], row["rule_b"], row["type"], row["detail"], db.now(),
         row["severity"], row["suggestion"], row["slots_a"], row["slots_b"],
         row["tenant_id"], row["workspace_id"]))
    return {"id": row["id"], "action": "inserted"}


def _record_term_conflicts(conflicts: list, actor: str = "") -> dict:
    """批量持久化冲突；返回 inserted/updated/kept 计数。空列表不写库。"""
    out = {"inserted": 0, "updated": 0, "kept": 0, "ids": []}
    items = [x for x in (conflicts or []) if isinstance(x, dict)]
    if not items:
        return out
    c = db.connect()
    try:
        for item in items:
            r = _upsert_term_conflict(c, item, actor=actor)
            if r["id"] not in out["ids"]:
                out["ids"].append(r["id"])
            out[r["action"]] = out.get(r["action"], 0) + 1
        c.commit()
    finally:
        c.close()
    return out


def _merge_existing_term(c, existing: dict, aliases: list, not_equal: list, relations: list,
                         definition: str, source: str, scope: str, entity_type: str,
                         unit: str) -> bool:
    """非 confirmed 的既有术语只做“补空/并集”，不覆盖其已有内容；幂等。"""
    syn = _clean_names(_as_list(_load_json_list(existing.get("synonyms_json"))) + list(aliases or []))
    ne = _clean_names(_as_list(_load_json_list(existing.get("not_equal_json"))) + list(not_equal or []))
    rel = _dedupe_relations([x for x in _load_json_list(existing.get("relations_json")) if isinstance(x, dict)]
                            + list(relations or []))
    patch = {}
    if syn != _as_list(_load_json_list(existing.get("synonyms_json"))):
        patch["synonyms_json"] = json.dumps(syn, ensure_ascii=False)
    if ne != _as_list(_load_json_list(existing.get("not_equal_json"))):
        patch["not_equal_json"] = json.dumps(ne, ensure_ascii=False)
    if rel != _dedupe_relations([x for x in _load_json_list(existing.get("relations_json")) if isinstance(x, dict)]):
        patch["relations_json"] = json.dumps(rel, ensure_ascii=False)
    for col, value in (("definition", definition), ("source", source), ("scope", scope),
                       ("entity_type", entity_type), ("unit", unit)):
        if value and not _text(existing.get(col)):
            patch[col] = value
    if not patch:
        return False
    sets = ",".join(f"{k}=?" for k in patch)
    c.execute(f"UPDATE business_term SET {sets} WHERE id=?",
              list(patch.values()) + [existing["id"]])
    return True


def list_terms(status: str = "") -> list:
    t, w = _scope()
    q = "tenant_id=? AND workspace_id=?"
    args = [t, w]
    if status:
        q += " AND status=?"; args.append(status)
    c = db.connect()
    try:
        rows = c.execute(f"SELECT * FROM business_term WHERE {q} ORDER BY name", args).fetchall()
        return [_row(dict(r)) for r in rows]
    finally:
        c.close()


def create_term(name: str, definition: str, synonyms: list | None = None,
                not_equal: list | None = None, source: str = "", scope: str = "",
                key: str = "", actor: str = "", entity_type: str = "", unit: str = "",
                relations: list | None = None) -> dict:
    name = _text(name)
    definition = _text(definition)
    if len(name) < 2 or len(definition) < 4:
        return _fail("术语名称至少 2 字、定义至少 4 字", "invalid_term", 400)
    t, w = _scope()
    key = _text(key or name).upper().replace(" ", "-")
    syn = _clean_names(_as_list(synonyms))
    ne = _clean_names(_as_list(not_equal))
    rel = _dedupe_relations(_as_relations(relations or []))
    tid = db.new_id("term")
    c = db.connect()
    existing = None
    try:
        existing = c.execute(
            "SELECT * FROM business_term "
            "WHERE tenant_id=? AND workspace_id=? AND (term_key=? OR name=?) LIMIT 1",
            (t, w, key, name)).fetchone()
        if existing is not None:
            existing = dict(existing)
        else:
            c.execute("INSERT INTO business_term(id,tenant_id,workspace_id,term_key,name,definition,"
                      "synonyms_json,not_equal_json,source,scope,entity_type,unit,relations_json,"
                      "version,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,1,'draft',?)",
                      (tid, t, w, key, name, definition,
                       json.dumps(syn, ensure_ascii=False),
                       json.dumps(ne, ensure_ascii=False), source, scope,
                       entity_type or "", unit or "", json.dumps(rel, ensure_ascii=False), db.now()))
            c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return _fail(f"术语保存失败：{type(e).__name__}", "term_save_failed", 400)
    finally:
        c.close()
    if existing is not None:
        same = (
            _text(existing.get("term_key")) == key
            and _text(existing.get("name")) == name
            and _text(existing.get("definition")) == definition
            and _clean_names(_as_list(_load_json_list(existing.get("synonyms_json")))) == syn
            and _clean_names(_as_list(_load_json_list(existing.get("not_equal_json")))) == ne
            and _dedupe_relations(_as_relations(_load_json_list(existing.get("relations_json")))) == rel
            and _text(existing.get("source")) == _text(source)
            and _text(existing.get("scope")) == _text(scope)
            and _text(existing.get("entity_type")) == _text(entity_type)
            and _text(existing.get("unit")) == _text(unit)
        )
        if same:
            # 完全相同的 create 请求按幂等成功处理：不新增、不重复审计、ID 不变。
            return {"ok": True, "term_id": existing.get("id"), "key": key,
                    "status": _text(existing.get("status")) or "draft",
                    "created": False, "idempotent": True, "existing": True,
                    "action": "create"}
        _record_term_conflicts([{
            "kind": "term_key_conflict", "severity": "warning",
            "tenant_id": t, "workspace_id": w, "term_id": existing.get("id"),
            "name": name, "value": key,
            "existing_term_id": existing.get("id"),
            "existing_name": existing.get("name"),
            "existing_status": existing.get("status"),
            "detail": "同一空间已存在相同 term_key 或标准名但内容不同，未创建重复术语",
        }], actor=actor)
        return _fail(f"术语已存在：{existing.get('name')}", "term_exists", 409,
                     existing_term_id=existing.get("id"))
    try:
        R.audit_logs.log(actor=actor or "system", action="term.created", object=tid,
                         after=json.dumps({"name": name, "key": key}, ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)
    return {"ok": True, "term_id": tid, "key": key, "status": "draft",
            "created": True, "idempotent": False, "action": "create"}


def get_term(term_id: str) -> dict | None:
    """按 ID 读取当前租户/空间术语；不存在/跨空间返回 None（调用方可映射 404）。"""
    tid = _text(term_id)
    if not tid:
        return None
    c = db.connect()
    try:
        row = _term_in_scope(c, tid)
        return _row(row) if row else None
    finally:
        c.close()


def _audit_term(actor: str, action: str, term_id: str, before: dict | None = None,
                after: dict | None = None) -> None:
    try:
        R.audit_logs.log(
            actor=actor or "system", action=action, object=term_id,
            before=json.dumps(before, ensure_ascii=False) if before else "",
            after=json.dumps(after, ensure_ascii=False) if after else "")
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)


def confirm(term_id: str, actor: str = "") -> dict:
    """确认术语并同步本体投影；重复确认幂等，且不覆盖首次确认人/时间。"""
    tid = _text(term_id)
    if not tid:
        return _not_found()
    c = db.connect()
    try:
        row = _term_in_scope(c, tid)
        if not row:
            return _not_found(tid)
        term = _row(row)
        version = max(1, int(term.get("version") or 1))
        now = db.now()
        was_effective = _is_effective_status(term.get("status"))
        preserved = was_effective and bool(_text(term.get("confirmed_at")))
        if preserved:
            c.execute("UPDATE business_term SET status='confirmed' WHERE id=?", (tid,))
            conf_by = _text(term.get("confirmed_by"))
            conf_at = _text(term.get("confirmed_at"))
            changed = _status(term.get("status")) != "confirmed"
        else:
            conf_by = _text(term.get("confirmed_by")) or (actor or "")
            conf_at = _text(term.get("confirmed_at")) or now
            c.execute("UPDATE business_term SET status='confirmed',confirmed_by=?,confirmed_at=? "
                      "WHERE id=?", (conf_by, conf_at, tid))
            changed = True
        fresh = dict(row)
        fresh.update({"status": "confirmed", "confirmed_by": conf_by, "confirmed_at": conf_at})
        conflicts: list = []
        alias_sync = _sync_term_aliases(c, fresh, actor=actor, conflicts=conflicts)
        c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return _fail(f"确认术语失败：{type(e).__name__}: {e}", "term_confirm_failed", 400)
    finally:
        c.close()

    if conflicts:
        _record_term_conflicts(conflicts, actor=actor)
    if not (_text(fresh.get("entity_type")) or _text(fresh.get("unit"))
            or _load_json_list(fresh.get("relations_json"))
            or _clean_names(_as_list(_load_json_list(fresh.get("not_equal_json"))))):
        # 无可投影载荷时清掉该 term_id 的历史 settings 投影，避免旧 canonical 残留。
        _remove_workspace_projection(tid)
    proj = _project_ontology(tid, actor=actor) or {}
    ent = _project_onto_entity(tid, actor=actor)
    if ent:
        proj = dict(proj)
        proj["onto_entity"] = ent
    proj["alias_projection"] = alias_sync
    try:
        scan_term_conflicts(actor=actor)
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)
    if changed:
        # 重复确认（已 confirmed 且确认元数据齐全）不重复写审计。
        _audit_term(actor, "term.confirmed", tid, after={
            "status": "confirmed", "confirmed_by": conf_by, "confirmed_at": conf_at,
            "projection": proj,
        })
    return {"ok": True, "term_id": tid, "status": "confirmed", "version": version,
            "confirmed_by": conf_by, "confirmed_at": conf_at,
            "changed": changed, "confirmed": bool(changed),
            "idempotent": not changed,
            "aliases": alias_sync, "projection": proj,
            "conflicts": conflicts}


def _normalize_update_lists(body: dict, row: dict) -> tuple[dict, dict | None]:
    """把 update 请求归一成待更新列；返回 (updates, error)。"""
    updates: dict = {}
    text_fields = (("name", "name"), ("definition", "definition"), ("source", "source"),
                   ("scope", "scope"), ("entity_type", "entity_type"), ("unit", "unit"))
    for key, col in text_fields:
        if key not in body:
            continue
        val = _text(body.get(key))
        if key == "name" and len(val) < 2:
            return {}, _fail("术语名称至少 2 字", "invalid_term", 400)
        if key == "definition" and len(val) < 4:
            return {}, _fail("术语定义至少 4 字", "invalid_term", 400)
        if val != _text(row.get(col)):
            updates[col] = val
    if "key" in body or "term_key" in body:
        raw = body.get("key") if "key" in body else body.get("term_key")
        new_key = _text(raw).upper().replace(" ", "-")
        if not new_key:
            new_key = _term_key(updates.get("name") or row.get("name"))
        if new_key != _text(row.get("term_key")):
            updates["term_key"] = new_key
    for key, col in (("synonyms", "synonyms_json"), ("not_equal", "not_equal_json")):
        if key not in body:
            continue
        vals = _clean_names(_as_list(body.get(key)))
        old = _clean_names(_as_list(_load_json_list(row.get(col))))
        if vals != old:
            updates[col] = json.dumps(vals, ensure_ascii=False)
    if "relations" in body:
        vals = _dedupe_relations(_as_relations(body.get("relations") or []))
        old = _dedupe_relations(_as_relations(_load_json_list(row.get("relations_json"))))
        if vals != old:
            updates["relations_json"] = json.dumps(vals, ensure_ascii=False)
    if "status" in body:
        new_status = _status(body.get("status"), "")
        if new_status not in _TERM_STATUSES:
            return {}, _fail(f"非法术语状态：{body.get('status')}",
                             "invalid_term_status", 400)
        if new_status != _status(row.get("status")):
            updates["status"] = new_status
    return updates, None


def update_term(term_id: str, patch: dict | None = None, actor: str = "", **fields) -> dict:
    """更新术语并同步/反投影本体。

    支持部分字段更新；无实际变化时返回 ``changed=False`` 且幂等（不升版本、
    不重复写别名/实体）。显式改 ``status`` 才改变确认状态：改成已生效状态会
    重新确认并补投影，改成 draft/candidate/ignored 会反投影（删实体、别名 stale）。
    """
    body: dict = {}
    if isinstance(patch, dict):
        body.update(patch)
    elif patch is not None:
        return _fail("更新内容必须是对象", "invalid_update", 400)
    body.update(fields)
    tid = _text(term_id)
    if not tid:
        return _not_found()
    known = {"name", "definition", "source", "scope", "entity_type", "unit",
             "key", "term_key", "synonyms", "not_equal", "relations", "status"}
    body = {k: v for k, v in body.items() if k in known}
    c = db.connect()
    try:
        row = _term_in_scope(c, tid)
        if not row:
            # 不存在优先于参数校验：不泄漏“存在但没有字段”的差异。
            return _not_found(tid)
        if not body:
            return _fail("没有可更新的字段", "empty_update", 400)
        before = _row(row)
        updates, err = _normalize_update_lists(body, row)
        if err:
            return err
        old_status = _status(row.get("status"), "draft")
        new_status = _status(updates.get("status") or old_status, "draft")
        new_name = _text(updates.get("name") or row.get("name"))
        new_key = _text(updates.get("term_key") or row.get("term_key"))
        clash = None
        if new_name != _text(row.get("name")) or new_key != _text(row.get("term_key")):
            r = c.execute(
                "SELECT id,name,term_key,status FROM business_term "
                "WHERE tenant_id=? AND workspace_id=? AND id<>? AND (term_key=? OR name=?) "
                "ORDER BY CASE WHEN status='confirmed' THEN 0 ELSE 1 END, rowid LIMIT 1",
                (_text(row.get("tenant_id")), _text(row.get("workspace_id")), tid,
                 new_key, new_name)).fetchone()
            clash = dict(r) if r else None
        if clash is not None:
            c.rollback()
            _record_term_conflicts([{
                "kind": "term_key_conflict", "severity": "warning",
                "tenant_id": _text(row.get("tenant_id")),
                "workspace_id": _text(row.get("workspace_id")),
                "term_id": tid, "name": new_name, "value": new_key,
                "existing_term_id": clash.get("id"), "existing_name": clash.get("name"),
                "existing_status": clash.get("status"),
                "detail": "更新后的 term_key/标准名与同空间其他术语冲突，未写入",
            }], actor=actor)
            return _fail(f"术语 key/名称已被占用：{clash.get('name')}",
                         "term_exists", 409, existing_term_id=clash.get("id"))

        old_eff = _is_effective_status(old_status)
        new_eff = _is_effective_status(new_status)
        if "status" in updates and new_eff and not old_eff:
            updates["confirmed_by"] = actor or _text(row.get("confirmed_by")) or ""
            updates["confirmed_at"] = db.now()
        elif "status" in updates and old_eff and not new_eff:
            # 显式降级：旧确认随失效一并清除，但 before 快照进入审计日志。
            updates["confirmed_by"] = ""
            updates["confirmed_at"] = ""
        changed = bool(updates)
        conflicts: list = []
        alias_sync = None
        version = max(1, int(row.get("version") or 1))
        if changed:
            version += 1
            updates["version"] = version
            sets = ",".join(f"{k}=?" for k in updates)
            c.execute(f"UPDATE business_term SET {sets} WHERE id=?",
                      list(updates.values()) + [tid])
            fresh = dict(row)
            fresh.update(updates)
            if new_eff:
                alias_sync = _sync_term_aliases(c, fresh, actor=actor, conflicts=conflicts)
            c.commit()
        else:
            fresh = dict(row)
            c.rollback()
            if new_eff:
                # 无内容变化也做一次幂等自愈：补齐历史确认术语缺失的 onto_alias。
                alias_sync = _sync_term_aliases(c, fresh, actor=actor, conflicts=conflicts)
                c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return _fail(f"更新术语失败：{type(e).__name__}: {e}", "term_update_failed", 400)
    finally:
        c.close()

    projection = {}
    reverse = {}
    name_changed = bool(changed and "name" in updates)
    if new_eff:
        # 术语名/可投影载荷变化时先清掉旧的 settings 投影，避免留下旧 canonical。
        has_payload = bool(_text(fresh.get("entity_type")) or _text(fresh.get("unit"))
                           or _load_json_list(fresh.get("relations_json"))
                           or _clean_names(_as_list(_load_json_list(fresh.get("not_equal_json")))))
        if name_changed or not has_payload:
            _remove_workspace_projection(tid)
        projection = _project_ontology(tid, actor=actor) or {}
        ent = _project_onto_entity(tid, actor=actor)
        if ent:
            projection = dict(projection)
            projection["onto_entity"] = ent
        projection["alias_projection"] = alias_sync
    else:
        reverse = _reverse_project_term(fresh, "downgrade", actor=actor)
    if conflicts:
        _record_term_conflicts(conflicts, actor=actor)
    try:
        scan_term_conflicts(actor=actor)
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)
    if changed:
        _audit_term(actor, "term.updated", tid, before=before, after={
            "changed": changed, "updates": {k: updates[k] for k in updates if k != "version"},
            "version": version, "projection": projection, "reverse_projection": reverse,
        })
    return {"ok": True, "term_id": tid, "status": new_status, "version": version,
            "changed": changed, "updated": bool(changed), "idempotent": not changed,
            "previous_status": old_status,
            "aliases": alias_sync, "projection": projection,
            "reverse_projection": reverse, "conflicts": conflicts}


def downgrade_term(term_id: str, status: str = "draft", actor: str = "",
                   reason: str = "") -> dict:
    """显式降级：默认 draft；反投影实体/别名并写审计。"""
    st = _status(status, "draft")
    if st in EFFECTIVE_STATUSES:
        return _fail("降级目标必须是 draft/candidate/ignored，不能是已生效状态",
                     "invalid_downgrade_target", 400)
    if st not in _TERM_STATUSES:
        return _fail(f"非法术语状态：{status}", "invalid_term_status", 400)
    res = update_term(term_id, {"status": st}, actor=actor)
    if res.get("ok"):
        res["downgraded"] = bool(res.get("changed"))
        res["reason"] = reason or ("已降级并反向清理本体投影"
                                   if res["downgraded"] else "术语已是目标状态，无需重复降级")
    return res


def set_term_status(term_id: str, status: str, actor: str = "") -> dict:
    """状态入口：生效状态走 confirm，非生效状态走 downgrade。"""
    st = _status(status, "")
    if st in EFFECTIVE_STATUSES:
        return confirm(term_id, actor=actor)
    if st not in _TERM_STATUSES:
        return _fail(f"非法术语状态：{status}", "invalid_term_status", 400)
    return downgrade_term(term_id, st, actor=actor)


def delete_term(term_id: str, actor: str = "", reason: str = "") -> dict:
    """删除术语并反向清理 onto_alias/onto_entity/settings 投影，不留孤儿。"""
    tid = _text(term_id)
    if not tid:
        return _not_found()
    c = db.connect()
    try:
        row = _term_in_scope(c, tid)
        if not row:
            return _not_found(tid)
        before = _row(row)
        before["aliases"] = [dict(x) for x in c.execute(
            "SELECT id,alias,entity_id,status,source FROM onto_alias WHERE entity_id=?",
            (tid,)).fetchall()]
        reverse = _reverse_onto_tables(c, row, "delete", actor=actor)
        c.execute("DELETE FROM business_term WHERE id=? AND tenant_id=? AND workspace_id=?",
                  (tid, _text(row.get("tenant_id")), _text(row.get("workspace_id"))))
        c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return _fail(f"删除术语失败：{type(e).__name__}: {e}", "term_delete_failed", 400)
    finally:
        c.close()
    removed_ws = _remove_workspace_projection(tid)
    reverse["workspace_terms_removed"] = removed_ws
    if reverse.get("conflicts"):
        _record_term_conflicts(reverse["conflicts"], actor=actor)
    try:
        scan_term_conflicts(actor=actor)
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)
    _audit_term(actor, "term.deleted", tid, before=before, after={
        "deleted": True, "reason": reason or "", "reverse_projection": reverse,
    })
    return {"ok": True, "term_id": tid, "deleted": True,
            "reverse_projection": reverse, "reason": reason or "已删除并反向清理本体投影"}


def _is_effective_status(status) -> bool:
    return _text(status).lower() in EFFECTIVE_STATUSES


def _effective_terms() -> list:
    """当前租户/空间内已生效术语（人工 confirmed + 旧迁移 active）。"""
    return [x for x in list_terms() if _is_effective_status(x.get("status"))]


def resolve(text: str) -> dict | None:
    """按标准名/同义词匹配已生效术语；draft/candidate 不当作正式定义。

    not_equal 中的词不得被归一为该术语：即使它同时出现在同义词里也不解析，
    避免“不等同”声明被别名链静默覆盖。
    """
    text = (text or "").strip()
    if not text:
        return None
    tn = _name(text)
    terms = _effective_terms()
    for x in terms:
        if _name(x.get("name")) == tn:
            return x
        forbidden = {_name(v) for v in (x.get("not_equal") or [])}
        if tn in forbidden:
            continue
        for a in x.get("synonyms") or []:
            if _name(a) == tn:
                return x
    return None


def effective_alias_pairs() -> dict:
    """已生效术语的同义词 → 标准名；not_equal 词对、重复归属不归一。"""
    terms = _effective_terms()
    by_name = {_name(t.get("name")): t for t in terms if _name(t.get("name"))}
    declared = {t.get("id"): {_name(v) for v in (t.get("not_equal") or [])} for t in terms}
    owner_count = {}
    for t in terms:
        for a in t.get("synonyms") or []:
            an = _name(a)
            if an:
                owner_count[an] = owner_count.get(an, 0) + 1
    out = {}
    for t in terms:
        name = _text(t.get("name"))
        if not name:
            continue
        tid = t.get("id")
        forbidden = set(declared.get(tid) or set())
        for a in t.get("synonyms") or []:
            an = _name(a)
            if not an or an == _name(name):
                continue
            # 1) 自身 not_equal：不等同词对不能归一
            if an in forbidden:
                continue
            # 2) 该别名恰好是另一个已生效术语的标准名，而两边声明了不等同
            other = by_name.get(an)
            if other and other.get("id") != tid:
                if _name(name) in (declared.get(other.get("id")) or set()) or \
                        an in forbidden:
                    continue
            # 3) 同一别名被多个已生效术语声明：冲突不归一（避免静默择一）
            if owner_count.get(an, 0) > 1:
                continue
            out[_text(a)] = name
    return out


def confirmed_alias_pairs() -> dict:
    """保留旧函数名；“已确认”与历史迁移的 active 均视为已生效。

    供工作空间本体/规则执行归一使用；not_equal 词对不会进入归一映射。
    """
    return effective_alias_pairs()


def _project_ontology(term_id: str, actor: str = "") -> dict:
    """把有类型/单位/关系的 confirmed 术语投影到当前空间 ontology_terms。"""
    term = next((x for x in list_terms() if x.get("id") == term_id), None)
    if not term:
        return {}
    rels = list(term.get("relations") or [])
    for x in term.get("not_equal") or []:
        rels.append({"type": "不等同", "to": x})
    if not (term.get("entity_type") or term.get("unit") or rels):
        return {}
    from . import ontology_service as _ontology
    tid, wid = _scope()
    if not wid:
        return {}
    st = _ontology.workspace_settings(wid)
    terms = _ontology.workspace_terms(st)
    hit = next((x for x in terms if x.get("canonical") == term.get("name")), None)
    payload = {"canonical": term.get("name"), "aliases": term.get("synonyms") or [],
               "type": term.get("entity_type") or "", "unit": term.get("unit") or "",
               "relations": rels, "term_id": term_id, "source": "business_term",
               "status": "active", "evidence": (term.get("definition") or "")[:500],
               "updated_at": db.now()}
    if hit:
        hit.update(payload)
    else:
        payload.update({"id": db.new_id("ot"), "count": 0, "created_at": db.now()})
        terms.append(payload)
    _ontology.save_workspace_settings(wid, {"ontology_terms": terms})
    try:
        R.audit_logs.log(actor=actor or "system", action="ontology.term_projected", object=term_id,
                         after=str(term.get("name") or ""))
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)
    return {"canonical": term.get("name"), "aliases": term.get("synonyms") or [],
            "type": term.get("entity_type") or "", "unit": term.get("unit") or "",
            "relations": rels}


# ---------------------------------------------------------------- onto_entity 投影

_ENTITY_PROJECTION_SOURCE = "business_term"


def _entity_type_key(workspace_id: str) -> str:
    """与迁移别名保持同一命名空间，保证实例与别名同类型、跨空间同名实体隔离。"""
    return _LEGACY_ALIAS_TYPE_PREFIX + (workspace_id or "default")


def _entity_props(row: dict) -> dict:
    """安全解析 onto_entity.props_json；损坏/空值一律返回 {}。"""
    raw = (row or {}).get("props_json")
    if isinstance(raw, dict):
        return dict(raw)
    if not isinstance(raw, str) or not raw.strip():
        return {}
    try:
        obj = json.loads(raw)
    except Exception:
        return {}
    return obj if isinstance(obj, dict) else {}


def _is_projected_entity(row: dict, term_id: str = "") -> bool:
    """是否为词典投影出的实体（区别于人工维护/人工确认的本体实体）。"""
    p = _entity_props(row)
    src = _text(p.get("projection_source") or p.get("source")).lower()
    if src != _ENTITY_PROJECTION_SOURCE:
        return False
    tid = _text(p.get("term_id"))
    if term_id:
        # 早期投影可能没有 term_id；主键等于术语 ID 时仍视为同一投影。
        return tid == _text(term_id) or (not tid and _text((row or {}).get("id")) == _text(term_id))
    return bool(tid) or _text(p.get("projection_source")) == _ENTITY_PROJECTION_SOURCE


def _entity_kind(row: dict) -> str:
    """projected / confirmed / manual：只有 projected 允许幂等更新。"""
    if _is_projected_entity(row):
        return "projected"
    status = _text(_entity_props(row).get("status")).lower()
    if status in ("confirmed", "active", "approved"):
        return "confirmed"
    return "manual"


def _entity_payload(term: dict) -> dict:
    """术语 → onto_entity.props 的稳定载荷（不含投影时间，便于幂等比较）。"""
    etype = _text(term.get("entity_type"))
    try:
        version = max(1, int(term.get("version") or 1))
    except Exception:
        version = 1
    return {
        "term_id": _text(term.get("id") or term.get("term_id")),
        "term_key": _text(term.get("term_key")),
        "type": etype,
        "entity_type": etype,
        "unit": _text(term.get("unit")),
        "scope": _text(term.get("scope")),
        "relations": _as_relations(term.get("relations_json") or term.get("relations")),
        "not_equal": _clean_names(_as_list(
            term.get("not_equal_json") or term.get("not_equal"))),
        "tenant_id": _text(term.get("tenant_id")),
        "workspace_id": _text(term.get("workspace_id")),
        "source": _ENTITY_PROJECTION_SOURCE,
        "term_source": _text(term.get("source")),
        "status": "confirmed",
        "term_status": _text(term.get("status")),
        "projection_source": _ENTITY_PROJECTION_SOURCE,
        "definition": _text(term.get("definition")),
        "aliases": _clean_names(_as_list(
            term.get("synonyms_json") or term.get("synonyms"))),
        "version": version,
        "confirmed_by": _text(term.get("confirmed_by")),
        "confirmed_at": _text(term.get("confirmed_at")),
        "term_created_at": _text(term.get("created_at")),
    }


def _entity_json(props: dict) -> str:
    return json.dumps(props, ensure_ascii=False, sort_keys=True)


def _projection_terms(c, tenant_id: str, workspace_id: str, statuses: tuple) -> list:
    placeholders = ",".join("?" for _ in statuses)
    sql = f"SELECT * FROM business_term WHERE LOWER(status) IN ({placeholders})"
    args = [x.lower() for x in statuses]
    if tenant_id:
        sql += " AND tenant_id=?"
        args.append(tenant_id)
    if workspace_id:
        sql += " AND workspace_id=?"
        args.append(workspace_id)
    sql += " ORDER BY tenant_id,workspace_id,name,id"
    return [dict(r) for r in c.execute(sql, args).fetchall()]


def _project_terms(c, terms: list, actor: str = "", dry_run: bool = False) -> dict:
    """在已打开事务内执行投影；不 commit/rollback，由调用方控制事务边界。"""
    res = {
        "ok": True, "source": _ENTITY_PROJECTION_SOURCE, "target": "onto_entity",
        "dry_run": bool(dry_run), "scanned_terms": len(terms),
        "created": 0, "updated": 0, "existing": 0,
        "created_entities": 0, "updated_entities": 0, "existing_entities": 0,
        "skipped_manual": 0, "skipped_confirmed": 0, "skipped_conflict": 0,
        "invalid_terms": 0, "conflicts": [], "warnings": [], "projected": [],
        "reason": "", "idempotent": False,
    }
    rows = [dict(r) for r in c.execute("SELECT * FROM onto_entity").fetchall()]
    by_id, by_name = {}, {}
    for row in rows:
        by_id[_text(row.get("id"))] = row
        nm = _name(row.get("name"))
        if nm:
            by_name.setdefault(nm, []).append(row)

    def _add_conflict(kind: str, conflict_type: str, term: dict, row: dict, detail: str):
        props = _entity_props(row)
        res["conflicts"].append({
            "kind": kind, "conflict_type": conflict_type, "severity": "warning",
            "tenant_id": _text(term.get("tenant_id")),
            "workspace_id": _text(term.get("workspace_id")),
            "term_id": _text(term.get("id")),
            "name": _text(term.get("name")),
            "existing_entity_id": _text(row.get("id")),
            "existing_type_key": _text(row.get("type_key")),
            "existing_name": _text(row.get("name")),
            "existing_source": _text(props.get("source") or props.get("projection_source")),
            "existing_status": _text(props.get("status")),
            "existing_tenant_id": _text(props.get("tenant_id")),
            "existing_workspace_id": _text(props.get("workspace_id")),
            "detail": detail,
        })

    for raw in terms:
        term = _row(dict(raw))
        term_id = _text(term.get("id"))
        name = _text(term.get("name"))
        tenant_id = _text(term.get("tenant_id"))
        workspace_id = _text(term.get("workspace_id"))
        if not term_id or not name:
            res["invalid_terms"] += 1
            res["warnings"].append({
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": term_id, "name": name,
                "warning": "invalid_term",
                "detail": "术语缺少 id 或名称，未投影",
            })
            continue

        payload = _entity_payload(term)
        props_json = _entity_json(payload)
        type_key = _entity_type_key(workspace_id)

        blocked = None
        existing = by_id.get(term_id)
        if existing is not None and not _is_projected_entity(existing, term_id):
            blocked = ("entity_id_conflict", "id", existing,
                       "onto_entity 主键与术语 ID 相同但并非该术语的投影，未覆盖")
        if not blocked:
            for row in by_name.get(_name(name), []):
                if _text(row.get("id")) == term_id:
                    continue
                kind = _entity_kind(row)
                if kind == "projected":
                    ep = _entity_props(row)
                    same_scope = (_text(ep.get("tenant_id")) == tenant_id and
                                  _text(ep.get("workspace_id")) == workspace_id)
                    if same_scope:
                        blocked = ("business_term_entity_conflict", "duplicate_term", row,
                                   "同一空间已存在同名投影实体（属于其他术语），未覆盖")
                        break
                    # 其他空间的同名投影实体允许并存，保证跨空间隔离。
                    continue
                if kind == "confirmed":
                    blocked = ("confirmed_entity_conflict", "confirmed", row,
                               "同名本体实体已确认，投影不覆盖人工/已确认实体")
                else:
                    blocked = ("manual_entity_conflict", "manual", row,
                               "同名本体实体为人工维护，投影不覆盖并记录冲突")
                break
        if blocked:
            kind, ctype, row, detail = blocked
            if kind == "manual_entity_conflict":
                res["skipped_manual"] += 1
            elif kind == "confirmed_entity_conflict":
                res["skipped_confirmed"] += 1
            else:
                res["skipped_conflict"] += 1
            _add_conflict(kind, ctype, term, row, detail)
            continue

        if existing is not None:
            old_name = _text(existing.get("name"))
            if (_text(existing.get("type_key")) == type_key and
                    old_name == name and _entity_props(existing) == payload):
                res["existing"] += 1
                action = "existing"
            else:
                if not dry_run:
                    c.execute("UPDATE onto_entity SET type_key=?,name=?,props_json=? WHERE id=?",
                              (type_key, name, props_json, term_id))
                existing.update({"type_key": type_key, "name": name,
                                 "props_json": props_json})
                if _name(old_name) != _name(name):
                    old_rows = by_name.get(_name(old_name)) or []
                    if existing in old_rows:
                        old_rows.remove(existing)
                    by_name.setdefault(_name(name), []).append(existing)
                res["updated"] += 1
                action = "updated"
        else:
            created_at = db.now()
            if not dry_run:
                try:
                    c.execute("INSERT INTO onto_entity(id,type_key,name,props_json,created_at) "
                              "VALUES(?,?,?,?,?)",
                              (term_id, type_key, name, props_json, created_at))
                except Exception as e:
                    if "no column" not in str(e).lower():
                        raise
                    c.execute("INSERT INTO onto_entity(id,type_key,name,props_json) VALUES(?,?,?,?)",
                              (term_id, type_key, name, props_json))
            existing = {"id": term_id, "type_key": type_key, "name": name,
                        "props_json": props_json, "created_at": created_at}
            by_id[term_id] = existing
            by_name.setdefault(_name(name), []).append(existing)
            res["created"] += 1
            action = "created"

        res["projected"].append({
            "term_id": term_id, "entity_id": term_id, "name": name,
            "type": _text(term.get("entity_type")), "type_key": type_key,
            "tenant_id": tenant_id, "workspace_id": workspace_id,
            "action": action,
        })

    res["created_entities"] = res["created"]
    res["updated_entities"] = res["updated"]
    res["existing_entities"] = res["existing"]
    res["idempotent"] = bool(res["created"] == 0 and res["updated"] == 0)
    if res["created"] or res["updated"]:
        res["reason"] = (f"业务词典 confirmed 术语已投影到 onto_entity：新增 {res['created']}、"
                         f"更新 {res['updated']}、已存在 {res['existing']}")
    elif res["existing"]:
        res["reason"] = ("onto_entity 已包含全部 confirmed 业务术语，本次未新增（幂等）："
                         f"已存在 {res['existing']} 条")
    else:
        res["reason"] = "没有可投影的业务术语"
    if res["conflicts"]:
        res["reason"] += f"；{len(res['conflicts'])} 条冲突未覆盖"
    return res


def project_confirmed_terms_to_onto_entity(tenant_id: str = "", workspace_id: str = "",
                                           actor: str = "", dry_run: bool = False,
                                           all_spaces: bool = False,
                                           statuses: tuple | list | None = None) -> dict:
    """把 confirmed 业务术语幂等投影到 ``onto_entity``，不改写人工/已确认实体。

    参数与旧迁移保持一致：省略租户/空间时取当前上下文；``all_spaces=True``
    表示本租户全部空间（未给租户时为全部）。默认只投影 ``confirmed``；
    旧迁移数据若需保留 ``active``（历史语义同样是“已生效”），显式传
    ``statuses=EFFECTIVE_STATUSES``。draft/candidate 不投影。

    每个术语使用 ``term_id`` 作为实体主键、``BusinessTerm:<workspace_id>`` 作为
    type_key，与迁移别名命名空间一致；业务类型、单位、关系、租户、空间、来源写进
    ``props_json``（onto_entity 只有 5 个固定列，不新增 schema）。

    没有可投影术语时返回 ``ok=False`` + ``code=confirmed_terms_missing``，
    不写库；同名人工实体/已确认实体只记录冲突并跳过，不覆盖。
    """
    if not all_spaces and not tenant_id and not workspace_id:
        tenant_id, workspace_id = _scope()
    statuses = tuple(_text(x).lower() for x in (statuses or ("confirmed",))
                     if _text(x)) or ("confirmed",)
    base = {
        "ok": False, "source": _ENTITY_PROJECTION_SOURCE, "target": "onto_entity",
        "dry_run": bool(dry_run), "tenant_id": tenant_id, "workspace_id": workspace_id,
        "all_spaces": bool(all_spaces), "statuses": list(statuses),
        "scanned_terms": 0, "confirmed_terms": 0, "created": 0, "updated": 0,
        "existing": 0, "created_entities": 0, "updated_entities": 0,
        "existing_entities": 0, "skipped_manual": 0, "skipped_confirmed": 0,
        "skipped_conflict": 0, "invalid_terms": 0, "conflicts": [], "warnings": [],
        "projected": [], "reason": "", "code": "", "idempotent": False,
    }
    c = db.connect()
    try:
        rows = _projection_terms(c, tenant_id, workspace_id, statuses)
        base["scanned_terms"] = len(rows)
        base["confirmed_terms"] = len(rows)
        if not rows:
            c.rollback()
            if workspace_id:
                reason = (f"工作空间 {workspace_id} 没有 confirmed 业务术语："
                          "没有可投影数据，未写入任何内容")
            elif tenant_id:
                reason = (f"租户 {tenant_id} 没有 confirmed 业务术语："
                          "没有可投影数据，未写入任何内容")
            else:
                reason = ("未发现 confirmed 业务术语：没有可投影数据，"
                          "未写入任何内容")
            base.update({"ok": False, "code": "confirmed_terms_missing", "reason": reason})
            return base
        body = _project_terms(c, rows, actor=actor, dry_run=dry_run)
        base.update(body)
        if dry_run:
            c.rollback()
            base["reason"] = "投影预演（dry_run）：" + base["reason"] + "；事务已回滚，未写入"
        else:
            c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return {**base, "ok": False, "code": "projection_failed",
                "reason": f"onto_entity 投影失败：{type(e).__name__}: {e}"}
    finally:
        c.close()

    if not dry_run:
        if base.get("conflicts"):
            try:
                _record_term_conflicts(base["conflicts"], actor=actor)
            except Exception:
                logging.getLogger(__name__).debug("ignored", exc_info=True)
        try:
            R.audit_logs.log(
                actor=actor or "system", action="term.onto_entity_projected",
                object=workspace_id or "*",
                after=json.dumps({k: base.get(k) for k in (
                    "scanned_terms", "created", "updated", "existing",
                    "skipped_manual", "skipped_confirmed", "skipped_conflict")},
                    ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
    return base


def _project_onto_entity(term_id: str, actor: str = "") -> dict:
    """确认单个术语时立即投影；返回投影结果/冲突，失败不阻断确认。"""
    tid = _text(term_id)
    if not tid:
        return {}
    c = db.connect()
    try:
        row = c.execute("SELECT * FROM business_term WHERE id=?", (tid,)).fetchone()
        if not row:
            return {}
        term = dict(row)
        if not _is_effective_status(term.get("status")):
            return {}
        body = _project_terms(c, [term], actor=actor)
        if body.get("ok"):
            # 投影被冲突阻断时，旧的词典投影不能继续以“当前术语”身份留在本体里；
            # 只删除仍带投影标记的实体（人工/已确认实体不在删除范围）。
            if not body.get("projected") and body.get("conflicts"):
                _delete_projected_entities_in_c(c, tid, _text(term.get("tenant_id")),
                                               _text(term.get("workspace_id")))
            c.commit()
        else:
            c.rollback()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return {"ok": False, "entity_id": "", "action": "failed",
                "code": "projection_failed",
                "reason": f"onto_entity 投影失败：{type(e).__name__}: {e}"}
    finally:
        c.close()
    conflicts = body.get("conflicts") or []
    conflict_ids = []
    if conflicts:
        rec = _record_term_conflicts(conflicts, actor=actor)
        conflict_ids = rec.get("ids") or []
    item = (body.get("projected") or [None])[0]
    return {
        "ok": bool(body.get("ok")),
        "entity_id": (item or {}).get("entity_id") or "",
        "type_key": (item or {}).get("type_key") or _entity_type_key(
            _text(term.get("workspace_id"))),
        "action": (item or {}).get("action") or ("conflict" if conflicts else ""),
        "conflicts": conflicts,
        "conflict_ids": conflict_ids,
        "reason": body.get("reason") or "",
        "idempotent": bool(body.get("idempotent")),
    }


# ---------------------------------------------------------------- 反投影

def _remove_workspace_projection(term_id: str) -> int:
    """移除 workspace.settings_json.ontology_terms 中该术语的投影项。

    只删带 ``term_id`` 的项（人工维护/其他来源的条目不动），返回删除数量。
    """
    tid = _text(term_id)
    _, wid = _scope()
    if not tid or not wid:
        return 0
    try:
        from . import ontology_service as _ontology
        st = _ontology.workspace_settings(wid)
        terms = _ontology.workspace_terms(st)
        kept = [x for x in terms if _text(x.get("term_id")) != tid]
        if len(kept) == len(terms):
            return 0
        _ontology.save_workspace_settings(wid, {"ontology_terms": kept})
        return len(terms) - len(kept)
    except Exception:
        return 0


def _delete_projected_entities_in_c(c, term_id: str, tenant_id: str = "",
                                    workspace_id: str = "") -> list:
    """删除当前术语投影出的 onto_entity；人工/已确认实体即使同主键也不删。"""
    tid = _text(term_id)
    deleted = []
    if not tid:
        return deleted
    rows = c.execute("SELECT id,type_key,name,props_json,created_at FROM onto_entity").fetchall()
    for raw in rows:
        row = dict(raw)
        if not _is_projected_entity(row, tid):
            continue
        props = _entity_props(row)
        p_tid = _text(props.get("term_id")) or _text(row.get("id"))
        if p_tid != tid:
            continue
        if tenant_id and _text(props.get("tenant_id")) not in ("", tenant_id):
            continue
        if workspace_id and _text(props.get("workspace_id")) not in ("", workspace_id):
            continue
        c.execute("DELETE FROM onto_entity WHERE id=?", (row.get("id"),))
        deleted.append(_text(row.get("id")))
    return deleted


def _reverse_onto_tables(c, term: dict, mode: str, actor: str = "") -> dict:
    """在已打开事务内反投影：实体删除；别名按 mode 删除或落 stale。

    - mode=delete：删除该实体名下的全部别名；
    - mode=downgrade：别名保留为 stale 墓碑（清 evidence，运行时本体不再载入）；
    - 非词典投影的人工/已确认实体不删除，只记录 skipped 冲突。
    """
    tid = _text(term.get("id") or term.get("term_id"))
    tenant_id = _text(term.get("tenant_id"))
    workspace_id = _text(term.get("workspace_id"))
    out = {"mode": mode, "entities_deleted": [], "entity_skipped": [],
           "aliases_deleted": 0, "aliases_staled": 0, "conflicts": []}
    if not tid:
        return out
    entities = {_text(r["id"]): dict(r) for r in c.execute(
        "SELECT id,type_key,name,props_json,created_at FROM onto_entity").fetchall()}
    deleted_ids = _delete_projected_entities_in_c(c, tid, tenant_id, workspace_id)
    out["entities_deleted"] = deleted_ids
    for eid, row in entities.items():
        if eid in deleted_ids:
            continue
        props = _entity_props(row)
        p_tid = _text(props.get("term_id")) or eid
        if p_tid != tid and eid != tid:
            continue
        # 主键等于术语 ID、但不是词典投影：属于人工实体，删除术语时保留并报告。
        if eid == tid or p_tid == tid:
            out["entity_skipped"].append({
                "entity_id": eid, "name": _text(row.get("name")),
                "entity_kind": _entity_kind(row),
            })
            out["conflicts"].append({
                "kind": "reverse_entity_skipped", "severity": "warning",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": tid, "name": _text(term.get("name")),
                "existing_entity_id": eid, "existing_type_key": _text(row.get("type_key")),
                "existing_name": _text(row.get("name")),
                "existing_status": _text(props.get("status")),
                "detail": "实体不是词典投影（人工/已确认），删除术语时保留，不做反向删除",
            })
    alias_rows = [dict(r) for r in c.execute(
        "SELECT id,type_key,alias,entity_id,evidence,source,status,created_at "
        "FROM onto_alias WHERE entity_id=?", (tid,)).fetchall()]
    for row in alias_rows:
        if mode == "delete":
            c.execute("DELETE FROM onto_alias WHERE id=?", (row.get("id"),))
            out["aliases_deleted"] += 1
        else:
            if _mark_alias_stale(c, row):
                out["aliases_staled"] += 1
    return out


def _reverse_project_term(term: dict, mode: str = "downgrade", actor: str = "") -> dict:
    """反投影入口（独立事务）：删除或标记 stale 本体投影，并清理 settings。"""
    tid = _text(term.get("id") or term.get("term_id"))
    if not tid:
        return {}
    c = db.connect()
    try:
        out = _reverse_onto_tables(c, term, mode, actor=actor)
        c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return {"ok": False, "code": "reverse_projection_failed",
                "error": f"反投影失败：{type(e).__name__}: {e}"}
    finally:
        c.close()
    out["workspace_terms_removed"] = _remove_workspace_projection(tid)
    out["ok"] = True
    out["changed"] = bool(
        out.get("entities_deleted") or out.get("entity_skipped")
        or out.get("aliases_deleted") or out.get("aliases_staled")
        or out.get("workspace_terms_removed") or out.get("conflicts"))
    if out.get("conflicts"):
        _record_term_conflicts(out["conflicts"], actor=actor)
    if out["changed"]:
        action = "term.downgraded" if mode == "downgrade" else "term.projection_reversed"
        _audit_term(actor, action, tid, after=out)
    return out


# 兼容不同调用方命名；实现只有一份。
project_confirmed_terms = project_confirmed_terms_to_onto_entity
project_business_terms_to_onto_entity = project_confirmed_terms_to_onto_entity
project_terms_to_onto_entity = project_confirmed_terms_to_onto_entity
project_onto_entities = project_confirmed_terms_to_onto_entity


# ---------------------------------------------------------------- 旧数据迁移

def migrate_legacy_ontology_terms(tenant_id: str = "", workspace_id: str = "",
                                  actor: str = "", dry_run: bool = False,
                                  all_spaces: bool = False) -> dict:
    """把旧 ``workspace.settings_json.ontology_terms`` 幂等迁到词典/别名表。

    - 来源/状态/租户/空间原样保留；旧 ``active`` 仍表示“已生效”；
    - 已确认（confirmed）术语一律不覆盖，连同其别名也不改写；
    - 既有非 confirmed 术语只补空/并集，不覆盖已有内容；
    - not_equal 同时兼容旧 item 字段和 relations 里的“不等同”；
    - 没有任何旧数据时返回 ``ok=False`` + ``code=legacy_data_missing``，
      不写库、不伪造“迁移成功”。
    """
    if not all_spaces and not tenant_id and not workspace_id:
        tenant_id, workspace_id = _scope()
    res = {
        "ok": False, "source": "workspace.settings_json.ontology_terms",
        "dry_run": bool(dry_run), "tenant_id": tenant_id, "workspace_id": workspace_id,
        "scanned_workspaces": 0, "workspaces_with_legacy": 0,
        "legacy_terms": 0, "valid_terms": 0,
        "created_terms": 0, "existing_terms": 0, "updated_terms": 0,
        "skipped_confirmed": 0, "skipped_key_conflict": 0,
        "created_aliases": 0, "existing_aliases": 0,
        "not_equal_terms": 0, "conflicts": [], "warnings": [], "invalid": [],
        "kept_confirmed": [], "workspaces": [], "reason": "",
    }
    c = db.connect()
    try:
        workspaces = _legacy_workspaces(tenant_id, workspace_id)
        if workspace_id and not workspaces:
            return {**res, "code": "workspace_missing",
                    "reason": f"工作空间不存在：{workspace_id}"}
        res["scanned_workspaces"] = len(workspaces)
        alias_index = _alias_owner_index(c)
        legacy_total = 0
        valid_total = 0

        for ws in workspaces:
            settings = _settings_dict(ws.get("settings_json"))
            items = _legacy_terms_in_settings(settings)
            if not items:
                continue
            res["workspaces_with_legacy"] += 1
            legacy_total += len(items)
            ws_sum = {"tenant_id": ws.get("tenant_id") or "", "workspace_id": ws.get("id") or "",
                      "name": ws.get("name") or "", "legacy_terms": len(items),
                      "valid_terms": 0, "created_terms": 0, "existing_terms": 0,
                      "updated_terms": 0, "skipped_confirmed": 0,
                      "skipped_key_conflict": 0,
                      "created_aliases": 0, "existing_aliases": 0, "invalid_terms": 0}
            for item in items:
                canonical = _text(item.get("canonical") or item.get("name"))
                legacy_id = _text(item.get("id") or item.get("term_id"))
                if len(canonical) < 2:
                    res["invalid"].append({
                        "tenant_id": ws.get("tenant_id") or "",
                        "workspace_id": ws.get("id") or "",
                        "legacy_id": legacy_id, "name": canonical,
                        "reason": "canonical 缺失或少于 2 字",
                    })
                    ws_sum["invalid_terms"] += 1
                    continue
                valid_total += 1
                ws_sum["valid_terms"] += 1

                aliases = _legacy_item_aliases(item)
                not_equal = _legacy_item_not_equal(item)
                relations = _legacy_item_relations(item)
                source = _text(item.get("source")) or "legacy:ontology_terms"
                status = _text(item.get("status")) or "draft"
                definition = _text(item.get("definition") or item.get("evidence"))
                scope = _text(item.get("scope"))
                entity_type = _text(item.get("type") or item.get("entity_type"))
                unit = _text(item.get("unit"))
                key = _term_key(item.get("term_key") or item.get("key") or canonical)
                created_at = _text(item.get("created_at")) or db.now()
                alias_created_at = (_text(item.get("updated_at")) or created_at)
                evidence = _text(item.get("evidence")) or definition
                if not definition:
                    res["warnings"].append({
                        "tenant_id": ws.get("tenant_id") or "",
                        "workspace_id": ws.get("id") or "",
                        "legacy_id": legacy_id, "name": canonical,
                        "warning": "missing_definition",
                        "detail": "旧数据没有 definition/evidence；已保留空定义，等待业务补充，未伪造定义",
                    })
                if not_equal:
                    res["not_equal_terms"] += 1

                existing = _find_existing_term(c, ws.get("tenant_id") or "",
                                               ws.get("id") or "", key, canonical)
                if existing:
                    ename = _text(existing.get("name"))
                    if _name(ename) != _name(canonical):
                        # key 命中但名称不同：说明是两个概念撞了 key，只报告，不合并。
                        res["conflicts"].append({
                            "kind": "term_key_conflict", "severity": "warning",
                            "tenant_id": ws.get("tenant_id") or "",
                            "workspace_id": ws.get("id") or "",
                            "term_id": existing.get("id"), "legacy_id": legacy_id,
                            "existing_name": ename, "legacy_name": canonical,
                            "detail": "term_key 已被同一空间内其他术语占用，未覆盖、未合并",
                        })
                        res["skipped_key_conflict"] += 1
                        ws_sum["skipped_key_conflict"] += 1
                        continue
                    if _text(existing.get("status")).lower() == "confirmed":
                        res["skipped_confirmed"] += 1
                        ws_sum["skipped_confirmed"] += 1
                        res["kept_confirmed"].append({
                            "tenant_id": ws.get("tenant_id") or "",
                            "workspace_id": ws.get("id") or "",
                            "term_id": existing.get("id"), "legacy_id": legacy_id,
                            "name": ename, "status": "confirmed",
                        })
                        # 已确认术语及其别名一律不动。
                        continue

                    res["existing_terms"] += 1
                    ws_sum["existing_terms"] += 1
                    if _merge_existing_term(c, existing, aliases, not_equal, relations,
                                            definition, source, scope, entity_type, unit):
                        res["updated_terms"] += 1
                        ws_sum["updated_terms"] += 1
                    for a in aliases:
                        ca, ea = _ensure_alias(c, alias_index, ws.get("tenant_id") or "",
                                               ws.get("id") or "", existing.get("id"), a,
                                               evidence, source, status, alias_created_at,
                                               res["conflicts"])
                        res["created_aliases"] += ca
                        ws_sum["created_aliases"] += ca
                        res["existing_aliases"] += ea
                        ws_sum["existing_aliases"] += ea
                    continue

                tid = db.new_id("term")
                confirmed_by = _text(item.get("confirmed_by"))
                confirmed_at = _text(item.get("confirmed_at"))
                if status.lower() == "confirmed":
                    confirmed_by = confirmed_by or actor or "legacy-migration"
                    confirmed_at = (confirmed_at or _text(item.get("updated_at"))
                                    or created_at or db.now())
                try:
                    version = max(1, int(item.get("version") or 1))
                except Exception:
                    version = 1
                c.execute(
                    "INSERT INTO business_term(id,tenant_id,workspace_id,term_key,name,definition,"
                    "synonyms_json,not_equal_json,source,scope,entity_type,unit,relations_json,"
                    "version,status,confirmed_by,confirmed_at,created_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (tid, ws.get("tenant_id") or "", ws.get("id") or "", key, canonical,
                     definition, json.dumps(aliases, ensure_ascii=False),
                     json.dumps(not_equal, ensure_ascii=False), source, scope,
                     entity_type, unit, json.dumps(relations, ensure_ascii=False),
                     version, status, confirmed_by, confirmed_at, created_at))
                res["created_terms"] += 1
                ws_sum["created_terms"] += 1
                for a in aliases:
                    ca, ea = _ensure_alias(c, alias_index, ws.get("tenant_id") or "",
                                           ws.get("id") or "", tid, a, evidence, source,
                                           status, alias_created_at, res["conflicts"])
                    res["created_aliases"] += ca
                    ws_sum["created_aliases"] += ca
                    res["existing_aliases"] += ea
                    ws_sum["existing_aliases"] += ea
            res["workspaces"].append(ws_sum)

        res["legacy_terms"] = legacy_total
        res["valid_terms"] = valid_total
        if legacy_total == 0:
            c.rollback()
            reason = (f"工作空间 {workspace_id} 的旧 ontology_terms 为空："
                      "没有可迁移数据，未写入任何内容"
                      if workspace_id else
                      "未发现旧 ontology_terms 数据：所有工作空间设置中都没有可迁移术语，"
                      "未写入任何内容")
            return {**res, "ok": False, "code": "legacy_data_missing", "reason": reason}
        if valid_total == 0:
            c.rollback()
            return {**res, "ok": False, "code": "legacy_data_invalid",
                    "reason": (f"旧 ontology_terms 共 {legacy_total} 条，但没有有效术语"
                               "（canonical 缺失或少于 2 字），未写入任何内容")}
        if dry_run:
            c.rollback()
        else:
            c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return {**res, "ok": False, "code": "migration_failed",
                "reason": f"迁移失败：{type(e).__name__}: {e}"}
    finally:
        c.close()

    res["ok"] = True
    res["idempotent"] = bool(res["created_terms"] == 0 and
                             (res["existing_terms"] or res["skipped_confirmed"]))
    if res["idempotent"]:
        res["reason"] = (f"旧 ontology_terms 已迁移，本次未新增（幂等）："
                         f"扫描 {res['legacy_terms']} 条，已存在 {res['existing_terms']} 条，"
                         f"保留已确认 {res['skipped_confirmed']} 条")
    else:
        res["reason"] = (f"旧 ontology_terms 迁移完成：新增 {res['created_terms']} 条术语、"
                         f"{res['created_aliases']} 个别名")
    if dry_run:
        res["reason"] = "迁移预演（dry_run）：" + res["reason"] + "；事务已回滚，未写入"
    else:
        if res.get("conflicts"):
            # 迁移冲突（别名占用/key 撞车）同样落冲突表，UI/接口可查询。
            try:
                _record_term_conflicts(res["conflicts"], actor=actor)
            except Exception:
                logging.getLogger(__name__).debug("ignored", exc_info=True)
        try:
            R.audit_logs.log(
                actor=actor or "system", action="term.legacy_migrated",
                object=workspace_id or "*",
                after=json.dumps({k: res.get(k) for k in (
                    "legacy_terms", "created_terms", "existing_terms",
                    "skipped_confirmed", "created_aliases")}, ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        # 迁移完成后把已生效术语补投到 onto_entity；投影失败不回滚迁移结果，
        # 只在结果中给出告警，避免旧数据迁移被本体投影问题阻塞。
        try:
            onto = project_confirmed_terms_to_onto_entity(
                tenant_id=tenant_id, workspace_id=workspace_id,
                actor=actor, all_spaces=all_spaces, statuses=EFFECTIVE_STATUSES)
            res["onto_entity"] = {
                "ok": onto.get("ok"),
                "code": onto.get("code") or "",
                "created": onto.get("created") or 0,
                "updated": onto.get("updated") or 0,
                "existing": onto.get("existing") or 0,
                "skipped_manual": onto.get("skipped_manual") or 0,
                "skipped_confirmed": onto.get("skipped_confirmed") or 0,
                "skipped_conflict": onto.get("skipped_conflict") or 0,
                "conflicts": onto.get("conflicts") or [],
                "reason": onto.get("reason") or "",
            }
            if not onto.get("ok") and onto.get("code") != "confirmed_terms_missing":
                res["warnings"].append({
                    "warning": "onto_entity_projection_failed",
                    "detail": onto.get("reason") or "",
                })
        except Exception as e:
            res["warnings"].append({
                "warning": "onto_entity_projection_failed",
                "detail": f"{type(e).__name__}: {e}",
            })
        # 迁移/补投可能暴露 not_equal、别名占用、实体冲突；同步到冲突表供查询。
        try:
            scan_term_conflicts(actor=actor)
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
    return res


# 兼容不同调用方命名；实现只有一份。
migrate_legacy_terms = migrate_legacy_ontology_terms
migrate_ontology_terms = migrate_legacy_ontology_terms
migrate_old_ontology_terms = migrate_legacy_ontology_terms


def aliases_for(term_id: str) -> list:
    """读取迁移/维护后落在 onto_alias 的术语别名。"""
    tid = _text(term_id)
    if not tid:
        return []
    c = db.connect()
    try:
        rows = c.execute(
            "SELECT id,type_key,alias,entity_id,evidence,source,status,created_at "
            "FROM onto_alias WHERE entity_id=? ORDER BY created_at,alias", (tid,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        c.close()


# ---------------------------------------------------------------- not_equal 查询/冲突

def not_equal_pairs() -> list:
    """当前租户/空间内所有 not_equal 声明（只返回非空项，供查询/导出）。"""
    out = []
    for x in list_terms():
        ne = _clean_names(_as_list(x.get("not_equal")))
        if not ne:
            continue
        out.append({
            "term_id": x.get("term_id"), "name": x.get("name"),
            "key": x.get("key") or x.get("term_key"),
            "status": x.get("status"), "source": x.get("source"),
            "synonyms": list(x.get("synonyms") or []), "not_equal": ne,
        })
    return out


def not_equal_map() -> dict:
    """标准名 → not_equal 列表；最小可查询入口。"""
    return {x["name"]: x["not_equal"] for x in not_equal_pairs()}


def not_equal_for(name_or_id: str) -> list:
    """按术语 id / 标准名 / 同义词查 not_equal；未命中返回空列表。"""
    target = _text(name_or_id)
    tn = _name(target)
    if not target:
        return []
    for x in list_terms():
        if x.get("term_id") == target or _name(x.get("name")) == tn or \
                any(_name(a) == tn for a in (x.get("synonyms") or [])):
            return _clean_names(_as_list(x.get("not_equal")))
    return []


def is_not_equal(a: str, b: str) -> bool:
    """判断两个词是否被声明为“不等同”（对称：任一方声明即可）。"""
    na, nb = _name(a), _name(b)
    if not na or not nb or na == nb:
        return False
    for x in list_terms():
        names = {_name(x.get("name"))}
        names.update(_name(v) for v in (x.get("synonyms") or []))
        names.discard("")
        ne = {_name(v) for v in (x.get("not_equal") or [])}
        if na in names and nb in ne:
            return True
        if nb in names and na in ne:
            return True
    return False


def detect_not_equal_conflicts() -> list:
    """最小冲突检测：自身矛盾、not_equal 与别名归一冲突、共享别名歧义。

    只报告可定位到术语的数据问题；忽略 ignored 状态，避免已废弃术语制造噪声。
    """
    terms = [x for x in list_terms() if _text(x.get("status")).lower() != "ignored"]
    by_name = {}
    for t in terms:
        by_name.setdefault(_name(t.get("name")), []).append(t)
    syn_owners = {}
    for t in terms:
        for a in t.get("synonyms") or []:
            an = _name(a)
            if an:
                syn_owners.setdefault(an, {})[t.get("term_id")] = t.get("name")
    out, seen = [], set()

    def add(kind: str, severity: str, **kw):
        sig = (kind, kw.get("term_id"), kw.get("other_term_id"),
               kw.get("alias"), _name(kw.get("value")),
               tuple(kw.get("term_ids") or ()))
        if sig in seen:
            return
        seen.add(sig)
        out.append({"kind": kind, "severity": severity, **kw})

    for t in terms:
        tid = t.get("term_id")
        tname = _text(t.get("name"))
        tn = _name(tname)
        if not tn:
            continue
        own_names = {tn}
        own_names.update(_name(v) for v in (t.get("synonyms") or []))
        own_names.discard("")
        for raw in _clean_names(_as_list(t.get("not_equal"))):
            vn = _name(raw)
            if vn in own_names:
                add("not_equal_self", "critical", term_id=tid, name=tname,
                    value=raw,
                    detail="术语把自身名称/同义词同时声明为 not_equal，"
                           "别名归一与不等同声明互相矛盾")
            for other in by_name.get(vn, []):
                oid = other.get("term_id")
                if not oid or oid == tid:
                    continue
                other_names = {_name(v) for v in (other.get("synonyms") or [])}
                other_names.discard("")
                if tn in other_names:
                    add("not_equal_alias_merge", "critical", term_id=tid, name=tname,
                        other_term_id=oid, other_name=other.get("name"), value=raw,
                        detail="本术语声明与对方不等同，但对方把本术语名称当作别名，"
                               "归一链会把两者合并")

    for an, owners in syn_owners.items():
        if len(owners) < 2:
            continue
        ids = [x for x in owners if x]
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                ta = next((x for x in terms if x.get("term_id") == ids[i]), None)
                tb = next((x for x in terms if x.get("term_id") == ids[j]), None)
                if not ta or not tb:
                    continue
                a_ne = {_name(v) for v in (ta.get("not_equal") or [])}
                b_ne = {_name(v) for v in (tb.get("not_equal") or [])}
                if _name(tb.get("name")) in a_ne or _name(ta.get("name")) in b_ne:
                    add("not_equal_alias_shared", "warning", alias=an,
                        term_ids=[ids[i], ids[j]],
                        names=[owners[ids[i]], owners[ids[j]]],
                        detail="同一别名被两个互斥术语声明，归一结果存在歧义")
    return out


# ---------------------------------------------------------------- 冲突扫描/查询

def _desired_aliases(term: dict) -> list:
    name = _text(term.get("name"))
    syn = _clean_names([x for x in _as_list(term.get("synonyms") or [])
                        if _name(x) != _name(name)])
    forbidden = {_name(x) for x in _clean_names(_as_list(term.get("not_equal") or []))}
    return [x for x in syn if _name(x) not in forbidden]


def _alias_conflicts_for_scope(c, term_rows: list) -> list:
    """实际别名归属 + 同义词期望归属的冲突；跨空间同名别名不判冲突。"""
    out = []
    terms_by_id = {_text(t.get("term_id") or t.get("id")): t for t in term_rows}
    _, w = _scope()
    type_key = _LEGACY_ALIAS_TYPE_PREFIX + (w or "default")
    alias_index = _alias_owner_index(c)
    entity_names = {}
    for r in c.execute("SELECT id,type_key,name FROM onto_entity WHERE type_key=?",
                       (type_key,)).fetchall():
        nm = _name(r["name"])
        if nm:
            entity_names.setdefault(nm, dict(r))
    for t in term_rows:
        tid = _text(t.get("term_id") or t.get("id"))
        if not tid or not _is_effective_status(t.get("status")):
            continue
        for alias in _desired_aliases(t):
            an = _name(alias)
            rows_here = alias_index.get(an, [])
            mine = any(_text(r.get("entity_id")) == tid for r in rows_here)
            if mine:
                continue
            entity = entity_names.get(an)
            if entity is not None and _text(entity.get("id")) != tid:
                out.append({
                    "kind": "alias_conflict", "severity": "warning",
                    "tenant_id": _text(t.get("tenant_id")),
                    "workspace_id": _text(t.get("workspace_id")),
                    "term_id": tid, "name": _text(t.get("name")), "alias": alias,
                    "existing_entity_id": _text(entity.get("id")),
                    "existing_type_key": _text(entity.get("type_key")),
                    "existing_name": _text(entity.get("name")),
                    "detail": "同义词与同命名空间内的其他本体实体标准名冲突",
                })
                continue
            for r in rows_here:
                if _text(r.get("type_key")) != type_key:
                    continue
                oid = _text(r.get("entity_id"))
                owner = terms_by_id.get(oid)
                if owner is not None and _is_effective_status(owner.get("status")):
                    out.append({
                        "kind": "alias_conflict", "severity": "warning",
                        "tenant_id": _text(t.get("tenant_id")),
                        "workspace_id": _text(t.get("workspace_id")),
                        "term_id": tid, "name": _text(t.get("name")), "alias": alias,
                        "existing_entity_id": oid,
                        "existing_type_key": _text(r.get("type_key")),
                        "existing_name": _text(owner.get("name")),
                        "existing_status": _text(owner.get("status")),
                        "detail": "同义词被其他已生效术语占用，保留旧归属（旧确认不覆盖）",
                    })
                    break
    # 同一别名被多个实体实际占用（历史数据/迁移造成），也必须在冲突表中可见。
    for an, rows in alias_index.items():
        owners = {_text(r.get("entity_id")): r for r in rows
                  if _text(r.get("type_key")) == type_key
                  and _text(r.get("status")) != "stale"}
        owners = {k: v for k, v in owners.items() if k}
        if len(owners) < 2:
            continue
        ids = sorted(owners)
        names = [_text((terms_by_id.get(i) or {}).get("name")) for i in ids]
        effective = [i for i in ids
                     if terms_by_id.get(i) and _is_effective_status(terms_by_id[i].get("status"))]
        if not effective:
            continue
        out.append({
            "kind": "alias_conflict", "severity": "warning",
            "tenant_id": _scope()[0], "workspace_id": w,
            "term_id": effective[0], "alias": _text(owners[effective[0]].get("alias")),
            "term_ids": ids, "names": names,
            "existing_entity_id": ids[0] if ids else "",
            "detail": "同一别名被多个实体占用，归一结果存在歧义",
        })
    return out


def _entity_conflicts_for_scope(c, tenant_id: str, workspace_id: str) -> list:
    rows = _projection_terms(c, tenant_id, workspace_id, EFFECTIVE_STATUSES)
    if not rows:
        return []
    # dry_run 不写库；只借投影器算出与人工/已确认/同名实体冲突的条目。
    body = _project_terms(c, rows, dry_run=True)
    return list(body.get("conflicts") or [])


def _name_conflicts_for_scope(term_rows: list) -> list:
    out = []
    groups = {}
    for t in term_rows:
        if _status(t.get("status"), "draft") == "ignored":
            continue
        nm = _name(t.get("name"))
        if nm:
            groups.setdefault(nm, []).append(t)
    for nm, rows in groups.items():
        if len(rows) < 2:
            continue
        ids = [_text(x.get("term_id") or x.get("id")) for x in rows]
        names = [_text(x.get("name")) for x in rows]
        for x in rows:
            out.append({
                "kind": "term_name_conflict", "severity": "warning",
                "tenant_id": _text(x.get("tenant_id")),
                "workspace_id": _text(x.get("workspace_id")),
                "term_id": _text(x.get("term_id") or x.get("id")),
                "name": _text(x.get("name")),
                "term_ids": ids, "names": names,
                "detail": "同一空间存在多个同标准名术语，词典解析存在歧义",
            })
    return out


def _reverse_orphans_for_scope(c, tenant_id: str, workspace_id: str) -> list:
    """扫描指向不存在/未生效术语的投影；用于冲突可见与删除后的孤儿自检。"""
    out = []
    type_key = _LEGACY_ALIAS_TYPE_PREFIX + (workspace_id or "default")
    term_rows = [dict(r) for r in c.execute(
        "SELECT id,name,status,tenant_id,workspace_id FROM business_term "
        "WHERE tenant_id=? AND workspace_id=?", (tenant_id, workspace_id)).fetchall()]
    terms_by_id = {_text(r.get("id")): r for r in term_rows}
    for r in c.execute("SELECT id,type_key,alias,entity_id,status FROM onto_alias "
                       "WHERE type_key=?", (type_key,)).fetchall():
        row = dict(r)
        owner = terms_by_id.get(_text(row.get("entity_id")))
        if owner is None:
            out.append({
                "kind": "reverse_orphan", "severity": "info", "orphan_type": "alias",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "existing_entity_id": _text(row.get("entity_id")),
                "existing_name": _text(row.get("alias")),
                "alias": _text(row.get("alias")),
                "existing_status": _text(row.get("status")),
                "detail": "别名指向不存在的术语，属于孤儿投影",
            })
        elif (not _is_effective_status(owner.get("status"))
              and _is_effective_status(row.get("status"))):
            out.append({
                "kind": "reverse_orphan", "severity": "info", "orphan_type": "alias",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": _text(owner.get("id")), "name": _text(owner.get("name")),
                "existing_entity_id": _text(row.get("entity_id")),
                "existing_name": _text(row.get("name")),
                "alias": _text(row.get("alias")),
                "existing_status": _text(row.get("status")),
                "detail": "术语已未生效但别名仍为活动状态，属于待反投影的孤儿",
            })
    for r in c.execute("SELECT id,type_key,name,props_json FROM onto_entity").fetchall():
        row = dict(r)
        props = _entity_props(row)
        src = _text(props.get("projection_source") or props.get("source")).lower()
        if src != _ENTITY_PROJECTION_SOURCE:
            continue
        p_t = _text(props.get("tenant_id"))
        p_w = _text(props.get("workspace_id"))
        if (p_t and p_t != tenant_id) or (p_w and p_w != workspace_id):
            continue
        tid = _text(props.get("term_id")) or _text(row.get("id"))
        owner = terms_by_id.get(tid)
        if owner is None or not _is_effective_status(owner.get("status")):
            out.append({
                "kind": "reverse_orphan", "severity": "info", "orphan_type": "entity",
                "tenant_id": tenant_id, "workspace_id": workspace_id,
                "term_id": tid if owner is not None else "",
                "name": _text(owner.get("name")) if owner else "",
                "existing_entity_id": _text(row.get("id")),
                "existing_type_key": _text(row.get("type_key")),
                "existing_name": _text(row.get("name")),
                "existing_status": _text(props.get("status")),
                "detail": "onto_entity 仍带词典投影标记，但术语不存在或未生效",
            })
    try:
        from . import ontology_service as _ontology
        st = _ontology.workspace_settings(workspace_id)
        for item in _ontology.workspace_terms(st):
            tid = _text(item.get("term_id"))
            if not tid or _text(item.get("source")) != _ENTITY_PROJECTION_SOURCE:
                continue
            owner = terms_by_id.get(tid)
            if owner is None or not _is_effective_status(owner.get("status")):
                out.append({
                    "kind": "reverse_orphan", "severity": "info",
                    "orphan_type": "workspace_term",
                    "tenant_id": tenant_id, "workspace_id": workspace_id,
                    "term_id": tid, "name": _text(item.get("canonical")),
                    "existing_name": _text(item.get("canonical")),
                    "detail": "workspace.settings_json.ontology_terms 仍保留未生效术语投影",
                })
    except Exception:
        logging.getLogger(__name__).debug("ignored", exc_info=True)
    return out


def scan_term_conflicts(actor: str = "", close_resolved: bool = True) -> dict:
    """重建当前租户/空间的词典冲突表；幂等，且自动关闭已不存在的 open 冲突。"""
    t, w = _scope()
    c = db.connect()
    resolved = 0
    try:
        term_rows = [_row(dict(r)) for r in c.execute(
            "SELECT * FROM business_term WHERE tenant_id=? AND workspace_id=? ORDER BY name",
            (t, w)).fetchall()]
        conflicts = []
        conflicts += _alias_conflicts_for_scope(c, term_rows)
        conflicts += _name_conflicts_for_scope(term_rows)
        conflicts += _entity_conflicts_for_scope(c, t, w)
        conflicts += _reverse_orphans_for_scope(c, t, w)
        conflicts += detect_not_equal_conflicts()
        by_id = {}
        for item in conflicts:
            payload = _term_conflict_payload(item)
            if payload["id"] not in by_id:
                by_id[payload["id"]] = item
        for item in by_id.values():
            _upsert_term_conflict(c, item, actor=actor)
        if close_resolved:
            keep_open_types = ("term_key_conflict", "term_reverse_entity_skipped")
            rows = c.execute(
                "SELECT id,type FROM conflict WHERE type LIKE 'term_%' "
                "AND tenant_id=? AND workspace_id=? AND status='open'", (t, w)).fetchall()
            for row in rows:
                if _text(row["id"]) in by_id or _text(row["type"]) in keep_open_types:
                    continue
                c.execute("UPDATE conflict SET status='resolved',resolved_at=?,resolved_by=?,"
                          "note='自动关闭：冲突已不存在' WHERE id=?",
                          (db.now(), actor or "system", row["id"]))
                resolved += 1
        c.commit()
    except Exception as e:
        try:
            c.rollback()
        except Exception:
            logging.getLogger(__name__).debug("ignored", exc_info=True)
        return {"ok": False, "code": "conflict_scan_failed",
                "error": f"冲突扫描失败：{type(e).__name__}: {e}",
                "items": [], "active": 0, "resolved": 0}
    finally:
        c.close()
    items = []
    for pid, item in by_id.items():
        payload = _term_conflict_payload(item)
        items.append({**item, "id": pid, "type": payload["type"],
                      "severity": payload["severity"], "tenant_id": t,
                      "workspace_id": w})
    if resolved:
        _audit_term(actor, "term.conflicts_resolved", w or "*", after={"resolved": resolved})
    return {"ok": True, "items": items, "conflicts": items,
            "active": len(items), "resolved": resolved,
            "tenant_id": t, "workspace_id": w}


def list_term_conflicts(status: str = "", conflict_type: str = "",
                        limit: int = 200, offset: int = 0) -> dict:
    """查询词典冲突（默认 open）；status='all' 可看已裁决历史。"""
    t, w = _scope()
    want = _text(status) or "open"
    where = ["type LIKE 'term_%'", "tenant_id=?", "workspace_id=?"]
    args = [t, w]
    if want != "all":
        where.append("status=?")
        args.append(want)
    if _text(conflict_type):
        where.append("type=?")
        args.append(_text(conflict_type))
    c = db.connect()
    try:
        sql = ("SELECT * FROM conflict WHERE " + " AND ".join(where) +
               " ORDER BY created_at DESC,id LIMIT ? OFFSET ?")
        rows = [dict(r) for r in c.execute(sql, args + [max(1, int(limit)), max(0, int(offset))]).fetchall()]
        all_rows = [dict(r) for r in c.execute(
            "SELECT status,severity FROM conflict WHERE type LIKE 'term_%' "
            "AND tenant_id=? AND workspace_id=?", (t, w)).fetchall()]
    finally:
        c.close()
    items = []
    for r in rows:
        for k in ("slots_a", "slots_b"):
            try:
                r[k] = json.loads(r.get(k) or "{}")
            except Exception:
                r[k] = {}
        r["kind"] = _text(r.get("type")).replace(_CONFLICT_TYPE_PREFIX, "", 1)
        r["term_id"] = _text((r.get("slots_a") or {}).get("term_id"))
        items.append(r)
    stats = {
        "total": len(all_rows),
        "open": sum(1 for x in all_rows if _text(x.get("status")) == "open"),
        "critical": sum(1 for x in all_rows if _text(x.get("severity")) == "critical"),
        "resolved": sum(1 for x in all_rows if _text(x.get("status")) == "resolved"),
        "ignored": sum(1 for x in all_rows if _text(x.get("status")) == "ignored"),
    }
    return {"ok": True, "items": items, "conflicts": items,
            "stats": stats, "total": len(items),
            "status": want, "tenant_id": t, "workspace_id": w,
            "reason": "" if items else "当前作用域没有符合条件的词典冲突"}


def orphan_projections() -> dict:
    """当前空间的词典投影孤儿自检：aliases/entities/workspace_terms。"""
    t, w = _scope()
    c = db.connect()
    try:
        items = _reverse_orphans_for_scope(c, t, w)
    finally:
        c.close()
    groups = {"alias": [], "entity": [], "workspace_term": []}
    for x in items:
        groups.setdefault(_text(x.get("orphan_type")), []).append(x)
    return {"ok": True, "items": items, "orphans": items,
            "aliases": groups.get("alias", []),
            "entities": groups.get("entity", []),
            "workspace_terms": groups.get("workspace_term", []),
            "count": len(items), "tenant_id": t, "workspace_id": w}


def sync_not_equal_conflicts(actor: str = "") -> dict:
    """把 not_equal 冲突同步进冲突表（旧缺口：not_equal 从未进冲突表）。"""
    items = detect_not_equal_conflicts()
    stats = _record_term_conflicts(items, actor=actor)
    return {"ok": True, "conflicts": items, **stats,
            "count": len(items), "reason": "" if items else "没有 not_equal 冲突"}


def conflicts_for_term(term_id: str, status: str = "open") -> list:
    """按术语 ID 查冲突（默认 open）；命中 rule_a 或 slots_a.term_id。"""
    tid = _text(term_id)
    if not tid:
        return []
    items = list_term_conflicts("all" if _text(status) == "all" else status,
                                limit=500).get("items") or []
    return [x for x in items
            if _text(x.get("rule_a")) == tid
            or _text((x.get("slots_a") or {}).get("term_id")) == tid]


# 兼容不同调用方命名；实现只有一份。
not_equal_conflicts = detect_not_equal_conflicts
query_not_equal = not_equal_pairs
query_term_conflicts = list_term_conflicts
query_conflicts = list_term_conflicts
term_conflicts = list_term_conflicts
list_conflicts = list_term_conflicts
term_conflict_list = conflicts_for_term
verify_projections = orphan_projections
orphans = orphan_projections
update = update_term
delete = delete_term
downgrade = downgrade_term
set_status = set_term_status
create = create_term
confirm_term = confirm



