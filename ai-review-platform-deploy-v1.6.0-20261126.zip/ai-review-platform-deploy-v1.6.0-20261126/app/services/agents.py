"""智能体管理：运行汇总 + 列表（带指标）+ 详情（职责/工作流/提示词/版本）。"""
import contextvars
import gzip
import hashlib
import json
import logging
import math
import os
import tempfile

from .. import db
from .. import repositories as R
from .agent_definitions import AGENT_META, AGENT_RUNTIME, CAP_BY_AGENT, NODE_EXTRA, PARAMS
from . import agent_runtime as _art
from .agent_runners import (RUNNERS, sanitize_node_io, summarize_node_status)

# L108：运行期「当前操作人」上下文。run_agent 的 audit actor 必须可追溯到真实用户，
# 不能写成 system；HTTP/CLI 入口显式传 actor 之外，嵌套调用（orchestrator/review 等
# 间接 run_agent）从本上下文继承，避免只修到第一层。
_ACTOR_CTX = contextvars.ContextVar("agent_runtime_actor", default="")


def set_actor(actor: str):
    """设置当前上下文操作人（返回 token，供 reset_actor 恢复）。"""
    return _ACTOR_CTX.set(str(actor or ""))


def reset_actor(token) -> None:
    """恢复 set_actor 之前的操作人；token 非法时忽略（不阻断请求收尾）。"""
    try:
        _ACTOR_CTX.reset(token)
    except Exception:  # noqa: BLE001 - 上下文已失效时保持当前值即可
        pass


def current_actor() -> str:
    """当前上下文操作人；空串表示未设置（run_agent 回退 system 仅限系统自动化路径）。"""
    try:
        return str(_ACTOR_CTX.get() or "")
    except Exception:  # noqa: BLE001
        return ""

# 7 智能体登记顺序（与 agent_definitions.AGENT_META 同源；看板/路由矩阵都以此为唯一清单）
HEALTH_AGENTS = tuple(AGENT_META.keys())


def _profile(a: dict) -> dict:
    try:
        return json.loads(a.get("profile_json") or "{}")
    except Exception:
        return {}


def _prompt_map(raw) -> dict:
    """{节点名: 非空提示词}；空字符串不视为已覆盖。"""
    return {str(x.get("node") or ""): str(x.get("prompt") or "")
            for x in _art.prompt_list(raw) if str(x.get("prompt") or "").strip()}


def _node_stats(profile: dict) -> dict:
    """节点类型统计与模型节点提示词覆盖数。

    只有 type=模型 的节点计入提示词覆盖；程序/校验节点由程序/规则执行，
    即使历史数据里有文本也不计为模型提示词，更不会由系统伪造。
    """
    wf = profile.get("workflow") or []
    types: dict = {}
    for n in wf:
        t = str(n.get("type") or "程序")
        types[t] = types.get(t, 0) + 1
    model_nodes = [n for n in wf if str(n.get("type") or "") == "模型"]
    names = [str(n.get("name") or "") for n in model_nodes if n.get("name")]
    prompts = _prompt_map(profile.get("prompts_list"))
    covered = [x for x in names if prompts.get(x)]
    missing = [x for x in names if not prompts.get(x)]
    return {
        "nodes": len(wf),
        "types": types,
        "model_node_count": len(model_nodes),
        "program_node_count": types.get("程序", 0),
        "check_node_count": types.get("校验", 0),
        "manual_node_count": types.get("人工", 0),
        "prompt_count": len(covered),
        "prompt_coverage": (round(len(covered) / len(model_nodes), 3) if model_nodes else None),
        "agent_kind": "模型型" if model_nodes else "程序型",
        "prompt_covered": bool(model_nodes) and not missing,
        "model_nodes_missing_prompt": missing,
    }


def _runs(agent_id: str) -> list:
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT r.* FROM agent_run r JOIN agent_version v ON v.id=r.agent_version_id "
                "WHERE v.agent_id=? ORDER BY r.created_at DESC", (agent_id,)).fetchall()]
        return rows
    except Exception:
        return []


# ---------------- 智能体可用性：四态与模型可用性同源，不拿“已启用”冒充可用 ----------------
AVAIL_LABEL = {"ok": "连接正常", "configured": "已配置待测",
               "fail": "连接失败", "unconfigured": "未配置",
               "disabled": "已停用", "program": "程序型可用（无需模型）"}
_WORST_FIRST = ("fail", "unconfigured", "configured")


def _model_index() -> dict:
    """读取模型四态（model.availability，只读），建立 id/model_id/name → 状态 索引。"""
    try:
        from . import model as _model
        av = _model.availability()
    except Exception:
        logging.getLogger(__name__).debug("model availability unavailable", exc_info=True)
        return {"by_key": {}, "counts": {}}
    by_key: dict = {}
    for m in av.get("items") or []:
        rec = {"state": m.get("state"), "label": m.get("state_label") or "未配置",
               "name": m.get("name") or "", "model_id": m.get("model_id") or "",
               "enabled": bool(m.get("enabled"))}
        for k in (m.get("id"), m.get("model_id"), m.get("name")):
            if k:
                by_key[str(k)] = rec
    return {"by_key": by_key, "counts": av.get("counts") or {}}


def _model_refs(profile: dict, version: dict) -> list:
    """该智能体依赖的模型引用：版本模型 + 各模型节点绑定的模型（去重）。"""
    refs = []
    _v = str((version or {}).get("model") or "").strip()
    if _v:
        refs.append(_v)
    for p in profile.get("prompts_list") or []:
        _m = str(p.get("model_id") or "").strip()
        if _m and _m not in refs:
            refs.append(_m)
    for n in profile.get("workflow") or []:
        if str(n.get("type") or "") != "模型":
            continue
        _m = str(n.get("model_id") or "").strip()
        if _m and _m not in refs:
            refs.append(_m)
    return refs


def agent_availability(agent: dict, node_stats: dict, profile: dict, version: dict,
                       model_idx: dict | None = None) -> dict:
    """智能体可用性（四态）：由依赖模型状态决定，停用/程序型单独标注。

    说明：这里只反映“依赖模型是否可用”，不声称智能体业务质量已经验证；
    质量仍需运行记录/评测证据。
    """
    status = str((agent or {}).get("status") or "draft")
    if status != "active":
        return {"state": "disabled", "label": AVAIL_LABEL["disabled"],
                "effective": False, "model_refs": [],
                "note": "智能体已停用；停用状态不等于可用，恢复后按依赖模型四态判定"}
    if not node_stats.get("model_node_count"):
        return {"state": "program", "label": AVAIL_LABEL["program"],
                "effective": True, "model_refs": [],
                "note": "程序/规则节点执行，不依赖模型密钥"}
    idx = (model_idx if model_idx is not None else _model_index()).get("by_key") or {}
    refs = _model_refs(profile, version or {})
    hits = []
    for ref in refs:
        rec = idx.get(ref)
        if rec:
            hits.append({**rec, "ref": ref})
        else:
            hits.append({"state": "unconfigured", "label": AVAIL_LABEL["unconfigured"],
                         "ref": ref, "name": ref, "model_id": ref, "enabled": False})
    states = [h["state"] for h in hits]
    state = next((s for s in _WORST_FIRST if s in states),
                 "ok" if "ok" in states else "unconfigured")
    primary = next((h for h in hits if h["state"] == state), hits[0] if hits else {})
    ref_text = "、".join(str(h.get("ref") or "") for h in hits) or "默认模型"
    note_map = {
        "ok": f"依赖模型 {ref_text} 最近一次真实测试连接成功（数据库记录）",
        "configured": f"依赖模型 {ref_text} 已配置凭据但尚未真实测试；不显示为可用",
        "fail": f"依赖模型 {ref_text} 最近一次测试连接失败；调用会降级/失败",
        "unconfigured": f"依赖模型 {ref_text} 未配置凭据；模型节点会降级/跳过",
    }
    return {"state": state, "label": AVAIL_LABEL[state], "effective": state == "ok",
            "model_refs": refs, "model_name": primary.get("name") or "",
            "model_state": state, "note": note_map[state]}


def list_agents() -> dict:
    out = []
    try:
        agents = [dict(r) for r in R.agents.list()]
    except Exception:
        agents = []
    total_runs = total_ok = 0
    model_idx = _model_index()
    av_counts = {k: 0 for k in AVAIL_LABEL}
    for a in agents:
        p = _profile(a)
        runs = _runs(a["id"])
        ok = sum(1 for r in runs if (r.get("status") or "") == "ok")
        fail = len(runs) - ok
        total_runs += len(runs)
        total_ok += ok
        meta = AGENT_META.get(a["id"], {})
        version = _latest_published(a["id"]) or {}
        _pubs_n = len(published_versions(a["id"]))
        st = _node_stats(p)
        av = agent_availability(a, st, p, version, model_idx)
        av_counts[av["state"]] = av_counts.get(av["state"], 0) + 1
        out.append({
            "id": a["id"], "name": a.get("name", ""), "type": a.get("type", ""),
            "status": a.get("status", "draft"),
            "desc": p.get("desc", ""),
            "group": p.get("group", "通用"),
            "tags": p.get("tags", []),
            "capability": meta.get("capability", a.get("type", "")),
            "cap": meta.get("cap", ""),
            "trigger": meta.get("trigger", "未配置主链路触发点"),
            "main_stage": meta.get("main_stage", ""),
            "main_chain": bool(meta and a.get("status") == "active"),
            "input": meta.get("input", ""), "output": meta.get("output", ""),
            "version": version.get("version", ""), "model": version.get("model", ""),
            # L108：生效版本 id / published 数（旧库多条 published 可被观测到）
            "version_id": str(version.get("id") or ""),
            "published_version_count": _pubs_n,
            "version_governance": ("ok" if _pubs_n <= 1 else "legacy_multiple_published"),
            "runs": len(runs), "success": ok, "failure": fail,
            "ok_rate": (round(ok / len(runs), 3) if runs else None),
            "avg_latency": (round(sum((x.get("latency_ms") or 0) for x in runs) / len(runs)) if runs else None),
            "last_run": runs[0].get("created_at", "") if runs else "",
            "nodes": st["nodes"],
            "params": (len(p.get("params_list") or []) if p.get("params_list") is not None
                       else p.get("params", 0)),
            "prompts": st["prompt_count"],
            # 模型型/程序型标识与提示词覆盖率：列表页据此展示，程序节点不计入提示词
            "agent_kind": st["agent_kind"],
            "model_node_count": st["model_node_count"],
            "program_node_count": st["program_node_count"],
            "prompt_count": st["prompt_count"],
            "prompt_coverage": st["prompt_coverage"],
            "prompt_covered": st["prompt_covered"],
            "model_nodes_missing_prompt": st["model_nodes_missing_prompt"],
            # 四态可用性：不把 status=active（管理启用）当成可用。
            "availability_state": av["state"], "availability_label": av["label"],
            "availability_note": av["note"], "effective": av["effective"],
            "model_refs": av["model_refs"], "model_name": av.get("model_name") or "",
            "management_label": "管理启用" if a.get("status") == "active" else "管理停用",
        })
    enabled_n = sum(1 for x in out if x["status"] == "active")
    return {"items": out, "total": len(out),
            "enabled": enabled_n,
            "management_enabled": enabled_n,
            "runs": total_runs,
            "ok_rate": (round(total_ok / total_runs, 3) if total_runs else None),
            "availability_counts": av_counts,
            "effective": sum(1 for x in out if x.get("effective")),
            "availability_labels": dict(AVAIL_LABEL),
            "availability_policy": ("智能体可用性由其依赖模型的四态决定：未配置/已配置待测/"
                                    "连接失败都不算可用；程序型智能体不依赖模型；"
                                    "“管理启用”只是开关，不等于可用")}


def agent_detail(agent_id: str) -> dict:
    a = R.agents.get(agent_id)
    if not a:
        return {}
    p = _profile(a)
    runs = _runs(agent_id)
    ok = sum(1 for r in runs if (r.get("status") or "") == "ok")
    meta = AGENT_META.get(agent_id, {})
    version = _latest_published(agent_id) or {}
    _published = published_versions(agent_id)
    versions, versions_error = [], ""
    try:
        # agent_version 表真实列是 published_at/version（没有 created_at）。
        # 这里若读失败不许静默吞成「暂无版本」：显式返回 versions_error 供前端提示。
        versions = [dict(v) for v in R.agent_versions.list(
            "agent_id=?", (agent_id,), order="published_at DESC, version DESC")]
    except Exception as _e:  # noqa: BLE001 - 读失败必须可观测，不伪造空态
        versions_error = f"{type(_e).__name__}: {str(_e)[:200]}"
        logging.getLogger(__name__).error(
            "agent version history read failed agent=%s", agent_id, exc_info=True)
    st = _node_stats(p)
    av = agent_availability(a, st, p, version)
    _type_by_name = {str(n.get("name") or ""): str(n.get("type") or "") for n in (p.get("workflow") or [])}
    return {
        "id": a["id"], "name": a.get("name", ""), "type": a.get("type", ""),
        "status": a.get("status", "draft"),
        "desc": p.get("desc", ""),
        "capability": meta.get("capability", a.get("type", "")), "cap": meta.get("cap", ""),
        "trigger": meta.get("trigger", "未配置主链路触发点"), "main_stage": meta.get("main_stage", ""),
        "main_chain": bool(meta and a.get("status") == "active"),
        "input": meta.get("input", ""), "output": meta.get("output", ""),
        "current_version": version.get("version", ""), "model": version.get("model", ""),
        # L108：唯一生效版本显式下发（id 供审计/回滚追溯；published 数用于发现旧库未治理）
        "current_version_id": str(version.get("id") or ""),
        "effective_version": version.get("version", ""),
        "effective_version_id": str(version.get("id") or ""),
        "published_version_count": len(_published),
        "version_governance": ("ok" if len(_published) <= 1
                               else "legacy_multiple_published"),
        "group": p.get("group", "通用"), "tags": p.get("tags", []),
        "responsibility": p.get("responsibility", ""),
        "not_responsibility": p.get("not_responsibility", ""),
        "run_modes": p.get("run_modes", []),
        "inputs": p.get("inputs", []),
        "outputs": p.get("outputs", []),
        "workflow": p.get("workflow", []),
        # 只返回非空提示词；node_type 标明它属于模型节点，程序/校验节点不伪造提示词
        "prompts_list": [{"node": x["node"], "prompt": x["prompt"],
                          "model_id": x.get("model_id", ""),
                          "node_type": _type_by_name.get(x["node"], "模型")}
                         for x in _art.prompt_list(p.get("prompts_list"))],
        "prompt_defaults": {str(x.get("node") or ""): str(x.get("prompt") or "")
                            for x in (AGENT_RUNTIME.get(agent_id, {}) or {}).get("prompts", [])
                            if str(x.get("prompt") or "").strip()},
        "params_list": p.get("params_list", []),
        # 模型型/程序型标识 + 模型节点提示词覆盖数（程序节点不计入）
        "node_stats": st,
        "agent_kind": st["agent_kind"],
        "model_node_count": st["model_node_count"],
        "program_node_count": st["program_node_count"],
        "prompt_count": st["prompt_count"],
        "prompt_coverage": st["prompt_coverage"],
        "prompt_covered": st["prompt_covered"],
        "model_nodes_missing_prompt": st["model_nodes_missing_prompt"],
        # 四态可用性（与模型页同源）；"管理启用"不等于可用。
        "availability_state": av["state"], "availability_label": av["label"],
        "availability_note": av["note"], "effective": av["effective"],
        "model_refs": av["model_refs"], "model_name": av.get("model_name") or "",
        "management_label": "管理启用" if a.get("status") == "active" else "管理停用",
        "availability_labels": dict(AVAIL_LABEL),
        "metrics": {"runs": len(runs), "ok": ok, "fail": len(runs) - ok,
                    "ok_rate": (round(ok / len(runs), 3) if runs else None),
                    "avg_latency": (round(sum((x.get("latency_ms") or 0) for x in runs) / len(runs)) if runs else None),
                    "last_run": runs[0].get("created_at", "") if runs else "",
                    "nodes": st["nodes"],
                    "params": (len(p.get("params_list") or []) if p.get("params_list") is not None
                               else p.get("params", 0)),
                    "prompts": st["prompt_count"]},
        "recent_runs": [{"id": r.get("id", ""), "status": r.get("status", ""), "latency": r.get("latency_ms"),
                         "case_id": r.get("case_id", ""), "created_at": r.get("created_at", "")} for r in runs[:12]],
        "node_runs": [{"node_id": n.get("node_id", ""), "node_name": n.get("node_name", ""),
                       "node_type": n.get("node_type", ""), "status": n.get("status", ""),
                       "latency": n.get("latency_ms"), "created_at": n.get("created_at", ""),
                       "input": _safe_json(n.get("input_json")),
                       "output": _safe_json(n.get("output_json")), "error": n.get("error") or ""}
                      for n in (R.agent_node_runs.list("agent_id=?", (agent_id,),
                                                        order="created_at DESC", limit=30) if hasattr(R, "agent_node_runs") else [])],
        "versions": [{"id": v.get("id", ""),
                      "version": v.get("version", ""), "status": v.get("status", ""),
                      # L108：唯一生效版本标记（superseded/archived 不再被误认成生效）
                      "effective": bool(v.get("id") and v.get("id") == version.get("id")),
                      "published_at": v.get("published_at", ""),
                      "model": v.get("model", "")} for v in versions],
        "versions_total": len(versions),
        # 版本历史读取失败时非空（前端显示「版本历史读取失败」而不是「暂无版本」）
        "versions_error": versions_error,
    }


def list_runs(limit: int = 50) -> list:
    out = []
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT r.*, a.name AS agent_name FROM agent_run r "
                "LEFT JOIN agent_version av ON av.id=r.agent_version_id "
                "LEFT JOIN agent a ON a.id=av.agent_id "
                "ORDER BY r.created_at DESC LIMIT ?", (limit,)).fetchall()]
        for r in rows:
            out.append({"agent": r.get("agent_name") or "", "status": r.get("status", ""),
                        "latency": (str(r.get("latency_ms")) + "ms") if r.get("latency_ms") is not None else "",
                        "created_at": r.get("created_at", "")})
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return out


def _safe_json(raw):
    try:
        return json.loads(raw or "{}")
    except Exception:
        return {}


# ===========================================================================
# L14 A1：7 智能体 per-agent 健康看板（从 agent_run 聚合，只读）
#
# 口径（写死，前端与 API 同一份）：
#   runs        = 时间窗（最近 limit 条 agent_run）内该 agent 的运行数
#   success     = status=ok；degraded 不算成功（确定性回退/模型不可用必须可见）
#   success_rate= ok / runs；无运行 → null（空态不伪造 0%）
#   p50/p95_ms  = 该 agent 全部运行 latency_ms 的最近秩分位数（不插值；空 → null）
#   tokens      = 仅统计新运行写入的 result_json._llm_usage（旧运行无归属，不估算）
#   top_failures= fail/degraded 的原因聚类 Top5（result_json.error/degraded_reason 归一）
# 历史数据（15k 行）只有 status/latency，无 tokens → token_runs=0，页面显示「无归属」。
# ===========================================================================
HEALTH_LIMIT_DEFAULT = 5000
HEALTH_LIMIT_MIN = 1
HEALTH_LIMIT_MAX = 20000


def _percentile(values: list, q: float):
    """最近秩法分位数（不插值）。空列表返回 None。"""
    vals = sorted(int(v) for v in values if v is not None)
    if not vals:
        return None
    k = max(1, min(len(vals), int(math.ceil(float(q) * len(vals)))))
    return vals[k - 1]


def _health_failure_reason(row: dict) -> str:
    """把 fail/degraded 运行归一成可聚合的失败原因（Top5 口径，不展开原始长文）。

    L168：旧行 result_json 可能被 8000 字符截断 → 走 parse_result_json 容错解析，
    截断历史行显式归为 legacy_truncated，而不是静默当空数据。
    """
    d = parse_result_json(row.get("result_json"))
    if not isinstance(d, dict):
        d = {}
    if d.get("_legacy_truncated"):
        return "legacy_truncated_result_json（L168 前 8000 字符截断，不可完整审计）"
    status = str(row.get("status") or "")
    if status == "fail":
        raw = str(d.get("error") or d.get("degraded_reason") or "").strip()
        return _classify_runtime_failure(raw) or (raw[:80] or "unknown")
    raw = str(d.get("degraded_reason") or "").strip()
    if not raw:
        return "degraded"
    return _classify_runtime_failure(raw) or ("degraded: " + raw[:80])


def agents_health(limit: int = HEALTH_LIMIT_DEFAULT) -> dict:
    """7 智能体健康聚合（只读；空库空态返回 200 语义，不伪造健康结论）。"""
    try:
        limit = int(limit)
    except Exception:
        limit = HEALTH_LIMIT_DEFAULT
    limit = max(HEALTH_LIMIT_MIN, min(HEALTH_LIMIT_MAX, limit))
    # 登记名：优先 agent 表真实名称；表为空/缺行时回落 AGENT_META 能力名
    names: dict = {}
    try:
        for a in R.agents.list():
            names[str(a.get("id") or "")] = str(a.get("name") or "")
    except Exception:
        names = {}
    rows: list = []
    total_runs = 0
    try:
        with db.session() as c:
            total_runs = int(c.execute("SELECT COUNT(*) AS n FROM agent_run").fetchone()["n"])
            rows = [dict(r) for r in c.execute(
                "SELECT r.id, r.status, r.latency_ms, r.result_json, r.created_at, "
                "       v.agent_id AS agent_id "
                "FROM agent_run r LEFT JOIN agent_version v ON v.id=r.agent_version_id "
                "ORDER BY r.created_at DESC LIMIT ?", (limit,)).fetchall()]
    except Exception:
        logging.getLogger(__name__).warning("智能体健康聚合读取失败", exc_info=True)
        rows = []
    buckets = {aid: {"agent_id": aid, "runs": 0, "ok": 0, "degraded": 0, "fail": 0,
                     "latencies": [], "tokens_in": 0, "tokens_out": 0, "token_runs": 0,
                     "llm_calls": 0, "failures": {}, "last_run_at": "", "first_run_at": ""}
               for aid in HEALTH_AGENTS}
    unregistered = 0
    for r in rows:
        aid = str(r.get("agent_id") or "")
        if aid not in buckets:
            unregistered += 1
            continue
        b = buckets[aid]
        b["runs"] += 1
        st = str(r.get("status") or "")
        if st == "ok":
            b["ok"] += 1
        elif st == "degraded":
            b["degraded"] += 1
            b["failures"][_health_failure_reason(r)] = b["failures"].get(_health_failure_reason(r), 0) + 1
        else:
            b["fail"] += 1
            b["failures"][_health_failure_reason(r)] = b["failures"].get(_health_failure_reason(r), 0) + 1
        if r.get("latency_ms") is not None:
            b["latencies"].append(int(r.get("latency_ms") or 0))
        created = str(r.get("created_at") or "")
        if created:
            if not b["last_run_at"] or created > b["last_run_at"]:
                b["last_run_at"] = created
            if not b["first_run_at"] or created < b["first_run_at"]:
                b["first_run_at"] = created
        d = parse_result_json(r.get("result_json"))
        usage = (d.get("_llm_usage") if isinstance(d, dict) else None) or {}
        if isinstance(usage, dict) and (usage.get("tokens_in") or usage.get("tokens_out")):
            b["token_runs"] += 1
            b["tokens_in"] += int(usage.get("tokens_in") or 0)
            b["tokens_out"] += int(usage.get("tokens_out") or 0)
            b["llm_calls"] += int(usage.get("calls") or 0)
    out_agents = []
    for aid in HEALTH_AGENTS:
        b = buckets[aid]
        meta = AGENT_META.get(aid, {})
        failures = sorted(b["failures"].items(), key=lambda kv: (-kv[1], kv[0]))[:5]
        out_agents.append({
            "agent_id": aid,
            "name": names.get(aid) or meta.get("capability") or aid,
            "capability": meta.get("capability", ""),
            "cap": meta.get("cap", ""),
            "runs": b["runs"],
            "success": b["ok"],
            "degraded": b["degraded"],
            "failure": b["fail"],
            "success_rate": (round(b["ok"] / b["runs"], 4) if b["runs"] else None),
            "degraded_rate": (round(b["degraded"] / b["runs"], 4) if b["runs"] else None),
            "p50_ms": _percentile(b["latencies"], 0.50),
            "p95_ms": _percentile(b["latencies"], 0.95),
            "avg_ms": (round(sum(b["latencies"]) / len(b["latencies"])) if b["latencies"] else None),
            "tokens_in": b["tokens_in"],
            "tokens_out": b["tokens_out"],
            "llm_calls": b["llm_calls"],
            "token_runs": b["token_runs"],
            "tokens_attributed": bool(b["token_runs"]),
            "top_failures": [{"reason": k, "count": v} for k, v in failures],
            "last_run_at": b["last_run_at"],
            "first_run_at": b["first_run_at"],
        })
    window_rows = [r for r in rows if r.get("created_at")]
    since = min((str(r.get("created_at")) for r in window_rows), default="")
    until = max((str(r.get("created_at")) for r in window_rows), default="")
    token_runs = sum(a["token_runs"] for a in out_agents)
    return {
        "generated_at": db.now(),
        "agents": out_agents,
        "summary": {
            "limit": limit,
            "runs_scanned": len(rows),
            "runs_total": total_runs,
            "unregistered_runs": unregistered,
            "since": since,
            "until": until,
            "token_attributed_runs": token_runs,
            "token_attribution_rate": (round(token_runs / len(rows), 4) if rows else None),
            "empty_state": not any(a["runs"] for a in out_agents),
        },
        "metrics": {
            "success_rate": "status=ok / 全部运行；degraded（模型不可用/确定性回退）不计成功",
            "latency": "P50/P95 = latency_ms 最近秩分位数（不插值，单位 ms）",
            "tokens": "仅聚合 result_json._llm_usage（L14 起新运行写入）；历史运行无归属不估算",
            "top_failures": "fail/degraded 的 result_json.error/degraded_reason 归一后 Top5",
        },
        "notes": [
            "数据源：agent_run（LEFT JOIN agent_version 取 agent_id）；只读，不写库。",
            f"时间窗：最近 {limit} 条运行（全库 {total_runs} 条）；未登记到 7 智能体的运行 "
            f"{unregistered} 条不计入行但计入扫描数。",
            "tokens 只在 result_json._llm_usage 存在时计入；历史运行没有该字段，"
            "token_runs=0 表示无可归属数据（不是 0 消耗）。",
            "空态：时间窗内无运行记录时 7 行仍返回、指标为 null，前端显示「无数据」而不是健康结论。",
        ],
    }


# 运行期模型失败可吸收的稳定状态（llm_router.classify_error 口径）
_MODEL_FAIL_STATES = ("rate_limited", "unauthorized", "model_not_found", "payment_required",
                      "upstream_error", "timeout", "http_error", "forbidden", "external_denied")


def _classify_runtime_failure(text: str) -> str:
    try:
        from ..engine import llm_router as _lr
        return str(_lr.classify_error(RuntimeError(str(text or ""))) or "")
    except Exception:
        logging.getLogger(__name__).debug("classify runtime failure skipped", exc_info=True)
        return ""


def _writeback_model_runtime_failure(model_refs, state: str, detail: str) -> None:
    """运行期真实失败回写模型四态 status='fail'，避免「已配置待测」掩盖 429/401/超时。

    只回写状态列（model_config 无 last_error 列）：失败原因随 agent_run.result_json
    与节点轨迹可查，不新增列、不做数据迁移。
    """
    try:
        with db.session() as c:
            updated = 0
            for ref in dict.fromkeys(str(x) for x in (model_refs or []) if x):
                rows = c.execute(
                    "SELECT id FROM model_config WHERE id=? OR model_id=? OR name=?",
                    (ref, ref, ref)).fetchall()
                for row in rows:
                    c.execute("UPDATE model_config SET status='fail' WHERE id=?", (row["id"],))
                    updated += 1
            if not updated:
                # 2026-11-21：节点/版本未绑定具体模型引用时（refs 为空或都匹配不到行），
                # 失败的其实是**路由当前生效的模型**。按路由 resolved 配置精确定位该行
                # （base_url + model_id），再回退默认模型、最后回退首行；
                # 只在确实无法按引用定位时回退，不放松按引用精确定位的优先级。
                rid = None
                try:
                    from ..engine import llm_router as _lr2
                    _cfg2 = _lr2.resolve() or {}
                    _b = str(_cfg2.get("base_url") or "").strip()
                    _m = str(_cfg2.get("model") or "").strip()
                    if _b and _m:
                        _hit = c.execute(
                            "SELECT id FROM model_config WHERE base_url=? AND model_id=? "
                            "ORDER BY rowid LIMIT 1", (_b, _m)).fetchone()
                        rid = _hit["id"] if _hit else None
                except Exception:  # noqa: BLE001
                    rid = None
                row = (c.execute("SELECT id FROM model_config WHERE id=? LIMIT 1",
                                 (rid,)).fetchone() if rid else None) or c.execute(
                    "SELECT id FROM model_config WHERE is_default=1 ORDER BY id LIMIT 1"
                ).fetchone() or c.execute(
                    "SELECT id FROM model_config ORDER BY rowid LIMIT 1").fetchone()
                if row:
                    c.execute("UPDATE model_config SET status='fail' WHERE id=?", (row["id"],))
                    logging.getLogger(__name__).info(
                        "model runtime failure writeback：按引用未定位到模型，回退标记默认模型 id=%s",
                        row["id"])
            c.commit()
    except Exception:
        logging.getLogger(__name__).warning(
            "model runtime failure writeback failed state=%s detail=%s",
            state, str(detail)[:120], exc_info=True)


def _upflow_node_failures(result, status: str, runtime: dict | None = None,
                          trace: list | None = None) -> str:
    """节点级失败上卷：模型节点 failed 时 run 不许仍记 ok（限流 429 成功率虚高）。

    - status=ok 且存在 failed 节点 → degraded，并写真实 degraded_reason；
    - 失败原因按 llm_router.classify_error 分类，429/401/超时按模型回写四态 fail。
    """
    if not isinstance(result, dict):
        return status
    if trace is None:
        trace = result.get("_node_trace") or []
    failed = [t for t in trace if str(t.get("status") or "") == "failed"]
    # 判定类 runner 把模型异常吞成逐条「执行失败」结果（error=true）而不是节点 failed，
    # 这里同口径上卷：否则 429/401 仍然会把整次运行记成 ok（成功率虚高）。
    error_items = [r for r in (result.get("results") or [])
                   if isinstance(r, dict) and (r.get("error") is True
                                               or str(r.get("state") or "") == "执行失败")]
    if not failed and not error_items:
        return status
    if status == "ok":
        status = "degraded"
    reason = str((failed[0].get("error") if failed else "")
                 or (error_items[0].get("rationale") if error_items else "")
                 or (failed[0].get("name") if failed else "") or "模型判定失败")
    if error_items:
        result["error_results"] = len(error_items)
        result["error_sample"] = str(error_items[0].get("rationale") or "")[:200]
    result["degraded"] = True
    if not str(result.get("degraded_reason") or "").strip():
        result["degraded_reason"] = ("节点失败：" + reason)[:300]
    result["failed_nodes"] = [{"id": str(t.get("id") or ""), "name": str(t.get("name") or ""),
                               "type": str(t.get("type") or ""),
                               "error": str(t.get("error") or "")[:200]} for t in failed]
    refs = []
    try:
        rt = ((runtime or {}).get("_runtime") or {})
        refs = [str(x) for x in [rt.get("model")] +
                list((rt.get("node_models") or {}).values()) if x]
    except Exception:
        refs = []
    state = _classify_runtime_failure(reason)
    # 2026-11-21：原条件是 `and refs`，导致「节点/版本没有显式模型引用」时（包内模式无 .env
    # 的默认路径就是这样）写回永远不执行 → 运行期 429 之后模型四态仍显示「已配置待测」。
    # refs 为空时由 _writeback_model_runtime_failure 内部按「路由 resolved 配置 → 默认模型 →
    # 首行」回退定位，因此这里不再用 refs 作为前置条件。
    if state in _MODEL_FAIL_STATES:
        _writeback_model_runtime_failure(refs, state, reason)
    return status


# ===================== 智能体执行（真实运行） =====================
import re as _re
import time as _time

# ===========================================================================
# L168 · agent_run.result_json：不静默截断，全量结果可审计
#
# 背景（L165 OBS-02）：旧实现 json.dumps(result)[:8000] —— 直接把 JSON 字符串切一半：
#   * 52 个 run 的 result_json 不是合法 JSON，审计/回归无法解析；
#   * judge 319 个逐点 verdict 只能从截断前缀恢复 45 条样本。
#
# 新口径（本模块是 agent_run.result_json 的唯一写入口）：
#   1. 永远写**合法 JSON**，并带 `_result_meta`：schema_version / sha256 / chars / bytes /
#      truncated / stored_chars / max_chars / keys；
#   2. 全量 payload ≤ 上限（默认 256KB，RULEPROOF_AGENT_RESULT_MAX_CHARS 可调）→ 全量入库，
#      truncated=false，hash 可核对（判官 319 点位这类大结果在阈值内直接可审计）；
#   3. 超上限 → 全量 gzip JSON 落 blob（目录 RULEPROOF_AGENT_RESULT_BLOB_DIR，默认临时目录），
#      result_json 只存有界摘要 + 显式 truncated=true + pointer(path/sha256/chars)；
#      blob 写失败时**宁可整段落库也不静默截断**（storage=inline_full_fallback）；
#   4. 旧库历史行（曾被 8000 截断）不迁移、不改写；读取侧 parse_result_json() 兼容解析并标
#      `_legacy_truncated=true`，不伪造完整结果。
# ===========================================================================
AGENT_RESULT_SCHEMA_VERSION = 2
AGENT_RESULT_MAX_CHARS_DEFAULT = 262144
AGENT_RESULT_META_KEY = "_result_meta"
_AGENT_RESULT_MAX_ENV = "RULEPROOF_AGENT_RESULT_MAX_CHARS"
_AGENT_RESULT_BLOB_ENV = "RULEPROOF_AGENT_RESULT_BLOB_DIR"
_RESULT_SUMMARY_BUDGET = 8000
_RESULT_ESSENTIAL_KEYS = ("ok", "error", "count", "agent_mode", "degraded",
                          "degraded_reason", "node_status_summary", "degraded_nodes",
                          "_llm_usage", "workflow_check")
_LEGACY_RESULT_SCAN_KEYS = ("agent_mode", "degraded", "degraded_reason", "error", "count")


def _sha256_json_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


def agent_result_max_chars() -> int:
    """result_json 全量入库上限（默认 256KB；最小 4096，避免误配置成 0 导致永久 blob）。"""
    try:
        v = int(str(os.environ.get(_AGENT_RESULT_MAX_ENV) or "").strip() or
                AGENT_RESULT_MAX_CHARS_DEFAULT)
    except Exception:  # noqa: BLE001 - 非法配置回落默认值
        v = AGENT_RESULT_MAX_CHARS_DEFAULT
    return max(4096, v)


def agent_result_blob_dir() -> str:
    """超限结果 blob 目录：显式 env > <临时目录>/ruleproof_agent_results。"""
    try:
        d = str(os.environ.get(_AGENT_RESULT_BLOB_ENV) or "").strip()
    except Exception:  # noqa: BLE001
        d = ""
    return d or os.path.join(tempfile.gettempdir(), "ruleproof_agent_results")


def parse_result_json(raw) -> dict:
    """解析 agent_run.result_json（兼容 L168 之前被 8000 字符截断的历史行）。

    - 新行：合法 JSON + _result_meta（hash/大小/truncated 标记），直接返回；
    - 旧行：非法 JSON → 返回 {"_legacy_truncated": True, "_raw_chars": N, ...扫描出的关键字段}；
      明确标记「不可完整审计的历史结果」，不伪造完整内容。
    """
    text = str(raw or "").strip()
    if not text:
        return {}
    try:
        v = json.loads(text)
        if isinstance(v, dict):
            return v
        return {"_value": v}
    except Exception:  # noqa: BLE001 - 老库截断行，走容错解析
        pass
    out = {"_legacy_truncated": True, "_raw_chars": len(text)}
    for key in _LEGACY_RESULT_SCAN_KEYS:
        m = _re.search(r'"%s"\s*:\s*("(?:[^"\\]|\\.)*"|true|false|null|-?\d+(?:\.\d+)?)'
                       % _re.escape(key), text)
        if not m:
            continue
        raw_v = m.group(1)
        if raw_v == "null":
            out[key] = None
        elif raw_v in ("true", "false"):
            out[key] = (raw_v == "true")
        elif raw_v.startswith('"'):
            try:
                out[key] = json.loads(raw_v)
            except Exception:  # noqa: BLE001
                out[key] = raw_v.strip('"')
        else:
            try:
                out[key] = int(raw_v) if "." not in raw_v else float(raw_v)
            except Exception:  # noqa: BLE001
                out[key] = raw_v
    return out


def _result_blob_write(run_id: str, full_text: str, sha256: str) -> dict | None:
    """把超限全量结果原子写入 gzip blob；失败返回 None（调用方转 inline 全量，绝不截断）。"""
    try:
        d = agent_result_blob_dir()
        os.makedirs(d, exist_ok=True)
        safe_id = "".join(c if (c.isalnum() or c in "-_.") else "_" for c in str(run_id or ""))[:80]
        safe_id = safe_id or "run"
        path = os.path.join(d, f"{safe_id}-{sha256[:16]}.json.gz")
        data = gzip.compress(str(full_text).encode("utf-8"), compresslevel=3)
        fd, tmp = tempfile.mkstemp(prefix=".tmp_arun_", dir=d)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    logging.getLogger(__name__).debug("agent result blob tmp cleanup skipped",
                                                     exc_info=True)
        return {"kind": "gzip_json", "path": path, "sha256": sha256,
                "chars": len(full_text), "bytes": len(str(full_text).encode("utf-8")),
                "gzip_bytes": len(data), "encoding": "utf-8"}
    except Exception:  # noqa: BLE001 - blob 失败不阻断运行记录，转 inline 全量
        logging.getLogger(__name__).warning("agent result blob write failed run_id=%s", run_id,
                                            exc_info=True)
        return None


def _bounded_result_summary(payload: dict, budget: int = _RESULT_SUMMARY_BUDGET) -> dict:
    """超限结果的有界摘要：小字段保留，大字段只留计数/hash/指针标记（明示被外置）。"""
    summary: dict = {}
    for key, value in (payload or {}).items():
        if key == AGENT_RESULT_META_KEY:
            continue
        try:
            raw = json.dumps(value, ensure_ascii=False, default=str)
        except Exception:  # noqa: BLE001
            raw = str(value)
        if len(raw) <= 600:
            summary[key] = value
            continue
        if isinstance(value, list):
            summary[key] = {"_externalized": True, "type": "list", "count": len(value),
                            "chars": len(raw), "sha256": _sha256_json_text(raw)[:32]}
        elif isinstance(value, dict):
            summary[key] = {"_externalized": True, "type": "dict",
                            "keys": sorted(str(k) for k in value.keys())[:20],
                            "chars": len(raw), "sha256": _sha256_json_text(raw)[:32]}
        else:
            summary[key] = {"_externalized": True, "type": type(value).__name__,
                            "chars": len(raw), "sha256": _sha256_json_text(raw)[:32]}
    if len(json.dumps(summary, ensure_ascii=False, default=str)) <= budget:
        return summary
    # 仍然超预算（大量中等字段）：只保留关键字段 + 外置标记
    out = {k: v for k, v in summary.items() if k in _RESULT_ESSENTIAL_KEYS}
    out["_dropped_keys"] = sorted(str(k) for k in summary.keys()
                                  if k not in _RESULT_ESSENTIAL_KEYS)[:40]
    if len(json.dumps(out, ensure_ascii=False, default=str)) > budget:
        out = {k: v for k, v in out.items() if k in ("ok", "error", "count", "agent_mode",
                                                     "degraded", "degraded_reason")}
    return out


def _finalize_meta_raw(out: dict, meta: dict) -> str:
    """把 meta.stored_chars 收敛成真实落库长度后返回最终 JSON 字符串（最多迭代 4 次）。"""
    out[AGENT_RESULT_META_KEY] = meta
    raw = json.dumps(out, ensure_ascii=False, default=str)
    for _ in range(4):
        if meta.get("stored_chars") == len(raw):
            break
        meta["stored_chars"] = len(raw)
        out[AGENT_RESULT_META_KEY] = meta
        raw = json.dumps(out, ensure_ascii=False, default=str)
    return raw


def serialize_run_result(run_id: str, payload) -> str:
    """序列化 agent_run.result_json：永远合法 JSON；不静默截断；全量 sha256 可核对。"""
    if not isinstance(payload, dict):
        payload = {"result": payload}
    payload = {k: v for k, v in payload.items() if k != AGENT_RESULT_META_KEY}
    try:
        full_text = json.dumps(payload, ensure_ascii=False, default=str)
    except Exception:  # noqa: BLE001 - 不可序列化对象降级为可审计的 repr 摘要
        payload = {"_unserializable": True, "repr": str(payload)[:2000]}
        full_text = json.dumps(payload, ensure_ascii=False)
        logging.getLogger(__name__).warning("agent result unserializable run_id=%s", run_id)
    sha = _sha256_json_text(full_text)
    chars = len(full_text)
    limit = agent_result_max_chars()
    meta = {"schema_version": AGENT_RESULT_SCHEMA_VERSION, "sha256": sha,
            "chars": chars, "bytes": len(full_text.encode("utf-8")),
            "truncated": False, "max_chars": limit,
            "keys": sorted(str(k) for k in payload.keys())[:40]}
    if chars <= limit:
        out = dict(payload)
        raw = _finalize_meta_raw(out, meta)
        if len(raw) > limit:
            # payload 本身在上限内、仅 meta 让它略超：保留全量（不因审计元数据丢结果）
            meta["meta_over_budget"] = True
            raw = _finalize_meta_raw(out, meta)
        return raw
    # 超上限：全量外置 blob；result_json 存有界摘要 + 显式截断/指针标记
    pointer = _result_blob_write(run_id, full_text, sha)
    if pointer is None:
        # fail-open（审计优先）：blob 不可写时整段落库并显式标记，不静默截断
        meta.update({"truncated": False, "storage": "inline_full_fallback",
                     "warn": "blob_unavailable_inline_full"})
        out = dict(payload)
        return _finalize_meta_raw(out, meta)
    summary = _bounded_result_summary(payload)
    meta.update({"truncated": True, "storage": "summary+blob",
                 "stored_chars": 0, "pointer": pointer})
    return _finalize_meta_raw(summary, meta)


def load_externalized_result(result: dict) -> dict | None:
    """按 result_json._result_meta.pointer 读取被外置的全量结果；不可用返回 None。"""
    if not isinstance(result, dict):
        return None
    meta = result.get(AGENT_RESULT_META_KEY) or {}
    ptr = meta.get("pointer") or {}
    path = str(ptr.get("path") or "")
    if not meta.get("truncated") or not path or not os.path.isfile(path):
        return None
    try:
        with gzip.open(path, "rt", encoding="utf-8") as f:
            full_text = f.read()
        if ptr.get("sha256") and _sha256_json_text(full_text) != ptr.get("sha256"):
            logging.getLogger(__name__).warning("agent result blob sha256 mismatch path=%s", path)
            return None
        return json.loads(full_text)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning("agent result blob read failed path=%s", path,
                                            exc_info=True)
        return None


def _record_run(agent_id: str, status: str, latency_ms: int, result: dict, case_id: str = "",
                version_id: str = "", llm_usage: dict | None = None) -> str:
    rid = db.new_id("arun")
    try:
        # L108：运行归属只认「唯一生效版本」，不再用 list 第一行（旧实现无排序，
        # 多条 published 时会把 run 记到任意历史版本上）。
        _eff = effective_version(agent_id) or {}
        vid = version_id or str(_eff.get("id") or "")
        # L14 A1：把本次运行的模型用量（tokens/调用数）写进 agent_run.result_json，
        # 供 /api/v1/agents/health 从 agent_run 单表可聚合（历史运行无该字段，不估算）。
        _payload = dict(result) if isinstance(result, dict) else {"result": result}
        if llm_usage:
            _payload = {"_llm_usage": llm_usage, **_payload}
        _raw = serialize_run_result(rid, _payload)
        with db.session() as c:
            c.execute("INSERT INTO agent_run(id,agent_version_id,case_id,status,cost,latency_ms,result_json,created_at) "
                      "VALUES(?,?,?,?,?,?,?,?)",
                      (rid, vid, case_id or "", status, 0, latency_ms, _raw, db.now()))
    except Exception:
        logging.getLogger(__name__).warning("agent_run 结果落库失败 run_id=%s", rid, exc_info=True)
    return rid


def _record_node_runs(run_id: str, agent_id: str, trace: list) -> None:
    """节点级轨迹落库：input/output 脱敏 + 有界；输入缺失显式标 unavailable（不静默空）。"""
    rows = []
    for n in (trace or []):
        if not isinstance(n, dict):
            continue
        _inp = n.get("input")
        if _inp in (None, {}, ""):
            _inp = {"kind": "unavailable",
                    "note": "该节点未上报输入摘要（不伪造）"}
        rows.append({
            "id": n.get("id", ""), "name": n.get("name", ""), "type": n.get("type", ""),
            "status": str(n.get("status") or "ok"),
            "latency_ms": int(n.get("latency_ms") or 0),
            "error": str(n.get("error") or "")[:300],
            "input": sanitize_node_io(_inp, max_chars=1500, field="input"),
            "output": sanitize_node_io(n.get("output") or {}, max_chars=6000, field="output"),
        })
    _art.record_node_runs(run_id, agent_id, rows)


CAPABILITIES = {
    "judge.points": "semantic",
    "parse.document": "parse",
    "extract.facts": "extract",
    "rule.generate": "rule",
    "conflict.analyze": "conflict",
    "feedback.attribute": "analyze",
    "rule.mine": "rulemine",
}


# ---------------------------------------------------------------------------
# L108 · 智能体版本治理：唯一生效版本（每 agent 同时至多一个 published）
#
# 背景（L106 G4）：旧库 agent_version 158 行里 157 行 status=published，
# 同秒多版本，`_latest_published` 靠 (published_at, version) 兜底排序猜生效版本；
# audit/rollback 无法只凭 status 判断当前生效版本。
#
# 口径：
#   * 生效版本 = status='published' 中确定性最新一条（published_at, version 数字）；
#   * 发布事务：旧 published 全部置 superseded + 插入新 published，同一事务提交；
#     BEGIN IMMEDIATE 让并发发布串行化，任何时刻该 agent 至多一个 published；
#   * 读取路径统一走 effective_version()（本模块唯一入口），不再各写排序；
#   * 历史多条 published 不隐式改写（避免 init_db 悄悄改产品库），由
#     published_versions() 显式暴露 + repair_published_versions() 显式修复。
# ---------------------------------------------------------------------------
def _vnum(version: str) -> tuple:
    import re as _re
    nums = _re.findall(r"\d+", str(version or ""))
    return tuple(int(x) for x in nums[:3]) if nums else (0,)


def _version_sort_key(version: dict) -> tuple:
    return (str((version or {}).get("published_at") or ""),
            _vnum((version or {}).get("version")))


def _all_versions(agent_id: str) -> list:
    try:
        return [dict(r) for r in R.agent_versions.list(
            "agent_id=?", (agent_id,), order="published_at DESC, version DESC")]
    except Exception:
        logging.getLogger(__name__).debug("agent versions read failed agent=%s",
                                          agent_id, exc_info=True)
        return []


def published_versions(agent_id: str) -> list:
    """该智能体全部 status=published 版本（正常 ≤1；旧库可能多条，按生效排序）。"""
    pubs = [r for r in _all_versions(agent_id) if (r.get("status") or "") == "published"]
    pubs.sort(key=_version_sort_key, reverse=True)
    return pubs


def effective_version(agent_id: str) -> dict:
    """唯一生效版本（读取路径唯一入口）。

    - 正常（≤1 published）：直接返回该 published 版本；
    - 旧库多条 published：确定性取最新一条并留 warning（不静默猜、也不在读取时写库）；
    - 无 published：回落最新版本（保持旧行为：草稿/历史库仍可读，不伪造空态）。
    """
    rows = _all_versions(agent_id)
    if not rows:
        return {}
    pubs = [r for r in rows if (r.get("status") or "") == "published"]
    if len(pubs) > 1:
        pubs.sort(key=_version_sort_key, reverse=True)
        logging.getLogger(__name__).warning(
            "agent_version 存在多条 published（legacy 未治理）：agent=%s published=%d，"
            "生效取 %s；请显式执行 repair_published_versions(apply=True)",
            agent_id, len(pubs), pubs[0].get("version"))
        return pubs[0]
    if pubs:
        return pubs[0]
    rows.sort(key=_version_sort_key, reverse=True)
    return rows[0]


def _latest_published(agent_id: str) -> dict:
    """兼容旧名：等同于 effective_version（所有读取路径统一到唯一生效版本）。"""
    return effective_version(agent_id)


def _next_version_from_rows(rows: list) -> str:
    nums = []
    for r in rows or []:
        m = _vnum_root(r.get("version"))
        if m is not None:
            nums.append(m)
    return f"v1.{(max(nums) if nums else 0) + 1}"


def _vnum_root(version: str):
    """解析 ``v1.N`` 的 N；非该形态返回 None（不参与编号递增）。"""
    import re as _re
    m = _re.search(r"^v1\.(\d+)$", str(version or ""))
    return int(m.group(1)) if m else None


def publish_version(agent_id: str, *, profile: dict | None = None, actor: str = "",
                    force: bool = False, model: str = "", source: str = "") -> dict:
    """发布智能体版本（写路径唯一入口，事务化 + 幂等 + 并发安全）。

    返回：
      ok=True  {"ok", "version", "version_id", "superseded", "source"}
      ok=False {"ok", "code": "no_change", "status": 400, "current_version", "version_id"}
      ok=False {"ok", "code": "not_found", "status": 404}
    """
    a = R.agents.get(agent_id)
    if not a:
        return {"ok": False, "code": "not_found", "status": 404}
    prof = dict(profile) if profile is not None else _profile(a)
    prompts = prof.get("prompts_list") or []
    workflow = prof.get("workflow") or []
    params = prof.get("params_list") or []
    stamp = db.now()
    vid = db.new_id("av")
    with db.session() as c:
        # 发布是「读旧 published → 置 superseded → 插新 published」的复合写；
        # IMMEDIATE 先拿写锁，两个并发发布者不会都基于同一旧版本各插一条 published。
        c.execute("BEGIN IMMEDIATE")
        rows = [dict(r) for r in c.execute(
            "SELECT * FROM agent_version WHERE agent_id=? "
            "ORDER BY published_at DESC, rowid DESC", (agent_id,)).fetchall()]
        pubs = [r for r in rows if (r.get("status") or "") == "published"]
        pubs.sort(key=_version_sort_key, reverse=True)
        cur = pubs[0] if pubs else None
        if cur and not force:
            try:
                cur_prompts = json.loads(cur.get("prompt") or "[]")
                cur_tools = json.loads(cur.get("tools_json") or "{}")
            except Exception:  # noqa: BLE001 - 旧数据不可解析时按「有变更」处理
                cur_prompts, cur_tools = object(), {}
            if (isinstance(cur_prompts, list) and cur_prompts == prompts
                    and (cur_tools.get("workflow") or []) == workflow
                    and (cur_tools.get("params") or []) == params):
                return {"ok": False, "code": "no_change", "status": 400,
                        "current_version": str(cur.get("version") or ""),
                        "version_id": str(cur.get("id") or "")}
        ver = _next_version_from_rows(rows)
        superseded = 0
        if pubs:
            cur_rows = c.execute(
                "UPDATE agent_version SET status='superseded' "
                "WHERE agent_id=? AND status='published'", (agent_id,))
            superseded = max(0, int(cur_rows.rowcount or 0))
        ver_model = str(model or (cur or {}).get("model") or "")
        c.execute(
            "INSERT INTO agent_version(id,agent_id,version,prompt,model,tools_json,"
            "published_at,status) VALUES(?,?,?,?,?,?,?,'published')",
            (vid, agent_id, ver,
             json.dumps(prompts, ensure_ascii=False), ver_model,
             json.dumps({"workflow": workflow, "params": params}, ensure_ascii=False),
             stamp))
        c.execute("UPDATE agent SET status='active' WHERE id=?", (agent_id,))
        # 关键写操作审计与业务写同事务（AGENTS 铁律 4）：审计失败 → 事务回滚。
        from . import audit as _audit
        _audit.log_in_tx(c, actor=str(actor or "system"), action="agent.published",
                         object_=agent_id,
                         after=json.dumps({"version": ver, "superseded": superseded,
                                           "source": str(source or "")},
                                          ensure_ascii=False))
    return {"ok": True, "version": ver, "version_id": vid,
            "superseded": superseded, "source": str(source or "")}


def repair_published_versions(agent_id: str = "", *, apply: bool = False,
                              actor: str = "system") -> dict:
    """显式修复旧库「同 agent 多条 published」：只保留生效一条，其余置 superseded。

    不在 init_db 自动执行（避免隐式改产品库）；apply=False 只报告不写库。
    返回 {ok, applied, agents, superseded, detail}；幂等（已是唯一则 superseded=0）。
    """
    out = {"ok": True, "applied": bool(apply), "agents": 0, "superseded": 0, "detail": []}
    with db.session() as c:
        c.execute("BEGIN IMMEDIATE")
        if agent_id:
            aids = [str(agent_id)]
        else:
            aids = [str(r[0]) for r in c.execute(
                "SELECT DISTINCT agent_id FROM agent_version WHERE status='published'").fetchall()]
        for aid in aids:
            pubs = [dict(r) for r in c.execute(
                "SELECT * FROM agent_version WHERE agent_id=? AND status='published'",
                (aid,)).fetchall()]
            pubs.sort(key=_version_sort_key, reverse=True)
            if len(pubs) <= 1:
                continue
            keep = pubs[0]
            drop = pubs[1:]
            out["detail"].append({"agent_id": aid,
                                  "keep": str(keep.get("version") or ""),
                                  "superseded": [str(x.get("version") or "") for x in drop]})
            out["agents"] += 1
            if apply:
                for x in drop:
                    # 只改状态，保留原 published_at（审计/回溯要看到历史发布时间）。
                    c.execute("UPDATE agent_version SET status='superseded' WHERE id=?",
                              (x.get("id"),))
                out["superseded"] += len(drop)
        if apply and out["superseded"]:
            from . import audit as _audit
            _audit.log_in_tx(c, actor=str(actor or "system"),
                             action="agent.version_repaired", object_="agent_version",
                             after=json.dumps({"superseded": out["superseded"],
                                               "agents": out["agents"],
                                               "detail": out["detail"]},
                                              ensure_ascii=False)[:4000])
    return out



def _prompt_list(value):
    return _art.prompt_list(value)


def _runtime_for(agent: dict) -> dict:
    _p = _profile(agent)
    _p["_agent_id"] = agent.get("id", "")
    return _art.runtime_snapshot(_p, _latest_published(agent.get("id", "")) or {})


def run_capability(name: str, payload: dict = None) -> dict:
    """按能力执行：优先用已发布智能体版本，缺失则回落内置实现并标 degraded。

    返回 {ok, degraded, agent_id, version, prompt, payload}
    业务方拿到 prompt/version 后自行执行，或直接调用 run_agent。
    """
    typ = CAPABILITIES.get(name)
    if not typ:
        return {"ok": False, "degraded": True, "reason": f"未注册能力：{name}"}
    agent = None
    try:
        rows = [a for a in R.agents.list() if (a.get("status") or "") == "active"
                and (a.get("type") or "") in (typ, name)]
        agent = rows[0] if rows else None
    except Exception:
        agent = None
    if not agent:
        return {"ok": True, "degraded": True, "agent_id": "", "version": "",
                "prompt": "", "reason": "该能力没有启用中的智能体，使用内置实现"}
    prof = _profile(agent)
    ver = _latest_published(agent["id"])
    pl = _prompt_list(prof.get("prompts_list"))
    prompt = pl[0]["prompt"] if pl else ""
    vp = _prompt_list(ver.get("prompt"))
    if vp:
        prompt = vp[0]["prompt"]
    return {"ok": True, "degraded": False, "agent_id": agent["id"],
            "version": ver.get("version", ""), "prompt": prompt,
            "model": ver.get("model", "")}


DEFAULT_PROMPTS = {
    "extract.facts": (
        "你是事实抽取器。从文本中抽取可核验的结构化事实，只输出 JSON 数组。"
        "每项：{\"object\":\"对象或指标名\",\"param\":\"参数名\",\"value\":数字或字符串,"
        "\"unit\":\"单位\",\"quote\":\"原文片段\"}。不编造，抽不到就给空数组。"
    ),
    "parse.document": (
        "你是文档结构解析器。把给定文本拆成结构化块，只输出 JSON 数组。"
        "每项：{\"type\":\"标题|段落|条款|表格行\",\"index\":序号,\"text\":\"内容\"}。"
        "不改写原文，不补全内容。"
    ),
    "conflict.analyze": (
        "你是规则冲突分析器。输入是若干规则的文本描述，只输出 JSON 数组。"
        "每项：{\"a\":\"规则A\",\"b\":\"规则B\",\"type\":\"互斥冲突|重复冗余|疑似重叠\","
        "\"detail\":\"原因\"}。只有区间无交集才算互斥冲突；完全相同算重复冗余；"
        "单位或作用域不同算疑似重叠。无法判断时不要输出该项。"
    ),
    "judge.points": (
        "你是审核点位判定器。根据给定判据对给定文本做判定，只输出 JSON 数组。"
        "每项：{\"point_id\":\"点位\",\"result\":\"conform|nonconform|concern|not_assessed\","
        "\"reason\":\"依据\",\"quote\":\"原文片段\",\"issue_level\":\"高|中|低|null\"}。"
        "证据不足时 result 必须是 not_assessed，不得猜。"
    ),
    "feedback.attribute": (
        "你是复核反馈归因器。输入是一条复核意见，只输出 JSON 数组。"
        "每项：{\"root_cause\":\"解析|抽取|规则|执行器|证据|人工标注\",\"detail\":\"原因\","
        "\"suggestion\":\"改进动作\"}。"
    ),
    "rule.generate": (
        "你是审核规则提炼器。把用户给的一段规则描述拆成可执行规则。"
        "只输出 JSON 数组，每项必须包含：subject（对象名）、metric（原文里会出现的指标名，"
        "如『采购金额』而不是『单次采购金额』）、op（<= 或 >= 或 =）、value（数字）、"
        "unit（单位，如 万元/元/%）、action（不满足时的结论）、"
        "applicability（适用条件字符串数组，可为空；仅当原文明确限定适用范围时才填，"
        "不要把指标名本身当条件）、exceptions（例外条款字符串数组，可为空）、"
        "clause_items（**条款类规则**必填：原文要求必须出现的条款名称数组，"
        "如「验收标准」「交付期限」「营业执照」；数值类规则给空数组）。"
        "例：『紧急采购除外』→ exceptions:[\"紧急采购\"]。不要解释，不要自然语言断言。"
    ),
}


def execute_capability(name: str, payload: dict = None) -> dict:
    """真正执行能力：取已发布版本提示词与模型，调用模型并解析产出。

    run_capability 只返回“元信息”；本函数才产生业务结果。
    """
    import json as _j
    payload = payload or {}
    import time as _t
    _t0 = _t.time()
    meta = run_capability(name, payload)
    if not meta.get("ok"):
        return {"ok": False, "reason": meta.get("reason", "能力不可用")}
    prompt = meta.get("prompt") or DEFAULT_PROMPTS.get(name, "")
    # 节点级参数：从智能体 profile 读取（温度/超时/重试）
    _params = {}
    try:
        import json as _pj
        from .. import repositories as _R2
        _aid = meta.get("agent_id") or ""
        _row = _R2.agents.list("id=?", (_aid,))
        if _row:
            for kv in (_pj.loads(_row[0].get("profile_json") or "{}").get("params_list") or []):
                _params[str(kv.get("name"))] = kv.get("v")
    except Exception:
        _params = {}
    if not prompt:
        return {"ok": False, "degraded": True, "reason": f"能力 {name} 没有提示词，且无内置默认"}
    try:
        from ..engine import llm, llm_router
        cfg = llm_router.resolve()
        if not cfg.get("enabled") or not cfg.get("api_key"):
            return {"ok": False, "degraded": True,
                    "reason": "未配置可用模型（DB/环境均无 key），智能体未执行"}
        model = meta.get("model") or cfg.get("model") or ""
        question = payload.get("text") or payload.get("content") or ""
        raw = llm.chat_completion(cfg["base_url"], cfg["api_key"], model,
                                 [{"role": "system", "content": prompt},
                                  {"role": "user", "content": question}],
                                 timeout=int(float(_params.get("timeout_seconds") or 90)),
                                 max_tokens=int(float(_params.get("max_tokens") or 1200)),
                                 temperature=float(_params.get("temperature") or 0))
        items = None
        try:
            body = raw[raw.index("["): raw.rindex("]") + 1]
            items = _j.loads(body)
        except Exception:
            items = None
        result = {"ok": True, "degraded": bool(meta.get("degraded")), "agent_id": meta.get("agent_id", ""),
                  "version": meta.get("version", ""), "model": model,
                  "count": len(items or []), "items": items, "raw": raw[:1500]}
        # 运行记录：此前 agent_run 恒为 0 行，无法证明「被调用过」
        try:
            _ver = _latest_published(meta.get("agent_id") or "")
            if _ver and _ver.get("id"):
                _arun_id = db.new_id("arun")
                R.agent_runs.insert(id=_arun_id, agent_version_id=_ver["id"],
                                    case_id="", status="ok", cost=0.0,
                                    latency_ms=int((_t.time() - _t0) * 1000),
                                    result_json=serialize_run_result(
                                        _arun_id, {"count": len(items or [])}),
                                    created_at=db.now())
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        return result
    except Exception as e:  # noqa
        return {"ok": False, "reason": f"{type(e).__name__}: {str(e)[:160]}"}


CONTRACTS = {
    "parse": {"any": ("path", "document_id"), "error": "缺少 path 或 document_id"},
    "extract": {"all": ("text",), "error": "缺少 text"},
    "rule": {"all": ("text",), "error": "缺少 text（制度/标准片段）"},
    "conflict": {},
    "semantic": {"all": ("points",), "error": "缺少 points（待判定点位）"},
    "analyze": {},
}


def validate_payload(typ: str, payload: dict) -> str:
    c = CONTRACTS.get(typ) or {}
    if c.get("all") and not all(payload.get(k) for k in c["all"]):
        return c.get("error") or "输入不完整"
    if c.get("any") and not any(payload.get(k) for k in c["any"]):
        return c.get("error") or "输入不完整"
    return ""


def _begin_agent_llm_trace(llm_engine, agent_id: str) -> bool:
    """L14 A1：无外层 trace 时为本次智能体运行开独立 trace，用于 tokens 归属。

    有外层 trace（project.audit 主链）时**不接管**：否则会偷走主链的 llm_trace 落库/归因。
    返回 True 表示本次运行拥有 trace，结束时必须调用 ``_end_agent_llm_trace``。
    """
    try:
        if getattr(llm_engine, "_TRACE").get() is not None:
            return False
        llm_engine.begin_trace({"source": "agent", "agent_id": agent_id})
        return True
    except Exception:
        return False


def _end_agent_llm_trace(llm_engine, owned: bool) -> dict | None:
    """结束本次运行 trace：补落 llm_trace（保持原可观测性）+ 返回 tokens 用量。

    这些调用此前走 ``_persist_orphan_call`` 直接落 llm_trace；被 trace 接管后必须逐条补落，
    否则运维看板「模型调用」会变少。返回 None 表示无可归属调用（确定性运行/失败在模型前）。
    """
    if not owned:
        return None
    try:
        tr = llm_engine.take_trace() or {}
    except Exception:
        return None
    calls = [c for c in (tr.get("calls") or []) if isinstance(c, dict)]
    try:
        from .llm_trace import record_orphan_call
        for c in calls:
            record_orphan_call(c)
    except Exception:
        logging.getLogger(__name__).warning("agent llm_trace replay failed", exc_info=True)
    if not calls:
        return None
    return {"calls": len(calls),
            "tokens_in": sum(int(c.get("tokens_in") or 0) for c in calls),
            "tokens_out": sum(int(c.get("tokens_out") or 0) for c in calls),
            "models": sorted({str(c.get("model") or "") for c in calls if c.get("model")})}


def run_agent(agent_id: str, payload: dict = None, actor: str = "") -> dict:
    """执行智能体：按 type 分派到真实实现，记录运行并返回结果。

    actor：真实操作人（路由传会话 user id）。审计不许把「谁运行的」写成 system。
    """
    a = R.agents.get(agent_id)
    if not a:
        return {"error": "智能体不存在"}
    if (a.get("status") or "") != "active":
        return {"error": "智能体已停用，不进入主链路", "code": "agent_disabled"}
    payload = payload or {}
    typ = a.get("type") or ""
    fn = RUNNERS.get(typ)
    if not fn:
        return {"error": f"该类型智能体暂无可执行实现：{typ}"}
    t0 = _time.time()
    _llm_usage = None
    try:
        _verr = validate_payload(typ, payload)
        if _verr:
            raise ValueError(_verr)
        runtime = _runtime_for(a)
        if isinstance(runtime, dict):
            # L14 A2：agent-judge 只读工具的审计要写真实操作人（不新增参��通道）
            runtime["_actor"] = str(actor or "system")
        from ..engine import llm_router as _lr_agent
        from ..engine import llm as _llm_engine
        _lr_agent.set_agent_model(((runtime.get("_runtime") or {}).get("model") or ""))
        # 无 begin_trace 上下文的调用也会落 llm_trace；stage 标 agent 便于归因
        _llm_engine.set_stage("agent")
        # L14 A1：接管本次运行的模型调用，结束后折算 tokens 写进 agent_run.result_json
        _trace_owned = _begin_agent_llm_trace(_llm_engine, agent_id)
        try:
            result = fn(payload, runtime)
        finally:
            _lr_agent.set_agent_model("")
            _llm_engine.set_stage("未标注")
            _llm_usage = _end_agent_llm_trace(_llm_engine, _trace_owned)
        # L168：节点轨迹从结果里取出（只落 agent_node_run，不在 result_json 重复一份，
        # 这是旧实现 result_json 被 8000 字符截断的主因）。
        _ntrace = result.pop("_node_trace", []) or [] if isinstance(result, dict) else []
        _node_summary = summarize_node_status(_ntrace) if _ntrace else None
        if isinstance(result, dict) and _node_summary:
            result["node_status_summary"] = {
                k: v for k, v in _node_summary.items() if k != "degraded_nodes"}
            if _node_summary.get("degraded_nodes"):
                result["degraded_nodes"] = _node_summary["degraded_nodes"]
        # 先按结果自身标记定状态：error→fail、确定性回退→degraded、其余→ok；
        # 再把节点级失败上卷（429/401 等运行期失败不许仍记 ok）。
        status = "fail" if (isinstance(result, dict) and result.get("error")) else (
            "degraded" if (isinstance(result, dict) and (
                result.get("degraded") or result.get("agent_mode") == "deterministic_fallback"))
            else "ok")
        status = _upflow_node_failures(result, status, runtime, trace=_ntrace)
        # 一致性兜底：节点已如实标 fallback/degraded（模型未真实调用）时 run 不得仍 ok。
        if (status == "ok" and _node_summary
                and _node_summary.get("forced_degraded")):
            status = "degraded"
            if isinstance(result, dict):
                result["degraded"] = True
                _first = (_node_summary.get("degraded_nodes") or [{}])[0]
                if not str(result.get("degraded_reason") or "").strip():
                    result["degraded_reason"] = (
                        "节点降级：%s %s（%s）" % (
                            _first.get("name") or _first.get("id") or "",
                            _first.get("status") or "", _first.get("reason_code") or "")
                    )[:300]
                result["node_level_status_upgraded"] = True
    except Exception as e:  # noqa
        result = {"error": f"{type(e).__name__}: {str(e)[:200]}"}
        status = "fail"
        _ntrace = []
        _node_summary = None
    ms = int((_time.time() - t0) * 1000)
    # 真实操作人：显式 actor > 运行期上下文（嵌套调用继承）> system（仅系统自动化）。
    # 不得把「谁运行的」写成 system（L108 G5）。
    _audit_actor = str(actor or current_actor() or "system")
    _case = str((payload or {}).get("case_id") or "")
    if not _case:
        try:
            from . import ctx as _ctx_agent
            _case = _ctx_agent.get_case()
        except Exception:
            _case = ""
    _dag_check = {"ok": True, "missing": [], "unexpected": [], "order_ok": True,
                  "failed": [], "skipped": [], "covered": 0, "total": 0}
    try:
        from . import agent_dag as _dagm
        _wf = (((runtime or {}).get("_runtime") or {}).get("workflow") or [])
        if _wf:
            _dag_check = _dagm.validate_trace(_wf, _ntrace)
            # 标记 optional 的模型节点由运行时按需执行（未配模型/未触发时不运行），
            # 不算“工作流缺失”，但必须显式列出，不能伪造为已执行。
            _optional = {str(n.get("id") or n.get("name") or "")
                         for n in _wf if n.get("optional")}
            _missing_optional = [x for x in (_dag_check.get("missing") or []) if str(x) in _optional]
            _missing_required = [x for x in (_dag_check.get("missing") or []) if str(x) not in _optional]
            if _missing_optional:
                _dag_check["optional_not_run"] = _missing_optional
            _dag_check["missing"] = _missing_required
            _dag_check["ok"] = (not _missing_required and not _dag_check.get("unexpected")
                                and bool(_dag_check.get("order_ok")))
            if isinstance(result, dict):
                result["workflow_check"] = _dag_check
        # 记录节点轨迹；缺节点/乱序是显式可观测问题，不静默吞掉
        if not _dag_check.get("ok"):
            R.audit_logs.log(actor=_audit_actor, action="agent.workflow_incomplete",
                             object=agent_id,
                             after=json.dumps(_dag_check, ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).debug("dag trace check skipped", exc_info=True)
    # 运行记录与节点轨迹同一份状态口径：先定稿 result（含 workflow_check）再落库。
    rid = _record_run(agent_id, status, ms, result, _case,
                      (runtime or {}).get("_runtime", {}).get("version_id", "")
                      if "runtime" in locals() else "",
                      llm_usage=_llm_usage)
    _record_node_runs(rid, agent_id, _ntrace)
    R.audit_logs.log(actor=_audit_actor, action="agent.run", object=agent_id, after=status)
    if status == "fail":
        try:
            from . import notify as _ntf
            _ntf.notify_system_incident(f"智能体执行失败：{a.get('name') or agent_id}",
                                        str((result or {}).get("error") or "未返回错误详情")[:300])
        except Exception:
            logging.getLogger(__name__).debug('agent fail notify skipped', exc_info=True)
    return {"run_id": rid, "status": status, "latency_ms": ms, "result": result}


REQUIRE_CUES = ("必须约定", "应当约定", "须约定", "必须包含", "应当包含", "须包含",
                "必须提供", "须提供", "应当提供", "必须附", "须附", "必须明确", "须明确")
# 这些主题天然不是数值指标：即使模型给了 value，也应按条款处理
NON_NUMERIC = ("执照", "许可证", "验收", "管辖", "期限", "承诺", "证明", "记录", "报告")


def _clause_slots(text: str, action: str = "") -> dict:
    """把「必须约定 A 与 B」这类非数值规则转成 require_any。"""
    import re as _re
    t = (text or "").strip()
    for cue in REQUIRE_CUES:
        if cue in t:
            body = t.split(cue, 1)[1]
            body = body.replace("的", "").replace("。", "")
            items = [x.strip() for x in _re.split(r"[与和及、,，/]|以及", body) if x.strip()]
            items = [x for x in items if 2 <= len(x) <= 12]
            if items:
                return {"subject": items[0], "require_any": items[:5],
                        "action": (action or "缺少必备条款")[:80]}
    return {}


def _assertion_to_slots(assertion: str, action: str = "") -> dict:
    """把「X <= 10万元」这类断言转成 ruleexec 可执行的 slots。"""
    import re as _re
    m = _re.search(r"(.+?)\s*(<=|>=|≤|≥|<|>|=)\s*([\d.]+)\s*(万元|元|%|％|℃|天|日)?", assertion or "")
    if not m:
        return {}
    metric, op, val, unit = m.group(1).strip(), m.group(2), float(m.group(3)), (m.group(4) or "")
    # 金额：统一归一到元，unit 不再保留“万元”，否则执行器会再乘一次。
    if unit in ("万元", "万"):
        val, unit = val * 10000, "元"
    # 取断言主题的后 4~6 字，提高与原文表述的匹配率（如「单次采购金额」→「采购金额」）
    short = metric[-4:] if len(metric) > 4 else metric
    return {"metric": short, "op": op, "value": val, "unit": unit,
            "action": action[:80]}


def sediment_rules(text: str, publish: bool = True) -> dict:
    """能力①主流程：一段话 → 提炼 → 落规则库（草稿）→ 冲突检测 → 发布。

    返回 {ok, created:[rule_code], conflicts:[...], published:int}
    """
    gen = execute_capability("rule.generate", {"text": text})
    unmatched = []
    try:
        from . import ontology_service as _ontology
        if gen.get("ok") and gen.get("items"):
            names = [str(it.get("metric") or it.get("subject") or "") for it in gen["items"]]
            norm = _ontology.normalize_many([n for n in names if n])
            for it in gen["items"]:
                key = str(it.get("metric") or it.get("subject") or "")
                if key in norm["mapped"]:
                    it["metric"] = norm["mapped"][key]
            unmatched = norm["unmatched"]
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    if not gen.get("ok") or not gen.get("items"):
        return {"ok": False, "reason": gen.get("reason") or "未提炼出规则", "created": []}
    created, conflicts = [], []
    try:
        from . import rule as rule_svc
        from .. import repositories as R
        for it in gen["items"]:
            code = "CUS-" + str(abs(hash(it.get("subject", ""))) % 100000)
            name = (it.get("subject") or "客户规则")[:30]
            desc = it.get("assertion") or ""
            action = it.get("action") or ""
            rid = None
            slots = {}
            _clauses = []   # 关闭：同义归一并未压住误报（FP 3→15），需条款级抽取
            if _clauses:
                slots = {"subject": (it.get("subject") or _clauses[0]),
                         "require_any": _clauses,
                         "action": (action or "缺少必备条款")[:80],
                         "evidence_requirement": (it.get("evidence_requirement") or "")[:80]}
            _topic = f"{it.get('subject') or ''}{it.get('metric') or ''}{desc}"
            _is_text_rule = any(k in _topic for k in NON_NUMERIC)
            if not slots and it.get("metric") and it.get("value") is not None and not _is_text_rule:
                _u = it.get("unit") or ""
                _scale = {"万元": 10000, "万": 10000, "元": 1, "%": 1, "％": 1}.get(_u, 1)
                slots = {"subject": it.get("subject") or it.get("metric"),
                         "metric": str(it["metric"])[-6:], "op": it.get("op") or "<=",
                         "value": float(it["value"]) * _scale, "unit": "元" if _scale == 10000 else _u,
                         "action": (it.get("action") or "")[:80],
                         "applicability": [str(x) for x in (it.get("applicability") or []) if x],
                         "exceptions": [str(x) for x in (it.get("exceptions") or []) if x]}
            if not slots:
                slots = (_clause_slots(desc, action)
                         or _assertion_to_slots(desc, action)
                         or {"require": (desc or "")[:20]})
            try:
                got = rule_svc.create_rule(code=code, name=name, category="客户沉淀",
                                           rclass="semantic",
                                           slots=slots,
                                           source="客户口述")
                rid = got.get("rule_id")
                pub_err = ""
                try:
                    rule_svc.publish(rid)
                except Exception as e:  # noqa
                    pub_err = f"{type(e).__name__}: {str(e)[:80]}"
                    try:
                        R.rules.update(rid, status="published")
                    except Exception:
                        logging.getLogger(__name__).debug('ignored', exc_info=True)
            except Exception as e:
                rid = None
            if not rid:
                continue
            created.append({"code": code, "name": name, "assertion": desc, "action": action})
        try:
            from . import conflict as conflict_svc
            rows_ = []
            for c in created:
                rr = R.rules.list("code=?", (c["code"],))
                if rr:
                    v = R.rules.latest_version(rr[0]["id"]) or {}
                    try:
                        import json as _jj
                        rr[0] = dict(rr[0]); rr[0]["slots"] = _jj.loads(v.get("slots_json") or "{}")
                    except Exception:
                        logging.getLogger(__name__).debug('ignored', exc_info=True)
                    rows_.append(rr[0])
            report = conflict_svc.analyze_rules(rows_)
            conflicts = report.get("items", report) if isinstance(report, dict) else report
        except Exception as e:
            conflicts = [{"error": f"{type(e).__name__}: {str(e)[:80]}"}]
    except Exception as e:  # noqa
        return {"ok": False, "reason": f"{type(e).__name__}: {str(e)[:120]}", "created": created}
    return {"ok": True, "created": created, "conflicts": conflicts,
            "published": len(created), "model": gen.get("model", ""),
            "unmatched_entities": unmatched}


# ---------------- 智能体资产自愈（重建库后自动补全，避免“看起来有、实际空”）----------------

# ---------------- Agent Runtime：节点级工作流与模型节点提示词 ----------------
# 只有 type=模型 的节点配置提示词；程序/校验节点不伪造提示词。
def _canonical_runtime(spec: dict) -> dict:
    """把静态定义转成 profile 的运行时字段。"""
    return {
        "workflow": [dict(x) for x in (spec.get("workflow") or [])],
        "prompts_list": [dict(x) for x in (spec.get("prompts") or [])],
        "params_list": [{"name": n, "v": v, "type": t, "desc": d}
                        for n, v, t, d in (spec.get("params") or [])],
    }


def _runtime_needs_sync(prof: dict, spec: dict) -> bool:
    """旧库是否需要补 workflow/prompts：缺模型节点（或类型不对）/缺该节点的非空提示词。"""
    if not spec:
        return False
    if int(prof.get("runtime_version") or 0) < 2:
        return True
    by_name = {str(n.get("name") or ""): n for n in (prof.get("workflow") or []) if isinstance(n, dict)}
    for n in spec.get("workflow") or []:
        name = str(n.get("name") or "")
        if str(n.get("type") or "") == "模型":
            cur = by_name.get(name)
            if not cur or str(cur.get("type") or "") != "模型":
                return True
    prompts = _prompt_map(prof.get("prompts_list"))
    for p in spec.get("prompts") or []:
        node = str(p.get("node") or "")
        if node and str(p.get("prompt") or "").strip() and not prompts.get(node):
            return True
    return False


def _merge_runtime(prof: dict, spec: dict) -> None:
    """保留用户已编辑内容，只补缺失的模型节点与提示词（不覆盖非空提示词）。"""
    cur_nodes = {str(n.get("name") or ""): n
                 for n in (prof.get("workflow") or []) if isinstance(n, dict)}
    merged = []
    for n in spec.get("workflow") or []:
        name = str(n.get("name") or "")
        if name in cur_nodes:
            cur = dict(cur_nodes.pop(name))
            # 同名节点但类型不对（如旧库把模型节点存成程序节点）时，以规范类型为准
            if str(cur.get("type") or "") != str(n.get("type") or ""):
                cur["type"] = n.get("type")
                cur["desc"] = cur.get("desc") or n.get("desc") or ""
            merged.append(cur)
        else:
            merged.append(dict(n))
    # 用户自定义的额外节点保留在末尾，不静默删除
    merged.extend(dict(x) for x in cur_nodes.values())
    prof["workflow"] = merged
    cur_prompts = {str(x.get("node") or ""): x
                   for x in (prof.get("prompts_list") or []) if isinstance(x, dict)}
    spec_nodes = {str(p.get("node") or "") for p in spec.get("prompts") or []}
    prompts = []
    for p in spec.get("prompts") or []:
        node = str(p.get("node") or "")
        cur = cur_prompts.get(node)
        # 用户已编辑且非空的提示词优先；系统默认只补缺失
        prompts.append(dict(cur) if (cur and str(cur.get("prompt") or "").strip()) else dict(p))
    for node, cur in cur_prompts.items():
        if node not in spec_nodes:
            prompts.append(dict(cur))
    prof["prompts_list"] = prompts
    if not (prof.get("params_list") or []):
        prof["params_list"] = _canonical_runtime(spec)["params_list"]


def _version_matches_profile(pub: dict, prof: dict) -> bool:
    """已发布版本是否已包含当前 profile 的提示词、工作流与参数（避免重复插版本）。"""
    import json as _j
    try:
        old_prompts = _j.loads(pub.get("prompt") or "[]")
    except Exception:
        old_prompts = []
    if not isinstance(old_prompts, list) or old_prompts != (prof.get("prompts_list") or []):
        return False
    try:
        tools = _j.loads(pub.get("tools_json") or "{}")
    except Exception:
        tools = {}
    return ((tools.get("workflow") or []) == (prof.get("workflow") or [])
            and (tools.get("params") or []) == (prof.get("params_list") or []))


def _next_version(agent_id: str) -> str:
    """下一个版本号（v1.N，按历史最大 N + 1；superseded 行也参与递增）。"""
    rows = R.agent_versions.list("agent_id=?", (agent_id,)) or []
    return _next_version_from_rows([dict(r) for r in rows])


def ensure_agent_assets() -> dict:
    """幂等补齐节点级工作流/提示词/参数/版本。runtime_version=2 为当前运行时规范。

    - 新库：按 AGENT_RUNTIME 建 profile，并给每个智能体发布一条首版；
    - 旧库：缺模型节点/提示词时补 workflow+prompt（保留用户已编辑的非空提示词），
      已一致的版本不重复插入；
    - 程序/校验节点永远不产生提示词。
    """
    import json as _j
    fixed, published, skipped = 0, 0, 0
    for aid in CAP_BY_AGENT:
        rows = R.agents.list("id=?", (aid,))
        if not rows:
            spec0 = AGENT_RUNTIME.get(aid) or {}
            if not spec0:
                continue
            base = _canonical_runtime(spec0)
            prof0 = {"desc": spec0.get("desc", ""), "group": spec0.get("group", "规则"),
                     "tags": spec0.get("tags", []), "responsibility": spec0.get("responsibility", ""),
                     "not_responsibility": spec0.get("not_responsibility", ""),
                     "run_modes": [], "inputs": spec0.get("inputs", []),
                     "outputs": spec0.get("outputs", []),
                     **base,
                     "runtime_version": 2,
                     "nodes": len(base["workflow"]),
                     "prompts": len(_prompt_map(base["prompts_list"])),
                     "params": len(base["params_list"])}
            R.agents.insert(id=aid, name=spec0.get("name") or aid,
                            type=spec0.get("type") or "rulemine",
                            status=spec0.get("status") or "active",
                            profile_json=_j.dumps(prof0, ensure_ascii=False))
            rows = R.agents.list("id=?", (aid,))
            fixed += 1
        if not rows:
            continue
        prof = _j.loads(rows[0].get("profile_json") or "{}")
        spec = AGENT_RUNTIME.get(aid) or {}
        legacy = bool(spec) and int(prof.get("runtime_version") or 0) < 2
        needs_sync = _runtime_needs_sync(prof, spec)
        if needs_sync:
            if legacy:
                # 旧数据没有节点级规范：整体升级到当前规范
                prof.update(_canonical_runtime(spec))
            else:
                _merge_runtime(prof, spec)
            prof["runtime_version"] = 2
            fixed += 1
        elif spec and not prof.get("runtime_version"):
            prof["runtime_version"] = 2
        prof["nodes"] = len(prof.get("workflow") or [])
        prof["prompts"] = len(_prompt_map(prof.get("prompts_list")))
        prof["params"] = len(prof.get("params_list") or [])
        R.agents.update(aid, profile_json=_j.dumps(prof, ensure_ascii=False))
        pub = _latest_published(aid)
        # 版本必须与当前 profile 的 workflow/提示词/参数一致；不一致才补发，一致则不重复插。
        # L108：补发统一走 publish_version（旧 published 置 superseded + 唯一生效语义）。
        if not pub or not _version_matches_profile(pub, prof):
            _res = publish_version(aid, profile=prof, actor="system", model=str(
                (pub or {}).get("model") or "deepseek-chat"), source="ensure_agent_assets")
            if _res.get("ok"):
                published += 1
            else:
                skipped += 1
        else:
            skipped += 1
    return {"profiles_fixed": fixed, "versions_published": published,
            "versions_skipped": skipped, "versions_total": len(R.agent_versions.list())}


def rollback(agent_id: str, version: str = "", actor: str = "") -> dict:
    """回滚：把指定/上一个历史版本重新置为 published，其它 published 置 superseded。

    L108 唯一生效语义：回滚同样走事务，保证回滚后该 agent 仍只有 1 个 published；
    旧实现把当前 published 置 archived，多版本叠加后仍可能残留多条 published。
    审计 actor 使用真实操作人（缺省 system 仅限系统自动化路径）。
    """
    with db.session() as c:
        c.execute("BEGIN IMMEDIATE")
        vers = [dict(r) for r in c.execute(
            "SELECT * FROM agent_version WHERE agent_id=? "
            "ORDER BY published_at DESC, rowid DESC", (agent_id,)).fetchall()]
        if not vers:
            return {"ok": False, "reason": "无版本可回滚"}
        pub = [v for v in vers if (v.get("status") or "") == "published"]
        pub.sort(key=_version_sort_key, reverse=True)
        if version:
            target = next((v for v in vers if str(v.get("version")) == str(version)), None)
        else:
            # 上一个历史版本：优先取已生效版本之外的最新一条（按发布时间）。
            others = [v for v in vers if not pub or v.get("id") != pub[0].get("id")]
            target = others[0] if others else None
        if not target:
            return {"ok": False, "reason": "没有可回滚到的历史版本"}
        if str(target.get("status") or "") == "published" and len(pub) <= 1:
            return {"ok": True, "version": target.get("version"),
                    "version_id": target["id"], "changed": False}
        stamp = db.now()
        c.execute("UPDATE agent_version SET status='superseded' "
                  "WHERE agent_id=? AND status='published' AND id<>?",
                  (agent_id, target["id"]))
        c.execute("UPDATE agent_version SET status='published', published_at=? WHERE id=?",
                  (stamp, target["id"]))
        from . import audit as _audit
        _audit.log_in_tx(c, actor=str(actor or "system"), action="agent.rollback",
                         object_=agent_id,
                         after=json.dumps({"version": target.get("version"),
                                           "version_id": target["id"]},
                                          ensure_ascii=False))
    return {"ok": True, "version": target.get("version"),
            "version_id": target["id"], "changed": True}
