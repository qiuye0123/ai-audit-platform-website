import binascii
import json
import logging
import struct
import tempfile
import zlib

"""模型管理：当前模型配置 + 系统内模型调用点（环节）清单 + 连通性测试。"""
from .. import config, db
from .. import repositories as R
from ..engine import llm

# 系统内模型调用点（环节）——详细区分每一处用到模型的地方
MODEL_POINTS = [
    {"key": "r4_judge", "name": "R4 语义判断（审核复核）", "used": True,
     "desc": "确定性规则找出候选后，由模型判断「成立/不成立/需人工 + 置信度」",
     "endpoint": "/api/v1/reviews（semantic=True 时触发）", "provider": "judge.semantic_judge"},
    {"key": "nl_rule", "name": "自然语言 → 规则生成", "used": True,
     "desc": "把用户审核要求分类到 10 类模板并填槽位（结构化 JSON）",
     "endpoint": "/api/v1/rule/parse、/api/v1/rules", "provider": "llm.chat_completion"},
    {"key": "judge_api", "name": "语义判断调试接口", "used": True,
     "desc": "单条语义判断的在线调试",
     "endpoint": "/api/v1/judge", "provider": "judge.semantic_judge"},
    {"key": "audit_point_semantic", "name": "通用审核点（method=M/C 语义类）", "used": True,
     "desc": "审核点语义执行：先判适用→再判合格→五态",
     "endpoint": "/api/v1/audit-points/execute", "provider": "extract.execute_audit_point"},
    {"key": "fact_extract", "name": "LLM 事实抽取", "used": True,
     "desc": "从工艺文本抽取结构化事实（工序/参数/数值/单位/对象）",
     "endpoint": "主链执行体内（manifest 执行体经 hooks 适配层调用；L110 起无独立 HTTP 入口）",
     "provider": "extract.extract_facts"},
    {"key": "ocr", "name": "扫描件 OCR", "used": False,
     "desc": "扫描件图片识别：主链路百度智能云 Unlimited-OCR-2（千帆 v2 Bearer），"
             "PaddleOCR-VL 备用，视觉模型兜底（DeepSeek-chat 本身不支持图片）",
     "endpoint": "百度 Unlimited-OCR 2 / PaddleOCR-VL / 视觉模型 / RULEPROOF_OCR_CMD", "provider": "外部命令/VLM"},
]


def effective() -> dict:
    """当前真实生效的模型配置来源（DB / ENV / NONE）。"""
    from ..engine import llm_router
    return llm_router.status()


def config_info() -> dict:
    c = config.LLM
    key = c.get("api_key", "")
    masked = (key[:6] + "…" + key[-4:]) if len(key) > 10 else ("已配置" if key else "未配置")
    return {
        "enabled": bool(c.get("enabled")),
        "base_url": c.get("base_url", ""),
        "model": c.get("model", ""),
        "api_key_masked": masked,
        "timeout_seconds": c.get("timeout_seconds", 20),
        "max_tokens": c.get("max_tokens", 512),
    }


def _trace_stats() -> dict:
    """按模型归集真实调用统计；没有调用时返回空统计。"""
    out = {}
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT model, COUNT(*) calls, COALESCE(SUM(tokens_in),0) tin, "
                "COALESCE(SUM(tokens_out),0) tout, COALESCE(AVG(latency_ms),0) lat, "
                "MAX(created_at) last, SUM(CASE WHEN COALESCE(response_text,'')!='' THEN 1 ELSE 0 END) ok "
                "FROM llm_trace GROUP BY model").fetchall()
        for r in rows:
            d = dict(r)
            d["tokens"] = int(d.get("tin") or 0) + int(d.get("tout") or 0)
            d["success"] = int(d.get("ok") or 0)
            d["failure"] = max(0, int(d.get("calls") or 0) - d["success"])
            d["success_rate"] = (d["success"] / d["calls"]) if d.get("calls") else None
            out[str(d.get("model") or "")] = d
    except Exception:
        logging.getLogger(__name__).debug("model trace stats unavailable", exc_info=True)
    return out


def _bound_model(points_map: dict, point: dict, models: list) -> dict:
    """调用点绑定：OCR/视觉优先视觉模型，其余使用默认启用聊天模型。"""
    cap = "ocr" if point.get("key") == "ocr" else "chat"
    if point.get("key") == "ocr":
        cand = [m for m in models if m.get("enabled") and any(c in (m.get("capabilities") or []) for c in ("ocr", "vision"))]
    else:
        cand = [m for m in models if m.get("enabled") and cap in (m.get("capabilities") or [])]
    if not cand:
        return {}
    chosen = next((m for m in cand if m.get("is_default")), cand[0])
    return {"model_id": chosen.get("id"), "model_name": chosen.get("name"), "model_code": chosen.get("model_id")}


def points() -> list:
    models = (list_models().get("items") or [])
    traces = _trace_stats()
    try:
        from ..engine import ocr as _ocr
        _ocr_ready = bool(_ocr.status().get("configured"))
    except Exception:
        _ocr_ready = False
    out = []
    for p in MODEL_POINTS:
        d = dict(p)
        d.update(_bound_model({}, p, models))
        st = traces.get(d.get("model_code") or "") or traces.get(d.get("model_name") or "")
        d["stats"] = st or {"calls": 0, "success": 0, "failure": 0, "success_rate": None, "tokens": 0,
                            "lat": 0, "last": ""}
        d["stats_scope"] = "bound_model"
        if p.get("key") == "ocr":
            d["used"] = _ocr_ready
            d["configured"] = _ocr_ready
            d["status_note"] = "已配置视觉/OCR 模型或外部 OCR" if _ocr_ready else "仅有模型行但未配置密钥；扫描件会显式跳过"
        out.append(d)
    return out


def test_connection() -> dict:
    """发一条最小请求测连通性；未配置/失败返回原因。"""
    c = config.LLM
    if not (c.get("enabled") and c.get("api_key")):
        return {"ok": False, "detail": "未配置模型（RULEPROOF_LLM_*）"}
    try:
        out = llm.chat_completion(c["base_url"], c["api_key"], c["model"],
                                  [{"role": "user", "content": "只回复两个字：正常"}],
                                  c.get("timeout_seconds", 20), 10)
        return {"ok": True, "detail": "连通正常", "reply": (out or "").strip()[:40]}
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"{type(e).__name__}: {e}"}


# ---------------- 多模型管理（模型配置页） ----------------
CAP_LABEL = {"chat": "对话/审核判定", "vision": "视觉理解", "ocr": "图文识别", "embed": "向量化"}

PRESET_MODELS = [
    {"key": "deepseek", "name": "DeepSeek 4.1 Flash", "desc": "文本审核默认模型",
     "provider": "DeepSeek", "model_id": "deepseek-flash", "capabilities": "chat"},
    {"key": "ernie", "name": "文心 5.5 Flash", "desc": "备用文本审核模型",
     "provider": "Baidu Qianfan", "model_id": "ernie-5.5-flash-preview", "capabilities": "chat"},
    {"key": "vision", "name": "视觉理解", "desc": "读取截图、照片、扫描件，按图理解与转写",
     "provider": "DeepSeek", "model_id": "deepseek-flash", "capabilities": "vision"},
    {"key": "ocr", "name": "视觉 OCR（备用）", "desc": "复用视觉模型做纯图片页 OCR；Unlimited-OCR-2/PaddleOCR-VL 不可用时的兜底",
     "provider": "DeepSeek", "model_id": "deepseek-flash", "capabilities": "ocr"},
    # T-58：新接入的专用 OCR 模型。即使 Key 未配置也在模型页展示，
    # 状态由真实 OCR status() 判定；auto_show=True 的预置行由 list_models 幂等补行。
    {"key": "baidu_ocr", "name": "百度智能云 Unlimited-OCR-2",
     "desc": "百度智能云文档解析（Unlimited-OCR 2），扫描件/图片 OCR 主链路；"
             "凭据来自 BAIDU_OCR_BEARER / RULEPROOF_BAIDU_OCR_BEARER 或模型配置，未配置也展示",
     "provider": "百度智能云", "model_id": "Unlimited-OCR-2", "capabilities": "ocr",
     "auto_show": True},
    {"key": "paddle_ocr", "name": "PaddleOCR-VL",
     "desc": "PaddleOCR-VL 异步 Job OCR，百度 Unlimited-OCR 失败时备用；Token 来自环境变量或模型配置，未配置也展示",
     "provider": "PaddlePaddle", "model_id": "PaddleOCR-VL-1.6", "capabilities": "ocr",
     "auto_show": True},
    {"key": "embed", "name": "向量模型", "desc": "用于知识库检索与语义召回（可选）",
     "provider": "本地", "model_id": "local-embed", "capabilities": "embed"},
]


def _mask(key: str) -> str:
    key = key or ""
    return (key[:4] + "…" + key[-4:]) if len(key) > 10 else ("已配置" if key else "未配置")


# ---------------- OCR 预置模型：展示状态 / 幂等补行（T-58） ----------------
_OCR_CRED_HINT = "环境变量或模型配置"
_OCR_PRESET_IDS = {"baidu_ocr": "mdl-baidu-ocr", "paddle_ocr": "mdl-paddle-ocr"}


def _ocr_engine_status() -> dict:
    """真实 OCR 引擎状态（只读探测，不发起识别、不读取密钥明文）。"""
    try:
        from ..engine import ocr as _ocr_engine
        return _ocr_engine.status() or {}
    except Exception:
        logging.getLogger(__name__).debug("ocr status unavailable", exc_info=True)
        return {}


def _ocr_family(provider: str, model_id: str) -> str:
    """按 provider/model_id 归类 OCR 通道：baidu / paddle / vision（旧视觉/千帆 OCR）。"""
    text = f"{provider or ''} {model_id or ''}".strip().lower()
    if "paddle" in text:
        return "paddle"
    if ("unlimited" in text or "textmind" in text
            or "baidu-unlimited" in text or "baidu-doc" in text):
        return "baidu"
    return "vision"


def _is_ocr_model(m: dict) -> bool:
    """是否 OCR 能力模型：capabilities 含 ocr，或 provider/model_id 命中 OCR 标识。"""
    if "ocr" in (m.get("capabilities") or []):
        return True
    text = f"{m.get('provider') or ''} {m.get('model_id') or ''}".strip().lower()
    return any(k in text for k in ("ocr", "unlimited", "paddle", "textmind"))


def _ocr_presets() -> list:
    return [p for p in PRESET_MODELS if p.get("auto_show") and p.get("capabilities") == "ocr"]


def _preset_configured(preset: dict, ost: dict) -> bool:
    fam = _ocr_family(preset.get("provider", ""), preset.get("model_id", ""))
    if fam == "baidu":
        return bool(ost.get("has_baidu"))
    if fam == "paddle":
        return bool(ost.get("has_paddle"))
    return bool(ost.get("has_vision"))


def _ocr_preset_mid(preset: dict) -> str:
    return (_OCR_PRESET_IDS.get(preset.get("key") or "")
            or ("mdl-" + str(preset.get("key") or "ocr").replace("_", "-")))


def _insert_ocr_preset_row(preset: dict, mid: str, ost: dict) -> bool:
    """插入一条 OCR 预置配置行（不写密钥）；返回是否真的插入。幂等靠 INSERT OR IGNORE。"""
    status = "unknown" if _preset_configured(preset, ost) else "unconfigured"
    try:
        with db.session() as c:
            cur = c.execute(
                "INSERT OR IGNORE INTO model_config(id,name,provider,model_id,base_url,api_key,"
                "capabilities,is_default,enabled,status,created_at) "
                "VALUES(?,?,?,?,?,'',?,0,1,?,?)",
                (mid, preset.get("name") or "", preset.get("provider") or "",
                 preset.get("model_id") or "", preset.get("base_url") or "",
                 preset.get("capabilities") or "ocr", status, db.now()))
            return bool(cur.rowcount)
    except Exception:
        logging.getLogger(__name__).warning(
            "OCR 预置模型补行失败：key=%s", preset.get("key"), exc_info=True)
        return False


def _retire_legacy_ocr_rows() -> None:
    """旧版「千帆 DeepSeek-OCR」预置行迁移：未配置密钥的删除；已配置的标记旧模型并停用。

    只在读取模型列表时做一次性清理（现有逻辑本来就会幂等补 OCR 行），不覆盖人工新配置。
    """
    try:
        with db.session() as c:
            c.execute("DELETE FROM model_config WHERE "
                      "(id IN ('mdl-ocr','mdl-qianfan-ocr') OR name LIKE '%DeepSeek-OCR%') "
                      "AND COALESCE(model_id,'') NOT LIKE '%Unlimited%' "
                      "AND COALESCE(provider,'') NOT LIKE '%unlimited%' "
                      "AND (api_key IS NULL OR TRIM(api_key)='')")
            c.execute("UPDATE model_config SET name='旧 OCR 模型（建议改用 Unlimited-OCR-2）', enabled=0, status='unconfigured' "
                      "WHERE (id IN ('mdl-ocr','mdl-qianfan-ocr') OR name LIKE '%DeepSeek-OCR%') "
                      "AND COALESCE(model_id,'') NOT LIKE '%Unlimited%' AND COALESCE(provider,'') NOT LIKE '%unlimited%'")
    except Exception:
        logging.getLogger(__name__).debug("legacy ocr row cleanup skipped", exc_info=True)


def _ensure_ocr_model_rows(ost: dict | None = None) -> list:
    """OCR 预置模型不在 model_config 时幂等补一行。

    - 即使 Key 未配置也补行（模型页可见，状态由真实 OCR status() 判定）；
    - 已存在同 provider+model_id（人工配置/旧库行）则跳过，绝不覆盖人工配置；
    - INSERT OR IGNORE + 稳定主键，重复 GET / 并发调用不会重复插入；
    - 只写配置行，不写任何密钥，不写日志明文。
    """
    presets = _ocr_presets()
    if not presets:
        return []
    try:
        rows = [dict(r) for r in R.model_configs.list(order="created_at ASC")]
    except Exception:
        logging.getLogger(__name__).debug("model_config 读取失败，跳过 OCR 补行", exc_info=True)
        return []
    if ost is None:
        ost = _ocr_engine_status()
    known_ids = {str(r.get("id") or "") for r in rows}
    known_keys = {((r.get("provider") or "").strip().lower(),
                   (r.get("model_id") or "").strip().lower()) for r in rows}
    created = []
    for p in presets:
        mid = _ocr_preset_mid(p)
        pkey = ((p.get("provider") or "").strip().lower(),
                (p.get("model_id") or "").strip().lower())
        if mid in known_ids or pkey in known_keys:
            continue
        if _insert_ocr_preset_row(p, mid, ost):
            created.append(mid)
        known_ids.add(mid)
        known_keys.add(pkey)
    if created:
        logging.getLogger(__name__).info("模型页自动补入 OCR 预置行 %d 条（不写密钥）", len(created))
    return created


def _ocr_runtime_hint(fam: str) -> str:
    """OCR 依赖缺失提示（不读密钥）：Key 已配置但引擎不可用时给出可操作原因。"""
    try:
        if fam == "baidu":
            from ..engine import baidu_ocr as _baidu
            if getattr(_baidu, "requests", None) is None:
                return "；运行环境缺少 requests 依赖（pip install -r requirements.txt）"
        elif fam == "paddle":
            from ..engine import paddleocr as _paddle
            try:
                _paddle._requests()
            except Exception:
                return "；运行环境缺少 requests 依赖（pip install -r requirements.txt）"
    except Exception:
        logging.getLogger(__name__).debug("ocr runtime hint unavailable", exc_info=True)
    return ""


def _apply_ocr_status(m: dict, ost: dict, has_row_key: bool) -> None:
    """OCR 行状态：凭据来自环境变量或模型配置，未做真实识别不显示“连接成功”。"""
    fam = _ocr_family(m.get("provider"), m.get("model_id"))
    m["ocr_family"] = fam
    m["credential_source"] = _OCR_CRED_HINT
    if "ocr" not in (m.get("capabilities") or []):
        m["capability_labels"] = list(m.get("capability_labels") or []) + ["图文识别"]
        m["capability_inferred"] = True
    if fam == "baidu":
        configured = bool(ost.get("has_baidu"))
        missing = ("未配置百度 Unlimited-OCR 凭据（千帆 Bearer：BAIDU_OCR_BEARER / "
                   "RULEPROOF_BAIDU_OCR_BEARER，或 API Key+Secret Key；也可在模型配置填写）；"
                   "密钥来源：环境变量或模型配置")
        ready = ("百度 Unlimited-OCR 凭据已配置（千帆 Bearer 或 API Key+Secret，环境变量或模型配置）；"
                 "未做真实识别前不显示“连接成功”")
    elif fam == "paddle":
        configured = bool(ost.get("has_paddle"))
        missing = "未配置 PaddleOCR Token（环境变量 RULEPROOF_OCR_TOKEN 或模型配置）；Token 来源：环境变量或模型配置"
        ready = "PaddleOCR-VL Token 已配置（环境变量或模型配置）；未做真实识别前不显示“连接成功”"
    else:
        configured = bool(has_row_key)
        missing = "该 OCR 行未配置密钥（环境变量或模型配置）"
        ready = "该 OCR 行已配置密钥（环境变量或模型配置）；建议点「测试连接」做真实 OCR 调用"
    if not configured:
        m["status"] = "unconfigured"
        m["status_note"] = missing + _ocr_runtime_hint(fam)
    elif str(m.get("status") or "unknown") == "ok":
        # 旧库/历史状态可能是种子或早期连通性记录：如实标注为数据库记录，
        # 不声称“当前已验证”，请管理员重新测试连接用真实 OCR 调用确认。
        m["status"] = "ok"
        m["status_note"] = ("数据库记录为连接成功（历史/最近一次测试结果）；"
                            "可重新「测试连接」用真实 OCR 调用验证")
    elif str(m.get("status") or "unknown") == "fail":
        m["status"] = "fail"
        m["status_note"] = "最近一次「测试连接」失败；Key 来源：环境变量或模型配置"
    else:
        m["status"] = "configured"
        m["status_note"] = ready


def list_models() -> dict:
    # OCR 预置模型缺失时先幂等补行：旧库（只有旧 mdl-ocr）也能看到新接入的 OCR 模型。
    _retire_legacy_ocr_rows()
    try:
        _ensure_ocr_model_rows()
    except Exception:
        logging.getLogger(__name__).warning("OCR 预置模型补行失败（列表接口继续只读返回）", exc_info=True)
    rows = []
    try:
        rows = [dict(r) for r in R.model_configs.list(order="created_at ASC")]
    except Exception:
        rows = []
    out = []
    for r in rows:
        caps = [c for c in (r.get("capabilities") or "").split(",") if c]
        out.append({
            "id": r["id"], "name": r.get("name", ""), "provider": r.get("provider", ""),
            "model_id": r.get("model_id", ""), "base_url": r.get("base_url", ""),
            "api_key_masked": _mask(r.get("api_key", "")),
            "capabilities": caps,
            "capability_labels": [CAP_LABEL.get(c, c) for c in caps],
            "is_default": bool(r.get("is_default")), "enabled": bool(r.get("enabled")),
            "status": r.get("status") or "unknown", "created_at": r.get("created_at", ""),
            # 仅内部判定“该行是否真的带 Key”，返回前移除；不暴露明文密钥。
            "_has_row_key": bool(str(r.get("api_key") or "").strip()),
        })
    # OCR 的可用性由真实 OCR 配置判定，不沿用创建时的 unknown/ok 状态；
    # 新补的预置行凭据就绪时状态为 configured，只有真实测试连接通过才显示 ok。
    _ost = _ocr_engine_status()
    for m in out:
        _has_row_key = bool(m.pop("_has_row_key", False))
        if _is_ocr_model(m):
            _apply_ocr_status(m, _ost, _has_row_key)
    stats = _trace_stats()
    for m in out:
        st = stats.get(m.get("model_id") or "") or stats.get(m.get("name") or "") or {}
        m["stats"] = {
            "calls": int(st.get("calls") or 0), "success": int(st.get("success") or 0),
            "failure": int(st.get("failure") or 0),
            "success_rate": st.get("success_rate"), "tokens": int(st.get("tokens") or 0),
            "avg_latency_ms": int(st.get("lat") or 0), "last_call": st.get("last") or "",
        }
    return {"items": out, "total": len(out),
            "enabled": sum(1 for x in out if x["enabled"]),
            "connected": sum(1 for x in out if x["status"] == "ok"),
            "configured": sum(1 for x in out if x["status"] in ("ok", "configured")),
            # 四态补充：未配置 / 连接失败 单独计数，页面不再把 enabled 当可用。
            "unconfigured": sum(1 for x in out if x["status"] == "unconfigured"),
            "fail": sum(1 for x in out if x["status"] == "fail"),
            "default_model": next((x["name"] for x in out if x["is_default"]), "")}


# 统一四态：未配置 → 已配置待测 → 连接正常 / 连接失败。
# enabled 只是管理开关，不是可用性；只有真实测试连接通过才认为“连接正常”。
STATE_LABEL = {"unconfigured": "未配置", "configured": "已配置待测",
               "ok": "连接正常", "fail": "连接失败"}
STATE_ORDER = ("ok", "configured", "fail", "unconfigured")
_WORST_FIRST = ("fail", "unconfigured", "configured")


def _brief(m: dict | None) -> dict | None:
    if not m:
        return None
    return {"id": m.get("id"), "name": m.get("name"), "provider": m.get("provider"),
            "model_id": m.get("model_id"), "status": m.get("status"),
            "state": m.get("state"), "state_label": m.get("state_label"),
            "status_note": m.get("status_note") or "",
            "enabled": bool(m.get("enabled"))}


def availability(models=None) -> dict:
    """模型可用性四态汇总（只读；不发起任何真实调用、不读取明文密钥）。

    口径：
    - 未配置：无密钥/无凭据（OCR 由真实 OCR 引擎配置判定）；
    - 已配置待测：有凭据但尚未做真实连接测试，或测试结果未回写；
    - 连接正常：最近一次真实测试连接成功（数据库记录）；
    - 连接失败：最近一次真实测试连接失败。
    ``enabled`` 只是管理开关，不参与“可用”判定，页面必须分开展示。
    """
    lm = {"items": models} if models is not None else list_models()
    items = []
    counts = {"total": 0, "ok": 0, "configured": 0, "fail": 0, "unconfigured": 0,
              "enabled": 0, "effective": 0, "management_enabled": 0}
    for m in lm.get("items") or []:
        st = str(m.get("status") or "").strip()
        has_key = str(m.get("api_key_masked") or "") not in ("", "未配置")
        if st not in STATE_LABEL:
            # 历史 unknown：有密钥=已配置待测；无密钥=未配置；不能当成可用。
            st = "configured" if has_key else "unconfigured"
        elif st == "unconfigured" and has_key and not _is_ocr_model(m):
            # 刚补填 Key 的对话模型行：状态列还没回写，但凭据已就绪 → 已配置待测。
            # OCR 行不套用：OCR 由真实引擎凭据判定（缺 Secret/依赖时仍为未配置）。
            st = "configured"
        d = dict(m)
        d["status"] = st
        d["state"] = st
        d["state_label"] = STATE_LABEL[st]
        d["management_label"] = "管理启用" if m.get("enabled") else "管理停用"
        # 只有真实测试连接成功才算可用；enabled=1 不等于可用。
        d["effective"] = st == "ok"
        items.append(d)
        counts["total"] += 1
        counts[st] += 1
        counts["enabled"] += 1 if m.get("enabled") else 0
        counts["management_enabled"] += 1 if m.get("enabled") else 0
        counts["effective"] += 1 if st == "ok" else 0
    ocr_items = [x for x in items if _is_ocr_model(x)]
    def _fam_of(x):
        return _ocr_family(x.get("provider"), x.get("model_id"))
    primary = next((x for x in ocr_items if _fam_of(x) == "baidu"), None)
    backup = next((x for x in ocr_items if _fam_of(x) == "paddle"), None)
    try:
        _ost = _ocr_engine_status()
    except Exception:
        _ost = {}
    return {
        "items": items,
        "counts": counts,
        "total": counts["total"],
        "state_labels": dict(STATE_LABEL),
        "state_order": list(STATE_ORDER),
        "state_policy": ("未配置=无凭据；已配置待测=有凭据未真实测试；"
                         "连接正常=真实测试连接成功（数据库记录）；连接失败=最近测试失败；"
                         "enabled 只是管理开关，不等于可用"),
        # OCR 主链路（百度 Unlimited-OCR-2）/ 备用（PaddleOCR-VL）：无 Key 时必须显示未配置。
        "ocr": {
            "primary": _brief(primary),
            "backup": _brief(backup),
            "engine_configured": bool(_ost.get("configured")),
            "engine_note": (_ost.get("reason") or "") if isinstance(_ost, dict) else "",
            "policy": "主链路=百度智能云 Unlimited-OCR-2；备用=PaddleOCR-VL；无 Key 显示未配置，不伪造识别成功",
        },
    }


def create_model(name: str, provider: str, model_id: str, base_url: str = "",
                 api_key: str = "", capabilities: str = "chat", is_default: bool = False,
                 actor: str = "") -> dict:
    """新建模型配置。

    ``actor``：真实操作人（HTTP 路由传会话 user sub；CLI 未传时审计记 ``system``）。
    P2-B6-04：审计不得硬编码 ``admin``，否则追责时无法回答“谁改的模型”。
    """
    if not name.strip() or not model_id.strip():
        raise Exception("模型名称和模型 ID 不能为空")
    mid = db.new_id("mdl")
    if is_default or not R.model_configs.list():
        R.model_configs.list()
        try:
            with db.session() as c:
                c.execute("UPDATE model_config SET is_default=0")
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        is_default = True
    R.model_configs.insert(id=mid, name=name.strip(), provider=provider or "", model_id=model_id.strip(),
                           base_url=base_url or "", api_key=api_key or "", capabilities=capabilities or "chat",
                           is_default=1 if is_default else 0, enabled=1, status="unknown", created_at=db.now())
    R.audit_logs.log(actor=str(actor or "system"), action="model.created", object=mid,
                     after=name.strip())
    try:
        from ..engine import llm_router as _lr
        _lr.invalidate()   # 立即生效
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"id": mid}


def update_model(mid: str, actor: str = "", **kw) -> dict:
    """更新模型配置；``actor`` 为真实操作人（P2-B6-04，审计不写死 admin）。"""
    r = R.model_configs.get(mid)
    if not r:
        raise Exception("模型不存在")
    upd = {}
    for k in ("name", "provider", "model_id", "base_url", "capabilities"):
        if kw.get(k) not in (None, ""):
            upd[k] = kw[k]
    if kw.get("api_key"):
        upd["api_key"] = kw["api_key"]
    if kw.get("is_default"):
        try:
            with db.session() as c:
                c.execute("UPDATE model_config SET is_default=0")
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        upd["is_default"] = 1
    if kw.get("enabled") is not None:
        upd["enabled"] = 1 if kw["enabled"] else 0
    if upd:
        R.model_configs.update(mid, **upd)
    R.audit_logs.log(actor=str(actor or "system"), action="model.updated", object=mid)
    try:
        from ..engine import llm_router as _lr
        _lr.invalidate()   # 立即生效
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"id": mid, "updated": list(upd.keys())}


def delete_model(mid: str, actor: str = "") -> dict:
    """删除模型配置；``actor`` 为真实操作人（P2-B6-04，审计不写死 admin）。"""
    r = R.model_configs.get(mid)
    if not r:
        raise Exception("模型不存在")
    try:
        with db.session() as c:
            c.execute("DELETE FROM model_config WHERE id=?", (mid,))
    except Exception as e:  # noqa
        raise Exception("删除失败")
    R.audit_logs.log(actor=str(actor or "system"), action="model.deleted", object=mid)
    try:
        from ..engine import llm_router as _lr
        _lr.invalidate()
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return {"id": mid, "deleted": True}


# ---------------- 测试连接：OCR 走真实 OCR 探测，不复用对话接口 ----------------
_PROBE_PNG_CACHE: dict = {}

# 5x7 点阵字模：让探针图含真实可读文字（OCR 能识别出内容，而不是只有色块）。
_PROBE_FONT = {
    "R": (".###.", "#...#", "#...#", ".###.", "#.#..", "#..#.", "#...#"),
    "U": ("#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    "L": ("#....", "#....", "#....", "#....", "#....", "#....", "#####"),
    "E": ("#####", "#....", "#....", "####.", "#....", "#....", "#####"),
    "P": ("####.", "#...#", "#...#", "####.", "#....", "#....", "#...."),
    "O": (".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    "F": ("#####", "#....", "#....", "####.", "#....", "#....", "#...."),
    "C": (".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."),
    "T": ("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."),
    "S": (".####", "#....", "#....", ".###.", "....#", "....#", "####."),
    "2": (".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"),
    "0": (".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."),
    "6": ("..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."),
    " ": (".....", ".....", ".....", ".....", ".....", ".....", "....."),
}
_PROBE_TEXT = "RULEPROOF OCR TEST 2026"


def _probe_png_bytes() -> bytes:
    """生成一张不含任何密钥的最小 PNG（白底黑字 RULEPROOF OCR TEST 2026）。

    文字用内置 5x7 点阵放大绘制，OCR 真实调用能返回可读文本，用于连通性/识别探针。
    """
    if _PROBE_PNG_CACHE.get("png"):
        return _PROBE_PNG_CACHE["png"]
    scale, margin = 6, 24
    cw, ch = 5 * scale + scale, 7 * scale          # 字宽 + 字距
    width = margin * 2 + cw * len(_PROBE_TEXT)
    height = margin * 2 + ch
    dark = set()
    for i, cha in enumerate(_PROBE_TEXT):
        glyph = _PROBE_FONT.get(cha.upper(), _PROBE_FONT[" "])
        ox = margin + i * cw
        for gy, row in enumerate(glyph):
            for gx, bit in enumerate(row):
                if bit == "#":
                    for dy in range(scale):
                        for dx in range(scale):
                            dark.add((ox + gx * scale + dx, margin + gy * scale + dy))

    def _chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", binascii.crc32(tag + data) & 0xFFFFFFFF))

    raw = bytearray()
    for y in range(height):
        raw.append(0)  # filter type
        for x in range(width):
            raw += b"\x00\x00\x00" if (x, y) in dark else b"\xff\xff\xff"
    png = (b"\x89PNG\r\n\x1a\n"
           + _chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
           + _chunk(b"IDAT", zlib.compress(bytes(raw), 6))
           + _chunk(b"IEND", b""))
    _PROBE_PNG_CACHE["png"] = png
    return png


def _write_probe_png() -> str:
    fd, tmp = tempfile.mkstemp(prefix="rp_ocr_probe_", suffix=".png")
    with open(fd, "wb") as f:
        f.write(_probe_png_bytes())
    return tmp


def _probe_baidu_ocr() -> dict:
    """百度 Unlimited-OCR 真实最小调用（不在日志/页面输出密钥）。

    - 千帆 v2 Bearer：真实 OCR 一张最小文字图，返回识别文本；
    - 旧 OAuth：真实换 access_token；
    - 旧 aip Bearer：真实提交最小任务。
    成功与否由真实调用结果决定，不伪造。
    """
    try:
        from ..engine import baidu_ocr as _baidu
        st = _baidu.status()
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"百度 OCR 模块不可用：{type(e).__name__}"}
    if not st.get("configured"):
        return {"ok": False, "unconfigured": True,
                "detail": (st.get("reason") or "未配置百度 Unlimited-OCR 凭据")
                          + f"；Key 来源：{_OCR_CRED_HINT}"}
    tmp = ""
    try:
        cfg = _baidu._cfg()
        if cfg.get("auth_mode") == "oauth":
            _baidu._token()  # 真实 OAuth 调用：验证 Key/Secret 与网络
            return {"ok": True, "probe": "oauth_token",
                    "detail": "百度 Unlimited-OCR OAuth 鉴权通过（真实 API 调用）；文档识别在上传文件时触发"}
        tmp = _write_probe_png()
        if cfg.get("auth_mode") == "qianfan":
            out = _baidu.run_file(tmp, file_name="rp_ocr_probe.png", timeout_s=180)
            text = (out.get("text") or "").strip()
            if not out.get("ok"):
                return {"ok": False,
                        "detail": "百度 Unlimited-OCR-2 真实调用失败："
                                  + str(out.get("reason") or "未知原因")[:180]}
            return {"ok": True, "probe": "qianfan_ocr_call",
                    "detail": f"百度 Unlimited-OCR-2 真实 OCR 调用成功（最小文字图识别 {len(text)} 字）",
                    "reply": text[:40]}
        _baidu._submit(path=tmp, file_name="rp_ocr_probe.png", timeout=60)
        return {"ok": True, "probe": "task_submit",
                "detail": "百度 Unlimited-OCR 任务提交成功（最小图片，task_id 已返回）"}
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"百度 Unlimited-OCR 调用失败：{type(e).__name__}: {str(e)[:120]}"}
    finally:
        if tmp:
            try:
                import os as _os
                _os.unlink(tmp)
            except Exception:
                logging.getLogger(__name__).debug("probe png cleanup skipped", exc_info=True)


def _probe_paddle_ocr() -> dict:
    """PaddleOCR-VL 真实最小调用：提交一张最小图片任务（验证 Token 与提交端点）。"""
    try:
        from ..engine import paddleocr as _paddle
        st = _paddle.status()
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"PaddleOCR 模块不可用：{type(e).__name__}"}
    if not st.get("configured"):
        return {"ok": False, "unconfigured": True,
                "detail": (st.get("reason") or "未配置 PaddleOCR Token")
                          + f"；Token 来源：{_OCR_CRED_HINT}"}
    try:
        requests = _paddle._requests()
        cfg = _paddle._cfg()
        base = (cfg.get("base_url") or "").rstrip("/")
        job_url = base + "/jobs" if base.endswith("/ocr") else base
        if not job_url.endswith("/jobs"):
            job_url = job_url.rstrip("/") + "/jobs"
        payload = {"useDocOrientationClassify": False, "useDocUnwarping": False,
                   "useChartRecognition": False}
        r = requests.post(job_url, headers={"Authorization": "Bearer " + str(cfg.get("token") or "")},
                          data={"model": cfg.get("model") or "",
                                "optionalPayload": json.dumps(payload, ensure_ascii=False)},
                          files={"file": ("rp_ocr_probe.png", _probe_png_bytes(), "image/png")},
                          timeout=(20, 60))
        if r.status_code != 200:
            return {"ok": False, "detail": f"PaddleOCR 提交失败 HTTP {r.status_code}: {str(r.text or '')[:120]}"}
        job_id = str((((r.json() or {}).get("data") or {}).get("jobId") or ""))
        if not job_id:
            return {"ok": False, "detail": "PaddleOCR 未返回 jobId"}
        return {"ok": True, "probe": "job_submit",
                "detail": "PaddleOCR 任务提交成功（最小图片，job_id 已返回；未轮询识别结果）"}
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"PaddleOCR 调用失败：{type(e).__name__}: {str(e)[:120]}"}


def _probe_vision_ocr_model(row: dict) -> dict:
    """旧视觉/千帆 OCR 行：用该行自己的凭据发真实图片，不复用对话模型 Key。"""
    key = str(row.get("api_key") or "").strip()
    base = str(row.get("base_url") or "").strip()
    model = str(row.get("model_id") or "").strip()
    if not key:
        return {"ok": False, "unconfigured": True,
                "detail": f"该 OCR 行未配置密钥（{_OCR_CRED_HINT}）；不会复用对话模型 Key 冒充 OCR"}
    if not base or not model:
        return {"ok": False, "detail": "该 OCR 行缺少 Base URL 或模型 ID"}
    try:
        out = llm.vision_ocr(_probe_png_bytes(), "image/png",
                             {"base_url": base, "api_key": key, "model": model,
                              "timeout_seconds": 30})
        return {"ok": True, "probe": "vision_image_call",
                "detail": "视觉 OCR 接口连通（最小图片真实调用返回）；识别质量需用真实扫描件验证",
                "reply": (out or "").strip()[:40]}
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"视觉 OCR 调用失败：{type(e).__name__}: {str(e)[:120]}"}


def _is_ocr_row(row: dict) -> bool:
    caps = [c for c in str(row.get("capabilities") or "").split(",") if c]
    return _is_ocr_model({"capabilities": caps, "provider": row.get("provider"),
                          "model_id": row.get("model_id")})


def _test_ocr_model(row: dict) -> dict:
    fam = _ocr_family(row.get("provider"), row.get("model_id"))
    if fam == "baidu":
        out = _probe_baidu_ocr()
    elif fam == "paddle":
        out = _probe_paddle_ocr()
    else:
        out = _probe_vision_ocr_model(row)
    out["family"] = fam
    out["ocr"] = True
    if out.get("unconfigured") and not out.get("detail"):
        out["detail"] = f"未配置密钥（{_OCR_CRED_HINT}）"
    return out


def _test_chat_model(r: dict) -> dict:
    key = r.get("api_key") or config.LLM.get("api_key", "")
    base = r.get("base_url") or config.LLM.get("base_url", "")
    model = r.get("model_id") or config.LLM.get("model", "")
    if not key:
        return {"ok": False, "unconfigured": True, "detail": "未配置 API Key"}
    try:
        out = llm.chat_completion(base, key, model,
                                  [{"role": "user", "content": "只回复两个字：正常"}], 15, 10)
        return {"ok": True, "detail": "连接成功", "reply": (out or "").strip()[:40]}
    except Exception as e:  # noqa
        return {"ok": False, "detail": f"{type(e).__name__}: {str(e)[:120]}"}


def test_model(mid: str = "") -> dict:
    """测试某个模型；不传则测当前环境配置。

    OCR 能力模型必须走真实 OCR 探测（百度/PaddleOCR/视觉 OCR 行自身凭据），
    不得用对话接口或对话模型 Key 冒充 OCR 连通性。
    """
    if not mid:
        return test_connection()
    try:
        _ensure_ocr_model_rows()
    except Exception:
        logging.getLogger(__name__).debug("test_model 前 OCR 补行跳过", exc_info=True)
    r = R.model_configs.get(mid)
    if not r:
        return {"ok": False, "detail": "模型不存在"}
    if _is_ocr_row(r):
        out = _test_ocr_model(r)
    else:
        out = _test_chat_model(r)
    try:
        if out.get("ok"):
            R.model_configs.update(mid, status="ok")
        elif out.get("unconfigured"):
            R.model_configs.update(mid, status="unconfigured")
        else:
            R.model_configs.update(mid, status="fail")
    except Exception:
        logging.getLogger(__name__).debug("模型状态回写失败", exc_info=True)
    return out


def add_preset(key: str, actor: str = "") -> dict:
    """按预置模板添加模型；``actor`` 透传给 create_model / 审计（P2-B6-04）。"""
    p = next((x for x in PRESET_MODELS if x["key"] == key), None)
    if not p:
        raise Exception("未知的预置模型")
    p_cap = str(p.get("capabilities") or "chat")
    p_mid = str(p.get("model_id") or "").strip().lower()
    for r in R.model_configs.list():
        caps = [c for c in str(r.get("capabilities") or "").split(",") if c]
        if (str(r.get("model_id") or "").strip().lower() == p_mid and p_cap in caps):
            # 已在库中（含自动补行/人工配置）：幂等返回，不重复插入、不覆盖人工配置。
            return {"id": r.get("id"), "exists": True, "name": r.get("name", "")}
    if p.get("auto_show") and p_cap == "ocr":
        # 专用 OCR 预置只登记配置行（稳定主键、不写密钥），不复用对话模型 Key；
        # 密钥由环境变量或人工配置提供。
        mid = _ocr_preset_mid(p)
        created = _insert_ocr_preset_row(p, mid, _ocr_engine_status())
        if created:
            R.audit_logs.log(actor=str(actor or "system"), action="model.created", object=mid,
                             after=p.get("name", ""))
            try:
                from ..engine import llm_router as _lr
                _lr.invalidate()
            except Exception:
                logging.getLogger(__name__).debug("llm_router invalidate skipped", exc_info=True)
        row = R.model_configs.get(mid) or {}
        return {"id": mid, "exists": not created, "name": row.get("name") or p.get("name", "")}
    return create_model(p["name"], p["provider"], p["model_id"],
                        config.LLM.get("base_url", ""), config.LLM.get("api_key", ""),
                        p_cap, False, actor=actor)
