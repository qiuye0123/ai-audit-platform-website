# -*- coding: utf-8 -*-
"""Extra 人工复核队列：把机制规则产生的额外 fail 显式交给人工，不自动算 TP。

生产语义：
- expected 仅用于回测/离线评分；生产可传 None。
- 所有机制 fail 默认进入待复核；有 expected 时 extra 单列。
- 不把 extra 静默丢弃，也不把它们自动算成误报/正确。
"""
from __future__ import annotations


def build_queue(results: list[dict], expected: set[str] | None = None) -> dict:
    fails = [x for x in (results or []) if x.get("state") == "fail"]
    expected = set(expected or ())
    extras = [x for x in fails if x.get("code") not in expected] if expected else list(fails)
    items = []
    for x in extras:
        items.append({
            "code": x.get("code") or "",
            "confidence": x.get("confidence"),
            "quote": (x.get("quote") or "")[:240],
            "rationale": (x.get("rationale") or "")[:300],
            "reason": "not_in_expected" if expected else "mechanism_fail",
            "requires_human": True,
            "suggested_action": "确认是否成立；不成立则记 false_positive 并沉淀反例机制",
        })
    return {"ok": True, "total_fail": len(fails), "extra": len(extras),
            "requires_human": len(items), "items": items,
            "note": "extra 不自动判误报；必须人工复核后计入 precision/负例机制"}

def decide(rule_code: str, decision: str, quote: str = "", reason: str = "",
           case_id: str = "", actor: str = "") -> dict:
    """人工裁决一条 extra：confirm 或 false_positive。

    false_positive 会写入 feedback，后续 negative_cards 自动把同机制 fail 转人工。
    """
    code = str(rule_code or "").strip()
    if not code:
        return {"ok": False, "error": "rule_code 不能为空"}
    kind = {"confirm": "confirm", "confirmed": "confirm",
            "false_positive": "false_positive", "false-positive": "false_positive",
            "reject": "false_positive"}.get(str(decision or "").strip().lower())
    if not kind:
        return {"ok": False, "error": "decision 必须是 confirm 或 false_positive"}
    from . import feedback as _fb
    r = _fb.record(case_id=case_id, finding_id="", kind=kind, rule_code=code,
                   title=("Extra 复核确认" if kind == "confirm" else "Extra 复核误报"),
                   payload={"quote": str(quote or "")[:1000], "reason": str(reason or "")[:1000],
                            "source": "extra_review"},
                   actor=actor or "reviewer")
    if r.get("error"):
        return {"ok": False, "error": r["error"]}
    try:
        from .. import repositories as R
        R.audit_logs.log(actor=actor or "reviewer", action="extra.reviewed",
                         object=code, after=f"{kind}:{r.get('feedback_id')}")
    except Exception:
        pass
    return {"ok": True, "rule_code": code, "decision": kind,
            "feedback_id": r.get("feedback_id"), "note": "误报已沉淀为反例卡来源，下次审核生效"}
