# -*- coding: utf-8 -*-
"""机制级规则挖掘：把“具体原句差异”抽象为 机制 + 证据 + 触发条件。

输入是审核点/机制/证据（可来自反馈或标注训练集），
输出是可编译为 RuleIR 的机制规则规格；不把目标原句写进规则。
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Iterable

_STOP = set("的了在和与及或对于以及其中进行是否应当必须需要必须可以本文件原文规定要求检查核对确认".replace(" ", ""))
_TOKEN_RE = re.compile(r"[\u4e00-\u9fa5A-Za-z0-9]{2,12}")


@dataclass
class MechanismSpec:
    point_id: str
    point_name: str
    mechanisms: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    trigger: list[str] = field(default_factory=list)
    check_steps: str = ""
    pass_criteria: str = ""
    applicability: str = ""

    def criterion(self) -> str:
        mech = "；".join(self.mechanisms[:8]) or "该审核点存在需要核对的业务机制"
        ev = "；".join(self.evidence[:8]) or "对应字段、条款或记录"
        tr = "；".join(self.trigger[:6]) or "该审核点适用条件成立"
        extra = ""
        if self.applicability:
            extra += f"适用条件：{self.applicability}。\n"
        if self.check_steps:
            extra += f"核查步骤：{self.check_steps}。\n"
        if self.pass_criteria:
            extra += f"通过判据：{self.pass_criteria}。\n"
        return (f"审核点：{self.point_name}。\n"
                f"机制：{mech}。\n"
                f"证据对象：{ev}。\n"
                f"触发条件：{tr}。\n"
                f"{extra}"
                "判定要求：只依据原文/表格中的证据判断该机制是否成立；"
                "若原文明确出现与机制一致的冲突、缺失、放宽、错配或前后不一致，判 fail；"
                "无法定位证据判 insufficient；不适用判 na；证据完整且符合要求判 pass。"
                "若证据直接显示该机制发生冲突、缺失、放宽或错配，必须判 fail；"
                "不要仅因为文件类型、模板或未显式写出条款就判 na；确实不适用才判 na。")

    def payload(self, code: str = "") -> dict:
        return {
            "code": code or f"MECH-{self.point_id}",
            "name": f"机制规则｜{self.point_name}",
            "category": "completeness",
            "rclass": "R3",
            "point_id": self.point_id,
            "slots": {
                "criterion": self.criterion(),
                "required_evidence": "；".join(self.evidence[:8]) or "对应字段/条款/记录",
                "description": "机制级规则；不绑定具体客户原句",
                "applicable_types": ["md", "pdf", "docx", "xlsx", "xls"],
                "on_insufficient": "abstain",
            },
            "scope": {
                "criterion": self.criterion(),
                "applicable_types": ["md", "pdf", "docx", "xlsx", "xls"],
            },
        }


def _tokens(text: str) -> list[str]:
    out = []
    for x in _TOKEN_RE.findall(str(text or "")):
        x = x.strip()
        if len(x) < 2 or x in _STOP:
            continue
        out.append(x)
    return list(dict.fromkeys(out))


def build_catalog(records: Iterable[dict], evidence_by_point: dict | None = None) -> list[MechanismSpec]:
    """records: [{point_id, point_name, mechanism, evidence?}]；按审核点聚合。"""
    evidence_by_point = evidence_by_point or {}
    groups: dict[str, MechanismSpec] = {}
    for r in records or ():
        pid = str(r.get("point_id") or r.get("审核点") or r.get("audit_point_id") or "").strip()
        if not pid:
            continue
        name = str(r.get("point_name") or r.get("审核点名称") or r.get("audit_point_name") or pid)
        spec = groups.setdefault(pid, MechanismSpec(pid, name))
        mech = str(r.get("mechanism") or r.get("机制") or "").strip()
        if mech and mech not in spec.mechanisms:
            spec.mechanisms.append(mech)
        _evs = r.get("evidence") or evidence_by_point.get(pid) or []
        if isinstance(_evs, str):
            _evs = [_evs]
        for ev in _evs:
            if isinstance(ev, dict):
                ev = ev.get("term") or ev.get("text") or ""
            ev = str(ev).strip()
            if ev and ev not in spec.evidence:
                spec.evidence.append(ev)
        for t in r.get("trigger") or []:
            t = str(t).strip()
            if t and t not in spec.trigger:
                spec.trigger.append(t)
        for key in ("check_steps", "pass_criteria", "applicability"):
            val = str(r.get(key) or "").strip()
            if val and not getattr(spec, key):
                setattr(spec, key, val)
    return list(groups.values())


def route(text: str, specs: list[MechanismSpec], top_k: int = 0) -> list[MechanismSpec]:
    """按目标文本与机制/证据/审核点名称的弱重叠排序；top_k=0 返回全部。

    路由只使用目标文档本身，不使用答案/标签，避免按目标答案选点。
    """
    doc = str(text or "")
    ranked = []
    for i, s in enumerate(specs):
        terms = _tokens(" ".join(s.mechanisms + s.evidence + [s.point_name, s.check_steps, s.pass_criteria]))
        score = sum(1 for t in terms if t in doc)
        # 审核点名称命中额外加分
        if s.point_name and s.point_name in doc:
            score += 2
        ranked.append((score, len(s.mechanisms), -i, s))
    ranked.sort(reverse=True, key=lambda x: (x[0], x[1], x[2]))
    if top_k and top_k > 0:
        return [x[3] for x in ranked[:top_k]]
    return [x[3] for x in ranked]


def load_catalog(path: str) -> list[MechanismSpec]:
    """读取机制目录 JSON；兼容 {items:[...]} 或 [...]. """
    import json
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    items = data.get("items") if isinstance(data, dict) else data
    out = []
    def _ls(v):
        if isinstance(v, str):
            return [z.strip() for z in __import__("re").split(r"[、,，;；/\\s]+", v) if z.strip()]
        return [str(z).strip() for z in (v or []) if str(z).strip()]
    for x in items or []:
        if not isinstance(x, dict):
            continue
        out.append(MechanismSpec(
            point_id=str(x.get("point_id") or ""),
            point_name=str(x.get("point_name") or x.get("point_id") or ""),
            mechanisms=_ls(x.get("mechanisms")),
            evidence=_ls(x.get("evidence")),
            trigger=[str(t) for t in (x.get("trigger") or []) if str(t).strip()],
            check_steps=str(x.get("check_steps") or ""),
            pass_criteria=str(x.get("pass_criteria") or ""),
            applicability=str(x.get("applicability") or ""),
        ))
    return out


def materialize(specs: list[MechanismSpec], publish: bool = False, by: str = "") -> dict:
    """把机制规格写为草稿；publish=True 时走正常发布门禁。不是直接改库。"""
    from . import rule as _rule
    created, failed = [], []
    for s in specs or []:
        if not s.point_id:
            continue
        try:
            got = _rule.create_rule(
                code=s.point_id, name=f"机制规则｜{s.point_name}",
                category="completeness", rclass="R3",
                slots={"criterion": s.criterion(),
                       "required_evidence": "；".join(s.evidence[:8]) or "对应字段/条款/记录",
                       "description": "机制级规则；不绑定具体客户原句",
                       "applicable_types": ["md", "pdf", "docx", "xlsx", "xls"]},
                source="mechanism_mining",
                scope={"applicable_types": ["md", "pdf", "docx", "xlsx", "xls"],
                       "criterion": s.criterion()},
                point_override=s.point_id,
            )
            rid = got.get("rule_id") or ""
            if publish and rid:
                pub = _rule.publish(rid)
                if pub.get("error"):
                    failed.append({"point": s.point_id, "error": pub.get("error")})
                    continue
            created.append({"point": s.point_id, "rule_id": rid})
        except Exception as e:
            failed.append({"point": s.point_id, "error": f"{type(e).__name__}: {e}"})
    return {"ok": not failed, "created": len(created), "failed": len(failed),
            "items": created, "failures": failed[:20], "published": bool(publish)}

def mine_from_feedback(limit: int = 500) -> dict:
    """客户反馈 → 机制候选 + 反例卡；不依赖测试答案，不自动发布。"""
    from .. import db
    rows = []
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT id,finding_id,kind,rule_code,title,payload,created_at FROM feedback "
                "ORDER BY created_at DESC LIMIT ?", (max(1, int(limit)),)).fetchall()]
    except Exception:
        rows = []
    groups = {}
    for r in rows:
        code = str(r.get("rule_code") or "").strip()
        if not code:
            continue
        g = groups.setdefault(code, {"point_id": code, "point_name": r.get("title") or code,
                                     "mechanisms": [], "evidence": [], "pos": 0, "neg": 0,
                                     "last_at": ""})
        title = str(r.get("title") or "").strip()
        if title and title not in g["mechanisms"]:
            g["mechanisms"].append(title)
        if r.get("kind") == "confirm":
            g["pos"] += 1
        elif r.get("kind") in ("false_positive", "manual"):
            g["neg"] += 1
        g["last_at"] = max(g["last_at"], str(r.get("created_at") or ""))
    specs = [MechanismSpec(point_id=g["point_id"], point_name=g["point_name"],
                           mechanisms=g["mechanisms"][:8], evidence=[]) for g in groups.values()]
    return {"ok": True, "source": "feedback", "records": len(rows), "items": [
        {"point_id": g["point_id"], "point_name": g["point_name"], "mechanisms": g["mechanisms"],
         "positive": g["pos"], "negative": g["neg"], "last_at": g["last_at"]}
        for g in groups.values()], "specs": specs,
        "note": "从客户反馈生成机制候选；负向计数用于反例卡，不自动发布"}
