# -*- coding: utf-8 -*-
"""关键信息抽取服务：文档 → 文本 → 字段。"""
from .. import repositories as R
from ..engine import deepparse
from ..engine import keyinfo


def extract_document(document_id: str, doc_type: str = "contract", use_llm: bool = False) -> dict:
    d = R.documents.get(document_id)
    if not d:
        return {"error": "文档不存在"}
    path = d.get("path") or ""
    try:
        parsed = deepparse.parse_and_extract(path)
        text = parsed["doc"].get("text", "")
    except Exception as e:
        return {"error": f"解析失败：{type(e).__name__}"}
    out = keyinfo.extract(text, doc_type=doc_type, use_llm=use_llm)
    out["document_id"] = document_id
    out["filename"] = d.get("filename") or ""
    return out
