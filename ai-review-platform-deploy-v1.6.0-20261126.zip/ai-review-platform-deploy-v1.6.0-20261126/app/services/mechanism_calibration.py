# -*- coding: utf-8 -*-
"""机制规则校准：用真实 confirm/false_positive 反馈决定是否降级/阻断。

安全阈值：
- 至少 MIN_NEG 条负反馈
- confirm 必须为 0（有确认样本时不能一刀切阻断）
- 输出只作用于显式机制点位，普通规则不受影响
"""
from __future__ import annotations
from . import feedback as _feedback

MIN_NEG = 3


def stats(limit: int = 5000) -> dict:
    rows = []
    try:
        rows = _feedback.list_feedback(limit=limit)
    except Exception:
        rows = []
    out = {}
    for r in rows:
        code = str(r.get("rule_code") or "").strip()
        if not code:
            continue
        g = out.setdefault(code, {"rule_code": code, "confirm": 0, "false_positive": 0,
                                  "need_evidence": 0, "manual": 0, "last_at": ""})
        k = str(r.get("kind") or "")
        if k == "confirm": g["confirm"] += 1
        elif k == "false_positive": g["false_positive"] += 1
        elif k == "need_evidence": g["need_evidence"] += 1
        elif k == "manual": g["manual"] += 1
        g["last_at"] = max(g["last_at"], str(r.get("created_at") or ""))
    items = []
    for g in out.values():
        neg = g["false_positive"]
        confirmed = g["confirm"]
        # 拉普拉斯平滑后的准确率，仅用于排序，不直接当生产精度。
        acc = (confirmed + 1.0) / (confirmed + neg + 2.0)
        blocked = neg >= MIN_NEG and confirmed == 0
        items.append({**g, "neg": neg, "smoothed_accuracy": round(acc, 3),
                      "blocked": blocked,
                      "action": "insufficient" if blocked else "keep",
                      "reason": ("负反馈已达阈值且无确认样本" if blocked else
                                 "证据不足，继续观察" if neg else "暂无反馈")})
    items.sort(key=lambda x: (-x["neg"], x["rule_code"]))
    return {"ok": True, "min_neg": MIN_NEG, "total_rules": len(items),
            "blocked": sum(1 for x in items if x["blocked"]), "items": items}


def blocklist() -> dict:
    d = stats()
    return {x["rule_code"]: x for x in d.get("items") or [] if x.get("blocked")}


def apply(results: list[dict], points: list[dict], policy: dict | None = None) -> tuple[list[dict], dict]:
    policy = blocklist() if policy is None else policy
    pmap = {str(p.get("id") or p.get("code") or ""): p for p in (points or [])}
    hit = []
    for r in results or []:
        if r.get("state") != "fail":
            continue
        code = str(r.get("code") or r.get("id") or "")
        p = pmap.get(code) or {}
        if not (p.get("mechanism_gate") or p.get("mechanism_type") or p.get("mechanism_priority")):
            continue
        c = policy.get(code)
        if not c:
            continue
        r["state"] = "insufficient"
        r["gate"] = {"passed": False, "reason": "mechanism_feedback_calibrated",
                     "rule_code": code, "neg": c.get("neg"), "confirm": c.get("confirm")}
        r["rationale"] = (str(r.get("rationale") or "") +
                          f"（反馈校准：该规则负反馈 {c.get('neg')} 条、确认 {c.get('confirm')} 条，转人工复核）").strip()
        hit.append({"code": code, "neg": c.get("neg"), "confirm": c.get("confirm")})
    return results, {"blocked_rules": len(policy), "hit": len(hit), "items": hit[:50]}
