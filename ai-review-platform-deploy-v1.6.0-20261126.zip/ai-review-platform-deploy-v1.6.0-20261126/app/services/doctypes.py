"""客户自定义文档类型：用户自助新增即生效，管理员事后复核。"""
import json
from .. import db
from .. import repositories as R


def create(name: str, aliases=None, audit_types=None, point_ids=None, created_by: str = "") -> dict:
    name = (name or "").strip()
    if not name:
        return {"ok": False, "reason": "类型名称不能为空"}
    code = "DT-C-" + db.new_id("t")[:8]
    tid = db.new_id("dtc")
    R.doc_type_custom.insert(id=tid, code=code, name=name,
                             aliases_json=json.dumps(aliases or [], ensure_ascii=False),
                             audit_types_json=json.dumps(audit_types or [], ensure_ascii=False),
                             point_ids_json=json.dumps(point_ids or [], ensure_ascii=False),
                             status="active", created_by=created_by, created_at=db.now())
    try:
        from . import notify as _n
        _n.notify_admins("type_created", f"新增文档类型待复核：{name}",
                  f"编码 {code}；审核面 {audit_types or '未配置'}；创建人 {created_by or '-'}")
    except Exception:
        pass
    return {"ok": True, "id": tid, "code": code, "name": name}


def list_active() -> list:
    return [dict(r) for r in R.doc_type_custom.list("status=?", ("active",))]


def as_library_entries() -> list:
    out = []
    for r in list_active():
        out.append({"id": r.get("code") or r.get("id"), "name": r.get("name"),
                    "aliases": json.loads(r.get("aliases_json") or "[]"),
                    "default_audit_types": json.loads(r.get("audit_types_json") or "[]"),
                    "custom": True})
    return out


def disable(tid: str) -> dict:
    R.doc_type_custom.update(tid, status="disabled")
    return {"ok": True}


# ---------------- 类型记忆（第 8 项）----------------
def remember(scope: str, scope_id: str, doc_type: str) -> dict:
    """记住本次选择的文档类型（scope=project|user）。"""
    name = (doc_type or "").strip()
    if not name:
        return {"ok": False, "reason": "类型为空"}
    c = db.connect()
    try:
        c.execute("INSERT INTO doc_type_memory(id, scope, scope_id, doc_type, updated_at) "
                  "VALUES(?,?,?,?,?) ON CONFLICT(scope, scope_id) DO UPDATE SET doc_type=?, updated_at=?",
                  (db.new_id("dtm"), scope, scope_id, name, db.now(), name, db.now()))
        c.commit()
        return {"ok": True, "scope": scope, "scope_id": scope_id, "doc_type": name}
    finally:
        c.close()


def recall(scope: str, scope_id: str) -> dict:
    """取上次类型。只要记忆存在就返回（前端可改）；类型是否仍有效单独标记，不吞掉记忆。"""
    c = db.connect()
    try:
        r = c.execute("SELECT doc_type FROM doc_type_memory WHERE scope=? AND scope_id=?",
                      (scope, scope_id or "")).fetchone()
    finally:
        c.close()
    if not r or not r[0]:
        return {"doc_type": "", "source": "none"}
    name = r[0]
    alive = any(x.get("name") == name for x in list_active())
    if not alive:
        try:
            from . import auditpoints as _AP
            alive = any((dt.get("name") or "") == name or name in (dt.get("aliases") or [])
                        for dt in _AP.load().document_types)
        except Exception:
            alive = False
    return {"doc_type": name, "source": "memory", "verified": alive}

