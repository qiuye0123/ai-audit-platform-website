"""变量抽取：把原文里的金额/比例/天数抽成结构化断言需要的键值（纯正则，零模型调用）。"""
import re
import logging

_NUM = r"(\d+(?:\.\d+)?)"
_UNIT = r"(万元|元|%|％|天|日|个月|年|倍)"

# 键 → 触发词（命中后取其后的数字）
PATTERNS = [
    ("累计上限", ["累计责任限额", "累计上限", "累计限额", "责任总限额", "总限额"]),
    ("已支付", ["已赔付", "已支付", "已付", "已收"]),
    ("违约金日费率", ["日率", "日万分之", "每日万分之", "日千分之"]),
    ("押金", ["押金", "保证金"]),
    ("应退金额", ["应退", "退还"]),
    ("已支付", ["已支付", "已付", "已收"]),
    ("应扣", ["应扣", "扣除", "扣减"]),
    ("累计上限", ["累计上限", "累计限额", "责任总限额", "总限额"]),
    ("单次限额", ["单次责任限额", "单次限额", "单项限额", "每次限额", "责任限额"]),
    ("年度剩余限额", ["年度剩余限额", "剩余额度", "剩余限额"]),
    ("已支付", ["已支付", "已付", "已发生"]),
    ("本次支付", ["本次支付", "本次应付", "本次"]),
    ("质保金比例", ["质保金", "质量保证金"]),
    ("预付款比例", ["预付款", "首付款"]),
    ("违约金日费率", ["日万分之", "每日万分之", "日千分之", "每日千分之"]),
    ("逾期天数", ["逾期", "延迟"]),
    ("汇率", ["汇率"]),
    ("原币金额", ["原币", "外币金额", "美元金额"]),
    ("结算金额", ["结算金额", "折合人民币", "人民币金额"]),
]

_UNIT_SCALE = {"万元": 10000, "元": 1, "%": 1, "％": 1, "天": 1, "日": 1, "个月": 30, "年": 365, "倍": 1}


def _find(text: str, cues: list):
    for cue in cues:
        for m in re.finditer(re.escape(cue) + r"[^0-9]{0,8}" + _NUM + r"\s*" + _UNIT + "?", text):
            raw = float(m.group(1))
            unit = m.group(2) or ""
            return raw * _UNIT_SCALE.get(unit, 1), unit
    return None, ""


ALIASES = {
    "已支付": ["已支付额", "已付", "已赔付"],
    "本次支付": ["本次支付额", "本次应付", "本次损失"],
    "累计上限": ["累计责任上限", "责任总限额", "累计责任限额"],
    "单次限额": ["单次责任限额", "单项限额"],
}


def _with_aliases(d: dict) -> dict:
    out = dict(d)
    for key, names in ALIASES.items():
        if key in d:
            for n in names:
                out.setdefault(n, d[key])
    return out


def _ranges_and_dates(text: str, out: dict) -> None:
    """抽区间（80~85℃）与日期（2026-03-05）。"""
    import re as _re
    t = text or ""
    m = _re.search(r"(\d+(?:\.\d+)?)\s*[~～至\-]\s*(\d+(?:\.\d+)?)\s*(℃|°C|%|％|天|日|个月)?", t)
    if m:
        out.setdefault("区间下限", float(m.group(1)))
        out.setdefault("区间上限", float(m.group(2)))
        if m.group(3):
            out.setdefault("区间单位", m.group(3))
    dm = _re.search(r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})", t)
    if dm:
        out.setdefault("日期", f"{dm.group(1)}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}")


def extract(text: str) -> dict:
    """返回 {键: 数值}；万元/元统一折算成元，比例/天数保持原值。

    百分比作用于基数的结构（如「总量为100万的20%」）交给 structured_extract 补。
    """
    out = {}
    for key, cues in PATTERNS:
        val, unit = _find(text or "", cues)
        if val is not None:
            out[key] = val
            out[key + "_单位"] = unit
    try:
        from .structured_extract import (extract_money_items, extract_payment_sum,
                                         extract_penalty_total, extract_ratios)
        out.update(extract_ratios(text or ""))
        out.update(extract_money_items(text or ""))
        out.update(extract_payment_sum(text or ""))
        out.update(extract_penalty_total(text or ""))
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    try:
        from .structured_extract import extract_percent_of_base
        for item in extract_percent_of_base(text or ""):
            out["累计上限"] = item["value"]        # 结构化计算优先于裸正则（基数≠限额）
            out.setdefault("累计上限_来源", f"{item['label']}：{item['base_value']}×{item['pct']}%")
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    _ranges_and_dates(text or "", out)
    return _with_aliases(out)
