"""L1：解析 + 条款切分 + 规则级检索（规则→候选条款），只判相关规则。"""
import json, re
from pathlib import Path
from .. import repositories as R
from . import structure
from .extract import _provider, _chat, _json_of
from .lab_l0 import _doc_text


def _bg(t: str):
    t = "".join(ch for ch in (t or "") if "\u4e00" <= ch <= "\u9fff")
    return {t[i:i + 2] for i in range(len(t) - 1)}


def _rules(limit: int):
    """返回全部已发布规则（不再按列表顺序截断，先全量算相关性再取 topN）。"""
    out = []
    for r in R.rules.list("status=?", ("published",)):
        vs = R.rule_versions.list("rule_id=?", (r["id"],), order="id DESC")
        try:
            slots = json.loads((vs[0].get("slots_json") if vs else "") or "{}")
        except Exception:
            slots = {}
        out.append({"code": r.get("code"), "name": r.get("name") or "",
                    "criterion": str(slots.get("criterion") or r.get("name") or "")[:300]})
    return out


def l1_judge(path: str, limit: int = 20, topk: int = 2, min_score: int = 2) -> dict:
    text = _doc_text(path)
    clauses = structure.segment(text) or [{"id": "C0", "text": text[:4000]}]
    if _provider() is None:
        return {"findings": [], "rules_judged": 0, "rules_skipped": 0, "calls": 0}
    findings, judged, skipped, calls = [], 0, 0, 0
    # 规则级检索：先对全部规则算“与本文档最佳条款重叠分”，再取 topN
    all_rules = _rules(limit)
    def _best(r):
        own = _bg(f"{r['name']} {r['criterion']}")
        return max((len(own & _bg(c["text"])) for c in clauses), default=0)
    ranked = sorted(all_rules, key=_best, reverse=True)
    picked_rules = [r for r in ranked if _best(r) >= min_score][:limit]
    for r in picked_rules:
        own = _bg(f"{r['name']} {r['criterion']}")
        scored = sorted(((len(own & _bg(c["text"])), c) for c in clauses), key=lambda x: -x[0])
        picked = [c for sc, c in scored[:topk] if sc >= min_score]
        if not picked:
            skipped += 1
            continue
        ctx = "\n---\n".join(c["text"][:1200] for c in picked)
        sys_msg = ("你是文件审核器。只依据给出的条款判断该规则是否被违反。输出 JSON 对象："
                   "{\"verdict\":\"fail|pass|na\",\"quote\":\"条款中的逐字片段\",\"reason\":\"一句话\"}。"
                   "quote 必须逐字出现在条款中；找不到依据判 na。")
        user = f"规则：{r['code']} {r['criterion']}\n\n条款：\n{ctx}"
        calls += 1
        try:
            j = _json_of(_chat([{"role": "system", "content": sys_msg},
                                {"role": "user", "content": user}], max_tokens=600))
        except Exception:
            continue
        judged += 1
        if not isinstance(j, dict) or str(j.get("verdict") or "").lower() != "fail":
            continue
        q = str(j.get("quote") or "")
        if q and q not in ctx and re.sub(r"\s+", "", q) not in re.sub(r"\s+", "", ctx):
            continue
        findings.append({"rule_code": r["code"], "point_id": r["code"], "level": "critical",
                         "title": r["name"][:36], "description": j.get("reason") or "",
                         "locations": [{"quote": q}], "state": "不满足", "origin": "customer_rule"})
    return {"findings": findings, "rules_judged": judged, "rules_skipped": skipped, "calls": calls}
