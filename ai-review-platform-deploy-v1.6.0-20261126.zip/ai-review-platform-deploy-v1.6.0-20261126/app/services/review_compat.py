"""兼容入口：旧 /api/v1/reviews、/upload、/demo 统一走项目主链。

入口契约（P0-1）：唯一产品入口是 ``project.audit`` 的 manual / assisted 两模式。
本模块只做传输/参数适配（建项目 + 挂文件 + 显式 ai_assist），不定义第三套
full / legacy 语义：

- ``ai_assist=True``  → assisted
- ``ai_assist=False`` → manual
- ``ai_assist=None``  → assisted（历史兼容默认，不是隐式 full）
- 其它值（含 ``full`` / ``legacy``）→ 直接拒绝

返回值统一经 ``review.normalize_result``，与 review / review_legacy 共享 schema；
完成后写 ``review.completed`` 审计，与 legacy 入口同口径。
"""
from __future__ import annotations


def run_review_api(name: str, doc_paths: list, user: str = "", ai_assist=None,
                   compat_mode: str = "", filenames: list | None = None) -> dict:
    from . import project
    from . import review as _rv
    # 与 review / review_legacy 共享权限口径：admin / 平台身份只读，不能发起审核写
    _rv.assert_entry_writable(user, entry="review_compat")
    assist = _rv.resolve_compat_ai_assist(ai_assist)
    if not doc_paths:
        raise ValueError("缺少 doc_paths")
    pid = project.create(name or "审核任务", user=user or "", description="",
                         audit_type="", focus="", audit_category="", document_type="",
                         compat_mode=compat_mode or "")
    for _i, path in enumerate(doc_paths):
        # 兼容上传接口必须保留客户原始文件名（F11：旧实现用临时文件名落库）
        _fn = str((filenames or [])[_i]) if filenames and _i < len(filenames) else ""
        project.add_document(pid, path, _fn or None)
    out = project.audit(pid, ai_assist=assist)
    mode = "assisted" if assist else "manual"
    out = _rv.normalize_result(out, entry="review_compat", pipeline="project",
                               mode=mode, case_id=pid)
    _rv.log_entry_completion(pid, out["summary"], entry="review_compat",
                             pipeline="project", mode=mode)
    return out
