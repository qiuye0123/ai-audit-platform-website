# -*- coding: utf-8 -*-
"""状态机**单一事实源**（L92，2026-11-24）。

背景：L88 审计（G10–G21）发现规则/版本/项目/finding/报告/任务/通知的状态与迁移
分散在 rule.py / project.py / project_write_routes.py / task.py / semantic_core.py /
review.py 多处；case 可被通用 ``repositories.update`` 任意写坏；7 张核心 status 表
无 DB 兜底；规则迁移矩阵漏 ``restore``（archived→draft 实际合法）。本模块把这些
对象的状态集合、合法迁移、动作→目标状态、遗留别名集中到**唯一 authoring 面**：

- ``RULE_STATES`` / ``RULE_ACTIONS`` / ``RULE_VERSION_*``：``app/services/rule.py`` 从
  这里派生 ``RULE_STATES``/``VERSION_STATES``/``_RULE_TRANSITIONS``/``lifecycle_matrix()``，
  补上 ``restore``（archived/approved/published/draft 可恢复为新草稿；pending 拒绝）。
- ``CASE_STATES`` / ``CASE_ACTIONS``：项目状态机（created/draft/auditing/reviewing/
  completed/audit_failed）；``app/repositories.py`` 对 ``audit_case.status`` 做白名单
  迁移校验（CAS 走 ``BaseRepo.update_status``），任意写 ``corrupt_demo`` 被拒绝。
- ``FINDING_STATES`` / ``FINDING_DECISION_ACTIONS``：finding 五态 + 裁决动作迁移表
  （confirmed/false_positive/need_evidence/ignored/pending/superseded）。
- ``REPORT_STATES`` / ``REPORT_ACTIONS``：报告持久化状态（draft/generated/signed/
  exported/revoked）；``app/db.py`` 幂等给 report 表补 ``status`` 列。
- ``TASK_STATES`` / ``NOTIFICATION_STATES``：异步任务与站内通知（未读/已读）状态。
- ``DB_STATUS_COLUMNS``：7 张核心状态表的 DB 兜底映射（rule/rule_version/audit_case/
  finding/audit_manifest/task_job/report）；``app/db.py`` 据此生成幂等 CHECK 触发器
  （BEFORE INSERT/UPDATE OF status），VALUES 集合 = 规范态 ∪ 遗留别名（保留历史值，
  只拒绝新写入的非法值；既有非法值由 ``_init_state_guard_schema`` 写入
  ``state_legacy_report`` 报告，不静默修改）。
- ``LEGACY_ALIASES``：历史库有 ``failed/error/running/done``（case）、``issued``（report）
  等旧值；读取侧用 ``normalize()`` 归一，写入侧 DB 仍接受（不得破坏历史/夹具）。

设计约束（违反即退化为双事实源）：
1. **只依赖标准库** —— 不 import ``app.*``、不连库。``app/services/rule.py`` /
   ``app/repositories.py`` / ``app/db.py`` 都从这里 import；QA 脚本可按文件路径加载。
2. 新增状态/迁移只改本文件；其他模块不允许再手写一份状态名单。
3. DB 兜底只做「值域」校验（不校验迁移方向），迁移方向由服务层/repository 校验：
   测试夹具常直接 INSERT 目标态（如 status='completed'），DB 若强制迁移方向会破坏
   夹具；值域兜底已足以阻止 ``UPDATE ... SET status='corrupt_demo'`` 写坏。
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# 1) 规则（rule.status）
# ---------------------------------------------------------------------------
RULE_STATES = ("draft", "pending", "approved", "published", "archived")
RULE_LABELS = {
    "draft": "草稿", "pending": "待审批", "approved": "已批准",
    "published": "已发布", "archived": "已下线",
}
# 动作 → 目标状态（唯一 authoring 面；lifecycle_matrix() 的 transitions 由此派生）
RULE_ACTIONS = {
    "draft": {"submit": "pending", "publish": "published", "archive": "archived",
              # restore：从历史版本克隆新草稿；规则本态保持 draft
              "restore": "draft"},
    "pending": {"approve": "approved", "rollback": "draft", "archive": "archived"},
    "approved": {"publish": "published", "rollback": "draft", "archive": "archived",
                 "restore": "draft"},
    "published": {"rollback": "draft", "archive": "archived", "restore": "draft"},
    # G10：archived --restore_version--> draft 是实际合法迁移，旧矩阵漏登记
    "archived": {"restore": "draft"},
}

# ---------------------------------------------------------------------------
# 2) 规则版本（rule_version.status）
# ---------------------------------------------------------------------------
RULE_VERSION_STATES = ("draft", "pending", "approved", "published", "superseded")
RULE_VERSION_LABELS = {
    "draft": "草稿", "pending": "待审批", "approved": "已批准",
    "published": "已发布", "superseded": "已被替代",
}
RULE_VERSION_ACTIONS = {
    "draft": {"submit": "pending", "publish": "published"},
    "pending": {"approve": "approved", "rollback": "draft", "supersede": "superseded"},
    "approved": {"publish": "published", "rollback": "superseded",
                 "supersede": "superseded"},
    "published": {"supersede": "superseded"},
    "superseded": {},
}

# ---------------------------------------------------------------------------
# 3) 审核项目（audit_case.status）
# ---------------------------------------------------------------------------
CASE_STATES = ("created", "draft", "auditing", "reviewing", "completed", "audit_failed")
CASE_LABELS = {
    "created": "已创建", "draft": "草稿", "auditing": "审核中",
    "reviewing": "复核中", "completed": "已完成", "audit_failed": "审核失败",
}
CASE_ACTIONS = {
    "created": {"start": "draft", "audit": "auditing", "review": "reviewing",
                "complete": "completed", "fail": "audit_failed"},
    "draft": {"audit": "auditing", "review": "reviewing",
              "complete": "completed", "fail": "audit_failed"},
    "auditing": {"review": "reviewing", "complete": "completed",
                 "fail": "audit_failed", "retry": "draft"},
    "reviewing": {"review": "reviewing", "complete": "completed",
                  "fail": "audit_failed", "retry": "draft"},
    "completed": {"reaudit": "reviewing", "fail": "audit_failed",
                  "complete": "completed"},
    "audit_failed": {"reaudit": "reviewing", "retry": "draft",
                     "complete": "completed", "fail": "audit_failed"},
}

# ---------------------------------------------------------------------------
# 4) 发现（finding.status）与人工裁决（decision）
# ---------------------------------------------------------------------------
FINDING_STATES = ("pending", "confirmed", "false_positive", "need_evidence",
                  "ignored", "superseded")
FINDING_LABELS = {
    "pending": "待复核", "confirmed": "已确认", "false_positive": "误报",
    "need_evidence": "需补证", "ignored": "已忽略", "superseded": "已被替代",
}
# 裁决动作 → 目标 finding 状态（review.decide / reject_decision / 抑制删除共用）
FINDING_DECISION_ACTIONS = {
    "confirmed": "confirmed",
    "false_positive": "false_positive",
    "need_evidence": "need_evidence",
    "ignored": "ignored",
    "rejected": "pending",
    "reopen": "pending",
    "supersede": "superseded",
}
# 任意已裁决态之间允许改判（confirmed↔false_positive 等），也允许退回 pending；
# superseded 是终态，但补证→语义重判链路会把旧 finding 从 need_evidence/confirmed
# 等状态直接替代，故允许任意状态 → superseded（L94 暴露的 need_evidence→superseded）。
_FINDING_REDECIDE_TARGETS = ("pending", "confirmed", "false_positive",
                             "need_evidence", "ignored")
FINDING_ACTIONS = {}
for _st in FINDING_STATES:
    _FINDING_REDECIDE_TARGETS_FOR_STATE = _FINDING_REDECIDE_TARGETS
    if _st == "pending":
        _targets = {"confirmed", "false_positive", "need_evidence", "ignored",
                    "superseded", "pending"}
    elif _st == "superseded":
        # 已被替代的旧 finding 仍允许重开/改判（补证重判链路会重写 finding），
        # 但 DB/服务层都不会把它写回 superseded 以外的未知态。
        _targets = {"pending", "confirmed", "false_positive", "need_evidence",
                    "ignored", "superseded"}
    else:
        _targets = set(_FINDING_REDECIDE_TARGETS) | {"superseded"}
    FINDING_ACTIONS[_st] = {
        _action: _target
        for _action, _target in FINDING_DECISION_ACTIONS.items()
        if _target in _targets
    }
    if _st in ("pending", "superseded"):
        # 兜底：直接按目标态登记（调用方可能只给目标态）
        for _target in _targets:
            FINDING_ACTIONS[_st].setdefault(_target, _target)
del _st, _targets, _FINDING_REDECIDE_TARGETS, _FINDING_REDECIDE_TARGETS_FOR_STATE

# ---------------------------------------------------------------------------
# 5) 报告（report.status，L92 起持久化；G13）
# ---------------------------------------------------------------------------
REPORT_STATES = ("draft", "generated", "signed", "exported", "revoked")
REPORT_LABELS = {
    "draft": "草稿", "generated": "已生成", "signed": "已签发",
    "exported": "已导出", "revoked": "已撤销",
}
REPORT_ACTIONS = {
    "draft": {"generate": "generated", "sign": "signed", "revoke": "revoked"},
    "generated": {"sign": "signed", "export": "exported", "revoke": "revoked",
                  "generate": "generated"},
    "signed": {"export": "exported", "revoke": "revoked"},
    "exported": {"export": "exported", "revoke": "revoked"},
    "revoked": {},
}

# ---------------------------------------------------------------------------
# 6) 异步任务（task_job.status）
# ---------------------------------------------------------------------------
TASK_STATES = ("queued", "running", "done", "failed", "cancelled", "timeout")
TASK_LABELS = {
    "queued": "排队中", "running": "运行中", "done": "已完成",
    "failed": "失败", "cancelled": "已取消", "timeout": "超时",
}
TASK_TERMINAL_STATES = ("done", "failed", "cancelled", "timeout")
TASK_ACTIONS = {
    "queued": {"start": "running", "cancel": "cancelled", "fail": "failed",
               "timeout": "timeout"},
    "running": {"complete": "done", "fail": "failed", "cancel": "cancelled",
                "timeout": "timeout"},
    "done": {}, "failed": {}, "cancelled": {}, "timeout": {},
}

# ---------------------------------------------------------------------------
# 7) 站内通知（notification.read 0/1 → 未读/已读；G19）
# ---------------------------------------------------------------------------
NOTIFICATION_STATES = ("unread", "read")
NOTIFICATION_LABELS = {"unread": "未读", "read": "已读"}
NOTIFICATION_ACTIONS = {"unread": {"read": "read"}, "read": {}}
NOTIFICATION_READ_VALUE = {"unread": 0, "read": 1}

# ---------------------------------------------------------------------------
# 8) 冻结清单（audit_manifest.status）：插入态，无状态迁移写点（G14 现状登记）
# ---------------------------------------------------------------------------
MANIFEST_STATES = ("frozen", "reaudit")
MANIFEST_LABELS = {"frozen": "已冻结", "reaudit": "复审清单"}


# ---------------------------------------------------------------------------
# 9) 判定结论状态（finding.state / manifest D5 / 台账 / 报告口径）—— DU-29 单一源
# ---------------------------------------------------------------------------
# 背景（DU-29，2026-11-25）：``manifest_exec``（D5 V03 六状态组合）与
# ``audit_ledger``（台账/报告四类口径）曾各自维护一份状态别名表；两份当前语义
# 对齐，但新增别名需改两处 → 漂移风险。现把「别名 → 规范态」集中到本文件为唯一
# authoring 面，消费方只保留「规范态 → 本域取值」的轴映射（不是第二份别名表）：
#   - ``manifest_exec``：D5 契约六态（pass/fail/insufficient/unknown/na/
#     execution_failed）；规范态 ``missing`` 不在六态内，按 ``unknown`` fail-closed；
#   - ``audit_ledger``：台账/报告口径把 ``execution_failed`` 记为 ``failed``；
#     无法识别的取值原样返回（调用方仍按 unknown 处理，绝不伪造 pass/fail）。
VERDICT_STATES = ("pass", "fail", "insufficient", "unknown", "missing",
                  "na", "execution_failed")
# na 家族：不适用是确定结论，绝不进 unknown（红线 3）。manifest D5 与台账/报告共用。
NA_STATES = frozenset({"na", "n/a", "not_applicable", "not applicable",
                       "not-applicable", "notapplicable", "skipped",
                       "不适用", "未适用"})
VERDICT_ALIASES = {
    # 判定结论
    "pass": "pass", "ok": "pass", "满足": "pass", "通过": "pass",
    "fail": "fail", "不满足": "fail", "不通过": "fail",
    "insufficient": "insufficient", "needs_model": "insufficient",
    "证据不足": "insufficient",
    "unknown": "unknown", "无法判断": "unknown", "未判断": "unknown",
    "未执行": "unknown", "弃权": "unknown",
    # 结果缺失（应审未执行/无结果）：台账/报告单列；D5 六态没有该态，消费方归 unknown
    "missing": "missing", "缺失": "missing", "结果缺失": "missing",
    # 执行失败（报告「执行失败」口径；D5 契约态名 execution_failed）
    "execution_failed": "execution_failed", "blocked": "execution_failed",
    "failed": "execution_failed", "executor_error": "execution_failed",
    "执行失败": "execution_failed",
}
VERDICT_ALIASES.update({_s: "na" for _s in NA_STATES})


def normalize_verdict(raw, *, passthrough_unknown: bool = False) -> str:
    """任意落库结论/状态 → 规范态（唯一别名事实源）。

    - 已登记别名（含大小写/中文/历史写法）→ ``VERDICT_STATES`` 之一；
    - 空值 → ``unknown``（不得当 pass/fail）；
    - 未识别取值：``passthrough_unknown=False`` 时归 ``unknown``（D5 组合口径），
      ``True`` 时原样返回（台账旧口径，调用方仍按 unknown 处理），绝不伪造 pass/fail。
    """
    s = str(raw if raw is not None else "").strip()
    if not s:
        return "unknown"
    hit = VERDICT_ALIASES.get(s)
    if hit is None:
        hit = VERDICT_ALIASES.get(s.lower())
    if hit is not None:
        return hit
    return s if passthrough_unknown else "unknown"


# finding.state 五态归一（DU-08，2026-11-25）：manifest/台账的 finding 只物化
# fail 与 insufficient（红线 5）；上游 factreview/dag 缺 state 字段或给出未识别取值时
# 必须 fail-safe 归 insufficient，**不得默认 fail**（否则会伪造“不满足”且绕过证据门禁）。
FINDING_VERDICT_STATES = ("pass", "fail", "insufficient", "na", "unknown")
FINDING_VERDICT_ALIASES = {
    "pass": "pass", "满足": "pass", "ok": "pass",
    "fail": "fail", "不满足": "fail", "不通过": "fail",
    "insufficient": "insufficient", "证据不足": "insufficient",
    "弃权(需人工)": "insufficient", "需人工": "insufficient",
    "needs_model": "insufficient", "missing": "insufficient",
    "缺失": "insufficient", "结果缺失": "insufficient",
    "na": "na", "不适用": "na", "not_applicable": "na", "skipped": "na",
    "unknown": "unknown", "未知": "unknown", "无法判断": "unknown",
    "执行失败": "unknown", "failed": "unknown", "blocked": "unknown",
}


def normalize_finding_verdict(raw) -> str:
    """finding.state 归一：空值/未识别 → insufficient（fail-safe，DU-08）。"""
    s = str(raw if raw is not None else "").strip()
    if not s:
        return "insufficient"
    hit = FINDING_VERDICT_ALIASES.get(s)
    if hit is None:
        hit = FINDING_VERDICT_ALIASES.get(s.lower())
    return hit if hit is not None else "insufficient"


# ---------------------------------------------------------------------------
# 统一视图
# ---------------------------------------------------------------------------
STATE_SETS = {
    "rule": RULE_STATES,
    "rule_version": RULE_VERSION_STATES,
    "audit_case": CASE_STATES,
    "finding": FINDING_STATES,
    "report": REPORT_STATES,
    "task_job": TASK_STATES,
    "notification": NOTIFICATION_STATES,
    "audit_manifest": MANIFEST_STATES,
}
ACTION_TABLES = {
    "rule": RULE_ACTIONS,
    "rule_version": RULE_VERSION_ACTIONS,
    "audit_case": CASE_ACTIONS,
    "finding": FINDING_ACTIONS,
    "report": REPORT_ACTIONS,
    "task_job": TASK_ACTIONS,
    "notification": NOTIFICATION_ACTIONS,
}
LABELS = {
    "rule": RULE_LABELS,
    "rule_version": RULE_VERSION_LABELS,
    "audit_case": CASE_LABELS,
    "finding": FINDING_LABELS,
    "report": REPORT_LABELS,
    "task_job": TASK_LABELS,
    "notification": NOTIFICATION_LABELS,
    "audit_manifest": MANIFEST_LABELS,
}

# 历史遗留值（读取归一 + DB 值域保留；不主动迁移历史行，非法值另行报告）
LEGACY_ALIASES = {
    "audit_case": {"failed": "audit_failed", "error": "audit_failed",
                   "running": "reviewing", "done": "completed"},
    "report": {"issued": "signed"},
    "finding": {},
    "rule": {},
    "rule_version": {},
    "task_job": {},
    "audit_manifest": {},
    "notification": {},
}

# 7 张核心 status 表（table → (column, kind)）；db.py 据此幂等建触发器。
DB_STATUS_COLUMNS = {
    "rule": ("status", "rule"),
    "rule_version": ("status", "rule_version"),
    "audit_case": ("status", "audit_case"),
    "finding": ("status", "finding"),
    "audit_manifest": ("status", "audit_manifest"),
    "task_job": ("status", "task_job"),
    "report": ("status", "report"),
}
# 通知的 read 位（0/1）也做 DB 兜底（不是 status 列，单列登记）
DB_BIT_COLUMNS = {
    "notification": ("read", {0, 1}),
}
# 需要「迁移方向」校验的对象（repository 层；DB 只做值域）
REPOSITORY_TRANSITION_GUARDED = ("audit_case", "finding", "report")


# ---------------------------------------------------------------------------
# 派生与校验
# ---------------------------------------------------------------------------
def targets_of(kind: str, state: str) -> tuple:
    """该状态经任意动作可到达的目标状态（排序稳定）。"""
    acts = (ACTION_TABLES.get(kind) or {}).get(str(state or "")) or {}
    return tuple(sorted(set(acts.values())))


def transitions(kind: str) -> dict:
    """from_state → 目标状态元组（供 lifecycle_matrix/文档/测试读取）。"""
    table = ACTION_TABLES.get(kind) or {}
    return {st: list(targets_of(kind, st)) for st in (STATE_SETS.get(kind) or ())}


def actions_of(kind: str, state: str) -> dict:
    return dict(((ACTION_TABLES.get(kind) or {}).get(str(state or "")) or {}))


def action_target(kind: str, state: str, action: str):
    """(from_state, action) → 目标状态；非法动作返回 None（fail-closed，不猜）。"""
    acts = (ACTION_TABLES.get(kind) or {}).get(str(state or "")) or {}
    to = acts.get(str(action or ""))
    if to is not None:
        return to
    # finding：允许调用方直接用目标态当动作名（decide(...,"confirmed") 之类）
    if kind == "finding" and action in (STATE_SETS.get("finding") or ()):
        return str(action) if action in targets_of(kind, state) else None
    return None


def is_state(kind: str, value) -> bool:
    return str(value if value is not None else "") in (STATE_SETS.get(kind) or ())


def normalize(kind: str, value) -> str:
    """遗留别名/大小写归一为规范态；未知值原样返回（不伪造合法态）。"""
    raw = str(value if value is not None else "").strip()
    low = raw.lower()
    canonical = STATE_SETS.get(kind) or ()
    if low in canonical:
        return low
    alias = (LEGACY_ALIASES.get(kind) or {}).get(low)
    return alias or raw


def allowed_values(kind: str) -> tuple:
    """DB 触发器值域 = 规范态 ∪ 遗留别名（保留历史值兼容；新写非法值仍拒绝）。"""
    vals = list(STATE_SETS.get(kind) or ())
    for alias in (LEGACY_ALIASES.get(kind) or {}):
        if alias not in vals:
            vals.append(alias)
    return tuple(vals)


def can_transition(kind: str, from_state, to_state) -> bool:
    """迁移是否合法（同态幂等返回 True；未知 from/to 一律 False）。"""
    frm = normalize(kind, from_state)
    to = normalize(kind, to_state)
    if not is_state(kind, frm) or not is_state(kind, to):
        return False
    if frm == to:
        return True
    return to in targets_of(kind, frm)


def assert_transition(kind: str, from_state, to_state, action: str = "") -> None:
    """非法迁移抛 ValueError（调用方转 400/409 或 fail-closed 异常）。"""
    if can_transition(kind, from_state, to_state):
        return
    raise ValueError(
        "invalid_transition:%s:%s->%s%s"
        % (kind, normalize(kind, from_state) or str(from_state or ""),
           normalize(kind, to_state) or str(to_state or ""),
           ("(%s)" % action) if action else ""))


def assert_action(kind: str, state: str, action: str) -> str:
    """动作必须在该状态下合法；返回目标状态。"""
    to = action_target(kind, state, action)
    if to is None:
        raise ValueError("invalid_action:%s:%s:%s" % (kind, state, action))
    return to


def label(kind: str, value) -> str:
    canon = normalize(kind, value)
    return (LABELS.get(kind) or {}).get(canon, str(value if value is not None else ""))


def matrix(kind: str) -> dict:
    """机读矩阵（状态中文 label / 迁移 / 动作→目标）。"""
    return {
        "kind": kind,
        "states": list(STATE_SETS.get(kind) or ()),
        "labels": dict(LABELS.get(kind) or {}),
        "transitions": transitions(kind),
        "actions": {st: dict(acts) for st, acts in (ACTION_TABLES.get(kind) or {}).items()},
        "legacy_aliases": dict(LEGACY_ALIASES.get(kind) or {}),
    }


def all_matrices() -> dict:
    return {kind: matrix(kind) for kind in STATE_SETS}


def terminal_states(kind: str) -> tuple:
    return tuple(st for st in (STATE_SETS.get(kind) or ())
                 if not targets_of(kind, st) or kind == "rule" and st == "archived")


def db_guard_specs() -> list:
    """DB 兜底规格：[(table, column, kind, allowed_values)]（db.py 生成触发器）。"""
    out = []
    for table, (column, kind) in DB_STATUS_COLUMNS.items():
        out.append((table, column, kind, allowed_values(kind)))
    for table, (column, values) in DB_BIT_COLUMNS.items():
        out.append((table, column, "", tuple(sorted(values))))
    return out


def validate() -> list:
    """自洽校验；返回错误列表（空=通过）。"""
    errors = []
    for kind, states in STATE_SETS.items():
        if not states:
            errors.append(f"{kind}: 状态集合为空")
        if len(states) != len(set(states)):
            errors.append(f"{kind}: 状态重复")
        for st in states:
            for target in targets_of(kind, st):
                if target not in states:
                    errors.append(f"{kind}: {st} → 未知状态 {target}")
            for action, target in (ACTION_TABLES.get(kind, {}).get(st) or {}).items():
                if target not in states:
                    errors.append(f"{kind}: {st} --{action}--> 未知状态 {target}")
        legacy = LEGACY_ALIASES.get(kind) or {}
        for alias, canon in legacy.items():
            if canon not in states:
                errors.append(f"{kind}: 遗留别名 {alias}→{canon} 目标非规范态")
            if alias in states:
                errors.append(f"{kind}: 遗留别名 {alias} 与规范态重名")
    for table, (column, kind) in DB_STATUS_COLUMNS.items():
        if kind not in STATE_SETS:
            errors.append(f"DB_STATUS_COLUMNS.{table}: 未知 kind {kind}")
    for table, (column, kind) in DB_STATUS_COLUMNS.items():
        if not column:
            errors.append(f"DB_STATUS_COLUMNS.{table}: 缺列名")
    for kind in REPOSITORY_TRANSITION_GUARDED:
        if kind not in STATE_SETS:
            errors.append(f"REPOSITORY_TRANSITION_GUARDED: 未知 kind {kind}")
    # DU-29（2026-11-25）：判定结论别名表自洽（manifest D5 / 台账 / 报告同一事实源）
    for alias, canon in VERDICT_ALIASES.items():
        if canon not in VERDICT_STATES:
            errors.append(f"VERDICT_ALIASES: {alias}→未知规范态 {canon}")
        if str(alias).strip() != alias:
            errors.append(f"VERDICT_ALIASES: 别名 {alias!r} 含首尾空白（归一前应先 strip）")
    for na in NA_STATES:
        if VERDICT_ALIASES.get(na) != "na":
            errors.append(f"NA_STATES: {na!r} 未映射为 na")
    for alias, canon in FINDING_VERDICT_ALIASES.items():
        if canon not in FINDING_VERDICT_STATES:
            errors.append(f"FINDING_VERDICT_ALIASES: {alias}→未知 finding 态 {canon}")
        if str(alias).strip() != alias:
            errors.append(f"FINDING_VERDICT_ALIASES: 别名 {alias!r} 含首尾空白")
    for st in FINDING_VERDICT_STATES:
        if VERDICT_STATES and st not in VERDICT_STATES:
            errors.append(f"FINDING_VERDICT_STATES: {st} 不是 VERDICT_STATES 子集")
    return errors


__all__ = [name for name in dir() if name.isupper()] + [
    "targets_of", "transitions", "actions_of", "action_target", "is_state",
    "normalize", "allowed_values", "can_transition", "assert_transition",
    "assert_action", "label", "matrix", "all_matrices", "terminal_states",
    "db_guard_specs", "validate",
]
