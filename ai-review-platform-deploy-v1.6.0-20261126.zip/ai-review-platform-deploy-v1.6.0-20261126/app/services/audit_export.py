# -*- coding: utf-8 -*-
"""审计日志导出产品化（T-201，默认安全：默认关闭）。

背景：审计日志是只读合规轨迹，旧口径是「不提供导出」（页面无入口，API 403）。
本需求把它做成**可审计、可关闭、需二次确认**的产品能力，安全默认不变：

1. **默认关闭**：``sys_config.audit.export_enabled`` 未设置或为 0 → 一律 403
   （``audit_export_disabled``），与旧「不提供导出」完全一致；
2. **开启粒度**：平台级 ``audit.export_enabled`` + 空间级
   ``audit.export_enabled.<tenant>.<workspace>``（空间键优先，便于单空间试点）；
   开启操作只允许 super_admin，且每次都写 ``audit_export.config_changed`` 审计；
3. **权限**：导出仅 ``super_admin`` / ``platform_op``；其他角色（含业务管理员）403；
4. **二次确认**：``confirm=true``（HTTP body / CLI --confirm）缺失 → 400
   ``confirm_required``，不允许“一次点击直接下载”；
5. **留痕**：每次成功导出写 ``audit.exported`` 审计（谁/条件/条数/格式/SHA256/批次号，
   与审计查询同源）；导出文件带水印列（导出人/角色/时间/批次号）；
6. **不可改删**：本模块只提供 status/export/set_enabled，不提供任何删除/修改导出文件或
   审计行的入口；HTTP 只注册 GET status + POST export。

导出格式：CSV（UTF-8 BOM，Excel 可直接打开）/ JSONL（每行一条，附 ``_watermark``）。
内容 SHA256 是**实际导出字节**的哈希，写入审计后可复核“拿到的文件没被改过”。
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import os

from .. import db
from .. import repositories as R
from . import audit as audit_svc

log = logging.getLogger(__name__)

ENABLED_KEY = "audit.export_enabled"
WORKSPACE_KEY_FMT = "audit.export_enabled.%s.%s"
ALLOWED_ROLES = ("super_admin", "platform_op")
ADMIN_ROLES = ("super_admin",)
FORMATS = ("csv", "jsonl")
MAX_ROWS_DEFAULT = 20000

WATERMARK_COLUMNS = ("watermark_exported_by", "watermark_exported_role",
                     "watermark_exported_at", "watermark_batch_id")
CSV_COLUMNS = ("id", "created_at", "actor", "actor_name", "action", "action_label",
               "result", "object", "before_json", "after_json", "request_id", "ip",
               "tenant_id", "workspace_id") + WATERMARK_COLUMNS


def max_rows() -> int:
    raw = str(os.environ.get("RULEPROOF_AUDIT_EXPORT_MAX_ROWS") or "").strip()
    try:
        n = int(raw) if raw else MAX_ROWS_DEFAULT
    except ValueError:
        log.warning("RULEPROOF_AUDIT_EXPORT_MAX_ROWS 非整数：%r（用默认 %s）",
                    raw, MAX_ROWS_DEFAULT)
        n = MAX_ROWS_DEFAULT
    return max(1, n)


def _flag(value) -> bool:
    return str(value if value is not None else "").strip().lower() in ("1", "true", "yes", "on")


def _sys_get(key: str) -> str:
    try:
        from . import sysconfig
        return str(sysconfig.get(key) or "").strip()
    except Exception:  # noqa: BLE001 - 配置读失败按“未配置=关闭”处理（安全默认），但留日志
        log.warning("审计导出配置读取失败 key=%s（按关闭处理）", key, exc_info=True)
        return ""


def is_enabled(tenant_id: str = "", workspace_id: str = "") -> dict:
    """当前作用域是否开启审计导出（默认 False；空间键优先于平台键）。"""
    ws_key = ""
    if tenant_id and workspace_id:
        ws_key = WORKSPACE_KEY_FMT % (tenant_id, workspace_id)
        ws_val = _sys_get(ws_key)
        if ws_val != "":
            return {"enabled": _flag(ws_val), "scope": "workspace",
                    "key": ws_key, "value": ws_val}
    platform_val = _sys_get(ENABLED_KEY)
    if platform_val != "":
        return {"enabled": _flag(platform_val), "scope": "platform",
                "key": ENABLED_KEY, "value": platform_val}
    env_val = str(os.environ.get("RULEPROOF_AUDIT_EXPORT_ENABLED") or "").strip()
    if env_val != "":
        return {"enabled": _flag(env_val), "scope": "env",
                "key": "RULEPROOF_AUDIT_EXPORT_ENABLED", "value": env_val}
    return {"enabled": False, "scope": "default", "key": ENABLED_KEY, "value": ""}


def _deny(status: int, code: str, error: str, **extra) -> dict:
    out = {"ok": False, "status": int(status), "code": code, "error": error}
    out.update(extra)
    return out


def status(role: str, tenant_id: str = "", workspace_id: str = "") -> dict:
    """导出能力状态（仅 super_admin/platform_op 可查看）。"""
    if role not in ALLOWED_ROLES:
        return _deny(403, "forbidden", "仅系统管理员/平台运营可查看审计导出状态",
                     allowed_roles=list(ALLOWED_ROLES))
    cfg = is_enabled(tenant_id, workspace_id)
    return {"ok": True, **cfg, "allowed_roles": list(ALLOWED_ROLES),
            "formats": list(FORMATS), "max_rows": max_rows(),
            "watermark_columns": list(WATERMARK_COLUMNS),
            "require_confirm": True, "read_only": True}


def _normalize_fmt(fmt) -> str:
    f = str(fmt or "csv").strip().lower()
    return f if f in FORMATS else ""


def _filters(q="", result="", action="", actor="", date_from="", date_to="") -> dict:
    return {"q": str(q or ""), "result": str(result or ""), "action": str(action or ""),
            "actor": str(actor or ""), "date_from": str(date_from or ""),
            "date_to": str(date_to or "")}


# P2-B8-05：审计导出 CSV 会被下载到 Excel/WPS/Sheets 打开，以 = + - @ TAB CR
# 开头的单元格会被当公式解析（=cmd|'/C calc'!A0 → 命令执行）。前缀单引号消毒。
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _cell(value) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    text = value if isinstance(value, str) else str(value)
    if text and text[0] in _FORMULA_PREFIXES:
        return "'" + text
    return text


def _csv_bytes(rows: list, watermark: dict) -> bytes:
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\r\n")
    writer.writerow(list(CSV_COLUMNS))
    for row in rows:
        row = dict(row or {})
        out = []
        for col in CSV_COLUMNS:
            if col in WATERMARK_COLUMNS:
                out.append(_cell(watermark.get(col)))
            else:
                out.append(_cell(row.get(col)))
        writer.writerow(out)
    # UTF-8 BOM：Excel 打开中文不乱码；SHA256 按实际字节（含 BOM）计算
    return b"\xef\xbb\xbf" + buf.getvalue().encode("utf-8")


def _jsonl_bytes(rows: list, watermark: dict) -> bytes:
    lines = []
    for row in rows:
        item = {k: (row or {}).get(k) for k in CSV_COLUMNS if k not in WATERMARK_COLUMNS}
        item["_watermark"] = dict(watermark)
        lines.append(json.dumps(item, ensure_ascii=False))
    return ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8")


def _watermark(actor: str, role: str, at: str, batch_id: str) -> dict:
    return {"watermark_exported_by": actor, "watermark_exported_role": role,
            "watermark_exported_at": at, "watermark_batch_id": batch_id}


def _write_audit(action: str, actor: str, object_: str, payload: dict,
                 tenant_id: str = "", workspace_id: str = "",
                 ip: str = "", request_id: str = "") -> None:
    """写审计（独立事务）。失败必须显式抛出：导出是合规动作，不能“导出成功但无留痕”。"""
    from . import ctx as _ctx
    with _ctx.scoped(tenant_id or "", workspace_id or ""):
        R.audit_logs.log(actor=actor or "system", action=action, object=object_,
                         after=json.dumps(payload, ensure_ascii=False)[:4000],
                         request_id=request_id or "", ip=ip or "")


def export(actor: str, role: str, fmt: str = "csv", confirm: bool = False,
           q: str = "", result: str = "", action: str = "", actor_filter: str = "",
           date_from: str = "", date_to: str = "", tenant_id: str = "",
           workspace_id: str = "", ip: str = "", request_id: str = "") -> dict:
    """执行一次审计导出。返回 ``{"ok": True, "content": bytes, ...}`` 或错误 dict。

    检查顺序（与“默认安全”一致）：
    角色 → 开关（默认 403）→ 二次确认（400）→ 格式（400）→ 行数上限（400）。
    成功路径必然写一条 ``audit.exported`` 审计；审计写失败则整个导出失败（不静默）。
    """
    if role not in ALLOWED_ROLES:
        return _deny(403, "forbidden", "仅系统管理员/平台运营可导出审计日志",
                     allowed_roles=list(ALLOWED_ROLES))
    cfg = is_enabled(tenant_id, workspace_id)
    if not cfg.get("enabled"):
        return _deny(403, "audit_export_disabled",
                     "审计导出默认关闭（合规默认）：需 super_admin 显式开启 "
                     "audit.export_enabled 后才能导出", config=cfg)
    if not confirm:
        return _deny(400, "confirm_required",
                     "审计导出属于敏感操作，必须二次确认（confirm=true）",
                     config=cfg)
    fmt = _normalize_fmt(fmt)
    if not fmt:
        return _deny(400, "invalid_format", "导出格式只支持 csv / jsonl",
                     formats=list(FORMATS), config=cfg)
    limit = max_rows()
    try:
        res = audit_svc.search_logs(
            q=str(q or ""), result=str(result or ""), action=str(action or ""),
            actor=str(actor_filter or ""), date_from=str(date_from or ""),
            date_to=str(date_to or ""), limit=limit + 1, offset=0,
            tenant_id=tenant_id or "", workspace_id=workspace_id or "")
    except Exception as exc:  # noqa: BLE001 - 查询失败要如实报 500，不能返回空文件
        log.error("审计导出查询失败 actor=%s", actor, exc_info=True)
        return _deny(500, "audit_export_query_failed",
                     f"审计日志查询失败：{type(exc).__name__}")
    rows = list(res.get("items") or [])
    total = int(res.get("total") or 0)
    if total > limit:
        return _deny(400, "export_too_large",
                     f"命中 {total} 行，超过单次导出上限 {limit} 行；请缩小筛选范围"
                     "（本接口不做截断导出，避免拿到不完整审计数据）",
                     total=total, max_rows=limit, config=cfg)
    batch_id = db.new_id("aex")
    at = db.now()
    watermark = _watermark(actor, role, at, batch_id)
    content = _csv_bytes(rows, watermark) if fmt == "csv" else _jsonl_bytes(rows, watermark)
    sha256 = hashlib.sha256(content).hexdigest()
    audit_payload = {
        "batch_id": batch_id, "format": fmt, "rows": len(rows), "total": total,
        "sha256": sha256, "bytes": len(content),
        "filters": _filters(q, result, action, actor_filter, date_from, date_to),
        "scope": {"tenant_id": tenant_id or "", "workspace_id": workspace_id or "",
                  "config_scope": cfg.get("scope"), "config_key": cfg.get("key")},
        "watermark": watermark, "at": at,
    }
    try:
        _write_audit("audit.exported", actor, batch_id, audit_payload,
                     tenant_id=tenant_id, workspace_id=workspace_id,
                     ip=ip, request_id=request_id)
    except Exception as exc:  # noqa: BLE001 - 审计写失败必须让导出失败（合规优先）
        log.error("审计导出留痕失败 batch=%s actor=%s", batch_id, actor, exc_info=True)
        return _deny(500, "audit_write_failed",
                     f"导出留痕写入失败，已拒绝返回文件：{type(exc).__name__}")
    filename = "audit_export_%s.%s" % (batch_id, "csv" if fmt == "csv" else "jsonl")
    return {"ok": True, "content": content, "format": fmt, "rows": len(rows),
            "total": total, "sha256": sha256, "bytes": len(content),
            "batch_id": batch_id, "filename": filename, "watermark": watermark,
            "filters": audit_payload["filters"], "config": cfg, "read_only": True}


def set_enabled(enabled: bool, actor: str = "system", role: str = "super_admin",
                tenant_id: str = "", workspace_id: str = "",
                request_id: str = "", ip: str = "") -> dict:
    """开启/关闭审计导出（仅 super_admin；写 sys_config + 审计）。

    作用域：传 workspace_id → 空间级键；否则平台级键。
    """
    if role not in ADMIN_ROLES:
        return _deny(403, "forbidden", "仅系统管理员可变更审计导出开关")
    key = (WORKSPACE_KEY_FMT % (tenant_id, workspace_id)) if workspace_id else ENABLED_KEY
    value = "1" if enabled else "0"
    try:
        from . import sysconfig
        sysconfig.set_many({key: value})
    except Exception as exc:  # noqa: BLE001
        log.error("审计导出开关写入失败 key=%s", key, exc_info=True)
        return _deny(500, "config_write_failed", f"配置写入失败：{type(exc).__name__}")
    at = db.now()
    payload = {"key": key, "enabled": bool(enabled), "scope":
               ("workspace" if workspace_id else "platform"),
               "tenant_id": tenant_id or "", "workspace_id": workspace_id or "",
               "actor": actor, "at": at}
    try:
        _write_audit("audit_export.config_changed", actor, key, payload,
                     tenant_id=tenant_id, workspace_id=workspace_id,
                     ip=ip, request_id=request_id)
    except Exception as exc:  # noqa: BLE001
        log.error("审计导出开关变更留痕失败 key=%s", key, exc_info=True)
        return _deny(500, "audit_write_failed",
                     f"配置变更留痕失败：{type(exc).__name__}")
    return {"ok": True, "enabled": bool(enabled), "key": key,
            "scope": payload["scope"], "actor": actor, "at": at}
