import logging
"""首页：按身份返回工作台数据（统计 + 最近案例 + 通知 + 快捷入口）。"""
from .. import repositories as R
from . import notify, evolution


# ---------------------------------------------------------------------------
# 首页业务 KPI（T-107 P0-03）：规则/冲突数字统一取 rule_counts / 冲突列表同一口径，
# 不再让前端去匹配不存在的 label 后兜底为 0/—。
# ---------------------------------------------------------------------------

def _rule_domain_counts(user=None) -> tuple:
    """返回 (rule_counts, conflict_stats)；取数失败返回 ({}, {}) 不伪造 0。"""
    rc, cs = {}, {}
    try:
        from . import rule_library as _rl
        rc = _rl.rule_counts(scope="tenant")
    except Exception:
        logging.getLogger(__name__).debug("home rule_counts unavailable", exc_info=True)
    try:
        from . import conflict as _cf
        cs = (_cf.list_conflicts("", user=user or {}) or {}).get("stats") or {}
    except Exception:
        logging.getLogger(__name__).debug("home conflict stats unavailable", exc_info=True)
    return rc, cs


def _rule_kpi_stats(rc: dict, cs: dict, alerts: list, role: str = "") -> list:
    """规则/冲突/命中/Override/告警 KPI（label 与 web/app.js 读取的 label 对齐）。

    label 顺序有约束：``sv("规则")`` 取第一个包含“规则”的项，因此“规则发布”必须
    排在“待审批规则”之前；``sv("冲突")`` 同理匹配“待处理冲突”。
    """
    hits = (rc.get("hits") or {})
    try:
        decisions = R.decisions.list()
        n_dec = len(decisions)
        n_fp = sum(1 for d in decisions if str(d.get("decision") or "") == "false_positive")
        override = (round(n_fp / n_dec * 100, 1) if n_dec else None)
    except Exception:
        override, n_fp, n_dec = None, 0, 0
    return [
        {"label": "规则发布", "value": rc.get("executable_versions", 0),
         "hint": "可执行规则版本（current_version_id 且版本 published）"},
        {"label": "待审批规则", "value": rc.get("pending_approval_rules", 0), "hint": "条"},
        # E-04（DuMate 20261118）：审核端与业务端首页同一指标口径不同（审核员仅本人相关），
        # 首页必须自带范围标注，不能只在冲突页说明。
        {"label": "待处理冲突", "value": cs.get("open", 0),
         "hint": ("条（仅本人相关可裁范围，含证据不足子状态）" if role == "reviewer"
                  else "条（本租户可裁范围，含证据不足子状态）")},
        {"label": "命中归因", "value": hits.get("attributed", 0),
         "hint": "已归因 / 未归因 %d（未归因不按 0 处理）"
                 % hits.get("unattributed", 0)},
        {"label": "Override 误报率",
         "value": ("%s%%" % override if override is not None else "—"),
         "hint": "人工判误报 %d / 已复核 %d" % (n_fp, n_dec)},
        {"label": "告警", "value": len(alerts or []), "hint": "条系统告警"},
    ]



def _attach_finding_stats(cases: list) -> list:
    """批量补 pending/decided/total/status_label，避免逐项目 SQL（P1-B8-01 首页）。

    口径与旧逐项目实现（``_admin_home`` / ``review.my_cases``）完全一致：
    取 finding 全量窗口（不按 last_run_id 收窄），pending 计 status=pending，
    decided = 其余。旧实现对每个项目调一次 ``R.findings.by_case()``，1000 项目
    ≈1000 次 SQL；这里用 ``project._batch_case_facts`` 的批量 IN 查询一次取齐。
    """
    from . import project as _project
    facts = _project._batch_case_facts(cases)
    out = []
    for c in cases:
        fs = facts["findings"].get(str(c.get("id") or "")) or []
        pending = sum(1 for f in fs if f.get("status") == "pending")
        decided = len(fs) - pending
        _cst = str(c.get("status") or "")
        if _cst in ("auditing", "reviewing"):
            status_label = "审核中"
        elif _cst == "audit_failed":
            status_label = "审核失败"
        elif not fs:
            status_label = "待审核"
        elif pending:
            status_label = "待复核"
        else:
            status_label = "已确认"
        out.append({**c, "pending_count": pending, "decided_count": decided,
                    "total_count": len(fs), "status_label": status_label})
    return out


def _admin_home(user=None):
    """业务管理员首页：与审核员首页同构，只是项目/发现汇总本租户所有审核员。"""
    # P1-B8-01：先一条批查询补全 finding 统计，避免逐项目 SQL（原 1000 项目
    # ≈1000 次 R.findings.by_case）；行字段/计数口径不变。
    cases = _attach_finding_stats(R.cases.list(order="created_at DESC"))
    items = []
    pending_total = 0
    decided_total = 0
    for c in cases:
        pending = c["pending_count"]
        decided = c["decided_count"]
        pending_total += pending
        decided_total += decided
        _cst = str(c.get("status") or "")
        items.append({
            "id": c["id"], "name": c.get("name") or "", "status": _cst,
            "status_label": c["status_label"], "created_at": c.get("created_at") or "",
            "pending_count": pending, "decided_count": decided, "total_count": c["total_count"],
        })
    todo = sorted([x for x in items if x["pending_count"] > 0], key=lambda x: -x["pending_count"])[:8]
    doing = sum(1 for x in items if x.get("status") not in ("completed", "confirmed"))
    unread = notify.unread_count((user or {}).get("sub", "admin"))
    _rc, _cs = _rule_domain_counts(user)
    _alerts = notify.alerts()
    return {
        "role": "admin",
        "name": (user or {}).get("name", "") or "业务管理员",
        "stats": [
            {"label": "待复核", "value": pending_total, "hint": "全部审核员待处理发现"},
            {"label": "进行中项目", "value": doing, "hint": "个"},
            {"label": "已复核", "value": decided_total, "hint": "发现"},
            {"label": "未读消息", "value": unread, "hint": "条"},
        # E-04 修正（dumate-fix 实测发现）：原来这里误传 "reviewer"，导致业务端显示
        # 「仅本人相关可裁范围」。业务管理员应为「本租户可裁范围」。
        ] + _rule_kpi_stats(_rc, _cs, _alerts, "admin"),
        "rule_counts": _rc, "rule_hits": _rc.get("hits") or {},
        "conflict_stats": _cs,
        "todo": [{"id": c["id"], "name": c["name"], "pending_count": c["pending_count"],
                  "status": c["status_label"], "created_at": c.get("created_at", "")} for c in todo],
        "my_projects": [{k: c[k] for k in ("id", "name", "status_label", "pending_count", "decided_count", "created_at")} for c in items[:8]],
        "recent_cases": [{"id": c["id"], "name": c["name"], "status": c["status"], "created_at": c["created_at"],
                          "pending_count": c["pending_count"], "decided_count": c["decided_count"]} for c in items[:6]],
        "notifications": notify.list_for((user or {}).get("sub", "admin"), limit=8),
        "alerts": _alerts,
    }


def _reviewer_home(user):
    """审核员首页：以「项目」为单位，聚焦我的待办 + 我的项目 + 完成情况。"""
    sub = user.get("sub", "")
    # P1-B8-01：原 review.my_cases(sub) 逐项目查 finding（914 项目 ≈914 次 SQL）；
    # 这里用同一批量取数复刻其返回结构（字段/状态标签口径与 my_cases 一致）。
    # 保持与 review.my_cases 同步：若那边口径变化，这里需同步（review.py 本批不允许改）。
    mine = _attach_finding_stats(
        R.cases.list("created_by=?", (sub,), order="created_at DESC"))
    pending = sum(c.get("pending_count", 0) for c in mine)
    decided = sum(c.get("decided_count", 0) for c in mine)
    doing = sum(1 for c in mine if c.get("status") not in ("completed",))
    # 待复核项目：按待复核数降序
    todo = sorted([c for c in mine if c.get("pending_count", 0) > 0], key=lambda x: -x["pending_count"])
    _rc, _cs = _rule_domain_counts(user)
    _alerts = []
    return {
        "role": "reviewer",
        "name": (user or {}).get("name", "") or "审核员",
        "stats": [
            {"label": "待复核", "value": pending, "hint": "发现（需处理）"},
            {"label": "进行中项目", "value": doing, "hint": "个"},
            {"label": "已复核", "value": decided, "hint": "发现"},
            {"label": "未读消息", "value": notify.unread_count(sub), "hint": "条"},
        # E-04 修正（dumate-fix 实测发现）：原来这里误传 "admin"，导致审核端显示
        # 「本租户可裁范围」。审核员应看到「仅本人相关可裁范围」。
        ] + _rule_kpi_stats(_rc, _cs, _alerts, "reviewer"),
        "rule_counts": _rc, "rule_hits": _rc.get("hits") or {},
        "conflict_stats": _cs,
        # E-05（DuMate 20261118）：列表只展示前 8 个项目，但 KPI「待复核」是全部发现数，
        # 两者不闭合且无「查看全部」入口。下发 todo_total/todo_shown 供前端标注。
        "todo": [{"id": c["id"], "name": c["name"], "pending_count": c["pending_count"],
                  "status": c.get("status_label", ""), "created_at": c.get("created_at", "")} for c in todo[:8]],
        "todo_total": len(todo), "todo_shown": min(8, len(todo)),
        "todo_pending_total": pending,
        "my_projects": [{"id": c["id"], "name": c["name"], "status": c.get("status_label", ""),
                         "pending_count": c.get("pending_count", 0), "decided_count": c.get("decided_count", 0),
                         "created_at": c.get("created_at", "")} for c in mine[:8]],
        "notifications": notify.list_for(sub, limit=8),
        "alerts": _alerts,
    }


def _super_dashboard(tenant_id: str = "") -> dict:
    """系统管理员的 IT 看板：只做跨系统运维统计，不读租户业务内容。"""
    from .. import db
    import datetime as _dt
    _tid = str(tenant_id or "")
    days = [( _dt.date.today() - _dt.timedelta(days=i)).isoformat() for i in range(6, -1, -1)]
    out = {"days": days, "audits": [0]*7, "llm_calls": [0]*7, "tokens": [0]*7,
           "agent_runs": [0]*7, "llm_total": 0, "llm_tokens": 0, "llm_latency": 0,
           "model_rows": [], "agent_status": [], "health": {}}
    try:
        with db.session() as c:
            for i, d in enumerate(days):
                out["audits"][i] = c.execute("SELECT count(*) FROM audit_log WHERE substr(created_at,1,10)=?", (d,)).fetchone()[0]
                try:
                    row = c.execute("SELECT count(*), COALESCE(sum(tokens_in+tokens_out),0) FROM llm_trace WHERE substr(created_at,1,10)=?", (d,)).fetchone()
                    out["llm_calls"][i], out["tokens"][i] = row[0], row[1]
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
                try:
                    out["agent_runs"][i] = c.execute("SELECT count(*) FROM agent_run WHERE substr(created_at,1,10)=?", (d,)).fetchone()[0]
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
            try:
                row = c.execute("SELECT count(*), COALESCE(sum(tokens_in+tokens_out),0), COALESCE(avg(latency_ms),0) FROM llm_trace").fetchone()
                out["llm_total"], out["llm_tokens"], out["llm_latency"] = row[0], row[1], round(row[2] or 0)
                out["model_rows"] = [dict(x) for x in c.execute(
                    "SELECT model, count(*) AS calls, COALESCE(sum(tokens_in+tokens_out),0) AS tokens "
                    "FROM llm_trace GROUP BY model ORDER BY calls DESC LIMIT 6").fetchall()]
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
            try:
                out["agent_status"] = [dict(x) for x in c.execute(
                    "SELECT status, count(*) AS n FROM agent GROUP BY status").fetchall()]
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
            try:
                _models = c.execute("SELECT status, enabled, is_default, name FROM model_config").fetchall()
                _mstat = {"total": len(_models), "enabled": 0, "ok": 0, "fail": 0, "unconfigured": 0, "default": ""}
                for _m in _models:
                    if int(_m["enabled"] or 0):
                        _mstat["enabled"] += 1
                    _st = _m["status"] or "unknown"
                    if _st in ("ok", "fail", "unconfigured"):
                        _mstat[_st] += 1
                    if int(_m["is_default"] or 0):
                        _mstat["default"] = _m["name"] or ""
                _events = c.execute("SELECT status, count(*) n FROM open_event GROUP BY status").fetchall()
                _ev = {str(x["status"] or "pending"): x["n"] for x in _events}
                # E-01（DuMate 20261118）：health.accounts 必须与「账号」KPI 同口径——
                # 仅本租户、排除 platform_op（平台端维护）与已删除。原先按全库 GROUP BY
                # 统计，导致首页同时出现「3 账号」和「7 启用」。
                _users = c.execute(
                    "SELECT COALESCE(u.status,'active') s, count(*) n FROM user u "
                    "WHERE COALESCE(u.tenant_id,'')=? AND COALESCE(u.status,'active')!='deleted' "
                    "AND NOT EXISTS (SELECT 1 FROM user_role ur JOIN role r ON r.id=ur.role_id "
                    "                WHERE ur.user_id=u.id AND r.code='platform_op') "
                    "GROUP BY COALESCE(u.status,'active')", (_tid,)).fetchall()
                _acct = {str(x["s"]): x["n"] for x in _users}
                _must = c.execute(
                    "SELECT count(*) FROM user u WHERE u.must_change_pwd=1 "
                    "AND COALESCE(u.status,'active')='active' AND COALESCE(u.tenant_id,'')=? "
                    "AND NOT EXISTS (SELECT 1 FROM user_role ur JOIN role r ON r.id=ur.role_id "
                    "                WHERE ur.user_id=u.id AND r.code='platform_op')", (_tid,)).fetchone()[0]
                _last_err = c.execute("SELECT last_error FROM open_event WHERE last_error!='' ORDER BY created_at DESC LIMIT 1").fetchone()
                out["health"] = {
                    "models": _mstat,
                    "callbacks": {"pending": _ev.get("pending", 0), "retry": _ev.get("retry", 0),
                                  "failed": _ev.get("failed", 0), "delivered": _ev.get("delivered", 0),
                                  "last_error": (_last_err[0] if _last_err else "")},
                    "accounts": {"disabled": _acct.get("disabled", 0), "must_change": _must,
                                 "active": _acct.get("active", 0)},
                }
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
            try:
                from . import notify as _ntf
                out["health"]["channels"] = _ntf.channel_status()
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return out


def _super_home(user) -> dict:
    """超管首页：IT 视角（账号/对接/模型/智能体/审计），不含业务项目与规则。"""
    from .. import db
    from . import agents, model
    from . import audit as audit_service
    from . import notify
    users = []
    admins = []
    apps = events = agent_n = logs_total = 0
    fails = 0
    try:
        with db.session() as c:
            users = [dict(x) for x in c.execute(
                "SELECT id,name,phone,status FROM user WHERE COALESCE(status,'active')!='deleted'").fetchall()]
            admins = [dict(x) for x in c.execute(
                "SELECT u.id,u.name FROM user u JOIN user_role ur ON ur.user_id=u.id "
                "JOIN role r ON r.id=ur.role_id WHERE r.code='admin' "
                "AND COALESCE(u.status,'active')!='deleted'").fetchall()]
            apps = c.execute("SELECT COUNT(*) FROM open_app").fetchone()[0]
            events = c.execute("SELECT COUNT(*) FROM open_event WHERE delivered=0").fetchone()[0]
            agent_n = c.execute("SELECT COUNT(*) FROM agent").fetchone()[0]
            logs_total = c.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    fails = 0
    m = {}
    try:
        m = model.info() if hasattr(model, "info") else {}
    except Exception:
        m = {}
    return {
        "role": "super_admin", "name": (user or {}).get("name", "") or "未命名用户",
        "stats": [
            {"label": "账号", "value": len(users), "hint": f"管理员 {len(admins)}"},
            {"label": "开放应用", "value": apps, "hint": "对接系统"},
            {"label": "待投递回调", "value": events, "hint": "未送达"},
            {"label": "智能体", "value": agent_n, "hint": "个"},
            {"label": "审计日志", "value": logs_total, "hint": "累计记录"},
            {"label": "异常事件", "value": fails, "hint": "需处理"},
        ],
        "recent_cases": [],
        "notifications": notify.list_for((user or {}).get("sub", ""), limit=8),
        "alerts": [],
        "it_dashboard": _super_dashboard((user or {}).get("tenant_id") or ""),
    }


def home(user: dict) -> dict:
    from .. import db as _db
    role = ""
    try:
        role = _db.connect().execute(
            "SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?",
            ((user or {}).get("sub", ""),)).fetchone()
        role = role["code"] if role else ""
    except Exception:
        role = (user or {}).get("role", "")
    from . import stats as _stats
    if role == "super_admin":
        return _super_home(user)
    if role == "admin":
        return _stats.decorate_home(_admin_home(user), {**(user or {}), "role": role})
    return _stats.decorate_home(_reviewer_home(user or {}), {**(user or {}), "role": role})
