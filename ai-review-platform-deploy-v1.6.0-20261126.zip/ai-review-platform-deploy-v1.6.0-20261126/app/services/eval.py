"""评测服务：黄金样例 P/R、证据定位覆盖率、五态覆盖，并持久化 eval_run。"""
import json
import os
import tempfile

from .. import db
from .. import repositories as R
from ..engine import engine

GOLDEN = os.environ.get("RULEPROOF_GOLDEN", "")  # 可选：指定黄金样例；为空则只跑合成用例
EXPECT_CRITICAL = ["S1", "S2", "S3", "S4"]
EXPECT_WARNING = ["G-酱油饭", "G-味林香甜酱", "G3", "G4", "G5", "G6", "G7"]


def _recall(got, exp):
    return sum(1 for e in exp if e in got) / len(exp)


def _precision(got, exp):
    return sum(1 for g in got if g in exp) / len(got) if got else 1.0


def run_eval(golden_path: str = "") -> dict:
    """跑评测：有黄金样例则对齐黄金样例，否则用合成用例（与行业无关）。"""
    golden_path = golden_path or os.environ.get("RULEPROOF_GOLDEN", "")
    if not golden_path or not os.path.exists(golden_path):
        return run_eval_multi()
    rep = engine.build_report(golden_path)
    crit = [f["id"] for f in rep["findings"] if f["level"] == "critical"]
    warn = [f["id"] for f in rep["findings"] if f["level"] == "warning"]

    with_loc = sum(1 for f in rep["findings"]
                   if f["locations"] and any(l.get("locator") for l in f["locations"]))
    loc_cov = with_loc / len(rep["findings"]) if rep["findings"] else 1.0

    metrics = {
        "critical_recall": _recall(crit, EXPECT_CRITICAL),
        "critical_precision": _precision(crit, EXPECT_CRITICAL),
        "warning_recall": _recall(warn, EXPECT_WARNING),
        "warning_precision": _precision(warn, EXPECT_WARNING),
        "evidence_location_coverage": loc_cov,
        "checks_total": rep["summary"]["checks_total"],
        "checks_done": rep["summary"]["checks_done"],
        "evidence_insufficient": rep["summary"]["evidence_insufficient"],
        "exec_failed": rep["summary"]["exec_failed"],
        # trace：完整发现明细（不只看汇总），含每个发现的规则/证据定位
        "trace": [
            {"id": f["id"], "rule_code": f["rule_code"], "level": f["level"],
             "locations": [l.get("locator") for l in f.get("locations", [])]}
            for f in rep["findings"]
        ],
    }
    # 持久化
    es = R.eval_sets.list()
    if not es:
        es_id = db.new_id("es")
        R.eval_sets.insert(id=es_id, name="黄金样例评测集", golden_json=json.dumps({"critical": EXPECT_CRITICAL, "warning": EXPECT_WARNING}, ensure_ascii=False))
    else:
        es_id = es[0]["id"]
    R.eval_runs.insert(id=db.new_id("er"), eval_set_id=es_id, metrics_json=json.dumps(metrics, ensure_ascii=False))
    return {"metrics": metrics, "passed": (metrics["critical_recall"] == 1.0
                                           and metrics["warning_recall"] >= 0.8
                                           and metrics["critical_precision"] == 1.0
                                           and metrics["warning_precision"] == 1.0
                                           and metrics["evidence_location_coverage"] >= 0.98)}


# ---------------------------------------------------------------- 评测集扩充

def _mk_sheet(ws, impl_date, version, sig_values):
    """写入合成用例的最小表头结构。"""
    ws["A3"] = "实施日期"; ws["C3"] = impl_date
    ws["A4"] = "版本号"; ws["C4"] = version
    ws["A7"] = "商品名"; ws["D7"] = "测试产品"
    ws["A9"] = "工序名称"; ws["C9"] = "炒卷心菜"
    for i, role in enumerate(["研发经理", "生产经理", "品管经理", "研发"]):
        ws.cell(row=5, column=i + 1, value=role)
        ws.cell(row=6, column=i + 1, value=sig_values[i])


def _mk_all_x(path):
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "蔬菜前处理"
    _mk_sheet(ws, "X", "X", ["X", "X", "X", "X"])
    wb.save(path)


def _mk_valid(path):
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "蔬菜前处理"
    _mk_sheet(ws, "2026-03-17", "LHHK-C-RD-STP-649A1", ["张三", "李四", "王五", "赵六"])
    wb.save(path)


def run_eval_multi() -> dict:
    """多用例评测：黄金 + 全X占位符 + 合规样例，聚合指标。"""
    tmpdir = tempfile.mkdtemp(prefix="ruleproof_eval_")
    all_x = os.path.join(tmpdir, "全X.xlsx")
    valid = os.path.join(tmpdir, "合规.xlsx")
    _mk_all_x(all_x)
    _mk_valid(valid)
    cases = [("全X占位符", all_x, ["S2", "S3"], []), ("合规样例", valid, [], [])]
    golden = os.environ.get("RULEPROOF_GOLDEN", "")
    if golden and os.path.exists(golden):
        cases.insert(0, ("黄金样例", golden, EXPECT_CRITICAL, EXPECT_WARNING))
    per_case = []
    hit_c = hit_w = exp_c = exp_w = got_c = got_w = 0
    for name, path, ec, ew in cases:
        rep = engine.build_report(path)
        got_crit = [f["id"] for f in rep["findings"] if f["level"] == "critical"]
        got_warn = [f["id"] for f in rep["findings"] if f["level"] == "warning"]
        per_case.append({"name": name,
                         "critical_got": got_crit, "critical_exp": ec,
                         "warning_got": got_warn, "warning_exp": ew})
        hit_c += sum(1 for e in ec if e in got_crit)
        hit_w += sum(1 for e in ew if e in got_warn)
        exp_c += len(ec); exp_w += len(ew); got_c += len(got_crit); got_w += len(got_warn)
    metrics = {
        "cases": len(cases),
        "critical_recall": hit_c / exp_c if exp_c else 1.0,
        "critical_precision": hit_c / got_c if got_c else 1.0,
        "warning_recall": hit_w / exp_w if exp_w else 1.0,
        "warning_precision": hit_w / got_w if got_w else 1.0,
        "per_case": per_case,
    }
    es = R.eval_sets.list()
    if not es:
        R.eval_sets.insert(id=db.new_id("es"), name="合成用例评测集", golden_json=json.dumps(per_case, ensure_ascii=False))
    R.eval_runs.insert(id=db.new_id("er"), eval_set_id=(R.eval_sets.list() or [{"id": ""}])[0]["id"],
                       metrics_json=json.dumps(metrics, ensure_ascii=False))
    metrics["passed"] = (metrics["critical_recall"] == 1.0 and metrics["warning_recall"] == 1.0
                         and metrics["critical_precision"] == 1.0 and metrics["warning_precision"] == 1.0)
    return {"metrics": metrics, "passed": metrics["passed"]}
