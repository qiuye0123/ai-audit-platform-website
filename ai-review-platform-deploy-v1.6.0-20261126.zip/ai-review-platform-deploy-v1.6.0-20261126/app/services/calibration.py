"""校准路由（选择性预测 + 弃权）——「Jev」概念的真正可落地部分。

不做概念，做机制：把 LLM 判定的「置信度」和「人工复核结果」对齐，算出可靠阈值，
低于阈值就弃权转人工，只对高置信度下结论，并输出「覆盖率 + 回答准确率」两个可审计指标。

本轮口径统一（此前多套样本口径并存，导致同一置信度在不同入口得到不同结论）：

- 所有统计（reliability/threshold_for/summary/gate/rule_gate/coverage/by_rule/
  selective）统一读 ``_sample_rows()``：当前租户/空间上下文内的样本，历史无隔离
  标签的样本作为全局共享样本回落（与仓储层 include_global 同口径）；
- 最小样本数统一由 ``min_samples()`` 给出（env RULEPROOF_JEV_MIN_SAMPLES >
  sysconfig jev_min_samples > 3），不再各处写 30/3 两套门槛；
- 「样本不足 ≠ 弃权」：样本不足一律 ``abstain=False`` + ``uncalibrated=True``，
  保留原判定并显式标注未校准；只有已校准且低于阈值才弃权。
"""
import json
import logging
import os

from .. import db
from .. import repositories as R

_LOG = logging.getLogger(__name__)
_DEFAULT_MIN_SAMPLES = 3


def _all_rows() -> list:
    """全库样本（只读、仅用于口径回落与契约哈希；业务判断用 _sample_rows）。"""
    try:
        c = db.connect()
        rows = [dict(r) for r in c.execute("SELECT * FROM calibration").fetchall()]
        c.close()
        return rows
    except Exception:  # noqa: BLE001
        try:
            return R.calibration.list()
        except Exception:  # noqa: BLE001
            return []


def _valid_rows(rows: list) -> list:
    return [r for r in rows if r.get("correct") in (0, 1)]


def _current_scope() -> dict:
    try:
        from . import ctx as _ctx
        cur = _ctx.get_context() or {}
        return {"tenant_id": str(cur.get("tenant_id") or ""),
                "workspace_id": str(cur.get("workspace_id") or "")}
    except Exception:  # noqa: BLE001
        return {"tenant_id": "", "workspace_id": ""}


def min_sample_threshold() -> int:
    """统一的最小样本数门槛（环境变量 > sysconfig > 默认 3）。"""
    raw = os.environ.get("RULEPROOF_JEV_MIN_SAMPLES")
    if raw:
        try:
            return max(1, int(raw))
        except (TypeError, ValueError):
            pass
    try:
        from . import sysconfig
        v = sysconfig.get("jev_min_samples")
        if v:
            return max(1, int(float(v)))
    except Exception:  # noqa: BLE001
        pass
    return _DEFAULT_MIN_SAMPLES


def min_samples() -> int:
    """统一最小样本数的公共别名（供 API/测试读取，不参与参数遮蔽）。"""
    return min_sample_threshold()


def _sample_rows(level: str = "auto") -> list:
    """统一 JEV 样本口径。

    level=auto（默认）：有空间上下文按空间，有租户上下文按租户，否则全局；
    level=workspace / tenant / global：显式指定回落层级（阈值分层用）。
    「无隔离标签」的历史样本视为全局共享，避免旧数据在上下文里凭空消失。
    """
    rows = _all_rows()
    if level == "global":
        return rows
    cur = _current_scope()
    tid, wid = cur["tenant_id"], cur["workspace_id"]
    if level == "auto":
        if wid and tid:
            level = "workspace"
        elif tid:
            level = "tenant"
        else:
            return rows
    if level == "workspace":
        if not tid:
            return rows
        return [r for r in rows
                if (r.get("tenant_id") or "") in ("", tid)
                and (r.get("workspace_id") or "") in ("", wid)]
    if level == "tenant":
        if not tid:
            return rows
        return [r for r in rows
                if (r.get("tenant_id") or "") in ("", tid)]
    return rows


def sample_scope() -> dict:
    """当前 JEV 样本口径快照（供审计/测试核对“口径统一”）。"""
    cur = _current_scope()
    level = "workspace" if (cur["tenant_id"] and cur["workspace_id"]) else (
        "tenant" if cur["tenant_id"] else "global")
    counts = {lv: len(_valid_rows(_sample_rows(lv)))
              for lv in ("workspace", "tenant", "global")}
    return {"level": level, "min_samples": min_samples(),
            "counts": counts, "rows": len(_valid_rows(_sample_rows())),
            "context": cur}



def record(confidence, correct, rule_code: str = "", point_id: str = "", source: str = "human"):
    """记录一次模型判定：confidence + 人工复核是否正确 + 归属规则/点位。"""
    if confidence is None:
        return
    try:
        from . import ctx as _ctx
        _cur = _ctx.get_context()
    except Exception:
        _cur = {"tenant_id": "", "workspace_id": ""}
    R.calibration.insert(id=db.new_id("cal"), confidence=round(float(confidence), 3),
                         correct=1 if correct else 0, created_at=db.now(),
                         rule_code=rule_code or "", point_id=point_id or "",
                         source=source or "human",
                         tenant_id=_cur.get("tenant_id") or "t-default",
                         workspace_id=_cur.get("workspace_id") or "ws-default")


def _scope_samples() -> list:
    """兼容别名：统一走 _sample_rows()（当前租户/空间口径，未标注样本回落全局）。"""
    return _valid_rows(_sample_rows())


def samples() -> list:
    return _scope_samples()


def reliability(samples: list = None) -> dict:
    """可靠性曲线：按置信度分桶，算每桶实际准确率 + ECE（校准误差）。"""
    rows = samples if samples is not None else _scope_samples()
    if not rows:
        return {"samples": 0, "ece": None, "buckets": []}
    buckets = {}
    for r in rows:
        b = round(r["confidence"] * 10) / 10  # 0.1 桶
        buckets.setdefault(b, []).append(r["correct"])
    out = []
    ece = 0.0
    for b in sorted(buckets):
        vals = buckets[b]
        acc = sum(vals) / len(vals)
        ece += abs(acc - b) * len(vals)
        out.append({"confidence": b, "accuracy": round(acc, 3), "n": len(vals)})
    ece /= len(rows)
    return {"samples": len(rows), "ece": round(ece, 4), "buckets": out}


def threshold_for(min_accuracy: float = 0.9) -> float:
    """找使「回答部分准确率 ≥ min_accuracy」的最低置信度阈值（选择性预测）。"""
    rows = sorted(_scope_samples(), key=lambda r: r.get("confidence") or 0, reverse=True)
    if not rows:
        return 0.0
    best = 0.0
    above = []
    # 从高到低，找第一个满足「累计准确率≥阈值」的置信度
    for r in rows:
        above.append(r)
        acc = sum(x["correct"] for x in above) / len(above)
        if acc >= min_accuracy:
            best = r["confidence"]
        else:
            break
    return round(best, 2)


def min_accuracy_f() -> float:
    """目标回答准确率（Jev 配置，默认 0.9）。"""
    try:
        from . import sysconfig
        v = sysconfig.get("jev_min_accuracy")
        return float(v) if v else 0.9
    except Exception:
        return 0.9


def set_min_accuracy(v: float) -> dict:
    from . import sysconfig
    v = max(0.5, min(0.99, float(v)))
    sysconfig.set_many({"jev_min_accuracy": str(v)})
    return {"min_accuracy": v}


def selective(confidence, min_accuracy: float = None) -> dict:
    """选择性预测：已校准且 confidence 低于阈值 → 弃权；未校准不弃权。

    口径：阈值只用 ``scoped_threshold``（同一 _sample_rows 样本集 + 统一最小样本数）；
    “样本不足”只意味着“未校准”，不是“弃权”——保留原判定并显式标记 uncalibrated。
    """
    if confidence is None:
        return {"answer": False, "abstain": True, "confidence": None,
                "reason": "no_confidence"}
    ma = min_accuracy if min_accuracy is not None else min_accuracy_f()
    try:
        _g = scoped_threshold(min_samples=min_samples(), min_accuracy=ma)
    except Exception as exc:  # noqa: BLE001
        return {"answer": True, "abstain": False, "confidence": confidence,
                "threshold": None, "uncalibrated": True,
                "gate": f"calibration_error:{type(exc).__name__}"}
    if not _g.get("ok"):
        # 未校准不等于“所有结论都不可用”：此前 threshold=None 会把 0.8~0.94 的
        # 真实模型 fail 全部降级为 insufficient，导致批量审核几乎全 unknown。
        # 保留模型判定并显式标记 uncalibrated；只有已校准且低于阈值才弃权。
        return {"answer": True, "abstain": False, "confidence": confidence,
                "threshold": None, "gate": _g.get("reason"),
                "gate_forced": True, "uncalibrated": True,
                "samples": _g.get("samples")}
    t = float(_g.get("threshold") or 0)
    if float(confidence) < t:
        return {"answer": False, "abstain": True, "confidence": confidence,
                "threshold": t, "calibrated": True, "level": _g.get("level")}
    return {"answer": True, "abstain": False, "confidence": confidence,
            "threshold": t, "calibrated": True, "level": _g.get("level")}


def summary() -> dict:
    """校准状态：样本数 / ECE / 阈值 / 覆盖率 / 回答准确率。"""
    rel = reliability()
    if rel["samples"] == 0:
        return {"samples": 0, "ece": None, "threshold": None,
                "min_accuracy": min_accuracy_f(), "min_samples": min_samples(),
                "scope": sample_scope(),
                "note": "尚无校准样本（人工复核后自动累积）"}
    ma = min_accuracy_f()
    t = threshold_for(ma)
    rows = _scope_samples()
    answered = [r for r in rows if r["confidence"] >= t]
    acc = sum(r["correct"] for r in answered) / len(answered) if answered else 1.0
    return {"samples": rel["samples"], "ece": rel["ece"], "threshold": t,
            "coverage": round(len(answered) / len(rows), 3), "accuracy": round(acc, 3),
            "min_accuracy": ma, "min_samples": min_samples(), "buckets": rel["buckets"],
            "scope": sample_scope()}




def rule_gate(rule_code: str, min_samples: int = None) -> dict:
    """规则级 JEV 门禁：样本足够且准确率低于目标时，D5 应弃权转人工。

    - 样本口径与全局统计一致（``_sample_rows``，当前租户/空间）；
    - 最小样本数统一走 ``min_samples()``（调用方显式传参优先）；
    - **样本不足不弃权**：返回 abstain=False + uncalibrated=True，
      只标注“未校准”，不改写原结论。
    """
    code = str(rule_code or "").strip()
    need = int(min_samples) if min_samples else min_sample_threshold()
    if not code:
        return {"abstain": False, "reason": "no_rule_code", "uncalibrated": True,
                "samples": 0, "needed": need, "target": min_accuracy_f()}
    try:
        rows = [r for r in _scope_samples() if str(r.get("rule_code") or "") == code]
    except Exception:  # noqa: BLE001
        rows = []
    if len(rows) < max(1, need):
        return {"abstain": False, "reason": "insufficient_samples",
                "uncalibrated": True, "samples": len(rows), "needed": max(1, need),
                "target": min_accuracy_f()}
    acc = sum(int(r.get("correct") or 0) for r in rows) / len(rows)
    target = min_accuracy_f()
    return {"abstain": acc < target, "samples": len(rows), "accuracy": round(acc, 3),
            "target": target, "needed": max(1, need),
            "reason": "low_rule_accuracy" if acc < target else "ok"}


def by_rule() -> list:
    """按规则聚合校准样本：样本数 / 实际准确率 / 覆盖率 / 是否达到目标准确率。"""
    try:
        rows = _scope_samples()
    except Exception:  # noqa: BLE001
        return []
    agg = {}
    for r in rows:
        code = r.get("rule_code") or ""
        if not code:
            continue
        a = agg.setdefault(code, {"rule_code": code, "samples": 0, "correct": 0, "confs": []})
        a["samples"] += 1
        a["correct"] += int(r.get("correct") or 0)
        a["confs"].append(float(r.get("confidence") or 0))
    ma = min_accuracy_f()
    out = []
    for code, a in agg.items():
        acc = a["correct"] / a["samples"] if a["samples"] else 0.0
        out.append({"rule_code": code, "samples": a["samples"], "accuracy": round(acc, 3),
                    "avg_confidence": round(sum(a["confs"]) / len(a["confs"]), 3) if a["confs"] else None,
                    "target": ma, "meets_target": acc >= ma})
    out.sort(key=lambda x: (x["meets_target"], -x["samples"]))
    return out


# ---------------- Jev 治理（借鉴本体：校验 → 门禁 → 契约）----------------
def validate_sample(confidence, correct, rule_code: str = "", point_id: str = "") -> dict:
    """样本校验：缺归属、置信度越界、correct 非布尔的样本一律拒收。"""
    errs = []
    try:
        c = float(confidence)
    except Exception:
        return {"ok": False, "errors": ["confidence 非数值"]}
    if not (0.0 <= c <= 1.0):
        errs.append("confidence 越界（应在 0~1）")
    if correct not in (0, 1, True, False):
        errs.append("correct 非布尔值")
    if not (rule_code or point_id):
        errs.append("缺少归属（rule_code / point_id 至少一个）")
    return {"ok": not errs, "errors": errs}


def record_checked(confidence, correct, rule_code: str = "", point_id: str = "") -> dict:
    """带校验的写入：不合格样本不落库，避免污染阈值。"""
    v = validate_sample(confidence, correct, rule_code, point_id)
    if not v["ok"]:
        return {"ok": False, "rejected": True, "errors": v["errors"]}
    record(confidence, correct, rule_code, point_id)
    return {"ok": True}


def coverage() -> dict:
    """Jev 覆盖率：有多少规则至少有一条校准样本（真覆盖指标，口径同 _sample_rows）。"""
    try:
        rows = _scope_samples()
        have = {r.get("rule_code") for r in rows if r.get("rule_code")}
        rules = {r.get("code") for r in R.rules.list("status=?", ("published",))}
    except Exception:  # noqa: BLE001
        return {"rules": 0, "covered": 0, "rate": 0.0}
    covered = len(have & rules)
    return {"rules": len(rules), "covered": covered,
            "rate": round(covered / max(1, len(rules)), 3),
            "samples": len(rows), "scope": sample_scope()}


def gate(min_samples: int = None, min_accuracy: float = 0.9) -> dict:
    """阈值门禁：样本不足或准确率不达标 → 不允许把阈值用于自动放行。

    样本不足返回 ``abstain=False + uncalibrated=True``：这是“未校准”，
    不是“本条判定弃权”；只有已校准且阈值以上准确率不达标才 block 自动放行。
    """
    need = int(min_samples) if min_samples else min_sample_threshold()
    rows = _scope_samples()
    n = len(rows)
    if n < need:
        return {"ok": False, "abstain": False, "uncalibrated": True,
                "reason": f"样本不足（{n}/{need}），阈值不得用于自动放行",
                "threshold": None, "samples": n, "needed": need,
                "scope": sample_scope()}
    th = threshold_for(min_accuracy)
    above = [r for r in rows if r.get("confidence", 0) >= th]
    acc = (sum(r["correct"] for r in above) / len(above)) if above else 0.0
    ok = acc >= min_accuracy
    return {"ok": ok, "abstain": False, "threshold": th, "samples": n,
            "needed": need,
            "coverage": round(len(above) / n, 3),
            "accuracy_above": round(acc, 3),
            "reason": "" if ok else f"阈值以上准确率 {acc:.2f} 未达 {min_accuracy}"}


def contract_hash() -> str:
    """阈值契约：样本集变化则哈希变化，用于结论归因（全库样本，跨空间可复现）。"""
    import hashlib
    rows = sorted(_all_rows(), key=lambda r: r.get("confidence") or 0)
    payload = json.dumps([[r.get("confidence"), r.get("correct"), r.get("rule_code")] for r in rows])
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


# ---------------- 全局样本回流（让 Jev 从 1% 走向全局覆盖）----------------
def ingest_reviews() -> dict:
    """从人工复核结果自动回流校准样本：正/负反馈 → (confidence, correct)。

    样本来源：feedback 表中 confirm（正确）/ false_positive（错误）的记录，
    通过 finding 找到对应点位的判定置信度。去重键 = finding_id + kind。
    """
    import json as _j
    n = 0
    skipped = 0
    try:
        fbs = R.feedback.list()
    except Exception:
        return {"ingested": 0, "skipped": 0, "reason": "feedback 不可读"}
    have = {(r.get("finding_id") or "", str(r.get("confidence"))) for r in _all_rows()}
    for fb in fbs:
        kind = (fb.get("kind") or "")
        if kind not in ("confirm", "false_positive"):
            continue
        fid = fb.get("finding_id") or ""
        correct = 1 if kind == "confirm" else 0
        conf = None
        try:
            payload = _j.loads(fb.get("payload") or "{}")
            conf = payload.get("confidence")
        except Exception:
            payload = {}
        if conf is None:
            # 从 point_state 反查该点位最近一次判定的置信度
            try:
                c = db.connect()
                row = c.execute("SELECT confidence FROM point_state WHERE point_id=? "
                                "AND confidence IS NOT NULL ORDER BY rowid DESC LIMIT 1",
                                ((fb.get("rule_code") or ""),)).fetchone()
                c.close()
                conf = row[0] if row else None
            except Exception:
                conf = None
        if conf is None:
            skipped += 1
            continue
        key = (fid, str(round(float(conf), 3)))
        if key in have:
            skipped += 1
            continue
        record(conf, correct, rule_code=(fb.get("rule_code") or ""), point_id=(fb.get("rule_code") or ""), source="human")
        have.add(key)
        n += 1
    return {"ingested": n, "skipped": skipped}


def ingest_consistency(min_repeats: int = 2) -> dict:
    """一致性回流：确定性点位（非语义）多次判定结果一致 → 视为伪标签样本。

    只对 method 属于 calculate/compare/text/expert 的点位启用；
    语义点位不参与，避免用模型自证模型。
    """
    n = 0
    skipped = 0
    try:
        c = db.connect()
        rows = c.execute("SELECT point_id, confidence, state, count(*) as n FROM point_state "
                         "WHERE confidence IS NOT NULL GROUP BY point_id, state, confidence "
                         "HAVING n >= ?", (min_repeats,)).fetchall()
        c.close()
    except Exception:
        return {"ingested": 0, "skipped": 0, "reason": "point_state 不可读"}
    deterministic = set()
    try:
        from . import auditpoints as AP
        for p in AP.load().points:
            if (getattr(p, "method", "") in ("calculate", "compare", "text", "expert")):
                deterministic.add(p.id)
    except Exception:
        pass
    have = {(r.get("point_id") or "", str(r.get("confidence"))) for r in _all_rows()}
    for pid, conf, state, cnt in rows:
        if pid not in deterministic:
            skipped += 1
            continue
        key = (pid, str(round(float(conf), 3)))
        if key in have:
            skipped += 1
            continue
        record(conf, 1, rule_code=pid, point_id=pid, source="consistency")
        have.add(key)
        n += 1
    return {"ingested": n, "skipped": skipped, "deterministic_points": len(deterministic)}


def coverage_by_point() -> dict:
    """按点位看校准覆盖：有多少点位至少有 1 条样本。"""
    try:
        rows = R.calibration.list()
        pts = {r.get("point_id") for r in rows if r.get("point_id")}
        from . import auditpoints as AP
        allp = {p.id for p in AP.load().points}
    except Exception:
        return {"points": 0, "covered": 0, "rate": 0.0}
    return {"points": len(allp), "covered": len(pts & allp),
            "rate": round(len(pts & allp) / max(1, len(allp)), 3)}


def human_samples() -> list:
    """当前租户/空间口径下的人工复核样本（一致性伪标签不算）。"""
    return [r for r in _scope_samples() if (r.get("source") or "human") == "human"]


def gate_strict(min_human: int = None, min_accuracy: float = None) -> dict:
    """严格门禁：只认可人工复核样本；一致性样本不得用于放行决策。"""
    need = int(min_human) if min_human else min_sample_threshold()
    target = float(min_accuracy) if min_accuracy is not None else min_accuracy_f()
    rows = human_samples()
    if len(rows) < need:
        return {"ok": False, "human": len(rows), "needed": min_human,
                "reason": f"人工复核样本不足（{len(rows)}/{min_human}），阈值不得用于自动放行"}
    th = threshold_for(min_accuracy)
    above = [r for r in rows if r.get("confidence", 0) >= th]
    acc = (sum(r["correct"] for r in above) / len(above)) if above else 0.0
    return {"ok": acc >= min_accuracy, "human": len(rows), "threshold": th,
            "accuracy_above": round(acc, 3), "coverage": round(len(above) / len(rows), 3)}


# ---------------- 空间级阈值 + 租户级回落（E 项）----------------
def _rows_scoped(level: str) -> list:
    """level=workspace|tenant|global：统一走 _sample_rows（同一样本口径）。"""
    return _valid_rows(_sample_rows(level))


def space_alpha(default: float = 0.05):
    """空间设置里的 α 优先。"""
    try:
        from . import ctx as _c, workspaces as _w
        cur = _c.get_context()
        st = _w.get_settings(cur.get("workspace_id") or "") if cur.get("workspace_id") else {}
        a = st.get("alpha")
        if a is not None:
            return float(a)
    except Exception:
        pass
    return default


def scoped_threshold(min_samples: int = None, min_accuracy: float = None) -> dict:
    """先看空间样本，不足回落租户，再不足回落全局；都不足 → 不给阈值（未校准）。

    最小样本数默认走 ``min_sample_threshold()``；目标准确率默认走
    ``min_accuracy_f()``，与 summary/rule_gate/selective 全口径一致。
    """
    need = int(min_samples) if min_samples else min_sample_threshold()
    target = float(min_accuracy) if min_accuracy is not None else min_accuracy_f()
    for level in ("workspace", "tenant", "global"):
        rows = _rows_scoped(level)
        if len(rows) >= need:
            th = _threshold_from(rows, target)
            above = [r for r in rows if (r.get("confidence") or 0) >= th]
            acc = (sum(r["correct"] for r in above) / len(above)) if above else 0.0
            if acc >= target:
                return {"ok": True, "level": level, "threshold": th, "samples": len(rows),
                        "accuracy": round(acc, 3), "min_samples": need, "target": target}
    counts = {lv: len(_rows_scoped(lv)) for lv in ("workspace", "tenant", "global")}
    return {"ok": False, "level": "none", "threshold": None, "counts": counts,
            "min_samples": need, "target": target,
            "abstain": False, "uncalibrated": True,
            "reason": f"空间/租户/全局样本均不足，阈值不用于自动放行 {counts}"}


def _threshold_from(rows: list, min_accuracy: float) -> float:
    rows = sorted(rows, key=lambda r: r.get("confidence") or 0, reverse=True)
    best, above = 0.0, []
    for r in rows:
        above.append(r)
        acc = sum(x["correct"] for x in above) / len(above)
        if acc >= min_accuracy:
            best = r.get("confidence") or 0
        else:
            break
    return round(best, 2)


def coverage_scoped() -> dict:
    out = {}
    for level in ("workspace", "tenant", "global"):
        rows = _rows_scoped(level)
        out[level] = {"samples": len(rows),
                      "human": len([r for r in rows if (r.get("source") or "human") == "human"])}
    return out


def risk_coverage(steps: int = 10) -> list:
    """风险-覆盖率曲线：阈值越高覆盖率越低、风险越低。返回每档阈值下的覆盖率与错误率。"""
    rows = [r for r in _rows_scoped("global") if r.get("correct") in (0, 1)]
    if not rows:
        return []
    out = []
    for i in range(steps + 1):
        th = round(i / steps, 1)
        kept = [r for r in rows if (r.get("confidence") or 0) >= th]
        if not kept:
            out.append({"threshold": th, "coverage": 0.0, "risk": None, "n": 0})
            continue
        risk = 1 - sum(r["correct"] for r in kept) / len(kept)
        out.append({"threshold": th, "coverage": round(len(kept) / len(rows), 3),
                    "risk": round(risk, 4), "n": len(kept)})
    return out


def pick_threshold(alpha: float = 0.05) -> dict:
    """按风险预算 α 选阈值：在 risk<=α 的档位里取覆盖率最高者。"""
    rc = risk_coverage(20)
    ok = [x for x in rc if x["risk"] is not None and x["risk"] <= alpha]
    if not ok:
        return {"ok": False, "alpha": alpha, "reason": "无任何阈值满足风险预算", "curve": rc}
    best = max(ok, key=lambda x: x["coverage"])
    return {"ok": True, "alpha": alpha, "threshold": best["threshold"],
            "coverage": best["coverage"], "risk": best["risk"], "n": best["n"]}


def drift(bucket: str = "week") -> dict:
    """漂移监控：按周/批次比较样本量、风险、覆盖率与平均置信度。"""
    rows = [r for r in _rows_scoped("global") if r.get("correct") in (0, 1)]
    buckets = {}
    for r in rows:
        ts = (r.get("created_at") or "")[:10]
        if bucket == "week" and len(ts) >= 10:
            import datetime as _dt
            try:
                d = _dt.date.fromisoformat(ts)
                key = f"{d.isocalendar()[0]}-W{d.isocalendar()[1]:02d}"
            except Exception:
                key = ts[:7]
        else:
            key = ts[:7]
        b = buckets.setdefault(key, {"n": 0, "correct": 0, "conf": 0.0})
        b["n"] += 1
        b["correct"] += r["correct"]
        b["conf"] += float(r.get("confidence") or 0)
    out = []
    prev = None
    for k in sorted(buckets):
        b = buckets[k]
        risk = 1 - b["correct"] / b["n"] if b["n"] else 0
        row = {"bucket": k, "n": b["n"], "risk": round(risk, 4),
               "avg_conf": round(b["conf"] / b["n"], 3) if b["n"] else 0}
        if prev is not None:
            row["risk_delta"] = round(risk - prev, 4)
        out.append(row)
        prev = risk
    alert = any((x.get("risk_delta") or 0) > 0.05 for x in out)
    return {"buckets": out, "alert": alert, "reason": "风险上升超过 5 个百分点" if alert else ""}


def replay_igain(rule_code: str) -> dict:
    """回放收益：该规则样本上的正确率相对 0.5 基线的提升（简单口径，非因果）。

    样本口径与其他 JEV 统计一致（当前租户/空间），避免跨租户样本冒充回放证据。
    """
    rows = [r for r in _scope_samples()
            if (r.get("rule_code") or "") == rule_code and r.get("correct") in (0, 1)]
    if not rows:
        return {"samples": 0, "acc": None, "igain": None}
    acc = sum(r["correct"] for r in rows) / len(rows)
    return {"samples": len(rows), "acc": round(acc, 3), "igain": round(acc - 0.5, 3)}
