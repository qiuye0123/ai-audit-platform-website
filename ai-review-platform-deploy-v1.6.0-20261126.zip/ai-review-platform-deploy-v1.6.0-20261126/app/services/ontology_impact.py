"""本体影响分析：一个术语变更会影响哪些规则、决策表、智能体和审核点。"""
import json
from .. import repositories as R


def impact(term: str) -> dict:
    t = str(term or "").strip()
    if not t:
        return {"term": "", "rules": [], "decision_tables": [], "agents": [], "count": 0,
                "note": "请输入标准名或别名"}
    low = t.lower()
    rules = []
    for r in R.rules.list(order="name ASC"):
        hit = t in (r.get("name") or "") or t in (r.get("source") or "")
        slots = {}
        try:
            v = R.rules.latest_version(r["id"]) or {}
            slots = json.loads(v.get("slots_json") or "{}")
            hit = hit or low in json.dumps(slots, ensure_ascii=False).lower()
        except Exception:
            pass
        if hit:
            rules.append({"code": r.get("code"), "name": r.get("name"),
                          "status": r.get("status"), "metric": slots.get("metric") or ""})
    tables = []
    for d in R.decision_tables.list(order="created_at DESC"):
        hit = t in (d.get("name") or "") or t in (d.get("source") or "")
        try:
            hit = hit or low in (d.get("rules_json") or "").lower()
        except Exception:
            pass
        if hit:
            tables.append({"code": d.get("code"), "name": d.get("name"),
                           "status": d.get("status"), "version": d.get("version")})
    agents = []
    for a in R.agents.list():
        try:
            prof = json.loads(a.get("profile_json") or "{}")
        except Exception:
            prof = {}
        blob = json.dumps(prof, ensure_ascii=False)
        if low in blob.lower():
            agents.append({"id": a.get("id"), "name": a.get("name"), "status": a.get("status")})
    return {"term": t, "rules": rules, "decision_tables": tables, "agents": agents,
            "count": len(rules) + len(tables) + len(agents),
            "note": "仅展示当前租户/空间可见内容；发布前请人工确认影响。"}
