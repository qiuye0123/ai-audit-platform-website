"""三态拆分：执行状态 / 复核状态 / 报告状态（不再用单一「已完成」）。"""
from .. import repositories as R


def compute(case_id: str) -> dict:
    case = R.cases.get(case_id) or {}
    findings = R.findings.by_case(case_id) if hasattr(R.findings, "by_case") else []
    pending = [f for f in findings if (f.get("status") or "pending") in ("pending", "")]
    critical_pending = [f for f in pending if (f.get("severity") or "") == "critical"]

    raw = (case.get("status") or "").lower()
    if raw in ("failed", "error"):
        exec_status = "执行失败"
    elif raw in ("running", "reviewing"):
        exec_status = "运行中"
    elif raw in ("completed", "done"):
        exec_status = "执行完成"
    else:
        exec_status = "未运行" if not findings else "执行完成"

    review_status = "待复核" if pending else "复核完成"

    signed = False
    for rep in (R.reports.list("case_id=?", (case_id,)) if hasattr(R, "reports") else []):
        if (rep.get("status") or "") in ("signed", "exported", "issued"):
            signed = True
            break
    report_status = "已签发" if signed else "未签发"

    return {
        "case_id": case_id,
        "exec_status": exec_status,
        "review_status": review_status,
        "report_status": report_status,
        "pending": len(pending),
        "critical_pending": len(critical_pending),
        "findings": len(findings),
    }


def label(case_id: str) -> str:
    s = compute(case_id)
    return f"{s['exec_status']} / {s['review_status']}（待复核 {s['pending']}） / {s['report_status']}"
