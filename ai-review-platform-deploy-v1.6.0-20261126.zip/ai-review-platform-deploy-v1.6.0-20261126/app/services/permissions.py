# -*- coding: utf-8 -*-
"""权限包（DB 权限点 / 角色权限包）——**派生自单一事实源** ``permission_registry``。

T-199（2026-11-20）起本模块不再手写 ``MODULES``/``DEFAULT_BUNDLES``：
``app/services/permission_registry.py`` 是唯一的 authoring 面，
``permission`` / ``role_permission`` 表只是它的**缓存/种子**（``ensure_seed`` 负责对账）。

本模块同时保留「系统管理员不可写审核业务」这一产品边界的**服务层事实源**（F-28 P0）：
- HTTP ``_guard`` 的白名单反向判定是第一道（URL 层）；
- ``write_denied``/``actor_write_denied`` 供路由/服务层做第二道角色校验，
  避免只靠 URL 前缀清单（新增业务前缀不会自动漏判）；
- 角色边界策略常量同样来自注册表 ``ROLE_POLICY``，此处只做同名再导出。
"""
from .. import db
from . import permission_registry as _reg

# 兼容导出（唯一事实源在 permission_registry.ROLE_POLICY，此处不重复维护）
BUSINESS_WRITE_DENY_ROLES = _reg.role_policy("business_write_deny_roles")
ONTOLOGY_ACCESS_ROLES = _reg.role_policy("ontology_access_roles")
TERMS_ACCESS_ROLES = _reg.role_policy("terms_access_roles")

# 派生：等价旧手写清单（(module, 展示名, [action]) 列表）
MODULES = list(_reg.modules())
# 派生：等价旧手写清单（role → 权限包；super_admin 为 ["*"]，种子时展开）
DEFAULT_BUNDLES = {role: list(bundle) for role, bundle in _reg.role_bundles().items()}


def ontology_denied(role: str) -> bool:
    """该角色是否禁止访问本体域接口（GET/POST 同口径，read 也拒绝，避免 types/instances/links 泄露）。"""
    return str(role or "").strip() not in ONTOLOGY_ACCESS_ROLES


def terms_denied(role: str) -> bool:
    """该角色是否禁止访问企业词典接口（GET/POST 同口径，read 也拒绝，避免术语/同义词/迁移状态泄露）。"""
    return str(role or "").strip() not in TERMS_ACCESS_ROLES


def write_denied(role: str) -> bool:
    """该角色是否禁止写审核业务（服务层第二道校验的纯函数事实源）。"""
    return str(role or "").strip() in BUSINESS_WRITE_DENY_ROLES


def actor_write_denied(actor: str) -> bool:
    """按账号的真实角色判断是否禁止写审核业务。

    服务层函数通常只拿到 actor（uid/用户名）而没有 role；这里回查账号角色，
    供 evolution/rsi/qa 等服务在路由未做权限校验时兜底。查不到角色的系统
    自动化 actor（scheduler/system 等）不视为越权。
    """
    aid = str(actor or "").strip()
    if not aid:
        return False
    try:
        from . import account as _account
        roles = set(_account.roles_of(aid) or [])
    except Exception:
        # P2-19：角色回查异常时 fail-closed（按“禁止写业务”处理），不能吞异常放行。
        import logging
        logging.getLogger(__name__).error(
            "actor role lookup failed（fail-closed，按禁止写审核业务处理）actor=%s",
            aid, exc_info=True)
        return True
    return bool(roles & set(BUSINESS_WRITE_DENY_ROLES))


def deny_write_payload(action: str = "") -> dict:
    """服务层拒绝写业务时的统一返回体（HTTP 路由据此映射 403）。"""
    return {"ok": False, "status": 403,
            "error": "系统管理员不访问审核业务" + (f"（{action}）" if action else ""),
            "code": "forbidden"}


def ensure_seed() -> dict:
    """把注册表灌进 DB（**缓存/种子**语义）：新增权限点、按角色对账权限包、清理过期缓存行。

    幂等；可重复调用（CLI/服务启动时都会调用）。DB 不一致以注册表为准：
    - ``permission``：缺失的插入；不在注册表的旧 code 删除（连带 role_permission）；
    - ``role_permission``：四个内置角色按注册表 bundle 增/删（自定义角色不动）。

    T-199 之后 role_permission 不再允许被手工当成第二事实源：菜单/按钮/HTTP/CLI
    的判定都从 ``permission_registry`` / 动作表派生。
    """
    plan = _reg.seed_rows()
    valid = {row[0] for row in plan["permissions"]}
    added = 0
    c = db.connect()
    try:
        for code, module, action, name in plan["permissions"]:
            cur = c.execute(
                "INSERT OR IGNORE INTO permission(code, module, action, name) VALUES(?,?,?,?)",
                (code, module, action, name))
            added += cur.rowcount
        stale = [r[0] for r in c.execute("SELECT code FROM permission") if r[0] not in valid]
        for code in stale:
            c.execute("DELETE FROM role_permission WHERE permission_code=?", (code,))
            c.execute("DELETE FROM permission WHERE code=?", (code,))
        for role_code, codes in plan["role_bundles"].items():
            rid = c.execute("SELECT id FROM role WHERE code=?", (role_code,)).fetchone()
            if not rid:
                continue
            want = set(codes)
            have = {r[0] for r in c.execute(
                "SELECT permission_code FROM role_permission WHERE role_id=?", (rid[0],))}
            for code in sorted(want - have):
                c.execute("INSERT OR IGNORE INTO role_permission(role_id, permission_code) VALUES(?,?)",
                          (rid[0], code))
            for code in sorted(have - want):
                c.execute("DELETE FROM role_permission WHERE role_id=? AND permission_code=?",
                          (rid[0], code))
        c.commit()
    finally:
        c.close()
    return {"permissions_added": added, "permission_points": len(plan["permissions"]),
            "stale_permission_rows_removed": len(stale),
            "roles": sorted(plan["role_bundles"])}


def of_user(user_id: str) -> list:
    c = db.connect()
    try:
        rows = c.execute(
            "SELECT DISTINCT rp.permission_code FROM user_role ur "
            "JOIN role_permission rp ON rp.role_id=ur.role_id WHERE ur.user_id=?", (user_id,)).fetchall()
    finally:
        c.close()
    return sorted({r[0] for r in rows})


def has(user_id: str, code: str) -> bool:
    perms = of_user(user_id)
    return code in perms or f"{code.split('.')[0]}.*" in perms


def menu_for(user_id: str) -> dict:
    """旧接口（DB 权限点视角的模块动作布尔表）；菜单渲染已统一走 ``permission.permissions``。"""
    perms = set(of_user(user_id))
    return {m: {a: (f"{m}.{a}" in perms) for a in acts} for m, _, acts in MODULES}
