"""规则性质 / 风险等级 / 业务严重度的唯一映射。

正交维度：
- nature：规则怎么判（5 类内部性质）
- rclass：风险等级 R0–R5（机器字段）
- severity：业务严重度 高/中/低（展示口径）
"""
from __future__ import annotations

# 唯一 5 类内部性质
NATURES = ("threshold", "obligation", "evidence", "relational", "procedural")
NATURE_LABELS = {
    "threshold": "阈值/数值",
    "obligation": "义务/禁止",
    "evidence": "事实/证据完备",
    "relational": "关系/一致性",
    "procedural": "流程/形式",
}

# rulegen 的 12 类必须全部有归宿；不允许“生成了类别但系统没有路由”
CATEGORY_TO_NATURE = {
    "limit": "threshold",
    "consistency": "relational",
    "completeness": "evidence",
    "format": "procedural",
    "preprocess": "procedural",
    "record": "evidence",
    "prohibited": "obligation",
    "frequency": "procedural",
    "personnel": "evidence",
    "equipment": "evidence",
    "label": "evidence",
    "citation": "relational",
}
CATEGORY_LABELS = {
    "limit": "限值", "consistency": "一致性", "completeness": "完整性",
    "format": "格式", "preprocess": "前处理", "record": "记录要求",
    "prohibited": "禁止性", "frequency": "时限/频率", "personnel": "人员资质",
    "equipment": "设备设施", "label": "标识标签", "citation": "引用一致",
}

# 风险等级 → 业务严重度（唯一投影）
RCLASS_TO_SEVERITY = {
    "R0": "critical", "R1": "critical",
    "R2": "warning", "R3": "warning", "R4": "warning",
    "R5": "suspected",
}
SEVERITY_LABELS = {"critical": "高", "warning": "中", "suspected": "低"}
LEVEL_TO_SEVERITY = {"高": "critical", "中": "warning", "低": "suspected"}
SEVERITY_ALIASES = {
    "P0": "critical", "P1": "warning", "P2": "suspected",
    "major": "warning", "minor": "suspected",
    "critical": "critical", "warning": "warning", "suspected": "suspected",
    "高": "critical", "中": "warning", "低": "suspected",
}


def nature_of(category: str, fallback: str = "obligation") -> str:
    return CATEGORY_TO_NATURE.get(str(category or "").strip(), fallback)


def severity_of(value: str, fallback: str = "warning") -> str:
    v = str(value or "").strip()
    if v in RCLASS_TO_SEVERITY:
        return RCLASS_TO_SEVERITY[v]
    return SEVERITY_ALIASES.get(v, fallback)




def validate() -> dict:
    errs = []
    for cat in CATEGORY_LABELS:
        if cat not in CATEGORY_TO_NATURE:
            errs.append(f"规则类别无性质归宿：{cat}")
    for cat, nat in CATEGORY_TO_NATURE.items():
        if nat not in NATURES:
            errs.append(f"性质不在 5 类：{cat}->{nat}")
    for r, sev in RCLASS_TO_SEVERITY.items():
        if sev not in SEVERITY_LABELS:
            errs.append(f"rclass 无严重度投影：{r}")
    return {"ok": not errs, "errors": errs, "categories": len(CATEGORY_LABELS),
            "natures": list(NATURES), "rclasses": len(RCLASS_TO_SEVERITY)}
