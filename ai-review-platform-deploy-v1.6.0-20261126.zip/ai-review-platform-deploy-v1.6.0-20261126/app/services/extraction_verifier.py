# -*- coding: utf-8 -*-
"""L155 Extractor-Verifier 独立校验器（确定性 / 0 模型 / 纯标准库）。

依据：`/tmp/2026_99.txt` §"Extractor-Verifier 双模型校验与交叉共识"——
独立 Verifier 只接收「原文切片 + 抽出的目标字段值」，专门审查三件事：

1. 是否为原文合法子串（``is_substring``）；
2. 是否夹带了相邻标签 / 括号注释 / 下一列或下一行文本（``contamination`` /
   ``label_bleed``）——**不允许把相邻列、括号注释、下一行文本当作值**；
3. 与文档内其它关联字段是否存在数学 / 逻辑冲突（``cross_field_ok``：明细合计=
   总额、日期先后、单位换算一致性）。

本模块只做「能由现有输入确定性验证」的部分，不用独立校验模型、不调 LLM、不联网、
不写库、不 import app 其它模块（纯 stdlib），因此可被 HTTP/CLI/离线脚本独立调用。

三态 verdict（与 L55 证书内核同口径）：

- ``pass``          = 所有适用检查通过（确认）；
- ``fail``          = 出现矛盾 / 污染 / 越界（fail-closed，不可直通）；
- ``insufficient``  = 输入不足（无文档、空值、数值写法歧义），**绝不静默 pass**。

字段类型（``type``）：``number`` / ``percent`` / ``date`` / ``code`` / ``text`` /
``range``（如 22~25℃）/ ``limit``（如 ≤4 h）。未显式给出时按值形态推断。

文档输入形态（``doc``）：

- ``str``：纯文本；
- ``dict``：``{"text": str, "tables": [...]}``。``tables`` 支持两种结构：
  ``{"sheet": "评分表", "rows": [[...], ...]}``（0 基行列）或
  ``{"sheet": "评分表", "cells": [{"row": 0, "col": "B"|1, "text": "..."}]}``。
  表格结构用于识别「相邻列 / 下一行」污染；没有表格结构时退化为文本启发式
  （分隔符 / 多值 / 括号注释 / 标签夹带）。

字段输入形态（``fields[i]``）::

    {"key": "amount", "label": "合同金额", "value": "120000.00",
     "raw": "120,000.00 元", "unit": "元", "type": "number",
     "quote": "合同金额：120,000.00 元", "start": 123, "end": 145,
     "cell": {"sheet": "评分表", "row": 2, "col": "B"}}  # 或 anchor="评分表!B3"

字段规格（``specs[key]``）::

    {"type": "number", "unit": "元", "units": ["元", "万元"],
     "min": 0, "max": 100000000, "pattern": "", "min_len": 2,
     "date_min": "2020-01-01", "date_max": "2030-12-31"}

跨字段断言（``assertions``）::

    {"id": "a1", "type": "sum", "total": "amount",
     "parts": ["i1", "i2"], "tolerance": 0.01, "name": "明细合计=总额"}
    {"id": "a2", "type": "date_order", "earlier": "sign_date", "later": "effective_date"}
    {"id": "a3", "type": "unit_consistency", "fields": ["w_g", "w_kg"], "tolerance": 0.01}
    {"id": "a4", "type": "equality", "fields": ["a", "b"]}
    {"id": "a5", "type": "range_relation", "left": "min_t", "right": "max_t", "op": "<="}

现有解析 facts（``app/engine/facts.py`` 的统一 schema）可通过
:func:`fields_from_facts` / :func:`assertions_from_facts` 构造成本模块输入；
:func:`verify_facts` 是一步式便捷入口。注意：facts 构造断言是启发式（只在无歧义时
构造），定位坐标（``char_start``）是 section 内偏移，不直接当文档绝对坐标使用。

边界（详见 `docs/qa/build55_ExtractorVerifier与字段置信_20261125.md`）：
本模块是**独立只读校验能力**，不产生 finding、不改 D1–D5 结论、不写数据库；
主链接入需要另立施工单（"能接主链 / 只能独立调用"边界见报告 §5）。
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata

VERIFIER_VERSION = "l155/v1"

VERDICT_PASS = "pass"
VERDICT_FAIL = "fail"
VERDICT_INSUFFICIENT = "insufficient"

# 输入上限（确定性预算，防超大请求拖垮进程；超出抛 VerificationInputError）
MAX_DOC_CHARS = 1_000_000
MAX_FIELDS = 2000
MAX_ASSERTIONS = 500
MAX_QUOTE_CHARS = 2_000

NUMBER_TYPES = ("number", "percent", "range", "limit")
_DATE_LIKE = re.compile(r"\d{4}\s*[年\-/\.]\s*\d{1,2}\s*[月\-/\.]\s*\d{1,2}")
_NUM_TOKEN_RE = re.compile(r"[+-]?(?:\d{1,3}(?:[,，]\d{3})+|\d+)(?:\.\d+)?")
_DATE_RE = re.compile(
    r"(\d{4})\s*[年\-/\.]\s*(\d{1,2})\s*[月\-/\.]\s*(\d{1,2})\s*日?")
_RANGE_RE = re.compile(
    r"^\s*([+-]?(?:\d{1,3}(?:[,，]\d{3})+|\d+)(?:\.\d+)?)\s*"
    r"(?:[~～\-—–]|至|到)\s*"
    r"([+-]?(?:\d{1,3}(?:[,，]\d{3})+|\d+)(?:\.\d+)?)\s*$")
_LIMIT_RE = re.compile(r"^\s*([≤≥<>＜＞=＝])\s*([+-]?\d+(?:\.\d+)?)\s*$")
_PAREN_RE = re.compile(r"[（(]([^（）()]{0,80})[）)]")
_TABLE_ANCHOR_RE = re.compile(r"^(.*?)!([A-Za-z]{1,3})(\d{1,6})$")
_WS_RE = re.compile(r"\s+")

# 允许作为「值」内聚形态的写法（不算串列/多值污染）
_COMPOSITE_HINTS = ("~", "～", "—", "–", "至", "到", "±", "≥", "≤", "<", ">", "×", "*", "/")
_ANNOTATION_HINT_RE = re.compile(
    r"(元|万元|亿元|%|‰|℃|°C|kg|KG|g|G|mg|毫克|克|千克|公斤|吨|ml|mL|L|升|毫升|mm|cm|m|km|"
    r"h|小时|分钟|min|秒|s|天|日|制|以.{0,12}为准|实际|参考|约|上限|下限|不含|含税|未税|"
    r"折合|汇率|手写|扫描|盖章|复印件|原件|注|说明|单位|备注)")

# 单位字典：别名 → (量纲族, 规范基准单位, 相对于基准单位的倍率)
UNIT_ALIASES = {
    # 温度（温度不做线性换算，只认同基准；℃/°C 视同）
    "℃": ("temp", "℃", 1.0), "°c": ("temp", "℃", 1.0), "°C": ("temp", "℃", 1.0),
    "摄氏度": ("temp", "℃", 1.0),
    # 质量
    "mg": ("mass", "g", 0.001), "毫克": ("mass", "g", 0.001),
    "g": ("mass", "g", 1.0), "克": ("mass", "g", 1.0),
    "kg": ("mass", "g", 1000.0), "千克": ("mass", "g", 1000.0), "公斤": ("mass", "g", 1000.0),
    "t": ("mass", "g", 1_000_000.0), "吨": ("mass", "g", 1_000_000.0),
    "斤": ("mass", "g", 500.0),
    # 金额
    "元": ("money", "元", 1.0), "块": ("money", "元", 1.0),
    "万元": ("money", "元", 10_000.0), "万": ("money", "元", 10_000.0),
    "亿元": ("money", "元", 100_000_000.0), "亿": ("money", "元", 100_000_000.0),
    # 长度
    "mm": ("length", "mm", 1.0), "毫米": ("length", "mm", 1.0),
    "cm": ("length", "mm", 10.0), "厘米": ("length", "mm", 10.0),
    "m": ("length", "mm", 1000.0), "米": ("length", "mm", 1000.0),
    "km": ("length", "mm", 1_000_000.0), "千米": ("length", "mm", 1_000_000.0),
    "公里": ("length", "mm", 1_000_000.0),
    # 体积
    "ml": ("volume", "ml", 1.0), "毫升": ("volume", "ml", 1.0),
    "l": ("volume", "ml", 1000.0), "L": ("volume", "ml", 1000.0), "升": ("volume", "ml", 1000.0),
    # 时间
    "s": ("time", "s", 1.0), "秒": ("time", "s", 1.0),
    "min": ("time", "s", 60.0), "分钟": ("time", "s", 60.0),
    "h": ("time", "s", 3600.0), "小时": ("time", "s", 3600.0),
    "天": ("time", "s", 86400.0), "日": ("time", "s", 86400.0),
    # 比例
    "%": ("percent", "%", 1.0), "％": ("percent", "%", 1.0),
    "‰": ("percent", "%", 0.1),
    "ppm": ("ratio", "ppm", 1.0), "mg/kg": ("ratio", "mg/kg", 1.0),
    "g/kg": ("ratio", "g/kg", 1.0), "mpa": ("pressure", "MPa", 1.0),
    "kpa": ("pressure", "MPa", 0.001), "pa": ("pressure", "MPa", 0.000001),
}
_CURRENCY_SYMBOLS = ("￥", "¥", "$", "€", "£")
_UNIT_KEYS_BY_LEN = sorted(UNIT_ALIASES, key=len, reverse=True)

FACT_KIND_TYPE = {
    "date": "date",
    "temp": "number", "time": "number", "conc": "number", "weight": "number",
    "percent": "number", "length": "number", "num": "number", "ratio": "number",
    "money": "number", "amount": "number", "temperature": "number",
    "id": "code", "version": "code", "code": "code", "placeholder": "code",
    "range": "range", "compare": "limit", "name": "text", "text": "text",
}

# facts 断言构造：合计类线索 / 日期角色线索（只在无歧义时构造）
_TOTAL_HINTS = re.compile(r"(合计|总额|总价|小计|总计|总金额|价税合计|汇 总|汇总)")
_DATE_ROLES = (
    ("publish", re.compile(r"(发布|公布)")),
    ("approve", re.compile(r"(批准|审批|签发|核准)")),
    ("sign", re.compile(r"(签订|签署|签约|签定)")),
    ("effective", re.compile(r"(生效|实施|执行|履行)")),
    ("start", re.compile(r"(开始|起始|开工|启用)")),
    ("end", re.compile(r"(结束|截止|终止|到期|失效)")),
)
_DATE_ORDER_PAIRS = (
    ("publish", "effective"), ("approve", "effective"),
    ("sign", "effective"), ("start", "end"),
)


class VerificationInputError(ValueError):
    """输入不合法（HTTP 层映射 400 invalid_request）。"""

    def __init__(self, message: str, code: str = "invalid_request"):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------------------
# 基础文本 / 数值 / 日期工具
# ---------------------------------------------------------------------------
def _s(value) -> str:
    if value is None:
        return ""
    return str(value)


def _nfkc(text: str) -> str:
    return unicodedata.normalize("NFKC", text or "")


def _collapse_ws(text: str) -> str:
    """空白折叠（用于“逐字”校验时容忍换行/多空格差异，不改变非空白字符）。"""
    return _WS_RE.sub(" ", (text or "")).strip()


def _norm_compare(text: str) -> str:
    return _collapse_ws(_nfkc(text))


def _build_ws_index(text: str) -> tuple:
    """空白折叠 + 原文偏移映射：返回 (norm_text, [raw_start_idx...], [raw_end_idx...])。

    只折叠“连续空白→单空格”并 strip，非空白字符一一对应，因此可把 norm 区间映射回
    原文区间，用于“引文被换行打断但逐字内容一致”的定位。
    """
    chars, starts, ends = [], [], []
    prev_ws = False
    for i, ch in enumerate(text or ""):
        if ch.isspace():
            if prev_ws:
                continue
            chars.append(" ")
            starts.append(i)
            ends.append(i + 1)
            prev_ws = True
        else:
            chars.append(ch)
            starts.append(i)
            ends.append(i + 1)
            prev_ws = False
    # strip 两端空白
    lo, hi = 0, len(chars)
    while lo < hi and chars[lo] == " ":
        lo += 1
    while hi > lo and chars[hi - 1] == " ":
        hi -= 1
    return "".join(chars[lo:hi]), starts[lo:hi], ends[lo:hi]


def _to_float(value) -> float | None:
    s = _s(value).strip().replace("，", "").replace(",", "")
    s = s.replace("−", "-").replace("－", "-")
    if not s:
        return None
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def _parse_date(value) -> tuple | None:
    """日期写法 → (y, m, d)；非法返回 None（不猜）。"""
    m = _DATE_RE.search(_s(value))
    if not m:
        return None
    try:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    except (TypeError, ValueError):
        return None
    if not (1900 <= y <= 2200 and 1 <= mo <= 12 and 1 <= d <= 31):
        return None
    try:
        import datetime as _dt
        _dt.date(y, mo, d)
        return (y, mo, d)
    except ValueError:
        return None


def _date_iso(value) -> str:
    got = _parse_date(value)
    if not got:
        return ""
    return "%04d-%02d-%02d" % got


def _parse_range(value) -> tuple | None:
    m = _RANGE_RE.match(_s(value).strip())
    if not m:
        return None
    lo, hi = _to_float(m.group(1)), _to_float(m.group(2))
    if lo is None or hi is None:
        return None
    return lo, hi


def _parse_limit(value) -> tuple | None:
    m = _LIMIT_RE.match(_s(value).strip())
    if not m:
        return None
    num = _to_float(m.group(2))
    if num is None:
        return None
    op = {"＜": "<", "＞": ">", "＝": "="}.get(m.group(1), m.group(1))
    return op, num


def _parse_number_unit(raw: str) -> tuple:
    """一段文本里的「数字 + 单位」→ (number, raw_unit, canonical, factor) 或 (None, ...)。

    只识别“数字紧邻单位”的写法（含货币符号前缀）；识别不了时 unit 为空，仍返回数字。
    """
    s = _nfkc(_s(raw)).strip()
    for sym in _CURRENCY_SYMBOLS:
        s = s.replace(sym, " ")
    s = s.strip()
    # 去掉常见前缀词（人民币/约/共/合计等），数字定位后再取其后单位
    m = _NUM_TOKEN_RE.search(s)
    if not m:
        return None, "", None, None
    num = _to_float(m.group(0))
    tail = s[m.end():].strip()
    unit = ""
    if tail:
        low = tail.lower()
        for key in _UNIT_KEYS_BY_LEN:
            if low.startswith(key.lower()):
                unit = key
                break
        if not unit:
            # 单位前可能有空白（“4 ℃”）已 strip；仍取一个短单位词（≤4 字符，中文/字母）
            um = re.match(r"([A-Za-z%‰]{1,5}|[\u4e00-\u9fa5]{1,2})", tail)
            if um:
                unit = um.group(1)
    info = _unit_canon(unit)
    return num, unit, (info if info[0] else None), (info[2] if info[0] else None)


def _unit_canon(unit: str):
    """单位 → (family, base_unit, factor)；未登记返回 (None, None, None)。"""
    u = _s(unit).strip()
    if not u:
        return None, None, None
    info = UNIT_ALIASES.get(u) or UNIT_ALIASES.get(u.lower())
    if info:
        return info
    # 兼底：全角/大小写差异
    for key, val in UNIT_ALIASES.items():
        if key.lower() == u.lower():
            return val
    return None, None, None


def _unit_of(field: dict) -> tuple:
    """字段声明的单位 → (family, canonical)。"""
    family, canon, _ = _unit_canon(_s(field.get("unit")))
    return family, canon


def _embedded_unit_of(field: dict) -> tuple:
    """raw/value 内嵌单位 → (family, canonical, factor)。"""
    for src in (_s(field.get("raw")), _s(field.get("value"))):
        if not src:
            continue
        _, unit, canon, factor = _parse_number_unit(src)
        if unit and canon:
            return canon[0], canon[1], factor
    return None, None, None


def _infer_type(field: dict, spec: dict | None = None) -> str:
    spec = spec or {}
    t = _s(spec.get("type") or field.get("type")).strip().lower()
    if t:
        return t
    value = _s(field.get("value") or field.get("raw"))
    if _parse_range(value):
        return "range"
    if _parse_limit(value):
        return "limit"
    if _parse_date(value):
        return "date"
    family, _ = _unit_of(field)
    if family is not None or _embedded_unit_of(field)[0] is not None:
        return "number"
    if _to_float(value) is not None:
        return "number"
    if re.search(r"[A-Za-z0-9\-〔〕\[\]（）()年第号\./]{3,}", value):
        return "code"
    return "text"


# ---------------------------------------------------------------------------
# 文档归一与定位
# ---------------------------------------------------------------------------
def normalize_document(doc) -> dict | None:
    """文档输入归一：``str`` 或 ``{"text":..., "tables":[...]}`` → 内部视图。

    返回 ``{"text","lines","line_starts","tables","has_text","chars"}``；
    ``doc is None`` 返回 ``None``（调用方按 insufficient 处理）。
    """
    if doc is None:
        return None
    if isinstance(doc, str):
        text, tables = doc, []
    elif isinstance(doc, dict):
        text = _s(doc.get("text") or doc.get("doc_text") or doc.get("content"))
        tables = doc.get("tables") or []
        if not isinstance(tables, list):
            tables = []
    else:
        text, tables = _s(doc), []
    if len(text) > MAX_DOC_CHARS:
        raise VerificationInputError(
            "文档文本过大（%d 字符 > %d 上限）" % (len(text), MAX_DOC_CHARS),
            code="document_too_large")
    lines = text.splitlines()
    line_starts, pos = [], 0
    for line in lines:
        line_starts.append(pos)
        pos += len(line) + 1
    return {"text": text, "lines": lines, "line_starts": line_starts,
            "tables": tables, "has_text": bool(text.strip()), "chars": len(text)}


def _doc_text(document) -> str:
    return _s((document or {}).get("text")) if isinstance(document, dict) else ""


def locate_quote(text: str, quote: str) -> dict:
    """在原文中定位引文（先逐字，再空白折叠），返回偏移与出现次数。

    返回 ``{"found","start","end","mode","occurrences"}``；
    ``mode`` ∈ ``exact`` / ``ws_normalized`` / ``none``。多次出现时取第一次，
    ``occurrences`` 供上层判“是否可唯一定位”。
    """
    q = _s(quote).strip()
    if not q or not text:
        return {"found": False, "start": None, "end": None,
                "mode": "none", "occurrences": 0}
    count = text.count(q)
    if count:
        i = text.find(q)
        return {"found": True, "start": i, "end": i + len(q),
                "mode": "exact", "occurrences": count}
    norm, starts, ends = _build_ws_index(text)
    cq = _collapse_ws(_nfkc(q))
    if not cq:
        return {"found": False, "start": None, "end": None,
                "mode": "none", "occurrences": 0}
    ncount = norm.count(cq)
    if ncount:
        i = norm.find(cq)
        s = starts[i]
        e = ends[i + len(cq) - 1]
        return {"found": True, "start": s, "end": e,
                "mode": "ws_normalized", "occurrences": ncount}
    return {"found": False, "start": None, "end": None,
            "mode": "none", "occurrences": 0}


def _locate_value(text: str, cand: str, type_: str, value) -> dict:
    """定位抽取值本身：逐字 → 空白折叠 → 数值等价（唯一时）。"""
    loc = locate_quote(text, cand)
    if loc["found"]:
        return {"found": True, "start": loc["start"], "end": loc["end"],
                "mode": loc["mode"], "occurrences": loc["occurrences"]}
    # 数值等价：规范值（如 120000.0）与原文写法（120,000）不同但数值相同
    if type_ in NUMBER_TYPES:
        target = _to_float(value if value is not None else cand)
        if target is not None:
            hits = []
            for m in _NUM_TOKEN_RE.finditer(text):
                num = _to_float(m.group(0))
                if num is None:
                    continue
                if abs(num - target) <= max(1e-9, abs(target) * 1e-9):
                    hits.append((m.start(), m.end()))
            if len(hits) == 1:
                return {"found": True, "start": hits[0][0], "end": hits[0][1],
                        "mode": "numeric_equivalent", "occurrences": 1}
            if len(hits) > 1:
                return {"found": True, "start": hits[0][0], "end": hits[0][1],
                        "mode": "numeric_equivalent", "occurrences": len(hits)}
    return {"found": False, "start": None, "end": None,
            "mode": "none", "occurrences": 0}


def _field_cell(field: dict) -> dict | None:
    """字段的表格坐标：``cell`` dict 或 ``anchor="评分表!B3"``（1 基行/列）。"""
    cell = field.get("cell")
    if isinstance(cell, dict) and cell.get("sheet") is not None:
        return {"sheet": _s(cell.get("sheet")),
                "row": _col_to_index(cell.get("row")),
                "col": _col_to_index(cell.get("col"))}
    anchor = _s(field.get("anchor"))
    m = _TABLE_ANCHOR_RE.match(anchor)
    if m:
        return {"sheet": m.group(1), "row": int(m.group(3)) - 1,
                "col": _letters_to_index(m.group(2))}
    return None


def _letters_to_index(letters) -> int:
    s = _s(letters).strip().upper()
    if not s:
        return -1
    if s.isdigit():
        return int(s) - 1
    if not s.isalpha():
        return -1
    out = 0
    for ch in s:
        out = out * 26 + (ord(ch) - ord("A") + 1)
    return out - 1


def _col_to_index(col) -> int:
    """列：字母（A/B/.../AA）或 0/1 基整数；Excel 字母按 1 基 → 返回 0 基。"""
    if isinstance(col, int):
        return col
    s = _s(col).strip()
    if not s:
        return -1
    if s.isdigit():
        return int(s) - 1
    return _letters_to_index(s)


def _table_cell_map(document: dict) -> dict:
    """把 doc.tables 归一成 ``{(sheet, row, col): text}``（0 基 row/col）。"""
    out = {}
    for table in (document or {}).get("tables") or []:
        if not isinstance(table, dict):
            continue
        sheet = _s(table.get("sheet") or table.get("name"))
        cells = table.get("cells")
        if isinstance(cells, list):
            for cell in cells:
                if not isinstance(cell, dict):
                    continue
                r, c = _col_to_index(cell.get("row")), _col_to_index(cell.get("col"))
                if r < 0 or c < 0:
                    continue
                out[(sheet, r, c)] = _s(cell.get("text") or cell.get("value"))
        rows = table.get("rows")
        if isinstance(rows, list):
            for r, row in enumerate(rows):
                if not isinstance(row, (list, tuple)):
                    continue
                for c, val in enumerate(row):
                    out[(sheet, r, c)] = _s(val)
    return out


def _neighbor_cells(document: dict, cell: dict) -> list:
    """相邻单元格（同行左右列 = 相邻列污染；同列下一行 = 下一行污染）。"""
    cmap = _table_cell_map(document)
    if not cmap:
        return []
    sheet = cell.get("sheet")
    row, col = cell.get("row"), cell.get("col")
    if row is None or col is None or row < 0 or col < 0:
        return []
    out = []
    own = cmap.get((sheet, row, col))
    for direction, (dr, dc) in (("left", (0, -1)), ("right", (0, 1)),
                                ("below", (1, 0)), ("above", (-1, 0))):
        text = cmap.get((sheet, row + dr, col + dc))
        if text and text.strip() and text != own:
            kind = "next_line" if direction in ("below", "above") else "adjacent_column"
            out.append({"direction": direction, "text": text.strip(), "kind": kind})
    return out


# ---------------------------------------------------------------------------
# 逐项检查：子串 / 污染 / 标签夹带
# ---------------------------------------------------------------------------
def check_substring(field: dict, document: dict | None, type_: str) -> dict:
    """检查抽取值是否为原文合法子串，并尽量给出坐标。"""
    value = field.get("value")
    raw = _s(field.get("raw"))
    cand = raw or _s(value)
    text = _doc_text(document)
    out = {"is_substring": None, "mode": "none", "start": None, "end": None,
           "occurrences": 0, "candidate": cand, "span_ok": None,
           "quote_found": False, "quote": _s(field.get("quote"))[:MAX_QUOTE_CHARS],
           "detail": ""}
    if document is None or not text.strip():
        out["detail"] = "无文档文本，无法校验原文命中（insufficient）"
        return out
    if not cand.strip():
        out["detail"] = "空值，无法校验原文命中"
        return out
    loc = _locate_value(text, cand, type_, value)
    if loc["found"]:
        out.update({"is_substring": True, "mode": loc["mode"],
                    "start": loc["start"], "end": loc["end"],
                    "occurrences": loc["occurrences"]})
    else:
        out["is_substring"] = False
        out["detail"] = "抽取值在原文中找不到对应子串/数值"
    # 引文 / 坐标校验
    quote = _s(field.get("quote"))
    if quote:
        qloc = locate_quote(text, quote)
        out["quote_found"] = qloc["found"]
        if qloc["found"] and out["start"] is None:
            out["start"], out["end"] = qloc["start"], qloc["end"]
            out["mode"] = "quote_only" if out["is_substring"] else out["mode"]
    start, end = field.get("start"), field.get("end")
    if isinstance(start, int) and isinstance(end, int) and not isinstance(start, bool):
        span_ok = False
        if 0 <= start < end <= len(text):
            span = text[start:end]
            if quote:
                span_ok = _norm_compare(span) == _norm_compare(quote)
            elif out["start"] is not None:
                span_ok = (start <= out["start"] and out["end"] <= end)
            else:
                span_ok = _norm_compare(span) == _norm_compare(cand)
        out["span_ok"] = span_ok
        if span_ok:
            out["start"], out["end"] = start, end
    elif out["start"] is not None:
        # 没有显式坐标时，用定位结果衡量“可唯一定位”
        out["span_ok"] = out["occurrences"] == 1
    if not out["is_substring"] and out["start"] is not None and quote:
        # 引文在原文但值不在：仍判 is_substring=False（值不可核验）
        out["detail"] = out["detail"] or "引文可定位，但抽取值本身不是原文子串"
    return out


def _annotation_like(segment: str) -> bool:
    return bool(_ANNOTATION_HINT_RE.search(_s(segment)))


def _line_of(text: str, pos: int) -> tuple:
    """返回 (行号 0 基, 行文本)。"""
    if pos is None:
        return -1, ""
    before = text[:max(0, pos)]
    line_no = before.count("\n")
    start = before.rfind("\n") + 1
    end = text.find("\n", start)
    if end < 0:
        end = len(text)
    return line_no, text[start:end]


def check_contamination(field: dict, document: dict | None, sub: dict,
                        type_: str) -> dict:
    """检查值是否夹带相邻列 / 括号注释 / 下一行文本 / 多值串。

    返回 ``{"hit": bool, "kinds": [...], "items": [{kind, segment, ...}]}``。
    """
    items = []
    seen = set()

    def add(kind, detail=None, segment=""):
        if kind in seen and not detail:
            return
        seen.add(kind)
        items.append({"kind": kind, "segment": _s(segment)[:160],
                      "detail": _s(detail)[:300]})

    if document is None:
        return {"hit": False, "kinds": [], "items": [], "checked": False}
    candidates = []
    if _s(field.get("raw")):
        candidates.append(("raw", _s(field.get("raw"))))
    if _s(field.get("value")):
        candidates.append(("value", _s(field.get("value"))))
    if not candidates:
        return {"hit": False, "kinds": [], "items": [], "checked": True}

    text = _doc_text(document)
    for origin, cand in candidates:
        s = cand.strip()
        if not s:
            continue
        paren_hit = False
        # 1) 括号注释（数值/日期/编码类一律视为污染；文本类只在注释像“单位/备注”时判污染）
        m = _PAREN_RE.search(s)
        if m:
            if type_ in NUMBER_TYPES or type_ in ("date", "code") or _annotation_like(m.group(1)):
                paren_hit = True
                add("parenthesis_annotation",
                    "括号注释不得作为值（%s）：%s" % (origin, m.group(0)), m.group(0))
        # 2) 换行：值本身跨行 = 把下一行文本当值
        if "\n" in s or "\r" in s:
            add("next_line", "值内包含换行（%s）" % origin, s.replace("\n", "\\n")[:80])
        # 3) 表格分隔符 / 分号：相邻列被拍平进值
        if "\t" in s or " | " in s or "｜" in s or "||" in s:
            add("adjacent_column", "值内包含表格列分隔符（%s）" % origin, s[:80])
        elif type_ not in ("text",) and ("；" in s or ";" in s):
            add("adjacent_column", "值内包含分号（%s）" % origin, s[:80])
        # 4) 多值串：非日期/区间/编码写法下出现 ≥2 个数字（括号注释已单独记，不重复判）
        if type_ not in ("code", "text", "range", "limit", "date") and not paren_hit:
            nums = _NUM_TOKEN_RE.findall(s)
            if len(nums) >= 2 and not _DATE_LIKE.search(s) and not _parse_range(s):
                add("adjacent_column", "值内出现多个数值（%s）：%s" % (origin, nums), s[:80])
        if type_ == "code" and re.search(r"\s", s):
            # 编码类不应含内部空白（“A123 B456”=串列）
            add("adjacent_column", "编码值内含空白（%s）" % origin, s[:80])
        # 5) 截断/粘连标点（值以标签分隔符结尾 = 只抽到标签没抽到值）
        if s.endswith((":", "：", "|", "｜")):
            add("trailing_separator", "值以标签分隔符结尾（%s）" % origin, s[:80])
        if s.endswith(("、", "，", ",")) and type_ not in ("text",):
            add("trailing_separator", "值以顿号/逗号结尾（%s）" % origin, s[:80])

    # 6) 表格相邻列 / 下一行（有结构时最可靠）
    cell = _field_cell(field)
    if cell:
        for nb in _neighbor_cells(document, cell):
            for origin, cand in candidates:
                if nb["text"] and nb["text"] in cand:
                    add(nb["kind"],
                        "值夹带相邻单元格（%s，%s 方向）：%s"
                        % (origin, nb["direction"], nb["text"]), nb["text"])
    # 7) 无表格结构时：若值 == 所在整行且行内有 | 分隔 → 相邻列污染
    if not cell and sub.get("start") is not None:
        _, line = _line_of(text, sub["start"])
        if " | " in line and _norm_compare(line) == _norm_compare(candidates[0][1]):
            add("adjacent_column", "整行（含列分隔符）被当作值", line[:80])

    return {"hit": bool(items), "kinds": sorted(seen), "items": items, "checked": True}


def _label_pairs(field: dict, context: dict) -> tuple:
    """(own_labels, other_labels)：own 含 spec/字段标签；other 排除 own 的自包含关系。"""
    spec = (context or {}).get("spec") or {}
    own = []
    for cand in (field.get("label"), field.get("key"), spec.get("label")):
        s = _s(cand).strip()
        if len(s) >= 2 and s not in own:
            own.append(s)
    for cand in (spec.get("aliases") or []):
        s = _s(cand).strip()
        if len(s) >= 2 and s not in own:
            own.append(s)
    key = _s(field.get("key"))
    others = {}
    for item in ((context or {}).get("fields") or []):
        if not isinstance(item, dict) or _s(item.get("key")) == key:
            continue
        for cand in (item.get("label"), item.get("key")):
            s = _s(cand).strip()
            if len(s) < 2 or s in own:
                continue
            if any(s in own_label for own_label in own):
                continue  # 短标签是自身标签子串 → 歧义，不判外标签
            others[s] = _s(item.get("key")) or s
    for skey, sspec in ((context or {}).get("specs") or {}).items():
        if _s(skey) == key or not isinstance(sspec, dict):
            continue
        s = _s(sspec.get("label")).strip()
        if len(s) >= 2 and s not in own and not any(s in x for x in own):
            others.setdefault(s, _s(skey))
    return own, others


def check_label_bleed(field: dict, document: dict | None, sub: dict,
                      context: dict | None) -> dict:
    """检查标签夹带：值里含自身/其它字段标签，或值落在错误标签下。"""
    context = context or {}
    own, others = _label_pairs(field, context)
    text = _doc_text(document)
    start = sub.get("start")
    cand = _s(sub.get("candidate") or field.get("raw") or field.get("value")).strip()
    items, seen = [], set()

    def add(kind, detail, segment=""):
        key = (kind, detail)
        if key in seen:
            return
        seen.add(key)
        items.append({"kind": kind, "detail": _s(detail)[:300],
                      "segment": _s(segment)[:160]})

    for label in own:
        if label and label in cand:
            if _norm_compare(cand) == _norm_compare(label):
                add("label_only", "值只有标签、没有实际内容：%s" % label, label)
            else:
                add("self_label", "值夹带自身标签「%s」" % label, cand[:80])
    for label, other_key in others.items():
        if label and label in cand:
            add("foreign_label", "值夹带其它字段标签「%s」（%s）"
                % (label, other_key), cand[:80])

    # 值落在错误标签下：沿值前面最近的标签判断（同一行/无句子中断）。
    # 精度优先：只把「外标签 + 分隔符/空白 + 值」这种直接取值位判为标签夹带；
    # 纯空白紧邻仅在 foreign 标签 ≥3 字且没有更近的自身标签时才判（避免“冷藏库温度”
    # 里的“温度”这种复合词误伤）。
    # 且只有坐标明确（显式 start/end，或原文唯一命中）时才做“错误标签上下文”判断；
    # 多次出现的短值（如 "1"）无法确定落在哪个标签下，不得据此判 fail。
    ambiguous_pos = (field.get("start") is None or field.get("end") is None) \
        and (sub.get("occurrences") or 0) != 1
    if start is not None and text and not ambiguous_pos:
        window = text[max(0, start - 80):start]
        own_end = -1
        for label in own:
            pos = window.rfind(label)
            if pos >= 0:
                own_end = max(own_end, pos + len(label))
        foreign_end, foreign_label = -1, ""
        for label in others:
            pos = window.rfind(label)
            if pos < 0:
                continue
            sep_tail = window[pos + len(label):]
            has_sep = bool(re.fullmatch(r"[\s:：=\-—]*[:：=][\s:：=\-—]*", sep_tail))
            has_space = bool(sep_tail) and not sep_tail.strip()
            if not has_sep and not (has_space and len(label) >= 3):
                continue
            if pos + len(label) > foreign_end:
                foreign_end, foreign_label = pos + len(label), label
        # 外标签比自身标签更靠近取值位 → 值落在了别的字段标签下（标签串位）
        if foreign_label and foreign_end > own_end:
            add("wrong_label_context",
                "值位于其它字段标签「%s」之下（标签夹带）" % foreign_label,
                text[max(0, start - 80):start + 40])
    return {"hit": bool(items), "kinds": sorted({x["kind"] for x in items}),
            "items": items, "labels_checked": len(own) + len(others)}


# ---------------------------------------------------------------------------
# 逐项检查：单位 / 范围
# ---------------------------------------------------------------------------
def check_unit(field: dict, spec: dict, type_: str) -> dict:
    """单位校验：量纲一致 + 允许单位 + 内嵌单位换算一致性。

    返回 ``{"ok": bool|None, "kind": str, "expected","declared","embedded",
    "converted","value","detail"}``；``ok=None`` = 该字段无单位约束（不适用）。
    """
    spec = spec or {}
    expected = _s(spec.get("unit"))
    allowed = [x for x in (spec.get("units") or []) if _s(x).strip()]
    declared_family, declared_canon = _unit_of(field)
    embedded_family, embedded_canon, embedded_factor = _embedded_unit_of(field)
    value_num = _to_float(field.get("value"))
    out = {"ok": None, "kind": "not_applicable", "expected": expected,
           "allowed": allowed, "declared": _s(field.get("unit")),
           "embedded": embedded_canon or "", "converted": None,
           "value": field.get("value"), "detail": ""}
    if not expected and not allowed:
        out["detail"] = "字段无单位约束（不适用）"
        return out
    # 约束目标单位
    target = expected or _s(allowed[0])
    tfam, tcanon, tfactor = _unit_canon(target)
    if tfam is None:
        out["detail"] = "规格单位未登记，无法校验：%s" % target
        out["kind"] = "unknown_expected_unit"
        out["ok"] = False
        return out
    # 声明单位 / 内嵌单位的量纲必须与目标一致
    for origin, fam, canon in (("declared", declared_family, declared_canon),
                               ("embedded", embedded_family, embedded_canon)):
        if fam is not None and tfam is not None and fam != tfam:
            out.update({"ok": False, "kind": "unit_mismatch",
                        "detail": "%s 单位量纲不一致：%s vs 期望 %s"
                                  % (origin, canon, target)})
            return out
    # 允许单位清单：规范基准单位必须在允许清单的规范基准内
    if allowed:
        allow_bases = set()
        for a in allowed:
            af, ac, _ = _unit_canon(a)
            if af is None:
                allow_bases.add(_s(a))
            elif ac:
                allow_bases.add(ac)
        got_base = declared_canon or embedded_canon
        if got_base and got_base not in allow_bases:
            out.update({"ok": False, "kind": "unit_mismatch",
                        "detail": "单位 %s 不在允许清单 %s" % (got_base, allowed)})
            return out
    # 期望单位（spec.unit）作为规范基准：声明单位若与它同族但不同基准，需换算值核验
    if expected:
        got_base = declared_canon or embedded_canon
        if got_base is None and not declared_family and not embedded_family:
            out.update({"ok": False, "kind": "missing_unit",
                        "detail": "期望单位 %s，但字段未声明也无可解析内嵌单位" % expected})
            return out
        # 换算一致性：raw 内嵌单位 + 数字 换算到目标单位后应等于 value
        raw = _s(field.get("raw"))
        raw_num, _, raw_canon, raw_factor = _parse_number_unit(raw) if raw else (None, "", None, None)
        if (raw_num is not None and raw_canon and raw_factor is not None
                and value_num is not None):
            # 目标基准：优先 spec.unit 规范基准；否则用声明单位规范基准
            base_canon = tcanon or declared_canon or raw_canon
            if raw_canon[0] == tfam:
                converted = raw_num * raw_factor / (tfactor or 1.0)
                out["converted"] = round(converted, 6)
                tol = max(1e-6, abs(converted) * 0.001, abs(value_num) * 1e-9)
                # 允许“千分位/四舍五入”1‰ 误差
                if abs(converted - value_num) > tol:
                    out.update({"ok": False, "kind": "conversion_mismatch",
                                "detail": "内嵌单位换算不一致：%s %s → %.6g %s，但值为 %s"
                                          % (raw_num, raw_canon[1], converted,
                                             tfactor and tcanon or base_canon,
                                             value_num)})
                    return out
    out["ok"] = True
    out["kind"] = "ok"
    out["detail"] = "单位校验通过（目标 %s）" % target
    return out


def _check_bounds(num: float, spec: dict) -> tuple:
    """数值 min/max（含端点）→ (ok, detail)。"""
    lo, hi = spec.get("min"), spec.get("max")
    if lo is not None:
        lo_f = _to_float(lo)
        if lo_f is not None and num < lo_f - 1e-12:
            return False, "小于下限 %s（值 %s）" % (lo, num)
    if hi is not None:
        hi_f = _to_float(hi)
        if hi_f is not None and num > hi_f + 1e-12:
            return False, "大于上限 %s（值 %s）" % (hi, num)
    return True, ""


def check_range(field: dict, spec: dict, type_: str) -> dict:
    """范围/类型校验：数值 min-max、日期合法与区间、编码正则、文本长度。

    ``ok=None`` = 无范围约束（不适用）。数值/日期解析失败属于 fail（fail-closed）。
    """
    spec = spec or {}
    out = {"ok": None, "kind": "not_applicable", "detail": "", "parsed": None}
    value = field.get("value")
    text = _s(value if value is not None else field.get("raw")).strip()
    if not text:
        out["detail"] = "空值（不适用范围校验）"
        return out
    if type_ in ("number", "percent"):
        num = _to_float(text)
        if num is None:
            out.update({"ok": False, "kind": "not_numeric",
                        "detail": "数值字段无法解析为数字：%s" % text[:60]})
            return out
        out["parsed"] = num
        ok, why = _check_bounds(num, spec)
        out.update({"ok": ok, "kind": "ok" if ok else "out_of_range", "detail": why})
        return out
    if type_ == "date":
        iso = _date_iso(text)
        if not iso:
            out.update({"ok": False, "kind": "invalid_date",
                        "detail": "日期字段非法：%s" % text[:60]})
            return out
        out["parsed"] = iso
        lo, hi = _s(spec.get("date_min")), _s(spec.get("date_max"))
        if lo and iso < lo:
            out.update({"ok": False, "kind": "out_of_range",
                        "detail": "日期早于下限 %s（%s）" % (lo, iso)})
            return out
        if hi and iso > hi:
            out.update({"ok": False, "kind": "out_of_range",
                        "detail": "日期晚于上限 %s（%s）" % (hi, iso)})
            return out
        out.update({"ok": True, "kind": "ok"})
        return out
    if type_ == "code":
        pat = _s(spec.get("pattern"))
        if pat:
            try:
                if not re.search(pat, text):
                    out.update({"ok": False, "kind": "pattern_mismatch",
                                "detail": "编码不匹配正则：%s" % pat})
                    return out
            except re.error:
                out.update({"ok": None, "kind": "invalid_spec_pattern",
                            "detail": "规格正则非法：%s" % pat})
                return out
        ok, why = _check_len(text, spec)
        if not ok:
            out.update({"ok": False, "kind": "length_out_of_range", "detail": why})
            return out
        out.update({"ok": True if pat or spec.get("min_len") is not None
                    or spec.get("max_len") is not None else None,
                    "kind": "ok" if pat else "not_applicable"})
        return out
    if type_ == "text":
        ok, why = _check_len(text, spec)
        if not ok:
            out.update({"ok": False, "kind": "length_out_of_range", "detail": why})
            return out
        constrained = (spec.get("min_len") is not None or spec.get("max_len") is not None)
        out.update({"ok": True if constrained else None,
                    "kind": "ok" if constrained else "not_applicable"})
        return out
    if type_ == "range":
        got = _parse_range(text)
        if not got:
            out.update({"ok": False, "kind": "invalid_range",
                        "detail": "区间写法无法解析：%s" % text[:60]})
            return out
        lo, hi = got
        if lo > hi:
            out.update({"ok": False, "kind": "inverted_range",
                        "detail": "区间上下界颠倒：%s > %s" % (lo, hi)})
            return out
        out["parsed"] = [lo, hi]
        for num in (lo, hi):
            ok, why = _check_bounds(num, spec)
            if not ok:
                out.update({"ok": False, "kind": "out_of_range", "detail": why})
                return out
        out.update({"ok": True, "kind": "ok"})
        return out
    if type_ == "limit":
        got = _parse_limit(text)
        if not got:
            out.update({"ok": False, "kind": "invalid_limit",
                        "detail": "阈值写法无法解析：%s" % text[:60]})
            return out
        op, num = got
        out["parsed"] = [op, num]
        hi = _to_float(spec.get("max"))
        lo = _to_float(spec.get("min"))
        if hi is not None and op in ("<", "<=", "≤", "=") and num > hi + 1e-12:
            out.update({"ok": False, "kind": "out_of_range",
                        "detail": "阈值 %s%s 超出上限 %s" % (op, num, hi)})
            return out
        if lo is not None and op in (">", ">=", "≥", "=") and num < lo - 1e-12:
            out.update({"ok": False, "kind": "out_of_range",
                        "detail": "阈值 %s%s 低于下限 %s" % (op, num, lo)})
            return out
        out.update({"ok": True, "kind": "ok"})
        return out
    out["detail"] = "未知字段类型：%s" % type_
    return out


def _check_len(text: str, spec: dict) -> tuple:
    lo = spec.get("min_len")
    hi = spec.get("max_len")
    if lo is not None:
        try:
            if len(text) < int(lo):
                return False, "长度 %d 小于下限 %s" % (len(text), lo)
        except (TypeError, ValueError):
            pass
    if hi is not None:
        try:
            if len(text) > int(hi):
                return False, "长度 %d 大于上限 %s" % (len(text), hi)
        except (TypeError, ValueError):
            pass
    return True, ""


# ---------------------------------------------------------------------------
# 跨字段断言
# ---------------------------------------------------------------------------
def _assertion_keys(assertion: dict) -> list:
    keys = []
    for name in ("total", "left", "right", "earlier", "later"):
        v = _s(assertion.get(name)).strip()
        if v:
            keys.append(v)
    for name in ("parts", "fields"):
        for v in (assertion.get(name) or []):
            if _s(v).strip():
                keys.append(_s(v).strip())
    out = []
    for k in keys:
        if k not in out:
            out.append(k)
    return out


def _field_number(field: dict) -> tuple:
    """字段 → (number, family, canonical, factor)；解析不了 number=None。

    ``factor`` 是「该字段数值 → 规范基准单位」的倍率（如字段单位 kg、基准 g → 1000）。
    """
    num = _to_float(field.get("value"))
    if num is None:
        raw = _s(field.get("raw"))
        if raw:
            num = _parse_number_unit(raw)[0]
    family, canon, factor = _unit_canon(_s(field.get("unit")))
    if family is None:
        family, canon, factor = _embedded_unit_of(field)
    return num, family, canon, (factor or 1.0)


def _eval_sum(assertion: dict, fields: dict) -> dict:
    total_key = _s(assertion.get("total"))
    total_field = fields.get(total_key) or {}
    total_num, total_fam, total_canon, total_factor = _field_number(total_field)
    part_keys = [_s(k) for k in (assertion.get("parts") or []) if _s(k)]
    out = {"total": total_key, "parts": {}, "sum": None, "diff": None}
    if total_num is None:
        return {"status": "insufficient", "detail": "总额字段缺失或非数值：%s" % total_key,
                "computed": out}
    total_factor = total_factor or 1.0
    # 统一换算到「规范基准单位」后比较：g/kg、元/万元等混用不能直接相加
    total_base = total_num * total_factor
    acc = 0.0
    for key in part_keys:
        part = fields.get(key) or {}
        num, fam, canon, factor = _field_number(part)
        if num is None:
            return {"status": "insufficient",
                    "detail": "明细字段缺失或非数值：%s" % key, "computed": out}
        # 族必须一致（金额 vs 质量不能相加）
        if fam and total_fam and fam != total_fam:
            return {"status": "insufficient",
                    "detail": "明细 %s 与总额 %s 单位量纲不同（%s vs %s）"
                              % (key, total_key, fam, total_fam), "computed": out}
        base = num * (factor or 1.0)
        out["parts"][key] = round(base, 6)
        acc += base
    out["sum"] = round(acc, 6)
    out["total_base"] = round(total_base, 6)
    out["diff"] = round(acc - total_base, 6)
    tol = assertion.get("tolerance")
    if tol is None:
        tol = max(0.01, abs(total_base) * 0.001)
    try:
        tol_f = abs(float(tol))
    except (TypeError, ValueError):
        tol_f = max(0.01, abs(total_base) * 0.001)
    out["tolerance"] = tol_f
    if abs(out["diff"]) <= tol_f:
        return {"status": "pass", "detail": "明细合计 %.6g 与总额 %.6g（基准单位）一致"
                "（差 %.6g ≤ %s）" % (acc, total_base, out["diff"], round(tol_f, 6)),
                "computed": out}
    return {"status": "fail", "detail": "明细合计 %.6g ≠ 总额 %.6g（基准单位，差 %.6g > %s）"
            % (acc, total_base, out["diff"], round(tol_f, 6)), "computed": out}


def _eval_date_order(assertion: dict, fields: dict) -> dict:
    e_key, l_key = _s(assertion.get("earlier")), _s(assertion.get("later"))
    e_iso = _date_iso((fields.get(e_key) or {}).get("value"))
    l_iso = _date_iso((fields.get(l_key) or {}).get("value"))
    computed = {"earlier": e_iso, "later": l_iso}
    if not e_iso or not l_iso:
        return {"status": "insufficient",
                "detail": "日期字段缺失或非法：%s=%s / %s=%s"
                          % (e_key, e_iso or "缺失", l_key, l_iso or "缺失"),
                "computed": computed}
    if e_iso <= l_iso:
        return {"status": "pass", "detail": "%s(%s) 不晚于 %s(%s)"
                % (e_key, e_iso, l_key, l_iso), "computed": computed}
    return {"status": "fail", "detail": "日期先后矛盾：%s(%s) 晚于 %s(%s)"
            % (e_key, e_iso, l_key, l_iso), "computed": computed}


def _eval_unit_consistency(assertion: dict, fields: dict) -> dict:
    keys = [_s(k) for k in (assertion.get("fields") or []) if _s(k)]
    computed = {"items": []}
    if len(keys) < 2:
        return {"status": "insufficient", "detail": "单位一致性断言至少需要 2 个字段",
                "computed": computed}
    base_fam = base_canon = base_factor = None
    values = []
    for key in keys:
        field = fields.get(key) or {}
        num, fam, canon, factor = _field_number(field)
        if num is None:
            return {"status": "insufficient", "detail": "字段缺失或非数值：%s" % key,
                    "computed": computed}
        if fam is None:
            return {"status": "insufficient", "detail": "字段缺单位，无法做换算一致性：%s" % key,
                    "computed": computed}
        if base_fam is None:
            base_fam, base_canon, base_factor = fam, canon, factor or 1.0
        elif fam != base_fam:
            return {"status": "insufficient",
                    "detail": "字段量纲不同（%s vs %s）" % (base_fam, fam),
                    "computed": computed}
        base = num * (factor or 1.0) / (base_factor or 1.0)
        values.append(base)
        computed["items"].append({"key": key, "value": num, "unit": canon or "",
                                  "base": round(base, 6)})
    tol = assertion.get("tolerance")
    try:
        tol_f = abs(float(tol)) if tol is not None else 0.01
    except (TypeError, ValueError):
        tol_f = 0.01
    lo, hi = min(values), max(values)
    rel = (hi - lo) / max(1e-12, abs(hi))
    computed.update({"min": round(lo, 6), "max": round(hi, 6),
                     "rel_diff": round(rel, 8), "tolerance": tol_f})
    if rel <= tol_f:
        return {"status": "pass", "detail": "单位换算后一致（相对差 %.6g ≤ %s）"
                % (rel, tol_f), "computed": computed}
    return {"status": "fail", "detail": "单位换算后不一致（相对差 %.6g > %s）"
            % (rel, tol_f), "computed": computed}


def _eval_equality(assertion: dict, fields: dict) -> dict:
    keys = [_s(k) for k in (assertion.get("fields") or []) if _s(k)]
    if len(keys) < 2:
        return {"status": "insufficient", "detail": "等值断言至少需要 2 个字段",
                "computed": {"items": []}}
    vals = []
    for key in keys:
        field = fields.get(key) or {}
        if field.get("value") is None:
            return {"status": "insufficient", "detail": "字段缺失：%s" % key,
                    "computed": {"items": []}}
        vals.append(_norm_compare(_s(field.get("value"))))
    computed = {"values": vals}
    tol = assertion.get("tolerance")
    nums = [_to_float(_s((fields.get(k) or {}).get("value"))) for k in keys]
    if tol is not None and all(n is not None for n in nums):
        try:
            tol_f = abs(float(tol))
        except (TypeError, ValueError):
            tol_f = 0.0
        diff = max(nums) - min(nums)
        computed["diff"] = diff
        ok = abs(diff) <= tol_f
        return {"status": "pass" if ok else "fail",
                "detail": ("数值等值一致（差 %s ≤ %s）" if ok else "数值不等（差 %s > %s）")
                          % (diff, tol_f), "computed": computed}
    ok = len(set(vals)) == 1
    return {"status": "pass" if ok else "fail",
            "detail": "字段值一致" if ok else "字段值不一致：%s" % vals,
            "computed": computed}


def _eval_range_relation(assertion: dict, fields: dict) -> dict:
    left_key, right_key = _s(assertion.get("left")), _s(assertion.get("right"))
    op = _s(assertion.get("op") or "<=")
    ln, lf, lc, lfac = _field_number(fields.get(left_key) or {})
    rn, rf, rc, rfac = _field_number(fields.get(right_key) or {})
    if ln is None or rn is None:
        return {"status": "insufficient",
                "detail": "字段缺失或非数值：%s / %s" % (left_key, right_key),
                "computed": {}}
    if lf and rf and lf != rf:
        return {"status": "insufficient",
                "detail": "字段量纲不同（%s vs %s）" % (lf, rf), "computed": {}}
    if lf and rf and (lfac or 1.0) != (rfac or 1.0):
        ln = ln * (lfac or 1.0) / (rfac or 1.0)
    computed = {"left": ln, "right": rn, "op": op}
    ok = {"<=": ln <= rn + 1e-12, "≤": ln <= rn + 1e-12,
          ">=": ln >= rn - 1e-12, "≥": ln >= rn - 1e-12,
          "<": ln < rn, ">": ln > rn,
          "==": abs(ln - rn) <= 1e-12, "=": abs(ln - rn) <= 1e-12}.get(op)
    if ok is None:
        return {"status": "insufficient", "detail": "未知关系运算符：%s" % op,
                "computed": computed}
    return {"status": "pass" if ok else "fail",
            "detail": "%s %s %s 成立" % (ln, op, rn) if ok else "%s %s %s 不成立" % (ln, op, rn),
            "computed": computed}


_ASSERTION_EVAL = {
    "sum": _eval_sum,
    "date_order": _eval_date_order,
    "unit_consistency": _eval_unit_consistency,
    "equality": _eval_equality,
    "range_relation": _eval_range_relation,
}


def verify_assertions(assertions: list, fields: dict) -> list:
    """执行跨字段断言 → 结果列表（每项含 status/computed/fields 引用）。"""
    results = []
    for idx, assertion in enumerate(assertions or []):
        if not isinstance(assertion, dict):
            results.append({"id": "assertion:%d" % idx, "type": "",
                            "name": "", "status": "insufficient",
                            "fields": [], "computed": {},
                            "detail": "断言不是对象"})
            continue
        aid = _s(assertion.get("id")) or "assertion:%d" % idx
        atype = _s(assertion.get("type"))
        name = _s(assertion.get("name")) or atype or aid
        keys = _assertion_keys(assertion)
        evaluator = _ASSERTION_EVAL.get(atype)
        if evaluator is None:
            results.append({"id": aid, "type": atype, "name": name,
                            "status": "insufficient", "fields": keys,
                            "computed": {},
                            "detail": "未知断言类型：%s" % (atype or "(空)")})
            continue
        try:
            got = evaluator(assertion, fields)
        except Exception as exc:  # noqa: BLE001 - 断言实现异常不能静默 pass
            got = {"status": "insufficient", "computed": {},
                   "detail": "断言执行失败：%s: %s" % (type(exc).__name__, exc)}
        results.append({"id": aid, "type": atype, "name": name,
                        "status": got.get("status", "insufficient"),
                        "fields": keys, "computed": got.get("computed") or {},
                        "detail": got.get("detail", "")})
    return results


# ---------------------------------------------------------------------------
# 逐字段 / 批量校验
# ---------------------------------------------------------------------------
def _empty(value) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    return False


def verify_field(field: dict, document=None, spec: dict | None = None,
                 context: dict | None = None) -> dict:
    """单字段校验（Verifier 核心）：返回任务书要求的全部标志 + verdict + evidence。"""
    if not isinstance(field, dict):
        raise VerificationInputError("fields 内元素必须是对象")
    spec = dict(spec or {})
    context = context or {}
    key = _s(field.get("key")) or "field"
    label = _s(field.get("label")) or _s(spec.get("label")) or key
    type_ = _infer_type(field, spec)
    doc = context.get("_document")
    if doc is None:
        doc = normalize_document(document)

    sub = check_substring(field, doc, type_)
    contamination = check_contamination(field, doc, sub, type_)
    label_bleed = check_label_bleed(field, doc, sub, context)
    unit = check_unit(field, spec, type_)
    rang = check_range(field, spec, type_)
    cross = context.get("cross") or []
    cross_status = context.get("cross_status")
    if cross:
        cross_field_ok = cross_status
    else:
        cross_field_ok = None
    # 空值 / 数值写法歧义：没有可核验对象，单位缺失/多值串等派生判断不得升级为 fail，
    # 统一按 insufficient（fail-closed 的“不猜”语义，与 L55 证书内核口径一致）。
    no_subject = (_empty(field.get("value")) and _empty(field.get("raw"))) \
        or field.get("ambiguous") is True
    if no_subject:
        sub = dict(sub, is_substring=None, span_ok=None)
        contamination = {"hit": False, "kinds": [], "items": [],
                         "checked": contamination.get("checked", True)}
        label_bleed = {"hit": False, "kinds": [], "items": [],
                       "labels_checked": label_bleed.get("labels_checked", 0)}
        unit = dict(unit, ok=None, kind="not_verifiable_no_value")
        rang = dict(rang, ok=None, kind="not_verifiable_no_value")

    reasons = []
    if sub.get("is_substring") is False:
        reasons.append("is_substring:false")
    if contamination.get("hit"):
        reasons.extend("contamination:%s" % k for k in contamination.get("kinds") or [])
    if label_bleed.get("hit"):
        reasons.extend("label_bleed:%s" % k for k in label_bleed.get("kinds") or [])
    if unit.get("ok") is False:
        reasons.append("unit:%s" % unit.get("kind"))
    if rang.get("ok") is False:
        reasons.append("range:%s" % rang.get("kind"))
    if cross_field_ok is False:
        reasons.append("cross_field:conflict")

    insufficient_reasons = []
    if doc is None or not doc.get("has_text"):
        insufficient_reasons.append("document_missing")
    if _empty(field.get("value")) and _empty(field.get("raw")):
        insufficient_reasons.append("empty_value")
    if field.get("ambiguous") is True:
        insufficient_reasons.append("ambiguous_number")
    if type_ in NUMBER_TYPES and _empty(field.get("value")) and not _empty(field.get("raw")):
        # raw 有值但 value 为空：尚未归一，按证据不足处理（不猜）
        insufficient_reasons.append("value_not_normalized")

    hard_fail = bool(sub.get("is_substring") is False
                     or contamination.get("hit")
                     or label_bleed.get("hit")
                     or unit.get("ok") is False
                     or rang.get("ok") is False
                     or cross_field_ok is False)
    if hard_fail:
        verdict = VERDICT_FAIL
    elif insufficient_reasons:
        verdict = VERDICT_INSUFFICIENT
    else:
        verdict = VERDICT_PASS
    reasons.extend(insufficient_reasons)
    if not reasons:
        reasons.append("all_applicable_checks_passed")

    evidence = {
        "quote": sub.get("quote") or "",
        "start": sub.get("start"),
        "end": sub.get("end"),
        "locate_mode": sub.get("mode"),
        "occurrences": sub.get("occurrences"),
        "span_ok": sub.get("span_ok"),
        "quote_found": bool(sub.get("quote_found")),
        "candidate": sub.get("candidate"),
        "document_has_text": bool(doc and doc.get("has_text")),
        "checks": [
            {"check": "is_substring", "value": sub.get("is_substring"),
             "mode": sub.get("mode")},
            {"check": "contamination", "value": contamination.get("hit"),
             "kinds": contamination.get("kinds") or []},
            {"check": "label_bleed", "value": label_bleed.get("hit"),
             "kinds": label_bleed.get("kinds") or []},
            {"check": "unit_ok", "value": unit.get("ok"), "kind": unit.get("kind")},
            {"check": "range_ok", "value": rang.get("ok"), "kind": rang.get("kind")},
            {"check": "cross_field_ok", "value": cross_field_ok,
             "assertions": [x.get("id") for x in cross] if cross else []},
        ],
    }
    if sub.get("detail"):
        evidence["substring_detail"] = sub["detail"]
    return {
        "key": key, "label": label, "type": type_,
        "value": field.get("value"), "raw": field.get("raw"),
        "unit": field.get("unit"),
        "is_substring": sub.get("is_substring"),
        "contamination": contamination,
        "label_bleed": label_bleed,
        "unit_ok": unit.get("ok"),
        "unit_check": unit,
        "range_ok": rang.get("ok"),
        "range_check": rang,
        "cross_field_ok": cross_field_ok,
        "cross_field": {"assertions": cross, "status": cross_status} if cross else
                       {"assertions": [], "status": None},
        "verdict": verdict,
        "reasons": reasons,
        "evidence": evidence,
    }


def verify_extraction(payload: dict) -> dict:
    """批量校验入口（HTTP/CLI/脚本共用）。

    ``payload``：``{"doc","fields","specs","assertions"}``（``doc`` 可为 str/dict）。
    返回逐字段结果 + 跨字段断言结果 + 汇总 verdict + 输入摘要（可复现）。
    """
    if not isinstance(payload, dict):
        raise VerificationInputError("请求体必须是 JSON 对象")
    doc_in = payload.get("doc", payload.get("document"))
    if isinstance(doc_in, dict) and not _s(doc_in.get("text")):
        doc_in = doc_in or None
    elif isinstance(doc_in, str) and not doc_in.strip():
        doc_in = doc_in
    fields_in = payload.get("fields")
    if not isinstance(fields_in, list) or not fields_in:
        raise VerificationInputError("fields 必须是非空数组")
    if len(fields_in) > MAX_FIELDS:
        raise VerificationInputError("fields 超过上限 %d（%d）"
                                     % (MAX_FIELDS, len(fields_in)),
                                     code="too_many_fields")
    specs = payload.get("specs") or {}
    if not isinstance(specs, dict):
        raise VerificationInputError("specs 必须是对象（key → 规格）")
    assertions = payload.get("assertions") or []
    if not isinstance(assertions, list):
        raise VerificationInputError("assertions 必须数组")
    if len(assertions) > MAX_ASSERTIONS:
        raise VerificationInputError("assertions 超过上限 %d（%d）"
                                     % (MAX_ASSERTIONS, len(assertions)),
                                     code="too_many_assertions")
    doc = normalize_document(doc_in) if doc_in is not None else None

    fields = []
    for idx, item in enumerate(fields_in):
        if not isinstance(item, dict):
            raise VerificationInputError("fields[%d] 必须是对象" % idx)
        field = dict(item)
        if not _s(field.get("key")):
            field["key"] = "field:%d" % idx
        fields.append(field)
    fields_by_key = {_s(f.get("key")): f for f in fields}

    assertion_results = verify_assertions(assertions, fields_by_key)
    cross_by_key, status_by_key = {}, {}
    for res in assertion_results:
        for key in res.get("fields") or []:
            cross_by_key.setdefault(key, []).append(res)
            prev = status_by_key.get(key)
            st = res.get("status")
            if prev == "fail" or st == "fail":
                status_by_key[key] = "fail"
            elif prev is None:
                status_by_key[key] = st
            elif prev == "pass" and st == "insufficient":
                status_by_key[key] = "insufficient"
    # 断言状态 → 该字段 cross_field_ok 三态
    cross_ok_by_key = {}
    for key, st in status_by_key.items():
        cross_ok_by_key[key] = {"pass": True, "fail": False}.get(st)
    for key in cross_by_key:
        cross_ok_by_key.setdefault(key, None)

    results = []
    for field in fields:
        key = _s(field.get("key"))
        ctx = {
            "_document": doc,
            "fields": fields,
            "specs": specs,
            "spec": specs.get(key) or {},
            "cross": cross_by_key.get(key) or [],
            "cross_status": cross_ok_by_key.get(key),
        }
        results.append(verify_field(field, doc, specs.get(key) or {}, ctx))

    summary = {"n_fields": len(results), "pass": 0, "fail": 0, "insufficient": 0,
               "contamination": 0, "label_bleed": 0, "unit_fail": 0,
               "range_fail": 0, "cross_fail": 0, "substring_fail": 0,
               "assertions": {"n": len(assertion_results), "pass": 0, "fail": 0,
                              "insufficient": 0}}
    actions = []
    for res in results:
        v = res.get("verdict")
        summary[v] = summary.get(v, 0) + 1
        if res.get("contamination", {}).get("hit"):
            summary["contamination"] += 1
        if res.get("label_bleed", {}).get("hit"):
            summary["label_bleed"] += 1
        if res.get("unit_ok") is False:
            summary["unit_fail"] += 1
        if res.get("range_ok") is False:
            summary["range_fail"] += 1
        if res.get("cross_field_ok") is False:
            summary["cross_fail"] += 1
        if res.get("is_substring") is False:
            summary["substring_fail"] += 1
        if v == VERDICT_FAIL:
            action = "review"
        elif v == VERDICT_INSUFFICIENT:
            action = "re_extract"
        else:
            action = "accept"
        actions.append({"key": res.get("key"), "action": action,
                        "reasons": list(res.get("reasons") or [])})
    for res in assertion_results:
        st = res.get("status")
        summary["assertions"][st] = summary["assertions"].get(st, 0) + 1

    if summary["fail"]:
        verdict = VERDICT_FAIL
    elif summary["insufficient"]:
        verdict = VERDICT_INSUFFICIENT
    else:
        verdict = VERDICT_PASS

    digest_src = {"doc": _doc_text(doc) if doc else "",
                  "fields": [{k: f.get(k) for k in
                              ("key", "label", "value", "raw", "unit", "type",
                               "quote", "start", "end", "cell", "anchor")}
                             for f in fields],
                  "specs": specs, "assertions": assertions}
    digest = hashlib.sha256(
        json.dumps(digest_src, ensure_ascii=False, sort_keys=True,
                   separators=(",", ":")).encode("utf-8")).hexdigest()
    return {
        "verifier_version": VERIFIER_VERSION,
        "verdict": verdict,
        "summary": summary,
        "fields": results,
        "assertions": assertion_results,
        "actions": actions,
        "document": {"has_text": bool(doc and doc.get("has_text")),
                     "chars": (doc or {}).get("chars", 0),
                     "tables": len((doc or {}).get("tables") or [])},
        "input_digest": digest,
        "limits": {"max_doc_chars": MAX_DOC_CHARS, "max_fields": MAX_FIELDS,
                   "max_assertions": MAX_ASSERTIONS,
                   "max_quote_chars": MAX_QUOTE_CHARS},
    }


# ---------------------------------------------------------------------------
# 现有解析 facts → 本模块输入（"可用现有解析 facts 构造"）
# ---------------------------------------------------------------------------
def fields_from_facts(facts: list, prefix: str = "fact") -> list:
    """统一 facts（``app/engine/facts.py`` schema）→ 可校验字段列表。

    facts 字段：``{kind, metric, object, value, unit, anchor, quote, source, start}``；
    deepparse 事实另有 ``raw/context/char_start``（char_start 是 section 内偏移，不
    直接当文档绝对坐标）。facts 没提供绝对坐标时 ``start`` 留空（可定位信号不可用）。
    """
    out = []
    for idx, fact in enumerate(facts or []):
        if not isinstance(fact, dict):
            continue
        key = "%s:%d" % (prefix, idx)
        kind = _s(fact.get("kind"))
        type_ = FACT_KIND_TYPE.get(kind, "text")
        raw = _s(fact.get("raw")) or ("" if _empty(fact.get("value"))
                                      else _s(fact.get("value")))
        quote = _s(fact.get("quote") or fact.get("context"))[:MAX_QUOTE_CHARS]
        start = fact.get("start")
        if not isinstance(start, int) or isinstance(start, bool):
            start = None
        out.append({
            "key": key,
            "label": _s(fact.get("metric")) or _s(fact.get("object")) or kind or key,
            "value": fact.get("value"),
            "raw": raw,
            "unit": _s(fact.get("unit")),
            "type": type_,
            "quote": quote,
            "start": start,
            "end": None,
            "anchor": _s(fact.get("anchor")),
            "source": _s(fact.get("source")),
        })
    return out


def assertions_from_facts(facts: list, prefix: str = "fact") -> list:
    """从统一 facts 构造可验证的跨字段断言（只在无歧义时构造，宁缺勿猜）。

    构造三类：
    - ``sum``：同一锚点（sheet/段落）内存在 1 个「合计/总额/总价」数值事实 + ≥2 个
      明细数值事实 → 断言「明细合计 = 总额」；
    - ``date_order``：按日期角色（发布/批准/签订 → 生效；开始 → 结束）配对；
    - ``unit_consistency``：同一对象/指标出现 ≥2 种同量纲不同单位 → 换算一致性。
    """
    out = []
    numeric, dates, unit_groups = [], [], {}
    for idx, fact in enumerate(facts or []):
        if not isinstance(fact, dict):
            continue
        key = "%s:%d" % (prefix, idx)
        kind = _s(fact.get("kind"))
        metric = _s(fact.get("metric")) + " " + _s(fact.get("object"))
        if kind == "date":
            iso = _date_iso(fact.get("value") or fact.get("raw"))
            if iso:
                dates.append({"key": key, "iso": iso, "metric": metric})
            continue
        num = _to_float(fact.get("value"))
        if num is None:
            num, _, canon, _ = _parse_number_unit(_s(fact.get("raw")))
            family = canon[0] if canon else None
        else:
            family = _unit_canon(_s(fact.get("unit")))[0]
        if num is None:
            continue
        anchor = _s(fact.get("anchor"))
        group = anchor.split("!")[0] if "!" in anchor else anchor
        numeric.append({"key": key, "num": num, "metric": metric,
                        "group": group, "family": family,
                        "total_like": bool(_TOTAL_HINTS.search(metric))})
        raw_unit = _s(fact.get("unit")).strip()
        obj = _norm_compare(_s(fact.get("object")) or _s(fact.get("metric")))
        if obj and raw_unit:
            unit_groups.setdefault((obj, family), []).append(
                {"key": key, "unit": raw_unit, "num": num})

    # 1) 合计断言：每个锚点最多 1 条
    by_group = {}
    for item in numeric:
        by_group.setdefault(item["group"], []).append(item)
    for group, items in sorted(by_group.items()):
        totals = [x for x in items if x["total_like"]]
        parts = [x for x in items if not x["total_like"]]
        if len(totals) != 1 or len(parts) < 2:
            continue
        total = totals[0]
        same_family = [p for p in parts
                       if (not p["family"] or not total["family"]
                           or p["family"] == total["family"])]
        if len(same_family) < 2:
            continue
        out.append({
            "id": "facts-sum-%d" % len(out), "type": "sum",
            "name": "明细合计=总额（%s）" % (group or "全文档"),
            "total": total["key"],
            "parts": [p["key"] for p in same_family],
            "tolerance": 0.01,
            "_source": "facts:sum",
        })

    # 2) 日期先后断言
    role_dates = {}
    for item in dates:
        for role, pat in _DATE_ROLES:
            if pat.search(item["metric"]) and role not in role_dates:
                role_dates[role] = item
    for earlier, later in _DATE_ORDER_PAIRS:
        e, l = role_dates.get(earlier), role_dates.get(later)
        if e and l and e["key"] != l["key"]:
            out.append({
                "id": "facts-date-%d" % len(out), "type": "date_order",
                "name": "日期先后（%s → %s）" % (earlier, later),
                "earlier": e["key"], "later": l["key"],
                "_source": "facts:date_order",
            })

    # 3) 单位换算一致性断言（同对象/指标、同量纲、不同单位写法）。
    # 只在“换算后数值一致”的组上构造：同名指标的不同测点本来就可能数值不同，
    # 仅凭单位不同不能判冲突（宁缺勿猜）；真正的冲突检测由调用方显式断言承担。
    for (obj, family), items in sorted(
            unit_groups.items(),
            key=lambda kv: (_s(kv[0][0]), _s(kv[0][1]))):
        units = {x["unit"] for x in items}
        if family is None or len(units) < 2 or len(items) < 2:
            continue
        bases = []
        for x in items:
            _, _, factor = _unit_canon(x["unit"])
            if factor is None:
                bases = []
                break
            bases.append(float(x["num"]) * float(factor))
        if len(bases) < 2:
            continue
        hi = max(abs(b) for b in bases) or 1.0
        rel = (max(bases) - min(bases)) / hi
        if rel > 0.01:
            continue
        out.append({
            "id": "facts-unit-%d" % len(out), "type": "unit_consistency",
            "name": "单位换算一致性（%s）" % obj,
            "fields": [x["key"] for x in items],
            "tolerance": 0.01,
            "_source": "facts:unit_consistency",
        })
    return out


def verify_facts(facts: list, document=None) -> dict:
    """便捷入口：facts → 字段 + 断言 → 批量校验（0 模型）。"""
    fields = fields_from_facts(facts)
    assertions = assertions_from_facts(facts)
    return verify_extraction({"doc": document, "fields": fields,
                              "assertions": assertions})


__all__ = [
    "VERIFIER_VERSION", "VERDICT_PASS", "VERDICT_FAIL", "VERDICT_INSUFFICIENT",
    "VerificationInputError", "UNIT_ALIASES",
    "MAX_DOC_CHARS", "MAX_FIELDS", "MAX_ASSERTIONS", "MAX_QUOTE_CHARS",
    "normalize_document", "locate_quote",
    "check_substring", "check_contamination", "check_label_bleed",
    "check_unit", "check_range", "verify_assertions",
    "verify_field", "verify_extraction",
    "fields_from_facts", "assertions_from_facts", "verify_facts",
]
