"""本体资产：租户隔离读写 + 同事务审计（T-197 / P1-2、P1-3）。

设计（评审 §5 建议的「平台级共享库 + 租户级扩展层」两表语义，用同表 tenant 列实现）：

- ``onto_entity/onto_alias/onto_link/onto_version`` 新增 ``tenant_id``（NULL = 平台共享资产）；
- 业务管理员写入 = 本租户扩展层（tenant_id=当前租户、workspace_id=NULL，租户内跨空间共享）；
- 读取 = 平台共享资产（NULL）+ 本租户扩展层；**看不到、改不到其他租户的资产**；
- 越权访问（跨租户 id / 版本）统一返回 404（不泄露存在性）；
- 6 类写操作（entity_created/updated/deleted、alias_created/updated/deleted）与业务写
  **同一事务**落审计（``audit.log_in_tx``）；失败整体回滚，不出现“写了但没审计”。

边界（如实）：engine 内存本体是进程级单例，``load_from_db`` 依赖调用时的 ctx 过滤；
HTTP/CLI/脚本经本模块写后会按当前 ctx 重载。manifest._graph_snapshot 历史上直接 SELECT
全表（非本任务写作用域），因此“冻结快照里的实体/关系清单”仍可能包含共享层+当前租户层，
但不含其他租户扩展层以外的数据依赖；已在该快照 note 中如实标注。
"""
from __future__ import annotations

import json
import logging

from .. import db
from .. import repositories as R
from . import audit as _audit

LOG = logging.getLogger(__name__)

ENTITY_TYPE_KEYS = ("Field", "Product", "HalfProduct", "ProcessStep", "Party", "Metric",
                    "Unit", "Document")
LINK_TYPE_EXPECT = {"produced_by": ("HalfProduct", "ProcessStep"),
                    "measured_by": ("ProcessStep", "Metric"),
                    "uses_unit": ("Metric", "Unit"),
                    "document_field": ("Document", "Field"),
                    "document_party": ("Document", "Party")}


def _ctx() -> tuple:
    try:
        from . import ctx as _ctx_mod
        cur = _ctx_mod.get_context() or {}
        return (str(cur.get("tenant_id") or ""), str(cur.get("workspace_id") or ""),
                bool(_ctx_mod.is_system()))
    except Exception:
        return ("", "", False)


def _reload_engine() -> None:
    try:
        from ..engine import engine as _engine_mod
        _engine_mod.reload_ontology()
    except Exception:
        LOG.warning("ontology engine reload skipped", exc_info=True)


# ---------------------------------------------------------------------------
# 读：租户可见视图
# ---------------------------------------------------------------------------
def _visible_where(alias: str = "") -> tuple:
    """SQL where 片段 + 参数：NULL（平台共享）或当前租户。无租户上下文 = 全可见（脚本）。"""
    tenant, _ws, system = _ctx()
    p = (alias + "." if alias else "")
    if not tenant or system:
        return "1=1", ()
    return f"({p}tenant_id IS NULL OR {p}tenant_id=?)", (tenant,)


def visible_entities() -> list:
    where, params = _visible_where()
    try:
        with db.session() as c:
            rows = c.execute(
                f"SELECT id,type_key,name,props_json,created_at,tenant_id FROM onto_entity "
                f"WHERE {where} ORDER BY type_key,name", params).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        LOG.debug("visible entities failed", exc_info=True)
        return []


def visible_aliases() -> list:
    where, params = _visible_where("a")
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT a.id,a.type_key,a.alias,a.entity_id,a.evidence,a.source,a.status,"
                "a.created_at,a.tenant_id,e.name AS entity_name "
                "FROM onto_alias a LEFT JOIN onto_entity e ON e.id=a.entity_id "
                f"WHERE {where} ORDER BY a.type_key,a.alias", params).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        LOG.debug("visible aliases failed", exc_info=True)
        return []


def visible_links() -> list:
    where, params = _visible_where("l")
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT l.id,l.key,l.source_id,l.target_id,l.tenant_id,"
                "s.name AS source_name,t.name AS target_name,"
                "s.tenant_id AS source_tenant,t.tenant_id AS target_tenant "
                "FROM onto_link l LEFT JOIN onto_entity s ON s.id=l.source_id "
                "LEFT JOIN onto_entity t ON t.id=l.target_id "
                f"WHERE {where} ORDER BY l.key", params).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        LOG.debug("visible links failed", exc_info=True)
        return []


def admin_view() -> dict:
    """GET /api/v1/ontology 的租户可见视图（与 engine.ONTO.to_admin_dict 结构兼容）。"""
    try:
        from ..engine import engine as _engine_mod
        base = _engine_mod.ONTO.to_admin_dict()
    except Exception:
        base = {"types": [], "link_types": [], "instances": [], "links": [], "alias_list": []}
    ents = visible_entities()
    als = visible_aliases()
    lks = visible_links()
    ent_ids = {str(e.get("id") or "") for e in ents}
    alias_count = {}
    for a in als:
        eid = str(a.get("entity_id") or "")
        alias_count[eid] = alias_count.get(eid, 0) + 1
    instances = [{"id": str(e.get("id") or ""), "name": str(e.get("name") or ""),
                  "type_key": str(e.get("type_key") or ""),
                  "alias_count": int(alias_count.get(str(e.get("id") or ""), 0)),
                  "scope": "shared" if not e.get("tenant_id") else "tenant"} for e in ents]
    alias_list = [{"id": str(a.get("id") or ""), "alias": str(a.get("alias") or ""),
                   "name": str(a.get("entity_name") or ""),
                   "type_key": str(a.get("type_key") or ""),
                   "entity_id": str(a.get("entity_id") or ""),
                   "evidence": str(a.get("evidence") or ""),
                   "source": str(a.get("source") or ""),
                   "status": str(a.get("status") or ""),
                   "scope": "shared" if not a.get("tenant_id") else "tenant"} for a in als]
    links = []
    for l in lks:
        if str(l.get("source_id") or "") not in ent_ids or \
                str(l.get("target_id") or "") not in ent_ids:
            continue
        expect = LINK_TYPE_EXPECT.get(str(l.get("key") or ""))
        ok = True
        if expect:
            st = next((e.get("type_key") for e in ents
                       if str(e.get("id") or "") == str(l.get("source_id") or "")), "")
            tt = next((e.get("type_key") for e in ents
                       if str(e.get("id") or "") == str(l.get("target_id") or "")), "")
            ok = (st, tt) == expect
        links.append({"id": str(l.get("id") or ""), "key": str(l.get("key") or ""),
                      "source_name": str(l.get("source_name") or l.get("source_id") or ""),
                      "target_name": str(l.get("target_name") or l.get("target_id") or ""),
                      "ok": bool(ok),
                      "scope": "shared" if not l.get("tenant_id") else "tenant"})
    return {**base, "instances": instances, "alias_list": alias_list, "links": links,
            "scope": {"tenant_id": _ctx()[0], "shared_visible": True,
                      "atomic": "平台共享层（tenant_id IS NULL）+ 本租户扩展层"}}


# ---------------------------------------------------------------------------
# 写：校验 + 同事务审计
# ---------------------------------------------------------------------------
def _entity_row(c, entity_id: str) -> dict | None:
    tenant, _ws, system = _ctx()
    row = c.execute("SELECT * FROM onto_entity WHERE id=?", (entity_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    tid = str(d.get("tenant_id") or "")
    if tid and tenant and tid != tenant and not system:
        return None
    return d


def _alias_row(c, alias_id: str) -> dict | None:
    tenant, _ws, system = _ctx()
    row = c.execute("SELECT * FROM onto_alias WHERE id=?", (alias_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    tid = str(d.get("tenant_id") or "")
    if tid and tenant and tid != tenant and not system:
        return None
    return d


def _is_shared(row: dict) -> bool:
    return not str((row or {}).get("tenant_id") or "")


def create_entity(type_key: str, name: str, props: dict = None, *, actor: str = "") -> dict:
    type_key = str(type_key or "").strip() or "HalfProduct"
    name = str(name or "").strip()
    if not name:
        return {"ok": False, "code": "invalid_entity", "reason": "实体名称不能为空"}
    if len(name) > 60:
        return {"ok": False, "code": "invalid_entity", "reason": "实体名称最长 60 字"}
    try:
        from ..engine import engine as _engine_mod
        type_ok = type_key in (_engine_mod.ONTO.types or {})
    except Exception:
        type_ok = type_key in ENTITY_TYPE_KEYS
    if not type_ok:
        return {"ok": False, "code": "invalid_entity_type",
                "reason": f"未知实体类型：{type_key}（可选 {'/'.join(ENTITY_TYPE_KEYS)}）"}
    tenant, _ws, _system = _ctx()
    iid = db.new_id("oe")
    where, params = _visible_where()
    try:
        with db.session() as c:
            dup = c.execute(
                f"SELECT id FROM onto_entity WHERE name=? AND type_key=? AND {where}",
                (name, type_key, *params)).fetchone()
            if dup:
                return {"ok": False, "code": "duplicate_entity", "reason": "同名实体已存在"}
            c.execute("INSERT INTO onto_entity(id,type_key,name,props_json,created_at,"
                      "tenant_id,workspace_id) VALUES(?,?,?,?,?,?,NULL)",
                      (iid, type_key, name, json.dumps(props or {}, ensure_ascii=False),
                       db.now(), tenant or None))
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.entity_created",
                             object_=iid,
                             after=json.dumps({"type_key": type_key, "name": name},
                                              ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "entity_id": iid, "type_key": type_key, "name": name,
            "scope": "shared" if not tenant else "tenant"}


def update_entity(entity_id: str, *, name: str = None, type_key: str = None,
                  props: dict = None, actor: str = "") -> dict:
    eid = str(entity_id or "").strip()
    try:
        with db.session() as c:
            row = _entity_row(c, eid)
            if not row:
                return {"ok": False, "code": "not_found", "reason": "实体不存在"}
            if _is_shared(row):
                return {"ok": False, "code": "shared_asset",
                        "reason": "平台共享实体不可修改；请在租户扩展层新增/覆盖"}
            before = {k: row.get(k) for k in ("name", "type_key", "props_json")}
            upd = {}
            if name is not None:
                nm = str(name).strip()
                if not nm or len(nm) > 60:
                    return {"ok": False, "code": "invalid_entity", "reason": "实体名称不合法"}
                upd["name"] = nm
            if type_key is not None:
                tk = str(type_key).strip()
                if tk not in ENTITY_TYPE_KEYS:
                    return {"ok": False, "code": "invalid_entity_type", "reason": "未知实体类型"}
                upd["type_key"] = tk
            if props is not None:
                upd["props_json"] = json.dumps(props, ensure_ascii=False)
            if not upd:
                return {"ok": False, "code": "no_change", "reason": "没有要修改的字段"}
            c.execute("UPDATE onto_entity SET " + ",".join(f"{k}=?" for k in upd) + " WHERE id=?",
                      [*upd.values(), eid])
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.entity_updated",
                             object_=eid, before=json.dumps(before, ensure_ascii=False),
                             after=json.dumps({k: upd.get(k) for k in upd}, ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "entity_id": eid}


def delete_entity(entity_id: str, *, actor: str = "") -> dict:
    eid = str(entity_id or "").strip()
    try:
        with db.session() as c:
            row = _entity_row(c, eid)
            if not row:
                return {"ok": False, "code": "not_found", "reason": "实体不存在"}
            if _is_shared(row):
                return {"ok": False, "code": "shared_asset",
                        "reason": "平台共享实体不可删除；租户扩展请用别名/停用"}
            n_alias = c.execute("SELECT COUNT(*) FROM onto_alias WHERE entity_id=?",
                                (eid,)).fetchone()[0]
            n_link = c.execute("SELECT COUNT(*) FROM onto_link WHERE source_id=? OR target_id=?",
                               (eid, eid)).fetchone()[0]
            if n_alias or n_link:
                return {"ok": False, "code": "entity_in_use",
                        "reason": f"实体仍有 {n_alias} 个别名 / {n_link} 条关系引用，先清理再删"}
            c.execute("DELETE FROM onto_entity WHERE id=?", (eid,))
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.entity_deleted",
                             object_=eid,
                             before=json.dumps({"name": row.get("name"),
                                                "type_key": row.get("type_key")},
                                               ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "entity_id": eid}


def create_alias(type_key: str, alias: str, entity_id: str, evidence: str,
                 *, actor: str = "") -> dict:
    tk = str(type_key or "").strip()
    al = str(alias or "").strip()
    eid = str(entity_id or "").strip()
    ev = str(evidence or "").strip()
    if not (tk and al and eid):
        return {"ok": False, "code": "invalid_alias", "reason": "类型、别名、目标实例不能为空"}
    if len(al) > 60:
        return {"ok": False, "code": "invalid_alias", "reason": "别名最长 60 字"}
    if not ev:
        return {"ok": False, "code": "alias_evidence_required",
                "reason": "别名必须填写依据/原文来源，禁止无依据合并概念"}
    tenant, _ws, _system = _ctx()
    aid = db.new_id("oa")
    try:
        with db.session() as c:
            ent = _entity_row(c, eid)
            if not ent:
                # 跨租户/不存在统一 404：不泄露其他租户资产存在性
                return {"ok": False, "code": "not_found", "reason": "目标实例不存在"}
            if str(ent.get("type_key") or "") != tk:
                return {"ok": False, "code": "alias_type_mismatch",
                        "reason": f"别名类型与实例类型不一致：{tk} / {ent.get('type_key')}"}
            where, params = _visible_where()
            old = c.execute(
                f"SELECT id,entity_id FROM onto_alias WHERE type_key=? AND alias=? AND {where}",
                (tk, al, *params)).fetchone()
            if old and str(old["entity_id"]) != eid:
                return {"ok": False, "code": "alias_conflict",
                        "reason": "别名已被其他实例占用"}
            if old:
                return {"ok": False, "code": "duplicate_alias",
                        "reason": "该实例已有同名别名"}
            c.execute("INSERT INTO onto_alias(id,type_key,alias,entity_id,evidence,source,"
                      "status,created_at,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,?,?,?,?,NULL)",
                      (aid, tk, al, eid, ev, "manual", "approved", db.now(),
                       tenant or None))
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.alias_created",
                             object_=aid,
                             after=json.dumps({"type_key": tk, "alias": al,
                                               "entity_id": eid, "evidence": ev[:300]},
                                              ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "alias_id": aid, "evidence": ev}


def update_alias(alias_id: str, *, alias: str = None, evidence: str = None,
                 status: str = None, actor: str = "") -> dict:
    aid = str(alias_id or "").strip()
    try:
        with db.session() as c:
            row = _alias_row(c, aid)
            if not row:
                return {"ok": False, "code": "not_found", "reason": "别名不存在"}
            if _is_shared(row):
                return {"ok": False, "code": "shared_asset",
                        "reason": "平台共享别名不可修改；请新增租户别名覆盖"}
            upd = {}
            if alias is not None:
                al = str(alias).strip()
                if not al or len(al) > 60:
                    return {"ok": False, "code": "invalid_alias", "reason": "别名不合法"}
                upd["alias"] = al
            if evidence is not None:
                ev = str(evidence).strip()
                if not ev:
                    return {"ok": False, "code": "alias_evidence_required",
                            "reason": "别名必须填写依据/原文来源"}
                upd["evidence"] = ev[:1000]
            if status is not None:
                st = str(status).strip()
                if st not in ("approved", "proposed", "rejected"):
                    return {"ok": False, "code": "invalid_status",
                            "reason": "状态只能是 approved/proposed/rejected"}
                upd["status"] = st
            if not upd:
                return {"ok": False, "code": "no_change", "reason": "没有要修改的字段"}
            c.execute("UPDATE onto_alias SET " + ",".join(f"{k}=?" for k in upd) + " WHERE id=?",
                      [*upd.values(), aid])
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.alias_updated",
                             object_=aid,
                             before=json.dumps({k: row.get(k) for k in upd}, ensure_ascii=False),
                             after=json.dumps(upd, ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "alias_id": aid}


def delete_alias(alias_id: str, *, actor: str = "") -> dict:
    aid = str(alias_id or "").strip()
    try:
        with db.session() as c:
            row = _alias_row(c, aid)
            if not row:
                return {"ok": False, "code": "not_found", "reason": "别名不存在"}
            if _is_shared(row):
                return {"ok": False, "code": "shared_asset",
                        "reason": "平台共享别名不可删除；租户别名可删"}
            c.execute("DELETE FROM onto_alias WHERE id=?", (aid,))
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.alias_deleted",
                             object_=aid,
                             before=json.dumps({"alias": row.get("alias"),
                                                "entity_id": row.get("entity_id")},
                                               ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "alias_id": aid}


def create_link(key: str, source_id: str, target_id: str, *, actor: str = "") -> dict:
    key = str(key or "").strip() or "produced_by"
    sid = str(source_id or "").strip()
    tid_target = str(target_id or "").strip()
    if not (sid and tid_target):
        return {"ok": False, "code": "invalid_link", "reason": "source_id / target_id 不能为空"}
    tenant, _ws, _system = _ctx()
    lid = db.new_id("ol")
    try:
        with db.session() as c:
            src = _entity_row(c, sid)
            dst = _entity_row(c, tid_target)
            if not src or not dst:
                return {"ok": False, "code": "not_found", "reason": "关系端点不存在"}
            where, params = _visible_where()
            dup = c.execute(
                f"SELECT id FROM onto_link WHERE key=? AND source_id=? AND target_id=? AND {where}",
                (key, sid, tid_target, *params)).fetchone()
            if dup:
                return {"ok": False, "code": "duplicate_link", "reason": "关系已存在"}
            expect = LINK_TYPE_EXPECT.get(key)
            if expect and (str(src.get("type_key")), str(dst.get("type_key"))) != expect:
                return {"ok": False, "code": "link_direction_invalid",
                        "reason": f"{key} 要求 {expect[0]} → {expect[1]}，"
                                  f"实际 {src.get('type_key')} → {dst.get('type_key')}"}
            c.execute("INSERT INTO onto_link(id,key,source_id,target_id,tenant_id,workspace_id) "
                      "VALUES(?,?,?,?,?,NULL)",
                      (lid, key, sid, tid_target, tenant or None))
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.link_created",
                             object_=lid,
                             after=json.dumps({"key": key, "source_id": sid,
                                               "target_id": tid_target}, ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "link_id": lid}


def delete_link(link_id: str, *, actor: str = "") -> dict:
    lid = str(link_id or "").strip()
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM onto_link WHERE id=?", (lid,)).fetchone()
            if not row:
                return {"ok": False, "code": "not_found", "reason": "关系不存在"}
            d = dict(row)
            if _is_shared(d):
                return {"ok": False, "code": "shared_asset",
                        "reason": "平台共享关系不可删除"}
            c.execute("DELETE FROM onto_link WHERE id=?", (lid,))
            _audit.log_in_tx(c, actor=str(actor or "system"), action="ontology.link_deleted",
                             object_=lid,
                             before=json.dumps({"key": d.get("key"),
                                                "source_id": d.get("source_id"),
                                                "target_id": d.get("target_id")},
                                               ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "write_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
    _reload_engine()
    return {"ok": True, "link_id": lid}


def version_visible(version_id: str) -> dict | None:
    """发布版本按租户可见（跨租户/不存在统一 None → 404）。"""
    vid = str(version_id or "").strip()
    tenant, _ws, system = _ctx()
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM onto_version WHERE id=?", (vid,)).fetchone()
        if not row:
            return None
        d = dict(row)
        tid = str(d.get("tenant_id") or "")
        if tid and tenant and tid != tenant and not system:
            return None
        return d
    except Exception:
        return None
