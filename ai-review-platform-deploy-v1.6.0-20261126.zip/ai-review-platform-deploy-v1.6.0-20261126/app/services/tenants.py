"""多租户端：开通/停用/恢复租户、管理租户管理员、租户品牌配置。"""
import base64
import re
import time
import urllib.parse

from .. import db
from .. import repositories as R
from . import permissions as P

DEFAULT_PLATFORM_NAME = "AI 审核平台"
MAX_PLATFORM_NAME_LEN = 40
MAX_LOGO_BYTES = 512 * 1024
MAX_LOGO_URL_LEN = 2048
# 只允许位图 data URL；拒绝 SVG/text/html 等可执行内容伪装成 logo。
_LOGO_DATA_RE = re.compile(
    r"^data:image/(png|jpe?g|webp|gif);base64,([A-Za-z0-9+/=\s]+)$", re.I)
_DATA_URI_SAFE_BYTES = MAX_LOGO_BYTES * 4 // 3 + 1024


def _c():
    return db.connect()


def _default_branding() -> dict:
    return {"found": False, "tenant_id": "", "tenant_code": "", "tenant_name": "",
            "tenant_status": "", "platform_name": DEFAULT_PLATFORM_NAME,
            "logo_url": "", "logo": "", "configured": False,
            "default_platform_name": DEFAULT_PLATFORM_NAME}


def _image_magic_ok(raw: bytes) -> bool:
    """校验常见位图文件头，避免把任意 base64 内容当图片落库。"""
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return True
    if raw[:3] == b"\xff\xd8\xff":
        return True
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return True
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return True
    return False


def normalize_platform_name(value) -> tuple:
    """返回 (规范值, 错误)。空字符串表示回退默认平台名。"""
    name = str(value or "").strip()
    name = re.sub(r"[\x00-\x1f\x7f]+", " ", name)
    name = re.sub(r"\s{2,}", " ", name).strip()
    if len(name) > MAX_PLATFORM_NAME_LEN:
        return None, f"平台名称最多 {MAX_PLATFORM_NAME_LEN} 个字"
    return name, ""


def normalize_logo_url(value) -> tuple:
    """返回 (规范值, 错误)。支持 http(s) 地址与 PNG/JPEG/WebP/GIF data URL。"""
    logo = str(value or "").strip()
    if not logo:
        return "", ""
    if len(logo) > _DATA_URI_SAFE_BYTES + MAX_LOGO_URL_LEN:
        return None, "Logo 数据过大（图片上限 512KB）"
    if logo.lower().startswith("data:"):
        m = _LOGO_DATA_RE.match(logo)
        if not m:
            return None, "Logo 仅支持 PNG/JPEG/WebP/GIF 的图片 data URL"
        try:
            raw = base64.b64decode(re.sub(r"\s+", "", m.group(2)), validate=True)
        except Exception:
            return None, "Logo data URL 不是合法的 base64 图片"
        if not raw:
            return None, "Logo 图片内容为空"
        if len(raw) > MAX_LOGO_BYTES:
            return None, "Logo 图片不能超过 512KB"
        if not _image_magic_ok(raw):
            return None, "Logo data URL 不是有效的图片文件"
        return logo, ""
    low = logo.lower()
    if low.startswith(("http://", "https://")):
        if len(logo) > MAX_LOGO_URL_LEN:
            return None, "Logo 地址过长（最多 2048 字符）"
        try:
            parsed = urllib.parse.urlsplit(logo)
        except Exception:
            return None, "Logo 地址不合法"
        if not parsed.hostname:
            return None, "Logo 地址缺少域名"
        return logo, ""
    return None, "Logo 必须是 http(s) 地址或图片 data URL"


# ---------------------------------------------------------------------------
# S3（评审 P0 第二批）：租户停用/过期 → 已登录会话立即失效
#
# 修复前：登录时校验 tenant.status（server.py 登录分支），但**会话期**只校验
# user.status/token_version，租户被停用后已登录的 cookie 仍可读全部业务数据直到
# JWT 过期（1h）。登录与运行期两套口径，属安全缺口。
# ---------------------------------------------------------------------------
def tenant_session_state(tenant_id: str, today: str = "") -> dict:
    """会话期租户状态（服务层唯一事实源，HTTP 会话校验与测试同源）。

    返回 ``{"ok": bool, "status": "active|suspended|expired|missing", "code": str,
    "http_status": int, "reason": str}``：

    - 无租户（平台运营 / 外部身份 / 历史数据）→ 放行（平台身份由平台层另行判定）；
    - 租户行不存在 → 放行（旧库/外部身份，不能因缺行误杀；登录侧另有租户校验）；
    - status != active → 拒绝（``tenant_suspended``，401：会话失效）；
    - expires_at 有值且早于今天 → 拒绝（``tenant_expired``，403：身份有效但订阅过期）。
    """
    tid = str(tenant_id or "").strip()
    if not tid:
        return {"ok": True, "status": "missing", "code": "", "http_status": 200, "reason": ""}
    c = _c()
    try:
        row = c.execute("SELECT status,expires_at FROM tenant WHERE id=?", (tid,)).fetchone()
    finally:
        c.close()
    if not row:
        return {"ok": True, "status": "missing", "code": "", "http_status": 200, "reason": ""}
    status = str(row["status"] or "active")
    if status != "active":
        return {"ok": False, "status": "suspended", "code": "tenant_suspended",
                "http_status": 401,
                "reason": "所属租户已停用，会话已失效，请联系平台管理员"}
    exp = str(row["expires_at"] or "").strip()
    if exp:
        day = str(today or "").strip() or time.strftime("%Y-%m-%d")
        # 只比较日期前缀（历史数据有 'YYYY-MM-DD' 与 'YYYY-MM-DD HH:MM:SS' 两种）
        if exp[:10] < day[:10]:
            return {"ok": False, "status": "expired", "code": "tenant_expired",
                    "http_status": 403,
                    "reason": "所属租户已过期，会话已失效，请联系平台管理员续期"}
    return {"ok": True, "status": "active", "code": "", "http_status": 200, "reason": ""}


def get_tenant_branding(tenant_ref: str = "") -> dict:
    """按租户 id 或 code 读取品牌；不存在/未配置时返回默认品牌（不抛错）。"""
    ref = str(tenant_ref or "").strip()
    if not ref:
        return _default_branding()
    c = _c()
    try:
        row = c.execute("SELECT id,code,name,status,logo_url,platform_name FROM tenant "
                        "WHERE id=? OR code=?", (ref, ref)).fetchone()
    finally:
        c.close()
    if not row:
        return _default_branding()
    name = str(row["platform_name"] or "").strip()
    logo = str(row["logo_url"] or "").strip()
    return {"found": True, "tenant_id": row["id"], "tenant_code": row["code"] or "",
            "tenant_name": row["name"] or "", "tenant_status": row["status"] or "active",
            "platform_name": name or DEFAULT_PLATFORM_NAME,
            "logo_url": logo, "logo": logo, "configured": bool(name or logo),
            "default_platform_name": DEFAULT_PLATFORM_NAME}


def branding_for_user(user_id: str) -> dict:
    """登录后品牌：按账号所属租户读取；平台账号无租户时回退默认。"""
    uid = str(user_id or "").strip()
    if not uid:
        return _default_branding()
    c = _c()
    try:
        row = c.execute("SELECT tenant_id FROM user WHERE id=?", (uid,)).fetchone()
    finally:
        c.close()
    return get_tenant_branding((row["tenant_id"] if row else "") or "")


def branding_for_case(case_id: str) -> dict:
    """报告品牌：按案例所属租户读取；跨租户/不存在时回退默认。"""
    cid = str(case_id or "").strip()
    if not cid:
        return _default_branding()
    c = _c()
    try:
        row = c.execute("SELECT tenant_id FROM audit_case WHERE id=?", (cid,)).fetchone()
    finally:
        c.close()
    return get_tenant_branding((row["tenant_id"] if row else "") or "")


def update_tenant_branding(user_id: str, fields: dict, actor: str = "",
                           role: str = "") -> dict:
    """更新本租户品牌。仅本租户业务管理员（active role=admin）可写。

    tenant 只能来自登录账号自身，请求体中的 tenant_id 一律忽略，避免跨租户改写。
    """
    if str(role or "").strip() != "admin":
        return {"ok": False, "reason": "仅租户业务管理员可修改租户配置", "code": "forbidden"}
    uid = str(user_id or "").strip()
    if not uid:
        return {"ok": False, "reason": "未登录", "code": "unauthorized"}
    c = _c()
    try:
        u = c.execute("SELECT tenant_id,status FROM user WHERE id=?", (uid,)).fetchone()
        if not u:
            return {"ok": False, "reason": "账号不存在", "code": "unauthorized"}
        tenant_id = str(u["tenant_id"] or "")
        if not tenant_id:
            return {"ok": False, "reason": "平台账号不属于任何租户，不能修改租户配置",
                    "code": "forbidden"}
        # 二次校验角色归属，防止会话角色被伪造后只看前端。
        role_rows = c.execute(
            "SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?",
            (uid,)).fetchall()
        if "admin" not in {str(x[0]) for x in role_rows}:
            return {"ok": False, "reason": "仅租户业务管理员可修改租户配置",
                    "code": "forbidden"}
        t = c.execute("SELECT id FROM tenant WHERE id=?", (tenant_id,)).fetchone()
        if not t:
            return {"ok": False, "reason": "租户不存在", "code": "not_found"}
        fields = dict(fields or {})
        # 兼容调用方用 logo 作为字段名；统一落库到 logo_url。
        if "logo" in fields and "logo_url" not in fields:
            fields["logo_url"] = fields.get("logo")
        updates = {}
        if "platform_name" in fields:
            name, err = normalize_platform_name(fields.get("platform_name"))
            if err:
                return {"ok": False, "reason": err, "code": "invalid_branding"}
            updates["platform_name"] = name
        if "logo_url" in fields:
            logo, err = normalize_logo_url(fields.get("logo_url"))
            if err:
                return {"ok": False, "reason": err, "code": "invalid_branding"}
            updates["logo_url"] = logo
        if not updates:
            return {"ok": False, "reason": "没有可更新字段", "code": "invalid_request"}
        # P2-B5-02（评审 B5-H1）：审计必须给「改前值」。旧实现只写 after，
        # before_json 恒为空串 → 品牌改动（同步登录页/报告标题）无法定责。
        # 这里写库前读旧值，且只在**真的有变化**时写审计（空值/同值提交不再刷一条）。
        _old = c.execute("SELECT platform_name,logo_url FROM tenant WHERE id=?",
                         (tenant_id,)).fetchone()
        _old_map = {"platform_name": str((_old["platform_name"] if _old else "") or ""),
                    "logo_url": str((_old["logo_url"] if _old else "") or "")}
        _changed = {k: v for k, v in updates.items() if _old_map.get(k, "") != str(v or "")}
        if not _changed:
            branding = get_tenant_branding(tenant_id)
            return {"ok": True, "branding": branding,
                    "platform_name": branding.get("platform_name"),
                    "logo_url": branding.get("logo_url"),
                    "updated": [], "unchanged": True}

        def _mask(d: dict) -> dict:
            """审计里不落 data URL 原文（可能很长且含内嵌凭据），只标 <data-url>/<empty>。"""
            out = {}
            for k, v in d.items():
                sv = str(v or "")
                out[k] = "<data-url>" if (k == "logo_url" and sv.startswith("data:")) else (sv or "<empty>")
            return out
        sets = ",".join(f"{k}=?" for k in _changed)
        c.execute(f"UPDATE tenant SET {sets} WHERE id=?", (*_changed.values(), tenant_id))
        c.commit()
        R.audit_logs.log(actor=actor or uid, action="tenant.config.update",
                         object=tenant_id,
                         before=str(_mask({k: _old_map.get(k, "") for k in _changed})),
                         after=str(_mask(_changed)))
        branding = get_tenant_branding(tenant_id)
        return {"ok": True, "branding": branding,
                "platform_name": branding.get("platform_name"),
                "logo_url": branding.get("logo_url"),
                "updated": sorted(updates.keys())}
    finally:
        c.close()


def list_tenants() -> list:
    """平台只看租户编号/名称/状态/首个系统管理员，不暴露业务信息或空间数。"""
    c = _c()
    try:
        rows = c.execute("SELECT id,code,name,status,created_at,edition,expires_at,platform_name FROM tenant "
                         "WHERE COALESCE(status,'active')!='deleted' ORDER BY created_at").fetchall()
        out = []
        for r in rows:
            ad = c.execute("SELECT u.id,u.name,u.phone,u.email,u.account_no,u.status FROM user u "
                           "JOIN user_role ur ON ur.user_id=u.id JOIN role ro ON ro.id=ur.role_id "
                           "WHERE u.tenant_id=? AND ro.code IN ('admin','super_admin') "
                           "ORDER BY u.is_initial DESC, u.created_at LIMIT 1", (r["id"],)).fetchone()
            out.append({"id": r["id"], "code": r["code"], "name": r["name"],
                        "status": r["status"], "protected": r["id"] == "t-default",
                        "edition": r["edition"] or "trial", "expires_at": r["expires_at"] or "",
                        "platform_name": r["platform_name"] or "",
                        "created_at": r["created_at"] or "",
                        "admin_id": ad["id"] if ad else "", "admin_name": ad["name"] if ad else "",
                        "admin_phone": ad["phone"] if ad else "", "admin_email": ad["email"] if ad else "",
                        "admin_account_no": ad["account_no"] if ad else "",
                        "admin_status": ad["status"] if ad else "",
                        "has_admin": bool(ad)})
        return out
    finally:
        c.close()


def create_tenant(code: str, name: str, admin_phone: str = "", admin_pwd: str = "", actor: str = "",
                  industry: str = "", contact_name: str = "", contact_phone: str = "",
                  contact_email: str = "", edition: str = "trial", expires_at: str = "",
                  admin_name: str = "", admin_email: str = "") -> dict:
    """开通租户：租户编号自动生成；管理员可稍后在该租户下开通。"""
    name = (name or "").strip()
    if len(name) < 2:
        return {"ok": False, "reason": "租户名称至少 2 个字"}
    if not (code or "").strip():
        import datetime as _dt
        code = "T" + _dt.datetime.now().strftime("%Y%m%d%H%M%S")
    code = code.strip()
    edition = edition if edition in ("trial", "formal") else "trial"
    c = _c()
    try:
        if c.execute("SELECT 1 FROM tenant WHERE code=?", (code,)).fetchone():
            return {"ok": False, "reason": "租户编号已存在"}
        tid = db.new_id("t")
        c.execute("INSERT INTO tenant(id,code,name,status,created_at,industry,contact_name,contact_phone,contact_email,edition,expires_at) "
                  "VALUES(?,?,?,'active',?,?,?,?,?,?,?)",
                  (tid, code, name, db.now(), industry or "", contact_name or "",
                   contact_phone or "", contact_email or "", edition, expires_at or ""))
        _wsid = db.new_id("ws")
        import json as _jws
        c.execute("INSERT INTO workspace(id,tenant_id,name,status,created_at,settings_json) VALUES(?,?,?,'active',?,?)",
                  (_wsid, tid, "通用工作空间", db.now(), _jws.dumps({"setup_required": True}, ensure_ascii=False)))
        uid = ""
        if admin_phone and admin_pwd:
            if c.execute("SELECT 1 FROM user WHERE phone=? AND COALESCE(portal,'')='admin'", (admin_phone,)).fetchone():
                c.rollback()
                return {"ok": False, "reason": "该手机号已有管理端账号，不能重复作为租户管理员"}
            from app import auth as _auth
            h, salt = _auth.hash_password(admin_pwd)
            uid = db.new_id("u")
            _ano = _make_account_no(c, "SA")
            _uname = admin_phone
            if c.execute("SELECT 1 FROM user WHERE username=?", (admin_phone,)).fetchone():
                _uname = admin_phone + "#admin"
            c.execute("INSERT INTO user(id,username,name,email,phone,status,password_hash,salt,must_change_pwd,created_at,tenant_id,current_workspace_id,is_initial,account_no,portal) "
                      "VALUES(?,?,?,?,?,'active',?,?,1,?,?,?,1,?,'admin')",
                      (uid, _uname, (admin_name or "未命名用户").strip(),
                       (admin_email or contact_email or "").strip(), admin_phone,
                       h, salt, db.now(), tid, _wsid, _ano))
            rid = c.execute("SELECT id FROM role WHERE code='super_admin'").fetchone()
            if rid:
                c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) VALUES(?,?)", (uid, rid[0]))
        c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.tenant.create",
                         object=tid, after=f"{code}/{name}")
        return {"ok": True, "tenant_id": tid, "admin_id": uid, "code": code}
    finally:
        c.close()


def _make_account_no(c, prefix: str = "SA") -> str:
    import datetime as _dt
    n = c.execute("SELECT count(*) FROM user WHERE account_no LIKE ?", (prefix + "%",)).fetchone()[0] + 1
    return f"{prefix}{_dt.datetime.now().strftime('%Y%m%d')}{n:04d}"


def _tenant_admin_row(c, u) -> dict:
    _ano = u["account_no"] or ""
    if not _ano:
        _ano = _make_account_no(c, "SA")
        c.execute("UPDATE user SET account_no=? WHERE id=?", (_ano, u["id"]))
        c.commit()
    _role = str(u.get("_role_code") or "") if hasattr(u, "get") else ""
    return {"id": u["id"], "account_no": _ano, "name": u["name"] or "",
            "phone": u["phone"] or "", "email": u["email"] or "",
            "status": u["status"] or "active", "is_initial": bool(u["is_initial"]),
            "created_at": u["created_at"] or "", "tenant_id": u["tenant_id"] or "",
            # E-03：角色码由 list_tenant_admins 注入（此处 sqlite3.Row 无 .get）
            "role_code": _role}


def _admin_disable_block_reason(rows, uid: str) -> str:
    """后端唯一停用判定：返回空串表示允许停用，否则返回可展示的原因。

    接口把同一原因下发给平台端 UI，前端置灰/提示与后端 fail-closed 使用同一口径。
    """
    target = next((x for x in rows if str(x["id"]) == str(uid)), None)
    if target is None:
        return "该账号不是租户管理员，不能停用"
    if (target["status"] or "active") != "active":
        return ""
    active = sum(1 for x in rows if (x["status"] or "active") == "active")
    if len(rows) <= 1:
        return "该租户只有一个管理员，不能停用"
    if active <= 1:
        return "至少保留一个启用中的租户管理员，不能停用"
    return ""


def list_tenant_admins(tenant_id: str) -> list:
    c = _c()
    try:
        # E-03（DuMate 20261118）：join 出角色码，供平台端「角色」列显示与系统端一致的角色名
        # （原先平台端该列显示 is_initial 派生值「管理员/初始管理员」，系统端显示「系统管理员」）。
        rows = c.execute(
            "SELECT DISTINCT u.*, r.code AS _role_code FROM user u JOIN user_role ur ON ur.user_id=u.id "
            "JOIN role r ON r.id=ur.role_id "
            "WHERE u.tenant_id=? AND r.code IN ('admin','super_admin') ORDER BY u.created_at", (tenant_id,)).fetchall()
        out = []
        for x in rows:
            d = _tenant_admin_row(c, x)
            _rc = str(x["_role_code"] or "")
            d["role_code"] = _rc
            d["role_label"] = {"super_admin": "系统管理员", "admin": "业务管理员"}.get(_rc, _rc)
            reason = _admin_disable_block_reason(rows, d["id"])
            d["can_disable"] = (d["status"] == "active" and not reason)
            d["disable_block_reason"] = reason
            d["admin_count"] = len(rows)
            d["active_admin_count"] = sum(
                1 for y in rows if (y["status"] or "active") == "active")
            out.append(d)
        return out
    finally:
        c.close()


def add_tenant_admin(tenant_id: str, name: str, phone: str, email: str, pwd: str, actor: str = "") -> dict:
    name = (name or "").strip(); phone = (phone or "").strip(); email = (email or "").strip()
    if len(name) < 2:
        return {"ok": False, "reason": "姓名至少 2 个字"}
    if len(phone) != 11 or not phone.isdigit():
        return {"ok": False, "reason": "手机号必须为 11 位数字"}
    if len(pwd or "") < 8:
        return {"ok": False, "reason": "初始密码至少 8 位"}
    c = _c()
    try:
        t = c.execute("SELECT name FROM tenant WHERE id=?", (tenant_id,)).fetchone()
        if not t:
            return {"ok": False, "reason": "租户不存在"}
        if c.execute("SELECT 1 FROM user WHERE phone=? AND COALESCE(portal,'') IN ('admin','')", (phone,)).fetchone():
            return {"ok": False, "reason": "该手机号已有管理端账号"}
        from app import auth as _auth
        h, salt = _auth.hash_password(pwd)
        uid = db.new_id("u"); ano = _make_account_no(c, "SA")
        ws = c.execute("SELECT id FROM workspace WHERE tenant_id=? ORDER BY created_at LIMIT 1", (tenant_id,)).fetchone()
        wid = ws[0] if ws else ""
        _first = c.execute("SELECT count(*) FROM user u JOIN user_role ur ON ur.user_id=u.id JOIN role r ON r.id=ur.role_id "
                           "WHERE u.tenant_id=? AND r.code IN ('admin','super_admin')", (tenant_id,)).fetchone()[0] == 0
        _uname = phone
        if c.execute("SELECT 1 FROM user WHERE username=?", (phone,)).fetchone():
            _uname = phone + "#admin"
        c.execute("INSERT INTO user(id,username,name,email,phone,status,password_hash,salt,must_change_pwd,created_at,tenant_id,current_workspace_id,is_initial,account_no,portal,initial_password) "
                  "VALUES(?,?,?,?,?,'active',?,?,1,?,?,?,?,?,'admin',?)",
                  (uid, _uname, name, email, phone, h, salt, db.now(), tenant_id, wid, 1 if _first else 0, ano, pwd))
        rid = c.execute("SELECT id FROM role WHERE code='super_admin'").fetchone()
        if rid:
            c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) VALUES(?,?)", (uid, rid[0]))
        c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.tenant_admin.create", object=uid,
                         after=f"{tenant_id}/{phone}")
        return {"ok": True, "id": uid, "account_no": ano}
    finally:
        c.close()


def reset_tenant_admin_password(uid: str, pwd: str, actor: str = "") -> dict:
    from app import auth as _auth
    pwd = pwd or _auth.generate_password(10)
    if len(pwd or "") < 8:
        return {"ok": False, "reason": "新密码至少 8 位"}
    c = _c()
    try:
        u = c.execute("SELECT u.phone, GROUP_CONCAT(r.code) AS roles FROM user u "
                      "LEFT JOIN user_role ur ON ur.user_id=u.id LEFT JOIN role r ON r.id=ur.role_id "
                      "WHERE u.id=? GROUP BY u.id", (uid,)).fetchone()
        if not u:
            return {"ok": False, "reason": "管理员不存在"}
        from app import auth as _auth
        h, salt = _auth.hash_password(pwd)
        c.execute("UPDATE user SET password_hash=?,salt=?,must_change_pwd=1,initial_password=? WHERE id=?", (h, salt, pwd, uid)); c.commit()
        from . import password_reset as _pr
        rec = _pr.issue(uid, pwd, actor=actor or "platform", source="platform_tenant_admin")
        R.audit_logs.log(actor=actor or "platform", action="platform.tenant_admin.reset_password", object=uid)
        return {"ok": True, "temporary_password": pwd, "reset_record_id": rec["id"], "expires_at": rec["expires_at"]}
    finally:
        c.close()


def update_tenant_admin(uid: str, name: str = "", email: str = "", actor: str = "") -> dict:
    name = (name or "").strip(); email = (email or "").strip()
    if len(name) < 2:
        return {"ok": False, "reason": "姓名至少 2 个字"}
    c = _c()
    try:
        if not c.execute("SELECT 1 FROM user WHERE id=?", (uid,)).fetchone():
            return {"ok": False, "reason": "管理员不存在"}
        c.execute("UPDATE user SET name=?,email=? WHERE id=?", (name, email, uid)); c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.tenant_admin.update", object=uid, after=name)
        return {"ok": True}
    finally:
        c.close()


def set_tenant_admin_status(uid: str, status: str, actor: str = "") -> dict:
    if status not in ("active", "disabled"):
        return {"ok": False, "reason": "状态只能是 active/disabled"}
    c = _c()
    try:
        u = c.execute("SELECT u.id,u.tenant_id FROM user u WHERE u.id=?", (uid,)).fetchone()
        if not u:
            return {"ok": False, "reason": "管理员不存在", "code": "not_found"}
        tid = u["tenant_id"] or ""
        rows = c.execute(
            "SELECT DISTINCT u.id, u.status FROM user u JOIN user_role ur ON ur.user_id=u.id "
            "JOIN role r ON r.id=ur.role_id WHERE u.tenant_id=? AND r.code IN ('admin','super_admin')",
            (tid,)).fetchall()
        active = sum(1 for x in rows if (x["status"] or "active") == "active")
        # 目标必须确实是该租户管理员；否则绝不能借这个接口改其它账号状态。
        target = next((x for x in rows if str(x["id"]) == str(uid)), None)
        if target is None:
            return {"ok": False, "reason": "该账号不是租户管理员，不能操作", "protected": True,
                    "code": "not_tenant_admin"}
        if status == "disabled":
            reason = _admin_disable_block_reason(rows, uid)
            if reason:
                return {"ok": False, "reason": reason, "protected": True,
                        "code": "last_active_admin",
                        "admin_count": len(rows), "active_admin_count": active}
        # 初始管理员在租户有多个启用管理员时也允许停用；只守住“至少保留一个启用账号”。
        c.execute("UPDATE user SET status=? WHERE id=?", (status, uid)); c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.tenant_admin.status", object=uid, after=status)
        was_active = (target["status"] or "active") == "active"
        new_active = active + (1 if (status == "active" and not was_active)
                               else -1 if (status == "disabled" and was_active) else 0)
        return {"ok": True, "admin_count": len(rows),
                "active_admin_count": max(0, new_active)}
    finally:
        c.close()


def update_tenant(tenant_id: str, fields: dict, actor: str = "") -> dict:
    allowed = ("name", "industry", "contact_name", "contact_phone", "contact_email",
               "edition", "expires_at", "platform_name", "logo_url")
    raw_fields = dict(fields or {})
    if "logo" in raw_fields and "logo_url" not in raw_fields:
        raw_fields["logo_url"] = raw_fields.get("logo")
    vals = {k: raw_fields.get(k) for k in allowed if k in raw_fields}
    if "name" in vals and len((vals["name"] or "").strip()) < 2:
        return {"ok": False, "reason": "租户名称至少 2 个字"}
    if not vals:
        return {"ok": False, "reason": "没有可更新字段"}
    if vals.get("edition") not in (None, "", "trial", "formal"):
        return {"ok": False, "reason": "版本只能是 trial/formal"}
    if "platform_name" in vals:
        name, err = normalize_platform_name(vals["platform_name"])
        if err:
            return {"ok": False, "reason": err, "code": "invalid_branding"}
        vals["platform_name"] = name
    if "logo_url" in vals:
        logo, err = normalize_logo_url(vals["logo_url"])
        if err:
            return {"ok": False, "reason": err, "code": "invalid_branding"}
        vals["logo_url"] = logo
    c = _c()
    try:
        sets = ",".join(f"{k}=?" for k in vals)
        c.execute(f"UPDATE tenant SET {sets} WHERE id=?", (*vals.values(), tenant_id)); c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.tenant.update", object=tenant_id, after=str(vals))
        return {"ok": True}
    finally:
        c.close()


def delete_tenant(tenant_id: str, actor: str = "") -> dict:
    # 租户不允许删除；停用/归档通过租户状态完成，避免业务数据被误删。
    return {"ok": False, "reason": "当前版本不支持删除租户，请使用停用", "protected": True}



def set_status(tenant_id: str, status: str) -> dict:
    if status not in ("active", "suspended"):
        return {"ok": False, "reason": "状态只能是 active/suspended"}
    if tenant_id == "t-default" and status == "suspended":
        return {"ok": False, "reason": "默认租户承载初始系统管理员，不可停用", "protected": True}
    c = _c()
    try:
        c.execute("UPDATE tenant SET status=? WHERE id=?", (status, tenant_id))
        c.commit()
        R.audit_logs.log(actor="platform", action="platform.tenant.status", object=tenant_id, after=status)
        return {"ok": True}
    finally:
        c.close()


def list_platform_admins() -> list:
    """平台级管理员：role=platform_op，不归属任何租户。"""
    c = _c()
    try:
        rows = c.execute(
            "SELECT u.id,u.name,u.phone,u.email,u.status,u.must_change_pwd,u.created_at,u.account_no,u.is_initial FROM user u "
            "JOIN user_role ur ON ur.user_id=u.id JOIN role r ON r.id=ur.role_id "
            "WHERE r.code='platform_op' AND COALESCE(u.status,'active')!='deleted' ORDER BY u.created_at").fetchall()
        out = []
        for x in rows:
            d = dict(x)
            if not d.get("account_no"):
                _ano = _make_account_no(c, "PO")
                c.execute("UPDATE user SET account_no=? WHERE id=?", (_ano, d["id"]))
                d["account_no"] = _ano
            d["protected"] = (d.get("phone") or "") == "13600003333" or d.get("id") == "u-plat"
            d["role_label"] = "平台管理员"
            out.append(d)
        c.commit()
        return out
    finally:
        c.close()


def create_platform_admin(phone: str, name: str, pwd: str, actor: str = "", email: str = "") -> dict:
    phone = (phone or "").strip(); name = (name or "").strip(); email = (email or "").strip()
    if len(phone) != 11 or not phone.isdigit():
        return {"ok": False, "reason": "手机号必须为 11 位数字"}
    if len(name) < 2:
        return {"ok": False, "reason": "姓名至少 2 个字"}
    if len(pwd or "") < 8:
        return {"ok": False, "reason": "初始密码至少 8 位"}
    c = _c()
    try:
        if c.execute("SELECT 1 FROM user WHERE phone=? AND COALESCE(portal,'')='platform'", (phone,)).fetchone():
            return {"ok": False, "reason": "该手机号已有平台端账号"}
        from app import auth as _auth
        h, s = _auth.hash_password(pwd)
        uid = db.new_id("u")
        _ano = _make_account_no(c, "PO")
        _uname = phone
        if c.execute("SELECT 1 FROM user WHERE username=?", (phone,)).fetchone():
            _uname = phone + "#platform"
        c.execute("INSERT INTO user(id,username,name,email,phone,status,password_hash,salt,must_change_pwd,created_at,tenant_id,workspace_id,current_workspace_id,account_no,is_initial,portal) "
                  "VALUES(?,?,?,?,?,'active',?,?,1,?,NULL,NULL,NULL,?,0,'platform')",
                  (uid, _uname, name, email, phone, h, s, db.now(), _ano))
        rid = c.execute("SELECT id FROM role WHERE code='platform_op'").fetchone()
        if not rid:
            c.rollback()
            return {"ok": False, "reason": "缺少 platform_op 角色"}
        c.execute("INSERT OR IGNORE INTO user_role(user_id,role_id) VALUES(?,?)", (uid, rid[0]))
        c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.admin.create",
                         object=uid, after=phone)
        return {"ok": True, "admin_id": uid}
    finally:
        c.close()


def set_platform_admin_status(uid: str, status: str, actor: str = "") -> dict:
    if status not in ("active", "disabled"):
        return {"ok": False, "reason": "状态只能是 active/disabled"}
    c = _c()
    try:
        row = c.execute("SELECT u.phone FROM user u JOIN user_role ur ON ur.user_id=u.id "
                        "JOIN role r ON r.id=ur.role_id WHERE u.id=? AND r.code='platform_op'", (uid,)).fetchone()
        if not row:
            return {"ok": False, "reason": "平台管理员不存在"}
        # 初始平台账号与当前登录账号不可停用，避免把平台自己锁死
        if (row["phone"] or "") == "13600003333" or uid == actor:
            return {"ok": False, "reason": "初始平台账号/当前登录账号不可停用", "protected": True}
        c.execute("UPDATE user SET status=? WHERE id=?", (status, uid)); c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.admin.status",
                         object=uid, after=status)
        return {"ok": True}
    finally:
        c.close()


def update_platform_admin(uid: str, name: str = "", email: str = "", actor: str = "") -> dict:
    name = (name or "").strip(); email = (email or "").strip()
    c = _c()
    try:
        # E-02（DuMate 20261118）：保护口径必须与 UI / 停用判定一致——
        # 原先只认 id!='u-plat'，但演示/真实库里初始平台账号 id 是 user-platform，
        # 导致「UI 显示不可操作、接口却允许编辑」的口径分叉。统一按「初始手机号 or id」判定。
        # dumate-regress 2026-11-18：保护判定必须先于参数校验——否则非法姓名会先返回
        # 「姓名至少 2 个字」而不带 protected，调用方无法区分「参数错」与「账号受保护」。
        _row = c.execute("SELECT phone FROM user WHERE id=?", (uid,)).fetchone()
        if not _row:
            return {"ok": False, "reason": "平台管理员不存在"}
        if (str(_row["phone"] or "") == "13600003333") or str(uid) == "u-plat":
            return {"ok": False, "reason": "初始平台账号不可编辑", "protected": True}
        if len(name) < 2:
            return {"ok": False, "reason": "姓名至少 2 个字"}
        c.execute("UPDATE user SET name=?,email=? WHERE id=?", (name, email, uid)); c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.admin.update", object=uid, after=name)
        return {"ok": True}
    finally:
        c.close()


def delete_platform_admin(uid: str, actor: str = "") -> dict:
    c = _c()
    try:
        u = c.execute("SELECT phone FROM user WHERE id=?", (uid,)).fetchone()
        if not u:
            return {"ok": False, "reason": "平台管理员不存在"}
        if (u["phone"] or "") == "13600003333" or uid == actor:
            return {"ok": False, "reason": "初始平台账号/当前登录账号不可删除", "protected": True}
        c.execute("UPDATE user SET status='deleted' WHERE id=?", (uid,)); c.commit()
        R.audit_logs.log(actor=actor or "platform", action="platform.admin.delete", object=uid)
        return {"ok": True}
    finally:
        c.close()


def reset_platform_admin_password(uid: str, pwd: str, actor: str = "") -> dict:
    from app import auth as _auth
    pwd = pwd or _auth.generate_password(10)
    if len(pwd or "") < 8:
        return {"ok": False, "reason": "新密码至少 8 位"}
    c = _c()
    try:
        _u = c.execute("SELECT phone FROM user WHERE id=?", (uid,)).fetchone()
        if _u and ((_u["phone"] or "") == "13600003333" or uid == actor):
            return {"ok": False, "reason": "初始平台账号不可重置密码", "protected": True}
        from app import auth as _auth
        h, s = _auth.hash_password(pwd)
        c.execute("UPDATE user SET password_hash=?,salt=?,must_change_pwd=1,initial_password=? WHERE id=?", (h, s, pwd, uid))
        c.commit()
        from . import password_reset as _pr
        rec = _pr.issue(uid, pwd, actor=actor or "platform", source="platform_admin")
        R.audit_logs.log(actor=actor or "platform", action="platform.admin.reset_password", object=uid)
        return {"ok": True, "temporary_password": pwd, "reset_record_id": rec["id"], "expires_at": rec["expires_at"]}
    finally:
        c.close()
