"""问题分类体系（可配置 taxonomy，5 大类 + 子类，报告/导出聚合用）。

产品背景（领域 A「不准」）：finding 需要统一分类口径，供报告、导出、趋势、
问题分布和客户自定义映射使用。本模块提供：
- ``DEFAULT_TAXONOMY``：合规性 / 一致性 / 完整性 / 规范性 / 风险性 5 大类及子类；
- ``resolve(taxonomy, rule)``：规则 → 分类路径（先 category，再 rclass，再关键字，
  最后兜底），返回路径与命中依据，便于解释；
- ``register_custom`` / ``list_custom``：按租户存自定义映射（存 ``sys_config``，
  本轮不建表，Phase 2 再接 API/UI）；
- ``summarize(findings)``：按分类聚合 finding（报告/导出用）。

存储口径：``sys_config`` key = ``taxonomy:custom:<tenant_id>``（JSON）。
只写 sys_config，不改任何业务表 schema；自定义映射只影响「展示/聚合分类」，
不改变规则执行、finding 五态与报告门禁结论。
"""
from __future__ import annotations

import copy
import json
import logging

log = logging.getLogger(__name__)

TAXONOMY_VERSION = "taxonomy-v1"
MAJORS = ("合规性", "一致性", "完整性", "规范性", "风险性")
FALLBACK_PATH = ["规范性", "其他"]

#: 5 大类 → 子类（报告/导出按此顺序展示）
DEFAULT_TAXONOMY = {
    "version": TAXONOMY_VERSION,
    "majors": {
        "合规性": ["限值超标", "禁止性条款", "资质资格", "设备设施", "签章授权"],
        "一致性": ["引用一致", "跨文件一致", "单位口径"],
        "完整性": ["必备材料", "记录字段", "签章完备"],
        "规范性": ["格式规范", "时限频率", "流程步骤", "标识标签"],
        "风险性": ["高风险红线", "异常数值", "敏感主体"],
    },
    # 规则类别（rule_taxonomy 的 12 类）→ 分类路径
    "category_map": {
        "limit": ["合规性", "限值超标"],
        "prohibited": ["合规性", "禁止性条款"],
        "personnel": ["合规性", "资质资格"],
        "equipment": ["合规性", "设备设施"],
        "consistency": ["一致性", "跨文件一致"],
        "citation": ["一致性", "引用一致"],
        "completeness": ["完整性", "必备材料"],
        "record": ["完整性", "记录字段"],
        "format": ["规范性", "格式规范"],
        "preprocess": ["规范性", "流程步骤"],
        "frequency": ["规范性", "时限频率"],
        "label": ["规范性", "标识标签"],
    },
    # 类别无法识别时按风险等级兜底（category 优先于 rclass）
    "rclass_map": {
        "R0": ["风险性", "高风险红线"],
        "R1": ["风险性", "异常数值"],
        "R2": ["风险性", "异常数值"],
        "R3": ["风险性", "敏感主体"],
        "R4": ["风险性", "敏感主体"],
        "R5": ["风险性", "敏感主体"],
    },
    # 关键字兜底：按顺序匹配，先命中先用
    "keywords": [
        {"path": ["风险性", "高风险红线"],
         "keywords": ["红线", "一票否决", "重大风险", "严禁", "不得"],
         "note": "红线/禁止性表述优先归风险性"},
        {"path": ["一致性", "单位口径"],
         "keywords": ["单位不一致", "单位换算", "口径不一致"]},
        {"path": ["完整性", "签章完备"],
         "keywords": ["签章", "盖章", "签字", "公章"]},
        {"path": ["规范性", "时限频率"],
         "keywords": ["截止时间", "时限", "逾期", "频次", "频率"]},
        {"path": ["完整性", "必备材料"],
         "keywords": ["缺少材料", "未提供", "缺失", "必备"]},
    ],
    "rule_map": {},
}


def _path(v) -> list:
    """任意 path 形态 → [major, minor]；不合法返回 []。"""
    if isinstance(v, dict):
        major = str(v.get("major") or v.get("一级") or "").strip()
        minor = str(v.get("minor") or v.get("sub") or v.get("二级") or "").strip()
        return [major, minor] if major and minor else []
    if isinstance(v, (list, tuple)) and len(v) == 2:
        major, minor = str(v[0] or "").strip(), str(v[1] or "").strip()
        return [major, minor] if major and minor else []
    return []


def _parse_json(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str) or not raw.strip():
        return {}
    try:
        obj = json.loads(raw)
    except Exception:  # noqa: BLE001
        return {}
    return obj if isinstance(obj, dict) else {}


def _merged(taxonomy=None) -> dict:
    """传入 taxonomy 与默认合并（传 None 用默认）；majors 缺省用默认。"""
    base = copy.deepcopy(DEFAULT_TAXONOMY)
    if not isinstance(taxonomy, dict):
        return base
    for key in ("category_map", "rclass_map", "rule_map"):
        merged = dict(base.get(key) or {})
        merged.update({str(k): _path(v) or v
                       for k, v in (taxonomy.get(key) or {}).items()})
        base[key] = merged
    if isinstance(taxonomy.get("majors"), dict):
        for major, subs in taxonomy["majors"].items():
            base["majors"][str(major)] = list(subs or [])
    # 自定义 keywords 优先于默认
    custom_kw = [x for x in (taxonomy.get("keywords") or []) if isinstance(x, dict)]
    base["keywords"] = custom_kw + [x for x in base["keywords"]
                                    if x not in custom_kw]
    return base


def _major_allowed(major: str, majors: dict) -> bool:
    return str(major or "").strip() in (majors or {})


def _text_of(rule: dict) -> str:
    parts = []
    for key in ("name", "title", "criterion", "criteria", "description", "detail",
                "summary", "reason", "text"):
        val = rule.get(key)
        if isinstance(val, str) and val.strip():
            parts.append(val)
    for key in ("slots", "scope"):
        nested = rule.get(key)
        if isinstance(nested, dict):
            parts.append(_text_of(nested))
    scope = _parse_json(rule.get("scope_json"))
    if scope:
        parts.append(_text_of(scope))
    slots = _parse_json(rule.get("slots_json"))
    if slots:
        parts.append(_text_of(slots))
    return " ".join(parts)


def _rule_fields(rule: dict) -> tuple:
    """从规则行/finding/规则包点位里取 (code, category, rclass)。"""
    if not isinstance(rule, dict):
        return "", "", ""
    code = str(rule.get("code") or rule.get("rule_code") or rule.get("rule_id")
               or "").strip()
    category = str(rule.get("category") or "").strip()
    rclass = str(rule.get("rclass") or rule.get("risk_level") or "").strip().upper()
    slots = _parse_json(rule.get("slots_json")) or (rule.get("slots")
                                                   if isinstance(rule.get("slots"), dict) else {})
    scope = _parse_json(rule.get("scope_json"))
    if not category:
        category = str(slots.get("category") or scope.get("category") or "").strip()
    if not rclass:
        rclass = str(slots.get("rclass") or scope.get("rclass") or "").strip().upper()
    tax = scope.get("taxonomy") if isinstance(scope.get("taxonomy"), dict) else {}
    if not category:
        category = str(tax.get("category") or "").strip()
    if not rclass:
        rclass = str(tax.get("rclass") or "").strip().upper()
    return code, category, rclass


#: 规则编码 → (category, rclass, name) 的只读补全缓存（finding 里只有规则编码时，
#: 报告/导出仍能按规则类别归类；缓存上限 4096，避免长进程无界增长）
_RULE_META_CACHE = {}


def _db_rule_meta(code: str) -> dict:
    """只读：按规则编码或 id 补全 (category, rclass, name)，取不到返回 {}。"""
    key = str(code or "").strip()
    if not key:
        return {}
    if key in _RULE_META_CACHE:
        return _RULE_META_CACHE[key]
    meta = {}
    try:
        from .. import repositories as R
        row = R.rules.get(key) or {}
        if not row:
            rows = R.rules.list("code=?", (key,), limit=1) or []
            row = rows[0] if rows else {}
        if row:
            scope = _parse_json(row.get("scope_json"))
            tax = scope.get("taxonomy") if isinstance(scope.get("taxonomy"), dict) else {}
            meta = {"category": str(row.get("category") or tax.get("category") or ""),
                    "rclass": str(row.get("rclass") or tax.get("rclass") or "").upper(),
                    "name": str(row.get("name") or "")}
    except Exception:  # noqa: BLE001 - DB 不可用时不做补全，分类回退默认口径
        log.debug("taxonomy: rule meta lookup skipped code=%s", key, exc_info=True)
        meta = {}
    if len(_RULE_META_CACHE) >= 4096:
        _RULE_META_CACHE.clear()
    _RULE_META_CACHE[key] = meta
    return meta


def resolve(taxonomy, rule) -> dict:
    """规则 → 分类路径。

    解析顺序（结果可解释，``matched_by`` 标明依据）：
        1. ``rule_map[code]``（租户自定义按规则编码覆盖，最高优先级）；
        2. ``category_map[category]``（rule_taxonomy 12 类）；
        3. ``rclass_map[rclass]``（类别不可识别时按风险等级归属）；
        4. 关键字扫描（自定义 keywords 优先，再默认 keywords）；
        5. 兜底 ``["规范性", "其他"]``。

    返回：{path, major, minor, matched_by, category, rclass, code, taxonomy_version}
    """
    tax = _merged(taxonomy)
    source_rule = rule if isinstance(rule, dict) else {}
    code, category, rclass = _rule_fields(source_rule)
    enriched = dict(source_rule)
    if code and (not category or not rclass):
        # finding/台账里通常只有规则编码：只读补全规则类别/风险级，报告才能按类聚合
        meta = _db_rule_meta(code)
        category = category or meta.get("category") or ""
        rclass = rclass or meta.get("rclass") or ""
        if meta.get("name") and not enriched.get("name"):
            enriched["name"] = meta["name"]
    base = {"category": category, "rclass": rclass, "code": code,
            "taxonomy_version": str(tax.get("version") or TAXONOMY_VERSION)}

    def _mk(path, matched_by):
        return {**base, "path": list(path), "major": path[0], "minor": path[1],
                "matched_by": matched_by}

    rule_map = tax.get("rule_map") or {}
    if code and code in rule_map:
        p = _path(rule_map[code])
        if p:
            return _mk(p, "rule_map")
    category_map = tax.get("category_map") or {}
    if category and category in category_map:
        p = _path(category_map[category])
        if p:
            return _mk(p, "category_map")
    rclass_map = tax.get("rclass_map") or {}
    if rclass and rclass in rclass_map:
        p = _path(rclass_map[rclass])
        if p:
            return _mk(p, "rclass_map")
    text = _text_of(enriched)
    for group in tax.get("keywords") or []:
        p = _path(group.get("path"))
        if not p:
            continue
        if any(str(kw) and str(kw) in text for kw in (group.get("keywords") or [])):
            return _mk(p, "keyword")
    return _mk(list(FALLBACK_PATH), "fallback")


# ------------------------------------------------------------------ 租户自定义
def _custom_key(tenant_id: str) -> str:
    return f"taxonomy:custom:{tenant_id}"


_ALLOWED_SECTIONS = ("category_map", "rclass_map", "rule_map", "keywords", "majors")


def _validate_mapping(mapping: dict, majors: dict) -> list:
    errors = []
    if not isinstance(mapping, dict):
        return ["自定义分类必须是 JSON 对象"]
    unknown = [k for k in mapping if k not in _ALLOWED_SECTIONS]
    if unknown:
        errors.append(f"未知自定义分区：{'、'.join(unknown)}"
                      f"（允许 {'/'.join(_ALLOWED_SECTIONS)}）")
    for section in ("category_map", "rule_map"):
        values = mapping.get(section)
        if values is None:
            continue
        if not isinstance(values, dict):
            errors.append(f"{section} 必须是对象（key → [大类, 子类]）")
            continue
        for key, val in values.items():
            if not str(key or "").strip():
                errors.append(f"{section} 存在空 key")
                continue
            p = _path(val)
            if not p:
                errors.append(f"{section}.{key} 分类路径必须是 [大类, 子类] 两个非空字符串")
            elif not _major_allowed(p[0], majors):
                errors.append(f"{section}.{key} 大类「{p[0]}」不在 5 大类内"
                              f"（{'/'.join(majors)}）")
    rclass_map = mapping.get("rclass_map")
    if rclass_map is not None:
        if not isinstance(rclass_map, dict):
            errors.append("rclass_map 必须是对象（R0~R5 → [大类, 子类]）")
        else:
            for key, val in rclass_map.items():
                if str(key or "").strip().upper() not in ("R0", "R1", "R2", "R3", "R4", "R5"):
                    errors.append(f"rclass_map 未知风险等级：{key}")
                p = _path(val)
                if not p:
                    errors.append(f"rclass_map.{key} 分类路径必须是 [大类, 子类] 两个非空字符串")
                elif not _major_allowed(p[0], majors):
                    errors.append(f"rclass_map.{key} 大类「{p[0]}」不在 5 大类内")
    keywords = mapping.get("keywords")
    if keywords is not None:
        if not isinstance(keywords, list):
            errors.append("keywords 必须是数组（[{path, keywords}]）")
        else:
            for i, group in enumerate(keywords):
                if not isinstance(group, dict):
                    errors.append(f"keywords[{i}] 必须是对象")
                    continue
                p = _path(group.get("path"))
                if not p:
                    errors.append(f"keywords[{i}].path 必须是 [大类, 子类]")
                elif not _major_allowed(p[0], majors):
                    errors.append(f"keywords[{i}] 大类「{p[0]}」不在 5 大类内")
                kws = group.get("keywords")
                if not isinstance(kws, list) or not [x for x in kws if str(x).strip()]:
                    errors.append(f"keywords[{i}].keywords 必须是非空字符串数组")
    majors_patch = mapping.get("majors")
    if majors_patch is not None:
        if not isinstance(majors_patch, dict):
            errors.append("majors 必须是对象（大类 → 子类数组）")
        else:
            for major, subs in majors_patch.items():
                if str(major or "").strip() not in MAJORS:
                    errors.append(f"majors 不允许新增/改名大类：{major}"
                                  f"（固定 {'/'.join(MAJORS)}）")
                if not isinstance(subs, list) or not [x for x in subs if str(x).strip()]:
                    errors.append(f"majors.{major} 子类必须是非空字符串数组")
    return errors


def list_custom(tenant_id: str) -> dict:
    """读取租户自定义分类映射（无自定义返回 {}）。"""
    tid = str(tenant_id or "").strip()
    if not tid:
        return {}
    try:
        from . import sysconfig
        raw = sysconfig.get(_custom_key(tid), "")
    except Exception:  # noqa: BLE001 - 未初始化/DB 不可用时按无自定义处理
        log.warning("taxonomy: list_custom 读取失败 tenant=%s", tid, exc_info=True)
        return {}
    obj = _parse_json(raw)
    # 存储形态 {"mapping": {...}, "updated_at": "..."}；兼容早期直接存 mapping 的形态
    if isinstance(obj.get("mapping"), dict):
        return obj["mapping"]
    return obj


def get_taxonomy(tenant_id: str = "") -> dict:
    """默认分类 + 该租户自定义覆盖后的完整 taxonomy（可直接传给 resolve）。"""
    custom = list_custom(tenant_id)
    tax = _merged(None)
    if custom:
        tax = _merged({**tax, **custom})
        tax["custom"] = True
    tax["tenant_id"] = str(tenant_id or "")
    tax["custom"] = bool(custom)
    return tax


def register_custom(tenant_id: str, mapping: dict) -> dict:
    """注册/合并租户自定义分类映射（写 ``sys_config``，不建表）。

    返回 {ok, tenant_id, errors, custom}；校验失败不写库。
    """
    tid = str(tenant_id or "").strip()
    if not tid:
        return {"ok": False, "tenant_id": "", "custom": {},
                "errors": ["tenant_id 不能为空（自定义分类必须归属租户）"]}
    errors = _validate_mapping(mapping, DEFAULT_TAXONOMY["majors"])
    if errors:
        return {"ok": False, "tenant_id": tid, "custom": list_custom(tid),
                "errors": errors}
    current = list_custom(tid)
    merged = copy.deepcopy(current)
    for section, value in mapping.items():
        if isinstance(value, dict) and isinstance(merged.get(section), dict):
            merged[section].update(copy.deepcopy(value))
        elif isinstance(value, list) and isinstance(merged.get(section), list):
            merged[section] = copy.deepcopy(value) + merged[section]
        else:
            merged[section] = copy.deepcopy(value)
    try:
        from . import sysconfig
        sysconfig.set_many({_custom_key(tid): json.dumps(
            {"mapping": merged, "updated_at": _now()}, ensure_ascii=False)})
    except Exception as exc:  # noqa: BLE001 - 写失败必须显式返回错误
        log.warning("taxonomy: register_custom 写入失败 tenant=%s", tid, exc_info=True)
        return {"ok": False, "tenant_id": tid, "custom": current,
                "errors": [f"自定义分类写入失败：{type(exc).__name__}: {exc}"]}
    return {"ok": True, "tenant_id": tid, "custom": list_custom(tid), "errors": []}


def _now() -> str:
    from .. import db as _db
    try:
        return _db.now()
    except Exception:  # noqa: BLE001
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def reset_custom(tenant_id: str) -> dict:
    """清除租户自定义分类（恢复默认 5 大类映射）。"""
    tid = str(tenant_id or "").strip()
    if not tid:
        return {"ok": False, "errors": ["tenant_id 不能为空"]}
    try:
        from . import sysconfig
        removed = sysconfig.delete_keys([_custom_key(tid)])
    except Exception as exc:  # noqa: BLE001
        log.warning("taxonomy: reset_custom 失败 tenant=%s", tid, exc_info=True)
        return {"ok": False, "errors": [f"清除失败：{type(exc).__name__}: {exc}"]}
    return {"ok": True, "tenant_id": tid, "removed": int(removed or 0)}


def summarize(findings, taxonomy=None, tenant_id: str = "") -> dict:
    """按分类聚合 finding（报告/导出用）。

    每个 finding 用 ``resolve`` 解析分类；返回总数、按大类、按路径（大类/子类）、
    兜底数量与分类版本。不改变 finding 本身。
    """
    tax = taxonomy if isinstance(taxonomy, dict) else (
        get_taxonomy(tenant_id) if tenant_id else _merged(None))
    by_major = {m: 0 for m in tax.get("majors") or MAJORS}
    by_path = {}
    fallback = 0
    detail = []
    for finding in (findings or []):
        if not isinstance(finding, dict):
            continue
        resolved = resolve(tax, finding)
        major, minor = resolved["major"], resolved["minor"]
        by_major[major] = by_major.get(major, 0) + 1
        key = f"{major}/{minor}"
        by_path[key] = by_path.get(key, 0) + 1
        if resolved.get("matched_by") == "fallback":
            fallback += 1
        detail.append({"finding_id": finding.get("id") or finding.get("finding_id") or "",
                       **{k: resolved[k] for k in ("path", "major", "minor", "matched_by")}})
    return {"total": len(detail), "by_major": by_major,
            "by_path": dict(sorted(by_path.items(), key=lambda kv: -kv[1])),
            "fallback": fallback, "detail": detail,
            "taxonomy_version": str(tax.get("version") or TAXONOMY_VERSION),
            "tenant_id": str(tenant_id or tax.get("tenant_id") or "")}
