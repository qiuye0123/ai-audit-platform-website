"""条款单元结构化抽取（B 子系统第一步）。

针对第 24 轮发现的真实措辞，抽两类正则抽不到的结构：
1) 百分比作用于基数：『累计责任限额为合同总价100万元的20%』
2) 分段费率：『前10天日率0.02%，后10天日率0.03%』
纯正则 + 计算，不调用模型，结果可复现。
"""
import re

_CN_NUM = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}


def _num(s):
    try:
        return float(str(s).replace(",", ""))
    except (TypeError, ValueError):
        return None


def extract_percent_of_base(text: str) -> list:
    """抽『…为<基数描述><数值><单位>的<百分比>%』结构。

    返回 [{label, base_value, base_unit, pct, value}]
    """
    out = []
    pat = re.compile(
        r"([\u4e00-\u9fa5]{0,12}?)(?:为|是|按)[^0-9]{0,10}?(\d+(?:\.\d+)?)\s*(万元|元)\s*的\s*(\d+(?:\.\d+)?)\s*[%％]")
    scale = {"万元": 10000, "元": 1}
    for m in pat.finditer(text or ""):
        label = (m.group(1) or "").strip() or "限额"
        base = _num(m.group(2))
        pct = _num(m.group(4))
        if base is None or pct is None:
            continue
        out.append({"label": label + "上限", "base_value": base * scale[m.group(3)],
                    "base_unit": m.group(3), "pct": pct, "value": base * scale[m.group(3)] * pct / 100})
    return out


def extract_rate_segments(text: str) -> list:
    """抽分段费率：『前10天日率0.02%，后10天日率0.03%』→ [{days, rate}]。"""
    t = text or ""
    segs = []
    pat = re.compile(r"(前|后|第)?\s*(\d+|[一二三四五六七八九十]+)\s*(天|日)[^0-9%％]{0,8}日?率?\s*(\d+(?:\.\d+)?)\s*[%％]")
    for m in pat.finditer(t):
        d = _num(m.group(2)) or _CN_NUM.get(m.group(2))
        r = _num(m.group(4))
        if d and r is not None:
            segs.append({"order": m.group(1) or "", "days": float(d), "rate_pct": r})
    # 去重（同一段可能被多次匹配）
    uniq, seen = [], set()
    for s in segs:
        key = (s["order"], s["days"], s["rate_pct"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(s)
    return uniq


def extract_due_balance_chain(text: str) -> list:
    """抽『逾期第1至4日余额20万元，第5日当日入账8万元』这类时序片段（仅抽取事件，不推演）。"""
    out = []
    pat = re.compile(r"第\s*(\d+)\s*(?:至|-|~)\s*(\d+)\s*日[^0-9]{0,10}(\d+(?:\.\d+)?)\s*(万元|元)")
    for m in pat.finditer(text or ""):
        scale = 10000 if m.group(4) == "万元" else 1
        out.append({"from_day": int(m.group(1)), "to_day": int(m.group(2)),
                    "balance": _num(m.group(3)) * scale})
    return out


def extract_all(text: str) -> dict:
    return {"percent_of_base": extract_percent_of_base(text),
            "rate_segments": extract_rate_segments(text),
            "due_chain": extract_due_balance_chain(text)}


_RATIO_CUES = ["预付款", "预付款项", "首付款", "首付", "质保金", "质量保证金", "尾款", "进度款"]


def extract_ratios(text: str) -> dict:
    """抽「预付款30%」「质保金5%」这类比例，返回 {键: 百分比数值}。"""
    out = {}
    t = text or ""
    for cue in _RATIO_CUES:
        m = re.search(re.escape(cue) + r"[^0-9%％]{0,12}?(\d+(?:\.\d+)?)\s*[%％]", t)
        if m:
            key = "质保金比例" if "质保" in cue else ("预付款比例" if "预付" in cue or "首付" in cue else cue + "比例")
            out.setdefault(key, float(m.group(1)))
    return out


def extract_money_items(text: str) -> dict:
    """抽「报价总价」「分项金额」并求和。"""
    out = {}
    t = text or ""
    m = re.search(r"(?:报价总价|合同总价|总价|合同金额)[^0-9]{0,8}(\d+(?:\.\d+)?)\s*(万元|元)", t)
    if m:
        scale = 10000 if m.group(2) == "万元" else 1
        out["报价总价"] = float(m.group(1)) * scale
        out["总价"] = out["报价总价"]
    items = [float(x) * (10000 if u == "万元" else 1)
             for x, u in re.findall(r"分项[^0-9]{0,10}(\d+(?:\.\d+)?)\s*(万元|元)", t)]
    if items:
        out["分项金额之和"] = sum(items)
    return out


def extract_payment_sum(text: str) -> dict:
    """抽各期付款比例并求和：『首付30%…进度款40%…尾款30%』→ 各期付款比例之和=100。"""
    t = text or ""
    vals = [float(x) for clause in t.split("；") for x in
            re.findall(r"(\d+(?:\.\d+)?)\s*[%％]", clause)
            if any(k in clause for k in ("付款", "支付", "首付", "尾款", "进度款", "结算", "预付"))]
    if len(vals) >= 2:
        return {"各期付款比例之和": sum(vals), "各期付款比例": vals}
    return {}


def extract_penalty_total(text: str) -> dict:
    """按分段费率估算违约金总额：Σ(基数 × 日率% × 天数)。"""
    t = text or ""
    segs = extract_rate_segments(t)
    if not segs:
        return {}
    m = re.search(r"(\d+(?:\.\d+)?)\s*(万元|元)[^。；]{0,12}(?:债务|本金|欠款|余额)", t) or \
        re.search(r"(?:债务|本金|欠款|余额)[^0-9]{0,8}(\d+(?:\.\d+)?)\s*(万元|元)", t)
    if not m:
        return {}
    base = float(m.group(1)) * (10000 if m.group(2) == "万元" else 1)
    total = sum(base * s["rate_pct"] / 100 * s["days"] for s in segs)
    spans = []
    day = 1
    for s in segs:
        spans.append([day, day + int(s["days"]) - 1])
        day += int(s["days"])
    return {"违约金基数": base, "违约金总额": round(total, 2), "各档天数区间": spans}


_CHECK_MARKS = {"☑", "■", "√", "✓", "✔", "▣", "◉"}
_UNCHECK_MARKS = {"□", "☐", "○", "◯"}


def extract_checkboxes(text: str) -> dict:
    """抽取表单勾选项：返回已选/未选/歧义。

    支持「☑预付款 / □定金」这类写法；全部未勾选时标记 ambiguous=True，
    由上层决定“证据不足”而不是猜。
    """
    import re as _re
    t = text or ""
    selected, unselected = [], []
    for m in _re.finditer(r"([☑■√✓✔▣◉□☐○◯])\s*([\u4e00-\u9fa5A-Za-z0-9]{1,12})", t):
        mark, name = m.group(1), m.group(2)
        (selected if mark in _CHECK_MARKS else unselected).append(name)
    all_items = list(dict.fromkeys(selected + unselected))
    return {"selected": selected, "unselected": unselected, "items": all_items,
            "ambiguous": (not selected) and bool(unselected)}


def simulate_balance_chain(opening: float, days: int, events: list = None,
                           rates: list = None) -> dict:
    """时序余额推演：期初余额 + 按日事件 → 逐日余额与（可选）违约金。

    规则：
      - 事件按日生效，direction=reduce 抵减 / increase 增加；
      - 超出区间的日期不生效，进 events_ignored 且说明原因（不静默丢弃）；
      - 传 rates 时按**逐日余额 × 当日费率**累加违约金；
      - 不传 rates 只出余额，不瞎算金额。
    """
    days = int(days or 0)
    ev = sorted([dict(e) for e in (events or [])], key=lambda e: int(e.get("day") or 0))
    per_day = {}
    ignored = []
    for e in ev:
        d = int(e.get("day") or 0)
        if d < 1 or d > days:
            ignored.append({**e, "reason": "超出推演区间，未生效"})
            continue
        per_day.setdefault(d, []).append(e)

    daily, applied = [], []
    balance = float(opening or 0)
    for day in range(1, days + 1):
        for e in per_day.get(day, []):
            amt = float(e.get("amount") or 0)
            if (e.get("direction") or "reduce") == "increase":
                balance += amt
            else:
                balance -= amt
            applied.append({**e, "balance_after": round(balance, 2)})
        daily.append({"day": day, "balance": round(balance, 2)})

    penalty = None
    if rates:
        total = 0.0
        for row in daily:
            d = row["day"]
            rate = None
            for r in rates:
                if int(r.get("from_day") or 1) <= d <= int(r.get("to_day") or days):
                    rate = float(r.get("rate_pct") or 0)
                    break
            if rate is not None:
                total += row["balance"] * rate / 100
        penalty = round(total, 2)

    return {"opening": opening, "days": days, "daily": daily,
            "penalty": penalty, "events_applied": applied, "events_ignored": ignored}
