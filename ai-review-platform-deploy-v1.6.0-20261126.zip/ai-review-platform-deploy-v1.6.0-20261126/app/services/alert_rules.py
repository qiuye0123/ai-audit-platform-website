# -*- coding: utf-8 -*-
"""告警规则（T-201）：模型连续失败 / 审核失败率 / 报告门禁异常 / 队列积压 / 5xx 率。

触发动作（都真实落库，不是只返回内存状态）：
1. 审计：``alert.triggered`` / ``alert.recovered``（actor=system，object=规则 key，
   after=结构化证据：当前值/阈值/样本量/时间）；恢复同样留痕；
2. 站内消息：复用 :func:`app.services.notify.notify_role`（默认 super_admin），
   冷却窗口内不重复轰炸；
3. 指标：``rp_alert_evaluations_total`` / ``rp_alert_fired_total`` /
   ``rp_alert_active``（/metrics 可见）。

阈值配置（env 优先于 sys_config，便于容器化部署；DB 配置可热改）：
- ``RULEPROOF_ALERT_MODEL_FAILS``        模型连续失败次数（默认 3）
- ``RULEPROOF_ALERT_REVIEW_FAIL_RATE``   审核失败率阈值（默认 0.2）
- ``RULEPROOF_ALERT_GATE_RATIO``         门禁拦截比例阈值（默认 0.8，最少 10 次检查）
- ``RULEPROOF_ALERT_QUEUE_BACKLOG``      task_job queued 积压阈值（默认 100）
- ``RULEPROOF_ALERT_SHADOW_BACKLOG``     影子池 pending 阈值（默认 200）
- ``RULEPROOF_ALERT_5XX_RATE``           5xx 比例阈值（默认 0.05，最少 20 个响应）
- ``RULEPROOF_ALERT_COOLDOWN``           冷却秒数（默认 300）
- ``RULEPROOF_ALERT_TENANT``             告警审计归属租户（默认 t-default）
- sys_config 键：``alert.<上面短横线后的小写名>``，如 ``alert.model_consecutive_failures``。

冷却窗口：进程内状态（重启后重置）。单实例部署足够；多实例部署需把状态外置
（本轮 NOT DONE，见交付报告）。健康检查 ``/health`` 每次触发一次评估，
没有额外常驻线程（单机零运维）。
"""
from __future__ import annotations

import json
import logging
import os
import time

from .. import config
from .. import db
from .. import repositories as R
from . import metrics

log = logging.getLogger(__name__)

RULES = ("model_consecutive_failures", "review_failure_rate", "report_gate_anomaly",
         "queue_backlog", "http_5xx_rate")

RULE_LABELS = {
    "model_consecutive_failures": "模型连续失败",
    "review_failure_rate": "审核失败率超阈值",
    "report_gate_anomaly": "报告门禁异常（拦截比例过高）",
    "queue_backlog": "任务队列/影子池积压",
    "http_5xx_rate": "HTTP 5xx 比例超阈值",
}

_ENV = {
    "model_consecutive_failures": ("RULEPROOF_ALERT_MODEL_FAILS", 3),
    "review_failure_rate": ("RULEPROOF_ALERT_REVIEW_FAIL_RATE", 0.2),
    "review_min_runs": ("RULEPROOF_ALERT_REVIEW_MIN_RUNS", 5),
    "gate_anomaly_ratio": ("RULEPROOF_ALERT_GATE_RATIO", 0.8),
    "gate_min_checks": ("RULEPROOF_ALERT_GATE_MIN_CHECKS", 10),
    "queue_backlog": ("RULEPROOF_ALERT_QUEUE_BACKLOG", 100),
    "shadow_backlog": ("RULEPROOF_ALERT_SHADOW_BACKLOG", 200),
    "http_5xx_rate": ("RULEPROOF_ALERT_5XX_RATE", 0.05),
    "http_min_responses": ("RULEPROOF_ALERT_5XX_MIN_RESPONSES", 20),
    "cooldown_seconds": ("RULEPROOF_ALERT_COOLDOWN", 300),
}

# sys_config 键（与 env 同名短名；DB 优先于 env 默认，但 env 显式设置优先于 DB：
# 容器/CI 场景以环境变量为部署事实源，避免旧库里残留配置覆盖部署方意图）。
_SYS_KEYS = {
    "model_consecutive_failures": "alert.model_consecutive_failures",
    "review_failure_rate": "alert.review_failure_rate",
    "review_min_runs": "alert.review_min_runs",
    "gate_anomaly_ratio": "alert.gate_anomaly_ratio",
    "gate_min_checks": "alert.gate_min_checks",
    "queue_backlog": "alert.queue_backlog",
    "shadow_backlog": "alert.shadow_backlog",
    "http_5xx_rate": "alert.http_5xx_rate",
    "http_min_responses": "alert.http_5xx_min_responses",
    "cooldown_seconds": "alert.cooldown_seconds",
}

# 进程内冷却/状态：rule_key -> {"fired": bool, "last_trigger": ts, "since": iso,
#                               "last_detail": str, "value": number}
_STATE: dict = {}


def reset_state() -> None:
    """清空告警状态（测试用；不影响已落库的审计/消息）。"""
    _STATE.clear()


def _env_number(key: str):
    name, default = _ENV[key]
    raw = str(os.environ.get(name) or "").strip()
    if raw == "":
        return None
    try:
        return float(raw)
    except ValueError:
        log.warning("告警阈值环境变量不是数字：%s=%r（忽略，用默认 %s）", name, raw, default)
        return None


def _db_number(key: str):
    try:
        from . import sysconfig
        raw = str(sysconfig.get(_SYS_KEYS[key]) or "").strip()
        if raw == "":
            return None
        return float(raw)
    except Exception:  # noqa: BLE001 - 配置读失败不回退成“坏阈值”，用默认
        log.warning("告警阈值 sys_config 读取失败 key=%s", key, exc_info=True)
        return None


def get_thresholds() -> dict:
    """合并阈值：env > sys_config > 内置默认。类型按默认值归一。"""
    out = {}
    for key, (_name, default) in _ENV.items():
        val = _env_number(key)
        if val is None:
            val = _db_number(key)
        if val is None:
            val = default
        out[key] = int(val) if isinstance(default, int) else float(val)
    return out


def set_threshold(key: str, value, actor: str = "system") -> dict:
    """写 sys_config 阈值（super_admin 操作；env 显式设置时该键不会生效，返回值说明）。"""
    if key not in _SYS_KEYS:
        return {"ok": False, "status": 400, "code": "unknown_threshold",
                "error": f"未知阈值：{key}"}
    try:
        num = float(value)
    except (TypeError, ValueError):
        return {"ok": False, "status": 400, "code": "invalid_value",
                "error": f"阈值必须是数字：{value!r}"}
    from . import sysconfig
    sysconfig.set_many({_SYS_KEYS[key]: str(num)})
    effective = _env_number(key)
    env_name = _ENV[key][0]
    return {"ok": True, "key": key, "value": num if not isinstance(_ENV[key][1], int) else int(num),
            "config_key": _SYS_KEYS[key], "actor": actor,
            "env_override": (env_name if effective is not None else ""),
            "env_takes_precedence": effective is not None}


# ---------------------------------------------------------------------------
# 各规则的数据采集（真实来源：metrics 内存 + DB 只读）
# ---------------------------------------------------------------------------
def _db_queue_stats() -> dict:
    out = {"queued": 0, "running": 0, "shadow_pending": 0}
    try:
        with db.session() as c:
            out["queued"] = int(c.execute(
                "SELECT COUNT(*) FROM task_job WHERE status='queued'").fetchone()[0] or 0)
            out["running"] = int(c.execute(
                "SELECT COUNT(*) FROM task_job WHERE status='running'").fetchone()[0] or 0)
            try:
                out["shadow_pending"] = int(c.execute(
                    "SELECT COUNT(*) FROM shadow_item WHERE shadow_status='pending'"
                ).fetchone()[0] or 0)
            except Exception:  # noqa: BLE001 - 老库无 shadow_item 表：如实保持 0 且不影响其它规则
                out["shadow_pending"] = 0
    except Exception:  # noqa: BLE001
        log.warning("告警规则：队列积压统计失败", exc_info=True)
    return out


def _db_review_stats(window_days: int = 7) -> dict:
    """审核失败率（按审计项目状态，最近 window_days 天）；无样本 total=0。"""
    out = {"total": 0, "failed": 0, "rate": 0.0, "window_days": int(window_days)}
    try:
        cutoff = time.strftime("%Y-%m-%d %H:%M:%S",
                               time.localtime(time.time() - int(window_days) * 86400))
        with db.session() as c:
            row = c.execute(
                "SELECT COUNT(*) AS total, "
                "SUM(CASE WHEN status IN ('audit_failed','failed','error') THEN 1 ELSE 0 END) "
                "AS failed FROM audit_case WHERE created_at>=?", (cutoff,)).fetchone()
            total = int((row["total"] if row else 0) or 0)
            failed = int((row["failed"] if row else 0) or 0)
        out.update(total=total, failed=failed,
                   rate=(failed / total) if total else 0.0)
    except Exception:  # noqa: BLE001
        log.warning("告警规则：审核失败率统计失败", exc_info=True)
    return out


def _evaluate_conditions(thresholds: dict | None = None) -> list:
    """逐规则计算是否触发；返回 [{key, fired, value, threshold, detail, samples}]。"""
    th = thresholds or get_thresholds()
    snap = metrics.snapshot()
    queue = _db_queue_stats()
    review = _db_review_stats()
    out = []

    # 1) 模型连续失败
    fails = int(snap.get("llm_consecutive_failures") or 0)
    out.append({
        "key": "model_consecutive_failures",
        "fired": fails >= int(th["model_consecutive_failures"]),
        "value": fails,
        "threshold": int(th["model_consecutive_failures"]),
        "samples": len(snap.get("llm_recent") or []),
        "detail": f"模型最近连续失败 {fails} 次（阈值 {int(th['model_consecutive_failures'])}）",
    })

    # 2) 审核失败率
    rate = float(review.get("rate") or 0.0)
    out.append({
        "key": "review_failure_rate",
        "fired": (int(review.get("total") or 0) >= int(th["review_min_runs"])
                  and rate >= float(th["review_failure_rate"])),
        "value": round(rate, 4),
        "threshold": float(th["review_failure_rate"]),
        "samples": int(review.get("total") or 0),
        "detail": (f"最近 {review.get('window_days')} 天审核 {review.get('total')} 个，"
                   f"失败 {review.get('failed')} 个，失败率 {rate:.1%}"
                   f"（阈值 {float(th['review_failure_rate']):.1%}，最少样本 "
                   f"{int(th['review_min_runs'])}）"),
    })

    # 3) 报告门禁异常（拦截比例过高 = 规则/数据系统性问题，而不是单份报告不过）
    gate = snap.get("gate") or {}
    g_checks = int(gate.get("checks") or 0)
    g_ratio = float(gate.get("blocked_ratio") or 0.0)
    out.append({
        "key": "report_gate_anomaly",
        "fired": (g_checks >= int(th["gate_min_checks"])
                  and g_ratio >= float(th["gate_anomaly_ratio"])),
        "value": round(g_ratio, 4),
        "threshold": float(th["gate_anomaly_ratio"]),
        "samples": g_checks,
        "detail": (f"报告门禁检查 {g_checks} 次，拦截 {int(gate.get('blocked') or 0)} 次，"
                   f"拦截比例 {g_ratio:.1%}（阈值 {float(th['gate_anomaly_ratio']):.1%}，"
                   f"最少检查 {int(th['gate_min_checks'])}）"),
    })

    # 4) 队列/影子池积压
    out.append({
        "key": "queue_backlog",
        "fired": (queue["queued"] >= int(th["queue_backlog"])
                  or queue["shadow_pending"] >= int(th["shadow_backlog"])),
        "value": max(queue["queued"], queue["shadow_pending"]),
        "threshold": max(int(th["queue_backlog"]), int(th["shadow_backlog"])),
        "samples": queue["queued"] + queue["running"] + queue["shadow_pending"],
        "detail": (f"任务队列 queued={queue['queued']}（阈值 {int(th['queue_backlog'])}）、"
                   f"running={queue['running']}；影子池 pending={queue['shadow_pending']}"
                   f"（阈值 {int(th['shadow_backlog'])}）"),
    })

    # 5) HTTP 5xx 率
    http = snap.get("http") or {}
    h_total = int(http.get("responses") or 0)
    h_rate = float(http.get("rate") or 0.0)
    out.append({
        "key": "http_5xx_rate",
        "fired": (h_total >= int(th["http_min_responses"])
                  and h_rate >= float(th["http_5xx_rate"])),
        "value": round(h_rate, 4),
        "threshold": float(th["http_5xx_rate"]),
        "samples": h_total,
        "detail": (f"HTTP 响应 {h_total} 个，其中 5xx {int(http.get('5xx') or 0)} 个，"
                   f"比例 {h_rate:.1%}（阈值 {float(th['http_5xx_rate']):.1%}，最少响应 "
                   f"{int(th['http_min_responses'])}）"),
    })
    return out


# ---------------------------------------------------------------------------
# 触发 / 恢复 / 冷却
# ---------------------------------------------------------------------------
def _alert_tenant() -> str:
    return (os.environ.get("RULEPROOF_ALERT_TENANT") or "").strip() or "t-default"


def _receivers() -> list:
    raw = str(os.environ.get("RULEPROOF_ALERT_RECEIVERS") or "").strip()
    roles = [x.strip() for x in raw.split(",") if x.strip()] if raw else ["super_admin"]
    return roles or ["super_admin"]


def _write_audit(action: str, rule_key: str, payload: dict) -> None:
    """告警审计写入（独立事务；失败显式记录日志，不影响其它规则评估）。"""
    try:
        from . import ctx as _ctx
        with _ctx.scoped(_alert_tenant(), ""):
            R.audit_logs.log(actor="system", action=action, object=rule_key,
                             after=json.dumps(payload, ensure_ascii=False)[:4000])
    except Exception:  # noqa: BLE001 - 审计失败必须留结构化日志（铁律 2）
        log.error("告警审计写入失败 action=%s rule=%s", action, rule_key, exc_info=True)


def _notify(action: str, rule_key: str, detail: str) -> list:
    """站内消息（复用 notify；事件走已登记的 system.incident，可见角色 super_admin）。"""
    title = ("【系统告警】%s" % RULE_LABELS.get(rule_key, rule_key)) if action == "alert.triggered" \
        else ("【告警恢复】%s" % RULE_LABELS.get(rule_key, rule_key))
    sent = []
    try:
        from . import notify
        for role in _receivers():
            try:
                sent.extend(notify.notify_role(role, "system.incident", title, detail))
            except Exception:  # noqa: BLE001
                log.warning("告警站内消息发送失败 rule=%s role=%s", rule_key, role,
                            exc_info=True)
    except Exception:  # noqa: BLE001
        log.warning("告警站内消息模块不可用 rule=%s", rule_key, exc_info=True)
    return sent


def active_alerts() -> list:
    return [{"rule": k, "label": RULE_LABELS.get(k, k),
             "since": v.get("since"), "detail": v.get("last_detail"),
             "value": v.get("value")}
            for k, v in sorted(_STATE.items()) if v.get("fired")]


def evaluate(persist: bool = True, now: float | None = None) -> dict:
    """评估全部告警规则；persist=True 时触发/恢复写审计与站内消息（受冷却约束）。"""
    now = float(now if now is not None else time.time())
    th = get_thresholds()
    conditions = _evaluate_conditions(th)
    events = []
    for cond in conditions:
        key = cond["key"]
        fired = bool(cond["fired"])
        st = _STATE.get(key)
        if fired:
            st = _STATE.setdefault(key, {"fired": False, "last_trigger": 0.0,
                                         "since": "", "last_detail": "", "value": 0})
            st["value"] = cond["value"]
            st["last_detail"] = cond["detail"]
            if not st["fired"]:
                st.update(fired=True, last_trigger=now,
                          since=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now)))
                events.append({"action": "alert.triggered", "rule": key,
                               "label": RULE_LABELS.get(key, key),
                               "detail": cond["detail"], "value": cond["value"],
                               "threshold": cond["threshold"], "samples": cond["samples"]})
            elif now - float(st.get("last_trigger") or 0) >= float(th["cooldown_seconds"]):
                st["last_trigger"] = now
                events.append({"action": "alert.triggered", "rule": key,
                               "label": RULE_LABELS.get(key, key),
                               "detail": cond["detail"], "value": cond["value"],
                               "threshold": cond["threshold"], "samples": cond["samples"],
                               "repeat": True})
            else:
                events.append({"action": "alert.suppressed", "rule": key,
                               "detail": "冷却窗口内，不重复触发",
                               "cooldown_remaining": round(
                                   float(th["cooldown_seconds"])
                                   - (now - float(st.get("last_trigger") or 0)), 1)})
        else:
            if st and st.get("fired"):
                st.update(fired=False, last_trigger=0.0, since="")
                events.append({"action": "alert.recovered", "rule": key,
                               "label": RULE_LABELS.get(key, key),
                               "detail": "指标恢复：" + cond["detail"],
                               "value": cond["value"], "threshold": cond["threshold"],
                               "samples": cond["samples"]})
            else:
                _STATE.setdefault(key, {"fired": False, "last_trigger": 0.0,
                                        "since": "", "last_detail": "",
                                        "value": cond["value"]})
                _STATE[key]["value"] = cond["value"]

    triggered = [e for e in events if e["action"] == "alert.triggered"]
    recovered = [e for e in events if e["action"] == "alert.recovered"]
    if persist:
        try:
            metrics.counter("rp_alert_evaluations_total",
                            value=1, result=("fired" if triggered else "ok"))
            for ev in events:
                if ev["action"] == "alert.triggered":
                    metrics.counter("rp_alert_fired_total", value=1, rule=ev["rule"])
                    _write_audit("alert.triggered", ev["rule"], {
                        "rule": ev["rule"], "label": ev["label"],
                        "detail": ev["detail"], "value": ev["value"],
                        "threshold": ev["threshold"], "samples": ev["samples"],
                        "repeat": bool(ev.get("repeat")), "at": db.now(),
                        "cooldown_seconds": th["cooldown_seconds"],
                    })
                    ev["notified"] = _notify("alert.triggered", ev["rule"], ev["detail"])
                elif ev["action"] == "alert.recovered":
                    _write_audit("alert.recovered", ev["rule"], {
                        "rule": ev["rule"], "label": ev["label"],
                        "detail": ev["detail"], "value": ev["value"],
                        "threshold": ev["threshold"], "at": db.now()})
                    ev["notified"] = _notify("alert.recovered", ev["rule"], ev["detail"])
        except Exception:  # noqa: BLE001
            log.error("告警持久化失败（评估结果仍返回）", exc_info=True)
    try:
        metrics.gauge_set("rp_alert_active", len(active_alerts()))
    except Exception:  # noqa: BLE001
        log.warning("告警活跃数指标写入失败", exc_info=True)
    return {"ok": True, "at": db.now(), "thresholds": th,
            "active": active_alerts(), "events": events,
            "triggered": len(triggered), "recovered": len(recovered),
            "suppressed": len([e for e in events if e["action"] == "alert.suppressed"])}


# ---------------------------------------------------------------------------
# /health 依赖状态（DB/模型可配置为必需项）
# ---------------------------------------------------------------------------
def _health_flag(name: str, default: str) -> bool:
    raw = str(os.environ.get(name) or default).strip().lower()
    return raw in ("1", "true", "yes", "on")


def db_dependency() -> dict:
    required = _health_flag("RULEPROOF_HEALTH_REQUIRE_DB", "1")
    try:
        with db.session() as c:
            c.execute("SELECT 1").fetchone()
        return {"status": "ok", "required": required, "detail": "SQLite 可读写"}
    except Exception as exc:  # noqa: BLE001 - 健康检查要报告原因，而不是抛
        log.warning("健康检查：DB 不可用", exc_info=True)
        return {"status": "error", "required": required,
                "detail": f"DB 不可用：{type(exc).__name__}"}


def model_dependency() -> dict:
    required = _health_flag("RULEPROOF_HEALTH_REQUIRE_MODEL", "0")
    llm = getattr(config, "LLM", {}) or {}
    enabled = bool(llm.get("enabled"))
    configured = bool(str(llm.get("base_url") or "").strip()
                      and str(llm.get("api_key") or "").strip())
    consecutive = metrics.llm_consecutive_failures()
    if not enabled:
        status = "disabled"
        detail = "模型调用未启用（RULEPROOF_LLM_ENABLED 非 1）；语义能力降级为确定性规则"
    elif not configured:
        status = "unconfigured"
        detail = "模型已启用但 base_url/api_key 未配置"
    elif consecutive >= 3:
        status = "degraded"
        detail = f"模型最近连续失败 {consecutive} 次（见告警 model_consecutive_failures）"
    else:
        status = "ok"
        detail = f"模型 {llm.get('model') or '(未命名)'} 已配置"
    return {"status": status, "required": required,
            "configured": bool(enabled and configured),
            "consecutive_failures": consecutive, "detail": detail}


def health_payload() -> dict:
    """健康检查负载：DB/模型/告警三块依赖 + 顺带评估告警（冷却内不重复）。"""
    db_dep = db_dependency()
    model_dep = model_dependency()
    alert_eval = {}
    try:
        alert_eval = evaluate(persist=True)
    except Exception:  # noqa: BLE001 - 告警评估异常不能让 /health 崩，但必须上报
        log.error("健康检查：告警规则评估异常", exc_info=True)
        alert_eval = {"ok": False, "error": "告警评估异常（见服务日志）"}
    alerts_dep = {"status": "ok" if alert_eval.get("ok", True) else "error",
                  "required": False,
                  "detail": (f"活跃告警 {len(alert_eval.get('active') or [])} 条"
                             if alert_eval.get("ok", True) else "告警评估异常")}
    deps = {"db": db_dep, "model": model_dep, "alerts": alerts_dep}
    # required 的依赖必须 status=ok 才算健康；非必需依赖只上报状态不阻断
    ok = all((not d.get("required")) or d.get("status") == "ok"
             for d in deps.values())
    return {
        "ok": ok,
        "dependencies": deps,
        "alerts": {"active": alert_eval.get("active") or [],
                   "triggered": alert_eval.get("triggered", 0),
                   "recovered": alert_eval.get("recovered", 0),
                   "at": alert_eval.get("at", "")},
    }
