# -*- coding: utf-8 -*-
"""真实模型调用 → ``llm_trace`` 落库（服务层实现，引擎经 hooks 适配层调用）。

## 为什么需要这个模块

P1-B6-03：智能体/判据/页面助手/OCR 兜底等调用点**没有** ``llm.begin_trace()``
上下文，此前这些真实模型调用被直接丢弃 → 运维看板「模型调用」恒 0、模型页调用
统计全是「—」。本模块负责补落这类调用：``run_id``/``case_id`` 允许为空，``stage``
取调用方标记（agent）或 ``misc``，**失败也落行**（可计量、可归因）。

## 分层约束（engine_pack_test 断言）

``app/engine/llm.py`` 不得 import services，也不得直接写库；它只调用
``app/engine/hooks.py::record_llm_call`` 适配函数。本模块是落库实现，
注册到该 hook（build49 B1 已删除独立注册入口 ``app/services/hooks_register.py``；
未注册时 hooks 懒加载同一实现）。

## 失败口径

落库失败不得影响模型调用主链（与改动前一致）：异常只写结构化日志，不向上抛。
"""
from __future__ import annotations

import json
import logging

from .. import db
from . import ctx as _ctx

log = logging.getLogger(__name__)


def record_orphan_call(call: dict) -> None:
    """落一条「无 begin_trace 上下文」的真实模型调用（失败也落行）。

    ``call`` 字段与 ``app.engine.llm._record_call`` 构造的一致：
    model/prompt_hash/prompt_chars/latency_ms/tokens_in/tokens_out/point_ids/
    stage/messages_json/response_text；缺字段按空处理。不抛异常。
    """
    try:
        try:
            case_id = str(_ctx.get_case() or "")
        except Exception:  # noqa: BLE001 - 无 case 上下文时落空 case_id，不阻断
            case_id = ""
        stage = str((call or {}).get("stage") or "").strip()
        if not stage or stage == "未标注":
            stage = "misc"
        try:
            with db.session() as c:
                c.execute(
                    "INSERT INTO llm_trace(id,run_id,case_id,model,prompt_hash,prompt_chars,"
                    "latency_ms,tokens_in,tokens_out,point_ids,evidence_ids,stage,messages_json,"
                    "response_text,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (db.new_id("lt"), "", case_id, call.get("model") or "",
                     call.get("prompt_hash") or "", int(call.get("prompt_chars") or 0),
                     int(call.get("latency_ms") or 0), int(call.get("tokens_in") or 0),
                     int(call.get("tokens_out") or 0),
                     json.dumps(call.get("point_ids") or [], ensure_ascii=False), "",
                     stage, call.get("messages_json") or "",
                     call.get("response_text") or "", db.now()))
                c.commit()
        except Exception:  # noqa: BLE001 - 记录失败不得影响模型调用，但必须留结构化日志
            log.warning(
                "llm_trace 落库失败（无 trace 上下文调用）：model=%s stage=%s",
                call.get("model") or "", stage, exc_info=True)
    except Exception:  # noqa: BLE001 - 见模块 docstring：可观测性故障不影响主链
        log.warning(
            "llm_trace fallback 初始化失败：model=%s",
            (call or {}).get("model") or "", exc_info=True)


__all__ = ["record_orphan_call"]
