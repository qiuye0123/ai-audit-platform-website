"""开放平台（P1）：AppKey/AppSecret 签名鉴权、任务推送、结果回调（Webhook）。"""
import hashlib
import logging
import hmac
import json
import os
import time
import urllib.request

from datetime import datetime, timedelta
from .. import db, auth, obs
from .. import repositories as R
from . import secret_box
from . import net_guard


def _scope() -> tuple[str, str]:
    try:
        from . import ctx as _ctx
        c = _ctx.get_context() or {}
        return c.get("tenant_id") or "", c.get("workspace_id") or ""
    except Exception:
        return "", ""


def _visible(row: dict, tenant: str = "", workspace: str = "", allow_legacy_default: bool = True) -> bool:
    if not row:
        return False
    t = str(row.get("tenant_id") or "")
    w = str(row.get("workspace_id") or "")
    if tenant and t and t != tenant:
        return False
    if workspace and w and w != workspace:
        return False
    if (t or w) == "" and allow_legacy_default:
        # 迁移前旧数据无空间键：仅默认空间可见，避免把历史应用泄漏到私有空间
        if (tenant and tenant != "t-default") or (workspace and workspace != "ws-default"):
            return False
    return True


def _app_for_admin(app_id: str) -> tuple[dict, dict|None]:
    app = R.open_apps.get(app_id)
    t, w = _scope()
    if not app or not _visible(app, t, w):
        return {}, {"error": "应用不存在"}
    return app, None


# ---------------------------------------------------------------- 签名
def sign(secret: str, app_key: str, timestamp: str, nonce: str, body: bytes) -> str:
    msg = f"{app_key}{timestamp}{nonce}".encode() + body
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


def _nonce_ttl() -> int:
    try:
        return max(600, int(os.environ.get("RULEPROOF_OPEN_NONCE_TTL", "600") or 600))
    except Exception:
        return 600


_NONCE_CLEANUP_INTERVAL = 60
_LAST_NONCE_CLEANUP = 0.0


def cleanup_nonce(force: bool = False, now_ts: float | None = None) -> dict:
    """清理超过 nonce 时间窗的 open_nonce 行。

    时间口径修复：旧实现 `created_at < datetime('now','-10 minutes')` 用 SQLite 的
    UTC 时间对比 `db.now()` 写入的本地时间：
    - UTC+ 时区：本地时间比 UTC 快，过期行几乎永远不删 → nonce 表持续膨胀；
    - UTC- 时区：本地时间比 UTC 慢，刚写入的 nonce 立即被删 → 重放防护失效。
    现在统一用与 db.now() 相同的本地时间计算 cutoff。
    """
    global _LAST_NONCE_CLEANUP
    now = float(now_ts if now_ts is not None else time.time())
    if not force and (now - _LAST_NONCE_CLEANUP) < _NONCE_CLEANUP_INTERVAL:
        return {"skipped": True, "deleted": 0, "cutoff": ""}
    cutoff = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now - _nonce_ttl()))
    try:
        with db.session() as c:
            cur = c.execute("DELETE FROM open_nonce WHERE created_at < ?", (cutoff,))
            c.commit()
            deleted = int(cur.rowcount or 0)
    except Exception:
        logging.getLogger(__name__).warning("open nonce cleanup failed", exc_info=True)
        return {"skipped": False, "deleted": 0, "cutoff": cutoff, "error": "cleanup_failed"}
    _LAST_NONCE_CLEANUP = now
    return {"skipped": False, "deleted": deleted, "cutoff": cutoff}


def _check_and_store_nonce(app_key: str, nonce: str) -> str:
    """重放校验 + 落库，同一短事务同一连接（避免旧实现多次开连接/异常路径泄漏）。

    返回空串表示通过；否则返回拒绝原因。SELECT 命中重复时不写库。
    """
    try:
        with db.session() as c:
            r = c.execute("SELECT 1 FROM open_nonce WHERE nonce=?", (nonce,)).fetchone()
            if r:
                c.commit()
                return "nonce 重复（疑似重放）"
            c.execute("INSERT INTO open_nonce(nonce,app_key,created_at) VALUES(?,?,?)",
                      (nonce, app_key, db.now()))
            c.commit()
    except Exception:
        logging.getLogger(__name__).warning('open nonce store failed', exc_info=True)
        return "nonce 存储失败，拒绝本次请求"
    return ""


def _verify_signature(app_key: str, timestamp: str, nonce: str, body: bytes, signature: str) -> tuple:
    """基础字段 + 时间窗 + 应用 + HMAC 签名校验（不消费 nonce）。返回 (ok, app, reason)。"""
    if not app_key or not signature:
        return False, None, "缺少签名"
    if not nonce:
        return False, None, "缺少 nonce"
    try:
        ts = int(timestamp or 0)
    except Exception:
        return False, None, "时间戳非法"
    if abs(time.time() - ts) > 300:
        return False, None, "时间戳过期"
    rows = R.open_apps.list("app_key=? AND status='active'", (app_key,))
    if not rows:
        return False, None, "应用不存在或已停用"
    app = rows[0]
    try:
        expect = sign(secret_box.open_secret(app["app_secret"]), app_key, timestamp, nonce, body)
    except Exception:
        return False, app, "应用密钥不可解密"
    if not hmac.compare_digest(expect, signature):
        return False, None, "签名不匹配"
    return True, app, ""


def verify(app_key: str, timestamp: str, nonce: str, body: bytes, signature: str) -> tuple:
    """返回 (ok, app, reason)。timestamp ±300s、nonce 去重。"""
    ok, app, why = _verify_signature(app_key, timestamp, nonce, body, signature)
    if not ok:
        return False, app, why
    cleanup_nonce()   # 节流清理（时间口径与 db.now() 一致，不再偶发/提前删除）
    nwhy = _check_and_store_nonce(str(app_key), str(nonce))
    if nwhy:
        # 签名有效但 nonce 被拒：仍返回 app，供沙箱记录“已签名但被拒绝”的重放。
        # 所有调用方都必须按 ok=False 处理。
        return False, app, nwhy
    return True, app, ""


# ---------------------------------------------------------------- 应用管理（管理员）
def create_app(name: str, callback_url: str = "", events: str = "audit.completed",
                actor: str = "") -> dict:
    app_key = "AK" + db.new_id("app")[-12:]
    app_secret = auth.generate_password(32)
    aid = db.new_id("app")
    _t, _w = _scope()
    R.open_apps.insert(id=aid, app_key=app_key, app_secret=secret_box.seal(app_secret), name=name or "未命名应用",
                       callback_url=callback_url, events=events, status="active", created_at=db.now(),
                       tenant_id=_t, workspace_id=_w)
    # DU-15（P2，2026-11-25）：审计 actor 旧实现硬编码 "admin"，super_admin 创建
    # 应用时无法追责到真实操作人。现在由路由/CLI 传入会话 sub；内部脚本未传时
    # 保留 "admin" 兼容（不伪造真实 uid）。
    R.audit_logs.log(actor=actor or "admin", action="open.app_created", object=aid, after=name or "")
    return {"id": aid, "app_key": app_key, "app_secret": app_secret, "name": name,
            "callback_url": callback_url, "events": events}


def _mask_secret(value) -> str:
    try:
        plain = secret_box.open_secret(value)
        return (plain[:6] + "****") if plain else "****"
    except Exception:
        return "****"


def list_apps() -> list:
    out = []
    try:
        events = R.open_events.list(order="created_at DESC", limit=500)
    except Exception:
        events = []
    by_app = {}
    for e in events:
        by_app.setdefault(e.get("app_key") or "", []).append(e)
    _t, _w = _scope()
    for a in R.open_apps.list(order="created_at DESC"):
        if not _visible(a, _t, _w):
            continue
        es = by_app.get(a["app_key"], [])
        delivered = sum(1 for e in es if (e.get("status") or "") == "delivered" or e.get("delivered"))
        failed = sum(1 for e in es if (e.get("status") or "") == "failed")
        pending = sum(1 for e in es if (e.get("status") or "") in ("pending", "retry"))
        out.append({"id": a["id"], "app_key": a["app_key"],
                    "app_secret_masked": _mask_secret(a.get("app_secret")),
                    "secret_status": "已配置" if a.get("app_secret") else "未配置",
                    "name": a["name"], "callback_url": a.get("callback_url") or "",
                    "events": a.get("events") or "", "status": a.get("status") or "active",
                    "created_at": a.get("created_at") or "",
                    "event_count": len(es), "delivered": delivered, "failed": failed, "pending": pending,
                    "last_event_at": (es[0].get("created_at") if es else "") or "",
                    "last_error": next((e.get("last_error") for e in es if e.get("last_error")), ""),
                    "tenant_id": a.get("tenant_id") or "", "workspace_id": a.get("workspace_id") or ""})
    return out


# ---------------------------------------------------------------- 任务推送
MAX_OPEN_FILE_BYTES = 20 * 1024 * 1024
MAX_OPEN_TOTAL_BYTES = 60 * 1024 * 1024
OPEN_EXTS = (".xlsx", ".docx", ".pdf", ".md", ".txt")


def accept_task(app: dict, payload: dict) -> dict:
    """接收外部任务：只做校验和入队，审核由后台 worker 异步执行。"""
    import base64
    import os
    files = payload.get("files") or []
    if not isinstance(files, list) or not files:
        raise ValueError("files 不能为空")
    total = 0
    clean = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("files 格式不合法")
        fn = str(f.get("filename") or "").strip() or "file.xlsx"
        ext = os.path.splitext(fn)[1].lower()
        if ext not in OPEN_EXTS:
            raise ValueError(f"不支持的文件类型：{fn}")
        data = f.get("content_base64") or ""
        try:
            raw = base64.b64decode(data, validate=True)
        except Exception as exc:
            raise ValueError(f"文件 {fn} base64 不合法") from exc
        if not raw:
            raise ValueError(f"文件 {fn} 为空")
        if len(raw) > MAX_OPEN_FILE_BYTES:
            raise ValueError(f"文件 {fn} 超过 20MB 上限")
        total += len(raw)
        if total > MAX_OPEN_TOTAL_BYTES:
            raise ValueError("文件合计超过 60MB 上限")
        clean.append({"filename": fn, "content_base64": data})
    tid = db.new_id("ot")
    _t = app.get("tenant_id") or ""
    _w = app.get("workspace_id") or ""
    with db.session() as c:
        c.execute("INSERT INTO open_task_queue(id,app_key,payload_json,status,error,project_id,created_at,updated_at,tenant_id,workspace_id) "
                  "VALUES(?,?,?,'accepted','','',?,?,?,?)",
                  (tid, app.get("app_key", ""), json.dumps({"payload": payload, "files": clean}, ensure_ascii=False),
                   db.now(), db.now(), _t, _w))
        # F2（评审 P0 第二批）：``open.task_accepted`` 在 audit.ACTION_LABEL 登记为
        # 「外部推送任务」，但修复前 accept_task 只 INSERT 队列表、**没有任何审计写入**，
        # 审计中心永远看不到外部推送。与「审计是只读完整轨迹」的契约冲突。
        # 结论：保留登记并在此补写（入站受理是关键业务写）——与队列入库同事务，
        # 审计失败即整体回滚，不让“任务已受理但无轨迹”发生。
        from . import audit as _audit
        from . import ctx as _cx
        # 审计行必须带应用所属租户/空间（审计页按租户过滤）；手工切上下文后在 finally
        # 恢复调用方上下文，避免把外层（HTTP 请求/CLI）的作用域清空。
        # L98 P1：完整状态快照/恢复（避免只回 tenant/workspace 丢掉审核模式/system）
        _prev = _cx.snapshot()
        _cx.set_context(_t, _w)
        try:
            _audit.log_in_tx(
                c, actor="open:" + str(app.get("app_key") or ""),
                action="open.task_accepted", object_=tid,
                after=json.dumps({"task_id": tid, "app_key": app.get("app_key") or "",
                                  "app_name": app.get("name") or "",
                                  "files": [x.get("filename") for x in clean],
                                  "file_count": len(clean),
                                  "external_id": str(payload.get("external_id") or ""),
                                  "status": "accepted"}, ensure_ascii=False))
        finally:
            _cx.restore(_prev)
    return {"task_id": tid, "status": "accepted"}


def process_tasks(limit: int = 2) -> dict:
    """后台执行已接受任务：建项目、上传、审核、入队回调。"""
    from . import project, ctx
    stats = {"scanned": 0, "completed": 0, "failed": 0}
    with db.session() as c:
        rows = [dict(r) for r in c.execute(
            "SELECT * FROM open_task_queue WHERE status='accepted' ORDER BY created_at LIMIT ?", (limit,)).fetchall()]
    for row in rows:
        stats["scanned"] += 1
        tid = row["id"]
        _t_q = time.time()
        obs.log_event("queue.task.start", module="services.open", status="processing",
                      task_id=tid, app_key=row.get("app_key") or "")
        with db.session() as c:
            c.execute("UPDATE open_task_queue SET status='processing',updated_at=? WHERE id=? AND status='accepted'",
                      (db.now(), tid))
            c.commit()
        try:
            data = json.loads(row.get("payload_json") or "{}")
            payload = data.get("payload") or {}
            files = data.get("files") or []
            app_rows = R.open_apps.list("app_key=?", (row.get("app_key") or "",))
            app = app_rows[0] if app_rows else {}
            _at = app.get("tenant_id") or row.get("tenant_id") or "t-default"
            _aw = app.get("workspace_id") or row.get("workspace_id") or "ws-default"
            ctx.set_context(_at, _aw)
            pid = project.create(payload.get("project_name") or "外部推送任务",
                                 user="open:" + str(row.get("app_key") or ""),
                                 description=payload.get("external_id") or "")
            import base64, os, tempfile
            for f in files:
                raw = base64.b64decode(f.get("content_base64") or "", validate=True)
                tmp = tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(f["filename"])[1])
                tmp.write(raw); tmp.close()
                try:
                    project.add_document(pid, tmp.name, f["filename"])
                finally:
                    os.unlink(tmp.name)
            result = project.audit(pid, ai_assist=True)
            with db.session() as c:
                c.execute("UPDATE open_task_queue SET status='completed',project_id=?,updated_at=? WHERE id=?",
                          (pid, db.now(), tid))
                c.commit()
            R.open_tasks.insert(id=tid, project_id=pid, external_id=payload.get("external_id") or "",
                                callback_url=payload.get("callback_url") or app.get("callback_url") or "",
                                status="completed", created_at=db.now(),
                                tenant_id=app.get("tenant_id") or "", workspace_id=app.get("workspace_id") or "")
            callback = payload.get("callback_url") or app.get("callback_url") or ""
            if callback:
                _enqueue(app, callback, "audit.completed", {
                    "event": "audit.completed", "task_id": tid, "project_id": pid,
                    "external_id": payload.get("external_id") or "",
                    "summary": result.get("summary") or {},
                    "findings": [{"id": f["id"], "severity": f["severity"], "title": f["title"]}
                                 for f in result.get("findings") or []]}, tid)
            stats["completed"] += 1
            obs.log_event("queue.task.finish", module="services.open", status="done",
                          latency=obs.elapsed_ms(_t_q), task_id=tid, project_id=pid,
                          app_key=row.get("app_key") or "")
        except Exception as exc:
            _err_txt = f"{type(exc).__name__}: {str(exc)[:300]}"
            with db.session() as c:
                c.execute("UPDATE open_task_queue SET status='failed',error=?,updated_at=? WHERE id=?",
                          (_err_txt, db.now(), tid))
                c.commit()
            stats["failed"] += 1
            obs.log_event("queue.task.finish", module="services.open", level="error",
                          status="failed", latency=obs.elapsed_ms(_t_q),
                          error=_err_txt, task_id=tid,
                          app_key=row.get("app_key") or "")
    return stats


def queue_task(tid: str) -> dict:
    with db.session() as c:
        r = c.execute("SELECT * FROM open_task_queue WHERE id=?", (tid,)).fetchone()
    if not r:
        return {}
    d = dict(r)
    try:
        data = json.loads(d.get("payload_json") or "{}")
        d["files"] = [{"filename": x.get("filename")} for x in (data.get("files") or [])]
    except Exception:
        d["files"] = []
    return {k: v for k, v in d.items() if k != "payload_json"}


def _enqueue(app, callback_url, event_type, payload, task_id=""):
    """把回调事件落库，交给后台 worker 异步投递（返回 event_id）。"""
    eid = db.new_id("ev")
    if not (app.get("tenant_id") or app.get("workspace_id")):
        _full = R.open_apps.list("app_key=?", (app.get("app_key") or "",))
        if _full:
            app = {**app, **dict(_full[0])}
    R.open_events.insert(id=eid, task_id=task_id, type=event_type,
                         payload=json.dumps(payload, ensure_ascii=False),
                         delivered=0, retry_count=0, created_at=db.now(),
                         app_key=app.get("app_key", ""), callback_url=callback_url,
                         status="pending", attempts=0,
                         tenant_id=app.get("tenant_id") or "", workspace_id=app.get("workspace_id") or "")
    return eid


MAX_ATTEMPTS = 5
BACKOFF_SECONDS = (0, 5, 15, 60, 300)


def enqueue_event(app: dict, event_type: str, payload: dict, callback_url: str = "") -> str:
    return _enqueue(app, callback_url or app.get("callback_url") or "", event_type, payload)


def _sign_headers(app: dict, body: bytes):
    ts = str(int(time.time()))
    nonce = db.new_id("n")[-12:]
    sig = sign(secret_box.open_secret(app["app_secret"]), app["app_key"], ts, nonce, body)
    return {"Content-Type": "application/json", "X-App-Key": app["app_key"],
            "X-Timestamp": ts, "X-Nonce": nonce, "X-Signature": sig}


def _audit_webhook_failed(event: dict, attempts: int, err: str) -> None:
    """F2：``open.webhook_failed`` 终态审计（回调最终失败必须可追溯）。

    修复前 ``audit.ACTION_LABEL`` 登记了「回调失败」但**没有任何写入点**：失败只进
    站内通知，审计中心查不到。结论：保留登记并补写（这是终态业务事实）。

    独立事务写；异常只记 warning —— 投递结果已落库，不能因为审计异常把「已发生的
    失败」翻成异常抛给投递 worker（否则统计与状态会不一致）。
    """
    try:
        with db.session() as _c:
            from . import audit as _audit_f
            from . import ctx as _cx_f
            with _cx_f.scoped(str(event.get("tenant_id") or ""),
                              str(event.get("workspace_id") or "")):
                _audit_f.log_in_tx(
                    _c, actor="open:" + str(event.get("app_key") or ""),
                    action="open.webhook_failed", object_=str(event.get("id") or ""),
                    after=json.dumps({
                        "event_id": str(event.get("id") or ""),
                        "event_type": str(event.get("type") or ""),
                        "app_key": str(event.get("app_key") or ""),
                        "task_id": str(event.get("task_id") or ""),
                        "attempts": int(attempts),
                        "last_error": str(err or "")[:300],
                        "status": "failed"}, ensure_ascii=False))
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).warning(
            "open webhook_failed audit skipped event=%s", event.get("id"), exc_info=True)


def deliver_pending(limit: int = 20, sleep_fn=time.sleep, now_fn=time.time) -> dict:
    """投递待发送事件：签名 + 重试/退避 + 状态落库。返回统计。"""
    import datetime as _dt
    stats = {"scanned": 0, "delivered": 0, "retry": 0, "failed": 0}
    rows = R.open_events.list("delivered=0", order="created_at ASC", limit=limit * 3)
    apps = {a["app_key"]: a for a in R.open_apps.list()}
    for e in rows:
        if stats["scanned"] >= limit:
            break
        st = e.get("status") or "pending"
        if st not in ("pending", "retry"):
            continue
        nxt = e.get("next_retry_at") or ""
        if nxt:
            try:
                if _dt.datetime.fromisoformat(nxt.replace("Z", "")) > _dt.datetime.now():
                    continue
            except Exception:
                pass
        attempts = int(e.get("attempts") or 0)
        if attempts >= MAX_ATTEMPTS:
            R.open_events.update(e["id"], status="failed", delivered=0)
            _audit_webhook_failed(e, attempts, e.get("last_error") or "超过最大重试次数")
            stats["failed"] += 1
            continue
        app = apps.get(e.get("app_key") or "")
        url = (e.get("callback_url") or (app or {}).get("callback_url") or "")
        if not app or app.get("status") != "active" or not url:
            R.open_events.update(e["id"], status="failed", last_error="应用停用或无回调地址")
            # F2：终态失败（不再重试）必须留痕，与投递失败同口径。
            _audit_webhook_failed(e, attempts, "应用停用或无回调地址")
            stats["failed"] += 1
            continue
        allowed, why = net_guard.check_url(url, allow_loopback=os.environ.get("RULEPROOF_OPEN_ALLOW_LOOPBACK") == "1")
        if not allowed:
            R.open_events.update(e["id"], status="failed", last_error=why)
            # F2：回调地址被安全策略拒绝同样是「回调失败」终态，必须留痕。
            _audit_webhook_failed(e, attempts, "回调地址不被允许：" + str(why or ""))
            stats["failed"] += 1
            continue
        stats["scanned"] += 1
        body = (e.get("payload") or "{}").encode()
        headers = _sign_headers(app, body)
        ok, err = False, ""
        try:
            status, _resp = net_guard.request_url(
                url, body, headers, timeout=8,
                allow_loopback=os.environ.get("RULEPROOF_OPEN_ALLOW_LOOPBACK") == "1")
            ok = 200 <= int(status) < 300
            if not ok:
                err = f"HTTP {status}"
        except Exception as ex:
            err = f"{type(ex).__name__}: {str(ex)[:120]}"
        attempts += 1
        if ok:
            R.open_events.update(e["id"], delivered=1, status="delivered", attempts=attempts,
                                 last_error="", retry_count=attempts - 1)
            stats["delivered"] += 1
        else:
            failed_final = attempts >= MAX_ATTEMPTS
            nxt_ts = datetime.now() + timedelta(seconds=BACKOFF_SECONDS[min(attempts, len(BACKOFF_SECONDS) - 1)])
            R.open_events.update(e["id"], status="failed" if failed_final else "retry",
                                 attempts=attempts, last_error=err, retry_count=attempts,
                                 next_retry_at=nxt_ts.strftime("%Y-%m-%dT%H:%M:%S"))
            stats["failed" if failed_final else "retry"] += 1
            if failed_final:
                # F2：终态失败写审计（保留 ACTION_LABEL 登记并补写入点）。
                _audit_webhook_failed(e, attempts, err)
                try:
                    from . import notify as _ntf
                    _ntf.notify_system_incident("开放平台回调最终失败",
                                                f"{e.get('app_key') or ''} / {e.get('type') or ''} / {err[:180]}")
                except Exception:
                    logging.getLogger(__name__).debug('open fail notify skipped', exc_info=True)
    return stats


def update_app(app_id: str, name: str = "", callback_url: str = "", events: str = "", status: str = "") -> dict:
    app, err = _app_for_admin(app_id)
    if err:
        return err
    upd = {}
    if name:
        upd["name"] = name
    if callback_url:
        upd["callback_url"] = callback_url
    if events:
        upd["events"] = events
    if status in ("active", "disabled"):
        upd["status"] = status
    if upd:
        R.open_apps.update(app_id, **upd)
    return {"ok": True, "updated": list(upd.keys()), "app_key": app["app_key"]}


def rotate_secret(app_id: str) -> dict:
    app, err = _app_for_admin(app_id)
    if err:
        return err
    new_secret = auth.generate_password(32)
    R.open_apps.update(app_id, app_secret=secret_box.seal(new_secret))
    return {"ok": True, "app_key": app["app_key"], "app_secret": new_secret}


def send_test_event(app_id: str) -> dict:
    app, err = _app_for_admin(app_id)
    if err:
        return err
    payload = {"event": "ping", "app_key": app["app_key"], "sent_at": db.now()}
    eid = enqueue_event(app, "ping", payload)
    return {"ok": True, "event_id": eid, "callback_url": app.get("callback_url") or ""}


# 沙箱接收端资源上限：未认证请求不得无限写库（旧实现任何匿名 POST 都会 INSERT）。
MAX_SANDBOX_BODY_BYTES = int(os.environ.get("RULEPROOF_SANDBOX_MAX_BODY", str(256 * 1024)) or 256 * 1024)
SANDBOX_RETENTION_DAYS = float(os.environ.get("RULEPROOF_SANDBOX_RETENTION_DAYS", "7") or 7)
SANDBOX_MAX_ROWS = int(os.environ.get("RULEPROOF_SANDBOX_MAX_ROWS", "1000") or 1000)
_SANDBOX_CLEANUP_INTERVAL = 60
_LAST_SANDBOX_CLEANUP = 0.0


def cleanup_sandbox(force: bool = False, now_ts: float | None = None) -> dict:
    """沙箱记录保留期清理：按天删除过期行，并把总行数压到硬上限（默认 7 天 / 1000 行）。"""
    global _LAST_SANDBOX_CLEANUP
    now = float(now_ts if now_ts is not None else time.time())
    if not force and (now - _LAST_SANDBOX_CLEANUP) < _SANDBOX_CLEANUP_INTERVAL:
        return {"skipped": True, "deleted": 0, "trimmed": 0, "cutoff": ""}
    cutoff = time.strftime("%Y-%m-%d %H:%M:%S",
                           time.localtime(now - max(0.0, SANDBOX_RETENTION_DAYS) * 86400))
    deleted = trimmed = 0
    try:
        with db.session() as c:
            cur = c.execute("DELETE FROM open_sandbox WHERE received_at < ?", (cutoff,))
            deleted = int(cur.rowcount or 0)
            total = int(c.execute("SELECT COUNT(*) FROM open_sandbox").fetchone()[0])
            if total > SANDBOX_MAX_ROWS:
                keep = max(0, SANDBOX_MAX_ROWS)
                cur2 = c.execute(
                    "DELETE FROM open_sandbox WHERE id IN "
                    "(SELECT id FROM open_sandbox ORDER BY received_at ASC, rowid ASC LIMIT ?)",
                    (total - keep,))
                trimmed = int(cur2.rowcount or 0)
            c.commit()
    except Exception:
        logging.getLogger(__name__).warning("open sandbox cleanup failed", exc_info=True)
        return {"skipped": False, "deleted": 0, "trimmed": 0, "cutoff": cutoff, "error": "cleanup_failed"}
    _LAST_SANDBOX_CLEANUP = now
    return {"skipped": False, "deleted": deleted, "trimmed": trimmed, "cutoff": cutoff}


def receive_sandbox(headers: dict, body: bytes) -> dict:
    """模拟接收端：记录回调并验证签名（用于仿真测试）。

    安全边界（20261117）：
    - 未通过 HMAC 签名的请求一律不落库（返回 401），杜绝匿名写库/撑大表；
    - body 超过 MAX_SANDBOX_BODY_BYTES 直接 413，不做签名计算、不落库；
    - 只有已签名请求（含 nonce 重放的已签名请求，valid=0 留证）才写记录；
    - 落库前按保留期/行数上限清理（cleanup_sandbox）。
    """
    key = headers.get("X-App-Key") or headers.get("x-app-key") or ""
    sig = headers.get("X-Signature") or headers.get("x-signature") or ""
    ts = headers.get("X-Timestamp") or headers.get("x-timestamp") or ""
    nonce = headers.get("X-Nonce") or headers.get("x-nonce") or ""
    if body and len(body) > MAX_SANDBOX_BODY_BYTES:
        return {"ok": False, "valid": False, "stored": False,
                "reason": f"body 超过沙箱 {MAX_SANDBOX_BODY_BYTES // 1024}KB 上限", "http_status": 413}
    sig_ok, app, why = _verify_signature(key, ts, nonce, body, sig)
    if not sig_ok:
        # 关键修复：无有效签名不得 INSERT（旧实现无条件写 open_sandbox）。
        obs.log_event("open.sandbox.rejected", module="services.open", level="warning",
                      status="rejected", reason=why[:80], app_key=key[:40])
        return {"ok": False, "valid": False, "stored": False, "reason": why, "http_status": 401}
    nonce_reason = _check_and_store_nonce(str(key), str(nonce))
    valid = not nonce_reason
    cleanup_sandbox()
    R.open_sandbox.insert(id=db.new_id("sb"), app_key=key, signature=sig, timestamp=ts,
                          nonce=nonce, body=body.decode("utf-8", "replace")[:MAX_SANDBOX_BODY_BYTES],
                          valid=1 if valid else 0, received_at=db.now(),
                          tenant_id=(app or {}).get("tenant_id") or "",
                          workspace_id=(app or {}).get("workspace_id") or "")
    return {"ok": valid, "valid": valid, "stored": True,
            "reason": nonce_reason, "http_status": 200 if valid else 401}


def list_sandbox(limit: int = 50) -> list:
    _t, _w = _scope()
    out = []
    for x in R.open_sandbox.list(order="received_at DESC", limit=limit * 2):
        if not _visible(x, _t, _w):
            continue
        out.append({"id": x["id"], "app_key": x["app_key"], "valid": bool(x["valid"]),
                    "signature": x["signature"], "received_at": x["received_at"],
                    "body": (x["body"] or "")[:300]})
        if len(out) >= limit:
            break
    return out



def _dispatch(app, callback_url, event_type, payload, task_id=""):
    """（同步版，保留给测试/手动触发）POST 回调，失败重试 3 次。"""
    body = json.dumps(payload, ensure_ascii=False).encode()
    ts = str(int(time.time()))
    nonce = db.new_id("n")[-10:]
    sig = sign(secret_box.open_secret(app["app_secret"]), app["app_key"], ts, nonce, body)
    eid = db.new_id("ev")
    R.open_events.insert(id=eid, task_id=task_id, type=event_type, payload=payload if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False),
                         delivered=0, retry_count=0, created_at=db.now(),
                         tenant_id=app.get("tenant_id") or "", workspace_id=app.get("workspace_id") or "")
    allowed, why = net_guard.check_url(callback_url, allow_loopback=os.environ.get("RULEPROOF_OPEN_ALLOW_LOOPBACK") == "1")
    if not allowed:
        raise ValueError(f"callback URL 不安全：{why}")
    for attempt in range(3):
        try:
            _st, _ = net_guard.request_url(callback_url, body, {
                "Content-Type": "application/json",
                "X-App-Key": app["app_key"], "X-Timestamp": ts, "X-Nonce": nonce, "X-Signature": sig,
            }, timeout=5, allow_loopback=os.environ.get("RULEPROOF_OPEN_ALLOW_LOOPBACK") == "1")
            if 200 <= int(_st) < 300:
                R.open_events.update(eid, delivered=1, retry_count=attempt)
                return True
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        time.sleep(3 ** attempt)
    R.open_events.update(eid, retry_count=3)
    return False


def task_detail(tid: str) -> dict:
    q = queue_task(tid)
    if q:
        return {"task_id": q["id"], "project_id": q.get("project_id") or "",
                "external_id": "", "status": q.get("status") or "",
                "error": q.get("error") or "", "files": q.get("files") or [],
                "created_at": q.get("created_at") or ""}
    t = R.open_tasks.get(tid)
    if not t:
        return {"error": "task not found"}
    return {"task_id": t["id"], "project_id": t["project_id"], "external_id": t.get("external_id") or "",
            "status": t.get("status") or "", "created_at": t.get("created_at") or ""}


def list_events(limit: int = 50, status: str = "", app_key: str = "") -> list:
    out = []
    _t, _w = _scope()
    for e in R.open_events.list(order="created_at DESC", limit=limit * 3):
        if not _visible(e, _t, _w):
            continue
        st = e.get("status") or ("delivered" if e.get("delivered") else "pending")
        if status and st != status and not (status == "retry" and st == "retry"):
            continue
        if app_key and (e.get("app_key") or "") != app_key:
            continue
        if len(out) >= limit:
            break
        out.append({"id": e["id"], "task_id": e.get("task_id") or "", "type": e.get("type") or "",
                    "is_test_event": (e.get("type") == "ping"),
                    "app_key": e.get("app_key") or "", "delivered": bool(e.get("delivered")), "retry_count": e.get("retry_count") or 0,
                    "status": e.get("status") or ("delivered" if e.get("delivered") else "pending"),
                    "attempts": e.get("attempts") or 0, "last_error": e.get("last_error") or "",
                    "next_retry_at": e.get("next_retry_at") or "",
                    "created_at": e.get("created_at") or ""})
    return out


def _payload_preview(raw: str, limit: int = 4000) -> tuple:
    """事件 payload 预览：合法 JSON 时格式化；只读截断，不回传任何密钥。"""
    text = str(raw or "")
    try:
        pretty = json.dumps(json.loads(text), ensure_ascii=False, indent=2)
    except Exception:
        pretty = text
    return pretty[:limit], len(pretty) > limit


def event_detail(event_id: str, user: dict | None = None) -> dict:
    """投递详情（只读）：事件、签名预览、尝试次数、错误、下次重试。

    AppSecret 只用于计算签名预览（截断展示），不返回密钥本身；
    非本租户事件返回空（调用方按 404 处理）。
    """
    eid = str(event_id or "").strip()
    if not eid:
        return {}
    try:
        row = R.open_events.get(eid)
    except Exception:
        row = None
    if not row:
        return {}
    _t, _w = _scope()
    if not _visible(row, _t, _w):
        return {}
    e = dict(row)
    app = {}
    try:
        apps = R.open_apps.list("app_key=?", (e.get("app_key") or "",))
        app = dict(apps[0]) if apps else {}
    except Exception:
        app = {}
    payload_text, payload_truncated = _payload_preview(e.get("payload") or "")
    signature_preview = ""
    timestamp = ""
    nonce = ""
    try:
        raw = str(e.get("payload") or "").encode("utf-8")
        timestamp = str(int(time.time()))
        nonce = db.new_id("n")[-10:]
        secret = secret_box.open_secret(app.get("app_secret") or "") if app else ""
        if secret and app.get("app_key"):
            sig = sign(secret, app.get("app_key") or "", timestamp, nonce, raw)
            signature_preview = sig[:16] + "…（截断预览，完整签名由投递时生成）"
    except Exception:
        signature_preview = ""
    st = str(e.get("status") or ("delivered" if e.get("delivered") else "pending"))
    return {
        "ok": True, "id": eid, "type": e.get("type") or "", "task_id": e.get("task_id") or "",
        "app_key": e.get("app_key") or "", "app_name": app.get("name") or "",
        "callback_url": e.get("callback_url") or app.get("callback_url") or "",
        "status": st,
        "delivered": bool(e.get("delivered")),
        "attempts": int(e.get("attempts") or 0),
        "retry_count": int(e.get("retry_count") or 0),
        "last_error": e.get("last_error") or "",
        "next_retry_at": e.get("next_retry_at") or "",
        "created_at": e.get("created_at") or "",
        "is_test_event": (e.get("type") == "ping"),
        "payload_preview": payload_text,
        "payload_truncated": payload_truncated,
        "signature_preview": signature_preview,
        "signature_note": ("投递时使用 HMAC-SHA256(AppSecret, AppKey + Timestamp + Nonce + Body)；"
                           "完整签名与 AppSecret 不在页面展示"),
        "signature_headers_sample": {"X-App-Key": e.get("app_key") or "",
                                     "X-Timestamp": timestamp or "（投递时生成）",
                                     "X-Nonce": nonce or "（投递时生成）",
                                     "X-Signature": signature_preview or "（投递时生成）"},
        "retry_policy": {"max_attempts": MAX_ATTEMPTS, "backoff_seconds": list(BACKOFF_SECONDS)},
        "note": "投递详情为只读；重试由后台 worker 按退避策略执行，不提供页面强制重试。",
    }
