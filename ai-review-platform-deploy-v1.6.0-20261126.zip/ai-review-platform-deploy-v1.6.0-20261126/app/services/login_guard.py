"""登录失败限流：IP + 账号双维度，默认 5 次/15 分钟，锁 15 分钟。

进程内内存实现，适合单实例；多实例部署时应替换为 Redis/DB 计数。
"""
from __future__ import annotations
import os
import threading
import time

_LOCK = threading.Lock()
_FAILS: dict[str, list[float]] = {}
_LOCKED: dict[str, float] = {}


def _window() -> int:
    try:
        return max(60, int(os.environ.get("RULEPROOF_LOGIN_WINDOW_SEC", "900")))
    except Exception:
        return 900


def _max_fails() -> int:
    try:
        return max(1, int(os.environ.get("RULEPROOF_LOGIN_MAX_FAILS", "5")))
    except Exception:
        return 5


def _keys(ip: str, ident: str) -> list[str]:
    return [f"ip:{ip or '-'}", f"acct:{(ident or '').strip().lower() or '-'}"]


def check(ip: str, ident: str) -> tuple[bool, int]:
    now = time.time()
    with _LOCK:
        for k in _keys(ip, ident):
            until = _LOCKED.get(k, 0)
            if until > now:
                return False, max(1, int(until - now))
        return True, 0


def fail(ip: str, ident: str) -> None:
    now = time.time()
    with _LOCK:
        win = _window()
        for k in _keys(ip, ident):
            arr = [t for t in _FAILS.get(k, []) if now - t < win]
            arr.append(now)
            _FAILS[k] = arr
            if len(arr) >= _max_fails():
                _LOCKED[k] = now + win


def success(ip: str, ident: str) -> None:
    with _LOCK:
        for k in _keys(ip, ident):
            _FAILS.pop(k, None)
            _LOCKED.pop(k, None)
