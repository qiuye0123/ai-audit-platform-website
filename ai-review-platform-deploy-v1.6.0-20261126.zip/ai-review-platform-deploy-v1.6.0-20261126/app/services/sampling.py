"""抽检策略（计划层，纯计算、不落库、不依赖数据库）。

产品背景（领域 A：审核能力「不漏」）：审核项目文档多时，全量审核成本高，
需要可解释、可复现的抽检计划。本模块只负责**计划层**——给定文档数量/来源与
高风险规则清单，产出「选哪些文档、排除哪些、为什么」；真正的执行（按计划调用
审核主链）由 Phase 2 接线完成，见 docs/qa/领域A吸收_20261120.md。

三种模式：
- ``full``：全部文档进入审核（默认，等价于不抽检）；
- ``ratio``：按 ``ratio`` 向上取整抽检（如 5 份 × 0.2 → 1 份）；
- ``risk``：命中高风险规则的文档优先进入抽检，不足按比例补齐。

设计口径（交付诚实性）：
1. 结果**确定性**：不引入随机数，同样的输入永远得到同样的顺序；抽检不是抽样统计
   意义上的随机样本，报告/UI 必须如实写「确定性按序抽检」，不得包装成随机抽样。
2. 没有任何真实命中数据时，``risk`` 模式不会编造风险：按比例兜底并在 ``reason``
   里写明「未提供风险命中数据」。
3. ``selected``/``excluded`` 里的元素默认是文档下标（0..n-1）；调用方给了
   ``doc_hits`` 时用其中的文档标识（``doc``/``document_id``），便于直接回填项目。
"""
from __future__ import annotations

import math

VALID_MODES = ("full", "ratio", "risk")


def _norm_ratio(ratio) -> float:
    try:
        r = float(ratio)
    except (TypeError, ValueError):
        raise ValueError(f"抽检比例必须是 0~1 的数字：{ratio!r}") from None
    if not (0.0 <= r <= 1.0):
        raise ValueError(f"抽检比例必须在 0~1 之间：{r}")
    return r


def _doc_label(hit: dict, index: int):
    for key in ("doc", "document_id", "doc_id", "id"):
        if hit.get(key) not in (None, ""):
            return hit[key]
    return index


def _norm_hits(doc_hits) -> list:
    out = []
    for i, hit in enumerate(doc_hits or []):
        if not isinstance(hit, dict):
            raise ValueError(f"doc_hits[{i}] 必须是对象（含 doc/rules）：{hit!r}")
        rules = hit.get("rules") or hit.get("hit_rules") or []
        if isinstance(rules, str):
            rules = [rules]
        out.append({"doc": _doc_label(hit, i),
                    "rules": [str(x) for x in rules if str(x).strip()]})
    return out


def plan(total_docs: int, mode: str = "full", ratio: float = 0.2,
         risk_rules=None, doc_hits=None) -> dict:
    """产出抽检计划：{selected, excluded, reason, ...}（纯计算，不读写数据库）。

    参数：
        total_docs: 待审文档总数（>=0 的整数）。
        mode: full / ratio / risk；未知模式直接抛 ValueError。
        ratio: 抽检比例，0~1；``ratio`` 模式向上取整，``risk`` 模式作为补齐目标。
        risk_rules: 高风险规则编码列表（risk 模式下用于排序优先级）。
        doc_hits: 可选，文档级命中信息 [{"doc": "D1", "rules": ["BID-021"]}]，
                  顺序即文档默认顺序；长度必须与 total_docs 一致。

    返回：
        {ok, mode, total, ratio, target_count, selected, selected_count,
         excluded, excluded_count, reason, risk_rule_codes, risk_hits,
         risk_selected_count, deterministic}
    """
    if isinstance(total_docs, bool) or not isinstance(total_docs, int):
        raise ValueError(f"total_docs 必须是整数：{total_docs!r}")
    if total_docs < 0:
        raise ValueError(f"total_docs 不能为负：{total_docs}")
    m = str(mode or "").strip().lower()
    if m not in VALID_MODES:
        raise ValueError(f"未知抽检模式：{mode!r}（只接受 {'/'.join(VALID_MODES)}）")
    r = _norm_ratio(ratio)
    risk_codes = [str(x).strip() for x in (risk_rules or []) if str(x).strip()]
    hits = _norm_hits(doc_hits)
    if hits and len(hits) != total_docs:
        raise ValueError(
            f"doc_hits 数量（{len(hits)}）与 total_docs（{total_docs}）不一致")
    order = [_doc_label(h, i) for i, h in enumerate(hits)] if hits \
        else list(range(total_docs))
    if not hits:
        hits = [{"doc": order[i], "rules": []} for i in range(total_docs)]

    base = {"ok": True, "mode": m, "total": total_docs, "ratio": r,
            "risk_rule_codes": risk_codes, "deterministic": True,
            "risk_hits": {}, "risk_selected_count": 0}

    if total_docs == 0:
        return {**base, "target_count": 0, "selected": [], "selected_count": 0,
                "excluded": [], "excluded_count": 0,
                "reason": "no_documents：没有可抽检的文档"}

    target = total_docs if m == "full" else int(math.ceil(total_docs * r))
    target = max(0, min(int(target), total_docs))

    if m == "full":
        return {**base, "target_count": target, "selected": list(order),
                "selected_count": len(order), "excluded": [], "excluded_count": 0,
                "reason": f"full：全部 {total_docs} 份文档进入审核（未抽检）"}

    risk_hits = {}
    for h in hits:
        matched = [c for c in h["rules"] if c in risk_codes]
        if matched:
            risk_hits[str(h["doc"])] = matched

    if m == "ratio":
        selected = list(order[:target])
        excluded = list(order[target:])
        reason = (f"ratio：按比例 {r:g} 向上取整抽检 {target}/{total_docs} 份"
                  f"（确定性按序，非随机抽样）")
        if target == 0:
            reason = f"ratio：比例 {r:g} 向上取整为 0，本次不抽检（0/{total_docs}）"
        return {**base, "target_count": target, "selected": selected,
                "selected_count": len(selected), "excluded": excluded,
                "excluded_count": len(excluded), "reason": reason,
                "risk_hits": risk_hits}

    # ---------- risk：命中高风险规则的文档优先 ----------
    risk_docs = [h["doc"] for h in hits if str(h["doc"]) in risk_hits]
    risk_docs.sort(key=lambda d: -len(risk_hits[str(d)]))
    selected = list(risk_docs[:target])
    risk_selected = len(selected)
    if len(selected) < target:
        for d in order:
            if d in selected:
                continue
            selected.append(d)
            if len(selected) >= target:
                break
    excluded = [d for d in order if d not in selected]
    if not risk_codes:
        reason = (f"risk：未提供高风险规则清单，按比例 {r:g} 兜底抽检 "
                  f"{target}/{total_docs} 份")
    elif not risk_hits:
        reason = (f"risk：未发现命中高风险规则的文档（{len(risk_codes)} 条高风险规则），"
                  f"按比例 {r:g} 兜底抽检 {target}/{total_docs} 份")
    else:
        reason = (f"risk：{len(risk_hits)} 份文档命中高风险规则，优先选中 "
                  f"{risk_selected} 份；本次抽检 {target}/{total_docs} 份"
                  f"（确定性按序，非随机抽样）")
    return {**base, "target_count": target, "selected": selected,
            "selected_count": len(selected), "excluded": excluded,
            "excluded_count": len(excluded), "reason": reason,
            "risk_hits": risk_hits, "risk_selected_count": risk_selected}
