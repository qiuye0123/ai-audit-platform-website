# -*- coding: utf-8 -*-
"""机制互斥/优先级/反例卡：同一证据只保留最高优先级机制，压重复过报。

- 只有显式带 mechanism_type/mechanism_priority 的点位参与仲裁；
- 不改变普通确定性规则；
- 被压制的结果转 insufficient + gate.reason，保留给人工复核，不静默丢弃。
"""
from __future__ import annotations
import difflib
import hashlib
import json
import re

# 机制大类优先级：越具体、越接近硬约束越高。
TYPE_PRIORITY = {
    "qualification": 92, "license": 92, "amount": 82, "tax": 80,
    "consistency": 70, "date": 66, "process": 58, "format": 34,
    "generic": 40,
}
# 单点优先级覆盖：同一证据命中多个点时，优先保留更具体的业务机制。
POINT_PRIORITY = {
    "A02-003": 96, "A02-004": 95, "A02-006": 94, "A04-002": 82,
    "C09-001": 68, "C09-002": 62, "C09-003": 58, "P01-O08": 56,
    "P01-O07": 32, "P01-O01": 30, "P01-O02": 31, "P01-O03": 29,
    "P01-O04": 28, "P01-O10": 27, "F02-004": 80, "F02-006": 45,
}
TYPE_HINTS = {
    "qualification": ("资质", "资格", "许可", "证书", "执业", "准入", "等级"),
    "amount": ("金额", "报价", "限价", "单价", "总价", "费用", "价款", "税率", "比例", "费率"),
    "date": ("日期", "时间", "期限", "工期", "有效期", "截止", "时点", "年度", "日历天"),
    "process": ("流程", "程序", "顺序", "评审", "开标", "投标", "审批", "签字", "签署", "获取"),
    "consistency": ("一致", "合计", "数量", "单位", "量纲", "对比", "核对", "相符", "错配"),
    "format": ("格式", "编号", "结构", "表格", "重复", "残缺", "可读", "解析", "标题"),
}


def infer_type(point: dict) -> str:
    explicit = str((point or {}).get("mechanism_type") or "").strip().lower()
    if explicit in TYPE_PRIORITY:
        return explicit
    text = " ".join(str((point or {}).get(k) or "") for k in
                    ("name", "point", "criterion", "route_terms", "mechanism_terms", "evidence_terms"))
    best, score = "generic", 0
    for typ, kws in TYPE_HINTS.items():
        n = sum(1 for k in kws if k in text)
        if n > score:
            best, score = typ, n
    return best


def priority(point: dict) -> int:
    try:
        v = int((point or {}).get("mechanism_priority"))
        if v:
            return v
    except Exception:
        pass
    pid = str((point or {}).get("id") or (point or {}).get("code") or "")
    return int(POINT_PRIORITY.get(pid, TYPE_PRIORITY.get(infer_type(point), 40)))


def _norm_quote(quote: str) -> str:
    q = re.sub(r"\s+", "", str(quote or ""))
    q = re.sub(r"[，,。；;：:、\"'“”‘’（）()\[\]【】]", "", q)
    return q


def _qkey(quote: str) -> str:
    q = re.sub(r"\s+", "", str(quote or ""))
    q = re.sub(r"[，,。；;：:、\"'“”‘’（）()\[\]【】]", "", q)
    return hashlib.sha256(q.encode("utf-8")).hexdigest() if q else ""


def arbitrate(results: list[dict], points: list[dict]) -> tuple[list[dict], dict]:
    """同一 quote 的多个 fail，只保留优先级最高的一个；其余转人工。"""
    pmap = {str(p.get("id") or p.get("code") or ""): p for p in (points or [])}
    base_groups = {}
    for r in results or []:
        if r.get("state") != "fail":
            continue
        pid = str(r.get("code") or r.get("id") or "")
        p = pmap.get(pid) or {}
        if not (p.get("mechanism_type") or p.get("mechanism_priority") or p.get("mechanism_gate")):
            continue
        qk = _qkey(r.get("quote") or r.get("evidence") or "")
        if not qk:
            continue
        base_groups.setdefault(qk, []).append((priority(p), pid, r, p))

    # 近似证据聚类：模型常把同一证据换一种说法，精确字符串相等不够。
    groups = []
    for rows0 in base_groups.values():
        placed = False
        for cluster in groups:
            rep = cluster[0]
            if infer_type(rep[3]) != infer_type(rows0[0][3]):
                continue
            a = _norm_quote(rep[2].get("quote") or "")
            b = _norm_quote(rows0[0][2].get("quote") or "")
            if not a or not b:
                continue
            ratio = 1.0 if (a in b or b in a) else difflib.SequenceMatcher(None, a, b).ratio()
            if ratio >= 0.86:
                cluster.extend(rows0); placed = True; break
        if not placed:
            groups.append(list(rows0))
    suppressed = []
    for rows in groups:
        if len(rows) < 2:
            continue
        rows.sort(key=lambda x: (-x[0], x[1]))
        top = rows[0]
        top_type = infer_type(top[3])
        top_group = str((top[3].get("exclusive_group") or ""))
        for pr, pid, r, p in rows[1:]:
            if pr >= top[0]:
                continue  # 同优先级不强行压制
            # 只有同一机制族/同一显式互斥组才压制；跨族同句可能同时成立。
            # 宽泛点跨族压制需要证据归属图，暂不做未经校准的强制压制。
            typ = infer_type(p)
            grp = str(p.get("exclusive_group") or "")
            if not ((typ == top_type) or (grp and grp == top_group)):
                continue
            # 高置信的下位点不自动压掉：避免为了降 extra 制造漏判，交给人工仲裁。
            try:
                _wc = float(top[2].get("confidence"))
                _lc = float(r.get("confidence"))
                if _lc > _wc + 0.05:
                    continue
            except Exception:
                pass
            r["state"] = "insufficient"
            r["gate"] = {"passed": False, "reason": "suppressed_by_priority",
                         "winner": top[1], "quote": (r.get("quote") or "")[:160]}
            r["rationale"] = (str(r.get("rationale") or "") +
                              f"（机制互斥：同一证据已由更高优先级 {top[1]} 处理，本点转人工复核）").strip()
            suppressed.append({"code": pid, "winner": top[1], "priority": pr,
                               "winner_priority": top[0], "quote": (r.get("quote") or "")[:120]})
    return results, {"groups": len(groups), "suppressed": len(suppressed),
                     "items": suppressed[:50]}


def negative_cards(limit: int = 500) -> list[dict]:
    """反馈卡：false_positive/manual 反例、need_evidence 补证、confirm 正例。"""
    out = {}
    try:
        from .. import db
        with db.session() as c:
            rows = c.execute(
                "SELECT id,kind,rule_code,title,payload,created_at FROM feedback "
                "WHERE kind IN ('false_positive','manual','need_evidence','confirm') "
                "ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        for r in rows:
            code = str(r["rule_code"] or "").strip()
            if not code:
                continue
            key = (code, str(r["kind"]))
            _kind = str(r["kind"])
            _action = ("keep" if _kind == "confirm" else
                       "require_evidence" if _kind == "need_evidence" else "suppress")
            g = out.setdefault(key, {"id": "fb-" + code + "-" + _kind, "rule_code": code,
                                     "kind": _kind, "action": _action, "count": 0,
                                     "last_at": "", "reason": "", "title": ""})
            g["count"] += 1
            g["last_at"] = max(g["last_at"], str(r["created_at"] or ""))
            g["title"] = str(r["title"] or g["title"] or "")
            if not g["reason"]:
                try:
                    payload = json.loads(r["payload"] or "{}")
                except Exception:
                    payload = {}
                g["reason"] = str(payload.get("reason") or payload.get("note") or g["title"] or "反馈误报")
    except Exception:
        return []
    return sorted(out.values(), key=lambda x: (-x["count"], x["rule_code"]))


def apply_negative_cards(results: list[dict], points: list[dict], cards: list[dict] | None = None) -> tuple[list[dict], dict]:
    """命中反例卡的 fail 转人工，不直接算成立。"""
    cards = negative_cards() if cards is None else cards
    by_code = {c.get("rule_code"): c for c in cards if c.get("rule_code")}
    pmap = {str(p.get("id") or p.get("code") or ""): p for p in (points or [])}
    hit = []
    for r in results or []:
        if r.get("state") != "fail":
            continue
        code = str(r.get("code") or r.get("id") or "")
        _p = pmap.get(code) or {}
        if not (_p.get("mechanism_gate") or _p.get("mechanism_type") or _p.get("mechanism_priority")):
            continue
        c = by_code.get(code)
        if not c:
            continue
        if c.get("action") == "keep":
            continue  # confirm 正例不压制
        if c.get("action") == "require_evidence":
            r["state"] = "insufficient"
            r["gate"] = {"passed": False, "reason": "need_evidence_card",
                         "card": c.get("id"), "count": c.get("count")}
            r["rationale"] = (str(r.get("rationale") or "") +
                              f"（补证机制卡：该规则历史要求补证 {c.get('count')} 次，转人工补证）").strip()
            hit.append({"code": code, "card": c.get("id"), "kind": "need_evidence", "count": c.get("count")})
            continue
        r["state"] = "insufficient"
        r["gate"] = {"passed": False, "reason": "negative_mechanism_card",
                     "card": c.get("id"), "count": c.get("count")}
        r["rationale"] = (str(r.get("rationale") or "") +
                          f"（反例机制卡：该规则历史误报 {c.get('count')} 次，转人工复核）").strip()
        hit.append({"code": code, "card": c.get("id"), "count": c.get("count")})
    return results, {"cards": len(cards), "hit": len(hit), "items": hit[:50]}
