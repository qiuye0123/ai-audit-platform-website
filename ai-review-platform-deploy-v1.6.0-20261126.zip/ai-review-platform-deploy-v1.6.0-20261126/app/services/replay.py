"""规则回放：用历史案例验证规则改动的影响面（市场标配，此前缺失）。

流程：取最近 N 个有文件的历史案例 → 用「当前生效参数」跑一遍 → 再用「待发布参数」跑一遍
     → 对比新增/消失的问题，给出影响面。不落库，纯只读模拟。
"""
import os
import logging

from .. import db
from .. import repositories as R

MAX_CASES = 20


def _run(path: str) -> list:
    from ..engine import engine
    from ..engine import factreview
    out = []
    try:
        out.extend(engine.build_report(path)["findings"])
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    try:
        for f in factreview.review_document(path)["findings"]:
            out.append({"rule_code": f["id"], "title": f["title"], "level": f["level"]})
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return out


def _keys(rows: list) -> set:
    return {(r.get("rule_code") or "", r.get("title") or "") for r in rows}


def replay(code: str, limit: int = MAX_CASES) -> dict:
    """对比某规则在「生效参数」与「待发布参数」下的结论差异。"""
    from . import ruleparam
    pend = ruleparam.pending(code)
    if not pend:
        return {"error": "该规则没有待发布的参数变更"}
    from . import project as _proj
    cases = []
    for c in R.cases.list(order="created_at DESC", limit=limit):
        docs = _proj.documents(c["id"])   # 通过 case_document 关联取文档
        if docs:
            cases.append((c, docs[0].get("path") or ""))
    affected, details = 0, []
    for c, path in cases:
        if not path or not os.path.exists(path):
            continue
        base = _run(path)
        with ruleparam.override(code, pend):
            after = _run(path)
        b, a = _keys(base), _keys(after)
        added = [k for k in a - b]
        removed = [k for k in b - a]
        if added or removed:
            affected += 1
            details.append({"case_id": c["id"], "name": c.get("name", ""),
                            "added": [f"{x[0]} {x[1]}" for x in added][:5],
                            "removed": [f"{x[0]} {x[1]}" for x in removed][:5]})
    return {"rule_code": code, "cases": len(cases), "affected": affected,
            "details": details, "pending": pend, "active": ruleparam.get(code)}
