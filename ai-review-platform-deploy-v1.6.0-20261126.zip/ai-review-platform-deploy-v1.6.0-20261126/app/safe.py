"""静默失败治理：统一异常出口。

原则：生产环境记 warning 日志（不吞），测试/开发环境（RULEPROOF_STRICT=1）直接抛出。
用法：
    from ..safe import guard
    with guard("读取规则参数", code=code, default=None) as ctx:
        ...  # 异常时 ctx.result 取默认值
"""
import logging
import os

LOG = logging.getLogger("ruleproof")
if not LOG.handlers:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

STRICT = os.environ.get("RULEPROOF_STRICT") == "1"


class guard:
    def __init__(self, what: str, default=None, **ctx):
        self.what, self.default, self.ctx, self.result = what, default, ctx, default

    def __enter__(self):
        self.result = self.default
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type is None:
            return False
        msg = f"[silent-guard] {self.what} 失败：{exc_type.__name__}: {exc}"
        if self.ctx:
            msg += f" | {self.ctx}"
        LOG.warning(msg)
        if STRICT:
            return False           # 严格模式：向上抛
        self.result = self.default  # 生产：降级并留痕
        return True


def last_error():
    """最近一次被 guard 吞掉的异常（供健康检查展示）。"""
    return _LAST.get("err")


_LAST = {}


def note(what, exc):
    _LAST["err"] = f"{what}: {type(exc).__name__}: {exc}"
