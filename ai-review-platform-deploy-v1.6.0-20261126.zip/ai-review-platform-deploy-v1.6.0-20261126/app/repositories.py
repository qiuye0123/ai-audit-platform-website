"""数据访问层（Repository）。每实体一个 repository，统一走 db.session。"""
import json
import logging
from typing import Any, Optional

from . import db


def _row(r) -> dict:
    return dict(r) if r is not None else None


_COLS_CACHE = {}


def _iso_cols(table: str):
    """该表是否有 tenant_id / workspace_id 隔离列（带缓存）。"""
    if table in _COLS_CACHE:
        return _COLS_CACHE[table]
    cols = set()
    try:
        c = db.connect()
        cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
        c.close()
    except Exception:
        cols = set()
    out = (("tenant_id" in cols), ("workspace_id" in cols))
    _COLS_CACHE[table] = out
    return out


def _state_machines():
    """延迟 import 状态机单一事实源（避免 repositories ↔ services 包循环导入）。"""
    from .services import state_machines as _sm
    return _sm


def _status_kind(table: str):
    """该表若为 7 张核心状态表之一，返回 (column, kind)；否则 None。"""
    try:
        return _state_machines().DB_STATUS_COLUMNS.get(str(table or ""))
    except Exception:  # noqa: BLE001 - 状态机不可用时由 DB 触发器兜底，不阻断读
        return None


def validate_status_value(table: str, column: str, value) -> str:
    """校验状态值域（规范态 ∪ 遗留别名）；非法值 raise ValueError。

    DB 触发器是第二道；本函数让通用 ``repositories.update`` 也能在写前 fail-fast，
    错误信息带 table/column/value，便于 L92 非法迁移测试给出可读证据。
    """
    sm = _state_machines()
    spec = sm.DB_STATUS_COLUMNS.get(str(table or ""))
    if not spec or spec[0] != str(column or ""):
        return str(value if value is not None else "")
    kind = spec[1]
    val = str(value if value is not None else "")
    if val == "":
        raise ValueError(f"invalid_state_value:{table}.{column}=空值（kind={kind}）")
    if val not in sm.allowed_values(kind):
        raise ValueError(
            f"invalid_state_value:{table}.{column}={val!r}"
            f"（允许：{','.join(sm.allowed_values(kind))}）")
    return val


# ---------------------------------------------------------------------------
# L93（2026-11-24）：finding 来源四要素写点（唯一 Repository 写入口）
#
# 主链 manifest_exec / 人工复核 / 语义重审等均经 ``R.findings.insert`` 落库；
# 这里统一补全 created_by/created_at/source/source_kind/rule_version_id：
#   * 显式传入的字段一律不覆盖（调用方更权威）；
#   * created_at/created_by 从所属 audit_run 派生（无 run 时回退 case.created_by）；
#   * source/source_kind 由 engine 显式映射（manifest/semantic/manual/seed/legacy）；
#   * rule_version_id 按「规则码→规则 + 版本」唯一解析，多义/缺失留空（不伪造）。
# 非 Repository 写路径（semantic_core/seed 的直 SQL）由 DB AFTER INSERT 触发器兜底；
# 历史数据回填见 ``app/data_migrations.py --docmodel-backfill``。
# ---------------------------------------------------------------------------
def _docmodel_finding_enrich(cols: dict) -> dict:
    out = dict(cols or {})
    if not out:
        return out
    engine = str(out.get("engine") or "")
    run = case = None
    rule_ref = str(out.get("rule_id") or "")
    version = str(out.get("rule_version") or "")
    resolved_rv = ""
    try:
        from . import docmodel as _dm  # 纯标准库模块，无循环依赖
        src, kind = _dm.engine_source(engine)
        c = db.connect()
        try:
            if str(out.get("run_id") or ""):
                run = _row(c.execute(
                    "SELECT created_by,created_at,manifest_id FROM audit_run WHERE id=?",
                    (str(out["run_id"]),)).fetchone())
            if str(out.get("case_id") or ""):
                case = _row(c.execute(
                    "SELECT created_by FROM audit_case WHERE id=?",
                    (str(out["case_id"]),)).fetchone())
            if rule_ref and not str(out.get("rule_version_id") or ""):
                rows = c.execute(
                    "SELECT rv.id, rv.version FROM rule_version rv "
                    "JOIN rule r ON r.id=rv.rule_id "
                    "WHERE r.id=? OR r.code=?", (rule_ref, rule_ref)).fetchall()
                if rows:
                    exact = [str(r[0]) for r in rows
                             if str(r[1] or "") == version]
                    if len(exact) == 1:
                        resolved_rv = exact[0]
                    elif len(rows) == 1:
                        resolved_rv = str(rows[0][0])
        finally:
            c.close()
        if not str(out.get("created_at") or ""):
            out["created_at"] = (run or {}).get("created_at") or db.now()
        if not str(out.get("created_by") or ""):
            out["created_by"] = ((run or {}).get("created_by")
                                 or (case or {}).get("created_by") or "system")
        if not str(out.get("source") or ""):
            out["source"] = src or "repository_insert"
        if not str(out.get("source_kind") or ""):
            out["source_kind"] = kind or "direct"
        if resolved_rv and not str(out.get("rule_version_id") or ""):
            out["rule_version_id"] = resolved_rv
    except Exception:  # noqa: BLE001 —— 补全失败不阻断 finding 主链写入（DB 触发器兜底）
        logging.getLogger(__name__).warning(
            "L93 finding 来源补全失败（DB 触发器兜底）", exc_info=True)
    # 兜底：无论查询是否成功，来源四要素不得为空（new 写入契约：来源齐全）
    if not str(out.get("created_at") or ""):
        out["created_at"] = db.now()
    if not str(out.get("created_by") or ""):
        out["created_by"] = "system"
    if not str(out.get("source") or ""):
        out["source"] = "repository_insert"
    if not str(out.get("source_kind") or ""):
        out["source_kind"] = "direct"
    return out


class BaseRepo:
    table = ""
    # 全局内置资产（目前只有 rule）在租户上下文下仍应可见；
    # 其余业务表严格按 tenant_id 隔离，NULL 不代表全局。
    include_global = False

    def __init__(self, conn=None):
        self.conn = conn

    def _c(self):
        return self.conn if self.conn is not None else db.connect()

    def _close(self, c):
        if self.conn is None:
            c.close()

    def insert(self, **cols) -> dict:
        try:
            from .services import ctx as _ctx
            cur = _ctx.get_context()
            has_t, has_w = _iso_cols(self.table)
            if has_t and "tenant_id" not in cols and cur["tenant_id"]:
                cols["tenant_id"] = cur["tenant_id"]
            if has_w and "workspace_id" not in cols and cur["workspace_id"]:
                cols["workspace_id"] = cur["workspace_id"]
        except Exception:
            pass
        # L92：INSERT 也要过状态值域（DB 触发器同步兜底）；空/缺省列按 DB 默认值。
        _kind_spec = _status_kind(self.table)
        if _kind_spec and _kind_spec[0] in cols and cols.get(_kind_spec[0]) not in (None, ""):
            validate_status_value(self.table, _kind_spec[0], cols.get(_kind_spec[0]))
        c = self._c()
        try:
            keys = list(cols.keys())
            ph = ",".join("?" * len(keys))
            sql = f"INSERT INTO {self.table} ({','.join(keys)}) VALUES ({ph})"
            c.execute(sql, [cols[k] for k in keys])
            c.commit()
        finally:
            self._close(c)
        return dict(cols)

    def _scope_sql(self, where: str = "1=1", params: tuple = ()) -> tuple:
        """在上下文存在时给单条读写追加租户/空间条件。"""
        try:
            from .services import ctx as _ctx
            cur = _ctx.get_context()
            has_t, has_w = _iso_cols(self.table)
            if has_t and cur["tenant_id"]:
                if self.include_global:
                    where += " AND (tenant_id=? OR tenant_id IS NULL)"
                else:
                    where += " AND tenant_id=?"
                params = tuple(params) + (cur["tenant_id"],)
        except Exception:
            pass
        return where, params

    def get(self, id: str) -> Optional[dict]:
        where, params = self._scope_sql("id=?", (id,))
        c = self._c()
        r = c.execute(f"SELECT * FROM {self.table} WHERE {where}", params).fetchone()
        self._close(c)
        return _row(r)

    def list(self, where: str = "1=1", params: tuple = (), order: str = "", limit: int = 0, offset: int = 0) -> list:
        # 隔离：上下文存在时强制追加 tenant/workspace 条件；严格模式下无作用域则拒绝
        try:
            from .services import ctx as _ctx
            cur = _ctx.get_context()
            has_t, has_w = _iso_cols(self.table)
            if has_t and cur["tenant_id"]:
                if self.include_global:
                    where += " AND (tenant_id=? OR tenant_id IS NULL)"
                else:
                    where += " AND tenant_id=?"
                params = tuple(params) + (cur["tenant_id"],)
            if has_w and cur["workspace_id"]:
                if self.include_global:
                    where += " AND (workspace_id=? OR workspace_id IS NULL)"
                else:
                    where += " AND workspace_id=?"
                params = tuple(params) + (cur["workspace_id"],)
            import os as _os
            if (_os.environ.get("RULEPROOF_STRICT_SCOPE", "0") == "1"
                    and (has_t or has_w) and not cur["tenant_id"] and not cur["workspace_id"]
                    and not _ctx.is_system()):
                return []
        except Exception:
            pass
        c = self._c()
        sql = f"SELECT * FROM {self.table} WHERE {where}" + (f" ORDER BY {order}" if order else "")
        if limit:
            sql += f" LIMIT {int(limit)} OFFSET {int(offset)}"
        rows = c.execute(sql, params).fetchall()
        self._close(c)
        return [_row(r) for r in rows]

    def update(self, id: str, **cols) -> None:
        """通用更新；status 列走状态机值域/迁移校验（L92）。

        - 7 张核心 status 表：值域 = 规范态 ∪ 遗留别名；非法值（如 corrupt_demo）
          直接 ValueError，不再依赖调用方自觉；
        - audit_case / finding / report 额外做「迁移方向」白名单校验（L92
          ``REPOSITORY_TRANSITION_GUARDED``）；同态幂等放行；
        - ``_expected_status`` 为可选 CAS 前置（不进入 SET 列）。
        """
        expected = cols.pop("_expected_status", None)
        _kind_spec = _status_kind(self.table)
        if _kind_spec and "status" in cols and _kind_spec[0] == "status":
            validate_status_value(self.table, "status", cols.get("status"))
            self._validate_status_transition(id, cols.get("status"))
        where, wparams = self._scope_sql("id=?", (id,))
        wparams = list(wparams)
        if expected is not None:
            where += " AND status=?"
            wparams.append(expected)
        c = self._c()
        sets = ",".join(f"{k}=?" for k in cols)
        c.execute(f"UPDATE {self.table} SET {sets} WHERE {where}", [*cols.values(), *wparams])
        c.commit()
        self._close(c)

    def _validate_status_transition(self, id: str, new_status) -> None:
        """迁移方向白名单校验（仅 REPOSITORY_TRANSITION_GUARDED 的表）。"""
        spec = _status_kind(self.table)
        if not spec:
            return
        column, kind = spec
        sm = _state_machines()
        if kind not in sm.REPOSITORY_TRANSITION_GUARDED:
            return
        current = self.get(id) or {}
        old = current.get(column)
        if old in (None, ""):
            return
        if sm.normalize(kind, old) == sm.normalize(kind, new_status):
            return
        if not sm.can_transition(kind, old, new_status):
            raise ValueError(
                f"invalid_transition:{self.table}.{column}:"
                f"{sm.normalize(kind, old)}->{sm.normalize(kind, new_status)}"
                f"（允许：{','.join(sm.targets_of(kind, sm.normalize(kind, old))) or '无'}）")

    def update_status(self, id: str, status: str, expected: str = "", action: str = "") -> int:
        """带状态机校验的 CAS 状态写入口（L92「白名单/CAS」统一写点）。

        返回 rowcount：1=迁移成功；0=前置状态不匹配（调用方转 409/幂等）。
        ``expected`` 为空时以当前行读到的状态作为 CAS 前置（读-校验-条件写，
        SQLite 单写锁保证并发下只有一个成功）。
        """
        spec = _status_kind(self.table)
        if not spec or spec[0] != "status":
            raise ValueError(f"update_status 不适用于表 {self.table}")
        column, kind = spec
        sm = _state_machines()
        validate_status_value(self.table, column, status)
        current = self.get(id) or {}
        old = current.get(column)
        if expected:
            old = expected
        if old not in (None, ""):
            new_canon = sm.normalize(kind, status)
            old_canon = sm.normalize(kind, old)
            if action:
                target = sm.action_target(kind, old_canon, action)
                if target is None:
                    raise ValueError(f"invalid_action:{kind}:{old_canon}:{action}")
                if new_canon != target:
                    raise ValueError(
                        f"invalid_transition:{kind}:{old_canon}--{action}-->{target}"
                        f"（请求 {new_canon}）")
            elif kind in sm.REPOSITORY_TRANSITION_GUARDED:
                sm.assert_transition(kind, old_canon, new_canon)
        where, wparams = self._scope_sql("id=?", (id,))
        c = self._c()
        try:
            sql = f"UPDATE {self.table} SET {column}=? WHERE {where}"
            params = [status, *wparams]
            if old is not None:
                sql += f" AND {column}=?"
                params.append(old)
            cur = c.execute(sql, params)
            c.commit()
            return int(cur.rowcount or 0)
        finally:
            self._close(c)

    def delete(self, id: str) -> None:
        where, params = self._scope_sql("id=?", (id,))
        c = self._c()
        c.execute(f"DELETE FROM {self.table} WHERE {where}", params)
        c.commit()
        self._close(c)

    def count(self, where: str = "1=1", params: tuple = ()) -> int:
        try:
            from .services import ctx as _ctx
            cur = _ctx.get_context()
            has_t, has_w = _iso_cols(self.table)
            if has_t and cur["tenant_id"]:
                if self.include_global:
                    where += " AND (tenant_id=? OR tenant_id IS NULL)"
                else:
                    where += " AND tenant_id=?"
                params = tuple(params) + (cur["tenant_id"],)
            if has_w and cur["workspace_id"]:
                if self.include_global:
                    where += " AND (workspace_id=? OR workspace_id IS NULL)"
                else:
                    where += " AND workspace_id=?"
                params = tuple(params) + (cur["workspace_id"],)
        except Exception:
            pass
        c = self._c()
        n = c.execute(f"SELECT count(*) FROM {self.table} WHERE {where}", params).fetchone()[0]
        self._close(c)
        return n


class OrgRepo(BaseRepo):
    table = "org"


class PlantRepo(BaseRepo):
    table = "plant"


class UserRepo(BaseRepo):
    table = "user"


class RuleRepo(BaseRepo):
    table = "rule"
    include_global = True

    def latest_version(self, rule_id) -> Optional[dict]:
        c = self._c()
        r = c.execute("SELECT * FROM rule_version WHERE rule_id=? ORDER BY rowid DESC LIMIT 1", (rule_id,)).fetchone()
        self._close(c)
        return _row(r)

    def latest_versions(self, rule_ids=None) -> dict:
        """批量取 rule_id → 最新版本行（单查询，语义逐字同 latest_version）。

        P2 慢节点最小修：规则库页联动/静态分析原逐规则 ``latest_version()``
        （每次新建连接 + 全表扫描 rule_version），规则数 × 1 次 SQL。这里一次
        ``ORDER BY rule_id, rowid DESC`` 取回，按 rule_id 保留首行 → 与
        ``latest_version`` 的 ``ORDER BY rowid DESC LIMIT 1`` 完全一致。
        """
        ids = []
        for x in (rule_ids or ()):
            s = str(x or "")
            if s:
                ids.append(s)
        c = self._c()
        try:
            if rule_ids is None:
                rows = c.execute("SELECT * FROM rule_version ORDER BY rule_id, rowid DESC").fetchall()
            else:
                if not ids:
                    return {}
                ph = ",".join("?" * len(ids))
                rows = c.execute(
                    f"SELECT * FROM rule_version WHERE rule_id IN ({ph}) "
                    "ORDER BY rule_id, rowid DESC", tuple(ids)).fetchall()
        finally:
            self._close(c)
        out = {}
        for r in rows:
            d = _row(r)
            out.setdefault(str(d.get("rule_id") or ""), d)
        return out

    def published_versions(self, rule_id) -> list:
        """该规则全部 published 版本（迁移后应 ≤1；供状态机/QA 断言唯一性）。"""
        c = self._c()
        rows = c.execute("SELECT * FROM rule_version WHERE rule_id=? AND status='published' "
                         "ORDER BY rowid DESC", (rule_id,)).fetchall()
        self._close(c)
        return [_row(r) for r in rows]

    def published_version(self, rule_id) -> Optional[dict]:
        """执行/冻结只允许已发布版本，禁止 rowid 最新 draft 混入。

        - 已下线规则不得再返回生效版本（archive 时版本已 superseded，这里再兜底）；
        - 优先 current_version_id（旧库无指针时回退最新 published 版本）。
        """
        try:
            row = self.get(rule_id) or {}
            if str(row.get("status") or "") == "archived":
                return None
            cid = str(row.get("current_version_id") or "")
            if cid:
                c = self._c()
                r = c.execute("SELECT * FROM rule_version WHERE id=? AND rule_id=? AND status='published'",
                              (cid, rule_id)).fetchone()
                self._close(c)
                if r:
                    return _row(r)
        except Exception:
            pass
        c = self._c()
        r = c.execute("SELECT * FROM rule_version WHERE rule_id=? AND status='published' "
                      "ORDER BY rowid DESC LIMIT 1", (rule_id,)).fetchone()
        self._close(c)
        return _row(r)

    def by_tag(self, tag: str, status: str = "", limit: int = 0) -> list:
        """按 ``rule.scope_json.tags`` 检索规则（只读取数，不写）。

        标签是规则库的检索/路由/审批分组条件：服务层 ``rule.search_by_tags`` 复用本查询；
        作用域仍走 ``self.list`` 的租户/空间隔离，不接受绕过隔离的裸 SQL。
        """
        token = str(tag or "").strip()
        if not token:
            return []
        where, params = ("status=?", (status,)) if status else ("1=1", ())
        out = []
        for row in self.list(where, params, order="created_at DESC"):
            try:
                scope = json.loads(row.get("scope_json") or "{}")
            except Exception:
                continue
            tags = [str(x).strip() for x in (scope.get("tags") or []) if str(x).strip()]
            if token in tags:
                out.append(row)
                if limit and len(out) >= limit:
                    break
        return out


class RuleVersionRepo(BaseRepo):
    table = "rule_version"


class DocumentRepo(BaseRepo):
    table = "document"


class AnchorRepo(BaseRepo):
    table = "anchor"


class AuditCaseRepo(BaseRepo):
    table = "audit_case"

    def add_document(self, case_id, document_id):
        c = self._c()
        c.execute("INSERT OR IGNORE INTO case_document(case_id,document_id) VALUES(?,?)", (case_id, document_id))
        c.commit()
        self._close(c)

    def documents(self, case_id) -> list:
        c = self._c()
        rows = c.execute("SELECT d.* FROM document d JOIN case_document cd ON d.id=cd.document_id WHERE cd.case_id=?", (case_id,)).fetchall()
        self._close(c)
        return [_row(r) for r in rows]


class FindingRepo(BaseRepo):
    table = "finding"

    def insert(self, **cols) -> dict:
        """L93：finding 写入统一补全来源四要素 + 权威版本关联（见上）。"""
        try:
            cols = _docmodel_finding_enrich(cols)
        except Exception:  # noqa: BLE001 —— 补全异常不允许阻断写；DB 触发器兜底
            logging.getLogger(__name__).warning(
                "L93 finding 来源补全异常（继续原始写入）", exc_info=True)
        return super().insert(**cols)

    def by_case(self, case_id) -> list:
        return self.list("case_id=?", (case_id,), order="severity DESC, id")


class EvidenceRepo(BaseRepo):
    table = "evidence"


class DecisionRepo(BaseRepo):
    table = "decision"


class ReportRepo(BaseRepo):
    table = "report"


class AgentRepo(BaseRepo):
    table = "agent"


class AgentVersionRepo(BaseRepo):
    table = "agent_version"


class AgentRunRepo(BaseRepo):
    table = "agent_run"


class AgentNodeRunRepo(BaseRepo):
    table = "agent_node_run"


class AuditLogRepo(BaseRepo):
    table = "audit_log"

    def log(self, actor, action, object="", before="", after="", request_id="", ip=""):
        return self.insert(id=db.new_id("log"), actor=actor, action=action, object=object,
                           before_json=before, after_json=after, request_id=request_id,
                           ip=ip, created_at=db.now())


class ConflictRepo(BaseRepo):
    table = "conflict"


class RuleSnapshotRepo(BaseRepo):
    table = "rule_snapshot"


class OntoEntityRepo(BaseRepo):
    table = "onto_entity"
    # T-197（P1-2）：本体图 = 平台共享资产（tenant_id IS NULL）+ 本租户扩展层。
    include_global = True


class OntoAliasRepo(BaseRepo):
    table = "onto_alias"
    include_global = True


class OntoLinkRepo(BaseRepo):
    table = "onto_link"
    include_global = True


class NotificationRepo(BaseRepo):
    table = "notification"


class OntoVersionRepo(BaseRepo):
    table = "onto_version"
    # T-197（P1-2）：发布版本按租户隔离；旧库无 tenant_id 的历史版本视为全局（NULL）。
    include_global = True


class CalibrationRepo(BaseRepo):
    table = "calibration"


class OpenAppRepo(BaseRepo):
    table = "open_app"


class OpenTaskRepo(BaseRepo):
    table = "open_task"


class OpenEventRepo(BaseRepo):
    table = "open_event"


class OpenSandboxRepo(BaseRepo):
    table = "open_sandbox"


class EvalSetRepo(BaseRepo):
    table = "eval_set"


class EvalRunRepo(BaseRepo):
    table = "eval_run"


# 便捷实例（无状态，可直接调用）
orgs = OrgRepo()
plants = PlantRepo()
users = UserRepo()
rules = RuleRepo()
rule_versions = RuleVersionRepo()
documents = DocumentRepo()
anchors = AnchorRepo()
cases = AuditCaseRepo()
findings = FindingRepo()
evidences = EvidenceRepo()
decisions = DecisionRepo()
reports = ReportRepo()
agents = AgentRepo()
agent_versions = AgentVersionRepo()
agent_runs = AgentRunRepo()
agent_node_runs = AgentNodeRunRepo()
audit_logs = AuditLogRepo()
conflicts = ConflictRepo()
rule_snapshots = RuleSnapshotRepo()
onto_entities = OntoEntityRepo()
onto_aliases = OntoAliasRepo()
onto_links = OntoLinkRepo()
notifications = NotificationRepo()
onto_versions = OntoVersionRepo()
calibration = CalibrationRepo()
open_apps = OpenAppRepo()
open_tasks = OpenTaskRepo()
open_events = OpenEventRepo()
open_sandbox = OpenSandboxRepo()
eval_sets = EvalSetRepo()
eval_runs = EvalRunRepo()


class AuditRunRepo(BaseRepo):
    table = "audit_run"


audit_runs = AuditRunRepo()


class ModelConfigRepo(BaseRepo):
    table = "model_config"


model_configs = ModelConfigRepo()


class DecisionTableRepo(BaseRepo):
    table = "decision_table"


class DecisionTableVersionRepo(BaseRepo):
    table = "decision_table_version"


decision_tables = DecisionTableRepo()
decision_table_versions = DecisionTableVersionRepo()


class LlmCacheRepo(BaseRepo):
    table = "llm_cache"


llm_cache = LlmCacheRepo()


class RsiCandidateRepo(BaseRepo):
    table = "rsi_candidate"


rsi_candidates = RsiCandidateRepo()


class PointStateRepo(BaseRepo):
    table = "point_state"


point_states = PointStateRepo()


class QaSampleRepo(BaseRepo):
    table = "qa_sample"


qa_samples = QaSampleRepo()


class RuleParamRepo(BaseRepo):
    table = "rule_param"


rule_params = RuleParamRepo()


class FeedbackRepo(BaseRepo):
    table = "feedback"


feedback = FeedbackRepo()


class EvolutionTaskRepo(BaseRepo):
    table = "evolution_task"


evolution_tasks = EvolutionTaskRepo()


class DocTypeCustomRepo(BaseRepo):
    table = "doc_type_custom"


doc_type_custom = DocTypeCustomRepo()
