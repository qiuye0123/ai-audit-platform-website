"""发现/证据/复核写路由：从 server.py 抽出，权限与响应保持。"""
from __future__ import annotations
import base64
from .. import db
from .. import repositories as R
from ..services import review


def _identity(u: dict) -> tuple:
    """P0-1：裁决审计身份只取服务端会话，绝不读请求体里的 user/actor。"""
    u = u or {}
    account = str(u.get("sub") or u.get("account") or "").strip()
    display = str(u.get("name") or u.get("username") or account or "审核员").strip()
    return account, display


def _decision_http_status(result: dict) -> int:
    """把服务层裁决结果映射成 HTTP 状态码（冲突 409 / 越权 403 / 参数 400）。"""
    result = result or {}
    code = str(result.get("code") or "")
    if code == "decision_conflict":
        return 409
    if code in ("forbidden", "evaluation_locked"):
        return int(result.get("status") or 403)
    if code == "not_found":
        return 404
    if result.get("error"):
        return int(result.get("status") or 400)
    return 200


def post(path: str, body: dict, user: dict, owned, active_role: str):
    u = user or {}
    if path == "/api/v1/findings/batch-decision":
        # P2-2 批量裁决：服务端逐条复用单条裁决服务函数（逐条审计 + 批量汇总审计）。
        account, display = _identity(u)
        r = review.batch_decide((body or {}).get("finding_ids") or [],
                                (body or {}).get("decision", ""),
                                (body or {}).get("reason", ""),
                                (body or {}).get("note", ""),
                                user=display, user_id=account, actor=account,
                                display_name=display,
                                expected_status=(body or {}).get("expected_status", "pending"))
        st = _decision_http_status(r) if not r.get("ok") else 200
        return st, r
    if path == "/api/v1/findings/batch-undo":
        account, display = _identity(u)
        r = review.batch_undo(str((body or {}).get("batch_id") or ""),
                              user=display, user_id=account, actor=account,
                              display_name=display)
        st = 200
        if not r.get("ok"):
            st = int(r.get("status") or 400)
        return st, r
    if path.startswith("/api/v1/findings/") and path.endswith("/sediment"):
        fid = path.split("/")[-2]
        from ..services import permissions as _pm
        ok = _pm.has(u.get("sub", ""), "rule.manage")
        if not ok:
            try:
                from ..services import permission as _pm2
                ok = _pm2.can(u.get("role") or "", "rule.create")
            except Exception:
                ok = False
        if not ok:
            return 403, {"error": "无权限沉淀规则", "code": "forbidden"}
        f = R.findings.get(fid)
        if not f:
            return 404, {"error": "发现不存在", "code": "not_found"}
        case = R.cases.get(f.get("case_id") or "") or {}
        from ..services import rule as _rs
        code = "SED-" + (db.new_id("r").split("_")[-1][:8]).upper()
        slots = {"criterion": str((body or {}).get("criterion") or f.get("summary") or f.get("title") or "")[:600],
                 "source_finding": fid}
        try:
            o = _rs.create_rule(code=code, name=str((body or {}).get("name") or f.get("title") or "沉淀规则")[:40],
                                category=case.get("audit_category") or "客户沉淀",
                                rclass="R3", slots=slots, source="AI辅助-沉淀")
        except Exception as e:
            return 400, {"error": str(e), "code": "create_failed"}
        return 200, {"ok": True, "rule_id": o["rule_id"], "code": code, "status": "draft"}
    if path.startswith("/api/v1/findings/") and path.endswith("/update"):
        fid = path.split("/")[-2]
        f0 = R.findings.get(fid)
        if not f0 or not owned(f0.get("case_id", "")):
            return 403, {"error": "无权操作他人结论", "code": "forbidden"}
        return 200, review.update_finding(fid, (body or {}).get("title", ""),
                                          (body or {}).get("severity", ""),
                                          (body or {}).get("detail", ""), u.get("sub", ""))
    if path.startswith("/api/v1/findings/") and path.endswith("/delete"):
        # P1-5：删除默认=抑制（可审计/可复算），仅 manual 且无裁决记录才物理删。
        # 响应显式给 mode=suppressed|physical，前端按钮文案可据此区分「删除」/「抑制」。
        fid = path.split("/")[-2]
        f0 = R.findings.get(fid)
        if not f0 or not owned(f0.get("case_id", "")):
            return 403, {"error": "无权操作他人结论", "code": "forbidden"}
        r = review.delete_finding(fid, u.get("sub", ""),
                                  reason=str((body or {}).get("reason") or ""))
        r = dict(r or {})
        r.setdefault("mode", "suppressed" if not r.get("deleted") else "physical")
        return 200, r
    if path.startswith("/api/v1/findings/") and path.endswith("/reject"):
        fid = path.split("/")[-2]
        if active_role not in ("admin", "super_admin"):
            return 403, {"error": "仅管理员可退回复核", "code": "forbidden"}
        return 200, review.reject_decision(fid, u.get("name", "管理员"), u.get("sub", ""),
                                           (body or {}).get("reason", ""))
    if path.startswith("/api/v1/findings/") and path.endswith("/evidence"):
        fid = path.split("/")[-2]
        f0 = R.findings.get(fid)
        if not f0 or not owned(f0.get("case_id", "")):
            return 403, {"error": "无权操作他人结论", "code": "forbidden"}
        content = None
        if (body or {}).get("data"):
            try:
                content = base64.b64decode(body.get("data", ""), validate=True)
            except Exception:
                return 400, {"error": "文件内容不是合法 base64", "code": "invalid_base64"}
        return 200, review.add_evidence(fid, (body or {}).get("text", ""),
                                        (body or {}).get("filename", ""), content,
                                        u.get("name", ""), u.get("sub", ""))
    if path.startswith("/api/v1/findings/") and path.endswith("/decision"):
        fid = path.split("/")[-2]
        f = R.findings.get(fid)
        if not f:
            return 404, {"error": "finding not found", "code": "not_found"}
        if not owned(f.get("case_id")):
            return 403, {"error": "无权复核他人案例", "code": "forbidden"}
        # P0-1：审计 actor 只取会话身份；body.user / body.actor 一律忽略，
        # 显示名只作为 after_json.display_name 留痕。
        account, display = _identity(u)
        r = review.decide(fid, (body or {}).get("decision", ""),
                          (body or {}).get("reason", ""), (body or {}).get("note", ""),
                          user=display, user_id=account, actor=account,
                          display_name=display,
                          expected_status=(body or {}).get("expected_status", ""))
        return _decision_http_status(r), r
    return None
