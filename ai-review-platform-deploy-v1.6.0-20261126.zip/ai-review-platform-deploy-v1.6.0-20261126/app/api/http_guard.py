# -*- coding: utf-8 -*-
"""HTTP 层并发/幂等/限制辅助（P2 修复；server.py 只做薄调用，保持拆分契约）。

本模块承接从 ``app/api/server.py`` 下沉的横切逻辑，避免 server.py 行数膨胀：

- **P2-08 Idempotency-Key 落库**：key 主键 + scope 指纹 + TTL；重启/多进程仍有效，
  过期行按 TTL 清理、总量有上限（不再是无界进程内 dict）。
- **P2-15 HEAD**：/health 与静态资源返回 200 + Content-Length + 空 body；
  其余路径维持 405。
- **P2-16 请求体分级上限**：普通 JSON 接口小上限（默认 16MB），仅真实文件上传
  路径（项目文档/知识库/OCR/文档解析/对比）保留大上限（默认 140MB）；
  另加“写入并发槽位”和“大上传并发槽位”，防止 ThreadingHTTPServer 线程/内存耗尽。
- **P2-05 架构图访问控制**：查看器/资源仅平台管理员（super_admin/platform_op）；
  `_qa` 内部产物禁止 HTTP 读取；架构 HTML 响应加 nosniff。
"""
from __future__ import annotations

import base64
import json
import logging
import os
import threading
import time
from pathlib import Path

from .. import db

LOG = logging.getLogger(__name__)
WEB = str(Path(__file__).resolve().parents[2] / "web")

# ---------------------------------------------------------------------------
# P2-08：Idempotency-Key 落库
# ---------------------------------------------------------------------------
IDEM_TTL = 3600            # 与旧进程内缓存口径一致：1 小时
IDEM_MAX_ROWS = 20000      # 容量上限：超过后按 expires_at 最早批量清理
IDEM_PURGE_BATCH = 500


def idem_scope(user: dict, path: str, body) -> str:
    """幂等作用域：租户+账号+方法/路径+请求体摘要，不能只按调用方 key 命中。"""
    import hashlib
    u = user or {}
    tenant = str(u.get("tenant_id") or "t-default")
    sub = str(u.get("sub") or "")
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True, default=str)
    return f"{tenant}|{sub}|{path}|{hashlib.sha256(raw.encode()).hexdigest()[:24]}"


def idem_get(key):
    """返回 (expires_at, status, body_bytes, scope) 或 None；DB 异常 → miss 并记 error。"""
    if not key:
        return None
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT scope, status, body_b64, expires_at FROM http_idempotency WHERE key=?",
                (str(key),)).fetchone()
            if not row:
                return None
            if float(row["expires_at"] or 0) <= time.time():
                c.execute("DELETE FROM http_idempotency WHERE key=?", (str(key),))
                return None
            try:
                body = base64.b64decode(row["body_b64"] or "")
            except Exception:
                body = b""
            return (float(row["expires_at"]), int(row["status"] or 200), body,
                    str(row["scope"] or ""))
    except Exception:  # noqa: BLE001 - 幂等缓存不可用不阻断业务，但必须留 error 日志
        LOG.error("idempotency lookup failed key=%s", str(key)[:80], exc_info=True)
        return None


def idem_put(key, code, body, scope: str = "") -> None:
    """写入幂等响应（落库）。DB 异常只记 error：幂等缓存是优化，不应让已成功的
    业务写返回 5xx 诱发客户端重试；但绝不回退到进程内缓存（多进程承诺不成立）。"""
    if not key:
        return
    try:
        b64 = base64.b64encode(body if isinstance(body, (bytes, bytearray)) else b"").decode()
        now = time.time()
        with db.session() as c:
            c.execute("DELETE FROM http_idempotency WHERE expires_at<=?", (now,))
            n = c.execute("SELECT count(*) FROM http_idempotency").fetchone()[0]
            if int(n) >= IDEM_MAX_ROWS:
                c.execute("DELETE FROM http_idempotency WHERE key IN (SELECT key FROM "
                          "http_idempotency ORDER BY expires_at ASC LIMIT ?)",
                          (IDEM_PURGE_BATCH,))
            c.execute("INSERT OR REPLACE INTO http_idempotency(key,scope,status,body_b64,"
                      "created_at,expires_at) VALUES(?,?,?,?,?,?)",
                      (str(key), str(scope or ""), int(code), b64, db.now(),
                       now + IDEM_TTL))
    except Exception:  # noqa: BLE001
        LOG.error("idempotency store failed key=%s", str(key)[:80], exc_info=True)


# ---------------------------------------------------------------------------
# P2-15：HEAD
# ---------------------------------------------------------------------------
_STATIC_TYPES = {
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml", ".ico": "image/x-icon",
    ".json": "application/json; charset=utf-8",
}


def head_ok(handler) -> None:
    """处理 HEAD（仅无害只读资源）：/health 与 web/ 内公开静态文件。

    不把 HEAD 映射成 do_GET：GET 路由里仍有历史副作用分支，HEAD 不能触发写。
    """
    from .. import config
    path = str(handler.path or "").split("?", 1)[0]
    if path in ("/health", "/healthz"):
        body = handler._json({"ok": True, "app": config.APP_NAME,
                              "version": config.APP_VERSION})
        _send_headers(handler, 200, len(body), "application/json; charset=utf-8")
        return
    name = path.lstrip("/")
    ext = os.path.splitext(name)[1].lower()
    if (name and ".." not in name.split("/") and not name.startswith(".")
            and ext in _STATIC_TYPES and "/" not in name.strip("/")):
        full = os.path.join(WEB, name)
        if os.path.isfile(full):
            try:
                size = os.path.getsize(full)
            except OSError:
                size = 0
            _send_headers(handler, 200, size, _STATIC_TYPES[ext])
            return
    body = handler._json({"error": "方法不支持", "code": "method_not_allowed"})
    _send_headers(handler, 405, len(body), "application/json; charset=utf-8",
                  extra={"Allow": "GET, HEAD, POST, PUT, DELETE"})


def cors_echo_origin(origin: str) -> str:
    """F-03（build56 外部独立审查 P1）：CORS 白名单回显（RULEPROOF_CORS_ORIGINS）。

    返回应回显的 Origin；**未配置 / 无 Origin / Origin=null / 不在白名单 / 配置了 * 
    一律返回空**（调用方据此不输出 CORS 头，同源默认生效，永不输出通配符）。
    """
    origin = str(origin or "").strip().rstrip("/")
    if not origin or origin == "null":
        return ""
    raw = str(os.environ.get("RULEPROOF_CORS_ORIGINS") or "")
    allowed = {x.strip().rstrip("/") for x in raw.split(",") if x.strip()}
    allowed.discard("*")
    return origin if origin in allowed else ""


def send_cors_header(handler) -> None:
    """F-03：输出白名单 CORS 头；无 Origin / 非白名单不输出（永不 ``*``）。

    四处发送路径（_send / _session_error_response / _send_session / do_GET 知识库原始
    字节分支）与 HEAD/静态响应（_send_headers）统一调用本函数，口径单源。
    """
    try:
        origin = cors_echo_origin(handler.headers.get("Origin"))
    except Exception:  # noqa: BLE001 - 取 header 失败按无 Origin 处理（不放宽）
        return
    if not origin:
        return
    handler.send_header("Access-Control-Allow-Origin", origin)
    handler.send_header("Access-Control-Allow-Credentials", "true")
    handler.send_header("Vary", "Origin")


def _send_headers(handler, code: int, length: int, ctype: str, extra=None) -> None:
    handler.send_response(code)
    handler.send_header("Content-Type", ctype)
    send_cors_header(handler)
    handler.send_header("X-Request-Id", getattr(handler, "_rid", "-"))
    for k, v in (extra or {}).items():
        handler.send_header(str(k), str(v))
    handler.send_header("Content-Length", str(int(length)))
    handler.end_headers()


# ---------------------------------------------------------------------------
# P2-16：请求体分级上限 + 并发槽位
# ---------------------------------------------------------------------------
MAX_JSON_BODY_BYTES_DEFAULT = 16 * 1024 * 1024        # 普通 JSON 接口
MAX_UPLOAD_BODY_BYTES_DEFAULT = 140 * 1024 * 1024     # 单文件 100MB base64 后约 134MB
_UPLOAD_PATHS = ("/api/v1/ocr", "/api/v1/review-doc", "/api/v1/doc/parse",
                 "/api/v1/reviews",
                 # 历史/兼容文件上传口（base64 落盘）：
                 "/api/v1/upload", "/api/v1/audit-points/batch")


def _env_int(name: str, default: int) -> int:
    try:
        return max(1024, int(os.environ.get(name, str(default))))
    except Exception:
        return default


def _env_count(name: str, default: int) -> int:
    """并发槽位数量（1..4096）：必须与字节上限分开，不能套 1024 下限。"""
    try:
        return max(1, min(4096, int(os.environ.get(name, str(default)))))
    except Exception:
        return default


def max_json_body_bytes() -> int:
    # 兼容 F12 旧覆盖点：显式设置 RULEPROOF_MAX_BODY_BYTES 时，普通接口上限也
    # 跟随该值（旧行为是全局上限）；否则用新的 JSON 专用上限。
    import os as _os
    legacy = _os.environ.get("RULEPROOF_MAX_BODY_BYTES")
    default = _env_int("RULEPROOF_MAX_BODY_BYTES", MAX_JSON_BODY_BYTES_DEFAULT)         if legacy else MAX_JSON_BODY_BYTES_DEFAULT
    return _env_int("RULEPROOF_MAX_JSON_BODY_BYTES", default)


def max_upload_body_bytes() -> int:
    # 兼容既有环境变量名 RULEPROOF_MAX_BODY_BYTES（F12 已公开的覆盖点）。
    return _env_int("RULEPROOF_MAX_BODY_BYTES", MAX_UPLOAD_BODY_BYTES_DEFAULT)


def post_body_cap(path: str):
    """POST/PUT 请求体上限（字节）；返回 (cap, kind)。None=该路径有自己的上限。"""
    p = str(path or "").split("?", 1)[0]
    if p.startswith("/api/v1/open/sandbox"):
        return None, "own"       # 开放平台沙箱：公开路径，自有 256KB 上限
    if p.startswith("/api/v1/knowledge/"):
        try:
            from ..services import knowledge as _kb
            return _kb.max_bytes() + 1024 * 1024, "knowledge"
        except Exception:
            return max_json_body_bytes(), "json"
    if p.startswith("/api/v1/projects/") and p.endswith("/documents"):
        return max_upload_body_bytes(), "upload"
    if p.startswith("/api/v1/findings/") and p.endswith("/evidence"):
        return max_upload_body_bytes(), "upload"
    if p in _UPLOAD_PATHS:
        return max_upload_body_bytes(), "upload"
    return max_json_body_bytes(), "json"


_WRITE_SLOTS = threading.BoundedSemaphore(_env_count("RULEPROOF_MAX_CONCURRENT_WRITES", 256))
_UPLOAD_SLOTS = threading.BoundedSemaphore(_env_count("RULEPROOF_MAX_CONCURRENT_UPLOADS", 4))


def acquire_slot(handler, kind: str) -> bool:
    """获取并发槽位；失败返回 False（调用方回 503/429）。kind: write|upload。"""
    sem = _UPLOAD_SLOTS if kind == "upload" else _WRITE_SLOTS
    if not sem.acquire(blocking=False):
        return False
    held = getattr(handler, "_hg_slots", None)
    if held is None:
        held = []
        handler._hg_slots = held
    held.append(sem)
    return True


def release_slots(handler) -> None:
    """释放本请求持有的全部槽位（server.Handler.handle_one_request finally 调用）。"""
    for sem in getattr(handler, "_hg_slots", None) or []:
        try:
            sem.release()
        except ValueError:
            pass
    try:
        handler._hg_slots = []
    except Exception:
        pass


# ---------------------------------------------------------------------------
# P2-05：架构图访问控制
# ---------------------------------------------------------------------------
ARCH_ROLES = ("super_admin", "platform_op")


def arch_denied(role: str, path: str) -> bool:
    """架构图查看器/资源/内部 QA 产物：仅平台管理员；_qa 一律 404。"""
    p = str(path or "")
    if "/_qa/" in p or p.startswith("/architecture/_qa"):
        return True
    return str(role or "") not in ARCH_ROLES


def arch_headers(ext: str) -> dict:
    """架构图 HTML/资源响应头：禁嗅探 + 禁缓存（P2-05/P2-06 纵深）。"""
    out = {"X-Content-Type-Options": "nosniff", "Cache-Control": "no-store, must-revalidate"}
    if ext == ".html":
        out["Content-Security-Policy"] = ("default-src 'none'; style-src 'unsafe-inline'; "
                                          "img-src data:; font-src data:")
    return out
