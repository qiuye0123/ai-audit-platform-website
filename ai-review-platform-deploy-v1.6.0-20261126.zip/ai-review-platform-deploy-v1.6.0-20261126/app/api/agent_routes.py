"""智能体 API 路由：列表/详情/运行/更新/发布。

把智能体域从 server.py 的 GET/POST 分发中抽出，同时消除 GET 中的写操作分支。
"""
from __future__ import annotations
import json

from .. import db
from .. import repositories as R
from ..services import agents, permissions
from .. import config as _cfg


def _admin(user: dict) -> bool:
    return (user or {}).get("role") in ("admin", "super_admin")


_ALLOWED_STATUS = ("active", "draft", "disabled")
_ALLOWED_TYPES = ("parse", "extract", "rulegen", "conflict", "judge", "report", "ocr", "rulemine")
# P2-B6-08：每个模型节点提示词上限。超长提示词会抬高 token 成本并可能被模型截断。
PROMPT_MAX_CHARS = 8000


def _validate_prompts(prompts_list) -> str:
    """提示词结构 + 长度校验；返回错误文案（空串=通过）。"""
    if not isinstance(prompts_list, list):
        return "prompts_list 必须是数组"
    for i, item in enumerate(prompts_list):
        if not isinstance(item, dict):
            return f"prompts_list[{i}] 必须是对象"
        text = str(item.get("prompt") or "")
        if len(text) > PROMPT_MAX_CHARS:
            return (f"节点「{item.get('node') or i}」提示词 {len(text)} 字符，"
                    f"超过上限 {PROMPT_MAX_CHARS} 字符")
    return ""


def get(path: str, user: dict):
    if path == "/api/v1/agents":
        if not _admin(user):
            return 403, {"error": "仅管理员可查看智能体", "code": "forbidden"}
        return 200, agents.list_agents()
    if path == "/api/v1/agents/runs":
        if not _admin(user):
            return 403, {"error": "仅管理员可查看智能体运行", "code": "forbidden"}
        return 200, agents.list_runs()
    if path.startswith("/api/v1/agents/"):
        # B6-C1：详情与列表同口径（菜单/列表 403 不能靠直连 URL 绕开）
        if not _admin(user):
            return 403, {"error": "仅管理员可查看智能体详情", "code": "forbidden"}
        aid = path.split("/")[-1]
        d = agents.agent_detail(aid)
        if not d:
            return 404, {"error": "智能体不存在", "code": "not_found"}
        return 200, d
    return None


def post(path: str, user: dict, body: dict, blocked: bool = False):
    if not path.startswith("/api/v1/agents/"):
        return None
    if blocked:
        return 403, {"error": "该工作空间已关闭智能体模块", "code": "module_off"}
    action = path.rsplit("/", 1)[-1]
    aid = path.split("/")[-2] if path.count("/") >= 4 else ""
    if action == "run":
        if not permissions.has((user or {}).get("sub", ""), "agent.manage"):
            return 403, {"error": "无权限运行智能体（需 agent.manage）", "code": "forbidden"}
        return 200, agents.run_agent(aid, body or {},
                                     actor=(user or {}).get("sub", ""))
    if action == "update":
        if not permissions.has((user or {}).get("sub", ""), "agent.manage"):
            return 403, {"error": "无权限修改智能体（需 agent.manage）", "code": "forbidden"}
        a = R.agents.get(aid)
        if not a:
            return 404, {"error": "智能体不存在", "code": "not_found"}
        try:
            # P2-B6-06：非法枚举不再静默忽略（200 但未生效 = 骗调用方）
            if "status" in body and body.get("status") not in _ALLOWED_STATUS:
                return 400, {"error": f"非法 status：{body.get('status')!r}；允许值 "
                                      f"{list(_ALLOWED_STATUS)}", "code": "invalid_status",
                             "allowed": list(_ALLOWED_STATUS)}
            if "type" in body and body.get("type") not in _ALLOWED_TYPES:
                return 400, {"error": f"非法 type：{body.get('type')!r}；允许值 "
                                      f"{list(_ALLOWED_TYPES)}", "code": "invalid_type",
                             "allowed": list(_ALLOWED_TYPES)}
            # P2-B6-08：提示词长度上限（超长提示词拒绝，不原样入库）
            if body.get("prompts_list") is not None:
                _perr = _validate_prompts(body.get("prompts_list"))
                if _perr:
                    return 400, {"error": _perr, "code": "invalid_prompt_length",
                                 "limit": PROMPT_MAX_CHARS}
            prof = json.loads(a.get("profile_json") or "{}")
            for k in ("prompts_list", "params_list", "desc", "responsibility", "not_responsibility",
                      "workflow", "group", "tags"):
                if body.get(k) is not None:
                    prof[k] = body[k]
            if body.get("status") in _ALLOWED_STATUS:
                R.agents.update(aid, status=body["status"])
            if body.get("type") in _ALLOWED_TYPES:
                R.agents.update(aid, type=body["type"])
            if isinstance(prof.get("prompts_list"), list):
                prof["prompts"] = len(prof["prompts_list"])
            if isinstance(prof.get("params_list"), list):
                prof["params"] = len(prof["params_list"])
            if isinstance(prof.get("workflow"), list):
                prof["nodes"] = len(prof["workflow"])
            R.agents.update(aid, profile_json=json.dumps(prof, ensure_ascii=False))
            R.audit_logs.log(actor=(user or {}).get("sub", ""), action="agent.updated", object=aid)
            return 200, {"ok": True}
        except Exception as e:
            return 400, {"error": str(e), "code": "invalid_update"}
    if action == "publish":
        if not permissions.has((user or {}).get("sub", ""), "agent.manage"):
            return 403, {"error": "无权限发布智能体（需 agent.manage）", "code": "forbidden"}
        a = R.agents.get(aid)
        if not a:
            return 404, {"error": "智能体不存在", "code": "not_found"}
        try:
            prof = json.loads(a.get("profile_json") or "{}")
            # L108：发布走服务层事务（旧 published → superseded + 新 published，
            # 每 agent 至多一个生效版本；幂等/并发在 agents.publish_version 内保证）。
            _res = agents.publish_version(
                aid, profile=prof, actor=str((user or {}).get("sub") or ""),
                force=bool((body or {}).get("force")),
                model=str(_cfg.LLM.get("model", "") or ""), source="http")
            if not _res.get("ok"):
                if _res.get("code") == "no_change":
                    return 400, {"error": "提示词/工作流/参数与最新发布版本无变更，无需重复发布；"
                                          "确需重发请传 force=true",
                                 "code": "no_change",
                                 "current_version": _res.get("current_version") or "",
                                 "version_id": _res.get("version_id") or ""}
                return int(_res.get("status") or 400), {
                    "error": "智能体不存在" if _res.get("code") == "not_found" else "发布失败",
                    "code": str(_res.get("code") or "invalid_publish")}
            return 200, {"ok": True, "version": _res.get("version") or "",
                         "version_id": _res.get("version_id") or "",
                         "superseded": int(_res.get("superseded") or 0)}
        except Exception as e:
            return 400, {"error": str(e), "code": "invalid_publish"}
    return None
