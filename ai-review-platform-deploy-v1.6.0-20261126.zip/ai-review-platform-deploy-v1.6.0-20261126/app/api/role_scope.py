# -*- coding: utf-8 -*-
"""系统管理员（super_admin）业务边界 + 业务写第二道角色校验（F-28 P0）。

外部独立验收报告 2026-11-17 F-28：旧实现用「审核业务前缀黑名单」
``_BIZ_PREFIXES`` + 只读判定，漏掉 evolution/errorbook/rsi/qa/calibration/
manifest/audit/scheduler 等业务前缀时，系统管理员的写请求会直接穿过角色
门禁进入业务层；同类新前缀还会继续漏。

本模块提供 fail-closed 白名单反向判定（第一道，URL 层）：

1. 平台/IT 域（账号/模型/智能体/开放平台/系统审计日志/消息配置/租户配置/
   运维看板）明确列出，方法不限（由各模块自身权限再校验）；
2. 审核业务仅放行「明确列出的只读 GET」，且有副作用的 GET（报告生成、
   历史 GET 写入口）一律拒绝；
3. 其余 /api/v1 请求对 super_admin 一律 403，新增业务前缀默认拒绝。

业务写还有第二道角色校验（``business_write_denied``）：不依赖 URL 前缀清单，
按服务层权限事实源 ``app.services.permissions.write_denied`` 判定；供
server.py 各业务写路由分支与 route 模块（如 evolution_routes）调用。
"""
from __future__ import annotations

import logging

# ---------------------------------------------------------------------------
# 第一道：super_admin 白名单反向判定
# ---------------------------------------------------------------------------
# 平台/IT 域：系统管理员可读写，不属于审核业务。
SUPER_ADMIN_PLATFORM_PREFIXES = (
    "/api/v1/users", "/api/v1/password-resets",
    "/api/v1/model", "/api/v1/models",
    "/api/v1/agents",
    "/api/v1/open/",
    "/api/v1/audit-logs",
    "/api/v1/notify", "/api/v1/notifications", "/api/v1/alerts",
    "/api/v1/tenant/",
    "/api/v1/ops/",
    "/api/v1/data-policy",
    "/api/v1/system/",
    "/api/v1/me", "/api/v1/auth/", "/api/v1/page-guide/",
    "/api/v1/public/", "/api/v1/events/",
    "/api/v1/fs/", "/api/v1/layout/",
)
# 审核业务只读 GET 白名单：只放行「读」，写方法（POST/PUT/DELETE）一律 403。
SUPER_ADMIN_BIZ_READ_PREFIXES = (
    "/api/v1/home", "/api/v1/dashboard",
    "/api/v1/projects", "/api/v1/reviews", "/api/v1/reports", "/api/v1/documents",
    "/api/v1/rules", "/api/v1/rule/", "/api/v1/workspaces", "/api/v1/findings",
    "/api/v1/analytics", "/api/v1/conflicts", "/api/v1/feedback",
    "/api/v1/auditpoints", "/api/v1/audit-points", "/api/v1/doctypes",
    "/api/v1/sediment", "/api/v1/terms", "/api/v1/decision-tables",
    "/api/v1/ontology", "/api/v1/evolution", "/api/v1/errorbook",
    "/api/v1/rsi", "/api/v1/qa", "/api/v1/calibration", "/api/v1/manifest",
    "/api/v1/audit/", "/api/v1/audit-records", "/api/v1/audit-categories",
    "/api/v1/scheduler", "/api/v1/my-audits", "/api/v1/eval",
    "/api/v1/review/", "/api/v1/points/", "/api/v1/highlight", "/api/v1/kie/",
    "/api/v1/resolve/", "/api/v1/tasks", "/api/v1/trend/",
    "/api/v1/schema/", "/api/v1/doc/",
)
# 历史 GET 写入口：任何角色都先 405「写操作请使用 POST」。
# super_admin 只读判定与 do_GET 的 405 判定必须同源，禁止各维护一份清单。
GET_WRITE_SUFFIXES = ("/publish", "/submit", "/approve", "/update", "/restore",
                      "/params/publish", "/mine/draft", "/batch",
                      "/qa/sample", "/scheduler/run", "/rsi/frozen",
                      "/settle", "/rollback", "/judge", "/analyze",
                      "/audit-points/confirm", "/audit-points/execute",
                      "/audit-points/prepare-migration",
                      "/audit-points/activate-confirm",
                      "/audit-points/confirm-recommended", "/mechanism/import")
# 报告生成 GET 会落报告记录/审计日志：super_admin 只读也必须拒绝。
REPORT_EXPORT_SUFFIXES = ("/report.docx", "/report.html", "/report.pdf")


def is_get_write_path(path: str) -> bool:
    """该 GET 路径实际是写操作（历史 GET 写入口，统一 405）。"""
    return any(path.endswith(x) for x in GET_WRITE_SUFFIXES)


def is_report_export_path(path: str) -> bool:
    return path.startswith("/api/v1/reviews/") and any(
        path.endswith(x) for x in REPORT_EXPORT_SUFFIXES)


def super_admin_denied(method: str, path: str) -> bool:
    """系统管理员白名单反向判定：返回 True 表示拒绝。

    - 平台/IT 域：放行（方法不限）；
    - 审核业务：仅放行明确列出的只读 GET，且不能是有副作用的 GET；
    - 其它 /api/v1 路径：默认拒绝（fail-closed）。
    """
    if not path.startswith("/api/v1/"):
        return False
    if any(path.startswith(x) for x in SUPER_ADMIN_PLATFORM_PREFIXES):
        return False
    if str(method or "").upper() in ("GET", "HEAD"):
        if is_get_write_path(path) or is_report_export_path(path):
            return True
        if any(path.startswith(x) for x in SUPER_ADMIN_BIZ_READ_PREFIXES):
            return False
    return True


# ---------------------------------------------------------------------------
# 第二道：业务写角色校验（不依赖 URL 前缀清单）
# ---------------------------------------------------------------------------
def business_write_denied(handler, action: str = ""):
    """路由/服务层第二道角色校验（F-28）。返回 None=放行，否则已发送 403 响应。

    第一道是 ``super_admin_denied``（URL 白名单）；这里按服务层权限表
    ``app.services.permissions.write_denied`` 再判一次角色，即使新增路由/前缀
    没有被登记，系统管理员/平台运营也不能写审核业务。
    """
    try:
        from app.services import permissions as _perms
        user = handler._session_user() or {}
        role = str(user.get("role") or "")
        if _perms.write_denied(role):
            msg = ("系统管理员不访问审核业务" if role == "super_admin"
                   else "平台身份不可访问业务接口")
            if action:
                logging.getLogger(__name__).info(
                    "business write denied by role: role=%s action=%s", role, action)
            return handler._err(403, msg, "forbidden")
    except Exception:
        # P2-19：权限判定异常必须 fail-closed（拒绝），不能吞异常后放行。
        logging.getLogger(__name__).error(
            "business write role check failed（fail-closed，拒绝本次写）action=%s",
            action, exc_info=True)
        return handler._err(500, "权限校验失败，已拒绝本次操作（请稍后重试）",
                            "permission_check_failed")
    return None


def feedback_scope(handler, feedback_id: str):
    """feedback 统一作用域（F-12）：不存在/跨租户 404、他人项目 403。

    反馈表没有独立 resolver 分支，这里按主键原始读取后解析所属 case，
    与其它业务路由「先 404 再 403」的口径一致；不能把查不到统一降级成 400。
    """
    from app import db
    fid = str(feedback_id or "").strip()
    if not fid:
        return None, (404, {"error": "反馈不存在", "code": "not_found"})
    try:
        with db.session() as c:
            r = c.execute("SELECT * FROM feedback WHERE id=?", (fid,)).fetchone()
            row = dict(r) if r else None
    except Exception:
        row = None
    if not row:
        return None, (404, {"error": "反馈不存在", "code": "not_found"})
    cid = str(row.get("case_id") or "").strip()
    if not cid and row.get("finding_id"):
        try:
            with db.session() as c:
                f = c.execute("SELECT case_id FROM finding WHERE id=?",
                              (row.get("finding_id"),)).fetchone()
                cid = str((f["case_id"] if f else "") or "")
        except Exception:
            cid = ""
    if cid:
        _case, deny = handler._resolve_id("case", cid)
        if deny:
            st = int(deny[0])
            if st == 404:
                return None, (404, {"error": "反馈不存在", "code": "not_found"})
            return None, (403, {"error": "无权访问该反馈", "code": "forbidden"})
    return row, None
