"""租户配置/品牌路由（业务管理员域）。

路由函数不直接写 HTTP 响应，返回 ``(status, payload)`` 或 ``None``。
- ``/api/v1/tenant/config``：仅本租户 active role=admin 可读写，reviewer 403；
  tenant 只取自会话账号自身，请求体里的 tenant_id 不参与更新。
- ``/api/v1/tenant/branding``：登录后只读品牌（admin/reviewer/系统管理员均可读），
  用于 sidebar/title 同步；平台运营账号无租户，按现有边界 403。
- ``/api/v1/public/tenant-branding``：登录页按 ?tenant=CODE 读取品牌，无需会话。
"""
from __future__ import annotations

from .. import db
from ..services import tenants


def _deny(msg="无权限", code="forbidden"):
    return 403, {"error": msg, "code": code}


def _user_row(uid: str) -> dict:
    if not uid:
        return {}
    c = db.connect()
    try:
        row = c.execute("SELECT id,tenant_id,status FROM user WHERE id=?", (uid,)).fetchone()
        return dict(row) if row else {}
    finally:
        c.close()


def get(path: str, user: dict):
    uid = str((user or {}).get("sub") or "")
    role = str((user or {}).get("role") or "")
    if not uid:
        return 401, {"error": "未登录", "code": "unauthorized"}
    if path == "/api/v1/tenant/config":
        # 租户配置本身只对业务管理员开放；reviewer/系统管理员/平台运营 403。
        if role != "admin":
            return _deny("仅租户业务管理员可访问租户配置", "forbidden")
        row = _user_row(uid)
        if not row or not row.get("tenant_id"):
            return _deny("账号未归属租户，不能访问租户配置", "forbidden")
        branding = tenants.get_tenant_branding(row["tenant_id"])
        return 200, {"ok": True, "tenant_id": row["tenant_id"],
                     "can_edit": True, "branding": branding,
                     "platform_name": branding.get("platform_name"),
                     "logo_url": branding.get("logo_url")}
    if path == "/api/v1/tenant/branding":
        if role == "platform_op" or not uid:
            return _deny("平台账号无租户品牌", "forbidden")
        return 200, {"ok": True, "branding": tenants.branding_for_user(uid)}
    return None


def post(path: str, user: dict, body: dict):
    uid = str((user or {}).get("sub") or "")
    role = str((user or {}).get("role") or "")
    # /tenant/branding 同时接受写操作，保持与租户配置同一权限和校验口径。
    if path in ("/api/v1/tenant/config", "/api/v1/tenant/branding"):
        if role != "admin":
            return _deny("仅租户业务管理员可修改租户配置", "forbidden")
        if not uid:
            return 401, {"error": "未登录", "code": "unauthorized"}
        r = tenants.update_tenant_branding(uid, body or {}, actor=uid, role=role)
        if r.get("ok"):
            return 200, r
        code = str(r.get("code") or "")
        status = 401 if code == "unauthorized" else 403 if code == "forbidden" else 400
        return status, r
    return None


def public_get(query: dict):
    """登录页品牌：按租户 code/id 读取；未配置/不存在回退默认。"""
    q = query or {}
    ref = str(q.get("tenant") or q.get("code") or q.get("tenant_id") or "").strip()
    branding = tenants.get_tenant_branding(ref)
    return 200, {"ok": True, "branding": branding,
                 "platform_name": branding.get("platform_name"),
                 "logo_url": branding.get("logo_url")}
