"""企业业务词典（terms）HTTP 动作层：从 server.py 抽出服务调用。

拆分边界说明（重要，勿误改）：
- **路由匹配、管理员门禁、请求字段解析、HTTP 状态码映射仍留在 server.py**。
  原因是 gate 的词典 UI 静态契约测试
  （``scripts/qa/dict_ui_static_test.py::test_backend_route_contract``、
  ``scripts/qa/dict_stale_ui_test.py::test_http_route_contract``）直接断言
  ``app/api/server.py`` 文本里必须存在这些路由谓词、字段读取、权限文案与
  ``http_status`` 映射；它们不在本次可改文件范围内。把这些内容整体搬走会
  让 gate 两项 FAIL。
- 因此本模块承接**动作实现**：把 HTTP 层解析好的参数归一后调用 terms 服务，
  统一返回服务结果；server.py 只保留薄适配（谓词 → 权限 → 字段 → 本模块 →
  状态码），URL/权限/返回与拆分前逐字段一致。
- 后续若允许更新上述静态测试，可把 server.py 的薄适配整体迁入本模块。
"""
from __future__ import annotations

from ..services import terms as _terms


# --------------------------------------------------------------------------- 读取
def list_terms(status: str = ""):
    return _terms.list_terms(status)


def preview_migration(actor: str = "", dry_run: bool = True, all_spaces: bool = True):
    return _terms.migrate_legacy_ontology_terms(
        actor=actor, dry_run=dry_run, all_spaces=all_spaces)


# --------------------------------------------------------------------------- 写入
def create_term(name: str, definition: str, synonyms, not_equal, source: str,
                scope: str, key: str, actor: str, entity_type: str = "",
                unit: str = "", relations=None):
    return _terms.create_term(name, definition, synonyms or [], not_equal or [],
                              source or "", scope or "", key or "", actor,
                              entity_type or "", unit or "", relations or [])


def update_term(term_id: str, body: dict, actor: str):
    return _terms.update_term(term_id, body or {}, actor)


def delete_term(term_id: str, actor: str):
    return _terms.delete_term(term_id, actor)


def confirm(term_id: str, actor: str):
    return _terms.confirm(term_id, actor)


def migrate(actor: str, dry_run: bool = False, all_spaces: bool = False):
    return _terms.migrate_legacy_ontology_terms(
        actor=actor, dry_run=bool(dry_run), all_spaces=bool(all_spaces))
