"""规则进化 HTTP 路由：从 server.py 物理移出。

边界（URL/权限/返回与拆分前一致，由 server_split_contract_test 的
41 路由 × 5 身份契约回归锁定）：
- URL/权限/返回不变；鉴权仍由 server.py 的 ``_guard`` 先做，本模块只处理
  handler 已经通过身份校验后的路由分支。
- ``/api/v1/evolution/rules/<code>/replay|trend|rollback-suggestion`` 仍由
  ``evolution.handle_http`` 在 ``_guard`` 之前的前置钩子分发（历史边界，
  见 app/services/evolution.py），不在本模块重复。
- GET 前缀先判 ``mod_evolution`` 空间开关；POST 不判（与拆分前一致，POST
  的 evolution 分支原本没有模块开关检查）。
- 模块通过 handler 复用 ``_session_user``/``_body``/``_send`` 等既有能力，
  不另起会话与响应实现。
"""
from __future__ import annotations

from .. import repositories as R
from ..services import evolution
from ..services import rule as rule_service



def _finding_scope(handler, finding_id: str):
    """进化沉淀/分析的对象作用域：跨租户/不存在 404，他人项目 403（与 HTTP 其余入口一致）。

    之前直接调 evolution.settle_feedback/analyze_feedback，跨租户 ID 会绕过 resolver
    返回 200/400（F5：跨租户 400 而非 404）。这里先走统一 finding resolver。
    """
    _row, deny = handler._resolve_id("finding", finding_id)
    if deny:
        return deny
    return None


def _module_off(handler) -> bool:
    """与 server._module_off 同口径：当前空间显式关闭 mod_evolution 时拒绝。"""
    try:
        from ..services import workspaces as _wm
        u = handler._session_user() or {}
        cur = _wm.current(u.get("sub", ""))
        return _wm.explicit_off(cur.get("id", ""), "mod_evolution")
    except Exception:
        return False


def _evo_limit(handler, default: int = 200, cap: int = 500) -> int:
    """L18 三个只读视图的 limit 解析（越界钳制，非法值回默认；不抛 500）。"""
    try:
        raw = (handler._query() or {}).get("limit")
        if isinstance(raw, (list, tuple)):
            raw = raw[0] if raw else ""
        return max(1, min(int(raw), cap)) if raw else default
    except (TypeError, ValueError):
        return default


def _evo_role(handler) -> dict:
    return handler._session_user() or {}


def get(handler, path: str, query: dict):
    """GET 分支：返回 (status, body) 或 None（非本组路由）。"""
    if path.startswith("/api/v1/evolution") and _module_off(handler):
        return 403, {"error": "该工作空间已关闭规则进化模块", "code": "module_off"}
    # L18（S3）自进化前端 3 个只读视图：归因复核 / 候选门禁时间线 / 生效版本与回滚。
    # 服务层各自做 evo.view 权限与 reviewer 数据范围（服务层 403 与 HTTP 同码）。
    if path.rstrip("/") == "/api/v1/evolution/attribution":
        _out = evolution.attribution_review(limit=_evo_limit(handler, 200), user=_evo_role(handler))
        return (200 if _out.get("ok") else int(_out.get("status") or 403)), _out
    if path.rstrip("/") == "/api/v1/evolution/candidates":
        _out = evolution.candidate_timeline(
            limit=_evo_limit(handler, 50), rule_code=str((handler._query() or {}).get("rule") or ""),
            user=_evo_role(handler))
        return (200 if _out.get("ok") else int(_out.get("status") or 403)), _out
    if path.rstrip("/") == "/api/v1/evolution/versions":
        _out = evolution.effective_versions(limit=_evo_limit(handler, 50), user=_evo_role(handler))
        return (200 if _out.get("ok") else int(_out.get("status") or 403)), _out
    if path.startswith("/api/v1/evolution/prereg/") and path.count("/") == 5:
        # 只读哈希状态（不阻断）；门禁读取（候选时间线）才做 blocked 断言。
        cid = path.rstrip("/").split("/")[-1]
        return 200, {"ok": True, "candidate_id": cid,
                     "check": evolution.prereg_assert(cid, by="http-read", block=False)}
    if path == "/api/v1/evolution/feedback":

        try:
            from ..services import feedback as _fb2
            _ledger = {"items": _fb2.list_feedback(limit=50), "stats": _fb2.stats()}
        except Exception:
            _ledger = {"items": [], "stats": {}}
        return 200, {"items": evolution.feedback_list(),
                     "stats": evolution.feedback_stats(),
                     "ledger": _ledger}
    if path == "/api/v1/evolution":
        return 200, evolution.evolution_suggestions()
    if path == "/api/v1/evolution/points":
        return 200, evolution.point_suggestions()
    if path == "/api/v1/errorbook":
        # 错误书沿用历史 URL（不在 /evolution 前缀下），仍属进化域路由。
        limit, offset = handler._pagination()
        return 200, evolution.error_book()[offset:offset + limit]
    # 兼容旧 do_GET 末尾的写语义入口（拆分前 GET 也能触发，行为保持不变）。
    # F-29：/analyze 已收口为 GET 写 405（server._GET_WRITE_SUFFIXES），这里仅作为
    # 直接调用本模块时的第二道角色校验。
    if path.startswith("/api/v1/evolution/feedback/") and path.endswith("/analyze"):
        from ..services import permissions as _perms
        if _perms.write_denied((handler._session_user() or {}).get("role") or ""):
            return 403, {"error": "系统管理员不访问审核业务", "code": "forbidden"}
        fid = path.split("/")[-2]
        _deny = _finding_scope(handler, fid)
        if _deny:
            return _deny
        u = handler._session_user() or {}
        return 200, evolution.analyze_feedback(fid, u.get("sub", ""))
    if path.startswith("/api/v1/evolution/feedback/") and path.endswith("/settle"):
        fid = path.split("/")[-2]
        _deny = _finding_scope(handler, fid)
        if _deny:
            return _deny
        b = handler._body()
        u = handler._session_user() or {}
        return 200, evolution.settle_feedback(
            fid, b.get("action", "revise"), b.get("note", ""), u.get("sub", ""))
    return None


def post(handler, path: str, user: dict):
    """POST 分支：返回 (status, body) 或 None（非本组路由）。"""
    u = user or {}
    # F-28 第二道角色校验（服务层权限表）：系统管理员/平台运营不得写审核业务。
    # 第一道是 server._guard 的白名单反向判定；这里不依赖 URL 前缀清单。
    from ..services import permissions as _perms
    if _perms.write_denied(u.get("role") or ""):
        return 403, {"error": "系统管理员不访问审核业务", "code": "forbidden"}
    # L18（S4）：显式登记候选预注册 hash（运维/CI/迁移用；正式写点在候选创建时）。
    if path.startswith("/api/v1/evolution/prereg/") and path.count("/") == 5:
        if not evolution.user_can_manage(u):
            return 403, {"error": "无权限登记预注册 hash（需要 evo.manage）", "code": "forbidden"}
        cid = path.rstrip("/").split("/")[-1]
        b = handler._body() or {}
        out = evolution.prereg_register_candidate(
            cid, prereg_path=str(b.get("prereg_path") or ""), by=u.get("sub", ""))
        return int(out.get("status") or 200) if isinstance(out.get("status"), int) else 200, out
    if path.startswith("/api/v1/evolution/") and path.endswith("/draft"):
        code = path.split("/")[-2]
        try:
            base = next((r for r in R.rules.list() if r.get("code") == code), None)
            name = (base or {}).get("name") or code
            res = rule_service.create_rule(
                f"{code}-R1", f"{name}（修订稿）", (base or {}).get("category", "consistency"),
                (base or {}).get("rclass", "R2"),
                {"require": "待补充执行条件"}, source="进化建议生成")
            R.audit_logs.log(actor=u.get("sub", "admin"),
                             action="rule.draft_from_suggestion",
                             object=res.get("rule_id", ""))
            return 200, res
        except PermissionError as e:
            return 403, {"error": str(e), "code": "forbidden"}
        except Exception as e:  # noqa: BLE001
            return 400, {"error": f"生成失败：{type(e).__name__}", "code": "invalid_rule"}
    if path.startswith("/api/v1/evolution/feedback/") and path.endswith("/analyze"):
        fid = path.split("/")[-2]
        _deny = _finding_scope(handler, fid)
        if _deny:
            return _deny
        return 200, evolution.analyze_feedback(fid, u.get("sub", ""))
    if path.startswith("/api/v1/evolution/feedback/") and path.endswith("/settle"):
        fid = path.split("/")[-2]
        _deny = _finding_scope(handler, fid)
        if _deny:
            return _deny
        b = handler._body()
        return 200, evolution.settle_feedback(
            fid, b.get("action", "revise"), b.get("note", ""), u.get("sub", ""))
    return None


# ===================== 空间准确率看板（T-177 V1） =====================
# URL（任务/设计文档约定）：
#   GET  /api/v1/workspace/accuracy             → 每轮 F1+CI+n_docs+δ_min+规则数+配对Δ+判定
#   GET  /api/v1/workspace/accuracy/coldstart   → 冷启动「建议先补 N 条规则」
#   POST /api/v1/workspace/accuracy/rounds      → 记录一轮评测结果（逐文档 tp/fp/fn）
# 角色：GET = evo.view（admin/reviewer）；POST = evo.manage（admin）。
# 系统管理员/平台运营：按 F-28 不访问审核业务（server._guard 第一道 + 这里第二道）。
_ACC_GET_PATHS = ("/api/v1/workspace/accuracy", "/api/v1/workspace/accuracy/coldstart")
_ACC_POST_PATH = "/api/v1/workspace/accuracy/rounds"
# P2-B8-04 / AGENTS §13：n_docs 过小或 δ_min 不可估计时不允许声明「提升」。
# 单文档 bootstrap 退化为单点（CI 宽 0、σ/δ_min 无法估计），必须判 insufficient。
_ACC_MIN_DOCS_FOR_VERDICT = 5


def _enforce_resolution_verdict(round_obj: dict) -> dict:
    """看板口径守卫：没有设计分辨率（δ_min）就不许声明提升/回归。"""
    if not isinstance(round_obj, dict):
        return round_obj
    delta = round_obj.get("delta")
    if not isinstance(delta, dict):
        return round_obj
    verdict = delta.get("verdict") if isinstance(delta.get("verdict"), dict) else {}
    if not verdict:
        return round_obj
    # 2026-11-21 修正：首轮没有可配对上一轮 → verdict=baseline（这是「如实说没对照」，
    # 不是「宣称提升」）。B8-04 的降级只应作用于**有对照轮次**的比较结论，否则会把
    # 合法的 baseline 首轮误判成 insufficient（空间准确率看板 A9 因此 FAIL）。
    if str(verdict.get("code") or "") == "baseline" or not delta.get("available", True):
        return round_obj
    n_docs = int(round_obj.get("n_docs") or 0)
    delta_min = delta.get("delta_min")
    reason = ""
    if n_docs < _ACC_MIN_DOCS_FOR_VERDICT:
        reason = (f"n_docs={n_docs} < {_ACC_MIN_DOCS_FOR_VERDICT}：样本量不足，"
                  "无法估计设计分辨率 δ_min，不能判定提升/回归")
    elif delta_min is None:
        reason = "δ_min 不可估计（σ_Δ 或配对样本缺失），不能判定提升/回归"
    if reason and str(verdict.get("code") or "") != "insufficient":
        delta["original_verdict"] = dict(verdict)
        delta["verdict"] = {"code": "insufficient", "label": "样本不足，无法判定",
                            "rule": reason, "n_docs": n_docs, "delta_min": delta_min}
        delta["resolution_insufficient"] = True
        delta["resolution_reason"] = reason
    return round_obj


def _enforce_board_resolution(body: dict) -> dict:
    """把口径守卫套到看板/轮次写入响应（含 summary.latest_verdict 同步）。"""
    if not isinstance(body, dict) or body.get("code") in ("forbidden", "storage_unavailable"):
        return body
    rounds = body.get("rounds")
    if isinstance(rounds, list):
        for r in rounds:
            _enforce_resolution_verdict(r)
        if rounds:
            body["latest"] = rounds[-1]
    latest = body.get("latest")
    if isinstance(latest, dict):
        _enforce_resolution_verdict(latest)
    summary = body.get("summary")
    if isinstance(summary, dict) and isinstance(latest, dict):
        summary["latest_verdict"] = (latest.get("delta") or {}).get("verdict")
        summary["verdicts"] = [((r.get("delta") or {}).get("verdict") or {}).get("code")
                               for r in (rounds or [])]
    _enforce_resolution_verdict(body)
    return body


def _acc_read_limit(handler, default: int = 20) -> int:
    try:
        raw = (handler._query() or {}).get("limit")
        return max(1, min(int(raw), 200)) if raw else default
    except Exception:
        return default


def get_accuracy(handler, path: str, query: dict = None):
    """GET 分支：返回 (status, body) 或 None（非本组路由）。"""
    p = str(path or "").rstrip("/")
    if p == "/api/v1/workspace/accuracy":
        from ..services import evolution as _evo
        u = handler._session_user() or {}
        from ..services import permissions as _perms
        if str(u.get("role") or "") in _perms.BUSINESS_WRITE_DENY_ROLES:
            return 403, {"error": "系统管理员不访问审核业务", "code": "forbidden"}
        return 200, _enforce_board_resolution(
            _evo.accuracy_board(limit=_acc_read_limit(handler, 20), user=u))
    if p == "/api/v1/workspace/accuracy/coldstart":
        from ..services import evolution as _evo
        u = handler._session_user() or {}
        from ..services import permissions as _perms
        if str(u.get("role") or "") in _perms.BUSINESS_WRITE_DENY_ROLES:
            return 403, {"error": "系统管理员不访问审核业务", "code": "forbidden"}
        return 200, _evo.accuracy_coldstart(limit=_acc_read_limit(handler, 5), user=u)
    return None


def post_accuracy(handler, path: str, user: dict):
    """POST 分支：返回 (status, body) 或 None（非本组路由）。"""
    p = str(path or "").rstrip("/")
    if p != _ACC_POST_PATH:
        return None
    from ..services import evolution as _evo
    u = user or {}
    out = _evo.accuracy_record_round(handler._body() or {}, user=u,
                                     source=str((handler._body() or {}).get("source") or ""))
    status = int(out.get("status") or (200 if out.get("ok") else 400))
    # P2-B8-04：n_docs/δ_min 不满足时强制 insufficient（响应与看板同口径）
    out = _enforce_board_resolution(out)
    return status, out
