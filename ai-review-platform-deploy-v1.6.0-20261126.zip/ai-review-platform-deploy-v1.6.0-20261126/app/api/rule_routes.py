"""规则生命周期写路由：从 server.py 抽出，行为保持不变。

T-185（KB 评审 P1-1）：`/api/v1/rules/{id}/update` 透传作用域/证据/点位字段，
让规则编辑器的「适用范围/适用条件/证据范围/必需证据/点位映射」真正落库；
服务端二次校验在 `rule.update_draft`（白名单/长度/真实点位），非法值返回 400。
"""
from __future__ import annotations
from ..services import rule, replay


def post(path: str, body: dict, user: dict):
    u = user or {}
    if path.startswith("/api/v1/rules/") and path.endswith("/update") and path.count("/") == 5:
        rid = path.split("/")[-2]
        if (u.get("role") or "") != "admin":
            return 403, {"error": "审核员只能新建或查看规则；修改规则需业务管理员", "code": "forbidden"}
        b = body or {}
        try:
            return 200, rule.update_draft(
                rid, b.get("name"), b.get("category"),
                b.get("criterion"), u.get("sub", "admin"),
                scope=b.get("scope"),
                evidence_scope=b.get("evidence_scope"),
                required_evidence=b.get("required_evidence"),
                point_id=b.get("point_id") or "",
                scope_declare_required=bool(b.get("scope_declare_required")))
        except ValueError as e:
            return 400, {"error": str(e), "code": "invalid_rule"}
    if path.startswith("/api/v1/rules/") and path.endswith("/submit") and path.count("/") == 5:
        rid = path.split("/")[-2]
        if (u.get("role") or "") != "admin":
            return 403, {"error": "审核员只能新建或查看规则；提交审批需业务管理员", "code": "forbidden"}
        return 200, rule.submit(rid, u.get("sub", "admin"))
    if path.startswith("/api/v1/rules/") and path.endswith("/approve") and path.count("/") == 5:
        rid = path.split("/")[-2]
        return 200, rule.approve(rid, u.get("sub", "admin"))
    if path.startswith("/api/v1/rules/") and path.endswith("/publish") and path.count("/") == 5:
        rid = path.split("/")[-2]
        return 200, rule.publish(rid)
    if path.startswith("/api/v1/rules/") and path.endswith("/restore") and path.count("/") == 5:
        rid = path.split("/")[-2]
        if (u.get("role") or "") != "admin":
            return 403, {"error": "仅业务管理员可回滚规则", "code": "forbidden"}
        return 200, rule.restore_version(rid, (body or {}).get("version") or "", u.get("sub", "admin"))
    if path.startswith("/api/v1/rules/") and path.endswith("/replay") and path.count("/") == 5:
        code = path.split("/")[-2]
        return 200, replay.replay(code)
    return None
