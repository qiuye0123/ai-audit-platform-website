"""审核点位路由：从 server.py 物理移出。

覆盖三组 URL（拆分前后完全一致）：
- ``/api/v1/points/detail`` 与 ``/api/v1/points/<id>``（点位详情/单点）
- ``/api/v1/audit-points...``（平台点位库、批次、确认、执行、迁移、路由）
- 对应 POST：confirm / execute / prepare-migration / activate-confirm /
  confirm-recommended / batch（L95：批量执行，复用单点服务层 + 预算 + 审计）

权限/返回约定：
- 鉴权仍由 server.py 的 ``_guard`` 先行；本模块只处理已登录用户的分支。
- 管理员门禁（admin/super_admin）、点位 ID resolver、二级 batch resolver、
  case 作用域沿用 handler 的统一实现，不新造一套 403/404 语义。
- 所有拒绝以 ``(status, body)`` 返回，由 server.py 用既有 ``_send`` 发出，
  保持 200→400（body 含 error 且无 ok）等历史行为不变。
"""
from __future__ import annotations

import base64
import json
import logging
import os
import tempfile

from .. import db
from .. import repositories as R
from ..services import audit, auditpoints, extract, pstates, point_confirm


# --------------------------------------------------------------------------- 作用域
def _workspace_scope(handler, wsid, user=None):
    """点位确认迁移/启用只允许本租户空间；跨租户按不存在处理。"""
    wsid = str(wsid or "").strip()
    if not wsid:
        return None, None
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return None, (401, {"error": "未登录", "code": "unauthorized"})
    try:
        with db.session() as c:
            row = c.execute("SELECT * FROM workspace WHERE id=?", (wsid,)).fetchone()
    except Exception:
        row = None
    if not row:
        return None, (404, {"error": "工作空间不存在", "code": "not_found"})
    try:
        from ..services import ctx as _cx
        cur = _cx.get_context() or {}
    except Exception:
        cur = {}
    tenant = str(cur.get("tenant_id") or "")
    if tenant and str(row["tenant_id"] or "") and str(row["tenant_id"]) != tenant:
        return None, (404, {"error": "工作空间不存在", "code": "not_found"})
    return dict(row), None


# --------------------------------------------------------------------------- 点位确认/执行
def _confirm(handler, user=None):
    """点位确认/撤销：管理员门禁 → 点位 ID resolver → 写 auditpoint_confirmation。"""
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return 401, {"error": "未登录", "code": "unauthorized"}
    if (u.get("role") or "") not in ("admin", "super_admin"):
        return 403, {"error": "仅管理员可确认点位", "code": "forbidden"}
    b = handler._body() or {}
    _ids = b.get("point_ids") or []
    if _ids:
        if not isinstance(_ids, (list, tuple)):
            return 400, {"error": "point_ids 必须是数组", "code": "invalid_request"}
        _clean = [str(x).strip() for x in _ids if str(x).strip()]
        if not _clean:
            return 400, {"error": "point_ids 不能为空", "code": "invalid_request"}
        for _pid in _clean:
            _p, _deny = handler._resolve_id("point", _pid, u)
            if _deny:
                return _deny
        if b.get("revoke"):
            _r = point_confirm.revoke_many(_clean, actor=u.get("sub", ""))
        else:
            _r = point_confirm.confirm_many(_clean, actor=u.get("sub", ""))
        return 200, _r
    _pid = str(b.get("point_id") or "").strip()
    if not _pid:
        return 400, {"error": "point_id 必填", "code": "invalid_request"}
    _p, _deny = handler._resolve_id("point", _pid, u)
    if _deny:
        return _deny
    if b.get("revoke"):
        return 200, point_confirm.revoke(_pid, u.get("sub", ""))
    return 200, point_confirm.confirm(
        _pid, str(b.get("criterion") or ""), b.get("scope") or [], u.get("sub", ""))


def _execute(handler, user=None):
    """单点执行：先鉴权；请求若带 point.id 则先过 point resolver。"""
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return 401, {"error": "未登录", "code": "unauthorized"}
    b = handler._body() or {}
    point = b.get("point") or {}
    if not isinstance(point, dict):
        return 400, {"error": "point 必须是对象", "code": "invalid_request"}
    _pid = str(point.get("id") or "").strip()
    if _pid:
        _p, _deny = handler._resolve_id("point", _pid, u)
        if _deny:
            return _deny
    return 200, extract.execute_audit_point(point, b.get("doc_text", ""))


# --------------------------------------------------------------------------- 批量执行（L95）
# 预算上限（显式拒绝，不静默截断）：单次批量最多 BATCH_MAX_POINTS 个点位
# （每个点位 = 1 次单点执行调用），被测文本最多 BATCH_MAX_DOC_CHARS 字符。
BATCH_MAX_POINTS = 10
BATCH_MAX_DOC_CHARS = 200_000
BATCH_ACTIONS = ("execute",)
BATCH_AUDIT_ACTION = "auditpoint.batch_executed"


def _batch_budget() -> dict:
    """批量端点预算上限（机读；响应与 400 拒绝体共用）。"""
    return {"max_points": BATCH_MAX_POINTS, "max_doc_chars": BATCH_MAX_DOC_CHARS}


def _batch_execute(handler, user=None):
    """POST /api/v1/audit-points/batch：多审核点批量执行（逐项结果 + 预算 + 审计）。

    与单点 ``POST /api/v1/audit-points/execute`` 同一执行语义：
    逐项复用 ``extract.execute_audit_point``（先判适用再判合格，输出五态/证据/理由），
    权限同源（登录用户 + 每个点位走统一 ``_resolve_id``：不存在 404、跨租户按不存在、
    他人/跨空间 403）；本端点不新造 403/404 语义，也不写审核主链（与单点调试一致）。

    请求体（``points`` 与 ``point_ids`` 二选一，``points`` 优先）：
    - ``points``: [点位对象 或 点位 ID 字符串, ...]，最多 ``BATCH_MAX_POINTS`` 个；
      点位对象带 id/point_id/code 时先过 resolver，再按调用方对象执行（同单点 execute）。
    - ``point_ids``: ["A01-001", ...]（按平台点位库取点执行）
    - ``doc_text``: 被测文本（可选；超 ``BATCH_MAX_DOC_CHARS`` 显式 400，不截断）
    - ``action``: 仅支持 ``"execute"``（缺省）；其它值 400 ``batch_action_not_supported``

    返回：``items`` 逐项结果（index/point_id/ok/state/...，单项异常记 ok=false 不吞）、
    ``summary.by_state`` 五态计数、``budget``（上限/已用）、``audit``（批量审计是否留痕；
    只记 point_ids/状态分布，不记 doc_text，避免把被测原文写进审计）。
    """
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return 401, {"error": "未登录", "code": "unauthorized"}
    b = handler._body() or {}
    action = str(b.get("action") or "execute").strip().lower()
    if action not in BATCH_ACTIONS:
        return 400, {"error": f"不支持的批量动作：{action or '(空)'}（仅支持 execute）",
                     "code": "batch_action_not_supported", "action": action,
                     "supported": list(BATCH_ACTIONS)}
    doc_text = b.get("doc_text")
    if doc_text is None:
        doc_text = ""
    if not isinstance(doc_text, str):
        return 400, {"error": "doc_text 必须是字符串", "code": "invalid_request"}
    if len(doc_text) > BATCH_MAX_DOC_CHARS:
        return 400, {"error": f"doc_text 超过批量预算上限（{len(doc_text)} > "
                              f"{BATCH_MAX_DOC_CHARS} 字符）",
                     "code": "batch_budget_exceeded", "budget": _batch_budget(),
                     "received_doc_chars": len(doc_text)}
    raw = b.get("points")
    if raw is None:
        raw = b.get("point_ids")
    if raw is None:
        return 400, {"error": "points 或 point_ids 必填", "code": "invalid_request",
                     "budget": _batch_budget()}
    if not isinstance(raw, (list, tuple)):
        return 400, {"error": "points/point_ids 必须是数组", "code": "invalid_request"}
    if not raw:
        return 400, {"error": "批量列表不能为空", "code": "batch_empty",
                     "budget": _batch_budget()}
    if len(raw) > BATCH_MAX_POINTS:
        return 400, {"error": f"批量点位超过预算上限（{len(raw)} > {BATCH_MAX_POINTS}）",
                     "code": "batch_too_large", "budget": _batch_budget(),
                     "received_points": len(raw)}
    # 先解析/鉴权全部点位（任一点位不存在/越权 → 整批拒绝，不执行一半）
    resolved = []
    for i, item in enumerate(raw):
        if isinstance(item, str):
            pid = item.strip()
            if not pid:
                return 400, {"error": f"第 {i} 项点位 ID 为空", "code": "invalid_point",
                             "index": i}
            row, deny = handler._resolve_id("point", pid, u)
            if deny:
                return deny
            point = dict(row or {})
            resolved.append((pid, point))
            continue
        if isinstance(item, dict):
            point = dict(item)
            pid = str(point.get("id") or point.get("point_id")
                      or point.get("code") or "").strip()
            if pid:
                row, deny = handler._resolve_id("point", pid, u)
                if deny:
                    return deny
                # 与单点 execute 一致：resolver 只做鉴权，执行用调用方传入的点位对象；
                # 调用方对象缺关键字段时以库对象补齐，避免“有 id 但空判据”的隐式失败。
                for _k in ("point", "criterion", "action"):
                    if not str(point.get(_k) or "").strip() and row:
                        point[_k] = row.get(_k) or ""
                point.setdefault("id", pid)
            resolved.append((pid, point))
            continue
        return 400, {"error": f"第 {i} 项必须是点位对象或点位 ID 字符串",
                     "code": "invalid_point", "index": i}
    items, by_state = [], {}
    for i, (pid, point) in enumerate(resolved):
        try:
            res = extract.execute_audit_point(point, doc_text)
        except Exception as exc:  # noqa: BLE001 - 单项失败如实记录，整批不吞成假成功
            logging.getLogger(__name__).warning(
                "batch point execute failed index=%s point=%s", i, pid, exc_info=True)
            items.append({"index": i, "point_id": pid, "ok": False,
                          "error": f"{type(exc).__name__}: {exc}",
                          "state": ""})
            by_state["error"] = by_state.get("error", 0) + 1
            continue
        state = str((res or {}).get("state") or "")
        by_state[state or "unknown"] = by_state.get(state or "unknown", 0) + 1
        items.append({"index": i, "point_id": pid, "ok": True, **(res or {})})
    # 审计：每次批量 1 条（同事务写失败则整体失败，不 200 假成功）；不写 doc_text。
    audit_logged = False
    try:
        _ids = [pid for pid, _p in resolved if pid]
        _after = json.dumps({"action": action, "total": len(items),
                             "by_state": by_state, "point_ids": _ids},
                            ensure_ascii=False, sort_keys=True)
        with db.session() as c:
            audit.log_in_tx(c, actor=str(u.get("sub") or ""),
                            action=BATCH_AUDIT_ACTION,
                            object_=",".join(_ids)[:500], after=_after[:2000])
        audit_logged = True
    except Exception:  # noqa: BLE001 - 审计失败必须显式 500/fail-closed，不静默放行
        logging.getLogger(__name__).error(
            "batch execute audit failed; refuse to report success", exc_info=True)
        return 500, {"error": "批量执行审计写入失败，已拒绝本次结果",
                     "code": "audit_write_failed"}
    return 200, {"ok": True, "action": action,
                 "doc_chars": len(doc_text),
                 "budget": {**_batch_budget(), "used_points": len(items),
                            "truncated": False},
                 "summary": {"total": len(items), "by_state": by_state},
                 "items": items,
                 "audit": {"action": BATCH_AUDIT_ACTION, "logged": audit_logged,
                           "count": 1}}


def _prepare_migration(handler, user=None):
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return 401, {"error": "未登录", "code": "unauthorized"}
    if (u.get("role") or "") not in ("admin", "super_admin"):
        return 403, {"error": "仅管理员可迁移点位", "code": "forbidden"}
    b = handler._body() or {}
    _ws, _deny = _workspace_scope(handler, str(b.get("workspace_id") or ""), u)
    if _deny:
        return _deny
    return 200, point_confirm.prepare_migration(
        str(b.get("workspace_id") or ""), u.get("sub", ""))


def _activate(handler, user=None):
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return 401, {"error": "未登录", "code": "unauthorized"}
    if (u.get("role") or "") not in ("admin", "super_admin"):
        return 403, {"error": "仅管理员可启用点位门禁", "code": "forbidden"}
    b = handler._body() or {}
    _ws, _deny = _workspace_scope(handler, str(b.get("workspace_id") or ""), u)
    if _deny:
        return _deny
    return 200, point_confirm.activate_workspace(
        str(b.get("workspace_id") or ""), u.get("sub", ""))


def _confirm_recommended(handler, user=None):
    u = user if user is not None else (handler._session_user() or {})
    if not u:
        return 401, {"error": "未登录", "code": "unauthorized"}
    if (u.get("role") or "") not in ("admin", "super_admin"):
        return 403, {"error": "仅管理员可确认点位", "code": "forbidden"}
    return 200, point_confirm.confirm_recommended(u.get("sub", ""))


# --------------------------------------------------------------------------- 点位库
def _base_type(name):
    """文件类型 → 业务域；唯一事实源在 app.services.workspaces.base_type_of。

    新建空间适用性判断（T-105）也消费同一份口径，这里只做转发，避免两处各写一套。
    """
    try:
        from ..services import workspaces as _wsm
        return _wsm.base_type_of(name)
    except Exception:  # 端点库异常时退回本地启发式，不影响点位列表返回
        n = str(name or "")
        if any(k in n for k in ("食品", "工艺", "配方", "检验", "标签", "生产")):
            return "food"
        if any(k in n for k in ("合同", "招标", "投标", "报价", "采购", "销售")):
            return "contract"
        if any(k in n for k in ("申报", "许可", "资质", "执照", "审批", "备案")):
            return "application"
        return "general"


def _library():
    from ..services import workspaces as _wsm
    lib = auditpoints.load()
    _profiles = _wsm.document_type_profiles()
    docs = []
    seen = set()
    for d in (lib.document_types or []):
        nm = str(d.get("name") or d.get("id") or "").strip() if isinstance(d, dict) else ""
        if not nm or nm in seen:
            continue
        seen.add(nm)
        prof = _profiles["types"].get(nm) or {}
        docs.append({"id": (d.get("id") or nm) if isinstance(d, dict) else nm,
                     "name": nm,
                     "base_type": _base_type(nm),
                     "default_audit_types": list(prof.get("default_audit_types") or [
                         str(x) for x in ((d.get("default_audit_types") or []) if isinstance(d, dict) else [])
                         if str(x).strip()]),
                     "aliases": list(prof.get("aliases") or [])})
    if not docs:
        docs = [{"id": x, "name": x, "base_type": b,
                 "default_audit_types": [], "aliases": []} for x, b in [
            ("食品工艺书", "food"), ("采购合同", "contract"), ("销售合同", "contract"),
            ("申报材料", "application"), ("通用文件", "general")]]
    # T-105：文件类型选择框最后固定加“其他（未列入标准类型）”。
    # 只扩展 document_types 的条目字段（HTTP 顶层 key 契约不变），前端据此渲染最后一项。
    if not any(x.get("name") == _wsm.OTHER_DOC_TYPE for x in docs):
        docs.append({"id": "DT-OTHER", "name": _wsm.OTHER_DOC_TYPE,
                     "base_type": "general", "default_audit_types": [],
                     "aliases": [], "other": True,
                     "note": "通用规则 / 需人工确认；不伪造专用规则"})
    types = []
    for t in (getattr(lib, "audit_types", []) or []):
        if isinstance(t, dict):
            types.append({"id": t.get("id") or "", "name": t.get("name") or "",
                          "category_id": t.get("category_id") or t.get("category") or ""})
    return {"document_types": docs,
            "categories": [{"id": x, "name": x} for x in (lib.categories_list() or [])],
            "audit_types": types}


def _options(handler):
    """新建规则可选的平台点位：只返回当前工作空间文件类型匹配的点位。"""
    lib = auditpoints.load()
    try:
        from ..services import workspaces as _wsm
        _u = handler._session_user() or {}
        _cur = _wsm.current(_u.get("sub", "")) or {}
        _st = _wsm.get_settings(_cur.get("id", "")) or {}
        _doc_types = [str(x) for x in (_st.get("doc_types") or []) if str(x).strip()]
    except Exception:
        _cur, _doc_types = {}, []
    _bases = {_base_type(x) for x in _doc_types if _base_type(x) != "general"}
    # 优先用审核库的“文档类型 → 默认审核类型”映射，避免把合同点位混进食品工艺书
    _doc_map = {}
    for _dt in (getattr(lib, "document_types", []) or []):
        _nm = str(_dt.get("name") or "")
        if _nm:
            _doc_map[_nm] = set(_dt.get("default_audit_types") or [])
    _allowed_types = set()
    for _nm in _doc_types:
        if _nm in _doc_map:
            _allowed_types |= _doc_map[_nm]
        else:
            # 兼容“工艺空间”写成主类型的场景，按名称包含关系找最接近的文档类型
            for _k, _v in _doc_map.items():
                if _nm in _k or _k in _nm:
                    _allowed_types |= _v
    items = []
    for _p in (getattr(lib, "points", []) or []):
        _d = _p.to_dict() if hasattr(_p, "to_dict") else dict(_p)
        _pb = _base_type(_d.get("type_name") or _d.get("name") or "")
        if _allowed_types:
            _matched = (_d.get("type_id") in _allowed_types)
        else:
            _matched = (not _bases) or (_pb in _bases) or (_pb == "general")
        if not _matched:
            continue
        items.append({"id": _d.get("id") or "", "code": _d.get("code") or "",
                      "name": _d.get("name") or _d.get("point") or "",
                      "type_id": _d.get("type_id") or "",
                      "type_name": _d.get("type_name") or "",
                      "category": _d.get("category") or "",
                      "severity": _d.get("severity") or ""})
    return {"items": items, "total": len(items), "workspace": _cur.get("name") or "",
            "doc_types": _doc_types,
            "note": "仅显示当前工作空间文件类型匹配的平台点位；留空表示自动映射。"}


def _detail(handler, query):
    q = {k: (v[0] if v else "") for k, v in (query or {}).items()}
    b = str(q.get("batch") or "")
    cid = str(q.get("case") or "")
    u = handler._session_user() or {}
    batches = [x.strip() for x in b.split(",") if x.strip()]
    if cid:
        # case 维度统一走 resolver + 所有权：不存在/跨租户 404，跨空间/他人 403。
        _case, _deny = handler._case_scope(cid, u)
        if _deny:
            return _deny
    if batches:
        # 批次是二级 ID：先解析到 case 再按租户/空间/归属鉴权，且不能被 case 参数绕过。
        _bcid = ""
        for _bid in batches:
            _bobj, _deny = handler._secondary_scope("batch", _bid, u)
            if _deny:
                return _deny
            if not _bcid:
                _bcid = _bobj.get("case_id") or ""
            elif _bcid != (_bobj.get("case_id") or ""):
                return 404, {"error": "批次不存在", "code": "not_found"}
        if cid and cid != _bcid:
            return 404, {"error": "批次不存在", "code": "not_found"}
        if not cid:
            cid = _bcid
    if not cid and not batches and (u.get("role") or "") not in ("admin", "super_admin"):
        return 403, {"error": "缺少项目或批次", "code": "forbidden"}
    if cid and not batches:
        # 项目维度：取该项目最近一次审核的批次（audit_runs.batch_ids）
        try:
            case = R.cases.get(cid) or {}
            rid = case.get("last_run_id") or ""
            run = R.audit_runs.get(rid) if rid else {}
            bs = (run.get("batch_ids") or "").split(",")
            batches = [x for x in bs if x]
        except Exception as _e:
            logging.getLogger(__name__).warning("points/case 解析失败：%s", _e)
            batches = []
    if cid and not batches:
        # 项目对不上批次：返回空，绝不回退全库（否则会把别人的数据当本项目的）
        return 200, {"batch": "", "batches": [],
                     "summary": {"total": 0, "by_state": {}},
                     "items": [], "note": "该项目暂无点位记录"}
    merged = {}
    for x in batches:
        for it in pstates.detail(x):
            prev = merged.get(it["point_id"])
            if prev is None or str(it.get("quote") or "") > str(prev.get("quote") or ""):
                merged[it["point_id"]] = it
    items = list(merged.values())
    sm = {}
    for it in items:
        sm[it["state"]] = sm.get(it["state"], 0) + 1
    return 200, {"batch": (batches[0] if batches else ""),
                 "batches": batches,
                 "summary": {"total": len(items), "by_state": sm},
                 "items": items}


def _batch(handler):
    b = handler._body()
    filename = b.get("filename", "doc.xlsx")
    try:
        data = base64.b64decode(b.get("data", ""), validate=True)
    except Exception:
        return 400, {"error": "data 不是合法 base64", "code": "invalid_base64"}
    ok, why = handler._valid_file(filename, data)
    if not ok:
        return 400, {"error": why, "code": "invalid_file"}
    tmp = tempfile.NamedTemporaryFile(delete=False,
                                      suffix=os.path.splitext(filename)[1] or ".xlsx")
    try:
        tmp.write(data)
        tmp.close()
        return 200, auditpoints.batch_review(
            tmp.name, tier=b.get("tier", "S2"), max_points=int(b.get("max_points", 0) or 0))
    finally:
        os.unlink(tmp.name)


def _route(query):
    q = query or {}
    tier = q.get("tier", ["S2"])[0]
    families = q.get("families", [""])[0].split(",") if q.get("families") else None
    return 200, auditpoints.route(tier=tier, families=families)


# --------------------------------------------------------------------------- 路由入口
def get(handler, path: str, query: dict):
    """GET 分支：返回 (status, body) 或 None（非本组路由）。"""
    if path == "/api/v1/points/detail":
        return _detail(handler, query)
    if path.startswith("/api/v1/points/") and path.count("/") == 4:
        # 平台审核点位详情：统一 point resolver（全局库，不存在 404）。
        _pt, _deny = handler._resolve_id("point", path.split("/")[-1])
        if _deny:
            return _deny
        return 200, {"point": _pt}
    if path == "/api/v1/audit-points/recommended":
        return 200, point_confirm.recommended()
    if path == "/api/v1/audit-points/prepare-migration":
        return _prepare_migration(handler, handler._session_user() or {})
    if path == "/api/v1/audit-points/activate-confirm":
        return _activate(handler, handler._session_user() or {})
    if path == "/api/v1/audit-points/confirm-recommended":
        return _confirm_recommended(handler, handler._session_user() or {})
    if path == "/api/v1/audit-points/confirmations":
        return 200, point_confirm.status()
    if path == "/api/v1/audit-points":
        return 200, auditpoints.stats()
    if path == "/api/v1/audit-points/library":
        return 200, _library()
    if path == "/api/v1/audit-points/options":
        return 200, _options(handler)
    # 历史 GET 写入口：/batch 已由 server._GET_WRITE_SUFFIXES 统一 405（L95 起走 POST 批量执行）；
    # 这里保留旧分支仅用于 server 拆分前契约（不可经 HTTP 到达），不新增 GET 写语义。
    if path == "/api/v1/audit-points/batch":
        return _batch(handler)
    if path == "/api/v1/audit-points/confirm":
        return _confirm(handler, handler._session_user() or {})
    if path == "/api/v1/audit-points/execute":
        return _execute(handler, handler._session_user() or {})
    if path == "/api/v1/audit-points/route":
        return _route(query)
    return None


def post(handler, path: str, user: dict):
    """POST 分支：返回 (status, body) 或 None（非本组路由）。"""
    u = user or {}
    if path == "/api/v1/audit-points/confirm":
        return _confirm(handler, u)
    if path == "/api/v1/audit-points/execute":
        return _execute(handler, u)
    if path == "/api/v1/audit-points/batch":
        return _batch_execute(handler, u)
    if path == "/api/v1/audit-points/prepare-migration":
        return _prepare_migration(handler, u)
    if path == "/api/v1/audit-points/activate-confirm":
        return _activate(handler, u)
    if path == "/api/v1/audit-points/confirm-recommended":
        return _confirm_recommended(handler, u)
    return None
