# -*- coding: utf-8 -*-
"""开放平台 HTTP 路由（T-203 第一批：从 server.py 物理移出）。

覆盖：管理端 ``/api/v1/open/*``（应用/事件/回调投递/沙箱列表/deliver）、公开签名端
``/open/v1/tasks`` 与 ``/open/v1/tasks/{id}``、沙箱接收端 ``/api/v1/open/sandbox``
（公开但需可验证签名 + 大小上限）。

对象作用域 helper（``open_app_scope`` / ``open_task_detail_scoped`` / ``open_callback_ok`` /
``url_allowed``）唯一实现移入本模块；``server.py`` 保留同名别名，
``app/cli.py`` 的 ``from app.api.server import open_app_scope, ...`` 调用面不变。
"""
from __future__ import annotations

import json
import logging

from .. import db
from .. import repositories as R
from ..services import open as open_service

NOT_HANDLED = object()


def url_allowed(url: str) -> tuple:
    """SSRF 防护（P2-18）：与出站通道同源（net_guard），每次校验都重新解析并拒绝
    环回/私网/链路本地/元数据地址；实际出站由 net_guard 固定已校验 IP。"""
    try:
        from ..services import net_guard
        return net_guard.check_url(str(url or ""))
    except Exception:
        logging.getLogger(__name__).error("SSRF 校验失败（fail-closed）", exc_info=True)
        return False, "URL 校验失败"


def open_callback_ok(url: str) -> tuple:
    """开放平台回调：普通地址走 SSRF 校验；显式沙箱路径允许本机。"""
    from urllib.parse import urlparse
    u = urlparse(str(url or ""))
    if u.path == "/api/v1/open/sandbox" and u.hostname in ("127.0.0.1", "localhost", "::1"):
        return True, ""
    return url_allowed(url)


def open_app_scope(app_id: str, user: dict | None = None,
                   tenant_id: str = None, workspace_id: str = None):
    """开放平台应用：不存在/跨租户 404，同租户跨空间 403。"""
    u = user or {}
    if not u:
        return None, (401, {"error": "未登录", "code": "unauthorized"})
    if tenant_id is None or workspace_id is None:
        try:
            from ..services import ctx as _cx
            cur = _cx.get_context() or {}
        except Exception:
            cur = {}
        if tenant_id is None:
            tenant_id = cur.get("tenant_id") or ""
        if workspace_id is None:
            workspace_id = cur.get("workspace_id") or ""
    app = R.open_apps.get(str(app_id or ""))
    if not app:
        return None, (404, {"error": "应用不存在", "code": "not_found"})
    if not open_service._visible(app, str(tenant_id or ""), str(workspace_id or "")):
        return None, (403, {"error": "无权访问该应用", "code": "forbidden"})
    return app, None


def open_task_detail_scoped(task_id: str, tenant_id: str = "", workspace_id: str = "",
                            strict_workspace: bool = False):
    """开放平台任务详情：签名应用只能看本应用租户/空间的任务；管理端跨空间 403。"""
    tid = str(task_id or "").strip()
    row = None
    with db.session() as c:
        r = c.execute("SELECT id,tenant_id,workspace_id FROM open_task_queue WHERE id=?",
                      (tid,)).fetchone()
        if not r:
            r = c.execute("SELECT id,tenant_id,workspace_id FROM open_task WHERE id=?",
                          (tid,)).fetchone()
        row = dict(r) if r else None
    if not row:
        return None, (404, {"error": "任务不存在", "code": "not_found"})
    rt = str(row.get("tenant_id") or "")
    rw = str(row.get("workspace_id") or "")
    if tenant_id and rt and rt != tenant_id:
        return None, (404, {"error": "任务不存在", "code": "not_found"})
    if workspace_id and rw and rw != workspace_id:
        if strict_workspace:
            return None, (403, {"error": "无权访问该任务", "code": "forbidden"})
        return None, (404, {"error": "任务不存在", "code": "not_found"})
    try:
        from ..services import ctx as _cx
        # L98 P1：任务详情查询临时切到任务所属租户/空间；退出恢复调用方完整状态，
        # 避免同一请求后续读写残留任务作用域（旧实现只切不恢复）。
        _saved = _cx.snapshot()
        _cx.set_context(rt or tenant_id, rw or workspace_id)
        try:
            detail = open_service.task_detail(tid)
        finally:
            _cx.restore(_saved)
    except Exception:
        logging.getLogger(__name__).warning("开放平台任务详情失败", exc_info=True)
        return None, (404, {"error": "任务不存在", "code": "not_found"})
    if not detail or detail.get("error"):
        return None, (404, {"error": "任务不存在", "code": "not_found"})
    return detail, None


def get_open_event_detail(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _u = handler._session_user() or {}
    if (_u.get("role") or "") not in ("super_admin", "platform_op"):
        return handler._err(403, "仅系统管理员/平台管理员可查看投递详情", "forbidden")
    _eid = p.split("/")[-1]
    _detail = open_service.event_detail(_eid, _u)
    if not _detail:
        return handler._err(404, "事件不存在", "not_found")
    return handler._send(200, handler._json(_detail))

def get_open_apps(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    return handler._send(200, handler._json(open_service.list_apps()))

def get_open_events(handler, q):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    return handler._send(200, handler._json(open_service.list_events(
        status=q.get("status", [""])[0], app_key=q.get("app", [""])[0], limit=100)))

def get_open_sandbox(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    return handler._send(200, handler._json(open_service.list_sandbox()))

def get_open_task_detail(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    tid = p.split("/")[-1]
    ok, _app, why = open_service.verify(handler.headers.get("X-App-Key", ""),
                                        handler.headers.get("X-Timestamp", ""),
                                        handler.headers.get("X-Nonce", ""), b"",
                                        handler.headers.get("X-Signature", ""))
    if not ok:
        return handler._send(401, handler._json({"error": why, "code": "invalid_signature"}))
    # 签名只证明调用方是某个应用；任务必须属于该应用的租户/空间，否则按不存在处理。
    _detail, _deny = open_task_detail_scoped(
        tid, str((_app or {}).get("tenant_id") or ""),
        str((_app or {}).get("workspace_id") or ""), strict_workspace=False)
    if _deny:
        return handler._send_deny(_deny)
    return handler._send(200, handler._json(_detail))

def post_open_tasks(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    raw = handler._body_raw()
    ok, app, why = open_service.verify(handler.headers.get("X-App-Key", ""),
                                       handler.headers.get("X-Timestamp", ""),
                                       handler.headers.get("X-Nonce", ""), raw,
                                       handler.headers.get("X-Signature", ""))
    if not ok:
        return handler._send(401, handler._json({"error": why, "code": "invalid_signature"}))
    payload = json.loads(raw.decode("utf-8")) if raw else {}
    return handler._send(200, handler._json(open_service.accept_task(app, payload)))

def post_open_deliver(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    return handler._send(200, handler._json(open_service.deliver_pending()))

def post_open_sandbox(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 沙箱接收端：公开路径，但只有“可验证签名 + 大小/保留期受限”的请求才落库。
    if getattr(handler, "_body_too_large", False):
        _cap = int(getattr(handler, "_body_limit_hit", 0) or open_service.MAX_SANDBOX_BODY_BYTES)
        return handler._send(413, handler._json(
            {"ok": False, "valid": False, "stored": False, "code": "payload_too_large",
             "reason": f"body 超过沙箱 {max(1, _cap // 1024)}KB 上限"}))
    body = handler._body_raw()
    _result = open_service.receive_sandbox(dict(handler.headers), body)
    _status = int(_result.pop("http_status", 200) or 200)
    return handler._send(_status, handler._json(_result))

def post_open_app_test(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    aid = p.split("/")[-2]
    _app, _deny = open_app_scope(aid, handler._session_user() or {})
    if _deny:
        return handler._send_deny(_deny)
    return handler._send(200, handler._json(open_service.send_test_event(aid)))

def post_open_app_rotate(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    aid = p.split("/")[-2]
    _app, _deny = open_app_scope(aid, handler._session_user() or {})
    if _deny:
        return handler._send_deny(_deny)
    return handler._send(200, handler._json(open_service.rotate_secret(aid)))

def post_open_app_update(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    aid = p.split("/")[-2]
    # 先做对象作用域（不存在 404、跨空间 403），再做请求体校验。
    _app, _deny = open_app_scope(aid, handler._session_user() or {})
    if _deny:
        return handler._send_deny(_deny)
    b = handler._body()
    _cb2 = str(b.get("callback_url") or "")
    if _cb2:
        _ok2, _why2 = open_callback_ok(_cb2)
        if not _ok2:
            return handler._err(400, "callback_url 不被允许：" + _why2, "invalid_url")
    return handler._send(200, handler._json(open_service.update_app(
        aid, b.get("name", ""), _cb2, b.get("events", ""), b.get("status", ""))))

def post_open_apps(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    b = handler._body()
    _cb = str(b.get("callback_url") or "")
    if b.get("sandbox") and not _cb:
        _cb = f"http://127.0.0.1:{handler.server.server_port}/api/v1/open/sandbox"
    if _cb:
        _okc, _whyc = open_callback_ok(_cb)
        if not _okc:
            return handler._err(400, "callback_url 不被允许：" + _whyc, "invalid_url")
    # DU-15：审计 actor = 当前会话真实用户（旧实现服务层硬编码 "admin"）。
    _u_app = handler._session_user() or {}
    return handler._send(200, handler._json(open_service.create_app(
        b.get("name", ""), _cb, b.get("events", "audit.completed"),
        actor=str(_u_app.get("sub") or ""))))
