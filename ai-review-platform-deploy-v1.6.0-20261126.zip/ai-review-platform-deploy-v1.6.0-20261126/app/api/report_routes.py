"""报告读取/生成/签发/导出路由：从 server.py 抽出的报告域。

所有权和门禁由 handler 传入，避免路由模块直接依赖 Handler。
L94（2026-11-24）：新增签发/导出 **POST 入口**（``post_entry``），并把既有 GET
报告导出强制走服务层严格入口 ``report.export_report``（审计/回执/门禁/职责分离
不再由路由各写一套）。
"""
from __future__ import annotations
import hashlib
import json
import logging

from .. import repositories as R
from ..services import report, review
from ..services import permissions as _perms

log = logging.getLogger(__name__)

_JSON = "application/json; charset=utf-8"
_HTML = "text/html; charset=utf-8"
_DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

# L94：签发/导出入口的机读错误码（HTTP 与 CLI 同源；CLI 按 status 映射分类退出码）
ENTRY_ERR_NOT_REVIEWER = "forbidden"
ENTRY_ERR_NOT_FOUND = "not_found"
ENTRY_ERR_NOT_GENERATED = "report_not_generated"
ENTRY_ERR_NOT_SIGNED = "report_not_signed"
ENTRY_ERR_HASH = "content_hash_mismatch"
ENTRY_ERR_TRANSITION = "invalid_transition"


def _audit_export(cid: str, fmt: str, actor: str = "") -> None:
    """裁决台账 CSV 导出留痕（报告 html/docx 已改由 ``report.export_report`` 写审计）。

    写 ``report.exported``（成功导出后才写，失败不写）；动作名含 'export' 便于审计页
    按「导出」维度筛选。审计失败只告警，不把已成功的导出变成失败响应（导出已完成，
    不能回滚已发给客户的内容），但必须可见（铁律 2）。
    """
    try:
        _ver = ""
        try:
            rows = R.reports.list("case_id=?", (cid,), order="exported_at DESC")
            _ver = str((rows[0] or {}).get("version") or "") if rows else ""
        except Exception:
            _ver = ""
        R.audit_logs.log(actor=actor or "system", action="report.exported", object=cid,
                         after=json.dumps(
                             {"format": fmt, "version": _ver, "case_id": cid},
                             ensure_ascii=False))
    except Exception:
        log.warning("report.exported audit skipped cid=%s fmt=%s", cid, fmt, exc_info=True)


def _route_error(exc: BaseException) -> tuple[int, dict]:
    """L94：报告服务层异常 → 路由错误响应（错误码 HTTP/CLI 同源）。"""
    status = int(getattr(exc, "status", 0) or 0)
    code = str(getattr(exc, "code", "") or "")
    if isinstance(exc, report.ReportPermissionError):
        return status or 403, {"error": str(exc), "code": code or "forbidden"}
    if isinstance(exc, report.ReportGateError):
        return status or 409, {"error": str(exc), "code": code or "report_blocked"}
    if isinstance(exc, ValueError):
        return 409, {"error": str(exc), "code": code or "report_blocked"}
    log.error("report route internal error", exc_info=True)
    return 500, {"error": "报告服务内部错误", "code": "internal_error"}


def _unauth(user: dict) -> bool:
    return not (str((user or {}).get("sub") or "").strip()
                or str((user or {}).get("role") or "").strip())


def get(path: str, cid: str, owned: bool, gate=None, actor: str = "", role: str = ""):
    if not owned:
        return 403, {"error": "无权访问他人案例", "code": "forbidden"}, _JSON
    if path.endswith("/report-status"):
        return 200, report.status(cid), _JSON
    if path.endswith(("/report.docx", "/report.html")):
        if gate:
            return gate
        fmt = "docx" if path.endswith("/report.docx") else "html"
        if role:
            # L94：HTTP 真实导出路径（server 传入会话 role）强制走服务层严格入口
            # （职责分离 + 门禁 + L87 审计状态 + 导出回执/`report.exported` 审计一次写全），
            # 不再在路由层直出 build_report_*。
            try:
                body = report.export_report(cid, fmt, actor=actor, role=role)
            except Exception as exc:  # noqa: BLE001 —— 服务层错误按同源码返回
                status, payload = _route_error(exc)
                return status, payload, _JSON
        else:
            # 兼容历史直接调用方（单元测试/旧内部调用只传 actor，由调用方自行完成门禁）：
            # 保持原“渲染 + report.exported 留痕”契约；HTTP 入口永远不会走到这里
            # （server.py 从会话解析 role 后必传）。不新增放行：无 role 即非产品导出路径。
            body = (report.build_report_docx(cid) if fmt == "docx"
                    else report.build_report_html(cid))
            _audit_export(cid, fmt, actor)
        if fmt == "docx":
            return 200, body, _DOCX
        if isinstance(body, (bytes, bytearray)):
            body = bytes(body).decode("utf-8", "replace")
        return 200, body.encode("utf-8"), _HTML
    if path.endswith("/report.pdf"):
        # T-81 D-03：PDF 报告导出已移除（产品口径，与 CLI `report --format pdf` 一致）。
        # 路由层不再调用 report.build_report_pdf，也不依赖 LibreOffice 环境；
        # 统一显式 403 pdf_export_removed，绝不产出 application/pdf。
        return 403, {"error": "PDF 报告导出已移除；请导出 DOCX 或 HTML",
                     "code": "pdf_export_removed"}, _JSON
    if path.startswith("/api/v1/reviews/"):
        return 200, review.case_report(cid), _JSON
    return None


def post_entry(action: str, report_id: str, case_id: str, user: dict,
               body: dict | None = None, q: dict | None = None):
    """L94：POST /api/v1/reports/{id}/(sign|export) 统一入口。

    权限（与 GET 报告导出同一口径）：仅 reviewer 本人项目；业务管理员/系统管理员/
    平台运营 → 403；跨租户 → 404、他人项目 → 403（由 server._report_scope 先判）。
    审计：签发 → ``report.signed``、导出 → ``report.exported``（服务层同事务写）。
    幂等：重复签发返回 already_signed=True，不重复写审计。
    错误码：report_not_generated（0 报告行）/ report_not_signed（导出未签发）/
    content_hash_mismatch（hash 与生成时不一致）/ invalid_transition（状态机非法）。
    """
    action = str(action or "").strip().lower()
    if action not in ("sign", "export"):
        return 404, {"error": "接口不存在", "code": ENTRY_ERR_NOT_FOUND}, _JSON
    user = user or {}
    body = body or {}
    if _unauth(user):
        return 401, {"error": "报告签发/导出需要认证身份", "code": "unauthorized"}, _JSON
    actor = str(user.get("sub") or "").strip()
    role = str(user.get("role") or "").strip()
    # 角色口径与 GET /reviews/{cid}/report.docx|html、CLI `report` 完全一致（reviewer-only）。
    if role != "reviewer":
        verb = "签发" if action == "sign" else "导出"
        return 403, {"error": f"报告{verb}仅审核员可执行", "code": ENTRY_ERR_NOT_REVIEWER}, _JSON
    if not str(case_id or "").strip():
        return 404, {"error": "报告不存在", "code": ENTRY_ERR_NOT_FOUND}, _JSON
    rid = str(report_id or "").strip()
    row = R.reports.get(rid) if rid else None

    if action == "sign":
        expected = str(body.get("content_hash") or "").strip()
        if row is not None and expected:
            actual = str(row.get("content_hash") or "")
            # 客户端期望 hash 与当前行不一致：多半不是最新版本或内容已被篡改，先拒绝。
            if not actual or actual != expected:
                return 409, {
                    "error": "content_hash 与当前报告行不一致（可能不是最新版本或内容被篡改），拒绝签发",
                    "code": ENTRY_ERR_HASH, "expected": actual}, _JSON
        note = str(body.get("note") or "")
        try:
            out = report.sign_report(case_id, actor=actor, role=role, note=note,
                                     report_id=rid if row is not None else "")
        except Exception as exc:  # noqa: BLE001 —— 统一错误码映射
            status, payload = _route_error(exc)
            return status, payload, _JSON
        payload = dict(out or {})
        payload.update({"ok": True, "action": "sign", "case_id": case_id,
                        "report_id": payload.get("report_id") or rid})
        return 200, payload, _JSON

    # ---- export ----
    fmt = str(body.get("format") or "").strip().lower()
    if not fmt:
        try:
            fmt = str(((q or {}).get("format") or ["html"])[0] or "html").strip().lower()
        except Exception:  # noqa: BLE001
            fmt = "html"
    if fmt == "pdf":
        return 403, {"error": "PDF 报告导出已移除；请导出 DOCX 或 HTML",
                     "code": "pdf_export_removed"}, _JSON
    if fmt not in ("html", "docx"):
        return 400, {"error": f"不支持的报告格式：{fmt}（可选 html/docx）",
                     "code": "invalid_request"}, _JSON
    if row is None:
        # 无报告行：可机读错误（区别于“未知报告 id”的 404 由 server 层先判）。
        return 409, {"error": "尚未生成报告，不能导出：请先调用 report.generate 生成报告",
                     "code": ENTRY_ERR_NOT_GENERATED}, _JSON
    if not (str(row.get("signed_by") or "").strip()
            and str(row.get("signed_at") or "").strip()):
        return 409, {"error": "报告尚未签发，不能导出：请先调用报告签发（sign）",
                     "code": ENTRY_ERR_NOT_SIGNED}, _JSON
    if report.verify_content_hash(row) is False:
        return 409, {"error": "报告内容与生成时的 content_hash 不一致（可能被篡改），拒绝导出",
                     "code": ENTRY_ERR_HASH}, _JSON
    try:
        # L94：目标行必须属于本 case 且为当前最新报告行（历史版本导出会造成单据歧义）
        report._target_report_row(case_id, rid)
    except Exception as exc:  # noqa: BLE001
        status, payload = _route_error(exc)
        return status, payload, _JSON
    try:
        content = report.export_report(case_id, fmt, actor=actor, role=role,
                                       report_id=rid)
    except Exception as exc:  # noqa: BLE001
        status, payload = _route_error(exc)
        return status, payload, _JSON
    raw = bytes(content) if isinstance(content, (bytes, bytearray)) else str(content).encode("utf-8")
    headers = {
        "X-Report-Id": str(row.get("id") or rid),
        "X-Report-Version": str(row.get("version") or ""),
        "X-Report-Exported-Hash": "sha256:" + hashlib.sha256(raw).hexdigest(),
    }
    if fmt == "docx":
        headers["Content-Disposition"] = f'attachment; filename="report-{case_id}.docx"'
        return 200, raw, _DOCX, headers
    headers["Content-Disposition"] = f'attachment; filename="report-{case_id}.html"'
    return 200, raw, _HTML, headers


def adjudication_get(path: str, cid: str, q: dict, owned: bool = True,
                     actor: str = ""):
    """L80 / P0-C 只读接口（89 号 §6.1）：逐行台账 + 统计（CLI/HTTP 同源）。

    权限：与报告导出同权——调用方（server.py）已做 ``_case_scope``（跨租户 404 /
    他人项目 403 / 超管平台运营 403）；本函数再做一道 owned 兜底。
    审计：读接口不写审计（与现有只读查询同口径）；导出（CLI export / format=csv）
    在服务层写 ``report.exported``。
    """
    if not owned:
        return 403, {"error": "无权访问他人案例", "code": "forbidden"}, _JSON
    from ..services import adjudication_ledger as _adj
    try:
        _sw = _adj.validate_switches()
    except ValueError as e:
        return 409, {"error": str(e), "code": "invalid_switch_combo"}, _JSON
    if not _sw.get("ledger"):
        return 409, {"error": "裁决来源台账未启用（RULEPROOF_ADJUDICATION_LEDGER=0）",
                     "code": "ledger_disabled"}, _JSON
    run_id = str((q.get("run_id") or [""])[0] or "").strip()
    if path.endswith("/adjudication-ledger"):
        fmt = str((q.get("format") or ["json"])[0] or "json").strip().lower()
        try:
            limit = int((q.get("limit") or ["200"])[0] or 200)
            offset = int((q.get("offset") or ["0"])[0] or 0)
        except (TypeError, ValueError):
            return 400, {"error": "limit/offset 必须是整数", "code": "invalid_request"}, _JSON
        data = _adj.ledger_rows(case_id=cid, run_id=run_id, limit=limit, offset=offset)
        if not data.get("ok"):
            return 404, {"error": data.get("error") or "台账不可用",
                         "code": data.get("code") or "not_found"}, _JSON
        if fmt == "csv":
            # CSV 直出（与 CLI/导出同列序）；审计由 report.exported 口径在服务层记录
            body = _adj.rows_to_csv(data.get("rows") or []).encode("utf-8")
            try:
                _audit_export(cid, "adjudication_ledger_csv", actor)
            except Exception:
                log.warning("adjudication csv export audit skipped cid=%s", cid)
            return 200, body, "text/csv; charset=utf-8"
        return 200, data, _JSON
    # /adjudication-stats
    group_by = str((q.get("group_by") or [""])[0] or "")
    stats = _adj.ledger_stats(case_id=cid, run_id=run_id, group_by=group_by)
    if not stats.get("ok"):
        return 409, {"error": stats.get("error") or "统计不可用",
                     "code": stats.get("code") or "stats_unavailable"}, _JSON
    return 200, stats, _JSON


def adjudication_run_stats(run_id: str, q: dict, actor: str = ""):
    """GET /api/v1/runs/{run_id}/adjudication-stats（run 级统计；CLI 同源）。"""
    from .. import db as _db
    try:
        with _db.session() as c:
            row = c.execute("SELECT case_id FROM audit_run WHERE id=?",
                            (str(run_id or ""),)).fetchone()
        case_id = str((row["case_id"] if row else "") or "")
    except Exception:
        case_id = ""
    if not case_id:
        return 404, {"error": "审核批次不存在", "code": "not_found"}, _JSON
    from ..services import adjudication_ledger as _adj
    try:
        _sw = _adj.validate_switches()
    except ValueError as e:
        return 409, {"error": str(e), "code": "invalid_switch_combo"}, _JSON
    if not _sw.get("ledger"):
        return 409, {"error": "裁决来源台账未启用（RULEPROOF_ADJUDICATION_LEDGER=0）",
                     "code": "ledger_disabled"}, _JSON
    group_by = str((q.get("group_by") or [""])[0] or "")
    stats = _adj.ledger_stats(case_id=case_id, run_id=run_id, group_by=group_by)
    if not stats.get("ok"):
        return 409, {"error": stats.get("error") or "统计不可用",
                     "code": stats.get("code") or "stats_unavailable"}, _JSON
    return 200, stats, _JSON


def post_generate(path: str, cid: str, user: dict, owned: bool):
    if not R.cases.get(cid):
        return 404, {"error": "案例不存在", "code": "not_found"}, _JSON
    if not owned:
        return 403, {"error": "无权访问他人案例", "code": "forbidden"}, _JSON
    # T-199：报告生成/导出权限点第二道（旧 report.export 死权限点接线）；
    # 角色口径仍是 reviewer-only（report.generate 内还有职责分离校验）。
    if not _perms.has((user or {}).get("sub", ""), "report.export"):
        return 403, {"error": "无权限（需 report.export）", "code": "forbidden"}, _JSON
    try:
        return 200, report.generate(cid, (user or {}).get("sub", "")), _JSON
    except report.ReportPermissionError as e:
        # 职责/身份越权是 401/403；只有“报告门禁未通过”才是 409。
        return int(getattr(e, "status", 403) or 403), {"error": str(e),
                "code": getattr(e, "code", "forbidden") or "forbidden"}, _JSON
    except ValueError as e:
        # L77：ReportGateError 带具体门禁错误码（如 audit_write_failed）时透传；
        # 其它 ValueError 保持既有 report_blocked 契约。
        return 409, {"error": str(e),
                     "code": str(getattr(e, "code", "") or "report_blocked")}, _JSON
