"""页面操作助手 HTTP 适配：只读页面知识 + 单次受限模型问答。"""
from __future__ import annotations
from ..services import page_guide as _pg


def get_context(user, query):
    page = ""
    try:
        v = query.get("page") if isinstance(query, dict) else ""
        page = v if isinstance(v, str) else (v[0] if v else "")
    except Exception:
        page = ""
    return _pg.context(page, user)


def post_chat(user, body):
    body = body or {}
    return _pg.chat(body.get("page") or "", user, body.get("message") or "")
