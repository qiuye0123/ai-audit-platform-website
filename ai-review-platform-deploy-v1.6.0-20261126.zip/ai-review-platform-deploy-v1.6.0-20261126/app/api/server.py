"""REST API 层 + 静态前端服务。"""
import base64
import hashlib
import json
import logging
import os
import sys
import tempfile
import threading
from pathlib import Path
import time
import urllib.parse
import uuid
from html import escape as _esc_html
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app import config, db, auth, obs  # noqa: E402
from app import repositories as R  # noqa: E402
MAX_FILE_BYTES = 100 * 1024 * 1024  # 单份文件上限 100MB
from app.api import http_guard as _hg  # noqa: E402  # P2-05/08/15/16 横切逻辑
MAX_BODY_BYTES_DEFAULT = _hg.MAX_UPLOAD_BODY_BYTES_DEFAULT  # 兼容旧常量（上传上限）
from app.services import review, rule, feedback, ruleparam, scheduler, replay, qa_sample, decision_table, schema_check, pstates, rsi_protocol, conflict, eval_service, evolution, report, stats, compare, notify, ontology_service, auditpoints, model, extract, calibration, home, project, account  # noqa: E402
from app.services import open as open_service  # noqa: E402
from app.services import audit  # noqa: E402
from app.services import export as export_service  # noqa: E402
from app.services import task, permission, sysconfig, agents  # noqa: E402
from app.services import secret_box  # noqa: E402  # L147 P0-2/P0-3 静态加密与密钥脱敏
from app.engine import engine, stdcheck, rexec, docparse, judge, llm, ocr, deepparse, factreview  # noqa: E402
from app.engine import rules_meta  # noqa: E402
# T-201：/metrics（Prometheus 文本）与 /health 依赖状态的路由模块；server.py 只做注册。
from app.api import metrics_routes as _metrics_routes  # noqa: E402
# T-203 影子池 Phase2：GET/POST /api/v1/projects/{cid}/shadow-items* 与 /api/v1/shadow-items/escalate。
# handle() 自带 guard/权限/错误码（仅 import 服务层，无循环 import）；server.py 只做 2 处注册。
from app.api import shadow_routes as _shadow_routes  # noqa: E402
# T-203 第一批：审核主链 / 本体 / 开放平台三段的处理体已物理移入 *_routes.py；
# server.py 只保留原位置的分发谓词 + 一行委托（顺序/优先级与拆分前完全一致）。
from app.api import review_routes as _review_routes  # noqa: E402
from app.api import ontology_routes as _ontology_routes  # noqa: E402
from app.api import open_routes as _open_routes  # noqa: E402

# ---------------------------------------------------------------------------
# L147（2026-11-25，P0-2/P0-3 最小整改）：传输与静态加密开关的唯一边界。
# 说明：这些 helper 是纯函数（只读环境变量/服务状态，不写库），便于被测试直接导入；
# 生产建议与密钥托管见 docs/qa/安全整改_20261125.md。
# ---------------------------------------------------------------------------
_TRUE_FLAGS = ("1", "true", "yes", "on")
_FALSE_FLAGS = ("0", "false", "no", "off")
_TLS_WARN = {"last": 0.0}


def _is_prod_env() -> bool:
    """生产环境判定（与 app.auth._is_prod 同口径，避免循环依赖直接复制）。"""
    return (os.environ.get("RULEPROOF_ENV") or "").strip().lower() in ("prod", "production")


def _cookie_secure_enabled() -> bool:
    """会话/state Cookie 是否加 ``Secure``。

    规则（P0-3）：
    - 显式 ``RULEPROOF_COOKIE_SECURE=1/0`` 优先；显式 0 仅用于临时 HTTP 排障，
      prod 下启动会 WARN；
    - 未显式配置时：**prod 默认强制 True**；开发/测试环境保持历史默认 False
      （不改变测试环境行为）。
    """
    raw = (os.environ.get("RULEPROOF_COOKIE_SECURE") or "").strip().lower()
    if raw in _TRUE_FLAGS:
        return True
    if raw in _FALSE_FLAGS:
        return False
    return _is_prod_env()


def _cookie_secure_attr() -> str:
    return "; Secure" if _cookie_secure_enabled() else ""


def _warn_if_plaintext_http(headers=None, logger=None) -> None:
    """prod 下请求不是 HTTPS（且无 ``X-Forwarded-Proto: https``）时显式 WARN。

    本服务自身只监听明文 HTTP（标准库 ThreadingHTTPServer，无 ssl context）；
    TLS 必须由反向代理（nginx/caddy）终止后转发。这里只告警不阻断（阻断会直接
    导致无法登录），并做 300s 限流避免刷日志。开发/测试环境不告警。
    """
    if not _is_prod_env():
        return
    proto = ""
    try:
        if headers is not None:
            proto = str(headers.get("X-Forwarded-Proto") or "").strip().lower()
    except Exception:
        proto = ""
    if proto == "https":
        return
    now = time.time()
    if now - float(_TLS_WARN.get("last") or 0) < 300:
        return
    _TLS_WARN["last"] = now
    (logger or logging.getLogger(__name__)).warning(
        "security-tls: 生产环境收到明文 HTTP 请求（X-Forwarded-Proto=%r）；本服务不做 TLS 终止，"
        "必须由反向代理终止 HTTPS 并转发（见 docs/qa/安全整改_20261125.md）；Cookie Secure=%s",
        proto or "-", _cookie_secure_enabled())


def _seal_model_api_key(value: str) -> str:
    """写入 ``model_config.api_key`` 前的加密（开关开启时；关闭/空值原样返回）。"""
    raw = str(value or "")
    if not raw or not secret_box.model_key_encrypt_enabled():
        return raw
    return secret_box.seal_model_api_key(raw)


def _scrub_model_key_masks(payload: dict) -> dict:
    """模型列表响应脱敏加固：api_key_masked 不得出现密文/明文片段。"""
    try:
        for item in (payload or {}).get("items") or []:
            raw = str(item.get("api_key_masked") or "")
            if "enc1:" in raw or secret_box.is_sealed(raw):
                item["api_key_masked"] = "已加密（不可显示）"
    except Exception:
        logging.getLogger(__name__).debug("model key mask scrub skipped", exc_info=True)
    return payload


def security_static_encryption_status() -> dict:
    """P0-2/P0-3 状态汇总（运维/测试读取；不含任何密钥/口令/密文）。"""
    try:
        from app.services import db_backup as _bk
        backup = _bk.backup_encryption_status()
    except Exception as e:  # noqa: BLE001 - 状态接口不得因单模块异常整体失败
        backup = {"error": f"{type(e).__name__}: {e}"}
    try:
        model_key = {
            "switch": secret_box.model_key_encrypt_enabled(),
            "readpath_wired": secret_box.model_key_readpath_wired(),
            "master_key": secret_box.master_key_status(),
        }
    except Exception as e:  # noqa: BLE001
        model_key = {"error": f"{type(e).__name__}: {e}"}
    return {
        "cookie_secure": _cookie_secure_enabled(),
        "prod": _is_prod_env(),
        "tls_termination": "external-required",
        "backup_encryption": backup,
        "model_key_encryption": model_key,
        "file_encryption": secret_box.file_crypto_status(),
        # L150 / L140 A-05：审计 append-only 触发器状态（只读；缺失只 WARN，不自动建）
        "audit_append_only": _audit_append_only_status(),
    }


def _audit_append_only_status(db_path=None) -> dict:
    """审计 append-only 状态（只读；供启动自检/状态接口统一取数）。

    L150：把 ``db.audit_append_only_status()`` 的只读探测包一层兜底——状态查询本身
    失败不得让启动/状态接口崩溃；失败返回 ``status=error``（调用方 WARN）。
    """
    try:
        return db.audit_append_only_status(db_path)
    except Exception as exc:  # noqa: BLE001 - 自检失败要显式报告，不阻断启动
        return {"checked": False, "status": "error", "enabled": None,
                "triggers": [], "missing": list(db.AUDIT_APPEND_ONLY_TRIGGERS),
                "db": str(db_path or db.DB_PATH),
                "error": "%s: %s" % (type(exc).__name__, exc),
                "note": "append-only 状态自检失败（只读检查，不改 schema）"}


def _log_security_startup_warnings() -> None:
    """启动期安全配置自检（只 WARN，不改变启动结果；prod 明文降级会明确提示）。"""
    log = logging.getLogger(__name__)
    if _is_prod_env():
        raw = (os.environ.get("RULEPROOF_COOKIE_SECURE") or "").strip().lower()
        if raw in _FALSE_FLAGS:
            log.warning("security-cookie: prod 显式关闭 Cookie Secure（RULEPROOF_COOKIE_SECURE=0）："
                        "仅允许临时明文排障，必须尽快恢复并确保反代 TLS")
        else:
            log.warning("security-tls: prod 会话 Cookie 已强制 Secure；本服务监听明文 HTTP，"
                        "TLS 必须由反向代理终止（未见反代配置时登录将不可用）")
    try:
        from app.services import db_backup as _bk
        _bk.backup_encryption_status()   # 内部按需 WARN（prod 未加密/缺工具/缺口令）
    except Exception:
        log.debug("backup encryption startup check skipped", exc_info=True)
    if secret_box.model_key_encrypt_enabled():
        if not secret_box.model_key_readpath_wired():
            log.warning("security-model-key: RULEPROOF_MODEL_KEY_ENCRYPT=1 但运行时读路径未接线"
                        "（RULEPROOF_MODEL_KEY_READPATH!=1）：禁止迁移 api_key，"
                        "否则模型调用会 401（见 docs/qa/安全整改_20261125.md）")
        else:
            log.info("security-model-key: model_config.api_key 加密已开启且读路径已声明接线")
    elif _is_prod_env():
        log.warning("security-model-key: prod 未开启 model_config.api_key 加密"
                    "（RULEPROOF_MODEL_KEY_ENCRYPT=0）：API Key 仍明文入库，建议迁移后置 1")
    # L150 / L140 A-05：审计 append-only 触发器启动自检（只读，不 install）。
    # 升级库历史上没有触发器（L140 实测产品库 0 个），必须显式 `rp db migrate` 安装
    # 20261125_004_l109_audit_append_only；本自检只在缺失时 WARN + 结构化状态可查，
    # 不阻断启动、也绝不自动建触发器/改 schema。
    try:
        status = _audit_append_only_status()
        if status.get("checked") and status.get("enabled"):
            obs.log_event("security.audit_append_only", module="api.server", level="info",
                          status="pass", db=status.get("db"),
                          triggers=status.get("triggers"), audit_rows=status.get("audit_rows"))
        elif status.get("status") == "db_missing":
            # 新库首次启动（init_db 尚未执行）：无触发器可查，迁移会在 fresh init 时安装。
            log.info("security-audit-append-only: 库尚未创建（%s），启动初始化后由迁移安装触发器",
                     status.get("db"))
        else:
            obs.log_event("security.audit_append_only", module="api.server", level="warning",
                          status=status.get("status") or "warn",
                          db=status.get("db"), missing=status.get("missing"),
                          triggers=status.get("triggers"),
                          audit_rows=status.get("audit_rows"),
                          error=status.get("error") or "",
                          note="audit_log 缺少 append-only 触发器：审计行可被 UPDATE/DELETE；"
                               "执行 `rp db migrate` 安装 20261125_004_l109_audit_append_only"
                               "（本服务不自动建触发器/不改 schema）")
    except Exception:  # noqa: BLE001 - 自检失败不得阻断启动
        log.warning("审计 append-only 启动自检失败（不阻断启动）", exc_info=True)


WEB = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "web")

_idem_scope, _idem_get, _idem_put = _hg.idem_scope, _hg.idem_get, _hg.idem_put

_PUBLIC_GET = {"/", "/index.html", "/style.css", "/app.js", "/login_bg.js", "/dict_view.js", "/login", "/login.css",
               "/admin", "/admin/system", "/admin/business", "/admin/business/tenant-config", "/tenant-config",
               "/admin/login", "/admin.html",
               "/admin/system/login", "/admin/business/login", "/login-admin.html",
               "/login-admin-system.html", "/login-admin-business.html",
               "/reviewer", "/reviewer/login", "/reviewer.html", "/login-reviewer.html",
               "/platform", "/platform/login", "/platform.js", "/branding.js", "/tenant_config.js",
               "/settings_drawers.css", "/settings_drawers.js", "/accuracy_board.js", "/ops.js", "/ops.html", "/messages.js", "/decision_tables.js", "/open_platform.js", "/models.js", "/notify_config.js", "/rule_intake.js", "/rule_mining.js", "/rules_view.js", "/rule_detail_view.js", "/new_rule_view.js", "/rule_file_intake.js", "/knowledge_base.js", "/projects_view.js", "/project_detail_view.js", "/workbench_view.js", "/workbench_edit_view.js", "/workbench_locate.js", "/workbench_report.js", "/workbench_preview.js", "/audit_progress.js", "/new_project_view.js", "/finding_list_view.js",  "/login-platform.html",
               "/callback", "/logout", "/mock-oidc/authorize", "/health", "/api/v1/me",
               "/login/sso", "/auth/sso",
               "/system-map", "/system_map.html", "/ops", "/ops.js", "/page_guide.js", "/page_guide.css",
               "/api/v1/public/tenant-branding"}
_ADMIN_GET = {"/api/v1/feedback", "/api/v1/errorbook", "/api/v1/dashboard", "/api/v1/users", "/api/v1/open/apps", "/api/v1/open/events", "/api/v1/open/sandbox", "/api/v1/audit-logs",
              "/api/v1/eval", "/api/v1/eval/multi", "/api/v1/reviews"}
_ADMIN_GET_PREFIX = ["/api/v1/audit/", "/api/v1/model/", "/api/v1/models"]
_ADMIN_POST = {"/api/v1/sediment", "/api/v1/users"}
_ADMIN_POST_PREFIX = ["/api/v1/ontology/", "/api/v1/model/", "/api/v1/models",
                      "/api/v1/users/", "/api/v1/open/"]
_PUBLIC_POST = {"/api/v1/auth/login", "/open/v1/tasks", "/api/v1/open/sandbox"}
# S3：租户停用/过期拒绝审计的限流状态（进程内，只为防刷库；拒绝本身不依赖它）
_TENANT_DENY_LOCK = threading.Lock()
_TENANT_DENY_SEEN: dict = {}

# 系统管理员业务边界（白名单反向判定）与业务写第二道角色校验统一放在
# app/api/role_scope.py（F-28）：server.py 只保留 dispatch 与调用点。
from app.api.role_scope import (  # noqa: E402
    business_write_denied as _business_write_denied_impl,
    feedback_scope as _feedback_scope_impl,
    is_get_write_path as _is_get_write_path,
    super_admin_denied as _super_admin_denied,
)

# T-43 人工复核闭环路由（展示项 100% 复核 / 人工漏报 / 后台对账）。
# 路径与权限都收敛到 app.services.human_review（CLI 调同一批服务函数）：
#   GET  /api/v1/projects/{cid}/human-review         工作台队列（不含隐藏项内容）
#   GET  /api/v1/projects/{cid}/human-review/backend 后台对账/审计（抑制台账+反馈候选）
#   GET  /api/v1/projects/{cid}/omissions            人工漏报列表
#   POST /api/v1/projects/{cid}/human-review/decide  展示项裁决
#   POST /api/v1/projects/{cid}/omissions            登记人工漏报（位置/问题/证据/actor）
#   POST /api/v1/projects/{cid}/omissions/reconcile  后台四类对账
_HUMAN_REVIEW_GET = {"human-review": "status", "omissions": "omissions"}
_HUMAN_REVIEW_GET_SUB = {("human-review", "backend"): "backend"}
_HUMAN_REVIEW_POST = {"human-review/decide": "decide",
                      "human-review/independent": "independent",
                      "omissions": "omission",
                      "omissions/reconcile": "reconcile"}



def _rulegen_dispatch(handler, method: str):
    """P0-5/T-191 D3：规则判据候选池路由（/api/v1/rules/suggest*）。

    权限/审计/状态机全部在 app.services.rule 服务层（与 CLI 同源）：
      admin 可 suggest/confirm/reject/shadow/publish；reviewer 只读；
      super_admin/platform_op 由 _guard + 服务层双重拒绝（403）。
    返回 True 表示已响应，避免落入通用 rules 路由。
    """
    p = handler.path.split("?")[0].rstrip("/")
    if p != "/api/v1/rules/suggest" and not p.startswith("/api/v1/rules/suggest/"):
        return False
    from app.services import rule as _rgs
    q = {k: v for k, v in (handler._query() or {}).items()}
    body = None
    if str(method).upper() == "POST":
        try:
            body = handler._body() or {}
        except Exception:
            body = {}
    out = _rgs.rulegen_http(str(method), p, q, body, handler._session_user() or {})
    status, payload = out if isinstance(out, tuple) else (200, out)
    handler._send(int(status), handler._json(payload))
    return True


def _human_review_route(path: str, method: str = "GET"):
    """解析 T-43 人工复核路由；非本组路由返回 None（不影响既有 dispatch）。"""
    parts = [x for x in str(path or "").strip("/").split("/") if x]
    if len(parts) < 5 or parts[:3] != ["api", "v1", "projects"]:
        return None
    cid, tail = parts[3], "/".join(parts[4:])
    if str(method or "").upper() == "GET":
        kind = _HUMAN_REVIEW_GET.get(tail) or _HUMAN_REVIEW_GET_SUB.get(
            tuple(parts[4:]))
    else:
        kind = _HUMAN_REVIEW_POST.get(tail)
    return (cid, kind) if kind else None


def _human_review_dispatch(handler, cid: str, kind: str):
    """HTTP 层只做参数适配；权限/租户/审计全部在 human_review 服务层（与 CLI 同源）。"""
    from app.services import human_review as _hrs
    user = handler._session_user() or {}
    actor = str(user.get("sub") or user.get("id") or "")
    role = str(user.get("role") or "")
    body = handler._body() or {} if kind != "status" and kind != "omissions" else {}

    def _send(out):
        status = 200 if out.get("ok") else int(out.get("status") or 400)
        return handler._send(status, handler._json(out))

    if kind == "status":
        q = handler._query() or {}
        include_hidden = _v32_q(q, "include_hidden", "reveal") in (
            "1", "true", "yes", "on")
        return _send(_hrs.case_payload(
            cid, actor=actor, role=role, include_hidden=include_hidden,
            via="http_get" if include_hidden else "http"))
    if kind == "backend":
        return _send(_hrs.backend_view(cid, actor=actor, role=role))
    if kind == "omissions":
        q = handler._query() or {}
        status_filter = _v32_q(q, "status")
        return _send(_hrs.list_omissions(cid, actor=actor, role=role,
                                         status=status_filter))
    if kind == "independent":
        # T-51：evaluation/盲审模式“提交独立复核”（提交后才允许打开隐藏项）
        return _send(_hrs.submit_independent_review(
            cid, actor=actor, role=role,
            note=str(body.get("note") or "")))
    if kind == "decide":
        evidence = body.get("evidence")
        return _send(_hrs.decide_item(
            cid, body.get("item_id") or body.get("id") or "",
            body.get("decision") or body.get("human_status") or "",
            actor=actor, role=role, reason=body.get("reason") or "",
            label=body.get("label") or "",
            evidence=evidence if isinstance(evidence, dict) else None))
    if kind == "omission":
        locator = body.get("locator")
        if isinstance(locator, str):
            locator = {"text": locator}
        return _send(_hrs.submit_omission(
            cid, actor=actor, role=role, quote=body.get("quote") or "",
            issue=body.get("issue") or "", locator=locator,
            rule_hint=body.get("rule_hint") or "",
            subject=body.get("subject") or "",
            object_id=body.get("object_id") or "",
            note=body.get("note") or ""))
    if kind == "reconcile":
        return _send(_hrs.reconcile_case(cid, actor=actor, role=role,
                                         doc_text=str(body.get("doc_text") or "")))
    return handler._err(404, "未知人工复核操作", "not_found")


# ===========================================================================
# T-51（V3.3 增补）人工“显示隐藏疑似问题 (N)”开关路由。
# 权限/模式门禁/租户过滤/审计/进化池钩子全部在 app.services.human_review
# （与 CLI `rp hidden-item` 同一批服务函数，HTTP 只做参数适配）：
#   GET  /api/v1/projects/{cid}/hidden-items            默认关闭：只返回摘要
#   GET  /api/v1/projects/{cid}/hidden-items?include_hidden=1  打开（写 reveal 审计）
#   GET  /api/v1/projects/{cid}/hidden-items/metrics   指标（分模式/来源/原因）
#   POST /api/v1/projects/{cid}/hidden-items/reveal    打开（二次确认 confirm=true）
#   POST /api/v1/projects/{cid}/hidden-items/{id}/{action}
#        action = confirm | reject | request-evidence | recover | merge | rule-error
#   POST /api/v1/projects/{cid}/hidden-items/evolution-defaults   TTL 弱默认处置
#   GET  /api/v1/projects/{cid}/review-mode            复核模式读取
#   POST /api/v1/projects/{cid}/review-mode            模式设置（production/evaluation）
#   GET  /api/v1/hidden-metrics                         跨项目指标（租户/角色过滤）
#   POST /api/v1/projects/{cid}/human-review/independent  提交独立复核（盲审解锁）
# ===========================================================================
_HIDDEN_ACTION_TAILS = {"confirm": "confirm", "reject": "reject",
                        "request-evidence": "request-evidence",
                        "recover": "recover", "merge": "merge",
                        "rule-error": "rule-error"}


def _hidden_toggle_route(path: str, method: str = "GET"):
    """解析 T-51 隐藏开关路由；非本组返回 None（不影响既有 dispatch）。"""
    parts = [x for x in str(path or "").strip("/").split("/") if x]
    if len(parts) < 5 or parts[:3] != ["api", "v1", "projects"]:
        return None
    cid, tail = parts[3], parts[4:]
    if str(method or "").upper() == "GET":
        if tail == ["hidden-items"]:
            return cid, "summary", ""
        if tail == ["hidden-items", "metrics"]:
            return cid, "metrics", ""
        if tail == ["review-mode"]:
            return cid, "mode", ""
        return None
    if tail == ["hidden-items", "reveal"]:
        return cid, "reveal", ""
    if tail == ["hidden-items", "evolution-defaults"]:
        return cid, "evolution_defaults", ""
    if tail == ["review-mode"]:
        return cid, "mode_set", ""
    if len(tail) == 3 and tail[0] == "hidden-items" \
            and tail[2] in _HIDDEN_ACTION_TAILS and tail[1]:
        return cid, _HIDDEN_ACTION_TAILS[tail[2]], tail[1]
    return None


def _hidden_toggle_dispatch(handler, cid: str, kind: str, ident: str = ""):
    """HTTP 薄适配：权限/租户/模式门禁/审计/进化池全部在 human_review 服务层。"""
    from app.services import human_review as _hr
    user = handler._session_user() or {}
    actor = str(user.get("sub") or user.get("id") or "")
    role = str(user.get("role") or "")
    q = handler._query() or {}

    def _send(out):
        status = 200 if out.get("ok") else int(out.get("status") or 400)
        return handler._send(status, handler._json(out))

    if kind == "summary":
        include_hidden = _v32_q(q, "include_hidden", "reveal") in (
            "1", "true", "yes", "on")
        return _send(_hr.hidden_items(
            cid, actor=actor, role=role, include_hidden=include_hidden,
            via="http_get" if include_hidden else "http"))
    if kind == "metrics":
        return _send(_hr.hidden_metrics(case_id=cid, actor=actor, role=role))
    if kind == "reveal":
        body = handler._body() or {}
        if not bool(body.get("confirm")):
            return handler._err(400, "打开隐藏项需要二次确认"
                                "（confirm=true；打开动作将被审计）",
                                "confirm_required")
        return _send(_hr.reveal_hidden(
            cid, actor=actor, role=role, note=str(body.get("note") or ""),
            via="http_post"))
    if kind == "evolution_defaults":
        body = handler._body() or {}
        if not bool(body.get("confirm")):
            return handler._err(400, "应用 TTL 默认处置需要二次确认（confirm=true）",
                                "confirm_required")
        _d = handler._business_write_denied("hidden_items.evolution_defaults")
        if _d:
            return _d
        try:
            ttl_days = int(body.get("ttl_days") or _hr.EVOLUTION_DEFAULT_TTL_DAYS)
        except Exception:  # noqa: BLE001
            ttl_days = _hr.EVOLUTION_DEFAULT_TTL_DAYS
        return _send(_hr.apply_evolution_defaults(
            case_id=cid, actor=actor, role=role, ttl_days=ttl_days,
            dry_run=bool(body.get("dry_run"))))
    if kind in _HIDDEN_ACTION_TAILS.values():
        _d = handler._business_write_denied(f"hidden_items.{kind}")
        if _d:
            return _d
        body = handler._body() or {}
        evidence = body.get("evidence")
        return _send(_hr.hidden_item_action(
            cid, ident, kind, actor=actor, role=role,
            reason=str(body.get("reason") or ""),
            merge_into=str(body.get("merge_into") or body.get("into") or ""),
            evidence=evidence if isinstance(evidence, dict) else None,
            via="http_post"))
    if kind == "mode":
        return _send(_hr.review_mode_get(cid, actor=actor, role=role))
    if kind == "mode_set":
        _d = handler._business_write_denied("hidden_items.review_mode_set")
        if _d:
            return _d
        body = handler._body() or {}
        _force = bool(body.get("force"))
        if _force and not bool(body.get("confirm")):
            return handler._err(
                400, "强制回退复核模式需要二次确认（confirm=true；操作写审计）",
                "confirm_required")
        return _send(_hr.review_mode_set(
            cid, str(body.get("mode") or ""), actor=actor, role=role,
            reason=str(body.get("reason") or ""), force=_force))
    return handler._err(404, "未知隐藏开关操作", "not_found")


def _hidden_metrics_dispatch(handler):
    """跨项目隐藏项指标（租户/角色过滤在服务层；super_admin 由 URL 门禁拒绝）。"""
    from app.services import human_review as _hr
    user = handler._session_user() or {}
    actor = str(user.get("sub") or user.get("id") or "")
    role = str(user.get("role") or "")
    q = handler._query() or {}
    out = _hr.hidden_metrics(
        case_id=_v32_q(q, "case", "case_id"), actor=actor, role=role,
        tenant_id=_v32_q(q, "tenant", "tenant_id"))
    status = 200 if out.get("ok") else int(out.get("status") or 400)
    return handler._send(status, handler._json(out))


# T-50（Qoder W-14）V3.2 双轨数据产品路由：与 CLI 同一批服务函数
# （app.services.human_review），权限/租户/审计全部在服务层，HTTP 只做参数适配。
#   GET  /api/v1/direct-drafts[?case=&run_id=]       直连草稿列表
#   GET  /api/v1/direct-drafts/{id}                  直连草稿详情（不可变原始输出）
#   GET  /api/v1/comparisons[?case=&bucket=&...]     四桶差异列表（审核员仅 visible）
#   GET  /api/v1/comparisons/{id}                    四桶差异详情
#   GET  /api/v1/visibility?case=                    可见性策略应用状态
#   GET  /api/v1/suppression-ledger[?case=&status=]  抑制台账（管理员完整/审核员脱敏）
#   GET  /api/v1/suppression-ledger/{id}             台账详情
#   POST /api/v1/suppression-ledger/{id}/recover     人工恢复（写审计 + 写回 finding）
#   GET  /api/v1/human-omissions[?case=&status=]     人工漏报列表
#   GET  /api/v1/human-omissions/{id}                人工漏报详情
#   POST /api/v1/human-omissions                     登记人工漏报（位置/问题/证据/actor）
_V32_ROUTES = (
    ("/api/v1/direct-drafts", "direct-drafts"),
    ("/api/v1/comparisons", "comparisons"),
    ("/api/v1/visibility", "visibility"),
    ("/api/v1/suppression-ledger", "suppression-ledger"),
    ("/api/v1/human-omissions", "human-omissions"),
)


def _v32_route(path: str):
    """解析 V3.2 产品数据路由；非本组返回 None（不影响既有 dispatch）。"""
    p = str(path or "").strip()
    if len(p) > 1 and p.endswith("/"):
        p = p.rstrip("/")
    for base, res in _V32_ROUTES:
        if p == base:
            return res, "list", ""
        if p.startswith(base + "/"):
            parts = [x for x in p[len(base) + 1:].split("/") if x]
            if not parts:
                return res, "list", ""
            if res == "suppression-ledger" and len(parts) == 2 and parts[1] == "recover":
                return res, "recover", parts[0]
            if len(parts) == 1:
                return res, "show", parts[0]
            return res, "invalid", "/".join(parts)
    return None


def _v32_q(q, *names) -> str:
    """取 query 第一个非空值；兼容 _query() 的扁平 dict 与 parse_qs 的 list。"""
    for name in names:
        val = q.get(name)
        if isinstance(val, (list, tuple)):
            val = val[0] if val else ""
        if str(val or "").strip():
            return str(val).strip()
    return ""


def _v32_dispatch(handler, route, method: str = "GET"):
    """HTTP 薄适配：权限/租户/审计在 human_review 服务层（HTTP/CLI/report_gate 同源）。"""
    from app.services import human_review as _hr
    res, action, ident = route
    user = handler._session_user() or {}
    actor = str(user.get("sub") or user.get("id") or "")
    role = str(user.get("role") or "")
    q = handler._query() or {}

    def _send(out):
        status = 200 if out.get("ok") else int(out.get("status") or 400)
        return handler._send(status, handler._json(out))

    if str(method or "").upper() == "POST":
        body = handler._body() or {}
        if res == "suppression-ledger" and action == "recover":
            _d = handler._business_write_denied("suppression_ledger.recover")
            if _d:
                return _d
            return _send(_hr.ledger_recover(
                ledger_id=ident, actor=actor, role=role,
                reason=str(body.get("reason") or "")))
        if res == "human-omissions" and action == "list":
            _d = handler._business_write_denied("human_omission.add")
            if _d:
                return _d
            cid = str(body.get("case_id") or body.get("case") or "").strip()
            _case, deny = handler._case_scope(cid)
            if deny:
                return handler._send_deny(deny)
            locator = body.get("locator")
            if isinstance(locator, str):
                locator = {"text": locator}
            return _send(_hr.submit_omission(
                cid, actor=actor, role=role, quote=body.get("quote") or "",
                issue=body.get("issue") or "", locator=locator,
                rule_hint=body.get("rule_hint") or "",
                subject=body.get("subject") or "",
                object_id=body.get("object_id") or "",
                note=body.get("note") or ""))
        return handler._err(405, "该方法不支持（写操作请用 POST）", "method_not_allowed")
    if action == "recover":
        return handler._err(405, "写操作请使用 POST", "method_not_allowed")
    if action not in ("list", "show"):
        return handler._err(404, "接口不存在", "not_found")
    cid = _v32_q(q, "case", "case_id")
    if cid:
        _case, deny = handler._case_scope(cid)
        if deny:
            return handler._send_deny(deny)
    limit = _v32_q(q, "limit") or 200
    offset = _v32_q(q, "offset") or 0
    if res == "direct-drafts":
        if action == "show":
            return _send(_hr.direct_draft_show(
                draft_id=ident, actor=actor, role=role))
        return _send(_hr.direct_draft_list(
            actor=actor, role=role, case_id=cid,
            run_id=_v32_q(q, "run_id", "run"), limit=limit, offset=offset))
    if res == "comparisons":
        if action == "show":
            return _send(_hr.comparison_show(
                item_id=ident, actor=actor, role=role,
                doc_text=_v32_q(q, "doc_text")))
        return _send(_hr.comparison_list(
            actor=actor, role=role, case_id=cid,
            bucket=_v32_q(q, "bucket"),
            visibility=_v32_q(q, "visibility"),
            human_status=_v32_q(q, "human_status", "status_filter"),
            limit=limit, offset=offset))
    if res == "visibility":
        if not cid:
            return handler._err(400, "需要 case 参数", "invalid_request")
        return _send(_hr.visibility_show(case_id=cid, actor=actor, role=role))
    if res == "suppression-ledger":
        if action == "show":
            return _send(_hr.ledger_show(ledger_id=ident, actor=actor, role=role))
        return _send(_hr.ledger_list(
            actor=actor, role=role, case_id=cid,
            status=_v32_q(q, "status"), source=_v32_q(q, "source"),
            limit=limit, offset=offset))
    if res == "human-omissions":
        if action == "show":
            return _send(_hr.omission_show(
                omission_id=ident, actor=actor, role=role))
        return _send(_hr.omission_list(
            actor=actor, role=role, case_id=cid,
            status=_v32_q(q, "status"), limit=limit, offset=offset))
    return handler._err(404, "接口不存在", "not_found")


def _apply_branding_html(html: bytes, branding: dict | None) -> bytes:
    """把租户品牌注入静态 HTML（服务端首屏，JS 未加载也不是默认平台名）。

    - 平台名替换 HTML 文本中的默认“AI 审核平台”（HTML 转义）；
    - 注入 ``window.__RP_TENANT_BRANDING__`` 供 branding.js 立即应用 logo 并监听动态文本。
    未配置品牌（无平台名/logo）时原样返回，保证默认回退。
    """
    if not isinstance(branding, dict) or not branding.get("configured"):
        return html
    name = str(branding.get("platform_name") or "").strip()
    default_name = "AI 审核平台"
    try:
        if name and name != default_name:
            html = html.replace(default_name.encode("utf-8"),
                                _esc_html(name).encode("utf-8"))
        # 首屏也注入 logo <img>，避免必须等 JS 才出现；branding.js 负责后续动态刷新/清除。
        logo = str(branding.get("logo_url") or "").strip()
        if logo:
            safe_logo = _esc_html(logo, quote=True)
            safe_alt = _esc_html(name or default_name, quote=True)

            def _img(size):
                return (f'<img class="rp-brand-logo" src="{safe_logo}" alt="{safe_alt}" '
                        f'style="display:block;width:{size}px;height:{size}px;'
                        f'object-fit:contain;border-radius:6px;background:transparent">')
            html = html.replace(
                b'<span class="login-logo">AI</span>',
                f'<span class="login-logo" data-rp-server-logo="1" '
                f'style="background:transparent;box-shadow:none">{_img(34)}</span>'.encode())
            html = html.replace(
                b'<span class="mark">AI</span>',
                f'<span class="mark" data-rp-server-logo="1" '
                f'style="border:0;background:transparent;box-shadow:none">{_img(26)}</span>'.encode())
            html = html.replace(
                b'<span class="logo">AI</span>',
                f'<span class="logo" data-rp-server-logo="1" '
                f'style="display:grid;width:30px;height:30px;place-items:center">{_img(30)}</span>'.encode())
        payload = json.dumps({"branding": branding}, ensure_ascii=False).replace("</", "<\\/")
        tag = (f'<script>window.__RP_TENANT_BRANDING__={payload};</script>').encode("utf-8")
        if b"</head>" in html:
            html = html.replace(b"</head>", tag + b"</head>", 1)
        else:
            html += tag
    except Exception:
        logging.getLogger(__name__).debug("branding inject skipped", exc_info=True)
        return html
    return html


def _module_off(self, key: str) -> bool:
    try:
        from app.services import workspaces as _wm, permissions as _pm
        u = self._session_user() or {}
        cur = _wm.current(u.get("sub", ""))
        return _wm.explicit_off(cur.get("id", ""), key)
    except Exception:
        return False


_ontology_target_workspace = _ontology_routes._ontology_target_workspace   # T-203：唯一实现见 app/api/ontology_routes.py


def _ops_meta(codes):
    """运营元数据：负责人 / 最近日期 / 维护记录（优先真实 owner 字段）。"""
    from app import repositories as _R
    meta = {c: {"owner": "", "updated_at": "", "records": 0, "last_action": ""} for c in codes}
    try:
        rule_rows = {r.get("code"): (r.get("owner") or "") for r in _R.rules.list()}
        dt_rows = {r.get("code"): (r.get("owner") or "") for r in _R.decision_tables.list()}
        for c in codes:
            meta[c]["owner"] = rule_rows.get(c) or dt_rows.get(c) or ""
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    try:
        logs = _R.audit_logs.list(order="created_at DESC")
    except Exception:
        logs = []
    for lg in logs:
        obj = str(lg.get("object") or "")
        if obj not in meta:
            continue
        m = meta[obj]
        m["records"] += 1
        if not m["updated_at"]:
            m["updated_at"] = lg.get("created_at") or ""
            m["last_action"] = lg.get("action") or ""
            if not m["owner"]:
                m["owner"] = lg.get("actor") or ""
    return meta


def _rule_owned_by(row: dict, user: dict) -> bool:
    """规则是否属于当前用户；优先 owner_id，旧数据回退到 owner 名称/账号。"""
    if not row or not user:
        return False
    oid = str(row.get("owner_id") or "").strip()
    if oid:
        return oid == str(user.get("sub") or "")
    owner = str(row.get("owner") or "").strip()
    return bool(owner) and owner in {str(user.get("name") or ""), str(user.get("username") or ""), str(user.get("sub") or "")}


def _scoped_rule(value, user):
    """规则写操作统一作用域解析（支持 rule id / code）。

    不存在、跨租户、跨空间一律 404，不泄露“存在但无权”的差异；
    规则生命周期写路由必须先过这里，禁止直接按 id 改库绕过空间隔离。
    """
    from app.services import ids as _ids
    raw = str(value or "").strip()
    try:
        row = R.rules.get(raw) if raw else None
        if not row and raw:
            rows = R.rules.list("code=?", (raw,))
            row = rows[0] if rows else None
        if not row:
            raise _ids.IDLookupError(404, "规则不存在", "not_found")
        return _ids.resolve("rule", row.get("id") or "", user or {}), None
    except _ids.IDLookupError as e:
        return None, (e.status, {"error": e.message, "code": e.code})


# ---------------- 二级 ID（manifest_result / manifest_evidence / batch）------------
# 三类 ID 都不是独立业务实体：先解析到所属 audit_case，再按租户/空间/归属统一
# 判 403/404。函数放在模块级，HTTP Handler 与 CLI 共用同一套解析/鉴权语义。
SECONDARY_KINDS = {"manifest_result", "manifest_evidence", "batch"}
SECONDARY_LABELS = {
    "manifest_result": ("审核结果不存在", "无权访问该审核结果"),
    "manifest_evidence": ("补证事项不存在", "无权访问该补证事项"),
    "batch": ("批次不存在", "无权访问该批次"),
}


def resolve_secondary_raw(kind: str, oid: str):
    """把二级 ID 解析为 {case, row, manifest, evidence, ...}；不存在返回 None。"""
    oid = str(oid or "").strip()
    if not oid or kind not in SECONDARY_LABELS:
        return None
    try:
        with db.session() as c:
            row, manifest, evidence = {}, {}, {}
            case_id = ""
            if kind == "manifest_result":
                r = c.execute("SELECT * FROM manifest_result WHERE id=?", (oid,)).fetchone()
                if not r:
                    return None
                row = dict(r)
                m = c.execute("SELECT * FROM audit_manifest WHERE id=?",
                              (row.get("manifest_id") or "",)).fetchone()
                if not m:
                    return None
                manifest = dict(m)
                case_id = str(manifest.get("case_id") or "")
            elif kind == "manifest_evidence":
                e = c.execute("SELECT * FROM manifest_evidence WHERE id=?", (oid,)).fetchone()
                if not e:
                    return None
                evidence = dict(e)
                r = c.execute("SELECT * FROM manifest_result WHERE id=?",
                              (evidence.get("result_id") or "",)).fetchone()
                if not r:
                    return None
                row = dict(r)
                m = c.execute("SELECT * FROM audit_manifest WHERE id=?",
                              (row.get("manifest_id") or "",)).fetchone()
                if not m:
                    return None
                manifest = dict(m)
                case_id = str(manifest.get("case_id") or "")
            else:  # batch：批次只存在 audit_run.batch_ids 中，解析后仍以 case 为准
                runs = c.execute(
                    "SELECT * FROM audit_run WHERE ','||COALESCE(batch_ids,'')||',' LIKE ? "
                    "ORDER BY created_at DESC", ("%," + oid + ",%",)).fetchall()
                if not runs:
                    return None
                row = dict(runs[0])
                for rr in runs[1:]:
                    if str(rr["case_id"] or "") != str(row.get("case_id") or ""):
                        return None
                case_id = str(row.get("case_id") or "")
            if not case_id:
                return None
            cr = c.execute("SELECT * FROM audit_case WHERE id=?", (case_id,)).fetchone()
            if not cr:
                return None
            case = dict(cr)
            return {"kind": kind, "id": oid, "row": row, "manifest": manifest,
                    "evidence": evidence, "case": case, "case_id": case_id,
                    "tenant_id": str(case.get("tenant_id") or ""),
                    "workspace_id": str(case.get("workspace_id") or "")}
    except Exception:
        logging.getLogger(__name__).warning("二级 ID 解析失败：%s", kind, exc_info=True)
        return None


def secondary_case_deny(case, user, kind, tenant_id=None, workspace_id=None):
    """二级 ID 所属 case 的租户/空间/归属判定；返回 (status, body) 或 None。"""
    missing, forbidden = SECONDARY_LABELS.get(kind, ("对象不存在", "无权访问该对象"))
    if not user:
        return 401, {"error": "未登录", "code": "unauthorized"}
    if tenant_id is None or workspace_id is None:
        try:
            from app.services import ctx as _cx
            cur = _cx.get_context() or {}
        except Exception:
            cur = {}
        if tenant_id is None:
            tenant_id = str(cur.get("tenant_id") or "")
        if workspace_id is None:
            workspace_id = str(cur.get("workspace_id") or "")
    tenant = str(tenant_id or "")
    workspace = str(workspace_id or "")
    case_tenant = str(case.get("tenant_id") or "")
    case_ws = str(case.get("workspace_id") or "")
    # 跨租户一律 404，不能靠 403 暴露对象存在；同租户跨空间 403。
    if tenant and case_tenant and case_tenant != tenant:
        return 404, {"error": missing, "code": "not_found"}
    if workspace and case_ws and case_ws != workspace:
        return 403, {"error": forbidden, "code": "forbidden"}
    role = str(user.get("role") or "")
    if role in ("admin", "super_admin"):
        return None
    if role == "reviewer":
        owner = str(case.get("created_by") or "")
        if owner and owner in (str(user.get("sub") or ""), str(user.get("id") or "")):
            return None
    return 403, {"error": forbidden, "code": "forbidden"}


def resolve_secondary(kind: str, oid: str, user: dict | None = None,
                      tenant_id: str = None, workspace_id: str = None):
    """统一二级 ID 入口：先鉴权，再解析，再校验所属 case 作用域。"""
    u = user or {}
    missing = SECONDARY_LABELS.get(kind, ("对象不存在", ""))[0]
    if not u:
        return None, (401, {"error": "未登录", "code": "unauthorized"})
    obj = resolve_secondary_raw(kind, oid)
    if not obj:
        return None, (404, {"error": missing, "code": "not_found"})
    deny = secondary_case_deny(obj.get("case") or {}, u, kind, tenant_id, workspace_id)
    if deny:
        return None, deny
    return obj, None


def _evidence_item(row) -> dict:
    d = dict(row)
    raw = d.pop("checklist_json", "[]")
    try:
        d["checklist"] = json.loads(raw or "[]")
    except Exception:
        d["checklist"] = []
    return d


def list_manifest_evidence(result_id: str = "", user: dict | None = None, limit: int = 100):
    """读取补证事项：带 result 时先解析 result 作用域；不带时只返回当前用户可见项。"""
    u = user or {}
    if not u:
        return None, (401, {"error": "未登录", "code": "unauthorized"})
    rid = str(result_id or "").strip()
    try:
        limit = max(1, min(int(limit or 100), 500))
    except Exception:
        limit = 100
    if rid:
        _obj, deny = resolve_secondary("manifest_result", rid, u)
        if deny:
            return None, deny
        with db.session() as c:
            rows = c.execute("SELECT * FROM manifest_evidence WHERE result_id=? "
                             "ORDER BY created_at DESC LIMIT ?", (rid, limit)).fetchall()
        items = [_evidence_item(r) for r in rows]
        return {"result_id": rid, "items": items, "total": len(items)}, None
    with db.session() as c:
        rows = c.execute("SELECT * FROM manifest_evidence ORDER BY created_at DESC LIMIT ?",
                         (limit * 4,)).fetchall()
    items = []
    for r in rows:
        _obj, deny = resolve_secondary("manifest_evidence", str(r["id"]), u)
        if deny:
            continue
        items.append(_evidence_item(r))
        if len(items) >= limit:
            break
    return {"result_id": "", "items": items, "total": len(items)}, None


# ---------------- 导出（HTTP/CLI 同一实现） ----------------
def _export_role(user) -> str:
    return str((user or {}).get("role") or "")


def _csv_export_audit(actor, action, object_, body, kind, filters,
                      scope=None, request_id="", ip="") -> dict:
    """项目/发现/审核记录 CSV 导出写审计（L150 A-01 低成本补点）。

    - 只审计**成功返回的导出**（权限拒绝/参数错误在调用前已 return，不产生导出事件）；
    - ``after_json`` 含 kind/rows/bytes/**实际导出字节 sha256**/batch_id/filters/scope，
      与审计日志导出（audit.exported）同构，便于复核“拿到的文件没被改过”；
    - **审计失败不阻断导出**（业务读导出不能被留痕故障拖死）：失败只写结构化日志
      （obs 事件 ``export.audit_failed`` + 含 action/actor/object/sha256 的 error 日志），
      不改变导出结果/HTTP 状态码。与审计日志导出（合规导出必须留痕、失败即拒）刻意区分。
    """
    content = body or b""
    payload = {"kind": kind, "format": "csv",
               "rows": int(export_service.row_count(content)),
               "bytes": len(content),
               "sha256": hashlib.sha256(content).hexdigest(),
               "batch_id": db.new_id("exb"), "at": db.now(),
               "filters": filters or {}, "scope": scope or {}}
    try:
        R.audit_logs.log(actor=str(actor or "system"), action=str(action or ""),
                         object=str(object_ or ""),
                         after=json.dumps(payload, ensure_ascii=False)[:4000],
                         request_id=str(request_id or ""), ip=str(ip or ""))
        payload["audited"] = True
    except Exception as exc:  # noqa: BLE001 - 留痕失败不阻断导出，但必须结构化上报
        payload["audited"] = False
        try:
            obs.log_event("export.audit_failed", module="api.server", level="error",
                          rid=str(request_id or ""), user=str(actor or ""),
                          status="audit_write_failed",
                          error="%s: %s" % (type(exc).__name__, exc),
                          action=str(action or ""), object=str(object_ or ""),
                          sha256=payload["sha256"], rows=payload["rows"],
                          tenant=str((scope or {}).get("tenant_id") or ""))
        except Exception:  # pragma: no cover - obs 自身异常也不能影响导出
            logging.getLogger(__name__).error(
                "export audit failed action=%s actor=%s object=%s sha256=%s",
                action, actor, object_, payload["sha256"], exc_info=True)
    return payload


def build_projects_csv(user, request_id: str = "", ip: str = ""):
    """项目 CSV：管理员看本租户全空间，审核员只看自己项目（跨空间的自有项目也算）。"""
    from app.services import ctx as _cx
    role = _export_role(user)
    if role not in ("admin", "reviewer"):
        return None, (403, {"error": "无权限导出项目", "code": "forbidden"})
    # L98 P1：完整状态快照/恢复（旧写法 finally 只回 tenant/workspace）
    old = _cx.snapshot()
    try:
        _cx.set_context(old.get("tenant_id") or "t-default", "")
        cases = R.cases.list(order="created_at DESC")
        if role == "reviewer":
            _uid = str((user or {}).get("sub") or "")
            cases = [c for c in cases if str(c.get("created_by") or "") == _uid]
        rows = []
        for c in cases:
            fs = R.findings.list("case_id=?", (c["id"],))
            rows.append({"id": c["id"], "name": c.get("name") or "",
                         "status": c.get("status") or "",
                         "created_by": c.get("created_by") or "",
                         "created_at": c.get("created_at") or "",
                         "findings": len(fs),
                         "critical": sum(1 for f in fs if f.get("severity") == "critical"),
                         "pending": sum(1 for f in fs if f.get("status") == "pending")})
        body = export_service._csv(rows, ["id", "name", "status", "created_by", "created_at",
                                          "findings", "critical", "pending"])
    finally:
        _cx.restore(old)
    _csv_export_audit(
        actor=str((user or {}).get("sub") or ""), action="export.projects_csv",
        object_="projects.csv", body=body, kind="projects",
        filters={"role": role,
                 "visibility": "tenant_all_workspaces" if role == "admin" else "self_projects"},
        scope=_cx.get_context(), request_id=request_id, ip=ip)
    return body, None


def build_findings_csv(user, case_id, request_id: str = "", ip: str = ""):
    """发现 CSV：case 必须先过统一 resolver（不存在 404、他人/跨空间 403、跨租户 404）。"""
    from app.services import ids as _ids
    role = _export_role(user)
    if role not in ("admin", "reviewer"):
        return None, (403, {"error": "无权限导出发现", "code": "forbidden"})
    cid = str(case_id or "").strip()
    if not cid:
        return None, (400, {"error": "需要 case_id", "code": "invalid_request"})
    try:
        _ids.resolve("case", cid, user or {})
    except _ids.IDLookupError as e:
        return None, (e.status, {"error": e.message, "code": e.code})
    body = export_service.findings_csv(cid)
    from app.services import ctx as _cx
    _csv_export_audit(
        actor=str((user or {}).get("sub") or ""), action="export.findings_csv",
        object_="findings.csv:" + cid, body=body, kind="findings",
        filters={"case_id": cid, "role": role},
        scope=_cx.get_context(), request_id=request_id, ip=ip)
    return body, None


def build_audit_records_csv(user, date_from: str = "", date_to: str = "", reviewer_id: str = "",
                            request_id: str = "", ip: str = ""):
    """审核记录导出：业务管理员专属；系统管理员/审核员一律 403。"""
    role = _export_role(user)
    if role != "admin":
        return None, (403, {"error": "仅业务管理员可导出审核记录", "code": "forbidden"})
    body = export_service.audit_records_csv(date_from, date_to, reviewer_id)
    from app.services import ctx as _cx
    _csv_export_audit(
        actor=str((user or {}).get("sub") or ""), action="export.audit_records_csv",
        object_="audit-records.csv", body=body, kind="audit_records",
        filters={"date_from": date_from or "", "date_to": date_to or "",
                 "reviewer_id": reviewer_id or "", "role": role},
        scope=_cx.get_context(), request_id=request_id, ip=ip)
    return body, None


# ---------------- 开放平台对象作用域（HTTP/CLI 同一实现） ----------------
open_app_scope = _open_routes.open_app_scope   # T-203：唯一实现见 app/api/open_routes.py


open_task_detail_scoped = _open_routes.open_task_detail_scoped   # T-203：唯一实现见 app/api/open_routes.py


def _set_owner(kind, code, actor, actor_id=""):
    """创建后写入负责人（真实字段）；owner_id 用于“本人规则”权限判断。"""
    if not actor and not actor_id:
        return
    from app import repositories as _R
    try:
        update = {}
        if actor:
            update["owner"] = actor
        if actor_id:
            update["owner_id"] = actor_id
        if not update:
            return
        if kind == "rule":
            rows = _R.rules.list("code=?", (code,))
            if rows: _R.rules.update(rows[0]["id"], **update)
        else:
            rows = _R.decision_tables.list("code=?", (code,))
            if rows: _R.decision_tables.update(rows[0]["id"], **update)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)


_role_of = _review_routes.role_of   # T-203：唯一实现见 app/api/review_routes.py



_url_allowed = _open_routes.url_allowed   # T-203：唯一实现见 app/api/open_routes.py


_open_callback_ok = _open_routes.open_callback_ok   # T-203：唯一实现见 app/api/open_routes.py


def _model_url_ok(url: str) -> tuple:
    """模型地址：仅 http/https；默认拒绝内网/环回（本地模型需显式 RULEPROOF_ALLOW_LOCAL_MODEL=1）。"""
    if not url:
        return True, ""
    if str(os.environ.get("RULEPROOF_ALLOW_LOCAL_MODEL", "0")).lower() in ("1", "true", "yes"):
        from urllib.parse import urlparse
        u = urlparse(str(url))
        return (u.scheme in ("http", "https") and bool(u.hostname), "只允许 http/https")
    return _url_allowed(url)


finding_provenance = _review_routes.finding_provenance   # T-203：唯一实现见 app/api/review_routes.py


def explain(rule_id: str) -> dict:
    """可解释：这条规则是什么、命中了几处、每处证据在哪、为什么这么判。"""
    from app.services import rule_detail as _rd
    d = _rd.get(rule_id)
    if not d:
        return {}
    r = d["rule"]
    condition = rules_meta.condition_of(r["code"]) or {
        "consistency": "跨 Sheet / 跨文档比对，要求相关字段完全一致",
        "completeness": "字段存在且不为空/不为占位符 X",
        "limit": "数值与限值比较（≥/≤/=），带单位与容差",
        "format": "序号连续、格式规范",
        "preprocess": "前处理步骤含器具/作业内容/成品规格",
    }.get(r["category"], r["category"])
    return {
        "rule": r, "condition": condition,
        "hit_count": d.get("hit_count", 0), "override_count": d.get("override_count", 0),
        "findings": d["findings"], "versions": d["versions"],
    }


# ---------------------------------------------------------------------------
# 系统管理员控制面：统一口径（首页 KPI 范围标签 / 账号口径 / 四态可用性）
# ---------------------------------------------------------------------------
HOME_SCOPE_NOTES = {
    "super_admin": {"账号": "本租户 · 与账号列表同口径", "开放应用": "本租户",
                    "待投递回调": "本租户", "智能体": "全平台注册（可用性见智能体页）",
                    "审计日志": "本租户 · 全时间累计", "异常事件": "本租户 · 近 7 天"},
    "admin": None,   # 业务管理员：本租户 · 全部空间
    "reviewer": None,
}


def _tenant_of_user(user: dict) -> str:
    """当前会话账号的租户（数据库行为准，JWT claim 兜底）。"""
    uid = str((user or {}).get("sub") or "")
    row = {}
    try:
        row = R.users.get(uid) or {}
    except Exception:
        row = {}
    return str(row.get("tenant_id") or (user or {}).get("tenant_id") or "")


def _sql_count(sql: str, params=()) -> int:
    try:
        with db.session() as c:
            r = c.execute(sql, params).fetchone()
        return int((r[0] if r else 0) or 0)
    except Exception:
        logging.getLogger(__name__).debug("count query failed: %s", sql, exc_info=True)
        return 0


def _days_ago(n: int = 7) -> str:
    import datetime as _dt
    return (_dt.date.today() - _dt.timedelta(days=int(n))).isoformat()


def _super_home_patch(out: dict, user: dict) -> dict:
    """超管首页：修正账号口径 + 用真实状态替换“已启用=可用”的展示。"""
    uid = str((user or {}).get("sub") or "")
    tenant = _tenant_of_user(user)
    stats = out.get("stats") or []
    _scope = HOME_SCOPE_NOTES["super_admin"]
    try:
        acct_n = len(account.list_users("super_admin", uid))
    except Exception:
        acct_n = 0
    try:
        apps_n = len(open_service.list_apps())
    except Exception:
        apps_n = 0
    pending_n = _sql_count(
        "SELECT COUNT(*) FROM open_event WHERE delivered=0 "
        "AND (COALESCE(tenant_id,'')='' OR tenant_id=?)", (tenant,))
    audit_n = _sql_count(
        "SELECT COUNT(*) FROM audit_log WHERE COALESCE(tenant_id,'')='' OR tenant_id=?", (tenant,))
    _week = _days_ago(7)
    fails = _sql_count(
        "SELECT COUNT(*) FROM audit_log WHERE substr(created_at,1,10)>=? "
        "AND (action LIKE '%failed%' OR action LIKE '%error%')", (_week,))
    fails += _sql_count("SELECT COUNT(*) FROM open_event WHERE status='failed'")
    fails += _sql_count("SELECT COUNT(*) FROM task_job WHERE status='failed'")
    try:
        ag = agents.list_agents()
        agent_n = int(ag.get("total") or 0)
        _avc = ag.get("availability_counts") or {}
    except Exception:
        agent_n = 0
        _avc = {}
    _by_label = {"账号": acct_n, "开放应用": apps_n, "待投递回调": pending_n,
                 "智能体": agent_n, "审计日志": audit_n, "异常事件": fails}
    for s in stats:
        label = str(s.get("label") or "")
        if label in _by_label:
            s["value"] = _by_label[label]
        s["scope"] = "本租户"
        s["scope_note"] = _scope.get(label, "本租户")
        if label == "账号":
            s["hint"] = "本租户账号（与账号列表同口径，不含已删除/平台运营）"
        elif label == "智能体":
            s["hint"] = (f"可用性四态：连接正常 {_avc.get('ok', 0)} · 已配置待测 {_avc.get('configured', 0)}"
                         f" · 未配置 {_avc.get('unconfigured', 0)} · 连接失败 {_avc.get('fail', 0)}")
        elif label == "异常事件":
            s["hint"] = "近 7 天：审计失败/回调失败/任务失败（不含空指标）"
        elif label == "审计日志":
            s["hint"] = "本租户累计审计记录"
        elif label == "待投递回调":
            s["hint"] = "delivered=0 的开放平台事件"
        elif label == "开放应用":
            s["hint"] = "本租户接入应用"
    out["stats"] = stats
    return out


def _dashboard_patch(out: dict, user: dict) -> dict:
    """超管 IT 看板：模型/智能体四态 + OCR 主备 + 范围/时间窗说明。"""
    dash = out.get("it_dashboard")
    if not isinstance(dash, dict):
        return out
    try:
        mav = model.availability()
    except Exception:
        mav = {"counts": {}, "items": [], "ocr": {}}
    try:
        ag = agents.list_agents()
    except Exception:
        ag = {"availability_counts": {}, "items": []}
    mcounts = mav.get("counts") or {}
    acounts = ag.get("availability_counts") or {}
    health = dash.get("health") or {}
    health["models"] = {
        "total": mcounts.get("total", 0), "enabled": mcounts.get("enabled", 0),
        "ok": mcounts.get("ok", 0), "configured": mcounts.get("configured", 0),
        "unconfigured": mcounts.get("unconfigured", 0), "fail": mcounts.get("fail", 0),
        "effective": mcounts.get("effective", 0),
        "policy": "enabled 只是管理开关；未配置/已配置待测/连接失败都不算可用",
    }
    health["agents"] = {
        "total": int(ag.get("total") or 0), "enabled": int(ag.get("enabled") or 0),
        "ok": acounts.get("ok", 0), "configured": acounts.get("configured", 0),
        "unconfigured": acounts.get("unconfigured", 0), "fail": acounts.get("fail", 0),
        "disabled": acounts.get("disabled", 0), "program": acounts.get("program", 0),
        "effective": int(ag.get("effective") or 0),
        "policy": "管理启用≠可用；可用性由依赖模型四态决定",
    }
    dash["health"] = health
    dash["ocr"] = mav.get("ocr") or {}
    dash["models"] = mav.get("items") or []
    dash["agents"] = [{"id": x.get("id"), "name": x.get("name"),
                       "state": x.get("availability_state"),
                       "label": x.get("availability_label"),
                       "note": x.get("availability_note"),
                       "management": x.get("management_label")}
                      for x in (ag.get("items") or [])]
    dash["scope_meta"] = {
        "tenant_id": _tenant_of_user(user),
        "window": "近 7 天（趋势/异常）；累计（调用/审计）",
        "sources": ["user", "open_app/open_event", "model_config + engine.ocr.status()",
                    "agent + agent_version", "audit_log", "task_job", "channel_status()"],
        "note": "所有数字来自当前库真实记录；空记录不伪造 0 值健康结论。",
    }
    out["it_dashboard"] = dash
    return out


def _decorate_home(out: dict, user: dict) -> dict:
    """首页数据出口统一加工：范围标签 + 账号口径 + 四态。"""
    if not isinstance(out, dict):
        return out
    role = str(out.get("role") or (user or {}).get("role") or "")
    tenant = _tenant_of_user(user)
    if role == "super_admin":
        _super_home_patch(out, user)
        _dashboard_patch(out, user)
    else:
        for s in out.get("stats") or []:
            s["scope"] = "本人" if role == "reviewer" else "本租户"
            s["scope_note"] = ("本人 · 全部空间" if role == "reviewer"
                               else "本租户 · 全部空间汇总")
        out["scope_meta"] = {
            "tenant_id": tenant,
            "workspace_scope": "全部空间（首页不随工作空间切换）",
            "window": "当前值（记录/发现计数），问题分析默认近 30 天",
            "note": "本人/本租户口径由服务端按角色过滤，前端不做二次放大。",
        }
    return out


# ---------------- 账号列表：初始密码不常驻、待改密、操作原因 ----------------
# DU-01（P0，2026-11-25）：账号列表脱敏/范围过滤的**唯一实现**已下沉到
# app/services/account.py；HTTP 与 CLI 都调用服务层同一函数，禁止各自维护一份，
# 否则 CLI/HTTP 输出口径会再次漂移（旧隐患正是 CLI 直接 dump 服务层原始行）。
def _sanitize_user_item(u: dict, viewer_id: str) -> dict:
    """账号列表单行：移除明文初始密码，补充待改密/自身/初始账号原因。"""
    return account.sanitize_user_item(u, viewer_id)


def _sanitize_users_payload(payload, viewer: dict):
    return account.sanitize_users_payload(payload, viewer)


def _user_login_history(uid: str, viewer: dict) -> tuple:
    """账号登录历史（只读，来自审计日志真实记录）。"""
    target = None
    try:
        target = R.users.get(uid) or None
    except Exception:
        target = None
    if not target:
        return 404, {"error": "账号不存在", "code": "not_found"}
    viewer_tenant = _tenant_of_user(viewer)
    if viewer_tenant and str(target.get("tenant_id") or "") != viewer_tenant:
        return 404, {"error": "账号不存在", "code": "not_found"}
    actions = ("auth.login", "auth.login_failed", "auth.logout",
               "account.password_reset", "user.password_changed")
    ph = ",".join("?" for _ in actions)
    items = []
    try:
        with db.session() as c:
            rows = c.execute(
                f"SELECT id,actor,action,object,request_id,ip,created_at FROM audit_log "
                f"WHERE (actor=? OR object=?) AND action IN ({ph}) "
                f"ORDER BY created_at DESC LIMIT 50",
                (uid, uid, *actions)).fetchall()
            items = [dict(r) for r in rows]
    except Exception:
        logging.getLogger(__name__).warning("login history query failed", exc_info=True)
    labels = {"auth.login": "登录成功", "auth.login_failed": "登录失败",
              "auth.logout": "退出登录", "account.password_reset": "密码重置",
              "user.password_changed": "修改密码"}
    for it in items:
        it["action_label"] = labels.get(str(it.get("action") or ""), it.get("action") or "")
    return 200, {
        "ok": True, "user_id": uid, "name": target.get("name") or "",
        "phone": target.get("phone") or "", "last_login": target.get("last_login") or "",
        "items": items, "total": len(items),
        "session_model": "无状态 JWT 会话",
        "active_sessions_supported": False,
        "active_sessions_note": ("当前版本会话为签名 JWT，服务端不保存会话列表，"
                                 "因此不展示“活跃会话”也不提供踢出他人会话（NOT DONE）；"
                                 "登录失败/成功/退出/改密均来自 audit_log 真实记录。"),
    }


# ---------------- 审计日志：对象追踪 + 坏数据对账 ----------------
def _audit_scope_pair(viewer: dict) -> tuple:
    tenant = _tenant_of_user(viewer)
    workspace = ""
    try:
        ws = (viewer or {}).get("workspace_id") or ""
        workspace = str(ws)
    except Exception:
        workspace = ""
    return tenant, workspace


def _audit_object_trace(obj: str, viewer: dict, limit: int = 50) -> tuple:
    """按对象追踪：同一 object 的全部审计记录（严格匹配，不模糊扩大）。"""
    obj = str(obj or "").strip()
    if not obj:
        return 400, {"error": "缺少 object 参数", "code": "invalid_argument"}
    tenant, _ws = _audit_scope_pair(viewer)
    try:
        limit = max(1, min(int(limit or 50), 200))
    except Exception:
        limit = 50
    params = [obj]
    where = "object=?"
    if tenant:
        where += " AND (COALESCE(tenant_id,'')='' OR tenant_id=?)"
        params.append(tenant)
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                f"SELECT id,actor,action,object,before_json,after_json,request_id,ip,created_at,tenant_id "
                f"FROM audit_log WHERE {where} ORDER BY created_at DESC LIMIT ?",
                tuple(params + [limit])).fetchall()]
    except Exception:
        logging.getLogger(__name__).warning("audit object trace failed", exc_info=True)
        rows = []
    for r in rows:
        r["detail"] = (r.get("after_json") or "")[:300]
    return 200, {"ok": True, "object": obj, "items": rows, "total": len(rows),
                 "note": "对象追踪按 object 精确匹配；只读，不可编辑/删除。"}


def _audit_reconcile(viewer: dict) -> tuple:
    """审计坏数据对账：JSON 坏值、请求编号缺失、对象缺失（只读，不自动修复）。"""
    tenant, _ws = _audit_scope_pair(viewer)
    where = "1=1"
    params: list = []
    if tenant:
        where += " AND (COALESCE(tenant_id,'')='' OR tenant_id=?)"
        params.append(tenant)
    out = {"ok": True, "scope": {"tenant_id": tenant, "window": "全时间"},
           "total": 0, "request_id_missing": 0, "object_missing": 0,
           "request_id_coverage": None,
           "after_json_invalid": 0, "before_json_invalid": 0, "samples": [],
           "note": ("对账口径：统计 before_json/after_json 无法解析为 JSON 的行；"
                    "历史纯文本写法（如直接存对象名称）不是数据损坏，只是不能结构化对账。"
                    "只报告不自动修复；先备份再按样本核对。")}
    try:
        with db.session() as c:
            out["total"] = int(c.execute(f"SELECT COUNT(*) FROM audit_log WHERE {where}",
                                         tuple(params)).fetchone()[0] or 0)
            out["request_id_missing"] = int(c.execute(
                f"SELECT COUNT(*) FROM audit_log WHERE {where} AND COALESCE(request_id,'')=''",
                tuple(params)).fetchone()[0] or 0)
            out["object_missing"] = int(c.execute(
                f"SELECT COUNT(*) FROM audit_log WHERE {where} AND COALESCE(object,'')=''",
                tuple(params)).fetchone()[0] or 0)
            if out["total"]:
                out["request_id_coverage"] = round(
                    (out["total"] - out["request_id_missing"]) / out["total"], 3)
            bad = c.execute(
                f"SELECT id,action,object,request_id,created_at,before_json,after_json FROM audit_log "
                f"WHERE {where} AND ("
                f"(COALESCE(before_json,'')<>'' AND json_valid(before_json)=0) OR "
                f"(COALESCE(after_json,'')<>'' AND json_valid(after_json)=0)) "
                f"ORDER BY created_at DESC LIMIT 20", tuple(params)).fetchall()
            for r in bad:
                d = dict(r)
                fields = []
                for k in ("before_json", "after_json"):
                    val = str(d.get(k) or "")
                    if val and not _json_ok(val):
                        fields.append(k)
                        out["before_json_invalid" if k == "before_json" else "after_json_invalid"] += 1
                out["samples"].append({"id": d.get("id"), "action": d.get("action"),
                                       "object": d.get("object"), "request_id": d.get("request_id"),
                                       "created_at": d.get("created_at"), "bad_fields": fields})
    except Exception:
        logging.getLogger(__name__).warning("audit reconcile failed", exc_info=True)
        out["note"] = "对账查询失败（可能为旧库缺少 json_valid 支持）；只读接口不修改数据。"
    # L150 / L140 A-05：可查的 append-only 状态（缺失 → status=warn；只报告不修复）。
    out["audit_append_only"] = _audit_append_only_status()
    return 200, out


def _json_ok(raw: str) -> bool:
    try:
        json.loads(raw)
        return True
    except Exception:
        return False


# ---------------- 通知配置：测试发送（真实站内消息）+ 触发记录 ----------------
def _notify_test_send(user: dict, body: dict, request_id: str = "", ip: str = "") -> tuple:
    """向本人发送一条真实站内消息，验证模板渲染与站内投递链路。"""
    uid = str((user or {}).get("sub") or "")
    evt = str((body or {}).get("event") or "system.test").strip()
    if not uid:
        return 401, {"error": "未登录", "code": "unauthorized"}
    events = {e["key"]: e for e in (notify.NOTIFY_EVENTS or [])}
    cfg = {}
    try:
        cfg = (notify.get_config().get("config") or {}).get(evt) or {}
    except Exception:
        cfg = {}
    title = "【通知测试】" + (events.get(evt, {}).get("name") or "站内消息测试")
    detail = ("这是一条真实站内消息（由通知配置页“测试发送”触发）；"
              "事件=" + evt + "；若该事件被禁用或无可见角色，真实业务触发时不会发送。")
    rendered_title, rendered_detail = title, detail
    try:
        rendered_title, rendered_detail = notify._render_text(evt, title, detail)
    except Exception:
        logging.getLogger(__name__).debug("notify template render failed", exc_info=True)
    try:
        res = notify.notify(uid, "system.test", rendered_title, rendered_detail)
    except Exception as exc:  # noqa: BLE001
        logging.getLogger(__name__).warning("notify test send failed", exc_info=True)
        return 500, {"ok": False, "error": f"站内消息发送失败：{type(exc).__name__}", "code": "notify_failed"}
    try:
        R.audit_logs.log(actor=uid, action="notify.test_sent", object=evt,
                         after=json.dumps({"event": evt, "title": rendered_title}, ensure_ascii=False),
                         request_id=str(request_id or ""), ip=str(ip or ""))
    except Exception:
        logging.getLogger(__name__).debug("notify test audit skipped", exc_info=True)
    enabled = bool(cfg.get("enabled"))
    return 200, {
        "ok": True, "channel": "inapp", "event": evt,
        "notification_id": (res or {}).get("id") or "",
        "delivered": bool((res or {}).get("id")),
        "rendered_title": rendered_title, "rendered_detail": rendered_detail,
        "template": {"title_template": cfg.get("title_template") or "{title}",
                     "detail_template": cfg.get("detail_template") or "{detail}"},
        "event_enabled": enabled,
        "audiences": cfg.get("audiences") or [],
        "note": ("已写入真实站内消息（消息中心可见），不是模拟提示。" if (res or {}).get("id")
                 else "消息未写入：当前事件被禁用或无可见角色，请检查配置。"),
    }


def _notify_records(user: dict, limit: int = 30) -> tuple:
    """真实触发记录：notification 表中本租户最近消息 + 按事件聚合。"""
    tenant = _tenant_of_user(user)
    try:
        limit = max(1, min(int(limit or 30), 200))
    except Exception:
        limit = 30
    where = "1=1"
    params: list = []
    if tenant:
        # P1-B7-01 ②：只返回本租户行。旧实现把 tenant_id='' 当成本租户数据 →
        # 其他租户超管的 system.incident（tenant_id=''）混入本租户触发记录。
        where += " AND COALESCE(n.tenant_id,'')=?"
        params.append(tenant)
    else:
        # 无租户角色（平台级账号）只能看到无租户行，不反向读取任意租户数据
        where += " AND COALESCE(n.tenant_id,'')=''"
    items, by_type = [], []
    try:
        with db.session() as c:
            rows = c.execute(
                f"SELECT n.id,n.actor,n.type,n.title,n.detail,n.read,n.created_at,"
                f"COALESCE(u.name,'') AS actor_name FROM notification n "
                f"LEFT JOIN user u ON u.id=n.actor WHERE {where} "
                f"ORDER BY n.created_at DESC LIMIT ?",
                tuple(params + [limit])).fetchall()
            items = [dict(r) for r in rows]
            agg = c.execute(
                f"SELECT n.type, COUNT(*) AS n, MAX(n.created_at) AS last_at FROM notification n "
                f"WHERE {where} GROUP BY n.type ORDER BY n DESC", tuple(params)).fetchall()
            by_type = [dict(r) for r in agg]
    except Exception:
        logging.getLogger(__name__).warning("notify records query failed", exc_info=True)
    return 200, {"ok": True, "items": items, "by_type": by_type,
                 "total": len(items), "scope": {"tenant_id": tenant},
                 "note": "触发记录来自 notification 表真实写入；站内消息是当前唯一渠道。"}


class AppServer(ThreadingHTTPServer):
    """服务端兜底：未处理异常写入系统管理员消息中心。"""

    def handle_error(self, request, client_address):
        import traceback as _tb
        try:
            _exc = _tb.format_exc()
            from app.services import notify as _ntf
            _ntf.notify_system_incident("服务请求异常",
                                        f"{client_address[0] if client_address else '-'} · {_exc[-500:]}")
        except Exception:
            logging.getLogger(__name__).debug('server incident notify skipped', exc_info=True)
        super().handle_error(request, client_address)


class Handler(BaseHTTPRequestHandler):
    # F-03（build56 外部独立审查 P1）：CORS 白名单实现统一在 http_guard
    # （cors_echo_origin / send_cors_header）；此处及 4 处发送路径只调用，不硬编码 *。
    def _send(self, code, body, ctype="application/json; charset=utf-8", headers=None):
        if code == 200 and ctype.startswith("application/json"):
            try:
                _o = json.loads(body.decode("utf-8")) if body else {}
                if isinstance(_o, dict) and _o.get("error") and not _o.get("ok"):
                    code = 400
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        _hg.send_cors_header(self)   # F-03：白名单回显（无 Origin / 非白名单不输出；永不 *）
        self.send_header("X-Request-Id", getattr(self, "_rid", "-"))
        for _hk, _hv in (headers or {}).items():
            self.send_header(str(_hk), str(_hv))
        self.send_header("Content-Length", str(len(body)))
        # 静态资源与页面不缓存：避免前端更新后浏览器仍跑旧脚本
        if ctype.startswith(("application/javascript", "text/css", "text/html")):
            self.send_header("Cache-Control", "no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj):
        return json.dumps(obj, ensure_ascii=False).encode("utf-8")

    def _audit_req_fields(self) -> dict:
        """HTTP 审计兜底字段：请求级 request_id + 客户端 IP（L150 / L140 A-03）。

        业务审计此前仅极少数动作带 ip/rid（L140 实测 ip 3.2%、request_id 2.7%）；
        这里统一从 handler 取（``self._rid`` 在 do_GET/do_POST 入口已生成，
        ``client_address`` 为 TCP 对端地址），调用点只需 ``**self._audit_req_fields()``，
        不改服务层/权限逻辑。离线调用（无 HTTP 请求）天然返回空串，不伪造。
        """
        ip = ""
        try:
            ip = self.client_address[0] if self.client_address else ""
        except Exception:  # noqa: BLE001 - 取 IP 失败不得影响审计写入/业务
            ip = ""
        return {"request_id": str(getattr(self, "_rid", "") or ""), "ip": ip}

    def _sse(self, actor: str):
        """SSE 实时推送：新通知即时送达，15s 心跳保活。"""
        import queue as _q
        self.close_connection = True
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.wfile.write(b": connected\n\n")
            self.wfile.flush()
        except Exception:
            return
        sub = notify.subscribe(actor)
        try:
            while True:
                try:
                    item = sub.get(timeout=15)
                    self.wfile.write(("data: " + json.dumps(item, ensure_ascii=False) + "\n\n").encode("utf-8"))
                except _q.Empty:
                    self.wfile.write(b": ping\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        finally:
            notify.unsubscribe(actor, sub)

    def _session_error_response(self, exc):
        """E-02：会话签名不可用时返回可读 JSON 500，而不是空响应/直接断连。"""
        logging.getLogger(__name__).error(
            "session token creation failed（会话签名不可用）: %s", exc, exc_info=True)
        if auth._is_prod():
            msg = ("会话签名失败：生产环境必须配置 RULEPROOF_SESSION_SECRET"
                   "（当前为空或开发占位值）。请在平台根 .env 写入随机密钥后重启服务；"
                   "使用 ./start.sh 首次生产启动会自动生成。")
        else:
            msg = f"会话创建失败：{type(exc).__name__}"
        body = self._json({"error": msg, "code": "session_secret_missing"})
        try:
            self.send_response(500)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            _hg.send_cors_header(self)   # F-03：白名单回显（登录失败响应同样不得输出 *）
            self.send_header("X-Request-Id", getattr(self, "_rid", "-"))
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            logging.getLogger(__name__).debug("session error response failed", exc_info=True)

    def _send_session(self, code, body, user, ctype="application/json; charset=utf-8"):
        """先 send_response 再写 Set-Cookie（顺序必须是这个）。"""
        try:
            token = auth.make_session(user)
        except Exception as exc:  # E-02：不得让未捕获异常变成空响应
            return self._session_error_response(exc)
        self.send_response(code)
        self._set_session(user, token)
        self.send_header("Content-Type", ctype)
        _hg.send_cors_header(self)   # F-03：带 Set-Cookie 的登录/会话响应不得输出 *
        self.send_header("X-Request-Id", getattr(self, "_rid", "-"))
        self.send_header("Content-Length", str(len(body)))
        # 静态资源与页面不缓存：避免前端更新后浏览器仍跑旧脚本
        if ctype.startswith(("application/javascript", "text/css", "text/html")):
            self.send_header("Cache-Control", "no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(body)

    def _err(self, code, msg, err_code="bad_request"):
        return self._send(code, self._json({"error": msg, "code": err_code}))

    def _conflict_internal(self, action: str, cid: str, exc):
        # P2-04 收口：冲突写通用异常兜底——记录 error 并返回 500（不吞成 200/断连）。
        logging.getLogger(__name__).error("conflict %s failed cid=%s: %s", action, cid,
                                          type(exc).__name__, exc_info=True)
        return self._err(500, "冲突操作失败（服务内部错误），本次操作已回滚", f"conflict_{action}_failed")

    def _redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_PUT(self):
        # 数据边界策略：PUT 保存配置 / DELETE 删除执行（DELETE 必须带预览凭证）。
        # 其余 PUT/PATCH/DELETE 仍统一 405；系统管理员业务边界在下方统一判定。
        _p = self.path.split("?", 1)[0]
        # P2-16：非上传类 PUT/DELETE 请求体统一小上限 + 写入并发槽位。
        _cap, _kind = _hg.post_body_cap(_p)
        try:
            _clen = int(self.headers.get("Content-Length", 0) or 0)
        except Exception:
            _clen = -1
        if _clen < 0 or _clen > (_cap if _cap is not None else _hg.max_upload_body_bytes()):
            self.close_connection = True
            return self._send(413, self._json({"error": "请求体过大或长度非法",
                                               "code": "payload_too_large"}))
        if self.command != "OPTIONS" and not _hg.acquire_slot(self, "write"):
            return self._send(503, self._json({"error": "服务繁忙（并发写入已达上限）",
                                               "code": "server_busy"}))
        if _p == "/api/v1/data-policy" or _p.startswith("/api/v1/data-policy/"):
            self._t0 = time.time()
            self._rid = uuid.uuid4().hex[:12]
            obs.bind(rid=self._rid)
            g = self._guard(self.command, _p)
            if g:
                return self._send(g[0], g[1])
            from app.api import data_policy_routes as _dpr
            _u = self._session_user() or {}
            _body = self._body() if self.command in ("PUT", "DELETE") else {}
            _kwargs = {"request_id": getattr(self, "_rid", ""),
                       "ip": (self.client_address[0] if self.client_address else "")}
            if self.command == "PUT":
                _out = _dpr.put(_p, _u, _body)
            elif self.command == "DELETE":
                _out = _dpr.delete(_p, _u, _body, **_kwargs)
            else:
                _out = None
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
            return self._send(405, self._json({"error": "方法不支持",
                                               "code": "method_not_allowed"}))
        # T-75 知识库删除（DELETE）：删文件 / 删一级文件夹（均需 confirm=1）。
        if _p.startswith("/api/v1/knowledge/") and self.command == "DELETE":
            self._t0 = time.time()
            self._rid = uuid.uuid4().hex[:12]
            obs.bind(rid=self._rid)
            g = self._guard(self.command, _p)
            if g:
                return self._send(g[0], g[1])
            from app.api import knowledge_routes as _kr
            _out = _kr.delete(self, _p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
            return self._send(404, self._json({"error": "接口不存在", "code": "not_found"}))
        # 系统管理员：白名单反向判定（F-28）。业务/未知前缀的 PUT/PATCH/DELETE 一律
        # 与 POST 同口径 403；平台/IT 前缀与其他身份保持原有 405（HEAD 也走这里，
        # 但不执行 GET，仍 405）。
        try:
            _p = self.path.split("?", 1)[0]
            _u = self._session_user() or {}
            if (self.command in ("PUT", "PATCH", "DELETE")
                    and (_u.get("role") or "") == "super_admin"
                    and _super_admin_denied(self.command, _p)):
                return self._send(403, self._json({"error": "系统管理员不访问审核业务",
                                                   "code": "forbidden"}))
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        return self._send(405, self._json({"error": "方法不支持", "code": "method_not_allowed"}))

    do_DELETE = do_PUT
    do_PATCH = do_PUT
    do_OPTIONS = do_PUT

    def handle_one_request(self):
        try:  # finally 释放 P2-16 并发槽位（异常路径也不泄漏）
            super().handle_one_request()
        finally:
            _hg.release_slots(self)

    def do_HEAD(self):
        self._rid = uuid.uuid4().hex[:12]  # P2-15：/health+公开静态 200/空 body，其余 405
        _hg.head_ok(self)

    def _pagination(self):
        q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
        try:
            limit = min(int(q.get("limit", ["100"])[0]), 500)
            offset = max(int(q.get("offset", ["0"])[0]), 0)
        except ValueError:
            limit, offset = 100, 0
        return limit, offset

    def _valid_file(self, filename, data):
        ext = os.path.splitext(filename)[1].lower()
        if ext == ".xls":
            return False, "不支持旧版 .xls，请另存为 .xlsx"
        if ext not in (".xlsx", ".docx", ".pdf", ".txt", ".eml"):
            return False, f"不支持的文件类型 {ext or '(无扩展名)'}（支持 xlsx/docx/pdf/txt/eml）"
        if not data:
            return False, "文件为空，拒绝上传"
        if len(data) > MAX_FILE_BYTES:
            return False, f"单份文件超过 {MAX_FILE_BYTES // 1024 // 1024}MB 上限"
        return True, ""

    def _query(self) -> dict:
        """解析 query string 为扁平 dict（值取第一个）。"""
        raw = self.path.split("?", 1)[1] if "?" in self.path else ""
        q = urllib.parse.parse_qs(raw)
        return {k: (v[0] if v else "") for k, v in q.items()}

    def _body_raw(self):
        """读原始请求体（签名校验需要原始字节，且只能读一次）。"""
        if not hasattr(self, "_raw_body"):
            n = int(self.headers.get("Content-Length", 0))
            _max = _hg.max_upload_body_bytes()
            # 沙箱接收端是公开路径：在读取 body 之前就用 Content-Length 拦截超大请求，
            # 避免 300KB+ 甚至接近全局上限的匿名 body 被读入内存/参与 JSON 解析。
            if self.path.split("?")[0] == "/api/v1/open/sandbox":
                try:
                    from app.services import open as _open_svc
                    _cap = int(_open_svc.MAX_SANDBOX_BODY_BYTES)
                except Exception:
                    _cap = 256 * 1024
                if n > _cap:
                    self._raw_body = b""
                    self._body_too_large = True
                    self._body_limit_hit = _cap
                    self.close_connection = True
                    return self._raw_body
            if n > _max:
                self._raw_body = b""
                self._body_too_large = True
                return self._raw_body
            self._raw_body = self.rfile.read(n) if n else b""
        return self._raw_body

    def _body(self):
        raw = self._body_raw()
        try:
            v = json.loads(raw.decode("utf-8") or "{}")
            return v if isinstance(v, dict) else {}
        except Exception:
            logging.getLogger(__name__).warning("请求体不是合法 JSON，按空对象处理")
            return {}

    def _active_role(self) -> str:
        """当前会话选定的身份（多身份时可切换）。"""
        u = self._session_user() or {}
        return u.get("role") or _role_of(u.get("sub")) or ""

    def _session_user(self):
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        token = cookie.get("rp_session").value if cookie.get("rp_session") else ""
        # DU-02（P1，2026-11-25）：本方法可能被同一请求多次调用；每次重置失败标记，
        # 由 ``_guard``/``do_POST`` 统一消费（401/503），不允许静默放行。
        self._auth_fail = None
        u = auth.verify_session(token) if token else None
        row = {}
        if u:
            # 账号状态/会话版本：改密、管理员重置、停用、登出后旧 JWT 立即失效。
            # 旧 token 无 ver 视为 0；token_version 一旦 +1，旧 token 下一次请求即 401。
            try:
                row = R.users.get(u.get("sub", "")) or {}
            except Exception:
                # DU-02：读账号行失败必须 fail-closed（503），不能当作“行不存在/放行”。
                # 旧实现 ``except: row={}`` 会让 DB 故障窗口内的旧 token 继续可用 ≤1h。
                logging.getLogger(__name__).error(
                    "session account lookup failed（fail-closed，拒绝请求）sub=%s",
                    u.get("sub") or "-", exc_info=True)
                self._auth_fail = (503, self._json({
                    "error": "会话/账号校验服务异常，已拒绝请求（请稍后重试）",
                    "code": "session_check_failed"}))
                return None
            if (not row) and ("platform_op" in (u.get("roles") or [])
                              or u.get("role") == "platform_op"
                              or u.get("portal") == "platform"):
                # DU-02 回修：平台运营账号 tenant_id=NULL，UserRepo.get 受当前线程
                # 租户上下文影响会查不到（旧实现 row={} 跳过校验掩盖了此问题）。
                # 平台身份按 token sub 做一次无租户作用域的账号行读取，再用同一
                # 状态/版本校验；查不到仍走下面 401，不放宽删除/停用吊销。
                try:
                    with db.session() as _pc:
                        _prow = _pc.execute("SELECT * FROM user WHERE id=?",
                                            (u.get("sub", ""),)).fetchone()
                        row = dict(_prow) if _prow else {}
                except Exception:
                    row = {}
            if not row:
                # DU-02：账号被物理删除后行缺失 → 旧 JWT 立即 401。
                # 旧实现 ``if row: ...`` 整体跳过校验 → 已删除身份仍可业务访问至 exp；
                # 同时空行不得再回落 ``t-default`` 租户上下文（跨租户风险）。
                logging.getLogger(__name__).warning(
                    "session account missing（deleted or unknown）sub=%s → 401",
                    u.get("sub") or "-")
                self._auth_fail = (401, self._json({
                    "error": "账号不存在或已删除，请重新登录",
                    "code": "unauthorized"}))
                return None
            if (row.get("status") or "active") != "active":
                u = None
            elif int(u.get("ver") or 0) != int(row.get("token_version") or 0):
                u = None
        # S3：缓存本次请求已读到的账号行，供 _tenant_session_violation 复用
        # （避免每个请求为了拿 tenant_id 再查一次 users）。
        self._session_row = row
        # 每个请求按会话用户设置租户/空间上下文：上传、列表、审核都按当前空间落库与查询
        try:
            from app.services import ctx as _ctx
            if u:
                c = row
                ws_id = c.get("current_workspace_id") or "ws-default"
                _ctx.set_context(c.get("tenant_id") or "t-default", ws_id)
                obs.bind(user=u.get("sub") or "",
                         tenant=c.get("tenant_id") or "t-default")
            else:
                _ctx.set_context("", "")
                obs.bind(user="", tenant="")
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        return u

    def _tenant_session_violation(self, u):
        """S3：会话期租户状态校验（停用→401 disabled、过期→403）。

        与登录分支同源（``tenants.tenant_session_state``），避免“登录拦住了、会话没拦住”
        两套口径。平台身份（platform_op 不属任何租户）与外部身份（无 tenant_id）放行，
        由平台层其它门禁负责。拒绝时写审计（同租户 60s 内只记一条，防刷库）。

        性能：复用 ``_session_user`` 已读到的账号行（同一请求内缓存），
        避免每个请求多一次 ``users`` 查询。
        """
        from app.services import tenants as _tenants
        uid = str((u or {}).get("sub") or "")
        row = getattr(self, "_session_row", None)
        if row is None:
            row = R.users.get(uid) or {}
        tid = str(row.get("tenant_id") or (u or {}).get("tenant_id") or "")
        if not tid:
            return None
        state = _tenants.tenant_session_state(tid)
        if state.get("ok"):
            return None
        self._audit_tenant_deny(uid, tid, state)
        return int(state.get("http_status") or 401), self._json({
            "error": state.get("reason") or "所属租户不可用，会话已失效",
            "code": state.get("code") or "tenant_suspended"})

    def _audit_tenant_deny(self, uid: str, tenant_id: str, state: dict) -> None:
        """租户状态拒绝审计（限流：同 (租户, 状态) 60s 一条；失败不阻断拒绝）。"""
        key = f"{tenant_id}|{state.get('status') or ''}"
        now = time.time()
        with _TENANT_DENY_LOCK:
            last = _TENANT_DENY_SEEN.get(key, 0.0)
            if now - last < 60:
                return
            _TENANT_DENY_SEEN[key] = now
        try:
            R.audit_logs.log(actor=uid, action="auth.tenant_session_denied",
                             object=tenant_id,
                             after=f"{state.get('code') or ''}|{state.get('status') or ''}",
                             **self._audit_req_fields())
        except Exception:  # noqa: BLE001 - 审计失败不能把拒绝变成 200
            logging.getLogger(__name__).warning(
                "tenant session deny audit skipped tenant=%s", tenant_id, exc_info=True)

    def _idem_write(self, scope_path: str, body, fn):
        """C7（评审 P0 第二批）：写接口统一 ``Idempotency-Key`` 支持。

        修复前只有 ``POST /api/v1/reviews`` 支持幂等键，三个最高风险的裁决/复核接口
        （单条发现裁决、批量裁决、清单子要求复核）都没有：网络重试、双提交、网关重放
        会产生第二条裁决与第二条审计（C5 的 CAS 只能防“并发不同值”，防不住“同键重放”）。

        ``fn()`` 返回 ``(http_status, payload_bytes)``。第二次同键同体请求直接回放首次
        响应（不重复执行业务写、不重复审计）；同键不同体 409 ``idempotency_conflict``。
        缓存不可用时不阻断业务（``http_guard`` 内已只记 error 日志）。
        """
        key = str(self.headers.get("Idempotency-Key", "") or "").strip()
        if not key:
            return fn()
        u = self._session_user() or {}
        scope = _idem_scope(u, scope_path, body)
        cached = _idem_get(key)
        if cached:
            if len(cached) > 3 and cached[3] != scope:
                return 409, self._json({"error": "Idempotency-Key 已用于其他请求",
                                        "code": "idempotency_conflict"})
            return cached[1], cached[2]
        status, payload = fn()
        # 与 _send 的降级口径保持一致：200 但响应体带 error 的，按 400 处理，
        # 且只在真正成功时缓存（失败不留幂等记录，客户端可安全重试）。
        code = int(status or 200)
        try:
            _o = json.loads(payload.decode("utf-8")) if payload else {}
            if code == 200 and isinstance(_o, dict) and _o.get("error") and not _o.get("ok"):
                code = 400
        except Exception:  # noqa: BLE001
            pass
        if 200 <= code < 300:
            _idem_put(key, code, payload, scope)
        return status, payload

    def _case_owned(self, case_id):
        """数据范围：按项目所属空间校验；通过后把本次请求上下文切到项目空间。

        项目列表是跨空间展示的，但项目详情/证据/报告表带 workspace 过滤。
        如果这里不切上下文，打开其他空间的项目会出现“标题能打开、问题为空”。
        """
        u = self._session_user()
        if not u or not case_id:
            return False
        try:
            with db.session() as _c:
                _r = _c.execute("SELECT * FROM audit_case WHERE id=?", (case_id,)).fetchone()
                c = dict(_r) if _r else None
        except Exception:
            c = None
        if not c:
            return False
        try:
            from app.services import ctx as _cx
            _cur = _cx.get_context() or {}
            _tid = _cur.get("tenant_id") or ""
        except Exception:
            _tid = ""
        if _tid and c.get("tenant_id") and c.get("tenant_id") != _tid:
            return False
        if (u.get("role") or "") == "admin":
            ok = True
        elif (u.get("role") or "") == "super_admin":
            ok = False
        else:
            ok = c.get("created_by") == u.get("sub")
        if ok:
            try:
                from app.services import ctx as _cx2
                _cx2.set_context(c.get("tenant_id") or "t-default", c.get("workspace_id") or "ws-default")
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
        return ok

    # ---------------- 业务路由统一 typed ID 作用域 ----------------
    # 目标：业务 GET/POST 不再各自决定“查不到”和“无权限”的边界。
    # 所有错误都收敛为 resolver 的 404/403，未登录由 _guard 在解析前统一 401。
    def _resolve_id(self, kind, obj_id, user=None):
        """resolver 薄封装：返回 (row, None) 或 (None, (status, body))。

        P1（2026-11-22 节点穷举测试）：项目列表按产品口径跨空间汇总，但 resolver
        按「当前 session 空间」判权，导致打开其它空间的**自有**项目 403。这里在
        403 时先按对象所属 case 的空间切一次请求上下文再重判；_case_owned 只对
        本租户内本人（reviewer）/业务管理员（admin）放行，跨租户仍在首判 404，
        因此不放宽任何跨租户/跨人可见性。
        """
        from app.services import ids as _ids
        u = user if user is not None else (self._session_user() or {})
        try:
            return _ids.resolve(kind, obj_id, u), None
        except _ids.IDLookupError as e:
            if e.status == 403 and self._switch_to_object_case(kind, obj_id):
                try:
                    return _ids.resolve(kind, obj_id, u), None
                except _ids.IDLookupError as e2:
                    return None, (e2.status, {"error": e2.message, "code": e2.code})
            return None, (e.status, {"error": e.message, "code": e.code})

    def _switch_to_object_case(self, kind, obj_id) -> bool:
        """按业务对象所属 case 切请求上下文；返回是否已切（false=不可重判）。

        只用于「resolver 首判 403」后的跨空间重判：找到对象所属 case 后交给
        _case_owned 做租户 + 归属判定并顺带切上下文，不自行放宽权限。
        """
        kind = (kind or "").strip().lower()
        cid = ""
        try:
            if kind in ("case", "project"):
                cid = str(obj_id or "")
            elif kind == "report":
                cid = str((R.reports.get(obj_id) or {}).get("case_id") or "")
            elif kind == "finding":
                cid = str((R.findings.get(obj_id) or {}).get("case_id") or "")
            elif kind in ("document", "doc"):
                with db.session() as _c:
                    _r = _c.execute("SELECT case_id FROM case_document "
                                    "WHERE document_id=? LIMIT 1", (obj_id,)).fetchone()
                cid = str((_r["case_id"] if _r else "") or "")
        except Exception:  # 取不到所属 case 时保持原拒绝，不静默放行
            cid = ""
        return bool(cid) and self._case_owned(cid)

    def _send_deny(self, deny):
        return self._send(deny[0], self._json(deny[1]))

    def _business_write_denied(self, action: str = ""):
        """审核业务写第二道角色校验（F-28）：实现见 app.api.role_scope。"""
        return _business_write_denied_impl(self, action)

    def _feedback_scope(self, feedback_id: str):
        """feedback 统一作用域（F-12）：实现见 app.api.role_scope。"""
        return _feedback_scope_impl(self, feedback_id)

    def _case_scope(self, case_id, user=None):
        """case/project 统一入口：不存在/跨租户 404；无权限/跨空间 403。

        resolver 负责租户 + 空间 + 归属语义；_case_owned 负责把请求上下文切到
        项目所在空间，保证后续 report/findings/points 查询不会串空间。
        """
        u = user if user is not None else (self._session_user() or {})
        row, deny = self._resolve_id("case", case_id, u)
        if deny:
            return None, deny
        if not self._case_owned(case_id):
            return None, (403, {"error": "无权访问该项目", "code": "forbidden"})
        return row, None

    def _report_scope(self, report_id):
        """report 按真实 rep ID 读取，并补所属 case 的范围校验。

        resolver 的 report 分支不校验“case 已不可见/跨租户”（R.reports 无隔离列），
        业务路由必须再解析一次 case：跨租户/已删除 case → 404，他人 case → 403。
        """
        row, deny = self._resolve_id("report", report_id)
        if deny:
            return None, deny
        case, deny = self._resolve_id("case", row.get("case_id") or "")
        if deny:
            msg = "报告不存在" if deny[0] == 404 else "无权访问该报告"
            return None, (deny[0], {"error": msg, "code": deny[1].get("code") or "not_found"})
        return {**row, "case": case}, None

    def _task_scope(self, task_id):
        """task 统一入口：resolver 管 owner，业务路由再补租户与所属 case 范围。

        注意：resolver 本体对 task 只校验 owner（task.py 属其他 lane），因此跨租户
        任务不能只靠业务路由的 resolver 调用；这里补一层租户比较，避免跨租户可见。
        """
        from app.services import ids as _ids, ctx as _cx
        u = self._session_user() or {}
        try:
            row = _ids.resolve("task", task_id, u)
        except _ids.IDLookupError as e:
            return None, (e.status, {"error": e.message, "code": e.code})
        cur_tenant = ""
        try:
            cur_tenant = (_cx.get_context() or {}).get("tenant_id") or ""
        except Exception:
            cur_tenant = ""
        owner = str(row.get("owner") or "")
        if owner and cur_tenant:
            try:
                with db.session() as _c:
                    _r = _c.execute("SELECT tenant_id FROM user WHERE id=?", (owner,)).fetchone()
                if _r and (_r["tenant_id"] or "") and _r["tenant_id"] != cur_tenant:
                    return None, (404, {"error": "任务不存在", "code": "not_found"})
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
        cid = str(row.get("case_id") or "")
        if cid:
            # 跨空间项目下的任务同样按「对象所属 case」重判（P1，2026-11-22）。
            _case, _deny = self._resolve_id("case", cid, u)
            if _deny:
                msg = "任务不存在" if _deny[0] == 404 else "无权访问该任务"
                return None, (_deny[0], {"error": msg,
                                          "code": (_deny[1] or {}).get("code") or "forbidden"})
        return row, None

    # ---------------- 二级 ID（manifest_result / manifest_evidence / batch）------------
    _SECONDARY_LABELS = SECONDARY_LABELS

    def _secondary_resolve(self, kind, oid):
        return resolve_secondary_raw(kind, oid)

    def _secondary_case_deny(self, case, user, kind):
        return secondary_case_deny(case, user, kind)

    def _secondary_scope(self, kind, oid, user=None):
        """统一二级 ID 入口：先鉴权，再解析，再校验所属 case 作用域。"""
        u = user if user is not None else (self._session_user() or {})
        return resolve_secondary(kind, oid, u)

    def _visible_batch_ids(self, user=None):
        """当前用户可见的批次；review/coverage 无 batch 时不再回退全库。"""
        u = user if user is not None else (self._session_user() or {})
        if not u:
            return []
        try:
            with db.session() as c:
                runs = c.execute("SELECT case_id, batch_ids FROM audit_run "
                                 "WHERE COALESCE(batch_ids,'')<>''").fetchall()
                cases = {}
                _cids = sorted({str(r["case_id"] or "") for r in runs if r["case_id"]})
                if _cids:
                    _ph = ",".join("?" for _ in _cids)
                    for r in c.execute(f"SELECT * FROM audit_case WHERE id IN ({_ph})",
                                       tuple(_cids)).fetchall():
                        cases[str(r["id"])] = dict(r)
        except Exception:
            logging.getLogger(__name__).warning("可见批次解析失败", exc_info=True)
            return []
        out = []
        for r in runs:
            case = cases.get(str(r["case_id"] or ""))
            if not case:
                continue
            if self._secondary_case_deny(case, u, "batch"):
                continue
            for bid in str(r["batch_ids"] or "").split(","):
                bid = bid.strip()
                if bid and bid not in out:
                    out.append(bid)
        return out

    def _guard_fail(self, what: str):
        """P2-19：权限/账号校验异常时 fail-closed（503），不能吞异常后放行。"""
        logging.getLogger(__name__).error(
            "%s 校验异常（fail-closed，拒绝请求）", what, exc_info=True)
        return 503, self._json({"error": "权限/账号校验服务异常，已拒绝请求",
                                "code": "permission_check_failed"})

    def _guard(self, method, path):
        """返回 None 表示放行；否则返回 (http_code, body_bytes)。"""
        if path.startswith("/open/") or "/.well-known/" in path:
            return None
        u = self._session_user()
        # DU-02（P1）：会话/账号校验失败必须按 fail-closed 处理——
        #   账号行缺失（已删除）→ 401；DB 异常 → 503。
        # 公开页面（登录页/静态资源）仍放行，避免被删账号连重新登录入口都打不开；
        # /api/v1/me 是 _PUBLIC_GET，但业务处理分支自身会按 u=None 返回 401。
        _auth_fail = getattr(self, "_auth_fail", None)
        if _auth_fail and not (method in ("GET", "HEAD") and path in _PUBLIC_GET) \
                and path not in _PUBLIC_POST:
            return _auth_fail
        # 停用账号立即失效：只要有会话就校验状态（含公开路径）
        if u:
            try:
                row = R.users.get(u.get("sub", ""))
                # 外部身份（OIDC 首次登录尚未落库）不判定为停用；只有已存在的账号被停用才拦截
                if row and (row.get("status") or "active") != "active":
                    return 401, self._json({"error": "账号已停用", "code": "disabled"})
            except Exception:
                return self._guard_fail("账号停用状态")
        # S3（评审 P0 第二批）：租户停用/过期 → 已登录会话同样立即失效。
        # 修复前只校验 user.status，租户被停用后旧 cookie 仍能读业务数据直到 JWT 过期；
        # 现在与登录口径同源（tenants.tenant_session_state），并写审计留痕（限流防刷）。
        # 范围限定 /api/ 与写方法：静态页面/登录页必须仍可打开（租户被停用后用户需要
        # 换账号重新登录，不能把人锁在一个 401 JSON 上）。
        if u and (method not in ("GET", "HEAD") or path.startswith("/api/")):
            try:
                _tstate = self._tenant_session_violation(u)
            except Exception:
                return self._guard_fail("租户状态")
            if _tstate:
                return _tstate
        if method == "GET":
            if path in _PUBLIC_GET:
                return None
        else:
            if path in _PUBLIC_POST:
                return None
        if not u:
            return 401, self._json({"error": "未登录", "code": "unauthorized"})
        # L92（L88 G02/G08）：未知/悬空角色 fail-closed。修复前未知角色可回退 home
        # 菜单、拿空权限继续访问未接线的写路由；现在会话角色不在注册表四角色内时，
        # 只允许自身信息/退出，其余接口一律 403（不再静默放行）。
        try:
            from app.services import permission_registry as _preg
            _urole_pre = str(u.get("role") or "")
            if _urole_pre and not _preg.is_known_role(_urole_pre):
                _me_paths = ("/api/v1/me", "/api/v1/me/permissions", "/logout")
                if path not in _me_paths:
                    return 403, self._json({
                        "error": "未知角色（未注册），已拒绝访问",
                        "code": "forbidden"})
        except Exception:
            return self._guard_fail("角色注册表")
        # P2-05：架构图查看器/内部产物仅平台管理员；/architecture-assets/ 由下方
        # 登录校验兜底（不再免登录直出）。
        if path.startswith("/architecture/") and _hg.arch_denied(
                str(u.get("role") or ""), path):
            return 403, self._json({"error": "无权限访问架构图", "code": "forbidden"})
        # 首次登录/管理员重置后：改密前只允许自身信息、改密、权限、退出
        from app.services import password_policy as _pwp
        if _pwp.must_change_block(u, path):
            return 403, self._json({"error": "首次登录或临时密码必须先修改密码",
                                    "code": "password_change_required"})
        if u.get("role") == "platform_op":
            if not (path.startswith("/api/v1/platform/") or ("/architecture" in path) or path in
                    ("/api/v1/me", "/api/v1/me/permissions", "/api/v1/auth/login",
                     "/logout")):
                return 403, self._json({"error": "平台身份不可访问业务接口", "code": "forbidden"})
        # T-122：本体域读/写角色边界（服务端同口径）。
        # 用户口径「审核员不看本体」：/api/v1/ontology 与 /api/v1/ontology/* 的 GET/POST 一律 403，
        # 不能只靠菜单/前端路由；GET 也必须拒绝，否则 types/instances/links/alias_list、
        # workspace 统计、validate 报告、impact 影响面等会经只读接口泄露。
        # 业务管理员/系统管理员保持既有权限（系统管理员的业务只读白名单与写拒绝仍由 F-28 判定）。
        try:
            if path == "/api/v1/ontology" or path.startswith("/api/v1/ontology/"):
                from app.services import permissions as _onto_perms
                if _onto_perms.ontology_denied(u.get("role") or ""):
                    return 403, self._json({"error": "审核员不看本体（服务端已拒绝）", "code": "forbidden"})
        except Exception:
            return self._guard_fail("本体域角色")
        # T-126：企业词典与本体同属规则配置层，用户口径「审核员不看本体/企业词典」。
        # reviewer 对 /api/v1/terms 与 /api/v1/terms/* 的 GET/POST 一律 403（读也拒绝，
        # 避免 items/synonyms/not_equal/迁移预览/投影状态等经只读接口泄露）；
        # admin/super_admin 保持既有权限（super_admin 的只读白名单/写拒绝仍由 F-28 判定）。
        try:
            if path == "/api/v1/terms" or path.startswith("/api/v1/terms/"):
                from app.services import permissions as _terms_perms
                if _terms_perms.terms_denied(u.get("role") or ""):
                    # 写/确认/迁移沿用既有 403 文案（不改变既有 HTTP 契约）；
                    # 读接口（GET /api/v1/terms 等）用「审核员不看企业词典」明确角色边界。
                    _tp = path.rstrip("/")
                    if method != "GET" and method != "HEAD":
                        if _tp == "/api/v1/terms/migrate" or _tp.endswith("/terms/migrate"):
                            _tmsg = "只有管理员可迁移词典"
                        elif _tp.endswith("/confirm"):
                            _tmsg = "只有管理员可确认业务术语"
                        elif _tp == "/api/v1/terms" or _tp.endswith(("/update", "/delete")):
                            _tmsg = "只有管理员可维护业务术语"
                        else:
                            _tmsg = "审核员不看企业词典（服务端已拒绝）"
                    elif _tp == "/api/v1/terms/migrate/preview":
                        _tmsg = "只有管理员可迁移词典"
                    else:
                        _tmsg = "审核员不看企业词典（服务端已拒绝）"
                    return 403, self._json({"error": _tmsg, "code": "forbidden"})
        except Exception:
            return self._guard_fail("企业词典角色")
        # 账号管理仅系统管理员：业务管理员不能开号/看账号
        try:
            if path.startswith("/api/v1/users") and (u.get("role") or "") != "super_admin":
                return 403, self._json({"error": "账号管理仅系统管理员可用", "code": "forbidden"})
        except Exception:
            return self._guard_fail("账号管理角色")
        # 管理端两类管理员硬隔离：系统管理员可只读业务（B），业务管理员不碰 IT
        try:
            _role1 = u.get("role") or ""
            _it = ("/api/v1/open", "/api/v1/model", "/api/v1/agents", "/api/v1/audit-logs",
                   "/api/v1/users")
            if _role1 == "super_admin" and _super_admin_denied(method, path):
                # F-28 白名单反向判定：只放行平台/IT 域与明确列出的只读业务 GET，
                # 其余（含 evolution/rsi/qa/calibration/manifest/audit/scheduler 写）
                # 一律 403，不再依赖易漏的业务前缀黑名单。
                return 403, self._json({"error": "系统管理员不访问审核业务", "code": "forbidden"})
            if _role1 == "admin" and any(path.startswith(x) for x in _it):
                return 403, self._json({"error": "业务管理员不访问平台/IT 功能", "code": "forbidden"})
            # 通知配置是平台级全局单例（notify_setting id=global）：仅系统管理员可读写；
            # 业务管理员/审核员即使绕过页面直接调 API 也在此被拒（服务层还有第二道校验）。
            if path == "/api/v1/notify/config" and _role1 != "super_admin":
                return 403, self._json({"error": "仅系统管理员可配置消息", "code": "forbidden"})
        except Exception:
            return self._guard_fail("管理员边界")
        # 审核员可创建/提交规则，但发布/批准/回滚/归档仍是管理员
        try:
            _role0 = u.get("role") or ""
            _rp = path.rstrip("/").split("/")
            _ract = _rp[-1] if _rp else ""
            if _role0 not in ("admin", "super_admin") and path.startswith("/api/v1/rules/") \
                    and method == "POST" and _ract in ("approve", "publish", "delete"):
                return 403, self._json({"error": "无权限（规则发布需管理员）", "code": "forbidden"})
        except Exception:
            return self._guard_fail("规则发布角色")
        if u.get("role") not in ("admin", "super_admin"):
            if method == "GET":
                if path in _ADMIN_GET or any(path.startswith(x) for x in _ADMIN_GET_PREFIX):
                    return 403, self._json({"error": "无权限（需管理员）", "code": "forbidden"})
            else:
                if path in _ADMIN_POST or any(path.startswith(x) for x in _ADMIN_POST_PREFIX):
                    return 403, self._json({"error": "无权限（需管理员）", "code": "forbidden"})
        # 写操作按 action 校验：不能只靠前端隐藏按钮
        try:
            from app.services import permission as _pm
            _role = u.get("role") or ""
            _act = None
            if method == "POST":
                if path == "/api/v1/projects":
                    _act = "project.create"
                elif path.startswith("/api/v1/projects/") and path.endswith("/documents"):
                    _act = "project.upload"
                elif path.startswith("/api/v1/projects/") and (path.endswith("/audit") or path.endswith("/audit-async")):
                    _act = "audit.run"
                elif path.startswith("/api/v1/findings/") and (
                        path.endswith("/decision") or path.endswith("/batch-decision")
                        or path.endswith("/batch-undo")):
                    _act = "finding.decide"
            if _act and not _pm.can(_role, _act):
                return 403, self._json({"error": f"无权限（需 {_act}）", "code": "forbidden"})
        except Exception:
            return self._guard_fail("操作权限点")
        # 平台层身份白名单：权限全部属于 platform.* 的账号只能访问平台接口与自身信息
        if method in ("GET", "POST"):
            u = self._session_user() or {}
            sub = u.get("sub") or ""
            if sub:
                try:
                    from app.services import permissions as _pmw
                    perms = _pmw.of_user(sub)
                    if perms and all(x.startswith("platform.") for x in perms):
                        allowed = (path.startswith("/api/v1/platform/") or ("/architecture" in path) or path in
                                   ("/api/v1/me", "/api/v1/me/permissions",
                                    "/api/v1/auth/login", "/api/v1/ops/overview",
                                    "/logout"))
                        if not allowed:
                            return 403, self._json({"error": "平台身份不可访问业务接口", "code": "forbidden"})
                except Exception:
                    return self._guard_fail("平台身份白名单")
        return None

    def _report_gate(self, cid):
        """报告门禁（P0-5）：待复核 / 高严重度未签发 / unknown>0 / 解析缺口未接受。

        P1-04：fail-closed。门禁一旦无法计算（DB/服务异常），必须拒绝报告导出并
        返回 500，不能返回 None 放行；只有 check_gate 明确 ok 才继续导出。
        """
        try:
            from app.services import report as _report_mod
            res = _report_mod.check_gate(cid)
        except Exception as exc:  # noqa: BLE001 - 门禁计算失败必须 fail-closed
            logging.getLogger(__name__).error(
                "report gate check failed（fail-closed，拒绝导出）cid=%s: %s",
                cid, type(exc).__name__, exc_info=True)
            return self._err(500, "报告门禁计算失败，已拒绝导出（请稍后重试或联系管理员）",
                             "report_gate_failed")
        if not isinstance(res, dict):
            logging.getLogger(__name__).error(
                "report gate returned non-dict（fail-closed，拒绝导出）cid=%s type=%s",
                cid, type(res).__name__)
            return self._err(500, "报告门禁返回异常，已拒绝导出", "report_gate_failed")
        if res.get("ok"):
            return None
        reasons = res.get("reasons") or []
        if isinstance(reasons, str):
            reasons = [reasons]
        reasons = [str(x) for x in reasons if str(x or "").strip()]
        # L77：门禁给出机读错误码（audit_write_failed 等）时透传；否则保持 report_blocked 契约。
        _err_code = str(res.get("error_code") or "report_blocked")
        return self._err(409, "；".join(reasons) or "报告未满足放行条件", _err_code)

    def _set_session(self, user, token: str | None = None):
        token = token or auth.make_session(user)
        secure = _cookie_secure_attr()   # L147 P0-3：prod 默认强制 Secure（显式开关优先）
        self.send_header("Set-Cookie", f"rp_session={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=3600{secure}")

    # 本地演示便利开关：默认关闭；生产环境硬禁用。
    # 只有显式 RULEPROOF_TEST_AUTOLOGIN=1 且非 prod 时才允许入口自动登录。
    # 测试入口安全策略在 app/api/test_access.py；默认关闭、prod 硬禁用。
    def _test_auto_enabled(self):
        from app.api import test_access as _ta
        return _ta.enabled(self.client_address[0] if self.client_address else "")

    def _test_profile(self, kind):
        from app.api import test_access as _ta
        return _ta.profile(kind)

    def _redirect(self, location: str):
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _branded(self, filename, user=None):
        """读取静态页并按会话用户租户注入品牌（未登录/平台账号回退默认）。"""
        html = self._static(filename)
        uid = str((user or {}).get("sub") or "")
        if not uid:
            return html
        try:
            from app.services import tenants as _tn
            return _apply_branding_html(html, _tn.branding_for_user(uid))
        except Exception:
            logging.getLogger(__name__).debug("branded page skipped", exc_info=True)
            return html

    def _login_page(self, filename, query=None):
        """登录页：支持 ?tenant=CODE 服务端首屏品牌，无配置回退默认。"""
        html = self._static(filename)
        q = query or {}
        code = str((q.get("tenant") or [""])[0]).strip()
        if code:
            try:
                from app.services import tenants as _tn
                html = _apply_branding_html(html, _tn.get_tenant_branding(code))
            except Exception:
                logging.getLogger(__name__).debug("login branding skipped", exc_info=True)
        return self._send(200, html, "text/html; charset=utf-8")

    def _auto_entry(self, kind, filename):
        cur = self._session_user() or {}
        allowed = {"platform": {"platform_op"}, "system": {"super_admin"},
                   "business": {"admin"}, "reviewer": {"reviewer"}}[kind]
        if not self._test_auto_enabled():
            if cur and (cur.get("role") or "") not in allowed:
                target = {"super_admin": "/admin/system", "admin": "/admin/business",
                          "reviewer": "/reviewer", "platform_op": "/platform"}.get(cur.get("role") or "", "/login")
                return self._redirect(target)
            return self._send(200, self._branded(filename, cur), "text/html; charset=utf-8")
        _q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
        _switch = str((_q.get("switch") or [""])[0]).lower() in ("1", "true", "yes")
        if cur:
            if (cur.get("role") or "") in allowed:
                return self._send(200, self._branded(filename, cur), "text/html; charset=utf-8")
            # 测试入口显式带 ?switch=1 时允许切换测试账号；普通浏览器后退不带参数，仍按当前身份重定向。
            if _switch:
                prof = self._test_profile(kind)
                if prof:
                    return self._send_session(200, self._branded(filename, prof), prof, "text/html; charset=utf-8")
            target = {"super_admin": "/admin/system", "admin": "/admin/business",
                      "reviewer": "/reviewer", "platform_op": "/platform"}.get(cur.get("role") or "", "/login")
            return self._redirect(target)
        prof = self._test_profile(kind)
        if not prof:
            return self._send(200, self._branded(filename, cur), "text/html; charset=utf-8")
        return self._send_session(200, self._branded(filename, prof), prof, "text/html; charset=utf-8")

    def do_GET(self):
        obs.clear()
        _path0 = self.path.split("?")[0]
        # E-06（DuMate 20261118）：/favicon.ico 由浏览器自动发起，登录前无会话、登录后也无对应文件，
        # 原实现分别在登录前 401、登录后 404，污染控制台。这里放在 guard 之前直接 204。
        if _path0 in ("/favicon.ico", "/apple-touch-icon.png"):
            return self._send(204, b"", "image/x-icon")
        # GET 写入口统一 405（与 super_admin 只读判定同源：_GET_WRITE_SUFFIXES）。
        if _is_get_write_path(_path0):
            return self._send(405, self._json({"error": "写操作请使用 POST", "code": "method_not_allowed"}))
        # T-201（唯一 1 处注册）：/metrics（Prometheus 文本）+ /health（依赖状态）。
        # 指标采集/权限/渲染全部在 app/api/metrics_routes.py 与 app/services/metrics.py，
        # 这里只做一行路由注册，不改动其它 dispatch 逻辑。
        if _metrics_routes.handle(self, _path0):
            return
        # /rules/{code}/params 是写接口；/rules/params 是只读总览，不能一刀切
        if _path0.startswith("/api/v1/rules/") and _path0.endswith("/params") and _path0.count("/") == 5:
            return self._send(405, self._json({"error": "写操作请使用 POST", "code": "method_not_allowed"}))
        self._t0 = time.time()
        self._rid = uuid.uuid4().hex[:12]
        obs.bind(rid=self._rid)
        p = self.path.split("?")[0]
        q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
        # 进化回放/趋势：handler 内复用 _guard/_session_user，非该前缀直接放行到原路由
        if evolution.handle_http(self, "GET"):
            return
        # T-203 影子池 Phase2：与 evolution 同一注册位（guard 之前），handle 内部自带 guard。
        if _shadow_routes.handle(self, "GET"):
            return
        g = self._guard("GET", p)
        if g:
            return self._send(g[0], g[1])
        # L50 规则分组标签（只读）：GET /api/v1/rules/tags；实现见 rule_tag_routes.py。
        # 必须在通用 /api/v1/rules/ 兜底之外单独分发（否则会被当成规则 id 查成 404）。
        from app.api import rule_tag_routes as _rtr
        _rtr_out = _rtr.get(self, p, q)
        if _rtr_out is not None:
            return self._send(_rtr_out[0], self._json(_rtr_out[1]))
        # P1-7 Phase3 收尾（L11）：直连发现成本/延迟查询入口。
        # 服务层在 direct_draft（指标落库/聚合）与 dual_track_gateway（唯一入口）：
        #   GET /api/v1/shadow/direct-discovery/metrics?case_id=&run_id=&limit=
        #   GET /api/v1/shadow/direct-discovery/compare?case_id=&run_id=&limit=
        #   GET /api/v1/shadow/direct-discovery/claims?case_id=
        if p.rstrip("/") in ("/api/v1/shadow/direct-discovery/metrics",
                             "/api/v1/shadow/direct-discovery/compare",
                             "/api/v1/shadow/direct-discovery/claims"):
            from app.services import dual_track_gateway as _gw_ddm
            _q_ddm = self._query()
            _cid_ddm = str(_q_ddm.get("case_id") or _q_ddm.get("project_id") or "")
            if _cid_ddm and not R.cases.get(_cid_ddm):
                return self._err(404, "项目不存在", "not_found")
            _rid_ddm = str(_q_ddm.get("run_id") or "")
            try:
                _lim_ddm = int(_q_ddm.get("limit") or 20)
            except (TypeError, ValueError):
                _lim_ddm = 20
            if p.rstrip("/").endswith("/compare"):
                _out_ddm = _gw_ddm.direct_discovery_compare(
                    case_id=_cid_ddm, run_id=_rid_ddm, limit=_lim_ddm)
            elif p.rstrip("/").endswith("/claims"):
                _out_ddm = _gw_ddm.direct_discovery_claims(case_id=_cid_ddm)
            else:
                _out_ddm = _gw_ddm.direct_discovery_metrics(
                    case_id=_cid_ddm, run_id=_rid_ddm, limit=_lim_ddm)
            return self._send(200, self._json(_out_ddm))
        # T-177：空间准确率看板（GET，真实评测结果，空态不伪造）
        if p.rstrip("/") in ("/api/v1/workspace/accuracy",
                             "/api/v1/workspace/accuracy/coldstart"):
            from app.api import evolution_routes as _ev_acc
            _out = _ev_acc.get_accuracy(self, p, self._query())
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        # T-75 知识库（GET）：文件夹/文件列表 + 文件查看（inline/安全下载）。
        # 文件查看返回原始字节，不能走 _json；headers 由路由模块给出。
        if p == "/api/v1/knowledge" or p.startswith("/api/v1/knowledge/"):
            from app.api import knowledge_routes as _kr
            _out = _kr.get(self, p, self._query())
            if _out is not None:
                if len(_out) > 2 and isinstance(_out[1], (bytes, bytearray)):
                    _st, _body, _ctype = _out[0], _out[1], _out[2]
                    _hdr = _out[3] if len(_out) > 3 else {}
                    self.send_response(_st)
                    self.send_header("Content-Type", _ctype)
                    _hg.send_cors_header(self)   # F-03：知识库原始字节分支同样走白名单
                    self.send_header("X-Request-Id", getattr(self, "_rid", "-"))
                    for _k, _v in (_hdr or {}).items():
                        self.send_header(str(_k), str(_v))
                    self.send_header("Content-Length", str(len(_body)))
                    self.end_headers()
                    self.wfile.write(_body)
                    return
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/data-policy" or p.startswith("/api/v1/data-policy/"):
            from app.api import data_policy_routes as _dpr
            _out = _dpr.get(p, self._session_user() or {}, self._query())
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/ops/overview":
            from app.api import ops_routes as _opsr
            _out = _opsr.get(p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/public/tenant-branding":
            from app.api import tenant_config_routes as _tcr
            _out = _tcr.public_get(self._query())
            return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/page-guide/context":
            from app.api import page_guide_routes as _pgr
            _out = _pgr.get_context(self._session_user() or {}, self._query())
            return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/tenant/"):
            from app.api import tenant_config_routes as _tcr
            _out = _tcr.get(p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/platform/"):
            from app.api import platform_routes as _pr
            _out = _pr.get(p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/agents/health":
            # L14 A1：智能体健康看板（只读；须先于 /api/v1/agents 通用派发，避免被当成详情）
            from app.api import agents_routes as _ahr
            _out = _ahr.get(p, self._session_user() or {}, self._query())
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/agents"):
            from app.api import agent_routes as _ar
            _out = _ar.get(p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/notify/records":
            _u = self._session_user() or {}
            if (_u.get("role") or "") != "super_admin":
                return self._err(403, "仅系统管理员可查看通知触发记录", "forbidden")
            _st, _body = _notify_records(_u, q.get("limit", ["30"])[0])
            return self._send(_st, self._json(_body))
        if p.startswith(("/api/v1/notify", "/api/v1/notifications", "/api/v1/alerts")):
            from app.api import message_routes as _mr
            _out = _mr.get(p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/decision-tables"):
            if _module_off(self, "mod_decision_table"):
                return self._err(403, "该工作空间已关闭决策表模块", "module_off")
            from app.api import decision_routes as _dr
            _out = _dr.get(p, _ops_meta)
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        # L80 / P0-C 裁决来源统计只读接口（89 号 §6.1）：逐行台账 + 统计。
        # 权限与报告导出同源：_case_scope（跨租户 404 / 他人项目 403）+ 超管/平台 403。
        if (p.startswith(("/api/v1/reviews/", "/api/v1/projects/", "/api/v1/cases/"))
                and (p.endswith("/adjudication-ledger")
                     or p.endswith("/adjudication-stats"))):
            _parts = [x for x in p.split("/") if x]
            _cid = _parts[-2] if len(_parts) >= 2 else ""
            _case, _deny = self._case_scope(_cid)
            if _deny:
                return self._send_deny(_deny)
            _u_adj = self._session_user() or {}
            if (_u_adj.get("role") or "") in ("super_admin", "platform_op"):
                return self._err(403, "系统管理员不访问审核业务", "forbidden")
            from app.api import report_routes as _rr_adj
            _out_adj = _rr_adj.adjudication_get(
                p, _cid, q, True,
                actor=str(_u_adj.get("sub") or ""))
            if _out_adj is not None:
                return self._send(
                    _out_adj[0],
                    _out_adj[1] if isinstance(_out_adj[1], bytes) else self._json(_out_adj[1]),
                    _out_adj[2])
        if (p.startswith("/api/v1/runs/") and p.endswith("/adjudication-stats")):
            _parts_r = [x for x in p.split("/") if x]
            _rid_adj = _parts_r[-2] if len(_parts_r) >= 2 else ""
            _u_r = self._session_user() or {}
            if (_u_r.get("role") or "") in ("super_admin", "platform_op"):
                return self._err(403, "系统管理员不访问审核业务", "forbidden")
            try:
                with db.session() as _c_adj:
                    _row_adj = _c_adj.execute(
                        "SELECT case_id FROM audit_run WHERE id=?", (_rid_adj,)).fetchone()
                _cid_adj = str((_row_adj["case_id"] if _row_adj else "") or "")
            except Exception:
                _cid_adj = ""
            if not _cid_adj:
                return self._err(404, "审核批次不存在", "not_found")
            _case_adj, _deny_adj = self._case_scope(_cid_adj)
            if _deny_adj:
                return self._send_deny(_deny_adj)
            from app.api import report_routes as _rr_adj2
            _out_adj2 = _rr_adj2.adjudication_run_stats(_rid_adj, q)
            return self._send(
                _out_adj2[0],
                _out_adj2[1] if isinstance(_out_adj2[1], bytes) else self._json(_out_adj2[1]),
                _out_adj2[2])
        if p.startswith("/api/v1/reviews/") and p != "/api/v1/reviews/mine" and (p.endswith(("/report-status", "/report.docx", "/report.html", "/report.pdf")) or p.count("/") == 4):
            from app.api import report_routes as _rr
            _cid = p.split("/")[-2] if p.endswith(("/report-status", "/report.docx", "/report.html", "/report.pdf")) else p.split("/")[-1]
            # P1（L172 20261126）：必须先取会话身份，再 _case_scope 切到项目所属空间；
            # 顺序反过来时 _session_user() 会把 ctx 覆盖回「会话当前空间」，导致跨空间
            # report-status 把项目 findings 过滤成 0 → can_generate=true，导出也绕过门禁。
            _u_report = self._session_user() or {}
            _case, _deny = self._case_scope(_cid, user=_u_report)
            if _deny:
                return self._send_deny(_deny)
            _gate = None
            if p.endswith(("/report.docx", "/report.html", "/report.pdf")):
                if (_u_report.get("role") or "") != "reviewer":
                    return self._err(403, "报告导出仅审核员可执行", "forbidden")
                # T-81 D-03：PDF 报告导出已移除（产品口径，与 CLI 一致）。
                # 在门禁/渲染前明确禁用：不依赖 LibreOffice 环境，绝不进入
                # report.build_report_pdf，也不返回 200 application/pdf。
                if p.endswith("/report.pdf"):
                    return self._err(403, "PDF 报告导出已移除；请导出 DOCX 或 HTML",
                                     "pdf_export_removed")
                _gate = self._report_gate(_cid)
                if _gate:
                    return _gate
            _out = _rr.get(p, _cid, True, None,
                           actor=str(_u_report.get("sub") or ""),
                           role=str(_u_report.get("role") or ""))
            if _out is not None:
                return self._send(_out[0], _out[1] if isinstance(_out[1], bytes) else self._json(_out[1]), _out[2])
        if p == "/api/v1/reports":
            return _review_routes.get_reports(self, q)
        if p.startswith("/api/v1/reports/") and p.count("/") == 4:
            return _review_routes.get_report_detail(self, p)
        _v32 = _v32_route(p)
        if _v32:
            return _v32_dispatch(self, _v32, "GET")
        # T-51 隐藏疑似问题开关（GET）：跨项目指标 / 项目隐藏项摘要与打开 / 复核模式。
        if p.rstrip("/") == "/api/v1/hidden-metrics":
            return _hidden_metrics_dispatch(self)
        _ht_route = _hidden_toggle_route(p, "GET")
        if _ht_route:
            _ht_cid, _ht_kind, _ht_ident = _ht_route
            _case, _deny = self._case_scope(_ht_cid)
            if _deny:
                return self._send_deny(_deny)
            return _hidden_toggle_dispatch(self, _ht_cid, _ht_kind, _ht_ident)
        # T-43 人工复核闭环（GET）：工作台队列 / 后台对账 / 漏报列表。
        # 必须放在 projects 泛路由之前；权限统一由 human_review→review.authorize_case 判定。
        _hr_route = _human_review_route(p, "GET")
        if _hr_route:
            _hr_cid, _hr_kind = _hr_route
            _case, _deny = self._case_scope(_hr_cid)
            if _deny:
                return self._send_deny(_deny)
            return _human_review_dispatch(self, _hr_cid, _hr_kind)
        if p == "/api/v1/projects" or p.startswith("/api/v1/projects/"):
            # 文档文件读取先走统一 resolver：不存在的 case 返回 404 而不是 owned=False 的 403；
            # document 级 403/404 与 /api/v1/resolve/document 保持一致。
            if p.endswith("/file") and "/documents/" in p:
                _parts = p.strip("/").split("/")
                if len(_parts) >= 5:
                    _case, _deny = self._case_scope(_parts[-4])
                    if _deny:
                        return self._send_deny(_deny)
                    _doc, _deny = self._resolve_id("document", _parts[-2])
                    if _deny:
                        return self._send_deny(_deny)
            from app.api import project_routes as _pj_r
            _out = _pj_r.get(p, self._query(), self._session_user() or {}, self._case_owned)
            if _out is not None:
                return self._send(_out[0], _out[1] if isinstance(_out[1], bytes) else self._json(_out[1]), _out[2])
        if p == "/platform":
            return self._auto_entry("platform", "platform.html")
        if p == "/ops":
            _u = self._session_user() or {}
            if _u.get("role") != "super_admin":
                return self._send(403, self._json({"error": "运维看板仅系统管理员", "code": "forbidden"}),
                                  "application/json; charset=utf-8")
            return self._send(200, self._branded("ops.html", self._session_user()),
                              "text/html; charset=utf-8")
        if p == "/ops.js":
            return self._send(200, self._static("ops.js"),
                              "application/javascript; charset=utf-8")
        if p == "/rules/static-analysis":
            return self._send(200, self._branded("rule-analysis.html", self._session_user()),
                              "text/html; charset=utf-8")
        if p in ("/admin/system", "/admin/system/"):
            return self._auto_entry("system", "admin.html")
        if p in ("/admin/business", "/admin/business/"):
            return self._auto_entry("business", "index.html")
        if p in ("/admin/business/tenant-config", "/tenant-config"):
            return self._send(200, self._branded("tenant_config.html", self._session_user()),
                              "text/html; charset=utf-8")
        if p == "/admin":
            _u0 = self._session_user() or {}
            _f0 = "index.html" if (_u0.get("role") == "admin") else "admin.html"
            return self._send(200, self._branded(_f0, _u0), "text/html; charset=utf-8")
        if p == "/reviewer":
            return self._auto_entry("reviewer", "reviewer.html")
        if p in ("/platform/login", "/login-platform.html"):
            return self._login_page("login-platform.html", q)
        if p == "/platform.js":
            return self._send(200, self._static("platform.js"), "application/javascript; charset=utf-8")
        if p == "/branding.js":
            return self._send(200, self._static("branding.js"), "application/javascript; charset=utf-8")
        if p == "/tenant_config.js":
            return self._send(200, self._static("tenant_config.js"), "application/javascript; charset=utf-8")
        if p == "/settings_drawers.js":
            return self._send(200, self._static("settings_drawers.js"), "application/javascript; charset=utf-8")
        if p == "/settings_drawers.css":
            return self._send(200, self._static("settings_drawers.css"), "text/css; charset=utf-8")
        if p == "/ops.js":
            return self._send(200, self._static("ops.js"), "application/javascript; charset=utf-8")
        if p == "/ops.html":
            return self._send(200, self._static("ops.html"), "text/html; charset=utf-8")
        if p == "/page_guide.js":
            return self._send(200, self._static("page_guide.js"), "application/javascript; charset=utf-8")
        if p == "/page_guide.css":
            return self._send(200, self._static("page_guide.css"), "text/css; charset=utf-8")
        if p in ("/admin/system/login", "/login-admin-system.html"):
            return self._login_page("login-admin-system.html", q)
        if p in ("/admin/business/login", "/login-admin-business.html"):
            return self._login_page("login-admin-business.html", q)
        if p in ("/admin/login", "/login-admin.html"):
            return self._login_page("login-admin.html", q)
        if p in ("/reviewer/login", "/login-reviewer.html"):
            return self._login_page("login-reviewer.html", q)
        if p == "/login.css":
            return self._send(200, self._static("login.css"), "text/css; charset=utf-8")
        if p == "/login_bg.js":
            return self._send(200, self._static("login_bg.js"), "application/javascript; charset=utf-8")
        if p in ("/system-map", "/system_map.html"):
            return self._send(200, self._static("system_map.html"), "text/html; charset=utf-8")
        if p.startswith("/architecture/"):
            _rel = p[len("/architecture/"):].strip("/")
            # P2-05：内部 QA 产物（_qa/../*.png、结果 JSON、日志）禁止 HTTP 读取。
            if (not _rel or ".." in _rel.split("/") or _rel.startswith(".")
                    or "/_qa/" in ("/" + _rel + "/")):
                return self._send(404, b"not found", "text/plain; charset=utf-8")
            _base = os.path.realpath(os.path.join(WEB, "architecture"))
            _full = os.path.realpath(os.path.join(_base, _rel))
            if not _full.startswith(_base + os.sep) or not os.path.isfile(_full):
                return self._send(404, b"not found", "text/plain; charset=utf-8")
            _ext = os.path.splitext(_full)[1].lower()
            _ctype = {".html": "text/html; charset=utf-8", ".png": "image/png",
                      ".json": "application/json; charset=utf-8"}.get(_ext, "application/octet-stream")
            try:
                with open(_full, "rb") as _fh:
                    # P2-05/06：架构 HTML/资源禁嗅探、HTML CSP 收紧（纵深防御）。
                    return self._send(200, _fh.read(), _ctype,
                                      headers=_hg.arch_headers(_ext))
            except Exception:
                return self._send(404, b"not found", "text/plain; charset=utf-8")
        if p.startswith("/architecture-assets/"):
            _an = os.path.basename(p)
            # P2-05：空名/隐藏名/静态读取失败都必须返回 HTTP 响应（不能 return tuple 导致空响应）。
            if not _an or _an.startswith("."):
                return self._send(404, b"not found", "text/plain; charset=utf-8")
            try:
                return self._send(200, self._static("architecture_assets/" + _an), "image/jpeg")
            except Exception:
                return self._send(404, b"not found", "text/plain; charset=utf-8")
        if p == "/login":
            return self._login_page("login.html", q)
        if p in ("/login/sso", "/auth/sso"):
            # OIDC 登录发起：state 一次性、绑定到当前浏览器 cookie。
            # 之后 /callback 必须回传同一 state，否则拒绝（防登录 CSRF / 会话固定）。
            state = auth.new_oauth_state()
            secure = _cookie_secure_attr()   # L147 P0-3：state cookie 与 rp_session 同口径
            self.send_response(302)
            self.send_header("Location", auth.authorization_url(state))
            self.send_header("Set-Cookie",
                             f"{auth.OAUTH_STATE_COOKIE}={auth.sign_oauth_state(state)}; "
                             f"HttpOnly; SameSite=Lax; Path=/; Max-Age={auth.OAUTH_STATE_TTL}{secure}")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if p.endswith("/.well-known/openid-configuration"):
            if auth._is_prod():
                return self._err(404, "not found", "not_found")
            base = "http://" + self.headers.get("Host", "127.0.0.1:8765")
            return self._send(200, self._json({
                "issuer": base + "/mock-oidc",
                "authorization_endpoint": base + "/mock-oidc/authorize",
                "token_endpoint": base + "/mock-oidc/token",
                "response_types_supported": ["code"],
                "subject_types_supported": ["public"],
                "id_token_signing_alg_values_supported": ["HS256"]}))
        if p == "/mock-oidc/authorize":
            if auth._is_prod():
                return self._err(404, "not found", "not_found")
            # 内置 mock IdP：签发授权码（带用户 + 角色）→ 重定向回 redirect_uri
            role = q.get("login_hint", ["reviewer"])[0]
            if role not in ("admin", "reviewer"):
                role = "reviewer"
            name = "陈成" if role == "admin" else "审核员"
            _cfg = auth.oidc_config()
            code = auth.sign_jwt({"sub": "user-001" if role == "admin" else "user-002",
                                  "name": name, "email": "chencheng@example.com",
                                  "iss": _cfg["issuer"], "aud": _cfg["client_id"],
                                  "role": role, "exp": int(__import__("time").time()) + 300},
                                 _cfg["client_secret"])
            _allowed_redir = str(auth.oidc_config().get("redirect_uri") or "")
            redir = q.get("redirect_uri", [_allowed_redir])[0]
            if _allowed_redir and redir != _allowed_redir and not redir.startswith("/"):
                return self._err(400, "redirect_uri 不在白名单", "invalid_redirect")
            state = q.get("state", [""])[0]
            return self._redirect(f"{redir}?code={code}&state={state}")
        if p == "/callback":
            code = q.get("code", [""])[0]
            state = q.get("state", [""])[0]
            _ck = SimpleCookie(self.headers.get("Cookie", ""))
            _ckv = _ck.get(auth.OAUTH_STATE_COOKIE)
            signed_state = _ckv.value if _ckv else ""
            if not auth.verify_oauth_state(signed_state, state):
                # 缺 state / state 与浏览器 cookie 不匹配：直接拒绝且不签发任何会话。
                # 这同时阻止“拿他人 code 让受害者登录攻击者会话”的登录 CSRF。
                try:
                    R.audit_logs.log(actor="-", action="auth.oidc_rejected", object="callback",
                                     after=f"state_mismatch|has_cookie={bool(signed_state)}",
                                     **self._audit_req_fields())
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
                _body = self._json({"error": "state 校验失败：登录请求不属于当前浏览器会话",
                                    "code": "invalid_state"})
                self.send_response(400)
                self.send_header("Set-Cookie", f"{auth.OAUTH_STATE_COOKIE}=; HttpOnly; Path=/; Max-Age=0{_cookie_secure_attr()}")
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(_body)))
                self.end_headers()
                self.wfile.write(_body)
                return
            user = auth.exchange_code(code)
            if not user:
                return self._send(401, self._json({"error": "无效授权码"}))
            # E-02：先计算结果再写 302，签名失败时返回可读 JSON 500（避免空响应）
            try:
                _token = auth.make_session(user)
            except Exception as exc:
                return self._session_error_response(exc)
            self.send_response(302)
            self.send_header("Location", "/")
            # state 一次性：成功或失败都清掉 cookie，重放同一 callback URL 不再可用。
            self.send_header("Set-Cookie", f"{auth.OAUTH_STATE_COOKIE}=; HttpOnly; Path=/; Max-Age=0{_cookie_secure_attr()}")
            self._set_session(user, _token)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if p == "/logout":
            u = self._session_user()
            if u:
                # 登出即吊销该账号此前签发的全部 JWT：旧 cookie 重放不再可用。
                try:
                    auth.bump_token_version(u.get("sub", ""))
                except Exception:
                    logging.getLogger(__name__).warning("logout token_version bump failed", exc_info=True)
                R.audit_logs.log(actor=u.get("sub", ""), action="auth.logout",
                                 object=u.get("sub", ""), **self._audit_req_fields())
            self.send_response(302)
            self.send_header("Location", "/")
            self.send_header("Set-Cookie", f"rp_session=; HttpOnly; Path=/; Max-Age=0{_cookie_secure_attr()}")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if p.startswith("/api/v1/resolve/"):
            from app.services import ids as _ids
            _u = self._session_user() or {}
            _parts = p.split("/")
            _kind, _oid = _parts[-2], _parts[-1]
            if _kind in SECONDARY_KINDS:
                # 二级 ID 与 8 个主 kind 同一入口：未登录 401、不存在 404、
                # 他人/跨空间 403、跨租户 404，HTTP 与 CLI 结果一致。
                _obj, _deny = resolve_secondary(_kind, _oid, _u)
                if _deny:
                    return self._send_deny(_deny)
                return self._send(200, self._json({"ok": True, "kind": _kind,
                                                   "object": _obj}))
            try:
                return self._send(200, self._json({"ok": True, "kind": _kind,
                    "object": _ids.resolve(_kind, _oid, _u)}))
            except _ids.IDLookupError as e:
                return self._err(e.status, e.message, e.code)
        if p.startswith("/api/v1/manifest/results/") and p.endswith("/history"):
            _rid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_result", _rid)
            if _deny:
                return self._send_deny(_deny)
            from app.services import manifest_exec as _me
            return self._send(200, self._json(_me.history(_rid)))
        if p == "/api/v1/manifest/evidence":
            # 补证事项读取：CLI evidence list 与 HTTP 同一实现/同一作用域。
            _q = self._query()
            _payload, _deny = list_manifest_evidence(
                _q.get("result") or _q.get("result_id") or "", self._session_user() or {})
            if _deny:
                return self._send_deny(_deny)
            return self._send(200, self._json({"ok": True, **_payload}))
        if p == "/api/v1/terms":
            from app.api import terms_routes as _tm
            return self._send(200, self._json({"items": _tm.list_terms(q.get("status", [""])[0])}))
        if p == "/api/v1/terms/migrate/preview":
            u = self._session_user() or {}
            if (u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "只有管理员可迁移词典", "forbidden")
            from app.api import terms_routes as _tm
            _q = self._query()
            return self._send(200, self._json(_tm.preview_migration(
                actor=u.get("sub", ""), dry_run=True,
                all_spaces=str(_q.get("all_spaces", ["1"])[0]).lower() not in ("0", "false", "no"))))
        if p == "/api/v1/me/permissions":
            u = self._session_user() or {}
            return self._send(200, self._json(permission.permissions(u.get("role", "reviewer"))))
        if p == "/api/v1/tasks" or p.startswith("/api/v1/tasks/"):
            # 任务详情：统一 resolver + 租户/case 范围；列表仍走任务模块。
            if p != "/api/v1/tasks" and p.count("/") == 4:
                _trow, _deny = self._task_scope(p.split("/")[-1])
                if _deny:
                    return self._send_deny(_deny)
                return self._send(200, self._json(_trow))
            from app.api import task_routes as _tr
            _out = _tr.get(p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/me":
            u = self._session_user()
            if u:
                prof = R.users.get(u.get("sub")) or {}
                u = {**u,
                     "name": prof.get("name") or u.get("name", ""),
                     "username": prof.get("username") or "",
                     "phone": prof.get("phone") or "",
                     "email": prof.get("email") or u.get("email", ""),
                     "created_at": prof.get("created_at") or "",
                     "onboarded_at": prof.get("onboarded_at") or "",
                     "must_change_pwd": bool(prof.get("must_change_pwd")),
                     "portal": prof.get("portal") or account.portal_of_role(u.get("role") or _role_of(u.get("sub")) or "reviewer"),
                     "role": u.get("role") or _role_of(u.get("sub")) or "reviewer",
                     "roles": account.roles_of(u.get("sub"))}
                return self._send(200, self._json({"user": u}))
            return self._send(401, self._json({"error": "未登录"}))
        if p in ("/", "/index.html"):
            _u = self._session_user() or {}
            _r = _u.get("role") or ""
            if _r == "platform_op":
                return self._redirect("/platform")
            if _r == "super_admin":
                return self._redirect("/admin/system")
            if _r == "admin":
                return self._redirect("/admin/business")
            if _r == "reviewer":
                return self._redirect("/reviewer")
            return self._redirect("/login")
        if p == "/style.css":
            return self._send(200, self._static("style.css"), "text/css; charset=utf-8")
        if p == "/app.js":
            return self._send(200, self._static("app.js"), "application/javascript; charset=utf-8")
        if p == "/dict_view.js":
            return self._send(200, self._static("dict_view.js"), "application/javascript; charset=utf-8")
        if p == "/messages.js":
            return self._send(200, self._static("messages.js"), "application/javascript; charset=utf-8")
        if p == "/decision_tables.js":
            return self._send(200, self._static("decision_tables.js"), "application/javascript; charset=utf-8")
        if p == "/open_platform.js":
            return self._send(200, self._static("open_platform.js"), "application/javascript; charset=utf-8")
        if p == "/models.js":
            return self._send(200, self._static("models.js"), "application/javascript; charset=utf-8")
        if p == "/notify_config.js":
            return self._send(200, self._static("notify_config.js"), "application/javascript; charset=utf-8")
        if p == "/rule_intake.js":
            return self._send(200, self._static("rule_intake.js"), "application/javascript; charset=utf-8")
        if p == "/rule_mining.js":
            return self._send(200, self._static("rule_mining.js"), "application/javascript; charset=utf-8")
        if p == "/rules_view.js":
            return self._send(200, self._static("rules_view.js"), "application/javascript; charset=utf-8")
        if p == "/rule_detail_view.js":
            return self._send(200, self._static("rule_detail_view.js"), "application/javascript; charset=utf-8")
        if p == "/new_rule_view.js":
            return self._send(200, self._static("new_rule_view.js"), "application/javascript; charset=utf-8")
        if p == "/accuracy_board.js":
            return self._send(200, self._static("accuracy_board.js"), "application/javascript; charset=utf-8")
        if p == "/rule_file_intake.js":
            return self._send(200, self._static("rule_file_intake.js"), "application/javascript; charset=utf-8")
        if p == "/knowledge_base.js":
            return self._send(200, self._static("knowledge_base.js"), "application/javascript; charset=utf-8")
        if p == "/projects_view.js":
            return self._send(200, self._static("projects_view.js"), "application/javascript; charset=utf-8")
        if p == "/project_detail_view.js":
            return self._send(200, self._static("project_detail_view.js"), "application/javascript; charset=utf-8")
        if p == "/workbench_view.js":
            return self._send(200, self._static("workbench_view.js"), "application/javascript; charset=utf-8")
        if p == "/workbench_edit_view.js":
            return self._send(200, self._static("workbench_edit_view.js"), "application/javascript; charset=utf-8")
        if p == "/workbench_locate.js":
            return self._send(200, self._static("workbench_locate.js"), "application/javascript; charset=utf-8")
        if p == "/workbench_report.js":
            return self._send(200, self._static("workbench_report.js"), "application/javascript; charset=utf-8")
        if p == "/workbench_preview.js":
            return self._send(200, self._static("workbench_preview.js"), "application/javascript; charset=utf-8")
        if p == "/audit_progress.js":
            return self._send(200, self._static("audit_progress.js"), "application/javascript; charset=utf-8")
        if p == "/new_project_view.js":
            return self._send(200, self._static("new_project_view.js"), "application/javascript; charset=utf-8")
        if p == "/finding_list_view.js":
            return self._send(200, self._static("finding_list_view.js"), "application/javascript; charset=utf-8")
        if p == "/api/v1/rule/decompose":
            return self._err(405, "规则拆解只接受 POST", "method_not_allowed")
        if p == "/api/v1/rules/mechanism/calibration":
            from app.services import mechanism_calibration as _mcal
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可查看机制校准", "forbidden")
            return self._send(200, self._json(_mcal.stats()))
        if p == "/api/v1/rules/mechanism/negative-cards":
            from app.services import mechanism_graph as _mg_neg
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可查看反例卡", "forbidden")
            cards = _mg_neg.negative_cards(limit=500)
            return self._send(200, self._json({"ok": True, "count": len(cards), "items": cards}))
        if p == "/api/v1/rules/mechanism/feedback":
            from app.services import mechanism_mining as _mm_fb
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可挖掘客户反馈", "forbidden")
            q = self._query() or {}
            try:
                limit = int((q.get("limit") or ["200"])[0])
            except Exception:
                limit = 200
            out = _mm_fb.mine_from_feedback(limit=max(1, min(1000, limit)))
            out.pop("specs", None)
            return self._send(200, self._json(out))
        if p == "/api/v1/rules/mechanism/catalog":
            from app.services import mechanism_mining as _mm_cat
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可查看机制目录", "forbidden")
            _cat = Path(__file__).resolve().parents[2] / "seed" / "mechanisms" / "p01_catalog.json"
            try:
                _specs = _mm_cat.load_catalog(str(_cat))
            except Exception as e:
                return self._err(400, f"机制目录不可用：{e}", "invalid_catalog")
            _items = [{"point_id": x.point_id, "point_name": x.point_name,
                       "mechanisms": x.mechanisms, "evidence": x.evidence,
                       "applicability": x.applicability} for x in _specs]
            return self._send(200, self._json({"ok": True, "count": len(_items), "items": _items}))
        if p == "/api/v1/rules/mechanism/import":
            from app.services import mechanism_mining as _mm_imp
            from app.services.mechanism_mining import MechanismSpec as _MSpec
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可导入机制规则", "forbidden")
            b = self._body() or {}
            _items_in = b.get("items")
            if _items_in:
                _specs = []
                for x in _items_in if isinstance(_items_in, list) else []:
                    if not isinstance(x, dict) or not x.get("point_id"):
                        continue
                    _specs.append(_MSpec(point_id=str(x.get("point_id")), point_name=str(x.get("point_name") or x.get("point_id")),
                                         mechanisms=[str(m) for m in (x.get("mechanisms") or [])],
                                         evidence=[str(e) for e in (x.get("evidence") or [])],
                                         check_steps=str(x.get("check_steps") or ""),
                                         pass_criteria=str(x.get("pass_criteria") or ""),
                                         applicability=str(x.get("applicability") or "")))
            else:
                _cat = Path(__file__).resolve().parents[2] / "seed" / "mechanisms" / "p01_catalog.json"
                try:
                    _specs = _mm_imp.load_catalog(str(_cat))
                except Exception as e:
                    return self._err(400, f"机制目录不可用：{e}", "invalid_catalog")
            out = _mm_imp.materialize(_specs, publish=bool(b.get("publish")), by=u.get("sub", ""))
            return self._send(200 if out.get("ok") else 400, self._json(out))
        if _rulegen_dispatch(self, "GET"):
            return
        if p.startswith("/api/v1/rules/") and p.split("/")[-1] in ("update", "submit", "approve", "publish", "replay"):
            _rrow, _rdeny = _scoped_rule(p.split("/")[-2], self._session_user() or {})
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            from app.api import rule_routes as _rr
            _out = _rr.post(p, self._body() or {}, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/rules/") and p.endswith("/params/publish") and p.count("/") == 6:
            code = ruleparam.resolve_rule_code(p.split("/")[-3])
            u = self._session_user() or {}
            if not code:
                return self._err(404, "规则不存在", "not_found")
            if (u.get("role") or "") != "admin":
                return self._err(403, "审核员只能新建或查看规则；阈值发布需业务管理员", "forbidden")
            return self._send(200, self._json(ruleparam.publish(code, u.get("sub", "admin"))))
        if p.startswith("/api/v1/rules/") and p.endswith("/params/pending") and p.count("/") == 6:
            _raw = p.split("/")[-3]
            _rrow, _rdeny = _scoped_rule(_raw, self._session_user() or {})
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            code = str(_rrow.get("code") or "")
            if not code:
                return self._err(404, "规则不存在", "not_found")
            return self._send(200, self._json({"rule_code": code, "pending": ruleparam.pending(code)}))
        if p.startswith("/api/v1/rules/") and p.endswith("/params") and p.count("/") == 5:
            code = ruleparam.resolve_rule_code(p.split("/")[-2]); b = self._body(); u = self._session_user() or {}
            if not code:
                return self._err(404, "规则不存在", "not_found")
            if (u.get("role") or "") != "admin":
                return self._err(403, "审核员只能新建或查看规则；修改阈值需业务管理员", "forbidden")
            return self._send(200, self._json(ruleparam.update(code, **{k: v for k, v in b.items() if k in ("value", "op", "lo", "hi", "unit", "scope", "metric")})))
        if p == "/api/v1/rules/mine":
            from app.services import rule_mining
            u = self._session_user() or {}
            if (u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "仅管理员可执行规则挖掘", "forbidden")
            return self._send(200, self._json(rule_mining.mine(20)))
        if p == "/api/v1/rules/mine/draft":
            from app.services import rule_mining
            u = self._session_user() or {}
            if (u.get("role") or "") not in ("admin", "super_admin", "reviewer"):
                return self._err(403, "无权限创建规则草稿", "forbidden")
            b = self._body() or {}
            _draft = rule_mining.create_draft(
                b.get("title") or "", b.get("summary") or "", b.get("form") or "single",
                u.get("sub", ""), b.get("rule_code") or "")
            if _draft.get("rule_id"):
                # P1-B8-02：挖掘草稿此前 rule/rule_version 落库 + 通知管理员，但审计链断。
                # 与 /rules/custom 同源动作 rule.created，用 source 区分来源（mining）。
                try:
                    R.audit_logs.log(
                        actor=u.get("sub", "") or "system", action="rule.created",
                        object=str(_draft.get("rule_id")),
                        after=json.dumps({"source": "rule_mining",
                                          "title": b.get("title") or "",
                                          "rule_code": b.get("rule_code") or "",
                                          "existing": bool(_draft.get("existing")),
                                          "auto_published": False,
                                          "requires_human_confirm": True},
                                         ensure_ascii=False),
                        **self._audit_req_fields())
                except Exception:
                    logging.getLogger(__name__).error(
                        "rule mining draft audit failed rule_id=%s",
                        _draft.get("rule_id"), exc_info=True)
            return self._send(200, self._json(_draft))
        if p == "/api/v1/rules/batch":
            b = self._body()
            items = b.get("rules") or []
            u = self._session_user() or {}
            created = []
            skipped = []
            for it in items[:60]:
                try:
                    _src = it.get("source", "document_decompose")
                    _slots = it.get("slots") or {}
                    _crit = str(_slots.get("criterion") or (it.get("scope") or {}).get("criterion") or "")[:500]
                    # 文件/制度重复确认时幂等：同来源 + 同名称 + 同判据不重复落草稿
                    _dup = None
                    for _er in R.rules.list("source=?", (_src,)):
                        if (_er.get("name") or "") != it.get("name", "未命名规则"):
                            continue
                        try:
                            _ev = R.rules.latest_version(_er["id"]) or {}
                            _es = json.loads(_ev.get("slots_json") or "{}")
                        except Exception:
                            _es = {}
                        if str(_es.get("criterion") or "")[:500] == _crit:
                            _dup = _er
                            break
                    if _dup:
                        skipped.append({"rule_id": _dup.get("id"), "name": _dup.get("name"),
                                        "reason": "同来源同判据已存在"})
                        continue
                    r = rule.create_rule(
                        code=it.get("code") or f"RSI-{db.new_id('x')[:6].upper()}",
                        name=it.get("name", "未命名规则"), category=it.get("category", "consistency"),
                        rclass=it.get("rclass", "R4"), slots=_slots,
                        source=_src,
                        scope=it.get("scope") or {}, point_override=str(it.get("point_id") or ""))
                    _rr0 = R.rules.get(r.get("rule_id") or "") or {}
                    if _rr0:
                        _set_owner("rule", _rr0.get("code") or "", u.get("name") or u.get("sub", ""), u.get("sub", ""))
                    created.append(r)
                except Exception:
                    continue
            _ci0 = []
            try:
                for _it0 in created:
                    _hits0 = conflict.check_rule(_it0.get("rule_id") or "")
                    if _hits0:
                        _ci0.append({"rule_id": _it0.get("rule_id"), "conflicts": _hits0})
            except Exception:
                _ci0 = []
            R.audit_logs.log(actor=u.get("sub", ""), action="rule.batch_created",
                             after=str(len(created)), **self._audit_req_fields())
            return self._send(200, self._json({"created": len(created), "items": created,
                                               "skipped": skipped, "conflicts": _ci0}))
        if p == "/api/v1/rules/params":
            return self._send(200, self._json(ruleparam.list_all()))
        if p == "/api/v1/rules/static-analysis":
            from app.services import rule_static as _rst
            from app.services import ctx as _cxr
            _c = _cxr.get_context()
            return self._send(200, self._json(_rst.analyze(_c.get("workspace_id", ""))))
        if p == "/api/v1/rules/linkage":
            return self._send(200, self._json(rule.linkage()))
        if p == "/api/v1/rules/effective-select/diagnostics":
            # X-12 P0-2：回退一致性诊断（「切到 0 会掉出执行集的规则清单」）。
            # 仅业务管理员；返回诊断 + 修复工具 dry-run 计划（不写库）。
            _u_eff = self._session_user() or {}
            if str(_u_eff.get("role") or "") != "admin":
                return self._err(403, "生效口径诊断仅业务管理员可查看", "forbidden")
            try:
                _diag = rule.effective_selection_diff()
                _plan = rule.repair_effective_drift(dry_run=True)
            except Exception as exc:  # noqa: BLE001 - 诊断接口失败必须可见（不得静默空结果）
                logging.getLogger(__name__).error(
                    "生效口径诊断失败: %s", type(exc).__name__, exc_info=True)
                return self._err(500, "生效口径诊断失败（请检查数据库连接）",
                                 "effective_diagnostics_failed")
            return self._send(200, self._json({
                "ok": True, "diagnostics": _diag, "repair_plan": _plan,
                "repair_api": "POST /api/v1/rules/effective-select/repair-drift",
                "hint": ("开关=0 会静默移出 %d 条已发布规则；"
                         "可用 repair_plan/CLI `rp rule repair-drift --apply` 归位"
                         % _diag.get("dropped_count", 0))}))
        if p == "/api/v1/rules":
            # 兼容：无分页参数时返回数组；带 page/page_size 时返回信封
            _q0 = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
            _envelope = bool(_q0.get("page") or _q0.get("page_size"))
            limit, offset = self._pagination()
            if not _envelope:
                limit = max(limit, 1000)
            from app.services import rule_library as _rl
            allr = _rl.stats()
            # L50：分组标签过滤（组织维度；标签须在当前工作空间可见，否则 404）。
            # 与 scope.tags 路由标签不同域，仅过滤展示集合，不改变规则顺序/生效口径。
            _tag_id = (_q0.get("tag_id") or [""])[0]
            if _tag_id:
                allr = _rtr.filter_rules_by_tag(allr, _tag_id)
                if allr is None:
                    return self._err(404, "规则分组标签不存在或当前工作空间不可见", "not_found")
            page = allr[offset:offset + limit]
            meta = _ops_meta([x.get("code") or "" for x in page])
            for x in page:
                m = meta.get(x.get("code") or "", {})
                x["owner"] = x.get("owner") or m.get("owner") or ""
                x["department"] = account.department_of(x.get("owner") or "")
                x["updated_at"] = x.get("updated_at") or m.get("updated_at") or x.get("created_at") or ""
                x["records"] = m.get("records", 0)
                x["last_action"] = m.get("last_action", "")
            _rtr.attach_tags(page)
            if _envelope:
                _ps = int((_q0.get("page_size") or ["20"])[0] or 20)
                _pg = int((_q0.get("page") or ["1"])[0] or 1)
                _all = allr
                _page = _all[(_pg - 1) * _ps:_pg * _ps]
                _rtr.attach_tags(_page)
                return self._send(200, self._json({"items": _page, "total": len(_all),
                                                   "page": _pg, "page_size": _ps,
                                                   "pages": max(1, (len(_all) + _ps - 1) // _ps)}))
            return self._send(200, self._json(page))
        # B1/B2/B3（2026-11-20 外部对抗审查）：规则作用域数据巡检（只读）。
        # 列出历史无 scope 规则 / 隐式全量通配 / 伪造点位，供管理员补齐或执行隔离修复。
        if p == "/api/v1/rules/scope-anomalies":
            _au = self._session_user() or {}
            if (_au.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可查看规则作用域巡检", "forbidden")
            _q0 = self._query() or {}
            try:
                _lim = int((_q0.get("limit") or ["0"])[0] or 0)
            except (TypeError, ValueError):
                _lim = 0
            return self._send(200, self._json(rule.scope_data_anomalies(limit=_lim)))
        if p.startswith("/api/v1/rules/"):
            rid = p.split("/")[-1]
            if rid == "explain":
                # 规则解释与详情同一作用域：不存在/跨租户 404；同租户跨空间只读放行（L40 K7）。
                _rrow, _rdeny = rule.scoped_rule_read(p.split("/")[-2], self._session_user() or {})
                if _rdeny:
                    return self._send(_rdeny[0], self._json(_rdeny[1]))
                return self._send(200, self._json(explain(str(_rrow.get("id") or ""))))
            # 详情同时接受 rule id / code；不存在/跨租户一律 404（以前返回 200 {}）。
            _rrow, _rdeny = rule.scoped_rule_read(rid, self._session_user() or {})
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            from app.services import rule_detail as _rd
            return self._send(200, self._json(_rd.get(str(_rrow.get("id") or rid))))
        if p == "/api/v1/export/projects.csv":
            _body, _deny = build_projects_csv(
                self._session_user() or {}, **self._audit_req_fields())
            if _deny:
                return self._send_deny(_deny)
            return self._send(200, _body, "text/csv; charset=utf-8")
        if p == "/api/v1/export/findings.csv":
            _body, _deny = build_findings_csv(
                self._session_user() or {}, (q.get("case_id") or [""])[0],
                **self._audit_req_fields())
            if _deny:
                return self._send_deny(_deny)
            return self._send(200, _body, "text/csv; charset=utf-8")
        if p == "/api/v1/export/audit-records.csv":
            _body, _deny = build_audit_records_csv(
                self._session_user() or {}, q.get("from", [""])[0],
                q.get("to", [""])[0], q.get("reviewer", [""])[0],
                **self._audit_req_fields())
            if _deny:
                return self._send_deny(_deny)
            return self._send(200, _body, "text/csv; charset=utf-8")
        if p == "/api/v1/export/audit-logs.csv":
            return self._err(403, "审计日志只读，不提供导出", "forbidden")
        if p == "/api/v1/fs/list":
            # T-128 安全守卫：目录浏览只允许「项目上传目录 / 知识库上传目录」白名单，
            # 默认根不再是进程用户 home；管理员也不能列 home 或任意服务器目录。
            # 路径统一 realpath 校验，拒绝 .. 穿越与越界符号链接；越界 403 并写审计。
            import os as _os
            _fsu = self._session_user() or {}
            _fsrole = _role_of(_fsu.get("sub"))
            if _fsrole not in ("admin", "super_admin"):
                return self._err(403, "仅管理员可浏览目录", "forbidden")
            def _fs_roots():
                _roots = []
                try:
                    from app.services import identifiers as _ids
                    _roots.append(_ids.upload_root())
                except Exception:
                    logging.getLogger(__name__).warning(
                        "fs/list 上传白名单目录解析失败（已跳过该白名单根）", exc_info=True)
                try:
                    from app.services import knowledge as _kn
                    _roots.append(_os.path.realpath(str(_kn.ROOT)))
                except Exception:
                    logging.getLogger(__name__).warning(
                        "fs/list 知识库白名单目录解析失败（已跳过该白名单根）", exc_info=True)
                # 显式 RULEPROOF_FS_ROOT 仅在平台根内生效：不把 home/任意服务器目录纳入白名单。
                _cfg = (_os.environ.get("RULEPROOF_FS_ROOT") or "").strip()
                if _cfg:
                    try:
                        _pr = _os.path.realpath(config.PLATFORM_ROOT)
                        _cr = _os.path.realpath(_os.path.expanduser(_cfg))
                        if _cr == _pr or _cr.startswith(_pr + _os.sep):
                            _roots.append(_cr)
                    except Exception:
                        logging.getLogger(__name__).warning(
                            "fs/list RULEPROOF_FS_ROOT 解析失败（已忽略该显式根）", exc_info=True)
                _out = []
                for _r in _roots:
                    if _r and _r not in _out:
                        _out.append(_r)
                return _out
            _roots = _fs_roots()
            if not _roots:
                return self._err(503, "目录浏览白名单未配置", "fs_root_unconfigured")
            _home = _os.path.realpath(_os.path.expanduser("~"))
            def _fs_within(_real):
                return any(_real == _r or _real.startswith(_r + _os.sep) for _r in _roots)
            _default = next((_r for _r in _roots if _os.path.isdir(_r)), _roots[0])
            _want = (q.get("path", [""])[0] or "").strip() or _default
            try:
                _real = _os.path.realpath(_os.path.expanduser(_want))
            except Exception:
                return self._err(400, "非法路径", "invalid_path")
            if _real == _home or not _fs_within(_real):
                try:
                    R.audit_logs.log(actor=_fsu.get("sub", ""), action="fs.list_denied",
                                     object=str(_want)[:200],
                                     after=json.dumps({"reason": "out_of_whitelist", "role": _fsrole},
                                                      ensure_ascii=False),
                                     **self._audit_req_fields())
                except Exception:
                    logging.getLogger(__name__).debug('fs.list_denied audit skipped', exc_info=True)
                return self._err(403, "只能浏览项目/上传白名单目录", "forbidden")
            if not _os.path.isdir(_real):
                return self._err(400, "无法读取目录：目录不存在或不是文件夹", "invalid_directory")
            try:
                # 只列出仍落在白名单内的真实目录：越界符号链接不展示（访问时也会 403）。
                dirs = sorted([d for d in _os.listdir(_real)
                               if _os.path.isdir(_os.path.join(_real, d)) and not d.startswith(".")
                               and _fs_within(_os.path.realpath(_os.path.join(_real, d)))])
            except Exception as e:
                return self._err(400, f"无法读取目录：{type(e).__name__}", "invalid_directory")
            parent = _os.path.dirname(_real)
            if parent == _home or not _fs_within(parent):
                parent = ""
            _root = next((_r for _r in _roots if _real == _r or _real.startswith(_r + _os.sep)), _roots[0])
            return self._send(200, self._json({"path": _real, "root": _root, "parent": parent, "dirs": dirs}))
        if p == "/api/v1/audit-records":
            return _review_routes.get_audit_records(self, q)
        if p == "/api/v1/audit-logs.csv":
            return self._err(403, "审计日志只读，不提供导出", "forbidden")
        if p in ("/api/v1/audit-logs/trace", "/api/v1/audit-logs/reconcile"):
            u = self._session_user() or {}
            if u.get("role") != "super_admin":
                return self._err(403, "仅系统管理员可查看审计日志", "forbidden")
            if p.endswith("/reconcile"):
                _st, _body = _audit_reconcile(u)
                return self._send(_st, self._json(_body))
            _st, _body = _audit_object_trace(
                q.get("object", [""])[0], u, q.get("limit", ["50"])[0])
            return self._send(_st, self._json(_body))
        # T-201：审计导出状态（默认关闭；仅 super_admin/platform_op；GET 只读状态）。
        # 导出动作只允许 POST + 二次确认，见 do_POST 同名路由（服务层 app/services/audit_export.py）。
        if p in ("/api/v1/audit-logs/export/status", "/api/v1/platform/audit-export/status"):
            from app.api import audit_export_routes as _aex_status
            return _aex_status.handle_get(self)
        if p == "/api/v1/audit-logs":
            u = self._session_user() or {}
            if u.get("role") != "super_admin":
                return self._err(403, "仅系统管理员可查看审计日志", "forbidden")
            _q = q.get("q", [""])[0].strip()
            _result = q.get("result", [""])[0]
            _action = q.get("action", [""])[0]
            _actor = q.get("actor", [""])[0]
            try:
                _page = max(1, int(q.get("page", ["1"])[0] or 1))
            except Exception:
                _page = 1
            try:
                _size = min(100, max(5, int(q.get("page_size", ["20"])[0] or 20)))
            except Exception:
                _size = 20
            _r = audit.search_logs(_q, _result, _action, _actor,
                                   q.get("from", [""])[0], q.get("to", [""])[0],
                                   _size, (_page - 1) * _size,
                                   tenant_id=(u or {}).get("tenant_id") or "",
                                   workspace_id=(u or {}).get("workspace_id") or "")
            _total = _r.get("total", 0)
            return self._send(200, self._json({"logs": _r.get("items", []), "total": _total,
                                               "summary": _r.get("summary", {}),
                                               "page": _page, "page_size": _size,
                                               "pages": max(1, (int(_total) + _size - 1) // _size),
                                               "actions": audit.actions()}))
        if p.startswith("/api/v1/open/events/"):
            return _open_routes.get_open_event_detail(self, p)
        if p == "/api/v1/open/apps":
            return _open_routes.get_open_apps(self)
        if p == "/api/v1/open/events":
            return _open_routes.get_open_events(self, q)
        if p == "/api/v1/open/sandbox":
            return _open_routes.get_open_sandbox(self)
        if p.startswith("/open/v1/tasks/"):
            return _open_routes.get_open_task_detail(self, p)
        if p == "/api/v1/password-resets":
            u = self._session_user() or {}
            if u.get("role") != "super_admin":
                return self._err(403, "仅系统管理员可查看密码重置记录", "forbidden")
            from app.services import password_reset as _prl, ctx as _prx
            _tid = (_prx.get_context() or {}).get("tenant_id", "")
            return self._send(200, self._json({"items": _prl.list_resets(_tid, 100)}))
        if p == "/api/v1/users":
            _u = self._session_user() or {}
            _has_page = any(k in q for k in ("page", "page_size", "q", "role", "status"))
            if not _has_page:
                return self._send(200, self._json(_sanitize_users_payload(
                    account.list_users(self._active_role() or "", _u.get("sub", "")), _u)))
            try:
                _page = max(1, int(q.get("page", ["1"])[0] or 1))
            except Exception:
                _page = 1
            try:
                _size = min(100, max(5, int(q.get("page_size", ["20"])[0] or 20)))
            except Exception:
                _size = 20
            return self._send(200, self._json(_sanitize_users_payload(
                account.list_users_page(
                    self._active_role() or "", _u.get("sub", ""), q.get("q", [""])[0],
                    q.get("role", [""])[0], q.get("status", [""])[0], _page, _size), _u)))
        if p.startswith("/api/v1/users/") and p.endswith("/login-history"):
            _u = self._session_user() or {}
            if _u.get("role") != "super_admin":
                return self._err(403, "仅系统管理员可查看账号登录历史", "forbidden")
            _uid = p.split("/")[-2]
            _st, _body = _user_login_history(_uid, _u)
            return self._send(_st, self._json(_body))
        if p == "/api/v1/my-audits":
            return _review_routes.get_my_audits(self, q)
        if p == "/api/v1/analytics/issues.csv":
            _ucsv = self._session_user() or {}
            if _ucsv.get("role") == "reviewer":
                return self._err(403, "审核员首页不提供导出", "forbidden")
            from app.services import analytics as _an15
            from app.services import ctx as _cx15
            import csv as _csv, io as _io
            _c15 = _cx15.get_context()
            _u15 = self._session_user() or {}
            _w15 = "" if _u15.get("role") in ("admin", "reviewer") else _c15.get("workspace_id", "")
            _o15 = _u15.get("sub", "") if _u15.get("role") == "reviewer" else ""
            try:
                _qs15 = parse_qs(urlparse(self.path).query)
                _days15 = int((_qs15.get("days") or ["30"])[0])
            except Exception:
                _days15 = 30
            _d15 = _an15.summary(_w15, _c15.get("tenant_id", ""), _days15, _o15)
            buf = _io.StringIO(); w = _csv.writer(buf)
            w.writerow(["维度", "名称", "数量"])
            for x in _d15.get("top_rules") or []:
                w.writerow(["高频问题", (x.get("title") or x.get("code") or ""), x.get("count")])
            for x in _d15.get("faces") or []:
                w.writerow(["审核面", x.get("label") or x.get("face"), x.get("count")])
            for x in _d15.get("categories") or []:
                w.writerow(["规则类别", x.get("category"), x.get("count")])
            for x in _d15.get("sheets") or []:
                w.writerow(["文档位置", x.get("sheet"), x.get("count")])
            for x in _d15.get("recurring") or []:
                w.writerow(["重复出现", (x.get("title") or x.get("code") or ""), x.get("cases")])
            return self._send(200, buf.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8")
        if p == "/api/v1/analytics/issues":
            from app.services import analytics as _an
            from app.services import ctx as _cx9
            _c9 = _cx9.get_context()
            _u9 = self._session_user() or {}
            _wid9 = "" if _u9.get("role") in ("admin", "reviewer") else _c9.get("workspace_id", "")
            _owner9 = _u9.get("sub", "") if _u9.get("role") == "reviewer" else ""
            _days = 30
            try:
                from urllib.parse import urlparse, parse_qs
                _qs = parse_qs(urlparse(self.path).query)
                _days = int((_qs.get("days") or ["30"])[0])
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
            return self._send(200, self._json(_an.summary(_wid9,
                                                          _c9.get("tenant_id", ""), _days, _owner9)))
        if p == "/api/v1/workspaces/rules-review":
            from app.services import rules_review as _rr1, workspaces as _w13, ctx as _cx13
            _c13 = _cx13.get_context()
            return self._send(200, self._json(_rr1.check(_c13.get("workspace_id", ""))))
        if p == "/api/v1/workspaces/members":
            from app.services import workspaces as _wm, account as _am
            u = self._session_user() or {}
            _roles_m = set(_am.roles_of(u.get("sub", "")))
            if not (_roles_m & {"admin", "super_admin"}):
                return self._err(403, "仅业务管理员可查看空间成员", "forbidden")
            _urow_m = R.users.get(u.get("sub", "")) or {}
            return self._send(200, self._json({"items": _wm.member_options(
                _urow_m.get("tenant_id") or "t-default")}))
        if p == "/api/v1/workspaces/settings":
            from app.services import workspaces as _w5, account as _acc5
            u = self._session_user() or {}
            cur = _w5.current(u.get("sub", ""))
            q = self._query()
            _wsid5 = q.get("id") or cur.get("id", "")
            _target = _w5.get(_wsid5) if _wsid5 else {}
            if not _target:
                return self._err(404, "空间不存在或已归档", "not_found")
            _roles5 = set(_acc5.roles_of(u.get("sub", "")))
            _urow5 = R.users.get(u.get("sub", "")) or {}
            # 全局可见：同租户所有用户都能查看空间详情；编辑权限仍由 save 接口限制
            if _target.get("tenant_id") != (_urow5.get("tenant_id") or "t-default") and "super_admin" not in _roles5:
                return self._err(403, "不能查看其他租户的空间", "forbidden")
            return self._send(200, self._json({"workspace": _target,
                                               "settings": _w5.get_settings(_wsid5),
                                               "modules": _w5.modules(_wsid5)}))
        if p == "/api/v1/workspaces":
            from app.services import workspaces as _w
            u = self._session_user() or {}
            _urow = R.users.get(u.get("sub", "")) or {}
            return self._send(200, self._json({"items": _w.list_for(u.get("sub", ""),
                                                                   _urow.get("tenant_id") or "t-default"),
                                               "current": _w.current(u.get("sub", ""))}))
        if p == "/api/v1/doctypes":
            from app.services import doctypes as _dt
            return self._send(200, self._json(_dt.list_active()))
        if p == "/api/v1/doctypes/last":
            from app.services import doctypes as _dt
            q = self._query()
            scope = q.get("scope") or "project"
            sid = q.get("id") or ""
            return self._send(200, self._json(_dt.recall(scope, sid)))
        if (p == "/api/v1/points/detail"
                or (p.startswith("/api/v1/points/") and p.count("/") == 4)
                or p == "/api/v1/audit-points"
                or p.startswith("/api/v1/audit-points/")):
            from app.api import point_routes as _ptr
            _out = _ptr.get(self, p, q)
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/findings":
            return _review_routes.get_findings(self)
        if p.startswith("/api/v1/findings/") and p.count("/") == 4:
            return _review_routes.get_finding_detail(self, p)
        if p.startswith("/api/v1/findings/") and p.endswith("/provenance"):
            return _review_routes.get_finding_provenance(self, p)
        if p.startswith("/api/v1/findings/") and p.endswith("/root-cause"):
            return _review_routes.get_finding_root_cause(self, p)
        if p == "/api/v1/reviews":
            return _review_routes.get_reviews(self)
        if p == "/api/v1/reviews/mine":
            return _review_routes.get_reviews_mine(self)
        if p == "/api/v1/highlight":
            return _review_routes.get_highlight(self)
        if p == "/api/v1/conflicts":
            q = self._query()
            _u = self._session_user() or {}
            return self._send(200, self._json(conflict.list_conflicts(
                q.get("status", ""), all_spaces=False, user=_u)))
        if p.startswith("/api/v1/conflicts/") and p.count("/") == 4:
            # T-63 冲突聚合详情：冲突头 / A、B 完整规则快照（六组字段）/ 差异 /
            # 证据影响 / 裁决与历史 / 关联冲突 / 当前用户可裁范围。
            cid = p.split("/")[-1]
            try:
                return self._send(200, self._json(
                    conflict.get_detail(cid, self._session_user() or {})))
            except conflict.ConflictError as e:
                return self._err(e.status, e.message, e.code)
        if p == "/api/v1/eval":
            return self._send(200, self._json(eval_service.run_eval()))
        if p == "/api/v1/eval/multi":
            return self._send(200, self._json(eval_service.run_eval_multi()))
        if p == "/api/v1/scheduler":
            return self._send(200, self._json(scheduler.status()))
        if p == "/api/v1/feedback/mine":
            u = self._session_user() or {}
            return self._send(200, self._json({"items": feedback.list_mine(u.get("sub", ""))}))
        if p == "/api/v1/feedback":
            q = self._query()
            _items = feedback.list_feedback(q.get("kind", ""), q.get("status", ""))
            # P2 慢节点最小修：部门名一次批量查，替代逐条 department_of（原 N+1）。
            # 口径不变：仅按 actor_id 查（缺 actor_id 时旧实现等价查不到 → ""）。
            _dept = account.departments_of(
                [x.get("actor_id") or "" for x in _items])
            for _x in _items:
                _x["department"] = _dept.get(str(_x.get("actor_id") or ""), "")
            return self._send(200, self._json({
                "items": _items,
                "stats": feedback.stats(), "rules": feedback.rule_ledger()}))
        # T-197（P0-1/P0-2）：本体能力清单 + 空间开关。放在模块开关之前：
        # 管理员在「模块已关」时仍需要看到能力清单/开关状态并诊断（模块关≠能力开）。
        if p in ("/api/v1/ontology/capabilities", "/api/v1/ontology/switch"):
            return _ontology_routes.get_ontology_capabilities_switch(self, p, q)
        if p == "/api/v1/ontology/versions":
            return _ontology_routes.get_ontology_versions(self)
        if p.startswith("/api/v1/ontology/version/") and p.count("/") == 5:
            return _ontology_routes.get_ontology_version_detail(self, p)
        if p.startswith("/api/v1/ontology") and _module_off(self, "mod_ontology"):
            return self._err(403, "该工作空间已关闭本体模块", "module_off")
        if p.startswith("/api/v1/calibration") and _module_off(self, "mod_jev"):
            return self._err(403, "该工作空间已关闭 Jev 校准模块", "module_off")
        if p.startswith("/api/v1/agents") and p.endswith(("/run", "/update", "/publish")) and _module_off(self, "mod_agents"):
            return self._err(403, "该工作空间已关闭智能体模块", "module_off")
        if p.startswith("/api/v1/evolution") or p == "/api/v1/errorbook":
            from app.api import evolution_routes as _ev
            _out = _ev.get(self, p, q)
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/dashboard":
            return self._send(200, self._json(stats.dashboard()))
        if p.startswith("/api/v1/audit/"):
            cid = p.split("/")[-1]
            return self._send(200, self._json(stats.audit_summary(cid)))
        if p.startswith("/api/v1/trend/"):
            code = p.split("/")[-1]
            return self._send(200, self._json(stats.trend(code)))
        if p == "/api/v1/ontology/workspace":
            return _ontology_routes.get_ontology_workspace(self)
        if p == "/api/v1/ontology/validate":
            return _ontology_routes.get_ontology_validate(self)
        if p == "/api/v1/ontology":
            return _ontology_routes.get_ontology_graph(self)
        if p == "/api/v1/ontology/impact":
            return _ontology_routes.get_ontology_impact(self)
        if p == "/api/v1/events/stream":
            u = self._session_user()
            if not u:
                return self._err(401, "未登录", "unauthorized")
            return self._sse(u.get("sub", ""))
        if p.startswith("/api/v1/documents/") and p.count("/") == 4:
            return _review_routes.get_document_detail(self, p)
        if p == "/api/v1/audit-categories":
            cats = []
            try:
                lib = auditpoints.load()
                cats = [{"id": c.get("id"), "name": c.get("name")} for c in (lib.categories or [])]
            except Exception:
                cats = []
            if not cats:
                cats = [{"id": x, "name": y} for x, y in [
                    ("A", "主体、资格与程序"), ("B", "结构与内容完备"), ("C", "事实、数据与证据"),
                    ("D", "逻辑、论证与结论"), ("E", "权利义务与风险分配"),
                    ("F", "商务、执行与合规底线"), ("G", "披露、申报与绩效")]]
            return self._send(200, self._json(cats))
        if p.startswith("/api/v1/layout/") and p.count("/") == 4:
            did = p.split("/")[-1]
            drow, _deny = self._resolve_id("document", did)
            if _deny:
                return self._send_deny(_deny)
            from app.engine import layout as _ly
            return self._send(200, self._json(_ly.analyze(drow.get("path") or "")))
        if p.startswith("/api/v1/schema/") and p.count("/") == 4:
            # X-07 P2-2：数据字典/表结构属后台能力（含 user/audit_log/open_app 表清单），
            # 权限点 schema.view（业务管理员/系统管理员）；审核员 403（不能只靠菜单隐藏）。
            from app.services import permission as _pm_schema
            _u_schema = self._session_user() or {}
            if not _pm_schema.can(str(_u_schema.get("role") or ""), "schema.view"):
                return self._err(403, "数据字典仅业务管理员/系统管理员可访问", "forbidden")
            t = p.split("/")[-1]
            return self._send(200, self._json(schema_check.load_schema(t)))
        if p == "/api/v1/qa/sample":
            # DU-05（P1，2026-11-25）：抽样复核写路由无角色守卫——reviewer 实测
            # POST 200 并触发抽样写。抽样属于业务管理员的质量校准动作（judge 已仅
            # admin），现在 create 与 judge 同口径：admin + 服务层第二道角色校验，
            # 并把租户/空间显式传入（旧实现只传 actor，抽样范围依赖请求上下文）。
            b = self._body() or {}; u = self._session_user() or {}
            _d = self._business_write_denied("qa.sample")
            if _d:
                return _d
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可发起抽样复核", "forbidden")
            return self._send(200, self._json(qa_sample.create(
                int(b.get("percent", 10) or 10), u.get("sub", ""),
                tenant_id=_tenant_of_user(u),
                workspace_id=str(u.get("workspace_id") or ""))))
        if p.startswith("/api/v1/rsi/candidates/") and p.endswith("/rollback") and p.count("/") == 6:
            _d = self._business_write_denied("rsi.rollback")
            if _d:
                return _d
            cid = p.split("/")[-2]; u = self._session_user() or {}
            return self._send(200, self._json(rsi_protocol.rollback(cid, u.get("sub", ""))))
        if p == "/api/v1/rsi/frozen":
            _d = self._business_write_denied("rsi.frozen")
            if _d:
                return _d
            b = self._body()
            return self._send(200, self._json(rsi_protocol.set_frozen(
                bool(b.get("frozen")), by=(self._session_user() or {}).get("sub", ""))))
        if p.startswith("/api/v1/qa/samples/") and p.endswith("/judge") and p.count("/") == 6:
            _d = self._business_write_denied("qa.judge")
            if _d:
                return _d
            u = self._session_user() or {}
            # F-28：抽样复核判定属于审核业务写，系统管理员只读，业务管理员执行。
            if u.get("role") != "admin":
                return self._err(403, "仅业务管理员可判定抽样复核", "forbidden")
            sid = p.split("/")[-2]; b = self._body()
            return self._send(200, self._json(qa_sample.judge(
                sid, bool(b.get("agree")), b.get("note", ""), u.get("sub", ""),
                tenant_id=u.get("tenant_id") or "", workspace_id=u.get("workspace_id") or "")))
        if p == "/api/v1/scheduler/run":
            _d = self._business_write_denied("scheduler.run")
            if _d:
                return _d
            return self._send(200, self._json(scheduler.scan_once(force=True)))
        if p.startswith("/api/v1/feedback/") and p.endswith("/settle"):
            _d = self._business_write_denied("feedback.settle")
            if _d:
                return _d
            fid = p.split("/")[-2]
            # F-12：不存在/跨租户 404、他人项目 403；不能把“查不到”降级成 400/200。
            _fb, _fb_deny = self._feedback_scope(fid)
            if _fb_deny:
                return self._send_deny(_fb_deny)
            b = self._body()
            u = self._session_user() or {}
            # B5 修复（T-177）：透传 auto_publish（默认 False）。只有请求体显式 true 才在
            # 沉淀后立即发布；默认仍只生成草稿，人工到草稿箱点「发布生效」。
            _r = feedback.settle(fid, b.get("action", "revise"), b.get("note", ""),
                                 u.get("sub", ""),
                                 auto_publish=bool(b.get("auto_publish") is True))
            if _r.get("ok"):
                return self._send(200, self._json(_r))
            # 权限拒绝必须 403（AGENTS §3：前端隐藏≠权限，服务端 403）；其余按服务层
            # http_status 映射（LaneR B2：结构缺失可补=422 needs_structure，其余 400）。
            _code = (403 if (_r.get("status") == 403 or _r.get("code") == "forbidden")
                     else int(_r.get("http_status") or 400))
            return self._send(_code, self._json(_r))
        if p == "/api/v1/models/effective":
            return self._send(200, self._json(model.effective()))
        if p == "/api/v1/models":
            _lm = model.list_models()
            # 四态可用性随列表返回：enabled 只是管理开关，页面必须按四态展示。
            _lm["availability"] = model.availability(_lm.get("items") or [])
            # L147 P0-3：api_key_masked 不得回显 enc1 密文/明文片段。
            return self._send(200, self._json(_scrub_model_key_masks(_lm)))
        if p == "/api/v1/models/presets":
            return self._send(200, self._json(model.PRESET_MODELS))
        if p == "/api/v1/model/config":
            return self._send(200, self._json(model.config_info()))
        if p == "/api/v1/model/points":
            return self._send(200, self._json(model.points()))
        if p == "/api/v1/rsi/candidates":
            return self._send(200, self._json({"items": rsi_protocol.list_candidates(self._query().get("rule", ""))}))
        if p.startswith("/api/v1/documents/") and p.endswith("/parse-report") and p.count("/") == 5:
            return _review_routes.get_document_parse_report(self, p)
        if p == "/api/v1/review/coverage":
            return _review_routes.get_review_coverage(self)
        # L155：Extractor-Verifier 只读校验端点（策略读取；校验见 do_POST 同名注册）。
        # 幂等/只读：不写库、不写审计；权限走 _guard + review_routes 第二道角色确认。
        if p == "/api/v1/extraction/confidence-policy":
            return _review_routes.get_extraction_confidence_policy(self)
        if p == "/api/v1/qa/samples":
            _u = self._session_user() or {}
            if _u.get("role") not in ("admin", "super_admin"):
                return self._err(403, "仅管理员可查看抽样复核", "forbidden")
            q = self._query()
            return self._send(200, self._json({
                "items": qa_sample.list_samples(q.get("status", ""), tenant_id=_u.get("tenant_id") or "", workspace_id=_u.get("workspace_id") or ""),
                "stats": qa_sample.stats(tenant_id=_u.get("tenant_id") or "", workspace_id=_u.get("workspace_id") or "")}))
        if p == "/api/v1/calibration/config":
            try:
                return self._send(200, self._json({"min_accuracy": calibration.min_accuracy_f(),
                                                   "threshold": calibration.threshold_for()}))
            except Exception as e:
                return self._err(400, str(e), "calibration_error")
        if p == "/api/v1/calibration/rules":
            return self._send(200, self._json(calibration.by_rule()))
        if p == "/api/v1/calibration":
            return self._send(200, self._json(calibration.summary()))
        if p == "/api/v1/system/capabilities":
            from app.engine import ocr as _ocr
            try:
                _cal = calibration.summary()
            except Exception:
                _cal = {}
            # P2-B5-01：前端「最多 3 份文件」写死、服务端上限 10 份 → 口径分裂。
            # 这里把服务端真实上限下发（单一事实源 = project.MAX_FILES），
            # 前端文案与预校验都读同一个数字，不再各自硬编码。
            try:
                from app.services import project as _pj_cap
                _limits = {"max_files": int(_pj_cap.MAX_FILES),
                           "max_file_mb": int(_pj_cap.MAX_FILE_BYTES // 1024 // 1024),
                           "max_total_mb": int(_pj_cap.MAX_TOTAL_BYTES // 1024 // 1024)}
            except Exception:
                _limits = {}
            return self._send(200, self._json({"ocr": _ocr.status(),
                                                "limits": _limits,
                                                "calibration": {"samples": _cal.get("samples", 0)}}))
        if p == "/api/v1/home":
            _hu = self._session_user() or {}
            if _hu.get("role") in ("admin", "reviewer"):
                try:
                    from app.services import ctx as _cxh
                    _ch = _cxh.get_context()
                    _cxh.set_context(_ch.get("tenant_id") or "t-default", "")
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
            return self._send(200, self._json(_decorate_home(home.home(_hu), _hu)))
        if p == "/health":
            return self._send(200, self._json({"ok": True, "app": config.APP_NAME, "version": config.APP_VERSION}))
        return self._err(404, "not found")

    def do_POST(self):
        obs.clear()
        _p0 = self.path.split("?")[0]
        # P2-16：分级请求体上限 + chunked 明确 411（避免边解析边吃内存）。
        if not _p0.startswith("/api/v1/open/sandbox"):
            _cap, _kind = _hg.post_body_cap(_p0)
            try:
                _clen = int(self.headers.get("Content-Length", 0) or 0)
            except Exception:
                _clen = -1
            if _clen < 0 or (_clen == 0 and str(
                    self.headers.get("Transfer-Encoding") or "").lower() == "chunked"):
                self.close_connection = True
                return self._send(411, self._json({
                    "error": "必须提供合法 Content-Length（不支持 chunked 大请求体）",
                    "code": "length_required"}))
            if _cap is not None and _clen > _cap:
                self.close_connection = True
                return self._send(413, self._json({
                    "error": (f"请求体过大：{_clen / 1024 / 1024:.1f}MB 超过 "
                              f"{_cap / 1024 / 1024:.0f}MB 上限（普通接口 "
                              f"{_hg.max_json_body_bytes() // 1024 // 1024}MB；单文件上传上限 100MB，"
                              "base64 编码后约 134MB）"),
                    "code": "payload_too_large", "limit_bytes": _cap,
                    "received_bytes": _clen}))
            if not _hg.acquire_slot(self, "write"):
                return self._send(503, self._json({
                    "error": "服务繁忙（并发写入已达上限），请稍后重试",
                    "code": "server_busy"}))
            if _kind == "upload" and not _hg.acquire_slot(self, "upload"):
                return self._send(429, self._json({
                    "error": "同时进行的文件上传过多，请稍后重试",
                    "code": "too_many_uploads"}))
        # 进化回滚建议：handler 内复用 _guard/_session_user，非该前缀直接放行到原路由
        if evolution.handle_http(self, "POST"):
            return
        # T-203 影子池 Phase2：escalate 需在未登录时校验调度令牌，故必须早于未登录 401。
        if _shadow_routes.handle(self, "POST"):
            return
        # 未登录必须在任何对象解析/请求体处理之前统一 401：
        # 否则不存在的对象返回 404、存在的对象返回 403/继续处理，会被用来探测存在性。
        if _p0.startswith("/api/v1/") and _p0 not in _PUBLIC_POST:
            _u0 = self._session_user()
            # DU-02：账号已删除 → 401；DB 异常 → 503（fail-closed，不能降级成“未登录”）
            if getattr(self, "_auth_fail", None):
                return self._send(*self._auth_fail)
            if not _u0:
                return self._err(401, "未登录", "unauthorized")
        if _p0 == "/api/v1/terms/migrate" or _p0 == "/api/v1/terms" or (
                _p0.startswith("/api/v1/terms/") and _p0.endswith(("/update", "/delete", "/confirm"))):
            # terms 动作层在 _guard 之前：先执行与其它写接口相同的停用/改密/角色检查。
            # platform_op 由 terms 路由自己的管理员门禁拒绝，保留既有错误文案。
            _u0 = self._session_user() or {}
            if (_u0.get("role") or "") != "platform_op":
                _g = self._guard("POST", _p0)
                if _g:
                    return self._send(*_g)
        if _p0 == "/api/v1/page-guide/chat":
            from app.api import page_guide_routes as _pgr
            _g = self._guard("POST", _p0)
            if _g:
                return self._send(*_g)
            _out = _pgr.post_chat(self._session_user() or {}, self._body() or {})
            return self._send(_out[0], self._json(_out[1]))
        if _p0 == "/api/v1/terms/migrate":
            _u = self._session_user() or {}
            if (_u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "只有管理员可迁移词典", "forbidden")
            _b = self._body() or {}
            from app.api import terms_routes as _tm
            _r = _tm.migrate(_u.get("sub", ""), dry_run=bool(_b.get("dry_run")),
                             all_spaces=bool(_b.get("all_spaces")))
            return self._send(200 if _r.get("ok") else 400, self._json(_r))
        if _p0.startswith("/api/v1/terms/") and (_p0.endswith("/update") or _p0.endswith("/delete")):
            _u = self._session_user() or {}
            if (_u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "只有管理员可维护业务术语", "forbidden")
            _tid = _p0.split("/")[-2]
            from app.api import terms_routes as _tm
            if _p0.endswith("/delete"):
                _r = _tm.delete_term(_tid, _u.get("sub", ""))
            else:
                _r = _tm.update_term(_tid, self._body() or {}, _u.get("sub", ""))
            return self._send(int(_r.get("http_status") or (200 if _r.get("ok") else 400)), self._json(_r))
        if _p0 == "/api/v1/terms":
            _u = self._session_user() or {}
            if (_u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "只有管理员可维护业务术语", "forbidden")
            _b = self._body() or {}
            from app.api import terms_routes as _tm
            _r = _tm.create_term(_b.get("name") or "", _b.get("definition") or "",
                                 _b.get("synonyms") or [], _b.get("not_equal") or [],
                                 _b.get("source") or "", _b.get("scope") or "",
                                 _b.get("key") or "", _u.get("sub", ""),
                                 _b.get("entity_type") or "", _b.get("unit") or "",
                                 _b.get("relations") or [])
            return self._send(int(_r.get("http_status") or (200 if _r.get("ok") else 400)), self._json(_r))
        if _p0.startswith("/api/v1/terms/") and _p0.endswith("/confirm"):
            _u = self._session_user() or {}
            if (_u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "只有管理员可确认业务术语", "forbidden")
            _tid = _p0.split("/")[-2]
            from app.api import terms_routes as _tm
            _r = _tm.confirm(_tid, _u.get("sub", ""))
            return self._send(200 if _r.get("ok") else 404, self._json(_r))
        # L108：`POST /api/v1/agents/workflow/run` 必须走统一 _guard 之后再派发。
        # 旧实现放在 _guard 之前，只查 role∈(admin,super_admin) → 业务管理员可绕过
        # IT 隔离执行 7 智能体 DAG（L106 G3）。统一 guard 后：admin 由 IT 隔离 403、
        # reviewer 由服务层同源权限 agent.manage 403；审计 actor 用真实会话 uid。
        # T-197（P0-1/P0-2）：本体开关 / 能力入口（L110 删除零消费者的自动评估/影子标签 HTTP 面）。
        # 放在模块开关 guard 之前：模块关只关「本体 API 消费」，配置/诊断入口仍需可达。
        if _p0 in ("/api/v1/ontology/switch", "/api/v1/ontology/capabilities"):
            return _ontology_routes.post_ontology_capabilities(self, _p0, _scoped_rule)
        for _pre, _mod, _msg in (("/api/v1/ontology", "mod_ontology", "本体"),
                                  ("/api/v1/calibration", "mod_jev", "Jev 校准"),
                                  ("/api/v1/decision-tables", "mod_decision_table", "决策表")):
            if _p0.startswith(_pre) and _module_off(self, _mod):
                return self._send(403, self._json({"error": f"该工作空间已关闭{_msg}模块", "code": "module_off"}))
        if _p0.startswith("/api/v1/agents/") and _p0.endswith(("/run", "/update", "/publish")) and _module_off(self, "mod_agents"):
            return self._send(403, self._json({"error": "该工作空间已关闭智能体模块", "code": "module_off"}))
        # T-75 知识库写入口（建文件夹 / multipart 上传）必须在统一 JSON 校验之前分发：
        # multipart 请求体不是 JSON，不能被下面的非法 JSON 校验误判。
        if _p0 == "/api/v1/knowledge/folders" or _p0 == "/api/v1/knowledge/files":
            _g = self._guard("POST", _p0)
            if _g:
                return self._send(*_g)
            from app.api import knowledge_routes as _kr
            _out = _kr.post(self, _p0, self._session_user() or {})
            return self._send(_out[0], self._json(_out[1]))
        if self._body_raw():
            try:
                json.loads(self._body_raw().decode("utf-8") or "{}")
            except Exception:
                return self._send(400, self._json({"error": "请求体不是合法 JSON", "code": "invalid_json"}))
        self._t0 = time.time()
        self._rid = uuid.uuid4().hex[:12]
        obs.bind(rid=self._rid)
        p = self.path.split("?")[0]
        g = self._guard("POST", p)
        if g:
            return self._send(g[0], g[1])
        # L94（2026-11-24）：报告签发/导出唯一写入口
        #   POST /api/v1/reports/{report_id}/sign   —— 签发（幂等；report.signed 审计）
        #   POST /api/v1/reports/{report_id}/export —— 导出（要求已签发；report.exported 审计）
        # 对象范围走 _report_scope（跨租户 404 / 他人 403）；无报告行时允许按 case id
        # 进入服务层返回机读 report_not_generated（而不是笼统 404），便于 CLI/HTTP 同源排障。
        if p.startswith("/api/v1/reports/") and p.count("/") == 5 \
                and p.endswith(("/sign", "/export")):
            from app.api import report_routes as _rr_entry
            _action = p.rsplit("/", 1)[-1]
            _rid = p.split("/")[-2]
            _row, _deny = self._report_scope(_rid)
            if _deny:
                # 无 report 行：尝试按 case id 走服务层报告 0 行错误码（未知对象仍 404）
                _case, _cdeny = self._case_scope(_rid)
                if _cdeny:
                    return self._send_deny(_deny)
                _entry = _rr_entry.post_entry(
                    _action, "", _rid, self._session_user() or {},
                    self._body() or {}, self._query())
            else:
                _entry = _rr_entry.post_entry(
                    _action, str(_row.get("id") or _rid),
                    str(_row.get("case_id") or ""), self._session_user() or {},
                    self._body() or {}, self._query())
            if _entry is not None:
                _st, _payload = _entry[0], _entry[1]
                _ct = _entry[2] if len(_entry) > 2 else "application/json; charset=utf-8"
                _hd = _entry[3] if len(_entry) > 3 else None
                _body_bytes = (_payload if isinstance(_payload, (bytes, bytearray))
                               else self._json(_payload))
                return self._send(_st, _body_bytes, _ct, _hd)
        # L50 规则分组标签（写）：POST /api/v1/rules/tags[/<id>/rename|delete|assign|unassign|full-audit]；
        # 标签 CRUD/打标/自检逻辑与权限/审计全部在 rule_tag_routes.py + services/rule_tags.py。
        from app.api import rule_tag_routes as _rtr
        _rtr_out = _rtr.post(self, p)
        if _rtr_out is not None:
            return self._send(_rtr_out[0], self._json(_rtr_out[1]))
        # T-201：审计导出（POST，必须 confirm=true；默认关闭；仅 super_admin/platform_op；
        # 每次导出写审计 audit.exported 并带水印列）。权限/开关/水印全部在服务层。
        if p in ("/api/v1/audit-logs/export", "/api/v1/platform/audit-export"):
            from app.api import audit_export_routes as _aex_post
            return _aex_post.handle_post(self)
        # T-177：空间准确率看板（POST 记录一轮评测结果；admin/evo.manage）
        if p.rstrip("/") == "/api/v1/workspace/accuracy/rounds":
            from app.api import evolution_routes as _ev_acc
            _out = _ev_acc.post_accuracy(self, p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/data-policy/"):
            from app.api import data_policy_routes as _dpr
            _out = _dpr.post(p, self._session_user() or {}, self._body(),
                             request_id=getattr(self, "_rid", ""),
                             ip=(self.client_address[0] if self.client_address else ""))
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
            return self._send(404, self._json({"error": "接口不存在", "code": "not_found"}))
        # 二级 ID（result/evidence/batch）必须在 _guard 之后解析：未登录统一 401，
        # 且不能靠 404/403 差异探测对象是否存在。
        if p.startswith("/api/v1/manifest/results/") and p.endswith("/history"):
            _rid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_result", _rid)
            if _deny:
                return self._send_deny(_deny)
            from app.services import manifest_exec as _me
            return self._send(200, self._json(_me.history(_rid)))
        if p.startswith("/api/v1/manifest/evidence/") and p.endswith("/review"):
            _d = self._business_write_denied("manifest.evidence.review")
            if _d:
                return _d
            _eid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_evidence", _eid)
            if _deny:
                return self._send_deny(_deny)
            _b = self._body() or {}
            _nrid = str((_obj.get("evidence") or {}).get("new_result_id") or "")
            if not _nrid:
                return self._err(400, "补证尚未重判，不能复核", "not_reaudited")
            _nobj, _ndeny = self._secondary_scope("manifest_result", _nrid)
            if _ndeny or not _nobj or _nobj.get("case_id") != _obj.get("case_id"):
                return self._err(404, "审核结果不存在", "not_found")
            _u = self._session_user() or {}
            from app.services import manifest_exec as _me
            _r = _me.decide(_nrid, _b.get("status") or "", _b.get("reason") or "",
                            _u.get("sub", ""), _u.get("role", ""))
            return self._send(200 if _r.get("ok") else 400, self._json(_r))
        if p.startswith("/api/v1/manifest/evidence/") and p.endswith("/reaudit"):
            _d = self._business_write_denied("manifest.evidence.reaudit")
            if _d:
                return _d
            _eid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_evidence", _eid)
            if _deny:
                return self._send_deny(_deny)
            _u = self._session_user() or {}
            from app.services import manifest_exec as _me
            _r = _me.reaudit_evidence(_eid, _u.get("sub", ""), _u.get("role", ""))
            return self._send(200 if _r.get("ok") else 400, self._json(_r))
        if p.startswith("/api/v1/manifest/evidence/") and p.endswith("/fulfill"):
            _d = self._business_write_denied("manifest.evidence.fulfill")
            if _d:
                return _d
            _eid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_evidence", _eid)
            if _deny:
                return self._send_deny(_deny)
            _u = self._session_user() or {}
            _b = self._body() or {}
            from app.services import manifest_exec as _me
            _r = _me.fulfill_evidence(_eid, _b.get("evidence_ref") or "",
                                      _u.get("sub", ""), _u.get("role", ""))
            return self._send(200 if _r.get("ok") else 400, self._json(_r))
        if p.startswith("/api/v1/manifest/results/") and p.endswith("/evidence-request"):
            _d = self._business_write_denied("manifest.result.evidence-request")
            if _d:
                return _d
            _rid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_result", _rid)
            if _deny:
                return self._send_deny(_deny)
            _u = self._session_user() or {}
            _b = self._body() or {}
            from app.services import manifest_exec as _me
            _r = _me.request_evidence(_rid, _b.get("reason") or "", _u.get("sub", ""),
                                      _u.get("role", ""), _b.get("checklist") or [])
            return self._send(200 if _r.get("ok") else 400, self._json(_r))
        if p.startswith("/api/v1/manifest/results/") and p.endswith("/decision"):
            _d = self._business_write_denied("manifest.result.decision")
            if _d:
                return _d
            _rid = p.split("/")[-2]
            _obj, _deny = self._secondary_scope("manifest_result", _rid)
            if _deny:
                return self._send_deny(_deny)
            _b = self._body() or {}
            def _do_manifest(_rid=_rid, _b=_b):
                _u = self._session_user() or {}
                from app.services import manifest_exec as _me
                _r = _me.decide(_rid, _b.get("status") or "", _b.get("reason") or "",
                                _u.get("sub", ""), _u.get("role", ""))
                _code = 200 if _r.get("ok") else int(_r.get("status") or 400)
                return _code, self._json(_r)
            # C7：清单子要求复核（可被“补证重判”链式重试）→ 支持 Idempotency-Key
            _st, _pl = self._idem_write(f"POST:{p}", _b, _do_manifest)
            return self._send(_st, _pl)
        if (p == "/api/v1/audit-points/confirm"
                or p == "/api/v1/audit-points/execute"
                or p == "/api/v1/audit-points/batch"      # L95：批量执行（POST 语义）
                or p == "/api/v1/audit-points/prepare-migration"
                or p == "/api/v1/audit-points/activate-confirm"
                or p == "/api/v1/audit-points/confirm-recommended"):
            from app.api import point_routes as _ptr
            _out = _ptr.post(self, p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        # finding/task 的存在性与归属解析必须在 _guard 之后：
        # 未登录请求先统一 401，避免用 404/403 差异探测对象是否存在。
        # P2-2 批量裁决路由没有单个 finding id，先于 id resolver 分发。
        if p in ("/api/v1/findings/batch-decision", "/api/v1/findings/batch-undo"):
            from app.api import finding_routes as _frb
            _bb = self._body() or {}
            def _do_batch(_p=p, _b=_bb):
                _o = _frb.post(_p, _b, self._session_user() or {},
                               self._case_owned, self._active_role())
                if _o is None:
                    return 404, self._json({"error": "not_found", "code": "not_found"})
                return _o[0], self._json(_o[1])
            if p == "/api/v1/findings/batch-decision":
                # C7：批量裁决（一次改多条结论/多条审计）→ 支持 Idempotency-Key，
                # 网关重试不会把同一批裁决执行两遍（第二次直接回放首次响应）。
                _st, _pl = self._idem_write(f"POST:{p}", _bb, _do_batch)
                return self._send(_st, _pl)
            _outb = _frb.post(p, _bb, self._session_user() or {},
                              self._case_owned, self._active_role())
            if _outb is not None:
                return self._send(_outb[0], self._json(_outb[1]))
        if p.startswith("/api/v1/findings/"):
            _fid = p.split("/")[-2] if p.endswith(("/decision", "/provenance", "/sediment", "/update", "/delete", "/reject", "/evidence")) else p.split("/")[-1]
            # P1（2026-11-22）：finding 属 case 级对象；走统一 _resolve_id 以便打开
            # 跨空间自有项目时按所属 case 切上下文再判权（跨租户仍 404，不放宽）。
            _frow, _fdeny = self._resolve_id("finding", _fid, self._session_user() or {})
            if _fdeny:
                return self._err(_fdeny[0], (_fdeny[1] or {}).get("error") or "无权访问该发现",
                                 (_fdeny[1] or {}).get("code") or "forbidden")
        if p.startswith("/api/v1/tasks/") and p.endswith("/cancel"):
            _tid = p.split("/")[-2]
            _u = self._session_user() or {}
            _trow, _deny = self._task_scope(_tid)
            if _deny:
                return self._send_deny(_deny)
            _r = task.cancel(_tid, actor=_u.get("sub", ""))
            return self._send(200 if _r.get("ok") else 400, self._json(_r))
        if p.startswith("/api/v1/tenant/"):
            from app.api import tenant_config_routes as _tcr
            _out = _tcr.post(p, self._session_user() or {}, self._body() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/platform/"):
            from app.api import platform_routes as _pr
            _out = _pr.post(p, self._session_user() or {}, self._body() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/agents/workflow/run":
            # L108：统一 _guard 之后派发（旧实现早于 _guard → 业务管理员 200 绕过 IT 隔离）。
            # 权限与服务层/HTTP 其它 agents 写入口同源：agent.manage（当前仅系统管理员持有）；
            # admin 已由 _guard 的 IT 隔离 403、reviewer/platform_op 由 _guard/permission 403。
            from app.services import permissions as _wf_perms
            _u_wf = self._session_user() or {}
            if not _wf_perms.has(str(_u_wf.get("sub") or ""), "agent.manage"):
                return self._err(403, "无权限执行 DAG 工作流（需 agent.manage）", "forbidden")
            _b_wf = self._body() or {}
            _actor_wf = str(_u_wf.get("sub") or "")
            from app.services import agent_handlers as _ah_wf
            from app.services import agent_workflow as _aw_wf
            _h_wf = _ah_wf.build(case_id=_b_wf.get("case_id") or "",
                                 path=_b_wf.get("path") or "",
                                 text=_b_wf.get("text") or "",
                                 points=_b_wf.get("points") or [],
                                 policy_text=_b_wf.get("policy_text") or "",
                                 rule_code=_b_wf.get("rule_code") or "",
                                 feedback_id=_b_wf.get("feedback_id") or "",
                                 actor=_actor_wf)
            _r_wf = _aw_wf.run(_b_wf, handlers=_h_wf, actor=_actor_wf)
            # 入口级审计：谁触发了 DAG、执行了多少节点/是否失败；内部 agent.run 审计
            # 由 run_agent 用同一 actor 写（不再出现 system）。
            try:
                from app import repositories as _R_wf
                _R_wf.audit_logs.log(
                    actor=_actor_wf, action="agent.workflow_run", object="workflow",
                    after=json.dumps({"case_id": _b_wf.get("case_id") or "",
                                      "trace": len(_r_wf.get("trace") or []),
                                      "ok": bool(_r_wf.get("ok")),
                                      "failed": _r_wf.get("failed") or []},
                                     ensure_ascii=False),
                    **self._audit_req_fields())
            except Exception:  # noqa: BLE001 - 入口审计失败不伪造成功，但要留诊断
                logging.getLogger(__name__).warning(
                    "agent.workflow_run audit write failed", exc_info=True)
            return self._send(200, self._json(_r_wf))
        if p.startswith("/api/v1/agents/"):
            from app.api import agent_routes as _ar
            _out = _ar.post(p, self._session_user() or {}, self._body() or {},
                            blocked=_module_off(self, "mod_agents"))
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/notify/test":
            _u = self._session_user() or {}
            if _u.get("role") != "super_admin":
                return self._err(403, "仅系统管理员可测试通知", "forbidden")
            _st, _body = _notify_test_send(_u, self._body() or {},
                                           **self._audit_req_fields())
            return self._send(_st, self._json(_body))
        if p.startswith(("/api/v1/notify", "/api/v1/notifications")):
            from app.api import message_routes as _mr
            _out = _mr.post(p, self._session_user() or {}, self._body() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/decision-tables"):
            if _module_off(self, "mod_decision_table"):
                return self._err(403, "该工作空间已关闭决策表模块", "module_off")
            from app.api import decision_routes as _dr
            _out = _dr.post(p, self._body() or {}, self._session_user() or {}, _set_owner)
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/projects/") and p.endswith("/point-stale") and p.count("/") == 5:
            return _review_routes.post_project_point_stale(self, p)
        if p.startswith("/api/v1/projects/") and p.endswith(("/documents", "/audit", "/audit-async")):
            _ret = _review_routes.post_project_documents_audit(self, p)
            if _ret is not _review_routes.NOT_HANDLED:
                return _ret
        if p.startswith("/api/v1/reviews/") and p.endswith("/report") and p.count("/") == 5:
            _ret = _review_routes.post_review_report(self, p)
            if _ret is not _review_routes.NOT_HANDLED:
                return _ret
        if p == "/api/v1/rule/parse":
            b = self._body()
            u = self._session_user() or {}
            r = agents.run_agent("agent-rulegen", {"text": b.get("text", ""), "save": False},
                                 actor=u.get("sub", ""))
            # degraded 是确定性回退：可执行、可返回候选，但必须把状态暴露给调用方，
            # 不能像 ok 一样被当作真实模型执行。
            if r.get("status") not in ("ok", "degraded"):
                return self._err(503, str((r.get("result") or {}).get("error") or "规则生成智能体不可用"),
                                 "agent_unavailable")
            _out = dict(r.get("result") or {})
            _out["agent_status"] = r.get("status")
            _out["degraded"] = bool(_out.get("degraded") or r.get("status") == "degraded")
            return self._send(200, self._json(_out))
        if p == "/api/v1/rules/intake/chat":
            b = self._body() or {}
            u = self._session_user() or {}
            if (u.get("role") or "") not in ("admin", "super_admin", "reviewer"):
                return self._err(403, "无权限提交规则", "forbidden")
            from app.services import rule_intake as _ri
            out = _ri.chat(b.get("messages") or [], save=bool(b.get("save")),
                           confirm=bool(b.get("confirm")), user=u.get("sub", ""))
            if out.get("error"):
                return self._err(400, out["error"], "rule_intake_failed")
            return self._send(200, self._json(out))
        if p == "/api/v1/rule/decompose":
            b = self._body()
            try:
                data = base64.b64decode(b.get("data", ""), validate=True)
            except Exception:
                return self._err(400, "data 不是合法 base64", "invalid_base64")
            # P1-B5-01（形同 document upload 的路径穿越）：旧实现把客户端 filename 直接拼进
            # 临时文件名 `decomp_<id>_<fn>`，fn='../../../etc/passwd' → open() 目标越界 →
            # FileNotFoundError 未捕获 → socketserver 关连接（前端只看到「网络错误」）。
            # 现在：消毒（严格模式，含路径分隔符/.. 直接 400）+ 全链路 try/except
            # 把任何异常映射成结构化 JSON（400/500 + 明确 code），绝不静默断连。
            from app.services import project as _pj_san
            fn, _fn_err = _pj_san.sanitize_filename(b.get("filename", ""),
                                                    default="规范文件", strict=True)
            if _fn_err:
                return self._err(400, _fn_err, "invalid_filename")
            try:
                tmp = os.path.join(tempfile.gettempdir(), f"decomp_{db.new_id('x')}_{fn}")
                _tmp_real = os.path.realpath(tmp)
                if not _tmp_real.startswith(os.path.realpath(tempfile.gettempdir()) + os.sep):
                    return self._err(400, "文件名非法（目标路径越界）", "invalid_filename")
                with open(tmp, "wb") as f:
                    f.write(data)
            except OSError as _wf:
                logging.getLogger(__name__).warning(
                    "rule/decompose 写入临时文件失败 fn=%s", fn, exc_info=True)
                return self._err(400, f"文件写入失败：{type(_wf).__name__}: {str(_wf)[:120]}",
                                 "decompose_write_failed")
            try:
                from app.services import rule_file_agents as _rfa
                res = _rfa.decompose(tmp, int(b.get("limit", 30) or 30),
                                     source_type=str(b.get("source_type") or "document"))
            except Exception as _df:  # noqa: BLE001 —— 拆解失败必须是可读错误（不许断连）
                logging.getLogger(__name__).warning(
                    "rule/decompose 拆解失败 fn=%s", fn, exc_info=True)
                return self._err(500, f"规则拆解失败：{type(_df).__name__}: {str(_df)[:160]}",
                                 "decompose_failed")
            finally:
                try:
                    os.remove(tmp)
                except OSError:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
            # T-185（KB 评审 P1-1）：拆解结果附带作用域建议（可见、可改、可解释），
            # 入库时前端把确认后的值随 scope 提交；不改变拆解本身产出的候选结构。
            try:
                from app.services import rule as _rule_svc
                _scope_ctx = _rule_svc.workspace_scope_context()
                for _c in (res.get("candidates") or []):
                    try:
                        _c["scope_suggestion"] = _rule_svc.suggest_candidate_scope(
                            _c, filename=fn,
                            source_type=str(b.get("source_type") or "document"),
                            scope_context=_scope_ctx)
                    except Exception:
                        logging.getLogger(__name__).warning(
                            "candidate scope suggestion failed", exc_info=True)
                res["scope_context"] = {
                    "workspace": {"id": _scope_ctx.get("id") or "",
                                  "name": _scope_ctx.get("name") or "",
                                  "doc_types": list(_scope_ctx.get("doc_types") or [])},
                    "filename": fn,
                    "note": "候选的「适用范围」为自动推断的默认值，入库前可确认/修改，"
                            "入库后仍可在草稿「继续编辑」中改",
                }
            except Exception:  # noqa: BLE001 —— 建议只是辅助，不得让拆解失败
                logging.getLogger(__name__).warning(
                    "decompose scope suggestion skipped", exc_info=True)
            return self._send(200, self._json(res))
        if p == "/api/v1/rules/effective-select/repair-drift":
            # X-12 P0-2：漂移修复工具（dry-run/apply；apply 逐条写审计、幂等）。
            _d_eff = self._business_write_denied("rules.effective_drift_repair")
            if _d_eff:
                return _d_eff
            _u_eff2 = self._session_user() or {}
            if str(_u_eff2.get("role") or "") != "admin":
                return self._err(403, "规则漂移修复仅业务管理员可执行", "forbidden")
            _b_eff = self._body() or {}
            _dry = bool(_b_eff.get("apply")) is False
            if "dry_run" in _b_eff:
                _dry = bool(_b_eff.get("dry_run"))
            _out_eff = rule.repair_effective_drift(
                dry_run=_dry, actor=str(_u_eff2.get("sub") or "system"))
            return self._send(200, self._json(_out_eff))
        if _rulegen_dispatch(self, "POST"):
            return
        if p.startswith("/api/v1/rules/") and p.endswith("/restore") and p.count("/") == 5:
            rid = p.split("/")[-2]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可回滚规则", "forbidden")
            _rrow, _rdeny = _scoped_rule(rid, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            from app.api import rule_routes as _rrr
            _out = _rrr.post(p, self._body() or {}, u)
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/rules/") and p.endswith("/update") and p.count("/") == 5:
            rid = p.split("/")[-2]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "审核员只能新建或查看规则；修改规则需业务管理员", "forbidden")
            _rrow, _rdeny = _scoped_rule(rid, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            b = self._body() or {}
            try:
                return self._send(200, self._json(rule.update_draft(
                    rid, b.get("name"), b.get("category"), b.get("criterion"),
                    u.get("sub", "admin"), scope=b.get("scope"),
                    evidence_scope=b.get("evidence_scope"),
                    required_evidence=b.get("required_evidence"),
                    point_id=b.get("point_id") or "",
                    scope_declare_required=bool(b.get("scope_declare_required")))))
            except ValueError as e:
                return self._err(400, str(e), "invalid_rule")
        if p.startswith("/api/v1/rules/") and p.endswith("/submit") and p.count("/") == 5:
            rid = p.split("/")[-2]; u = self._session_user() or {}
            # L92（L88 G04 单边修复）：registry/CLI 允许 reviewer 提交审批，HTTP
            # 旧逻辑只允许 admin → 同一动作 CLI 200/HTTP 403。现三入口同策略：
            # admin + reviewer 可 submit；super_admin/platform_op/未知角色 403。
            _deny_submit = rule.action_denied(u.get("role") or "", "submit")
            if _deny_submit:
                return self._err(403, _deny_submit.get("message") or "无权限提交规则",
                                 "forbidden")
            _rrow, _rdeny = _scoped_rule(rid, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            return self._send(200, self._json(
                rule.submit(rid, u.get("sub", "admin"), role=u.get("role") or "")))
        if p.startswith("/api/v1/rules/") and p.endswith("/approve") and p.count("/") == 5:
            rid = p.split("/")[-2]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "该规则操作需业务管理员", "forbidden")
            _rrow, _rdeny = _scoped_rule(rid, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            return self._send(200, self._json(rule.approve(rid, u.get("sub", "admin"))))
        if p.startswith("/api/v1/rules/") and p.endswith("/publish") and p.count("/") == 5:
            rid = p.split("/")[-2]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "该规则操作需业务管理员", "forbidden")
            _rrow, _rdeny = _scoped_rule(rid, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            # 2026-11-23 LaneR（A 类 B2）：尊重服务层 http_status（结构缺失可补=422；
            # 其余非 ok 由 `_send` 把 200+error 升级为 400），与 terms 路由既有写法一致。
            _pub = rule.publish(rid, (self._session_user() or {}).get("sub", "system"))
            return self._send(int(_pub.get("http_status") or 200), self._json(_pub))
        if p.startswith("/api/v1/rules/") and p.endswith("/replay") and p.count("/") == 5:
            code = p.split("/")[-2]; u = self._session_user() or {}
            _rrow, _rdeny = _scoped_rule(code, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            return self._send(200, self._json(replay.replay(str(_rrow.get("code") or code))))
        if p.startswith("/api/v1/rules/") and p.endswith("/params/publish") and p.count("/") == 6:
            _raw = p.split("/")[-3]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "审核员只能新建或查看规则；阈值发布需业务管理员", "forbidden")
            _rrow, _rdeny = _scoped_rule(_raw, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            code = str(_rrow.get("code") or "")
            if not code:
                return self._err(404, "规则不存在", "not_found")
            return self._send(200, self._json(ruleparam.publish(code, u.get("sub", "admin"))))
        if p.startswith("/api/v1/rules/") and p.endswith("/params/pending") and p.count("/") == 6:
            _raw = p.split("/")[-3]; u = self._session_user() or {}
            _rrow, _rdeny = _scoped_rule(_raw, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            code = str(_rrow.get("code") or "")
            if not code:
                return self._err(404, "规则不存在", "not_found")
            return self._send(200, self._json({"rule_code": code, "pending": ruleparam.pending(code)}))
        if p.startswith("/api/v1/rules/") and p.endswith("/params") and p.count("/") == 5:
            _raw = p.split("/")[-2]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "审核员只能新建或查看规则；修改阈值需业务管理员", "forbidden")
            _rrow, _rdeny = _scoped_rule(_raw, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            code = str(_rrow.get("code") or "")
            if not code:
                return self._err(404, "规则不存在", "not_found")
            b = self._body() or {}
            return self._send(200, self._json(ruleparam.update(code, **{k: v for k, v in b.items() if k in ("value", "op", "lo", "hi", "unit", "scope", "metric")})))
        if p == "/api/v1/rules/mine":
            from app.services import rule_mining
            u = self._session_user() or {}
            if (u.get("role") or "") not in ("admin", "super_admin"):
                return self._err(403, "仅管理员可执行规则挖掘", "forbidden")
            return self._send(200, self._json(rule_mining.mine(20)))
        if p == "/api/v1/rules/mine/draft":
            from app.services import rule_mining
            u = self._session_user() or {}
            if (u.get("role") or "") not in ("admin", "super_admin", "reviewer"):
                return self._err(403, "无权限创建规则草稿", "forbidden")
            b = self._body() or {}
            _draft = rule_mining.create_draft(
                b.get("title") or "", b.get("summary") or "", b.get("form") or "single",
                u.get("sub", ""), b.get("rule_code") or "")
            if _draft.get("rule_id"):
                # P1-B8-02：挖掘草稿此前 rule/rule_version 落库 + 通知管理员，但审计链断。
                # 与 /rules/custom 同源动作 rule.created，用 source 区分来源（mining）。
                try:
                    R.audit_logs.log(
                        actor=u.get("sub", "") or "system", action="rule.created",
                        object=str(_draft.get("rule_id")),
                        after=json.dumps({"source": "rule_mining",
                                          "title": b.get("title") or "",
                                          "rule_code": b.get("rule_code") or "",
                                          "existing": bool(_draft.get("existing")),
                                          "auto_published": False,
                                          "requires_human_confirm": True},
                                         ensure_ascii=False),
                        **self._audit_req_fields())
                except Exception:
                    logging.getLogger(__name__).error(
                        "rule mining draft audit failed rule_id=%s",
                        _draft.get("rule_id"), exc_info=True)
            return self._send(200, self._json(_draft))
        # B2（2026-11-20 外部对抗审查）：伪造点位清理（默认 dry-run，apply 需显式）。
        if p == "/api/v1/rules/scope-repair":
            _su = self._session_user() or {}
            if (_su.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可执行规则作用域修复", "forbidden")
            _sb = self._body() or {}
            _dry = bool(_sb.get("apply")) is False
            if "dry_run" in _sb:
                _dry = bool(_sb.get("dry_run"))
            _out = rule.repair_scope_point_mapping(dry_run=_dry,
                                                   actor=str(_su.get("sub") or "system"))
            return self._send(200, self._json(_out))
        if p == "/api/v1/rules/batch":
            b = self._body()
            items = b.get("rules") or []
            u = self._session_user() or {}
            # L50：批量导入后自动打标——先解析/校验 tag_ids/tag_names（不存在且 admin 才建，
            # reviewer 只能使用已存在标签），失败在创建规则前整体返回，避免半成品。
            _tag_plan, _tag_deny = _rtr.prepare_batch_tags(b, u)
            if _tag_deny:
                return self._send(_tag_deny[0], self._json(_tag_deny[1]))
            # B1/B2/B3（2026-11-20 外部对抗审查）：批量入库先做安全类二次校验
            # （隐式全量通配 / 平台保留来源 / 非法 point_mapping）→ 整体 400，
            # 不再让非法输入被 `except: continue` 静默吞掉。
            for _i, _it in enumerate(items[:60]):
                if not isinstance(_it, dict):
                    return self._err(400, f"第{_i + 1}条规则格式非法", "invalid_rule")
                try:
                    rule.assert_rule_source_allowed(str(_it.get("source") or ""))
                    rule.assert_scope_declaration_valid(_it.get("scope"), _it.get("slots"))
                    _pm0 = (_it.get("scope") or {}).get("point_mapping") \
                        if isinstance(_it.get("scope"), dict) else None
                    if _pm0 is not None:
                        rule.normalize_point_mapping_input(_pm0)
                except ValueError as _ve:
                    return self._err(400, f"第{_i + 1}条规则作用域/来源非法：{_ve}",
                                     "invalid_scope")
            # T-185（KB 评审 P1-1）：导入/拆解入库时按真实信号自动推断作用域默认值。
            # 只在本请求显式 `infer_scope=true` 时启用；显式提交的 scope 值不覆盖；
            # 推断结果逐条回显到响应 items[].scope_inferred，前端提示“已自动推断，请确认”。
            _infer_on = bool(b.get("infer_scope"))
            _scope_ctx = {}
            if _infer_on:
                try:
                    _scope_ctx = rule.workspace_scope_context()
                except Exception:
                    logging.getLogger(__name__).warning(
                        "batch scope context unavailable", exc_info=True)
                    _scope_ctx = {}
            created = []
            rejected = []
            skipped = []
            for it in items[:60]:
                try:
                    _src = it.get("source", "document_decompose")
                    _slots = dict(it.get("slots") or {})
                    _scope_in = it.get("scope") if isinstance(it.get("scope"), dict) else {}
                    _inferred = None
                    if _infer_on:
                        try:
                            _imp = rule.apply_import_scope(
                                _scope_in, _slots,
                                filename=str(it.get("filename") or b.get("filename") or ""),
                                source_type=str(it.get("source_type") or _src),
                                candidate_text=str(it.get("quote") or ""),
                                category=str(it.get("category") or ""),
                                rclass=str(it.get("rclass") or ""),
                                name=str(it.get("name") or ""),
                                scope_context=_scope_ctx)
                            _scope_in = _imp.get("scope") or _scope_in
                            _slots = _imp.get("slots") or _slots
                            _inferred = _imp.get("inferred") or None
                        except Exception:
                            logging.getLogger(__name__).warning(
                                "batch scope inference skipped", exc_info=True)
                    _crit = str(_slots.get("criterion") or _scope_in.get("criterion") or "")[:500]
                    # 文件/制度重复确认时幂等：同来源 + 同名称 + 同判据不重复落草稿
                    _dup = None
                    for _er in R.rules.list("source=?", (_src,)):
                        if (_er.get("name") or "") != it.get("name", "未命名规则"):
                            continue
                        try:
                            _ev = R.rules.latest_version(_er["id"]) or {}
                            _es = json.loads(_ev.get("slots_json") or "{}")
                        except Exception:
                            _es = {}
                        if str(_es.get("criterion") or "")[:500] == _crit:
                            _dup = _er
                            break
                    if _dup:
                        skipped.append({"rule_id": _dup.get("id"), "name": _dup.get("name"),
                                        "reason": "同来源同判据已存在"})
                        continue
                    r = rule.create_rule(
                        code=it.get("code") or f"RSI-{db.new_id('x')[:6].upper()}",
                        name=it.get("name", "未命名规则"), category=it.get("category", "consistency"),
                        rclass=it.get("rclass", "R4"), slots=_slots,
                        source=_src,
                        scope=_scope_in, point_override=str(it.get("point_id") or ""))
                    if _inferred:
                        r["scope_inferred"] = _inferred
                    _rr0 = R.rules.get(r.get("rule_id") or "") or {}
                    if _rr0:
                        _set_owner("rule", _rr0.get("code") or "", u.get("name") or u.get("sub", ""), u.get("sub", ""))
                    created.append(r)
                except ValueError as _ve:
                    # 安全类/校验类拒绝必须可见（不再 except: continue 静默丢弃）
                    rejected.append({"index": len(created) + len(skipped) + len(rejected),
                                     "name": it.get("name") or "",
                                     "reason": f"{type(_ve).__name__}: {_ve}"[:300]})
                except Exception as _exc:  # noqa: BLE001 - 逐条失败可见，不静默
                    logging.getLogger(__name__).warning(
                        "batch rule create failed name=%s", it.get("name"), exc_info=True)
                    rejected.append({"index": len(created) + len(skipped) + len(rejected),
                                     "name": it.get("name") or "",
                                     "reason": f"{type(_exc).__name__}: {_exc}"[:300]})
            _ci0 = []
            try:
                for _it0 in created:
                    _hits0 = conflict.check_rule(_it0.get("rule_id") or "")
                    if _hits0:
                        _ci0.append({"rule_id": _it0.get("rule_id"), "conflicts": _hits0})
            except Exception:
                _ci0 = []
            # L50：创建成功（含幂等 skipped）后逐条打标，返回 tags/tagged/tag_created。
            _tag_out = _rtr.commit_batch_tags(_tag_plan, created, skipped, u)
            R.audit_logs.log(actor=u.get("sub", ""), action="rule.batch_created",
                             after=str(len(created)), **self._audit_req_fields())
            _inferred_n = sum(1 for x in created if x.get("scope_inferred"))
            _batch_out = {"created": len(created), "items": created,
                          "skipped": skipped, "rejected": rejected, "conflicts": _ci0,
                          "infer_scope": _infer_on, "inferred_count": _inferred_n}
            _batch_out.update(_tag_out)
            if _infer_on:
                _batch_out["scope_context"] = {
                    "workspace": {"id": _scope_ctx.get("id") or "",
                                  "name": _scope_ctx.get("name") or "",
                                  "doc_types": list(_scope_ctx.get("doc_types") or [])}}
            # 全部被拒（无创建/无幂等跳过）→ 400 失败语义，不让“0 条创建”伪装成 200 成功
            if rejected and not created and not skipped:
                _batch_out["error"] = "批量入库失败：全部规则被拒绝"
                _batch_out["code"] = "batch_all_rejected"
                return self._send(400, self._json(_batch_out))
            return self._send(200, self._json(_batch_out))
        if p == "/api/v1/rules/params":
            return self._send(200, self._json(ruleparam.list_all()))
        if p == "/api/v1/rules/linkage":
            return self._send(200, self._json(rule.linkage()))
        if p == "/api/v1/rules":
            b = self._body(); u = self._session_user() or {}
            # L92 三入口统一门禁：与 registry/CLI/服务层同规则——rule.create 显式
            # 持有角色 admin/reviewer 可建草稿；super_admin/platform_op/未知角色 403。
            _deny_create = rule.action_denied(u.get("role") or "", "create")
            if _deny_create:
                return self._err(403, _deny_create.get("message") or "无权限创建规则",
                                 "forbidden")
            _text = str(b.get("text") or "").strip()
            if not _text:
                return self._err(400, "缺少规则文本", "invalid_request")
            _rr = agents.run_agent("agent-rulegen", {"text": _text, "save": True},
                                   actor=u.get("sub", ""))
            if _rr.get("status") != "ok":
                return self._err(503, str((_rr.get("result") or {}).get("error") or "规则生成智能体不可用"),
                                 "agent_unavailable")
            _nr = _rr.get("result") or {}
            if _nr.get("rule_id"):
                _rr1 = R.rules.get(_nr.get("rule_id") or "") or {}
                _set_owner("rule", _rr1.get("code") or "", u.get("name") or u.get("sub", ""), u.get("sub", ""))
                R.audit_logs.log(actor=u.get("sub", ""), action="rule.created",
                                 object=_nr.get("rule_id") or "",
                                 after=__import__("json").dumps({"agent_run": _rr.get("run_id"), "text": _text[:200]}, ensure_ascii=False),
                                 **self._audit_req_fields())
            return self._send(200, self._json(_nr))
        if p == "/api/v1/rules/plan-preview":
            u = self._session_user() or {}
            if not u:
                return self._err(401, "未登录", "unauthorized")
            b = self._body()
            from app.services import execution_plan
            slots = b.get("slots") or {}
            ir = {}
            try:
                from app.services import rule_ir
                ir = rule_ir.compile_rule(slots, b.get("category") or "", b.get("rclass") or "", b.get("name") or "")
            except Exception:
                ir = {}
            return self._send(200, self._json({"ok": True, "plan": execution_plan.derive(slots), "ir": ir}))
        if p == "/api/v1/rules/custom":
            b = self._body()
            u = self._session_user() or {}
            # L92（L88 G05）：此前 /rules/custom 无角色门禁（任意已登录角色可写规则
            # 草稿）。现与 /rules、CLI rule create、服务层 create_rule 同一策略：
            # admin/reviewer 可建草稿；super_admin/platform_op/未知角色 403。
            _deny_custom = rule.action_denied(u.get("role") or "", "create")
            if _deny_custom:
                return self._err(403, _deny_custom.get("message") or "无权限创建规则",
                                 "forbidden")
            name = str(b.get("name") or "").strip()
            if not name:
                return self._err(400, "规则名称不能为空", "invalid_rule")
            code = str(b.get("code") or "").strip() or f"CUST-{db.new_id('x')[:6].upper()}"
            _slots_in = dict(b.get("slots") or {})
            _scope_in = dict(b.get("scope") or {})
            _inferred_c = None
            # T-185：一句话/表单入口可选自动推断作用域（显式 scope 值优先，不覆盖）
            if b.get("infer_scope"):
                try:
                    _imp_c = rule.apply_import_scope(
                        _scope_in, _slots_in,
                        filename=str(b.get("filename") or ""),
                        source_type=str(b.get("source") or "manual"),
                        candidate_text=str(b.get("criterion") or _slots_in.get("criterion") or ""),
                        category=str(b.get("category") or ""),
                        rclass=str(b.get("rclass") or ""), name=name)
                    _scope_in = _imp_c.get("scope") or _scope_in
                    _slots_in = _imp_c.get("slots") or _slots_in
                    _inferred_c = _imp_c.get("inferred") or None
                except Exception:
                    logging.getLogger(__name__).warning(
                        "custom rule scope inference skipped", exc_info=True)
            try:
                r = rule.create_rule(code=code, name=name, category=b.get("category") or "consistency",
                                     rclass=b.get("rclass") or "R4", slots=_slots_in,
                                     source=b.get("source") or "manual",
                                     scope=_scope_in,
                                     point_override=str(b.get("point_id") or ""))
            except Exception as e:  # noqa
                # L79 写入门：模板/算子/单位未知时携带机读错误码（unsupported_*），
                # 其余校验失败仍为 invalid_rule（不改变既有调用方口径）。
                return self._err(400, str(e), str(getattr(e, "code", "") or "invalid_rule"))
            if _inferred_c:
                r["scope_inferred"] = _inferred_c
            _set_owner("rule", code, u.get("name") or u.get("sub", ""), u.get("sub", ""))
            R.audit_logs.log(actor=u.get("sub", ""), action="rule.created", object=code,
                             **self._audit_req_fields())
            try:
                r["conflicts"] = conflict.check_rule(r.get("rule_id") or code)
            except Exception:
                r["conflicts"] = []
            return self._send(200, self._json(r))
        if p.startswith("/api/v1/rules/") and p.endswith("/publish") and p.count("/") == 5:
            rid = p.split("/")[-2]; u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "该规则操作需业务管理员", "forbidden")
            _rrow, _rdeny = _scoped_rule(rid, u)
            if _rdeny:
                return self._send(_rdeny[0], self._json(_rdeny[1]))
            # 2026-11-23 LaneR（A 类 B2）：尊重服务层 http_status（结构缺失可补=422；
            # 其余非 ok 由 `_send` 把 200+error 升级为 400），与 terms 路由既有写法一致。
            _pub = rule.publish(rid, (self._session_user() or {}).get("sub", "system"))
            return self._send(int(_pub.get("http_status") or 200), self._json(_pub))
        for act, fn in [("submit", rule.submit), ("approve", rule.approve),
                        ("rollback", rule.rollback), ("archive", rule.archive)]:
            if p.startswith("/api/v1/rules/") and p.endswith(f"/{act}"):
                rid = p.split("/")[-2]; u = self._session_user() or {}
                _role_rule = u.get("role") or ""
                _rrow, _rdeny = _scoped_rule(rid, u)
                if _rdeny:
                    return self._send(_rdeny[0], self._json(_rdeny[1]))
                if act in ("rollback", "archive"):
                    # 审核员只能对本人上传的规则回滚/下线；其他人的规则只读
                    if _role_rule != "admin" and not (_role_rule == "reviewer" and _rule_owned_by(_rrow, u)):
                        return self._err(403, "只能回滚或下线本人上传的规则", "forbidden")
                elif _role_rule != "admin":
                    return self._err(403, "该规则操作需业务管理员", "forbidden")
                return self._send(200, self._json(fn(rid, actor=u.get("sub", "admin"))))
        if p == "/api/v1/workspaces/rules-review/waive":
            # X-11 P0-1：规则体检豁免 = 主链门禁开关，只能业务管理员操作 + 必须写审计。
            # 旧实现只校验 permissions.has(audit.review)（审核员也有）且不写审计，
            # 审核员可自助把「规则体检未通过」豁免掉，主链门禁形同虚设。
            from app.services import rules_review as _rr2, workspaces as _w14, ctx as _cx14
            from app.services import permission as _pm14
            u = self._session_user() or {}
            _deny14 = self._business_write_denied("rules_review.waive")
            if _deny14:
                return _deny14
            _role14 = str(u.get("role") or "")
            if _role14 != "admin" or not _pm14.can(_role14, "ws.manage"):
                return self._err(403, "规则体检豁免需业务管理员权限（ws.manage）", "forbidden")
            b = self._body() or {}
            _rule14 = str(b.get("rule_id") or "").strip()
            _reason14 = str(b.get("reason") or "").strip()
            if not _rule14:
                return self._err(400, "缺少 rule_id，无法豁免", "rule_id_required")
            if not _reason14:
                return self._err(400, "豁免必须填写原因（写入审计，用于事后对账）",
                                 "waive_reason_required")
            _c14 = _cx14.get_context() or {}
            _wsid14 = str(b.get("workspace_id") or _c14.get("workspace_id") or "")
            _tgt14 = _w14.get(_wsid14) if _wsid14 else {}
            if not _tgt14:
                return self._err(404, "工作空间不存在或已归档", "not_found")
            _urow14 = R.users.get(u.get("sub", "")) or {}
            if _tgt14.get("tenant_id") != (_urow14.get("tenant_id") or "t-default"):
                return self._err(403, "不能豁免其他租户工作空间的规则", "forbidden")
            r = _rr2.waive(_wsid14, _rule14, _reason14, actor=u.get("sub", ""),
                           tenant_id=_tgt14.get("tenant_id") or "",
                           workspace_id=_wsid14)
            if r.get("ok"):
                return self._send(200, self._json(r))
            return self._send(400, self._json(r))
        if p == "/api/v1/rules/mechanism/catalog":
            from app.services import mechanism_mining as _mm
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可查看机制目录", "forbidden")
            _cat = Path(__file__).resolve().parents[2] / "seed" / "mechanisms" / "p01_catalog.json"
            try:
                _specs = _mm.load_catalog(str(_cat))
            except Exception as e:
                return self._err(400, f"机制目录不可用：{e}", "invalid_catalog")
            _items = [{"point_id": x.point_id, "point_name": x.point_name,
                       "mechanisms": x.mechanisms, "evidence": x.evidence,
                       "applicability": x.applicability} for x in _specs]
            return self._send(200, self._json({"ok": True, "count": len(_items), "items": _items}))
        if p == "/api/v1/rules/mechanism/import":
            from app.services import mechanism_mining as _mm
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可导入机制规则", "forbidden")
            b = self._body() or {}
            items = b.get("items")
            if not items:
                _cat = Path(__file__).resolve().parents[2] / "seed" / "mechanisms" / "p01_catalog.json"
                try:
                    specs = _mm.load_catalog(str(_cat))
                except Exception as e:
                    return self._err(400, f"机制目录不可用：{e}", "invalid_catalog")
            else:
                specs = []
                # 接受前端传入的机制项，不把任意路径当文件
                from app.services.mechanism_mining import MechanismSpec
                for x in items:
                    if not isinstance(x, dict) or not x.get("point_id"):
                        continue
                    specs.append(MechanismSpec(point_id=str(x.get("point_id")), point_name=str(x.get("point_name") or x.get("point_id")),
                                               mechanisms=[str(m) for m in (x.get("mechanisms") or [])],
                                               evidence=[str(e) for e in (x.get("evidence") or [])],
                                               check_steps=str(x.get("check_steps") or ""),
                                               pass_criteria=str(x.get("pass_criteria") or ""),
                                               applicability=str(x.get("applicability") or "")))
            out = _mm.materialize(specs, publish=bool(b.get("publish")), by=u.get("sub", ""))
            return self._send(200 if out.get("ok") else 400, self._json(out))
        if p == "/api/v1/workspaces/settings/save":
            from app.services import workspaces as _w6
            u = self._session_user() or {}
            b = self._body() or {}
            cur = _w6.current(u.get("sub", ""))
            _wsid6 = b.get("id") or cur.get("id", "")
            _target6 = _w6.get(_wsid6) if _wsid6 else {}
            if not _target6:
                return self._err(404, "空间不存在或已归档", "not_found")
            _roles6 = set()
            try:
                from app.services import account as _acc0
                _roles6 = set(_acc0.roles_of(u.get("sub", "")))
            except Exception:
                logging.getLogger(__name__).debug('ignored', exc_info=True)
            _is_admin = bool(_roles6 & {"admin", "super_admin"})
            if not (_is_admin or _target6.get("created_by") == u.get("sub")):
                return self._err(403, "仅管理员或空间创建者可改设置", "forbidden")
            _urow6 = R.users.get(u.get("sub", "")) or {}
            if _target6.get("tenant_id") != (_urow6.get("tenant_id") or "t-default") and "super_admin" not in _roles6:
                return self._err(403, "不能修改其他租户的空间", "forbidden")
            _newname = str(b.get("name") or "").strip()
            _renamed = False
            if _newname and _newname != str(_target6.get("name") or ""):
                _rn = _w6.rename(_wsid6, _newname)
                if not _rn.get("ok"):
                    return self._send(400, self._json(_rn))
                _renamed = True
            r = _w6.save_settings(_wsid6, b)
            if r.get("ok"):
                r["renamed"] = _renamed
                r["setup_required"] = _w6.setup_required(_wsid6)
            return self._send(200 if r.get("ok") else 400, self._json(r))
        if p == "/api/v1/workspaces/create":
            from app.services import workspaces as _w
            u = self._session_user() or {}
            # DU-36（P3，2026-11-25）：权限拒绝统一 403（旧实现落到服务层被拒返回
            # 400 code=forbidden，与 CLI `_need(uid,"ws.manage")`→403 不同源）。
            # ws.manage 在注册表中仅授予业务管理员，此处先按同一权限点返回 403。
            from app.services import permission as _pm_ws
            if not _pm_ws.can(str(u.get("role") or ""), "ws.manage"):
                return self._err(403, "无权限（需 ws.manage）", "forbidden")
            b = self._body() or {}
            # T-197（P1-6）：工作空间创建必须绑定「当前登录用户所属租户」。
            # 旧实现不传 tenant_id → 默认 t-default，Acme 管理员新建的空间落到
            # t-default，随后对该空间写设置被 403 拒绝（管理员自建空间不可配置）。
            _ut_row = {}
            try:
                _ut_row = R.users.get(u.get("sub", "")) or {}
            except Exception:
                _ut_row = {}
            _ut_tenant = str(_ut_row.get("tenant_id") or u.get("tenant_id") or "")
            r = _w.create(b.get("name") or "", u.get("sub", ""),
                          tenant_id=_ut_tenant or "t-default",
                          settings=b.get("settings") or {})
            return self._send(200 if r.get("ok") else 400, self._json(r))
        if p == "/api/v1/workspaces/switch":
            from app.services import workspaces as _w
            u = self._session_user() or {}
            b = self._body() or {}
            r = _w.switch(u.get("sub", ""), b.get("id") or "")
            return self._send(200 if r.get("ok") else 400, self._json(r))
        if p == "/api/v1/doctypes/create":
            from app.services import doctypes as _dt
            b = self._body() or {}
            u = self._session_user() or {}
            r = _dt.create(b.get("name") or "", aliases=b.get("aliases") or [],
                           audit_types=b.get("audit_types") or [], created_by=u.get("sub", ""))
            return self._send(200 if r.get("ok") else 400, self._json(r))
        if p == "/api/v1/doctypes/remember":
            # DU-04（P1，2026-11-25）：该路由无角色守卫、scope_id 可任意指定 →
            # reviewer 实测 200 并可写他人项目/任意 scope 的文档类型记忆。
            # 现改为：仅业务管理员（写配置层）+ scope 所有权校验（project 走
            # _case_scope；user 只能写当前会话本人，客户端 id 不生效）。
            from app.services import doctypes as _dt
            b = self._body() or {}
            u = self._session_user() or {}
            _d = self._business_write_denied("doctypes.remember")
            if _d:
                return _d
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可维护文档类型记忆", "forbidden")
            _scope = str(b.get("scope") or "project").strip()
            _sid = str(b.get("id") or "").strip()
            if _scope not in ("project", "user"):
                return self._err(400, "scope 只支持 project/user", "invalid_scope")
            if _scope == "user":
                # 用户级记忆只能写自己：忽略客户端 scope_id，强制当前会话账号
                _sid = str(u.get("sub") or "")
            else:
                if not _sid:
                    return self._err(400, "缺少项目 id", "invalid_scope")
                _case, _deny = self._case_scope(_sid)
                if _deny:
                    return self._send_deny(_deny)
            r = _dt.remember(_scope, _sid, b.get("doc_type") or "")
            return self._send(200, self._json(r))
        if p == "/api/v1/ontology/workspace/discover":
            return _ontology_routes.post_ontology_workspace_discover(self)
        if p == "/api/v1/ontology/workspace/add":
            u = self._session_user() or {}
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可维护本体", "forbidden")
            b = self._body() or {}
            from app.services import ontology_service as _ows   # T-200 门面
            r = _ows.add_manual(str(b.get("canonical") or ""), b.get("aliases") or [],
                                str(b.get("type") or ""), u.get("sub", ""), str(b.get("evidence") or ""))
            return self._send(200 if r.get("ok") else 400, self._json(r))
        if p == "/api/v1/ontology/workspace/term":
            return _ontology_routes.post_ontology_workspace_term(self)
        if p == "/api/v1/ontology/workspace/threshold":
            return _ontology_routes.post_ontology_workspace_threshold(self)
        if p == "/api/v1/ontology/validate":
            return _ontology_routes.post_ontology_validate(self)
        if p == "/api/v1/ontology/publish":
            _gv = engine.ONTO.validate()
            if not _gv.get("ok"):
                return self._err(400, "本体关系/类型校验未通过，禁止发布：" + "；".join(
                    str(x.get("msg") or "") for x in (_gv.get("errors") or [])[:3]), "ontology_invalid")
            from app.services import ontology_v2 as _ov
            r = _ov.publish()
            return self._send(200 if r.get("ok") else 400, self._json(r))
        # T-197（P1-2/P1-3）：本体资产写接口——租户隔离（跨租户统一 404）+ 同事务审计。
        # 6 类写操作：entity_created/updated/deleted、alias_created/updated/deleted
        #（关系写同样留痕 ontology.link_created/deleted）。
        if p in ("/api/v1/ontology/entity", "/api/v1/ontology/entity/update",
                 "/api/v1/ontology/entity/delete", "/api/v1/ontology/alias",
                 "/api/v1/ontology/alias/update", "/api/v1/ontology/alias/delete",
                 "/api/v1/ontology/link", "/api/v1/ontology/link/delete"):
            _ret = _ontology_routes.post_ontology_assets(self, p)
            if _ret is not _ontology_routes.NOT_HANDLED:
                return _ret
        if p == "/api/v1/ontology/snapshot":
            return _ontology_routes.post_ontology_snapshot(self)
        if p.startswith("/api/v1/ontology/version/") and p.endswith("/publish"):
            return _ontology_routes.post_ontology_version_publish(self, p)
        if p == "/api/v1/ontology/versions":
            return _ontology_routes.post_ontology_versions(self)
        if p == "/api/v1/ontology/impact":
            return _ontology_routes.post_ontology_impact(self)
        if p == "/open/v1/tasks":
            return _open_routes.post_open_tasks(self)
        if p == "/api/v1/calibration/config":
            _d = self._business_write_denied("calibration.config")
            if _d:
                return _d
            # F-28：Jev 校准属于审核业务写，系统管理员只读；业务管理员负责调整。
            if _role_of((self._session_user() or {}).get("sub")) != "admin":
                return self._err(403, "仅业务管理员可调整 Jev 配置", "forbidden")
            b = self._body()
            try:
                r = calibration.set_min_accuracy(float(b.get("min_accuracy", 0.9)))
                R.audit_logs.log(actor=(self._session_user() or {}).get("sub", ""), action="jev.config",
                                 after=str(r), **self._audit_req_fields())
                return self._send(200, self._json(r))
            except Exception as e:  # noqa
                return self._err(400, str(e), "invalid_config")
        if p == "/api/v1/open/deliver":
            return _open_routes.post_open_deliver(self)
        if p == "/api/v1/open/sandbox":
            return _open_routes.post_open_sandbox(self)
        if p.startswith("/api/v1/open/apps/") and p.endswith("/test"):
            return _open_routes.post_open_app_test(self, p)
        if p.startswith("/api/v1/open/apps/") and p.endswith("/rotate"):
            return _open_routes.post_open_app_rotate(self, p)
        if p.startswith("/api/v1/open/apps/") and p.endswith("/update"):
            return _open_routes.post_open_app_update(self, p)
        if p == "/api/v1/open/apps":
            return _open_routes.post_open_apps(self)
        if p == "/api/v1/conflicts/detect":
            # P1-B4-01：检测是业务写（新增 conflict 行进待裁决队列、影响报告门禁），
            # 必须带真实操作人写审计（conflict.detect / conflict.detect_failed）。
            _u_det = self._session_user() or {}
            return self._send(200, self._json(conflict.detect(
                persist=True, actor=_u_det.get("sub", "") or "")))
        if p.startswith("/api/v1/conflicts/") and p.endswith("/resolve"):
            # T-63 裁决：服务端强制角色/租户/空间/可裁范围；6 条 resolution 路径、
            # 影响面确认（both_wrong）、审计、幂等。错误码 400/403/404/409 由服务层给出。
            cid = p.split("/")[-2]
            u = self._session_user() or {}
            b = self._body()
            try:
                _out = conflict.resolve(
                    cid, b.get("action", ""), b.get("note", ""), u.get("sub", ""),
                    all_spaces=False,
                    resolution=b.get("resolution", ""),
                    corrected_criterion=b.get("corrected_criterion", ""),
                    impact=b.get("impact") or {},
                    confirm_impact=bool(b.get("confirm_impact")),
                    impact_digest=b.get("impact_digest", ""),
                    user_ctx=u,
                    idempotency_key=b.get("idempotency_key", ""))
                return self._send(200, self._json(_out))
            except conflict.ConflictError as e:
                return self._err(e.status, e.message, e.code)
            except ValueError as e:
                return self._err(400, str(e), "invalid_action")
            except Exception as exc:  # noqa: BLE001 - 内部错误必须返回 5xx（失败可见）
                return self._conflict_internal("resolve", cid, exc)
        if p.startswith("/api/v1/conflicts/") and p.endswith("/recreate"):
            # T-63「两者都不对」后的重新新建规则：create_draft 只生成草稿（不自动发布），
            # link 关联已新建规则。权限与裁决同源（admin 本租户+本空间 / reviewer 本人相关）。
            cid = p.split("/")[-2]
            u = self._session_user() or {}
            b = self._body()
            try:
                _out = conflict.recreate(
                    cid, action=b.get("action", "create_draft"),
                    rule_id=b.get("rule_id", ""), user=u, user_sub=u.get("sub", ""))
                return self._send(200, self._json(_out))
            except conflict.ConflictError as e:
                return self._err(e.status, e.message, e.code)
            except Exception as exc:  # noqa: BLE001 - 内部错误必须返回 5xx（失败可见）
                return self._conflict_internal("recreate", cid, exc)

        if p.startswith("/api/v1/evolution/"):
            from app.api import evolution_routes as _ev
            _out = _ev.post(self, p, self._session_user() or {})
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p.startswith("/api/v1/schema/") and p.count("/") == 4:
            # X-07：写 schema 同样需要 schema.view（业务管理员/系统管理员）；审核员 403。
            from app.services import permission as _pm_schema_w
            _u_schema_w = self._session_user() or {}
            if not _pm_schema_w.can(str(_u_schema_w.get("role") or ""), "schema.view"):
                return self._err(403, "数据字典仅业务管理员/系统管理员可维护", "forbidden")
            t = p.split("/")[-1]; b = self._body(); u = self._session_user() or {}
            return self._send(200, self._json(schema_check.save_schema(t, b, u.get("sub", ""))))
        if p == "/api/v1/qa/sample":
            # DU-05（P1，2026-11-25）：抽样复核写路由无角色守卫——reviewer 实测
            # POST 200 并触发抽样写。抽样属于业务管理员的质量校准动作（judge 已仅
            # admin），现在 create 与 judge 同口径：admin + 服务层第二道角色校验，
            # 并把租户/空间显式传入（旧实现只传 actor，抽样范围依赖请求上下文）。
            b = self._body() or {}; u = self._session_user() or {}
            _d = self._business_write_denied("qa.sample")
            if _d:
                return _d
            if (u.get("role") or "") != "admin":
                return self._err(403, "仅业务管理员可发起抽样复核", "forbidden")
            return self._send(200, self._json(qa_sample.create(
                int(b.get("percent", 10) or 10), u.get("sub", ""),
                tenant_id=_tenant_of_user(u),
                workspace_id=str(u.get("workspace_id") or ""))))
        if p.startswith("/api/v1/rsi/candidates/") and p.endswith("/rollback") and p.count("/") == 6:
            _d = self._business_write_denied("rsi.rollback")
            if _d:
                return _d
            cid = p.split("/")[-2]; u = self._session_user() or {}
            return self._send(200, self._json(rsi_protocol.rollback(cid, u.get("sub", ""))))
        if p == "/api/v1/rsi/frozen":
            _d = self._business_write_denied("rsi.frozen")
            if _d:
                return _d
            b = self._body()
            return self._send(200, self._json(rsi_protocol.set_frozen(
                bool(b.get("frozen")), by=(self._session_user() or {}).get("sub", ""))))
        if p.startswith("/api/v1/qa/samples/") and p.endswith("/judge") and p.count("/") == 6:
            _d = self._business_write_denied("qa.judge")
            if _d:
                return _d
            u = self._session_user() or {}
            # F-28：抽样复核判定属于审核业务写，系统管理员只读，业务管理员执行。
            if u.get("role") != "admin":
                return self._err(403, "仅业务管理员可判定抽样复核", "forbidden")
            sid = p.split("/")[-2]; b = self._body()
            return self._send(200, self._json(qa_sample.judge(
                sid, bool(b.get("agree")), b.get("note", ""), u.get("sub", ""),
                tenant_id=u.get("tenant_id") or "", workspace_id=u.get("workspace_id") or "")))
        if p == "/api/v1/scheduler/run":
            _d = self._business_write_denied("scheduler.run")
            if _d:
                return _d
            return self._send(200, self._json(scheduler.scan_once(force=True)))
        if p.startswith("/api/v1/feedback/") and p.endswith("/settle"):
            _d = self._business_write_denied("feedback.settle")
            if _d:
                return _d
            fid = p.split("/")[-2]
            # F-12：不存在/跨租户 404、他人项目 403；不能把“查不到”降级成 400/200。
            _fb, _fb_deny = self._feedback_scope(fid)
            if _fb_deny:
                return self._send_deny(_fb_deny)
            b = self._body()
            u = self._session_user() or {}
            # B5 修复（T-177）：透传 auto_publish（默认 False）。只有请求体显式 true 才在
            # 沉淀后立即发布；默认仍只生成草稿，人工到草稿箱点「发布生效」。
            _r = feedback.settle(fid, b.get("action", "revise"), b.get("note", ""),
                                 u.get("sub", ""),
                                 auto_publish=bool(b.get("auto_publish") is True))
            # L18（S4 预注册防事后改）：候选创建时写 prereg_sha256（6 行最小接线）。
            if _r.get("ok") and _r.get("candidate_id"):
                try:
                    evolution.prereg_register_candidate(
                        _r["candidate_id"], by=u.get("sub") or "system", audit=True)
                except Exception:  # noqa: BLE001 - 预注册是旁路，不得阻断沉淀主流程
                    logging.getLogger(__name__).warning("prereg register failed", exc_info=True)
            if _r.get("ok"):
                return self._send(200, self._json(_r))
            # 权限拒绝必须 403（AGENTS §3：前端隐藏≠权限，服务端 403）；其余按服务层
            # http_status 映射（LaneR B2：结构缺失可补=422 needs_structure，其余 400）。
            _code = (403 if (_r.get("status") == 403 or _r.get("code") == "forbidden")
                     else int(_r.get("http_status") or 400))
            return self._send(_code, self._json(_r))
        if p == "/api/v1/models/effective":
            return self._send(200, self._json(model.effective()))
        if p == "/api/v1/models":
            b = self._body()
            # P2-B6-04：审计 actor 必须是当前登录用户（不是硬编码 admin）。
            _m_actor = (self._session_user() or {}).get("sub", "")
            _mb2 = str(b.get("base_url") or "")
            if _mb2:
                _okM2, _whyM2 = _model_url_ok(_mb2)
                if not _okM2:
                    return self._err(400, "base_url 不被允许：" + _whyM2, "invalid_url")
            try:
                return self._send(200, self._json(model.create_model(
                    b.get("name", ""), b.get("provider", ""), b.get("model_id", ""),
                    b.get("base_url", ""), _seal_model_api_key(b.get("api_key", "")),
                    b.get("capabilities", "chat"), bool(b.get("is_default")),
                    actor=_m_actor)))
            except Exception as e:  # noqa
                return self._err(400, str(e), "invalid_model")
        if p == "/api/v1/models/preset":
            b = self._body()
            _alias = {"deepseek": "deepseek", "flash": "deepseek", "ernie": "ernie",
                      "wenxin": "ernie", "ocr-model": "ocr"}
            _key = _alias.get(str(b.get("key", "")).lower(), b.get("key", ""))
            # P2-B6-04：预置模型创建同样记真实操作人。
            _m_actor = (self._session_user() or {}).get("sub", "")
            try:
                return self._send(200, self._json(model.add_preset(_key, actor=_m_actor)))
            except Exception as e:  # noqa
                return self._err(400, str(e), "invalid_preset")
        if p.startswith("/api/v1/models/"):
            mid = p.split("/")[-2] if p.endswith(("/update", "/delete", "/test")) else p.split("/")[-1]
            b = self._body() if p.endswith(("/update",)) else {}
            # P2-B6-04：update/delete 审计 actor = 当前登录用户。
            _m_actor = (self._session_user() or {}).get("sub", "")
            try:
                if p.endswith("/test"):
                    return self._send(200, self._json(model.test_model(mid)))
                if p.endswith("/update"):
                    _ub = str(b.get("base_url") or "")
                    if _ub:
                        _okU, _whyU = _model_url_ok(_ub)
                        if not _okU:
                            return self._err(400, "base_url 不被允许：" + _whyU, "invalid_url")
                    # L147 P0-3：开关开启时 api_key 加密入库（主密钥缺失 fail-closed 400）。
                    if b.get("api_key"):
                        b = dict(b)
                        b["api_key"] = _seal_model_api_key(str(b.get("api_key") or ""))
                    return self._send(200, self._json(model.update_model(mid, actor=_m_actor, **b)))
                if p.endswith("/delete"):
                    return self._send(200, self._json(model.delete_model(mid, actor=_m_actor)))
                return self._err(404, "not found")
            except Exception as e:  # noqa
                return self._err(400, str(e), "invalid_model")
        if p == "/api/v1/users":
            b = self._body()
            u = self._session_user() or {}
            try:
                r = account.create_user(b.get("username", "") or b.get("phone", ""), b.get("name", ""),
                                        b.get("role", ""), b.get("phone", ""), b.get("email", ""),
                                        b.get("password", ""),
                                        created_by=u.get("sub", ""), actor_role=u.get("role", ""),
                                        roles=b.get("roles") or None,
                                        tenant_id=str(b.get("tenant_id") or ""),
                                        department=b.get("department") or "")
            except PermissionError as e:
                return self._err(403, str(e), "forbidden")
            except ValueError as e:
                code = "forbidden" if "只能开通" in str(e) else "invalid_user"
                return self._err(403 if code == "forbidden" else 400, str(e), code)
            return self._send(200, self._json(r))
        if p.startswith("/api/v1/users/") and p.endswith("/update"):
            uid = p.split("/")[-2]
            b = self._body() or {}
            u = self._session_user() or {}
            try:
                return self._send(200, self._json(account.update_user(
                    uid, b.get("name") or "", b.get("phone") or "", b.get("email") or "",
                    actor=u.get("sub", ""), actor_role=u.get("role", ""),
                    department=b.get("department") or "")))
            except ValueError as e:
                return self._err(400, str(e), "invalid_user")
        if p.startswith("/api/v1/users/") and p.endswith("/reset-password"):
            uid = p.split("/")[-2]
            u = self._session_user() or {}
            try:
                _r = account.reset_password(uid, self._body().get("password", ""),
                                            actor=u.get("sub", "admin"), actor_role=u.get("role", ""))
            except ValueError as e:
                return self._err(403, str(e), "forbidden")
            # 管理员重置后：该账号此前所有 JWT 立即失效，必须用临时密码重新登录并改密。
            try:
                auth.bump_token_version(uid)
            except Exception:
                logging.getLogger(__name__).warning("reset token_version bump failed uid=%s", uid, exc_info=True)
            return self._send(200, self._json(_r))
        if p.startswith("/api/v1/users/") and p.endswith("/status"):
            uid = p.split("/")[-2]
            try:
                u = self._session_user() or {}
                _r = account.set_status(uid, self._body().get("status", ""),
                                        actor=u.get("sub", "admin"), actor_role=u.get("role", ""))
            except ValueError as e:
                return self._err(400, str(e), "invalid_user")
            # 停用/启用都吊销旧 JWT：重新启用后旧 cookie 也不能复活。
            try:
                auth.bump_token_version(uid)
            except Exception:
                logging.getLogger(__name__).warning("status token_version bump failed uid=%s", uid, exc_info=True)
            return self._send(200, self._json(_r))
        if p.startswith("/api/v1/users/") and p.endswith("/delete"):
            uid = p.split("/")[-2]
            u = self._session_user() or {}
            try:
                _r = account.delete_user(uid, actor=u.get("sub", ""), actor_role=u.get("role", ""))
            except ValueError as e:
                return self._err(403, str(e), "forbidden")
            # 删除前先吊销：即使账号行随后被删除，遗留 token 也不再被任何在线实例接受。
            try:
                auth.bump_token_version(uid)
            except Exception:
                logging.getLogger(__name__).warning("delete token_version bump failed uid=%s", uid, exc_info=True)
            return self._send(200, self._json(_r))
        if p == "/api/v1/auth/login":
            b = self._body()
            # L147 P0-3：prod 明文 HTTP 部署显式 WARN（TLS 由反代终止）。
            _warn_if_plaintext_http(self.headers, logging.getLogger(__name__))
            ident = (b.get("account") or b.get("username") or "").strip()
            password = b.get("password") or ""
            from app.services import login_guard as _lg
            _ip = self.client_address[0] if self.client_address else ""
            portal = str(b.get("portal") or "").strip().lower()
            if portal not in ("", "platform", "admin", "reviewer"):
                return self._err(400, "端口参数不合法", "invalid_portal")
            if not ident:
                return self._err(400, "账号不能为空", "invalid_identifier")
            # 手机号或邮箱登录；按端口筛选，允许同一手机号存在不同端账号
            rows_all = R.users.list("phone=? AND phone!=''", (ident,)) or R.users.list("email=? AND email!=''", (ident,))
            rows = [x for x in rows_all if (x.get("portal") or "") == portal] if portal else rows_all
            user = rows[0] if rows else None
            # 账号存在但进错端：明确提示正确入口，不再伪装成“账号或密码错误”。
            if not user and portal:
                for _alt in rows_all:
                    if auth.verify_password(password, _alt.get("password_hash") or "", _alt.get("salt") or ""):
                        _p = (_alt.get("portal") or account.portal_of_role((account.roles_of(_alt["id"]) or ["reviewer"])[0]) or "")
                        _label = {"reviewer": "审核端", "admin": "管理端", "platform": "平台端"}.get(_p, "对应端")
                        return self._err(403, f"该账号属于{_label}，请使用{_label}登录入口", "wrong_portal")
            _allow, _retry = _lg.check(_ip, ident)
            if not _allow:
                # 锁定期内只允许“密码确实正确”的本人登录；错误密码仍返回 429，避免把正确密码误报成密码错误。
                _valid_locked = bool(user and auth.verify_password(password, user.get("password_hash") or "", user.get("salt") or "")
                                     and (user.get("status") or "active") == "active")
                if not _valid_locked:
                    return self._err(429, f"登录失败次数过多，请 {int(_retry)} 秒后再试", "login_rate_limited")
                _lg.success(_ip, ident)
            username = ident
            if not user or not auth.verify_password(password, user.get("password_hash") or "", user.get("salt") or ""):
                _lg.fail(_ip, ident)
                R.audit_logs.log(actor=username or "-", action="auth.login_failed", object=username,
                                 ip=self.client_address[0] if self.client_address else "",
                                 request_id=str(getattr(self, "_rid", "") or ""))
                return self._err(401, "账号或密码错误", "invalid_credentials")
            if (user.get("status") or "active") != "active":
                return self._err(403, "账号已停用", "disabled")
            # 租户停用 → 该租户下所有账号不可登录；平台运营不属于任何租户，必须绕过
            roles = account.roles_of(user["id"]) or ["reviewer"]
            if portal == "platform" and "platform_op" not in roles:
                return self._err(403, "该手机号不属于平台端", "wrong_portal")
            if portal == "admin" and not (set(roles) & {"admin", "super_admin"}):
                return self._err(403, "该手机号不属于管理端", "wrong_portal")
            if portal == "reviewer" and "reviewer" not in roles:
                return self._err(403, "该手机号不属于审核端", "wrong_portal")
            if "platform_op" not in roles:
                _tid = user.get("tenant_id") or "t-default"
                try:
                    _trow = db.connect().execute("SELECT status FROM tenant WHERE id=?", (_tid,)).fetchone()
                    if _trow and (_trow[0] or "active") != "active":
                        return self._err(403, "所属租户已停用", "tenant_suspended")
                except Exception:
                    logging.getLogger(__name__).debug('ignored', exc_info=True)
            role = roles[0]
            prof = {"sub": user["id"], "name": user.get("name") or username,
                    "email": user.get("email") or "", "role": role, "roles": roles,
                    "tenant_id": user.get("tenant_id") or "",
                    "workspace_id": user.get("workspace_id") or "",
                    "portal": user.get("portal") or portal or account.portal_of_role(role),
                    "must_change_pwd": bool(user.get("must_change_pwd"))}
            _lg.success(_ip, ident)
            R.users.update(user["id"], last_login=db.now())
            R.audit_logs.log(actor=user["id"], action="auth.login", object=username,
                             ip=self.client_address[0] if self.client_address else "",
                             request_id=str(getattr(self, "_rid", "") or ""))
            return self._send_session(200, self._json({"user": prof, "need_choose": len(roles) > 1}), prof)
        if p == "/api/v1/me/profile":
            u = self._session_user()
            if not u:
                return self._err(401, "未登录", "unauthorized")
            # 手机号绑定账号不可改；邮箱非必填且可修改。审核员姓名/手机号由管理员配置，仅可改邮箱。
            b = self._body()
            _role = self._active_role()
            upd = {}
            for k in ("name", "email", "phone"):
                if k not in b:
                    continue
                v = str(b.get(k) or "").strip()
                if k == "email":
                    upd[k] = v   # 邮箱非必填，允许清空
                elif k == "name":
                    if _role == "reviewer":
                        continue
                    if not v:
                        return self._err(400, "姓名不能为空", "invalid_profile")
                    upd[k] = v
                elif k == "phone":
                    if _role == "reviewer":
                        continue
                    if not v:
                        return self._err(400, "手机号不能为空", "invalid_profile")
                    upd[k] = v
            if upd:
                R.users.update(u["sub"], **upd)
            return self._send(200, self._json({"ok": True, "updated": list(upd.keys())}))
        if p == "/api/v1/me/onboarded":
            u = self._session_user() or {}
            if not u:
                return self._err(401, "未登录", "unauthorized")
            R.users.update(u.get("sub", ""), onboarded_at=db.now())
            return self._send(200, self._json({"ok": True}))
        if p == "/api/v1/me/password":
            u = self._session_user()
            if not u:
                return self._err(401, "未登录", "unauthorized")
            b = self._body()
            # DU-09（P2，2026-11-25）：改密必须走统一密码策略——旧实现只校验
            # ``len(new)>=8``，首登账号可把密码设成 aaaaaaaa；validate_new_password
            # 已存在但未接线。现在 HTTP 与 CLI ``user change-password`` 共用
            # account.change_own_password（复杂度/常见弱口令/原密码/吊销旧 JWT 同源）。
            try:
                _pw_r = account.change_own_password(
                    u.get("sub", ""), str(b.get("old_password") or ""),
                    str(b.get("new_password") or ""))
            except ValueError as _pwe:
                if str(_pwe) == "原密码错误":
                    return self._err(400, "原密码错误", "wrong_password")
                return self._err(400, str(_pwe) or "密码不符合安全策略", "weak_password")
            # 改密后吊销所有旧 JWT（含本会话的旧 cookie），再以新版本重签当前会话。
            _new_ver = int((_pw_r or {}).get("token_version") or 0)
            prof2 = dict(u); prof2["must_change_pwd"] = False; prof2["token_version"] = _new_ver
            return self._send_session(200, self._json({"ok": True}), prof2)
        if p == "/api/v1/projects":
            return _review_routes.post_projects(self)
        if p.startswith("/api/v1/projects/") and p.endswith("/preview"):
            return _review_routes.post_project_preview(self, p)
        if p.startswith("/api/v1/projects/") and p.endswith("/manifest"):
            return _review_routes.post_project_manifest(self, p)
        if p.startswith("/api/v1/projects/") and p.endswith("/manifest/execute"):
            return _review_routes.post_project_manifest_execute(self, p)
        if p.startswith("/api/v1/projects/") and p.endswith("/ledger"):
            return _review_routes.post_project_ledger(self, p)
        if p.startswith("/api/v1/projects/") and p.endswith("/accept-gap"):
            return _review_routes.post_project_accept_gap(self, p)
        if p == "/api/v1/reviews/extra/decide":
            return _review_routes.post_reviews_extra_decide(self)
        if p == "/api/v1/reviews":
            b = self._body()
            key = self.headers.get("Idempotency-Key", "")
            _ru = self._session_user() or {}
            _scope = _idem_scope(_ru, "POST:/api/v1/reviews", b)
            cached = _idem_get(key)
            if cached:
                if len(cached) > 3 and cached[3] != _scope:
                    return self._err(409, "Idempotency-Key 已用于其他请求", "idempotency_conflict")
                return self._send(cached[1], cached[2])
            try:
                _docs = b.get("doc_paths") or ([config.GOLDEN] if config.GOLDEN else [])
                if not _docs:
                    return self._err(400, "缺少 doc_paths（且未配置默认样例）", "invalid_request")
                # P1-03：HTTP 不接受任意服务器本地路径；只允许上传目录，CLI 才可读本地路径
                if os.environ.get("RULEPROOF_ALLOW_EXTERNAL_REVIEW_PATHS") != "1":
                    from app.services import identifiers as _ids
                    for _dp in _docs:
                        if not _ids.is_uploaded_path(str(_dp or "")):
                            return self._err(403, "HTTP 审核只接受已上传文件", "external_path_forbidden")
                # 兼容接口：旧 /api/v1/reviews 保留 run_review，但已补 audit_run/last_run_id；
                # 产品主路径仍是 /projects + /audit。
                from app.services import audit_orchestrator as _ao
                _mode = str(b.get("mode") or "assisted")
                if _mode not in ("manual", "assisted"):
                    return self._err(400, "mode 只支持 manual/assisted", "invalid_mode")
                result = _ao.run(_ao.from_legacy(
                    b.get("name", "审核任务"), _docs,
                    points_path=b.get("points_path") or "",
                    semantic=config.LLM.get("enabled", False),
                    created_by=(self._session_user() or {}).get("sub", ""), mode=_mode))
            except Exception as e:  # noqa
                return self._err(500, f"审核失败：{type(e).__name__}", "review_failed")
            body = self._json(result)
            _idem_put(key, 200, body, _scope)
            return self._send(200, body)
        # L155：Extractor-Verifier 只读校验端点（POST 只读语义；校验/置信度纯函数，
        # 不写库、不写审计、不调模型）。实现见 review_routes.post_extraction_verify。
        if p == "/api/v1/extraction/verify":
            return _review_routes.post_extraction_verify(self)
        if p == "/api/v1/kie/extract":
            return _review_routes.post_kie_extract(self)
        if p == "/api/v1/findings":
            return _review_routes.post_findings(self)
        if p.startswith("/api/v1/projects/") and p.endswith("/accept-unknown"):
            # T-35：对象级例外授权 HTTP 接线。旧实现写 point_ids 批量审计（V08 之后
            # 不再放行，导致入口成功但报告仍阻断）；现改为 collect_unknown 取对象级
            # binding 后逐个 result_id 调用 report_gate.accept_unknown_object()。
            # 批量请求固定 400、hash/run 变化 409、execution_failed 409、跨租户/越权 403/404。
            # F-28 第二道角色校验：系统管理员/平台运营不写业务（不接受 unknown）。
            _d = self._business_write_denied("project.accept-unknown")
            if _d:
                return _d
            cid = p.split("/")[-2]
            _case, _deny = self._case_scope(cid)
            if _deny:
                return self._send_deny(_deny)
            from app.api import exception_routes as _exc
            _status, _out = _exc.post_accept(cid, self._body() or {},
                                             self._session_user() or {})
            return self._send(_status, self._json(_out))
        # T-50（W-14）V3.2 双轨数据产品路由（POST）：
        #   POST /api/v1/suppression-ledger/{id}/recover  人工恢复（写审计+写回 finding）
        #   POST /api/v1/human-omissions                  登记人工漏报
        # F-28 第二道角色校验 + 服务层 review.authorize_case（与 CLI 同源）。
        _v32p = _v32_route(p)
        if _v32p:
            return _v32_dispatch(self, _v32p, "POST")
        # T-51 隐藏疑似问题开关（POST）：打开 / 逐条裁决 / TTL 默认处置 / 复核模式。
        _ht_post = _hidden_toggle_route(p, "POST")
        if _ht_post:
            _ht_cid, _ht_kind, _ht_ident = _ht_post
            _case, _deny = self._case_scope(_ht_cid)
            if _deny:
                return self._send_deny(_deny)
            return _hidden_toggle_dispatch(self, _ht_cid, _ht_kind, _ht_ident)
        # T-43 人工复核闭环（POST）：裁决 / 人工漏报 / 后台对账。
        # F-28 第二道角色校验 + _case_scope（不存在/跨租户 404、跨空间/他人 403）；
        # 展示项复核/漏报/对账只允许审核员本人项目（业务管理员只读、系统管理员禁写）。
        _hr_post = _human_review_route(p, "POST")
        if _hr_post:
            _hr_cid, _hr_kind = _hr_post
            _d = self._business_write_denied(f"human_review.{_hr_kind}")
            if _d:
                return _d
            _case, _deny = self._case_scope(_hr_cid)
            if _deny:
                return self._send_deny(_deny)
            return _human_review_dispatch(self, _hr_cid, _hr_kind)
        if p.startswith("/api/v1/projects/") and p.endswith("/retry-failed"):
            return _review_routes.post_project_retry_failed(self, p)
        if p.startswith("/api/v1/projects/") and p.endswith("/ai-assist"):
            return _review_routes.post_project_ai_assist(self, p)
        if p.startswith("/api/v1/findings/") and p.split("/")[-1] in ("sediment", "update", "delete", "reject", "evidence", "decision"):
            from app.api import finding_routes as _fr
            _fb = self._body() or {}
            def _do_finding(_p=p, _b=_fb):
                _out = _fr.post(_p, _b, self._session_user() or {},
                                self._case_owned, self._active_role())
                if _out is None:
                    return 404, self._json({"error": "not_found", "code": "not_found"})
                return _out[0], self._json(_out[1])
            if p.endswith("/decision"):
                # C7：裁决是最高风险写（不可撤销的结论变更）→ 支持 Idempotency-Key
                _st, _pl = self._idem_write(f"POST:{p}", _fb, _do_finding)
                return self._send(_st, _pl)
            _out = _fr.post(p, _fb, self._session_user() or {},
                            self._case_owned, self._active_role())
            if _out is not None:
                return self._send(_out[0], self._json(_out[1]))
        if p == "/api/v1/upload":
            # DU-13（P2，2026-11-25）：隐藏 legacy 上传写路由无角色守卫，reviewer
            # 空 body 实测 400（到达 handler 而非 403）；管理员可经此绕过主链。
            # 该接口是 deprecated 兼容面，按“发起审核”权限收紧为仅审核员。
            from app.services import permission as _pm_up
            _u_up = self._session_user() or {}
            if not _pm_up.can(str(_u_up.get("role") or ""), "audit.run"):
                return self._err(403, "仅审核员可使用旧版上传审核接口（deprecated）", "forbidden")
            _d = self._business_write_denied("review.upload")
            if _d:
                return _d
            return _review_routes.post_upload(self)
        if p == "/api/v1/model/test":
            return self._send(200, self._json(model.test_connection()))
        if p == "/api/v1/ocr":
            return _review_routes.post_ocr(self, p)
        if p == "/api/v1/review-doc":
            return _review_routes.post_review_doc(self, p)
        if p == "/api/v1/judge":
            return _review_routes.post_judge(self, p)
        if p == "/api/v1/doc/parse":
            return _review_routes.post_doc_parse(self, p)
        if p == "/api/v1/sediment":
            return _review_routes.post_sediment(self)
        return self._err(404, "not found")

    def _static(self, name):
        with open(os.path.join(WEB, name), "rb") as f:
            return f.read()

    def log_message(self, fmt, *args):
        requestline = str(args[0]) if args else ""
        status = str(args[1]) if len(args) > 1 else ""
        parts = requestline.split(" ") if isinstance(requestline, str) else []
        method = parts[0] if parts else ""
        path = (parts[1] if len(parts) > 1 else "").split("?")[0]  # 去掉查询串，避免敏感参数入日志
        latency = round((time.time() - getattr(self, "_t0", time.time())) * 1000)
        # 统一 JSON 日志：兼容旧字段 method/path/ip/latency_ms，同时补齐
        # ts/level/rid/event/module/tenant/user/status/latency/error。
        obs.log_event("http.request", module="api.server",
                      rid=getattr(self, "_rid", None), status=status,
                      latency=latency, method=method, path=path,
                      latency_ms=latency,
                      ip=self.client_address[0] if self.client_address else "")
        obs.clear()


def _timeout_worker():
    import time as _t
    while True:
        try:
            project.scan_timeouts()
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        _t.sleep(1800)


def rule_stats():
    """兼容旧联动门禁：规则库统计已拆到 services.rule_library。"""
    from app.services import rule_library
    return rule_library.stats()


def main():
    import argparse
    obs.install()
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default=config.HOST,
                    help="监听地址（默认取 RULEPROOF_HOST；未设置时 127.0.0.1，"
                         "容器内需显式 0.0.0.0）")
    ap.add_argument("--port", type=int, default=config.PORT)
    args = ap.parse_args()
    # E-02：prod 下会话密钥缺失/占位时启动 fail-fast（可读错误 + 非 0 退出），
    # 禁止服务带病启动后登录表现为空响应/静默失败。
    try:
        auth.assert_session_secret_ready()
    except RuntimeError as exc:
        print(f"启动失败：{exc}", file=sys.stderr)
        print("提示：./start.sh 首次生产启动会自动生成并写入 .env；"
              "也可按上方命令生成后手动写入 .env 再启动。", file=sys.stderr)
        raise SystemExit(2)
    # L147（P0-2/P0-3）：静态加密/传输安全配置启动自检（只 WARN，不改变启动结果）。
    try:
        _log_security_startup_warnings()
    except Exception:  # noqa: BLE001 - 自检失败不得阻断启动
        logging.getLogger(__name__).warning("安全启动自检失败（不阻断启动）", exc_info=True)
    # L77（build49 P0，90 号 §二-3）：生产环境禁止回退杆（SINGLE_ENTRY_FIX=0 /
    # SNAPSHOT_V3=0）。启动期 fail-fast：可读配置错误 + 非 0 退出，先于 DB 初始化；
    # 非 prod 仅 warning，回退审计在 db.init_db 后补写。
    try:
        from app.services import single_entry as _se_guard
    except Exception:  # noqa: BLE001 - 守卫模块不可用不阻断启动（旧行为）
        _se_guard = None
        logging.getLogger(__name__).debug("single_entry startup guard unavailable",
                                          exc_info=True)
    if _se_guard is not None:
        try:
            # L94：只有 prod 需要“先于 DB 初始化 fail-fast”；非 prod 的 warning+审计
            # 延后到 db.init_db() 之后（旧实现先调用会在空库上写审计失败并被去重集合
            # 标记为已写，导致回退杆审计永久丢失）。
            if _se_guard.is_prod():
                _se_guard.assert_production_switches(emit_audit=False)
        except _se_guard.ConfigError as _cfg_exc:
            print(f"启动失败：{_cfg_exc}", file=sys.stderr)
            raise SystemExit(2)
    db.init_db()
    if _se_guard is not None:
        try:
            _se_guard.assert_production_switches(emit_audit=True)
        except _se_guard.ConfigError:  # prod 已在 init_db 前 fail-fast；此处不应出现
            logging.getLogger(__name__).warning(
                "rollback lever prod guard raised after init_db", exc_info=True)
        except Exception:  # noqa: BLE001 - 审计留痕失败不阻断启动（已 warning）
            logging.getLogger(__name__).debug("rollback lever audit skipped",
                                              exc_info=True)
    try:
        from app.services import task as _task_boot
        _task_boot.recover()
        # 多实例/崩溃实例巡检：定期只回收“心跳过期”的任务，本进程 live 任务不会被误杀。
        # 单实例重启（新 instance_id）也能在租约后自动回收上次残留，不必等下一次重启。
        try:
            _reap_interval = float(os.environ.get("RULEPROOF_TASK_REAP_INTERVAL", "60") or 0)
        except Exception:
            _reap_interval = 60.0

        def _task_reaper():
            import time as _rt
            while True:
                _rt.sleep(max(1.0, _reap_interval))
                try:
                    _task_boot.recover()
                except Exception:
                    logging.getLogger(__name__).debug("task reaper failed", exc_info=True)

        if _reap_interval > 0:
            threading.Thread(target=_task_reaper, daemon=True, name="task-reaper").start()
    except Exception:
        logging.getLogger(__name__).debug("task recovery skipped", exc_info=True)
    try:
        from app.services import permissions as _perms0
        _perms0.ensure_seed()
    except Exception:
        logging.getLogger(__name__).exception("权限种子初始化失败")
    engine.reload_ontology()
    # 只保留 open.deliver_pending 一条投递链路；旧的 webhook_worker 会造成重复投递
    # 反馈队列调度：自动驱动误报归因智能体
    try:
        scheduler.start()
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    try:
        threading.Thread(target=_timeout_worker, daemon=True).start()
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)   # Webhook 异步投递 worker
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    # X-12 P0-2：启动即做「生效口径回退一致性检查」——漂移规则清单 WARN 结构化日志 +
    # 审计（开关=0 时按回退风险级别），不再等一次 env 变更后静默丢规则。
    try:
        from app.services import rule as _rule_boot
        _boot_eff = _rule_boot.run_effective_select_startup_check()
        if _boot_eff.get("dropped_count"):
            logging.getLogger(__name__).warning(
                "RULE_EFFECTIVE_SELECT_STARTUP dropped=%s codes=%s",
                _boot_eff.get("dropped_count"),
                [x.get("code") for x in _boot_eff.get("dropped") or []][:20])
    except Exception:
        logging.getLogger(__name__).exception(
            "生效口径回退一致性检查失败（不阻断启动，但需人工关注）")
    print(f"{config.APP_NAME} v{config.APP_VERSION} → http://{args.host}:{args.port}")
    import threading as _th

    def _open_worker():
        import time as _t
        while True:
            try:
                open_service.process_tasks(limit=2)
                open_service.deliver_pending(limit=10)
            except Exception:
                logging.getLogger(__name__).debug("open worker error", exc_info=True)
            _t.sleep(10)

    if str(os.environ.get("RULEPROOF_OPEN_WORKER", "1")) not in ("0", "false", "no"):
        _th.Thread(target=_open_worker, daemon=True, name="open-delivery").start()
    AppServer((args.host, args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
