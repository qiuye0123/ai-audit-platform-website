"""决策表路由：从 server.py 抽出的独立领域。"""
from __future__ import annotations
from ..services import decision_table, permissions as _perms


def get(path: str, meta_fn=None) -> tuple | None:
    if path == "/api/v1/decision-tables":
        items = decision_table.list_tables()
        meta = (meta_fn([x.get("code") or "" for x in items]) if meta_fn else {})
        for x in items:
            m = meta.get(x.get("code") or "", {})
            x["owner"] = x.get("owner") or m.get("owner") or ""
            x["updated_at"] = x.get("updated_at") or m.get("updated_at") or x.get("created_at") or ""
            x["records"] = m.get("records", 0)
            x["last_action"] = m.get("last_action", "")
        return 200, {"items": items}
    if path.startswith("/api/v1/decision-tables/") and path.count("/") == 4:
        code = path.split("/")[-1]
        return 200, decision_table.detail(code)
    return None


def post(path: str, body: dict, user: dict, set_owner=None) -> tuple | None:
    body = body or {}
    user = user or {}
    # 决策表是业务规则资产：只有业务管理员可以写；审核员/系统/平台只读。
    if (user.get("role") or "") != "admin":
        return 403, {"error": "仅业务管理员可维护决策表", "code": "forbidden"}
    # T-199：权限点第二道（旧 dt.manage 死权限点接线；DB 权限包=注册表缓存）
    if not _perms.has(user.get("sub", ""), "dt.manage"):
        return 403, {"error": "无权限（需 dt.manage）", "code": "forbidden"}
    if path == "/api/v1/decision-tables":
        # X-13：canary_percent 原样下传，由服务层 normalize_canary 处理
        # （0 是合法值=全量关闭灰度；旧 `int(x or 100)` 会把 0 吞成 100）。
        if "canary_percent" in body:
            _cv, _cerr = decision_table.normalize_canary(body.get("canary_percent"))
            if _cerr:
                return 400, {"error": _cerr, "code": "invalid_canary"}
        else:
            _cv = 100
        out = decision_table.create(
            body.get("code", ""), body.get("name", ""), body.get("rules") or [],
            body.get("hit_policy", "first"), body.get("source", ""), user.get("sub", ""),
            body.get("scope_types") or [], _cv)
        # P1-B3-02 / P2-B3-02：code 是业务主键，重复创建 409 duplicate_code（不静默覆盖、
        # 也不允许两条同 code 并存）；非法字符/超长 400 invalid_code（不让异常编码进
        # DT-<code> 包装规则、审计 object、导出与冲突检测）。
        _err_code = str(out.get("code") or "")
        if _err_code == "duplicate_code":
            return 409, out
        if _err_code == "invalid_code":
            return 400, out
        if set_owner and not out.get("error"):
            set_owner("dt", body.get("code", ""), user.get("name") or user.get("sub", ""), user.get("sub", ""))
        return 200, out
    if path.startswith("/api/v1/decision-tables/") and path.endswith("/copy") and path.count("/") == 5:
        code = path.split("/")[-2]
        return 200, decision_table.copy_as_draft(code, str(body.get("new_code") or ""), user.get("sub", ""))
    if path.startswith("/api/v1/decision-tables/") and path.count("/") == 4:
        code = path.split("/")[-1]
        return 200, decision_table.update(
            code, body.get("name", ""), body.get("rules"), body.get("hit_policy", ""),
            body.get("scope_types"),
            body.get("canary_percent") if "canary_percent" in body else None,
            user.get("sub", ""))
    if path.startswith("/api/v1/decision-tables/") and path.endswith("/archive") and path.count("/") == 5:
        # X-13：发布后整体关闭/下线入口（旧实现只有 create/copy/update/publish/evaluate，
        # 灰度关不掉时只能删数据）。写审计、幂等；下线后 evaluate 显式 state=archived。
        code = path.split("/")[-2]
        out = decision_table.archive(code, user.get("sub", ""))
        return (200 if out.get("ok") else 404), out
    if path.startswith("/api/v1/decision-tables/") and path.endswith("/publish") and path.count("/") == 5:
        code = path.split("/")[-2]
        return 200, decision_table.publish(code, user.get("sub", ""))
    if path.startswith("/api/v1/decision-tables/") and path.endswith("/evaluate") and path.count("/") == 5:
        code = path.split("/")[-2]
        # B3-03（评审 P1）：「测试求值」必须与真实审核同源同参。
        # 修复前只传 facts，丢掉 body 里的 case_id / audit_type，而 evaluate 正是用这两个
        # 参数决定 canary 灰度分流与 scope_types 适用范围 → 测试求值全 match，真实审核
        # 却 skipped，客户「测出来能命中、上线不命中」。
        # 这里原样透传（字符串归一，缺省空串=不参与分流，与服务层默认一致）。
        return 200, decision_table.evaluate(
            code, body.get("facts") or {},
            audit_type=str(body.get("audit_type") or ""),
            case_id=str(body.get("case_id") or ""))
    return None
