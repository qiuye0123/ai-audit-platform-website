"""测试入口访问控制：只允许显式注入的测试账号，生产环境硬禁用。

从 server.py 抽出，避免安全开关和路由处理混在一个文件。
"""
from __future__ import annotations
import json
import os
import logging
from .. import db, auth
from ..services import account


def _accounts() -> dict:
    try:
        raw = os.environ.get("RULEPROOF_TEST_ACCOUNTS_JSON") or ""
        if not raw:
            return {}
        data = json.loads(raw)
        if not isinstance(data, dict):
            return {}
        return {str(k): (str(v[0]), str(v[1])) for k, v in data.items()
                if isinstance(v, (list, tuple)) and len(v) >= 2}
    except Exception:
        logging.getLogger(__name__).warning("test account JSON invalid", exc_info=True)
        return {}


def enabled(remote_addr: str) -> bool:
    if (os.environ.get("RULEPROOF_ENV") or "").strip().lower() in ("prod", "production"):
        return False
    if (os.environ.get("RULEPROOF_TEST_AUTOLOGIN") or "0").strip() not in ("1", "true", "yes"):
        return False
    host = remote_addr or ""
    return host in ("127.0.0.1", "::1") or host.startswith("127.")


def profile(kind: str):
    accounts = _accounts()
    if kind not in accounts:
        return None
    phone, pwd = accounts[kind]
    try:
        with db.session() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM user WHERE phone=? AND status='active'", (phone,)).fetchall()]
    except Exception:
        rows = []
    portals = {"platform": "platform", "system": "admin", "business": "admin", "reviewer": "reviewer"}
    rows = [x for x in rows if (x.get("portal") or "") == portals[kind]]
    for user in rows:
        if not auth.verify_password(pwd, user.get("password_hash") or "", user.get("salt") or ""):
            continue
        roles = account.roles_of(user["id"]) or []
        need = {"system": "super_admin", "business": "admin", "platform": "platform_op", "reviewer": "reviewer"}[kind]
        if need not in roles:
            continue
        role = "super_admin" if kind == "system" else ("admin" if kind == "business" else roles[0])
        return {"sub": user["id"], "name": user.get("name") or phone,
                "email": user.get("email") or "", "role": role, "roles": roles,
                "portal": portals[kind], "must_change_pwd": False}
    return None
