# -*- coding: utf-8 -*-
"""T-75 知识库 HTTP 路由（从 server.py 只做分发，业务在 app.services.knowledge）。

路由（全部按当前会话租户/空间隔离；跨空间/租户一律 404，不泄露存在性）：
- GET    /api/v1/knowledge                      一级文件夹 + 文件列表（?folder_id= 可选过滤）
- GET    /api/v1/knowledge/recycle              回收站：已软删的文件 + 文件夹（T-188）
- GET    /api/v1/knowledge/files/<id>/view      查看：pdf/图片/txt inline；office 安全下载
- POST   /api/v1/knowledge/folders              建一级文件夹（同空间同名 409）
- POST   /api/v1/knowledge/files                multipart 上传（重复 sha256 幂等）；
                                                JSON 时为写命令分支（T-188，见下）
- DELETE /api/v1/knowledge/files/<id>?confirm=1 彻底删除文件（必须二次确认，不可恢复）
- DELETE /api/v1/knowledge/folders/<id>?confirm=1 彻底删除一级文件夹（连同文件，不可恢复）

T-188 写命令（POST /api/v1/knowledge/files，Content-Type: application/json）：
- {"op":"rename","kind":"file|folder","id":"...","name":"新名称"}
  重命名：服务端清洗名称/类型白名单/同空间重名拒绝 + 审计
- {"op":"move","ids":["..."],"folder_id":"kf_x|"}
  移动文件到一级文件夹（folder_id='' = 未归档）；目标不存在/跨空间 404
- {"op":"trash","kind":"file|folder","ids":["..."]}
  删除进回收站（软删）；kind=folder 时一次一个文件夹，连同其存活文件一起
- {"op":"restore","kind":"file|folder","ids":["..."]}
  从回收站恢复；文件夹恢复时一并恢复随它删除的文件；同名冲突 409
- {"op":"purge","kind":"file|folder","ids":["..."],"confirm":true}
  彻底删除（必须 confirm=true，二次确认 + 审计，物理文件清理）

说明：POST 的 JSON 命令复用既有「/api/v1/knowledge/files」分发点，是为了不新增
server.py 路由（本任务不改 server.py 分发层）；业务校验、权限、审计全部在 service 层，
与 DELETE/上传同源，不产生「前端隐藏代替权限」的绕过。DELETE 端点保留原语义
（彻底删除），因此旧调用方/旧测试的 API 语义不变；页面上「删除」走 trash（回收站）。

边界：系统管理员/平台运营按平台既有业务边界 403（service 第二道校验）；业务管理员与
审核员在所属工作空间内全部权限；不提供分享/权限设置/二级文件夹入口。
"""
from __future__ import annotations

import re
import urllib.parse

from ..services import knowledge


def _user(handler) -> dict:
    return handler._session_user() or {}


def _is_json(handler) -> bool:
    ct = str(handler.headers.get("Content-Type", "") or "").lower()
    return "application/json" in ct


def get(handler, path: str, query: dict):
    """GET 分支：返回 (status, body) 或 (status, bytes, ctype, headers)，None=非本组。"""
    try:
        if path.rstrip("/") == "/api/v1/knowledge":
            return 200, knowledge.list_knowledge(
                _user(handler), folder_id=str((query or {}).get("folder_id") or ""))
        if path.rstrip("/") == "/api/v1/knowledge/recycle":
            return 200, knowledge.list_recycle(_user(handler))
        m = re.fullmatch(r"/api/v1/knowledge/files/([^/]+)/view", path)
        if m:
            fid = urllib.parse.unquote(m.group(1))
            info = knowledge.resolve_view(_user(handler), fid)
            download = str((query or {}).get("download") or "").lower() in ("1", "true", "yes")
            inline = bool(info["inline"]) and not download
            try:
                data = info["path"].read_bytes()
            except OSError:
                return 404, {"ok": False, "error": "文件已丢失（存储中不存在）",
                             "code": "not_found"}
            headers = {
                "Content-Disposition": knowledge.content_disposition(info["filename"], inline),
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "private, max-age=60",
            }
            ctype = info["mime"] if inline else "application/octet-stream"
            return 200, data, ctype, headers
        if path.startswith("/api/v1/knowledge"):
            return 404, {"ok": False, "error": "接口不存在", "code": "not_found"}
        return None
    except knowledge.KnowledgeError as e:
        return e.status, e.payload()
    except Exception:  # noqa: BLE001
        import logging
        logging.getLogger(__name__).warning("knowledge GET failed", exc_info=True)
        return 500, {"ok": False, "error": "知识库读取失败", "code": "internal_error"}


def post(handler, path: str, user: dict):
    """POST 分支：建文件夹 / multipart 上传 / JSON 写命令（重命名/移动/回收站）。"""
    try:
        if path.rstrip("/") == "/api/v1/knowledge/folders":
            b = handler._body() or {}
            return 200, knowledge.create_folder(user, b.get("name") or "")
        if path.rstrip("/") == "/api/v1/knowledge/files":
            # 上传是 multipart；T-188 的写命令走 JSON（同一分发点，不改 server.py）。
            if _is_json(handler) and not str(handler.headers.get("Content-Type", "")).lower().startswith("multipart/"):
                return 200, knowledge.command(user, handler._body() or {})
            return _upload(handler, user)
        if path.startswith("/api/v1/knowledge"):
            return 404, {"ok": False, "error": "接口不存在", "code": "not_found"}
        return None
    except knowledge.KnowledgeError as e:
        return e.status, e.payload()
    except Exception:  # noqa: BLE001
        import logging
        logging.getLogger(__name__).warning("knowledge POST failed", exc_info=True)
        return 500, {"ok": False, "error": "知识库写入失败", "code": "internal_error"}


def delete(handler, path: str, user: dict):
    """DELETE 分支：彻底删除文件 / 一级文件夹（均需 confirm=1，不可恢复）。

    页面「删除」= 回收站软删，走 POST 命令 op=trash；DELETE 保留原「彻底删除」语义。
    """
    try:
        q = handler._query() if hasattr(handler, "_query") else {}
        confirm = str((q or {}).get("confirm") or "").lower() in ("1", "true", "yes")
        parts = path.strip("/").split("/")
        if len(parts) == 5 and parts[:3] == ["api", "v1", "knowledge"]:
            obj, oid = parts[3], urllib.parse.unquote(parts[4])
            if obj == "files":
                return 200, knowledge.delete_file(user, oid, confirm=confirm)
            if obj == "folders":
                return 200, knowledge.delete_folder(user, oid, confirm=confirm)
        if path.startswith("/api/v1/knowledge"):
            return 404, {"ok": False, "error": "接口不存在", "code": "not_found"}
        return None
    except knowledge.KnowledgeError as e:
        return e.status, e.payload()
    except Exception:  # noqa: BLE001
        import logging
        logging.getLogger(__name__).warning("knowledge DELETE failed", exc_info=True)
        return 500, {"ok": False, "error": "知识库删除失败", "code": "internal_error"}


def _upload(handler, user: dict):
    """multipart 上传：先按 Content-Length 拦截超大请求，再解析 multipart。"""
    try:
        clen = int(handler.headers.get("Content-Length", 0) or 0)
    except Exception:
        clen = 0
    cap = knowledge.max_bytes() + 1024 * 1024  # multipart 头/边界开销余量
    limit_mb = max(1, knowledge.max_bytes() // 1024 // 1024)
    if clen and clen > cap:
        return 413, {"ok": False,
                     "error": f"文件超过 {limit_mb}MB 上限，请压缩后重试",
                     "code": "file_too_large", "limit_bytes": knowledge.max_bytes()}
    raw = handler._body_raw()
    fields, files = knowledge.parse_multipart(raw, handler.headers.get("Content-Type", ""))
    if not files:
        return 400, {"ok": False, "error": "缺少上传文件（multipart 字段名 file）",
                     "code": "invalid_request"}
    part = next((x for x in files if x.get("name") == "file"), files[0])
    out = knowledge.upload(
        user, part.get("filename") or "", part.get("data") or b"",
        folder_id=str(fields.get("folder_id") or "").strip(),
        mime=part.get("content_type") or "", source=str(fields.get("source") or ""))
    return 200, out
