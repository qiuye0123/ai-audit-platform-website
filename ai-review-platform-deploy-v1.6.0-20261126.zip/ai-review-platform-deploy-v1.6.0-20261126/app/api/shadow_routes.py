# -*- coding: utf-8 -*-
"""影子池（三区仲裁）HTTP 适配层（T-203 影子池产品化 Phase 2）。

## 职责边界（为什么是薄适配）

服务层 ``app/services/shadow_pool.py`` 是影子池**唯一事实源**：仲裁 R1–R4、
``shadow_item`` 表、reveal 语义、四动作裁决、二次复核升级、指标、导出、
审计（``shadow.added/revealed/decided/escalated/purged``）、权限（``shadow.view`` /
``shadow.decide`` / ``shadow.export``）全部在服务层强制。本模块**只做**：

1. 解析路径 → 服务函数；
2. session/tenant/space 上下文（复用 ``Handler._session_user`` / ``_case_scope``）；
3. 服务层返回的 ``status/code`` → HTTP 状态码（一一映射，不新增语义）；
4. ``shadow export`` 的 format=json|csv 序列化（权限仍在服务层）。

CLI（``app/cli.py`` 的 ``rp shadow *``）调用**同一批服务函数**，因此
HTTP 与 CLI 的权限、审计、错误码完全同源（测试见 ``scripts/qa/shadow_phase2_test.py``）。

## 路由（契约见 docs/qa/影子池产品化_20261120.md §10.1；本文件按 T-203 任务书路径）

| 方法/路径 | 说明 | 权限 |
|---|---|---|
| ``GET  /api/v1/projects/{cid}/shadow-items`` | 默认只给 N/汇总，**不返回明细** | ``shadow.view``（reviewer 本人项目 / admin 只读） |
| ``POST /api/v1/projects/{cid}/shadow-items/reveal`` | 二次确认（``confirm=true``）打开明细，写 ``shadow.revealed`` | 同上；盲审未提交 403 ``evaluation_locked`` |
| ``POST /api/v1/projects/{cid}/shadow-items/{id}/decide`` | 四动作 confirm/false_positive/unsure/skip | ``shadow.decide``（仅 reviewer 本人项目；admin 403） |
| ``GET  /api/v1/projects/{cid}/shadow-items/metrics`` | 指标（池大小/真问题比例/裁决耗时/升级率） | ``shadow.view`` |
| ``GET  /api/v1/projects/{cid}/shadow-items/export`` | 导出影子清单（``format=json|csv``） | **``shadow.export``，默认仅 admin** |
| ``POST /api/v1/shadow-items/escalate`` | 未裁决 → 二次复核（系统/调度动作） | 调度令牌；人类角色 403 |

契约兼容别名（同服务函数，便于按 §10.1 路径调用）：
``GET /api/v1/projects/{cid}/shadow-metrics``、``GET /api/v1/projects/{cid}/shadow-export``。

## 系统动作（escalate）如何认证

escalate 是**系统/调度**动作，服务层 ``shadow_pool.escalate_pending`` 明确拒绝任何
人类角色（``role`` 非空即 403）。HTTP 侧因此不能走普通会话身份，判定顺序：

1. 请求头 ``X-Scheduler-Token``（或 ``Authorization: Bearer <token>``）与
   ``RULEPROOF_SCHEDULER_TOKEN`` 完全一致 → 允许，actor 记为
   ``system:scheduler``（写审计）。**未配置该 env 时一律拒绝**（fail-closed）。
2. 否则有会话用户 → ``403 forbidden``（人类角色不可调用系统动作）。
3. 既无令牌也无会话 → ``401 unauthenticated``。

## 依赖约束

本模块只 import 服务层唯一入口（``app.services.dual_track_gateway``）与标准库，
**不 import** ``app.api.server``，避免 ``server.py`` → ``shadow_routes`` → ``server.py``
循环导入；也不直接 import ``shadow_pool``（T-202 唯一入口 AST 约束）。
``server.py`` 只需两行注册（见 ``docs/qa/影子池Phase2_20261120.md`` §4）：

    if _shadow_routes.handle(self, "GET"):  return
    if _shadow_routes.handle(self, "POST"): return
"""
from __future__ import annotations

import csv
import io
import json
import os

# T-202 唯一入口约束：HTTP 层只允许经 dual_track_gateway 调用五套机制，
# 不直接 import shadow_pool（AST 约束见 scripts/qa/dual_track_gateway_test.py F 组）。
from app.services import dual_track_gateway as GW

# 常量/文案同源（状态、动作、理由、提示语）也走 gateway 快照。
SP_META = GW.shadow_constants()

# 服务层 code → HTTP 状态码（其余按服务层返回的 status；没有 status 的 ok=False 记 400）。
_CODE_STATUS = {
    "unauthenticated": 401,
    "forbidden": 403,
    "read_only_shadow_pool": 403,
    "shadow_export_forbidden": 403,
    "evaluation_locked": 403,
    "scheduler_token_required": 403,
    "not_found": 404,
    "invalid_shadow_action": 400,
    "invalid_shadow_reason": 400,
    "invalid_zone_source": 400,
    "invalid_escalation_config": 400,
    "case_ids_required": 400,
    "case_id_required": 400,
    "confirm_required": 400,
    "bad_request": 400,
    "discarded_not_decidable": 409,
}

# 允许 `_guard` 之外自带鉴权的路径（escalate 需要在未登录时校验调度令牌）。
_SYSTEM_PATHS = {"/api/v1/shadow-items/escalate"}


# ---------------------------------------------------------------------------
# 通用工具
# ---------------------------------------------------------------------------
def _norm_q(query: dict, *names, default: str = "") -> str:
    """取 query 首个命中值（``Handler._query()`` 返回 {k: [v, ...]}）。"""
    q = query or {}
    for name in names:
        if name in q:
            val = q.get(name)
            if isinstance(val, (list, tuple)):
                return str(val[0]) if val else default
            return str(val)
    return default


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value or "").strip().lower() in ("1", "true", "yes", "on", "y")


def _send_service(handler, out: dict):
    """服务层结果 → HTTP（ok=True 200；否则按 code/status 映射）。"""
    if out.get("ok"):
        return handler._send(200, handler._json(out))
    code = str(out.get("code") or "")
    status = int(_CODE_STATUS.get(code) or out.get("status") or 400)
    return handler._send(status, handler._json(out))


def _actor(handler) -> tuple[str, str]:
    user = handler._session_user() or {}
    actor = str(user.get("sub") or user.get("id") or "")
    role = str(user.get("role") or "")
    return actor, role


def _scoped_case(handler, cid: str):
    """项目作用域：不存在/跨租户 404、无权限/跨空间 403（与既有业务路由同源）。

    服务层还会再校验一次 ``review.authorize_case``（前端隐藏 ≠ 权限）。
    返回 ``(case_row, deny)``，deny 非 None 时调用方直接回写。
    """
    try:
        case_row, deny = handler._case_scope(cid)
    except Exception:  # noqa: BLE001 - 作用域校验异常必须 fail-closed
        return None, (503, {"error": "项目作用域校验异常，已拒绝请求",
                            "code": "permission_check_failed"})
    return case_row, deny


# ---------------------------------------------------------------------------
# 路由解析
# ---------------------------------------------------------------------------
def route(path: str, method: str = "GET"):
    """解析影子池路由；非本组返回 None（不影响既有 dispatch）。

    返回 ``(kind, cid, item_id)``：
    ``kind`` ∈ summary/reveal/decide/metrics/export/escalate。
    """
    p = str(path or "").strip()
    if len(p) > 1 and p.endswith("/"):
        p = p.rstrip("/")
    m = str(method or "GET").upper()

    # 系统动作（跨项目）：POST /api/v1/shadow-items/escalate
    if p == "/api/v1/shadow-items/escalate" and m == "POST":
        return ("escalate", "", "")

    parts = [x for x in p.strip("/").split("/") if x]
    if len(parts) < 5 or parts[:3] != ["api", "v1", "projects"]:
        return None
    cid, tail = parts[3], parts[4:]
    if m == "GET":
        if tail == ["shadow-items"]:
            return ("summary", cid, "")
        if tail == ["shadow-items", "metrics"] or tail == ["shadow-metrics"]:
            return ("metrics", cid, "")
        if tail == ["shadow-items", "export"] or tail == ["shadow-export"]:
            return ("export", cid, "")
        return None
    if tail == ["shadow-items", "reveal"]:
        return ("reveal", cid, "")
    if len(tail) == 3 and tail[0] == "shadow-items" and tail[2] == "decide" and tail[1]:
        return ("decide", cid, tail[1])
    return None


# ---------------------------------------------------------------------------
# 各路由处理
# ---------------------------------------------------------------------------
def get_summary(handler, cid: str):
    actor, role = _actor(handler)
    case_row, deny = _scoped_case(handler, cid)
    if deny:
        return handler._send_deny(deny)
    q = handler._query() or {}
    # 默认 reveal=False：只给 N/汇总，明细为空（契约硬要求：默认不返回明细）。
    reveal = _as_bool(_norm_q(q, "reveal", default="0"))
    out = GW.shadow_items(
        cid, reveal=reveal, actor=actor, role=role,
        reason=_norm_q(q, "reason"), status=_norm_q(q, "status"),
        include_purged=_as_bool(_norm_q(q, "include_purged", default="0")),
        via="http_get")
    out.setdefault("requested_reveal", reveal)
    return _send_service(handler, out)


def post_reveal(handler, cid: str):
    actor, role = _actor(handler)
    body = handler._body() or {}
    if not _as_bool(body.get("confirm")):
        return handler._err(
            400, "打开影子池需要二次确认（confirm=true；打开动作将被审计）",
            "confirm_required")
    case_row, deny = _scoped_case(handler, cid)
    if deny:
        return handler._send_deny(deny)
    out = GW.shadow_items(
        cid, reveal=True, actor=actor, role=role,
        reason=str(body.get("reason") or ""), status=str(body.get("status") or ""),
        via="http_reveal")
    return _send_service(handler, out)


def post_decide(handler, cid: str, item_id: str):
    actor, role = _actor(handler)
    body = handler._body() or {}
    action = str(body.get("action") or body.get("decision") or "")
    # 写业务第二道角色校验（与 HTTP 其它业务写一致）；服务层还会再校验一次。
    try:
        denied = handler._business_write_denied("shadow.decide")
    except Exception:  # noqa: BLE001
        denied = None
    if denied:
        return denied
    case_row, deny = _scoped_case(handler, cid)
    if deny:
        return handler._send_deny(deny)
    out = GW.decide(cid, item_id, action, actor=actor, role=role,
                    note=str(body.get("note") or body.get("reason") or ""))
    return _send_service(handler, out)


def get_metrics(handler, cid: str):
    actor, role = _actor(handler)
    case_row, deny = _scoped_case(handler, cid)
    if deny:
        return handler._send_deny(deny)
    return _send_service(handler, GW.shadow_metrics(cid, actor=actor, role=role))


def get_export(handler, cid: str):
    actor, role = _actor(handler)
    q = handler._query() or {}
    fmt = (_norm_q(q, "format", default="json") or "json").lower()
    include_discarded = _as_bool(_norm_q(q, "include_discarded", default="1"))
    case_row, deny = _scoped_case(handler, cid)
    if deny:
        return handler._send_deny(deny)
    out = GW.shadow_export(cid, actor=actor, role=role,
                           include_discarded=include_discarded)
    if not out.get("ok"):
        return _send_service(handler, out)
    if fmt not in ("json", "csv"):
        return handler._err(400, "format 仅支持 json|csv", "invalid_format")
    payload = dict(out)
    payload["format"] = fmt
    if fmt == "csv":
        payload["csv"] = _items_to_csv(out.get("items") or [])
        payload["csv_columns"] = _CSV_COLUMNS
    return _send_service(handler, payload)


_CSV_COLUMNS = ("id", "zone", "zone_source", "shadow_reason", "shadow_status",
                "shadow_round", "rule_code", "object_id", "subject", "issue_type",
                "severity", "risk_level", "shadow_confidence", "shadow_reviewed_by",
                "shadow_reviewed_at", "default_disposition", "created_at", "warning")


def _items_to_csv(items: list) -> str:
    """影子清单 CSV（导出物只含白名单字段；不含任何 gold 字段）。"""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(_CSV_COLUMNS), extrasaction="ignore")
    writer.writeheader()
    for item in items:
        writer.writerow({k: item.get(k, "") for k in _CSV_COLUMNS})
    return buf.getvalue()


def post_escalate(handler):
    """系统/调度动作：未裁决影子项 → 二次复核队列。

    认证：``RULEPROOF_SCHEDULER_TOKEN`` 与请求头一致 → system actor；
    否则有会话 → 403（人类角色不可调用系统动作）；无会话 → 401。
    """
    token_expected = str(os.environ.get("RULEPROOF_SCHEDULER_TOKEN") or "").strip()
    provided = str(handler.headers.get("X-Scheduler-Token") or "").strip()
    if not provided:
        auth = str(handler.headers.get("Authorization") or "").strip()
        if auth.lower().startswith("bearer "):
            provided = auth[7:].strip()
    if token_expected and provided and provided == token_expected:
        actor = "system:scheduler"
        role = ""
    else:
        user = handler._session_user() or {}
        if user:
            return handler._err(
                403, "二次复核升级是系统/调度动作：人类角色不可调用"
                "（请通过调度器携带 X-Scheduler-Token）", "forbidden")
        if not token_expected:
            return handler._err(
                403, "未配置 RULEPROOF_SCHEDULER_TOKEN：拒绝系统动作（fail-closed）",
                "scheduler_token_required")
        return handler._err(401, "未认证", "unauthenticated")
    body = handler._body() or {}
    case_ids = body.get("case_ids") or body.get("cases") or []
    if isinstance(case_ids, str):
        case_ids = [x for x in case_ids.replace(",", " ").split() if x]
    case_id = str(body.get("case_id") or "")
    if case_id and case_id not in case_ids:
        case_ids = [case_id] + [x for x in case_ids if x]
    try:
        # 注意：0 是合法值（"刚创建也要转/不限时间"），不能用 `or` 兜底（0 会被吞成默认值）。
        _rounds_raw = body.get("rounds")
        rounds = int(_rounds_raw if _rounds_raw is not None
                     else SP_META["default_escalation_rounds"])
        _older_raw = body.get("older_than_hours")
        if _older_raw is None:
            _older_raw = body.get("older_than")
        older = int(_older_raw if _older_raw is not None
                    else SP_META["default_escalation_hours"])
    except (TypeError, ValueError):
        return handler._err(400, "rounds/older_than_hours 必须为整数",
                            "invalid_escalation_config")
    out = GW.escalate_pending(case_ids, rounds=rounds, older_than_hours=older,
                              actor=actor, role=role,
                              dry_run=_as_bool(body.get("dry_run")))
    return _send_service(handler, out)


# ---------------------------------------------------------------------------
# 统一入口（server.py 只加两行注册）
# ---------------------------------------------------------------------------
def handle(handler, method: str = "GET") -> bool:
    """在现有 HTTP Handler 上分发影子池路由；返回 True 表示已发送响应。

    ``server.py`` 注册位置（在 ``evolution.handle_http`` 之后、``_guard`` 之前）：

        if _shadow_routes.handle(self, "GET"):  return
        if _shadow_routes.handle(self, "POST"): return

    非本组路由返回 False（零影响既有 dispatch）。
    """
    m = str(method or "GET").upper()
    path = str(getattr(handler, "path", "") or "").split("?", 1)[0]
    routed = route(path, m)
    if not routed:
        return False
    kind, cid, item_id = routed

    # 系统动作自带认证（需在未登录时校验调度令牌），不走会话 guard。
    if kind == "escalate":
        post_escalate(handler)
        return True

    # 其余路径沿用既有 guard（未登录 401 / 角色边界 / 平台边界 / 改密拦截等）。
    gate = handler._guard(m, path)
    if gate:
        handler._send(gate[0], gate[1])
        return True

    if kind == "summary":
        get_summary(handler, cid)
    elif kind == "reveal":
        post_reveal(handler, cid)
    elif kind == "decide":
        post_decide(handler, cid, item_id)
    elif kind == "metrics":
        get_metrics(handler, cid)
    elif kind == "export":
        get_export(handler, cid)
    else:  # pragma: no cover - route() 已保证
        return False
    return True


__all__ = ["route", "handle", "get_summary", "post_reveal", "post_decide",
           "get_metrics", "get_export", "post_escalate"]
