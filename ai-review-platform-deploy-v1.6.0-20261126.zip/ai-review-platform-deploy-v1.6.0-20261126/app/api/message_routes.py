"""消息中心/通知配置路由：从 server.py 抽出的消息域。

T-199（2026-11-20）：消息域权限点从单一事实源接线——
- 消息中心读接口（列表/未读/已读）要求 ``msg.view``；
- 通知配置（平台级全局单例）要求 ``config.notify``（另有 super_admin 角色门禁）。
"""
from __future__ import annotations
from ..services import notify
from ..services import permissions as _perms


def _has(user: dict, code: str) -> bool:
    """按账号真实权限包判定（DB 权限包是注册表缓存；super_admin 由通配持有）。"""
    return _perms.has((user or {}).get("sub", ""), code)


def get(path: str, user: dict):
    if path == "/api/v1/notify/channels":
        return 200, notify.channel_status()
    if path == "/api/v1/notify/config":
        if (user or {}).get("role") != "super_admin":
            return 403, {"error": "仅系统管理员可配置消息", "code": "forbidden"}
        if not _has(user, "config.notify"):
            return 403, {"error": "无权限（需 config.notify）", "code": "forbidden"}
        return 200, notify.get_config()
    if path == "/api/v1/notifications":
        if not _has(user, "msg.view"):
            return 403, {"error": "无权限（需 msg.view）", "code": "forbidden"}
        return 200, notify.list_for((user or {}).get("sub", ""), limit=1000)
    if path == "/api/v1/notifications/unread":
        if not _has(user, "msg.view"):
            return 403, {"error": "无权限（需 msg.view）", "code": "forbidden"}
        return 200, {"count": notify.unread_count((user or {}).get("sub", ""))}
    if path == "/api/v1/alerts":
        return 200, notify.alerts()
    return None


def post(path: str, user: dict, body: dict):
    if path == "/api/v1/notify/config":
        if (user or {}).get("role") != "super_admin":
            return 403, {"error": "仅系统管理员可配置消息", "code": "forbidden"}
        if not _has(user, "config.notify"):
            return 403, {"error": "无权限（需 config.notify）", "code": "forbidden"}
        body = body or {}
        cfg = body.get("config") if isinstance(body, dict) and "config" in body else body
        try:
            return 200, notify.save_config(
                cfg, (user or {}).get("sub", ""),
                actor_role=(user or {}).get("role", ""))
        except notify.NotifyConfigError as e:
            return 400, {"error": str(e), "code": notify.NotifyConfigError.code}
        except notify.NotifyTemplateError as e:
            return 400, {"error": str(e), "code": notify.NotifyTemplateError.code}
        except RuntimeError as e:  # 配置已生效但审计留痕失败：不能假成功
            return 500, {"error": str(e), "code": "audit_failed", "config_saved": True}
    if path == "/api/v1/notify/test":
        return 200, notify.test_channel()
    if path == "/api/v1/notifications/read-all":
        if not _has(user, "msg.view"):
            return 403, {"error": "无权限（需 msg.view）", "code": "forbidden"}
        try:
            return 200, notify.mark_all_read((user or {}).get("sub", ""))
        except ValueError as e:
            return 403, {"error": str(e), "code": "forbidden"}
    if path.startswith("/api/v1/notifications/") and path.endswith("/read"):
        if not _has(user, "msg.view"):
            return 403, {"error": "无权限（需 msg.view）", "code": "forbidden"}
        nid = path.split("/")[-2]
        try:
            return 200, notify.mark_read(nid, (user or {}).get("sub", ""))
        except notify.NotificationNotFound as e:
            # 不存在 ≠ 越权：404 让客户端能区分「消息不在了」和「不是你的消息」
            return 404, {"error": str(e), "code": "not_found"}
        except notify.NotificationForbidden as e:
            return 403, {"error": str(e), "code": "forbidden"}
        except ValueError as e:
            return 403, {"error": str(e), "code": "forbidden"}
    return None
