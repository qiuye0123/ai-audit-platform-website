"""运营看板只读路由（/api/v1/ops/overview）。"""
from __future__ import annotations

from ..services import ops


def get(path: str, user: dict):
    if path != "/api/v1/ops/overview":
        return None
    ok, reason = ops.can_view_overview(user or {})
    if not ok:
        return 403, {"error": reason, "code": "forbidden"}
    try:
        return 200, ops.overview()
    except Exception as exc:  # noqa: BLE001
        # 不伪造统计：读取失败就明确失败，不返回全 0 冒充正常
        return 500, {"error": f"运维看板读取失败：{type(exc).__name__}",
                     "code": "ops_overview_failed"}
