"""智能体健康看板只读 API（L14 A1）：``GET /api/v1/agents/health``。

口径与 ``app/services/agents.agents_health`` 同源（从 agent_run 聚合 7 智能体成功率/
P50/P95 延迟/tokens/失败 Top5）。硬约束：
- **只读**：只 SELECT，不写库、不触发智能体运行、不写审计（看板本身不是动作）；
- 权限：admin / super_admin（业务管理员/系统管理员 = 平台视角）；reviewer 与
  platform_op 一律 403（platform_op 在 server 前置守卫已 403，这里双保险）；
- ``limit``：聚合的最近运行条数，1..20000，默认 5000；非法 → 400（不静默回退）；
- 空态：无运行记录仍返回 200 + 7 行（指标 null），不伪造健康结论。
"""
from __future__ import annotations

from ..services import agents

# 可查看角色：业务管理员（租户级只读）+ 系统管理员（平台级）。审核员/平台运营不可见。
_HEALTH_ROLES = ("admin", "super_admin")


def _parse_limit(query: dict) -> tuple[int, str]:
    """返回 (limit, 错误文案)。错误非空时调用方返回 400。"""
    raw = (query or {}).get("limit")
    if isinstance(raw, (list, tuple)):
        raw = raw[0] if raw else ""
    if raw is None:
        return agents.HEALTH_LIMIT_DEFAULT, ""
    text = str(raw)
    if not text.strip():
        # 显式传了 limit 但为空白（如 ?limit=%20）→ 400，不静默回退默认值
        return 0, f"limit 不能为空白（收到 {text!r}）"
    if not text.strip().isdigit():
        return 0, f"limit 必须是正整数（收到 {text.strip()!r}）"
    val = int(text.strip())
    if val < agents.HEALTH_LIMIT_MIN or val > agents.HEALTH_LIMIT_MAX:
        return 0, (f"limit 超出范围 [{agents.HEALTH_LIMIT_MIN}, "
                   f"{agents.HEALTH_LIMIT_MAX}]（收到 {val}）")
    return val, ""


def get(path: str, user: dict, query: dict | None = None):
    """GET 派发：只承接 /api/v1/agents/health，其余返回 None 交回 server。"""
    if path != "/api/v1/agents/health":
        return None
    role = str((user or {}).get("role") or "")
    if not (user or {}).get("sub"):
        return 401, {"error": "未登录", "code": "unauthorized"}
    if role not in _HEALTH_ROLES:
        return 403, {"error": "无权限查看智能体健康（仅管理员/平台权限）", "code": "forbidden"}
    limit, err = _parse_limit(query or {})
    if err:
        return 400, {"error": err, "code": "invalid_limit",
                     "min": agents.HEALTH_LIMIT_MIN, "max": agents.HEALTH_LIMIT_MAX}
    try:
        data = agents.agents_health(limit=limit)
    except Exception as exc:  # noqa: BLE001 - 读取失败必须显式失败，不返回全 0 冒充正常
        return 500, {"error": f"智能体健康读取失败：{type(exc).__name__}",
                     "code": "agents_health_failed"}
    data["ok"] = True
    return 200, data
