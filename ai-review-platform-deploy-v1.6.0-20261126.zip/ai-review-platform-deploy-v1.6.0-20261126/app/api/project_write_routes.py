"""项目写路由：上传、同步审核、异步审核。

项目创建仍留在 server.py 以保留幂等键处理；该模块只处理已存在项目的写操作。

审核重复提交策略（本模块负责）：
- 异步 /audit-async：同一项目同一时刻只允许 1 个 queued/running 任务；
  相同 idempotency_key 永远返回同一个 task_id（重放，不重复计算）；
  不同 key 或未带 key 的并发提交返回 409 audit_in_progress。
- 同步 /audit：进程内按项目抢占；并发/重复提交返回 409 audit_in_progress；
  相同 idempotency_key 在 TTL 内重放同一份响应；跨进程用 audit_case.status
  原子抢占兜底。同步审核没有 task_id，不能取消，长审核请走 /audit-async。
- 同步 /audit 的幂等键来自请求体 idempotency_key（server.py 目前只把
  Idempotency-Key 头注入到 /audit-async；头注入同步入口不在本文件改动范围）。
- 同步响应幂等缓存是进程内 TTL；多进程部署时 DB 抢占只保证并发互斥，不保证
  跨进程重放同一份响应（异步 idem_key 落在 task_job，可跨进程重放）。

取消后项目状态恢复：
- task.submit 的 on_cancel 回调在取消落库后立即把仍处于 auditing/reviewing
  的项目回滚到审核前状态；job 内的入口/出口 checkpoint 仍保留，防止重复回滚。
- 每次审核抢占都会递增项目 generation；迟到的旧任务回滚只在 generation 未变
  时生效，避免旧任务取消回滚把新审核的“审核中”状态踩掉。

逐文档安全点 checkpoint 边界：
- project.audit 内部不可改且没有阶段/文档回调参数；本模块在异步 job 内用线程
  作用域的文档枚举包装（project.documents / manifest_exec.run 阶段边界）注入
  task.checkpoint。project.audit / DAG 的每个“按文件”循环在取下一份文件前都会
  经过检查点，取消可在文档之间生效。
- 单文档内部、manifest_exec 单个对象的 D4/D5 计算仍不可中断：必须等该文件/
  该对象当前计算返回后，才会在下一个安全点退出。线程不能被强杀，这是硬边界。
"""
from __future__ import annotations
import base64
import contextlib
import hashlib
import io
import json
import logging
import os
import tempfile
import threading
import time
import zipfile

from .. import db
from .. import repositories as R
from ..services import project, task, workspaces, audit_orchestrator, manifest_exec

log = logging.getLogger(__name__)

MAX_FILE_BYTES = 100 * 1024 * 1024
ALLOWED_EXTS = (".xlsx", ".docx", ".pdf")

# 同步 /audit 的进程内幂等缓存与并发占位。跨进程并发由 audit_case.status 兜底。
_SUBMIT_LOCK = threading.RLock()
_SYNC_ACTIVE = {}   # case_id -> {token,idem,scope,started}
_SYNC_CACHE = {}    # (case_id, idem) -> {expires,scope,body}
_CASE_GEN = {}      # case_id -> 本地审核代次，防止旧任务回滚新审核
_SYNC_CACHE_MAX = 256

AUDIT_STALE_SECONDS = int(os.environ.get("RULEPROOF_AUDIT_STALE_SECONDS", "3600") or 3600)
SYNC_IDEM_TTL = int(os.environ.get("RULEPROOF_SYNC_AUDIT_IDEM_TTL", "3600") or 3600)
SYNC_IDEM_MAX_BYTES = int(os.environ.get("RULEPROOF_SYNC_AUDIT_IDEM_MAX_BYTES",
                                         str(1024 * 1024)) or 1024 * 1024)


def _sniff_document_kind(data: bytes) -> str:
    """按 magic bytes 嗅探真实文件格式（L144/I1：扩展名与实际格式不符 → 拒绝）。

    · PDF：文件头 ``%PDF-``；
    · docx/xlsx：OOXML = ZIP（``PK``），进一步按包内条目区分
      ``word/document.xml``（docx）与 ``xl/workbook.xml``（xlsx）；
    · 其它/损坏 zip 返回 zip 或空串（由调用方与扩展名比对后拒绝）。
    只读嗅探，不写盘、不走网络（上传拒绝发生在落盘/解析之前）。
    """
    if not data:
        return ""
    if data[:5] == b"%PDF-":
        return "pdf"
    if data[:2] == b"PK":
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                names = set(zf.namelist())
        except Exception:  # noqa: BLE001 - 损坏 zip：交给扩展名比对拒绝，不抛异常
            return "zip"
        if "xl/workbook.xml" in names:
            return "xlsx"
        if "word/document.xml" in names:
            return "docx"
        return "zip"
    return ""


def _valid_file(filename: str, data: bytes) -> tuple[bool, str]:
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".xls":
        return False, "不支持旧版 .xls，请另存为 .xlsx"
    if ext not in ALLOWED_EXTS:
        return False, f"不支持的文件类型 {ext or '(无扩展名)'}"
    if not data:
        return False, "文件为空，拒绝上传"
    if len(data) > MAX_FILE_BYTES:
        return False, f"单份文件超过 {MAX_FILE_BYTES // 1024 // 1024}MB 上限"
    # L144/I1（2026-11-25）：扩展名与实际格式必须一致（magic bytes 复核）。
    # 只改拒绝口径，不改变白名单/体积/空文件等既有语义。
    actual = _sniff_document_kind(data)
    expect = ext.lstrip(".")
    if actual != expect:
        return False, (f"文件内容与扩展名不符：扩展名 {ext}，实际格式 {actual or '未知'}；"
                       "请在原软件中另存为正确的 .docx/.xlsx/.pdf 后重试")
    return True, ""


def _audit_log(action: str, cid: str, after: str = "", actor: str = "system") -> None:
    try:
        R.audit_logs.log(actor=actor or "system", action=action, object=cid or "",
                         after=after or "")
    except Exception:
        log.debug("project write audit log skipped action=%s", action, exc_info=True)


def _ts_seconds(ts) -> float | None:
    s = str(ts or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            return time.mktime(time.strptime(s, fmt))
        except Exception:
            continue
    return None


def _claim_audit_state(cid: str) -> tuple[dict | None, str, bool]:
    """DB 级原子抢占“审核中”状态，跨进程也只有一个赢家（DU-03）。

    返回 (prev, reason, stale)。prev 非空表示抢占成功；stale=True 表示覆盖了
    一个没有活跃任务且 audit_run 已超时的旧“审核中”状态。

    DU-03（P1，2026-11-25）：修复前无论当前状态是什么都直接
    ``UPDATE audit_case SET status='auditing'``，绕过了 ``state_machines`` 的迁移
    方向白名单——实测 completed 项目可以再被重审成 auditing（矩阵外迁移）。
    现在迁移方向统一从 ``state_machines`` 单一事实源派生（CASE_ACTIONS/action_target）：

    - created/draft：action=audit → auditing；
    - audit_failed / stale 的 auditing、reviewing：action=retry → draft，再 audit → auditing
      （两步在同一 BEGIN IMMEDIATE 事务内，外部看不到中间态；合法迁移均经矩阵校验）；
    - completed：CASE_ACTIONS 里只有 reaudit→reviewing，没有 audit 动作 → 拒绝，
      返回 ``reaudit_required``（调用方 409，要求显式 reaudit 后再审）；
    - 其它未知/非法状态：``invalid_transition`` fail-closed。

    写法仍是同一事务内的 CAS（``WHERE status=旧值``），保持跨进程 only-one-winner；
    不做跨事务的“先读后写”，避免并发下两个进程同时抢到。
    """
    from ..services import state_machines as _sm
    try:
        with db.session() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT status,progress FROM audit_case WHERE id=?", (cid,)).fetchone()
            if not row:
                return None, "not_found", False
            prev = dict(row)
            raw_status = str(prev.get("status") or "")
            status = _sm.normalize("audit_case", raw_status)
            stale = False
            if status in ("auditing", "reviewing"):
                active_task = c.execute(
                    "SELECT id FROM task_job WHERE case_id=? AND status IN ('queued','running') "
                    "ORDER BY rowid DESC LIMIT 1", (cid,)).fetchone()
                run = c.execute(
                    "SELECT created_at FROM audit_run WHERE case_id=? ORDER BY rowid DESC LIMIT 1",
                    (cid,)).fetchone()
                run_age = None if not run else _ts_seconds(run["created_at"])
                recent_run = run_age is not None and (time.time() - run_age) < AUDIT_STALE_SECONDS
                if active_task:
                    return None, "task_active", False
                if recent_run:
                    return None, "recent_run", False
                stale = True
            if status == "completed":
                # DU-03：completed→auditing 不是合法单步迁移；但产品必须支持“已完成项目重审”。
                # 在同一事务内按状态机合法链路原子推进：
                #   completed --reaudit--> reviewing --retry--> draft --audit--> auditing
                # 外部看不到中间态，所有单步都经 CASE_ACTIONS 校验（不再裸 SQL 跨态）。
                _cur = status
                for _act in ("reaudit", "retry", "audit"):
                    _tgt = _sm.action_target("audit_case", _cur, _act)
                    if _tgt is None:
                        return None, "invalid_transition", False
                    cur = c.execute(
                        "UPDATE audit_case SET status=?, progress=0 WHERE id=? AND status=?",
                        (_tgt, cid, _cur))
                    if int(cur.rowcount or 0) <= 0:
                        return None, "case_changed", False
                    _cur = _tgt
                if _cur != "auditing":
                    return None, "invalid_transition", False
                return prev, "", False
            action = "retry" if status in ("auditing", "reviewing", "audit_failed") else "audit"
            target = _sm.action_target("audit_case", status, action)
            if target is None:
                return None, "invalid_transition", False
            if target == "auditing":
                cur = c.execute(
                    "UPDATE audit_case SET status='auditing', progress=0 "
                    "WHERE id=? AND status=?", (cid, raw_status))
                if int(cur.rowcount or 0) <= 0:
                    return None, "case_changed", False
            elif target == "draft" and _sm.action_target("audit_case", "draft", "audit") == "auditing":
                cur = c.execute(
                    "UPDATE audit_case SET status='draft', progress=0 "
                    "WHERE id=? AND status=?", (cid, raw_status))
                if int(cur.rowcount or 0) <= 0:
                    return None, "case_changed", False
                cur = c.execute(
                    "UPDATE audit_case SET status='auditing', progress=0 "
                    "WHERE id=? AND status='draft'", (cid,))
                if int(cur.rowcount or 0) <= 0:
                    return None, "case_changed", False
            else:
                return None, "invalid_transition", False
        return prev, "", stale
    except Exception:
        log.warning("抢占审核状态失败 case=%s", cid, exc_info=True)
        return None, "db_error", False


def _next_case_gen(cid: str) -> int:
    with _SUBMIT_LOCK:
        gen = int(_CASE_GEN.get(cid, 0)) + 1
        _CASE_GEN[cid] = gen
        return gen


def _restore_case_if_current(cid: str, gen: int, prev_status: str, prev_progress: int,
                             actor: str = "", tid: str = "") -> bool:
    """取消后回滚项目状态；generation 变化说明已有新审核，禁止旧任务回滚。"""
    if not gen:
        return False
    with _SUBMIT_LOCK:
        if _CASE_GEN.get(cid) != gen:
            return False
        try:
            with db.session() as c:
                row = c.execute("SELECT status FROM audit_case WHERE id=?", (cid,)).fetchone()
                cur_status = str(row["status"] or "") if row else ""
                if cur_status not in ("auditing", "reviewing"):
                    return False
                cur = c.execute(
                    "UPDATE audit_case SET status=?, progress=? "
                    "WHERE id=? AND status IN ('auditing','reviewing')",
                    (prev_status or "draft", int(prev_progress or 0), cid))
                changed = cur.rowcount > 0
        except Exception:
            log.warning("恢复取消项目状态失败 case=%s", cid, exc_info=True)
            return False
        if changed:
            _audit_log("project.audit_cancelled_restored", cid,
                       f"task={tid or ''}|{cur_status}->{prev_status or 'draft'}", actor=actor)
        return changed


def _mark_audit_failed(cid: str, gen: int, actor: str = "", tid: str = "") -> bool:
    if not gen:
        return False
    with _SUBMIT_LOCK:
        if _CASE_GEN.get(cid) != gen:
            return False
        try:
            with db.session() as c:
                cur = c.execute(
                    "UPDATE audit_case SET status='audit_failed', progress=0 "
                    "WHERE id=? AND status IN ('auditing','reviewing')", (cid,))
                changed = cur.rowcount > 0
        except Exception:
            log.warning("标记审核失败状态失败 case=%s", cid, exc_info=True)
            return False
        if changed:
            _audit_log("project.audit_failed", cid, f"task={tid or ''}", actor=actor)
        return changed


def _finalize_completed(cid: str, gen: int, tid: str = "") -> bool:
    """审核成功后的兜底完成态：只在项目仍处于审核中时落 completed。

    与取消互斥：任务在 DB 已取消时不落 completed，避免“用户取消了但项目还完成”。
    """
    with _SUBMIT_LOCK:
        if gen and _CASE_GEN.get(cid) != gen:
            return False
        try:
            with db.session() as c:
                c.execute("BEGIN IMMEDIATE")
                if tid:
                    r = c.execute("SELECT status,cancel_requested FROM task_job WHERE id=?",
                                  (tid,)).fetchone()
                    if r and (r["cancel_requested"] or r["status"] == "cancelled"):
                        raise task.TaskCancelled(tid)
                cur = c.execute(
                    "UPDATE audit_case SET status='completed', progress=100, last_audit_at=? "
                    "WHERE id=? AND status IN ('auditing','reviewing')", (db.now(), cid))
                return cur.rowcount > 0
        except task.TaskCancelled:
            raise
        except Exception:
            log.warning("审核完成态落库失败 case=%s", cid, exc_info=True)
            return False


def _sync_scope(ai: bool, dt: str, pt: str, semantic: bool) -> str:
    raw = json.dumps({"ai": bool(ai), "dt": str(dt or ""), "pt": str(pt or ""),
                      "semantic": bool(semantic)}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _sync_cache_lookup(cid: str, idem: str, scope: str) -> tuple[str, dict]:
    if not idem:
        return "miss", {}
    now = time.time()
    with _SUBMIT_LOCK:
        e = _SYNC_CACHE.get((cid, idem))
        if not e:
            return "miss", {}
        if e.get("expires", 0) <= now:
            _SYNC_CACHE.pop((cid, idem), None)
            return "miss", {}
        if e.get("scope") != scope:
            return "conflict", {}
        return "hit", dict(e.get("body") or {})


def _sync_cache_put(cid: str, idem: str, scope: str, out) -> None:
    if not idem or not isinstance(out, dict):
        return
    try:
        size = len(json.dumps(out, ensure_ascii=False, default=str).encode("utf-8"))
    except Exception:
        return
    if size > SYNC_IDEM_MAX_BYTES:
        return
    now = time.time()
    with _SUBMIT_LOCK:
        if len(_SYNC_CACHE) >= _SYNC_CACHE_MAX:
            expired = [k for k, v in _SYNC_CACHE.items() if v.get("expires", 0) <= now]
            for k in expired:
                _SYNC_CACHE.pop(k, None)
            if len(_SYNC_CACHE) >= _SYNC_CACHE_MAX:
                oldest = min(_SYNC_CACHE.items(), key=lambda kv: kv[1].get("expires", 0))[0]
                _SYNC_CACHE.pop(oldest, None)
        _SYNC_CACHE[(cid, idem)] = {"expires": now + max(0, SYNC_IDEM_TTL),
                                    "scope": scope, "body": dict(out)}


# ---------------------------------------------------------------------------
# 逐文档 checkpoint 包装：只改 route，不改 project.audit。
# 线程作用域安装，其他线程调用 project.documents / manifest_exec.run 时原样透传；
# 异步 job 退出后立即恢复原函数，避免全局长期 monkeypatch。
# ---------------------------------------------------------------------------
_ORIG_PROJECT_DOCUMENTS = project.documents
_ORIG_MANIFEST_RUN = manifest_exec.run
_AUDIT_PATCH_LOCK = threading.RLock()
_AUDIT_PATCHED = False
_DOC_HOOKS = {}  # thread_ident -> (case_id, task_id)


class _CheckpointDocuments(list):
    """project.audit 的 docs 列表包装：每取下一份文档前检查取消。"""

    def __init__(self, items, tid: str):
        super().__init__(items)
        self._tid = tid

    def __iter__(self):
        for item in list.__iter__(self):
            task.checkpoint(self._tid)
            yield item

    def __getitem__(self, index):
        task.checkpoint(self._tid)
        return list.__getitem__(self, index)


def _checkpointed_documents(case_id: str) -> list:
    rows = _ORIG_PROJECT_DOCUMENTS(case_id)
    hook = _DOC_HOOKS.get(threading.get_ident())
    if hook and hook[0] == case_id and hook[1]:
        return _CheckpointDocuments(rows, hook[1])
    return rows


def _checkpointed_manifest_run(mid: str, *args, **kwargs):
    # 只在 manifest 阶段开始前检查：project.audit 用 try/except 包住 manifest_exec.run，
    # 阶段返回后的 TaskCancelled 会被吞掉，反而可能导致清单结果被当成“跳过”。
    # 阶段内部的单对象 D4/D5 计算仍是不可中断边界，返回后由文档循环检查点退出。
    hook = _DOC_HOOKS.get(threading.get_ident())
    if hook and hook[1]:
        task.checkpoint(hook[1])
    return _ORIG_MANIFEST_RUN(mid, *args, **kwargs)


def _install_audit_patches_locked() -> None:
    global _AUDIT_PATCHED
    if _AUDIT_PATCHED:
        return
    project.documents = _checkpointed_documents
    manifest_exec.run = _checkpointed_manifest_run
    _AUDIT_PATCHED = True


def _uninstall_audit_patches_locked() -> None:
    global _AUDIT_PATCHED
    if not _AUDIT_PATCHED or _DOC_HOOKS:
        return
    project.documents = _ORIG_PROJECT_DOCUMENTS
    manifest_exec.run = _ORIG_MANIFEST_RUN
    _AUDIT_PATCHED = False


@contextlib.contextmanager
def _audit_checkpoint_scope(cid: str, tid: str):
    """在异步审核 job 内启用逐文档检查点（线程作用域）。"""
    if not tid:
        yield
        return
    ident = threading.get_ident()
    with _AUDIT_PATCH_LOCK:
        _DOC_HOOKS[ident] = (cid, tid)
        _install_audit_patches_locked()
    try:
        yield
    finally:
        with _AUDIT_PATCH_LOCK:
            if _DOC_HOOKS.get(ident) == (cid, tid):
                _DOC_HOOKS.pop(ident, None)
            _uninstall_audit_patches_locked()


def _find_duplicate_document(case_id: str, file_hash: str) -> dict | None:
    """同项目内同内容文件幂等：返回已存在的 document 行（含解析结果），供上传去重。"""
    if not case_id or not file_hash:
        return None
    try:
        with db.session() as c:
            row = c.execute(
                "SELECT d.* FROM document d JOIN case_document cd ON cd.document_id=d.id "
                "WHERE cd.case_id=? AND d.hash=? ORDER BY d.created_at LIMIT 1",
                (case_id, file_hash)).fetchone()
            return dict(row) if row else None
    except Exception:
        log.debug("duplicate document lookup skipped", exc_info=True)
        return None


def post(path: str, body: dict, user: dict, owned) -> tuple | None:
    if not path.startswith("/api/v1/projects/"):
        return None
    parts = path.strip("/").split("/")
    cid = parts[-2] if len(parts) >= 3 else ""
    if path.endswith("/documents"):
        if not owned(cid):
            return 403, {"error": "无权操作他人项目", "code": "forbidden"}
        body = body or {}
        actor = (user or {}).get("sub", "") or "system"
        # P1-B5-01：文件名消毒必须在任何落盘/去重之前。含 ../、绝对路径、反斜杠、
        # 控制字符、超长名、空名一律 400 invalid_filename（且写一条拒绝审计），
        # 绝不把「填错文件名」变成连接级故障（旧行为：FileNotFoundError → 断连）。
        filename, _fn_err = project.sanitize_filename(
            body.get("filename", ""), default="", strict=True)
        if _fn_err:
            _audit_log("document.upload_rejected", cid,
                       f"reason=invalid_filename|filename={str(body.get('filename'))[:120]}",
                       actor=actor)
            return 400, {"error": _fn_err, "code": "invalid_filename"}
        # 解码后的内容再校验一遍（超长名/非法字符均已在上一步挡住，这里只剩扩展名/体积）
        try:
            data = base64.b64decode(body.get("data", ""), validate=True)
        except Exception:
            _audit_log("document.upload_rejected", cid,
                       f"reason=invalid_base64|filename={filename[:120]}", actor=actor)
            return 400, {"error": "data 不是合法 base64", "code": "invalid_base64"}
        ok, why = _valid_file(filename, data)
        if not ok:
            _audit_log("document.upload_rejected", cid,
                       f"reason=invalid_file|filename={filename[:120]}|why={why[:120]}",
                       actor=actor)
            return 400, {"error": why, "code": "invalid_file"}
        # F13：同项目同内容文件不重复解析（同 hash 幂等复用已落库文档）。
        _file_hash = hashlib.sha256(data).hexdigest()[:16]
        _dup = _find_duplicate_document(cid, _file_hash)
        if _dup:
            # 幂等复用也是「文件入系统」事实，同样留痕（duplicate=true 便于区分）
            _audit_log("document.uploaded", cid,
                       json.dumps({"case_id": cid, "filename": filename,
                                   "sha256": _file_hash, "size": len(data),
                                   "duplicate": True, "reused": True,
                                   "document_id": _dup.get("id") or ""},
                                  ensure_ascii=False), actor=actor)
            return 200, {"document_id": _dup.get("id"),
                         "filename": _dup.get("filename") or filename,
                         "duplicate": True, "reused": True,
                         "parse_status": _dup.get("parse_status") or "",
                         "note": "同内容文件已存在，复用已有解析结果，不重复解析"}
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(filename)[1] or ".docx")
        try:
            tmp.write(data); tmp.close()
            try:
                _before = {str(d.get("id") or "") for d in project.documents(cid)}
                doc_id = project.add_document(cid, tmp.name, filename)
            except ValueError as e:
                _audit_log("document.upload_rejected", cid,
                           f"reason=invalid_document|filename={filename[:120]}|why={str(e)[:160]}",
                           actor=actor)
                return 400, {"error": str(e), "code": "invalid_document"}
            except Exception as e:  # noqa: BLE001 —— P1-B5-01：任何异常都必须映射成可读错误
                log.warning("document upload failed cid=%s filename=%s",
                            cid, filename, exc_info=True)
                _audit_log("document.upload_rejected", cid,
                           f"reason=upload_failed|filename={filename[:120]}|"
                           f"why={type(e).__name__}: {str(e)[:140]}", actor=actor)
                return 500, {"error": f"文件上传处理失败：{type(e).__name__}", "code": "upload_failed"}
            _duplicate = bool(doc_id and doc_id in _before)
            _doc_row = R.documents.get(doc_id) or {}
            # P1-B5-02：上传原件是证据链起点（报告/门禁/复核都依赖它），必须写审计：
            # 谁 / 何时 / 哪个项目 / 什么文件 / 多大 / 解析状态。
            _audit_log("document.uploaded", cid,
                       json.dumps({"case_id": cid, "filename": filename,
                                   "sha256": _file_hash, "size": len(data),
                                   "parse_status": _doc_row.get("parse_status") or "",
                                   "duplicate": _duplicate, "document_id": doc_id or ""},
                                  ensure_ascii=False), actor=actor)
            return 200, {"document_id": doc_id, "filename": filename,
                         "duplicate": _duplicate, "reused": _duplicate}
        finally:
            os.unlink(tmp.name)
    if path.endswith("/audit-async"):
        if not owned(cid):
            return 403, {"error": "无权操作他人项目", "code": "forbidden"}
        body = body or {}
        ai = body.get("ai_assist", True)
        ai = True if ai is None else bool(ai)
        dt = str(body.get("doc_type") or "")
        if ai:
            cur = workspaces.current((user or {}).get("sub", ""))
            if not workspaces.module_on(cur.get("id", ""), "mod_ai_assist"):
                return 403, {"error": "该工作空间未启用 AI 辅助规则", "code": "module_off"}
        pt = str(body.get("policy_text") or "")
        actor = (user or {}).get("sub", "")
        _idem = str(body.get("idempotency_key") or "").strip()
        _idem_key = f"audit:{cid}:{_idem}" if _idem else ""
        if _idem_key:
            existing = task.find_by_idem(_idem_key)
            if existing:
                return 200, {"task_id": existing.get("id"), "status": existing.get("status"),
                             "replayed": True, "idempotency_key": _idem,
                             "ai_assist": ai, "policy_text_used": bool(pt)}
        try:
            project.preflight(cid, dt)
        except ValueError as e:
            return 400, {"error": str(e), "code": "audit_preflight_failed"}

        # 取消后项目不能永远停在“审核中”：记录进入审核前的状态，仅在任务确实被
        # 取消且审核尚未完成时回滚。已完成（completed）的审核不回滚，避免丢结果。
        # generation 保证旧任务的迟到回滚不会踩掉新审核。
        _state = {"tid": "", "ready": threading.Event(), "gen": 0,
                  "prev_status": "draft", "prev_progress": 0}

        def _restore_case():
            _restore_case_if_current(cid, _state.get("gen") or 0,
                                     _state.get("prev_status") or "draft",
                                     int(_state.get("prev_progress") or 0),
                                     actor=actor, tid=_state.get("tid") or "")

        def _on_cancel(_tid):
            # 取消一落库就恢复项目状态，不必等 project.audit 返回；job 退出时
            # 还会走一次 checkpoint，_restore_case 幂等且 generation 已校验。
            _restore_case()

        # 边界：project.audit 仍是单体调用，阶段/文档级退出由 _audit_checkpoint_scope
        # 在文档枚举与 manifest_exec 阶段边界注入；单文档内部计算不可中断。
        def _audit_job():
            _state["ready"].wait(5.0)
            _tid = _state.get("tid") or ""
            try:
                if _tid:
                    task.checkpoint(_tid)
                scope = _audit_checkpoint_scope(cid, _tid) if _tid else contextlib.nullcontext()
                with scope:
                    _out = audit_orchestrator.run(audit_orchestrator.from_project(
                        cid, ai_assist=ai, doc_type=dt, policy_text=pt, actor=actor))
                # 审核返回与任务落库之间仍可能收到取消；这里再检查一次，让 job
                # 不把已取消任务的结果继续带回 task._finish。
                if _tid:
                    task.checkpoint(_tid)
                _finalize_completed(cid, _state.get("gen") or 0, _tid)
                return _out
            except task.TaskCancelled:
                _restore_case()
                raise
            except Exception:
                # 取消与审核异常同时发生时，取消优先：不能把用户主动取消标成审核失败。
                if _tid and task.is_cancelled(_tid):
                    _restore_case()
                    raise task.TaskCancelled(_tid)
                _mark_audit_failed(cid, _state.get("gen") or 0, actor=actor, tid=_tid)
                raise

        with _SUBMIT_LOCK:
            if _idem_key:
                existing = task.find_by_idem(_idem_key)
                if existing:
                    return 200, {"task_id": existing.get("id"), "status": existing.get("status"),
                                 "replayed": True, "idempotency_key": _idem,
                                 "ai_assist": ai, "policy_text_used": bool(pt)}
            sync_active = _SYNC_ACTIVE.get(cid)
            if sync_active:
                return 409, {"error": "项目已有同步审核进行中，请稍后重试",
                             "code": "audit_in_progress", "audit_mode": "sync",
                             "idempotency_key": sync_active.get("idem") or ""}
            active = task.active_for_case(cid)
            if active:
                return 409, {"error": "项目已有审核任务进行中，请使用相同 idempotency_key 重放或稍后重试",
                             "code": "audit_in_progress", "task_id": active.get("id"),
                             "status": active.get("status")}
            prev, reason, stale = _claim_audit_state(cid)
            if not prev:
                if reason == "not_found":
                    return 404, {"error": "项目不存在", "code": "not_found"}
                if reason == "db_error":
                    return 503, {"error": "审核状态抢占失败，请重试", "code": "audit_claim_failed"}
                # DU-03：状态机拒绝的矩阵外迁移必须给机读原因，不能伪装成“审核中”。
                if reason == "reaudit_required":
                    return 409, {"error": "项目已完成，重新审核必须走显式 reaudit（completed 不能直接回到审核中）",
                                 "code": "reaudit_required"}
                if reason == "invalid_transition":
                    return 409, {"error": "当前项目状态不允许发起审核", "code": "invalid_transition"}
                if reason == "case_changed":
                    return 409, {"error": "项目状态已被其他请求变更，请刷新后重试",
                                 "code": "state_conflict"}
                active = task.active_for_case(cid)
                return 409, {"error": "项目已有审核任务进行中，请稍后重试",
                             "code": "audit_in_progress",
                             "task_id": (active or {}).get("id", ""),
                             "reason": reason}
            _state["gen"] = _next_case_gen(cid)
            _prev_status = str(prev.get("status") or "draft")
            if stale and _prev_status in ("auditing", "reviewing"):
                # 旧的“审核中”已无活跃任务且 run 超时，回滚目标不能还是 auditing。
                _prev_status = "draft"
            _state["prev_status"] = _prev_status
            _state["prev_progress"] = int(prev.get("progress") or 0)
            if stale:
                _audit_log("project.audit_stale_takeover", cid,
                           f"status={prev.get('status')}", actor=actor)
            # task.submit 内部生成 tid 并立即启动 worker；job 先等待 tid 绑定后再
            # 进入审核，保证取消检查点从第一行起就可用。
            try:
                tid = task.submit("audit", _audit_job, owner=actor, case_id=cid,
                                  idem_key=_idem_key, on_cancel=_on_cancel)
            except Exception:
                _restore_case()
                raise
            _state["tid"] = tid
            _state["ready"].set()
        return 200, {"task_id": tid, "status": "running", "ai_assist": ai,
                     "policy_text_used": bool(pt), "idempotency_key": _idem,
                     "replayed": False}
    if path.endswith("/audit"):
        if not owned(cid):
            return 403, {"error": "无权操作他人项目", "code": "forbidden"}
        body = body or {}
        ai = body.get("ai_assist", True)
        ai = True if ai is None else bool(ai)
        dt = str(body.get("doc_type") or "")
        if ai:
            cur = workspaces.current((user or {}).get("sub", ""))
            if not workspaces.module_on(cur.get("id", ""), "mod_ai_assist"):
                return 403, {"error": "该工作空间未启用 AI 辅助规则", "code": "module_off"}
        pt = str(body.get("policy_text") or "")
        actor = (user or {}).get("sub", "")
        _idem = str(body.get("idempotency_key") or "").strip()
        try:
            from ..engine import llm_router as _lr
            _sem = bool((_lr.resolve() or {}).get("enabled"))
        except Exception:
            _sem = False
        # 幂等作用域只包含调用方显式参数；semantic 由模型配置推导，不能因为
        # 运行环境变化把同一请求误判为“不同参数”。
        _scope = _sync_scope(ai, dt, pt, False)

        # 1) 幂等键：TTL 内重放同一份响应；同 key 不同参数拒绝，避免串结果。
        hit, cached = _sync_cache_lookup(cid, _idem, _scope)
        if hit == "conflict":
            return 409, {"error": "Idempotency-Key 已用于不同参数的审核请求",
                         "code": "idempotency_conflict"}
        if hit == "hit":
            return 200, {**cached, "replayed": True, "idempotency_key": _idem}
        with _SUBMIT_LOCK:
            act = _SYNC_ACTIVE.get(cid)
            if act:
                return 409, {"error": "项目已有同步审核进行中，请稍后重试",
                             "code": "audit_in_progress", "audit_mode": "sync"}
            active = task.active_for_case(cid)
            if active:
                return 409, {"error": "项目已有审核任务进行中，请稍后重试",
                             "code": "audit_in_progress", "task_id": active.get("id"),
                             "status": active.get("status")}

        try:
            project.preflight(cid, dt)
        except ValueError as e:
            return 400, {"error": str(e), "code": "audit_preflight_failed"}

        token = db.new_id("sync")
        gen = 0
        # 2) 进程内占位 + DB 原子抢占：并发重复提交只能有一个进入审核。
        with _SUBMIT_LOCK:
            hit, cached = _sync_cache_lookup(cid, _idem, _scope)
            if hit == "conflict":
                return 409, {"error": "Idempotency-Key 已用于不同参数的审核请求",
                             "code": "idempotency_conflict"}
            if hit == "hit":
                return 200, {**cached, "replayed": True, "idempotency_key": _idem}
            act = _SYNC_ACTIVE.get(cid)
            if act:
                return 409, {"error": "项目已有同步审核进行中，请稍后重试",
                             "code": "audit_in_progress", "audit_mode": "sync"}
            active = task.active_for_case(cid)
            if active:
                return 409, {"error": "项目已有审核任务进行中，请稍后重试",
                             "code": "audit_in_progress", "task_id": active.get("id"),
                             "status": active.get("status")}
            prev, reason, stale = _claim_audit_state(cid)
            if not prev:
                if reason == "not_found":
                    return 404, {"error": "项目不存在", "code": "not_found"}
                if reason == "db_error":
                    return 503, {"error": "审核状态抢占失败，请重试", "code": "audit_claim_failed"}
                # DU-03：状态机拒绝的矩阵外迁移必须给机读原因，不能伪装成“审核中”。
                if reason == "reaudit_required":
                    return 409, {"error": "项目已完成，重新审核必须走显式 reaudit（completed 不能直接回到审核中）",
                                 "code": "reaudit_required"}
                if reason == "invalid_transition":
                    return 409, {"error": "当前项目状态不允许发起审核", "code": "invalid_transition"}
                if reason == "case_changed":
                    return 409, {"error": "项目状态已被其他请求变更，请刷新后重试",
                                 "code": "state_conflict"}
                active = task.active_for_case(cid)
                return 409, {"error": "项目已有审核任务进行中，请稍后重试",
                             "code": "audit_in_progress",
                             "task_id": (active or {}).get("id", ""),
                             "reason": reason}
            gen = _next_case_gen(cid)
            _SYNC_ACTIVE[cid] = {"token": token, "idem": _idem, "scope": _scope,
                                 "started": time.time()}
            if stale:
                _audit_log("project.audit_stale_takeover", cid,
                           f"status={prev.get('status')}|mode=sync", actor=actor)
        try:
            out = audit_orchestrator.run(audit_orchestrator.from_project(
                cid, ai_assist=ai, doc_type=dt, policy_text=pt, semantic=_sem,
                actor=actor))
            _finalize_completed(cid, gen)
            _sync_cache_put(cid, _idem, _scope, out)
            resp = dict(out) if isinstance(out, dict) else {"result": out}
            resp.update({"idempotency_key": _idem, "replayed": False})
            return 200, resp
        except Exception as _exc:
            _mark_audit_failed(cid, gen, actor=actor)
            # L52 ⑤：冻结清单执行被阻断/0 执行的审核必须返回明确错误（409），
            # 不能退化成“已完成 0 发现”；其余异常保持原有 500 语义。
            try:
                from app.services import single_entry as _se_h
                if isinstance(_exc, _se_h.ManifestExecutionBlocked):
                    return int(_exc.http_status), _exc.to_dict()
            except Exception:  # noqa: BLE001
                pass
            raise
        finally:
            with _SUBMIT_LOCK:
                a = _SYNC_ACTIVE.get(cid)
                if a and a.get("token") == token:
                    _SYNC_ACTIVE.pop(cid, None)
    return None
