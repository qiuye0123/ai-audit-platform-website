# -*- coding: utf-8 -*-
"""本体 HTTP 路由（T-203 第一批：从 server.py 物理移出 + T-200 门面改造落地）。

覆盖：``GET/POST /api/v1/ontology*``（图/版本/工作空间/校验/发布/实体·别名·关系资产/
快照/影响面/能力清单与空间开关/自动评估/影子标签）。

**T-200 转交清单落地（本文件即 server.py 转交清单的落点）**：本文件不 import
``ontology_v2`` / ``ontology_ops`` / ``ontology_assets`` / ``ontology_workspace`` /
``ontology_gate`` / ``ontology_impact``，全部经 ``app.services.ontology_service`` 单一门面；
名称消歧按门面契约：``status`` → ``workspace_status``、``ontology_v2.publish`` →
``publish_graph``、``ontology_ops.publish`` → ``publish_version``。

零行为变化约定同 ``review_routes.py``：谓词留在 server.py，处理体逐字搬移（self.→handler.），
dispatch 局部量按当时的值传入。
"""
from __future__ import annotations

import json
import logging

from .. import db
from .. import repositories as R
from ..engine import engine
from ..services import ontology_service, rule

NOT_HANDLED = object()


def _ontology_target_workspace(handler, raw_ws: str = "") -> dict:
    """T-197：本体开关/能力 API 的目标空间解析（跳过跨租户越权）。

    返回 {"workspace_id": ...} 或 {"error": (http_code, payload)}：
    - 未传 workspace_id → 当前空间；
    - 跨租户/不存在 → 404（不泄露存在性），服务端拒绝而不是只靠前端。
    """
    from ..services import workspaces as _wsm
    u = handler._session_user() or {}
    cur = _wsm.current(u.get("sub", "")) or {}
    ws_id = str(raw_ws or "").strip() or str(cur.get("id") or "")
    row = _wsm.get(ws_id) if ws_id else {}
    if not row:
        return {"workspace_id": ws_id,
                "error": (404, {"error": "工作空间不存在", "code": "not_found"})}
    try:
        from .. import repositories as _R
        urow = _R.users.get(u.get("sub", "")) or {}
        utenant = str(urow.get("tenant_id") or "")
        if utenant and str(row.get("tenant_id") or "") and utenant != str(row.get("tenant_id")):
            return {"workspace_id": ws_id,
                    "error": (404, {"error": "工作空间不存在", "code": "not_found"})}
    except Exception:
        logging.getLogger(__name__).debug("ontology target tenant check skipped", exc_info=True)
    return {"workspace_id": ws_id, "tenant_id": str(row.get("tenant_id") or "")}


def get_ontology_capabilities_switch(handler, p, q):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _q_raw = (q.get("workspace_id") or [""])[0] if isinstance(q, dict) else ""
    _target = _ontology_target_workspace(handler, _q_raw)
    if _target.get("error"):
        return handler._send(*_target["error"])
    from app.services import ontology_service as _ocg
    if p.endswith("/capabilities"):
        return handler._send(200, handler._json(_ocg.capabilities(_target["workspace_id"])))
    return handler._send(200, handler._json(_ocg.switch_report(_target["workspace_id"])))

def get_ontology_versions(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import ontology_service as _oo_g
    return handler._send(200, handler._json({"items": _oo_g.list_versions()}))

def get_ontology_version_detail(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _vg = p.split("/")[-1]
    from app.services import ontology_service as _oa_g
    _vrow = _oa_g.version_visible(_vg)
    if not _vrow:
        return handler._err(404, "本体版本不存在", "not_found")
    return handler._send(200, handler._json(_vrow))

def get_ontology_workspace(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import ontology_service as _ows
    return handler._send(200, handler._json(_ows.workspace_status()))

def get_ontology_validate(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import ontology_service as _ov0
    _v20 = _ov0.validate()
    _graph0 = engine.ONTO.validate()
    return handler._send(200, handler._json({"ok": bool(_v20.get("ok")) and bool(_graph0.get("ok")),
                                       "v2": _v20, "graph": _graph0}))

def get_ontology_graph(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # T-197（P1-2）：本体图设为「平台共享层 + 本租户扩展层」，
    # 读接口按 ctx 过滤；其他租户扩展层不可见（跨租户读取不返回、不发 404 列表）。
    from app.services import ontology_service as _oa_view
    d = _oa_view.admin_view()
    try:
        with db.session() as _c:
            _rows = {r["id"]: dict(r) for r in _c.execute(
                "SELECT id,created_at,tenant_id FROM onto_entity").fetchall()}
        for _i in d.get("instances") or []:
            _r = _rows.get(_i.get("id") or "")
            _i["created_at"] = (_r or {}).get("created_at") or ""
            if _i.get("scope") != "tenant":
                _i["source"] = "系统预置" if not (_r or {}).get("created_at") else "用户新增"
            else:
                _i["source"] = "用户新增"
        for _t in d.get("types") or []:
            _t["source"] = "系统内置"
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return handler._send(200, handler._json(d))

def get_ontology_impact(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import ontology_service as _ontology_impact
    u = handler._session_user() or {}
    if (u.get("role") or "") not in ("admin", "super_admin", "reviewer"):
        return handler._err(403, "无权限查看本体影响", "forbidden")
    return handler._send(200, handler._json(_ontology_impact.impact(handler._query().get("term", ""))))

def post_ontology_capabilities(handler, _p0, _scoped_rule):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _u_ont = handler._session_user() or {}
    if (_u_ont.get("role") or "") != "admin":
        return handler._err(403, "仅业务管理员可配置本体能力/开关", "forbidden")
    _b_ont = handler._body() or {}
    _actor_ont = _u_ont.get("sub", "")
    from app.services import ontology_service as _oc_post
    _target = _ontology_target_workspace(handler, str(_b_ont.get("workspace_id") or ""))
    if _target.get("error"):
        return handler._send(*_target["error"])
    _wid_ont = _target["workspace_id"]
    if _p0 == "/api/v1/ontology/switch":
        _out = _oc_post.set_control(
            _wid_ont, enabled=_b_ont.get("enabled"), mode=_b_ont.get("mode"),
            actor=_actor_ont, reason=str(_b_ont.get("reason") or ""),
            source="manual")
        if not _out.get("ok"):
            _code_ont = 404 if _out.get("code") == "not_found" else (
                403 if _out.get("code") in ("forbidden", "workspace_required", "invalid_mode")
                else 400)
            return handler._err(_code_ont, _out.get("reason") or "切换失败",
                             _out.get("code") or "invalid_switch")
        return handler._send(200, handler._json(_out))
    # POST /api/v1/ontology/capabilities
    _action_ont = str(_b_ont.get("action") or "").strip()
    _mode_ont = str(_b_ont.get("execution_mode") or "").strip()
    _cfg_ont = _b_ont.get("cross_doc")
    _rid_ont = str(_b_ont.get("rule_id") or "").strip()
    if _action_ont == "configure_rule":
        _rrow_ont, _rdeny_ont = _scoped_rule(_rid_ont, _u_ont)
        if _rdeny_ont:
            return handler._send(_rdeny_ont[0], handler._json(_rdeny_ont[1]))
        try:
            _out = rule.configure_capability(
                str(_rrow_ont.get("id") or ""), _mode_ont, _cfg_ont,
                actor=_actor_ont)
        except ValueError as _exc_ont:
            return handler._err(400, str(_exc_ont), "invalid_rule_capability")
        return handler._send(200, handler._json({
            "ok": True, **_out,
            "capability": {"execution_mode": _mode_ont or "single",
                           "cross_doc": (_out.get("capability") or {}).get("project_compute")},
            "switch": _oc_post.effective(_wid_ont),
            "note": ("规则已保存为草稿；发布后审核按当前空间开关消费。"
                     if _out.get("forked") or not _out.get("effective_version")
                     else "规则已保存；已发布旧版本继续生效，直到新版本发布")}))
    if _action_ont == "create_rule":
        _name_ont = str(_b_ont.get("name") or "").strip()
        if not _name_ont:
            return handler._err(400, "规则名称不能为空", "invalid_rule")
        _code_ont = str(_b_ont.get("code") or "").strip() or (
            "CUST-" + db.new_id("x")[:6].upper())
        _slots_ont = dict(_b_ont.get("slots") or {})
        _slots_ont["execution_mode"] = _mode_ont or "cross_doc_consistency"
        if _cfg_ont is not None:
            _slots_ont["cross_doc"] = _cfg_ont
        try:
            _out = rule.create_rule(
                code=_code_ont, name=_name_ont,
                category=str(_b_ont.get("category") or "consistency"),
                rclass=str(_b_ont.get("rclass") or "R4"),
                slots=_slots_ont, source="manual",
                scope=_b_ont.get("scope") or {},
                point_override=str(_b_ont.get("point_id") or ""))
        except ValueError as _exc_ont2:
            return handler._err(400, str(_exc_ont2), "invalid_rule_capability")
        try:
            R.audit_logs.log(actor=_actor_ont, action="rule.created",
                             object=_code_ont,
                             after=json.dumps(
                                 {"capability": "cross_doc_consistency",
                                  "rule_id": _out.get("rule_id")},
                                 ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).warning(
                "capability rule created audit failed", exc_info=True)
        return handler._send(200, handler._json({
            "ok": True, **_out,
            "capability": {"execution_mode": "cross_doc_consistency"},
            "switch": _oc_post.effective(_wid_ont),
            "note": "规则已创建为草稿；发布后审核按当前空间开关消费"}))
    return handler._err(400, "action 只支持 configure_rule / create_rule",
                     "invalid_capability_action")

def post_ontology_workspace_discover(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    u = handler._session_user() or {}
    if (u.get("role") or "") != "admin":
        return handler._err(403, "仅业务管理员可启动本体自动建模", "forbidden")
    from app.services import ontology_service as _ows
    r = _ows.discover()
    return handler._send(200 if r.get("ok") else 400, handler._json(r))

def post_ontology_workspace_term(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    u = handler._session_user() or {}
    if (u.get("role") or "") != "admin":
        return handler._err(403, "仅业务管理员可维护本体", "forbidden")
    b = handler._body() or {}
    from app.services import ontology_service as _ows
    r = _ows.set_term(str(b.get("id") or ""), str(b.get("status") or ""), u.get("sub", ""))
    return handler._send(200 if r.get("ok") else 400, handler._json(r))

def post_ontology_workspace_threshold(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    u = handler._session_user() or {}
    if (u.get("role") or "") != "admin":
        return handler._err(403, "仅业务管理员可修改阈值", "forbidden")
    b = handler._body() or {}
    from app.services import ontology_service as _ows
    r = _ows.save_threshold(b.get("threshold") or 10, u.get("sub", ""))
    return handler._send(200 if r.get("ok") else 400, handler._json(r))

def post_ontology_validate(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import ontology_service as _ov
    _v2 = _ov.validate()
    _graph = engine.ONTO.validate()
    return handler._send(200, handler._json({"ok": bool(_v2.get("ok")) and bool(_graph.get("ok")),
                                       "v2": _v2, "graph": _graph}))

def post_ontology_assets(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _u_oasset = handler._session_user() or {}
    if (_u_oasset.get("role") or "") != "admin":
        return handler._err(403, "仅业务管理员可维护本体资产", "forbidden")
    _b_as = handler._body() or {}
    _actor_as = _u_oasset.get("sub", "")
    from app.services import ontology_service as _oa_post

    def _asset_reply(_r, _ok_keys=()):
        if not _r.get("ok"):
            _code = str(_r.get("code") or "")
            _st = 404 if _code == "not_found" else (
                403 if _code == "shared_asset" else (
                    409 if _code in ("alias_conflict", "duplicate_entity",
                                     "duplicate_alias", "duplicate_link",
                                     "entity_in_use") else 400))
            return handler._send(_st, handler._json({"error": _r.get("reason") or "写入失败",
                                               "code": _code or "write_failed"}))
        _payload = {"ok": True, **_r}
        return handler._send(200, handler._json(_payload))

    if p == "/api/v1/ontology/entity":
        return _asset_reply(_oa_post.create_entity(
            str(_b_as.get("type_key") or "HalfProduct"),
            str(_b_as.get("name") or ""), _b_as.get("props") or {},
            actor=_actor_as))
    if p == "/api/v1/ontology/entity/update":
        return _asset_reply(_oa_post.update_entity(
            str(_b_as.get("id") or ""), name=_b_as.get("name"),
            type_key=_b_as.get("type_key"), props=_b_as.get("props"),
            actor=_actor_as))
    if p == "/api/v1/ontology/entity/delete":
        return _asset_reply(_oa_post.delete_entity(
            str(_b_as.get("id") or ""), actor=_actor_as))
    if p == "/api/v1/ontology/alias":
        return _asset_reply(_oa_post.create_alias(
            str(_b_as.get("type_key") or ""), str(_b_as.get("alias") or ""),
            str(_b_as.get("entity_id") or ""), str(_b_as.get("evidence") or ""),
            actor=_actor_as))
    if p == "/api/v1/ontology/alias/update":
        return _asset_reply(_oa_post.update_alias(
            str(_b_as.get("id") or ""), alias=_b_as.get("alias"),
            evidence=_b_as.get("evidence"), status=_b_as.get("status"),
            actor=_actor_as))
    if p == "/api/v1/ontology/alias/delete":
        return _asset_reply(_oa_post.delete_alias(
            str(_b_as.get("id") or ""), actor=_actor_as))
    if p == "/api/v1/ontology/link":
        return _asset_reply(_oa_post.create_link(
            str(_b_as.get("key") or "produced_by"),
            str(_b_as.get("source_id") or ""), str(_b_as.get("target_id") or ""),
            actor=_actor_as))
    if p == "/api/v1/ontology/link/delete":
        return _asset_reply(_oa_post.delete_link(
            str(_b_as.get("id") or ""), actor=_actor_as))
    return NOT_HANDLED   # 原分支可能不响应而落到后续 dispatch（语义保持）

def post_ontology_snapshot(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    return handler._send(200, handler._json(ontology_service.snapshot()))

def post_ontology_version_publish(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    vid = p.split("/")[-2]
    _pr = ontology_service.publish_version(vid)
    if _pr.get("error"):
        _pst = int(_pr.get("http_status") or 400)
        return handler._send(_pst, handler._json({"error": _pr.get("error"),
                                            "code": _pr.get("code") or "publish_failed",
                                            **_pr}))
    return handler._send(200, handler._json(_pr))

def post_ontology_versions(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    return handler._send(200, handler._json(ontology_service.list_versions()))

def post_ontology_impact(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import ontology_service as _ontology_impact
    u = handler._session_user() or {}
    if (u.get("role") or "") not in ("admin", "super_admin", "reviewer"):
        return handler._err(403, "无权限查看本体影响", "forbidden")
    return handler._send(200, handler._json(_ontology_impact.impact(handler._query().get("term", ""))))
