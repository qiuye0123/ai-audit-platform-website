# -*- coding: utf-8 -*-
"""审计导出 HTTP 适配（T-201）：GET status + POST export（二次确认）。

注册方式：``app/api/server.py`` 只加 2 处 dispatch（GET 状态 / POST 导出），
权限/开关/水印/审计全部在服务层 ``app/services/audit_export.py``（CLI 同源）。

角色路径口径（与既有守卫一致，不新开角色通道）：
- super_admin  ：``/api/v1/audit-logs/export/status``、``/api/v1/audit-logs/export``
- platform_op  ：``/api/v1/platform/audit-export/status``、``/api/v1/platform/audit-export``
  （platform_op 的守卫只放行 /api/v1/platform/* 前缀；super_admin 的业务边界守卫
   只放行 /api/v1/audit-logs* —— 因此两个入口指向同一个服务函数，各自可达。）
"""
from __future__ import annotations

import logging

from app import repositories as R
from app.services import audit_export

log = logging.getLogger(__name__)


def _actor(handler) -> dict:
    try:
        user = handler._session_user() or {}
    except Exception:  # noqa: BLE001 - 会话解析失败按未登录处理（服务层再 403）
        log.warning("审计导出：会话解析失败", exc_info=True)
        user = {}
    uid = str(user.get("sub") or user.get("id") or "")
    role = str(user.get("role") or "")
    row = {}
    try:
        row = R.users.get(uid) or {} if uid else {}
    except Exception:  # noqa: BLE001 - 账号行缺失不影响角色判定（角色来自已验签会话）
        log.warning("审计导出：账号行读取失败 uid=%s", uid, exc_info=True)
    return {
        "uid": uid, "role": role,
        "tenant_id": str(row.get("tenant_id") or user.get("tenant_id") or ""),
        "workspace_id": str(row.get("current_workspace_id")
                           or row.get("workspace_id")
                           or user.get("workspace_id") or ""),
    }


def _send_json(handler, out: dict) -> bool:
    status = int(out.get("status") or (200 if out.get("ok") else 400))
    body = dict(out)
    body.pop("content", None)
    if not body.get("ok") and not body.get("error"):
        body["error"] = "审计导出请求失败"
    handler._send(status, handler._json(body))
    return True


def handle_get(handler) -> bool:
    """GET .../status：导出能力/配置状态（只读，不导出数据）。"""
    actor = _actor(handler)
    out = audit_export.status(actor["role"], actor["tenant_id"], actor["workspace_id"])
    return _send_json(handler, out)


def handle_post(handler) -> bool:
    """POST 导出：必须 confirm=true；成功返回带水印列的 CSV/JSONL 附件。"""
    actor = _actor(handler)
    try:
        body = handler._body() or {}
    except Exception:  # noqa: BLE001 - 非法 JSON 由 do_POST 统一校验，这里兜底
        log.warning("审计导出：请求体解析失败", exc_info=True)
        body = {}
    fmt = str(body.get("format") or "csv")
    confirm = body.get("confirm") in (True, 1, "1", "true", "yes")
    # 数据边界：super_admin 只能导出本租户；platform_op 是平台身份，默认全平台，
    # 显式传 tenant_id 时按该租户过滤（越权风险由角色本身承担，见交付报告边界说明）。
    tenant_id = actor["tenant_id"]
    if actor["role"] == "platform_op":
        tenant_id = str(body.get("tenant_id") or actor["tenant_id"] or "")
    out = audit_export.export(
        actor=actor["uid"], role=actor["role"], fmt=fmt, confirm=confirm,
        q=str(body.get("q") or ""), result=str(body.get("result") or ""),
        action=str(body.get("action") or ""), actor_filter=str(body.get("actor") or ""),
        date_from=str(body.get("date_from") or body.get("from") or ""),
        date_to=str(body.get("date_to") or body.get("to") or ""),
        tenant_id=tenant_id, workspace_id=actor["workspace_id"],
        ip=(handler.client_address[0] if handler.client_address else ""),
        request_id=getattr(handler, "_rid", "") or "")
    if not out.get("ok"):
        return _send_json(handler, out)
    content = out.pop("content")
    ctype = ("text/csv; charset=utf-8" if out.get("format") == "csv"
             else "application/x-ndjson; charset=utf-8")
    headers = {
        "Content-Disposition": 'attachment; filename="%s"' % out.get("filename"),
        "X-Audit-Export-Sha256": out.get("sha256", ""),
        "X-Audit-Export-Rows": str(out.get("rows", 0)),
        "X-Audit-Export-Batch": out.get("batch_id", ""),
        "Cache-Control": "no-store",
    }
    handler._send(200, content, ctype, headers)
    return True
