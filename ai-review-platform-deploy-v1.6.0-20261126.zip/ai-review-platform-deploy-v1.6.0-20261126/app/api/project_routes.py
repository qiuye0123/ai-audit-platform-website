"""项目读取路由：列表、文件预览、解析预览、文档、LLM trace、详情。

从 server.py 抽出；所有权由 handler 传入，路由模块不直接依赖 Handler。
"""
from __future__ import annotations
import json
import mimetypes
import os

from .. import db
from .. import repositories as R
from ..services import project, review, ctx


def _resolve_case(cid: str, user: dict):
    """统一 case 解析：不存在 → 404（不因 owned=False 变 403）。"""
    try:
        from ..services import ids as _ids
        _ids.resolve("case", cid, user or {})
    except _ids.IDLookupError as e:
        return e.status, {"error": e.message, "code": e.code}, "application/json"
    return None


def _resolve_pdf_doc(cid: str, did: str, user: dict):
    """校验 case 归属与文档存在性，返回 (doc, error) 之一。"""
    err = _resolve_case(cid, user)
    if err:
        return None, err
    doc = next((x for x in R.cases.documents(cid) if x.get("id") == did), None)
    if not doc:
        return None, (404, {"error": "文件不存在", "code": "not_found"}, "application/json")
    return doc, None


_PREVIEW_MAX_TEXT = 200_000
_PREVIEW_MAX_TEXT_BYTES = 200_000
_PREVIEW_MAX_HTML_BYTES = 1_000_000


def _truncate_str_bytes(val: str, max_bytes: int) -> tuple:
    if len(val.encode("utf-8")) <= max_bytes:
        return val, None
    lo, hi = 0, len(val)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if len(val[:mid].encode("utf-8")) <= max_bytes:
            lo = mid
        else:
            hi = mid - 1
    return val[:lo], {"original_len": len(val), "original_bytes": len(val.encode("utf-8")),
                      "returned_len": lo, "limit_bytes": max_bytes}


def _truncate_preview(payload: dict) -> dict:
    """P2-B8-03：大文本预览不分页/不截断 → 单响应 9.25MB。

    超过阈值（text 200KB / html 1MB）只返回前 N 字节并带 truncated 标记与原始大小，
    前端据此提示「已截断」；完整内容走原始文件/审核工作台，不把解析全文塞进一次 JSON。
    """
    if not isinstance(payload, dict):
        return payload
    out = dict(payload)
    truncated = {}
    for key, cap in (("text", _PREVIEW_MAX_TEXT_BYTES), ("html", _PREVIEW_MAX_HTML_BYTES)):
        val = out.get(key)
        if isinstance(val, str) and val:
            cut, meta = _truncate_str_bytes(val, cap)
            if meta is not None:
                out[key] = cut
                truncated[key] = meta
    if truncated:
        out["truncated"] = True
        out["truncation"] = truncated
        out["truncated_notice"] = (
            "预览内容过大，已截断展示（" + "、".join(
                f"{k} 原始 {v['original_bytes']} 字节 → 返回 {v['returned_len']} 字符"
                for k, v in truncated.items()) + "）；完整内容请查看原始文件或审核工作台")
    else:
        out.setdefault("truncated", False)
    return out


def get(path: str, query: dict, user: dict, owned):
    if path == "/api/v1/projects":
        # 项目列表不按空间切分；空间只作为筛选条件
        if (user or {}).get("role") in ("admin", "reviewer"):
            cur = ctx.get_context()
            ctx.set_context(cur.get("tenant_id") or "t-default", "")
        return 200, project.list_projects(
            (user or {}).get("sub", ""), (user or {}).get("role") in ("admin", "super_admin"),
            keyword=(query or {}).get("q", ""), status_f=(query or {}).get("status", ""),
            date_from=(query or {}).get("from", ""), date_to=(query or {}).get("to", ""),
            reviewer=(query or {}).get("reviewer", ""), space_id=(query or {}).get("space", ""),
            page=int((query or {}).get("page") or 1),
            page_size=int((query or {}).get("page_size") or 20),
            stale_only=(query or {}).get("stale_only", "")), "application/json"
    if not path.startswith("/api/v1/projects/"):
        return None
    # 这些是 server.py 的专项路由，不能被通用 case_report 兜底抢先 404
    if path.endswith(("/manifest", "/manifest/execute", "/ledger")):
        return None
    parts = path.strip("/").split("/")
    cid = parts[-1]
    if path.endswith(("/preview", "/documents", "/unknown-classes",
                      "/unknown-candidates")):
        cid = parts[-2]
    if "/llm-traces/" in path:
        cid = parts[-3]
    if path.endswith("/file"):
        cid, did = parts[-4], parts[-2]
        if not owned(cid):
            return 403, {"error": "无权访问他人项目", "code": "forbidden"}, "application/json"
        doc = next((x for x in R.cases.documents(cid) if x.get("id") == did), None)
        if not doc:
            return 404, {"error": "文件不存在", "code": "not_found"}, "application/json"
        p = doc.get("path") or ""
        if not p or not os.path.exists(p):
            return 404, {"error": "文件不存在", "code": "not_found"}, "application/json"
        mime = mimetypes.guess_type(p)[0] or ("application/pdf" if p.lower().endswith(".pdf") else "application/octet-stream")
        with open(p, "rb") as fh:
            return 200, fh.read(), mime
    # T-94：PDF 原始文件预览（真实页数 + 逐页 PNG），不依赖浏览器原生 PDF 插件。
    #   GET /api/v1/projects/{cid}/documents/{did}/pdf-meta
    #   GET /api/v1/projects/{cid}/documents/{did}/pdf-page?page=N&size=1600
    if path.endswith(("/pdf-meta", "/pdf-page")) and "/documents/" in path:
        cid, did = parts[-4], parts[-2]
        if not owned(cid):
            return 403, {"error": "无权访问他人项目", "code": "forbidden"}, "application/json"
        doc, err = _resolve_pdf_doc(cid, did, user)
        if err:
            return err
        p = doc.get("path") or ""
        if not p or not os.path.exists(p):
            return 404, {"error": "文件不存在", "code": "not_found"}, "application/json"
        if not (p.lower().endswith(".pdf")
                or str(doc.get("filename") or "").lower().endswith(".pdf")):
            return 415, {"error": "该文件不是 PDF，无法使用 PDF 页图预览",
                         "code": "not_pdf"}, "application/json"
        from ..services import pdf_preview as _pp
        if path.endswith("/pdf-meta"):
            m = _pp.meta(p)
            payload = {"doc_id": did, "filename": doc.get("filename") or "", **m}
            return 200, payload, "application/json"
        try:
            page_no = int((query or {}).get("page") or 1)
        except (TypeError, ValueError):
            return 400, {"error": "页码必须是整数", "code": "bad_page"}, "application/json"
        try:
            size = int((query or {}).get("size") or 1600)
        except (TypeError, ValueError):
            size = 1600
        cnt = _pp.page_count(p)
        if not cnt.get("ok"):
            return 422, {"error": "无法读取 PDF 页数：" + "；".join(cnt.get("errors") or []),
                         "code": "pdf_page_count_failed",
                         "details": cnt.get("errors") or []}, "application/json"
        total = int(cnt.get("count") or 0)
        if page_no < 1 or page_no > total:
            return 400, {"error": f"页码超出范围（1-{total}）", "code": "bad_page",
                         "page_count": total}, "application/json"
        try:
            got = _pp.render_page(p, page_no, size)
        except _pp.PdfPreviewError as e:
            return 422, {"error": str(e), "code": "pdf_render_unavailable",
                         "details": list(e.details or [])}, "application/json"
        return 200, got["png"], "image/png"
    # 统一 ID 解析：不存在必须是 404，不能因为 owned=False 一律变 403。
    # P1（2026-11-22 节点穷举测试）：项目列表跨空间汇总；打开非当前空间的自有项目时，
    # resolver 会先按 session 空间 403。这里先由 owned（= Handler._case_owned）按项目
    # 所属空间切上下文再重判一次；owned 只对同租户本人/业务管理员放行，跨租户仍在
    # resolver 首判 404，不放宽任何跨租户/跨人可见性。
    try:
        from ..services import ids as _ids
        _ids.resolve("case", cid, user or {})
    except _ids.IDLookupError as e:
        if e.status == 403 and owned(cid):
            try:
                _ids.resolve("case", cid, user or {})
            except _ids.IDLookupError as e2:
                return e2.status, {"error": e2.message, "code": e2.code}, "application/json"
        else:
            return e.status, {"error": e.message, "code": e.code}, "application/json"
    if not owned(cid):
        return 403, {"error": "无权访问他人项目", "code": "forbidden"}, "application/json"
    if path.endswith("/preview"):
        _payload = review.document_preview(cid, (query or {}).get("doc_id", ""))
        return 200, _truncate_preview(_payload), "application/json"
    if path.endswith("/documents"):
        return 200, project.documents(cid), "application/json"
    if path.endswith("/unknown-classes"):
        from ..services import pstates as _ps
        cls = _ps.unknown_classes(cid)
        # 最新 manifest 的 result 映射：unknown 点位 → manifest_result
        rmap = {}
        try:
            with db.session() as _c:
                _m = _c.execute("SELECT id FROM audit_manifest WHERE case_id=? ORDER BY created_at DESC LIMIT 1",
                                (cid,)).fetchone()
                if _m:
                    for _r in _c.execute("SELECT id,rule_code FROM manifest_result WHERE manifest_id=?", (_m["id"],)):
                        rmap[str(_r["rule_code"] or "")] = _r["id"]
        except Exception:
            rmap = {}
        rows = []
        for k, ids in cls.items():
            if k in ("customer_rule", "not_applicable"):
                continue
            for pid in ids or []:
                rows.append({"point_id": pid, "class": k,
                             "result_id": rmap.get(str(pid), "")})
        return 200, {"case_id": cid, "classes": cls, "rows": rows,
                     "counts": {k: len(v or []) for k, v in cls.items()}}, "application/json"
    if path.endswith("/unknown-candidates"):
        # T-35：对象级例外授权候选（先 collect_unknown 取 result_id/result_hash/run_id
        # 绑定）；UI“逐项接受”按钮的数据源，同时返回报告门禁状态供接受后刷新。
        from . import exception_routes as _exc
        return 200, _exc.candidates_payload(cid), "application/json"
    if "/llm-traces/" in path:
        tid = parts[-1]
        with db.session() as c:
            row = c.execute("SELECT * FROM llm_trace WHERE id=? AND case_id=?", (tid, cid)).fetchone()
        if not row:
            return 404, {"error": "trace 不存在", "code": "not_found"}, "application/json"
        d = dict(row)
        for k in ("point_ids", "evidence_ids", "messages_json"):
            try:
                d[k] = json.loads(d.get(k) or "[]")
            except Exception:
                d[k] = []
        return 200, d, "application/json"
    return 200, review.case_report(cid), "application/json"
