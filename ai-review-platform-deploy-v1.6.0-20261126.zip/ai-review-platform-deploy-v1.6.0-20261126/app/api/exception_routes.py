# -*- coding: utf-8 -*-
"""对象级例外授权 HTTP/CLI 共用路由（T-35 接线）。

背景（T-28 / V08 契约，服务层已实现）：
    ``report_gate.accept_unknown_object(case_id, result_id, result_hash, run_id,
    reason, actor, role)`` 只允许**按对象**授权，绑定 result_id + result_hash +
    run_id；关键项（critical 规则）需要两名不同 actor 各自授权一次；execution_failed
    / 完整性错误不可豁免；run/hash 变化与过期自动失效。
    但 HTTP ``POST /projects/{cid}/accept-unknown`` 与 CLI ``report --accept-unknown``
    仍是旧 ``point_ids`` 批量审计（一次覆盖全部 unknown，且 V08 之后不再放行），
    出现“UI/入口点击成功但报告仍被门禁阻断”。

本模块把 HTTP/CLI 接线收敛到同一实现：

1. ``GET  /api/v1/projects/{cid}/unknown-candidates``
   先 ``report_gate.collect_unknown()`` 取每个 unknown 的对象级 binding，返回可授权
   候选（result_id/result_hash/run_id/kind/key_item/required_actors/waivable/
   actors/accepted）以及当前报告门禁状态。UI 用这份数据渲染“逐项接受”，无候选
   时禁用按钮。
2. ``POST /api/v1/projects/{cid}/accept-unknown``
   **一次只接受一个对象**（禁止批量）：
   - 请求含 point_ids/result_ids/... 批量字段或 result_id 为 list/逗号串
     → ``400 batch_forbidden``，不进入服务层、不写审计；
   - 必须先 ``collect_unknown`` 取 binding：对象不在当前 unknown 集合 → 404；
   - 客户端携带的 hash/run 与服务器 binding 不一致 → ``409 stale_hash`` /
     ``409 stale_run``（结果/批次已变更，旧授权失效）；
   - execution_failed/完整性错误 → ``409 non_waivable``；
   - 其余成功/关键项待第二人 → 200，返回 accepted/pending/rejected/skipped。
   actor 一律取真实会话用户 ``sub``/``id``，role 取会话角色；关键项双人由服务层
   判定（同一 actor 重复授权不生效）。
3. CLI 复用同一函数：``rp exception list/accept``（审核员 + 业务管理员第二授权人），
   以及 ``rp report --accept-unknown --result-id ...``（仅审核员，兼容旧标志）。

HTTP 状态码与服务层 code 的映射在 ``_CODE_STATUS`` 中，CLI 用同一 code 作为退出码
（400/403/404/409），保证入口一致、可脚本化。
"""
from __future__ import annotations

from ..services import report_gate

# 可执行例外授权的角色（与 report_gate._ACCEPT_ACTORS 的入口子集一致）：
# - reviewer：审核员（项目负责人），页面入口；
# - admin：业务管理员，页面只读不展示入口，但按服务层口径可担任关键项第二名
#   不同授权人（关键项双人必须由两个不同 actor 完成）。
ACCEPT_ROLES = ("reviewer", "admin")

# 批量形状固定反例：出现任一字段即 400，不进入服务层（禁止一次批量豁免）。
BATCH_KEYS = ("point_ids", "result_ids", "object_ids", "objects", "batch_ids",
              "keys", "result_id_list", "result_ids_list", "accept_all", "all")

# 服务层拒绝码 → HTTP 状态码（CLI 同码作退出码）。
_CODE_STATUS = {
    "batch_forbidden": 400,
    "result_id_required": 400,
    "reason_required": 400,
    "actor_required": 400,
    "run_required": 400,
    "forbidden": 403,
    "not_found": 404,
    "stale_run": 409,
    "stale_hash": 409,
    "non_waivable": 409,
    "audit_failed": 500,
    "internal_error": 500,
}


# ---------------------------------------------------------------------------
# 统一返回结构（单对象请求也保持数组形状，UI/CLI/测试共用）
# ---------------------------------------------------------------------------
def _payload(case_id: str, ok: bool = True) -> dict:
    return {"ok": bool(ok), "case_id": case_id,
            "accepted": [], "pending": [], "rejected": [], "skipped": [],
            "run_id": "", "actor": "", "role": "",
            "report_gate": {}, "unknown": {}}


def _gate_status(case_id: str) -> dict:
    """报告门禁真实状态（report.check_gate：与报告生成/导出同一门禁）。"""
    try:
        from ..services import report as _report
        g = _report.check_gate(case_id) or {}
        return {"ok": bool(g.get("ok")), "reasons": list(g.get("reasons") or []),
                "stats": g.get("stats") or {}}
    except Exception:  # noqa: BLE001
        return {"ok": False, "reasons": ["报告门禁状态读取失败"], "stats": {}}


def _unknown_summary(info: dict) -> dict:
    return {
        "run_id": str(info.get("run_id") or ""),
        "platform": len(info.get("platform") or []),
        "manifest": len(info.get("manifest") or []),
        "accepted_count": int(info.get("accepted_count") or 0),
        "platform_unaccepted": len(info.get("platform_unaccepted") or []),
        "manifest_unaccepted": len(info.get("manifest_unaccepted") or []),
    }


def _accepted_meta(info: dict) -> dict:
    """collect_unknown().accept.details → {result_id: 授权状态}（同源门禁数据）。"""
    out = {}
    for d in ((info.get("accept") or {}).get("details") or []):
        rid = str((d or {}).get("result_id") or "")
        if not rid:
            continue
        out[rid] = d
    return out


def _candidate_item(it: dict, binding: dict, detail: dict, run_id: str) -> dict:
    rid = str(binding.get("result_id") or "")
    waivable = bool(binding.get("waivable"))
    key_item = bool(binding.get("key_item"))
    required = int(binding.get("required_actors") or 1)
    actors = sorted({str(x) for x in ((detail or {}).get("actors") or []) if str(x)})
    effective = bool((detail or {}).get("accepted"))
    label = (str(binding.get("rule_code") or "") or str(binding.get("point_id") or "")
             or str(it.get("point_id") or "") or rid)
    accept_disabled = ""
    if not rid:
        accept_disabled = (str(binding.get("non_waivable_reason") or "")
                           or "结果缺失（完整性错误）不可通过例外豁免")
    elif not waivable:
        accept_disabled = str(binding.get("non_waivable_reason") or "不可豁免类别")
    elif effective:
        accept_disabled = "对象级例外授权已生效"
    return {
        "result_id": rid,
        "result_hash": str(binding.get("result_hash") or ""),
        "run_id": str(binding.get("run_id") or run_id or ""),
        "kind": str(binding.get("kind") or ""),
        "source": str(it.get("source") or ""),
        "label": label,
        "rule_code": str(binding.get("rule_code") or ""),
        "point_id": str(binding.get("point_id") or it.get("point_id") or ""),
        "object_id": str(binding.get("object_id") or it.get("object_id") or ""),
        "sub_id": str(binding.get("sub_id") or ""),
        "state": str(binding.get("state") or it.get("state") or ""),
        "reason": str(it.get("reason") or "")[:300],
        "key_item": key_item,
        "required_actors": required,
        "waivable": waivable,
        "non_waivable_reason": str(binding.get("non_waivable_reason") or ""),
        "accepted": effective,
        "actors": actors,
        "remaining_actors": max(0, required - len(actors)),
        "detail_reason": str((detail or {}).get("reason") or ""),
        # UI 直接据此禁用：“逐项接受”按钮 disabled=bool(accept_disabled)
        "accept_disabled_reason": accept_disabled,
    }


# ---------------------------------------------------------------------------
# GET：对象级候选（先 collect_unknown 取 binding）
# ---------------------------------------------------------------------------
def candidates_payload(case_id: str) -> dict:
    """当前 run 的可授权 unknown 对象列表 + 报告门禁状态（UI“逐项接受”数据源）。"""
    info = report_gate.collect_unknown(case_id)
    run_id = str(info.get("run_id") or "")
    details = _accepted_meta(info)
    rows = []
    for it in list(info.get("platform") or []) + list(info.get("manifest") or []):
        it = it or {}
        binding = it.get("binding") or {}
        if not binding:
            continue
        rows.append(_candidate_item(it, binding, details.get(str(binding.get("result_id") or "")),
                                    run_id))
    # 同一 result_id 可能同时出现在 platform/manifest 集合（异常数据）：只保留一条，
    # 绑定字段必须完全一致才去重，避免 UI 出现两个可点按钮造成重复授权。
    seen, uniq = set(), []
    for row in rows:
        key = (row["result_id"], row["result_hash"], row["run_id"], row["kind"])
        if row["result_id"] and key in seen:
            continue
        seen.add(key)
        uniq.append(row)
    counts = {
        "total": len(uniq),
        "waivable": sum(1 for x in uniq if x["waivable"]),
        "accepted": sum(1 for x in uniq if x["accepted"]),
        "pending": sum(1 for x in uniq if x["waivable"] and not x["accepted"]),
        "non_waivable": sum(1 for x in uniq if not x["waivable"]),
        "key_items": sum(1 for x in uniq if x["key_item"]),
        "key_pending": sum(1 for x in uniq if x["key_item"] and not x["accepted"]),
    }
    payload = {"ok": True, "case_id": case_id,
               "candidates": uniq, "counts": counts,
               "run_id": run_id,
               "unknown": _unknown_summary(info),
               "report_gate": _gate_status(case_id)}
    return payload


# ---------------------------------------------------------------------------
# POST：逐对象接受（禁止批量）
# ---------------------------------------------------------------------------
def _reject_payload(case_id: str, result_id, code: str, error: str,
                    detail: dict | None = None) -> dict:
    payload = _payload(case_id, ok=False)
    payload["rejected"] = [{"result_id": str(result_id or ""), "code": code,
                            "error": error, **(detail or {})}]
    payload["error"] = error
    payload["code"] = code
    return payload


def _batch_reject(case_id: str, error: str, field: str = "", result_id="") -> dict:
    payload = _reject_payload(case_id, result_id, "batch_forbidden", error,
                              {"field": field} if field else None)
    payload["batch_forbidden"] = True
    return payload


def _status_for(code: str) -> int:
    return int(_CODE_STATUS.get(str(code or ""), 400))


def post_accept(case_id: str, body: dict, user: dict) -> tuple:
    """逐对象接受 unknown（HTTP/CLI 共用）。返回 (status, payload)。"""
    body = body if isinstance(body, dict) else {}
    u = user or {}
    actor = str(u.get("sub") or u.get("id") or "").strip()
    role = str(u.get("role") or "").strip()
    # 角色门禁：与 report_gate._ACCEPT_ACTORS 的入口子集一致（super_admin/
    # platform_op 在 handler 的 _business_write_denied 已先拒绝，这里再兜底）。
    if role and role not in ACCEPT_ROLES:
        return 403, _reject_payload(case_id, "", "forbidden", "无例外授权权限")
    # 1) 批量固定反例：任何批量字段 / list / 逗号串 → 400，禁入服务层
    for key in BATCH_KEYS:
        if key in body:
            return 400, _batch_reject(
                case_id, "禁止批量豁免：一次只能接受一个对象（result_id）", field=key)
    rid = body.get("result_id")
    if isinstance(rid, (list, tuple, set, dict)):
        return 400, _batch_reject(case_id, "禁止批量豁免：result_id 必须为单个对象 ID",
                                  field="result_id", result_id="")
    rid = str(rid or "").strip()
    if not rid:
        return 400, _reject_payload(case_id, "", "result_id_required",
                                    "必须提供对象级 result_id（禁止一次接受全部 unknown）")
    if any(ch in rid for ch in (",", "|", " ")):
        return 400, _batch_reject(case_id, "禁止批量豁免：result_id 不允许包含多个对象",
                                  field="result_id", result_id=rid)
    reason = str(body.get("reason") or "").strip()
    if not reason:
        return 400, _reject_payload(case_id, rid, "reason_required",
                                    "接受 unknown 必须填写理由")
    if not actor:
        return 400, _reject_payload(case_id, rid, "actor_required", "必须记录授权人")
    # 2) 先 collect_unknown 取对象级 binding：只允许授权“当前 unknown 集合”里的对象，
    #    防止客户端拿旧 hash / 别的 case 的 result_id 直接写一条看似合法的审计。
    info = report_gate.collect_unknown(case_id)
    run_id = str(info.get("run_id") or "")
    bindings = {}
    for it in list(info.get("platform") or []) + list(info.get("manifest") or []):
        b = (it or {}).get("binding") or {}
        if str(b.get("result_id") or ""):
            bindings[str(b["result_id"])] = b
    binding = bindings.get(rid)
    if not binding:
        return 404, _reject_payload(
            case_id, rid, "not_found",
            "对象不在当前 unknown 候选（结果已变更/已失效或不属于本项目）")
    cur_run = str(binding.get("run_id") or run_id or "")
    req_run = str(body.get("run_id") or "").strip()
    req_hash = str(body.get("result_hash") or "").strip()
    if req_run and req_run != cur_run:
        payload = _reject_payload(
            case_id, rid, "stale_run",
            "run 已变化：只能按当前审核批次授权（旧批次授权已失效）",
            {"current_run_id": cur_run, "expected_run_id": req_run})
        return 409, payload
    if req_hash and req_hash != str(binding.get("result_hash") or ""):
        payload = _reject_payload(
            case_id, rid, "stale_hash",
            "结果/证据已变更（result_hash 不匹配），请重新读取后授权",
            {"current_hash": str(binding.get("result_hash") or ""),
             "expected_hash": req_hash})
        return 409, payload
    # 3) 服务层对象级授权（关键项双人/不可豁免/失效均由服务层判定）
    try:
        r = report_gate.accept_unknown_object(
            case_id, rid,
            result_hash=str(binding.get("result_hash") or ""),
            run_id=cur_run, reason=reason, actor=actor, role=role)
    except Exception as e:  # noqa: BLE001
        return 500, _reject_payload(case_id, rid, "internal_error",
                                    f"对象级授权失败：{type(e).__name__}")
    item = {
        "result_id": rid,
        "result_hash": str((r or {}).get("result_hash") or binding.get("result_hash") or ""),
        "run_id": str((r or {}).get("run_id") or cur_run),
        "kind": str((r or {}).get("kind") or binding.get("kind") or ""),
        "rule_code": str(binding.get("rule_code") or ""),
        "point_id": str(binding.get("point_id") or ""),
        "object_id": str(binding.get("object_id") or ""),
        "key_item": bool((r or {}).get("key_item", binding.get("key_item"))),
        "required_actors": int((r or {}).get("required_actors")
                               or binding.get("required_actors") or 1),
        "actors": list((r or {}).get("actors") or []),
        "expires_at": str((r or {}).get("expires_at") or ""),
        "actor": actor, "role": role,
        "accepted": bool((r or {}).get("accepted")),
        "requires_second": bool((r or {}).get("requires_second")),
        "note": str((r or {}).get("note") or ""),
    }
    if not (r or {}).get("ok"):
        code = str((r or {}).get("code") or "rejected")
        payload = _reject_payload(case_id, rid, code,
                                  str((r or {}).get("error") or "对象级授权被拒绝"), item)
        return _status_for(code), payload
    payload = _payload(case_id, ok=True)
    if item["accepted"]:
        payload["accepted"] = [item]
    else:
        payload["pending"] = [item]
    payload.update({"run_id": cur_run, "actor": actor, "role": role,
                    "unknown": _unknown_summary(report_gate.collect_unknown(case_id)),
                    "report_gate": _gate_status(case_id)})
    return 200, payload
