# -*- coding: utf-8 -*-
"""审核主链 HTTP 路由（T-203 第一批：从 server.py 物理移出）。

覆盖：报告 / 审核记录 / 发现（含证据链）/ 审核兼容入口 / 项目写链 / 文档 / KIE /
本地兼容与调试入口（demo、highlight、upload(deprecated)、compare、ocr、review-doc、judge、
doc/parse、sediment）。

**零行为变化约定**：
- 分发谓词仍留在 ``server.py`` 原位置（顺序/优先级不变），本模块只提供各分支处理体；
- 每块一个函数，只做 ``self.`` → ``handler.`` 的机械替换；dispatch 局部量（``p``/``q``/``_p0``）
  由 server.py 按**当时的值**传入，不重新解析 → 与拆分前一致；
- 权限判定、状态码、JSON 结构、审计动作**逐字未改**；鉴权仍由 ``server.py`` 的 ``_guard`` 先行；
- ``role_of`` / ``finding_provenance`` 的唯一实现移入本模块，server.py 保留同名别名
  （``from app.api.server import finding_provenance`` 等既有引用面不变）。
"""
from __future__ import annotations

import base64
import json
import logging
import os
import tempfile

from .. import config, db
from .. import repositories as R
from ..engine import deepparse, engine, factreview, judge, llm, ocr
from ..services import (compare, eval_service, project, pstates, review, rule)
from . import http_guard as _hg

_idem_scope, _idem_get, _idem_put = _hg.idem_scope, _hg.idem_get, _hg.idem_put

# 原内联分支可能「不响应而落到后续 dispatch」：用哨兵保持同一语义（不得当作已处理）。
NOT_HANDLED = object()

# ---------------- L143/T-③：裁决原因策略（单一实现；HTTP 路由与 UI 同口径） ----------------
# 背景（L132 报告 Top4）：单条裁决服务端不校验 reason（UI 必填、批量仅误报必填），
# API/CLI 可绕过 UI 纪律 → 误报/补证/忽略样本缺原因，进化台账质量下降。
# 本模块提供唯一口径；finding/批量裁决由 finding_routes.py 调用（不在本 lane 写作用域，
# 见报告 NOT DONE：接线 3 行），本模块内已接入 extra 复核裁决入口。
DECISION_ACTIONS = ("confirmed", "false_positive", "need_evidence", "ignored")
DECISION_REASON_REQUIRED = ("false_positive", "need_evidence", "ignored")
DECISION_REASON_LABELS = {
    "confirmed": "确认问题", "false_positive": "确认误报",
    "need_evidence": "退回补证", "ignored": "忽略",
}


def decision_reason_policy() -> dict:
    """裁决原因策略（供 UI/CLI/测试读取，避免各处硬编码分叉）。"""
    return {"actions": list(DECISION_ACTIONS),
            "reason_required": list(DECISION_REASON_REQUIRED),
            "reason_optional": ["confirmed"],
            "labels": dict(DECISION_REASON_LABELS),
            "version": "l143/v1"}


def validate_decision_reason(decision: str, reason: str = "") -> dict:
    """服务端原因校验（单一实现）。

    返回 ``{ok:True}`` 或 ``{ok:False,error,code:"reason_required",status:400,
    decision,action,exception}``；未知 decision 返回 ``invalid_decision``。
    口径：false_positive / need_evidence / ignored 必须给非空 reason；confirmed 可选。
    """
    d = str(decision or "").strip()
    # extra 复核历史词汇归一（confirm/reject）。
    _alias = {"confirm": "confirmed", "reject": "false_positive"}
    d = _alias.get(d, d)
    if d not in DECISION_ACTIONS:
        return {"ok": False, "error": "未知裁决动作", "code": "invalid_decision",
                "status": 400, "decision": decision}
    if d in DECISION_REASON_REQUIRED and not str(reason or "").strip():
        return {"ok": False, "status": 400, "code": "reason_required", "decision": d,
                "action": d,
                "error": "「%s」必须填写原因（原因会进入审计与规则进化反馈）"
                         % DECISION_REASON_LABELS.get(d, d)}
    return {"ok": True, "decision": d, "reason": str(reason or "").strip()}


def get_reports(handler, q):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 报告列表按 case 维度读取：case 必须存在且当前用户可见。
    _cid = (q.get("case_id") or q.get("case") or [""])[0]
    if not _cid:
        return handler._err(400, "需要 case_id", "invalid_request")
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    _rows = R.reports.list("case_id=?", (_cid,), order="exported_at DESC")
    return handler._send(200, handler._json({"items": _rows, "total": len(_rows), "case_id": _cid}))

def get_report_detail(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 真实 rep ID 的读取路由：不存在 404，跨租户/跨空间/他人 case 403/404。
    _rep, _deny = handler._report_scope(p.split("/")[-1])
    if _deny:
        return handler._send_deny(_deny)
    return handler._send(200, handler._json({"report": _rep, "case": _rep.get("case") or {}}))

def get_audit_records(handler, q):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    if (handler._active_role() or "") not in ("admin", "super_admin"):
        return handler._err(403, "仅管理员可查看审核记录", "forbidden")
    return handler._send(200, handler._json(review.audit_records(
        date_from=q.get("from", [""])[0], date_to=q.get("to", [""])[0],
        reviewer_id=q.get("reviewer", [""])[0])))

def get_my_audits(handler, q):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    u = handler._session_user() or {}
    # 业务管理员看本租户全部审核员的数据；审核员只看自己的数据。
    # 两者都清空 workspace，避免被当前空间限制成“只看当前空间的审核”。
    if u.get("role") in ("admin", "reviewer"):
        try:
            from app.services import ctx as _cxm
            _cm = _cxm.get_context()
            _cxm.set_context(_cm.get("tenant_id") or "t-default", "")
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    is_admin = u.get("role") in ("admin", "super_admin")
    return handler._send(200, handler._json(project.my_audits(
        "" if is_admin else u.get("sub", ""),
        status_f=q.get("status", [""])[0],
        keyword=q.get("q", [""])[0],
        date_from=q.get("from", [""])[0],
        date_to=q.get("to", [""])[0],
        page=int(q.get("page", ["1"])[0] or 1),
        page_size=int(q.get("page_size", ["20"])[0] or 20))))

def get_findings(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 发现列表按 case 维度读取：case 走统一 resolver，再做租户/空间隔离。
    _q = handler._query()
    _cid = _q.get("case_id") or _q.get("case") or ""
    if not _cid:
        return handler._err(400, "需要 case_id", "invalid_request")
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    _fs = R.findings.list("case_id=?", (_cid,), order="rowid DESC")
    _sev = (_q.get("severity") or "").strip()
    _st = (_q.get("status") or "").strip()
    if _sev:
        _fs = [f for f in _fs if (f.get("severity") or "") == _sev]
    if _st:
        _fs = [f for f in _fs if (f.get("status") or "pending") == _st]
    return handler._send(200, handler._json({"items": _fs, "total": len(_fs), "case_id": _cid}))

def get_finding_detail(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 发现详情：不存在 404，他人/跨租户/跨空间 403/404，不泄露存在性。
    _fid = p.split("/")[-1]
    _f, _deny = handler._resolve_id("finding", _fid)
    if _deny:
        return handler._send_deny(_deny)
    _detail = finding_provenance(_fid)
    try:
        _detail["decisions"] = R.decisions.list("finding_id=?", (_fid,), order="created_at DESC")
    except Exception:
        _detail["decisions"] = []
    return handler._send(200, handler._json(_detail))

def get_finding_provenance(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 证据链与详情/写路由统一 resolver 语义（以前对他人 finding 返回 404）。
    _fid = p.split("/")[-2]
    _f, _deny = handler._resolve_id("finding", _fid)
    if _deny:
        return handler._send_deny(_deny)
    return handler._send(200, handler._json(finding_provenance(_fid)))

def get_finding_root_cause(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # P0/P1 语义闭环：结构化根因只读接口；权限与 finding 详情同一 resolver。
    _fid = p.split("/")[-2]
    _f, _deny = handler._resolve_id("finding", _fid)
    if _deny:
        return handler._send_deny(_deny)
    _out = review.semantic_root_cause(_f)
    return handler._send(200 if _out.get("ok") else 404, handler._json(_out))

def get_reviews(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    limit, offset = handler._pagination()
    return handler._send(200, handler._json(R.cases.list(order="created_at DESC", limit=limit, offset=offset)))

def get_reviews_mine(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    u = handler._session_user()
    return handler._send(200, handler._json(review.my_cases(u.get("sub", "") if u else "")))

def get_highlight(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    if not config.GOLDEN or not os.path.exists(config.GOLDEN):
        return handler._err(400, "未配置样例文件（RULEPROOF_GOLDEN）", "not_configured")
    try:
        rep = engine.build_report(config.GOLDEN)
        return handler._send(200, engine.render_workbook_html(config.GOLDEN, rep["findings"]).encode("utf-8"),
                         "text/html; charset=utf-8")
    except Exception as e:
        return handler._err(500, str(e))

def get_document_detail(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # 文档详情：统一 document resolver；跨租户/跨空间/他人项目 403/404。
    _did = p.split("/")[-1]
    _doc, _deny = handler._resolve_id("document", _did)
    if _deny:
        return handler._send_deny(_deny)
    _u = handler._session_user() or {}
    _visible_cases = []
    try:
        with db.session() as _c1:
            _links = [r["case_id"] for r in _c1.execute(
                "SELECT case_id FROM case_document WHERE document_id=?", (_did,)).fetchall()]
        for _cid1 in _links:
            _cres = handler._resolve_id("case", _cid1, _u)
            if not _cres[1]:
                _visible_cases.append(_cid1)
    except Exception:
        _visible_cases = []
    # 不向前端回传服务器本地路径（path）；只暴露业务字段。
    _doc_out = {k: v for k, v in (_doc or {}).items() if k != "path"}
    return handler._send(200, handler._json({"document": _doc_out, "cases": _visible_cases}))

def get_document_parse_report(handler, p):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    did = p.split("/")[-2]
    row, _deny = handler._resolve_id("document", did)
    if _deny:
        return handler._send_deny(_deny)
    from app.engine import parse_report as _pr
    return handler._send(200, handler._json(_pr.report(row.get("path") or "",
                                                  row.get("filename") or "")))

def get_review_coverage(handler):
    """GET 分支处理体（原 server.py do_GET 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _b = str(handler._query().get("batch", "") or "")
    _batches = [x.strip() for x in _b.split(",") if x.strip()]
    if _batches:
        # batch 是二级 ID：先解析到所属 case，再按租户/空间/归属鉴权。
        for _bid in _batches:
            _bobj, _deny = handler._secondary_scope("batch", _bid)
            if _deny:
                return handler._send_deny(_deny)
        return handler._send(200, handler._json(pstates.coverage_batches(_batches)))
    # 无 batch 时只汇总当前用户可见的批次，绝不回退全库。
    return handler._send(200, handler._json(pstates.coverage_batches(handler._visible_batch_ids())))

def post_project_point_stale(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    from app.services import point_confirm
    return handler._send(200, handler._json(point_confirm.stale_for_case(_cid, notify=True)))

def post_project_documents_audit(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _cid = p.split("/")[-2]
    # 统一 case 解析：不存在的项目 404，他人的项目 403（项目写模块只做二次校验）。
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    from app.api import project_write_routes as _pw
    _bw = handler._body() or {}
    if p.endswith("/audit-async") and not _bw.get("idempotency_key"):
        _hkey = handler.headers.get("Idempotency-Key") or ""
        if _hkey:
            _bw["idempotency_key"] = _hkey
    _out = _pw.post(p, _bw, handler._session_user() or {}, handler._case_owned)
    if _out is not None:
        return handler._send(_out[0], handler._json(_out[1]))
    return NOT_HANDLED   # 原分支可能不响应而落到后续 dispatch（语义保持）

def post_review_report(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.api import report_routes as _rr
    _cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    _out = _rr.post_generate(p, _cid, handler._session_user() or {}, True)
    if _out is not None:
        return handler._send(_out[0], handler._json(_out[1]))
    return NOT_HANDLED   # 原分支可能不响应而落到后续 dispatch（语义保持）

def post_projects(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    try:
        from app.services import case_status as _cs
        _rows = project.list_cases() if hasattr(project, "list_cases") else None
        if _rows is not None:
            for _r in _rows:
                _st = _cs.compute(_r.get("id") or "")
                _r.update({"exec_status": _st["exec_status"], "review_status": _st["review_status"],
                           "report_status": _st["report_status"], "pending": _st["pending"]})
            return handler._send(200, handler._json(_rows))
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    b = handler._body()
    _ik = ""
    _ih = (handler.headers.get("Idempotency-Key", "") or "").strip()
    if _ih:
        _ik = "projects:" + _ih
    u = handler._session_user() or {}
    _scope = _idem_scope(u, "POST:/api/v1/projects", b)
    _ic = _idem_get(_ik)
    if _ic:
        if len(_ic) > 3 and _ic[3] != _scope:
            return handler._err(409, "Idempotency-Key 已用于其他请求", "idempotency_conflict")
        return handler._send(_ic[1], _ic[2])
    try:
        cid = project.create(b.get("name", "未命名项目"), u.get("sub", ""), b.get("description", ""),
                             b.get("audit_type", ""), b.get("focus", ""), b.get("audit_category", ""),
                             b.get("document_type", ""))
    except ValueError as e:
        return handler._err(400, str(e), "invalid_project")
    _pb = handler._json({"project_id": cid})
    _idem_put(_ik, 200, _pb, _scope)
    return handler._send(200, _pb)

def post_project_preview(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(cid)
    if _deny:
        return handler._send_deny(_deny)
    _q1 = handler._query()
    doc_id = _q1.get("doc_id", [""])[0]
    return handler._send(200, handler._json(review.document_preview(cid, doc_id)))

def post_project_manifest(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    from app.services import manifest as _mf
    _runs = R.audit_runs.list("case_id=?", (_cid,), order="created_at DESC", limit=1)
    _mid = (_runs[0].get("manifest_id") if _runs else "") or ""
    _row = None
    if _mid:
        with db.session() as _c:
            _x = _c.execute("SELECT * FROM audit_manifest WHERE id=?", (_mid,)).fetchone()
            _row = dict(_x) if _x else None
    if not _row:
        _built = _mf.freeze(_cid, actor=(handler._session_user() or {}).get("sub", ""))
        if _built.get("ok"):
            with db.session() as _c:
                _x = _c.execute("SELECT * FROM audit_manifest WHERE id=?", (_built["manifest_id"],)).fetchone()
                _row = dict(_x) if _x else None
    if not _row:
        return handler._err(404, "审核清单不存在", "not_found")
    for _k in ("objects_json", "rules_json", "items_json"):
        try: _row[_k] = json.loads(_row.get(_k) or "[]")
        except Exception: _row[_k] = []
    return handler._send(200, handler._json(_row))

def post_project_manifest_execute(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _cid = p.split("/")[-3]
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    _runs = R.audit_runs.list("case_id=?", (_cid,), order="created_at DESC", limit=1)
    _mid = (_runs[0].get("manifest_id") if _runs else "") or ""
    if not _mid:
        from app.services import manifest as _mf
        _b = _mf.freeze(_cid, actor=(handler._session_user() or {}).get("sub", ""))
        _mid = _b.get("manifest_id") or ""
    if not _mid:
        return handler._err(404, "审核清单不存在", "not_found")
    # 2026-11-20（gpt-5.2 文档评审发现）：此前直接调 manifest_exec.run，绕过
    # manifest.execute 的守卫（external_override_rejected / scope_violation_dropped 后置过滤
    # 与 manifest.executed 审计）。改为走统一入口，行为由 manifest.execute 决定；
    # 若 execute 不可用（缺实现）再回落到 run，避免接口直接 500。
    from app.services import manifest as _mf
    _actor = (handler._session_user() or {}).get("sub", "")
    # L52 ③ 清单执行入口二选一（响应显式标注 mode）：
    #   - 同一冻结清单已有执行结果 → 只读重放 replay_readonly（幂等：不写 active/finding）；
    #   - 首次执行 → manifest.execute 成功后 project.materialize_manifest_run 完整物化
    #     finding/evidence/anchor + audit_run（不再“只写 active”）。
    try:
        from app.services import single_entry as _se
        _se_on = _se.enabled()
    except Exception:  # noqa: BLE001 - 开关不可用 → 旧行为
        _se_on = False
    if _se_on:
        _ro = _mf.replay_readonly(_mid, actor=_actor)
        if _ro.get("executed"):
            return handler._send(200, handler._json(_ro))
    try:
        _res = _mf.execute(_mid, actor=_actor)
        if isinstance(_res, dict) and (_res.get("ok") is False):
            _code = str(_res.get("code") or "execute_failed")
            _st = int(_res.get("status") or 409)
            return handler._err(_st, str(_res.get("error") or "审核清单执行被阻断"), _code)
        if _se_on and isinstance(_res, dict):
            from app.services import project as _pj
            _mat = _pj.materialize_manifest_run(
                _cid, _mid, _res, actor=_actor,
                entry="http:POST /projects/{cid}/manifest/execute")
            _res = {**_res, **_mat, "manifest_only_entry": True}
        return handler._send(200, handler._json(_res))
    except Exception:
        if _se_on:
            # L52：开关开启时不再静默回落到低审计路径（L46a H17）。
            raise
        logging.getLogger(__name__).warning(
            "manifest.execute 不可用，回落 manifest_exec.run", exc_info=True)
    from app.services import manifest_exec as _me
    return handler._send(200, handler._json(_me.run(_mid)))

def post_project_ledger(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    _cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(_cid)
    if _deny:
        return handler._send_deny(_deny)
    # _query() 已经是扁平 dict（值不是 list），不能再取 [0]，否则只会拿到首字符。
    _b = handler._query().get("batch", "")
    for _bid in [x.strip() for x in str(_b or "").split(",") if x.strip()]:
        # 批次必须属于当前项目；否则会把他人 point_state 混进本项目台账。
        _bobj, _deny = handler._secondary_scope("batch", _bid)
        if _deny:
            return handler._send_deny(_deny)
        if _bobj.get("case_id") != _cid:
            return handler._err(404, "批次不存在", "not_found")
    from app.services import pstates as _ps
    return handler._send(200, handler._json(_ps.ledger(_b, case_id=_cid)))

def post_project_accept_gap(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # F-28 第二道角色校验：系统管理员/平台运营不写业务（不接受解析缺口）。
    _d = handler._business_write_denied("project.accept-gap")
    if _d:
        return _d
    _parts = p.split("/")
    cid, did = _parts[-4], _parts[-2]
    _case, _deny = handler._case_scope(cid)
    if _deny:
        return handler._send_deny(_deny)
    # 文档也必须能通过 document resolver：不能只凭项目归属修改任意 doc_id。
    _d, _deny = handler._resolve_id("document", did)
    if _deny:
        return handler._send_deny(_deny)
    u = handler._session_user() or {}
    b = handler._body()
    with db.session() as _c1:
        _link = _c1.execute("SELECT 1 FROM case_document WHERE case_id=? AND document_id=?",
                            (cid, did)).fetchone()
    if not _link:
        return handler._err(404, "文件不属于该项目", "not_found")
    R.documents.update(did, parse_summary="[缺口已接受] " + str(b.get("reason") or "")
                       + " ｜ " + str(_d.get("parse_summary") or ""))
    R.audit_logs.log(actor=u.get("sub", ""), action="document.accept_gap", object=did,
                     after=str(b.get("reason") or ""))
    return handler._send(200, handler._json({"ok": True, "doc_id": did}))

def post_reviews_extra_decide(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import extra_review as _er
    u = handler._session_user() or {}
    if (u.get("role") or "") not in ("admin", "reviewer"):
        return handler._err(403, "需要复核权限", "forbidden")
    b = handler._body() or {}
    # L143/T-③：非 confirmed 裁决服务端强制原因（与 batch/UI 同口径，400 reason_required）
    _chk = validate_decision_reason(str(b.get("decision") or ""),
                                    str(b.get("reason") or ""))
    if not _chk.get("ok"):
        return handler._err(int(_chk.get("status") or 400),
                            str(_chk.get("error") or "参数错误"),
                            str(_chk.get("code") or "invalid_request"))
    r = _er.decide(str(b.get("rule_code") or ""), str(b.get("decision") or ""),
                   str(b.get("quote") or ""), str(b.get("reason") or ""),
                   str(b.get("case_id") or ""), u.get("name") or u.get("username") or "reviewer")
    return handler._send(200 if r.get("ok") else 400, handler._json(r))

def post_kie_extract(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    from app.services import kie as _kie
    b = handler._body()
    did = str(b.get("document_id") or "")
    if not did:
        return handler._err(400, "需要 document_id", "invalid_request")
    _d, _deny = handler._resolve_id("document", did)
    if _deny:
        return handler._send_deny(_deny)
    _cid = _d.get("case_id", "")
    if not _cid:
        try:
            with db.session() as _cx:
                _row = _cx.execute("SELECT case_id FROM case_document WHERE document_id=? LIMIT 1",
                                   (did,)).fetchone()
            _cid = (_row["case_id"] if _row else "")
        except Exception:
            _cid = ""
    # 与旧行为一致：KIE 只接受已绑定项目且项目可见的文件；未绑定文件仍 403。
    if not _cid:
        return handler._err(403, "无权访问该文档", "forbidden")
    return handler._send(200, handler._json(_kie.extract_document(
        did, str(b.get("doc_type") or "contract"), bool(b.get("use_llm")))))

def post_findings(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    u = handler._session_user() or {}
    if u.get("role") != "reviewer":
        return handler._err(403, "只有审核员可以手动新增问题", "forbidden")
    b = handler._body()
    _case, _deny = handler._case_scope(b.get("case_id", ""), u)
    if _deny:
        return handler._send_deny(_deny)
    return handler._send(200, handler._json(review.add_manual_finding(
        b.get("case_id", ""), b.get("severity", "warning"), b.get("title", ""),
        b.get("detail", ""), b.get("category", ""), u.get("name", ""), u.get("sub", ""),
        b.get("locator", ""), b.get("quote", ""), b.get("document_id", ""),
        b.get("suggestion", ""))))

def post_project_retry_failed(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(cid)
    if _deny:
        return handler._send_deny(_deny)
    from app.services import retry as _rt
    try:
        r = _rt.retry_failed(cid)
    except ValueError as e:
        return handler._err(400, str(e), "invalid_project")
    return handler._send(200, handler._json(r))

def post_project_ai_assist(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    cid = p.split("/")[-2]
    _case, _deny = handler._case_scope(cid)
    if _deny:
        return handler._send_deny(_deny)
    from app.services import workspaces as _w11
    u = handler._session_user() or {}
    # 只校验项目归属（已在上面 _case_scope），审核员可对自己项目补跑
    _cur = _w11.current(u.get("sub", ""))
    if not _w11.module_on(_cur.get("id", ""), "mod_ai_assist"):
        return handler._err(403, "该工作空间未启用 AI 辅助规则", "module_off")
    b = handler._body() or {}
    try:
        # DU-17：审计 actor 必须回到真实发起人（HTTP 补跑审核的场景）。
        r = project.audit(cid, ai_assist=True, doc_type=str(b.get("doc_type") or ""),
                          actor=str(u.get("sub") or ""))
    except ValueError as e:
        return handler._err(400, str(e), "invalid_project")
    fs = r.get("findings") or []
    _ai_fs = [x for x in fs if str(x.get("origin") or "").startswith("platform")]
    return handler._send(200, handler._json({"ok": True, "total": len(fs), "ai_findings": len(_ai_fs)}))

def post_upload(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    b = handler._body()
    filename = b.get("filename", "upload.xlsx")
    try:
        data = base64.b64decode(b.get("data", ""), validate=True)
    except Exception:
        return handler._err(400, "data 不是合法 base64", "invalid_base64")
    ok, why = handler._valid_file(filename, data)
    if not ok:
        return handler._err(400, why, "invalid_file")
    suffix = os.path.splitext(filename)[1] or ".xlsx"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        from app.services import review_compat as _rc2
        _result = _rc2.run_review_api(
            b.get("name", filename), [tmp.name],
            user=(handler._session_user() or {}).get("sub", ""),
            ai_assist=b.get("ai_assist"), filenames=[filename])
        # X4：旧上传接口只保留兼容，明确标注 deprecated，并说明与主链路的
        # 模式/统计口径差异（默认 assisted，含平台点位弃权；不要与 manual 主链
        # 的未知/弃权数字直接对比）。
        _result["deprecated"] = {
            "endpoint": "/api/v1/upload",
            "since": "2026-11-18",
            "message": "旧上传接口已弃用（仅保留兼容）；请改用主链路："
                       "POST /api/v1/projects → POST /api/v1/projects/{id}/documents "
                       "→ POST /api/v1/projects/{id}/audit-async",
            "successor": [
                "POST /api/v1/projects",
                "POST /api/v1/projects/{id}/documents",
                "POST /api/v1/projects/{id}/audit-async",
            ],
            "compat_mode": str((_result.get("review_contract") or {}).get("mode") or ""),
            "note": "本接口默认 ai_assist=True（assisted）；未显式 ai_assist=false 时，"
                    "abstain/unknown 含平台点位弃权，不能与 manual 主链数字直接对比。",
        }
        return handler._send(200, handler._json(_result),
                          headers={"Deprecation": "true",
                                   "X-Deprecated-Endpoint": "/api/v1/projects"})
    except ValueError as e:
        # 规则体检/业务校验阻断是客户端可修正错误，不能伪装成服务端 500
        return handler._err(400, str(e), "business_blocked")
    except Exception as e:
        return handler._err(500, str(e))
    finally:
        os.unlink(tmp.name)

def post_ocr(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # T-131 安全守卫：OCR 会触发外部 OCR/视觉模型，调试接口不得由任意登录用户调用。
    # 角色 = admin/super_admin 或显式授权（RULEPROOF_MODEL_DEBUG_ROLES）；
    # 入参有界（base64/解码字节/MIME 白名单）；无 OCR 能力明确 503（不静默伪成功）；
    # 拒绝/不可用/成功均写审计（只落大小/哈希/MIME，不落图片内容/文本原文）。
    import hashlib as _hashlib
    _ou = handler._session_user() or {}
    _orole = _ou.get("role") or role_of(_ou.get("sub"))
    _oextra = {x.strip() for x in str(os.environ.get("RULEPROOF_MODEL_DEBUG_ROLES") or "").split(",")
               if x.strip()}
    _oaudit = lambda action, after=None: R.audit_logs.log(
        actor=_ou.get("sub", ""), action=action, object=str(_orole or "")[:40],
        after=json.dumps(after or {}, ensure_ascii=False))
    if _orole not in ("admin", "super_admin") and _orole not in _oextra:
        try:
            _oaudit("ocr.denied", {"path": p, "reason": "role"})
        except Exception:
            logging.getLogger(__name__).debug("ocr denied audit skipped", exc_info=True)
        return handler._err(403, "无权限：OCR 调试接口仅业务管理员/系统管理员或显式授权角色可调用",
                         "forbidden")
    # P1-06：数据边界 external_model=deny 时，图片不得发往外部 OCR/视觉模型。
    from app.engine import llm as _llm_ocr
    if _llm_ocr.external_model_denied():
        try:
            _oaudit("ocr.denied", {"path": p, "reason": "external_model_deny"})
        except Exception:
            logging.getLogger(__name__).debug("ocr policy audit skipped", exc_info=True)
        return handler._err(
            403, "数据边界策略 external_model=deny：禁止把图片发送外部 OCR/"
                 "视觉模型，已拒绝本次识别", "external_model_denied")
    b = handler._body() or {}
    _img_s = b.get("image") or ""
    if not isinstance(_img_s, str) or not _img_s.strip():
        return handler._err(400, "image 不能为空", "invalid_image")
    if len(_img_s) > 28 * 1024 * 1024:
        return handler._err(400, "图片过大（解码后上限 20MB）", "invalid_image")
    try:
        img = base64.b64decode(_img_s, validate=True)
    except Exception:
        return handler._err(400, "image 不是合法 base64", "invalid_base64")
    if not img:
        return handler._err(400, "图片为空", "invalid_image")
    if len(img) > 20 * 1024 * 1024:
        return handler._err(400, "图片过大（上限 20MB）", "invalid_image")
    _omime = str(b.get("mime") or "image/png").strip().lower()
    if _omime not in {"image/png", "image/jpeg", "image/jpg", "image/webp",
                      "image/gif", "image/bmp", "image/tiff"}:
        return handler._err(400, "不支持的图片类型（png/jpeg/webp/gif/bmp/tiff）", "invalid_mime")
    # 能力探测：任一专用 OCR（百度/Paddle/千帆）或视觉模型可用才调用；否则明确失败。
    _oready = False
    try:
        from app.engine import baidu_ocr as _baidu
        _oready = _oready or bool(_baidu.configured())
    except Exception:
        logging.getLogger(__name__).debug("ocr baidu probe failed", exc_info=True)
    try:
        from app.engine import paddleocr as _paddle
        _oready = _oready or bool(_paddle.configured())
    except Exception:
        logging.getLogger(__name__).debug("ocr paddle probe failed", exc_info=True)
    try:
        _oready = _oready or bool(ocr._dedicated_ocr_cfg())
    except Exception:
        logging.getLogger(__name__).debug("ocr dedicated probe failed", exc_info=True)
    try:
        from app.engine import llm_router as _orouter
        _oready = _oready or bool(_orouter.resolve().get("enabled"))
    except Exception:
        logging.getLogger(__name__).debug("ocr llm probe failed", exc_info=True)
    if not _oready:
        try:
            _oaudit("ocr.unavailable", {"path": p, "reason": "ocr_model_unconfigured",
                                        "bytes": len(img), "mime": _omime,
                                        "image_sha256": _hashlib.sha256(img).hexdigest()[:16]})
        except Exception:
            logging.getLogger(__name__).debug("ocr unavailable audit skipped", exc_info=True)
        return handler._err(503, "OCR 模型未配置（专用 OCR/视觉模型均未启用或无 API key）；"
                              "本次未调用外部模型", "ocr_model_unconfigured")
    try:
        text = ocr.ocr_image_via_vision(img, _omime, config)
    except Exception:
        logging.getLogger(__name__).error("ocr route call failed", exc_info=True)
        text = None
    if text is None:
        try:
            _oaudit("ocr.unavailable", {"path": p, "reason": "ocr_call_failed",
                                        "bytes": len(img), "mime": _omime,
                                        "image_sha256": _hashlib.sha256(img).hexdigest()[:16]})
        except Exception:
            logging.getLogger(__name__).debug("ocr failed audit skipped", exc_info=True)
        return handler._err(503, "OCR 模型调用失败或未返回结果；本次不返回伪造识别内容",
                         "ocr_unavailable")
    try:
        _oaudit("ocr.success", {"path": p, "bytes": len(img), "mime": _omime,
                                "image_sha256": _hashlib.sha256(img).hexdigest()[:16],
                                "text_chars": len(str(text))})
    except Exception:
        logging.getLogger(__name__).error("ocr success audit write failed", exc_info=True)
    return handler._send(200, handler._json({"text": text}))

def post_review_doc(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # T-131 安全守卫：解析调试接口仅 admin/super_admin 或显式授权角色可调用；
    # 文件名只允许单段（禁路径/..）、入参有界；临时文件路径不回传/不落日志；审计只落哈希/大小。
    import hashlib as _hashlib
    _ru = handler._session_user() or {}
    _rrole = _ru.get("role") or role_of(_ru.get("sub"))
    _rextra = {x.strip() for x in str(os.environ.get("RULEPROOF_MODEL_DEBUG_ROLES") or "").split(",")
               if x.strip()}
    if _rrole not in ("admin", "super_admin") and _rrole not in _rextra:
        try:
            R.audit_logs.log(actor=_ru.get("sub", ""), action="review_doc.denied",
                             object=str(_rrole or "")[:40],
                             after=json.dumps({"path": p, "reason": "role"}, ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("review-doc denied audit skipped", exc_info=True)
        return handler._err(403, "无权限：文档复核调试接口仅业务管理员/系统管理员或显式授权角色可调用",
                         "forbidden")
    b = handler._body() or {}
    _rfn = "doc.xlsx" if b.get("filename") is None else str(b.get("filename") or "")
    _rfn = (_rfn or "doc.xlsx").strip()
    if (len(_rfn) > 255 or "\x00" in _rfn or "/" in _rfn or "\\" in _rfn
            or ".." in _rfn):
        return handler._err(400, "文件名不合法（不得包含路径或上级目录）", "invalid_filename")
    try:
        data = base64.b64decode(b.get("data", ""), validate=True)
    except Exception:
        return handler._err(400, "data 不是合法 base64", "invalid_base64")
    ok, why = handler._valid_file(_rfn, data)
    if not ok:
        return handler._err(400, why, "invalid_file")
    _rext = os.path.splitext(_rfn)[1].lower() or ".xlsx"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=_rext)
    try:
        tmp.write(data); tmp.close()
        try:
            _rout = factreview.review_document(tmp.name)
        except Exception:
            logging.getLogger(__name__).error("review-doc parse failed", exc_info=True)
            try:
                R.audit_logs.log(actor=_ru.get("sub", ""), action="review_doc.unavailable",
                                 object=str(_rrole or "")[:40],
                                 after=json.dumps({"path": p, "reason": "parse_failed",
                                                   "ext": _rext, "bytes": len(data),
                                                   "doc_sha256": _hashlib.sha256(data).hexdigest()[:16]},
                                                  ensure_ascii=False))
            except Exception:
                logging.getLogger(__name__).debug("review-doc unavailable audit skipped", exc_info=True)
            return handler._err(400, "文档解析失败（不返回文件内容）", "review_doc_failed")
        # 不把服务器临时路径返回给调用方（路径/日志不落系统路径）
        _rsafe = "upload" + _rext
        try:
            _rs = json.dumps(_rout, ensure_ascii=False).replace(tmp.name, _rsafe)
            _rout = json.loads(_rs)
        except Exception:
            logging.getLogger(__name__).debug("review-doc sanitize failed", exc_info=True)
        try:
            R.audit_logs.log(actor=_ru.get("sub", ""), action="review_doc.success",
                             object=str(_rrole or "")[:40],
                             after=json.dumps({"path": p, "ext": _rext, "bytes": len(data),
                                               "doc_sha256": _hashlib.sha256(data).hexdigest()[:16],
                                               "fact_count": int((_rout or {}).get("fact_count") or 0),
                                               "findings": len((_rout or {}).get("findings") or [])},
                                              ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).error("review-doc success audit write failed", exc_info=True)
        return handler._send(200, handler._json(_rout))
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            logging.getLogger(__name__).debug("review-doc temp cleanup failed", exc_info=True)

def post_judge(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # T-128 安全守卫：语义判断会触发外部模型调用，不得任意登录用户触发。
    # 仅 admin/super_admin 或显式授权角色（RULEPROOF_JUDGE_ROLES 逗号分隔）可调用；
    # 拒绝/未配置/成功调用均写审计；无 key/未启用时明确失败（503），不再静默 200 弃权。
    _ju = handler._session_user() or {}
    _jrole = _ju.get("role") or role_of(_ju.get("sub"))
    _jextra = {x.strip() for x in str(os.environ.get("RULEPROOF_JUDGE_ROLES") or "").split(",")
               if x.strip()}
    if _jrole not in ("admin", "super_admin") and _jrole not in _jextra:
        try:
            R.audit_logs.log(actor=_ju.get("sub", ""), action="judge.semantic_denied",
                             object=str(_jrole or "")[:40],
                             after=json.dumps({"path": p, "reason": "role"}, ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug('judge denied audit skipped', exc_info=True)
        return handler._err(403, "无权限：语义判断（外部模型）仅业务管理员/系统管理员或显式授权角色可调用",
                         "forbidden")
    b = handler._body()
    _jq = str(b.get("question") or "").strip()
    if not _jq:
        return handler._err(400, "缺少 question", "invalid_request")
    if len(_jq) > 8000:
        return handler._err(400, "question 过长（上限 8000 字符）", "invalid_request")
    _jv = b.get("evidence") or []
    if not isinstance(_jv, list):
        return handler._err(400, "evidence 必须是数组", "invalid_request")
    if len(_jv) > 50:
        return handler._err(400, "evidence 条数过多（上限 50）", "invalid_request")
    try:
        _jchars = len(json.dumps(_jv, ensure_ascii=False))
    except Exception:
        _jchars = 0
    if _jchars > 20000:
        return handler._err(400, "evidence 过大（上限 20000 字符）", "invalid_request")
    try:
        _jprovider = llm.openai_judge_provider(config)
    except Exception:
        _jprovider = None
    if _jprovider is None:
        try:
            R.audit_logs.log(actor=_ju.get("sub", ""), action="judge.semantic_unavailable",
                             object="semantic_judge",
                             after=json.dumps({"reason": "llm_not_configured", "role": _jrole},
                                              ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug('judge unavailable audit skipped', exc_info=True)
        return handler._err(503, "语义判断模型未配置（缺少 LLM API key 或未启用）；本次未调用外部模型",
                         "judge_model_unconfigured")
    _jres = judge.semantic_judge(_jq, _jv, _jprovider).to_dict()
    try:
        import hashlib as _hashlib
        R.audit_logs.log(actor=_ju.get("sub", ""), action="judge.semantic",
                         object="semantic_judge",
                         after=json.dumps({
                             "question_sha256": _hashlib.sha256(_jq.encode("utf-8")).hexdigest()[:16],
                             "question_chars": len(_jq), "evidence_count": len(_jv),
                             "state": _jres.get("state"), "confidence": _jres.get("confidence"),
                             "provider": _jres.get("provider"), "role": _jrole},
                             ensure_ascii=False))
    except Exception:
        logging.getLogger(__name__).error('judge.semantic audit write failed', exc_info=True)
    return handler._send(200, handler._json(_jres))

def post_doc_parse(handler, p):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    # T-131 安全守卫：深度解析调试接口仅 admin/super_admin 或显式授权角色可调用；
    # 文件名只允许单段、入参有界；临时文件路径不回传/不落日志；审计只落哈希/大小/事实数。
    import hashlib as _hashlib
    _du = handler._session_user() or {}
    _drole = _du.get("role") or role_of(_du.get("sub"))
    _dextra = {x.strip() for x in str(os.environ.get("RULEPROOF_MODEL_DEBUG_ROLES") or "").split(",")
               if x.strip()}
    if _drole not in ("admin", "super_admin") and _drole not in _dextra:
        try:
            R.audit_logs.log(actor=_du.get("sub", ""), action="doc_parse.denied",
                             object=str(_drole or "")[:40],
                             after=json.dumps({"path": p, "reason": "role"}, ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).debug("doc-parse denied audit skipped", exc_info=True)
        return handler._err(403, "无权限：深度解析调试接口仅业务管理员/系统管理员或显式授权角色可调用",
                         "forbidden")
    b = handler._body() or {}
    _dfn = "doc.docx" if b.get("filename") is None else str(b.get("filename") or "")
    _dfn = (_dfn or "doc.docx").strip()
    if (len(_dfn) > 255 or "\x00" in _dfn or "/" in _dfn or "\\" in _dfn
            or ".." in _dfn):
        return handler._err(400, "文件名不合法（不得包含路径或上级目录）", "invalid_filename")
    try:
        data = base64.b64decode(b.get("data", ""), validate=True)
    except Exception:
        return handler._err(400, "data 不是合法 base64", "invalid_base64")
    ok, why = handler._valid_file(_dfn, data)
    if not ok:
        return handler._err(400, why, "invalid_file")
    _dext = os.path.splitext(_dfn)[1].lower() or ".docx"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=_dext)
    try:
        tmp.write(data); tmp.close()
        try:
            _dout = deepparse.parse_and_extract(tmp.name)
        except Exception:
            logging.getLogger(__name__).error("doc-parse failed", exc_info=True)
            try:
                R.audit_logs.log(actor=_du.get("sub", ""), action="doc_parse.unavailable",
                                 object=str(_drole or "")[:40],
                                 after=json.dumps({"path": p, "reason": "parse_failed",
                                                   "ext": _dext, "bytes": len(data),
                                                   "doc_sha256": _hashlib.sha256(data).hexdigest()[:16]},
                                                  ensure_ascii=False))
            except Exception:
                logging.getLogger(__name__).debug("doc-parse unavailable audit skipped", exc_info=True)
            return handler._err(400, "文档解析失败（不返回文件内容）", "doc_parse_failed")
        _dsafe = "upload" + _dext
        try:
            _ds = json.dumps(_dout, ensure_ascii=False).replace(tmp.name, _dsafe)
            _dout = json.loads(_ds)
        except Exception:
            logging.getLogger(__name__).debug("doc-parse sanitize failed", exc_info=True)
        try:
            _dtxt = ""
            try:
                _dtxt = str(((_dout or {}).get("doc") or {}).get("text") or "")
            except Exception:
                _dtxt = ""
            R.audit_logs.log(actor=_du.get("sub", ""), action="doc_parse.success",
                             object=str(_drole or "")[:40],
                             after=json.dumps({"path": p, "ext": _dext, "bytes": len(data),
                                               "doc_sha256": _hashlib.sha256(data).hexdigest()[:16],
                                               "fact_count": int((_dout or {}).get("fact_count") or 0),
                                               "text_chars": len(_dtxt)},
                                              ensure_ascii=False))
        except Exception:
            logging.getLogger(__name__).error("doc-parse success audit write failed", exc_info=True)
        return handler._send(200, handler._json(_dout))
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            logging.getLogger(__name__).debug("doc-parse temp cleanup failed", exc_info=True)

def post_sediment(handler):
    """POST 分支处理体（原 server.py do_POST 内联代码逐字搬移，权限/状态码/JSON/审计未改）。"""
    try:
        d = (handler._body() or {}).get("dir") or config.STANDARDS_DIR
    except Exception:
        d = config.STANDARDS_DIR
    if not d:
        return handler._err(400, "未配置企业标准目录（RULEPROOF_STANDARDS）", "not_configured")
    import os as _os
    if not _os.path.isdir(d):
        return handler._err(400, f"目录不存在：{d}", "invalid_directory")
    _allowed = _os.path.realpath(config.STANDARDS_DIR or _os.getcwd())
    _real = _os.path.realpath(d)
    _root = _os.path.realpath(_os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))))
    if not (_real == _allowed or _real.startswith(_allowed + _os.sep) or _real == _root or _real.startswith(_root + _os.sep)):
        return handler._err(403, "目录不在允许的导入范围内", "forbidden_directory")
    try:
        return handler._send(200, handler._json(rule.import_from_standards(d)))
    except Exception as e:  # noqa
        return handler._err(400, f"导入失败：{type(e).__name__}", "import_failed")


# ---------------- L155：Extractor-Verifier 只读校验端点 ----------------
# 依据 docs/qa/build55_ExtractorVerifier与字段置信_20261125.md：
#   POST /api/v1/extraction/verify             抽取值 → Verifier 校验 + 字段级置信度
#   GET  /api/v1/extraction/confidence-policy  置信度策略/阈值/信号（只读）
# 只读语义：不写库、不写审计、不调模型；未登录由 server._guard 统一 401，
# 第二道角色确认与 review 读接口同口径（reviewer/admin 可读）。
_EXTRACTION_READ_ROLES = ("reviewer", "admin")


def _extraction_guard(handler):
    """L155 只读端点第二道角色校验（未登录已由 _guard 统一 401）。"""
    u = handler._session_user() or {}
    role = str(u.get("role") or "")
    if role in _EXTRACTION_READ_ROLES:
        return None
    return handler._err(403, "仅审核员/业务管理员可使用抽取校验（只读）", "forbidden")


def post_extraction_verify(handler):
    """POST 分支处理体：抽取校验 + 字段级置信度（L155，只读）。

    body 示例::

        {"doc": "合同金额：120,000.00 元\\n签订日期：2026-01-01",
         "fields": [{"key": "amount", "label": "合同金额", "value": "120000.00",
                     "raw": "120,000.00 元", "unit": "元", "type": "number",
                     "quote": "120,000.00 元"}],
         "specs": {"amount": {"type": "number", "unit": "元", "min": 0}},
         "assertions": [],
         "samples": {"amount": ["120000.00", "120000"]},
         "include_confidence": true}
    """
    _deny = _extraction_guard(handler)
    if _deny:
        return _deny
    body = handler._body()
    if not isinstance(body, dict) or not body:
        return handler._err(400, "请求体必须是非空 JSON 对象（见 L155 接口契约）",
                            "invalid_request")
    from ..services import extraction_confidence as _ext_confidence
    from ..services import extraction_verifier as _ext_verifier
    try:
        out = _ext_confidence.score_request(body)
    except _ext_verifier.VerificationInputError as exc:
        return handler._err(400, str(exc), getattr(exc, "code", "invalid_request"))
    except Exception as exc:  # noqa: BLE001 - 校验失败必须显式 500，不静默
        logging.getLogger(__name__).error("extraction verify failed", exc_info=True)
        return handler._err(500, "抽取校验失败：%s" % type(exc).__name__, "verify_failed")
    payload = {"ok": True, "contract": "l155/v1", "read_only": True,
               "verify": out.get("verify") or {},
               "confidence": out.get("confidence") or {}}
    if body.get("include_confidence") is False:
        payload.pop("confidence", None)
    return handler._send(200, handler._json(payload))


def get_extraction_confidence_policy(handler):
    """GET 分支处理体：置信度策略（阈值/信号/校准口径，L155，只读）。"""
    _deny = _extraction_guard(handler)
    if _deny:
        return _deny
    from ..services import extraction_confidence as _ext_confidence
    return handler._send(200, handler._json({
        "ok": True, "contract": "l155/v1", "read_only": True,
        "policy": _ext_confidence.confidence_policy()}))


# ---------------- 共享 helper（唯一实现；server.py 以别名对外，引用面不变） ----------------
def role_of(user_id: str) -> str:
    """取用户角色 code（super_admin 优先）。"""
    if not user_id:
        return ""
    try:
        with db.session() as c:
            rows = c.execute("SELECT r.code FROM user_role ur JOIN role r ON r.id=ur.role_id WHERE ur.user_id=?",
                             (user_id,)).fetchall()
        codes = [r["code"] for r in rows]
        for pref in ("super_admin", "admin", "reviewer"):
            if pref in codes:
                return pref
        return codes[0] if codes else ""
    except Exception:
        return ""


# L148：run 冻结清单解析缓存（同一 case/run 的多条 finding 共享；有界，避免 GET
# 每次都解析大 JSON）。只缓存只读的 items 列表，不缓存版本解析结果（finding 各自不同）。
_PROV_MANIFEST_ITEMS_CACHE: dict = {}
_PROV_MANIFEST_CACHE_MAX = 8


def _prov_manifest_items(mid: str, run_id: str) -> tuple:
    """读 audit_manifest（按 manifest_id 优先，再回退 run_id）并解析 items_json。

    返回 ``(manifest_id, hash, items)``；读取失败返回 ``("", "", [])`` 并留 debug 日志。
    有界缓存（最多 8 个清单）只读；缓存值为负也缓存，避免无清单 run 每次重复查询。
    """
    key = str(mid or "") or ("run:" + str(run_id or ""))
    if key in _PROV_MANIFEST_ITEMS_CACHE:
        return _PROV_MANIFEST_ITEMS_CACHE[key]
    row = None
    try:
        with db.session() as c:
            if mid:
                row = c.execute(
                    "SELECT id,items_json,hash FROM audit_manifest WHERE id=?",
                    (mid,)).fetchone()
            if row is None and run_id:
                row = c.execute(
                    "SELECT id,items_json,hash FROM audit_manifest "
                    "WHERE run_id=? ORDER BY rowid DESC LIMIT 1", (run_id,)).fetchone()
        if row is None:
            out = ("", "", [])
        else:
            try:
                items = json.loads(row["items_json"] or "[]")
            except Exception:  # noqa: BLE001
                items = []
            if not isinstance(items, list):
                items = []
            out = (str(row["id"] or mid or ""), str(row["hash"] or ""), items)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug('ignored', exc_info=True)
        out = ("", "", [])
    _PROV_MANIFEST_ITEMS_CACHE[key] = out
    if len(_PROV_MANIFEST_ITEMS_CACHE) > _PROV_MANIFEST_CACHE_MAX:
        _PROV_MANIFEST_ITEMS_CACHE.pop(next(iter(_PROV_MANIFEST_ITEMS_CACHE)))
    return out


def _prov_run_frozen_version(f: dict, rule: dict) -> dict:
    """L148/T-③（读取侧）：按 finding 实际 run 的冻结清单解析实际规则版本（只读）。

    链路：``finding.run_id`` → ``audit_run.manifest_id`` → ``audit_manifest.items_json``
    → item.binding.rule_version.version_id（run 冻结时刻实际执行的版本）。失败/无关联
    返回 ``{}``（不猜、不抛）；latest published 不再作为“实际版本”来源。
    """
    run_id = str((f or {}).get("run_id") or "").strip()
    if not run_id:
        return {}
    try:
        run = R.audit_runs.get(run_id) or {}
    except Exception:  # noqa: BLE001 —— 读失败降级为空，由调用方显式记缺失
        logging.getLogger(__name__).debug('ignored', exc_info=True)
        run = {}
    mid = str(run.get("manifest_id") or "").strip()
    row_id, row_hash, items = _prov_manifest_items(mid, run_id)
    if not items:
        return {}
    codes = {str((f or {}).get("rule_id") or "")}
    if rule:
        codes.add(str(rule.get("id") or ""))
        codes.add(str(rule.get("code") or ""))
    codes.discard("")
    matches = [it for it in items if isinstance(it, dict) and (
        str(it.get("rule_id") or "") in codes or str(it.get("code") or "") in codes)]
    if not matches:
        return {}
    obj_id = str((f or {}).get("object_id") or "")
    with_obj = [it for it in matches
                if obj_id and str(it.get("object_id") or "") == obj_id]
    it = (with_obj or matches)[0]
    binding = it.get("binding") if isinstance(it.get("binding"), dict) else {}
    rv_meta = (binding.get("rule_version")
               if isinstance(binding.get("rule_version"), dict) else {})
    vid = str(rv_meta.get("version_id") or "").strip()
    if not vid:
        return {}
    try:
        version = R.rule_versions.get(vid) or None
    except Exception:  # noqa: BLE001
        version = None
    return {"available": True, "run_id": run_id, "manifest_id": row_id,
            "manifest_hash": row_hash, "version_id": vid, "version": version,
            "frozen_version": str(rv_meta.get("version")
                                  or (version or {}).get("version") or ""),
            "frozen_content_sha": str(rv_meta.get("content_sha") or ""),
            "matched_by": ("rule_code+object_id" if with_obj else "rule_code"),
            "source": "run.manifest.rule_version"}


def _prov_evidence_missing(rd: dict) -> list:
    """单条证据的缺失项（机读码；供前端/审计显式展示“缺什么”，不静默）。"""
    miss = []
    if not str(rd.get("locator") or "").strip():
        miss.append("locator")
    if not rd.get("page"):
        miss.append("page")
    if str(rd.get("locator_kind") or "none") not in ("cell", "page", "text_span"):
        miss.append("coordinate")
    if not rd.get("has_char_span"):
        miss.append("char_span")
    if not str(rd.get("quote") or "").strip():
        miss.append("quote")
    return miss


def _prov_evidence_explain(rd: dict) -> str:
    """单条证据的缺失说明（人读；不静默契约的文本来源）。"""
    kind = str(rd.get("locator_kind") or "none")
    return {"cell": "", "page": "仅页坐标（无单元格/字符区间）",
            "text_span": "仅字符区间（无页/单元格坐标）",
            "quote": "仅逐字引文（无可跳转坐标）",
            "filename": "仅文件名（无页/单元格/字符区间）",
            "manual": "人工新增占位（无坐标）",
            "none": "无定位字段"}.get(kind, "定位信息不完整")


def finding_provenance(fid: str) -> dict:
    """A3/B3：一条结论的证据链（规则版本→锚点/原文→模型/批次→案例/文档）。

    L143/T-③（2026-11-25，按 L132 报告 Top3 修复）：
      · doc 从 evidence.document_id 取（finding 表没有 doc_id 列，旧实现恒 None）；
      · page 从 anchor.locator 解析（anchor 表没有 page 列），并把 locator 里的
        ``Sheet!B15`` 解析成 sheet/row/col，文本 finding 用 char span 生成
        ``第N段 · 字符a-b`` 定位文本（供前端跳转/高亮）；
      · 规则版本优先 finding 实际 ``rule_version_id``；缺失时按 finding 实际 run 的
        冻结清单（``audit_run.manifest_id`` → ``audit_manifest.items_json`` →
        ``binding.rule_version.version_id``）解析；只有都缺失才回退「最新 published」
        并在 source/version_is_actual 中明确标注，杜绝张冠李戴。
    L148/T-③（2026-11-25，读取侧接线）：
      · 读取走 ``auditpoints.anchor_evidence_rows/anchor_read_columns`` 单一投影；
      · 新增顶层 ``location``/``char_span``/``missing``/``missing_detail`` 与
        ``run_manifest``/``version_is_actual``/``version_missing``/``doc_missing``，
        缺失项显式给出原因（前端不需再猜）；
      · 新增 ``anchor_backfill`` 能力声明（API 可用回填写侧，project.py 调用点不在本
        lane 写作用域）；``finding_anchor_backfill()`` 是 API/CLI 维护调用面。
    返回结构向后兼容（旧字段一个不少），只增字段。
    """
    f = R.findings.get(fid)
    if not f:
        return {}
    from app.services import auditpoints as _ap_prov
    chain, evidence = [], []
    _rows = _ap_prov.anchor_evidence_rows(fid, finding=f)
    _ev_raw = [(r.get("evidence") or {}, r.get("anchor") or {}) for r in _rows]
    _doc_id = ""
    for _r in _rows:
        if not _doc_id and _r.get("document_id"):
            _doc_id = str(_r["document_id"])
    rule, version, version_source, version_is_actual = None, None, "", False
    _version_detail, _run_frozen = {}, {}
    try:
        for r in R.rules.list():
            if r.get("code") == f.get("rule_id"):
                rule = r
                break
        _rv_id = str(f.get("rule_version_id") or "")
        if _rv_id:
            version = R.rule_versions.get(_rv_id) or None
            if version:
                version_source = "finding.rule_version_id"
                version_is_actual = True
                _version_detail = {"version_id": _rv_id,
                                   "reason": "finding 直接关联实际执行版本"}
        if not version:
            # 实际 run 的冻结清单 → 冻结时刻实际执行的版本（优先于字符串匹配/最新发布）
            _run_frozen = _prov_run_frozen_version(f, rule)
            if _run_frozen:
                _fv = _run_frozen.get("version")
                version = (dict(_fv) if _fv else
                           {"id": _run_frozen.get("version_id") or "",
                            "version": _run_frozen.get("frozen_version") or ""})
                version_source = "run.manifest.rule_version"
                version_is_actual = True
                _version_detail = {"version_id": _run_frozen.get("version_id") or "",
                                   "manifest_id": _run_frozen.get("manifest_id") or "",
                                   "reason": "按 finding 实际 run 的冻结清单解析"}
        if not version and rule:
            _want = str(f.get("rule_version") or "").strip()
            _vs = R.rule_versions.list("rule_id=?", (rule["id"],), order="rowid DESC")
            if _want:
                version = next((v for v in _vs
                                if str(v.get("version") or "") == _want), None)
                if version:
                    version_source = "finding.rule_version"
                    version_is_actual = True
                    _version_detail = {"version_id": str(version.get("id") or ""),
                                       "reason": "按 finding.rule_version 字符串精确匹配"}
            if not version:
                # 旧数据无版本关联：只作展示兜底，source/version_is_actual 明示非实际版本
                version = R.rules.published_version(rule["id"]) or None
                if version:
                    version_source = "latest_published_fallback"
                    version_is_actual = False
                    _version_detail = {
                        "version_id": str(version.get("id") or ""),
                        "reason": "finding 无 rule_version_id、rule_version 与 run 冻结清单"
                                  "均无可解析版本；仅展示最新 published（非实际版本）"}
    except Exception:  # noqa: BLE001 —— 版本解析失败不阻断证据链，缺失由 missing 显式给出
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    _run_manifest = {"run_id": str(f.get("run_id") or ""), "available": False,
                     "manifest_id": "", "source": "audit_run.manifest_id"}
    run = None
    if f.get("run_id"):
        try:
            run = R.audit_runs.get(f["run_id"])
        except Exception:  # noqa: BLE001
            run = None
        _run_manifest["manifest_id"] = str((run or {}).get("manifest_id") or "")
    if _run_frozen:
        _run_manifest.update(_run_frozen)
    elif not str(f.get("run_id") or "").strip():
        _run_manifest["reason"] = "finding.run_id 为空（无实际 run 可追溯）"
    elif not _run_manifest.get("manifest_id"):
        _run_manifest["reason"] = "run 未关联冻结清单 manifest_id"
    else:
        _run_manifest["reason"] = "冻结清单中未找到该 finding 的规则/对象绑定"
    case = R.cases.get(f.get("case_id")) if f.get("case_id") else None
    doc = None
    _doc_reason = ""
    _doc_ref = _doc_id or str(f.get("object_id") or "")
    if _doc_ref:
        # P2-07：文档读取必须绑定 finding 所属项目（不再直接 R.documents.get，
        # 也不再有“仅 tenant、无 workspace”的读路径）。
        try:
            with db.session() as _dc:
                _dr = _dc.execute(
                    "SELECT d.* FROM document d WHERE d.id=? AND EXISTS(SELECT 1 FROM "
                    "case_document cd WHERE cd.document_id=d.id AND cd.case_id=?)",
                    (_doc_ref, f.get("case_id") or "")).fetchone()
            doc = dict(_dr) if _dr else None
        except Exception:  # noqa: BLE001
            doc = None
        if doc:
            _doc_out = {k: v for k, v in doc.items() if k != "path"}
            _doc_out["has_path"] = bool(str(doc.get("path") or "").strip())
            doc = _doc_out
        else:
            _doc_reason = ("文档不存在或不属于该 finding 所属项目（P2-07 隔离）"
                           if _doc_id else "finding.object_id 指向的文档不存在")
    else:
        _doc_reason = "finding 与 evidence 均未记录 document_id"
    _fname = str((doc or {}).get("filename") or "")
    _rank = {"cell": 3, "page": 2, "text_span": 2, "quote": 1}
    _primary_idx, _primary_rank = -1, -1
    for e, a in _ev_raw:
        readable = _ap_prov.anchor_read_columns(a, finding=f, filename=_fname)
        ev = {
            "anchor": a, "anchor_id": str(a.get("id") or e.get("anchor_id") or ""),
            "document_id": str(e.get("document_id") or a.get("document_id") or ""),
            "excerpt": e.get("quote") or e.get("excerpt") or "",
            # 兼容旧字段（page/sheet/row/col 现在是解析后的可读值）
            "page": readable.get("page"), "sheet": readable.get("sheet"),
            "row": readable.get("row"), "col": readable.get("col"),
            # L143 新增：可读定位 / 字符区间 / 可导航判定
            "locator": readable.get("locator") or "",
            "locator_kind": readable.get("locator_kind") or "none",
            "text_locator": readable.get("text_locator") or "",
            "char_start": readable.get("char_start", -1),
            "char_end": readable.get("char_end", -1),
            "has_char_span": bool(readable.get("has_char_span")),
            "navigable": bool(readable.get("navigable")),
            "anchor_strength": readable.get("anchor_strength") or "none",
            "backfill_status": readable.get("backfill_status") or "",
            # L148：缺失项显式（机读码 + 人读说明）
            "missing": _prov_evidence_missing(readable),
            "explain": _prov_evidence_explain(readable),
        }
        evidence.append(ev)
        _r = _rank.get(str(readable.get("locator_kind") or "none"), 0)
        if _r > _primary_rank:
            _primary_idx, _primary_rank = len(evidence) - 1, _r
    _prim = evidence[_primary_idx] if 0 <= _primary_idx < len(evidence) else {}
    _prim_cell = ""
    if _prim.get("sheet") and _prim.get("row") and _prim.get("col"):
        _prim_cell = "%s!%s%d" % (_prim["sheet"], _prim["col"], int(_prim["row"]))
    location = {"source": ("evidence[%d]" % _primary_idx) if _prim else "",
                "locator": _prim.get("locator") or "",
                "locator_kind": _prim.get("locator_kind") or "none",
                "page": _prim.get("page"), "sheet": _prim.get("sheet") or "",
                "row": _prim.get("row"), "col": _prim.get("col") or "",
                "cell": _prim_cell, "char_start": _prim.get("char_start", -1),
                "char_end": _prim.get("char_end", -1),
                "has_char_span": bool(_prim.get("has_char_span")),
                "quote": _prim.get("excerpt") or "",
                "navigable": bool(_prim.get("navigable")),
                "anchor_strength": _prim.get("anchor_strength") or "none",
                "backfill_status": _prim.get("backfill_status") or ""}
    _cs, _ce = -1, -1
    try:
        _cs, _ce = int(f.get("char_start")), int(f.get("char_end"))
    except (TypeError, ValueError):
        _cs, _ce = -1, -1
    if not (_cs >= 0 and _ce > _cs):
        for ev in evidence:
            if ev.get("has_char_span"):
                try:
                    _cs, _ce = int(ev.get("char_start")), int(ev.get("char_end"))
                except (TypeError, ValueError):
                    _cs, _ce = -1, -1
                if _cs >= 0 and _ce > _cs:
                    break
    char_span = {"start": _cs, "end": _ce,
                 "length": (_ce - _cs) if (_cs >= 0 and _ce > _cs) else 0,
                 "has_span": bool(_cs >= 0 and _ce > _cs)}
    _missing, _missing_detail = [], {}
    if doc is None:
        _missing.append("doc")
        _missing_detail["doc"] = _doc_reason or "文档未解析"
    if version is None:
        _missing.append("rule_version")
        _missing_detail["rule_version"] = (
            "finding 无 rule_version_id，且实际 run 冻结清单无可解析版本"
            if str(f.get("run_id") or "").strip() else
            "finding 无 rule_version_id/rule_version，且无实际 run 可追溯")
    _nav = any(bool(ev.get("navigable")) for ev in evidence)
    if not _nav:
        _missing.append("navigable_position")
        _missing_detail["navigable_position"] = "证据均无页/单元格/字符区间可跳转坐标"
    if not any(ev.get("page") for ev in evidence):
        _missing.append("page")
        _missing_detail["page"] = "locator 无页码（PDF 页定位缺失）"
    if not any(str(ev.get("locator") or "").strip() for ev in evidence):
        _missing.append("locator")
        _missing_detail["locator"] = "anchor.locator 为空"
    if not char_span["has_span"]:
        _missing.append("char_span")
        _missing_detail["char_span"] = "finding/证据均无有效字符区间"
    if not any(str(ev.get("excerpt") or "").strip() for ev in evidence):
        _missing.append("quote")
        _missing_detail["quote"] = "证据无逐字引文"
    if rule:
        chain.append({"step": "规则", "code": rule.get("code"), "name": rule.get("name"),
                      "version": (version or {}).get("version"), "status": rule.get("status")})
    if version:
        chain.append({"step": "规则版本", "id": version.get("id"),
                      "published_at": version.get("published_at"),
                      "hash": (version.get("slots_json") or "")[:12],
                      "source": version_source or "finding.rule_version",
                      "is_actual": version_is_actual})
    if _run_frozen:
        chain.append({"step": "冻结清单",
                      "manifest_id": _run_frozen.get("manifest_id") or "",
                      "frozen_version_id": _run_frozen.get("version_id") or "",
                      "matched_by": _run_frozen.get("matched_by") or ""})
    if doc:
        chain.append({"step": "文档", "document_id": doc.get("id"),
                      "filename": doc.get("filename")})
    for ev in evidence:
        chain.append({"step": "证据锚点", "sheet": ev["sheet"], "row": ev["row"],
                      "col": ev["col"], "page": ev["page"],
                      "locator_kind": ev["locator_kind"],
                      "char_start": ev["char_start"], "char_end": ev["char_end"],
                      "navigable": ev["navigable"], "missing": ev["missing"],
                      "quote": (ev["excerpt"] or "")[:200]})
    chain.append({"step": "判定来源", "engine": f.get("engine"), "layer": f.get("layer") or "",
                  "severity": f.get("severity"), "created_at": f.get("created_at")})
    if run:
        chain.append({"step": "审核批次", "run_id": run.get("id"), "started_at": run.get("started_at"),
                      "finished_at": run.get("finished_at")})
    if case:
        chain.append({"step": "项目", "case_id": case.get("id"), "name": case.get("name"),
                      "conclusion": case.get("conclusion")})
    try:
        _cap = _ap_prov.anchor_backfill_capability()
    except Exception:  # noqa: BLE001
        _cap = {}
    return {"finding": {k: f.get(k) for k in ("id", "rule_id", "title", "severity", "status",
                                              "engine", "layer", "created_at", "run_id",
                                              "case_id", "rule_version", "rule_version_id",
                                              "object_id", "verbatim_quote", "char_start",
                                              "char_end", "anchor_mode", "anchor_strength",
                                              "backfill_status", "backfill_reason")},
            "rule": rule, "version": version, "version_source": version_source,
            "version_is_actual": version_is_actual,
            "version_missing": version is None, "version_detail": _version_detail,
            "run": run, "run_manifest": _run_manifest,
            "case": case, "doc": doc, "doc_missing": doc is None,
            "doc_missing_reason": _doc_reason,
            "evidence": evidence, "chain": chain,
            "location": location, "char_span": char_span,
            "missing": _missing, "missing_detail": _missing_detail,
            "navigable": _nav,
            "provenance_version": "l143/v1",
            "provenance_read_version": "l148/v1",
            "anchor_read_version": _ap_prov.ANCHOR_BACKFILL_VERSION,
            "anchor_read_source": "auditpoints.anchor_read_columns",
            "anchor_backfill": _cap}


def finding_anchor_backfill(fid: str, *, document_id: str = "", doc_text: str = "",
                            filename: str = "") -> dict:
    """L148/T-③（API 维护调用面）：回填单条 finding 的 anchor 可读坐标（幂等、审计）。

    供 HTTP 维护入口 / CLI / 迁移脚本调用，写侧唯一实现是
    ``auditpoints.apply_anchor_backfill``（只写 anchor/evidence 定位元数据，不改结论）。
    server.py 维护路由与 project.py 主链写点不在本 lane 写作用域，见报告 NOT DONE；
    **权限/租户校验由调用方负责**（本函数不做鉴权，和 auditpoints 写函数同层）。
    """
    f = R.findings.get(str(fid or ""))
    if not f:
        return {"ok": False, "error": "finding_not_found", "code": "not_found",
                "status": 404, "finding_id": str(fid or "")}
    from app.services import auditpoints as _ap_bf
    r = _ap_bf.apply_anchor_backfill(str(fid), finding=f, document_id=str(document_id or ""),
                                     doc_text=str(doc_text or ""),
                                     filename=str(filename or ""), audit=True)
    if isinstance(r, dict):
        r.setdefault("entrypoint", "review_routes.finding_anchor_backfill")
        r.setdefault("read_version", _ap_bf.ANCHOR_BACKFILL_VERSION)
    return r
