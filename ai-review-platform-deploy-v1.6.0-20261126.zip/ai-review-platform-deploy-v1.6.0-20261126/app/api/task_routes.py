"""任务路由模块：从 server.py 抽出，任务归属/取消仍走统一 resolver。"""
from __future__ import annotations
from ..services import task as _task
from ..services import ids as _ids


def get(path: str, user: dict):
    if path == "/api/v1/tasks":
        _u = user or {}
        _all = (_u.get("role") or "") in ("super_admin", "platform_op")
        return 200, _task.list_tasks(owner=("" if _all else _u.get("sub", "")))
    if path.startswith("/api/v1/tasks/"):
        try:
            return 200, _ids.resolve("task", path.split("/")[-1], user or {})
        except _ids.IDLookupError as e:
            return e.status, {"error": e.message, "code": e.code}
    return None


def post(path: str, body: dict, user: dict):
    if path.startswith("/api/v1/tasks/") and path.endswith("/cancel"):
        _tid = path.split("/")[-2]
        try:
            _ids.resolve("task", _tid, user or {})
        except _ids.IDLookupError as e:
            return e.status, {"error": e.message, "code": e.code}
        return 200, _task.cancel(_tid, actor=(user or {}).get("sub", ""))
    return None
