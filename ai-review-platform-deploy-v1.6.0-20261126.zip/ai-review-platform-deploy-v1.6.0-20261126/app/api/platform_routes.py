"""平台端租户/平台管理员路由（从 server.py 抽出的第一组领域路由）。

只处理平台运营域：权限、租户、平台管理员、租户管理员、平台密钥重置记录。
路由函数不直接写 HTTP 响应，返回 (status, payload) 或 None。
"""
from __future__ import annotations
import sqlite3

from .. import db
from .. import repositories as R
from ..services import permissions, tenants, password_reset


def _deny(msg="无权限（需平台层）", code="forbidden"):
    return 403, {"error": msg, "code": code}


def _is_platform(user: dict) -> bool:
    return (user or {}).get("role") == "platform_op"


def get(path: str, user: dict):
    if not _is_platform(user):
        return _deny("仅平台运营可访问平台租户接口")
    uid = (user or {}).get("sub", "")
    if path == "/api/v1/platform/admins":
        if not permissions.has(uid, "platform.tenant.view"):
            return _deny()
        return 200, {"items": tenants.list_platform_admins()}
    if path == "/api/v1/platform/tenants":
        if not permissions.has(uid, "platform.tenant.view"):
            return _deny()
        return 200, {"items": tenants.list_tenants()}
    if path.startswith("/api/v1/platform/tenants/") and path.endswith("/admins"):
        if not permissions.has(uid, "platform.tenant.view"):
            return _deny()
        return 200, {"items": tenants.list_tenant_admins(path.split("/")[-2])}
    if path == "/api/v1/platform/password-resets":
        if not permissions.has(uid, "platform.tenant.view"):
            return _deny()
        return 200, {"items": password_reset.list_resets("", 100)}
    if path == "/api/v1/platform/audit-logs":
        if not permissions.has(uid, "platform.tenant.view"):
            return _deny()
        rows = []
        with db.session() as c:
            for r in c.execute(
                    "SELECT id,actor,action,object,after_json,created_at FROM audit_log "
                    "WHERE action LIKE 'platform.%' OR action LIKE 'tenant.%' "
                    "ORDER BY created_at DESC LIMIT 200").fetchall():
                rows.append(dict(r))
        return 200, {"items": rows}
    return None


def post(path: str, user: dict, body: dict):
    if not _is_platform(user):
        return _deny("仅平台运营可访问平台租户接口")
    uid = (user or {}).get("sub", "")
    body = body or {}
    if path == "/api/v1/platform/admins":
        if not permissions.has(uid, "platform.tenant.view"):
            return _deny()
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.create_platform_admin(body.get("phone") or "", body.get("name") or "",
                                          body.get("password") or "", uid, body.get("email") or "")
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/admins/status":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.set_platform_admin_status(body.get("id") or "", body.get("status") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/admins/reset-password":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.reset_platform_admin_password(body.get("id") or "", body.get("password") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/admins/update":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.update_platform_admin(body.get("id") or "", body.get("name") or "",
                                          body.get("email") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/admins/delete":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.delete_platform_admin(body.get("id") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenants/create":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        try:
            r = tenants.create_tenant(body.get("code") or "", body.get("name") or "",
                                      body.get("admin_phone") or "", body.get("admin_pwd") or "", uid,
                                      body.get("industry") or "", body.get("contact_name") or "",
                                      body.get("contact_phone") or "", body.get("contact_email") or "",
                                      body.get("edition") or "trial", body.get("expires_at") or "",
                                      body.get("admin_name") or "", body.get("admin_email") or "")
        except sqlite3.IntegrityError:
            return 409, {"error": "管理员手机号已存在", "code": "conflict"}
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenants/update":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.update_tenant(body.get("id") or "", body, uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenants/delete":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.delete_tenant(body.get("id") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenants/status":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.set_status(body.get("id") or "", body.get("status") or "")
        return (200 if r.get("ok") else 400), r
    if path.startswith("/api/v1/platform/tenants/") and path.endswith("/admins"):
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        tid = path.split("/")[-2]
        r = tenants.add_tenant_admin(tid, body.get("name") or "", body.get("phone") or "",
                                     body.get("email") or "", body.get("password") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenant-admins/reset-password":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.reset_tenant_admin_password(body.get("id") or "", body.get("password") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenant-admins/update":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.update_tenant_admin(body.get("id") or "", body.get("name") or "",
                                        body.get("email") or "", uid)
        return (200 if r.get("ok") else 400), r
    if path == "/api/v1/platform/tenant-admins/status":
        if not permissions.has(uid, "platform.tenant.manage"):
            return _deny("无权限（需平台层管理）")
        r = tenants.set_tenant_admin_status(body.get("id") or "", body.get("status") or "", uid)
        return (200 if r.get("ok") else 400), r
    return None
