# -*- coding: utf-8 -*-
"""可观测性 HTTP 适配（T-201）：``GET /metrics`` + 增强版 ``GET /health``。

为什么放在独立 route 模块（server.py 只加 1 处注册）：
- server.py 太大、被多条任务线共享；可观测性逻辑集中在这里，注册只有一行，
  冲突面最小；
- 指标采集/权限/渲染全在 ``app/services/metrics.py``（纯内存、无第三方依赖），
  本模块只做 HTTP 适配与权限判定。

权限口径（/metrics）：
- 默认：**仅本机（loopback）或 admin/super_admin 会话**；其余 401/403；
- 部署到需要跨机抓取的 Prometheus 时，设置 ``RULEPROOF_METRICS_TOKEN``，
  则必须携带 ``Authorization: Bearer <token>``（或不带前缀直接 ``X-Metrics-Token``），
  本机匿名将被拒绝（显式配置优先于本机豁免）。

``/health``（公开，与既有契约兼容）在原有 ``ok/app/version`` 基础上增加依赖状态：
- DB：``SELECT 1`` 是否可用（``RULEPROOF_HEALTH_REQUIRE_DB`` 默认 1，必需则故障时 503）；
- 模型：是否配置可用（``RULEPROOF_HEALTH_REQUIRE_MODEL`` 默认 0，仅上报不阻断）；
- 告警：每次健康检查顺带评估一次告警规则（冷却窗口内不重复触发），
  这样没有外部调度器的单机部署也能闭环，不需要新增常驻线程。
"""
from __future__ import annotations

import logging
import os
import threading
import urllib.parse

from app import config

log = logging.getLogger(__name__)

_CTYPE = "text/plain; version=0.0.4; charset=utf-8"
_HOOK_LOCK = threading.Lock()

_LOOPBACK = ("127.0.0.1", "::1", "localhost")


# ---------------------------------------------------------------------------
# HTTP 响应计数埋点：包装 Handler._send（覆盖所有方法；只本模块安装，不改 server 逻辑）
# ---------------------------------------------------------------------------
def _install_http_hook(handler_cls) -> bool:
    """幂等：给 Handler._send 挂一层计数。返回是否本次新安装。"""
    try:
        with _HOOK_LOCK:
            orig = getattr(handler_cls, "_send", None)
            if orig is None or getattr(orig, "_rp_metrics_hooked", False):
                return False

            def _send(self, code, body, ctype="application/json; charset=utf-8",
                      headers=None):
                try:
                    from app.services import metrics as _m
                    _m.http_response(code, getattr(self, "command", ""))
                except Exception:  # noqa: BLE001 - 指标故障绝不能影响响应
                    log.warning("metrics http hook failed", exc_info=True)
                return orig(self, code, body, ctype, headers)

            _send._rp_metrics_hooked = True
            _send.__wrapped__ = orig
            handler_cls._send = _send
            return True
    except Exception:  # noqa: BLE001
        log.warning("metrics http hook install failed", exc_info=True)
        return False


# ---------------------------------------------------------------------------
# 权限
# ---------------------------------------------------------------------------
def _client_ip(handler) -> str:
    try:
        return str((handler.client_address or ("",))[0])
    except Exception:
        return ""


def _is_loopback(ip: str) -> bool:
    ip = str(ip or "")
    return ip in _LOOPBACK or ip.startswith("127.") or ip.startswith("::ffff:127.")


def _configured_token() -> str:
    return str(os.environ.get("RULEPROOF_METRICS_TOKEN") or "").strip()


def _token_from_request(handler) -> str:
    try:
        auth = str(handler.headers.get("Authorization") or "")
        if auth.lower().startswith("bearer "):
            return auth.split(" ", 1)[1].strip()
        return str(handler.headers.get("X-Metrics-Token") or "").strip()
    except Exception:
        return ""


def authorize(handler) -> tuple:
    """返回 (allowed: bool, status: int, code: str, reason: str)。

    顺序：显式 token 配置 > 本机 > 管理员会话。未登录且非本机 → 401；
    已登录但角色不足 → 403。**绝不把指标面暴露给匿名公网请求。**
    """
    token = _configured_token()
    if token:
        got = _token_from_request(handler)
        if got and got == token:
            return True, 200, "ok", "token"
        return False, 401, "unauthorized", "metrics token 缺失或不匹配"
    ip = _client_ip(handler)
    if _is_loopback(ip):
        return True, 200, "ok", "loopback"
    try:
        user = handler._session_user() or {}
    except Exception:
        user = {}
    role = str(user.get("role") or "")
    if not user:
        return False, 401, "unauthorized", "未登录（/metrics 仅本机或管理员）"
    if role in ("admin", "super_admin"):
        return True, 200, "ok", "role:%s" % role
    return False, 403, "forbidden", "/metrics 仅本机或管理员可访问"


# ---------------------------------------------------------------------------
# /metrics
# ---------------------------------------------------------------------------
def serve_metrics(handler) -> bool:
    allowed, status, code, reason = authorize(handler)
    if not allowed:
        body = handler._json({"error": reason, "code": code})
        handler._send(status, body, "application/json; charset=utf-8",
                      {"Cache-Control": "no-store"})
        return True
    from app.services import metrics as _m
    body = _m.scrape()
    handler._send(200, body, _CTYPE, {"Cache-Control": "no-store"})
    return True


# ---------------------------------------------------------------------------
# /health（公开：ok/app/version 兼容 + 依赖状态 + 告警评估）
# ---------------------------------------------------------------------------
def _health_payload() -> tuple:
    from app.services import alert_rules
    try:
        payload = alert_rules.health_payload()
    except Exception:  # noqa: BLE001 - 健康检查自身失败要显式降级为 503，不静默
        log.error("alert_rules.health_payload failed", exc_info=True)
        payload = {"ok": False, "dependencies": {
            "alerts": {"status": "error", "required": False,
                       "detail": "告警规则评估异常（见服务日志）"}}, "alerts": {}}
    deps = payload.get("dependencies") or {}
    body = {
        "ok": bool(payload.get("ok", True)),
        "app": config.APP_NAME,
        "version": config.APP_VERSION,
        "dependencies": deps,
        "alerts": payload.get("alerts") or {},
    }
    return (200 if body["ok"] else 503), body


def serve_health(handler) -> bool:
    status, body = _health_payload()
    handler._send(status, handler._json(body), "application/json; charset=utf-8",
                  {"Cache-Control": "no-store"})
    return True


# ---------------------------------------------------------------------------
# E1 自进化效果度量（T12，2026-11-23）：GET /api/v1/metrics/evolution/effect
#   只读查询 evolution_effect（写入点在 app/services/evolution.settle_feedback）。
#   权限（与 /api/v1/* 业务接口同口径，不做 loopback 匿名豁免——它是 /api/v1 面，
#   匿名 200 会被节点矩阵判为鉴权绕过）：metrics token（部署抓取）或 admin/super_admin 会话；
#   匿名 401、其它角色 403。只读，无写操作，不暴露模型内容。
# ---------------------------------------------------------------------------
_EFFECT_PATH = "/api/v1/metrics/evolution/effect"


def _authorize_effect(handler) -> tuple:
    """返回 (allowed, status, code, reason)；/api/v1 面必须登录或带 metrics token。"""
    token = _configured_token()
    if token:
        got = _token_from_request(handler)
        if got and got == token:
            return True, 200, "ok", "token"
        return False, 401, "unauthorized", "metrics token 缺失或不匹配"
    try:
        user = handler._session_user() or {}
    except Exception:
        user = {}
    role = str(user.get("role") or "")
    if not user:
        return False, 401, "unauthorized", "未登录（进化效果指标需登录）"
    if role in ("admin", "super_admin"):
        return True, 200, "ok", "role:%s" % role
    return False, 403, "forbidden", "进化效果指标仅管理员可访问"


def serve_evolution_effect(handler) -> bool:
    allowed, status, code, reason = _authorize_effect(handler)
    if not allowed:
        body = handler._json({"error": reason, "code": code})
        handler._send(status, body, "application/json; charset=utf-8",
                      {"Cache-Control": "no-store"})
        return True
    raw = str(getattr(handler, "path", "") or "")
    qs = urllib.parse.parse_qs(raw.split("?", 1)[1] if "?" in raw else "")
    kind = str((qs.get("kind") or [""])[0] or "").strip()
    subject_id = str((qs.get("subject_id") or [""])[0] or "").strip()
    raw_limit = str((qs.get("limit") or ["50"])[0] or "50").strip()
    try:
        limit = int(raw_limit)
    except ValueError:
        handler._send(400, handler._json({"error": "limit 必须是整数", "code": "invalid_argument"}),
                      "application/json; charset=utf-8", {"Cache-Control": "no-store"})
        return True
    if limit < 1 or limit > 500:
        handler._send(400, handler._json({"error": "limit 取值 1..500", "code": "invalid_argument"}),
                      "application/json; charset=utf-8", {"Cache-Control": "no-store"})
        return True
    from app.services import evolution as _evolution
    data = _evolution.effect_list(kind=kind, subject_id=subject_id, limit=limit)
    handler._send(200 if data.get("status") == "ok" else 503,
                  handler._json(data), "application/json; charset=utf-8",
                  {"Cache-Control": "no-store"})
    return True


# ---------------------------------------------------------------------------
# server.py 唯一注册入口
# ---------------------------------------------------------------------------
_METRICS_PATHS = ("/metrics",)
_HEALTH_PATHS = ("/health",)


def handle(handler, path: str) -> bool:
    """server.Handler.do_GET 第一行调用；返回 True 表示已响应。"""
    try:
        _install_http_hook(type(handler))
        p = str(path or "").strip()
        # E1（T12）：先于 /metrics 判定（精确路径，不影响既有 /metrics /health 契约）
        if p.rstrip("/") == _EFFECT_PATH:
            return serve_evolution_effect(handler)
        if p in _METRICS_PATHS:
            return serve_metrics(handler)
        if p in _HEALTH_PATHS:
            return serve_health(handler)
        return False
    except Exception:  # noqa: BLE001 - 可观测性端点异常不影响其它路由
        log.error("metrics route handle failed path=%s", path, exc_info=True)
        return False
