# -*- coding: utf-8 -*-
"""L50 规则分组标签 HTTP 路由（server.py 只做最小分发，业务在 app.services.rule_tags）。

路由（全部按当前会话租户/空间强隔离；跨租户/跨空间统一 404，不泄露存在性）：
- GET  /api/v1/rules/tags                     分组标签列表（含 rule_count/权限提示）
- POST /api/v1/rules/tags                     新建分组标签（admin/super_admin）
- POST /api/v1/rules/tags/<id>/rename         重命名/改色（admin/super_admin）
- POST /api/v1/rules/tags/<id>/delete         删除分组（连同打标关系，不删规则）
- POST /api/v1/rules/tags/<id>/assign         规则加入分组（reviewer/admin/super_admin，幂等）
- POST /api/v1/rules/tags/<id>/unassign       规则移出分组（同上，幂等）
- POST /api/v1/rules/tags/<id>/full-audit     分组全链路自检（只读 dry-run，写审计）
- GET  /api/v1/rules?tag_id=                  规则列表按分组过滤 + 行内附 tags
- POST /api/v1/rules/batch                    body 支持 tag_ids/tag_names（批量导入后自动打标）

与 ``rule.scope_json.tags``（manifest 路由标签）不同域：本组路由只读写独立表
``rule_tag`` / ``rule_tag_item``，不影响 manifest 路由/判定语义。

HTTP 层系统管理员（super_admin）写请求仍由 server._guard 的 F-28 业务边界 403；
平台运营不可访问业务接口。端口幂等/权限/审计在服务层，CLI 可复用同一服务。
"""
from __future__ import annotations

import logging
import re
import urllib.parse

from ..services import rule_tags as _svc

_ITEM_RE = re.compile(
    r"^/api/v1/rules/tags/([^/]+)/(rename|delete|assign|unassign|full-audit)/?$")
_log = logging.getLogger(__name__)


def _user(handler) -> dict:
    return handler._session_user() or {}


def _payload(exc: "_svc.RuleTagError"):
    return exc.status, exc.payload()


# --------------------------------------------------------------------------- GET
def get(handler, path: str, query: dict):
    """GET 分支：返回 (status, body)；None=非本组路径。"""
    _p = str(path or "").rstrip("/")
    if _p == "/api/v1/rules/tags":
        try:
            return 200, _svc.list_tags(_user(handler))
        except _svc.RuleTagError as exc:
            return _payload(exc)
        except Exception as exc:  # noqa: BLE001 - 读接口失败必须可见
            _log.error("rule_tags list failed: %s", type(exc).__name__, exc_info=True)
            return 500, {"ok": False, "error": "分组标签列表读取失败",
                         "code": "rule_tags_failed"}
    if _p.startswith("/api/v1/rules/tags/"):
        # 读取只开放列表接口：/tags/<id> 及子路径读一律 404（写能力见 POST）。
        return 404, {"ok": False, "error": "接口不存在", "code": "not_found"}
    return None


# --------------------------------------------------------------------------- POST
def post(handler, path: str):
    """POST 分支：返回 (status, body)；None=非本组路径。"""
    p = str(path or "").split("?", 1)[0].rstrip("/")
    user = _user(handler)
    try:
        if p == "/api/v1/rules/tags":
            body = handler._body() or {}
            return 200, _svc.create_tag(user, body.get("name"),
                                        color=str(body.get("color") or ""))
        m = _ITEM_RE.match(p)
        if m:
            tag_id = urllib.parse.unquote(m.group(1))
            op = m.group(2)
            body = handler._body() or {}
            if op == "rename":
                has_color = "color" in body
                return 200, _svc.rename_tag(
                    user, tag_id,
                    name=body.get("name") if "name" in body else None,
                    color=body.get("color") if has_color else None)
            if op == "delete":
                return 200, _svc.delete_tag(user, tag_id)
            if op == "assign":
                return 200, _svc.assign(user, tag_id, body)
            if op == "unassign":
                return 200, _svc.unassign(user, tag_id, body)
            if op == "full-audit":
                try:
                    limit = int(body.get("limit") or 0)
                except (TypeError, ValueError):
                    limit = 0
                return 200, _svc.full_audit(user, tag_id, limit=limit or 200)
        if p.startswith("/api/v1/rules/tags/"):
            return 404, {"ok": False, "error": "接口不存在", "code": "not_found"}
        return None
    except _svc.RuleTagError as exc:
        return _payload(exc)
    except Exception as exc:  # noqa: BLE001 - 写路由异常必须返回 500，不得静默
        _log.error("rule_tags %s failed: %s", p, type(exc).__name__, exc_info=True)
        return 500, {"ok": False, "error": "分组标签操作失败（服务内部错误）",
                     "code": "rule_tags_failed"}


# --------------------------------------------------------------------------- 规则列表 / 批量入库接线
def filter_rules_by_tag(rows: list, tag_id: str):
    """GET /api/v1/rules?tag_id= 过滤；返回 None 表示标签不存在/跨空间（调用方 404）。"""
    return _svc.filter_rules_by_tag(rows, tag_id)


def attach_tags(rows: list) -> list:
    """GET /api/v1/rules 行附 tags:[{id,name,color}]。"""
    return _svc.attach_tags(rows)


def prepare_batch_tags(body: dict, user: dict):
    """POST /api/v1/rules/batch 前置解析 tag_ids/tag_names；返回 (plan, deny)。"""
    try:
        return _svc.prepare_batch_tags(body or {}, user or {})
    except _svc.RuleTagError as exc:
        return None, (exc.status, exc.payload())
    except Exception as exc:  # noqa: BLE001 - 标签解析失败必须可见（不静默忽略）
        _log.error("batch rule tag prepare failed: %s", type(exc).__name__, exc_info=True)
        return None, (500, {"ok": False, "error": "批量打标参数解析失败",
                            "code": "rule_tags_failed"})


def commit_batch_tags(plan, created: list, skipped: list, user: dict) -> dict:
    """POST /api/v1/rules/batch 创建成功后逐条打标；返回响应增量。"""
    try:
        return _svc.commit_batch_tags(plan or {}, created or [], skipped or [], user or {})
    except _svc.RuleTagError as exc:
        return {"tags": [], "tagged": 0, "tag_created": [],
                "tag_error": exc.message, "tag_error_code": exc.code}
    except Exception as exc:  # noqa: BLE001
        _log.error("batch rule tag commit failed: %s", type(exc).__name__, exc_info=True)
        return {"tags": [], "tagged": 0, "tag_created": [],
                "tag_error": "批量打标失败（规则已创建，可稍后重试打标）",
                "tag_error_code": "rule_tags_failed"}
