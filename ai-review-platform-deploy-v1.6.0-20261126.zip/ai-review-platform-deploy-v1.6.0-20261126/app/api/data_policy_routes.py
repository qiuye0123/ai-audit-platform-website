# -*- coding: utf-8 -*-
"""数据边界策略路由（HTTP 接线；权限/租户边界与 CLI、页面同源）。

路由函数不直接写 HTTP 响应，返回 ``(status, payload)`` 或 ``None``。

- ``GET  /api/v1/data-policy``（或 ``/status`` / ``/config``）：读取状态与配置；
- ``PUT  /api/v1/data-policy``：保存配置（写审计 ``data.policy.updated``）；
- ``POST /api/v1/data-policy/purge/preview``：删除影响面预览 + 签发一次性预览凭证；
- ``POST /api/v1/data-policy/purge/execute``：删除执行（默认 dry-run；真实执行仅系统管理员）；
- ``DELETE /api/v1/data-policy/purge``：删除执行（必须携带预览凭证；未预览返回 428）。

权限（按现有四角色）：
- 读取/预览/dry-run：仅系统管理员（super_admin）；业务管理员已不进入数据边界；
- 真实删除：仅系统管理员（super_admin）；
- 审核员（reviewer）/平台运营（platform_op）：403（platform_op 还会被 ``_guard`` 提前拦截）。

跨租户：目标租户只取会话账号自身的 ``user.tenant_id``；请求里显式传其他租户 → 403。
"""
from __future__ import annotations

from .. import db
from ..services import sysconfig

# P2-13：权限口径与服务层 status 元数据同源（唯一事实源 = app.services.sysconfig）。
# 仅系统管理员；业务管理员/审核员/平台运营 403。
READ_ROLES = tuple(sysconfig.DATA_POLICY_READ_ROLES)
EXECUTE_ROLES = tuple(sysconfig.DATA_POLICY_EXECUTE_ROLES)
PREFIX = "/api/v1/data-policy"


def _json_err(status: int, msg: str, code: str = "forbidden", **extra) -> tuple:
    return status, {"error": msg, "code": code, **extra}


def _user_row(uid: str) -> dict:
    if not uid:
        return {}
    try:
        with db.session() as c:
            r = c.execute("SELECT id,tenant_id,status FROM user WHERE id=?", (uid,)).fetchone()
        return dict(r) if r else {}
    except Exception:
        return {}


def _actor(user: dict) -> tuple:
    """(uid, role, 账号租户)。租户以账号行为准，JWT claim 仅兜底。"""
    u = user or {}
    uid = str(u.get("sub") or u.get("id") or "")
    role = str(u.get("role") or "")
    row = _user_row(uid)
    tenant = str(row.get("tenant_id") or u.get("tenant_id") or "t-default").strip()
    return uid, role, tenant


def _require_read(user: dict) -> tuple:
    uid, role, tenant = _actor(user)
    if not uid:
        return None, _json_err(401, "未登录", "unauthorized")
    if role not in READ_ROLES:
        return None, _json_err(403, "仅系统管理员可查看数据边界策略", "forbidden")
    if not tenant:
        return None, _json_err(403, "账号未归属租户，不能访问数据边界策略", "forbidden")
    return (uid, role, tenant), None


def _resolve_tenant(user: dict, requested: str = "") -> tuple:
    """目标租户 = 账号所属租户；显式请求其他租户 → 403（跨租户拒绝）。"""
    ident, deny = _require_read(user)
    if deny:
        return None, deny
    uid, role, tenant = ident
    req = str(requested or "").strip()
    if req and req != tenant:
        return None, _json_err(403, "跨租户访问被拒绝：目标租户与账号所属租户不一致",
                               "tenant_mismatch")
    return (uid, role, tenant), None


def _result_http(result: dict) -> tuple:
    """服务层结果 → (http_status, payload)。"""
    if result.get("ok"):
        return 200, result
    status = int(result.get("status") or 400)
    return status, result


def _status_payload(role: str, tenant: str) -> dict:
    status = sysconfig.data_policy_status()
    return {
        "ok": True,
        "tenant_id": tenant,
        "role": role,
        "configured": status["configured"],
        "can_edit": role in READ_ROLES,
        "can_execute_purge": role in EXECUTE_ROLES,
        "policy": status["policy"],
        "values": status["policy"]["values"],
        "meta": status["policy"]["meta"],
        "missing_required": status["policy"]["missing_required"],
        "warnings": status["warnings"],
        "external_model": status["external_model"],
        "retention": status["retention"],
        "deletion": status["deletion"],
        "api": status["api"],
    }


def get(path: str, user: dict, query: dict = None):
    q = query or {}
    if path == PREFIX + "/retention":
        # L169/HW-19：留存天数 → 到期影响面只读入口（补读入口；不删除任何行）
        target, deny = _resolve_tenant(user, q.get("tenant_id") or q.get("tenant") or "")
        if deny:
            return deny
        uid, role, tenant = target
        return 200, sysconfig.retention_plan(tenant, str(q.get("workspace_id") or ""))
    if path == PREFIX or path in (PREFIX + "/status", PREFIX + "/config"):
        target, deny = _resolve_tenant(user, q.get("tenant_id") or q.get("tenant") or "")
        if deny:
            return deny
        uid, role, tenant = target
        payload = _status_payload(role, tenant)
        if path == PREFIX + "/config":
            return 200, {"ok": True, "tenant_id": tenant, "role": role,
                         "can_edit": role in READ_ROLES,
                         "policy": payload["policy"],
                         "configured": payload["configured"],
                         "warnings": payload["warnings"]}
        return 200, payload
    return None


def put(path: str, user: dict, body: dict):
    if path != PREFIX:
        return None
    target, deny = _resolve_tenant(user, (body or {}).get("tenant_id") or "")
    if deny:
        return deny
    uid, role, tenant = target
    if role not in READ_ROLES:
        return _json_err(403, "仅系统管理员可配置数据边界策略", "forbidden")
    fields = (body or {}).get("fields")
    if not isinstance(fields, dict):
        fields = {k: v for k, v in (body or {}).items()
                  if k not in ("tenant_id", "actor", "reason", "note_meta")}
    if not fields:
        return _json_err(400, "没有可保存的数据策略字段", "invalid_policy")
    try:
        result = sysconfig.set_data_policy(fields, actor=uid)
    except ValueError as exc:
        return _json_err(400, str(exc), "invalid_policy")
    payload = _status_payload(role, tenant)
    return 200, {"ok": True, "changed": result.get("changed") or {},
                 "configured": payload["configured"],
                 "policy": payload["policy"],
                 "warnings": payload["warnings"],
                 "can_edit": payload["can_edit"],
                 "can_execute_purge": payload["can_execute_purge"]}


def _as_bool(value, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() not in ("0", "false", "no", "off", "")


def post(path: str, user: dict, body: dict, request_id: str = "", ip: str = ""):
    b = body or {}
    if path == PREFIX + "/purge/preview":
        target, deny = _resolve_tenant(user, b.get("tenant_id") or "")
        if deny:
            return deny
        uid, role, tenant = target
        try:
            result = sysconfig.create_purge_preview(
                tenant, workspace_id=str(b.get("workspace_id") or ""), actor=uid,
                request_id=request_id, ip=ip)
        except ValueError as exc:
            return _json_err(400, str(exc), "invalid_tenant")
        return 200, {"ok": True, "role": role, "can_execute_purge": role in EXECUTE_ROLES,
                     **result}
    if path in (PREFIX + "/purge/execute", PREFIX + "/purge"):
        target, deny = _resolve_tenant(user, b.get("tenant_id") or "")
        if deny:
            return deny
        uid, role, tenant = target
        dry_run = _as_bool(b.get("dry_run"), True)
        if not dry_run and role not in EXECUTE_ROLES:
            return _json_err(403, "实际删除仅系统管理员执行（业务管理员可预览/dry-run）",
                             "forbidden")
        result = sysconfig.purge_execute(
            tenant, preview_token=str(b.get("preview_token") or b.get("token") or ""),
            actor=uid, confirm=str(b.get("confirm") or ""), dry_run=dry_run,
            workspace_id=str(b.get("workspace_id") or ""),
            request_id=request_id, ip=ip, role=role)
        return _result_http(result)
    return None


def delete(path: str, user: dict, body: dict, request_id: str = "", ip: str = ""):
    """DELETE 删除执行：必须带预览凭证；未预览/凭证过期 428，不删除任何行。"""
    if path != PREFIX + "/purge":
        return None
    b = body or {}
    target, deny = _resolve_tenant(user, b.get("tenant_id") or "")
    if deny:
        return deny
    uid, role, tenant = target
    if role not in EXECUTE_ROLES:
        return _json_err(403, "实际删除仅系统管理员执行（业务管理员可预览/dry-run）",
                         "forbidden")
    if not str(b.get("preview_token") or b.get("token") or ""):
        return _json_err(428, "不得未预览直接 DELETE：缺少 preview_token，请先调用 "
                              "POST /api/v1/data-policy/purge/preview", "preview_required")
    result = sysconfig.purge_execute(
        tenant, preview_token=str(b.get("preview_token") or b.get("token") or ""),
        actor=uid, confirm=str(b.get("confirm") or ""), dry_run=False,
        workspace_id=str(b.get("workspace_id") or ""), request_id=request_id, ip=ip,
        role=role)
    return _result_http(result)
