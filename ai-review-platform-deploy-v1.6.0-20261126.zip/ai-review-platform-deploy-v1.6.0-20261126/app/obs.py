"""统一结构化日志（平台级，零第三方依赖）。

目标格式（每条日志一行 JSON）::

    {"ts": "...", "level": "info", "rid": "...", "event": "http.request",
     "module": "api.server", "tenant": "t-default", "user": "u1",
     "status": "200", "latency": 12, "error": null, ...}

设计约束：
- **兼容旧日志**：既有 ``logging.getLogger(__name__).info(...)`` 不需要改；
  它们仍按原格式 / 原 handler 输出。只有显式调用 :func:`log_event` 的
  路径使用统一字段；``install()`` 只接管 ``ruleproof`` logger，不碰其它
  logger，也不会重复输出（``propagate=False``）。
- **不吞异常**：:func:`log_event` 自身失败时退化为普通 logging，不影响主流程。
- **请求上下文**：rid / tenant / user 放在 contextvars；异步任务线程启动时
  用 :func:`snapshot` / :func:`restore` 传递（contextvars 不会自动跨线程）。
"""
from __future__ import annotations

import contextvars
import json
import logging
import os
import sys
import threading
import time
from datetime import datetime, timezone

REQUIRED_FIELDS = ("ts", "level", "rid", "event", "module", "tenant", "user",
                   "status", "latency", "error")

_CTX = contextvars.ContextVar("ruleproof_obs_context", default={})
_INSTALL_LOCK = threading.Lock()
_LOG_LEVELS = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "warn": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}


def _now_iso() -> str:
    # 本地时区 + 偏移，便于人工看，也保留机器可解析性
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds")


def current() -> dict:
    """当前线程/协程的日志上下文快照。"""
    try:
        return dict(_CTX.get() or {})
    except Exception:
        return {}


def snapshot() -> dict:
    """给新线程传递上下文用（见 task.submit）。"""
    return current()


def bind(**kw) -> dict:
    """合并并写入日志上下文；值为 None 的键忽略。"""
    base = current()
    for k, v in kw.items():
        if v is None:
            continue
        base[k] = v
    _CTX.set(base)
    return base


def restore(ctx: dict | None) -> dict:
    """在新线程中恢复上下文快照。"""
    _CTX.set(dict(ctx or {}))
    return current()


def clear() -> None:
    _CTX.set({})


def _payload(event: str, *, module: str = "", level: str = "info",
             rid=None, tenant=None, user=None, status=None, latency=None,
             error=None, extra: dict | None = None) -> dict:
    ctx = current()
    data = {
        "ts": _now_iso(),
        "level": str(level or "info").lower(),
        "rid": rid if rid is not None else ctx.get("rid"),
        "event": str(event or "log"),
        "module": str(module or ctx.get("module") or "app"),
        "tenant": tenant if tenant is not None else ctx.get("tenant"),
        "user": user if user is not None else ctx.get("user"),
        "status": str(status) if status is not None else None,
        "latency": None if latency is None else int(latency),
        "error": None if error in (None, "") else str(error)[:2000],
    }
    if isinstance(extra, dict):
        for k, v in extra.items():
            if k in REQUIRED_FIELDS:
                # 必填字段以显式参数为准，extra 不得覆盖
                continue
            if k in ("message", "exc_info", "exc_text", "stack_info"):
                continue
            data[k] = v
    return data


class JsonFormatter(logging.Formatter):
    """把 ``log_event`` 的结构化数据或普通 LogRecord 输出成单行 JSON。

    普通 LogRecord（旧调用点）也会得到统一必填字段，event 取消息文本；
    这样灰度接入期间同一 logger 不会出现 JSON / 纯文本混排。
    """

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        data = getattr(record, "rp_event", None)
        if not isinstance(data, dict):
            ctx = current()
            err = None
            if record.exc_info:
                try:
                    err = self.formatException(record.exc_info)[:2000]
                except Exception:
                    err = "exception"
            data = {
                "ts": _now_iso(),
                "level": record.levelname.lower(),
                "rid": ctx.get("rid"),
                "event": record.getMessage(),
                "module": record.name,
                "tenant": ctx.get("tenant"),
                "user": ctx.get("user"),
                "status": None,
                "latency": None,
                "error": err,
            }
        else:
            data = dict(data)
        try:
            return json.dumps(data, ensure_ascii=False, default=str,
                              separators=(",", ":"))
        except Exception:
            # 理论上不会发生（default=str），极端情况下退化为安全文本
            return json.dumps({"ts": _now_iso(), "level": record.levelname.lower(),
                               "event": record.getMessage(), "module": record.name},
                              ensure_ascii=False)


def install(stream=None, level: str | int | None = None) -> logging.Logger:
    """安装统一 JSON formatter 到 ``ruleproof`` logger（幂等）。

    只接管 ``ruleproof`` 一个 logger；其余模块的既有日志保持原格式，
    避免一次性重写全部调用点。
    """
    logger = logging.getLogger("ruleproof")
    with _INSTALL_LOCK:
        if getattr(logger, "_rp_obs_installed", False):
            return logger
        handler = logging.StreamHandler(stream or sys.stderr)
        handler.setFormatter(JsonFormatter())
        logger.addHandler(handler)
        lv = level if level is not None else os.environ.get("RULEPROOF_LOG_LEVEL", "INFO")
        if isinstance(lv, str):
            lv = _LOG_LEVELS.get(lv.strip().lower(), logging.INFO)
        logger.setLevel(lv)
        # 防止与 root basicConfig 重复输出；其它 logger 不受影响
        logger.propagate = False
        logger._rp_obs_installed = True  # type: ignore[attr-defined]
        return logger


def log_event(event: str, *, module: str = "", level: str = "info",
              rid=None, tenant=None, user=None, status=None, latency=None,
              error=None, **extra) -> dict:
    """写一条统一格式日志，返回实际落盘的 payload（便于测试断言）。

    参数中的 ``extra`` 会作为附加字段输出（如 model/tokens/task_id），
    但不会覆盖必填字段。任何异常都不得影响调用方。
    """
    try:
        install()
        payload = _payload(event, module=module, level=level, rid=rid,
                           tenant=tenant, user=user, status=status,
                           latency=latency, error=error, extra=extra)
        logger = logging.getLogger("ruleproof")
        lvl = _LOG_LEVELS.get(str(level or "info").lower(), logging.INFO)
        # message 也写成完整 JSON：即使外部 handler 只格式化 %(message)s，
        # 仍然是合法的一行 JSON（兼容旧日志收集器）。
        logger.log(lvl, json.dumps(payload, ensure_ascii=False, default=str,
                                   separators=(",", ":")),
                   extra={"rp_event": payload})
        return payload
    except Exception:
        try:
            logging.getLogger("ruleproof").warning(
                "obs.log_event failed: %s", event, exc_info=True)
        except Exception:
            pass
        return {}




def elapsed_ms(t0: float | None) -> int | None:
    if not t0:
        return None
    return int((time.time() - t0) * 1000)
