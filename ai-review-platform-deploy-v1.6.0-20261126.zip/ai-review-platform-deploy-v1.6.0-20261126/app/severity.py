"""全平台唯一严重度口径：critical / warning / info。

历史别名（suspected、P0/P1/P2、高/中/低、major/minor）只允许从入口归一，
不得再写入 finding.severity。R0–R5 是规则风险等级，不是严重度。
"""
SEVERITIES = ("critical", "warning", "info")
SEVERITY_LABEL = {"critical": "严重", "warning": "一般", "info": "提示",
                  "suspected": "提示"}
SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2, "suspected": 2}

_ALIASES = {
    "critical": "critical", "high": "critical", "p0": "critical", "严重": "critical",
    "warning": "warning", "medium": "warning", "p1": "warning", "major": "warning",
    "一般": "warning", "中": "warning",
    "info": "info", "low": "info", "p2": "info", "minor": "info", "suspected": "info",
    "提示": "info", "信息": "info", "低": "info",
}


def from_rclass(rclass: str) -> str:
    """R0/R1→critical；R2/R3/R4→warning；R5→info。"""
    rc = str(rclass or "").strip().upper()
    if rc in ("R0", "R1"):
        return "critical"
    if rc == "R5":
        return "info"
    return "warning"


def normalize(value: str = "", rclass: str = "", strict: bool = False) -> str:
    """入口归一；未识别值默认 warning，strict=True 则拒绝。"""
    v = str(value or "").strip().lower()
    if v in _ALIASES:
        return _ALIASES[v]
    if v.upper() in ("R0", "R1", "R2", "R3", "R4", "R5"):
        return from_rclass(v)
    if rclass:
        return from_rclass(rclass)
    if strict and v:
        raise ValueError(f"未知严重度：{value}")
    return "warning"


def validate(value: str) -> bool:
    return str(value or "").strip().lower() in _ALIASES


def label(sev: str) -> str:
    return SEVERITY_LABEL.get(normalize(sev), normalize(sev))


