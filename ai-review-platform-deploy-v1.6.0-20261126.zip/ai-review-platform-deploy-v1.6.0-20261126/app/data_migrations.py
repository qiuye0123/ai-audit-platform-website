"""平台数据层迁移：幂等 + 事务化 + 迁移前 SQLite 备份。

设计边界：
- **不自动运行**。``init_db()`` / 服务启动不会调用本模块，避免在未显式
  授权时改动已经上线的 ``data/*.db``。运维执行::

      python -m app.data_migrations --db data/ruleproof.db --dry-run
      python -m app.data_migrations --db data/ruleproof.db

- 每个迁移只做 ``CREATE TABLE/INDEX IF NOT EXISTS`` 或可判定的加列；
  执行前检查表和列，老库缺列时记为 skipped，不会让整个迁移失败。
- 只要存在待执行迁移，先做在线 SQLite 备份并校验 integrity_check；
  备份失败直接中止，不写数据库。
- 所有迁移在一个 ``BEGIN IMMEDIATE`` 事务里执行并记录到
  ``schema_migration``；异常整体回滚，不会留下半迁移。
- 迁移记录带 checksum；已执行迁移的 SQL 被改动时只告警并跳过
  （不重放、不破坏上线数据），由人工确认后再发新迁移。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import sqlite3
import sys
import time
import uuid
from pathlib import Path

from .services import db_backup
from . import docmodel as _docmodel
# L109：迁移目录与 init_db 共用同一份 DDL 常量（单一事实源）；本模块 import 时
# app.db 已由 app.services 链加载，不存在环形导入。具体使用点均延迟到函数内亦可。
from . import db as _db


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                       (table,)).fetchone()
    return bool(row)


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {str(r[1]) for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}
    except sqlite3.Error:
        return set()


# 索引清单：热点查询路径。所有索引都带 IF NOT EXISTS，重复执行安全。
_INDEXES = [
    ("idx_finding_case_status", "finding", ("case_id", "status")),
    ("idx_finding_run", "finding", ("run_id",)),
    ("idx_finding_rule", "finding", ("rule_id",)),
    ("idx_audit_case_tenant_ws", "audit_case", ("tenant_id", "workspace_id")),
    ("idx_audit_case_created", "audit_case", ("created_at",)),
    ("idx_document_tenant_ws", "document", ("tenant_id", "workspace_id")),
    ("idx_audit_log_created", "audit_log", ("created_at",)),
    ("idx_audit_log_object", "audit_log", ("object",)),
    ("idx_task_job_status", "task_job", ("status",)),
    ("idx_task_job_case", "task_job", ("case_id",)),
    ("idx_llm_trace_created", "llm_trace", ("created_at",)),
    ("idx_llm_trace_case", "llm_trace", ("case_id",)),
    ("idx_open_event_delivery", "open_event", ("delivered", "status")),
    ("idx_notification_actor_read", "notification", ("actor", "read")),
    ("idx_password_reset_user", "password_reset", ("user_id",)),
    ("idx_business_term_ws", "business_term", ("workspace_id",)),
]


MIGRATIONS = [
    {
        "id": "20261116_001_hot_path_indexes",
        "name": "热路径索引（finding/audit_case/task_job/llm_trace/audit_log 等）",
        # L109：base=True 表示“基线迁移”——其对象属于新库基线，init_db 通过
        # ensure_infra_schema() 幂等安装（fresh init_db 即与迁移后同构）。
        "base": True,
        "indexes": _INDEXES,
        "sql": [],
    },
    {
        "id": "20261116_002_platform_upgrade",
        "name": "平台升级历史表（ops 看板读取最近升级版本）",
        "base": True,
        "indexes": [
            ("idx_platform_upgrade_applied", "platform_upgrade", ("applied_at",)),
        ],
        "sql": [
            """CREATE TABLE IF NOT EXISTS platform_upgrade(
  id TEXT PRIMARY KEY,
  from_version TEXT DEFAULT '',
  to_version TEXT DEFAULT '',
  package TEXT DEFAULT '',
  package_sha256 TEXT DEFAULT '',
  files_count INTEGER DEFAULT 0,
  applied_at TEXT DEFAULT '',
  applied_by TEXT DEFAULT '',
  UNIQUE(to_version, package_sha256)
)""",
        ],
    },
    # L94（2026-11-24）：重复数据监控——表 + 非唯一索引。与 app/db.py 的
    # L94_MONITOR_SCHEMA/L94_MONITOR_INDEXES 同一份 DDL 口径（schema_drift_test 交叉校验，
    # 迁移目录因此是“可执行单一事实源”：产品库/老库显式 apply 后与 init_db 新库同构）。
    {
        "id": "20261124_003_l94_dup_monitor",
        "name": "L94 重复数据监控表 + 非唯一索引（rule.code/document.hash/point_state；不强制唯一）",
        "indexes": [
            ("idx_rule_code_nonunique", "rule", ("code",)),
            ("idx_document_hash_nonunique", "document", ("hash",)),
            ("idx_point_state_batch_point_nonunique", "point_state",
             ("batch_id", "point_id")),
        ],
        "sql": [
            """CREATE TABLE IF NOT EXISTS duplicate_monitor_report (
  id TEXT PRIMARY KEY,
  table_name TEXT NOT NULL,
  key_columns TEXT NOT NULL,
  label TEXT DEFAULT '',
  total_rows INTEGER DEFAULT 0,
  dup_groups INTEGER DEFAULT 0,
  dup_rows INTEGER DEFAULT 0,
  top_json TEXT DEFAULT '[]',
  detected_at TEXT DEFAULT ''
)""",
            """CREATE INDEX IF NOT EXISTS idx_duplicate_monitor_table
  ON duplicate_monitor_report(table_name, detected_at)""",
        ],
    },
]

# ---------------------------------------------------------------------------
# L109（2026-11-25）：DB schema 单一事实源 —— 两条新迁移
#
# 1) 审计 append-only（auto=True）：audit_log 的 UPDATE/DELETE DB 级触发器。
#    首个应用时产品库/老库获得 DB 级不可改删保证；正常 INSERT 写入不受影响。
#    产品库**不在 L109 lane 自动应用**（本 lane 只读产品库），由 launch/升级时
#    显式 `rp db migrate`（或 `python -m app.data_migrations --db <库>`）安装。
# 2) 运行期按需 schema（auto=False / lazy）：rsi_shadow/direct_claim*/
#    evolution_accuracy_round/point_state_write_failure 等 feature-lazy 表 + 兜底列。
#    DDL 唯一定义在 app/db.py 的 RUNTIME_EXTENSION_SCHEMA / RUNTIME_EXTENSION_COLUMNS，
#    本目录只做“可执行登记”（fresh init 不自动建，保持与产品库 104 表同构；
#    显式 apply 时全量安装，随后运行期 ensure_*() 退化为 0 变更兜底）。
# 两者都幂等：CREATE ... IF NOT EXISTS / 加列前检查列存在。
# ---------------------------------------------------------------------------
_RUNTIME_EXTENSION_SQL = [
    sql for _group in _db.RUNTIME_EXTENSION_SCHEMA.values() for sql in _group
]
_RUNTIME_EXTENSION_ADD_COLUMNS = [
    (table, col, ddl)
    for table, cols in _db.RUNTIME_EXTENSION_COLUMNS.items()
    for col, ddl in cols
]
# 唯一索引：元组末位 True = UNIQUE；老库若有历史重复行，apply 时跳过该索引并告警
# （不阻断整次迁移；服务层写入降级为先查后插）。
_RUNTIME_EXTENSION_UNIQUE_INDEXES = [
    (name, table, cols, True)
    for name, table, cols in _db.RUNTIME_EXTENSION_UNIQUE_INDEXES
]

MIGRATIONS.extend([
    {
        "id": "20261125_004_l109_audit_append_only",
        "name": "L109 审计日志 append-only（audit_log UPDATE/DELETE DB 触发器）",
        "auto": True,
        "indexes": [],
        "sql": list(_db.AUDIT_APPEND_ONLY_SQL),
    },
    {
        "id": "20261125_005_l109_runtime_schema",
        "name": "L109 运行期按需 schema 统一登记（rsi_shadow/direct_claim*/"
                "evolution_accuracy_round/point_state_write_failure + 兜底列）",
        "auto": False,
        "indexes": list(_RUNTIME_EXTENSION_UNIQUE_INDEXES),
        "sql": list(_RUNTIME_EXTENSION_SQL),
        "add_columns": list(_RUNTIME_EXTENSION_ADD_COLUMNS),
    },
])

_MIGRATION_TABLE_SQL = """CREATE TABLE IF NOT EXISTS schema_migration(
  version TEXT PRIMARY KEY,
  name TEXT DEFAULT '',
  checksum TEXT DEFAULT '',
  applied_at TEXT DEFAULT ''
)"""


def ensure_infra_schema(conn: sqlite3.Connection) -> dict:
    """幂等安装迁移基础设施（由 init_db 调用，单一事实源 = 本模块迁移目录）。

    - ``schema_migration``：版本化迁移记录表；
    - ``base=True`` 的迁移条目对象（热路径索引 / platform_upgrade 升级历史表）；
    与 ``apply()`` 不同：不写迁移记录、不备份（纯 schema 基线，fresh init_db 与
    “init_db + 显式迁移”同构）。索引/表缺失时跳过（老库列不全不阻断启动）。
    """
    stats = {"tables": 0, "indexes": 0, "migrations": []}
    before_t = {str(r[0]) for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    conn.execute(_MIGRATION_TABLE_SQL)
    for m in MIGRATIONS:
        if not m.get("base"):
            continue
        stats["migrations"].append(m["id"])
        for sql in (m.get("sql") or []):
            try:
                conn.execute(sql)
            except sqlite3.Error:
                logging.getLogger(__name__).warning(
                    "L109 base 迁移对象安装跳过 %s", m["id"], exc_info=True)
        for idx_name, table, cols in (m.get("indexes") or []):
            if not _table_exists(conn, table):
                continue
            have = _columns(conn, table)
            if any(c not in have for c in cols):
                continue
            conn.execute(
                f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON "{table}"'
                f'({",".join(chr(34) + c + chr(34) for c in cols)})')
            stats["indexes"] += 1
    after_t = {str(r[0]) for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    stats["tables"] = len(after_t - before_t)
    return stats


def checksum_of(m: dict) -> str:
    """迁移 checksum（幂等/防篡改）。L109：含 add_columns 时一并纳入（旧迁移不受影响）。"""
    payload = {"id": m.get("id"), "name": m.get("name"),
               "indexes": m.get("indexes") or [], "sql": m.get("sql") or []}
    if m.get("add_columns"):
        payload["add_columns"] = m["add_columns"]
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def migration_catalog() -> list[dict]:
    """供升级包看板/测试读取的迁移目录（只读）。"""
    return [{"id": m["id"], "name": m["name"], "checksum": checksum_of(m)}
            for m in MIGRATIONS]


def schema_status(conn: sqlite3.Connection) -> dict:
    if not _table_exists(conn, "schema_migration"):
        return {"available": False, "version": 0, "latest": None, "applied": []}
    rows = [dict(r) for r in conn.execute(
        "SELECT version,name,checksum,applied_at FROM schema_migration "
        "ORDER BY applied_at,version").fetchall()]
    return {"available": True, "version": len(rows),
            "latest": (rows[-1] if rows else None), "applied": rows}


def _open(db_path: str | Path, query_only: bool = False) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 15000")
    conn.execute("PRAGMA foreign_keys = ON")
    if query_only:
        conn.execute("PRAGMA query_only = ON")
    return conn


def _planned(conn: sqlite3.Connection, *, auto_only: bool = False
             ) -> tuple[list[dict], list[dict], list[str], list[str]]:
    """计算待执行迁移。

    auto_only=True（seed/fresh init 路径）：跳过 ``auto=False`` 的 lazy 迁移
    （feature-lazy 表由运行期 ensure 或显式迁移安装，保持 fresh=产品库 104 表）；
    这些条目在 ``deferred`` 返回，便于看板/测试区分“延迟”与“已应用”。
    """
    existing = {}
    if _table_exists(conn, "schema_migration"):
        existing = {str(r["version"]): dict(r) for r in conn.execute(
            "SELECT version,name,checksum,applied_at FROM schema_migration").fetchall()}
    pending, skipped, warnings, deferred = [], [], [], []
    for m in MIGRATIONS:
        row = existing.get(m["id"])
        if row:
            if row.get("checksum") and row["checksum"] != checksum_of(m):
                warnings.append(f"迁移 {m['id']} 的 checksum 与已执行记录不一致，已跳过重放")
            skipped.append({"id": m["id"], "reason": "already_applied",
                            "applied_at": row.get("applied_at")})
            continue
        if auto_only and not m.get("auto", True):
            deferred.append(m["id"])
            continue
        pending.append(m)
    return pending, skipped, warnings, deferred


def apply(db_path: str | Path | None = None, *, dry_run: bool = False,
          backup: bool = True, backup_dir: str | Path | None = None,
          actor: str = "cli", auto_only: bool = False) -> dict:
    """执行待迁移。返回结构化结果；任何异常都不吞，交给调用方处理。

    ``auto_only=True``：只应用 auto=True 的迁移（fresh init/seed 路径）；
    auto=False 的 feature-lazy 迁移（L109 运行期 schema）返回在 ``deferred``，
    由运行期 ensure 兜底或显式 ``rp db migrate`` 安装。
    """
    path = Path(db_path or os.environ.get("RULEPROOF_DB", "")).resolve()
    if not path or not str(path) or not path.exists():
        return {"ok": False, "error": f"数据库不存在：{path}", "code": "db_not_found",
                "db": str(path), "dry_run": bool(dry_run)}
    started = time.time()
    conn = _open(path, query_only=bool(dry_run))
    try:
        before = schema_status(conn)
        pending, skipped, warnings, deferred = _planned(conn, auto_only=auto_only)
        if dry_run:
            return {
                "ok": True,
                "dry_run": True,
                "db": str(path),
                "pending": [m["id"] for m in pending],
                "skipped": skipped,
                "deferred": deferred,
                "warnings": warnings,
                "auto_only": bool(auto_only),
                "schema_version": before["version"],
                "would_backup": bool(pending and backup),
                "duration_ms": int((time.time() - started) * 1000),
            }
        if not pending:
            return {
                "ok": True,
                "dry_run": False,
                "db": str(path),
                "applied": [],
                "skipped": skipped,
                "deferred": deferred,
                "warnings": warnings,
                "backup": None,
                "auto_only": bool(auto_only),
                "schema_before": before["version"],
                "schema_after": before["version"],
                "duration_ms": int((time.time() - started) * 1000),
            }
        if not backup:
            return {"ok": False, "error": "迁移必须先备份（backup=False 被拒绝）",
                    "code": "backup_required", "db": str(path)}

        # 1) 先备份，后写库
        b = db_backup.backup(path, backup_dir=backup_dir, label="pre-migration")

        # 2) 单事务执行全部待迁移
        applied, skipped_migrations = [], []
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute(_MIGRATION_TABLE_SQL)
            for m in pending:
                try:
                    for sql in (m.get("sql") or []):
                        conn.execute(sql)
                    # L109：运行期兜底列（幂等：先查列存在再加；缺表则跳过）
                    cols_done, cols_skipped = [], []
                    for table, col, ddl in (m.get("add_columns") or []):
                        if not _table_exists(conn, table):
                            cols_skipped.append({"column": f"{table}.{col}",
                                                 "reason": f"缺少表 {table}"})
                            continue
                        if col in _columns(conn, table):
                            continue
                        conn.execute(
                            f'ALTER TABLE "{table}" ADD COLUMN "{col}" {ddl}')
                        cols_done.append(f"{table}.{col}")
                    idx_done, idx_skipped = [], []
                    for idx_spec in (m.get("indexes") or []):
                        idx_name, table, cols = idx_spec[0], idx_spec[1], idx_spec[2]
                        unique = bool(idx_spec[3]) if len(idx_spec) > 3 else False
                        if not _table_exists(conn, table):
                            idx_skipped.append({"index": idx_name, "reason": f"缺少表 {table}"})
                            continue
                        have = _columns(conn, table)
                        missing = [c for c in cols if c not in have]
                        if missing:
                            idx_skipped.append({"index": idx_name,
                                                "reason": f"缺少列 {','.join(missing)}"})
                            continue
                        try:
                            conn.execute(
                                f'CREATE {"UNIQUE " if unique else ""}INDEX '
                                f'IF NOT EXISTS "{idx_name}" ON "{table}"'
                                f'({",".join(chr(34) + c + chr(34) for c in cols)})')
                        except sqlite3.Error as exc:
                            # 唯一索引遇历史重复行：跳过不阻断迁移（运行期降级先查后插）
                            idx_skipped.append({"index": idx_name,
                                                "reason": f"建索引失败：{exc}"})
                            continue
                        idx_done.append(idx_name)
                    conn.execute(
                        "INSERT INTO schema_migration(version,name,checksum,applied_at) "
                        "VALUES(?,?,?,?)",
                        (m["id"], m.get("name") or "", checksum_of(m), _now()))
                    applied.append({"id": m["id"], "name": m.get("name") or "",
                                    "indexes": idx_done, "indexes_skipped": idx_skipped,
                                    "columns": cols_done,
                                    "columns_skipped": cols_skipped})
                    if idx_skipped:
                        warnings.append(f"{m['id']} 部分索引跳过：{idx_skipped}")
                    if cols_skipped:
                        warnings.append(f"{m['id']} 部分兜底列跳过：{cols_skipped}")
                except Exception as exc:
                    # 事务回滚由外层统一处理，但先记录哪个迁移失败
                    raise RuntimeError(f"迁移 {m['id']} 失败：{type(exc).__name__}: {exc}") from exc
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            raise

        after = schema_status(conn)
        return {
            "ok": True,
            "dry_run": False,
            "db": str(path),
            "applied": applied,
            "skipped": skipped + [{"id": x["id"], "reason": "not_pending"} for x in pending
                                  if x["id"] not in {a["id"] for a in applied}],
            "deferred": deferred,
            "warnings": warnings,
            "auto_only": bool(auto_only),
            "backup": b.get("backup"),
            "backup_sha256": b.get("sha256"),
            "schema_before": before["version"],
            "schema_after": after["version"],
            "actor": actor,
            "duration_ms": int((time.time() - started) * 1000),
        }
    finally:
        conn.close()


def record_upgrade(db_path: str | Path, *, from_version: str = "", to_version: str = "",
                   package: str = "", package_sha256: str = "",
                   files_count: int = 0, actor: str = "upgrade") -> dict:
    """幂等记录一次升级（供 ops 看板展示“最近升级版本”）。

    只写系统表 platform_upgrade，不写任何业务表；重复包（to_version +
    package_sha256 相同）只保留一条。
    """
    path = Path(db_path).resolve()
    if not path.exists():
        return {"ok": False, "error": f"数据库不存在：{path}", "code": "db_not_found"}
    conn = _open(path)
    try:
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute("""CREATE TABLE IF NOT EXISTS platform_upgrade(
  id TEXT PRIMARY KEY,
  from_version TEXT DEFAULT '',
  to_version TEXT DEFAULT '',
  package TEXT DEFAULT '',
  package_sha256 TEXT DEFAULT '',
  files_count INTEGER DEFAULT 0,
  applied_at TEXT DEFAULT '',
  applied_by TEXT DEFAULT '',
  UNIQUE(to_version, package_sha256)
)""")
            old = conn.execute(
                "SELECT id,from_version,to_version,package,package_sha256,files_count,applied_at "
                "FROM platform_upgrade WHERE to_version=? AND package_sha256=?",
                (to_version, package_sha256)).fetchone()
            if old:
                conn.commit()
                return {"ok": True, "recorded": False, "reason": "already_recorded",
                        "upgrade": dict(old)}
            uid = "upg-" + uuid.uuid4().hex[:12]
            conn.execute(
                "INSERT INTO platform_upgrade(id,from_version,to_version,package,"
                "package_sha256,files_count,applied_at,applied_by) VALUES(?,?,?,?,?,?,?,?)",
                (uid, from_version, to_version, os.path.basename(package),
                 package_sha256, int(files_count or 0), _now(), actor))
            conn.commit()
            row = conn.execute("SELECT * FROM platform_upgrade WHERE id=?", (uid,)).fetchone()
            return {"ok": True, "recorded": True, "upgrade": dict(row)}
        except Exception:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            raise
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# L93（2026-11-24）核心单据模型字段：显式迁移/回填/体检
#
# 设计边界（与 init_db 分工）：
#   * 列/索引/监控表/触发器由 ``app/db.py::init_db`` 幂等安装（服务启动即生效）；
#   * 本模块负责**显式**动作并留下 ``schema_migration`` / ``data_backfill_log`` 记录：
#       - ``--docmodel-migrate``：对已存在的库幂等执行 init_db 的 L93 部分并记录迁移；
#       - ``--docmodel-backfill``：历史 finding 来源回填（默认 dry-run；--apply 才写，
#         单事务 + 每行审计 + 幂等；产品库默认拒绝，需 --allow-product-db）。
#   * 回填只从可证明事实派生（run/审计事件/唯一规则版本/唯一清单结果），
#     多义或缺失一律留空并计入 skipped_reasons，不伪造。
# ---------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).resolve().parents[1]
_PRODUCT_DB = (_REPO_ROOT / "data" / "ruleproof.db").resolve()


def _docmodel_refuse_product(path: Path, allow_product: bool) -> None:
    try:
        resolved = Path(path).resolve()
    except Exception:
        resolved = Path(path)
    if resolved == _PRODUCT_DB and not allow_product:
        raise RuntimeError(
            f"拒绝直接操作产品库 {_PRODUCT_DB}（铁律 6/产品库守卫）："
            "请先 cp 到 /tmp 副本操作；确需产品库迁移须手工加 --allow-product-db"
            "（会先自动备份）")


def _docmodel_ensure_schema(conn: sqlite3.Connection, path: Path,
                            *, init_schema: bool) -> dict:
    """确保 L93 列存在。init_schema=True 时调用 init_db（幂等，全量初始化）。"""
    cols = _columns(conn, "finding")
    need = {"created_by", "created_at", "source", "source_kind", "rule_version_id"}
    if need <= cols:
        return {"ok": True, "already": True}
    if not init_schema:
        return {"ok": False, "error": "L93 列不存在：请先运行 `python -m app.cli db migrate`"
                                       " 或本命令加 --docmodel-init-schema（需 RULEPROOF_DB 指向同一路径）",
                "code": "docmodel_schema_missing", "missing": sorted(need - cols)}
    env_db = str(os.environ.get("RULEPROOF_DB") or "").strip()
    try:
        env_ok = bool(env_db) and Path(env_db).resolve() == Path(path).resolve()
    except Exception:
        env_ok = False
    if not env_ok:
        return {"ok": False, "code": "env_db_mismatch",
                "error": "init_db 需要 RULEPROOF_DB 与 --db 指向同一路径"
                         "（产品库写保护按 RULEPROOF_DB 判定）；请用环境变量指定同一 /tmp 副本"}
    from . import db as _dbm  # 延迟导入：确保 RULEPROOF_DB 已在环境里
    _dbm.init_db(conn)
    return {"ok": True, "already": False, "initialized": True}


def docmodel_migrate(db_path: str | Path | None = None, *, dry_run: bool = False,
                     allow_product: bool = False, actor: str = "cli") -> dict:
    """幂等执行 L93 schema 安装并写 schema_migration 记录（不写业务数据）。"""
    path = Path(db_path or os.environ.get("RULEPROOF_DB", "")).resolve()
    if not path or not path.exists():
        return {"ok": False, "error": f"数据库不存在：{path}", "code": "db_not_found"}
    _docmodel_refuse_product(path, allow_product)
    if dry_run:
        conn = _open(path, query_only=True)
        try:
            missing = sorted({"created_by", "created_at", "source", "source_kind",
                              "rule_version_id"} - _columns(conn, "finding"))
            return {"ok": True, "dry_run": True, "db": str(path),
                    "missing_columns": missing,
                    "would_init": bool(missing)}
        finally:
            conn.close()
    conn = _open(path)
    try:
        conn.execute("BEGIN IMMEDIATE")
        try:
            schema = _docmodel_ensure_schema(conn, path, init_schema=True)
            if not schema.get("ok"):
                conn.rollback()
                return {**schema, "db": str(path)}
            conn.execute(_MIGRATION_TABLE_SQL)
            import hashlib
            conn.execute(
                "INSERT OR IGNORE INTO schema_migration(version,name,checksum,applied_at) "
                "VALUES(?,?,?,?)",
                (_docmodel.MIGRATION_ID, _docmodel.MIGRATION_NAME,
                 hashlib.sha256(_docmodel.MIGRATION_ID.encode()).hexdigest(), _now()))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        health = _docmodel.refresh_health(conn)
        return {"ok": True, "dry_run": False, "db": str(path),
                "migration": _docmodel.MIGRATION_ID, "schema": schema,
                "health": health, "actor": actor}
    finally:
        conn.close()


def docmodel_status(db_path: str | Path | None = None, *,
                    refresh: bool = False) -> dict:
    """只读体检（空值率/解析率/重复码/孤儿/0 行报告）；refresh 时刷新监控快照。"""
    path = Path(db_path or os.environ.get("RULEPROOF_DB", "")).resolve()
    if not path or not path.exists():
        return {"ok": False, "error": f"数据库不存在：{path}", "code": "db_not_found"}
    conn = _open(path)
    try:
        snap = _docmodel.health_snapshot(conn)
        if refresh:
            snap["refreshed"] = _docmodel.refresh_health(conn)
        return {"ok": True, "db": str(path), "snapshot": snap}
    finally:
        conn.close()


def docmodel_backfill(db_path: str | Path | None = None, *, apply_: bool = False,
                      allow_product: bool = False, init_schema: bool = False,
                      limit: int = 0, backup: bool = True,
                      backup_dir: str | Path | None = None,
                      actor: str = "cli") -> dict:
    """历史 finding 来源回填：默认 dry-run；apply=True 才写（单事务+备份+审计+幂等）。"""
    path = Path(db_path or os.environ.get("RULEPROOF_DB", "")).resolve()
    if not path or not path.exists():
        return {"ok": False, "error": f"数据库不存在：{path}", "code": "db_not_found"}
    _docmodel_refuse_product(path, allow_product)
    if apply_ and not backup:
        return {"ok": False, "error": "回填必须先备份（backup=False 被拒绝）",
                "code": "backup_required"}
    conn = _open(path, query_only=False)
    try:
        # apply 必须在**任何写之前**先备份（含补列动作）；dry-run 对已迁移库零写。
        schema = _docmodel_ensure_schema(conn, path, init_schema=init_schema)
        if not schema.get("ok"):
            return {**schema, "db": str(path), "mode": "apply" if apply_ else "dry-run"}
        if not apply_:
            out = _docmodel.backfill(conn, dry_run=True)
            out["db"] = str(path)
            out["schema"] = schema
            _trim_plan(out.get("plan") or {})
            return out
        # 先算计划：已无待回填项 → 幂等 no-op（不备份、不写批次日志，避免每次重复写）
        plan = _docmodel.backfill_plan(conn, limit=limit)
        _pending = (int(plan.get("fillable_rows") or 0)
                    + int((plan.get("run_manifest") or {}).get("fillable") or 0)
                    + int((plan.get("manifest_run") or {}).get("fillable") or 0))
        if _pending <= 0:
            _trim_plan(plan)
            return {"ok": not bool(plan.get("error")), "mode": "apply",
                    "db": str(path), "schema": schema, "applied": 0,
                    "audit_rows": 0, "idempotent": True,
                    "backup": None,
                    "note": "幂等 no-op：历史回填已完成，无待填字段/关联",
                    "plan": plan}
        b = db_backup.backup(path, backup_dir=backup_dir,
                             label="pre-docmodel-backfill")
        out = _docmodel.backfill(conn, dry_run=False, actor=actor, limit=limit)
        out["db"] = str(path)
        out["schema"] = schema
        out["backup"] = b.get("backup")
        out["backup_sha256"] = b.get("sha256")
        out["actor"] = actor
        return out
    finally:
        conn.close()


def _trim_plan(plan: dict, keep: int = 20) -> dict:
    """CLI 输出瘦身：计划最多保留前 keep 条明细（统计仍为全量）。"""
    items = plan.get("items") or []
    if len(items) > keep:
        plan["items_truncated"] = len(items) - keep
        plan["items"] = items[:keep]
    for key in ("run_manifest", "manifest_run"):
        info = plan.get(key) or {}
        its = info.get("items") or []
        if len(its) > keep:
            info["items_truncated"] = len(its) - keep
            info["items"] = its[:keep]
            plan[key] = info
    return plan


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="平台数据层迁移（幂等/事务/先备份）")
    ap.add_argument("--db", default=os.environ.get("RULEPROOF_DB", ""),
                    help="SQLite 数据库路径；默认 RULEPROOF_DB")
    ap.add_argument("--dry-run", action="store_true", help="只列出待执行迁移，不写库")
    ap.add_argument("--backup-dir", default="", help="迁移前备份目录；默认 <db>/backups")
    ap.add_argument("--actor", default="cli")
    ap.add_argument("--auto-only", action="store_true",
                    help="只应用 auto=True 迁移（L109：审计 append-only；不预建 feature-lazy "
                         "运行期表，保持 fresh=产品库 104 表同构）")
    ap.add_argument("--json", action="store_true", help="输出 JSON（默认即 JSON）")
    ap.add_argument("--catalog", action="store_true", help="仅输出版本化迁移目录")
    ap.add_argument("--record-upgrade", action="store_true", help="迁移后记录升级版本")
    ap.add_argument("--record-only", action="store_true", help="只记录升级版本，不执行迁移")
    ap.add_argument("--from-version", default="")
    ap.add_argument("--to-version", default="")
    ap.add_argument("--package", default="")
    ap.add_argument("--package-sha256", default="")
    ap.add_argument("--files-count", type=int, default=0)
    # L93 单据模型字段（显式动作；默认 dry-run）
    ap.add_argument("--docmodel-migrate", action="store_true",
                    help="幂等安装 L93 单据模型列/索引/监控表/触发器并记录迁移")
    ap.add_argument("--docmodel-backfill", action="store_true",
                    help="历史 finding 来源回填（默认 dry-run；--apply 才写）")
    ap.add_argument("--docmodel-status", action="store_true",
                    help="只读体检：空值率/解析率/重复码/孤儿/0 行报告")
    ap.add_argument("--docmodel-init-schema", action="store_true",
                    help="回填前允许 init_db 幂等补列（要求 RULEPROOF_DB 与 --db 同路径）")
    ap.add_argument("--docmodel-refresh", action="store_true",
                    help="--docmodel-status 时同时刷新 docmodel_health_report 快照")
    ap.add_argument("--apply", action="store_true",
                    help="--docmodel-backfill 时真正写库（默认 dry-run）")
    ap.add_argument("--allow-product-db", action="store_true",
                    help="允许对产品库 data/ruleproof.db 执行 L93 显式迁移/回填（先自动备份）")
    ap.add_argument("--limit", type=int, default=0, help="回填/输出明细上限")
    # L94：DB 迁移单一事实源 / schema drift / 重复数据监控（只读；不自动改产品库）
    ap.add_argument("--schema-drift", action="store_true",
                    help="只读：目标库 vs init_db 新库 schema 差异报告（不写目标库）")
    ap.add_argument("--schema-drift-json", default="",
                    help="--schema-drift 的机读 JSON 输出路径（默认只打印）")
    ap.add_argument("--dup-monitor", action="store_true",
                    help="只读：重复数据监控报表（rule.code/document.hash/point_state）")
    ap.add_argument("--dup-record", action="store_true",
                    help="--dup-monitor 时把结果写入 duplicate_monitor_report（产品库拒绝）")
    args = ap.parse_args(argv)

    if args.catalog:
        print(json.dumps({"ok": True, "migrations": migration_catalog()},
                         ensure_ascii=False, indent=1))
        return 0
    # L94：schema drift / 重复数据监控（只读；产品库只以 mode=ro 打开）
    if args.schema_drift or args.dup_monitor:
        if not args.db:
            print(json.dumps({"ok": False, "error": "需要 --db 或 RULEPROOF_DB"},
                             ensure_ascii=False))
            return 2
        from . import db as _db
        if args.schema_drift:
            out = _db.schema_drift_report(args.db)
            if args.schema_drift_json:
                try:
                    Path(args.schema_drift_json).parent.mkdir(parents=True, exist_ok=True)
                    Path(args.schema_drift_json).write_text(
                        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
                except OSError as exc:
                    out["json_write_error"] = f"{type(exc).__name__}: {exc}"
        else:
            out = _db.duplicate_report(args.db)
            if args.dup_record and out.get("ok"):
                out["record"] = _db.record_duplicate_monitor(
                    args.db, metrics=out.get("metrics"))
        print(json.dumps(out, ensure_ascii=False, indent=1))
        return 0 if out.get("ok") else 1
    # L93：显式单据模型动作（不混入版本化 MIGRATIONS 自动 apply，避免改变既有
    # db migrate 的迁移条数契约；动作结果记录在 schema_migration / data_backfill_log）
    if args.docmodel_migrate or args.docmodel_backfill or args.docmodel_status:
        if not args.db:
            print(json.dumps({"ok": False, "error": "需要 --db 或 RULEPROOF_DB"},
                             ensure_ascii=False))
            return 2
        try:
            if args.docmodel_status:
                out = docmodel_status(args.db, refresh=args.docmodel_refresh)
                if out.get("ok"):
                    snap = out.get("snapshot") or {}
                    out["snapshot"] = {k: snap.get(k) for k in
                                       ("generated_at", "findings", "rules",
                                        "rule_versions", "reports", "audit_runs",
                                        "rule_code_duplicates", "missing_columns")}
                    if snap.get("orphans"):
                        out["snapshot"]["orphans"] = {
                            k: v for k, v in snap["orphans"].items()
                            if isinstance(v, dict)}
                    if snap.get("rows") and args.limit:
                        out["snapshot"]["rows"] = snap["rows"][:args.limit]
                print(json.dumps(out, ensure_ascii=False, indent=1))
                return 0 if out.get("ok") else 1
            if args.docmodel_migrate:
                out = docmodel_migrate(args.db, dry_run=args.dry_run,
                                       allow_product=args.allow_product_db,
                                       actor=args.actor)
                print(json.dumps(out, ensure_ascii=False, indent=1))
                return 0 if out.get("ok") else 1
            out = docmodel_backfill(
                args.db, apply_=bool(args.apply), allow_product=args.allow_product_db,
                init_schema=bool(args.docmodel_init_schema or args.apply),
                limit=args.limit, actor=args.actor,
                backup_dir=args.backup_dir or None)
            print(json.dumps(out, ensure_ascii=False, indent=1))
            return 0 if out.get("ok") else 1
        except Exception as exc:  # noqa: BLE001
            print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"},
                             ensure_ascii=False))
            return 1
    if not args.db:
        print(json.dumps({"ok": False, "error": "需要 --db 或 RULEPROOF_DB"},
                         ensure_ascii=False))
        return 2
    try:
        if args.record_only:
            out = record_upgrade(
                args.db, from_version=args.from_version, to_version=args.to_version,
                package=args.package, package_sha256=args.package_sha256,
                files_count=args.files_count, actor=args.actor)
            print(json.dumps(out, ensure_ascii=False, indent=1))
            return 0 if out.get("ok") else 1
        out = apply(args.db, dry_run=args.dry_run, actor=args.actor,
                    backup_dir=args.backup_dir or None,
                    auto_only=bool(getattr(args, "auto_only", False)))
        if out.get("ok") and args.record_upgrade and not args.dry_run:
            out["upgrade_record"] = record_upgrade(
                args.db, from_version=args.from_version, to_version=args.to_version,
                package=args.package, package_sha256=args.package_sha256,
                files_count=args.files_count, actor=args.actor)
        print(json.dumps(out, ensure_ascii=False, indent=1))
        return 0 if out.get("ok") else 1
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"},
                         ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
