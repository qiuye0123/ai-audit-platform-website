"""认证：OIDC 授权码流 + JWT（HS256，标准库实现）+ 会话（HMAC 签名 cookie）。

真实 IdP 只需配置 OIDC_* 环境变量；内置 mock IdP 供离线端到端测试。
"""
import base64
import hashlib
import hmac
import json
import os
import time
import urllib.parse


# ---------------------------------------------------------------- JWT（HS256）
def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64url_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _b64url_json(obj) -> str:
    return _b64url(json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode())


def sign_jwt(payload: dict, secret: str) -> str:
    h = _b64url_json({"alg": "HS256", "typ": "JWT"})
    p = _b64url_json(payload)
    sig = _b64url(hmac.new(secret.encode(), f"{h}.{p}".encode(), hashlib.sha256).digest())
    return f"{h}.{p}.{sig}"


def verify_jwt(token: str, secret: str) -> dict | None:
    try:
        h, p, s = token.split(".")
        exp_sig = _b64url(hmac.new(secret.encode(), f"{h}.{p}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(exp_sig, s):
            return None
        payload = json.loads(_b64url_dec(p))
        if payload.get("exp") and payload["exp"] < time.time():
            return None
        return payload
    except Exception:
        return None


# ---------------------------------------------------------------- 配置
def oidc_config() -> dict:
    """优先读管理端「开放平台 → SSO 配置」，回退环境变量。"""
    def _get(key, env, default):
        try:
            from .services import sysconfig
            v = sysconfig.get(key, "")
            return v if v else os.environ.get(env, default)
        except Exception:
            return os.environ.get(env, default)
    _secret = _get("sso.client_secret", "RULEPROOF_OIDC_CLIENT_SECRET", "dev-secret")
    if _is_prod() and _secret == "dev-secret":
        raise RuntimeError("生产环境必须配置 RULEPROOF_OIDC_CLIENT_SECRET")
    return {
        "enabled": _get("sso.enabled", "RULEPROOF_OIDC_ENABLED", "") in ("1", "true", True),
        "issuer": _get("sso.issuer", "RULEPROOF_OIDC_ISSUER", "http://127.0.0.1:8765/mock-oidc"),
        "client_id": _get("sso.client_id", "RULEPROOF_OIDC_CLIENT_ID", "ruleproof"),
        "client_secret": _secret,
        "redirect_uri": _get("sso.redirect_uri", "RULEPROOF_OIDC_REDIRECT", "http://127.0.0.1:8765/callback"),
    }


SESSION_DEV_SECRET = "ruleproof-session-dev-secret"


def _is_prod() -> bool:
    return (os.environ.get("RULEPROOF_ENV") or "").strip().lower() in ("prod", "production")


def session_secret() -> str:
    """会话签名密钥（E-02）。

    prod 下必须配置真实密钥；空串/纯空白/开发占位值一律视为“未配置”并拒绝。
    旧实现把 `.env` 里的 `RULEPROOF_SESSION_SECRET=`（空串）当成合法密钥，
    会用空密钥签发 JWT（登录看似成功但实际不安全）；环境变量完全缺失时才抛
    RuntimeError，导致登录空响应。现在两种情形统一为可读的 RuntimeError。
    """
    v = (os.environ.get("RULEPROOF_SESSION_SECRET") or "").strip()
    if _is_prod():
        if not v or v == SESSION_DEV_SECRET:
            raise RuntimeError(
                "生产环境必须配置 RULEPROOF_SESSION_SECRET（当前为空或开发占位值）。"
                "生成方式：python3 -c 'import secrets; print(secrets.token_urlsafe(32))'，"
                "写入平台根 .env 后重启；使用 ./start.sh 首次生产启动会自动生成。")
        return v
    return v or SESSION_DEV_SECRET


def assert_session_secret_ready() -> None:
    """启动自检（fail-fast）：prod 缺少会话密钥时抛可读 RuntimeError。"""
    session_secret()


# ---------------------------------------------------------------- 会话
def _token_version_of(sub: str) -> int:
    """读取账号当前会话版本；账号不存在/DB 不可用时回退 0（兼容旧库与脚本账号）。"""
    if not sub:
        return 0
    try:
        from . import db
        with db.session() as c:
            r = c.execute("SELECT token_version FROM user WHERE id=?", (sub,)).fetchone()
        return int((r[0] if r is not None and r[0] is not None else 0) or 0)
    except Exception:
        return 0


def bump_token_version(sub: str) -> int:
    """吊销某账号此前签发的全部 JWT：版本 +1 并返回新版本。

    改密、管理员重置、停用/启用、登出都必须调用；旧 token 的 ver 与新值
    不一致后由 server._session_user 统一拒绝（401）。
    """
    if not sub:
        return 0
    from . import db
    with db.session() as c:
        c.execute("UPDATE user SET token_version=COALESCE(token_version,0)+1 WHERE id=?", (sub,))
        r = c.execute("SELECT token_version FROM user WHERE id=?", (sub,)).fetchone()
        c.commit()
    return int((r[0] if r is not None and r[0] is not None else 0) or 0)


def make_session(user: dict, ttl: int = 3600, token_version: int | None = None) -> str:
    sub = user.get("sub", "")
    if token_version is None:
        if user.get("token_version") is not None:
            token_version = int(user.get("token_version") or 0)
        else:
            token_version = _token_version_of(sub)
    return sign_jwt({"sub": sub, "name": user.get("name", ""),
                     "email": user.get("email", ""), "role": user.get("role", "reviewer"),
                     "tenant_id": user.get("tenant_id") or "",
                     "workspace_id": user.get("workspace_id") or "",
                     "must_change_pwd": bool(user.get("must_change_pwd")),
                     "ver": int(token_version or 0),
                     "exp": int(time.time()) + ttl}, session_secret())


def verify_session(token: str) -> dict | None:
    return verify_jwt(token, session_secret())


# ---------------------------------------------------------------- OAuth state（防登录 CSRF/会话固定）
OAUTH_STATE_COOKIE = "rp_oauth_state"
OAUTH_STATE_TTL = 300


def new_oauth_state() -> str:
    import secrets
    return secrets.token_urlsafe(24)


def sign_oauth_state(state: str, ttl: int = OAUTH_STATE_TTL) -> str:
    return sign_jwt({"purpose": "oauth_state", "state": str(state or ""),
                     "exp": int(time.time()) + int(ttl)}, session_secret())


def verify_oauth_state(cookie_value: str, state: str) -> bool:
    """校验 /callback 的 state 与浏览器 cookie 绑定：缺一即拒绝。"""
    if not cookie_value or not state:
        return False
    p = verify_jwt(cookie_value, session_secret())
    if not p or p.get("purpose") != "oauth_state":
        return False
    return hmac.compare_digest(str(p.get("state") or ""), str(state))


def authorization_url(state: str) -> str:
    cfg = oidc_config()
    q = urllib.parse.urlencode({
        "response_type": "code", "client_id": cfg["client_id"],
        "redirect_uri": cfg["redirect_uri"], "scope": "openid profile email", "state": state,
    })
    return f"{cfg['issuer']}/authorize?{q}"


def exchange_code(code: str) -> dict | None:
    """交换授权码 → id_token。

    - 内置 mock（默认）：code 即 client_secret 签名的 JWT，直接校验。
    - 真实 IdP（设置 RULEPROOF_OIDC_REAL=1）：POST {issuer}/token 换 id_token，再做 claims 校验。
    """
    cfg = oidc_config()
    if _is_prod() and os.environ.get("RULEPROOF_OIDC_REAL") != "1":
        # 生产环境绝不允许内置 mock IdP 签发/交换授权码
        return None
    if os.environ.get("RULEPROOF_OIDC_REAL") != "1":
        payload = verify_jwt(code, cfg["client_secret"])
        if not payload:
            return None
        # mock 也必须完整校验 exp/iss/aud，不能因为是内置 IdP 就跳过
        cfg = oidc_config()
        if not payload.get("exp") or payload["exp"] < time.time():
            return None
        if payload.get("iss") != cfg["issuer"]:
            return None
        if payload.get("aud") != cfg["client_id"]:
            return None
        return {"sub": payload.get("sub", ""), "name": payload.get("name", ""),
                "email": payload.get("email", ""), "role": payload.get("role", "reviewer"),
                "id_token": code}
    return exchange_code_real(code)


def exchange_code_real(code: str) -> dict | None:
    """真实 OIDC token 端点交换 + id_token claims 校验（RSA 签名需 cryptography，见 README）。"""
    import urllib.request
    cfg = oidc_config()
    data = urllib.parse.urlencode({
        "grant_type": "authorization_code", "code": code, "redirect_uri": cfg["redirect_uri"],
        "client_id": cfg["client_id"], "client_secret": cfg["client_secret"],
    }).encode()
    req = urllib.request.Request(f"{cfg['issuer']}/token", data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            tokens = json.loads(r.read().decode())
    except Exception:
        return None
    idt = tokens.get("id_token", "")
    return verify_id_token(idt)


def verify_id_token(id_token: str) -> dict | None:
    """校验 id_token：只接受 HS256/RS256 验签，不再降级为未签名 claims。"""
    cfg = oidc_config()
    payload = verify_jwt(id_token, cfg["client_secret"])
    if payload is None:
        payload = verify_rs256_via_jwks(id_token, cfg["issuer"])
    if payload is None:
        # 安全：未签名/签名不匹配的 token 一律拒绝，禁止降级解析
        return None
    # 必要 claims 必须存在且有效；缺失不是“跳过校验”
    if not payload.get("exp") or payload["exp"] < time.time():
        return None
    if not cfg.get("issuer") or payload.get("iss") != cfg["issuer"]:
        return None
    aud = payload.get("aud")
    if isinstance(aud, list):
        if cfg["client_id"] not in aud:
            return None
    elif aud != cfg["client_id"]:
        return None
    return {"sub": payload.get("sub", ""), "name": payload.get("name", ""),
            "email": payload.get("email", ""), "role": payload.get("role", "reviewer"),
            "id_token": id_token}


def fetch_jwks(issuer: str) -> dict:
    """OIDC discovery → jwks_uri → JWKS。"""
    import urllib.request
    cfg_url = issuer.rstrip("/") + "/.well-known/openid-configuration"
    with urllib.request.urlopen(cfg_url, timeout=10) as r:
        cfg = json.loads(r.read().decode())
    with urllib.request.urlopen(cfg["jwks_uri"], timeout=10) as r:
        return json.loads(r.read().decode())


def verify_rs256(token: str, jwks: dict) -> dict | None:
    """RS256 验签（cryptography）。"""
    try:
        from cryptography.hazmat.primitives.asymmetric import rsa, padding
        from cryptography.hazmat.primitives import hashes
        h, p, s = token.split(".")
        header = json.loads(_b64url_dec(h))
        if header.get("alg") != "RS256":
            return None
        sig = _b64url_dec(s)
        data = f"{h}.{p}".encode()
        for key in jwks.get("keys", []):
            if key.get("kty") != "RSA":
                continue
            try:
                n = int.from_bytes(_b64url_dec(key["n"]), "big")
                e = int.from_bytes(_b64url_dec(key["e"]), "big")
                pub = rsa.RSAPublicNumbers(e, n).public_key()
                pub.verify(sig, data, padding.PKCS1v15(), hashes.SHA256())
                return json.loads(_b64url_dec(p))
            except Exception:
                continue
        return None
    except Exception:
        return None


def verify_rs256_via_jwks(id_token: str, issuer: str) -> dict | None:
    try:
        return verify_rs256(id_token, fetch_jwks(issuer))
    except Exception:
        return None


# ===== 本地账号密码（PBKDF2-SHA256，stdlib）=====
import hashlib as _hl
import hmac as _hm
import os as _os


def hash_password(password: str, salt: str = "") -> tuple:
    """返回 (hash_hex, salt_hex)。"""
    if not salt:
        salt = _os.urandom(16).hex()
    dk = _hl.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 100000)
    return dk.hex(), salt


def verify_password(password: str, hash_hex: str, salt: str) -> bool:
    if not hash_hex or not salt:
        return False
    dk, _ = hash_password(password, salt)
    return _hm.compare_digest(dk, hash_hex)


def generate_password(n: int = 10) -> str:
    import secrets
    import string
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(n))
