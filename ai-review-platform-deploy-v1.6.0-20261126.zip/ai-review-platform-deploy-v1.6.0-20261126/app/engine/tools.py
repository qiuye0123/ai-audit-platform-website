"""可复现工具：日期差、金额/税额、汇率换算、节假日/工作日判断。

汇率与节假日日历必须由调用方给出显式来源 + 版本 + 有效期/覆盖期；
缺源、缺版本、过期、未知币种/日期/日历一律返回 insufficient。
工具不联网、不内置汇率或法定节假日数据，也不猜默认来源/默认汇率/默认方向。
"""
from __future__ import annotations
import os
import re
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP


# ---------------------------------------------------------------------------
# L39 执行器 P0 修复统一开关（2026-11-24）
#   RULEPROOF_EXEC_FIXES_V2 默认 1（全部修复生效）；=0 逐项回退（保持历史行为）；
#   也可传逗号分隔的项名列表（仅列表内修复生效，便于单向回滚/定位）。
#   项名见各调用点：fullwidth / temp_negative / time_scale / conc_scale /
#   unit_scale_ext / composite_time / approx / missing_unit / unknown_unit /
#   date_lhs_take / date_nfkc / date_ext_scan / unsupported_type / temp_degree。
# ---------------------------------------------------------------------------
EXEC_FIXES_V2_ENV = "RULEPROOF_EXEC_FIXES_V2"


def exec_fix_v2(item: str = "") -> bool:
    """执行器 P0 修复开关：默认开；``RULEPROOF_EXEC_FIXES_V2=0`` 全部回退。

    - ``1`` / 空 / true / on  → 全部修复生效（默认）
    - ``0`` / false / off     → 全部回退（历史行为）
    - 逗号列表（如 ``approx,date_lhs_take``）→ 仅列出的项生效
    """
    raw = str(os.environ.get(EXEC_FIXES_V2_ENV, "1")).strip().lower()
    if raw in ("", "1", "true", "on", "yes", "all"):
        return True
    if raw in ("0", "false", "off", "no", "none"):
        return False
    enabled = {x.strip() for x in raw.split(",") if x.strip()}
    return bool(item) and item in enabled


# ---------------------------------------------------------------------------
# L42 执行器对象绑定/作用域修复统一开关（2026-11-24）
#   RULEPROOF_EXEC_FIXES_V3 默认 1（全部修复生效）；=0 逐项回退；
#   也可传逗号分隔项名列表（仅列表内生效）。项名：
#   object_bind   文本路径对象绑定（同一 metric 多对象取值不得合并判定）
#   scope_text    文本路径作用域过滤（与事实路径 :scope 同口径，过滤后为空不静默丢）
#   quote_short   证据门禁：逐字短引文（含数字/单位）只按逐字命中判定，不因 <4 字降级
#   date_det      criterion 无 metric 的结构化关系算子（含 date）走确定性执行，不进语义分支
#   mi_generic    非白名单码逐行实例物化（按 L19 独立实例口径，引文带行上下文）
#   unit_vocab    单位词表补 件/次/秒（取数引文包含单位；计数单位可比较）
# ===========================================================================
EXEC_FIXES_V3_ENV = "RULEPROOF_EXEC_FIXES_V3"


def exec_fix_v3(item: str = "") -> bool:
    """执行器对象绑定修复开关：默认开；``RULEPROOF_EXEC_FIXES_V3=0`` 全部回退。

    - ``1`` / 空 / true / on  → 全部修复生效（默认）
    - ``0`` / false / off     → 全部回退（历史行为）
    - 逗号列表（如 ``object_bind,unit_vocab``）→ 仅列出的项生效
    """
    raw = str(os.environ.get(EXEC_FIXES_V3_ENV, "1")).strip().lower()
    if raw in ("", "1", "true", "on", "yes", "all"):
        return True
    if raw in ("0", "false", "off", "no", "none"):
        return False
    enabled = {x.strip() for x in raw.split(",") if x.strip()}
    return bool(item) and item in enabled


def _d(v):
    try:
        s = str(v or "").strip()
        if not s:
            return None
        for _a, _b in (("年", "-"), ("月", "-"), ("日", ""), ("/", "-"), (".", "-")):
            s = s.replace(_a, _b)
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except Exception:
        return None


def date_diff(start, end, calendar: str = "natural", include_start: bool = False,
              include_end: bool = True, calendar_data=None, calendar_source: str = "",
              calendar_version: str = "", holidays=None, makeup_workdays=None,
              coverage_start: str = "", coverage_end: str = "",
              calendar_year="", weekend_days=None) -> dict:
    """日期差：natural=自然日；business=仅周一至周五（旧口径，向后兼容）；
    workday=按显式法定节假日日历计算工作日（缺源/缺版本/超覆盖期→insufficient）。

    business 在同时提供日历数据时也走节假日口径；workday 必须提供日历。
    默认口径为“含截止日、不含起算日”，与旧版一致；calendar 传日历对象时按 workday 处理。
    """
    if isinstance(calendar, dict):
        calendar_data = calendar_data if calendar_data is not None else calendar
        calendar = "workday"
    mode = str(calendar or "natural").strip().lower()
    trace = {"tool": "date_diff", "start": start, "end": end, "calendar": mode,
             "include_start": include_start, "include_end": include_end}
    a, b = _d(start), _d(end)
    if not a or not b:
        return {"ok": False, "status": "insufficient", "code": "missing_input",
                "reason": "起算日或截止日缺失/不可解析", "trace": trace}
    if b < a:
        return {"ok": False, "status": "failed", "code": "end_before_start",
                "reason": "截止日早于起算日", "trace": trace}
    if mode in ("", "natural", "calendar", "自然日", "日历日"):
        days = (b - a).days
        if include_start:
            days += 1
        if not include_end:
            days = max(0, days - 1)
        trace["calendar_basis"] = "natural"
        return {"ok": True, "status": "pass", "code": "ok", "days": days,
                "calendar_basis": "natural", "trace": trace}
    if mode not in ("business", "weekday", "business_day", "workday", "工作日",
                    "holiday", "holiday_calendar"):
        return {"ok": False, "status": "insufficient", "code": "calendar_unknown",
                "reason": f"未知日期口径：{calendar}", "trace": trace}
    has_calendar = (calendar_data is not None or str(calendar_source or "").strip()
                    or str(calendar_version or "").strip() or holidays is not None
                    or makeup_workdays is not None or str(coverage_start or "").strip()
                    or str(coverage_end or "").strip() or calendar_year not in (None, "")
                    or weekend_days is not None)
    if mode in ("business", "weekday", "business_day") and not has_calendar:
        # 旧口径：只按周一至周五；trace 明确标注，不冒充法定节假日日历
        n, cur = 0, a
        while cur <= b:
            if cur.weekday() < 5:
                n += 1
            cur += timedelta(days=1)
        if not include_start and a.weekday() < 5:
            n -= 1
        if not include_end and b.weekday() < 5:
            n -= 1
        trace.update({"calendar_basis": "weekday_only", "calendar_source": "",
                      "calendar_version": "",
                      "warnings": ["未提供法定节假日日历，仅按周一至周五计算"]})
        return {"ok": True, "status": "pass", "code": "ok", "days": max(0, n),
                "calendar_basis": "weekday_only", "trace": trace}
    cal = _calendar_spec(calendar_data=calendar_data, calendar_source=calendar_source,
                         calendar_version=calendar_version, holidays=holidays,
                         makeup_workdays=makeup_workdays, coverage_start=coverage_start,
                         coverage_end=coverage_end, calendar_year=calendar_year,
                         weekend_days=weekend_days)
    if not cal.get("ok"):
        cal.setdefault("trace", {})["tool"] = "date_diff"
        cal["trace"].update({"start": start, "end": end, "calendar": mode})
        return cal
    base_trace = {**trace, **_calendar_trace(cal), "calendar_basis": "holiday_calendar"}
    if a < cal["coverage_start"]:
        return {"ok": False, "status": "insufficient", "code": "calendar_out_of_range",
                "reason": f"起算日 {a} 早于日历覆盖期 {cal['coverage_start']}",
                "trace": base_trace}
    if b > cal["coverage_end"]:
        return {"ok": False, "status": "insufficient", "code": "calendar_expired",
                "reason": f"截止日 {b} 超出日历覆盖期 {cal['coverage_end']}（日历过期/未覆盖）",
                "trace": base_trace}
    if (b - a).days > 366 * 200:
        return {"ok": False, "status": "failed", "code": "range_too_large",
                "reason": "日期范围过大，拒绝计算", "trace": trace}
    n, cur = 0, a
    while cur <= b:
        if _is_workday(cur, cal):
            n += 1
        cur += timedelta(days=1)
    if not include_start and _is_workday(a, cal):
        n -= 1
    if not include_end and _is_workday(b, cal):
        n -= 1
    base_trace.update({
        "holidays_applied": [x.isoformat() for x in sorted(cal["holidays"]) if a <= x <= b],
        "makeup_workdays_applied": [x.isoformat() for x in sorted(cal["makeup_workdays"])
                                    if a <= x <= b]})
    return {"ok": True, "status": "pass", "code": "ok", "days": max(0, n),
            "calendar_basis": "holiday_calendar", "trace": base_trace}


# ---------------------------------------------------------------------------
# 节假日/工作日日历（显式来源 + 版本 + 覆盖期，不内置任何法定节假日数据）
# ---------------------------------------------------------------------------

def _calendar_spec(calendar_data=None, calendar_source: str = "", calendar_version: str = "",
                   holidays=None, makeup_workdays=None, coverage_start: str = "",
                   coverage_end: str = "", calendar_year="", weekend_days=None) -> dict:
    """归一化显式日历输入；缺源/缺版本/缺覆盖期/缺节假日清单都返回 insufficient。

    calendar_data 结构：source、version、year 或 coverage_start/coverage_end、
    holidays（必填，无节假日传 []）、makeup_workdays（调休上班日）、weekend_days。
    顶层同名参数优先；不根据 holidays 推断覆盖期，也不补默认节假日。
    """
    if calendar_data is not None and not isinstance(calendar_data, dict):
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": "calendar_data 必须是含 source/version/holidays/coverage 的对象",
                "trace": {"calendar_data": type(calendar_data).__name__}}
    data = calendar_data or {}
    src = str(calendar_source or data.get("source") or "").strip()
    ver = str(calendar_version or data.get("version") or "").strip()
    trace = {"calendar_source": src, "calendar_version": ver}
    if not src:
        return {"ok": False, "status": "insufficient", "code": "calendar_source_unknown",
                "reason": "缺少日历来源 calendar_source，不能猜", "trace": trace}
    if not ver:
        return {"ok": False, "status": "insufficient", "code": "calendar_version_unknown",
                "reason": "缺少日历版本 calendar_version，不能猜", "trace": trace}
    cs_raw = coverage_start or data.get("coverage_start") or ""
    ce_raw = coverage_end or data.get("coverage_end") or ""
    year_raw = calendar_year if calendar_year not in (None, "") else (
        data.get("year") or data.get("calendar_year") or "")
    if not str(cs_raw).strip() and not str(ce_raw).strip() and str(year_raw).strip():
        y = str(year_raw).strip()
        if not re.fullmatch(r"\d{4}", y):
            return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                    "reason": f"日历年不可解析：{year_raw}", "trace": trace}
        cs_raw, ce_raw = f"{y}-01-01", f"{y}-12-31"
    cs, ce = _d(cs_raw), _d(ce_raw)
    if not cs or not ce:
        return {"ok": False, "status": "insufficient", "code": "calendar_coverage_unknown",
                "reason": "缺少完整日历覆盖期 coverage_start/coverage_end（或仅给 calendar_year）",
                "trace": trace}
    trace.update({"coverage_start": str(cs), "coverage_end": str(ce)})
    if ce < cs:
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": "日历覆盖期起止倒置", "trace": trace}
    hol = holidays if holidays is not None else data.get("holidays")
    if hol is None:
        return {"ok": False, "status": "insufficient", "code": "holidays_unknown",
                "reason": "缺少法定节假日清单 holidays（无节假日也必须显式给出 []）",
                "trace": trace}
    if not isinstance(hol, (list, tuple, set)):
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": "holidays 必须是日期数组", "trace": trace}
    mk = makeup_workdays
    if mk is None:
        mk = data.get("makeup_workdays")
    if mk is None:
        mk = data.get("workdays")
    if mk is None:
        mk = []
    if not isinstance(mk, (list, tuple, set)):
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": "makeup_workdays 必须是日期数组", "trace": trace}
    wd = weekend_days if weekend_days is not None else data.get("weekend_days")
    if wd is None:
        wd = [5, 6]
    try:
        wd = sorted({int(x) for x in wd})
    except Exception:
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": "weekend_days 必须是 0-6 的整数数组", "trace": trace}
    if any(x < 0 or x > 6 for x in wd):
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": "weekend_days 必须是 0-6 的整数数组（可为空=无周末）", "trace": trace}

    def _parse_dates(vals, name):
        out = set()
        for x in vals:
            dd = _d(x)
            if dd is None:
                return None, f"{name} 含不可解析日期：{x}"
            if dd < cs or dd > ce:
                return None, f"{name} 日期 {dd} 超出覆盖期 {cs}~{ce}"
            out.add(dd)
        return out, ""

    hs, err = _parse_dates(hol, "holidays")
    if hs is None:
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": err, "trace": trace}
    ms, err = _parse_dates(mk, "makeup_workdays")
    if ms is None:
        return {"ok": False, "status": "failed", "code": "bad_calendar_data",
                "reason": err, "trace": trace}
    conflict = hs & ms
    if conflict:
        return {"ok": False, "status": "insufficient", "code": "calendar_conflict",
                "reason": "同一日期同时标为节假日与调休上班日："
                          + ",".join(sorted(x.isoformat() for x in conflict)),
                "trace": trace}
    return {"ok": True, "source": src, "version": ver, "coverage_start": cs,
            "coverage_end": ce, "holidays": hs, "makeup_workdays": ms,
            "weekend_days": wd,
            "trace": {"calendar_source": src, "calendar_version": ver,
                      "coverage_start": str(cs), "coverage_end": str(ce),
                      "weekend_days": wd, "holidays_count": len(hs),
                      "makeup_workdays_count": len(ms)}}


def _calendar_trace(cal: dict) -> dict:
    return {"calendar_source": cal["source"], "calendar_version": cal["version"],
            "coverage_start": str(cal["coverage_start"]),
            "coverage_end": str(cal["coverage_end"]),
            "weekend_days": cal["weekend_days"],
            "holidays_count": len(cal["holidays"]),
            "makeup_workdays_count": len(cal["makeup_workdays"])}


def _workday_flags(day: date, cal: dict) -> dict:
    is_weekend = day.weekday() in cal["weekend_days"]
    is_holiday = day in cal["holidays"]
    is_makeup = day in cal["makeup_workdays"]
    is_workday = (not is_holiday) and (is_makeup or not is_weekend)
    if is_holiday:
        day_type = "holiday"
    elif is_makeup:
        day_type = "makeup_workday"
    elif is_weekend:
        day_type = "weekend"
    else:
        day_type = "workday"
    return {"is_workday": is_workday, "is_holiday": is_holiday,
            "is_weekend": is_weekend, "is_makeup_workday": is_makeup,
            "is_non_workday": not is_workday, "day_type": day_type}


def _is_workday(day: date, cal: dict) -> bool:
    return _workday_flags(day, cal)["is_workday"]


def workday_check(day, calendar_data=None, calendar_source: str = "",
                  calendar_version: str = "", holidays=None, makeup_workdays=None,
                  coverage_start: str = "", coverage_end: str = "",
                  calendar_year="", weekend_days=None) -> dict:
    """判断某日是否工作日/节假日：必须给显式日历来源、版本与覆盖期。"""
    trace = {"tool": "workday_check", "day": day}
    if str(day if day is not None else "").strip() == "":
        return {"ok": False, "status": "insufficient", "code": "missing_input",
                "reason": "缺少待判断日期", "trace": trace}
    d = _d(day)
    if not d:
        return {"ok": False, "status": "insufficient", "code": "missing_input",
                "reason": "日期缺失/不可解析", "trace": trace}
    cal = _calendar_spec(calendar_data=calendar_data, calendar_source=calendar_source,
                         calendar_version=calendar_version, holidays=holidays,
                         makeup_workdays=makeup_workdays, coverage_start=coverage_start,
                         coverage_end=coverage_end, calendar_year=calendar_year,
                         weekend_days=weekend_days)
    if not cal.get("ok"):
        cal.setdefault("trace", {})["tool"] = "workday_check"
        return cal
    if d < cal["coverage_start"]:
        return {"ok": False, "status": "insufficient", "code": "calendar_out_of_range",
                "reason": f"日期 {d} 早于日历覆盖期 {cal['coverage_start']}",
                "trace": {**trace, **_calendar_trace(cal)}}
    if d > cal["coverage_end"]:
        return {"ok": False, "status": "insufficient", "code": "calendar_expired",
                "reason": f"日期 {d} 超出日历覆盖期 {cal['coverage_end']}（日历过期/未覆盖）",
                "trace": {**trace, **_calendar_trace(cal)}}
    flags = _workday_flags(d, cal)
    trace.update({**_calendar_trace(cal), **flags, "day": str(d)})
    return {"ok": True, "status": "pass", "code": "ok", "value": flags["day_type"],
            **flags, "trace": trace}


def workday_diff(start, end, include_start: bool = False, include_end: bool = True,
                 **calendar_kwargs) -> dict:
    """严格工作日差：必须提供显式节假日日历；等价 date_diff(..., calendar="workday")。"""
    _cal = calendar_kwargs.pop("calendar", None)
    if isinstance(_cal, dict) and calendar_kwargs.get("calendar_data") is None:
        calendar_kwargs["calendar_data"] = _cal
    return date_diff(start, end, "workday", include_start, include_end, **calendar_kwargs)


# ---------------------------------------------------------------------------
# 汇率换算（显式来源 + 版本 + 报价日 + 适用期，不联网、不内置汇率、不猜方向）
# ---------------------------------------------------------------------------

# ISO 4217 常用币种代码白名单（只校验币种代码，不含任何汇率数据）；
# 别名只做确定性归一，未列出的代码一律 currency_unknown，不猜。
_CCY_ALIASES = {
    "人民币": "CNY", "元": "CNY", "rmb": "CNY", "cny": "CNY", "¥": "CNY", "￥": "CNY",
    "美元": "USD", "美金": "USD", "usd": "USD", "$": "USD",
    "欧元": "EUR", "eur": "EUR", "€": "EUR",
    "港币": "HKD", "港元": "HKD", "hkd": "HKD",
    "日元": "JPY", "日圆": "JPY", "jpy": "JPY",
    "英镑": "GBP", "gbp": "GBP",
    "澳元": "AUD", "aud": "AUD", "加元": "CAD", "cad": "CAD",
    "新加坡元": "SGD", "新元": "SGD", "sgd": "SGD",
    "瑞士法郎": "CHF", "chf": "CHF", "韩元": "KRW", "krw": "KRW",
    "新台币": "TWD", "twd": "TWD", "澳门元": "MOP", "mop": "MOP",
    "泰铢": "THB", "thb": "THB", "林吉特": "MYR", "myr": "MYR",
}
_SUPPORTED_CCY = frozenset({
    "CNY", "USD", "EUR", "HKD", "JPY", "GBP", "AUD", "CAD", "SGD", "CHF",
    "KRW", "TWD", "MOP", "THB", "MYR", "NZD", "SEK", "NOK", "DKK", "RUB",
    "INR", "BRL", "ZAR", "AED", "SAR", "MXN", "IDR", "PHP", "VND", "TRY",
})


def _ccy(v) -> str:
    s = str(v if v is not None else "").strip()
    if not s:
        return ""
    return _CCY_ALIASES.get(s.lower(), "") or (s.upper() if s.upper() in _SUPPORTED_CCY else "")


def _decimal(v) -> Decimal:
    s = str(v if v is not None else "").strip()
    for _a, _b in ((",", ""), ("，", ""), ("¥", ""), ("￥", "")):
        s = s.replace(_a, _b)
    return Decimal(s)


def _fx_direction(v) -> str:
    x = str(v or "").strip().lower().replace(" ", "")
    if x in ("from_to", "from-to", "from->to", "multiply", "mul", "乘", "1from=rateto"):
        return "from_to"
    if x in ("to_from", "to-from", "to->from", "divide", "div", "除", "1to=ratefrom"):
        return "to_from"
    return ""


def _rate_pair(v):
    s = str(v or "").strip().upper().replace(" ", "")
    m = re.fullmatch(r"([A-Z]{3})[/:]([A-Z]{3})", s)
    if not m:
        return None, f"汇率对不可解析：{v}（应形如 USD/CNY）"
    return (m.group(1), m.group(2)), ""


def fx_convert(amount, from_currency, to_currency, rate=None, rate_source: str = "",
               rate_version: str = "", rate_date: str = "", as_of: str = "",
               valid_until: str = "", max_age_days=None, rate_direction: str = "",
               rate_pair: str = "", quantize: str = "0.01") -> dict:
    """汇率换算：原币×/÷显式汇率；必须带来源、版本、报价日与适用期。

    rate 的方向不能默认：用 rate_direction=from_to（1 原币=rate 目标币）或
    to_from（1 目标币=rate 原币），也可用 rate_pair=USD/CNY 声明。
    缺来源/版本/汇率/报价日/适用日/有效期，已过期/未生效，未知币种 → insufficient。
    """
    trace = {"tool": "fx_convert", "amount": str(amount), "from_currency": from_currency,
             "to_currency": to_currency, "rate": str(rate), "rate_source": rate_source,
             "rate_version": rate_version, "rate_date": rate_date, "as_of": as_of,
             "valid_until": valid_until, "max_age_days": max_age_days,
             "rate_direction": rate_direction, "rate_pair": rate_pair, "quantize": quantize}

    def _out(code, reason, status="insufficient"):
        return {"ok": False, "status": status, "code": code, "reason": reason, "trace": trace}

    if str(amount if amount is not None else "").strip() == "":
        return _out("missing_input", "缺少待换算金额")
    try:
        amt = _decimal(amount)
    except Exception as e:
        return _out("bad_amount", f"金额不可解析：{type(e).__name__}", "failed")
    if not amt.is_finite():
        return _out("bad_amount", "金额必须是有限数", "failed")
    f, t = _ccy(from_currency), _ccy(to_currency)
    if not f or not t:
        return _out("currency_unknown", "币种缺失或未知，不能默认人民币")
    trace.update({"from_currency": f, "to_currency": t})
    try:
        q = Decimal(str(quantize))
        if q <= 0:
            raise ValueError
    except Exception:
        return _out("bad_quantize", "舍入位数不可解析", "failed")
    if f == t:
        try:
            v = amt.quantize(q, rounding=ROUND_HALF_UP)
        except Exception as e:
            return _out("tool_error", f"{type(e).__name__}: {e}", "failed")
        trace.update({"identity": True, "rate_used": "1"})
        return {"ok": True, "status": "pass", "code": "ok", "value": str(v),
                "converted": str(v), "identity": True, "trace": trace}
    src = str(rate_source or "").strip()
    ver = str(rate_version or "").strip()
    if not src:
        return _out("rate_source_unknown", "缺少汇率来源 rate_source，不能猜")
    if not ver:
        return _out("rate_version_unknown", "缺少汇率版本 rate_version，不能猜")
    if rate is None or str(rate).strip() == "":
        return _out("rate_unknown", "缺少汇率，不能猜")
    try:
        r = _decimal(rate)
    except Exception as e:
        return _out("bad_rate", f"汇率不可解析：{type(e).__name__}", "failed")
    if not r.is_finite() or r <= 0:
        return _out("bad_rate", "汇率必须是大于 0 的有限数", "failed")
    if str(rate_date or "").strip() == "":
        return _out("rate_date_unknown", "缺少汇率报价日 rate_date，无法判断时效")
    rd = _d(rate_date)
    if not rd:
        return _out("bad_date", "汇率报价日不可解析", "failed")
    direction, pair = "", None
    pair_raw = str(rate_pair or "").strip()
    if pair_raw:
        pair, perr = _rate_pair(pair_raw)
        if perr:
            return _out("bad_rate_pair", perr, "failed")
        base, quote = pair
        if not _ccy(base) or not _ccy(quote):
            return _out("currency_unknown", f"汇率对含未知币种：{pair_raw}")
        if {f, t} != {_ccy(base), _ccy(quote)}:
            return _out("rate_pair_mismatch",
                        f"汇率对 {base}/{quote} 与换算币种 {f}->{t} 不匹配")
        direction = "from_to" if (f == _ccy(base) and t == _ccy(quote)) else "to_from"
        d2 = _fx_direction(rate_direction)
        if str(rate_direction or "").strip() and not d2:
            return _out("bad_rate_direction", f"未知汇率方向：{rate_direction}", "failed")
        if d2 and d2 != direction:
            return _out("rate_direction_conflict", "rate_direction 与 rate_pair 方向冲突")
    else:
        direction = _fx_direction(rate_direction)
        if not direction:
            return _out("rate_direction_unknown", "未声明汇率方向，不能默认乘或除")
    if str(as_of or "").strip() == "":
        return _out("as_of_unknown", "缺少汇率适用日 as_of，无法判断是否过期")
    ao = _d(as_of)
    if not ao:
        return _out("bad_date", "汇率适用日不可解析", "failed")
    vu = None
    if str(valid_until or "").strip():
        vu = _d(valid_until)
        if not vu:
            return _out("bad_date", "汇率有效期 valid_until 不可解析", "failed")
        if vu < rd:
            return _out("bad_validity", "汇率有效期早于报价日", "failed")
    max_age = None
    if max_age_days is not None and str(max_age_days).strip() != "":
        try:
            max_age = int(str(max_age_days).strip())
            if max_age < 0:
                raise ValueError
        except Exception:
            return _out("bad_validity", "max_age_days 必须是非负整数", "failed")
    if vu is None and max_age is None:
        return _out("rate_validity_unknown", "缺少汇率有效期/最大时效，无法判断是否过期")
    if ao < rd:
        return _out("rate_not_yet_effective", f"适用日 {ao} 早于汇率报价日 {rd}")
    if vu is not None and ao > vu:
        return _out("rate_expired", f"汇率已于 {vu} 过期（适用日 {ao}）")
    if max_age is not None and (ao - rd).days > max_age:
        return _out("rate_expired",
                    f"汇率报价日 {rd} 距适用日 {ao} 已 {(ao - rd).days} 天，超过 {max_age} 天")
    try:
        raw = amt * r if direction == "from_to" else amt / r
        converted = raw.quantize(q, rounding=ROUND_HALF_UP)
    except Exception as e:
        return _out("tool_error", f"{type(e).__name__}: {e}", "failed")
    trace.update({"rate": str(r), "rate_date": str(rd), "as_of": str(ao),
                  "valid_until": str(vu) if vu else "", "max_age_days": max_age,
                  "rate_direction": direction,
                  "rate_pair": f"{pair[0]}/{pair[1]}" if pair else "",
                  "rate_source": src, "rate_version": ver,
                  "formula": f"{amt} × {r}" if direction == "from_to" else f"{amt} ÷ {r}"})
    return {"ok": True, "status": "pass", "code": "ok", "value": str(converted),
            "converted": str(converted), "rate": str(r), "from_currency": f,
            "to_currency": t, "rate_direction": direction, "rate_source": src,
            "rate_version": ver, "rate_date": str(rd), "as_of": str(ao),
            "valid_until": str(vu) if vu else "", "trace": trace}


_DATE_RE = __import__("re").compile(r"(20\d{2})\s*[-/年.]\s*(\d{1,2})\s*[-/月.]\s*(\d{1,2})")


def extract_labeled_date(text: str, label: str) -> dict:
    """按标签同行/邻近取日期；找不到返回 missing_input，不猜首尾日期。"""
    text = str(text or "")
    if not label:
        return {"ok": False, "code": "missing_label", "value": "", "trace": {"tool": "date_extract", "label": label}}
    for line in text.splitlines():
        if label in line:
            m = _DATE_RE.search(line)
            if m:
                return {"ok": True, "code": "ok", "value": f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}",
                        "trace": {"tool": "date_extract", "label": label, "line": line.strip()[:120]}}
    return {"ok": False, "code": "missing_input", "value": "",
            "trace": {"tool": "date_extract", "label": label, "line": ""}}


_AMOUNT_RE = __import__("re").compile(
    r"([¥￥]?)\s*([0-9][0-9,，]*(?:\.[0-9]+)?)\s*(万元|万|元|CNY|USD|HKD|EUR)?")
_CURRENCY = {"¥": "CNY", "￥": "CNY", "元": "CNY", "CNY": "CNY",
             "USD": "USD", "HKD": "HKD", "EUR": "EUR"}


def extract_labeled_amount(text: str, label: str) -> dict:
    text = str(text or "")
    if not label:
        return {"ok": False, "code": "missing_label", "trace": {"tool": "amount_extract", "label": label}}
    for line in text.splitlines():
        if label in line:
            m = _AMOUNT_RE.search(line.split(label, 1)[1])
            if m:
                raw, unit = m.group(2), (m.group(3) or "")
                try:
                    val = Decimal(raw.replace(",", "").replace("，", ""))
                except Exception:
                    return {"ok": False, "code": "bad_amount", "trace": {"tool": "amount_extract", "line": line}}
                if unit in ("万元", "万"):
                    val *= Decimal("10000")
                cur = _CURRENCY.get(m.group(1) or "") or _CURRENCY.get(unit) or ""
                tax = None
                if "含税" in line:
                    tax = True
                elif "不含税" in line or "未税" in line:
                    tax = False
                return {"ok": True, "code": "ok", "value": str(val), "currency": cur, "tax_included": tax,
                        "trace": {"tool": "amount_extract", "label": label, "line": line.strip()[:160],
                                  "raw": m.group(0)}}
    return {"ok": False, "code": "missing_input", "trace": {"tool": "amount_extract", "label": label, "line": ""}}


def money_compare(amount, threshold, op: str = "<=", currency: str = "",
                  want_currency: str = "", tax_included=None, want_tax_included=None,
                  quantize: str = "0.01") -> dict:
    trace = {"tool": "money_compare", "amount": str(amount), "threshold": str(threshold),
             "op": op, "currency": currency, "want_currency": want_currency,
             "tax_included": tax_included, "want_tax_included": want_tax_included}
    try:
        a, t = Decimal(str(amount)), Decimal(str(threshold))
    except Exception as e:
        return {"ok": False, "status": "failed", "code": "tool_error",
                "reason": f"{type(e).__name__}: {e}", "trace": trace}
    if want_currency and not currency:
        return {"ok": False, "status": "insufficient", "code": "currency_unknown",
                "reason": "未识别币种，不能默认人民币", "trace": trace}
    if want_currency and currency and currency != want_currency:
        return {"ok": False, "status": "insufficient", "code": "currency_mismatch",
                "reason": f"币种不匹配：{currency} != {want_currency}", "trace": trace}
    if want_tax_included is not None and tax_included is None:
        return {"ok": False, "status": "insufficient", "code": "tax_status_unknown",
                "reason": "未识别含税/不含税口径", "trace": trace}
    if want_tax_included is not None and tax_included != want_tax_included:
        return {"ok": False, "status": "insufficient", "code": "tax_status_mismatch",
                "reason": "含税口径不匹配", "trace": trace}
    ok = {"<=": a <= t, ">=": a >= t, "<": a < t, ">": a > t,
          "=": a == t, "!=": a != t}.get(op)
    if ok is None:
        return {"ok": False, "status": "failed", "code": "bad_operator", "trace": trace}
    trace["normalized_amount"] = str(a.quantize(Decimal(quantize)))
    return {"ok": True, "status": "pass" if ok else "fail", "code": "ok",
            "value": str(a), "trace": trace}


def tax_convert(amount, rate, direction: str = "net_to_gross", quantize: str = "0.01") -> dict:
    """金额税额：不含税→含税 / 含税→不含税，Decimal + 明确舍入。"""
    trace = {"tool": "tax_convert", "amount": str(amount), "rate": str(rate),
             "direction": direction, "quantize": quantize}
    try:
        a = Decimal(str(amount)); r = Decimal(str(rate))
        if r > 1:
            r = r / Decimal("100")
        q = Decimal(quantize)
        if direction in ("net_to_gross", "不含税转含税", "exclusive_to_inclusive"):
            net = a.quantize(q, rounding=ROUND_HALF_UP)
            tax = (net * r).quantize(q, rounding=ROUND_HALF_UP)
            gross = (net + tax).quantize(q, rounding=ROUND_HALF_UP)
        elif direction in ("gross_to_net", "含税转不含税", "inclusive_to_exclusive"):
            gross = a.quantize(q, rounding=ROUND_HALF_UP)
            net = (gross / (Decimal("1") + r)).quantize(q, rounding=ROUND_HALF_UP)
            tax = (gross - net).quantize(q, rounding=ROUND_HALF_UP)
        else:
            return {"ok": False, "status": "failed", "code": "bad_direction",
                    "reason": f"未知方向：{direction}", "trace": trace}
        trace.update({"net": str(net), "tax": str(tax), "gross": str(gross), "rate_normalized": str(r)})
        return {"ok": True, "status": "pass", "code": "ok", "net": str(net), "tax": str(tax),
                "gross": str(gross), "value": str(gross), "trace": trace}
    except Exception as e:
        return {"ok": False, "status": "failed", "code": "tool_error",
                "reason": f"{type(e).__name__}: {e}", "trace": trace}


def tax_compare(amount, rate, direction: str = "", selector: str = "gross",
                threshold="", op: str = "<=", quantize: str = "0.01",
                rate_source: str = "", tax_status_source: str = "",
                direction_source: str = "", currency_source: str = "") -> dict:
    """税额换算后按 gross/net/tax 参与阈值比较；税率/方向/来源缺失显式报错。"""
    if rate in (None, ""):
        return {"ok": False, "status": "insufficient", "code": "rate_unknown",
                "reason": "缺少税率，不能默认 13%", "trace": {"tool": "tax_compare", "rate": rate}}
    if not direction:
        return {"ok": False, "status": "insufficient", "code": "direction_unknown",
                "reason": "缺少含税/不含税方向，不能默认 net_to_gross",
                "trace": {"tool": "tax_compare", "direction": direction}}
    c = tax_convert(amount, rate, direction, quantize)
    if not c.get("ok"):
        return c
    sel = str(selector or "gross")
    if sel not in ("gross", "net", "tax"):
        return {"ok": False, "status": "failed", "code": "bad_selector",
                "reason": f"未知选择：{sel}", "trace": c.get("trace")}
    try:
        v = Decimal(str(c[sel])); t = Decimal(str(threshold))
    except Exception as e:
        return {"ok": False, "status": "failed", "code": "tool_error",
                "reason": f"{type(e).__name__}: {e}", "trace": c.get("trace")}
    ok = {"<=": v <= t, ">=": v >= t, "<": v < t, ">": v > t, "=": v == t, "!=": v != t}.get(op)
    if ok is None:
        return {"ok": False, "status": "failed", "code": "bad_operator", "trace": c.get("trace")}
    tr = {**(c.get("trace") or {}), "tool": "tax_compare", "selector": sel,
          "rate_source": rate_source or "", "tax_status_source": tax_status_source or "",
          "direction_source": direction_source or "", "currency_source": currency_source or "",
          "selected_value": str(v), "threshold": str(t), "op": op,
          "result": "pass" if ok else "fail"}
    return {"ok": True, "status": "pass" if ok else "fail", "code": "ok",
            "value": str(v), "net": c["net"], "tax": c["tax"], "gross": c["gross"], "trace": tr}


def money_sum(values: list, quantize: str = "0.01") -> dict:
    trace = {"tool": "money_sum", "values": values, "quantize": quantize}
    try:
        total = sum((Decimal(str(x)) for x in values), Decimal("0"))
        return {"ok": True, "status": "pass", "code": "ok",
                "total": str(total.quantize(Decimal(quantize), rounding=ROUND_HALF_UP)),
                "trace": trace}
    except Exception as e:
        return {"ok": False, "status": "failed", "code": "tool_error",
                "reason": f"{type(e).__name__}: {e}", "trace": trace}


def money_diff(a, b, quantize: str = "0.01") -> dict:
    try:
        x, y = Decimal(str(a)), Decimal(str(b))
        return {"ok": True, "status": "pass", "code": "ok",
                "diff": str((x - y).quantize(Decimal(quantize), rounding=ROUND_HALF_UP)),
                "trace": {"tool": "money_diff", "a": str(a), "b": str(b), "quantize": quantize}}
    except Exception as e:
        return {"ok": False, "status": "failed", "code": "tool_error",
                "reason": f"{type(e).__name__}: {e}",
                "trace": {"tool": "money_diff", "a": str(a), "b": str(b)}}


def _calendar_kwargs(sub: dict) -> dict:
    """从规则 JSON 取显式日历字段；calendar 本身可以是日历对象。"""
    cal = sub.get("calendar_data")
    if cal is None and isinstance(sub.get("calendar"), dict):
        cal = sub.get("calendar")
    mk = sub.get("makeup_workdays")
    if mk is None:
        mk = sub.get("workdays")
    return {"calendar_data": cal,
            "calendar_source": sub.get("calendar_source") or "",
            "calendar_version": sub.get("calendar_version") or "",
            "holidays": sub.get("holidays"),
            "makeup_workdays": mk,
            "coverage_start": sub.get("coverage_start") or "",
            "coverage_end": sub.get("coverage_end") or "",
            "calendar_year": sub.get("calendar_year", sub.get("year", "")),
            "weekend_days": sub.get("weekend_days")}


def run(sub: dict) -> dict:
    sub = sub or {}
    t = str(sub.get("tool") or "")
    if t in ("date_diff", "workday_diff"):
        mode = sub.get("calendar") or "natural"
        if t == "workday_diff":
            mode = "workday"
        return date_diff(sub.get("start"), sub.get("end"), mode,
                         bool(sub.get("include_start")), bool(sub.get("include_end", True)),
                         **_calendar_kwargs(sub))
    if t in ("workday_check", "holiday_check"):
        return workday_check(sub.get("day") or sub.get("date"), **_calendar_kwargs(sub))
    if t in ("fx_convert", "currency_convert"):
        return fx_convert(sub.get("amount"), sub.get("from_currency") or sub.get("from"),
                          sub.get("to_currency") or sub.get("to"), sub.get("rate"),
                          sub.get("rate_source") or "", sub.get("rate_version") or "",
                          sub.get("rate_date") or "",
                          sub.get("as_of") or sub.get("on_date") or "",
                          sub.get("valid_until") or sub.get("expires_on") or "",
                          sub.get("max_age_days"), sub.get("rate_direction") or "",
                          sub.get("rate_pair") or "", sub.get("quantize") or "0.01")
    if t == "money_sum":
        return money_sum(sub.get("values") or [], sub.get("quantize") or "0.01")
    if t == "money_diff":
        return money_diff(sub.get("a"), sub.get("b"), sub.get("quantize") or "0.01")
    if t == "tax_compare":
        return tax_compare(sub.get("amount"), sub.get("rate"), sub.get("direction") or "",
                           sub.get("selector") or "gross", sub.get("threshold"), sub.get("op") or "<=",
                           sub.get("quantize") or "0.01", sub.get("rate_source") or "",
                           sub.get("tax_status_source") or "", sub.get("direction_source") or "",
                           sub.get("currency_source") or "")
    if t == "tax_convert":
        return tax_convert(sub.get("amount"), sub.get("rate"), sub.get("direction") or "net_to_gross",
                           sub.get("quantize") or "0.01")
    if t == "money_compare":
        return money_compare(sub.get("amount"), sub.get("threshold"), sub.get("op") or "<=",
                             sub.get("currency") or "", sub.get("want_currency") or "",
                             sub.get("tax_included"), sub.get("want_tax_included"), sub.get("quantize") or "0.01")
    return {"ok": False, "status": "failed", "code": "unknown_tool",
            "reason": f"未知工具：{t}", "trace": {"tool": t}}


# ---------------------------------------------------------------------------
# 数值/比例/费率表达归一（task-22 P0 业务有效性）
#
# 目标：同一业务数值在真实文件里的常见写法要先归一、再比较，包括
#   1) 全角数字/小数点/百分号（１２，０００．５０％）；
#   2) 中文数字与大写金额（壹仟贰佰万元、百分之三十五、万分之八、百分之零点零八）；
#   3) 含税/未税口径（不猜：口径缺失时调用方必须判证据不足）；
#   4) 单位换行/跨行（数字与「万元」被换行拆开）。
# 本段只做确定性解析，不联网、不猜默认口径、不替调用方做取舍。
# ---------------------------------------------------------------------------
_FULLWIDTH_NUM_MAP = {
    "０": "0", "１": "1", "２": "2", "３": "3", "４": "4",
    "５": "5", "６": "6", "７": "7", "８": "8", "９": "9",
    "．": ".", "，": ",", "％": "%", "＋": "+", "－": "-", "−": "-",
    "／": "/", "：": ":", "；": ";", "　": " ", "（": "(", "）": ")",
}
# L39 ③ 全角拉丁字母归一：Ａ-Ｚ/ａ-ｚ 逐字符 1:1 映射（不改变长度，引文下标仍可回指原文）。
# 背景（L31v2 240 盲测 nfkc_fullwidth 类 9/22）：`ｍｉｎ/ｈ/ｋｇ/ｐｐｍ/ｍｇ／ｋｇ/Ｘ`
# 等全角字母单位未归一，取数层完全匹配不到单位。
_FULLWIDTH_LETTER_MAP = {
    **{chr(0xFF21 + i): chr(ord("A") + i) for i in range(26)},
    **{chr(0xFF41 + i): chr(ord("a") + i) for i in range(26)},
    "＊": "*", "＋": "+",
}
_FULLWIDTH_NUM_MAP_FIX2 = dict(_FULLWIDTH_NUM_MAP)
_FULLWIDTH_NUM_MAP_FIX2.update(_FULLWIDTH_LETTER_MAP)
_FULLWIDTH_TRANS = str.maketrans(_FULLWIDTH_NUM_MAP)
_FULLWIDTH_TRANS_FIX2 = str.maketrans(_FULLWIDTH_NUM_MAP_FIX2)


def canonical_numeric_text(text) -> str:
    """数字表达归一：全角→半角（逐字符 1:1，便于把匹配位置映射回原文引文）。

    L39 ③：``RULEPROOF_EXEC_FIXES_V2`` 开启时额外归一全角拉丁字母（Ａ-Ｚ/ａ-ｚ）；
    =0 时逐字回退到只归一全角数字/标点的历史行为。
    """
    trans = _FULLWIDTH_TRANS_FIX2 if exec_fix_v2("fullwidth") else _FULLWIDTH_TRANS
    return str(text or "").translate(trans)


_CN_DIGIT = {"零": 0, "〇": 0, "一": 1, "壹": 1, "二": 2, "贰": 2, "两": 2, "兩": 2,
             "三": 3, "叁": 3, "四": 4, "肆": 4, "五": 5, "伍": 5,
             "六": 6, "陆": 6, "七": 7, "柒": 7, "八": 8, "捌": 8, "九": 9, "玖": 9}
_CN_UNIT = {"十": 10, "拾": 10, "百": 100, "佰": 100, "千": 1000, "仟": 1000}
_CN_BIG = {"万": 10000, "萬": 10000, "亿": 100000000, "億": 100000000}
CN_NUM_CHARS = "".join(list(_CN_DIGIT) + list(_CN_UNIT) + list(_CN_BIG)) + "点點"


def _cn_int(s: str):
    total = 0
    section = 0
    number = 0
    seen_digit = False
    for ch in s:
        if ch in _CN_DIGIT:
            number = _CN_DIGIT[ch]
            seen_digit = True
        elif ch in _CN_UNIT:
            if not seen_digit and not section:
                if ch not in ("十", "拾"):
                    return None
                number = 1
            section += (number or 1) * _CN_UNIT[ch]
            number = 0
        elif ch in _CN_BIG:
            if not (seen_digit or section):
                return None
            section += number
            total += section * _CN_BIG[ch]
            section = 0
            number = 0
        else:
            return None
    if not seen_digit and not total and not section:
        return None
    return total + section + number


def cn_number(token) -> float | None:
    """中文数字/大写金额 → float；不是中文数字返回 None。"""
    s = canonical_numeric_text(token).strip()
    if not s or not any(ch in _CN_DIGIT or ch in _CN_UNIT or ch in _CN_BIG
                        or ch in "点點" for ch in s):
        return None
    if "点" in s or "點" in s:
        for sep in ("点", "點"):
            if sep in s:
                int_part, frac_part = s.split(sep, 1)
                break
        iv = _cn_int(int_part) if int_part else 0
        if iv is None:
            return None
        frac = []
        for ch in frac_part:
            if ch in _CN_DIGIT:
                frac.append(str(_CN_DIGIT[ch]))
            else:
                return None
        try:
            return float(f"{iv}.{''.join(frac) or 0}")
        except ValueError:
            return None
    value = _cn_int(s)
    return float(value) if value is not None else None


_TAX_INCLUDED_RE = re.compile(r"含税|价税合计|含[^，。；;\n]{0,6}增值税")
_TAX_EXCLUDED_RE = re.compile(r"不含税|未税|除税|税前|不含增值税")


def tax_basis_of(context) -> dict:
    """从数字上下文识别含税/未税口径；无法识别时 basis 为空（调用方不得猜）。"""
    c = canonical_numeric_text(context)
    if _TAX_EXCLUDED_RE.search(c):
        m = _TAX_EXCLUDED_RE.search(c)
        return {"basis": "excluded", "marker": m.group(0), "source_text": c[:80]}
    m = _TAX_INCLUDED_RE.search(c)
    if m:
        return {"basis": "included", "marker": m.group(0), "source_text": c[:80]}
    return {"basis": "", "marker": "", "source_text": c[:80]}


def tax_basis_label(basis) -> str:
    return {"included": "含税", "excluded": "未税"}.get(str(basis or ""), "")


def normalize_tax_request(value) -> str:
    """规则声明的含税口径归一：included/excluded/含税/未税/不含税…；未知返回空串。"""
    text = str(value or "").strip().lower()
    if text in ("included", "include", "gross", "含税", "含税价", "true", "1"):
        return "included"
    if text in ("excluded", "exclude", "net", "未税", "不含税", "未税价", "false", "0"):
        return "excluded"
    return ""


# ---------------------------------------------------------------------------
# 币种归一（金额规则：外币金额缺汇率/换算时点时必须证据不足，不能按本币阈值直接比较）
# ---------------------------------------------------------------------------
CURRENCY_ALIASES = {
    "元": "CNY", "人民币": "CNY", "rmb": "CNY", "cny": "CNY", "¥": "CNY", "￥": "CNY",
    "美元": "USD", "美金": "USD", "usd": "USD", "$": "USD", "米元": "USD",
    "欧元": "EUR", "eur": "EUR",
    "港元": "HKD", "港币": "HKD", "hkd": "HKD",
    "英镑": "GBP", "gbp": "GBP",
    "日元": "JPY", "jpy": "JPY",
    "韩元": "KRW", "krw": "KRW",
    "卢布": "RUB", "rub": "RUB",
}

_FX_RATE_PATTERNS = (
    r"汇率\s*(?:为|是|按|取|[:：])?\s*(\d+(?:\.\d+)?)",
    r"折算率\s*(?:为|是|[:：])?\s*(\d+(?:\.\d+)?)",
    r"1\s*[^\d\s]{0,6}\s*(?:=|＝|兑|兑换|折合|约合|换)\s*(\d+(?:\.\d+)?)",
    r"(\d+(?:\.\d+)?)\s*(?:元|人民币)\s*/\s*(?:美元|美金|欧元|港元|英镑|日元)",
)
_FX_TIME_RE = re.compile(
    r"(?:\d{4})\s*[-/年.]\s*(?:\d{1,2})\s*[-/月.]\s*(?:\d{1,2})(?:\s*日)?"
    r"|换算时点\s*[:：]?\s*[^\s，。；;]{4,20}")


def currency_of(unit) -> str:
    """单位/币种写法 → 规范币种码（CNY/USD/…）；无法识别返回空串。"""
    u = str(unit or "").strip()
    if not u:
        return ""
    return (CURRENCY_ALIASES.get(u) or CURRENCY_ALIASES.get(u.lower())
            or CURRENCY_ALIASES.get(u.upper() if len(u) <= 3 else "") or "")


def fx_rate_evidence(text) -> dict:
    """外币换算证据：必须同时给出**显式汇率数值**和**换算时点**，缺一即不完整。

    返回 {rate, rate_raw, time_point, complete, missing}；不猜默认汇率。
    """
    body = canonical_numeric_text(text)
    rate, rate_raw = None, ""
    for pat in _FX_RATE_PATTERNS:
        m = re.search(pat, body)
        if not m:
            continue
        try:
            rate = float(m.group(1))
        except (TypeError, ValueError):
            continue
        if rate and rate > 0:
            rate_raw = m.group(0)[:60]
            break
    mt = _FX_TIME_RE.search(body)
    out = {"rate": rate, "rate_raw": rate_raw,
           "time_point": (mt.group(0)[:40] if mt else ""),
           "missing": []}
    if rate is None:
        out["missing"].append("rate")
    if not out["time_point"]:
        out["missing"].append("time_point")
    out["complete"] = not out["missing"]
    return out

