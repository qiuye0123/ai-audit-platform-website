# -*- coding: utf-8 -*-
"""三段式规则 IR（主体 / 算子 / 客体）+ 类型驱动算子 + 中文模态词表。

借鉴 CN118467683B 的思路：规则统一编译为 (subject, operator, object)；
subject.datatype 决定 operator 候选集；模态词独立成数据表；单位比较前归一。

T-112（2026-11-18）在 typed IR 内补齐两类非数值判据（既有门禁缺口，此前保存期
直接拒绝，导致 conflict_scenarios 的集合/文本规则无法创建）：
- enum   ：``metric + op(in/not_in/=) + values[]`` → 值集合约束；
- keyword：``metric + require/forbid/require_any`` → 包含/禁止关键字约束。
两类都要求主体与客体显式存在；算子/客体缺失或非法仍返回 errors，不放宽成
「任意形态都过」。
"""
import math
import os
import re

from .ruleexec import (_UNIT_SCALE, _unit_dim, _unit_key, _unit_known,
                       _unit_scale, _opspec_fix_on)

# 算子单一真相源（L79）：中文模态词 + 类型驱动算子集合统一来自 app/engine/registry.py，
# 执行期语义不变（normalize_operator 仍受 RULEPROOF_OPERATOR_SPEC_FIX 控制 `==` 归一；
# registry 只是把「已知算子/写法」收敛为一份表，供保存期写入门与发布门共用）。
from .registry import MODALITY as _REG_MODALITY  # noqa: E402
from .registry import OPERATORS_BY_TYPE as _REG_OPERATORS_BY_TYPE  # noqa: E402

MODALITY = [tuple(x) for x in _REG_MODALITY]
OPERATORS_BY_TYPE = {k: set(v) for k, v in _REG_OPERATORS_BY_TYPE.items()}

DATE_WORDS = ("日期", "截止时间", "开标时间", "签订时间", "发布时间", "生效日期")
TEXT_WORDS = ("名称", "单位名称", "地址", "联系人", "投标人", "招标人", "编号", "文号", "资质", "范围")
_KEYWORD_KEYS = ("require", "forbid", "forbidden", "require_any")


# L62 B3（2026-11-24）：精确比较算子的写法归一（`==`/`≠`/全角＝），
# 仅在 RULEPROOF_OPERATOR_SPEC_FIX=1 时生效；=0 回退「无法识别算子」（历史口径）。
_OPSPEC_OP_ALIAS = {"==": "=", "≠": "!=", "＝": "=", "!＝": "!=", "!==": "!="}


def normalize_operator(text_or_op: str) -> str:
    s = str(text_or_op or "").strip()
    if _opspec_fix_on("exact_op") and s in _OPSPEC_OP_ALIAS:
        s = _OPSPEC_OP_ALIAS[s]
    all_ops = {o for ops in OPERATORS_BY_TYPE.values() for o in ops}
    if s in all_ops:
        return s
    for word, op in sorted(MODALITY, key=lambda x: -len(x[0])):
        if word in s:
            return op
    return ""


def _enum_values(slots: dict) -> list:
    """枚举取值集合：values / enum / options（列表、元组、集合或单个字符串）。"""
    raw = slots.get("values")
    if raw is None:
        raw = slots.get("enum")
    if raw is None:
        raw = slots.get("options")
    if raw is None:
        return []
    if isinstance(raw, dict):
        raw = list(raw.keys())
    elif isinstance(raw, str):
        raw = [raw]
    elif not isinstance(raw, (list, tuple, set)):
        return []
    out = []
    for v in raw:
        text = str(v).strip()
        if text and text not in out:
            out.append(text)
    return out


def _keyword_condition(slots: dict) -> dict:
    """关键字判据：require→contains、forbid→not_contains、require_any→contains(any)。"""
    req_any = slots.get("require_any")
    if isinstance(req_any, str):
        req_any = [req_any]
    if isinstance(req_any, (list, tuple)):
        keys = [str(x).strip() for x in req_any if str(x).strip()]
        if keys:
            return {"mode": "contains", "effect": "require", "any_of": True, "keywords": keys}
    req = str(slots.get("require") or "").strip()
    if req:
        return {"mode": "contains", "effect": "require", "any_of": False, "keywords": [req]}
    forb = str(slots.get("forbid") or slots.get("forbidden") or "").strip()
    if forb:
        return {"mode": "not_contains", "effect": "forbid", "any_of": False, "keywords": [forb]}
    return {}


def infer_datatype(slots: dict) -> str:
    name = str(slots.get("metric") or slots.get("object") or slots.get("subject") or "")
    unit = str(slots.get("unit") or "")
    v = slots.get("value", slots.get("threshold"))
    rng = slots.get("range") or None
    if v in (None, "") and not rng and _enum_values(slots):
        return "enum"
    # L5 段1 区间算子 op="range"：value="lo-hi" 是字符串，不能按 text 类型编译；
    # range 语义恒为数值（闭区间 lo<=x<=hi），datatype 必须是 number。
    if rng or str(slots.get("operator") or slots.get("op") or "").strip() == "range":
        return "number"
    if any(w in name for w in DATE_WORDS):
        return "date"
    if any(w in name for w in TEXT_WORDS):
        return "text"
    if isinstance(v, (int, float)):
        return "number"
    try:
        float(str(v).replace(",", ""))
        return "number"
    except Exception:
        pass
    if _unit_known(unit):
        return "number"
    if slots.get("enum") or slots.get("options"):
        return "enum"
    if slots.get("bool") is not None:
        return "boolean"
    return "text"


def _compile_number(slots, name, raw_op, dtype, errors):
    unit = str(slots.get("unit") or "")
    value = slots.get("value", slots.get("threshold"))
    rng = slots.get("range") or None
    op = normalize_operator(raw_op)
    if not name:
        errors.append("缺少主体（metric/object）")
    if not op:
        errors.append(f"无法识别算子（原文：{str(raw_op)[:30]}）")
    elif op not in OPERATORS_BY_TYPE.get(dtype, set()):
        errors.append(f"算子 {op} 不适用于类型 {dtype}（候选：{sorted(OPERATORS_BY_TYPE.get(dtype, []))}）")
    if op not in ("contains", "not_contains", "regex") and value in (None, "") and not rng:
        errors.append("缺少客体（阈值/范围/目标值）")
    if unit and not _unit_known(unit):
        errors.append(f"未知单位：{unit}")
    return {
        "subject": {"name": name, "datatype": dtype, "unit": unit},
        "operator": op,
        "object": {"value": value, "range": rng, "unit": unit,
                   "normalized_value": _norm_value(value, unit)},
        "raw": {"operator": str(raw_op)},
    }


def _compile_enum(slots, name, raw_op, errors):
    """enum：值集合约束（op ∈ in/not_in/=/!=，客体为 values[]）。"""
    unit = str(slots.get("unit") or "")
    values = _enum_values(slots)
    op = normalize_operator(raw_op) if str(raw_op or "").strip() else ""
    if not name:
        errors.append("缺少主体（metric/object）")
    if not op:
        errors.append(f"无法识别算子（原文：{str(raw_op)[:30]}）")
    elif op not in OPERATORS_BY_TYPE["enum"]:
        errors.append(f"算子 {op} 不适用于类型 enum（候选：{sorted(OPERATORS_BY_TYPE['enum'])}）")
    if not values:
        errors.append("缺少客体（取值集合 values）")
    if unit and not _unit_known(unit):
        errors.append(f"未知单位：{unit}")
    return {
        "subject": {"name": name, "datatype": "enum", "unit": unit},
        "operator": op,
        "object": {"value": None, "range": None, "unit": unit,
                   "normalized_value": None, "values": values},
        "raw": {"operator": str(raw_op)},
    }


def _compile_keyword(slots, name, errors):
    """keyword：包含/禁止关键字约束（客体为 require/forbid 关键字）。"""
    unit = str(slots.get("unit") or "")
    kw = _keyword_condition(slots)
    explicit = str(slots.get("operator") or slots.get("op") or "").strip()
    op = ""
    if explicit:
        op = normalize_operator(explicit)
        if not op:
            errors.append(f"无法识别算子（原文：{explicit[:30]}）")
        elif op not in OPERATORS_BY_TYPE["text"]:
            errors.append(f"算子 {op} 不适用于类型 text（候选：{sorted(OPERATORS_BY_TYPE['text'])}）")
    else:
        op = str(kw.get("mode") or "")
    if not name:
        errors.append("缺少主体（metric/object）")
    if not kw.get("keywords"):
        errors.append("缺少客体（必需/禁止关键字 require/forbid）")
    if unit and not _unit_known(unit):
        errors.append(f"未知单位：{unit}")
    return {
        "subject": {"name": name, "datatype": "text", "unit": unit},
        "operator": op,
        "object": {"value": (kw.get("keywords") or [""])[0] if kw.get("keywords") else None,
                   "range": None, "unit": unit, "normalized_value": None,
                   "keywords": list(kw.get("keywords") or []),
                   "any_of": bool(kw.get("any_of")),
                   "effect": str(kw.get("effect") or "")},
        "raw": {"operator": explicit},
    }


def compile_three_segment(slots: dict) -> dict:
    """编译并校验三段式；返回 {ok, errors, ir:{subject,operator,object}}。

    按判据形态分流（number/enum/keyword）：enum 与 keyword 是 typed IR 的显式
    约束类型，不是「任意槽位都编译通过」；主体/客体/算子缺失或非法仍返回 errors。
    """
    slots = dict(slots or {})
    errors = []
    name = str(slots.get("metric") or slots.get("object") or "").strip()
    value = slots.get("value", slots.get("threshold"))
    rng = slots.get("range") or None
    enum_values = _enum_values(slots)
    keyword = _keyword_condition(slots)
    raw_op = slots.get("operator") or slots.get("op") or slots.get("criterion") or ""
    _op_hint = normalize_operator(raw_op)
    # 形态判定：数值/日期优先（保持既有 limit 口径），其次 enum，再 keyword。
    if value not in (None, "") or rng:
        dtype = infer_datatype(slots)
        ir = _compile_number(slots, name, raw_op, dtype, errors)
    elif enum_values or _op_hint in ("in", "not_in"):
        # 有取值集合，或显式声明集合算子：按 enum 编译（缺 values 仍报「缺少客体」）
        ir = _compile_enum(slots, name, raw_op, errors)
    elif keyword or _op_hint in ("contains", "not_contains", "regex"):
        # 有关键字，或显式声明文本算子：按 keyword 编译（缺 require/forbid 仍报错）
        ir = _compile_keyword(slots, name, errors)
    else:
        dtype = infer_datatype(slots)
        ir = _compile_number(slots, name, raw_op, dtype, errors)
    return {"ok": not errors, "errors": errors, "ir": ir}


def _norm_value(value, unit: str):
    """阈值归一到基准单位（压力→Pa、金额→元…）；未注册单位原样返回，不猜。"""
    try:
        v = float(str(value).replace(",", ""))
    except Exception:
        return value
    scale = _unit_scale(unit)
    if scale is not None:
        return v * scale
    return v


def _compare_enum(ir: dict, fact_value) -> str:
    values = [str(x) for x in ((ir.get("object") or {}).get("values") or [])]
    fact = str(fact_value if fact_value is not None else "").strip()
    op = ir.get("operator") or ""
    if not values or not fact:
        return "证据不足"
    hit = any(v and (v == fact or v in fact) for v in values)
    if op in ("in", "="):
        return "满足" if hit else "不满足"
    if op in ("not_in", "!="):
        return "不满足" if hit else "满足"
    return "证据不足"


def _compare_keyword(ir: dict, fact_value) -> str:
    obj = ir.get("object") or {}
    keywords = [str(x) for x in (obj.get("keywords") or []) if str(x)]
    text = str(fact_value if fact_value is not None else "")
    op = ir.get("operator") or ""
    if not keywords or not text.strip():
        return "证据不足"
    if op == "contains":
        if obj.get("any_of"):
            return "满足" if any(k in text for k in keywords) else "不满足"
        return "满足" if all(k in text for k in keywords) else "不满足"
    if op == "not_contains":
        return "不满足" if any(k in text for k in keywords) else "满足"
    if op == "=":
        return "满足" if any(k == text.strip() for k in keywords) else "不满足"
    if op == "!=":
        return "不满足" if any(k == text.strip() for k in keywords) else "满足"
    return "证据不足"


# L86 P0-2：裁决允许的单位来源白名单（与 ruleexec._OPSPEC_INHERIT_SOURCES 同口径）。
_UNIT_SOURCE_ALLOWED = ("rule_slot", "frozen_alias", "conversion_table")


def _fact_identity_fix_on() -> bool:
    """L86 事实身份/单位来源修复开关（默认 1；=0 逐项回退历史口径）。"""
    try:
        return str(os.environ.get("RULEPROOF_FACT_IDENTITY_FIX", "1")).strip().lower() \
            not in ("0", "false", "off", "no")
    except Exception:
        return True


def _num_or_none(v):
    """数值解析（NaN/Inf 可解析出来，由 ``_finite_num`` 另行判定）。"""
    if isinstance(v, bool):
        return None
    try:
        if isinstance(v, (int, float)):
            return float(v)
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError, OverflowError):
        return None


def _finite_num(v) -> bool:
    """数值是否有限（NaN/Inf/非数值 → False）。"""
    f = _num_or_none(v)
    return f is not None and math.isfinite(f)


def _unit_source_tag(fact_unit, rule_unit, declared=None) -> str:
    """比较所用单位的来源：

    - 调用方显式声明（``rule_slot`` / ``frozen_alias`` / ``conversion_table``）优先；
    - 事实单位与规则单位同键 → 规则槽位单位（``rule_slot``）；
    - 不同单位经换算表换算 → ``conversion_table``；
    - 无单位参与（规则与事实都无单位）→ ``rule_slot``（空单位槽位）。
    """
    declared = str(declared or "").strip().lower()
    if declared in _UNIT_SOURCE_ALLOWED:
        return declared
    kf, kt = _unit_key(fact_unit), _unit_key(rule_unit)
    if kf and kt:
        return "rule_slot" if kf == kt else "conversion_table"
    return "rule_slot"


def _ir_insufficient(detail: str, **extra) -> dict:
    out = {"state": "证据不足", "detail": detail, "unit_source": "",
           "unit_inherited": False}
    out.update(extra)
    return out


def _compare_range_detail(ir: dict, fact_value, fact_unit: str = "",
                          unit_source=None) -> dict:
    """区间算子 op="range" 的详情版比较（含单位来源/非有限门禁，L86 P0-2）。

    闭区间 lo <= x <= hi；只做算术比较，复用既有单位归一与未知单位 fail-closed 口径。
    """
    obj = ir.get("object") or {}
    rng = obj.get("range") if isinstance(obj.get("range"), dict) else {}
    lo = hi = None
    for key, val in (("lo", rng.get("lo")), ("hi", rng.get("hi"))):
        num = _num_or_none(val)
        if key == "lo":
            lo = num
        else:
            hi = num
    if lo is None or hi is None:
        m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[-~～〜至到—–－]\s*(-?\d+(?:\.\d+)?)\s*$",
                     str(obj.get("value") or ""))
        if m:
            lo, hi = float(m.group(1)), float(m.group(2))
    if lo is None or hi is None:
        return _ir_insufficient("区间上下限无法解析")
    v = _num_or_none(fact_value)
    if v is None:
        return _ir_insufficient("事实数值无法解析")
    fix_on = _fact_identity_fix_on()
    if fix_on and not (_finite_num(lo) and _finite_num(hi)):
        return _ir_insufficient("规则区间端点非有限（NaN/Inf），不参与判定",
                                non_finite_blocked=True)
    if fix_on and not _finite_num(v):
        return _ir_insufficient("事实数值非有限（NaN/Inf），不参与判定",
                                non_finite_blocked=True)
    tunit = (ir.get("subject") or {}).get("unit") or (obj.get("unit") or "")
    src = ""
    inherited = False
    if fix_on:
        if tunit and not fact_unit:
            declared = str(unit_source or "").strip().lower()
            if declared in _UNIT_SOURCE_ALLOWED:
                fact_unit, src, inherited = tunit, declared, True
            else:
                return _ir_insufficient(
                    f"缺计量单位：事实数值 {v!r} 未标 {tunit} 或其他可换算单位，"
                    "且无单位来源（rule_slot/frozen_alias/conversion_table）→ 不猜单位",
                    unit_source_missing=True)
        elif fact_unit and not tunit:
            if _unit_known(fact_unit) or str(fact_unit).strip():
                return _ir_insufficient(
                    f"规则槽位无单位、事实带单位 {fact_unit!r}，无法确定比较基准单位",
                    unit_source_missing=True)
        elif fact_unit and tunit:
            src = _unit_source_tag(fact_unit, tunit, unit_source)
    if fact_unit and tunit:
        kf, kt = _unit_key(fact_unit), _unit_key(tunit)
        if not kf or not kt:
            return _ir_insufficient(f"未知单位：事实 {fact_unit!r} / 规则 {tunit!r}，不猜")
        df, dt = _unit_dim(kf), _unit_dim(kt)
        if df and dt and df != dt:
            return _ir_insufficient(f"跨量纲：{fact_unit} → {tunit}，不猜")
        sf, st = _UNIT_SCALE.get(kf), _UNIT_SCALE.get(kt)
        if sf is None or st is None:
            return _ir_insufficient(f"单位无法换算：{fact_unit} → {tunit}，不猜")
        v = v * sf / st
    elif not tunit and not fact_unit:
        src = "rule_slot"
    return {"state": "满足" if lo <= v <= hi else "不满足",
            "detail": "", "value": v, "unit": _unit_key(tunit) or str(tunit or ""),
            "unit_source": src, "unit_inherited": inherited}


def compare_fact_detail(ir: dict, fact_value, fact_unit: str = "",
                        unit_source=None) -> dict:
    """按 IR 比较事实的**详情版**：返回 state + unit_source/unit_inherited 等。

    L86 P0-2（外部复验报告 HEAD96eb3be §7 P0-2）：本函数是 rule_ir2 的比较入口，
    必须与 ruleexec 同口径 fail-closed：
    - 规则有单位、事实无单位且无合法单位来源 → 证据不足（不得按规则单位静默比较）；
    - 规则无单位、事实带单位 → 无法确定基准单位 → 证据不足；
    - 未知单位/跨量纲 → 证据不足；
    - NaN/Inf 等非有限数（规则阈值或事实值）→ 证据不足（不得落成 满足/不满足）；
    - 成功比较时回填 ``unit_source``（rule_slot / frozen_alias / conversion_table）。
    统一开关 ``RULEPROOF_FACT_IDENTITY_FIX`` 默认 1；=0 回退历史口径。
    """
    op = ir.get("operator") or ""
    if op in ("in", "not_in") and (ir.get("subject") or {}).get("datatype") == "enum":
        st = _compare_enum(ir, fact_value)
        return {"state": st, "detail": "", "unit_source": "",
                "unit_inherited": False}
    if op in ("contains", "not_contains"):
        st = _compare_keyword(ir, fact_value)
        return {"state": st, "detail": "", "unit_source": "",
                "unit_inherited": False}
    if op == "range":
        return _compare_range_detail(ir, fact_value, fact_unit, unit_source)
    obj = ir.get("object") or {}
    target = obj.get("value", obj.get("normalized_value"))
    tunit = (ir.get("subject") or {}).get("unit") or (obj.get("unit") or "")
    fix_on = _fact_identity_fix_on()
    t = _num_or_none(target)
    v = _num_or_none(fact_value)
    if t is None or v is None:
        return _ir_insufficient("规则阈值或事实值无法解析为数值")
    src = ""
    inherited = False
    if fix_on:
        if not _finite_num(t):
            return _ir_insufficient(
                f"规则阈值非有限（NaN/Inf：{target!r}），不参与判定",
                non_finite_blocked=True)
        if not _finite_num(v):
            return _ir_insufficient(
                f"事实数值非有限（NaN/Inf：{fact_value!r}），不参与判定",
                non_finite_blocked=True)
        if tunit and not fact_unit:
            declared = str(unit_source or "").strip().lower()
            if declared in _UNIT_SOURCE_ALLOWED:
                fact_unit, src, inherited = tunit, declared, True
            else:
                return _ir_insufficient(
                    f"缺计量单位：事实数值 {fact_value!r} 未标 {tunit} 或其他可换算单位，"
                    "且无单位来源（rule_slot/frozen_alias/conversion_table）→ 不猜单位",
                    unit_source_missing=True)
        elif fact_unit and not tunit:
            return _ir_insufficient(
                f"规则槽位无单位、事实带单位 {fact_unit!r}，无法确定比较基准单位",
                unit_source_missing=True)
    if fact_unit and tunit:
        kf, kt = _unit_key(fact_unit), _unit_key(tunit)
        # 未知单位不得猜成「与规则同单位」直接比较
        if not kf or not kt:
            return _ir_insufficient(f"未知单位：事实 {fact_unit!r} / 规则 {tunit!r}，不猜")
        df, dt = _unit_dim(kf), _unit_dim(kt)
        if df and dt and df != dt:
            return _ir_insufficient(f"跨量纲：{fact_unit} → {tunit}，不猜")
        sf, st = _UNIT_SCALE.get(kf), _UNIT_SCALE.get(kt)
        if sf is None or st is None:
            return _ir_insufficient(f"单位无法换算：{fact_unit} → {tunit}，不猜")
        v = v * sf / st
        if fix_on:
            src = _unit_source_tag(fact_unit, tunit, unit_source)
    elif not tunit and not fact_unit:
        src = "rule_slot"
    ops = {">=": lambda a, b: a >= b, "<=": lambda a, b: a <= b, "=": lambda a, b: a == b,
           ">": lambda a, b: a > b, "<": lambda a, b: a < b, "!=": lambda a, b: a != b}
    fn = ops.get(op)
    if not fn:
        return _ir_insufficient(f"不支持的比较符 {op!r}")
    return {"state": "满足" if fn(v, t) else "不满足", "detail": "",
            "value": v, "unit": _unit_key(tunit) or str(tunit or ""),
            "unit_source": src, "unit_inherited": inherited}


def compare_fact(ir: dict, fact_value, fact_unit: str = "", unit_source=None) -> str:
    """按 IR 比较事实，返回 满足/不满足/证据不足；单位不同先归一。

    enum/keyword typed IR 按值集合/关键字直接判定；数值 IR 保留原单位换算口径，
    未知单位/跨量纲一律证据不足（不猜）。L86 起缺单位/无来源/非有限数同样证据不足；
    ``=0`` 回退历史口径。需要单位来源等详情时用 :func:`compare_fact_detail`。
    """
    if not _fact_identity_fix_on():
        return _compare_fact_legacy(ir, fact_value, fact_unit)
    return compare_fact_detail(ir, fact_value, fact_unit, unit_source).get("state", "证据不足")


def _compare_fact_legacy(ir: dict, fact_value, fact_unit: str = "") -> str:
    """L86 =0 回退口径（与 2026-11-24 前逐字节一致的历史比较）。"""
    op = ir.get("operator") or ""
    if op in ("in", "not_in") and (ir.get("subject") or {}).get("datatype") == "enum":
        return _compare_enum(ir, fact_value)
    if op in ("contains", "not_contains"):
        return _compare_keyword(ir, fact_value)
    if op == "range":
        return _compare_range_legacy(ir, fact_value, fact_unit)
    target = ir.get("object", {}).get("value", ir.get("object", {}).get("normalized_value"))
    tunit = ir.get("subject", {}).get("unit") or ""
    try:
        t = float(str(target).replace(",", ""))
        v = float(str(fact_value).replace(",", ""))
    except Exception:
        return "证据不足"
    if fact_unit and tunit:
        kf, kt = _unit_key(fact_unit), _unit_key(tunit)
        if not kf or not kt:
            return "证据不足"
        df, dt = _unit_dim(kf), _unit_dim(kt)
        if df and dt and df != dt:
            return "证据不足"
        sf, st = _UNIT_SCALE.get(kf), _UNIT_SCALE.get(kt)
        if sf is None or st is None:
            return "证据不足"
        v = v * sf / st
    ops = {">=": lambda a, b: a >= b, "<=": lambda a, b: a <= b, "=": lambda a, b: a == b,
           ">": lambda a, b: a > b, "<": lambda a, b: a < b, "!=": lambda a, b: a != b}
    fn = ops.get(op)
    if not fn:
        return "证据不足"
    return "满足" if fn(v, t) else "不满足"


def _compare_range_legacy(ir: dict, fact_value, fact_unit: str = "") -> str:
    """L86 =0 回退口径的区间比较（历史实现，不新增门禁）。"""
    obj = ir.get("object") or {}
    rng = obj.get("range") if isinstance(obj.get("range"), dict) else {}
    lo = hi = None
    for key, val in (("lo", rng.get("lo")), ("hi", rng.get("hi"))):
        try:
            num = float(str(val).replace(",", ""))
        except Exception:
            num = None
        if key == "lo":
            lo = num
        else:
            hi = num
    if lo is None or hi is None:
        m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[-~～〜至到—–－]\s*(-?\d+(?:\.\d+)?)\s*$",
                     str(obj.get("value") or ""))
        if m:
            lo, hi = float(m.group(1)), float(m.group(2))
    if lo is None or hi is None:
        return "证据不足"
    try:
        v = float(str(fact_value).replace(",", ""))
    except Exception:
        return "证据不足"
    tunit = (ir.get("subject") or {}).get("unit") or ""
    if fact_unit and tunit:
        kf, kt = _unit_key(fact_unit), _unit_key(tunit)
        if not kf or not kt:
            return "证据不足"
        df, dt = _unit_dim(kf), _unit_dim(kt)
        if df and dt and df != dt:
            return "证据不足"
        sf, st = _UNIT_SCALE.get(kf), _UNIT_SCALE.get(kt)
        if sf is None or st is None:
            return "证据不足"
        v = v * sf / st
    return "满足" if lo <= v <= hi else "不满足"
