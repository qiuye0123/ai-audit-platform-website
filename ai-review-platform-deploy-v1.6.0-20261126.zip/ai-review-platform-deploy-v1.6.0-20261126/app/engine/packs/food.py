# -*- coding: utf-8 -*-
"""食品工艺包：检查函数 + 注册表。

通用工具与类型由引擎在加载时注入（见 engine.py 底部），本文件不反向依赖 engine，
因此可以独立被替换/扩展成其他行业包。
"""
import os
import re
import unicodedata

# ---------------------------------------------------------------------------
# L107（2026-11-25）工艺包温度判据单位归一（D1 修复）
#
# 缺陷：_chk_center_temp/_chk_cooling/_chk_cold_storage 直接比较事实层取到的原始数值，
#   规则阈值固定按摄氏（℃）书写。温标混写时：
#     · 「中心温度158℉以上出锅」→ 158 ≥ 85 → 假通过（158℉=70℃，应不满足）；
#     · 「冷却至中心温度50℉」→ 50 > 10 → 误报（50℉=10℃，应满足）。
# 修复：取数后先用执行器同源单位归一（ruleexec._temp_to_c，与 judge_limit 同一口径；
#   rexec 先把 ℃/°C/摄氏度/度/℉/°F/华氏度 规范成 ℃/℉），温度阈值比较前统一换算到 ℃。
# 缺失/未知单位 → 不猜（计入不可判定；无违规且存在不可判定事实 → 证据不足）。
# 开关 RULEPROOF_FOOD_UNIT_FIX（默认 1；=0 逐字回退旧行为，用于 A/B 与回滚）。
# ---------------------------------------------------------------------------
def _food_unit_fix_on() -> bool:
    """工艺包温度单位归一开关（默认开；=0 回退旧口径）。"""
    return str(os.environ.get("RULEPROOF_FOOD_UNIT_FIX", "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _temp_to_celsius(fact):
    """温度事实 → 摄氏值；单位缺失/未知返回 None（fail-safe：不猜单位、不默认按 ℃ 比较）。"""
    from .. import ruleexec as _re
    unit = str(getattr(fact, "unit", "") or "").strip()
    if not unit:
        return None
    try:
        return _re._temp_to_c(getattr(fact, "value", None), unit)
    except (TypeError, ValueError):
        return None
    except Exception:                     # noqa: BLE001 - 换算异常按不可判定处理并留痕
        import logging as _logging
        _logging.getLogger(__name__).debug("food temp unit conversion failed",
                                         exc_info=True)
        return None


def _temp_facts_celsius(hits):
    """温度事实列表 → (可判定 [(fact, ℃)], 不可判定 [fact])；开关关闭时原值按 ℃ 返回。"""
    if not _food_unit_fix_on():
        return [(f, f.value) for f in hits], []
    decided, undecided = [], []
    for f in hits:
        c = _temp_to_celsius(f)
        if c is None:
            undecided.append(f)
            continue
        decided.append((f, c))
    return decided, undecided


def _fmt_temp_pair(fact, c) -> str:
    """引文/描述展示：原值+原单位（换算值 ≠ 原值时才附 ℃ 换算）。"""
    raw = f"{fact.value:g}{fact.unit}"
    if c is None or abs(float(c) - float(fact.value)) < 1e-9 and fact.unit == "℃":
        return raw
    return f"{raw}={c:g}℃"


def _chk_version_consistency(doc, statuses, findings, pass_items):
    valid_versions = {h.version for h in doc.headers.values() if h.version is not None and not is_placeholder(h.version)}
    if len(valid_versions) == 1:
        statuses.append(RuleStatus("RW20260525001", "工单号/版本号一致性", "满足", f"非占位符版本号统一：{sorted(valid_versions)[0]}"))
        pass_items.append({"name": "工单号/版本号一致性", "detail": f"{len([h for h in doc.headers.values() if not is_placeholder(h.version)])} 个有版本号的 Sheet 一致"})
    elif len(valid_versions) > 1:
        statuses.append(RuleStatus("RW20260525001", "工单号/版本号一致性", "不满足", "存在多个版本号"))
    else:
        statuses.append(RuleStatus("RW20260525001", "工单号/版本号一致性", "证据不足", "无有效版本号"))


def _chk_impl_dates(doc, statuses, findings, pass_items):
    from ...services import ruleparam as _rp_d
    import datetime as _dt
    _tol = int(_rp_d.option("RW20260526004", "date_tolerance_days", 0) or 0)

    def _parse(v):
        for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
            try:
                return _dt.datetime.strptime(str(v)[:10].replace("/", "-"), "%Y-%m-%d")
            except Exception:
                continue
        return None

    dates = {}
    for h in doc.headers.values():
        if h.impl_date:
            dates.setdefault(h.impl_date, []).append(h.sheet)
    if len(dates) > 1 and _tol > 0:
        parsed = [_parse(d) for d in dates]
        if all(parsed):
            span = (max(parsed) - min(parsed)).days
            if span <= _tol:
                statuses.append(RuleStatus("RW20260526004", "实施日期一致", "满足",
                                           f"跨度 {span} 天 ≤ 容差 {_tol} 天"))
                return
    if len(dates) > 1:
        groups = "；".join(f"{d}（{len(v)} 个）" for d, v in dates.items())
        anchors = []
        for d, v in dates.items():
            for s in v:
                r, c = _split_cell(doc.headers[s].impl_date_cell)
                anchors.append(Anchor(s, r, c, f"实施日期 = {d}"))
        findings.append(Finding("S1", "RW20260526004", "critical", "实施日期跨 Sheet 不一致",
                                f"存在 {len(dates)} 种实施日期：{groups}",
                                "确认最终生效版本，统一全部 Sheet 的实施日期", anchors=anchors))
        statuses.append(RuleStatus("RW20260526004", "实施日期一致", "不满足", groups))
    elif len(dates) == 1:
        statuses.append(RuleStatus("RW20260526004", "实施日期一致", "满足", list(dates)[0]))
    else:
        statuses.append(RuleStatus("RW20260526004", "实施日期一致", "证据不足", "未解析到实施日期"))


def _chk_version_placeholder(doc, statuses, findings, pass_items):
    from ...services import ruleparam as _rp_v
    _req = _rp_v.option("RW20260525002", "required_fields", None)
    _allow = _rp_v.option("RW20260525002", "allow_placeholder", []) or []
    if _req is not None and "版本号" not in _req:
        statuses.append(RuleStatus("RW20260525002", "版本号非空", "不适用", "该字段未列入必填"))
        return
    _parsed_ver = [h for h in doc.headers.values() if h.version is not None]
    if bool(_header_alias_fix_on()) and not _parsed_ver:
        # L107 D3：表头标签未被识别 → 不能默认放行（旧实现 bad_ver 为空即判「满足」）。
        statuses.append(RuleStatus("RW20260525002", "版本号非空", "证据不足",
                                   "未解析到版本号字段（表头标签/列偏移未识别，不默认放行）"))
        return
    bad_ver = [h for h in doc.headers.values()
               if h.version is not None and is_placeholder(h.version) and str(h.version) not in _allow]
    if bad_ver:
        findings.append(Finding("S2", "RW20260525002", "critical", "版本号为占位符（X/空）",
                                f"{len(bad_ver)} 个 Sheet 版本号未填写：{'、'.join(h.sheet for h in bad_ver)}",
                                "填入实际版本号",
                                anchors=[Anchor(h.sheet, *_split_cell(h.version_cell), "版本号 = X") for h in bad_ver]))
        statuses.append(RuleStatus("RW20260525002", "版本号非空", "不满足", f"{len(bad_ver)} 个 Sheet 为占位符"))
    else:
        statuses.append(RuleStatus("RW20260525002", "版本号非空", "满足", "全部填写"))


# ---------------------------------------------------------------------------
# L120（2026-11-25）签名非空判据「空集合」修复（P1）
#
# 缺陷：_chk_signatures 只遍历「已解析到的 signature roles」（`h.signatures.items()`）。
#   整个文档没有任何签名字段（表头标签未被识别/文档本无签名区）时，bad_sig 为空 →
#   落入 else 分支输出「满足 全部签名」= 把「没有证据」写成「全部合规」（silent pass）。
# 修复（四态；保留 required_fields / allow_placeholder 语义）：
#   · 整个文档所有 Sheet 都没有签名字段 → 证据不足（不默认放行）；
#   · 某 Sheet 存在签名字段（解析到 ≥1 个 SIGN_ROLES 角色标签）但不完整
#     （角色为空/占位/该 Sheet 缺少部分角色标签）→ 不满足并列出缺失角色；
#   · 存在签名字段的每个 Sheet 的 SIGN_ROLES 均非空且非占位 → 满足；
#   · 完全没有签名标签的 Sheet（如包装指示书等未设签名区的 Sheet）不凭空判违规——
#     否则 clean 稿会因「包装指示书无签名区」产生误报（L68 clean_10 签名类 finding
#     k=0/10 份，Clopper-Pearson 95% 上界 25.89%；仅作 clean-control 基线，不宣称零误报）。
# 开关 RULEPROOF_FOOD_SIGNATURE_EMPTY_FIX（默认 1；=0 逐字回退旧行为，A/B 与回滚）。
# ---------------------------------------------------------------------------
def _food_signature_empty_fix_on() -> bool:
    """工艺包签名「空集合」修复开关（默认开；=0 回退旧口径）。"""
    return str(os.environ.get("RULEPROOF_FOOD_SIGNATURE_EMPTY_FIX", "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _signature_roles() -> list:
    """签名角色全集（唯一事实源 engine.SIGN_ROLES；独立加载无注入时惰性导入）。"""
    roles = globals().get("SIGN_ROLES")
    if roles:
        return list(roles)
    try:
        from ..engine import SIGN_ROLES as _roles
        return list(_roles)
    except Exception:                     # noqa: BLE001 - 极端独立加载场景回退内置清单
        return ["研发经理", "生产经理", "品管经理", "研发"]


def _signature_missing_roles(header, allow) -> list:
    """某 Sheet 的缺失签名角色：未解析到角色标签 + 值为空/占位（allow 白名单除外）。"""
    _allow = allow or []
    missing = []
    for role in _signature_roles():
        if role not in header.signatures:
            missing.append(role)          # 该 Sheet 缺少该角色签名字段（标签未识别/未设）
        elif is_placeholder(header.signatures[role]) and str(header.signatures[role]) not in _allow:
            missing.append(role)          # 字段存在但为空/占位
    return missing


def _chk_signatures(doc, statuses, findings, pass_items):
    from ...services import ruleparam as _rp_s
    _req2 = _rp_s.option("RW20260525002", "required_fields", None)
    _allow2 = _rp_s.option("RW20260525002", "allow_placeholder", []) or []
    if _req2 is not None and "签名" not in _req2:
        statuses.append(RuleStatus("RW20260525002", "签名非空", "不适用", "该字段未列入必填"))
        return
    if not _food_signature_empty_fix_on():
        # 旧口径逐字回退：只看「已解析到的角色」，空集合落入满足（修前 silent pass 可复现）
        bad_sig = []
        for h in doc.headers.values():
            missing = [r for r, v in h.signatures.items() if is_placeholder(v) and str(v) not in _allow2]
            if missing:
                bad_sig.append((h, missing))
    else:
        _signed = [h for h in doc.headers.values() if h.signatures]
        if not _signed:
            statuses.append(RuleStatus("RW20260525002", "签名非空", "证据不足",
                                       "整个文档未解析到签名字段（表头标签/签名区未识别，不默认放行）"))
            return
        bad_sig = [(h, _miss) for h in _signed for _miss in [_signature_missing_roles(h, _allow2)]
                   if _miss]
    if bad_sig:
        anchors = []
        for h, missing in bad_sig:
            for role in missing:
                r, c = _split_cell(h.signature_cells.get(role))
                anchors.append(Anchor(h.sheet, r, c, f"{role} 签名 = X"))
        findings.append(Finding("S3", "RW20260525002", "critical", "人员签名为占位符（X/空）",
                                f"{len(bad_sig)} 个 Sheet 签名未填写：" + "；".join(f"{h.sheet}（{'、'.join(m)}）" for h, m in bad_sig),
                                "补填实际负责人姓名并签字", anchors=anchors))
        statuses.append(RuleStatus("RW20260525002", "签名非空", "不满足", f"{len(bad_sig)} 个 Sheet 缺失签名"))
    else:
        statuses.append(RuleStatus("RW20260525002", "签名非空", "满足", "全部签名"))


def _chk_product_name(doc, statuses, findings, pass_items):
    from ...services import ruleparam as _rp_n
    _aliases = _rp_n.option("RW20260525003", "name_aliases", []) or []
    _allow_short = bool(_rp_n.option("RW20260525003", "allow_short_name", False))

    def _norm(n):
        for grp in _aliases:
            if n in (grp if isinstance(grp, list) else [grp]):
                return (grp[0] if isinstance(grp, list) else grp) if grp else n
        return n

    names = {}
    for h in doc.headers.values():
        if h.product_name:
            names.setdefault(_norm(h.product_name), []).append(h.sheet)
    if len(names) > 1 and _allow_short:
        ks = sorted(names, key=len)
        if all(k in ks[-1] for k in ks):   # 所有名称都是最长名的子串 → 视为简称，放行
            statuses.append(RuleStatus("RW20260525003", "产品名称一致", "满足", "允许简称"))
            return
    if len(names) > 1:
        full = max(names.keys(), key=len)
        short = min(names.keys(), key=len)
        anchors = [Anchor(s, *_split_cell(doc.headers[s].product_cell), f"产品名称 = {full}") for s in names[full]] + \
                  [Anchor(s, *_split_cell(doc.headers[s].product_cell), f"产品名称 = {short}") for s in names[short]]
        findings.append(Finding("S4", "RW20260525003", "critical", "产品名称全称/简称混用",
                                f"全称“{full}”（{len(names[full])} 个 Sheet）与简称“{short}”（{len(names[short])} 个 Sheet）混用",
                                f"统一为完整产品名称“{full}”", anchors=anchors))
        statuses.append(RuleStatus("RW20260525003", "产品名称一致", "不满足", f"{len(names)} 种写法"))
    elif len(names) == 1:
        statuses.append(RuleStatus("RW20260525003", "产品名称一致", "满足", list(names)[0]))
    else:
        statuses.append(RuleStatus("RW20260525003", "产品名称一致", "证据不足", "未解析到产品名称"))


def _chk_half_product_closure(doc, statuses, findings, pass_items):
    proc_names = [doc.headers[s].process_name for s in doc.packaging.get("process_sheets", []) if doc.headers[s].process_name]
    ph = doc.packaging.get("half_products", [])
    unmatched = []
    from ...services import ruleparam as _rp_b2
    _exempt = _rp_b2.option("B-2", "outsource_keywords", ["外购", "直接使用", "免加工"]) or []
    _sheet_text = " ".join((getattr(doc, "text", "") or "").split()) if isinstance(getattr(doc, "text", ""), str) else ""
    for hp in ph:
        # 外购/免加工豁免：说明中标注了豁免关键词则跳过
        if any(k and k in _sheet_text and k in (hp.name or "") for k in _exempt):
            continue
        _hp_norm = ONTO.has_alias(hp.name)
        if not ONTO.has_process(_hp_norm, [ONTO.has_alias(x) for x in proc_names]):
            unmatched.append(hp)
            findings.append(Finding(f"G-{hp.name}", "B-2", "warning", f"半成品无对应工序：{hp.name}",
                                    f"半成品清单含“{hp.name}”，但全部工序 Sheet 无对应制作/处理工序",
                                    "若为外购半成品直接使用需注明来源；若为自制需补充工序",
                                    anchors=[Anchor("包装指示书 ", hp.row, "B", f"半成品 = {hp.name}")]))
    if unmatched:
        statuses.append(RuleStatus("B-2", "半成品工序闭环", "不满足", "无工序：" + "、".join(hp.name for hp in unmatched)))
    elif ph:
        statuses.append(RuleStatus("B-2", "半成品工序闭环", "满足", f"{len(ph)} 项均有对应工序"))
    elif doc.packaging.get("packaging_sheet") and proc_names and bool(_header_alias_fix_on()):
        # L107 D3：有包装指示书 + 工序表，但半成品清单标签未识别 → 证据不足（不静默无结论）
        statuses.append(RuleStatus("B-2", "半成品工序闭环", "证据不足",
                                   "未解析到半成品清单（表头标签/子表头列未识别，不默认放行）"))


def _chk_half_seq(doc, statuses, findings, pass_items):
    ph = doc.packaging.get("half_products", [])
    seqs = sorted(int(hp.seq) for hp in ph if hp.seq and hp.seq.isdigit())
    if seqs:
        from ...services import ruleparam as _rp_c3
        _allow_gap = bool(_rp_c3.option("C-3", "allow_gap", False))
        _start = int(_rp_c3.option("C-3", "start_from", 1) or 1)
        missing = [] if _allow_gap else [n for n in range(max(seqs[0], _start), seqs[-1] + 1) if n not in seqs]
        if missing:
            findings.append(Finding("G3", "C-3", "warning", "半成品清单序号跳号",
                                    f"序号 {seqs} 中缺少 {missing}", "确认缺失序号对应的半成品是否遗漏，或说明跳号原因",
                                    anchors=[Anchor("包装指示书 ", ph[0].row if ph else None, "A", f"序号 {seqs}")]))
            statuses.append(RuleStatus("C-3", "半成品序号连续", "不满足", f"缺少 {missing}"))
        else:
            statuses.append(RuleStatus("C-3", "半成品序号连续", "满足", "连续"))
    elif doc.packaging.get("packaging_sheet") and bool(_header_alias_fix_on()):
        statuses.append(RuleStatus("C-3", "半成品序号连续", "证据不足",
                                   "未解析到半成品清单序号（表头标签未识别，不默认放行）"))


def _chk_material_seq(doc, statuses, findings, pass_items):
    mats = doc.packaging.get("materials", [])
    mat_no_seq = [m for m in mats if not (m.seq and m.seq.strip())]
    if mat_no_seq:
        findings.append(Finding("G4", "C-3", "warning", "包材缺少序号",
                                f"包材“{mat_no_seq[0].name}”无序号（其余包材均有编号）", "补充序号",
                                anchors=[Anchor("包装指示书 ", mat_no_seq[0].row, "B", f"包材 = {mat_no_seq[0].name}")]))
        statuses.append(RuleStatus("C-3", "包材序号", "不满足", f"{len(mat_no_seq)} 项缺序号"))
    elif mats:
        statuses.append(RuleStatus("C-3", "包材序号", "满足", f"{len(mats)} 项均有编号"))
    elif doc.packaging.get("packaging_sheet") and bool(_header_alias_fix_on()):
        statuses.append(RuleStatus("C-3", "包材序号", "证据不足",
                                   "未解析到包材清单（标签/子表头列未识别，不默认放行）"))


def _chk_weight_total(doc, statuses, findings, pass_items):
    ph = doc.packaging.get("half_products", [])
    design_total = doc.packaging.get("design_total")
    if bool(_header_alias_fix_on()) and doc.packaging.get("packaging_sheet") and not ph:
        statuses.append(RuleStatus("B-4", "投料量与总重匹配", "证据不足",
                                   "未解析到半成品清单（表头标签/子表头列未识别，不默认放行）"))
        return
    if bool(_header_alias_fix_on()) and ph and design_total is None:
        statuses.append(RuleStatus("B-4", "投料量与总重匹配", "证据不足",
                                   "未解析到设计总重量（表头标签/列偏移未识别，不默认放行）"))
        return
    if ph and design_total is not None:
        _missing = [hp for hp in ph if hp.weight is None]
        if _missing:
            statuses.append(RuleStatus("B-4", "投料量与总重匹配", "证据不足",
                                       f"{len(_missing)} 项半成品缺重量，不能按 0 计"))
            return
        s = sum(hp.weight for hp in ph)
        from ...services import ruleparam as _rp_b4
        _tol = float(_rp_b4.option("B-4", "weight_tolerance_pct", 5.0))
        _limit = max(0.5, design_total * _tol / 100.0)
        if abs(s - design_total) > _limit:
            findings.append(Finding("G5", "B-4", "warning", "半成品重量合计与设计总重不匹配",
                                    f"半成品重量合计 {s:g}g，设计总重 {design_total:g}g，差异 {abs(s-design_total):g}g"
                                    f"（容差 {_tol:g}%，允许 ±{_limit:g}g）",
                                    "核实各半成品投料量，或说明差异原因（如加工损耗）",
                                    # L71 R3：原 locator 包装指示书 !D1 指向空单元格（row1 只有 A1 标题）；
                                    # 重量合计/设计总重实际在 J4（只修坐标，不改判定）
                                    anchors=[Anchor("包装指示书 ", 4, "J", f"重量合计 = {s:g}g vs 设计总重 = {design_total:g}g")]))
            statuses.append(RuleStatus("B-4", "投料量与总重匹配", "不满足", f"{s:g} vs {design_total:g}"))
        else:
            statuses.append(RuleStatus("B-4", "投料量与总重匹配", "满足", f"{s:g}g"))


def _chk_garlic(doc, statuses, findings, pass_items):
    from ...services import ruleparam as _rp_e3
    _need_spec = bool(_rp_e3.option("E3", "require_spec", True))
    _need_tool = bool(_rp_e3.option("E3", "require_tool", True))
    if not _need_spec and not _need_tool:
        statuses.append(RuleStatus("E3", "蒜泥规格", "不适用", "已关闭规格与器具必填"))
        return
    _found_e3 = False
    for col_a, txt, row in doc.process_text.get("蔬菜前处理", []):
        _txt_n = ONTO.has_alias(txt)
        if ("蒜" in _txt_n) and ("泥" in _txt_n or "末" in _txt_n):
            _found_e3 = True
            _miss_spec = _need_spec and not re.search(r"粒径|细度|\d+(?:\.\d+)?\s*(?:mm|毫米)|目", txt)
            _miss_tool = _need_tool and not re.search(r"刀|砧板|粉碎机|料理机|器具", txt)
            if _miss_spec or _miss_tool:
                findings.append(Finding("G6", "E3", "warning", "蒜泥无规格尺寸",
                                        "“蒜打成蒜泥”标注了器具和作业内容，但未标注细度/粒径规格",
                                        ("补充蒜泥规格，如“蒜打成蒜泥（粒径≤1mm）”" if _miss_spec
                                         else "补注使用器具，如“粉碎机”"),
                                        # L71 R3：原 locator B 列恒空，内容实际在 F 列（只修坐标）
                                        anchors=[Anchor("蔬菜前处理", row, "F", txt[:80])]))
                statuses.append(RuleStatus("E3", "蒜泥规格", "不满足", "无粒径/细度"))
                return
    if not _found_e3:
        statuses.append(RuleStatus("E3", "蒜泥规格", "不适用", "未发现蒜泥工序"))
        return
    pass_items.append({"name": "蒜泥规格", "detail": "蒜泥工序已标注规格/器具"})
    statuses.append(RuleStatus("E3", "蒜泥规格", "满足", "已标注"))


def _chk_chicken(doc, statuses, findings, pass_items):
    from ...services import ruleparam as _rp_e4
    if not bool(_rp_e4.option("E4", "require_wash", True)):
        statuses.append(RuleStatus("E4", "鸡胸肉清洗", "不适用", "已关闭清洗必填"))
        return
    meat_rows = doc.process_text.get("肉类前处理", [])
    chicken_mentioned = any("鸡胸肉" in txt for _, txt, *_ in meat_rows)
    chicken_wash = any("鸡胸肉" in txt and ("清洗" in txt or "去筋膜" in txt or "洗净" in txt) for _, txt, *_ in meat_rows)
    if chicken_mentioned and not chicken_wash:
        row = next((r for _, txt, r in meat_rows if "鸡胸肉" in txt), None)
        findings.append(Finding("G7", "E4", "warning", "鸡胸肉切块前缺少清洗",
                                "鸡胸肉流程为 解冻→切块，缺少“清洗/去筋膜”步骤（清洗仅针对鸡蛋）",
                                "在解冻与切块之间补充“清洗鸡胸肉，去除筋膜杂质”，并注明器具",
                                # L71 R3：原 locator B 列恒空，内容实际在 F 列（只修坐标）
                                anchors=[Anchor("肉类前处理", row, "F", "鸡胸肉缺清洗")]))
        statuses.append(RuleStatus("E4", "鸡胸肉清洗", "不满足", "缺清洗"))
    elif chicken_mentioned:
        pass_items.append({"name": "鸡胸肉清洗", "detail": "鸡胸肉工序包含清洗/去筋膜"})
        statuses.append(RuleStatus("E4", "鸡胸肉清洗", "满足", "已包含清洗"))
    else:
        statuses.append(RuleStatus("E4", "鸡胸肉清洗", "不适用", "未发现鸡胸肉工序"))


def _chk_center_temp(doc, statuses, findings, pass_items):
    from .. import rexec
    hits = [f for f in rexec.extract_numeric_facts(doc.process_text)
            if f.metric == "温度" and f.scope == "中心温度"]
    if not hits:
        statuses.append(RuleStatus("RW20260525005", "加热中心温度达标", "证据不足", "未抽到中心温度"))
        return
    from ...services import ruleparam as _rp
    _th = float(_rp.value("RW20260525005", "value", 85))
    decided, undecided = _temp_facts_celsius(hits)
    bad = [(f, c) for f, c in decided if c < _th]
    if bad:
        _show = "、".join(_fmt_temp_pair(f, c) for f, c in bad[:5])
        findings.append(Finding("P-中心温度", "RW20260525005", "critical", "加热中心温度未达标",
                                f"{len(bad)} 处中心温度 < {_th:g}℃（{_show}）",
                                f"将加热中心温度提高至 ≥{_th:g}℃",
                                anchors=[Anchor(f.sheet, None, None, f.quote) for f, _c in bad]))
        statuses.append(RuleStatus("RW20260525005", "加热中心温度达标", "不满足", f"{len(bad)} 处 <{_th:g}℃"))
    elif undecided:
        _show = "、".join(f"{f.value:g}{f.unit or '（缺单位）'}" for f in undecided[:5])
        statuses.append(RuleStatus("RW20260525005", "加热中心温度达标", "证据不足",
                                   f"{len(undecided)} 处中心温度缺可识别单位，无法核验（{_show}）；不猜单位"))
    else:
        statuses.append(RuleStatus("RW20260525005", "加热中心温度达标", "满足", f"{len(decided)} 处 ≥{_th:g}℃"))


# ---------------------------------------------------------------------------
# L120（2026-11-25）工艺包消毒浓度判据单位归一（P1 修复）
#
# 缺陷：_chk_ppm 直接比较事实层原始数值（`f.value < 200`），把单位当 ppm：
#   「消毒液浓度 200ppb」（=0.2ppm）被当成 200ppm → 假通过（应不满足）；
#   「消毒液浓度 200000ppb」（=200ppm）与 200ppm 同判满足（原也对，但纯属数值巧合）；
#   反过来 0.2ppm 判不满足时 finding detail 只显示数值、看不出单位归一。
# 修复：与温度 D1 同思路，取数后先用统一浓度归一换算到 ppm 再比较：
#   ppm=1、mg/kg=1、ppb=0.001、μg/kg/ug/kg=0.001、g/kg=1000
#   （与 ruleexec 执行器 registry 同源：基准 mg/kg；g/kg=1000 是登记换算，不是猜单位）。
#   单位缺失/未登记 → 不猜（计入不可判定；无违规且存在不可判定事实 → 证据不足）。
# finding detail 显示「原值+归一值」（如 200ppb=0.2ppm），阈值仍按 ppm 口径。
# 开关 RULEPROOF_FOOD_CONC_UNIT_FIX（默认 1；=0 逐字回退旧「原值直接比」行为，A/B 与回滚）。
# ---------------------------------------------------------------------------
def _food_conc_unit_fix_on() -> bool:
    """工艺包消毒浓度单位归一开关（默认开；=0 回退旧口径）。"""
    return str(os.environ.get("RULEPROOF_FOOD_CONC_UNIT_FIX", "1")).strip().lower() not in (
        "0", "false", "off", "no")


# 浓度单位 → ppm 倍率（唯一事实源：与 registry/ruleexec 单位表同源，基准 mg/kg）。
# fail-safe：空白/未登记单位返回 None（不默认按 ppm 比较、不猜单位）。
# 取值与 app/engine/registry.py 的登记倍率一致：mg/kg=1、g/kg=1000（UNIT_SCALE_BASE）、
# ppm=1、ppb/ug/kg=0.001（UNIT_SCALE_FIX2，基准 mg/kg）；μg/kg 与 ug/kg 同物理单位。
_CONC_UNIT_TO_PPM = {
    "ppm": 1.0, "mg/kg": 1.0,
    "ppb": 0.001, "μg/kg": 0.001,
    "g/kg": 1000.0,
}


def _conc_unit_key(unit) -> str:
    """浓度单位规范键：去空白 + NFKC（兼容字符/微符号）+ 大小写归一；未登记返回空串。"""
    raw = str(unit or "").strip()
    if not raw:
        return ""
    try:
        key = unicodedata.normalize("NFKC", raw)
    except (TypeError, ValueError):
        key = raw
    # 去空白（含全角空格）；微符号（U+00B5）与希腊字母 μ 是同一物理单位，统一到 μ 写法
    key = re.sub(r"\s+", "", key).replace("\u3000", "").replace("µ", "μ")
    low = key.lower()
    if low in ("ppm", "ppb", "mg/kg", "g/kg"):
        return low
    if low in ("ug/kg", "μg/kg"):
        return "μg/kg"
    return ""


def _conc_to_ppm(fact):
    """浓度事实 → ppm 值；单位缺失/未登记返回 None（不猜单位、不默认按 ppm 比较）。"""
    key = _conc_unit_key(getattr(fact, "unit", None))
    if not key:
        return None
    try:
        return float(getattr(fact, "value", None)) * _CONC_UNIT_TO_PPM[key]
    except (TypeError, ValueError):
        return None


def _conc_facts_ppm(hits):
    """浓度事实列表 → (可判定 [(fact, ppm)], 不可判定 [fact])；开关关闭时原值按 ppm 返回。"""
    if not _food_conc_unit_fix_on():
        return [(f, f.value) for f in hits], []
    decided, undecided = [], []
    for f in hits:
        p = _conc_to_ppm(f)
        if p is None:
            undecided.append(f)
            continue
        decided.append((f, p))
    return decided, undecided


def _fmt_conc_pair(fact, ppm) -> str:
    """引文/描述展示：原值+原单位（换算值与原值不同/单位非 ppm 时附 ppm 归一值）。"""
    raw = f"{fact.value:g}{getattr(fact, 'unit', '') or ''}"
    if ppm is None:
        return raw
    try:
        same = (abs(float(ppm) - float(fact.value)) < 1e-9
                and str(getattr(fact, "unit", "") or "").strip().lower() == "ppm")
    except (TypeError, ValueError):
        same = False
    return raw if same else f"{raw}={ppm:g}ppm"


def _chk_ppm(doc, statuses, findings, pass_items):
    from .. import rexec
    hits_all = [f for f in rexec.extract_numeric_facts(doc.process_text) if f.metric == "浓度"]
    # L26（2026-11-23）：消毒浓度判据的对象作用域绑定——手部/洗手消毒液（50-100ppm 属人体
    # 卫生更窄规则，数据集 R-LIM-02 明确 exclude）不套「≥200ppm」；环境/工器具/食品接触面
    # 消毒液仍按阈值判。开关 RULEPROOF_DISINFECT_SCOPE_FIX=0 回退旧行为（全部 ppm 参与比较）。
    _scope_fix = rexec._disinfect_scope_fix_on()
    hand = [f for f in hits_all if getattr(f, "conc_scope", "") == "hand"] if _scope_fix else []
    hits = [f for f in hits_all if not (_scope_fix and getattr(f, "conc_scope", "") == "hand")]
    if not hits:
        if hand:
            statuses.append(RuleStatus(
                "RW20260525006", "消毒浓度达标", "不适用",
                f"仅抽到手部/洗手消毒液浓度 {len(hand)} 处（"
                + "、".join(f"{f.value:g}{f.unit}" for f in hand[:3])
                + "）；该判据对象为工器具/环境/食品接触面消毒液，手部消毒液不适用"))
            return
        statuses.append(RuleStatus("RW20260525006", "消毒浓度达标", "证据不足", "未抽到消毒浓度"))
        return
    from ...services import ruleparam as _rp2
    _th2 = float(_rp2.value("RW20260525006", "value", 200))
    decided, undecided = _conc_facts_ppm(hits)
    bad = [(f, ppm) for f, ppm in decided if ppm < _th2]
    if bad:
        if _food_conc_unit_fix_on():
            _show = "、".join(_fmt_conc_pair(f, ppm) for f, ppm in bad[:5])
        else:
            # =0 逐字回退旧描述（原值直接按 ppm 展示，不附归一；A/B 对照可复现）
            _show = ", ".join(f"{f.value:g}ppm" for f, _p in bad[:5])
        findings.append(Finding("P-消毒", "RW20260525006", "warning", "消毒浓度未达标",
                                f"{len(bad)} 处消毒浓度 < {_th2:g}ppm（{_show}）",
                                f"将消毒液浓度提高至 ≥{_th2:g}ppm",
                                anchors=[Anchor(f.sheet, None, None, f.quote) for f, _p in bad]))
        statuses.append(RuleStatus("RW20260525006", "消毒浓度达标", "不满足", f"{len(bad)} 处 <{_th2:g}ppm"))
    elif undecided:
        _show = "、".join(f"{f.value:g}{f.unit or '（缺单位）'}" for f in undecided[:5])
        statuses.append(RuleStatus("RW20260525006", "消毒浓度达标", "证据不足",
                                   f"{len(undecided)} 处消毒浓度单位不可识别，无法核验（{_show}）；不猜单位"))
    else:
        statuses.append(RuleStatus("RW20260525006", "消毒浓度达标", "满足", f"{len(decided)} 处 ≥{_th2:g}ppm"))


def _chk_cooling(doc, statuses, findings, pass_items):
    from .. import rexec
    hits = [f for f in rexec.extract_numeric_facts(doc.process_text)
            if f.metric == "温度" and f.scope == "冷却"]
    if not hits:
        statuses.append(RuleStatus("RW20260525009", "冷却温度达标", "证据不足", "未抽到冷却温度"))
        return
    decided, undecided = _temp_facts_celsius(hits)
    bad = [(f, c) for f, c in decided if c > 10]
    if bad:
        _show = "、".join(_fmt_temp_pair(f, c) for f, c in bad[:5])
        findings.append(Finding("P-冷却", "RW20260525009", "warning", "冷却温度未达标",
                                f"{len(bad)} 处冷却温度 >10℃（{_show}）",
                                "将冷却温度降至 ≤10℃",
                                anchors=[Anchor(f.sheet, None, None, f.quote) for f, _c in bad]))
        statuses.append(RuleStatus("RW20260525009", "冷却温度达标", "不满足", f"{len(bad)} 处 >10℃"))
    elif undecided:
        _show = "、".join(f"{f.value:g}{f.unit or '（缺单位）'}" for f in undecided[:5])
        statuses.append(RuleStatus("RW20260525009", "冷却温度达标", "证据不足",
                                   f"{len(undecided)} 处冷却温度缺可识别单位，无法核验（{_show}）；不猜单位"))
    else:
        statuses.append(RuleStatus("RW20260525009", "冷却温度达标", "满足", f"{len(decided)} 处 ≤10℃"))


def _chk_cold_storage(doc, statuses, findings, pass_items):
    from .. import rexec
    hits = [f for f in rexec.extract_numeric_facts(doc.process_text)
            if f.metric == "温度" and f.scope == "冷藏暂存"]
    if not hits:
        statuses.append(RuleStatus("RW20260525010", "冷藏暂存温度达标", "证据不足", "未抽到冷藏/暂存温度"))
        return
    decided, undecided = _temp_facts_celsius(hits)
    bad = [(f, c) for f, c in decided if c > 8]
    if bad:
        _show = "、".join(_fmt_temp_pair(f, c) for f, c in bad[:5])
        findings.append(Finding("P-冷藏", "RW20260525010", "warning", "冷藏暂存温度超标",
                                f"{len(bad)} 处冷藏/暂存温度 >8℃（{_show}）",
                                "将冷藏/暂存温度降至 ≤8℃",
                                anchors=[Anchor(f.sheet, None, None, f.quote) for f, _c in bad]))
        statuses.append(RuleStatus("RW20260525010", "冷藏暂存温度达标", "不满足", f"{len(bad)} 处 >8℃"))
    elif undecided:
        _show = "、".join(f"{f.value:g}{f.unit or '（缺单位）'}" for f in undecided[:5])
        statuses.append(RuleStatus("RW20260525010", "冷藏暂存温度达标", "证据不足",
                                   f"{len(undecided)} 处冷藏/暂存温度缺可识别单位，无法核验（{_show}）；不猜单位"))
    else:
        statuses.append(RuleStatus("RW20260525010", "冷藏暂存温度达标", "满足", f"{len(decided)} 处 ≤8℃"))


def _thaw_criterion_pending_on() -> bool:
    """解冻口径「待定」开关（B1-L1 T03，2026-11-23；默认开，=0 回退旧口径）。

    背景：解冻时长判据（≥20h，RW20260525011/FOOD01-005）可能是**规则内容错误**，
    尚未经规则 owner 裁决（见 docs/qa/解冻口径裁决路径_20261123.md）。代码侧不改
    判定语义，只对「判据是否适用尚不确定」的情形返回「口径待定/证据不足」：
      · 非冷藏解冻方式（流动水/流动饮用水/流水/室温/常温/微波…）的时长 —— ≥20h 是否适用待裁决；
      · 「解冻后/解冻完成/解冻完毕 Xh 内」= 后续工序时限，不是解冻时长（取数绑定；任何开关下都排除）；
      · 「每 4h 记录/监测」= 频率，不作为解冻时长（取数侧 time_scope 不命中「解冻」）。
    明确冷藏解冻（解冻间/冷藏库/0-4℃ 语境）的时长仍按 ≥20h 判，不在本开关内放宽。
    L26（2026-11-23）：本分支与 manifest 确定性通道 ``ruleexec.judge_limit_rule`` 同口径
    （同一 RULEPROOF_THAW_CRITERION_PENDING 开关 + 同一 rexec._time_scope 取数）。
    """
    import os as _os
    return str(_os.environ.get("RULEPROOF_THAW_CRITERION_PENDING", "1")).strip().lower() \
        not in ("0", "false", "off", "no")


def _chk_thaw(doc, statuses, findings, pass_items):
    from .. import rexec
    # 解冻时长等价写法（h/小时/min/分钟/天…）统一到小时再比较：
    # 原实现只收 h/小时，等价转写「720min」被当成“未抽到解冻时长”而漏判（LaneQ 2026-11-23）。
    # B1-L1 T03（2026-11-23）：按 time_scope（工序+对象）绑定：
    #   - 解冻后处理时限 → 排除（后续工序时限，不是解冻时长）；
    #   - 解冻-非冷藏方式 → 「口径待定/证据不足」（不改判据语义，等业务裁决）；
    #   - 解冻（冷藏解冻语境）→ 仍按 ≥20h 判。
    _pending_on = _thaw_criterion_pending_on()
    hits, pending = [], []
    for f in rexec.extract_numeric_facts(doc.process_text):
        if f.metric != "时间":
            continue
        h = rexec.time_to_hours(f.value, f.unit)
        if h is None:
            continue
        if _pending_on:
            if f.time_scope == "解冻后处理时限":
                continue
            if getattr(f, "frequency", False):
                continue  # 「每 4h 记录/监测」是频率，不是解冻时长（L26）
            if f.time_scope == "解冻-非冷藏方式":
                pending.append((f, h))
                continue
            if f.time_scope != "解冻":
                continue
        else:
            # 回退口径（RULEPROOF_THAW_CRITERION_PENDING=0）：旧的「行内含解冻即取数」，
            # 把解冻后时限/非冷藏方式时长一并当解冻时长比较（L23/L25 旧误报由此复现）。
            if "解冻" not in (getattr(f, "context", "") or ""):
                continue
        hits.append((f, h))
    if not hits and not pending:
        statuses.append(RuleStatus("RW20260525011", "解冻时长达标", "证据不足", "未抽到解冻时长"))
        return
    bad = [(f, h) for f, h in hits if h < 20]
    if bad:
        findings.append(Finding("P-解冻", "RW20260525011", "warning", "解冻时长不足",
                                f"{len(bad)} 处解冻时长 <20h（{', '.join(f'{f.value:g}{f.unit}' for f, _h in bad[:5])}）",
                                "将解冻时长延长至 ≥20h",
                                anchors=[Anchor(f.sheet, None, None, f.quote) for f, _h in bad]))
        statuses.append(RuleStatus("RW20260525011", "解冻时长达标", "不满足", f"{len(bad)} 处 <20h"))
        return
    if pending:
        _vals = "、".join(f"{f.value:g}{f.unit}" for f, _h in pending[:5])
        statuses.append(RuleStatus(
            "RW20260525011", "解冻时长达标", "证据不足",
            "口径待定：解冻时长判据（≥20h）对非冷藏解冻方式（流动水/室温等）是否适用，"
            f"待规则 owner 业务裁决（见 docs/qa/解冻口径裁决路径_20261123.md）；"
            f"已抽到非冷藏解冻时长 {len(pending)} 处（{_vals}），按口径待定记证据不足，不判不满足"))
        return
    statuses.append(RuleStatus("RW20260525011", "解冻时长达标", "满足", f"{len(hits)} 处 ≥20h"))


def _chk_weight_unit(doc, statuses, findings, pass_items):
    from .. import rexec
    d = getattr(doc, "packaging", None)
    if not d:
        statuses.append(RuleStatus("RW20260525012", "重量单位一致性", "不适用", "无包装指示书"))
        return
    # 缺单位不得默认按 g 放行（LaneQ 2026-11-23，fail-safe）：
    # 判据本身就是“单位一致性”，单位被清空/写不可识别 → 证据不足，而不是 silent pass。
    raw_unit = d.get("design_unit")
    unit = rexec.canon_weight_unit(raw_unit)
    if not unit:
        statuses.append(RuleStatus("RW20260525012", "重量单位一致性", "证据不足",
                                   "设计总重量未标注可识别单位，无法核验 kg/g 是否混用"))
        return
    total = d.get("design_total") or 0
    half_sum = sum(h.weight or 0 for h in (d.get("half_products") or []))
    if unit == "kg" and half_sum > 0:
        design_g = total * 1000
        if design_g > half_sum * 10 or design_g < half_sum * 0.1:
            findings.append(Finding("P-单位", "RW20260525012", "warning", "重量单位疑似混淆",
                                    f"设计总重量 {total}{unit}(={design_g:g}g) 与半成品合计 {half_sum:g}g 量级不符，疑似 kg/g 混淆",
                                    "确认设计总重量单位（应为 g）",
                                    # L71 R3：原 locator 包装指示书 !D1 指向空单元格；单位实际在 N4
                                    anchors=[Anchor("包装指示书 ", 4, "N", f"设计总重量 {total}{unit}")]))
            statuses.append(RuleStatus("RW20260525012", "重量单位一致性", "不满足", "kg/g 疑似混淆"))
            return
    statuses.append(RuleStatus("RW20260525012", "重量单位一致性", "满足", f"{total}{unit}"))


def _chk_name_norm(doc, statuses, findings, pass_items):
    import difflib
    known = [i.name for i in ONTO.instances_of("Product")]
    for h in doc.headers.values():
        n = h.product_name.strip()
        if not n or n in known:
            continue
        close = difflib.get_close_matches(n, known, n=1, cutoff=0.6)
        if close:
            findings.append(Finding("P-名称", "RW20260525007", "warning",
                                    f"产品名称疑似错别字：{n}",
                                    f"与已知名称“{close[0]}”相近",
                                    f"确认是否应为“{close[0]}”",
                                    anchors=[Anchor(h.sheet, None, None, f"产品名称 = {n}")]))
            statuses.append(RuleStatus("RW20260525007", "产品名称规范", "不满足", f"{n} 疑似 {close[0]}"))
            return
    statuses.append(RuleStatus("RW20260525007", "产品名称规范", "满足", "名称规范"))


def _collect_pass_items(doc, statuses, findings, pass_items):
    if _any_text_has(doc, "蔬菜前处理", "200ppm", "10min"):
        pass_items.append({"name": "消毒参数", "detail": "200ppm / 10min"})
    if _any_text_has(doc, "蔬菜前处理", "0-8℃") or _any_text_has(doc, "肉类前处理", "0-8℃"):
        pass_items.append({"name": "冷藏温度", "detail": "0-8℃"})
    if _any_text_has(doc, "肉类前处理", "解冻", "0-8℃"):
        pass_items.append({"name": "解冻条件", "detail": "冷藏解冻 + 0-8℃"})


# 执行顺序（数据）：追加规则只需在下面加一行 + 写一个检查函数。
CHECKS = [
    ("RW20260525001", _chk_version_consistency),
    ("RW20260526004", _chk_impl_dates),
    ("RW20260525002", _chk_version_placeholder),
    ("RW20260525002", _chk_signatures),
    ("RW20260525003", _chk_product_name),
    ("B-2", _chk_half_product_closure),
    ("C-3", _chk_half_seq),
    ("C-3", _chk_material_seq),
    ("B-4", _chk_weight_total),
    ("E3", _chk_garlic),
    ("E4", _chk_chicken),
    ("RW20260525005", _chk_center_temp),
    ("RW20260525006", _chk_ppm),
    ("RW20260525007", _chk_name_norm),
    ("RW20260525009", _chk_cooling),
    ("RW20260525010", _chk_cold_storage),
    ("RW20260525011", _chk_thaw),
    ("RW20260525012", _chk_weight_unit),
]


# 半成品 → 工序名称（演示种子，生产环境来自客户实体词典）
PROCESS_ALIASES = {
    "炒卷心菜": "炒卷心菜",
    "炒土豆丝": "炒土豆丝",
    "热处理番茄沙司": "热处理番茄沙司",
    "炒奥尔良鸡块": "炸制、炒奥尔良鸡块",
    "焯水玉米粒": "焯水蔬菜",
    "煎荷包蛋": "煎蛋",
}


def _collect_pass_items(doc, statuses, findings, pass_items):
    if _any_text_has(doc, "蔬菜前处理", "200ppm", "10min"):
        pass_items.append({"name": "消毒参数", "detail": "200ppm / 10min"})
    if _any_text_has(doc, "蔬菜前处理", "0-8℃") or _any_text_has(doc, "肉类前处理", "0-8℃"):
        pass_items.append({"name": "冷藏温度", "detail": "0-8℃"})
    if _any_text_has(doc, "肉类前处理", "解冻", "0-8℃"):
        pass_items.append({"name": "解冻条件", "detail": "冷藏解冻 + 0-8℃"})


# 执行顺序（数据）：追加规则只需在下面加一行 + 写一个检查函数。

# ===========================================================================
# build53 L146（T-⑥ P1）：食品包契约声明
#
# 此前 food.py 只有裸 CHECKS 列表，由 engine.py 硬 import + `__dict__.update`
# 隐式注入；本声明把它登记为正式 pack：
#   - 18 条检查 = 16 条内置规则（RW20260525002 / C-3 各 2 条同码检查）；
#   - doc_types 与审核点库补充层 DT-FOOD「食品工艺书」同名（含既有别名），
#     非食品文档不再进入本包 18 检（由 registry.food_applies 判定）；
#   - golden/switches/engine_min 必须齐备，否则 registry 拒绝安装（fail-closed）。
# 运行期仍由 engine.py 注入通用类型（RuleStatus/Finding/Anchor/…），本文件不反向
# import engine（既有 12 处 services.ruleparam 依赖保留，属 P3 迁移项）。
# ===========================================================================
def build_manifest():
    """食品行业包声明（PackManifest）；每次调用返回新对象。"""
    from .base import PackManifest
    from ..rules_meta import BUILTIN_RULES

    checks = tuple(
        {"code": str(code), "ref": f"app.engine.packs.food:{fn.__name__}",
         "kind": "engine_check"}
        for code, fn in CHECKS
    )
    # 与规则元数据单一事实源对账：18 检必须恰好覆盖 16 条内置规则，一条不多一条不少
    rule_codes = sorted({str(r.get("code")) for r in BUILTIN_RULES})
    check_codes = sorted({entry["code"] for entry in checks})
    if check_codes != rule_codes:
        raise ValueError(
            "food pack 18 检与 rules_meta.BUILTIN_RULES 不一致："
            f"checks-only={sorted(set(check_codes) - set(rule_codes))} "
            f"rules-only={sorted(set(rule_codes) - set(check_codes))}")
    return PackManifest(
        id="food",
        version="1.0.0",
        kind="industry",
        doc_types=("食品工艺书", "工艺书", "生产工艺", "工艺单", "工艺规程", "工序卡"),
        checks=checks,
        parser_hooks=(
            {"hook": "engine.parse_xlsx", "kind": "xlsx_parser",
             "ref": "app.engine.engine:parse_xlsx"},
            {"hook": "engine.build_report", "kind": "xlsx_parser",
             "ref": "app.engine.engine:build_report"},
        ),
        ontology={"kind": "seed_function", "version": "2026-11-25.1",
                  "ref": "app.engine.ontology:seed_food_ontology"},
        golden=(
            {"name": "L68 食品工艺书数据集回归", "kind": "regression_script",
             "ref": "scripts/qa/eval_food_process_datasets.py"},
            {"name": "L69 parse_50 解析回归", "kind": "regression_script",
             "ref": "scripts/qa/eval_food_parse_50_platform.py"},
            {"name": "L74 工艺书四项闭环不变量门", "kind": "assertions",
             "ref": "scripts/qa/food_process_regression.py"},
            {"name": "L107 食品工艺书缺陷专项", "kind": "assertions",
             "ref": "scripts/qa/l107_food_fixes_test.py"},
        ),
        switches=(
            {"name": "RULEPROOF_PACK_FOOD", "kind": "kill_switch", "default": 1,
             "desc": "食品 pack 总开关：默认 1 走注册表；=0 回退旧硬 import 行为"},
            {"name": "RULEPROOF_FOOD_UNIT_FIX", "kind": "feature", "default": 1,
             "desc": "L107 D1 温度判据单位归一（=0 逐字回退）"},
            {"name": "RULEPROOF_FOOD_HEADER_ALIAS", "kind": "rollback", "default": 1,
             "desc": "L107 D3 表头别名/动态偏移（=0 逐字回退）"},
        ),
        engine_min=">=1.5.0",
        layer="builtin",
        description="食品工艺书行业包：旧引擎 18 条确定性检查（16 条内置规则）+ 食品本体/解析钩子登记",
    )
