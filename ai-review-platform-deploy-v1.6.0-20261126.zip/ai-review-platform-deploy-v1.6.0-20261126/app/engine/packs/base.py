# -*- coding: utf-8 -*-
"""行业包（Pack）契约 —— build53 L146（T-⑥ 食品 pack 化 P0/P1 试点）。

本模块只定义**数据契约与校验**，不加载任何具体行业包、不 import 服务层，
因此可以被 registry / 单个 pack / 测试脚本独立复用。

契约字段（任务口径，10 项）：
    id / version / doc_types / checks / parser_hooks / ontology / golden /
    switches / engine_min / validate

约定：
- pack 是**纯声明 + 运行时模块引用**；代码/数据错误必须在 ``validate()`` 阶段
  一次性报全（不静默跳过），registry 对校验失败的包 fail-closed（不安装）。
- ``ref`` 一律使用 ``模块路径:属性名`` 形式，registry 负责解析；解析失败
  = fail-closed（不猜测、不回退到其它包）。
- 未知 pack kind / 未知 check kind / 未知 parser hook kind / 未知 golden kind /
  未知 switch kind 均为校验错误（unknown kind fail-closed）。
- 本文件不产生任何运行时副作用（无 import 服务层、无读环境变量），
  供 engine 在启动阶段决定“加载哪个包 / 是否回退”。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

# ---------------------------------------------------------------------------
# 契约版本与枚举
# ---------------------------------------------------------------------------
PACK_CONTRACT_VERSION = "1.0"

# 合并层级（顺序即优先级：后者覆盖前者）；见 registry.LAYER_ORDER
LAYER_ORDER = ("builtin", "official", "tenant", "workspace")

# pack 类型：目前只有 industry（行业包）；未知值 fail-closed
PACK_KINDS = frozenset({"industry"})
# checks 类型：engine_check = 旧引擎检查函数 (code, fn)；未知值 fail-closed
CHECK_KINDS = frozenset({"engine_check"})
# parser_hooks 类型：声明解析钩子归属（P2 迁移前的登记位，不在本轮改解析器）
PARSER_HOOK_KINDS = frozenset({"xlsx_parser", "text_parser", "doc_parser"})
# golden 回归资产类型
GOLDEN_KINDS = frozenset({"regression_script", "dataset", "assertions"})
# 开关类型
SWITCH_KINDS = frozenset({"kill_switch", "feature", "rollback"})
# ontology 类型
ONTOLOGY_KINDS = frozenset({"seed_function", "data_file"})

_PACK_ID_RE = re.compile(r"^[a-z][a-z0-9_-]{1,31}$")
_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
_ENGINE_MIN_RE = re.compile(r"^(>=\s*)?\d+\.\d+\.\d+$")
_REF_RE = re.compile(r"^[A-Za-z_][\w.]*:[A-Za-z_]\w*$")
_ENV_RE = re.compile(r"^[A-Z][A-Z0-9_]{2,63}$")

# 契约允许的顶层键（未知键 fail-closed；便于发现拼写错误/未登记字段）
_ALLOWED_KEYS = frozenset({
    "id", "version", "kind", "doc_types", "checks", "parser_hooks", "ontology",
    "golden", "switches", "engine_min",
    # 允许的可选治理字段（不参与运行时判定，仅留痕）
    "layer", "description", "based_on", "replaces", "meta",
})


class PackError(Exception):
    """pack 相关错误基类（fail-closed）。"""


class UnknownPackError(PackError):
    """请求了未注册的 pack id（fail-closed，不允许静默回退）。"""


class PackValidationError(PackError):
    """pack 声明校验失败（未知 kind / 字段缺失 / ref 非法等，fail-closed）。"""


def _as_tuple(value: Any) -> tuple:
    if value is None:
        return ()
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def _check_ref(entry: Any, *, where: str, kind_key: str, kinds: frozenset,
               required_keys: tuple = ("ref",)) -> list[str]:
    """校验一条带 kind + ref 的声明；返回错误列表。"""
    errs: list[str] = []
    if not isinstance(entry, dict):
        return [f"{where}: 声明必须是对象（dict），实际 {type(entry).__name__}"]
    kind = str(entry.get("kind") or "").strip()
    if not kind:
        errs.append(f"{where}: 缺少 kind")
    elif kind not in kinds:
        errs.append(f"{where}: 未知 kind={kind!r}（允许 {sorted(kinds)}）")
    for key in required_keys:
        val = entry.get(key)
        if not isinstance(val, str) or not val.strip():
            errs.append(f"{where}: 缺少非空字符串 {key}")
    ref = entry.get("ref")
    if isinstance(ref, str) and ref.strip() and not _REF_RE.match(ref.strip()):
        errs.append(f"{where}: ref={ref!r} 不是 模块:属性 形式")
    return errs


@dataclass
class PackManifest:
    """一个行业包的声明（不可变数据由 validate 保证）。"""

    id: str = ""
    version: str = ""
    kind: str = "industry"
    doc_types: tuple = ()
    checks: tuple = ()
    parser_hooks: tuple = ()
    ontology: Optional[dict] = None
    golden: tuple = ()
    switches: tuple = ()
    engine_min: str = ""
    # ---- 治理留痕（可选，不参与判定）----
    layer: str = "builtin"
    description: str = ""
    based_on: str = ""
    replaces: str = ""
    meta: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    # 契约校验（10 字段；一次性报全，不静默）
    # ------------------------------------------------------------------
    def validate(self) -> list[str]:
        """返回全部校验错误；空列表 = 通过。"""
        errs: list[str] = []
        pid = str(self.id or "").strip()
        if not pid:
            errs.append("id: 不能为空")
        elif not _PACK_ID_RE.match(pid):
            errs.append(f"id: {pid!r} 非法（需小写字母开头，1-32 位 [a-z0-9_-]）")

        ver = str(self.version or "").strip()
        if not ver:
            errs.append("version: 不能为空（semver，如 1.0.0）")
        elif not _SEMVER_RE.match(ver):
            errs.append(f"version: {ver!r} 不是 semver（x.y.z）")

        kind = str(self.kind or "").strip()
        if kind not in PACK_KINDS:
            errs.append(f"kind: 未知 pack kind={kind!r}（允许 {sorted(PACK_KINDS)}）")

        # doc_types：行业包必须声明服务的文档类型（向后兼容的空声明 = 错误）
        doc_types = _as_tuple(self.doc_types)
        if not doc_types:
            errs.append("doc_types: 行业包必须声明至少 1 个文档类型")
        seen_dt: set = set()
        for i, dt in enumerate(doc_types):
            name = str(dt or "").strip()
            if not name:
                errs.append(f"doc_types[{i}]: 不能为空字符串")
                continue
            if name in seen_dt:
                errs.append(f"doc_types[{i}]: 重复声明 {name!r}")
            seen_dt.add(name)

        # checks：18 条检查 / 16 条规则码允许 code 重复（同码多检查），但 (code, ref) 必须唯一
        checks = _as_tuple(self.checks)
        if not checks:
            errs.append("checks: 行业包必须声明至少 1 条检查")
        seen_check: set = set()
        for i, entry in enumerate(checks):
            where = f"checks[{i}]"
            errs.extend(_check_ref(entry, where=where, kind_key="kind",
                                   kinds=CHECK_KINDS,
                                   required_keys=("code", "ref")))
            if isinstance(entry, dict):
                code = str(entry.get("code") or "").strip()
                ref = str(entry.get("ref") or "").strip()
                if code and ref:
                    key = (code, ref)
                    if key in seen_check:
                        errs.append(f"{where}: 重复检查声明 code={code!r} ref={ref!r}")
                    seen_check.add(key)

        # parser_hooks：可为空（本轮不动解析器），声明了就必须合法
        for i, entry in enumerate(_as_tuple(self.parser_hooks)):
            errs.extend(_check_ref(entry, where=f"parser_hooks[{i}]", kind_key="kind",
                                   kinds=PARSER_HOOK_KINDS,
                                   required_keys=("hook", "ref")))

        # ontology：可为空；声明了就必须有 ref/kind/version
        if self.ontology is not None:
            onto = self.ontology
            if not isinstance(onto, dict):
                errs.append("ontology: 必须是对象（dict）或 null")
            else:
                errs.extend(_check_ref(onto, where="ontology", kind_key="kind",
                                       kinds=ONTOLOGY_KINDS,
                                       required_keys=("ref",)))
                if not str(onto.get("version") or "").strip():
                    errs.append("ontology: 缺少 version")

        # golden：必须有回归资产（没有 golden 的包不允许启用）
        golden = _as_tuple(self.golden)
        if not golden:
            errs.append("golden: 行业包必须声明至少 1 项回归资产")
        for i, entry in enumerate(golden):
            where = f"golden[{i}]"
            if not isinstance(entry, dict):
                errs.append(f"{where}: 声明必须是对象（dict）")
                continue
            if not str(entry.get("name") or "").strip():
                errs.append(f"{where}: 缺少 name")
            kind = entry.get("kind")
            if kind is not None and str(kind) not in GOLDEN_KINDS:
                errs.append(f"{where}: 未知 kind={kind!r}（允许 {sorted(GOLDEN_KINDS)}）")
            if not isinstance(entry.get("ref"), str) or not str(entry.get("ref")).strip():
                errs.append(f"{where}: 缺少非空字符串 ref")

        # switches：必须声明 pack 级 kill switch（RULEPROOF_PACK_<ID>）
        switches = _as_tuple(self.switches)
        if not switches:
            errs.append("switches: 行业包必须声明至少 1 个开关（含 pack kill switch）")
        has_kill = False
        for i, entry in enumerate(switches):
            where = f"switches[{i}]"
            if not isinstance(entry, dict):
                errs.append(f"{where}: 声明必须是对象（dict）")
                continue
            name = str(entry.get("name") or "").strip()
            if not name:
                errs.append(f"{where}: 缺少 name")
            elif not _ENV_RE.match(name):
                errs.append(f"{where}: name={name!r} 必须是环境变量形式（大写/数字/下划线）")
            kind = str(entry.get("kind") or "").strip()
            if kind not in SWITCH_KINDS:
                errs.append(f"{where}: 未知 kind={kind!r}（允许 {sorted(SWITCH_KINDS)}）")
            if kind == "kill_switch":
                has_kill = True
            default = entry.get("default")
            if default not in (0, 1, "0", "1", True, False):
                errs.append(f"{where}: default 必须是 0/1")
        if switches and not has_kill:
            errs.append("switches: 缺少 kind=kill_switch 的 pack 级开关（默认 1，可 =0 回退）")

        # engine_min：引擎最低版本（>=x.y.z 或 x.y.z）
        emin = str(self.engine_min or "").strip()
        if not emin:
            errs.append("engine_min: 不能为空（如 >=5.3.0）")
        elif not _ENGINE_MIN_RE.match(emin):
            errs.append(f"engine_min: {emin!r} 非法（需 >=x.y.z 或 x.y.z）")

        # 治理字段
        if str(self.layer or "") not in LAYER_ORDER:
            errs.append(f"layer: 未知层={self.layer!r}（允许 {list(LAYER_ORDER)}）")
        return errs

    # ------------------------------------------------------------------
    def check_codes(self) -> list[str]:
        """按声明顺序返回检查的规则码（保留重复，18 检中同码多检查）。"""
        return [str(c.get("code") or "").strip() for c in _as_tuple(self.checks)
                if isinstance(c, dict)]

    def unique_rule_codes(self) -> list[str]:
        """去重后的规则码（食品包 18 检 → 16 条内置规则）。"""
        seen, out = set(), []
        for code in self.check_codes():
            if code and code not in seen:
                seen.add(code)
                out.append(code)
        return out

    def to_dict(self) -> dict:
        d = asdict(self)
        for key in ("doc_types", "checks", "parser_hooks", "golden", "switches"):
            d[key] = [dict(x) if isinstance(x, dict) else x for x in (d.get(key) or ())]
        return d

    @classmethod
    def from_dict(cls, data: Any, layer: str = "builtin") -> "PackManifest":
        """从 JSON/字典构造；未知字段立即报错（fail-closed），不做静默丢弃。"""
        if not isinstance(data, dict):
            raise PackValidationError(
                f"pack 声明必须是对象（dict），实际 {type(data).__name__}")
        unknown = sorted(set(data.keys()) - _ALLOWED_KEYS)
        if unknown:
            raise PackValidationError(f"pack 声明包含未登记字段：{unknown}")
        kwargs = {k: data.get(k) for k in _ALLOWED_KEYS if k in data}
        kwargs.setdefault("layer", layer)
        kwargs["doc_types"] = _as_tuple(kwargs.get("doc_types"))
        kwargs["checks"] = _as_tuple(kwargs.get("checks"))
        kwargs["parser_hooks"] = _as_tuple(kwargs.get("parser_hooks"))
        kwargs["golden"] = _as_tuple(kwargs.get("golden"))
        kwargs["switches"] = _as_tuple(kwargs.get("switches"))
        kwargs.setdefault("kind", "industry")
        return cls(**kwargs)


@dataclass
class Pack:
    """已解析、可直接注入引擎的行业包。"""

    manifest: PackManifest
    module: Any = None
    checks: tuple = ()          # tuple[(code, callable)]，声明顺序
    process_aliases: dict = field(default_factory=dict)
    collect_pass_items: Any = None
    ontology_loader: Any = None

    @property
    def id(self) -> str:
        return self.manifest.id

    @property
    def version(self) -> str:
        return self.manifest.version

    def inject(self, namespace: dict) -> None:
        """把引擎通用工具/类型注入 pack 模块（与旧 engine.py 行为一致）。"""
        if self.module is None:
            raise PackError("pack 无可注入的运行时模块（builtin 包必须提供 module）")
        self.module.__dict__.update(namespace)


def engine_min_satisfied(min_spec: str, current: str) -> bool:
    """engine_min（>=x.y.z 或 x.y.z）是否被当前引擎版本满足。

    非法格式返回 False（fail-closed）；用于 registry/engine 启动时阻止不兼容包。
    """
    def _parse(v):
        parts = str(v or "").strip().split(".")
        if len(parts) != 3 or not all(p.isdigit() for p in parts):
            return None
        return tuple(int(p) for p in parts)

    spec = str(min_spec or "").strip()
    if not spec or not _ENGINE_MIN_RE.match(spec):
        return False
    required = _parse(spec.replace(">=", "").strip())
    have = _parse(current)
    if required is None or have is None:
        return False
    return have >= required
