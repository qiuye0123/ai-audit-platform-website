# -*- coding: utf-8 -*-
"""Pack 注册表 —— build53 L146（T-⑥ 食品 pack 化 P0/P1 试点）。

职责（P1 最小可验证版）：
1. **发现/校验**：builtin 包（代码内登记，如 food）+ official/tenant/workspace 三层
   JSON 声明（可选目录，见 ``ENV_LAYER_DIRS``）；任何声明先过 ``base.PackManifest.validate()``，
   失败 → 记入 ``Registry.errors`` 且**不安装**（fail-closed，不静默跳过）。
2. **合并顺序**：``builtin < official < tenant < workspace``，同 id 后者覆盖前者
   （覆盖来源记录在 ``Registry.source_of``，便于审计；不改变判定语义）。
3. **未知 / 未知 kind fail-closed**：``Registry.get(未知 id)`` 抛 ``UnknownPackError``；
   包内出现未知 check/parser/golden/switch/ontology kind → 校验失败，包不安装。
4. **运行时解析**：把 ``模块:属性`` ref 解析成真实函数/对象；任一 ref 解析失败 →
   ``PackValidationError``（不猜测、不回退到其它包）。
5. **食品包适用性（P0 非食品隔离）**：``food_applies()`` 用**平台现有 doc_type / 业务域
   判断**（审核上下文显式 doc_type → 工作空间文件类型 → 审核点库确定性路由），
   只对判定为食品工艺书的文档进入旧引擎 18 检；非食品/无法判定 → 跳过（fail-closed）。

开关（可 =0 逐字回退旧行为）：
- ``RULEPROOF_PACK_FOOD``：默认 "1"；"0" 时 engine 走旧硬 import 路径（不经过本注册表）。
- ``RULEPROOF_PACK_OFFICIAL_DIR`` / ``RULEPROOF_PACK_TENANT_DIR`` /
  ``RULEPROOF_PACK_WORKSPACE_DIR``：三层外部 pack 声明目录（``*.json``）。
- ``RULEPROOF_PACK_NO_BUILTIN``：测试/故障注入用；"1" 时不登记 builtin 包
  （用于验证「pack 未知时 fail-closed，不静默回退」）。

分层约定：本模块属于 engine 层；只在需要宿主判断时**懒加载** services
（``app.services.ctx`` / ``app.services.workspaces`` / ``app.services.auditpoints``），
加载失败按“无法判定”处理（fail-closed），不阻塞引擎独立运行。
"""
from __future__ import annotations

import importlib
import json
import logging
import os
from pathlib import Path

from .base import (
    LAYER_ORDER,
    Pack,
    PackError,
    PackManifest,
    PackValidationError,
    UnknownPackError,
)

LOG = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 开关 / 环境变量（字面量读取：开关注册表 gate 按字面量静态扫描）
# ---------------------------------------------------------------------------
ENV_PACK_FOOD = "RULEPROOF_PACK_FOOD"
ENV_NO_BUILTIN = "RULEPROOF_PACK_NO_BUILTIN"
ENV_LAYER_DIRS = {
    "official": "RULEPROOF_PACK_OFFICIAL_DIR",
    "tenant": "RULEPROOF_PACK_TENANT_DIR",
    "workspace": "RULEPROOF_PACK_WORKSPACE_DIR",
}

FOOD_PACK_ID = "food"
FOOD_PACK_VERSION = "1.0.0"
# 旧引擎 18 检 = 16 条内置规则（同码多检查：RW20260525002 / C-3 各 2 条）
FOOD_CHECK_COUNT = 18
FOOD_RULE_COUNT = 16


def _switch_on(name: str, default: str = "1") -> bool:
    raw = os.environ.get(name, default)
    if raw is None or str(raw).strip() == "":
        return True
    return str(raw).strip().lower() not in ("0", "false", "off", "no")


def pack_switch_env(pack_id: str) -> str:
    """pack 级 kill switch 环境变量名：RULEPROOF_PACK_<ID>（id 大写、- → _）。"""
    return "RULEPROOF_PACK_" + str(pack_id or "").strip().upper().replace("-", "_")


# ---------------------------------------------------------------------------
# 声明载入
# ---------------------------------------------------------------------------
def _load_decl_dir(directory: str, layer: str) -> tuple[list[PackManifest], list[str]]:
    """读取一层 JSON 声明目录：每个 ``*.json`` 可以是单个 pack 对象或 {"packs": [...]}。

    返回 (manifests, errors)；单文件格式/字段错误只记录错误（该包不安装），
    不让整层静默失效。
    """
    manifests: list[PackManifest] = []
    errors: list[str] = []
    if not directory:
        return manifests, errors
    root = Path(directory).expanduser()
    if not root.is_dir():
        # 显式配置了目录却不存在 → 记错误（fail-closed），不静默忽略
        errors.append(f"layer={layer}: 声明目录不存在：{root}")
        return manifests, errors
    for path in sorted(root.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001 - 声明文件不可读 → fail-closed
            errors.append(f"layer={layer}: {path.name} JSON 解析失败：{type(exc).__name__}: {exc}")
            continue
        items = data.get("packs") if isinstance(data, dict) and "packs" in data else data
        if isinstance(items, dict):
            items = [items]
        if not isinstance(items, list) or not items:
            errors.append(f"layer={layer}: {path.name} 未包含 pack 声明（对象/数组）")
            continue
        for i, item in enumerate(items):
            try:
                manifest = PackManifest.from_dict(item, layer=layer)
            except PackValidationError as exc:
                errors.append(f"layer={layer}: {path.name}[{i}] 构造失败：{exc}")
                continue
            errs = manifest.validate()
            if errs:
                errors.extend(f"layer={layer}: {path.name}[{i}] id={manifest.id!r}: {e}"
                              for e in errs)
                continue
            manifests.append(manifest)
    return manifests, errors


def _builtin_manifests() -> tuple[list[PackManifest], list[str]]:
    """builtin 层：代码内登记的包（当前只有 food）。"""
    manifests: list[PackManifest] = []
    errors: list[str] = []
    if _switch_on(ENV_NO_BUILTIN, "0"):
        return manifests, errors
    try:
        food_mod = importlib.import_module("app.engine.packs.food")
    except Exception as exc:  # noqa: BLE001 - builtin 包缺失/语法错误 → fail-closed
        errors.append(f"builtin: food 包导入失败：{type(exc).__name__}: {exc}")
        return manifests, errors
    builder = getattr(food_mod, "build_manifest", None)
    if not callable(builder):
        errors.append("builtin: food 包缺少 build_manifest()")
        return manifests, errors
    try:
        manifest = builder()
    except Exception as exc:  # noqa: BLE001
        errors.append(f"builtin: food.build_manifest() 失败：{type(exc).__name__}: {exc}")
        return manifests, errors
    if not isinstance(manifest, PackManifest):
        errors.append("builtin: food.build_manifest() 必须返回 PackManifest")
        return manifests, errors
    manifest.layer = "builtin"
    errs = manifest.validate()
    if errs:
        errors.extend(f"builtin: food: {e}" for e in errs)
        return manifests, errors
    manifests.append(manifest)
    return manifests, errors


# ---------------------------------------------------------------------------
# 合并 / 注册表
# ---------------------------------------------------------------------------
def merge_manifests(layers: dict) -> tuple[dict, dict, list[str]]:
    """按 builtin<official<tenant<workspace 顺序合并声明。

    返回 (pack id → manifest, pack id → 来源层, errors)。同 id 后者覆盖前者；
    覆盖声明里的 ``replaces``（若填写）必须等于被覆盖版本，否则报错（fail-closed）。
    """
    merged: dict[str, PackManifest] = {}
    source_of: dict[str, str] = {}
    errors: list[str] = []
    for layer in LAYER_ORDER:
        for manifest in layers.get(layer) or []:
            pid = manifest.id
            if pid in merged:
                prev = merged[pid]
                if manifest.replaces and manifest.replaces != prev.version:
                    errors.append(
                        f"layer={layer}: pack {pid!r} replaces={manifest.replaces!r} "
                        f"与被覆盖版本 {prev.version!r} 不一致")
                    continue
                LOG.info("pack override: id=%s %s(%s) → %s(%s)",
                         pid, prev.layer, prev.version, layer, manifest.version)
            merged[pid] = manifest
            source_of[pid] = layer
    return merged, source_of, errors


class Registry:
    """已合并的 pack 注册表（不可变快照；engine 启动时创建一次）。"""

    def __init__(self, manifests: dict, source_of: dict, errors: list[str],
                 layer_files: dict | None = None):
        self.manifests = dict(manifests)
        self.source_of = dict(source_of)
        self.errors = list(errors)
        self.layer_files = dict(layer_files or {})
        self._resolved: dict[str, Pack] = {}

    # -- 查询 ----------------------------------------------------------
    def available(self) -> list[dict]:
        out = []
        for pid in sorted(self.manifests):
            m = self.manifests[pid]
            out.append({"id": pid, "version": m.version, "kind": m.kind,
                        "layer": self.source_of.get(pid) or m.layer,
                        "doc_types": list(m.doc_types),
                        "checks": len(m.checks),
                        "rules": len(m.unique_rule_codes()),
                        "switches": [str(s.get("name")) for s in m.switches
                                     if isinstance(s, dict)]})
        return out

    def has(self, pack_id: str) -> bool:
        return str(pack_id) in self.manifests

    def get_manifest(self, pack_id: str) -> PackManifest:
        pid = str(pack_id or "").strip()
        if pid not in self.manifests:
            raise UnknownPackError(
                f"未注册的 pack: {pid!r}（已安装：{sorted(self.manifests)}）；"
                f"拒绝静默回退")
        return self.manifests[pid]

    def switch_on(self, pack_id: str) -> bool:
        """pack 级 kill switch：默认取声明 default（1=开）；=0 回退旧行为。"""
        manifest = self.get_manifest(pack_id)
        default = "1"
        for sw in manifest.switches:
            if isinstance(sw, dict) and sw.get("kind") == "kill_switch":
                default = str(sw.get("default", "1"))
                break
        return _switch_on(pack_switch_env(pack_id), default)

    # -- 解析 ----------------------------------------------------------
    @staticmethod
    def resolve_ref(ref: str):
        """``模块:属性`` → 对象；解析失败抛 PackValidationError（fail-closed）。"""
        text = str(ref or "").strip()
        if ":" not in text:
            raise PackValidationError(f"ref={ref!r} 不是 模块:属性 形式")
        module_path, attr_path = text.split(":", 1)
        try:
            obj = importlib.import_module(module_path)
        except Exception as exc:  # noqa: BLE001
            raise PackValidationError(
                f"ref={ref!r} 模块导入失败：{type(exc).__name__}: {exc}") from exc
        for part in attr_path.split("."):
            try:
                obj = getattr(obj, part)
            except AttributeError as exc:
                raise PackValidationError(
                    f"ref={ref!r} 属性不存在：{part}") from exc
        return obj

    def resolve(self, pack_id: str) -> Pack:
        """解析为可注入引擎的 Pack；同 id 缓存（一个进程内引用稳定）。"""
        pid = str(pack_id or "").strip()
        if pid in self._resolved:
            return self._resolved[pid]
        manifest = self.get_manifest(pid)
        checks = []
        modules: set = set()
        for i, entry in enumerate(manifest.checks):
            code = str(entry.get("code") or "").strip()
            ref = str(entry.get("ref") or "").strip()
            fn = self.resolve_ref(ref)
            if not callable(fn):
                raise PackValidationError(f"pack={pid!r} checks[{i}] ref={ref!r} 不可调用")
            checks.append((code, fn))
            modules.add(ref.split(":", 1)[0])
        if len(modules) != 1:
            raise PackValidationError(
                f"pack={pid!r} checks 必须来自同一运行时模块，实际 {sorted(modules)}")
        module = importlib.import_module(next(iter(modules)))
        process_aliases = getattr(module, "PROCESS_ALIASES", None)
        if not isinstance(process_aliases, dict):
            raise PackValidationError(f"pack={pid!r} 模块缺少 PROCESS_ALIASES(dict)")
        collect = getattr(module, "_collect_pass_items", None)
        if not callable(collect):
            raise PackValidationError(f"pack={pid!r} 模块缺少 _collect_pass_items()")
        ontology_loader = None
        if manifest.ontology:
            ontology_loader = self.resolve_ref(manifest.ontology.get("ref"))
        pack = Pack(manifest=manifest, module=module, checks=tuple(checks),
                    process_aliases=dict(process_aliases),
                    collect_pass_items=collect, ontology_loader=ontology_loader)
        self._resolved[pid] = pack
        return pack

    # -- 食品包适用性（P0 非食品隔离）----------------------------------
    def food_applies(self, path: str = "", doc=None) -> dict:
        """判断当前文档是否应进入食品 18 检（只用于平台真实审核上下文）。

        判定只使用**平台既有的显式 doc_type / 业务域信号**（不根据正文内容猜行业）：
          1. 非平台审核上下文（如直接 import engine 的脚本/测试）→ 保持旧行为
             （applies=True，reason=no_platform_audit_context）。这是 P1 逐字节等价的前提：
             库直接调用（L107/L121/评测脚本）行为不变。
          2. 审核上下文显式文档类型（按以下优先级，均为平台已有数据，不是推断）：
               a) 本次审核选择（project.audit(doc_type=...) / CLI --type / UI 审核弹窗）
               b) 项目记录上的文件类型（audit_case.document_type / audit_type）
             食品工艺书类 → applies=True；其它已声明类型 → applies=False。
          3. 工作空间配置的主文件类型（workspaces.get_settings.doc_types）：
               全部为食品类型 → True；非空且不含食品类型 → False。
          4. 以上都没有（未选择/未配置）→ **fail-closed 跳过**（不猜文档类型）。
             审核点库确定性路由结果只作为判定证据记录（route 字段），不用于把陌生
             文档送进食品 18 检——L135 探针已证明含「冷却/消毒」词的化工工艺书会被
             路由识别成食品工艺书，用路由作 ON 依据会继续跨行业误报。
        返回 dict：applies / reason / pack / doc_type / business_domain / route。
        """
        out = {"applies": True, "pack": FOOD_PACK_ID, "reason": "legacy",
               "doc_type": "", "business_domain": "", "route": {}}
        try:
            state = _host_audit_state()
        except Exception:  # noqa: BLE001 - 宿主不可用 = 非平台上下文（保持旧行为）
            out["reason"] = "host_unavailable_legacy"
            return out
        out["doc_type"] = state.get("doc_type") or ""
        if not state.get("platform_audit"):
            out["reason"] = "no_platform_audit_context"
            return out
        food_types = self._food_doc_type_names()
        explicit = str(state.get("doc_type") or "").strip()
        source = "audit_selection"
        if not explicit:
            case_type, case_source = _case_document_type(state.get("case") or "")
            explicit, source = case_type, case_source
        if explicit:
            if _is_food_doc_type(explicit, food_types):
                out.update(applies=True, reason="explicit_food_doc_type",
                           doc_type=explicit, business_domain=_business_domain(explicit))
            else:
                out.update(applies=False, reason="explicit_non_food_doc_type",
                           doc_type=explicit, business_domain=_business_domain(explicit))
            out["doc_type_source"] = source
            return out
        # 工作空间主文件类型
        try:
            from ...services import workspaces as _ws
            settings = _ws.get_settings(state.get("workspace_id") or "") or {}
            ws_types = [str(x).strip() for x in (settings.get("doc_types") or [])
                        if str(x).strip()]
        except Exception:  # noqa: BLE001 - 读不到工作空间 = 无法判定
            ws_types = []
        if ws_types:
            if all(_is_food_doc_type(t, food_types) for t in ws_types):
                out.update(applies=True, reason="workspace_food_domain",
                           doc_type=ws_types[0],
                           business_domain=_business_domain(ws_types[0]))
                out["doc_type_source"] = "workspace.doc_types"
                return out
            if not any(_is_food_doc_type(t, food_types) for t in ws_types):
                out.update(applies=False, reason="workspace_non_food_domain",
                           doc_type=ws_types[0],
                           business_domain=_business_domain(ws_types[0]))
                out["doc_type_source"] = "workspace.doc_types"
                return out
        # 证据：记录既有确定性路由结果（不参与 ON 判定，仅供审计/报告解释）
        route = {}
        try:
            text = _document_text(path, doc)
            from ...services import auditpoints as _ap
            route = _ap.routed_point_ids(text) if text else {"ok": False, "reason": "no_text"}
        except Exception as exc:  # noqa: BLE001 - 路由不可用不影响 fail-closed 结论
            route = {"ok": False, "reason": f"route_error:{type(exc).__name__}"}
        out["route"] = {k: route.get(k) for k in ("ok", "reason", "doc_type")}
        out.update(applies=False, reason="unknown_doc_type_fail_closed")
        return out

    def _food_doc_type_names(self) -> tuple:
        try:
            manifest = self.get_manifest(FOOD_PACK_ID)
        except UnknownPackError:
            return ()
        return tuple(str(x).strip() for x in manifest.doc_types if str(x).strip())


# ---------------------------------------------------------------------------
# 宿主态 / 文档类型（全部懒加载 services，失败按无法判定处理）
# ---------------------------------------------------------------------------
def _host_audit_state() -> dict:
    """当前线程的平台审核上下文（tenant/workspace/mode/doc_type/case）。"""
    from ...services import ctx as _ctx
    snap = _ctx.snapshot()
    return {
        "tenant": snap.get("tenant_id") or "",
        "workspace_id": snap.get("workspace_id") or "",
        "mode": snap.get("mode") or "",
        "doc_type": snap.get("doc_type") or "",
        "case": snap.get("case") or "",
        # 平台真实审核：project.audit 会同时设置 mode 与 case；库/脚本直调两者皆空
        "platform_audit": bool((snap.get("mode") or "") in ("manual", "assisted")
                               and (snap.get("case") or "")),
    }


def _case_document_type(case_id: str) -> tuple[str, str]:
    """项目记录上的显式文件类型（audit_case.document_type → audit_type）。

    只读；读取失败返回 ("", "")（由调用方按“未选择”fail-closed 处理）。
    """
    if not case_id:
        return "", ""
    try:
        from ... import repositories as _R
        case = _R.cases.get(case_id) or {}
    except Exception:  # noqa: BLE001 - 项目不可读 = 未选择
        return "", ""
    for key, label in (("document_type", "case.document_type"),
                       ("audit_type", "case.audit_type")):
        val = str(case.get(key) or "").strip()
        if val:
            return val, label
    return "", ""


def _business_domain(doc_type: str) -> str:
    try:
        from ...services import workspaces as _ws
        return _ws.base_type_of(doc_type)
    except Exception:  # noqa: BLE001 - 业务域不可用不参与 fail-closed 判定
        return ""


def _is_food_doc_type(doc_type: str, food_types: tuple) -> bool:
    name = str(doc_type or "").strip()
    if not name:
        return False
    return name in set(food_types)


def _document_text(path: str, doc=None) -> str:
    """待判定文档文本：xlsx 用 deepparse 统一解析（与主链路由同一输入）。"""
    if doc is not None:
        try:
            parts = [str(getattr(doc, "path", "") or "")]
            for header in (getattr(doc, "headers", None) or {}).values():
                for attr in ("impl_date", "version", "product_name", "process_name"):
                    val = getattr(header, attr, None)
                    if val:
                        parts.append(str(val))
            for sheet, rows in (getattr(doc, "process_text", None) or {}).items():
                parts.append(str(sheet))
                for row in rows or []:
                    try:
                        parts.append(str(row[1]))
                    except (IndexError, TypeError):
                        continue
            return "\n".join(parts)
        except Exception:  # noqa: BLE001 - 字符串化失败退回文件解析
            pass
    if not path:
        return ""
    try:
        from ..deepparse import parse_document
        parsed = parse_document(path)
        return getattr(parsed, "text", "") or ""
    except Exception:  # noqa: BLE001
        return ""


# ---------------------------------------------------------------------------
# 工厂 / 默认注册表
# ---------------------------------------------------------------------------
def load_registry(official_dir: str = "", tenant_dir: str = "", workspace_dir: str = "",
                  extra_layers: dict | None = None) -> Registry:
    """按层级载入并合并全部声明；返回 Registry（errors 非空也返回，由 engine 决定）."""
    layers: dict[str, list] = {name: [] for name in LAYER_ORDER}
    errors: list[str] = []
    builtin, berrs = _builtin_manifests()
    layers["builtin"] = builtin
    errors.extend(berrs)
    dirs = {
        "official": official_dir or os.environ.get(ENV_LAYER_DIRS["official"], ""),
        "tenant": tenant_dir or os.environ.get(ENV_LAYER_DIRS["tenant"], ""),
        "workspace": workspace_dir or os.environ.get(ENV_LAYER_DIRS["workspace"], ""),
    }
    layer_files: dict[str, str] = {}
    for layer in ("official", "tenant", "workspace"):
        directory = dirs.get(layer) or ""
        if not directory:
            continue
        layer_files[layer] = directory
        manifests, lerrs = _load_decl_dir(directory, layer)
        layers[layer] = manifests
        errors.extend(lerrs)
    for layer, manifests in (extra_layers or {}).items():
        if layer not in LAYER_ORDER or layer == "builtin":
            errors.append(f"extra_layers: 非法层 {layer!r}（允许 {list(LAYER_ORDER[1:])}）")
            continue
        for manifest in manifests or []:
            errs = manifest.validate()
            if errs:
                errors.extend(f"layer={layer}: {manifest.id!r}: {e}" for e in errs)
                continue
            manifest.layer = layer
            layers[layer].append(manifest)
    merged, source_of, merrs = merge_manifests(layers)
    errors.extend(merrs)
    return Registry(merged, source_of, errors, layer_files)


_DEFAULT: Registry | None = None


def get_default_registry() -> Registry:
    """进程内默认注册表（engine 启动时创建；测试可 reset）。"""
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = load_registry()
    return _DEFAULT

