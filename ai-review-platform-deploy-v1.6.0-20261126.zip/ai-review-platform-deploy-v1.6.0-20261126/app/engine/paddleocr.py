# -*- coding: utf-8 -*-
"""PaddleOCR-VL 异步 Job 客户端（PaddleOCR AI Studio API）。

只在配置了 token 时启用；未配置/网络失败返回明确错误，不伪造 OCR 成功。
密钥来源优先级：model_config(paddleocr/OCR) → 环境变量。
"""
from __future__ import annotations
import json
import logging
import os
import re
import time
from pathlib import Path

from .ocr import DEFAULT_PADDLE_OCR_MODEL, ocr_model

DEFAULT_JOB_URL = "https://paddleocr.aistudio-app.com/api/v2/ocr/jobs"
# build49 B0：模型 ID 默认值/读取点统一在 app/engine/ocr.py（单一真相源），本模块只做别名兼容。
DEFAULT_MODEL = DEFAULT_PADDLE_OCR_MODEL


def _cfg() -> dict:
    base = os.environ.get("RULEPROOF_OCR_BASE_URL", "").strip()
    token = (os.environ.get("RULEPROOF_OCR_TOKEN", "")
             or os.environ.get("RULEPROOF_OCR_API_KEY", "")).strip()
    # build49 B0：不再直接读 RULEPROOF_OCR_MODEL（与专用 OCR 通道共用同名变量的矛盾已修）；
    # 改走 ocr.ocr_model("paddle")：RULEPROOF_PADDLE_OCR_MODEL，默认 PaddleOCR-VL-1.6，
    # 兼容旧单变量写法（仅当 RULEPROOF_OCR_MODEL 显式配置为 Paddle 模型时沿用）。
    model = ocr_model("paddle")
    try:
        from .. import db
        with db.session() as c:
            row = c.execute(
                "SELECT base_url,api_key,model_id FROM model_config "
                "WHERE enabled=1 AND (LOWER(provider) LIKE '%paddle%' "
                "OR LOWER(model_id) LIKE '%paddleocr%') "
                "ORDER BY created_at DESC LIMIT 1").fetchone()
        if row and row["api_key"]:
            base = row["base_url"] or base
            token = row["api_key"] or token
            model = row["model_id"] or model
    except Exception:
        logging.getLogger(__name__).debug("paddleocr config read skipped", exc_info=True)
    return {"base_url": (base or DEFAULT_JOB_URL).rstrip("/"), "token": token, "model": model or DEFAULT_MODEL}


def configured() -> bool:
    return bool(_cfg().get("token"))


def status() -> dict:
    c = _cfg()
    return {"configured": bool(c.get("token")), "provider": "paddleocr",
            "mode": "paddleocr-vl" if c.get("token") else "none",
            "endpoint": c.get("base_url"), "model": c.get("model"),
            "reason": "" if c.get("token") else "未配置 PaddleOCR Token（RULEPROOF_OCR_TOKEN 或模型配置）"}


def _requests():
    try:
        import requests  # noqa
        return requests
    except Exception as e:
        raise RuntimeError("requests 未安装，无法调用 PaddleOCR") from e


def run_pdf(path: str, cfg: dict | None = None, max_pages: int = 20, timeout_s: int = 600) -> dict:
    """PDF 优先走逐页图片 OCR（PaddleOCR PDF 直传在某些文件上返回 500）。"""
    try:
        from . import pdf_render
        imgs = pdf_render.render_pdf_pages(path, max_pages=max_pages)
    except Exception as e:
        return {"ok": False, "text": "", "pages": 0,
                "reason": f"PDF 转图失败：{type(e).__name__}: {e}", "provider": "paddleocr"}
    if not imgs:
        return {"ok": False, "text": "", "pages": 0, "reason": "PDF 未渲染出页面", "provider": "paddleocr"}
    parts, errs, used = [], [], 0
    for i, ip in enumerate(imgs):
        r = run_file(ip, cfg=cfg, timeout_s=max(120, timeout_s // max(1, len(imgs)) + 60))
        if r.get("ok") and (r.get("text") or "").strip():
            used += 1
            txt = r.get("text") or ""
            # 单页图片 API 已带 [第1页]，替换为 PDF 的真实页码
            txt = txt.replace("[第1页]", f"[第{i + 1}页]", 1)
            parts.append(txt)
        else:
            errs.append(str(r.get("reason") or "失败")[:100])
    if not parts:
        return {"ok": False, "text": "", "pages": len(imgs),
                "reason": "；".join(errs[:3]) or "PaddleOCR 未返回文本", "provider": "paddleocr"}
    return {"ok": True, "text": "\n\n".join(parts), "pages": len(imgs),
            "reason": f"PaddleOCR 成功 {used}/{len(imgs)} 页（逐页图片）",
            "provider": "paddleocr"}


def run_file(path: str, cfg: dict | None = None, timeout_s: int = 600) -> dict:
    """提交本地文件并轮询结果；PDF 直传（失败时调用方可用 run_pdf 降级）。"""
    c = cfg or _cfg()
    if not c.get("token"):
        return {"ok": False, "text": "", "pages": 0, "reason": "PaddleOCR 未配置 Token", "provider": "paddleocr"}
    p = Path(path)
    if not p.is_file():
        return {"ok": False, "text": "", "pages": 0, "reason": "文件不存在", "provider": "paddleocr"}
    try:
        requests = _requests()
    except Exception as e:
        return {"ok": False, "text": "", "pages": 0, "reason": str(e), "provider": "paddleocr"}
    headers = {"Authorization": "Bearer " + c["token"]}
    payload = {"useDocOrientationClassify": False, "useDocUnwarping": False, "useChartRecognition": False}
    job_url = c["base_url"] + "/jobs" if c["base_url"].endswith("/ocr") else c["base_url"]
    # 兼容用户给的完整 jobs URL，也兼容配置成 .../ocr
    if not job_url.endswith("/jobs"):
        job_url = job_url.rstrip("/") + "/jobs"
    _mime = {"pdf": "application/pdf", "png": "image/png", "jpg": "image/jpeg",
             "jpeg": "image/jpeg", "webp": "image/webp", "gif": "image/gif",
             "bmp": "image/bmp"}.get(p.suffix.lower().lstrip("."), "application/octet-stream")
    try:
        with p.open("rb") as f:
            r = requests.post(job_url, headers=headers,
                              data={"model": c["model"], "optionalPayload": json.dumps(payload, ensure_ascii=False)},
                              files={"file": (p.name, f, _mime)}, timeout=(20, 120))
        if r.status_code != 200:
            return {"ok": False, "text": "", "pages": 0,
                    "reason": f"OCR 提交失败 HTTP {r.status_code}: {r.text[:200]}", "provider": "paddleocr"}
        body = r.json() or {}
        job_id = ((body.get("data") or {}).get("jobId") or "")
        if not job_id:
            return {"ok": False, "text": "", "pages": 0,
                    "reason": "OCR 未返回 jobId", "provider": "paddleocr"}
    except Exception as e:
        return {"ok": False, "text": "", "pages": 0,
                "reason": f"OCR 提交异常：{type(e).__name__}: {e}", "provider": "paddleocr"}
    deadline = time.time() + max(30, int(timeout_s))
    state = "pending"; data = {}; last_err = ""
    while time.time() < deadline:
        try:
            jr = requests.get(job_url + "/" + job_id, headers=headers, timeout=(20, 60))
            if jr.status_code != 200:
                return {"ok": False, "text": "", "pages": 0,
                        "reason": f"OCR 轮询 HTTP {jr.status_code}: {jr.text[:200]}",
                        "provider": "paddleocr", "job_id": job_id}
            data = (jr.json() or {}).get("data") or {}
            state = str(data.get("state") or "").lower()
            if state in ("done", "failed"):
                break
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
        time.sleep(2)
    if state != "done":
        reason = (data.get("errorMsg") or last_err or ("OCR 超时" if state not in ("failed",) else "OCR 失败"))
        return {"ok": False, "text": "", "pages": 0, "reason": str(reason)[:300],
                "provider": "paddleocr", "job_id": job_id, "state": state}
    try:
        url = ((data.get("resultUrl") or {}).get("jsonUrl") or "")
    except Exception:
        url = ""
    if not url:
        return {"ok": False, "text": "", "pages": 0, "reason": "OCR 完成但无 resultUrl",
                "provider": "paddleocr", "job_id": job_id}
    try:
        jr = requests.get(url, timeout=(20, 120))
        jr.raise_for_status()
        text, pages = _parse_jsonl(jr.text)
    except Exception as e:
        return {"ok": False, "text": "", "pages": 0, "reason": f"OCR 结果下载失败：{type(e).__name__}",
                "provider": "paddleocr", "job_id": job_id}
    if not text.strip():
        return {"ok": False, "text": "", "pages": pages, "reason": "OCR 返回空文本",
                "provider": "paddleocr", "job_id": job_id}
    return {"ok": True, "text": text, "pages": pages, "reason": f"PaddleOCR 成功 {pages} 页",
            "provider": "paddleocr", "job_id": job_id}


def _clean_markdown(md: str) -> str:
    """去掉 PaddleOCR 返回的图片占位 HTML，保留文字/表格文本。"""
    t = re.sub(r"<div[^>]*>.*?</div>", "", str(md or ""), flags=re.S | re.I)
    t = re.sub(r"<[^>]+>", "", t)
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", t)
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def _parse_jsonl(raw: str) -> tuple[str, int]:
    parts: list[str] = []
    pages = 0
    for line in str(raw or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        result = obj.get("result") or obj
        for res in (result.get("layoutParsingResults") or []):
            md = ((res.get("markdown") or {}).get("text") or "")
            md = _clean_markdown(md)
            if md.strip():
                pages += 1
                parts.append(f"[第{pages}页]\n{md.strip()}")
    return "\n\n".join(parts), pages
