"""
规则 schema v0：10 类参数化条款模板 + 自然语言分类/槽位填充。

原则（方案 v2）：放弃自由“NL→规则”，LLM 只做模板槽位填充；每类模板预定义
条件结构、证据类型、测试生成器和 R0—R4 执行类别。这里用确定性分类器 + 正则
槽位填充作为基线，`llm_fill` 是 LLM 的挂载点。
"""
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass
class RuleDraft:
    category: str
    name: str
    rclass: str
    slots: dict = field(default_factory=dict)
    evidence: list = field(default_factory=list)
    tests: dict = field(default_factory=dict)


# 模板/单位单一真相源（L79）：名单与单位表统一来自 app/engine/registry.py，
# 本模块只保留兼容常量名（TEMPLATES=10 类 NL 填槽模板投影；EXECUTOR_BY_TEMPLATE=12 类
# 可执行模板投影），避免第二份名单漂移。判定语义不变（classify/fill_slots 口径不动）。
from .registry import (EXECUTORS as _REG_EXECUTORS,
                       EXECUTOR_BY_TEMPLATE as _REG_EXECUTOR_BY_TEMPLATE,
                       NL_UNIT_WORDS as _REG_NL_UNIT_WORDS,
                       UNIT_CANON as _REG_UNIT_CANON,
                       nl_templates as _reg_nl_templates)

TEMPLATES = _reg_nl_templates()


def classify(text: str) -> dict:
    """按关键词打分，选最高分类；平局取先出现。"""
    best, best_score = TEMPLATES[0], 0
    for t in TEMPLATES:
        score = sum(1 for k in t["keywords"] if k in text)
        if score > best_score:
            best, best_score = t, score
    return best


def _first_number(text: str) -> str:
    m = re.search(r"-?\d+(?:\.\d+)?", text)
    return m.group(0) if m else ""


# 数值单位表/单位规范映射（与 app/services/rule.py 的确定性数值解析口径一致；长单位优先）。
# L79：字面集合与中文归一映射统一由 app/engine/registry.py 提供（单一真相源），本模块只
# 保留既有常量名供 fill_slots 使用：
# - _UNITS：NL 限值解析的长单位优先正则（registry.NL_UNIT_WORDS 投影，逐项与迁移前一致）；
# - _UNIT_CANON：解析出口的中文/符号归一（registry.UNIT_CANON 投影；ruleexec 执行期单位表
#   同一来源，避免「解析归一表」与「执行器单位表」两套口径）。
_UNITS = "|".join(re.escape(u) for u in sorted(set(_REG_NL_UNIT_WORDS), key=len, reverse=True))
_UNIT_CANON = dict(_REG_UNIT_CANON)


def _canon_unit(u) -> str:
    """把解析出的单位归一成执行器可识别的写法（未知写法原样返回，不猜量纲）。"""
    raw = str(u or "").strip()
    return _UNIT_CANON.get(raw, raw)


def _op(text: str) -> str:
    # 义务/禁止类中文比较词（招标与合同最常见），先匹配长词再匹配短词
    if any(x in text for x in ("不得低于", "不得少于", "不应低于", "不能低于", "不能少于",
                               "不准低于", "别低于", "别少于", "不少于", "不低于", "至少",
                               "≥", "达到")):
        return ">="
    if any(x in text for x in ("不得高于", "不得超过", "不应高于", "不应超过", "不能超过",
                               "不准超过", "别超过", "别高于", "不超过", "不高于", "最多",
                               "至多", "≤")):
        return "<="
    if "±" in text:
        return "range"
    if any(x in text for x in ("以下", "小于", "<", "＜")):
        return "<"
    if any(x in text for x in ("以上", "大于", ">", "＞")):
        return ">"
    return "="


# 12 类可执行模板 → 执行器（field_presence/cross_relation 为执行器专用模板，
# 只经 API/导入/编译路径进入；新建表单仅展示 10 类 NL 填槽模板）
EXECUTOR_BY_TEMPLATE = dict(_REG_EXECUTOR_BY_TEMPLATE)
EXECUTORS = set(_REG_EXECUTORS)



def executor_reachable(slots: dict) -> tuple:
    """模板 → 执行器可达性（发布门禁用）。"""
    tpl = str((slots or {}).get("_template") or "")
    ex = str((slots or {}).get("_executor") or EXECUTOR_BY_TEMPLATE.get(tpl) or "")
    if not tpl:
        return True, ""
    if ex not in EXECUTORS:
        return False, f"模板 {tpl} 未声明有效执行器"
    if ex == "script":
        return False, "script 执行器尚未实现"
    if ex == "decision_table":
        return False, "decision_table 执行器尚未接入模板"
    if ex == "rule" and tpl not in EXECUTOR_BY_TEMPLATE:
        return False, f"模板 {tpl} 无 rule 执行器"
    return True, ""


def fill_slots(text: str, template: dict) -> dict:
    slots = {s: "" for s in template["slots"]}
    code = template["code"]
    slots["_template"] = code
    slots["_executor"] = EXECUTOR_BY_TEMPLATE.get(code, "llm")
    if code == "limit":
        # LaneQ 2026-11-23：规则文本里的全角数字/字母/单位写法和等价中文单位先归一，再解析阈值：
        # NFKC 把「８５／ＫＧ／㎏／＞」等折叠成 ASCII，℃→°C 仍在单位表内；归一只在限值分支内部
        # 使用，不下沉改写规则原文（slots 里存的是归一后的阈值/单位，语义不变）。
        text = unicodedata.normalize("NFKC", str(text or ""))
        slots["op"] = _op(text)
        # 主体：模态词之前的短语（投标报价 / 合同金额 / 中心温度 / 净含量…）
        MOD = r"(?:不得|不应|禁止|必须|应当|应|须|至少|不少于|不低于|不超过|不高于|不得超过|不得低于|不得高于|≤|≥|<|>)"
        mm0 = re.match(r"\s*([\u4e00-\u9fa5A-Za-z（）()]{2,18}?)\s*" + MOD, text)
        slots["metric"] = mm0.group(1).strip() if mm0 else ""
        # 日期型：签订日期应为 2024 年 1 月 1 日
        if any(w in text for w in ("日期", "时间")) and re.search(r"\d{4}\s*[年\-/.]\s*\d{1,2}", text):
            dm = re.search(r"(\d{4})\s*[年\-/.]\s*(\d{1,2})\s*[月\-/.]\s*(\d{1,2})", text)
            if dm:
                slots["value"] = f"{int(dm.group(1)):04d}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}"
                slots["unit"] = ""
                slots["_datetype"] = "date"
                return slots
        if "付款" in text or "支付" in text:
            slots["metric"] = "付款期限"
        # 客体：区间值（10~20 分钟 / 2℃~8℃ / 18℃~26℃）→ range
        _rm = re.search(r"(?P<lo>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*(?P<u1>" + _UNITS + r")?"
                        r"\s*(?:~|～|〜|至|到|—|–)\s*"
                        r"(?P<hi>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*(?P<u2>" + _UNITS + r")?", text)
        if _rm and (_rm.group("u1") or _rm.group("u2")):
            _lo = float(_rm.group("lo").replace(",", ""))
            _hi = float(_rm.group("hi").replace(",", ""))
            slots["op"] = "range"
            slots["value"] = f"{_lo:g}-{_hi:g}"
            slots["unit"] = _canon_unit(_rm.group("u2") or _rm.group("u1") or "")
            slots["lo"], slots["hi"] = _lo, _hi
            slots["range"] = {"lo": _lo, "hi": _hi}
            slots["tolerance"] = ""
            return slots
        # 客体：数字（支持千分位）+ 单位（万元/元/天/℃…）
        mv = re.search(r"(-?\d{1,3}(?:,\d{3})+(?:\.\d+)?|(?:零下)?-?\d+(?:\.\d+)?)\s*(" + _UNITS + r")?", text)
        if mv:
            slots["value"] = mv.group(1)
            slots["unit"] = _canon_unit(mv.group(2) or "")
        else:
            slots["value"] = _first_number(text)
            slots["unit"] = ""
        slots["tolerance"] = _first_number(text.split("±")[1]) if "±" in text else ""
    elif code == "completeness":
        slots["required_docs"] = text
        _terms = _extract_terms(text, multi=True)
        if _terms:
            slots["_terms"] = _terms
    elif code == "consistency":
        slots["objects"] = text
        slots["across"] = "跨文档" if ("跨" in text or "一致" in text) else "本文件"
    elif code == "prohibited":
        slots["object"] = text
        slots["forbidden"] = "是"
        _obj = _extract_terms(text, multi=False)
        if _obj:
            slots["_terms"] = [_obj[0]]
            slots["forbid"] = _obj[0]
    elif code == "frequency":
        slots["action"] = text
        slots["frequency"] = _first_number(text)
        _terms = _extract_terms(text, multi=True)
        if _terms:
            slots["_terms"] = _terms
    else:
        slots[template["slots"][0]] = text
        _terms = _extract_terms(text, multi=True)
        if _terms:
            slots["_terms"] = _terms
    return slots


def _extract_terms(text: str, multi: bool = True) -> list:
    """从条款里抽具体要素（签字/盖章、持证上岗、批次信息、CAS 编号、GB 15603、转包…）。"""
    s = str(text or "").strip()
    s = re.sub(r"^(.*?)(?:不得|禁止|严禁|不可|必须|应当|应|须|需|要求)", "", s) if re.match(r"^.*?(不得|禁止|严禁|不可|必须|应当|应|须|需|要求)", s) else s
    s = re.sub(r"^(使用|采用|出现|存在|标注|记录|引用|包含|提供|持有|佩戴|持|按照|按|执行|完成)", "", s)
    s = re.sub(r"(等|以上|以下|方可|为准)$", "", s).strip("，。；; ")
    if not s:
        return []
    code = re.search(r"([A-Z]{2,}\s*\d{2,}[\-\d]*)", s)
    if code:
        return [code.group(1).replace(" ", "")]
    if multi:
        parts = re.split(r"[、，,]|并|且|和", s)
        return [p.strip("，。；; ") for p in parts if 1 < len(p.strip()) <= 30]
    return [s[:30]]


def test_skeleton(template: dict, slots: dict) -> dict:
    """生成 3 正 / 3 反测试骨架（字符串占位，可被真实用例替换）。"""
    name = template["name"]
    pos = [
        f"{name}：满足条件的样例（{slots.get('metric','对象')} 合规）",
        f"{name}：边界值（临界通过）",
        f"{name}：正常通过样例",
    ]
    neg = [
        f"{name}：不满足（缺失/超限）",
        f"{name}：占位符 X / 空值",
        f"{name}：单位或计量基准不一致",
    ]
    return {"positive": pos, "negative": neg}


def parse_nl_rule(text: str) -> RuleDraft:
    """自然语言 → 规则草稿（分类 + 填槽 + 测试骨架）。"""
    t = classify(text)
    slots = fill_slots(text, t)
    tests = test_skeleton(t, slots)
    return RuleDraft(category=t["code"], name=t["name"], rclass=t["rclass"],
                     slots=slots, evidence=t["evidence"], tests=tests)


def llm_fill(text: str, template: dict) -> dict:
    """LLM 槽位填充挂载点（本 MVP 用确定性 fill_slots 兜底）。"""
    return fill_slots(text, template)
