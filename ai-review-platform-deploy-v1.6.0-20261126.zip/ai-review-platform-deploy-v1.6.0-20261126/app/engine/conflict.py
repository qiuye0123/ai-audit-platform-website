"""
冲突检测（三态）：已证明冲突 / 未发现冲突 / 无法判定。

原则（方案 v2）：先对齐产品/工序/适用时间/单位/例外，再判断约束是否矛盾；
P0 只支持数值区间、枚举集合、版本适用性；自然语言条款冲突只做辅助提示。
"""
import re
from dataclasses import dataclass, field, asdict


@dataclass
class NumericRule:
    rule_id: str
    metric: str          # 指标：温度/时间/浓度/重量
    process: str         # 适用工序（作用域对齐键）
    unit: str            # ℃ / min / ppm / g ...
    op: str              # >= / <= / = / range
    value: object        # float 或 (lo, hi)


def _norm_unit(u: str) -> str:
    u = u.strip().replace("°C", "℃").replace("摄氏度", "℃")
    return u


def _bounds(r: NumericRule):
    if r.op == ">=":
        return (r.value, None)
    if r.op == ">":
        return (r.value, None)   # 严格大于用开区间示意
    if r.op == "<=":
        return (None, r.value)
    if r.op == "<":
        return (None, r.value)
    if r.op == "=":
        return (r.value, r.value)
    if r.op == "range" and isinstance(r.value, (tuple, list)):
        return (r.value[0], r.value[1])
    return (None, None)


def _overlap(a, b):
    """区间重叠判断；None 表示无限。返回 None=无法判定。"""
    if a == (None, None) or b == (None, None):
        return None
    lo = max(a[0] if a[0] is not None else -float("inf"),
             b[0] if b[0] is not None else -float("inf"))
    hi = min(a[1] if a[1] is not None else float("inf"),
             b[1] if b[1] is not None else float("inf"))
    return lo <= hi


def analyze(rules: list[NumericRule]) -> list[dict]:
    """两两比较：先对齐 metric+unit+process，再判断矛盾。"""
    out = []
    for i in range(len(rules)):
        for j in range(i + 1, len(rules)):
            a, b = rules[i], rules[j]
            verdict = {"a": a.rule_id, "b": b.rule_id, "type": "未发现冲突", "detail": ""}
            # 作用域对齐
            if a.process != b.process:
                verdict["type"] = "未发现冲突"
                verdict["detail"] = f"适用工序不同（{a.process} vs {b.process}），不构成冲突"
            elif a.metric != b.metric:
                verdict["type"] = "未发现冲突"
                verdict["detail"] = f"指标不同（{a.metric} vs {b.metric}）"
            elif _norm_unit(a.unit) != _norm_unit(b.unit):
                verdict["type"] = "无法判定"
                verdict["detail"] = f"单位不一致（{a.unit or '未标注'} vs {b.unit or '未标注'}），无法判定"
            else:
                ov = _overlap(_bounds(a), _bounds(b))
                if ov is None:
                    verdict["type"] = "无法判定"
                    verdict["detail"] = "约束形式无法解析，无法判定"
                elif ov:
                    verdict["type"] = "未发现冲突"
                    verdict["detail"] = f"约束区间存在交集（{a.op}{a.value} / {b.op}{b.value}）"
                else:
                    verdict["type"] = "已证明冲突"
                    verdict["detail"] = f"同一工序同一指标约束矛盾：{a.rule_id} {a.op}{a.value}{a.unit} 与 {b.rule_id} {b.op}{b.value}{b.unit} 无交集"
            out.append(verdict)
    return out

