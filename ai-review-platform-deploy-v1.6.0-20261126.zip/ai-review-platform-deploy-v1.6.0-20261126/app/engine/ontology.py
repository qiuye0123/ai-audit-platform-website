import logging
"""轻量本体（不用 OWL/SHACL）：对象类型 + 实例 + 别名消歧 + 实例级链接 + 健康度。

设计（对齐 ONTOS 本体理念，裁剪到审核平台最小必要面）：
- 元模型：ObjectType / ObjectInstance / Link / Alias（按类型作用域）。
- canonical_id：别名归一，跨文档对齐实体（半成品名 ↔ 工序名）。
- 实例级链接：半成品 --produced_by--> 工序；用于「半成品工序闭环」规则（数据驱动，非硬编码）。
- 健康度：孤岛实例/悬空链接，回答「本体有没有沉淀、有没有缺口」。
"""
from dataclasses import dataclass, field


@dataclass
class LinkType:
    key: str
    name: str
    source_type: str
    target_type: str
    cardinality: str = "many_to_one"


@dataclass
class ObjectType:
    key: str
    name: str
    domain: str = ""
    description: str = ""
    parent_key: str = ""
    abstract: bool = False
    properties: dict = field(default_factory=dict)


@dataclass
class ObjectInstance:
    id: str
    type_key: str
    name: str
    props: dict = field(default_factory=dict)


@dataclass
class Link:
    key: str
    source_id: str
    target_id: str


def _norm(s) -> str:
    return str(s or "").replace("\u3000", "").replace(" ", "").strip()


class Ontology:
    def __init__(self):
        self.types: dict[str, ObjectType] = {}
        self.instances: dict[str, ObjectInstance] = {}
        self.links: list[Link] = []
        self.link_types: dict[str, LinkType] = {}
        self._by_type_name: dict[tuple, str] = {}   # (type_key, norm) -> iid
        self._alias: dict[tuple, str] = {}          # (type_key, norm) -> iid
        self.alias_meta: dict[tuple, dict] = {}      # 别名证据/来源/状态

    def add_type(self, key, name, domain="", description="", parent_key="", abstract=False):
        self.types[key] = ObjectType(key, name, domain, description, parent_key, abstract, {})

    def add_property(self, type_key, key, name, data_type="string", required=False,
                     enum_values=None, description=""):
        t = self.types.get(type_key)
        if not t:
            raise ValueError(f"类型不存在：{type_key}")
        if data_type not in ("string", "number", "integer", "boolean", "date", "enum", "object"):
            raise ValueError(f"属性数据类型不合法：{data_type}")
        t.properties[key] = {"key": key, "name": name, "data_type": data_type,
                             "required": bool(required), "enum_values": enum_values or [],
                             "description": description}

    def add_link_type(self, key, name, source_type, target_type, cardinality="many_to_one"):
        if cardinality not in ("one_to_one", "one_to_many", "many_to_one", "many_to_many"):
            raise ValueError(f"关系基数不合法：{cardinality}")
        self.link_types[key] = LinkType(key, name, source_type, target_type, cardinality)

    def add_instance(self, type_key, name, props=None, iid=None):
        iid = iid or f"{type_key}:{_norm(name)}"
        inst = ObjectInstance(iid, type_key, name, props or {})
        self.instances[iid] = inst
        self._by_type_name[(type_key, _norm(name))] = iid
        return iid

    def add_alias(self, type_key, alias, instance_id, evidence="", source="legacy",
                  status="approved"):
        """别名必须有明确指向、同类型、可追溯依据；禁止跨类型/跨实体覆盖。"""
        alias_n = _norm(alias)
        inst = self.instances.get(instance_id)
        if not alias_n or not inst:
            raise ValueError("别名或目标实例不存在")
        if inst.type_key != type_key:
            raise ValueError(f"别名类型不匹配：{type_key} ≠ {inst.type_key}")
        old = self._alias.get((type_key, alias_n))
        if old and old != instance_id:
            raise ValueError(f"别名已被占用：{alias} → {self.instances.get(old).name if old in self.instances else old}")
        # 不允许把另一个实体的标准名当别名，避免概念被悄悄合并
        other = self._by_type_name.get((type_key, alias_n))
        if other and other != instance_id:
            raise ValueError(f"别名与同类实体标准名冲突：{alias} → {self.instances[other].name}")
        if source == "manual" and not str(evidence or "").strip():
            raise ValueError("人工别名必须填写依据（原文/制度/术语来源）")
        self._alias[(type_key, alias_n)] = instance_id
        self.alias_meta[(type_key, alias_n)] = {
            "evidence": str(evidence or "")[:500], "source": source, "status": status,
        }
        return True

    def add_link(self, key, source_id, target_id):
        self.links.append(Link(key, source_id, target_id))

    # ---- 查询 ----
    def resolve(self, name, type_key=None):
        """别名/名称 → 实例；type_key 给定则按类型作用域优先。"""
        n = _norm(name)
        if not n:
            return None
        if type_key:
            iid = self._alias.get((type_key, n)) or self._by_type_name.get((type_key, n))
            if iid:
                return self.instances.get(iid)
        for iid in self._alias.values():
            inst = self.instances.get(iid)
            if inst and _norm(inst.name) == n:
                return inst
        return self.instances.get(self._by_type_name.get((type_key, n), "")) if type_key else None

    def instances_of(self, type_key):
        return [i for i in self.instances.values() if i.type_key == type_key]

    def linked(self, source_id, link_key):
        return [self.instances[l.target_id] for l in self.links
                if l.key == link_key and l.source_id == source_id and l.target_id in self.instances]

    def has_process(self, half_product_name, process_names):
        """半成品是否在文档工序中存在对应处理（走 produced_by 链接，数据驱动）。"""
        inst = self.resolve(half_product_name, "HalfProduct")
        if not inst:
            return False
        targets = self.linked(inst.id, "produced_by")
        if targets:
            return any(t.name in process_names for t in targets)
        return any(inst.name == p or inst.name in p or p in inst.name for p in process_names)

    def to_admin_dict(self) -> dict:
        """管理端所需结构：类型 / 实例 / 别名明细 / 链接（带方向校验）。"""
        alias_list = []
        for (type_key, alias), iid in getattr(self, "_alias", {}).items():
            ent = self.instances.get(iid)
            if ent:
                meta = getattr(self, "alias_meta", {}).get((type_key, alias), {})
                alias_list.append({"alias": alias, "name": ent.name, "type_key": type_key,
                                   "evidence": meta.get("evidence", ""),
                                   "source": meta.get("source", "legacy"),
                                   "status": meta.get("status", "approved")})
        bad_idx = set()
        for idx, l in enumerate(self.links):
            src, dst = self.instances.get(l.source_id), self.instances.get(l.target_id)
            if not src or not dst:
                bad_idx.add(idx)
                continue
            expect = {"produced_by": ("HalfProduct", "ProcessStep")}.get(l.key)
            if expect and (src.type_key, dst.type_key) != expect:
                bad_idx.add(idx)
        links = []
        for idx, l in enumerate(self.links):
            src, dst = self.instances.get(l.source_id), self.instances.get(l.target_id)
            links.append({"key": l.key, "source_name": src.name if src else l.source_id,
                          "target_name": dst.name if dst else l.target_id, "ok": idx not in bad_idx})
        return {"types": [{"key": t["key"], "name": t["name"], "desc": t.get("domain", ""),
                            "parent_key": t.get("parent_key", ""), "abstract": t.get("abstract", False),
                            "properties": t.get("properties", {})} for t in self.to_dict()["types"]],
                "link_types": [{"key": x.key, "name": x.name, "source_type": x.source_type,
                                "target_type": x.target_type, "cardinality": x.cardinality}
                               for x in getattr(self, "link_types", {}).values()],
                "instances": [{"id": i.id, "name": i.name, "type_key": i.type_key,
                               "alias_count": sum(1 for k, v in getattr(self, "_alias", {}).items()
                                                  if v == i.id)} for i in self.instances.values()],
                "links": links, "alias_list": alias_list}

    def validate_links(self):
        """校验链接方向与目标类型；返回错误列表（空表示全部合法）。"""
        errs = []
        expect = {"produced_by": ("HalfProduct", "ProcessStep"),
                  "measured_by": ("ProcessStep", "Metric")}
        for l in self.links:
            src = self.instances.get(l.source_id)
            dst = self.instances.get(l.target_id)
            if src is None or dst is None:
                errs.append(f"悬空链接：{l.key} {l.source_id} → {l.target_id}")
                continue
            pair = expect.get(l.key)
            if pair and (src.type_key, dst.type_key) != pair:
                errs.append(f"方向/类型错误：{l.key} {src.type_key}({src.name}) → "
                            f"{dst.type_key}({dst.name})，应为 {pair[0]} → {pair[1]}")
        return errs

    def has_alias(self, text: str):
        """把文本中出现的别名归一为实体名（用于名称类检查）。"""
        out = text or ""
        for (type_key, alias), iid in getattr(self, "_alias", {}).items():
            if alias and alias in out and alias != (self.instances.get(iid).name if iid in self.instances else ""):
                ent = self.instances.get(iid)
                if ent:
                    out = out.replace(alias, ent.name)
        return out

    def validate(self) -> dict:
        """本体结构校验：类型/属性/关系/别名。错误阻断发布，警告提示治理。"""
        errors, warnings = [], []
        for key, t in self.types.items():
            if not t.name:
                errors.append({"code": "TYPE_NAME", "entity": key, "msg": "类型缺少名称"})
            if t.parent_key and t.parent_key not in self.types:
                errors.append({"code": "TYPE_PARENT", "entity": key, "msg": f"父类型不存在：{t.parent_key}"})
            for pkey, prop in (t.properties or {}).items():
                if not prop.get("name"):
                    errors.append({"code": "PROP_NAME", "entity": f"{key}.{pkey}", "msg": "属性缺少名称"})
        for key, lt in self.link_types.items():
            if lt.source_type not in self.types or lt.target_type not in self.types:
                errors.append({"code": "LINK_TYPE", "entity": key,
                               "msg": f"关系端点类型不存在：{lt.source_type} → {lt.target_type}"})
        for (type_key, alias), iid in getattr(self, "_alias", {}).items():
            ent = self.instances.get(iid)
            if not ent:
                errors.append({"code": "ALIAS_TARGET", "entity": alias, "msg": "别名指向不存在的实例"})
                continue
            if ent.type_key != type_key:
                errors.append({"code": "ALIAS_TYPE", "entity": alias,
                               "msg": f"别名类型与实例不一致：{type_key} / {ent.type_key}"})
            meta = getattr(self, "alias_meta", {}).get((type_key, alias), {})
            if meta.get("source") == "manual" and not meta.get("evidence"):
                errors.append({"code": "ALIAS_EVIDENCE", "entity": alias, "msg": "人工别名缺少依据"})
        for l in self.links:
            src, dst = self.instances.get(l.source_id), self.instances.get(l.target_id)
            if not src or not dst:
                errors.append({"code": "LINK_DANGLING", "entity": l.key,
                               "msg": f"悬空关系：{l.source_id} → {l.target_id}"})
                continue
            lt = self.link_types.get(l.key)
            if lt and (src.type_key != lt.source_type or dst.type_key != lt.target_type):
                errors.append({"code": "LINK_DIRECTION", "entity": l.key,
                               "msg": f"关系方向不符：{src.type_key} → {dst.type_key}，应为 {lt.source_type} → {lt.target_type}"})
        return {"ok": not errors, "errors": errors, "warnings": warnings}

    # ---- 健康度 ----
    def health(self):
        findings = []
        orphan = [i for i in self.instances.values()
                  if not any(l.source_id == i.id or l.target_id == i.id for l in self.links)]
        if orphan:
            findings.append({"level": "warn", "title": f"{len(orphan)} 个实例无关系",
                             "detail": "、".join(i.name for i in orphan[:8])})
        dangling = [l for l in self.links if l.source_id not in self.instances or l.target_id not in self.instances]
        if dangling:
            findings.append({"level": "error", "title": f"{len(dangling)} 条悬空链接", "detail": "端点实例缺失"})
        _v = self.validate()
        for e in _v.get("errors") or []:
            findings.append({"level": "error", "title": e.get("msg"), "detail": e.get("entity", "")})
        penalty = sum({"error": 20, "warn": 6, "info": 2}.get(f["level"], 0) for f in findings)
        return {
            "types": len(self.types), "instances": len(self.instances), "links": len(self.links),
            "aliases": len(self._alias), "score": max(0, 100 - penalty), "findings": findings,
        }

    def to_dict(self):
        return {
            "types": [{"key": t.key, "name": t.name, "domain": t.domain,
                       "parent_key": t.parent_key, "abstract": t.abstract,
                       "properties": t.properties} for t in self.types.values()],
            "instances": [{"id": i.id, "type": i.type_key, "name": i.name} for i in self.instances.values()],
            "links": [{"key": l.key, "source": l.source_id, "target": l.target_id} for l in self.links],
            "health": self.health(),
        }


def seed_food_ontology() -> Ontology:
    """食品工艺书本体（通用建模，非某企业机密数据）。"""
    o = Ontology()
    for _t in [("ProcessStep", "工序", "工艺", "加工工序"),
               ("HalfProduct", "半成品", "物料", "半成品"),
               ("Metric", "指标", "工艺", "工艺参数指标"),
               ("Unit", "单位", "计量", "计量单位"),
               ("Product", "产品", "物料", "产品（名称规范词典）"),
               ("Party", "主体", "主体", "当事人/合作方"),
               ("Document", "文档", "文档", "被审核的文件"),
               ("Field", "字段", "元数据", "文档表头与工序字段")]:
        o.add_type(*_t)
    for _p in [("Field", "code", "单号/编码", "string", False), ("Field", "name", "名称", "string", True),
               ("Field", "value", "值", "string", False), ("Field", "unit", "单位", "string", False),
               ("Metric", "canonical_name", "标准名", "string", True),
               ("Metric", "unit", "单位", "string", False), ("Metric", "scope", "适用作用域", "string", False),
               ("HalfProduct", "name", "名称", "string", True), ("HalfProduct", "spec", "规格", "string", False)]:
        try:
            o.add_property(*_p)
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    o.add_link_type("produced_by", "由工序生产", "HalfProduct", "ProcessStep", "many_to_one")
    o.add_link_type("measured_by", "由指标度量", "ProcessStep", "Metric", "one_to_many")
    o.add_link_type("uses_unit", "使用单位", "Metric", "Unit", "many_to_one")
    o.add_link_type("document_field", "文档包含字段", "Document", "Field", "one_to_many")
    o.add_link_type("document_party", "文档涉及主体", "Document", "Party", "many_to_many")
    o.add_type("Party", "主体", "主体", "当事人/合作方（甲方/乙方/供应商等）")
    o.add_type("Document", "文档", "文档", "被审核的文件；与文档中的字段不是同一概念")
    # 字段概念：审核规则判定的落点。不同业务概念只做并列实例，绝不预设别名。
    o.add_type("Field", "字段", "元数据", "文档表头与工序字段")
    for fname in ["工单号", "工艺单号", "版本号", "文件版本", "产品名称", "品名",
                  "实施日期", "执行日期", "签名", "签字", "序号", "编号",
                  "重量", "投料量", "单位", "消毒浓度", "半成品清单", "半制品",
                  "前处理", "工序闭环",
                  "冷藏", "冷藏暂存", "解冻时长", "解冻", "蒜泥",
                  "蔬菜前处理", "蔬菜预处理"]:
        o.add_instance("Field", fname)
    # 唯一保留的种子别名：只覆盖明确的同义异体写法，并带依据；不做业务概念合并
    try:
        _garlic = o.resolve("蒜泥", "Field")
        if _garlic:
            o.add_alias("Field", "蒜沫", _garlic.id,
                        evidence="食品工艺文档常见异体写法：蒜沫=蒜泥（种子词典，人工审核）",
                        source="seed", status="approved")
            o.add_alias("Field", "蒜蓉", _garlic.id,
                        evidence="食品工艺文档常见异体写法：蒜蓉=蒜泥（种子词典，人工审核）",
                        source="seed", status="approved")
    except Exception:
        logging.getLogger(__name__).debug('seed garlic aliases skipped', exc_info=True)

    # 类型属性：本体不是只有名字；属性定义用于实例校验和主链取数
    for _p in [("code", "单号/编码", "string", False), ("name", "名称", "string", True),
               ("value", "值", "string", False), ("unit", "单位", "string", False)]:
        try:
            o.add_property("Field", *_p)
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    for _p in [("canonical_name", "标准名", "string", True), ("unit", "单位", "string", False),
               ("scope", "适用作用域", "string", False)]:
        try:
            o.add_property("Metric", *_p)
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    for _p in [("name", "名称", "string", True), ("spec", "规格", "string", False)]:
        try:
            o.add_property("HalfProduct", *_p)
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    o.add_link_type("produced_by", "由工序生产", "HalfProduct", "ProcessStep", "many_to_one")
    o.add_link_type("measured_by", "由指标度量", "ProcessStep", "Metric", "one_to_many")
    o.add_link_type("uses_unit", "使用单位", "Metric", "Unit", "many_to_one")
    o.add_link_type("document_field", "文档包含字段", "Document", "Field", "one_to_many")
    o.add_link_type("document_party", "文档涉及主体", "Document", "Party", "many_to_many")

    # 工序实例（canonical，与工艺书工序名一致）+ 别名
    for name in ["蔬菜前处理", "肉类前处理", "焯水蔬菜", "炒卷心菜", "炒土豆丝",
                 "煎蛋", "炸制、炒奥尔良鸡块", "热处理番茄沙司"]:
        o.add_instance("ProcessStep", name)

    # 半成品实例
    for name in ["炒卷心菜", "炒土豆丝", "热处理番茄沙司", "炒奥尔良鸡块",
                 "焯水玉米粒", "煎荷包蛋", "酱油饭", "味林香甜酱"]:
        o.add_instance("HalfProduct", name)

    # 半成品 → 工序 链接（闭环校验依据）
    links = [
        ("炒卷心菜", "炒卷心菜"), ("炒土豆丝", "炒土豆丝"),
        ("热处理番茄沙司", "热处理番茄沙司"), ("焯水玉米粒", "焯水蔬菜"),
        ("煎荷包蛋", "煎蛋"), ("炒奥尔良鸡块", "炸制、炒奥尔良鸡块"),
    ]
    for hp, proc in links:
        src = o.resolve(hp, "HalfProduct")
        tgt = o.resolve(proc, "ProcessStep")
        if src and tgt:
            o.add_link("produced_by", src.id, tgt.id)

    # 指标 + 单位
    for m in ["中心温度", "冷却温度", "冷藏温度", "解冻时长", "消毒浓度"]:
        o.add_instance("Metric", m, props={"scope": m, "unit": "℃" if "温度" in m else ""})
    # 同一“温度”词在不同工序/口径下不是同一指标：通过 scope 属性区分，不做别名合并
    o.add_instance("Metric", "加热中心温度", props={"scope": "加热", "unit": "℃"})
    for u in ["℃", "分钟", "秒", "g", "kg", "ppm"]:
        o.add_instance("Unit", u)

    # 产品（名称规范词典）
    for p in ["烤肉拌饭", "喷香烤肉拌饭", "罗森 喷香烤肉拌饭3.0", "测试产品"]:
        o.add_instance("Product", p)

    # 主体/当事人（合同类点位用：名称对齐、主体一致）
    for party in ["苏州某食品有限公司", "某原料供应商", "某物流有限公司", "某商贸有限公司"]:
        o.add_instance("Party", party)

    return o


# ---------------------------------------------------------------- DB 持久化
def seed_to_db():
    """把食品本体种子写入 DB（幂等）。"""
    import json
    from .. import db, repositories as R
    o = seed_food_ontology()
    if R.onto_entities.count() == 0:
        for i in o.instances.values():
            R.onto_entities.insert(id=i.id, type_key=i.type_key, name=i.name,
                                   props_json=json.dumps(i.props, ensure_ascii=False))
        for (tk, alias), iid in o._alias.items():
            meta = getattr(o, "alias_meta", {}).get((tk, alias), {})
            R.onto_aliases.insert(id=db.new_id("oa"), type_key=tk, alias=alias, entity_id=iid,
                                  evidence=meta.get("evidence", ""), source=meta.get("source", "seed"),
                                  status=meta.get("status", "approved"), created_at=db.now())
        for l in o.links:
            R.onto_links.insert(id=db.new_id("ol"), key=l.key, source_id=l.source_id, target_id=l.target_id)
    return R.onto_entities.count()


def load_from_db():
    """从 DB 载入本体；空则回退种子。"""
    import json
    from .. import repositories as R
    ents = R.onto_entities.list()
    if not ents:
        return seed_food_ontology()
    o = Ontology()
    for _t in [("ProcessStep", "工序", "工艺", "加工工序"),
               ("HalfProduct", "半成品", "物料", "半成品"),
               ("Metric", "指标", "工艺", "工艺参数指标"),
               ("Unit", "单位", "计量", "计量单位"),
               ("Product", "产品", "物料", "产品（名称规范词典）"),
               ("Party", "主体", "主体", "当事人/合作方"),
               ("Document", "文档", "文档", "被审核的文件"),
               ("Field", "字段", "元数据", "文档表头与工序字段")]:
        o.add_type(*_t)
    for _p in [("Field", "code", "单号/编码", "string", False), ("Field", "name", "名称", "string", True),
               ("Field", "value", "值", "string", False), ("Field", "unit", "单位", "string", False),
               ("Metric", "canonical_name", "标准名", "string", True),
               ("Metric", "unit", "单位", "string", False), ("Metric", "scope", "适用作用域", "string", False),
               ("HalfProduct", "name", "名称", "string", True), ("HalfProduct", "spec", "规格", "string", False)]:
        try:
            o.add_property(*_p)
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
    o.add_link_type("produced_by", "由工序生产", "HalfProduct", "ProcessStep", "many_to_one")
    o.add_link_type("measured_by", "由指标度量", "ProcessStep", "Metric", "one_to_many")
    o.add_link_type("uses_unit", "使用单位", "Metric", "Unit", "many_to_one")
    o.add_link_type("document_field", "文档包含字段", "Document", "Field", "one_to_many")
    o.add_link_type("document_party", "文档涉及主体", "Document", "Party", "many_to_many")
    for e in ents:
        props = {}
        try:
            props = json.loads(e.get("props_json") or "{}")
        except Exception:
            logging.getLogger(__name__).debug('ignored', exc_info=True)
        o.add_instance(e["type_key"], e["name"], props=props, iid=e["id"])
    for a in R.onto_aliases.list():
        _ev = a.get("evidence") or ""
        _src = a.get("source") or "legacy"
        # 历史无依据别名不再进入运行时；必须重新人工确认并补依据
        if not _ev and _src != "seed":
            continue
        try:
            o.add_alias(a["type_key"], a["alias"], a["entity_id"],
                        evidence=_ev, source=_src, status=a.get("status") or "approved")
        except Exception:
            logging.getLogger(__name__).debug("invalid alias skipped: %s", a.get("alias"), exc_info=True)
    for l in R.onto_links.list():
        o.add_link(l["key"], l["source_id"], l["target_id"])
    return o
