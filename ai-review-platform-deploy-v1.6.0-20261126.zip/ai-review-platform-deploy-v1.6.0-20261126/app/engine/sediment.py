"""
规则沉淀：企业标准 → 限值 → 规则草稿（限值模板）。

把 standards.py 抽出的“指标 ≤ 值 单位”限值，套进 rule_schema 的“限值”模板，
生成可入库的 RuleDraft（含测试骨架）。这是“冷启动挖掘”的落地。

产物只含结构化规则草稿，不含企业标准原文/检测方法编号。
"""
import re
import sys


from .standards import build_index  # noqa: E402
from .rule_schema import RuleDraft, parse_nl_rule  # noqa: E402


def limit_to_draft(limit_text: str, source: str = "") -> RuleDraft:
    """“铅 ≤ 0.2 mg/kg” → 限值规则草稿。"""
    m = re.match(r"(.+?)\s*(≤|＜|<|≥|＞|>)\s*(\d+(?:\.\d+)?)\s*(.*)$", limit_text)
    if not m:
        return None
    metric, sym, value, unit = m.group(1).strip(), m.group(2), m.group(3), m.group(4).strip()
    op = {"≤": "<=", "＜": "<", "<": "<", "≥": ">=", "＞": ">", ">": ">"}[sym]
    d = parse_nl_rule(f"{metric} {'不得高于' if op == '<=' else '不低于'} {value}{unit}")
    d.category = "limit"
    d.name = "限值"
    d.rclass = "R1"
    d.slots = {"metric": metric, "op": op, "value": value, "unit": unit}
    d.evidence = ["检测报告/指标单元格", "原文引用"]
    d.tests = {
        "positive": [f"{metric} ≤ {value}{unit} 的合规样例"],
        "negative": [f"{metric} 超 {value}{unit} 的违规样例", f"{metric} 未标注/证据不足"],
    }
    return d


def standards_to_rules(pdf_dir: str) -> list:
    """遍历企业标准目录，抽取限值 → 规则草稿。"""
    idx = build_index(pdf_dir)
    drafts = []
    for it in idx:
        if "error" in it:
            continue
        for limit in it.get("limits", []):
            d = limit_to_draft(limit)
            if d:
                drafts.append({"standard_no": it.get("standard_no", ""), "product": it.get("product", ""), "draft": d})
    return drafts


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    drafts = standards_to_rules(argv[0])
    for x in drafts:
        d = x["draft"]
        print(f"{x['standard_no']:14} {x['product'][:12]:12} → {d.slots['metric']} ≤ {d.slots['value']}{d.slots['unit']}")
    print(f"\n共生成 {len(drafts)} 条限值规则草稿")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
