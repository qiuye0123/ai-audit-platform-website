# -*- coding: utf-8 -*-
"""执行计划与平台可达性：IR → executor/verifier/params/evidence + 冲突检测。

`plan` 输出 `policy-plan/v1`（deterministic=true、model_calls=0）；
`executor_reachable` 如实标 yes/partial/no，不把 partial 伪装成可达。
`detect_conflicts` 只覆盖数值/时间差区间（date_absolute/文本/语义显式 NOT_ENCODED）。

来源：L63 原型（规格 82 号 §5/§6）；L73 接入 lane 原样生产化。
"""
from __future__ import annotations

import itertools
import math

from .policy_ir import (PLAN_VERSION, to_base)

# 5) plan：执行器类型 / 参数 / 证据要求 / 平台可达性
# ---------------------------------------------------------------------------
_EXECUTOR = {
    "limit": {"executor": "numeric_limit", "verifier": "numeric_recompute"},
    "date": {"executor": "date_gap", "verifier": "date_direction"},
    "consistency": {"executor": "relation_compare", "verifier": "relation_recompute"},
    "prohibited": {"executor": "keyword_forbid", "verifier": "verbatim_span"},
    "completeness": {"executor": "keyword_require", "verifier": "verbatim_span"},
    "unit": {"executor": "unit_registry", "verifier": "unit_rounding"},
}

def plan(ir) -> dict:
    """IR → 可执行计划（参数/证据/验证器/平台可达性/确定性/0 模型）。"""
    rtype = ir["rule_type"]
    cond = ir["condition"]
    executor = _EXECUTOR[rtype]["executor"]
    verifier = _EXECUTOR[rtype]["verifier"]
    warnings = []
    reach = "yes"
    reach_note = ""
    if rtype == "limit":
        dim = (cond.get("unit_norm") or {}).get("dim")
        if dim in ("count", "capacity"):
            reach, reach_note = "partial", ("L37 IR-1：平台数值 IR 单位注册表不认计数/容量单位，"
                                            "需 M2 归一（有损）")
        if cond.get("operator") in ("!=", "range"):
            reach, reach_note = "partial", "平台数值算子集不含该算子（需执行器扩展）"
    elif rtype == "date":
        if cond.get("kind") == "date_absolute":
            executor, reach = "date_absolute", "yes"
        else:
            executor = "date_gap"
            reach, reach_note = "partial", ("L37 IR-3：limit IR 只有绝对日期算子，两时点自动求差"
                                            "仅跨角色 cross_role 路径可达")
    elif rtype == "consistency":
        executor = "relation_tolerance" if cond.get("kind") == "tolerance" \
            else "relation_equality"
        reach, reach_note = "partial", ("L37 IR-2：consistency 规则 create OK 但 approve 需 "
                                        "typed relations（ir_needs_structure）")
    elif rtype == "unit":
        if cond.get("kind") == "conversion":
            reach, reach_note = "no", "换算规则不在平台 rule IR 内（需 unit registry/mapper 承接）"
        else:
            reach, reach_note = "partial", "取整口径不在平台 rule IR 内（需 verifier 配置承接）"
    params = {"metric": ir["metric"]["name"], "object": ir["subject"]["object"],
              "granularity": ir["subject"]["granularity"]}
    if rtype in ("limit", "date") and cond.get("kind") != "date_absolute":
        params.update({"operator": cond["operator"], "value": cond["value"],
                       "unit": cond["unit"], "unit_canonical": (cond.get("unit_norm") or {}).get("canonical"),
                       "canonical_value": cond.get("canonical_value"),
                       "inclusive": cond.get("inclusive")})
    elif rtype == "date":
        params.update({"operator": cond["operator"], "date": cond["date"]})
    elif rtype == "consistency":
        params.update({"kind": cond["kind"], "left": cond.get("left"),
                       "right": cond.get("right")})
        if cond.get("kind") == "tolerance":
            params.update({"operator": cond["operator"], "value": cond["value"],
                           "unit": cond["unit"], "inclusive": cond.get("inclusive")})
    elif rtype == "prohibited":
        params.update({"forbidden": cond["forbidden"], "match": "contains"})
    elif rtype == "completeness":
        params.update({"required": cond["required"], "match_mode": cond["match_mode"]})
    elif rtype == "unit":
        params.update({k: cond.get(k) for k in ("kind", "unit", "decimals", "from_unit",
                                                "to_unit", "factor") if cond.get(k) is not None})
    if ir["subject"].get("semantic_qualifier"):
        warnings.append({"code": "semantic_qualifier",
                         "message": "含语义限定项，需证据语义核验后才能判 fail"})
        reach = "partial" if reach == "yes" else reach
        reach_note = reach_note or "语义限定项需人工/证据语义核验"
    evidence = {
        "required": True,
        "declared": ir["evidence"]["declared"],
        "derived": ir["evidence"]["derived"],
        "source": ir["evidence"]["source"],
        "locator": ir["evidence"]["locator"],
        "min_count": ir["evidence"]["min_count"],
        "verbatim_quote": True,
    }
    p = {
        "plan_version": PLAN_VERSION,
        "ir_id": ir["ir_id"],
        "rule_type": rtype,
        "executor": executor,
        "verifier": verifier,
        "params": params,
        "evidence": evidence,
        "inclusive_boundary": cond.get("inclusive"),
        "scope": ir["scope"],
        "deterministic": True,
        "model_calls": 0,
        "executor_reachable": reach,
        "reachability_note": reach_note,
        "warnings": warnings,
        "platform_slots": to_platform_slots(ir),
    }
    return p


def to_platform_slots(ir):
    """IR → 平台 rule IR（metric/op/value/unit）最小映射；如实标注降级（L37 IR-1/3/7）。"""
    rtype = ir["rule_type"]
    cond = ir["condition"]
    notes = []
    if rtype == "limit":
        unit = cond.get("unit")
        entry = cond.get("unit_norm") or {}
        platform_unit = unit
        lossy = False
        if entry.get("dim") in ("count", "capacity"):
            platform_unit = ""
            lossy = True
            notes.append("IR-1：计数/容量单位归一为无量纲（有损）")
        if any(w in ir["metric"]["name"] for w in ("编号", "名称", "文号")):
            notes.append("IR-7：指标名含文本词表子串，平台 infer_datatype 会误判 text")
        return {"supported": True, "metric": ir["metric"]["name"],
                "op": cond["operator"], "value": cond["value"],
                "unit": platform_unit, "lossy": lossy, "notes": notes}
    if rtype == "date" and cond.get("kind") == "date_gap":
        return {"supported": True, "metric": ir["metric"]["name"],
                "op": cond["operator"], "value": cond["value"], "unit": cond["unit"],
                "lossy": False,
                "notes": ["IR-3：按「已记录间隔值」数值承接；两时点自动求差不在 limit IR"]}
    if rtype == "date":
        return {"supported": True, "metric": ir["metric"]["name"],
                "op": {"before": "before", "after": "after", "=": "="}.get(cond["operator"],
                                                                        cond["operator"]),
                "value": cond["date"], "unit": "", "lossy": False, "notes": []}
    if rtype == "prohibited":
        return {"supported": True, "metric": "禁止事项", "op": "not_contains",
                "value": cond["forbidden"], "unit": "", "lossy": False, "notes": []}
    if rtype == "completeness":
        return {"supported": True, "metric": "必备材料",
                "op": "require_any" if cond.get("match_mode") == "any" else "require",
                "value": cond["required"], "unit": "", "lossy": False, "notes": []}
    if rtype == "consistency":
        return {"supported": cond.get("kind") == "tolerance",
                "metric": ir["metric"]["name"],
                "op": cond.get("operator") or "=",
                "value": cond.get("value"), "unit": cond.get("unit") or "",
                "lossy": True,
                "notes": ["IR-2：无 typed relations，approve 会 ir_needs_structure"]}
    if rtype == "unit":
        return {"supported": False, "reason": "换算/取整规则不在平台 rule IR 内",
                "notes": ["需 unit registry / verifier 配置承接；不得伪装成数值规则"]}
    return {"supported": False, "reason": "unknown rule_type", "notes": []}

def _pass_interval(cond):
    """满足区间 (lo, hi, lo_open, hi_open)；lo/hi 用 canonical base 值。无法编码返回 None。"""
    kind = cond.get("kind")
    if kind not in ("numeric_limit", "tolerance", "date_gap"):
        return None
    v = cond.get("canonical_value")
    if v is None:
        unit = cond.get("unit")
        v = to_base(cond.get("value"), unit) if unit else cond.get("value")
    if not isinstance(v, (int, float)) or not math.isfinite(v):
        return None
    op = cond.get("operator")
    incl = bool(cond.get("inclusive", True))
    if op == ">=":
        return (v, math.inf, not incl, True)
    if op == ">":
        return (v, math.inf, True, True)
    if op == "<=":
        return (-math.inf, v, True, not incl)
    if op == "<":
        return (-math.inf, v, True, True)
    if op == "=":
        return (v, v, False, False)
    if op == "range":
        return None
    return None


def _interval_intersect(a, b):
    """返回 (lo, hi, lo_open, hi_open) 或 None（无交集）。"""
    lo = max(a[0], b[0])
    hi = min(a[1], b[1])
    lo_open = a[2] if a[0] == lo else b[2] if b[0] == lo else a[2] or b[2]
    hi_open = a[3] if a[1] == hi else b[3] if b[1] == hi else a[3] or b[3]
    if lo > hi:
        return None
    if lo == hi and (lo_open or hi_open):
        return None
    return (lo, hi, lo_open, hi_open)


def _dim_of(cond):
    entry = cond.get("unit_norm")
    if entry:
        return entry.get("dim")
    if cond.get("kind") == "date_gap":
        return "time"
    return None


def detect_conflicts(irs) -> dict:
    """规则集一致性检查：同适用范围+同指标+同单位维度。

    * conflict：满足区间交集为空（同一份文档不可能同时满足两条规则）
    * duplicate：条件完全重复
    * coverage_gap：同指标在多个适用范围间缺失（advisory）+ 语义限定项无确定性核验（advisory）
    * not_encoded：日期绝对值 / 文本 / 语义类不进入区间比较（显式分类，不算已证明）
    """
    conflicts, duplicates, gaps, not_encoded = [], [], [], []
    groups = {}
    for ir in irs:
        cond = ir["condition"]
        if cond.get("kind") in ("date_absolute", "equality", "prohibited",
                                "completeness", "conversion", "rounding"):
            not_encoded.append({"ir_id": ir["ir_id"], "rule_type": ir["rule_type"],
                                "kind": cond.get("kind"),
                                "reason": "不在数值/时间差区间编码子集（NOT_ENCODED，不得当已证明）"})
            continue
        dim = _dim_of(cond)
        if dim is None:
            not_encoded.append({"ir_id": ir["ir_id"], "rule_type": ir["rule_type"],
                                "reason": "缺单位维度，无法区间比较"})
            continue
        key = (ir["scope"]["industry"], ir["scope"]["process"], ir["metric"]["name"], dim)
        groups.setdefault(key, []).append(ir)
    for key, items in sorted(groups.items(), key=lambda kv: str(kv[0])):
        industry, process, metric, dim = key
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                a, b = items[i], items[j]
                ia, ib = _pass_interval(a["condition"]), _pass_interval(b["condition"])
                if ia is None or ib is None:
                    not_encoded.append({"a": a["ir_id"], "b": b["ir_id"],
                                        "reason": "区间不可编码（NOT_ENCODED）"})
                    continue
                if ia == ib and a["condition"].get("operator") == b["condition"].get("operator"):
                    duplicates.append({"a": a["ir_id"], "b": b["ir_id"],
                                       "metric": metric, "process": process,
                                       "detail": "条件完全重复"})
                    continue
                inter = _interval_intersect(ia, ib)
                if inter is None:
                    conflicts.append({
                        "a": a["ir_id"], "b": b["ir_id"], "metric": metric,
                        "process": process, "dim": dim,
                        "a_constraint": f"{a['condition'].get('operator')} "
                                        f"{a['condition'].get('canonical_value')} {dim}",
                        "b_constraint": f"{b['condition'].get('operator')} "
                                        f"{b['condition'].get('canonical_value')} {dim}",
                        "witness": f"满足区间 {ia} 与 {ib} 无交集",
                        "severity": "blocking",
                    })
    # 覆盖缺口：同 industry 下同 metric 在部分 process 缺失
    by_ind = {}
    for ir in irs:
        by_ind.setdefault(ir["scope"]["industry"], []).append(ir)
    for ind, items in sorted(by_ind.items(), key=lambda kv: str(kv[0])):
        metric_process = {}
        for ir in items:
            metric_process.setdefault(ir["metric"]["name"], set()).add(
                ir["scope"]["process"])
        procs = {ir["scope"]["process"] for ir in items}
        for metric, have in sorted(metric_process.items(), key=lambda kv: kv[0]):
            missing = procs - have
            if missing and len(have) >= 1:
                gaps.append({"industry": ind, "metric": metric,
                             "covered_in": sorted(have),
                             "missing_in": sorted(missing),
                             "severity": "advisory",
                             "detail": "同一指标在不同适用范围间存在覆盖缺口"})
    for ir in irs:
        if ir["subject"].get("semantic_qualifier"):
            gaps.append({"ir_id": ir["ir_id"], "metric": ir["metric"]["name"],
                         "severity": "advisory",
                         "detail": f"语义限定项 {ir['subject']['semantic_qualifier']} "
                                   f"无确定性核验（需证据语义/人工）"})
    return {"conflicts": conflicts, "duplicates": duplicates,
            "coverage_gaps": gaps, "not_encoded": not_encoded,
            "checked_pairs": sum(len(v) * (len(v) - 1) // 2 for v in groups.values()),
            "conflict_count": len(conflicts), "duplicate_count": len(duplicates),
            "coverage_gap_count": len(gaps), "not_encoded_count": len(not_encoded)}
