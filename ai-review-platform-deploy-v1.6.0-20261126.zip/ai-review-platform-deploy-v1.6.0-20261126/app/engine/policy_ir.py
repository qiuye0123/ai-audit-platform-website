# -*- coding: utf-8 -*-
"""Policy IR v3：schema 常量、单位维度模型、canonical JSON / digest、结构校验。

来源：L63 原型 `scripts/qa/prototypes/policy_compiler.py`（规格
`docs/CURRENT/82-PolicyCompiler与反译验证规格_20261124.md`）；接入 lane L73。
本模块是**纯函数、零 IO、零模型调用**的编译期产物层：不 import app.services，
不读写数据库，不依赖系统时钟，保证同文本同版本 → 同 ir_id / 同 digest。
"""
from __future__ import annotations

import datetime
import hashlib
import json
import math
import re
import unicodedata

SCHEMA_VERSION = "policy-ir/v3"
COMPILER_VERSION = "policy-compiler/2026-11-24.1"
PLAN_VERSION = "policy-plan/v1"
RENDERER_VERSION = "policy-renderer/2026-11-24.1"
GATE_VERSION = "policy-gate/2026-11-24.1"
SWITCH_NAME = "RULEPROOF_POLICY_COMPILER"

RULE_TYPES = ("limit", "unit", "date", "consistency", "prohibited", "completeness")

# 平台 rule IR（app/engine/rule_ir2.py OPERATORS_BY_TYPE）的同口径算子集
OPERATORS_BY_TYPE = {
    "number": {">=", "<=", "=", ">", "<", "!=", "range"},
    "date": {"=", "before", "after", "between"},
    "text": {"contains", "not_contains", "=", "!=", "regex"},
}


# 单位表：raw -> (dimension, canonical, factor, offset)；base 值 = value * factor + offset
# dimension 覆盖：count / time / mass / temp / conc / money / pct / capacity / length / volume / pressure
UNITS = {}


def _add_units(dim, canonical, factor, offset, names):
    for name in names:
        UNITS[name] = {"dim": dim, "canonical": canonical,
                       "factor": factor, "offset": offset}


_add_units("count", "count", 1.0, 0.0,
           ["张", "件", "份", "册", "箱", "联", "页", "家", "人", "个", "次", "套",
            "项", "批", "条", "台", "只", "枚", "根", "块", "袋", "盒", "支", "瓶",
            "罐", "卷", "盘", "组", "处", "座", "间", "辆", "艘", "架", "门", "笔",
            "单", "户", "层", "排", "列", "段", "节", "篇", "本", "部", "床", "具"])
_add_units("time", "min", 1.0, 0.0, ["min", "分钟", "分"])
_add_units("time", "min", 60.0, 0.0, ["h", "小时", "小 时", "时"])
_add_units("time", "min", 1.0 / 60.0, 0.0, ["s", "秒"])
_add_units("time", "min", 1440.0, 0.0, ["天", "日", "日历日", "d"])
_add_units("time", "min", 10080.0, 0.0, ["周", "星期"])
_add_units("time", "min", 43200.0, 0.0, ["月"])
_add_units("time", "min", 525600.0, 0.0, ["年"])
_add_units("mass", "g", 1.0, 0.0, ["g", "克"])
_add_units("mass", "g", 1000.0, 0.0, ["kg", "千克", "公斤"])
_add_units("mass", "g", 0.001, 0.0, ["mg", "毫克"])
_add_units("mass", "g", 1e-6, 0.0, ["μg", "µg", "微克"])
_add_units("mass", "g", 1e6, 0.0, ["t", "吨"])
_add_units("temp", "℃", 1.0, 0.0, ["℃", "°C", "°c", "摄氏度"])
_add_units("temp", "℃", 5.0 / 9.0, -160.0 / 9.0, ["℉", "°F", "华氏度"])
_add_units("conc", "mg/kg", 1.0, 0.0, ["ppm", "PPM", "mg/kg", "mg·kg⁻¹", "mg·kg-1"])
_add_units("conc", "mg/kg", 0.001, 0.0, ["ppb", "PPB", "μg/kg", "ug/kg"])
_add_units("conc", "mg/kg", 1000.0, 0.0, ["mg/g", "g/kg"])
_add_units("conc", "mg/kg", 10000.0, 0.0, ["g/100g", "g/100mL", "g/100ml"])
_add_units("conc", "mg/kg", 1.0, 0.0, ["mg/L", "mg/l"])
_add_units("money", "元", 1.0, 0.0, ["元", "人民币", "RMB", "CNY"])
_add_units("money", "元", 1000.0, 0.0, ["千元"])
_add_units("money", "元", 10000.0, 0.0, ["万元"])
_add_units("money", "元", 1000000.0, 0.0, ["百万元"])
_add_units("money", "元", 100000000.0, 0.0, ["亿元"])
_add_units("pct", "%", 1.0, 0.0, ["%", "％", "%(w/w)", "个百分点"])
_add_units("capacity", "MiB", 1.0, 0.0, ["MiB", "mib"])
_add_units("capacity", "MiB", 1.0 / 1024.0, 0.0, ["KiB", "kib"])
_add_units("capacity", "MiB", 1024.0, 0.0, ["GiB", "gib"])
_add_units("capacity", "MiB", 1000000.0 / 1048576.0, 0.0, ["MB", "mb"])
_add_units("capacity", "MiB", 1000000000.0 / 1048576.0, 0.0, ["GB", "gb"])
_add_units("length", "mm", 1.0, 0.0, ["mm", "毫米"])
_add_units("length", "mm", 10.0, 0.0, ["cm", "厘米"])
_add_units("length", "mm", 1000.0, 0.0, ["m", "米"])
_add_units("volume", "mL", 1.0, 0.0, ["mL", "ml", "毫升"])
_add_units("volume", "mL", 1000.0, 0.0, ["L", "升"])
_add_units("pressure", "Pa", 1.0, 0.0, ["Pa", "帕", "帕斯卡"])
_add_units("pressure", "Pa", 1000.0, 0.0, ["kPa", "千帕"])
_add_units("pressure", "Pa", 1000000.0, 0.0, ["MPa", "兆帕"])
_add_units("pressure", "Pa", 100000.0, 0.0, ["bar", "巴"])

# 单位词表按长度倒序（"万元" 必须先于 "元"）
_UNIT_NAMES_BY_LEN = sorted(UNITS, key=lambda u: (-len(u), u))
_UNIT_ALT = "|".join(re.escape(u) for u in _UNIT_NAMES_BY_LEN)

# 数值 + 单位（单位必填；「人民币」前缀可选）
_NUM_UNIT_RE = re.compile(
    r"(?:\s*人民币)?\s*(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>" + _UNIT_ALT + r")"
)
# 宽松数值（用于判断"有数字但单位缺失/未知"）
_LOOSE_NUM_RE = re.compile(r"(?P<value>\d+(?:\.\d+)?)\s*(?P<tail>[^\s，。；、（）()：:]{0,8})")

def canonical_json(obj) -> str:
    """canonical JSON：sort_keys + 紧凑分隔 + 不转义中文（字节级可复现口径）。"""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _norm(text: str) -> str:
    """比较用归一：NFKC + 去空白（不用于 span 定位，span 始终基于原文）。"""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(text or "")))


def _norm_unit(raw):
    if raw is None:
        return None
    key = _norm(raw)
    entry = UNITS.get(key)
    if entry is None:
        # NFKC 后 "℃" → "°C" 的兼容处理与常见去尾括号
        for cand in (key, key.replace("°c", "°C"), key.replace("mib", "MiB")):
            if cand in UNITS:
                return UNITS[cand]
    return entry


def to_base(value, unit):
    """数值按单位换算到该维度 base；未知单位返回 None。"""
    entry = _norm_unit(unit)
    if entry is None or not isinstance(value, (int, float)) or not math.isfinite(value):
        return None
    return value * entry["factor"] + entry["offset"]


def _nm(value):
    """数值规范化：整数值去掉 .0，保证 canonical/反译稳定。"""
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value

def _coverage(ir):
    """编译期槽位覆盖：声明了哪些 / 缺口哪些（证据/例外/后果缺失 → gap）。"""
    required = ["object", "metric", "operator", "threshold", "unit", "scope",
                "evidence", "exception", "consequence"]
    declared, gaps = [], []
    cond = ir["condition"]
    checks = {
        "object": bool(ir["subject"]["object"]),
        "metric": bool(ir["metric"]["name"]),
        "operator": bool(cond.get("operator") or cond.get("modal") or cond.get("kind")),
        "threshold": cond.get("value") is not None or cond.get("date") is not None
                     or bool(cond.get("required")) or bool(cond.get("forbidden"))
                     or cond.get("kind") in ("conversion", "rounding"),
        "unit": bool(cond.get("unit")) or cond.get("kind") in ("conversion", "rounding",
                                                               "prohibited", "completeness"),
        "scope": bool(ir["scope"]["process"]) and bool(ir["scope"]["industry"]),
        "evidence": ir["evidence"]["declared"],
        "exception": ir["exceptions"]["declared"],
        "consequence": ir["consequence"]["declared"],
    }
    for key in required:
        if checks.get(key):
            declared.append(key)
        else:
            gaps.append({"slot": key, "severity": "advisory",
                         "message": f"{key} 未在原文声明（IR 不编造，发布门按策略处理）"})
    total = len(required)
    return {"required_slots": required, "declared": declared, "gaps": gaps,
            "declared_count": len(declared), "total": total,
            "ratio": round(len(declared) / total, 4)}

# 2) validate_ir：schema / 算子 / 单位 / scope / 证据 / span / 编译版本
# ---------------------------------------------------------------------------
REQUIRED_IR_KEYS = ("schema_version", "ir_id", "rule_type", "source", "subject", "metric",
                    "condition", "scope", "exceptions", "evidence", "consequence", "compile")


def validate_ir(ir) -> dict:
    """16 项编译期校验；任何未知/缺失/非法 → errors（fail-closed）。

    返回 {"ok": bool, "errors": [{"code","message","field"}], "warnings": [...],
          "checks": [{"check_id","status","detail"}]}
    """
    errors, warnings, checks = [], [], []

    def chk(cid, ok, detail="", error_code=None, field=None, severity="error"):
        status = "pass" if ok else ("fail" if severity == "error" else "warn")
        checks.append({"check_id": cid, "status": status, "detail": detail})
        if not ok:
            item = {"code": error_code or cid, "message": detail, "field": field,
                    "check_id": cid}
            (errors if severity == "error" else warnings).append(item)
        return ok

    if not isinstance(ir, dict):
        return {"ok": False, "errors": [{"code": "not_a_dict",
                                         "message": "IR 不是对象", "field": None}],
                "warnings": [], "checks": []}
    chk("V01_schema_version", ir.get("schema_version") == SCHEMA_VERSION,
        f"schema_version={ir.get('schema_version')!r} 期望 {SCHEMA_VERSION}",
        "bad_schema_version", "schema_version")
    missing = [k for k in REQUIRED_IR_KEYS if k not in ir]
    chk("V02_required_keys", not missing, f"缺字段：{missing}", "missing_fields")
    rtype = ir.get("rule_type")
    chk("V03_rule_type_known", rtype in RULE_TYPES,
        f"未知规则类型：{rtype!r}（fail-closed）", "unknown_rule_type", "rule_type")
    if missing or rtype not in RULE_TYPES:
        return {"ok": False, "errors": errors, "warnings": warnings, "checks": checks}

    src = ir.get("source") or {}
    text = src.get("text")
    span = src.get("span") or {}
    span_ok = (isinstance(text, str) and isinstance(span.get("start"), int)
               and isinstance(span.get("end"), int)
               and 0 <= span["start"] <= span["end"] <= len(text)
               and text[span["start"]:span["end"]] == span.get("text"))
    sha_ok = isinstance(text, str) and src.get("sha256") == sha256_text(text)
    chk("V04_source_span", span_ok, "source.span 与原文不逐字一致", "bad_source_span",
        "source")
    chk("V05_source_sha256", sha_ok, "source.sha256 与 text 不一致", "bad_source_sha256",
        "source")
    subject = ir.get("subject") or {}
    metric = ir.get("metric") or {}
    obj = subject.get("object")
    chk("V06_object", isinstance(obj, str) and obj.strip() != "" if rtype != "unit"
        else True, f"对象为空：{obj!r}", "missing_object", "subject.object")
    chk("V07_metric", isinstance(metric.get("name"), str) and metric["name"].strip() != "",
        f"指标为空：{metric.get('name')!r}", "missing_metric", "metric.name")
    cond = ir.get("condition") or {}
    dtype = metric.get("datatype")
    chk("V08_datatype", dtype in OPERATORS_BY_TYPE or (rtype == "unit" and dtype == "unit"),
        f"未知 datatype：{dtype!r}", "unknown_datatype", "metric.datatype")
    op = cond.get("operator")
    kind = cond.get("kind")
    if rtype in ("limit", "consistency", "date") or kind in ("numeric_limit", "tolerance",
                                                             "date_gap", "date_absolute"):
        allowed = OPERATORS_BY_TYPE["date" if kind == "date_absolute" else "number"]
        chk("V09_operator_allowed", op in allowed,
            f"算子 {op!r} 不适用于 {kind}（候选：{sorted(allowed)}）",
            "operator_not_allowed", "condition.operator")
    else:
        chk("V09_operator_allowed", kind in ("prohibited", "completeness", "conversion",
                                             "rounding"),
            f"未知条件类型：{kind!r}", "unknown_condition_kind", "condition.kind")

    # 数值有限性
    val = cond.get("value")
    if kind in ("numeric_limit", "tolerance", "date_gap"):
        finite = isinstance(val, (int, float)) and not isinstance(val, bool) \
            and math.isfinite(val)
        chk("V10_threshold_finite", finite, f"阈值非有限数值：{val!r}", "non_finite_value",
            "condition.value")
        unit_raw = cond.get("unit")
        entry = _norm_unit(unit_raw)
        chk("V11_unit_known", entry is not None, f"未知单位：{unit_raw!r}（fail-closed）",
            "unknown_unit", "condition.unit")
        if entry:
            dim_ok = True
            detail = f"单位维度 {entry['dim']}"
            if kind in ("date_gap",) and entry["dim"] != "time":
                dim_ok, detail = False, f"时间差规则单位非时间维度：{entry['dim']}"
            chk("V12_unit_dimension", dim_ok, detail, "unit_dimension_mismatch",
                "condition.unit")
        else:
            chk("V12_unit_dimension", False, "单位未知无法判维度", "unknown_unit",
                "condition.unit")
        incl_ok = isinstance(cond.get("inclusive"), bool)
        chk("V13_inclusive_flag", incl_ok, f"inclusive 非布尔：{cond.get('inclusive')!r}",
            "bad_inclusive", "condition.inclusive")
    elif kind == "date_absolute":
        date_ok = False
        date_val = cond.get("date")
        if re.match(r"^\d{4}-\d{2}-\d{2}$", str(date_val)):
            try:
                datetime.date.fromisoformat(str(date_val))
                date_ok = True
            except ValueError:
                date_ok = False
        chk("V10_threshold_finite", date_ok,
            f"日期阈值非法：{date_val!r}", "bad_date", "condition.date")
        chk("V11_unit_known", True, "date_absolute 不需要单位")
        chk("V12_unit_dimension", True, "date_absolute 不需要单位维度")
        chk("V13_inclusive_flag", isinstance(cond.get("inclusive"), bool),
            f"inclusive 非布尔：{cond.get('inclusive')!r}", "bad_inclusive")
    elif kind == "conversion":
        frm, to, fac = cond.get("from_unit"), cond.get("to_unit"), cond.get("factor")
        chk("V10_threshold_finite", isinstance(fac, (int, float))
            and math.isfinite(fac) and fac > 0, f"换算系数非法：{fac!r}",
            "bad_conversion_factor")
        chk("V11_unit_known", bool(frm) and bool(to), "换算规则缺少 from/to 单位",
            "missing_unit")
        chk("V12_unit_dimension", _norm(frm) != _norm(to), "换算前后单位相同",
            "noop_conversion")
        chk("V13_inclusive_flag", True, "换算规则无 inclusive")
    elif kind == "rounding":
        chk("V10_threshold_finite", True, "取整规则无阈值")
        chk("V11_unit_known", cond.get("unit") is None or _norm_unit(cond.get("unit")),
            f"取整规则未知单位：{cond.get('unit')!r}", "unknown_unit", "condition.unit")
        dec = cond.get("decimals")
        chk("V12_unit_dimension", dec is None or (isinstance(dec, int) and 0 <= dec <= 6),
            f"小数位数非法：{dec!r}", "bad_decimals", "condition.decimals")
        chk("V13_inclusive_flag", True, "取整规则无 inclusive")
    elif kind == "prohibited":
        forbidden = cond.get("forbidden") or []
        chk("V10_threshold_finite", bool(forbidden), "禁止事项为空", "missing_forbidden")
        chk("V11_unit_known", True, "prohibited 不需要单位")
        chk("V12_unit_dimension", all(isinstance(x, str) and len(_norm(x)) >= 2
                                      for x in forbidden),
            "禁止事项过短或非字符串", "bad_forbidden_term")
        chk("V13_inclusive_flag", True, "prohibited 无 inclusive")
    elif kind == "completeness":
        required = cond.get("required") or []
        chk("V10_threshold_finite", bool(required), "必备项为空", "missing_required")
        chk("V11_unit_known", True, "completeness 不需要单位")
        chk("V12_unit_dimension", cond.get("match_mode") in ("all", "any"),
            f"match_mode 非法：{cond.get('match_mode')!r}", "bad_match_mode")
        chk("V13_inclusive_flag", all(isinstance(x, str) and _norm(x) for x in required),
            "必备项非法", "bad_required_term")

    # 一致性/日期 类型专属结构
    if kind == "tolerance":
        chk("V14_relation_operands",
            bool(_norm(cond.get("left"))) and bool(_norm(cond.get("right"))),
            "一致性规则缺少 left/right 可比较对象", "relation_operands_missing",
            "condition.left")
    elif kind == "equality":
        chk("V14_relation_operands",
            bool(_norm(cond.get("left"))) and bool(_norm(cond.get("right"))),
            "一致性规则缺少 left/right 可比较对象", "relation_operands_missing",
            "condition.left")
    elif kind == "date_gap":
        chk("V14_relation_operands", bool(_norm(metric.get("name"))),
            "时间差规则缺少指标名", "missing_metric")
    else:
        chk("V14_relation_operands", True, "无需关系对象")

    # scope / 证据 / 例外 / 后果 / 编译元数据
    scope = ir.get("scope") or {}
    chk("V15_scope", bool(_norm(scope.get("process"))) or rtype == "unit",
        f"适用范围 process 为空：{scope.get('process')!r}", "missing_scope", "scope")
    chk("V15b_out_of_scope", scope.get("out_of_scope") in ("na", "insufficient", "fail"),
        f"范围外处理非法：{scope.get('out_of_scope')!r}", "bad_out_of_scope", "scope")
    ev = ir.get("evidence") or {}
    if ev.get("declared"):
        chk("V16_evidence", bool(_norm(ev.get("source"))) and (ev.get("min_count") or 0) >= 1,
            "证据要求声明不完整（source/min_count）", "bad_evidence", "evidence")
    else:
        chk("V16_evidence", True, "证据未声明（derived；发布门按策略处理）", severity="warn")
    exc = ir.get("exceptions") or {}
    chk("V16b_exceptions",
        isinstance(exc.get("items"), list) and all(
            isinstance(x, dict) and _norm(x.get("condition")) for x in exc.get("items", [])),
        "例外条款结构非法", "bad_exceptions", "exceptions")
    comp = ir.get("compile") or {}
    chk("V17_compiler", comp.get("compiler_version") == COMPILER_VERSION
        and comp.get("mode") == "deterministic" and comp.get("model_calls") == 0,
        f"编译元数据非法：{comp.get('compiler_version')!r}/{comp.get('mode')!r}/"
        f"{comp.get('model_calls')!r}", "bad_compiler_meta", "compile")
    chk("V17b_template", comp.get("template") == rtype,
        f"template 与 rule_type 不一致：{comp.get('template')!r} vs {rtype!r}",
        "template_mismatch", "compile.template")
    chk("V18_coverage", isinstance(ir.get("coverage"), dict)
        and ir["coverage"].get("total") == 9, "coverage 结构非法", "bad_coverage",
        "coverage")
    chk("V19_ir_id", isinstance(ir.get("ir_id"), str) and ir["ir_id"].startswith("ir-")
        and len(ir["ir_id"]) == 19, f"ir_id 非法：{ir.get('ir_id')!r}", "bad_ir_id", "ir_id")
    return {"ok": not errors, "errors": errors, "warnings": warnings, "checks": checks}

def ir_digest(ir) -> str:
    """IR 内容摘要：canonical JSON 的 sha256（不含时间戳/随机量，跨进程稳定）。"""
    return "sha256:" + hashlib.sha256(canonical_json(ir).encode("utf-8")).hexdigest()


def canonical_source_span(text: str) -> dict:
    """规则来源文本的 canonical span（start=0, end=字符数；UTF-8 码点口径）。"""
    t = str(text or "")
    return {"start": 0, "end": len(t), "text": t}

