"""审核点库（可替换）：支持正式「文件审核库」（302 点 / 103 文件类型 / 69 审核类型 / 5 执行方式）。

加载：RULEPROOF_AUDIT_LIBRARY 指向目录（含 审核点库.json / 文件类型与路由.json / 审核提示词.jsonl）。
兼容旧的简化 JSON（points 数组）。
"""
import json
import os
from dataclasses import dataclass, field
from typing import Optional

# 3 级问题等级（统一叫法）：高→严重 / 中→一般 / 低→疑似
LEVEL_TO_SEVERITY = {"高": "critical", "中": "warning", "低": "suspected"}
SEVERITY_TO_LEVEL = {v: k for k, v in LEVEL_TO_SEVERITY.items()}
# 兼容旧 P0/P1/P2
P_LEVEL = {"P0": "高", "P1": "中", "P2": "低"}
SEV_ALIAS = {"P0": "critical", "P1": "warning", "P2": "suspected",
             "高": "critical", "中": "warning", "低": "suspected",
             "critical": "critical", "warning": "warning", "suspected": "suspected"}


@dataclass
class AuditPoint:
    id: str
    code: str
    name: str
    category_id: str
    category: str
    type_id: str
    type_name: str
    trigger: str
    criterion: str
    required_evidence: str
    method: str               # semantic / compare / expert / text / calculate / D
    method_name: str
    level_raw: str            # 高/中/低
    severity: str             # critical/warning/suspected
    applicable_roles: list = field(default_factory=list)
    missing_handling: str = ""
    result_boundary: str = ""
    prompt: str = ""
    executor: str = ""       # 有值表示由确定性程序执行（对应内置规则码）
    match: str = ""          # 同名规则码下用标题关键词区分
    evidence_gate: bool = False
    evidence_terms: list = field(default_factory=list)
    mechanism_terms: list = field(default_factory=list)
    route_terms: list = field(default_factory=list)
    mechanism_gate: bool = False
    mechanism_type: str = ""
    mechanism_priority: int = 0
    exclusive_group: str = ""

    @property
    def sev_key(self) -> str:
        return self.severity

    @property
    def is_deterministic(self) -> bool:
        return self.method in ("compare", "text", "calculate", "D")

    def to_dict(self) -> dict:
        return {
            "id": self.id, "code": self.code, "name": self.name,
            "category_id": self.category_id, "category": self.category,
            "type_id": self.type_id, "type_name": self.type_name,
            "trigger": self.trigger, "criterion": self.criterion,
            "required_evidence": self.required_evidence,
            "method": self.method, "method_name": self.method_name,
            "level": self.level_raw, "severity": self.severity,
            "applicable_roles": self.applicable_roles,
            "missing_handling": self.missing_handling,
            "result_boundary": self.result_boundary,
            "executor": self.executor, "match": self.match,
            "evidence_gate": self.evidence_gate,
            "evidence_terms": self.evidence_terms,
            "mechanism_terms": self.mechanism_terms,
            "route_terms": self.route_terms,
            "mechanism_gate": self.mechanism_gate,
            "mechanism_type": self.mechanism_type,
            "mechanism_priority": self.mechanism_priority,
            "exclusive_group": self.exclusive_group,
            # 兼容旧字段
            "point": self.name, "evidence": self.required_evidence,
            "exec_level": self.level_raw, "tier": self.level_raw,
        }


class AuditPointLibrary:
    def __init__(self):
        self.points: list = []
        self.categories: list = []
        self.audit_types: dict = {}        # type_id -> {name, category, point_ids, trigger}
        self.document_types: list = []
        self.type_hint_aliases: dict = {}
        self.pack_document_types: set = set()     # [{id,name,aliases,recognition_elements,default_audit_types,default_role}]
        self.feature_additions: list = []  # [{feature,type_ids}]
        self.unknown_policy: str = ""
        self.dispatch: str = ""
        self.precheck: list = []
        # 审核类型的路由依据（文件类型与路由.json 的 route_basis）
        self.route_basis: dict = {}

    # ---------------- 加载 ----------------
    def load_points(self, rows: list, prompts: dict = None) -> int:
        prompts = prompts or {}
        for r in rows:
            raw_sev = str(r.get("severity") or "").strip()
            level = str(r.get("default_issue_level") or r.get("level")
                        or P_LEVEL.get(raw_sev, "") or "").strip()
            # default_issue_level 是权威业务等级；severity 只做机器投影，冲突时以等级为准。
            sev = (LEVEL_TO_SEVERITY.get(level)
                   or SEV_ALIAS.get(raw_sev) or "warning")
            self.points.append(AuditPoint(
                id=r.get("id", ""), code=r.get("code") or r.get("id", ""),
                name=r.get("name") or r.get("point", ""),
                category_id=r.get("category_id", ""), category=r.get("category") or r.get("category_name", ""),
                type_id=r.get("type_id", ""), type_name=r.get("type_name", ""),
                trigger=r.get("trigger") or r.get("applicable_when", ""),
                criterion=r.get("criterion", ""),
                required_evidence=r.get("required_evidence") or r.get("evidence", ""),
                method=r.get("method", "semantic"), method_name=r.get("method_name", ""),
                level_raw=level or SEVERITY_TO_LEVEL.get(sev, ""),
                severity=sev,
                applicable_roles=r.get("applicable_roles") or [],
                missing_handling=r.get("missing_handling", ""),
                result_boundary=r.get("result_boundary", ""),
                executor=r.get("executor", ""),
                match=r.get("match", ""),
                evidence_gate=bool(r.get("evidence_gate")),
                evidence_terms=r.get("evidence_terms") or [],
                mechanism_terms=r.get("mechanism_terms") or [],
                route_terms=r.get("route_terms") or [],
                mechanism_gate=bool(r.get("mechanism_gate")),
                mechanism_type=str(r.get("mechanism_type") or ""),
                mechanism_priority=int(r.get("mechanism_priority") or 0),
                exclusive_group=str(r.get("exclusive_group") or ""),
                prompt=prompts.get(r.get("id", ""), ""),
            ))
        return len(self.points)

    def load(self, rows: list, prompts: dict = None) -> int:
        """兼容旧调用名。"""
        return self.load_points(rows, prompts)

    @classmethod
    def from_json_file(cls, path: str) -> "AuditPointLibrary":
        """兼容旧的简化 JSON（list 或 {points: [...]}）。"""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        lib = cls()
        rows = data if isinstance(data, list) else data.get("points", [])
        lib.load_points(rows)
        return lib

    def merge_supplement(self, path: str) -> int:
        """合并补充层（额外文件类型/审核类型/点位），用于把垂直场景接入同一体系。"""
        if not path or not os.path.exists(path):
            return 0
        try:
            d = json.load(open(path, encoding="utf-8"))
        except Exception:
            return 0
        for dt in d.get("document_types") or []:
            self.document_types.append(dt)
            if dt.get("id"):
                self.pack_document_types.add(dt["id"])
        for k, v in (d.get("type_hint_aliases") or {}).items():
            self.type_hint_aliases[k] = v
        # 路由补充：为没有默认挂载的二级审核类型补文件类型，避免孤儿点
        for add in d.get("route_additions") or []:
            tid = str(add.get("audit_type") or "")
            if not tid:
                continue
            for dt in self.document_types:
                if str(dt.get("id") or "") in (add.get("document_types") or []):
                    types = list(dt.get("default_audit_types") or [])
                    if tid not in types:
                        types.append(tid)
                    dt["default_audit_types"] = types
        for t in d.get("audit_types") or []:
            self.audit_types[t.get("id")] = t
        before = len(self.points)
        self.load_points(d.get("points") or [])
        return len(self.points) - before

    @classmethod
    def from_library_dir(cls, dir_path: str) -> "AuditPointLibrary":
        """加载正式「文件审核库」目录。"""
        lib = cls()
        def _p(name):
            return os.path.join(dir_path, name)
        # 1) 审核点库
        lib_file = _p("审核点库.json")
        if os.path.exists(lib_file):
            data = json.load(open(lib_file, encoding="utf-8"))
            lib.categories = data.get("categories", [])
            lib.audit_types = {t.get("id"): t for t in data.get("audit_types", [])}
            # 2) 提示词
            prompts = {}
            pr = _p("审核提示词.jsonl")
            if os.path.exists(pr):
                with open(pr, encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            d = json.loads(line)
                            prompts[d.get("id", "")] = d.get("prompt", "")
                        except Exception:
                            continue
            lib.load_points(data.get("points", []), prompts)
        # 3) 文件类型与路由
        route_file = _p("文件类型与路由.json")
        if os.path.exists(route_file):
            r = json.load(open(route_file, encoding="utf-8"))
            lib.document_types = r.get("document_types", [])
            lib.feature_additions = r.get("feature_additions", [])
            lib.unknown_policy = r.get("unknown_policy", "")
            lib.dispatch = r.get("dispatch", "")
            lib.precheck = r.get("precheck", [])
            lib.route_basis = r.get("route_basis") or {}
            # audit_types 路由（以路由文件为准，补 trigger/point_ids）
            for t in r.get("audit_types", []):
                lib.audit_types.setdefault(t.get("id"), t)
        return lib

    # ---------------- 路由 ----------------
    def identify_document_type(self, text: str) -> dict:
        """文件类型识别（关键词/别名匹配，未知返回 unknown）。"""
        best, best_score = None, 0
        low = text or ""
        for dt in self.document_types:
            score = sum(1 for a in (dt.get("aliases") or []) if a and a in low)
            score += sum(1 for e in (dt.get("recognition_elements") or []) if e and e in low)
            if score > best_score:
                best, best_score = dt, score
        if not best or best_score < 2:
            return {"id": "unknown", "name": "未知类型", "score": best_score,
                    "policy": self.unknown_policy, "default_audit_types": []}
        return {"id": best.get("id"), "name": best.get("name"), "score": best_score,
                "default_role": best.get("default_role", ""),
                "default_audit_types": best.get("default_audit_types", [])}

    def route_points(self, type_ids: list) -> list:
        """审核类型 → 点位（只返回这些类型的点位，不全库）。"""
        pid_set = set()
        for tid in type_ids or []:
            t = self.audit_types.get(tid) or {}
            pid_set.update(t.get("point_ids") or [])
        return [p for p in self.points if p.id in pid_set]

    def apply_feature_additions(self, text: str, type_ids: list) -> list:
        """条件追加：文本命中某特征 → 追加审核类型。"""
        extra = list(type_ids or [])
        for fa in self.feature_additions or []:
            feature = fa.get("feature", "")
            if feature and feature in (text or ""):
                for tid in fa.get("type_ids") or []:
                    if tid not in extra:
                        extra.append(tid)
        return extra

    # 兼容旧 route()
    def route(self, doc_types: list = None, tier: str = "S2", families: list = None) -> list:
        tiers = {"S1": ["高"], "S2": ["高", "中"], "S3": ["高", "中", "低"]}.get(tier, ["高", "中"])
        return [p for p in self.points if not tier or p.level_raw in tiers]

    def families(self) -> list:
        return sorted({p.category for p in self.points if p.category})

    def categories_list(self) -> list:
        return sorted({p.category for p in self.points if p.category})

    def stats(self) -> dict:
        from collections import Counter
        return {
            "total": len(self.points),
            "categories": len(self.categories_list()),
            "audit_types": len(self.audit_types),
            "document_types": len(self.document_types),
            "severity": dict(Counter(p.severity for p in self.points)),
            "method": dict(Counter(p.method for p in self.points)),
            "level": dict(Counter(p.level_raw for p in self.points)),
        }

    # ---------------- 路由/字段覆盖自检 ----------------
    def default_routed_type_ids(self) -> set:
        """出现在任一文件类型 default_audit_types 的审核类型（平台默认路径）。"""
        out = set()
        for dt in self.document_types or []:
            out.update(str(x) for x in (dt.get("default_audit_types") or []) if str(x))
        return out

    def conditional_routed_type_ids(self) -> set:
        """出现在任一文件类型 conditional_audit_types 的审核类型（条件路径）。"""
        out = set()
        for dt in self.document_types or []:
            out.update(str(x) for x in (dt.get("conditional_audit_types") or []) if str(x))
        return out

    def _routed_point_ids(self, type_ids: set) -> set:
        ids = set()
        for tid in type_ids:
            ids.update((self.audit_types.get(tid) or {}).get("point_ids") or [])
        return ids

    def point_coverage(self) -> dict:
        """点位路由与字段一致性自检（唯一来源）。

        - default_routed_points：平台默认路径（default_audit_types）可达的点位数；
        - conditional_routed_points：叠加 conditional_audit_types 后可达的点位数；
        - unrouted_points：任何文件类型都路由不到的点位（死点位）；
        - severity_empty / severity_invalid / level_severity_mismatch：字段一致性；
        - type_default_documents：审核类型 → 默认携带它的文件类型 id。
        """
        default_types = self.default_routed_type_ids()
        cond_types = self.conditional_routed_type_ids()
        default_pids = self._routed_point_ids(default_types)
        # 条件路径 = 默认路径 ∪ conditional 追加；不是只算 conditional 单体
        cond_pids = self._routed_point_ids(default_types | cond_types)
        all_pids = {p.id for p in self.points}
        default_types_known = {t for t in default_types if t in self.audit_types}
        cond_types_known = {t for t in cond_types if t in self.audit_types}
        type_default_documents = {}
        for dt in self.document_types or []:
            did = str(dt.get("id") or "")
            for tid in dt.get("default_audit_types") or []:
                type_default_documents.setdefault(str(tid), []).append(did)
        severity_empty, severity_invalid, mismatch = [], [], []
        for p in self.points:
            if not str(p.severity or "").strip():
                severity_empty.append(p.id)
            elif p.severity not in ("critical", "warning", "suspected"):
                severity_invalid.append({"id": p.id, "severity": p.severity})
            if SEVERITY_TO_LEVEL.get(p.severity) != p.level_raw:
                mismatch.append({"id": p.id, "level": p.level_raw, "severity": p.severity})
        dead_types = sorted({str(p.type_id) for p in self.points
                             if p.type_id and str(p.type_id) not in default_types})
        return {
            "total_points": len(self.points),
            "total_audit_types": len(self.audit_types),
            "total_document_types": len(self.document_types),
            "default_routed_types": sorted(default_types_known),
            "conditional_only_types": sorted(cond_types_known - default_types_known),
            "default_routed_points": len(default_pids),
            "conditional_routed_points": len(cond_pids),
            "unrouted_points": sorted(all_pids - cond_pids),
            "dead_types": dead_types,
            "type_default_documents": type_default_documents,
            "severity_empty": severity_empty,
            "severity_invalid": severity_invalid,
            "level_severity_mismatch": mismatch,
            "route_basis_types": sorted((self.route_basis or {}).get("audit_types", {}) or {}),
        }

