# -*- coding: utf-8 -*-
"""确定性语义层 P0 引擎（纯函数：无 DB、无网络、无模型调用）。

本模块只负责“已类型化事实 + 已编译规则”的确定性执行，不负责：

- 从文档中抽取事实（由解析器/事实层完成，见 ``facts_from_parsed``）；
- 自然语言判据编译（由规则/IR 编译器完成）；
- 审核结论落库、权限、报告。

边界约定
--------
1. 规则 AST 表达的是 **违规条件**：``true`` = 命中违规（fail），
   ``false`` = 未命中违规（pass），``unknown`` = 证据不足（insufficient）。
   ``EvalResult.verdict`` 直接给出 ``fail / pass / insufficient``。
2. 三值逻辑采用 Kleene 语义：``false`` 支配 AND，``true`` 支配 OR。
3. ``missing`` 不是 0，也不是 false；默认 ``on_missing=unknown``。
4. 同一 ``batch_id + metric`` 多值且未声明聚合 → conflict → 默认 unknown。
5. 单位/量纲不匹配 → unknown；不能跨量纲“换算”。
6. 空事实集 / 空分组 → unknown（合规场景不做空集“真空通过”）。

TypedRule 示例::

    {
      "id": "R11",
      "scope": {"file_type": "food_process", "batch": "same_batch"},
      "expr": {
        "op": "and",
        "args": [
          {"op": "lt", "left": {"metric": "中心温度", "unit": "℃"}, "right": 85},
          {"op": "lt", "left": {"metric": "保温时长", "unit": "min"}, "right": 10}
        ]
      },
      "quantifier": "each",
      "on_missing": "unknown",
      "on_conflict": "unknown",
      "conclusion": {"fail": "双低", "pass": "不构成双低"}
    }
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping, Sequence


# ---------------------------------------------------------------------------
# 1. 三值逻辑
# ---------------------------------------------------------------------------
class Tri(str, Enum):
    """三值：true / false / unknown。字符串枚举，便于直接 JSON 序列化。"""

    TRUE = "true"
    FALSE = "false"
    UNKNOWN = "unknown"

    def __str__(self) -> str:  # 日志/断言更直观
        return self.value

    @property
    def known(self) -> bool:
        return self is not Tri.UNKNOWN

    @property
    def verdict(self) -> str:
        """把“违规条件真值”映射成审核结论：true→fail，false→pass。"""
        return {"true": "fail", "false": "pass", "unknown": "insufficient"}[self.value]


_TRUE = Tri.TRUE
_FALSE = Tri.FALSE
_UNKNOWN = Tri.UNKNOWN

# 显式真值表：false 支配 AND，true 支配 OR（Kleene 三值逻辑）。
AND_TABLE = {
    (_TRUE, _TRUE): _TRUE,
    (_TRUE, _FALSE): _FALSE,
    (_TRUE, _UNKNOWN): _UNKNOWN,
    (_FALSE, _TRUE): _FALSE,
    (_FALSE, _FALSE): _FALSE,
    (_FALSE, _UNKNOWN): _FALSE,
    (_UNKNOWN, _TRUE): _UNKNOWN,
    (_UNKNOWN, _FALSE): _FALSE,
    (_UNKNOWN, _UNKNOWN): _UNKNOWN,
}
OR_TABLE = {
    (_TRUE, _TRUE): _TRUE,
    (_TRUE, _FALSE): _TRUE,
    (_TRUE, _UNKNOWN): _TRUE,
    (_FALSE, _TRUE): _TRUE,
    (_FALSE, _FALSE): _FALSE,
    (_FALSE, _UNKNOWN): _UNKNOWN,
    (_UNKNOWN, _TRUE): _TRUE,
    (_UNKNOWN, _FALSE): _UNKNOWN,
    (_UNKNOWN, _UNKNOWN): _UNKNOWN,
}
NOT_TABLE = {_TRUE: _FALSE, _FALSE: _TRUE, _UNKNOWN: _UNKNOWN}

_TRI_TEXT = {
    "true": _TRUE, "t": _TRUE, "1": _TRUE, "yes": _TRUE,
    "false": _FALSE, "f": _FALSE, "0": _FALSE, "no": _FALSE,
    "unknown": _UNKNOWN, "u": _UNKNOWN, "none": _UNKNOWN, "null": _UNKNOWN,
    "": _UNKNOWN,
}


def coerce_tri(value: Any) -> Tri:
    """把 bool / 字符串 / Tri 统一成 Tri；无法识别时抛 ValueError。

    注意：不把 ``None`` 当 false，而是当 unknown（缺失不是 0/false）。
    """
    if isinstance(value, Tri):
        return value
    if isinstance(value, bool):
        return _TRUE if value else _FALSE
    if value is None:
        return _UNKNOWN
    key = str(value).strip().lower()
    if key in _TRI_TEXT:
        return _TRI_TEXT[key]
    raise ValueError(f"无法识别的三值：{value!r}")


def tri_not(value: Any) -> Tri:
    return NOT_TABLE[coerce_tri(value)]


def tri_and(*values: Any) -> Tri:
    """三值 AND。零个参数返回 unknown（审核场景不做空集真空为真）。"""
    vals = [coerce_tri(v) for v in values]
    if not vals:
        return _UNKNOWN
    acc = vals[0]
    for v in vals[1:]:
        acc = AND_TABLE[(acc, v)]
    return acc


def tri_or(*values: Any) -> Tri:
    """三值 OR。零个参数返回 unknown（审核场景不做空集真空为假）。"""
    vals = [coerce_tri(v) for v in values]
    if not vals:
        return _UNKNOWN
    acc = vals[0]
    for v in vals[1:]:
        acc = OR_TABLE[(acc, v)]
    return acc


# ---------------------------------------------------------------------------
# 2. 单位 / 量纲注册表与换算
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class UnitDef:
    """线性仿射单位：``base = value * factor + offset``。"""

    canonical: str
    dimension: str
    factor: float = 1.0
    offset: float = 0.0
    aliases: tuple = ()

    def to_base(self, value: float) -> float:
        return float(value) * self.factor + self.offset

    def from_base(self, base: float) -> float:
        return (float(base) - self.offset) / self.factor


_UNITS: dict = {}
_UNIT_ALIASES: dict = {}


def register_unit(canonical: str, dimension: str, factor: float = 1.0,
                  offset: float = 0.0, aliases: Iterable[str] = ()) -> UnitDef:
    """注册/扩展单位。P0 只内置温度、质量、时间；后续可按同一接口扩展。"""
    canonical = str(canonical or "").strip()
    dimension = str(dimension or "").strip().lower()
    if not canonical or not dimension:
        raise ValueError("单位与量纲不能为空")
    try:
        factor = float(factor)
        offset = float(offset)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"单位换算参数非法：{canonical}") from exc
    if not math.isfinite(factor) or factor == 0 or not math.isfinite(offset):
        raise ValueError(f"单位换算参数非法：{canonical}")
    defn = UnitDef(canonical, dimension, factor, offset, tuple(str(a).strip() for a in aliases if str(a).strip()))
    _UNITS[canonical] = defn
    _UNIT_ALIASES[canonical] = canonical
    for alias in defn.aliases:
        _UNIT_ALIASES[alias] = canonical
    return defn


def normalize_unit(unit: Any) -> str:
    """把单位别名归一为注册表中的 canonical 写法；未注册单位原样返回（去空白）。"""
    text = str(unit or "").strip()
    if not text:
        return ""
    return _UNIT_ALIASES.get(text, text)


def unit_dimension(unit: Any) -> str:
    """单位量纲；未知单位返回空串。"""
    defn = _UNITS.get(normalize_unit(unit))
    return defn.dimension if defn else ""


def units_compatible(left: Any, right: Any) -> bool:
    """两个单位是否可换算（同为已知且量纲一致）。"""
    ld, rd = unit_dimension(left), unit_dimension(right)
    return bool(ld and rd and ld == rd)


def to_number(value: Any) -> float | None:
    """把数值/数值字符串转成有限浮点；bool、NaN/Inf、文本返回 None。"""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    elif isinstance(value, str):
        text = (value.strip().replace("−", "-").replace("－", "-")
                .replace("，", "").replace(",", "").replace("\u3000", "")
                .replace(" ", ""))
        if not text or not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", text):
            return None
        try:
            number = float(text)
        except Exception:  # noqa: BLE001
            return None
    else:
        return None
    return number if math.isfinite(number) else None


def convert_value(value: Any, from_unit: Any, to_unit: Any) -> float | None:
    """同量纲换算；量纲不一致/单位未知/值为非数值时返回 None（由调用方转 unknown）。"""
    number = to_number(value)
    if number is None:
        return None
    src = normalize_unit(from_unit)
    dst = normalize_unit(to_unit)
    if not src and not dst:
        return number
    if not src or not dst:
        return None
    if src == dst:
        return number
    a, b = _UNITS.get(src), _UNITS.get(dst)
    if a is None or b is None or a.dimension != b.dimension:
        return None
    return b.from_base(a.to_base(number))


def _bootstrap_units() -> None:
    # 温度：基准 ℃
    register_unit("℃", "temperature", 1.0, 0.0,
                  ("°C", "C", "摄氏", "摄氏度", "degC", "celsius"))
    register_unit("°F", "temperature", 5.0 / 9.0, -160.0 / 9.0,
                  ("℉", "F", "华氏", "华氏度", "degF", "fahrenheit"))
    register_unit("K", "temperature", 1.0, -273.15,
                  ("开尔文", "开氏度", "kelvin"))
    # 质量：基准 g
    register_unit("g", "mass", 1.0, 0.0, ("克", "gram", "grams"))
    register_unit("kg", "mass", 1000.0, 0.0, ("千克", "公斤", "kilogram", "kilograms"))
    register_unit("mg", "mass", 0.001, 0.0, ("毫克", "milligram", "milligrams"))
    register_unit("μg", "mass", 0.000001, 0.0,
                  ("µg", "ug", "微克", "microgram", "micrograms"))
    register_unit("t", "mass", 1000000.0, 0.0, ("吨", "公吨"))
    # 时间：基准 s
    register_unit("s", "time", 1.0, 0.0, ("秒", "sec", "second", "seconds"))
    register_unit("min", "time", 60.0, 0.0, ("分钟", "分", "minute", "minutes"))
    register_unit("h", "time", 3600.0, 0.0, ("小时", "时", "hr", "hrs", "hour", "hours"))
    register_unit("d", "time", 86400.0, 0.0, ("天", "日", "day", "days"))


_bootstrap_units()


# ---------------------------------------------------------------------------
# 3. 事实层 TypedFact
# ---------------------------------------------------------------------------
FACT_STATUSES = ("present", "missing", "conflict")
_AGGREGATIONS = {"max", "min", "sum", "avg"}


def normalize_metric(value: Any) -> str:
    """指标名归一：去首尾空白，内部连续空白折叠为一个空格。"""
    return re.sub(r"\s+", " ", str(value or "").strip())


@dataclass(frozen=True)
class TypedFact:
    """带类型的事实。缺失/冲突是显式状态，不能伪装成 0/false。"""

    subject: str = ""
    metric: str = ""
    value: Any = None
    unit: str = ""
    dimension: str = ""
    batch_id: str = ""
    row_id: str = ""
    status: str = "present"
    span: tuple = ()
    confidence: float = 1.0
    source: str = ""
    quote: str = ""

    def __post_init__(self) -> None:
        for name in ("subject", "metric", "unit", "dimension", "batch_id", "row_id", "source"):
            value = getattr(self, name)
            object.__setattr__(self, name, str(value or "").strip())
        object.__setattr__(self, "quote", str(self.quote or ""))

        status = str(self.status or "present").strip().lower()
        if status == "ambiguous":  # 文档中 ambiguous 与 conflict 同义，统一成 conflict
            status = "conflict"
        if status not in FACT_STATUSES:
            raise ValueError(f"非法事实状态：{self.status!r}，只允许 {FACT_STATUSES}")
        object.__setattr__(self, "status", status)

        span = self.span
        if span is None or span == ():
            span = ()
        elif isinstance(span, (list, tuple)) and len(span) == 2:
            span = (int(span[0]), int(span[1]))
        else:
            raise ValueError(f"span 必须是 (start, end) 或空：{self.span!r}")
        object.__setattr__(self, "span", span)

        if not self.dimension and self.unit:
            object.__setattr__(self, "dimension", unit_dimension(self.unit))

        try:
            conf = float(self.confidence)
        except Exception:  # noqa: BLE001
            conf = 1.0
        if not math.isfinite(conf):
            conf = 1.0
        object.__setattr__(self, "confidence", min(1.0, max(0.0, conf)))

    @property
    def has_locator(self) -> bool:
        return bool(self.row_id or self.quote or self.span)

    def to_dict(self) -> dict:
        return {
            "subject": self.subject,
            "metric": self.metric,
            "value": self.value,
            "unit": self.unit,
            "dimension": self.dimension,
            "batch_id": self.batch_id,
            "row_id": self.row_id,
            "status": self.status,
            "span": list(self.span),
            "confidence": self.confidence,
            "source": self.source,
            "quote": self.quote,
        }

    @classmethod
    def from_dict(cls, data: Mapping) -> "TypedFact":
        if isinstance(data, cls):
            return data
        if not isinstance(data, Mapping):
            raise TypeError(f"事实必须是 Mapping 或 TypedFact：{type(data).__name__}")
        span = data.get("span")
        if isinstance(span, tuple) and len(span) == 2:
            span = span
        elif isinstance(span, list):
            span = tuple(span)
        elif span:
            span = tuple(span)
        else:
            span = ()
        return cls(
            subject=data.get("subject") or data.get("object") or "",
            metric=data.get("metric") or data.get("object") or data.get("kind") or "",
            value=data.get("value"),
            unit=data.get("unit") or "",
            dimension=data.get("dimension") or "",
            batch_id=data.get("batch_id") or data.get("batch") or "",
            row_id=data.get("row_id") or data.get("anchor") or data.get("cell") or "",
            status=data.get("status") or "present",
            span=span,
            confidence=data.get("confidence", 1.0),
            source=data.get("source") or "",
            quote=data.get("quote") or data.get("context") or "",
        )


# ---------------------------------------------------------------------------
# 4. 规则层 TypedRule AST（and/or/not + lt/lte/gt/gte/eq + 量词/策略）
# ---------------------------------------------------------------------------
class RuleError(ValueError):
    """规则 AST 结构错误（发布期应拦住，而不是运行期猜）。"""


_COMPARE_OPS = {"lt", "lte", "gt", "gte", "eq"}
_OP_ALIASES = {
    "<": "lt", "<=": "lte", "≤": "lte",
    ">": "gt", ">=": "gte", "≥": "gte",
    "=": "eq", "==": "eq",
    "且": "and", "与": "and", "或": "or", "非": "not",
    "all_of": "and", "all": "and", "any_of": "or", "any": "or",
}
_COMPARE_SYMBOL = {"lt": "<", "lte": "<=", "gt": ">", "gte": ">=", "eq": "=="}


def _norm_op(op: Any) -> str:
    text = str(op or "").strip().lower()
    return _OP_ALIASES.get(text, text)


def _parse_policy(value: Any, field_name: str) -> Tri:
    """策略：unknown / pass / fail（也接受 true/false 直接写三值）。

    pass/fail 是审核结论：pass → 违规条件 false；fail → 违规条件 true。
    """
    if value is None:
        return _UNKNOWN
    if isinstance(value, Tri):
        return value
    key = str(value).strip().lower()
    if key in ("unknown", "u", "insufficient", "证据不足"):
        return _UNKNOWN
    if key in ("pass", "false", "f", "通过", "满足"):
        return _FALSE
    if key in ("fail", "true", "t", "不通过", "不满足"):
        return _TRUE
    raise RuleError(f"{field_name} 策略非法：{value!r}，只允许 unknown/pass/fail")


@dataclass(frozen=True)
class Quantity:
    """比较阈值：数值+单位，或文本（仅 eq 使用）。"""

    value: Any
    unit: str = ""

    @property
    def is_text(self) -> bool:
        return isinstance(self.value, str)

    def to_dict(self) -> dict:
        return {"value": self.value, "unit": self.unit}


def parse_quantity(value: Any, default_unit: str = "") -> Quantity | None:
    """解析阈值/事实值：``85``、``"85"``、``"85℃"``、``"9.9min"``、``"合格"``。"""
    if isinstance(value, Quantity):
        return value
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return Quantity(float(value), normalize_unit(default_unit))
    if not isinstance(value, str):
        return None
    text = value.strip().replace("−", "-").replace("－", "-")
    if not text:
        return None
    number = to_number(text)
    if number is not None:
        return Quantity(number, normalize_unit(default_unit))
    match = re.match(r"^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*(.+)$", text)
    if match:
        rest = match.group(2).strip()
        # 含数字的后缀按文本处理（如日期 2026-08-12），避免把日期当数值阈值。
        if rest and not any(ch.isdigit() for ch in rest):
            return Quantity(float(match.group(1)), normalize_unit(rest))
    return Quantity(text, "")


@dataclass(frozen=True)
class FactRef:
    metric: str
    subject: str = ""
    unit: str = ""
    batch_id: str = ""
    aggregation: str = ""
    aliases: tuple = ()

    def names(self) -> tuple:
        names = [self.metric] + list(self.aliases or ())
        return tuple(n for n in (normalize_metric(x) for x in names) if n)


@dataclass(frozen=True)
class Logical:
    op: str
    args: tuple


@dataclass(frozen=True)
class Comparison:
    op: str
    ref: FactRef
    right: Quantity
    on_missing: Tri | None = None
    on_conflict: Tri | None = None


@dataclass(frozen=True)
class CompiledRule:
    rule_id: str
    expr: Any
    quantifier: str
    group_by: str
    on_missing: Tri
    on_conflict: Tri
    tolerance: float
    conclusion: dict
    raw: dict = field(default_factory=dict)


def _compile_comparison(node: Mapping, op: str) -> Comparison:
    ref_src = node.get("left", node.get("ref"))
    if ref_src is None:
        ref_src = node
    if isinstance(ref_src, str):
        ref_src = {"metric": ref_src}
    if not isinstance(ref_src, Mapping):
        raise RuleError("比较条件 left/ref 必须是对象或指标名")

    metric = normalize_metric(ref_src.get("metric") or ref_src.get("object"))
    if not metric:
        raise RuleError(f"{op} 条件缺少 metric")
    subject = normalize_metric(ref_src.get("subject"))
    unit = normalize_unit(ref_src.get("unit"))
    if unit and unit not in _UNITS:
        raise RuleError(f"未注册单位：{ref_src.get('unit')!r}（可用 register_unit 扩展）")
    batch_id = str(ref_src.get("batch_id") or ref_src.get("batch") or "").strip()

    aggregation = str(ref_src.get("aggregation") or node.get("aggregation") or "").strip().lower()
    if aggregation == "mean":
        aggregation = "avg"
    if aggregation and aggregation not in _AGGREGATIONS:
        raise RuleError(f"不支持的聚合方式：{aggregation!r}，只允许 {sorted(_AGGREGATIONS)}")
    aliases = ref_src.get("aliases") or ()
    if isinstance(aliases, str):
        aliases = [aliases]
    if not isinstance(aliases, (list, tuple)):
        raise RuleError("aliases 必须是字符串列表")
    aliases = tuple(dict.fromkeys(normalize_metric(x) for x in aliases if normalize_metric(x)))

    raw_right = node["right"] if "right" in node else node.get("value")
    if raw_right is None:
        raise RuleError(f"{op} 条件缺少 right/value 阈值")
    if isinstance(raw_right, Mapping):
        qty = parse_quantity(raw_right.get("value", raw_right.get("right")),
                             str(raw_right.get("unit") or ""))
    else:
        qty = parse_quantity(raw_right, unit)
    if qty is None:
        raise RuleError(f"{op} 条件阈值非法：{raw_right!r}")

    if qty.is_text:
        if op != "eq":
            raise RuleError(f"{op} 只支持数值阈值；文本阈值只支持 eq")
        if aggregation:
            raise RuleError("文本 eq 不支持聚合")
        return Comparison(op, FactRef(metric, subject, "", batch_id, "", aliases),
                          Quantity(str(qty.value).strip(), ""),
                          _parse_policy(node.get("on_missing"), "on_missing") if "on_missing" in node else None,
                          _parse_policy(node.get("on_conflict"), "on_conflict") if "on_conflict" in node else None)

    # 数值阈值：规则作者写错量纲必须在编译期拦住。
    if qty.unit:
        qty_unit = normalize_unit(qty.unit)
        if qty_unit not in _UNITS:
            raise RuleError(f"未注册单位：{qty.unit!r}")
        if unit:
            if not units_compatible(unit, qty_unit):
                raise RuleError(f"阈值单位 {qty.unit} 与事实单位 {unit} 量纲不匹配")
            converted = convert_value(qty.value, qty_unit, unit)
            if converted is None:
                raise RuleError(f"阈值单位无法换算：{qty.unit} -> {unit}")
            qty = Quantity(converted, unit)
        else:
            unit = qty_unit
            qty = Quantity(qty.value, qty_unit)
    elif unit:
        qty = Quantity(qty.value, unit)

    return Comparison(
        op,
        FactRef(metric, subject, unit, batch_id, aggregation, aliases),
        qty,
        _parse_policy(node.get("on_missing"), "on_missing") if "on_missing" in node else None,
        _parse_policy(node.get("on_conflict"), "on_conflict") if "on_conflict" in node else None,
    )


def _compile_node(node: Any) -> Any:
    if isinstance(node, bool) or not isinstance(node, Mapping):
        raise RuleError("条件节点必须是对象（dict），不能是布尔值/字符串")
    op = _norm_op(node.get("op"))
    if op in ("and", "or"):
        args = node.get("args")
        if args is None:
            args = node.get("all_of" if op == "and" else "any_of")
        if not isinstance(args, (list, tuple)) or not args:
            raise RuleError(f"{op} 至少需要一个子条件")
        return Logical(op, tuple(_compile_node(x) for x in args))
    if op == "not":
        arg = node.get("arg")
        if arg is None:
            maybe = node.get("args", node.get("not"))
            if isinstance(maybe, (list, tuple)):
                if len(maybe) != 1:
                    raise RuleError("not 只接受一个子条件")
                arg = maybe[0]
            else:
                arg = maybe
        if arg is None:
            raise RuleError("not 缺少子条件")
        return Logical("not", (_compile_node(arg),))
    if op in _COMPARE_OPS:
        return _compile_comparison(node, op)
    raise RuleError(f"不支持的算子：{node.get('op')!r}")


def _normalize_quantifier(value: Any) -> str:
    key = str(value or "each").strip().lower()
    if key in ("each", "every", "all", "each_batch", "all_batches"):
        return "each"
    if key in ("any", "some", "any_batch", "any_batches"):
        return "any"
    if key in ("collect", "collect_rows", "each_row", "rows"):
        return "collect"
    raise RuleError(f"量词非法：{value!r}，只允许 each/any/collect")


def _normalize_group_by(value: Any, quantifier: str) -> str:
    if value is None or str(value).strip() == "":
        return "row" if quantifier == "collect" else "batch"
    key = str(value).strip().lower()
    if key in ("batch", "same_batch", "each_batch"):
        return "batch"
    if key in ("row", "rows", "each_row", "row_id"):
        return "row"
    if key in ("none", "document", "doc", "file"):
        return "none"
    raise RuleError(f"group_by 非法：{value!r}，只允许 batch/row/none")


def compile_rule(rule: Mapping) -> CompiledRule:
    """校验并编译规则 AST；结构错误抛 RuleError。"""
    if isinstance(rule, CompiledRule):
        return rule
    if not isinstance(rule, Mapping):
        raise RuleError("规则必须是对象（dict）")
    expr_raw = rule.get("expr")
    if expr_raw is None:
        if "op" in rule:
            expr_raw = rule
        else:
            raise RuleError("规则缺少 expr")
    expr = _compile_node(expr_raw)

    scope = rule.get("scope") if isinstance(rule.get("scope"), Mapping) else {}
    quantifier = _normalize_quantifier(
        rule.get("quantifier", scope.get("quantifier", "each")))
    group_by = _normalize_group_by(rule.get("group_by", scope.get("group_by")), quantifier)
    on_missing = _parse_policy(rule.get("on_missing"), "on_missing")
    on_conflict = _parse_policy(rule.get("on_conflict"), "on_conflict")
    try:
        tolerance = float(rule.get("tolerance", 1e-9))
    except Exception as exc:  # noqa: BLE001
        raise RuleError("tolerance 必须是数值") from exc
    if not math.isfinite(tolerance) or tolerance < 0:
        raise RuleError("tolerance 必须是有限的非负数")
    conclusion = rule.get("conclusion") if isinstance(rule.get("conclusion"), Mapping) else {}
    return CompiledRule(
        rule_id=str(rule.get("id") or "").strip(),
        expr=expr,
        quantifier=quantifier,
        group_by=group_by,
        on_missing=on_missing,
        on_conflict=on_conflict,
        tolerance=tolerance,
        conclusion=dict(conclusion),
        raw=dict(rule),
    )


def validate_rule(rule: Mapping) -> list:
    """返回 AST 编译错误列表；空列表表示可执行。"""
    try:
        compile_rule(rule)
        return []
    except RuleError as exc:
        return [str(exc)]


def lint_rule(rule: Mapping) -> list:
    """发布前 lint：编译错误 + 显式字段缺失提醒（默认值安全但不透明）。"""
    problems = validate_rule(rule)
    if problems:
        return problems
    if not isinstance(rule, Mapping):
        return ["规则必须是对象（dict）"]
    checks = (
        ("quantifier", "缺少显式量词 quantifier（each/any/collect），执行时默认 each"),
        ("on_missing", "缺少显式 on_missing 策略，执行时默认 unknown"),
        ("on_conflict", "缺少显式 on_conflict 策略，执行时默认 unknown"),
        ("scope", "缺少 scope（文件类型/批次/对象），发布前应明确"),
    )
    for key, message in checks:
        if key not in rule:
            problems.append(message)
    return problems


# ---------------------------------------------------------------------------
# 5. 执行层：三值逻辑 + 量词 + 冲突/缺失/单位传播
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EvalResult:
    state: Tri
    reason: str
    detail: str = ""
    evidence: tuple = ()
    items: tuple = ()
    rule_id: str = ""

    @property
    def verdict(self) -> str:
        """审核结论：fail / pass / insufficient（AST 表达的是违规条件）。"""
        return self.state.verdict

    def to_dict(self) -> dict:
        return {
            "rule_id": self.rule_id,
            "state": self.state.value,
            "verdict": self.verdict,
            "reason": self.reason,
            "detail": self.detail,
            "evidence": list(self.evidence),
            "items": list(self.items),
        }


@dataclass
class _NodeResult:
    state: Tri
    reason: str
    detail: str = ""
    evidence: list = field(default_factory=list)


def _fact_evidence(fact: TypedFact, role: str) -> dict:
    row = fact.to_dict()
    row["role"] = role
    return row


def _dedupe_evidence(rows: Iterable[Mapping]) -> tuple:
    seen = set()
    out = []
    for row in rows or ():
        key = (row.get("metric"), row.get("batch_id"), row.get("row_id"),
               str(row.get("value")), row.get("unit"), row.get("status"), row.get("role"))
        if key in seen:
            continue
        seen.add(key)
        out.append(dict(row))
    return tuple(out)


def _iter_refs(node: Any) -> Iterable[FactRef]:
    if isinstance(node, Comparison):
        yield node.ref
    elif isinstance(node, Logical):
        for arg in node.args:
            yield from _iter_refs(arg)


def _fact_matches(fact: TypedFact, ref: FactRef) -> bool:
    names = set(ref.names())
    fact_names = {normalize_metric(fact.metric), normalize_metric(fact.subject)}
    fact_names.discard("")
    if not (names & fact_names):
        return False
    if ref.subject:
        subject = normalize_metric(ref.subject)
        if fact.subject and subject not in fact_names:
            return False
    if ref.batch_id and fact.batch_id != ref.batch_id:
        return False
    return True


def _group_key(fact: TypedFact, group_by: str):
    if group_by == "batch":
        batch = fact.batch_id.strip()
        if not batch:
            return None, "batch_missing"
        return (("batch", batch), {"batch_id": batch})
    if group_by == "row":
        row = fact.row_id.strip()
        if not row:
            return None, "row_missing"
        return (("row", fact.batch_id, row),
                {"batch_id": fact.batch_id, "row_id": row})
    return (("all",), {})


def _values_equal(left: float, right: float, tolerance: float) -> bool:
    return math.isclose(left, right, rel_tol=tolerance, abs_tol=max(tolerance, 1e-12))


def _policy_result(policy: Tri, kind: str, detail: str, evidence: list) -> _NodeResult:
    if policy is _UNKNOWN:
        return _NodeResult(_UNKNOWN, kind, detail, evidence)
    label = "fail" if policy is _TRUE else "pass"
    return _NodeResult(policy, f"{kind}_policy_{label}", detail + f"（显式策略 {label}）", evidence)


def _compare_value(op: str, value: float, right: float, tolerance: float) -> bool:
    if op == "lt":
        return value < right
    if op == "lte":
        return value <= right
    if op == "gt":
        return value > right
    if op == "gte":
        return value >= right
    if op == "eq":
        return _values_equal(value, right, tolerance)
    raise RuleError(f"未知比较算子：{op}")


def _eval_text_eq(node: Comparison, presents: Sequence[TypedFact], evidence: list,
                  on_conflict: Tri) -> _NodeResult:
    values = []
    for fact in presents:
        if fact.value is None:
            return _NodeResult(_UNKNOWN, "non_numeric",
                               f"指标 {node.ref.metric} 的文本值为空", evidence)
        text = str(fact.value).strip()
        if text not in values:
            values.append(text)
    if not values:
        return _NodeResult(_UNKNOWN, "missing", f"指标 {node.ref.metric} 无文本值", evidence)
    if len(values) > 1:
        return _policy_result(
            on_conflict, "conflict_multi_value",
            f"同 batch+metric 多文本值且未声明聚合：{values[:5]}", evidence)
    expect = str(node.right.value).strip()
    hit = values[0] == expect
    detail = f"{node.ref.metric}='{values[0]}' == '{expect}' -> {'true' if hit else 'false'}"
    return _NodeResult(_TRUE if hit else _FALSE,
                       "compare_true" if hit else "compare_false", detail, evidence)


def _eval_comparison(node: Comparison, facts: Sequence[TypedFact],
                     rule: CompiledRule) -> _NodeResult:
    selected = [f for f in facts if _fact_matches(f, node.ref)]
    evidence = [_fact_evidence(f, "candidate") for f in selected]
    if not selected:
        policy = node.on_missing if node.on_missing is not None else rule.on_missing
        return _policy_result(policy, "missing",
                              f"缺少指标 {node.ref.metric} 的事实", evidence)

    conflicts = [f for f in selected if f.status == "conflict"]
    missings = [f for f in selected if f.status == "missing"]
    presents = [f for f in selected if f.status == "present"]

    if conflicts:
        policy = node.on_conflict if node.on_conflict is not None else rule.on_conflict
        rows = [f.row_id or f.batch_id or "?" for f in conflicts]
        return _policy_result(policy, "conflict",
                              f"指标 {node.ref.metric} 存在冲突事实（行：{rows[:5]}）", evidence)
    if missings or not presents:
        policy = node.on_missing if node.on_missing is not None else rule.on_missing
        rows = [f.row_id or f.batch_id or "?" for f in missings]
        return _policy_result(policy, "missing",
                              f"指标 {node.ref.metric} 缺值（行：{rows[:5]}）", evidence)

    on_conflict = node.on_conflict if node.on_conflict is not None else rule.on_conflict

    if node.right.is_text:
        return _eval_text_eq(node, presents, evidence, on_conflict)

    expected = normalize_unit(node.ref.unit)
    expected_dim = unit_dimension(expected) if expected else ""

    numeric = []  # [(float, TypedFact)]
    for fact in presents:
        number = to_number(fact.value)
        if number is None:
            return _NodeResult(_UNKNOWN, "non_numeric",
                               f"指标 {node.ref.metric} 的值不是数值：{fact.value!r}", evidence)
        fact_unit = normalize_unit(fact.unit)
        fact_dim = fact.dimension or unit_dimension(fact_unit)
        if expected:
            if not fact_unit:
                return _NodeResult(_UNKNOWN, "unit_missing",
                                   f"指标 {node.ref.metric} 缺单位，无法与 {expected} 比较", evidence)
            if fact_unit not in _UNITS:
                return _NodeResult(_UNKNOWN, "unknown_unit",
                                   f"指标 {node.ref.metric} 的单位未注册：{fact.unit!r}", evidence)
            if expected_dim and fact_dim and fact_dim != expected_dim:
                return _NodeResult(
                    _UNKNOWN, "unit_dimension_mismatch",
                    f"量纲不匹配：{node.ref.metric} 事实单位 {fact.unit}（{fact_dim}）"
                    f"≠ 规则单位 {expected}（{expected_dim}）", evidence)
            if fact_unit != expected:
                converted = convert_value(number, fact_unit, expected)
                if converted is None:
                    return _NodeResult(
                        _UNKNOWN, "unit_conversion_failed",
                        f"单位无法换算：{fact.unit} -> {expected}", evidence)
                number = converted
        else:
            if fact_unit:
                if fact_unit not in _UNITS:
                    return _NodeResult(_UNKNOWN, "unknown_unit",
                                       f"指标 {node.ref.metric} 的单位未注册：{fact.unit!r}", evidence)
                numeric_units = {normalize_unit(x.unit) for x in presents if x.unit}
                if len(numeric_units) > 1:
                    dims = {unit_dimension(x) for x in numeric_units if unit_dimension(x)}
                    if len(dims) > 1:
                        return _NodeResult(_UNKNOWN, "unit_mismatch",
                                           f"同一指标存在不同量纲单位：{sorted(numeric_units)}", evidence)
                    return _NodeResult(_UNKNOWN, "unit_ambiguous",
                                       f"规则未声明单位，事实存在多种同量纲单位：{sorted(numeric_units)}",
                                       evidence)
            elif any(x.unit for x in presents):
                return _NodeResult(_UNKNOWN, "unit_ambiguous",
                                   f"指标 {node.ref.metric} 部分事实缺单位，无法比较", evidence)
        numeric.append((float(number), fact))

    if not numeric:
        return _NodeResult(_UNKNOWN, "missing", f"指标 {node.ref.metric} 无数值事实", evidence)

    unique = []  # [(value, fact)]
    for number, fact in numeric:
        if not any(_values_equal(number, old, rule.tolerance) for old, _ in unique):
            unique.append((number, fact))

    if len(unique) > 1:
        if not node.ref.aggregation:
            values = [round(v, 12) for v, _ in numeric]
            rows = [f.row_id or f.batch_id or "?" for _, f in numeric]
            return _policy_result(
                on_conflict, "conflict_multi_value",
                f"同 batch+metric 多值且未声明聚合：{node.ref.metric}={values}（行：{rows[:8]}）",
                evidence)
        numbers = [v for v, _ in numeric]
        aggregation = node.ref.aggregation
        if aggregation == "max":
            value = max(numbers)
        elif aggregation == "min":
            value = min(numbers)
        elif aggregation == "sum":
            value = sum(numbers)
        else:  # avg
            value = sum(numbers) / len(numbers)
        detail = (f"{node.ref.metric} 按 {aggregation} 聚合："
                  f"{[round(x, 12) for x in numbers]} -> {round(value, 12)}")
        evidence = [_fact_evidence(f, "aggregate") for f in presents]
        unit_label = expected
    else:
        value = unique[0][0]
        detail = ""
        unit_label = expected
        evidence = [_fact_evidence(f, "compare") for f in presents]

    right = float(node.right.value)
    hit = _compare_value(node.op, value, right, rule.tolerance)
    symbol = _COMPARE_SYMBOL[node.op]
    unit_text = unit_label or ""
    compare_detail = (f"{node.ref.metric}={value:.12g}{unit_text} {symbol} "
                      f"{right:.12g}{unit_text} -> {'true' if hit else 'false'}")
    full_detail = (detail + "；" + compare_detail) if detail else compare_detail
    return _NodeResult(_TRUE if hit else _FALSE,
                       "compare_true" if hit else "compare_false",
                       full_detail, evidence)


def _eval_node(node: Any, facts: Sequence[TypedFact], rule: CompiledRule) -> _NodeResult:
    if isinstance(node, Comparison):
        return _eval_comparison(node, facts, rule)
    if not isinstance(node, Logical):
        return _NodeResult(_UNKNOWN, "invalid_node", "条件节点非法")

    parts = [_eval_node(arg, facts, rule) for arg in node.args]
    evidence = [item for part in parts for item in part.evidence]

    if node.op == "not":
        part = parts[0]
        state = tri_not(part.state)
        return _NodeResult(state, "not", f"NOT {part.state.value} -> {state.value}", evidence)

    states = [part.state for part in parts]
    if node.op == "and":
        state = tri_and(*states)
        if state is _FALSE:
            bad = [f"子条件{i}:false" for i, item in enumerate(parts) if item.state is _FALSE]
            detail = "AND 有 false（false 支配）：" + ", ".join(bad)
        elif state is _UNKNOWN:
            bad = [f"子条件{i}:{item.reason}" for i, item in enumerate(parts)
                   if item.state is _UNKNOWN]
            detail = "AND 存在 unknown 且无 false：" + ", ".join(bad)
        else:
            detail = "AND 全部 true"
        return _NodeResult(state, f"and_{state.value}", detail, evidence)

    if node.op == "or":
        state = tri_or(*states)
        if state is _TRUE:
            good = [f"子条件{i}:true" for i, item in enumerate(parts) if item.state is _TRUE]
            detail = "OR 有 true（true 支配）：" + ", ".join(good)
        elif state is _UNKNOWN:
            bad = [f"子条件{i}:{item.reason}" for i, item in enumerate(parts)
                   if item.state is _UNKNOWN]
            detail = "OR 存在 unknown 且无 true：" + ", ".join(bad)
        else:
            detail = "OR 全部 false"
        return _NodeResult(state, f"or_{state.value}", detail, evidence)

    return _NodeResult(_UNKNOWN, "invalid_logical", f"未知逻辑算子：{node.op}", evidence)


def _aggregate_states(states: Sequence[Tri], quantifier: str) -> tuple:
    total = len(states)
    if not total:
        return _UNKNOWN, "empty_scope", "没有可判定的分组（不做空集真空通过）"
    false_count = sum(1 for x in states if x is _FALSE)
    true_count = sum(1 for x in states if x is _TRUE)
    unknown_count = total - false_count - true_count
    if quantifier in ("each", "collect"):
        if false_count:
            return _FALSE, f"{quantifier}_false", f"{false_count}/{total} 组为 false"
        if unknown_count:
            return _UNKNOWN, f"{quantifier}_unknown", f"{unknown_count}/{total} 组为 unknown"
        return _TRUE, f"{quantifier}_true", f"{true_count}/{total} 组为 true"
    # any
    if true_count:
        return _TRUE, "any_true", f"{true_count}/{total} 组为 true"
    if unknown_count:
        return _UNKNOWN, "any_unknown", f"{unknown_count}/{total} 组为 unknown"
    return _FALSE, "any_false", f"{false_count}/{total} 组为 false"


def evaluate(rule: Mapping, facts: Iterable) -> EvalResult:
    """执行规则：事实按量词分组后逐组三值判定，再按量词汇总。"""
    compiled = rule if isinstance(rule, CompiledRule) else compile_rule(rule)
    if isinstance(facts, Mapping):
        facts = [facts]
    typed = [f if isinstance(f, TypedFact) else TypedFact.from_dict(f)
             for f in (facts or ())]

    refs = list(_iter_refs(compiled.expr))
    if not refs:
        return EvalResult(_UNKNOWN, "invalid_rule", "规则没有任何比较条件", rule_id=compiled.rule_id)
    relevant = [f for f in typed if any(_fact_matches(f, ref) for ref in refs)]
    if not relevant:
        return EvalResult(_UNKNOWN, "no_facts",
                          "未找到规则引用指标的事实（缺失不是 0/false）",
                          rule_id=compiled.rule_id)

    groups = {}
    group_labels = {}
    for fact in relevant:
        key, label = _group_key(fact, compiled.group_by)
        if key is None:
            return EvalResult(
                _UNKNOWN, label,
                f"量词 {compiled.quantifier} / group_by={compiled.group_by} "
                f"需要明确的 {label.replace('_missing', '')}；"
                f"事实 {fact.metric!r} 的 {label.replace('_missing', '')} 为空",
                evidence=_dedupe_evidence([_fact_evidence(fact, "ungrouped")]),
                rule_id=compiled.rule_id)
        groups.setdefault(key, []).append(fact)
        group_labels[key] = label

    items = []
    states = []
    all_evidence = []
    for key, group_facts in groups.items():
        node_result = _eval_node(compiled.expr, group_facts, compiled)
        states.append(node_result.state)
        all_evidence.extend(node_result.evidence)
        items.append({
            "group": group_labels.get(key) or {},
            "state": node_result.state.value,
            "verdict": node_result.state.verdict,
            "reason": node_result.reason,
            "detail": node_result.detail,
            "evidence": list(_dedupe_evidence(node_result.evidence)),
        })

    state, reason, summary = _aggregate_states(states, compiled.quantifier)
    if len(items) == 1:
        # 单组时把组内精确原因（missing/conflict/unit_mismatch/compare_*）上提，
        # 多组时保留量词汇总原因并在 detail 里展开每组原因。
        reason = items[0]["reason"]
        summary = summary + "；" + str(items[0]["detail"])
    elif state is _UNKNOWN:
        details = [f"{item['group']}:{item['reason']}:{item['detail']}" for item in items
                   if item["state"] == "unknown"]
        if details:
            summary = summary + "；" + "；".join(details[:3])
    elif state is _FALSE and compiled.quantifier in ("each", "collect"):
        details = [f"{item['group']}:{item['reason']}:{item['detail']}" for item in items
                   if item["state"] == "false"]
        if details:
            summary = summary + "；" + "；".join(details[:3])

    return EvalResult(
        state=state,
        reason=reason,
        detail=summary,
        evidence=_dedupe_evidence(all_evidence),
        items=tuple(items),
        rule_id=compiled.rule_id,
    )


def evaluate_safe(rule: Mapping, facts: Iterable) -> EvalResult:
    """永不抛错的包装：AST/数据异常统一转 unknown（执行失败不是业务结论）。"""
    try:
        return evaluate(rule, facts)
    except Exception as exc:  # noqa: BLE001
        return EvalResult(_UNKNOWN, "execution_error",
                          f"{type(exc).__name__}: {str(exc)[:300]}")


# ---------------------------------------------------------------------------
# 6. 文档解析产物 -> TypedFact（纯数据适配，不做抽取）
# ---------------------------------------------------------------------------
_BATCH_RE = re.compile(
    r"(?:生产批号|产品批号|批号|批次号|批次)\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9._/\-]{1,40})")


def single_batch_from_text(text: str) -> str:
    """文档中恰好出现一个批次号时返回它；零个/多个（无法裁决）返回空串。"""
    values = []
    for match in _BATCH_RE.finditer(text or ""):
        value = match.group(1).strip().rstrip(".,;；。")
        if value and value not in values:
            values.append(value)
    return values[0] if len(values) == 1 else ""


def _span_from_fact(raw: Mapping) -> tuple:
    span = raw.get("span")
    if isinstance(span, (list, tuple)) and len(span) == 2:
        return (int(span[0]), int(span[1]))
    start = raw.get("start")
    if isinstance(start, (int, float)) and not isinstance(start, bool):
        quote = str(raw.get("quote") or raw.get("context") or "")
        return (int(start), int(start) + len(quote))
    return ()


def facts_from_parsed(parsed: Any, text: str = "", default_batch: str = "") -> list:
    """把解析产物中的 fact 列表适配为 TypedFact。

    - 接受 ``{"facts": [...]}``、``{"doc": {...}, "facts": [...]}`` 或 fact 列表；
    - 兼容 ``facts.py`` 的 legacy 字段（kind/metric/object/anchor/context/start）；
    - 不做文本抽取：文本只用于 span 回填和“唯一批次号”推断；
    - 批次无法唯一确定时保持空，后续量词会返回 unknown（batch_missing），不猜。
    """
    if isinstance(parsed, list):
        rows = parsed
    elif isinstance(parsed, Mapping):
        rows = parsed.get("facts")
        if rows is None:
            doc = parsed.get("doc")
            rows = doc.get("facts") if isinstance(doc, Mapping) else None
        rows = list(rows or [])
    else:
        rows = []
    if not default_batch:
        default_batch = single_batch_from_text(text)

    out = []
    for raw in rows:
        if isinstance(raw, TypedFact):
            out.append(raw)
            continue
        if hasattr(raw, "to_dict"):
            raw = raw.to_dict()
        if not isinstance(raw, Mapping):
            continue
        status = str(raw.get("status") or "present").strip().lower()
        if status == "ambiguous":
            status = "conflict"
        metric = normalize_metric(raw.get("metric") or raw.get("object") or raw.get("kind"))
        value = raw.get("value")
        if not metric and value is None:
            continue
        out.append(TypedFact(
            subject=raw.get("subject") or raw.get("object") or "",
            metric=metric,
            value=value,
            unit=raw.get("unit") or "",
            dimension=raw.get("dimension") or "",
            batch_id=raw.get("batch_id") or raw.get("batch") or default_batch,
            row_id=raw.get("row_id") or raw.get("anchor") or raw.get("cell") or "",
            status=status,
            span=_span_from_fact(raw),
            confidence=raw.get("confidence", 1.0),
            source=raw.get("source") or "parsed",
            quote=raw.get("quote") or raw.get("context") or "",
        ))
    return out
