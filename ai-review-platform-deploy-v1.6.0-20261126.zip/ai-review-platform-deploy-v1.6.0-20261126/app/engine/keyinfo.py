# -*- coding: utf-8 -*-
"""关键信息抽取（KIE）：独立能力模块。

定位：从合同/招标/公告等文档中抽取结构化字段（甲乙方、编号、金额、日期、地点等），
每个字段必须带原文证据（quote + 位置），确定性规则优先，模型只补缺字段且引文必须可核验。

设计原则：
1. 字段 schema 外置（FIELDS），新增字段不改执行逻辑；
2. 先规则后模型；规则命中即返回，模型只处理 missing；
3. 输出统一：{fields:[{key,label,value,raw,evidence{quote,start,end},confidence,method}], missing:[...]}
"""
import re

FIELDS = [
    {"key": "contract_no", "label": "合同编号", "type": "code",
     "patterns": [r"合同编号\s*[:：]?\s*([A-Za-z0-9\-〔〕\[\]（）()年第号\./]{3,60})"]},
    {"key": "project_name", "label": "项目名称", "type": "text",
     "patterns": [r"项目名称\s*[:：]\s*([^\n]{2,80})"]},
    {"key": "party_a", "label": "甲方", "type": "text",
     "patterns": [r"甲\s*方\s*(?:（[^）]*）)?\s*[:：]\s*([^\n]{2,80})",
                  r"甲\s*方\s*[:：]?\s*\n\s*([^\n]{2,80})"]},
    {"key": "party_b", "label": "乙方", "type": "text",
     "patterns": [r"乙\s*方\s*(?:（[^）]*）)?\s*[:：]\s*([^\n]{2,80})",
                  r"乙\s*方\s*[:：]?\s*\n\s*([^\n]{2,80})"]},
    {"key": "amount", "label": "合同金额（元）", "type": "number",
     "patterns": [r"(?:合同金额|合同价款|合同总价|总金额|价税合计)\s*(?:[:：]|为)?\s*(?:人民币)?\s*"
                  r"([0-9][0-9,，]*(?:\.[0-9]+)?\s*(?:万元|万|元)?)"]},
    {"key": "sign_place", "label": "签订地点", "type": "text",
     "patterns": [r"签订地点\s*[:：]\s*([^\n]{2,50})"]},
    {"key": "sign_date", "label": "签订日期", "type": "date",
     "patterns": [r"签订(?:时间|日期)\s*[:：]\s*([0-9]{4}\s*[年\-/\.]\s*[0-9]{1,2}\s*[月\-/\.]\s*[0-9]{1,2}\s*日?)"]},
    {"key": "validity", "label": "有效期", "type": "text",
     "patterns": [r"(?:有效期|服务期限|合同期限)\s*[:：]?\s*([^\n]{2,50})"]},
    {"key": "contact", "label": "联系人", "type": "text",
     "patterns": [r"(?:联系人|项目联系人)\s*[:：]\s*([^\n]{2,30})"]},
    {"key": "phone", "label": "联系电话", "type": "code",
     "patterns": [r"(?:联系电话|电话|手机)\s*[:：]\s*([0-9\-－—\s]{7,20})"]},
]


BID_FIELDS = [
    {"key": "tenderer", "label": "招标人", "type": "text",
     "patterns": [r"招\s*标\s*人\s*[:：]\s*([^\n]{2,60})"]},
    {"key": "bid_no", "label": "招标编号", "type": "code",
     "patterns": [r"招标编号\s*[:：]?\s*([A-Za-z0-9\-〔〕\[\]（）()年第号\./]{3,60})"]},
    {"key": "budget", "label": "预算金额（元）", "type": "number",
     "patterns": [r"(?:预算金额|最高限价|控制价)\s*(?:[:：]|为)?\s*(?:人民币)?\s*([0-9][0-9,，]*(?:\.[0-9]+)?\s*(?:万元|万|元)?)"]},
    {"key": "deadline", "label": "投标截止时间", "type": "text",
     "patterns": [r"(?:投标截止时间|截止时间)\s*[:：]\s*([^\n]{4,40})"]},
    {"key": "open_time", "label": "开标时间", "type": "text",
     "patterns": [r"开标时间\s*[:：]\s*([^\n]{4,40})"]},
]
ANNOUNCE_FIELDS = [
    {"key": "announce_no", "label": "公告编号", "type": "code",
     "patterns": [r"公告编号\s*[:：]?\s*([A-Za-z0-9\-〔〕\[\]（）()年第号\./]{3,60})"]},
    {"key": "publisher", "label": "发布单位", "type": "text",
     "patterns": [r"(?:发布单位|采购人|招标人)\s*[:：]\s*([^\n]{2,60})"]},
    {"key": "publish_date", "label": "发布日期", "type": "date",
     "patterns": [r"(?:发布日期|发布时间)\s*[:：]\s*([0-9]{4}\s*[年\-/\.]\s*[0-9]{1,2}\s*[月\-/\.]\s*[0-9]{1,2}\s*日?)"]},
]
PACK_FIELDS = {"contract": FIELDS, "bid": FIELDS + BID_FIELDS, "announcement": FIELDS + ANNOUNCE_FIELDS}


def _norm_date(s: str) -> str:
    m = re.search(r"(\d{4})\D+(\d{1,2})\D+(\d{1,2})", s or "")
    if not m:
        return (s or "").strip()
    y, mo, d = m.groups()
    return f"{int(y):04d}-{int(mo):02d}-{int(d):02d}"


def _to_yuan(raw: str):
    s = (raw or "").replace(",", "").replace("，", "").strip()
    m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*(万元|万|元)?", s)
    if not m:
        return None
    v = float(m.group(1))
    if m.group(2) in ("万元", "万"):
        v *= 10000
    return round(v, 2)


def _find_field(doc: str, spec: dict):
    for pat in spec.get("patterns") or []:
        m = re.search(pat, doc)
        if not m:
            continue
        raw = (m.group(1) or "").strip(" ：:。；;，,")
        if not raw:
            continue
        start, end = m.start(1), m.end(1)
        quote = doc[max(0, m.start() - 10):min(len(doc), m.end() + 10)].replace("\n", " ").strip()
        val = raw
        if spec["type"] == "number":
            val = _to_yuan(raw)
        elif spec["type"] == "date":
            val = _norm_date(raw)
        conf = 0.9 if spec["type"] in ("code", "number", "date") else 0.8
        return {"key": spec["key"], "label": spec["label"], "value": val, "raw": raw,
                "evidence": {"quote": quote, "start": start, "end": end},
                "confidence": conf, "method": "rule"}
    return None


def extract(text: str, doc_type: str = "contract", use_llm: bool = False) -> dict:
    """按文档类型字段包抽取；可选模型只补 missing 字段，且引文必须出现在原文。"""
    doc = text or ""
    specs = PACK_FIELDS.get(doc_type or "contract", FIELDS)
    fields, missing = [], []
    for spec in specs:
        got = _find_field(doc, spec)
        if got:
            fields.append(got)
        else:
            missing.append({"key": spec["key"], "label": spec["label"]})
    if use_llm and missing:
        try:
            fields.extend(_llm_fill(doc, missing, specs))
            got_keys = {f["key"] for f in fields}
            missing = [m for m in missing if m["key"] not in got_keys]
        except Exception:
            pass
    return {"fields": fields, "missing": missing,
            "doc_type": doc_type, "coverage": round(len(fields) / max(1, len(specs)), 3)}


def _llm_fill(doc: str, missing: list, specs: list) -> list:
    """模型补缺字段：要求逐字段输出 value+quote，quote 必须在原文出现。"""
    from . import hooks as _hk
    if _hk.llm_provider() is None:
        return []
    want = "、".join(f"{m['key']}({m['label']})" for m in missing)
    msgs = [{"role": "system", "content": "从文档中抽取字段。只输出 JSON：{\"fields\":[{\"key\":\"\",\"value\":\"\",\"quote\":\"原文逐字片段\"}]}；找不到就省略。"},
            {"role": "user", "content": f"需要字段：{want}\n\n文档：\n{doc[:8000]}"}]
    j = _hk.llm_json(_hk.llm_chat(msgs, max_tokens=600))
    out = []
    for it in (j.get("fields") or []):
        key, value, quote = str(it.get("key") or ""), str(it.get("value") or ""), str(it.get("quote") or "")
        spec = next((f for f in specs if f["key"] == key), None)
        if not spec or not value:
            continue
        if quote and quote not in doc:
            continue
        out.append({"key": key, "label": spec["label"], "value": value, "raw": value,
                    "evidence": {"quote": quote or doc[:80], "start": None, "end": None},
                    "confidence": 0.6, "method": "llm"})
    return out
