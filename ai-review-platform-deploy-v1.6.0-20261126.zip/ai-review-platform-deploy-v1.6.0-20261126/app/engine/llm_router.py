"""统一 LLM 解析点：DB 默认模型 → DB 可用 chat 候选兜底 → 环境变量兜底 → NONE。

所有需要调用模型的模块都必须走这里，禁止直接读 config.LLM。

T-104（2026-11-18，页面助手模型接入与默认模型兜底）：
- DB 没有默认模型（或默认模型不可用）时，自动按 created_at 选择第一个
  enabled=1、带有效 api_key、能力包含 chat 的模型；capabilities 为空的历史行
  按「对话」默认能力处理（旧库兼容），显式声明 ocr/vision/embed 的行不进入
  对话候选。
- 候选在真实调用中 401/限流/失败时，由 try_candidates()/chat_with_failover()
  继续尝试下一个候选；全部失败返回 ok=False 与真实错误状态，不伪造回答。
- resolve() 只做确定性选择与缓存，不在解析阶段发网络请求（避免给所有调用点
  增加探测开销）；需要真实容灾的调用点使用 chat_with_failover()。
"""
from __future__ import annotations

import os
import re
import threading
import time

from .. import config, db

_CACHE = {"at": 0.0, "cfg": None}
_TTL = 60.0
_TLS = threading.local()
_MAX_FAILOVER = 3  # 单次问答最多尝试的候选数（防止串行超时过长）

# 失败状态 → 中文说明（页面助手/管理端展示用；绝不包含密钥）
_ERR_LABELS = {
    "ok": "成功",
    "none": "无可用模型",
    "unauthorized": "认证失败（HTTP 401）",
    "payment_required": "余额/配额不足（HTTP 402）",
    "forbidden": "无权限（HTTP 403）",
    "model_not_found": "模型不存在（HTTP 404）",
    "rate_limited": "限流（HTTP 429）",
    "upstream_error": "上游服务错误（HTTP 5xx）",
    "http_error": "HTTP 错误",
    "timeout": "调用超时",
    "config_error": "模型配置不完整",
    "external_denied": "数据边界策略禁止外发",
    "empty": "模型返回空内容",
    "failed": "调用失败",
}


def error_label(status: str) -> str:
    """失败状态 → 可展示的中文原因（不含密钥/请求头）。"""
    s = str(status or "").strip()
    return _ERR_LABELS.get(s, s or "调用失败")


def set_agent_model(model_ref: str):
    """Agent Runtime 在节点执行期间绑定模型；空值恢复全局默认。"""
    _TLS.agent_model = str(model_ref or "").strip()


def agent_model() -> str:
    return str(getattr(_TLS, "agent_model", "") or "").strip()


def _timeout() -> int:
    return int(os.environ.get("RULEPROOF_LLM_TIMEOUT") or config.LLM.get("timeout_seconds", 20))


def _norm_url(url) -> str:
    return str(url or "").strip().rstrip("/").lower()


def _caps(raw) -> list:
    return [c.strip().lower() for c in str(raw or "").split(",") if c.strip()]


def _is_chat_capable(raw_caps) -> bool:
    """对话能力判定：显式 capabilities 含 chat，或历史行 capabilities 为空。

    空能力只按「对话」默认处理（旧库/种子行没有写 capabilities）；
    OCR / vision / embed 等显式声明的行绝不当作对话候选。
    """
    caps = _caps(raw_caps)
    return (not caps) or ("chat" in caps)


def _resolve_effective_key(row_key, row_base):
    """行内 Key 优先；行内无 Key 时仅允许复用环境 Key 且 base_url 必须匹配。

    返回 (key, key_source)；key_source ∈ {"row", "env", ""}。
    不允许把 DeepSeek 的环境 Key 配到其它 provider 的 base_url 上，避免伪造连通。
    """
    key = str(row_key or "").strip()
    if key:
        return key, "row"
    env_key = str(config.LLM.get("api_key") or "").strip()
    env_base = _norm_url(config.LLM.get("base_url"))
    base = _norm_url(row_base)
    if env_key and env_base and (not base or base == env_base):
        return env_key, "env"
    return "", ""


def _from_agent():
    ref = agent_model()
    if not ref:
        return None
    try:
        with db.session() as c:
            row = c.execute("SELECT base_url,api_key,model_id,name FROM model_config "
                            "WHERE (id=? OR model_id=? OR name=?) AND (status IS NULL OR status!='unconfigured') "
                            "ORDER BY is_default DESC, created_at DESC LIMIT 1",
                            (ref, ref, ref)).fetchone()
        if not row:
            return None
        base = (row["base_url"] or "").strip() or config.LLM.get("base_url", "")
        key = (row["api_key"] or "").strip() or config.LLM.get("api_key", "")
        model = (row["model_id"] or "").strip()
        if not (model and key):
            return None
        return {"base_url": base, "api_key": key, "model": model,
                "enabled": True, "source": f"AGENT:{row['name'] or model}",
                "timeout_seconds": _timeout()}
    except Exception:
        return None


def _from_override():
    """显式 RULEPROOF_MODEL_OVERRIDE（模型对照/测试用），优先于 DB。"""
    ov = (os.environ.get("RULEPROOF_MODEL_OVERRIDE") or "").strip()
    if not ov:
        return None
    return {"base_url": (os.environ.get("RULEPROOF_LLM_BASE_URL_OVERRIDE")
                         or config.LLM.get("base_url", "")),
            "api_key": (os.environ.get("RULEPROOF_LLM_KEY_OVERRIDE")
                        or config.LLM.get("api_key", "")),
            "model": ov, "enabled": True, "source": "OVERRIDE",
            "timeout_seconds": _timeout()}


def _from_db():
    """DB 默认模型（is_default=1）。无 Key 时返回 enabled=False（供兜底判断）。"""
    try:
        with db.session() as c:
            row = c.execute("SELECT base_url, api_key, model_id, name FROM model_config "
                            "WHERE is_default=1 AND (status IS NULL OR status != 'unconfigured') "
                            "ORDER BY created_at DESC LIMIT 1").fetchone()
        if not row:
            return None
        base = (row["base_url"] or "").strip() or config.LLM.get("base_url", "")
        model = (row["model_id"] or "").strip()
        if not model:
            return None
        key, key_src = _resolve_effective_key(row["api_key"], row["base_url"])
        source = f"DB:{row['name'] or model}"
        if key_src == "env":
            source = source + "+ENVKEY"
        return {"base_url": base, "api_key": key, "model": model,
                "enabled": bool(key), "source": source,
                "timeout_seconds": _timeout(), "key_source": key_src or "none",
                "is_default": True}
    except Exception:
        return None


def _db_chat_candidates():
    """DB 中 enabled + 有效 Key + chat 能力的模型，按 created_at 升序。

    默认模型（is_default=1）排最前；候选必须带有效 base_url/model/key，
    否则不进入列表（不伪造“可用”）。
    """
    try:
        with db.session() as c:
            rows = c.execute(
                "SELECT base_url, api_key, model_id, name, capabilities, is_default, created_at "
                "FROM model_config "
                "WHERE enabled=1 AND COALESCE(model_id,'')<>'' "
                "ORDER BY is_default DESC, created_at ASC, id ASC").fetchall()
    except Exception:
        return []
    out = []
    for row in rows:
        if not _is_chat_capable(row["capabilities"]):
            continue
        model = (row["model_id"] or "").strip()
        key, key_src = _resolve_effective_key(row["api_key"], row["base_url"])
        base = (row["base_url"] or "").strip() or config.LLM.get("base_url", "")
        if not (model and key and base):
            continue
        name = str(row["name"] or "").strip() or model
        source = f"DB:{name}"
        if key_src == "env":
            source = source + "+ENVKEY"
        out.append({"base_url": base, "api_key": key, "model": model,
                    "enabled": True, "source": source, "model_name": name,
                    "timeout_seconds": _timeout(),
                    "key_source": key_src, "is_default": bool(row["is_default"]),
                    "fallback": not bool(row["is_default"])})
    return out


def _from_env():
    c = config.LLM
    if not (c.get("enabled") and c.get("api_key")):
        return None
    return {"base_url": c.get("base_url", ""), "api_key": c.get("api_key", ""),
            "model": c.get("model", ""), "enabled": True, "source": "ENV",
            "timeout_seconds": _timeout(), "key_source": "env"}


def _none_cfg(reason: str = "") -> dict:
    cfg = {"base_url": "", "api_key": "", "model": "", "enabled": False,
           "source": "NONE", "timeout_seconds": 20}
    if reason:
        cfg["reason"] = reason
    return cfg


def candidates(refresh: bool = False) -> list:
    """按优先级返回可尝试的对话模型配置（默认模型 → DB chat 候选 → ENV）。

    仅返回带 base_url+model+api_key 的配置；显式关闭（RULEPROOF_LLM_ENABLED=0）、
    Agent 绑定、显式 OVERRIDE 时按对应语义返回。401/限流/失败后的继续尝试由
    try_candidates()/chat_with_failover() 负责。
    """
    if str(os.environ.get("RULEPROOF_LLM_ENABLED", "")).strip().lower() in ("0", "false", "no"):
        return []
    out = []
    _agent = _from_agent()
    if _agent:
        return [_agent] if (_agent.get("model") and _agent.get("api_key")
                            and _agent.get("base_url")) else []
    _ov = _from_override()
    if _ov:
        return [_ov] if (_ov.get("model") and _ov.get("api_key")) else []
    default = _from_db()
    if default and default.get("enabled") and default.get("api_key") and default.get("model"):
        out.append(default)
    for cfg in _db_chat_candidates():
        out.append(cfg)
    env = _from_env()
    if env and env.get("model") and env.get("api_key"):
        out.append(env)
    seen, deduped = set(), []
    for cfg in out:
        sig = (_norm_url(cfg.get("base_url")), str(cfg.get("model") or "").strip(),
               str(cfg.get("api_key") or ""))
        if sig in seen:
            continue
        seen.add(sig)
        deduped.append(cfg)
    return deduped


def resolve(refresh: bool = False) -> dict:
    """返回当前生效的模型配置：{base_url, api_key, model, enabled, source}。

    优先级：显式关闭 → Agent 绑定 → 显式 OVERRIDE → DB 默认模型 →
    DB 第一个可用 chat 候选（T-104 兜底）→ 环境变量 → NONE。
    """
    # 显式关闭（测试/离线）：优先于 DB 与其它环境变量
    if str(os.environ.get("RULEPROOF_LLM_ENABLED", "")).strip().lower() in ("0", "false", "no"):
        return {"base_url": "", "api_key": "", "model": "", "enabled": False,
                "source": "DISABLED", "timeout_seconds": 20,
                "reason": "RULEPROOF_LLM_ENABLED=0（显式关闭）"}
    # 环境覆盖（用于模型对照/测试，不改 DB 默认值，避免影响并发任务）
    _agent = _from_agent()
    if _agent:
        return _agent
    _ov = _from_override()
    if _ov:
        return _ov
    now = time.time()
    if not refresh and _CACHE["cfg"] is not None and now - _CACHE["at"] < _TTL:
        return _CACHE["cfg"]
    default = _from_db()
    if default and default.get("enabled") and default.get("api_key") and default.get("model"):
        cfg = default
    else:
        fallback = _db_chat_candidates()
        env = _from_env()
        if fallback:
            cfg = dict(fallback[0])
            cfg["fallback"] = True
            cfg["fallback_reason"] = ("default_model_missing" if not default
                                      else "default_model_unusable")
        elif env:
            cfg = dict(env)
            cfg["fallback"] = True
            cfg["fallback_reason"] = "no_db_chat_model"
        else:
            cfg = _none_cfg("DB 无默认模型/可用 chat 候选，环境变量也未配置可用 Key")
    _CACHE.update({"at": now, "cfg": cfg})
    return cfg


def invalidate():
    _CACHE.update({"at": 0.0, "cfg": None})


def status() -> dict:
    """管理端展示：当前生效来源、是否可用、是否与 env 不同。"""
    c = resolve(refresh=True)
    env = _from_env()
    return {"source": c.get("source"), "model": c.get("model"), "enabled": c.get("enabled"),
            "base_url": c.get("base_url"), "env_model": (env or {}).get("model", ""),
            "overridden": bool(env and c.get("model") != env.get("model")),
            "fallback": bool(c.get("fallback")),
            "reason": c.get("reason", "")}


def _http_status_of(exc) -> int | None:
    m = re.search(r"http\s*(\d{3})", f"{type(exc).__name__}: {exc}".lower())
    return int(m.group(1)) if m else None


def classify_error(exc) -> str:
    """模型调用异常 → 稳定状态串（unauthorized/rate_limited/timeout/...）。"""
    text = f"{type(exc).__name__}: {exc}".lower()
    if ("externalmodeldenied" in text or "external_model=deny" in text
            or "数据边界" in text):
        return "external_denied"
    code = _http_status_of(exc)
    if code is not None:
        if code == 401:
            return "unauthorized"
        if code == 402:
            return "payment_required"
        if code == 403:
            return "forbidden"
        if code == 404:
            return "model_not_found"
        if code == 429:
            return "rate_limited"
        if 500 <= code < 600:
            return "upstream_error"
        return "http_error"
    if "too many requests" in text or "rate limit" in text:
        return "rate_limited"
    if "invalid_api_key" in text or "authentication" in text or "unauthorized" in text:
        return "unauthorized"
    if "payment required" in text:
        return "payment_required"
    if "timeout" in text or "timed out" in text:
        return "timeout"
    if ("只允许 http/https" in text or "域名无法解析" in text or "不允许环回" in text
            or "base_url" in text or "模型配置" in text):
        return "config_error"
    if "空内容" in text or "empty" in text:
        return "empty"
    return "failed"


def _sanitize_error(exc, cfg: dict | None = None) -> str:
    """异常摘要脱敏：绝不把候选 Key/请求头写进返回或日志。"""
    s = str(exc or "")
    secret = str((cfg or {}).get("api_key") or "").strip()
    if secret:
        s = s.replace(secret, "***")
    s = re.sub(r"sk-[A-Za-z0-9_\-]{4,}", "sk-***", s)
    s = re.sub(r"(?i)(authorization|api[_-]?key)\s*[:=]\s*\S+", r"\1=***", s)
    return s[:240]


def _attempt(cfg: dict, status: str, latency_ms: int, error: str = "") -> dict:
    return {"source": str((cfg or {}).get("source") or ""),
            "model": str((cfg or {}).get("model") or ""),
            "model_name": str((cfg or {}).get("model_name")
                              or (cfg or {}).get("model") or ""),
            "status": status,
            "http_status": None,
            "latency_ms": int(latency_ms),
            "error": _sanitize_error(error, cfg) if error else ""}


def try_candidates(cfgs: list, messages: list, timeout: int = 15,
                   max_tokens: int = 512, temperature: float = 0,
                   max_candidates: int = _MAX_FAILOVER,
                   response_format: str | None = None) -> dict:
    """按顺序真实调用候选模型；401/限流/失败继续下一个，全部失败返回 ok=False。

    response_format 透传到 HTTP body（T1 半约束 JSON 解码：json_object）；默认 None
    时不写入任何字段，行为与改动前一致。

    返回（不含任何密钥）：
    {ok, content, model, model_name, source, status, latency_ms, total_latency_ms,
     attempts:[{source,model,model_name,status,http_status,latency_ms,error}],
     fallback, reason}
    """
    from . import llm as _llm  # 延迟导入，避免模块环

    ordered, seen = [], set()
    limit = max(1, int(max_candidates or 1))
    for cfg in list(cfgs or []):
        if not isinstance(cfg, dict):
            continue
        sig = (_norm_url(cfg.get("base_url")), str(cfg.get("model") or "").strip(),
               str(cfg.get("api_key") or ""))
        if sig in seen:
            continue
        seen.add(sig)
        ordered.append(cfg)
        if len(ordered) >= limit:
            break
    attempts = []
    total_ms = 0
    for cfg in ordered:
        t0 = time.time()
        try:
            content = _llm.chat_completion(
                str(cfg.get("base_url") or ""), str(cfg.get("api_key") or ""),
                str(cfg.get("model") or ""), messages,
                timeout=int(timeout or 15), max_tokens=int(max_tokens or 512),
                temperature=temperature, response_format=response_format)
            latency = int((time.time() - t0) * 1000)
            total_ms += latency
            attempts.append(_attempt(cfg, "ok", latency))
            return {"ok": True, "content": content,
                    "model": str(cfg.get("model") or ""),
                    "model_name": str(cfg.get("model_name") or cfg.get("model") or ""),
                    "source": str(cfg.get("source") or ""),
                    "status": "ok", "latency_ms": latency, "total_latency_ms": total_ms,
                    "attempts": attempts, "fallback": len(attempts) > 1,
                    "reason": ""}
        except Exception as exc:  # noqa: BLE001 - 逐个候选继续，不伪造成功
            latency = int((time.time() - t0) * 1000)
            total_ms += latency
            status = classify_error(exc)
            a = _attempt(cfg, status, latency, f"{type(exc).__name__}: {exc}")
            a["http_status"] = _http_status_of(exc)
            attempts.append(a)
    if not attempts:
        return {"ok": False, "content": "", "model": "", "model_name": "",
                "source": "NONE", "status": "none", "latency_ms": 0,
                "total_latency_ms": 0, "attempts": [], "fallback": False,
                "reason": "无可用模型（未提供候选配置）"}
    statuses = [a["status"] for a in attempts]
    primary = next((s for s in ("unauthorized", "rate_limited", "payment_required",
                                "external_denied", "config_error", "timeout",
                                "model_not_found", "upstream_error")
                    if s in statuses), statuses[-1])
    first = attempts[0]
    return {"ok": False, "content": "", "model": first["model"],
            "model_name": first["model_name"], "source": first["source"],
            "status": primary, "latency_ms": total_ms, "total_latency_ms": total_ms,
            "attempts": attempts, "fallback": len(attempts) > 1,
            "reason": f"已尝试 {len(attempts)} 个候选模型，全部失败：{error_label(primary)}"}


def chat_with_failover(messages: list, preferred: dict | None = None,
                       timeout: int = 15, max_tokens: int = 512,
                       temperature: float = 0,
                       response_format: str | None = None) -> dict:
    """页面助手等调用点的统一容灾入口：专用配置优先，再按 candidates() 兜底。

    候选 401/限流/失败自动继续下一个；全部失败返回 ok=False + 真实原因（不伪造）。
    response_format 透传（默认 None 不改行为）。
    """
    cfgs = []
    if isinstance(preferred, dict) and (preferred.get("model") or preferred.get("api_key")):
        cfgs.append(preferred)
    cfgs.extend(candidates())
    if not cfgs:
        # 兼容调用方已自行做过可用性门禁的场景（如测试注入）：仍尝试 resolve() 原样配置
        cfg = resolve()
        if isinstance(cfg, dict):
            cfgs.append(cfg)
    return try_candidates(cfgs, messages, timeout=timeout, max_tokens=max_tokens,
                          temperature=temperature, response_format=response_format)
