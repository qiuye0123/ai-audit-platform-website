"""PDF 逐页渲染（跨平台，无本地命令依赖）。
优先级：
1) pypdfium2（pip 安装，跨平台；默认）
2) pymupdf / fitz（若已安装；注意 AGPL 许可）
3) 外部渲染命令（RULEPROOF_PDF_RENDER_CMD，企业内网可自备）
都不可用 → 抛出明确异常，禁止静默返回空。
"""
import logging
import os
import subprocess
import tempfile


def _render_pypdfium2(path: str, outdir: str, max_pages: int) -> list:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    n = min(len(pdf), max_pages)
    out = []
    for i in range(n):
        page = pdf[i]
        bitmap = page.render(scale=2)
        pil = bitmap.to_pil()
        p = os.path.join(outdir, f"p{i + 1}.png")
        pil.save(p)
        out.append(p)
    return out


def _render_pymupdf(path: str, outdir: str, max_pages: int) -> list:
    import fitz
    doc = fitz.open(path)
    out = []
    for i in range(min(len(doc), max_pages)):
        pix = doc[i].get_pixmap(dpi=150)
        p = os.path.join(outdir, f"p{i + 1}.png")
        pix.save(p)
        out.append(p)
    return out


def _render_external(path: str, outdir: str, max_pages: int) -> list:
    cmd = (os.environ.get("RULEPROOF_PDF_RENDER_CMD") or "").strip()
    if not cmd:
        return []
    # 约定：命令接收 <pdf路径> <输出目录>，将 <=max_pages 页 PNG 写入目录，按页序命名
    r = subprocess.run(cmd.split() + [path, outdir], capture_output=True, text=True, timeout=300)
    if r.returncode != 0:
        raise RuntimeError(f"外部 PDF 渲染失败：{(r.stderr or '')[:120]}")
    files = sorted(f for f in os.listdir(outdir) if f.lower().endswith(".png"))
    return [os.path.join(outdir, f) for f in files[:max_pages]]


def render_pdf_pages(path: str, max_pages: int = 20) -> list:
    outdir = tempfile.mkdtemp(prefix="rp_pdfpages_")
    errors = []
    for name, fn in (("pypdfium2", _render_pypdfium2), ("pymupdf", _render_pymupdf),
                     ("external", _render_external)):
        try:
            out = fn(path, outdir, max_pages)
            if out:
                return out
        except Exception as e:  # noqa
            errors.append(f"{name}:{type(e).__name__}")
            logging.getLogger(__name__).debug("pdf render %s failed", name, exc_info=True)
    import shutil as _sh
    _sh.rmtree(outdir, ignore_errors=True)
    raise RuntimeError("无可用 PDF 渲染器（安装 pypdfium2，或配置 RULEPROOF_PDF_RENDER_CMD）：" + ",".join(errors))
