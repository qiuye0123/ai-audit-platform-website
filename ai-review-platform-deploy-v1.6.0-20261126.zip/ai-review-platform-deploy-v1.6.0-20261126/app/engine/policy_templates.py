# -*- coding: utf-8 -*-
"""六类确定性模板：自然语言条款 → typed IR v3（fail-closed）。

覆盖 limit / unit / date / consistency / prohibited / completeness 六类；
未知类型、缺单位、未知单位、不可映射算子一律拒绝（不产 IR、不猜）。
每个槽位保留原文 span（逐字回指），供反译互证使用。

来源：L63 原型（规格 82 号 §2）；L73 接入 lane 原样生产化，不改判定语义。
"""
from __future__ import annotations

import hashlib
import re
import math

from .policy_ir import (COMPILER_VERSION, SCHEMA_VERSION, _LOOSE_NUM_RE, _NUM_UNIT_RE, _coverage, _nm, _norm_unit, canonical_json, sha256_text, to_base)

NUM_MODALITY = [
    ("不得少于", ">=", True), ("不得低于", ">=", True), ("不应少于", ">=", True),
    ("不应低于", ">=", True), ("不少于", ">=", True), ("不低于", ">=", True),
    ("不小于", ">=", True), ("至少", ">=", True), (">=", ">=", True), ("≥", ">=", True),
    ("不得多于", "<=", True), ("不得高于", "<=", True), ("不得超过", "<=", True),
    ("不应超过", "<=", True), ("不应高于", "<=", True), ("不超过", "<=", True),
    ("不高于", "<=", True), ("不多于", "<=", True), ("不大于", "<=", True),
    ("至多", "<=", True), ("最多", "<=", True), ("<=", "<=", True), ("≤", "<=", True),
    ("必须等于", "=", True), ("应等于", "=", True), ("等于", "=", True),
    ("恰好为", "=", True), ("==", "=", True), ("＝", "=", True),
    ("小于", "<", False), ("低于", "<", False), ("少于", "<", False),
    ("大于", ">", False), ("高于", ">", False), ("超过", ">", False),
]

# 日期绝对比较词表
DATE_MODALITY = [
    ("不得晚于", "before", True), ("不晚于", "before", True), ("应早于", "before", True),
    ("早于", "before", True), ("之前", "before", True),
    ("不得早于", "after", True), ("不早于", "after", True), ("应晚于", "after", True),
    ("晚于", "after", True), ("之后", "after", True),
]

# 禁止性/完整性/一致性模态
PROHIBIT_MODALS = ("严禁", "禁止", "不得", "不允许", "不应", "不可", "杜绝")
COMPLETE_MODALS = ("必须包含", "应包含", "需包含", "必须提供", "应提供", "需提供",
                   "必须配备", "应配备", "需配备", "必须附", "应当有", "必须有")
CONSISTENCY_EQUALITY = ("应当一致", "必须一致", "应一致", "应相符", "必须相符",
                        "应相同", "应相等", "必须相等")
TOLERANCE_WORDS = ("偏差", "尾差", "差值", "误差", "差额")

# 粒度词
_GRANULARITY = [
    ("per_group", ("每组", "每一组", "逐组")),
    ("per_model", ("每个型号", "逐型号", "每个规格", "逐规格")),
    ("per_batch", ("每批", "本批", "逐批")),
    ("per_item", ("每份", "逐份", "每册", "逐册", "每联", "逐联", "每套", "逐套")),
    ("per_record", ("每条", "每一条", "逐条", "每笔", "逐笔")),
]

# 语义限定词：需要证据语义/人工复核，确定性执行器不能直接判
_SEMANTIC_QUALIFIERS = [("independence", ("独立", "相互独立")),
                        ("authenticity", ("真实", "真实性", "未伪造")),
                        ("completeness_semantic", ("齐全", "齐套"))]

_OBJECT_STRIP_SUFFIX = ("正式受理且未撤回", "正式受理", "未撤回", "正常运行", "正在运行",
                        "有效期内", "审核期间", "评标期间", "采购过程中", "执行期间",
                        "范围内", "过程中")
_OBJECT_LEAD_STRIP = ("在", "对于", "针对", "本", "该")
_OBJECT_MODAL_SPLIT = re.compile(r"(?:应当|必须|须|应|需|一律|不得|禁止|严禁|不允许|不可)")
_CONDITION_SUFFIX_RE = re.compile(
    r"^(?P<obj>.{2,14}?)(?:正式受理且未撤回|正式受理|未撤回|有效期内|审核期间|"
    r"评标期间|采购过程中|执行期间|期间|过程中|范围内|时)$"
)
_PROCESS_MARKERS = ("工位", "工序", "生产线", "车间", "线", "台", "库", "区", "室",
                    "站", "岗")
_METRIC_LEAD_STRIP = (
    "每一条受理记录的", "每一条的", "每一组的", "每组的", "每个型号的", "每个规格的",
    "每批的", "每单的", "每份的", "每册的", "每联的", "每套的", "每笔的", "逐条的",
    "该笔的", "本单的", "本条记录的", "该记录的", "本次的", "该批的", "的",
)
_EVIDENCE_RE = re.compile(r"证据[：:]\s*(?P<src>[^，,。；;]+)")
_EVIDENCE_LOC_RE = re.compile(r"位置[：:]\s*(?P<loc>[^，,。；;]+)")
_EVIDENCE_MIN_RE = re.compile(r"至少\s*(?P<n>\d+)\s*(?:条|项|份|个)")
_EXCEPTION_RE = re.compile(r"(?:例外|除外)[：:]\s*(?P<cond>[^。；;]+)")
_CONSEQ_RE = {
    "label": re.compile(r"后果[：:]\s*(?P<v>[^，,。；;]+)"),
    "action": re.compile(r"处置[：:]\s*(?P<v>[^，,。；;]+)"),
    "owner": re.compile(r"责任[：:]\s*(?P<v>[^，,。；;]+)"),
    "close_condition": re.compile(r"关闭条件[：:]\s*(?P<v>[^，,。；;]+)"),
}
_INCLUSIVE_RE = re.compile(r"(?:不含边界|不包含边界|不含|开区间)")
_EXCLUSIVE_RE = re.compile(r"(?:含边界|包含边界|含)")
_CLAUSE_SPLIT_RE = re.compile(r"[；;。\n]")

def _clauses(text: str):
    """按句号/分号/换行切分 clause，保留原文偏移。"""
    out, start = [], 0
    for m in _CLAUSE_SPLIT_RE.finditer(text):
        out.append((text[start:m.start()], start, m.start()))
        start = m.end()
    if start < len(text):
        out.append((text[start:], start, len(text)))
    return [c for c in out if c[0].strip()]


def _first_clause(text: str) -> str:
    clauses = _clauses(text)
    return clauses[0][0].strip() if clauses else text.strip()


def _find_span(text: str, needle: str):
    idx = text.find(needle)
    if idx < 0:
        return None
    return {"start": idx, "end": idx + len(needle), "text": needle}


def _slot(text, needle):
    """返回槽位值 + 原文 span（逐字）；找不到返回 None。"""
    if needle is None:
        return None
    span = _find_span(text, str(needle))
    if span is None:
        return None
    return span


def _numeric_modality(text):
    """按出现位置取最早的数值比较词；同位置取最长。返回 (op, op_text, inclusive, pos)。"""
    best = None
    for word, op, incl in NUM_MODALITY:
        idx = text.find(word)
        if idx < 0:
            continue
        cand = (idx, -len(word), word, op, incl)
        if best is None or cand[:2] < best[:2]:
            best = cand
    if best is None:
        return None
    return {"op": best[3], "text": best[2], "inclusive": best[4], "start": best[0],
            "end": best[0] + len(best[2])}


def _date_modality(text):
    best = None
    for word, op, incl in DATE_MODALITY:
        idx = text.find(word)
        if idx < 0:
            continue
        cand = (idx, -len(word), word, op, incl)
        if best is None or cand[:2] < best[:2]:
            best = cand
    if best is None:
        return None
    return {"op": best[3], "text": best[2], "inclusive": best[4], "start": best[0]}


def _first_of(text, words):
    for w in words:
        idx = text.find(w)
        if idx >= 0:
            return {"word": w, "start": idx}
    return None


def _unit_after(text, pos):
    """从 pos 起取 "数值 + 单位"；返回 dict 或 None。用于宽松探测缺单位/未知单位。"""
    m = _NUM_UNIT_RE.search(text, pos)
    if m:
        return {"value_raw": m.group("value"), "unit_raw": m.group("unit"),
                "start": m.start("value"), "unit_start": m.start("unit"),
                "unit_end": m.end("unit")}
    loose = _LOOSE_NUM_RE.search(text, pos)
    if loose:
        return {"value_raw": loose.group("value"), "unit_raw": loose.group("tail") or None,
                "start": loose.start("value"), "unit_start": loose.start("tail"),
                "unit_end": loose.end("tail")}
    return None


def _is_inclusive(text, default=True):
    if _INCLUSIVE_RE.search(text):
        return False
    if _EXCLUSIVE_RE.search(text):
        return True
    return default


def _date_literal(text):
    m = re.search(r"(?P<y>\d{4})\s*[-/年]\s*(?P<m>\d{1,2})\s*[-/月]\s*(?P<d>\d{1,2})\s*日?",
                  text)
    if not m:
        return None
    y, mo, d = int(m.group("y")), int(m.group("m")), int(m.group("d"))
    if not (1 <= mo <= 12 and 1 <= d <= 31):
        return None
    return {"iso": f"{y:04d}-{mo:02d}-{d:02d}", "raw": m.group(0),
            "start": m.start(), "end": m.end()}


def _time_metric_word(text):
    return any(w in text for w in ("间隔", "时差", "提前量", "时限", "时长", "期限",
                                   "周期", "日期", "天数", "用时", "耗时"))


def _granularity(text):
    for grain, words in _GRANULARITY:
        if any(w in text for w in words):
            return grain
    return "per_record"


def _semantic_qualifier(text):
    for q, words in _SEMANTIC_QUALIFIERS:
        if any(w in text for w in words):
            return q
    return None


def _strip_metric(operand: str) -> str:
    s = operand.strip().strip("，,；;。：: ")
    for lead in _METRIC_LEAD_STRIP:
        if lead and s.startswith(lead):
            s = s[len(lead):]
            break
    return s.strip() or operand.strip()


def _extract_object(text, first_clause, metric=None):
    """对象抽取（确定性字符串处理，不调模型）：

    首 clause → 截断到首个模态/动词 → 去条件后缀（正式受理且未撤回时/期间…）→
    去短时间前缀（对账时…）→ 按「的」取首段 → 去 metric 后缀。
    抽不到返回 None（上层回退 metric，校验另判）。
    """
    cand = first_clause.strip().strip("，,；;。 ")
    cand = cand.lstrip("在")
    m = _OBJECT_MODAL_SPLIT.search(cand)
    if m:
        cand = cand[:m.start()].strip()
    # 条件后缀：仅当后缀后是结尾/标点/"时" 才接受（防 "时间" 被 "时" 误切）
    for suffix in sorted(_OBJECT_STRIP_SUFFIX, key=len, reverse=True):
        idx = cand.find(suffix)
        if not (0 < idx <= 12):
            continue
        rest = cand[idx + len(suffix):].lstrip()
        if rest == "" or rest[0] in "，,；;。：:时":
            cand = cand[:idx].strip()
            break
    # 短时间前缀："对账时结算金额…" → obj "对账"（obj 不超过 4 字；"时间" 结尾不切）
    m = re.match(r"^(?P<obj>.{2,4}?)时(?P<rest>.*)$", cand)
    if m and not m.group("rest").startswith(("间", "刻", "段", "长", "限")):
        cand = m.group("obj").strip()
    if "的" in cand:
        head = cand.split("的")[0].strip()
        if len(head) >= 2:
            cand = head
    for lead in _OBJECT_LEAD_STRIP:
        if cand.startswith(lead) and len(cand) > len(lead) + 1:
            cand = cand[len(lead):].strip()
    if metric and cand.endswith(metric) and len(cand) > len(metric):
        cand = cand[:-len(metric)].strip()
    return cand.strip() or None


def _split_object_metric(operand):
    """在过程标记（工位/线/台/库/区/批…）处把操作数切成 (object, metric)。

    仅在标记后仍有 >=2 字指标名时切分，避免把指标名本身切断。
    """
    operand = operand.strip()
    for marker in _PROCESS_MARKERS:
        idx = operand.find(marker)
        if idx <= 0:
            continue
        cut = idx + len(marker)
        if len(operand) - cut >= 2:
            return operand[:cut].strip(), operand[cut:].strip()
    return None, operand

# ---------------------------------------------------------------------------
# 1) compile_rule：文本切分 → 槽位抽取 → 类型推断 → IR
# ---------------------------------------------------------------------------
def _classify(text, first):
    """类型推断（确定性优先级，互斥）：
    unit > prohibited > completeness > consistency > date > limit；无法归类 → unknown。
    """
    if re.search(r"以[^，。；]{1,8}为单位", text) or re.search(r"保留\s*\d+\s*位小数", text) \
            or re.search(r"1\s*[A-Za-z][\w·/^]*\s*=\s*[\d.]+\s*[A-Za-z][\w·/^]*", text):
        return "unit"
    if _first_of(first, PROHIBIT_MODALS) and not _numeric_modality(first) \
            and not _date_modality(first):
        return "prohibited"
    if _first_of(first, COMPLETE_MODALS):
        return "completeness"
    if _first_of(first, CONSISTENCY_EQUALITY) or (
            any(w in first for w in TOLERANCE_WORDS) and "绝对值" in first
            and re.search(r"与|和", first)):
        return "consistency"
    if _date_literal(text):
        return "date"
    if _time_metric_word(first) and (_numeric_modality(text) or _date_modality(text)):
        return "date"
    if _numeric_modality(text):
        return "limit"
    return "unknown"


def _rejected(text, reason, detail, rule_type=None):
    return {
        "status": "rejected",
        "rule_type": rule_type,
        "errors": [{"code": reason, "message": detail}],
        "warnings": [],
        "ir": None,
        "source_sha256": sha256_text(text),
        "source_chars": len(text),
    }


def _compile_unit(text, first=None):
    """unit 模板：换算规则或取整/口径规则。"""
    conv = re.search(r"1\s*(?P<frm>[A-Za-z·/^][\w·/^]*)\s*=\s*(?P<factor>[\d.]+)\s*"
                     r"(?P<to>[A-Za-z·/^][\w·/^]*)", text)
    if conv:
        factor = float(conv.group("factor"))
        if not math.isfinite(factor) or factor <= 0:
            return None, [{"code": "invalid_conversion_factor",
                           "message": f"换算系数非法：{conv.group('factor')}"}]
        cond = {"kind": "conversion",
                "from_unit": conv.group("frm"), "to_unit": conv.group("to"),
                "factor": _nm(factor), "factor_raw": conv.group("factor"),
                "notInPlatformIR": True}
        obj = None
        metric = {"name": "单位换算", "field": "单位换算", "datatype": "unit"}
        return {"condition": cond, "object": obj, "metric": metric,
                "spans": {"condition": {"start": conv.start(), "end": conv.end(),
                                        "text": conv.group(0)}}}, []
    m = re.search(r"(?P<obj>[^，。；]{1,16}?)一律以(?P<unit>[^，。；]{1,8}?)为单位",
                  text)
    d = re.search(r"保留\s*(?P<d>\d+)\s*位小数", text)
    if m or d:
        unit_raw = m.group("unit") if m else None
        if unit_raw and _norm_unit(unit_raw) is None:
            return None, [{"code": "unknown_unit",
                           "message": f"未知单位：{unit_raw}"}]
        obj_raw = m.group("obj").strip() if m else None
        cond = {"kind": "rounding",
                "unit": unit_raw,
                "unit_norm": (_norm_unit(unit_raw) if unit_raw else None),
                "decimals": int(d.group("d")) if d else None,
                "notInPlatformIR": True}
        return {"condition": cond,
                "object": obj_raw if obj_raw else "计量口径",
                "metric": {"name": "计量单位", "field": "计量单位", "datatype": "unit"},
                "spans": {"condition": _slot(text, d.group(0) if d else m.group(0))}}, []
    return None, [{"code": "unknown_rule_type", "message": "unit 模板未匹配到换算或取整规则"}]


def _compile_prohibited(text, first):
    modal = _first_of(first, PROHIBIT_MODALS)
    if not modal:
        return None, [{"code": "unknown_rule_type", "message": "未找到禁止性模态词"}]
    after = first[modal["start"] + len(modal["word"]):]
    after = after.split("；")[0]
    items = [s.strip("，,。；;、 ") for s in re.split(r"[、，,]", after) if s.strip("，,。；;、 ")]
    if not items:
        return None, [{"code": "unknown_rule_type", "message": "禁止性条款缺少禁止事项"}]
    obj = _extract_object(text, first)
    cond = {"kind": "prohibited", "modal": modal["word"],
            "forbidden": items, "match": "contains", "negation": True}
    metric = {"name": "禁止事项", "field": "禁止事项", "datatype": "text"}
    return {"condition": cond, "object": obj, "metric": metric,
            "spans": {"condition": _slot(text, items[0]),
                      "modal": _slot(text, modal["word"])}}, []


def _compile_completeness(text, first):
    modal = _first_of(first, COMPLETE_MODALS)
    if not modal:
        return None, [{"code": "unknown_rule_type", "message": "未找到完整性模态词"}]
    after = first[modal["start"] + len(modal["word"]):]
    after = after.split("；")[0]
    if "或" in after:
        mode = "any"
        items = [s.strip("，,。；;、 ") for s in re.split(r"或", after) if s.strip("，,。；;、 ")]
    else:
        mode = "all"
        items = [s.strip("，,。；;、 ") for s in re.split(r"[、，,]", after) if s.strip("，,。；;、 ")]
    if not items:
        return None, [{"code": "unknown_rule_type", "message": "完整性条款缺少必备项"}]
    obj = _extract_object(text, first)
    cond = {"kind": "completeness", "modal": modal["word"], "required": items,
            "match_mode": mode}
    metric = {"name": "必备材料", "field": "必备材料", "datatype": "text"}
    return {"condition": cond, "object": obj, "metric": metric,
            "spans": {"condition": _slot(text, modal["word"])}}, []


def _compile_consistency(text, first):
    if _first_of(first, CONSISTENCY_EQUALITY):
        eq = _first_of(first, CONSISTENCY_EQUALITY)
        rel = re.search(r"(?P<left>[^，。；：:]{1,20}?)(?:与|和)(?P<right>[^，。；：:]{1,20}?)"
                        r"(?:应|必须|应当)", first)
        left = rel.group("left") if rel else None
        right = rel.group("right") if rel else None
        if left:
            for lead in ("每一条受理记录的", "每一条的", "该记录的", "的"):
                if left.startswith(lead):
                    left = left[len(lead):]
        cond = {"kind": "equality", "operator": "=", "op_text": eq["word"],
                "left": left, "right": right, "value": None, "unit": None,
                "inclusive": True}
        obj = _extract_object(text, first)
        metric = {"name": f"{left}与{right}一致性" if left and right else "对象一致性",
                  "field": "一致性关系", "datatype": "text"}
        return {"condition": cond, "object": obj, "metric": metric,
                "spans": {"condition": _slot(text, eq["word"])}}, []
    tol = re.search(r"(?P<left>[^，。；：:]{1,20}?)(?:与|和)(?P<right>[^，。；：:]{1,20}?)的"
                    r"(?P<kind>偏差|尾差|差值|误差|差额)(?:绝对值)?", first)
    modal = _numeric_modality(first)
    if not tol or not modal:
        return None, [{"code": "unknown_rule_type",
                       "message": "一致性模板未匹配到可比较对象或比较词"}]
    num = _unit_after(first, modal["end"])
    if not num:
        return None, [{"code": "missing_threshold", "message": "一致性条款缺少阈值"}]
    entry = _norm_unit(num["unit_raw"])
    if entry is None:
        return None, [{"code": "unknown_unit", "message": f"未知单位：{num['unit_raw']}"}]
    left = tol.group("left").strip()
    right = tol.group("right").strip()
    obj = _extract_object(text, first)
    if obj and left.startswith(obj):
        left = left[len(obj):].lstrip("的时")
    for lead in ("每一条受理记录的", "每一条的", "该记录的"):
        if left.startswith(lead):
            left = left[len(lead):]
    incl = _is_inclusive(first, default=modal["inclusive"])
    cond = {"kind": "tolerance", "operator": modal["op"], "op_text": modal["text"],
            "left": left, "right": right, "tolerance_kind": tol.group("kind"),
            "value": _nm(float(num["value_raw"])), "value_raw": num["value_raw"],
            "unit": num["unit_raw"], "unit_norm": entry,
            "canonical_value": _nm(to_base(float(num["value_raw"]), num["unit_raw"])),
            "inclusive": incl, "datatype": "number"}
    metric = {"name": f"{left}与{right}的{tol.group('kind')}",
              "field": f"{tol.group('kind')}绝对值", "datatype": "number"}
    return {"condition": cond, "object": obj, "metric": metric,
            "spans": {"condition": _slot(text, num["value_raw"] + num["unit_raw"])
                      or _slot(text, num["value_raw"]),
                      "operator": _slot(text, modal["text"])}}, []


def _compile_date(text, first):
    lit = _date_literal(text)
    dmod = _date_modality(first)
    if lit and dmod:
        anchor = first[:dmod["start"]].strip()
        anchor = _extract_object(text, first, metric=anchor) or anchor
        cond = {"kind": "date_absolute", "operator": dmod["op"], "op_text": dmod["text"],
                "date": lit["iso"], "date_raw": lit["raw"], "inclusive": dmod["inclusive"],
                "datatype": "date"}
        metric = {"name": anchor or "日期", "field": "日期", "datatype": "date"}
        obj = _extract_object(text, first, metric=anchor)
        return {"condition": cond, "object": obj or anchor, "metric": metric,
                "spans": {"condition": _slot(text, lit["raw"]),
                          "operator": _slot(text, dmod["text"])}}, []
    if not (_time_metric_word(first) or _time_metric_word(text)):
        return None, [{"code": "unknown_rule_type", "message": "date 模板缺少日期或时间差语义"}]
    modal = _numeric_modality(first)
    if not modal:
        return None, [{"code": "unknown_rule_type", "message": "date 模板缺少比较词"}]
    num = _unit_after(first, modal["end"])
    if not num:
        return None, [{"code": "missing_threshold", "message": "时间差条款缺少阈值"}]
    entry = _norm_unit(num["unit_raw"])
    if entry is None:
        return None, [{"code": "unknown_unit", "message": f"未知单位：{num['unit_raw']}"}]
    if entry["dim"] != "time":
        return None, [{"code": "unit_dimension_mismatch",
                       "message": f"时间差规则单位不是时间维度：{num['unit_raw']}"}]
    operand = first[:modal["start"]].strip()
    for sep in ("，", ","):
        if sep in operand:
            operand = operand.split(sep)[-1]
    split_obj, metric_name = _split_object_metric(_strip_metric(operand))
    metric_name = _strip_metric(metric_name)
    obj = split_obj or _extract_object(text, first, metric=metric_name)
    cond = {"kind": "date_gap", "operator": modal["op"], "op_text": modal["text"],
            "value": _nm(float(num["value_raw"])), "value_raw": num["value_raw"],
            "unit": num["unit_raw"], "unit_norm": entry,
            "canonical_value": _nm(to_base(float(num["value_raw"]), num["unit_raw"])),
            "inclusive": _is_inclusive(first, default=modal["inclusive"]),
            "datatype": "date"}
    metric = {"name": metric_name, "field": f"{metric_name}实录", "datatype": "date"}
    return {"condition": cond, "object": obj, "metric": metric,
            "spans": {"condition": _slot(text, num["value_raw"] + num["unit_raw"])
                      or _slot(text, num["value_raw"]),
                      "operator": _slot(text, modal["text"])}}, []


def _compile_limit(text, first):
    modal = _numeric_modality(first)
    if not modal:
        return None, [{"code": "unknown_operator", "message": "未识别到数值比较词"}]
    num = _unit_after(first, modal["end"])
    if not num:
        loose = re.search(r"\d+(?:\.\d+)?", first[modal["end"]:])
        if loose:
            return None, [{"code": "missing_unit",
                           "message": "阈值缺少单位（fail-closed：不得无单位判定）"}]
        return None, [{"code": "missing_threshold", "message": "未找到数值阈值"}]
    if not num.get("unit_raw"):
        return None, [{"code": "missing_unit",
                       "message": "阈值缺少单位（fail-closed：不得无单位判定）"}]
    entry = _norm_unit(num["unit_raw"])
    if entry is None:
        return None, [{"code": "unknown_unit",
                       "message": f"未知单位：{num['unit_raw']}（fail-closed）"}]
    operand = first[:modal["start"]].strip()
    for sep in ("，", ","):
        if sep in operand:
            operand = operand.split(sep)[-1]
    split_obj, metric_name = _split_object_metric(_strip_metric(operand))
    metric_name = _strip_metric(metric_name)
    if not metric_name:
        return None, [{"code": "missing_metric", "message": "未识别到指标名"}]
    obj = split_obj or _extract_object(text, first, metric=metric_name)
    value = _nm(float(num["value_raw"]))
    cond = {"kind": "numeric_limit", "operator": modal["op"], "op_text": modal["text"],
            "value": value, "value_raw": num["value_raw"],
            "unit": num["unit_raw"], "unit_norm": entry,
            "canonical_value": _nm(to_base(float(num["value_raw"]), num["unit_raw"])),
            "inclusive": _is_inclusive(first, default=modal["inclusive"]),
            "datatype": "number"}
    metric = {"name": metric_name, "field": f"{metric_name}实录", "datatype": "number"}
    return {"condition": cond, "object": obj, "metric": metric,
            "spans": {"condition": _slot(text, num["value_raw"] + num["unit_raw"])
                      or _slot(text, num["value_raw"]),
                      "operator": _slot(text, modal["text"]),
                      "metric": _slot(text, metric_name)}}, []


_COMPILERS = {
    "unit": _compile_unit,
    "prohibited": _compile_prohibited,
    "completeness": _compile_completeness,
    "consistency": _compile_consistency,
    "date": _compile_date,
    "limit": _compile_limit,
}


def _extract_envelope(text):
    """从原文抽取 scope 生效条件 / 例外 / 证据 / 后果（声明式，缺省不编造）。"""
    ev_src = _EVIDENCE_RE.search(text)
    ev_loc = _EVIDENCE_LOC_RE.search(text)
    ev_min = _EVIDENCE_MIN_RE.search(text)
    declared = bool(ev_src or ev_loc or ev_min)
    evidence = {
        "declared": declared,
        "source": ev_src.group("src").strip() if ev_src else None,
        "locator": ev_loc.group("loc").strip() if ev_loc else (None if not declared
                                                               else "指标所在位置"),
        "min_count": int(ev_min.group("n")) if ev_min else (1 if declared else 1),
        "conflict_handling": "并列展示冲突值并提交复核" if declared else None,
        "derived": not declared,
    }
    exc = _EXCEPTION_RE.search(text)
    exceptions = {"declared": bool(exc), "items": []}
    if exc:
        exceptions["items"].append({"condition": exc.group("cond").strip(),
                                    "approver": None, "proof": None,
                                    "validity": None})
    consequence = {"declared": False, "label": None, "action": None,
                   "owner": None, "close_condition": None}
    for key, rx in _CONSEQ_RE.items():
        m = rx.search(text)
        if m:
            consequence[key] = m.group("v").strip()
            consequence["declared"] = True
    effective = None
    m = re.search(r"(?:^|[，,；;])(?P<c>[^，,。；;]{2,24}?(?:时|期间|范围内))[，,]",
                  text)
    if m:
        effective = m.group("c").strip()
    return evidence, exceptions, consequence, effective

def compile_rule(text: str) -> dict:
    """自然语言条款 → typed IR（policy-ir/v3）。

    返回 {"status": "compiled"|"rejected", "rule_type", "ir", "errors", "warnings", ...}。
    未知类型 / 缺单位 / 未知单位 / 不可映射算子 → rejected（fail-closed，不产 IR）。
    """
    if not isinstance(text, str) or not text.strip():
        return _rejected("", "empty_text", "规则文本为空")
    norm_text = text.strip()
    first = _first_clause(norm_text)
    rtype = _classify(norm_text, first)
    if rtype == "unknown":
        return _rejected(norm_text, "unknown_rule_type",
                         "无法映射到已注册规则类型（limit/unit/date/consistency/"
                         "prohibited/completeness），fail-closed 拒绝编译")
    built, errors = _COMPILERS[rtype](norm_text, first)
    if errors:
        return _rejected(norm_text, errors[0]["code"], errors[0]["message"], rtype)
    evidence, exceptions, consequence, effective = _extract_envelope(norm_text)
    obj = built.get("object")
    metric = built["metric"]
    if not obj and rtype != "unit":
        obj = metric["name"]
    grain = _granularity(norm_text)
    qualifier = _semantic_qualifier(first)
    warnings = []
    if evidence["derived"]:
        warnings.append({"code": "evidence_derived",
                         "message": "原文未声明证据要求，IR 标记 derived；发布门 blocking 模式将阻断"})
    if not exceptions["declared"]:
        warnings.append({"code": "exception_undeclared",
                         "message": "原文未声明例外条款（IR 记录 declared=false，不编造）"})
    if not consequence["declared"]:
        warnings.append({"code": "consequence_undeclared",
                         "message": "原文未声明后果类别（IR 记录 declared=false，不编造）"})
    if qualifier:
        warnings.append({"code": "semantic_qualifier",
                         "message": f"含语义限定项 {qualifier}：确定性执行器不能直接判定，需证据语义核验"})
    industry = None
    for ind in ("食品", "合同", "招采", "采购", "医疗", "建筑", "环保", "教育"):
        if ind in norm_text:
            industry = ind
            break
    cond = built["condition"]
    cond_spans = built.get("spans", {})
    ir_body = {
        "schema_version": SCHEMA_VERSION,
        "rule_type": rtype,
        "status": "compiled",
        "source": {
            "text": norm_text,
            "sha256": sha256_text(norm_text),
            "chars": len(norm_text),
            "span": {"start": 0, "end": len(norm_text), "text": norm_text},
        },
        "subject": {
            "object": obj,
            "object_span": _slot(norm_text, obj) if obj else None,
            "granularity": grain,
            "semantic_qualifier": qualifier,
        },
        "metric": {
            "name": metric["name"],
            "field": metric.get("field", metric["name"]),
            "datatype": metric.get("datatype", "number"),
            "span": cond_spans.get("metric"),
        },
        "condition": cond,
        "condition_spans": {
            "operator": cond_spans.get("operator"),
            "value": cond_spans.get("condition"),
        },
        "scope": {
            "industry": industry or "通用",
            "process": obj,
            "effective": effective,
            "out_of_scope": "na",
        },
        "exceptions": exceptions,
        "evidence": evidence,
        "consequence": consequence,
        "compile": {
            "compiler_version": COMPILER_VERSION,
            "template": rtype,
            "mode": "deterministic",
            "model_calls": 0,
            "unknown": [],
            "warnings": [w["code"] for w in warnings],
        },
        "coverage": {
            "required_slots": ["object", "metric", "operator", "threshold", "unit",
                               "scope", "evidence", "exception", "consequence"],
            "declared_slots": [],
            "gaps": [],
        },
    }
    ir_body["coverage"] = _coverage(ir_body)
    ir_body["ir_id"] = "ir-" + hashlib.sha256(
        canonical_json({k: ir_body[k] for k in ("rule_type", "source", "subject",
                                                "metric", "condition")}).encode("utf-8")
    ).hexdigest()[:16]
    ir = ir_body
    if rtype == "unit":
        ir["subject"]["object"] = obj
    return {
        "status": "compiled",
        "rule_type": rtype,
        "ir": ir,
        "errors": [],
        "warnings": warnings,
        "source_sha256": ir["source"]["sha256"],
        "source_chars": len(norm_text),
    }

def shadow_slots(text):
    """独立 shadow 抽取器：只从原文重新取「核心可判定槽位」，不复制 compile 的字段逻辑。"""
    first = _first_clause(text)
    rtype = _classify(text, first)
    slots = {"rule_type": rtype, "critical_total": 0, "critical_present": 0}
    if rtype == "limit":
        m = _numeric_modality(first)
        num = _unit_after(first, m["end"]) if m else None
        slots.update({"op": m["op"], "value": float(num["value_raw"]) if num else None,
                      "unit": num.get("unit_raw") if num else None})
        slots["critical_total"] = 3
    elif rtype == "date":
        lit = _date_literal(text)
        if lit:
            dm = _date_modality(first)
            slots.update({"date": lit["iso"], "op": dm["op"] if dm else None})
            slots["critical_total"] = 2
        else:
            m = _numeric_modality(first)
            num = _unit_after(first, m["end"]) if m else None
            slots.update({"op": m["op"], "value": float(num["value_raw"]) if num else None,
                          "unit": num.get("unit_raw") if num else None})
            slots["critical_total"] = 3
    elif rtype == "consistency":
        if _first_of(first, CONSISTENCY_EQUALITY):
            rel = re.search(r"(?P<left>[^，。；：:]{1,20}?)(?:与|和)(?P<right>[^，。；：:]{1,20}?)"
                            r"(?:应|必须|应当)", first)
            slots.update({"kind": "equality", "op": "=",
                          "left": rel.group("left") if rel else None,
                          "right": rel.group("right") if rel else None})
            slots["critical_total"] = 2
        else:
            m = _numeric_modality(first)
            num = _unit_after(first, m["end"]) if m else None
            slots.update({"kind": "tolerance", "op": m["op"] if m else None,
                          "value": float(num["value_raw"]) if num else None,
                          "unit": num.get("unit_raw") if num else None})
            slots["critical_total"] = 3
    elif rtype == "prohibited":
        modal = _first_of(first, PROHIBIT_MODALS)
        after = first[modal["start"] + len(modal["word"]):] if modal else ""
        items = [s.strip("，,。；;、 ") for s in re.split(r"[、，,]", after) if s.strip("，,。；;、 ")]
        slots.update({"forbidden": items})
        slots["critical_total"] = 1
    elif rtype == "completeness":
        modal = _first_of(first, COMPLETE_MODALS)
        after = first[modal["start"] + len(modal["word"]):] if modal else ""
        mode = "any" if "或" in after else "all"
        items = [s.strip("，,。；;、 ") for s in re.split(r"[或、，,]", after)
                 if s.strip("，,。；;、 ")]
        slots.update({"required": items, "match_mode": mode})
        slots["critical_total"] = 2
    elif rtype == "unit":
        conv = re.search(r"1\s*(?P<frm>[A-Za-z·/^][\w·/^]*)\s*=\s*(?P<factor>[\d.]+)\s*"
                         r"(?P<to>[A-Za-z·/^][\w·/^]*)", text)
        if conv:
            slots.update({"kind": "conversion", "from_unit": conv.group("frm"),
                          "to_unit": conv.group("to"), "factor": float(conv.group("factor"))})
            slots["critical_total"] = 3
        else:
            d = re.search(r"保留\s*(?P<d>\d+)\s*位小数", text)
            u = re.search(r"以(?P<u>[^，。；]{1,8}?)为单位", text)
            slots.update({"kind": "rounding",
                          "decimals": int(d.group("d")) if d else None,
                          "unit": u.group("u") if u else None})
            slots["critical_total"] = 2
    return slots
