"""L156 强类型结构化输出层：JSON Schema 子集校验 + 修复 + 反馈重试。

边界（先写在最前面，避免被误读成 token 级约束解码）：
    本模块**不是** token 级/Grammar 约束解码（vLLM guided decoding、GBNF、outlines 等），
    无法保证模型「生成时」就不越界。本机无 GPU、交付包不引入推理服务，DeepSeek/OpenAI 兼容
    接口只提供 response_format=json_object 这一级松约束；因此这里做的是「输出层等价工程」：

    1) 校验层 `validate()`：本地实现 JSON Schema 子集，错误路径精确到 ``$.a[0].b``；
    2) 修复层 `repair_json()`：修复模型常见畸形（```json 围栏 / 前后说明 / 尾逗号 /
       单引号 / Python 的 True|False|None / Unicode BOM、智能引号、裸控制字符）；
       修复失败抛 `JsonRepairError`，**不静默返回 None**；
    3) 重试层 `extract_json(prompt, schema, transport, max_retries)`：把上一轮的校验错误
       作为反馈喂回 transport 重试；耗尽仍不合法抛 `StructuredOutputError`（带
       attempts/errors/last_text，便于调用方显式降级或告警）。

能力边界一句话：只能保证「返回给调用方之前」结构合法或显式失败，不能保证生成期零越界。
与 `RULEPROOF_LLM_JSON_MODE`（是否外发 response_format/内嵌 schema）解耦：本模块只管输出层。
"""
from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# 开关：默认 1（开）；=0/false/no/off 时调用方逐字回退旧行为。空值按未设置=默认开。
STRUCTURED_OUTPUT_ENV = "RULEPROOF_STRUCTURED_OUTPUT"
_FALSE_VALUES = frozenset({"0", "false", "no", "off", "disable", "disabled"})

# 支持的 JSON Schema 子集关键词（报告/测试直接消费，防止文档与实现漂移）。
SCHEMA_KEYWORDS = (
    "type", "required", "properties", "items", "enum", "pattern",
    "minimum", "maximum", "min", "max", "minLength", "maxLength",
    "minItems", "maxItems", "oneOf", "anyOf", "const", "additionalProperties",
)

_JSON_TYPES = frozenset(
    {"object", "array", "string", "number", "integer", "boolean", "null"})
_MAX_SCHEMA_DEPTH = 64
_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def structured_output_enabled() -> bool:
    """L156 输出层结构化开关：默认开（"1"）；=0/false/no/off 时关闭。"""
    raw = os.environ.get(STRUCTURED_OUTPUT_ENV)
    if raw is None or str(raw).strip() == "":
        return True
    return str(raw).strip().lower() not in _FALSE_VALUES


# ---------------------------------------------------------------------------
# 1) 校验层：JSON Schema 子集
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class SchemaViolation:
    """一条 Schema 校验错误；path 精确到 JSON 值内位置（如 ``$.tags[2].name``）。"""

    path: str
    code: str
    message: str

    def __str__(self) -> str:  # noqa: D105 - 便于直接进重试反馈/日志
        return f"{self.path}: [{self.code}] {self.message}"


def _json_type_name(value) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return type(value).__name__


def json_type_matches(value, type_name: str) -> bool:
    """按 JSON Schema 语义判断类型；bool 不算 integer/number；整数值 float 算 integer。"""
    if type_name == "object":
        return isinstance(value, dict)
    if type_name == "array":
        return isinstance(value, list)
    if type_name == "string":
        return isinstance(value, str)
    if type_name == "boolean":
        return isinstance(value, bool)
    if type_name == "null":
        return value is None
    if type_name == "integer":
        if isinstance(value, bool):
            return False
        if isinstance(value, int):
            return True
        return isinstance(value, float) and value.is_integer()
    if type_name == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return False


def _json_equal(left, right) -> bool:
    """JSON 值等价：True != 1；1 == 1.0；容器逐项递归。"""
    if isinstance(left, bool) or isinstance(right, bool):
        return isinstance(left, bool) and isinstance(right, bool) and left is right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return left == right
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(
            _json_equal(a, b) for a, b in zip(left, right))
    if isinstance(left, dict) and isinstance(right, dict):
        return set(left) == set(right) and all(
            _json_equal(left[k], right[k]) for k in left)
    return left == right


def _child_path(path: str, key) -> str:
    if isinstance(key, str) and _KEY_RE.match(key):
        return f"{path}.{key}"
    return f"{path}[{json.dumps(key, ensure_ascii=False)}]"


def _number_bound(schema: dict, canonical: str, alias: str):
    """取数值/长度/条数下界：优先规范关键词，其次短别名 min/max（L156 任务口径）。"""
    if isinstance(schema.get(canonical), (int, float)) and not isinstance(
            schema.get(canonical), bool):
        return schema[canonical], canonical
    if isinstance(schema.get(alias), (int, float)) and not isinstance(
            schema.get(alias), bool):
        return schema[alias], alias
    return None, canonical


def validate(value, schema, path: str = "$", _depth: int = 0) -> list:
    """校验 value 是否符合 schema 子集；返回 SchemaViolation 列表（空列表=通过）。

    支持：type / required / properties / items / enum / pattern / minimum|maximum|
    min|max / minLength|maxLength / minItems|maxItems / oneOf / anyOf / const /
    additionalProperties。校验**收集多条错误**，类型不符的节点不再下钻（避免噪声）。
    """
    errors = []
    if _depth > _MAX_SCHEMA_DEPTH:
        return [SchemaViolation(path, "schema_invalid",
                                f"schema 嵌套超过 {_MAX_SCHEMA_DEPTH} 层")]
    if not isinstance(schema, dict):
        return [SchemaViolation(
            path, "schema_invalid", f"schema 必须是对象，实际 {type(schema).__name__}")]

    any_of = schema.get("anyOf")
    if isinstance(any_of, list) and any_of:
        branch_errors = [validate(value, sub, path, _depth + 1) for sub in any_of]
        if all(bool(be) for be in branch_errors):
            errors.append(SchemaViolation(path, "anyOf", "不满足 anyOf 任一分支"))
            return errors

    one_of = schema.get("oneOf")
    if isinstance(one_of, list) and one_of:
        branch_errors = [validate(value, sub, path, _depth + 1) for sub in one_of]
        matched = sum(1 for be in branch_errors if not be)
        if matched != 1:
            msg = f"oneOf 需恰好满足 1 个分支，实际满足 {matched} 个"
            if matched == 0 and branch_errors:
                first = "；".join(str(e) for e in branch_errors[0][:2])
                if first:
                    msg += f"（分支 0 首错：{first[:160]}）"
            errors.append(SchemaViolation(path, "oneOf", msg))
            return errors

    declared_type = schema.get("type")
    if declared_type is not None:
        names = [str(n) for n in (
            declared_type if isinstance(declared_type, list) else [declared_type])]
        unknown = [n for n in names if n not in _JSON_TYPES]
        if unknown:
            return errors + [SchemaViolation(
                path, "schema_invalid", f"type 含未知 JSON 类型 {unknown}")]
        if not any(json_type_matches(value, n) for n in names):
            return errors + [SchemaViolation(
                path, "type",
                f"类型应为 {'|'.join(names)}，实际 {_json_type_name(value)}")]

    if "const" in schema and not _json_equal(value, schema.get("const")):
        errors.append(SchemaViolation(
            path, "const", f"必须恰好等于 {schema.get('const')!r}，实际 {value!r}"))

    enum = schema.get("enum")
    if isinstance(enum, list) and enum:
        if not any(_json_equal(value, candidate) for candidate in enum):
            errors.append(SchemaViolation(
                path, "enum", f"取值必须是 {enum} 之一，实际 {value!r}"))

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        low, low_key = _number_bound(schema, "minimum", "min")
        if low is not None and value < low:
            errors.append(SchemaViolation(path, low_key, f"小于 {low_key} {low}"))
        high, high_key = _number_bound(schema, "maximum", "max")
        if high is not None and value > high:
            errors.append(SchemaViolation(path, high_key, f"大于 {high_key} {high}"))

    if isinstance(value, str):
        low, low_key = _number_bound(schema, "minLength", "min")
        if low is not None and len(value) < low:
            errors.append(SchemaViolation(
                path, low_key, f"长度 {len(value)} 小于 {low_key} {low}"))
        high, high_key = _number_bound(schema, "maxLength", "max")
        if high is not None and len(value) > high:
            errors.append(SchemaViolation(
                path, high_key, f"长度 {len(value)} 大于 {high_key} {high}"))
        pattern = schema.get("pattern")
        if isinstance(pattern, str):
            try:
                matched = re.search(pattern, value) is not None
            except re.error as exc:
                errors.append(SchemaViolation(
                    path, "schema_invalid", f"pattern 不是合法正则：{exc}"))
            else:
                if not matched:
                    errors.append(SchemaViolation(
                        path, "pattern", f"不匹配 pattern {pattern!r}"))

    if isinstance(value, list):
        low, low_key = _number_bound(schema, "minItems", "min")
        if low is not None and len(value) < low:
            errors.append(SchemaViolation(
                path, low_key, f"条数 {len(value)} 小于 {low_key} {low}"))
        high, high_key = _number_bound(schema, "maxItems", "max")
        if high is not None and len(value) > high:
            errors.append(SchemaViolation(
                path, high_key, f"条数 {len(value)} 大于 {high_key} {high}"))
        items = schema.get("items")
        if isinstance(items, dict):
            for index, item in enumerate(value):
                errors.extend(validate(item, items, f"{path}[{index}]", _depth + 1))
        elif isinstance(items, list):
            for index, (item, sub) in enumerate(zip(value, items)):
                errors.extend(validate(item, sub, f"{path}[{index}]", _depth + 1))

    if isinstance(value, dict):
        required = schema.get("required")
        if isinstance(required, list):
            for key in required:
                if key not in value:
                    errors.append(SchemaViolation(
                        _child_path(path, key), "required",
                        f'缺少必填字段 "{key}"'))
        properties = schema.get("properties")
        props = properties if isinstance(properties, dict) else {}
        for key, sub in props.items():
            if key in value:
                errors.extend(validate(value[key], sub, _child_path(path, key),
                                       _depth + 1))
        additional = schema.get("additionalProperties")
        if additional is False:
            unknown = [k for k in value if k not in props]
            if unknown:
                errors.append(SchemaViolation(
                    path, "additionalProperties",
                    f"不允许的额外字段 {unknown[:5]}"))
        elif isinstance(additional, dict):
            for key, sub in value.items():
                if key not in props:
                    errors.extend(validate(sub, additional, _child_path(path, key),
                                           _depth + 1))
    return errors


def format_violations(violations) -> str:
    """把校验错误拼成一行（重试反馈/日志用），保留精确路径。"""
    return "；".join(str(v)[:200] for v in list(violations)[:8])


# ---------------------------------------------------------------------------
# 2) 修复层：常见 JSON 畸形
# ---------------------------------------------------------------------------
class JsonRepairError(ValueError):
    """JSON 解析/修复失败（显式抛出，绝不静默返回 None）。"""

    def __init__(self, message: str, *, text: str = "", actions=None, attempts=None):
        super().__init__(str(message))
        self.text = text or ""
        self.actions = list(actions or [])
        self.attempts = list(attempts or [])


_UNICODE_JUNK = "\ufeff\u200b\u200c\u200d"
_FENCE_PATTERNS = (
    re.compile(r"```[ \t]*(?:json|JSON|Json)[ \t]*\r?\n?(.*?)(?:```|\Z)", re.S),
    re.compile(r"```[ \t]*\r?\n(.*?)(?:```|\Z)", re.S),
)
_SMART_QUOTE_MAP = {0x201C: 0x22, 0x201D: 0x22, 0x2018: 0x27, 0x2019: 0x27}


def _strip_outer(text: str):
    """去首尾空白与 BOM/零宽字符；返回 (文本, 动作列表)。"""
    actions = []
    stripped_ws = text.strip(" \t\r\n")
    stripped = stripped_ws.strip(_UNICODE_JUNK).strip(" \t\r\n")
    if stripped != stripped_ws:
        actions.append("bom")
    return stripped, actions


def _fence_payloads(text: str) -> list:
    """提取 markdown 代码块内容（```json / ``` 两种围栏，允许无闭合）。"""
    out = []
    for pattern in _FENCE_PATTERNS:
        for match in pattern.finditer(text):
            payload = match.group(1).strip()
            if payload and payload not in out:
                out.append(payload)
    return out


def _balanced_json_slice(text: str):
    """取首个 JSON 值的平衡括号子串（字符串/转义感知），兼容前后说明文字。"""
    start = -1
    for index, char in enumerate(text):
        if char in "{[":
            start = index
            break
    if start < 0:
        return None
    stack = []
    in_string = False
    quote_char = ""
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote_char:
                in_string = False
            continue
        if char == '"':
            in_string = True
            quote_char = '"'
        elif char == "'":
            in_string = True
            quote_char = "'"
        elif char in "{[":
            stack.append(char)
        elif char in "}]":
            if not stack:
                return None
            opener = stack.pop()
            if (opener == "{" and char != "}") or (opener == "[" and char != "]"):
                return None
            if not stack:
                return text[start:index + 1]
    return None


def _add_action(actions: list, action: str) -> None:
    if action not in actions:
        actions.append(action)


def _literal_at(text: str, index: int, literal: str) -> bool:
    """判断 index 处是否是独立单词形式的 Python 字面量（True/False/None）。"""
    if not text.startswith(literal, index):
        return False

    def _word(char: str) -> bool:
        return bool(char) and (char.isalnum() or char == "_")

    before = text[index - 1] if index > 0 else ""
    after = text[index + len(literal)] if index + len(literal) < len(text) else ""
    return not _word(before) and not _word(after)


def _normalize_json_like(text: str, *, smart_quotes: bool = False):
    """把类 JSON 文本规范成严格 JSON（字符串感知扫描）。

    修复：尾逗号、单引号字符串（含转义）、Python True/False/None、字符串内裸控制字符、
    可选智能引号。返回 (规范文本, 动作列表)；只改会破坏 JSON 语法的位置，不碰字符串内容。
    """
    source = str(text or "")
    actions = []
    if smart_quotes:
        replaced = source.translate(_SMART_QUOTE_MAP)
        if replaced != source:
            source = replaced
            _add_action(actions, "smart_quotes")
    out = []
    index = 0
    length = len(source)
    in_string = False
    quote_char = ""
    while index < length:
        char = source[index]
        if not in_string:
            if char == '"':
                out.append('"')
                in_string = True
                quote_char = '"'
                index += 1
                continue
            if char == "'":
                out.append('"')
                in_string = True
                quote_char = "'"
                _add_action(actions, "single_quote")
                index += 1
                continue
            if char == ",":
                lookahead = index + 1
                while lookahead < length and source[lookahead] in " \t\r\n":
                    lookahead += 1
                if lookahead < length and source[lookahead] in "}]":
                    _add_action(actions, "trailing_comma")
                    index += 1
                    continue
            for literal, replacement in (("True", "true"), ("False", "false"),
                                         ("None", "null")):
                if _literal_at(source, index, literal):
                    out.append(replacement)
                    _add_action(actions, "python_literals")
                    index += len(literal)
                    break
            else:
                out.append(char)
                index += 1
            continue
        # 字符串内部
        if char == "\\":
            if index + 1 >= length:
                out.append("\\\\")
                index += 1
                continue
            following = source[index + 1]
            if quote_char == "'":
                if following == "'":
                    out.append("'")
                elif following == '"':
                    out.append('\\"')
                elif following == "\\":
                    out.append("\\\\")
                else:
                    out.append("\\")
                    out.append(following)
            else:
                out.append("\\")
                out.append(following)
            index += 2
            continue
        if char == quote_char:
            out.append('"')
            in_string = False
            quote_char = ""
            index += 1
            continue
        if quote_char == "'" and char == '"':
            out.append('\\"')
            index += 1
            continue
        if char in "\n\r\t" or ord(char) < 0x20:
            escaped_char = {"\n": "\\n", "\r": "\\r", "\t": "\\t"}.get(char)
            if escaped_char is None:
                escaped_char = "\\u%04x" % ord(char)
            out.append(escaped_char)
            _add_action(actions, "control_chars")
            index += 1
            continue
        out.append(char)
        index += 1
    return "".join(out), actions


def _try_load(text: str):
    """严格解析；失败返回 (None, 错误说明)，不做任何修复。"""
    candidate = str(text or "").strip()
    if not candidate:
        return None, "空文本"
    try:
        return json.loads(candidate), ""
    except Exception as exc:  # noqa: BLE001 - 把原始错误交给修复层/重试反馈
        return None, f"{type(exc).__name__}: {exc}"


def _candidates(text: str) -> list:
    """生成候选 (文本, 动作) 列表：原始 / 围栏内容 / 平衡括号子串（含组合）。"""
    ordered = {}

    def _add(candidate: str, actions: list) -> None:
        candidate = str(candidate or "").strip()
        if not candidate:
            return
        existing = ordered.get(candidate)
        if existing is None:
            ordered[candidate] = list(actions)
        else:
            for action in actions:
                _add_action(existing, action)

    stripped, strip_actions = _strip_outer(text)
    _add(stripped, strip_actions)
    for payload in _fence_payloads(stripped):
        _add(payload, strip_actions + ["markdown_fence"])
        balanced = _balanced_json_slice(payload)
        if balanced and balanced.strip() != payload.strip():
            _add(balanced, strip_actions + ["markdown_fence", "prefix_suffix"])
    balanced = _balanced_json_slice(stripped)
    if balanced and balanced.strip() != stripped.strip():
        _add(balanced, strip_actions + ["prefix_suffix"])
    return list(ordered.items())


def _repair_with_text(text) -> tuple:
    """内部修复实现：返回 (value, 合法 JSON 文本, 修复动作列表)。

    合法 JSON 文本优先保留原候选文本（不重新序列化，保持调用方拿到的仍是模型原文的
    合法子集）；修复失败抛 JsonRepairError。
    """
    raw = "" if text is None else str(text)
    if not raw.strip():
        raise JsonRepairError("响应为空，无法解析 JSON", text=raw)
    attempts = []
    candidates = _candidates(raw)
    for candidate, actions in candidates:
        value, error = _try_load(candidate)
        if not error:
            return value, candidate, list(actions)
        attempts.append(("strict", error))

    normalized, normalize_actions = _normalize_json_like(raw)
    if normalize_actions:
        for candidate, actions in _candidates(normalized):
            value, error = _try_load(candidate)
            if not error:
                merged = list(normalize_actions)
                for action in actions:
                    _add_action(merged, action)
                return value, candidate, merged
            attempts.append(("normalized", error))

    smart_normalized, smart_actions = _normalize_json_like(raw, smart_quotes=True)
    if smart_actions and smart_normalized != normalized:
        for candidate, actions in _candidates(smart_normalized):
            value, error = _try_load(candidate)
            if not error:
                merged = list(smart_actions)
                for action in list(normalize_actions) + list(actions):
                    _add_action(merged, action)
                return value, candidate, merged
            attempts.append(("smart_quotes", error))

    first_error = attempts[0][1] if attempts else "未知错误"
    raise JsonRepairError(
        "JSON 解析/修复失败（首个错误：%s；共尝试 %d 个候选/修复步骤）"
        % (first_error, len(attempts)),
        text=raw, attempts=attempts)


def repair_json(text) -> tuple:
    """解析 JSON 文本并修复常见畸形；返回 (value, 修复动作列表)。

    修复失败抛 JsonRepairError（含 attempts 明细），**绝不静默返回 None**。
    修复动作（稳定字符串）：bom / markdown_fence / prefix_suffix / trailing_comma /
    single_quote / python_literals / control_chars / smart_quotes。
    注意：修复只发生在「严格解析失败之后」，合法 JSON 原样通过、动作列表为空。
    """
    value, _text, actions = _repair_with_text(text)
    return value, list(actions)


# ---------------------------------------------------------------------------
# 3) 重试层：失败把校验错误反馈给 transport
# ---------------------------------------------------------------------------
@dataclass
class ParseOutcome:
    """一次「解析+修复+校验」的结果（value 仅在 parsed 且无 errors 时可用）。"""

    value: object = None
    errors: list = field(default_factory=list)
    repairs: list = field(default_factory=list)
    parsed: bool = False
    # 成功解析出的合法 JSON 文本（原始严格 JSON，或修复后的候选文本）
    text: str = ""

    @property
    def ok(self) -> bool:
        return self.parsed and not self.errors


class StructuredOutputError(RuntimeError):
    """重试耗尽后仍不合法：显式失败，携带最后一次原文与错误明细。"""

    def __init__(self, message: str, *, attempts: int = 0, errors=None,
                 last_text: str = "", repairs=None):
        super().__init__(str(message))
        self.attempts = int(attempts or 0)
        self.errors = list(errors or [])
        self.last_text = last_text or ""
        self.repairs = list(repairs or [])


@dataclass
class ExtractionResult:
    """一次「取文本→修复→校验→反馈重试」的完整结果（供需要保留 JSON 文本的调用方）。"""

    ok: bool
    value: object = None
    text: str = ""          # 成功时：合法 JSON 文本（未修复=模型原文；修复=修复后候选文本）
    raw_text: str = ""      # 最后一次 transport 返回的原文（失败时=最后一次，绝不伪造）
    attempts: int = 0
    errors: list = field(default_factory=list)
    repairs: list = field(default_factory=list)


def extract_json_result(prompt, schema, transport, max_retries: int = 1, *,
                   hint: str = "", extra_validators=(),
                   include_schema_in_feedback=None, on_attempt=None) -> ExtractionResult:
    """执行「取文本→修复→校验→失败反馈重试」循环；**从不抛校验类异常**。

    契约同 `extract_json`；返回 ExtractionResult（ok=False 时调用方可显式降级，
    raw_text 保留最后一次原文，text 为空，errors 为最后一次校验错误）。
    """
    if not callable(transport):
        raise TypeError("transport 必须可调用：transport(prompt, feedback) -> str")
    try:
        retries = int(max_retries)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"max_retries 必须是整数，实际 {max_retries!r}") from exc
    if retries < 0:
        retries = 0
    total_attempts = retries + 1
    feedback = ""
    last_raw = ""
    last_errors = []
    all_repairs = []
    for attempt in range(1, total_attempts + 1):
        raw = transport(prompt, feedback)
        raw = "" if raw is None else str(raw)
        last_raw = raw
        outcome = parse_structured(raw, schema, extra_validators=extra_validators)
        for repair in outcome.repairs:
            _add_action(all_repairs, repair)
        if on_attempt is not None:
            try:
                on_attempt(attempt, list(outcome.errors), list(outcome.repairs))
            except Exception:  # noqa: BLE001 - 埋点故障不得破坏输出主链
                logger.warning("structured_output.on_attempt 回调异常（已忽略）",
                               exc_info=True)
        if outcome.ok:
            return ExtractionResult(ok=True, value=outcome.value, text=outcome.text,
                                    raw_text=raw, attempts=attempt,
                                    errors=[], repairs=list(all_repairs))
        last_errors = list(outcome.errors)
        if attempt < total_attempts:
            include_schema = (schema is not None
                              if include_schema_in_feedback is None
                              else bool(include_schema_in_feedback))
            feedback = build_retry_feedback(
                outcome.errors, schema=schema if include_schema else None, hint=hint)
    return ExtractionResult(
        ok=False, value=None, text="", raw_text=last_raw,
        attempts=total_attempts, errors=last_errors, repairs=list(all_repairs))


def parse_structured(text, schema, *, extra_validators=()) -> ParseOutcome:
    """解析+修复+Schema 校验+附加业务校验；解析失败转成显式错误列表（不抛异常）。"""
    try:
        value, json_text, repairs = _repair_with_text(text)
    except JsonRepairError as exc:
        return ParseOutcome(value=None, errors=[f"$: {exc}"],
                            repairs=list(exc.actions), parsed=False)
    violations = validate(value, schema) if schema else []
    errors = [str(item) for item in violations]
    for validator in extra_validators or ():
        try:
            extra = validator(value) or []
        except Exception as exc:  # noqa: BLE001 - 业务校验器故障必须显式反馈
            extra = [f"$: 业务校验器异常（{type(exc).__name__}: {exc}）"]
        errors.extend(str(item) for item in extra)
    return ParseOutcome(value=value, errors=errors, repairs=list(repairs),
                        parsed=True, text=json_text)


def build_retry_feedback(errors, *, schema=None, hint: str = "") -> str:
    """把校验错误拼成反馈消息（重试时作为 user 消息追加）。"""
    shown = "；".join(str(e)[:200] for e in list(errors or [])[:8])
    message = (
        "上一条输出未通过结构化校验：" + shown +
        "。请重新只输出一个合法 JSON 值：不要 Markdown 代码块、不要解释、不要前后缀文字；"
        "字段名、类型、枚举值、必填项必须严格符合要求。")
    if schema is not None:
        try:
            message += "\nJSON Schema：" + json.dumps(
                schema, ensure_ascii=False, separators=(",", ":"))
        except Exception:  # noqa: BLE001 - 反馈消息生成失败不应改变主流程语义
            logger.warning("重试反馈中的 schema 序列化失败（已省略 schema 文本）",
                           exc_info=True)
    if hint:
        message += "\n附加约束：" + str(hint)
    return message


def extract_json(prompt, schema, transport, max_retries: int = 1, *,
                 hint: str = "", extra_validators=(),
                 include_schema_in_feedback=None, on_attempt=None):
    """调用 transport 取 JSON 文本，校验/修复失败则带错误反馈重试，耗尽显式抛错。

    契约：
        prompt:    原始提示词；每次调用原样传给 transport（调用方可自行改用 messages）。
        schema:    JSON Schema 子集（见 `validate`）；可为 None 表示只做解析/修复。
        transport: ``transport(prompt, feedback) -> str``。首轮 feedback=""，重试轮为
                   上一轮校验错误拼成的反馈文本（0-LLM 测试里用 fake transport）。
        max_retries: 额外重试次数；总尝试次数 = max_retries + 1。
        extra_validators: 额外的业务校验函数列表 ``validator(value) -> list[str]``。
        include_schema_in_feedback: 重试反馈是否内嵌 schema（默认内嵌；JSON_MODE 路径
                   已在首轮 prompt 注入 schema 时传 False，避免重复膨胀）。
        on_attempt: 可选回调 ``on_attempt(attempt, errors, repairs)``，供 metrics 埋点；
                   回调异常只记日志，不影响重试主链。

    返回：合法 JSON 值（已修复/规范化）。
    失败：抛 StructuredOutputError，含 attempts / errors / last_text / repairs。
    """
    result = extract_json_result(prompt, schema, transport, max_retries, hint=hint,
                            extra_validators=extra_validators,
                            include_schema_in_feedback=include_schema_in_feedback,
                            on_attempt=on_attempt)
    if not result.ok:
        raise StructuredOutputError(
            "结构化输出校验失败：%d 次尝试后仍不合法（%d 项）：%s"
            % (result.attempts, len(result.errors),
               "；".join(str(e)[:120] for e in result.errors[:5])),
            attempts=result.attempts, errors=result.errors,
            last_text=result.raw_text, repairs=result.repairs)
    return result.value


__all__ = [
    "STRUCTURED_OUTPUT_ENV",
    "SCHEMA_KEYWORDS",
    "SchemaViolation",
    "JsonRepairError",
    "StructuredOutputError",
    "ParseOutcome",
    "ExtractionResult",
    "structured_output_enabled",
    "json_type_matches",
    "validate",
    "format_violations",
    "repair_json",
    "parse_structured",
    "build_retry_feedback",
    "extract_json_result",
    "extract_json",
]
