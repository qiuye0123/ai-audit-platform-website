# -*- coding: utf-8 -*-
import threading as _threading
"""引擎与宿主（服务层）之间的注入点。

引擎模块不 import services；需要租户上下文/本体/规则参数时调用本模块。
- 服务层可在启动时 register() 覆盖实现；
- 未注册时，本模块懒加载服务实现；服务不可用则返回安全默认值（引擎可独立运行）。
"""
_HOOKS = {}


def register(name, fn):
    _HOOKS[name] = fn


def _lazy(name):
    try:
        if name == "behavior":
            from ..services import ruleparam
            return ruleparam.behavior
        if name == "param_value":
            from ..services import ruleparam
            return lambda code, key, default=None: ruleparam.value(code, key, default)
        if name == "param_option":
            from ..services import ruleparam
            return lambda code, key, default=None: ruleparam.option(code, key, default)
        if name == "ontology_entities":
            from ..services import ontology_service as _onto
            return _onto.load_entities
        if name == "ontology_alias_index":
            from ..services import ontology_service as _onto
            return _onto.alias_index
        if name == "ontology_normalization":
            from ..services import ontology_service as _onto
            return _onto.normalization_rules
        if name == "norm_text":
            from ..services import entity_resolution
            return entity_resolution.norm_text
        if name == "ontology_gate_aliases":
            from ..services import ontology_service as _onto
            return _onto.gate_aliases
        if name == "context":
            from ..services import ctx
            return ctx.get_context
        if name == "explicit_off":
            from ..services import workspaces
            return workspaces.explicit_off
        if name == "workspace_settings":
            from ..services import workspaces
            return workspaces.get_settings
        if name == "workspace_ontology_aliases":
            from ..services import ontology_service as _onto
            return _onto.workspace_alias_pairs
        if name == "clause_find":
            from ..services import clause_norm
            return clause_norm.find
        if name == "rule_applicable":
            from ..services import rule_schema
            return rule_schema.applicable
        if name == "llm_provider":
            from ..services import extract
            return lambda: extract._provider()
        if name == "llm_chat":
            from ..services import extract
            return lambda messages, max_tokens=512: extract._chat(messages, max_tokens=max_tokens)
        if name == "llm_json":
            from ..services import extract
            return extract._json_of
        if name == "record_llm_call":
            # P1-B6-03：无 trace 上下文的真实模型调用也要落 llm_trace；落库实现在
            # app/services/llm_trace.py（引擎不直接 import services，经本适配层）。
            from ..services import llm_trace
            return llm_trace.record_orphan_call
        if name == "record_llm_metrics":
            # T-201：模型调用指标（/metrics）埋点；实现在 app/services/metrics.py。
            from ..services import metrics
            return metrics.llm_call
        if name == "data_policy":
            from ..services import sysconfig
            return sysconfig.get_data_policy
        if name == "safe_http_post":
            # P2-18：出站 HTTP 走服务层 net_guard（解析→校验→固定已校验 IP 直连），
            # 引擎不直接 import services（分层约定由本适配层承担）。
            from ..services import net_guard
            return net_guard.request_url
    except Exception:
        return None
    return None


def _call(name, default, *args, **kwargs):
    fn = _HOOKS.get(name) or _lazy(name)
    if not fn:
        return default() if callable(default) else default
    try:
        return fn(*args, **kwargs)
    except Exception:
        return default() if callable(default) else default


def behavior(code: str) -> dict:
    return _call("behavior", dict, code)


def param_value(rule_code: str, key: str, default=None):
    return _call("param_value", lambda: default, rule_code, key, default)


def param_option(rule_code: str, key: str, default=None):
    return _call("param_option", lambda: default, rule_code, key, default)


def ontology_entities() -> dict:
    return _call("ontology_entities", dict)


def ontology_alias_index() -> dict:
    return _call("ontology_alias_index", dict)


def ontology_normalization() -> dict:
    """本体 v2 归一数据段（组织形式等价尾缀 / 编号易混字符，T-157）。

    未注册时懒加载服务实现；服务不可用返回空 dict（调用方按"无归一规则"处理）。
    """
    return _call("ontology_normalization", dict)


def norm_text(value) -> str:
    """实体名归一（NFKC/去空白标点/去括注，T-157 键对齐用）。

    未注册时懒加载服务实现；服务不可用返回空串（调用方不得据此判定"同一实体"）。
    """
    return _call("norm_text", lambda: "", value)


def ontology_gate_aliases() -> tuple:
    return _call("ontology_gate_aliases", lambda: ({}, {}))


def workspace_ontology_aliases() -> dict:
    return _call("workspace_ontology_aliases", dict)


def context() -> dict:
    return _call("context", dict)


def explicit_off(workspace_id: str, key: str) -> bool:
    return _call("explicit_off", lambda: False, workspace_id, key)


def workspace_settings(workspace_id: str) -> dict:
    return _call("workspace_settings", dict, workspace_id)


def clause_find(term: str, text: str) -> dict:
    return _call("clause_find", lambda: {"found": str(term) in (text or ""), "negated": False,
                                          "matched": str(term)}, term, text)


def rule_applicable(slots: dict, text: str) -> dict:
    return _call("rule_applicable", lambda: {"applicable": True}, slots, text)


def llm_provider():
    return _call("llm_provider", lambda: None)


def llm_chat(messages: list, max_tokens: int = 512) -> str:
    return _call("llm_chat", lambda: "", messages, max_tokens)


def llm_json(content: str) -> dict:
    return _call("llm_json", dict, content)


def record_llm_call(call: dict) -> None:
    """P1-B6-03：把一次真实模型调用落到 llm_trace（适配层唯一注入点）。

    引擎 app/engine/llm.py 在「没有 begin_trace 上下文 / 调用失败」时必须落行，
    但不能直接 import services/落库：落库实现放服务层
    ``app/services/llm_trace.py::record_orphan_call``，由
    ``app/services/llm_trace.py`` 的 hooks 懒加载默认实现注册（build49 B1 已删除
    独立注册入口 ``app/services/hooks_register.py``，hooks 走懒加载）；服务不可用则
    安全返回 None（可观测性故障不得影响模型调用主链）。
    """
    return _call("record_llm_call", lambda: None, call)


def record_llm_metrics(model: str, ok: bool, latency_ms: int,
                       tokens_in: int = 0, tokens_out: int = 0) -> None:
    """T-201：模型调用指标埋点（/metrics 计数器/耗时/token），经服务层实现。

    引擎不 import services.metrics；服务不可用时安全返回（指标故障不影响主链）。
    """
    return _call("record_llm_metrics", lambda: None, model, ok, latency_ms,
                 tokens_in, tokens_out)


def safe_http_post(url: str, body: bytes = b"", headers: dict = None, timeout: float = 8,
                   allow_loopback: bool = False):
    """P2-18：安全出站 POST（解析→校验→固定已校验 IP 直连）。不可用时 fail-closed。"""
    fn = _HOOKS.get("safe_http_post") or _lazy("safe_http_post")
    if not callable(fn):
        raise RuntimeError("safe_http_post hook unavailable（安全出站通道未注册）")
    return fn(url, body=body, headers=headers or {}, timeout=timeout,
              allow_loopback=allow_loopback)


# ============================================================================
# TL-5 数值 provenance 守卫（engine 层唯一注入点）
#
# 背景（外部评审 TL-5）：视觉兜底 OCR 能产出数值文本且与文本层同流，此前只有
# 配置级 OCR 指纹、没有按页实际引擎 provenance，也没有「数值事实不得来自通用
# 视觉模型」的约束 → 扫描件数值判定可能被模型幻觉背书。
#
# 本模块只新增注入点与默认实现，不改任何既有函数：
#   - provenance 字段：ocr_engine / ocr_tier / vision_advisory（解析产物：页/段/事实）
#   - 判定守卫：`guard_judgement()` —— 数值判定依赖的 provenance 为 vision 或未知
#     （含老数据缺字段）时，降级为「证据不足」，带 evidence_source / suppressed_by
#     痕迹并写结构化审计日志，不静默；
#   - 开关：`RULEPROOF_NUMERIC_PROVENANCE_GUARD`，默认 "1"（fail-closed）；
#     置 "0" 完全回滚到改动前行为（guard 不动任何结果）。
#
# 口径：
#   trusted = 文本层 / 确定性结构化解析（ocr_engine=text_layer）或专用 OCR 引擎
#             （paddle / baidu / external_cmd，tier=ocr；不是通用视觉模型）
#   vision  = 通用视觉模型（tier=vision / vision_advisory=True）
#   unknown = 字段缺失 / 老快照 / mixed（任一未知都按不安全处理，不默认安全）
# ============================================================================
import json as _json
import logging as _logging
import os as _os
import re as _re
from collections import deque as _deque

NUMERIC_PROVENANCE_GUARD_ENV = "RULEPROOF_NUMERIC_PROVENANCE_GUARD"
_PROV_LOG = _logging.getLogger("ruleproof.numeric_provenance")
_GUARD_EVENTS = _deque(maxlen=200)

TRUSTED_ENGINES = frozenset({"text_layer"})
TRUSTED_OCR_ENGINES = frozenset({"paddle", "baidu", "external_cmd"})
VISION_ENGINES = frozenset({"vision"})
_PROVENANCE_FIELDS = ("ocr_engine", "ocr_tier", "vision_advisory", "evidence_source")
_PROV_STATES = ("trusted", "vision", "unknown", "mixed")
# 数值事实 kind（deepparse / facts / 统一事实层口径）；日期/版本/编号/占位符不算数值事实
NUMERIC_FACT_KINDS = frozenset({
    "num", "range", "compare", "temp", "time", "conc", "weight", "length", "area",
    "volume", "pressure", "power", "angle", "money", "percent", "ratio", "count",
    "speed", "density", "hardness", "grade",
})
NON_NUMERIC_FACT_KINDS = frozenset({"date", "version", "code", "placeholder", "heading",
                                    "paragraph", "cell", "table"})
_PASS_FAIL_STATES = ("满足", "不满足", "pass", "fail")
# B4（2026-11-20 外部对抗审查）：中文数字/量词/单位判据此前识别不到 → 数值 provenance
# 守卫被整段跳过（vision 来源的中文数字判定可判 pass/fail）。这里只扩展「是否数值类」的
# 识别面（识别到只是一律纳入 provenance 约束，方向是收紧不是放宽）。
_CN_NUM_CHARS = r"[零〇一二三四五六七八九十百千万亿两]"
_NUMERIC_POINT_RE = _re.compile(
    r"(?:[≥≤<>]|不小于|不大于|不低于|不高于|超过|少于|大于|小于|高于|低于|"
    r"\d+\s*(?:℃|°C|%|％|mg|kg|g|mL|ml|L|ppm|min|分钟|小时|天|MPa|kPa|元|万元|cm|mm|"
    r"摄氏度|秒|克|千克|公斤|毫克|升|毫升|吨|次|倍))"
    # 中文数字（两位以上：七十五/八十五/一百二十/一千二百）
    r"|(?:" + _CN_NUM_CHARS + r"{2,})"
    # 百分比/千分比/万分比 + 中文或阿拉伯数字
    r"|(?:百分之|千分之|万分之)[\d" + _CN_NUM_CHARS + r"]+"
    # 单个中文数字 + 计量单位（三小时/五天/八十五度/七十五摄氏度）
    r"|(?:" + _CN_NUM_CHARS + r"\s*(?:摄氏度|度|小时|分钟|秒钟|秒|天|日|克|千克|公斤|"
    r"毫克|升|毫升|吨|元|万元|次|倍|%))"
    # 比较/限值语义 + 中文数字（不低于八十五 / 不得超过一百 / 至少三）
    r"|(?:(?:不低于|不超过|不得低于|不得超过|不少于|不多于|至少|至多|最多|最少|"
    r"大于|小于|高于|低于)[^。；;，,\n]{0,6}(?:\d|" + _CN_NUM_CHARS + r"))",
    _re.I)


# TL-5 接线：主链判定入口（manifest D4 / review 规则执行 / 复核重判）不逐层传参，
# 用线程内 provenance 上下文传递文档级 provenance；未设置上下文时保持旧行为并留痕（见
# guard_judgement 的 basis=none 分支），不在主链外路径上误降级文本层文档。
_PROV_CTX = _threading.local()


class provenance_scope:
    """上下文管理器：在判定作用域内提供文档级 provenance（可嵌套，退出后恢复）。"""

    def __init__(self, provenance):
        self._prov = provenance
        self._old = None
        self._had = False

    def __enter__(self):
        self._had = hasattr(_PROV_CTX, "prov")
        self._old = getattr(_PROV_CTX, "prov", None)
        _PROV_CTX.prov = self._prov
        return self._prov

    def __exit__(self, exc_type, exc, tb):
        if self._had:
            _PROV_CTX.prov = self._old
        else:
            try:
                delattr(_PROV_CTX, "prov")
            except AttributeError:
                logging.getLogger(__name__).debug("provenance context 已无 prov（重复清理）", exc_info=True)
        return False


def current_provenance():
    """当前线程的文档级 provenance；未设置返回 None（=旧行为，不拦截）。"""
    return getattr(_PROV_CTX, "prov", None)


def numeric_provenance_guard_enabled() -> bool:
    """TL-5 守卫开关：默认 "1"（安全默认）；"0"/false/off/no 关闭 = 完全回滚。"""
    v = str(_os.environ.get(NUMERIC_PROVENANCE_GUARD_ENV, "1")).strip().lower()
    return v not in ("0", "false", "off", "no")


def reset_numeric_guard_events() -> None:
    """清空进程内降级事件（测试/运维自检用）。"""
    _GUARD_EVENTS.clear()


def numeric_guard_events() -> list:
    """本进程内数值 provenance 降级事件（结构化审计痕迹，最多 200 条）。"""
    return list(_GUARD_EVENTS)


def _as_dict(prov) -> dict:
    if isinstance(prov, dict):
        return prov
    if hasattr(prov, "to_dict"):
        try:
            d = prov.to_dict()
            return d if isinstance(d, dict) else {}
        except Exception:  # noqa: BLE001 - 适配对象不可序列化按未知处理，不静默通过
            _PROV_LOG.warning("provenance to_dict failed; treat as unknown", exc_info=True)
            return {}
    return {}


def provenance_state(prov) -> str:
    """provenance → trusted / vision / unknown / mixed（mixed 与 unknown 同属不安全）。

    接受：None（未知）/ 事实或段落 dict（ocr_engine/ocr_tier/vision_advisory）/
    文档 provenance 摘要（status）/ 解析产物 dict（doc/page_provenance）。

    B5（2026-11-20 外部对抗审查）：**字符串等非结构化输入不再被信任** ——
    即使调用方传 "trusted"/"text" 字符串也按 unknown 处理（fail-closed），
    避免用字符串短路数值 provenance 守卫。
    B6-①（同日）：**页级 provenance 优先** —— dict 里同时带 doc 级 status=trusted
    与非空 page_provenance（含 vision/mixed）时，以页级为准，doc 级不得覆盖。
    """
    if prov is None:
        return "unknown"
    if isinstance(prov, str):
        return "unknown"
    d = _as_dict(prov)
    if not d:
        return "unknown"
    # B6-①：页级证据优先于任何 doc 级 status（含手工注入的 trusted 摘要）
    _page = d.get("page_provenance")
    if isinstance(_page, dict) and _page:
        return doc_provenance(_page)["status"]
    if isinstance(_page, (list, tuple)) and _page:
        return doc_provenance(_page)["status"]
    st = str(d.get("status") or "").strip().lower()
    if st in _PROV_STATES:
        return st
    if isinstance(d.get("provenance"), dict):
        return provenance_state(d["provenance"])
    if isinstance(d.get("doc"), dict):
        return provenance_state(d["doc"])
    if "page_provenance" in d or "pages" in d:
        return doc_provenance(d.get("page_provenance") or d.get("pages"))["status"]
    eng = str(d.get("ocr_engine") or "").strip().lower()
    tier = str(d.get("ocr_tier") or "").strip().lower()
    va = d.get("vision_advisory")
    if va is True or eng in VISION_ENGINES or tier == "vision":
        return "vision"
    if va is False:
        if eng in TRUSTED_ENGINES and tier in ("", "text"):
            return "trusted"
        if eng in TRUSTED_OCR_ENGINES and tier in ("", "ocr"):
            return "trusted"
    # 字段缺失 / 不自洽 → 未知（fail-closed：不默认安全）
    return "unknown"


def doc_provenance(page_provenance=None, sections=None) -> dict:
    """聚合页/段 provenance 为文档级摘要（status=trusted/vision/unknown/mixed）。"""
    provs = []
    if isinstance(page_provenance, dict):
        for v in page_provenance.values():
            if isinstance(v, dict):
                provs.append(v)
    elif isinstance(page_provenance, (list, tuple)):
        for v in page_provenance:
            if isinstance(v, dict):
                inner = v.get("provenance")
                provs.append(inner if isinstance(inner, dict) else v)
    for s in sections or []:
        if isinstance(s, dict):
            provs.append(s)
    states = [provenance_state(p) for p in provs]
    if not states:
        return {"status": "unknown", "pages": 0, "vision_pages": 0, "trusted_pages": 0,
                "unknown_pages": 0, "ocr_engine": "", "ocr_tier": "",
                "vision_advisory": None, "engines": [],
                "reason": "无 provenance 字段（老数据/未知，按不安全处理）"}
    n_t = states.count("trusted")
    n_v = states.count("vision") + states.count("mixed")
    n_u = states.count("unknown")
    if n_t and (n_v or n_u):
        status = "mixed"
    elif n_v:
        status = "vision"
    elif n_u:
        status = "unknown"
    else:
        status = "trusted"
    engines, tiers = [], []
    for p in provs:
        d = _as_dict(p)
        e = str(d.get("ocr_engine") or "")
        t = str(d.get("ocr_tier") or "")
        if e and e not in engines:
            engines.append(e)
        if t and t not in tiers:
            tiers.append(t)
    return {"status": status, "pages": len(states), "vision_pages": n_v,
            "trusted_pages": n_t, "unknown_pages": n_u,
            "ocr_engine": (engines[0] if len(engines) == 1
                           else ("vision" if "vision" in engines else (engines[0] if engines else ""))),
            "ocr_tier": (tiers[0] if len(tiers) == 1
                         else ("vision" if "vision" in tiers else (tiers[0] if tiers else ""))),
            "vision_advisory": (True if n_v else (False if n_t and not n_u else None)),
            "engines": engines}


def provenance_of_parsed(parsed) -> dict:
    """从 agent-parse/parse_bridge 解析产物（{doc, facts} / ParsedDoc）取文档级 provenance。

    B6-①（2026-11-20 外部对抗审查）：**页级 provenance 优先**。当解析产物同时带
    非空 page_provenance 与 doc 级 provenance 摘要时，以逐页证据为准；doc 级
    trusted 摘要不得覆盖页级 vision/mixed（否则视觉页数值可被判 pass/fail）。
    """
    if parsed is None:
        return doc_provenance(None, None)
    d = _as_dict(parsed)
    if not d:
        return doc_provenance(None, None)
    doc = d.get("doc") if isinstance(d.get("doc"), dict) else d
    # ① 页级证据优先（doc 包一层 / 扁平解析产物两种形态都覆盖）
    for holder in (doc, d):
        pv = holder.get("page_provenance")
        if isinstance(pv, dict) and pv:
            return doc_provenance(pv, holder.get("sections"))
    # ② 没有页级证据时才采信文档级摘要（老产物/整份文档级口径）
    for holder in (doc, d):
        prov = holder.get("provenance")
        if isinstance(prov, dict) and "status" in prov:
            return prov
    return doc_provenance(None, None)


def fact_is_numeric(fact) -> bool:
    """事实是否数值类（日期/版本/编号/占位符/结构块不算数值事实）。"""
    d = _as_dict(fact)
    if not d:
        return False
    kind = str(d.get("kind") or "").strip().lower()
    if kind in NON_NUMERIC_FACT_KINDS:
        return False
    if kind in NUMERIC_FACT_KINDS:
        return True
    v = d.get("value")
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return True
    return bool(_re.search(r"\d", str(v if v is not None else d.get("text") or "")))


def fact_provenance(fact) -> str:
    """单条事实的 provenance 状态；缺字段 = unknown（不默认安全）。"""
    return provenance_state(fact)


def numeric_facts_provenance(facts) -> dict:
    """数值事实集合的 provenance 汇总；任一数值事实 vision/未知 → blocked。

    B6-②（2026-11-20 外部对抗审查）：**显式空事实集按 unknown 处理**（不是 trusted）。
    “没有数值事实”只说明调用方没提供可审计来源，不能据此证明数值判定安全；
    非空但无数值事实的集合仍维持原口径（没有数值依据可被幻觉背书）。
    """
    if isinstance(facts, dict):
        fact_list = [facts]
    elif facts is None:
        fact_list = []
    elif isinstance(facts, (list, tuple, set)):
        fact_list = list(facts)
    else:
        try:
            fact_list = list(facts)
        except TypeError:
            fact_list = []
    if not fact_list:
        return {"state": "unknown", "blocked": True, "numeric": 0,
                "counts": {"trusted": 0, "vision": 0, "unknown": 0, "mixed": 0},
                "examples": [], "basis": "facts_empty",
                "reason": "空事实集：没有可审计的数值来源（缺失≠安全，按 unknown 处理）"}
    counts = {"trusted": 0, "vision": 0, "unknown": 0, "mixed": 0}
    numeric, examples = 0, []
    for f in fact_list:
        if not fact_is_numeric(f):
            continue
        numeric += 1
        st = fact_provenance(f)
        counts[st] = counts.get(st, 0) + 1
        if st != "trusted" and len(examples) < 5:
            d = _as_dict(f)
            examples.append({"provenance": st, "kind": str(d.get("kind") or ""),
                             "anchor": str(d.get("anchor") or ""),
                             "value": d.get("value"),
                             "quote": str(d.get("context") or d.get("quote") or "")[:80]})
    blocked = any(v for k, v in counts.items() if k != "trusted")
    if numeric == 0:
        state = "trusted"      # 没有数值事实 → 没有可被幻觉背书的数值判定
    elif counts["vision"] or counts["mixed"]:
        state = "vision"
    elif counts["unknown"]:
        state = "unknown"
    else:
        state = "trusted"
    return {"state": state, "blocked": bool(blocked), "numeric": numeric,
            "counts": counts, "examples": examples, "basis": "facts"}


def fact_provenance_fields(prov) -> dict:
    """把 provenance 归一成事实字段（ocr_engine/ocr_tier/vision_advisory/evidence_source）。

    未知来源的数值事实同样标 evidence_source='vision_advisory'（TL-5：缺失 ≠ 安全）。
    """
    d = _as_dict(prov)
    st = provenance_state(prov)
    return {
        "ocr_engine": str(d.get("ocr_engine") or "") if st != "unknown" else "",
        "ocr_tier": str(d.get("ocr_tier") or "") if st != "unknown" else "",
        "vision_advisory": (True if st in ("vision", "mixed")
                            else (False if st == "trusted" else None)),
        "evidence_source": "" if st == "trusted" else "vision_advisory",
    }


def apply_fact_provenance(fact, prov) -> dict:
    """返回填充了 provenance 字段的新事实 dict（不修改入参）。"""
    d = _as_dict(fact)
    out = dict(d)
    out.update(fact_provenance_fields(prov))
    if fact_is_numeric(out) and provenance_state(prov) != "trusted":
        out["evidence_source"] = "vision_advisory"
    return out


def point_is_numeric(point) -> bool:
    """审核点/规则槽位是否数值类判据（决定是否受「数值不得来自视觉」约束）。"""
    if not isinstance(point, dict):
        return False
    for k in ("metric", "value", "op", "unit", "threshold", "limit", "operator"):
        if point.get(k) not in (None, "", [], {}):
            return True
    blob = " ".join(str(point.get(k) or "") for k in
                    ("criterion", "name", "point", "action", "evidence",
                     "required_evidence", "applicable_when", "requirement"))
    return bool(_NUMERIC_POINT_RE.search(blob))


def guard_judgement(result, provenance=None, facts=None, *, rule_code="", source="",
                    numeric=True) -> dict:
    """TL-5 约束：数值判定所依赖的事实 provenance 为 vision/未知 → 降级「证据不足」。

    - 开关关闭（RULEPROOF_NUMERIC_PROVENANCE_GUARD=0）→ 原样返回，行为与改动前一致；
    - 非 pass/fail 状态（证据不足/不适用/unknown/需人工）不拦截；
    - 判定 provenance 时优先 `provenance`（文档级），否则看 `facts`（事实级，只算数值事实）；
    - 降级结果带 evidence_source='vision_advisory'、suppressed_by='no_numeric_provenance'、
      original_state，并写 ruleproof.numeric_provenance 结构化日志 + 进程内事件（可审计）。
    返回新 dict，不修改入参。
    """
    if not isinstance(result, dict):
        return result
    if not numeric_provenance_guard_enabled():
        return result
    state = str(result.get("state") or result.get("status") or "").strip()
    if state not in _PASS_FAIL_STATES or not numeric:
        return result
    # 允许服务层覆盖实现（hooks.register("numeric_provenance_guard", fn)）
    _custom = _HOOKS.get("numeric_provenance_guard")
    if callable(_custom):
        try:
            return _custom(result, provenance=provenance, facts=facts,
                           rule_code=rule_code, source=source)
        except Exception:  # noqa: BLE001 - 守卫实现异常不能放行（继续走内置默认）
            _PROV_LOG.warning("numeric provenance guard hook failed; use built-in default",
                              exc_info=True)
    info = {}
    _ctx_prov = current_provenance() if provenance is None else None
    if provenance is not None:
        prov_state = provenance_state(provenance)
        info = {"basis": "provenance"}
    elif _ctx_prov is not None:
        provenance = _ctx_prov
        prov_state = provenance_state(_ctx_prov)
        info = {"basis": "provenance_context"}
    elif facts is not None:
        info = numeric_facts_provenance(facts)
        prov_state = str(info.get("state") or "unknown")
    else:
        # 未接线路径：保持旧行为（不降级），basis=none 可在事件/单测中识别
        prov_state, info = "unknown", {"basis": "none"}
    if prov_state == "trusted":
        return result
    event = {
        "at": _now_iso(), "guard": "numeric_provenance", "rule_code": str(rule_code or ""),
        "source": str(source or ""), "original_state": state,
        "provenance": prov_state, "suppressed_by": "no_numeric_provenance",
        "evidence_source": "vision_advisory",
        "numeric_facts": int(info.get("numeric") or 0),
        "counts": info.get("counts") or {}, "examples": info.get("examples") or [],
        "original_quote": str(result.get("quote") or "")[:120],
        "original_detail": str(result.get("detail") or result.get("rationale") or "")[:200],
    }
    _GUARD_EVENTS.append(event)
    try:
        _PROV_LOG.warning("NUMERIC_PROVENANCE_BLOCKED %s",
                          _json.dumps(event, ensure_ascii=False, default=str))
    except Exception:  # noqa: BLE001 - 日志序列化失败不能吞掉降级本身
        _PROV_LOG.warning("NUMERIC_PROVENANCE_BLOCKED rule=%s provenance=%s",
                          event["rule_code"], prov_state)
    out = dict(result)
    out["state"] = "证据不足"
    out["original_state"] = state
    out["evidence_source"] = "vision_advisory"
    out["suppressed_by"] = "no_numeric_provenance"
    out["provenance_blocked"] = True
    out["provenance"] = prov_state
    _why = ("数值 provenance 守卫：数值事实来源=" + prov_state
            + "（vision/未知，不得作为数值判定依据），判定降级为证据不足，不得判 pass/fail")
    _detail = str(result.get("detail") or result.get("rationale") or "").strip()
    out["detail"] = (_detail + "｜" + _why) if _detail else _why
    if "rationale" in result:
        out["rationale"] = out["detail"]
    return out


def _now_iso() -> str:
    from datetime import datetime as _dt
    return _dt.now().isoformat(timespec="seconds")
