"""
金规 · AI 审核平台 —— 规则引擎 MVP
文档解析 → 事实层 → 规则引擎 → 五态结果 → 证据锚点 → 报告

零第三方依赖（仅 openpyxl，随运行环境提供）。
"""
import datetime
import logging
import hashlib
import os
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from .rules_meta import RULE_META
from .ontology import seed_food_ontology, load_from_db
from . import rexec as _rexec

ONTO = seed_food_ontology()


def reload_ontology():
    """从 DB 重载本体（管理端编辑后调用，使修改即时生效）。"""
    global ONTO
    try:
        ONTO = load_from_db()
    except Exception:
        ONTO = seed_food_ontology()
    return ONTO

# ---------------------------------------------------------------- normalize

def norm_date(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    m = re.match(r"(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})日?", s)
    if m:
        try:
            return datetime.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))).strftime("%Y-%m-%d")
        except Exception:
            return f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    return s


# 占位符写法（NFKC 归一后比较：全角→半角、Ⅹ→X、ｘ→x）。
# LaneQ 2026-11-23：原实现只认半角 X/x，全角「Ｘ」被当成有效值 → 漏检；
# 这里扩到「Ｘ/ｘ/Ⅹ/xxx/待填/空/N/A/纯符号」等价写法，只影响占位符识别、不改其他判定语义。
_PLACEHOLDER_CORE = frozenset((
    "", "-", "—", "–", "/", "none", "null", "n/a", "na",
    "待填", "待定", "待补", "待签署", "待签", "空", "无", "未填", "xx", "xxx",
))
_PLACEHOLDER_CHARS = frozenset("xX×*＊")


def is_placeholder(v: Any) -> bool:
    if v is None:
        return True
    s = unicodedata.normalize("NFKC", str(v)).strip()
    if not s:
        return True
    if s.lower() in _PLACEHOLDER_CORE:
        return True
    # 纯占位符组成的值：X / Ｘ / Ⅹ / xx / ×  / ＿ / …… （去符号壳后全为占位字符）
    core = s.strip("_＿-—–/／·・.*＊× \t\u3000")
    if not core:
        return True
    return all(ch in _PLACEHOLDER_CHARS for ch in core)


def norm_num(v: Any) -> Optional[float]:
    if v is None:
        return None
    s = str(v).strip().replace(",", "").replace("，", "").replace(" ", "").replace("±", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return float(m.group(0)) if m else None




def sha(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


# ---------------------------------------------------------------- anchor / fact

@dataclass
class Anchor:
    sheet: str
    row: Optional[int]
    col: Optional[str]
    quote: str

    @property
    def locator(self) -> str:
        return f"{self.sheet}!{self.col}{self.row}" if self.col and self.row else self.sheet

    @property
    def content_hash(self) -> str:
        return sha(f"{self.sheet}|{self.col}{self.row}|{self.quote}")

    def to_dict(self) -> dict:
        return {
            "sheet": self.sheet, "row": self.row, "col": self.col,
            "locator": self.locator, "quote": self.quote, "hash": self.content_hash,
        }


@dataclass
class Fact:
    entity: str
    raw: str
    norm: Any = None
    unit: str = ""
    basis: str = ""            # 计量基准：投料量 / 成品含量 / 干基 / 未知
    sheet: str = ""
    row: Optional[int] = None
    col: Optional[str] = None
    doc_version: str = ""
    source: str = "native"     # native / extracted / ambiguous
    confirmed: bool = True

    def anchor(self) -> Anchor:
        return Anchor(self.sheet, self.row, self.col, self.raw)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["anchor"] = self.anchor().to_dict()
        return d


# ---------------------------------------------------------------- model

@dataclass
class SheetHeader:
    sheet: str
    impl_date: str = ""
    version: Optional[str] = None      # None=标签不存在；""或"X"=占位符
    product_name: str = ""
    process_name: str = ""
    signatures: dict = field(default_factory=dict)   # 角色 -> 值
    impl_date_cell: Optional[str] = None   # "C3"
    version_cell: Optional[str] = None
    product_cell: Optional[str] = None
    signature_cells: dict = field(default_factory=dict)  # 角色 -> "S4"


@dataclass
class HalfProduct:
    seq: Optional[str]
    name: str
    weight: Optional[float]
    unit: str
    row: Optional[int]


@dataclass
class Material:
    seq: Optional[str]
    name: str
    row: Optional[int]


@dataclass
class Document:
    path: str
    sheet_names: list = field(default_factory=list)
    headers: dict = field(default_factory=dict)            # sheet -> SheetHeader
    packaging: dict = field(default_factory=dict)          # design_total / half_products / materials
    process_text: dict = field(default_factory=dict)       # sheet -> list[(colA, row_text, row)]
    # L121 ④：工序行单元格明细 {sheet: {row: [(列字母, 文本)]}}，供 finding anchor 定位反查；
    # 不改变 process_text 结构（旧消费方按 3 元组解包，兼容）。
    process_cells: dict = field(default_factory=dict)


# ---------------------------------------------------------------- parser

SIGN_ROLES = ["研发经理", "生产经理", "品管经理", "研发"]

# 半成品 → 工序名称 的实体词典（生产环境来自客户实体词典/同义词表，此处为演示种子）
PROCESS_ALIASES = {}  # 由规则包在加载时注入（引擎不含行业词典）


def _cells(ws):
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                yield cell


def _norm_label(s: str) -> str:
    # 文档标签常带全角空格（U+3000），匹配前统一去掉
    return s.replace("\u3000", "").replace(" ", "").replace("\t", "")


def _find_label(ws, match_fn):
    for cell in _cells(ws):
        if match_fn(_norm_label(str(cell.value))):
            return cell.row, cell.column
    return None


def _val_at(ws, row, col):
    if col < 1 or row < 1:
        return None
    v = ws.cell(row=row, column=col).value
    return v


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ---------------------------------------------------------------------------
# L107（2026-11-25）单据表头/工序标签别名 + 动态偏移（D3 修复）
#
# 缺陷：parse_xlsx 表头字段用**精确标签**（实施日期/版本号/商品名/设计总重量/
#   半成品名称/包材编号）+ **固定列偏移**（+2/+3、清单固定列 1/2/8/10）取值。真实单据
#   模板写「生效日期/文件编号/品名」或值在标签右侧第 1 列（合并单元格右侧）时全部漏抽：
#   探针 P3 三字段全空；漏抽后 _chk_version_placeholder 等检查还会默认放行。
# 修复：
#   ① 标签别名表（通用单据字段，非行业词典）：实施日期←生效日期/执行日期；版本号←文件编号/
#      文件版本/版次；商品名←品名/产品名称；工序名称/标准工序←工序流程/操作步骤/加工工序；
#      设计总重量←设计总重/总重量；半成品名称←半成品名/半成品清单/半成品分项装盒标准；
#      包材编号←包材号/包材清单/包材清单与异物检测控制；
#   ② 取值改为「标签右侧最近的非空单元格」（按字段类型校验：日期必须是日期、重量必须是数值），
#      兼容值在 +1/+2/+3 列的不同模板/合并单元格（合并区域值在左上角，右侧扫描可达）；
#      标签单元格内「实施日期：2026-04-01」的同行内联值也支持；
#   ③ 半成品/包材清单按子表头列名（序号/分项名称/重量/单位/包材编号）动态定位列，
#      子表头不可识别时才回退旧固定列（1/2/8/10）。
# 开关 RULEPROOF_FOOD_HEADER_ALIAS（默认 1；=0 逐字回退旧行为，用于 A/B 与回滚）。
# 未识别字段由判据层判「证据不足」，不默认放行（见 packs/food.py 后缀检查）。
# ---------------------------------------------------------------------------
def _header_alias_fix_on() -> bool:
    """表头别名/动态偏移开关（默认开；=0 回退旧固定标签+偏移）。"""
    return str(os.environ.get("RULEPROOF_FOOD_HEADER_ALIAS", "1")).strip().lower() not in (
        "0", "false", "off", "no")


# ---------------------------------------------------------------------------
# L121（2026-11-25）build51 深度评审批次：工序行边界 / 隐藏工作表 / 引擎摘要 / 定位
#
# 缺陷（外部证据 /tmp/build51_deep_review）：
#   ① 工序行动态边界：工序文本固定读「表头后 21 行」（range(rc+1, rc+22)），
#      合法工序行移到第 22 行之后（F22→F23）即漏读 → 违规未发现、结论由「不满足」
#      翻成「满足」；compare 再把漏读当「已解决」（removed>0）。
#   ② 隐藏工作表：parse_xlsx 遍历 wb.sheetnames 全部工作表（含 hidden/veryHidden），
#      隐藏草稿表里的违规会改变正式结论，审核员也追溯不到来源。
#   ③ 引擎摘要：build_report 只要无 critical 就写「通过」+ complete=true，
#      6 项 evidence_insufficient 仍显示通过/完整（把证据不足当完整）。
#   ④ 定位：温控/浓度 finding 的 anchor 只有 sheet（row/col=None），locator 只剩
#      「蔬菜前处理」，无法回到原文单元格复核。
# 修复：
#   ① 工序行读到「文档结束 / 下一节标签 / 连续空行」为止（不固定行数）；开关
#      RULEPROOF_PROCESS_ROWS_DYNAMIC 默认 1，=0 逐字回退固定 21 行。
#   ② 正式审核排除 hidden/veryHidden 工作表（不参与告警/结论），隐藏表清单与说明写入
#      doc.packaging["hidden_sheets"]/["hidden_sheet_note"] 并在报告中输出，审核员可
#      追溯；开关 RULEPROOF_HIDDEN_SHEET_EXCLUDE 默认 1，=0 回退旧行为（纳入全部表）。
#   ③ 无 critical/不满足但存在证据不足或执行失败 → status=待复核、complete=false；
#      只有全部检查满足（且无 finding）才通过；开关 RULEPROOF_ENGINE_SUMMARY_FIX
#      默认 1，=0 逐字回退旧摘要口径（与 CLI/复核链 待复核 口径对齐）。
#   ④ 检查产出的 finding anchor 缺行/列时，按引文在工序行中反查真实行号+单元格列
#      （只补定位，不改判定/引文；无开关，纯定位修复）。
# ---------------------------------------------------------------------------
def _l121_switch_on(name: str) -> bool:
    """L121 开关通用读取（默认开；显式 0/false/off/no 关闭，用于 A/B 与回滚）。"""
    return str(os.environ.get(name, "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _process_rows_dynamic_on() -> bool:
    """工序行动态边界开关（默认 1；=0 逐字回退固定 21 行旧行为）。"""
    return _l121_switch_on("RULEPROOF_PROCESS_ROWS_DYNAMIC")


def _hidden_sheet_exclude_on() -> bool:
    """隐藏工作表排除开关（默认 1；=0 回退旧行为：隐藏表参与审核/结论）。"""
    return _l121_switch_on("RULEPROOF_HIDDEN_SHEET_EXCLUDE")


def _engine_summary_fix_on() -> bool:
    """引擎摘要修复开关（默认 1；=0 逐字回退旧摘要：无 critical 即「通过」）。"""
    return _l121_switch_on("RULEPROOF_ENGINE_SUMMARY_FIX")


# 固定 21 行 = 历史行为（RULEPROOF_PROCESS_ROWS_DYNAMIC=0 时逐字回退）
PROCESS_ROWS_LEGACY = 21
# 动态扫描安全上限（不是表格长度语义；仅防畸形 max_row 把扫描拖到百万行）
PROCESS_ROWS_SCAN_CAP = 5000
# 连续空行达到该值且其后为空 → 视为表结束；其后仍有内容则继续读（兼容稀疏模板）
PROCESS_BLANK_RUN_LIMIT = 20


# 通用单据表头字段别名（只做同一字段的常见写法归一，不含行业内容词）
_IMPL_DATE_LABELS = ("实施日期", "生效日期", "执行日期", "实施生效日期", "生效/实施日期")
_VERSION_LABELS = ("版本号", "文件编号", "文件版本", "版次", "版号",
                   "版本号/文件编号", "文件编号/版本号")
_PRODUCT_LABELS = ("商品名", "品名", "产品名称", "产品名", "商品名称")
_PROCESS_NAME_LABELS = ("工序名称", "工序名", "工序/名称", "工 序 名 称")
_PROCESS_TABLE_LABELS = ("标准工序", "工序流程", "操作步骤", "加工工序", "制造工序",
                         "作业步骤", "工序表", "作业工序")
_DESIGN_TOTAL_LABELS = ("设计总重量", "设计总重", "总重量", "设计重量", "设计总重量(g)",
                        "设计总重量（g）")
_HALF_LIST_LABELS = ("半成品名称", "半成品名", "半成品清单", "半成品分项装盒标准",
                     "半成品分项", "半成品配比")
_MATERIAL_LIST_LABELS = ("包材编号", "包材号", "包材清单", "包材编码",
                         "包材清单与异物检测控制", "包装材料清单")
_SIGN_ROLE_SET = frozenset(SIGN_ROLES)
_LABEL_VALUE_INLINE_RE = re.compile(r"[：:]\s*(\S.*)$")
_DATE_HEAD_RE = re.compile(r"(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})")
# 清单列名（半成品/包材共用；按子表头动态定位）
_LIST_COL_ALIASES = {
    "seq": ("序号", "编号", "项次", "序"),
    "name": ("分项名称", "半成品名称", "名称", "半成品名", "包材名称", "品名", "项目名称"),
    "weight": ("重量", "净重", "单重", "单件重量", "质量"),
    "unit": ("单位", "重量单位"),
    "material_no": ("包材编号", "包材号", "物料编号", "物料编码", "编码"),
}


def _find_label_any(ws, labels):
    """按别名表查找标签单元格（归一后精确匹配；命中任一别名即返回）。"""
    wanted = {_norm_label(str(x)) for x in labels}
    for cell in _cells(ws):
        if _norm_label(str(cell.value)) in wanted:
            return cell.row, cell.column
    return None


def _cell_meta_text(ws, row, col):
    """单元格文本 + 是否内联值（「标签：值」）→ (text, inline_value|None)。"""
    raw = _s(_val_at(ws, row, col))
    m = _LABEL_VALUE_INLINE_RE.search(raw)
    if m and m.group(1).strip():
        return raw, m.group(1).strip()
    return raw, None


def _right_value(ws, row, col, max_delta=8, accept=None):
    """标签右侧最近的非空单元格（可带类型校验）；返回 (value, row, col) 或 (None,None,None)。"""
    for c in range(col + 1, min(ws.max_column, col + max_delta) + 1):
        v = _val_at(ws, row, c)
        txt = _s(v)
        if not txt:
            continue
        if accept is not None and not accept(txt):
            continue
        return v, row, c
    return None, None, None


def _looks_like_date(t) -> bool:
    return bool(_DATE_HEAD_RE.match(_s(t)))


def _is_sign_role(t) -> bool:
    return _norm_label(_s(t)) in _SIGN_ROLE_SET


def _is_label_text(t) -> bool:
    """该文本是否是已知表头/列表标签（避免右侧扫描把相邻标签当值）。"""
    norm = _norm_label(_s(t))
    if not norm:
        return True
    if norm in _SIGN_ROLE_SET:
        return True
    for group in (_IMPL_DATE_LABELS, _VERSION_LABELS, _PRODUCT_LABELS,
                  _PROCESS_NAME_LABELS, _PROCESS_TABLE_LABELS, _DESIGN_TOTAL_LABELS,
                  _HALF_LIST_LABELS, _MATERIAL_LIST_LABELS):
        if norm in {_norm_label(str(x)) for x in group}:
            return True
    return False


def _label_value(ws, aliases, accept=None):
    """按别名找到标签并从其右侧取最近非空值；返回 (value, row, col, label_rc) 或 None。"""
    rc = _find_label_any(ws, aliases)
    if not rc:
        return None
    _raw, inline = _cell_meta_text(ws, rc[0], rc[1])
    if inline and (accept is None or accept(inline)):
        # 内联「标签：值」：返回标签位（值在同一单元格）
        return inline, rc[0], rc[1], rc
    if accept is not None:
        # 类型字段（日期/重量）按类型校验跳过不匹配列，避免把相邻字段标签当值
        v, r, c = _right_value(ws, rc[0], rc[1], accept=accept)
        if v is None:
            # 类型校验全部失败时仍记录第一个非空（由上层 norm 判空），保证可诊断
            v, r, c = _right_value(ws, rc[0], rc[1],
                                   accept=lambda t: not _is_label_text(t))
    else:
        v, r, c = _right_value(ws, rc[0], rc[1],
                               accept=lambda t: not _is_label_text(t))
    if v is None:
        return None
    return v, r, c, rc


# ---------------------------------------------------------------- L121 ① 工序行动态边界
# 下一节标签（工序表结束边界）：表头字段/签名角色/清单标签/常见小节标题，归一后精确匹配。
# 只在前两列判定，避免工序内容（F 列描述里出现「版本号」等字样）被误当边界。
_PROCESS_BOUNDARY_LABELS = frozenset(
    _norm_label(str(x))
    for _group in (_IMPL_DATE_LABELS, _VERSION_LABELS, _PRODUCT_LABELS,
                   _PROCESS_NAME_LABELS, _PROCESS_TABLE_LABELS, _DESIGN_TOTAL_LABELS,
                   _HALF_LIST_LABELS, _MATERIAL_LIST_LABELS)
    for x in _group
) | frozenset(_norm_label(str(x)) for x in SIGN_ROLES) | frozenset(
    _norm_label(x) for x in ("备注", "说明", "注意事项", "审核", "批准", "编制",
                             "制表", "日期", "签名", "版本", "生效", "实施"))


def _row_cells(ws, r):
    """一行内的非空单元格 [(列字母, 文本)]（列序从左到右）。"""
    out = []
    for c in range(1, int(ws.max_column or 0) + 1):
        txt = _s(_val_at(ws, r, c))
        if txt:
            out.append((get_column_letter(c), txt))
    return out


def _is_process_boundary_row(ws, r) -> bool:
    """该行是否是工序表的「下一节标签」行（版本号/实施日期/签名角色/下一张清单…）。

    判定从严，避免把工序内容误当边界而截断后面的合法工序行：
      · 下一节标签出现在**第一列**（真实模板的版本号/实施日期/签名字段都在 A 列）→ 边界；
      · 标签出现在第二列且该行只有 ≤2 个非空单元格（A 列为空/合并单元格的模板）→ 边界；
      · 工序行（如「序号 | 工序名 | 作业内容…」）即使工序名恰为「审核」「备注」等
        保留词、只要行内还有内容列就不会被误截断。
    """
    cells = _row_cells(ws, r)
    if not cells:
        return False
    norm1 = _norm_label(cells[0][1])
    if norm1 and norm1 in _PROCESS_BOUNDARY_LABELS:
        return True
    if len(cells) <= 2:
        for _c, txt in cells[1:]:
            norm = _norm_label(txt)
            if norm and norm in _PROCESS_BOUNDARY_LABELS:
                return True
    return False


def _has_content_between(ws, start, end) -> bool:
    """[start, end] 内是否还有任意非空单元格（用于判断连续空行之后是否已到表尾）。"""
    if end < start:
        return False
    for r in range(start, end + 1):
        if _row_cells(ws, r):
            return True
    return False


def _collect_process_rows(ws, label_row):
    """收集「标准工序」等表头之后到边界为止的工序行。

    L121 ①：不再固定 21 行——
      · 文档结束（ws.max_row，含安全上限 PROCESS_ROWS_SCAN_CAP）；
      · 下一节标签（版本号/实施日期/商品名/签名角色/清单标签…，见 _is_process_boundary_row）；
      · 连续空行 ≥ PROCESS_BLANK_RUN_LIMIT 且其后到表尾无内容（其后仍有内容 → 继续读，
        兼容「数据行之间隔着空白行」的稀疏模板）。
    RULEPROOF_PROCESS_ROWS_DYNAMIC=0 → 逐字回退旧行为（表头后固定读 21 行）。

    返回 (rows, cells_by_row)：
      rows = [(A 列文本, 行内非空单元格" "连接文本, 行号)]（与旧 process_text 结构一致）；
      cells_by_row = {行号: [(列字母, 文本)]}（供 L121 ④ anchor 定位反查，不改变旧消费方）。
    """
    rows, cells_by_row = [], {}
    if not _process_rows_dynamic_on():
        for r in range(label_row + 1, label_row + 1 + PROCESS_ROWS_LEGACY):
            cs = _row_cells(ws, r)
            if not cs:
                continue
            cells_by_row[r] = cs
            rows.append((_s(_val_at(ws, r, 1)), " ".join(t for _c, t in cs), r))
        return rows, cells_by_row

    end = min(int(ws.max_row or 0), label_row + PROCESS_ROWS_SCAN_CAP)
    for r in range(label_row + 1, end + 1):
        if _is_process_boundary_row(ws, r):
            end = r - 1
            break
    blank_run = 0
    for r in range(label_row + 1, end + 1):
        cs = _row_cells(ws, r)
        if not cs:
            blank_run += 1
            if (blank_run >= PROCESS_BLANK_RUN_LIMIT
                    and not _has_content_between(ws, r + 1, end)):
                break
            continue
        blank_run = 0
        cells_by_row[r] = cs
        rows.append((_s(_val_at(ws, r, 1)), " ".join(t for _c, t in cs), r))
    return rows, cells_by_row


def _find_list_header(ws, start_row, max_scan=4):
    """在 start_row 之后找清单子表头行，返回 (header_row, {key: col}) 或 (None, {})。"""
    for r in range(start_row, min(ws.max_row, start_row + max_scan) + 1):
        cols = {}
        for c in range(1, ws.max_column + 1):
            norm = _norm_label(_s(_val_at(ws, r, c)))
            if not norm:
                continue
            for key, aliases in _LIST_COL_ALIASES.items():
                if key in cols:
                    continue
                if norm in {_norm_label(str(x)) for x in aliases}:
                    cols[key] = c
                    break
        if "name" in cols and len(cols) >= 2:
            return r, cols
    return None, {}


def _extract_records(ws, label_aliases, kind):
    """标签 + 子表头动态列 → 记录列表；子表头不可识别时回退旧固定列（1/2/8/10）。

    返回 (records, header_row, cols) —— records 为 HalfProduct / Material 列表。
    """
    rc = _find_label_any(ws, label_aliases)
    if not rc:
        return [], None, {}
    header_row, cols = _find_list_header(ws, rc[0], max_scan=4)
    records = []
    if header_row is not None:
        name_col = cols["name"]
        # 子表头可能只识别到部分列（如合并单元格只写了名称/重量）；
        # 缺失列回退到历史固定列，避免 seq/unit 丢失导致 G3/G5 检查证据不足（L107 回归修复）。
        seq_col = cols.get("seq") or 1
        weight_col = cols.get("weight") or 8
        unit_col = cols.get("unit") or 10
        mat_no_col = cols.get("material_no")
        for r in range(header_row + 1, min(ws.max_row, header_row + 200) + 1):
            name = _s(_val_at(ws, r, name_col))
            if not name:
                break
            seq = _s(_val_at(ws, r, seq_col)) if seq_col else ""
            if (not seq.isdigit()) and (("合计" in name) or ("总计" in name)
                                        or ("小计" in name)):
                break  # 合计/汇总行不是清单记录（避免把合计行当半成品/包材）
            if kind == "half":
                w = norm_num(_val_at(ws, r, weight_col)) if weight_col else None
                u = _s(_val_at(ws, r, unit_col)) if unit_col else ""
                records.append(HalfProduct(seq, name, w, u, r))
            else:
                records.append(Material(seq, name, r))
        return records, header_row, cols
    # 旧固定列回退：半成品 name=2/seq=1/weight=8/unit=10；包材 name=2/seq=1
    for r in range(rc[0] + 1, min(ws.max_row, rc[0] + 20) + 1):
        name = _s(_val_at(ws, r, 2))
        if not name:
            break
        seq = _s(_val_at(ws, r, 1))
        if kind == "half":
            records.append(HalfProduct(seq, name, norm_num(_val_at(ws, r, 8)),
                                       _s(_val_at(ws, r, 10)), r))
        else:
            records.append(Material(seq, name, r))
    return records, None, {}


def parse_xlsx(path: str) -> Document:
    wb = load_workbook(path, read_only=False, data_only=True)
    doc = Document(path=path)
    all_sheet_names = list(wb.sheetnames)
    doc.sheet_names = all_sheet_names       # 工作簿真实清单（可追溯，含隐藏表）
    _fix = _header_alias_fix_on()

    # L121 ②：正式审核范围 = 可见工作表；hidden/veryHidden 表不参与解析/告警/结论。
    # 隐藏表清单与说明保留在 doc.packaging（build_report 输出），审核员可追溯来源。
    hidden_sheets = [
        sn for sn in all_sheet_names
        if str(getattr(wb[sn], "sheet_state", "visible") or "visible").strip().lower()
        in ("hidden", "veryhidden")
    ]
    _exclude_hidden = _hidden_sheet_exclude_on()
    audit_sheets = [sn for sn in all_sheet_names
                    if not (_exclude_hidden and sn in hidden_sheets)]
    doc.packaging["hidden_sheets"] = list(hidden_sheets)
    doc.packaging["hidden_sheet_excluded"] = bool(_exclude_hidden and hidden_sheets)
    doc.packaging["audit_sheets"] = list(audit_sheets)
    if hidden_sheets and _exclude_hidden:
        doc.packaging["hidden_sheet_note"] = (
            "隐藏工作表未参与正式审核：%s（仅审核可见表：%s）。如需纳入请取消隐藏后重新上传。"
            % ("、".join(hidden_sheets), "、".join(audit_sheets) or "无"))
    elif hidden_sheets:
        doc.packaging["hidden_sheet_note"] = (
            "隐藏工作表参与审核（RULEPROOF_HIDDEN_SHEET_EXCLUDE=0 回退旧行为）：%s。"
            % "、".join(hidden_sheets))
    else:
        doc.packaging["hidden_sheet_note"] = ""

    process_sheets = []
    packaging_sheet = None

    for sn in audit_sheets:
        ws = wb[sn]
        h = SheetHeader(sheet=sn)

        if _fix:
            # L107 D3：标签别名 + 右侧最近非空值（类型校验）；日期必须能解析成日期，
            # 避免把右侧相邻字段标签/说明文字当成日期值（旧 +2 偏移在真实模板上取到说明列）。
            got = _label_value(ws, _IMPL_DATE_LABELS, accept=_looks_like_date)
            if got:
                v, r, c, _rc = got
                h.impl_date = norm_date(v)
                if _looks_like_date(v):
                    h.impl_date_cell = f"{get_column_letter(c)}{r}"

            got = _label_value(ws, _VERSION_LABELS)
            if got:
                v, r, c, _rc = got
                h.version = _s(v)
                h.version_cell = f"{get_column_letter(c)}{r}"

            got = _label_value(ws, _PRODUCT_LABELS)
            if got:
                v, r, c, _rc = got
                h.product_name = _s(v)
                h.product_cell = f"{get_column_letter(c)}{r}"

            got = _label_value(ws, _PROCESS_NAME_LABELS)
            if got:
                v, r, c, _rc = got
                h.process_name = _s(v)
        else:
            # 旧行为（RULEPROOF_FOOD_HEADER_ALIAS=0 逐字回退）：精确标签 + 固定偏移
            rc = _find_label(ws, lambda t: t == "实施日期")
            if rc:
                v = _val_at(ws, rc[0], rc[1] + 2)
                h.impl_date = norm_date(v)
                h.impl_date_cell = f"{get_column_letter(rc[1] + 2)}{rc[0]}"

            rc = _find_label(ws, lambda t: t == "版本号")
            if rc:
                h.version = _s(_val_at(ws, rc[0], rc[1] + 2))
                h.version_cell = f"{get_column_letter(rc[1] + 2)}{rc[0]}"

            rc = _find_label(ws, lambda t: t == "商品名")
            if rc:
                h.product_name = _s(_val_at(ws, rc[0], rc[1] + 3))
                h.product_cell = f"{get_column_letter(rc[1] + 3)}{rc[0]}"

            rc = _find_label(ws, lambda t: "工序" in t and "名称" in t)
            if rc:
                h.process_name = _s(_val_at(ws, rc[0], rc[1] + 2))

        # 签名：标签在 r，值在 r+1（角色来自引擎 SIGN_ROLES，后续可由客户词典注入）
        for role in SIGN_ROLES:
            rc = _find_label(ws, lambda t, r=role: t == r)
            if rc:
                h.signatures[role] = _s(_val_at(ws, rc[0] + 1, rc[1]))
                h.signature_cells[role] = f"{get_column_letter(rc[1])}{rc[0] + 1}"

        doc.headers[sn] = h

        # 包装指示书识别
        if "包装" in sn:
            packaging_sheet = sn
        else:
            process_sheets.append(sn)

        # 工序文本（「标准工序」等表头之后；L107 D3 补工序流程/操作步骤/加工工序别名；
        # L121 ①：动态读到文档结束/下一节标签/连续空行，不再固定 21 行）
        if _fix:
            rc = _find_label_any(ws, _PROCESS_TABLE_LABELS)
        else:
            rc = _find_label(ws, lambda t: "标准工序" in t)
        if rc:
            rows, cells_by_row = _collect_process_rows(ws, rc[0])
            if rows:
                doc.process_text[sn] = rows
                doc.process_cells[sn] = cells_by_row

    doc.packaging["process_sheets"] = process_sheets
    doc.packaging["packaging_sheet"] = packaging_sheet

    # 包装指示书：设计总重量 / 半成品清单 / 包材清单
    if packaging_sheet:
        ws = wb[packaging_sheet]
        if _fix:
            got = _label_value(ws, _DESIGN_TOTAL_LABELS,
                               accept=lambda t: norm_num(t) is not None)
            if got:
                v, r, c, _rc = got
                doc.packaging["design_total"] = norm_num(v)
                unit = ""
                for cell in _cells(ws):
                    if cell.row == r:
                        # 单位等价写法统一（克→g、千克/公斤→kg、毫克→mg、全角ＫＧ→kg…）；
                        # 未识别写法留空，由判据层按 fail-safe 判证据不足，不默认按 g 放行。
                        cu = _rexec.canon_weight_unit(cell.value)
                        if cu:
                            unit = cu
                doc.packaging["design_unit"] = unit
            # 半成品/包材清单：标签别名 + 子表头列名动态定位（不可识别才回退固定列）
            half, _hr, _cols = _extract_records(ws, _HALF_LIST_LABELS, "half")
            if half:
                doc.packaging["half_products"] = half
            mats, _mr, _mcols = _extract_records(ws, _MATERIAL_LIST_LABELS, "material")
            if mats:
                doc.packaging["materials"] = mats
        else:
            # 旧行为（逐字回退）
            rc = _find_label(ws, lambda t: t == "设计总重量")
            if rc:
                design = norm_num(_val_at(ws, rc[0], rc[1] + 3))
                unit = ""
                for cell in _cells(ws):
                    if cell.row == rc[0]:
                        cu = _rexec.canon_weight_unit(cell.value)
                        if cu:
                            unit = cu
                doc.packaging["design_total"] = design
                doc.packaging["design_unit"] = unit

            rc = _find_label(ws, lambda t: t == "半成品名称")
            if rc:
                half = []
                for r in range(rc[0] + 1, rc[0] + 20):
                    name = str(_val_at(ws, r, 2)).strip() if _val_at(ws, r, 2) else ""
                    if name == "":
                        break
                    seq = str(_val_at(ws, r, 1)).strip() if _val_at(ws, r, 1) else ""
                    w = norm_num(_val_at(ws, r, 8))
                    u = str(_val_at(ws, r, 10)).strip() if _val_at(ws, r, 10) else ""
                    half.append(HalfProduct(seq, name, w, u, r))
                doc.packaging["half_products"] = half

            rc = _find_label(ws, lambda t: t == "包材编号")
            if rc:
                mats = []
                for r in range(rc[0] + 1, rc[0] + 20):
                    name = str(_val_at(ws, r, 2)).strip() if _val_at(ws, r, 2) else ""
                    if name == "":
                        break
                    seq = str(_val_at(ws, r, 1)).strip() if _val_at(ws, r, 1) else ""
                    mats.append(Material(seq, name, r))
                doc.packaging["materials"] = mats

    wb.close()
    return doc


# ---------------------------------------------------------------- rules / findings

@dataclass
class Finding:
    id: str
    rule_code: str
    level: str                 # critical / warning
    title: str
    description: str
    suggestion: str
    anchors: list = field(default_factory=list)
    facts: list = field(default_factory=list)
    rule_name: str = ""
    category: str = ""
    rclass: str = ""

    def to_dict(self) -> dict:
        return {
            "id": self.id, "rule_code": self.rule_code, "level": self.level,
            "rule_name": self.rule_name, "category": self.category, "rclass": self.rclass,
            "title": self.title, "description": self.description, "suggestion": self.suggestion,
            "locations": [a.to_dict() for a in self.anchors],
        }


@dataclass
class RuleStatus:
    rule_code: str
    name: str
    state: str                 # 满足 / 不满足 / 不适用 / 证据不足 / 执行失败
    detail: str = ""



def _split_cell(s):
    if not s:
        return None, None
    m = re.match(r"([A-Z]+)(\d+)", s)
    if m:
        return int(m.group(2)), m.group(1)
    return None, None


def _any_text_has(doc, sheet, *keys):
    return any(all(k in txt for k in keys) for _, txt, *_ in doc.process_text.get(sheet, []))


# ---------------------------------------------------------------- L121 ④ 证据定位补全
# 行业包产出的温控/浓度 finding 只有 Anchor(sheet, None, None, quote)（引文有、行列空），
# 审核员无法从 locator 回到原文单元格。这里在引擎侧按引文反查工序行 → 补真实行号 +
# 覆盖列（process_cells），只补定位，不改判定/引文/结论，也不引入行业词。
def _quote_cell_column(cells, quote):
    """在行内单元格中找与该引文最匹配的列字母；无命中返回 None。"""
    quote = _s(quote)
    exact = [c for c, t in cells if t == quote]
    if exact:
        return exact[0]
    subs = [(c, t) for c, t in cells if len(t) >= 2 and (t in quote or quote in t)]
    if not subs:
        return None
    # 优先含数字/单位的描述格（温控/浓度值所在格），同等条件取最长文本
    subs.sort(key=lambda ct: (bool(re.search(r"\d", ct[1])), len(ct[1])), reverse=True)
    return subs[0][0]


def _locate_quotes_in_process(doc, sheet, quote):
    """按引文在工序行中反查所有命中 [(score, sheet, 行号, 列字母)]（score 高优先）。

    返回全部命中而不是单条：同一 finding 可能有多个 anchor 引文相同（如两处
    「中心计量70℃以上出锅」），必须按序分配到不同行，否则所有定位都指向第一处。
    """
    quote = _s(quote)
    if not quote:
        return []
    process_text = getattr(doc, "process_text", {}) or {}
    process_cells = getattr(doc, "process_cells", {}) or {}
    names = [sheet] if sheet in process_text else list(process_text)
    hits = []
    for sn in names:
        for _col_a, txt, r in process_text.get(sn) or []:
            row_txt = _s(txt)
            if not row_txt:
                continue
            if row_txt == quote:
                score = 3
            elif quote in row_txt:
                score = 2
            elif row_txt in quote:
                score = 1
            else:
                continue
            col = _quote_cell_column((process_cells.get(sn) or {}).get(r) or [], quote)
            hits.append((score, sn, r, col))
    hits.sort(key=lambda h: (-h[0], h[1], h[2]))
    return hits


def _enrich_finding_locations(doc, findings):
    """给缺行/列的 anchor 补 sheet+row+col（只补空缺，不覆盖已有定位，不改引文）。

    同一 finding 内引文相同的多个 anchor 按出现顺序分配到不同行（已用行跳过），
    避免「两处违规同引文」被补成同一个单元格。
    """
    for f in findings or []:
        used = set()
        for a in getattr(f, "anchors", None) or []:
            if a.row is not None and a.col:
                used.add((getattr(a, "sheet", "") or "", a.row))
                continue
            hits = _locate_quotes_in_process(doc, getattr(a, "sheet", "") or "",
                                            getattr(a, "quote", "") or "")
            if not hits:
                continue
            pick = next((h for h in hits if (h[1], h[2]) not in used), hits[0])
            _score, sn, r, c = pick
            if not a.sheet:
                a.sheet = sn
            if a.row is None:
                a.row = r
            if not a.col and c:
                a.col = c
            used.add((sn, r))


# ---------------------------------------------------------------- 规则注册表
# 每条内置规则 = 一个独立检查函数；CHECKS 是执行顺序（数据），追加即扩展。
#
# build53 L146（T-⑥ P1）：行业包改为经 packs/registry.py 加载（builtin<official<
# tenant<workspace 合并 + 契约校验）；开关 RULEPROOF_PACK_FOOD 默认 1，=0 逐字回退
# 旧行为（硬 import + __dict__ 注入）。注册表/契约错误 → fail-closed：不安装任何
# 行业检查（CHECKS 为空），不静默回退旧硬编码注入。
PACK_STATE = {
    "pack_id": "food",
    "mode": "unloaded",          # legacy / registry / error
    "version": "",
    "layer": "",
    "checks": 0,
    "rules": [],
    "errors": [],
    "last_gate": {},
}


def _pack_food_switch_on() -> bool:
    """行业 pack 开关（默认 1；=0 逐字回退旧硬 import 行为）。"""
    return str(os.environ.get("RULEPROOF_PACK_FOOD", "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _noop_collect_pass_items(doc, statuses, findings, pass_items):
    """pack 加载失败时的占位（fail-closed：不产出任何检查结果）。"""
    return None


def _load_food_pack_legacy():
    """旧行为逐字回退路径（RULEPROOF_PACK_FOOD=0）。"""
    global _food_pack
    from .packs import food as _food_pack
    _food_pack.__dict__.update({k: v for k, v in globals().items()
                                if not k.startswith("__") and k not in ("CHECKS",)})
    PACK_STATE.update(mode="legacy", version="", layer="", errors=[],
                      checks=len(_food_pack.CHECKS),
                      rules=sorted({code for code, _fn in _food_pack.CHECKS}))
    return list(_food_pack.CHECKS), _food_pack.PROCESS_ALIASES, _food_pack._collect_pass_items


def _load_food_pack_registry():
    """注册表加载路径：契约校验 + 16 规则绑定 + 18 检解析，任一失败 fail-closed。"""
    global _food_pack
    from .packs import registry as _pack_registry
    from .packs.base import PackError, engine_min_satisfied
    from .rules_meta import BUILTIN_RULES, RULE_META
    from ..config import APP_VERSION

    registry = _pack_registry.get_default_registry()
    if registry.errors:
        raise PackError("注册表声明错误：" + "；".join(registry.errors[:5]))
    pack = registry.resolve("food")
    manifest = pack.manifest
    if not engine_min_satisfied(manifest.engine_min, APP_VERSION):
        raise PackError(
            f"food pack engine_min={manifest.engine_min!r} 不满足当前引擎 {APP_VERSION}")
    checks = list(pack.checks)
    codes = [code for code, _fn in checks]
    if len(checks) != _pack_registry.FOOD_CHECK_COUNT:
        raise PackError(
            f"food pack 检查数={len(checks)}，应为 {_pack_registry.FOOD_CHECK_COUNT}（18 检）")
    unique = sorted(set(codes))
    rule_codes = sorted(str(r.get("code")) for r in BUILTIN_RULES)
    if len(BUILTIN_RULES) != _pack_registry.FOOD_RULE_COUNT:
        raise PackError(
            f"内置规则数={len(BUILTIN_RULES)}，应为 {_pack_registry.FOOD_RULE_COUNT}（16 条）")
    if unique != rule_codes:
        raise PackError(
            "food pack 规则码与 rules_meta.BUILTIN_RULES 不一致："
            f"pack={unique} rules_meta={rule_codes}")
    if any(code not in RULE_META for code in codes):
        raise PackError("food pack 存在未登记规则码")
    module = pack.module
    _food_pack = module
    module.__dict__.update({k: v for k, v in globals().items()
                            if not k.startswith("__") and k not in ("CHECKS",)})
    PACK_STATE.update(mode="registry", version=manifest.version,
                      layer=registry.source_of.get("food") or manifest.layer,
                      errors=[], checks=len(checks), rules=unique)
    # 逐字节等价(2026-11-25)：旧代码在注入后读取 _food_pack.PROCESS_ALIASES，
    # 而注入内容含 engine 侧同名空 dict（PROCESS_ALIASES = {}）→ 旧实际值为 {}。
    # 这里保持旧语义（不借迁移顺手改运行期状态），pack 契约里的声明值仅用于登记/审计。
    return checks, dict(getattr(module, "PROCESS_ALIASES", {}) or {}), pack.collect_pass_items


if _pack_food_switch_on():
    try:
        CHECKS, PROCESS_ALIASES, _collect_pass_items = _load_food_pack_registry()
    except Exception as _e:  # noqa: BLE001 - fail-closed：不加载任何行业检查
        PACK_STATE.update(mode="error", errors=[f"{type(_e).__name__}: {_e}"],
                          checks=0, rules=[])
        logging.getLogger(__name__).error("food pack 加载失败（fail-closed，18 检不执行）：%s", _e)
        CHECKS, PROCESS_ALIASES = [], {}
        _collect_pass_items = _noop_collect_pass_items
else:
    CHECKS, PROCESS_ALIASES, _collect_pass_items = _load_food_pack_legacy()


def run_rules(doc: Document, category: str = "") -> dict:
    findings: list[Finding] = []
    statuses: list[RuleStatus] = []
    pass_items: list[dict] = []

    from . import audit_category as _ac
    from . import hooks as _hk
    for code, fn in CHECKS:
        meta = RULE_META.get(code) or {}
        if not _ac.allow_rule(category, meta.get("category", "")):
            continue
        beh = _hk.behavior(code)
        if beh.get("enabled") is False:
            statuses.append(RuleStatus(code, meta.get("name", code), "不适用", "规则已被停用"))
            continue
        try:
            fn(doc, statuses, findings, pass_items)
        except Exception as _e:
            statuses.append(RuleStatus(code, meta.get("name", code), "执行失败", f"{type(_e).__name__}: {_e}"))
            continue
    _collect_pass_items(doc, statuses, findings, pass_items)

    # 行为覆盖：严重度降级 + 忽略关键词（让内置规则可被 RSI 真正调整）
    try:
        from . import hooks as _hk2
        kept = []
        for f in findings:
            beh = _hk2.behavior(f.rule_code)
            kws = beh.get("ignore_keywords") or []
            if kws and any(k and k in (f.title or "") for k in kws):
                statuses.append(RuleStatus(f.rule_code, f.title, "不适用", f"命中忽略关键词：{','.join(kws)}"))
                continue
            sev = beh.get("severity") or ""
            if sev in ("critical", "warning", "suspected") and f.level != sev:
                f.level = sev
            kept.append(f)
        findings = kept
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 数据化：把规则元数据（名称/类别/R0-R4）从 rules_meta 回填到每个 finding（单一事实源）
    for f in findings:
        m = RULE_META.get(f.rule_code)
        if m:
            f.rule_name = m["name"]
            f.category = m["category"]
            f.rclass = m["rclass"]

    # L121 ④：温控/浓度等只带 sheet 的 anchor → 按引文反查真实行/列（不动判定与引文）
    _enrich_finding_locations(doc, findings)

    return {"findings": findings, "statuses": statuses, "pass_items": pass_items}


# ---------------------------------------------------------------- report

def _engine_summary(statuses, findings) -> dict:
    """引擎汇总（L121 ③）。

    开关 RULEPROOF_ENGINE_SUMMARY_FIX 默认 1：
      · 有 critical finding / 不满足 / warning finding → 不通过；
      · 无 critical/不满足但存在证据不足或执行失败 → 待复核（不得「通过」），
        complete=false（证据不足不算完整）；
      · 只有全部检查满足（且无 finding）才通过。
    =0 逐字回退旧口径：无 critical 即「通过」（有 finding 时「不通过」），
    complete 只看 exec_failed。
    """
    states = [s.state for s in statuses]
    done = sum(1 for s in states if s in ("满足", "不满足"))
    evidence_insufficient = sum(1 for s in states if s == "证据不足")
    exec_failed = sum(1 for s in states if s == "执行失败")
    critical = [f for f in findings if f.level == "critical"]
    warning = [f for f in findings if f.level == "warning"]
    state_fail = sum(1 for s in states if s == "不满足")

    if _engine_summary_fix_on():
        if critical or warning or state_fail:
            status = "不通过"
        elif evidence_insufficient or exec_failed:
            status = "待复核"
        else:
            status = "通过"
        complete = (exec_failed == 0 and evidence_insufficient == 0)
    else:
        # 旧行为逐字回退（=0 仅供 A/B 对照与回滚）
        status = "不通过" if critical else ("通过" if not findings else "不通过")
        complete = exec_failed == 0

    return {
        "status": status,
        "critical_count": len(critical),
        "warning_count": len(warning),
        "checks_total": len(statuses),
        "checks_done": done,
        "evidence_insufficient": evidence_insufficient,
        "exec_failed": exec_failed,
        "complete": complete,
    }


def _pack_gate_decision(path: str, doc: Document) -> tuple[dict, bool]:
    """P0（L146）：非行业文档不进入行业 18 检的准入判定（仅 registry 模式调用）。

    判定使用平台既有 doc_type/业务域信号（见 packs/registry.food_applies）：
    显式审核文档类型 → 工作空间主文件类型 → 审核点库确定性路由；无法判定按
    fail-closed 跳过（不猜测）。判定结果写入 PACK_STATE["last_gate"] 供审计/测试。
    """
    decision = {}
    try:
        from .packs import registry as _pack_registry
        decision = _pack_registry.get_default_registry().food_applies(path=path, doc=doc)
    except Exception as _e:  # noqa: BLE001 - 准入判定异常 → fail-closed（不进入行业检）
        decision = {"applies": False,
                    "reason": f"gate_error:{type(_e).__name__}: {_e}"}
    meta = {
        "id": "food",
        "version": str(PACK_STATE.get("version") or ""),
        "layer": str(PACK_STATE.get("layer") or ""),
        "applied": bool(decision.get("applies")),
        "reason": str(decision.get("reason") or ""),
        "doc_type": str(decision.get("doc_type") or ""),
    }
    PACK_STATE["last_gate"] = dict(decision)
    return meta, bool(decision.get("applies"))


def _pack_skipped_report(doc: Document, pack_meta: dict) -> dict:
    """未进入行业 pack 的工程报告：与 build_report 同键结构，但 0 检查/0 finding。

    summary 必须是「不适用」而不是「通过」：没适用的判定不能冒充合规结论。
    """
    return {
        "source": doc.path,
        "sheets": doc.sheet_names,
        "audit_sheets": (list(doc.packaging["audit_sheets"])
                         if doc.packaging.get("audit_sheets") is not None
                         else list(doc.sheet_names)),
        "hidden_sheets": list(doc.packaging.get("hidden_sheets") or []),
        "hidden_sheet_excluded": bool(doc.packaging.get("hidden_sheet_excluded")),
        "hidden_sheet_note": doc.packaging.get("hidden_sheet_note") or "",
        "summary": {"status": "不适用", "critical_count": 0, "warning_count": 0,
                    "checks_total": 0, "checks_done": 0,
                    "evidence_insufficient": 0, "exec_failed": 0,
                    "complete": False},
        "findings": [],
        "rule_status": [],
        "pass_items": [],
        "headers": {sn: asdict(h) for sn, h in doc.headers.items()},
        "pack": pack_meta,
    }


def build_report(path: str, category: str = "") -> dict:
    doc = parse_xlsx(path)
    pack_meta = None
    if PACK_STATE.get("mode") == "error":
        # pack 加载失败 fail-closed：不执行任何行业检查，也不冒充“通过”（摘要=不适用）。
        return _pack_skipped_report(doc, {
            "id": "food", "version": "", "layer": "",
            "applied": False, "reason": "pack_load_error",
            "errors": list(PACK_STATE.get("errors") or []),
        })
    if PACK_STATE.get("mode") == "registry":
        pack_meta, applies = _pack_gate_decision(path, doc)
        if not applies:
            # P0（L146）：非行业/无法判定文档不进入 18 检（0 检查、0 finding、
            # 摘要=不适用），不产生跨行业误报；旧行为由 RULEPROOF_PACK_FOOD=0 回退。
            return _pack_skipped_report(doc, pack_meta)
    res = run_rules(doc, category)
    findings = res["findings"]
    statuses = res["statuses"]

    report = {
        "source": doc.path,
        "sheets": doc.sheet_names,
        # L121 ②：审核范围/隐藏表证据（审核员可追溯来源；隐藏表不参与告警/结论）
        # 注意：audit_sheets 可能为空（全部工作表隐藏）→ 不能用 `or` 兜底成全部表，
        # 否则「审核范围为空」会被显示成「全部表参与审核」，属 fail-open。
        "audit_sheets": (list(doc.packaging["audit_sheets"])
                         if doc.packaging.get("audit_sheets") is not None
                         else list(doc.sheet_names)),
        "hidden_sheets": list(doc.packaging.get("hidden_sheets") or []),
        "hidden_sheet_excluded": bool(doc.packaging.get("hidden_sheet_excluded")),
        "hidden_sheet_note": doc.packaging.get("hidden_sheet_note") or "",
        # L121 ③：summary 收敛到 _engine_summary（待复核/complete=false/开关回退）
        "summary": _engine_summary(statuses, findings),
        "findings": [f.to_dict() for f in findings],
        "rule_status": [asdict(s) for s in statuses],
        "pass_items": res["pass_items"],
        "headers": {sn: asdict(h) for sn, h in doc.headers.items()},
    }
    if pack_meta is not None:
        # 新增可审计字段（旧代码无此键）；P1 逐字节等价对照时剔除本键后比较。
        report["pack"] = pack_meta
    return report


# ---------------------------------------------------------------- html


def render_workbook_html(path: str, findings: list, max_rows: int = 80, max_cols: int = 40) -> str:
    """把被审核的 xlsx 渲染成 HTML，问题单元格高亮（需求 e：审核界面高亮）。"""
    hl = set()
    for f in findings:
        for loc in f.get("locations", []):
            sheet = (loc.get("sheet") or "").strip()
            row = loc.get("row")
            col = loc.get("col")
            if sheet and row and col:
                hl.add((sheet, row, col.upper()))

    wb = load_workbook(path, read_only=True, data_only=True)
    parts = []
    for ws in wb.worksheets:
        title = ws.title
        parts.append(f'<div class="sheet"><div class="sheet-head">{_esc_html(title)}</div><table>')
        for r, row in enumerate(ws.iter_rows(min_row=1, max_row=max_rows, max_col=max_cols), start=1):
            parts.append("<tr>")
            for c, cell in enumerate(row, start=1):
                col = get_column_letter(c)
                val = "" if cell.value is None else str(cell.value)
                cls = " class='hl'" if (title.strip(), r, col) in hl else ""
                rc = f"{title.strip()}|{r}|{col}"
                parts.append(f"<td{cls} data-rc=\"{_esc_html(rc)}\">{_esc_html(val[:40]) or '&nbsp;'}</td>")
            parts.append("</tr>")
        parts.append("</table></div>")
    wb.close()
    css = ("<style>body{font-family:-apple-system,'PingFang SC',sans-serif;background:#F5F6F7;margin:0;padding:16px}"
           ".sheet{background:#fff;border:1px solid #DEE0E3;border-radius:8px;margin-bottom:16px;overflow:auto}"
           ".sheet-head{padding:10px 14px;font-weight:600;border-bottom:1px solid #EFF0F1}"
           "table{border-collapse:collapse;font-size:12px}td{border:1px solid #EFF0F1;padding:3px 6px;white-space:nowrap;max-width:220px;overflow:hidden;text-overflow:ellipsis}"
           "td.hl{background:#FFE1D6 !important;border:1px solid #F54A45;font-weight:600}"
           "td.focus{background:#FFF3B0 !important;border-color:#E8D98A}"
           ".sheet.focus{box-shadow:none}</style>")
    return f"<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><title>原文高亮</title>{css}</head><body>{''.join(parts)}</body></html>"


def _esc_html(s: str) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&#x27;"))
