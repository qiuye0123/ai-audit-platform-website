"""文档结构 IR（Document Structure IR）：页 / sheet / 表 / 行 / 单元格 / 坐标 / 字符区间。

L154（2026-11-25）新增。依据 docs/qa/build53_文档解析与预处理规格_20261125.md §5.2 O1–O5、
§5.3 T1–T10，把「解析后只剩一串文本」升级为**可复核的结构化中间表示**：

  Page(page, width_pt, height_pt, has_text_layer, ocr_engine, ocr_confidence, blocks, missing)
  Sheet(sheet, index, hidden, rows, columns, merge_ranges, table_ids, skipped)
  Table(table_id, doc_type, page_from, page_to, sheet, header_rows, repeated_header,
        rows, source, confidence, table_supported, status, continuation_of,
        merged_from_parts, page_available)
  Row(row, page, is_header, cells, source_lines, status)
  Cell(page, sheet, table_id, row, col, rowspan, colspan, text, char_start, char_end,
       bbox, source, confidence, merged_from, formula, missing_reason, is_header,
       line_index, nested_table_ids, text_in_document)

设计边界（不破坏既有契约）：
  * 本模块**只做结构表示与几何/字符区间计算**，不做 OCR、不做数字/单位归一、不做量纲换算；
  * 不 import `deepparse`（避免循环依赖），由 `deepparse` 在解析过程中构造 IR 后挂到
    `ParsedDoc.pages/sheets/tables`；`ParsedDoc.text/sections/facts` 的既有语义不变；
  * 字符区间 `char_start/char_end` 一律是 `ParsedDoc.text` 内**左闭右开**区间（O3）；
  * `bbox` 为 PDF 用户坐标（原点左下、单位 pt）`[x0, y0, x1, y1]`；docx/xlsx 无版面坐标 → `None`
    （不伪造坐标）；
  * PDF 表格只在**文本层坐标可重建**时 `table_supported=True`；不能重建 → `False` + `status=partial`，
    不假装成功（L137 T10/FC6）；
  * docx 嵌套表、批注、修订：批注/修订进**独立通道**（comments/revisions），不混入正文 `text/sections`，
    避免把可复核证据与正文证据口径搅在一起；
  * 隐藏文本/隐藏 sheet 仍沿用 deepparse 守卫：隐藏内容不进 IR 的正文单元格（留痕字段在 ParsedDoc）。
"""
from __future__ import annotations

import logging
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass, field, asdict

IR_VERSION = "l154-document-ir-1"

# 文本层/确定性解析的 provenance 口径（与 deepparse._TEXT_LAYER_PROV 一致；不 import 它）
_TEXT_LAYER = "text_layer"
_TRUSTED = 1.0

# PDF 表格检测参数（pt）
PDF_TABLE_COL_TOL = 12.0        # 同一列 x 中心容差
PDF_TABLE_ROW_TOL = 3.0         # 同一行 y 容差
PDF_TABLE_MIN_ROWS = 2          # 至少 2 行才构成表格块
PDF_TABLE_MAX_GAP = 60.0        # 同一块内相邻行 y 间隔上限（超过视为新块）
PDF_TABLE_HF_ZONE = 72.0        # 页眉/页脚带：y>=h-72 或 y<=72 不参与表格检测（与 L116 同口径）
PDF_TABLE_MAX_ROWS = 200        # 单页表格行上限（防御异常坐标/超大页）

# 值形态：数字 / 数字+单位 / 编号（PF-001、A12）/ 日期。用于「多级表头」识别。
_VALUE_RE = re.compile(
    r"^\s*(?:[-+−]?\d+(?:[.,]\d+)*(?:\s*%|\s*[A-Za-zμµ℃℉°]{1,6}(?:/[A-Za-zμµ]{1,6})?)?"
    r"|(?:起|止|≤|≥|<|>)?\s*\d)"
    r"|^\s*[A-Za-z]{1,8}[-_]?\d{1,6}\b"
    r"|^\s*\d{4}[-/]\d{1,2}[-/]\d{1,2}\s*$"
)

_WS_RE = re.compile(r"[ \t\u3000]{2,}")


# ============================================================ IR 数据模型
@dataclass
class Cell:
    """表格单元格（O1/O3/O4）。"""
    page: int | None = None            # PDF 页号；docx 页不可得 → None（不伪造，O2）
    sheet: str = ""                    # xlsx sheet 名；其它格式空
    table_id: str = ""
    row: int = 0                       # 1 基
    col: int = 0                       # 1 基
    rowspan: int = 1
    colspan: int = 1
    text: str = ""                     # 逻辑值（合并续行/空单元格为空串，占位不左移，T3/T4）
    char_start: int = -1               # ParsedDoc.text 内左闭右开区间（-1=不可定位）
    char_end: int = -1
    bbox: list | None = None           # PDF 用户坐标 [x0,y0,x1,y1]；docx/xlsx=None
    source: str = _TEXT_LAYER          # text_layer | ocr | merged
    confidence: float = _TRUSTED
    merged_from: dict | None = None    # 合并续行：{"row":r,"col":c}（指向逻辑值所在首格）
    formula: str = ""                  # 公式文本（xlsx：缓存或未缓存都记；T9）
    missing_reason: str = ""           # 如 formula_no_cache
    is_header: bool = False
    line_index: int = 0                # 该单元格文本来自 row.source_lines[line_index]（PDF 跨页行用）
    nested_table_ids: list = field(default_factory=list)   # docx 嵌套表（结构在 tables 里）
    text_in_document: bool = True      # False=结构可见但正文 text 中不可见（如嵌套表）

    def to_dict(self):
        return asdict(self)


@dataclass
class Row:
    """表格行（T1/T5）：row 为逻辑行号（1 基，含表头行）。"""
    row: int = 0
    page: int | None = None
    is_header: bool = False
    cells: list = field(default_factory=list)          # [Cell]
    source_lines: list = field(default_factory=list)   # 该行文本来源行（docx/xlsx 行文本；PDF 断行片段）
    page_to: int | None = None                          # 跨页行：结束页
    status: str = "ok"                                  # ok | partial
    note: str = ""

    def to_dict(self):
        d = asdict(self)
        return d


@dataclass
class Table:
    """逻辑表（O5/T5/T6/T7）。table_id 在跨页/跨行合并时保持不变。"""
    table_id: str = ""
    doc_type: str = ""
    page_from: int | None = None
    page_to: int | None = None
    sheet: str = ""
    header_rows: list = field(default_factory=list)     # 逻辑行号（1 基）
    repeated_header: bool = False
    rows: list = field(default_factory=list)           # [Row]
    source: str = _TEXT_LAYER
    confidence: float = _TRUSTED
    table_supported: bool = True                       # PDF 不能重建时 False（T10）
    status: str = "ok"                                 # ok | partial
    continuation_of: str = ""                          # 续表指向基表 table_id（能识别不能合并时）
    merged_from_parts: list = field(default_factory=list)  # 跨页合并来源 part id
    page_parts: list = field(default_factory=list)  # 跨页各部分：[{part_id,page,continuation_of}]
    page_available: bool = True                        # docx 无可靠页号 → False
    notes: list = field(default_factory=list)
    anchor: str = ""                                   # 定位锚（docx 表N / xlsx sheet / PDF 第N页）

    @property
    def ncols(self) -> int:
        return max((len(r.cells) for r in self.rows), default=0)

    def to_dict(self):
        out = {
            "table_id": self.table_id, "doc_type": self.doc_type,
            "page_from": self.page_from, "page_to": self.page_to,
            "sheet": self.sheet, "header_rows": list(self.header_rows),
            "repeated_header": bool(self.repeated_header),
            "rows": [r.to_dict() for r in self.rows],
            "n_rows": len(self.rows), "n_cols": self.ncols,
            "source": self.source, "confidence": float(self.confidence),
            "table_supported": bool(self.table_supported), "status": self.status,
            "continuation_of": self.continuation_of,
            "merged_from_parts": list(self.merged_from_parts),
            "page_parts": [dict(x) for x in self.page_parts],
            "page_available": bool(self.page_available),
            "notes": list(self.notes), "anchor": self.anchor,
        }
        return out


@dataclass
class Page:
    """PDF 页（O2）：按页文本块 + 页码 + 字符区间 + provenance。"""
    page: int = 0
    width_pt: float = 0.0
    height_pt: float = 0.0
    has_text_layer: bool = False
    ocr_engine: str = _TEXT_LAYER
    ocr_confidence: float = _TRUSTED
    blocks: list = field(default_factory=list)   # [{kind,text,bbox,char_start,char_end,source,confidence}]
    missing: bool = False                        # 无文本层且含图像（不可读页，FC4）
    blank: bool = False                          # 无文本层也无图像（空白页）
    notes: list = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


@dataclass
class Sheet:
    """xlsx sheet（T7）：sheet 为独立表身份；隐藏 sheet 只留痕不产出表。"""
    sheet: str = ""
    index: int = 0
    hidden: bool = False
    rows: int = 0
    columns: int = 0
    merge_ranges: list = field(default_factory=list)   # [{r1,c1,r2,c2}]
    table_ids: list = field(default_factory=list)
    skipped: bool = False
    note: str = ""

    def to_dict(self):
        return asdict(self)


# ============================================================ 构造与识别助手
def new_cell(text="", row=0, col=0, **kw) -> Cell:
    return Cell(text=str(text if text is not None else ""), row=int(row), col=int(col), **kw)


def is_value_like(text: str) -> bool:
    """单元格值形态（数字/数字+单位/编号/日期）——用于停止表头扫描、识别数据行。"""
    s = str(text if text is not None else "").strip()
    if not s:
        return False
    return bool(_VALUE_RE.match(s))


def _cell_entry(entry) -> tuple:
    """表头检测输入归一：str 或 {"text","colspan"} → (text, colspan)。"""
    if isinstance(entry, dict):
        try:
            span = max(1, int(entry.get("colspan") or 1))
        except (TypeError, ValueError):
            span = 1
        return str(entry.get("text") or "").strip(), span
    return str(entry or "").strip(), 1


def detect_header_rows(cell_texts: list, max_header_rows: int = 3,
                       min_coverage: int = 2) -> list:
    """多级表头识别（T6）：从第 1 行起连续「非值形态」行 → header_rows（1 基）。

    cell_texts: [[str | {"text","colspan"}, ...], ...]（按行）。标题行（跨列合并）与
    二级表头都算表头；第一行出现值形态（数字/编号/日期）即视为数据起始行。
    单列/覆盖不足（有效列宽 < min_coverage）的文本行不算表头（避免把纯文本行当表头）；
    全空行跳过不计数。max_header_rows 限制最多识别层级（默认 3 级）。
    """
    header = []
    for ridx, row in enumerate(cell_texts, 1):
        entries = [_cell_entry(c) for c in row]
        nonempty = [(t, sp) for t, sp in entries if t]
        if not nonempty:
            continue
        coverage = sum(sp for _t, sp in nonempty)
        if coverage < min_coverage:
            break                    # 单列文本行：不是表头，也不是可判数据行 → 停止
        if any(is_value_like(t) for t, _sp in nonempty):
            break
        header.append(ridx)
        if len(header) >= max_header_rows:
            break
    return header


def _nfkc(s: str) -> str:
    return unicodedata.normalize("NFKC", str(s or ""))


def _row_text_norm(texts) -> str:
    return " ".join(_nfkc(str(t or "")).strip() for t in texts if str(t or "").strip())


def _assign_cell_spans(table: Table, text: str, sections: list,
                       warnings: list) -> None:
    """把 Cell/Row 的 char 区间解析到 `ParsedDoc.text`（O3）：按 anchor+行文本取 section 基址。

    解析口径：docx/xlsx 一行一个 section（row.source_lines[0]）；PDF 一行可能由多个 section
    片段组成（跨页断行），故 row.source_lines 可多行、Cell.line_index 指明归属行。
    """
    queues = defaultdict(list)
    for i, sec in enumerate(sections):
        if str(getattr(sec, "kind", "")) in ("header", "footer"):
            continue
        key = (str(getattr(sec, "anchor", "") or ""), str(getattr(sec, "text", "") or ""))
        queues[key].append(i)
    ptr = defaultdict(int)
    search_from = 0

    def _take_section(anchor: str, line_text: str):
        nonlocal search_from
        key = (anchor, line_text)
        q = queues.get(key) or []
        p = ptr[key]
        if p < len(q):
            ptr[key] = p + 1
            sec = sections[q[p]]
            cs = int(getattr(sec, "char_start", -1) or -1)
            if cs >= 0 and text[cs:cs + len(line_text)] == line_text:
                search_from = max(search_from, cs + len(line_text))
                return cs
        # 回退：在 text 中顺序查找该行文本（如数字拼回改变了 section 文本）
        pos = text.find(line_text, search_from)
        if pos >= 0:
            search_from = pos + len(line_text)
            return pos
        return -1

    for row in table.rows:
        bases = [_take_section(table.anchor, line) for line in row.source_lines]
        if not bases:
            continue
        cursors = defaultdict(int)
        for cell in row.cells:
            li = int(cell.line_index or 0)
            if li < 0 or li >= len(bases):
                li = 0
            base = bases[li]
            line_text = row.source_lines[li] if li < len(row.source_lines) else ""
            if base < 0:
                cell.char_start = cell.char_end = -1
                if cell.text:
                    warnings.append(f"cell 无法定位：{table.table_id} R{row.row}C{cell.col}")
                continue
            if not cell.text:
                # 空单元格：零长度区间（占位可见但无文本，不伪造内容）
                cell.char_start = cell.char_end = base + min(cursors[li], len(line_text))
                continue
            start = cursors[li]
            j = line_text.find(cell.text, start)
            if j < 0:
                j = line_text.find(cell.text)
            if j < 0:
                cell.char_start = cell.char_end = -1
                warnings.append(f"cell 文本与行文本不符：{table.table_id} R{row.row}C{cell.col}")
                continue
            cell.char_start = base + j
            cell.char_end = base + j + len(cell.text)
            cursors[li] = j + len(cell.text)


def finalize_tables(tables: list, text: str, sections: list) -> list:
    """为所有表填 char 区间并做「格文本==text[span]」自检；返回 warnings。"""
    warnings = []
    for table in tables or []:
        _assign_cell_spans(table, text, sections, warnings)
        for row in table.rows:
            for cell in row.cells:
                if not cell.text:
                    continue
                if cell.char_start >= 0 and text[cell.char_start:cell.char_end] != cell.text:
                    warnings.append(
                        f"char span 自检失败：{cell.table_id} R{cell.row}C{cell.col}")
                    cell.char_start = cell.char_end = -1
    return warnings


def char_span_stats(tables: list) -> dict:
    """字符区间完整度：非空单元格中有精确 span 的比例（O3 度量）。"""
    total = resolved = 0
    for table in tables or []:
        for row in table.rows:
            for cell in row.cells:
                if not cell.text or not cell.text_in_document:
                    continue
                total += 1
                if cell.char_start is not None and cell.char_start >= 0 \
                        and cell.char_end > cell.char_start:
                    resolved += 1
    return {"cells_nonempty": total, "cells_with_span": resolved,
            "rate": (resolved / total) if total else 1.0}


def count_cells(tables: list) -> int:
    return sum(len(r.cells) for t in (tables or []) for r in t.rows)


def merge_integrity(tables: list) -> dict:
    """合并完整性（T4）：span 声明数、续行不重复逻辑值、续行标记数。"""
    spans = continuations = dup_values = 0
    for table in tables or []:
        for row in table.rows:
            for cell in row.cells:
                if cell.rowspan > 1 or cell.colspan > 1:
                    spans += 1
                if cell.merged_from:
                    continuations += 1
                    if cell.text:
                        dup_values += 1
    return {"merged_spans": spans, "merged_continuations": continuations,
            "continuation_with_value": dup_values}


def ir_summary(doc_type: str, pages: list, sheets: list, tables: list,
               warnings: list | None = None) -> dict:
    """IR 摘要（供 ParsedDoc.to_dict 与上层/测试消费；不改变 text/sections/facts）。"""
    tables = tables or []
    w = list(warnings or [])
    unsupported = [t.table_id for t in tables if not t.table_supported]
    partial = [t.table_id for t in tables if t.status != "ok"]
    table_supported = None if not tables else (not unsupported)
    return {
        "ir_version": IR_VERSION,
        "doc_type": str(doc_type or ""),
        "page_model": ("pdf_pages" if doc_type == "pdf"
                       else "xlsx_sheets" if doc_type == "xlsx" else "no_page_info"),
        "pages": len(pages or []),
        "sheets": len(sheets or []),
        "tables": len(tables),
        "cells": count_cells(tables),
        "table_supported": table_supported,
        "unsupported_tables": unsupported,
        "partial_tables": partial,
        "char_span": char_span_stats(tables),
        "merge": merge_integrity(tables),
        "warnings": w[:50],
    }


# ============================================================ PDF：页/文本块/表格
def _pdf_rows(segments: list) -> list:
    """PDF 文本段 → 行（同 y 容差内按 x 排序）；每行 cells=[{x,y,size,text}]。"""
    rows = []
    for x, y, size, raw in sorted(segments or [], key=lambda s: (-s[1], s[0])):
        txt = str(raw or "").strip()
        if not txt:
            continue
        for row in rows:
            if abs(row["y"] - y) <= PDF_TABLE_ROW_TOL:
                row["cells"].append({"x": float(x), "y": float(y),
                                     "size": float(size or 10.0), "text": txt})
                break
        else:
            rows.append({"y": float(y), "cells": [{"x": float(x), "y": float(y),
                                                   "size": float(size or 10.0),
                                                   "text": txt}]})
    for row in rows:
        row["cells"].sort(key=lambda c: c["x"])
        row["text"] = " ".join(c["text"] for c in row["cells"])
    return [r for r in sorted(rows, key=lambda r: -r["y"]) if r["cells"]]


def _cluster_columns(rows: list) -> list:
    """行内单元格 x → 列中心（1 维聚类，容差 PDF_TABLE_COL_TOL）。"""
    xs = sorted(c["x"] for row in rows for c in row["cells"])
    centers = []
    for x in xs:
        if not centers or abs(x - centers[-1]) > PDF_TABLE_COL_TOL:
            centers.append(x)
        else:
            centers[-1] = (centers[-1] + x) / 2.0
    return centers


def _map_cells_to_columns(row: dict, centers: list):
    """行内单元格 → 列号（1 基）；距离过远返回 None（列不可判 → 该表不假装支持）。"""
    mapped = {}
    for c in row["cells"]:
        best, bd = None, None
        for j, cx in enumerate(centers, 1):
            d = abs(c["x"] - cx)
            if bd is None or d < bd:
                best, bd = j, d
        if bd is None or bd > max(PDF_TABLE_COL_TOL * 2, 6.0):
            return None
        if best in mapped:      # 两格落同一列：列边界异常，不猜测合并
            return None
        mapped[best] = c
    return mapped


def _row_is_header(row: dict, centers: list) -> bool:
    """表头行判定：覆盖全部列、无值形态单元格（数字/编号/日期）。"""
    mapped = _map_cells_to_columns(row, centers)
    if not mapped or len(mapped) < len(centers):
        return False
    return not any(is_value_like(c["text"]) for c in mapped.values())


def _bbox_of(cell: dict) -> list:
    """单元格 bbox（PDF 用户坐标，左下原点；宽度按字符数粗略估算）。"""
    size = float(cell.get("size") or 10.0)
    width = sum(1.0 if ord(ch) > 0x2E7F else 0.5 for ch in str(cell.get("text") or "")) * size
    x = float(cell.get("x") or 0.0)
    y = float(cell.get("y") or 0.0)
    return [round(x, 1), round(y, 1), round(x + max(width, 1.0), 1), round(y + size, 1)]


def _block_to_rows(block: dict, centers: list) -> list:
    """页内表格块 → 行（cells 按列号对齐；缺列留空占位，T3）。"""
    out = []
    for row in block["rows"]:
        mapped = _map_cells_to_columns(row, centers)
        if mapped is None:
            return []
        cells = []
        for j in range(1, len(centers) + 1):
            c = mapped.get(j)
            cells.append({
                "col": j, "text": (c or {}).get("text", ""),
                "bbox": _bbox_of(c) if c else None,
                "x": (c or {}).get("x"), "y": row["y"],
                "size": (c or {}).get("size", 10.0),
            })
        out.append({"y": row["y"], "cells": cells, "raw_row": row,
                    "partial": len(mapped) < len(centers)})
    return out


def _page_tables(raw: dict) -> dict:
    """单页表格检测 → {"blocks": [...], "table_like_unsupported": [...]}。

    只认「≥2 个文本段组成、≥2 行、列 x 可聚类」的块；页眉/页脚带排除（与 L116 同口径）。
    单段文本行里出现 ≥2 个连续空格（视觉列分隔但无坐标）→ table_like_unsupported（不假装）。
    """
    height = float(raw.get("height") or 792.0)
    rows = _pdf_rows(raw.get("segments") or [])
    in_band = [r for r in rows
               if r["y"] < height - PDF_TABLE_HF_ZONE and r["y"] > PDF_TABLE_HF_ZONE]
    candidates = [r for r in in_band if len(r["cells"]) >= 2]
    blocks = []
    cur = []
    for row in candidates:
        if cur and abs(cur[-1]["y"] - row["y"]) > PDF_TABLE_MAX_GAP:
            blocks.append(cur)
            cur = []
        cur.append(row)
        if len(cur) > PDF_TABLE_MAX_ROWS:
            break
    if cur:
        blocks.append(cur)
    out_blocks = []
    for block in blocks:
        # 注意：单行块也可能是「跨页断行的页首/页尾片段」，不能因行少就丢弃；
        # 置信度在 Table.confidence 上按行数体现（不臆测为完整表）。
        # 部分行（跨页断行）不参与列聚类，避免把少列行当新列
        full_rows = [r for r in block if len(r["cells"]) >= max(2, len(block[0]["cells"]))]
        centers = _cluster_columns(full_rows or block)
        if len(centers) < 2:
            continue
        rows = _block_to_rows({"rows": block}, centers)
        if not rows:
            # 列不可判：仍有表格迹象 → 标 unsupported（不假装）
            out_blocks.append({"rows": [], "centers": centers,
                               "unsupported": True, "reason": "column_assignment_failed",
                               "raw": block})
            continue
        out_blocks.append({"rows": rows, "centers": centers,
                           "unsupported": False,
                           "header_guess": _row_is_header(rows[0]["raw_row"], centers),
                           "raw": block})
    # 无坐标表格迹象：单段行内多空格
    unsupported_single = []
    for row in rows:
        if len(row["cells"]) == 1 and _WS_RE.search(row["text"]):
            unsupported_single.append(row["text"])
    return {"blocks": out_blocks, "table_like_unsupported": unsupported_single}


def detect_pdf_tables(raw_pages: list) -> tuple:
    """PDF 文本层表格识别 + 跨页续行/续表合并（T1/T5/T6）。

    返回 (tables, meta)：
      tables: [Table]；meta: {table_supported, partial, reasons, unsupported_pages}
    绝不臆测：列不可判/断行不能拼回 → table_supported=False + status=partial（FC6）。
    """
    tables = []
    open_tables = []          # [{"table": Table, "centers": [...], "header_sig": str}]
    reasons = []
    unsupported_pages = []
    for raw in raw_pages or []:
        pno = int(raw.get("page") or 0)
        if not raw.get("segments"):
            continue
        info = _page_tables(raw)
        if info["table_like_unsupported"]:
            unsupported_pages.append(pno)
            reasons.append(f"page{pno}: 单段文本行含视觉列分隔但无坐标，表格不可重建（table_supported=false）")
            try:
                t = Table(table_id=f"pdf:p{pno}:t0", doc_type="pdf",
                          page_from=pno, page_to=pno, source=_TEXT_LAYER,
                          table_supported=False, status="partial",
                          anchor=f"第{pno}页",
                          notes=["table_like_text_without_coordinates"])
                t.rows = [Row(row=i, page=pno, cells=[
                    new_cell(line, row=i, col=1, page=pno, table_id=t.table_id,
                             source=_TEXT_LAYER, confidence=0.4)],
                    source_lines=[line], status="partial")
                    for i, line in enumerate(info["table_like_unsupported"], 1)]
                t.confidence = 0.4
                tables.append(t)
            except Exception:  # noqa: BLE001 - IR 构建失败不得阻断解析
                logging.getLogger(__name__).debug("pdf unsupported table IR failed",
                                                  exc_info=True)
        for block in info["blocks"]:
            centers = block["centers"]
            if block["unsupported"]:
                t = Table(table_id=f"pdf:p{pno}:t{len(tables) + 1}", doc_type="pdf",
                          page_from=pno, page_to=pno, source=_TEXT_LAYER,
                          table_supported=False, status="partial",
                          confidence=0.4, anchor=f"第{pno}页",
                          notes=[f"unsupported: {block['reason']}"])
                t.rows = [Row(row=i + 1, page=pno, cells=[
                    new_cell(row["text"], row=i + 1, col=1, page=pno,
                             table_id=t.table_id, source=_TEXT_LAYER, confidence=0.4)],
                    source_lines=[row["text"]], status="partial")
                    for i, row in enumerate(block["raw"])]
                tables.append(t)
                reasons.append(f"page{pno}: 表格列不可判（column_assignment_failed）→ partial")
                continue
            rows = block["rows"]
            header_sig = _row_text_norm([c["text"] for c in rows[0]["cells"]])
            header_guess = bool(block.get("header_guess"))
            # 找开放表（两种情形）：
            #   ① 有表头的块 → 续页表：列中心数量/位置兼容 + 表头签名一致；
            #   ② 无表头的块 → 页内/页首断行片段：列中心是既有表列的子集（T5）。
            match = None
            chosen_centers = centers
            if header_guess:
                for cand in open_tables:
                    tc = cand["centers"]
                    if len(tc) != len(centers):
                        continue
                    if max(abs(a - b) for a, b in zip(tc, centers)) > PDF_TABLE_COL_TOL * 2:
                        continue
                    if cand["header_sig"] and header_sig != cand["header_sig"]:
                        continue
                    match = cand
                    break
            else:
                for cand in reversed(open_tables):
                    tc = cand["centers"]
                    if not tc:
                        continue
                    if all(any(abs(c - t) <= PDF_TABLE_COL_TOL * 2 for t in tc)
                           for c in centers):
                        match = cand
                        chosen_centers = tc
                        break
                if match is not None:
                    _remapped = _block_to_rows({"rows": block["raw"]}, chosen_centers)
                    if _remapped:
                        rows = _remapped
            if match is None:
                t = Table(table_id=f"pdf:p{pno}:t{len(tables) + 1}", doc_type="pdf",
                          page_from=pno, page_to=pno, source=_TEXT_LAYER,
                          anchor=f"第{pno}页",
                          page_available=True)
                t.confidence = 1.0 if header_guess else 0.8
                t.rows = []
                tables.append(t)
                match = {"table": t, "centers": centers, "header_sig": header_sig}
                open_tables.append(match)
                t.merged_from_parts.append(f"{t.table_id}@p{pno}")
                t.page_parts.append({"part_id": f"{t.table_id}@p{pno}",
                                     "page": pno, "continuation_of": ""})
            table = match["table"]
            if pno != table.page_from:
                table.page_to = pno
            _part = f"{table.table_id}@p{pno}"
            if _part not in table.merged_from_parts:
                table.merged_from_parts.append(_part)
                table.page_parts.append({"part_id": _part, "page": pno,
                                         "continuation_of": table.table_id})
            start = 0
            if header_guess and table.rows and rows and header_sig == match["header_sig"] \
                    and header_sig == _row_text_norm([c.text for c in table.rows[0].cells]):
                table.repeated_header = True
                start = 1        # 续页重复表头：归一为逻辑表头，不计数据行（T6）
            for k in range(start, len(rows)):
                r = rows[k]
                # 跨页断行合并：上一行是部分行 + 本行只补缺列 → 拼成一行（T5）
                if r["partial"] and table.rows and table.rows[-1].status == "partial":
                    last = table.rows[-1]
                    filled = [c for c in last.cells if c.text]
                    incoming = [c for c in r["cells"] if c["text"]]
                    overlap = any(lc.col == ic["col"] for lc in filled for ic in incoming)
                    if not overlap:
                        frag_text = str(r.get("raw_row", {}).get("text")
                                        or " ".join(c["text"] for c in incoming))
                        if not last.source_lines:
                            last.source_lines.append(str(r.get("raw_row", {}).get("text", "")))
                        last.source_lines.append(frag_text)
                        _li = len(last.source_lines) - 1
                        for ic in incoming:
                            cell = last.cells[ic["col"] - 1]
                            cell.text = ic["text"]
                            cell.bbox = ic["bbox"] or cell.bbox
                            cell.confidence = 1.0
                            cell.line_index = _li      # 续行片段来自下一行/下一页
                            cell.page = pno
                        last.status = "ok"
                        last.page_to = pno
                        _fix_merged_row_lines(last)
                        continue
                row_no = len(table.rows) + 1
                cells = [new_cell(c["text"], row=row_no, col=c["col"], page=pno,
                                  table_id=table.table_id, source=_TEXT_LAYER,
                                  bbox=c["bbox"],
                                  confidence=1.0 if c["text"] else 0.6)
                         for c in r["cells"]]
                _src_text = str(r.get("raw_row", {}).get("text", ""))
                row = Row(row=row_no, page=pno, is_header=bool(header_guess and k == 0),
                          cells=cells, source_lines=[_src_text],
                          status="partial" if r["partial"] else "ok")
                if row.is_header:
                    table.header_rows.append(row_no)
                    for c in row.cells:
                        c.is_header = True
                table.rows.append(row)
    # 收尾：未拼回的部分行 → 表 partial/unsupported（不假装）
    for cand in open_tables:
        t = cand["table"]
        if not t.rows:
            continue
        if any(r.status != "ok" for r in t.rows):
            t.table_supported = False
            t.status = "partial"
            t.notes.append("cross_page_row_unmerged")
            _bad = [r.row for r in t.rows if r.status != "ok"]
            reasons.append(f"{t.table_id}: 跨页断行未能拼回（行 {_bad}）→ partial")
        if not any(r.is_header for r in t.rows) or not t.header_rows:
            # 无表头：仍可用，但降低置信度并留痕
            t.confidence = min(float(t.confidence), 0.8)
            t.notes.append("header_not_identified")
    supported = all(bool(t.table_supported) for t in tables) if tables else None
    meta = {"table_supported": supported,
            "partial": any(t.status != "ok" for t in tables),
            "reasons": reasons,
            "unsupported_pages": unsupported_pages}
    return tables, meta


def _fix_merged_row_lines(row: Row) -> None:
    """跨页行合并后 source_lines 仍是两个片段，保持可追溯（不复制逻辑值为一行文本）。"""
    row.note = "cross_page_continuation_merged"


def build_pdf_pages(raw_pages: list, sections: list) -> list:
    """PDF → [Page]：页号/页尺寸/文本层标志/按行文本块 + bbox + char 区间。"""
    pages = []
    page_secs = defaultdict(list)
    for sec in sections or []:
        anchor = str(getattr(sec, "anchor", "") or "")
        m = re.match(r"^第(\d+)页$", anchor)
        if m:
            page_secs[int(m.group(1))].append(sec)
    for raw in raw_pages or []:
        pno = int(raw.get("page") or 0)
        page = Page(page=pno, height_pt=float(raw.get("height") or 0.0),
                    width_pt=float(raw.get("width") or 0.0),
                    has_text_layer=bool(str(raw.get("text") or "").strip()))
        rows = _pdf_rows(raw.get("segments") or [])
        row_by_text = {}
        for r in rows:
            row_by_text.setdefault(r["text"], r)

        def _row_bbox(r):
            xs = [c["x"] for c in r["cells"]]
            sizes = [c["size"] for c in r["cells"]]
            y = r["y"]
            return [round(min(xs), 1), round(y, 1),
                    round(max(xs) + 20.0, 1), round(y + max(sizes or [10.0]), 1)]

        _row_ptr = [0]
        for sec in page_secs.get(pno) or []:
            txt = str(getattr(sec, "text", "") or "")
            if not txt:
                continue
            bbox = None
            _src = ""
            r = row_by_text.get(txt)
            if r:
                bbox = _row_bbox(r)
                _src = "line"
            else:
                # 数字/断行拼回后 section 文本是多行拼接：用首个来源行的 bbox（真实片段坐标，
                # 不伪造整块坐标），并标 bbox_source=approx_first_fragment
                for j in range(_row_ptr[0], len(rows)):
                    _rt = str(rows[j].get("text") or "")
                    if _rt and txt.startswith(_rt):
                        bbox = _row_bbox(rows[j])
                        _src = "approx_first_fragment"
                        _row_ptr[0] = j + 1
                        break
            _cs = getattr(sec, "char_start", -1)
            _ce = getattr(sec, "char_end", -1)
            block = {"kind": "text", "text": txt, "bbox": bbox,
                     "char_start": int(_cs) if _cs is not None else -1,
                     "char_end": int(_ce) if _ce is not None else -1,
                     "source": str(getattr(sec, "ocr_engine", "") or _TEXT_LAYER),
                     "bbox_source": _src,
                     "confidence": 1.0}
            page.blocks.append(block)
        if not page.blocks:
            page.ocr_engine = ""
            page.ocr_confidence = 0.0
        pages.append(page)
    return pages


# ============================================================ docx：批注通道
def extract_docx_comments(doc, path: str = "") -> dict:
    """提取 docx 批注为独立通道（L137 C1）：作者/时间/文本/锚点段落/锚点字符区间占位。

    返回 {"present", "parsed", "channel", "items":[...]}；
    批注文本**不进正文 text/sections**（防泄漏），但保留结构化可复核字段（C1/C4）。
    锚点字符区间由调用方在正文 section 区间确定后回填（本函数给相对段落内偏移）。
    """
    out = {"present": False, "parsed": 0, "channel": "word/comments.xml",
           "items": [], "anchored": 0, "note": ""}
    try:
        from docx.oxml.ns import qn
    except Exception:  # noqa: BLE001
        out["note"] = "python-docx 不可用，批注通道未解析"
        return out
    raw = []
    try:
        import zipfile
        from xml.etree import ElementTree as _ET
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            if "word/comments.xml" not in names:
                return out
            out["present"] = True
            root = _ET.fromstring(zf.read("word/comments.xml"))  # nosec B314 - 本地 zip 成员
            w_ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
            for c in root.iter(w_ns + "comment"):
                cid = str(c.get(w_ns + "id") or "")
                text = "".join(c.itertext()).strip()
                raw.append({"id": cid,
                            "author": str(c.get(w_ns + "author") or ""),
                            "initials": str(c.get(w_ns + "initials") or ""),
                            "date": str(c.get(w_ns + "date") or ""),
                            "text": text[:2000]})
    except Exception as exc:  # noqa: BLE001 - 批注解析失败不阻断正文；显式留痕
        out["note"] = f"comments_unparsed: {type(exc).__name__}: {str(exc)[:160]}"
        return out
    if not raw:
        return out
    anchors = {}
    try:
        for i, para in enumerate(getattr(doc, "paragraphs", []) or []):
            offset = 0
            open_ids = {}
            for child in para._p.iterchildren():
                tag = child.tag
                if tag == qn("w:commentRangeStart"):
                    open_ids[str(child.get(qn("w:id")))] = offset
                elif tag == qn("w:commentRangeEnd"):
                    cid = str(child.get(qn("w:id")))
                    if cid in open_ids:
                        anchors[cid] = {"paragraph": i + 1,
                                        "start": open_ids.pop(cid),
                                        "end": offset}
                elif tag == qn("w:r"):
                    offset += len("".join(t.text or "" for t in child.iter(qn("w:t"))))
    except Exception:  # noqa: BLE001 - 锚点失败时批注仍可列出（anchored=False）
        logging.getLogger(__name__).debug("docx comment anchors probe failed", exc_info=True)
    items = []
    for c in raw:
        a = anchors.get(c["id"]) or {}
        item = dict(c, source="comments_xml", kind="comment",
                    anchored=bool(a), anchor_paragraph=a.get("paragraph"),
                    anchor_start=a.get("start", -1), anchor_end=a.get("end", -1),
                    char_start=-1, char_end=-1, evidence_allowed=True)
        items.append(item)
        if a:
            out["anchored"] += 1
    out["items"] = items
    out["parsed"] = len(items)
    if out["parsed"] and not out["anchored"]:
        out["note"] = ("comments_present_but_unanchored: 已提取批注文本但未找到 "
                       "commentRangeStart/End 锚点（锚点缺失，证据不可定位）")
    return out


# ============================================================ 综合
def to_public(obj):
    """dataclass/列表/字典 → JSON 安全结构（去掉私有临时键）。"""
    if isinstance(obj, Table):
        return obj.to_dict()
    if isinstance(obj, (Row, Cell, Page, Sheet)):
        return asdict(obj)
    if isinstance(obj, list):
        return [to_public(x) for x in obj]
    if isinstance(obj, dict):
        return {k: to_public(v) for k, v in obj.items() if not str(k).startswith("_")}
    return obj
