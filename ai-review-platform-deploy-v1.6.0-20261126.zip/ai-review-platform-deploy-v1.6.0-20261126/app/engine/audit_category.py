"""审核类型（一级）→ 内部规则类别映射。

一级大类来自「文件审核库」的 A-G 七类；内部规则用的是 consistency/completeness/format/limit/preprocess。
本模块负责把「用户选的一级」翻译成「实际要执行的规则类别」，让选择真正生效。
"""

# 一级大类 → 内部规则类别（None 表示"该大类下没有内置规则"，只走审核点库）
CATEGORY_TO_RULES = {
    "A": set(),                                   # 主体、资格与程序（审核点库覆盖）
    "B": {"completeness", "format"},              # 结构与内容完备
    "C": {"consistency", "limit"},                # 事实、数据与证据
    "D": {"consistency"},                         # 逻辑、论证与结论
    "E": set(),                                   # 权利义务与风险分配
    "F": {"limit", "preprocess"},                 # 商务、执行与合规底线
    "G": set(),                                   # 披露、申报与绩效
}

# 事实层规则 id → 内部类别
FACT_RULE_CATEGORY = {
    "F-日期": "consistency", "F-版本": "completeness", "F-名称": "consistency",
    "F-签名": "completeness", "F-重量": "limit",
    "F-中心温度": "limit", "F-消毒": "limit", "F-冷却": "limit",
    "F-冷藏": "limit", "F-解冻": "limit", "F-单位": "format",
}

# 事实层规则 → 中文类别（用于报告展示，不再散落在服务层）
FACT_RULE_LABEL = {
    "F-中心温度": "参数限值", "F-消毒": "参数限值", "F-冷却": "参数限值",
    "F-冷藏": "参数限值", "F-解冻": "参数限值", "F-重量": "参数限值",
    "F-名称": "名称规范", "F-日期": "一致性", "F-版本": "完备性",
    "F-签名": "完备性", "F-单位": "格式",
}

LABELS = {
    "A": "主体、资格与程序", "B": "结构与内容完备", "C": "事实、数据与证据",
    "D": "逻辑、论证与结论", "E": "权利义务与风险分配", "F": "商务、执行与合规底线",
    "G": "披露、申报与绩效",
}


def rule_categories(category: str) -> set:
    """一级大类 → 允许执行的内部规则类别；空字符串表示"全部"。"""
    if not category:
        return set()
    return CATEGORY_TO_RULES.get(category.upper(), set())


def allow_rule(category: str, rule_category: str) -> bool:
    """判断某条内部规则是否应该在所选一级下执行。"""
    cats = rule_categories(category)
    if not cats:
        return True if not category else False
    return (rule_category or "") in cats


def allow_fact_rule(category: str, fact_id: str) -> bool:
    if not category:
        return True
    cats = rule_categories(category)
    if not cats:
        return False
    return FACT_RULE_CATEGORY.get(fact_id, "") in cats
