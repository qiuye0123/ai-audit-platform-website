# -*- coding: utf-8 -*-
"""批准摘录 vs 工艺正文的确定性差异检测（原生改写/引用编号篡改）。

不依赖模型：把 TJ「工艺正文原页N的批准摘录」与正文第 N 页逐段对齐；
近似但不一致 → 输出可定位差异。用于补通用 LLM 对“应→宜/编号+1”不敏感的短板。
"""
import difflib
import re


def _norm(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def _pages(text: str) -> dict:
    marks = list(re.finditer(r"(?m)^###\s*原页\s*(\d+)\s*$", text or ""))
    out = {}
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        out[m.group(1)] = (text[m.end():end] or "").strip()
    return out


def _approvals(text: str) -> list:
    out = []
    for m in re.finditer(r"(?ms)^###\s+(JS|TJ)-\S+\s*\n(.*?)(?=^###\s|\Z)", text or ""):
        body = m.group(2)
        a = re.search(r"工艺正文原页\s*(\d+)\s*的批准摘录[：:]\s*(.+)", body, re.S)
        if not a:
            continue
        snippet = a.group(2).strip().split("\n")[0].strip()
        if len(snippet) >= 8:
            out.append((m.group(1), a.group(1), snippet))
    return out


def findings(text: str, doc_name: str = "") -> list:
    pages = _pages(text)
    if not pages:
        return []
    out = []
    for tj, page_no, approved in _approvals(text):
        page = pages.get(page_no)
        if not page:
            continue
        na, np_ = _norm(approved), _norm(page)
        if not na:
            continue
        if na in np_:
            continue
        sm = difflib.SequenceMatcher(None, na, np_, autojunk=False)
        matched = sum(b.size for b in sm.get_matching_blocks())
        ratio = matched / max(1, len(na))
        if ratio < 0.72:
            continue
        # 取正文里与批准摘录最接近的一段，供人工比对
        blocks = sm.get_matching_blocks()
        if not blocks:
            continue
        b = max(blocks, key=lambda x: x.size)
        start = max(0, b.b - 20)
        after = page[start:start + max(40, len(approved) + 40)].strip()
        out.append({
            "id": f"APPROVED-DIFF-{tj}-{page_no}", "rule_code": "APPROVED-DIFF",
            "point_id": "", "level": "warning", "title": f"批准摘录与工艺正文不一致（原页{page_no}）",
            "rule_name": "批准文本一致性", "category": "text_diff",
            "description": f"批准摘录（TJ {tj}）为「{approved[:80]}」，正文原页 {page_no} 近似但不一致，需履行变更或恢复原文",
            "suggestion": "核对批准版本与正文，恢复批准文本或补充变更批准",
            "locations": [{"locator": f"工艺正文原页{page_no}", "quote": after[:180],
                           "sheet": "", "before": approved[:180], "after": after[:180]}],
            "criterion": "批准摘录与正文逐字一致", "level_label": "中",
            "evidence_id": tj,
        })
    return out


def native_recall(findings_list: list, gold_native: list) -> int:
    """测试辅助：按页号+问题关键词匹配金标。"""
    hit = 0
    for g in gold_native:
        page = re.search(r"原页\s*(\d+)", g.get("location") or "")
        if not page:
            continue
        p = page.group(1)
        if any(p in (x.get("locations") or [{}])[0].get("locator", "") for x in findings_list):
            hit += 1
    return hit
