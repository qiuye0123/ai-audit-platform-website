"""
标准对照检查（规则-事实 / 标准版本不一致，三态）。

对照“工艺要点”这类检查表与工艺书原文，检出“标准与样例不一致”的项，
输出三态：满足 / 不一致(需人工确认) / 证据不足。不静默选一个。

示例：工艺要点要求肉类冷藏解冻 48h / 中心 0-5℃；样例写 20h / 0-8℃。
这可能是版本/适用范围不同，必须提示人工确认，不能直接判“违规”。
"""
import os
import re
from dataclasses import dataclass, field, asdict

from openpyxl import load_workbook


@dataclass
class StdCheck:
    process: str
    metric: str
    expected: str
    found: str
    state: str          # 满足 / 不一致 / 证据不足
    detail: str = ""

    def to_dict(self):
        return asdict(self)


def load_points(path: str) -> list:
    """读取工艺要点.xlsx：Sheet1 的 工序/工艺/要点。"""
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[0] is None or str(r[0]).strip() == "":
            continue
        rows.append({
            "process": str(r[0]).strip(),
            "steps": str(r[1] or ""),
            "points": str(r[2] or ""),
        })
    wb.close()
    return rows


def _norm(s: str) -> str:
    return s.replace("\u3000", " ").replace("　", " ").strip()


# 可检查的“标准要求 → 样例实际”匹配项（演示种子，生产来自条款库）
CHECKS = [
    {
        "process": "肉类前处理",
        "metric": "解冻时长",
        "expect_tokens": ["48小时", "48h", "48 小时"],
        "sample_tokens": ["20h", "20小时", "20 小时"],
    },
    {
        "process": "肉类前处理",
        "metric": "解冻中心温度",
        "expect_tokens": ["0-5℃", "0~5℃", "0-5度"],
        "sample_tokens": ["0-8℃", "0~8℃"],
    },
    {
        "process": "蔬菜前处理",
        "metric": "消毒浓度",
        "expect_tokens": ["200ppm"],
        "sample_tokens": ["200ppm"],
    },
]


def check(doc_process_text: dict, points_path: str) -> list:
    """doc_process_text: {sheet: [(工序列值, 行文本)]}（来自 engine.parse_xlsx 的 process_text）。"""
    try:
        points = load_points(points_path) if points_path and os.path.exists(points_path) else []
    except Exception:
        points = []
    out = []
    point_by_proc = {_norm(p["process"]): p for p in points}

    # 把样例的 process_text 拍平为 {sheet: 全文}
    sample_text = {sn: " ".join(txt for _, txt, *_ in rows) for sn, rows in doc_process_text.items()}

    for c in CHECKS:
        proc = c["process"]
        # 找样例里对应的 sheet（按工序名模糊匹配）
        sheet = None
        for sn in sample_text:
            if proc in sn or sn in proc or proc[:2] in sn:
                sheet = sn
                break
        if sheet is None:
            out.append(StdCheck(proc, c["metric"], "", "", "证据不足", "样例未找到对应工序 Sheet"))
            continue
        txt = sample_text[sheet]
        exp_std = _norm(point_by_proc.get(proc, {}).get("points", ""))
        # 判据自证：期望值与样例值完全相同 → 无法证明不一致
        if c["expect_tokens"] == c["sample_tokens"]:
            out.append(StdCheck(proc, c["metric"], c["expect_tokens"][0], "", "证据不足",
                                "检查项判据与样例相同（自证），无法判定；请补标准值"))
            continue
        exp_hit = next((t for t in c["expect_tokens"] if t in exp_std), None)
        sam_hit = next((t for t in c["sample_tokens"] if t in txt), None)
        if not exp_hit:
            out.append(StdCheck(proc, c["metric"], c["expect_tokens"][0], sam_hit or "", "证据不足",
                                f"标准文本未提供可核对值（期望 {'/'.join(c['expect_tokens'])}）"))
        elif sam_hit and sam_hit != exp_hit:
            out.append(StdCheck(proc, c["metric"], exp_hit, sam_hit, "不一致",
                                f"工艺要点：{exp_std[:80]}；样例：{sam_hit}。需人工确认版本/适用范围"))
        elif sam_hit:
            out.append(StdCheck(proc, c["metric"], exp_hit, sam_hit, "满足", "与工艺要点一致"))
        else:
            out.append(StdCheck(proc, c["metric"], exp_hit, "", "证据不足",
                                f"样例未标注该指标（期望 {exp_hit}）"))
    return out
