#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Certificate Kernel（证书内核，生产版；入口 `app/engine/certificate.py`）。

L55 独立原型（`scripts/qa/prototypes/certificate_kernel.py`，106/106 断言）的 P2b 生产化：
把一条 finding 的「判定」变成一张可脱库、可独立重算、可字节级复现的证书。

职责（纯函数；0 模型 / 0 网络 / 0 数据库；只依赖文档原文视图 + 证书正文）：
  * 逐字引文 + 原文字符区间（quote / char_start / char_end，支持 locator 锚定 span）；
  * 结构化「复算输入」operands（数值/单位/日期/一致性/多实例/占位符/序号/重量/要素缺失）；
  * 确定性 verifier（9 类）重算结论，与 finding 声称的 fail 对齐；
  * 10 项标准 checks（引文存在 / span 一致 / 操作数可解析 / 操作数逐字命中 /
    复算可执行 / 复算结论与声称一致 / 预算 / verifier 已知且确定性 / 0 模型 / 输入绑定）；
  * 三态 status：pass（确认 claim）/ fail（与 claim 矛盾或篡改）/ insufficient
    （证据不足、未知单位、预算超限、verifier 未知等一律 → insufficient，绝不静默 pass）；
  * canonical JSON + certificate_id + digest；inputs_digest 绑定原文/规则版本/verifier/快照；
  * 独立 checker `verify_certificate`（只信任 证书 + 原文 + 可选当前快照）；
  * 报告门禁 `gate_report`（无证书/证书 fail/insufficient/输入漂移的结构化 reason）。

生产接线：`app/services/certificate_service.py`（签发/落表/覆盖统计/门禁节/降级）、
`app/services/manifest_exec.py`（D5 裁决后签发钩子）、`app/services/report_gate.py`（证书节）。
开关：`RULEPROOF_CERTIFICATE_KERNEL` 默认 0（关闭时与接入前逐字节一致）；
`RULEPROOF_CERTIFICATE_REQUIRED` 默认 0（advisory；=1 时报告门禁阻断）。
规格：`docs/CURRENT/71-CertificateKernel规格_20261124.md`。

兼容：VERIFIER_VERSION 与 L55 原型一致（cert-verifier-2026-11-24.1），
L55 golden 12 张证书可用本模块 `verify_certificate` 独立重算。

运行自检（本模块内建原型样例，可独立跑）：
    python3 -m app.engine.certificate --samples
"""
from __future__ import annotations

import logging
import hashlib
import json
import re
import unicodedata

SCHEMA_VERSION = "certificate-kernel/v1"
VERIFIER_VERSION = "cert-verifier-2026-11-24.1"
TEXT_PROFILE = "text/utf8-nfc-lines"
# 证据型证书（无 recompute 的语义类 finding 只签证据证书，不得伪造 0 模型复算通过）
EVIDENCE_CERT_KIND = "evidence_presence"
ALLOWED_STATUSES = ("pass", "fail", "insufficient")
# 原型期预算：确定性硬边界（不读墙钟，避免破坏字节可复现）
DEFAULT_BUDGET = {
    "max_checks": 16,
    "max_document_chars": 2_000_000,
    "max_quote_chars": 800,
    "max_operands": 64,
}
# 占位符词表（与 app/engine/engine.py 的 _PLACEHOLDER_* 同口径，仅取原型所需）
PLACEHOLDER_VALUES = frozenset((
    "", "-", "—", "–", "/", "none", "null", "n/a", "na", "x", "xx", "xxx",
    "待填", "待定", "待补", "待签署", "待签", "空", "无", "未填",
))
# 单位 → (量纲, 基准单位, 系数)：值 * factor = 基准值
UNIT_TABLE = {
    "℃": ("temperature", "℃", 1.0), "°c": ("temperature", "℃", 1.0),
    "摄氏度": ("temperature", "℃", 1.0),
    "℉": ("temperature", "℃", 5.0 / 9.0), "°f": ("temperature", "℃", 5.0 / 9.0),
    "华氏度": ("temperature", "℃", 5.0 / 9.0),
    "g": ("mass", "g", 1.0), "克": ("mass", "g", 1.0),
    "kg": ("mass", "g", 1000.0), "千克": ("mass", "g", 1000.0),
    "mg": ("mass", "g", 0.001),
    "ppm": ("concentration", "ppm", 1.0), "mg/kg": ("concentration", "ppm", 1.0),
    "mg·kg⁻¹": ("concentration", "ppm", 1.0),
    "h": ("time", "h", 1.0), "小时": ("time", "h", 1.0),
    "min": ("time", "h", 1.0 / 60.0), "分钟": ("time", "h", 1.0 / 60.0),
    "s": ("time", "h", 1.0 / 3600.0), "秒": ("time", "h", 1.0 / 3600.0),
}
TEMP_OFFSET_UNITS = frozenset(("℉", "°f", "华氏度"))
_NUM_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")
_DATE_RE = re.compile(r"(\d{4})\s*[-/年.]\s*(\d{1,2})\s*[-/月.]\s*(\d{1,2})")


# ================================================================ 序列化 / 摘要
def canonical_json(obj) -> str:
    """规范 JSON：sort_keys + 紧凑分隔符 + 不转义中文；证书字节复现的唯一来源。"""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_hex(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _digest(payload: dict) -> str:
    """证书摘要 = 去掉 digest 与 `_` 前缀展示元数据后的 canonical JSON 的 sha256。

    约定：以 `_` 开头的 key 是展示/分析元数据（如 golden 样例的 `_golden`），不属于
    证书正文，不参与 digest；正文任何改动都会改变 digest。
    """
    body = {k: v for k, v in payload.items() if k != "digest" and not str(k).startswith("_")}
    return "sha256:" + sha256_hex(canonical_json(body))


def stable_id(prefix: str, payload) -> str:
    return prefix + sha256_hex(canonical_json(payload))[:20]


def parse_number(text: str):
    """从引文提取第一个数值；找不到返回 None（不猜）。"""
    m = _NUM_RE.search(str(text or ""))
    return float(m.group(0)) if m else None


def parse_unit(text: str):
    """从引文提取温度/质量/浓度/时间单位；识别不到返回 ""（→ unknown → insufficient）。"""
    s = unicodedata.normalize("NFKC", str(text or "")).lower()
    # 先长后短，避免 "mg/kg" 被 "kg" 抢先；带上下标的写成归一形式
    for unit in sorted(UNIT_TABLE, key=len, reverse=True):
        u = unicodedata.normalize("NFKC", unit).lower()
        if u and u in s:
            return unit
    return ""


def to_base(value: float, unit: str):
    """单位归一。返回 (base_value, base_unit) 或 None（未知单位/量纲）。"""
    meta = UNIT_TABLE.get(str(unit or "").strip())
    if not meta:
        return None
    dim, base_unit, factor = meta
    v = float(value)
    if unit in TEMP_OFFSET_UNITS:
        return (v - 32.0) * 5.0 / 9.0, base_unit
    return v * factor, base_unit


def normalize_value(value) -> str:
    """文本一致性比较的规范形：NFKC + 去所有空白 + casefold。"""
    s = unicodedata.normalize("NFKC", str(value or ""))
    return re.sub(r"\s+", "", s).casefold()


def parse_date(text: str):
    """ISO 日期解析；非法日期返回 None（→ insufficient，不猜）。"""
    m = _DATE_RE.search(str(text or ""))
    if not m:
        return None
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if not (1 <= mo <= 12 and 1 <= d <= 31):
        return None
    try:
        import datetime
        return datetime.date(y, mo, d).isoformat()
    except Exception:
        return None


# ================================================================ 原文视图
class DocumentView:
    """原文的确定性视图：text + 可选 cell 索引（xlsx 原型用 celllines 序列化）。

    生产接入时用解析器的 canonical text + anchor(quote/char_start/char_end) 构造；
    verify 只依赖该视图，不依赖 issuer 的内存状态。
    """

    def __init__(self, text: str, *, profile: str = TEXT_PROFILE, cells=None,
                 path_hint: str = ""):
        self.text = str(text or "")
        self.profile = profile
        self.cells = dict(cells or {})  # locator -> {"text", "start", "end"}
        self.path_hint = path_hint
        self.sha256 = sha256_hex(self.text)

    def span(self, quote: str):
        """逐字定位；返回 (start, end)，找不到 (-1, -1)。不做模糊匹配。"""
        q = str(quote or "")
        if not q:
            return -1, -1
        idx = self.text.find(q)
        return (idx, idx + len(q)) if idx >= 0 else (-1, -1)

    def cell_span(self, locator: str):
        info = self.cells.get(str(locator or ""))
        if not info:
            return None
        return info.get("start"), info.get("end")

    def cell_text(self, locator: str) -> str:
        info = self.cells.get(str(locator or "")) or {}
        return str(info.get("text") or "")

    def digest(self) -> dict:
        return {"sha256": self.sha256, "chars": len(self.text),
                "profile": self.profile, "path_hint": self.path_hint}


def build_cellline_document(rows) -> DocumentView:
    """xlsx celllines 序列化（原型 golden 样例用）。

    rows: iterable of (sheet, row_no, col_letter, cell_text)。按传入顺序拼成
    `## Sheet: X` 头 + `<sheet>!<col><row>\\t<text>` 行；cells 记录每个单元格的
    locator → (text, start, end)，从而任何 quote 都有可复算的字面 span。
    """
    chunks, cells, last_sheet = [], {}, None
    pos = 0
    for sheet, row_no, col, text in rows:
        if str(text or "") == "":
            continue
        if sheet != last_sheet:
            header = f"## Sheet: {sheet}\n"
            chunks.append(header)
            pos += len(header)
            last_sheet = sheet
        locator = f"{sheet}!{col}{row_no}"
        line = f"{locator}\t{text}\n"
        start = pos
        chunks.append(line)
        pos += len(line)
        cells[locator] = {"text": str(text), "start": start, "end": start + len(str(text))}
    return DocumentView("".join(chunks), profile="xlsx-celllines/v1", cells=cells)


# ================================================================ checks
CHECK_IDS = (
    "CK001_quote_verbatim",      # 引文逐字存在于原文
    "CK002_span_consistent",     # char_start/end 与引文一致
    "CK003_operands_resolved",   # 复算操作数齐全（locator + quote + value）
    "CK004_operand_sources",     # 每个操作数 quote 逐字命中且值可从 quote 复算
    "CK005_recompute",           # verifier 纯函数可执行并给出结论
    "CK006_claim_match",         # 复算结论与 finding 声称一致
    "CK007_budget",              # checks/原文/引文/操作数在预算内
    "CK008_verifier_known",      # verifier kind 已注册、确定性、0 模型
    "CK009_no_model",            # 证书生成过程无模型调用
    "CK010_inputs_bound",        # inputs_digest 存在；若给当前快照则必须一致
)


def _check(check_id: str, status: str, detail: str = "") -> dict:
    assert status in ALLOWED_STATUSES, status
    return {"check_id": check_id, "status": status, "detail": str(detail or "")}


def _aggregate(checks) -> str:
    if any(c["status"] == "fail" for c in checks):
        return "fail"
    if any(c["status"] == "insufficient" for c in checks):
        return "insufficient"
    return "pass"


def _budget_checks(document: DocumentView, quote: str, operands, budget) -> list:
    out = []
    b = dict(DEFAULT_BUDGET)
    b.update(budget or {})
    problems = []
    if len(document.text) > int(b["max_document_chars"]):
        problems.append(f"document_chars={len(document.text)}>{b['max_document_chars']}")
    if len(str(quote or "")) > int(b["max_quote_chars"]):
        problems.append(f"quote_chars={len(str(quote or ''))}>{b['max_quote_chars']}")
    if len(operands or []) > int(b["max_operands"]):
        problems.append(f"operands={len(operands or [])}>{b['max_operands']}")
    out.append(_check("CK007_budget", "insufficient" if problems else "pass",
                      ";".join(problems) or f"budget={b['max_checks']}checks/{b['max_quote_chars']}quote_chars"))
    return out


# ================================================================ verifier 注册表
def _result(verdict: str, recompute: dict, detail: str = "") -> dict:
    """verifier 内部统一返回：verdict ∈ claim_holds / claim_contradicted / insufficient。"""
    assert verdict in ("claim_holds", "claim_contradicted", "insufficient"), verdict
    return {"verdict": verdict, "recompute": recompute, "detail": str(detail or "")}


def _operand_value(op: dict):
    """操作数取值：优先显式 value；否则从 quote 解析。返回 (value, unit, error)。"""
    raw = op.get("value")
    if raw is not None and str(raw) != "":
        try:
            return float(raw), str(op.get("unit") or ""), ""
        except (TypeError, ValueError):
            return None, str(op.get("unit") or ""), "value_not_numeric"
    quote = str(op.get("quote") or "")
    v = parse_number(quote)
    if v is None:
        return None, str(op.get("unit") or parse_unit(quote)), "value_not_parseable"
    unit = str(op.get("unit") or parse_unit(quote))
    return v, unit, ""


def verify_numeric_limit(claim: dict, operands: dict, document: DocumentView) -> dict:
    """数值阈值（数值/时长/温度通用）：op 成立=违规（claim fail 成立）。"""
    op = str(operands.get("op") or ">=")
    items = operands.get("items") or []
    cap = operands.get("cap")
    cap_truncated = bool(operands.get("cap_truncated"))
    if cap_truncated or (cap not in (None, "") and len(items) > int(cap)):
        return _result("insufficient", {
            "kind": "numeric_limit", "op": op, "cap": cap, "instances": len(items),
            "cap_truncated": True,
            "formula": "instances > cap => coverage incomplete => insufficient (unknown->insufficient)",
        }, f"实例数 {len(items)} 超 cap={cap}，覆盖不完整，不得认证")
    limit = operands.get("limit") or {}
    lim_v, lim_u = limit.get("value"), str(limit.get("unit") or "")
    lim_norm = to_base(float(lim_v), lim_u) if lim_v is not None and lim_u else (float(lim_v), lim_u) if lim_v is not None else None
    rows, violations, compared, missing = [], [], 0, 0
    for it in items:
        v, u, err = _operand_value(it)
        norm = to_base(v, u) if v is not None and u else None
        row = {"label": it.get("label") or it.get("locator") or "", "locator": it.get("locator") or "",
               "value": v, "unit": u, "raw_quote": str(it.get("quote") or "")[:200]}
        if norm is None or lim_norm is None:
            missing += 1
            row.update({"base_value": None, "base_unit": "", "verdict": "insufficient", "error": err or "unit_unknown"})
            rows.append(row)
            continue
        if norm[1] != lim_norm[1]:
            missing += 1
            row.update({"base_value": norm[0], "base_unit": norm[1], "verdict": "insufficient",
                        "error": f"dimension_mismatch:{norm[1]}!={lim_norm[1]}"})
            rows.append(row)
            continue
        compared += 1
        a, l = norm[0], lim_norm[0]
        ok = {">=": a >= l, ">": a > l, "<=": a <= l, "<": a < l, "==": a == l}.get(op)
        if ok is None:
            return _result("insufficient", {"kind": "numeric_limit", "reason": "unknown_op", "op": op, "rows": rows},
                           f"未知算子 {op}")
        violated = not ok
        if violated:
            violations.append(row)
        row.update({"base_value": a, "base_unit": norm[1], "limit_base": l,
                    "violated": violated, "verdict": "violated" if violated else "satisfied"})
        rows.append(row)
    recompute = {"kind": "numeric_limit", "op": op,
                 "limit": {"value": lim_v, "unit": lim_u, "base": list(lim_norm) if lim_norm else None},
                 "rows": rows, "compared": compared, "violations": len(violations), "missing": missing,
                 "formula": "for each item: normalized_value(actual) <op> limit"}
    if violations:
        return _result("claim_holds", recompute, f"{len(violations)}/{compared} 个实例违反阈值")
    if missing or compared == 0:
        return _result("insufficient", recompute, "无可比实例或单位/量纲未知（unknown→insufficient）")
    return _result("claim_contradicted", recompute, "全部实例满足阈值，与 finding 的 fail 声称矛盾")


def verify_unit_consistency(claim: dict, operands: dict, document: DocumentView) -> dict:
    """单位一致性：同一量的两个观测（如设计总重 360kg vs 分项和 389g）归一后不相等→claim 成立。"""
    a = operands.get("actual") or {}
    e = operands.get("expected") or {}
    av, au, aerr = _operand_value(a)
    ev, eu, eerr = _operand_value(e)
    an = to_base(av, au) if av is not None and au else None
    en = to_base(ev, eu) if ev is not None and eu else None
    recompute = {"kind": "unit_consistency", "actual": {"value": av, "unit": au, "base": list(an) if an else None},
                 "expected": {"value": ev, "unit": eu, "base": list(en) if en else None},
                 "formula": "normalize(actual) == normalize(expected) ? contradiction : claim_holds"}
    if an is None or en is None:
        return _result("insufficient", recompute, f"单位无法归一（{aerr or au}/{eerr or eu}）")
    if an[1] != en[1]:
        return _result("insufficient", recompute, f"量纲不同：{an[1]} vs {en[1]}")
    tol = float(operands.get("tolerance_pct") or 0.0) / 100.0
    diff = abs(an[0] - en[0])
    rel = diff / max(abs(en[0]), 1e-12)
    recompute.update({"base_diff": diff, "rel_diff": rel, "tolerance_pct": tol * 100})
    if rel > tol:
        return _result("claim_holds", recompute, f"归一后差 {diff:g}{an[1]}（相对 {rel:.2%}）")
    return _result("claim_contradicted", recompute, "归一后两值在容差内相等，与 fail 声称矛盾")


def verify_consistency(claim: dict, operands: dict, document: DocumentView) -> dict:
    """跨位置取值一致性（产品名称/数量/版本号等）：去重后 >1 即不一致。"""
    values = operands.get("values") or []
    normed, rows = {}, []
    for v in values:
        raw = v.get("value")
        if raw is None or str(raw) == "":
            raw = str(v.get("quote") or "")
        n = normalize_value(raw)
        rows.append({"label": v.get("label") or v.get("locator") or "", "locator": v.get("locator") or "",
                     "value": str(raw), "normalized": n, "quote": str(v.get("quote") or "")[:200]})
        if n:
            normed.setdefault(n, []).append(rows[-1]["label"])
    recompute = {"kind": "consistency", "distinct": len(normed), "n_values": len(rows),
                 "groups": [{"value": k, "count": len(vs), "refs": vs} for k, vs in normed.items()],
                 "rows": rows, "formula": "distinct(normalize(values)) > 1 => inconsistent"}
    if len(normed) >= 2:
        return _result("claim_holds", recompute, f"{len(normed)} 个不同取值，跨位置不一致")
    if len(normed) == 1 and len(rows) >= 2:
        return _result("claim_contradicted", recompute, "所有位置取值一致，与 fail 声称矛盾")
    return _result("insufficient", recompute, "可比较位置不足或取值缺失（unknown→insufficient）")


def verify_date_order(claim: dict, operands: dict, document: DocumentView) -> dict:
    """日期时序：earlier 必须 <= later；违反则 claim 成立。"""
    pairs = operands.get("pairs") or []
    rows, violations, missing = [], 0, 0
    for p in pairs:
        a = parse_date(str(p.get("earlier") or p.get("earlier_quote") or ""))
        b = parse_date(str(p.get("later") or p.get("later_quote") or ""))
        row = {"earlier_label": p.get("earlier_label") or "", "later_label": p.get("later_label") or "",
               "earlier": a, "later": b}
        if not a or not b:
            missing += 1
            row["verdict"] = "insufficient"
        else:
            row["violated"] = a > b
            row["verdict"] = "violated" if row["violated"] else "ok"
            violations += 1 if row["violated"] else 0
        rows.append(row)
    recompute = {"kind": "date_order", "rows": rows, "violations": violations, "missing": missing,
                 "formula": "parse_date(earlier) <= parse_date(later) ? ok : violated"}
    if violations:
        return _result("claim_holds", recompute, f"{violations} 对日期倒挂")
    if missing or not rows:
        return _result("insufficient", recompute, "日期缺失/不可解析（unknown→insufficient）")
    return _result("claim_contradicted", recompute, "日期链成立，与 fail 声称矛盾")


def verify_placeholder(claim: dict, operands: dict, document: DocumentView) -> dict:
    """占位符判定：值归一后属于占位符词表则 claim 成立。"""
    v = str(operands.get("value") or "")
    norm = normalize_value(v)
    is_ph = norm in PLACEHOLDER_VALUES or norm.strip("x*＊×") == ""
    recompute = {"kind": "placeholder", "value": v, "normalized": norm,
                 "placeholder_set": sorted(PLACEHOLDER_VALUES), "is_placeholder": is_ph,
                 "formula": "normalize(value) in placeholder_set"}
    if is_ph:
        return _result("claim_holds", recompute, "值为占位符/空")
    return _result("claim_contradicted", recompute, "值为有效值，与 fail 声称矛盾")


def verify_sequence_contiguous(claim: dict, operands: dict, document: DocumentView) -> dict:
    """序号连续性：整数序列出现缺口/重复则 claim 成立。"""
    values = operands.get("values") or []
    seq = []
    for v in values:
        raw = v.get("value")
        if raw is None or str(raw) == "":
            # 显式缺失位（如 A11 空）由 issuer 标 missing=True
            if v.get("missing"):
                seq.append(None)
            continue
        try:
            seq.append(int(float(str(raw))))
        except (TypeError, ValueError):
            return _result("insufficient", {"kind": "sequence_contiguous", "values": values},
                           f"序号不可解析：{raw!r}")
    present = [x for x in seq if x is not None]
    gaps, missing_positions = [], [i for i, x in enumerate(seq) if x is None]
    for i in range(1, len(present)):
        if present[i] != present[i - 1] + 1:
            gaps.append({"prev": present[i - 1], "next": present[i]})
    recompute = {"kind": "sequence_contiguous", "seq": seq, "present": present,
                 "gaps": gaps, "missing_positions": missing_positions,
                 "formula": "all(i,seq[i+1]-seq[i]==1) and no empty cell"}
    if gaps or missing_positions:
        return _result("claim_holds", recompute, f"缺口 {len(gaps)} 处、空位 {len(missing_positions)} 处")
    if len(present) < 2:
        return _result("insufficient", recompute, "序列长度不足（unknown→insufficient）")
    return _result("claim_contradicted", recompute, "序号连续，与 fail 声称矛盾")


def verify_weight_sum(claim: dict, operands: dict, document: DocumentView) -> dict:
    """分项和 vs 声明总重（容差内一致则矛盾）。"""
    parts, total, total_unit = [], 0.0, ""
    for p in operands.get("parts") or []:
        v, u, err = _operand_value(p)
        norm = to_base(v, u) if v is not None and u else None
        if norm is None:
            return _result("insufficient", {"kind": "weight_sum", "parts": parts, "reason": "part_unknown"},
                           f"分项单位未知：{p.get('label')} {u}")
        total += norm[0]
        total_unit = norm[1]
        parts.append({"label": p.get("label") or p.get("locator") or "", "value": v, "unit": u,
                      "base_value": norm[0], "locator": p.get("locator") or ""})
    declared = operands.get("declared") or {}
    dv, du, derr = _operand_value(declared)
    dn = to_base(dv, du) if dv is not None and du else None
    recompute = {"kind": "weight_sum", "parts": parts, "parts_sum_base": total, "base_unit": total_unit,
                 "declared": {"value": dv, "unit": du, "base": list(dn) if dn else None},
                 "formula": "abs(sum(parts) - declared) / declared > tolerance"}
    if dn is None:
        return _result("insufficient", recompute, "声明总重单位未知/缺失（unknown→insufficient）")
    tol = float(operands.get("tolerance_pct") or 0.0) / 100.0
    diff = abs(total - dn[0])
    rel = diff / max(abs(dn[0]), 1e-12)
    recompute.update({"base_diff": diff, "rel_diff": rel, "tolerance_pct": tol * 100})
    if rel > tol:
        return _result("claim_holds", recompute, f"分项和 {total:g}{total_unit} vs 声明 {dn[0]:g}{dn[1]}（差 {rel:.1%}）")
    return _result("claim_contradicted", recompute, "分项和与声明总重在容差内一致，与 fail 声称矛盾")


def verify_required_term_absent(claim: dict, operands: dict, document: DocumentView) -> dict:
    """必要要素缺失：target 行文本中 required_terms 全部不出现 → claim 成立。"""
    items = operands.get("items") or []
    terms = [str(t) for t in (operands.get("required_terms") or [])]
    if not terms:
        return _result("insufficient", {"kind": "required_term_absent", "reason": "no_required_terms"}, "未声明必要要素")
    hits, rows = [], []
    for it in items:
        txt = str(it.get("quote") or it.get("value") or "")
        found = [t for t in terms if t in txt]
        rows.append({"label": it.get("label") or it.get("locator") or "",
                     "locator": it.get("locator") or "", "text": txt[:200], "found_terms": found})
        hits.extend(found)
    recompute = {"kind": "required_term_absent", "required_terms": terms, "rows": rows,
                 "found": sorted(set(hits)), "formula": "none(required_terms in any(row.text))"}
    if not rows:
        return _result("insufficient", recompute, "无可用证据行（unknown→insufficient）")
    if not hits:
        return _result("claim_holds", recompute, "必要要素在证据行中全部缺失")
    return _result("claim_contradicted", recompute, f"必要要素出现：{sorted(set(hits))}")


def verify_evidence_presence(claim: dict, operands: dict, document: DocumentView) -> dict:
    """证据充分性判定：要求字段/单元格缺失时 fail 声称不可证 → insufficient（不得 pass）。"""
    required = operands.get("required") or []
    present = []
    for req in required:
        locator = str((req or {}).get("locator") or "")
        quote = str((req or {}).get("quote") or "")
        if (quote and quote in document.text) or (locator and document.cell_text(locator)):
            present.append(locator or quote)
    recompute = {"kind": "evidence_presence", "required": required, "present": present,
                 "missing": [r for r in required if (r.get("locator") or r.get("quote")) not in present],
                 "formula": "all required evidence present ? claim certifiable : insufficient"}
    if present and len(present) == len(required):
        return _result("claim_holds", recompute, "所需证据齐备")
    return _result("insufficient", recompute, "所需证据缺失；证据不足的 fail 不得认证（→insufficient）")


VERIFIERS = {
    "numeric_limit": verify_numeric_limit,
    "unit_consistency": verify_unit_consistency,
    "consistency": verify_consistency,
    "date_order": verify_date_order,
    "placeholder": verify_placeholder,
    "sequence_contiguous": verify_sequence_contiguous,
    "weight_sum": verify_weight_sum,
    "required_term_absent": verify_required_term_absent,
    "evidence_presence": verify_evidence_presence,
}


# ================================================================ issue
def _input_digest(document: DocumentView, finding: dict, verifier_kind: str,
                  inputs: dict | None) -> str:
    """inputs_digest：把「原文+规则版本+verifier 版本+策略快照」绑成一张 sha256。

    接入 L53 run_snapshot_v3 时 inputs["snapshot"] 至少含
    {schema_version, content_fingerprint, parser_version, engine_mode, switch_values}。
    """
    payload = {
        "schema_version": SCHEMA_VERSION,
        "document_sha256": document.sha256,
        "verifier": {"kind": verifier_kind, "version": VERIFIER_VERSION},
        "finding": {"finding_id": finding.get("finding_id") or finding.get("id") or "",
                    "rule_code": finding.get("rule_code") or "",
                    "rule_version_sha": finding.get("rule_version_sha") or ""},
        "inputs": inputs or {},
    }
    return "sha256:" + sha256_hex(canonical_json(payload))


def issue_certificate(finding: dict, document: DocumentView, verifier_kind: str,
                      operands: dict, *, inputs: dict | None = None,
                      quote: str = "", issued_at: str = "",
                      budget: dict | None = None, context: dict | None = None,
                      anchor_span=None) -> dict:
    """为一条 finding 签发证书（纯函数；同输入 + 同 issued_at → 字节完全一致）。

    finding 至少含：finding_id/rule_code/rule_version_sha/claimed_state(默认 fail)。
    返回证书 dict；不抛异常给主链——异常会转成 status=insufficient 的证书（fail-closed）。
    """
    ctx = dict(context or {})
    fid = str(finding.get("finding_id") or finding.get("id") or "")
    rule_code = str(finding.get("rule_code") or "")
    claimed = str(finding.get("claimed_state") or finding.get("state") or "fail")
    q = str(quote or finding.get("quote") or "")
    checks = []

    # CK001/002：引文与 span。生产入口可传 anchor_span（L71 回填的 locator 消歧 span）：
    # 仅当 text[cs:ce]==quote 时采用，否则回退全文首个逐字命中（与原型一致，不猜）。
    start, end = document.span(q)
    _a = anchor_span if isinstance(anchor_span, (tuple, list)) else None
    _span_source = "first_occurrence"
    if _a is not None and len(_a) == 2:
        try:
            _acs, _ace = int(_a[0]), int(_a[1])
            if _acs >= 0 and _ace > _acs and document.text[_acs:_ace] == q:
                start, end = _acs, _ace
                _span_source = "anchor"
        except (TypeError, ValueError):
            logging.getLogger(__name__).debug("non-fatal exception", exc_info=True)
    if not q:
        checks.append(_check("CK001_quote_verbatim", "insufficient", "quote_missing"))
        checks.append(_check("CK002_span_consistent", "insufficient", "quote_missing"))
    elif start < 0:
        checks.append(_check("CK001_quote_verbatim", "insufficient", "quote_not_in_document"))
        checks.append(_check("CK002_span_consistent", "insufficient", "quote_not_in_document"))
    else:
        checks.append(_check("CK001_quote_verbatim", "pass", f"quote@{start}:{end}"))
        checks.append(_check("CK002_span_consistent", "pass",
                             f"span_matches_quote:{_span_source}"))

    # CK008：verifier 已知/确定性；CK009：0 模型
    fn = VERIFIERS.get(str(verifier_kind or ""))
    if fn is None:
        checks.append(_check("CK008_verifier_known", "insufficient", f"unknown_verifier:{verifier_kind}"))
        recompute = {"kind": str(verifier_kind or ""), "reason": "unknown_verifier",
                     "operands": dict(operands or {})}
        status_reason, verdict = "insufficient", "insufficient"
    else:
        checks.append(_check("CK008_verifier_known", "pass",
                             f"{verifier_kind}@{VERIFIER_VERSION}; deterministic; model_calls=0"))
        checks.append(_check("CK009_no_model", "pass", "kernel 无模型/网络依赖"))
        try:
            res = fn({"state": claimed, "rule_code": rule_code, "finding_id": fid}, dict(operands or {}), document)
            verdict = res["verdict"]
            recompute = {"kind": str(verifier_kind), "operands": dict(operands or {}),
                         "result": res["recompute"], "verdict": res["verdict"]}
            detail = res.get("detail", "")
            checks.append(_check("CK005_recompute", "pass", detail))
        except Exception as exc:  # noqa: BLE001 - 原型内任何异常都不得静默 pass
            verdict, recompute = "insufficient", {"kind": str(verifier_kind), "error": f"{type(exc).__name__}: {exc}"}
            checks.append(_check("CK005_recompute", "insufficient", f"verifier_error:{type(exc).__name__}"))
        status_reason = {"claim_holds": "claim_holds", "claim_contradicted": "claim_contradicted",
                         "insufficient": "recompute_insufficient"}[verdict]

    # CK003/004：操作数齐全 & 每个操作数 quote 逐字命中 + 值可复算
    ops = operands or {}
    flat = []
    for key in ("items", "values", "parts"):
        flat.extend(ops.get(key) or [])
    for key in ("actual", "expected", "declared"):
        if isinstance(ops.get(key), dict):
            flat.append(ops[key])
    resolved, source_refs, problems = 0, [], []
    for i, op in enumerate(flat):
        loc = str((op or {}).get("locator") or "")
        oq = str((op or {}).get("quote") or "")
        if (op or {}).get("missing"):
            continue  # 显式缺失位（序号空位）不是证据，由 verifier 作为结构信息使用
        if not loc and not oq:
            continue
        s, e = document.span(oq) if oq else (-1, -1)
        if not oq or s < 0:
            problems.append(f"operand#{i}:quote_not_in_document")
            continue
        val = parse_number(oq)
        unit = str((op or {}).get("unit") or parse_unit(oq))
        ref = {"ref_id": f"R{i + 1}", "locator": loc or f"quote@{s}", "quote": oq,
               "char_start": s, "char_end": e}
        if loc and document.cell_text(loc):
            ref["cell_text"] = document.cell_text(loc)
        source_refs.append(ref)
        if val is not None:
            resolved += 1
    if problems:
        checks.append(_check("CK003_operands_resolved", "insufficient", ";".join(problems[:4])))
        checks.append(_check("CK004_operand_sources", "insufficient", ";".join(problems[:4])))
    elif flat:
        checks.append(_check("CK003_operands_resolved", "pass", f"{resolved}/{len(flat)} operands resolved"))
        checks.append(_check("CK004_operand_sources", "pass", f"{len(source_refs)} source_refs verbatim"))
    else:
        # 纯证据类 verifier 允许无操作数（quote 本身即证据）
        checks.append(_check("CK003_operands_resolved", "pass", "no_operands_required"))
        checks.append(_check("CK004_operand_sources", "pass", "no_operands_required"))

    # CK006：复算结论与 finding 声称一致
    if claimed == "fail":
        claim_ok = (verdict == "claim_holds")
        if verdict == "claim_contradicted":
            checks.append(_check("CK006_claim_match", "fail", "recompute 与 fail 声称矛盾"))
        elif verdict == "insufficient":
            checks.append(_check("CK006_claim_match", "insufficient", "复算不确定（unknown→insufficient）"))
        else:
            checks.append(_check("CK006_claim_match", "pass", "复算确认 fail 声称"))
    else:
        claim_ok = True
        checks.append(_check("CK006_claim_match", "pass", f"claimed_state={claimed} 不要求证书确认 fail"))

    # CK007 预算
    checks.extend(_budget_checks(document, q, flat, budget))

    # CK010 输入绑定
    inputs_digest = _input_digest(document, finding, str(verifier_kind or ""), inputs)
    cur = (context or {}).get("current_inputs_digest") or ""
    if cur and cur != inputs_digest:
        checks.append(_check("CK010_inputs_bound", "insufficient", "inputs_digest_mismatch"))
    else:
        checks.append(_check("CK010_inputs_bound", "pass", inputs_digest[:23]))

    checks.sort(key=lambda c: CHECK_IDS.index(c["check_id"]))
    status = _aggregate(checks)
    # 状态由 checks 决定；verdict 只作为 reason 明细（fail 来源可区分矛盾/篡改）
    if status == "pass" and not claim_ok:
        status = "insufficient"
    if status == "insufficient":
        _ck = {c["check_id"]: c for c in checks}
        if _ck.get("CK001_quote_verbatim", {}).get("status") == "insufficient":
            status_reason = str(_ck["CK001_quote_verbatim"].get("detail") or "quote_missing")
        elif any(c["status"] == "insufficient" and c["check_id"] in
                 ("CK003_operands_resolved", "CK004_operand_sources") for c in checks):
            status_reason = "operand_evidence_insufficient"
        elif verdict == "claim_contradicted":
            status_reason = "claim_contradicted"
    payload = {
        "schema_version": SCHEMA_VERSION,
        "certificate_id": "",  # 由下方 digest 回填
        "finding_id": fid,
        "rule_code": rule_code,
        "rule_version_sha": str(finding.get("rule_version_sha") or ""),
        "claim": {"state": claimed, "severity": str(finding.get("severity") or ""),
                  "result_id": str(finding.get("result_id") or ""),
                  "manifest_id": str(finding.get("manifest_id") or ""),
                  "manifest_hash": str(finding.get("manifest_hash") or "")},
        "quote": q, "char_start": start, "char_end": end,
        "quote_sha256": sha256_hex(q) if q else "",
        "text_profile": document.profile,
        "document": document.digest(),
        "source_refs": source_refs,
        "verifier": {"kind": str(verifier_kind or ""), "version": VERIFIER_VERSION,
                     "deterministic": True, "model_calls": 0},
        "recompute": recompute,
        "checks": checks,
        "status": status,
        "status_reason": status_reason,
        "issued_at": str(issued_at or (inputs or {}).get("issued_at") or ""),
        "inputs": dict(inputs or {}),
        "inputs_digest": inputs_digest,
        "context": {"engine": ctx.get("engine") or "prototype",
                    "note": "prototype certificate; no signature/hash-chain yet"},
    }
    _id_body = {k: v for k, v in payload.items()
                if k not in ("certificate_id", "digest") and not str(k).startswith("_")}
    payload["certificate_id"] = "cert-" + sha256_hex(canonical_json(_id_body))[:20]
    payload["digest"] = _digest(payload)
    return payload


# ================================================================ 生产便捷入口
def document_from_text(text: str, *, profile: str = "deepparse-canonical/v1",
                       cells=None, path_hint: str = "") -> DocumentView:
    """由解析器 canonical text 构造确定性原文视图（生产签发入口使用）。"""
    return DocumentView(text, profile=profile, cells=cells, path_hint=path_hint)


def compute_inputs_digest(document: DocumentView, finding: dict, verifier_kind: str,
                          inputs: dict | None = None) -> str:
    """inputs_digest 公开入口：原文 sha + 规则版本 + verifier 版本 + 快照/开关。"""
    return _input_digest(document, finding, str(verifier_kind or ""), inputs)


def issue_evidence_certificate(finding: dict, document: DocumentView, *,
                               quote: str = "", locator: str = "",
                               inputs: dict | None = None, issued_at: str = "",
                               anchor_span=None, context: dict | None = None) -> dict:
    """证据型证书：只证明 quote/span 逐字存在（无 recompute），语义类 finding 的诚实形态。

    `evidence_presence` verifier 要求 required 证据齐备 → claim_holds；缺失 → insufficient。
    本函数不把“证据存在”伪装成“数值复算通过”。
    """
    q = str(quote or "")
    operands = {"required": [{"locator": str(locator or ""), "quote": q}]}
    return issue_certificate(finding, document, EVIDENCE_CERT_KIND, operands,
                             inputs=inputs, quote=q, issued_at=issued_at,
                             anchor_span=anchor_span, context=context)


# ================================================================ 独立 checker
def verify_certificate(cert: dict, document: DocumentView, *,
                       current_inputs: dict | None = None,
                       current_inputs_digest: str = "") -> dict:
    """独立重算证书：只信任 证书 + 原文（+ 可选当前快照），不信任 issuer。

    返回 {valid, status(重算), stored_status, mismatches[], checks[], recomputed}。
    - 摘要不符 → valid=False, mismatch=digest_mismatch（篡改）
    - 引文/操作数被篡改（即使重算了摘要）→ CK001/CK004 fail 或复算结论与 status 矛盾
    - 当前快照 inputs_digest 不一致 → stale（valid=False, mismatch=inputs_digest_mismatch）
    """
    mismatches = []
    cert = dict(cert or {})
    if not cert:
        return {"valid": False, "status": "insufficient", "stored_status": "",
                "mismatches": ["empty_certificate"], "checks": [], "recomputed": {}}
    # 1) 摘要
    stored = str(cert.get("digest") or "")
    if stored != _digest(cert):
        mismatches.append("digest_mismatch")
    # 2) schema/verifier 版本
    checks = []
    if cert.get("schema_version") != SCHEMA_VERSION:
        checks.append(_check("CK008_verifier_known", "fail", f"schema_version={cert.get('schema_version')}"))
        mismatches.append("schema_version_unsupported")
    kind = str((cert.get("verifier") or {}).get("kind") or "")
    fn = VERIFIERS.get(kind)
    if fn is None:
        checks.append(_check("CK008_verifier_known", "fail", f"unknown_verifier:{kind}"))
        mismatches.append("unknown_verifier")
    # 3) 原文与引文。区分「引文不存在（证据缺失）」与「引文/span 被篡改」：
    #    * 引文在本证书里不存在 → 该证书不可能是 pass；若 issuer 也标 insufficient，则证书
    #      本身完整（valid 用于表达"证书是否可被独立采信"）。
    #    * 引文存在但 span 不一致 / source_ref 被改 → 篡改，integrity 失败。
    quote = str(cert.get("quote") or "")
    s, e = document.span(quote)
    q_ok = bool(quote) and s >= 0
    integrity_bad = []
    if not q_ok:
        mismatches.append("quote_not_in_document")
        checks.append(_check("CK001_quote_verbatim", "fail", "quote_not_in_document"))
        checks.append(_check("CK002_span_consistent", "insufficient", "quote_missing"))
    else:
        try:
            _cs = int(cert.get("char_start", -1))
            _ce = int(cert.get("char_end", -1))
        except (TypeError, ValueError):
            _cs, _ce = -1, -1
        # span 合法判据：等于全文首个逐字命中；或是另一处逐字命中（生产 anchor_span，
        # 仅当原文该区间严格等于 quote 时接受——不猜、不做模糊匹配）。
        span_ok = (_cs == s and _ce == e)
        if not span_ok and _cs >= 0 and _ce > _cs and _ce <= len(document.text) \
                and document.text[_cs:_ce] == quote:
            span_ok = True
        checks.append(_check("CK001_quote_verbatim", "pass", f"quote@{s}:{e}"))
        checks.append(_check("CK002_span_consistent", "pass" if span_ok else "fail",
                             "span_matches_quote" if span_ok else "span_mismatch"))
        if not span_ok:
            integrity_bad.append("span_tampered")
            mismatches.append("span_tampered")
    # 4) source_refs 逐字/span
    refs_ok = True
    for ref in cert.get("source_refs") or []:
        rq = str((ref or {}).get("quote") or "")
        rs, re_ = document.span(rq) if rq else (-1, -1)
        if rs < 0:
            refs_ok = False
            mismatches.append(f"source_ref_not_in_document:{ref.get('ref_id')}")
            if integrity_bad or str(cert.get("status")) != "insufficient":
                integrity_bad.append("source_ref_tampered")
            break
        try:
            _rcs, _rce = int(ref.get("char_start", -1)), int(ref.get("char_end", -1))
        except (TypeError, ValueError):
            _rcs, _rce = -1, -1
        _ref_span_ok = (_rcs == rs and _rce == re_)
        if not _ref_span_ok and _rcs >= 0 and _rce > _rcs and _rce <= len(document.text) \
                and document.text[_rcs:_rce] == rq:
            _ref_span_ok = True
        if not _ref_span_ok:
            refs_ok = False
            integrity_bad.append("source_ref_span_tampered")
            mismatches.append(f"source_ref_span_tampered:{ref.get('ref_id')}")
            break
    checks.append(_check("CK004_operand_sources", "pass" if refs_ok else "fail",
                         "source_refs_verbatim" if refs_ok else "source_ref_mismatch"))
    # 5) 独立重算：只用证书里的 operands + 原文（不信任 issuer 的 result）
    recomputed = {}
    status = "insufficient"
    stored_rec = cert.get("recompute") or {}
    operands = stored_rec.get("operands") or {}
    if fn is not None and q_ok:
        try:
            res = fn(cert.get("claim") or {}, operands, document)
            recomputed = res
            if stored_rec.get("kind") != res.get("recompute", {}).get("kind"):
                integrity_bad.append("recompute_kind_mismatch")
                mismatches.append("recompute_kind_mismatch")
            status = {"claim_holds": "pass", "claim_contradicted": "fail",
                      "insufficient": "insufficient"}[res["verdict"]]
        except Exception as exc:  # noqa: BLE001
            mismatches.append(f"recompute_error:{type(exc).__name__}")
            status = "insufficient"
    if not q_ok:
        status = "insufficient"  # 无逐字引文 → 任何证书都只能 insufficient
    if status != str(cert.get("status") or ""):
        mismatches.append("status_mismatch")
        integrity_bad.append("status_mismatch")
    # 6) 输入绑定（若给出当前快照）
    if current_inputs is not None:
        want = _input_digest(document, {"finding_id": cert.get("finding_id"),
                                        "rule_code": cert.get("rule_code"),
                                        "rule_version_sha": cert.get("rule_version_sha")},
                             str((cert.get("verifier") or {}).get("kind") or ""), current_inputs)
        if want != str(cert.get("inputs_digest") or ""):
            mismatches.append("inputs_digest_mismatch")
            status = "insufficient"
    if current_inputs_digest and current_inputs_digest != str(cert.get("inputs_digest") or ""):
        mismatches.append("inputs_digest_mismatch")
        status = "insufficient"
    # 引文不存在/证据缺失类 mismatch 在「issuer 也标 insufficient」时不算篡改；
    # 其余（摘要/span/source_ref/status/schema 不一致）都使证书不可采信。
    valid = not integrity_bad and not mismatches if str(cert.get("status")) != "insufficient" else not integrity_bad
    usable = valid and status == "pass" and str(cert.get("status")) == "pass" and q_ok
    return {"valid": valid, "usable": usable, "status": status,
            "stored_status": str(cert.get("status") or ""),
            "mismatches": mismatches, "checks": checks, "recomputed": recomputed}


# ================================================================ 报告门禁
def gate_report(findings, certificates, *, mode: str = "strict",
                current_inputs_digest: str = "") -> dict:
    """报告签发门禁（原型）：无证书 / 证书 fail / insufficient / 输入漂移 的 fail finding 一律阻断。

    mode="strict"：阻断 + 给出降级建议；"advisory"：只给 reason 不改变 ok（原型期）。
    返回 {ok, reasons[{code,message}], accepted[], downgraded[], blocked[], stats}。
    """
    assert mode in ("strict", "advisory"), mode
    certs = {str((c or {}).get("finding_id") or ""): c for c in (certificates or [])}
    reasons, accepted, downgraded, blocked = [], [], [], []
    stats = {"fail_findings": 0, "certified_pass": 0, "missing": 0,
             "cert_failed": 0, "cert_insufficient": 0, "stale": 0, "non_fail_skipped": 0}
    for f in findings or []:
        fid = str((f or {}).get("finding_id") or (f or {}).get("id") or "")
        state = str((f or {}).get("state") or "")
        if state != "fail":
            stats["non_fail_skipped"] += 1
            continue
        stats["fail_findings"] += 1
        cert = certs.get(fid)
        if not cert:
            stats["missing"] += 1
            blocked.append(fid)
            reasons.append({"code": "certificate_missing",
                            "message": f"finding {fid}（{f.get('rule_code', '')}）为 fail 但无证书，禁止签发"})
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": "certificate_missing"})
            continue
        _cur_dig = (current_inputs_digest.get(fid, "")
                    if isinstance(current_inputs_digest, dict) else current_inputs_digest)
        if _cur_dig and str(cert.get("inputs_digest") or "") != str(_cur_dig):
            stats["stale"] += 1
            blocked.append(fid)
            reasons.append({"code": "certificate_stale",
                            "message": f"finding {fid} 的证书 inputs_digest 与当前策略快照不一致（疑似重跑/规则变更）"})
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": "certificate_stale"})
            continue
        status = str(cert.get("status") or "")
        if status == "pass":
            stats["certified_pass"] += 1
            accepted.append(fid)
        elif status == "fail":
            stats["cert_failed"] += 1
            blocked.append(fid)
            reasons.append({"code": "certificate_failed",
                            "message": f"finding {fid} 的证书复算与 fail 结论矛盾，禁止签发并降级 insufficient"})
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": "certificate_failed"})
        elif status == "insufficient":
            stats["cert_insufficient"] += 1
            blocked.append(fid)
            reasons.append({"code": "certificate_insufficient",
                            "message": f"finding {fid} 证书证据不足（unknown→insufficient），需补证/人工复核"})
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": "certificate_insufficient"})
        else:
            stats["cert_insufficient"] += 1
            blocked.append(fid)
            reasons.append({"code": "certificate_invalid", "message": f"finding {fid} 证书状态非法：{status}"})
            downgraded.append({"finding_id": fid, "from": "fail", "to": "insufficient",
                               "reason": "certificate_invalid"})
    ok = not reasons if mode == "strict" else True
    stats["blocked"] = len(blocked)
    return {"ok": ok, "mode": mode, "reasons": reasons, "accepted": accepted,
            "downgraded": downgraded, "blocked": blocked, "stats": stats}


def downgrade_findings(findings, downgrades) -> list:
    """按门禁建议把 fail finding 降级为 insufficient（保留原始 claim 供审计）。"""
    by_id = {str((d or {}).get("finding_id") or ""): d for d in (downgrades or [])}
    out = []
    for f in findings or []:
        f2 = dict(f or {})
        d = by_id.get(str(f2.get("finding_id") or f2.get("id") or ""))
        if d and str(f2.get("state")) == "fail":
            f2["claim_state_before_certificate"] = "fail"
            f2["state"] = "insufficient"
            f2["status"] = "need_evidence"
            f2["certificate_downgrade_reason"] = d.get("reason") or ""
        out.append(f2)
    return out


# ================================================================ 20 条样例
def _finding(sid: str, rule_code: str, *, state: str = "fail", severity: str = "warning",
             quote: str = "", extra: dict | None = None) -> dict:
    f = {"finding_id": f"fnd-l55-{sid}", "rule_code": rule_code, "rule_version_sha": "sha256:" + sha256_hex(rule_code + ":v1")[:32],
         "claimed_state": state, "state": state, "severity": severity, "quote": quote,
         "result_id": f"mres-l55-{sid}", "manifest_id": "man-l55-demo",
         "manifest_hash": "sha256:" + sha256_hex("manifest-demo")[:32]}
    f.update(extra or {})
    return f


def _doc(lines) -> DocumentView:
    return DocumentView("\n".join(lines))


def build_samples() -> list:
    """20 条样例：数值 5 / 单位 3 / 日期 4 / 一致性 4 / 多实例 2 / 证据缺失 2。"""
    samples = []

    def add(sid, category, title, finding, document, verifier, operands,
            expected_status, expected_reason, inputs=None):
        samples.append({
            "sample_id": sid, "category": category, "title": title,
            "finding": finding, "document": document, "verifier": verifier,
            "operands": operands, "expected_status": expected_status,
            "expected_reason": expected_reason,
            "inputs": inputs or {"snapshot": {"schema_version": "run_snapshot_v3",
                                              "content_fingerprint": "sha256:" + sha256_hex("demo-cf")[:32],
                                              "parser_version": "deepparse-2026-11-24.1",
                                              "engine_mode": "deterministic"},
                                 "switch_values": {"RULEPROOF_CERTIFICATE_KERNEL": "0"},
                                 "issued_at": "2026-11-24T10:30:00+08:00"},
        })

    # ---------------- 数值 5
    d = _doc(["焯水工序", "水沸腾后加入包菜丝计时40秒", "中心温度≥78℃出锅，每批抽测"])
    add("S01", "数值", "中心温度 78℃ < 85℃ 下限（claim 成立）",
        _finding("s01", "FOOD01-001", severity="critical", quote="中心温度≥78℃出锅，每批抽测"),
        d, "numeric_limit",
        {"op": ">=", "limit": {"value": 85, "unit": "℃"},
         "items": [{"label": "焯水蔬菜", "locator": "焯水蔬菜!L25", "quote": "中心温度≥78℃出锅，每批抽测"}]},
        "pass", "claim_holds")
    d2 = _doc(["炒制工序", "中心温度≥90℃出锅"])
    add("S02", "数值", "声称未达标但复算显示 90℃≥85℃（证书 fail=矛盾）",
        _finding("s02", "FOOD01-001", severity="critical", quote="中心温度≥90℃出锅"),
        d2, "numeric_limit",
        {"op": ">=", "limit": {"value": 85, "unit": "℃"},
         "items": [{"label": "炒制", "locator": "炒锅!L31", "quote": "中心温度≥90℃出锅"}]},
        "fail", "claim_contradicted")
    d3 = _doc(["转入暂存", "暂存温度0-8℃，最长暂存4小时", "实测暂存温度12℃"])
    add("S03", "数值", "区间规则取上限：暂存 12℃ > 8℃（claim 成立）",
        _finding("s03", "FOOD01-004", quote="实测暂存温度12℃"),
        d3, "numeric_limit",
        {"op": "<=", "limit": {"value": 8, "unit": "℃"},
         "items": [{"label": "暂存", "locator": "炒土豆丝!L35", "quote": "实测暂存温度12℃"}]},
        "pass", "claim_holds")
    d4 = _doc(["解冻 鸡胸肉提前12h放于冷藏库内解冻"])
    add("S04", "数值", "解冻 12h < 20h 下限（含时长单位，claim 成立）",
        _finding("s04", "FOOD01-005", quote="提前12h放于冷藏库内解冻"),
        d4, "numeric_limit",
        {"op": ">=", "limit": {"value": 20, "unit": "h"},
         "items": [{"label": "解冻", "locator": "肉类前处理!F23", "quote": "提前12h放于冷藏库内解冻"}]},
        "pass", "claim_holds")
    d5 = _doc(["冷却工序", "冷却至合适温度"])
    add("S05", "数值", "引文无操作数 → unknown→insufficient",
        _finding("s05", "FOOD01-003", quote="冷却至合适温度"),
        d5, "numeric_limit",
        {"op": "<=", "limit": {"value": 10, "unit": "℃"},
         "items": [{"label": "冷却", "locator": "焯水蔬菜!L29", "quote": "冷却至合适温度"}]},
        "insufficient", "recompute_insufficient")

    # ---------------- 单位 3
    d6 = _doc(["设计总重量 360.0kg", "半成品清单 分项重量合计 389g",
               "酱油饭 200g 炒卷心菜 35g 焯水玉米粒 10g 炒土豆丝 35g",
               "荷包蛋 19g 炒奥尔良鸡块 70g 热处理番茄沙司 10g 味林香甜酱 10g"])
    add("S06", "单位", "设计总重 360.0kg vs 分项和 389g（单位混淆，claim 成立）",
        _finding("s06", "FOOD05-003", quote="设计总重量 360.0kg"),
        d6, "unit_consistency",
        {"actual": {"label": "设计总重", "locator": "包装指示书!N4", "quote": "360.0kg"},
         "expected": {"label": "分项和", "locator": "包装指示书!H10", "quote": "389g"}},
        "pass", "claim_holds")
    d7 = _doc(["出锅条件", "中心温度158℉以上出锅"])
    add("S07", "单位", "158℉=70℃ < 85℃（华氏换算后 claim 成立）",
        _finding("s07", "FOOD01-001", quote="中心温度158℉以上出锅"),
        d7, "numeric_limit",
        {"op": ">=", "limit": {"value": 85, "unit": "℃"},
         "items": [{"label": "玉米粒焯水", "locator": "焯水蔬菜!L26", "quote": "中心温度158℉以上出锅"}]},
        "pass", "claim_holds")
    d8 = _doc(["消毒液浓度 200mg/kg、浸泡消毒时间 10min"])
    add("S08", "单位", "200mg/kg 等价 200ppm，声称未达标被复算反驳（证书 fail）",
        _finding("s08", "FOOD01-002", quote="消毒液浓度 200mg/kg、浸泡消毒时间 10min"),
        d8, "numeric_limit",
        {"op": ">=", "limit": {"value": 200, "unit": "ppm"},
         "items": [{"label": "消毒", "locator": "蔬菜前处理!Q26", "quote": "消毒液浓度 200mg/kg、浸泡消毒时间 10min"}]},
        "fail", "claim_contradicted")

    # ---------------- 日期 4
    d9 = _doc(["实施日期 2025-07-01", "上市日期 2025-06-01"])
    add("S09", "日期", "实施 2025-07-01 晚于上市 2025-06-01（时序倒挂 claim 成立）",
        _finding("s09", "C09-001", quote="实施日期 2025-07-01"),
        d9, "date_order",
        {"pairs": [{"earlier_label": "实施日期", "earlier": "2025-07-01",
                    "later_label": "上市日期", "later": "2025-06-01"}]},
        "pass", "claim_holds")
    d10 = _doc(["实施日期 2025-07-01", "上市日期 2025-07-21"])
    add("S10", "日期", "实施早于上市，声称倒挂被复算反驳（证书 fail）",
        _finding("s10", "C09-001", quote="实施日期 2025-07-01"),
        d10, "date_order",
        {"pairs": [{"earlier_label": "实施日期", "earlier": "2025-07-01",
                    "later_label": "上市日期", "later": "2025-07-21"}]},
        "fail", "claim_contradicted")
    d11 = _doc(["蔬菜前处理 实施日期 2025-07-01", "肉类前处理 实施日期 2025-07-01",
                "炒土豆丝 实施日期 2026-03-17"])
    add("S11", "日期", "跨 Sheet 实施日期不一致（claim 成立）",
        _finding("s11", "FOOD03-001", severity="critical", quote="炒土豆丝 实施日期 2026-03-17"),
        d11, "consistency",
        {"values": [
            {"label": "蔬菜前处理", "locator": "蔬菜前处理!C3", "value": "2025-07-01", "quote": "实施日期 2025-07-01"},
            {"label": "肉类前处理", "locator": "肉类前处理!C3", "value": "2025-07-01", "quote": "肉类前处理 实施日期 2025-07-01"},
            {"label": "炒土豆丝", "locator": "炒土豆丝!C3", "value": "2026-03-17", "quote": "炒土豆丝 实施日期 2026-03-17"}]},
        "pass", "claim_holds")
    d12 = _doc(["实施日期 2025-13-45", "上市日期 2025-07-21"])
    add("S12", "日期", "非法日期不可解析 → unknown→insufficient",
        _finding("s12", "C09-001", quote="实施日期 2025-13-45"),
        d12, "date_order",
        {"pairs": [{"earlier_label": "实施日期", "earlier": "2025-13-45",
                    "later_label": "上市日期", "later": "2025-07-21"}]},
        "insufficient", "recompute_insufficient")

    # ---------------- 一致性 4
    d13 = _doc(["蔬菜前处理 产品名称 罗森 喷香烤肉拌饭3.0", "包装指示书 产品名称 烤肉拌饭"])
    add("S13", "一致性", "产品名称全称/简称混用（claim 成立）",
        _finding("s13", "FOOD03-002", quote="包装指示书 产品名称 烤肉拌饭"),
        d13, "consistency",
        {"values": [
            {"label": "蔬菜前处理", "locator": "蔬菜前处理!N7", "value": "罗森 喷香烤肉拌饭3.0",
             "quote": "蔬菜前处理 产品名称 罗森 喷香烤肉拌饭3.0"},
            {"label": "包装指示书", "locator": "包装指示书!M2", "value": "烤肉拌饭",
             "quote": "包装指示书 产品名称 烤肉拌饭"}]},
        "pass", "claim_holds")
    d14 = _doc(["Sheet A 产品名称 罗森 喷香烤肉拌饭3.0", "Sheet B 产品名称 罗森 喷香烤肉拌饭3.0"])
    add("S14", "一致性", "名称实际一致，声称混用被复算反驳（证书 fail）",
        _finding("s14", "FOOD03-002", quote="Sheet A 产品名称 罗森 喷香烤肉拌饭3.0"),
        d14, "consistency",
        {"values": [
            {"label": "Sheet A", "locator": "A!N7", "value": "罗森 喷香烤肉拌饭3.0",
             "quote": "Sheet A 产品名称 罗森 喷香烤肉拌饭3.0"},
            {"label": "Sheet B", "locator": "B!N7", "value": "罗森 喷香烤肉拌饭3.0",
             "quote": "Sheet B 产品名称 罗森 喷香烤肉拌饭3.0"}]},
        "fail", "claim_contradicted")
    d15 = _doc(["炒卷心菜 100份用量 4302", "肉类前处理 100份用量 4302", "焯水蔬菜 100份用量 5000"])
    add("S15", "一致性", "同物料 100 份用量跨 Sheet 不一致（claim 成立）",
        _finding("s15", "D02-001", quote="焯水蔬菜 100份用量 5000"),
        d15, "consistency",
        {"values": [
            {"label": "炒卷心菜", "locator": "炒卷心菜!H15", "value": "4302", "quote": "炒卷心菜 100份用量 4302"},
            {"label": "焯水蔬菜", "locator": "焯水蔬菜!H15", "value": "5000", "quote": "焯水蔬菜 100份用量 5000"}]},
        "pass", "claim_holds")
    d16 = _doc(["单 Sheet 只有一个版本号 LHHK-C-RD-STP-649A1"])
    add("S16", "一致性", "可比较位置 <2 → unknown→insufficient",
        _finding("s16", "FOOD04-001", quote="单 Sheet 只有一个版本号 LHHK-C-RD-STP-649A1"),
        d16, "consistency",
        {"values": [{"label": "唯一位置", "locator": "A!C4", "value": "LHHK-C-RD-STP-649A1",
                     "quote": "单 Sheet 只有一个版本号 LHHK-C-RD-STP-649A1"}]},
        "insufficient", "recompute_insufficient")

    # ---------------- 多实例 2
    d17 = _doc(["焯水蔬菜 中心温度≥78℃出锅", "煎蛋 中心温度80℃"])
    add("S17", "多实例", "同码多实例 2 处均低于 85℃（claim 成立，2/2 触犯）",
        _finding("s17", "FOOD01-001", severity="critical", quote="焯水蔬菜 中心温度≥78℃出锅"),
        d17, "numeric_limit",
        {"op": ">=", "limit": {"value": 85, "unit": "℃"},
         "items": [
             {"label": "焯水蔬菜#1", "locator": "焯水蔬菜!L25", "quote": "焯水蔬菜 中心温度≥78℃出锅"},
             {"label": "煎蛋#2", "locator": "煎蛋!L32", "quote": "煎蛋 中心温度80℃"}]},
        "pass", "claim_holds")
    d18 = _doc(["实例1 中心温度78℃", "实例2 中心温度70℃", "实例3 中心温度60℃",
                "实例4 中心温度55℃", "实例5 中心温度50℃", "实例6 中心温度48℃", "实例7 中心温度45℃"])
    add("S18", "多实例", "实例数超 cap 截断 → 覆盖不完整 → insufficient",
        _finding("s18", "FOOD01-001", severity="critical", quote="实例1 中心温度78℃"),
        d18, "numeric_limit",
        {"op": ">=", "limit": {"value": 85, "unit": "℃"},
         "items": [{"label": f"实例{i}", "locator": f"Sheet!L{25 + i}", "quote": f"实例{i} 中心温度{v}℃"}
                   for i, v in enumerate([78, 70, 60, 55, 50, 48, 45], start=1)],
         "cap": 3, "cap_truncated": True},
        # cap 截断时原型判定为 insufficient（宁可转人工也不静默扩大证明范围）
        "insufficient", "recompute_insufficient")

    # ---------------- 证据缺失 2
    d19 = _doc(["焯水 水沸腾后加入包菜丝计时40秒", "中心温度≥85℃出锅"])
    add("S19", "证据缺失", "引文不在原文（篡改/失败引文）→ insufficient，绝不 pass",
        _finding("s19", "FOOD01-001", quote="中心温度≥78℃出锅，每批抽测"),
        d19, "numeric_limit",
        {"op": ">=", "limit": {"value": 85, "unit": "℃"},
         "items": [{"label": "焯水蔬菜", "locator": "焯水蔬菜!L25", "quote": "中心温度≥78℃出锅，每批抽测"}]},
        "insufficient", "quote_missing")
    d20 = _doc(["冷却 包菜丝流水冷却", "冷却终温：未填写"])
    add("S20", "证据缺失", "字段缺失导致 fail 不可证 → insufficient（缺证据不得判 fail）",
        _finding("s20", "FOOD01-003", quote="冷却终温：未填写"),
        d20, "evidence_presence",
        {"required": [{"label": "冷却终温", "locator": "焯水蔬菜!L29", "quote": ""}]},
        "insufficient", "recompute_insufficient")
    return samples


def run_samples() -> list:
    """运行 20 条样例；返回逐条结果（含 expected/actual 与证书状态）。"""
    out = []
    for s in build_samples():
        cert = issue_certificate(s["finding"], s["document"], s["verifier"],
                                 s["operands"], inputs=s["inputs"], quote=s["finding"]["quote"])
        verify = verify_certificate(cert, s["document"])
        # 确定性：同输入再签一次，canonical 字节必须一致
        cert2 = issue_certificate(s["finding"], s["document"], s["verifier"],
                                  s["operands"], inputs=s["inputs"], quote=s["finding"]["quote"])
        deterministic = canonical_json(cert) == canonical_json(cert2)
        out.append({
            "sample_id": s["sample_id"], "category": s["category"], "title": s["title"],
            "expected_status": s["expected_status"], "expected_reason": s["expected_reason"],
            "actual_status": cert["status"], "actual_reason": cert["status_reason"],
            "verifier": s["verifier"], "checks_failed": [c["check_id"] for c in cert["checks"] if c["status"] != "pass"],
            "deterministic": deterministic,
            "independent_verify": {"valid": verify["valid"], "status": verify["status"],
                                   "mismatches": verify["mismatches"]},
            "certificate_id": cert["certificate_id"], "inputs_digest": cert["inputs_digest"],
            "status_ok": cert["status"] == s["expected_status"],
        })
    return out


def summarize(rows) -> dict:
    from collections import Counter
    cats = Counter(r["category"] for r in rows)
    st = Counter(r["actual_status"] for r in rows)
    return {
        "total": len(rows),
        "by_category": dict(sorted(cats.items())),
        "by_status": dict(sorted(st.items())),
        "all_status_ok": all(r["status_ok"] for r in rows),
        "all_deterministic": all(r["deterministic"] for r in rows),
        "all_verify_valid": all(r["independent_verify"]["valid"] for r in rows),
        "passed": sum(1 for r in rows if r["status_ok"] and r["deterministic"] and r["independent_verify"]["valid"]),
    }
