"""
规则执行（限值类）：把规则库里的限值类规则（metric/op/value/unit）对文档事实执行。

事实 = 从工艺书工序文本里抽出的数值，带 sheet/row/原文引用/作用域(scope)。
作用域区分“中心温度/冷却/冷藏暂存”，避免“中心温度≥85℃”误匹配“库内温度0-8℃”。

输出五态：满足 / 不满足 / 证据不足；不满足时给出违规证据锚点。

单位等价归一（LaneQ 2026-11-23，依据 docs/qa/L2防调分母与CheckList_20261123.md §6.3）：
  - 温度：℃ / °C / 摄氏度 / 度 均识别，统一规范为 ℃（度=摄氏同义写法，不做仿射换算）；
  - 时间：小时/时 ↔ h、分钟/分 ↔ min、秒/s ↔ s、天/d ↔ 天，统一规范写法；
    h↔min 的**数值换算在判据比较层**用 time_to_hours() 完成（阈值+单位→基准单位），
    抽取层只做写法归一、不擅自缩放数值（避免抽取值与原文不可复核）。
  - 全角数字/小数/百分号：用 tools.canonical_numeric_text 逐字符 1:1 归一后再匹配，
    quote 仍取原文（可复核、可定位）。
  - 本次只补等价写法与单位识别，不改变任何既有判定语义：同单位同数值输入与旧版逐字相同。
"""
import re
import unicodedata
from dataclasses import dataclass, asdict

from .tools import canonical_numeric_text, exec_fix_v2


def _temp_scope_bind_on() -> bool:
    """温度 scope「工序+对象」绑定开关（B1-L1 T01，2026-11-23）。

    默认开；``RULEPROOF_TEMP_SCOPE_BIND=0`` 回滚旧口径（仅按关键词优先级猜 scope）。
    背景（docs/qa/食品缺陷修复_20261123.md）：旧口径把数值前 10 字里只要出现
    「暂存/冷却」就归到「冷藏暂存/冷却」判据，导致 clean 稿的
    「暂存间温度10-15℃」（环境温度）、「一级冷却水温10-15℃」（水温）被当成
    冷藏温度/冷却终温 → FOOD01-003/004 误报。
    """
    import os as _os
    return str(_os.environ.get("RULEPROOF_TEMP_SCOPE_BIND", "1")).strip().lower() \
        not in ("0", "false", "off", "no")


def _disinfect_scope_fix_on() -> bool:
    """消毒浓度「对象作用域」绑定开关（L26，2026-11-23；默认开，=0 回退旧行为）。

    背景（外部合成挑战集 L23/L25）：clean-control 100/100 份文档因
    「员工进入车间前手部消毒池有效氯浓度 50-80ppm」被「消毒浓度 ≥200ppm」判据
    判不满足（数据集规则 R-LIM-02 明确 ``excludes: 手部消毒液浓度(50-100ppm)``）。
    该判据对象是**直接接触食品的工器具/食品接触面/环境消毒液**；手部/洗手消毒液是
    人体卫生的更窄规则，不套 200ppm。本开关只做「取数对象是否属于本判据」判定，
    **不改阈值/方向比较本身**；=0 时回到旧口径（所有 ppm 一律参与阈值比较）。
    """
    import os as _os
    return str(_os.environ.get("RULEPROOF_DISINFECT_SCOPE_FIX", "1")).strip().lower() \
        not in ("0", "false", "off", "no")


# 工序环境温度词：这些是「间/库/环境」的温度，不是产品中心温度/库内冷藏温度。
# 「常温库」是原料贮存环境，不是冷藏库；「成型间/暂存间/暂存架」是工序环境量。
_TEMP_ENV_CUES = ("成型间", "暂存间", "暂存架", "常温库", "原料间", "冷却间",
                  "解冻间", "车间", "操作间", "环境温度", "室温", "室内温度")
# 水温/油温/设备介质温度：不是产品温度，也不是库温。
_TEMP_MEDIUM_CUES = ("水温", "油温", "夹套水", "冷却水", "冰水", "清洗水")


def _temp_scope(txt: str) -> str:
    """温度事实的作用域（工序+对象绑定；B1-L1 T01 修复）。

    判定优先级（先具体对象，后工序；不再只按关键词出现顺序）：
      ① 水温/油温/设备介质 → 「水温」（不属于中心温度/冷却终温/冷藏库温判据）；
      ② 明确冷藏/冷冻库温 → 「冷藏暂存」；
      ③ 工序环境温度（成型间/暂存间/暂存架/常温库/冷却间/解冻间…）→ 「环境温度」；
      ④ 解冻 → 「解冻」；⑤ 冷却 → 「冷却」；⑥ 中心温度/品温 → 「中心温度」；
      ⑦ 其他。
    开关关闭时退回旧口径（逐字保留，供回滚/对照）。
    """
    if not _temp_scope_bind_on():
        if "解冻" in txt:
            return "解冻"
        if "冷却" in txt:
            return "冷却"
        if "库内温度" in txt or "冷藏" in txt or "暂存" in txt or "冷冻" in txt:
            return "冷藏暂存"
        if "中心温度" in txt:
            return "中心温度"
        return "其他"
    t = txt or ""
    if any(k in t for k in _TEMP_MEDIUM_CUES):
        return "水温"
    # 明确冷藏/冷冻库温（「冷藏/冷冻/冷库/库内温度」是判据对象本身）。先判它，
    # 再判工序环境词（否则「常温库温度」会被裸「库温」误当冷库）；
    # 「品温」是危险宽泛词（成品温度/半成品温度会误命中），不单独作中心温度线索。
    if any(k in t for k in ("冷藏", "冷冻", "冷库", "库内温度")):
        return "冷藏暂存"
    if any(k in t for k in _TEMP_ENV_CUES):
        return "环境温度"
    # 裸「暂存/库温」仍按冷藏暂存（既有判定口径不缩小：如「暂存温度12℃」是冷藏暂存违规）；
    # 只有明确的工序环境对象（间/架/成型间/常温库……）才改判环境温度。
    if "暂存" in t or "库温" in t:
        return "冷藏暂存"
    if "解冻" in t:
        return "解冻"
    if "冷却" in t:
        return "冷却"
    if "中心温度" in t:
        return "中心温度"
    return "其他"


# ---------------------------------------------------------------- 时间对象绑定（B1-L1 T03；L26 扩展）
# 解冻时长的「取数」必须区分：解冻时长 vs 解冻后处理时限 vs 非冷藏解冻方式。
# L26（2026-11-23，外部合成挑战集 L23/L25 clean 100/100 误报根因）扩展：
#   · 补充「流动/饮用水/水浴/喷淋/冷水/冰水」等非冷藏解冻方式线索——原表只有「流动水/流水」，
#     clean 稿写「流动饮用水解冻 4-6h」时漏识别 → 被当冷藏解冻时长判 <20h（实测 100/100）；
#   · 「解冻后/解冻完成/解冻完毕 Xh 内」的窗口识别补「完毕」写法（v2-hard 用「解冻完毕后」）。
_THAW_METHOD_CUES = ("流动水", "流动", "饮用水", "流水", "水解冻", "水浴", "喷淋",
                     "冷水", "冰水", "微波", "室温", "常温", "自然解冻", "空气解冻")
_THAW_WINDOW_BEFORE_RE = re.compile(r"解冻(?:完成|结束|完毕|后)[^，。；;|｜]{0,10}$")


def _time_scope(txt: str, norm: str, m) -> str:
    """时间事实的工序语义（仅对「解冻」相关时间赋值，其余返回空串）。

    - 「解冻后/解冻完成…4h 内」= 后续工序时限（不是解冻时长，旧实现误当解冻时长判 <20h）；
    - 行文含流动水/流水/室温/常温/微波等 = 非冷藏解冻方式（≥20h 判据是否适用待业务裁决，
      packs/food.py 按「口径待定/证据不足」处理，不直接判不满足）；
    - 其余含解冻 = 「解冻」（冷藏解冻口径，按现有 ≥20h 判据执行）。
    """
    if not txt or "解冻" not in txt:
        return ""
    before = norm[max(0, m.start() - 18):m.start()]
    after = norm[m.end():m.end() + 10]
    if _THAW_WINDOW_BEFORE_RE.search(before) and ("内" in after[:5] or "之内" in after[:6]):
        return "解冻后处理时限"
    if any(k in txt for k in _THAW_METHOD_CUES):
        return "解冻-非冷藏方式"
    return "解冻"


# ---------------------------------------------------------------- 消毒对象作用域（L26）
# 手部/洗手/皮肤消毒液线索（人体卫生，不属于「工器具/环境/食品接触面消毒液 ≥200ppm」判据）。
# 只取「数值前同一单元格内 ~45 字」窗口识别，避免整行串味（同一行既有手部又有工器具时，
# 工器具数值前不含手部词 → 不会被排除）。
_HAND_DISINFECT_CUES = ("手部", "洗手", "手消毒", "手消", "手指", "手浸", "手喷",
                        "足部", "足浴", "鞋靴消毒池", "靴消毒池")


def conc_scope(text_before: str) -> str:
    """浓度事实的消毒对象作用域：``hand`` = 手部/洗手消毒液；``""`` = 其他/未识别。

    仅当 ``RULEPROOF_DISINFECT_SCOPE_FIX`` 开启时调用方才会用它过滤（见 packs/food.py
    与 ruleexec._spec_facts），本函数本身不改任何阈值比较。
    """
    win = str(text_before or "")
    if any(k in win for k in _HAND_DISINFECT_CUES):
        return "hand"
    return ""


@dataclass
class NumFact:
    metric: str          # 温度 / 时间 / 浓度
    value: float
    unit: str
    sheet: str
    row: str
    quote: str
    scope: str = ""
    # B1-L1 T03（2026-11-23）：时间事实的工序语义（解冻/解冻-非冷藏方式/解冻后处理时限）；
    # context 保留完整行文本，供下钻判据（解冻口径待定）复核，不改变既有字段语义。
    context: str = ""
    time_scope: str = ""
    # L26（2026-11-23）：浓度事实的消毒对象作用域（hand=手部/洗手消毒液；空=其他）。
    conc_scope: str = ""
    # L26：是否「每 Xh 记录/监测」类频率数值（不是解冻时长；见 _chk_thaw）。
    frequency: bool = False

    def to_dict(self):
        return asdict(self)


# ---------------------------------------------------------------- 单位等价归一
# 温度单位中文等价（规范写法 = ℃）。只做同一物理量的写法归一，不做跨量纲猜测。
_TEMP_UNIT_CANON = {"℃": "℃", "°C": "℃", "°c": "℃", "摄氏度": "℃", "度": "℃"}
# L39 ④：华氏度等价写法归一（值不变，判据层做仿射换算）。
_TEMP_UNIT_CANON_FIX2 = dict(_TEMP_UNIT_CANON)
_TEMP_UNIT_CANON_FIX2.update({"℉": "℉", "°F": "℉", "°f": "℉",
                              "华氏度": "℉", "华氏": "℉"})
# 时间单位写法归一（值不变；天/日同义 → 天，24h 换算见 _TIME_TO_HOURS）。
_TIME_UNIT_CANON = {
    "h": "h", "小时": "h", "时": "h", "hr": "h",
    "min": "min", "分钟": "min", "分": "min",
    "s": "s", "秒": "s",
    "d": "天", "天": "天", "日": "天",
}
# 判据比较层的时间基准换算：1 基准单位 = N 小时。
_TIME_TO_HOURS = {"h": 1.0, "min": 1.0 / 60.0, "s": 1.0 / 3600.0, "天": 24.0}
# 重量/体积中文等价（供解析/比较层统一量纲写法；未登记写法返回空串，不猜）。
_WEIGHT_UNIT_CANON = {
    "g": "g", "克": "g", "kg": "kg", "千克": "kg", "公斤": "kg",
    "mg": "mg", "毫克": "mg", "μg": "μg", "ug": "μg", "微克": "μg",
    "t": "t", "吨": "t",
}
_VOLUME_UNIT_CANON = {"ml": "ml", "毫升": "ml", "l": "L", "升": "L"}


def _equiv_key(u) -> str:
    """单位写法归一：NFKC（全角→半角、㎏→kg、Ⅹ→X）+ 去首尾空白。"""
    return unicodedata.normalize("NFKC", str(u if u is not None else "")).strip()


def canon_temp_unit(u) -> str:
    """温度单位 → 规范写法 ℃/℉；未知写法返回空串（不猜量纲）。"""
    s = _equiv_key(u)
    if not s:
        return ""
    _tab = _TEMP_UNIT_CANON_FIX2 if exec_fix_v2("temp_negative") else _TEMP_UNIT_CANON
    return _tab.get(s) or _tab.get(s.lower(), "")


def canon_time_unit(u) -> str:
    """时间单位 → 规范写法 h/min/s/天；未知写法返回空串（不猜量纲）。"""
    s = _equiv_key(u)
    if not s:
        return ""
    return _TIME_UNIT_CANON.get(s) or _TIME_UNIT_CANON.get(s.lower(), "")


def time_to_hours(value, unit):
    """时间值 + 单位 → 小时；单位未知/值非法返回 None（调用方按证据不足处理）。

    供判据比较层使用：阈值单位与文中单位先归一到小时再比较（h↔min↔s↔天）。
    """
    canon = canon_time_unit(unit)
    if not canon:
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    return v * _TIME_TO_HOURS[canon]


def canon_weight_unit(u) -> str:
    """重量单位 → 规范写法 g/kg/mg/μg/t；未知写法返回空串（不猜量纲）。"""
    s = _equiv_key(u)
    if not s:
        return ""
    return _WEIGHT_UNIT_CANON.get(s) or _WEIGHT_UNIT_CANON.get(s.lower(), "")


def canon_volume_unit(u) -> str:
    """体积单位 → 规范写法 ml/L；未知写法返回空串（不猜量纲）。"""
    s = _equiv_key(u)
    if not s:
        return ""
    return _VOLUME_UNIT_CANON.get(s) or _VOLUME_UNIT_CANON.get(s.lower(), "")


# “度”是摄氏的常见口语写法，但同一字也用于角度/坡度/经纬度/浓度等量纲。
# 只对明确属于这些非温度量纲的前缀做豁免，避免把“坡度30度”抽成温度事实。
_AMBIG_DIM_CUES = ("坡度", "角度", "纬度", "经度", "深度", "宽度", "高度", "长度",
                   "斜度", "硬度", "浓度", "精度", "幅度", "厚度", "直径", "半径")


def _temp_unit_ok(text: str, start: int, unit: str) -> bool:
    """温度单位“度”的量纲歧义守卫（其余单位不受影响）。"""
    if unit != "度":
        return True
    pre = text[max(0, start - 3):start]
    return not any(pre.endswith(c) for c in _AMBIG_DIM_CUES)


# 温度：先匹配范围 0-8℃（作为一个“低值”事实），再匹配单值 85℃；
# 单位补「摄氏度/度」等价写法（LaneQ 2026-11-23）。
# L39 ④：修复开启时补前导负号（−19.5℃/−19.5摄氏度/℉ 同理）；=0 回退旧正则（符号丢失）。
_TEMP_UNIT_PAT = r"(?:℃|°C|摄氏度|度)"
# L39 ④ 温度事实层：华氏度/°F/℉ 也是规则 accepted_units 内的等价温标（L2B-009/012/017/
# 018/024 因事实层只认摄氏而取不到数）；修复开启时并入同一正则，规范单位回落 ℉。
_TEMP_UNIT_PAT_FIX2 = r"(?:℃|°C|摄氏度|度|℉|°F|华氏度|华氏)"
_TEMP_RANGE = re.compile(r"(\d+(?:\.\d+)?)\s*[-~～]\s*(\d+(?:\.\d+)?)\s*(" + _TEMP_UNIT_PAT + r")")
_TEMP_SINGLE = re.compile(r"(\d+(?:\.\d+)?)\s*(" + _TEMP_UNIT_PAT + r")")
_TEMP_SIGN = r"[-]?"                               # norm 已把 −/－ 归一为 ASCII "-"
_TEMP_RANGE_FIX2 = re.compile(r"(" + _TEMP_SIGN + r"\d+(?:\.\d+)?)\s*[-~～]\s*(" + _TEMP_SIGN
                              + r"\d+(?:\.\d+)?)\s*(" + _TEMP_UNIT_PAT_FIX2 + r")")
_TEMP_SINGLE_FIX2 = re.compile(r"(" + _TEMP_SIGN + r"\d+(?:\.\d+)?)\s*("
                               + _TEMP_UNIT_PAT_FIX2 + r")")
# 时间单位补「时/分/天/d」等价写法；ASCII 单位后不得紧跟字母（避免 100hPa 被当 100h）。
_TIME = re.compile(r"(\d+(?:\.\d+)?)\s*(min|分钟|小时|时|秒|s|h|天|d|分)(?![A-Za-z])")
# L39 ⑤：千分位时长（1,800s / 2,100s）也要取到完整数值，否则事实=800s 与原文=1800s
# 两条路径结论不一致会误转证据不足。
_TIME_FIX2 = re.compile(r"(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*"
                        r"(min|分钟|小时|时|秒|s|h|天|d|分)(?![A-Za-z])")
_CONC = re.compile(r"(\d+(?:\.\d+)?)\s*(ppm|mg/kg)")
# L39 ⑨：浓度补充 ppb / μg/kg / ug/kg / g/kg（大小写不敏感），否则事实层完全取不到数。
_CONC_FIX2 = re.compile(r"(\d+(?:\.\d+)?)\s*((?i:ppm|ppb)|mg/kg|μg/kg|ug/kg|g/kg)")


def _fact_num(tok) -> float:
    """事实数值：去千分位逗号；无法解析返回 None（调用方跳过，不静默当 0）。"""
    try:
        return float(str(tok).replace(",", ""))
    except (TypeError, ValueError):
        return None


def extract_numeric_facts(process_text: dict) -> list:
    facts = []
    _fix_temp = exec_fix_v2("temp_negative")
    _fix_time = exec_fix_v2("time_scale")
    _fix_conc = exec_fix_v2("conc_scale")
    _temp_range_re = _TEMP_RANGE_FIX2 if _fix_temp else _TEMP_RANGE
    _temp_single_re = _TEMP_SINGLE_FIX2 if _fix_temp else _TEMP_SINGLE
    _time_re = _TIME_FIX2 if _fix_time else _TIME
    _conc_re = _CONC_FIX2 if _fix_conc else _CONC
    for sheet, rows in process_text.items():
        for col_a, txt, *_ in rows:
            raw = str(txt or "")
            # 逐字符 1:1 全角→半角（数字/小数/百分号/全角字母），匹配下标仍可回指原文 quote。
            norm = canonical_numeric_text(raw)
            # 温度范围/单值：作用域用「值前 10 字」上下文（动作词在值前，如 冷却至/解冻至/中心温度）
            for m in _temp_range_re.finditer(norm):
                _v = _fact_num(m.group(1))
                if _v is None or not _temp_unit_ok(norm, m.start(), m.group(3)):
                    continue
                ctx = norm[max(0, m.start() - 10): m.start()]
                facts.append(NumFact("温度", _v, canon_temp_unit(m.group(3)),
                                     sheet, col_a or "-", raw[:80], _temp_scope(ctx)))
            for m in _temp_single_re.finditer(norm):
                _vtxt = m.group(1)
                # L39 ④：负号守卫——「0-8℃ / 10-15℃ / 0 - 8℃」里的 "-" 是区间连接符，
                # 不是负号；仅当前一个非空字符不是数字/温度单位时才按负值取。
                if _fix_temp and str(_vtxt).startswith("-"):
                    _pre = norm[:m.start()].rstrip()
                    # 前一字符是数字/温标符号 → 「0-8℃」区间连接符；「温度-19.5℃」的
                    # 「度」是「温度」用字，不是单位，不能当连接符（避免把负号吃掉）。
                    _sep = bool(_pre) and (
                        _pre[-1].isdigit() or _pre[-1] in ("℃", "℉", "°", "C", "F")
                        or bool(re.search(r"\d\s*(?:℃|℉|°C|°F|度)$", _pre)))
                    if _sep:
                        _vtxt = _vtxt[1:]
                _v = _fact_num(_vtxt)
                if _v is None or not _temp_unit_ok(norm, m.start(), m.group(2)):
                    continue
                ctx = norm[max(0, m.start() - 10): m.start()]
                facts.append(NumFact("温度", _v, canon_temp_unit(m.group(2)),
                                     sheet, col_a or "-", raw[:80], _temp_scope(ctx)))
            for m in _time_re.finditer(norm):
                _v = _fact_num(m.group(1))
                if _v is None:
                    continue
                # L26：频率数值（每 4h 记录/监测）不是解冻时长，打标供判据侧排除。
                _freq = bool(re.search(r"每[^0-9]{0,3}$",
                                       norm[max(0, m.start() - 6): m.start()]))
                facts.append(NumFact("时间", _v, canon_time_unit(m.group(2)),
                                     sheet, col_a or "-", raw[:80], "",
                                     context=raw, time_scope=_time_scope(raw, norm, m),
                                     frequency=_freq))
            for m in _conc_re.finditer(norm):
                _v = _fact_num(m.group(1))
                if _v is None:
                    continue
                # L26：浓度事实带「消毒对象」作用域；窗口取「同一单元格（| 分段）内数值前 45 字」，
                # 避免同一行相邻单元格（如前面手部消毒说明 + 后面工器具浓度）互相串味。
                _before = norm[max(0, m.start() - 45): m.start()]
                if "|" in norm or "｜" in norm:
                    _st = 0
                    for _part in re.split(r"[|｜]", norm):
                        _en = _st + len(_part)
                        if _st <= m.start() < _en:
                            _s = m.start() - _st
                            _before = _part[max(0, _s - 45): _s]
                            break
                        _st = _en + 1
                facts.append(NumFact("浓度", _v, m.group(2),
                                     sheet, col_a or "-", raw[:80], "",
                                     conc_scope=conc_scope(_before)))
    return facts


# ===========================================================================
# L27 Phase0 Task 0.3（2026-11-23，0 LLM）：无 gold 跨码 Span 折叠（UI 展示层聚合）
#
# 参考实现 scripts/qa/anchor_snapping.py::cluster_findings_for_ui_folding（自测通过）。
# 目的：BX 责任上限等「同一事项被多个规则码/阈值重复计数」（DocMate 复核：39 条责任
# 上限 FP 中 87.2% 是同项重复）——在**展示层**把同一原文区间的跨码 finding 折叠为一张
# 卡片，不删除、不改写任何底层 finding，因此 TP 损失恒为 0（纯函数，无 gold、0 模型）。
# 判定依据只有 char_start/char_end（原文区间）与置信度，不做语义猜测。
# ===========================================================================
@dataclass
class FoldableFinding:
    finding_id: str
    rule_code: str
    char_start: int
    char_end: int
    confidence: float = 0.5


@dataclass
class FoldedIssueCard:
    primary_finding_id: str
    primary_rule_code: str
    span: tuple
    related_rule_codes: list
    folded_finding_ids: list


def _spans_should_fold(a, b, overlap_threshold: float, max_gap_chars: int) -> bool:
    s1, e1 = a
    s2, e2 = b
    if s1 < 0 or s2 < 0 or e1 <= s1 or e2 <= s2:
        return False
    inter = max(0, min(e1, e2) - max(s1, s2))
    min_len = min(e1 - s1, e2 - s2)
    if min_len > 0 and (inter / min_len) >= overlap_threshold:
        return True
    gap = max(s1, s2) - min(e1, e2)
    return 0 <= gap <= max_gap_chars


def cluster_findings_for_ui_folding(findings, overlap_threshold: float = 0.50,
                                    max_gap_chars: int = 40) -> list:
    """按原文区间把跨码 finding 折叠为 UI 卡片（0 删 TP：所有 finding 都被保留在卡片里）。

    返回 ``FoldedIssueCard`` 列表；``folded_finding_ids`` 是**全部**输入 finding id 的
    一个划分（并集 = 输入全集、交集为空），因此“折叠”只影响展示，不损失任何一条 finding。
    """
    ordered = sorted(
        findings,
        key=lambda f: (-float(getattr(f, "confidence", 0.5) or 0.0),
                       -(max(0, int(getattr(f, "char_end", -1)) - int(getattr(f, "char_start", -1)))),
                       str(getattr(f, "finding_id", ""))),
    )
    cards = []
    for f in ordered:
        f_span = (int(f.char_start), int(f.char_end))
        placed = False
        for card in cards:
            if _spans_should_fold(card.span, f_span, overlap_threshold, max_gap_chars):
                card.folded_finding_ids.append(f.finding_id)
                if f.rule_code not in card.related_rule_codes:
                    card.related_rule_codes.append(f.rule_code)
                card.span = (min(card.span[0], f_span[0]), max(card.span[1], f_span[1]))
                placed = True
                break
        if not placed:
            cards.append(FoldedIssueCard(
                primary_finding_id=f.finding_id,
                primary_rule_code=f.rule_code,
                span=f_span,
                related_rule_codes=[f.rule_code],
                folded_finding_ids=[f.finding_id],
            ))
    return cards


def folded_ui_loss_check(findings, cards) -> dict:
    """折叠 0 TP 损失的可机读断言：并集==输入全集、交集为空、每条只出现一次。"""
    ids = [str(getattr(f, "finding_id", "")) for f in findings]
    folded = [str(x) for c in cards for x in c.folded_finding_ids]
    return {
        "n_findings": len(ids),
        "n_folded": len(folded),
        "n_cards": len(cards),
        "union_equal": sorted(folded) == sorted(ids),
        "no_duplicates": len(folded) == len(set(folded)),
        "no_loss": sorted(folded) == sorted(ids) and len(folded) == len(set(folded)),
    }
