# -*- coding: utf-8 -*-
"""百度智能云 文档解析（Unlimited-OCR 2）。

支持两种真实调用通道（都不伪造成功；失败返回明确原因）：

1. 千帆 v2 Bearer（T-99 新增，推荐）：
   POST https://qianfan.baidubce.com/v2/chat/completions
   model=unlimited-ocr-2，messages 里 image_url 传图片/PDF 的 Base64 data URL；
   Authorization: Bearer bce-v3/ALTAK-...（百度 BCE IAM API Key）。
   凭据来源：环境变量 BAIDU_OCR_BEARER / RULEPROOF_BAIDU_OCR_BEARER，
   或 model_config 行（mdl-baidu-ocr）api_key 以 bce-v3/ 开头。

2. 旧版 aip 异步任务（保留兼容）：
   POST /rest/2.0/brain/online/v2/unlimited-ocr-parser/task
   POST /rest/2.0/brain/online/v2/unlimited-ocr-parser/task/query
   result.markdown_url -> Markdown（表格为 HTML）
   鉴权：API Key + Secret Key 换 OAuth access_token，或历史 Bearer Key。

配置优先级：环境变量 > 本地 model_config；Token 不写入仓库/交付包，
也不出现在日志/错误文案中（返回前做脱敏）。
"""
from __future__ import annotations

import base64
import html
import json
import logging
import os
import re
import time
from pathlib import Path

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

DEFAULT_BASE = "https://aip.baidubce.com/rest/2.0/brain/online/v2/unlimited-ocr-parser"
DEFAULT_OAUTH = "https://aip.baidubce.com/oauth/2.0/token"
# T-99：千帆 v2 同步 OCR（Unlimited-OCR-2），Bearer bce-v3 IAM API Key。
DEFAULT_QIANFAN_BASE = "https://qianfan.baidubce.com/v2"
DEFAULT_QIANFAN_MODEL = "unlimited-ocr-2"
_TOKEN_CACHE: dict = {"token": "", "exp": 0.0, "key": ""}


def _model_row() -> dict:
    try:
        from .. import db
        with db.session() as c:
            rows = c.execute(
                "SELECT provider,base_url,api_key,model_id FROM model_config "
                "WHERE enabled=1 AND (provider LIKE '%textmind%' OR provider LIKE '%unlimited%' "
                "OR model_id LIKE '%unlimited%') ORDER BY created_at DESC LIMIT 5").fetchall()
        for r in rows:
            d = dict(r)
            if d.get("api_key"):
                return d
    except Exception:
        logging.getLogger(__name__).debug("baidu ocr model row skipped", exc_info=True)
    return {}


def _split_credentials(raw: str) -> tuple[str, str]:
    raw = str(raw or "").strip()
    if not raw:
        return "", ""
    try:
        d = json.loads(raw)
        if isinstance(d, dict):
            return str(d.get("api_key") or d.get("client_id") or ""), str(d.get("secret_key") or d.get("client_secret") or "")
    except Exception:
        pass
    if ":" in raw:
        a, b = raw.split(":", 1)
        return a.strip(), b.strip()
    return raw, ""


def _bearer_env() -> str:
    """千帆 v2 Bearer（bce-v3 IAM API Key）：新变量名优先，兼容部署方注入的别名。"""
    return (os.environ.get("RULEPROOF_BAIDU_OCR_BEARER")
            or os.environ.get("BAIDU_OCR_BEARER") or "").strip()


def _looks_like_iam_bearer(value: str) -> bool:
    """bce-v3/ALTAK-... 形式的百度 BCE IAM API Key（单凭据，不需要 Secret）。"""
    text = str(value or "").strip()
    return text.startswith("bce-v3/") and ":" not in text


def _redact(text: str, secrets: list) -> str:
    """错误文案脱敏：任何凭据值都不出现在返回给页面/日志的字符串里。"""
    out = str(text or "")
    for s in secrets:
        s = str(s or "")
        if s:
            out = out.replace(s, "***")
    return out


def _cfg() -> dict:
    """解析当前 OCR 凭据与通道（环境变量 > model_config；不打印/不返回明文到日志）。

    auth_mode:
      - qianfan：千帆 v2 Bearer（BAIDU_OCR_BEARER / RULEPROOF_BAIDU_OCR_BEARER，
        或 model_config 行的 bce-v3 单凭据）→ Unlimited-OCR-2 同步 OCR；
      - oauth：aip 旧异步任务，API Key + Secret Key；
      - bearer：aip 旧异步任务，历史单 Bearer Key（保留兼容）；
      - none：未配置。
    优先级：环境变量 API Key+Secret > 环境变量 Bearer > 环境变量单 Key >
    model_config Bearer > model_config Key/Secret。
    """
    row = _model_row()
    bearer = _bearer_env()
    env_api = (os.environ.get("RULEPROOF_BAIDU_OCR_KEY")
               or os.environ.get("RULEPROOF_BAIDU_OCR_API_KEY")
               or os.environ.get("BAIDU_DOC_AI_API_KEY") or "").strip()
    env_sec = (os.environ.get("RULEPROOF_BAIDU_OCR_SECRET_KEY")
               or os.environ.get("BAIDU_DOC_AI_SECRET_KEY") or "").strip()
    row_bearer, row_api, row_sec = "", "", ""
    if row.get("api_key"):
        raw_row = str(row.get("api_key") or "").strip()
        if _looks_like_iam_bearer(raw_row):
            row_bearer = raw_row
        else:
            row_api, row_sec = _split_credentials(raw_row)
    if env_api and env_sec:
        api, sec, token = env_api, env_sec, ""
    elif bearer:
        api, sec, token = "", "", bearer
    elif env_api:
        api, sec, token = env_api, "", ""
    elif row_bearer:
        api, sec, token = "", "", row_bearer
    else:
        api, sec, token = row_api, row_sec, ""
    if token:
        base = (os.environ.get("RULEPROOF_BAIDU_OCR_QIANFAN_BASE_URL")
                or DEFAULT_QIANFAN_BASE).rstrip("/")
        model = (os.environ.get("RULEPROOF_BAIDU_OCR_MODEL")
                 or DEFAULT_QIANFAN_MODEL)
        return {"api_key": "", "secret_key": "", "token": token, "base_url": base,
                "oauth_url": os.environ.get("RULEPROOF_BAIDU_OAUTH_URL", DEFAULT_OAUTH),
                "auth_mode": "qianfan", "model": "Unlimited-OCR-2",
                "qianfan_model": model, "provider": "baidu-unlimited-ocr"}
    base = (os.environ.get("RULEPROOF_BAIDU_OCR_BASE_URL")
            or row.get("base_url") or DEFAULT_BASE).rstrip("/")
    # 允许传入 .../task，统一成服务根
    if base.endswith("/task"):
        base = base[:-5]
    return {"api_key": api, "secret_key": sec, "token": "", "base_url": base,
            "oauth_url": os.environ.get("RULEPROOF_BAIDU_OAUTH_URL", DEFAULT_OAUTH),
            "auth_mode": "oauth" if (api and sec) else "bearer" if api else "none",
            "model": "Unlimited-OCR-2", "provider": "baidu-unlimited-ocr"}


def configured() -> bool:
    c = _cfg()
    if not requests:
        return False
    if c.get("auth_mode") == "qianfan":
        return bool(c.get("token") and c.get("base_url"))
    return bool(c.get("api_key") and c.get("base_url")
                and (c.get("secret_key") or _looks_like_iam_bearer(c.get("api_key"))))


def status() -> dict:
    c = _cfg()
    ok = configured()
    return {"configured": ok, "provider": "baidu-unlimited-ocr", "model": "Unlimited-OCR-2",
            "mode": "baidu-unlimited-ocr" if ok else "none", "endpoint": c.get("base_url", DEFAULT_BASE),
            "auth_mode": c.get("auth_mode", "none"),
            "qianfan_model": c.get("qianfan_model", ""),
            "reason": "" if ok else ("未配置百度 Unlimited-OCR 凭据（千帆 Bearer："
                                     "BAIDU_OCR_BEARER / RULEPROOF_BAIDU_OCR_BEARER，"
                                     "或 API Key+Secret Key）"
                                     + ("" if requests else "；运行环境缺少 requests 依赖"))}


def _token(timeout: int = 30) -> str:
    c = _cfg()
    key = c.get("api_key") or ""
    if _TOKEN_CACHE.get("token") and _TOKEN_CACHE.get("key") == key and time.time() < _TOKEN_CACHE.get("exp", 0):
        return _TOKEN_CACHE["token"]
    if not requests:
        raise RuntimeError("requests 未安装")
    r = requests.get(c["oauth_url"], params={"grant_type": "client_credentials",
                                             "client_id": c["api_key"],
                                             "client_secret": c["secret_key"]}, timeout=timeout)
    d = r.json() if r.content else {}
    tok = str(d.get("access_token") or "")
    if not tok:
        raise RuntimeError("百度 OAuth 失败：" + str(d.get("error_description") or d.get("error") or r.status_code))
    _TOKEN_CACHE.update({"token": tok, "key": key, "exp": time.time() + 29 * 86400})
    return tok


def _clean_markdown(md: str) -> str:
    t = str(md or "")
    # 保留表格单元格文字；HTML 标签转空格，避免把 <table> 整段吞掉
    t = re.sub(r"<br\s*/?>", "\n", t, flags=re.I)
    t = re.sub(r"</(?:p|div|tr|li|h[1-6])>", "\n", t, flags=re.I)
    t = re.sub(r"</(?:td|th)>", " | ", t, flags=re.I)
    t = re.sub(r"<[^>]+>", "", t)
    t = html.unescape(t)
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def _submit(path: str = "", file_url: str = "", file_name: str = "", timeout: int = 120) -> str:
    c = _cfg()
    if c.get("auth_mode") == "bearer":
        params = {}; headers = {"Authorization": "Bearer " + c["api_key"],
                                "Content-Type": "application/x-www-form-urlencoded"}
    else:
        params = {"access_token": _token()}; headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {"file_name": file_name or (Path(path).name if path else "document.pdf")}
    if file_url:
        data["file_url"] = file_url
    else:
        raw = Path(path).read_bytes()
        data["file_data"] = base64.b64encode(raw).decode()
    # 默认角度矫正；不默认擦章/水印，避免改变审核证据
    data.setdefault("angle_adjust", "true")
    r = requests.post(c["base_url"] + "/task", params=params,
                      data=data, headers=headers, timeout=timeout)
    d = r.json() if r.content else {}
    if int(d.get("error_code") or 0) != 0:
        raise RuntimeError(f"提交失败 {d.get('error_code')}: {d.get('error_msg')}")
    tid = str((d.get("result") or {}).get("task_id") or "")
    if not tid:
        raise RuntimeError("提交成功但未返回 task_id")
    return tid


def _query(task_id: str, timeout: int = 60) -> dict:
    c = _cfg()
    if c.get("auth_mode") == "bearer":
        params = {}; headers = {"Authorization": "Bearer " + c["api_key"],
                                "Content-Type": "application/x-www-form-urlencoded"}
    else:
        params = {"access_token": _token()}; headers = {"Content-Type": "application/x-www-form-urlencoded"}
    r = requests.post(c["base_url"] + "/task/query", params=params,
                      data={"task_id": task_id}, headers=headers, timeout=timeout)
    d = r.json() if r.content else {}
    if int(d.get("error_code") or 0) != 0:
        raise RuntimeError(f"查询失败 {d.get('error_code')}: {d.get('error_msg')}")
    return d.get("result") or {}


def _download(url: str, timeout: int = 120) -> str:
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


# ---------------- T-99：千帆 v2 Bearer 同步 OCR（Unlimited-OCR-2） ----------------
_MIME_BY_SUFFIX = {
    ".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg", ".webp": "image/webp", ".bmp": "image/bmp",
    ".gif": "image/gif", ".tif": "image/tiff", ".tiff": "image/tiff",
}


def _file_mime(path: str, file_name: str = "") -> str:
    suffix = Path(str(file_name or path or "")).suffix.lower()
    return _MIME_BY_SUFFIX.get(suffix, "application/octet-stream")


def _clean_layout_markup(text: str) -> str:
    """清洗 Unlimited-OCR-2 版面标记（<PAGE>/<BLOCK>/<FORK>/坐标数组），只留可读文本。

    模型输出示例：``<PAGE><BLOCK>title<LEVEL1>[38, 176, 930, 786]<FORK>正文``。
    表格 HTML 标签按旧版 _clean_markdown 的规则保留单元格文字。
    """
    t = str(text or "")
    t = re.sub(r"<FORK\s*/?>", "\n", t, flags=re.I)
    t = re.sub(r"</(?:p|div|tr|li|h[1-6])>", "\n", t, flags=re.I)
    t = re.sub(r"</(?:td|th)>", " | ", t, flags=re.I)
    # 版面/结构标签（只匹配标签形状，不吞正文比较符）
    t = re.sub(r"</?[A-Za-z][A-Za-z0-9_-]{0,20}(?:\s[^<>]{0,80})?\s*/?>", "", t)
    # 坐标数组 [x1, y1, x2, y2]
    t = re.sub(r"\[\s*-?\d+(?:\s*,\s*-?\d+)+\s*\]", "", t)
    t = html.unescape(t)
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def _qianfan_body(cfg: dict, path: str = "", file_url: str = "",
                  file_name: str = "") -> dict:
    if file_url:
        url = str(file_url)
    else:
        raw = Path(path).read_bytes()
        mime = _file_mime(path, file_name)
        url = f"data:{mime};base64," + base64.b64encode(raw).decode()
    return {
        "model": cfg.get("qianfan_model") or DEFAULT_QIANFAN_MODEL,
        "messages": [{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": url}}]}],
        "stream": False,
    }


def _qianfan_ocr(path: str = "", file_url: str = "", file_name: str = "",
                 timeout: int = 180) -> dict:
    """千帆 v2 Bearer 真实 OCR 调用；返回 {text, usage, raw}，失败抛脱敏后的异常。"""
    c = _cfg()
    if not requests:
        raise RuntimeError("requests 未安装")
    token = str(c.get("token") or "")
    if not token:
        raise RuntimeError("未配置千帆 Bearer 凭据")
    url = str(c.get("base_url") or DEFAULT_QIANFAN_BASE).rstrip("/") + "/chat/completions"
    body = _qianfan_body(c, path=path, file_url=file_url, file_name=file_name)
    r = requests.post(url, headers={"Authorization": "Bearer " + token,
                                    "Content-Type": "application/json"},
                      json=body, timeout=timeout)
    try:
        data = r.json() if (r.content or b"") else {}
    except Exception:
        data = {}
    status = int(getattr(r, "status_code", 0) or 0)
    if status != 200:
        err = data.get("error") if isinstance(data, dict) else {}
        if isinstance(err, dict):
            reason = str(err.get("message") or err.get("code") or "")[:200]
        else:
            reason = str(err or getattr(r, "text", "") or "")[:200]
        raise RuntimeError(_redact(f"千帆 OCR 失败 HTTP {status}：{reason}", [token]))
    ch = ((data.get("choices") or [{}])[0] if isinstance(data, dict) else {})
    content = (ch.get("message") or {}).get("content")
    if isinstance(content, list):
        content = "".join(str(x.get("text") or "") for x in content if isinstance(x, dict))
    usage = data.get("usage") or {}
    return {"text": str(content or ""), "usage": usage, "raw": data}


def _pdf_pages(path: str) -> int:
    if path and str(path).lower().endswith(".pdf"):
        try:
            from pypdf import PdfReader
            return len(PdfReader(path).pages)
        except Exception:
            return 0
    return 0


def _run_qianfan(path: str = "", file_url: str = "", file_name: str = "",
                 timeout_s: int = 180) -> dict:
    """千帆 v2 Bearer 同步 OCR：真实调用，失败如实返回原因（脱敏）。"""
    c = _cfg()
    token = str(c.get("token") or "")
    t0 = time.time()
    try:
        out = _qianfan_ocr(path=path, file_url=file_url, file_name=file_name,
                           timeout=max(30, int(timeout_s)))
        text = _clean_layout_markup(out.get("text"))
        latency_ms = int((time.time() - t0) * 1000)
        if not text:
            return {"ok": False, "provider": "baidu-unlimited-ocr", "model": "Unlimited-OCR-2",
                    "text": "", "pages": _pdf_pages(path), "latency_ms": latency_ms,
                    "reason": "千帆 Unlimited-OCR-2 返回空文本（未伪造识别结果）"}
        return {"ok": True, "provider": "baidu-unlimited-ocr", "model": "Unlimited-OCR-2",
                "text": text, "pages": _pdf_pages(path), "latency_ms": latency_ms,
                "usage": out.get("usage") or {}, "engine": "qianfan-bearer",
                "reason": "百度 Unlimited-OCR-2 解析成功（千帆 v2 Bearer 真实调用）"}
    except Exception as e:  # noqa: BLE001 - 失败如实返回，不重试不伪造
        return {"ok": False, "provider": "baidu-unlimited-ocr", "model": "Unlimited-OCR-2",
                "text": "", "pages": _pdf_pages(path),
                "latency_ms": int((time.time() - t0) * 1000),
                "reason": _redact(f"{type(e).__name__}: {str(e)[:240]}", [token])}


def run_file(path: str = "", file_url: str = "", timeout_s: int = 360,
             poll_s: float = 5.0, file_name: str = "") -> dict:
    """提交并轮询；成功返回 Markdown 文本。不伪造页数/成功。"""
    if not configured():
        return {"ok": False, "provider": "baidu-unlimited-ocr", "text": "", "pages": 0,
                "reason": "未配置百度 Unlimited-OCR 凭据（Bearer 或 API Key+Secret Key）"}
    if not path and not file_url:
        return {"ok": False, "provider": "baidu-unlimited-ocr", "text": "", "pages": 0,
                "reason": "未提供文件或 URL"}
    # T-99：千帆 v2 Bearer 走同步 OCR（图片/PDF 均可，单次真实 HTTP 调用）
    if _cfg().get("auth_mode") == "qianfan":
        return _run_qianfan(path=path, file_url=file_url, file_name=file_name,
                            timeout_s=timeout_s)
    t0 = time.time()
    tid = ""
    try:
        tid = _submit(path=path, file_url=file_url, file_name=file_name or (Path(path).name if path else "document.pdf"))
        end = time.time() + max(30, int(timeout_s))
        while time.time() < end:
            res = _query(tid)
            st = str(res.get("status") or "").lower()
            if st == "success":
                md_url = str(res.get("markdown_url") or "")
                if not md_url:
                    return {"ok": False, "provider": "baidu-unlimited-ocr", "task_id": tid,
                            "text": "", "pages": 0, "reason": "success 但无 markdown_url"}
                raw = _download(md_url)
                text = _clean_markdown(raw)
                pages = 0
                if path and str(path).lower().endswith(".pdf"):
                    try:
                        from pypdf import PdfReader
                        pages = len(PdfReader(path).pages)
                    except Exception:
                        pages = 0
                return {"ok": True, "provider": "baidu-unlimited-ocr", "model": "Unlimited-OCR-2",
                        "task_id": tid, "text": text, "pages": pages,
                        "reason": "百度 Unlimited-OCR 解析成功"}
            if st == "failed":
                return {"ok": False, "provider": "baidu-unlimited-ocr", "task_id": tid,
                        "text": "", "pages": 0, "reason": "任务失败：" + str(res.get("task_error") or "unknown")}
            time.sleep(max(1.0, float(poll_s)))
        return {"ok": False, "provider": "baidu-unlimited-ocr", "task_id": tid,
                "text": "", "pages": 0, "reason": f"轮询超时（{int(time.time()-t0)}s）"}
    except Exception as e:
        return {"ok": False, "provider": "baidu-unlimited-ocr", "task_id": tid,
                "text": "", "pages": 0, "reason": f"{type(e).__name__}: {str(e)[:240]}"}
