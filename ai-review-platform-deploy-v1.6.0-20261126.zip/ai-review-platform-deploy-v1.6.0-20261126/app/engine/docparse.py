"""DOCX/PDF/XLSX/MD 通用文件审核入口（第二解析入口）—— 事实/锚点。

L116 起第二入口复用 deepparse 统一解析（docx/PDF 页眉页脚同一 helper、xlsx/md 同一
section 来源），避免两入口口径漂移；docx 正文仍保留单元格级 locator（评测参考坐标）。
"""
import hashlib
import logging
import os
from dataclasses import dataclass, field, asdict

from docx import Document as DocxDocument


# TL-5：文本层/确定性解析 provenance（可信）
_TEXT_LAYER_PROV = {"ocr_engine": "text_layer", "ocr_tier": "text", "vision_advisory": False}


def _prov_fields(prov) -> dict:
    """provenance → DocFact 字段（未知时保持空/None，不默认安全）。"""
    from . import hooks as _hk
    f = _hk.fact_provenance_fields(prov)
    return {"ocr_engine": f["ocr_engine"], "ocr_tier": f["ocr_tier"],
            "vision_advisory": f["vision_advisory"], "evidence_source": f["evidence_source"]}


@dataclass
class DocFact:
    kind: str              # heading / paragraph / cell / ocr
    text: str
    locator: str           # 段号 / 表格 行x列 / 第N页
    quote: str
    # TL-5 按页 provenance：事实来源必须可归因；默认空 = 未知（不默认安全）。
    ocr_engine: str = ""        # 'text_layer' | 'paddle' | 'baidu' | 'external_cmd' | 'vision' | ''
    ocr_tier: str = ""          # 'text' | 'ocr' | 'vision' | ''
    vision_advisory: bool | None = None  # True=通用视觉模型产出，数值不得用于判定
    evidence_source: str = ""   # vision/未知来源的数值事实标 'vision_advisory'

    def to_dict(self):
        return asdict(self)


@dataclass
class DocReport:
    source: str
    paragraph_count: int = 0
    heading_count: int = 0
    table_count: int = 0
    headings: list = field(default_factory=list)
    facts: list = field(default_factory=list)
    checks: list = field(default_factory=list)
    # TL-5：按页 provenance（第N页 → {ocr_engine, ocr_tier, vision_advisory}）
    page_provenance: dict = field(default_factory=dict)
    # P1 安全（2026-11-23）：docx 解析时按开关跳过的隐藏文本摘要（白字/≤2pt/vanish）。
    # 只记位置/字符数/原因，不复制正文；与 deepparse.ParsedDoc.skipped_hidden_text 同口径。
    skipped_hidden_text: list = field(default_factory=list)
    # L116（2026-11-25）：xlsx 隐藏/极隐藏 sheet 跳过留痕（与 deepparse 同口径，第二入口不静默）。
    skipped_sheets: list = field(default_factory=list)
    # L116（2026-11-25）：页眉/页脚证据状态（与 deepparse.ParsedDoc.header_footer_evidence 同口径）：
    # {"format", "entry": "docparse", "switch", "state": found|none|no_text_layer|disabled|error,
    #  "sufficient", "reason", "facts", "source"}；state=none/no_text_layer 即证据不足。
    header_footer_evidence: dict = field(default_factory=dict)

    def provenance_summary(self) -> dict:
        from . import hooks as _hk
        return _hk.doc_provenance(self.page_provenance,
                                  [f.to_dict() for f in self.facts])

    def to_dict(self):
        _prov = self.provenance_summary()
        return {
            "source": self.source,
            "paragraph_count": self.paragraph_count,
            "heading_count": self.heading_count,
            "table_count": self.table_count,
            "headings": self.headings,
            "facts": [f.to_dict() for f in self.facts],
            "checks": self.checks,
            "page_provenance": dict(self.page_provenance or {}),
            "skipped_hidden_text": list(self.skipped_hidden_text or []),
            "skipped_sheets": list(self.skipped_sheets or []),
            "header_footer_evidence": dict(self.header_footer_evidence or {}),
            "provenance": _prov,
        }


def _hidden_text_guard_on() -> bool:
    """复用 deepparse 的隐藏文本守卫开关（RULEPROOF_HIDDEN_TEXT_GUARD，默认 1）。

    docparse/deepparse 是两条解析入口，守卫口径必须一致：同一开关、同一 run 级判定、
    同一留痕字段；这里不复制判定实现，避免两处口径漂移。
    """
    try:
        from . import deepparse as _dp
        return _dp.hidden_text_guard_enabled()
    except Exception:
        return False


def _hidden_text_helpers():
    from . import deepparse as _dp
    return _dp


# ---------------------------------------------------------------------------
# L116（2026-11-25）第二解析入口复用统一解析（docx/xlsx/PDF 页眉页脚）
#
# 缺陷（L43 §9 / L102 因子 #6）：L43 只修了 deepparse 主入口的 docx 页眉页脚，
#   docparse.parse_docx 仍 0/40 页眉事实；xlsx 打印页眉（L107）与 PDF 页眉页脚
#   （L116 主入口）在第二入口完全不可见；docparse.parse_document 仅支持 docx/pdf，
#   xlsx/md 直接返回「格式-执行失败」。两条入口各写一套解析 → 口径漂移。
# 修复：第二入口不复制解析实现，复用 deepparse 统一解析的同一批 helper/section：
#   · docx：复用 `_docx_header_footer_sections`（含隐藏文本守卫、首页/偶数页变体）；
#   · PDF：复用 `_pdf_collect_pages` + `_pdf_header_footer_evidence`（同一判定/同一 anchor）；
#   · xlsx/md：直接消费 `deepparse.parse_document` 的 sections → DocFact（含打印页眉/页脚），
#     表头别名等下游取数逻辑仍只在 engine.py 单一实现，第二入口只提供同一份文本/事实。
# 开关 RULEPROOF_DOCPARSE_HEADER_FACTS（默认 1；=0 回退：第二入口不产出 header/footer 事实）。
# 与主入口开关正交：主入口 =0 时第二入口同步不产出（避免同一文档两入口口径漂移）。
# ---------------------------------------------------------------------------
def header_facts_enabled() -> bool:
    """RULEPROOF_DOCPARSE_HEADER_FACTS（默认 1）：第二入口产出页眉/页脚事实。"""
    return str(os.environ.get("RULEPROOF_DOCPARSE_HEADER_FACTS", "1")).strip().lower() not in (
        "0", "false", "no", "off")


def _hf_evidence(format_: str, main_ev: dict, n_facts: int,
                 main_switch_env: str = "") -> dict:
    """第二入口页眉/页脚证据：主入口 evidence + 第二入口开关的综合状态（同口径不漂移）。

    state=found 需同时满足：第二入口开关开 + 主入口找到 header/footer；
    state=none / no_text_layer / disabled / error 一律 sufficient=False（证据不足/回退）。
    """
    main_ev = dict(main_ev or {})
    main_state = str(main_ev.get("state") or "")
    if not header_facts_enabled():
        return {"format": format_, "entry": "docparse", "switch": "off",
                "state": "disabled", "sufficient": False,
                "reason": "RULEPROOF_DOCPARSE_HEADER_FACTS=0（第二入口回退：不产出页眉/页脚事实）",
                "facts": 0, "source": "deepparse 统一解析（主入口 evidence=%s）" % (main_state or "?")}
    if main_state == "found" and n_facts > 0:
        return {"format": format_, "entry": "docparse", "switch": "on",
                "state": "found", "sufficient": True, "reason": "",
                "facts": int(n_facts), "source": "deepparse 统一解析（同 section 来源）"}
    if main_state == "disabled":
        return {"format": format_, "entry": "docparse", "switch": "on",
                "state": "disabled", "sufficient": False,
                "reason": ("主入口 %s=0（回退）：第二入口同步不产出，避免两入口口径漂移"
                           % (main_switch_env or "页眉/页脚开关")),
                "facts": 0, "source": "deepparse 统一解析（主入口 disabled）"}
    return {"format": format_, "entry": "docparse", "switch": "on",
            "state": main_state if main_state in ("none", "no_text_layer", "error") else "none",
            "sufficient": False,
            "reason": str(main_ev.get("reason")
                          or "未识别到页眉/页脚（字段缺失属证据不足，不默认放行）"),
            "facts": 0, "source": "deepparse 统一解析（主入口 evidence=%s）" % (main_state or "?")}


def _hf_fact(sec) -> DocFact:
    """统一解析 Section（header/footer）→ 第二入口 DocFact（kind/anchor/text 同口径）。"""
    return DocFact(str(sec.kind), str(sec.text), str(sec.anchor), str(sec.text)[:120],
                   **_prov_fields(_TEXT_LAYER_PROV))


def parse_docx(path: str) -> DocReport:
    """docx → 事实/锚点。P1 安全（2026-11-23）：默认跳过 run 级隐藏文本。

    隐藏文本（白色字体 / ≤2pt 极小字号 / vanish）不作为判定证据；只写
    skipped_hidden_text 结构化摘要（位置/字符数/原因，不复制正文）+ 警告日志。
    回退开关 RULEPROOF_HIDDEN_TEXT_GUARD=0 → 逐字旧行为（全部文本按正文解析）。
    """
    d = DocxDocument(path)
    r = DocReport(source=path)
    _guard_on = _hidden_text_guard_on()
    _dp = _hidden_text_helpers() if _guard_on else None
    pi = 0
    for i, para in enumerate(d.paragraphs):
        if _guard_on:
            t = _dp.visible_paragraph_text(para, f"段{i + 1}", r.skipped_hidden_text)
        else:
            t = para.text.strip()
        if not t:
            continue
        pi += 1
        style = para.style.name or ""
        _kw = _prov_fields(_TEXT_LAYER_PROV)
        if style.startswith("Heading") or style.startswith("Title"):
            r.heading_count += 1
            r.headings.append(t)
            r.facts.append(DocFact("heading", t, f"段{pi}", t[:120], **_kw))
        else:
            r.facts.append(DocFact("paragraph", t, f"段{pi}", t[:120], **_kw))
    r.paragraph_count = pi
    for ti, tb in enumerate(d.tables, 1):
        r.table_count += 1
        for ri, row in enumerate(tb.rows, 1):
            for ci, cell in enumerate(row.cells, 1):
                if _guard_on:
                    ct = _dp.visible_cell_text(
                        cell, f"表{ti} R{ri}C{ci}", r.skipped_hidden_text
                    ).replace("\n", " ").strip()
                else:
                    ct = cell.text.strip().replace("\n", " ")
                if ct:
                    r.facts.append(DocFact("cell", ct, f"表{ti} R{ri}C{ci}", ct[:120],
                                           **_prov_fields(_TEXT_LAYER_PROV)))
    if r.skipped_hidden_text:
        logging.getLogger(__name__).warning(
            "docx 跳过隐藏文本（不作为判定证据，共 %d 处）：%s", len(r.skipped_hidden_text),
            [(x.get("anchor"), x.get("chars"), x.get("reasons"))
             for x in r.skipped_hidden_text])

    # L116：页眉/页脚事实 —— 复用 deepparse 同一容器判定（含隐藏文本守卫、首页/偶数页变体），
    # 第二入口不复制实现；正文段落/表格事实的顺序与文本不变（header/footer 追加在末尾）。
    _dpmod = _hidden_text_helpers()
    _hf_secs, _main_ev = [], {}
    try:
        _main_on = _dpmod.docx_header_facts_enabled()
        if header_facts_enabled() and _main_on:
            _hf_secs = _dpmod._docx_header_footer_sections(
                d, _guard_on, r.skipped_hidden_text)
            for _s in _hf_secs:
                r.facts.append(_hf_fact(_s))
        _main_ev = _dpmod._header_footer_evidence(
            "docx", _main_on, len(_hf_secs), "RULEPROOF_DOCX_HEADER_FACTS",
            "docx 未识别到页眉/页脚（无 header/footer 容器）")
    except Exception:  # noqa: BLE001 - 页眉/页脚提取失败不得阻断既有段落/表格解析
        logging.getLogger(__name__).warning(
            "docparse docx 页眉/页脚提取失败（按旧行为继续）", exc_info=True)
        _main_ev = {"state": "error", "reason": "页眉/页脚提取异常"}
    r.header_footer_evidence = _hf_evidence(
        "docx", _main_ev, sum(1 for f in r.facts if f.kind in ("header", "footer")),
        "RULEPROOF_DOCX_HEADER_FACTS")

    # 通用检查（文件审核场景的最小检查）
    r.checks.append({"name": "文档含标题", "state": "满足" if r.heading_count > 0 else "不满足"})
    r.checks.append({"name": "文档含正文段落", "state": "满足" if r.paragraph_count > 0 else "不满足"})
    r.checks.append({"name": "文档含表格", "state": "满足" if r.table_count > 0 else "不满足", "detail": f"{r.table_count} 个表格"})
    return r


def parse_pdf(path: str, config=None) -> DocReport:
    """PDF 通用文件审核：抽文本 → 段落事实 → 通用检查；扫描件检测 + OCR 挂载。

    L116：页眉/页脚事实复用 deepparse 同一判定（`_pdf_collect_pages` +
    `_pdf_header_footer_evidence`，同一 anchor/开关）；扫描件（无文本层）不纳入
    页眉/页脚确定性解析（OCR 层 UNTESTED），证据状态记 header_footer_evidence。
    """
    from pypdf import PdfReader
    from . import ocr
    _dpmod = _hidden_text_helpers()
    r = DocReport(source=path)
    try:
        reader = PdfReader(path)
        _pages = _dpmod._pdf_collect_pages(reader)
        pi = 0
        _kw = _prov_fields(_TEXT_LAYER_PROV)
        for item in _pages:
            pno = int(item.get("page") or 0)
            text = str(item.get("text") or "").strip()
            if not text:
                continue
            r.page_provenance[f"第{pno}页"] = dict(_TEXT_LAYER_PROV)
            r.facts.append(DocFact("paragraph", text, f"第{pno}页", text[:120], **_kw))
            for para in text.split("\n"):
                para = para.strip()
                if len(para) > 4:
                    pi += 1
                    r.facts.append(DocFact("paragraph", para, f"第{pno}页 段{pi}", para[:120], **_kw))
        r.paragraph_count = pi
        # L116：文本层页眉/页脚事实（同 deepparse 判定）；扫描件不纳入（UNTESTED）
        _has_any_text = any(str(it.get("text") or "").strip() for it in _pages)
        _hf_facts = 0
        if _has_any_text:
            _hf_secs, _main_ev = _dpmod._pdf_header_footer_evidence(_pages)
            if header_facts_enabled():
                for _s in _hf_secs:
                    r.facts.append(_hf_fact(_s))
                    _hf_facts += 1
        else:
            _main_ev = _dpmod._pdf_no_text_layer_evidence(len(_pages))
        r.header_footer_evidence = _hf_evidence(
            "pdf", _main_ev, _hf_facts, "RULEPROOF_PDF_HEADER_FACTS")
        has_text_layer = pi > 0
        if not has_text_layer:
            # 扫描件：按页记录实际 OCR 引擎 provenance（视觉模型产出的数值不得用于判定）
            _det = {}
            try:
                _det = (ocr.ocr_scanned_pdf_detailed(path, config, max_pages=10)
                        if config is not None else {})
            except Exception:  # noqa: BLE001 - 详细失败信息由兜底路径给出
                logging.getLogger(__name__).warning("scanned pdf detailed OCR failed", exc_info=True)
                _det = {}
            ocr_text = str(_det.get("text") or "") or (ocr.ocr_pdf(path, config) or "")
            if ocr_text:
                _page_prov = dict(_det.get("page_provenance") or {})
                _prov = dict(_det.get("provenance") or {})
                if not _prov and not _page_prov:
                    # OCR_CMD 等无按页信息的路径：来源未知（不默认安全）
                    _prov = {"status": "unknown"}
                _kw_ocr = _prov_fields(_prov)
                r.facts.append(DocFact("ocr", ocr_text, "OCR", ocr_text[:120], **_kw_ocr))
                r.page_provenance.update(_page_prov)
                r.checks.append({"name": "扫描件 OCR 抽取", "state": "满足",
                                 "detail": f"OCR {len(ocr_text)} 字符（来源 "
                                           f"{_prov.get('ocr_engine') or '未知'}"
                                           f"/{_prov.get('ocr_tier') or '未知'}）"})
                if str(_prov.get("status") or "") in ("vision", "mixed", "unknown"):
                    r.checks.append({
                        "name": "数值事实来源", "state": "证据不足",
                        "detail": ("OCR 文本来源含通用视觉模型或未知（status="
                                   + str(_prov.get("status") or "unknown")
                                   + "），按 TL-5 不得作为数值判定依据，需人工核验")})
                has_text_layer = True
            else:
                r.checks.append({"name": "扫描件文本层", "state": "不满足",
                                 "detail": "无文本层且 OCR 未生效（需启用视觉模型或配置 OCR_CMD）"})
    except Exception as e:  # noqa
        r.checks.append({"name": "PDF 解析", "state": "执行失败", "detail": f"{type(e).__name__}: {e}"})
        return r
    r.checks.append({"name": "文档含正文", "state": "满足" if pi > 0 else "证据不足", "detail": f"{pi} 段"})
    r.checks.append({"name": "文档含文本层（可检索）", "state": "满足" if has_text_layer else "不满足", "detail": "扫描件需 OCR"})
    return r


def _report_from_parsed(parsed, source: str) -> DocReport:
    """deepparse 统一解析 ParsedDoc → 第二入口 DocReport（xlsx/md/txt 等格式复用）。

    只做模型映射，不复制解析/判定逻辑；header/footer 事实由第二入口开关统一控制，
    正文/表格事实与 deepparse 同一 section 来源（两入口文本逐字一致）。
    """
    r = DocReport(source=source)
    _kw = _prov_fields(_TEXT_LAYER_PROV)
    _hf_n = 0
    for sec in getattr(parsed, "sections", []) or []:
        _is_hf = str(getattr(sec, "kind", "")) in ("header", "footer")
        if _is_hf and not header_facts_enabled():
            continue
        r.facts.append(DocFact(str(sec.kind), str(sec.text), str(sec.anchor),
                               str(sec.text)[:120], **_kw))
        if _is_hf:
            _hf_n += 1
    _secs = list(getattr(parsed, "sections", []) or [])
    r.paragraph_count = sum(1 for s in _secs if str(s.kind) in ("paragraph", "heading"))
    r.heading_count = sum(1 for s in _secs if str(s.kind) == "heading")
    r.headings = [str(s.text) for s in _secs if str(s.kind) == "heading"]
    r.table_count = sum(1 for s in _secs if str(s.kind) == "table")
    r.page_provenance = dict(getattr(parsed, "page_provenance", {}) or {})
    r.skipped_sheets = list(getattr(parsed, "skipped_sheets", []) or [])
    _fmt = str(getattr(parsed, "doc_type", "") or "")
    if _fmt.lower() in ("md", "markdown", "txt"):
        r.header_footer_evidence = {}   # 纯文本无页眉页脚概念（不适用，不是证据缺口）
    else:
        _main_ev = dict(getattr(parsed, "header_footer_evidence", {}) or {})
        if not _main_ev:
            _main_ev = {"state": "none",
                        "reason": "统一解析未给出页眉/页脚证据（按证据不足处理，不默认放行）"}
        r.header_footer_evidence = _hf_evidence(_fmt, _main_ev, _hf_n)
    r.checks.append({"name": "文档含正文",
                     "state": "满足" if (r.paragraph_count or r.table_count) else "证据不足",
                     "detail": f"{r.paragraph_count} 段 / {r.table_count} 行表格"})
    r.checks.append({"name": "文档含表格",
                     "state": "满足" if r.table_count else "不满足",
                     "detail": f"{r.table_count} 行表格"})
    return r


def parse_xlsx(path: str) -> DocReport:
    """xlsx 通用文件审核：复用 deepparse.parse_document（打印页眉/页脚 + 隐藏 sheet 跳过口径）。

    L116：第二入口此前不支持 xlsx（返回「格式-执行失败」）；统一解析后 xlsx 的
    打印页眉/页脚（L107）、隐藏 sheet 安全跳过均与主入口同源，表头别名取数仍由
    engine.parse_xlsx（单一实现）消费同一份文本。
    """
    _dpmod = _hidden_text_helpers()
    try:
        parsed = _dpmod.parse_document(path)
    except Exception as e:  # noqa: BLE001 - 解析失败写检查项，不静默
        return DocReport(source=path, checks=[{
            "name": "xlsx 解析", "state": "执行失败",
            "detail": f"{type(e).__name__}: {str(e)[:200]}"}])
    r = _report_from_parsed(parsed, path)
    if r.skipped_sheets:
        logging.getLogger(__name__).warning(
            "docparse xlsx 跳过隐藏 sheet（不作为判定证据，共 %d 个）：%s",
            len(r.skipped_sheets), r.skipped_sheets)
    return r


def parse_md(path: str) -> DocReport:
    """md/txt 通用文件审核：复用 deepparse.parse_document（与主入口同一文本口径）。"""
    _dpmod = _hidden_text_helpers()
    try:
        parsed = _dpmod.parse_document(path)
    except Exception as e:  # noqa: BLE001
        return DocReport(source=path, checks=[{
            "name": "md 解析", "state": "执行失败",
            "detail": f"{type(e).__name__}: {str(e)[:200]}"}])
    return _report_from_parsed(parsed, path)


def parse_document(path: str) -> DocReport:
    """按扩展名分派：docx→parse_docx；pdf→parse_pdf；xlsx/xls→parse_xlsx；md/txt→parse_md。"""
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    if ext == "docx":
        return parse_docx(path)
    if ext == "pdf":
        return parse_pdf(path)
    if ext in ("xlsx", "xls"):
        return parse_xlsx(path)
    if ext in ("md", "markdown", "txt"):
        return parse_md(path)
    return DocReport(source=path, checks=[{"name": "格式", "state": "执行失败", "detail": f"不支持 .{ext}"}])
