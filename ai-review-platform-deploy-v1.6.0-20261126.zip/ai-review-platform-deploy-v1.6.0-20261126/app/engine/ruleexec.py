"""通用规则执行：把「已发布的 DB 规则」变成可执行的判定。

支持两种最常见的规则形态（由 rule_versions.slots_json 描述）：
1) 限值类：{"metric":"温度","op":">=","value":85,"unit":"℃","scope":"中心温度"}
2) 关键字类：{"require":"冷却"} / {"forbid":"防腐剂"} —— 文本包含/缺失判定
3) 跨行/跨表汇总类（显式 aggregation）：sum / max / min / avg / count / compare，
   见 cross_values / aggregate_values / compare_values / judge_cross

输出五态：满足 / 不满足 / 不适用 / 证据不足 / 执行失败。
"""
import math
import os
import re
import logging
import unicodedata
import datetime as _dt
from decimal import Decimal, ROUND_HALF_UP

from . import tools as _tools
# L79：单位单一真相源——基准倍率/压力/L39(L42)补充/温度/跨表补充倍率全部来自
# app/engine/registry.py；本模块保留既有常量名做兼容别名（执行期语义/开关口径不变）。
from .registry import (UNIT_SCALE_BASE as _REG_UNIT_SCALE_BASE,
                       PRESSURE_UNIT as _REG_PRESSURE_UNIT,
                       PRESSURE_ASCII_CANON as _REG_PRESSURE_ASCII_CANON,
                       UNIT_SCALE_FIX2 as _REG_UNIT_SCALE_FIX2,
                       UNIT_DIM_FIX2 as _REG_UNIT_DIM_FIX2,
                       UNIT_SCALE_V3 as _REG_UNIT_SCALE_V3,
                       UNIT_DIM_V3 as _REG_UNIT_DIM_V3,
                       TEMP_UNIT as _REG_TEMP_UNIT,
                       CROSS_EXTRA_SCALE as _REG_CROSS_EXTRA_SCALE)

METRIC_KIND = {"温度": "temp", "时间": "time", "浓度": "conc", "重量": "weight", "百分比": "percent"}

def _num(x):
    try:
        import re as _re
        s = str(x).replace("−", "-").replace("－", "-").translate(
            str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻", "0123456789+-"))
        m = _re.match(r"\s*([0-9]+(?:\.[0-9]+)?)\s*[×xX]\s*10\s*([+-]?\s*[0-9]+)", s)
        if m:
            return float(m.group(1)) * (10 ** int(m.group(2).replace(" ", "")))
        return float(s)
    except Exception:
        return None


def _cmp(v, op, target):
    if op in (">=", "≥"):
        return v >= target
    if op in ("<=", "≤"):
        return v <= target
    if op in (">",):
        return v > target
    if op in ("<",):
        return v < target
    if op in ("=", "=="):
        return abs(v - target) < 1e-9
    if op in ("!=", "≠"):
        return abs(v - target) >= 1e-9
    return None


def is_limit_rule(slots: dict) -> bool:
    """是否走限值执行器（judge_limit）。

    L5 段1 区间算子 op="range" 也属于限值类：即便 lo/hi 缺失也要进执行器，
    由 judge_limit 给出明确的「执行失败：缺少可解析的上下限」，不能落到
    「不适用」被静默当成无需判定。
    """
    if not slots or slots.get("metric") is None:
        return False
    if (slots.get("value") is not None or slots.get("range") is not None
            or slots.get("lo") is not None):
        return True
    return str(slots.get("op") or slots.get("operator") or "").strip() == "range"


# L5 段1（2026-11-21）区间解析新增 op="range"：value="lo-hi"（辅助字段 lo/hi/range）。
# 语义 = 闭区间 lo <= x <= hi。执行侧只把它翻译成既有算术比较（复用 _cmp/取数/单位归一），
# 不新增执行器；兼容 range{lo,hi} / lo+hi / value="lo-hi" 三种写法（与
# app.services.rule_ir.resolve_range_bounds 同口径）。
_RANGE_VALUE_RE = re.compile(
    r"^\s*(-?\d+(?:\.\d+)?)\s*[-~～〜至到—–－]\s*(-?\d+(?:\.\d+)?)\s*$")


def _range_bounds(slots: dict) -> tuple:
    """op=range 的闭区间上下限 (lo, hi)；解析不出返回 (None, None)。"""
    slots = dict(slots or {})

    def _f(v):
        return _num(v) if v not in (None, "") else None

    lo, hi = _f(slots.get("lo")), _f(slots.get("hi"))
    rng = slots.get("range")
    if isinstance(rng, dict):
        if lo is None:
            lo = _f(rng.get("lo"))
        if hi is None:
            hi = _f(rng.get("hi"))
    if lo is None or hi is None:
        m = _RANGE_VALUE_RE.match(str(slots.get("value", slots.get("threshold")) or ""))
        if m:
            if lo is None:
                lo = _num(m.group(1))
            if hi is None:
                hi = _num(m.group(2))
    return lo, hi


# 基准倍率表（registry 投影；原表字面迁移，数值/键逐项一致）
_UNIT_SCALE = dict(_REG_UNIT_SCALE_BASE)


# 压力维度：线性换算，基准 Pa（1 kPa = 1000 Pa，1 MPa = 10^6 Pa，1 bar = 10^5 Pa）。
# 表内只登记规范写法；大小写（kpa/KPA/Kpa）、内部空格（"k Pa"、"千 帕"）与中文
# 别名（千帕/兆帕/帕斯卡…）统一由 _unit_key() 归一，规则与 IR 仍保留原始单位文本。
# 压力维度单位表（registry 投影，基准 Pa）
_PRESSURE_UNIT = dict(_REG_PRESSURE_UNIT)
_UNIT_SCALE.update(_PRESSURE_UNIT)
# 压力 ASCII 单位大小写不敏感（不扩散到其他单位，避免改动既有口径）
_PRESSURE_ASCII_CANON = dict(_REG_PRESSURE_ASCII_CANON)

_UNIT_SPACE_RE = re.compile(r"\s+")

# ---------------------------------------------------------------------------
# L39 执行器 P0 修复（2026-11-24）：单位/量纲补充（统一开关 RULEPROOF_EXEC_FIXES_V2）
#   ⑤ 时间：s/秒（基准 min，1s = 1/60 min）
#   ⑨ 浓度：ppm / ppb / ug/kg（基准 mg/kg：ppm=1、ppb=0.001、ug/kg=0.001）
#   ③ 全角/兼容字符单位：㎏/㎎/㎝/㎜/㎖/㎥ 由 _unit_key 的 NFKC 兜底归一
# =0 时这些单位不参与换算（逐项回退到历史行为）。
# ---------------------------------------------------------------------------
_FIX2_UNIT_SCALE = dict(_REG_UNIT_SCALE_FIX2)
_FIX2_UNIT_DIM = dict(_REG_UNIT_DIM_FIX2)


def _fix2_on(item: str = "") -> bool:
    """L39 执行器修复统一开关（tools.exec_fix_v2 的本地别名）。"""
    return bool(_tools.exec_fix_v2(item))


# ---------------------------------------------------------------------------
# L42 执行器对象绑定/作用域修复（2026-11-24，统一开关 RULEPROOF_EXEC_FIXES_V3）
#   ⑤ 单位词表补 件/次/秒（L32 报告 §4.4/§6.5）：计数单位与秒既可做阈值换算，
#      也让 _occurrences 的引文切片包含已识别单位（修前引文截断成「计数为15」「复核1」）。
#   ① 对象绑定：规则声明 object/subject 时，文本路径只在该对象所在行/分句取数判定，
#      同一 metric 多对象的取值不得合并成一个「事实多处出现」集合（L32 clean 100/100 误报根因）。
#   作用域 scope_text：文本路径补事实路径 :scope 过滤同口径；过滤后为空不静默丢数（回退全量+留痕）。
# =0 时逐项回退到历史行为（引文不包含 件/次/秒、不绑定对象、不按 scope 过滤）。
# ---------------------------------------------------------------------------
_V3_UNIT_SCALE = dict(_REG_UNIT_SCALE_V3)
_V3_UNIT_DIM = dict(_REG_UNIT_DIM_V3)


def _fix3_on(item: str = "") -> bool:
    """L42 对象绑定/作用域修复统一开关（tools.exec_fix_v3 的本地别名）。"""
    return bool(_tools.exec_fix_v3(item))


# ---------------------------------------------------------------------------
# L107（2026-11-25）食品工艺书两处证据修复（默认开；=0 逐字回退旧行为）
#   D4 一致性引文指向异值：form=single 多位置取值不一致时，原实现 `bad = vals[1]`
#      取「第二处」——3 处 [V0.8,V1.0,V1.0] 时指向一致行 V1.0，点位错。改为按归一值
#      计数取多数，引文指向与多数不同的那一处；取值全部不同/并列时取「第一个与
#      vals[0] 不同的取值」（最早异值）并写 reason。只改证据选择，不改 state。
#   D5 缺失类 finding 引文为空：judge_keyword(require/require_any) 与 completeness/
#      record 等模板「缺少…」时 quote=""，fail 无逐字引文、不可回查。改为在调用方传入
#      的 text 中定位「最接近锚点」的原文行（显式 slots 锚点 > 需求词 2-gram > 常见合规
#      概念线索），逐字返回该行 + char_span/locator；原文无可用行（定位不到）→ 证据不足
#      （fail-closed），不得裸 fail。缺失类本身没有原文命中点，引文口径 = 缺失所在行上下文。
# ---------------------------------------------------------------------------
def _cons_outlier_quote_fix_on() -> bool:
    """D4：一致性 finding 引文指向异值（默认开；=0 回退 vals[1] 旧行为）。"""
    return str(os.environ.get("RULEPROOF_CONSISTENCY_OUTLIER_QUOTE", "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _missing_context_quote_fix_on() -> bool:
    """D5：缺失类 finding 带缺失上下文引文（默认开；=0 回退 quote="" 旧行为）。"""
    return str(os.environ.get("RULEPROOF_MISSING_CONTEXT_QUOTE", "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _scale_get(unit):
    """规范单位键 → 基准倍率；修复开启时先查 L39/L42 补充表（⑤/⑨/③/件/次/秒）。"""
    if not unit:
        return None
    if _fix2_on("unit_scale_ext") and unit in _FIX2_UNIT_SCALE:
        return _FIX2_UNIT_SCALE[unit]
    if _fix3_on("unit_vocab") and unit in _V3_UNIT_SCALE:
        return _V3_UNIT_SCALE[unit]
    return _UNIT_SCALE.get(unit)


def _temp_kind(u):
    """温度单位 → "C"/"F"；L39 单位等价补充「度」= 摄氏度（accepted_units 内等价写法）。"""
    u = str(u or "").strip()
    k = _TEMP_UNIT.get(u)
    if k is None and u == "度" and _fix2_on("temp_degree"):
        return "C"
    return k


def _unit_key(u) -> str:
    """单位规范键：去首尾/内部空白 + 压力单位大小写/中文别名归一；未注册返回空串。

    只做「同一单位的写法归一」，不做跨量纲映射，也不把未知单位猜成已知单位。
    L39 ③：修复开启时对兼容字符（㎏/㎎/㎝/㎜/㎖/㎥）与全角字母单位做 NFKC 兜底归一，
    以及 ⑤/⑨ 新增的 s/秒、ppm/ppb/ug/kg；=0 时逐项回退。
    """
    raw = str(u or "").strip()
    if not raw:
        return ""
    if raw in _UNIT_SCALE:
        return raw
    compact = _UNIT_SPACE_RE.sub("", raw)
    if compact in _UNIT_SCALE:
        return compact
    if compact.lower() in _PRESSURE_ASCII_CANON:
        return _PRESSURE_ASCII_CANON[compact.lower()]
    if _fix2_on("unit_scale_ext"):
        if compact in _FIX2_UNIT_SCALE:
            return compact
        try:
            nf = unicodedata.normalize("NFKC", compact)
        except Exception:                       # noqa: BLE001  归一失败不静默猜单位
            nf = compact
        if nf in _FIX2_UNIT_SCALE:
            return nf
        if nf in _UNIT_SCALE:
            return nf
        if nf.lower() in ("ppm", "ppb"):
            return nf.lower()
    if _fix3_on("unit_vocab") and compact in _V3_UNIT_SCALE:
        return compact
    return ""


# 温度单位：F↔C 是仿射变换（(F-32)*5/9），不能放进 _UNIT_SCALE 乘法表；
# 统一换算基准为摄氏（℃），阈值比较前先归一。
_TEMP_UNIT = dict(_REG_TEMP_UNIT)


def _temp_to_c(v, unit: str):
    """温度值 → 摄氏（℃）；不是温度单位返回 None。"""
    kind = _temp_kind(unit)
    if not kind:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if kind == "F":
        return (f - 32.0) * 5.0 / 9.0
    return f


def _c_to_temp(c, unit: str):
    """摄氏（℃）→ 目标温度单位；不是温度单位返回 None。"""
    kind = _temp_kind(unit)
    if not kind:
        return None
    try:
        f = float(c)
    except (TypeError, ValueError):
        return None
    if kind == "F":
        return f * 9.0 / 5.0 + 32.0
    return f


def _base_value(value, unit: str):
    """数值 → 与规则阈值同基准的「基本值」：温度统一 ℃，其它按 _UNIT_SCALE 缩放。"""
    u = _unit_key(unit) or str(unit or "").strip()
    if _temp_kind(u):
        return _temp_to_c(value, u)
    try:
        _sc = _scale_get(u)
        return float(value) * (_sc if _sc is not None else 1)
    except (TypeError, ValueError):
        return None


def _unit_dim(u: str):
    u = _unit_key(u) or (u or "").strip()
    if _temp_kind(u):
        return "temp"
    if u in _PRESSURE_UNIT:
        return "pressure"
    if u in ("g", "克", "kg", "千克", "t", "吨", "mg", "毫克", "μg"):
        return "mass"
    if u in ("分钟", "min", "小时", "h", "天", "日"):
        return "time"
    if u in ("mg/kg", "mg/g", "g/kg", "μg/kg", "µg/kg", "g/100g", "g/100mL", "g/100ml",
             "mg/L", "mg/l", "g/L", "g/l", "μg/L", "µg/L", "μg/l", "µg/l", "%(w/w)"):
        return "conc"
    if u in ("CFU/g", "CFU/ml", "CFU/mL", "个/g", "个/mL"):
        return "count_conc"
    if u in ("ml", "mL", "毫升", "L", "升"):
        return "vol"
    if u in ("mm", "毫米", "cm", "厘米", "m", "米"):
        return "len"
    if _fix3_on("unit_vocab") and u in _V3_UNIT_DIM:
        return _V3_UNIT_DIM[u]
    if _fix2_on("unit_scale_ext") and u in _FIX2_UNIT_DIM:
        return _FIX2_UNIT_DIM[u]
    return ""


def _unit_scale(u):
    """单位 → 基准单位倍率；未注册单位返回 None（调用方不得回退成 1 静默比较）。"""
    key = _unit_key(u)
    return _scale_get(key) if key else None


def _unit_known(u) -> bool:
    """单位是否已注册（含温度/压力等维度别名）；未知单位不得当作无单位数值比较。"""
    return bool(_unit_key(u)) or bool(_unit_dim(u))


def _convert(v: float, from_u: str, to_u: str):
    """同量纲换算；不同量纲/未知单位返回 None。"""
    fu = _unit_key(from_u) or (from_u or "").strip()
    tu = _unit_key(to_u) or (to_u or "").strip()
    if not fu or not tu:
        return v
    if fu == tu:
        return v
    # 温度：仿射换算，不能按乘法量表处理（℉ 184.82 → 84.9℃，阈值为 ℃ 时必须先归一）
    if _temp_kind(fu) and _temp_kind(tu):
        return _c_to_temp(_temp_to_c(v, fu), tu)
    df, dt = _unit_dim(fu), _unit_dim(tu)
    fs, ts = _scale_get(fu), _scale_get(tu)
    if df and dt and df == dt and fs is not None and ts is not None:
        return v * fs / ts
    # E06：禁止跨量纲换算（1kg 不能被当成 1000 分钟）
    return None


def _alias_names(metric: str) -> list:
    """指标名的同义写法（本体别名表），用于在原文中找回数值。"""
    names = [metric]
    try:
        from . import hooks as _hk
        _aliases, _overrides = _hk.ontology_gate_aliases()
        for canon, al in (_aliases or {}).items():
            if canon == metric or metric in [canon] + list(al):
                names.extend(al)
                names.append(canon)
        for canon, al in (_overrides or {}).items():
            if canon == metric:
                names.extend(al)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return list(dict.fromkeys([n for n in names if n]))


def _metric_names(metric: str, aliases: dict | None = None) -> list:
    """指标名候选：规则指标 + 冻结本体别名 + 金额/比例同义写法（真实合同措辞）。

    数值类规则取数的第一步不是数值，而是「原文里到底怎么写这个指标」。
    真实文件里同一个业务数值会出现：合同金额/合同价款/合同总价/合同总额/合同额、
    预付款比例/预付款支付比例/预付款、质保金比例/质量保证金、含税金额/不含税金额。
    这里只做同一指标的写法归一，不按「同类型」扩散（合同金额≠中标金额≠质保金）。
    """
    metric = str(metric or "").strip()
    if not metric:
        return []
    cands = [metric]
    for _canon, _als in (aliases or {}).items():
        if str(_canon) == metric:
            cands.extend([str(x) for x in (_als or []) if str(x).strip()])
        elif metric in [str(x) for x in (_als or [])]:
            cands.append(str(_canon))
    # 本体 v2 优先：只认「同一实体的显式别名」。
    # 注意：不能按"同类型"扩散（合同金额/预付款/质保金同属金额但不可互取，会取错数）。
    try:
        from . import hooks as _hk
        _idx = _hk.ontology_alias_index() or {}
        _ents = _hk.ontology_entities() or {}
        _etype = (_ents.get(metric) or {}).get("type") or ""
        # 日期/编号不做数值提取（否则会把年份/编号数字当金额参与比较）
        if _etype in ("日期", "编号"):
            return []
        for alias, owners in _idx.items():
            if len(alias) < 2:
                continue
            if metric in owners:
                cands.append(alias)
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 工作空间本体：自动/手动术语的启用别名，优先进入取数归一
    try:
        from . import hooks as _hk_ows
        for _a, _c in (_hk_ows.workspace_ontology_aliases() or {}).items():
            if _c == metric:
                cands.append(_a)
            elif _a == metric:
                cands.append(_c)
    except Exception:
        pass
    # 空间级本体别名：settings.ontology_aliases 形如 ["别名=规范名", ...]
    _onto_off = False
    try:
        from . import hooks as _hk2
        _cc = _hk2.context()
        _onto_off = _hk2.explicit_off(_cc.get("workspace_id", ""), "mod_ontology")
    except Exception:
        _onto_off = False
    if not _onto_off:
        try:
            from . import hooks as _hk3
            _cur_a = _hk3.context()
            _st_a = _hk3.workspace_settings(_cur_a.get("workspace_id") or "") if _cur_a.get("workspace_id") else {}
            for item in (_st_a.get("ontology_aliases") or []):
                if isinstance(item, str) and "=" in item:
                    alias_a, canon_a = [x.strip() for x in item.split("=", 1)]
                    if canon_a == metric and alias_a:
                        cands.append(alias_a)
                    elif alias_a == metric and canon_a:
                        cands.append(canon_a)
        except Exception:
            pass
    try:
        from . import hooks as _hk4
        _aliases4, _over4 = _hk4.ontology_gate_aliases()
        for canon, al in (_aliases4 or {}).items():
            if canon == metric:
                cands.extend([a for a in al if len(a) >= 3])
        for canon, al in (_over4 or {}).items():
            if canon == metric:
                cands.extend([a for a in al if len(a) >= 3])
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # 常见主体别名：养护时间→养护、付款期限→付款、投标有效期→投标有效期/有效期
    for suf in ("时间", "期限", "时长", "天数"):
        if metric.endswith(suf) and len(metric) > len(suf):
            cands.append(metric[:-len(suf)])
    # 金额/价款同义写法：合同金额→合同价款/合同总价/合同总额/合同额/预估金额…
    _base_cands = list(dict.fromkeys([c for c in cands if c]))
    for _b in _base_cands:
        for _tok in ("金额", "价款", "总价", "总额", "价", "额"):
            if _tok not in _b:
                continue
            for _rep in ("金额", "价款", "总价", "总额", "价", "额", "价税合计"):
                if _rep != _tok:
                    cands.append(_b.replace(_tok, _rep, 1))
    # 比例/费率类：去掉「比例/费率/率/上限」取主体（预付款比例→预付款、质保金比例→质保金）
    for _b in _base_cands:
        for _suf in ("比例", "费率", "日费率", "率", "上限"):
            if _b.endswith(_suf) and len(_b) > len(_suf):
                _stem = _b[:-len(_suf)]
                cands.append(_stem)
                for _suf2 in ("日", "每日"):
                    if _stem.endswith(_suf2) and len(_stem) > len(_suf2):
                        cands.append(_stem[:-len(_suf2)])
    # 含税/未税嵌入写法：合同金额→合同含税金额/合同不含税金额
    for _b in _base_cands:
        for _tok in ("金额", "价款", "总价", "总额"):
            if _tok in _b:
                cands.append(_b.replace(_tok, "含税" + _tok, 1))
                cands.append(_b.replace(_tok, "不含税" + _tok, 1))
    cands = list(dict.fromkeys([str(c).strip() for c in cands if str(c).strip()]))
    return cands


# 数值 token：阿拉伯数字（千分位/科学计数）+ 中文数字（含大写金额）
_NUM_ASCII = (r"[-−－]?(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?"
              r"|\d+(?:\.\d+)?(?:\s*[×xX]\s*10\s*[⁰¹²³⁴⁵⁶⁷⁸⁹0-9+\-]+)?)")
_CN_CLASS = re.escape(_tools.CN_NUM_CHARS)
_UNIT_ALT = (r"亿元|亿|万元|万|千元|百万元|元|美元|美金|欧元|港元|港币|英镑|日元|韩元|"
             r"USD|EUR|HKD|GBP|JPY|KRW|"
             r"(?i:mbar|kpa|mpa|hpa|pa|bar)|"
             r"千帕斯卡|兆帕斯卡|百帕斯卡|帕斯卡|千帕|兆帕|百帕|毫巴|"
             r"%(w/w)|%|℃|°C|摄氏度|℉|°F|华氏度|华氏|天|日|小时|分钟|min|h|"
             r"mg/kg|mg/g|g/kg|μg/kg|µg/kg|g/100g|g/100mL|g/100ml|g/L|g/l|"
             r"mg/L|mg/l|μg/L|µg/L|CFU/g|CFU/ml|CFU/mL|个/g|个/mL|"
             r"mg|μg|µg|kg|千克|克|毫克|g|吨|t|毫升|mL|ml|升|L|毫米|mm|厘米|cm|米")
# L39 修复补充的等价单位写法（⑤ s/秒、⑨ ppm/ppb/ug/kg、③ 兼容字符、温度「度」）。
# =0 时不进入正则（逐项回退），避免「30度」被历史规则当成单位捕获而改变旧口径。
_UNIT_ALT_FIX2 = (_UNIT_ALT + r"|秒|s|ppm|ppb|(?i:ppm|ppb)|ug/kg|度|㎏|㎎|㎝|㎜|㎖|㎥")


_V3_UNIT_ALT_EXTRA = ("件", "次", "秒")

def _unit_alt() -> str:
    alt = _UNIT_ALT_FIX2 if _fix2_on("unit_equiv") else _UNIT_ALT
    if _fix3_on("unit_vocab"):
        extra = [u for u in _V3_UNIT_ALT_EXTRA if u not in alt]
        if extra:
            alt = alt + "|" + "|".join(re.escape(u) for u in extra)
    return alt


_GAP_CLASS = "[^" + _CN_CLASS + "0-9%％。；;！？!?\\-−－]"

def _match_occurrences(name: str, norm: str) -> list:
    """单个指标名写法在归一文中的全部「指标+数值+单位」出现。"""
    pat = re.compile(
        re.escape(name) + r"(?P<gap>" + _GAP_CLASS + r"{0,20})"
        + r"(?:(?P<ratio>百分之|万分之|千分之)\s*)?"
        + r"(?:(?P<num>" + _NUM_ASCII + r")|(?P<cn>[" + _CN_CLASS + r"]+))"
        + r"\s*(?P<unit>" + _unit_alt() + r")?")
    out = []
    for m in pat.finditer(norm):
        raw_num = m.group("num") or m.group("cn") or ""
        if not raw_num:
            continue
        try:
            value = (_num(raw_num.replace(",", "")) if m.group("num")
                     else _tools.cn_number(raw_num))
        except Exception:
            value = None
        if value is None:
            continue
        ratio = m.group("ratio") or ""
        unit = m.group("unit") or ""
        if ratio:
            if ratio == "万分之":
                value = value / 100.0
            elif ratio == "千分之":
                value = value / 10.0
            unit = "%"
        out.append({"start": m.start(), "end": m.end(), "value": value,
                    "raw": raw_num, "unit": unit, "percent": (ratio == "百分之"
                                                              or unit in ("%", "%"))})
    return out


_RATE_METRIC_KEYS = ("率", "比例", "违约金", "费率")
_PENALTY_CTX_KEYS = ("违约金", "逾期", "滞纳", "罚息", "每日", "每天", "按日",
                     "日费率", "日利率", "日万分之")


def _rate_occurrences(norm: str, metric: str, names: list) -> list:
    """费率/比例类无指标名前缀的写法（每日0.03%、万分之八、按0.08%计、0.08%/日）。"""
    if not any(k in str(metric) for k in _RATE_METRIC_KEYS):
        return []
    out = []

    def _ctx_ok(pos):
        pre = norm[max(0, pos - 60):pos]
        if any(n and n in pre for n in names):
            return True
        return any(k in pre for k in _PENALTY_CTX_KEYS)

    def _push(start, end, value, quote_span=True):
        out.append({"start": start, "end": end, "value": value,
                    "raw": "", "unit": "%", "percent": True, "gap": "rate"})

    pct = r"(?P<num>\d+(?:\.\d+)?)\s*%"
    for m in re.finditer(r"(?:每[日天]|按日|日)\s*(?:按|以|为)?\s*" + pct, norm):
        if _ctx_ok(m.start()):
            _push(m.start(), m.end(), float(m.group("num")))
    for m in re.finditer(pct + r"\s*/\s*(?:日|天)", norm):
        if _ctx_ok(m.start()):
            _push(m.start(), m.end(), float(m.group("num")))
    for m in re.finditer(r"按\s*(?:每[日天]\s*)?(?P<num>\d+(?:\.\d+)?)\s*%", norm):
        if _ctx_ok(m.start()):
            _push(m.start(), m.end(), float(m.group("num")))
    for m in re.finditer(r"(?P<ratio>万分之|千分之|百分之)\s*"
                        r"(?:(?P<num>\d+(?:\.\d+)?)|(?P<cn>[" + _CN_CLASS + r"]+))", norm):
        if not _ctx_ok(m.start()):
            continue
        if m.group("cn"):
            value = _tools.cn_number(m.group("cn"))
        else:
            value = _num(m.group("num"))
        if value is None:
            continue
        ratio = m.group("ratio")
        if ratio == "万分之":
            value = value / 100.0
        elif ratio == "千分之":
            value = value / 10.0
        _push(m.start(), m.end(), value)
    return out


_MONEY_METRIC_KEYS = ("金额", "价款", "总价", "总额", "价", "额")

def _tax_labeled_occurrences(norm: str, metric: str, names: list) -> list:
    """金额类指标：原文用「含税/不含税/未税 + 数值」标注口径但省略指标名主体的情况。

    真实合同常见：「预估金额：不含税 500 万元，税率 0 %，含税 600 万元。」——
    第二个数值没有重复指标名，只有口径标签；只要同句/近邻已出现该指标名，就按口径收录。
    """
    if not any(k in str(metric) for k in _MONEY_METRIC_KEYS):
        return []
    out = []
    pat = re.compile(r"(?P<label>不含税|含税|未税)\s*"
                     + r"(?P<num>" + _NUM_ASCII + r")\s*(?P<unit>" + _unit_alt() + r")?")
    for m in pat.finditer(norm):
        pre = norm[max(0, m.start() - 48):m.start()]
        if not any(n and n in pre for n in names):
            continue
        val = _num(m.group("num").replace(",", ""))
        if val is None:
            continue
        label = m.group("label")
        out.append({"start": m.start(), "end": m.end(), "value": val,
                    "raw": m.group("num"), "unit": m.group("unit") or "",
                    "percent": (m.group("unit") or "") == "%",
                    "tax_hint": ("excluded" if label in ("不含税", "未税") else "included")})
    return out


_EVIDENCE_CONTEXT_MARKERS = {
    # 当前批次/本次实测：当前证据
    "current": ("当前", "本批", "本批次", "本次", "实测", "现批", "当批", "该批"),
    # 历史批次：历史违规不能当当前违规（C03/C01）
    "history": ("历史", "上批", "上一批", "往批", "旧批", "之前批", "上一年", "去年",
                "以往", "往期"),
    # 模板/参考/标准值：不是被测对象实测值
    "template": ("模板", "参考", "示例", "标准值", "目标值", "规定值", "要求值",
                 "示范", "样例"),
}


def _evidence_context(text: str, start: int) -> str:
    """出现位置的分句上下文：current / history / template / ""（未标注）。

    只取数值所在分句（。；;！？换行 前）内的标记，避免整份文档的「当前」字样
    污染历史条目的取数口径；无标记返回空串，调用方按未标注处理。
    """
    pre = str(text or "")[max(0, int(start or 0) - 160):int(start or 0)]
    seg = re.split(r"[。；;！？!?\n\r]", pre)[-1]
    best_kind, best_pos = "", -1
    for kind, marks in _EVIDENCE_CONTEXT_MARKERS.items():
        for mk in marks:
            pos = seg.rfind(mk)
            if pos > best_pos:
                best_kind, best_pos = kind, pos
    return best_kind


def _occurrences(metric: str, text: str, aliases: dict | None = None) -> list:
    """指标数值出现集：指标名变体 + 中文数字 + 全角归一 + 含税口径 + 费率特殊写法。

    quote 从**原文**按匹配位置切片，保证引文逐字可回查；norm 只用于匹配。
    """
    text = str(text or "")
    metric = str(metric or "")
    if not metric or not text:
        return []
    norm = _tools.canonical_numeric_text(text)
    names = _metric_names(metric, aliases)
    if not names:
        return []
    found = []
    for name in names:
        for occ in _match_occurrences(name, norm):
            occ["name"] = name
            found.append(occ)
    for occ in _rate_occurrences(norm, metric, names):
        found.append(occ)
    for occ in _tax_labeled_occurrences(norm, metric, names):
        found.append(occ)
    # 同一位置去重（同一数字被多个指标写法/特殊规则命中时只保留一条）
    found.sort(key=lambda x: (x["start"], -(x["end"] - x["start"])))
    deduped = []
    for occ in found:
        if any(not (occ["end"] <= x["start"] or occ["start"] >= x["end"]) for x in deduped):
            continue
        deduped.append(occ)
    # 引文切片 + 含税口径（口径取自指标名到数字的窗口，含数字后括号）
    for occ in deduped:
        end = occ["end"]
        tail = re.match(r"\s*(?:[（(][^）)]{0,10}[）)])?", norm[end:end + 14])
        if tail and tail.group(0).strip():
            end = end + tail.end()
        occ["end"] = end
        occ["quote"] = text[occ["start"]:end][:120]
        occ["tax"] = _tools.tax_basis_of(norm[occ["start"]:end])
        occ["tax_basis"] = (occ["tax"].get("basis")
                            or occ.pop("tax_hint", "") or "")
        # 温度先归一到 ℃，再进入比较（℉ 是仿射换算，不能乘系数）
        occ["base_value"] = _base_value(occ["value"], occ.get("unit") or "")
        # 币种：单位后缀优先；大写/小写币种码与「美元/美金」等写法统一
        cur = _tools.currency_of(occ.get("unit"))
        if not cur:
            for _tok in ("人民币", "美元", "美金", "港元", "港币", "欧元", "英镑",
                         "日元", "韩元", "USD", "CNY", "EUR", "HKD", "GBP"):
                if _tok in occ["quote"]:
                    cur = _tools.currency_of(_tok)
                    break
        occ["currency"] = cur
        # 批次上下文：当前/历史/模板，供限值类规则做「当前证据选择」
        occ["context"] = _evidence_context(text, occ["start"])
    return deduped


def _unit_group(unit: str) -> str:
    u = str(unit or "")
    if u == "%":
        return "percent"
    if u in ("元", "万元", "亿元", "千元", "百万元", "万", "亿", "价税合计") \
            or _tools.currency_of(u):
        return "money"
    return _unit_dim(u) or ""


def _occ_unit_compatible(occ: dict, rule_unit: str) -> bool:
    """出现值的单位能否与规则单位比较；无单位数据不硬套规则单位（返回 False）。"""
    ru = str(rule_unit or "")
    ou = str(occ.get("unit") or "")
    if not ru:
        return True
    if not ou:
        # 原文数值未标单位：保持历史口径（按规则单位直接比较），不因缺单位丢结果；
        # 显式单位冲突（如规则 %、文中金额）仍在上面的分支返回 False。
        return True
    if ru == "%":
        return ou == "%"
    if _unit_group(ru) == "money":
        return _unit_group(ou) == "money"
    return bool(_convert(1.0, ou, ru) is not None) or ou == ru


def _from_text(metric: str, text: str, aliases: dict | None = None):
    """事实里取不到时，直接从原文按「指标 + 数值 + 单位」取（覆盖『采购金额12万元』这类写法）。

    归一内容：金额同义写法（合同价款/合同总价/合同额）、含税/未税嵌入写法、
    中文数字/大写金额、全角数字、单位换行；aliases 为冻结本体别名快照。
    当前/历史/模板并存时优先当前证据（历史/模板值不得当当前实测值）。
    """
    occs = _occurrences(metric, text, aliases=aliases)
    if not occs:
        return None, None
    best = next((o for o in occs if o.get("context") in ("current", "")), occs[0])
    _q = best.get("quote")
    # 未知单位（如 40XYZ）不在 _UNIT_ALT 中；把值后的字母 token 保留到引文，
    # 供上层 tool_trace 判 unit_unknown，不能静默当作无单位数值 ok。
    try:
        _tail = text[int(best.get("end") or 0): int(best.get("end") or 0) + 16]
        _m = re.match(r"\s*([A-Za-zμµ]+(?:/[0-9A-Za-zμµ]+)?)", _tail or "")
        if _m and not _unit_known(_m.group(1)):
            _q = (_q or "") + _m.group(0).strip()
    except Exception:
        pass
    return best.get("base_value"), _q


_UNIT_TAIL_RE = re.compile(r"\s*([A-Za-zμµ]+(?:/[0-9A-Za-zμµ]+)?)")
# L39 ②：数值后的中文量词/混合 token（份/格/勺/码/档/级/刻度/单位A/#UNK…）。
# 只在规则显式声明 unknown_unit_policy=insufficient 且修复开启时启用，避免给既有
# 规则引入「数后中文词=未知单位」的误判（如「保温35分钟后」的单位已在上游捕获）。
_UNIT_TAIL_CJK_RE = re.compile(r"\s*(#\s?[A-Za-z0-9_]+|[\u4e00-\u9fffA-Za-zμµ]"
                               r"[\u4e00-\u9fffA-Za-z0-9μµ#]{0,3})")


def _unknown_unit_tail(text: str, occ: dict, policy: str = "") -> str:
    """数值后紧跟的未注册单位 token（如 40XYZ / 260份 / 290#UNK）；无则返回空串。

    与 ``_from_text`` 的 unit_unknown 口径一致：未知单位不得静默当作「无单位数值」
    参与比较（不能猜成通过），已注册单位在 _occurrences 中已作为 unit 捕获，不会到这里。

    L39 ②：``policy=="insufficient"`` 且修复开启时，追加识别中文量词/``#`` 前缀 token；
    该分支仅为声明了 unknown_unit_policy 的规则启用（无声明规则行为不变）。
    """
    if str(occ.get("unit") or ""):
        return ""
    try:
        end = int(occ.get("end") or 0)
    except (TypeError, ValueError):
        return ""
    hay = str(text or "")
    m = _UNIT_TAIL_RE.match(hay[end:end + 16])
    if m:
        token = m.group(1)
        return "" if _unit_known(token) else token
    if str(policy or "").strip().lower() == "insufficient" and _fix2_on("unknown_unit"):
        m2 = _UNIT_TAIL_CJK_RE.match(hay[end:end + 16])
        if m2:
            token = re.sub(r"\s+", "", m2.group(1))
            if token and not _unit_known(token):
                return token
    return ""


_DATE_RE = re.compile(r"(\d{4})\s*[-/年.]\s*(\d{1,2})\s*[-/月.]\s*(\d{1,2})")
_CODE_RE = re.compile(r"[A-Za-z0-9\-_/]{4,40}")


def _parse_date(s: str):
    m = _DATE_RE.search(s or "")
    if not m:
        return None
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if not (1 <= mo <= 12 and 1 <= d <= 31):
        return None
    return (y, mo, d)


def _entity_type(metric: str) -> str:
    try:
        from . import hooks as _hk
        ents = _hk.ontology_entities() or {}
        return (ents.get(str(metric)) or {}).get("type") or ""
    except Exception:
        return ""


def _metric_aliases(metric: str) -> list:
    try:
        from . import hooks as _hk
        idx = _hk.ontology_alias_index() or {}
        ents = _hk.ontology_entities() or {}
        et = (ents.get(str(metric)) or {}).get("type") or ""
        sib = {k for k, v in ents.items() if et and v.get("type") == et}
        out = [metric]
        for a, owners in idx.items():
            if str(metric) in owners or (set(owners) & sib):
                out.append(a)
        return list(dict.fromkeys([x for x in out if x]))
    except Exception:
        return [metric]


def _judge_date(slots: dict, text: str) -> dict:
    """日期类：从原文取日期，与规则日期比较（op 支持 <= >= = < >）。"""
    target = _parse_date(str(slots.get("value") or ""))
    if not target:
        return {"state": "执行失败", "detail": "规则日期无法解析", "quote": "", "value": None}
    for a in _metric_aliases(str(slots.get("metric"))):
        for m in re.finditer(re.escape(a), text or ""):
            seg = (text or "")[m.start(): m.start() + 80]
            got = _parse_date(seg)
            if got:
                op = str(slots.get("op") or "<=")
                ok = {"<=": got <= target, ">=": got >= target, "=": got == target,
                      "<": got < target, ">": got > target}.get(op, False)
                return {"state": "满足" if ok else "不满足",
                        "detail": f"{a}={got} {op} {target}", "quote": seg[:60], "value": got}
    return {"state": "证据不足", "detail": "原文未取到可解析日期", "quote": "", "value": None}


def _judge_code(slots: dict, text: str) -> dict:
    """编号类：只做一致性比对（相等/包含），不做数值比较。"""
    want = str(slots.get("value") or "").strip()
    if not want:
        return {"state": "执行失败", "detail": "规则编号为空", "quote": "", "value": None}
    for a in _metric_aliases(str(slots.get("metric"))):
        m = re.search(re.escape(a) + r"[^A-Za-z0-9]{0,6}([A-Za-z0-9\-_/]{4,40})", text or "")
        if m:
            got = m.group(1)
            ok = (got == want) if str(slots.get("op") or "=") == "=" else (want in got)
            return {"state": "满足" if ok else "不满足",
                    "detail": f"{a}={got} vs 规则 {want}", "quote": m.group(0)[:60], "value": got}
    return {"state": "证据不足", "detail": "原文未取到编号", "quote": "", "value": None}


_CONTEXT_SCOPE_KEYS = ("evidence_context", "context_scope", "evidence_window")

def _context_scope_of(slots: dict) -> str:
    raw = ""
    for k in _CONTEXT_SCOPE_KEYS:
        if (slots or {}).get(k) not in (None, ""):
            raw = str(slots.get(k))
            break
    v = raw.strip().lower()
    if v in ("current", "current_only", "current_batch", "当前", "当前批次", "本批"):
        return "current"
    return ""


def _select_evidence_context(slots: dict, occs: list) -> dict:
    """当前证据选择：规则声明「只审当前批次」时，历史/模板值不得当当前证据。

    返回 {}（未声明/无需过滤）；{"occs": [...]}（过滤后的取数集）；
    {"insufficient": True, ...}（只有历史/模板值，证据不足）。
    """
    if _context_scope_of(slots) != "current":
        return {}
    contexts = [str(o.get("context") or "") for o in occs]
    cur = [o for o in occs if o.get("context") == "current"]
    neutral = [o for o in occs if not o.get("context")]
    if cur:
        # 有当前实测值：历史/模板值不参与比较（未标注值保留，避免误伤无标记的真实值）
        kept = [o for o in occs if o.get("context") in ("current", "")]
        return {"occs": kept or cur, "contexts": contexts}
    if neutral:
        return {"occs": neutral, "contexts": contexts}
    flagged = [o for o in occs if o.get("context") in ("history", "template")]
    if flagged:
        sample = flagged[0]
        kinds = "、".join(sorted({str(o.get("context")) for o in flagged}))
        return {"insufficient": True,
                "detail": (f"原文只有{kinds}值（{sample.get('quote') or ''}），"
                           "不是当前批次实测证据，不能据此判定"),
                "quote": sample.get("quote") or "", "value": sample.get("value"),
                "contexts": contexts}
    return {}


def _currency_gate(slots: dict, text: str, rule_unit: str, compat: list) -> dict:
    """币种口径门禁：外币金额缺「显式汇率 + 换算时点」→ 证据不足。

    规则以人民币（元/万元…）为阈值时，美元/欧元等外币金额未经汇率折算不得
    直接与人民币阈值比较（A09）；有完整汇率+时点时按汇率折算后再比较。
    """
    rule_ccy = _tools.currency_of(rule_unit)
    if not rule_ccy or _unit_group(rule_unit) != "money":
        return {}
    foreign = [o for o in compat if o.get("currency") and o["currency"] != rule_ccy]
    if not foreign:
        return {}
    fx = _tools.fx_rate_evidence(text)
    if not fx.get("complete"):
        labels = {"rate": "汇率", "time_point": "换算时点"}
        miss = "、".join(labels.get(x, x) for x in (fx.get("missing") or []))
        sample = foreign[0]
        return {"insufficient": True,
                "detail": (f"外币金额（{sample.get('value')}{sample.get('unit') or ''}）"
                           f"缺少{miss or '汇率/换算时点'}，不能按人民币阈值直接比较"),
                "quote": sample.get("quote") or "", "value": sample.get("value")}
    try:
        rate = float(fx.get("rate"))
    except (TypeError, ValueError):
        rate = None
    if not rate:
        sample = foreign[0]
        return {"insufficient": True,
                "detail": "外币金额的汇率无法解析，证据不足",
                "quote": sample.get("quote") or "", "value": sample.get("value")}
    converted = []
    for o in compat:
        o2 = dict(o)
        if o.get("currency") and o["currency"] != rule_ccy:
            o2["base_value"] = float(o.get("value")) * rate
            o2["fx_rate"] = rate
            o2["fx_time_point"] = fx.get("time_point")
            o2["fx_converted_from"] = o.get("currency")
        converted.append(o2)
    return {"occs": converted, "fx": fx}


# ---------------------------------------------------------------------------
# L42 ① 文本路径对象绑定（RULEPROOF_EXEC_FIXES_V3=1 生效；=0 回退整篇取数）
#
# 背景（L32 报告 §3/§6.1）：D4 文本路径把**整篇**文档按 metric 取数，`_judge_limit_from_text`
# 又要求「同一指标 N 处取值每一处都满足」→ 同一 metric 的多对象取值被合并成一个事实集合，
# 一个对象的超限值把另一个对象的合规值判成不满足（clean 100/100 误报根因）。
# 口径：规则声明 object/subject（2–20 字、无句读/空白；或显式 object_bind 标记）时，
# 文本路径只保留**该对象所在行**再取数判定；全文没有该对象 → 不适用（不是证据不足，
# 也不是违规）；=0 时不绑定，行为与历史一致。
# ---------------------------------------------------------------------------
_V3_OBJECT_SLOT_KEYS = ("object", "subject")
_V3_OBJECT_BAD_CHARS = re.compile(r"[\s，,。；;：:、！？!?\n\r]")


def _v3_object_key(slots: dict) -> str:
    """规则声明且可用于文本路径绑定的对象名；未声明/不满足形态返回空串。"""
    if not isinstance(slots, dict):
        return ""
    forced = bool(slots.get("object_bind"))
    for k in _V3_OBJECT_SLOT_KEYS:
        v = str(slots.get(k) or "").strip()
        if not v:
            continue
        if forced:
            return v
        if 2 <= len(v) <= 20 and not _V3_OBJECT_BAD_CHARS.search(v):
            return v
    return ""


def _v3_object_bind(slots: dict, text: str) -> dict:
    """文本路径对象绑定。

    返回 {"active": bool, "key": str, "absent": bool, "text": str}：
    - active=False：未启用/规则未声明对象 → 调用方保持历史整篇取数；
    - absent=True：声明了对象但原文没有任何该对象所在行 → 不适用；
    - 否则 text=只含该对象的行（行序保持）。
    """
    key = _v3_object_key(slots)
    body = str(text or "")
    if not key or not body:
        return {"active": False, "key": key}
    kept = [ln for ln in body.splitlines(keepends=True) if key in ln]
    if not kept:
        return {"active": True, "key": key, "absent": True, "text": ""}
    return {"active": True, "key": key, "absent": False, "text": "".join(kept)}


def _v3_line_of(text: str, pos) -> str:
    """原文位置所在行（用于 scope 文本过滤；位置非法回退整篇）。"""
    body = str(text or "")
    try:
        p = max(0, min(int(pos or 0), len(body)))
    except (TypeError, ValueError):
        return body
    start = body.rfind("\n", 0, p) + 1
    end = body.find("\n", p)
    return body[start:end if end >= 0 else len(body)]


# ---------------------------------------------------------------------------
# L62 W5（2026-11-24）算子语义规格修复（统一开关 RULEPROOF_OPERATOR_SPEC_FIX，默认 1）
#   依据：docs/CURRENT/75-算子语义规格_20261124.md（L45 B1/B2/B3 + 外部评审 P0-A）
#   B1 区间端点：原文「0-8℃」是区间，不是单值 0；上界比较取上限 8、下界比较取下限 0，
#      range 判据按「区间包含」判定（lo>=要求下限 且 hi<=要求上限）。
#   B2 上下文作用域：同指标多处取值时按「分句上下文」选择规则 scope 命中处；分句无命中
#      再回退到整行（历史口径）；scope 在原文存在但无任何取值落在其上下文中 → 证据不足
#      （不静默把所有取值都当本规则对象）。scope 在全文都不存在时保留历史整篇口径。
#   B3 精确比较：`==`/`≠` 归一为 `=`/`!=`（单位归一后按数值精确比较；区间 vs 精确值
#      跨过目标 → 证据不足；文本包含类判据不支持精确算子 → fail-closed）。
#   P0-A 单位/数值有效性（外部评审 F1）：缺计量单位且规则未显式声明
#      missing_unit_policy=inherit → 证据不足；未知单位（个/份/箱…#TOKEN）→ 证据不足；
#      NaN/Inf/非有限数 → 证据不足；显式 inherit 且来源可证才继承规则单位并记录
#      unit_source（rule_slot/frozen_alias/conversion_table）。
#   =0 时上述语义全部逐项回退到历史行为（供 A/B 与回滚）。
# ---------------------------------------------------------------------------
_OPSPEC_FIX_ENV = "RULEPROOF_OPERATOR_SPEC_FIX"
_OPSPEC_INHERIT_SOURCES = ("rule_slot", "frozen_alias", "conversion_table")
# 非量纲计数/包装单位（外部评审 P0-A 例举）：数值后紧跟这些 token 视为未知单位，
# 不按规则单位静默比较。只枚举明确的计数/包装量词，避免把「以上/以下/左右」等
# 语义后缀误判成单位。
_OPSPEC_UNKNOWN_UNIT_TOKENS = (
    "个", "份", "箱", "包", "袋", "瓶", "罐", "盒", "桶", "支", "根", "片",
    "块", "只", "条", "张", "台", "套", "批", "杯", "碗", "盘", "捆", "组",
    "对", "双", "打", "令", "卷", "筒", "档", "级", "人", "户", "笔", "项",
)
_OPSPEC_RANGE_SEP = r"[-~～〜至到—–－]"
_OPSPEC_CLAUSE_BOUNDARY = "。；;！？!?\n\r，,|｜"


def _opspec_fix_on(item: str = "") -> bool:
    """L62 算子语义规格修复统一开关（默认 1；=0 全部回退历史行为）。"""
    try:
        return str(os.environ.get(_OPSPEC_FIX_ENV, "1")).strip().lower() not in (
            "0", "false", "off", "no")
    except Exception:
        return True


def _opspec_finite(v) -> bool:
    """数值是否有限（NaN/Inf → False；非数值 → False）。"""
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError, OverflowError):
        return False


# ---------------------------------------------------------------------------
# L86（2026-11-24，外部复验报告 HEAD96eb3be §7 P0-2）事实身份 + 单位来源
#   把「比较执行器必须带单位来源、非有限数不得进入裁决」从单点（judge_limit，L62）
#   扩到 ruleexec 的其余比较入口（跨表聚合/比较原语、文本级跨位置/合计算术、
#   spec 限值执行器），并给全部数值比较结论回填 unit_source 供复核追溯：
#     unit_source = rule_slot（规则槽位单位）/ frozen_alias（冻结别名）/
#                   conversion_table（换算表换算）
#   缺来源（规则有单位、事实无单位且无合法继承来源）→ 证据不足；
#   NaN/Inf 等非有限数（事实/阈值/汇总值/比较值）→ 证据不足（不得落成 满足/不满足）。
#   统一开关 RULEPROOF_FACT_IDENTITY_FIX（默认 1；=0 逐项回退历史行为）。
#   注：judge_limit 的缺单位/未知单位/非有限 fail-closed 语义由 L62 P0-A
#   （RULEPROOF_OPERATOR_SPEC_FIX）承载；本开关负责事实身份（parse_bridge）+
#   其余比较入口 + unit_source 追溯，=0 不回退 L62（两者独立，便于分项 A/B）。
# ---------------------------------------------------------------------------
# 与 rule_ir2 / parse_bridge 同口径的单位来源白名单（规则槽位/冻结别名/换算表）。
_UNIT_SOURCE_ALLOWED = ("rule_slot", "frozen_alias", "conversion_table")


def _fact_identity_fix_on() -> bool:
    """L86 事实身份/单位来源修复开关（默认 1；=0/false/off/no 回退历史行为）。"""
    try:
        return str(os.environ.get("RULEPROOF_FACT_IDENTITY_FIX", "1")).strip().lower() \
            not in ("0", "false", "off", "no")
    except Exception:
        return True


def _finite_num(v) -> bool:
    """数值是否有限（NaN/Inf/非数值 → False；数值字符串按既有 _num 口径解析）。"""
    try:
        f = float(v) if isinstance(v, (int, float)) else _num(v)
    except (TypeError, ValueError, OverflowError):
        return False
    return f is not None and math.isfinite(f)


def _unit_source_tag(fact_unit, rule_unit, declared="") -> str:
    """比较所用单位的来源：显式声明优先；同键单位=规则槽位；跨单位换算=换算表。"""
    declared = str(declared or "").strip().lower()
    if declared in _UNIT_SOURCE_ALLOWED:
        return declared
    kf, kt = _unit_key(fact_unit), _unit_key(rule_unit)
    if kf and kt:
        return "rule_slot" if kf == kt else "conversion_table"
    return "rule_slot"


def _tag_unit_source(res: dict, rule_unit: str, fact_units=(), declared="",
                     inherited=()) -> dict:
    """给比较结论回填 unit_source（L86；仅开关开启且涉及单位时），不改变 state。

    - 有继承（L62 missing_unit_policy=inherit）→ 用继承时记录的来源；
    - 事实单位与规则单位同键 → ``rule_slot``；
    - 发生过跨单位换算 → ``conversion_table``；
    - 规则单位为空/无单位参与 → 不标（unitless 比较不虚构来源）。
    """
    if not _fact_identity_fix_on() or not isinstance(res, dict):
        return res
    rule_unit = str(rule_unit or "")
    declared = str(declared or "").strip().lower()
    inh = [str(x) for x in inherited if str(x or "").strip() in _UNIT_SOURCE_ALLOWED]
    if inh:
        res.setdefault("unit_source", inh[0])
        return res
    if not rule_unit:
        return res
    if res.get("state") not in ("满足", "不满足"):
        return res
    units = [str(u or "") for u in fact_units]
    if units and any(u and _unit_key(u) != _unit_key(rule_unit) for u in units):
        # 发生事实单位 → 规则单位换算：单位来源是换算表（与规则槽位/冻结别名的来源正交）。
        res["unit_source"] = "conversion_table"
    else:
        res["unit_source"] = declared if declared in _UNIT_SOURCE_ALLOWED else "rule_slot"
    return res



def _opspec_rule_dim(rule_unit: str) -> str:
    """规则单位的量纲：temp/time/conc/mass/weight/vol/len/pressure/percent/money…"""
    u = str(rule_unit or "")
    if not u:
        return ""
    dim = _unit_dim(u)
    if dim:
        return dim
    group = _unit_group(u)
    if group:
        return group
    return "known" if _unit_known(u) else ""


def _opspec_unknown_unit_tail(text: str, occ: dict) -> str:
    """数值后紧跟的未注册单位 token（中文计数/包装单位、#TOKEN）；无则空串。"""
    if str(occ.get("unit") or ""):
        return ""
    try:
        end = int(occ.get("end") or 0)
    except (TypeError, ValueError):
        return ""
    hay = str(text or "")
    m = re.match(r"\s*(#\s?[A-Za-z0-9_]+)", hay[end:end + 16])
    if m:
        return re.sub(r"\s+", "", m.group(1))
    m2 = re.match(r"\s*([\u4e00-\u9fff]{1,3})", hay[end:end + 16])
    if m2:
        tok = m2.group(1)
        for u in _OPSPEC_UNKNOWN_UNIT_TOKENS:
            if tok.startswith(u):
                return u
    return ""


def _opspec_range_tail_re():
    """区间尾正则（第二个端点，可带单位）：复用当前单位词表，保持全半角/兼容字符口径。"""
    return re.compile(
        r"^\s*" + _OPSPEC_RANGE_SEP + r"\s*(?P<num>[-−－]?\d+(?:\.\d+)?)\s*"
        r"(?P<unit>" + _unit_alt() + r")?")


def _opspec_expand_range(occ: dict, text: str, norm: str, rule_unit: str) -> dict:
    """把「指标 + 首端点」出现扩成「指标 + 区间 [lo, hi]」出现；非区间原样返回。

    B1 根因：正则只取到区间首端点（0-8℃ 取 0），区间语义丢失后上界漏判。
    """
    if occ.get("range_hi") is not None:
        return occ
    try:
        end = int(occ.get("end") or 0)
    except (TypeError, ValueError):
        return occ
    m = _opspec_range_tail_re().match(norm[end:])
    if not m:
        return occ
    hi = _num(m.group("num"))
    lo = occ.get("value")
    if hi is None or lo is None or not _opspec_finite(lo) or not _opspec_finite(hi):
        return occ
    unit = str(occ.get("unit") or m.group("unit") or "")
    # 只对「有量纲的测量量」启用区间语义（日期/编号/纯计数不扩），且首尾端点不能倒置。
    dim = _unit_dim(unit) or _opspec_rule_dim(rule_unit) or _unit_group(unit)
    if not dim:
        return occ
    if float(lo) > float(hi):
        return occ
    # 日期误判保护：4 位年份 + 月份不是温度/浓度/时长区间（如 2026-08）
    raw_lo = str(occ.get("raw") or "").strip()
    if (len(raw_lo) == 4 and raw_lo.isdigit() and 1900 <= float(lo) <= 2100
            and 1 <= float(hi) <= 12 and m.group(0).strip().startswith("-")):
        return occ
    o2 = dict(occ)
    o2["is_range"] = True
    o2["range_lo"] = float(lo)
    o2["range_hi"] = float(hi)
    o2["range_sep"] = m.group(0).strip()
    o2["unit"] = unit
    o2["base_value"] = _base_value(lo, unit) if unit else None
    o2["base_lo"] = _base_value(lo, unit) if unit else None
    o2["base_hi"] = _base_value(hi, unit) if unit else None
    _end2 = end + m.end()
    o2["end"] = _end2
    o2["raw"] = (raw_lo + m.group(0).strip())[:40]
    o2["quote"] = text[int(occ.get("start") or 0):_end2][:120]
    return o2


def _opspec_clause_of(text: str, pos) -> str:
    """位置所在分句（。；;！？!?换行/逗号/竖线 为边界），用于 B2 上下文选择。"""
    body = str(text or "")
    try:
        p = max(0, min(int(pos or 0), len(body)))
    except (TypeError, ValueError):
        return body
    start = 0
    for i in range(p - 1, -1, -1):
        if body[i] in _OPSPEC_CLAUSE_BOUNDARY:
            start = i + 1
            break
    end = len(body)
    for i in range(p, len(body)):
        if body[i] in _OPSPEC_CLAUSE_BOUNDARY:
            end = i
            break
    return body[start:end]


def _opspec_units_gate(slots: dict, occs: list, text: str, rule_unit: str) -> dict:
    """P0-A 单位/数值有效性门禁：返回 {}（放行）或证据不足结果。

    - 未知单位（含中文计数/包装量词、#TOKEN）→ 证据不足；
    - 缺计量单位：默认证据不足（不按规则单位静默比较）；显式
      missing_unit_policy=inherit 且规则单位可证（unit_source 合法）才继承；
    - 数值 NaN/Inf/非有限 → 证据不足；
    - 继承时逐条记录 unit_source（rule_slot/frozen_alias/conversion_table）。
    """
    if not (_opspec_fix_on("unit_strict") and _fix2_on("missing_unit")):
        return {}
    rule_unit = str(rule_unit or "")
    if not rule_unit:
        return {}
    rule_dim = _opspec_rule_dim(rule_unit)
    if not rule_dim:
        # 规则单位未注册（如自定义单位）→ 不在此层猜，交既有 _occ_unit_compatible 处理
        return {}
    policy = str(slots.get("missing_unit_policy") or "").strip().lower()
    unit_source = str(slots.get("unit_source") or "").strip().lower() or "rule_slot"
    if unit_source not in _OPSPEC_INHERIT_SOURCES:
        return {"state": "证据不足",
                "detail": (f"单位继承来源不可证：unit_source={unit_source!r} 不在白名单 "
                           f"{list(_OPSPEC_INHERIT_SOURCES)}，不猜单位"),
                "quote": "", "value": None, "unit_source_blocked": True}
    out, inherited = [], 0
    for occ in occs:
        o = dict(occ or {})
        if not _opspec_finite(o.get("value")):
            return {"state": "证据不足",
                    "detail": f"数值非有限（NaN/Inf 或非数值 {o.get('value')!r}），不参与判定",
                    "quote": o.get("quote") or "", "value": o.get("value"),
                    "non_finite_blocked": True}
        if o.get("is_range") and (not _opspec_finite(o.get("range_lo"))
                                  or not _opspec_finite(o.get("range_hi"))):
            return {"state": "证据不足",
                    "detail": "区间端点非有限数（NaN/Inf），不参与判定",
                    "quote": o.get("quote") or "", "value": o.get("range_hi"),
                    "non_finite_blocked": True}
        unit = str(o.get("unit") or "")
        if unit:
            if not (_unit_known(unit) or _temp_kind(unit)):
                return {"state": "证据不足",
                        "detail": (f"未知单位：{unit}（规则单位 {rule_unit} 无法换算，"
                                   "不猜单位、不产生 pass/fail）"),
                        "quote": o.get("quote") or "", "value": o.get("value")}
            out.append(o)
            continue
        unk = _opspec_unknown_unit_tail(text, o)
        if unk:
            return {"state": "证据不足",
                    "detail": (f"未知单位：{unk}（非量纲计数/包装单位，规则单位 {rule_unit} "
                               "无法换算，不猜单位、不产生 pass/fail）"),
                    "quote": o.get("quote") or "", "value": o.get("value"),
                    "unknown_unit_blocked": True}
        if policy == "inherit":
            if not _unit_known(rule_unit):
                return {"state": "证据不足",
                        "detail": f"规则单位 {rule_unit} 未注册，无法作为继承来源",
                        "quote": o.get("quote") or "", "value": o.get("value"),
                        "unit_source_blocked": True}
            o["unit"] = rule_unit
            o["unit_source"] = unit_source
            o["unit_inherited"] = True
            o["base_value"] = _base_value(o.get("value"), rule_unit)
            if o.get("is_range"):
                o["base_lo"] = _base_value(o.get("range_lo"), rule_unit)
                o["base_hi"] = _base_value(o.get("range_hi"), rule_unit)
            out.append(o)
            inherited += 1
            continue
        return {"state": "证据不足",
                "detail": (f"缺计量单位：原文「{(str(o.get('quote') or '')[:40])}」仅给数值 "
                           f"{o.get('value')}，未标 {rule_unit} 或其他可换算单位；"
                           "默认不猜单位（显式 missing_unit_policy=inherit 才继承并记录来源）"),
                "quote": o.get("quote") or "", "value": o.get("value"),
                "missing_unit_blocked": True,
                "unit_source_missing": bool(_fact_identity_fix_on())}
    result = {"occs": out}
    if inherited:
        result["unit_inherited"] = inherited
    return result


def _opspec_compare_one(o: dict, op: str, target_base, lo_base, hi_base) -> bool | None:
    """单条出现（含区间出现）按算子比较：True/False；None = 无法确定（精确值跨区间）。"""
    is_range = bool(o.get("is_range")) and _opspec_fix_on("range_endpoint")
    lo_v = o.get("base_lo") if is_range else o.get("base_value")
    hi_v = o.get("base_hi") if is_range else o.get("base_value")
    if not _opspec_finite(lo_v) or not _opspec_finite(hi_v):
        return None
    if op == "range":
        # 区间包含：原文区间必须整体落在判据区间内（下界取下限、上界取上限）
        return bool(lo_v >= lo_base and hi_v <= hi_base)
    if op in (">=", "≥"):
        return _cmp(lo_v, op, target_base)
    if op in (">",):
        return _cmp(lo_v, op, target_base)
    if op in ("<=", "≤"):
        return _cmp(hi_v, op, target_base)
    if op in ("<",):
        return _cmp(hi_v, op, target_base)
    if op in ("=", "=="):
        if is_range and float(lo_v) != float(hi_v):
            if target_base < lo_v or target_base > hi_v:
                return False
            return None
        return _cmp(lo_v, op, target_base)
    if op in ("!=", "≠"):
        if is_range and float(lo_v) != float(hi_v):
            if target_base < lo_v or target_base > hi_v:
                return True
            return None
        return _cmp(lo_v, op, target_base)
    return _cmp(lo_v, op, target_base)


_OPSPEC_CONTEXT_LABELS = (
    "出锅", "冷却", "暂存", "冷藏", "冷冻", "解冻", "加热", "熟制", "消毒",
    "清洗", "焯水", "油炸", "煎制", "蒸煮", "炒制", "杀菌", "灭菌", "包装",
    "烘烤", "焙烤",
)


def _opspec_context_conflict(text: str, occs: list) -> list:
    """B2：无 scope 时检测「同指标多处取值分属不同工序上下文」——返回冲突标签组。

    只对温度/时间/浓度这类「同指标在不同工序取值语义不同」的物理量启用；
    每个出现取所在分句的工序标签集合，若存在两个非空且互不相交的集合，
    说明同一 metric 混了工序语义（出锅 85℃ vs 冷却 10℃），无法确定规则对象。
    """
    label_sets = []
    for o in occs:
        clause = _opspec_clause_of(text, o.get("start"))
        labels = {lb for lb in _OPSPEC_CONTEXT_LABELS if lb in clause}
        if labels:
            label_sets.append((o, labels))
    for i in range(len(label_sets)):
        for j in range(i + 1, len(label_sets)):
            a, b = label_sets[i][1], label_sets[j][1]
            if a and b and a.isdisjoint(b):
                return [sorted(a), sorted(b)]
    return []


def _judge_limit_from_text(slots: dict, text: str, aliases, target, op: str,
                           meta: dict | None = None) -> dict:
    """原文取数判定（事实层无该指标时）：多写法/多口径归一后逐项校验。

    口径（P0 业务有效性）：
    - 同一指标在原文有 N 处数值时，限值类要求**每一处**都满足；任一处超限即「不满足」，
      引文取第一处超限值（分段费率/多行披露都按此判定，不静默丢后一处）；
    - 规则显式声明 tax_basis（含税/未税）时只比较同口径数值；原文没标口径 → 证据不足，
      不猜、不默认 13% 换算；
    - 规则未声明口径但原文含税/未税并存 → 证据不足转人工（避免混口径误判）；
    - 单位不匹配（规则 %、文中金额等）→ 证据不足，不硬比。
    """
    metric = str(slots.get("metric") or "")
    rule_unit = str(slots.get("unit") or "")
    want_basis = _tools.normalize_tax_request(
        slots.get("tax_basis") if slots.get("tax_basis") not in (None, "")
        else slots.get("tax_included"))
    occs = _occurrences(metric, text, aliases=aliases)
    if not occs:
        return {"state": "证据不足",
                "detail": f"文档中未找到「{metric}」相关数值", "quote": "", "value": None}
    # 当前证据选择（规则声明 evidence_context=current 时）：历史/模板值不是当前实测证据。
    # 有当前证据 → 只用当前（+未标注）；只有历史/模板值 → 证据不足，不改判合规/违规。
    ctx_out = _select_evidence_context(slots, occs)
    if ctx_out.get("insufficient"):
        return {"state": "证据不足", "detail": ctx_out["detail"],
                "quote": ctx_out.get("quote") or "", "value": ctx_out.get("value"),
                "context_blocked": True, "contexts": ctx_out.get("contexts") or []}
    if ctx_out.get("occs") is not None:
        occs = ctx_out["occs"]
    # L42 scope_text：文本路径补事实路径 scope 过滤同口径（同一作用域关键词只在所在行取数）。
    # 过滤后为空时**不静默丢数**（回退全量并留痕），与事实路径「无匹配事实 → 回退文本」一致。
    # L62 B2：行内同指标多处时按**分句上下文**再收窄到 scope 命中分句；scope 在原文存在但
    # 无任何取值落在其上下文 → 证据不足（不把冷却段 10℃ 当出锅 85℃ 判）。
    if _fix3_on("scope_text"):
        _scope_kw = str(slots.get("scope") or "").strip()
        if _scope_kw:
            _line_scoped = [o for o in occs
                            if _scope_kw in _v3_line_of(text, o.get("start"))]
            if _opspec_fix_on("context_scope"):
                _clause_scoped = [o for o in occs
                                  if _scope_kw in _opspec_clause_of(text, o.get("start"))]
                if _clause_scoped:
                    occs = _clause_scoped
                elif _line_scoped:
                    occs = _line_scoped
                elif _scope_kw in str(text or ""):
                    return {"state": "证据不足",
                            "detail": (f"作用域「{_scope_kw}」在原文存在，但「{metric}」的"
                                       f"取值均不在该作用域分句/行内，无法确定应取哪一处"
                                       "（不静默取任一/最后一处，不猜）"),
                            "quote": "", "value": None, "scope_unbound": True}
                # scope 关键词整篇不存在 → 保留历史整篇取数口径（L42 2.4 兼容）
            elif _line_scoped:
                occs = _line_scoped
    # L62 B2（无 scope 声明）：同指标多处取值若分属不同工序上下文（出锅 vs 冷却），
    # 规则无法确定取哪一处 → 证据不足，不静默取任一处；无冲突时保留历史「每处均须满足」。
    if (_opspec_fix_on("context_scope") and not str(slots.get("scope") or "").strip()
            and len(occs) > 1
            and _opspec_rule_dim(rule_unit) in ("temp", "time", "conc")):
        _ctx_conflict = _opspec_context_conflict(text, occs)
        if _ctx_conflict:
            return {"state": "证据不足",
                    "detail": (f"同指标「{metric}」多处取值分属不同工序上下文"
                               f"（{' / '.join('/'.join(g) for g in _ctx_conflict)}），"
                               "规则未声明 scope，无法确定应取哪一处；不静默取任一/最后一处，"
                               "请补充 scope 或按上下文拆分规则"),
                    "quote": "", "value": None, "scope_ambiguous": True,
                    "context_labels": _ctx_conflict}
    # L62 B1：区间端点扩写（0-8℃ 不是单值 0）。只对有量纲测量量生效。
    if _opspec_fix_on("range_endpoint") and occs:
        _norm = _tools.canonical_numeric_text(text)
        occs = [_opspec_expand_range(o, text, _norm, rule_unit) for o in occs]
    # L62 P0-A 单位/数值有效性门禁（缺单位/未知单位/NaN/Inf → 证据不足；显式 inherit 才继承）
    _opspec_units = _opspec_units_gate(slots, occs, text, rule_unit)
    if _opspec_units.get("state") == "证据不足":
        return _opspec_units
    if _opspec_units.get("occs") is not None:
        occs = _opspec_units["occs"]
    # 未知单位 fail-closed：规则声明的单位有量纲时，原文数值后紧跟未注册单位
    # （如 40XYZ）不得按「无单位数值」直接比较，转证据不足。
    _unknown_policy = str(slots.get("unknown_unit_policy") or "").strip().lower()
    _missing_policy = str(slots.get("missing_unit_policy") or "").strip().lower()
    if rule_unit:
        for _occ in occs:
            _unk = _unknown_unit_tail(text, _occ, policy=_unknown_policy)
            if _unk:
                return {"state": "证据不足",
                        "detail": f"未知单位：{_unk}（规则单位 {rule_unit} 无法换算，不猜）",
                        "quote": _occ.get("quote") or "", "value": _occ.get("value")}
    # L39 ① 缺单位默认按规则单位比较的静默放行：规则显式声明
    # missing_unit_policy=insufficient 时，原文数值缺计量单位 → 证据不足（不猜单位）。
    # =0 回退：仍按规则单位直接比较（历史口径）。
    if (_fix2_on("missing_unit") and _missing_policy == "insufficient" and rule_unit):
        _no_unit = [o for o in occs if not str(o.get("unit") or "")]
        if _no_unit:
            _o = _no_unit[0]
            return {"state": "证据不足",
                    "detail": (f"缺计量单位：原文「{(str(_o.get('quote') or '')[:40])}」"
                               f"仅给数值 {_o.get('value')}，未标 {rule_unit} 或其他可换算单位，"
                               "不默认按规则单位比较"),
                    "quote": _o.get("quote") or "", "value": _o.get("value"),
                    "missing_unit_blocked": True,
                    "unit_source_missing": bool(_fact_identity_fix_on())}
    compat = [o for o in occs if _occ_unit_compatible(o, rule_unit)]
    mismatched = [o for o in occs if o not in compat]
    if not compat:
        sample = mismatched[0] if mismatched else {}
        return {"state": "证据不足",
                "detail": f"单位不符：规则要求 {rule_unit or '无单位'}，"
                          f"文中为 {sample.get('unit') or '无单位'}（{(sample.get('quote') or '')[:30]}）",
                "quote": sample.get("quote") or "", "value": sample.get("value")}
    # 币种口径（A09）：外币金额缺「汇率+换算时点」→ 证据不足，不能按本币阈值直接比较
    ccy_out = _currency_gate(slots, text, rule_unit, compat)
    if ccy_out.get("insufficient"):
        return {"state": "证据不足", "detail": ccy_out["detail"],
                "quote": ccy_out.get("quote") or "", "value": ccy_out.get("value"),
                "currency_blocked": True}
    if ccy_out.get("occs") is not None:
        compat = ccy_out["occs"]
    if want_basis:
        basis_hits = [o for o in compat if o.get("tax_basis") == want_basis]
        if not basis_hits:
            other = {o.get("tax_basis") for o in compat if o.get("tax_basis")}
            if other:
                labels = "、".join(_tools.tax_basis_label(x) for x in sorted(other))
                return {"state": "证据不足",
                        "detail": f"规则要求{_tools.tax_basis_label(want_basis)}口径，"
                                  f"原文只标注了{labels}金额",
                        "quote": compat[0].get("quote") or "",
                        "value": compat[0].get("base_value")}
            return {"state": "证据不足",
                    "detail": "原文未标注含税/未税口径，不能按猜测口径比较",
                    "quote": compat[0].get("quote") or "",
                    "value": compat[0].get("base_value")}
        compat = basis_hits
    else:
        bases = {o.get("tax_basis") for o in compat if o.get("tax_basis")}
        if len(bases) > 1:
            return {"state": "证据不足",
                    "detail": "原文同时出现含税与未税金额，规则未指定口径，转人工",
                    "quote": compat[0].get("quote") or "",
                    "value": compat[0].get("base_value")}
    # L86：把参与比较的出现单位回传给调用方，用于给结论回填 unit_source。
    if isinstance(meta, dict):
        meta["fact_units"] = [str(o.get("unit") or "") for o in compat]
        meta["fact_count"] = len(compat)
    _rscale = _unit_scale(rule_unit)
    target_base = target * _rscale if _rscale is not None else target
    rng = _range_bounds(slots) if op == "range" else (None, None)
    if op == "range" and (rng[0] is None or rng[1] is None):
        return {"state": "执行失败",
                "detail": "范围算子 range 缺少可解析的上下限（lo/hi 或 value='lo-hi'）",
                "quote": "", "value": None}
    lo_base = rng[0] * _rscale if (rng[0] is not None and _rscale is not None) else rng[0]
    hi_base = rng[1] * _rscale if (rng[1] is not None and _rscale is not None) else rng[1]
    # L62 P0-A：规则阈值/区间端点非有限（NaN/Inf）→ 证据不足，不参与比较（fail-closed）。
    if _opspec_fix_on("finite"):
        if op == "range":
            if not (_opspec_finite(lo_base) and _opspec_finite(hi_base)):
                return {"state": "证据不足",
                        "detail": "规则区间端点非有限（NaN/Inf），无法比较，不产生 pass/fail",
                        "quote": "", "value": None, "non_finite_blocked": True}
        elif not _opspec_finite(target_base):
            return {"state": "证据不足",
                    "detail": f"规则阈值非有限（NaN/Inf：{target!r}），无法比较，不产生 pass/fail",
                    "quote": "", "value": None, "non_finite_blocked": True}
    _op_txt = f"{rng[0]:g}-{rng[1]:g}" if op == "range" else f"{op} {target}"
    violations, uncertain = [], []
    for o in compat:
        if _opspec_fix_on("range_endpoint"):
            ok = _opspec_compare_one(o, op, target_base, lo_base, hi_base)
        elif op == "range":
            ok = lo_base <= o.get("base_value") <= hi_base
        else:
            ok = _cmp(o.get("base_value"), op, target_base)
        if ok is None:
            if _opspec_fix_on("range_endpoint"):
                uncertain.append(o)
                continue
            return {"state": "执行失败", "detail": f"不支持比较符 {op}",
                    "quote": o.get("quote") or "", "value": o.get("value")}
        if ok is False:
            violations.append(o)
    if uncertain and not violations:
        o = uncertain[0]
        _resp = {"state": "证据不足",
                 "detail": (f"{metric} 原文为区间 {o.get('range_lo'):g}-{o.get('range_hi'):g}"
                            f"{o.get('unit') or ''}，与精确比较 {_op_txt}{rule_unit} 跨过目标值，"
                            "无法确定满足/不满足（不按任一端点猜）"),
                 "quote": o.get("quote") or "", "value": o.get("base_value"),
                 "occurrences": len(compat), "range_precise_ambiguous": True}
        if _opspec_units.get("unit_inherited"):
            _resp["unit_inherited"] = _opspec_units["unit_inherited"]
            _resp["unit_source"] = o.get("unit_source") or "rule_slot"
        return _resp
    if violations:
        o = violations[0]
        _basis = (f"（{_tools.tax_basis_label(o.get('tax_basis'))}）"
                  if o.get("tax_basis") else "")
        _extra = (f"；共 {len(compat)} 处数值，{len(violations)} 处超限"
                  if len(compat) > 1 else "")
        if o.get("is_range"):
            _shown = (f"{o.get('range_lo'):g}-{o.get('range_hi'):g}"
                      f"{o.get('unit') or ''}（下限/上限双端点）")
            _range_meta = {"range_lo": o.get("range_lo"),
                           "range_hi": o.get("range_hi")}
        else:
            _shown = f"{o.get('value')}{o.get('unit') or ''}"
            _range_meta = {}
        _resp = {"state": "不满足",
                 "detail": (f"{metric} {_shown}{_basis} "
                            f"不满足 {_op_txt}{rule_unit}{_extra}"),
                 "quote": o.get("quote") or "", "value": o.get("base_value"),
                 "occurrences": len(compat), "violations": len(violations),
                 **_range_meta}
        if _opspec_units.get("unit_inherited"):
            _resp["unit_inherited"] = _opspec_units["unit_inherited"]
            _resp["unit_source"] = o.get("unit_source") or "rule_slot"
        return _resp
    o0 = compat[0]
    _basis0 = (f"（{_tools.tax_basis_label(o0.get('tax_basis'))}）"
               if o0.get("tax_basis") else "")
    _resp = {"state": "满足",
             "detail": f"{len(compat)} 处 {metric}{_basis0} 均满足 {_op_txt}{rule_unit}",
             "quote": o0.get("quote") or "", "value": o0.get("base_value"),
             "occurrences": len(compat)}
    if _opspec_units.get("unit_inherited"):
        _resp["unit_inherited"] = _opspec_units["unit_inherited"]
        _resp["unit_source"] = o0.get("unit_source") or "rule_slot"
    return _resp


# ---------------------------------------------------------------------------
# L39 ⑩ 约数/± 容差策略（统一开关 RULEPROOF_EXEC_FIXES_V2，=0 逐项回退）
#
# 背景（L31v2 240 盲测 approx_value 10/18）：`95 ± 8 mg/kg` 被抽成 8（只取到偏差量）、
# `约 98 mg/kg` 被当精确 98 直接与阈值比较，导致「约数靠近阈值」本应证据不足却被判 pass/fail。
# 口径（只对**物理测量量纲**生效：温度/时间/浓度/质量/体积/长度；金额/比例/计数不启用）：
#   ① 有显式 ±Δ：不确定带 = [v-Δ, v+Δ]；
#   ② 无显式 ± （约/大约/左右/≈/~）：相对不确定带 = v*(1±5%)（可用 slots.approx_relative_margin 覆盖）；
#   ③ 带整段落在满足侧 → 满足；整段落在违反侧 → 不满足；跨阈值 → 证据不足（boundary_crossing_approx_policy）。
# ===========================================================================
_APPROX_PRE_MARKS = ("大约", "约计", "约为", "约", "大概", "≈", "~", "～", "∼")
_APPROX_SUF_MARKS = ("左右", "上下", "前后")
_APPROX_TILDE_MARKS = ("≈", "~", "～", "∼")
_APPROX_MARGIN_DEFAULT = 0.05


def _measure_dim(rule_unit: str) -> str:
    d = _unit_dim(rule_unit)
    return d if d in ("temp", "time", "conc", "mass", "vol", "len") else ""


def _approx_candidates(slots: dict, text: str) -> list:
    """原文 → 与规则同量纲的约数候选 [{value, lo, hi, quote, state}]。"""
    ru = str(slots.get("unit") or "")
    dim = _measure_dim(ru)
    if not ru or not dim:
        return []
    try:
        margin = float(slots.get("approx_relative_margin")
                       if slots.get("approx_relative_margin") is not None
                       else _APPROX_MARGIN_DEFAULT)
    except (TypeError, ValueError):
        margin = _APPROX_MARGIN_DEFAULT
    norm = _tools.canonical_numeric_text(text)
    ualt = _unit_alt()
    pat = re.compile(
        r"(?P<pre>" + "|".join(re.escape(x) for x in _APPROX_PRE_MARKS) + r")?\s*"
        r"(?P<v>[-]?\d+(?:\.\d+)?)\s*"
        r"(?P<u1>" + ualt + r")?\s*"
        r"(?:±\s*(?P<d>\d+(?:\.\d+)?)\s*(?P<u2>" + ualt + r")?)?\s*"
        r"(?P<post>左右|上下|前后)?")
    out = []
    for m in pat.finditer(norm):
        pre = m.group("pre") or ""
        post = m.group("post") or ""
        delta_raw = m.group("d")
        if not (pre or post or delta_raw):
            continue
        # 「2.5℃~7.8℃」的 ~ 是区间连接符，不是约数前缀：前缀 ~ 前紧邻数值/单位 → 跳过
        if pre in _APPROX_TILDE_MARKS:
            head = norm[max(0, m.start("pre") - 1):m.start("pre")]
            if head and (head.isdigit() or _unit_known(head)):
                continue
        try:
            v = float(m.group("v"))
        except (TypeError, ValueError):
            continue
        u1 = m.group("u1") or ""
        u2 = m.group("u2") or u1
        uv = u1 or u2
        if not uv:
            continue
        v_rule = _convert(v, uv, ru)
        if v_rule is None:
            continue
        if delta_raw is not None:
            try:
                d_raw = float(delta_raw)
            except (TypeError, ValueError):
                continue
            d_rule = _convert(d_raw, u2, ru) if u2 else d_raw
            if d_rule is None:
                continue
            lo, hi = v_rule - d_rule, v_rule + d_rule
        else:
            band = abs(v_rule) * margin
            lo, hi = v_rule - band, v_rule + band
        out.append({"value": v, "unit": uv, "v_rule": v_rule, "lo": lo, "hi": hi,
                    "quote": norm[max(0, m.start() - 6):m.end()][:80],
                    "marker": pre or post or "±"})
    return out


def _approx_decision(slots: dict, text: str):
    """约数策略判定：None=无可决候选；否则 {state, detail, quote, value}。"""
    if not _fix2_on("approx"):
        return None
    pol = str(slots.get("boundary_crossing_approx_policy")
              or slots.get("approx_policy") or "insufficient").strip().lower()
    if pol in ("off", "ignore", "none", "0", "false"):
        return None
    cands = _approx_candidates(slots, text)
    if not cands:
        return None
    op = str(slots.get("op") or ">=")
    target = _num(str(slots.get("value", "")).replace(",", ""))
    if op == "range":
        rng = _range_bounds(slots)
        if rng[0] is None or rng[1] is None:
            return None
        rscale = _unit_scale(slots.get("unit"))
        lo_t = rng[0] * rscale if rscale is not None else rng[0]
        hi_t = rng[1] * rscale if rscale is not None else rng[1]

        def _meets(x):
            return lo_t <= x <= hi_t
    else:
        rscale = _unit_scale(slots.get("unit"))
        if target is None:
            return None
        if rscale is not None:
            target = target * rscale

        def _meets(x):
            return _cmp(x, op, target)
    def _crosses(c):
        a, b = _meets(c["lo"]), _meets(c["hi"])
        return a is not b

    cross = [c for c in cands if _crosses(c)]
    if cross:
        c = cross[0]
        return {"state": "证据不足",
                "detail": (f"约数/容差带 [{c['lo']:g}, {c['hi']:g}]（原文「{c['quote']}」）"
                           f"跨过阈值，无法确定是否满足 {op} {slots.get('value')}"
                           f"{slots.get('unit') or ''}，不按单点数值判定"),
                "quote": c["quote"], "value": c["v_rule"], "approx_crossing": True}
    bad = [c for c in cands if _meets(c["hi"]) is False
           and _meets(c["lo"]) is False]
    if bad:
        c = bad[0]
        return {"state": "不满足",
                "detail": (f"约数/容差带 [{c['lo']:g}, {c['hi']:g}]（原文「{c['quote']}」）"
                           f"整体超出 {op} {slots.get('value')}{slots.get('unit') or ''}"),
                "quote": c["quote"], "value": c["v_rule"], "approx": True}
    c = cands[0]
    return {"state": "满足",
            "detail": (f"约数/容差带 [{c['lo']:g}, {c['hi']:g}]（原文「{c['quote']}」）"
                       f"整体满足 {op} {slots.get('value')}{slots.get('unit') or ''}"),
            "quote": c["quote"], "value": c["v_rule"], "approx": True}


# ---------------------------------------------------------------------------
# L39 ⑥ 复合时长合成（规则 slots 声明 composite_time=true 时启用）
#   「1小时45分钟」「2h10min」会被抽成两个独立时间事实，逐项都能过阈值，
#   但合计时长已超限（L2B-044：2h10min ≤ 2h 判 pass，实为 130min>120min）。
#   口径：同句内相邻「h/小时 + min/分钟」（含 min+秒）先合成总时长再比较。
# ---------------------------------------------------------------------------
_COMPOSITE_H_RE = re.compile(r"(?P<a>\d+(?:\.\d+)?)\s*(?P<au>小时|h|hr)\s*"
                             r"(?P<b>\d+(?:\.\d+)?)\s*(?P<bu>分钟|min|分)")
_COMPOSITE_MS_RE = re.compile(r"(?P<a>\d+(?:\.\d+)?)\s*(?P<au>分钟|min|分)\s*"
                              r"(?P<b>\d+(?:\.\d+)?)\s*(?P<bu>秒|s)")


def _composite_decision(slots: dict, text: str):
    """复合时长判定：None=未声明 composite_time 或未命中模式。"""
    if not _fix2_on("composite_time") or not slots.get("composite_time"):
        return None
    ru = str(slots.get("unit") or "")
    if _unit_dim(ru) != "time":
        return None
    norm = _tools.canonical_numeric_text(text)
    totals = []
    for pat in (_COMPOSITE_H_RE, _COMPOSITE_MS_RE):
        for m in pat.finditer(norm):
            total = _convert(float(m.group("a")), m.group("au"), ru)
            b = _convert(float(m.group("b")), m.group("bu"), ru)
            if total is None or b is None:
                continue
            totals.append({"total": total + b, "quote": norm[m.start():m.end()]})
    if not totals:
        return None
    op = str(slots.get("op") or ">=")
    target = _num(str(slots.get("value", "")).replace(",", ""))
    if op == "range":
        rng = _range_bounds(slots)
        if rng[0] is None or rng[1] is None:
            return None
        lo_t, hi_t = rng[0], rng[1]

        def _meets(x):
            return lo_t <= x <= hi_t
    else:
        if target is None:
            return None

        def _meets(x):
            return _cmp(x, op, target)
    bad = [t for t in totals if _meets(t["total"]) is False]
    if bad:
        t = bad[0]
        return {"state": "不满足",
                "detail": (f"复合时长合计 {t['total']:g}{ru}（原文「{t['quote']}」）"
                           f"不满足 {op} {slots.get('value')}{ru}（各分项单独比较会漏判）"),
                "quote": t["quote"], "value": t["total"], "composite_time": True}
    t = totals[0]
    return {"state": "满足",
            "detail": (f"复合时长合计 {t['total']:g}{ru}（原文「{t['quote']}」）"
                       f"满足 {op} {slots.get('value')}{ru}"),
            "quote": t["quote"], "value": t["total"], "composite_time": True}


# L39 ⑩（保守边界，附加）：原文只给「宽泛上界」（≤10℃ / <1.0 ppm）时，上界高于阈值
# 无法确认是否满足阈值，不得按「第一个数值」判 fail；上界本身已满足则可放行（不夸大证据）。
_INEQ_RE = re.compile(r"(?P<mk>[<≤＜>≥＞])\s*(?P<v>[-]?\d+(?:\.\d+)?)\s*(?P<u>"
                      + _UNIT_ALT_FIX2 + r")")


def _inequality_decision(slots: dict, text: str):
    """宽泛上下界判定：None=无相关候选；否则证据不足（无法确认）。"""
    if not _fix2_on("inequality"):
        return None
    ru = str(slots.get("unit") or "")
    if not _measure_dim(ru) or not text:
        return None
    op = str(slots.get("op") or ">=")
    norm = _tools.canonical_numeric_text(text)
    target = _num(str(slots.get("value", "")).replace(",", ""))
    rng = _range_bounds(slots) if op == "range" else (None, None)
    rscale = _unit_scale(ru)
    if rscale is not None and target is not None:
        target = target * rscale
    # L39-hotfix（2026-11-24，GT35-05 回归）：宽泛上下界必须与“本规则的指标对象”同窗口，
    # 否则整篇扫描会把别的指标的上界（如过氧化值「≤0.25g/100g」）错安到铅上 → 误判证据不足。
    _metric = _tools.canonical_numeric_text(str(slots.get("metric") or ""))
    _m_tokens = {t for t in (_metric, _metric.split("(")[0], _metric.split("（")[0]) if t and len(t) >= 1}
    for m in _INEQ_RE.finditer(norm):
        mk = m.group("mk")
        try:
            v = float(m.group("v"))
        except (TypeError, ValueError):
            continue
        cv = _convert(v, m.group("u"), ru)
        if cv is None:
            continue
        if _m_tokens:
            _w = norm[max(0, m.start() - 80):m.end() + 80]
            if not any(t in _w for t in _m_tokens):
                continue
        if mk in ("<", "≤", "＜") and op in ("<=", "≤", "range"):
            if op == "range":
                hi_t = rng[1] * rscale if (rng[1] is not None and rscale is not None) else rng[1]
                if hi_t is not None and cv > hi_t:
                    return {"state": "证据不足",
                            "detail": (f"原文只给宽泛上界「{m.group(0)}」，无法确认是否"
                                       f"不超过 {hi_t:g}{ru}"),
                            "quote": norm[max(0, m.start() - 8):m.end()][:80],
                            "value": cv, "boundary_wide": True}
            elif target is not None and cv > target:
                return {"state": "证据不足",
                        "detail": (f"原文只给宽泛上界「{m.group(0)}」，上界 {cv:g}{ru} "
                                   f"高于阈值 {target:g}{ru}，无法确认是否满足"),
                        "quote": norm[max(0, m.start() - 8):m.end()][:80],
                        "value": cv, "boundary_wide": True}
        if mk in (">", "≥", "＞") and op in (">=", "≥", "range"):
            if op == "range":
                lo_t = rng[0] * rscale if (rng[0] is not None and rscale is not None) else rng[0]
                if lo_t is not None and cv < lo_t:
                    return {"state": "证据不足",
                            "detail": (f"原文只给宽泛下界「{m.group(0)}」，无法确认是否"
                                       f"不低于 {lo_t:g}{ru}"),
                            "quote": norm[max(0, m.start() - 8):m.end()][:80],
                            "value": cv, "boundary_wide": True}
            elif target is not None and cv < target:
                return {"state": "证据不足",
                        "detail": (f"原文只给宽泛下界「{m.group(0)}」，下界 {cv:g}{ru} "
                                   f"低于阈值 {target:g}{ru}，无法确认是否满足"),
                        "quote": norm[max(0, m.start() - 8):m.end()][:80],
                        "value": cv, "boundary_wide": True}
    return None


# 缺单位口径下的「裸小数」扫描（L39 ① 多实例补齐）：
# 规则声明 missing_unit_policy=insufficient 时，同一记录里出现「带单位值 + 裸数值」
# （如 L2B-198「B柜 6.0（单位缺失）」）也必须证据不足，不能只看带单位的事实通过就判满足。
_BARE_DEC_RE = re.compile(r"(?<![\d.])(\d+\.\d+)(?![\d.])")


def _bare_unit_number(text: str) -> str:
    """原文中「有小数但无单位」的数值（排除日期/编号片段）；无则返回空串。"""
    norm = _tools.canonical_numeric_text(text)
    _tail_re = re.compile(r"\s*(" + _unit_alt() + r")")
    for m in _BARE_DEC_RE.finditer(norm):
        tail = _tail_re.match(norm[m.end():m.end() + 12])
        if tail and _unit_known(tail.group(1)):
            continue
        prev = norm[max(0, m.start() - 1):m.start()]
        nxt = norm[m.end():m.end() + 1]
        if prev in ("-", "/", ":", "：", ".") or nxt in ("-", "/", ":", "："):
            continue
        return m.group(1)
    return ""


def judge_limit(slots: dict, facts: list, text: str = "", aliases: dict | None = None) -> dict:
    """对事实执行限值判定，返回 {state, detail, quote, value}。"""
    _etype = _entity_type(str(slots.get("metric")))
    if _etype == "日期":
        return _judge_date(slots, text)
    if _etype == "编号":
        return _judge_code(slots, text)
    kind = METRIC_KIND.get(str(slots.get("metric")), str(slots.get("metric")))
    op = str(slots.get("op") or ">=")
    rng = _range_bounds(slots) if op == "range" else (None, None)
    target = _num(str(slots.get("value", "")).replace(",", ""))
    if op == "range":
        # 闭区间 lo <= x <= hi（与 rule_ir.resolve_range_bounds 同口径）；缺上下限/倒置
        # 都明确报执行失败，不允许静默当成通过。
        if rng[0] is None or rng[1] is None:
            return {"state": "执行失败",
                    "detail": "范围算子 range 缺少可解析的上下限（lo/hi 或 value='lo-hi'）",
                    "quote": "", "value": None}
        if rng[0] > rng[1]:
            return {"state": "执行失败",
                    "detail": f"范围算子 range 下限大于上限（lo={rng[0]:g} > hi={rng[1]:g}）",
                    "quote": "", "value": None}
        if target is None:
            target = rng[0]
    elif target is None:
        return {"state": "执行失败", "detail": "规则缺少 value"}
    # L62 P0-A：规则阈值/区间端点 NaN/Inf/非有限 → 证据不足（不产生 pass/fail）。
    if _opspec_fix_on("finite"):
        if op == "range":
            if not (_opspec_finite(rng[0]) and _opspec_finite(rng[1])):
                return {"state": "证据不足",
                        "detail": "规则区间端点非有限（NaN/Inf），无法比较，不产生 pass/fail",
                        "quote": "", "value": None, "non_finite_blocked": True}
        elif not _opspec_finite(target):
            return {"state": "证据不足",
                    "detail": f"规则阈值非有限（NaN/Inf：{target!r}），无法比较，不产生 pass/fail",
                    "quote": "", "value": None, "non_finite_blocked": True}
    scope = str(slots.get("scope") or "")

    def _meets(x) -> bool:
        """range → 闭区间比较；其余算子沿用既有 _cmp（语义不变）。"""
        if op == "range":
            return rng[0] <= x <= rng[1]
        return _cmp(x, op, target)

    _op_txt = f"{rng[0]:g}-{rng[1]:g}" if op == "range" else f"{op} {target}"
    # L39 ⑩：宽泛上下界（≤10℃ / <1.0 ppm）无法确认是否满足阈值 → 证据不足。
    _ineq = _inequality_decision(slots, text)
    if _ineq is not None:
        return _ineq
    # L39 ⑥ 复合时长（规则声明 composite_time=true）：同句相邻 h+min 先合成总时长再比较。
    _comp = _composite_decision(slots, text)
    if _comp is not None:
        return _comp
    # L39 ⑩ 约数/± 容差：带跨阈值 → 证据不足（优先于单点数值比较）。
    _approx = _approx_decision(slots, text)
    if _approx is not None and _approx.get("state") == "证据不足":
        return _approx

    def _wrap(res):
        """用约数带结论修正单点判定（不弱化已有违规：事实判 fail 时保持 fail）。"""
        if not _approx:
            return res
        st = _approx.get("state")
        if res.get("state") == "满足":
            return _approx if st == "不满足" else res
        if res.get("state") == "证据不足":
            return _approx
        return res

    _missing_policy = str(slots.get("missing_unit_policy") or "").strip().lower()
    _unit_rule0 = str(slots.get("unit") or "")
    _unit_source0 = str(slots.get("unit_source") or "").strip().lower() or "rule_slot"

    def _fact_base_compare(lo_v, hi_v) -> bool | None:
        """L62 B1：事实带 range_hi（区间两端）时按端点比较；否则沿用既有 _meets。"""
        if _opspec_fix_on("range_endpoint") and hi_v is not None:
            lo_b = lo_v if op != "range" else rng[0]
            hi_b = hi_v if op != "range" else rng[1]
            return _opspec_compare_one(
                {"is_range": True, "base_lo": lo_b, "base_hi": hi_b,
                 "base_value": lo_b, "unit": _unit_rule0},
                op, target, rng[0], rng[1])
        return _meets(lo_v)

    matched = []
    for f in facts:
        d = f.to_dict() if hasattr(f, "to_dict") else f
        if d.get("kind") != kind:
            continue
        if scope and scope not in (d.get("context", "") + d.get("anchor", "") + d.get("unit", "") + d.get("object", "")):
            continue
        v = _num(d.get("value"))
        if v is None:
            continue
        if _opspec_fix_on("finite") and not _opspec_finite(v):
            return {"state": "证据不足",
                    "detail": f"事实数值非有限（NaN/Inf：{d.get('value')!r}），不参与判定",
                    "quote": d.get("context") or "", "value": d.get("value"),
                    "non_finite_blocked": True}
        fu = str(d.get("unit") or "")
        tu = str(slots.get("unit") or "")
        # L62 P0-A 事实路径：缺单位默认不按规则单位比较；显式 inherit 才继承并记录来源。
        if (_opspec_fix_on("unit_strict") and _fix2_on("missing_unit") and tu
                and not fu and _opspec_rule_dim(tu)):
            if _missing_policy == "inherit" and _unit_known(tu):
                if _unit_source0 not in _OPSPEC_INHERIT_SOURCES:
                    return {"state": "证据不足",
                            "detail": (f"单位继承来源不可证：unit_source={_unit_source0!r} "
                                       f"不在白名单 {list(_OPSPEC_INHERIT_SOURCES)}"),
                            "quote": d.get("context") or "", "value": v,
                            "unit_source_blocked": True}
                d = dict(d)
                d["unit"] = tu
                d["unit_source"] = _unit_source0
                d["unit_inherited"] = True
                fu = tu
            else:
                return {"state": "证据不足",
                        "detail": (f"缺计量单位：事实 {v!r} 未标 {tu} 或其他可换算单位，"
                                   "默认不猜单位（显式 missing_unit_policy=inherit 才继承）"),
                        "quote": d.get("context") or "", "value": v,
                        "missing_unit_blocked": True,
                        "unit_source_missing": bool(_fact_identity_fix_on())}
        cv = _convert(v, fu, tu) if (fu and tu) else v
        if cv is None:
            return {"state": "证据不足",
                    "detail": f"单位无法换算：文中 {v}{fu}，规则 {tu}",
                    "quote": d.get("context") or "", "value": v}
        _hi_raw = d.get("range_hi")
        hi_cv = None
        if _hi_raw is not None:
            try:
                _hi_raw = float(_hi_raw)
            except (TypeError, ValueError):
                _hi_raw = None
            if _hi_raw is not None:
                hi_cv = _convert(_hi_raw, fu, tu) if (fu and tu) else _hi_raw
                if hi_cv is None:
                    return {"state": "证据不足",
                            "detail": f"区间上限无法换算：文中 {_hi_raw}{fu}，规则 {tu}",
                            "quote": d.get("context") or "", "value": _hi_raw}
        matched.append((cv, d, hi_cv))
    # L86：事实路径参与比较的单位/继承来源，供结论回填 unit_source。
    _fact_units = [str(d.get("unit") or "") for _lo, d, _hi in matched]
    _inherited_srcs = [d.get("unit_source") for _lo, d, _hi in matched
                       if d.get("unit_inherited")]
    if not matched:
        _txt_meta = {}
        _txt_res = _wrap(_judge_limit_from_text(slots, text, aliases, target, op, _txt_meta))
        return _tag_unit_source(_txt_res, str(slots.get("unit") or ""),
                                _txt_meta.get("fact_units") or [],
                                slots.get("unit_source"))
    # L39 ① 事实路径的缺单位门禁：声明 missing_unit_policy=insufficient 时，
    # 同一记录出现「带单位值 + 裸小数」（如 L2B-198「B柜 6.0（单位缺失）」）→ 证据不足。
    if (_fix2_on("missing_unit") and _missing_policy == "insufficient"
            and str(slots.get("unit") or "")):
        _bare = _bare_unit_number(text)
        if _bare:
            return {"state": "证据不足",
                    "detail": (f"缺计量单位：原文存在无单位数值「{_bare}」，"
                               f"无法确认是否满足 {op} {slots.get('value')}"
                               f"{slots.get('unit')}，不默认按规则单位比较"),
                    "quote": "", "value": None, "missing_unit_blocked": True}
    # 对照校验：同一指标走「事实路径」与「原文兜底路径」，结论不一致 → 证据不足转人工。
    # L39 ④：区间/多值原文（如「−20.5℃~−16.8℃」）单值兜底只看第一处会与事实路径假冲突；
    # 修复开启时用「全出现逐项判定」的原文兜底路径对照（单值文本行为不变，A2.3 矛盾仍转证据不足）。
    _unit_rule = str(slots.get("unit") or "")
    _fact_ok = all(_fact_base_compare(lo_v, hi_v) is not False
                   for lo_v, _d, hi_v in matched)
    _text_ok, _tq = None, None
    if _fix2_on("path_consistency"):
        # 原文是「值1~值2」区间写法时，原文兜底只取得到第一处（指标名只出现一次），
        # 用它对照会与事实路径假冲突（L2B-126/128/129）；区间/多值文本跳过单值对照，
        # 以事实路径逐项判定为准。
        _range_tail = any(
            re.match(r"\s*[~～至到\-–—]\s*[-−－]?\d", str(text or "")[int(o.get("end") or 0):
                                                                          int(o.get("end") or 0) + 8])
            for o in _occurrences(slots.get("metric") or "", text, aliases=aliases))
        if not _range_tail:
            _txt_res = _judge_limit_from_text(slots, text, aliases, target, op)
            if _txt_res.get("state") in ("满足", "不满足"):
                _text_ok = _txt_res["state"] == "满足"
                _tq = _txt_res.get("quote")
    else:
        _tv, _tq = _from_text(slots.get("metric"), text, aliases=aliases)
        if _tv is not None:
            _rscale = _unit_scale(_unit_rule)
            _scale = _rscale if _rscale is not None else 1
            _text_ok = _meets(_tv / _scale)
    if _text_ok is not None and _text_ok != _fact_ok:
        return {"state": "证据不足",
                "detail": f"两条独立路径结论不一致（事实={'满足' if _fact_ok else '不满足'}，"
                          f"原文={'满足' if _text_ok else '不满足'}），转人工",
                "quote": _tq or matched[0][1].get("context", ""), "value": None, "conflict": True}
    bad = [(lo_v, d, hi_v) for lo_v, d, hi_v in matched
           if _fact_base_compare(lo_v, hi_v) is False]
    if bad:
        v, d, _hi = bad[0]
        _resp = {"state": "不满足",
                 "detail": f"{slots.get('metric')} {d.get('value')}{d.get('unit','')} 不满足 {_op_txt}{slots.get('unit','')}",
                 "quote": d.get("context") or d.get("quote") or "", "value": v}
        return _tag_unit_source(_resp, str(slots.get("unit") or ""), _fact_units,
                                _unit_source0, _inherited_srcs)
    _resp = _wrap({"state": "满足",
                   "detail": f"{len(matched)} 项均满足 {_op_txt}{slots.get('unit','')}",
                   "quote": matched[0][1].get("context", ""),
                   "value": matched[0][1].get("value")})
    _inherited = [d for _lo, d, _hi in matched if d.get("unit_inherited")]
    if _inherited:
        _resp["unit_inherited"] = len(_inherited)
        _resp["unit_source"] = _inherited[0].get("unit_source") or "rule_slot"
    return _tag_unit_source(_resp, str(slots.get("unit") or ""), _fact_units,
                            _unit_source0, _inherited_srcs)


# ---------------------------------------------------------------------------
# L107 D5：缺失类「缺失上下文」引文定位（确定性、0 模型；不读 gold）
#
# 缺失类 finding 的本质是「原文没有该要求」，所以没有可命中的原文片段。证据口径取
# 「缺失所在 sheet/行上下文」：在调用方传入的 text 中定位**最接近锚点的行**，逐字返回该行。
# 锚点来源（优先级从高到低，全部来自规则槽位/需求词本身，不猜语义）：
#   ① 显式锚点：slots 的 missing_context_anchors/context_anchors/anchors/section/scope/
#      object/subject（规则作者可指定应出现该要求的区段/对象词）；
#   ② 需求词 2-gram：require/require_any 词本身及其前/后 2 字；
#   ③ 常见合规概念线索表（_MISSING_CONTEXT_CUES）：如「金属探测/X光/异物检测」→
#      异物/检测/机检/检验/抽检/包装；「透明袋/装框重量」→ 装框/周转筐/包装/食品袋；
#      「暂存最大时长」→ 暂存/存放/时长/时限。只用于定位行，不改变判定语义。
# 定位不到（原文没有任何可用行）→ 返回 None，调用方按「证据不足」fail-closed（不得裸 fail）。
# 开关：RULEPROOF_MISSING_CONTEXT_QUOTE（默认 1；=0 回退 quote="" 旧行为）。
# ---------------------------------------------------------------------------
# (触发词, 上下文线索词)：触发词出现在需求词里时，线索词用于在原文行中定位缺失上下文。
_MISSING_CONTEXT_CUES = (
    (("异物", "金属", "探测", "X光", "x光", "机检", "金检", "检测"),
     ("异物", "检测", "探测", "机检", "金检", "检验", "质检", "抽检", "包装", "包材")),
    (("透明袋", "装框", "装袋", "周转筐", "周转箱", "包装", "封口", "装箱"),
     ("装框", "装袋", "装筐", "周转筐", "周转箱", "包装", "食品袋", "封口", "装箱", "袋")),
    (("时长", "时限", "暂存", "存放", "保质期", "保存", "贮存"),
     ("暂存", "存放", "存储", "贮存", "时长", "时限", "时间")),
    (("温度", "冷藏", "冷冻", "冷却", "库温", "加热", "解冻"),
     ("温度", "冷藏", "冷冻", "冷却", "库温", "℃", "℉")),
    (("清洗", "消毒", "杀菌", "灭菌", "冲洗"),
     ("清洗", "消毒", "杀菌", "灭菌", "冲洗", "洗涤")),
    (("标识", "标签", "标记", "追溯"),
     ("标识", "标签", "标记", "追溯", "批号")),
    (("记录", "台账", "登记", "归档", "留存"),
     ("记录", "台账", "登记", "归档", "留存")),
    (("签名", "签章", "签字", "盖章", "批准"),
     ("签名", "签章", "签字", "盖章", "批准")),
    (("培训", "资质", "健康证", "人员", "岗位"),
     ("培训", "资质", "健康证", "人员", "岗位")),
    (("设备", "器具", "工具", "校准", "计量"),
     ("设备", "器具", "工具", "校准", "计量")),
    (("重量", "称重", "投料", "净重", "配比"),
     ("重量", "称重", "投料", "计量", "净重", "kg", "克")),
    (("检验", "化验", "抽检", "质检", "验收"),
     ("检验", "化验", "抽检", "质检", "验收", "检测")),
    (("日期", "期限", "有效期", "时间"),
     ("日期", "期限", "有效期", "时间")),
    (("隔离", "分区", "交叉污染", "生熟"),
     ("隔离", "分区", "交叉污染", "生熟")),
    (("比例", "含量", "浓度", "限值", "指标"),
     ("比例", "含量", "浓度", "限值", "指标")),
)
_MISSING_CONTEXT_ANCHOR_KEYS = ("missing_context_anchors", "context_anchors", "anchors",
                                "section", "scope", "object", "subject")
_MISSING_CONTEXT_TITLE_MAXLEN = 40


def _missing_context_tokens(terms, slots) -> list:
    """需求词 + 规则锚点 → [(线索词, 权重)]；同词取最高权重、去重后返回。"""
    weighted = {}

    def _put(tok, w):
        tok = str(tok or "").strip()
        if len(tok) < 2 or len(tok) > 20:
            return
        weighted[tok] = max(weighted.get(tok, 0), w)

    # ① 规则显式锚点（权重最高；规则作者可指定应有该要求的区段/对象）
    for k in _MISSING_CONTEXT_ANCHOR_KEYS:
        v = (slots or {}).get(k) if isinstance(slots, dict) else None
        if isinstance(v, str):
            _put(v, 8)
        elif isinstance(v, (list, tuple)):
            for x in v:
                if isinstance(x, str):
                    _put(x, 8)
    # ② 需求词本身 / 前 2 字 / 后 2 字
    for term in terms or []:
        t = str(term or "").strip()
        if not t:
            continue
        _put(t, 6)
        if len(t) >= 3:
            _put(t[:2], 3)
            _put(t[-2:], 3)
    # ③ 常见合规概念线索（触发词命中需求词 → 线索词加权）
    for triggers, cues in _MISSING_CONTEXT_CUES:
        if any(x in str(t) for t in (terms or []) for x in triggers):
            for c in cues:
                _put(c, 2)
    return sorted(weighted.items(), key=lambda kv: (-kv[1], -len(kv[0])))


def _missing_context_quote(slots, terms, text) -> dict | None:
    """在 text 中定位「缺失所在行上下文」；返回 {quote,char_start,char_end,line,score,anchors}。

    定位不到（text 无任何非空行）→ None。只读原文，不伪造引文；quote 为原文逐字切片。
    """
    body = str(text or "")
    if not body.strip():
        return None
    lines = [(m.start(), m.group(0)) for m in re.finditer(r"[^\n]+", body)
             if m.group(0).strip()]
    tokens = _missing_context_tokens(terms, slots)
    best = None
    for start, raw in lines:
        line = raw.strip()
        score = 0
        hit = []
        for tok, w in tokens:
            if tok in line:
                if tok not in hit:
                    score += w
                    hit.append(tok)
        if score <= 0:
            continue
        # 表格行/字段行更可能承载「该要求应写在哪儿」的上下文；同等分数优先结构化行
        if ("|" in line) or ("｜" in line) or ("：" in line) or ("：" in line):
            score += 1
        key = score
        if best is None or key > best[0]:
            best = (key, start, raw, hit)
    if best is None:
        # 无可匹配线索 → 退化到「区段标题行」/首个非空行，仍给出可回查的缺失上下文；
        # 这是「该 sheet 未出现该要求」的最小可定位证据，不是伪造原文命中。
        for start, raw in lines:
            line = raw.strip()
            if ("|" in line) or ("｜" in line) or ("：" in line) or ("：" in line):
                continue
            if len(line) <= _MISSING_CONTEXT_TITLE_MAXLEN:
                best = (0, start, raw, [])
                break
        if best is None:
            best = (0, lines[0][0], lines[0][1], [])
    _score, start, raw, hit = best
    lead = len(raw) - len(raw.lstrip())
    quote = raw.strip()
    if len(quote) > 300:
        quote = quote[:300]
    cstart = start + lead
    return {"quote": quote,
            "char_start": cstart, "char_end": cstart + len(quote),
            "line": quote, "score": int(_score),
            "context_tokens": hit[:8],
            "locator": {"kind": "char_span", "char_start": cstart,
                        "char_end": cstart + len(quote)}}


def _missing_fail(slots, terms, text, detail: str) -> dict:
    """缺失类「不满足」结果 + 缺失上下文引文（L107 D5）。

    · 开关关：逐字回退旧结果（不满足 / quote=""）；
    · 开关开且定位到上下文行：不满足 + 逐字 quote + char_span/locator；
    · 开关开但原文无可用行（定位不到）：证据不足（fail-closed，不裸 fail）。
    """
    detail = str(detail or "")
    if not _missing_context_quote_fix_on():
        return {"state": "不满足", "detail": detail, "quote": "", "value": None}
    ctx = _missing_context_quote(slots, terms, text)
    if ctx is None:
        return {"state": "证据不足",
                "detail": detail + "；原文无可用上下文行，定位不到缺失位置（fail-closed 转人工）",
                "quote": "", "value": None, "missing_context": "unlocatable"}
    out = {"state": "不满足", "detail": detail, "value": None,
           "quote": ctx["quote"], "char_start": ctx["char_start"],
           "char_end": ctx["char_end"], "locator": ctx.get("locator") or {},
           "missing_context": True, "context_score": ctx.get("score") or 0}
    if ctx.get("context_tokens"):
        out["context_tokens"] = ctx["context_tokens"]
    return out


def _line_containing(text, token: str) -> str:
    """原文中含 token 的首个非空行（逐字）；找不到返回 ""。"""
    tok = str(token or "")
    if not tok:
        return ""
    for raw in re.finditer(r"[^\n]+", str(text or "")):
        line = raw.group(0)
        if tok in line:
            return line.strip()
    return ""


def judge_keyword(slots: dict, text: str) -> dict:
    """关键字类：支持 require / forbid / require_any（缺条款、缺证据）。"""
    req_any = slots.get("require_any") or []
    if req_any:
        from . import hooks as _hk
        missing, notes = [], []
        for x in req_any:
            r = _hk.clause_find(x, text or "")
            if (not r["found"]) or r["negated"]:
                missing.append(str(x))
                if r.get("matched"):
                    notes.append(f"{x}↔{r['matched']}")
        if missing:
            detail = "缺少：" + "、".join(missing) + (f"（同义匹配：{'；'.join(notes)}）" if notes else "")
            return _missing_fail(slots, req_any, text, detail)
        return {"state": "满足", "detail": "必备条款齐全（含同义表述）", "quote": "", "value": None}
    def _negated(word: str, text_: str) -> bool:
        """关键词前 4 字内出现否定词，视为否定语义。"""
        pos = (text_ or "").find(word)
        if pos < 0:
            return False
        prefix = (text_ or "")[max(0, pos - 5):pos]
        return any(x in prefix for x in ("未", "不", "无", "免", "没有", "无需"))

    req = slots.get("require") or ""
    forb = slots.get("forbid") or slots.get("forbidden") or ""
    if req:
        _found = req in text
        if _found and _negated(req, text):
            return {"state": "不满足", "detail": f"必需内容「{req}」处于否定语境",
                    "quote": _line_containing(text, req) or req}
        return ({"state": "满足", "detail": f"包含关键词「{req}」", "quote": req}
                if _found else _missing_fail(slots, [req], text, f"缺少必需内容「{req}」"))
    if forb:
        _found = forb in text
        _quote = forb
        if not _found and len(forb) >= 2:
            for _cand in (forb[:2], forb[-2:]):
                if _cand and _cand in text and not _negated(_cand, text):
                    _found, _quote = True, _cand
                    break
        if _found and _negated(_quote, text):
            return {"state": "满足", "detail": f"未出现（否定表述）「{_quote}」", "quote": _quote}
        return ({"state": "不满足", "detail": f"出现禁止内容「{forb}」", "quote": _quote}
                if _found else {"state": "满足", "detail": f"未出现「{forb}」", "quote": ""})
    return {"state": "不适用", "detail": "规则未配置可执行条件"}


# ---------------- 字段存在性 / 占位词 / 解析状态（SIGN 三态） ----------------
_FIELD_PLACEHOLDERS = ("待签", "待签名", "待签署", "待补签", "待补", "待填", "待定",
                       "未签", "签字", "盖章", "空白", "无", "未知", "N/A", "NA", "n/a",
                       "null", "None", "-", "—", "/", "／", ".")
_FIELD_UNREADABLE = ("OCR不可识别", "不可识别", "无法识别", "未识别", "识别失败",
                     "无法辨认", "字迹不清", "模糊不清", "无法确认", "□", "***", "___")
_FIELD_PARSE_INCOMPLETE = ("解析状态partial", "解析partial", "解析不完整", "解析失败",
                           "部分解析", "未完整解析", "ocr质量差", "OCR质量差",
                           "parse_partial", "partial")


def _field_list(slots: dict, key: str, default) -> tuple:
    vals = slots.get(key)
    if isinstance(vals, (list, tuple)):
        out = [str(x).strip() for x in vals if str(x or "").strip()]
        if out:
            return tuple(out)
    return tuple(default)


def judge_field_presence(slots: dict, text: str) -> dict:
    """必填字段判定：字段值可读 → 满足；空值/占位词 → 不满足；不可识别/解析不完整 → 证据不足。

    「空字段」与「无法识别」不是同一状态：输入解析完整时的明确空字段是业务违规（fail），
    OCR/解析不完整导致的内容不可读是证据不足（insufficient），不得当合规或违规。
    """
    field = str(slots.get("field") or slots.get("field_label")
                or slots.get("record_field") or slots.get("role") or "").strip()
    if not field:
        return {"state": "证据不足", "detail": "字段存在性判据缺少 field 配置",
                "quote": "", "value": None}
    body = str(text or "")
    placeholders = _field_list(slots, "placeholders", _FIELD_PLACEHOLDERS)
    unreadable = _field_list(slots, "unreadable_markers", _FIELD_UNREADABLE)
    parse_markers = _field_list(slots, "parse_incomplete_markers", _FIELD_PARSE_INCOMPLETE)
    parse_bad = [mk for mk in parse_markers if mk in body]
    m = re.search(re.escape(field) + r"[ \t]*(?:[:：]|为|是)?[ \t]*(?P<val>[^\n；;。]*)",
                  body)
    if not m:
        if parse_bad:
            return {"state": "证据不足",
                    "detail": f"未找到字段「{field}」，且文档解析状态不完整"
                              f"（{parse_bad[0]}），需补证/人工核验",
                    "quote": "", "value": None}
        return {"state": "不满足",
                "detail": f"记录未包含必填字段「{field}」（输入解析完整）",
                "quote": "", "value": None}
    val = str(m.group("val") or "").strip()
    quote = body[m.start():m.end()].strip()[:120]
    if not val:
        if parse_bad:
            return {"state": "证据不足",
                    "detail": f"字段「{field}」为空但文档解析不完整"
                              f"（{parse_bad[0]}），不能确认是明确空字段",
                    "quote": quote, "value": ""}
        return {"state": "不满足",
                "detail": f"字段「{field}」为空值（输入解析完整，明确空字段）",
                "quote": quote, "value": ""}
    if any(mk in val for mk in unreadable) or re.fullmatch(r"[\[(（][^\])）]{0,20}[\])）]", val):
        return {"state": "证据不足",
                "detail": f"字段「{field}」内容不可识别（{val[:30]}），OCR/解析不完整，需人工核验",
                "quote": quote, "value": val}
    if val in placeholders or any(val == p for p in placeholders):
        return {"state": "不满足",
                "detail": f"字段「{field}」为占位词「{val}」，不是有效人员标识",
                "quote": quote, "value": val}
    return {"state": "满足",
            "detail": f"字段「{field}」已填写：{val[:30]}",
            "quote": quote, "value": val}


def _is_field_presence_rule(slots: dict) -> bool:
    """是否字段存在性判据（显式模板，或声明 field 且无 metric/关键词条件）。"""
    if not isinstance(slots, dict):
        return False
    tpl = str(slots.get("_template") or "").strip().lower()
    if tpl in ("field_presence", "field_required", "field", "personnel_field"):
        return True
    return bool(slots.get("field")) and not slots.get("metric") \
        and not any(slots.get(k) for k in ("require", "forbid", "forbidden", "require_any"))


_PRESENCE_KEYS = {
    "completeness": "required_docs", "record": "record_field",
    "personnel": "role", "equipment": "equipment",
    "label": "item", "citation": "cited", "frequency": "action",
}


def _eval_expr(expr, text: str, facts: list) -> dict:
    """最小三值逻辑：all_of / any_of / not（未知不当作假）。"""
    if not isinstance(expr, dict):
        return {"state": "证据不足", "detail": "条件表达式非法"}
    if "not" in expr:
        r = _eval_expr(expr["not"], text, facts)
        return {"state": {"满足": "不满足", "不满足": "满足"}.get(r["state"], "证据不足"),
                "detail": "not: " + r.get("detail", "")}
    if "all_of" in expr or "any_of" in expr:
        key = "all_of" if "all_of" in expr else "any_of"
        parts = [_eval_expr(x, text, facts) for x in (expr.get(key) or [])]
        states = [p["state"] for p in parts]
        if key == "all_of":
            if any(x == "不满足" for x in states):
                return {"state": "不满足", "detail": "all_of 有子条件不满足"}
            if all(x == "满足" for x in states) and states:
                return {"state": "满足", "detail": "all_of 全部满足"}
            return {"state": "证据不足", "detail": "all_of 存在未知条件"}
        if any(x == "满足" for x in states):
            return {"state": "满足", "detail": "any_of 至少一条满足"}
        if states and all(x == "不满足" for x in states):
            return {"state": "不满足", "detail": "any_of 全部不满足"}
        return {"state": "证据不足", "detail": "any_of 存在未知条件"}
    if _is_cross_position_rule(expr):
        return judge_cross_position(expr if isinstance(expr.get("cross_position"), dict)
                                    else {"cross_position": expr}, text)
    if _is_sum_check_rule(expr):
        return judge_sum_check(expr if isinstance(expr.get("sum_check"), dict)
                               else {"sum_check": expr}, text)
    # P0-5 D2 修复第 3 项：ALTER 类型算子 + 跨角色关系算子（与 judge_rule 同源）
    if _is_alter_detect_rule(expr):
        return judge_alter_detect(expr if isinstance(expr.get("alter_detect"), dict)
                                  else {"alter_detect": expr}, text)
    if _is_cross_role_limit_rule(expr):
        return judge_cross_role_limit(expr if isinstance(expr.get("cross_role_limit"), dict)
                                      else {"cross_role_limit": expr}, text)
    if _is_cross_rule(expr):
        return judge_cross(expr, facts, text)
    if is_limit_rule(expr):
        return judge_limit(expr, facts, text)
    if expr.get("require") or expr.get("forbid") or expr.get("require_any"):
        return judge_keyword(expr, text)
    return {"state": "证据不足", "detail": "条件缺可执行要素"}


def judge_enum(slots: dict, text: str) -> dict:
    """枚举/集合约束（op in/not_in，客体 values[]）判定。

    三态口径：
    - in：文中命中任一允许取值 → 满足；未命中 → 证据不足（不把「没找到」猜成违规）；
    - not_in：文中出现禁止取值 → 不满足；未出现且能找到指标证据 → 满足；
      指标与取值都找不到 → 证据不足；
    - 算子/取值集合缺失或非法 → 执行失败/证据不足，不默认放行。
    """
    metric = str(slots.get("metric") or "")
    raw_op = str(slots.get("op") or slots.get("operator") or "in").strip()
    values = []
    op = ""
    try:
        from . import rule_ir2 as _ir2
        values = _ir2._enum_values(slots)
        op = {"in": "in", "not_in": "not_in", "=": "in", "!=": "not_in"}.get(
            _ir2.normalize_operator(raw_op) or raw_op, "")
    except Exception:
        values = []
        op = ""
    if not values:
        return {"state": "证据不足", "detail": "枚举规则缺少取值集合 values，无法判定",
                "quote": "", "value": None}
    if not op:
        return {"state": "执行失败", "detail": f"不支持的枚举算子：{raw_op}",
                "quote": "", "value": None}
    body = str(text or "")
    if not body.strip():
        return {"state": "证据不足", "detail": f"无原文证据，无法核对「{metric or '枚举'}」取值",
                "quote": "", "value": None}
    hits = [v for v in values if v in body]
    if op == "in":
        if hits:
            return {"state": "满足", "detail": f"{metric} 取值命中允许集合：{hits[0]}",
                    "quote": hits[0], "value": hits[0]}
        return {"state": "证据不足",
                "detail": f"文中未找到「{metric}」的允许取值（{('、'.join(values))[:40]}），不猜违规",
                "quote": "", "value": None}
    # not_in / !=
    if hits:
        return {"state": "不满足", "detail": f"{metric} 出现禁止取值：{hits[0]}",
                "quote": hits[0], "value": hits[0]}
    if metric and metric not in body:
        return {"state": "证据不足", "detail": f"文中未找到「{metric}」相关证据",
                "quote": "", "value": None}
    return {"state": "满足",
            "detail": f"{metric} 未出现禁止取值（{('、'.join(values))[:40]}）", "quote": "", "value": None}


def judge_rule(slots: dict, text: str, facts: list, aliases: dict | None = None) -> dict:
    # L62 B3：精确算子（==/≠）只支持数值/日期/枚举；文本包含类判据不支持精确算子 →
    # fail-closed（执行失败），不得退化成 contains 静默给结论。=0 回退历史行为。
    if _opspec_fix_on("exact_op") and isinstance(slots, dict):
        _op_raw = str(slots.get("op") or slots.get("operator") or "").strip()
        if _op_raw in ("==", "≠", "＝", "!＝", "!==") and (
                any(k in slots for k in ("require", "forbid", "forbidden", "require_any"))
                or str(slots.get("_template") or "") in (
                    "completeness", "personnel", "label", "citation", "record",
                    "frequency", "semantic")):
            return {"state": "执行失败",
                    "detail": (f"精确算子 {_op_raw} 不支持文本包含/要素类判据"
                               "（fail-closed：请改用 contains/not_contains 或枚举 in/not_in）"),
                    "quote": "", "value": None, "unsupported_exact_type": True}
    # L42 ① 文本路径对象绑定：同一 metric 多对象取值不得合并判定（=0 回退整篇取数）。
    # 仅对"有数值判据（metric + op/range）"的规则生效；require_present/require_unchanged/
    # prohibited 等非数值模板的 object 常是整句/锚点，绑定会把应判态误判为"不适用"。
    _cat = str(slots.get("_template") or slots.get("category") or slots.get("type") or "")
    _v3_obj_ok = (bool(slots.get("metric")) and bool(
        slots.get("op") or slots.get("range") or slots.get("value") is not None
        or _cat in ("limit", "range"))) or bool(
        slots.get("cross_role_limit") or slots.get("consistency") or slots.get("cross_position"))
    if _fix3_on("object_bind") and _v3_obj_ok:
        _ob = _v3_object_bind(slots, text)
        if _ob.get("active"):
            if _ob.get("absent"):
                return {"state": "不适用",
                        "detail": (f"原文未出现规则对象「{_ob.get('key')}」，"
                                   f"本规则对该文档不适用（不按其它对象的取值判定）"),
                        "quote": "", "value": None, "object_unbound": _ob.get("key")}
            text = _ob.get("text") or text
    # 适用条件 / 例外（P1-7）：不适用则直接返回，不进入判定
    try:
        from . import hooks as _hk
        ap = _hk.rule_applicable(slots, text)
        if not ap.get("applicable"):
            return {"state": "不适用", "detail": ap.get("reason", ""), "quote": "", "value": None}
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    if any(k in slots for k in ("all_of", "any_of", "not")):
        return _eval_expr(slots, text, facts)
    # 文本级关系/算术算子（P0-5 D2 修复第 2 项）：跨位置一致性、分项合计算术。
    # 放在 cross 汇总之前：它们的槽位形态（anchors/part_anchors）与跨表 aggregation 不同。
    if _is_cross_position_rule(slots):
        return judge_cross_position(slots, text)
    if _is_sum_check_rule(slots):
        return judge_sum_check(slots, text)
    # P0-5 D2 修复第 3 项：ALTER 类型算子（外部应有值比对）与跨角色关系算子。
    # 放在 cross 汇总之前：槽位形态（anchors+expected / lhs_anchors+rhs_anchor）
    # 与跨表 aggregation 不同，避免被 _is_cross_rule 抢走。
    if _is_alter_detect_rule(slots):
        return judge_alter_detect(slots, text)
    if _is_cross_role_limit_rule(slots):
        return judge_cross_role_limit(slots, text)
    if _is_cross_rule(slots):
        return judge_cross(slots, facts, text)
    # 字段存在性/占位词/解析状态（SIGN）：空字段、待签占位、OCR 不可识别三态分离
    if _is_field_presence_rule(slots):
        return judge_field_presence(slots, text)
    # L44 consistency 文本算子（编号/字符串跨位置一致性）：放在 limit 之前，避免带
    # metric/value（字段名形态）的一致性规则被 judge_limit 当成数值限值；只在规则显式
    # 声明一致性槽位且 RULEPROOF_CONSISTENCY_TEXT=1 时命中，limit/数值规则不受影响。
    if _is_consistency_text_rule(slots):
        return judge_consistency_text(slots, text)
    if str(slots.get("_template") or "") == "limit" and slots.get("metric"):
        try:
            from . import rule_ir2 as _ir2
            _c = _ir2.compile_three_segment(slots)
            if not _c["ok"]:
                return {"state": "执行失败", "detail": "IR 校验失败：" + "；".join(_c["errors"]),
                        "quote": "", "value": None}
            slots = dict(slots)
            slots["op"] = _c["ir"]["operator"]
        except Exception:
            logging.getLogger(__name__).debug("IR compile skipped", exc_info=True)
    if is_limit_rule(slots):
        return judge_limit(slots, facts, text, aliases=aliases)
    if slots.get("require") or slots.get("forbid") or slots.get("require_any") or slots.get("forbidden"):
        return judge_keyword(slots, text)
    if slots.get("values") is not None or slots.get("enum") or slots.get("options"):
        return judge_enum(slots, text)
    tpl = str(slots.get("_template") or "")
    terms = slots.get("_terms") or []
    if tpl in ("completeness", "personnel", "label", "citation", "record", "frequency") and terms:
        missing = []
        for x in terms:
            if x in (text or ""):
                continue
            if len(x) >= 2 and (x[:2] in (text or "") or x[-2:] in (text or "")):
                continue
            missing.append(x)
        if missing:
            return _missing_fail(slots, terms, text, "缺少：" + "、".join(missing))
        return {"state": "满足", "detail": "要素齐全：" + "、".join(terms), "quote": "、".join(terms)}
    key = _PRESENCE_KEYS.get(tpl)
    if key:
        want = str(slots.get(key) or "").strip()
        if want and want in (text or ""):
            return {"state": "满足", "detail": f"文档包含「{want}」", "quote": want}
        return {"state": "证据不足",
                "detail": f"未在文中找到「{want}」，需补充证据（模板 {tpl}）", "quote": ""}
    if tpl == "consistency":
        return {"state": "证据不足", "detail": "一致性模板需跨表事实，当前未取到足够事实", "quote": ""}
    # L39 ⑪ 平台无执行器的规则类型（如 conditional_clause）：不能报「不适用/na」
    # 被读成「本规则不适用」而静默放过；显式给「证据不足」转人工。
    # =0 回退到历史「不适用」口径。detail 文案保持不变（engine_level_probe 等按它识别 unsupported）。
    if _fix2_on("unsupported_type"):
        return {"state": "证据不足",
                "detail": "规则类型暂不支持自动执行（平台无该类型确定性执行器，转人工）",
                "quote": "", "value": None, "unsupported_type": True}
    return {"state": "不适用", "detail": "规则类型暂不支持自动执行"}


def all_from_text(metric: str, text: str, aliases: dict | None = None) -> list:
    """逐行提取同一指标的所有出现，供多行/多批审核使用。

    复用 _from_text 的别名与单位归一，不复制取数规则。
    """
    if not metric or not text:
        return []
    out = []
    seen = set()
    for line in str(text).splitlines():
        if not line.strip():
            continue
        val, quote = _from_text(metric, line, aliases=aliases)
        if val is None:
            continue
        key = (str(val), quote)
        if key in seen:
            continue
        seen.add(key)
        out.append({"value": val, "quote": quote or line[:60], "line": line})
    return out


# ---------------------------------------------------------------------------
# 跨行/跨表通用汇总原语
#
# 口径：
# - cross_values 只做「多行/多表取值 + 缺口报告」，缺值、空表、单位冲突不猜；
# - aggregate_values 只做同单位/可换算单位上的 sum/max/min/avg/count；
# - compare_values / compare_all 只做显式比较，未知比较符不默认放行；
# - judge_cross 把原语组合成现有五态：缺值/空表/单位冲突一律「证据不足」。
# 本段不修改 judge_limit 的单行口径；judge_rule 只有在显式 aggregation 汇总
# 或显式 cross_* 标记时才进入本段。
# ---------------------------------------------------------------------------

CROSS_AGGREGATIONS = ("sum", "max", "min", "avg", "count", "compare")
CROSS_VALUE_AGGREGATIONS = ("sum", "max", "min", "avg", "count")
CROSS_TEMPLATES = ("aggregate", "cross_aggregate", "cross_table", "cross_rows")

_CROSS_MISSING = frozenset((
    "", "-", "--", "—", "–", "/", "\\", "n/a", "na", "null", "none",
    "无", "未填", "待填", "空", "暂无", "不适用", "未提供", "缺失",
))
_CROSS_NUM_TOKEN = (
    r"([-−－]?\d{1,3}(?:,\d{3})+(?:\.\d+)?"
    r"|[-−－]?\d+(?:\.\d+)?(?:\s*[×xX]\s*10\s*[⁰¹²³⁴⁵⁶⁷⁸⁹0-9+\-]+)?)"
)
_CROSS_UNIT_FIX = (("°C", "℃"), ("摄氏度", "℃"), ("％", "%"),
                   ("㎏", "kg"), ("㎎", "mg"), ("µ", "μ"))
_CROSS_EXTRA_SCALE = dict(_REG_CROSS_EXTRA_SCALE)
_CROSS_SCALE = dict(_UNIT_SCALE)
_CROSS_SCALE.update(_CROSS_EXTRA_SCALE)
_CROSS_CURRENCY = {
    "元": "CNY", "万元": "CNY", "亿元": "CNY", "亿": "CNY",
    "CNY": "CNY", "RMB": "CNY", "人民币": "CNY",
    "美元": "USD", "USD": "USD", "港元": "HKD", "HKD": "HKD",
    "欧元": "EUR", "EUR": "EUR",
}
_CROSS_UNIT_WORDS = sorted({u for u in _CROSS_SCALE if u}, key=len, reverse=True)
_CROSS_UNIT_ALT = "|".join(re.escape(u) for u in _CROSS_UNIT_WORDS)
_CROSS_UNIT_HEAD_RE = re.compile(r"^\s*(" + _CROSS_UNIT_ALT + r")")
_CROSS_TEXT_UNIT_RE = re.compile(_CROSS_NUM_TOKEN + r"\s*(" + _CROSS_UNIT_ALT + r")")
_CROSS_NUMBER_RE = re.compile(r"^\s*[¥￥$]?\s*" + _CROSS_NUM_TOKEN + r"\s*(.*?)\s*$")


def _cross_norm_unit(u) -> str:
    u = str(u or "").strip()
    for old, new in _CROSS_UNIT_FIX:
        u = u.replace(old, new)
    # 压力等单位的写法归一（kpa/KPA/"千 帕"→kPa/千帕）；未注册单位保持原样，
    # 由 _cross_unit_key/_cross_convert 按「未知单位」处理，不猜成同一单位。
    return _unit_key(u) or u


def _cross_unit_key(u: str):
    """单位归一键：(量纲, 到基单位倍率)。量纲不同或倍率不同都不能直接汇总。"""
    u = _cross_norm_unit(u)
    if not u:
        return ("", 1.0)
    if u in _CROSS_CURRENCY:
        return ("money:" + _CROSS_CURRENCY[u], _CROSS_SCALE.get(u, 1.0))
    if u in ("%", "‰"):
        return ("percent", _CROSS_SCALE.get(u, 1.0))
    if u == "℃":
        return ("temp", 1.0)
    if u in ("秒", "s"):
        return ("time", _CROSS_SCALE.get(u, 1.0 / 60.0))
    dim = _unit_dim(u)
    if dim:
        return (dim, _CROSS_SCALE.get(u, 1.0))
    return ("unit:" + u, 1.0)


def _cross_convert(v: float, from_u: str, to_u: str):
    """跨表单位换算；量纲不同/未知单位/缺单位来源返回 None（由调用方判 insufficient）。"""
    fu, tu = _cross_norm_unit(from_u), _cross_norm_unit(to_u)
    if not fu and not tu:
        return v
    if not fu or not tu:
        # L86 P0-2：一侧有单位、另一侧无单位 → 不得静默按对方单位比较/换算。
        return None if _fact_identity_fix_on() else v
    if fu == tu:
        return v
    kf, kt = _cross_unit_key(fu), _cross_unit_key(tu)
    if not kf[0] or kf[0] != kt[0]:
        return None
    return v * kf[1] / kt[1]


def _cross_fmt(v) -> str:
    if isinstance(v, bool):
        return str(v)
    try:
        f = float(v)
    except Exception:
        return str(v)
    if f != f or f in (float("inf"), float("-inf")):
        return str(v)
    if abs(f - round(f)) < 1e-9:
        return str(int(round(f)))
    return "%.10g" % f


def _cross_tolerance(value, default=1e-9) -> float:
    if value in (None, ""):
        return default
    try:
        t = abs(float(value))
        return t if t > 0 else default
    except Exception:
        return default


def _cross_where(row: dict) -> str:
    table = str((row or {}).get("table") or "")
    row_no = str((row or {}).get("row") or "")
    if table and row_no:
        return "表«%s»第%s行" % (table, row_no)
    if table:
        return "表«%s»" % table
    if row_no:
        return "第%s行" % row_no
    return "文档"


def _cross_join_quotes(rows, limit=3) -> str:
    out = []
    for r in rows or []:
        q = str((r or {}).get("quote") or "").strip()
        if q and q not in out:
            out.append(q[:120])
        if len(out) >= limit:
            break
    return "；".join(out)


def _cross_fact_dict(f) -> dict:
    if hasattr(f, "to_dict"):
        try:
            d = f.to_dict()
            if isinstance(d, dict):
                return d
        except Exception:
            logging.getLogger(__name__).debug("cross fact to_dict skipped", exc_info=True)
    return f if isinstance(f, dict) else {}


def _cross_facts_list(facts) -> list:
    if isinstance(facts, dict):
        out = []
        for k, v in facts.items():
            if isinstance(v, dict):
                d = dict(v)
                d.setdefault("metric", k)
                out.append(d)
            else:
                out.append({"metric": k, "value": v})
        return out
    if isinstance(facts, (list, tuple, set)):
        return list(facts)
    return []


def _cross_metric_match(d: dict, metric: str) -> bool:
    name = str(metric or "").strip()
    if not name:
        return False
    kind = METRIC_KIND.get(name, name)
    if str(d.get("kind") or "") == kind:
        return True
    low = name.lower()
    for key in ("metric", "object", "name", "parameter"):
        if str(d.get(key) or "").strip().lower() == low:
            return True
    return False


def _cross_scope_match(d: dict, scope: str) -> bool:
    if not scope:
        return True
    hay = "".join(str(d.get(k) or "") for k in
                  ("context", "anchor", "unit", "object", "quote", "metric"))
    return scope in hay


def _cross_fact_table(d: dict) -> str:
    for key in ("table", "table_name", "sheet", "sheet_name"):
        if d.get(key) not in (None, ""):
            return str(d.get(key)).strip()
    anchor = str(d.get("anchor") or "")
    if "!" in anchor:
        return anchor.split("!", 1)[0].strip()
    return ""


def _cross_fact_row(d: dict) -> str:
    if d.get("row") not in (None, ""):
        return str(d.get("row")).strip()
    anchor = str(d.get("anchor") or "")
    if "!" in anchor:
        return anchor.split("!", 1)[1].strip()
    return ""


def _cross_fact_quote(d: dict) -> str:
    return str(d.get("quote") or d.get("context") or d.get("anchor") or "")[:200]


def _cross_split_cell(raw):
    """单元格 → (数值, 单位, 状态)。状态：'' 正常 / missing 缺值 / bad 无法解析。"""
    if raw is None:
        return None, "", "missing"
    if isinstance(raw, bool):
        return None, "", "bad"
    if isinstance(raw, (int, float)):
        return float(raw), "", ""
    s = str(raw).strip()
    if s.lower() in _CROSS_MISSING:
        return None, "", "missing"
    m = _CROSS_NUMBER_RE.match(s)
    if not m:
        return None, "", "bad"
    v = _num(str(m.group(1)).replace(",", ""))
    if v is None:
        return None, "", "bad"
    tail = str(m.group(2) or "").strip()
    unit = ""
    if tail:
        um = _CROSS_UNIT_HEAD_RE.match(tail)
        if um:
            unit = _cross_norm_unit(um.group(1))
        else:
            unit = _cross_norm_unit(re.split(r"[\s,，;；。]", tail, 1)[0])
    return v, unit, ""


def _cross_text_value_unit(occ: dict):
    """从 all_from_text 的出现回推原文数值与单位（_from_text 返回的是基单位值）。"""
    base = _num((occ or {}).get("value"))
    quote = str((occ or {}).get("quote") or (occ or {}).get("line") or "")
    if base is None:
        return None, ""
    tol = max(1e-9, abs(base) * 1e-9)
    first = None
    for m in _CROSS_TEXT_UNIT_RE.finditer(quote):
        raw = _num(str(m.group(1)).replace(",", ""))
        if raw is None:
            continue
        unit = _cross_norm_unit(m.group(2))
        if first is None:
            first = (raw, unit)
        scale = _CROSS_SCALE.get(unit, 1.0)
        if abs(raw * scale - base) <= tol or abs(raw - base) <= tol:
            return raw, unit
    if first:
        return first
    return base, ""


def _cross_requested_tables(slots: dict) -> list:
    def _as_list(v):
        if isinstance(v, str):
            parts = re.split(r"[,，;；\n]", v)
        elif isinstance(v, (list, tuple, set)):
            parts = [str(x) for x in v]
        else:
            return []
        return [x.strip() for x in parts if str(x or "").strip()]

    for key in ("tables", "sheets", "table_names", "sheet_names"):
        if slots.get(key):
            got = _as_list(slots.get(key))
            if got:
                return list(dict.fromkeys(got))
    for key in ("table", "sheet"):
        if slots.get(key):
            got = _as_list(slots.get(key))
            if got:
                return list(dict.fromkeys(got))
    return []


def _cross_base(status="ok", code="ok", reason="", source="", slots=None) -> dict:
    return {
        "status": status, "code": code, "reason": reason, "source": source,
        "metric": str((slots or {}).get("metric") or ""),
        "values": [], "rows": [], "tables": [], "unit": "", "count": 0,
        "missing_tables": [], "empty_tables": [], "missing": [], "conflicts": [],
    }


def _cross_trace(res: dict) -> dict:
    return {k: (res or {}).get(k) for k in
            ("status", "code", "reason", "source", "metric", "unit", "count", "tables",
             "missing_tables", "empty_tables", "missing", "conflicts", "aggregation", "value")}


def _cross_state(state: str, detail: str, quote: str = "", value=None, code: str = "", **extra) -> dict:
    out = {"state": state, "detail": detail, "quote": quote or "", "value": value,
           "code": code or ""}
    out.update(extra)
    return out


def _cross_insufficient(res: dict, detail="") -> dict:
    return _cross_state("证据不足", detail or (res or {}).get("reason") or "跨行/跨表证据不足",
                         _cross_join_quotes((res or {}).get("rows")), None,
                         (res or {}).get("code") or "insufficient",
                         aggregation=(res or {}).get("aggregation"),
                         count=(res or {}).get("count"), tables=(res or {}).get("tables") or [],
                         trace=_cross_trace(res or {}))


def _cross_failed(res: dict, detail="") -> dict:
    return _cross_state("执行失败", detail or (res or {}).get("reason") or "跨行/跨表执行失败",
                         "", None, (res or {}).get("code") or "cross_error",
                         trace=_cross_trace(res or {}))


def _rows_from_facts(facts, slots: dict, metric: str, scope: str) -> dict:
    res = _cross_base(source="facts", slots=slots)
    rows, groups, available, missing = [], {}, set(), []
    matched = 0
    for f in _cross_facts_list(facts):
        d = _cross_fact_dict(f)
        if not d:
            continue
        table = _cross_fact_table(d)
        row_no = _cross_fact_row(d)
        if table:
            available.add(table)
        if not _cross_metric_match(d, metric):
            continue
        if not _cross_scope_match(d, scope):
            continue
        matched += 1
        unit = _cross_norm_unit(d.get("unit") or "")
        quote = _cross_fact_quote(d)
        raw = d.get("value")
        v = _num(raw) if raw is not None else None
        if v is None and raw is not None:
            v, unit2, cell_status = _cross_split_cell(raw)
            if not unit and unit2:
                unit = unit2
            if cell_status:
                v = None
        if v is None:
            missing.append({"table": table, "row": row_no, "value": raw,
                            "unit": unit, "quote": quote, "reason": "missing_value"})
            continue
        rec = {"value": float(v), "raw": raw, "unit": unit, "table": table,
               "row": row_no, "quote": quote, "metric": metric,
               "source": str(d.get("source") or "fact")}
        rows.append(rec)
        groups.setdefault(table, []).append(rec)
    res.update(rows=rows, values=rows, groups=groups, available=available,
               missing=missing, matched=matched)
    return res


def _text_missing_rows(metric: str, text: str) -> list:
    """只把「指标名 + 明确空缺标记」识别为缺值；普通不含指标的句子不算缺值。"""
    aliases = [metric]
    try:
        aliases = _alias_names(metric) or [metric]
    except Exception:
        logging.getLogger(__name__).debug("cross alias lookup skipped", exc_info=True)
    aliases = [a for a in dict.fromkeys([str(x) for x in aliases if str(x or "").strip()])]
    out = []
    for i, line in enumerate(str(text or "").splitlines(), 1):
        s = line.strip()
        if not s:
            continue
        for a in aliases:
            pos = s.find(a)
            if pos < 0:
                continue
            tail = s[pos + len(a):pos + len(a) + 24]
            tail = re.sub(r"^\s*[（(][^）)]{0,12}[）)]", "", tail)
            m = re.match(r"^\s*[:：=＝\-—]?\s*([^\s，。；,;]{0,8})", tail)
            token = str(m.group(1) if m else "").strip().lower().rstrip("。；;")
            if token in _CROSS_MISSING:
                out.append({"table": "", "row": str(i), "value": token, "unit": "",
                            "quote": s[:120], "reason": "missing_value"})
                break
    return out


def _rows_from_text(text: str, slots: dict, metric: str) -> dict:
    res = _cross_base(source="text", slots=slots)
    raw_text = str(text or "")
    rows, missing = [], []
    available = {""} if raw_text.strip() else set()
    try:
        occs = all_from_text(metric, raw_text) if raw_text.strip() else []
    except Exception:
        logging.getLogger(__name__).debug("cross all_from_text failed", exc_info=True)
        occs = []
    for i, occ in enumerate(occs or [], 1):
        v, unit = _cross_text_value_unit(occ or {})
        if v is None:
            continue
        rows.append({"value": float(v), "raw": (occ or {}).get("value"), "unit": unit,
                     "table": "", "row": str(i),
                     "quote": str((occ or {}).get("quote") or (occ or {}).get("line") or "")[:200],
                     "metric": metric, "source": "text"})
    missing_policy = str(slots.get("missing_policy") or slots.get("on_missing")
                         or slots.get("missing") or "insufficient").strip().lower()
    if missing_policy not in ("skip", "ignore"):
        missing = _text_missing_rows(metric, raw_text)
    res.update(rows=rows, values=rows, groups={"": rows} if rows else {},
               available=available, missing=missing, matched=len(rows))
    return res


def _rows_from_tables(tables, slots: dict, metric: str) -> dict:
    res = _cross_base(source="tables", slots=slots)
    items = []
    if isinstance(tables, dict):
        for name, body in tables.items():
            name = str(name or "")
            if isinstance(body, dict) and ("rows" in body or "values" in body
                                           or "data" in body):
                items.append((name, body.get("rows") if "rows" in body else
                              (body.get("values") if "values" in body else body.get("data")),
                              body.get("unit") or ""))
            else:
                items.append((name, body, ""))
    elif isinstance(tables, (list, tuple)):
        for item in tables:
            if isinstance(item, dict) and ("rows" in item or "values" in item
                                           or "data" in item):
                items.append((str(item.get("table") or item.get("table_name")
                                 or item.get("sheet") or item.get("name") or ""),
                              item.get("rows") if "rows" in item else
                              (item.get("values") if "values" in item else item.get("data")),
                              item.get("unit") or ""))
            elif isinstance(item, dict) and (item.get("table") or item.get("sheet")):
                items.append((str(item.get("table") or item.get("sheet") or ""), [item], ""))
            elif isinstance(item, dict):
                items.append(("", [item], ""))
            else:
                items.append(("", [item], ""))
    else:
        res.update(status="failed", code="bad_tables",
                   reason="tables 必须是「表名→行列表」映射或表列表")
        return res

    rows, groups, available, missing = [], {}, set(), []
    column = slots.get("column")
    for name, body, default_unit in items:
        table = str(name or "").strip()
        available.add(table)
        if body is None:
            body = []
        if isinstance(body, (str, int, float, dict)):
            body = [body]
        try:
            body_list = list(body)
        except TypeError:
            body_list = [body]
        for idx, raw_row in enumerate(body_list, 1):
            row_no = str(idx)
            unit = _cross_norm_unit(default_unit)
            quote = ""
            if isinstance(raw_row, dict):
                if raw_row.get("metric") and not _cross_metric_match(raw_row, metric):
                    continue
                raw = raw_row.get("value")
                if raw is None:
                    raw = raw_row.get("amount")
                if raw is None:
                    raw = raw_row.get("val")
                if raw is None and metric in raw_row:
                    raw = raw_row.get(metric)
                if raw is None and column is not None:
                    raw = raw_row.get(column)
                row_no = str(raw_row.get("row") or idx)
                unit = _cross_norm_unit(raw_row.get("unit") or default_unit)
                quote = str(raw_row.get("quote") or raw_row.get("context") or "")[:200]
            elif isinstance(raw_row, (list, tuple)):
                col = column if column is not None else 0
                if isinstance(col, str) and col.isdigit():
                    col = int(col)
                if isinstance(col, int) and 0 <= col < len(raw_row):
                    raw = raw_row[col]
                else:
                    raw = raw_row[0] if raw_row else None
            else:
                raw = raw_row
            v, unit2, cell_status = _cross_split_cell(raw)
            if not unit and unit2:
                unit = unit2
            if cell_status:
                missing.append({"table": table, "row": row_no, "value": raw,
                                "unit": unit, "quote": quote,
                                "reason": "missing_value" if cell_status == "missing" else "bad_value"})
                continue
            rec = {"value": float(v), "raw": raw, "unit": unit, "table": table,
                   "row": row_no, "quote": quote, "metric": metric, "source": "table"}
            rows.append(rec)
            groups.setdefault(table, []).append(rec)
    res.update(rows=rows, values=rows, groups=groups, available=available,
               missing=missing, matched=len(rows))
    return res


def cross_values(slots=None, facts=None, text: str = "", tables=None) -> dict:
    """多行/多表取值原语。

    slots 支持的键：
      metric            必填，汇总指标
      unit/target_unit  目标单位；给出后同量纲值会换算到该单位
      tables/sheets/table/sheet  表名（或 sheet 名）选择；未给则用全部表
      scope             作用域过滤（与 judge_limit 同口径）
      missing_policy    insufficient（默认）| skip
      conflict_policy   insufficient（默认）| first | aggregate
      expected_count/min_count/expected_rows  最少取到几行，否则缺值
      column            结构化表按列下标/键取值
      unit_policy       ignore 时跳过单位一致性检查（count 场景）
    facts 支持统一事实 dict / Fact / NumFact；tables 支持
      {"表A": [12, "8万元", {"value": 3, "unit": "万元", "row": 4}]}
      或 [{"table": "表A", "unit": "万元", "rows": [...]}]

    返回 status=ok|insufficient|failed，并显式带 missing/empty_tables/
    missing_tables/conflicts；调用方不得把 insufficient 当 0 或空值继续汇总。
    """
    if isinstance(slots, str):
        slots = {"metric": slots}
    slots = dict(slots or {})
    metric = str(slots.get("metric") or slots.get("parameter") or "").strip()
    res = _cross_base(slots=slots)
    if not metric:
        res.update(status="failed", code="missing_metric", reason="未指定汇总指标 metric")
        return res

    target_unit = _cross_norm_unit(slots.get("unit") or slots.get("target_unit") or "")
    requested = _cross_requested_tables(slots)
    scope = str(slots.get("scope") or "")
    missing_policy = str(slots.get("missing_policy") or slots.get("on_missing")
                         or slots.get("missing") or "insufficient").strip().lower()
    conflict_policy = str(slots.get("conflict_policy") or slots.get("on_conflict")
                          or slots.get("conflict") or "insufficient").strip().lower()
    unit_policy = str(slots.get("unit_policy") or "").strip().lower()
    check_units = unit_policy not in ("ignore", "none", "skip") and slots.get("check_unit", True) is not False

    if tables is not None:
        parsed = _rows_from_tables(tables, slots, metric)
    elif _cross_facts_list(facts):
        parsed = _rows_from_facts(facts, slots, metric, scope)
        if not parsed.get("matched") and str(text or "").strip():
            parsed = _rows_from_text(text, slots, metric)
    else:
        parsed = _rows_from_text(text, slots, metric)
    if parsed.get("status") == "failed":
        res.update(status="failed", code=parsed.get("code") or "bad_source",
                   reason=parsed.get("reason") or "取值失败")
        return res
    res["source"] = parsed.get("source") or ""

    rows = list(parsed.get("rows") or [])
    available = set(parsed.get("available") or ())
    groups = parsed.get("groups") or {}
    missing = list(parsed.get("missing") or [])
    selected, missing_tables, empty_tables = [], [], []

    if requested:
        for t in requested:
            if t not in available:
                missing_tables.append(t)
            elif not groups.get(t) and not any(m.get("table") == t for m in missing):
                empty_tables.append(t)
        if (missing_tables or empty_tables) and missing_policy not in ("skip", "ignore"):
            code = "missing_table" if missing_tables else "empty_table"
            bits = []
            if missing_tables:
                bits.append("未找到表：" + "、".join(missing_tables))
            if empty_tables:
                bits.append("空表（无该指标取值）：" + "、".join(empty_tables))
            res.update(status="insufficient", code=code,
                       reason="；".join(bits), missing_tables=missing_tables,
                       empty_tables=empty_tables, missing=missing,
                       tables=list(requested), count=0)
            return res
        selected = [t for t in requested if t not in missing_tables and t not in empty_tables]
        rows = [r for t in selected for r in groups.get(t, [])]
    else:
        rows = list(parsed.get("rows") or [])
        selected = sorted({t for t in available if groups.get(t)})

    if not rows:
        table_missing = [m for m in missing if not requested or m.get("table") in selected]
        code = "missing_value" if table_missing else "empty_table"
        reason = ("取到指标「%s」但值为空/无法解析" % metric) if table_missing else \
                 ("空表：未取到指标「%s」的数值" % metric)
        res.update(status="insufficient", code=code, reason=reason,
                   missing_tables=missing_tables, empty_tables=empty_tables,
                   missing=table_missing, tables=[], count=0)
        return res

    if requested:
        missing = [m for m in missing if m.get("table") in selected]
    if missing and missing_policy not in ("skip", "ignore"):
        first = missing[0]
        res.update(status="insufficient", code="missing_value",
                   reason="存在缺值行：%s 的「%s」为空/无法解析" %
                          (_cross_where(first), metric),
                   missing_tables=missing_tables, empty_tables=empty_tables,
                   missing=missing, rows=rows, values=rows, count=len(rows),
                   tables=sorted({str(r.get("table")) for r in rows if r.get("table")}))
        return res

    expected_raw = slots.get("expected_count", slots.get("min_count",
                                                         slots.get("expected_rows")))
    if expected_raw not in (None, ""):
        expected = _num(str(expected_raw))
        if expected is not None and len(rows) < expected:
            res.update(status="insufficient", code="missing_value",
                       reason="取到 %d 行，少于要求的 %s 行" % (len(rows), _cross_fmt(expected)),
                       missing_tables=missing_tables, empty_tables=empty_tables,
                       missing=missing, rows=rows, values=rows, count=len(rows),
                       tables=sorted({str(r.get("table")) for r in rows if r.get("table")}))
            return res

    _conv_any = False
    if check_units and target_unit:
        converted = []
        _src = str(parsed.get("source") or "")
        for r in rows:
            # L86 P0-2：规则指定目标单位、事实/文本行未标单位 → 不按规则单位静默比较。
            # 结构化 tables 输入（裸数字单元格）保留历史契约：单元格单位由规则槽位声明，
            # 以 unit_source=rule_slot 显式留痕（不静默改用规则单位而不披露）。
            _ru = str(r.get("unit") or "").strip()
            if _fact_identity_fix_on() and _src in ("facts", "text") and not _ru:
                res.update(status="insufficient", code="unit_source_missing",
                           reason=("缺计量单位：%s 的数值未标单位，规则单位 %s 无来源可继承"
                                   "（不按规则单位静默比较）"
                                   % (_cross_where(r), target_unit)),
                           rows=rows, values=rows, missing_tables=missing_tables,
                           empty_tables=empty_tables, missing=missing,
                           count=len(rows),
                           tables=sorted({str(r.get("table")) for r in rows if r.get("table")}))
                return res
            if _fact_identity_fix_on() and _src == "tables" and not _ru:
                # 结构化 tables 裸数字单元格：历史契约按规则槽位单位解读，显式留痕
                # unit_source=rule_slot（不静默改单位，也不引入跨单位换算）。
                converted.append({**r, "value": float(r["value"]),
                                  "source_unit": "", "unit": target_unit})
                continue
            cv = _cross_convert(r["value"], r.get("unit"), target_unit)
            if cv is None:
                res.update(status="insufficient", code="unit_mismatch",
                           reason="单位无法换算：%s %s%s → %s" %
                                  (_cross_where(r), _cross_fmt(r["value"]),
                                   r.get("unit") or "（未标单位）", target_unit),
                           rows=rows, values=rows, missing_tables=missing_tables,
                           empty_tables=empty_tables, missing=missing,
                           count=len(rows),
                           tables=sorted({str(r.get("table")) for r in rows if r.get("table")}))
                return res
            if _cross_norm_unit(r.get("unit") or "") != _cross_norm_unit(target_unit):
                _conv_any = True
            converted.append({**r, "value": float(cv),
                              "source_unit": r.get("unit") or "", "unit": target_unit})
        rows = converted
        common_unit = target_unit
    elif check_units:
        keys = {_cross_unit_key(r.get("unit")) for r in rows if r.get("unit")}
        has_empty = any(not r.get("unit") for r in rows)
        if len(keys) > 1 or (keys and has_empty):
            names = sorted({str(r.get("unit")) for r in rows if r.get("unit")})
            if has_empty:
                names.append("（未标单位）")
            res.update(status="insufficient", code="unit_inconsistent",
                       reason="单位不一致，且规则未指定目标单位：" + "、".join(names),
                       rows=rows, values=rows, missing_tables=missing_tables,
                       empty_tables=empty_tables, missing=missing,
                       count=len(rows),
                       tables=sorted({str(r.get("table")) for r in rows if r.get("table")}))
            return res
        common_unit = next((r.get("unit") for r in rows if r.get("unit")), "")
    else:
        common_unit = ""

    uniq, seen = [], set()
    for r in rows:
        if r.get("table") or r.get("row"):
            key = (r.get("table"), r.get("row"), round(float(r["value"]), 9), r.get("unit"))
        else:
            key = (r.get("table"), r.get("row"), round(float(r["value"]), 9),
                   r.get("unit"), str(r.get("quote") or "")[:80])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(r)
    rows = uniq

    cells = {}
    for r in rows:
        if r.get("table") and r.get("row"):
            cells.setdefault((r["table"], r["row"]), []).append(r)
    conflicts = []
    tol = _cross_tolerance(slots.get("conflict_tolerance"), 1e-9)
    for (table, row_no), cell_rows in cells.items():
        vals = [x["value"] for x in cell_rows]
        if max(vals) - min(vals) > tol:
            conflicts.append({"table": table, "row": row_no,
                              "values": [{"value": x["value"], "unit": x.get("unit"),
                                          "quote": x.get("quote")} for x in cell_rows]})
    if conflicts:
        if conflict_policy in ("first", "keep_first", "keep-first"):
            keep = {key: rs[0] for key, rs in cells.items()}
            rows = [r for r in rows
                    if not (r.get("table") and r.get("row"))
                    or keep.get((r["table"], r["row"])) is r]
        elif conflict_policy not in ("aggregate", "all", "sum", "allow", "keep"):
            c0 = conflicts[0]
            res.update(status="insufficient", code="value_conflict",
                       reason="同一行出现多个不一致数值：%s第%s行 %s" %
                              ("表«%s»" % c0["table"], c0["row"],
                               " / ".join(_cross_fmt(x["value"]) + (x.get("unit") or "")
                                          for x in c0["values"])),
                       conflicts=conflicts, rows=rows, values=rows,
                       missing_tables=missing_tables, empty_tables=empty_tables,
                       missing=missing, count=len(rows),
                       tables=sorted({str(r.get("table")) for r in rows if r.get("table")}))
            return res

    tables_used = sorted({str(r.get("table")) for r in rows if r.get("table")})
    _unit_source = ""
    if _fact_identity_fix_on():
        _unit_source = "conversion_table" if _conv_any else "rule_slot"
    res.update(status="ok", code="ok", reason="", rows=rows, values=rows,
               tables=tables_used, unit=common_unit, count=len(rows),
               unit_source=_unit_source,
               missing_tables=missing_tables, empty_tables=empty_tables,
               missing=missing, conflicts=conflicts)
    return res


def aggregate_values(values, how: str = "sum", unit: str = "") -> dict:
    """对多行/多表值做 sum/max/min/avg/count；空值和单位冲突显式 insufficient。"""
    if isinstance(values, dict):
        rows = values.get("rows") or values.get("values") or []
        unit = unit or values.get("unit") or ""
    else:
        rows = list(values or [])
    how = str(how or "sum").strip().lower()
    if how in ("average", "mean"):
        how = "avg"
    out = {"status": "ok", "code": "ok", "reason": "", "aggregation": how,
           "value": None, "count": 0, "unit": _cross_norm_unit(unit)}
    if how not in CROSS_VALUE_AGGREGATIONS:
        out.update(status="failed", code="bad_aggregation",
                   reason="不支持的汇总方式：%s（可选 %s）" %
                          (how, "/".join(CROSS_VALUE_AGGREGATIONS)))
        return out
    nums, units = [], []
    _converted = False
    tu = _cross_norm_unit(unit)
    for r in rows:
        if isinstance(r, dict):
            raw = r.get("value")
            ru = _cross_norm_unit(r.get("unit") or "")
        else:
            raw, ru = r, ""
        if raw is None:
            out.update(status="insufficient", code="missing_value", reason="汇总值中存在空值")
            return out
        v = _num(raw)
        if v is None:
            v, unit2, cell_status = _cross_split_cell(raw)
            if not ru and unit2:
                ru = unit2
            if cell_status or v is None:
                out.update(status="insufficient", code="missing_value",
                           reason="汇总值无法解析：%s" % str(raw)[:40])
                return out
        # L86 P0-2：汇总值非有限（NaN/Inf）→ 证据不足，不得进入阈值比较/求和。
        if _fact_identity_fix_on() and not math.isfinite(float(v)):
            out.update(status="insufficient", code="non_finite",
                       reason="汇总值非有限（NaN/Inf），不参与判定")
            return out
        # L86 P0-2：目标单位由规则槽位给出、事实行无单位 → 不得把数值静默当目标单位。
        if _fact_identity_fix_on() and how != "count" and tu and not ru:
            out.update(status="insufficient", code="unit_source_missing",
                       reason=("缺计量单位：汇总行未标单位，规则单位 %s 无来源可继承"
                               "（不按规则单位静默比较）" % tu))
            return out
        if tu and ru:
            cv = _cross_convert(v, ru, tu)
            if cv is None:
                out.update(status="insufficient", code="unit_mismatch",
                           reason="单位无法换算：%s%s → %s" % (_cross_fmt(v), ru, tu))
                return out
            if _cross_norm_unit(ru) != tu:
                _converted = True
            v = cv
        nums.append(float(v))
        units.append(ru)
    out["count"] = len(nums)
    if not nums:
        out.update(status="insufficient", code="empty_table", reason="空表：没有可汇总的值")
        return out
    if not tu and how != "count":
        keys = {_cross_unit_key(u) for u in units if u}
        has_empty = any(not u for u in units)
        if len(keys) > 1 or (keys and has_empty):
            names = sorted({u for u in units if u})
            if has_empty:
                names.append("（未标单位）")
            out.update(status="insufficient", code="unit_inconsistent",
                       reason="单位不一致，无法直接汇总：" + "、".join(names))
            return out
        out["unit"] = next((u for u in units if u), "")
    elif tu:
        out["unit"] = tu
    if _fact_identity_fix_on():
        out["unit_source"] = "conversion_table" if _converted else "rule_slot"
    if how == "count":
        out["value"] = float(len(nums))
        return out
    if how == "sum":
        value = math.fsum(nums)
    elif how == "max":
        value = max(nums)
    elif how == "min":
        value = min(nums)
    else:
        value = math.fsum(nums) / len(nums)
    out["value"] = float(value)
    return out


def compare_values(left, op: str = "=", right=None, tolerance=1e-9) -> dict:
    """显式比较原语；未知操作符/不可比较值返回 failed，不默认放行。"""
    op = str(op or "=").strip()
    tol = _cross_tolerance(tolerance)
    out = {"status": "ok", "code": "ok", "reason": "", "op": op,
           "left": left, "right": right, "tolerance": tol, "result": None}
    if left is None or right is None or not str(left).strip() or not str(right).strip():
        out.update(status="insufficient", code="missing_value",
                   reason="比较值缺失/为空，不能默认相等")
        return out
    a, b = _num(str(left).replace(",", "").replace("，", "")), \
        _num(str(right).replace(",", "").replace("，", ""))
    if a is not None and b is not None:
        # L86 P0-2：非有限数（NaN/Inf）不得进入比较落成 满足/不满足。
        if _fact_identity_fix_on() and not (math.isfinite(a) and math.isfinite(b)):
            out.update(status="insufficient", code="non_finite",
                       reason="比较值非有限（NaN/Inf），不参与判定",
                       left=a, right=b)
            return out
        if op in (">=", "≥"):
            ok = a >= b
        elif op in ("<=", "≤"):
            ok = a <= b
        elif op == ">":
            ok = a > b
        elif op == "<":
            ok = a < b
        elif op in ("=", "=="):
            ok = abs(a - b) <= tol
        elif op in ("!=", "≠"):
            ok = abs(a - b) > tol
        else:
            out.update(status="failed", code="bad_operator",
                       reason="不支持的比较符：%s" % op)
            return out
        out.update(left=a, right=b, result=bool(ok))
        return out
    sa, sb = str(left if left is not None else "").strip(), str(right if right is not None else "").strip()
    if op in ("=", "=="):
        out.update(result=sa == sb, left=sa, right=sb)
        return out
    if op in ("!=", "≠"):
        out.update(result=sa != sb, left=sa, right=sb)
        return out
    out.update(status="failed", code="bad_value",
               reason="非数值只能做相等/不等比较：%s / %s" % (sa[:30], sb[:30]))
    return out


def compare_all(values, op: str = "=", tolerance=1e-9) -> dict:
    """多值一致性比较：全部与第一个值按 op 比较。至少两个值。"""
    vals = []
    for x in values or []:
        vals.append(x.get("value") if isinstance(x, dict) else x)
    out = {"status": "ok", "code": "ok", "reason": "", "op": str(op or "=").strip(),
           "values": vals, "result": None, "mismatches": []}
    if len(vals) < 2:
        out.update(status="insufficient", code="insufficient_values",
                   reason="至少需要两个值才能做多值比较")
        return out
    base = vals[0]
    for i, v in enumerate(vals[1:], 1):
        c = compare_values(base, op, v, tolerance)
        if c.get("status") != "ok":
            return {**out, **c}
        if not c.get("result"):
            out["mismatches"].append({"index": i + 1, "left": base, "right": v})
    out["result"] = not out["mismatches"]
    return out


def _cross_agg_name(slots: dict) -> str:
    return str(slots.get("aggregation") or slots.get("agg") or slots.get("summary") or "sum").strip().lower()


def _is_cross_rule(slots) -> bool:
    if not isinstance(slots, dict):
        return False
    if str(slots.get("_template") or "") in CROSS_TEMPLATES:
        return True
    if slots.get("cross_table") or slots.get("cross_rows") or slots.get("cross_aggregate") \
            or slots.get("multi_table"):
        return True
    agg = str(slots.get("aggregation") or slots.get("agg") or "").strip().lower()
    if agg in CROSS_VALUE_AGGREGATIONS:
        return True
    if agg == "compare":
        return bool(slots.get("left") or slots.get("right") or slots.get("compare")
                    or slots.get("across_tables") or slots.get("by_table")
                    or slots.get("compare_mode") or slots.get("tables") or slots.get("sheets"))
    return False


_CROSS_AGG_LABEL = {"sum": "合计", "max": "最大值", "min": "最小值",
                    "avg": "平均值", "count": "计数"}


def _cross_where_label(res: dict) -> str:
    tables_ = [t for t in (res.get("tables") or []) if t]
    if len(tables_) > 1:
        return "跨 %d 表" % len(tables_)
    if tables_:
        return "表«%s»" % tables_[0]
    return "文档"


def cross_aggregate(slots=None, facts=None, text: str = "", tables=None) -> dict:
    """cross_values + aggregate_values 的组合原语（不做阈值判定）。"""
    if isinstance(slots, str):
        slots = {"metric": slots}
    slots = dict(slots or {})
    how = _cross_agg_name(slots)
    if how not in CROSS_VALUE_AGGREGATIONS:
        return {"status": "failed", "code": "bad_aggregation", "reason": "不支持的汇总方式：%s" % how,
                "aggregation": how, "values": [], "rows": [], "tables": [], "unit": "", "count": 0}
    spec = dict(slots)
    spec["aggregation"] = how
    if how == "count":
        spec["unit_policy"] = "ignore"
    vals = cross_values(spec, facts, text, tables)
    if vals.get("status") != "ok":
        return {**vals, "aggregation": how}
    agg = aggregate_values(vals.get("rows") or [], how, unit=vals.get("unit") or "")
    out = {**vals, **agg, "aggregation": how}
    # L86：跨单位换算的 unit_source 以「发生过换算」为准（aggregate 只看已归一后的行）。
    if _fact_identity_fix_on() and (
            vals.get("unit_source") == "conversion_table"
            or agg.get("unit_source") == "conversion_table"):
        out["unit_source"] = "conversion_table"
    return out


def _judge_cross_value(slots: dict, facts, text: str, tables, how: str) -> dict:
    target_raw = slots.get("value", slots.get("threshold"))
    if isinstance(target_raw, (list, tuple, dict)) or target_raw in (None, ""):
        return _cross_state("执行失败", "跨表汇总缺少可比较阈值 value", "", None,
                            "missing_threshold", aggregation=how)
    target = _num(str(target_raw).replace(",", ""))
    if target is None:
        return _cross_state("执行失败", "跨表汇总阈值无法解析：%s" % str(target_raw)[:40],
                            "", None, "bad_threshold", aggregation=how)
    spec = dict(slots)
    spec["aggregation"] = how
    if how == "count":
        spec["unit_policy"] = "ignore"
    res = cross_aggregate(spec, facts, text, tables)
    if res.get("status") == "insufficient":
        out = _cross_insufficient(res)
        if _fact_identity_fix_on() and res.get("code") == "unit_source_missing":
            out["unit_source_missing"] = True
        return out
    if res.get("status") != "ok":
        return _cross_failed(res)
    op = str(slots.get("op") or slots.get("operator") or ">=").strip()
    tol = _cross_tolerance(slots.get("tolerance"))
    cmp_res = compare_values(res.get("value"), op, target, tol)
    if cmp_res.get("status") != "ok":
        # L86：非有限数等「无法比较」是证据不足，不是执行失败（fail-closed 但不误报）。
        if _fact_identity_fix_on() and cmp_res.get("status") == "insufficient":
            return _cross_state("证据不足", cmp_res.get("reason") or "比较值不可用", "", None,
                                cmp_res.get("code") or "insufficient",
                                aggregation=how, trace=_cross_trace(res))
        return _cross_state("执行失败", cmp_res.get("reason") or "比较失败", "", None,
                            cmp_res.get("code") or "compare_failed",
                            aggregation=how, trace=_cross_trace(res))
    unit = _cross_norm_unit(res.get("unit") or "")
    detail = "%s%d行%s=%s%s %s %s%s" % (
        _cross_where_label(res), int(res.get("count") or 0),
        _CROSS_AGG_LABEL.get(how, how), _cross_fmt(res.get("value")), unit,
        op, _cross_fmt(target), unit)
    state = "满足" if cmp_res.get("result") else "不满足"
    _extra = {"unit_source": res.get("unit_source") or "rule_slot"} \
        if _fact_identity_fix_on() else {}
    return _cross_state(state, detail, _cross_join_quotes(res.get("rows")),
                        res.get("value"), "ok", aggregation=how,
                        count=res.get("count"), tables=res.get("tables") or [],
                        unit=unit, target=target, trace=_cross_trace(res), **_extra)


def _cross_side_base(slots: dict, side: str) -> dict:
    spec = {k: slots[k] for k in
            ("metric", "scope", "unit", "missing_policy", "on_missing",
             "conflict_policy", "on_conflict", "min_count", "expected_count",
             "unit_policy", "column") if k in slots}
    for k in ("tables", "sheets", "table", "sheet"):
        if k in slots:
            spec[k] = slots[k]
    for key, target in ((side + "_metric", "metric"),
                        (side + "_tables", "tables"), (side + "_sheets", "sheets"),
                        (side + "_table", "table"), (side + "_sheet", "sheet"),
                        (side + "_unit", "unit"), (side + "_agg", "aggregation")):
        if key in slots:
            spec[target] = slots[key]
    return spec


def _cross_side_how(spec: dict) -> str:
    how = str(spec.get("aggregation") or spec.get("agg") or "").strip().lower()
    return how if how in CROSS_VALUE_AGGREGATIONS else "sum"


def _cross_side_result(side: str, res: dict) -> dict:
    label = "左侧" if side == "left" else "右侧"
    if res.get("status") == "insufficient":
        out = _cross_insufficient(res)
        out["code"] = "compare_%s_%s" % (side, res.get("code") or "insufficient")
        out["detail"] = "%s取值不足：%s" % (label, res.get("reason") or out.get("detail") or "")
        return out
    out = _cross_failed(res)
    out["code"] = "compare_%s_%s" % (side, res.get("code") or "failed")
    out["detail"] = "%s取值失败：%s" % (label, res.get("reason") or out.get("detail") or "")
    return out


def _judge_compare_across(slots: dict, facts, text: str, tables) -> dict:
    metric = str(slots.get("metric") or "").strip()
    if not metric:
        return _cross_state("执行失败", "跨表比较缺少 metric", "", None, "missing_metric")
    how = str(slots.get("table_agg") or slots.get("value_agg") or slots.get("agg") or "sum").strip().lower()
    how = how if how in CROSS_VALUE_AGGREGATIONS else "sum"
    spec = {k: v for k, v in slots.items() if k != "compare"}
    spec["aggregation"] = how
    spec.pop("left", None)
    spec.pop("right", None)
    if how == "count":
        spec["unit_policy"] = "ignore"
    res = cross_values(spec, facts, text, tables)
    if res.get("status") == "insufficient":
        out = _cross_insufficient(res)
        out["detail"] = "跨表比较取值不足：" + (res.get("reason") or "")
        return out
    if res.get("status") != "ok":
        return _cross_failed(res)
    table_names = [t for t in (res.get("tables") or []) if t]
    if len(table_names) < 2:
        return _cross_state("证据不足", "跨表比较至少需要两张表都有取值（当前 %d 表）" %
                            len(table_names), _cross_join_quotes(res.get("rows")), None,
                            "single_table", aggregation=how, count=res.get("count"),
                            tables=table_names)
    per_table = []
    for t in table_names:
        sub = [r for r in res.get("rows") or [] if r.get("table") == t]
        one = aggregate_values(sub, how, unit=res.get("unit") or "")
        if one.get("status") != "ok":
            out = _cross_insufficient({**one, "rows": sub, "tables": [t]})
            out["detail"] = "表«%s»汇总不足：%s" % (t, one.get("reason") or "")
            return out
        per_table.append({"table": t, "value": one.get("value"), "count": one.get("count"),
                          "unit": one.get("unit") or ""})
    op = str(slots.get("op") or slots.get("operator") or "=").strip()
    tol = _cross_tolerance(slots.get("tolerance"))
    cmp_res = compare_all([x["value"] for x in per_table], op, tol)
    if cmp_res.get("status") != "ok":
        if _fact_identity_fix_on() and cmp_res.get("status") == "insufficient":
            return _cross_state("证据不足", cmp_res.get("reason") or "比较值不可用", "",
                                None, cmp_res.get("code") or "insufficient",
                                aggregation=how, tables=table_names)
        return _cross_state("执行失败", cmp_res.get("reason") or "多值比较失败", "",
                            None, cmp_res.get("code") or "compare_failed",
                            aggregation=how, tables=table_names)
    unit = _cross_norm_unit(res.get("unit") or "")
    detail = "；".join("表«%s»%s=%s%s" % (x["table"], _CROSS_AGG_LABEL.get(how, how),
                                        _cross_fmt(x["value"]), unit or "")
                      for x in per_table)
    detail += "；要求 %s 一致" % op if op in ("=", "==", "!=", "≠") else "；要求两两 %s" % op
    state = "满足" if cmp_res.get("result") else "不满足"
    _extra = {"unit_source": res.get("unit_source") or "rule_slot"} \
        if _fact_identity_fix_on() else {}
    return _cross_state(state, detail, _cross_join_quotes(res.get("rows")),
                        per_table[0]["value"], "ok", aggregation=how,
                        count=res.get("count"), tables=table_names, unit=unit,
                        table_values=per_table, trace=_cross_trace(res), **_extra)


def _judge_cross_compare(slots: dict, facts, text: str, tables):
    """返回五态；没有左右/跨表条件时返回 None，由调用方退化为合计阈值比较。"""
    across = bool(slots.get("across_tables") or slots.get("by_table")) or \
        str(slots.get("compare_mode") or "").strip().lower() in ("across", "by_table", "table")
    if across:
        return _judge_compare_across(slots, facts, text, tables)

    flat = dict(slots)
    cmp = flat.get("compare")
    if isinstance(cmp, dict):
        for k in ("left", "right"):
            if k not in flat and k in cmp:
                flat[k] = cmp[k]
        for k, v in cmp.items():
            if k not in ("left", "right") and k not in flat:
                flat[k] = v

    left_spec = _cross_side_base(flat, "left")
    left_obj = flat.get("left")
    if isinstance(left_obj, dict):
        left_spec.update(left_obj)
    elif isinstance(left_obj, str) and left_obj.strip():
        left_spec["metric"] = left_obj.strip()
    left_how = _cross_side_how(left_spec)
    left_spec["aggregation"] = left_how

    right_obj = flat.get("right")
    right_kind = ""
    right_spec = _cross_side_base(flat, "right")
    right_number = None
    if right_obj is not None:
        if isinstance(right_obj, dict):
            right_spec.update(right_obj)
            if not right_obj.get("metric") and (right_obj.get("value") is not None
                                                or right_obj.get("threshold") is not None):
                right_kind = "value"
                right_number = right_obj.get("value", right_obj.get("threshold"))
                right_spec.pop("aggregation", None)
            else:
                right_kind = "rows"
        elif isinstance(right_obj, str) and _num(right_obj) is None:
            right_spec["metric"] = right_obj.strip()
            right_kind = "rows"
        elif right_obj is not None:
            right_kind = "value"
            right_number = right_obj
    elif flat.get("right_value") is not None:
        right_kind = "value"
        right_number = flat.get("right_value")
    elif flat.get("right_metric") or flat.get("metric2"):
        right_spec["metric"] = flat.get("right_metric") or flat.get("metric2")
        right_kind = "rows"
    elif flat.get("value", flat.get("threshold")) not in (None, ""):
        right_kind = "value"
        right_number = flat.get("value", flat.get("threshold"))
    if not right_kind:
        return None
    if not left_spec.get("metric"):
        left_spec["metric"] = flat.get("metric") or ""
    if right_kind == "rows":
        if not right_spec.get("metric"):
            right_spec["metric"] = left_spec.get("metric") or ""
        right_how = _cross_side_how(right_spec)
        right_spec["aggregation"] = right_how
    else:
        right_how = "value"

    outer_unit = _cross_norm_unit(flat.get("unit") or "")
    left_unit = _cross_norm_unit(left_spec.get("unit") or "")
    right_unit = _cross_norm_unit(right_spec.get("unit") or "") if right_kind == "rows" else \
        _cross_norm_unit(right_spec.get("unit") or "")
    if right_kind == "rows" and not outer_unit and bool(left_unit) != bool(right_unit):
        return _cross_state("证据不足", "左右两侧单位信息不完整，无法在不指定 unit 时比较",
                            "", None, "unit_missing")
    common_unit = outer_unit or left_unit or right_unit
    if common_unit:
        left_spec["unit"] = common_unit
        if right_kind == "rows":
            right_spec["unit"] = common_unit

    left_res = cross_aggregate(left_spec, facts, text, tables)
    if left_res.get("status") != "ok":
        return _cross_side_result("left", left_res)

    op = str(flat.get("op") or flat.get("operator") or "=").strip()
    tol = _cross_tolerance(flat.get("tolerance"))
    left_value = left_res.get("value")
    left_result_unit = _cross_norm_unit(left_res.get("unit") or "")

    if right_kind == "value":
        rv = _num(str(right_number).replace(",", "")) if right_number is not None else None
        if rv is None:
            return _cross_state("执行失败", "右侧阈值无法解析：%s" % str(right_number)[:40],
                                "", None, "bad_right_value")
        ru = right_unit or left_result_unit
        if not left_result_unit and ru:
            return _cross_state("证据不足", "左侧单位未知、右侧带单位，无法比较",
                                "", None, "unit_missing")
        _converted = False
        if left_result_unit and ru and ru != left_result_unit:
            cv = _cross_convert(rv, ru, left_result_unit)
            if cv is None:
                return _cross_state("证据不足", "左右单位无法换算：%s → %s" %
                                    (ru, left_result_unit), "", None, "unit_mismatch")
            rv = cv
            ru = left_result_unit
            _converted = True
        cmp_res = compare_values(left_value, op, rv, tol)
        if cmp_res.get("status") != "ok":
            if _fact_identity_fix_on() and cmp_res.get("status") == "insufficient":
                return _cross_state("证据不足", cmp_res.get("reason") or "比较值不可用",
                                    "", None, cmp_res.get("code") or "insufficient")
            return _cross_state("执行失败", cmp_res.get("reason") or "比较失败", "", None,
                                cmp_res.get("code") or "compare_failed")
        unit = left_result_unit or ru or ""
        detail = "%s%s=%s%s %s %s%s" % (_cross_where_label(left_res),
                                        _CROSS_AGG_LABEL.get(left_how, left_how),
                                        _cross_fmt(left_value), unit, op, _cross_fmt(rv), unit)
        _extra = {}
        if _fact_identity_fix_on():
            _extra["unit_source"] = ("conversion_table" if (_converted or (
                left_res.get("unit_source") == "conversion_table"))
                else "rule_slot")
        return _cross_state("满足" if cmp_res.get("result") else "不满足", detail,
                            _cross_join_quotes(left_res.get("rows")), left_value, "ok",
                            aggregation=left_how, count=left_res.get("count"),
                            tables=left_res.get("tables") or [], unit=unit,
                            right_value=rv, trace=_cross_trace(left_res), **_extra)

    right_res = cross_aggregate(right_spec, facts, text, tables)
    if right_res.get("status") != "ok":
        return _cross_side_result("right", right_res)
    right_value = right_res.get("value")
    right_result_unit = _cross_norm_unit(right_res.get("unit") or "")
    _converted = False
    if not left_result_unit and not right_result_unit:
        pass
    elif not left_result_unit or not right_result_unit:
        return _cross_state("证据不足", "左右两侧单位信息不完整，无法比较", "", None,
                            "unit_missing")
    elif left_result_unit != right_result_unit:
        cv = _cross_convert(right_value, right_result_unit, left_result_unit)
        if cv is None:
            return _cross_state("证据不足", "左右单位无法换算：%s → %s" %
                                (right_result_unit, left_result_unit), "", None, "unit_mismatch")
        right_value = cv
        right_result_unit = left_result_unit
        _converted = True
    cmp_res = compare_values(left_value, op, right_value, tol)
    if cmp_res.get("status") != "ok":
        if _fact_identity_fix_on() and cmp_res.get("status") == "insufficient":
            return _cross_state("证据不足", cmp_res.get("reason") or "比较值不可用", "",
                                None, cmp_res.get("code") or "insufficient")
        return _cross_state("执行失败", cmp_res.get("reason") or "比较失败", "", None,
                            cmp_res.get("code") or "compare_failed")
    unit = left_result_unit or right_result_unit or ""
    detail = "左%s%s=%s%s；右%s%s=%s%s；要求 %s" % (
        _cross_where_label(left_res), _CROSS_AGG_LABEL.get(left_how, left_how),
        _cross_fmt(left_value), unit,
        _cross_where_label(right_res), _CROSS_AGG_LABEL.get(right_how, right_how),
        _cross_fmt(right_value), unit, op)
    state = "满足" if cmp_res.get("result") else "不满足"
    tables_all = sorted(set(left_res.get("tables") or []) | set(right_res.get("tables") or []))
    _extra = {}
    if _fact_identity_fix_on():
        _extra["unit_source"] = ("conversion_table" if (_converted or (
            left_res.get("unit_source") == "conversion_table")
            or (right_res.get("unit_source") == "conversion_table"))
            else "rule_slot")
    return _cross_state(state, detail, _cross_join_quotes((left_res.get("rows") or [])
                                                         + (right_res.get("rows") or [])),
                        left_value, "ok", aggregation="compare",
                        count=(left_res.get("count") or 0) + (right_res.get("count") or 0),
                        tables=tables_all, unit=unit, left_value=left_value,
                        right_value=right_value, trace=_cross_trace(left_res), **_extra)


def judge_cross(slots=None, facts=None, text: str = "", tables=None) -> dict:
    """跨行/跨表汇总判定：五态输出，缺值/空表/单位不一致一律证据不足。

    支持：
      1) 阈值：{"metric":"采购金额","aggregation":"sum|max|min|avg|count",
                "op":"<=","value":25,"unit":"万元"}
      2) 左右比较：{"aggregation":"compare","metric":"合同金额","unit":"万元",
                    "left":{"tables":["汇总表"]},"right":{"tables":["明细表"]},"op":"="}
      3) 跨表一致：{"aggregation":"compare","across_tables":true,
                    "metric":"合同金额","table_agg":"sum","op":"="}
    显式 `unit` 时同量纲自动换算；未给 unit 时单位不一致直接 insufficient。
    """
    if isinstance(slots, str):
        slots = {"metric": slots}
    slots = dict(slots or {})
    agg = _cross_agg_name(slots)
    compare_requested = (agg == "compare" or bool(slots.get("across_tables"))
                         or bool(slots.get("by_table"))
                         or str(slots.get("compare_mode") or "").strip().lower()
                         in ("across", "by_table", "table")
                         or (slots.get("left") is not None and slots.get("right") is not None)
                         or bool(slots.get("compare")))
    if compare_requested:
        out = _judge_cross_compare(slots, facts, text, tables)
        if out is not None:
            return out
        return _judge_cross_value({**slots, "aggregation": "sum"}, facts, text, tables, "sum")
    if agg not in CROSS_VALUE_AGGREGATIONS:
        return _cross_state("执行失败", "不支持的汇总方式：%s" % agg, "", None,
                            "bad_aggregation", aggregation=agg)
    return _judge_cross_value(slots, facts, text, tables, agg)


# ---------------------------------------------------------------------------
# 文本级「跨位置一致性」与「合计算术」算子（P0-5 D2 修复第 2 项）
#
# 背景：D2 报告 §8.2-B/C 的执行器缺口——文本级 judge_rule 只会「单点取数 + 阈值
# 比较」，没有「同一事实在不同位置的值相互比对」和「分项求和与合计比对」两类
# 算术/关系算子，导致 D02-001（同一事实前后一致）、C01-001（分项与合计相符）
# 两类簇的 9 条明确规则漏报无法被任何判据覆盖。
#
# 本段只做**原文文本**取数（不依赖结构化 facts/tables），三态语义与既有算子一致：
#   cross_position  抽出 ≥2 个值 → 单位归一到同一基准 → 比对
#                   不一致 → 不满足（逐字引文 + 每处 locator）；一致 → 满足；
#                   可比出现 <2 → 证据不足（半可算，不猜违规）；配置非法 → 执行失败。
#   sum_check       抽分项与合计 → 同一单位基准求 fsum → 与合计比较
#                   超出容差 → 不满足；容差内 → 满足；缺项/缺合计 → 证据不足。
#
# 证据锚定：每处取值都带 locator（"第N段@@绝对偏移"）+ quote（原文逐字片段），
# 不编造、不跨句拼接；判定结果返回 evidence 数组供报告/复核逐条回查。
# ---------------------------------------------------------------------------
_XOP_UNIT_WORDS = (
    "个工作日", "日历天", "自然日", "个标段", "个自然村", "个组", "平方米", "平方分米",
    "平方公里", "立方米", "公里", "千米", "万元", "亿元", "千元", "百万元", "个月",
    "小时", "分钟", "MWp", "MW", "kW", "kWh", "kg", "mg", "吨", "厘米", "毫米", "米",
    "天", "日", "年", "家", "道", "座", "名", "人", "项", "套", "台", "张", "份", "处",
    "组", "条", "批", "次", "层", "页", "个", "元", "%", "‰", "℃", "分", "秒", "毫升",
    "升", "克",
)
_XOP_UNIT_ALT = "|".join(re.escape(u) for u in
                         sorted(set(_XOP_UNIT_WORDS), key=len, reverse=True))
_XOP_NUM = (r"[-−－]?(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?"
            r"|\d+(?:\.\d+)?(?:\s*[×xX]\s*10\s*[⁰¹²³⁴⁵⁶⁷⁸⁹0-9+\-]+)?)")
_XOP_OCC_RE = re.compile(r"(?P<num>" + _XOP_NUM + r")\s*(?P<unit>" + _XOP_UNIT_ALT + r")")
_XOP_CLAUSE_RE = re.compile(r"[^。；;\n\r！？!?]+")
_XOP_LABEL_SPLIT = re.compile(r"[，,、:：（）()\[\]【】|｜]")
_XOP_THRESHOLD_TAIL = ("达到", "不超过", "不少于", "不低于", "不高于", "以上", "以下",
                       "最多", "至少", "最高", "最低", "上限", "下限", "多于", "少于",
                       "超过", "不得", "应当", "可以", "需", "应")
_XOP_GRADE_CTX = ("分别", "依次", "各为", "不等", "分档", "档次", "逐级", "区间",
                  "幅度", "范围", "～", "~")
CROSS_POSITION_TEMPLATES = ("cross_position",)
SUM_CHECK_TEMPLATES = ("sum_check",)


def _xop_norm_label(raw, width: int = 20, strip_tail: bool = True) -> str:
    """标签归一：数字→删除（同一事实的数字不参与标签）、去序号/标点、可选去阈值尾词。

    strip_tail=False 时保留「以上/以下/不超过」等尾词，用于区分「平均值以上」与
    「平均值以下」这类只差阈值方向的标签（合计算术的分项名）。只做写法归一，
    不改写原文（引文仍取原文切片，可逐字回查）。
    """
    s = str(raw or "")
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[0-9０-９]+", "", s)
    s = re.sub(r"^[\s，。；、：:；,.!?！？（）()【】\[\]#\-—·]+", "", s)
    s = re.sub(r"[（(][^）)]{0,10}[）)]\s*$", "", s).strip()
    if strip_tail:
        for w in _XOP_THRESHOLD_TAIL:
            if s.endswith(w):
                s = s[: -len(w)]
    return s.strip()[:width]


def _xop_scan(text: str, label_width: int = 20) -> list:
    """原文 → 数值出现集（值 + 单位 + 归一标签 + 段号/偏移 + 逐字引文）。

    只在「不带句末标点」的分句内取数，避免把相邻条款的数字拼成一处；标签取数字
    前文最后一段（按顿号/逗号/冒号切分），保证「同一措辞的事实」才归到一组。
    """
    text = str(text or "")
    out = []
    for cm in _XOP_CLAUSE_RE.finditer(text):
        seg, seg_start = cm.group(0), cm.start()
        for m in _XOP_OCC_RE.finditer(seg):
            raw, unit = m.group("num"), m.group("unit")
            value = _num(str(raw).replace(",", "").replace("，", ""))
            if value is None:
                continue
            # L86 P0-2：非有限数（超长数字解析成 Inf 等）不得进入跨位置/合计裁决。
            if _fact_identity_fix_on() and not math.isfinite(float(value)):
                logging.getLogger(__name__).debug(
                    "xop_scan skipped non-finite numeric token: %r", raw)
                continue
            pre = seg[:m.start()]
            parts = [x for x in _XOP_LABEL_SPLIT.split(pre)]
            label_raw = (parts[-1] if parts else pre)[-label_width:]
            if not label_raw.strip() and len(parts) > 1:
                # 前一段以「：」结尾（如「R取值为：  15」）时，标签应取冒号前那一段
                label_raw = (parts[-2] + (parts[-1] if parts else ""))[-label_width:]
            label = _xop_norm_label(label_raw, width=label_width)
            label_full = _xop_norm_label(label_raw, width=max(label_width, 40),
                                         strip_tail=False)
            start = seg_start + m.start()
            end = seg_start + m.end()
            para = text.count("\n", 0, start) + 1
            out.append({
                "value": float(value), "raw": str(raw), "unit": unit,
                "unit_key": _cross_unit_key(_cross_norm_unit(unit)),
                "label": label, "label_full": label_full,
                "label_raw": label_raw.strip(), "clause": seg,
                "start": start, "end": end, "para": para,
                "locator": "第%d段@@%d" % (para, start),
                "quote": (label_raw[-12:] + seg[m.start():m.end()]).strip()[:120],
            })
    return out


def _xop_evidence(occ: dict) -> dict:
    return {"locator": occ.get("locator") or "", "quote": occ.get("quote") or "",
            "raw": occ.get("raw") or "", "unit": occ.get("unit") or "",
            "value": occ.get("value"), "label": occ.get("label") or ""}


def _xop_unit_convert(value, from_unit, to_unit):
    """同量纲换算到基准单位；量纲不同/未知单位/非有限数返回 None（不猜）。"""
    if _fact_identity_fix_on() and not _finite_num(value):
        return None
    if not to_unit:
        return float(value)
    got = _cross_convert(float(value), from_unit or "", to_unit)
    return None if got is None else float(got)


def _is_cross_position_rule(slots) -> bool:
    if not isinstance(slots, dict):
        return False
    if str(slots.get("_xop_kind") or "") == "cross_position":
        return True
    if str(slots.get("_template") or "") in CROSS_POSITION_TEMPLATES:
        return True
    return isinstance(slots.get("cross_position"), dict)


def _is_sum_check_rule(slots) -> bool:
    if not isinstance(slots, dict):
        return False
    if str(slots.get("_xop_kind") or "") == "sum_check":
        return True
    if str(slots.get("_template") or "") in SUM_CHECK_TEMPLATES:
        return True
    return isinstance(slots.get("sum_check"), dict)


def _xop_spec(slots: dict, key: str) -> dict:
    spec = (slots or {}).get(key)
    spec = dict(spec) if isinstance(spec, dict) else {}
    for k in ("anchors", "label_heads", "unit", "tolerance", "rel_tolerance",
              "min_values", "min_label_len", "total_anchor", "part_anchors",
              "part_heads", "window", "metric", "min_parts", "mode", "op", "operator",
              "part_scope", "structure", "exclude_units"):
        if k in (slots or {}) and k not in spec:
            spec[k] = (slots or {})[k]
    return spec


# ---------------------------------------------------------------------------
# 跨位置一致性的「分段限域」（P01-010 平台误报修复）
# 同一锚点在**不同路段/标段/项目**分别列示时，取值分属不同分段，不是「同一事实
# 多值」。分段信号（任一命中即算分段边界）：桩号区间 / 标段(包/合同段) /
# 项目序号 / 线路编号 / 独立的「工程概况」小节。
# ---------------------------------------------------------------------------
_XOP_SEG_SOURCES = (
    ("km", re.compile(r"K\d+\+\d+(?:\.\d+)?\s*[-~～—－–至]\s*K\d+\+\d+(?:\.\d+)?")),
    ("lot", re.compile(r"第\s*\d+\s*(?:标段|包|合同段)|\d+\s*-\s*\d+\s*标段")),
    ("road", re.compile(r"[国省县乡]道\s*\d+")),
    ("proj", re.compile(r"(?m)(?:^[ \t]*|[：:；;。、]\s*)[（(]\s*\d+\s*[）)]")),
    ("section", re.compile(r"(?m)^[ \t]*(?:\d+(?:\.\d+)*[.、]?\s*)?工程概况")),
)


def _xop_seg_key(kind: str, raw: str) -> tuple:
    s = re.sub(r"\s+", "", str(raw or ""))
    s = re.sub(r"[~～—－–]", "-", s)
    return (kind, s)


def _xop_seg_marks(text: str) -> list:
    """分段边界信号：[(位置, 分段键)]，按位置升序；同一位置多种信号都保留。"""
    body = str(text or "")
    marks = []
    for kind, rx in _XOP_SEG_SOURCES:
        for m in rx.finditer(body):
            marks.append((m.start(), _xop_seg_key(kind, m.group(0))))
    marks.sort(key=lambda x: x[0])
    return marks


def _xop_seg_assign(rows, text: str) -> list:
    """每个取值各回溯到最近的分段信号；无信号 → None（不猜、不当作同段）。"""
    marks = _xop_seg_marks(text)
    out = []
    for row in rows:
        pos = int(row.get("start") or 0)
        key = None
        for mark_pos, mark_key in marks:
            if mark_pos > pos:
                break
            key = mark_key
        out.append(key)
    return out


def _xop_seg_scope(rows, text: str):
    """分段限域判定：返回 (每处分段键, 是否按「分段列示」豁免矛盾)。

    只有**每个取值都找到分段、且分段归属两两互不相同（≥2 个分段）**时才认定
    分段列示；任一取值无分段、或两个取值同段，都保持原逻辑（真矛盾不许放过）。
    """
    segs = _xop_seg_assign(rows, text)
    keys = [s for s in segs if s is not None]
    split = (len(keys) == len(rows) and len(keys) >= 2
             and len(set(keys)) == len(keys))
    return segs, split


def judge_cross_position(slots: dict, text: str) -> dict:
    """文本级跨位置一致性：同一事实/同一锚点的多处取值归一后比对。

    分段限域：同一锚点在各取值分属不同路段/标段/项目（桩号区间、标段/包号、
    项目序号、线路编号等）时，属分段列示、非同一事实多值 → 证据不足，不判矛盾；
    同段异值仍按原逻辑判矛盾。

    slots（或 slots.cross_position）支持：
      anchors       位置模式：出现位置/上下文锚点（如 ["合同金额","总价","合计"]），
                    每个锚点命中的值归一组，组内 ≥2 个值必须一致；
      discovery     +label_heads：发现模式（锚点未知时），按归一标签分组，
                    label 必须含 label_heads 之一，组内 ≥2 个值必须一致；
      unit          统一基准单位（缺省用该组首个出现的单位）；
      tolerance     绝对值容差（默认 0）；rel_tolerance 相对容差（默认 0）；
      min_values    最少可比出现数（默认 2）；min_label_len 发现模式最小标签长度（默认 4）。
    """
    spec = _xop_spec(slots, "cross_position")
    anchors = [str(a).strip() for a in (spec.get("anchors") or []) if str(a or "").strip()]
    heads = [str(h).strip() for h in (spec.get("label_heads") or []) if str(h or "").strip()]
    discovery = bool(spec.get("discovery")) or (not anchors and bool(heads))
    try:
        tolerance = float(spec.get("tolerance") or 0.0)
    except (TypeError, ValueError):
        tolerance = 0.0
    try:
        rel_tolerance = float(spec.get("rel_tolerance") or 0.0)
    except (TypeError, ValueError):
        rel_tolerance = 0.0
    try:
        min_values = max(2, int(spec.get("min_values") or 2))
    except (TypeError, ValueError):
        min_values = 2
    try:
        min_label_len = max(1, int(spec.get("min_label_len") or 4))
    except (TypeError, ValueError):
        min_label_len = 4
    exclude_units = {_cross_norm_unit(u) for u in (spec.get("exclude_units") or [])
                     if str(u or "").strip()}
    if not anchors and not heads:
        return _cross_state("执行失败", "跨位置一致性缺少 anchors（出现位置）或 label_heads",
                            "", None, "missing_anchors")
    body = str(text or "")
    if not body.strip():
        return _cross_state("证据不足", "无原文证据，无法做跨位置一致性比对", "", None,
                            "empty_text")
    occs = _xop_scan(body)
    groups = {}
    scope = str(spec.get("compare_scope") or "pool").strip().lower()
    if not discovery:
        # 锚点模式：默认「汇总口径」（把各锚点抽到的值汇到同一单位基准下比对——
        # 对应「合同金额/总价/合计」这类**不同措辞同一事实**）；compare_scope=per_anchor
        # 时按锚点各自分组（同一措辞重复出现必须一致）。
        for occ in occs:
            for idx, anchor in enumerate(anchors):
                an = _xop_norm_label(anchor, width=40)
                if not an:
                    continue
                if an in occ["label"] or an in occ["label_full"] or \
                        an in occ["label_raw"]:
                    key = (idx, occ["unit_key"]) if scope == "per_anchor" \
                        else (None, occ["unit_key"])
                    groups.setdefault(key, []).append(occ)
                    break
    else:
        for occ in occs:
            label = occ["label"]
            if len(label) < min_label_len:
                continue
            if any(w in occ["clause"] for w in _XOP_GRADE_CTX):
                continue
            if occ["unit"] in exclude_units:
                continue
            if heads:
                unit = occ["unit"]
                hit = any((_xop_norm_label(h, width=40) in label
                           or _xop_norm_label(h, width=40) in unit)
                          for h in heads if _xop_norm_label(h, width=40))
                if not hit:
                    continue
            groups.setdefault(("label", label, occ["unit_key"]), []).append(occ)
    compared, mismatches, insufficient = 0, [], []
    for key, rows in groups.items():
        base_unit = str(spec.get("unit") or "")
        if not base_unit:
            base_unit = rows[0]["unit"]
        vals = []
        for row in rows:
            got = _xop_unit_convert(row["value"], row["unit"], base_unit)
            if got is None:
                return _cross_state("证据不足",
                                    "单位无法换算到同一基准：%s → %s"
                                    % (row["unit"], base_unit),
                                    row["quote"], None, "unit_mismatch")
            vals.append(got)
        if len(vals) < min_values:
            insufficient.append({"key": key, "n": len(vals), "rows": rows})
            continue
        compared += 1
        tol = max(abs(tolerance), max(abs(v) for v in vals) * abs(rel_tolerance))
        if max(vals) - min(vals) > tol:
            mismatches.append({"key": key, "values": vals, "rows": rows,
                               "unit": base_unit,
                               "spread": max(vals) - min(vals)})
    # 分段限域：同一锚点在逐路段/逐标段/逐项目分别列示时，各取值分属不同分段，
    # 不是「同一事实多值」，不得判矛盾（P01-010 平台误报）。只有**每个取值都各自
    # 成段（分段归属两两互不相同）**才豁免；同段异值仍按原逻辑判矛盾。
    segmented, kept = [], []
    for m in mismatches:
        segs, split = _xop_seg_scope(m["rows"], body)
        if split:
            segmented.append({"mismatch": m, "segments": segs})
        else:
            kept.append(m)
    mismatches = kept
    evidence = []
    for m in mismatches:
        for row, val in zip(m["rows"], m["values"]):
            ev = _xop_evidence(row)
            ev["value_base"] = val
            ev["unit_base"] = m["unit"]
            evidence.append(ev)
    if mismatches:
        first = mismatches[0]
        vals_txt = "、".join("%s%s" % (_cross_fmt(v), first["unit"]) for v in first["values"])
        where = ("「%s」" % first["key"][1] if first["key"][0] == "label"
                 else ("锚点「%s」" % "/".join(anchors) if len(anchors) <= 3
                       else "锚点集合"))
        detail = ("跨位置一致性不一致：%d 组取值冲突；首组%s为 %s（差 %s%s），"
                  "共比对 %d 组/ %d 处取值"
                  % (len(mismatches), where, vals_txt, _cross_fmt(first["spread"]),
                     first["unit"], compared, sum(len(g) for g in groups.values())))
        return _cross_state("不满足", detail, _cross_join_quotes(
            [r for m in mismatches for r in m["rows"]], limit=3),
            first["values"][0], "cross_position_mismatch",
            evidence=evidence, compared_groups=compared,
            mismatch_groups=len(mismatches))
    if segmented:
        n_values = sum(len(s["mismatch"]["rows"]) for s in segmented)
        distinct = []
        for s in segmented:
            for seg_key in s["segments"]:
                if seg_key not in distinct:
                    distinct.append(seg_key)
        seg_txt = "、".join(str(k[1]) for k in distinct[:5])
        detail = ("跨位置一致性不做判定：%d 个取值分属 %d 个分段，非同一事实多值"
                  "（分段：%s）；分段列示不按矛盾计"
                  % (n_values, len(distinct), seg_txt))
        seg_evidence = []
        for s in segmented:
            for row, seg_key in zip(s["mismatch"]["rows"], s["segments"]):
                ev = _xop_evidence(row)
                ev["segment"] = seg_key[1] if seg_key else ""
                seg_evidence.append(ev)
        return _cross_state(
            "证据不足", detail,
            _cross_join_quotes([r for s in segmented for r in s["mismatch"]["rows"]],
                               limit=3),
            None, "cross_position_segmented", evidence=seg_evidence,
            segmented_groups=len(segmented), distinct_segments=len(distinct),
            compared_groups=compared)
    if compared:
        return _cross_state(
            "满足", "跨位置一致性通过：%d 组共 %d 处取值归一后一致"
            % (compared, sum(len(g) for g in groups.values())),
            _cross_join_quotes([r for g in groups.values() for r in g], limit=2),
            None, "cross_position_consistent", evidence=[], compared_groups=compared)
    detail = ("证据不足：可比较位置不足（需要 ≥%d 处同锚点取值），"
              "当前命中 %d 处" % (min_values, sum(len(g) for g in groups.values())))
    if insufficient:
        detail += "；已命中但不足 %d 处的组：%d 个" % (min_values, len(insufficient))
    return _cross_state("证据不足", detail,
                        _cross_join_quotes([r for g in groups.values() for r in g], limit=2),
                        None, "insufficient_values",
                        evidence=[] if not insufficient else
                        [_xop_evidence(r) for g in insufficient for r in g["rows"][:3]])


# ===========================================================================
# L44 consistency 文本执行器（编号/字符串跨位置一致性，2026-11-24）
#
# 背景（L32/L42 报告唯一残差）：injected consistency 0/46 —— 平台 ruleexec 只有
# 数值型 cross_position（:2625 _xop_scan 只扫数值+单位）与需规则侧给期望编号的
# _judge_code（:714），没有「字段锚点 → 抽编号/字符串值 → 跨位置比较」文本算子，
# 6/30 consistency 规则（分册索引 vs 登记索引）在平台上不可执行。
#
# 本段只做原文文本取数（不依赖 facts/tables），三态语义与既有算子一致：
#   两侧都有取值且归一后一致 → 满足；有不一致 → 不满足（引文=首个不一致行，逐字）；
#   任一侧缺失/无可比较位置 → 证据不足（不猜违规、不猜通过）；配置非法 → 执行失败。
#
# 支持的规则槽位形态（任一即可，优先级从上到下）：
#   1) slots.consistency / slots.consistency_text = {left,right}（或 {anchors:[..]}）；
#   2) 上述字典 + left_anchor/right_anchor、lhs/rhs、anchor_left/anchor_right 别名；
#   3) 顶层 left/right（或 *_anchor 别名）+ _template/type/category == consistency；
#   4) slots key/value 对（metric=左字段、value=右字段、unit ∈ 编号/版本/标准号/状态、
#      op 为相等/不等，且 value 非数值 —— 限值规则有数值 value 不会命中）；
#   5) anchors=[单个字段] + 一致性模板 → 同一字段多处取值必须一致。
# 支持 kind：code（默认，编号/单号）/ version（版本号，前导零归一）/ std（标准号）/
# status（中文/英文状态字段）。op == / !=（!= 时要求两侧不同才算满足）。
#
# 开关：RULEPROOF_CONSISTENCY_TEXT 默认 1；=0 时 _is_consistency_text_rule 恒 False，
# 回退旧路径（D4 数值取数为空 → 证据不足「未提取到指标数值」），逐字段与历史一致。
# 严格增量：只在该开关 + 显式一致性槽位形态下生效，不改 limit/数值/cross_position 行为。
# ===========================================================================
_CONSISTENCY_TEXT_ENV = "RULEPROOF_CONSISTENCY_TEXT"


def _consistency_text_enabled() -> bool:
    """RULEPROOF_CONSISTENCY_TEXT（默认 1；=0/false/off 回退旧路径）。"""
    raw = str(os.environ.get(_CONSISTENCY_TEXT_ENV, "1")).strip().lower()
    return raw not in ("0", "false", "off", "no", "disable", "disabled", "")


_CONS_CODE_UNITS = ("编号", "单号", "代码", "编码", "代号", "版本", "版本号",
                    "标准号", "文号", "批号", "证号", "序号", "工单号")
_CONS_KINDS = ("code", "version", "std", "status")
_CONS_OP_EQ = ("=", "==", "eq", "equal", "same", "一致", "相同", "相等", "等于")
_CONS_OP_NE = ("!=", "≠", "ne", "neq", "not_equal", "不一致", "不同", "不等")
_CONS_LEFT_KEYS = ("left", "left_anchor", "lhs", "lhs_anchor", "anchor_left",
                   "field_left", "label_left")
_CONS_RIGHT_KEYS = ("right", "right_anchor", "rhs", "rhs_anchor", "anchor_right",
                    "field_right", "label_right")
_CONS_EXPECTED_KEYS = ("expected", "expected_value", "want", "expect")
_PLACEHOLDER_CONS_VALUES = ("", "x", "X", "—", "-", "/", "空", "无", "待填", "n/a")


def _cons_first_str(cfg: dict, keys: tuple) -> str:
    for k in keys:
        v = (cfg or {}).get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _cons_norm_kind(kind: str, unit: str = "") -> str:
    k = str(kind or "").strip().lower()
    if k in _CONS_KINDS:
        return k
    u = str(unit or "")
    if "版本" in u or k in ("ver", "version_no"):
        return "version"
    if "标准" in u or k in ("standard", "gb"):
        return "std"
    if "状态" in u or k in ("state",):
        return "status"
    return "code"


def _cons_spec_from_mapping(cfg: dict, unit: str = "") -> dict | None:
    """consistency 字典 → 规范化 spec；非法/信息不足返回 None。"""
    cfg = dict(cfg or {})
    left = _cons_first_str(cfg, _CONS_LEFT_KEYS)
    right = _cons_first_str(cfg, _CONS_RIGHT_KEYS)
    expected = _cons_first_str(cfg, _CONS_EXPECTED_KEYS)
    anchors = [str(a).strip() for a in (cfg.get("anchors") or cfg.get("fields")
                                        or cfg.get("positions") or [])
               if isinstance(a, str) and str(a).strip()]
    kind = _cons_norm_kind(cfg.get("kind") or cfg.get("value_type") or unit, unit)
    op_raw = str(cfg.get("op") or cfg.get("operator") or "==").strip().lower()
    op = "ne" if op_raw in _CONS_OP_NE else "eq"
    form = ""
    if left and right:
        form = "pair"
    elif left and expected:
        form = "expected"
        right = expected
    elif len(anchors) >= 2:
        form = "multi"
        left, right = anchors[0], anchors[1]
    elif len(anchors) == 1 or (left and not right):
        form = "single"
        left = left or anchors[0]
    else:
        return None
    if not left:
        return None
    return {"form": form, "left": left, "right": right, "expected": expected,
            "anchors": anchors, "kind": kind, "op": op}


def _consistency_text_spec(slots) -> dict | None:
    """规则槽位 → consistency 文本算子 spec；非一致性规则返回 None。

    只认可显式一致性形态（见段首说明），且开关 =0 时恒 None（回退旧路径）。
    """
    if not isinstance(slots, dict) or not _consistency_text_enabled():
        return None
    # 跨文档一致性能力（project_compute/cross_doc）由项目级执行器负责，不在此接管。
    if slots.get("project_compute") or \
            str(slots.get("execution_mode") or "") == "cross_doc_consistency":
        return None
    unit = str(slots.get("unit") or "")
    # 1/2) 显式 consistency / consistency_text 字典
    for key in ("consistency_text", "consistency"):
        cfg = slots.get(key)
        if isinstance(cfg, dict):
            spec = _cons_spec_from_mapping(cfg, unit=unit)
            if spec:
                return spec
    marker = str(slots.get("_xop_kind") or slots.get("consistency_kind") or "").strip().lower()
    tpl = str(slots.get("_template") or slots.get("type") or slots.get("category")
              or slots.get("rule_type") or "").strip().lower()
    is_consistency_typed = (marker in ("consistency_text", "consistency")
                            or tpl in ("consistency",))
    # 3) 顶层 left/right（需一致性模板/标记，避免误伤其它槽位）
    if is_consistency_typed:
        top = _cons_spec_from_mapping(slots, unit=unit)
        if top and top["form"] in ("pair", "multi", "single"):
            return top
        anchors = [str(a).strip() for a in (slots.get("anchors") or [])
                   if isinstance(a, str) and str(a).strip()]
        if len(anchors) == 1:
            return {"form": "single", "left": anchors[0], "right": "",
                    "expected": "", "anchors": anchors,
                    "kind": _cons_norm_kind(slots.get("kind") or unit, unit), "op": "eq"}
        if len(anchors) >= 2:
            return {"form": "multi", "left": anchors[0], "right": anchors[1],
                    "expected": "", "anchors": anchors,
                    "kind": _cons_norm_kind(slots.get("kind") or unit, unit), "op": "eq"}
    # 4) slots key/value 对（L32 数据集形态：metric=分册索引、value=登记索引、unit=编号）
    metric = str(slots.get("metric") or "").strip()
    value = slots.get("value")
    if metric and isinstance(value, str) and value.strip():
        op_raw = str(slots.get("op") or slots.get("operator") or "==").strip().lower()
        if op_raw in _CONS_OP_EQ + _CONS_OP_NE and _num(value) is None \
                and (is_consistency_typed or unit in _CONS_CODE_UNITS):
            return {"form": "pair", "left": metric, "right": value.strip(),
                    "expected": "", "anchors": [], "kind": _cons_norm_kind(unit, unit),
                    "op": "ne" if op_raw in _CONS_OP_NE else "eq"}
    return None


def _is_consistency_text_rule(slots) -> bool:
    """是否走 consistency 文本执行器（judge_consistency_text）。"""
    try:
        return _consistency_text_spec(slots) is not None
    except Exception:  # 铁律 2：识别异常不改变历史行为（按非一致性处理），留痕
        logging.getLogger(__name__).warning("consistency text spec detect failed",
                                           exc_info=True)
        return False


# 取值连接词：冒号/等号/竖线，或「为/是/记作/…」，或至少一个空白；不接受零间隔。
_CONS_SEP_RE = re.compile(
    r"(?:[ \t]*[:：=＝|｜][ \t]*"
    r"|[ \t]*(?:为|是|记作|写作|填写|填列|载明|标注|显示|列示|注明|作)[ \t]*"
    r"|[ \t]+)")
# 编号/版本/标准号 token：字母数字起头，允许内部 -_/.# 与「标准号 12345-2020」式空格。
_CONS_VALUE_CODE_RE = re.compile(
    r"(?P<v>[A-Za-z0-9][A-Za-z0-9\-_/.#]{0,38}"
    r"(?:[ \t]+[0-9][A-Za-z0-9\-_/.#]{0,30})?)")
# 状态/中文取值 token：2–12 个中文（可含字母数字），到标点/空白止。
_CONS_VALUE_CJK_RE = re.compile(r"(?P<v>[\u4e00-\u9fff][\u4e00-\u9fffA-Za-z0-9]{1,11})")
_CONS_TRAIL_RE = re.compile(r"[\-_/.#]+$")


def _cons_clean_token(raw: str) -> str:
    s = str(raw or "").strip()
    s = _CONS_TRAIL_RE.sub("", s)
    s = s.strip("，,。；;：:、[]【】()（）\"'“”‘’ \t")
    return s


def _cons_anchor_spans(anchor: str, line: str) -> list:
    """锚点在一行内的出现区间列表（用于排除「标准号」嵌在「引用标准号」里的误匹配）。"""
    if not anchor or not line:
        return []
    return [(m.start(), m.end()) for m in re.finditer(re.escape(anchor), line)]


def _cons_extract(anchor: str, line: str, kind: str,
                  exclude_spans=()) -> list[dict]:
    """在一行内按锚点抽取值：返回 [{value, raw, quote, start}]。

    exclude_spans：另一侧锚点的出现区间；落在这里面的匹配是「锚点嵌套」（如右锚点
    「标准号」嵌在左锚点「引用标准号」内），不是独立字段，跳过。
    """
    out = []
    if not anchor or not line:
        return out
    for m in re.finditer(re.escape(anchor), line):
        if any(lo <= m.start() and m.end() <= hi for lo, hi in (exclude_spans or ())):
            continue
        sep = _CONS_SEP_RE.match(line, m.end())
        if not sep:
            continue
        vstart = sep.end()
        raw = ""
        if kind in ("code", "version", "std", "auto"):
            tm = _CONS_VALUE_CODE_RE.match(line, vstart)
            if tm:
                raw = tm.group("v")
        if not raw and kind in ("status", "auto"):
            cm = _CONS_VALUE_CJK_RE.match(line, vstart)
            if cm:
                raw = cm.group("v")
        val = _cons_clean_token(raw)
        if not val or val.lower() in _PLACEHOLDER_CONS_VALUES:
            continue
        out.append({"value": val, "raw": str(raw or ""), "anchor": anchor,
                    "quote": line.strip()[:240], "start": m.start()})
    return out


def _cons_norm_value(value: str, kind: str) -> str:
    """一致性归一：去空白/引号/全角，编号类大写 + 数字段前导零归一。"""
    s = unicodedata.normalize("NFKC", str(value or ""))
    s = re.sub(r"\s+", "", s)
    s = _CONS_TRAIL_RE.sub("", s).strip("，,。；;：:、[]【】()（）\"'“”‘’")
    if kind == "status":
        return s
    s = s.upper()

    def _dz(m):
        return str(int(m.group(0)))

    return re.sub(r"[0-9]+", _dz, s)

def _cons_value_evidence(v: dict) -> dict:
    return {"anchor": v.get("anchor") or "", "value": v.get("value") or "",
            "quote": v.get("quote") or "", "char_start": v.get("start")}


def _cons_mismatch(a: dict, b: dict, kind: str, op: str) -> bool:
    na, nb = _cons_norm_value(a["value"], kind), _cons_norm_value(b["value"], kind)
    if op == "ne":
        return na == nb
    return na != nb


def _cons_single_outlier(vals: list, kind: str):
    """form=single 的「异值」定位（L107 D4 修复）。

    按归一值计数取多数；异值 = 第一个与多数值不同的取值（即证据应指向的那一处）。
    全部取值互不相同/多数并列时：取「第一个与 vals[0] 不同的取值」（最早异值），标注 tie。
    只返回证据选择结果，不改 state/判定语义。返回 (outlier_dict|None, meta)。
    """
    norms = [_cons_norm_value(v["value"], kind) for v in vals]
    counts = {}
    for n in norms:
        counts[n] = counts.get(n, 0) + 1
    if len(counts) <= 1:
        return None, {}
    max_count = max(counts.values())
    majority = [n for n, c in counts.items() if c == max_count]
    if len(majority) == 1:
        maj = majority[0]
        idx = next(i for i, n in enumerate(norms) if n != maj)
        maj_display = next(v["value"] for v, n in zip(vals, norms) if n == maj)
        return vals[idx], {"majority": maj, "majority_display": maj_display,
                           "majority_count": max_count, "outlier_index": idx,
                           "tie": False, "n": len(vals)}
    first = norms[0]
    idx = next((i for i, n in enumerate(norms) if n != first), 0)
    return vals[idx], {"majority": "", "majority_display": "", "majority_count": max_count,
                       "outlier_index": idx, "tie": True, "n": len(vals)}


def _cons_state(state: str, detail: str, quote: str = "", code: str = "",
               **extra) -> dict:
    out = {"state": state, "detail": detail, "quote": quote or "",
           "value": None, "code": code or ""}
    out.update(extra)
    return out


def _consistency_text_decision(slots: dict, text: str) -> dict:
    """编号/字符串跨位置一致性判定（详见段首说明）。

    slots 形如 {consistency: {left/right/anchors/kind/op/expected}}（或 key/value 对）；
    text 为待判原文（已由 judge_rule 按 object 绑定过滤）。
    """
    spec = _consistency_text_spec(slots)
    if not spec:
        return _cons_state("执行失败",
                           "规则未声明可执行的字段锚点（left/right 或 anchors）",
                           "", "missing_anchor")
    body = str(text or "")
    if not body.strip():
        return _cons_state("证据不足", "无原文证据，无法做跨位置一致性比对",
                           "", "empty_text", source="consistency_text")
    form, kind = spec.get("form") or "pair", spec.get("kind") or "code"
    op = spec.get("op") or "eq"
    lines = body.splitlines()

    def _vals(anchor):
        got = []
        for ln in lines:
            got.extend(_cons_extract(anchor, ln, kind))
        return got

    if form == "single":
        vals = _vals(spec["left"])
        if len(vals) < 2:
            return _cons_state(
                "证据不足",
                "跨位置一致性需要「%s」至少 2 处取值，当前命中 %d 处"
                % (spec["left"], len(vals)), "", "insufficient_values",
                source="consistency_text", anchor=spec["left"],
                evidence=[_cons_value_evidence(v) for v in vals])
        norm = [_cons_norm_value(v["value"], kind) for v in vals]
        if len(set(norm)) > 1:
            # L107 D4：引文/证据指向「异值」而不是恒取第二处（旧 bad=vals[1] 在
            # [V0.8,V1.0,V1.0] 时指向一致行 V1.0 → 点位错）。=0 逐字回退旧行为。
            and_meta = {}
            if _cons_outlier_quote_fix_on():
                bad, and_meta = _cons_single_outlier(vals, kind)
            else:
                bad = vals[1]
            if bad is None:
                bad = vals[1]
            if and_meta.get("tie"):
                _detail = ("同一字段「%s」跨位置取值不一致：%s 与其余 %d 处不同"
                           "（共 %d 处，取值并列无多数）"
                           % (spec["left"], bad["value"], len(vals) - 1, len(vals)))
            elif and_meta:
                _detail = ("同一字段「%s」跨位置取值不一致：%s（异值）与多数值 %s"
                           "（%d/%d 处）"
                           % (spec["left"], bad["value"], and_meta.get("majority_display")
                              or "", and_meta.get("majority_count") or 0, len(vals)))
            else:
                _detail = ("同一字段「%s」跨位置取值不一致：%s 与 %s（共 %d 处）"
                           % (spec["left"], vals[0]["value"], bad["value"], len(vals)))
            _extra = {"source": "consistency_text", "anchor": spec["left"],
                      "values": [v["value"] for v in vals],
                      "evidence": [_cons_value_evidence(v) for v in vals[:6]]}
            if and_meta:
                _extra.update({"outlier_value": bad["value"],
                               "outlier_index": and_meta.get("outlier_index"),
                               "majority_value": and_meta.get("majority_display") or "",
                               "majority_count": and_meta.get("majority_count"),
                               "majority_tie": bool(and_meta.get("tie"))})
            return _cons_state("不满足", _detail, bad["quote"],
                               "consistency_text_mismatch", **_extra)
        return _cons_state(
            "满足", "同一字段「%s」跨位置取值一致：%s（%d 处）"
            % (spec["left"], vals[0]["value"], len(vals)), vals[0]["quote"],
            "consistency_text_consistent", source="consistency_text",
            anchor=spec["left"], values=[v["value"] for v in vals[:6]],
            evidence=[_cons_value_evidence(v) for v in vals[:6]])

    left_vals = _vals(spec["left"])
    right_vals = ([{"value": spec["right"], "raw": spec["right"], "anchor": "expected",
                    "quote": "", "start": 0}]
                  if form == "expected" else _vals(spec["right"]))
    if form == "expected":
        # expected 形态：左侧每一处取值都必须等于规则给出的期望常量。
        pairs = [(lv, right_vals[0]) for lv in left_vals]
        mism = [(a, b) for a, b in pairs if _cons_mismatch(a, b, kind, op)]
        if mism:
            a, b = mism[0]
            return _cons_state(
                "不满足",
                "「%s」取值 %s 与规则期望 %s 不一致（%d 处中 %d 处不符）"
                % (spec["left"], a["value"], b["value"], len(pairs), len(mism)),
                str(a.get("quote") or ""), "consistency_text_mismatch",
                source="consistency_text", op=op, kind=kind,
                values=[a["value"], b["value"]],
                evidence=[_cons_value_evidence(v) for v in left_vals[:8]],
                compared_pairs=len(pairs), mismatch_pairs=len(mism))
        a0 = left_vals[0]
        return _cons_state(
            "满足", "「%s」取值与规则期望 %s 一致（%d 处）"
            % (spec["left"], spec["right"], len(pairs)),
            str(a0.get("quote") or ""), "consistency_text_consistent",
            source="consistency_text", op=op, kind=kind,
            values=[a0["value"], spec["right"]], compared_pairs=len(pairs),
            evidence=[_cons_value_evidence(v) for v in left_vals[:8]])
    if not left_vals and not right_vals:
        return _cons_state(
            "证据不足",
            "两侧字段「%s」「%s」均未在原文取到取值（或仅占位符）"
            % (spec["left"], spec["right"]), "", "missing_both_sides",
            source="consistency_text")
    if not left_vals:
        return _cons_state(
            "证据不足", "缺少「%s」一侧的取值，无法比对（不猜不一致）" % spec["left"],
            (right_vals[0].get("quote") or "") if right_vals else "",
            "missing_left_side", source="consistency_text",
            evidence=[_cons_value_evidence(v) for v in right_vals[:3]])
    if not right_vals:
        return _cons_state(
            "证据不足", "缺少「%s」一侧的取值，无法比对（不猜不一致）" % spec["right"],
            left_vals[0].get("quote") or "", "missing_right_side",
            source="consistency_text",
            evidence=[_cons_value_evidence(v) for v in left_vals[:3]])

    # 逐行配对优先（同一记录行内两侧字段），跨行再回退到「取值集合」比对。
    pairs = []
    if len(left_vals) == 1 and len(right_vals) == 1:
        pairs = [(left_vals[0], right_vals[0])]
    else:
        for ln in lines:
            lsp = _cons_anchor_spans(spec["left"], ln)
            rsp = _cons_anchor_spans(spec["right"], ln)
            lv = _cons_extract(spec["left"], ln, kind, exclude_spans=rsp)
            rv = _cons_extract(spec["right"], ln, kind, exclude_spans=lsp)
            if not lv or not rv:
                continue
            for i in range(min(len(lv), len(rv))):
                pairs.append((lv[i], rv[i]))
    if not pairs:
        # 跨行：两侧取值集合一致 → 满足；否则取对称差中的一处作为冲突证据（不猜方向）。
        ln_set = {_cons_norm_value(v["value"], kind) for v in left_vals}
        rn_set = {_cons_norm_value(v["value"], kind) for v in right_vals}
        if ln_set == rn_set:
            return _cons_state(
                "满足",
                "跨位置一致性通过：「%s」与「%s」取值集合一致（左侧 %d 处、右侧 %d 处）"
                % (spec["left"], spec["right"], len(left_vals), len(right_vals)),
                left_vals[0]["quote"], "consistency_text_consistent",
                source="consistency_text",
                values=[v["value"] for v in left_vals[:6]],
                evidence=[_cons_value_evidence(v)
                          for v in (left_vals + right_vals)[:6]])
        extra_left = [v for v in left_vals
                      if _cons_norm_value(v["value"], kind) not in rn_set]
        extra_right = [v for v in right_vals
                       if _cons_norm_value(v["value"], kind) not in ln_set]
        if extra_left:
            pairs = [(extra_left[0], right_vals[0])]
        else:
            pairs = [(left_vals[0], extra_right[0])]
    mism = [(a, b) for a, b in pairs if _cons_mismatch(a, b, kind, op)]
    all_evidence = []
    for a, b in pairs:
        all_evidence.extend([_cons_value_evidence(a), _cons_value_evidence(b)])
    if mism:
        a, b = mism[0]
        quote = str(b.get("quote") or a.get("quote") or "")
        rel = "不一致" if op != "ne" else "相同（应不同）"
        return _cons_state(
            "不满足",
            "跨位置一致性不满足：「%s」=%s 与「%s」=%s %s（比对 %d 组，%d 组冲突）"
            % (spec["left"], a["value"], spec["right"], b["value"], rel,
               len(pairs), len(mism)),
            str(quote or ""), "consistency_text_mismatch",
            source="consistency_text", op=op, kind=kind,
            values=[a["value"], b["value"]],
            evidence=all_evidence[:8],
            compared_pairs=len(pairs), mismatch_pairs=len(mism))
    a0, b0 = pairs[0]
    return _cons_state(
        "满足",
        "跨位置一致性通过：「%s」=%s 与「%s」=%s 一致（比对 %d 组）"
        % (spec["left"], a0["value"], spec["right"], b0["value"], len(pairs)),
        str(a0.get("quote") or b0.get("quote") or ""), "consistency_text_consistent",
        source="consistency_text", op=op, kind=kind,
        values=[a0["value"], b0["value"]],
        evidence=all_evidence[:8], compared_pairs=len(pairs))


def judge_consistency_text(slots: dict, text: str) -> dict:
    """对外的 consistency 文本算子入口（manifest_exec/D4 与测试共用）。"""
    return _consistency_text_decision(slots, text)


def judge_sum_check(slots: dict, text: str) -> dict:
    """文本级合计算术：分项之和与合计比对（同单位基准，绝对/相对容差）。

    slots（或 slots.sum_check）支持：
      total_anchor  合计项的位置锚点（如 "合计"/"总计"/"涵洞"）；
      part_anchors  分项位置锚点列表（≥2；缺任一项 → 证据不足，不当作 0）；
      part_heads    发现模式分项头词（part_anchors 缺省时按标签包含匹配）；
      unit          统一基准单位（缺省用合计项单位）；
      tolerance     绝对容差（默认 0.01，按币种最小分的常见口径）；rel_tolerance 相对容差；
      window        分项相对合计的取数窗口（字符，默认 240）。
    """
    spec = _xop_spec(slots, "sum_check")
    total_anchor = str(spec.get("total_anchor") or "").strip()
    parts = [str(a).strip() for a in (spec.get("part_anchors") or []) if str(a or "").strip()]
    part_heads = [str(h).strip() for h in (spec.get("part_heads") or []) if str(h or "").strip()]
    structure = str(spec.get("structure") or "total_parts").strip().lower()
    if not total_anchor and structure != "qizhong":
        return _cross_state("执行失败", "合计算术缺少 total_anchor（合计项位置）", "", None,
                            "missing_total_anchor")
    _op0 = str(spec.get("op") or spec.get("operator") or "=").strip()
    if structure == "qizhong" and (parts or part_heads):
        return _cross_state("执行失败", "structure=qizhong 不能同时给 part_anchors/part_heads",
                            "", None, "conflicting_spec")
    if structure != "qizhong" and len(parts) < 2 and not part_heads \
            and _op0 in ("=", "==", "!="):
        # 求和等式至少 2 个分项；上下界/构成关系（分项不得大于合计）允许单分项
        return _cross_state("执行失败",
                            "合计算术（等式）至少需要 2 个分项 part_anchors（或 part_heads）；"
                            "上下界核对可用 op 并给 1 个分项", "", None, "missing_part_anchors")
    try:
        tolerance = float(spec.get("tolerance") if spec.get("tolerance") is not None else 0.01)
    except (TypeError, ValueError):
        tolerance = 0.01
    try:
        rel_tolerance = float(spec.get("rel_tolerance") or 0.0)
    except (TypeError, ValueError):
        rel_tolerance = 0.0
    try:
        window = max(0, int(spec.get("window") or 240))
    except (TypeError, ValueError):
        window = 240
    op = str(spec.get("op") or spec.get("operator") or "=").strip()
    if op not in ("=", "==", "<=", "≤", ">=", "≥", "<", ">", "!="):
        return _cross_state("执行失败", "合计算术不支持的比较符：%s" % op, "", None,
                            "bad_operator")
    part_scope = str(spec.get("part_scope") or "clause").strip().lower()
    exclude_units = {_cross_norm_unit(u) for u in (spec.get("exclude_units") or [])
                     if str(u or "").strip()}
    body = str(text or "")
    if not body.strip():
        return _cross_state("证据不足", "无原文证据，无法做合计算术核对", "", None, "empty_text")
    occs = _xop_scan(body)
    structure = str(spec.get("structure") or "total_parts").strip().lower()
    if structure == "qizhong":
        # 结构式：「合计项 n单位，其中 a、b、c（同单位分项）」——合计必须等于分项之和。
        # 不依赖任何具体条款词面（合计项/分项都从原文结构里取），是机制级通用形态。
        qz = []
        for m in re.finditer(r"其中", body):
            pos = m.start()
            totals = [o for o in occs if o["end"] <= pos and pos - o["end"] <= 6]
            if not totals:
                continue
            total = totals[-1]
            clause = total["clause"]
            parts = [o for o in occs
                     if o["start"] >= m.end() and o["clause"] is clause
                     and _cross_unit_key(_cross_norm_unit(o["unit"]))
                     == _cross_unit_key(_cross_norm_unit(total["unit"]))
                     and o["start"] != total["start"]]
            if not parts:
                continue
            if _cross_norm_unit(total["unit"]) in exclude_units:
                continue
            qz.append({"total": total, "parts": parts,
                       "sum": math.fsum(p["value"] for p in parts)})
        if not qz:
            return _cross_state("证据不足", "未找到「合计项，其中分项…」结构（不足 2 个同单位分项）",
                                "", None, "missing_structure")
        bad, ev_all = [], []
        for cand in qz:
            total, part_sum = cand["total"], cand["sum"]
            tol = max(abs(tolerance), abs(total["value"]) * abs(rel_tolerance))
            ev = [_xop_evidence(total)] + [_xop_evidence(p) for p in cand["parts"]]
            if len(cand["parts"]) == 1:
                # 单分项「其中」结构：语义是「合计的构成之一」，只能校验「分项不大于合计」
                violated = part_sum - total["value"] > tol
            else:
                violated = abs(part_sum - total["value"]) > tol
            if violated:
                bad.append({"cand": cand, "diff": part_sum - total["value"],
                            "tol": tol, "evidence": ev})
            ev_all.extend(ev)
        if bad:
            first = bad[0]
            total = first["cand"]["total"]
            detail = ("合计结构不一致：合计项「%s」=%s%s；其中 %d 个分项合计=%s%s；"
                      "相差 %s%s（容差 %s%s）"
                      % (total["label"], _cross_fmt(total["value"]), total["unit"],
                         len(first["cand"]["parts"]), _cross_fmt(first["cand"]["sum"]),
                         total["unit"], _cross_fmt(abs(first["diff"])), total["unit"],
                         _cross_fmt(first["tol"]), total["unit"]))
            return _cross_state("不满足", detail,
                                _cross_join_quotes([total] + first["cand"]["parts"], limit=4),
                                first["cand"]["sum"], "sum_mismatch",
                                total_value=total["value"],
                                part_sum=first["cand"]["sum"], diff=first["diff"],
                                tolerance=first["tol"], unit=total["unit"],
                                evidence=first["evidence"])
        first = qz[0]
        return _cross_state(
            "满足", "合计结构一致：%d 组（合计项「%s」=%s%s = 分项合计）"
            % (len(qz), first["total"]["label"], _cross_fmt(first["total"]["value"]),
               first["total"]["unit"]),
            _cross_join_quotes([first["total"]] + first["parts"], limit=3),
            first["sum"], "sum_ok",
            total_value=first["total"]["value"], part_sum=first["sum"],
            unit=first["total"]["unit"], evidence=ev_all[:6])
    total_anchor_n = _xop_norm_label(total_anchor, width=40)
    totals = [o for o in occs if total_anchor_n and total_anchor_n in o["label"]]
    if not totals:
        return _cross_state("证据不足", "未找到合计项「%s」的取值" % total_anchor,
                            "", None, "missing_total")
    total = totals[0]
    base_unit = str(spec.get("unit") or total["unit"])
    total_base = _xop_unit_convert(total["value"], total["unit"], base_unit)
    if total_base is None:
        return _cross_state("证据不足", "合计项单位无法换算：%s → %s"
                            % (total["unit"], base_unit), total["quote"], None,
                            "unit_mismatch")
    found, missing, evidence = [], [], []
    if parts:
        for anchor in parts:
            an = _xop_norm_label(anchor, width=40)
            cands = [o for o in occs
                     if an and (an in o["label_full"] or an in o["label"])
                     and o["start"] != total["start"]]
            if not cands:
                missing.append(anchor)
                continue
            cands.sort(key=lambda o: (abs(o["start"] - total["end"]), o["start"]))
            pick = cands[0]
            if window and abs(pick["start"] - total["end"]) > window:
                missing.append(anchor)
                continue
            got = _xop_unit_convert(pick["value"], pick["unit"], base_unit)
            if got is None:
                return _cross_state("证据不足", "分项「%s」单位无法换算：%s → %s"
                                    % (anchor, pick["unit"], base_unit), pick["quote"], None,
                                    "unit_mismatch")
            found.append({"anchor": anchor, "value": got, "occurrence": pick})
            evidence.append(_xop_evidence(pick))
    else:
        # 发现模式：合计项之后同一取数窗口内、同单位的数值即为分项（标签含 part_heads）。
        heads_n = [_xop_norm_label(h, width=40) for h in part_heads]
        heads_n = [h for h in heads_n if h]
        for occ in occs:
            if occ["start"] <= total["end"]:
                continue
            if part_scope == "clause" and occ["clause"] is not total["clause"]:
                continue
            if window and occ["start"] - total["end"] > window:
                break
            if _cross_unit_key(_cross_norm_unit(occ["unit"])) != \
                    _cross_unit_key(_cross_norm_unit(total["unit"])):
                continue
            if heads_n and not any(h in occ["label_full"] or h in occ["label"]
                                   for h in heads_n):
                continue
            got = _xop_unit_convert(occ["value"], occ["unit"], base_unit)
            if got is None:
                continue
            found.append({"anchor": occ["label"], "value": got, "occurrence": occ})
            evidence.append(_xop_evidence(occ))
    default_min = 2 if op in ("=", "==", "!=") else 1
    min_parts = max(default_min, int(spec.get("min_parts") or default_min))
    if missing or len(found) < min_parts:
        return _cross_state(
            "证据不足",
            "合计算术缺项（%d 个分项未取到：%s），不按 0 继续求和"
            % (len(missing), "、".join(missing[:4]) or "分项不足 %d 项" % min_parts),
            total["quote"], None, "missing_parts",
            evidence=[_xop_evidence(total)] + evidence)
    part_sum = math.fsum(x["value"] for x in found)
    tol = max(abs(tolerance), abs(total_base) * abs(rel_tolerance))
    diff = part_sum - total_base
    ev = [_xop_evidence(total)] + evidence
    op_txt = {"=": "等于", "==": "等于", "<=": "不超过", "≤": "不超过",
              ">=": "不少于", "≥": "不少于", "<": "小于", ">": "大于",
              "!=": "不等于"}.get(op, op)
    detail_base = ("合计项「%s」=%s%s；分项 %d 项合计=%s%s（%s）；要求合计%s合计项"
                   % (total_anchor, _cross_fmt(total_base), base_unit,
                      len(found), _cross_fmt(part_sum), base_unit,
                      "、".join("%s=%s" % (x["anchor"], _cross_fmt(x["value"]))
                               for x in found), op_txt))
    if op in ("=", "=="):
        ok = abs(diff) <= tol
    elif op in ("<=", "≤"):
        ok = part_sum <= total_base + tol
    elif op in (">=", "≥"):
        ok = part_sum + tol >= total_base
    elif op == "<":
        ok = part_sum < total_base
    elif op == ">":
        ok = part_sum > total_base
    else:
        ok = abs(diff) > tol
    if not ok:
        return _cross_state(
            "不满足",
            detail_base + "；与合计相差 %s%s（容差 %s%s）"
            % (_cross_fmt(abs(diff)), base_unit, _cross_fmt(tol), base_unit),
            _cross_join_quotes([total] + [x["occurrence"] for x in found], limit=4),
            part_sum, "sum_mismatch",
            total_value=total_base, part_sum=part_sum, diff=diff,
            tolerance=tol, unit=base_unit, evidence=ev)
    return _cross_state(
        "满足", detail_base + "；在容差 %s%s 内满足" % (_cross_fmt(tol), base_unit),
        total["quote"], part_sum, "sum_ok",
        total_value=total_base, part_sum=part_sum, diff=diff,
        tolerance=tol, unit=base_unit, evidence=ev)


# ---------------------------------------------------------------------------
# ALTER 类型算子 + 跨角色关系算子（P0-5 D2 修复第 3 项）
#
# 背景：D2 修复第 2 项的 21 个算子机制组只有 3 个（14.3%）有判别力，根因已测：
#   cross_position 依赖「同一限值在单文档内出现 ≥2 次」，干净态常常证据不足；
#   alter_value 45 / alter_date 14 两类执行器缺口完全没有承接；
#   且没有任何算子处理「分项 vs 合计」「数量×单机容量 vs 总容量」「比例构成 vs 100%」
#   「获取/登记截止 vs 递交截止」「R 取值 vs 上下分项之和」这类**跨角色**关系。
#
# 本段新增两类文本级算子，语义与既有算子一致（五态 + 证据回链原文 locator/quote）：
#
# 1 alter_detect（ALTER 类型）
#    输入：anchors（应有值所在位置/上下文，≤8）+ expected（应有值，≥1）+ expected_source
#          （应为值来源）+ mode（value/date/unit）+ 容差。
#    **铁律**：expected_source 必须是**外部来源**（spec/contract/list/clean_consensus/
#    unit_lexicon）；同一文档自证（same_document/self/instance…）或空来源一律「执行失败」，
#    杜绝「用被测文档自己的另一处值当应有值」的自我循环。
#    行为：锚点处抽实际值 → 同量纲归一 → 与应有值比对 → 超容差「不满足」（引文+locator+diff）；
#          锚点未命中/单位不可换算 →「证据不足」；配置非法 →「执行失败」。
#
# 2 cross_role_limit（跨角色关系）
#    与 cross_position 的本质区别：它比的是**两个不同语义角色**（分项 vs 合计、
#    数量×单机容量 vs 总容量、比例构成 vs 100%、获取截止 vs 递交截止），
#    因此在正确态文本上**同样可判**（不需要同一事实重复出现）——这是本项能不能拿到
#    判别力的关键结构缺口。
#    模式：
#      part_le_total      每个分项 ≤ 合计（其中 X 类构成）
#      sum_le_total       Σ分项 ≤ 合计（入围家数 vs R 取值）
#      sum_eq_total       Σ分项 = 合计（桥梁 9=4+4+1、涵洞 149=54+95、己二腈+己二胺=尼龙66）
#      sum_ratio_eq       比例构成 Σ = 100%（出资比例）
#      product_eq_total   数量 × 单机容量 = 总容量（8台×6250kW=50MW）
#      product_le_total   数量 × 单机容量 ≤ 总容量
#      date_le / date_lt  日期链：前序角色（获取/登记截止）不得晚于后序（递交截止）
#      date_gap_ge        前序起点 → 后序截止的间隔 ≥ N 日（"不少于30日"自述口径）
# ---------------------------------------------------------------------------
_ADE_DATE_RE = re.compile(
    r"(?P<y>20\d{2})\s*[-/年.]\s*(?P<mo>\d{1,2})\s*[-/月.]\s*(?P<d>\d{1,2})\s*[日号]?"
    r"(?:\s*(?P<h>\d{1,2})\s*[时:：]\s*(?P<mi>\d{1,2})?\s*分?)?")
# 应有值来源白名单（外部来源）；其余一律拒绝执行（防同一文档自证）
_ADE_EXTERNAL_SOURCES = ("spec", "contract", "list", "clean_consensus",
                         "clean_instance", "unit_lexicon")
_ADE_SELF_SOURCES = ("same_document", "same_doc", "self", "instance", "instance_text",
                     "same_file", "document", "doc", "同一文档", "本文档")
# 跨角色关系：角色词表只做**定位**（不含任何具体数值/条款），接地由簇内文档验证
_CRL_COUNT_UNITS = ("台", "套", "个", "名", "人", "份", "次", "条", "处", "座", "张",
                    "页", "项", "家", "组", "批", "道", "只", "层", "排", "孔", "根")
_CRL_POWER_SCALE = {"W": 1.0, "瓦": 1.0, "kW": 1e3, "千瓦": 1e3, "MW": 1e6, "兆瓦": 1e6,
                    "GW": 1e9, "万千瓦": 1e7, "万kW": 1e7,
                    # 光伏组件的「峰值功率」单位（Wp/kWp/MWp）与 W 同量纲：不注册会把
                    # 「每单块容量 580Wp」当成未知单位 → 乘积核对恒证据不足（第 4 项实测）。
                    "Wp": 1.0, "kWp": 1e3, "MWp": 1e6, "GWp": 1e9, "万kWp": 1e7}
_CRL_ENERGY_SCALE = {"kWh": 1e3, "度": 1e3, "MWh": 1e6, "GWh": 1e9, "万kWh": 1e7,
                     "亿kWh": 1e11}
_CRL_AREA_SCALE = {"平方米": 1.0, "平米": 1.0, "㎡": 1.0, "m2": 1.0, "平方分米": 0.01,
                   "平方公里": 1e6, "公顷": 1e4, "亩": 666.6667}
_CRL_LEN_SCALE = {"毫米": 0.001, "厘米": 0.01, "米": 1.0, "m": 1.0, "千米": 1000.0,
                  "公里": 1000.0, "km": 1000.0}
_CRL_MASS_SCALE = {"吨": 1.0, "万吨": 1e4, "公斤": 0.001, "千克": 0.001, "kg": 0.001,
                   "克": 1e-6, "mg": 1e-9}
_CRL_MONEY_SCALE = {"元": 1.0, "万元": 1e4, "亿元": 1e8, "千元": 1e3, "百万元": 1e6}
# 时间口径：日历天/个工作日/自然日必须是**独立单位**（不能退化成「个」/「天」），
# 否则「计划工期：150个工作日」会被抽成单位「个」，单位一致性算子永远判错。
_CRL_TIME_SCALE = {"日历天": 1.0, "个工作日": 1.0, "工作日": 1.0, "自然日": 1.0,
                   "天": 1.0, "日": 1.0, "个月": 1.0, "年": 1.0}
_CRL_ALL_UNITS = tuple(sorted(set(
    list(_CRL_COUNT_UNITS) + list(_CRL_POWER_SCALE) + list(_CRL_ENERGY_SCALE)
    + list(_CRL_AREA_SCALE) + list(_CRL_LEN_SCALE) + list(_CRL_MASS_SCALE)
    + list(_CRL_MONEY_SCALE) + list(_CRL_TIME_SCALE)
    + ["%", "％", "‰", "万吨/年", "吨/年", "万m³", "立方米"]),
    key=len, reverse=True))
_CRL_UNIT_ALT = "|".join(re.escape(u) for u in _CRL_ALL_UNITS)
_CRL_NUM = r"[-−－]?(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)"
_CRL_OCC_RE = re.compile(r"(?P<num>" + _CRL_NUM + r")\s*(?P<unit>" + _CRL_UNIT_ALT + r")?")
_CRL_CLAUSE_RE = re.compile(r"[^。；;\n\r！？!?]+")
_CRL_LABEL_SPLIT = re.compile(r"[，,、:：（）()\[\]【】|｜。；;\s]")


def _crl_unit_dim(unit: str):
    """单位 → (量纲, 到基准倍率)；未知单位返回 None（不猜）。计数单位倍率 1。"""
    u = str(unit or "").strip()
    if not u:
        return ("count", 1.0)
    if u in ("%", "％"):
        return ("percent", 1.0)
    if u == "‰":
        return ("percent", 0.1)
    for table, dim in ((_CRL_MONEY_SCALE, "money"), (_CRL_POWER_SCALE, "power"),
                       (_CRL_ENERGY_SCALE, "energy"), (_CRL_AREA_SCALE, "area"),
                       (_CRL_LEN_SCALE, "length"), (_CRL_MASS_SCALE, "mass")):
        if u in table:
            return (dim, table[u])
    if u in _CRL_TIME_SCALE:
        return ("time", 1.0)
    if u in _CRL_COUNT_UNITS:
        return ("count", 1.0)
    if u in ("万吨/年", "吨/年"):
        return ("mass_rate", 1e4 if u.startswith("万") else 1.0)
    return None


def _crl_scan(text: str) -> list:
    """原文 → 数值出现集（值 + 单位 + 归一标签 + 段号/偏移 + 逐字引文）。

    与 _xop_scan 的差异：单位可缺省（"8台" 有单位，"8" 单独出现也算计数），
    并覆盖功率/能量/面积/金额/比例等量纲；标签取数字前文最后一段。
    """
    text = str(text or "")
    out = []
    for cm in _CRL_CLAUSE_RE.finditer(text):
        seg, seg_start = cm.group(0), cm.start()
        for m in _CRL_OCC_RE.finditer(seg):
            raw = m.group("num")
            unit = (m.group("unit") or "").strip()
            value = _num(str(raw).replace(",", ""))
            if value is None:
                continue
            pre = seg[:m.start()]
            parts = [x for x in _CRL_LABEL_SPLIT.split(pre) if x.strip()]
            label_raw = (parts[-1] if parts else pre)[-24:]
            start = seg_start + m.start()
            para = text.count("\n", 0, start) + 1
            dim = _crl_unit_dim(unit)
            out.append({
                "value": float(value), "raw": str(raw), "unit": unit,
                "dim": dim[0] if dim else "", "scale": dim[1] if dim else None,
                "label": _xop_norm_label(label_raw, width=20),
                "label_full": _xop_norm_label(label_raw, width=40, strip_tail=False),
                "label_raw": label_raw.strip(),
                "start": start, "end": seg_start + m.end(), "para": para,
                "locator": "第%d段@@%d" % (para, start),
                "quote": (label_raw[-12:] + seg[m.start():m.end()]).strip()[:120],
                "clause": seg,
            })
    return out


def _crl_base(occ: dict):
    """出现 → 基准量（按 dim 归一）；未知单位返回 None。"""
    if occ.get("dim") in ("", None) and not occ.get("unit"):
        return (1.0, "count")
    scale = occ.get("scale")
    if scale is None or not occ.get("dim"):
        return None
    return (float(occ["value"]) * float(scale), occ["dim"])


def _crl_unit_scale(occ: dict):
    """出现 → 该单位到基准的倍率（用于把基准量换回原单位显示）；未知返回 None。"""
    base = _crl_base(occ)
    if base is None or not occ.get("value"):
        return None
    try:
        return base[0] / float(occ["value"])
    except (TypeError, ValueError):
        return None


_CRL_MONTH_RE = re.compile(r"(?P<y>20\d{2})\s*[-/年.]\s*(?P<mo>\d{1,2})\s*月")
_CRL_CN_DIGIT = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7,
                 "八": 8, "九": 9, "十": 10}


def _crl_cn2int(raw):
    """中文/阿拉伯数字 → int（1..99 的常见写法；解析失败返回 None）。"""
    s = str(raw or "").strip()
    if not s:
        return None
    if s.isdigit():
        return int(s)
    if s in _CRL_CN_DIGIT:
        return _CRL_CN_DIGIT[s]
    if len(s) == 2 and s[0] == "十" and s[1] in _CRL_CN_DIGIT:
        return 10 + _CRL_CN_DIGIT[s[1]]
    if len(s) == 2 and s[1] == "十" and s[0] in _CRL_CN_DIGIT:
        return _CRL_CN_DIGIT[s[0]] * 10
    if len(s) == 3 and s[1] == "十" and s[0] in _CRL_CN_DIGIT \
            and s[2] in _CRL_CN_DIGIT:
        return _CRL_CN_DIGIT[s[0]] * 10 + _CRL_CN_DIGIT[s[2]]
    return None


def _crl_scan_months(text: str) -> list:
    """月份精度出现集（"2025年9月" → 2025-09-01；用于区间终点核对）。"""
    text = str(text or "")
    out = []
    for m in _CRL_MONTH_RE.finditer(text):
        y, mo = int(m.group("y")), int(m.group("mo"))
        if not 1 <= mo <= 12:
            continue
        start = m.start()
        para = text.count("\n", 0, start) + 1
        out.append({"date": _dt.date(y, mo, 1), "pos": start, "end": m.end(),
                    "txt": m.group(0), "para": para,
                    "locator": "第%d段@@%d" % (para, start),
                    "quote": text[max(0, start - 18):m.end()].strip()[:120]})
    return out


def _is_alter_detect_rule(slots) -> bool:
    if not isinstance(slots, dict):
        return False
    if str(slots.get("_xop_kind") or "") == "alter_detect":
        return True
    if str(slots.get("_template") or "") == "alter_detect":
        return True
    return isinstance(slots.get("alter_detect"), dict)


def _is_cross_role_limit_rule(slots) -> bool:
    if not isinstance(slots, dict):
        return False
    if str(slots.get("_xop_kind") or "") == "cross_role_limit":
        return True
    if str(slots.get("_template") or "") == "cross_role_limit":
        return True
    return isinstance(slots.get("cross_role_limit"), dict)


# 新算子槽位键：_xop_spec() 的键表是第 2 项写死的白名单，新键在这里补齐，
# 否则平铺层配置读不到（会静默忽略 → 把配置非法误判成证据不足）。
_XOP3_KEYS = ("anchors", "expected", "expected_source", "mode", "min_hits",
              "conflict_units",
              "lhs_anchors", "lhs_heads", "rhs_anchor", "total_ratio", "lhs_scope",
              "min_days", "label_width", "window", "tolerance", "rel_tolerance", "unit")


def _xop3_spec(slots: dict, key: str) -> dict:
    spec = dict((slots or {}).get(key) or {}) if isinstance(
        (slots or {}).get(key), dict) else {}
    try:
        flat = _xop_spec(slots, key)
    except Exception:            # noqa: BLE001  槽位异常不能静默：交给调用方判执行失败
        flat = {}
    for k in _XOP3_KEYS:
        if k not in spec:
            if k in flat:
                spec[k] = flat[k]
            elif isinstance(slots, dict) and k in slots:
                spec[k] = slots[k]
    for k, v in flat.items():
        spec.setdefault(k, v)
    return spec


# L39 ⑧：日期扫描补充「紧凑 20YYYYMMDD」与「仅精确到月 YYYY年M月」两种真实写法。
# 只在 date 链分支显式 extended=True 时启用（其它调用点保持历史口径，避免误识别编号）。
_ADE_COMPACT_DATE_RE = re.compile(r"(?<![\d])(?P<y>20\d{2})(?P<mo>\d{2})(?P<d>\d{2})(?![\d])")
_ADE_MONTH_RE = re.compile(r"(?<![\d])(?P<y>20\d{2})\s*年\s*(?P<mo>\d{1,2})\s*月(?!\s*\d)")


def _ade_scan_dates(text: str, extended: bool = False) -> list:
    """原文 → 日期/时刻出现集（按出现顺序；locator + 逐字引文）。

    L39 ⑧：修复开启时先做全角/紧凑归一（NFKC 数字，1:1 不移动下标）；
    ``extended=True`` 时再识别紧凑 8 位日期与「YYYY年M月」月精度日期
    （``precision="month"``，严格先后比较时同月视为无法确认）。
    """
    raw = str(text or "")
    text = raw
    if _fix2_on("date_nfkc"):
        text = _tools.canonical_numeric_text(text)
    # L42 ③：canonical_numeric_text 是逐字符 1:1 映射，归一文本下标可直接回查原文；
    # 引文切片必须来自**原文字符**（否则全角标点被归一后引文非逐字，证据门禁会降级）。
    _quote_src = raw if (_fix3_on("date_det") and len(raw) == len(text)) else text
    out = []
    for m in _ADE_DATE_RE.finditer(text):
        try:
            d = _dt.date(int(m.group("y")), int(m.group("mo")), int(m.group("d")))
        except (ValueError, TypeError):
            continue
        hh = int(m.group("h")) if m.group("h") else 0
        mi = int(m.group("mi")) if m.group("mi") else 0
        if not (0 <= hh <= 23 and 0 <= mi <= 59):
            hh, mi = 0, 0
        start = m.start()
        para = text.count("\n", 0, start) + 1
        out.append({
            "date": d, "hh": hh, "mi": mi, "pos": start, "end": m.end(),
            "txt": m.group(0), "para": para, "precision": "day",
            "key": (d.year, d.month, d.day, hh, mi),
            "locator": "第%d段@@%d" % (para, start),
            "quote": _quote_src[max(0, start - 18):m.end()].strip()[:120],
        })
    if extended and _fix2_on("date_ext_scan") and _fix2_on("date_nfkc"):
        taken = [(d["pos"], d["end"]) for d in out]

        def _overlap(a, b):
            return any(not (b <= x or a >= y) for x, y in taken)

        for m in _ADE_COMPACT_DATE_RE.finditer(text):
            if _overlap(m.start(), m.end()):
                continue
            try:
                d = _dt.date(int(m.group("y")), int(m.group("mo")), int(m.group("d")))
            except (ValueError, TypeError):
                continue
            start = m.start()
            para = text.count("\n", 0, start) + 1
            out.append({
                "date": d, "hh": 0, "mi": 0, "pos": start, "end": m.end(),
                "txt": m.group(0), "para": para, "precision": "day",
                "key": (d.year, d.month, d.day, 0, 0),
                "locator": "第%d段@@%d" % (para, start),
                "quote": _quote_src[max(0, start - 18):m.end()].strip()[:120],
            })
        for m in _ADE_MONTH_RE.finditer(text):
            if _overlap(m.start(), m.end()):
                continue
            try:
                d = _dt.date(int(m.group("y")), int(m.group("mo")), 1)
            except (ValueError, TypeError):
                continue
            start = m.start()
            para = text.count("\n", 0, start) + 1
            out.append({
                "date": d, "hh": 0, "mi": 0, "pos": start, "end": m.end(),
                "txt": m.group(0), "para": para, "precision": "month",
                "key": (d.year, d.month, d.day, 0, 0),
                "locator": "第%d段@@%d" % (para, start),
                "quote": _quote_src[max(0, start - 18):m.end()].strip()[:120],
            })
    out.sort(key=lambda x: x["pos"])
    return out


def _ade_norm_expected(raw) -> list:
    """应有值文本 → 结构化候选（date / value+unit / unit 词）。只做写法归一。"""
    out = []
    items = raw if isinstance(raw, (list, tuple)) else [raw]
    for item in items:
        s = str(item or "").strip()
        if not s:
            continue
        ds = _ade_scan_dates(s)
        if ds:
            # has_time：应有值文本里是否显式给了时刻；只有日期时按"同一天"比较，
            # 不能用 00:00 去要求原文也必须 00:00（会把合法的「2025年4月22日9时」判错）。
            has_time = bool(re.search(r"\d{1,2}\s*[时:：]", s))
            out.append({"kind": "date", "date": ds[0]["date"], "hh": ds[0]["hh"],
                        "mi": ds[0]["mi"], "has_time": has_time, "text": s})
            continue
        occs = _crl_scan(s)
        occs = [o for o in occs if o["unit"] or o["value"] is not None]
        if occs:
            out.append({"kind": "value", "num": occs[0]["value"],
                        "unit": occs[0]["unit"], "text": s})
            continue
        out.append({"kind": "unit", "unit": _cross_norm_unit(s), "text": s})
    return out


def _ade_collect(spec: dict, text: str, mode: str) -> tuple:
    """按 anchors 抽实际值（mode=value/unit 用数值扫描，mode=date 用日期扫描）。"""
    anchors = [str(a).strip() for a in (spec.get("anchors") or [])
               if str(a or "").strip()]
    try:
        window = max(0, int(spec.get("window") or 80))
    except (TypeError, ValueError):
        window = 80
    hits, evidence = [], []
    if mode == "date":
        dates = _ade_scan_dates(text)
        for anchor in anchors:
            for m in re.finditer(re.escape(anchor), text):
                cand = [d for d in dates
                        if m.end() <= d["pos"] <= m.end() + max(window, 40)]
                if not cand:
                    continue
                found = cand[-1]         # 「获取时间：起 至 止」→ 截止取最后一个日期
                hits.append({"anchor": anchor, "date": found["date"],
                             "key": found["key"], "occ": found})
                evidence.append({"locator": found["locator"], "quote": found["quote"],
                                 "anchor": anchor, "date": found["date"].isoformat(),
                                 "time": "%02d:%02d" % (found["hh"], found["mi"]),
                                 "raw": found["txt"]})
                break
        return hits, evidence
    occs = _crl_scan(text)
    for anchor in anchors:
        an = _xop_norm_label(anchor, width=40)
        if not an:
            continue
        cand = None
        for m in re.finditer(re.escape(anchor), text):
            near = [o for o in occs if m.end() <= o["start"] <= m.end() + max(window, 24)]
            if near:
                cand = near[0]
                break
        if cand is None:
            back = [o for o in occs
                    if an in o["label"] or an in o["label_full"] or an in o["label_raw"]]
            cand = back[0] if back else None
        if cand is None:
            continue
        hits.append({"anchor": anchor, "value": cand["value"], "unit": cand["unit"],
                     "occ": cand})
        ev = {"locator": cand["locator"], "quote": cand["quote"], "raw": cand["raw"],
              "unit": cand["unit"], "value": cand["value"], "label": cand["label"],
              "anchor": anchor}
        evidence.append(ev)
    return hits, evidence


def judge_alter_detect(slots: dict, text: str) -> dict:
    """ALTER 类型算子：抽实际值 → 与**外部应有值**比对 → 超容差「不满足」。

    slots（或 slots.alter_detect）：
      anchors          应有值出现位置/上下文（≤8，必填）
      expected         应有值（≥1，必填；"150日历天" / "2025-04-22" / "日历天"）
      expected_source  应有值来源（spec/contract/list/clean_consensus/clean_instance/
                       unit_lexicon）；**禁止**同一文档自证 → 执行失败
      mode             value（默认）| date | unit
      unit / tolerance / rel_tolerance / window / min_hits
    """
    spec = _xop3_spec(slots, "alter_detect")
    anchors = [str(a).strip() for a in (spec.get("anchors") or [])
               if str(a or "").strip()]
    expected_raw = spec.get("expected")
    if isinstance(expected_raw, str):
        expected_raw = [expected_raw]
    expected_raw = [str(x).strip() for x in (expected_raw or []) if str(x or "").strip()]
    src = str(spec.get("expected_source") or "").strip().lower()
    if not anchors:
        return _cross_state("执行失败", "alter_detect 缺少 anchors（应有值所在位置）", "",
                            None, "missing_anchors")
    if not expected_raw:
        return _cross_state("执行失败", "alter_detect 缺少 expected（外部应有值）", "",
                            None, "missing_expected")
    if src in _ADE_SELF_SOURCES or not src:
        return _cross_state(
            "执行失败",
            "alter_detect.expected_source 非法（%r）：应有值必须来自规格/合同/清单/多文档"
            "共识/单位词表等外部来源，禁止用同一文档自证（自我循环）" % (src or "空"),
            "", None, "self_certified_expected")
    if src not in _ADE_EXTERNAL_SOURCES:
        return _cross_state("执行失败", "alter_detect.expected_source 非法取值：%r" % src,
                            "", None, "bad_expected_source")
    exp = _ade_norm_expected(expected_raw)
    if not exp:
        return _cross_state("执行失败", "alter_detect.expected 无法解析为可比值", "", None,
                            "bad_expected")
    mode = str(spec.get("mode") or "").strip().lower()
    if not mode:
        kinds = {e["kind"] for e in exp}
        mode = "date" if kinds == {"date"} else ("unit" if kinds == {"unit"} else "value")
    if mode not in ("value", "date", "unit"):
        return _cross_state("执行失败", "alter_detect 不支持的 mode：%s" % mode, "", None,
                            "bad_mode")
    try:
        tolerance = float(spec.get("tolerance") if spec.get("tolerance") is not None else 0.0)
    except (TypeError, ValueError):
        tolerance = 0.0
    try:
        rel_tolerance = float(spec.get("rel_tolerance") or 0.0)
    except (TypeError, ValueError):
        rel_tolerance = 0.0
    try:
        min_hits = max(1, int(spec.get("min_hits") or 1))
    except (TypeError, ValueError):
        min_hits = 1
    body = str(text or "")
    if not body.strip():
        return _cross_state("证据不足", "无原文证据，无法做应有值比对", "", None, "empty_text")
    base_unit = str(spec.get("unit") or "")
    hits, evidence = _ade_collect(spec, body, mode)
    if len(hits) < min_hits:
        return _cross_state(
            "证据不足",
            "alter_detect 证据不足：锚点（%s）命中 %d 处 < 需要 %d 处"
            % ("、".join(anchors[:4]), len(hits), min_hits),
            _cross_join_quotes([h["occ"] for h in hits], limit=2), None,
            "insufficient_hits", evidence=evidence)
    expect_txt = "、".join(expected_raw)
    mismatches = []
    for h in hits:
        if mode == "date":
            exp_dates = [e for e in exp if e["kind"] == "date"]
            if not exp_dates:
                return _cross_state("证据不足", "mode=date 但 expected 不是日期", "", None,
                                    "mode_expected_mismatch")
            tol_minutes = int(max(0.0, tolerance) * 24 * 60)
            ok = False
            for e in exp_dates:
                want_date = (e["date"].year, e["date"].month, e["date"].day)
                got = h["key"]
                if not e.get("has_time"):
                    # 应有值只有日期 → 比到日粒度（时刻不参与）
                    if got[:3] == want_date:
                        ok = True
                        break
                    continue
                want = want_date + (e["hh"], e["mi"])
                delta = abs((_dt.datetime(*got) - _dt.datetime(*want)).total_seconds()) / 60.0
                if delta <= tol_minutes:
                    ok = True
                    break
            if not ok:
                mismatches.append({"hit": h, "expected": expect_txt,
                                   "actual": "%s %02d:%02d" % (h["date"].isoformat(),
                                                               h["occ"]["hh"],
                                                               h["occ"]["mi"]),
                                   "diff": "日期/时刻不等"})
            continue
        if mode == "unit":
            exp_units = [e.get("unit") for e in exp if e["kind"] in ("unit", "value")]
            exp_units = [_cross_norm_unit(u) for u in exp_units if u]
            if not exp_units:
                return _cross_state("证据不足", "mode=unit 但 expected 无单位", "", None,
                                    "mode_expected_mismatch")
            actual_unit = _cross_norm_unit(h["unit"])
            # conflict_units：显式声明「哪些单位写法属于同一量纲下的错误口径」
            # （如 日历天 vs 个工作日、元/套 vs 元/批）。给了它 → 只判这些口径冲突，
            # 不把「计划工期：2024年」这类日期里的 年/月 当成单位漂移（否则 clean 误报）。
            conflict = [_cross_norm_unit(x) for x in (spec.get("conflict_units") or [])
                        if str(x or "").strip()]
            if conflict:
                if actual_unit in conflict and actual_unit not in exp_units:
                    mismatches.append({"hit": h, "expected": "/".join(exp_units),
                                       "actual": actual_unit, "diff": "单位口径冲突"})
            elif actual_unit not in exp_units:
                mismatches.append({"hit": h, "expected": "/".join(exp_units),
                                   "actual": actual_unit, "diff": "单位口径不同"})
            continue
        exp_vals = [e for e in exp if e["kind"] == "value"]
        if not exp_vals:
            return _cross_state("证据不足", "mode=value 但 expected 无数值", "", None,
                                "mode_expected_mismatch")
        unit = base_unit or (exp_vals[0].get("unit") or h["unit"])
        got = _xop_unit_convert(h["value"], h["unit"], unit)
        if got is None:
            return _cross_state(
                "证据不足", "实际值单位无法换算到应有值基准：%s → %s" % (h["unit"], unit),
                h["occ"]["quote"], None, "unit_mismatch", evidence=evidence)
        ok, best = False, None
        for e in exp_vals:
            target = _xop_unit_convert(e["num"], e.get("unit") or unit, unit)
            if target is None:
                return _cross_state("证据不足", "应有值单位无法换算：%s" % e.get("unit"),
                                    "", None, "unit_mismatch")
            tol = max(abs(tolerance), abs(target) * abs(rel_tolerance))
            diff = got - target
            if best is None or abs(diff) < abs(best[1]):
                best = (target, diff, tol)
            if abs(diff) <= tol:
                ok = True
                break
        if not ok:
            mismatches.append({"hit": h, "expected": expect_txt,
                               "actual": "%s%s" % (_cross_fmt(got), unit),
                               "target": "%s%s" % (_cross_fmt(best[0]), unit),
                               "diff": _cross_fmt(best[1]), "unit": unit})
    if mismatches:
        first = mismatches[0]
        det = ("应与外部应有值一致但实际不符：应有「%s」，实际「%s」（差 %s）；"
               "锚点「%s」，共比对 %d 处、%d 处不符（来源 %s）"
               % (first["expected"], first["actual"], first.get("diff"),
                  first["hit"]["anchor"], len(hits), len(mismatches), src))
        return _cross_state(
            "不满足", det,
            _cross_join_quotes([m["hit"]["occ"] for m in mismatches], limit=3),
            first["actual"], "alter_mismatch", expected_source=src,
            expected=expect_txt, n_hits=len(hits), n_mismatch=len(mismatches),
            diff=first.get("diff"),
            # 证据锚定：每处不符的取值各 1 条 evidence（locator 可回查原文位置）
            evidence=[_xop_evidence(m["hit"]["occ"]) for m in mismatches])
    return _cross_state(
        "满足", "应有值一致：锚点 %d 处实际值均等于外部应有值「%s」（来源 %s）"
        % (len(hits), expect_txt, src),
        _cross_join_quotes([h["occ"] for h in hits], limit=2), None, "alter_ok",
        expected_source=src, expected=expect_txt, n_hits=len(hits), evidence=evidence)


# ---- 跨角色关系：角色定位（只做定位，不写死数值/条款） ----------------------
def _crl_label_hit(occ: dict, anchors: list, text: str = "", prefix: int = 40,
                   label_only: bool = False) -> str:
    """角色锚点命中：**标签含锚点**优先（强证据）；标签不含时才退回「锚点出现在该数值
    同分句前文 prefix 字内」（弱证据）。

    分级是必须的：出资比例段里「建设资金来自财政资金（资金来源），项目出资比例为：
    国有资金：0.0万元 0.0%」这类文本，弱证据会让「财政资金」命中到「国有资金」的
    0.0% 上，把 100% 的构成算成 0%。
    """
    hay = (occ.get("label_full") or "") + "|" + (occ.get("label") or "") + "|" + \
          (occ.get("label_raw") or "")
    for a in anchors:
        raw = str(a or "").strip()
        an = _xop_norm_label(raw, width=40)
        if (an and an in hay) or (raw and raw in hay):
            return raw
    if label_only:
        return ""
    body = str(text or "")
    pre = body[max(0, int(occ.get("start") or 0) - prefix): int(occ.get("start") or 0)] \
        if body else ""
    for a in anchors:
        raw = str(a or "").strip()
        if raw and pre and raw in pre:
            return raw
    return ""


def _crl_role_values(text: str, occs: list, anchors: list, *,
                     after: int = None, window: int = 240,
                     scope: str = "first") -> tuple:
    """按多个角色锚点取值：返回 (values, missing)。values=[{anchor,occ}]。"""
    values, missing = [], []
    used = set()
    for anchor in anchors:
        raw = str(anchor or "").strip()
        if not raw:
            continue
        occ = None
        # 1) 锚点出现位置之后的最近数值（同一分句/窗口内）
        for m in re.finditer(re.escape(raw), text):
            cand = [o for o in occs
                    if m.end() <= o["start"] <= m.end() + max(window, 24)]
            if after is not None:
                cand = [o for o in cand if o["start"] >= after]
            if cand:
                occ = cand[0]
                break
        # 2) 标签包含锚点（"其中工程费用约56500.00万元"）
        if occ is None:
            for o in occs:
                if _crl_label_hit(o, [raw]):
                    if after is not None and o["start"] < after:
                        continue
                    occ = o
                    break
        if occ is None:
            missing.append(raw)
            continue
        key = (occ["start"], occ["end"])
        if key in used:
            # 同一处数值被更长的角色锚点先认领了（"钢筋混凝土板涵64道" 同时命中
            # "板涵" 子串）→ 跳过，避免同一分项被重复计入（会把 149 算成 298）。
            continue
        used.add(key)
        values.append({"anchor": raw, "occ": occ})
    return values, missing


# ===========================================================================
# P0-5 D2 修复第 4 项：四个「取数原语」
#
# 第 3 项报告 §9 把 4 条未命中归因为「缺取数原语」。原语 = 只负责**从原文里取出**
# 判据要用的东西（不负责判定）：取出后的比较仍由既有 mode 语义完成。
#   ① range_overlap          区间/编号集合重叠（「1标段、4-10标段」vs「2-4标段」）
#   ② date_interval_end_le   无标签时间区间（「请于 A 至 B」）的终点 ≤ 后序时点
#   ③ window_consistency     同类人员时间窗口（社保/缴纳「（A-B）」）口径一致性
#   ④ date_span_relative_end 「近N年（自 A 至…截止之日止）」：相对终点按文档自身
#                            的递交截止时点换算跨度
# 四个原语都只做**确定性取数**：取不到 → 证据不足（不猜）；取到多义 → 证据不足。
# ===========================================================================
_CRL_RANGE_DASH = r"[-－—–~～至到]"       # 区间连接符（不含单个「-」以外的歧义）
_CRL_INTERVAL_JOIN = re.compile(r"^\s*(?:至|到|~|～|—|–|-|－)\s*$")


def _crl_locator(text: str, pos: int) -> str:
    para = str(text or "").count("\n", 0, max(0, int(pos))) + 1
    return "第%d段@@%d" % (para, pos)


def _crl_scan_date_intervals(text: str) -> list:
    """原语②取数：**无标签时间区间**（两个完整日期 + 至/到/~）。

    为什么要单独取：`date_le` 的 lhs 是措辞表（"获取时间/获取截止"），遇到
    「请于 2025-03-20 09:00:00 至 2025-04-16 10:29:00」这种**没有角色标签**的区间
    就取不到前序角色（第 3 项 P01-026 C09-003 漏命中）。
    只认「两个日期紧邻、中间只有连接符」——中间夹字的不是区间（不猜）。
    """
    body = str(text or "")
    dates = _ade_scan_dates(body)
    out = []
    for i in range(len(dates) - 1):
        d1, d2 = dates[i], dates[i + 1]
        between = body[d1["end"]:d2["pos"]]
        # 日期扫描器只抽到「时:分」，秒（":00"）留在 between 里 → 先剥掉再判连接符。
        between = re.sub(r"^\s*[:：]\s*\d{2}(?:\s*[:：]\s*\d{2})?", "", between)
        if not _CRL_INTERVAL_JOIN.match(between):
            continue
        start_pos = d1["pos"]
        out.append({"start": d1, "end": d2, "pos": start_pos,
                    "locator": _crl_locator(body, start_pos),
                    "quote": body[start_pos:d2["end"]][:160],
                    "ctx": body[max(0, start_pos - 40):start_pos]})
    return out


# ---- 原语② 角色锚点命中：中文同义变体归一化（词序 + 虚词「的」） ---------------
# 取数锚点不能写死单一样例：同一角色在真实公告里有多种写法，例如
#   「获取招标文件」/「招标文件的获取」/「获取招标文件时间」/「招标文件获取时间」。
# 原实现是裸子串 `anchor in pre` → 只中第 1/3 种，第 2/4 种漏取（P01-026 C09-003
# 「四、招标文件的获取 … 请于 A 至 B」→ 证据不足，实为可判）。
# 归一化口径（只用于**角色定位**，不改比较语义、不改取数窗口）：
#   ① 去空白、去「的」；
#   ② 对「2 字动词 + 宾语」型 ≥4 字锚点，额外尝试「宾语 + 动词」倒序
#      （「获取招标文件」→「招标文件获取」）。
# 不做逐字模糊/跳字匹配，避免把无关句里的字面碰巧拼成锚点。
def _crl_anchor_norm(text: str) -> str:
    """锚点/上下文归一化：去空白、去虚词「的」。"""
    return re.sub(r"\s+", "", str(text or "")).replace("的", "")


def _crl_anchor_hit(anchor: str, text: str) -> bool:
    """角色锚点是否命中上下文（原语②取数用；见上方归一化口径）。"""
    a = _crl_anchor_norm(anchor)
    t = _crl_anchor_norm(text)
    if not a or not t:
        return False
    if a in t:
        return True
    if len(a) >= 4 and (a[2:] + a[:2]) in t:
        return True
    return False


_CRL_MONTH_WINDOW_RE = re.compile(
    r"[（(]\s*(?P<y1>20\d{2})\s*年\s*(?P<m1>\d{1,2})\s*月\s*"
    r"[-－—–~～至到]\s*"
    r"(?P<y2>20\d{2})\s*年\s*(?P<m2>\d{1,2})\s*月\s*[）)]")


def _crl_scan_month_windows(text: str, ctx_anchors: list, ctx_window: int = 60) -> dict:
    """原语③取数：**同类人员时间窗口**（`（2024年2月-2025年2月）`）+ 前置语境过滤。

    口径（写死）：窗口前 `ctx_window` 字内必须出现 ctx_anchors 之一（社保/缴纳/养老
    保险…），否则不算该角色的窗口——避免把「施工期（2025年9月-2030年10月）」当成
    社保窗口（P01-025 实测反例）。
    """
    body = str(text or "")
    ctx_anchors = [str(a).strip() for a in (ctx_anchors or []) if str(a or "").strip()]
    wins = []
    for m in _CRL_MONTH_WINDOW_RE.finditer(body):
        y1, m1 = int(m.group("y1")), int(m.group("m1"))
        y2, m2 = int(m.group("y2")), int(m.group("m2"))
        if not (1 <= m1 <= 12 and 1 <= m2 <= 12):
            continue
        pre = body[max(0, m.start() - max(1, int(ctx_window))):m.start()]
        hit = next((a for a in ctx_anchors if a in pre), "")
        if ctx_anchors and not hit:
            continue
        wins.append({"start": (y1, m1), "end": (y2, m2), "anchor": hit,
                     "txt": m.group(0), "pos": m.start(), "endpos": m.end(),
                     "locator": _crl_locator(body, m.start()),
                     "quote": (pre[-16:] + m.group(0)).strip()[:120]})
    return {"ok": bool(wins), "windows": wins,
            "n_distinct": len({(w["start"], w["end"]) for w in wins})}


def _crl_deadline_date(text: str) -> dict:
    """取数据：投标/递交**截止时点**（文档自身定义的时点，用于相对终点换算）。

    只认定义句式「…截止时间…为 DATE」/「截止时间：DATE」；「至投标截止日止」这类
    引用不算定义（否则会取到区间起点）。取不到返回 {}（调用方判证据不足）。
    """
    body = str(text or "")
    dates = _ade_scan_dates(body)
    pats = (r"(?:递交|投标)[^。；\n]{0,26}?截止[^。；\n]{0,26}?为(?!准|据|依据)\s*",
            r"截止时间[^。；\n]{0,12}?[:：]\s*",
            r"截止[^。；\n]{0,16}?为(?!准|据|依据)\s*")
    for pat in pats:
        for m in re.finditer(pat, body):
            # 「…以验收备案日期为准」这类是**口径说明**不是时点定义 → 跳过
            if re.match(r"准|据|依据", body[m.end():m.end() + 3]):
                continue
            cand = [d for d in dates if m.end() <= d["pos"] <= m.end() + 80]
            if cand:
                return cand[0]
    return {}


# ---- 原语③ 补充：同类人员时间窗口的「月份跨度」 ------------------------------
# ---- 原语① 补充：编号集合的「前置窗口」截断 ----------------------------------
# 只在**句读**处截断（不按「具备/资质」截断）：「1标段、5-10标段具备…二级资质」里
# 编号与档位词同属一个复句，用顿号分隔的多个编号都属于同一档；而前一个逗号之前的
# 编号属于上一档（「…二级及以上资质、取得安全生产许可证，2-4标段具备…一级」）。
_CRL_SET_CUT = ("，", ",", "；", ";", "。", "：", ":", "\n", "）", ")", "（", "(")


def _crl_index_set_of(text: str, pos: int, unit: str, back: int = 120) -> dict:
    """锚点位置 → 其**前置窗口**内的编号集合（区间展开 + 单值）。

    为什么取前置窗口：中文写法是「1标段、5-10标段具备…二级资质」——编号在资质档位词
    之前。窗口在最近的句读处截断（不按「具备/资质」截断，否则会把同一档的编号切掉）。
    编号后必须紧跟单位词（`4-10标段`/`1标段`），避免把「二级」里的「二」当编号。
    """
    body = str(text or "")
    unit = str(unit or "标段")
    lo = max(0, int(pos) - max(24, int(back)))
    win = body[lo:int(pos)]
    cut = 0
    for tok in _CRL_SET_CUT:
        k = win.rfind(tok)
        if k >= 0:
            cut = max(cut, k + len(tok))
    win_cut = win[cut:]
    u = re.escape(unit)
    got = set()
    for rm in re.finditer(r"(\d{1,3})\s*" + _CRL_RANGE_DASH + r"\s*(\d{1,3})\s*" + u,
                          win_cut):
        a, b = int(rm.group(1)), int(rm.group(2))
        if 1 <= a <= b <= 200:
            got.update(range(a, b + 1))
    for sm in re.finditer(r"(?<![\d\-－—–~～])(\d{1,3})\s*" + u, win_cut):
        a = int(sm.group(1))
        if 1 <= a <= 200:
            got.add(a)
    return {"set": sorted(got), "window": win_cut[-60:],
            "quote": (body[lo + cut:int(pos)] + body[int(pos):int(pos) + 14]).strip()[:140],
            "locator": _crl_locator(body, max(0, int(pos) - 1))}


# ---- 原语④ 补充：框架年度跨度 ------------------------------------------------
_CRL_FRAMEWORK_RE = re.compile(
    r"(?P<y1>20\d{2})\s*[-－—–~～至到]\s*(?P<y2>20\d{2})\s*年")
_CRL_MONTH_DURATION_RE = re.compile(
    r"(?:绝对工期|服务期限|服务期|履约期限|合同工期|工期)?\s*[（(\[【]?\s*"
    r"(?P<n>\d{1,3})\s*个?月")


def judge_cross_role_limit(slots: dict, text: str) -> dict:
    """跨角色关系：分项 vs 合计 / 乘积 vs 总量 / 比例构成 vs 100% / 日期链。

    槽位（或 slots.cross_role_limit）见本段顶部注释。判定口径：
      - 角色未取到 → 证据不足（不推定为 0）；
      - 量纲不可比（如 平方分米 vs 平方米 之外的未知单位）→ 证据不足；
      - 关系被违反 → 不满足（引文 + 两侧 locator + 差值）；
      - 关系成立 → 满足。
    """
    spec = _xop3_spec(slots, "cross_role_limit")
    mode = str(spec.get("mode") or "part_le_total").strip().lower()
    lhs = [str(a).strip() for a in (spec.get("lhs_anchors") or [])
           if str(a or "").strip()]
    _rhs_raw = spec.get("rhs_anchor")
    rhs_list = [str(x).strip() for x in (_rhs_raw if isinstance(_rhs_raw, (list, tuple))
                                         else [_rhs_raw]) if str(x or "").strip()]
    rhs = rhs_list[0] if rhs_list else ""
    modes_ok = ("part_le_total", "sum_le_total", "sum_eq_total", "sum_ratio_eq",
                "product_eq_total", "product_le_total", "date_le", "date_lt",
                "date_gap_ge", "date_gap_stated", "date_range_le",
                "date_span_stated", "date_eq", "lhs_le_rhs", "lhs_eq_rhs",
                "count_eq_stated",
                # P0-5 D2 修复第 4 项：四个取数原语承接的模式
                "range_overlap", "interval_end_le", "window_gap_le",
                "date_span_relative")
    if mode not in modes_ok:
        return _cross_state("执行失败", "cross_role_limit 不支持的 mode：%s" % mode, "", None,
                            "bad_mode")
    if not lhs:
        return _cross_state("执行失败", "cross_role_limit 缺少 lhs_anchors（前序/分项角色）",
                            "", None, "missing_lhs")
    # 新原语模式：rhs 可为空（由原语自行取数），其余模式仍强制 rhs
    if not rhs and mode not in ("sum_ratio_eq", "date_span_stated",
                                "date_span_relative", "range_overlap",
                                "window_gap_le"):
        return _cross_state("执行失败", "cross_role_limit 缺少 rhs_anchor（合计/后序角色）",
                            "", None, "missing_rhs")
    try:
        tolerance = float(spec.get("tolerance") if spec.get("tolerance") is not None else 0.01)
    except (TypeError, ValueError):
        tolerance = 0.01
    try:
        rel_tolerance = float(spec.get("rel_tolerance") or 0.0)
    except (TypeError, ValueError):
        rel_tolerance = 0.0
    try:
        window = max(0, int(spec.get("window") or 240))
    except (TypeError, ValueError):
        window = 240
    try:
        total_ratio = float(spec.get("total_ratio")
                            if spec.get("total_ratio") is not None else 100.0)
    except (TypeError, ValueError):
        total_ratio = 100.0
    try:
        min_days = max(0, int(spec.get("min_days") or 0))
    except (TypeError, ValueError):
        min_days = 0
    scope = str(spec.get("lhs_scope") or "first").strip().lower()
    body = str(text or "")
    if not body.strip():
        return _cross_state("证据不足", "无原文证据，无法做跨角色关系核对", "", None,
                            "empty_text")
    # ==================================================================
    # P0-5 D2 修复第 4 项：四个取数原语（只取数 + 用既有关系比较；取不到→证据不足）
    # ==================================================================
    if mode == "range_overlap":
        # 原语①：两个资质/档位角色各自覆盖的编号集合是否重叠。
        # 「1标段、5-10标段…二级」「2-4标段…一级」→ 二级 {1,5,6,7,8,9,10}、一级 {2,3,4}
        # → 无重叠=满足；同一编号同时落入两档=不满足（L2 口径下这是明确矛盾）。
        unit = str(spec.get("unit") or "标段").strip() or "标段"
        try:
            back = max(24, int(spec.get("window") or 90))
        except (TypeError, ValueError):
            back = 90
        sets, ev = {}, []
        for anchor in lhs:
            raw = str(anchor or "").strip()
            if not raw:
                continue
            for m in re.finditer(re.escape(raw), body):
                got = _crl_index_set_of(body, m.start(), unit, back=back)
                if not got["set"]:
                    continue
                sets.setdefault(raw, set()).update(got["set"])
                ev.append({"locator": got["locator"], "quote": got["quote"],
                           "label": raw, "raw": "、".join(map(str, got["set"]))})
        if len(sets) < 2:
            return _cross_state(
                "证据不足",
                "区间重叠：只取到 %d 个角色的编号集合（需要 ≥2 个角色才能核重叠；已取到 %s）"
                % (len(sets), "、".join("「%s」=%s" % (k, sorted(v))
                                        for k, v in sets.items()) or "无"),
                "", None, "missing_index_sets",
                lhs_sets={k: sorted(v) for k, v in sets.items()}, evidence=ev)
        names = list(sets)
        overlaps = []
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                ov = sorted(sets[names[i]] & sets[names[j]])
                if ov:
                    overlaps.append({"a": names[i], "b": names[j], "overlap": ov})
        det = ("区间重叠核对（%s）：%s；重叠 %s"
               % (unit, "｜".join("「%s」={%s}" % (k, ",".join(map(str, sorted(v))))
                                  for k, v in sets.items()),
                  "；".join("「%s」∩「%s」={%s}" % (x["a"], x["b"],
                                                  ",".join(map(str, x["overlap"])))
                            for x in overlaps) or "无"))
        if overlaps:
            first = overlaps[0]
            return _cross_state(
                "不满足", det + "（同一编号落入两个档位要求，资格条件重叠）",
                _cross_join_quotes(ev[:3], limit=3), first["overlap"][0],
                "cross_role_range_overlap",
                overlap=[{"a": x["a"], "b": x["b"], "codes": x["overlap"]}
                         for x in overlaps],
                lhs_sets={k: sorted(v) for k, v in sets.items()}, evidence=ev)
        return _cross_state("满足", det + "（两个档位覆盖的编号互不重叠）",
                            _cross_join_quotes(ev[:3], limit=3), None,
                            "cross_role_range_disjoint",
                            lhs_sets={k: sorted(v) for k, v in sets.items()}, evidence=ev)
    if mode == "interval_end_le":
        # 原语②：**无标签时间区间**（「请于 A 至 B」）的终点 ≤ 后序时点。
        # 角色定位：lhs_anchors 任一出现在区间前 ctx_window 字内；
        # 负语境（写死）：区间前的上下文里若出现「工期/施工期/服务期/开竣工/近N年」
        #   这类**别的角色**标签，则该区间不属于本判据取数范围（不猜）——
        #   实测 P01-003「2.3计划工期…2027年6月15日至2024年12月15日」会被误当获取期。
        # 后序时点：优先用文档自身的「截止时间…为 DATE」定义句；取不到再看 rhs_anchor
        #   的**定义式**出现（锚点后 26 字内出现「为/：」再接日期）。
        try:
            ctx_window = max(20, int(spec.get("window") or 200))
        except (TypeError, ValueError):
            ctx_window = 200
        exclude_ctx = list(spec.get("exclude_ctx") or []) or [
            "工期", "施工期", "服务期", "服务期限", "开、竣工", "开工", "竣工",
            "近三", "近3", "近5", "近五", "近24", "近36", "近两年", "近三年"]
        intervals = _crl_scan_date_intervals(body)
        picked, skipped = [], []
        for iv in intervals:
            pre = body[max(0, iv["pos"] - ctx_window):iv["pos"]]
            if any(str(x) and str(x) in pre for x in exclude_ctx):
                skipped.append({"quote": iv["quote"], "why": "negative_context",
                                "ctx": pre[-40:]})
                continue
            # 角色锚点命中走同义变体归一化（「招标文件的获取」/「获取招标文件时间」
            # 等与「获取招标文件」等价；见 _crl_anchor_hit）。取数窗口不变。
            hit = next((a for a in lhs if a and _crl_anchor_hit(a, pre)), "")
            if lhs and not hit:
                continue
            picked.append({**iv, "anchor": hit})
        if not picked:
            return _cross_state(
                "证据不足",
                "无标签时间区间：原文没有「日期 至 日期」结构（或区间前无角色锚点 %s）%s"
                % ("、".join(lhs[:3]),
                   "；另有 %d 个区间因负语境被排除" % len(skipped) if skipped else ""),
                "", None, "missing_interval", skipped=skipped[:5])
        full = _ade_scan_dates(body)
        rhs_d = _crl_deadline_date(body) or None
        if rhs_d is None:
            for cand in (rhs_list or []):
                for m in re.finditer(re.escape(cand), body):
                    tail = body[m.end():m.end() + 26]
                    mm = re.search(r"[为:：]\s*$", tail) or re.search(r"[为:：]", tail)
                    if not mm:
                        continue
                    got = [d for d in full
                           if m.end() + mm.end() <= d["pos"] <= m.end() + 120]
                    if got:
                        rhs_d = got[0]
                        break
                if rhs_d is not None:
                    break
        if rhs_d is None:
            return _cross_state("证据不足",
                                "无标签时间区间：未取到后序时点（%s 或文档截止时间定义）"
                                % ("、".join(rhs_list[:2]) or "rhs_anchor"),
                                picked[0]["quote"], None, "missing_rhs_date")
        ev = [{"locator": rhs_d["locator"], "quote": rhs_d["quote"], "label": "后序时点",
               "raw": rhs_d["txt"]}]
        for iv in picked:
            ev.append({"locator": iv["locator"], "quote": iv["quote"],
                       "label": "区间" + ("（%s）" % iv["anchor"] if iv["anchor"] else ""),
                       "raw": iv["start"]["txt"] + "~" + iv["end"]["txt"]})
        bad = [iv for iv in picked if iv["end"]["key"] > rhs_d["key"]]
        det = ("无标签时间区间核对：%s；后序时点 %s"
               % ("｜".join("「%s」=%s~%s" % (iv["anchor"] or "-",
                                            iv["start"]["date"].isoformat(),
                                            iv["end"]["date"].isoformat())
                            for iv in picked[:4]), rhs_d["date"].isoformat()))
        if bad:
            first = bad[0]
            return _cross_state(
                "不满足", det + "（区间终点晚于后序时点：%s > %s）"
                % (first["end"]["date"].isoformat(), rhs_d["date"].isoformat()),
                _cross_join_quotes([{"locator": first["locator"],
                                     "quote": first["quote"]},
                                    {"locator": rhs_d["locator"],
                                     "quote": rhs_d["quote"]}], limit=2),
                first["end"]["date"].isoformat(), "cross_role_interval_late",
                interval={"start": first["start"]["date"].isoformat(),
                          "end": first["end"]["date"].isoformat()},
                rhs=rhs_d["date"].isoformat(), evidence=ev)
        return _cross_state("满足", det + "（区间终点不晚于后序时点）",
                            rhs_d["quote"], picked[0]["end"]["date"].isoformat(),
                            "cross_role_interval_ok", evidence=ev)
    if mode == "window_gap_le":
        # 原语③：同类人员时间窗口（社保/缴纳「（A年a月-B年b月）」）的**最晚月份**
        # 距该文档递交截止时点的月数 ≤ 上限（默认 6 个月）→ 满足；否则不满足。
        # 语境过滤：窗口前 window 字内必须出现 lhs_anchors（社保/缴纳/养老保险…）。
        try:
            max_gap = int(spec.get("min_days") or spec.get("max_gap_months") or 6)
        except (TypeError, ValueError):
            max_gap = 6
        try:
            ctx_window = max(20, int(spec.get("window") or 60))
        except (TypeError, ValueError):
            ctx_window = 60
        got = _crl_scan_month_windows(body, lhs, ctx_window=ctx_window)
        if not got["ok"]:
            return _cross_state(
                "证据不足",
                "时间窗口：原文没有「（YYYY年M月-YYYY年M月）」结构，或窗口前无 %s 语境"
                % "、".join(lhs[:3]), "", None, "missing_month_window")
        dl = _crl_deadline_date(body)
        if not dl:
            return _cross_state("证据不足",
                                "时间窗口：未取到文档递交截止时点，无法按月核对",
                                got["windows"][0]["quote"], None, "missing_deadline")
        # 口径（写死，训练集内定标）：**逐窗口**核对——同类人员（社保/缴纳）的每个窗口
        # 都必须覆盖到递交截止前 max_gap 个月内。只看「最晚那个窗口」会漏判：
        # 文档里常同时有「总监（旧窗口）」与「其他人员（新窗口）」，最晚窗口是新的，
        # 旧窗口的滞后就被掩盖（实测 P01-029 缺陷态）。
        gaps = []
        for w in got["windows"]:
            g_m = (dl["date"].year - w["end"][0]) * 12 + (dl["date"].month - w["end"][1])
            gaps.append({"window": w["txt"], "end": "%04d-%02d" % w["end"],
                         "gap_months": g_m, "locator": w["locator"],
                         "quote": w["quote"]})
        ev = [{"locator": w["locator"], "quote": w["quote"],
               "label": "窗口（%s）" % (w["anchor"] or "-"), "raw": w["txt"]}
              for w in got["windows"]]
        ev.append({"locator": dl["locator"], "quote": dl["quote"],
                   "label": "递交截止", "raw": dl["txt"]})
        worst = max(gaps, key=lambda x: x["gap_months"])
        det = ("时间窗口核对：%d 个窗口（%s）；递交截止 %s，最大滞后 %d 个月"
               "（上限 %d 个月：%s）"
               % (len(gaps), "、".join(g["window"] for g in gaps[:4]),
                  dl["date"].isoformat()[:7], worst["gap_months"], max_gap,
                  "、".join("%s→+%d月" % (g["end"], g["gap_months"]) for g in gaps[:4])))
        if worst["gap_months"] > max_gap:
            return _cross_state(
                "不满足", det + "（存在窗口大幅滞后，不能证明该人员当前在职）",
                _cross_join_quotes([{"locator": worst["locator"],
                                     "quote": worst["quote"]},
                                    {"locator": dl["locator"],
                                     "quote": dl["quote"]}], limit=2),
                worst["gap_months"], "cross_role_window_lag",
                gap_months=worst["gap_months"], max_gap_months=max_gap,
                windows=[w["txt"] for w in got["windows"]],
                gaps=gaps, evidence=ev)
        return _cross_state("满足", det, dl["quote"], worst["gap_months"],
                            "cross_role_window_ok", gap_months=worst["gap_months"],
                            max_gap_months=max_gap, gaps=gaps, evidence=ev)
    if mode == "date_span_relative":
        # 原语④：自述「近N年（自 A 至 …截止…止）」的跨度核对。终点是**相对表述**
        # （「投标文件递交截止之日止」）→ 用文档自身的递交截止时点换算（不像
        # date_span_stated 那样要求括号内两个完整日期）。
        m_span = None
        for _m in re.finditer(r"(?:近|最近)\s*([0-9一二三四五六七八九十]{1,3})\s*个?\s*"
                              r"(年|月)", body):
            _rest = body[_m.end():]
            _par = re.match(r"\s*[（(]", _rest)
            if not _par:
                continue        # 「近3年年平均营业收入…」这类不是区间自述 → 跳过
            _inner = _rest[_par.end():_par.end() + 160]
            _end = re.search(r"[）)]", _inner)
            _inner = _inner[:_end.start()] if _end else _inner
            if not _ade_scan_dates(_inner):
                continue        # 括号内无日期 → 不是区间自述
            m_span = _m
            break
        if not m_span:
            return _cross_state("证据不足",
                                "相对终点区间：原文没有「近N年/月（…日期…）」区间自述",
                                "", None, "missing_stated_span")
        n = _crl_cn2int(m_span.group(1))
        if not n:
            return _cross_state("证据不足", "相对终点区间：自述数量无法解析", "", None,
                                "bad_stated_span")
        unit = m_span.group(2)
        rest = body[m_span.end():]
        m_par = re.match(r"\s*[（(]", rest)
        if not m_par:
            return _cross_state(
                "证据不足", "相对终点区间：自述「%s」后不是紧邻括号，不推测区间"
                % m_span.group(0).strip(), "", None, "span_not_parenthesized")
        inner = rest[m_par.end(): m_par.end() + 160]
        m_end = re.search(r"[）)]", inner)
        inner = inner[:m_end.start()] if m_end else inner
        ds = _ade_scan_dates(inner)
        if not ds:
            return _cross_state("证据不足", "相对终点区间：括号内没有起始日期", "", None,
                                "missing_span_start")
        d1 = ds[0]
        rel = re.search(r"(?:截止|递交|投标)[^）)]{0,24}?止", inner)
        if not rel:
            return _cross_state(
                "证据不足",
                "相对终点区间：括号内终点不是「…截止…止」相对表述，且无第二个完整日期"
                "（不推测）", d1["quote"], None, "missing_relative_end")
        dl = _crl_deadline_date(body)
        if not dl:
            return _cross_state("证据不足",
                                "相对终点区间：未取到文档自身递交截止时点，无法换算终点",
                                d1["quote"], None, "missing_deadline")
        d2 = dl
        months = (d2["date"].year - d1["date"].year) * 12 + \
                 (d2["date"].month - d1["date"].month)
        want = n if unit == "月" else n * 12
        # 容差口径（训练集内定标，写死）：自述「近N年」在实务里按年度粗写，起止日期常
        # 比 N 年多出几个月（实测 P01-002 近三年 vs 40 个月、P01-009 38 个月、
        # P01-010 近5年 vs 61 个月）。容差 = want/6（≥3 个月）：36→6、60→10。
        # 该容差仍能判出 P01-024 缺陷态（近3年 vs 60 个月，差 24）。
        tol = max(3, abs(want) // 6)
        ev = [{"locator": d1["locator"], "quote": d1["quote"], "label": "起",
               "raw": d1["txt"]},
              {"locator": d2["locator"], "quote": d2["quote"], "label": "止（相对终点）",
               "raw": d2["txt"]}]
        det = ("相对终点区间核对：自述「%s」= %d 个月；括号内起点 %s，终点按文档"
               "「%s」= %s 换算，实为 %d 个月（容差 %d）"
               % (m_span.group(0).strip(), want, d1["date"].isoformat(),
                  rel.group(0)[:16], d2["date"].isoformat(), months, tol))
        if abs(months - want) > tol:
            return _cross_state(
                "不满足", det + "（差 %d 个月）" % abs(months - want),
                _cross_join_quotes([{"locator": d1["locator"], "quote": d1["quote"]},
                                    {"locator": d2["locator"], "quote": d2["quote"]}],
                                   limit=2),
                months, "cross_role_span_relative_mismatch",
                want_months=want, months=months, tolerance=tol, evidence=ev)
        return _cross_state("满足", det, d2["quote"], months,
                            "cross_role_span_relative_ok", want_months=want,
                            months=months, tolerance=tol, evidence=ev)
    # ---------------------------------------------------------------- 日期链
    if mode == "date_range_le":
        # 区间终点 ≤ 另一角色时点（"主体工程施工期（2025年9月-2030年10月）" vs "2031年7月末投产"）
        months = _crl_scan_months(body)
        full = _ade_scan_dates(body)
        def last_after(anchor, pool):
            for m in re.finditer(re.escape(anchor), body):
                cand = [x for x in pool if m.end() <= x["pos"] <= m.end() + 200]
                if cand:
                    return cand[-1]
            return None
        lhs_d = None
        for anchor in lhs:
            lhs_d = last_after(anchor, months) or last_after(anchor, full)
            if lhs_d is not None:
                break
        rhs_d = None
        for _c in (rhs_list or ["投产"]):
            rhs_d = last_after(_c, full) or last_after(_c, months)
            if rhs_d is not None:
                rhs = _c
                break
        if lhs_d is None:
            return _cross_state("证据不足", "区间终点：未取到前序角色（%s）的区间"
                                % "、".join(lhs[:3]), "", None, "missing_lhs_range")
        if rhs_d is None:
            return _cross_state("证据不足", "区间终点：未取到后序角色「%s」的时点"
                                % (rhs or "投产"), "", None, "missing_rhs_date")
        ev = [{"locator": lhs_d["locator"], "quote": lhs_d["quote"],
               "label": "区间：" + lhs[0], "raw": lhs_d["txt"]},
              {"locator": rhs_d["locator"], "quote": rhs_d["quote"],
               "label": "后序：" + rhs, "raw": rhs_d["txt"]}]
        det = ("区间终点核对：前序区间终点 %s %s 后序角色「%s」时点 %s"
               % (lhs_d["date"].isoformat(), "晚于" if lhs_d["date"] > rhs_d["date"]
                  else "不晚于", rhs, rhs_d["date"].isoformat()))
        if (lhs_d["date"].year, lhs_d["date"].month) > (rhs_d["date"].year,
                                                        rhs_d["date"].month):
            return _cross_state("不满足", det + "（区间越过后续节点，节点顺序倒置）",
                                _cross_join_quotes([{"locator": lhs_d["locator"],
                                                     "quote": lhs_d["quote"]},
                                                    {"locator": rhs_d["locator"],
                                                     "quote": rhs_d["quote"]}], limit=2),
                                lhs_d["date"].isoformat(), "cross_role_range_order",
                                evidence=ev)
        return _cross_state("满足", det, rhs_d["quote"], None,
                            "cross_role_range_ok", evidence=ev)
    if mode == "date_span_stated":
        # 自述「近N年/近N个月」与括号内起止日期跨度是否一致（业绩/信誉追溯期）
        m_span = re.search(r"(?:近|最近)\s*([0-9一二三四五六七八九十]{1,3})\s*个?\s*"
                           r"(年|月)", body)
        if not m_span:
            return _cross_state("证据不足", "追溯期：原文没有「近N年/月」自述", "", None,
                                "missing_stated_span")
        n = _crl_cn2int(m_span.group(1))
        if not n:
            return _cross_state("证据不足", "追溯期：自述数量无法解析", "", None,
                                "bad_stated_span")
        unit = m_span.group(2)
        # 口径写死：只认「近N年（起 至 止）」这种**紧邻括号**的写法。跨段找日期会把
        # 「近三年」和完全无关的两个日期配上 → clean 误报（实测 6/20 训练干净文档）。
        rest = body[m_span.end():]
        m_par = re.match(r"\s*[（(]", rest)
        if not m_par:
            return _cross_state("证据不足",
                                "追溯期：自述「%s」后不是紧邻括号内的起止日期，不推测区间"
                                % m_span.group(0).strip(), "", None, "span_not_parenthesized")
        inner = rest[m_par.end(): m_par.end() + 80]
        m_end = re.search(r"[）)]", inner)
        if not m_end:
            return _cross_state("证据不足", "追溯期：括号未闭合，不推测区间", "", None,
                                "span_unclosed")
        inner = inner[:m_end.start()]
        ds = _ade_scan_dates(inner)
        if len(ds) < 2:
            return _cross_state("证据不足", "追溯期：括号内起止日期不足 2 个", "", None,
                                "missing_span_dates")
        d1, d2 = ds[0], ds[1]
        months = (d2["date"].year - d1["date"].year) * 12 +                  (d2["date"].month - d1["date"].month)
        want = n if unit == "月" else n * 12
        det = ("追溯期核对：自述「%s」= %d 个月，括号内 %s ~ %s 实为 %d 个月"
               % (m_span.group(0).strip(), want, d1["date"].isoformat(),
                  d2["date"].isoformat(), months))
        tol = max(1, abs(want) // 12)
        ev = [{"locator": d1["locator"], "quote": d1["quote"], "label": "起",
               "raw": d1["txt"]},
              {"locator": d2["locator"], "quote": d2["quote"], "label": "止",
               "raw": d2["txt"]}]
        if abs(months - want) > tol:
            return _cross_state("不满足", det + "（差 %d 个月，超出 %d 个月容差）"
                                % (abs(months - want), tol),
                                _cross_join_quotes([{"locator": d1["locator"],
                                                     "quote": d1["quote"]},
                                                    {"locator": d2["locator"],
                                                     "quote": d2["quote"]}], limit=2),
                                months, "cross_role_span_mismatch", want_months=want,
                                months=months, evidence=ev)
        return _cross_state("满足", det, d2["quote"], months,
                            "cross_role_span_ok", want_months=want, months=months,
                            evidence=ev)
    if mode in ("date_le", "date_lt", "date_eq", "date_gap_ge", "date_gap_stated"):
        # L39 ⑧：日期链分支启用扩展扫描（全角归一 + 紧凑 8 位 + 「YYYY年M月」月精度）。
        dates = _ade_scan_dates(body, extended=True)
        try:
            role_window = max(40, int(spec.get("window") or 200))
        except (TypeError, ValueError):
            role_window = 200
        if not dates:
            return _cross_state("证据不足", "日期链：原文没有可解析日期", "", None,
                                "no_dates")
        # 角色日期定位（口径写死）：锚点出现位置 → 同分句内、**锚点之后**的日期才算该角色
        # 的取值（"获取时间：起 至 止"落两个日期取最后一个=截止；"截止时间…为X日"只落一个）。
        # 锚点前出现的日期（如「自2020年3月1日至投标截止日」里的 2020-03-01）不属于该角色，
        # 否则会把业绩期起点误认成投标截止（D2 修复第 2 项报告 §9 第 3 条同类问题）。
        def role_date(anchor, take="last", strict=False):
            """角色日期定位（口径写死）：

            - 日期必须在锚点**之后**（锚点前的日期属于别的角色，如「自2020-03-01至
              投标截止日」里的 2020-03-01）；
            - 锚点是「至/到/自…」这类区间引用的宾语时跳过（"至投标截止日"不是时点定义，
              时点定义通常写成「…截止时间为 X」「投标截止时间：X」）；
            - strict=True（后序角色）要求锚点后 role_window 内出现，不接受远距离兜底，
              避免把无关段落日期当成时点。
            """
            raw = str(anchor or "").strip()
            if not raw:
                return None
            # 先收集候选锚点出现位置：跳过「至/到/自/于」引导的区间宾语，以及
            # 「（同开标时间）」这类括注引用；优先取「锚点自成标签」的出现位置
            # （前一个字不是中文，如「6.1开标时间：」），避免把括注里的引用当定义句。
            picks = []
            for m in re.finditer(re.escape(raw), body):
                prev2 = body[max(0, m.start() - 2): m.start()]
                if prev2.endswith(("至", "到", "自", "于")):
                    continue
                label_like = (m.start() == 0 or not re.match(r"[\u4e00-\u9fff]",
                                                             body[m.start() - 1]))
                picks.append((0 if label_like else 1, m))
            picks.sort(key=lambda x: (x[0], x[1].start()))
            for _, m in picks:
                clause = None
                for cm in _CRL_CLAUSE_RE.finditer(body):
                    if cm.start() <= m.start() < cm.end():
                        clause = (cm.start(), cm.end())
                        break
                cand = []
                if clause is not None:
                    cand = [d for d in dates if m.end() <= d["pos"] < clause[1]]
                if not cand and not strict:
                    # 兜底：锚点单独成行（"获取\n\n2025年…至…"）时分句里没有日期，
                    # 允许取锚点之后 role_window 字内的日期（仍只取锚点之后）。
                    cand = [d for d in dates
                            if m.end() <= d["pos"] <= m.end() + role_window]
                if cand:
                    return cand[-1] if take == "last" else cand[0]
            return None
        rhs_d = None
        for _cand in (rhs_list or [lhs[0]]):
            rhs_d = role_date(_cand, "first", strict=True)
            if rhs_d is not None:
                rhs = _cand
                break
        if rhs_d is None:
            for _cand in (rhs_list or [lhs[0]]):
                rhs_d = role_date(_cand, "last", strict=True)
                if rhs_d is not None:
                    rhs = _cand
                    break
        if rhs_d is None:
            return _cross_state("证据不足", "日期链：未找到后序角色「%s」的日期"
                                % (rhs or lhs[0]), "", None, "missing_rhs_date")
        # L39 ⑦：date_lt 的前序角色取「锚点后第一个日期」而非最后一个。
        # 「生产日期 2026-03-10，有效期至 2027-03-09」同分句内两个日期，取 last 会把
        # 后序日期当生产日期 → 6 条 false fail。其它模式（如 date_le 的「获取时间 A 至 B」
        # 取截止）保持 last，不影响既有招采口径。
        _lhs_take = str(spec.get("lhs_take") or "").strip().lower()
        if _lhs_take not in ("first", "last"):
            _lhs_take = "first" if (mode == "date_lt" and _fix2_on("date_lhs_take")) else "last"
        lhs_hits, missing = [], []
        for anchor in lhs:
            d = role_date(anchor, _lhs_take)
            if d is None:
                missing.append(anchor)
            else:
                lhs_hits.append({"anchor": anchor, "date": d})
        ev = [{"locator": rhs_d["locator"], "quote": rhs_d["quote"],
               "label": "后序：" + (rhs or lhs[0]), "raw": rhs_d["txt"]}]
        for h in lhs_hits:
            ev.append({"locator": h["date"]["locator"], "quote": h["date"]["quote"],
                       "label": "前序：" + h["anchor"], "raw": h["date"]["txt"]})
        if not lhs_hits:
            return _cross_state("证据不足", "日期链：前序角色（%s）未取到日期"
                                % "、".join(lhs[:3]), "", None, "missing_lhs_date")
        if mode == "date_gap_stated":
            # 自述下限：从原文读「不少于N日/天」的 N（不写死常量，避免把无自述的文档误判）
            m_min = re.search(r"不少于\s*(\d{1,3})\s*(?:个)?(?:日|天)", body)
            if not m_min:
                return _cross_state("证据不足", "期限间隔：原文没有「不少于N日」自述下限",
                                    rhs_d["quote"], None, "missing_stated_min")
            min_days = int(m_min.group(1))
        if mode in ("date_gap_ge", "date_gap_stated"):
            # 前序起点（同句首个日期）→ 后序截止 的间隔是否 ≥ min_days
            start = None
            for anchor in lhs:
                ds = []
                for m in re.finditer(re.escape(anchor), body):
                    for cm in _CRL_CLAUSE_RE.finditer(body):
                        if cm.start() <= m.start() < cm.end():
                            ds.extend([d for d in dates
                                       if m.end() <= d["pos"] < cm.end()])
                            break
                    if not ds:
                        # 与 role_date 同口径的兜底（锚点单独成行）
                        ds.extend([d for d in dates
                                   if m.end() <= d["pos"] <= m.end() + role_window])
                    if ds:
                        break
                if ds:
                    start = ds[0]
                    break
            if start is None:
                return _cross_state("证据不足", "日期链：前序起点未取到", "", None,
                                    "missing_lhs_start")
            gap = (rhs_d["date"] - start["date"]).days
            det = ("期限间隔核对：前序起点 %s → 后序截止 %s 实为 %d 日，"
                   "自述下限 %d 日" % (start["date"].isoformat(),
                                      rhs_d["date"].isoformat(), gap, min_days))
            ev.insert(0, {"locator": start["locator"], "quote": start["quote"],
                          "label": "前序起点", "raw": start["txt"]})
            if gap < min_days:
                return _cross_state("不满足", det + "（不足 %d 日）" % (min_days - gap),
                                    _cross_join_quotes(
                                        [{"locator": start["locator"], "quote": start["quote"]},
                                         {"locator": rhs_d["locator"], "quote": rhs_d["quote"]}],
                                        limit=2),
                                    gap, "cross_role_date_gap", min_days=min_days,
                                    gap_days=gap, evidence=ev)
            return _cross_state("满足", det, rhs_d["quote"], gap,
                                "cross_role_date_gap_ok", min_days=min_days,
                                gap_days=gap, evidence=ev)
        # L39 ⑧：月精度日期（「2026年5月」）只比较到月；同月无法确认严格先后 → 证据不足
        def _prec_month(d):
            return str(d.get("precision") or "") == "month"

        _any_month = _prec_month(rhs_d) or any(_prec_month(h["date"]) for h in lhs_hits)

        def _date_key(d):
            if _any_month:
                return (d["date"].year, d["date"].month)
            return d["key"]

        if _any_month and mode == "date_lt":
            for h in lhs_hits:
                if (h["date"]["date"].year, h["date"]["date"].month) == \
                        (rhs_d["date"].year, rhs_d["date"].month) and \
                        (_prec_month(h["date"]) or _prec_month(rhs_d)):
                    return _cross_state(
                        "证据不足",
                        ("日期链：前序「%s」=%s 与后序「%s」=%s 仅精确到月且同月，"
                         "无法确认严格先后") % (h["anchor"], h["date"]["txt"],
                                                rhs or lhs[0], rhs_d["txt"]),
                        h["date"]["quote"], None, "date_month_precision")
        bad = []
        for h in lhs_hits:
            lk, rk = _date_key(h["date"]), _date_key(rhs_d)
            if mode == "date_le":
                viol = lk > rk
            elif mode == "date_eq":
                viol = lk[:3] != rk[:3]
            else:
                viol = lk >= rk
            if viol:
                bad.append(h)
        op_txt = {"date_le": "不得晚于", "date_eq": "必须同日",
                  "date_lt": "必须早于"}[mode]
        if bad:
            first = bad[0]
            det = ("日期链倒置：前序角色「%s」=%s %s 后序角色「%s」=%s"
                   "（共核对 %d 个前序角色、%d 个倒置）"
                   % (first["anchor"], first["date"]["date"].isoformat(), op_txt,
                      rhs or lhs[0], rhs_d["date"].isoformat(), len(lhs_hits), len(bad)))
            return _cross_state("不满足", det,
                                _cross_join_quotes(
                                    [{"locator": rhs_d["locator"], "quote": rhs_d["quote"]},
                                     {"locator": first["date"]["locator"],
                                      "quote": first["date"]["quote"]}], limit=2),
                                first["date"]["date"].isoformat(),
                                "cross_role_date_order", evidence=ev)
        return _cross_state("满足", "日期链成立：%d 个前序角色均%s后序角色「%s」=%s"
                            % (len(lhs_hits), op_txt.replace("必须", ""),
                               rhs or lhs[0], rhs_d["date"].isoformat()),
                            rhs_d["quote"], None, "cross_role_date_ok", evidence=ev)
    occs = _crl_scan(body)
    if not occs:
        return _cross_state("证据不足", "跨角色关系：原文没有可解析数值", "", None,
                            "no_values")
    # ------------------------------------------------------------ 比例构成
    if mode == "sum_ratio_eq":
        pct = [o for o in occs if o.get("dim") == "percent"]
        # 先按段（paragraph）聚类，选「命中角色锚点最多」的那一段作为构成列举段：
        # 出资比例/分值构成通常是一整段连续列举；正文里零散出现的 0.0% 会把合计压到 0。
        by_para = {}
        for o in pct:
            para = o.get("para")
            by_para.setdefault(para, []).append(o)
        best_para, best_hits = None, -1
        for para, rows0 in by_para.items():
            n = sum(1 for a in lhs if any(_crl_label_hit(o, [a], body) for o in rows0))
            if n > best_hits:
                best_para, best_hits = para, n
        rows = []
        if best_para is not None and best_hits > 0:
            pool = by_para[best_para]
            # 归属口径（写死）：每个百分比归给「前文最近的那一个角色锚点」（先强证据=标签
            # 命中，再弱证据=锚点文本在同一段前文 40 字内）。这样「财政资金：25939.09万元
            # 100.0%」的 100% 归「财政资金」，不会因为「国有资金：0.0万元 0.0%」出现在
            # 更前面而被错误归属（否则会让合计变成 0%）。
            assigned = {}
            for o in pool:
                cand = []
                for anchor in lhs:
                    hits = [m for m in re.finditer(re.escape(str(anchor)), body)
                            if m.start() < int(o.get("start") or 0)
                            and int(o.get("start") or 0) - m.end() <= 40]
                    if hits:
                        cand.append((hits[-1].end(), anchor))
                if not cand:
                    for anchor in lhs:
                        if _crl_label_hit(o, [anchor], body, label_only=True):
                            cand.append((0, anchor))
                if not cand:
                    continue
                cand.sort()
                anchor = cand[-1][1]
                if anchor not in assigned:
                    assigned[anchor] = o
            for anchor in lhs:
                if anchor in assigned:
                    rows.append({"anchor": anchor, "occ": assigned[anchor]})
        if not rows:
            return _cross_state("证据不足", "比例构成：未取到任何分项比例（%s）"
                                % "、".join(lhs[:4]), "", None, "missing_ratio_parts")
        vals, ev = [], []
        for r in rows:
            base = _crl_base(r["occ"])
            # percent 量纲的基准倍率：% → 1.0（值本身就是百分数）、‰ → 0.1，
            # 因此直接用 base[0]，不再乘 100（否则 100% 会被算成 10000%）。
            vals.append(base[0] if base else r["occ"]["value"])
            ev.append({"locator": r["occ"]["locator"], "quote": r["occ"]["quote"],
                       "raw": r["occ"]["raw"], "unit": r["occ"]["unit"],
                       "value": r["occ"]["value"], "label": r["anchor"]})
        total = math.fsum(vals)
        tol = max(abs(tolerance), abs(total_ratio) * abs(rel_tolerance))
        det = ("比例构成合计=%.2f%%（%d 个分项：%s），应闭合到 %.2f%%（差 %.2f 个百分点）"
               % (total, len(rows),
                  "、".join("%s=%.2f%%" % (r["anchor"], v)
                           for r, v in zip(rows, vals)), total_ratio,
                  total - total_ratio))
        if abs(total - total_ratio) > tol:
            return _cross_state("不满足", det,
                                _cross_join_quotes([r["occ"] for r in rows], limit=4),
                                total, "cross_role_ratio_mismatch",
                                total_ratio=total_ratio, part_sum=total,
                                diff=total - total_ratio, evidence=ev)
        return _cross_state("满足", det,
                            _cross_join_quotes([r["occ"] for r in rows], limit=2),
                            total, "cross_role_ratio_ok", total_ratio=total_ratio,
                            part_sum=total, evidence=ev)
    # ------------------------------------------------------- 数值型：合计/后序角色
    # 角色锚点允许多个别名（rhs_anchor 是列表）：逐个候选尝试，取第一个能落到具体
    # 取值的别名——只认第 0 个会把「规划建设容量 50MW」漏成「未找到总装机容量」
    # （P01-023 实测：该文档写的是「规划建设容量」而不是「总装机容量」）。
    rhs_occ = None
    for _cand_alias in (rhs_list or [rhs]):
        for o in occs:
            if _crl_label_hit(o, [_cand_alias], body):
                rhs_occ, rhs = o, _cand_alias
                break
        if rhs_occ is not None:
            break
    if rhs_occ is None:
        for _cand_alias in (rhs_list or [rhs]):
            for m in re.finditer(re.escape(_cand_alias), body):
                cand = [o for o in occs
                        if m.end() <= o["start"] <= m.end() + max(window, 40)]
                if cand:
                    rhs_occ, rhs = cand[0], _cand_alias
                    break
            if rhs_occ is not None:
                break
    if rhs_occ is None:
        return _cross_state("证据不足", "跨角色关系：未找到合计/后序角色「%s」的取值" % rhs,
                            "", None, "missing_rhs_value")
    rhs_base = _crl_base(rhs_occ)
    if rhs_base is None:
        return _cross_state("证据不足", "合计项单位未知（%s），不猜" % rhs_occ["unit"],
                            rhs_occ["quote"], None, "unit_mismatch")
    rhs_val, rhs_dim = rhs_base
    # 分项取值：默认要求**出现在合计项之后**（构成列举的典型形态）；若合计项之后
    # 一个分项都没取到（如「涵洞149道，其中板涵54道」写成合计在前、或分项在同段更早），
    # 退化为全篇按角色锚点取值——但要求每处锚点在**同一分句**里，避免把正文其他段落的
    # 同名数值当成构成分项（实测该退化会把 149 算成 298 → 干净文档误报）。
    values, missing = _crl_role_values(body, occs, lhs, after=rhs_occ["end"],
                                       window=window, scope=scope)
    if not values:
        values, missing = _crl_role_values(body, occs, lhs, after=None,
                                           window=window, scope=scope)
    if scope == "sum":
        agg, miss2 = [], []
        for anchor in lhs:
            rows = [o for o in occs if _crl_label_hit(o, [anchor], body)]
            if not rows:
                miss2.append(anchor)
            else:
                agg.append({"anchor": anchor, "occ": rows})
        values, missing = agg, miss2
    if not values:
        return _cross_state("证据不足", "跨角色关系：分项角色（%s）均未取到取值"
                            % "、".join(lhs[:4]), rhs_occ["quote"], None,
                            "missing_lhs_value",
                            evidence=[{"locator": rhs_occ["locator"],
                                       "quote": rhs_occ["quote"]}])
    # lhs_any：lhs_anchors 是**同义别名**（「允许中」/「最多中标」）而不是构成分项。
    # 别名只需要命中一个——否则写「最多中标」的文档会因为没写「允许中」被判证据不足
    # （第 3 项 cap_le_total 在留出集上就是这样恒证据不足的）。
    lhs_any = bool(spec.get("lhs_any"))
    vals, ev = [], [{"locator": rhs_occ["locator"], "quote": rhs_occ["quote"],
                     "raw": rhs_occ["raw"], "unit": rhs_occ["unit"],
                     "value": rhs_occ["value"], "label": rhs}]
    for f in values:
        rows = f["occ"] if isinstance(f["occ"], list) else [f["occ"]]
        for occ in rows:
            base = _crl_base(occ)
            if base is None:
                return _cross_state("证据不足", "分项单位未知（%s），不猜" % occ["unit"],
                                    occ["quote"], None, "unit_mismatch")
            vals.append({"anchor": f["anchor"], "value": base[0], "dim": base[1],
                         "occ": occ})
            ev.append({"locator": occ["locator"], "quote": occ["quote"],
                       "raw": occ["raw"], "unit": occ["unit"], "value": occ["value"],
                       "label": f["anchor"]})
    if missing and not lhs_any:
        return _cross_state("证据不足", "跨角色关系：分项角色未取到（%s），不推定为 0"
                            % "、".join(missing[:4]), rhs_occ["quote"], None,
                            "missing_lhs_value", evidence=ev)
    # --------------------------------------------------- product_eq/le_total
    if mode in ("product_eq_total", "product_le_total"):
        dims = {v["dim"] for v in vals if v["dim"] not in ("count", "")}
        if len(dims) > 1:
            return _cross_state("证据不足", "乘积因子量纲不一致：%s" % "、".join(sorted(dims)),
                                rhs_occ["quote"], None, "unit_mismatch", evidence=ev)
        prod = 1.0
        for v in vals:
            prod *= v["value"]
        if not dims:
            dim = "count"
        else:
            dim = next(iter(dims))
        if dim != rhs_dim and not (dim == "count" or rhs_dim == "count"):
            return _cross_state("证据不足", "乘积量纲（%s）与合计（%s）不可比"
                                % (dim, rhs_dim), rhs_occ["quote"], None,
                                "unit_mismatch", evidence=ev)
        tol = max(abs(tolerance), abs(rhs_val) * abs(rel_tolerance))
        _pscale = _crl_unit_scale(rhs_occ)
        _pdisp = (lambda base: _cross_fmt(base / _pscale) + rhs_occ["unit"]) \
            if _pscale else (lambda base: _cross_fmt(base))
        det = ("跨角色乘积关系：%s 乘积=%s；合计「%s」=%s"
               % ("×".join("%s(%s)" % (_cross_fmt(v["value"]), v["anchor"]) for v in vals),
                  _pdisp(prod), rhs, _pdisp(rhs_val)))
        bad = (abs(prod - rhs_val) > tol) if mode == "product_eq_total" \
            else (prod - rhs_val > tol)
        if bad:
            return _cross_state("不满足", det + "；差 %s（容差 %s）"
                                % (_pdisp(prod - rhs_val), _cross_fmt(tol)),
                                _cross_join_quotes([rhs_occ] + [v["occ"] for v in vals],
                                                   limit=4),
                                prod, "cross_role_product_mismatch",
                                total_value=rhs_val, product=prod, diff=prod - rhs_val,
                                tolerance=tol, evidence=ev)
        return _cross_state("满足", det + "；在容差 %s 内相符" % _cross_fmt(tol),
                            rhs_occ["quote"], prod, "cross_role_product_ok",
                            total_value=rhs_val, product=prod, tolerance=tol,
                            evidence=ev)
    # ------------------------------------------- 两个角色取值直接比较 / 计数核对
    if mode in ("lhs_le_rhs", "lhs_eq_rhs"):
        if len(vals) != 1:
            return _cross_state(
                "证据不足",
                "两个角色直接比较需要恰好 1 个前序角色取值，实际取到 %d 个（%s）"
                % (len(vals), "、".join(v["anchor"] for v in vals)),
                rhs_occ["quote"], None, "ambiguous_lhs", evidence=ev)
        a = vals[0]
        b = rhs_val
        tol = max(abs(tolerance), abs(b) * abs(rel_tolerance))
        det = ("角色比较（%s）：前序「%s」=%s%s；后序「%s」=%s%s"
               % (mode, a["anchor"], _cross_fmt(a["occ"]["value"]), a["occ"]["unit"],
                  rhs, _cross_fmt(rhs_occ["value"]), rhs_occ["unit"]))
        if a["dim"] != rhs_dim and not (a["dim"] == "count" or rhs_dim == "count"):
            return _cross_state("证据不足", "两个角色量纲不同（%s vs %s），不硬比"
                                % (a["dim"], rhs_dim), rhs_occ["quote"], None,
                                "unit_mismatch", evidence=ev)
        if mode == "lhs_le_rhs":
            bad = a["value"] > b + tol
            msg = "；前序大于后序（超 %s）" % _cross_fmt(a["value"] - b)
            if bad:
                return _cross_state("不满足", det + msg,
                                    _cross_join_quotes([a["occ"], rhs_occ], limit=2),
                                    a["value"], "cross_role_lhs_gt_rhs",
                                    lhs_value=a["value"], rhs_value=b,
                                    diff=a["value"] - b, tolerance=tol, evidence=ev)
            return _cross_state("满足", det + "；前序未超过后序（容差 %s）"
                                % _cross_fmt(tol), rhs_occ["quote"], a["value"],
                                "cross_role_lhs_le_rhs_ok", lhs_value=a["value"],
                                rhs_value=b, tolerance=tol, evidence=ev)
        if abs(a["value"] - b) > tol:
            return _cross_state("不满足", det + "；两者相差 %s（容差 %s）"
                                % (_cross_fmt(abs(a["value"] - b)), _cross_fmt(tol)),
                                _cross_join_quotes([a["occ"], rhs_occ], limit=2),
                                a["value"], "cross_role_lhs_ne_rhs",
                                lhs_value=a["value"], rhs_value=b,
                                diff=a["value"] - b, tolerance=tol, evidence=ev)
        return _cross_state("满足", det + "；两者相符（容差 %s）" % _cross_fmt(tol),
                            rhs_occ["quote"], a["value"], "cross_role_lhs_eq_rhs_ok",
                            lhs_value=a["value"], rhs_value=b, tolerance=tol,
                            evidence=ev)
    if mode == "count_eq_stated":
        # 计数核对：原文中「lhs 标签」出现的**不同编号/条目数** vs 声明的数量。
        # 口径写死：数的是原文里 lhs_anchors 各自出现次数（去重后），不推断缺失编号。
        stated = rhs_val
        counts = []
        for anchor in lhs:
            n = len(re.findall(re.escape(str(anchor)), body))
            counts.append((anchor, n))
        actual = sum(n for _, n in counts)
        tol = max(abs(tolerance), 0.0)
        det = ("计数核对：声明「%s」=%s；原文命中条目 %s（合计 %d）"
               % (rhs, _cross_fmt(rhs_occ["value"]),
                  "、".join("%s×%d" % (a, n) for a, n in counts), actual))
        if abs(actual - stated) > tol:
            return _cross_state("不满足", det + "；与声明数量相差 %s"
                                % _cross_fmt(actual - stated),
                                _cross_join_quotes([rhs_occ], limit=1), actual,
                                "cross_role_count_mismatch", stated=stated,
                                actual=actual, tolerance=tol, evidence=ev)
        return _cross_state("满足", det + "；计数与声明一致", rhs_occ["quote"], actual,
                            "cross_role_count_ok", stated=stated, actual=actual,
                            tolerance=tol, evidence=ev)
    # ------------------------------------------------------ sum_eq/le/part_le
    dims = {v["dim"] for v in vals}
    if len(dims) > 1:
        return _cross_state("证据不足", "分项量纲不一致（%s），不硬算" % "、".join(sorted(dims)),
                            rhs_occ["quote"], None, "unit_mismatch", evidence=ev)
    # 分项与合计必须同量纲（金额 vs 面积 vs 数量不可比）。唯一例外是计数单位（台/道/座…）
    # 与合计的计数单位相同；把「100 平方米」和「58000 万元」硬比会把量纲错误算成满足。
    if dims and rhs_dim and dims != {rhs_dim} and "count" not in dims \
            and rhs_dim != "count":
        return _cross_state(
            "证据不足",
            "分项量纲（%s）与合计量纲（%s）不可比，不硬算"
            % ("、".join(sorted(dims)), rhs_dim),
            rhs_occ["quote"], None, "unit_mismatch", evidence=ev)
    part_sum = math.fsum(v["value"] for v in vals)
    tol = max(abs(tolerance), abs(rhs_val) * abs(rel_tolerance))
    _rhs_scale = _crl_unit_scale(rhs_occ)
    _disp = (lambda base: _cross_fmt(base / _rhs_scale) + rhs_occ["unit"]) \
        if _rhs_scale else (lambda base: _cross_fmt(base))
    detail = ("跨角色关系（%s）：合计/后序「%s」=%s；分项 %d 项：%s（合计 %s）"
              % (mode, rhs, _disp(rhs_val), len(vals),
                 "、".join("%s=%s%s" % (v["anchor"], _cross_fmt(v["occ"]["value"]),
                                        v["occ"]["unit"]) for v in vals),
                 _disp(part_sum)))
    if mode == "part_le_total":
        bad = [v for v in vals if v["value"] - rhs_val > tol]
        if bad:
            first = bad[0]
            return _cross_state(
                "不满足", detail + "；分项「%s」=%s%s 大于合计 %s（超 %s）"
                % (first["anchor"], _cross_fmt(first["occ"]["value"]),
                   first["occ"]["unit"], _disp(rhs_val), _disp(first["value"] - rhs_val)),
                _cross_join_quotes([rhs_occ, first["occ"]], limit=2),
                first["value"], "cross_role_part_gt_total", total_value=rhs_val,
                part_value=first["value"], diff=first["value"] - rhs_val,
                tolerance=tol, evidence=ev)
        return _cross_state("满足", detail + "；各分项均未超过合计（容差 %s）"
                            % _cross_fmt(tol), rhs_occ["quote"], part_sum,
                            "cross_role_part_le_total_ok", total_value=rhs_val,
                            part_sum=part_sum, tolerance=tol, evidence=ev)
    if mode == "sum_le_total":
        if part_sum - rhs_val > tol:
            return _cross_state("不满足", detail + "；分项合计超出合计 %s"
                                % _cross_fmt(part_sum - rhs_val),
                                _cross_join_quotes([rhs_occ] + [v["occ"] for v in vals],
                                                   limit=4),
                                part_sum, "cross_role_sum_gt_total",
                                total_value=rhs_val, part_sum=part_sum,
                                diff=part_sum - rhs_val, tolerance=tol, evidence=ev)
        return _cross_state("满足", detail + "；分项合计未超合计", rhs_occ["quote"],
                            part_sum, "cross_role_sum_le_total_ok", total_value=rhs_val,
                            part_sum=part_sum, tolerance=tol, evidence=ev)
    if abs(part_sum - rhs_val) > tol:
        return _cross_state("不满足", detail + "；与合计相差 %s（容差 %s）"
                            % (_cross_fmt(abs(part_sum - rhs_val)), _cross_fmt(tol)),
                            _cross_join_quotes([rhs_occ] + [v["occ"] for v in vals],
                                               limit=4),
                            part_sum, "cross_role_sum_ne_total", total_value=rhs_val,
                            part_sum=part_sum, diff=part_sum - rhs_val,
                            tolerance=tol, evidence=ev)
    return _cross_state("满足", detail + "；构成闭合（容差 %s）" % _cross_fmt(tol),
                        rhs_occ["quote"], part_sum, "cross_role_sum_eq_total_ok",
                        total_value=rhs_val, part_sum=part_sum, tolerance=tol,
                        evidence=ev)


# ---------------------------------------------------------------------------
# 跨文件关系判定（订单键 + 版本比较）
#
# manifest D4 的确定性执行按「单文件」进行，跨文件关系（执行版本 vs 批准文件
# 同订单批准版本）没有执行器。这里提供与单文件执行器同口径的确定性关系执行：
#   - 订单键从原文显式字段提取（订单/订单号/合同号…），不做模糊猜测；
#   - 执行版本 / 批准版本按角色词识别，角色词由规则槽位声明；
#   - 订单不同 → 证据不足（不比较）；同订单批准版本冲突 → 证据不足；
#   - 版本相同 → 满足；版本不同 → 不满足。引文保留执行文件的版本行，可回查定位。
# ---------------------------------------------------------------------------
_RELATION_DEFAULTS = {
    "type": "version_match",
    "order_key_label": "订单",
    "subject_markers": ("执行", "送审", "实际"),
    "reference_markers": ("批准", "批复", "审定", "批准文件"),
    # 版本行/订单行排除词：其他订单、历史资料、草稿（draft 未生效）不进入同订单比较。
    "exclude_markers": ("其他订单", "历史资料", "历史批次", "参考范本", "草稿",
                        "draft", "未签署", "不生效", "不得用", "忽略", "示例"),
}


def _relation_tokens(raw):
    if isinstance(raw, (list, tuple)):
        return [str(x).strip() for x in raw if str(x or "").strip()]
    if isinstance(raw, str) and raw.strip():
        return [x.strip() for x in re.split(r"[、,，;；]", raw) if x.strip()]
    return []


def _relation_spec(slots: dict) -> dict:
    slots = dict(slots or {})
    raw = slots.get("cross_relation")
    spec = dict(raw) if isinstance(raw, dict) else {}
    labels = (_relation_tokens(spec.get("order_key_labels")
                               or slots.get("order_key_labels"))
              or _relation_tokens(spec.get("order_key_label")
                                  or slots.get("order_key_label")))
    if not labels:
        labels = [_RELATION_DEFAULTS["order_key_label"]]
    out = {
        "type": str(spec.get("type") or slots.get("relation_type")
                    or _RELATION_DEFAULTS["type"]).strip() or "version_match",
        # 多标签订单键：同一项目的订单键可能写在「合同编号/执行记录/批准单」等不同标签后，
        # 单标签匹配不到执行文件时关系执行器会稳定证据不足（产品缺口）。
        "order_key_labels": labels,
        "order_key_label": labels[0],
    }
    for key in ("subject_markers", "reference_markers", "exclude_markers"):
        vals = spec.get(key) or slots.get(key)
        got = _relation_tokens(vals)
        out[key] = tuple(got) if got else tuple(_RELATION_DEFAULTS[key])
    return out


def _relation_line_of(text: str, pos: int) -> str:
    body = str(text or "")
    start = body.rfind("\n", 0, max(0, pos)) + 1
    end = body.find("\n", max(0, pos))
    if end < 0:
        end = len(body)
    return body[start:end].strip()


def _relation_line_excluded(line: str, spec: dict) -> bool:
    """版本/订单行是否属于「其他订单/历史/草稿」等无效语境。"""
    text = str(line or "")
    return any(m and m in text for m in (spec.get("exclude_markers") or ()))


def _relation_order_keys_in(line: str, labels) -> list:
    """单行显式订单键：按多标签（合同编号/执行记录/批准单…）依次抽取，不猜模糊指代。"""
    out = []
    for label in labels or []:
        if not label:
            continue
        pat = re.compile(re.escape(label) + r"(?:号|编号)?[ \t]*[:：]?[ \t]*"
                         r"([A-Za-z0-9][A-Za-z0-9\-_/.、]{1,30})")
        for m in pat.finditer(str(line or "")):
            v = m.group(1).rstrip(".,;，。；、")
            if v and v not in out:
                out.append(v)
    return out


def _relation_order_keys(text: str, labels, spec: dict = None) -> list:
    """原文显式订单键（多标签；排除其他订单/历史资料/草稿行）。"""
    spec = spec or {}
    out = []
    for line in str(text or "").splitlines():
        if _relation_line_excluded(line, spec):
            continue
        for v in _relation_order_keys_in(line, labels):
            if v not in out:
                out.append(v)
    return out


def _relation_line_no(body: str, pos: int) -> int:
    return str(body or "")[:max(0, pos)].count("\n") + 1


def _relation_versions(text: str, spec: dict) -> list:
    """版本声明 → [{role, version, quote, line, line_no, order_keys, excluded}]。"""
    body = str(text or "")
    out = []
    for m in re.finditer("版本", body):
        line = _relation_line_of(body, m.start())
        pre = body[max(0, m.start() - 12):m.start()]
        after = body[m.end():m.end() + 18]
        vm = re.match(r"[ \t]*(?:[:：]|为|是)?[ \t]*([vV]?\d+(?:\.\d+)*)", after)
        if not vm:
            continue
        role = ""
        for mk in spec["subject_markers"]:
            if mk and mk in pre:
                role = "subject"
                break
        if not role:
            for mk in spec["reference_markers"]:
                if mk and mk in pre:
                    role = "reference"
                    break
        line_no = _relation_line_no(body, m.start())
        out.append({"role": role, "version": vm.group(1), "quote": line[:120],
                    "pos": m.start(), "line": line, "line_no": line_no,
                    "order_keys": _relation_order_keys_in(
                        line, spec.get("order_key_labels") or []),
                    "excluded": _relation_line_excluded(line, spec)})
    return out


def _version_key(value):
    """版本归一：v1 / 1 / V1.0 → 可比较元组；非数字退化为字符串。"""
    s = str(value or "").strip().lower()
    if s.startswith("v"):
        s = s[1:]
    parts = re.findall(r"\d+", s)
    if parts:
        return tuple(int(x) for x in parts)
    return (str(value or "").strip(),)


def _relation_evidence(docs, involved_ids):
    """关系判定证据：执行/批准文档中所有版本声明行（含被排除语境行，供审计核对）。"""
    out = []
    for d in docs:
        if str(d.get("object_id") or "") not in involved_ids:
            continue
        body = str(d.get("text") or "")
        for line_no, line in enumerate(body.splitlines(), 1):
            if "版本" not in line:
                continue
            if not re.search(r"版本[ \t]*(?:[:：]|为|是)?[ \t]*[vV]?\d", line):
                continue
            out.append({"file": str(d.get("filename") or ""),
                        "line": int(line_no), "quote": line.strip()[:200]})
    return out


def judge_document_relation(slots=None, documents=None) -> dict:
    """跨文件关系判定（确定性）：多标签订单键匹配 + 版本比较。

    documents: [{"object_id":..., "filename":..., "text":...}, ...]
    返回 {state: 满足/不满足/证据不足/执行失败, detail, quote, object_id,
          reference_object_id, order_key, subject_version, reference_version,
          evidence, trace}
    口径：
    - 订单键从原文显式标签（可多标签）提取，其他订单/历史/草稿行不作为本订单事实；
    - 执行版本 / 批准版本按角色词识别，draft 未生效不充当批准版本；
    - 订单不同 → 证据不足（不比较）；同订单批准版本冲突 → 证据不足；
    - 版本相同 → 满足；版本不同 → 不满足。
    """
    slots = dict(slots or {})
    spec = _relation_spec(slots)
    docs = [d for d in (documents or []) if isinstance(d, dict) and d.get("text")]
    base = {"quote": "", "object_id": "", "reference_object_id": "",
            "order_key": "", "subject_version": "", "reference_version": "",
            "relation": spec, "evidence": []}
    if spec["type"] not in ("version_match", "version_consistency", "version_equal"):
        return {**base, "state": "执行失败",
                "detail": "不支持的关系类型：%s" % spec["type"]}
    if len(docs) < 2:
        return {**base, "state": "证据不足",
                "detail": "跨文件关系判定至少需要 2 个文件（执行文件 + 批准文件），"
                          "当前只有 %d 个可解析文件" % len(docs),
                "documents": len(docs)}
    facts = []
    for d in docs:
        text = str(d.get("text") or "")
        facts.append({"object_id": str(d.get("object_id") or ""),
                      "filename": str(d.get("filename") or ""),
                      "text": text,
                      "order_keys": _relation_order_keys(
                          text, spec["order_key_labels"], spec),
                      "versions": _relation_versions(text, spec)})
    subjects = [(f, v) for f in facts for v in f["versions"]
                if v["role"] == "subject" and not v.get("excluded")]
    refs = [(f, v) for f in facts for v in f["versions"]
            if v["role"] == "reference" and not v.get("excluded")]
    if not subjects:
        return {**base, "state": "证据不足",
                "detail": "未找到执行版本证据（缺少「%s版本」声明），无法做跨文件版本比较"
                          % "、".join(spec["subject_markers"]),
                "documents": len(docs)}
    if len({(f["object_id"], _version_key(v["version"])) for f, v in subjects}) > 1:
        vals = sorted({v["version"] for _, v in subjects})
        return {**base, "state": "证据不足",
                "detail": "执行文件的执行版本存在多处冲突：%s，需人工裁决" % "、".join(vals),
                "documents": len(docs)}
    sf, sv = subjects[0]
    base["object_id"] = sf["object_id"]
    base["subject_version"] = sv["version"]
    base["quote"] = sv["quote"]
    order_key = ""
    if sv.get("order_keys"):
        order_key = str(sv["order_keys"][0])
    elif sf.get("order_keys"):
        order_key = str(sf["order_keys"][0])
    base["order_key"] = order_key
    if not order_key:
        return {**base, "state": "证据不足",
                "detail": "执行文件缺少「%s」订单键，无法定位同订单批准文件"
                          % "/".join(spec["order_key_labels"])}
    same_order = []
    for f, v in refs:
        keys = list(v.get("order_keys") or []) or list(f.get("order_keys") or [])
        if order_key in keys:
            same_order.append((f, v))
    if not same_order:
        if refs:
            other = sorted({k for f, v in refs
                            for k in (list(v.get("order_keys") or [])
                                      or list(f.get("order_keys") or []))})
            return {**base, "state": "证据不足",
                    "detail": "批准文件订单为 %s，与执行文件订单 %s 不同，订单不同不比较"
                              % ("、".join(other) or "未标注", order_key)}
        return {**base, "state": "证据不足",
                "detail": "缺少同订单（%s）批准文件/批准版本证据" % order_key}
    ref_versions = sorted({v["version"] for _, v in same_order}, key=_version_key)
    if len(ref_versions) > 1:
        return {**base, "state": "证据不足",
                "detail": "同订单（%s）批准文件的批准版本冲突：%s，需人工裁决"
                          % (order_key, "、".join(ref_versions))}
    rf, rv = same_order[0]
    base["reference_object_id"] = rf["object_id"]
    base["reference_version"] = rv["version"]
    base["evidence"] = _relation_evidence(
        docs, {str(sf["object_id"]), str(rf["object_id"])})
    same = _version_key(sv["version"]) == _version_key(rv["version"])
    return {**base,
            "state": "满足" if same else "不满足",
            "detail": "执行版本%s 与批准版本%s %s（订单 %s）"
                      % (sv["version"], rv["version"],
                         "一致" if same else "不一致", order_key),
            "trace": {"subject": sv, "reference": rv,
                      "subject_document": {"object_id": sf["object_id"],
                                           "filename": sf["filename"]},
                      "reference_document": {"object_id": rf["object_id"],
                                             "filename": rf["filename"]},
                      "order_key": order_key,
                      "order_key_labels": spec["order_key_labels"]}}


# ---------------------------------------------------------------------------
# 项目级确定性执行器（跨文件计算/比较）
#
# manifest D4 的确定性执行按「单文件」进行；未付余额、累计费用、UTC 时点比较、
# 许可证日期、台账勾稽、批次温度豁免这类结论必须同时读取项目内多份文件才能得出。
# 这里提供与单文件执行器同契约（五态 + 子要求 + tool_trace）的项目级执行器：
#   - 输入是 manifest 冻结对象的文本集合（同一项目上下文，不跨项目拼接）；
#   - 字段由规则槽位显式声明（标签/来源文件），执行期不猜模糊指代；
#   - 金额用 Decimal（最终分四舍五入），时点统一换算 UTC 比较，不做字符串排序；
#   - 关键原始事实缺失/不可读/来源冲突 → 证据不足，不猜、不补默认值；
#   - 输出与 D4 同口径的 subs，供 finding 台账按 occurrence 落库。
# 计算类型（slots["project_compute"]["calculation"]）：
#   unpaid_balance_cap / segmented_fee_cap / utc_deadline /
#   license_expiry_date / ledger_reconcile / batch_temperature_exception /
#   inventory_snapshot / invoice_payable / delivery_deadline / certificate_validity /
#   cross_doc_consistency（T-157 跨文档键对齐一致性，见文件后段「T-157」小节）
# ---------------------------------------------------------------------------
PROJECT_COMPUTE_TEMPLATE = "project_compute"

_PROJECT_CALCULATIONS = ("unpaid_balance_cap", "segmented_fee_cap",
                         "utc_deadline", "license_expiry_date",
                         "ledger_reconcile", "batch_temperature_exception",
                         "inventory_snapshot", "invoice_payable",
                         "delivery_deadline", "certificate_validity",
                         "cross_doc_consistency")

_PROJECT_DEFAULT_EXCLUDE = ("历史资料索引", "其他订单", "不属于本订单", "历史批次",
                            "参考范本", "草稿", "draft", "未签署", "不生效",
                            "不得用于", "忽略", "示例", "范本")


def _proj_num(raw):
    """金额/数值 → Decimal；不可解析返回 None（不返回 0）。"""
    s = str(raw if raw is not None else "").strip()
    if not s:
        return None
    s = (s.replace(",", "").replace("，", "").replace("￥", "")
          .replace("¥", "").replace("元", "").strip())
    if not re.match(r"^-?\d+(?:\.\d+)?$", s):
        return None
    try:
        return Decimal(s)
    except Exception:
        return None


def _proj_fmt(value):
    """Decimal/数值 → 稳定可读文本（整数不带小数点，小数去尾零但至少保留原精度）。"""
    if value is None:
        return ""
    try:
        d = Decimal(str(value))
    except Exception:
        return str(value)
    if d == d.to_integral_value():
        return str(int(d))
    return format(d.normalize(), "f")


def _proj_money(value):
    """金额 → 人民币分四舍五入后的 Decimal；None 透传。"""
    if value is None:
        return None
    try:
        d = Decimal(str(value))
    except Exception:
        return None
    return d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _proj_dt(raw):
    """时刻 → (UTC aware datetime, reason)；无时区/不可解析返回 reason，不猜时区。"""
    s = str(raw if raw is not None else "").strip().rstrip("。；;，,、")
    s = s.replace(" ", "T", 1) if re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:", s) else s
    if not s:
        return None, "missing"
    try:
        value = _dt.datetime.fromisoformat(s.replace("Z", "+00:00")
                                           .replace("z", "+00:00"))
    except Exception:
        return None, "unparsable"
    if value.tzinfo is None:
        return None, "tz_missing"
    return value.astimezone(_dt.timezone.utc), ""


def _proj_date(raw):
    """日期 → date；不可解析返回 None。"""
    s = str(raw if raw is not None else "").strip().rstrip("。；;，,、")
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", s)
    if not m:
        return None
    try:
        return _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except Exception:
        return None


def _proj_value_of(value):
    """从文本行里声明值：去引号/空白；返回原串（供 Decimal/日期/时刻解析）。"""
    return str(value if value is not None else "").strip().strip("“”\"'").strip()


def _project_spec(slots):
    raw = (slots or {}).get("project_compute")
    return dict(raw) if isinstance(raw, dict) else {}


def _proj_collect(documents, spec):
    """项目文档集 → 规则可见行（同项目上下文的全部冻结对象文本）。"""
    markers = tuple(spec.get("exclude_markers") or _PROJECT_DEFAULT_EXCLUDE)
    docs = []
    for d in documents or []:
        if not isinstance(d, dict):
            continue
        text = str(d.get("text") or "")
        clean = []
        for i, line in enumerate(text.splitlines(), 1):
            if any(m and m in line for m in markers):
                continue
            clean.append((i, line))
        docs.append({"object_id": str(d.get("object_id") or ""),
                     "filename": str(d.get("filename") or ""),
                     "text": text, "lines": text.splitlines(), "clean": clean})
    return docs


def _proj_files(docs, files):
    """按文件名筛选文档（files 为空时不过滤）。"""
    if not files:
        return docs
    return [d for d in docs if any(f and f in d["filename"] for f in files)]


def _proj_hits(docs, pattern, files=None, flags=0):
    out = []
    for d in _proj_files(docs, files):
        for i, line in d["clean"]:
            m = re.search(pattern, line, flags)
            if m:
                out.append({"file": d["filename"], "object_id": d["object_id"],
                            "line_no": i, "line": line.strip(), "match": m})
    return out


def _proj_evidence(hit):
    return {"file": hit["file"], "line": int(hit["line_no"]),
            "quote": str(hit["line"]).strip()}


def _proj_dedup_evidence(items):
    out, seen = [], set()
    for e in items or []:
        key = (str(e.get("file") or ""), int(e.get("line") or 0))
        if not key[0] or key[1] <= 0 or key in seen:
            continue
        seen.add(key)
        out.append({"file": key[0], "line": key[1],
                    "quote": str(e.get("quote") or "")})
    return out


def _proj_sub(sid, status, detail, quote, calc, evidence, inputs=None, result=None):
    trace = {"executor": PROJECT_COMPUTE_TEMPLATE, "calculation": calc,
             "evidence": _proj_dedup_evidence(evidence)}
    if inputs:
        trace["inputs"] = inputs
    if result:
        trace["result"] = result
    return {"id": sid, "status": status, "raw_state": "project_compute",
            "detail": detail, "quote": str(quote or "")[:300],
            "evidence_ok": status in ("pass", "fail"), "tool_trace": trace}


def _proj_result(state, detail, subs, calc, evidence, inputs=None, result=None):
    return {"state": state, "detail": detail, "subs": subs,
            "evidence": _proj_dedup_evidence(evidence),
            "trace": {"executor": PROJECT_COMPUTE_TEMPLATE,
                      "template": PROJECT_COMPUTE_TEMPLATE,
                      "calculation": calc, "state": state,
                      "inputs": inputs or {}, "result": result or {}}}


def _proj_insufficient(calc, detail, inputs=None, evidence=None):
    return _proj_result("证据不足", detail,
                        [_proj_sub("S1", "insufficient", detail, "", calc,
                                   evidence or [], inputs)],
                        calc, evidence or [], inputs)


def _proj_label_hit(docs, label, files=None):
    """标签显式取值：`标签：值` / `标签 值`；同一标签多处取值冲突返回 conflict。"""
    pat = re.escape(str(label)) + r"[ \t]*[:：=]?[ \t]*([^。；;\n]+)"
    hits = _proj_hits(docs, pat, files)
    values = []
    for h in hits:
        raw = _proj_value_of(h["match"].group(1))
        raw = re.split(r"[。；;]", raw)[0].strip()
        values.append((raw, h))
    return values


def _proj_single_value(docs, label, files=None, parse=None):
    """取唯一标签值：缺 → (None, reason missing)；冲突 → (None, reason conflict)。"""
    pairs = _proj_label_hit(docs, label, files)
    if not pairs:
        return None, "missing", []
    distinct = []
    for raw, hit in pairs:
        value = parse(raw) if parse else raw
        if value is not None and all(value != x for x, _ in distinct):
            distinct.append((value, hit))
    if not distinct:
        return None, "unparsable", pairs
    if len(distinct) > 1:
        return None, "conflict", pairs
    return distinct[0][0], "", pairs


def _proj_order_key(docs, label, files=None):
    pairs = _proj_label_hit(docs, label, files)
    for raw, hit in pairs:
        m = re.match(r"([A-Za-z0-9][A-Za-z0-9\-_/.]{0,40})", raw)
        if m:
            return m.group(1), hit
    return "", None


def _proj_ledger(spec, docs, ledger_files):
    """付款台账：行级 posted/cancelled 事件 + 汇总已付款 + 订单键一致性。

    只统计 posted；cancelled 不计入但保留为证据；金额不可识别 → insufficient，
    不静默丢弃（缺失付款金额会同时影响 R01/R03/R08 三个依赖项）。
    """
    rows, bad, evidence = [], [], []
    header = ""
    for d in _proj_files(docs, ledger_files):
        for i, line in d["clean"]:
            if "|" not in line:
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 3:
                continue
            state = parts[1].lower()
            amount_raw = parts[2]
            amount = _proj_num(amount_raw)
            row = {"row_id": parts[0], "state": state, "amount": amount,
                   "amount_raw": amount_raw, "file": d["filename"],
                   "line_no": i, "line": line.strip()}
            rows.append(row)
            evidence.append({"file": d["filename"], "line": i,
                             "quote": line.strip()})
            if state not in ("posted", "cancelled"):
                bad.append({**row, "reason": "unknown_state"})
            elif amount is None:
                bad.append({**row, "reason": "amount_unreadable"})
    for d in _proj_files(docs, ledger_files):
        for i, line in d["clean"]:
            m = re.search(r"付款台账[ \t]*[:：][ \t]*([A-Za-z0-9][A-Za-z0-9\-_/.]{0,40})",
                          line)
            if m and not header:
                header = m.group(1)
    posted = [r for r in rows if r["state"] == "posted" and r["amount"] is not None]
    cancelled = [r for r in rows if r["state"] == "cancelled"]
    if not rows:
        return {"ok": False, "reason": "ledger_missing", "detail": "未找到付款台账行",
                "rows": rows, "posted": [], "cancelled": [], "evidence": evidence}
    if bad:
        first = bad[0]
        detail = (f"付款台账 {first['row_id']} 金额不可识别（{first['amount_raw']}），"
                  "不能推定已付款合计" if first["reason"] == "amount_unreadable"
                  else f"付款台账 {first['row_id']} 状态不可识别（{first['state']}）")
        return {"ok": False, "reason": first["reason"], "detail": detail,
                "rows": rows, "posted": posted, "cancelled": cancelled,
                "evidence": evidence, "bad": bad}
    if not posted:
        return {"ok": False, "reason": "no_posted",
                "detail": "付款台账没有 posted 记录，无法核验已付款",
                "rows": rows, "posted": [], "cancelled": cancelled,
                "evidence": evidence}
    return {"ok": True, "rows": rows, "posted": posted, "cancelled": cancelled,
            "header": header, "evidence": evidence,
            "posted_total": sum((r["amount"] for r in posted), Decimal("0"))}


def _proj_cash_base(spec, docs, ledger_files):
    """合同总额 + posted 已付款 → 未付余额基数；同时校验订单键不跨单。"""
    total, reason, total_pairs = _proj_single_value(
        docs, spec.get("total_label") or "合同总额",
        spec.get("total_files") or spec.get("contract_files") or None,
        parse=_proj_num)
    if total is None:
        return {"ok": False, "reason": reason,
                "detail": ("缺少可核验的合同总额（%s）" % (spec.get("total_label") or "合同总额")
                           + ("，多处取值冲突" if reason == "conflict" else "")),
                "evidence": [_proj_evidence(h) for _v, h in total_pairs]}
    total_hit = total_pairs[0][1]
    ledger = _proj_ledger(spec, docs, ledger_files)
    evidence = [_proj_evidence(total_hit)] + list(ledger.get("evidence") or [])
    if not ledger.get("ok"):
        return {"ok": False, "reason": ledger.get("reason"),
                "detail": ledger.get("detail") or "付款台账不可核验",
                "evidence": evidence}
    contract_hit = _proj_order_key(docs, spec.get("contract_order_label") or "合同编号",
                                   spec.get("contract_files") or None)
    contract_key = contract_hit[0] if contract_hit else ""
    header = str(ledger.get("header") or "")
    if contract_key and header and contract_key != header:
        return {"ok": False, "reason": "order_mismatch",
                "detail": f"付款台账订单 {header} 与合同订单 {contract_key} 不一致，"
                          "不跨订单计算",
                "evidence": evidence}
    posted_total = ledger["posted_total"]
    unpaid = total - posted_total
    return {"ok": True, "total": total, "posted_total": posted_total,
            "unpaid": unpaid, "ledger": ledger, "evidence": evidence,
            "contract_key": contract_key, "ledger_key": header}


def _calc_unpaid_balance_cap(spec, docs):
    """R01：合同总额 − posted 已付款 ≤ 补充协议未付余额上限（cancelled 不计）。"""
    calc = "unpaid_balance_cap"
    cap_files = spec.get("cap_files") or ["02_amendment.txt"]
    base = _proj_cash_base(spec, docs, spec.get("ledger_files")
                           or ["03_payment.txt"])
    if not base.get("ok"):
        return _proj_insufficient(calc, base.get("detail") or "关键原始事实缺失",
                                  {"total_label": spec.get("total_label"),
                                   "cap_label": spec.get("cap_label")},
                                  base.get("evidence"))
    cap, reason, cap_pairs = _proj_single_value(
        docs, spec.get("cap_label") or "未付余额上限", cap_files, parse=_proj_num)
    evidence = list(base["evidence"]) + [_proj_evidence(h) for _v, h in cap_pairs]
    if cap is None:
        if reason == "missing":
            return _proj_insufficient(calc, "缺少可核验的未付余额上限（补充协议）",
                                      {"cap_files": cap_files}, evidence)
        return _proj_insufficient(calc, "未付余额上限取值不可解析或多处冲突",
                                  {"cap_files": cap_files}, evidence)
    cap_hit = cap_pairs[0][1]
    quote = cap_hit["line"].strip()
    inputs = {"total": _proj_fmt(base["total"]),
              "posted_total": _proj_fmt(base["posted_total"]),
              "unpaid": _proj_fmt(base["unpaid"]),
              "cap": _proj_fmt(cap),
              "cancelled_rows": [r["row_id"] for r in base["ledger"]["cancelled"]]}
    result = {"unpaid": _proj_fmt(base["unpaid"]), "cap": _proj_fmt(cap)}
    if base["unpaid"] <= cap:
        detail = (f"合同总额 {_proj_fmt(base['total'])} − posted 已付款 "
                  f"{_proj_fmt(base['posted_total'])} = 未付余额 "
                  f"{_proj_fmt(base['unpaid'])} ≤ 上限 {_proj_fmt(cap)}"
                  "（cancelled 不计）")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"合同总额 {_proj_fmt(base['total'])} − posted 已付款 "
              f"{_proj_fmt(base['posted_total'])} = 未付余额 "
              f"{_proj_fmt(base['unpaid'])} > 上限 {_proj_fmt(cap)}"
              f"（超出 {_proj_fmt(base['unpaid'] - cap)}，cancelled 不计）")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_segmented_fee_cap(spec, docs):
    """R03：未付余额按分段费率累计（前 30 日 0.03%/日，第 31 日起 0.08%/日），
    不复利，最终分四舍五入；累计费用 ≤ 未付余额 5% 封顶。"""
    calc = "segmented_fee_cap"
    base = _proj_cash_base(spec, docs, spec.get("ledger_files")
                           or ["03_payment.txt"])
    if not base.get("ok"):
        return _proj_insufficient(calc, base.get("detail") or "计费基数不可核验",
                                  {"base": "unpaid_balance"},
                                  base.get("evidence"))
    days, reason, day_pairs = _proj_single_value(
        docs, spec.get("days_label") or "计费天数",
        spec.get("days_files") or ["02_amendment.txt"],
        parse=lambda raw: int(raw) if re.match(r"^\d+$", raw or "") else None)
    evidence = list(base["evidence"]) + [_proj_evidence(h) for _v, h in day_pairs]
    if days is None:
        return _proj_insufficient(calc, "缺少可核验的计费天数",
                                  {"days_files": spec.get("days_files")}, evidence)
    first_days = int(spec.get("first_days") or 30)
    first_rate = Decimal(str(spec.get("first_rate") or "0.0003"))
    rest_rate = Decimal(str(spec.get("rest_rate") or "0.0008"))
    cap_rate = Decimal(str(spec.get("cap_rate") or "0.05"))
    cap_label = spec.get("cap_rule_label") or "累计费用上限"
    cap_values = _proj_label_hit(docs, cap_label,
                                 spec.get("cap_rule_files") or ["02_amendment.txt"])
    evidence += [_proj_evidence(h) for _raw, h in cap_values]
    first_part = min(days, first_days)
    rest_part = max(days - first_days, 0)
    unpaid = base["unpaid"]
    fee_raw = (unpaid * first_rate * first_part
               + unpaid * rest_rate * rest_part)
    fee = _proj_money(fee_raw)
    cap_raw = unpaid * cap_rate
    cap = _proj_money(cap_raw)
    inputs = {"unpaid": _proj_fmt(unpaid), "days": days,
              "first_days": first_part, "rest_days": rest_part,
              "first_rate": str(first_rate), "rest_rate": str(rest_rate),
              "fee": _proj_fmt(fee), "cap": _proj_fmt(cap)}
    result = {"fee": _proj_fmt(fee), "cap": _proj_fmt(cap)}
    quote = (cap_values[0][1]["line"].strip() if cap_values
             else (day_pairs[0][1]["line"].strip() if day_pairs else ""))
    if fee <= cap_raw:
        detail = (f"未付余额 {_proj_fmt(unpaid)} ×({first_part}×{first_rate}"
                  f"+{rest_part}×{rest_rate})={_proj_fmt(fee)} ≤ 封顶 "
                  f"{_proj_fmt(cap)}（{_proj_fmt(unpaid)}×{cap_rate}，不复利）")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"未付余额 {_proj_fmt(unpaid)} ×({first_part}×{first_rate}"
              f"+{rest_part}×{rest_rate})={_proj_fmt(fee)} > 封顶 "
              f"{_proj_fmt(cap)}（{_proj_fmt(unpaid)}×{cap_rate}，不复利）")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_utc_deadline(spec, docs):
    """R04：实际签收时刻 ≤ 补充协议签收截止（UTC 绝对时刻比较，等于允许）。"""
    calc = "utc_deadline"
    deadline_raw, reason, dl_pairs = _proj_single_value(
        docs, spec.get("deadline_label") or "签收截止",
        spec.get("deadline_files") or ["02_amendment.txt"])
    evidence = [_proj_evidence(h) for _v, h in dl_pairs]
    if deadline_raw is None:
        return _proj_insufficient(calc, "缺少可核验的签收截止时点", {}, evidence)
    deadline, d_reason = _proj_dt(deadline_raw)
    if deadline is None:
        return _proj_insufficient(
            calc, "签收截止时点" + ("缺少时区，不能按 UTC 比较"
                                    if d_reason == "tz_missing" else "不可解析"),
            {"deadline_raw": str(deadline_raw)}, evidence)
    received_raw, r_reason, rc_pairs = _proj_single_value(
        docs, spec.get("received_label") or "签收时点",
        spec.get("received_files") or ["04_execution.txt"])
    evidence += [_proj_evidence(h) for _v, h in rc_pairs]
    if received_raw is None:
        return _proj_insufficient(calc, "缺少可核验的实际签收时点", {}, evidence)
    received, rv_reason = _proj_dt(received_raw)
    if received is None:
        return _proj_insufficient(
            calc, "签收时点" + ("未注明时区，不可由其他文件推定，不能按 UTC 比较"
                                if rv_reason == "tz_missing" else "不可解析"),
            {"received_raw": str(received_raw)}, evidence)
    quote = (rc_pairs[0][1]["line"].strip() if rc_pairs else "")
    inputs = {"received_utc": received.isoformat(), "deadline_utc": deadline.isoformat()}
    result = {"received_utc": received.isoformat(), "deadline_utc": deadline.isoformat()}
    if received <= deadline:
        detail = (f"签收 {received.isoformat()} ≤ 截止 {deadline.isoformat()}（UTC，等于允许）")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"签收 {received.isoformat()} > 截止 {deadline.isoformat()}（UTC，晚 "
              f"{(received - deadline).total_seconds():.0f} 秒）")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_license_expiry_date(spec, docs):
    """R06：供应商许可证有效截止日期 ≥ 参考日期（按日期包含当日；不可读不猜）。"""
    calc = "license_expiry_date"
    expiry_raw, reason, ex_pairs = _proj_single_value(
        docs, spec.get("expiry_label") or "许可证有效截止日期",
        spec.get("expiry_files") or ["06_vendor_mail.txt"])
    evidence = [_proj_evidence(h) for _v, h in ex_pairs]
    unreadable = _proj_hits(docs, r"许可证[^\n]*(?:不可读|无法识别|不可辨认|缺失)",
                            spec.get("expiry_files") or None)
    if expiry_raw is None:
        if unreadable:
            return _proj_result(
                "证据不足",
                "许可证扫描区域不可读，不能推定有效截止日，转人工核验",
                [_proj_sub("S1", "insufficient",
                           "许可证扫描区域不可读，不能推定有效截止日", "", calc,
                           evidence + [_proj_evidence(h) for h in unreadable])],
                calc, evidence + [_proj_evidence(h) for h in unreadable])
        return _proj_insufficient(calc, "缺少可核验的许可证有效截止日期", {}, evidence)
    expiry = _proj_date(expiry_raw)
    if expiry is None:
        return _proj_insufficient(calc, "许可证有效截止日期不可解析", {}, evidence)
    ref_raw, _r, ref_pairs = _proj_single_value(
        docs, spec.get("reference_label") or "参考日期",
        spec.get("reference_files") or ["02_amendment.txt"])
    evidence += [_proj_evidence(h) for _v, h in ref_pairs]
    reference = _proj_date(ref_raw)
    if reference is None:
        return _proj_insufficient(calc, "缺少可核验的参考日期", {}, evidence)
    quote = (ex_pairs[0][1]["line"].strip() if ex_pairs else "")
    inputs = {"expiry": expiry.isoformat(), "reference_date": reference.isoformat()}
    result = dict(inputs)
    if expiry >= reference:
        detail = (f"许可证有效截止 {expiry.isoformat()} ≥ 参考日期 "
                  f"{reference.isoformat()}（含当日）")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"许可证有效截止 {expiry.isoformat()} < 参考日期 "
              f"{reference.isoformat()}（到期早于参考日）")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_ledger_reconcile(spec, docs):
    """R08：汇总表已付款必须精确等于同订单付款台账 posted 金额之和。"""
    calc = "ledger_reconcile"
    ledger_files = spec.get("ledger_files") or ["03_payment.txt"]
    ledger = _proj_ledger(spec, docs, ledger_files)
    evidence = list(ledger.get("evidence") or [])
    if not ledger.get("ok"):
        return _proj_insufficient(calc, ledger.get("detail") or "付款台账不可核验",
                                  {}, evidence)
    summary, reason, sum_pairs = _proj_single_value(
        docs, spec.get("summary_label") or "汇总已付款",
        spec.get("summary_files") or ledger_files, parse=_proj_num)
    evidence += [_proj_evidence(h) for _v, h in sum_pairs]
    if summary is None:
        return _proj_insufficient(calc, "缺少可核验的汇总已付款金额", {}, evidence)
    posted_total = ledger["posted_total"]
    quote = (sum_pairs[0][1]["line"].strip() if sum_pairs else "")
    inputs = {"summary": _proj_fmt(summary), "posted_total": _proj_fmt(posted_total),
              "posted_rows": [r["row_id"] for r in ledger["posted"]],
              "cancelled_rows": [r["row_id"] for r in ledger["cancelled"]]}
    result = {"differences": _proj_fmt(summary - posted_total)}
    if summary == posted_total:
        detail = (f"汇总已付款 {_proj_fmt(summary)} = posted 台账合计 "
                  f"{_proj_fmt(posted_total)}（cancelled 不计）")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"汇总已付款 {_proj_fmt(summary)} ≠ posted 台账合计 "
              f"{_proj_fmt(posted_total)}（差 {_proj_fmt(summary - posted_total)}，"
              "cancelled 不计）")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_batch_temperature_exception(spec, docs):
    """R05：当前每个批次全部实测值 ≥85℃；仅明确获批的同批次豁免允许降为 ≥80℃。

    豁免只在「approved + 明确列名当前批次」时生效；历史批次/其他批次/不适用声明
    不得套用。每个违规批次是独立 occurrence（instance_count=违规批次数）。
    """
    calc = "batch_temperature_exception"
    temp_files = spec.get("temp_files") or ["04_execution.txt"]
    base_min = Decimal(str(spec.get("min_value") or "85"))
    ex_files = spec.get("exception_files") or ["05_approvals.txt"]
    marker = spec.get("exception_marker") or "温度豁免"
    approved_marker = str(spec.get("exception_approved_marker") or "approved")
    pattern = (r"批次[ \t]*([A-Za-z0-9\-_]+)[^\n]*?"
               r"实测中心温度[ \t]*[:：][ \t]*(-?\d+(?:\.\d+)?)[ \t]*(℃|°C|℉|°F)")
    hits = _proj_hits(docs, pattern, temp_files)
    if not hits:
        return _proj_insufficient(calc, "未找到当前批次的实测中心温度", {},
                                  [])
    batches = []
    for h in hits:
        batch_id = str(h["match"].group(1)).strip()
        raw = Decimal(h["match"].group(2))
        unit = h["match"].group(3)
        celsius = _temp_to_c(float(raw), unit)
        if celsius is None:
            return _proj_insufficient(calc, f"批次 {batch_id} 实测温度不可换算", {},
                                      [_proj_evidence(h)])
        celsius = Decimal(str(celsius)).quantize(Decimal("0.0001"))
        entry = next((b for b in batches if b["batch_id"] == batch_id), None)
        if entry is None:
            entry = {"batch_id": batch_id, "values": [], "lines": []}
            batches.append(entry)
        entry["values"].append((celsius, raw, unit))
        entry["lines"].append(h)
    exceptions = []
    for h in _proj_hits(docs, re.escape(marker) + r"[^\n]*", ex_files):
        line = h["line"]
        if approved_marker and approved_marker not in line.lower():
            continue
        m_min = re.search(r"最低[ \t]*(\d+(?:\.\d+)?)[ \t]*(℃|°C|℉|°F)?", line)
        if not m_min:
            continue
        e_min = Decimal(m_min.group(1))
        if (m_min.group(2) or "℃") in ("℉", "°F"):
            conv = _temp_to_c(float(e_min), m_min.group(2))
            e_min = Decimal(str(conv if conv is not None else e_min))
        named = [b["batch_id"] for b in batches if b["batch_id"] in line]
        exceptions.append({"file": h["file"], "line_no": h["line_no"],
                           "line": line, "min": e_min, "batches": named,
                           "hit": h})
    evidence = [_proj_evidence(h) for h in hits]
    # 豁免声明行作为检查证据保留（含不适用/历史批次声明，说明为何未放宽阈值）；
    # 判定只采信 approved 且明确列名当前批次的豁免。
    for d in _proj_files(docs, ex_files):
        for _i, _line in enumerate(d["lines"], 1):
            if marker and marker in _line:
                evidence.append({"file": d["filename"], "line": _i,
                                 "quote": _line.strip()})
    evidence += [_proj_evidence(e["hit"]) for e in exceptions]
    failures, passed_batches = [], []
    thresholds = {}
    for b in batches:
        exception = next((e for e in exceptions
                          if b["batch_id"] in (e.get("batches") or [])), None)
        threshold = base_min
        if exception and exception["min"] < base_min:
            threshold = exception["min"]
        thresholds[b["batch_id"]] = _proj_fmt(threshold)
        bad_values = [(c, raw, unit, h) for (c, raw, unit), h in
                      zip(b["values"], b["lines"]) if c < threshold]
        if bad_values:
            failures.append((b, threshold, bad_values))
        else:
            passed_batches.append(b)
    inputs = {"base_min": _proj_fmt(base_min),
              "thresholds": thresholds,
              "batches": {b["batch_id"]: [_proj_fmt(c) for c, _r, _u in b["values"]]
                          for b in batches},
              "exceptions": [{"line": e["line"], "min": _proj_fmt(e["min"]),
                              "batches": e["batches"]} for e in exceptions]}
    if not failures:
        first = batches[0]["lines"][0]
        detail = "、".join(
            f"批次{b['batch_id']} 最低 {_proj_fmt(min(c for c, _r, _u in b['values']))}℃ "
            f"≥ 要求 {_proj_fmt(thresholds[b['batch_id']])}℃"
            for b in batches)
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail,
                                       first["line"].strip(), calc,
                                       evidence, inputs)],
                            calc, evidence, inputs)
    subs, details = [], []
    for idx, (batch, threshold, bad_values) in enumerate(failures, 1):
        first_bad = bad_values[0]
        detail = (f"批次{batch['batch_id']} 实测中心温度 "
                  f"{_proj_fmt(first_bad[0])}℃ 不满足 ≥ {_proj_fmt(threshold)}℃"
                  + ("（同批次获批豁免未覆盖该批次）"
                     if threshold == base_min else "（低于同批次获批豁免最低值）"))
        details.append(detail)
        subs.append(_proj_sub(f"S1#{idx}", "fail", detail,
                              first_bad[3]["line"].strip(), calc,
                              evidence, inputs))
    detail = "；".join(details)
    return _proj_result("不满足", detail, subs, calc, evidence, inputs)


# ---------------------------------------------------------------------------
# 项目级确定性执行器（多文件结构化业务计算：库存 / 发票 / 交付 / 证书）
#
# 与上一组计算同契约（五态 + 子要求 + tool_trace），输入是「同项目多文件」的
# 结构化行：``k1=v1;k2=v2;...``，或首段为行标记（如 ``opening;warehouse=W1;...``）。
# 文件角色（task / inventory / movements / packaging / commercial / acceptance /
# schedule / calendar / deliveries / certificates）与字段名由槽位声明，执行期不猜
# 模糊指代；默认字段名即多文件审核项目的通用字段约定，可按部署覆盖。
#
# 计算口径（slots["project_compute"]["calculation"]）：
#   - inventory_snapshot：仓库 W1 / SKU1 截至截止时刻的实物件数 =
#     期初件数 + posted 收货 - posted 发货（effective_at 等于截止计入，晚 1 秒不计）；
#     箱→件按该事件 effective_at 时生效的包装版本换算（仅换算箱数量，不再乘系数）；
#     调拨只在源仓计出库，目的仓收货不影响源仓；pending 不计；相同 event_id 的
#     完全相同重放只计一次；同 event_id 内容不同 → 证据不足不猜。
#   - invoice_payable：本订单在发票签发时点（含等号）已 accepted 的数量（按
#     acceptance_id 去重；received/rejected 不计），× 未税单价 ×(1-折扣率)×(1+税率)，
#     总额按分 ROUND_HALF_UP，再减本发票专属 approved 含税贷项（草稿/其他发票不计）；
#     与发票申报含税额容差 0。
#   - delivery_deadline：签收本地时刻 ≤15:00 当日为有效接单日，>15:00 顺延至下一
#     工作日；有效接单日之后第 2 个工作日 17:00 为基础期限（工作日只按日历）；
#     延期仅当本订单 approved 且 approved_at 不晚于基础期限才有效（事后批准不追溯），
#     按 extend_workdays 个工作日顺延、仍在 17:00 截止；到达恰好截止为按时，晚 1 秒
#     即逾期；两个交付分别计实例。有效延期多于一份 → 证据不足（本批至多一份）。
#   - certificate_validity：证书须精确匹配制造商与产品、status=approved、
#     approved_at ≤ 生产时刻、valid_from ≤ 生产 < valid_to，且生产时刻前未撤销；
#     未来批准即使 valid_from 回填也不可追溯；贸易商证书不能替代制造商证书；
#     每个交付分别计实例，值输出生产时应引用的唯一有效证书。
# 字段缺失 / 取值冲突 / 包装版本或日历缺口 / 有效证书不唯一 → 证据不足，不猜。
# ---------------------------------------------------------------------------
_STRUCT_EXCLUDE = ("archive_id=", "历史归档", "ARCHIVE-")
_PIECE_UNITS = ("piece", "pieces", "件", "个")
_BOX_UNITS = ("box", "boxes", "箱")
_STRUCT_TIME_FIELDS = ("at", "effective_at", "issued_at", "approved_at", "valid_from",
                       "valid_to", "revoked_at", "customer_received_at", "arrived_at",
                       "produced_at")


def _struct_records(docs, files, spec=None):
    """项目文档文本 → 结构化 k=v 记录（保留文件/原始行号/逐字原文）。"""
    spec = spec or {}
    markers = tuple(str(m) for m in (spec.get("struct_exclude_markers")
                                     or spec.get("exclude_markers") or _STRUCT_EXCLUDE)
                    if str(m))
    out = []
    for d in _proj_files(docs, files):
        for i, line in d["clean"]:
            raw = str(line).strip()
            if not raw or any(m in raw for m in markers):
                continue
            rec = {"_file": d["filename"], "_line": i, "_text": raw}
            for idx, part in enumerate(raw.split(";")):
                part = part.strip()
                if not part:
                    continue
                if "=" in part:
                    k, v = part.split("=", 1)
                    if k.strip():
                        rec[k.strip()] = v.strip()
                elif idx == 0:
                    rec["_flag"] = part
            if len(rec) == 3:
                continue
            out.append(rec)
    return out


def _struct_evidence(records):
    seen, out = set(), []
    for r in records or []:
        key = (str(r.get("_file") or ""), int(r.get("_line") or 0))
        if not key[0] or key[1] <= 0 or key in seen:
            continue
        seen.add(key)
        out.append({"file": key[0], "line": key[1],
                    "quote": str(r.get("_text") or "")})
    return out


def _struct_context(records):
    """结构化记录 → 合并字段上下文；同名字段不同取值记为冲突（不猜）。"""
    ctx, conflicts = {}, set()
    for r in records or []:
        for k, v in r.items():
            if str(k).startswith("_"):
                continue
            v = str(v).strip()
            if k in ctx and ctx[k] != v:
                conflicts.add(k)
            else:
                ctx.setdefault(k, v)
    return ctx, conflicts


def _struct_task_evidence(records, fields):
    return [r for r in records or [] if any(str(f) in r for f in fields)]


def _struct_local_dt(raw):
    """本地时刻 → aware datetime（保留原时区偏移）；无时区/不可解析返回原因，不猜。"""
    s = str(raw if raw is not None else "").strip()
    if not s:
        return None, "missing"
    try:
        value = _dt.datetime.fromisoformat(s.replace("Z", "+00:00")
                                           .replace("z", "+00:00"))
    except Exception:
        return None, "unparsable"
    if value.tzinfo is None:
        return None, "tz_missing"
    return value, ""


def _struct_num(rec, field):
    return _proj_num((rec or {}).get(field))


def _struct_box_pieces(pkg_records, record_sku_field, sku, at_utc, spec):
    """事件时刻生效的包装版本 → 每箱件数；缺版本/版本冲突/箱规不可解析返回原因。"""
    valid_from_field = spec.get("valid_from_field") or "valid_from"
    valid_to_field = spec.get("valid_to_field") or "valid_to"
    ppb_field = spec.get("pieces_per_box_field") or "pieces_per_box"
    valid = []
    for p in pkg_records or []:
        if str(p.get(record_sku_field) or "") != str(sku):
            continue
        vf_raw, vt_raw = p.get(valid_from_field), p.get(valid_to_field)
        if not vf_raw or not vt_raw:
            continue
        vf, why1 = _proj_dt(vf_raw)
        vt, why2 = _proj_dt(vt_raw)
        if vf is None or vt is None:
            return None, "包装版本日期不可解析或无时区"
        if vf <= at_utc < vt:
            valid.append(p)
    if not valid:
        return None, "该事件时刻没有生效的包装版本"
    if len(valid) > 1:
        return None, "该事件时刻存在多个生效包装版本"
    ppb = _proj_num(valid[0].get(ppb_field))
    if ppb is None or ppb <= 0:
        return None, "包装箱规不可解析"
    return ppb, ""


def _struct_working_map(records, spec):
    """日历记录 → {date: working}；日期/工作日值不可解析或同日冲突返回原因。"""
    date_field = spec.get("calendar_date_field") or "date"
    working_field = spec.get("calendar_working_field") or "working"
    out, conflicts = {}, set()
    for r in records or []:
        d = _proj_date(r.get(date_field))
        if d is None:
            return None, "日历日期不可解析"
        w = str(r.get(working_field) or "").strip().lower()
        if w in ("true", "1", "yes", "y", "是", "工作日"):
            val = True
        elif w in ("false", "0", "no", "n", "否", "休息日", "非工作日"):
            val = False
        else:
            return None, f"日历 {d.isoformat()} 的 working 值无法识别"
        if d in out and out[d] != val:
            conflicts.add(d)
        out[d] = val
    if conflicts:
        return None, "日历存在同日 working 冲突"
    return out, ""


def _struct_next_workday(cal, start, count):
    """start 之后第 count 个工作日（不含 start）；日历缺日期返回原因。"""
    day, found = start, 0
    while found < count:
        day = day + _dt.timedelta(days=1)
        if day not in cal:
            return None, f"日历缺少 {day.isoformat()}"
        if cal[day]:
            found += 1
    return day, ""


def _struct_scope(records, warehouse, sku, wh_field, sku_field):
    return [r for r in records or []
            if str(r.get(wh_field) or "") == warehouse
            and str(r.get(sku_field) or "") == sku]


def _struct_deadline_at(day, hour, minute, tzinfo):
    return _dt.datetime.combine(day, _dt.time(hour, minute)).replace(tzinfo=tzinfo)


def _calc_inventory_snapshot(spec, docs):
    """库存快照：仓库/SKU 截至截止时刻的实物件数（事件账本幂等 + 箱→件版本换算）。"""
    calc = "inventory_snapshot"
    task_files = spec.get("task_files") or ["task.txt"]
    inv_files = spec.get("inventory_files") or ["inventory.txt"]
    mv_files = spec.get("movement_files") or ["movements.txt"]
    pkg_files = spec.get("packaging_files") or ["packaging.txt"]
    wh_field = spec.get("warehouse_field") or "stock_warehouse"
    sku_field = spec.get("sku_field") or "stock_sku"
    r_wh = spec.get("record_warehouse_field") or "warehouse"
    r_sku = spec.get("record_sku_field") or "sku"
    opening_flag = str(spec.get("opening_flag") or "opening")
    snapshot_flag = str(spec.get("snapshot_flag") or "snapshot")
    deadline_field = spec.get("deadline_field") or "at"
    event_field = spec.get("event_id_field") or "event_id"
    kind_field = spec.get("kind_field") or "kind"
    status_field = spec.get("status_field") or "status"
    qty_field = spec.get("quantity_field") or "quantity"
    unit_field = spec.get("unit_field") or "unit"
    eff_field = spec.get("effective_at_field") or "effective_at"
    posted = str(spec.get("posted_status") or "posted")
    ignored_statuses = tuple(str(x) for x in (spec.get("ignored_statuses")
                                              or ("pending", "draft", "cancelled")))
    receive_kinds = tuple(str(x) for x in (spec.get("receive_kinds")
                                           or ("receive", "receipt", "收货", "调入")))
    ship_kinds = tuple(str(x) for x in (spec.get("ship_kinds")
                                        or ("ship", "issue", "发货", "调出")))
    piece_units = tuple(str(x) for x in (spec.get("piece_units") or _PIECE_UNITS))
    box_units = tuple(str(x) for x in (spec.get("box_units") or _BOX_UNITS))

    task_recs = _struct_records(docs, task_files, spec)
    ctx, conflicts = _struct_context(task_recs)
    evidence = _struct_evidence(_struct_task_evidence(task_recs, (wh_field, sku_field)))
    if conflicts & {wh_field, sku_field}:
        return _proj_insufficient(calc, "任务声明的仓库/SKU 冲突，无法确定核对对象",
                                  {}, evidence)
    wh = str(ctx.get(wh_field) or "").strip()
    sku = str(ctx.get(sku_field) or "").strip()
    if not wh or not sku:
        return _proj_insufficient(calc, "缺少仓库/SKU 核对对象声明", {}, evidence)

    inv = _struct_records(docs, inv_files, spec)
    evidence += _struct_evidence(inv)
    scoped = _struct_scope(inv, wh, sku, r_wh, r_sku)
    openings = [r for r in scoped if r.get("_flag") == opening_flag]
    snaps = [r for r in scoped if r.get("_flag") == snapshot_flag]
    if len(snaps) != 1:
        return _proj_insufficient(calc,
                                  f"截止快照缺失或冲突（{len(snaps)} 条），无法核对",
                                  {}, evidence)
    if not openings:
        return _proj_insufficient(calc, f"缺少 {wh}/{sku} 期初库存记录", {}, evidence)
    opening_total = Decimal("0")
    for r in openings:
        unit = str(r.get(unit_field) or "").strip()
        n = _struct_num(r, qty_field)
        if n is None:
            return _proj_insufficient(calc, "期初数量不可解析", {}, evidence)
        if unit in box_units:
            return _proj_insufficient(calc, "期初单位是箱；规则要求期初以件计，不换算猜测",
                                      {}, evidence)
        if unit not in piece_units:
            return _proj_insufficient(calc, f"期初单位无法识别：{unit or '空'}", {}, evidence)
        opening_total += n
    snap = snaps[0]
    deadline, why = _proj_dt(snap.get(deadline_field))
    if deadline is None:
        return _proj_insufficient(calc, f"截止时刻不可解析（{why}），不猜时点", {}, evidence)
    snap_qty = _struct_num(snap, qty_field)
    if snap_qty is None:
        return _proj_insufficient(calc, "快照数量不可解析", {}, evidence)
    snap_unit = str(snap.get(unit_field) or "").strip()
    pkg = _struct_records(docs, pkg_files, spec)
    evidence += _struct_evidence(pkg)
    if snap_unit in box_units:
        ppb, why = _struct_box_pieces(pkg, r_sku, sku, deadline, spec)
        if ppb is None:
            return _proj_insufficient(calc, f"快照为箱且{why}", {}, evidence)
        snap_qty = snap_qty * ppb
    elif snap_unit not in piece_units:
        return _proj_insufficient(calc, f"快照单位无法识别：{snap_unit or '空'}", {}, evidence)

    mv_all = _struct_records(docs, mv_files, spec)
    evidence += _struct_evidence(mv_all)
    scoped_mv = _struct_scope(mv_all, wh, sku, r_wh, r_sku)
    by_event = {}
    for r in scoped_mv:
        eid = str(r.get(event_field) or "").strip()
        if not eid:
            return _proj_insufficient(calc, "库存事件缺少 event_id，无法做重放幂等",
                                      {}, evidence)
        key = tuple(sorted((k, str(v)) for k, v in r.items()
                           if not str(k).startswith("_")))
        by_event.setdefault(eid, []).append((key, r))
    for eid, rows in by_event.items():
        if len({k for k, _r in rows}) > 1:
            return _proj_insufficient(
                calc, f"event_id {eid} 存在内容不同的记录，无法按重放幂等处理",
                {"duplicate_event_ids": sorted(by_event)}, evidence)
    unique_events = [rows[0][1] for rows in by_event.values()]

    qty = opening_total
    applied = []
    for r in unique_events:
        status = str(r.get(status_field) or "").strip()
        if status in ignored_statuses:
            continue
        if status != posted:
            return _proj_insufficient(calc, f"事件状态未定义：{status or '空'}", {}, evidence)
        eff, why = _proj_dt(r.get(eff_field))
        if eff is None:
            return _proj_insufficient(calc, f"事件生效时刻不可解析（{why}）", {}, evidence)
        if eff > deadline:
            continue
        n = _struct_num(r, qty_field)
        if n is None:
            return _proj_insufficient(calc, "事件数量不可解析", {}, evidence)
        unit = str(r.get(unit_field) or "").strip()
        if unit in piece_units:
            amount = n
        elif unit in box_units:
            ppb, why = _struct_box_pieces(pkg, r_sku, sku, eff, spec)
            if ppb is None:
                return _proj_insufficient(calc, f"箱事件换算失败：{why}", {}, evidence)
            amount = n * ppb
        else:
            return _proj_insufficient(calc, f"事件单位无法识别：{unit or '空'}", {}, evidence)
        kind = str(r.get(kind_field) or "").strip()
        if kind in receive_kinds:
            qty += amount
        elif kind in ship_kinds:
            qty -= amount
        else:
            return _proj_insufficient(calc, f"事件类型无法识别：{kind or '空'}", {}, evidence)
        applied.append(r)

    value = _proj_fmt(qty)
    inputs = {"warehouse": wh, "sku": sku,
              "deadline": deadline.isoformat(),
              "opening_pieces": _proj_fmt(opening_total),
              "events_applied": len(applied),
              "events_total": len(unique_events),
              "snapshot_reported": _proj_fmt(snap_qty)}
    result = {"value": value, "computed_pieces": value,
              "reported_pieces": _proj_fmt(snap_qty)}
    quote = str(snap.get("_text") or "")
    deadline_text = str(snap.get(deadline_field) or deadline.isoformat())
    if snap_qty == qty:
        detail = (f"{wh}/{sku} 截至 {deadline_text} 实物件数 {value}"
                  f"（期初 {_proj_fmt(opening_total)}，计入事件 {len(applied)} 条），"
                  f"与快照申报 {_proj_fmt(snap_qty)} 一致")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"{wh}/{sku} 截至 {deadline_text} 应为 {value} 件"
              f"（期初 {_proj_fmt(opening_total)}，计入事件 {len(applied)} 条），"
              f"快照申报 {_proj_fmt(snap_qty)}，不一致"
              f"（差 {_proj_fmt(snap_qty - qty)}）")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_invoice_payable(spec, docs):
    """发票允许额：合格验收数量 × 未税单价 ×(1-折扣)×(1+税率) - 专属已批准含税贷项。"""
    calc = "invoice_payable"
    task_files = spec.get("task_files") or ["task.txt"]
    comm_files = spec.get("commercial_files") or ["commercial.txt"]
    acc_files = spec.get("acceptance_files") or ["acceptance.txt"]
    order_field = spec.get("order_field") or "order"
    invoice_field = spec.get("invoice_field") or "invoice"
    task_order_field = spec.get("task_order_field") or "project_order"
    task_invoice_field = spec.get("task_invoice_field") or "invoice"
    credit_id_field = spec.get("credit_id_field") or "credit_id"
    status_field = spec.get("status_field") or "status"
    accepted_value = str(spec.get("accepted_status") or "accepted")
    ignored_acc_statuses = tuple(str(x) for x in (spec.get("ignored_acceptance_statuses")
                                                  or ("received", "rejected", "draft")))
    issued_field = spec.get("issued_at_field") or "issued_at"
    claimed_field = spec.get("claimed_gross_field") or "claimed_gross"
    price_field = spec.get("unit_price_field") or "unit_price_ex_tax"
    discount_field = spec.get("discount_field") or "discount_rate"
    tax_field = spec.get("tax_field") or "tax_rate"
    credit_gross_field = spec.get("credit_gross_field") or "gross_credit"
    approved_value = str(spec.get("credit_approved_status") or "approved")
    acc_id_field = spec.get("acceptance_id_field") or "acceptance_id"
    acc_qty_field = spec.get("acceptance_quantity_field") or "quantity"
    acc_at_field = spec.get("acceptance_at_field") or "at"

    task_recs = _struct_records(docs, task_files, spec)
    ctx, conflicts = _struct_context(task_recs)
    evidence = _struct_evidence(
        _struct_task_evidence(task_recs, (task_order_field, task_invoice_field)))
    if conflicts & {task_order_field, task_invoice_field}:
        return _proj_insufficient(calc, "任务声明的订单/发票冲突，无法确定核对对象",
                                  {}, evidence)
    order = str(ctx.get(task_order_field) or "").strip()
    invoice = str(ctx.get(task_invoice_field) or "").strip()
    if not order or not invoice:
        return _proj_insufficient(calc, "缺少本订单/本发票声明", {}, evidence)

    comm = _struct_records(docs, comm_files, spec)
    evidence += _struct_evidence(comm)
    terms = [r for r in comm if str(r.get(order_field) or "") == order
             and r.get(price_field) is not None]
    invoices = [r for r in comm if str(r.get(invoice_field) or "") == invoice
                and r.get(issued_field) is not None]
    if len(terms) != 1:
        return _proj_insufficient(calc, f"本订单价格条款缺失或冲突（{len(terms)} 条）",
                                  {}, evidence)
    if len(invoices) != 1:
        return _proj_insufficient(calc, f"本发票记录缺失或冲突（{len(invoices)} 条）",
                                  {}, evidence)
    term, inv = terms[0], invoices[0]
    if inv.get(order_field) is not None and str(inv.get(order_field)) != order:
        return _proj_insufficient(calc, "发票所属订单与项目订单不一致", {}, evidence)
    issued, why = _proj_dt(inv.get(issued_field))
    if issued is None:
        return _proj_insufficient(calc, f"发票签发时点不可解析（{why}）", {}, evidence)
    price = _proj_num(term.get(price_field))
    discount = _proj_num(term.get(discount_field))
    tax = _proj_num(term.get(tax_field))
    if price is None or discount is None or tax is None:
        return _proj_insufficient(calc, "合同单价/折扣率/税率不可解析", {}, evidence)
    claimed = _proj_num(inv.get(claimed_field))
    if claimed is None:
        return _proj_insufficient(calc, "发票申报含税金额不可解析", {}, evidence)

    acc = _struct_records(docs, acc_files, spec)
    evidence += _struct_evidence(acc)
    acc_rows = [r for r in acc if str(r.get(order_field) or "") == order
                and r.get(acc_id_field)]
    by_id = {}
    for r in acc_rows:
        aid = str(r.get(acc_id_field) or "").strip()
        key = tuple(sorted((k, str(v)) for k, v in r.items()
                           if not str(k).startswith("_")))
        by_id.setdefault(aid, []).append((key, r))
    qty = Decimal("0")
    for aid, rows in by_id.items():
        if len({k for k, _r in rows}) > 1:
            return _proj_insufficient(
                calc, f"验收 {aid} 重放内容不一致，无法按 acceptance_id 去重",
                {"duplicate_acceptance_ids": sorted(by_id)}, evidence)
        r = rows[0][1]
        status = str(r.get(status_field) or "").strip()
        if status in ignored_acc_statuses:
            continue
        if status != accepted_value:
            return _proj_insufficient(calc, f"验收状态未定义：{status or '空'}", {}, evidence)
        at, why = _proj_dt(r.get(acc_at_field))
        if at is None:
            return _proj_insufficient(calc, f"验收时点不可解析（{why}）", {}, evidence)
        if at > issued:
            continue
        n = _proj_num(r.get(acc_qty_field))
        if n is None:
            return _proj_insufficient(calc, "验收数量不可解析", {}, evidence)
        qty += n
    credit_rows = [r for r in comm if r.get(credit_id_field) is not None
                   and str(r.get(invoice_field) or "") == invoice]
    credits = Decimal("0")
    for r in credit_rows:
        status = str(r.get(status_field) or "").strip()
        if not status:
            return _proj_insufficient(calc, "贷项状态缺失，无法判断是否计入", {}, evidence)
        if status != approved_value:
            continue
        n = _proj_num(r.get(credit_gross_field))
        if n is None:
            return _proj_insufficient(calc, "已批准贷项金额不可解析", {}, evidence)
        credits += n
    gross = (qty * price * (Decimal("1") - discount) * (Decimal("1") + tax)
             ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    allowed = (gross - credits).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    value = format(allowed, "f")
    inputs = {"order": order, "invoice": invoice,
              "issued_at": issued.isoformat(),
              "accepted_quantity": _proj_fmt(qty),
              "unit_price_ex_tax": _proj_fmt(price),
              "discount_rate": _proj_fmt(discount),
              "tax_rate": _proj_fmt(tax),
              "gross_before_credit": format(gross, "f"),
              "approved_credits": _proj_fmt(credits),
              "allowed_gross": value,
              "claimed_gross": _proj_fmt(claimed)}
    result = {"value": value, "allowed_gross": value,
              "claimed_gross": _proj_fmt(claimed)}
    quote = str(inv.get("_text") or "")
    if claimed == allowed:
        detail = (f"本发票允许含税金额 {value} = 合格验收 {_proj_fmt(qty)} 件 × "
                  f"{_proj_fmt(price)} ×(1-{_proj_fmt(discount)})×(1+{_proj_fmt(tax)}) "
                  f"按分 ROUND_HALF_UP={format(gross, 'f')} - 专属已批准贷项 "
                  f"{_proj_fmt(credits)}，与申报 {_proj_fmt(claimed)} 一致")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail, quote, calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    detail = (f"本发票允许含税金额 {value}（合格验收 {_proj_fmt(qty)} 件，未税 "
              f"{_proj_fmt(price)}，折扣 {_proj_fmt(discount)}，税率 {_proj_fmt(tax)}，"
              f"含税 {format(gross, 'f')}，减专属已批准贷项 {_proj_fmt(credits)}），"
              f"申报 {_proj_fmt(claimed)}，差 {_proj_fmt(claimed - allowed)}")
    return _proj_result("不满足", detail,
                        [_proj_sub("S1#1", "fail", detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


def _calc_delivery_deadline(spec, docs):
    """交付期限：有效接单日 + 2 工作日 → 基础期限；仅期限前批准的延期可顺延。"""
    calc = "delivery_deadline"
    task_files = spec.get("task_files") or ["task.txt"]
    schedule_files = spec.get("schedule_files") or ["schedule.txt"]
    calendar_files = spec.get("calendar_files") or ["calendar.txt"]
    delivery_files = spec.get("delivery_files") or ["deliveries.txt"]
    order_field = spec.get("order_field") or "order"
    task_order_field = spec.get("task_order_field") or "project_order"
    received_field = spec.get("received_at_field") or "customer_received_at"
    ext_id_field = spec.get("extension_id_field") or "extension_id"
    ext_status_field = spec.get("extension_status_field") or "status"
    ext_approved_value = str(spec.get("extension_approved_status") or "approved")
    ext_approved_at_field = spec.get("extension_approved_at_field") or "approved_at"
    ext_days_field = spec.get("extend_workdays_field") or "extend_workdays"
    delivery_id_field = spec.get("delivery_id_field") or "delivery_id"
    arrived_field = spec.get("arrived_at_field") or "arrived_at"
    cutoff = str(spec.get("order_cutoff") or "15:00")
    base_days = int(spec.get("base_workdays") or 2)
    deadline_clock = str(spec.get("deadline_clock") or "17:00")
    max_extensions = int(spec.get("max_valid_extensions") or 1)

    task_recs = _struct_records(docs, task_files, spec)
    ctx, conflicts = _struct_context(task_recs)
    evidence = _struct_evidence(_struct_task_evidence(task_recs, (task_order_field,)))
    if conflicts & {task_order_field}:
        return _proj_insufficient(calc, "任务声明的订单冲突，无法确定核对对象",
                                  {}, evidence)
    order = str(ctx.get(task_order_field) or "").strip()
    if not order:
        return _proj_insufficient(calc, "缺少本订单声明", {}, evidence)

    sched = _struct_records(docs, schedule_files, spec)
    evidence += _struct_evidence(sched)
    recv_rows = [r for r in sched if str(r.get(order_field) or "") == order
                 and r.get(received_field) is not None]
    if len(recv_rows) != 1:
        return _proj_insufficient(calc, f"客户签收时刻缺失或冲突（{len(recv_rows)} 条）",
                                  {}, evidence)
    received, why = _struct_local_dt(recv_rows[0].get(received_field))
    if received is None:
        return _proj_insufficient(calc, f"签收时刻不可解析（{why}）", {}, evidence)
    try:
        cut_h, cut_m = [int(x) for x in cutoff.split(":", 1)]
        dl_h, dl_m = [int(x) for x in deadline_clock.split(":", 1)]
    except Exception:
        return _proj_insufficient(calc, "期限时钟配置不合法", {}, evidence)

    cal_recs = _struct_records(docs, calendar_files, spec)
    evidence += _struct_evidence(cal_recs)
    cal, why = _struct_working_map(cal_recs, spec)
    if cal is None:
        return _proj_insufficient(calc, f"日历不可用：{why}", {}, evidence)
    local = received.replace(tzinfo=None)
    if local.time() <= _dt.time(cut_h, cut_m):
        valid_day = local.date()
    else:
        day, why = _struct_next_workday(cal, local.date(), 1)
        if day is None:
            return _proj_insufficient(calc, f"有效接单日顺延失败：{why}", {}, evidence)
        valid_day = day
    base_day, why = _struct_next_workday(cal, valid_day, base_days)
    if base_day is None:
        return _proj_insufficient(calc, f"基础期限计算失败：{why}", {}, evidence)
    base = _struct_deadline_at(base_day, dl_h, dl_m, received.tzinfo)

    ext_rows = [r for r in sched if str(r.get(order_field) or "") == order
                and r.get(ext_id_field) is not None]
    valid_ext = []
    for r in ext_rows:
        status = str(r.get(ext_status_field) or "").strip()
        if status != ext_approved_value:
            continue
        approved_at, why = _struct_local_dt(r.get(ext_approved_at_field))
        if approved_at is None:
            return _proj_insufficient(
                calc, f"延期 {r.get(ext_id_field)} 批准时刻不可解析（{why}）", {}, evidence)
        if approved_at.astimezone(_dt.timezone.utc) <= base.astimezone(_dt.timezone.utc):
            valid_ext.append(r)
    if len(valid_ext) > max_extensions:
        return _proj_insufficient(
            calc, f"本订单存在 {len(valid_ext)} 份有效延期（本批至多 {max_extensions} 份），"
                  "无法确定唯一延期", {}, evidence)
    final = base
    ext_detail = "无有效延期"
    if valid_ext:
        ext = valid_ext[0]
        days = _proj_num(ext.get(ext_days_field))
        if days is None or days < 0 or days != days.to_integral_value():
            return _proj_insufficient(calc, "延期工作日数不可解析", {}, evidence)
        final_day, why = _struct_next_workday(cal, base_day, int(days))
        if final_day is None:
            return _proj_insufficient(calc, f"延期顺延失败：{why}", {}, evidence)
        final = _struct_deadline_at(final_day, dl_h, dl_m, received.tzinfo)
        ext_detail = (f"延期 {ext.get(ext_id_field)}（approved_at "
                      f"{ext.get(ext_approved_at_field)}，顺延 {int(days)} 个工作日）")

    dels = [r for r in _struct_records(docs, delivery_files, spec)
            if r.get(delivery_id_field)
            and (not order_field or not r.get(order_field)
                 or str(r.get(order_field)) == order)]
    evidence += _struct_evidence(_struct_records(docs, delivery_files, spec))
    if not dels:
        return _proj_insufficient(calc, "本订单没有可核对的交付记录", {}, evidence)
    final_utc = final.astimezone(_dt.timezone.utc)
    late = []
    for idx, r in enumerate(dels, 1):
        arrived, why = _struct_local_dt(r.get(arrived_field))
        if arrived is None:
            return _proj_insufficient(
                calc, f"交付 {r.get(delivery_id_field)} 到达时刻不可解析（{why}）",
                {}, evidence)
        if arrived.astimezone(_dt.timezone.utc) > final_utc:
            late.append((idx, r, arrived))
    value = final.isoformat(timespec="seconds")
    inputs = {"order": order, "received_at": received.isoformat(),
              "order_cutoff": cutoff, "deadline_clock": deadline_clock,
              "valid_order_day": valid_day.isoformat(),
              "base_days": base_days,
              "base_deadline": base.isoformat(timespec="seconds"),
              "extensions": ext_detail,
              "final_deadline": value,
              "deliveries": [r.get(delivery_id_field) for r in dels]}
    result = {"value": value, "final_deadline": value,
              "base_deadline": base.isoformat(timespec="seconds"),
              "valid_order_day": valid_day.isoformat()}
    if not late:
        detail = (f"有效接单日 {valid_day.isoformat()}，基础期限 "
                  f"{base.isoformat(timespec='seconds')}，{ext_detail}，最终截止 {value}；"
                  + "、".join(f"{r.get(delivery_id_field)} 到达 {r.get(arrived_field)} 未逾期"
                             for r in dels))
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail,
                                       str(dels[0].get("_text") or ""), calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    subs, details = [], []
    for idx, r, arrived in late:
        one = (f"{r.get(delivery_id_field)} 到达 {r.get(arrived_field)} 晚于最终截止 "
               f"{value}（逾期 {_proj_fmt((arrived - final).total_seconds())} 秒）")
        details.append(one)
        subs.append(_proj_sub(f"S1#{idx}", "fail", one,
                              str(r.get("_text") or ""), calc, evidence, inputs, result))
    detail = (f"有效接单日 {valid_day.isoformat()}，基础期限 "
              f"{base.isoformat(timespec='seconds')}，{ext_detail}，最终截止 {value}；"
              + "；".join(details))
    return _proj_result("不满足", detail, subs, calc, evidence, inputs, result)


def _calc_certificate_validity(spec, docs):
    """生产证书有效性：制造商/产品精确匹配 + approved/valid/未撤销，取唯一有效证书。"""
    calc = "certificate_validity"
    task_files = spec.get("task_files") or ["task.txt"]
    cert_files = spec.get("certificate_files") or ["certificates.txt"]
    delivery_files = spec.get("delivery_files") or ["deliveries.txt"]
    mfr_field = spec.get("manufacturer_field") or "manufacturer"
    product_field = spec.get("product_field") or "product"
    order_field = spec.get("order_field") or "order"
    task_order_field = spec.get("task_order_field") or "project_order"
    delivery_id_field = spec.get("delivery_id_field") or "delivery_id"
    produced_field = spec.get("produced_at_field") or "produced_at"
    declared_field = spec.get("declared_certificate_field") or "certificate_id"
    cert_id_field = spec.get("certificate_id_field") or "certificate_id"
    cert_status_field = spec.get("certificate_status_field") or "status"
    cert_approved_value = str(spec.get("certificate_approved_status") or "approved")
    cert_approved_at_field = spec.get("certificate_approved_at_field") or "approved_at"
    valid_from_field = spec.get("valid_from_field") or "valid_from"
    valid_to_field = spec.get("valid_to_field") or "valid_to"
    revoked_field = spec.get("revoked_at_field") or "revoked_at"

    task_recs = _struct_records(docs, task_files, spec)
    ctx, conflicts = _struct_context(task_recs)
    evidence = _struct_evidence(
        _struct_task_evidence(task_recs, (mfr_field, product_field, task_order_field)))
    if conflicts & {mfr_field, product_field, task_order_field}:
        return _proj_insufficient(calc, "任务声明的制造商/产品/订单冲突，无法确定核对对象",
                                  {}, evidence)
    mfr = str(ctx.get(mfr_field) or "").strip()
    product = str(ctx.get(product_field) or "").strip()
    order = str(ctx.get(task_order_field) or "").strip()
    if not mfr or not product:
        return _proj_insufficient(calc, "缺少制造商/产品核对对象声明", {}, evidence)

    certs = _struct_records(docs, cert_files, spec)
    evidence += _struct_evidence(certs)
    all_dels = _struct_records(docs, delivery_files, spec)
    evidence += _struct_evidence(all_dels)
    dels = [r for r in all_dels if r.get(delivery_id_field)
            and (not order_field or not r.get(order_field)
                 or str(r.get(order_field)) == order)]
    if not dels:
        return _proj_insufficient(calc, "本订单没有可核对的出货单", {}, evidence)
    bad, parts = [], []
    for idx, r in enumerate(sorted(dels, key=lambda x: str(x.get(delivery_id_field))), 1):
        d_mfr = str(r.get(mfr_field) or "").strip() or mfr
        d_product = str(r.get(product_field) or "").strip() or product
        if d_mfr != mfr or d_product != product:
            return _proj_insufficient(
                calc, f"出货单 {r.get(delivery_id_field)} 的制造商/产品与项目声明不一致，"
                      "无法确定应匹配的证书", {}, evidence)
        produced, why = _struct_local_dt(r.get(produced_field))
        if produced is None:
            return _proj_insufficient(
                calc, f"出货单 {r.get(delivery_id_field)} 生产时刻不可解析（{why}）",
                {}, evidence)
        candidates = []
        for c in certs:
            if str(c.get(mfr_field) or "") != d_mfr:
                continue
            if str(c.get(product_field) or "") != d_product:
                continue
            if str(c.get(cert_status_field) or "").strip() != cert_approved_value:
                continue
            approved_at, why = _struct_local_dt(c.get(cert_approved_at_field))
            vf, why2 = _struct_local_dt(c.get(valid_from_field))
            vt, why3 = _struct_local_dt(c.get(valid_to_field))
            if approved_at is None or vf is None or vt is None:
                return _proj_insufficient(
                    calc, f"证书 {c.get(cert_id_field)} 的批准/有效期不可解析", {}, evidence)
            if approved_at > produced:
                continue
            if not (vf <= produced < vt):
                continue
            rev_raw = c.get(revoked_field)
            if rev_raw not in (None, ""):
                revoked, why = _struct_local_dt(rev_raw)
                if revoked is None:
                    return _proj_insufficient(
                        calc, f"证书 {c.get(cert_id_field)} 撤销时刻不可解析", {}, evidence)
                if revoked <= produced:
                    continue
            candidates.append(c)
        ids = sorted({str(c.get(cert_id_field)) for c in candidates
                      if c.get(cert_id_field)})
        if len(ids) > 1:
            return _proj_insufficient(
                calc, f"出货单 {r.get(delivery_id_field)} 生产时刻存在多份有效证书"
                      f"（{'、'.join(ids)}），无法确定唯一应引用证书", {}, evidence)
        actual = ids[0] if ids else ""
        declared = str(r.get(declared_field) or "").strip()
        parts.append(f"{r.get(delivery_id_field)}={actual or '-'}")
        if not actual or declared != actual:
            bad.append((idx, r, declared, actual))
    value = ";".join(parts)
    inputs = {"manufacturer": mfr, "product": product, "order": order,
              "deliveries": [r.get(delivery_id_field) for r in dels],
              "actual_certificates": value}
    result = {"value": value, "actual_certificates": value}
    if not bad:
        detail = (f"制造商 {mfr}、产品 {product} 的出货："
                  + "；".join(f"{r.get(delivery_id_field)} 引用 "
                             f"{str(r.get(declared_field) or '')} 在生产时刻有效"
                             for r in dels)
                  + f"；实际应引用 {value}")
        return _proj_result("满足", detail,
                            [_proj_sub("S1", "pass", detail,
                                       str(dels[0].get("_text") or ""), calc,
                                       evidence, inputs, result)],
                            calc, evidence, inputs, result)
    subs, details = [], []
    for idx, r, declared, actual in bad:
        one = (f"{r.get(delivery_id_field)} 生产时刻 {r.get(produced_field)} 引用 "
               f"{declared or '（未引用证书）'} 无效；实际应引用 {actual or '（无有效证书）'}")
        details.append(one)
        subs.append(_proj_sub(f"S1#{idx}", "fail", one,
                              str(r.get("_text") or ""), calc, evidence, inputs, result))
    return _proj_result("不满足", "；".join(details), subs, calc, evidence, inputs, result)


# ---------------------------------------------------------------------------
# T-157 跨文档键对齐（确定性）+ 跨文档一致性执行器
#
# 背景（T7/T-154 实验层结论，见 docs/qa/T7本体跨文档价值AB_20261119.md、
# docs/qa/T7本体数据补齐_20261119.md）：本体最有价值的位置不是「喂给语义模型当上下文」，
# 而是「给确定性执行器提供可比对的键」——把原本因实体/口径对不上而算不了的跨文档比对
# 变成能算的。实验层：A 无对齐 37.1% → B' 确定性对齐 77.1% → B'' 补数据后 97.1%，FP 0；
# 全部 3 个误配来自「相似度 ≥0.86 自动合并」（已判死，本实现**不含**相似度/阈值/自动合并）。
#
# 本段把该对齐层接进产品主链（T-157 前产品只有 ruleexec 的 metric 别名取数，
# 没有 subject 级键对齐；execution_plan.py 显式 pair_supported=False）：
#   - 唯一开关 = RULEPROOF_ONTOLOGY_NORM（默认 "0"，步骤 3 通过后才改 "1"）：
#       "0" = 只做字面相等（等价 T7 A 臂，也是产品对跨文档键的既有行为）；
#       "1" = 启用确定性键对齐（norm_text → org_form / code_confusable → 指标别名 → 本体 canonical）；
#   - 对齐来源全部是「精确/归一相等」：不含相似度、阈值、自动合并；
#   - **只作用于键对齐层**：值级抽取/比较复用产品既有实现（_from_text/_parse_date/单位表），
#     _occurrences/judge_limit 等单文档取数与判定逻辑零改动。
# ---------------------------------------------------------------------------
ONTO_NORM_ENV = "RULEPROOF_ONTOLOGY_NORM"
_ONTO_NORM_DEFAULT = "1"        # T-157：步骤 3 产品路径 A/B 通过（B 34/35=97.1%、FP 0、A 37.1%）后改 "1"；
                                # 回滚 = 改回 "0" 或部署侧显式 RULEPROOF_ONTOLOGY_NORM=0
_ORG_FORM_STRIP_MAX = 6         # 连续剥离层数上限（异常数据防死循环）
_CROSS_DOC_KEY_KINDS = ("entity", "label", "code")
_CROSS_DOC_VALUE_TYPES = ("money", "quantity", "date", "code")
_ENGINE_ONTOLOGY_TYPES = ("Field", "Product", "HalfProduct", "ProcessStep", "Party", "Metric")


def _onto_norm_enabled() -> bool:
    """键对齐层开关；默认关（与预注册判据一致，未通过前产品行为保持只做字面相等）。"""
    v = str(os.environ.get(ONTO_NORM_ENV, _ONTO_NORM_DEFAULT) or "").strip().lower()
    return v not in ("", "0", "false", "no", "off")


def _norm_rules() -> dict:
    """归一数据段（懒加载服务层；不可用返回空 dict，引擎可独立运行）。"""
    try:
        from . import hooks as _hk
        rules = _hk.ontology_normalization() or {}
        return rules if isinstance(rules, dict) else {}
    except Exception:
        logging.getLogger(__name__).debug("ontology normalization unavailable", exc_info=True)
        return {}


def _key_norm_text(text) -> str:
    """键对齐文本归一（产品既有 entity_resolution.norm_text 口径，经 hooks 注入）。"""
    try:
        from . import hooks as _hk
        return str(_hk.norm_text(text) or "")
    except Exception:
        logging.getLogger(__name__).debug("norm_text unavailable", exc_info=True)
        return ""


def _norm_org_form(text, org_forms) -> str:
    """组织形式等价尾缀剥离（数据：normalization.org_forms）。

    只有名称**以尾缀结尾**、且剥离后仍 ≥2 字才生效；最多连续剥离 _ORG_FORM_STRIP_MAX 层。
    返回文本归一后的名称（无尾缀命中时即 norm_text 结果，与 T7 实验层同口径）。
    """
    t = _key_norm_text(text)
    if not t:
        return ""
    forms = []
    for f in org_forms or []:
        nf = _key_norm_text(f)
        if nf:
            forms.append(nf)
    forms = sorted(set(forms), key=len, reverse=True)
    for _ in range(_ORG_FORM_STRIP_MAX):
        hit = next((f for f in forms if t.endswith(f) and len(t) - len(f) >= 2), "")
        if not hit:
            break
        t = t[: -len(hit)]
    return t


def _norm_code(text, rules: dict):
    """编号归一（数据：normalization.code_confusables + code_key_pattern）。

    1) 只接受「字母/数字 + 分隔符」的编号形态，且去分隔符后必须匹配数据声明的编号模式；
    2) 按分隔符分段，逐段做易混字符映射（o→0 / i→1 / s→5）；
    3) 纯数字段按整数归一（去前导零，如 BJ-2025-020 与 BJ-2025-2O）。
    不是编号形态返回 None（中文/自然语言文本不进入该路径，避免把合法文本改坏）。
    """
    pat = str(rules.get("code_key_pattern") or "").strip()
    conf = rules.get("code_confusable") or {}
    seps = str(rules.get("code_segment_separators") or r"\-_/\.\s")
    if not pat or not isinstance(conf, dict) or not conf:
        return None
    t = str(text or "").strip().lower()
    if not t:
        return None
    try:
        segs = [x for x in re.split("[%s]+" % seps, t) if x]
    except re.error:
        return None
    if len(segs) < 2:                     # 需要分段（避免把单词/纯数字当编号）
        return None
    joined = "".join(segs)
    if not re.match(r"^[a-z0-9]+$", joined):
        return None
    try:
        if not re.match(pat, joined):
            return None
    except re.error:
        return None
    out = []
    for seg in segs:
        seg = "".join(str(conf.get(ch, ch)) for ch in seg)
        if seg.isdigit() and rules.get("code_numeric_segment"):
            try:
                seg = str(int(seg))
            except Exception:
                logging.getLogger(__name__).debug("code segment int skipped", exc_info=True)
        out.append(seg)
    return tuple(out)


def _norm_key(text, kind: str = "entity"):
    """键归一（T-157，唯一开关 = RULEPROOF_ONTOLOGY_NORM，默认关）。

    - kind="entity"：组织形式等价尾缀剥离（仅尾缀命中、剥离后 ≥2 字）；
    - kind="code"：编号易混字符（0/O、1/I、5/S）+ 编号形态门控 + 数字段去前导零；
    - 其它 kind：不归一，返回 None（值级抽取/比较不走这里）。

    开关关闭或数据不可用时返回 None（调用方按「未归一」处理，不得据此判定同一实体）。
    """
    if not _onto_norm_enabled():
        return None
    if kind == "entity":
        return _norm_org_form(text, _norm_rules().get("org_forms") or []) or None
    if kind == "code":
        return _norm_code(text, _norm_rules())
    return None


def _key_canon(text: str) -> dict:
    """键 → {来源: {canonical}}（确定性本体资产；不含相似度/阈值/自动合并）。

    来源：
    - ontology_v2：别名/实体名 → 规范实体名（冻结取数同一套资产）；
    - workspace_alias：工作空间已启用术语别名（客户主数据导入的产品落地路径，`ontology_workspace.add_manual`）；
    - engine：进程内本体（DB onto_entity/onto_alias 的种子资产，如 蒜沫/蒜蓉→蒜泥）。
    """
    s = str(text or "").strip()
    out = {}
    if not s:
        return out
    try:
        from . import hooks as _hk
        idx = _hk.ontology_alias_index() or {}
        ents = _hk.ontology_entities() or {}
        ov = set(str(x) for x in (idx.get(s) or []))
        if s in ents:
            ov.add(s)
        if ov:
            out["ontology_v2"] = ov
    except Exception:
        logging.getLogger(__name__).debug("ontology_v2 canon skipped", exc_info=True)
    try:
        from . import hooks as _hk2
        pairs = _hk2.workspace_ontology_aliases() or {}
        ws = set()
        if s in pairs:
            ws.add(str(pairs[s]))
        if s in {str(v) for v in pairs.values()}:
            ws.add(s)
        if ws:
            out["workspace_alias"] = ws
    except Exception:
        logging.getLogger(__name__).debug("workspace alias canon skipped", exc_info=True)
    try:
        from .engine import ONTO as _ONTO
        for tk in _ENGINE_ONTOLOGY_TYPES:
            inst = _ONTO.resolve(s, tk)
            if inst is not None:
                out.setdefault("engine", set()).add(str(inst.id))
    except Exception:
        logging.getLogger(__name__).debug("engine ontology canon skipped", exc_info=True)
    return out


def _labels_aligned(left: str, right: str) -> bool:
    """指标/口径 label 是否指同一实体（复用产品 _metric_names 的显式别名机制）。

    只在「同一实体的显式别名」范围内成立，不按同类型扩散（合同金额/预付款/质保金同属金额但不可互取）。
    """
    try:
        ln = set(_metric_names(left))
        rn = set(_metric_names(right))
    except Exception:
        return False
    if not ln or not rn:
        return False
    return right in ln or left in rn or bool(ln & rn)


def _align_keys(left: str, right: str, kind: str = ""):
    """跨文档键对齐（确定性）：返回 (是否同一键, 对齐来源)。

    顺序：字面 → norm_text（括注/空格/连字符归一）→ [开关开] 组织形式尾缀 / 编号易混字符
    → 指标口径别名 → 本体 canonical（同来源交集优先，再跨来源交集）。
    **不含相似度/阈值/自动合并**：T7 已证伪相似度 ≥0.86 自动合并（3/3 误配）。
    """
    left, right = str(left or "").strip(), str(right or "").strip()
    if not left or not right:
        return False, "empty"
    if left == right:
        return True, "literal"
    if not _onto_norm_enabled():
        return False, "none"
    ln, rn = _key_norm_text(left), _key_norm_text(right)
    if ln and rn and ln == rn:
        return True, "norm_text"
    k = str(kind or "").strip().lower()
    rules = _norm_rules()
    # ① 组织形式等价尾缀：只用于实体类键（主体/物料/产品名），不用于口径 label
    if k == "entity":
        lo = _norm_org_form(left, rules.get("org_forms") or [])
        ro = _norm_org_form(right, rules.get("org_forms") or [])
        if lo and ro and lo == ro:
            return True, "org_form"
    # ② 编号易混字符：两侧都必须是编号形态（数据声明模式）才启用
    lc, rc = _norm_code(left, rules), _norm_code(right, rules)
    if lc and rc and lc == rc:
        return True, "code_confusable"
    # ③ 指标/口径 label 别名（金额/日期口径同一实体）
    if k == "label" and _labels_aligned(left, right):
        return True, "metric_alias"
    # ④ 本体 canonical：别名/实体名归一后交集
    cl, cr = _key_canon(left), _key_canon(right)
    for source in ("ontology_v2", "workspace_alias", "engine"):
        if cl.get(source) and cr.get(source) and (cl[source] & cr[source]):
            return True, source
    l_all = set().union(*cl.values()) if cl else set()
    r_all = set().union(*cr.values()) if cr else set()
    if l_all and r_all and (l_all & r_all):
        return True, "canonical_cross"
    return False, "none"


def _cross_doc_file(docs, kw):
    """按文件名子串定位文档（同一项目冻结对象集内）。"""
    kw = str(kw or "").strip()
    if not kw:
        return None
    return next((d for d in docs if kw in str(d.get("filename") or "")), None)


def _cross_doc_label_value(doc, label):
    """显式标签取值（`标签：值`）→ (原值, 证据) ；取不到返回 (None, None)。

    先按严格口径（标签后必须紧跟冒号/等号）取，避免「甲方」误命中「甲方统一社会信用代码」；
    严格口径无命中时回退产品既有的 `_proj_label_hit`（`标签 值` 无冒号写法）。
    """
    label = str(label or "").strip()
    if not doc or not label:
        return None, None
    try:
        pat = re.compile(re.escape(label) + r"[ \t]*[:：=][ \t]*([^。；;\n]+)")
    except re.error:
        pat = None
    if pat is not None:
        for i, line in doc.get("clean") or []:
            m = pat.search(line)
            if not m:
                continue
            raw = _proj_value_of(m.group(1))
            raw = re.split(r"[。；;]", raw)[0].strip()
            if raw:
                return raw, {"file": doc.get("filename") or "", "line": int(i),
                             "quote": str(line).strip()}
    pairs = _proj_label_hit([doc], label)
    if not pairs:
        return None, None
    raw, hit = pairs[0]
    return str(raw or "").strip(), _proj_evidence(hit)


def _cross_doc_split_num_unit(raw: str):
    """'1,280,000.00元' / '128万元' / '2kg' / '120m³' → (float, unit)。"""
    s = (str(raw or "").strip().replace(",", "").replace("，", "")
         .replace("￥", "").replace("¥", ""))
    m = re.match(r"^(-?\d+(?:\.\d+)?)\s*([^\d\s]{0,6})", s)
    if not m:
        return None, ""
    return float(m.group(1)), m.group(2)


def _cross_doc_key_value(docs, side: dict, kind: str):
    """取一侧的比对键 → (键值, 证据)。label 类键 = label 本身；entity/code 类键按声明标签取值。"""
    if kind == "label":
        key = str(side.get("key") or side.get("value_label") or "").strip()
        return (key, None) if key else (None, None)
    label = str(side.get("key_label") or "").strip()
    doc = _cross_doc_file(docs, side.get("file"))
    if label and doc:
        raw, ev = _cross_doc_label_value(doc, label)
        if raw:
            return raw, ev
    key = str(side.get("key") or "").strip()      # 槽位显式声明（无标签场景）
    return (key, None) if key else (None, None)


def _cross_doc_value(docs, side: dict, vtype: str) -> dict:
    """确定性取数（两臂完全相同，复用产品既有数值/单位/日期归一）。

    数值类优先走 ``_from_text``（金额同义写法/万→元/kg→g 等），失败回退显式标签解析 + 单位表；
    日期走 ``_parse_date``；编号去空白/连字符后大写。取不到返回 value=None + reason（不猜默认值）。
    """
    label = str(side.get("value_label") or "").strip()
    doc = _cross_doc_file(docs, side.get("file"))
    if not doc or not label:
        return {"value": None, "reason": "file_or_label_missing"}
    if vtype in ("money", "quantity"):
        val, quote = _from_text(label, str(doc.get("text") or ""))
        if val is not None:
            return {"value": float(val), "via": "_from_text", "quote": quote or "",
                    "file": doc.get("filename") or ""}
        raw, ev = _cross_doc_label_value(doc, label)
        if raw:
            num, unit = _cross_doc_split_num_unit(raw)
            if num is not None:
                scale = _UNIT_SCALE.get(unit)
                return {"value": float(num) * float(scale if scale is not None else 1),
                        "via": "label_parse", "quote": (ev or {}).get("quote") or "",
                        "evidence": ev, "file": doc.get("filename") or ""}
        return {"value": None, "reason": "value_not_found"}
    raw, ev = _cross_doc_label_value(doc, label)
    if not raw:
        return {"value": None, "reason": "value_not_found"}
    quote = (ev or {}).get("quote") or ""
    if vtype == "date":
        return {"value": _parse_date(raw), "via": "_parse_date", "quote": quote,
                "evidence": ev, "file": doc.get("filename") or ""}
    if vtype == "code":
        return {"value": re.sub(r"[\s\-]+", "", raw).upper(), "via": "normalize_code",
                "quote": quote, "evidence": ev, "file": doc.get("filename") or ""}
    return {"value": None, "reason": "unsupported_value_type"}


def _cross_doc_fmt(value) -> str:
    """值 → 稳定可读文本（整数不带小数点；日期元组补零）。"""
    if isinstance(value, tuple) and len(value) == 3:
        try:
            return "%04d-%02d-%02d" % (int(value[0]), int(value[1]), int(value[2]))
        except Exception:
            return str(value)
    if isinstance(value, float) and value == int(value):
        return str(int(value))
    return str(value)


def _cross_doc_compare(vtype: str, va, vb) -> bool:
    """确定性比较：数值类按绝对值容差（同单位基准后），其余按相等。"""
    if vtype in ("money", "quantity"):
        try:
            return abs(float(va) - float(vb)) <= 1e-6
        except Exception:
            return False
    return va == vb


def _calc_cross_doc_consistency(spec, docs):
    """跨文档一致性（T-157）：键对齐 → 两侧取值 → 确定性比较。

    槽位形状（只声明取数口径，不含预期判定）::

        {"calculation": "cross_doc_consistency", "owner_file": "<左文件>",
         "key_kind": "entity|label|code",
         "left":  {"file": "...", "key_label": "...", "key": "...",
                   "value_label": "...", "value_type": "money|quantity|date|code"},
         "right": {...}}

    口径：键未对齐 / 取值失败 → **证据不足**（不比较，不上报不一致）；
          键对齐且两侧取值成功 → 满足/不满足。结论归属 owner_file（左文件）。
    """
    calc = "cross_doc_consistency"
    left = spec.get("left") if isinstance(spec.get("left"), dict) else {}
    right = spec.get("right") if isinstance(spec.get("right"), dict) else {}
    kind = str(spec.get("key_kind") or "entity").strip().lower()
    if kind not in _CROSS_DOC_KEY_KINDS:
        kind = "entity"
    vtype = str(left.get("value_type") or right.get("value_type") or "").strip().lower()
    if vtype not in _CROSS_DOC_VALUE_TYPES:
        detail = "跨文档一致性：值类型未声明或非法（%s，支持 %s）" % (
            vtype or "空", "/".join(_CROSS_DOC_VALUE_TYPES))
        return _proj_result("执行失败", detail,
                            [_proj_sub("S1", "fail", detail, "", calc, [])],
                            calc, [], {"value_type": vtype})
    lkey, lkey_ev = _cross_doc_key_value(docs, left, kind)
    rkey, rkey_ev = _cross_doc_key_value(docs, right, kind)
    evidence = [e for e in (lkey_ev, rkey_ev) if e]
    inputs = {"key_kind": kind, "value_type": vtype,
              "left_file": str(left.get("file") or ""),
              "right_file": str(right.get("file") or ""),
              "key_left": lkey or "", "key_right": rkey or ""}
    if not lkey or not rkey:
        detail = "缺少显式键字段（左=%s，右=%s），无法做键对齐" % (
            lkey or "（缺）", rkey or "（缺）")
        return _proj_insufficient(calc, detail, inputs, evidence)
    aligned, source = _align_keys(lkey, rkey, kind)
    inputs["align_source"] = source
    if not aligned:
        detail = "两侧键未对齐（%s vs %s，key_kind=%s，来源=%s），不比较" % (
            lkey, rkey, kind, source)
        return _proj_insufficient(calc, detail, inputs, evidence)
    lv = _cross_doc_value(docs, left, vtype)
    rv = _cross_doc_value(docs, right, vtype)
    for one in (lv, rv):
        ev = one.get("evidence")
        if ev:
            evidence.append(ev)
    inputs["value_left"] = lv.get("value")
    inputs["value_right"] = rv.get("value")
    if lv.get("value") is None or rv.get("value") is None:
        detail = "键已对齐（来源=%s），但取值失败（左=%s，右=%s）" % (
            source, lv.get("reason") or "空", rv.get("reason") or "空")
        return _proj_insufficient(calc, detail, inputs, evidence)
    same = _cross_doc_compare(vtype, lv.get("value"), rv.get("value"))
    result = {"align_source": source, "key_kind": kind, "value_type": vtype,
              "key_left": lkey, "key_right": rkey,
              "value_left": _cross_doc_fmt(lv.get("value")),
              "value_right": _cross_doc_fmt(rv.get("value")),
              "consistent": bool(same)}
    quote = lv.get("quote") or rv.get("quote") or ""
    detail = "键对齐（%s）：%s ≡ %s；%s 取数 %s vs %s → %s" % (
        source, lkey, rkey, vtype,
        _cross_doc_fmt(lv.get("value")), _cross_doc_fmt(rv.get("value")),
        "一致" if same else "不一致")
    state = "满足" if same else "不满足"
    status = "pass" if same else "fail"
    return _proj_result(state, detail,
                        [_proj_sub("S1", status, detail, quote, calc,
                                   evidence, inputs, result)],
                        calc, evidence, inputs, result)


_PROJECT_CALC_FUNCS = {
    "unpaid_balance_cap": _calc_unpaid_balance_cap,
    "segmented_fee_cap": _calc_segmented_fee_cap,
    "utc_deadline": _calc_utc_deadline,
    "license_expiry_date": _calc_license_expiry_date,
    "ledger_reconcile": _calc_ledger_reconcile,
    "batch_temperature_exception": _calc_batch_temperature_exception,
    "inventory_snapshot": _calc_inventory_snapshot,
    "invoice_payable": _calc_invoice_payable,
    "delivery_deadline": _calc_delivery_deadline,
    "certificate_validity": _calc_certificate_validity,
    "cross_doc_consistency": _calc_cross_doc_consistency,
}


def is_project_compute_rule(slots: dict) -> bool:
    """冻结槽位是否声明项目级确定性执行器。"""
    return bool(_project_spec(slots).get("calculation"))


def judge_project_compute(slots=None, documents=None) -> dict:
    """项目级确定性执行入口：slots 声明计算类型 + 字段标签，documents 为同项目文档集。

    返回 {state: 满足/不满足/证据不足/执行失败, detail, subs, evidence, trace}。
    """
    slots = dict(slots or {})
    spec = _project_spec(slots)
    calc = str(spec.get("calculation") or "").strip()
    if not calc:
        return {"state": "执行失败", "detail": "规则未声明 project_compute.calculation",
                "subs": [], "evidence": [],
                "trace": {"executor": PROJECT_COMPUTE_TEMPLATE, "state": "执行失败"}}
    func = _PROJECT_CALC_FUNCS.get(calc)
    if func is None:
        return {"state": "执行失败",
                "detail": "不支持的项目级计算类型：%s（支持：%s）"
                          % (calc, "、".join(_PROJECT_CALCULATIONS)),
                "subs": [], "evidence": [],
                "trace": {"executor": PROJECT_COMPUTE_TEMPLATE,
                          "calculation": calc, "state": "执行失败"}}
    docs = _proj_collect(documents, spec)
    if not docs:
        return _proj_insufficient(calc, "项目内没有可解析的文档文本", {}, [])
    try:
        out = func(spec, docs)
    except Exception as exc:  # noqa: BLE001 执行失败不许伪装成证据不足/不满足
        logging.getLogger(__name__).warning(
            "project_compute failed calc=%s: %s", calc, exc)
        return {"state": "执行失败",
                "detail": "项目级执行器异常：%s: %s" % (type(exc).__name__, str(exc)[:180]),
                "subs": [], "evidence": [],
                "trace": {"executor": PROJECT_COMPUTE_TEMPLATE,
                          "calculation": calc, "state": "执行失败"}}
    out.setdefault("trace", {})
    out["trace"].setdefault("executor", PROJECT_COMPUTE_TEMPLATE)
    out["trace"]["template"] = PROJECT_COMPUTE_TEMPLATE
    out["trace"].setdefault("calculation", calc)
    out["trace"]["state"] = out.get("state")
    return out


# ===========================================================================
# 平台食品工艺点位 · 确定性限值执行 + 判定守卫（T-170，2026-11-19）
#
# 背景（3 个已定位平台误报的根因层）：
#   ① 判据适用范围（method/适用工序）：冷却终温判据被串到「冷却至手温」这类
#      常温冷却场景 —— 缺终温数值时不得判「不满足」，应按适用性判「不适用/证据不足」；
#   ② 数值比较方向：250ppm/121℃ 这类「远超下限」的值被模型判成「与判据不符」——
#      数值比较必须由确定性执行器做，不能交给模型；
#   ③ 词典数据：产品名称规范判据在没有配置规范词典时被模型判 fail ——
#      无词典应降级「证据不足」，不能凭 4 个 demo 实体名判不满足。
#
# 本段只做两件事，不改判定语义边界：
#   1) judge_limit_rule(code, text)：把内置食品限值规则（RW20260525005/06/09/10/11）
#      用确定性取数+比较执行（阈值为平台判据，见 seed/library_supplement.json 与
#      app/engine/packs/food.py 内置执行器；不是国标数值）。
#   2) guard_judged(points, text, judged)：agent-judge 结论的确定性守卫，只在
#      「确定性执行器能给出结论」时覆盖模型的方向性误报；不覆盖模型给出的真实违规。
#
# 开关（默认全部开启；=0 关闭）：
#   RULEPROOF_JUDGE_GUARD          总开关（关闭后所有守卫不生效）
#   RULEPROOF_JUDGE_GUARD_NUMERIC  数值比较守卫（②）
#   RULEPROOF_JUDGE_GUARD_APPLIC   判据适用范围守卫（①）
#   RULEPROOF_JUDGE_GUARD_DICT     无词典降级守卫（③）
# ===========================================================================

# 平台食品点位限值判据（与 app/engine/packs/food.py 内置执行器同口径）：
#   中心温度≥85℃ / 消毒浓度≥200ppm / 冷却终温≤10℃ / 冷藏暂存 0-8℃ / 解冻≥20h
# 特别注意：解冻时长在 app/services/ruleparam.DEFAULTS 里登记为「≤48h（上限）」，
# 与内置执行器/点位判据的「≥20h」方向不一致；本表以执行器与点位判据为准，
# 该数据不一致已在 T-170 报告中列为 NOT DONE（不在本任务写作用域）。
FOOD_LIMIT_SPECS = {
    "RW20260525005": {"metric": "中心温度", "kind": "temp", "scope": "中心温度",
                      "op": ">=", "value": 85.0, "unit": "℃"},
    "RW20260525006": {"metric": "消毒浓度", "kind": "conc", "scope": "消毒",
                      "op": ">=", "value": 200.0, "unit": "ppm"},
    "RW20260525009": {"metric": "冷却终温", "kind": "temp", "scope": "冷却",
                      "op": "<=", "value": 10.0, "unit": "℃"},
    "RW20260525010": {"metric": "冷藏温度", "kind": "temp", "scope": "冷藏暂存",
                      "op": "range", "lo": 0.0, "hi": 8.0, "unit": "℃"},
    "RW20260525011": {"metric": "解冻时长", "kind": "time", "scope": "解冻",
                      "op": ">=", "value": 20.0, "unit": "h"},
}

# 食品点位（302/supplement 点位编号）→ 内置执行器规则码。
# 与 seed/library_supplement.json:points[].executor 的首段保持一致（单测校验，防漂移）。
FOOD_POINT_RULE = {
    "FOOD01-001": "RW20260525005",
    "FOOD01-002": "RW20260525006",
    "FOOD01-003": "RW20260525009",
    "FOOD01-004": "RW20260525010",
    "FOOD01-005": "RW20260525011",
}

# 常温/自然冷却语境：这类文档的「冷却」不是低温冷链工序，10℃ 终温判据不适用
# （跨场景串用修复 ①：烘焙干净稿「冷却至手温」→ 不适用，不得判不满足）。
_COOLING_AMBIENT_WORDS = ("手温", "室温", "常温")
# 说明：只在**冷却工序行**出现「手温/室温/常温」这类常温目标时才算跨场景；
# 「出炉后置于冷却架自然摊凉」只是中间的摊凉动作，不等于冷却工序按常温终点控制，
# 不能据此把冷链终温判据判成不适用（L2 真实注入「冷却间温度按工艺经验控制」即此情形）。

# 词典类判据（③）：名称规范判定必须有「规范词典」；没有配置词典时不得判 fail。
_DICT_HINTS = ("词典", "规范名称", "名称规范", "标准名称", "标准命名")


# 限值主题关键词：文档里连主题都不出现时，规则不适用（na），不记证据不足/unknown。
_TOPIC_KEYWORDS = {
    "中心温度": ("中心温度",),
    "消毒": ("消毒",),
    "冷却": ("冷却",),
    "冷藏暂存": ("冷藏", "暂存", "库内温度", "冷冻"),
    "解冻": ("解冻",),
}


# 前提缺失型适用性规则：判据有明确业务前提（如「有半成品清单」），
# 前提不成立时判「不适用」而不是 fail。修 ①/额外第 4 类平台误报：
# 文档没有半成品清单时，投料量/总重匹配判据本就不适用（历史 LLM 误判 fail）。
APPLICABILITY_RULES = {
    "B-4": {"precondition": ("半成品清单", "半成品"),
            "reason": "文档未包含半成品清单/半成品重量，投料量与总重匹配判据前提缺失"},
    # 半成品工序闭环：前提是存在半成品清单；没有清单时模型会拿工序行乱配（clean FP 实测）
    "B-2": {"precondition": ("半成品清单", "半成品"),
            "reason": "文档未包含半成品清单，半成品工序闭环判据前提缺失"},
}


# ---------------------------------------------------------------------------
# B-4 / FOOD05-003「投料量与总重匹配」粒度前置条件（A 类平台误报修复 2026-11-22）
#
# 背景（PS-L1-04 clean-control 假报，docs/qa/PS-L1-04裁决_20261122.md）：
#   文档只写了「单批投料牛肉粒 20000g」+ 单批配方（牛肉粒 20000g、腌酱 1200g…合计 23100g），
#   包装指示书只写「每袋净含量 380g / 设计总重量 380g」，**没有半成品清单/半成品重量**。
#   agent-judge 把「批次级投料合计 23100g」与「单袋级设计总重 380g」直接比较 → 判 fail。
#   两个量不在同一粒度，跨粒度比较不构成 B-4 判据下的违规：判据要求的是
#   「半成品重量合计 vs 设计总重」的**同一粒度**比较，且容差 ±5%（与内置执行器
#   app/engine/packs/food.py:_chk_weight_total 同口径）。
#
# 前置条件（本段确定性守卫，默认开；``RULEPROOF_B4_GRANULARITY_GUARD=0`` 回滚旧口径）：
#   ① 同一粒度可复算：设计总重行（或「重量构成」行）把设计总重拆成内容物+包材等分项，
#      分项合计与设计总重一致 → 判 满足/不满足（确定性复算，容差 ±5%）；
#   ② 只有批次级投料/配方总量 + 单件/单袋级设计总重、且无单件构成可复算 → 跨粒度不可比
#      → 判「不适用」（na），**不得判 fail**；
#   ③ 两者都不成立 → 返回 None（交更上游 APPLICABILITY_RULES / 原 agent-judge 路径）。
# ---------------------------------------------------------------------------
_B4_GRANULARITY_ENV = "RULEPROOF_B4_GRANULARITY_GUARD"
_B4_WEIGHT_TOL_PCT = 5.0   # 与 ruleparam「B-4/weight_tolerance_pct」默认值一致

# 批次级计量标记（「单批投料/单批配方/每批投料/按批次配方/投料总量」）
_B4_BATCH_MARKS = ("单批", "每批投料", "批次投料", "按批次配方", "批次配方", "投料总量")
# 单件/单袋级设计总重标记（仅用于证据说明，不参与数值比较）
_B4_UNIT_MARKS = ("每袋", "单袋", "每件", "单件")

_B4_NUM_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(kg|千克|g|克|mg|毫克)")
_B4_UNIT_G = {"kg": 1000.0, "千克": 1000.0, "g": 1.0, "克": 1.0,
              "mg": 0.001, "毫克": 0.001}
_B4_DESIGN_RE = re.compile(
    r"设计总重量\s*[：:]\s*(\d+(?:\.\d+)?)\s*(kg|千克|g|克|mg|毫克)")
# 「设计总重 = 内容物 + 包材…」的构成关键词（同一粒度复算的证据载体）
_B4_COMPOSITION_MARKS = ("内容物", "净重", "净含量", "包材", "标签", "自封袋",
                         "牛皮纸袋", "重量构成", "构成", "组成")
# 批次级计量标记（只认「批次级投料/配方」语境，不把单件净含量当批次量）
_B4_BATCH_MARKS = ("单批投料", "单批配方", "每批投料", "批次投料", "按批次配方",
                   "批次配方", "投料总量")
_B4_BATCH_DECL_RE = re.compile(
    r"(?:投料总重|投料总量|总重|总量|合计)\s*[：:]?\s*(\d+(?:\.\d+)?)\s*"
    r"(kg|千克|g|克|mg|毫克)")


def b4_granularity_guard_on() -> bool:
    """B-4 粒度前置条件开关：默认开；``=0`` 回滚旧口径（与其它守卫同口径的假值）。"""
    try:
        return str(os.environ.get(_B4_GRANULARITY_ENV, "1")).strip().lower() not in (
            "0", "false", "off", "no")
    except Exception:  # noqa: BLE001 - 开关读取失败按开启（与其它守卫默认一致）
        return True


def _b4_to_g(amount: str, unit: str) -> float:
    """重量换算为克（不认识的单位按 1:1，仅用于同单位文本内比较）。"""
    return float(amount) * _B4_UNIT_G.get(str(unit or "").strip().lower(), 1.0)


def _b4_flat(text: str) -> str:
    """把空白（含换行）折叠为单空格。

    主链对 .md 走 ``deepparse._parse_md`` 时，正文是 ``"\n".join(raw.split())`` 的
    「逐 token 一行」形态（「设计总重量：380」和单位 g 被换行拆开）；对 .docx 则是
    正常多行文本。守卫统一在折叠文本上做识别，两种解析形态结论一致；引文仍取原文切片。
    """
    return re.sub(r"\s+", " ", str(text or ""))


def _b4_quote_window(text: str, anchor: str, span: int = 140) -> str:
    """原文里以 anchor 为起点的连续切片（逐字可核验；tokenize 形态含换行也不改写）。"""
    body = str(text or "")
    pos = body.find(anchor)
    if pos < 0:
        return ""
    return body[pos:pos + span].strip()


def _b4_clause_segments(flat: str, m) -> tuple:
    """取设计总重匹配点前后的「同一分句」文本：before 到上一个 。/|/ - 边界，after 到下一个。"""
    end = len(flat)
    for sep in ("）", "。", "|", " - ", "\n"):
        k = flat.find(sep, m.end())
        if k >= 0:
            end = min(end, k + (1 if sep in ("）", "。") else 0))
    after = flat[m.end():end]
    start = max(0, m.start() - 240)
    for sep in ("。", "|", " - "):
        k = flat.rfind(sep, start, m.start())
        if k >= 0:
            start = k + len(sep)
    before = flat[start:m.start()]
    return before, after


def _b4_composition_sum(flat: str, design_g: float) -> tuple:
    """同一粒度复算：设计总重分句里把总重拆成内容物+包材等分项 → (分项合计, 证据文本)。

    识别口径：设计总重的**同一分句**（after 优先、before 兜底）里含构成类关键词、且能
    抽出 ≥2 个重量分项。**不要求分项合计等于设计总重**——合计与设计总重不一致正是要判
    不满足的真实违规；只有「根本拆不出分项」（如只有一行总重）才返回 (None, "")。
    只取同一分句是为了不把相邻的「包材清单（12 g/个）」重复计入（L1-06 实测）。
    """
    if not design_g:
        return None, ""
    for m in _B4_DESIGN_RE.finditer(str(flat or "")):
        before, after = _b4_clause_segments(flat, m)
        joined = before + after
        if not any(k in joined for k in _B4_COMPOSITION_MARKS):
            continue
        for seg in (after, before):
            parts = []
            for one in _B4_NUM_RE.finditer(seg):
                parts.append(_b4_to_g(one.group(1), one.group(2)))
            if len(parts) >= 2:
                return sum(parts), joined
    return None, ""


def _b4_batch_total(flat: str) -> tuple:
    """批次级投料/配方总量 → (克数, 证据窗口, 命中的批次标记)；无则 (None, "", "")。

    优先取标记附近的显式「投料总重/投料总量/总重/合计 X g」；没有显式总量时把该标记
    就近片段里的分项相加（片段截到该单元格结束，避免跨行把别的行数值算进来）。
    """
    body = str(flat or "")
    for mark in _B4_BATCH_MARKS:
        pos = body.find(mark)
        while pos >= 0:
            end = pos + 160
            for sep in ("|", "##"):
                k = body.find(sep, pos + len(mark))
                if k >= 0:
                    end = min(end, k)
            seg = body[pos:end].strip()
            decl = _B4_BATCH_DECL_RE.search(seg)
            if decl:
                return _b4_to_g(decl.group(1), decl.group(2)), seg, mark
            total, got = 0.0, False
            for one in _B4_NUM_RE.finditer(seg):
                total += _b4_to_g(one.group(1), one.group(2))
                got = True
            if got:
                return total, seg, mark
            pos = body.find(mark, pos + len(mark))
    return None, "", ""


def judge_weight_total_rule(code: str, text: str) -> dict | None:
    """B-4/FOOD05-003 投料量与总重匹配的**同一粒度**确定性判定（默认开，=0 回滚）。

    返回 {"state": 满足/不满足/不适用, "detail", "quote", "applicability", "values"}；
    None = 无可判依据（交原路径，不伪造结论）。跨粒度时只返回「不适用」，
    绝不返回「不满足」——这是本守卫的核心边界。
    """
    if not b4_granularity_guard_on():
        return None
    if str(code or "") not in ("B-4", "FOOD05-003"):
        return None
    body = str(text or "")
    flat = _b4_flat(body)
    m = _B4_DESIGN_RE.search(flat)
    if not m:
        return None
    design_g = _b4_to_g(m.group(1), m.group(2))
    comp_g, _comp_seg = _b4_composition_sum(flat, design_g)
    if comp_g is not None:
        tol = max(0.5, design_g * _B4_WEIGHT_TOL_PCT / 100.0)
        quote = _b4_quote_window(body, "设计总重量")
        if abs(comp_g - design_g) <= tol:
            return {"state": "满足",
                    "detail": (f"同一粒度可复算：分项重量合计 {comp_g:g}g ≈ 设计总重 "
                               f"{design_g:g}g（容差 ±{tol:g}g）"),
                    "quote": quote, "applicability": "same_granularity",
                    "values": [comp_g, design_g]}
        return {"state": "不满足",
                "detail": (f"同一粒度复算：分项重量合计 {comp_g:g}g 与设计总重 "
                           f"{design_g:g}g 不一致（容差 ±{tol:g}g）"),
                "quote": quote, "applicability": "same_granularity",
                "values": [comp_g, design_g]}
    batch_g, batch_seg, batch_mark = _b4_batch_total(flat)
    if batch_g is not None:
        quote = _b4_quote_window(body, batch_mark) or batch_seg[:200]
        return {"state": "不适用",
                "detail": (f"投料量是批次级（{batch_g:g}g，原文：{batch_seg[:60]}），"
                           f"设计总重 {design_g:g}g 是单件/单袋级；B-4 只在同一粒度的"
                           f"「投料量合计 vs 设计总重」下可判，跨粒度不可比"),
                "quote": quote, "applicability": "cross_granularity",
                "values": [batch_g, design_g]}
    return None


# 领域型判据（E3/E4 等）：内置执行器带明确物料前提（蒜泥 / 鸡胸肉），
# 文档不含该物料时判「不适用」而不是 fail（clean-control 实测误报：
# 香辣牛肉干/蜜汁猪肉脯被 E4「肉类前处理完整性」误报为 fail）。
# 有该物料时按内置执行器同口径做确定性判定；判不了返回 None 交原路径。
DOMAIN_RULES = {
    "E3": {"material": ("蒜",), "kind": "garlic"},
    "E4": {"material": ("鸡胸肉",), "kind": "chicken"},
}

_E4_WASH = ("清洗", "去筋膜", "去除筋膜", "洗净")

# E3/FOOD02-001「葱姜蒜类前处理三要素」确定性守卫（默认开；=0 回滚旧口径）
_E3_GUARD_ENV = "RULEPROOF_E3_THREE_ELEMENTS_FIX"
_E3_MATERIALS = ("葱", "姜", "蒜")
_E3_ACTIONS = ("清洗", "去皮", "切", "处理", "前处理", "剁", "打", "碎")
_E3_SPEC_RE = re.compile(
    r"\d+(?:\.\d+)?\s*(?:mm|毫米|cm|厘米|目)|粒径|细度|蒜泥|蒜末|姜末|葱花|碎粒|碎末")
_E3_TOOL_RE = re.compile(r"刀|砧板|机|槽|篮|盆|台|器具|粉碎|料理|切丁")


def _e3_guard_on() -> bool:
    """E3 三要素守卫开关：默认开，``=0`` 回滚旧口径（交 agent-judge 原路径）。"""
    try:
        return str(os.environ.get(_E3_GUARD_ENV, "1")).strip().lower() not in (
            "0", "false", "off", "no")
    except Exception:  # noqa: BLE001 - 开关读取失败按开启
        return True


def _judge_e3_three_elements(body: str) -> dict | None:
    """葱/姜/蒜前处理三要素（作业内容 + 器具 + 成品规格）确定性核验。

    只在原文同一行内同时核验到「材料 + 前处理动作 + 器具 + 成品规格」时返回「满足」；
    否则返回 None（交原路径），**绝不返回「不满足」**——本守卫只用于纠正
    「三要素明明齐全却被判 fail」的方向性误报（PS-L1-06 E3 假报）。
    """
    for line in str(body or "").splitlines():
        if not any(m in line for m in _E3_MATERIALS):
            continue
        if not any(a in line for a in _E3_ACTIONS):
            continue
        if _E3_SPEC_RE.search(line) and _E3_TOOL_RE.search(line):
            return {"state": "满足",
                    "detail": ("葱/姜/蒜前处理三要素齐全（同段含作业内容+器具+成品规格），"
                               "不因未使用的物料（如葱）缺规格而判不满足"),
                    "quote": line.strip()[:200], "applicability": "evaluated",
                    "guard": "E3_three_elements"}
    return None


def judge_domain_rule(code: str, text: str) -> dict | None:
    """领域物料前提 + 确定性判定（E3 蒜泥 / E4 鸡胸肉清洗）。

    返回 None 表示该规则没有确定性领域执行器或无法判定，调用方走原路径。
    """
    spec = DOMAIN_RULES.get(str(code or ""))
    if not spec:
        return None
    body = str(text or "")
    if not any(m in body for m in spec["material"]):
        return {"state": "不适用",
                "detail": f"文档不含「{'/'.join(spec['material'])}」物料，"
                          f"{code} 判据不适用（内置执行器同口径：物料缺失=不适用）",
                "quote": "", "applicability": "material_missing"}
    if spec["kind"] == "chicken":
        if any(w in body for w in _E4_WASH):
            return {"state": "满足",
                    "detail": "文档含鸡胸肉且肉类前处理包含清洗/去筋膜/洗净步骤",
                    "quote": next((ln.strip()[:160] for ln in body.splitlines()
                                   if any(w in ln for w in _E4_WASH)), ""),
                    "applicability": "evaluated"}
        return {"state": "不满足",
                "detail": "文档含鸡胸肉但肉类前处理缺少清洗/去筋膜/洗净步骤",
                "quote": next((ln.strip()[:160] for ln in body.splitlines()
                               if "鸡胸肉" in ln), ""),
                "applicability": "evaluated"}
    if spec["kind"] == "garlic":
        # E3「葱姜蒜类前处理三要素」确定性判定（A 类 clean-control 假报修复 2026-11-22）：
        # PS-L1-06 干净稿原文已有「姜、蒜去皮后切成边长 3 mm 的碎粒 | 清洗槽、沥水篮」
        # （作业内容 + 器具 + 成品规格三要素齐全，且配方无葱），agent-judge 却以
        # 「未规定葱的规格（配方亦无葱）」判 fail —— 把不存在的物料当缺要素。
        # 这里只做**方向性误报纠正**：三要素在原文同一前处理行内可确定性核验 → 满足；
        # 核验不到（缺要素/非表格行）→ 返回 None 交原路径，不伪造不满足（避免误伤）。
        if not _e3_guard_on():
            return None
        det = _judge_e3_three_elements(body)
        if det:
            return det
    # 蒜泥等其它形态：未实现完整三要素确定性判定 → 交原路径，不伪造结论
    return None


def judge_applicability_rule(code: str, text: str) -> dict | None:
    """前提缺失型适用性判定；返回 None 表示前提成立/无法判定，调用方走原路径。"""
    spec = APPLICABILITY_RULES.get(str(code or ""))
    if not spec:
        return None
    body = str(text or "")
    if not body.strip():
        return {"state": "证据不足", "detail": "无文档文本，无法判定适用性",
                "quote": "", "applicability": "no_text"}
    # B-4 粒度前置条件（2026-11-22 A 类修复）：只有同一粒度的「投料量合计 vs 设计总重」
    # 才可比。批次级投料量 vs 单件/单袋级设计总重 → 跨粒度不可比 → 不适用，不得判 fail。
    # 注意：不能用裸子串「半成品」判前提成立——「黑椒腌酱为外购半成品（附合格证明）」
    # 里的「半成品」是外购原料说明，不是「半成品清单/半成品重量」证据（PS-L1-04 假报根因）。
    if str(code or "") == "B-4":
        _b4 = judge_weight_total_rule("B-4", body)
        if _b4 and str(_b4.get("state")) == "不适用":
            return {"state": "不适用",
                    "detail": str(_b4.get("detail") or "") + "（判据不适用，不判不满足）",
                    "quote": str(_b4.get("quote") or ""),
                    "applicability": "cross_granularity"}
    if str(code or "") == "B-2" and b4_granularity_guard_on():
        # 同根因连带（PS-L1-04 单份重跑实测 B-2 同形态假报）：B-2「半成品工序闭环」的
        # 判据前提是**半成品清单**；「黑椒腌酱为外购半成品（附合格证明）」里的裸「半成品」
        # 是外购原料说明，不是清单证据。旧口径用裸子串「半成品」判前提成立 → 送 agent-judge
        # → 模型以「全文无独立半成品清单，闭环不成立」判 fail（把证据载体缺失当结论）。
        if "半成品清单" not in body:
            return {"state": "不适用",
                    "detail": spec["reason"] + "（判据不适用，不判不满足）",
                    "quote": "", "applicability": "precondition_missing"}
        return None  # 有半成品清单：保持原判定路径
    if any(k in body for k in spec["precondition"]):
        return None  # 前提成立：保持原判定路径
    return {"state": "不适用", "detail": spec["reason"] + "（判据不适用，不判不满足）",
            "quote": "", "applicability": "precondition_missing"}


# 跨 Sheet 一致性规则的确定性执行（T-170：同日期的重复误报归因到「工单号/版本号」规则）。
# 只在文档里能稳定抽到 ≥2 个同标签取值时给结论；抽不到就返回 None 交回原路径，
# 不用猜测扩大确定性结论（真实文档字段格式多样，宁可退回复核也不误报）。
CONSISTENCY_RULES = {
    "RW20260525001": {"kind": "version", "labels": ("版本号",)},
    "RW20260526004": {"kind": "date", "labels": ("实施日期",)},
    "RW20260525003": {"kind": "name", "labels": ("商品名", "产品名称")},
}

_PLACEHOLDERS = ("", "x", "X", "Ⅹ", "-", "—", "/", "无", "空", "待填", "n/a", "N/A")

# ---------------------------------------------------------------------------
# L28（2026-11-23）RW20260525001 版本号取值修复：
#   缺陷：`_label_values` 用「标签 | 值」逐行取数，把 xlsx 版本履历**表头行**
#         「版本号 | 生效/修订日期 | 修订内容摘要 | 批准人 | 引用标准号 | …」
#         的相邻列名「生效/修订日期」当成版本号取值；另一处（表头值行）取到真实
#         版本「V1.2（第 1.2 版）」→ 判「跨 Sheet 版本号不一致」→ 新行业 clean
#         xlsx 25/25 误报（L24 报告 §3.2）。引文是表头整行（逐字），证据门禁通过。
#   修复（开关 RULEPROOF_VERSION_LABEL_FIX，默认 1；=0 逐字回退旧行为）：
#     ① 排除列名/字段名单元格（生效/修订日期、日期、编号、序号、修订内容摘要…）与
#        不含数字的取值——版本号必须像版本号（含数字且不是列名）；
#     ② 多列版本履历表：识别表头行，按「版本号/版本」列名限定列序，只取该列数据
#        （历史版本按版本号排序取最大 = 当前版本，降序表同口径），不再把邻列当值；
#     ③ 比较前归一（去「（第 1.2 版）」装饰、大写），同一版本的不同书写不误判不一致；
#        真正跨位置/跨 Sheet 版本不一致仍判「不满足」（不放宽）。
# ---------------------------------------------------------------------------
_VERSION_LABEL_FIX_ENV = "RULEPROOF_VERSION_LABEL_FIX"

# 版本履历/表单里是「列名/字段名」而不是取值的单元格词表
_VERSION_HEADER_TOKENS = (
    "版本", "版本号", "版本号/版本", "生效/修订日期", "生效日期", "修订日期",
    "发布日期", "实施日期", "编制日期", "审核日期", "批准日期", "日期",
    "修订内容摘要", "修订内容", "修订说明", "内容摘要", "摘要", "修订人",
    "批准人", "编制人", "审核人", "文件编号", "编号", "序号", "受控状态",
    "引用标准号", "引用标准名称", "标准号", "标准名称", "备注", "名称",
)
_VERSION_HEADER_SUFFIXES = ("日期", "编号", "序号", "摘要", "批准人", "审核人",
                            "编制人", "标准号", "标准名称", "受控状态")


def _version_label_fix_on() -> bool:
    """版本号取值修复开关（默认开；``=0`` 回退旧行为，用于 A/B 与回滚）。"""
    try:
        return str(os.environ.get(_VERSION_LABEL_FIX_ENV, "1")).strip().lower() not in (
            "0", "false", "off", "no")
    except Exception:  # noqa: BLE001 - 开关读取失败按开启
        return True


def _is_version_header_cell(val: str) -> bool:
    """该单元格文本是否是列名/字段名（不是版本号取值）。"""
    s = re.sub(r"[\s\u3000]+", "", str(val or "")).strip("：:|｜/()（）")
    if not s:
        return True
    if s in _VERSION_HEADER_TOKENS:
        return True
    if len(s) <= 12 and s.endswith(_VERSION_HEADER_SUFFIXES):
        return True
    return False


def _looks_like_version(val: str) -> bool:
    """取值是否像版本号：含数字，且不是列名/字段名。"""
    s = str(val or "").strip()
    if not s or _is_version_header_cell(s):
        return False
    return bool(re.search(r"\d", s))


def _norm_version(val: str) -> str:
    """版本号归一（仅用于一致性比较，不改变 detail/引文中的原文取值）。

    ``V1.2（第 1.2 版）`` / ``V1.2(第1.2版)`` / ``第 1.2 版`` / ``v1.2`` 都归一为 ``V1.2``；
    ``DR-2026-V1`` 与 ``DR-2026-V2`` 保持可区分（不做「只取数字」的过度归一）。
    """
    import unicodedata as _ud
    s = _ud.normalize("NFKC", str(val or "")).strip()
    s = re.sub(r"[ \t\u3000]+", "", s)
    s = re.sub(r"[（(]\s*第\s*[^）)]*版\s*[）)]", "", s)
    s = re.sub(r"^第\s*([\d.]+)\s*版$", r"V\1", s)
    s = re.sub(r"[（(]\s*[）)]", "", s)
    return s.upper()


_VERSION_CORE_RE = re.compile(r"[Vv]?(\d+(?:\.\d+)+)")

def _version_order_key(val: str):
    """版本排序键（用于在版本履历里挑当前版本 = 最大版本号）；取不到返回 None。"""
    m = _VERSION_CORE_RE.search(_norm_version(val))
    if not m:
        return None
    try:
        return tuple(int(x) for x in m.group(1).split("."))
    except ValueError:
        return None


def _version_table_current(text: str) -> dict | None:
    """多列版本履历表：按表头列名限定，只取「版本号/版本」列，返回当前版本。

    识别「表头行」：一行按 ``|``/``｜`` 分段后含「版本号/版本」单元格，且**其余单元格
    全部是列名/字段名**（不含取值）。表头之后连续表格行按同一列序取版本列；当前版本 =
    版本号最大的那一行（履历升序/降序同口径），返回 {value, quote, line, row}。
    没有可识别的版本履历表 → None（交回标签取值路径，不猜）。
    """
    lines = str(text or "").splitlines()
    col_idx, header_i = None, -1
    for i, line in enumerate(lines):
        if "|" not in line and "｜" not in line:
            continue
        cells = [c.strip() for c in re.split(r"[|｜]", line)]
        vi = next((j for j, c in enumerate(cells) if c in ("版本号", "版本")), None)
        if vi is None:
            continue
        others = [c for j, c in enumerate(cells) if j != vi and c]
        if len(others) < 1:
            continue
        if not all(_is_version_header_cell(c) for c in others):
            continue  # 含真实取值（如元数据行「文件编号 | X | 版本号 | V1.2 …」）→ 不是表头
        col_idx, header_i = vi, i
        break
    if col_idx is None:
        return None
    rows = []
    for line in lines[header_i + 1:]:
        if "|" not in line and "｜" not in line:
            break  # 版本履历表结束（后续章节/正文）
        cells = [c.strip() for c in re.split(r"[|｜]", line)]
        if len(cells) <= col_idx:
            continue
        val = cells[col_idx].strip()
        if not _looks_like_version(val):
            continue  # 「— | — | …」汇总/占位行
        rows.append({"value": val, "quote": line.strip()[:200], "line": line})
    if not rows:
        return None
    keyed = [(i, _version_order_key(r["value"])) for i, r in enumerate(rows)]
    keyed = [(i, k) for i, k in keyed if k is not None]
    if keyed:
        best = rows[max(keyed, key=lambda x: (x[1], x[0]))[0]]
    else:
        best = rows[-1]
    return best


def _label_values(text: str, labels: tuple, exclude_headers: bool = False) -> list:
    """抽取「标签 | 值」的所有出现：返回 [{label, value, quote, line}]（同标签可多处）。

    exclude_headers=True（L28，版本号取值用）：跳过**取值本身是列名/字段名**的匹配
    （表头行「版本号 | 生效/修订日期 | …」的邻列名不是版本号取值）。
    """
    out = []
    for line in str(text or "").splitlines():
        for label in labels:
            for m in re.finditer(r"%s\s*[|｜:：]\s*([^|｜\n]+)" % re.escape(label), line):
                val = str(m.group(1) or "").strip()
                if not val:
                    continue
                if exclude_headers and _is_version_header_cell(val):
                    continue
                out.append({"label": label, "value": val,
                            "quote": line.strip()[:200], "line": line})
    return out


def _judge_version_consistency(text: str) -> dict | None:
    """RW20260525001 版本号一致性（L28 修复口径）：只取版本号/版本列值并归一比较。

    - 取值 <2 个 → None（交回原 agent-judge 路径，不猜）；
    - 归一后唯一 → 满足；>1 种 → 不满足（真不一致仍 fail，不放宽）。
    """
    vals = _label_values(text, ("版本号",), exclude_headers=True)
    cands = [v for v in vals if _looks_like_version(v["value"])]
    hist = _version_table_current(text)
    if hist is not None:
        cands.append({"label": "版本号", "value": hist["value"],
                      "quote": hist["quote"], "line": hist["line"]})
    valid = [v for v in cands if str(v["value"]).strip() not in _PLACEHOLDERS]
    uniq, seen_norm = [], []
    for v in valid:
        nv = _norm_version(v["value"])
        if nv in seen_norm:
            continue
        seen_norm.append(nv)
        uniq.append(v)
    if len(valid) < 2 or len(uniq) < 1:
        return None
    if len(uniq) > 1:
        a, b = uniq[0], uniq[1]
        return {"state": "不满足",
                "detail": f"跨 Sheet 版本号不一致：{a['value']} 与 {b['value']}"
                          f"（共 {len(uniq)} 种取值）",
                "quote": b["quote"], "applicability": "evaluated",
                "values": [v["value"] for v in uniq], "source": "version_label_fix"}
    return {"state": "满足",
            "detail": f"跨 Sheet 版本号一致：{uniq[0]['value']}（{len(valid)} 处，"
                      f"按版本号列取值）",
            "quote": uniq[0]["quote"], "applicability": "evaluated",
            "values": [u["value"] for u in uniq], "source": "version_label_fix"}


# 占位符判据（RW20260525002 版本号/签名非占位符）：确定性执行。
# 内置执行器 app/engine/packs/food.py::_chk_version_placeholder/_chk_signatures 是同口径，
# 主链 D4 之前把该判据交给模型，模型能找到 X 但引文常不逐字（签名单元格在表头值行），
# 引文不可核验 → insufficient → 报告门禁按设计阻断。这里用文档文本确定性定位。
_PLACEHOLDER_VALUES = ("X", "x", "Ⅹ", "Ｘ", "", "空", "待填", "-", "—", "/")

# ---------------------------------------------------------------------------
# L167（2026-11-25）签名区识别修复（D2：干净 xlsx 签名区误报 + 假证据门禁）
#
# 缺陷（build56 §4 D2 实测）：干净底稿 L1_21.xlsx（版本号 PS-BAK-2026-V1、签名
#   陈一鸣/周立/林岚/吴迪）被判「1 处占位符：签名 为 X/空」，quote 却是版本号行。
# 根因：旧实现把「角色标签行」下一行（版本号值行）按 `|` 切开后固定取 parts[2:] 前
#   4 段当签名值。真实模板中签名角色在 S/W/AA/AE 列、签名值在下一行**同列**，
#   中间空单元格被切成 ""；"" 属于占位符集合 → 干净稿误报，且引文=版本号行
#   （存在≠支撑结论，证据门禁只验逐字、不验主题匹配 → 假证据通过）。
# 修复：按签名区识别，不再按固定列偏移猜签名值：
#   · 角色标签必须是**独立单元格**（正文里出现的角色字样不算签名区标签）；
#   · 角色标签行需 ≥2 个角色（或行内含显式「签名/签署/签字」区标签）才构成签名区；
#   · 值单元格 = 标签行下一非空行**同列**单元格，且必须是签名值（人名/工号/占位符/
#     空）；版本号、日期、数值、字段标签、过长描述一律不算签名值 → 不据此判占位；
#   · MD/DOCX 行内「签署：研发经理 陈一鸣 / …」布局单独识别（格式间行为一致）；
#   · 整个文档未识别到签名区 → 证据不足（不判 fail，也不伪装「全部满足」）。
# 开关 RULEPROOF_PLACEHOLDER_SIGN_AREA（默认 1；=0 逐字回退旧识别，A/B 与回滚）。
# 只改 RW20260525002 确定性执行中的签名识别；不改其它规则/执行器语义。
# ---------------------------------------------------------------------------
_PLACEHOLDER_SIGN_AREA_ENV = "RULEPROOF_PLACEHOLDER_SIGN_AREA"
_SIGN_ROLE_ORDER = ("研发经理", "生产经理", "品管经理", "研发")
_SIGN_FIELD_LABELS = ("签名", "签署", "签字")
# 签名值单元格的「非签名」白名单：这些内容出现在角色标签下方时说明不是签名区
# （字段标签/日期/数值列等），不得据此判签名占位。
_SIGN_NON_VALUE_LABELS = (
    "版本号", "版本", "实施日期", "生效日期", "商品名", "产品名称", "成品名称",
    "工序名称", "工序", "标准工序", "作业内容", "作业条件", "作业要点", "器具",
    "设计总重量", "生产数", "净重", "毛重", "备注", "原材料名", "原材料",
    "投入量合计（确认用）", "半成品名称", "包材名称", "包材编号", "序号", "编号",
    "日期", "核准", "审核", "制表", "编制")


def _placeholder_sign_area_on() -> bool:
    """L167 签名区识别开关（默认 1；=0 逐字回退旧识别，A/B 与回滚）。"""
    return str(os.environ.get(_PLACEHOLDER_SIGN_AREA_ENV, "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _ph_norm_cell(value) -> str:
    """单元格归一：NFKC（全角→半角）+ 去全部空白（含全角空格/制表符）。"""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(value or "")))


_SIGN_ROLE_NORMS = {_ph_norm_cell(r): r for r in _SIGN_ROLE_ORDER}
_SIGN_FIELD_NORMS = frozenset(_ph_norm_cell(x) for x in _SIGN_FIELD_LABELS)
_SIGN_NON_VALUE_NORMS = frozenset(_ph_norm_cell(x) for x in _SIGN_NON_VALUE_LABELS)
# 签名占位额外写法（与版本号占位同口径 + 签名场景专有写法）
_SIGN_PLACEHOLDER_EXTRA = ("未填", "未签", "待签", "无", "N/A", "NA", "n/a")


def _ph_cells(line) -> list:
    """文本行按表格分隔符切分单元格（保留空单元格/列位置，供同列对齐）。"""
    return [str(c).strip() for c in re.split(r"[|｜]", str(line or ""))]


def _ph_line_empty(line) -> bool:
    """是否空行：xlsx 文本里空行只剩分隔符/空白；空行不当作签名值行。"""
    text = str(line or "").strip()
    if not text:
        return True
    return not any(str(c).strip() for c in _ph_cells(text))


def _ph_is_signature_placeholder(value) -> bool:
    """是否签名占位/空值（旧口径 + 签名场景专有占位写法）。"""
    v = str(value or "").strip()
    return v in _PLACEHOLDER_VALUES or v in _SIGN_PLACEHOLDER_EXTRA


def _ph_looks_like_signature_value(value) -> bool:
    """值单元格是否签名值（人名/工号/占位符/空）。

    「值单元格必须是签名值」：字段标签、日期、版本号/编号、纯数值、带单位数值、
    过长描述文本都不是签名值——角色标签下方是这些内容时，该角色标签不在签名区，
    不能据此判签名占位（D2 根因：把版本号行/空列当签名值）。
    """
    s = _ph_norm_cell(value)
    if not s:
        return True                        # 空单元格 = 可能签名未填，进入占位判定
    if s in _PLACEHOLDER_VALUES or s in _SIGN_PLACEHOLDER_EXTRA:
        return True
    if s in _SIGN_ROLE_NORMS or s in _SIGN_FIELD_NORMS or s in _SIGN_NON_VALUE_NORMS:
        return False
    if re.match(r"^\d{4}[-/年.]\d{1,2}", s):                        # 日期
        return False
    if re.fullmatch(r"[\d.．\-—/／:：年月日时分秒%％]+", s):          # 纯数值/时间
        return False
    if re.match(r"(?i)^(v|ver|version|rev|ps|fp|版)[-_ ]?\d", s):   # 版本号形态
        return False
    if re.search(r"(?i)ppm|℃|°c|°f|kg|mg|min|ml|小时|分钟|公斤", s):  # 带单位数值/描述
        return False
    if not re.search(r"[A-Za-z\u4e00-\u9fff]", s):                  # 必须含文字/字母
        return False
    if len(s) > 16:                                                 # 过长 = 描述文本
        return False
    return True


def _ph_version_problems(lines: list) -> list:
    """版本号占位：`版本号 | X`（保持修前口径：仅表格分隔符，不改非签名判定语义）。"""
    problems = []
    for ln in lines:
        m = re.search(r"版本号\s*[|｜]\s*([^|｜\n]*)", ln)
        if not m:
            continue
        val = str(m.group(1) or "").strip()
        if val in _PLACEHOLDER_VALUES:
            problems.append({"kind": "版本号", "value": val,
                             "quote": ln.strip()[:160]})
    return problems


def _ph_align_signature_pairs(cells: list, vcells: list, role_cols: list) -> tuple:
    """角色标签行 → 值行的列对齐（返回 (delta, pairs)；对齐失败 (None, [])）。

    解析层对稠密行做「标签紧邻值」归一化（`_xlsx_label_adjacent_cells`）会删掉标签与
    值之间的空列，**同一工作簿不同行可能删的列数不同**（如包装指示书角色行有
    「实施日期」被归一化、签名值行没有）→ 文本行间列号错位。这里只在有限偏移
    （0/±1/±2）内选择使「尽可能多角色同列命中签名值、且没有角色同列是非签名内容」
    的对齐；不做无限列猜测，也不按固定偏移硬取。
    """
    best = None
    for delta in (0, 1, -1, 2, -2):
        pairs, present, empty, bad = [], 0, 0, 0
        for ci, role, label in role_cols:
            vi = ci + delta
            val = vcells[vi] if 0 <= vi < len(vcells) else ""
            pairs.append((role, val, vi, label))
            if not str(val).strip():
                empty += 1
            elif _ph_looks_like_signature_value(val):
                present += 1
            else:
                bad += 1
        if bad:
            continue                       # 对齐后命中版本号/日期/角色标签等 → 不是签名值行
        score = (present, -empty)
        if best is None or score > best[0]:
            best = (score, delta, pairs)
    if best is None:
        return None, []
    return best[1], best[2]


def _ph_signature_areas(lines: list) -> list:
    """识别表格型签名区（角色标签行 + 同列签名值行）。

    返回 [{"label_line": i, "value_line": j|None,
           "pairs": [(role, value, col_idx, raw_label)], "resolved": bool}]。
    · 角色标签必须独立单元格；≥2 个同行角色，或行内含「签名/签署/签字」→ 签名区；
    · 值行 = 标签行之后第一条非空行；列数需与标签行同量级（防把下一节标题当值行）；
    · 列对齐允许有限偏移（解析层标签归一化会删空列造成行间错位）；
    · 至少一个角色的同列单元格是**非空签名值**，才算确认签名值行；全空无法区分
      「签名区未填」与「标签不在签名区」→ 按无签名区处理（证据不足，不判 fail）。
    """
    areas, i, n = [], 0, len(lines)
    while i < n:
        cells = _ph_cells(lines[i])
        role_cols = []
        for ci, cell in enumerate(cells):
            _nc = _ph_norm_cell(cell)
            if _nc in _SIGN_ROLE_NORMS:
                role_cols.append((ci, _SIGN_ROLE_NORMS[_nc], cell))
        if not role_cols:
            i += 1
            continue
        if len(role_cols) < 2 and not any(k in lines[i] for k in _SIGN_FIELD_LABELS):
            i += 1
            continue
        j = i + 1
        while j < n and _ph_line_empty(lines[j]):
            j += 1
        if j >= n:
            areas.append({"label_line": i, "value_line": None,
                          "pairs": [(r, "", c, lab) for c, r, lab in role_cols],
                          "resolved": False})
            break
        vcells = _ph_cells(lines[j])
        # 值行必须与标签行同量级（列数差 ≤2）：防把下一节标题/单字段行当值行
        if len(vcells) < 2 or len(vcells) < len(cells) - 2:
            i += 1
            continue
        delta, pairs = _ph_align_signature_pairs(cells, vcells, role_cols)
        present = [p for p in pairs if str(p[1]).strip()
                   and _ph_looks_like_signature_value(p[1])]
        if delta is None or not present:
            # 没有可确认的签名值（全空/非签名内容）→ 不据此判占位，继续找签名区
            i += 1
            continue
        areas.append({"label_line": i, "value_line": j, "pairs": pairs,
                      "shift": delta, "resolved": True})
        i = j + 1
    return areas


def _ph_signature_quote(lines: list, area: dict, label: str) -> str:
    """签名占位引文：角色标签（逐字）+ 值行（逐字），两段都可回查。

    值行含其它角色签名值时展示同列上下文；空签名无法用单格表达，由角色标签段
    支撑「对应角色/签名字段」，值行展示该行实际填写情况（不伪造 X）。
    """
    _lab = str(label or "").strip()
    j = area.get("value_line")
    _val_line = (str(lines[j]).strip()[:150]
                 if isinstance(j, int) and 0 <= j < len(lines) else "")
    if _val_line and _val_line != _lab:
        return f"{_lab}；{_val_line}"[:200]
    return _lab[:200]


def _ph_signature_problems(lines: list, areas: list) -> list:
    """从签名区提取占位/空签名问题（空列/无关值行不算签名，不产生误报）。"""
    problems = []
    for a in areas:
        if not a.get("resolved"):
            continue
        for role, val, _ci, label in a.get("pairs") or []:
            if not _ph_looks_like_signature_value(val):
                continue                  # 该角色下方不是签名值 → 该角色不在签名区
            if not _ph_is_signature_placeholder(val):
                continue
            problems.append({"kind": "签名", "role": role,
                             "value": str(val or "").strip(),
                             "quote": _ph_signature_quote(lines, a, label)})
    return problems


def _ph_inline_value_ok(value) -> bool:
    """行内签署值是否签名值：空/占位符，或 2-4 字中文人名 / 工号样式短 ID。"""
    s = _ph_norm_cell(value)
    if not s:
        return True                        # 显式签署行里空值 = 可能未签，进入占位判定
    if _ph_is_signature_placeholder(value):
        return True                        # X/空/待填/未签… 仍是签名值（待判占位）
    if any(r in s for r in _SIGN_ROLE_NORMS):
        return False                       # 捕获到的是另一个角色名，不是签名值
    if s in _SIGN_FIELD_NORMS or s in _SIGN_NON_VALUE_NORMS:
        return False
    if re.fullmatch(r"[\u4e00-\u9fff]{2,6}", s):        # 中文人名
        return True
    if re.fullmatch(r"[A-Za-z][A-Za-z0-9._\-]{1,15}", s):  # 工号/ID 样式
        return True
    return False


def _ph_inline_signatures(lines: list) -> tuple:
    """MD/DOCX 行内签名区（「签署：研发经理 陈一鸣 / 生产经理 周立 …」）。

    返回 (found_roles, problems)。表格行（含 `|`）交给列对齐逻辑，不在此重复识别；
    **必须行内出现显式「签名/签署/签字」区标签**（正文里只提角色名不算签名区）；
    角色名后由空格/冒号分隔的短值必须是签名值（人名/工号/占位符/空），
    否则该角色不构成签名区证据；占位/空 → 问题。
    """
    found, problems = [], []
    _role_re = re.compile(r"(研发经理|生产经理|品管经理|研发(?!经理))")
    for ln in lines:
        if "|" in ln or "｜" in ln:
            continue
        if not any(k in ln for k in _SIGN_FIELD_LABELS):
            continue                       # 无显式签名区标签 → 不是签名区（防正文角色名误判）
        for m in _role_re.finditer(ln):
            role = m.group(0)
            if role in found:
                continue
            vm = re.match(r"\s*[:：]?\s*([^\s/／、,，;；|｜()（）\[\]【】]{1,16})",
                          ln[m.end():])
            val = (vm.group(1) or "").strip() if vm else ""
            if not _ph_inline_value_ok(val):
                continue                   # 捕获到的是描述文本/其它角色 → 不是签名值
            found.append(role)
            if _ph_is_signature_placeholder(val):
                problems.append({"kind": "签名", "role": role, "value": val,
                                 "quote": ln.strip()[:200]})
    return found, problems


def _ph_fail_result(problems: list) -> dict:
    """占位符问题的统一返回（去重 + 有支撑的逐字引文列表）。"""
    uniq, seen = [], set()
    for p in problems:
        if p["quote"] in seen:
            continue
        seen.add(p["quote"])
        uniq.append(p)
    return {"state": "不满足",
            "detail": f"{len(uniq)} 处占位符：{'、'.join(p['kind'] for p in uniq)} 为 X/空",
            "quote": uniq[0]["quote"],
            "violations": [u["quote"] for u in uniq],
            "labels": [u["kind"] for u in uniq],
            "applicability": "evaluated"}


def _judge_placeholder_legacy(lines: list) -> dict:
    """L167 修前逐字回退（RULEPROOF_PLACEHOLDER_SIGN_AREA=0 专用，勿改语义）。

    旧签名识别：角色行下一行含「版本号」→ 取该行 parts[2:6] 当签名值
    （L1_21 干净稿即此路径把空列误报为签名占位）。
    """
    problems = []
    for ln in lines:
        m = re.search(r"版本号\s*[|｜]\s*([^|｜]*)", ln)
        if not m:
            continue
        val = str(m.group(1) or "").strip()
        if val in _PLACEHOLDER_VALUES:
            problems.append({"kind": "版本号", "value": val,
                             "quote": ln.strip()[:160]})
    _roles = ("研发经理", "生产经理", "品管经理")
    for i, ln in enumerate(lines[:-1]):
        if sum(1 for r in _roles if r in ln) < 2:
            continue
        nxt = lines[i + 1]
        if "版本号" not in nxt:
            continue
        parts = [x.strip() for x in re.split(r"[|｜]", nxt)]
        sig_vals = parts[2:] if len(parts) > 2 else []
        bad_sig = [v for v in sig_vals[:4] if v in _PLACEHOLDER_VALUES]
        if bad_sig:
            problems.append({"kind": "签名", "value": bad_sig[0],
                             "quote": nxt.strip()[:160]})
    if not problems:
        return {"state": "满足",
                "detail": "版本号与签名均非占位符（确定性核对表头值行）",
                "quote": "", "violations": [], "applicability": "evaluated"}
    return _ph_fail_result(problems)


def judge_placeholder_rule(code: str, text: str) -> dict | None:
    """版本号/签名占位符确定性判定（RW20260525002）；其他规则返回 None。

    L167：签名按「签名区」识别（列对齐/行内签署）；无签名区 → 证据不足，不判 fail。
    开关 RULEPROOF_PLACEHOLDER_SIGN_AREA=0 → 逐字回退修前识别（_judge_placeholder_legacy）。
    """
    if str(code or "") != "RW20260525002":
        return None
    lines = str(text or "").splitlines()
    if not lines:
        return None
    if not _placeholder_sign_area_on():
        return _judge_placeholder_legacy(lines)
    problems = _ph_version_problems(lines)
    areas = _ph_signature_areas(lines)
    inline_found, inline_problems = _ph_inline_signatures(lines)
    problems.extend(_ph_signature_problems(lines, areas))
    problems.extend(inline_problems)
    area_found = any(a.get("resolved") for a in areas) or bool(inline_found)
    if problems:
        return _ph_fail_result(problems)
    if not area_found:
        # 无签名区：证据不足（不默认放行，也不把「没有证据」写成 fail）
        return {"state": "证据不足",
                "detail": "文档未解析到签名区（角色标签/签名值单元格未识别，不默认放行）",
                "quote": "", "violations": [], "labels": [],
                "applicability": "evaluated"}
    return {"state": "满足",
            "detail": "版本号与签名均非占位符（按签名区列对齐/行内签署核对）",
            "quote": "", "violations": [], "applicability": "evaluated"}


def judge_consistency_rule(code: str, text: str) -> dict | None:
    """跨 Sheet 一致性规则（版本号/实施日期/商品名）的确定性执行。

    判据：同一标签在文档多个 Sheet 的取值必须一致（忽略占位符 X/空，与内置执行器同口径）。
    - 抽到 ≥2 个有效取值且唯一 → 满足；
    - 抽到 ≥2 个有效取值且不一致 → 不满足（引文取第一个不一致值所在行，逐字）；
    - 取值 <2 个（单 Sheet/抽不到）→ None，交原 agent-judge 路径。
    """
    spec = CONSISTENCY_RULES.get(str(code or ""))
    if not spec:
        return None
    # L28（2026-11-23）RW20260525001 版本号取值修复：只取「版本号/版本」列值、
    # 排除表头/字段名、多列履历按列名限定列序；=0 逐字回退旧行为（A/B 与回滚）。
    if str(spec.get("kind")) == "version" and _version_label_fix_on():
        return _judge_version_consistency(text)
    vals = _label_values(text, tuple(spec["labels"]))
    if spec["kind"] in ("version", "date"):
        valid = [v for v in vals if str(v["value"]).strip() not in _PLACEHOLDERS]
    else:
        valid = [v for v in vals if str(v["value"]).strip() not in _PLACEHOLDERS]
    uniq = []
    for v in valid:
        if v["value"] not in [u["value"] for u in uniq]:
            uniq.append(v)
    if len(valid) < 2 or len(uniq) < 1:
        return None
    kind_txt = {"version": "版本号", "date": "实施日期", "name": "商品名/产品名称"}[spec["kind"]]
    if len(uniq) > 1:
        a, b = uniq[0], uniq[1]
        return {"state": "不满足",
                "detail": f"跨 Sheet {kind_txt}不一致：{a['value']} 与 {b['value']}"
                          f"（共 {len(uniq)} 种取值）",
                "quote": b["quote"], "applicability": "evaluated",
                "values": [v["value"] for v in uniq]}
    return {"state": "满足",
            "detail": f"跨 Sheet {kind_txt}一致：{uniq[0]['value']}（{len(valid)} 处）",
            "quote": uniq[0]["quote"], "applicability": "evaluated",
            "values": [u["value"] for u in uniq]}


# ===========================================================================
# P01 招标采购审核点 · 文内确定性结构算子（修 C，2026-11-21）
#
# 依据：docs/qa/L1主机制_无finding根因_20261121.md §3.1（E4a：D4 判 pass 的 35 条 FN）
# 与 §6 ROI#3。这 35 条全部是 method=semantic 的 S2 审核点，没有 metric/op/value
# 结构化 slots，所以既有 guard_judged 的数值限值路径（judge_limit_rule）逐条都落到
# `_resolve_rule_code` 的空路径（ruleexec.py:7639-7643）——一条也覆盖不到。
# 但其中 11 条的违规是**文内确定性矛盾**（盲测注入把一个数字/日期/单位改掉，原文别处
# 仍有正确取值/自洽约束），可以用与 sum_check / interval_end_le / window_gap_le /
# range_overlap 同口径的取数直接判：
#   ① 分项合计 ≠ 总数（出资比例合计 / 评分构成合计 / 桥梁分项；sum_check 口径）
#   ② 数量/量纲（台数×单机容量 ≠ 总装机容量；同产品「拟建X万吨/年」两处不一致）
#   ③ 单位不一致（同组取值一处带 % 一处不带）
#   ④ 日期链（获取截止 > 投标截止；获取开始+约定「不少于N日」> 投标截止；
#      interval_end_le / window_gap_le 口径）
#   ⑤ 声明数 ≠ 枚举数（「2项工作（投标登记）」；集合/应含未含口径）
# 严格增量：判不了 → None（不动模型结论）；只在「确定=不满足 且 模型=pass」时改 fail。
# 引文一律取**原文整行切片**；取不到原文行 → 由 guard_judged 降级 insufficient
# （fail-closed：不许绕过引文门禁裸 fail）。
# 开关：RULEPROOF_JUDGE_GUARD_CROSSREF（默认开，=0 关闭）。
# ===========================================================================
_P01_CROSSREF_CODES = ("C01-005", "C09-001", "C10-001", "F02-007",
                          "C01-001", "C06-003", "F08-002", "A01-005",
                          "A02-004", "F02-004", "A02-006", "F01-006", "A02-002",
                          # 2026-11-23 第三批：跨位置取值一致性 / 费率基数 / 引用来源 / 期限口径
                          "A01-003", "C08-003", "B03-002", "C09-002")


def _p01_norm(s: str) -> str:
    """NFKC + 去水平空白（保留换行，便于按原文行回查逐字引文）。"""
    import unicodedata as _ud
    return re.sub(r"[ \t\u3000]+", "", _ud.normalize("NFKC", str(s or "")))


def _p01_parse_date(s: str):
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日(?:(\d{1,2})[时:](\d{1,2})?)?", str(s or ""))
    if not m:
        return None
    try:
        return _dt.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                            int(m.group(4) or 0), int(m.group(5) or 0))
    except ValueError:
        return None


def _p01_det(rule: str, detail: str, fragment: str, operands: list, recompute: str) -> dict:
    return {"rule": rule, "detail": detail, "fragment": fragment,
            "operands": list(operands or []), "recompute": recompute}


def _p01_sum_check(t: str):
    """① 分项合计 ≠ 总数（sum_check 口径）。"""
    pairs = re.findall(r"[：:]([\d.]+)万元([\d.]+)%", t)
    if len(pairs) >= 3:
        total = sum(float(v[1]) for v in pairs)
        if abs(total - 100.0) > 0.51:
            m = re.search(r"[\u4e00-\u9fa5]{2,10}[：:][\d.]+万元[\d.]+%", t)
            return _p01_det(
                "sum_check_ratio",
                "出资比例分项合计=%.1f%%≠100%%（分项互斥且穷尽总体）" % total,
                m.group(0) if m else "", [p[1] + "%" for p in pairs[:8]],
                "sum(%s)=%.1f%%" % ("+".join(p[1] for p in pairs[:8]), total))
    m = re.search(r"(?:经济标|投标报价)[^|\n]{0,20}?(\d+)分[^|\n]{0,30}?"
                  r"(?:技术标|设计方案)[^|\n]{0,20}?(\d+)分[^|\n]{0,30}?"
                  r"(?:商务标|资信部分)[^|\n]{0,20}?(\d+)分", t)
    if m:
        a, b, c = int(m.group(1)), int(m.group(2)), int(m.group(3))
        total = a + b + c
        if total != 100:
            return _p01_det(
                "sum_check_score", "评分构成合计 %d 分≠100 分" % total, m.group(0),
                ["%d分" % a, "%d分" % b, "%d分" % c],
                "%d+%d+%d=%d" % (a, b, c, total))
    return None


def _p01_qty_check(t: str):
    """② 数量/量纲矛盾：台数×单机容量 vs 总容量；同产品产量两处不一致；桥梁分项合计。"""
    m1 = re.search(r"(\d+)台单机容量为(\d+(?:\.\d+)?)(kW|MW)", t)
    m2 = re.search(r"(?:总装机容量|规划建设容量|装机容量)(\d+(?:\.\d+)?)(MW|万kW|万千瓦)", t)
    if m1 and m2:
        n, cap, u1 = int(m1.group(1)), float(m1.group(2)), m1.group(3).lower()
        tot, u2 = float(m2.group(1)), m2.group(2)
        tot_mw = tot * 10 if u2 in ("万千瓦", "万kW") else tot
        calc = cap / 1000.0 * n if u1 == "kw" else cap * n
        if abs(calc - tot_mw) > 1.0:
            return _p01_det(
                "capacity_product",
                "%d台×%g%s=%.3gMW，与总装机容量%g%s不一致" % (n, cap, m1.group(3), calc, tot, u2),
                m1.group(0), ["%d台" % n, "%g%s" % (cap, m1.group(3)), "%g%s" % (tot, u2)],
                "%d×%g%s=%.3gMW ≠ %g%s" % (n, cap, m1.group(3), calc, tot, u2))
    seen = {}
    for m in re.finditer(r"拟建(\d+(?:\.\d+)?)万吨/年([\u4e00-\u9fa5]{2,6})装置", t):
        val, prod = float(m.group(1)), m.group(2)
        if prod in seen and abs(seen[prod][0] - val) > 1e-9:
            return _p01_det(
                "prod_qty_conflict",
                "%s装置产量两处不一致：%g vs %g 万吨/年" % (prod, seen[prod][0], val),
                m.group(0), ["%g万吨/年" % seen[prod][0], "%g万吨/年" % val],
                "%s: %g != %g" % (prod, seen[prod][0], val))
        seen.setdefault(prod, (val, m.group(0)))
    m = re.search(r"全线设置桥梁(\d+)座[,，]其中大桥(\d+)座[、,，]中桥(\d+)座[、,，]小桥(\d+)座", t)
    if m:
        total = int(m.group(1))
        parts = int(m.group(2)) + int(m.group(3)) + int(m.group(4))
        if total != parts:
            return _p01_det(
                "sum_check_bridge",
                "桥梁分项合计 %d 座≠总数 %d 座" % (parts, total),
                m.group(0), ["大桥%d座" % int(m.group(2)), "中桥%d座" % int(m.group(3)),
                             "小桥%d座" % int(m.group(4))],
                "%d+%d+%d=%d ≠ %d" % (int(m.group(2)), int(m.group(3)), int(m.group(4)),
                                       parts, total))
    return None


def _p01_unit_check(t: str):
    """③ 单位不一致：同一组取值一处带 % 一处不带。"""
    m = re.search(r"K2取值(?:为|范围)?[：:]?(\d+(?:\.\d+)?)(%?)", t)
    m1 = re.search(r"K1值取值范围[：:]([^；;。]{0,60})", t)
    if m and m1 and "%" in m1.group(1) and not m.group(2):
        return _p01_det(
            "unit_missing", "K2取值 %s 缺百分号，而同组 K1 取值范围带 %%" % m.group(1),
            m.group(0), ["K2=%s" % m.group(1), "K1=%%集"], "K2无单位 vs K1有%%")
    return None


def _p01_date_chain(t: str):
    """④ 日期链：获取截止 > 投标截止；获取开始+「不少于N日」> 投标截止。"""
    dl = re.search(r"(?:投标截止时间|递交的截止时间|截止时间)[^。；\n]{0,20}?(?:为|[:：])"
                   r"(\d{4}年\d{1,2}月\d{1,2}日[^。；，\n]{0,10})", t)
    out = None
    mg = re.search(r"获取时[间间为][^。；\n]{0,10}?[：:为]?"
                   r"(\d{4}年\d{1,2}月\d{1,2}日[^至到。；，]{0,8})至"
                   r"(\d{4}年\d{1,2}月\d{1,2}日[^。；，\n]{0,10})", t)
    if mg and dl:
        get_end = _p01_parse_date(mg.group(2))
        deadline = _p01_parse_date(dl.group(1))
        if get_end and deadline and get_end > deadline:
            out = _p01_det(
                "interval_end_le",
                "招标文件获取截止 %s 晚于投标截止 %s" % (get_end, deadline),
                mg.group(0), [str(get_end), str(deadline)],
                "get_end(%s) > deadline(%s)" % (get_end, deadline))
    msp = re.search(r"(\d{4}年\d{1,2}月\d{1,2}日[^至到。；，]{0,8})至投标文件递交的截止时间止"
                    r"[（(]不少于(\d+)日[）)]", t)
    if msp and dl:
        start = _p01_parse_date(msp.group(1))
        deadline = _p01_parse_date(dl.group(1))
        need = int(msp.group(2))
        if start and deadline:
            gap = (deadline - start).days
            if gap < need:
                return out or _p01_det(
                    "window_gap_le",
                    "获取开始 %s 至投标截止 %s 仅 %d 日 < 约定「不少于%d日」"
                    % (start.date(), deadline.date(), gap, need),
                    msp.group(0), [str(start.date()), str(deadline.date()), "%d日" % gap],
                    "(deadline-start).days=%d < need=%d" % (gap, need))
    return out


def _p01_count_claim(t: str):
    """⑥ 声明数 ≠ 枚举数：「N项（A和B）」枚举少于声明。"""
    for m in re.finditer(r"(\d+)项([^（(。；]{0,6})[（(]([^）)]{2,60})[）)]", t):
        claim = int(m.group(1))
        body = m.group(3)
        if re.search(r"任意|任一|之一|其一", body):
            continue
        parts = [p for p in re.split(r"[和及、与]", body) if p]
        if claim >= 2 and len(parts) == 1:
            return _p01_det(
                "count_claim_mismatch",
                "声明 %d 项，括号内仅枚举 %d 项" % (claim, len(parts)),
                m.group(0), ["声明=%d" % claim, "枚举=%d" % len(parts)],
                "len(enum)=%d != %d" % (len(parts), claim))
    return None


# ---------------------------------------------------------------------------
# P01 确定性判据扩展（2026-11-22，operator-criteria）
#
# 依据：docs/qa/算子级确定性判据扩展_20261122.md 的覆盖矩阵。P01 83 个点位里有
# 一批点位的「注入违规」本身就是**文内可复算的算术/单位/日期/主体矛盾**：
#   ① 合计/分项：总投资 vs 工程费用、评标总分 vs 分项分值、改造面积 vs 分栋面积、
#      路线全长 vs 分段里程、总工期 vs 设计+施工、标段数 vs 标段序号、涵洞分项、
#      R 值 vs 平均值上下家数、技术标表头 vs 子项分值、企业业绩门类满分 vs 单项上限；
#   ② 单位/量纲：同一工期标签同时出现「日历天 / 工作日」、同一「降压站X KV 出线」
#      出现两个电压等级、单套限价被写成元/批；
#   ③ 业绩口径：类似业绩门槛金额 > 本项目估算价/设计费；同一业绩要求两个起算年份；
#   ④ 主体角色：同一「招标人」出现两个名称；项目负责人与招标管理人员同名。
# 与既有 4 个点位（C01-005/C09-001/C10-001/F02-007）同口径：只做取数+算术比较，
# 不新增执行器；判不了返回 None（调用方保留语义模型结论，不猜）。
# 引文一律由 _p01_raw_quote 回填原文整行切片；取不到原文行由 guard_judged 降级
# insufficient（fail-closed）。
# ---------------------------------------------------------------------------
_P01_SUM_CODES = ("C01-001", "C06-003", "F08-002", "A01-005")
# 允许把「模型判 insufficient/na」也接管为确定性 fail 的点位（第二跳）。
# 旧 4 个点位保持历史口径（只在模型 pass 时接管），避免无谓放大。
# 2026-11-22 第二批：5 个「强制模态 vs 替代/豁免」点位同样纳入第二跳。
_P01_SECOND_HOP_CODES = _P01_SUM_CODES + ("A02-004", "F02-004", "A02-006",
                                          "F01-006", "A02-002",
                                          # 2026-11-23 第三批 4 码（模型 insufficient/na 也接管）
                                          "A01-003", "C08-003", "B03-002", "C09-002")

_CN_NUM = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
           "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}


def _p01_fnum(x):
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return None


def _p01_cn_int(s):
    s = str(s or "").strip()
    if s.isdigit():
        return int(s)
    if s in _CN_NUM:
        return _CN_NUM[s]
    if "十" in s:
        a, _, b = s.partition("十")
        return _CN_NUM.get(a, 1) * 10 + (_CN_NUM.get(b, 0) if b else 0)
    return None


def _p01_det2(rule, detail, fragment, operands, recompute):
    return _p01_det(rule, detail, fragment, operands, recompute)


def _p01_sum_total(t: str):
    """C01-001 分项与合计相符：合计/分项复算（只报「确定不等」）。"""
    # ① 工程费用（分项）> 项目总投资（合计）
    m = re.search(r"总投资约?(\d+(?:\.\d+)?)万元[^\n]{0,10}?其中工程费用约?(\d+(?:\.\d+)?)万元", t)
    if m:
        total, part = _p01_fnum(m.group(1)), _p01_fnum(m.group(2))
        if total is not None and part is not None and part > total + 1e-9:
            return _p01_det2("sum_part_gt_total",
                             "工程费用 %g 万元 > 项目总投资 %g 万元（分项大于合计）" % (part, total),
                             m.group(0), ["总投资=%g万元" % total, "工程费用=%g万元" % part],
                             "part=%.2f > total=%.2f" % (part, total))
    # ② 评标总分 = 分项分值合计
    for line in t.splitlines():
        m = re.search(r"总分(?:为|是)?\s*(\d+(?:\.\d+)?)分[^\n]{0,3}其中([^\n]+)", line)
        if not m:
            continue
        total = _p01_fnum(m.group(1))
        vals = [_p01_fnum(x) for x in re.findall(r"(\d+(?:\.\d+)?)分", m.group(2))]
        vals = [v for v in vals if v is not None]
        if total is None or len(vals) < 3:
            continue
        s = sum(vals)
        if abs(s - total) > 1e-6:
            return _p01_det2("sum_score_total",
                             "评标总分 %g 分 ≠ 分项合计 %g 分（%s）"
                             % (total, s, "+".join("%g" % v for v in vals)),
                             m.group(0)[:160], ["总分=%g分" % total,
                                               "分项=" + "+".join("%g" % v for v in vals) + "=%g分" % s],
                             "sum(parts)=%.2f != total=%.2f" % (s, total))
    # ③ 改造面积（合计）= 分栋建筑面积（分项）合计
    mt = re.search(r"改造面积约?(\d+(?:\.\d+)?)平方米", t)
    subs = [_p01_fnum(x) for x in re.findall(r"建筑面积约?(\d+(?:\.\d+)?)平方米", t)]
    subs = [v for v in subs if v is not None]
    if mt and len(subs) >= 2:
        total = _p01_fnum(mt.group(1))
        s = sum(subs)
        if total is not None and abs(s - total) > 1e-6:
            return _p01_det2("sum_area_total",
                             "改造面积 %g 平方米 ≠ 分栋建筑面积合计 %g 平方米" % (total, s),
                             mt.group(0), ["改造面积=%g" % total,
                                           "分栋=" + "+".join("%g" % v for v in subs) + "=%g" % s],
                             "sum(sub_areas)=%.2f != total=%.2f" % (s, total))
    # ④ 路线全长（合计）= 各段里程（分项）合计（≥3 段才复算）
    mt = re.search(r"路线全长(\d+(?:\.\d+)?)公里", t)
    segs = [_p01_fnum(x) for x in re.findall(r"段全长(\d+(?:\.\d+)?)公里", t)]
    segs = [v for v in segs if v is not None]
    if mt and len(segs) >= 3:
        total = _p01_fnum(mt.group(1))
        s = sum(segs)
        if total is not None and abs(s - total) > 0.05:
            return _p01_det2("sum_route_total",
                             "路线全长 %g 公里 ≠ 分段里程合计 %g 公里" % (total, s),
                             mt.group(0), ["路线全长=%g公里" % total,
                                           "分段=" + "+".join("%g" % v for v in segs) + "=%g公里" % s],
                             "sum(segments)=%.3f != total=%.3f" % (s, total))
    # ⑤ 总工期 = 设计工期 + 施工工期
    mt = re.search(r"总工期(?:要求)?[：:为]?\s*(\d+)日历天", t)
    md = re.search(r"设计工期[：:]\s*(\d+)日历天", t)
    ms = re.search(r"施工工期[：:]\s*(\d+)日历天", t)
    if mt and md and ms:
        total, design, build = int(mt.group(1)), int(md.group(1)), int(ms.group(1))
        if total != design + build:
            return _p01_det2("sum_duration_total",
                             "总工期 %d 日历天 ≠ 设计工期 %d + 施工工期 %d = %d 日历天"
                             % (total, design, build, design + build),
                             mt.group(0), ["总工期=%d" % total,
                                           "设计=%d" % design, "施工=%d" % build],
                             "%d + %d = %d != %d" % (design, build, design + build, total))
    # ⑥ 标段数（声明）= 标段序号上界（枚举）
    m = re.search(r"划分([一二三四五六七八九十两\d]+)个标段", t)
    if m:
        n = _p01_cn_int(m.group(1))
        idx = [int(x) for x in re.findall(r"标段(\d+)(?:[【\s:：]|$)", t)]
        if n and idx and max(idx) > n:
            return _p01_det2("count_section",
                             "声明划分 %d 个标段，但正文出现标段%d（枚举数 > 声明数）"
                             % (n, max(idx)),
                             "标段%d" % max(idx), ["声明=%d个标段" % n, "最大标段序号=%d" % max(idx)],
                             "max(section_index)=%d > declared=%d" % (max(idx), n))
    # ⑦ 涵洞分项合计 = 总数
    mt = re.search(r"涵洞(?:共)?(\d+)道", t)
    if mt:
        parts = []
        for name in ("钢筋混凝土板涵", "钢波纹管涵", "盖板涵", "圆管涵", "箱涵"):
            parts += [int(x) for x in re.findall(name + r"(\d+)道", t)]
        if len(parts) >= 2:
            total = int(mt.group(1))
            s = sum(parts)
            if s > total:
                return _p01_det2("sum_culvert_total",
                                 "涵洞分项合计 %d 道 > 总数 %d 道" % (s, total),
                                 mt.group(0), ["总数=%d道" % total,
                                               "分项=%s=%d道" % ("+".join(map(str, parts)), s)],
                                 "sum(parts)=%d > total=%d" % (s, total))
    # ⑧ 入围家数：平均值以上 + 平均值以下 = R
    mr = re.search(r"R取值为[：:]?\s*(\d+)", t)
    mm = re.search(r"平均值以上\s*(\d+)\s*家[、,，]?\s*平均值以下\s*(\d+)\s*家", t)
    if mr and mm:
        r = int(mr.group(1))
        a, b = int(mm.group(1)), int(mm.group(2))
        if a + b != r:
            return _p01_det2("sum_rank_count",
                             "入围家数：平均值以上 %d + 以下 %d = %d ≠ R 值 %d"
                             % (a, b, a + b, r),
                             mm.group(0), ["R=%d" % r, "以上=%d" % a, "以下=%d" % b],
                             "%d + %d = %d != R=%d" % (a, b, a + b, r))
    # ⑨ 表头门类满分 = 子项分值合计（按「门类(总分) | 子项(分值)」表格行）
    mh = re.search(r"设计方案\s*\(?(\d+)\s*分\)?", t)
    if mh:
        sub = []
        for line in t.splitlines():
            mm = re.search(r"设计方案\s*\(?(\d+)\s*分\)?\|([^|\n]{0,20})\((\d+)\s*分\)", line)
            if mm and int(mm.group(1)) == int(mh.group(1)):
                sub.append(int(mm.group(3)))
        if len(sub) >= 3 and sum(sub) != int(mh.group(1)):
            return _p01_det2("sum_subscore_total",
                             "设计方案门类 %s 分 ≠ 子项合计 %d 分" % (mh.group(1), sum(sub)),
                             mh.group(0), ["门类=%s分" % mh.group(1),
                                           "子项=%s=%d分" % ("+".join(map(str, sub)), sum(sub))],
                             "sum(sub_scores)=%d" % sum(sub))
    # ⑩ 企业业绩单项上限 ≤ 门类满分
    mc = re.search(r"企业业绩\s*\((\d+)分\)", t)
    if mc:
        tail = t[mc.end():mc.end() + 400]
        mx = re.search(r"最多得\s*(\d+)\s*分", tail)
        if mx and int(mx.group(1)) > int(mc.group(1)):
            return _p01_det2("score_cap_over_total",
                             "企业业绩单项上限 %s 分 > 门类满分 %s 分"
                             % (mx.group(1), mc.group(1)),
                             mc.group(0), ["门类满分=%s分" % mc.group(1),
                                           "单项上限=%s分" % mx.group(1)],
                             "cap=%s > total=%s" % (mx.group(1), mc.group(1)))
    return None


def _p01_unit_dim_check(t: str):
    """C06-003 单位量纲和计量基准可比：同标签/同取值单位冲突。"""
    # ① 同一工期标签同一数值同时出现「日历天」与「工作日」
    occ = {}
    for m in re.finditer(r"(计划工期|总工期|设计服务期|施工工期|服务期)"
                         r"[：:为]?\s*(\d+)\s*(日历天|个工作日|工作日|天)", t):
        occ.setdefault((m.group(1), m.group(2)), []).append((m.group(3), m.group(0)))
    for (label, num), items in occ.items():
        units = {u for u, _ in items}
        if "日历天" in units and ("工作日" in units or "个工作日" in units):
            _u, frag = next(x for x in items if "工作日" in x[0])
            return _p01_det2("unit_calendar_workday",
                             "同一「%s %s」同时按「日历天」与「工作日」计量（单位口径漂移）"
                             % (label, num), frag,
                             ["%s=%s" % (label, num), "单位=日历天/工作日"],
                             "calendar_day vs workday")
    # ② 明确「日历天」却按实际工作日统计同一数字
    m = re.search(r"(\d+)日历天[^\n]{0,30}?(\d+)天按实际工作日统计", t)
    if m and m.group(1) == m.group(2):
        return _p01_det2("unit_calendar_workday",
                         "「%s日历天」与「%s天按实际工作日统计」口径冲突" % (m.group(1), m.group(2)),
                         m.group(0)[:160], ["日历天=%s" % m.group(1), "工作日=%s" % m.group(2)],
                         "calendar_day != workday")
    # ③ 同一「降压站 X KV 出线」出现两个电压等级
    m = re.search(r"降压站(\d+)KV出线", t)
    vals = sorted({int(x) for x in re.findall(r"降压站(\d+)KV出线", t)})
    if m and len(vals) >= 2:
        return _p01_det2("unit_voltage_conflict",
                         "降压站出线电压等级不一致：%s KV" % " / ".join(map(str, vals)),
                         m.group(0), ["%dKV" % v for v in vals],
                         "distinct(voltage)=%s" % vals)
    # ④ 单套限价被写成批次限价（元/批 与 单套 并存）
    m = re.search(r"元/批", t)
    if m and re.search(r"单套", t):
        return _p01_det2("unit_price_basis",
                         "控制价格出现「元/批」计价，而同文明确「单套」控制价（计价基准混同）",
                         m.group(0), ["计价单位=元/批", "对照=单套控制价"],
                         "batch_price vs per_set")
    return None


def _p01_perf_check(t: str):
    """F08-002 类似业绩对应明确要求：业绩门槛 > 项目规模 / 起算年份冲突。"""
    # ① 业绩门槛金额 > 本项目估算价/设计费（以不合理条件抬高业绩门槛）
    ths = []
    for pat in (r"承担过单项合同造价(\d+(?:\.\d+)?)万元及以上",
                r"承担过单项合同设计费(?:金额)?不少于\s*(\d+(?:\.\d+)?)\s*万元",
                r"类似工程[^\n]{0,20}合同额为?\s*(\d+(?:\.\d+)?)\s*万元",
                r"合同额为?\s*(\d+(?:\.\d+)?)\s*万元及以上"):
        for m in re.finditer(pat, t):
            ths.append((_p01_fnum(m.group(1)), m.group(0)))
    sizes = []
    for pat in (r"工程估算价\s*\(?万元\)?\s*[：:]\s*(\d+(?:\.\d+)?)",
                r"估算价\s*[：:约]?\s*(\d+(?:\.\d+)?)\s*万元",
                r"项目总投资\s*[：:约]?\s*(\d+(?:\.\d+)?)\s*万元"):
        for m in re.finditer(pat, t):
            sizes.append((_p01_fnum(m.group(1)), m.group(0)))
    if not sizes:
        # 设计费作为项目规模：取不含「业绩/承担/不少于」的行
        for line in t.splitlines():
            if "设计费" in line and "万元" in line and not re.search(r"业绩|承担|不少于", line):
                m = re.search(r"设计费[^\d]{0,6}(\d+(?:\.\d+)?)\s*万元", line)
                if m:
                    sizes.append((_p01_fnum(m.group(1)), m.group(0)))
                    break
    if ths and sizes:
        th, th_frag = ths[0]
        size, _sf = sizes[0]
        if th is not None and size is not None and th > size + 1e-9:
            return _p01_det2("perf_threshold_over_scale",
                             "类似业绩门槛 %g 万元 > 本项目规模 %g 万元（业绩门槛反超项目自身规模）"
                             % (th, size), th_frag,
                             ["业绩门槛=%g万元" % th, "项目规模=%g万元" % size],
                             "threshold=%.2f > scale=%.2f" % (th, size))
    # ② 同一业绩要求出现两个不同起算年份
    starts = []
    for line in t.splitlines():
        if not re.search(r"承担过|完成过|具有.*业绩", line):
            continue
        for m in re.finditer(r"(?:自)?\s*(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日", line):
            starts.append((int(m.group(1)), int(m.group(2)), int(m.group(3)), m.group(0)))
    if len(starts) >= 2:
        uniq = {}
        for y, mo, d, frag in starts:
            uniq.setdefault((y, mo, d), frag)
        if len(uniq) >= 2:
            pairs = list(uniq.items())[:2]
            return _p01_det2("perf_start_year_conflict",
                             "同类业绩要求出现两个起算时点：%s 与 %s（认定口径不一致）"
                             % ("%04d-%02d-%02d" % pairs[0][0], "%04d-%02d-%02d" % pairs[1][0]),
                             pairs[1][1], ["起算1=%04d-%02d-%02d" % pairs[0][0],
                                           "起算2=%04d-%02d-%02d" % pairs[1][0]],
                             "distinct(start)=%d" % len(uniq))
    return None


def _p01_role_check(t: str):
    """A01-005 主体与角色指向明确：同一角色出现两个主体名 / 角色主体混同。"""
    # ① 同一「招标人」角色出现两个不同名称
    names = []
    for m in re.finditer(r"招标人为\s*([^\s，,。；;:：]{4,40})", t):
        names.append(m.group(1))
    for m in re.finditer(r"招标人[：:]\s*([^\s，,。；;:：]{4,40})", t):
        names.append(m.group(1))
    lines = t.splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "招标人" or line.strip() == "招标人：":
            for nxt in lines[i + 1:i + 4]:
                if nxt.strip():
                    names.append(nxt.strip()[:40])
                    break
    norm_names = []
    for n in names:
        if not (6 <= len(n) <= 40):
            continue
        if re.match(r"[不未将可应须予依对在与或由向从把被为的]", n):
            continue
        if not re.search(r"公司|局|委员会|政府|中心|集团|院|所|厂|银行|学校|医院", n):
            continue
        if n not in norm_names:
            norm_names.append(n)
    if len(norm_names) >= 2:
        a, b = norm_names[0], norm_names[1]
        if a not in b and b not in a:
            return _p01_det2("role_party_conflict",
                             "同一「招标人」出现两个主体：%s / %s" % (a, b),
                             b, ["招标人1=%s" % a, "招标人2=%s" % b],
                             "distinct(招标人)=2")
    # ② 项目负责人与招标管理人员同名（同一角色由两人承担）
    mp = re.search(r"项目负责人[：:]\s*([\u4e00-\u9fa5]{2,4})", t)
    mg = re.search(r"招标管理人员联系人[：:]\s*([\u4e00-\u9fa5]{2,4})", t)
    if mp and mg and mp.group(1) == mg.group(1):
        return _p01_det2("role_person_conflict",
                         "%s 同时被列为项目负责人与招标管理人员（同一角色指向两人）"
                         % mp.group(1), mp.group(0),
                         ["项目负责人=%s" % mp.group(1), "招标管理人员=%s" % mg.group(1)],
                         "same person two roles")
    return None


# ---------------------------------------------------------------------------
# P01 确定性判据第二批（2026-11-22，operator-criteria-2）
#
# 族：「强制模态 vs 替代/豁免」——A02-004 执业人员资格（14 FN）/ F02-004 响应清单覆盖
# （9）/ A02-006 分项业务与资质（8）/ F01-006 评审条件协调（8）/ A02-002 资质类别等级（7）
# 共 46 条无 finding FN（覆盖矩阵 Top5，见 docs/qa/算子级确定性判据扩展_20261122.md §6）。
#
# 接入原则（不许把语义判断题硬做成关键词匹配）：
#   · 只接「文内能取到成对事实 + 可做一致性/算术/集合比较」的子判据：
#       强制（必须/须/应/不得/只能/均须） 与 替代/豁免（可/只需/仅/无须/免除/不计入）
#       在同一对象（角色/证书/资质/人数上限/材料/流程）上并存 → 文内口径互斥；
#       合计/上限与分项/枚举做算术比较；标段集合 ∩ 回避集合做集合比较。
#   · **另一侧取不到 → 返回 None**（模型结论保留，转人工）；不做「单侧关键词出现就判」。
#   · quote 一律 _p01_raw_quote 回填原文连续切片；取不到 → guard_judged 降级 insufficient。
#   · 每个码都保留「不可判 → insufficient」分支（取数失败/模式不匹配 → None）。
#   · 本批 5 码全部加入第二跳（模型 pass/insufficient/na + 确定性不满足 → fail）。
# 依据：5 码 gold 的 46 条注入机制逐条核对（见报告 §1），每条判据都对应一个可复算的
# 文内矛盾/缺失/不一致，未使用 gold 文本作为运行时输入。
# ---------------------------------------------------------------------------
_P01_MODAL_CODES = ("A02-004", "F02-004", "A02-006", "F01-006", "A02-002")

# 注册建造师/资质专业词表（同一命名口径，跨点位复用；只做同文取值比对）
_P01_DISC = (r"(市政公用工程|水利水电工程|建筑工程|机电工程|石油化工工程|"
             r"公路工程|通信与广电工程|铁路工程|港口与航道工程|民航机场工程)")
_P01_GRADE = {"特级": 5, "甲级": 4, "一级": 4, "乙级": 3, "二级": 3,
              "丙级": 2, "三级": 2, "四级": 1}


def _p01_grade(s) -> int:
    return int(_P01_GRADE.get(str(s or "").strip(), 0))


def _p01_tech_title_inversion(t: str):
    """技术负责人职称等级 < 质量管理/安全管理负责人（同文配置标准倒挂）。"""
    mt = re.search(r"技术负责人[^;。\n]{0,20}?工程序列(初|中|高)级", t)
    mo = re.search(r"(?:质量管理负责人|安全管理负责人)[^;。\n]{0,20}?工程序列(中|高)级", t)
    if not (mt and mo):
        return None
    lv = {"初": 1, "中": 2, "高": 3}
    if lv[mt.group(1)] < lv[mo.group(1)]:
        return _p01_det2(
            "title_rank_inversion",
            "技术负责人要求「%s级」低于同文%s「%s级」（技术总负责层级倒挂）"
            % (mt.group(1), mo.group(0).split("工程序列")[0], mo.group(1)),
            mt.group(0), ["技术负责人=%s级" % mt.group(1),
                          "%s=%s级" % (mo.group(0).split("工程序列")[0], mo.group(1))],
            "rank(tech_head)=%d < rank(%s)=%d"
            % (lv[mt.group(1)], mo.group(0).split("工程序列")[0], lv[mo.group(1)]))
    return None


def _p01_pm_discipline_mismatch(t: str):
    """项目经理注册专业 ≠ 投标企业施工总承包资质专业（同文两处事实比对）。"""
    mq = re.search(_P01_DISC + r"施工总承包", t)
    if not mq:
        return None
    ent_disc = mq.group(1)
    found = []
    for mm in re.finditer(r"(?:项目负责人|项目经理)[\s\S]{0,140}?(" + _P01_DISC
                          + r")(?:\(专业\)|专业)[^;。\n]{0,24}?注册建造师", t):
        # 角色关键字与证书子句可能分处两行：引文只取证书子句（单行连续切片）
        clause = re.search(r"(?:" + _P01_DISC + r")(?:\(专业\)|专业)[^;。\n]{0,24}?注册建造师",
                           mm.group(0))
        found.append((mm.group(1), clause.group(0) if clause else mm.group(0)))
    if not found:
        return None
    if any(d == ent_disc for d, _ in found):
        return None
    disc, frag = found[0]
    return _p01_det2(
        "pm_discipline_mismatch",
        "项目经理注册专业「%s」与投标企业施工总承包资质专业「%s」不一致"
        % (disc, ent_disc), frag,
        ["企业资质专业=%s" % ent_disc, "项目经理注册专业=%s" % disc],
        "pm_disc(%s) != enterprise_qual(%s)" % (disc, ent_disc))


def _p01_same_qual_two_grades(t: str):
    """同一资质名称在同文出现两个不同等级（联合体条款 vs 主体条款降级/提级）。"""
    quals = {}
    for mm in re.finditer(r"(水利水电工程施工总承包|市政公用工程施工总承包|"
                          r"建筑工程施工总承包|机电工程施工总承包|公路工程施工总承包|"
                          r"石油化工工程施工总承包)(特级|一级|二级|三级)", t):
        quals.setdefault(mm.group(1), []).append((mm.group(2), mm.group(0)))
    for name, items in quals.items():
        grades = {g for g, _ in items}
        if len(grades) < 2:
            continue
        hi = max(items, key=lambda x: _p01_grade(x[0]))
        lo = min(items, key=lambda x: _p01_grade(x[0]))
        return _p01_det2(
            "qual_two_grades",
            "同一资质「%s」在同文出现两个等级：%s / %s（资格条件不唯一）"
            % (name, hi[0], lo[0]), lo[1],
            ["%s:%s" % (name, hi[0]), "%s:%s" % (name, lo[0])],
            "distinct(grade)=%s" % sorted(grades))
    return None


def _p01_parallel_joiner(t: str):
    """「同时具备」却用「或」连接设计资质与施工资质（并列改择一）。"""
    for mm in re.finditer(r"同时具备[^。\n]{0,240}", t):
        sent = mm.group(0)
        if re.search(r"设计[^。\n]{0,80}?资质或[^。\n]{0,16}?施工总承包", sent):
            frag_m = re.search(r"设计[^。\n]{0,80}?资质或[^。\n]{0,16}?施工总承包", sent)
            return _p01_det2(
                "parallel_to_or",
                "句首「同时具备」要求设计资质与施工资质并列，但两资质之间用「或」连接"
                "（并列关系被改为择一，只持一类即可满足）", frag_m.group(0),
                ["连接词=或", "约束词=同时具备"],
                "require(AND, design_qual + construction_qual) vs text(OR)")
    return None


def _p01_license_exemption(t: str):
    """「无须取得 X 许可证」与同文强制「具有有效的 X 许可证」并存（豁免 vs 强制许可）。"""
    m = re.search(r"无须取得([^;。\n]{2,24}?许可证)", t)
    if not m:
        return None
    key = m.group(1)
    core = key.replace("许可证", "")
    # 许可主体词：去掉「经营/生产/使用/运输/道路运输」等后缀动作词后取核心主体
    subject = re.sub(r"(道路运输|经营|生产|使用|运输)$", "", core) or core
    subj_pat = re.escape(subject) if subject else re.escape(core)
    if subj_pat and re.search(r"具有有效的[^;。\n]{0,30}?" + subj_pat
                              + r"[^;。\n]{0,24}?许可证", t):
        return _p01_det2(
            "license_exempt_conflict",
            "一般资格允许「%s」，而同文强制要求「具有有效的%s」（豁免与强制许可冲突）"
            % (m.group(0), key), m.group(0),
            ["豁免=" + m.group(0), "强制=" + key],
            "exempt(%s) vs mandatory(%s)" % ("无须取得", "具有有效的"))
    return None


def _p01_gas_grade_inversion(t: str):
    """非主体专业（燃气）资质等级高于同组配套专业（给水）：同一资质链内等级倒挂。"""
    mg = re.search(r"燃气工程\)?专业(甲级|乙级|丙级)", t)
    mw = re.search(r"给水工程\)?专业(甲级|乙级|丙级)", t)
    if not (mg and mw):
        return None
    if _p01_grade(mg.group(1)) > _p01_grade(mw.group(1)):
        return _p01_det2(
            "non_main_qual_raised",
            "非主体配套专业「燃气工程」要求%s，高于同组配套专业「给水工程」%s"
            "（同一资质链内非主体专业门槛倒挂）" % (mg.group(1), mw.group(1)),
            "燃气工程)专业" + mg.group(1) if "燃气工程)专业" in t
            else "燃气工程专业" + mg.group(1),
            ["燃气工程=" + mg.group(1), "给水工程=" + mw.group(1)],
            "grade(gas)=%d > grade(water)=%d"
            % (_p01_grade(mg.group(1)), _p01_grade(mw.group(1))))
    return None


def _p01_personnel_check(t: str):
    """A02-004 执业人员信息与资格要求对应（只报文内确定性矛盾/替代证据）。"""
    # ⑴ 岗位执业资格类别被跨专业替代：设计负责人「可由 A 替代 B」＋同文另有「设计负责人须…B」
    m = re.search(r"设计负责人可由[^;。\n]{1,20}?替代([^;。\n]{1,20})", t)
    if m:
        base = m.group(1)
        occ = list(re.finditer(r"设计负责人[^;。\n]{0,40}" + re.escape(base), t))
        if len(occ) >= 2:
            return _p01_det2(
                "cred_cross_category",
                "设计负责人岗位执业资格被跨专业替代：%s；同文另一处仍要求「%s」"
                % (m.group(0), base), m.group(0),
                ["替代条款=" + m.group(0), "另一处要求=" + base],
                "substitute(%s -> %s); same role two cert categories"
                % ("注册建造师", base))
    # ⑵ 专职在岗限制变成调度承诺：「允许同时担任其他在建」＋同文「未担任其他在建」
    m = re.search(r"允许同时担任其他在建[^;。\n]{0,30}", t)
    if m:
        m2 = re.search(r"未担任其他在建[^;。\n]{0,30}", t)
        if m2:
            return _p01_det2(
                "exclusive_duty_to_promise",
                "同一岗位一处允许「%s」，另一处要求「%s」（专职在岗限制被改成调度承诺）"
                % (m.group(0), m2.group(0)), m.group(0),
                ["允许=" + m.group(0), "禁止=" + m2.group(0)],
                "allow(concurrent) AND forbid(concurrent)")
    # ⑶ 负责人岗位资格被替代并遗漏安全证书：「施工负责人只需 X 资格」＋同文要求建造师+安全证
    m = re.search(r"施工负责人只需[^;。\n]{0,30}", t)
    if m and re.search(r"(?:专业)?[一二三四]级注册建造师", t) \
            and re.search(r"安全生产考核合格证书", t):
        return _p01_det2(
            "lead_qual_replaced_missing_safety_cert",
            "联合体条款把施工负责人资格限缩为「%s」，而同文其他承包模式要求注册建造师"
            "且持安全生产考核合格证书（岗位资格被替代并遗漏安全证书）" % m.group(0),
            m.group(0), ["限缩=" + m.group(0), "对照=注册建造师+安全生产考核合格证书"],
            "only(%s) vs required(builder + safety cert)" % m.group(0))
    # ⑷ 专职要求随承包模式被降低：同文「专职安全生产管理人员」＋「兼职…即可」
    m = re.search(r"配备\d+名兼职安全生产管理人员[^;。\n]{0,20}", t)
    if m and re.search(r"专职安全生产管理人员", t):
        return _p01_det2(
            "fulltime_to_parttime",
            "同一安全管理岗位一处要求「%s」，另一处配「%s」（专职要求被兼职降低）"
            % (re.search(r"[^;。\n]{0,12}专职安全生产管理人员[^;。\n]{0,16}", t).group(0),
               m.group(0)), m.group(0),
            ["专职=" + re.search(r"专职安全生产管理人员", t).group(0),
             "兼职=" + m.group(0)],
            "fulltime_role vs parttime_staffing")
    # ⑸ 联合体人员归属责任错配：总承包项目经理「可以为非牵头」＋同文「必须均为牵头单位」
    m = re.search(r"总承包项目经理可以为非牵头[^;。\n]{0,20}", t)
    if m and re.search(r"必须均为牵头单位正式职工", t):
        return _p01_det2(
            "joint_leader_attribution",
            "联合体条款允许「%s」，而同文要求总承包项目经理「必须均为牵头单位正式职工」"
            % m.group(0), m.group(0),
            ["允许=" + m.group(0), "强制=必须均为牵头单位正式职工"],
            "allow(non_leader staff) AND require(leader staff)")
    # ⑹ 设计负责人证书类别与施工岗位重复（设计岗位错配为建造师；同文无设计类注册证书）
    m = re.search(r"(?:项目)?设计负责人[^;。\n]{0,40}?注册建造师", t)
    if m and "注册建筑师" not in m.group(0) and re.search(
            r"施工项目经理[^;。\n]{0,40}?注册建造师", t):
        return _p01_det2(
            "design_lead_builder_cert",
            "设计负责人岗位要求「注册建造师」证书（与施工项目经理证书类别重复；"
            "设计岗位未要求设计类注册执业资格）", m.group(0),
            ["设计负责人=" + m.group(0),
             "施工项目经理=注册建造师"],
            "design_post cert(建造师) == construction_post cert(建造师)")
    # ⑺ 同一专业建造师等级倒挂：总承包项目经理低于施工项目经理
    mp = re.search(r"项目经理[\s\S]{0,200}?(" + _P01_DISC
                   + r")专业([一二三四])级", t)
    ms = re.search(r"施工项目经理[\s\S]{0,160}?(" + _P01_DISC
                   + r")专业(?:的)?([一二三四])级", t)
    if mp and ms and mp.group(1) == ms.group(1) \
            and _p01_grade(mp.group(2)) < _p01_grade(ms.group(2)):
        def _single_line(mm):
            cl = re.search(r"(?:" + _P01_DISC + r")专业(?:的)?[一二三四]级", mm.group(0))
            return cl.group(0) if cl else mm.group(0)
        return _p01_det2(
            "builder_grade_inversion",
            "同一专业（%s）注册建造师：总承包项目经理要求%s级，低于其管理的施工项目经理%s级"
            % (mp.group(1), mp.group(2), ms.group(2)),
            _single_line(ms) if "施工项目经理" in ms.group(0) else _single_line(mp),
            ["总承包项目经理=%s级" % mp.group(2), "施工项目经理=%s级" % ms.group(2)],
            "grade(pm)=%d < grade(sub_pm)=%d"
            % (_p01_grade(mp.group(2)), _p01_grade(ms.group(2))))
    # ⑻ 项目经理注册专业与企业施工资质专业错配
    det = _p01_pm_discipline_mismatch(t)
    if det:
        return det
    # ⑼ 总监注册专业与监理资质专业不一致
    ml = re.search(r"(房屋建筑工程|市政公用工程)甲级监理资质", t)
    md = re.search(r"总监理工程师[^;。\n]{0,60}?\(?(房屋建筑工程|市政公用工程)专业", t)
    if ml and md and ml.group(1) != md.group(1):
        return _p01_det2(
            "supervisor_discipline_mismatch",
            "总监理工程师注册专业「%s」与企业监理资质专业「%s」不一致"
            % (md.group(1), ml.group(1)), md.group(0),
            ["总监专业=" + md.group(1), "监理资质专业=" + ml.group(1)],
            "supervisor_disc(%s) != supervision_qual(%s)"
            % (md.group(1), ml.group(1)))
    # ⑽ 同一批标段的项目负责人职称门槛不一致（单标段被提高）
    rows = [(m.group(1), m.group(0)) for m in re.finditer(
        r"第([一二三四五六七八九十\d]+)标段:项目负责人:具有相关专业(高级|中级|初级)或以上技术职称", t)]
    if len(rows) >= 2:
        cnt = {}
        for _n, frag in rows:
            lv = re.search(r"(高级|中级|初级)", frag).group(1)
            cnt[lv] = cnt.get(lv, 0) + 1
        if len(cnt) >= 2:
            major = max(cnt, key=lambda k: (cnt[k], {"高级": 3, "中级": 2, "初级": 1}[k]))
            odd = next((x for x in rows
                        if re.search(r"(高级|中级|初级)", x[1]).group(1) != major), None)
            if odd:
                lv = re.search(r"(高级|中级|初级)", odd[1]).group(1)
                return _p01_det2(
                    "section_title_threshold",
                    "同一批标段的项目负责人职称门槛不一致：第%s标段要求%s，其余标段为%s"
                    % (odd[0], lv, major), odd[1],
                    ["异常标段=第%s标段%s" % (odd[0], lv), "其余标段=%s" % major],
                    "distinct(section_title_level)>=2")
    # ⑾ 项目经理限定由设计方人员担任，却要求施工类执业资格（主体与资格冲突）
    m = re.search(r"项目经理[^;。\n]{0,30}?必须由[^;。\n]{0,15}?设计方的人员担任", t)
    if m:
        seg = t[m.start():m.start() + 400]
        if re.search(r"一级建造师", seg) and re.search(r"施工工作经历|水安B证", seg):
            return _p01_det2(
                "pm_source_vs_construction_qual",
                "项目经理限定「%s」，却同时要求一级建造师/水安B证/施工工作经历"
                "（主体来源与执业资格类型冲突）" % m.group(0), m.group(0),
                ["限定=" + m.group(0), "资格=一级建造师+水安B证+施工工作经历"],
                "role_source(design party) vs qual(construction)")
    # ⑿ 专职安全员 B 类证书与施工项目经理 B 类重合（岗位证书类别错配）
    m1 = re.search(r"专职安全生产管理人员[^;。\n]{0,120}B类", t)
    m2 = re.search(r"(?:施工项目经理|项目负责人)[^;。\n]{0,200}B类", t)
    if m1 and m2:
        return _p01_det2(
            "safety_officer_cert_dup",
            "专职安全生产管理人员与施工项目经理同时要求安全生产考核合格证书（B类）"
            "（B 类为项目负责人证书，专职安全员应为 C 类）", m1.group(0),
            ["专职安全员=" + m1.group(0), "施工项目经理=B类"],
            "cert_class(B) assigned to both 项目负责人 and 专职安全员")
    return None


def _p01_response_item_check(t: str):
    """F02-004 响应清单覆盖适用要求（并列/全覆盖被限缩/免除）。"""
    # ⑴ 并列证明路径被限缩为单一材料：「业绩仅以 X 为准」＋同文「业绩以 X 或 Y 为准」
    m1 = re.search(r"业绩仅以[^;。\n]{1,12}为准", t)
    m2 = re.search(r"业绩以[^;。\n]{0,16}?(?:或|、)[^;。\n]{0,16}?为准", t)
    if m1 and m2:
        return _p01_det2(
            "proof_path_narrowed",
            "同一类业绩的证明路径被限缩：一处「%s」，另一处「%s」"
            % (m2.group(0), m1.group(0)), m1.group(0),
            ["并列=" + m2.group(0), "限缩=" + m1.group(0)],
            "proof(OR) vs proof(only)")
    # ⑵ 联合体财务审查范围缩减：「仅联合体牵头人须提供报表」＋「联合体所有成员均须符合」
    m1 = re.search(r"仅联合体牵头人须提供报表[^;。\n]{0,20}", t)
    if m1 and re.search(r"联合体所有成员均须符合要求", t):
        return _p01_det2(
            "joint_finance_scope_reduced",
            "联合体财务审查范围被缩减：一处「%s」，另一处「联合体所有成员均须符合要求」"
            % m1.group(0), m1.group(0),
            ["缩减=" + m1.group(0), "对照=联合体所有成员均须符合要求"],
            "only(leader reports) vs all members comply")
    # ⑶ 全覆盖设计要求被抽样替代：「每层每个房间」＋「仅提供一个代表房间即可」
    m1 = re.search(r"每[^;。，\n]{0,4}?每个[^;。，\n]{0,6}", t)
    m2 = re.search(r"仅提供[^;。\n]{0,8}?代表[^;。\n]{0,8}", t)
    if m1 and m2:
        return _p01_det2(
            "full_coverage_to_sample",
            "设计要求由全覆盖改为抽样：「%s…」却「%s」（其他房间视为被代表图覆盖）"
            % (m1.group(0), m2.group(0)), m2.group(0),
            ["全覆盖=" + m1.group(0), "抽样=" + m2.group(0)],
            "coverage(each room) vs sample(one representative)")
    # ⑷ 按标段缴纳被改为按项目合并：「按项目合并递交投标保证金」＋「分配至对应标段」
    m = re.search(r"按项目合并[^;。\n]{0,20}投标保证金", t)
    if m and re.search(r"分配\(?至对应标段|按标段递交|对应标段\(包\)", t):
        return _p01_det2(
            "deposit_by_section_replaced",
            "保证金缴纳口径矛盾：一处「%s」，后文仍要求「分配至对应标段（包）」"
            "（按标段缴纳被改为按项目合并）" % m.group(0), m.group(0),
            ["合并缴纳=" + m.group(0), "对照=分配至对应标段"],
            "per_section deposit vs merged deposit")
    # ⑸ 代理商准入与后续条款矛盾：「不允许代理商投标」＋同句仍以代理商为前提
    m = re.search(r"不允许代理商投标", t)
    if m and re.search(r"投标人为代理商的", t):
        return _p01_det2(
            "agent_admission_conflict",
            "准入条款「%s」与后续「投标人为代理商的…多家代理商代理同一服务时均将被否决」"
            "自相矛盾（禁止代理商参与却以代理商参与为前提设否决规则）"
            % m.group(0), m.group(0),
            ["准入=不允许代理商投标", "后续=投标人为代理商的…"],
            "forbid(agent) AND regulate(agent)")
    # ⑹ 资质与业绩并列条件缺项：「免除业绩证明」＋同文要求「同时具有…业绩」
    m1 = re.search(r"免除业绩证明", t)
    m2 = re.search(r"同时具有[^;。\n]{0,30}?业绩", t)
    if m1 and m2:
        return _p01_det2(
            "qual_and_perf_exempted",
            "资质与业绩并列条件被免除：一处允许「%s」，同文要求「%s」"
            % (m1.group(0), m2.group(0)), m1.group(0),
            ["免除=" + m1.group(0), "并列=" + m2.group(0)],
            "perf required(AND) vs exempted")
    # ⑺ 未来承诺替代现有管理体系：「以…承诺替代 QHSE 组织机构」＋「具有 QHSE 组织机构」
    m1 = re.search(r"以遵守[^;。\n]{0,12}?承诺替代[^;。\n]{0,20}", t)
    if m1 and re.search(r"具有QHSE管理组织机构及职责", t):
        return _p01_det2(
            "promise_replaces_system",
            "「%s」，而同文资格要求「具有 QHSE 管理组织机构及职责、规章制度」"
            "（承诺不能替代现有管理体系）" % m1.group(0), m1.group(0),
            ["替代=" + m1.group(0), "要求=具有QHSE管理组织机构及职责"],
            "commitment replaces existing organization")
    # ⑻ 查询证明改为口头说明：「提供查询结果」＋「可仅作口头说明，无需提供」
    m = re.search(r"可仅作口头说明[^;。\n]{0,20}", t)
    if m and re.search(r"提供[^;。\n]{0,20}查询结果", t):
        return _p01_det2(
            "proof_to_oral_statement",
            "同句既要求「提供查询结果」，又允许「%s」（证明要求被口头说明替代）"
            % m.group(0), m.group(0),
            ["要求=提供查询结果", "替代=" + m.group(0)],
            "required(proof) vs oral(statement)")
    # ⑼ 联合体成员资质材料免除：「无需提供联合体其他成员资质证书」＋「成员单位须具有资质」
    m = re.search(r"无需提供联合体其他成员[^;。\n]{0,20}", t)
    if m and re.search(r"联合体成员中承担[^;。\n]{0,10}工作的单位须具有", t):
        return _p01_det2(
            "member_qual_proof_exempted",
            "「%s」，而同文要求联合体成员中承担各专业工作的单位须具有相应资质"
            "（成员资质材料被免除，招标人无法核验）" % m.group(0), m.group(0),
            ["免除=" + m.group(0), "对照=联合体成员中承担…工作的单位须具有资质"],
            "proof of member qualification waived")
    return None


def _p01_business_qual_check(t: str):
    """A02-006 分项业务与资质要求对应（身份/专业范围/专项准入/业绩门槛）。"""
    # ⑴ 投标身份与强制资格冲突：「供货商应为制造商」＋「投标人可为代理经销商」
    m1 = re.search(r"应为[^;。\n]{0,20}?制造商|应是[^;。\n]{0,20}?制造商", t)
    m2 = re.search(r"可为[^;。\n]{0,20}?代理经销商|只承担销售和交付的代理经销商", t)
    if m1 and m2:
        return _p01_det2(
            "manufacturer_vs_agent",
            "投标身份矛盾：一处强制「%s」，另一处允许「%s」"
            % (m1.group(0), m2.group(0)), m2.group(0),
            ["强制身份=" + m1.group(0), "替代身份=" + m2.group(0)],
            "require(manufacturer) vs allow(agent)")
    # ⑵ 资质交叉引用指向错误专业：「设计分包单位只需满足施工企业…条款」
    m = re.search(r"设计分包单位[^;。\n]{0,10}?(?:施工企业|施工单位)[^;。\n]{0,20}", t)
    if m:
        return _p01_det2(
            "cross_ref_wrong_discipline",
            "设计分包单位的资质被交叉引用到「%s」（设计专业被指向施工资质条款）"
            % m.group(0), m.group(0),
            ["引用=" + m.group(0), "对照=3.2.2设计单位投标"],
            "design subcontractor -> construction clause")
    # ⑶ 回避标段范围未覆盖全部同业务标段（水保方案编制单位）
    m = re.search(r"水土保持方案编制单位均不得参加第[^;。\n]{0,24}?标段的投标", t)
    if m:
        seg_nums = {int(x) for x in re.findall(r"\d+", m.group(0))}
        wb_nums = set()
        for mm in re.finditer(r"第(\d+)标段\|([^|\n]{0,40})", t):
            if "水土保持" in mm.group(2) or "水保" in mm.group(2):
                wb_nums.add(int(mm.group(1)))
        miss = sorted(wb_nums - seg_nums)
        extra = sorted(seg_nums - wb_nums)
        if wb_nums and miss:
            return _p01_det2(
                "avoid_section_scope",
                "水保方案编制单位回避标段范围与业务属性错位：回避段落含第%s标段，"
                "但水保类标段为第%s标段%s"
                % ("、".join(map(str, sorted(seg_nums))),
                   "、".join(map(str, sorted(wb_nums))),
                   ("，未覆盖第%s标段" % "、".join(map(str, miss))) if miss
                   else ("，却无谓排除非水保标段第%s" % "、".join(map(str, extra)))),
                m.group(0), ["回避标段=" + "、".join(map(str, sorted(seg_nums))),
                            "水保标段=" + "、".join(map(str, sorted(wb_nums)))],
                "avoid_set=%s vs water_soil_set=%s" % (sorted(seg_nums), sorted(wb_nums)))
    # ⑷ 个人履历与企业承接业绩对象混淆：「不是投标人承接」＋「作为投标人企业业绩」
    m = re.search(r"不是投标人承接[^;。\n]{0,20}", t)
    if m and re.search(r"作为投标人企业业绩[^;。\n]{0,10}", t):
        return _p01_det2(
            "personal_vs_company_perf",
            "「%s」却「作为投标人企业业绩直接认可」（个人参与不等于企业承接）"
            % m.group(0), m.group(0),
            ["事实不是投标人承接", "却作为投标人企业业绩"],
            "non_self_project recognized as company performance")
    # ⑸ 资质专业范围漏项：市政行业（道路工程）专业资质＋项目含排水/雨污分流
    m = re.search(r"市政行业\(([^)]{1,40})\)专业(?:设计)?[甲乙丙]级", t)
    if m:
        profs = m.group(1)
        if "道路工程" in profs and "排水工程" not in profs \
                and re.search(r"雨污分流|排水工程|排水设计", t):
            return _p01_det2(
                "qual_profession_missing",
                "市政行业（%s）专业设计资质未包含「排水工程」，但招标范围含雨污分流/排水"
                "（资质专业范围漏项，该路径允许无排水专业资质承接排水设计）" % profs,
                m.group(0), ["资质专业=" + profs, "项目范围=含雨污分流/排水"],
                "required_water_discipline not in qual_professions")
    # ⑹ 安全生产许可证主体由施工错为设计
    m = re.search(r"设计单位[^;。\n]{0,10}?安全生产许可证", t)
    if m:
        return _p01_det2(
            "safety_license_wrong_subject",
            "安全生产许可证被要求由「%s」持有（该证与施工主体绑定，主体错配）"
            % m.group(0), m.group(0),
            ["被要求主体=设计单位", "证书=安全生产许可证"],
            "safety_license(wrong subject: design unit)")
    # ⑺ 基础主体资格替代专项准入：「营业执照即可/不再核查资源库」＋「须为资源库内承包商」
    m1 = re.search(r"按承包商准入合格处理[^;。\n]{0,20}|不再核查资源库状态", t)
    if m1 and re.search(r"资源库内承包商", t):
        return _p01_det2(
            "basic_qual_replaces_admission",
            "「%s」，而同文要求「投标人需为…承包商资源库内承包商」"
            "（营业执照/已领取执照不能替代专项准入）" % m1.group(0), m1.group(0),
            ["替代=" + m1.group(0), "要求=资源库内承包商"],
            "business_license treated as resource-pool admission")
    # ⑻ 业绩单机容量门槛高于本项目自身单机容量
    mproj = re.search(r"单机容量为(\d+)MW|安装\d+台单机容量为(\d+)MW", t)
    mth = re.search(r"单机容量[^;。\n]{0,4}?[≧≥>=]{1,2}\s*(\d+)\s*MW", t)
    if mproj and mth:
        proj = int(mproj.group(1) or mproj.group(2))
        th = int(mth.group(1))
        if th > proj:
            return _p01_det2(
                "perf_unit_capacity_over_project",
                "业绩门槛「单机容量≥%dMW」高于本项目自身单机容量 %dMW"
                "（业绩门槛反超项目规模）" % (th, proj), mth.group(0),
                ["业绩门槛=%dMW" % th, "项目单机容量=%dMW" % proj],
                "threshold(%dMW) > project(%dMW)" % (th, proj))
    return None


def _p01_review_condition_check(t: str):
    """F01-006 评审条件与需求协调（流程/账户/篇幅/分值/日期/上限集合）。"""
    from datetime import date as _date
    # ⑴ 并行流程误作可替代流程：「任意一个即为报名成功」＋「均需完成才算作报名成功」
    m = re.search(r"任意一个即为报名成功|完成任意一个即为[^;。\n]{0,10}", t)
    if m and re.search(r"均需完成", t):
        return _p01_det2(
            "parallel_to_optional",
            "两个并行/并列步骤被改为可替代：一处「%s」，另一处要求「均需完成」"
            % m.group(0), m.group(0),
            ["可替代=" + m.group(0), "强制=均需完成"],
            "each_required(AND) vs any_one(OR)")
    # ⑵ 动态项目账户被静态历史账户替代：「沿用上次项目的汇款路径」＋「根据系统显示收款账号」
    m = re.search(r"沿用上次项目的汇款路径[^;。\n]{0,20}", t)
    if m and re.search(r"根据系统显示收款账号|动态生成|唯一的汇款路径", t):
        return _p01_det2(
            "dynamic_account_to_static",
            "「%s」，而同文要求按本项目动态生成的收款账号汇款"
            "（动态项目账户被静态历史账户替代）" % m.group(0), m.group(0),
            ["替代=" + m.group(0), "对照=根据系统显示收款账号/动态生成"],
            "static(reuse path) vs dynamic(per-project account)")
    # ⑶ 总篇幅上限 > 分项页数上限合计（评分约束失效）
    mt = re.search(r"总篇幅不超过\s*(\d+)\s*页", t)
    parts = [int(x) for x in re.findall(r"\(≤(\d+)页\)", t)]
    if mt and len(parts) >= 3:
        total, s = int(mt.group(1)), sum(parts)
        if total > s:
            return _p01_det2(
                "page_limit_exceeds_sum",
                "总篇幅上限 %d 页 > 各评审要点分项上限合计 %d 页（%s）"
                % (total, s, "+".join(map(str, parts))), mt.group(0),
                ["总篇幅=%d页" % total,
                 "分项=" + "+".join(map(str, parts)) + "=%d页" % s],
                "total(%d) > sum(parts)=%d" % (total, s))
    # ⑷ 报价满分与报价分值设置不符：「投标报价（M分」＋「评标价等于评标基准价的得分N分」
    mh = re.search(r"投标报价\s*\((\d+)分", t)
    mb = re.search(r"评标价等于评标基准价的得分(\d+)分", t)
    if mh and mb:
        full, base = int(mh.group(1)), int(mb.group(1))
        if full != base:
            return _p01_det2(
                "price_full_score_mismatch",
                "投标报价满分 %d 分，但「评标价等于评标基准价的得分 %d 分」"
                "（报价项可得上限低于设置满分，总分无法闭合）" % (full, base),
                mb.group(0),
                ["满分=%d分" % full, "基准价得分=%d分" % base],
                "full_score(%d) != base_price_score(%d)" % (full, base))
    # ⑸ 文件获取截止晚于投标截止/提交时间
    mg = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日至(\d{4})年(\d{1,2})月(\d{1,2})日"
                   r"[^;。\n]{0,30}?(?:内完成|获取|下载|报名)", t)
    md = re.search(r"(?:建议于|投标截止时间|递交的截止时间|提交时间)[^;。\n]{0,30}?"
                   r"(\d{4})年(\d{1,2})月(\d{1,2})日", t)
    if mg and md:
        get_end = _date(int(mg.group(4)), int(mg.group(5)), int(mg.group(6)))
        deadline = _date(int(md.group(1)), int(md.group(2)), int(md.group(3)))
        if get_end > deadline:
            return _p01_det2(
                "get_deadline_after_bid",
                "招标文件获取截止 %s 晚于投标截止/提交时间 %s（获取期覆盖投标期）"
                % (get_end.isoformat(), deadline.isoformat()), mg.group(0),
                ["获取截止=" + get_end.isoformat(), "投标截止=" + deadline.isoformat()],
                "get_end(%s) > bid_deadline(%s)"
                % (get_end.isoformat(), deadline.isoformat()))
    # ⑹ 关联企业上限超过组内标段数
    ms = re.search(r"组内划分为(\d+)个标段", t)
    ml = re.search(r"具有关联关系的投标人数量不得超过组内的标段数量(\d+)名", t)
    if ms and ml and int(ml.group(1)) > int(ms.group(1)):
        return _p01_det2(
            "related_cap_over_sections",
            "关联企业投标人上限 %s 名 > 组内标段数 %s（上限超过标段数）"
            % (ml.group(1), ms.group(1)), ml.group(0),
            ["上限=%s名" % ml.group(1), "标段数=%s" % ms.group(1)],
            "cap(%s) > sections(%s)" % (ml.group(1), ms.group(1)))
    # ⑺ 中标候选人限制范围扩大：同文「中标候选人第一名」与「中标候选人」（无第一名）并存
    m1 = re.search(r"不接受有在建、已中标未开工或已列为其他项目中标候选人第一名", t)
    m2 = re.search(r"不接受有在建、已中标未开工或已列为其他项目中标候选人的", t)
    if m1 and m2:
        return _p01_det2(
            "candidate_scope_expanded",
            "同一限制一处为「已列为其他项目中标候选人第一名」，另一处扩大为"
            "「已列为其他项目中标候选人」（无「第一名」限定，否决范围被扩大）",
            m2.group(0),
            ["原限定=中标候选人第一名", "扩大=中标候选人"],
            "candidate(first only) vs candidate(any rank)")
    return None


def _p01_qual_grade_check(t: str):
    """A02-002 资质类别等级符合明确要求（豁免/等级/并列/专业错配）。"""
    det = _p01_license_exemption(t)
    if det:
        return det
    det = _p01_tech_title_inversion(t)
    if det:
        return det
    det = _p01_same_qual_two_grades(t)
    if det:
        return det
    det = _p01_parallel_joiner(t)
    if det:
        return det
    det = _p01_gas_grade_inversion(t)
    if det:
        return det
    return _p01_pm_discipline_mismatch(t)


# ===========================================================================
# CT 通用审核点 · 文内确定性算术核对（2026-11-22，CT 进了清单也不判）
#
# 依据 docs/qa/CT进了清单也不判_20261123.md：CT 44 份修路由后 810 条 FN 中
# D4/D5 判 na/pass/insufficient = 401 条（49.5%）；其中**单一点位码 D10-004
# 「公式变量与定义一致」判 na = 99 条（283 条 na 的 35%）**，分布在 10 份
# 统计公报类文档（CT-087~097 中的 9 份可复算）。gold 机制全部是「公布值 vs
# 同文可复算值不一致」（占比/差额/比值/增长率/研发强度），与点位判据
# 「每个实际使用变量可定位定义单位及取值」完全同口径 → 可用确定性算子判。
#
# 只做取数 + 算术比较，不新增执行器；判不了 → None（保留模型结论，不猜）。
# 引文取**原文连续切片**（_p01_raw_quote 同口径）；取不到由 guard_judged
# 降级 insufficient（fail-closed，不绕引文门禁）。
# 与 P01 码不重叠（D10-004 为平台通用审核点），不影响 P01 既有接管。
# ===========================================================================
_CT_DET_CODES = ("D10-004",)
# 允许把「模型判 insufficient/na」也接管为确定性 fail 的 CT 点位（第二跳）。
_CT_SECOND_HOP_CODES = ("D10-004",)


def _ct_num(x):
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return None


def _ct_label_value(t: str, label: str):
    """label 后（允许注脚/为/是/达到/支出等衔接词）最近的数字。"""
    m = re.search(re.escape(label) + r"(?:\[[^\]]*\])?"
                  r"(?:为|是|达到|达|支出|投入|共计|总计)?([\d,]+(?:\.\d+)?)", t)
    return _ct_num(m.group(1)) if m else None


def _ct_disclosure_check(t: str):
    """D10-004 公式变量与定义一致：公布值 vs 同文可复算值（只报「确定不一致」）。

    已接 6 类文内可复算事实（均为统计公报/披露文件的高频结构）：
      ① 增加值构成比：第X产业增加值 ÷ GDP  vs 「第X产业增加值(占国内生产总值)比重为P%」
      ② 研发强度：研发经费 ÷ GDP vs 「与国内生产总值之比为P%」
      ③ 进出口差额：出口 − 进口 vs 「货物进出口顺差/服务进出口逆差N亿元」
      ④ 城乡收入比值：城镇均值 ÷ 农村均值 vs 「城乡居民人均可支配收入比值为R」
      ⑤ 服务消费占比：服务性消费支出 ÷ 居民人均消费支出 vs 「占…比重为P%」
      ⑥ 同比变动率：(变动量) ÷ (本期∓变动量) vs 「…，比上年增加/减少M，增长/下降P%」
    容差按公布精度（占比 0.20pp、比值 0.02、增长率 0.05pp、差额 max(2,0.1%)）；
    容差内视为「与公布精度相容」，不判不满足（宁少勿滥）。
    """
    out = []

    def _hit(rule, detail, fragment, operands, recompute):
        out.append(_p01_det(rule, detail, fragment, operands, recompute))

    # ① 增加值构成比（GDP / 三次产业）
    gdp = _ct_label_value(t, "国内生产总值")
    inds = {}
    for k, lab in (("一", "第一产业增加值"), ("二", "第二产业增加值"), ("三", "第三产业增加值")):
        v = _ct_label_value(t, lab)
        if v is not None:
            inds[k] = v
    if gdp:
        for k, lab in (("一", "第一产业"), ("二", "第二产业"), ("三", "第三产业")):
            if k not in inds:
                continue
            comp = inds[k] / gdp * 100
            for pat in (lab + r"增加值占国内生产总值比重为([\d.]+)%",
                        lab + r"增加值比重为([\d.]+)%"):
                for m in re.finditer(pat, t):
                    stated = _ct_num(m.group(1))
                    if stated is None:
                        continue
                    if abs(stated - comp) > 0.20:
                        _hit("ct_gdp_composition",
                             "%s增加值 %g 亿元 ÷ 国内生产总值 %g 亿元 = %.4f%%，"
                             "但公布比重为 %s%%（超出公布精度）"
                             % (lab, inds[k], gdp, comp, m.group(1)),
                             m.group(0), ["%g亿元" % inds[k], "%g亿元" % gdp],
                             "%g/%g*100=%.4f%%" % (inds[k], gdp, comp))
        # ② 研发强度
        rd = None
        for lab in ("研究与试验发展（R&D）经费", "研究与试验发展(R&D)经费",
                    "研究与试验发展经费", "研发经费支出", "研发经费"):
            rd = _ct_label_value(t, lab)
            if rd:
                break
        if rd:
            for m in re.finditer(r"与国内生产总值之比为([\d.]+)%", t):
                stated = _ct_num(m.group(1))
                comp = rd / gdp * 100
                if stated is not None and abs(stated - comp) > 0.20:
                    _hit("ct_rd_intensity",
                         "研发经费 %g 亿元 ÷ 国内生产总值 %g 亿元 = %.4f%%，"
                         "但公布研发强度为 %s%%（超出公布精度）"
                         % (rd, gdp, comp, m.group(1)),
                         m.group(0), ["%g亿元" % rd, "%g亿元" % gdp],
                         "%g/%g*100=%.4f%%" % (rd, gdp, comp))
    # ③ 进出口差额
    for kind, outlab, inlab, reslab in (
            ("货物", "货物出口", "货物进口", "货物进出口顺差"),
            ("服务", "服务出口", "服务进口", "服务进出口逆差")):
        e = _ct_label_value(t, outlab)
        i = _ct_label_value(t, inlab)
        if e is None or i is None:
            continue
        for m in re.finditer(reslab + r"([\d,]+(?:\.\d+)?)亿元", t):
            stated = _ct_num(m.group(1))
            if stated is None:
                continue
            diff = abs(e - i)
            if abs(stated - diff) > max(2.0, diff * 0.001):
                _hit("ct_trade_balance",
                     "%s差额按出口 %g 减进口 %g = %g 亿元，但公布为 %s 亿元"
                     % (kind, e, i, diff, m.group(1)),
                     m.group(0), ["出口=%g亿元" % e, "进口=%g亿元" % i],
                     "|%g-%g|=%g" % (e, i, diff))
    # ④ 城乡收入比值
    urban = _ct_label_value(t, "城镇居民人均可支配收入")
    rural = _ct_label_value(t, "农村居民人均可支配收入")
    if urban and rural:
        for m in re.finditer(r"城乡居民人均可支配收入比值为([\d.]+)", t):
            stated = _ct_num(m.group(1))
            comp = urban / rural
            if stated is not None and abs(stated - comp) > 0.02:
                _hit("ct_income_ratio",
                     "城镇居民人均可支配收入 %g ÷ 农村 %g = %.4f，但公布比值为 %s"
                     % (urban, rural, comp, m.group(1)),
                     m.group(0), ["城镇=%g" % urban, "农村=%g" % rural],
                     "%g/%g=%.4f" % (urban, rural, comp))
    # ⑤ 服务消费占比
    svc = _ct_label_value(t, "居民人均服务性消费支出")
    tot = _ct_label_value(t, "居民人均消费支出")
    if svc and tot:
        for m in re.finditer(r"占居民人均消费支出(?:的)?比重为([\d.]+)%", t):
            stated = _ct_num(m.group(1))
            comp = svc / tot * 100
            if stated is not None and abs(stated - comp) > 0.20:
                _hit("ct_service_consumption_share",
                     "居民人均服务性消费支出 %g ÷ 居民人均消费支出 %g = %.4f%%，"
                     "但公布比重为 %s%%" % (svc, tot, comp, m.group(1)),
                     m.group(0), ["服务消费=%g" % svc, "消费支出=%g" % tot],
                     "%g/%g*100=%.4f%%" % (svc, tot, comp))
    # ⑥ 同比变动率（跨单位：本期「万X」vs 变动量「X」→ 统一到基础单位）
    pat = re.compile(r"([\d][\d,]*(?:\.\d+)?)(万?)([所人个张项])(?:[，,])"
                     r"比上年(增加|减少)([\d][\d,]*(?:\.\d+)?)(万?)(?:[所人个张项]?)"
                     r"(?:[，,])(增长|下降)([\d.]+)%")
    for m in pat.finditer(t):
        cur = _ct_num(m.group(1))
        chg = _ct_num(m.group(5))
        if not cur or not chg:
            continue
        if m.group(2) == "万" and m.group(6) == "":
            chg = chg / 10000.0
        elif m.group(2) == "" and m.group(6) == "万":
            chg = chg * 10000.0
        base = cur - chg if m.group(4) == "增加" else cur + chg
        if base <= 0:
            continue
        comp = chg / base * 100
        stated = _ct_num(m.group(8))
        if stated is not None and abs(stated - comp) > 0.05:
            _hit("ct_yoy_rate",
                 "同比%s量 %g ÷ 基期 %g = %.4f%%，但公布为 %s%%（超出公布精度）"
                 % (m.group(4), chg, base, comp, m.group(8)),
                 m.group(0), ["变动量=%g" % chg, "基期=%g" % base],
                 "%g/%g*100=%.4f%%" % (chg, base, comp))
    return out[0] if out else None


# ===========================================================================
# CT 专用判据族（2026-11-23，ct-criteria）：预算/统计类文档的文内确定性复算
#
# 依据 docs/qa/CT进了清单也不判_20261123.md：CT 44 份修路由后 810 条 FN 中
# D5 na 283 + pass 69 + abstain 49 = 401 条「进了清单也不判」；P01 判据在 CT 上
# 接管 0 条（P01 白名单 13+4 码里与 CT 映射码有交集的 9 码全部取不到「两侧成对
# 事实」=None）。CT 文档（部门预算/决算/统计公报/绩效自评）的注入违规与 P01
# 招标文件不同：主体是**同文档内可复算的算术矛盾**，因此另建本判据族：
#
#   G05-002 预算测算过程可复算：
#     ① 增长率：本金 X ± 变动量 Y → 复算 Y/(X∓Y) vs 公布「增长/下降 P%」；
#     ② 预算完成率：年初预算 X、决算/执行 Y → 复算 Y/X vs 公布「完成…的 P%」。
#   C01-001 分项与合计相符：统计公报「合计 = 分项之和」（招生/在校/毕业/产量/
#     进出口/保费/赔款/随迁子女/本专科/民办高校）。
#   G05-004 预算各级汇总勾稽一致：基本支出 = 人员经费 + 公用经费（同段取数）。
#   C08-003 费率基数及结果符合依据：① 价格分公式方向（低价优先应 基准价/投标
#     报价，写成 投标报价/基准价 = 报价越高得分越高）；② 同文档「扣除前」与
#     「扣除后」两种价格口径并存（政策落空）。
#
# 同一把尺子：只做取数 + 算术比较；另一侧取不到 / 差在公布精度容差内 → None
# （保留模型结论，不猜、不关键词硬判）。detail 带完整复算式与原文数值串；
# 引文由 _p01_raw_quote 回填原文连续切片（fail-closed）。
# ===========================================================================
_CT2_CODES = ("G05-002", "C01-001", "G05-004", "C08-003")
# 允许把「模型判 insufficient/na」也接管为确定性 fail 的 CT 点位（第二跳）。
_CT2_SECOND_HOP_CODES = _CT2_CODES

_CT2_PCT_TOL = 0.15      # 比率复算容差（pp；公布值 2 位小数 + 源数字四舍五入）
_CT2_SUM_ABS = 0.03      # 合计复算绝对容差（万/亿/所）
_CT2_SUM_REL = 0.0002    # 合计复算相对容差（0.02%：覆盖四舍五入与跨单位取整）


def _ct2_num(x):
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return None


def _ct2_tol(total, abs_tol=_CT2_SUM_ABS, rel=_CT2_SUM_REL):
    try:
        return max(float(abs_tol), abs(float(total)) * float(rel))
    except Exception:
        return float(abs_tol)


def _ct2_frag(mtext):
    """取匹配文本中**单行内**最长片段作引文锚（_p01_raw_quote 只回查单行）。"""
    segs = [s for s in str(mtext or "").split("\n") if s.strip()]
    if not segs:
        return ""
    return max(segs, key=len)


def _ct2_sum_hit(t, pat, label):
    """合计 vs 分项之和：任一匹配不成立即返回确定性「不满足」。"""
    for m in re.finditer(pat, t):
        vals = [_ct2_num(g) for g in m.groups()]
        if len(vals) < 2 or any(v is None for v in vals):
            continue
        total, parts = vals[0], vals[1:]
        s = sum(parts)
        if abs(total - s) <= _ct2_tol(total):
            continue
        return _p01_det(
            "ct_sum_components",
            "%s：公布合计 %g，但同文分项 %s 相加 = %g（差 %g，超出四舍五入容差）"
            % (label, total, "+".join("%g" % v for v in parts), s, abs(total - s)),
            _ct2_frag(m.group(0)),
            ["合计=%g" % total] + ["分项%d=%g" % (i + 1, v) for i, v in enumerate(parts)],
            "sum(%s)=%g != %g" % ("+".join("%g" % v for v in parts), s, total))
    return None


def _ct2_budget_calc(t):
    """G05-002 预算测算过程可复算：增长率 / 预算完成率复算（只报确定不一致）。"""
    # ① 增长率：X 万元 ± Y 万元 → Y/(X∓Y)；公布「增长/下降 P%」
    for m in re.finditer(r"(增加|减少)([\d,]+(?:\.\d+)?)万\s*元[，,]?\s*(增长|下降)\s*([\d.]+)%", t):
        change, y, stated = m.group(1), _ct2_num(m.group(2)), _ct2_num(m.group(4))
        if y is None or stated is None:
            continue
        # 回看同句/邻句最后一个「X万元」，且该金额与比较句之间出现「比上年/与…相比」
        pre = t[max(0, m.start() - 260):m.start()]
        ams = list(re.finditer(r"([\d,]+(?:\.\d+)?)万\s*元", pre))
        if not ams:
            continue
        x = _ct2_num(ams[-1].group(1))
        between = pre[ams[-1].end():]
        if x is None or not re.search(r"比上年|与\d{4}年度相比|与上年|相比", between):
            continue
        base = x - y if change == "增加" else x + y
        if base <= 0:
            continue
        comp = y / base * 100.0
        if abs(comp - stated) <= _CT2_PCT_TOL:
            continue
        return _p01_det(
            "ct_growth_rate",
            "同比%s：本期 %g 万元 %s %g 万元 → 基期 %g 万元，复算变动率 %g÷%g=%.2f%%，"
            "但公布为 %s%%（超容差 %.2fpp）"
            % (change, x, change, y, base, y, base, comp, m.group(4),
               abs(comp - stated)),
            _ct2_frag(m.group(0)),
            ["本期=%g万元" % x, "变动量=%g万元" % y, "基期=%g万元" % base],
            "|%g-%g|=%g; %g/%g*100=%.2f%% vs %s%%"
            % (x, y, base, y, base, comp, m.group(4)))
    # ② 预算完成率：年初预算 X、支出决算 Y → Y/X；公布「完成…的 P%」
    _done_pats = (
        (r"年初预算为([\d,]+(?:\.\d+)?)万\s*元[^。；]{0,40}?"
         r"支出决算为([\d,]+(?:\.\d+)?)万\s*元[^。；]{0,30}?"
         r"完成(?:年初预算|全年预算数|预算)的([\d.]+)%", "年初预算"),
        (r"全年预算为([\d,]+(?:\.\d+)?)万\s*元[^。；]{0,40}?"
         r"支出决算为([\d,]+(?:\.\d+)?)万\s*元[^。；]{0,30}?"
         r"完成全年预算数\s*的([\d.]+)%", "全年预算"),
        (r"项目全年预算数为([\d,]+(?:\.\d+)?)万\s*元[^。；]{0,60}?"
         r"执行数为([\d,]+(?:\.\d+)?)万\s*元[^。；]{0,30}?"
         r"完成预算的([\d.]+)%", "项目全年预算"),
    )
    for pat, kind in _done_pats:
        for m in re.finditer(pat, t):
            x, y, stated = _ct2_num(m.group(1)), _ct2_num(m.group(2)), _ct2_num(m.group(3))
            if not x or y is None or stated is None:
                continue
            comp = y / x * 100.0
            if abs(comp - stated) <= _CT2_PCT_TOL:
                continue
            return _p01_det(
                "ct_budget_completion",
                "%s完成率：%s %g 万元、决算/执行 %g 万元 → 复算 %g÷%g=%.2f%%，"
                "但公布为 %s%%（超容差 %.2fpp）"
                % (kind, kind, x, y, y, x, comp, m.group(3), abs(comp - stated)),
                _ct2_frag(m.group(0)),
                ["%s=%g万元" % (kind, x), "决算/执行=%g万元" % y],
                "%g/%g*100=%.2f%% vs %s%%" % (y, x, comp, m.group(3)))
    return None


def _ct2_bulletin_sum(t):
    """C01-001 分项与合计相符：统计公报「合计 = 分项之和」（同文可复算）。"""
    pats = (
        (r"总量([\d.]+)万人[\s\S]{0,40}?其中[，,]?外出农民工([\d.]+)万人"
         r"[\s\S]{0,20}?本地农民工([\d.]+)万人", "农民工总量"),
        (r"全年粮食产量([\d.]+)万吨[\s\S]{0,80}?夏粮产量([\d.]+)万吨"
         r"[\s\S]{0,20}?早稻产量([\d.]+)万吨[\s\S]{0,20}?秋粮产量([\d.]+)万吨", "粮食产量"),
        (r"猪牛羊禽肉产量([\d.]+)万吨[\s\S]{0,20}?猪肉产量([\d.]+)万吨"
         r"[\s\S]{0,20}?牛肉产量([\d.]+)万吨[\s\S]{0,20}?羊肉产量([\d.]+)万吨"
         r"[\s\S]{0,20}?禽肉产量([\d.]+)万吨", "猪牛羊禽肉产量"),
        (r"货物进出口总额([\d.]+)亿元[\s\S]{0,40}?出口([\d.]+)亿元"
         r"[\s\S]{0,20}?进口([\d.]+)亿元", "货物进出口总额"),
        (r"服务进出口总额([\d.]+)亿元[\s\S]{0,40}?服务出口([\d.]+)亿元"
         r"[\s\S]{0,20}?服务进口([\d.]+)亿元", "服务进出口总额"),
        (r"原保险保费收入(?:\[\d+\])?([\d.]+)亿元[\s\S]{0,80}?"
         r"寿险业务原保险保费收入([\d.]+)亿元"
         r"[\s\S]{0,10}?健康险和意外伤害险业务原保险保费收入([\d.]+)亿元"
         r"[\s\S]{0,10}?财产险业务原保险保费收入([\d.]+)亿元", "原保险保费收入"),
        (r"支付各类赔款及给付([\d.]+)亿元[\s\S]{0,40}?"
         r"寿险业务给付([\d.]+)亿元[\s\S]{0,10}?"
         r"健康险和意外伤害险业务赔款及给付([\d.]+)亿元"
         r"[\s\S]{0,10}?财产险业务赔款([\d.]+)亿元", "赔款及给付"),
        (r"研究生招生(?:\[\d+\])?([\d.]+)万人[\s\S]{0,90}?其中[，,]?"
         r"博士生([\d.]+)万人[，,]?硕士生([\d.]+)万人", "研究生招生"),
        (r"在学研究生(?:\[\d+\])?([\d.]+)万人[\s\S]{0,90}?其中[，,]?"
         r"在学博士生([\d.]+)万人[^，。]{0,5}?在学硕士生([\d.]+)万人", "在学研究生"),
        (r"毕业研究生(?:\[\d+\])?([\d.]+)万人[\s\S]{0,40}?其中[，,]?"
         r"毕业博士生([\d.]+)万人[，,]?毕业硕士生([\d.]+)万人", "毕业研究生"),
        (r"随迁子女([\d.]+)万人。其中[，,]?在小学就读([\d.]+)万人"
         r"[，,]?在初中就读([\d.]+)万人", "随迁子女"),
        (r"随迁子女([\d.]+)万人，在小学就读的[\s\S]{0,10}?([\d.]+)万人"
         r"[，,]?在初中就读的[\s\S]{0,10}?([\d.]+)万人", "随迁子女"),
        (r"本专科共有在校生([\d.]+)万人。其中[，,]?普通本科在校生([\d.]+)万人"
         r"[，,]?职业本科在校生([\d.]+)万人[，,]?\(专科\)在校生([\d.]+)万人",
         "本专科在校生"),
        (r"本专科共有毕业生([\d.]+)万人。其中[，,]?普通本科毕业生([\d.]+)万人"
         r"[，,]?职业本科毕业生([\d.]+)万人[，,]?\(专科\)毕业生([\d.]+)万人",
         "本专科毕业生"),
        (r"民办高校([\d.]+)所[\s\S]{0,20}?其中[，,]?普通本科学校([\d.]+)所"
         r"[，,]?本科层次职业学校([\d.]+)所[，,]?\(专科\)学校([\d.]+)所"
         r"[，,]?成人高等学校([\d.]+)所", "民办高校数"),
        (r"招收研究生(?:\[\d+\])?([\d.]+)万人[\s\S]{0,90}?其中[，,]?招收?博士生([\d.]+)万人[，,]?硕士生([\d.]+)万人", "研究生招生"),
        (r"义务教育阶段招生([\d.]+)万人[，,]?在校生([\d.]+)万人[，,]?专任教师([\d.]+)万人[\s\S]{0,40}?小学[\s\S]{0,80}?招生([\d.]+)万人[，,]?在校生([\d.]+)万人[，,]?专任教师([\d.]+)万人[\s\S]{0,40}?初中[\s\S]{0,80}?招生([\d.]+)万人[，,]?在校生([\d.]+)万人[，,]?专任教师([\d.]+)万人", "义务教育阶段汇总"),
    )
    for pat, label in pats:
        det = _ct2_sum_hit(t, pat, label)
        if det:
            return det
    return None


def _ct2_basic_expense(t):
    """G05-004 预算各级汇总勾稽：基本支出 = 人员经费 + 公用经费（同段三处取数）。"""
    for m in re.finditer(r"([\d,]+(?:\.\d+)?)万\s*元[，,]?其中[：:]", t):
        basic = _ct2_num(m.group(1))
        if basic is None:
            continue
        pre = t[max(0, m.start() - 24):m.start()]
        if "基本支出" not in pre:
            continue
        seg = t[m.end():m.end() + 460]
        pm = re.search(r"(?:人员支出|人员经费)([\d,]+(?:\.\d+)?)万\s*元", seg)
        gm = re.search(r"(?:日常公用支出|公用经费)([\d,]+(?:\.\d+)?)万\s*元", seg)
        if not pm or not gm:
            continue
        p_, g_ = _ct2_num(pm.group(1)), _ct2_num(gm.group(1))
        if p_ is None or g_ is None or (p_ <= 0 and g_ <= 0):
            continue
        s = p_ + g_
        if abs(basic - s) <= _ct2_tol(basic):
            continue
        return _p01_det(
            "ct_basic_expense_sum",
            "基本支出 %g 万元，但同段人员经费 %g + 公用经费 %g = %g 万元（差 %g，"
            "超出四舍五入容差）" % (basic, p_, g_, s, abs(basic - s)),
            _ct2_frag(m.group(0)),
            ["基本支出=%g万元" % basic, "人员经费=%g万元" % p_, "公用经费=%g万元" % g_],
            "%g+%g=%g != %g" % (p_, g_, s, basic))
    return None


def _ct2_fee_basis(t):
    """C08-003 费率基数及结果符合依据：价格分公式方向 / 价格扣除口径并存。"""
    # ① 价格分公式方向：低价优先法下应为「评标基准价／投标报价」；写成
    #    「投标报价／评标基准价」则报价越高得分越高，与同段「基准价得满分」相反。
    for m in re.finditer(r"(?:投标报价得分|报价分)[=＝][（(]([^）)]{1,26})[／/]([^）)]{1,26})[）)]", t):
        a, b = _p01_norm(m.group(1)), _p01_norm(m.group(2))
        if "报价" in a and "基准价" in b:
            return _p01_det(
                "ct_price_formula_inverted",
                "价格分公式写成「%s／%s」：报价越高得分越高，与同段「价格最低的投标"
                "报价为评标基准价、其价格分为满分（低价优先法）」方向相反"
                % (m.group(1), m.group(2)),
                _ct2_frag(m.group(0)),
                ["分子=%s" % m.group(1), "分母=%s" % m.group(2)],
                "低价优先要求 基准价/报价；文档写 报价/基准价")
    # ② 同文档「扣除前的价格参加评审」与「扣除后的价格参与评审」并存：
    #    价格扣除政策在评审环节被架空（同一事项两种口径）。
    if "扣除前的价格" in t and "扣除后的价格" in t:
        m = re.search(r"[^。\n]{0,50}扣除前的价格[^。\n]{0,20}", t) or \
            re.search(r"扣除前的价格[^。\n]{0,20}", t)
        frag = _ct2_frag(m.group(0)) if m else "扣除前的价格"
        return _p01_det(
            "ct_price_deduction_conflict",
            "同一文档并存两种评审价格口径：多处写「用扣除后的价格参与评审」，"
            "另一处写「用扣除前的价格参加评审」→ 价格扣除政策在评审环节落空",
            frag, ["扣除后=参与评审", "扣除前=参加评审"],
            "同事项两口径：扣除后参与评审 vs 扣除前参加评审")
    return None


def _ct2_judge(code, t):
    """CT 专用判据族 dispatch（仅在本点位 P01 同码判据取不到时兜底调用）。"""
    if code == "G05-002":
        return _ct2_budget_calc(t)
    if code == "C01-001":
        return _ct2_bulletin_sum(t)
    if code == "G05-004":
        return _ct2_basic_expense(t)
    if code == "C08-003":
        return _ct2_fee_basis(t)
    return None


# ===========================================================================
# 第三批（2026-11-23）：4 点位「跨位置取值一致性 / 费率基数与结果 / 引用与来源对应
# / 期限计算口径」的文内确定性判据。
#
# 只接「文内能同时取到成对事实」的确定性矛盾（另一侧取不到 → None，保留模型结论）：
#   A01-003 主体基本信息差异可解释：
#     ① 招标人地址 与 招标代理机构地址 完全相同（两主体同值）；
#     ② 代建体制下「招标人为项目业主」（招标人与代建单位/项目业主混同）；
#     ③ 联系方式地址 落入 2.1 建设地点（主体联系地址与项目地点混同）；
#     ④ 招标人 与 招标机构/招标代理机构 为同一主体；
#     ⑤ 同一电话同时挂在「招标人」与「监督管理部门」两个主体；
#     ⑥ 同一号码的传真区号与电话区号不一致。
#   C08-003 费率基数及结果符合依据：
#     ① 金额大写 vs 括号内阿拉伯数字不等；
#     ② 同一「标段估算金额/保证金」两表按标段复算的比例不一致（且超 2%）；
#     ③ 基础条款与同段「执行口径」追加句在阈值边界/扣分系数/插值方式/样本归属上
#        自相矛盾（≥N 家 vs 恰有 N 家不剔除；高/低系数对调；插入法 vs 不扣分；
#        无效标仍计入有效样本）。
#   B03-002 引用条款与来源内容对应：
#     ① 同一章序号在同一枚举内对应两个不同名称（同号不同名，必有一处错）；
#     ② 同一标段在 2.4 表「服务期限」与 2.5「服务期限」的终点类型不一致；
#     ③ 同一「发包人要求/技术要求」内容被引到两个不同章号。
#   C09-002 期限计算口径明确：
#     ① 招标文件获取起点至投标截止的间隔 < 同句明确的「不少于 N 日」；
#     ② 业绩认定基准写「完工时间」，而同句证明材料清单要求「签订时间」（双时间基准）。
# 所有判据只做字符串/算术/日期比较，不引入 gold 文本；引文由 _p01_raw_quote 回填原文
# 连续切片，取不到 → guard_judged 降 insufficient（fail-closed）。
# ===========================================================================
_P01_BATCH3_CODES = ("A01-003", "C08-003", "B03-002", "C09-002")

_CN_AMT_D = {"零": 0, "壹": 1, "贰": 2, "叁": 3, "肆": 4, "伍": 5, "陆": 6,
             "柒": 7, "捌": 8, "玖": 9, "一": 1, "二": 2, "两": 2, "三": 3,
             "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_CN_AMT_U = {"拾": 10, "十": 10, "佰": 100, "百": 100, "仟": 1000, "千": 1000}
_CN_AMT_RUN = "[" + "".join(_CN_AMT_D) + "".join(_CN_AMT_U) + "万亿" + "]"
_P01_DASH = "[-—－~]"


def _p01_cn_amount(s):
    """中文大写金额 → 数值（仅用于同文大小写金额比对；解析失败返回 None）。"""
    s = str(s or "").strip()
    if not s:
        return None
    total = 0.0
    section = 0.0
    number = 0.0
    hit = False
    for ch in s:
        if ch in _CN_AMT_D:
            number = float(_CN_AMT_D[ch])
            hit = True
        elif ch in _CN_AMT_U:
            section += (number or 1.0) * _CN_AMT_U[ch]
            number = 0.0
            hit = True
        elif ch == "万":
            section += number
            total += (section or 1.0) * 10000.0
            section = 0.0
            number = 0.0
            hit = True
        elif ch == "亿":
            section += number
            total += (section or 1.0) * 100000000.0
            section = 0.0
            number = 0.0
            hit = True
        elif ch in "元圆":
            break
        elif ch in "整正":
            continue
        else:
            return None
    return total + section + number if hit else None


def _p01_field_after(t, label, maxlen=80):
    """标签后的第一个非空值（允许标签与值之间隔空行；优先同行冒号形式）。"""
    m = re.search(re.escape(label) + r"[：:]\s*([^\n]{2,%d})" % maxlen, t)
    if m:
        return m.group(1).strip()
    m = re.search(re.escape(label) + r"\s*\n+\s*([^\n]{2,%d})" % maxlen, t)
    return m.group(1).strip() if m else ""


def _p01_ident_core(s):
    """主体名称归一：去空白/括号，用于「同一主体」比对。"""
    s = _p01_norm(s)
    return re.sub(r"[（）()【】\[\]《》<>“”\"'·,，。;；:：]", "", s)


def _p01_subject_info_check(t: str):
    """A01-003：主体基本信息差异可解释（同字段两值 / 两主体同值）。"""
    # ① 招标人地址 == 招标代理机构地址（两个不同主体共用同一地址）
    v1 = _p01_field_after(t, "招标人地址")
    v2 = _p01_field_after(t, "招标代理机构地址")
    if v1 and v2 and len(_p01_norm(v1)) >= 6 and _p01_norm(v1) == _p01_norm(v2):
        return _p01_det2(
            "addr_same_two_subjects",
            "招标代理机构地址：%s 与招标人地址：%s 完全相同（两个不同主体共用同一联系地址）" % (v2, v1),
            v2, ["招标人地址=%s" % v1, "招标代理机构地址=%s" % v2],
            "normalize(addr_agent)==normalize(addr_owner)")
    # ② 代建体制下「招标人为项目业主」（招标人应为代建单位）
    mo = re.search(r"项目业主(?:为)?([^\n，,。；;]{4,50})[，,]", t)
    mc = re.search(r"委托([^\n，,。；;]{4,50})代为建设", t)
    mz = re.search(r"招标人为([^\n，,。；;]{4,60}?)(?:招标项目|，|,|。|；|;|\n)", t)
    if mo and mc and mz:
        owner = _p01_ident_core(mo.group(1))
        tenderer = _p01_ident_core(mz.group(1))
        if owner and tenderer and owner == tenderer:
            return _p01_det2(
                "tenderer_is_owner_under_agency",
                "招标人为%s（即项目业主），而本项目已约定委托%s代为建设；"
                "代建体制下招标人应为代建单位，招标人与项目业主混同"
                % (mz.group(1), mc.group(1)),
                "招标人为" + mz.group(1),
                ["项目业主=%s" % mo.group(1), "代建单位=%s" % mc.group(1),
                 "招标人=%s" % mz.group(1)],
                "normalize(招标人)==normalize(项目业主) 且存在委托代建")
    # ③ 联系方式地址 落入 2.1 建设地点（主体联系地址与项目地点混同）
    ms = re.search(r"建设地点[：:]\s*([^\n。；;]{4,80})", t)
    if ms:
        site = _p01_norm(ms.group(1))
        for ma in re.finditer(r"地址[：:]?\s*\n+\s*([^\n]{4,80})", t):
            v = ma.group(1).strip()
            nv = _p01_norm(v)
            if len(nv) >= 6 and nv in site:
                return _p01_det2(
                    "contact_addr_in_site",
                    "联系方式地址：%s 与 2.1 建设地点：%s 相同/被其包含（主体联系地址误填项目地点）"
                    % (v, ms.group(1)),
                    v, ["联系地址=%s" % v, "建设地点=%s" % ms.group(1)],
                    "normalize(联系地址) in normalize(建设地点)")
    # ④ 招标人 与 招标机构/招标代理机构 为同一主体
    if mz:
        tenderer = _p01_ident_core(mz.group(1))
        for label in ("招标机构", "招标代理机构"):
            ag = _p01_field_after(t, label, 60)
            if not ag:
                continue
            agency = _p01_ident_core(ag)
            if len(tenderer) >= 8 and len(agency) >= 8 and (
                    tenderer in agency or agency in tenderer):
                return _p01_det2(
                    "tenderer_equals_agency",
                    "招标人为%s，同时%s：%s；同一主体既是招标人又是招标代理机构"
                    % (mz.group(1), label, ag),
                    "招标人为" + mz.group(1),
                    ["招标人=%s" % mz.group(1), "%s=%s" % (label, ag)],
                    "normalize(招标人) ⊂ normalize(%s)" % label)
    # ⑤ 同一电话同时挂在「招标人」与「监督管理部门」两个主体（要求两次独立出现）
    _ROLE_PAT = ((re.compile(r"招标监督管理部门|监督部门|行政监督|举报|投诉"), "监督"),
                 (re.compile(r"招标代理机构|招标机构|招标人|采购人"), "招标人"))
    occ = {}
    for mp in re.finditer(r"(0\d{2,3})" + _P01_DASH + r"(\d{7,8})", t):
        num = mp.group(1) + "-" + mp.group(2)
        ctx = t[max(0, mp.start() - 100):mp.start()]
        role, far = None, -1
        for pat, name in _ROLE_PAT:
            mm = None
            for mm in pat.finditer(ctx):
                pass
            if mm is not None and mm.start() > far:
                far, role = mm.start(), name
        if role:
            occ.setdefault(num, []).append(role)
    for num, roles in occ.items():
        if "监督" in roles and "招标人" in roles:
            return _p01_det2(
                "phone_shared_owner_supervisor",
                "电话 %s 同时登记在「招标人」与「招标监督管理部门」两个主体下；"
                "异议受理与监督渠道混同" % num,
                num,
                ["号码=%s" % num, "出现角色=%s" % "/".join(roles)],
                "同一号码在文内出现 %d 次，分属两个不同主体标签" % len(roles))
    # ⑥ 同一号码的传真区号与电话区号不一致
    area_by_local = {}
    for mp in re.finditer(r"(0\d{2,3})" + _P01_DASH + r"(\d{7,8})", t):
        area_by_local.setdefault(mp.group(2), set()).add(mp.group(1))
    for local, areas in area_by_local.items():
        if len(areas) >= 2:
            a = sorted(areas)
            return _p01_det2(
                "fax_phone_area_conflict",
                "同一号码 %s 出现两个区号：%s；传真与电话归属地不一致"
                % (local, " / ".join(a)),
                local,
                ["本地号码=%s" % local, "区号=%s" % " / ".join(a)],
                "同号码多区号 → 区号冲突")
    return None


def _p01_table_rows(t: str):
    """归一化文本中的 markdown 表格行 → [[cell,...], ...]。"""
    rows = []
    for ln in str(t or "").split("\n"):
        if ln.count("|") >= 3:
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            if cells:
                rows.append(cells)
    return rows


def _p01_table_by_header(t: str, header_key: str, value_keys: tuple):
    """按表头定位数据列：返回 [(标段号, 标段名, {value_key: text}), ...]。"""
    rows = _p01_table_rows(t)
    out = []
    for i, cells in enumerate(rows):
        joined = "|".join(cells)
        if header_key in joined and "标段" in joined:
            cols = {}
            for key in value_keys:
                for j, c in enumerate(cells):
                    if key in c:
                        cols[key] = j
                        break
            if not cols:
                continue
            for row in rows[i + 1:]:
                if len(row) < 2 or not re.match(r"^\d+$", row[0]):
                    if out:
                        break
                    continue
                rec = {}
                for key, j in cols.items():
                    rec[key] = row[j] if j < len(row) else ""
                out.append((row[0], row[1] if len(row) > 1 else "", rec))
                if len(row) < 2:
                    break
            break
    return out


def _p01_fee_base_check(t: str):
    """C08-003：费率基数及结果符合依据（大小写金额 / 保证金比例 / 执行口径自相矛盾）。"""
    # ① 金额大写 vs 括号内阿拉伯数字
    mamt = re.search(r"(" + _CN_AMT_RUN + r"{2,16})元[（(]\s*[¥￥]?\s*([\d,]+(?:\.\d+)?)", t)
    if mamt:
        cn = _p01_cn_amount(mamt.group(1))
        num = _p01_fnum(mamt.group(2))
        if cn is not None and num is not None and abs(cn - num) > 0.01:
            return _p01_det2(
                "amount_cn_vs_digit",
                "金额大写「%s元」=%g ≠ 括号内数字「%s」=%g（同一金额两种写法不一致）"
                % (mamt.group(1), cn, mamt.group(2), num),
                mamt.group(0),
                ["大写=%g" % cn, "数字=%g" % num],
                "cn_amount(%s)=%g ≠ %s" % (mamt.group(1), cn, mamt.group(2)))
    # ② 同表标段保证金比例复算（保证金表 ÷ 估算/含税金额表）
    dep = _p01_table_by_header(t, "投标保证金", ("保证金", "金额"))
    est = _p01_table_by_header(t, "含税金额", ("含税金额",))
    if dep and est:
        est_by_no = {}
        for no, name, rec in est:
            for v in rec.values():
                val = _p01_fnum(v)
                if val:
                    est_by_no[no] = (name, val)
                    break
        ratios = []
        for no, name, rec in dep:
            dval = None
            for v in rec.values():
                dval = _p01_fnum(v)
                if dval:
                    break
            if not dval or no not in est_by_no:
                continue
            ev = est_by_no[no][1]
            if ev:
                ratios.append((no, name, dval, ev, 100.0 * dval / ev))
        if len(ratios) >= 2:
            lo = min(r[4] for r in ratios)
            hi = max(r[4] for r in ratios)
            if hi - lo > 0.5 and hi > 2.05:
                r0 = max(ratios, key=lambda x: x[4])
                return _p01_det2(
                    "deposit_ratio_inconsistent",
                    "投标保证金比例按标段复算不一致："
                    + "；".join("标段%s %g万/%g万=%.2f%%" % (r[0], r[2], r[3], r[4])
                               for r in ratios)
                    + "（同项目同表口径应一致，且不得超过估算价2%）",
                    "|" + r0[0] + "|" + r0[1] + "|" + ("%g" % r0[2]) + "|",
                    ["标段%s=%.2f%%" % (r[0], r[4]) for r in ratios],
                    "；".join("%g/%g=%.4f" % (r[2], r[3], r[4] / 100.0) for r in ratios))
    # ③ 阈值边界：≥N 家即剔除极值，追加口径称恰有 N 家不剔除
    mt = re.search(r"≥(\d+)家[^\n。]{0,40}?去掉", t)
    mu = re.search(r"恰有(\d+)家[^\n。]{0,30}?不[^\n。]{0,10}?(?:剔除|去掉)", t)
    if mt and mu and int(mt.group(1)) == int(mu.group(1)):
        n = int(mt.group(1))
        return _p01_det2(
            "threshold_boundary_conflict",
            "基础条款「有效投标文件≥%d家时即去掉最高/最低价」包含 %d 家本身；"
            "追加口径却称「恰有 %d 家不剔除」（同一阈值边界两处相反）" % (n, n, n),
            mu.group(0), ["阈值=≥%d家" % n, "追加口径=恰有%d家不剔除" % n],
            "≥%d 含 %d，与「恰有 %d 家不执行」矛盾" % (n, n, n))
    # ④ 扣分系数：基础条款每高1%扣a、每低1%扣b，追加口径的高低扣分对调
    mh = re.search(r"每高([\d.]+)%的所扣分值为([\d.]+)[，,]每低([\d.]+)%的所扣分值为([\d.]+)", t)
    mx = re.search(r"比基准价低([\d.]+)%时扣([\d.]+)分[；;，,]比基准价高([\d.]+)%时扣([\d.]+)分", t)
    if mh and mx:
        a = _p01_fnum(mh.group(2))
        b = _p01_fnum(mh.group(4))
        plow = _p01_fnum(mx.group(1))
        clow = _p01_fnum(mx.group(2))
        phigh = _p01_fnum(mx.group(3))
        chigh = _p01_fnum(mx.group(4))
        if None not in (a, b, plow, clow, phigh, chigh):
            exp_low = b * plow
            exp_high = a * phigh
            swapped = (abs(clow - exp_high) <= 0.011 and abs(chigh - exp_low) <= 0.011)
            wrong = (abs(clow - exp_low) > 0.011 or abs(chigh - exp_high) > 0.011)
            if swapped or wrong:
                    return _p01_det2(
                        "deduction_coefficient_swap",
                        "基础条款每高1%%扣%g/每低1%%扣%g；按系数复算低%g%%应扣%g分、高%g%%应扣%g分；"
                        "追加口径却称低%g%%扣%g分、高%g%%扣%g分"
                        % (a, b, plow, exp_low, phigh, exp_high,
                           plow, clow, phigh, chigh),
                        mx.group(0),
                        ["高1%%=%g" % a, "低1%%=%g" % b,
                         "复算低%g%%=%g" % (plow, exp_low), "追加低%g%%=%g" % (plow, clow),
                         "复算高%g%%=%g" % (phigh, exp_high), "追加高%g%%=%g" % (phigh, chigh)],
                        "%g*%g=%g vs %g；%g*%g=%g vs %g"
                        % (b, plow, exp_low, clow, a, phigh, exp_high, chigh))
    # ⑤ 插值：基础条款「偏离不足1%按插入法连续计分」，追加口径称偏离<1%不扣分
    mi = re.search(r"偏离不足1%[^\n。]{0,20}?插入法", t)
    mf = re.search(r"偏离([\d.]+)%[^\n。]{0,24}?不扣分", t)
    if mi and mf:
        pct = _p01_fnum(mf.group(1))
        if pct is not None and 0 < pct < 1:
            return _p01_det2(
                "interpolation_to_flat",
                "基础条款规定偏离不足1%%按插入法连续计分；追加口径却称偏离%g%%不扣分"
                "（把连续插值改成整档取整，同一计分规则两处矛盾）" % pct,
                mf.group(0), ["插值方式=插入法", "追加口径=偏离%g%%不扣分" % pct],
                "插入法(连续) vs %g%%→0 分（整档）" % pct)
    # ⑥ 无效标样本：有效投标文件定义 vs 已否决报价仍作为基准价样本
    mv = re.search(r"有效投标文件指未被[^\n。]{0,20}判定为无效标", t)
    mw = re.search(r"已否决[^\n。]{0,30}?仍作为基准价样本", t)
    if mv and mw:
        return _p01_det2(
            "invalid_bid_as_valid_sample",
            "基础条款定义「有效投标文件指未被判定为无效标的投标文件」；"
            "追加口径却称「已否决…报价仍作为基准价样本保留」（无效标被计入有效样本）",
            mw.group(0), ["有效标定义=未被判定无效标", "追加口径=已否决仍计入样本"],
            "无效标 ∉ 有效标，但被保留为基准价样本")
    return None


def _p01_chapter_period_class(s: str) -> str:
    s = str(s or "")
    if "水保" in s or "水土保持" in s:
        return "水保"
    if "环保" in s or "环境" in s:
        return "环保"
    return ""


def _p01_ref_source_check(t: str):
    """B03-002：引用条款与来源内容对应（章节序号/标段期限/章节引用编号）。"""
    # ① 同一章序号在同一枚举内对应两个不同名称
    titles = {}
    raw = {}
    for m in re.finditer(r"第([一二三四五六七八九十]+)章[（(]([^）)\n]{2,30})[）)]", t):
        titles.setdefault(m.group(1), []).append(m.group(2))
        raw.setdefault(m.group(1), []).append(m.group(0))
    for num, names in titles.items():
        uniq = []
        for x in names:
            if x not in uniq:
                uniq.append(x)
        if len(uniq) >= 2:
            return _p01_det2(
                "chapter_number_duplicate",
                "同一招标范围枚举中第%s章出现两次且名称不同：%s；各章序号必须唯一，"
                "重复序号造成章号缺号" % (num, "、".join("第%s章（%s）" % (num, x) for x in uniq)),
                raw[num][-1],
                ["第%s章=%s" % (num, x) for x in uniq],
                "同章号 %d 个不同名称" % len(uniq))
    # ② 同一标段：2.4 表「服务期限」终点 vs 2.5「服务期限」终点类型不一致
    m25 = re.search(r"服务期限[：:]([^\n]{10,600})", t)
    if m25:
        seg = m25.group(1)
        per = {}
        for m in re.finditer(r"第(\d+)标段[：:]([^\n第]{5,150}?)(?=第\d+标段[：:]|$)", seg):
            per[m.group(1)] = m.group(2)
        tab = {}
        for ln in t.split("\n"):
            if ln.count("|") >= 3:
                cells = [c.strip() for c in ln.strip().strip("|").split("|")]
                km = re.match(r"^第(\d+)标段$", cells[0]) if cells else None
                if km:
                    tab[km.group(1)] = cells[-1]
        for no, txt in per.items():
            if no not in tab:
                continue
            c1 = _p01_chapter_period_class(tab[no])
            c2 = _p01_chapter_period_class(txt)
            if c1 and c2 and c1 != c2:
                return _p01_det2(
                    "section_period_mismatch",
                    "2.4 表第%s标段服务期限终点为「%s」，2.5 却写「第%s标段：%s」"
                    "（同一标段两个期限终点，套用了其他标段终点）" % (no, c1, no, txt),
                    txt,
                    ["2.4表=%s" % c1, "2.5=%s" % c2],
                    "标段%s 期限终点类型 %s ≠ %s" % (no, c1, c2))
    # ③ 同一「发包人要求/技术要求」内容被引到两个不同章号
    mr1 = re.search(r"详见第([一二三四五六七八九十]+)章发包人要求", t)
    mr2 = re.search(r"第([一二三四五六七八九十]+)章[“\"'（(]?主要技术要求或技术方案", t)
    if mr1 and mr2 and mr1.group(1) != mr2.group(1):
        return _p01_det2(
            "chapter_ref_mismatch",
            "服务要求指向「第%s章发包人要求」，而同一文件明确「主要技术要求或技术方案」在"
            "第%s章（同一内容两处章节引用编号不一致）" % (mr1.group(1), mr2.group(1)),
            "详见第" + mr1.group(1) + "章发包人要求",
            ["服务要求引用=第%s章发包人要求" % mr1.group(1),
             "技术要求所在=第%s章" % mr2.group(1)],
            "第%s章 ≠ 第%s章" % (mr1.group(1), mr2.group(1)))
    return None


def _p01_period_calc_check(t: str):
    """C09-002：期限计算口径明确（获取期不少于N日 / 业绩时间基准）。"""
    # ① 招标文件获取起点 → 投标截止 的间隔 < 同句「不少于 N 日」
    mget = re.search(
        r"(\d{4})年(\d{1,2})月(\d{1,2})日(\d{1,2})时(\d{1,2})分?至投标文件递交的截止时间止"
        r"[（(]不少于(\d+)日[）)]", t)
    if mget:
        start = None
        try:
            start = _dt.datetime(int(mget.group(1)), int(mget.group(2)), int(mget.group(3)),
                                 int(mget.group(4)), int(mget.group(5)))
        except ValueError:
            start = None
        mend = re.search(r"截止时间[（(]投标截止时间[，,]下同[）)]为"
                         r"(\d{4})年(\d{1,2})月(\d{1,2})日(\d{1,2})时(\d{1,2})分", t)
        if not mend:
            mend = re.search(r"截止时间[^。\n]{0,30}?为(\d{4})年(\d{1,2})月(\d{1,2})日"
                             r"(\d{1,2})时(\d{1,2})分", t)
        end = None
        if mend:
            try:
                end = _dt.datetime(int(mend.group(1)), int(mend.group(2)), int(mend.group(3)),
                                   int(mend.group(4)), int(mend.group(5)))
            except ValueError:
                end = None
        need = int(mget.group(6))
        if start and end:
            days = (end - start).total_seconds() / 86400.0
            if days < need - 1e-6:
                return _p01_det2(
                    "get_period_lt_min_days",
                    "招标文件获取起始 %s，投标截止 %s，间隔 %.2f 日 < 同句明确要求「不少于%d日」"
                    % (start.strftime("%Y年%m月%d日%H时%M分"),
                       end.strftime("%Y年%m月%d日%H时%M分"), days, need),
                    "为" + end.strftime("%Y年%m月%d日%H时%M分"),
                    ["获取起始=%s" % start.strftime("%Y-%m-%d %H:%M"),
                     "投标截止=%s" % end.strftime("%Y-%m-%d %H:%M"),
                     "明确下限=%d日" % need],
                    "(end-start)=%.3f 日 < %d 日" % (days, need))
    # ② 业绩认定基准写「完工时间」，同句证明材料清单却要求「签订时间」（双时间基准）
    mb = re.search(r"时间以(?:工程)?完工时间为准", t)
    if mb:
        ctx = t[max(0, mb.start() - 260):mb.end() + 40]
        mp = re.search(r"合同[（(]包含[^）)]{0,160}?签订时间", ctx)
        if mp:
            return _p01_det2(
                "perf_time_basis_conflict",
                "业绩证明材料清单要求「签订时间」，同句认定基准却写「时间以工程完工时间为准」；"
                "同一业绩条款并存两个时间基准（签约/完工），认定口径不唯一",
                mb.group(0), ["认定基准=完工时间", "证明材料要求=签订时间"],
                "证明载体(签订时间) vs 认定基准(完工时间) 不一致")
    return None


# ===========================================================================
# BX 合同盲测 · 数值复算判据族（2026-11-23，bx-numeric）
#
# 依据 docs/qa/BX缺口分析_20261123.md §3：BX A 臂 139 条 FN 中 A 系数值型 15 码
# 占 85 条（61.2%）；gold 480 条中 195 条（40.6%）的违规机制是「已批准商务条件
# （SW-xxxx）与拟定执行条款（TK-xxxx）同一事项的数值/口径不自洽」——两侧事实都在
# 文内，可用算术复算确定性判定（B 臂直连能命中其中 122/139，证明差异在判据不在能力）。
#
# BX 文档结构（20/20 份、48/48 节一致）：
#   ## 已批准商务条件   ### SW-1014 事项1014  <一行条款>
#   ## 拟定执行条款     ### TK-1014 事项1014  <一行条款>
# 本族只对**同一事项号的 SW/TK 成对取数**后做算术比较（不引入 gold 文本）：
#   ① 两侧数值都取到 / 内部勾稽通过 / 超出业务容差 → 确定性「不满足」，
#      detail 带完整复算式与两侧原文数值串；
#   ② 任一侧取不到、或两侧关系无法确定性归因 → None（保留模型结论，不猜、
#      不单侧硬判）；
#   ③ 合规口径（复算值在容差内）→ None（不误伤，反向控制）。
# 容差按业务：金额 ±0.01 元；比例 ±0.1pp；汇率按公布精度（2 位小数 → usd*0.5 分）；
# 复算类按「应纳金额 ±0.1%」（费率/天数取整来源）。引文一律由 _p01_raw_quote 回填
# 原文**连续切片**；取不到 → guard_judged 降 insufficient（fail-closed）。
# 开关 RULEPROOF_JUDGE_GUARD_BX（默认开，=0 关闭本族；总开关 RULEPROOF_JUDGE_GUARD）。
#
# 码选择（6 码，覆盖已路由 A 系码 72 条 FN 中的 47 条 = 65%；宁少勿滥）：
#   E02-001(14 FN) 违约金分段计费：余额×日率×分段天数复算，TK 用单段基数；
#   E03-003(11)   累计责任限额：总价×比例=限额，已赔付+本次 > 限额仍全额支付；
#   F10-004(9)    含税口径：SW 含税总价已含全部税款+TK 另加收税款（重复加计）；
#   F11-003(5)    分拆合并：n×单笔 > 合并登记阈值却声称每笔均免登记；
#   C14-001(4)    汇率折算：美元×汇率=人民币，TK 用除法（方向倒置）；
#   E10-002(4)    退出结算：预付−已完成=应退，TK 再扣已在已完成中列支的专项费。
# 不纳入：C08-002/003/006（21 条 FN）100% 被审核类型路由裁出清单（frozen_items
# 21/24），确定性算子拿不到 D5 执行位，须改「文件类型与路由」配置，不在本文件授权
# 范围内；E01-004/E05-003 等「同一费用重复承担/免责范围集合」码（20 条 FN）语义成分
# 高于算术成分，留待判据改写，避免关键词硬判误伤。
# 多实例：不加入 _MI_ALL_CODES —— BX gold 每 (文档, 码) 至多 1 条实例
# （BX缺口分析 §4：docs_multi=0），多实例只会重复物化 → FP；BX 评测固定
# RULEPROOF_MULTI_INSTANCE=0。
# ===========================================================================
_BX_DET_CODES = ("E02-001", "E03-003", "F10-004", "F11-003", "C14-001", "E10-002")
# 允许把「模型判 insufficient/na」也接管为确定性 fail 的点位（第二跳）。
# 6 码全部纳入：判据触发的前提是「同一事项 SW/TK 两侧数值都取到且确定性矛盾」，
# 这本身就证明了该点位适用且违规——模型把它判 na/insufficient 属「证据载体缺失
# 当结论」的同一类漏判（BX缺口分析 §2.4：D5 na 32 条 = 23.0% FN）。与 P01/CT
# 第二跳同口径：只在模型 pass/na/insufficient 时接管，模型已判 fail 不重复接管
# （锚点错的走下面的「锚点回填」）。
_BX_SECOND_HOP_CODES = _BX_DET_CODES
# 模型已判 fail 但引文锚到别处（BX 的 M 类 FN：模板空白占位符/他码条款）→ 用确定性
# 算子的 SW/TK 原文切片回填引文。只修锚点、不改判态（fail→fail），回填后仍走
# 引文逐字门禁；取不到原文切片则不动模型结论。
_BX_ANCHOR_FIX_CODES = _BX_DET_CODES

_BX_AMT_TOL = 0.01          # 金额容差（元）
_BX_YUAN = 10000.0          # 万元 → 元


def _bx_num(x):
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return None


def _bx_wan_tol():
    """万元口径的金额容差（0.01 元 = 1e-6 万元）。"""
    return _BX_AMT_TOL / _BX_YUAN


_BX_SEC_RE = re.compile(
    r"(?m)^#{1,4}\s*(SW|TK)-(\d{1,8})\s*事项\s*(\d{1,8})\s*\n(.*?)(?=^#{1,4}|\Z)", re.S)


def _bx_pairs(t: str) -> list:
    """文内 SW/TK 事项对 → [(事项号, SW条款, TK条款)]（同事项号两侧都在才返回）。

    条款取**单行正文**（本数据集 48/48 节为单行）；若历史文档多行则拍平（引文回填
    仍由 _p01_raw_quote 按原文行定位，取不到即 fail-closed）。
    """
    acc = {}
    for m in _BX_SEC_RE.finditer(str(t or "")):
        kind, no = m.group(1), m.group(3)
        lines = [x.strip() for x in str(m.group(4) or "").splitlines() if x.strip()]
        if not lines:
            continue
        acc.setdefault(no, {})[kind] = "".join(lines)
    return [(no, d["SW"], d["TK"]) for no, d in acc.items() if "SW" in d and "TK" in d]


def _bx_penalty_tiers(t: str):
    """E02-001 违约金计算及调整风险：余额×日率×分段天数复算 vs TK 应收额。"""
    for _no, sw, tk in _bx_pairs(t):
        tiers = [(int(a), int(b), _bx_num(c)) for a, b, c in
                 re.findall(r"第(\d+)至(\d+)日余额([\d.]+)万元", sw)]
        m_in = re.search(r"第(\d+)日当日入账([\d.]+)万元并?当日抵减", sw)
        m_rate = re.search(r"按日([\d.]+)%计算", sw)
        if len(tiers) != 2 or not m_in or not m_rate:
            continue
        bal1, bal2 = tiers[0][2], tiers[1][2]
        rate, incoming = _bx_num(m_rate.group(1)), _bx_num(m_in.group(2))
        m_tk = re.search(r"(?:应收)?逾期违约金(?:合计)?([\d,]+(?:\.\d+)?)元", tk) or \
            re.search(r"违约金合计([\d,]+(?:\.\d+)?)元", tk)
        if None in (bal1, bal2, rate, incoming) or not m_tk:
            continue
        # 内部勾稽：第 1 段日数、第 2 段日数、入账抵扣后余额必须与第 2 段余额一致
        days1 = tiers[0][1] - tiers[0][0] + 1
        days2 = tiers[1][1] - tiers[1][0] + 1
        if days1 <= 0 or days2 <= 0 or abs((bal1 - incoming) - bal2) > _bx_wan_tol():
            continue
        stated = _bx_num(m_tk.group(1))
        if stated is None:
            continue
        expected = (bal1 * days1 + bal2 * days2) * _BX_YUAN * rate / 100.0
        tol = max(_BX_AMT_TOL, expected * 0.001)   # 金额 ±0.01 元 / 复算 0.1%
        if abs(stated - expected) <= tol:
            continue
        single_base = bal1 * (days1 + days2) * _BX_YUAN * rate / 100.0
        return _p01_det(
            "bx_penalty_tier_rollforward",
            "按 SW 分段余额复算：%g万元×%g%%×%d日 + %g万元×%g%%×%d日 = %g元，"
            "但 TK 应收违约金为 %g元（差 %g元）%s"
            % (bal1, rate, days1, bal2, rate, days2, expected, stated,
               abs(stated - expected),
               "；TK 数值等于按第 1 段基数 %g万元×%g%%×%d日=%g元（未扣除第%d日入账"
               "%g万元抵减，计费基础被扩大）"
               % (bal1, rate, days1 + days2, single_base, tiers[1][0], incoming)
               if abs(stated - single_base) <= tol else ""),
            tk, ["余额1=%g万元" % bal1, "天数1=%d日" % days1,
                 "余额2=%g万元" % bal2, "天数2=%d日" % days2,
                 "日率=%g%%" % rate, "TK应收=%g元" % stated],
            "%g*%d+%g*%d=%g万元·日；×%g%%×10000=%g元 vs %g元"
            % (bal1, days1, bal2, days2, bal1 * days1 + bal2 * days2,
               rate, expected, stated))
    return None


def _bx_limit_cumulative(t: str):
    """E03-003 责任限额口径可计算：累计限额 = 总价×比例；已赔付+本次 > 限额仍全额支付。"""
    for _no, sw, tk in _bx_pairs(t):
        m_lim = re.search(r"累计责任限额为合同总价([\d.]+)万元的([\d.]+)%", sw)
        m_paid = re.search(r"已赔付[^;。]*?([\d.]+)万元", sw)
        m_cur = re.search(r"本次[^;。]*?(?:损失|金额)([\d.]+)万元", sw)
        if not m_lim or not m_paid or not m_cur:
            continue
        total, pct = _bx_num(m_lim.group(1)), _bx_num(m_lim.group(2))
        paid, cur = _bx_num(m_paid.group(1)), _bx_num(m_cur.group(1))
        if None in (total, pct, paid, cur):
            continue
        limit = total * pct / 100.0
        used = paid + cur
        if used <= limit + _bx_wan_tol():
            continue          # 未越界 → 合规（不判）
        # 第二侧：执行条款就同一事项列明的本次支付金额，且必须等于 SW 本次损失
        m_pay = re.search(r"本次[^;。]*?(?:支付|赔付|赔偿)([\d.]+)万元", tk)
        if not m_pay:
            continue
        pay = _bx_num(m_pay.group(1))
        if pay is None or abs(pay - cur) > _bx_wan_tol():
            continue
        return _p01_det(
            "bx_cumulative_limit",
            "累计责任限额 = 合同总价%g万元×%g%% = %g万元；已赔付%g万元 + 本次%g万元 = "
            "%g万元 > %g万元（超%g万元），但 TK 仍按本次损失 %g万元全额支付并称"
            "「低于单项控制额」——把累计限额当成逐次限额"
            % (total, pct, limit, paid, cur, used, limit, used - limit, pay),
            tk, ["累计限额=%g万元" % limit, "已赔付=%g万元" % paid,
                 "本次损失=%g万元" % cur, "TK本次支付=%g万元" % pay],
            "limit=%g*%g%%=%g；paid+cur=%g+%g=%g > %g"
            % (total, pct, limit, paid, cur, used, limit))
    return None


def _bx_tax_inclusive(t: str):
    """F10-004 金额含税口径清楚：SW 含税总价已含全部税款，TK 另加收税款（重复加计）。"""
    for _no, sw, tk in _bx_pairs(t):
        m_base = re.search(r"含税总价([\d.]+)万元", sw)
        if not m_base or "已包含" not in sw or "税" not in sw:
            continue
        if not re.search(r"已包含[^;。]*?税款|未约定额外税费", sw):
            continue
        m_tb = re.search(r"结算总额为([\d.]+)万元", tk)
        m_extra = re.search(r"另(?:向[^;。]*?)?(?:加收|加计|收取)([\d.]+)万元税款", tk)
        if not m_tb or not m_extra:
            continue
        base, tb = _bx_num(m_base.group(1)), _bx_num(m_tb.group(1))
        extra = _bx_num(m_extra.group(1))
        if None in (base, tb, extra):
            continue
        if abs(tb - base) > _bx_wan_tol() or extra <= _bx_wan_tol():
            continue
        return _p01_det(
            "bx_tax_double_charge",
            "SW 锁定含税总价 %g万元且「已包含全部税款、未约定额外税费」；TK 结算总额同为 "
            "%g万元，却另加收 %g万元税款 → 实际结算 %g+%g=%g万元，同一笔税款被重复加计"
            % (base, tb, extra, base, extra, base + extra),
            tk, ["含税总价=%g万元" % base, "TK结算总额=%g万元" % tb,
                 "TK另加税款=%g万元" % extra],
            "%g(含税已含全部税款)+%g(另加)=%g"% (base, extra, base + extra))
    return None


def _bx_gift_split(t: str):
    """F11-003 礼品招待登记与制度对应：n×单笔 > 合并登记阈值，却按每笔免登记。"""
    for _no, sw, tk in _bx_pairs(t):
        m_thr = re.search(r"累计超过([\d,]+(?:\.\d+)?)元须报批", sw)
        if not m_thr or "合并登记" not in sw:
            continue
        m_split = re.search(r"([一二两三四五六七八九十\d]+)次各([\d,]+(?:\.\d+)?)元", tk)
        m_exempt = re.search(r"免(?:登记|报批|审批)|无需(?:登记|报批|审批)", tk)
        if not m_split or not m_exempt:
            continue
        n = _p01_cn_int(m_split.group(1))
        each = _bx_num(m_split.group(2))
        thr = _bx_num(m_thr.group(1))
        if not n or None in (each, thr):
            continue
        total = n * each
        if total <= thr + _BX_AMT_TOL:
            continue          # 未超阈值 → 合规（不判）
        return _p01_det(
            "bx_gift_split_evasion",
            "同一赠送人同月同接收人礼品须合并登记、累计超过 %g元须报批；TK 为%d次各%g元 "
            "= %g元 > %g元，却按「每笔低于阈值」声称免登记免审批（分拆规避合并登记）"
            % (thr, n, each, total, thr),
            tk, ["合并阈值=%g元" % thr, "次数=%d次" % n, "单笔=%g元" % each,
                 "合计=%g元" % total],
            "%d×%g=%g > %g" % (n, each, total, thr))
    return None


def _bx_fx_calc(t: str):
    """C14-001 币种汇率及折算正确：美元×汇率=人民币；TK 用除法（方向倒置）。"""
    for _no, sw, tk in _bx_pairs(t):
        m_rate = re.search(r"1美元[=＝]([\d.]+)元人民币", sw)
        m_usd = re.search(r"结算([\d.]+)万美元", sw)
        if not m_rate or not m_usd:
            continue
        rate_s = str(m_rate.group(1))
        rate, usd = _bx_num(rate_s), _bx_num(m_usd.group(1))
        if rate is None or not usd:
            continue
        m_tk = re.search(r"人民币结算额为([\d,]+(?:\.\d+)?)元", tk)
        if not m_tk:
            continue
        stated = _bx_num(m_tk.group(1))
        if stated is None:
            continue
        expected = usd * _BX_YUAN * rate
        prec = len(rate_s.split(".")[1]) if "." in rate_s else 0
        tol = _BX_AMT_TOL + usd * _BX_YUAN * 0.5 * (10.0 ** -prec)  # 汇率公布精度
        if abs(stated - expected) <= tol:
            continue
        inverted = abs(stated - usd * _BX_YUAN / rate) <= max(_BX_AMT_TOL, stated * 0.001)
        return _p01_det(
            "bx_fx_direction",
            "SW 约定 1美元=%s元人民币、需结算%g万美元 → 人民币应为 %g万美元×%s=%g元；"
            "TK 人民币结算额为 %g元（差 %g元）%s"
            % (rate_s, usd, usd, rate_s, expected, stated, abs(stated - expected),
               "；TK 数值等于 %g万美元÷%s=%g元，汇率作除数使用（方向倒置）"
               % (usd, rate_s, usd * _BX_YUAN / rate) if inverted else ""),
            tk, ["汇率=1美元:%s元" % rate_s, "结算额=%g万美元" % usd,
                 "应折算=%g元" % expected, "TK结算=%g元" % stated],
            "%g*10000*%s=%g元 vs %g元" % (usd, rate_s, expected, stated))
    return None


def _bx_exit_settlement(t: str):
    """E10-002 退出结算与交接安排：预付−已完成=应退；TK 再扣已在已完成中列支的专项费。"""
    for _no, sw, tk in _bx_pairs(t):
        m_pre = re.search(r"已预付([\d.]+)万元", sw)
        m_done = re.search(r"已完成[^;。]*?([\d.]+)万元", sw)
        if not m_pre or not m_done or "只退未履行余额" not in sw:
            continue
        m_fee = re.search(r"退出专项费([\d.]+)万元[^;。]*?已在[^;。]*?中列支", sw)
        m_tk = re.search(r"退回([\d.]+)万元", tk)
        if not m_fee or not m_tk:
            continue          # 无「已在已完成服务中列支」的专项费 → 无法确定性归因
        pre, done = _bx_num(m_pre.group(1)), _bx_num(m_done.group(1))
        fee, stated = _bx_num(m_fee.group(1)), _bx_num(m_tk.group(1))
        if None in (pre, done, fee, stated):
            continue
        expected = pre - done
        if abs(stated - expected) <= _bx_wan_tol():
            continue          # 退未履行余额 → 合规（不判）
        if abs(stated - (expected - fee)) > _bx_wan_tol():
            continue          # 差额无法归因为「重复扣减已列支专项费」→ 不猜
        return _p01_det(
            "bx_exit_double_deduct",
            "SW：已预付%g万元、已完成并认可服务%g万元，应退未履行余额 %g−%g=%g万元；"
            "退出专项费%g万元已批准并已在已完成服务中列支（不得二次扣减）。"
            "TK 却退回 %g万元 = %g−%g−%g，把已列支的专项费重复扣减一次"
            % (pre, done, pre, done, expected, fee, stated, pre, done, fee),
            tk, ["已预付=%g万元" % pre, "已完成=%g万元" % done,
                 "已列支专项费=%g万元" % fee, "应退=%g万元" % expected,
                 "TK退回=%g万元" % stated],
            "%g-%g=%g；%g-%g-%g=%g vs %g" % (pre, done, expected, pre, done, fee, stated,
                                            expected))
    return None


def _bx_judge(code, t):
    """BX 数值复算判据族 dispatch（输入为 _p01_norm 归一化全文）。"""
    if code == "E02-001":
        return _bx_penalty_tiers(t)
    if code == "E03-003":
        return _bx_limit_cumulative(t)
    if code == "F10-004":
        return _bx_tax_inclusive(t)
    if code == "F11-003":
        return _bx_gift_split(t)
    if code == "C14-001":
        return _bx_fx_calc(t)
    if code == "E10-002":
        return _bx_exit_settlement(t)
    return None


# ===========================================================================
# L158 召回攻坚 pilot（2026-11-25）：P01 可迁移判据 → CT 点位 + 同码多实例候选拆分/证据绑定
#
# 依据：docs/qa/build55_召回攻坚pilot_20261125.md；
#   docs/qa/L1主机制_无finding根因_20261121.md §6 ROI#3（P01 已接 16 码文内确定性算子）；
#   docs/qa/CT进了清单也不判_20261123.md §2.2/§10（下轮候选：C01-004 子集占比 14 条、
#     C06-003 日历天/工作日 11 条）；docs/qa/CT专用确定性判据_20261123.md §10.3（同上）。
#
# 本轮只做**可验证的确定性判据**，不做语义猜测；任一侧取数失败 → None，保留模型结论：
#   · 2 个 CT 点位（沿用 P01 范式：两侧取数 + 算术/方向比较 + 原文连续切片引文）：
#       C06-003 单位量纲和计量基准可比
#         ① 同一数量在「日历天/日历日」与「工作日」两种口径并存（同标签，或带期间标签）；
#         ② 投标保证金有效期「届满日…满 M 日终止」短于同文投标有效期 N 天（M < N）；
#         ③ 百分比/小数输入量级混淆（折扣率 75% 与「填写 0.75」并存）。
#       C01-004 同口径指标表内表间一致
#         ① 子集占比复算：子集 ÷ 同文总量 = P_computed，与公布值差 > 0.11pp；
#         ② 就业率分子分母倒置（公布值 == 服务人数 ÷ 就业人数）；
#         ③ 完成率 100% 但支出决算恰为年初预算 2 倍（同项重复计入的算术指纹）。
#     fail-closed：对象不在白名单/取数不足 → None；引文由 _p01_raw_quote 回填原文连续
#     切片，取不到 → guard_judged 降 insufficient（不裸 fail）。
#   · 第二跳：模型 na/insufficient → 确定性 fail 接管（与 P01/CT/BX 第二跳同口径）；
#     模型已 fail 不改（严格增量）；模型 pass 也可接管（既有首跳，同一开关门禁）。
#   · 同码多实例候选拆分/证据绑定（现有 judge_cross_ref_rule_all 之外的缺口）：
#     现有 multi_instance 为「命中→遮罩→重扫」，一次只返回 1 条聚合命中、每条只有
#     1 个引文；本段 recall_pilot_instances() 直接枚举**全部候选实例**（每个实例带
#     instance_key + 两侧证据绑定），供下游 manifest/project（本 lane 写域外）按候选
#     拆分为多条 finding；=0 时返回空（不改变默认判定）。
#
# 开关 RULEPROOF_RECALL_PILOT：**默认 0（实验）**；=0 时新点位不进 dispatch/第二跳/
# 多实例辅助 → 默认判定与 HEAD 逐字段一致；=1 才启用本段（A/B、回放与滚动验证）。
# 注意：本 lane 写域不含 .env.example 与开关注册表，故该开关暂未登记（见报告 §边界）。
# ===========================================================================
_RECALL_PILOT_ENV = "RULEPROOF_RECALL_PILOT"
# 本轮 pilot 覆盖的 CT 点位码（与 _P01/_CT/_CT2/_BX 码集不重叠或按「P01 先、CT 兜底」处理）
_RP_CT_CODES = ("C06-003", "C01-004")
# 允许把「模型判 insufficient/na」也接管为确定性 fail 的点位（第二跳；与 P01/CT/BX 同口径）
_RP_SECOND_HOP_CODES = _RP_CT_CODES
_RP_PCT_TOL = 0.11        # 占比复算容差（pp；公布值 2 位小数 + 源数四舍五入）
_RP_ABS_TOL = 0.011       # 金额/数量绝对容差（万元）
# 期间标签：用于「同一数量日历天/工作日并存」时判断两侧是否指向同一类期间
_RP_DUR_LABELS = ("投标有效期", "响应文件有效期", "磋商有效期", "投标文件有效期",
                  "合同履行期限", "履行期限", "供货及安装期", "供货安装期",
                  "供货及安装时间", "供货安装时间", "安装期", "供货期限", "交付期限",
                  "交货时间", "服务期", "计划工期", "总工期", "设计服务期", "施工工期",
                  "工期", "质保期", "保修期", "有效期")
_RP_PERIOD_LABELS = frozenset(_RP_DUR_LABELS) - {"质保期", "保修期"}
_RP_DUR_RE = re.compile(r"(\d{1,3})\s*(个工作日|工作日|日历天|日历日|天)")
_RP_LABEL_RE = re.compile("(" + "|".join(
    sorted(_RP_DUR_LABELS, key=len, reverse=True)) + ")")


def recall_pilot_enabled() -> bool:
    """RULEPROOF_RECALL_PILOT 唯一解析：默认 0（实验关），"1"/true/on/yes 为开。

    默认关的依据：本轮 CT 判据只在仓内夹具上做过离线回放（0 LLM），未做真实重跑；
    按「先实验、不改变默认判定」口径，只有显式 =1 才进入 dispatch/第二跳/多实例辅助。
    """
    try:
        return str(os.environ.get(_RECALL_PILOT_ENV, "0")).strip().lower() in (
            "1", "true", "on", "yes")
    except Exception:      # 读取失败按默认关（不放大行为）
        return False


def _rp_flat(text: str):
    """NFKC + 去全部空白（含换行）的扁平串 + 每个扁平字符回指入参文本的下标。

    计算类判据在扁平串上做跨行正则；引文回填仍走 _p01_raw_quote（要求单行连续切片），
    因此实例证据统一由 _rp_finalize 取「跨行匹配里最长的那一行」做 fragment。
    """
    out, idx = [], []
    for i, ch in enumerate(str(text or "")):
        for c in unicodedata.normalize("NFKC", ch):
            if c.isspace() or c == "\u3000":
                continue
            out.append(c)
            idx.append(i)
    return "".join(out), idx


def _rp_finalize(norm_text: str, idx: list, hits: list) -> list:
    """把扁平坐标的候选命中 → 归一化文本的单行 fragment（每实例一个主引文 + 证据引文）。

    取数失败（任一侧片段取不到）的候选整条丢弃（fail-closed：不猜、不裸报）。
    """
    out = []
    n = len(idx)
    for h in hits or []:
        anchors = h.get("anchors") or []
        frags = []
        for a in anchors:
            if not isinstance(a, (tuple, list)) or len(a) != 2:
                continue
            try:
                s, e = int(a[0]), int(a[1])
            except (TypeError, ValueError):
                continue
            if s < 0 or e <= s or s >= n:
                continue
            ts = idx[s]
            te = idx[min(e, n) - 1] + 1
            seg = str(norm_text)[ts:te]
            lines = [x for x in seg.split("\n") if x.strip()]
            if lines:
                frags.append(max(lines, key=len).strip())
        if not frags:
            continue
        d = dict(h)
        d.pop("anchors", None)
        d["fragment"] = frags[0]
        d["evidence_fragments"] = frags[1:]
        out.append(d)
    return out


def _rp_det(rule: str, detail: str, fragment: str, operands: list, recompute: str,
            instance_key: str, evidence_fragments: list) -> dict:
    return {"rule": rule, "detail": detail, "fragment": fragment,
            "operands": list(operands or []), "recompute": recompute,
            "instance_key": instance_key,
            "evidence_fragments": list(evidence_fragments or [])}


# ---------------------------------------------------------------------------
# C06-003 单位量纲和计量基准可比（3 类子判据）
# ---------------------------------------------------------------------------
def _rp_unit_workday_conflict(flat: str) -> list:
    """① 同一数量在「日历天/日历日」与「工作日」两种口径并存。

    P01 版 _p01_unit_dim_check 只覆盖「计划工期/总工期/服务期」等少数标签；CT 的注入
    机制是把「90 日历日/10 日历天/60 日历天」改成「N 个工作日」（投标有效期/供货安装
    期/合同履行期限/响应文件有效期），故本判据按「同数量+同期间标签」或「任一侧带期间
    标签」识别，两条侧证据都取原文连续切片。
    """
    occ = []
    for m in _RP_DUR_RE.finditer(flat):
        prefix = flat[max(0, m.start() - 30):m.start()]
        labels = _RP_LABEL_RE.findall(prefix)
        occ.append({"num": int(m.group(1)),
                    "unit": "workday" if "工作日" in m.group(2) else "calendar",
                    "raw": m.group(0), "label": labels[-1] if labels else "",
                    "pos": m.start(), "end": m.end()})
    bynum = {}
    for o in occ:
        bynum.setdefault(o["num"], []).append(o)
    out, seen = [], set()
    for num in sorted(bynum):
        cals = [x for x in bynum[num] if x["unit"] == "calendar"]
        wds = [x for x in bynum[num] if x["unit"] == "workday"]
        for w in wds:
            mate = None
            for c in cals:
                if w["label"] and w["label"] == c["label"]:
                    mate = (c, "same_label")
                    break
                if (w["label"] in _RP_PERIOD_LABELS) or (c["label"] in _RP_PERIOD_LABELS):
                    mate = (c, "period_label")
                    break
            if not mate:
                continue
            c, kind = mate
            key = "%d:%d" % (num, w["pos"])
            if key in seen:
                continue
            seen.add(key)
            lab = w["label"] or c["label"]
            detail = ("同一期间「%s」数量 %d 在工作日/日历天两种口径并存：文中一处写「%s」"
                      "（工作日口径），另一处写「%s」（日历口径）；%d 个工作日会实质长于"
                      "%d 个日历天，期间被延长" % (lab or "期限", num, w["raw"], c["raw"],
                                                  num, num))
            out.append({"rule": "rp_unit_calendar_workday", "detail": detail,
                        "operands": ["工作日侧=%s" % w["raw"], "日历侧=%s" % c["raw"],
                                     "期间=%s" % (lab or "期限")],
                        "recompute": "workday(%d) vs calendar(%d) kind=%s"
                                     % (num, num, kind),
                        "instance_key": "unit_calendar_workday:%d:%s" % (num, lab or ""),
                        "anchors": [(w["pos"], w["end"]), (c["pos"], c["end"])]})
    return out


def _rp_deposit_coverage(flat: str) -> list:
    """② 投标保证金有效期「届满日…满 M 日终止」短于同文投标有效期 N 天（M < N）。"""
    m = re.search(r"届满日可在开标后满(\d{1,3})日终止", flat)
    if not m:
        return []
    try:
        need = int(m.group(1))
    except ValueError:
        return []
    out = []
    for mm in re.finditer(r"投标有效期[：:]\s*开标后\s*(\d{1,3})\s*天", flat):
        try:
            have = int(mm.group(1))
        except ValueError:
            continue
        if need >= have:
            continue
        out.append({"rule": "rp_deposit_coverage",
                    "detail": ("投标保证金有效期条款写「其有效期的届满日可在开标后满%d日终止」，"
                               "短于同文投标有效期「开标后 %d 天」：保证金覆盖不足 %d 天"
                               % (need, have, have - need)),
                    "operands": ["保证金届满=%d日" % need, "投标有效期=%d天" % have],
                    "recompute": "deposit(%d) < bid_validity(%d)" % (need, have),
                    "instance_key": "deposit_coverage:%d<%d" % (need, have),
                    "anchors": [(m.start(), m.end()), (mm.start(), mm.end())]})
    return out


def _rp_pct_magnitude(flat: str) -> list:
    """③ 百分比/小数输入量级混淆：折扣率按 % 公布，却要求填写 0.x 小数。"""
    pcts = []
    for m in re.finditer(r"(?:综合)?折扣率[^\n。；]{0,20}?(\d{1,3}(?:\.\d+)?)\s*%", flat):
        try:
            pcts.append((float(m.group(1)), m.start(), m.end()))
        except ValueError:
            continue
    if not pcts:
        return []
    out = []
    for m in re.finditer(r"填写[\u201c\u201d\"']?(\d?\.\d+)[\u201c\u201d\"']?", flat):
        try:
            x = float(m.group(1))
        except ValueError:
            continue
        if not (0 < x < 1):
            continue
        p = round(x * 100.0, 2)
        mate = next((c for c in pcts if abs(c[0] - p) <= 1e-9), None)
        if not mate:
            continue
        out.append({"rule": "rp_pct_magnitude",
                    "detail": ("折扣率量级混淆：文中按百分数公布 %.2f%%，同处却要求填写小数"
                               "「%s」（量级差 100 倍：小数 %s = %.2f%%）"
                               % (mate[0], m.group(1), m.group(1), p)),
                    "operands": ["百分数=%.2f%%" % mate[0], "填写小数=%s" % m.group(1)],
                    "recompute": "%s*100=%.2f%% vs stated %.2f%%"
                                 % (m.group(1), p, mate[0]),
                    "instance_key": "pct_magnitude:%s/%.2f" % (m.group(1), mate[0]),
                    "anchors": [(m.start(), m.end()), (mate[1], mate[2])]})
    return out


# ---------------------------------------------------------------------------
# C01-004 同口径指标表内表间一致（3 类子判据）
# ---------------------------------------------------------------------------
def _rp_totals(flat: str) -> dict:
    """全国口径总量取数（只取判据族可核验的 3 个同口径对象；取不到 → 该对象跳过）。"""
    reg = {}
    m = re.search(r"全国共有幼儿园(\d+(?:\.\d+)?)万所", flat)
    if m:
        reg["全国幼儿园"] = (float(m.group(1)), "万所", m.start(0), m.end(0))
    m = re.search(r"全国共有学前教育在园幼儿[^0-9]{0,12}?(\d+(?:\.\d+)?)万人", flat)
    if not m:
        m = re.search(r"(?:学前教育)?在园幼儿\[\d+\](\d+(?:\.\d+)?)万人", flat)
    if m:
        reg["全国在园幼儿"] = (float(m.group(1)), "万人", m.start(0), m.end(0))
    m = re.search(r"特殊教育[^。；]{0,40}?在校生(\d+(?:\.\d+)?)万人", flat)
    if m:
        reg["特殊教育在校生"] = (float(m.group(1)), "万人", m.start(0), m.end(0))
    return reg


def _rp_subset_share(flat: str) -> list:
    """① 子集占比复算：子集 ÷ 同文全国总量 vs 公布「占…的比例 P%」。"""
    reg = _rp_totals(flat)
    if not reg:
        return []
    obj_map = (("幼儿园", "全国幼儿园"),
               ("在园幼儿", "全国在园幼儿"),
               ("特殊教育", "特殊教育在校生"))
    out = []
    for m in re.finditer(r"占([^，。；\n]{1,24}?)(?:的?比例)?(\d+(?:\.\d+)?)%", flat):
        label = m.group(1)
        try:
            stated = float(m.group(2))
        except ValueError:
            continue
        obj = None
        for token, name in obj_map:
            if token in label:
                obj = name
                break
        if not obj or obj not in reg:
            continue
        tot, unit, tpos0, tpos1 = reg[obj]
        if tot <= 0:
            continue
        sent_start = 0
        for sm in re.finditer(r"[。；;！？!?]", flat[:m.start()]):
            sent_start = sm.end()
        win = flat[sent_start:m.start()]
        cands = []
        for cm in re.finditer(r"(\d+(?:\.\d+)?)(万所|万人|所|人)", win):
            pre = win[max(0, cm.start() - 8):cm.start()]
            if re.search(r"(比上年|同比|减少|增加|下降|增长|提高|降低)", pre):
                continue
            if cm.group(2) != unit:
                continue
            v = float(cm.group(1))
            if 0 < v < tot * 0.999:
                cands.append((v, sent_start + cm.start(), sent_start + cm.end(),
                              cm.group(2)))
        if not cands:
            continue
        sub, spos0, spos1, sunit = cands[-1]
        comp = sub / tot * 100.0
        if abs(comp - stated) <= _RP_PCT_TOL:
            continue
        out.append({"rule": "rp_subset_share",
                    "detail": ("同口径子集占比复算：%s 子集 %.2f %s ÷ 同文总量 %.2f %s = "
                               "%.2f%%，与公布值 %.2f%% 相差 %.2fpp（超复算容差 %.2fpp）"
                               % (obj.replace("全国", ""), sub, sunit, tot, unit,
                                  comp, stated, abs(comp - stated), _RP_PCT_TOL)),
                    "operands": ["子集=%.2f%s" % (sub, sunit),
                                 "总量=%.2f%s" % (tot, unit),
                                 "公布值=%.2f%%" % stated,
                                 "复算值=%.2f%%" % comp],
                    "recompute": "%.2f/%.2f*100=%.2f%% vs %.2f%%"
                                 % (sub, tot, comp, stated),
                    "instance_key": "subset_share:%s:%.2f" % (obj, stated),
                    "anchors": [(m.start(), m.end()), (spos0, spos1), (tpos0, tpos1)]})
    return out


def _rp_inverted_rate(flat: str) -> list:
    """② 就业率分子分母倒置：公布值 == 服务人数 ÷ 促进就业人数（倒置值）。"""
    out = []
    pat = (r"(?:联系|服务)(?:服务)?(\d[\d,]*)名?[^。\n]{0,40}?促进就业(\d[\d,]*)人"
           r"[^。\n]{0,20}?就业率[达为]?\s*(\d+(?:\.\d+)?)%")
    for m in re.finditer(pat, flat):
        try:
            served = float(m.group(1).replace(",", ""))
            employed = float(m.group(2).replace(",", ""))
            stated = float(m.group(3))
        except ValueError:
            continue
        if served <= 0 or employed <= 0:
            continue
        normal = employed / served * 100.0
        inverted = served / employed * 100.0
        if abs(stated - inverted) > _RP_PCT_TOL or abs(stated - normal) <= _RP_PCT_TOL:
            continue
        out.append({"rule": "rp_inverted_rate",
                    "detail": ("就业率分子分母倒置：促进就业 %d 人 ÷ 已联系服务 %d 人 = "
                               "%.2f%%，但文中公布为 %.2f%%，恰为服务人数÷就业人数 = %.2f%%"
                               "（分子分母颠倒）"
                               % (int(employed), int(served), normal, stated, inverted)),
                    "operands": ["已联系服务=%d人" % int(served),
                                 "促进就业=%d人" % int(employed),
                                 "公布值=%.2f%%" % stated,
                                 "正算值=%.2f%%" % normal,
                                 "倒置值=%.2f%%" % inverted],
                    "recompute": "%d/%d*100=%.2f%% vs stated %.2f%%"
                                 % (int(employed), int(served), normal, stated),
                    "instance_key": "inverted_rate:%d/%d" % (int(served), int(employed)),
                    "anchors": [(m.start(), m.end())]})
    return out


def _rp_budget_double(flat: str) -> list:
    """③ 完成率 100% 但支出决算恰为年初预算 2 倍（同项重复计入的算术指纹）。

    窄口径（不放开通用「完成率≠决算/预算」：原始文档存在预算调整/跨项口径，通用比较
    会在非注入文档上误报）：只认「公布完成率 100.00% 且 决算 == 2×年初预算」的确定
    重复计入形态。
    """
    out = []
    pat = (r"年初预算为(\d+(?:\.\d+)?)万元[^。；\n]{0,40}?支出决算为"
           r"(\d+(?:\.\d+)?)万元[^。；\n]{0,20}?完成年初预算的(100(?:\.0+)?)%")
    for m in re.finditer(pat, flat):
        try:
            budget = float(m.group(1))
            actual = float(m.group(2))
            stated = float(m.group(3))
        except ValueError:
            continue
        if budget <= 0 or abs(actual - 2 * budget) > _RP_ABS_TOL:
            continue
        out.append({"rule": "rp_budget_double_count",
                    "detail": ("完成率勾稽：年初预算 %.2f 万元、支出决算 %.2f 万元，复算完成率 "
                               "%.2f%%，但公布为 %.2f%%；决算额恰为年初预算 2 倍"
                               "（同项重复计入的算术指纹）"
                               % (budget, actual, actual / budget * 100.0, stated)),
                    "operands": ["年初预算=%.2f万元" % budget,
                                 "支出决算=%.2f万元" % actual,
                                 "公布完成率=%.2f%%" % stated],
                    "recompute": "actual(%.2f) == 2*budget(%.2f)" % (actual, budget),
                    "instance_key": "budget_double_count:%.2f->%.2f" % (budget, actual),
                    "anchors": [(m.start(), m.end())]})
    return out


_RP_CT_DETECTORS = {
    "C06-003": lambda flat: (_rp_unit_workday_conflict(flat)
                             + _rp_deposit_coverage(flat)
                             + _rp_pct_magnitude(flat)),
    "C01-004": lambda flat: (_rp_subset_share(flat)
                             + _rp_inverted_rate(flat)
                             + _rp_budget_double(flat)),
}


def _rp_judge_all(code: str, norm_text: str) -> list:
    """CT pilot 点位 → 全部候选确定性实例（每实例含单行 fragment + 证据片段）。"""
    code = str(code or "").strip()
    fn = _RP_CT_DETECTORS.get(code)
    body = str(norm_text or "")
    if not fn or not body.strip():
        return []
    flat, idx = _rp_flat(body)
    if not flat:
        return []
    return _rp_finalize(body, idx, fn(flat))


def _rp_judge(code: str, norm_text: str):
    """CT pilot 点位单条判定（返回第一条候选；无候选 → None，调用方保留模型结论）。"""
    hits = _rp_judge_all(code, norm_text)
    if not hits:
        return None
    h = dict(hits[0])
    ev = h.pop("evidence_fragments", [])
    return _rp_det(h.get("rule") or "recall_pilot", h.get("detail") or "",
                   h.get("fragment") or "", h.get("operands") or [],
                   h.get("recompute") or "", h.get("instance_key") or "", ev)


def recall_pilot_bind_instances(text: str, candidates: list,
                                accepted: list | None = None, limit: int = 0) -> dict:
    """同码多实例「候选拆分/证据绑定」：把候选实例绑定为互不重叠的独立证据实例。

    与既有 ``mi_accept_instances`` 的差异（现有 multi_instance 之外的缺口）：
      ① 候选由确定性判据**一次枚举**（不是「命中→遮罩→重扫」），同一码的多个独立
         违规（如 CT-054 的 30/60 两处单位漂移）一次全部拿到；
      ② 每个候选带 ``instance_key``（期间/对象/数值三元组）与 ``evidence``（主引文 +
         对侧证据引文），绑定结果可直接作多条 finding 的候选，便于与 gold 多条目对账；
      ③ 去重口径 = instance_key 唯一 + 引文/span 不重叠（同一处原文只算 1 实例）。
    绑定不接受「引文不可逐字定位 / 归一化 <8 字 / 与已接受实例引文互相包含 / span 重叠」
    的候选（fail-closed，不把两个实例粘成一条）。返回
    {accepted, rejected:[{quote,instance_key,reason}], truncated, limit, input, accepted_count}。
    """
    cap = max(1, min(int(limit or 0) or multi_instance_limit(), multi_instance_limit()))
    acc = [dict(x) for x in (accepted or []) if isinstance(x, dict)]
    keys = {str(a.get("instance_key") or "") for a in acc if a.get("instance_key")}
    out, rejected, truncated = [], [], 0
    for c in candidates or []:
        if not isinstance(c, dict):
            continue
        q = str(c.get("quote") or "")
        key = str(c.get("instance_key") or "")
        why = ""
        if not q:
            why = "quote_missing"
        elif len(_p01_norm(q)) < 8:
            why = "quote_too_short"
        elif not _mi_offsets(text, q):
            why = "quote_not_verbatim"
        elif key and key in keys:
            why = "duplicate_instance_key"
        else:
            nq = _p01_norm(q)
            for a in acc:
                aq = str(a.get("quote") or "")
                naq = _p01_norm(aq)
                if naq and (nq in naq or naq in nq):
                    why = "same_instance_as_accepted"
                    break
                for (s1, e1) in _mi_offsets(text, q):
                    for (s2, e2) in _mi_offsets(text, aq):
                        if s1 < e2 and s2 < e1:
                            why = "instance_span_overlap"
                            break
                    if why:
                        break
                if why:
                    break
        if why:
            rejected.append({"quote": q[:120], "instance_key": key, "reason": why})
            continue
        if len(acc) >= cap:
            truncated += 1
            continue
        acc.append(dict(c))
        out.append(dict(c))
        if key:
            keys.add(key)
    return {"accepted": out, "rejected": rejected, "truncated": truncated,
            "limit": cap, "input": len(candidates or []), "accepted_count": len(acc),
            "source": "ruleexec.recall_pilot_bind_instances"}


def recall_pilot_instances(code: str, text: str, limit: int = 0) -> dict:
    """同码多实例辅助：枚举该 CT pilot 点位的全部独立违规实例并绑定证据。

    返回 {code, enabled, instances, rejected, truncated, limit, generated_count,
    applied_count, source}；开关 =0 / 非 pilot 码 → instances 为空（默认判定不变）。
    本 lane 不把它接入 manifest/project（写域外）；它供下游按候选拆分 finding，或供
    离线回放/人工复核核对「同码多条违规」的候选数与证据绑定。
    """
    res = {"code": str(code or ""), "enabled": recall_pilot_enabled(),
           "instances": [], "rejected": [], "truncated": 0,
           "limit": multi_instance_limit() if recall_pilot_enabled() else 0,
           "generated_count": 0, "applied_count": 0,
           "source": "ruleexec.recall_pilot_instances"}
    code = str(code or "").strip()
    body = str(text or "")
    if not res["enabled"] or code not in _RP_CT_CODES or not body.strip():
        return res
    norm_text = _p01_norm(body)
    cands = []
    for h in _rp_judge_all(code, norm_text):
        q = _p01_raw_quote(body, h.get("fragment") or "")
        ev = []
        for f in h.get("evidence_fragments") or []:
            eq = _p01_raw_quote(body, f)
            if eq:
                ev.append(eq)
        span = _mi_raw_span(body, h.get("fragment") or "")
        cands.append({"code": code, "rule": h.get("rule") or "recall_pilot",
                      "detail": h.get("detail") or "", "quote": q,
                      "operands": h.get("operands") or [],
                      "recompute": h.get("recompute") or "",
                      "instance_key": h.get("instance_key") or "",
                      "span": [span[0], span[1]] if span else None,
                      "evidence": ([{"role": "primary", "quote": q}] if q else [])
                                  + [{"role": "counterpart", "quote": x} for x in ev]})
    res["generated_count"] = len(cands)
    bound = recall_pilot_bind_instances(body, cands, limit=limit)
    res["instances"] = bound["accepted"]
    res["rejected"] = bound["rejected"]
    res["truncated"] = bound["truncated"]
    res["limit"] = bound["limit"]
    res["applied_count"] = bound["accepted_count"]
    return res


def _p01_norm_map(line: str):
    """单行 NFKC+去空白后的字符串，以及每个归一字符回指原文的下标。"""
    import unicodedata as _ud
    out, idx = [], []
    for i, ch in enumerate(str(line or "")):
        n = _ud.normalize("NFKC", ch)
        for c in n:
            if c in " \t\u3000":
                continue
            out.append(c)
            idx.append(i)
    return "".join(out), idx


def _p01_raw_quote(text: str, fragment: str) -> str:
    """归一化片段 → 原文**连续切片**（证据门禁要求 quote 必须是原文连续逐字片段）。

    2026-11-22：长行（工程概况/表格行）整行截断会把证据句截掉（回放里 P01-024 的
    「其中钢筋混凝土板涵64道」在 220 字之后 → 引文不可核验/匹配失败）。改为：
    在归一化行内定位片段，再按字符映射回原文下标，取片段前后窗口的连续原文切片。
    """
    frag = str(fragment or "")
    if not frag:
        return ""
    for line in str(text or "").splitlines():
        if not line.strip():
            continue
        nline, idx = _p01_norm_map(line)
        pos = nline.find(frag)
        if pos < 0:
            continue
        start = idx[pos]
        last = pos + len(frag) - 1
        end = idx[last] + 1 if last < len(idx) else len(line)
        left = max(0, start - 60)
        right = min(len(line), end + 120)
        q = line[left:right].strip()
        return q[:260]
    return ""


def judge_cross_ref_rule(code: str, text: str) -> dict | None:
    """P01 审核点的文内确定性结构算子。

    返回 {"state":"不满足", "rule", "detail", "quote", "operands", "recompute"}；
    None 表示该点位没有文内结构判据 / 取数不足（调用方必须保留模型结论，不猜）。
    """
    code = str(code or "").strip()
    _rp_on = bool(code in _RP_CT_CODES and recall_pilot_enabled())
    if code not in _P01_CROSSREF_CODES and code not in _CT_DET_CODES \
            and code not in _CT2_CODES and code not in _BX_DET_CODES and not _rp_on:
        return None
    body = str(text or "")
    if not body.strip():
        return None
    t = _p01_norm(body)
    det = None
    try:
        if code == "C01-005":
            det = _p01_sum_check(t)
        elif code == "C10-001":
            det = _p01_qty_check(t) or _p01_unit_check(t)
        elif code == "C09-001":
            det = _p01_date_chain(t)
        elif code == "F02-007":
            det = _p01_count_claim(t)
        elif code == "C01-001":
            det = _p01_sum_total(t)
        elif code == "C06-003":
            det = _p01_unit_dim_check(t)
        elif code == "F08-002":
            det = _p01_perf_check(t)
        elif code == "A01-005":
            det = _p01_role_check(t)
        elif code == "A02-004":
            det = _p01_personnel_check(t)
        elif code == "F02-004":
            det = _p01_response_item_check(t)
        elif code == "A02-006":
            det = _p01_business_qual_check(t)
        elif code == "F01-006":
            det = _p01_review_condition_check(t)
        elif code == "A02-002":
            det = _p01_qual_grade_check(t)
        elif code == "A01-003":
            det = _p01_subject_info_check(t)
        elif code == "C08-003":
            det = _p01_fee_base_check(t)
        elif code == "B03-002":
            det = _p01_ref_source_check(t)
        elif code == "C09-002":
            det = _p01_period_calc_check(t)
        elif code in _BX_DET_CODES:
            det = _bx_judge(code, t)      # BX 合同 SW/TK 数值复算判据族（第二侧取数）
        elif code in _CT_DET_CODES:
            det = _ct_disclosure_check(t)
        if det is None and code in _CT2_CODES:
            det = _ct2_judge(code, t)   # CT 专用判据族（P01 同码判据取不到时兜底）
        if det is None and code in _RP_CT_CODES and recall_pilot_enabled():
            det = _rp_judge(code, t)    # L158 pilot：CT C06-003/C01-004（默认关）
    except Exception:  # 铁律 2：算子异常不得静默；判不了就交回模型结论
        logging.getLogger(__name__).warning(
            "cross_ref_rule failed（原样返回模型结论）code=%s", code, exc_info=True)
        return None
    if not det:
        return None
    det = dict(det)
    det["state"] = "不满足"
    det["quote"] = _p01_raw_quote(body, det.get("fragment") or "")
    return det


# ===========================================================================
# 同码多实例（2026-11-23，multi-instance）：规则的**返回结构**支持多实例
#
# 结构性上限（docs/qa/CT进了清单也不判_20261123.md §2.2/§6.5）：manifest 每个
# 「文档 × 规则码」只有 1 个 item / 1 个 D4 子要求 → 物化 1 条 finding，而 gold
# 同码常 9–11 条。CT 810 条 FN 中 570 条（70.4%）卡在「同码单实例上限」
# （同码 finding 数不足 218 + 有 fail 对不上 352 的上限部分）。
#
# 本段只做**多实例返回结构**：把既有确定性算子从「只回第一条」扩展成「按实例逐条回」，
# 供 manifest_exec.py（D4 追加子要求）与 project.py（物化为多条 finding）使用。
# 开关 RULEPROOF_MULTI_INSTANCE（2026-11-23 起默认 1；=0 回滚）：关闭时 judge_cross_ref_rule 等既有函数
# 逐字段不变；本段新增函数在关闭时一律返回 []（不物化任何额外实例）。
#
# 实例判据（与任务口径一致）：
#   ① 同一 (case, rule_code) 下，两实例的**归一化 quote 互不包含**且 **span 不重叠**
#      → 视为不同实例；同一实例重复输入（同引文/同 span）只留 1 条（幂等）。
#   ② 每个实例仍必须通过既有引文门禁：quote 必须是原文连续逐字切片。
#   ③ 每 (doc, code) 上限 5 个实例（防噪声爆炸），超出记录审计并截断（不静默）。
# ===========================================================================
_MULTI_INSTANCE_ENV = "RULEPROOF_MULTI_INSTANCE"
# 每 (doc, code) 实例上限：默认 5。
# 轮 B（2026-11-23）实测 cap10：CT F1 .3266→.3987（+7.21pp CI[+4.62,+9.62]）收益成立，
# 但预注册质量门「新增 FP ≤26」实测 34 未过（新增 TP 69 / TP 率 67.0% 两项通过）
# → 按预注册规则**回滚默认 5**（docs/qa/CT上限实测_20261122.md §5）。
# 机制保留：显式 RULEPROOF_MULTI_INSTANCE_LIMIT=10 可启用（下轮解耦 prompt 顶棚后重测）。
_MULTI_INSTANCE_LIMIT = 5
_MI_ALL_CODES = tuple(_P01_CROSSREF_CODES) + tuple(_CT_DET_CODES) + tuple(_CT2_CODES)


def multi_instance_enabled() -> bool:
    """总开关：2026-11-23 起**默认 1（开）**，=0 为回滚杆。

    默认开的依据（真实重跑，非回放）：
    - CT 44 份：.1761 → .2781（+10.20pp CI[+5.64,+14.71]，新增 61TP/8FP）
    - P01 30 份：.4586 → .4858（+2.72pp CI[+0.21,+5.49]，新增 13TP/7FP）
    - 三数据集合并 L1：Δ(A−B) −4.40pp → −0.16pp（+4.24pp），无数据集点估计变差
    证据：docs/qa/CT多实例真实重跑_20261123.md、docs/qa/P01真实重跑v3_20261123.md、
    docs/qa/L1三数据集合并v2_20261123.md。
    """
    try:
        return str(os.environ.get(_MULTI_INSTANCE_ENV, "1")).strip().lower() not in (
            "0", "false", "no", "off")
    except Exception:
        return True


def multi_instance_limit() -> int:
    """每 (doc, code) 实例上限：默认 5（轮 B cap10 实测未过预注册质量门 → 回滚；
    显式 ``RULEPROOF_MULTI_INSTANCE_LIMIT=10`` 可启用 cap10），环境变量可调（1–20 夹逼）。"""
    try:
        n = int(os.environ.get("RULEPROOF_MULTI_INSTANCE_LIMIT",
                               str(_MULTI_INSTANCE_LIMIT)) or _MULTI_INSTANCE_LIMIT)
    except Exception:
        n = _MULTI_INSTANCE_LIMIT
    return max(1, min(n, 20))


def mi_instance_reject(text: str, quote: str, accepted: list) -> str:
    """实例判据：返回拒绝原因（空串 = 接受为独立实例）。

    ① 引文必须逐字命中原文（可定位 span）；② ≥8 字（防「合计」「符合」类短引文粘连）；
    ③ 归一化引文不得与已接受实例互相包含（同一实例的不同截取）；④ span 不得重叠
    （同一处原文不能算两个实例 → 同一实例重复输入只留 1 条，幂等）。
    """
    q = str(quote or "").strip()
    if not q:
        return "quote_missing"
    nq = _p01_norm(q)
    if len(nq) < 8:
        return "quote_too_short"
    spans = _mi_offsets(text, q)
    if not spans:
        return "quote_not_verbatim"
    for a in accepted or []:
        aq = str((a or {}).get("quote") or "").strip()
        if not aq:
            continue
        naq = _p01_norm(aq)
        if not naq:
            continue
        if nq in naq or naq in nq:
            return "same_instance_as_accepted"
        for (s1, e1) in spans:
            for (s2, e2) in _mi_offsets(text, aq):
                if s1 < e2 and s2 < e1:
                    return "instance_span_overlap"
    return ""


def _mi_offsets(text: str, quote: str) -> list:
    """引文在**原文**中的全部 [start,end) 位置（逐字；找不到返回 []）。"""
    t, q = str(text or ""), str(quote or "")
    if not t or not q:
        return []
    out, i = [], t.find(q)
    while i >= 0:
        out.append((i, i + len(q)))
        i = t.find(q, i + 1)
    return out


def mi_accept_instances(text: str, rows: list, accepted: list | None = None,
                        limit: int = 0) -> dict:
    """按实例判据从候选行里挑独立实例（供 project.py 物化拆分使用）。

    rows: [{"quote":..., ...}]; accepted: 已接受实例（同结构）。
    返回 {"accepted": [...], "rejected": [{"quote","reason"}], "truncated": n,
          "limit": cap, "input": len(rows)}。
    """
    cap = max(1, min(int(limit or 0) or multi_instance_limit(), multi_instance_limit()))
    acc = [dict(x) for x in (accepted or []) if isinstance(x, dict)]
    out, rejected, truncated = [], [], 0
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        if len(acc) >= cap:
            truncated += 1
            continue
        q = str(r.get("quote") or "")
        why = mi_instance_reject(text, q, acc)
        if why:
            rejected.append({"quote": q[:120], "reason": why})
            continue
        acc.append(dict(r))
        out.append(dict(r))
    return {"accepted": out, "rejected": rejected, "truncated": truncated,
            "limit": cap, "input": len(rows or [])}


def _mi_raw_span(text: str, fragment: str):
    """归一化片段 → 原文**紧切片** (start, end, quote)。

    与 ``_p01_raw_quote`` 的区别：不带 ±60/120 字上下文，保证不同实例的 span 互不
    重叠（上下文窗口会让两条实例的 quote 互相包含，被实例判据误判成同一实例）。
    找不到返回 None。
    """
    t, frag = str(text or ""), str(fragment or "")
    if not t or not frag:
        return None
    off = 0
    for line in t.splitlines(keepends=True):
        if line.strip():
            try:
                nline, idx = _p01_norm_map(line)
            except Exception:
                nline, idx = "", []
            pos = nline.find(frag)
            if pos >= 0:
                last = pos + len(frag) - 1
                s = off + idx[pos]
                e = off + (idx[last] + 1 if last < len(idx) else len(line))
                if e > s:
                    return (s, e, t[s:e])
        off += len(line)
    return None


def _mi_mask_fragment(text: str, fragment: str) -> str | None:
    """把归一化片段对应的**原文连续区间**替换成 □（逐行回查，保留其余上下文）。

    用于「遮罩 + 重扫」找同码的下一条独立违规实例；找不到返回 None（调用方停止）。
    """
    t, frag = str(text or ""), str(fragment or "")
    if not t or not frag:
        return None
    off = 0
    for line in t.splitlines(keepends=True):
        if line.strip():
            try:
                nline, idx = _p01_norm_map(line)
            except Exception:
                nline, idx = "", []
            pos = nline.find(frag)
            if pos >= 0:
                last = pos + len(frag) - 1
                s = off + idx[pos]
                e = off + (idx[last] + 1 if last < len(idx) else len(line))
                return t[:s] + ("\u25a1" * max(1, e - s)) + t[e:]
        off += len(line)
    return None


def judge_cross_ref_rule_all(code: str, text: str, limit: int = 0,
                             truncation_sink: list | None = None) -> list:
    """同码多实例：逐个返回该点位的**全部**独立违规实例（确定性算子，不调模型）。

    复用 judge_cross_ref_rule（只回第一条）：命中后用「遮罩 + 重扫」找下一条，
    每条都过 mi_instance_reject（引文逐字 / 互不包含 / span 不重叠 / ≥8 字），
    最多 limit 条（默认 multi_instance_limit()，当前默认 5；cap10 机制保留可显式启用）。返回
    [{state,rule,detail,quote,fragment,operands,recompute,instance_index,
    instance_audit}]。开关关闭 / 非白名单码 → []。

    ``truncation_sink``（A 类缺陷修复 2026-11-23）：传入 list 时，若独立实例数超过
    cap，函数在**不改返回值**的前提下继续扫描剩余候选，把「被丢弃候选数 + quote 摘要」
    追加进 sink，供调用方写 ``multi_instance.truncated`` 审计——原先在 cap 处直接
    ``break``，导致审计看到的 truncated 恒为 0（静默截断）。默认 None = 旧行为不变。
    """
    if not multi_instance_enabled():
        return []
    code = str(code or "").strip()
    body = str(text or "")
    if code not in _MI_ALL_CODES or not body.strip():
        return []
    cap = max(1, min(int(limit or 0) or multi_instance_limit(), multi_instance_limit()))
    out, accepted, masked = [], [], body
    for _ in range(cap + 3):
        try:
            det = judge_cross_ref_rule(code, masked)
        except Exception:
            logging.getLogger(__name__).warning(
                "multi-instance judge failed code=%s", code, exc_info=True)
            break
        if not det:
            break
        frag = str(det.get("fragment") or "")
        span = _mi_raw_span(body, frag) if frag else None
        q = span[2] if span else ""
        why = mi_instance_reject(body, q, accepted) if q else "quote_missing"
        if not why:
            if len(out) >= cap:
                break
            accepted.append({"quote": q})
            d = dict(det)
            d["quote"] = q
            d["state"] = "不满足"
            d["instance_index"] = len(out) + 1
            d["instance_span"] = [span[0], span[1]]
            d["instance_audit"] = {"code": code, "limit": cap,
                                   "source": "ruleexec.judge_cross_ref_rule_all"}
            out.append(d)
        nxt = _mi_mask_fragment(masked, frag) if frag else None
        if not nxt or nxt == masked:
            break
        masked = nxt
    if truncation_sink is not None and len(out) >= cap and masked:
        # A 类审计：已到 cap，但屏蔽重扫仍能命中候选 → 继续扫描计数（不追加输出）。
        # 该分支只在调用方显式传入 sink 时进入，默认路径（None）与原实现逐字段一致。
        discarded, digests, scan = 0, [], 0
        while masked and scan < 512:
            scan += 1
            try:
                det = judge_cross_ref_rule(code, masked)
            except Exception:
                logging.getLogger(__name__).warning(
                    "multi-instance truncation scan failed code=%s", code, exc_info=True)
                break
            if not det:
                break
            frag = str(det.get("fragment") or "")
            span = _mi_raw_span(body, frag) if frag else None
            q = span[2] if span else ""
            why = mi_instance_reject(body, q, accepted) if q else "quote_missing"
            if not why:
                discarded += 1
                if len(digests) < 5:
                    digests.append(q[:60])
            nxt = _mi_mask_fragment(masked, frag) if frag else None
            if not nxt or nxt == masked:
                break
            masked = nxt
        if discarded or (masked and scan >= 512):
            # 只有真的丢弃了候选（或扫描到安全上限）才写审计，避免「恰好等于 cap 但无剩余」误报
            truncation_sink.append({
                "action": "truncated", "code": code, "limit": cap,
                "accepted": len(out), "discarded_candidates": discarded,
                "discarded_quotes": digests,
                "scan_limit_reached": bool(masked and scan >= 512),
                "source": "ruleexec.judge_cross_ref_rule_all"})
    return out


def _judge_guard_on(name: str) -> bool:
    """守卫开关：总开关 + 分项开关，默认开；任何非空非 1 值视为关闭。"""
    if str(os.environ.get("RULEPROOF_JUDGE_GUARD", "1")).strip() in ("0", "false", "off", "no"):
        return False
    v = str(os.environ.get(name, "1")).strip()
    return v not in ("0", "false", "off", "no")


# ============================================================================
# P0-8（T-181）：AI 数据集 L1 clean-control 20/112 误报根因修复（作用域/负号/量纲）
#
# T-176 实测：20 条 FP 全部是确定性限值执行器在更丰富 AI 正文上的作用域误配：
#   中心温度作用域 ×11（非加热工序的实测/上限中心温度被判 ≥85℃）
#   冷却环境温度 ×3（冷却间环境温度被判 冷却终温≤10℃）
#   解冻方式 ×2（「每 4h 记录库温」的监测频率被判成 解冻时长 4h）
#   负温度 ×2（「冷冻库温度 ≤-18℃」负号丢失成 18℃ 后与 0-8℃ 比较）
#   余氯 ppm ×2（「余氯≤0.1 ppm」残留限被判成 消毒液浓度 0.1ppm <200ppm）
# 修法：只修执行器的取数/作用域，不放宽判据、不改 gold：
#   1) 温度取数支持负号（range 的连字符不误当负号）；
#   2) 中心温度≥85℃ 判据只认「加热工序 + 温度下限要求」的事实，上限/非加热实测不判违规；
#   3) 冷却终温≤10℃ 判据只认产品终温（终温/中心温度/品温），冷却间环境温度不算；
#   4) 冷藏暂存判据不把冷冻/速冻库（≤-18℃）当冷藏暂存违规；
#   5) 消毒浓度判据只认「浓度」上下文，余氯/残留限不参与；监测频率（每4h）不当解冻时长。
# 开关：RULEPROOF_P0_LIMIT_SCOPE_FIX=0 恢复旧口径（默认开；回滚/A-B 用）。
# ============================================================================
_P0_LIMIT_SCOPE_ENV = "RULEPROOF_P0_LIMIT_SCOPE_FIX"
# 支持负号的温度取数（range 分隔符前的 ℃/° 排除，避免「24℃-26℃」的 26 被当成 -26）
_TEMP_RANGE_SIGNED = re.compile(
    r"(?<![\d.℃°])(-?\d+(?:\.\d+)?)\s*[-~]\s*(-?\d+(?:\.\d+)?)\s*(℃|°C)")
_TEMP_SINGLE_SIGNED = re.compile(r"(?<![\d.℃°])(-?\d+(?:\.\d+)?)\s*(℃|°C)")
# 加热工序关键词：中心温度≥85℃ 只属于加热/熟制工序（烘烤/蒸煮/卤制/灭菌/焯水…）
_HEATING_PROCESS_WORDS = (
    "烘烤", "烘焙", "烤制", "焙烤", "烤", "蒸煮", "清蒸", "蒸", "卤制", "卤水",
    "灭菌", "杀菌", "焯水", "焯烫", "油炸", "加热", "熟制", "熬煮", "煎", "炒制",
)
# 温度下限要求标记（中心温度判据是「≥下限」；没有下限要求的上限/实测不判违规）
_TEMP_LOWER_MARKS = ("≥", ">=", "不低于", "至少", "不得低于", "应不低于", "高于")
# 温度上限/目标标记（这类事实不是「中心温度应达到」的违规对象）
_TEMP_UPPER_MARKS = ("≤", "<=", "以下", "以内", "不高于", "不得超过", "不超过", "低于")

# ---------------------------------------------------------------------------
# L178（2026-11-26）外部 build56 全链路评审 P1：确定性限值通道与食品引擎同结论
#
# 评审证据：/tmp/review56/证据/复测.py（隔离库、合成 xlsx、0 模型）实测
#   ① 消毒浓度单位：packs/food.py 已按 ppm 归一（200ppb=0.2ppm < 200ppm → 不满足），
#      但 manifest 确定性通道只从文本抽 ppm|mg/kg（rexec 旧 _CONC），200ppb 完全抽不到
#      → RW20260525006 记「未抽取到消毒浓度数值」→ CLI 与引擎结论相反。
#   ② 中心温度作用域闸：`_fact_allowed_for_p0` 只认数值**前**的「≥/不低于/至少/高于」
#      与既有加热工序词；「中心温度90℃以上出锅」的「以上」（数值**后**的下限）与
#      「出锅」（加热工序）都不识别 → 温度事实被闸掉 → RW20260525005 证据不足；
#      而 packs/food.py 对同一文本判定不满足（70℃ < 85℃），CLI 与引擎结论相反。
#
# 修法（只修取数/单位归一，不放宽阈值、不改判据方向）：
#   · 浓度取数复用 rexec L39 已登记单位词表 `_CONC_FIX2`（ppm/ppb/mg/kg/μg/kg/g/kg，
#     与引擎 facts 层同一事实源），比较前用执行器注册表 `_convert` 归一到判据单位
#     （单一事实源 app/engine/registry.py，不新建第二张换算表）；展示保留「原值=归一值」。
#   · 中心温度「以上/及以上」识别为下限语义；「出锅」识别为加热工序。
# 开关（默认 1；=0 逐字回退旧口径，供 A/B 与回滚）：
#   RULEPROOF_DET_LIMIT_CONC_UNIT_FIX / RULEPROOF_DET_LIMIT_TEMP_SCOPE_FIX
# ---------------------------------------------------------------------------
_DET_LIMIT_CONC_UNIT_ENV = "RULEPROOF_DET_LIMIT_CONC_UNIT_FIX"
_DET_LIMIT_TEMP_SCOPE_ENV = "RULEPROOF_DET_LIMIT_TEMP_SCOPE_FIX"
# 值后下限语义（「90℃以上」「≥…」的等价写法）
_DET_LIMIT_LOWER_AFTER_MARKS = ("以上", "及以上")
# 补充加热工序词（L178：与平台点位判据原文「加热工序必须标注中心温度达到 85℃ 以上
# 才能出锅」同词表；只补「出锅」，不动既有词表，避免跨场景语义漂移）
_DET_LIMIT_HEATING_EXTRA = ("出锅",)


def _det_limit_conc_unit_fix_on() -> bool:
    """L178 ①：确定性限值通道浓度跨单位归一并比较（默认 1；=0 回退旧「只认 ppm」）。"""
    return str(os.environ.get(_DET_LIMIT_CONC_UNIT_ENV, "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _det_limit_temp_scope_fix_on() -> bool:
    """L178 ②：中心温度「以上」下限 +「出锅」加热工序识别（默认 1；=0 回退旧口径）。"""
    return str(os.environ.get(_DET_LIMIT_TEMP_SCOPE_ENV, "1")).strip().lower() not in (
        "0", "false", "off", "no")


def _det_limit_normalize_fact(fact: dict, target_unit: str):
    """L178 ①：把数值事实换算到判据单位；返回 ``(fact|None, 不可识别单位)``。

    - 判据无单位 / 事实无单位 / 单位同键 → 原事实（单位缺失不猜成判据单位）；
    - 同量纲已登记单位（如 ppb → ppm）→ 克隆事实：``value``=归一值、``unit``=判据单位，
      保留 ``raw_value/raw_unit`` 供展示「原值=归一值」，``unit_source=conversion_table``；
    - 未登记/跨量纲（如「个」）→ ``(None, 单位原文)``，调用方计入 ``unit_undecided``
      转证据不足（不猜单位、不按原值硬比）。
    """
    src_unit = str((fact or {}).get("unit") or "").strip()
    tu = str(target_unit or "").strip()
    if not tu or not src_unit:
        return dict(fact or {}), ""
    if _unit_key(src_unit) == _unit_key(tu) and _unit_key(src_unit):
        return dict(fact or {}), ""
    try:
        conv = _convert(float((fact or {}).get("value")), src_unit, tu)
    except (TypeError, ValueError, OverflowError):
        conv = None
    if conv is None:
        return None, src_unit
    nf = dict(fact or {})
    nf["raw_value"] = (fact or {}).get("value")
    nf["raw_unit"] = src_unit
    nf["value"] = conv
    nf["unit"] = tu
    nf["unit_source"] = "conversion_table"
    return nf, ""


def _p0_limit_scope_fix_on() -> bool:
    return str(os.environ.get(_P0_LIMIT_SCOPE_ENV, "1")).strip() not in (
        "0", "false", "off", "no")


def _thaw_criterion_pending_on() -> bool:
    """解冻「口径待定」开关（L26，2026-11-23；与 packs/food.py 同一环境变量，默认开）。

    manifest 确定性通道（``judge_limit_rule``）必须与 packs/food.py 的 B1-L1 T03
    待定分支同口径，否则生产 0-LLM 通道仍把「流动水/室温解冻 4-6h」当解冻时长 <20h
    判 fail（L20 已指出 md 主链未接线；L23/L25 clean 100/100 复现）。
    ``RULEPROOF_THAW_CRITERION_PENDING=0`` 回退旧行为（所有含「解冻」行的时间数值参与 ≥20h 比较）。
    """
    return str(os.environ.get("RULEPROOF_THAW_CRITERION_PENDING", "1")).strip().lower() \
        not in ("0", "false", "off", "no")


def _disinfect_scope_fix_on() -> bool:
    """消毒浓度「对象作用域」开关（L26，2026-11-23；与 rexec/packs 同口径，默认开）。

    ``RULEPROOF_DISINFECT_SCOPE_FIX=0`` 回退旧行为（所有 ppm 一律参与 ≥200ppm 比较）。
    手部/洗手消毒液（50-100ppm，人体卫生更窄规则）不套「工器具/环境/食品接触面消毒液」判据。
    """
    return str(os.environ.get("RULEPROOF_DISINFECT_SCOPE_FIX", "1")).strip().lower() \
        not in ("0", "false", "off", "no")


def _fact_allowed_for_p0(spec: dict, fact: dict) -> bool:
    """P0-8 作用域闸：该数值事实是否真的属于本判据的执行作用域。

    只做「事实是否属于判据对象」的判定，不放宽阈值/方向/单位比较本身；
    开关关闭时恒 True（旧口径）。
    """
    # L28 输入类型守卫：非 dict 入参显式 TypeError（由 _spec_facts 计数转「证据不足」），
    # 不允许 AttributeError 冒到主链把 D5 记为 blocked。
    if not isinstance(spec, dict) or not isinstance(fact, dict):
        raise TypeError("_fact_allowed_for_p0 requires dict spec/fact")
    if not _p0_limit_scope_fix_on():
        return True
    kind = str(spec.get("kind") or "")
    scope = str(spec.get("scope") or "")
    before = str(fact.get("before") or "")
    after = str(fact.get("after") or "")
    line = str(fact.get("line") or "")
    if kind == "temp" and scope == "中心温度":
        # 上限/目标型事实（≤10℃、以下、不超过…）不是「加热中心温度下限」的违规对象
        if any(k in before for k in _TEMP_UPPER_MARKS) \
                or any(k in after for k in ("以下", "以内")):
            return False
        # 排除型条件句（「高于 4℃ 的原料单独隔离报废」= 超过即报废的上限，不是加热要求）
        if any(k in after for k in ("报废", "隔离", "拒收", "退回", "作废", "不得")):
            return False
        lower = any(k in before for k in _TEMP_LOWER_MARKS)
        # L178 ②：值后「以上/及以上」= 下限语义（判据原文「中心温度达到 85℃ 以上才能出锅」）
        if not lower and _det_limit_temp_scope_fix_on():
            lower = any(k in after for k in _DET_LIMIT_LOWER_AFTER_MARKS)
        heating = any(k in line for k in _HEATING_PROCESS_WORDS)
        if not heating and _det_limit_temp_scope_fix_on():
            heating = any(k in line for k in _DET_LIMIT_HEATING_EXTRA)
        # 2026-11-22 修（工艺书 clean-control 假报，PS-L1-01 复现）：
        # 冷却工序的「复冷触发条件句」——如「中心温度高于10℃的面包留在冷却间继续冷却15min后复测」——
        # before 含「高于」（命中 _TEMP_LOWER_MARKS）但它是冷却判据，不是加热工序的温度下限要求；
        # 若该行不含任何加热工序词，则不是「中心温度应达到」的违规对象（判据原文只约束加热工序）。
        if lower and not heating and any(k in line for k in ("冷却", "复冷", "摊凉", "降温")):
            return False
        return bool(lower or heating)
    if kind == "temp" and scope == "冷却":
        # 冷却终温 = 产品温度；「冷却间温度/环境温度」是环境量，不是终温
        return any(k in before for k in ("终温", "中心温度", "品温"))
    if kind == "temp" and scope == "冷藏暂存":
        # 冷冻/速冻库（-18℃ 及以下）不是「冷藏暂存 0-8℃」的判定对象
        if any(k in line for k in ("冷冻", "速冻", "冻结")):
            return False
        try:
            if float(fact.get("value") or 0) <= -10:
                return False
        except (TypeError, ValueError):
            return False
        return True
    if kind == "conc":
        # 余氯/残留是冲洗后的残留限值，不是消毒液浓度
        if any(k in before for k in ("余氯", "残留")):
            return False
        return any(k in before for k in ("浓度", "消毒液", "次氯酸钠", "含氯", "有效氯"))
    if kind == "time":
        # 「每 4h 记录」是监测频率，不是解冻时长
        if fact.get("frequency"):
            return False
        return not bool(re.search(r"每[^0-9]{0,3}$", before))
    return True


def _text_numeric_facts(text: str, sign_aware: bool = None) -> list:
    """从纯文本逐行抽取数值事实（复用 rexec 的取数与作用域口径）。

    返回 [{metric,value,unit,scope,quote,line,before,after,range_hi?,frequency?}]；
    before/after 是数值前后上下文（供 P0-8 作用域闸判断 "是要求还是实测/环境量"）。
    sign_aware（默认随 RULEPROOF_P0_LIMIT_SCOPE_FIX）支持负温度 -18℃。
    只为确定性限值执行服务，不改变 rexec/factreview 的既有行为。
    """
    from . import rexec as _rex
    if sign_aware is None:
        sign_aware = _p0_limit_scope_fix_on()
    _range_pat = _TEMP_RANGE_SIGNED if sign_aware else _rex._TEMP_RANGE
    _single_pat = _TEMP_SINGLE_SIGNED if sign_aware else _rex._TEMP_SINGLE
    out = []

    def _tight_quote(line: str, token: str) -> str:
        """取包含取数 token 的「单元格/字段」片段作为引文（优先精确证据）。

        解析文本里同一内容可能出现两次（工序 Sheet 行 + 派生的「工艺参数表」行），
        按整行取引文会让同一条违规产生两条不同引文 → finding 级证据门禁重复核验 /
        召回时第二处证据丢失。这里按 `|` 分段，只取**包含该数值的那一段**：
        两处重复内容的引文因此完全相同，去重后每条违规只留一条逐字引文。
        """
        seg = line
        if "|" in line or "｜" in line:
            for part in re.split(r"[|｜]", line):
                if token and token in part:
                    seg = part
                    break
        return seg.strip()[:160]

    def _seg_ctx(line: str, m) -> tuple:
        """数值所在「单元格（| 分段）」内的前后文。

        解析文本把一行多个单元格用 ` | ` 拼成一行；若用整行取上下文，
        相邻单元格里另一句话的「≤/以下/每」会污染本数值的语义判定
        （实测：「牛腱中心温度 0-4℃ | 中心温度高于 4℃ 的原料…」的 4℃ 被误当中心温度要求）。
        因此 before/after 只在本单元格内取；line 仍保留整行（加热工序关键词可能在别的单元格）。
        L26：额外返回 wide_before/wide_after（单元格内更大窗口 45/25 字），供「消毒对象」
        （手部/洗手消毒液）与「解冻口径」这类需要对象名词的作用域判定使用；既有
        before/after（16/10 字）口径与所有既有判定语义不变。
        """
        if "|" in line or "｜" in line:
            start = 0
            for part in re.split(r"[|｜]", line):
                end = start + len(part)
                if start <= m.start() < end:
                    s = m.start() - start
                    e = m.end() - start
                    return (part[max(0, s - 16): s], part[e: e + 10], line, part,
                            part[max(0, s - 45): s], part[e: e + 25])
                start = end + 1
        return (line[max(0, m.start() - 16): m.start()],
                line[m.end(): m.end() + 10], line, line,
                line[max(0, m.start() - 45): m.start()],
                line[m.end(): m.end() + 25])

    def _with_ctx(fact: dict, line: str, m) -> dict:
        before, after, whole, seg, wide_before, wide_after = _seg_ctx(line, m)
        fact["before"] = before
        fact["after"] = after
        fact["line"] = whole
        fact["seg"] = seg
        fact["wide_before"] = wide_before
        fact["wide_after"] = wide_after
        return fact

    # L178 ①：浓度取数正则按开关选定一次（逐行复用，不重复分支）
    _conc_re = (_rex._CONC_FIX2
                if (_det_limit_conc_unit_fix_on()
                    and _rex.exec_fix_v2("conc_scale"))
                else _rex._CONC)
    for line in str(text or "").splitlines():
        if not line.strip():
            continue
        # L26：解冻「后置时限 / 非冷藏方式」识别需要「原文 + 归一下标」同一套位置
        # （canonical_numeric_text 为 1:1 逐字符映射，匹配下标可回指原文）。
        _norm_line = _rex.canonical_numeric_text(line)
        for m in _range_pat.finditer(line):
            ctx = line[max(0, m.start() - 10): m.start()]
            out.append(_with_ctx({"metric": "温度", "value": float(m.group(1)),
                                  "range_hi": float(m.group(2)), "unit": m.group(3),
                                  "scope": _rex._temp_scope(ctx),
                                  "quote": _tight_quote(line, m.group(0)),
                                  "line": line}, line, m))
        for m in _single_pat.finditer(line):
            ctx = line[max(0, m.start() - 10): m.start()]
            out.append(_with_ctx({"metric": "温度", "value": float(m.group(1)),
                                  "unit": m.group(2),
                                  "scope": _rex._temp_scope(ctx),
                                  "quote": _tight_quote(line, m.group(0)),
                                  "line": line}, line, m))
        for m in _rex._TIME.finditer(line):
            before, _after, _whole, _seg, _wb, _wa = _seg_ctx(line, m)
            out.append(_with_ctx({"metric": "时间", "value": float(m.group(1)),
                                  "unit": m.group(2), "scope": "",
                                  "quote": _tight_quote(line, m.group(0)),
                                  "line": line,
                                  # B1-L1 T03 同口径：解冻/解冻-非冷藏方式/解冻后处理时限
                                  "time_scope": _rex._time_scope(line, _norm_line, m),
                                  "frequency": bool(re.search(r"每[^0-9]{0,3}$", before))},
                                 line, m))
        # L178 ①：浓度取数复用 rexec L39 已登记单位词表（ppm/ppb/mg/kg/μg/kg/g/kg），
        # 与 packs/food.py 事实层同一取数来源；=0 回退旧「只认 ppm|mg/kg」口径。
        for m in _conc_re.finditer(line):
            out.append(_with_ctx({"metric": "浓度", "value": float(m.group(1)),
                                  "unit": m.group(2), "scope": "",
                                  # L26：手部/洗手消毒液 vs 工器具/环境/食品接触面消毒液
                                  "conc_scope": _rex.conc_scope(
                                      line[max(0, m.start() - 45): m.start()]),
                                  "quote": _tight_quote(line, m.group(0)),
                                  "line": line}, line, m))
    return out


def _spec_facts(spec: dict, text: str) -> dict:
    """按限值判据的作用域/单位/工序关键词筛出事实（P0-8 作用域闸；L26 扩展为 dict）。

    返回 ``{"facts": [...], "pending": [...], "excluded_hand": n, "malformed": n,
    "unit_undecided": [(原值, 单位)]}``：
      · facts：参与阈值比较的事实（浓度事实已按判据单位归一，见 L178 ①）；
      · pending：解冻「口径待定」事实（非冷藏解冻方式，判据是否适用待业务裁决，
        不参与阈值比较、不得据此判 fail）——与 packs/food.py 待定分支同口径；
      · excluded_hand：因对象为手部/洗手消毒液而被本判据作用域排除的浓度事实数
        （L26，数据集 R-LIM-02 ``excludes 手部消毒液``）；
      · malformed：取数结果里**非 dict / 结构异常**的事实条数（L28 输入类型守卫：
        不静默丢弃，交 ``judge_limit_rule`` 记「证据不足」并留痕，不得 AttributeError）；
      · unit_undecided：L178 ① 浓度事实单位未登记/跨量纲无法归一的条目（不猜单位，
        交 ``judge_limit_rule`` 记「证据不足」并留痕）。
    """
    kind = str(spec.get("kind") or "")
    scope = str(spec.get("scope") or "")
    unit = str(spec.get("unit") or "")
    out, pending = [], []
    excluded_hand = 0
    malformed = 0
    unit_undecided = []
    _seen, _seen_pending = set(), set()
    _thaw_pending_on = _thaw_criterion_pending_on()
    _scope_fix_on = _disinfect_scope_fix_on()
    for f in (_text_numeric_facts(text) or []):
        # L28 输入类型守卫：取数结果必须是 dict，非 dict 项计数后交上层转「证据不足」
        if not isinstance(f, dict):
            malformed += 1
            continue
        # L86 P0-2：非有限数事实（NaN/Inf）不得进入阈值比较 → 计数为 malformed 转证据不足。
        if _fact_identity_fix_on() and not _finite_num(f.get("value")):
            malformed += 1
            logging.getLogger(__name__).warning(
                "limit spec fact guard skipped non-finite value: %r", f.get("value"))
            continue
        if _fact_identity_fix_on() and f.get("range_hi") is not None \
                and not _finite_num(f.get("range_hi")):
            malformed += 1
            logging.getLogger(__name__).warning(
                "limit spec fact guard skipped non-finite range_hi: %r", f.get("range_hi"))
            continue
        try:
            if kind == "temp":
                if f.get("metric") != "温度" or f.get("scope") != scope:
                    continue
            elif kind == "conc":
                if f.get("metric") != "浓度":
                    continue
                # 消毒浓度：取数值前上下文属于消毒工序的行（避免把防腐剂/清洗剂浓度算进来）
                if scope and scope not in (f.get("line") or ""):
                    continue
                # L178 ①：跨单位归一（200ppb=0.2ppm、200mg/kg=200ppm…）后再进阈值比较；
                # 单位缺失不猜成 ppm；未登记单位计入 unit_undecided 转证据不足（不静默丢）。
                if unit and _det_limit_conc_unit_fix_on():
                    _nf, _bad_unit = _det_limit_normalize_fact(f, unit)
                    if _nf is None:
                        unit_undecided.append((_limit_fact_text(f), _bad_unit))
                        continue
                    f = _nf
                elif unit and str(f.get("unit") or "") != unit:
                    continue
                # L26：手部/洗手消毒液不是本判据对象（工器具/环境/食品接触面消毒液）
                if _scope_fix_on and str(f.get("conc_scope") or "") == "hand":
                    excluded_hand += 1
                    continue
            elif kind == "time":
                if f.get("metric") != "时间":
                    continue
                if scope and scope not in (f.get("line") or ""):
                    continue
                if unit and str(f.get("unit") or "") not in (unit, "小时"):
                    continue
                # L26：解冻时长取数必须区分「解冻时长 vs 解冻后时限 vs 监测频率」
                _ts = str(f.get("time_scope") or "")
                if scope == "解冻" and _thaw_pending_on:
                    if _ts == "解冻后处理时限":
                        continue  # 后续工序时限，不是解冻时长（取数绑定，任何开关下都排除）
                    if _ts == "解冻-非冷藏方式":
                        _pk = (f.get("metric"), str(f.get("value")), str(f.get("unit")),
                               str(f.get("quote")))
                        if _pk in _seen_pending:
                            continue
                        _seen_pending.add(_pk)
                        pending.append(f)  # 口径待定：不参与阈值比较，不判 fail
                        continue
            else:
                continue
            if not _fact_allowed_for_p0(spec, f):
                continue
            key = (f.get("metric"), str(f.get("value")), str(f.get("unit")),
                   f.get("scope"), str(f.get("quote")))
            if key in _seen:
                continue
            _seen.add(key)
            out.append(f)
        except (AttributeError, KeyError, TypeError, ValueError) as _e:
            # 铁律 2：异常留痕（计数 + warning 日志），不静默吞掉；交上层转「证据不足」
            malformed += 1
            logging.getLogger(__name__).warning(
                "limit spec fact guard skipped malformed fact: %s: %s", type(_e).__name__, _e)
            continue
    return {"facts": out, "pending": pending, "excluded_hand": excluded_hand,
            "malformed": malformed, "unit_undecided": unit_undecided}


def _cmp_state(spec: dict, fact: dict) -> bool:
    """单条事实是否满足限值判据。range 用 range_hi 判上界、value 判下界。

    L28 输入类型守卫：非 dict / 缺 value 等结构异常显式 TypeError（由调用方计数转
    「证据不足」），不得 AttributeError 冒到主链把 D5 记为 blocked。
    """
    if not isinstance(spec, dict) or not isinstance(fact, dict):
        raise TypeError("_cmp_state requires dict spec/fact")
    op = str(spec.get("op") or "")
    v = float(fact.get("value"))
    hi = fact.get("range_hi")
    if op in (">=", "≥", "gte"):
        return v >= float(spec.get("value"))
    if op in ("<=", "≤", "lte"):
        return v <= float(spec.get("value"))
    if op in ("=", "==", "eq"):
        return abs(v - float(spec.get("value"))) < 1e-9
    if op == "range":
        lo = float(spec.get("lo")); hi_th = float(spec.get("hi"))
        if hi is not None:
            return v >= lo and float(hi) <= hi_th
        return lo <= v <= hi_th
    return False


def _cooling_applicability(text: str) -> dict:
    """冷却终温判据的适用性判定（① 判据跨场景串用修复）。

    - 文档没有冷却工序 → 不适用（规则无适用对象）；
    - 有冷却工序但降温方式为常温/自然冷却（手温/室温/摊凉…）→ 10℃ 冷链终温判据
      不适用于该工序，判「不适用」并给出原因（不判 fail、也不误报证据不足）；
    - 有冷却工序、非常温语境但未标注终温数值 → 「证据不足」（缺证据，不猜违规）。
    """
    lines = [ln for ln in str(text or "").splitlines() if "冷却" in ln]
    if not lines:
        return {"state": "不适用", "detail": "文档无冷却工序，冷却终温判据不适用",
                "quote": "", "applicability": "no_cooling_process"}
    for ln in lines:
        if any(w in ln for w in _COOLING_AMBIENT_WORDS):
            return {"state": "不适用",
                    "detail": "冷却方式为常温/自然冷却（含「手温/室温/摊凉」语境），"
                              "不适用 ≤10℃ 冷链终温判据（判据跨场景串用已拦截）",
                    "quote": ln.strip()[:120], "applicability": "ambient_cooling"}
    return {"state": "证据不足",
            "detail": "有冷却工序但未抽取到冷却终温数值（不得据此判不满足）",
            "quote": "", "applicability": "missing_cooling_value"}


def _limit_fact_text(f) -> str:
    """限值事实取值格式化（L28 类型守卫：value/unit 异常时不抛异常，仍可留痕）。

    L178 ①：浓度事实经单位归一后展示「原值=归一值」（如 ``200ppb=0.2ppm``），
    阈值仍按判据单位比较；无换算的普通事实输出与历史逐字一致。
    """
    if not isinstance(f, dict):
        return "?"
    _raw_v, _raw_u = f.get("raw_value"), f.get("raw_unit")
    if _raw_v is not None and _raw_u \
            and str(_raw_u) != str(f.get("unit") or ""):
        try:
            return "%g%s=%g%s" % (float(_raw_v), _raw_u,
                                  float(f.get("value")), f.get("unit") or "")
        except (TypeError, ValueError):
            pass
    try:
        return "%g%s" % (float(f.get("value")), f.get("unit") or "")
    except (TypeError, ValueError):
        return "%s%s" % (f.get("value"), f.get("unit") or "")


def _limit_malformed_result(spec, detail: str, malformed: int = 0, extra=None) -> dict:
    """L28 输入类型守卫的「证据不足」结论（留痕：guard/applicability/malformed 计数）。"""
    out = {"state": "证据不足", "detail": detail, "quote": "",
           "values": [], "spec": spec if isinstance(spec, dict) else {},
           "applicability": "malformed_input", "guard": "limit_input_type",
           "malformed": int(malformed or 0)}
    if extra:
        out.update(extra)
    return out


def judge_limit_rule(code: str, text: str) -> dict | None:
    """内置食品限值规则的确定性执行；不支持的规则码返回 None。

    返回 {"state": 满足/不满足/不适用/证据不足, "detail", "quote", "values", "spec"}；
    None 表示该规则没有确定性限值执行器，调用方必须走原路径（不得当成通过）。

    L26（2026-11-23）两处作用域修复接在确定性通道（生产 0-LLM 主链）上：
      · 消毒浓度（RW20260525006）：手部/洗手消毒液事实被排除；若文档只有手部消毒液 →
        「不适用」；环境/工器具/食品接触面消毒液仍按 ≥200ppm 判（不达标仍 fail）；
      · 解冻（RW20260525011）：非冷藏解冻方式（流动水/流动饮用水/室温/微波…）→「口径待定/
        证据不足」（待业务裁决，不判 fail）；「解冻后 Xh 内」= 后续时限、频率 → 取数排除；
        明确冷藏解冻的「解冻时长 <20h」仍判不满足。
    开关：RULEPROOF_DISINFECT_SCOPE_FIX（默认 1）/ RULEPROOF_THAW_CRITERION_PENDING（默认 1），
    =0 回退旧行为。

    L28（2026-11-23）输入类型守卫：L24 观察到 10 个 item 在「L26 改动中间态」下
    ``_spec_facts`` 返回 dict 而消费方按 list 迭代 → ``AttributeError: 'str' object has no
    attribute 'get'`` → D5 blocked。现在 spec / 取数结果 / 事实项 / 结果解析全链路做类型
    守卫：非 dict、旧 list 形态、None、结构化异常一律转「证据不足」并留痕
    （guard=limit_input_type），**不得 AttributeError、不得 blocked**。
    """
    spec = FOOD_LIMIT_SPECS.get(str(code or ""))
    if not spec:
        return None
    # L28 类型守卫 ①：spec 必须是 dict（脏配置/中间态不得 AttributeError）
    if not isinstance(spec, dict):
        return _limit_malformed_result(
            spec, f"限值判据配置非 dict（{type(spec).__name__}），类型守卫拦截，"
                  f"不执行阈值比较，转人工补证")
    try:
        _sf = _spec_facts(spec, text)
    except (AttributeError, KeyError, TypeError) as _e:
        # L28 类型守卫 ②：取数结果结构异常 → 证据不足并留痕（异常类型写进 detail，不静默）
        return _limit_malformed_result(
            spec, f"限值取数结构异常（{type(_e).__name__}: {str(_e)[:120]}），类型守卫"
                  f"拦截，不执行阈值比较，转人工补证")
    unit_undecided = []
    if isinstance(_sf, dict):
        _raw_facts = _sf.get("facts")
        _raw_pending = _sf.get("pending") or []
        excluded_hand = _sf.get("excluded_hand") or 0
        malformed = int(_sf.get("malformed") or 0)
        # L178 ①：浓度事实单位无法归一的条目（不猜单位，转证据不足并留痕）
        _raw_undec = _sf.get("unit_undecided") or []
        unit_undecided = [x for x in _raw_undec if isinstance(x, (list, tuple))]
    elif isinstance(_sf, (list, tuple)):
        # 兼容旧 `_spec_facts` 返回 list 的形态（回滚杆 / 改动中间态）：按 facts 解析，
        # 绝不把 dict 当 list 迭代或反之（L24 AttributeError 根因）。
        _raw_facts, _raw_pending, excluded_hand, malformed = _sf, [], 0, 0
    else:
        return _limit_malformed_result(
            spec, f"限值取数结果类型异常（{type(_sf).__name__}），类型守卫拦截，"
                  f"不执行阈值比较，转人工补证")
    if _raw_facts is None:
        return _limit_malformed_result(
            spec, "限值取数结果缺少 facts 列表（类型守卫拦截），转人工补证")
    if not isinstance(_raw_facts, (list, tuple)):
        return _limit_malformed_result(
            spec, f"限值取数 facts 类型异常（{type(_raw_facts).__name__}），类型守卫拦截，"
                  f"转人工补证")
    facts = [f for f in _raw_facts if isinstance(f, dict)]
    malformed += len(_raw_facts) - len(facts)
    pending = [f for f in _raw_pending if isinstance(f, dict)] \
        if isinstance(_raw_pending, (list, tuple)) else []
    if malformed:
        return _limit_malformed_result(
            spec, f"限值事实项含非 dict/结构异常 {malformed} 条（类型守卫拦截，"
                  f"不执行阈值比较，转人工补证）", malformed=malformed)
    try:
        excluded_hand = int(excluded_hand or 0)
    except (TypeError, ValueError):
        excluded_hand = 0
    unit = str(spec.get("unit") or "")
    metric = str(spec.get("metric") or code)
    if not facts:
        if pending:
            _pvals = [_limit_fact_text(f) for f in pending[:8]]
            return {"state": "证据不足",
                    "detail": ("口径待定：解冻时长判据（≥20h）对非冷藏解冻方式"
                               "（流动水/流动饮用水/室温/常温/微波等）是否适用，待规则 owner "
                               "业务裁决；已抽到非冷藏解冻时长 "
                               + "、".join(_pvals) + "，按口径待定记证据不足，不判不满足"),
                    "quote": str(pending[0].get("quote") or "")[:200],
                    "values": _pvals, "spec": spec,
                    "applicability": "thaw_criterion_pending"}
        if excluded_hand:
            return {"state": "不适用",
                    "detail": ("仅检测到手部/洗手消毒液浓度（规则作用域为工器具/环境/食品接触面"
                               "消毒液，手部消毒液按数据集 R-LIM-02 明确排除），判据不适用"),
                    "quote": "", "values": [], "spec": spec,
                    "applicability": "hand_hygiene_excluded"}
        if str(spec.get("kind")) == "temp" and spec.get("scope") == "冷却":
            return {**_cooling_applicability(text), "values": [], "spec": spec}
        # 判据适用范围（①）：文档根本没有该工序/字段主题 → 规则不适用（na），
        # 不能记「证据不足」——na 是确定结论，既不阻断报告门禁也不进 unknown。
        _topic_kw = _TOPIC_KEYWORDS.get(str(spec.get("scope") or ""), ())
        if _topic_kw and not any(k in str(text or "") for k in _topic_kw):
            return {"state": "不适用",
                    "detail": f"文档无「{metric}」相关工序/字段主题，规则不适用",
                    "quote": "", "values": [], "spec": spec,
                    "applicability": "no_topic"}
        if unit_undecided:
            # L178 ①：有浓度事实但单位未登记/跨量纲 → 证据不足并说明（不猜单位，不按原值硬比）
            _uvals = [str(x[0]) for x in unit_undecided[:8]]
            _uunits = []
            for _x in unit_undecided[:8]:
                _u = str((_x[1] if len(_x) > 1 else "") or "").strip()
                if _u and _u not in _uunits:
                    _uunits.append(_u)
            return {"state": "证据不足",
                    "detail": (f"未提取到可核验的{metric}数值：{len(unit_undecided)} 处"
                               f"单位不可识别（{'、'.join(_uvals)}"
                               + (f"；单位={'、'.join(_uunits)}" if _uunits else "")
                               + "），不猜单位，需补证/人工核验"),
                    "quote": "", "values": _uvals, "spec": spec,
                    "applicability": "unit_undecided"}
        return {"state": "证据不足",
                "detail": f"未抽取到{metric}数值，不判不满足（需补证/人工核验）",
                "quote": "", "values": [], "spec": spec,
                "applicability": "missing_value"}
    ok, bad = [], []
    _cmp_err = 0
    for f in facts:
        try:
            _meets = _cmp_state(spec, f)
        except (AttributeError, KeyError, TypeError, ValueError) as _e:
            # L28 类型守卫 ③：单条事实结构异常（缺 value / value 非数值）→ 计数留痕，
            # 不执行阈值比较（不得 AttributeError / blocked）
            _cmp_err += 1
            logging.getLogger(__name__).warning(
                "limit fact cmp guard skipped malformed fact: %s: %s",
                type(_e).__name__, _e)
            continue
        (ok if _meets else bad).append(f)
    if _cmp_err:
        return _limit_malformed_result(
            spec, f"限值事实项结构异常 {_cmp_err} 条（类型守卫拦截，不执行阈值比较，"
                  f"转人工补证）", malformed=_cmp_err)
    vals = [_limit_fact_text(f) for f in facts[:8]]
    if bad:
        q = str(bad[0].get("quote") or "")[:200]
        _op_txt_bad = (f"{spec.get('lo')}-{spec.get('hi')}{unit}"
                       if str(spec.get("op")) == "range"
                       else f"{spec.get('op')}{spec.get('value', '')}{unit}")
        # 多条违规：每处给一条独立引文（主链 D4 逐行落子要求，finding 保留多个证据锚点），
        # 保证「同规则多处越界」每条 gold 都能被逐字证据命中（不合并掉第二、三处）。
        _violations = []
        for f in bad[:8]:
            _q = str(f.get("quote") or "").strip()
            if _q and _q not in _violations:
                _violations.append(_q[:160])
        _bad_res = {"state": "不满足",
                    "detail": f"{len(bad)} 处{metric}不满足 {_op_txt_bad}"
                              f"（实测：{'、'.join(vals)}）",
                    "quote": q, "violations": _violations,
                    "values": vals, "spec": spec, "bad_count": len(bad),
                    "applicability": "evaluated"}
        # L178 ①：发生单位换算时 unit_source=conversion_table（L86 追溯口径不丢）
        _decl = ("conversion_table"
                 if any(str(f.get("unit_source") or "") == "conversion_table" for f in bad)
                 else "")
        return _tag_unit_source(_bad_res, unit,
                                [str(f.get("unit") or "") for f in bad],
                                declared=_decl)
    if pending:
        # 口径待定（与 packs/food.py 待定分支同序：先真违规、再待定、最后满足）
        _pvals = [_limit_fact_text(f) for f in pending[:8]]
        return {"state": "证据不足",
                "detail": ("口径待定：解冻时长判据（≥20h）对非冷藏解冻方式"
                           "（流动水/流动饮用水/室温/常温/微波等）是否适用，待规则 owner "
                           "业务裁决；已抽到非冷藏解冻时长 " + "、".join(_pvals)
                           + "，按口径待定记证据不足，不判不满足"),
                "quote": str(pending[0].get("quote") or "")[:200],
                "values": _pvals, "spec": spec,
                "applicability": "thaw_criterion_pending"}
    _op_txt = (f"{spec.get('lo')}-{spec.get('hi')}{unit}"
               if str(spec.get("op")) == "range"
               else f"{spec.get('op')}{spec.get('value', '')}{unit}")
    _ok_res = {"state": "满足",
               "detail": f"{len(ok)} 处{metric}满足 {_op_txt}"
                         f"（实测：{'、'.join(vals)}）",
               "quote": str(ok[0].get("quote") or "")[:200], "values": vals, "spec": spec,
               "applicability": "evaluated"}
    _decl_ok = ("conversion_table"
                if any(str(f.get("unit_source") or "") == "conversion_table" for f in ok)
                else "")
    return _tag_unit_source(_ok_res, unit,
                            [str(f.get("unit") or "") for f in ok],
                            declared=_decl_ok)


# ---------------------------------------------------------------- 词典/名称规范守卫

def dictionary_names() -> list:
    """平台已配置的「规范词典」名称（③ 修复的判定前提/数据源）。

    只认**用户/空间级**词典（企业业务词典 business_term 或空间本体术语 canonical/aliases），
    不把引擎内置 demo 本体（炒卷心菜/酱油饭…4 个演示实体名）当规范词典——那正是误报来源。

    注意：agent-judge 在主链里跑在独立线程（manifest_exec._semantic_eval），
    ``ctx`` 线程局部在该线程里为空，因此这里**不能**走 ctx 依赖的 service 视图，
    改为直接读库（workspace.settings_json.ontology_terms + business_term），保证判定稳定。
    """
    import json as _json
    from .. import db as _db
    names = []
    try:
        with _db.session() as c:
            rows = c.execute("SELECT settings_json FROM workspace").fetchall()
        for row in rows:
            try:
                st = _json.loads(row["settings_json"] or "{}")
            except Exception:
                continue
            for t in (st.get("ontology_terms") or []):
                if str(t.get("status") or "") != "active":
                    continue
                for k in ("canonical",):
                    v = str(t.get(k) or "").strip()
                    if v and v not in names:
                        names.append(v)
                for a in (t.get("aliases") or []):
                    a = str(a or "").strip()
                    if a and a not in names:
                        names.append(a)
    except Exception:
        logging.getLogger(__name__).debug("workspace dictionary read skipped", exc_info=True)
    try:
        with _db.session() as c:
            rows = c.execute(
                "SELECT name, aliases_json FROM business_term "
                "WHERE status IN ('confirmed','active')").fetchall()
        for row in rows:
            v = str(row["name"] or "").strip()
            if v and v not in names:
                names.append(v)
            try:
                for a in (_json.loads(row["aliases_json"] or "[]") or []):
                    a = str(a or "").strip()
                    if a and a not in names:
                        names.append(a)
            except Exception:
                # 铁律 2：别名 JSON 解析失败不得静默（原为 pass，静默失败门禁 112→113 抓出）
                logging.getLogger(__name__).debug(
                    "business_term aliases_json parse skipped", exc_info=True)
    except Exception:
        logging.getLogger(__name__).debug("business_term dictionary read skipped", exc_info=True)
    return names


def dictionary_configured() -> bool:
    """平台是否配置了「规范词典」（③ 修复的判定前提）。"""
    return bool(dictionary_names())


def _doc_product_names(text: str) -> list:
    """从文档里抽「商品名/产品名称」取值（用于词典比对）。"""
    vals = []
    for v in _label_values(text, ("商品名", "产品名称")):
        name = str(v.get("value") or "").strip()
        if name and name not in vals:
            vals.append(name)
    return vals


def _name_in_dictionary(name: str, names: list) -> bool:
    n = str(name or "").strip()
    if not n:
        return False
    for d in names:
        d = str(d or "").strip()
        if not d:
            continue
        if n == d or (len(n) >= 2 and (n in d or d in n)):
            return True
    return False


def _is_dictionary_point(point: dict) -> bool:
    """该点位判据是否依赖「规范词典」。"""
    hay = f"{point.get('name') or ''} {point.get('criterion') or ''}"
    return any(k in hay for k in _DICT_HINTS)


def _resolve_rule_code(point: dict) -> str:
    pid = str(point.get("id") or point.get("code") or "").strip()
    if pid in FOOD_LIMIT_SPECS:
        return pid
    return FOOD_POINT_RULE.get(pid, "")


# ============================================================================
# L130 · build52 六视角①（2026-11-25）：确定性规则 vs 概率性 AI 的边界与冲突仲裁
# ——硬合规项一票否决 / 不可覆盖边界（食品高严肃红线）
#
# 审计（只读，详见 docs/qa/build52_六视角①_确定性规则与AI仲裁_20261125.md §1）：
#   裁决链同时存在两类裁决源：确定性执行器（ruleexec.* / decision_table，可复算、
#   可逐字取证）与概率性模型（agent-judge / LLM / semantic 复核，不可复现、可能漏抽取）。
#   主链多数入口先走确定性分支（manifest_exec D4 的 _deterministic_* 命中即 continue），
#   但 agent-judge 结果合并处 guard_judged 仍有两个「模型可覆盖硬规则」的洞：
#     ① 确定性执行器判「证据不足/执行失败」时，模型 pass/na 原样保留 → 硬合规项
#        「不确定」被模型静默放成通过/不适用（报告门禁也看不到 unknown）；
#     ② RULEPROOF_JUDGE_GUARD=0（或分项 =0）时，模型 pass/na 可直接覆盖确定性
#        「不满足」→ 硬规则 fail 被模型改写成 pass。
#
# 本段是硬合规项边界的**唯一实现**（调用方禁止自写第二套）：
#   · hard_rule_scope()：只复用平台既有判据族，不新增行业硬编码——
#       FOOD_LIMIT_SPECS（杀菌中心温度/消毒浓度/冷却终温/冷藏区间/解冻时长）、
#       通用限值 slots（unit 量纲 temp/time、conc/count_conc）、prohibited 模板/
#       forbid/not_in 取值（禁用物质）、label/field_presence 模板（强制标识）；
#   · hard_rule_deterministic_result()：用既有执行器（judge_limit_rule/judge_rule）
#       复算确定性结论；非硬判据族返回 None（调用方保持原路径，不得当成通过）；
#   · arbitrate_hard_rule()：显式冲突仲裁，输出结构化
#       {final_state, hard_veto, model_overridden, conflict_list, review_required,
#        resolution, switch, det_*, model_state, ...}；真值表只收紧不放松：
#         确定=不满足 + 模型∈{pass,na,unknown,insufficient}
#             → fail（引文逐字可核验）；引文不可核验 → insufficient（fail-closed，
#               绝不裸 fail；review_required=True）
#         确定=证据不足/执行失败 + 模型∈{pass,na} → insufficient + review_required
#             （硬合规项未知不得静默 pass；na 也不得由模型单独决定）
#         确定=满足 + 模型=fail → pass（模型误报纠正，既有守卫口径）
#         确定=不适用 → na（模型 pass/fail 不采信；不适用是确定性结论）
#         其余无冲突组合不改模型结论（不把未知硬升成 pass）
#   · guard_judged 内逐行复用 _veto_row()（与既有数值/B-4/结构/词典守卫叠加）；
#   · apply_hard_rule_veto() 供其它 judge 路径使用；hard_rule_conflicts() 汇总冲突。
#
# 开关：RULEPROOF_HARD_RULE_VETO（默认 1；=0 逐字回退：零行为变化，供 A/B 与回滚）。
# 与 RULEPROOF_JUDGE_GUARD 正交：旧守卫总开关关闭时硬边界仍生效（除非本开关=0），
# 避免「关旧守卫 → 硬规则失守」的绕过路径。
# ============================================================================
HARD_RULE_VETO_ENV = "RULEPROOF_HARD_RULE_VETO"
HARD_RULE_VETO_DEFAULT = "1"      # 默认开；=0/false/off/no 逐字回退

HARD_RULE_FAMILIES = {
    "sterilization_param": "杀菌/加热参数（中心温度硬限值）",
    "disinfection_limit": "消毒浓度硬限值",
    "temperature_time": "温度/时间硬限值（冷却/冷藏/解冻）",
    "additive_limit": "添加剂/残留限量",
    "prohibited_substance": "禁用物质",
    "mandatory_label": "强制标识/必填字段",
}

# 内置食品限值码 → 硬合规族（复用 FOOD_LIMIT_SPECS 既有判据，不新增行业硬编码）
_FOOD_LIMIT_HARD_FAMILY = {
    "RW20260525005": ("sterilization_param",
                      "FOOD_LIMIT_SPECS 中心温度≥85℃（加热/杀菌参数）"),
    "RW20260525006": ("disinfection_limit",
                      "FOOD_LIMIT_SPECS 消毒浓度≥200ppm"),
    "RW20260525009": ("temperature_time",
                      "FOOD_LIMIT_SPECS 冷却终温≤10℃"),
    "RW20260525010": ("temperature_time",
                      "FOOD_LIMIT_SPECS 冷藏暂存温度 0-8℃"),
    "RW20260525011": ("temperature_time",
                      "FOOD_LIMIT_SPECS 解冻时长≥20h"),
}
_HARD_LIMIT_TEMP_TIME_DIMS = ("temp", "time")
_HARD_LIMIT_CONC_DIMS = ("conc", "count_conc")
_HARD_MODEL_STATES = ("pass", "fail", "na", "insufficient", "unknown")


def hard_rule_veto_enabled() -> bool:
    """硬规则一票否决开关：默认开；=0/false/off/no 关闭（逐字回退）。"""
    try:
        raw = str(os.environ.get(HARD_RULE_VETO_ENV,
                                 HARD_RULE_VETO_DEFAULT)).strip().lower()
    except Exception:                      # noqa: BLE001 - 开关读取失败按默认开（fail-safe）
        return True
    return raw not in ("0", "false", "off", "no")


def hard_rule_families() -> dict:
    """硬合规判据族定义（只读副本；报告/测试/审计用）。"""
    return dict(HARD_RULE_FAMILIES)


def _hard_state_norm(raw) -> str:
    """任意历史状态名 → 五态规范词（pass/fail/na/insufficient/unknown）。

    只做归一，不发明结论：无法识别 → unknown（fail-closed，而不是猜 pass）。
    """
    s = str(raw if raw is not None else "").strip()
    if not s:
        return "unknown"
    low = s.lower()
    if s in _HARD_MODEL_STATES:
        return s
    if s in ("满足", "通过", "合规", "成立"):
        return "pass"
    if s in ("不满足", "不通过", "违规", "不成立"):
        return "fail"
    if low in ("na", "n/a", "not_applicable", "not applicable", "skipped") \
            or s == "不适用":
        return "na"
    if s in ("证据不足", "弃权", "弃权(需人工)", "需人工", "待人工"):
        return "insufficient"
    if s in ("执行失败", "未执行", "受阻") or low in (
            "blocked", "failed", "execution_failed", "executor_error", "needs_model"):
        return "unknown"
    return "unknown"


def _hard_label_keywords() -> tuple:
    """强制标识字段关键词：复用 registry 既有「标识标签」模板关键词（单一真相源）。"""
    try:
        from .registry import TEMPLATES as _tpls
        for _t in (_tpls or []):
            if str((_t or {}).get("code") or "") == "label":
                return tuple(str(x) for x in ((_t or {}).get("keywords") or [])
                             if str(x).strip())
    except Exception:                      # noqa: BLE001 - 只读元数据读取失败不影响判定
        logging.getLogger(__name__).debug(
            "registry label keywords unavailable", exc_info=True)
    return ()


def hard_rule_scope(rule_code: str = "", point: dict | None = None,
                    slots: dict | None = None) -> dict:
    """硬合规项识别（只复用既有判据族，不新增行业硬编码）。

    返回 {"hard": bool, "family": str, "family_label": str, "basis": str,
          "source": str, "executor": str, "rule_code": str[, "reason": str]}
    - 内置食品限值码（FOOD_LIMIT_SPECS / FOOD_POINT_RULE 点位）→ 对应硬合规族；
    - slots 判据：prohibited/forbid/not_in 取值 → 禁用物质；label/field_presence
      （字段命中 registry 标识标签关键词）→ 强制标识；limit 且 unit 量纲 ∈
      {temp,time} → 温度/时间；量纲 ∈ {conc,count_conc} → 添加剂/残留限量；
    - 其它 → hard=False（不在本边界作用域，保持原合并口径）。
    """
    point = point if isinstance(point, dict) else {}
    code = str(rule_code or "").strip()
    if not code:
        code = _resolve_rule_code(point)
    if code in FOOD_LIMIT_SPECS:
        fam, basis = _FOOD_LIMIT_HARD_FAMILY.get(
            code, ("temperature_time", "FOOD_LIMIT_SPECS 食品工艺内置限值"))
        return {"hard": True, "family": fam,
                "family_label": HARD_RULE_FAMILIES.get(fam, fam),
                "basis": basis, "source": "FOOD_LIMIT_SPECS",
                "executor": "ruleexec.judge_limit_rule", "rule_code": code}
    pid = str(point.get("id") or point.get("code") or "").strip()
    if pid and pid != code:
        mapped = _resolve_rule_code({"id": pid})
        if mapped and mapped in FOOD_LIMIT_SPECS:
            _s = hard_rule_scope(mapped, point=point, slots=slots)
            _s["point_id"] = pid
            return _s
    if isinstance(slots, dict) and slots:
        tpl = str(slots.get("_template") or slots.get("type")
                  or slots.get("template") or "").strip()
        op = str(slots.get("op") or slots.get("operator") or "").strip()
        values = slots.get("values")
        if values is None:
            values = slots.get("enum") if slots.get("enum") is not None \
                else slots.get("options")
        if (tpl == "prohibited" or slots.get("forbid") or slots.get("forbidden")
                or (op in ("not_in", "!=") and values)):
            return {"hard": True, "family": "prohibited_substance",
                    "family_label": HARD_RULE_FAMILIES["prohibited_substance"],
                    "basis": "既有 prohibited 模板/forbid/not_in 取值判据（禁用物质）",
                    "source": "slots:prohibited",
                    "executor": "ruleexec.judge_rule", "rule_code": code}
        _field = str(slots.get("field") or slots.get("field_label")
                     or slots.get("record_field") or slots.get("role")
                     or slots.get("item") or "").strip()
        _kws = _hard_label_keywords()
        if tpl == "label" or (_is_field_presence_rule(slots) and _field
                              and any(k and k in _field for k in _kws)):
            return {"hard": True, "family": "mandatory_label",
                    "family_label": HARD_RULE_FAMILIES["mandatory_label"],
                    "basis": "既有 label/field_presence 判据（强制标识/必填字段）",
                    "source": "slots:label",
                    "executor": "ruleexec.judge_rule", "rule_code": code}
        if is_limit_rule(slots) or tpl == "limit":
            _unit = str(slots.get("unit") or "")
            try:
                _dim = _unit_dim(_unit) if _unit else ""
            except Exception:              # noqa: BLE001 - 单位解析失败不猜量纲
                _dim = ""
            if _dim in _HARD_LIMIT_TEMP_TIME_DIMS:
                return {"hard": True, "family": "temperature_time",
                        "family_label": HARD_RULE_FAMILIES["temperature_time"],
                        "basis": (f"既有 limit 判据 unit={_unit}"
                                  f"（量纲={_dim}，温度/时间硬限值）"),
                        "source": "slots:limit",
                        "executor": "ruleexec.judge_limit", "rule_code": code}
            if _dim in _HARD_LIMIT_CONC_DIMS:
                return {"hard": True, "family": "additive_limit",
                        "family_label": HARD_RULE_FAMILIES["additive_limit"],
                        "basis": (f"既有 limit 判据 unit={_unit}"
                                  f"（量纲={_dim}，添加剂/残留限量）"),
                        "source": "slots:limit",
                        "executor": "ruleexec.judge_limit", "rule_code": code}
    return {"hard": False, "family": "", "family_label": "", "basis": "",
            "source": "", "executor": "", "rule_code": code,
            "reason": "非硬合规项：不在本边界作用域（保持原有合并口径）"}


def hard_rule_deterministic_result(rule_code: str = "", point: dict | None = None,
                                   slots: dict | None = None,
                                   text: str = "") -> dict | None:
    """用既有确定性执行器复算硬合规项结论；无法复算返回 None（不得当成通过）。

    - slots 判据 → ``judge_rule``（与 D4/语义路径同一执行器）；
    - 内置食品限值码 → ``judge_limit_rule``；
    - 其它（无确定性执行器的硬判据族，如部分模型点位）→ None（缺口见报告 §4）。
    执行器异常 → {"state": "执行失败"}（显式留痕，不伪装通过）。
    """
    body = str(text or "")
    try:
        if isinstance(slots, dict) and slots:
            return judge_rule(dict(slots), body, [])
        code = str(rule_code or "").strip() or _resolve_rule_code(point or {})
        if code in FOOD_LIMIT_SPECS:
            return judge_limit_rule(code, body)
    except Exception as exc:               # noqa: BLE001 - 执行器异常必须显式，不伪造结论
        logging.getLogger(__name__).warning(
            "hard rule deterministic eval failed rule=%s: %s", rule_code, exc,
            exc_info=True)
        return {"state": "执行失败",
                "detail": (f"硬规则确定性执行器异常（{type(exc).__name__}: "
                           f"{str(exc)[:120]}）"),
                "quote": "", "hard_eval_error": True}
    return None


def _hard_quote_verifiable(quote, text) -> bool:
    """fail 引文可核验性：有引文且（未给原文 或 引文逐字在原文中）。

    未给原文时采信确定性执行器自带的原文切片（执行器内部即从同一原文取数）；
    给了原文就必须逐字命中 —— 不可核验一律 fail-closed（不裸 fail）。
    """
    q = str(quote or "").strip()
    if not q:
        return False
    body = str(text or "")
    if not body:
        return True
    return q in body


def _hard_det_summary(det) -> dict:
    """确定性结果 → JSON 安全摘要（只保留裁决需要的字段，不复制大对象）。"""
    d = det if isinstance(det, dict) else {}
    vals = d.get("values")
    return {"state": _hard_state_norm(d.get("state")),
            "raw_state": str(d.get("state") or "")[:40],
            "detail": str(d.get("detail") or "")[:400],
            "quote": str(d.get("quote") or "")[:400],
            "applicability": str(d.get("applicability") or "")[:80],
            "values": list(vals)[:8] if isinstance(vals, (list, tuple)) else []}


def arbitrate_hard_rule(det=None, model_state: str = "", *,
                        rule_code: str = "", point: dict | None = None,
                        slots: dict | None = None, text: str = "",
                        current_state=None) -> dict:
    """硬合规项 × 模型裁决的显式冲突仲裁（唯一实现；纯函数、JSON 安全）。

    参数
    ----
    det : dict|None      确定性执行器结果（judge_limit_rule / judge_rule）；
                         None = 该判据族无可复算执行器（保持模型结论，见 §4 缺口）。
    model_state : str    模型原始裁决（五态/中文状态名均可；只读取，不改入参）。
    rule_code / point / slots : 用于 hard_rule_scope() 的硬合规项识别。
    text : str           归属对象原文（fail 引文逐字核验；为空时采信执行器切片）。
    current_state : str  既有守卫处理后的当前状态（默认=模型状态）。

    返回
    ----
    dict：{hard, rule_code, point_id, family, family_label, basis, switch,
           model_state, det_state, det_raw_state, det_detail, det_quote,
           det_applicability, quote_verifiable, final_state, state_changed,
           hard_veto, model_overridden, review_required, resolution, reason,
           conflict_list}
    真值表（只收紧不放松，详见段首注释）：
      · det=不满足：模型非 fail → fail（引文可核验）/ insufficient（fail-closed）；
      · det=证据不足/执行失败：模型 pass/na → insufficient + review_required；
      · det=满足：模型 fail → pass；模型弃权/不适用 → 维持现状（不硬升 pass）；
      · det=不适用：→ na（模型 pass/fail 不采信）。
      · 开关=0：原样返回（final_state=当前状态，resolution=switch_off）。
    """
    point = point if isinstance(point, dict) else {}
    scope = hard_rule_scope(rule_code=rule_code, point=point, slots=slots)
    model_norm = _hard_state_norm(model_state)
    cur_norm = _hard_state_norm(current_state) if current_state is not None \
        else model_norm
    pid = str(point.get("id") or point.get("code") or "")
    code = str(scope.get("rule_code") or rule_code or pid or "")
    det_sum = _hard_det_summary(det)
    det_state = det_sum["state"]
    quote_ok = _hard_quote_verifiable(det_sum["quote"], text)
    res = {
        "hard": bool(scope.get("hard")),
        "rule_code": code,
        "point_id": pid,
        "family": scope.get("family") or "",
        "family_label": scope.get("family_label") or "",
        "basis": scope.get("basis") or "",
        "switch": {"name": HARD_RULE_VETO_ENV,
                   "enabled": hard_rule_veto_enabled(),
                   "default": HARD_RULE_VETO_DEFAULT},
        "model_state": model_norm,
        "det_state": det_state,
        "det_raw_state": det_sum["raw_state"],
        "det_detail": det_sum["detail"],
        "det_quote": det_sum["quote"],
        "det_applicability": det_sum["applicability"],
        "quote_verifiable": bool(quote_ok),
        "final_state": cur_norm,
        "state_changed": False,
        "hard_veto": False,
        "model_overridden": False,
        "review_required": False,
        "resolution": "not_hard_rule",
        "reason": "",
        "conflict_list": [],
    }
    if not res["hard"]:
        res["reason"] = scope.get("reason") or "非硬合规项：保持原有合并口径"
        return res
    if not res["switch"]["enabled"]:
        res["resolution"] = "switch_off"
        res["reason"] = (f"{HARD_RULE_VETO_ENV}=0：硬规则边界关闭，"
                         "原样保留既有结论（A/B 回退）")
        return res
    if not isinstance(det, dict) or not det_state:
        res["resolution"] = "no_deterministic_result"
        res["reason"] = ("硬合规项没有可复算的确定性结论：不覆盖模型裁决"
                         "（该判据族无确定性执行器，缺口见报告 §4 未解决清单）")
        return res
    final = cur_norm
    if det_state == "fail":
        if model_norm == "fail":
            final = "fail"
            res["resolution"] = "agreed_fail"
            res["reason"] = "确定性不满足与模型 fail 一致，保持 fail"
        elif quote_ok:
            final = "fail"
            res["hard_veto"] = True
            res["model_overridden"] = True
            res["resolution"] = "hard_fail_preserved"
            res["reason"] = ("硬规则一票否决：确定性执行器判不满足（"
                             + str(res["det_detail"])[:80]
                             + f"），模型 {model_norm} 不可覆盖 fail")
        else:
            final = "insufficient"
            res["hard_veto"] = True
            res["model_overridden"] = True
            res["review_required"] = True
            res["resolution"] = "hard_fail_quote_unverifiable"
            res["reason"] = ("确定性判不满足但引文不可逐字核验（fail-closed）："
                             "降证据不足/复核；不接受模型 pass/na 静默覆盖")
    elif det_state in ("insufficient", "unknown"):
        if model_norm in ("pass", "na"):
            final = "insufficient"
            res["hard_veto"] = True
            res["model_overridden"] = True
            res["review_required"] = True
            res["resolution"] = "hard_unknown_not_pass"
            res["reason"] = (f"硬合规项确定性结论=证据不足，模型 {model_norm} 不得"
                             "静默通过/不适用：降证据不足并转复核")
        elif model_norm == "fail":
            final = "insufficient"
            res["model_overridden"] = True
            res["review_required"] = True
            res["resolution"] = "model_fail_without_det_support"
            res["reason"] = ("模型 fail 无确定性证据支撑：按证据不足/复核"
                             "（不伪造确定 fail）")
        else:
            final = cur_norm
            res["resolution"] = "hard_unknown_agreed"
            res["reason"] = "确定性与模型均为证据不足/未知，保持既有结论"
    elif det_state == "pass":
        if model_norm == "fail":
            final = "pass"
            res["model_overridden"] = True
            res["resolution"] = "hard_pass_overrides_model_fail"
            res["reason"] = ("确定性执行器判满足，模型 fail 误报被纠正"
                             "（既有守卫口径）")
        else:
            final = cur_norm
            res["resolution"] = "hard_pass_model_abstain"
            res["reason"] = ("确定性判满足但模型弃权/不适用：维持既有证据状态"
                             "（不硬升 pass）")
    elif det_state == "na":
        final = "na"
        res["model_overridden"] = model_norm != "na"
        res["resolution"] = ("hard_na_overrides_model" if res["model_overridden"]
                             else "hard_na_agreed")
        res["reason"] = ("确定性适用性判定=不适用（"
                         + (res["det_applicability"] or "已判定")
                         + "）：模型 pass/fail 不采信，保持 na")
    else:
        res["resolution"] = "det_state_unrecognized"
        res["reason"] = f"确定性状态无法识别（{det_state}）：不改模型结论"
    res["final_state"] = final
    res["state_changed"] = final != cur_norm
    if res["hard_veto"] or res["model_overridden"]:
        res["conflict_list"].append({
            "point_id": pid,
            "rule_code": code,
            "family": res["family"],
            "det_state": det_state,
            "det_raw_state": res["det_raw_state"],
            "model_state": model_norm,
            "current_state": cur_norm,
            "final_state": final,
            "resolution": res["resolution"],
            "hard_veto": bool(res["hard_veto"]),
            "model_overridden": bool(res["model_overridden"]),
            "quote_verifiable": bool(quote_ok),
            "det_detail": str(res["det_detail"])[:200],
        })
    return res


def _veto_row(row: dict, point: dict, text: str, det=None,
              model_state=None) -> dict | None:
    """把硬规则边界应用到单条 judge 结果（就地更新，row 必须已是 dict 副本）。

    只在 RULEPROOF_HARD_RULE_VETO=1 且该点位属硬合规项时生效；开关=0/非硬项返回
    None 且不修改 row（逐字回退）。返回结构化仲裁结果（写入 row["hard_rule"]）。
    """
    if not isinstance(row, dict) or not hard_rule_veto_enabled():
        return None
    try:
        point = point if isinstance(point, dict) else {
            "id": str(row.get("code") or "")}
        code = _resolve_rule_code(point)
        scope = hard_rule_scope(rule_code=code, point=point)
        if not scope.get("hard"):
            return None
        _det = det if isinstance(det, dict) else hard_rule_deterministic_result(
            rule_code=code, point=point, text=text)
        if not isinstance(_det, dict):
            return None
        _model_in = _hard_state_norm(model_state if model_state is not None
                                     else row.get("state"))
        _entry = _hard_state_norm(row.get("state"))
        res = arbitrate_hard_rule(_det, _model_in, rule_code=code, point=point,
                                  text=text, current_state=_entry)
        if not res.get("hard"):
            return None
        _final = str(res.get("final_state") or _entry)
        if _final and _final != _entry:
            row["state"] = _final
            _why = str(res.get("reason") or "")
            if _final == "fail":
                _q = str(res.get("det_quote") or "")
                if _q and (not str(text or "") or _q in str(text or "")):
                    row["quote"] = _q
            row["rationale"] = ((str(row.get("rationale") or "") + "｜"
                                 + _why).strip("｜"))
        # 硬否决/模型改写证据：无论状态是否被本层改写都写（既有守卫可能已把
        # fail 落好，但「硬规则一票否决」这一事实仍需结构化留痕）。
        if res.get("hard_veto") or res.get("model_overridden"):
            _ev = {"rule": "hard_rule_veto",
                   "family": res.get("family"),
                   "det_state": res.get("det_raw_state"),
                   "model_state": res.get("model_state"),
                   "final_state": _final,
                   "resolution": res.get("resolution"),
                   "quote_verifiable": bool(res.get("quote_verifiable"))}
            # 与既有守卫证据并存：既有 judge_guard（数值/B-4/结构/词典）保留原 rule，
            # 另加 hard_rule_veto 子证据；无既有证据时直接作为主证据。
            if isinstance(row.get("judge_guard"), dict):
                row["judge_guard"].setdefault("hard_rule_veto", dict(_ev))
            else:
                row["judge_guard"] = dict(_ev)
            if str(row.get("state") or "") == "fail":
                if isinstance(row.get("guard_override"), dict):
                    row["guard_override"].setdefault("hard_rule_veto", dict(_ev))
                else:
                    row["guard_override"] = dict(_ev)
        row["hard_rule"] = res
        return res
    except Exception:                      # noqa: BLE001 - 边界异常不得改变既有结论
        logging.getLogger(__name__).warning(
            "hard rule veto skipped（保留既有结论）point=%s",
            (row or {}).get("code"), exc_info=True)
        return None


def apply_hard_rule_veto(points: list, text: str, judged: list) -> list:
    """独立入口：对一批 agent-judge 结果应用硬规则一票否决（不依赖 guard_judged）。

    返回新列表（逐行浅拷贝，不修改入参）；开关=0 时内容与入参一致（A/B 回退）。
    与 guard_judged 内的调用可叠加（幂等：已仲裁过的行再次仲裁结果一致）。
    """
    if not isinstance(judged, list):
        return judged
    by_id = {}
    for p in (points or []):
        if isinstance(p, dict):
            by_id[str(p.get("id") or p.get("code") or "")] = p
    out = []
    on = hard_rule_veto_enabled()
    for row in judged:
        if not isinstance(row, dict):
            out.append(row)
            continue
        r = dict(row)
        if on:
            pid = str(r.get("code") or r.get("point_id") or "")
            _veto_row(r, by_id.get(pid) or {"id": pid}, text)
        out.append(r)
    return out


def hard_rule_conflicts(judged: list) -> dict:
    """汇总逐点硬规则仲裁结果（报告/门禁/证据用；纯读取，不写库）。"""
    conflicts = []
    hard_items = n_veto = n_over = 0
    for row in (judged or []):
        if not isinstance(row, dict):
            continue
        hr = row.get("hard_rule")
        if not isinstance(hr, dict) or not hr.get("hard"):
            continue
        hard_items += 1
        if hr.get("hard_veto"):
            n_veto += 1
        if hr.get("model_overridden"):
            n_over += 1
        for c in (hr.get("conflict_list") or []):
            if isinstance(c, dict):
                conflicts.append(dict(c))
    return {"hard_items": hard_items, "hard_veto": n_veto,
            "model_overridden": n_over, "conflict_list": conflicts,
            "switch": {"name": HARD_RULE_VETO_ENV,
                       "enabled": hard_rule_veto_enabled(),
                       "default": HARD_RULE_VETO_DEFAULT}}


def guard_judged(points: list, text: str, judged: list) -> list:
    """agent-judge 结论的确定性守卫（②③ 修复；① 通过限值执行器的适用性实现）。

    覆盖规则（只在确定性执行器能给出结论时生效，绝不把可执行的真实违规改掉）：
      · 数值比较：确定性=满足 且 模型=fail → pass（② 250ppm/121℃ 方向误报）；
        确定性=不满足 且 模型∈{pass,insufficient} → fail（召回兜底，引文取原文）；
        确定性=证据不足/不适用 且 模型=fail → 降级 insufficient/na（① 缺终温不判 fail）；
      · 结构类（修 C）：P01 审核点的文内确定性矛盾（分项合计/数量量纲/单位/日期链/
        编号区间/声明计数，见 judge_cross_ref_rule）判「不满足」且 模型=pass → fail，
        并写 judge_guard/guard_override 证据（判据名/操作数/复算结果/逐字 quote）；
        引文取不到原文切片 → 降 insufficient（fail-closed，不绕引文门禁）；
        确定性无法判定（缺数据）→ 不动模型结论；
      · 无词典：点位依赖规范词典且平台未配置词典 且 模型=fail → insufficient（③）；
      · L130 硬合规项一票否决（2026-11-25）：食品限值/添加剂限量/温度时间/禁用物质/
        强制标识等硬合规项的确定性 fail 不允许被模型改为 pass/na/unknown（引文不可
        核验则 fail-closed 降 insufficient）；确定性证据不足的硬合规项不允许模型静默
        pass/na → insufficient+复核。实现见 arbitrate_hard_rule/_veto_row，
        开关 RULEPROOF_HARD_RULE_VETO（默认 1，=0 回退；与 RULEPROOF_JUDGE_GUARD 正交）。
    开关关闭时原样返回（供 A/B 与回滚）。
    """
    if not isinstance(judged, list) or not points:
        return judged
    try:
        by_id = {str(p.get("id") or p.get("code") or ""): p for p in points if isinstance(p, dict)}
        out = []
        for row in judged:
            if not isinstance(row, dict):
                out.append(row)
                continue
            row = dict(row)
            _model_state_in = str(row.get("state") or "")
            pid = str(row.get("code") or "")
            point = by_id.get(pid) or {"id": pid}
            code = _resolve_rule_code(point)
            det = None
            if code and _judge_guard_on("RULEPROOF_JUDGE_GUARD_NUMERIC"):
                det = judge_limit_rule(code, text)
            if det:
                st = str(row.get("state") or "")
                dst = str(det.get("state") or "")
                if dst == "满足" and st == "fail":
                    row.update({"state": "pass",
                                "rationale": ((row.get("rationale") or "") +
                                              "｜确定性执行器复核：数值满足判据，模型误报已纠正").strip("｜"),
                                "judge_guard": {"rule": "numeric_compare", "det_state": dst,
                                                "model_state": st,
                                                "detail": det.get("detail") or ""}})
                elif dst == "不满足" and st in ("pass", "insufficient", "na"):
                    row.update({"state": "fail", "quote": det.get("quote") or ""})
                    row["rationale"] = ((row.get("rationale") or "") +
                                        "｜确定性执行器复核：数值不满足判据").strip("｜")
                    row["judge_guard"] = {"rule": "numeric_compare", "det_state": dst,
                                          "model_state": st,
                                          "detail": det.get("detail") or ""}
                elif dst in ("证据不足", "不适用") and st == "fail":
                    _map = {"证据不足": "insufficient", "不适用": "na"}
                    row.update({"state": _map[dst],
                                "rationale": ((row.get("rationale") or "") +
                                              "｜确定性执行器复核：" + str(det.get("detail") or "")
                                              ).strip("｜")})
                    row["judge_guard"] = {"rule": "applicability", "det_state": dst,
                                          "model_state": st,
                                          "applicability": det.get("applicability") or "",
                                          "detail": det.get("detail") or ""}
                elif det.get("applicability") in ("ambient_cooling", "no_cooling_process",
                                                   "no_topic", "precondition_missing") \
                        and st != "fail" and _judge_guard_on("RULEPROOF_JUDGE_GUARD_APPLIC"):
                    # 常温/无冷却工序：确定「不适用」优先于模型给 pass/insufficient（不伪造适用）
                    row.update({"state": "na",
                                "rationale": ((row.get("rationale") or "") +
                                              "｜确定性执行器复核：" + str(det.get("detail") or "")
                                              ).strip("｜")})
                    row["judge_guard"] = {"rule": "applicability", "det_state": dst,
                                          "model_state": st,
                                          "applicability": det.get("applicability") or ""}
            # B-4 / FOOD05-003 粒度守卫（2026-11-22 A 类修复，PS-L1-04 假报）：
            # 跨粒度（批次投料量 vs 单件/单袋设计总重）→ 模型 fail 降 na；
            # 同一粒度可复算 → 模型 fail 纠正 pass 或 pass/insufficient/na 接管 fail；
            # 接管 fail 必须逐字引文（fail-closed），取不到引文就降 insufficient。
            if pid in ("B-4", "FOOD05-003"):
                try:
                    _b4det = judge_weight_total_rule(pid, text)
                except Exception:  # noqa: BLE001 - 守卫异常不得改变判定（与原路径一致）
                    _b4det = None
                    logging.getLogger(__name__).warning(
                        "B-4 粒度守卫失败（原样返回模型结论）point=%s", pid, exc_info=True)
                if _b4det:
                    _b4st = str(_b4det.get("state") or "")
                    _b4_model = str(row.get("state") or "")
                    _b4ev = {"rule": "b4_granularity", "det_state": _b4st,
                             "model_state": _b4_model,
                             "applicability": _b4det.get("applicability") or "",
                             "detail": _b4det.get("detail") or "",
                             "values": _b4det.get("values") or [],
                             "switch": _B4_GRANULARITY_ENV}
                    if _b4st == "不适用" and _b4_model == "fail":
                        row.update({"state": "na",
                                    "rationale": ((row.get("rationale") or "") +
                                                  "｜确定性粒度守卫：" +
                                                  str(_b4det.get("detail") or "")).strip("｜")})
                        row["judge_guard"] = _b4ev
                    elif _b4st == "满足" and _b4_model == "fail":
                        row.update({"state": "pass",
                                    "rationale": ((row.get("rationale") or "") +
                                                  "｜确定性粒度守卫：" +
                                                  str(_b4det.get("detail") or "")).strip("｜")})
                        row["judge_guard"] = _b4ev
                    elif _b4st == "不满足" and _b4_model in ("pass", "insufficient", "na"):
                        _b4q = str(_b4det.get("quote") or "")
                        if _b4q and _b4q in text:
                            row.update({"state": "fail", "quote": _b4q,
                                        "rationale": ((row.get("rationale") or "") +
                                                      "｜确定性粒度守卫：" +
                                                      str(_b4det.get("detail") or "")).strip("｜")})
                            row["judge_guard"] = _b4ev
                            row["guard_override"] = _b4ev
                        else:
                            _b4ev["quote_gate"] = "failed"
                            row.update({"state": "insufficient",
                                        "rationale": ((row.get("rationale") or "") +
                                                      "｜确定性粒度守卫判定不满足，但引文不可核验"
                                                      "（fail-closed），降级证据不足").strip("｜")})
                            row["judge_guard"] = _b4ev
            # 修 C：P01 结构类确定性算子 —— 与模型结论的冲突处理（严格增量）。
            # 只在「确定性判据明确不满足 且 模型判 pass」时改 fail；判不了不动模型结论。
            # fail-closed：改 fail 的 quote 必须是原文切片，取不到就降 insufficient。
            _x_model_st = str(row.get("state") or "")
            _x_takeover = (_x_model_st == "pass") or (
                _x_model_st in ("insufficient", "na")
                and (pid in _P01_SECOND_HOP_CODES or pid in _CT_SECOND_HOP_CODES
                     or pid in _CT2_SECOND_HOP_CODES or pid in _BX_SECOND_HOP_CODES
                     or (pid in _RP_SECOND_HOP_CODES and recall_pilot_enabled()))
                and _judge_guard_on("RULEPROOF_JUDGE_GUARD_CROSSREF_SECOND_HOP"))
            # BX 判据族独立开关：关闭时本族既不接管 pass/na、也不回填锚点。
            if pid in _BX_DET_CODES and not _judge_guard_on("RULEPROOF_JUDGE_GUARD_BX"):
                _x_takeover = False
            if _judge_guard_on("RULEPROOF_JUDGE_GUARD_CROSSREF") and _x_takeover:
                try:
                    _xdet = judge_cross_ref_rule(pid, text)
                except Exception:
                    _xdet = None
                    logging.getLogger(__name__).warning(
                        "cross-ref guard failed（原样返回模型结论）point=%s", pid, exc_info=True)
                if _xdet and str(_xdet.get("state") or "") == "不满足":
                    _xq = str(_xdet.get("quote") or "")
                    _xev = {"rule": _xdet.get("rule") or "cross_ref",
                            "det_state": "不满足", "model_state": _x_model_st,
                            "second_hop": _x_model_st in ("insufficient", "na"),
                            "operands": _xdet.get("operands") or [],
                            "recompute": _xdet.get("recompute") or "",
                            "detail": _xdet.get("detail") or "",
                            "quote": _xq}
                    if _xq and _xq in text:
                        row.update({
                            "state": "fail", "quote": _xq,
                            "rationale": ((row.get("rationale") or "") +
                                          "｜确定性结构算子复核：" +
                                          str(_xdet.get("detail") or "")).strip("｜"),
                            "judge_guard": _xev, "guard_override": _xev})
                    else:
                        _xev["quote_gate"] = "failed"
                        row.update({
                            "state": "insufficient",
                            "rationale": ((row.get("rationale") or "") +
                                          "｜确定性结构算子判定不满足，但引文不可核验"
                                          "（fail-closed），降级证据不足").strip("｜"),
                            "judge_guard": _xev, "guard_override": _xev})
            # BX：模型已判 fail 但引文锚到别处（M 类 FN：模板空白/他码条款）→ 用确定性
            # 算子的 SW/TK 原文切片回填引文。**不改判态**（fail→fail），只修锚点；
            # 回填后仍要求 quote 逐字在原文（fail-closed），取不到则不动模型结论。
            if (_x_model_st == "fail" and pid in _BX_ANCHOR_FIX_CODES
                    and _judge_guard_on("RULEPROOF_JUDGE_GUARD_BX")):
                try:
                    _bxdet = judge_cross_ref_rule(pid, text)
                except Exception:
                    _bxdet = None
                    logging.getLogger(__name__).warning(
                        "BX numeric guard failed（原样返回模型结论）point=%s", pid,
                        exc_info=True)
                if _bxdet and str(_bxdet.get("state") or "") == "不满足":
                    _bxq = str(_bxdet.get("quote") or "")
                    if _bxq and _bxq in text:
                        _bxev = {"rule": _bxdet.get("rule") or "bx_numeric",
                                 "det_state": "不满足", "model_state": "fail",
                                 "anchor_fix": True,
                                 "operands": _bxdet.get("operands") or [],
                                 "recompute": _bxdet.get("recompute") or "",
                                 "detail": _bxdet.get("detail") or "",
                                 "quote": _bxq}
                        row.update({
                            "quote": _bxq,
                            "rationale": ((row.get("rationale") or "") +
                                          "｜确定性数值复算复核（锚点回填）：" +
                                          str(_bxdet.get("detail") or "")).strip("｜"),
                            "judge_guard": _bxev, "guard_override": _bxev})
            if _judge_guard_on("RULEPROOF_JUDGE_GUARD_DICT") \
                    and _is_dictionary_point(point):
                try:
                    _dict_names = dictionary_names()
                except Exception:
                    _dict_names = None  # 检测失败时保守：不覆盖模型结论（不能假装没词典）
                if _dict_names is not None:
                    _doc_names = _doc_product_names(text)
                    _all_in = bool(_doc_names) and all(
                        _name_in_dictionary(n, _dict_names) for n in _doc_names)
                    _model_st = str(row.get("state") or "")
                    if _all_in and _model_st in ("fail", "insufficient", "na"):
                        row.update({
                            "state": "pass",
                            "rationale": ((row.get("rationale") or "") +
                                          "｜确定性词典比对：文档商品名均在已配置规范词典内").strip("｜"),
                            "judge_guard": {"rule": "dictionary_match",
                                            "model_state": _model_st,
                                            "names": _doc_names[:6]}})
                    elif not _dict_names and str(row.get("state") or "") == "fail":
                        row.update({
                            "state": "insufficient",
                            "rationale": ((row.get("rationale") or "") +
                                          "｜平台未配置规范词典，名称规范判据不可判定"
                                          "（按证据不足转人工，不判不满足）").strip("｜"),
                            "judge_guard": {"rule": "dictionary_missing",
                                            "model_state": "fail",
                                            "detail": "无规范词典（引擎 demo 实体名不算规范词典）"}})
            # L130 六视角①（2026-11-25）：硬合规项一票否决/不可覆盖边界。
            # 叠加在既有守卫之后：只在硬合规项族（食品限值/添加剂限量/温度时间/
            # 禁用物质/强制标识）上生效，只做「不让确定性 fail 被模型改写、不让
            # 未知硬合规项静默 pass/na」的收紧；非硬项/开关=0 时零行为变化。
            # 模型原始状态单独传入（既有守卫可能已改写 row["state"]）。
            if hard_rule_veto_enabled():
                try:
                    _veto_row(row, point, text, det=det,
                              model_state=_model_state_in)
                except Exception:        # noqa: BLE001 - 边界异常不得改变既有结论
                    logging.getLogger(__name__).warning(
                        "hard rule veto skipped（保留既有守卫结论）point=%s",
                        pid, exc_info=True)
            out.append(row)
        return out
    except Exception:
        logging.getLogger(__name__).warning("judge guard failed（原样返回模型结论）", exc_info=True)
        return judged
