"""深入通用解析器：任意 docx/pdf/xlsx → 统一文档模型 → 结构化事实层。

目标：不再绑定单一 xlsx 结构；任何真实文件都能抽到「可复核的事实」，
供上层 15 条规则 / 审核点库 / 语义判断 统一消费。

事实种类：温度/时间/浓度/重量/占比/日期/编号/金额/名称/版本号/占位符X，
每条带 值/单位/对象/上下文/锚点(段落或表格单元格)。
"""
import os
import re
import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime
import unicodedata

# L154（2026-11-25）：文档结构 IR（页/表/行列单元格/坐标/字符区间）。
# 本模块只做结构与几何/字符区间，不 import deepparse（无循环依赖）。
from . import document_ir as _dir


@dataclass
class Section:
    kind: str          # paragraph / heading / table
    text: str
    anchor: str        # 定位（页/段落/单元格）
    # TL-5 按页/段 provenance：该文本块实际由哪一层产出。
    # 默认空 = 未知（老数据/无 provenance 快照），不默认安全；解析器必须显式填充。
    ocr_engine: str = ""        # 'text_layer' | 'paddle' | 'baidu' | 'external_cmd' | 'vision' | ''
    ocr_tier: str = ""          # 'text' | 'ocr' | 'vision' | ''
    vision_advisory: bool | None = None  # None=未知；True=通用视觉模型产出（数值不得用于判定）
    # L43（2026-11-24）：该 section 文本在 ParsedDoc.text 中的字符区间（左闭右开，-1=未知）。
    # 页眉/页脚 section（kind=header/footer）必填，供证据定位与正文/页眉区段消歧使用；
    # 其它格式保留 -1（不改变既有语义）。
    char_start: int = -1
    char_end: int = -1

    def to_dict(self):
        return asdict(self)


@dataclass
class ParsedDoc:
    source: str
    doc_type: str
    sections: list = field(default_factory=list)
    text: str = ""
    # T-148：解析状态（ok/partial/failed，语义与 document.parse_status 一致，不新增状态值）。
    # 扫描件无文本层时，若 OCR 前置的 PDF 渲染能力不可用，这里必须是 partial 并带原因，
    # 不能只返回空文本让上层以为「解析成功但没内容」。
    parse_status: str = "ok"
    status_reason: str = ""
    ocr_capability: dict = field(default_factory=dict)   # {status, available, source, reason, hint}
    ocr_unavailable: bool = False                        # 需要 OCR 但 OCR 能力不可用
    # TL-5：按页 provenance，如 {"第1页": {"ocr_engine": "vision", "ocr_tier": "vision",
    # "vision_advisory": True}}；空 dict = 未知（老数据），不默认安全。
    page_provenance: dict = field(default_factory=dict)
    # P0 安全（2026-11-22）：xlsx 解析时按开关跳过的隐藏/极隐藏 sheet 名（结构化留痕，不静默）。
    # 隐藏 sheet 是攻击者可控载体（内容不应成为判定证据），见 docs/qa/P0加固_提示边界与隐藏sheet_20261122.md
    skipped_sheets: list = field(default_factory=list)
    # P1 安全（2026-11-23）：docx 解析时按开关跳过的隐藏文本摘要（白字/≤2pt/vanish）。
    # 只记位置/字符数/原因，不复制正文（防止把攻击载荷带进解析报告/DB）；见
    # docs/qa/注入加固残留_20261123.md §5-P1 与 docs/qa/P1加固三项_20261123.md。
    skipped_hidden_text: list = field(default_factory=list)
    # L116（2026-11-25）：页眉/页脚证据状态（结构化，不静默）：
    # {"format": "pdf|docx|xlsx", "switch": "on|off", "state": "found|none|no_text_layer|disabled|error",
    #  "sufficient": bool, "reason": str, "sections": int, "pages": int}
    # state=none/no_text_layer 即「证据不足」：字段缺失是解析层证据缺口，上层不得默认放行；
    # 空 dict = 老数据/该格式不适用（不默认安全）。
    header_footer_evidence: dict = field(default_factory=dict)
    # L144 T-⑤a（2026-11-25）：按页 fail-closed 的缺失范围枚举（FC4/FC10）。
    # pages_missing=无文本层且含图像内容的页（不可判定）；pages_blank=无文本层也无图像的空白页。
    pages_missing: list = field(default_factory=list)
    pages_blank: list = field(default_factory=list)
    # L144：断行/跨页数字拼回证据（N9；每条含 before/fragment/joined/anchor）。
    numeric_joins: list = field(default_factory=list)
    # L144：表格结构质量与显式标记（T3/T4/T9）：
    # {format, sheets:[{sheet,rows,columns,merges,merged_continuations,formula_no_cache}],
    #  empty_cells, merged_continuations:[...], formula_no_cache:[...]}
    table_quality: dict = field(default_factory=dict)
    # L154（2026-11-25）：文档结构 IR（L137 §5.2 O1–O5 / §5.3 T1–T10）。
    # 与 text/sections/facts 并列的**新增结构**，不改变既有字段语义：
    #   pages   [Page]   PDF 页（页号/尺寸/文本层/文本块+bbox+char 区间）
    #   sheets  [Sheet]  xlsx sheet（sheet 为独立表身份，隐藏 sheet 只留痕）
    #   tables  [Table]  表（table_id / 行列 / rowspan, colspan / 单元格 char 区间 / 续表）
    #   comments   docx 批注独立通道（作者/时间/锚点/文本，不进正文）
    #   revisions  docx 修订通道（默认接受插入、忽略删除并标注）
    #   ir_summary IR 摘要（表数/单元格数/char span 完整度/不支持明示）
    pages: list = field(default_factory=list)
    sheets: list = field(default_factory=list)
    tables: list = field(default_factory=list)
    comments: dict = field(default_factory=dict)
    revisions: dict = field(default_factory=dict)
    ir_summary: dict = field(default_factory=dict)

    def provenance_summary(self) -> dict:
        """文档级 provenance 摘要（trusted / vision / unknown / mixed；复用 hooks 口径）。"""
        from . import hooks as _hk
        return _hk.doc_provenance(self.page_provenance,
                                  [asdict(s) for s in self.sections])

    def to_dict(self):
        _prov = self.provenance_summary()
        return {"source": self.source, "doc_type": self.doc_type, "text": self.text,
                "sections": [asdict(s) for s in self.sections],
                "parse_status": self.parse_status, "status_reason": self.status_reason,
                "ocr_capability": self.ocr_capability,
                "ocr_unavailable": self.ocr_unavailable,
                "page_provenance": dict(self.page_provenance or {}),
                "skipped_sheets": list(self.skipped_sheets or []),
                "skipped_hidden_text": list(self.skipped_hidden_text or []),
                "header_footer_evidence": dict(self.header_footer_evidence or {}),
                "pages_missing": list(self.pages_missing or []),
                "pages_blank": list(self.pages_blank or []),
                "numeric_joins": list(self.numeric_joins or []),
                "table_quality": dict(self.table_quality or {}),
                # L154 结构 IR（新增字段；text/sections/facts 不变）
                "pages": list(self.pages or []),
                "sheets": list(self.sheets or []),
                "tables": list(self.tables or []),
                "comments": dict(self.comments or {}),
                "revisions": dict(self.revisions or {}),
                "ir_summary": dict(self.ir_summary or {}),
                # L144 fail-closed：降级状态与原因随解析产物透传（L137 FC10），
                # 不把 partial/failed 当 ok 交给上层（上层仍需按 parse_status 判）。
                "degraded": self.parse_status != "ok",
                "degraded_reason": str(self.status_reason or ""),
                "provenance": _prov,
                "ocr_engine": str(_prov.get("ocr_engine") or ""),
                "ocr_tier": str(_prov.get("ocr_tier") or ""),
                "vision_advisory": _prov.get("vision_advisory")}


@dataclass
class Fact:
    kind: str          # temp/time/conc/weight/percent/date/id/version/placeholder
    value: str
    unit: str
    object: str        # 对象（如 中心温度/消毒/解冻）
    context: str
    anchor: str
    # TL-5 provenance：数值事实来源必须可归因；字段默认空/None = 未知（不默认安全）。
    ocr_engine: str = ""        # 'text_layer' | 'paddle' | 'baidu' | 'external_cmd' | 'vision' | ''
    ocr_tier: str = ""          # 'text' | 'ocr' | 'vision' | ''
    vision_advisory: bool | None = None  # True=通用视觉模型产出，数值不得作为判定依据
    evidence_source: str = ""   # 未知/视觉来源的数值事实标 'vision_advisory'（可审计）
    # L43（2026-11-24）：来源 section 类型（paragraph/heading/table/header/footer；''=未知）
    # 与「值」在所属 section 文本内的字符区间（左闭右开，-1=未知）。页眉/页脚字段据此可定位。
    section_kind: str = ""
    char_start: int = -1
    char_end: int = -1
    # L144 T-⑤a（2026-11-25）：数字/单位写法归一的审计字段（N1/N2/N4/N8）。
    raw: str = ""              # 原文写法（NFKC 前；含千分位/全角/负号变体），用于引文回指
    value_ascii: bool = True   # value 是否 ASCII 十进制（N2 契约）
    confidence: float = 1.0    # 数值规约置信度；0=歧义/未知单位，不得用于确定性比较
    ambiguous: bool = False    # 数值写法歧义（N4：不猜，value 空）
    unit_unknown: bool = False  # 单位未登记（N8：不猜量纲）
    normalized: bool = False   # 是否经过写法归一（如 1,200→1200）

    def to_dict(self):
        return asdict(self)


# ---------------------------------------------------------------- 数值/单位抽取
# L144 T-⑤a（2026-11-25）：事实层「数字/单位写法归一」。
# 依据 docs/qa/build53_文档解析与预处理规格_20261125.md §5.4 N1–N10：
#   N1 正文数值在事实层统一 NFKC（全角数字/全角单位/㎏→kg/％→%），但保留 raw 原文回指；
#   N2 value 必须是 ASCII 十进制（^-?\d+(\.\d+)?$），禁止全角/千分位逗号/货币符号进入 value；
#   N3 千分位 1,200 / 12,000 / 1,200.5 → 1200 / 12000 / 1200.5；
#   N4 欧洲小数 1.234,56 → 1234.56（以分隔符结构与位数判据）；**歧义不猜**：
#      标 ambiguous_number、value 空、confidence=0（下游不得用于确定性比较）；
#   N5 负号 -/−/－ 归一到 ASCII 负号；区间连接符 0-8℃ 不得解析成负值；
#   N6 ％/% 归一 %，‰ 单列 ratio；
#   N7 单位登记表扩容（℃/℉/°F/㎏/ppm/ppb/mg/kg/μg/kg/g/kg 等）；
#   N8 未登记单位 → unit_unknown（不猜量纲、confidence=0、不得参与确定性比较）；
#   N9 断行数字由 _apply_numeric_joins 在解析层按「邻近 section + 纯数值片段」保守拼回；
#   N10 解析层只做**写法归一**，不做量纲换算（换算只在比较层 certificate.to_base /
#       rexec.canon_*；本层不产出 base_value/系数，避免两套换算口径）。
# 回退：本任务未 commit；如需回退，按任务写作用域 revert 本文件即可（未新增开关，避免开关登记面扩大）。
_UNIT_SPECS = [
    # (kind, [(写法, 归一单位) ...]) —— 写法按 NFKC 后文本匹配；归一单位用于事实层输出
    ("temp", [("℃", "℃"), ("°C", "℃"), ("摄氏度", "℃"), ("度", "℃"),
              ("℉", "℉"), ("°F", "℉"), ("华氏度", "℉")]),
    ("time", [("h", "h"), ("hr", "h"), ("小时", "h"), ("min", "min"), ("分钟", "min"),
              ("s", "s"), ("sec", "s"), ("秒", "s"), ("ms", "ms"), ("工作日", "工作日"),
              ("天", "天"), ("日", "日"), ("d", "d")]),
    ("conc", [("ppm", "ppm"), ("ppb", "ppb"), ("ppt", "ppt"),
              ("mg/kg", "mg/kg"), ("mg·kg⁻¹", "mg/kg"), ("mg·kg-1", "mg/kg"),
              ("mg/kg-1", "mg/kg"), ("μg/kg", "μg/kg"), ("µg/kg", "μg/kg"),
              ("ug/kg", "μg/kg"), ("g/kg", "g/kg"),
              ("mg/L", "mg/L"), ("μg/L", "μg/L"), ("g/L", "g/L"),
              ("mg/m3", "mg/m3"), ("μg/m3", "μg/m3"), ("mol/L", "mol/L")]),
    ("weight", [("kg", "kg"), ("千克", "kg"), ("公斤", "kg"),
                ("g", "g"), ("克", "g"), ("mg", "mg"), ("毫克", "mg"),
                ("μg", "μg"), ("µg", "μg"), ("微克", "μg"),
                ("t", "t"), ("吨", "t"), ("斤", "斤")]),
    ("length", [("mm", "mm"), ("毫米", "mm"), ("cm", "cm"), ("厘米", "cm"),
                ("km", "km"), ("千米", "km"), ("m", "m"), ("米", "m"),
                ("μm", "μm"), ("µm", "μm"), ("微米", "μm"), ("nm", "nm"), ("纳米", "nm"),
                ("in", "in"), ("英寸", "in"), ("ft", "ft")]),
    ("area", [("m2", "m2"), ("㎡", "m2"), ("平方米", "m2"), ("m²", "m2"),
              ("cm2", "cm2"), ("mm2", "mm2"), ("hm2", "hm2"), ("公顷", "hm2")]),
    ("volume", [("mL", "mL"), ("ml", "mL"), ("毫升", "mL"), ("μL", "μL"),
                ("L", "L"), ("l", "L"), ("升", "L"),
                ("m3", "m3"), ("立方米", "m3"), ("m³", "m3")]),
    ("pressure", [("MPa", "MPa"), ("kPa", "kPa"), ("hPa", "hPa"), ("Pa", "Pa"),
                  ("mbar", "mbar"), ("bar", "bar"), ("公斤压力", "公斤压力"), ("psi", "psi")]),
    ("power", [("kW·h", "kW·h"), ("kWh", "kW·h"), ("kW", "kW"), ("MW", "MW"),
               ("W", "W"), ("伏", "V"), ("V", "V"), ("A", "A")]),
    ("angle", [("°", "°"), ("′", "′"), ("″", "″")]),
    ("money", [("亿元", "亿元"), ("万元", "万元"), ("美元", "美元"), ("USD", "USD"),
               ("CNY", "CNY"), ("元", "元"), ("¥", "元"), ("￥", "元")]),
    ("percent", [("%", "%")]),
    ("ratio", [("‰", "‰")]),
    ("count", [("个", "个"), ("件", "件"), ("套", "套"), ("台", "台"), ("处", "处"),
               ("根", "根"), ("张", "张"), ("份", "份"), ("组", "组"), ("批", "批"),
               ("次", "次"), ("条", "条"), ("项", "项")]),
    ("speed", [("r/min", "r/min"), ("rpm", "rpm"), ("m/s", "m/s"),
               ("km/h", "km/h"), ("m/min", "m/min")]),
    ("density", [("kg/m3", "kg/m3"), ("g/cm3", "g/cm3")]),
    ("hardness", [("HB", "HB"), ("HRC", "HRC"), ("HV", "HV")]),
    ("grade", [("级", "级"), ("等级", "等级")]),
]
# 单位写法 → (kind, 归一单位)；键为 NFKC 后的小写写法（ASCII 大小写不敏感，CJK 不变）
_UNIT_INDEX = {}
_UNIT_CANON = {}
for _kind, _specs in _UNIT_SPECS:
    for _alias, _canon in _specs:
        _key = unicodedata.normalize("NFKC", _alias).strip().lower()
        _UNIT_INDEX.setdefault(_key, _kind)
        _UNIT_CANON.setdefault(_key, _canon)
# 兼容旧口径：旧 `_UNIT_INDEX[_u] = _k` 为「后写覆盖」，「度」最终归 angle（非 temp）。
# 本登记表用 setdefault 保留首写，故显式覆盖以维持既有事实 kind/下游判据不变（T2 不回归）。
_UNIT_INDEX["度"] = "angle"
_UNIT_CANON["度"] = "度"
_UNIT_ALT = "|".join(re.escape(_k) for _k in sorted(_UNIT_INDEX, key=len, reverse=True))
_UNIT_TAIL_RE = re.compile(r"(?i)\s*(" + _UNIT_ALT + r")(?![A-Za-z0-9_])")
_ASCII_DECIMAL_RE = re.compile(r"^-?\d+(?:\.\d+)?$")


def _is_ascii_decimal(v) -> bool:
    """value 是否 ASCII 十进制（N2 契约；供 value_ascii 审计字段）。"""
    return bool(_ASCII_DECIMAL_RE.match(str(v if v is not None else "")))


# 未登记单位（N8，保守）：仅识别数字后（可隔 1 个空格）的 ASCII/希腊单位样式 token，
# 且长度 ≤5、不是常见英文停用词/量词（避免把 "12 December"/"12 项" 这类误标成单位）；
# 命中即 unit_unknown=True + confidence=0（不猜量纲、不参与确定性比较）。
_UNKNOWN_UNIT_RE = re.compile(r"([A-Za-zμµ]{1,5})(?![A-Za-z0-9_])")
_UNKNOWN_UNIT_STOPWORDS = {
    "a", "an", "the", "of", "to", "in", "on", "at", "by", "for", "is", "are",
    "was", "were", "and", "or", "vs", "via", "per", "no", "not", "has", "may",
    "can", "shall", "will", "day", "days", "year", "years", "time",
}
# 数字 token（NFKC 后文本上匹配；不含单位）。分隔符结构：
#   US 千分位 1,200 / 1,200.5；EU 多点千分位 1.234.567；EU 千分位+小数 1.234,56；
#   EU 单逗号两位小数 2,50（N4 判据：唯一逗号且其后 2 位）；普通小数/整数；.5。
_NUMISH = (r"(?:[-−－]?(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?"
           r"|\d{1,3}(?:\.\d{3}){2,}(?:,\d+)?"
           r"|\d{1,3}(?:\.\d{3})+,\d+"
           r"|\d{1,3},\d{2}"
           r"|\d+(?:\.\d+)?"
           r"|\.\d+))")
_NUMISH_RE = re.compile(r"(?<![0-9A-Za-z_.,])" + _NUMISH + r"(?!\d)")
# 区间：连接符两侧都是数值；排除日期/版本式 "2026-11-01"（hi 后接 -数字 即拒绝）
_RANGE_RE = re.compile(r"(?<![0-9A-Za-z_.,])(?P<lo>" + _NUMISH + r")\s*"
                       r"(?P<sep>~|～|—|–|至|到|-)\s*(?P<hi>" + _NUMISH + r")"
                       r"(?![0-9])(?![-\-/–—]\d)")
_COMPARE_RE = re.compile(r"(?P<op>≥|≤|>|<|不小于|不大于|不低于|不高于|超过|少于|大于|小于)\s*"
                         r"(?P<num>" + _NUMISH + r")")
# N4 歧义写法（不猜）：逗号后仅 1 位（2,5 可能是 2.5 或 25，千分位不完整）
_AMBIG_NUM_RE = re.compile(r"(?<![0-9A-Za-z_.,])(?P<tok>[-−－]?\d{1,3},\d(?!\d))")
# 非数值事实（沿用旧口径；在 NFKC 文本上匹配，value 尽量取 ASCII）
_NON_NUM_PATTERNS = [
    ("date", re.compile(r"(20\d{2}|19\d{2})[-/年]\s*(\d{1,2})[-/月]\s*(\d{1,2})日?")),
    ("version", re.compile(r"([A-Za-z]{1,8}[-/][A-Za-z0-9]{2,}(?:[-/][A-Za-z0-9]+)+)")),
    ("code", re.compile(r"\b([A-Z]{1,4}[-_]?\d{2,}[-_]?\d{2,}(?:[-_]\w+)?)\b")),
    ("placeholder", re.compile(r"(?:编号|版本号|版本|签名|日期)[:：]\s*([Xx×＿_]{1,}|待填|空)")),
]
# 领域对象词：只影响 object 字段（同一指标的跨位置比对），不影响抽取本身
_OBJECT_CUES = [
    ("温度", ("温度", "中心温度", "终温", "冷藏", "冷冻", "冷却", "库温", "水温", "油温")),
    ("时间", ("时间", "时长", "养护", "固化", "干燥", "保温", "静置", "解冻")),
    ("浓度", ("浓度", "含量", "剂量", "掺量")),
    ("重量", ("重量", "重量份", "用量", "投料", "质量")),
    ("长度", ("厚度", "直径", "深度", "宽度", "高度", "间距", "长度", "孔径")),
    ("面积", ("面积", "粘结面积", "覆盖面积")),
    ("压力", ("压力", "压强", "风压")),
    ("角度", ("角度", "坡度", "倾角")),
    ("金额", ("金额", "价款", "报价", "费用", "总价")),
    ("比例", ("比例", "百分比", "含量占比", "含水率")),
]


def _nfkc_with_map(text: str):
    """NFKC 归一 + 归一字符→原文下标的映射（逐字符归一，保证 raw/char span 可回指）。

    返回 (归一文本, orig_index)。orig_index[i] = 归一文本第 i 个字符来自原文的字符下标；
    NFKC 可把 1 个兼容字符展开成多个（㎏→kg、℉→°F），展开字符共享同一原文下标。
    """
    nchars, idx = [], []
    for i, ch in enumerate(str(text or "")):
        n = unicodedata.normalize("NFKC", ch)
        for c in n:
            nchars.append(c)
            idx.append(i)
    return "".join(nchars), idx


def _orig_span(orig_index, start: int, end: int) -> tuple:
    """归一文本区间 [start,end) → 原文区间（左闭右开）；不可映射返回 (-1,-1)。"""
    if not orig_index or end <= start:
        return -1, -1
    try:
        s = int(orig_index[max(0, start)])
        e = int(orig_index[min(len(orig_index) - 1, end - 1)]) + 1
    except (IndexError, TypeError, ValueError):
        return -1, -1
    return s, e


def _parse_number_token(tok: str) -> dict:
    """数字写法 → {value, raw, ambiguous, reason, normalized}（N2–N5）。

    value 为空 + ambiguous=True = 歧义/不可规范化：不猜（下游 confidence=0 不得判定）。
    """
    raw = str(tok or "")
    s = raw.replace("−", "-").replace("－", "-")
    neg = s.startswith("-")
    if neg:
        s = s[1:]
    value, reason = "", ""
    if "," in s and "." in s:
        if re.fullmatch(r"\d{1,3}(?:\.\d{3})+,\d+", s):
            value = s.replace(".", "").replace(",", ".")
        elif re.fullmatch(r"\d{1,3}(?:,\d{3})+(?:\.\d+)", s):
            value = s.replace(",", "")
        else:
            reason = "mixed_separators"
    elif "," in s:
        if re.fullmatch(r"\d{1,3}(?:,\d{3})+", s):
            value = s.replace(",", "")
        elif re.fullmatch(r"\d{1,3},\d{2}", s):     # N4：唯一逗号 + 其后恰好 2 位
            value = s.replace(",", ".")
        else:
            reason = "ambiguous_thousands_or_decimal_comma"
    elif s.count(".") > 1:
        if re.fullmatch(r"\d{1,3}(?:\.\d{3}){2,}", s):
            value = s.replace(".", "")
        else:
            reason = "ambiguous_multiple_dots"
    elif s.startswith("."):
        value = "0" + s
    elif s:
        value = s
    else:
        reason = "empty"
    if value:
        try:
            float(value)
        except (TypeError, ValueError):
            value, reason = "", "not_float"
    if not value:
        return {"value": "", "raw": raw, "ambiguous": True,
                "reason": reason or "ambiguous_number", "normalized": False}
    if neg and value != "0":
        value = "-" + value
    return {"value": value, "raw": raw, "ambiguous": False, "reason": "",
            "normalized": (value != s), "normalized_value_ascii": value.isascii()}


def _match_unknown_unit(ntext: str, pos: int):
    """数字后的未登记单位（N8，保守）。仅允许 0–1 个空格 + 1–5 位 ASCII/希腊字母。

    返回 (raw_unit, end) 或 None；停用词/英文单词不当作单位（不猜量纲）。
    """
    tail = ntext[pos:]
    stripped = tail.lstrip(" ")
    gap = len(tail) - len(stripped)
    if gap > 1 or not stripped:
        return None
    m = _UNKNOWN_UNIT_RE.match(stripped)
    if not m:
        return None
    word = m.group(1)
    if word.lower() in _UNKNOWN_UNIT_STOPWORDS:
        return None
    return word, pos + gap + m.end()


def _match_unit(ntext: str, pos: int):
    """从 pos 起匹配登记单位（允许空白）。返回 (kind, canonical, end, raw_unit) 或 None。"""
    m = _UNIT_TAIL_RE.match(ntext, pos)
    if not m:
        return None
    raw_unit = m.group(1)
    key = raw_unit.strip().lower()
    kind = _UNIT_INDEX.get(key) or "num"
    canon = _UNIT_CANON.get(key) or raw_unit.strip()
    return kind, canon, m.end(), raw_unit.strip()


def _object_of(text: str, start: int) -> str:
    """取离数值最近的对象线索（不是第一个匹配），避免跨句串味。"""
    ctx = text[max(0, start - 24):start]
    generic = {"温度", "时间", "浓度", "重量", "长度", "面积", "压力", "角度", "金额", "比例"}
    hits = []
    for obj, kws in _OBJECT_CUES:
        for kw in kws:
            pos = ctx.rfind(kw)
            if pos >= 0:
                hits.append((obj, kw, pos, pos + len(kw)))
    if not hits:
        return ""
    specific = [h for h in hits if h[1] not in generic]
    pool = specific or hits
    obj, kw, pos, end = max(pool, key=lambda h: (h[3], len(h[1])))
    return kw


def _norm_date(m):
    y, mo, d = m.group(1), m.group(2), m.group(3)
    try:
        return datetime(int(y), int(mo), int(d)).strftime("%Y-%m-%d")
    except Exception:
        return f"{y}-{mo}-{d}"


# 文本层/确定性解析（非 OCR、非视觉模型）的 provenance：可信，不影响既有数值判定
_TEXT_LAYER_PROV = {"ocr_engine": "text_layer", "ocr_tier": "text", "vision_advisory": False}


def _section_prov_kwargs(prov) -> dict:
    """provenance → Section 的 provenance 字段（未知时保持空/None，不默认安全）。"""
    from . import hooks as _hk
    f = _hk.fact_provenance_fields(prov)
    return {"ocr_engine": f["ocr_engine"], "ocr_tier": f["ocr_tier"],
            "vision_advisory": f["vision_advisory"]}


# ---- P1 安全（2026-11-23）：docx 隐藏文本（白字 / ≤2pt / vanish）----------------
# 背景：docs/qa/注入加固残留_20261123.md §5-P1 —— docx 白色字体 2pt / 1pt 的指令文本
# 被当普通正文进入判定 prompt（文本层无格式感知）。这里在解析层按 run 级格式跳过隐藏
# 文本（不作为判定证据），只留结构化摘要（位置/字符数/原因，不复制正文），并写警告日志；
# 不改判定逻辑/阈值/输出协议。独立开关、可逐字回退；与 xlsx 隐藏 sheet 跳过同口径。
# 回退：RULEPROOF_HIDDEN_TEXT_GUARD=0 → 逐字恢复旧行为（全部文本按正文解析）。
_HIDDEN_TEXT_MAX_PT = 2.0


def hidden_text_guard_enabled() -> bool:
    """RULEPROOF_HIDDEN_TEXT_GUARD（默认 1）：docx 隐藏文本不进判定文本。"""
    return str(os.environ.get("RULEPROOF_HIDDEN_TEXT_GUARD", "1")).strip().lower() not in (
        "0", "false", "no", "off")


def _font_hidden_reasons(font) -> list:
    """单个 Font 对象上的隐藏样式原因（只读格式，不改文本；空 = 可见）。"""
    reasons = []
    if font is None:
        return reasons
    _log = logging.getLogger(__name__)
    try:
        if getattr(font, "hidden", None) is True:
            reasons.append("vanish")
    except Exception as _e:  # 样式探测失败不阻断解析，但留痕
        _log.debug("hidden style probe (hidden) failed: %s", _e)
    try:
        if getattr(font, "spec_vanish", None) is True:
            reasons.append("spec_vanish")
    except Exception as _e:
        _log.debug("hidden style probe (spec_vanish) failed: %s", _e)
    try:
        size = getattr(font, "size", None)
        if size is not None and float(size.pt) <= _HIDDEN_TEXT_MAX_PT:
            reasons.append("size<=2pt")
    except Exception as _e:
        _log.debug("hidden style probe (size) failed: %s", _e)
    try:
        color = getattr(font, "color", None)
        rgb = getattr(color, "rgb", None) if color is not None else None
        if rgb is not None:
            from docx.shared import RGBColor
            if rgb == RGBColor(0xFF, 0xFF, 0xFF):
                reasons.append("white")
    except Exception as _e:
        _log.debug("hidden style probe (color) failed: %s", _e)
    return reasons


def run_hidden_reasons(run, para=None) -> list:
    """run 级隐藏原因；直接格式未设置时按段落样式字体继承判断（样式级白字/隐藏同样不可见）。"""
    r = _font_hidden_reasons(getattr(run, "font", None))
    if r:
        return r
    if para is not None:
        try:
            style = getattr(para, "style", None)
            r2 = _font_hidden_reasons(getattr(style, "font", None)) if style is not None else []
            if r2:
                return r2
        except Exception as _e:
            logging.getLogger(__name__).debug("hidden style inherit probe failed: %s", _e)
    return []


def _hidden_text_info(anchor: str, chars: int, reasons: list) -> dict:
    """隐藏文本结构化留痕：不落正文（防止把攻击载荷复制进解析报告/DB）。"""
    return {"kind": "hidden_text", "provenance": "hidden_text", "anchor": str(anchor),
            "chars": int(chars), "reasons": sorted(set(reasons or []))}


def _visible_run_text(run, para, skipped, anchor, acc) -> str:
    """单个 run 的可见文本（隐藏 run 只累计留痕，不返回文本）。"""
    t = run.text or ""
    if not t:
        return ""
    _r = run_hidden_reasons(run, para)
    if _r:
        acc["chars"] += len(t)
        acc["reasons"].update(_r)
        return ""
    return t


def visible_paragraph_text(para, anchor: str = "", skipped: list | None = None,
                           revisions: list | None = None) -> str:
    """段落可见文本：跳过隐藏 run；隐藏部分只记位置/字符数/原因摘要（不复制正文）。

    L154（2026-11-25）修订语义（L137 C2）：w:ins（作者已提交的插入）按「接受修订后的
    生效文本」可见；w:del（被删除内容）不作为证据、不进入正文，只写 revisions 通道标注。
    `revisions` 传入列表时收集结构化标注（作者/时间/文本/是否隐藏），不改变正文口径。
    """
    chunks, acc = [], {"chars": 0, "reasons": set()}

    def _append_run(run):
        t = _visible_run_text(run, para, skipped, anchor, acc)
        if t:
            chunks.append(t)
            return t
        return ""

    try:
        from docx.oxml.ns import qn
        from docx.text.run import Run
        _run_tag, _ins_tag, _del_tag = qn("w:r"), qn("w:ins"), qn("w:del")
        _move_to, _move_from = qn("w:moveTo"), qn("w:moveFrom")
        _structured = True
    except Exception:  # noqa: BLE001 - python-docx 不可用：退化旧口径
        _structured = False
    if _structured:
        _p_el = getattr(para, "_p", None)
        for child in (list(_p_el) if _p_el is not None else []):
            tag = child.tag
            if tag == _run_tag:
                _append_run(Run(child, para))
            elif tag in (_ins_tag, _move_to):
                # 接受修订 → 插入文本可见（含嵌套 run）；隐藏 run 仍按守卫跳过
                parts = []
                try:
                    author = str(child.get(qn("w:author")) or "")
                    date = str(child.get(qn("w:date")) or "")
                except Exception:  # noqa: BLE001
                    author, date = "", ""
                for run_el in child.iter(_run_tag):
                    t = _append_run(Run(run_el, para))
                    if t:
                        parts.append(t)
                if revisions is not None:
                    revisions.append({
                        "kind": "insert",
                        "action": "accepted_visible",
                        "author": author, "date": date,
                        "anchor": str(anchor),
                        "text": "".join(parts)[:400],
                        "chars": len("".join(parts)),
                        "evidence_allowed": True,
                    })
            elif tag in (_del_tag, _move_from):
                # 删除修订：不是生效文本 → 不进入正文；只留结构化标注（不复制为证据）
                deleted = ""
                try:
                    deleted = "".join(
                        str(t.text or "") for t in child.iter(qn("w:delText")))
                    author = str(child.get(qn("w:author")) or "")
                    date = str(child.get(qn("w:date")) or "")
                except Exception:  # noqa: BLE001
                    author, date = "", ""
                if revisions is not None:
                    revisions.append({
                        "kind": "delete",
                        "action": "ignored_as_evidence",
                        "author": author, "date": date,
                        "anchor": str(anchor),
                        "text": deleted[:400],
                        "chars": len(deleted),
                        "evidence_allowed": False,
                    })
    else:
        for run in (getattr(para, "runs", None) or []):
            _append_run(run)
    if acc["chars"]:
        if skipped is not None:
            skipped.append(_hidden_text_info(str(anchor), acc["chars"],
                                             list(acc["reasons"])))
        # 逐段明细走 debug（避免白字较多的正常文档刷屏）；文档级汇总由各解析入口 warning 留痕
        logging.getLogger(__name__).debug(
            "docx 跳过隐藏文本：anchor=%s chars=%d reasons=%s",
            anchor, acc["chars"], sorted(acc["reasons"]))
    return "".join(chunks).strip()


def visible_cell_text(cell, anchor: str = "", skipped: list | None = None,
                      revisions: list | None = None) -> str:
    """表格单元格可见文本：逐段落跳过隐藏 run（修订语义同段落，L154 C2）。"""
    parts = []
    for pi, p in enumerate(getattr(cell, "paragraphs", None) or []):
        t = visible_paragraph_text(p, f"{anchor}/p{pi + 1}", skipped, revisions)
        if t:
            parts.append(t)
    return "\n".join(parts)


def docx_hidden_text_scan(path: str) -> list:
    """预扫 docx 隐藏文本（仅统计，不写日志）：用于决定是否绕开 docling 增强路径。

    增强路径（docling 等）只回文本、拿不到 run 级格式；guard 开且预扫命中隐藏文本时，
    解析改走 python-docx 格式感知路径，保证跳过逻辑生效（增强路径无隐藏文本时保持原样）。
    """
    skipped = []
    try:
        from docx import Document
        d = Document(path)
    except Exception:
        return skipped
    for i, para in enumerate(d.paragraphs):
        for run in (getattr(para, "runs", None) or []):
            if not (run.text or ""):
                continue
            _r = run_hidden_reasons(run, para)
            if _r:
                skipped.append(_hidden_text_info(f"段落{i + 1}", len(run.text), _r))
    for ti, table in enumerate(d.tables, 1):
        for ri, row in enumerate(table.rows, 1):
            for ci, cell in enumerate(row.cells, 1):
                for pi, p in enumerate(getattr(cell, "paragraphs", None) or []):
                    for run in (getattr(p, "runs", None) or []):
                        if not (run.text or ""):
                            continue
                        _r = run_hidden_reasons(run, p)
                        if _r:
                            skipped.append(_hidden_text_info(
                                f"表{ti} R{ri}C{ci}/p{pi + 1}", len(run.text), _r))
    return skipped


# ---- L43（2026-11-24）：docx 页眉/页脚进入解析结果 ------------------------------
# 背景：docs/qa/L36_解析陷阱平台实测_20261123.md —— 40/40 份 docx 的页眉 `卷号`
# 全部漏抽（平台 docx section 只有段落+表格，header/footer 不可见）；这是 L36 唯一
# 硬缺口（docx 字段准确率 50%）。页眉/页脚是真实业务文档（卷号/版本/日期/页码/编号）
# 的常见载体，解析层必须给出**可定位**的文本与事实，供规则/证据门禁消费。
# 设计约束（不改变既有语义）：
#   · 只新增 section（kind=header/footer），正文段落/表格的 section 顺序与文本逐字不变；
#   · 只新增 Fact 的 source 元数据（section_kind / char_start / char_end），正文 fact 取值不变；
#   · 隐藏文本守卫（RULEPROOF_HIDDEN_TEXT_GUARD）同样作用于页眉/页脚 run；
#   · 同一 header/footer 容器只产出 1 个 section（段落 + 表格行按序拼接），
#     linked-to-previous 的容器跳过（避免多 section 文档重复计入）。
# 回退：RULEPROOF_DOCX_HEADER_FACTS=0 → 逐字恢复旧行为（只解析 paragraphs + tables）。
def docx_header_facts_enabled() -> bool:
    """RULEPROOF_DOCX_HEADER_FACTS（默认 1）：docx 页眉/页脚文本进入 sections/text/facts。"""
    return str(os.environ.get("RULEPROOF_DOCX_HEADER_FACTS", "1")).strip().lower() not in (
        "0", "false", "no", "off")


# (python-docx 属性, 锚点前缀, Section.kind, 锚点后缀)
_DOCX_HF_VARIANTS = (
    ("header", "页眉", "header", ""),
    ("footer", "页脚", "footer", ""),
    ("first_page_header", "页眉", "header", "-首页"),
    ("first_page_footer", "页脚", "footer", "-首页"),
    ("even_page_header", "页眉", "header", "-偶数页"),
    ("even_page_footer", "页脚", "footer", "-偶数页"),
)


def _docx_hf_block_texts(hf, anchor: str, guard_on: bool, skipped: list | None) -> list:
    """页眉/页脚容器 → 可见文本块列表（段落按序 + 表格行按序，表格行内用 ' | '）。"""
    texts = []
    try:
        paras = list(getattr(hf, "paragraphs", None) or [])
    except Exception as _e:  # 格式探测失败不阻断解析，但留 debug
        logging.getLogger(__name__).debug("docx hf paragraphs probe failed: %s", _e)
        paras = []
    for pi, para in enumerate(paras):
        if guard_on:
            t = visible_paragraph_text(para, f"{anchor}/p{pi + 1}", skipped)
        else:
            t = (para.text or "").strip()
        if t:
            texts.append(_clean_line(t))
    try:
        tables = list(getattr(hf, "tables", None) or [])
    except Exception as _e:
        logging.getLogger(__name__).debug("docx hf tables probe failed: %s", _e)
        tables = []
    for ti, table in enumerate(tables, 1):
        for ri, row in enumerate(table.rows, 1):
            row_cells = []
            for ci, cell in enumerate(row.cells, 1):
                if guard_on:
                    row_cells.append(visible_cell_text(
                        cell, f"{anchor}/表{ti} R{ri}C{ci}", skipped).strip())
                else:
                    row_cells.append((cell.text or "").strip())
            if any(row_cells):
                texts.append(_clean_line(" | ".join(row_cells)))
    return texts


def _docx_header_footer_sections(doc, guard_on: bool, skipped: list | None) -> list:
    """docx 页眉/页脚 → Section(kind=header/footer)；空块/继承上一节链接的容器不产出。"""
    out = []
    try:
        secs = list(getattr(doc, "sections", None) or [])
    except Exception as _e:
        logging.getLogger(__name__).warning("docx sections probe failed: %s", _e)
        return out
    _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
    for si, sec in enumerate(secs, 1):
        for attr, prefix, kind, suffix in _DOCX_HF_VARIANTS:
            try:
                hf = getattr(sec, attr)
            except Exception as _e:
                logging.getLogger(__name__).debug("docx hf probe %s failed: %s", attr, _e)
                continue
            if hf is None:
                continue
            # linked-to-previous：内容继承自上一节，已在上一节产出，不重复计入
            try:
                if getattr(hf, "is_linked_to_previous", False):
                    continue
            except Exception as _e:
                logging.getLogger(__name__).debug("docx hf linked probe failed: %s", _e)
                continue
            anchor = f"{prefix}{si}{suffix}"
            texts = _docx_hf_block_texts(hf, anchor, guard_on, skipped)
            if not texts:
                continue
            out.append(Section(kind, "\n".join(texts), anchor, **_kw))
    return out


def _assign_section_spans(sections: list) -> str:
    """给 sections 填 char_start/char_end（ParsedDoc.text 内区间），返回拼接后的 text。

    只填元数据，不改 section 顺序/文本；正文事实逐字不变（L43 正文不回归判据）。
    """
    parts, pos = [], 0
    for i, sec in enumerate(sections):
        if i:
            pos += 1          # 分隔符 '\n'
        sec.char_start = pos
        pos += len(sec.text)
        sec.char_end = pos
        parts.append(sec.text)
    return "\n".join(parts)


def _header_footer_evidence(format_: str, enabled: bool, n_sections: int,
                            switch_env: str, reason_none: str) -> dict:
    """页眉/页脚证据状态（docx/xlsx 用；PDF 由 _pdf_header_footer_evidence 产出）。

    L116：state=none（识别不到）与 no_text_layer 都是「证据不足」——字段缺失是解析层
    证据缺口，上层不得默认放行；switch=off 是显式回退（A/B、回滚），同样不产生证据。
    """
    if not enabled:
        return {"format": format_, "switch": "off", "state": "disabled",
                "sufficient": False,
                "reason": f"{switch_env}=0（回退旧行为：不解析页眉/页脚）",
                "sections": 0, "pages": 0}
    if n_sections:
        return {"format": format_, "switch": "on", "state": "found", "sufficient": True,
                "reason": "", "sections": int(n_sections), "pages": 0}
    return {"format": format_, "switch": "on", "state": "none", "sufficient": False,
            "reason": reason_none, "sections": 0, "pages": 0}


def extract_facts(text: str, anchor: str = "", provenance=None) -> list:
    """通用事实抽取：不假设行业，抽「数值+量纲 / 范围 / 阈值 / 日期 / 版本 / 编号 / 占位符」。

    L144 T-⑤a（2026-11-25）在事实层新增数字/单位写法归一（规格 N1–N10）：
      · 匹配在 NFKC 文本上做（全角数字/㎏/％/℉ 归一），raw 原文 + char span 保留回指；
      · value 必须 ASCII 十进制；千分位/欧洲小数/负号变体/`.5` 正确归一；
      · 歧义数字（如 `2,5` 单逗号 1 位）不猜：value 空、raw 保留、confidence=0、ambiguous=True；
      · 单位登记表扩容；未登记单位 → unit_unknown=True、confidence=0（不猜量纲）；
      · 不在此层做量纲换算（N10），source='text_layer' 由 provenance 字段表达。

    provenance（TL-5）：来源段落/页的 provenance（Section 或 dict）。每条事实带
    ocr_engine / ocr_tier / vision_advisory；数值事实来源为 vision 或未知时
    evidence_source='vision_advisory'（缺口径时按未知处理，不默认安全）。
    不传 provenance = 未知来源（老调用方行为：字段为空/None，不改变抽取内容）。
    """
    from . import hooks as _hk
    src_text = str(text or "")
    ntext, omap = _nfkc_with_map(src_text)

    facts = []

    def _mk(kind, value, unit, start, end, *, raw="", raw_start=None, raw_end=None,
            ambiguous=False, unit_unknown=False, confidence=1.0, extra_object_at=None):
        # char span 语义（O3）与既有消费者一致：指向 **value 数值本身**（如 "85"），
        # 不含单位；raw 保留完整原文写法（如 "1,200 mg/kg"/"85℃"）用于引文回指。
        o_start, o_end = _orig_span(omap, start, end)
        rs = start if raw_start is None else raw_start
        re_ = end if raw_end is None else raw_end
        ro_start, ro_end = _orig_span(omap, rs, re_)
        obj_at = start if extra_object_at is None else extra_object_at
        f = Fact(kind, value, unit,
                 _object_of(ntext, obj_at),
                 src_text[max(0, o_start - 12):(o_end + 8 if o_end >= 0 else 0)]
                 if o_start >= 0 else "",
                 anchor)
        f.char_start, f.char_end = o_start, o_end
        f.raw = (src_text[ro_start:ro_end] if ro_start >= 0 else "") or raw
        f.value_ascii = bool(value) and str(value).isascii() and _is_ascii_decimal(value)
        f.confidence = float(confidence)
        f.ambiguous = bool(ambiguous)
        f.unit_unknown = bool(unit_unknown)
        f.normalized = bool(raw and f.raw and f.raw != value)
        return f

    def _num_fact(kind, num, unit, unit_unknown, start, token_end, unit_end):
        """由 _parse_number_token 结果 + 单位构造数值事实（歧义/未知单位 fail-closed）。

        char span = 数值 token（与旧行为/证据定位口径一致）；raw = 原文完整写法。
        """
        if num.get("ambiguous"):
            return _mk(kind if kind != "num" else "num", "", "", start, token_end,
                       raw=num.get("raw") or "", raw_start=start, raw_end=unit_end,
                       ambiguous=True, confidence=0.0)
        conf = 0.0 if unit_unknown else 1.0
        return _mk(kind, num["value"], unit, start, token_end, raw=num.get("raw") or "",
                   raw_start=start, raw_end=unit_end,
                   unit_unknown=unit_unknown, confidence=conf)

    # 0) 日期/版本/编号/占位符：沿用旧口径（在 NFKC 文本上匹配，value 取归一后写法）
    non_num_spans = []
    for kind, pat in _NON_NUM_PATTERNS:
        for m in pat.finditer(ntext):
            non_num_spans.append((m.start(), m.end()))
            if kind == "date":
                y, mo, d = m.group(1), m.group(2), m.group(3)
                try:
                    val = datetime(int(y), int(mo), int(d)).strftime("%Y-%m-%d")
                except Exception:
                    val = f"{y}-{mo}-{d}"
                facts.append(_mk("date", val, "", m.start(), m.end(), raw=m.group(0)))
            else:
                facts.append(_mk(kind, m.group(1), "", m.start(1), m.end(1),
                                 raw=m.group(1)))

    def _overlaps(span):
        return any(span[0] < e and span[1] > s for s, e in non_num_spans)

    # 1) 区间（N5：0-8℃ 不能解析成负值；日期/版本内的 "-" 不当区间）
    range_spans = []
    for m in _RANGE_RE.finditer(ntext):
        if _overlaps((m.start(), m.end())):
            continue
        lo = _parse_number_token(m.group("lo"))
        hi = _parse_number_token(m.group("hi"))
        if lo.get("ambiguous") or hi.get("ambiguous"):
            f = _mk("range", "", (m.group("sep") or "").strip(), m.start(), m.end(),
                    raw=m.group(0), ambiguous=True, confidence=0.0)
            facts.append(f)
        else:
            uinfo = _match_unit(ntext, m.end("hi"))
            unit = unit_unknown = False
            unit_txt = ""
            end = m.end()
            if uinfo:
                kind_u, canon_u, end, _ru = uinfo
                unit_txt = canon_u
            else:
                um = _match_unknown_unit(ntext, m.end("hi"))
                if um:
                    unit_txt, end = um[0], um[1]
                    unit_unknown = True
            f = _mk("range", f"{lo['value']}~{hi['value']}", unit_txt,
                    m.start("lo"), m.end("hi"), raw=m.group(0),
                    raw_start=m.start(), raw_end=end,
                    unit_unknown=unit_unknown,
                    confidence=0.0 if unit_unknown else 1.0)
            facts.append(f)
        range_spans.append((m.start(), m.end()))

    # 2) 比较符（保留旧行为：≥85℃ 既产出 compare，也产出 temp 数值事实）
    compare_spans = []
    for m in _COMPARE_RE.finditer(ntext):
        num = _parse_number_token(m.group("num"))
        uinfo = _match_unit(ntext, m.end("num"))
        unit_txt, unit_unknown, end, unit_kind = "", False, m.end("num"), "num"
        if uinfo:
            unit_kind, canon_u, end, _ru = uinfo
            unit_txt = canon_u
        else:
            um = _match_unknown_unit(ntext, m.end("num"))
            if um:
                unit_txt, end = um[0], um[1]
                unit_unknown = True
        op = (m.group("op") or "").strip()
        if num.get("ambiguous"):
            f = _mk("compare", "", unit_txt, m.start(), end, raw=m.group(0),
                    ambiguous=True, confidence=0.0)
        else:
            f = _mk("compare", f"{op}{num['value']}", unit_txt,
                    m.start("num"), m.end("num"), raw=m.group(0),
                    raw_start=m.start(), raw_end=end,
                    unit_unknown=unit_unknown,
                    confidence=0.0 if unit_unknown else 1.0)
        facts.append(f)
        compare_spans.append((m.start(), m.end()))

    # 2b) 歧义数字（N4：逗号+1 位等无法判定位数的写法）→ 保留 raw + confidence=0，不猜。
    #     例："2,5 kg" 可能是 2.5 或 25（千分位不完整）；不得改写为 2 或 5 再取单位。
    ambiguous_spans = []
    for m in _AMBIG_NUM_RE.finditer(ntext):
        start, end_tok = m.start(), m.end()
        if _overlaps((start, end_tok)):
            continue
        num = _parse_number_token(m.group("tok"))
        uinfo = _match_unit(ntext, end_tok)
        unit_txt, end = "", end_tok
        kind = "num"
        if uinfo:
            kind, unit_txt, end, _ru = uinfo
        f = _mk(kind, "", unit_txt, start, end_tok, raw="", raw_start=start,
                raw_end=end, ambiguous=True, confidence=0.0)
        f.raw = src_text[_orig_span(omap, start, end)[0]:_orig_span(omap, start, end)[1]] \
            if _orig_span(omap, start, end)[0] >= 0 else m.group("tok")
        facts.append(f)
        ambiguous_spans.append((start, end))

    # 3) 数值 + 单位（主路径）
    for m in _NUMISH_RE.finditer(ntext):
        start, end_num = m.start(), m.end()
        if _overlaps((start, end_num)):
            continue
        if any(start < e and end_num > s0 for s0, e in ambiguous_spans):
            continue
        # 区间内的数字不再单独产出（避免把 0-8℃ 的右端点当独立事实）
        in_range = any(start < re_ and end_num > rs for rs, re_ in range_spans)
        num = _parse_number_token(m.group(0))
        uinfo = _match_unit(ntext, end_num)
        if in_range:
            # 区间内的端点不再单独产出（避免把 0-8℃ 的右端点当独立事实）
            continue
        if uinfo:
            kind, canon, end, _ru = uinfo
            facts.append(_num_fact(kind, num, canon, False, start, end_num, end))
            continue
        # N8：未登记单位（保守：0–1 空格 + 1–5 位 ASCII/希腊单位 token）
        um = _match_unknown_unit(ntext, end_num)
        if um:
            facts.append(_num_fact("num", num, um[0], True, start, end_num, um[1]))
            continue
        # 纯数字无单位：旧行为不产出数值事实（只有 compare/range 才带无单位数值）

    # TL-5：逐条事实落 provenance（数值事实来源 vision/未知 → evidence_source 留痕）
    _fields = _hk.fact_provenance_fields(provenance)
    # L43：来源 section 类型（页眉/页脚事实可据此区段消歧；正文=paragraph/heading/table）
    if isinstance(provenance, dict):
        _prov_kind = str(provenance.get("kind") or "")
    elif provenance is not None:
        _prov_kind = str(getattr(provenance, "kind", "") or "")
    else:
        _prov_kind = ""
    for f in facts:
        f.ocr_engine = str(_fields.get("ocr_engine") or "")
        f.ocr_tier = str(_fields.get("ocr_tier") or "")
        f.vision_advisory = _fields.get("vision_advisory")
        f.evidence_source = ""
        f.section_kind = _prov_kind
    for f in facts:
        if _hk.fact_is_numeric(f) and _hk.fact_provenance(f) != "trusted":
            f.evidence_source = "vision_advisory"
    return facts



# ---- L144 T-⑤a（2026-11-25）：跨页/断行数字拼回（N9，保守） ------------------
# 只在「上一块以数值/比较符结尾」且「下一块整块是数值+登记单位」时拼接，且：
#   · 上一块尾部数字的前缀必须以中文/比较符/冒号结尾（排除 PF-001 / V1.2 这类编号尾数）；
#   · 下一块允许 markdown 列表符号（"- 88℃"）；
#   · 不跨页眉/页脚 section 拼接；
#   · 每次拼接写 numeric_joins 证据（before/fragment/joined/anchor），不静默。
_JOIN_BULLET_RE = re.compile(r"^[-*+]\s+")
_JOIN_NEXT_RE = re.compile(
    r"^(?P<num>(?:\d[\d.,]*\d|\d|\.\d+))\s*(?P<unit>" + _UNIT_ALT + r")$", re.I)
_JOIN_TAIL_NUM_RE = re.compile(r"(?P<num>(?:\d[\d.,]*\d|\d|\.\d+))\s*$")
_JOIN_TAIL_OP_RE = re.compile(r"(?:[≥≤<>]|不小于|不大于|不低于|不高于)\s*$")


def _join_prev_kind(text: str) -> str:
    """上一块是否以可拼接的「比较符 / 数值片段」结尾；返回 op/num/''。"""
    t = str(text or "").rstrip()
    if not t:
        return ""
    if _JOIN_TAIL_OP_RE.search(t):
        return "op"
    m = _JOIN_TAIL_NUM_RE.search(t)
    if not m:
        return ""
    prefix = t[:m.start("num")].rstrip()
    if not prefix:
        return "num"
    last = prefix[-1]
    if last in "≥≤<>:：，,、；;（(第至到":
        return "num"
    if re.match(r"[\u4e00-\u9fff]", last):
        return "num"
    return ""


def _apply_numeric_joins(sections: list) -> list:
    """保守拼回断行数字；就地替换 sections 并返回拼回证据列表（N9）。"""
    if not sections:
        return []
    out, joins = [], []
    i, n = 0, len(sections)
    while i < n:
        cur = sections[i]
        if i + 1 < n and cur.kind not in ("header", "footer"):
            nxt = sections[i + 1]
            kind = _join_prev_kind(cur.text)
            frag = _JOIN_BULLET_RE.sub("", str(nxt.text or "").strip()) if nxt.kind not in (
                "header", "footer") else ""
            # 单位写法需 NFKC 后再匹配（℃→°C、㎏→kg、℉→°F），拼接文本保留原文
            frag_norm = unicodedata.normalize("NFKC", frag) if frag else ""
            m = _JOIN_NEXT_RE.match(frag_norm) if (kind and frag_norm) else None
            if m:
                joined = str(cur.text).rstrip() + frag
                out.append(Section(cur.kind, joined, cur.anchor,
                                   ocr_engine=cur.ocr_engine, ocr_tier=cur.ocr_tier,
                                   vision_advisory=cur.vision_advisory,
                                   char_start=cur.char_start, char_end=cur.char_end))
                joins.append({"anchor": cur.anchor, "next_anchor": nxt.anchor,
                              "before": str(cur.text), "fragment": str(nxt.text),
                              "joined": joined, "unit": m.group("unit")})
                i += 2
                continue
        out.append(cur)
        i += 1
    if joins:
        sections[:] = out
    return joins


# ---------------------------------------------------------------- Markdown 格式伪影清洗（B1-L1 T02）
# 背景（docs/qa/食品缺陷修复_20261123.md）：工艺书 md 经平台解析后，
#   ① 粗体标记 `**` 被当作字段值的一部分（如「版本号：DR-2026-V1**」），
#   ② 同一行用全角空格串起来的多个「标签：值」（如「版本号：V1　实施日期：D1　商品名：N」）
#      被跨 Sheet 一致性判据当成**一个**字段值 → 与表格行的干净取值比对得到「2 种取值」→ 误报；
#   ③ 行内多个单元格被压成「每 token 一行」（旧 `_parse_md` 的 `"\n".join(raw.split())`），
#      「标签 | 值」不再同一行，确定性表头判据取不到值（漏检/口径不稳）。
# 本清洗只做**格式层归一**，不改变正文语义：
#   · 移除成对 `**`/`__` 强调标记（强调不承载业务语义；落单标记一并清除）；
#   · 把全角空格分隔的「值 + 下一个 标签：」边界规范为平台的单元格分隔符「 | 」；
#   · `_parse_md` 保留原始行结构（不再按空白 token 撕裂字段行）。
# 开关：RULEPROOF_MD_ARTIFACT_CLEAN=0 → 回退旧解析行为（逐字兼容，供回滚/对照）。
_MD_BOLD_RE = re.compile(r"\*\*(.+?)\*\*", re.S)
_MD_UNDERSCORE_RE = re.compile(r"(?<![0-9A-Za-z])__(.+?)__(?![0-9A-Za-z])", re.S)
_FIELD_RUN_SEP_RE = re.compile(r"(?<=\S)\u3000(?=[^\u3000：:|｜]{1,14}[：:])")


def _md_artifact_clean_on() -> bool:
    return str(os.environ.get("RULEPROOF_MD_ARTIFACT_CLEAN", "1")).strip().lower() \
        not in ("0", "false", "off", "no")


def _clean_markdown_line(line: str) -> str:
    """Markdown 行格式伪影清洗（只删格式标记/规范分隔符，不改正文内容与顺序）。"""
    s = str(line or "")
    if not s:
        return s
    s = _MD_BOLD_RE.sub(r"\1", s)
    s = _MD_UNDERSCORE_RE.sub(r"\1", s)
    s = s.replace("**", "")          # 落单粗体标记（成对已还原）不参与取数
    s = _FIELD_RUN_SEP_RE.sub(" | ", s)
    return s


def _clean_line(line: str) -> str:
    return _clean_markdown_line(line) if _md_artifact_clean_on() else line


# ---------------------------------------------------------------- 解析能力（可插拔：Docling/MinerU/pymupdf → pypdf 兜底）
def _parse_pdf_enhanced(path: str):
    """尝试 Docling/MinerU/pymupdf；不可用返回 None。"""
    # Docling
    try:
        from docling.document_converter import DocumentConverter
        res = DocumentConverter().convert(path)
        md = res.document.export_to_markdown()
        if md and md.strip():
            return md
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    # pymupdf
    try:
        import fitz
        doc = fitz.open(path)
        txt = "\n".join(page.get_text() for page in doc)
        doc.close()
        if txt.strip():
            return txt
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    return None


# ---------------------------------------------------------------- 统一解析
def parse_document(path: str) -> ParsedDoc:
    """统一解析入口（主链文本来源）。

    L144 T-⑤a（2026-11-25）fail-closed：
      · 未知扩展名/图片（png/jpg/...）不再返回空 ParsedDoc(parse_status=ok)，一律
        parse_status=failed + status_reason=unsupported_format（L137 I5/FC1）；
      · 任何解析异常 → failed + status_reason（FC2，禁止异常吞掉当成功）；
      · 支持格式但 0 文本/0 结构块 → failed + empty_document（禁止 ok+空文本）。
    """
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    try:
        if ext == "docx":
            doc = _parse_docx(path)
        elif ext == "pdf":
            doc = _parse_pdf(path)
        elif ext in ("xlsx", "xls"):
            doc = _parse_xlsx(path)
        elif ext in ("md", "markdown", "txt"):
            doc = _parse_md(path)
        else:
            return ParsedDoc(path, ext or "unknown", [], "", parse_status="failed",
                             status_reason=(
                                 f"unsupported_format: .{ext or '(无扩展名)'} 不在确定性解析"
                                 "白名单（xlsx/docx/pdf/md/txt）；图片/扫描件请转 PDF 或走 "
                                 "OCR 专用入口。禁止返回 ok+空文本（L137 I5/FC1）"))
    except Exception as e:  # noqa: BLE001 - L137 FC2：解析异常必须落 failed，不静默
        logging.getLogger(__name__).warning("deepparse parse failed ext=%s", ext,
                                            exc_info=True)
        return ParsedDoc(path, ext or "unknown", [], "", parse_status="failed",
                         status_reason=f"parse_exception: {type(e).__name__}: {str(e)[:200]}")
    if doc.parse_status == "ok" and not str(doc.text or "").strip():
        doc.parse_status = "failed"
        doc.status_reason = ("empty_document: 支持格式但未提取到任何文本/结构块"
                             "（不返回 ok+空文本；L137 FC1/FC10）")
    # L154：结构 IR 明确「表格不能重建」时不得报 ok（L137 T10/FC6：不假装）
    _ir = doc.ir_summary or {}
    _unsupported = list(_ir.get("unsupported_tables") or [])
    if doc.parse_status == "ok" and _unsupported:
        doc.parse_status = "partial"
        _tr = (_ir.get("table_detection") or {}).get("reasons") or []
        doc.status_reason = (
            "table_structure_partial: 以下表结构不能可靠重建（table_supported=false）："
            + ",".join(str(x) for x in _unsupported[:5])
            + (("；" + "；".join(str(x) for x in _tr[:2])) if _tr else "")
            + "（该表证据不得用于确定性判定；L137 T10/FC6）")[:500]
    return doc


def _parse_md(path: str) -> ParsedDoc:
    """Markdown/纯文本：按标题与段落切块，保留原页定位（如「原页16」）。"""
    import re as _re
    try:
        raw = open(path, encoding="utf-8", errors="ignore").read()
    except Exception as e:  # noqa: BLE001 - 读取失败必须落 failed（L137 FC2）
        return ParsedDoc(path, "md", [], "", parse_status="failed",
                         status_reason=f"read_error: {type(e).__name__}: {str(e)[:200]}")
    sections = []
    page = ""
    idx = 0
    _clean_on = _md_artifact_clean_on()
    lines = []
    for line in raw.splitlines():
        t = line.strip()
        if not t:
            continue
        idx += 1
        if _clean_on:
            t = _clean_markdown_line(t)
        lines.append(t)
        m = _re.search(r"原页\s*(\d+)", t)
        if m:
            page = f"原页{m.group(1)}"
        if t.startswith("#"):
            kind = "heading"
        else:
            kind = "paragraph"
        sections.append(Section(kind, t, page or f"段{idx}",
                                **_section_prov_kwargs(_TEXT_LAYER_PROV)))
    # 旧实现 `"\n".join(raw.split())` 会把每个空白 token 拆成一行，字段行
    # 「版本号：V1　实施日期：D1」被撕裂 → 表头/一致性确定性判据取不到值。
    # B1-L1 T02：保留行结构（清洗后）；开关关闭时逐字回退旧口径。
    if _clean_on:
        joins = _apply_numeric_joins(sections)      # L144 N9：断行数字拼回（保守）
        text = "\n".join(s.text for s in sections)   # 与 sections 一致（拼回后重新拼文本）
    else:
        # 开关关闭时逐字回退旧文本口径（不拼回、不改变 raw.split 文本），保证回滚一致性。
        joins = []
        text = "\n".join(raw.split())
    return ParsedDoc(path, "md", sections, text, numeric_joins=joins)


# ---- L144 T-⑤a：docx 表格单元格（T3 空占位 / T4 合并 span+续行标记） --------
def _docx_tc_grid_span(tc) -> int:
    """w:tc 的横向合并 span（w:gridSpan/@w:val），无则 1。"""
    try:
        pr = getattr(tc, "tcPr", None)
        if pr is None:
            return 1
        from docx.oxml.ns import qn
        g = pr.find(qn("w:gridSpan"))
        if g is None:
            return 1
        return max(1, int(g.get(qn("w:val")) or 1))
    except Exception:  # noqa: BLE001 - 格式探测失败按无合并处理，不阻断解析
        logging.getLogger(__name__).debug("docx gridSpan probe failed", exc_info=True)
        return 1


def _docx_tc_vmerge(tc) -> str:
    """w:tc 的纵向合并状态：'restart' / 'continue' / ''（无合并）。"""
    try:
        pr = getattr(tc, "tcPr", None)
        if pr is None:
            return ""
        from docx.oxml.ns import qn
        v = pr.find(qn("w:vMerge"))
        if v is None:
            return ""
        return str(v.get(qn("w:val")) or "continue")
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("docx vMerge probe failed", exc_info=True)
        return ""


def _docx_table_row_cells(table, table_idx: int, ri: int, tr, guard_on: bool,
                          skipped: list, revisions: list | None = None) -> tuple:
    """docx 表格行 → (按 grid 列展开的 cells, 合并续行标记, 横向 span 数, 单元格结构)。

    T3：空单元格保留占位（不左移）；T4：gridSpan 展开为「首格值 + 空占位」，
    vMerge=continue 的续行不重复逻辑值、写 merged_from 审计（结构化显式标记）。
    L154（2026-11-25）：第 4 项返回逐 grid 列的单元格结构（col/text/colspan/merged_from），
    供 document_ir 建 Cell/Row（不改变前 3 项与正文 section 文本口径）。
    """
    from docx.table import _Cell
    cells, conts, structs = [], [], []
    spans = 0
    for tc in (getattr(tr, "tc_lst", None) or []):
        cell = _Cell(tc, table)
        if guard_on:
            text = visible_cell_text(
                cell, f"表{table_idx} R{ri}C{len(cells) + 1}", skipped,
                revisions).strip()
        else:
            text = (cell.text or "").strip()
        gs = _docx_tc_grid_span(tc)
        vm = _docx_tc_vmerge(tc)
        col = len(cells) + 1
        if vm == "continue":
            cells.append("")          # 续行不重复逻辑值（T4）
            conts.append({"table": table_idx, "row": ri, "col": col,
                          "merged_from_row": max(1, ri - 1), "merged_from_col": col,
                          "reason": "vmerge_continue"})
            structs.append({"col": col, "text": "", "colspan": 1,
                            "merged_from": {"row": max(1, ri - 1), "col": col},
                            "source": "merged"})
        else:
            cells.append(text)
            structs.append({"col": col, "text": text, "colspan": gs,
                            "merged_from": None, "source": "text_layer"})
        spans += gs - 1
        for k in range(gs - 1):
            cells.append("")          # 横向合并占位（T4：不得重复逻辑值）
            structs.append({"col": col + k + 1, "text": "", "colspan": 1,
                            "merged_from": {"row": ri, "col": col},
                            "source": "merged"})
    return cells, conts, spans, structs


def _docx_body_image_count(doc) -> int:
    """正文内嵌图片数（inline shapes + w:drawing/w:pict 元素；用于图片型文档 fail-closed）。"""
    n = 0
    try:
        n = len(getattr(doc, "inline_shapes", []) or [])
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("docx inline_shapes probe failed", exc_info=True)
    try:
        from docx.oxml.ns import qn
        body = doc.element.body
        n = max(n, len(body.findall(".//" + qn("w:drawing")))
                + len(body.findall(".//" + qn("w:pict"))))
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("docx body drawing probe failed", exc_info=True)
    return int(n)

# ---- L154（2026-11-25）：docx 结构 IR（表/行/单元格 + 嵌套表） ----------------
def _docx_nested_ir_table(table, table_id: str, guard_on: bool,
                          skipped: list, parent_id: str = "",
                          parent_row: int = 0, parent_col: int = 0,
                          depth: int = 1) -> "_dir.Table":
    """docx 嵌套表 → IR Table（结构可见；正文 text 不含嵌套表文本 → text_in_document=False）。

    嵌套表单元格文本不进入 `ParsedDoc.text/sections`（保持既有正文口径不回归），但结构、
    行列、单元格文本在 IR 中完整可见并通过 `nested_table_ids` 与父单元格关联——不静默丢失。
    """
    t = _dir.Table(table_id=table_id, doc_type="docx", anchor=parent_id or table_id,
                   page_available=False, source="text_layer", confidence=1.0,
                   table_supported=True, status="ok")
    t.notes.append("nested_table_text_not_in_body")
    if parent_id:
        t.notes.append(f"parent={parent_id} R{parent_row}C{parent_col}")
    rows = []
    for ri, tr in enumerate(getattr(table._tbl, "tr_lst", []) or []):
        row_cells, _conts, _spans, structs = _docx_table_row_cells(
            table, 0, ri + 1, tr, guard_on, skipped)
        if not any(row_cells):
            continue
        cells = []
        for st in structs:
            cells.append(_dir.new_cell(
                st.get("text", ""), row=ri + 1, col=int(st.get("col") or 0),
                table_id=table_id,
                colspan=max(1, int(st.get("colspan") or 1)),
                merged_from=(dict(st["merged_from"]) if st.get("merged_from") else None),
                source=("merged" if st.get("merged_from") else "text_layer"),
                confidence=1.0 if st.get("text") else 0.9,
                text_in_document=False))
        rows.append(_dir.Row(row=ri + 1, page=None, cells=cells,
                             source_lines=[" ".join(row_cells)]))
    t.rows = rows
    header_pos = _dir.detect_header_rows([[c.text for c in r.cells] for r in rows])
    t.header_rows = [rows[i - 1].row for i in header_pos]
    for i in header_pos:
        rows[i - 1].is_header = True
        for c in rows[i - 1].cells:
            c.is_header = True
    return t


def _docx_ir_tables(d, table_quality: dict, guard_on: bool, skipped: list,
                    revisions: list | None = None) -> tuple:
    """由主解析循环已完成的行结构汇总 docx IR 表（不重复扫描正文，避免隐藏文本二次留痕）。

    返回 (tables, nested_tables)；tables 的 Row.source_lines 与正文 table section 文本一致，
    供 document_ir.finalize_tables 解析 char 区间。
    """
    # 主循环已把每个表的行结构放进 table_quality["_ir_rows"]（临时），这里只汇总 + 嵌套表。
    tables = []
    for ti, table in enumerate(getattr(d, "tables", []) or []):
        rows_data = (table_quality.get("_ir_rows") or {}).get(ti + 1) or []
        if not rows_data:
            continue
        t = _dir.Table(table_id=f"docx:t{ti + 1}", doc_type="docx",
                       anchor=f"表{ti + 1}", page_available=False,
                       source="text_layer", confidence=1.0)
        t.rows = [_dir.Row(row=rd["row"], page=None, cells=rd["cells"],
                           source_lines=[rd["text"]]) for rd in rows_data]
        # vMerge 续行 → 锚格 rowspan 增加（续行单元格 merged_from 已在主循环设置）
        for cont in table_quality.get("merged_continuations") or []:
            if int(cont.get("table") or 0) != ti + 1:
                continue
            ar, ac = int(cont.get("merged_from_row") or 0), int(cont.get("merged_from_col") or 0)
            anchor = next((c for r in t.rows if r.row == ar for c in r.cells
                           if c.col == ac), None)
            if anchor is not None:
                anchor.rowspan = int(anchor.rowspan) + 1
                anchor.source = "merged"
        # 多级表头（T6）：标题行 + 表头行都算表头，值形态行起为数据
        header_pos = _dir.detect_header_rows(
            [[{"text": c.text, "colspan": c.colspan} for c in r.cells] for r in t.rows])
        t.header_rows = [t.rows[i - 1].row for i in header_pos if i <= len(t.rows)]
        for i in header_pos:
            if i <= len(t.rows):
                t.rows[i - 1].is_header = True
                for c in t.rows[i - 1].cells:
                    c.is_header = True
        if not t.header_rows:
            t.confidence = 0.8
            t.notes.append("header_not_identified")
        tables.append(t)
    # 嵌套表：只读嵌套 table 的单元格（不重复扫描父单元格段落 → 隐藏文本不重复留痕）
    nested = []
    try:
        from docx.table import _Cell
        cell_ref = table_quality.get("_ir_cells") or {}
        for ti, table in enumerate(getattr(d, "tables", []) or []):
            for ri, tr in enumerate(getattr(table._tbl, "tr_lst", []) or []):
                col = 0
                for tci, tc in enumerate(getattr(tr, "tc_lst", []) or []):
                    col += 1
                    cell = _Cell(tc, table)
                    for ni, nt in enumerate(getattr(cell, "tables", []) or [], 1):
                        nid = f"docx:t{ti + 1}:n{ri + 1}C{col}:t{ni}"
                        ntIR = _docx_nested_ir_table(
                            nt, nid, guard_on, skipped,
                            parent_id=f"docx:t{ti + 1}", parent_row=ri + 1,
                            parent_col=col)
                        nested.append(ntIR)
                        parent = cell_ref.get((ti + 1, ri + 1, col))
                        if parent is not None:
                            parent.nested_table_ids.append(nid)
                    try:
                        from docx.oxml.ns import qn as _qn
                        _gs = tc.find(_qn("w:tcPr"))
                        if _gs is not None:
                            g = _gs.find(_qn("w:gridSpan"))
                            if g is not None:
                                col += max(0, int(g.get(_qn("w:val")) or 1) - 1)
                    except Exception:  # noqa: BLE001 - 列号探测失败不阻断 IR
                        logging.getLogger(__name__).debug(
                            "docx nested gridSpan probe failed", exc_info=True)
    except Exception:  # noqa: BLE001 - 嵌套表失败不得阻断正文解析
        logging.getLogger(__name__).warning("docx 嵌套表 IR 构建失败（按无嵌套表继续）",
                                            exc_info=True)
    return tables, nested


def _docx_comments_with_spans(d, path: str, sections: list,
                              para_info: dict) -> dict:
    """批注通道 + 字符区间回填（L137 C1/C4）：批注文本不进正文，独立可定位。

    para_info: {段落序号(1基): {"anchor": "段落N", "text": 可见文本}}。
    数字拼回（L144 N9）可能把两个段落合成一个 section，故按 anchor 查 section、
    再按锚点相对偏移回填；锚点不可用时退化为整段区间并标 anchor_span_exact=False。
    """
    comments = _dir.extract_docx_comments(d, path)
    try:
        anchor_map = {str(getattr(sec, "anchor", "")): sec for sec in sections}
        for item in comments.get("items") or []:
            pno = item.get("anchor_paragraph")
            info = para_info.get(pno) if pno is not None else None
            if not info:
                item["anchor_resolved"] = False
                continue
            sec = anchor_map.get(str(info.get("anchor") or ""))
            if sec is None:
                # 段落在数字拼回中被并入前一 section：按可见文本在正文中回退定位
                sec = next((x for x in sections
                            if str(info.get("text") or "") and
                            str(info.get("text")) in str(getattr(x, "text", ""))), None)
            if sec is None:
                item["anchor_resolved"] = False
                continue
            base = int(sec.char_start)
            para_text = str(info.get("text") or "")
            st = int(item.get("anchor_start") or 0)
            en = int(item.get("anchor_end") or 0)
            if sec.text == para_text and 0 <= st <= en <= len(sec.text):
                item["char_start"], item["char_end"] = base + st, base + en
            else:
                pos = sec.text.find(para_text[:40]) if para_text else -1
                if pos >= 0 and para_text and sec.text.startswith(para_text, pos):
                    item["char_start"] = base + pos
                    item["char_end"] = base + pos + len(para_text)
                else:
                    item["char_start"] = int(sec.char_start)
                    item["char_end"] = int(sec.char_end)
                item["anchor_span_exact"] = False
            item["anchor_text"] = para_text or str(sec.text)
            item["anchor_resolved"] = True
    except Exception:  # noqa: BLE001 - 批注定位失败不阻断解析（已 anchored 标记）
        logging.getLogger(__name__).warning("docx 批注 char 区间回填失败", exc_info=True)
    return comments


def _docx_revision_summary(revisions: list) -> dict:
    """修订通道汇总（L137 C2）：默认接受插入、忽略删除并标注。"""
    ins = [r for r in (revisions or []) if r.get("kind") == "insert"]
    dele = [r for r in (revisions or []) if r.get("kind") == "delete"]
    return {
        "mode": "accept_insertions_ignore_deletions",
        "policy": ("w:ins 按接受修订后的生效文本进入正文（可作证据）；"
                   "w:del 不作为证据、不进入正文，仅结构化标注（evidence_allowed=false）"),
        "insertions": ins,
        "deletions": dele,
        "inserted_chars": sum(int(r.get("chars") or 0) for r in ins),
        "deleted_chars": sum(int(r.get("chars") or 0) for r in dele),
        "revision_present": bool(revisions),
        "annotated": bool(revisions),
    }


def _parse_docx(path: str) -> ParsedDoc:
    """docx → 统一文档模型。P1 安全（2026-11-23）：默认跳过 run 级隐藏文本。

    隐藏文本（白色字体 / ≤2pt 极小字号 / vanish 隐藏属性）是攻击者可控载体，不作为
    判定证据；跳过处只写 ParsedDoc.skipped_hidden_text 结构化摘要（位置/字符数/原因，
    不复制正文）+ 警告日志。回退开关 RULEPROOF_HIDDEN_TEXT_GUARD=0 → 逐字旧行为。

    L43（2026-11-24）：默认把页眉/页脚（含首页/偶数页变体、页眉页脚内表格）作为独立
    section（kind=header/footer，anchor=页眉N/页脚N）追加在正文之后，并填 char 区间；
    正文 section 的顺序/文本逐字不变。回退开关 RULEPROOF_DOCX_HEADER_FACTS=0 → 旧行为。
    """
    _guard_on = hidden_text_guard_enabled()
    _hf_on = docx_header_facts_enabled()
    _pre_skipped = docx_hidden_text_scan(path) if _guard_on else []
    # 增强路径只回文本、拿不到 run 级格式：命中隐藏文本时不走增强路径，保证跳过生效。
    enhanced = _parse_pdf_enhanced(path) if not _pre_skipped else None  # docling 同样支持 docx/md
    if enhanced:
        _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
        _lines = [_clean_line(ln.strip()) for ln in enhanced.split("\n") if ln.strip()]
        sections = [Section("paragraph", ln, f"段{i+1}", **_kw)
                    for i, ln in enumerate(_lines)]
        if _hf_on:
            # 增强路径（docling 等）拿不到 header/footer 结构：用 python-docx 补充；
            # 若该块文本已整段出现在增强正文中则不重复追加（避免同一页眉计两次）。
            try:
                from docx import Document
                _hf_skipped = []
                _hf_secs = _docx_header_footer_sections(
                    Document(path), _guard_on, _hf_skipped)
                _body_join = "\n".join(_lines)
                for _s in _hf_secs:
                    if _s.text and _s.text in _body_join:
                        continue
                    sections.append(_s)
                if _hf_skipped:
                    logging.getLogger(__name__).warning(
                        "docx 页眉/页脚跳过隐藏文本（增强路径，不作为判定证据，共 %d 处）：%s",
                        len(_hf_skipped),
                        [(x.get("anchor"), x.get("chars"), x.get("reasons")) for x in _hf_skipped])
            except Exception:  # noqa: BLE001 - 补充失败不得阻断既有增强解析
                logging.getLogger(__name__).warning(
                    "docx 页眉/页脚提取失败（增强路径），按旧行为继续", exc_info=True)
        _hf_n = sum(1 for _s in sections if _s.kind in ("header", "footer"))
        return ParsedDoc(path, "docx", sections, _assign_section_spans(sections),
                         ir_summary=_dir.ir_summary(
                             "docx", [], [], [],
                             ["enhanced_path_no_ir: 增强解析路径只回文本，未重建结构 IR"]),
                         header_footer_evidence=_header_footer_evidence(
                             "docx", _hf_on, _hf_n, "RULEPROOF_DOCX_HEADER_FACTS",
                             "docx 未识别到页眉/页脚（无 header/footer 容器）"))
    from docx import Document
    d = Document(path)
    sections = []
    skipped_hidden_text = []
    revisions = []
    _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
    table_quality = {"format": "docx", "tables": [], "empty_cells": 0,
                     "merged_continuations": [], "merged_spans": 0}
    # L154：IR 行结构在主循环同步采集（避免二次扫描导致隐藏文本重复留痕）
    ir_rows_by_table = {}
    ir_cells_by_key = {}
    para_info = {}          # 段落序号(1基) → {anchor, text}（批注锚点回填用）
    pi = 0
    for i, para in enumerate(d.paragraphs):
        if _guard_on:
            t = visible_paragraph_text(para, f"段落{i + 1}", skipped_hidden_text, revisions)
        else:
            t = (para.text or "").strip()
        if not t:
            continue
        # B1-L1 T02：md→docx（测试/迁移链路）保留的 markdown 伪影在段落层清洗；
        # 真实 docx 的成对强调标记不承载业务语义，清洗不改变正文内容。
        t = _clean_line(t)
        style = (para.style.name or "").lower()
        kind = "heading" if "heading" in style or "title" in style else "paragraph"
        sec_anchor = f"段落{len(sections) + 1}"
        para_info[i + 1] = {"anchor": sec_anchor, "text": t}
        sections.append(Section(kind, t, sec_anchor, **_kw))
        pi += 1
    for ti, table in enumerate(d.tables):
        # L144 T-⑤a：T3 空单元格保留占位列（不左移）+ T4 合并单元格（gridSpan/vMerge）
        # 展开为「首格值 + 空占位」，续行不重复逻辑值；结构写 table_quality 显式留痕。
        # L154：同一次遍历产出 IR 行/单元格结构（不改变正文 section 文本口径）。
        grid_prev = {}
        tq = {"table": ti + 1, "rows": 0, "columns": 0,
              "merged_continuations": [], "merged_spans": 0}
        for ri, tr in enumerate(getattr(table._tbl, "tr_lst", []) or []):
            row_cells, row_conts, row_spans, row_structs = _docx_table_row_cells(
                table, ti + 1, ri + 1, tr, _guard_on, skipped_hidden_text, revisions)
            tq["rows"] += 1
            tq["columns"] = max(tq["columns"], len(row_cells))
            tq["merged_spans"] += row_spans
            for cont in row_conts:
                col = cont["col"]
                cont["merged_from_value"] = grid_prev.get(col, "")
                tq["merged_continuations"].append(cont)
                table_quality["merged_continuations"].append(cont)
            grid_prev = {}
            for ci, v in enumerate(row_cells, 1):
                grid_prev[ci] = v if v else grid_prev.get(ci, "")
            table_quality["empty_cells"] += sum(1 for c in row_cells if not c)
            if any(row_cells):
                row_text = _clean_line(" | ".join(row_cells))
                sections.append(Section("table", row_text, f"表{ti + 1}", **_kw))
                _ir_cells = []
                for st in row_structs:
                    _col = int(st.get("col") or 0)
                    _cell = _dir.new_cell(
                        st.get("text", ""), row=ri + 1, col=_col,
                        table_id=f"docx:t{ti + 1}",
                        colspan=max(1, int(st.get("colspan") or 1)),
                        merged_from=(dict(st["merged_from"])
                                     if st.get("merged_from") else None),
                        source=("merged" if st.get("merged_from") else "text_layer"),
                        confidence=1.0 if st.get("text") else 0.9)
                    _ir_cells.append(_cell)
                    ir_cells_by_key[(ti + 1, ri + 1, _col)] = _cell
                ir_rows_by_table.setdefault(ti + 1, []).append(
                    {"row": ri + 1, "cells": _ir_cells, "text": row_text})
        table_quality["tables"].append(tq)
    table_quality["_ir_rows"] = ir_rows_by_table
    table_quality["_ir_cells"] = ir_cells_by_key
    ir_tables, nested_tables = _docx_ir_tables(
        d, table_quality, _guard_on, skipped_hidden_text, revisions)
    for _pk in [k for k in list(table_quality) if str(k).startswith("_")]:
        table_quality.pop(_pk, None)
    _hf_secs = []
    if _hf_on:
        # 页眉/页脚追加在正文之后：正文 section 顺序/文本不变（正文不回归）
        _hf_secs = _docx_header_footer_sections(d, _guard_on, skipped_hidden_text)
        sections.extend(_hf_secs)
    _body_chars = sum(len(s.text or "") for s in sections
                      if s.kind not in ("header", "footer"))
    # L144 N9：正文断行数字拼回（页眉/页脚不参与）
    _body = [s for s in sections if s.kind not in ("header", "footer")]
    _joins = _apply_numeric_joins(_body)
    if _joins:
        sections = _body + [s for s in sections if s.kind in ("header", "footer")]
    if skipped_hidden_text:
        logging.getLogger(__name__).warning(
            "docx 跳过隐藏文本汇总（不作为判定证据，共 %d 处）：%s",
            len(skipped_hidden_text),
            [(x.get("anchor"), x.get("chars"), x.get("reasons")) for x in skipped_hidden_text])
    text = _assign_section_spans(sections)
    _imgs = _docx_body_image_count(d)
    _status, _reason = "ok", ""
    if _imgs and _body_chars < 40:
        # L144 / L137 FC5：图片型 docx（正文只有标题文本、内容全在图里）不得报 full/ok。
        _status = "partial"
        _reason = (f"image_only_content: 正文含 {_imgs} 张内嵌图片、可提取正文仅 "
                   f"{_body_chars} 字符；图片内容未经 OCR（OCR 能力不可用/未启用），"
                   "图片内文本不可判定（L137 FC5）")
    # L154：修订/批注通道（不进入正文 text；批注文本保持不泄漏，只走独立通道）
    revisions_doc = _docx_revision_summary(revisions)
    comments = _docx_comments_with_spans(d, path, sections, para_info)
    if comments.get("present") and not comments.get("parsed") and _status == "ok":
        _status = "partial"
        _reason = ("comments_unparsed: 文档含批注但批注通道未解析（"
                   + str(comments.get("note") or "")[:160] + "）；L137 C1 禁止静默不可见")
    _ir_all = ir_tables + nested_tables
    _ir_warnings = _dir.finalize_tables(_ir_all, text, sections)
    ir_sum = _dir.ir_summary("docx", [], [], _ir_all, _ir_warnings)
    if nested_tables:
        ir_sum["nested_tables"] = len(nested_tables)
    if revisions_doc.get("revision_present"):
        ir_sum["revisions"] = {
            "insertions": len(revisions_doc.get("insertions") or []),
            "deletions": len(revisions_doc.get("deletions") or []),
            "mode": revisions_doc.get("mode")}
    if comments.get("present"):
        ir_sum["comments"] = {"present": True, "parsed": int(comments.get("parsed") or 0),
                              "anchored": int(comments.get("anchored") or 0)}
    return ParsedDoc(path, "docx", sections, text,
                     parse_status=_status, status_reason=_reason,
                     skipped_hidden_text=skipped_hidden_text,
                     numeric_joins=_joins, table_quality=table_quality,
                     pages=[], sheets=[],
                     tables=[t.to_dict() for t in _ir_all],
                     comments=comments, revisions=revisions_doc,
                     ir_summary=ir_sum,
                     header_footer_evidence=_header_footer_evidence(
                         "docx", _hf_on, len(_hf_secs), "RULEPROOF_DOCX_HEADER_FACTS",
                         "docx 未识别到页眉/页脚（无 header/footer 容器）"))


# ---------------------------------------------------------------------------
# L116（2026-11-25）PDF 页眉/页脚进入解析结果（因子 #6「解析残余」）
#
# 缺陷：_parse_pdf 只调 page.extract_text() 取正文；文本层 PDF 的页眉/页脚
#   （报告模板版本号/文件编号/页脚签名/页码）与正文混在一起、且没有可定位的
#   header/footer section，与 docx（L43）/xlsx（L107）口径不一致；layout.analyze_pdf
#   只认「跨页重复首/末行」，单页/带标签的页眉页脚抓不到（本 lane 不改 layout.py，
#   在 deepparse 统一解析层实现）。
# 设计（只做文本层、确定性、0 新增依赖）：
#   · pypdf extract_text(visitor_text=...) 取每个文本段的字符矩阵，用 mult(tm, cm)
#     的等价实现算绝对坐标；按「页面上下边缘带（72pt / 1 英寸）」收集候选页眉/页脚行；
#   · 双判据接受：① 跨页重复（数字归一后同文 ≥2 页）；② 命中页眉/页脚标签词
#     （版本/编号/签名/页码/第N页/Version/Report No/Signature…）。不采用「首行/末行
#     即页眉页脚」的纯位置启发式，避免误伤无页眉文档的首行标题；
#   · 接受行 → Section(kind="header"/"footer", anchor="页眉(第1-3页)"/"页脚(第2页)")，
#     追加在正文 sections 之后；正文 section 顺序/文本逐字不变（与 L43 同口径）；
#     同文跨页只产出 1 个 section（页码逐页不同则按页产出，保持页码可定位）；
#   · 无文本层（扫描件）不做页眉/页脚抽取：OCR 层未纳入（UNTESTED），避免把视觉
#     模型产出当页眉字段证据；证据状态写进 ParsedDoc.header_footer_evidence（结构化）。
# 回退：RULEPROOF_PDF_HEADER_FACTS=0 → 逐字恢复旧行为（不产出 header/footer section）。
# ---------------------------------------------------------------------------
_PDF_HF_ZONE_PT = 72.0          # 页边距带：页眉 y>=h-72；页脚 y<=72（常见 0.5–1 英寸）
_PDF_HF_ROW_TOL = 3.0           # 同一行 y 容差（pt）
_PDF_HF_MAX_ROWS = 8            # 边缘带行数上限；超过视为坐标异常（旋转/扫描文本层），不判定
_PDF_HF_LABEL_RE = re.compile(
    r"(版本|编号|文件号|文号|页码|页眉|页脚|签名|签字|审核人|批准人|编制人|模板|表单|"
    r"报告编号|第\s*\d+\s*页|共\s*\d+\s*页|"
    r"version|ver\.|template|report\s*no|doc(?:ument)?\s*no|file\s*no|"
    r"signature|sign(?:ed)?\s*by|page\s*\d+|page\s*:)",
    re.I)
_CJK_CHAR_RE = re.compile(r"[\u2e80-\u9fff\uf900-\ufaff\uff00-\uffef]")


def pdf_header_facts_enabled() -> bool:
    """RULEPROOF_PDF_HEADER_FACTS（默认 1）：PDF 文本层页眉/页脚进入 sections/text。"""
    return str(os.environ.get("RULEPROOF_PDF_HEADER_FACTS", "1")).strip().lower() not in (
        "0", "false", "no", "off")


def _pdf_mult(tm, cm) -> tuple:
    """pypdf mult(tm, cm) 的等价实现（PDF 行向量约定；不依赖 pypdf 私有 API）。"""
    a, b, c, d, e, f = (float(x or 0) for x in list(tm)[:6])
    na, nb, nc, nd, ne, nf = (float(x or 0) for x in list(cm)[:6])
    return (a * na + b * nc, a * nb + b * nd,
            c * na + d * nc, c * nb + d * nd,
            e * na + f * nc + ne, e * nb + f * nd + nf)


def _pdf_est_width(text: str, size: float) -> float:
    """粗略估算文本宽度（pt）：CJK/全角按 1em，其余按 0.5em（只用于同行拼接判断）。"""
    if size <= 0:
        size = 10.0
    return sum(1.0 if _CJK_CHAR_RE.match(ch) else 0.5 for ch in str(text or "")) * size


def _pdf_join_row_parts(parts: list) -> str:
    """同一 y 行内的多个文本段按 x 顺序拼接；间距明显时补空格（中文不加）。"""
    out, prev_x, prev_txt, prev_size = [], None, "", 10.0
    for x, raw, size in sorted(parts, key=lambda p: p[0]):
        txt = str(raw or "")
        if not txt:
            continue
        if out and prev_x is not None:
            gap = float(x) - (prev_x + _pdf_est_width(prev_txt, prev_size))
            if gap > max(2.0, 0.3 * prev_size) and not _CJK_CHAR_RE.search(prev_txt[-1:] + txt[:1]):
                out.append(" ")
        out.append(txt)
        prev_x, prev_txt, prev_size = float(x), txt, float(size or 10.0)
    return "".join(out).strip()


def _pdf_page_has_visual(page) -> bool:
    """页面是否含图像内容（扫描页/图片页判定；探测失败按 False 处理，不臆测）。"""
    try:
        imgs = getattr(page, "images", None)
        if imgs is not None:
            return len(imgs) > 0
    except Exception:  # noqa: BLE001 - 图像探测失败不阻断文本解析
        logging.getLogger(__name__).debug("pdf page images probe failed", exc_info=True)
    try:
        res = page.get("/Resources")
        res = res.get_object() if hasattr(res, "get_object") else res
        xobj = (res or {}).get("/XObject")
        xobj = xobj.get_object() if hasattr(xobj, "get_object") else xobj
        for _k, _v in (xobj or {}).items():
            _o = _v.get_object() if hasattr(_v, "get_object") else _v
            if str((_o or {}).get("/Subtype") or "") == "/Image":
                return True
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).debug("pdf xobject images probe failed", exc_info=True)
    return False


def _pdf_collect_pages(reader) -> list:
    """逐页取文本 + 文本段坐标：返回 [{page,height,text,segments:[(x,y,size,text)]}]。

    visitor 不可用（老 pypdf/测试 mock）时退化为纯文本（segments 为空，不做页眉页脚判定）；
    extract_text 抛异常时该页记空文本（不阻断既有解析）。
    """
    out = []
    for pno, page in enumerate(getattr(reader, "pages", []) or [], 1):
        try:
            _mb = page.mediabox
            _bottom = float(_mb.bottom)
            _height = float(_mb.height)
        except Exception:
            _bottom, _height = 0.0, 792.0
        try:
            if float(page.get("/Rotate") or 0) % 360 in (90, 270):
                # 旋转页文本坐标语义不同：只取纯文本，不做页眉/页脚位置判定（保守）
                _text = page.extract_text() or ""
                out.append({"page": pno, "height": _height, "text": str(_text),
                            "segments": [], "rotated": True,
                            "has_visual": _pdf_page_has_visual(page)})
                continue
        except Exception:
            logging.getLogger(__name__).debug("ignored exception (fail-closed cleanup)", exc_info=True)
        segments = []

        def _visitor(text, cm, tm, font_dict, font_size, _segments=segments):
            raw = str(text or "")
            if not raw.strip():
                return
            try:
                m = _pdf_mult(tm, cm)
            except Exception:
                return
            try:
                size = float(font_size or 0.0)
            except (TypeError, ValueError):
                size = 0.0
            _segments.append((float(m[4]), float(m[5]) - _bottom, size, raw))

        try:
            text = page.extract_text(visitor_text=_visitor) or ""
        except TypeError:
            # 不支持 visitor_text 的调用方/老实现：退化纯文本
            try:
                text = page.extract_text() or ""
            except Exception:
                text = ""
        except Exception:
            logging.getLogger(__name__).debug("pdf text extract failed: page=%s", pno,
                                              exc_info=True)
            text = ""
        out.append({"page": pno, "height": _height, "text": str(text),
                    "segments": segments, "rotated": False,
                    "has_visual": _pdf_page_has_visual(page)})
    return out


def _pdf_row_groups(segments: list) -> list:
    """文本段 → 行（同一 y 容差内按 x 拼接），按从上到下排序。"""
    rows = []
    for x, y, size, raw in sorted(segments, key=lambda s: (-s[1], s[0])):
        for row in rows:
            if abs(row["y"] - y) <= _PDF_HF_ROW_TOL:
                row["parts"].append((x, raw, size))
                break
        else:
            rows.append({"y": y, "parts": [(x, raw, size)]})
    for row in rows:
        row["text"] = _pdf_join_row_parts(row["parts"])
    return [r for r in sorted(rows, key=lambda r: -r["y"]) if r.get("text")]


def _pdf_hf_norm(text: str) -> str:
    """页眉/页脚重复判定的归一文本（NFKC + 去空白 + 数字→#；大小写不敏感）。"""
    import unicodedata
    s = unicodedata.normalize("NFKC", str(text or "")).strip().lower()
    s = re.sub(r"\s+", "", s)
    return re.sub(r"\d+", "#", s)


def _pdf_page_span_label(pages: list) -> str:
    """页码集合 → 「第1页」「第2,4页」「第1-3页」（用于 anchor 定位）。"""
    ps = sorted({int(p) for p in pages or []})
    if not ps:
        return "第0页"
    if len(ps) == 1:
        return f"第{ps[0]}页"
    if ps == list(range(ps[0], ps[-1] + 1)):
        return f"第{ps[0]}-{ps[-1]}页"
    return "第" + ",".join(str(p) for p in ps) + "页"


def _pdf_header_footer_evidence(pages: list) -> tuple:
    """页眉/页脚判定：返回 (sections, evidence)。只读 pages（_pdf_collect_pages 产物）。"""
    if not pdf_header_facts_enabled():
        return [], {"format": "pdf", "switch": "off", "state": "disabled",
                    "sufficient": False,
                    "reason": "RULEPROOF_PDF_HEADER_FACTS=0（回退旧行为：不解析页眉/页脚）",
                    "sections": 0, "pages": len(pages or [])}
    try:
        page_rows = []
        for item in pages or []:
            rows = _pdf_row_groups(item.get("segments") or [])
            _h = float(item.get("height") or 792.0)
            top = [r for r in rows if r["y"] >= _h - _PDF_HF_ZONE_PT]
            bottom = [r for r in rows if r["y"] <= _PDF_HF_ZONE_PT]
            if len(top) > _PDF_HF_MAX_ROWS:
                top = []
            if len(bottom) > _PDF_HF_MAX_ROWS:
                bottom = []
            page_rows.append({"page": int(item.get("page") or 0),
                              "header": top, "footer": bottom})
        counts = {"header": {}, "footer": {}}
        for item in page_rows:
            for kind in ("header", "footer"):
                seen = set()
                for row in item[kind]:
                    norm = _pdf_hf_norm(row["text"])
                    if not norm or norm in seen:
                        continue
                    seen.add(norm)
                    counts[kind][norm] = counts[kind].get(norm, 0) + 1
        blocks = []
        for item in page_rows:
            for kind in ("header", "footer"):
                accepted = []
                for row in item[kind]:
                    norm = _pdf_hf_norm(row["text"])
                    if not norm:
                        continue
                    if counts[kind].get(norm, 0) >= 2 or _PDF_HF_LABEL_RE.search(row["text"]):
                        if not accepted or accepted[-1] != row["text"]:
                            accepted.append(row["text"])
                if accepted:
                    blocks.append({"kind": kind, "text": "\n".join(accepted),
                                   "page": item["page"]})
        groups, index = [], {}
        for block in blocks:
            key = (block["kind"], block["text"])
            if key in index:
                groups[index[key]]["pages"].append(block["page"])
            else:
                index[key] = len(groups)
                groups.append({"kind": block["kind"], "text": block["text"],
                               "pages": [block["page"]]})
        _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
        sections = []
        for group in groups:
            label = _pdf_page_span_label(group["pages"])
            prefix = "页眉" if group["kind"] == "header" else "页脚"
            sections.append(Section(group["kind"], _clean_line(group["text"]),
                                    f"{prefix}({label})", **_kw))
        if sections:
            return sections, {"format": "pdf", "switch": "on", "state": "found",
                              "sufficient": True, "reason": "",
                              "sections": len(sections), "pages": len(page_rows)}
        return [], {"format": "pdf", "switch": "on", "state": "none",
                    "sufficient": False,
                    "reason": ("文本层未识别到页眉/页脚：边缘带无跨页重复行，"
                               "且不含页眉/页脚标签（字段缺失属证据不足，不默认放行）"),
                    "sections": 0, "pages": len(page_rows)}
    except Exception as e:  # noqa: BLE001 - 页眉页脚判定失败不得阻断既有正文解析
        logging.getLogger(__name__).warning("pdf 页眉/页脚判定失败（按旧正文继续）",
                                            exc_info=True)
        return [], {"format": "pdf", "switch": "on", "state": "error",
                    "sufficient": False,
                    "reason": f"{type(e).__name__}: {str(e)[:200]}",
                    "sections": 0, "pages": len(pages or [])}


def _pdf_no_text_layer_evidence(pages: int = 0) -> dict:
    """扫描件/无文本层：页眉/页脚不纳入确定性解析（OCR 层 UNTESTED）。"""
    return {"format": "pdf", "switch": "on" if pdf_header_facts_enabled() else "off",
            "state": "no_text_layer", "sufficient": False,
            "reason": ("无文本层（扫描件）：页眉/页脚不纳入确定性解析（OCR 层 UNTESTED）；"
                       "页眉字段缺失属证据不足，不默认放行"),
            "sections": 0, "pages": int(pages or 0)}


def _pdf_ir(raw_pages: list, sections: list, text: str,
            page_prov: dict | None = None, missing: list | None = None,
            blank: list | None = None) -> tuple:
    """PDF → (pages, tables, ir_summary, table_meta)。

    页/文本块给页码、bbox、char 区间；表格只在文本层坐标可重建时 table_supported=True，
    不能重建（列不可判/跨页断行拼不回/只有视觉列分隔无坐标）→ 显式 partial（L137 T10/FC6）。
    IR 构建失败不得阻断既有文本解析（降级为仅文本 + 显式 warning）。
    """
    try:
        tables, tmeta = _dir.detect_pdf_tables(raw_pages)
        pages = _dir.build_pdf_pages(raw_pages, sections)
        _miss = set(int(x) for x in (missing or []))
        _blank = set(int(x) for x in (blank or []))
        for _p in pages:
            _p.missing = _p.page in _miss
            _p.blank = _p.page in _blank
            if _p.blank:
                _p.notes.append("blank_page_no_text_no_visual")
            if _p.missing:
                _p.notes.append("no_text_layer_with_visual_content")
        _prov = page_prov or {}
        for _p in pages:
            _pv = _prov.get(f"第{_p.page}页") or {}
            if _pv:
                _p.ocr_engine = str(_pv.get("ocr_engine") or "ocr")
                # OCR 置信度当前链路未提供：不伪造 1.0，记 0 并留痕（R2/R3）
                _p.ocr_confidence = float(_pv.get("ocr_confidence") or 0.0)
                if _p.ocr_confidence <= 0.0:
                    _p.notes.append("ocr_confidence_unavailable")
        if page_prov:
            # OCR 路径：文本来自 OCR 而非文本层
            for _p in pages:
                _p.has_text_layer = False
                _p.ocr_engine = _p.ocr_engine or "ocr"
        warnings = _dir.finalize_tables(tables, text, sections)
        ir_sum = _dir.ir_summary("pdf", pages, [], tables, warnings)
        ir_sum["table_detection"] = {
            "partial": bool(tmeta.get("partial")),
            "unsupported_pages": list(tmeta.get("unsupported_pages") or []),
            "reasons": list(tmeta.get("reasons") or [])[:20],
        }
        return ([p.to_dict() for p in pages], [t.to_dict() for t in tables],
                ir_sum, tmeta)
    except Exception:  # noqa: BLE001 - IR 构建失败不得阻断已有解析
        logging.getLogger(__name__).warning("pdf 结构 IR 构建失败（按旧行为继续）",
                                            exc_info=True)
        return ([], [], _dir.ir_summary("pdf", [], [], [],
                                        ["ir_build_failed: PDF 结构 IR 构建异常"]), {})


def _pdf_table_partial_reason(tmeta: dict) -> str:
    """表格不可重建时的显式缺失原因（供 parse_status=partial 的 status_reason）。"""
    reasons = [str(x) for x in (tmeta or {}).get("reasons") or []]
    return ("table_structure_partial: " + ("；".join(reasons[:3]) if reasons else
            "PDF 表格列/跨页续行不能可靠重建，该表证据不得用于确定性判定（L137 T10/FC6）"))


def _parse_pdf(path: str) -> ParsedDoc:
    enhanced = _parse_pdf_enhanced(path)
    if enhanced:
        _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
        _lines = [_clean_line(ln.strip()) for ln in enhanced.split("\n") if ln.strip()]
        sections = [Section("paragraph", ln, f"段{i+1}", **_kw)
                    for i, ln in enumerate(_lines)]
        # L116：增强路径（docling/pymupdf）拿不到字符坐标，用 pypdf 单独补页眉/页脚；
        # 增强正文里可能已含页眉文本，这里仍产出独立可定位 section（不删正文，与正文解析口径一致）。
        _hf_pages = None
        try:
            from pypdf import PdfReader as _PdfReader
            _hf_pages = _pdf_collect_pages(_PdfReader(path))
            _hf_sections, _hf_ev = _pdf_header_footer_evidence(_hf_pages)
        except Exception:  # noqa: BLE001 - 补充失败不得阻断既有增强解析
            logging.getLogger(__name__).warning("pdf 页眉/页脚提取失败（增强路径），按旧行为继续",
                                                exc_info=True)
            _hf_sections, _hf_ev = [], {"format": "pdf", "switch": "on",
                                        "state": "error", "sufficient": False,
                                        "reason": "增强路径页眉/页脚提取异常", "sections": 0,
                                        "pages": 0}
        if _hf_sections:
            sections.extend(_hf_sections)
        text = _assign_section_spans(sections)
        _pages_ir, _tables_ir, _ir_sum, _tmeta = _pdf_ir(_hf_pages or [], sections, text)
        _ir_sum["warnings"] = list(_ir_sum.get("warnings") or []) + [
            "enhanced_path: 增强解析路径的正文行无页内坐标，页文本块 bbox 不完整"]
        return ParsedDoc(path, "pdf", sections, text,
                         pages=_pages_ir, tables=_tables_ir, ir_summary=_ir_sum,
                         header_footer_evidence=_hf_ev)
    from pypdf import PdfReader
    r = PdfReader(path)
    sections = []
    page_prov = {}
    _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
    _pages = _pdf_collect_pages(r)
    _missing, _blank = [], []
    for item in _pages:
        t = str(item.get("text") or "").strip()
        if t:
            pno = int(item.get("page") or 0)
            page_prov[f"第{pno}页"] = dict(_TEXT_LAYER_PROV)
            for para in t.split("\n"):
                para = para.strip()
                if para:
                    sections.append(Section("paragraph", para, f"第{pno}页", **_kw))
        else:
            # L144 FC4/R6：按页判定文本层。含图像但无文本层 = 不可读页（扫描页），
            # 必须 partial + 枚举缺失页；空白页（无图像）单独记录，不降级。
            _pno = int(item.get("page") or 0)
            (_missing if item.get("has_visual") else _blank).append(_pno)
    _joins = _apply_numeric_joins(sections)      # L144 N9：跨页/断行数字拼回（保守）
    text = "\n".join(s.text for s in sections)
    if _missing and text.strip():
        # 混合文档：部分页有文本层、部分页只有图像 → 按页 fail-closed（禁止整体报 ok）
        _reason = (f"mixed_pages: {len(_missing)}/{len(_pages)} 页无可提取文本层且含图像内容"
                   f"（页 {','.join(str(p) for p in _missing)}），未对缺失页执行 OCR"
                   "（OCR 能力不可用/未启用）；缺失页内容不参与判定（L137 FC4/R6）")
        text = _assign_section_spans(sections)      # 填 char 区间（文本逐字不变）
        _pages_ir, _tables_ir, _ir_sum, _tmeta = _pdf_ir(
            _pages, sections, text, missing=_missing, blank=_blank)
        return ParsedDoc(path, "pdf", sections, text, parse_status="partial",
                         status_reason=_reason, page_provenance=page_prov,
                         numeric_joins=_joins, pages_missing=_missing,
                         pages_blank=_blank, pages=_pages_ir, tables=_tables_ir,
                         ir_summary=_ir_sum,
                         header_footer_evidence=_pdf_header_footer_evidence(_pages)[1])
    if not text.strip():
        # 扫描版（无文本层）：OCR 兜底。OCR 前处理依赖 PDF 渲染能力，渲染器不可用时
        # 必须显式返回「需要 OCR 但 OCR 能力不可用」（T-148），不能只给空文本。
        # L144：全篇无文本层时，含图像页全部记入 pages_missing（按页缺失范围可枚举）。
        _no_text_ev = _pdf_no_text_layer_evidence(len(_pages))
        try:
            from . import ocr as _ocr
            from .. import config as _cfg
            _det = _ocr.ocr_scanned_pdf_detailed(path, _cfg, max_pages=10)
            if _det.get("text"):
                _page_prov = dict(_det.get("page_provenance") or {})
                _sections = []
                for _pt in (_det.get("page_texts") or []):
                    _pv = dict(_pt.get("provenance") or {})
                    _kw2 = _section_prov_kwargs(_pv)
                    _anchor = f"第{_pt.get('page')}页"
                    for _ln in str(_pt.get("text") or "").split("\n"):
                        if _ln.strip():
                            _sections.append(Section("paragraph", _ln.strip(), _anchor, **_kw2))
                if not _sections:
                    # 兼容旧 detailed 返回（无 page_texts）：无 provenance 按未知处理
                    _sections = [Section("paragraph", ln.strip(), "OCR")
                                 for ln in _det["text"].split("\n") if ln.strip()]
                _ocr_text = str(_det["text"])
                _pages_ir, _tables_ir, _ir_sum, _tmeta = _pdf_ir(
                    _pages, _sections, _ocr_text, page_prov=_page_prov,
                    missing=_missing, blank=_blank)
                _ir_sum["ocr"] = {"ocr_unavailable": False,
                                  "note": "扫描件 OCR 文本来源见 page_provenance；OCR 质量 NOT TESTED"}
                return ParsedDoc(path, "pdf", _sections, _ocr_text,
                                 parse_status="ok",
                                 status_reason=str(_det.get("reason") or "扫描件 OCR 已补齐"),
                                 page_provenance=_page_prov,
                                 pages_missing=_missing, pages_blank=_blank,
                                 pages=_pages_ir, tables=_tables_ir, ir_summary=_ir_sum,
                                 header_footer_evidence=_no_text_ev)
            _cap = _det.get("ocr_capability") or {}
            _reason = str(_det.get("reason") or "")
            _pages_ir, _tables_ir, _ir_sum, _tmeta = _pdf_ir(
                _pages, [], "", missing=_missing, blank=_blank)
            _ir_sum["ocr"] = {"ocr_unavailable": bool(_det.get("ocr_unavailable")),
                              "note": "无文本层且 OCR 未产出；页码/空白页在 pages 中枚举"}
            if _det.get("ocr_unavailable"):
                _hint = str(_cap.get("hint") or "").strip()
                _cap_reason = str(_cap.get("reason") or "").strip()
                return ParsedDoc(path, "pdf", [], "", parse_status="partial",
                                 status_reason=(("需要 OCR 但 OCR 能力不可用"
                                                 + (f"（{_hint}）" if _hint else "") + "："
                                                 + (_cap_reason or _reason))[:400]),
                                 ocr_capability=_cap, ocr_unavailable=True,
                                 pages_missing=_missing or [int(p.get("page") or 0)
                                                            for p in _pages],
                                 pages_blank=_blank, pages=_pages_ir,
                                 ir_summary=_ir_sum,
                                 header_footer_evidence=_no_text_ev)
            return ParsedDoc(path, "pdf", [], "", parse_status="partial",
                             status_reason=("扫描件需要 OCR，但 OCR 未返回文本：" + _reason)[:300],
                             ocr_capability=_cap, pages_missing=_missing or [
                                 int(p.get("page") or 0) for p in _pages],
                             pages_blank=_blank, pages=_pages_ir, ir_summary=_ir_sum,
                             header_footer_evidence=_no_text_ev)
        except Exception as e:  # noqa: BLE001 - 兜底失败也要留下可诊断状态
            logging.getLogger(__name__).warning("scanned pdf OCR failed", exc_info=True)
            _pages_ir, _tables_ir, _ir_sum, _tmeta = _pdf_ir(
                _pages, [], "", missing=_missing, blank=_blank)
            return ParsedDoc(path, "pdf", [], "", parse_status="partial",
                             status_reason=f"扫描件 OCR 异常：{type(e).__name__}: {str(e)[:200]}",
                             pages_missing=_missing or [int(p.get("page") or 0) for p in _pages],
                             pages_blank=_blank, pages=_pages_ir, ir_summary=_ir_sum,
                             header_footer_evidence=_no_text_ev)
    _hf_sections, _hf_evidence = _pdf_header_footer_evidence(_pages)
    if _hf_sections:
        sections.extend(_hf_sections)
    text = _assign_section_spans(sections)          # 填 char 区间（文本逐字不变）
    _pages_ir, _tables_ir, _ir_sum, _tmeta = _pdf_ir(
        _pages, sections, text, missing=_missing, blank=_blank)
    _status, _reason = "ok", ""
    if (_tmeta or {}).get("partial"):
        _status = "partial"
        _reason = _pdf_table_partial_reason(_tmeta)
    return ParsedDoc(path, "pdf", sections, text, parse_status=_status,
                     status_reason=_reason, numeric_joins=_joins,
                     pages=_pages_ir, tables=_tables_ir, ir_summary=_ir_sum,
                     header_footer_evidence=_hf_evidence)


# ---------------------------------------------------------------------------
# L107（2026-11-25）xlsx 打印页眉/页脚进入解析结果（D2 修复）
#
# 缺陷：_parse_xlsx 只遍历单元格；openpyxl read_only=True 下 ws.oddHeader/oddFooter
#   恒为 None，excel 打印页眉（真实工艺书常写版本号/文件名/页码）完全不可见，L69
#   parse_50 页眉版本号 20/50（仅 docx 命中），字段 295/325。
# 修复：read_only 主流程不变（0 额外内存），直读 xlsx zip 的
#   xl/workbook.xml + _rels（sheet 名→sheetN.xml，含隐藏态）+ 各 sheet 的
#   <headerFooter> 节点，按 &L/&C/&R 位置拆分后与 docx 同口径产出
#   Section(kind="header"/"footer", anchor="{sheet}!{oddHeader|evenHeader|firstHeader|
#   oddFooter|evenFooter|firstFooter}.{left|center|right}")；隐藏/极隐藏 sheet 仍然跳过
#   （页眉同样不读，沿用 _HIDDEN_SHEET_SKIP_ENV 口径）。正文 table section 顺序/文本
#   逐字不变，header/footer 追加在末尾并填 char 区间。
# 开关 RULEPROOF_XLSX_HEADER_FACTS（默认 1；=0 逐字回退旧行为，用于 A/B 与回滚）。
# ---------------------------------------------------------------------------
_XLSX_HF_MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_XLSX_DOC_REL_NS = ("http://schemas.openxmlformats.org/officeDocument/2006/relationships",
                    "http://purl.oclc.org/ooxml/officeDocument/relationships")
# (workbook 关系属性名, Section.kind, openpyxl 属性名) —— 与 L69 参考面 loc 命名一致
_XLSX_HF_TYPES = (
    ("oddHeader", "header", "oddHeader"),
    ("oddFooter", "footer", "oddFooter"),
    ("evenHeader", "header", "evenHeader"),
    ("evenFooter", "footer", "evenFooter"),
    ("firstHeader", "header", "firstHeader"),
    ("firstFooter", "footer", "firstFooter"),
)
_XLSX_HF_POS = {"L": "left", "C": "center", "R": "right"}


def xlsx_header_facts_enabled() -> bool:
    """RULEPROOF_XLSX_HEADER_FACTS（默认 1）：xlsx 打印页眉/页脚文本进入 sections/text。"""
    return str(os.environ.get("RULEPROOF_XLSX_HEADER_FACTS", "1")).strip().lower() not in (
        "0", "false", "no", "off")


def _xlsx_hf_positions(raw: str) -> dict:
    """打印页眉/页脚字符串按 &L/&C/&R 拆成 {left,center,right}（无位置码默认 center）。

    OOXML 把页眉存成单串（如 ``&L版本号:V1.0&R第 1 页``）；openpyxl 在非 read_only
    下解析成 left/center/right 三段。本函数做同一拆分（``&&`` 还原为字面 ``&``），
    只拆位置，不做格式化/页码解释（页码留在 right 段，供上层判断干扰项）。
    """
    parts = {"left": [], "center": [], "right": []}
    cur = "center"
    buf, i, n = [], 0, len(raw or "")
    while i < n:
        ch = raw[i]
        if ch == "&" and i + 1 < n and raw[i + 1] in _XLSX_HF_POS:
            parts[cur].append("".join(buf))
            buf = []
            cur = _XLSX_HF_POS[raw[i + 1]]
            i += 2
            continue
        if ch == "&" and i + 1 < n and raw[i + 1] == "&":
            buf.append("&")
            i += 2
            continue
        buf.append(ch)
        i += 1
    parts[cur].append("".join(buf))
    return {k: "".join(v).strip() for k, v in parts.items() if "".join(v).strip()}


def _xlsx_sheet_hf_map(path: str) -> dict:
    """直读 xlsx zip：返回 {sheet_title: [(kind, attr, pos, text)]}（只含非空打印页眉/页脚）。

    sheet 名→sheetN.xml 用 xl/workbook.xml 的 r:id + xl/_rels/workbook.xml.rels 解析
    （不假设 sheetN 顺序）；路径/XML 损坏时返回 {} 并 warning（解析降级不静默）。
    """
    import zipfile
    from xml.etree import ElementTree as _ET
    _log = logging.getLogger(__name__)
    try:
        zf = zipfile.ZipFile(path)
    except Exception as _e:  # noqa: BLE001 - 非 zip/损坏文件不阻断既有解析
        _log.warning("xlsx 打印页眉解析失败（zip 打开异常，按旧行为继续）：%s", _e)
        return {}
    out = {}
    try:
        with zf:
            names = set(zf.namelist())
            try:
                wb = _ET.fromstring(zf.read("xl/workbook.xml"))  # nosec B314 - local xlsx zip member, no external entity/network
            except KeyError:
                return {}
            rel_map = {}
            if "xl/_rels/workbook.xml.rels" in names:
                try:
                    rels = _ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))  # nosec B314 - local xlsx zip member, no external entity/network
                    for rel in rels:
                        rel_map[str(rel.get("Id") or "")] = str(rel.get("Target") or "")
                except _ET.ParseError as _e:
                    _log.warning("xlsx workbook rels 解析失败：%s", _e)
            rel_attrs = ["{%s}id" % ns for ns in _XLSX_DOC_REL_NS]
            for sheet in wb.iter("{%s}sheet" % _XLSX_HF_MAIN_NS):
                title = str(sheet.get("name") or "")
                rid = next((sheet.get(a) for a in rel_attrs if sheet.get(a)), "") or ""
                target = rel_map.get(rid, "")
                if not target:
                    continue
                target = target.lstrip("/")
                if not target.startswith("xl/"):
                    target = "xl/" + target
                target = os.path.normpath(target).replace(os.sep, "/")
                if target not in names:
                    continue
                try:
                    root = _ET.fromstring(zf.read(target))  # nosec B314 - local xlsx zip member, no external entity/network
                except (_ET.ParseError, KeyError) as _e:
                    _log.warning("xlsx sheet XML 解析失败（%s）：%s", target, _e)
                    continue
                hf = root.find(".//{%s}headerFooter" % _XLSX_HF_MAIN_NS)
                if hf is None:
                    continue
                found = []
                for tag, kind, _attr in _XLSX_HF_TYPES:
                    node = hf.find("{%s}%s" % (_XLSX_HF_MAIN_NS, tag))
                    if node is None:
                        continue
                    raw = "".join(node.itertext())
                    for pos, txt in _xlsx_hf_positions(raw).items():
                        found.append((kind, tag, pos, txt))
                if found:
                    out[title] = found
    except Exception as _e:  # noqa: BLE001 - 页眉解析失败不得阻断既有单元格解析
        _log.warning("xlsx 打印页眉解析失败（按旧行为继续）：%s", _e, exc_info=True)
        return {}
    return out


def _xlsx_header_footer_sections(path: str) -> list:
    """xlsx 打印页眉/页脚 → Section 列表（可见 sheet；锚点与 L69 参考面 loc 一致）。"""
    _kw = _section_prov_kwargs(_TEXT_LAYER_PROV)
    out = []
    for sheet_title, items in _xlsx_sheet_hf_map(path).items():
        for kind, attr, pos, text in items:
            out.append(Section(kind, _clean_line(text),
                               f"{sheet_title}!{attr}.{pos}", **_kw))
    return out


_HIDDEN_SHEET_SKIP_ENV = "RULEPROOF_PARSE_SKIP_HIDDEN_SHEET"


def skip_hidden_sheets() -> bool:
    """隐藏 sheet 是否跳过（唯一解析器：deepparse；证据回填等模块复用同一口径）。"""
    return str(os.environ.get("RULEPROOF_PARSE_SKIP_HIDDEN_SHEET", "1")
               ).strip().lower() not in ("0", "false", "no", "off")


# ---- L144 T-⑤a（2026-11-25）：xlsx 表格结构质量（T3 空占位 / T4 合并 / T9 公式） ---
# 缺陷（L137 G2）：旧实现 `[str(c).strip() for c in row if c is not None...]` 丢弃 None →
# 空单元格/合并续行/公式无缓存全部**静默丢空 → 列左移（串列）**。
# 修复：保留 grid 列占位（None→''）；合并续行写 merged_from 审计；公式无缓存（data_only
# 读成 None）显式写入公式文本 + missing_reason=formula_no_cache；结构写 table_quality。
# 合并/公式信息 openpyxl read_only 不可得 → 直读 xlsx zip sheet XML（与 L107 页眉同一来源）。
def _xlsx_parse_ref_range(ref: str):
    """'A1:D1' / 'A1' → (r1,c1,r2,c2)（1 基）；非法返回 None。"""
    from openpyxl.utils.cell import range_boundaries
    try:
        c1, r1, c2, r2 = range_boundaries(str(ref or ""))
        return int(r1), int(c1), int(r2), int(c2)
    except Exception:  # noqa: BLE001 - 非法 merge 引用跳过
        return None


def _xlsx_ref_to_rc(ref: str):
    """'C5' → (5,3)；非法返回 None。"""
    from openpyxl.utils.cell import coordinate_to_tuple
    try:
        r, c = coordinate_to_tuple(str(ref or ""))
        return int(r), int(c)
    except Exception:  # noqa: BLE001
        return None


def _xlsx_sheet_xml_roots(path: str) -> dict:
    """xlsx zip → {sheet 标题: sheet XML root}（可见/隐藏都在；路径损坏返回 {}）。"""
    import zipfile
    from xml.etree import ElementTree as _ET
    out = {}
    try:
        zf = zipfile.ZipFile(path)
    except Exception as _e:  # noqa: BLE001 - 损坏 zip 不阻断既有解析（parse_document 兜底）
        logging.getLogger(__name__).warning("xlsx sheet XML 打开失败（按旧行为继续）：%s", _e)
        return {}
    try:
        with zf:
            names = set(zf.namelist())
            try:
                wb = _ET.fromstring(zf.read("xl/workbook.xml"))  # nosec B314 - 本地 zip 成员
            except (KeyError, _ET.ParseError):
                return {}
            rel_map = {}
            if "xl/_rels/workbook.xml.rels" in names:
                try:
                    rels = _ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))  # nosec B314
                    for rel in rels:
                        rel_map[str(rel.get("Id") or "")] = str(rel.get("Target") or "")
                except _ET.ParseError as _e:
                    logging.getLogger(__name__).warning("xlsx rels 解析失败：%s", _e)
            rel_attrs = ["{%s}id" % ns for ns in _XLSX_DOC_REL_NS]
            for sheet in wb.iter("{%s}sheet" % _XLSX_HF_MAIN_NS):
                title = str(sheet.get("name") or "")
                rid = next((sheet.get(a) for a in rel_attrs if sheet.get(a)), "") or ""
                target = rel_map.get(rid, "")
                if not target:
                    continue
                target = target.lstrip("/")
                if not target.startswith("xl/"):
                    target = "xl/" + target
                target = os.path.normpath(target).replace(os.sep, "/")
                if target not in names:
                    continue
                try:
                    out[title] = _ET.fromstring(zf.read(target))  # nosec B314 - 本地 zip 成员
                except (_ET.ParseError, KeyError) as _e:
                    logging.getLogger(__name__).warning(
                        "xlsx sheet XML 解析失败（%s）：%s", target, _e)
    except Exception as _e:  # noqa: BLE001
        logging.getLogger(__name__).warning("xlsx sheet XML 解析失败（按旧行为继续）：%s",
                                            _e, exc_info=True)
        return {}
    return out


def _xlsx_sheet_meta(path: str) -> dict:
    """{sheet: {"merges":[(r1,c1,r2,c2)], "formula_no_cache":{(r,c): "=…"},
                "formula_cached":{(r,c): "=…"}}}。

    L154：区分「公式有缓存值」（data_only 可读到值）与「无缓存」（T9 必须显式标记）；
    两者都保留公式文本，供 IR Cell.formula 与证据回指。
    """
    out = {}
    for title, root in _xlsx_sheet_xml_roots(path).items():
        merges = []
        for mc in root.iter("{%s}mergeCell" % _XLSX_HF_MAIN_NS):
            rng = _xlsx_parse_ref_range(str(mc.get("ref") or ""))
            if rng:
                merges.append(rng)
        formulas, cached_formulas = {}, {}
        for cell in root.iter("{%s}c" % _XLSX_HF_MAIN_NS):
            fnode = cell.find("{%s}f" % _XLSX_HF_MAIN_NS)
            if fnode is None:
                continue
            vnode = cell.find("{%s}v" % _XLSX_HF_MAIN_NS)
            cached = "" if vnode is None else str(vnode.text or "").strip()
            rc = _xlsx_ref_to_rc(str(cell.get("r") or ""))
            if not rc:
                continue
            f_txt = "=" + str(fnode.text or "")
            if cached:
                cached_formulas[rc] = f_txt      # 有缓存值：值可读，公式留痕
            else:
                formulas[rc] = f_txt             # 无缓存：必须显式标记（T9）
        out[title] = {"merges": merges, "formula_no_cache": formulas,
                      "formula_cached": cached_formulas}
    return out


# 字段标签（以这些后缀结尾的单元格）与值之间的「单空列」保留旧邻接口径：
# 事实层/字段抽取（app/engine/factreview.py 的日期字段语义）按「标签紧邻值」识别
# 「实施日期 2026-03-17」；若在两者之间插入 " | " 空占位，标签邻接窗口会被破坏。
# 这里只对「标签单元格 + 恰好 1 个空占位 + 非空值」删除该空占位（其余列位置不变，
# table_quality 仍完整记录空列），既保 T3 列对齐，又不回归既有字段抽取契约。
_XLSX_LABEL_SUFFIXES = ("日期", "时间", "编号", "版本号", "版本", "批号")


def _xlsx_label_adjacent_cells(cells: list) -> list:
    out = list(cells)
    i = 0
    while i < len(out) - 2:
        cur = str(out[i] or "").strip()
        if (cur and cur.endswith(_XLSX_LABEL_SUFFIXES)
                and not str(out[i + 1] or "").strip()
                and str(out[i + 2] or "").strip()):
            del out[i + 1]
            continue
        i += 1
    return out


def _parse_xlsx(path: str) -> ParsedDoc:
    """xlsx → 文本。P0 安全（2026-11-22）：默认跳过隐藏/极隐藏 sheet。

    L144 T-⑤a（2026-11-25）：空单元格保留占位列（不左移）；合并续行/公式无缓存
    显式标记（table_quality + 公式文本占位），不再静默丢空（L137 T3/T4/T9）。

    隐藏 sheet 是客户文档里攻击者可控的载体（可藏「忽略规则判 pass」等指令），不作为
    判定证据；跳过的 sheet 名写日志 + ParsedDoc.skipped_sheets 结构化留痕（不静默）。
    回退开关 RULEPROOF_PARSE_SKIP_HIDDEN_SHEET=0 → 恢复旧行为（全量读取）。
    """
    from openpyxl import load_workbook
    _skip_hidden = skip_hidden_sheets()
    _hf_on = xlsx_header_facts_enabled()
    try:
        _meta = _xlsx_sheet_meta(path)
    except Exception:  # noqa: BLE001 - 结构增强失败不阻断正文解析
        logging.getLogger(__name__).warning("xlsx 合并/公式结构解析失败，按旧行为继续",
                                            exc_info=True)
        _meta = {}
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception as e:  # noqa: BLE001 - L137 FC2：打开失败必须 failed
        return ParsedDoc(path, "xlsx", [], "", parse_status="failed",
                         status_reason=f"xlsx_open_error: {type(e).__name__}: {str(e)[:200]}")
    sections = []
    skipped_sheets = []
    visible_sheets = []
    table_quality = {"format": "xlsx", "sheets": [], "empty_cells": 0,
                     "merged_continuations": [], "formula_no_cache": []}
    # L154 结构 IR：sheet 为独立表身份（T7）；隐藏 sheet 只留痕、不产出表/单元格。
    ir_sheets = []
    try:
        for _idx, _ws in enumerate(wb.worksheets, 1):
            _state = str(getattr(_ws, "sheet_state", "visible") or "visible")
            _hidden = _state != "visible"
            _skipped = bool(_skip_hidden and _hidden)
            ir_sheets.append(_dir.Sheet(
                sheet=str(_ws.title), index=_idx, hidden=_hidden,
                skipped=_skipped,
                note=("hidden_sheet_skipped: 隐藏/极隐藏 sheet 不作为判定证据（结构化留痕）"
                      if _skipped else
                      ("hidden_sheet_read: RULEPROOF_PARSE_SKIP_HIDDEN_SHEET=0" if _hidden else ""))))
    except Exception:  # noqa: BLE001 - sheet 枚举失败不得阻断既有解析
        logging.getLogger(__name__).warning("xlsx sheet 枚举失败", exc_info=True)
    ir_tables = []
    try:
        for ws in wb.worksheets:
            _state = str(getattr(ws, "sheet_state", "visible") or "visible")
            if _skip_hidden and _state != "visible":
                skipped_sheets.append(str(ws.title))
                continue
            title = str(ws.title)
            visible_sheets.append(title)
            smeta = _meta.get(title) or {}
            merge_map = {}
            anchor_map = {}
            merge_ranges = []
            for (r1, c1, r2, c2) in (smeta.get("merges") or []):
                merge_ranges.append({"r1": int(r1), "c1": int(c1),
                                     "r2": int(r2), "c2": int(c2)})
                anchor_map[(int(r1), int(c1))] = (max(1, int(r2) - int(r1) + 1),
                                                 max(1, int(c2) - int(c1) + 1))
                for rr in range(int(r1), int(r2) + 1):
                    for cc in range(int(c1), int(c2) + 1):
                        if (rr, cc) != (r1, c1):
                            merge_map[(rr, cc)] = (int(r1), int(c1))
            fmap = smeta.get("formula_no_cache") or {}
            fcmap = smeta.get("formula_cached") or {}
            rows = []
            try:
                for row in ws.iter_rows(values_only=True):
                    rows.append(list(row))
            except Exception as e:  # noqa: BLE001 - 单 sheet 读取失败显式降级
                logging.getLogger(__name__).warning(
                    "xlsx sheet 读取失败（%s）：%s", title, e)
                table_quality["sheets"].append({"sheet": title, "error":
                                                f"{type(e).__name__}: {str(e)[:120]}"})
                continue
            ncols = max([len(r) for r in rows] or [0])
            if not ncols:
                table_quality["sheets"].append({"sheet": title, "rows": 0, "columns": 0,
                                                "merges": len(smeta.get("merges") or []),
                                                "merged_continuations": 0,
                                                "formula_no_cache": 0})
                _ir_sheet = next((x for x in ir_sheets if x.sheet == title), None)
                if _ir_sheet is not None:
                    _ir_sheet.rows, _ir_sheet.columns = 0, 0
                    _ir_sheet.merge_ranges = merge_ranges
                continue
            for row in rows:
                if len(row) < ncols:
                    row.extend([None] * (ncols - len(row)))
            formula_n = 0
            cont_n = 0
            ir_rows = []
            for ri, row in enumerate(rows, 1):
                cells, any_val = [], False
                structs = []
                for ci in range(1, ncols + 1):
                    if (ri, ci) in merge_map:
                        # T4：合并续行占位（空串），不重复逻辑值；结构审计在下方记录
                        cells.append("")
                        ar, ac = merge_map[(ri, ci)]
                        structs.append({"col": ci, "text": "",
                                        "merged_from": {"row": int(ar), "col": int(ac)},
                                        "source": "merged", "rowspan": 1, "colspan": 1})
                        table_quality["empty_cells"] += 1
                        continue
                    _span = anchor_map.get((ri, ci), (1, 1))
                    f_txt = fmap.get((ri, ci))
                    if f_txt:
                        # T9：公式无缓存 → 保留公式文本占位 + missing_reason 显式标记
                        cells.append(f_txt)
                        formula_n += 1
                        any_val = True
                        try:
                            from openpyxl.utils.cell import get_column_letter
                            cell_ref = f"{get_column_letter(ci)}{ri}"
                        except Exception:  # noqa: BLE001
                            cell_ref = f"R{ri}C{ci}"
                        table_quality["formula_no_cache"].append({
                            "sheet": title, "row": ri, "col": ci, "cell": cell_ref,
                            "formula": f_txt, "missing_reason": "formula_no_cache"})
                        structs.append({"col": ci, "text": f_txt,
                                        "formula": f_txt,
                                        "missing_reason": "formula_no_cache",
                                        "rowspan": _span[0], "colspan": _span[1],
                                        "source": "text_layer"})
                        continue
                    v = row[ci - 1]
                    s = "" if v is None else str(v).strip()
                    if s:
                        cells.append(s)
                        any_val = True
                    else:
                        cells.append("")          # T3：空单元格保留占位列
                        table_quality["empty_cells"] += 1
                    structs.append({"col": ci, "text": s,
                                    "formula": str(fcmap.get((ri, ci)) or ""),
                                    "missing_reason": "",
                                    "rowspan": _span[0], "colspan": _span[1],
                                    "source": "merged" if (ri, ci) in anchor_map
                                    else "text_layer"})
                for ci in range(1, ncols + 1):
                    if (ri, ci) in merge_map:
                        ar, ac = merge_map[(ri, ci)]
                        cont_n += 1
                        table_quality["merged_continuations"].append({
                            "sheet": title, "row": ri, "col": ci,
                            "merged_from_row": int(ar), "merged_from_col": int(ac),
                            "reason": "merged_continuation"})
                if any_val:
                    # T3：**多列密集行（≥3 个非空单元格）保留空单元格占位列**（防左移/串列，
                    # 对应 L137 串列率验收）；≤2 个非空单元格的稀疏行沿用旧文本口径
                    # （仅非空值按原序 join），因为：
                    #   · 稀疏行（如「实施日期 | 空 | 日期」）若插占位会破坏下游事实层
                    #     字段标签邻接（factreview 按「标签紧邻值」归日期/字段语义），
                    #     以及 L36/L107 既有单字段适配层契约；
                    #   · 稀疏行的空列位置仍完整记录在 table_quality（sheets/empty_cells/
                    #     merged_continuations），不静默丢失。
                    _nonempty = [c for c in cells if c]
                    if len(_nonempty) >= 3:
                        _row_text = " | ".join(_xlsx_label_adjacent_cells(cells))
                    else:
                        _row_text = " | ".join(_nonempty)
                    sections.append(Section("table", _row_text, title,
                                            **_section_prov_kwargs(_TEXT_LAYER_PROV)))
                    # L154：IR 行/单元格（与正文 section 同一 row_text，char 区间可回指）
                    _ir_cells = []
                    for st in structs:
                        _ir_cells.append(_dir.new_cell(
                            st.get("text", ""), row=ri, col=int(st["col"]),
                            sheet=title, table_id=f"xlsx:{title}",
                            rowspan=max(1, int(st.get("rowspan") or 1)),
                            colspan=max(1, int(st.get("colspan") or 1)),
                            merged_from=(dict(st["merged_from"])
                                         if st.get("merged_from") else None),
                            source=str(st.get("source") or "text_layer"),
                            formula=str(st.get("formula") or ""),
                            missing_reason=str(st.get("missing_reason") or ""),
                            confidence=1.0 if st.get("text") else 0.9))
                    ir_rows.append({"row": ri, "cells": _ir_cells, "text": _row_text})
            _ir_sheet = next((x for x in ir_sheets if x.sheet == title), None)
            if _ir_sheet is not None:
                _ir_sheet.rows = len(rows)
                _ir_sheet.columns = ncols
                _ir_sheet.merge_ranges = merge_ranges
            # L154：每个可见 sheet = 独立表身份（T7），同表头不跨 sheet 合并。
            if ir_rows:
                _t = _dir.Table(
                    table_id=f"xlsx:{title}", doc_type="xlsx", sheet=title,
                    anchor=title, page_available=False, source="text_layer",
                    confidence=1.0)
                _t.rows = [_dir.Row(row=rd["row"], page=None, cells=rd["cells"],
                                    source_lines=[rd["text"]]) for rd in ir_rows]
                # 多级表头识别（T6）：标题行 + 表头行都算表头（合并标题 colspan 由 Cell 表达）
                _hdr_pos = _dir.detect_header_rows(
                    [[{"text": c.text, "colspan": c.colspan} for c in r.cells]
                     for r in _t.rows])
                _hdr_rows = [_t.rows[i - 1].row for i in _hdr_pos if i <= len(_t.rows)]
                if _hdr_rows:
                    _sig = " ".join(str(_t.rows[_hdr_pos[-1] - 1].cells[j].text)
                                    for j in range(len(_t.rows[_hdr_pos[-1] - 1].cells)))
                    _sig = "".join(_sig.split())
                    for r in _t.rows:
                        if r.row in _hdr_rows:
                            r.is_header = True
                            for c in r.cells:
                                c.is_header = True
                    # 重复表头行（同 sheet 内再次出现）：归一到 header_rows，不计数据（T6）
                    for r in _t.rows:
                        if r.row in _hdr_rows:
                            continue
                        _rtxt = "".join(" ".join(str(c.text) for c in r.cells).split())
                        if _rtxt and _rtxt == _sig:
                            _hdr_rows.append(r.row)
                            r.is_header = True
                            for c in r.cells:
                                c.is_header = True
                            _t.repeated_header = True
                    _t.header_rows = sorted(set(_hdr_rows))
                else:
                    _t.confidence = 0.8
                    _t.notes.append("header_not_identified")
                ir_tables.append(_t)
                if _ir_sheet is not None:
                    _ir_sheet.table_ids.append(_t.table_id)
            table_quality["sheets"].append({
                "sheet": title, "rows": len(rows), "columns": ncols,
                "merges": len(smeta.get("merges") or []),
                "merged_continuations": cont_n,
                "formula_no_cache": formula_n})
    finally:
        try:
            wb.close()
        except Exception:  # noqa: BLE001
            logging.getLogger(__name__).debug("xlsx close failed", exc_info=True)
    _hf_secs = []
    if _hf_on:
        # L107 D2：打印页眉/页脚作为独立 section 追加在正文之后（正文顺序/文本不变）；
        # 隐藏 sheet 的页眉同样不作为判定证据（只取可见 sheet，与跳隐藏 sheet 同口径）。
        try:
            _visible = set(visible_sheets)
            for _sec in _xlsx_header_footer_sections(path):
                if _sec.anchor.split("!", 1)[0] in _visible:
                    sections.append(_sec)
                    _hf_secs.append(_sec)
        except Exception:  # noqa: BLE001 - 页眉补充失败不得阻断既有解析
            logging.getLogger(__name__).warning(
                "xlsx 打印页眉/页脚提取失败，按旧行为继续", exc_info=True)
    if skipped_sheets:
        logging.getLogger(__name__).warning(
            "xlsx 跳过隐藏 sheet（不作为判定证据，共 %d 个）：%s",
            len(skipped_sheets), skipped_sheets)
    text = _assign_section_spans(sections)
    _ir_warnings = _dir.finalize_tables(ir_tables, text, sections)
    ir_sum = _dir.ir_summary("xlsx", [], ir_sheets, ir_tables, _ir_warnings)
    return ParsedDoc(path, "xlsx", sections, text,
                     skipped_sheets=skipped_sheets, table_quality=table_quality,
                     pages=[], sheets=[s.to_dict() for s in ir_sheets],
                     tables=[t.to_dict() for t in ir_tables], ir_summary=ir_sum,
                     header_footer_evidence=_header_footer_evidence(
                         "xlsx", _hf_on, len(_hf_secs), "RULEPROOF_XLSX_HEADER_FACTS",
                         "xlsx 未识别到打印页眉/页脚（可见 sheet 无 <headerFooter> 内容）"))

def parse_and_extract(path: str) -> dict:
    """一步到位：解析 + 抽事实，返回 {doc, facts, provenance}。

    TL-5：事实按所属段落/页 provenance 标注（文本层=trusted；扫描件视觉 OCR=vision，
    数值事实标 evidence_source='vision_advisory'，上层数值判定必须降级）。
    """
    doc = parse_document(path)
    facts = []
    for s in doc.sections:
        facts.extend(extract_facts(s.text, s.anchor, provenance=s))
    doc_dict = doc.to_dict()
    return {"doc": doc_dict, "facts": [f.to_dict() for f in facts],
            "fact_count": len(facts),
            "provenance": doc_dict.get("provenance") or {}}
