"""
企业标准 → 规则候选 提取器（规则沉淀的“冷启动挖掘”）。

从企业标准 PDF 中抽取：标准号 / 产品 / 发布·实施日期 / 代替关系 /
关键指标与数值限值 / 贮存·保质期条款，产出结构化规则候选，供人工确认后
走 10 类条款模板 → 规则库。

只用 pypdf（已随运行环境安装）；对扫描件返回“无可提取文本”。
"""
import json
import os
import re
import sys
from dataclasses import dataclass, field, asdict

from pypdf import PdfReader


METRICS = [
    "菌落总数", "大肠菌群", "致病菌", "金黄色葡萄球菌", "沙门氏菌",
    "过氧化值", "酸价", "铅", "镉", "总砷", "无机砷", "水分", "蛋白质",
    "脂肪", "氯化物", "食品添加剂", "山梨酸", "苯甲酸", "亚硝酸盐",
    "中心温度", "冷藏", "冷冻", "贮存", "保质期",
]


def extract_text(path: str) -> str:
    try:
        r = PdfReader(path)
        return "\n".join((p.extract_text() or "") for p in r.pages)
    except Exception as e:  # noqa
        return f"__ERR__ {type(e).__name__}: {e}"


def _norm(s: str) -> str:
    return s.replace("\u3000", " ").replace("\xa0", " ").strip()


def parse_standard(text: str, filename: str) -> dict:
    t = _norm(text)
    out = {
        "file": filename,
        "standard_no": "",
        "product": "",
        "publish_date": "",
        "implement_date": "",
        "replaces": "",
        "metrics": [],
        "limits": [],
        "has_storage": False,
        "has_shelf_life": False,
    }
    m = re.search(r"(Q/[A-Z0-9]+\s*[0-9]+S)", t)
    if m:
        out["standard_no"] = m.group(1).replace(" ", "")
    m = re.search(r"(\d{4})\s*[-.年]\s*(\d{1,2})\s*[-.月]\s*(\d{1,2})\s*日?\s*发布", t)
    if m:
        out["publish_date"] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    m = re.search(r"(\d{4})\s*[-.年]\s*(\d{1,2})\s*[-.月]\s*(\d{1,2})\s*日?\s*实施", t)
    if m:
        out["implement_date"] = f"{m.group(1)}-{m.group(2).zfill(2)}-{m.group(3).zfill(2)}"
    m = re.search(r"代替\s*([^\n，。]{2,30})", t)
    if m:
        out["replaces"] = m.group(1).strip()
    # 产品名：标准号之后、发布/实施之前的一段
    m = re.search(r"(?:S\s*—?\s*\d{4}\s*)([^\n]{2,30}?)\s*(?:\d{4}\s*[-.]\s*\d{1,2})", t)
    if m:
        out["product"] = m.group(1).strip()

    for metric in METRICS:
        if metric in t:
            out["metrics"].append(metric)
    out["metrics"] = sorted(set(out["metrics"]))

    # 数值限值：指标名 + 单位 + ≤/＜ + 数值（理化指标；微生物采样方案 n/c/m/M 另需人工标注）
    LIMIT_METRICS = ["过氧化值", "酸价", "铅", "镉", "砷", "总砷", "无机砷", "甲基汞",
                     "铬", "氯化物", "水分", "蛋白质", "脂肪", "亚硝酸盐", "山梨酸",
                     "苯甲酸", "N-二甲基亚硝胺"]
    pat = re.compile(
        r"(?P<metric>" + "|".join(LIMIT_METRICS) + r")"
        r"[^≤<>]{0,30}?(?P<unit>g/100g|g/kg|mg/kg|mg/g|μg/kg|μg/100g|%|CFU/g)?"
        r"\s*(?P<op>≤|＜|<|≥|＞|>)\s*(?P<value>\d+(?:\.\d+)?)\s*(?P<unit2>g/100g|g/kg|mg/kg|mg/g|μg/kg|%|CFU/g)?"
    )
    for mm in pat.finditer(t):
        m = mm.group("metric")
        u = (mm.group("unit") or mm.group("unit2") or "").strip()
        _op = mm.group("op")
        op = "＜" if _op in ("＜", "<") else "＞" if _op in ("＞", ">") else "≤" if _op in ("≤",) else "≥"
        out["limits"].append(f"{m} {op} {mm.group('value')}{' ' + u if u else ''}")

    out["has_storage"] = "贮存" in t or "贮藏" in t
    out["has_shelf_life"] = "保质期" in t
    return out


def build_index(pdf_dir: str) -> list:
    items = []
    for name in sorted(os.listdir(pdf_dir)):
        if not name.lower().endswith(".pdf"):
            continue
        fp = os.path.join(pdf_dir, name)
        text = extract_text(fp)
        if text.startswith("__ERR__") or not text.strip():
            items.append({"file": name, "error": text or "空文本"})
            continue
        items.append(parse_standard(text, name))
    return items


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    idx = build_index(argv[0])
    print(json.dumps(idx, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
