# -*- coding: utf-8 -*-
"""TJ 批准摘录 vs JL 执行记录：逐对判定跨节不一致。

盲测/审计场景中，批准条件与执行记录按编号成对出现（TJ-x-N ↔ JL-x-N）。
通用分窗+prompt 容易漏；这里按对检索，一次只看一对，专测编号/日期/数值/版本/授权/范围。
"""
import json
import re


def pair_blocks(text: str) -> list:
    def blocks(prefix):
        out = {}
        for m in re.finditer(r"(?ms)^###\s+(" + prefix + r"-\S+)\s*\n(.*?)(?=^###\s|\Z)", text or ""):
            out[m.group(1)] = m.group(2).strip()
        return out
    tj, jl = blocks("TJ"), blocks("JL")
    pairs = []
    for tid, tbody in tj.items():
        tail = tid.split("-")[-1]
        for jid, jbody in jl.items():
            if jid.split("-")[-1] == tail:
                pairs.append((tid, tbody, jid, jbody))
                break
    return pairs


def check(text: str, use_llm: bool = True) -> list:
    pairs = pair_blocks(text)
    if not pairs or not use_llm:
        return []
    try:
        from . import hooks
        if hooks.llm_provider() is None:
            return []
    except Exception:
        return []
    out = []
    for tid, tbody, jid, jbody in pairs:
        prompt = (
            "你是企业审核员。下面是一条批准条件（TJ）与对应执行记录（JL）。"
            "只判断执行记录是否与批准条件冲突：编号/日期/数值/版本/授权/范围/结论等。"
            "文字表述不同但语义一致不算冲突；无法确定时 conflict=false。"
            "只输出 JSON，不要解释：{\"conflict\":true|false,\"reason\":\"依据\",\"quote\":\"JL 原文片段\"}。\n\n"
            f"【批准 {tid}】\n{tbody[:1200]}\n\n【执行 {jid}】\n{jbody[:1200]}"
        )
        try:
            raw = hooks.llm_chat([{"role": "user", "content": prompt}], max_tokens=300)
            body = raw[raw.index("{"): raw.rindex("}") + 1]
            j = json.loads(body)
        except Exception:
            continue
        if not isinstance(j, dict) or not j.get("conflict"):
            continue
        reason = str(j.get("reason") or "")[:300]
        quote = str(j.get("quote") or jbody[:120])[:200]
        out.append({
            "id": f"RECORD-PAIR-{tid}-{jid}", "rule_code": "RECORD-PAIR",
            "point_id": "", "level": str(j.get("level") or "warning"),
            "title": f"批准条件与执行记录不一致（{jid}）",
            "rule_name": "批准-执行一致性", "category": "record_pair",
            "description": f"批准 {tid} 与执行 {jid} 存在冲突：{reason}",
            "suggestion": "核对批准版本/编号/数值/授权范围，补充变更批准或更正执行记录",
            "locations": [{"locator": jid, "quote": quote, "sheet": "",
                           "evidence_id": tid, "before": tbody[:180], "after": jbody[:180]}],
            "criterion": "执行记录必须符合批准条件", "level_label": "中",
        })
    return out
