# -*- coding: utf-8 -*-
"""L79 单一真相源 Registry（Rule Type / Operator / Unit 三合一，v1）。

背景（90 号 §二-5 / L48 可扩展底子审计）：
- 规则模板三处名单漂移：``app/engine/rule_schema.py::TEMPLATES`` 10 类、
  ``rule_schema::EXECUTOR_BY_TEMPLATE`` 12 项、``web/app.js::RULE_TEMPLATES`` 12 类（且集合不同）；
- 单位表多源：``ruleexec._UNIT_SCALE`` 缺 ppm/℉/秒 统一入口，``rule_schema._UNIT_CANON``
  另有一份中文/符号归一表，L39 的 ppm/ppb/℉/秒/s 又散在 ``_FIX2_UNIT_SCALE``/``_TEMP_UNIT``；
- 算子表在 ``rule_ir2`` 内部，保存期没有统一校验入口。

本模块是本轮 **唯一数据源**：模板 / 算子 / 单位在这里各只定义一次，下游模块一律
引用本模块（保留旧常量名做兼容别名，避免第二份名单）：

  rule_schema.TEMPLATES            = registry.nl_templates()          （10 类填槽模板投影）
  rule_schema.EXECUTOR_BY_TEMPLATE = registry.executor_map()          （12 类可执行模板投影）
  rule_ir2.OPERATORS_BY_TYPE       = registry.OPERATORS_BY_TYPE
  rule_ir2.MODALITY                = registry.MODALITY
  ruleexec._UNIT_SCALE / _FIX2_* / _V3_* / _TEMP_UNIT = registry 各投影

口径（不改变判定语义）：
- 10 类 ``limit..citation`` 是 **NL 填槽/分类模板**（rule_schema.TEMPLATES 仍是这 10 类）；
- 额外 2 类 ``field_presence`` / ``cross_relation`` 是 **执行器专用模板**（ruleexec 已实现，
  只经 API/导入/编译路径进入，不在新建表单里选）——三者合成 12 项可执行模板；
- ``format`` / ``preprocess`` 不是执行器模板（ruleexec 无专属执行分支），只是 rulegen
  分类/内置规则用的类别；本轮从新建表单模板下拉移除，只在类别标签表里保留展示。
- 单位 registry 收录「可换算单位」（base/L39/L42/温度/压力）与「可解析但不可换算单位」
  （元/吨、CFU/g 等历史文本单位）。可换算=归一后参与比较；不可换算=执行期沿用
  P0-A「未知/不可换算单位 → 证据不足」，写入门只拒绝**完全未登记**的单位。

写入门（L79 §2）：
  ``validate_write(category, slots)`` 抛 :class:`RuleWriteGateError`
  （``.code ∈ unsupported_template|unsupported_operator|unsupported_unit``）；
  开关 ``RULEPROOF_RULE_WRITE_GATE``（默认 1；=0 逐字节回退旧行为，不做写入门）。
  发布门 ``rule_schema.executor_reachable`` 保持不变（仍在发布期生效）。

指纹：``fingerprint()`` 对规范化 payload 取 SHA256，与运行期开关（EXEC_FIXES_V2/V3、
WRITE_GATE）无关；同内容跨库/跨进程稳定，供快照/报告引用。
"""
from __future__ import annotations

import hashlib
import json
import os
import re

REGISTRY_VERSION = "l79-registry-v1"

# 写入门开关（默认 1=开启；=0 回退历史行为：不校验模板/算子/单位）
WRITE_GATE_ENV = "RULEPROOF_RULE_WRITE_GATE"

# 规则执行器白名单（原 rule_schema.EXECUTORS）
EXECUTORS = frozenset({"rule", "llm", "script", "decision_table"})


class RuleWriteGateError(ValueError):
    """写入门拒绝：携带机读错误码（400 响应 code 字段同源）。"""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = str(code or "invalid_rule")


# ###########################################################################
# 1. 规则模板（12 类可执行模板：10 类 NL 填槽 + 2 类执行器专用）
# ###########################################################################
# 前 10 项从 rule_schema.TEMPLATES 原样迁入（code/name/rclass/slots/evidence/pattern/keywords，
# 逐个字段与迁移前一致；classify()/fill_slots() 行为不变）。
# 后 2 项是 ruleexec 既有确定性执行器（judge_field_presence / judge_document_relation），
# 原只存在于 EXECUTOR_BY_TEMPLATE，未进 TEMPLATES；本轮纳入同一张表，标记
# nl_fillable=False / ui_selectable=False（不参与 NL 分类、不出现在新建表单）。
_TEMPLATE_ROWS = [
    {
        "code": "limit", "name": "限值", "rclass": "R1", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["metric", "op", "value", "unit", "tolerance"],
        "evidence": ["参数单元格", "原文引用"],
        "pattern": r"(温度|时间|浓度|重量|净含量|中心温度|冷却|pH|水分|蛋白质|脂肪|糖|盐|ppm|g|kg|℃|min)",
        "keywords": ["达到", "不低于", "不高于", "不超过", "至少", "±", "℃", "min", "ppm", "g", "kg", "≤", "≥"],
    },
    {
        "code": "completeness", "name": "完整性", "rclass": "R0", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["required_docs"],
        "evidence": ["文件列表"],
        "pattern": r"(必须|应|需).{0,12}(包含|提交|齐|附|提供|出具)",
        "keywords": ["必须包含", "应包含", "需提供", "附", "齐套", "完整"],
    },
    {
        "code": "record", "name": "记录要求", "rclass": "R1", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["record_field", "required"],
        "evidence": ["记录字段单元格"],
        "pattern": r"(记录|填写|登记|签名|日期)",
        "keywords": ["记录", "填写", "签名", "签字", "登记", "日期"],
    },
    {
        "code": "consistency", "name": "一致性", "rclass": "R3", "executor": "llm",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["objects", "across"],
        "evidence": ["跨文档单元格对"],
        "pattern": r"(一致|统一|对应|匹配|相符|同步)",
        "keywords": ["一致", "统一", "对应", "匹配", "相符", "同步", "跨"],
    },
    {
        "code": "prohibited", "name": "禁止性", "rclass": "R2", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["object", "forbidden"],
        "evidence": ["原文引用"],
        "pattern": r"(禁止|不得|不应|严禁|不允许|不可)",
        "keywords": ["禁止", "不得", "严禁", "不应", "不允许", "不可"],
    },
    {
        "code": "frequency", "name": "时限/频率", "rclass": "R1", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["action", "frequency", "window"],
        "evidence": ["参数单元格"],
        "pattern": r"(每天|每周|每月|每批|每次|小时|分钟|天|频率|定期)",
        "keywords": ["每天", "每周", "每月", "每批", "每次", "定期", "频率", "小时", "分钟"],
    },
    {
        "code": "personnel", "name": "人员资质", "rclass": "R2", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["role", "qualification"],
        "evidence": ["人员信息", "证书"],
        "pattern": r"(人员|员工|操作员|质检|培训|健康证|上岗|资质)",
        "keywords": ["人员", "培训", "健康证", "上岗", "资质", "资质证书"],
    },
    {
        "code": "equipment", "name": "设备设施", "rclass": "R2", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["equipment", "state"],
        "evidence": ["设备信息"],
        "pattern": r"(设备|设施|器具|机器|杀菌|金属探测|校准|保养|消毒)",
        "keywords": ["设备", "器具", "杀菌", "金属探测", "校准", "保养"],
    },
    {
        "code": "label", "name": "标识标签", "rclass": "R2", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["item", "label_required"],
        "evidence": ["标签/标识原文"],
        "pattern": r"(标签|标识|名称|规格|生产日期|保质期|贮存|条码|致敏)",
        "keywords": ["标签", "标识", "生产日期", "保质期", "贮存", "条码", "致敏"],
    },
    {
        "code": "citation", "name": "引用一致", "rclass": "R3", "executor": "rule",
        "nl_fillable": True, "ui_selectable": True,
        "slots": ["cited", "source"],
        "evidence": ["引用字段 + 被引用文件"],
        "pattern": r"(引用|依据|参照|标准|版本|编号|GB|Q/)",
        "keywords": ["引用", "依据", "参照", "标准号", "版本", "编号", "GB"],
    },
    {
        # 字段存在性：ruleexec.judge_field_presence（字段值三态：空字段 fail / 不可识别 insufficient）
        "code": "field_presence", "name": "字段存在性", "rclass": "R0", "executor": "rule",
        "nl_fillable": False, "ui_selectable": False,
        "slots": ["field", "role"],
        "evidence": ["字段单元格"],
        "pattern": "",
        "keywords": [],
    },
    {
        # 跨文件关系：ruleexec.judge_document_relation（订单键 + 执行/批准版本比较，文档集级）
        "code": "cross_relation", "name": "跨文件关系", "rclass": "R3", "executor": "rule",
        "nl_fillable": False, "ui_selectable": False,
        "slots": ["cross_relation", "order_key_label"],
        "evidence": ["跨文档比较"],
        "pattern": "",
        "keywords": [],
    },
]

# 模板别名（执行器已识别的历史写法；写入门按别名接受，归一为 canonical code）
TEMPLATE_ALIASES = {
    # ruleexec._is_field_presence_rule 已识别的历史写法（执行期同一判据）
    "field": "field_presence",
    "field_required": "field_presence",
    "personnel_field": "field_presence",
}

# rulegen 12 类类别（分类/展示口径；含 format/preprocess 两个「无专属执行器的类别」）。
# 顺序与 app/services/rule_taxonomy.py::CATEGORY_TO_NATURE 一致（一致性测试逐项核对）。
CATEGORY_ORDER = ("limit", "consistency", "completeness", "format", "preprocess",
                  "record", "prohibited", "frequency", "personnel", "equipment",
                  "label", "citation")
CATEGORY_TO_NATURE = {
    "limit": "threshold",
    "consistency": "relational",
    "completeness": "evidence",
    "format": "procedural",
    "preprocess": "procedural",
    "record": "evidence",
    "prohibited": "obligation",
    "frequency": "procedural",
    "personnel": "evidence",
    "equipment": "evidence",
    "label": "evidence",
    "citation": "relational",
}
# 类别标签：10 类复用模板 name；format/preprocess 保留历史展示名。
_CATEGORY_EXTRA_LABELS = {"format": "格式", "preprocess": "前处理"}


def _build_templates():
    """规范化模板表：补 executor（未显式声明时按 executor_map 兜底）。"""
    rows = []
    for row in _TEMPLATE_ROWS:
        rec = dict(row)
        rec.setdefault("executor", "")
        rows.append(rec)
    return rows


TEMPLATES = _build_templates()
_TEMPLATE_BY_CODE = {t["code"]: t for t in TEMPLATES}
EXECUTOR_TEMPLATE_CODES = tuple(t["code"] for t in TEMPLATES if t.get("executor"))
NL_TEMPLATE_CODES = tuple(t["code"] for t in TEMPLATES if t.get("nl_fillable"))
UI_TEMPLATE_CODES = tuple(t["code"] for t in TEMPLATES if t.get("ui_selectable"))
# 类别→模板自动映射（保持历史口径：只有 10 类 NL 模板会由 category 自动补 _template；
# 执行器专用 2 类不参与该映射，避免改变既有语义/类别 taxonomy）
CATEGORY_TEMPLATE_CODES = NL_TEMPLATE_CODES
EXECUTOR_BY_TEMPLATE = {t["code"]: t["executor"] for t in TEMPLATES if t.get("executor")}

CATEGORIES = {}
for _code in CATEGORY_ORDER:
    _tpl = _TEMPLATE_BY_CODE.get(_code)
    CATEGORIES[_code] = {
        "code": _code,
        "label": (_tpl or {}).get("name") or _CATEGORY_EXTRA_LABELS.get(_code, _code),
        "nature": CATEGORY_TO_NATURE[_code],
        "template": _code if _tpl else "",
        "executor": EXECUTOR_BY_TEMPLATE.get(_code, ""),
        "legacy_no_executor": bool(_code not in _TEMPLATE_BY_CODE),
    }
LEGACY_CATEGORY_CODES = tuple(c for c in CATEGORY_ORDER if c not in _TEMPLATE_BY_CODE)


# ###########################################################################
# 2. 算子（类型驱动 + 中文模态词）
# ###########################################################################
MODALITY = [
    ("不得低于", ">="), ("不得少于", ">="), ("不应低于", ">="), ("不少于", ">="),
    ("不低于", ">="), ("至少", ">="), ("达到", ">="), ("≥", ">="),
    ("不得高于", "<="), ("不得超过", "<="), ("不应高于", "<="), ("不应超过", "<="),
    ("不超过", "<="), ("不高于", "<="), ("≤", "<="),
    ("应为", "="), ("必须为", "="), ("等于", "="),
    ("小于", "<"), ("低于", "<"), ("<", "<"),
    ("大于", ">"), ("高于", ">"), (">", ">"),
]

OPERATORS_BY_TYPE = {
    "number": {">=", "<=", "=", ">", "<", "!=", "range"},
    "date": {"=", "before", "after", "between"},
    "text": {"contains", "not_contains", "=", "!=", "regex"},
    "enum": {"in", "not_in", "=", "!="},
    "boolean": {"=", "!="},
}

# 精确比较算子的写法别名（L62 B3 的 `==`/`≠`/全角＝ 只在 RULEPROOF_OPERATOR_SPEC_FIX=1 时
# 进入执行语义；这里作为 **已知写法** 收录，供保存期写入门判定「是不是已知算子」，
# 不改执行期归一开关语义）。另收录 IR/执行计划层已存在的等价写法（eq/lt/...）。
OPERATOR_ALIASES = {
    "==": "=", "≠": "!=", "＝": "=", "!＝": "!=", "!==": "!=",
    "eq": "=", "equal": "=", "same": "=", "ne": "!=",
    "lt": "<", "le": "<=", "lte": "<=", "gt": ">", "ge": ">=", "gte": ">=",
    "≈": "=",
}
ALL_OPERATORS = frozenset(
    set(OPERATOR_ALIASES) | set(OPERATOR_ALIASES.values())
    | {op for ops in OPERATORS_BY_TYPE.values() for op in ops}
    | {op for _word, op in MODALITY}
)


def normalize_operator(value) -> str:
    """算子写法 → 规范算子码；未知返回空串（不猜）。

    与 rule_ir2.normalize_operator 的区别：本函数用于 **注册表/写入门**，不受
    ``RULEPROOF_OPERATOR_SPEC_FIX`` 开关影响（保存期判定「已知/未知」不随执行开关漂移）；
    执行期仍走 rule_ir2 的开关化归一，判定语义不变。
    """
    s = str(value or "").strip()
    if not s:
        return ""
    # 别名优先返回 canonical 码（== → =、eq → =、≠ → !=），便于写入门/报告统一口径；
    # 执行期 rule_ir2 仍按自己的开关化表处理，不受这里影响。
    if s in OPERATOR_ALIASES:
        return OPERATOR_ALIASES[s]
    if s in ALL_OPERATORS:
        return s
    for word, op in sorted(MODALITY, key=lambda x: -len(x[0])):
        if word in s:
            return op
    return ""


def validate_operator(value) -> tuple:
    """(ok, canonical, reason)：写入门/测试用。"""
    s = str(value or "").strip()
    if not s:
        return True, "", ""
    op = normalize_operator(s)
    if not op:
        return False, "", f"未知算子：{s}"
    return True, op, ""


# ###########################################################################
# 3. 单位（可换算 + 可解析不可换算 + 温度仿射）
# ###########################################################################
# 3.1 基准倍率表（原 ruleexec._UNIT_SCALE：基准 min / g / ml / mm / 元 / ...）
UNIT_SCALE_BASE = {
    "亿元": 100000000, "亿": 100000000, "万元": 10000, "万": 10000,
    "千元": 1000, "百万元": 1000000, "元": 1, "%": 1, "％": 1, "℃": 1,
    "天": 1440, "日": 1440, "小时": 60, "h": 60, "分钟": 1, "min": 1,
    "g": 1, "克": 1, "kg": 1000, "千克": 1000, "t": 1000000, "吨": 1000000,
    "mg": 0.001, "毫克": 0.001, "μg": 0.000001, "µg": 0.000001,
    "mg/kg": 1, "mg/g": 1000, "g/kg": 1000, "μg/kg": 0.001, "µg/kg": 0.001,
    "g/100g": 10000, "g/100mL": 10000, "g/100ml": 10000,
    "mg/L": 1, "mg/l": 1, "g/L": 1000, "g/l": 1000,
    "μg/L": 0.001, "µg/L": 0.001, "μg/l": 0.001, "µg/l": 0.001,
    "CFU/g": 1, "CFU/ml": 1, "CFU/mL": 1, "个/g": 1, "个/mL": 1,
    "%(w/w)": 10000,
    "ml": 1, "mL": 1, "毫升": 1, "L": 1000, "升": 1000,
    "mm": 1, "毫米": 1, "cm": 10, "厘米": 10, "m": 1000, "米": 1000,
}

# 3.2 压力维度（基准 Pa；登记规范写法，大小写/中文别名由归一入口处理）。
PRESSURE_UNIT = {
    "Pa": 1, "帕": 1, "帕斯卡": 1,
    "hPa": 100, "百帕": 100, "百帕斯卡": 100,
    "kPa": 1000, "千帕": 1000, "千帕斯卡": 1000,
    "MPa": 1000000, "兆帕": 1000000, "兆帕斯卡": 1000000,
    "bar": 100000, "巴": 100000,
    "mbar": 100, "毫巴": 100,
}

# 3.3 L39 执行器 P0 修复：时间 s/秒、浓度 ppm/ppb/ug/kg、全角兼容字符（基准 min / mg/kg / 对应基本单位）
UNIT_SCALE_FIX2 = {
    "s": 1.0 / 60.0, "秒": 1.0 / 60.0,
    "ppm": 1.0, "PPM": 1.0, "ppb": 0.001, "PPB": 0.001, "ug/kg": 0.001,
    "㎏": 1000.0, "㎎": 0.001, "㎝": 10.0, "㎜": 1.0, "㎖": 1.0, "㎥": 1000.0,
}
UNIT_DIM_FIX2 = {
    "s": "time", "秒": "time",
    "ppm": "conc", "PPM": "conc", "ppb": "conc", "PPB": "conc", "ug/kg": "conc",
    "㎏": "mass", "㎎": "mass", "㎝": "len", "㎜": "len", "㎖": "vol", "㎥": "vol",
}

# 3.4 L42 执行器对象绑定修复：件/次/秒（计数单位 + 秒可换算；引文切片包含单位）
UNIT_SCALE_V3 = {"件": 1.0, "次": 1.0, "秒": 1.0 / 60.0}
UNIT_DIM_V3 = {"件": "count", "次": "count", "秒": "time"}

# 3.5 温度（F↔C 是仿射变换，不能放进乘法表；统一基准 ℃）
TEMP_UNIT = {"℃": "C", "°C": "C", "摄氏度": "C",
             "℉": "F", "°F": "F", "华氏度": "F", "华氏": "F"}
# 「度」= 摄氏度只在 L39 temp_degree 项开启时生效（执行期脚标保留在 ruleexec）
TEMP_DEGREE_ALIAS = "度"

# 3.6 中文/符号写法归一（原 rule_schema._UNIT_CANON，含 2026-11-21「个日历天」事故注释）
UNIT_CANON = {
    "个日历天": "天", "日历天": "天", "日": "天", "个工作日": "天", "工作日": "天", "d": "天",
    "个月": "月", "个": "", "次": "", "倍": "", "份": "", "批": "", "件": "", "台": "",
    "套": "", "人次": "", "级": "", "度": "℃", "摄氏度": "℃", "％": "%",
    # 中文单位↔符号等价（LaneQ 2026-11-23）：执行器单位注册表两种写法都认，统一成符号写法。
    "时": "h", "分": "min", "千克": "kg", "公斤": "kg", "克": "g", "毫克": "mg",
    "毫升": "ml", "升": "L", "l": "L",
}

# 3.7 NL 限值解析的长单位优先词表（原 rule_schema._UNITS 的字面集合，顺序无关、
# 由调用方 sorted(set(...), key=len) 处理；与迁移前逐项一致）。
NL_UNIT_WORDS = (
    "个百分点", "个日历天", "元/吨", "元/件", "吨/小时", "吨/天", "m³/h", "m3/h",
    "L/m²·d", "kWh/吨", "g/100g", "g/100mL", "g/100ml", "mg/100kg", "mg/kg", "mg/L",
    "mg/l", "mg/m³", "mg/m3", "μg/kg", "μg/L", "CFU/g", "cfu/g", "CFU/mL", "cfu/ml",
    "MPN/g", "亿元", "百万元", "千元", "万元", "万", "元", "ppm", "ppb", "dB(A)", "dB",
    "MPa", "kPa", "Pa", "kV", "kW", "Hz", "个月", "日历天", "小时", "分钟", "min",
    "年", "月", "天", "日", "秒", "件", "个", "次", "倍", "级", "份", "批", "台",
    "套", "人次", "分", "吨", "千克", "公斤", "kg", "克", "毫克", "微克", "g", "mg",
    "μg", "ug", "升", "毫升", "mL", "ml", "立方米", "L", "l", "m³", "m3", "℃", "°C",
    "摄氏度", "度", "%", "％", "时", "d",
)

# 3.8 跨行/跨表汇总的补充倍率（原 ruleexec._CROSS_EXTRA_SCALE）
CROSS_EXTRA_SCALE = {
    "亿元": 100000000.0, "亿": 100000000.0, "‰": 0.1,
    "CNY": 1.0, "RMB": 1.0, "人民币": 1.0,
    "美元": 1.0, "USD": 1.0, "港元": 1.0, "HKD": 1.0,
    "欧元": 1.0, "EUR": 1.0,
    "秒": 1.0 / 60.0, "s": 1.0 / 60.0,
    "个": 1.0, "件": 1.0, "套": 1.0, "台": 1.0, "处": 1.0, "根": 1.0,
    "张": 1.0, "份": 1.0, "组": 1.0, "批": 1.0, "次": 1.0,
}

# 3.9 可解析但不可换算的历史文本单位（services/rule.py 的 NL 数值解析器会产出；
# 注册表登记为「已知单位、不可换算」→ 写入门接受、执行期沿用 P0-A 证据不足）。
LEGACY_TEXT_UNITS = (
    "元/千克", "元/公斤", "吨/年", "m³/s", "m3/s", "l/m²·d", "kwh/吨",
    "mg/100g", "MPN/100g", "CFU/ml", "角", "μg/kg", "ug/L", "μg/L",
    "个工作日", "工作日", "dB(A)", "kV", "kW", "Hz", "立方米", "个百分点",
)

# 压力 ASCII 大小写归一（只对压力单位生效，不扩散到其他单位）
PRESSURE_ASCII_CANON = {"pa": "Pa", "hpa": "hPa", "kpa": "kPa",
                        "mpa": "MPa", "bar": "bar", "mbar": "mbar"}

# 统一入口的规范写法（registry.normalize_unit 返回这些 canonical token；执行期
# ruleexec._unit_key 保留各自历史写法以避免改动执行口径，二者数值/量纲等价）。
UNIT_NORMALIZE_ALIASES = {
    "PPM": "ppm", "PPB": "ppb",
    "°C": "℃", "°c": "℃", "摄氏度": "℃",
    "°F": "℉", "°f": "℉", "华氏度": "℉", "华氏": "℉",
    "㎏": "kg", "㎎": "mg", "㎝": "cm", "㎜": "mm", "㎖": "ml", "㎥": "m³",
    "µg": "μg", "µL": "μL",
}

_UNIT_SPACE_RE = re.compile(r"\s+")


def _all_scale_tables():
    return (UNIT_SCALE_BASE, PRESSURE_UNIT, UNIT_SCALE_FIX2, UNIT_SCALE_V3)


def known_unit_tokens() -> frozenset:
    """写入门接受的单位 token 集合（可换算 + 可解析不可换算 + 中文归一别名/目标）。"""
    tokens = set()
    for table in _all_scale_tables():
        tokens |= set(table)
    tokens |= set(TEMP_UNIT)
    tokens |= set(UNIT_CANON)
    tokens |= {v for v in UNIT_CANON.values() if v}
    tokens |= set(NL_UNIT_WORDS)
    tokens |= set(CROSS_EXTRA_SCALE)
    tokens |= set(LEGACY_TEXT_UNITS)
    tokens.add(TEMP_DEGREE_ALIAS)
    return frozenset(t for t in tokens if t)


KNOWN_UNIT_TOKENS = known_unit_tokens()


def _unit_lookup_raw(raw: str):
    """未开关化的单位查找：返回 (规范键, 层) 或 ("", "")。不猜跨量纲。"""
    s = str(raw or "").strip()
    if not s:
        return "", ""
    if s in UNIT_SCALE_BASE or s in PRESSURE_UNIT:
        return s, "base"
    compact = _UNIT_SPACE_RE.sub("", s)
    if compact in UNIT_SCALE_BASE or compact in PRESSURE_UNIT:
        return compact, "base"
    if compact.lower() in PRESSURE_ASCII_CANON:
        return PRESSURE_ASCII_CANON[compact.lower()], "base"
    if compact in UNIT_SCALE_FIX2:
        return compact, "fix2"
    if compact in TEMP_UNIT:
        return compact, "temp"
    if compact in UNIT_SCALE_V3:
        return compact, "v3"
    # 兼容字符/全角 NFKC（与执行期 L39 ③ 同口径，但这里不受开关影响，属于「已知写法」）
    try:
        import unicodedata
        nf = unicodedata.normalize("NFKC", compact)
    except Exception:  # noqa: BLE001 - 归一失败按未登记处理，不猜
        nf = compact
    for key in (nf, nf.lower()):
        if key in UNIT_SCALE_FIX2:
            return key, "fix2"
        if key in UNIT_SCALE_BASE:
            return key, "base"
        if key in TEMP_UNIT:
            return key, "temp"
        if key in UNIT_SCALE_V3:
            return key, "v3"
    return "", ""


def normalize_unit(raw) -> str:
    """单位写法规格化：中文/符号等价与别名 → 规范键；未登记返回空串（不猜）。

    - 中文/符号别名走 ``UNIT_CANON``（如 个日历天→天、千克→kg、度→℃）；
    - 可换算单位返回注册表规范键（ppm/PPM→ppm、kpa→kPa、℉→℉…）；
    - 解析器可产出但不可换算的历史单位原样返回（调用方按「已知不可换算」处理）；
    - 完全未登记返回空串。
    """
    s = str(raw or "").strip()
    if not s:
        return ""
    if s in UNIT_CANON:
        return UNIT_CANON[s]
    key, _layer = _unit_lookup_raw(s)
    if key:
        return UNIT_NORMALIZE_ALIASES.get(key, key)
    if s in NL_UNIT_WORDS or s in LEGACY_TEXT_UNITS or s in CROSS_EXTRA_SCALE:
        return s
    return ""


def unit_scale(raw):
    """换算倍率（基准：min/g/ml/mm/Pa/元/℃）；不可换算/未登记返回 None。"""
    key = normalize_unit(raw)
    if not key:
        return None
    for table in _all_scale_tables():
        if key in table:
            return table[key]
    return None


def unit_dim(raw) -> str:
    """量纲：money/mass/vol/len/time/conc/pressure/temp/count；未知返回空串。"""
    key = normalize_unit(raw)
    if not key:
        return ""
    if key in UNIT_DIM_FIX2:
        return UNIT_DIM_FIX2[key]
    if key in UNIT_DIM_V3:
        return UNIT_DIM_V3[key]
    if key in TEMP_UNIT:
        return "temp"
    if key in PRESSURE_UNIT:
        return "pressure"
    if key in ("%", "％"):
        return "ratio"
    if key in ("天", "日", "小时", "h", "分钟", "min", "个月", "年", "月"):
        return "time"
    if key in ("g", "kg", "mg", "μg", "µg", "t", "克", "千克", "吨", "毫克", "微克",
               "mm", "cm", "m", "毫米", "厘米", "米",
               "mg/kg", "mg/g", "g/kg", "g/100g", "g/100mL", "g/100ml",
               "μg/kg", "µg/kg", "CFU/g", "CFU/ml", "CFU/mL", "个/g", "个/mL"):
        return "mass"
    if key in ("ml", "mL", "L", "升", "毫升", "g/L", "g/l", "mg/L", "mg/l",
               "μg/L", "µg/L", "μg/l", "µg/l"):
        return "vol"
    if key in ("元", "万元", "亿元", "亿", "千元", "百万元", "CNY", "RMB", "美元",
               "USD", "港元", "HKD", "欧元", "EUR", "人民币"):
        return "money"
    if key in ("件", "次", "个", "套", "台", "处", "根", "张", "份", "组", "批"):
        return "count"
    return ""


def unit_known(raw) -> bool:
    """是否登记单位（含可解析不可换算的历史文本单位）。空单位视为已声明。"""
    s = str(raw or "").strip()
    if not s:
        return True
    return normalize_unit(s) != "" or s in KNOWN_UNIT_TOKENS


def validate_unit(raw) -> tuple:
    """(ok, canonical, reason)：写入门/测试用。空单位返回 ok=True。"""
    s = str(raw or "").strip()
    if not s:
        return True, "", ""
    canon = normalize_unit(s)
    if canon or s in KNOWN_UNIT_TOKENS:
        return True, canon or s, ""
    return False, "", f"未知单位：{s}"


def temp_to_c(value, raw):
    """温度 → 摄氏；不是温度单位/不可解析返回 None（供测试/写入门辅助）。"""
    key = normalize_unit(raw)
    kind = TEMP_UNIT.get(key) if key else None
    if kind is None and str(raw or "").strip() == TEMP_DEGREE_ALIAS:
        kind = "C"
    if kind is None:
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if kind == "F":
        return (v - 32.0) * 5.0 / 9.0
    return v


# ###########################################################################
# 4. 投影/查询（下游模块引用这些，不直接改上面的表）
# ###########################################################################
def template(code):
    """模板记录（不存在返回 None）。"""
    return _TEMPLATE_BY_CODE.get(str(code or "").strip())


def template_codes() -> tuple:
    """12 类可执行模板 codes（顺序固定）。"""
    return EXECUTOR_TEMPLATE_CODES




def canonical_template(code) -> str:
    """模板写法 → canonical code；未知返回空串。"""
    c = str(code or "").strip().lower()
    if c in _TEMPLATE_BY_CODE:
        return c
    return TEMPLATE_ALIASES.get(c, "")


def validate_template(code) -> tuple:
    """(ok, canonical, reason)：写入门/测试用。空模板视为没有模板。"""
    c = str(code or "").strip()
    if not c:
        return True, "", ""
    canon = canonical_template(c)
    if canon:
        return True, canon, ""
    return False, "", f"未知模板：{c}"


def nl_templates() -> list:
    """10 类 NL 填槽模板（rule_schema.TEMPLATES 投影；逐项返回副本）。"""
    return [dict(t) for t in TEMPLATES if t.get("nl_fillable")]


def ui_templates() -> list:
    """可在新建表单选择的模板（当前 = 10 类；2 类执行器专用仅 API/导入）。"""
    return [dict(t) for t in TEMPLATES if t.get("ui_selectable")]


def executor_map() -> dict:
    """模板 → 执行器（rule_schema.EXECUTOR_BY_TEMPLATE 投影）。"""
    return dict(EXECUTOR_BY_TEMPLATE)




# ###########################################################################
# 5. 写入门（L79 §2）
# ###########################################################################
_FALSE_TOKENS = {"0", "false", "off", "no", "none", "disabled"}


def write_gate_enabled() -> bool:
    """RULEPROOF_RULE_WRITE_GATE 开关：默认 1；0/false/off/no/none 回退旧行为。"""
    raw = str(os.environ.get("RULEPROOF_RULE_WRITE_GATE", "1")).strip().lower()
    return raw not in _FALSE_TOKENS


def validate_write(category: str, slots: dict) -> dict:
    """保存/导入前置校验（不影响发布门 executor_reachable）。

    只校验 **显式声明** 的模板/算子/单位（不猜、不补全、不改写 slots）：
      ① ``slots._template`` 非空且不是登记模板/执行器别名 → unsupported_template；
      ② ``slots.op`` / ``slots.operator`` 非空且归一不回来 → unsupported_operator；
      ③ ``slots.unit`` 非空且未登记 → unsupported_unit。
    返回 ``{"ok": True, "template": ..., "operator": ..., "unit": ...}``；
    失败抛 :class:`RuleWriteGateError`（``.code`` 供 HTTP 400 使用）。
    """
    slots = dict(slots or {})
    out = {"ok": True, "template": "", "operator": "", "unit": ""}
    raw_tpl = str(slots.get("_template") or "").strip()
    if raw_tpl:
        ok, canon, why = validate_template(raw_tpl)
        if not ok:
            raise RuleWriteGateError("unsupported_template",
                                     f"{why}（写入门 unsupported_template）")
        out["template"] = canon
    raw_op = str(slots.get("operator") or slots.get("op") or "").strip()
    if raw_op:
        ok, canon, why = validate_operator(raw_op)
        if not ok:
            raise RuleWriteGateError("unsupported_operator",
                                     f"{why}（写入门 unsupported_operator）")
        out["operator"] = canon
    raw_unit = str(slots.get("unit") or "").strip()
    if raw_unit:
        ok, canon, why = validate_unit(raw_unit)
        if not ok:
            raise RuleWriteGateError("unsupported_unit",
                                     f"{why}（写入门 unsupported_unit）")
        out["unit"] = canon
    # category 只做回显（历史允许「客户沉淀/通用」等非模板类别，不能在此拒绝）
    out["category"] = str(category or "")
    return out


# ###########################################################################
# 6. 指纹 / 快照
# ###########################################################################
def _unit_payload():
    rows = []
    for token in sorted(KNOWN_UNIT_TOKENS):
        rows.append({
            "token": token,
            "canonical": normalize_unit(token),
            "scale": unit_scale(token),
            "dim": unit_dim(token),
        })
    return rows


def canonical_payload() -> dict:
    """规范化 payload（fingerprint 与 artifact 快照同源；与运行期开关无关）。"""
    return {
        "registry_version": REGISTRY_VERSION,
        "templates": [
            {
                "code": t["code"], "name": t["name"], "rclass": t["rclass"],
                "executor": t["executor"], "slots": list(t.get("slots") or []),
                "evidence": list(t.get("evidence") or []),
                "nl_fillable": bool(t.get("nl_fillable")),
                "ui_selectable": bool(t.get("ui_selectable")),
            }
            for t in TEMPLATES
        ],
        "legacy_categories": list(LEGACY_CATEGORY_CODES),
        "categories": [dict(CATEGORIES[c]) for c in CATEGORY_ORDER],
        "executors": sorted(EXECUTORS),
        "operators_by_type": {k: sorted(v) for k, v in sorted(OPERATORS_BY_TYPE.items())},
        "modality": [list(x) for x in MODALITY],
        "operator_aliases": dict(sorted(OPERATOR_ALIASES.items())),
        "unit_canon": dict(sorted(UNIT_CANON.items())),
        "nl_unit_words": sorted(set(NL_UNIT_WORDS)),
        "units": _unit_payload(),
        "cross_extra_scale": {k: v for k, v in sorted(CROSS_EXTRA_SCALE.items())},
    }


def _dump_payload(payload) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


_FP_CACHE = {}


def fingerprint() -> str:
    """单一真相源内容指纹（SHA256，稳定；不随 RULEPROOF_* 开关变化）。"""
    if "fp" not in _FP_CACHE:
        _FP_CACHE["fp"] = hashlib.sha256(
            _dump_payload(canonical_payload()).encode("utf-8")).hexdigest()
    return _FP_CACHE["fp"]


def snapshot() -> dict:
    """机读快照（报告/artifacts 用）：指纹 + 三源投影计数 + 单位/算子统计。"""
    return {
        "registry_version": REGISTRY_VERSION,
        "fingerprint": fingerprint(),
        "templates_total": len(TEMPLATES),
        "executor_templates": len(EXECUTOR_TEMPLATE_CODES),
        "nl_templates": len(NL_TEMPLATE_CODES),
        "ui_templates": len(UI_TEMPLATE_CODES),
        "legacy_categories": list(LEGACY_CATEGORY_CODES),
        "categories": len(CATEGORY_ORDER),
        "executors": sorted(EXECUTORS),
        "operators": len(ALL_OPERATORS),
        "operator_types": {k: len(v) for k, v in OPERATORS_BY_TYPE.items()},
        "modality": len(MODALITY),
        "units_total": len(KNOWN_UNIT_TOKENS),
        "units_convertible": sum(1 for t in KNOWN_UNIT_TOKENS if unit_scale(t) is not None),
        "units_text_only": sum(1 for t in KNOWN_UNIT_TOKENS
                               if unit_scale(t) is None and unit_dim(t) == ""),
        "write_gate_env": WRITE_GATE_ENV,
        "write_gate_default": True,
    }
