# -*- coding: utf-8 -*-
"""确定性反译 renderer + 语义 diff（IR ↔ 原文互证，无随机、0 模型调用）。

`back_translate` 把 IR 渲染回中文；`semantic_diff` 用独立 shadow 抽取器从原文
重取核心槽位，叠加 span 逐字校验与「反译回环」，输出一致率。
一致率是确定性自洽口径，不是人工标注 faithful 率（L63 §5.3 边界）。

来源：L63 原型（规格 82 号 §4）；L73 接入 lane 原样生产化。
"""
from __future__ import annotations

import re

from .policy_ir import (RENDERER_VERSION, _nm, _norm, _norm_unit, to_base)
from .policy_templates import (compile_rule, shadow_slots)

_OP_WORD = {">=": "不得少于", "<=": "不得超过", "=": "应等于", "<": "小于", ">": "大于",
            "!=": "不得等于"}
_DATE_OP_WORD = {"before": "不得晚于", "after": "不得早于", "=": "应等于",
                 "between": "应在区间"}

def _render_declared(ir):
    parts = []
    exc = ir.get("exceptions") or {}
    if exc.get("declared"):
        for item in exc.get("items", []):
            parts.append("例外：" + item["condition"])
    ev = ir.get("evidence") or {}
    if ev.get("declared"):
        seg = "证据：" + (ev.get("source") or "原文")
        if ev.get("min_count"):
            seg += f"，至少{ev['min_count']}条"
        parts.append(seg)
    cq = ir.get("consequence") or {}
    if cq.get("declared"):
        segs = []
        for key, label in (("label", "后果"), ("action", "处置"),
                           ("owner", "责任"), ("close_condition", "关闭条件")):
            if cq.get(key):
                segs.append(f"{label}：{cq[key]}")
        if segs:
            parts.append("，".join(segs))
    return "；" + "；".join(parts) if parts else ""


def _render_condition(ir):
    rtype = ir["rule_type"]
    cond = ir["condition"]
    obj = ir.get("subject", {}).get("object") or ""
    prefix = f"在{obj}范围内，" if obj and rtype != "unit" else ""
    if rtype == "limit":
        word = _OP_WORD.get(cond["operator"], cond.get("op_text", "应满足"))
        incl = "（含边界）" if cond.get("inclusive") else "（不含边界）"
        return f"{prefix}{ir['metric']['name']}{word}{_nm(cond['value'])}{cond['unit']}{incl}"
    if rtype == "date":
        if cond["kind"] == "date_absolute":
            word = _DATE_OP_WORD.get(cond["operator"], "不得晚于")
            return f"{ir['metric']['name']}{word}{cond['date']}（含边界）"
        word = _OP_WORD.get(cond["operator"], cond.get("op_text", "应满足"))
        incl = "（含边界）" if cond.get("inclusive") else "（不含边界）"
        return f"{prefix}{ir['metric']['name']}{word}{_nm(cond['value'])}{cond['unit']}{incl}"
    if rtype == "consistency":
        if cond["kind"] == "equality":
            return f"{prefix}{cond['left']}与{cond['right']}应一致"
        word = _OP_WORD.get(cond["operator"], "不得超过")
        return (f"{prefix}{cond['left']}与{cond['right']}的{cond['tolerance_kind']}"
                f"绝对值{word}{_nm(cond['value'])}{cond['unit']}")
    if rtype == "prohibited":
        return f"{obj}{cond['modal']}{'、'.join(cond['forbidden'])}"
    if rtype == "completeness":
        joiner = "或" if cond.get("match_mode") == "any" else "、"
        return f"{obj}{cond['modal']}{joiner.join(cond['required'])}"
    if rtype == "unit":
        if cond["kind"] == "conversion":
            return f"1 {cond['from_unit']} = {_nm(cond['factor'])} {cond['to_unit']}"
        seg = f"{obj}一律以{cond['unit']}为单位"
        if cond.get("decimals") is not None:
            seg += f"，保留{cond['decimals']}位小数"
        return seg
    raise ValueError("unknown rule_type: " + rtype)


def back_translate(ir, llm_votes=None, renderer_meta=None) -> dict:
    """IR → 自然语言。

    llm_votes：**已录制**的独立 LLM 反译文本列表（本原型不发任何模型调用；仅做多票聚合）。
      - 未传：确定性 renderer，mode="deterministic"，needs_human=False；
      - 传入：与确定性 renderer 比对，多数票与确定性 renderer 一致且 ≥2/3 → consistent；
              任何不一致 → needs_human=True（不得自动放行）。
    """
    text = _render_condition(ir) + _render_declared(ir) + "。"
    out = {
        "schema_version": "policy-render/v1",
        "renderer_version": RENDERER_VERSION,
        "mode": "deterministic",
        "text": text,
        "model_calls": 0,
        "needs_human": False,
        "votes": [],
        "confidence": 1.0,
    }
    if llm_votes:
        votes = []
        agree = 0
        for v in llm_votes:
            same = _norm(str(v)) == _norm(text)
            votes.append({"text": str(v), "agrees_with_renderer": same})
            agree += 1 if same else 0
        n = len(votes)
        out["mode"] = "deterministic+recorded_votes"
        out["votes"] = votes
        out["confidence"] = round(agree / n, 4)
        if agree < 2 and n >= 2:
            out["needs_human"] = True
        if agree != n:
            out["needs_human"] = True
    if renderer_meta:
        out["renderer_meta"] = dict(renderer_meta)
    return out

def _canonical_slot(ir):
    """从 IR 取与 shadow 同构的核心槽位向量。"""
    cond = ir.get("condition") or {}
    rtype = ir.get("rule_type")
    out = {"rule_type": rtype}
    if rtype == "limit":
        out.update({"op": cond.get("operator"), "value": _nm(cond.get("value")),
                    "unit": cond.get("unit")})
    elif rtype == "date":
        if cond.get("kind") == "date_absolute":
            out.update({"date": cond.get("date"), "op": cond.get("operator")})
        else:
            out.update({"op": cond.get("operator"), "value": _nm(cond.get("value")),
                        "unit": cond.get("unit")})
    elif rtype == "consistency":
        if cond.get("kind") == "equality":
            out.update({"kind": "equality", "op": cond.get("operator"),
                        "left": cond.get("left"), "right": cond.get("right")})
        else:
            out.update({"kind": "tolerance", "op": cond.get("operator"),
                        "value": _nm(cond.get("value")), "unit": cond.get("unit")})
    elif rtype == "prohibited":
        out.update({"forbidden": cond.get("forbidden")})
    elif rtype == "completeness":
        out.update({"required": cond.get("required"),
                    "match_mode": cond.get("match_mode")})
    elif rtype == "unit":
        if cond.get("kind") == "conversion":
            out.update({"kind": "conversion", "from_unit": cond.get("from_unit"),
                        "to_unit": cond.get("to_unit"), "factor": _nm(cond.get("factor"))})
        else:
            out.update({"kind": "rounding", "decimals": cond.get("decimals"),
                        "unit": cond.get("unit")})
    return out


def unit_equiv(raw_a, raw_b):
    """单位等价：同写法；或同维度且可换算（canonical 相同）。计数单位不可互换。"""
    if _norm(raw_a) == _norm(raw_b):
        return True
    ea, eb = _norm_unit(raw_a), _norm_unit(raw_b)
    if not ea or not eb:
        return False
    if ea["dim"] == "count":
        return False
    return ea["canonical"] == eb["canonical"] and ea["dim"] == eb["dim"]


def _slots_equal(a, b):
    """槽位等值比较：字符串归一；数值按单位维度换算后比较（允许单位别名）。"""
    if isinstance(a, list) and isinstance(b, list):
        return sorted(_norm(x) for x in a) == sorted(_norm(x) for x in b)
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(a - b) < 1e-9
    return _norm(a) == _norm(b)


def semantic_diff(ir, text) -> dict:
    """IR ↔ 原文 槽位级一致性 + 反译回环（必须全部满足才 consistent）。

    返回 {"consistent","ratio","matched","total","critical_diffs","warnings",
          "roundtrip_ok","span_ok"}。
    """
    warnings, diffs = [], []
    shadow = shadow_slots(text)
    cand = _canonical_slot(ir)
    if shadow["rule_type"] != cand["rule_type"]:
        diffs.append({"slot": "rule_type", "ir": cand["rule_type"],
                      "text": shadow["rule_type"], "severity": "critical"})
    total = shadow.get("critical_total", 0)
    matched = 0
    keys = [k for k in cand if k != "rule_type"]
    for key in keys:
        iv, tv = cand.get(key), shadow.get(key)
        if key in ("unit",) and iv and tv:
            if unit_equiv(iv, tv):
                matched += 1
                if _norm(iv) != _norm(tv):
                    warnings.append({"slot": "unit", "message": f"单位别名：{iv} ≡ {tv}"})
                continue
        if key in ("value",) and isinstance(iv, (int, float)) and isinstance(tv, (int, float)):
            iu, tu = cand.get("unit"), shadow.get("unit") or cand.get("unit")
            if iu and tu and unit_equiv(iu, tu):
                iv_base = to_base(float(iv), iu)
                tv_base = to_base(float(tv), tu)
                if iv_base is not None and tv_base is not None and abs(iv_base - tv_base) < 1e-9:
                    matched += 1
                    continue
        if _slots_equal(iv, tv):
            matched += 1
        else:
            diffs.append({"slot": key, "ir": iv, "text": tv, "severity": "critical"})
    # span 逐字校验（以 IR 自带 source.text 为参照：跨文本互证时不误报 span）
    ref_text = (ir.get("source") or {}).get("text", text)
    span_ok = True
    for name, span in (ir.get("condition_spans") or {}).items():
        if not span:
            continue
        got = ref_text[span["start"]:span["end"]]
        if got != span["text"] or span["text"] not in ref_text:
            span_ok = False
            diffs.append({"slot": f"span:{name}", "ir": span["text"], "text": got,
                          "severity": "critical"})
    # 反译回环：IR → 文本 → 再编译 → 核心槽位等值
    rendered = back_translate(ir)["text"]
    recomp = compile_rule(rendered)
    roundtrip_ok = False
    roundtrip_detail = None
    if recomp["status"] == "compiled":
        re_slots = _canonical_slot(recomp["ir"])
        diffs_rt = [k for k in cand if not _slots_equal(cand.get(k), re_slots.get(k))]
        roundtrip_ok = not diffs_rt
        if diffs_rt:
            roundtrip_detail = diffs_rt
    else:
        roundtrip_detail = ["recompile_rejected:" + recomp["errors"][0]["code"]]
    if not roundtrip_ok:
        diffs.append({"slot": "roundtrip", "ir": cand, "text": roundtrip_detail,
                      "severity": "critical"})
    total_eff = len(keys) + 1  # 实际比较槽位数 + 回环
    matched_eff = matched + (1 if roundtrip_ok else 0)
    critical = [d for d in diffs if d["severity"] == "critical"]
    ratio = round(matched_eff / total_eff, 4) if total_eff else 1.0
    return {"consistent": not critical, "ratio": ratio, "matched": matched_eff,
            "total": total_eff, "critical_diffs": critical, "warnings": warnings,
            "roundtrip_ok": roundtrip_ok, "span_ok": span_ok,
            "back_translation": rendered, "shadow_slots": shadow,
            "ir_slots": cand, "renderer_version": RENDERER_VERSION}
