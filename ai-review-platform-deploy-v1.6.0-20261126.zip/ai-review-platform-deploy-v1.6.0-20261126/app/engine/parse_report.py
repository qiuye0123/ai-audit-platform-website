"""解析报告：量化解析完整度，并给出“未完整解析”的具体原因（供客户查看）。"""
import logging
import os

from . import deepparse


def _xlsx(path):
    from openpyxl import load_workbook
    gaps, rows_total, cells = [], 0, 0
    wb = load_workbook(path, data_only=True)
    for ws in wb.worksheets:
        n = 0
        for row in ws.iter_rows(values_only=True):
            if any(v is not None for v in row):
                n += 1
                cells += sum(1 for v in row if v is not None)
        rows_total += n
        if n == 0:
            gaps.append(f"工作表「{ws.title}」为空")
        elif n < 5:
            gaps.append(f"工作表「{ws.title}」仅 {n} 行有效数据，可能未解析完整")
    return {"sheets": len(wb.worksheets), "rows": rows_total, "cells": cells}, gaps


def _docx(path):
    from docx import Document
    d = Document(path)
    paras = [p for p in d.paragraphs if (p.text or "").strip()]
    chars = sum(len(p.text or "") for p in paras)
    gaps = []
    # F-01：区分“抽取失败”与“文档本来就短”。短文档只要真实抽到文本（段落/表格），
    # 就不是解析缺口；只有完全没有段落文本且无表格时才提示图片型文档。
    if not paras and not len(d.tables):
        gaps.append("未解析到段落/表格文本，可能是图片型文档")
    return {"paragraphs": len(paras), "chars": chars, "tables": len(d.tables)}, gaps


def _pdf(path):
    from pypdf import PdfReader
    r = PdfReader(path)
    empty, chars = 0, 0
    for pg in r.pages:
        t = pg.extract_text() or ""
        chars += len(t)
        if not t.strip():
            empty += 1
    gaps = []
    if empty:
        gaps.append(f"{empty}/{len(r.pages)} 页无可提取文本，疑似扫描件，需要 OCR")
    return {"pages": len(r.pages), "chars": chars, "empty_pages": empty}, gaps


def _md(path):
    txt = open(path, encoding="utf-8", errors="ignore").read()
    lines = [l for l in txt.splitlines() if l.strip()]
    gaps = []
    if len(lines) < 20:
        gaps.append("文本行数极少，可能内容不完整")
    return {"lines": len(lines), "chars": len(txt)}, gaps


def report(path: str, display_name: str = "", parsed=None) -> dict:
    """解析报告。

    ``parsed``：调用方已经过统一解析入口（``services.parse_bridge.parse_document``）
    解析好的 ``ParsedDoc``。给定时本函数不再调用 ``deepparse.parse_document``，
    避免同一文件在一次审核内被完整解析两次（L149）；缺省 None 保持原行为
    （本函数内直连解析）。只读取 ``text``/``sections``，不改变任何 gap/status 语义。
    """
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    detail, gaps = {}, []
    # T-148：扫描件（PDF 无文本层）的 OCR 能力状态。渲染器不可用时把诊断信息写进
    # gaps（上层据此落 partial + 原因），并在返回里带 ocr_capability / ocr_unavailable 标志；
    # 不新增/不改 parse_status 的 ok/partial/failed 语义。
    ocr_capability, ocr_unavailable = {}, False
    try:
        if ext in ("xlsx", "xls"):
            detail, gaps = _xlsx(path)
        elif ext == "docx":
            detail, gaps = _docx(path)
        elif ext == "pdf":
            detail, gaps = _pdf(path)
            if detail and not detail.get("chars"):
                try:
                    from . import ocr as _ocr
                    _cap = _ocr.pdf_render_capability()
                    ocr_capability = {k: _cap.get(k) for k in
                                      ("status", "available", "source", "reason", "hint")
                                      if k in _cap}
                    if _cap.get("available") is False:
                        ocr_unavailable = True
                        _hint = str(_cap.get("hint") or "").strip()
                        # 优先用第一个失败渲染器的原始原因（含 dlopen/libpdfium.dylib/
                        # code signature 等可诊断文本），避免被汇总前缀挤出摘要截断窗口。
                        _srcs = [s for s in (_cap.get("sources") or [])
                                 if isinstance(s, dict) and s.get("available") is False]
                        _reason = str((_srcs[0].get("reason") if _srcs else "")
                                      or _cap.get("reason") or "").strip()
                        gaps.insert(0, (
                            "[OCR 能力不可用] 需要 OCR 但 PDF 渲染能力不可用"
                            + (f"（{_hint}）" if _hint else "") + "：" + _reason)[:420])
                except Exception:  # noqa: BLE001 - 能力探测失败不能吞掉已有解析缺口
                    logging.getLogger(__name__).warning(
                        "pdf render capability probe failed", exc_info=True)
        elif ext in ("md", "txt"):
            detail, gaps = _md(path)
        else:
            gaps.append(f"未支持的格式：{ext}（将按纯文本处理，可能丢失结构）")
        doc = parsed if parsed is not None else deepparse.parse_document(path)
        sections = len(getattr(doc, "sections", []) or [])
        chars = len(getattr(doc, "text", "") or "")
        if sections == 0:
            gaps.append("未解析出任何结构块")
        # 只要有格式级详情（能打开、知道有几张表/几页），就算 partial 而不是 failed
        status = "full" if not gaps else ("partial" if (sections or detail) else "failed")
        return {"file": display_name or os.path.basename(path), "ext": ext, "status": status,
                "sections": sections, "chars": chars, "detail": detail, "gaps": gaps,
                "ocr_capability": ocr_capability, "ocr_unavailable": ocr_unavailable}
    except Exception as e:  # noqa
        return {"file": display_name or os.path.basename(path), "ext": ext, "status": "failed",
                "sections": 0, "chars": 0, "detail": detail,
                "gaps": [f"{type(e).__name__}: {str(e)[:120]}"],
                "ocr_capability": ocr_capability, "ocr_unavailable": ocr_unavailable}
