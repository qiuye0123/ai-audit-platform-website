"""
内置规则定义（单一事实源）。

种子(seed)、引擎(engine)、可解释(explain)、前端全部引用这里，不再各自硬编码。
code 是唯一键；category 对应 10 类条款模板；rclass 是 R0—R5 执行级；condition 是“为什么这么判”的自然语言。

严重度口径（2026-11-16）：
- 业务严重度只有 critical / warning / info 三档，唯一实现仍是 ``app.severity``；
- 规则侧的 severity 一律由 rclass 投影得到（R0/R1→critical，R2/R3/R4→warning，R5→info）；
- P0/P1/P2、高/中/低、major/minor、suspected 等只是**入口别名**，归一后不得再写入 finding/rule；
- 未识别别名在 strict 模式下直接拒绝，不做静默兜底。
"""
from .. import severity as _severity

SEVERITY_LEVELS = ("critical", "warning", "info")
RCLASSES = ("R0", "R1", "R2", "R3", "R4", "R5")
# rclass → 业务严重度（唯一投影；app.severity.from_rclass 是唯一实现）
RCLASS_TO_SEVERITY = {rc: _severity.from_rclass(rc) for rc in RCLASSES}
# app.severity 未登记但业务入口存在的中文等价别名；仍先归一到它认识的“严重”
_EXTRA_ALIASES = {"高": "严重"}
# 入口别名 → 规范值；只用于归一，不作为落库值
SEVERITY_ALIASES = {
    alias: _severity.normalize(_EXTRA_ALIASES.get(alias, alias), strict=True)
    for alias in ("critical", "high", "p0", "严重", "高",
                  "warning", "medium", "major", "p1", "一般", "中",
                  "info", "low", "minor", "p2", "suspected", "提示", "信息", "低")
}


def normalize_rclass(value: str = "", strict: bool = False) -> str:
    """规范化 R0–R5；空值返回空串，未知值 strict 拒绝。"""
    rc = str(value or "").strip().upper()
    if not rc:
        return ""
    if rc in RCLASS_TO_SEVERITY:
        return rc
    if strict:
        raise ValueError(f"未知风险等级：{value}（只接受 {'/'.join(RCLASSES)}）")
    return ""


def normalize_severity(value: str = "", rclass: str = "", strict: bool = False,
                       default: str = "warning") -> str:
    """入口归一：别名/rclass → critical|warning|info。

    - value 为空时按 rclass 投影；rclass 也没有则返回 default；
    - value 是 R0–R5 时按同一张 rclass 表投影；
    - value 是已登记别名（含 retired 别名 suspected/P0/高 等）时归一；
    - 未识别值：strict=True 抛 ValueError，否则回退 rclass/default，绝不原样返回。
    """
    v = str(value or "").strip()
    rc = normalize_rclass(rclass)
    if v:
        if v.upper() in RCLASS_TO_SEVERITY:
            return RCLASS_TO_SEVERITY[v.upper()]
        try:
            return _severity.normalize(v, strict=True)
        except ValueError:
            alt = _EXTRA_ALIASES.get(v)
            if alt:
                return _severity.normalize(alt, strict=True)
            if strict:
                raise ValueError(f"未知严重度：{value}（只接受 critical/warning/info 或已登记别名）")
            return RCLASS_TO_SEVERITY.get(rc, default)
    if rc:
        return RCLASS_TO_SEVERITY[rc]
    return default


def severity_of_rclass(rclass: str = "", strict: bool = False) -> str:
    rc = normalize_rclass(rclass, strict=strict)
    return RCLASS_TO_SEVERITY.get(rc, "")


BUILTIN_RULES = [
    {"code": "RW20260525001", "name": "工单号/版本号一致性", "category": "consistency", "rclass": "R3",
     "condition": "跨 Sheet / 跨文档比对，要求相关字段完全一致"},
    {"code": "RW20260526004", "name": "实施日期一致", "category": "consistency", "rclass": "R0",
     "condition": "全部 Sheet 的实施日期必须相同（同一版本同一天生效）"},
    {"code": "RW20260525002", "name": "版本号/签名非占位符", "category": "completeness", "rclass": "R0",
     "condition": "版本号与签名必须填写，不得为空或占位符 X"},
    {"code": "RW20260525003", "name": "产品名称一致", "category": "consistency", "rclass": "R0",
     "condition": "产品名称全称/简称必须统一"},
    {"code": "B-2", "name": "半成品工序闭环", "category": "consistency", "rclass": "R3",
     "condition": "半成品清单每一项都要在工序 Sheet 有对应处理（外购需注明）"},
    {"code": "C-3", "name": "序号连续", "category": "format", "rclass": "R1",
     "condition": "序号/编号连续，不得跳号、缺号或重复"},
    {"code": "B-4", "name": "投料量与总重匹配", "category": "limit", "rclass": "R1",
     "condition": "半成品重量合计与设计总重在容差内一致"},
    {"code": "E3", "name": "葱姜蒜规格", "category": "preprocess", "rclass": "R4",
     "condition": "前处理必含器具 + 作业内容 + 成品规格（如蒜泥粒径）"},
    {"code": "E4", "name": "肉类前处理完整性", "category": "preprocess", "rclass": "R4",
     "condition": "肉类必含解冻 → 清洗/去筋膜 → 切制 + 规格"},
    {"code": "RW20260525005", "name": "加热中心温度达标", "category": "limit", "rclass": "R1",
     "condition": "加热工序中心温度 ≥85℃（作用域=中心温度）"},
    {"code": "RW20260525006", "name": "消毒浓度达标", "category": "limit", "rclass": "R1",
     "condition": "消毒液浓度 ≥200ppm"},
    {"code": "RW20260525007", "name": "产品名称规范", "category": "consistency", "rclass": "R4",
     "condition": "产品名称与已知名称词典匹配（检测疑似错别字）"},
    {"code": "RW20260525009", "name": "冷却温度达标", "category": "limit", "rclass": "R1",
     "condition": "冷却工序温度 ≤10℃（作用域=冷却）"},
    {"code": "RW20260525010", "name": "冷藏暂存温度达标", "category": "limit", "rclass": "R1",
     "condition": "冷藏/暂存/库内温度 ≤8℃（作用域=冷藏暂存）"},
    {"code": "RW20260525011", "name": "解冻时长达标", "category": "limit", "rclass": "R1",
     "condition": "解冻时长 ≥20h（作用域=解冻，单位 h/小时）"},
    {"code": "RW20260525012", "name": "重量单位一致性", "category": "consistency", "rclass": "R1",
     "condition": "设计总重量单位应为 g（kg 且数值异常时提示）"},
]

# 内置规则的 severity 不再单独硬编码：统一由 rclass 投影，避免两套口径漂移
for _r in BUILTIN_RULES:
    _r["severity"] = RCLASS_TO_SEVERITY[_r["rclass"]]

RULE_META = {r["code"]: r for r in BUILTIN_RULES}


def validate() -> dict:
    """内置规则元数据自检：编码唯一、rclass/severity 映射一致、别名零残留。"""
    errs = []
    codes = [r.get("code") for r in BUILTIN_RULES]
    if len(codes) != len(set(codes)):
        errs.append("内置规则 code 重复")
    for r in BUILTIN_RULES:
        try:
            rc = normalize_rclass(r.get("rclass"), strict=True)
            sev = normalize_severity(r.get("severity"), rc, strict=True)
        except ValueError as e:
            errs.append(f"{r.get('code')} 风险等级/严重度非法：{e}")
            continue
        if sev != RCLASS_TO_SEVERITY[rc]:
            errs.append(f"{r.get('code')} severity 与 rclass 映射不一致：{sev} vs {RCLASS_TO_SEVERITY[rc]}")
        elif str(r.get("severity") or "") not in SEVERITY_LEVELS:
            errs.append(f"{r.get('code')} severity 不是规范值：{r.get('severity')}")
        if not str(r.get("condition") or "").strip():
            errs.append(f"{r.get('code')} 缺少 condition")
    return {"ok": not errs, "errors": errs, "rules": len(BUILTIN_RULES),
            "severities": sorted({r["severity"] for r in BUILTIN_RULES}),
            "rclasses": sorted({r["rclass"] for r in BUILTIN_RULES})}


def condition_of(code: str) -> str:
    return RULE_META.get(code, {}).get("condition", "")
