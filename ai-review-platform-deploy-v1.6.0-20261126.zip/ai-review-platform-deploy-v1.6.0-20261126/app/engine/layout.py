"""轻量版面分析：把文档切成「标题 / 正文 / 表格 / 页眉页脚」块，给出块级定位。

定位：不引入视觉模型，用结构启发式；PDF 按页文本分块，docx 按段落样式，xlsx 按单元格区域。
"""
import re

HEADING = re.compile(r"^(第[一二三四五六七八九十]+[章节条]|[0-9]+(\.[0-9]+)*[\.、]?\s+\S|一、|二、|三、|四、|五、)")


def analyze_docx(path: str) -> list:
    from docx import Document
    d = Document(path)
    blocks = []
    for i, p in enumerate(d.paragraphs):
        txt = (p.text or "").strip()
        if not txt:
            continue
        style = (p.style.name or "").lower()
        kind = "heading" if ("heading" in style or HEADING.match(txt)) else "text"
        blocks.append({"kind": kind, "text": txt[:200], "locator": f"第 {i+1} 段"})
    for ti, t in enumerate(d.tables):
        blocks.append({"kind": "table", "text": f"表格 {len(t.rows)} 行 × {len(t.columns)} 列",
                       "locator": f"表格 {ti+1}"})
    return blocks


def analyze_pdf(path: str) -> list:
    """PDF：按页切分，并用「跨页重复的首/末行」识别页眉页脚。"""
    from pypdf import PdfReader
    from collections import Counter
    r = PdfReader(path)
    pages = []
    for i, page in enumerate(r.pages, 1):
        txt = (page.extract_text() or "").strip()
        lines = [l.strip() for l in txt.splitlines() if l.strip()] if txt else []
        pages.append((i, lines))
    firsts = Counter(p[1][0] for p in pages if p[1])
    lasts = Counter(p[1][-1] for p in pages if p[1] and len(p[1]) > 1)
    n = max(len(pages), 1)
    header = {k for k, c in firsts.items() if c >= max(2, n // 2)}
    footer = {k for k, c in lasts.items() if c >= max(2, n // 2)}
    blocks = []
    for i, lines in pages:
        if not lines:
            blocks.append({"kind": "empty", "text": "", "locator": f"第 {i} 页"})
            continue
        for idx, line in enumerate(lines):
            if idx == 0 and line in header:
                kind = "header"
            elif idx == len(lines) - 1 and line in footer:
                kind = "footer"
            elif HEADING.match(line):
                kind = "heading"
            else:
                kind = "text"
            blocks.append({"kind": kind, "text": line[:200], "locator": f"第 {i} 页"})
    return blocks


def analyze_xlsx(path: str) -> list:
    """xlsx：按 Sheet 切表格块，并统计合并单元格区域数（判断表头结构复杂度）。"""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    blocks = []
    for ws in wb.worksheets:
        rows = 0
        for row in ws.iter_rows(values_only=True):
            if any(v is not None for v in row):
                rows += 1
            if rows > 200:
                break
        merged = len(getattr(ws, "merged_cells", []).ranges) if hasattr(ws, "merged_cells") else 0
        blocks.append({"kind": "table",
                       "text": f"{ws.title}：{rows} 行" + (f"，合并区域 {merged}" if merged else ""),
                       "locator": ws.title})
    wb.close()
    return blocks


def analyze(path: str) -> dict:
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    try:
        if ext == "docx":
            blocks = analyze_docx(path)
        elif ext == "pdf":
            blocks = analyze_pdf(path)
        elif ext in ("xlsx", "xls"):
            blocks = analyze_xlsx(path)
        else:
            blocks = []
    except Exception as e:  # noqa
        return {"blocks": [], "error": f"{type(e).__name__}", "counts": {}}
    counts = {}
    for b in blocks:
        counts[b["kind"]] = counts.get(b["kind"], 0) + 1
    return {"blocks": blocks[:200], "counts": counts, "total": len(blocks)}
