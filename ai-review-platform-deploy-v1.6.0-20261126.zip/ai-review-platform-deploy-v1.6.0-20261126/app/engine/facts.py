# -*- coding: utf-8 -*-
"""统一事实层：所有抽取器输出同一种 fact JSON，供规则/决策表/证据链共用。

Schema:
  {kind, metric, object, value, unit, anchor, quote, source, start}
- deepparse.Fact（文本抽取）与 rexec.NumFact（表格数值）都适配到这里
- 旧入口保留，逐步改为本模块的适配器
"""
from . import deepparse


def make(kind="", metric="", object="", value=None, unit="", anchor="", quote="", source="", start=None):
    return {"kind": str(kind or ""), "metric": str(metric or ""), "object": str(object or ""),
            "value": value, "unit": str(unit or ""), "anchor": str(anchor or ""),
            "quote": str(quote or "")[:200], "source": source, "start": start}


def from_deepparse(f) -> dict:
    d = f.to_dict() if hasattr(f, "to_dict") else dict(f)
    return make(kind=d.get("kind", ""), metric=d.get("object") or d.get("kind", ""),
                object=d.get("object", ""), value=d.get("value"), unit=d.get("unit", ""),
                anchor=d.get("anchor", ""), quote=d.get("context", ""), source="deepparse")


def from_rexec(f) -> dict:
    d = f.to_dict() if hasattr(f, "to_dict") else dict(f)
    kind_map = {"温度": "temp", "时间": "time", "浓度": "conc", "重量": "weight"}
    return make(kind=kind_map.get(d.get("metric", ""), d.get("metric", "")),
                metric=d.get("metric", ""), object=d.get("scope", "") or d.get("metric", ""),
                value=d.get("value"), unit=d.get("unit", ""),
                anchor=f"{d.get('sheet','')}!{d.get('row','')}",
                quote=d.get("quote", ""), source="rexec")


def unify(*lists) -> list:
    out, seen = [], set()
    for lst in lists:
        for x in lst or []:
            key = (x.get("kind"), str(x.get("value")), x.get("unit"), x.get("anchor"))
            if key in seen:
                continue
            seen.add(key)
            out.append(x)
    return out


def extract(text: str) -> list:
    """文本 → 统一事实（deepparse 入口适配）。"""
    return [from_deepparse(f) for f in deepparse.extract_facts(text or "")]


def extract_document(path: str) -> list:
    parsed = deepparse.parse_and_extract(path)
    return extract(parsed["doc"].get("text", ""))


def merge(process_text: dict, text: str = "") -> list:
    from . import rexec
    return unify(extract(text), [from_rexec(f) for f in rexec.extract_numeric_facts(process_text or {})])
