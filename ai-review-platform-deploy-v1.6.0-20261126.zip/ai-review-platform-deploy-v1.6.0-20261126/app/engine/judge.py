"""
R4 语义判断挂载点（LLM judge / 语义判别）。

原则（方案 v2）：确定性优先；语义判断只在规则/图无法判定时进入；**不默认接任何模型**。
- 未配置模型时：返回“弃权（需人工）”，绝不凭空给结论。
- 可注入 provider（真实 LLM judge / 决策模型），必须返回置信度 + 证据 + 可审计理由。
- 提供确定性 keyword 兜底（低置信），仅作提示，不作终审。
"""
from dataclasses import dataclass, field, asdict
from typing import Callable, Optional


@dataclass
class JudgeResult:
    state: str              # 满足 / 不满足 / 弃权(需人工) / 证据不足
    confidence: Optional[float]
    rationale: str
    provider: str           # none / rule / llm / decision-model
    evidence: list = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


def abstain(reason: str) -> JudgeResult:
    """未配置语义判断模型时的诚实弃权。"""
    return JudgeResult(state="弃权(需人工)", confidence=None,
                       rationale=reason, provider="none")


def semantic_judge(question: str, evidence: list, provider: Optional[Callable] = None) -> JudgeResult:
    """provider: 可调用，输入 (question, evidence) 返回 dict{state,confidence,rationale}。

    无 provider 时弃权，不猜测。这是“接了必须生效”——不接就不生效，不硬给结论。
    """
    if provider is None:
        return abstain("未配置语义判断模型（不默认接 LLM/Jev）；该结论需人工复核")
    try:
        r = provider(question, evidence)
        return JudgeResult(
            state=r.get("state", "证据不足"),
            confidence=r.get("confidence"),
            rationale=r.get("rationale", ""),
            provider=r.get("provider", "llm"),
            evidence=evidence,
        )
    except Exception as e:  # noqa
        return abstain(f"语义判断调用失败：{type(e).__name__}")

