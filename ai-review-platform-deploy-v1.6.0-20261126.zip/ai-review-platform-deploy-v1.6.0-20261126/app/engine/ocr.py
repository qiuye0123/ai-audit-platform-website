"""
OCR（扫描件）检测与挂载点。

- detect_text_layer(path)：PDF 是否有文本层（扫描件通常无文本层）。
- ocr_pdf(path, config)：若配置了 OCR 引擎（RULEPROOF_OCR_CMD，外部命令，读 PDF 输出文本到 stdout），
  则调用；否则返回 None（需人工/待 OCR）。
- pdf_render_capability(force=False)：PDF 渲染能力三态探测（available / unavailable / unknown），
  供解析/审核上层表达「图像 PDF 需要 OCR，但渲染能力不可用」这个状态，禁止静默 0 字符。
- pdf_to_images_detailed / ocr_scanned_pdf_detailed：带结构化失败原因（含渲染器诊断）的版本。

不内置重型 OCR 依赖（PaddleOCR 等），保持可插拔；接 PaddleOCR 只需把 OCR_CMD 设为调用脚本。
"""
import logging
import os
import shlex
import shutil
import subprocess
import tempfile
import time
from datetime import datetime

from pypdf import PdfReader

# ---------------------------------------------------------------------------
# OCR 模型 ID 单一真相源（build49 B0：修复 RULEPROOF_OCR_MODEL 矛盾开关）
#
# 历史问题：同名 RULEPROOF_OCR_MODEL 被两个 OCR 通道复用，且两处默认值不一致
# （专用 OCR 千帆通道默认 deepseek-ocr；PaddleOCR-VL 通道默认 PaddleOCR-VL-1.6），
# 同一环境变量取值错配会让其中一个通道用错模型 ID（静默降级/失效）。
# 修复口径（单一真相源在本模块，paddleocr.py 复用同一 helper）：
#   - 专用 OCR（千帆 deepseek-ocr）通道：只读 RULEPROOF_OCR_MODEL，默认 deepseek-ocr；
#   - PaddleOCR-VL 通道：只读 RULEPROOF_PADDLE_OCR_MODEL，默认 PaddleOCR-VL-1.6；
#     兼容旧值：若只显式配置了 RULEPROOF_OCR_MODEL 且值形如 PaddleOCR 模型，则沿用
#     （旧版本单变量写法），否则忽略（避免专用 OCR 的 deepseek-ocr 泄漏到 Paddle 通道）。
# ---------------------------------------------------------------------------
DEFAULT_OCR_MODEL = "deepseek-ocr"
DEFAULT_PADDLE_OCR_MODEL = "PaddleOCR-VL-1.6"


def ocr_model(channel: str = "dedicated") -> str:
    """OCR 模型 ID 唯一读取点。

    channel="dedicated"（默认）：专用 OCR（千帆 deepseek-ocr）通道，读
    ``RULEPROOF_OCR_MODEL``，默认 ``deepseek-ocr``；
    channel="paddle"：PaddleOCR-VL 通道，读 ``RULEPROOF_PADDLE_OCR_MODEL``，
    默认 ``PaddleOCR-VL-1.6``，并对旧单变量写法做向后兼容。
    """
    # 每个开关固定只读一次（同一读取点带默认值，避免同名变量两处默认造成「矛盾开关」误报）。
    ocr_env = (os.environ.get("RULEPROOF_OCR_MODEL", "deepseek-ocr") or "").strip()
    paddle_env = (os.environ.get("RULEPROOF_PADDLE_OCR_MODEL", "PaddleOCR-VL-1.6") or "").strip()
    if channel == "paddle":
        if paddle_env:
            return paddle_env
        if "paddle" in ocr_env.lower():   # 旧单变量写法兼容（仅当值确为 Paddle 模型）
            return ocr_env
        return DEFAULT_PADDLE_OCR_MODEL
    return ocr_env or DEFAULT_OCR_MODEL


def _external_model_denied() -> bool:
    """P1-06：数据边界 external_model=deny 时禁止把文件/图片发往外部 OCR/视觉 API。

    唯一事实源在 app/engine/llm.py（读 sysconfig 数据边界策略）；本地文本层抽取/
    本地外部命令 OCR 不受此限，只有外部 HTTP 识别（百度/Paddle/视觉模型）被拦。
    """
    try:
        from . import llm as _llm
        return bool(_llm.external_model_denied())
    except Exception:  # noqa: BLE001 - 策略读取失败不阻断本地路径
        logging.getLogger(__name__).warning("ocr external policy check failed", exc_info=True)
        return False


def detect_text_layer(path: str) -> bool:
    try:
        reader = PdfReader(path)
        for page in reader.pages[:3]:  # 前 3 页抽查
            if (page.extract_text() or "").strip():
                return True
        return False
    except Exception:
        return False


def ocr_pdf(path: str, config) -> str | None:
    """config 带 OCR_CMD（外部命令，参数追加 PDF 路径）。未配置返回 None。"""
    cmd = getattr(config, "OCR_CMD", "") or os.environ.get("RULEPROOF_OCR_CMD", "")
    if not cmd:
        return None
    try:
        out = subprocess.run(cmd.split() + [path], capture_output=True, text=True, timeout=300)
        return out.stdout.strip() if out.returncode == 0 else None
    except Exception:
        return None



def _dedicated_ocr_cfg() -> dict:
    """读取专用 OCR 配置（models 表 provider=baidu-qianfan + model_id=deepseek-ocr）。"""
    try:
        from .. import db
        with db.session() as c:
            r = c.execute("SELECT base_url, api_key, model_id FROM model_config "
                          "WHERE provider='baidu-qianfan' AND model_id LIKE '%ocr%' AND enabled=1 "
                          "ORDER BY created_at DESC LIMIT 1").fetchone()
        if r and r["api_key"]:
            return {"base_url": r["base_url"], "api_key": r["api_key"], "model": r["model_id"]}
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    base = os.environ.get("RULEPROOF_OCR_BASE_URL", "")
    key = os.environ.get("RULEPROOF_OCR_API_KEY", "")
    model = ocr_model("dedicated")  # build49 B0：唯一读取点（默认 deepseek-ocr）
    return {"base_url": base, "api_key": key, "model": model} if (base and key) else {}


def _unknown_provenance(reason: str = "") -> dict:
    """未知来源（失败/未配置/老数据）：vision_advisory=None，禁止默认当作安全。"""
    return {"ocr_engine": "", "ocr_tier": "", "vision_advisory": None,
            "reason": str(reason or "")[:200]}


def _prov(engine: str, tier: str, reason: str = "") -> dict:
    """provenance 三元组；vision_advisory 仅通用视觉模型为 True。"""
    return {"ocr_engine": str(engine or ""), "ocr_tier": str(tier or ""),
            "vision_advisory": str(tier or "") == "vision", "reason": str(reason or "")[:200]}


def ocr_image_dedicated_detailed(image_bytes: bytes, mime: str) -> dict:
    """专用 OCR（百度 Unlimited-OCR → PaddleOCR-VL → 千帆专用 OCR 模型），带 provenance。

    返回 {ok, text, reason, provenance}；专用 OCR 引擎（tier=ocr）不是通用视觉模型，
    vision_advisory=False。失败时 provenance 为未知（vision_advisory=None）。
    """
    if _external_model_denied():
        logging.getLogger(__name__).warning(
            "external_model=deny：拒绝外部 OCR 图片识别（百度/Paddle/千帆）")
        return {"ok": False, "text": "", "reason": "数据边界 external_model=deny",
                "provenance": _unknown_provenance("external_model=deny")}
    try:
        from . import baidu_ocr as _baidu
        if _baidu.configured():
            import tempfile, os as _os0
            suffix = {"image/png": ".png", "image/jpeg": ".jpg", "image/jpg": ".jpg",
                      "image/webp": ".webp", "image/gif": ".gif", "image/bmp": ".bmp",
                      "image/tiff": ".tiff"}.get(str(mime or "").lower(), ".png")
            fd, tmp = tempfile.mkstemp(prefix="rp_baidu_", suffix=suffix)
            try:
                with _os0.fdopen(fd, "wb") as f:
                    f.write(image_bytes)
                br = _baidu.run_file(tmp, timeout_s=300)
                if br.get("ok") and (br.get("text") or "").strip():
                    return {"ok": True, "text": br.get("text"),
                            "reason": "百度 Unlimited-OCR",
                            "provenance": _prov("baidu", "ocr", "百度 Unlimited-OCR")}
            finally:
                try:
                    _os0.unlink(tmp)
                except Exception:
                    logging.getLogger(__name__).debug("baidu tmp unlink failed", exc_info=True)
    except Exception:  # noqa: BLE001 - 单一引擎失败不阻断后续专用引擎
        logging.getLogger(__name__).debug("baidu image OCR failed", exc_info=True)
    try:
        from . import paddleocr as _paddle
        if _paddle.configured():
            import tempfile
            suffix = {"image/png": ".png", "image/jpeg": ".jpg", "image/jpg": ".jpg",
                      "image/webp": ".webp", "image/gif": ".gif"}.get(str(mime or "").lower(), ".png")
            fd, tmp = tempfile.mkstemp(prefix="rp_ocr_", suffix=suffix)
            try:
                import os as _os
                with _os.fdopen(fd, "wb") as f:
                    f.write(image_bytes)
                r = _paddle.run_file(tmp, timeout_s=300)
                if r.get("ok") and (r.get("text") or "").strip():
                    return {"ok": True, "text": r.get("text"),
                            "reason": "PaddleOCR-VL",
                            "provenance": _prov("paddle", "ocr", "PaddleOCR-VL")}
            finally:
                try:
                    import os as _os2
                    _os2.unlink(tmp)
                except Exception:
                    logging.getLogger(__name__).debug("paddle tmp unlink failed", exc_info=True)
    except Exception:  # noqa: BLE001 - 单一引擎失败不阻断后续专用引擎
        logging.getLogger(__name__).debug("paddle image OCR failed", exc_info=True)
    cfg = _dedicated_ocr_cfg()
    if not cfg:
        return {"ok": False, "text": "", "reason": "专用 OCR 未配置",
                "provenance": _unknown_provenance("专用 OCR 未配置")}
    try:
        from . import llm
        t = llm.vision_ocr(image_bytes, mime, cfg,
                           prompt="识别图片中的全部文字，按阅读顺序逐行输出，保留表格换行，不要解释。")
        if (t or "").strip():
            # 千帆专用 OCR 模型（deepseek-ocr 等）是专用识别引擎，不是通用视觉模型
            return {"ok": True, "text": t, "reason": "专用 OCR 模型",
                    "provenance": _prov("baidu", "ocr", "千帆专用 OCR 模型")}
        return {"ok": False, "text": "", "reason": "专用 OCR 模型未返回文本",
                "provenance": _unknown_provenance("专用 OCR 模型未返回文本")}
    except Exception:  # noqa: BLE001 - 兜底失败必须带未知 provenance 返回
        logging.getLogger(__name__).warning("专用 OCR 失败", exc_info=True)
        return {"ok": False, "text": "", "reason": "专用 OCR 调用异常",
                "provenance": _unknown_provenance("专用 OCR 调用异常")}




def ocr_image_via_vision_detailed(image_bytes: bytes, mime: str, config=None) -> dict:
    """OCR（专用引擎 → 通用视觉模型兜底），带 provenance。

    返回 {ok, text, reason, provenance}：
    - 专用 OCR 引擎 → tier=ocr，vision_advisory=False；
    - 通用视觉模型兜底 → tier=vision，vision_advisory=True（数值事实不得作为判定依据）。
    """
    if _external_model_denied():
        logging.getLogger(__name__).warning(
            "external_model=deny：拒绝图片外发 OCR（专用/视觉模型均不调用）")
        return {"ok": False, "text": "", "reason": "数据边界 external_model=deny",
                "provenance": _unknown_provenance("external_model=deny")}
    det = ocr_image_dedicated_detailed(image_bytes, mime)
    if det.get("ok") and (det.get("text") or "").strip():
        return det
    from . import llm, llm_router
    c = llm_router.resolve()
    if not c.get("enabled"):
        return {"ok": False, "text": "", "reason": "视觉模型未配置",
                "provenance": _unknown_provenance("视觉模型未配置")}
    try:
        t = llm.vision_ocr(image_bytes, mime, c)
    except Exception:  # noqa: BLE001 - 视觉兜底异常返回未知 provenance，不静默当成功
        logging.getLogger(__name__).warning("视觉 OCR 失败", exc_info=True)
        return {"ok": False, "text": "", "reason": "视觉 OCR 调用异常",
                "provenance": _unknown_provenance("视觉 OCR 调用异常")}
    if not (t or "").strip():
        return {"ok": False, "text": "", "reason": "视觉模型未返回文本",
                "provenance": _unknown_provenance("视觉模型未返回文本")}
    return {"ok": True, "text": t, "reason": "通用视觉模型兜底",
            "provenance": _prov("vision", "vision", "通用视觉模型兜底 OCR")}


def ocr_image_via_vision(image_bytes: bytes, mime: str, config=None) -> str | None:
    """OCR：优先专用 OCR 模型；不可用时回退到视觉模型（文本入口，兼容旧调用）。"""
    det = ocr_image_via_vision_detailed(image_bytes, mime, config)
    return det.get("text") if det.get("ok") else None


# ---------------------------------------------------------------- PDF 渲染能力探测（三态）
# 图像 PDF 必须先渲染成页图才能 OCR。渲染器缺失时旧实现只在 stderr 打一行 Warning，
# 然后 parse_document 返回空文本、上层仍可能认为「解析成功但没内容」——这是静默失败。
# 这里提供可复用探测：available / unavailable / unknown，并且必须 try 实际加载：
# pypdfium2 可能 find_spec/import 都正常，但第一次调用原生库才 OSError（macOS 代码签名）。
_RENDER_CAP_CACHE = {"at": 0.0, "value": None}
_RENDER_CAP_TTL_S = 60          # 秒：安装/修复渲染器后无需重启进程，最长 60s 生效
_RENDER_KNOWN_HINTS = (
    ("dlopen", "原生动态库加载失败"),
    ("code signature", "代码签名无效"),
    ("team ids", "Team ID 不匹配"),
    ("modulenotfounderror", "模块未安装"),
    ("no module named", "模块未安装"),
)


def _short_err(e: BaseException, limit: int = 240) -> str:
    return f"{type(e).__name__}: {str(e)[:limit]}"


def _render_failure_hint(text: str) -> str:
    """把常见原生库错误翻译成可诊断的中文线索（原始异常文本仍保留在 reason 里）。"""
    low = str(text or "").lower()
    hints = []
    for key, label in _RENDER_KNOWN_HINTS:
        if key in low and label not in hints:
            hints.append(label)
    return "；".join(hints)


def _probe_pypdfium2_render() -> dict:
    """实际加载 pypdfium2 并做一次原生渲染调用（find_spec / import 都不算数）。"""
    try:
        import pypdfium2 as pdfium
        doc = pdfium.PdfDocument.new()
        try:
            page = doc.new_page(72, 72)
            bitmap = page.render(scale=1)
            pil = bitmap.to_pil()          # 与 pdf_render 保存 PNG 的真实链路一致
            if not (pil.width and pil.height):
                raise RuntimeError("pypdfium2 渲染结果尺寸为 0")
        finally:
            try:
                doc.close()
            except Exception:  # noqa: BLE001 - close 失败不改变能力判定
                logging.getLogger(__name__).debug("pypdfium2 probe close failed", exc_info=True)
    except Exception as e:  # noqa: BLE001 - 加载/渲染失败都按 unavailable 保留原因
        return {"source": "pypdfium2", "available": False,
                "reason": f"pypdfium2 加载/渲染失败：{_short_err(e)}",
                "hint": _render_failure_hint(str(e))}
    return {"source": "pypdfium2", "available": True,
            "reason": "pypdfium2 实际渲染可用", "hint": ""}


def _probe_pymupdf_render() -> dict:
    """实际加载 fitz/PyMuPDF 并渲染一页（pdf_render 的 pymupdf 分支用 fitz 包名）。"""
    try:
        import fitz
        doc = fitz.open()
        try:
            page = doc.new_page()
            pix = page.get_pixmap(dpi=72)
            ok = bool(pix.width and pix.height)
            del pix
        finally:
            try:
                doc.close()
            except Exception:  # noqa: BLE001 - close 失败不改变能力判定
                logging.getLogger(__name__).debug("pymupdf probe close failed", exc_info=True)
        if not ok:
            raise RuntimeError("pymupdf 渲染结果尺寸为 0")
    except Exception as e:  # noqa: BLE001
        return {"source": "pymupdf", "available": False,
                "reason": f"pymupdf 加载/渲染失败：{_short_err(e)}",
                "hint": _render_failure_hint(str(e))}
    return {"source": "pymupdf", "available": True,
            "reason": "pymupdf 实际渲染可用", "hint": ""}


def _write_probe_pdf(path: str) -> None:
    """生成 1 页空白 PDF 作为外部渲染命令的探测输入（只依赖 pypdf）。"""
    from pypdf import PdfWriter
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    with open(path, "wb") as fh:
        writer.write(fh)


def _probe_external_render_cmd() -> dict:
    """探测 RULEPROOF_PDF_RENDER_CMD（``<pdf> <outdir>``，输出 pN.png）：真实执行一次。"""
    cmd = (os.environ.get("RULEPROOF_PDF_RENDER_CMD") or "").strip()
    if not cmd:
        return {"source": "external_cmd", "available": False,
                "reason": "未配置 RULEPROOF_PDF_RENDER_CMD", "hint": ""}
    try:
        argv = shlex.split(cmd)
    except ValueError as e:
        return {"source": "external_cmd", "available": False,
                "reason": f"外部渲染命令解析失败：{_short_err(e)}", "hint": ""}
    if not argv:
        return {"source": "external_cmd", "available": False,
                "reason": "外部渲染命令为空", "hint": ""}
    exe = argv[0]
    if not ((os.path.isabs(exe) and os.path.exists(exe)) or shutil.which(exe)):
        return {"source": "external_cmd", "available": False,
                "reason": f"外部渲染命令不存在：{exe}", "hint": ""}
    try:
        with tempfile.TemporaryDirectory(prefix="rp_render_probe_") as td:
            pdf = os.path.join(td, "probe.pdf")
            _write_probe_pdf(pdf)
            outdir = os.path.join(td, "out")
            os.makedirs(outdir, exist_ok=True)
            r = subprocess.run(argv + [pdf, outdir], capture_output=True, text=True, timeout=60)
            pngs = sorted(f for f in os.listdir(outdir) if f.lower().endswith(".png"))
            if r.returncode == 0 and pngs:
                return {"source": "external_cmd", "available": True,
                        "reason": f"外部渲染命令可用（探测输出 {len(pngs)} 张 PNG）", "hint": ""}
            return {"source": "external_cmd", "available": False,
                    "reason": (f"外部渲染命令执行失败：rc={r.returncode}，"
                               f"stderr={(r.stderr or '')[:160] or '空'}"), "hint": ""}
    except subprocess.TimeoutExpired:
        return {"source": "external_cmd", "available": False,
                "reason": "外部渲染命令探测超时（60s）", "hint": ""}
    except Exception as e:  # noqa: BLE001 - 探测异常也要如实返回原因
        return {"source": "external_cmd", "available": False,
                "reason": f"外部渲染命令探测异常：{_short_err(e)}", "hint": ""}


def pdf_render_capability(force: bool = False) -> dict:
    """PDF 渲染能力三态探测（OCR 前置），可复用、带缓存（默认 60s）。

    返回::

        {"status": "available"|"unavailable"|"unknown",
         "available": True|False|None,     # 三态：None 表示无法判定
         "source": "pypdfium2"|"pymupdf"|"external_cmd"|"",
         "reason": "可诊断原因（含原始异常，如 dylib/code signature/Team IDs）",
         "hint": "中文线索（动态库加载失败/代码签名无效/Team ID 不匹配…）",
         "sources": [{"source","available","reason","hint"}, ...],
         "scope": "ocr_render", "checked_at": "..."}

    判定口径：
    - available：pypdfium2 / pymupdf / RULEPROOF_PDF_RENDER_CMD 任一项**实际**可用；
    - unavailable：全部探测明确失败（未安装 / 加载失败 / 命令缺失或执行失败）；
    - unknown：没有可用项，但至少一项探测本身异常/无法判定（不能算「不可用」）。
    """
    now = time.time()
    cached = _RENDER_CAP_CACHE.get("value")
    if (cached and not force
            and (now - float(_RENDER_CAP_CACHE.get("at") or 0.0)) < _RENDER_CAP_TTL_S):
        return dict(cached)
    probes = (_probe_pypdfium2_render, _probe_pymupdf_render, _probe_external_render_cmd)
    sources = []
    for fn in probes:
        try:
            r = fn()
            if not isinstance(r, dict):
                raise TypeError("探测返回值不是 dict")
        except Exception as e:  # noqa: BLE001 - 探测本身异常 = 无法判定，不能记成不可用
            logging.getLogger(__name__).warning(
                "pdf render probe %s error: %s", getattr(fn, "__name__", "?"), e)
            r = {"source": getattr(fn, "__name__", ""), "available": None,
                 "reason": f"探测本身异常：{_short_err(e)}", "hint": ""}
        sources.append({"source": str(r.get("source") or getattr(fn, "__name__", "")),
                        "available": r.get("available"),
                        "reason": str(r.get("reason") or "")[:320],
                        "hint": str(r.get("hint") or "")})
        if r.get("available") is True:
            out = {"status": "available", "available": True,
                   "source": sources[-1]["source"],
                   "reason": sources[-1]["reason"], "hint": sources[-1]["hint"],
                   "sources": sources, "scope": "ocr_render",
                   "checked_at": datetime.now().isoformat(timespec="seconds")}
            _RENDER_CAP_CACHE.update({"at": now, "value": out})
            return dict(out)
    _checked = datetime.now().isoformat(timespec="seconds")
    _hints = []
    for _s in sources:
        for _h in str(_s.get("hint") or "").split("；"):
            if _h and _h not in _hints:
                _hints.append(_h)
    _hint = "；".join(_hints)
    if any(s["available"] is None for s in sources):
        _unknown = [s for s in sources if s["available"] is None]
        out = {"status": "unknown", "available": None, "source": "",
               "reason": ("无法判定 PDF 渲染能力："
                          + "；".join(f"{s['source']}：{s['reason']}" for s in _unknown)[:400]),
               "hint": _hint, "sources": sources, "scope": "ocr_render",
               "checked_at": _checked}
    else:
        _detail = "；".join(f"{s['source']}：{s['reason']}" for s in sources if s["reason"])
        out = {"status": "unavailable", "available": False, "source": "",
               "reason": ("无可用 PDF 渲染器（OCR 前置渲染链路 pypdfium2 / pymupdf / "
                          "RULEPROOF_PDF_RENDER_CMD 均不可用）：" + _detail)[:900],
               "hint": _hint, "sources": sources, "scope": "ocr_render",
               "checked_at": _checked}
    _RENDER_CAP_CACHE.update({"at": now, "value": out})
    return dict(out)


def reset_pdf_render_capability_cache() -> None:
    """清空渲染能力探测缓存（测试/运维重新探测用）。"""
    _RENDER_CAP_CACHE.update({"at": 0.0, "value": None})


def pdf_to_images_detailed(path: str, max_pages: int = 20) -> dict:
    """PDF 逐页渲染为 PNG；返回 {images, error, ocr_capability, ocr_unavailable}。

    与 old ``pdf_to_images`` 的区别：失败不返回裸 []，而是把渲染器诊断信息结构化
    带回，供 parse_status / 解析报告 / 编排轨迹表达「需要 OCR 但 OCR 能力不可用」。
    """
    from . import pdf_render
    try:
        images = pdf_render.render_pdf_pages(path, max_pages=max_pages)
    except Exception as e:  # noqa: BLE001 - 渲染失败必须带原因返回，禁止静默
        _cap = pdf_render_capability()
        logging.getLogger(__name__).warning("PDF 渲染不可用：%s", str(e)[:160])
        return {"images": [], "error": str(e)[:400], "ocr_capability": _cap,
                "ocr_unavailable": _cap.get("available") is False}
    if not images:
        _cap = pdf_render_capability()
        logging.getLogger(__name__).warning("PDF 渲染不可用：未渲染出页面")
        return {"images": [], "error": "未渲染出页面", "ocr_capability": _cap,
                "ocr_unavailable": _cap.get("available") is False}
    return {"images": list(images), "error": "", "ocr_capability": {}, "ocr_unavailable": False}


def pdf_to_images(path: str, max_pages: int = 20) -> list:
    """PDF 逐页渲染为 PNG（跨平台：pypdfium2 / pymupdf / 外部命令）。"""
    return pdf_to_images_detailed(path, max_pages=max_pages)["images"]


def _prov_summary(provs) -> dict:
    """把页/段 provenance 列表聚合成文档级摘要（复用 hooks 的 trusted/vision/unknown 口径）。"""
    from . import hooks as _hk
    return _hk.doc_provenance(None, [dict(p) for p in (provs or []) if isinstance(p, dict)])


def _unknown_summary(reason: str = "") -> dict:
    """未知来源的文档级摘要（失败/未配置/老数据；不默认安全）。"""
    from . import hooks as _hk
    s = _hk.doc_provenance(None, None)
    s["reason"] = str(reason or s.get("reason") or "")
    return s


def ocr_scanned_pdf_detailed(path: str, config, max_pages: int = 20) -> dict:
    """扫描版 PDF：逐页渲染 → OCR（专用引擎→视觉模型）→ 带页码文本 + 按页 provenance。

    返回新增字段（向后兼容，text 格式与旧版逐字节一致）：
      page_texts      [{"page", "text", "provenance"}] 逐页文本与实际引擎
      page_provenance {"第N页": {ocr_engine, ocr_tier, vision_advisory}}
      provenance      文档级摘要（status=trusted/vision/mixed/unknown）
      ocr_engine / ocr_tier / vision_advisory  文档级平铺（便利字段）
    视觉模型参与的页 vision_advisory=True：该页数值事实不得作为判定依据（TL-5）。
    """
    det = pdf_to_images_detailed(path, max_pages=max_pages)
    imgs = det.get("images") or []
    cap = det.get("ocr_capability") or {}
    cap_short = {k: cap.get(k) for k in ("status", "available", "source", "reason", "hint")
                 if k in cap}
    out = {"ok": False, "text": "", "pages": len(imgs), "reason": "",
           "ocr_capability": cap_short,
           "ocr_unavailable": bool(det.get("ocr_unavailable")),
           "page_texts": [], "page_provenance": {},
           "provenance": _unknown_summary("未执行 OCR"),
           "ocr_engine": "", "ocr_tier": "", "vision_advisory": None}
    if not imgs:
        if det.get("ocr_unavailable"):
            out["reason"] = "PDF 渲染不可用：" + str(det.get("error") or "未渲染出页面")
        else:
            out["reason"] = "未渲染出页面"
        out["provenance"] = _unknown_summary(out["reason"])
        return out
    texts, page_texts, page_prov = [], [], {}
    for i, img in enumerate(imgs):
        try:
            with open(img, "rb") as fh:
                data = fh.read()
        except Exception:  # noqa: BLE001 - 单页读图失败不阻断其余页
            logging.getLogger(__name__).debug("ocr read page image failed", exc_info=True)
            continue
        pdet = ocr_image_via_vision_detailed(data, "image/png", config)
        t = str(pdet.get("text") or "") if pdet.get("ok") else ""
        if t:
            texts.append(f"[第{i + 1}页]\n{t}")
            pv = dict(pdet.get("provenance") or {})
            page_texts.append({"page": i + 1, "text": t, "provenance": pv})
            page_prov[f"第{i + 1}页"] = pv
    out["text"] = "\n".join(texts)
    out["ok"] = bool(out["text"])
    out["page_texts"] = page_texts
    out["page_provenance"] = page_prov
    summary = _prov_summary(list(page_prov.values())) if page_prov else _unknown_summary("OCR 无返回")
    out["provenance"] = summary
    out["ocr_engine"] = str(summary.get("ocr_engine") or "")
    out["ocr_tier"] = str(summary.get("ocr_tier") or "")
    out["vision_advisory"] = summary.get("vision_advisory")
    out["reason"] = (f"OCR 成功 {len(texts)}/{len(imgs)} 页" if out["ok"]
                     else "已渲染但 OCR 引擎未返回结果（需配置视觉模型/专用 OCR/RULEPROOF_OCR_CMD）")
    return out


def ocr_scanned_pdf(path: str, config, max_pages: int = 20) -> str:
    """扫描版 PDF：逐页渲染 → 视觉模型 OCR → 带页码文本。"""
    return str(ocr_scanned_pdf_detailed(path, config, max_pages=max_pages).get("text") or "")


def ocr_pdf_via_vision(path: str, config=None, max_pages: int = 20) -> dict:
    """PDF → 图片 → 视觉模型 OCR。返回 {ok, text, pages, reason, provenance, page_provenance}。

    provenance（TL-5）：
    - 有文本层 → text_layer/text/vision_advisory=False（trusted）；
    - 逐页 OCR → 按页记录实际引擎（专用 OCR=ocr / 通用视觉模型=vision）；
    - 失败/未配置 → 未知（vision_advisory=None，不默认安全）。
    """
    if _external_model_denied():
        return {"ok": False, "text": "", "pages": 0,
                "reason": "数据边界策略 external_model=deny：禁止把扫描件发送外部 OCR/"
                          "视觉模型；需本地 OCR 或人工处理",
                "provenance": _unknown_summary("external_model=deny"),
                "page_provenance": {}, "ocr_engine": "", "ocr_tier": "",
                "vision_advisory": None}
    try:
        if detect_text_layer(path):
            from pypdf import PdfReader
            reader = PdfReader(path)
            txt = "\n".join((pg.extract_text() or "") for pg in reader.pages)
            _prov = _prov_summary([_prov("text_layer", "text")])
            return {"ok": True, "text": txt, "pages": len(reader.pages),
                    "reason": "有文本层，直接抽取", "provenance": _prov,
                    "page_provenance": {f"第{i + 1}页": _prov("text_layer", "text")
                                        for i in range(len(reader.pages))},
                    "ocr_engine": "text_layer", "ocr_tier": "text",
                    "vision_advisory": False}
    except Exception:
        logging.getLogger(__name__).debug('ignored', exc_info=True)
    _det = pdf_to_images_detailed(path, max_pages=max_pages)
    imgs = _det.get("images") or []
    if not imgs:
        _reason = ("PDF 渲染不可用：" + str(_det.get("error") or "未渲染出页面")
                   if _det.get("ocr_unavailable") else "未渲染出页面")
        return {"ok": False, "text": "", "pages": 0, "reason": _reason,
                "ocr_capability": _det.get("ocr_capability") or {},
                "ocr_unavailable": bool(_det.get("ocr_unavailable")),
                "provenance": _unknown_summary(_reason), "page_provenance": {},
                "ocr_engine": "", "ocr_tier": "", "vision_advisory": None}
    parts, used, page_prov, page_texts = [], 0, {}, []
    for idx, ip in enumerate(imgs):
        try:
            with open(ip, "rb") as fh:
                b = fh.read()
        except Exception:
            logging.getLogger(__name__).debug("ocr read page image failed", exc_info=True)
            continue
        pdet = ocr_image_via_vision_detailed(b, "image/png", config)
        t = str(pdet.get("text") or "") if pdet.get("ok") else ""
        if t:
            parts.append(t)
            used += 1
            pv = dict(pdet.get("provenance") or {})
            page_prov[f"第{idx + 1}页"] = pv
            page_texts.append({"page": idx + 1, "text": t, "provenance": pv})
    if not parts:
        return {"ok": False, "text": "", "pages": len(imgs),
                "reason": "视觉模型未返回结果（需配置支持图片的模型）",
                "ocr_capability": {}, "ocr_unavailable": False,
                "provenance": _unknown_summary("视觉模型未返回结果"),
                "page_provenance": {}, "page_texts": [], "ocr_engine": "",
                "ocr_tier": "", "vision_advisory": None}
    summary = _prov_summary(list(page_prov.values())) if page_prov else _unknown_summary()
    return {"ok": True, "text": "\n".join(parts), "pages": len(imgs),
            "reason": f"OCR 成功 {used}/{len(imgs)} 页",
            "ocr_capability": {}, "ocr_unavailable": False,
            "provenance": summary, "page_provenance": page_prov,
            "page_texts": page_texts,
            "ocr_engine": str(summary.get("ocr_engine") or ""),
            "ocr_tier": str(summary.get("ocr_tier") or ""),
            "vision_advisory": summary.get("vision_advisory")}


def ocr_pdf_auto(path: str, config=None) -> dict:
    """统一入口：文本层 → PaddleOCR-VL → 外部命令 → 视觉模型。"""
    # 有文本层直接抽取，不调用任何 OCR（避免浪费/伪造 OCR 成功）
    try:
        if detect_text_layer(path):
            from pypdf import PdfReader
            reader = PdfReader(path)
            txt = "\n".join((pg.extract_text() or "") for pg in reader.pages)
            _tprov = _prov("text_layer", "text")
            return {"ok": True, "text": txt, "pages": len(reader.pages),
                    "reason": "有文本层，直接抽取", "provider": "text_layer",
                    "provenance": _prov_summary([_tprov]),
                    "page_provenance": {f"第{i + 1}页": dict(_tprov)
                                        for i in range(len(reader.pages))},
                    "ocr_engine": "text_layer", "ocr_tier": "text",
                    "vision_advisory": False}
    except Exception:
        logging.getLogger(__name__).debug("text layer read skipped", exc_info=True)
    # P1-06：后续均为外部 HTTP OCR（百度/Paddle/视觉），显式 deny 时在首个外发前拒绝。
    if _external_model_denied():
        return {"ok": False, "text": "", "pages": 0,
                "reason": "数据边界策略 external_model=deny：扫描件 OCR 需外部识别 API，"
                          "已拒绝外发；需本地 OCR_CMD 或人工处理",
                "provenance": _unknown_summary("external_model=deny"),
                "page_provenance": {}, "ocr_engine": "", "ocr_tier": "",
                "vision_advisory": None}
    # 百度 Unlimited-OCR 2（主链路）
    _baidu_err = None
    try:
        from . import baidu_ocr as _baidu
        if _baidu.configured():
            br = _baidu.run_file(path)
            if br.get("ok") and (br.get("text") or "").strip():
                _bout = dict(br)
                _bprov = _prov("baidu", "ocr", "百度 Unlimited-OCR 2")
                _bout.update({"provenance": _prov_summary([_bprov]),
                              "page_provenance": {}, "ocr_engine": "baidu",
                              "ocr_tier": "ocr", "vision_advisory": False})
                return _bout
            _baidu_err = br
            logging.getLogger(__name__).warning("百度 Unlimited-OCR 失败：%s", str(br.get("reason") or "")[:160])
    except Exception as e:
        _baidu_err = {"ok": False, "reason": f"百度 OCR 异常：{type(e).__name__}"}
    # PaddleOCR-VL 异步 Job
    try:
        from . import paddleocr as _paddle
        if _paddle.configured():
            r = _paddle.run_file(path)
            if r.get("ok"):
                _pout = dict(r)
                _pprov = _prov("paddle", "ocr", "PaddleOCR-VL")
                _pout.update({"provenance": _prov_summary([_pprov]),
                              "page_provenance": {}, "ocr_engine": "paddle",
                              "ocr_tier": "ocr", "vision_advisory": False})
                return _pout
            # PDF 直传失败时，尝试逐页图片（需要 pypdfium2/外部渲染器；不可用会给出明确原因）
            try:
                if str(path).lower().endswith(".pdf"):
                    r2 = _paddle.run_pdf(path, max_pages=20)
                    if r2.get("ok"):
                        _p2out = dict(r2)
                        _p2prov = _prov("paddle", "ocr", "PaddleOCR-VL 逐页")
                        _p2out.update({"provenance": _prov_summary([_p2prov]),
                                       "page_provenance": {}, "ocr_engine": "paddle",
                                       "ocr_tier": "ocr", "vision_advisory": False})
                        return _p2out
                    r = {"ok": False, "reason": (r.get("reason") or "") + "；" + (r2.get("reason") or ""),
                         "pages": 0, "provider": "paddleocr"}
            except Exception:
                pass
            logging.getLogger(__name__).warning("PaddleOCR 失败：%s", str(r.get("reason") or "")[:160])
            _paddle_err = r
    except Exception as e:
        _paddle_err = {"ok": False, "reason": f"PaddleOCR 异常：{type(e).__name__}"}
    cmd = getattr(config, "OCR_CMD", "") or os.environ.get("RULEPROOF_OCR_CMD", "")
    if cmd:
        txt = ocr_pdf(path, config)
        if txt:
            _cprov = _prov("external_cmd", "ocr", "外部 OCR 命令")
            return {"ok": True, "text": txt, "pages": 0, "reason": "外部 OCR 命令",
                    "provenance": _prov_summary([_cprov]), "page_provenance": {},
                    "ocr_engine": "external_cmd", "ocr_tier": "ocr",
                    "vision_advisory": False}
    # 最终仍失败时，若 Paddle 有明确错误，保留该原因，避免伪造成“未配置”
    out = ocr_pdf_via_vision(path, config)
    if not out.get("ok"):
        if locals().get("_baidu_err"):
            out["baidu_error"] = _baidu_err.get("reason")
            out["reason"] = str(_baidu_err.get("reason") or out.get("reason"))
        if locals().get("_paddle_err"):
            out["paddle_error"] = _paddle_err.get("reason")
            out["reason"] = str(_paddle_err.get("reason") or out.get("reason"))
        # T-148：渲染器不可用是扫描件 OCR 的根因，不能被上层 OCR 错误覆盖掉；
        # 上层据此把「需要 OCR 但 OCR 能力不可用」显式表达出来。
        if out.get("ocr_unavailable"):
            _cap_reason = str((out.get("ocr_capability") or {}).get("reason") or "")
            out["reason"] = ("PDF 渲染不可用（OCR 无法执行），" + str(out.get("reason") or "")
                             + (("；" + _cap_reason) if _cap_reason else ""))[:900]
    return out



def status() -> dict:
    """OCR 可用状态：给产品 UI/健康检查用，不触发实际识别。

    T-148：额外带 ``pdf_render`` 三态能力（图像 PDF OCR 的前置渲染能力），
    让健康检查/模型页能显示「渲染器不可用」，而不是只显示 OCR 凭据有没有配。
    """
    cmd = os.environ.get("RULEPROOF_OCR_CMD", "")
    cfg = _dedicated_ocr_cfg()
    paddle = {}
    try:
        from . import paddleocr as _paddle
        paddle = _paddle.status()
    except Exception:
        paddle = {}
        logging.getLogger(__name__).debug("paddle ocr status skipped", exc_info=True)
    baidu = {}
    try:
        from . import baidu_ocr as _baidu
        baidu = _baidu.status()
    except Exception:
        baidu = {}
        logging.getLogger(__name__).debug("baidu ocr status skipped", exc_info=True)
    configured = bool(cmd or cfg or baidu.get("configured") or paddle.get("configured"))
    mode = ("baidu-unlimited-ocr" if baidu.get("configured") else
            "paddleocr-vl" if paddle.get("configured") else
            "external_cmd" if cmd else ("vision" if cfg else "none"))
    _render = {}
    try:
        _cap = pdf_render_capability()
        _render = {k: _cap.get(k) for k in ("status", "available", "source", "reason", "hint")}
    except Exception:  # noqa: BLE001 - 健康检查不能因探测异常而失败
        logging.getLogger(__name__).warning("pdf render capability status skipped", exc_info=True)
    return {"configured": configured, "mode": mode,
            "has_external_cmd": bool(cmd), "has_vision": bool(cfg),
            "has_paddle": bool(paddle.get("configured")),
            "has_baidu": bool(baidu.get("configured")),
            "pdf_render": _render, "baidu": baidu, "paddle": paddle}
