import logging
import re
from datetime import datetime
"""事实层审核：任意文档（docx/pdf/xlsx）→ deepparse 抽事实 → 通用规则判定。

这是"规则迁移到事实层"：规则不再读 xlsx 表头，而是读统一的 Fact，
因此任何真实文件都能过同一套规则。当前覆盖：日期一致/版本占位符/温度/浓度/名称。
"""
from . import deepparse


# ---------------------------------------------------------------- 事实定位 / 表格列名（日期/重量共用）
_VALUE_DATE_RE = re.compile(r"^(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})日?$")


def _value_regex(val: str):
    """把归一后的日期值（如 2026-11-08）还原成可匹配原文写法的正则（含 2026年11月8日）。"""
    m = _VALUE_DATE_RE.match(str(val or ""))
    if not m:
        return None
    return re.compile(rf"{m.group(1)}[-/年]\s*0?{int(m.group(2))}[-/月]\s*0?{int(m.group(3))}日?")


def _fact_span(raw: str, fact: dict):
    """返回事实数值在原文中的 (起点, 原文长度)；定位失败 (-1, 0)。

    优先用事实自带的 context（抽取时的原文片段）定位，再在片段内定位数值；
    日期值已归一为 YYYY-MM-DD，原文可能是 2026年11月8日，因此用 _value_regex 兜底，
    避免「按归一值找不到 → 回退到 context 起点」导致字段语义窗口整体错位。
    """
    raw = str(raw or "")
    val = str((fact or {}).get("value") or "")
    ctx = str((fact or {}).get("context") or "")
    rx = _value_regex(val) if val else None
    if ctx:
        p = raw.find(ctx)
        if p >= 0:
            limit = p + len(ctx) + len(val) + 8
            if val:
                q = raw.find(val, p, limit)
                if q >= 0:
                    return q, len(val)
            if rx:
                m = rx.search(raw, p, limit)
                if m:
                    return m.start(), m.end() - m.start()
            return p, len(ctx)
    if val:
        q = raw.find(val)
        if q >= 0:
            return q, len(val)
    if rx:
        m = rx.search(raw)
        if m:
            return m.start(), m.end() - m.start()
    return -1, 0


def _table_column_label(raw: str, pos: int, span_len: int) -> str:
    """表格行事件：向上找同列数的表头行，返回该列列名（如 实施日期/重量/投料量）。

    非表格行或找不到表头返回空串。docx 表格与 xlsx 单元格在 deepparse 文本里都是
    「a | b | c」形式，且表头行在数据行上方，因此可按列下标对齐恢复字段语义。
    """
    raw = str(raw or "")
    if pos < 0:
        return ""
    ls = raw.rfind("\n", 0, pos) + 1
    le = raw.find("\n", pos + max(1, int(span_len)))
    if le < 0:
        le = len(raw)
    line = raw[ls:le]
    if "|" not in line:
        return ""
    cells = line.split("|")
    offset = pos - ls
    col, acc = -1, 0
    for i, c in enumerate(cells):
        if acc <= offset <= acc + len(c):
            col = i
            break
        acc += len(c) + 1
    if col < 0:
        return ""
    prev_lines = raw[:ls].split("\n") if ls > 0 else []
    for back in reversed(prev_lines[-12:]):
        if "|" not in back:
            continue
        hcells = back.split("|")
        if len(hcells) != len(cells):
            continue
        head = hcells[col].strip()
        if head and not re.search(r"\d", head):
            return head
    return ""


# ---------------------------------------------------------------- 日期一致性（T-146 误报修复）
# 旧口径（误报根因）：_distinct_dates(facts) = 全文所有 kind=date 的值去重，len>1 即判
#   critical「日期不一致」。
# 为什么错：一份正常文档天然包含多个不同语义的日期——批准日 / 编制完成日 / 实施开始日 /
#   表格实施日期——全文去重后的「多值」不等于「不一致」。干净底稿 80/80 因此被 100%
#   打上 critical 误报（CC-045 三日期：2026-11-01 批准、2026-11-08 编制、2026-11-10 实施）。
# 新口径：先按「字段语义」给每个日期归类——显式字段名（实施日期/检验日期…）、表格列名，
#   或紧邻的角色词（编制于/批准生效…）；**只有同一字段出现 ≥2 个不同值**才判不一致。
#   不同字段各一值属正常业务事实，不报；字段语义无法判定的日期不参与比对（宁可不报，不猜）。
# 级别：warning + certainty=probable + degraded=True（需人工复核，不进 critical 主队列）。
_DATE_FIELD_LABEL_RE = re.compile(
    r"((?:[\u4e00-\u9fa5]{2,8}?)?(?:日期|时间))\s*(?:[:：|｜]|为|是|于|=)?\s*$")
_DATE_ROLE_WORDS = (
    "批准", "审批", "核准", "签发", "编制", "拟制", "起草", "填写", "复核", "审核",
    "校对", "检验", "检测", "验收", "实施", "执行", "生效", "启用", "发布", "公布",
    "更新", "修订", "更改", "签署", "记录", "归档",
)
_DATE_ROLE_BEFORE_RE = re.compile(
    "(" + "|".join(_DATE_ROLE_WORDS) + r")\s*(?:日期|时间)?\s*(?:为|是|于|[:：])?\s*$")
# 后缀窗口允许数字/空格/中文标点（如「2026年11月8日09:00 林澄完成编制」），
# 但遇到句末标点/换行即停，避免把下一句的角色词归到本日期上。
_DATE_ROLE_AFTER_RE = re.compile(
    r"^(?:日)?(?:[^。；;！？!?\n]{0,16}?)(" + "|".join(_DATE_ROLE_WORDS) + ")")


def _date_field_label(raw: str, fact: dict) -> str:
    """给日期事实归「字段语义」标签；无法判定返回空串（不参与一致性比对）。"""
    raw = str(raw or "")
    pos, span_len = _fact_span(raw, fact)
    if pos < 0:
        return ""
    before = raw[max(0, pos - 24):pos]
    after = raw[pos + span_len:pos + span_len + 24]
    m = _DATE_FIELD_LABEL_RE.search(before)
    if m:
        lab = m.group(1)
        head = lab[:-2] if lab.endswith(("日期", "时间")) else lab
        return head if len(head) >= 2 else lab
    head = _table_column_label(raw, pos, span_len)
    if head and re.search(r"(日期|时间)$", head):
        head = head[:-2] if head.endswith(("日期", "时间")) else head
        return head if len(head) >= 2 else head
    m = _DATE_ROLE_BEFORE_RE.search(before)
    if m:
        return m.group(1)
    m = _DATE_ROLE_AFTER_RE.search(after)
    if m:
        return m.group(1)
    return ""


def _within_date_tolerance(values: list, tol_days: int) -> bool:
    if tol_days <= 0:
        return False
    try:
        parsed = [datetime.strptime(str(v)[:10].replace("/", "-"), "%Y-%m-%d") for v in values]
    except Exception:
        return False
    return bool(parsed) and (max(parsed) - min(parsed)).days <= tol_days


def _date_conflicts(facts, raw: str) -> list:
    """同字段多值 → 日期不一致结论；不同字段各一值不报。"""
    groups = {}
    for f in facts or []:
        if (f or {}).get("kind") != "date":
            continue
        label = _date_field_label(raw, f)
        if not label:
            continue
        groups.setdefault(label, set()).add(str(f.get("value") or ""))
    if not groups:
        return []
    tol = 0
    try:
        from . import hooks as _hk_dt
        tol = int(_hk_dt.param_option("RW20260526004", "date_tolerance_days", 0) or 0)
    except Exception:
        logging.getLogger(__name__).debug("date tolerance read skipped", exc_info=True)
    out = []
    for label in sorted(groups):
        vals = sorted(v for v in groups[label] if v)
        if len(vals) < 2:
            continue
        if _within_date_tolerance(vals, tol):
            continue
        out.append({"id": "F-日期", "level": "warning", "title": "同一字段日期不一致",
                    "detail": f"字段「{label}」出现 {len(vals)} 个不同日期：{', '.join(vals[:5])}",
                    "evidence": vals, "certainty": "probable", "degraded": True})
    return out


# ---------------------------------------------------------------- 重量单位（T-146 误报修复）
# 旧口径（误报根因）：kind=weight 且 unit=kg 且 value>50 → warning「量级异常，疑似 kg/g 混淆」。
# 为什么错：以 kg 为单位的配料/投料/验收记录 50–400kg 本就是正常量级，「数值大」不是问题；
#   干净底稿 20 份 × 6 条 warning 全部来自这个量级猜测（100kg/293kg 等）。
# 新口径：只有「同一指标同时以 kg 与 g 两种单位表达、且两个数值近似相等」——即同一指标被标了
#   互差约 1000 倍的单位——才是真正疑似 kg/g 混淆，报 warning；
#   归属证据必须是同一 object（如「投料量」）或同一字段名（净重/投料量/表头重量列），
#   单值量级、不同指标各自带单位都**不报**；无归属证据时不猜测（宁可不报）。
_W_KG_UNITS = ("kg", "千克", "公斤")
_W_G_UNITS = ("g", "克")
_WEIGHT_LABEL_RE = re.compile(
    r"(净重|毛重|总重|单重|载重|承重|皮重|重量份|投料量|配方量|重量|投料|用量|质量|称量|秤量|计量)"
    r"\s*(?:[:：为是]|计|约)?\s*$")
_WEIGHT_COL_HINT = ("重量", "净重", "毛重", "投料", "用量", "质量", "称重", "称量", "计量")


def _weight_metric_label(raw: str, fact: dict) -> str:
    """给重量事实归「字段语义」标签（净重/投料量/表头重量列…）；无法判定返回空串。"""
    raw = str(raw or "")
    pos, span_len = _fact_span(raw, fact)
    if pos < 0:
        return ""
    m = _WEIGHT_LABEL_RE.search(raw[max(0, pos - 24):pos])
    if m:
        return m.group(1)
    head = _table_column_label(raw, pos, span_len)
    if head and not re.search(r"\d", head) and any(k in head for k in _WEIGHT_COL_HINT):
        return head
    return ""


def _weight_confusions(facts, raw: str) -> list:
    wf = [f for f in facts or [] if (f or {}).get("kind") == "weight"]
    kg_f = [f for f in wf if str(f.get("unit") or "").strip().lower() in _W_KG_UNITS]
    g_f = [f for f in wf if str(f.get("unit") or "").strip().lower() in _W_G_UNITS]
    if not kg_f or not g_f:
        return []
    out, seen = [], set()
    for a in kg_f:
        for b in g_f:
            try:
                va, vb = float(a.get("value")), float(b.get("value"))
            except (TypeError, ValueError):
                continue
            if va <= 0 or vb <= 0:
                continue
            # 数值近似相等（±1%）→ 同一数值一边写 kg、一边写 g，归一后相差约 1000 倍
            if abs(va - vb) > max(va, vb) * 0.01:
                continue
            obj_a = str(a.get("object") or "").strip()
            obj_b = str(b.get("object") or "").strip()
            lab_a = _weight_metric_label(raw, a)
            lab_b = _weight_metric_label(raw, b)
            same_obj = bool(obj_a) and obj_a == obj_b
            same_label = bool(lab_a) and lab_a == lab_b
            if not (same_obj or same_label):
                continue
            key = (obj_a or lab_a or "|", round(va, 6))
            if key in seen:
                continue
            seen.add(key)
            metric = obj_a or lab_a
            out.append({"id": "F-单位", "level": "warning", "title": "重量单位疑似混淆",
                        "detail": f"同一指标（{metric}）同时出现 {va:g}kg 与 {vb:g}g"
                                  f"（数值相同、单位互差约 1000 倍），疑似 kg/g 混淆",
                        "evidence": [str(a.get("context") or ""), str(b.get("context") or "")],
                        "certainty": "probable", "degraded": True})
    return out


# F-16：工序阶段 + 要求方向识别（fact-fallback 不得用裸子串把合规值判成 critical）
_SENT_SEPS = "。；;!！?？\n"
_DIR_UPPER = ("不高于", "不得超过", "不得高于", "不超过", "不大于", "以下", "以内", "≤", "<=")
_DIR_LOWER = ("不低于", "不得低于", "不少于", "不小于", "以上", "≥", ">=")
_HEAT_STAGE = ("加热", "蒸煮", "热处理", "烹饪", "油炸", "烘烤", "煎", "中心温度达到", "保温")
_COOL_STAGE = ("冷却", "速冷", "降温", "冷藏", "冷冻", "暂存", "库温", "水温")


def _fact_window(raw: str, fact: dict):
    """定位事实数值在原文中的位置：返回 (句内前缀, 紧邻后缀, 阶段上下文)。"""
    raw = str(raw or "")
    if not raw:
        return "", "", ""
    ctx = str((fact or {}).get("context") or "")
    pos = raw.find(ctx) if ctx else -1
    if pos < 0:
        val0 = str((fact or {}).get("value") or "")
        pos = raw.find(val0) if val0 else -1
    if pos < 0:
        return "", "", ""
    val = str((fact or {}).get("value") or "")
    vpos = pos
    if val:
        idx = raw.find(val, pos, pos + max(len(ctx), 8) + 8)
        if idx >= 0:
            vpos = idx
    start = 0
    for sep in _SENT_SEPS:
        j = raw.rfind(sep, 0, vpos)
        if j + 1 > start:
            start = j + 1
    end = len(raw)
    for sep in _SENT_SEPS:
        j = raw.find(sep, vpos + len(val))
        if j >= 0 and j < end:
            end = j
    prefix = raw[start:vpos]
    # 后缀只取数值后紧邻的一小段（到标点为止），避免同一长句后半段的“以下/不高于”
    # 被错误归到前面数值的要求方向上（工序目标值 vs 限值要求）
    suffix_raw = raw[vpos + len(val):end]
    suffix = ""
    for ch in suffix_raw[:12]:
        if ch in "，,、。；;!！?？\n":
            break
        suffix += ch
    stage_window = raw[max(0, start - 160):end]
    return prefix, suffix, stage_window


def _requirement_direction(text: str) -> str:
    t = str(text or "")
    up = any(k in t for k in _DIR_UPPER)
    low = any(k in t for k in _DIR_LOWER)
    if up and not low:
        return "upper"
    if low and not up:
        return "lower"
    if up and low:
        return "mixed"
    return ""


def _stage_of(text: str) -> str:
    t = str(text or "")
    heat = any(k in t for k in _HEAT_STAGE)
    cool = any(k in t for k in _COOL_STAGE)
    if heat and not cool:
        return "heat"
    if cool and not heat:
        return "cool"
    if heat and cool:
        return "mixed"
    return ""


def _temp_finding(fid, level, title, detail, evidence, *, certainty, degraded,
                  direction="", stage="", confidence=None) -> dict:
    return {"id": fid, "level": level, "title": title, "detail": detail,
            "evidence": list(evidence or []), "certainty": certainty,
            "degraded": bool(degraded), "direction": direction or "",
            "stage": stage or "", "confidence": confidence}


def review_text(text: str, label: str = "合并文档", category: str = "") -> dict:
    """对合并后的文本做事实层审核（多文件当一份处理）。"""
    facts = [f.to_dict() for f in deepparse.extract_facts(text, label)]
    return _review(facts, text, label, category)


def review_document(path: str, category: str = "") -> dict:
    """事实层审核，返回 findings + 摘要。"""
    parsed = deepparse.parse_and_extract(path)
    return _review(parsed["facts"], parsed["doc"].get("text", ""), path, category)


def _review(facts, raw, source, category=""):
    findings = []

    # 1. 日期一致性（T-146 误报修复：按字段语义归类后才比对；尊重 date_tolerance_days 容差）
    #    旧实现「全文日期去重 >1 即 critical」会把批准日/编制日/实施日这类正常多日期文档
    #    100% 判成不一致；新实现只报「同一字段出现多个不同值」，且降级为 warning/probable。
    findings.extend(_date_conflicts(facts, raw))

    # 2. 版本号占位符（编号/版本字段为 X）
    import re as _re
    if _re.search(r"(编号|版本号|版本)[:：]\s*[Xx]\b", raw):
        findings.append({"id": "F-版本", "level": "critical", "title": "版本号占位符",
                         "detail": "版本/编号字段为占位符 X", "evidence": ["版本号 X"]})
    versions = [f for f in facts if f["kind"] == "version"]
    x_ver = [v for v in versions if v["value"].upper() == "X"]
    if x_ver:
        findings.append({"id": "F-版本", "level": "critical", "title": "版本号占位符",
                         "detail": f"{len(x_ver)} 处版本号为 X", "evidence": [v["value"] for v in x_ver]})

    # 温度/浓度阈值从参数表读取（内置规则可被 RSI 真正修订）
    from . import hooks as _hk_p
    _T_HEAT = float(_hk_p.param_value("RW20260525005", "value", 85))
    _T_COOL = float(_hk_p.param_value("RW20260525009", "value", 10))
    _C_DIS = float(_hk_p.param_value("RW20260525006", "value", 200))
    # 3. 温度限值（中心温度≥阈值、冷却≤阈值、冷藏暂存区间）
    #    F-16：必须识别工序阶段与要求方向（≤/≥/冷却至/不高于/不低于），
    #    方向/阶段无法判定的结论降级为提示（probable/degraded），不得 certainty=certain critical。
    for f in facts:
        if f["kind"] != "temp":
            continue
        try:
            v = float(f["value"])
        except Exception:
            continue
        prefix, suffix, stage_window = _fact_window(raw, f)
        direction = _requirement_direction(prefix + suffix) or _requirement_direction(prefix)
        stage = _stage_of(stage_window) or _stage_of(prefix)
        obj = str(f.get("object") or "")
        if "中心温度" in obj:
            # 上限要求（不高于/不超过/以下…）是另一类约束，不能按 ≥85℃ 判不合格
            if direction == "upper":
                continue
            # 冷却阶段的上限/目标值不按加热 ≥85℃ 判
            if stage == "cool":
                continue
            if v < _T_HEAT:
                confident = stage == "heat" or direction == "lower"
                if confident:
                    findings.append(_temp_finding(
                        "F-中心温度", "critical", "中心温度未达标",
                        f"{f['value']}℃ < {_T_HEAT:g}℃", [f["context"]],
                        certainty="certain", degraded=False, direction=direction, stage=stage))
                else:
                    # 无加热阶段/下限方向证据：降级为提示，转人工复核，不产出误报级 critical
                    findings.append(_temp_finding(
                        "F-中心温度", "info", "中心温度疑似未达标（无法确认工序阶段/要求方向）",
                        f"{f['value']}℃ 低于 {_T_HEAT:g}℃，但原文未明确加热阶段或下限要求，需人工复核",
                        [f["context"]], certainty="probable", degraded=True,
                        direction=direction, stage=stage))
        if "冷却" in obj and v > _T_COOL:
            target_only = ("至" in prefix) and direction != "upper"
            if direction == "upper":
                findings.append(_temp_finding(
                    "F-冷却", "warning", "冷却温度超标",
                    f"{f['value']}℃ > {_T_COOL:g}℃", [f["context"]],
                    certainty="certain", degraded=False, direction=direction, stage=stage))
            elif target_only:
                # “冷却至 92℃”是工序目标值，不是 ≤10℃ 限值要求，不能据此判超标
                continue
            else:
                findings.append(_temp_finding(
                    "F-冷却", "info", "冷却温度疑似超标（无法确认要求方向）",
                    f"{f['value']}℃ 高于 {_T_COOL:g}℃，但原文未给出上限要求，需人工复核",
                    [f["context"]], certainty="probable", degraded=True,
                    direction=direction, stage=stage))
        if ("冷藏" in obj or "库内温度" in obj or "暂存" in obj) and v > 8:
            if direction == "upper":
                findings.append(_temp_finding(
                    "F-冷藏", "warning", "冷藏暂存温度超标",
                    f"{f['value']}℃ > 8℃", [f["context"]],
                    certainty="certain", degraded=False, direction=direction, stage=stage))
            elif "至" in prefix and direction != "upper":
                continue
            else:
                findings.append(_temp_finding(
                    "F-冷藏", "info", "冷藏暂存温度疑似超标（无法确认要求方向）",
                    f"{f['value']}℃ 高于 8℃，原文未给出上限要求，需人工复核",
                    [f["context"]], certainty="probable", degraded=True,
                    direction=direction, stage=stage))

    # 4. 消毒浓度 ≥200ppm
    for f in facts:
        if f["kind"] == "conc" and float(f["value"]) < _C_DIS:
            findings.append({"id": "F-消毒", "level": "warning", "title": "消毒浓度未达标",
                             "detail": f"{f['value']}ppm < {_C_DIS:g}ppm", "evidence": [f["context"]]})

    # 5. 解冻时长 ≥20h（时间 + 解冻上下文）
    for f in facts:
        if f["kind"] == "time" and "解冻" in f["object"] and f["unit"] in ("h", "小时") and float(f["value"]) < 20:
            findings.append({"id": "F-解冻", "level": "warning", "title": "解冻时长不足",
                             "detail": f"{f['value']}{f['unit']} < 20h", "evidence": [f["context"]]})

    # 6. 签名占位符
    if _re.search(r"(检验员|审核员|复核|签名)[:：]\s*[Xx]\b", raw):
        findings.append({"id": "F-签名", "level": "critical", "title": "签名占位符",
                         "detail": "检验员/审核员/复核签名为 X", "evidence": ["签名 X"]})

    # 7. 重量不匹配（设计总重量 vs 半成品合计）
    dm = _re.search(r"设计总重量[:：]?\s*(\d+(?:\.\d+)?)\s*(kg|g|千克|克)", raw)
    hm = _re.search(r"半成品合计[:：]?\s*(\d+(?:\.\d+)?)\s*(kg|g|千克|克)", raw)
    if dm and hm:
        def _g(v, u):
            return float(v) * (1000 if u in ("kg", "千克") else 1)
        dg, hg = _g(dm.group(1), dm.group(2)), _g(hm.group(1), hm.group(2))
        if abs(dg - hg) > max(dg, hg) * 0.01:
            findings.append({"id": "F-重量", "level": "warning", "title": "重量不匹配",
                             "detail": f"设计总重量 {dg:g}g ≠ 半成品合计 {hg:g}g", "evidence": [raw[:60]]})

    # 8. 重量单位疑似混淆（T-146 误报修复：只报同指标 kg/g 互差 1000 倍的真实混淆信号）
    #    旧实现「kg 且 value>50 即量级异常」把 100kg/293kg 这类正常配料量级全部判成疑似混淆，
    #    干净底稿 20 份 × 6 条 warning 全部来自它。新实现要求「同 object 或同一行同时出现
    #    kg 与 g 且数值近似相等」，单值量级不报。
    findings.extend(_weight_confusions(facts, raw))

    # 9. 产品名称错别字（对照本体词典）
    pm = _re.search(r"产品名称[:：]\s*(\S+)", raw)
    if pm:
        name = pm.group(1).strip().rstrip("。.,，;；、")
        try:
            from .engine import ONTO
            known = [i.name for i in ONTO.instances_of("Product")]
        except Exception:
            known = []
        import difflib
        if known and name not in known:
            close = difflib.get_close_matches(name, known, n=1, cutoff=0.6)
            if close:
                findings.append({"id": "F-名称", "level": "warning", "title": f"产品名称疑似错别字：{name}",
                                 "detail": f"与已知名称“{close[0]}”相近", "evidence": [name]})

    # 审核类型（一级）过滤：只保留该大类下的规则
    from . import audit_category as _ac
    if category:
        findings = [f for f in findings if _ac.allow_fact_rule(category, f["id"])]
    critical = [f for f in findings if f["level"] == "critical"]
    return {
        "source": source,
        "fact_count": len(facts),
        "findings": findings,
        "summary": {"critical_count": len(critical), "warning_count": len(findings) - len(critical),
                    "status": "不通过" if critical else "通过"},
    }
