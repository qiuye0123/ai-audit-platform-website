#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T-95 四角色大量演示数据扩充（独立脚本，幂等，不改 seed.py / app.js / 前端 / dist）。

用途
----
在 ``seed.py`` 建好的临时/演示库上，一次性写入四个演示账号都能看到的大量演示数据：

- 审核员（13700002222 王芳）/ 业务管理员（13500001111 周敏）
  · t-default 60+ 演示项目（completed / reviewing / draft 混合），findings 800+，
    每条 finding 都带 anchor 位置 + evidence 证据；completed 项目同时有已复核
    和待复核发现，审核员本人项目可直接在「问题列表」里复核。
  · 80+ 审计日志、50+ 站内消息、20+ 规则反馈 / 错误书、20+ 规则与版本、
    10+ 规则冲突、15+ 点位确认（含多个空间）。
  · 本体建模：30+ 中文实体（工序/半成品/产品/指标/单位/主体/文档/字段）、
    60+ 别名、40+ 关系（produced_by / measured_by / uses_unit / document_field /
    document_party），并可追溯到企业词典术语（business_term）与当前空间术语。
  · 规则进化：30+ 进化候选 + 30+ 进化台账，覆盖误报 / 漏报 / 证据不足 /
    规则过严 / 作用域过大，pending / accepted / settled 混合，候选只落痕不自动发布。
  · 规则库：60+ 规则（draft / pending / approved / published / archived 混合）、
    10+ 决策表（draft / published / archived 混合）；冲突 20+，A/B 规则真实存在。
- 系统管理员（13800000000 陈志远）
  · 20+ 演示账号（reviewer / admin，统一演示口令 Demo@123456）、10+ 工作空间
    （doc_types 覆盖食物工艺/合同/招标/申报/通用等多类；如平台已落地「其他」类型会自动纳入）、
    5+ 开放平台应用与投递事件；模型/智能体沿用 seed.py 现有数据，不重复写。
- 平台运营（13600003333 赵磊）
  · 10+ 租户（正式/试用/停用/到期混合）、12+ 租户管理员、平台侧审计日志、
    密码重置记录。平台「消息中心」由租户有效期/停用/缺管理员自动派生，无需单独写入。

安全边界
--------
1. 只写演示数据，统一使用固定 ID + ``INSERT OR IGNORE`` / 存在检查，重复运行计数稳定；
   不覆盖 ``case-hist-*`` / ``case-biz-*`` / ``case-complex-*`` 现有夹具，也不改
   seed.py 生成的账号/规则/模型/智能体行。
2. 文档只引用仓库内现有 ``seed/`` 演示文件路径，不复制任何大文件。
3. 生产保护：``RULEPROOF_ENV=prod`` 默认直接拒绝；默认库 ``data/ruleproof.db``
   只有在显式 ``RULEPROOF_SEED_DEMO=1`` 或 ``--allow-live-db`` 时才允许写入。
4. 所有数据均标注「演示」字样，不代表真实客户材料，也不代表真实准确率。

用法
----
    # 1) 先用 seed.py 建库（临时库即可）
    RULEPROOF_DB=/tmp/demo_bulk/demo.db RULEPROOF_ENV=dev python3 seed.py
    # 2) 再扩充演示数据（可重复执行）
    RULEPROOF_DB=/tmp/demo_bulk/demo.db python3 seed_demo_bulk.py \
        --summary-json /tmp/demo_bulk/bulk_summary.json

退出码：0 = 全部目标达成；1 = 有目标未达成（输出 NOT DONE）；2 = 前置/安全校验失败。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

if sys.version_info < (3, 10):  # pragma: no cover - 与 ./rp / start.sh 解释器要求一致
    print("错误：需要 Python 3.10+（app.db 使用 PEP 604 语法）", file=sys.stderr)
    raise SystemExit(127)

# --------------------------------------------------------------------------- 常量
TENANT = "t-default"
WS_DEFAULT = "ws-default"
DEMO_PWD = "Demo@123456"
BASE_DAY = datetime(2026, 10, 1, 9, 0, 0)

# 受保护的既有测试夹具：本脚本绝不写入这些前缀的行。
PROTECTED_CASE_PREFIXES = ("case-hist-", "case-biz-", "case-complex-")

# 现有演示文件池（只用 seed/ 下已存在的文件，不复制大文件）。
FILE_POOL = [
    ("seed/demo_docs/华东食品-酱卤牛肉生产许可申报材料-2026-10.docx", "申报材料", "application", "application"),
    ("seed/demo_docs/华东食品-速冻水饺出厂检验报告-2026-06.docx", "检验报告", "food", "food"),
    ("seed/demo_docs/云川软件-源代码保密协议-2026-08.docx", "保密协议", "contract", "contract"),
    ("seed/demo_docs/城投产业园-建设工程施工合同-2026-09.docx", "施工合同", "contract", "contract"),
    ("seed/demo_docs/市公共资源-智慧园区设备采购招标文件-2026-11.docx", "招标文件", "bid", "bid"),
    ("seed/demo_docs/市公共资源-智慧园区设备采购评标报告-2026-11.docx", "评标报告", "bid", "bid"),
    ("seed/demo_docs/星海科技-数据中心运维服务合同-2026-07.docx", "服务合同", "contract", "contract"),
    ("seed/demo_docs/星海科技-设备采购合同-2026-10.docx", "采购合同", "contract", "contract"),
    ("seed/demo_extra_docs/extra_01.docx", "合同补充文件", "contract", "contract"),
    ("seed/demo_extra_docs/extra_02.docx", "招标附件", "bid", "bid"),
    ("seed/demo_extra_docs/extra_03.docx", "工艺记录", "food", "food"),
    ("seed/demo_extra_docs/extra_04.docx", "申报附件", "application", "application"),
    ("seed/demo_extra_docs/extra_05.docx", "施工记录", "contract", "contract"),
    ("seed/demo_extra_docs/extra_06.docx", "验收记录", "general", "general"),
    ("seed/demo_extra_docs/extra_07.docx", "评审记录", "bid", "bid"),
    ("seed/demo_extra_docs/extra_08.docx", "检验记录", "food", "food"),
    ("seed/food_history/华东食品-酱卤牛肉-工艺记录-2026-08.pdf", "食品工艺书", "food", "food"),
    ("seed/food_history/华东食品-速冻水饺-工艺记录-2026-06.pdf", "食品工艺书", "food", "food"),
    ("seed/food_history/华东食品-每日坚果-工艺记录-2026-07.pdf", "食品工艺书", "food", "food"),
    ("seed/complex_docs/复杂演示-智慧园区设备采购合同.docx", "采购合同", "contract", "contract"),
    ("seed/complex_docs/复杂演示-设备清单与报价.xlsx", "设备清单与报价", "contract", "contract"),
    ("seed/complex_docs/复杂演示-到货验收报告.pdf", "到货验收报告", "contract", "contract"),
    ("seed/complex_docs/复杂演示-网络设备招标文件.docx", "招标文件", "bid", "bid"),
    ("seed/complex_docs/复杂演示-网络设备招标文件-附件.docx", "招标附件", "bid", "bid"),
    ("seed/complex_docs/复杂演示-投标报价与评分.xlsx", "投标报价与评分", "bid", "bid"),
    ("seed/complex_docs/复杂演示-招标公告.pdf", "招标公告", "bid", "bid"),
    ("seed/complex_docs/复杂演示-酱卤牛肉工艺规程.docx", "工艺规程", "food", "food"),
    ("seed/complex_docs/复杂演示-工艺参数与检验记录.xlsx", "工艺参数与检验记录", "food", "food"),
    ("seed/complex_docs/复杂演示-成品检验报告.pdf", "成品检验报告", "food", "food"),
]

CATEGORY_LABEL = {
    "contract": "合同审核", "food": "食品工艺审核", "bid": "招标采购审核",
    "application": "许可申报审核", "general": "通用文档审核",
}
CATEGORY_DOC_TYPE = {
    "contract": "采购合同", "food": "食品工艺书", "bid": "招标文件",
    "application": "申报材料", "general": "通用文件",
}
TITLE_POOL = {
    "contract": [
        "合同金额与预算上限不一致", "付款节点与验收条件脱节", "违约金比例缺失",
        "合同主体名称与资质证书不一致", "服务期限与到期日矛盾", "质保金比例超出约定",
        "交付期与开工令日期冲突", "保密条款范围过窄", "争议解决条款缺失",
        "发票类型未约定", "验收标准缺少可量化指标", "附件清单与正文不一致",
    ],
    "food": [
        "卤制中心温度低于工艺下限", "保温时间不足", "冷却时限超出规定",
        "净含量偏差接近上限", "检验记录缺少签字", "配料表投料量不一致",
        "批次号前后不一致", "菌落总数接近限值", "亚硝酸盐结果异常",
        "工艺参数单位混用", "原料解冻温度超范围", "包装标签标识缺失",
        "生产日期与批号不对应", "设备清洗记录缺失",
    ],
    "bid": [
        "技术负偏离超过限制", "投标人业绩数量不足", "项目经理资格不符",
        "报价与清单合计不一致", "资格条件与评审办法冲突", "投标截止时间与公告不一致",
        "价格分计算错误", "质保期不满足要求", "投标文件缺少附件",
        "评分表分值合计异常", "最高限价超过批复预算", "投标有效期不足",
    ],
    "application": [
        "申报材料缺少布局图", "食品安全管理员配置缺失", "生产场所地址不一致",
        "许可类别与产品不匹配", "检验设备清单缺失", "申报批次与试制记录不符",
    ],
    "general": [
        "文档缺少版本号", "签署日期缺失", "附件与正文引用不一致",
        "关键字段为占位符", "跨文档数量不一致", "审批流程缺少节点",
        "生效条件未明确", "变更记录缺失",
    ],
}
SUGGEST_POOL = [
    "按原文补证后由审核员复核；演示数据不构成正式审核结论。",
    "统一数值/单位口径，补充签批记录后再复核；演示数据。",
    "核对引用条款与附件一致性，必要时退回复核；演示数据。",
    "补齐缺失的日期与签字信息，保留原始记录；演示数据。",
    "与对应单据交叉核对，确认口径后登记复核意见；演示数据。",
]

REVIEWER_NAMES = ["李静", "张伟", "陈晨", "刘洋", "杨帆", "黄磊", "赵丹", "周涛",
                  "吴倩", "徐明", "孙悦", "马超", "朱琳", "胡兵", "郭婷", "何勇"]
ADMIN_NAMES = ["林芳", "郑凯", "谢敏", "罗静", "高翔", "梁宇"]
DISABLED_NAMES = ["钱进", "曹颖"]
DEPARTMENTS = ["质量审核部", "质量审核二组", "合规审核组", "食品质量部", "合同审核组", "招标审核组"]

# 工作空间（系统管理员端 10+）：doc_types 多样，运行时按平台类型库校验/兜底。
SPACES = [
    ("ws-demo-01", "演示空间 · 合同审核", ["采购合同", "销售合同", "服务合同"], True),
    ("ws-demo-02", "演示空间 · 食品工艺", ["食品工艺书", "工艺规程/工艺卡", "质量检验记录"], True),
    ("ws-demo-03", "演示空间 · 招标采购", ["招标文件", "投标文件", "评标报告"], False),
    ("ws-demo-04", "演示空间 · 许可申报", ["资质认定/许可证申请材料", "项目申报书", "承诺函/声明函"], False),
    ("ws-demo-05", "演示空间 · 通用文档", ["公文/通知/函件", "内部管理制度", "会议纪要"], False),
    ("ws-demo-06", "演示空间 · 华东食品线", ["食品工艺书", "检验/试验报告", "生产记录/批记录"], True),
    ("ws-demo-07", "演示空间 · 星海科技线", ["采购合同", "服务合同", "保密协议"], False),
    ("ws-demo-08", "演示空间 · 城投产业园线", ["建设工程施工合同", "履约验收报告", "项目验收报告"], False),
    ("ws-demo-09", "演示空间 · 公共资源线", ["招标文件", "评标报告", "中标通知书"], False),
    ("ws-demo-10", "演示空间 · 抽查复盘", ["质量检验记录", "项目验收报告", "数据分析报告"], False),
]
# 平台类型库不可用/类型名变更时的兜底主类型（仍尽量取现有类型，不伪造）
PREFERRED_DOC_TYPES = ["采购合同", "食品工艺书", "招标文件", "内部管理制度", "质量检验记录"]

# 规则（系统管理员/业务管理员规则库 20+ 条规则、20+ 版本）
DEMO_RULES = [
    ("DEMO-CT-001", "合同金额与预算上限一致性", "limit", "R1", "published",
     "合同含税金额不得超过批复预算上限，超出即判不满足。"),
    ("DEMO-CT-002", "付款节点与验收条件一致性", "consistency", "R2", "published",
     "付款节点必须与验收/交付条件对应，不得早于验收。"),
    ("DEMO-CT-003", "违约金比例合规性", "limit", "R2", "published",
     "延期违约金比例应在合同约定范围内（每日 0.1%–0.5%）。"),
    ("DEMO-CT-004", "合同主体名称一致性", "consistency", "R1", "published",
     "合同甲方/乙方名称须与资质证书主体名称逐字一致。"),
    ("DEMO-FD-005", "卤制中心温度达标", "limit", "R0", "published",
     "卤制工序实测中心温度必须 ≥ 85℃，以工序参数表为准。"),
    ("DEMO-FD-006", "冷却时限合规", "limit", "R1", "published",
     "熟制品应在 2 小时内冷却至 10℃ 以下。"),
    ("DEMO-FD-007", "检验记录签字完整性", "completeness", "R2", "published",
     "检验记录须有检验员签字与日期，缺失即判不满足。"),
    ("DEMO-FD-008", "配料表投料量一致性", "consistency", "R1", "published",
     "配料表投料量与工艺规程总投料量应一致。"),
    ("DEMO-BD-009", "技术负偏离项数限制", "limit", "R1", "published",
     "技术参数负偏离超过 3 项按无效投标处理。"),
    ("DEMO-BD-010", "投标截止时间一致性", "consistency", "R2", "published",
     "招标公告与招标文件的投标截止时间必须一致。"),
    ("DEMO-AP-011", "申报材料完整性", "completeness", "R2", "pending",
     "生产许可申报材料须包含场所布局图、设备清单与人员资质。"),
    ("DEMO-GN-012", "文档版本与日期完整性", "format", "R3", "draft",
     "通用文档应包含版本号与生效日期，占位符视为不满足。"),
]

# 规则扩展（目标：DB 规则 60+，覆盖 draft / pending / approved / published / archived）
DEMO_RULES_EXTRA = [
    ("DEMO-CT-013", "预付款比例上限", "limit", "R1", "published", "预付款比例不得超过合同金额的 30%。"),
    ("DEMO-CT-014", "质保金比例范围", "limit", "R2", "approved", "质保金比例应为合同金额的 3%–5%。"),
    ("DEMO-CT-015", "争议解决条款完整性", "completeness", "R2", "published", "合同须约定争议解决方式与适用法律。"),
    ("DEMO-CT-016", "发票类型与税率一致性", "consistency", "R2", "pending", "发票类型与税率须与合同价款条款一致。"),
    ("DEMO-CT-017", "交付期与开工令一致性", "consistency", "R2", "published", "交付期起算日必须与开工令日期一致。"),
    ("DEMO-CT-018", "保密义务期限", "limit", "R3", "draft", "保密义务期限不得短于合同约定的最低年限。"),
    ("DEMO-FD-019", "冷却工序温度达标", "limit", "R1", "published", "冷却后中心温度应 ≤ 10℃，以工序记录为准。"),
    ("DEMO-FD-020", "杀菌工序时间下限", "limit", "R1", "published", "杀菌时间不得低于工艺规程规定下限。"),
    ("DEMO-FD-021", "包装净含量偏差", "limit", "R2", "approved", "包装净含量偏差不得超过标注值的 ±3%。"),
    ("DEMO-FD-022", "生产日期与批号一致性", "consistency", "R2", "published", "生产日期须与批号编码规则一致。"),
    ("DEMO-FD-023", "检验报告签字完整性", "completeness", "R2", "published", "检验报告须有检验员与审核员签字及日期。"),
    ("DEMO-FD-024", "原料验收记录完整性", "completeness", "R2", "pending", "原料验收记录须含供应商、批次与检验结论。"),
    ("DEMO-FD-025", "过敏原标识完整性", "label", "R1", "published", "含过敏原产品须在标签中完整标识。"),
    ("DEMO-FD-026", "设备清洗记录时效", "frequency", "R2", "published", "设备清洗记录须在每班次内按时登记。"),
    ("DEMO-FD-027", "人员健康证有效期", "personnel", "R2", "draft", "接触直接入口食品人员健康证须在有效期内。"),
    ("DEMO-BD-028", "最高限价合规", "limit", "R1", "published", "投标报价不得超过招标文件最高限价。"),
    ("DEMO-BD-029", "投标保证金比例", "limit", "R2", "approved", "投标保证金不得超过采购预算金额的 2%。"),
    ("DEMO-BD-030", "资格条件与评审办法一致性", "consistency", "R2", "published", "资格条件与评审办法不得互相矛盾。"),
    ("DEMO-BD-031", "投标文件签署有效性", "completeness", "R2", "pending", "投标文件须按招标文件要求签字盖章。"),
    ("DEMO-BD-032", "中标通知书要素完整性", "completeness", "R3", "archived", "中标通知书须包含中标金额、工期与签订期限。"),
    ("DEMO-AP-033", "生产场所地址一致性", "consistency", "R2", "published", "申报材料中的生产场所地址须与营业执照一致。"),
    ("DEMO-AP-034", "试制记录与申报批次一致性", "consistency", "R2", "pending", "试制记录批次须与申报产品批次一致。"),
    ("DEMO-AP-035", "承诺函签署完整性", "completeness", "R2", "archived", "承诺函须由法定代表人或授权代表签署。"),
    ("DEMO-GN-036", "文档版本号非占位符", "format", "R3", "published", "文档版本号不得为占位符或空白。"),
    ("DEMO-GN-037", "生效日期完整性", "format", "R3", "approved", "文档须标注生效日期且格式统一。"),
    ("DEMO-GN-038", "附件清单一致性", "consistency", "R3", "draft", "正文附件清单须与实际附件逐一对应。"),
    ("DEMO-GN-039", "公文签发权限", "personnel", "R3", "pending", "公文须由具备签发权限的岗位签发。"),
    ("DEMO-GN-040", "会议纪要决议项闭环", "record", "R3", "published", "会议纪要须记录决议项、责任人与完成时限。"),
    ("DEMO-CT-041", "供应商资质有效期", "personnel", "R2", "published", "供应商营业执照与资质证书须在有效期内。"),
    ("DEMO-CT-042", "履约验收标准可量化", "limit", "R2", "approved", "履约验收标准须可量化并可复核。"),
    ("DEMO-FD-043", "菌落总数限值", "limit", "R1", "published", "菌落总数不得超过产品执行标准的限值。"),
    ("DEMO-FD-044", "亚硝酸盐限值", "limit", "R1", "published", "亚硝酸盐残留量不得超过标准限值。"),
    ("DEMO-BD-045", "评标报告评分合计", "consistency", "R2", "published", "评标报告各项评分合计须与总分一致。"),
    ("DEMO-AP-046", "许可类别与产品匹配", "consistency", "R2", "pending", "许可类别须覆盖申报产品范围。"),
    ("DEMO-GN-047", "归档版本唯一性", "consistency", "R3", "archived", "同一文档归档版本须唯一可追溯。"),
    ("DEMO-GN-048", "引用标准现行有效", "citation", "R2", "published", "文档引用的标准须为现行有效版本。"),
]

# 决策表（10+，draft / published / archived 混合；rules 采用 when/severity/message/suggestion）
DECISION_TABLE_DEFS = [
    ("DEMO-DT-001", "合同金额+风险等级转人工", "first", "published", "v1.0",
     ["采购合同", "销售合同"], [
         {"when": [{"metric": "合同金额", "op": ">=", "value": 1000000}],
          "severity": "critical", "message": "大额合同需人工复核预算与授权",
          "suggestion": "核对预算批复与授权文件后复核"},
         {"when": [{"metric": "风险等级", "op": "=", "value": "高"}],
          "severity": "warning", "message": "高风险合同需增加复核人",
          "suggestion": "由质量负责人二次复核"},
     ]),
    ("DEMO-DT-002", "投标负偏离+业绩组合风险", "collect", "published", "v1.0",
     ["招标文件", "投标文件"], [
         {"when": [{"metric": "负偏离项数", "op": ">", "value": 3}],
          "severity": "critical", "message": "负偏离超过 3 项，按无效投标处理",
          "suggestion": "核验技术参数负偏离清单"},
         {"when": [{"metric": "业绩数量", "op": "<", "value": 2}],
          "severity": "warning", "message": "业绩数量不足，需资格复核",
          "suggestion": "补充同类项目合同与验收证明"},
     ]),
    ("DEMO-DT-003", "食品工艺参数组合判定", "first", "published", "v1.0",
     ["食品工艺书"], [
         {"when": [{"metric": "中心温度", "op": "<", "value": 85}],
          "severity": "critical", "message": "中心温度低于工艺下限",
          "suggestion": "核实加热工序记录并补证"},
         {"when": [{"metric": "冷却时长", "op": ">", "value": 2}],
          "severity": "warning", "message": "冷却时长超过 2 小时",
          "suggestion": "核对冷却设备记录"},
     ]),
    ("DEMO-DT-004", "净含量与标签一致性", "unique", "published", "v1.0",
     ["食品工艺书", "检验/试验报告"], [
         {"when": [{"metric": "净含量偏差", "op": ">", "value": 3}],
          "severity": "warning", "message": "净含量偏差超过允许范围",
          "suggestion": "复核包装计量记录"},
         {"when": [{"metric": "标签标识", "op": "=", "value": "缺失"}],
          "severity": "critical", "message": "标签标识缺失",
          "suggestion": "补充标签样张与审核记录"},
     ]),
    ("DEMO-DT-005", "申报材料完整性组合", "first", "draft", "v0.1",
     ["资质认定/许可证申请材料"], [
         {"when": [{"metric": "布局图", "op": "=", "value": "缺失"}],
          "severity": "critical", "message": "缺少生产场所布局图",
          "suggestion": "补交布局图后重新申报"},
     ]),
    ("DEMO-DT-006", "合同付款与验收组合", "first", "draft", "v0.1",
     ["采购合同", "服务合同"], [
         {"when": [{"metric": "付款比例", "op": ">", "value": 30}],
          "severity": "warning", "message": "预付款比例偏高",
          "suggestion": "核对付款节点与验收条件"},
     ]),
    ("DEMO-DT-007", "评标评分异常组合", "collect", "published", "v1.0",
     ["评标报告"], [
         {"when": [{"metric": "评分合计", "op": "!=", "value": 100}],
          "severity": "warning", "message": "评分合计与总分不一致",
          "suggestion": "复核评分表与汇总表"},
     ]),
    ("DEMO-DT-008", "废弃-通用文档风险（演示下线）", "first", "archived", "v0.9",
     ["内部管理制度"], [
         {"when": [{"metric": "版本号", "op": "=", "value": "缺失"}],
          "severity": "info", "message": "文档缺少版本号",
          "suggestion": "补充版本号"},
     ]),
    ("DEMO-DT-009", "食品检验结果组合判定", "unique", "published", "v1.0",
     ["检验/试验报告"], [
         {"when": [{"metric": "菌落总数", "op": ">", "value": 100000}],
          "severity": "critical", "message": "菌落总数超限",
          "suggestion": "复检并启动不合格处置"},
         {"when": [{"metric": "亚硝酸盐", "op": ">", "value": 30}],
          "severity": "critical", "message": "亚硝酸盐残留超限",
          "suggestion": "复检并核对配料记录"},
     ]),
    ("DEMO-DT-010", "供应商资质组合校验", "first", "draft", "v0.1",
     ["供应商准入/尽调材料"], [
         {"when": [{"metric": "资质有效期", "op": "=", "value": "已过期"}],
          "severity": "critical", "message": "供应商资质已过期",
          "suggestion": "暂停准入并要求更新资质"},
     ]),
    ("DEMO-DT-011", "培训记录与人员资质", "first", "draft", "v0.1",
     ["培训方案/培训手册"], [
         {"when": [{"metric": "健康证", "op": "=", "value": "缺失"}],
          "severity": "warning", "message": "人员健康证缺失",
          "suggestion": "补齐健康证后上岗"},
     ]),
    ("DEMO-DT-012", "废弃-旧版违规标尺（演示下线）", "first", "archived", "v0.8",
     ["公文/通知/函件"], [
         {"when": [{"metric": "签发人", "op": "=", "value": "缺失"}],
          "severity": "info", "message": "公文缺少签发人",
          "suggestion": "补充签发记录"},
     ]),
]

# 冲突扩展（在既有 12 条基础上追加；A/B 规则均为本轮真实创建的规则编码）
CONFLICT_EXTRA = [
    ("DEMO-CT-013", "DEMO-CT-001", "duplicate", "预付款比例上限与合同金额上限都作用于同一合同主表。",
     "warning", "保留金额上限规则，预付款规则限定付款条款证据", "open"),
    ("DEMO-CT-014", "DEMO-CT-003", "numeric_conflict", "质保金比例范围与违约金比例对同一金额基数口径不同。",
     "warning", "统一以合同总额为计算基数", "resolved"),
    ("DEMO-CT-015", "DEMO-GN-012", "scope_conflict", "争议解决条款完整性与通用文档完整性同时覆盖合同正文。",
     "warning", "通用文档规则排除合同类文档", "open"),
    ("DEMO-CT-016", "DEMO-CT-002", "priority_conflict", "发票税率一致性与付款节点对开票前提的判定优先级未定义。",
     "warning", "付款条件优先校验发票要素", "ignored"),
    ("DEMO-FD-019", "DEMO-FD-005", "numeric_conflict", "冷却温度与卤制中心温度对热处理终点的温度阈值不一致。",
     "critical", "区分加热终点与冷却终点两个阈值", "open"),
    ("DEMO-FD-020", "DEMO-FD-006", "unit_mismatch", "杀菌时间一条按分钟、一条按秒记录，存在单位混用。",
     "warning", "统一为分钟口径并声明单位", "resolved"),
    ("DEMO-FD-021", "DEMO-FD-007", "scope_conflict", "净含量偏差与检验记录签字都要求同一条包装记录证据。",
     "warning", "拆分为计量记录与检验记录两类证据", "open"),
    ("DEMO-FD-022", "DEMO-GN-036", "duplicate", "生产日期与版本号规则都要求文档表头字段，命中会重复提示。",
     "warning", "合并为表头完整性规则", "ignored"),
    ("DEMO-BD-028", "DEMO-BD-009", "priority_conflict", "最高限价与负偏离项数对无效投标的判定优先级未定义。",
     "warning", "先判最高限价，再判负偏离项数", "open"),
    ("DEMO-BD-029", "DEMO-BD-030", "numeric_conflict", "保证金比例与资格条件对采购预算的引用口径不同。",
     "warning", "统一引用批复预算金额", "resolved"),
    ("DEMO-AP-033", "DEMO-AP-034", "scope_conflict", "生产场所地址与试制批次规则都作用于申报主体材料。",
     "warning", "按材料章节限定作用域", "ignored"),
    ("DEMO-GN-040", "DEMO-GN-039", "unit_mismatch", "会议决议完成时限一条按工作日、一条按自然日。",
     "warning", "统一按自然日口径", "resolved"),
]

DEMO_TENANTS = [
    ("t-demo-01", "DEMO-B01", "味源食品（苏州）有限公司", "active", "formal", "2027-12-31", "食品制造", True),
    ("t-demo-02", "DEMO-B02", "星海智造装备有限公司", "active", "trial", "2026-12-10", "装备制造", True),
    ("t-demo-03", "DEMO-B03", "城投供应链管理有限公司", "active", "trial", "2026-11-10", "供应链", True),
    ("t-demo-04", "DEMO-B04", "云川软件技术有限公司", "active", "formal", "2028-03-31", "软件服务", True),
    ("t-demo-05", "DEMO-B05", "清源环保工程有限公司", "active", "trial", "2027-01-20", "环保工程", False),
    ("t-demo-06", "DEMO-B06", "禾丰农业科技有限公司", "active", "trial", "2026-12-31", "农业科技", True),
    ("t-demo-07", "DEMO-B07", "启明医疗器械有限公司", "suspended", "formal", "2027-06-30", "医疗器械", True),
    ("t-demo-08", "DEMO-B08", "远航物流服务有限公司", "suspended", "trial", "2026-09-30", "物流服务", True),
    ("t-demo-09", "DEMO-B09", "江南检验检测有限公司", "active", "formal", "2026-12-05", "检验检测", True),
    ("t-demo-10", "DEMO-B10", "恒信食品配料有限公司", "active", "trial", "2027-02-28", "食品配料", False),
]
TENANT_ADMIN_NAMES = ["王海", "刘敏", "赵强", "孙丽", "周杰", "吴桐", "郑楠", "冯雪",
                      "陈波", "褚懿", "卫蓝", "蒋涛", "沈莹", "韩宇"]
PLATFORM_ADMIN_NAMES = ["赵磊", "许晴", "邓超"]

OPEN_APPS = [
    ("app-demo-01", "AKDEMO202611180001", "演示 ERP 接入", "audit.completed,ping"),
    ("app-demo-02", "AKDEMO202611180002", "演示 OA 审批流", "audit.completed,audit.failed"),
    ("app-demo-03", "AKDEMO202611180003", "演示 供应商门户", "audit.completed"),
    ("app-demo-04", "AKDEMO202611180004", "演示 财务共享中心", "audit.completed,ping"),
    ("app-demo-05", "AKDEMO202611180005", "演示 质量中台", "audit.completed,audit.failed,ping"),
    ("app-demo-06", "AKDEMO202611180006", "演示 数据仓库 ETL", "audit.completed"),
]

CONFLICT_SEEDS = [
    ("DEMO-CT-001", "DEMO-CT-002", "scope_conflict", "合同金额规则与付款节点规则都覆盖采购合同，作用域存在重叠。",
     "warning", "明确两条规则的责任字段与证据范围", "open"),
    ("DEMO-FD-005", "DEMO-FD-006", "priority_conflict", "中心温度与冷却时限规则对「热处理完成」节点优先级未定义。",
     "warning", "中心温度作为硬性前置，冷却时限作为后续校验", "open"),
    ("DEMO-CT-003", "DEMO-BD-009", "numeric_conflict", "违约金比例与负偏离扣分对同一评分项的权重口径不同。",
     "warning", "统一扣分与违约金口径，避免重复计算", "resolved"),
    ("DEMO-FD-007", "DEMO-FD-008", "duplicate", "检验记录签字与配料表一致性都要求同一条记录，命中会重复提示。",
     "warning", "合并为一条记录完整性规则或明确分工", "open"),
    ("DEMO-BD-009", "DEMO-BD-010", "scope_conflict", "技术负偏离与投标截止时间规则都作用于投标文件整体。",
     "warning", "限定各自证据范围（技术附件/公告正文）", "ignored"),
    ("DEMO-CT-002", "DEMO-CT-003", "priority_conflict", "付款节点与违约金规则对逾期定义不一致。",
     "warning", "统一逾期起算点", "open"),
    ("DEMO-FD-005", "DEMO-FD-007", "unit_mismatch", "中心温度一条按 ℃、一条按 ℉ 记录，存在单位混用风险。",
     "critical", "统一摄氏度口径，并在规则中声明单位", "open"),
    ("DEMO-CT-001", "DEMO-CT-004", "numeric_conflict", "金额上限与主体一致性规则对同一合同的适用范围不同。",
     "warning", "明确金额规则仅适用主合同", "resolved"),
    ("DEMO-BD-010", "DEMO-CT-004", "scope_conflict", "主体名称规则同时覆盖招标文件与合同文件。",
     "warning", "在规则库中声明适用文档类型", "open"),
    ("DEMO-AP-011", "DEMO-GN-012", "duplicate", "申报材料完整性与通用文档完整性存在重复检查项。",
     "warning", "保留申报专项规则，通用规则排除申报材料", "open"),
    ("DEMO-FD-006", "DEMO-FD-008", "numeric_conflict", "冷却时限与投料量规则对批次记录的时间戳口径不同。",
     "warning", "统一使用生产批次时间戳", "open"),
    ("DEMO-CT-002", "DEMO-AP-011", "unit_mismatch", "付款比例单位（%/‰）在合同与申报材料中不一致。",
     "warning", "申报材料按百分比口径统一", "ignored"),
]


# --------------------------------------------------------------------------- 基础工具
class Seeder:
    def __init__(self):
        from app import db  # noqa: F401  (延迟导入，确保 RULEPROOF_DB 已生效)
        self.db = db
        self.file_hash_cache: dict[str, str] = {}
        self.inserted: dict[str, int] = {}
        self.warnings: list[str] = []
        self.failures: list[str] = []
        self.decisions: list[dict] = []
        self.findings_index: list[dict] = []
        self.case_meta: dict[str, dict] = {}
        self.rules: list[dict] = []
        self.rule_by_code: dict[str, dict] = {}
        self.ontology_entity_ids: list[str] = []
        self.ontology_alias_ids: list[str] = []
        self.ontology_link_ids: list[str] = []
        self.term_ids: list[str] = []
        self.decision_table_codes: list[str] = []
        self.evolution_task_ids: list[str] = []
        self.rsi_candidate_ids: list[str] = []
        self.conflict_ids: list[str] = []
        self.notes: list[str] = []
        self.other_doc_type_landed = False

    # ---- 通用写入
    def ins(self, c, table: str, row: dict) -> int:
        cols = list(row.keys())
        sql = ("INSERT OR IGNORE INTO " + table + "(" + ",".join(cols) + ") VALUES("
               + ",".join("?" * len(cols)) + ")")
        cur = c.execute(sql, [row[k] for k in cols])
        n = int(cur.rowcount or 0)
        if n:
            self.inserted[table] = self.inserted.get(table, 0) + n
        return n

    def ins_check(self, c, table: str, pk: str) -> bool:
        """固定主键行是否已存在（用于区分“新增/已存在”，辅助幂等埋点）。"""
        try:
            return bool(c.execute("SELECT 1 FROM " + table + " WHERE id=?", (pk,)).fetchone())
        except Exception:
            return False

    def sha_file(self, rel: str) -> str:
        if rel not in self.file_hash_cache:
            path = os.path.join(ROOT, rel)
            with open(path, "rb") as fh:
                self.file_hash_cache[rel] = hashlib.sha256(fh.read()).hexdigest()
        return self.file_hash_cache[rel]

    @staticmethod
    def fmt(dt: datetime) -> str:
        return dt.strftime("%Y-%m-%d %H:%M:%S")

    def count(self, table: str, where: str = "1=1", params: tuple = ()) -> int:
        c = self.db.connect()
        try:
            return int(c.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}", params).fetchone()[0])
        finally:
            c.close()

    def counts(self) -> dict:
        out = {}
        for table in ("user", "tenant", "workspace", "audit_case", "document", "audit_run",
                      "finding", "anchor", "evidence", "decision", "feedback", "conflict",
                      "rule", "rule_version", "decision_table", "decision_table_version",
                      "notification", "audit_log", "open_app", "open_event", "open_sandbox",
                      "password_reset", "auditpoint_confirmation", "onto_entity", "onto_alias",
                      "onto_link", "onto_version", "business_term", "evolution_task",
                      "rsi_candidate"):
            try:
                out[table] = self.count(table)
            except Exception:
                out[table] = -1
        return out


# --------------------------------------------------------------------------- 1. 工作空间（系统管理员 10+）
# --------------------------------------------------------------------------- 1. 工作空间（系统管理员 10+；doc_types 多样）
def _known_doc_types() -> list[str]:
    """平台现有文档类型（审核库 + 客户自定义类型）；不可用时返回空，不伪造。"""
    names: list[str] = []
    try:
        from app.services import auditpoints
        lib = auditpoints.load()
        for d in (lib.document_types or []):
            if isinstance(d, dict) and str(d.get("name") or "").strip():
                names.append(str(d["name"]).strip())
            elif isinstance(d, str) and d.strip():
                names.append(d.strip())
    except Exception:
        pass
    try:
        from app import repositories as R
        for r in R.doc_type_custom.list("status=?", ("active",)):
            n = str(r.get("name") or "").strip()
            if n:
                names.append(n)
    except Exception:
        pass
    return list(dict.fromkeys([n for n in names if n]))


def _effective_doc_types(configured: list[str]) -> tuple[list[str], bool]:
    """按平台类型库校验空间主文件类型；返回 (实际采用类型, 是否含「其他」类型)。"""
    known = _known_doc_types()
    if not known:
        return list(configured)[:5], False
    out = [x for x in configured if x in known]
    has_other = False
    for extra in ("其他", "其他文件", "其他类型", "其他文档"):
        if extra in known:
            if extra not in out:
                out.append(extra)
            has_other = True
            break
    for x in PREFERRED_DOC_TYPES:
        if len(out) >= 3:
            break
        if x in known and x not in out:
            out.append(x)
    for x in known:
        if len(out) >= 3:
            break
        if x not in out:
            out.append(x)
    return out[:5], has_other


def seed_workspaces(s: Seeder, c) -> set[str]:
    """写入演示空间；返回实际存在的空间 id 集合（供项目归属兜底）。

    doc_types 按平台现有类型库校验；「其他」类型如已落地（审核库或客户自定义类型）
    会自动纳入，否则在报告里明确标注未落地，不伪造类型。
    """
    created = set()
    for wid, name, doc_types, point_required in SPACES:
        dts, has_other = _effective_doc_types(doc_types)
        if has_other:
            s.other_doc_type_landed = True
        settings = {
            "visibility": "tenant", "members": [], "doc_types": dts,
            "setup_required": False, "point_confirm_required": bool(point_required),
            "configured_at": s.fmt(BASE_DAY + timedelta(days=2)),
        }
        s.ins(c, "workspace", {
            "id": wid, "tenant_id": TENANT, "name": name, "status": "active",
            "created_by": "user-admin", "created_at": s.fmt(BASE_DAY + timedelta(days=2)),
            "settings_json": json.dumps(settings, ensure_ascii=False),
        })
        # 已存在的演示空间：幂等归一化配置（只动本脚本自己的 ws-demo-*，不碰既有空间）
        c.execute("UPDATE workspace SET settings_json=? WHERE id=? AND tenant_id=? AND settings_json<>?",
                  (json.dumps(settings, ensure_ascii=False), wid, TENANT,
                   json.dumps(settings, ensure_ascii=False)))
    for row in c.execute("SELECT id FROM workspace WHERE tenant_id=? AND id LIKE 'ws-demo-%'",
                         (TENANT,)).fetchall():
        created.add(row[0])
    s.notes.append("空间 doc_types 已按平台类型库校验；「其他」类型" +
                   ("已落地并纳入空间类型" if s.other_doc_type_landed else "尚未落地，未伪造该类型"))
    return created



# --------------------------------------------------------------------------- 2. 账号（系统管理员 20+）
def seed_accounts(s: Seeder, c) -> dict:
    from app import auth

    def user_row(uid, phone, name, role_code, portal, dept, created_day, status="active"):
        h, salt = auth.hash_password(DEMO_PWD)
        return {
            "id": uid, "username": phone, "name": name, "phone": phone,
            "email": f"{phone}@demo.local", "status": status, "portal": portal,
            "password_hash": h, "salt": salt, "must_change_pwd": 0,
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            "current_workspace_id": WS_DEFAULT, "department": dept,
            "created_by": "user-admin", "created_at": s.fmt(BASE_DAY + timedelta(days=created_day)),
            "account_no": "DM" + uid.replace("user-demo-", "").upper().replace("-", "")[:10],
            "is_initial": 0, "token_version": 0, "initial_password": "",
        }

    reviewers, admins = [], []
    for i, name in enumerate(REVIEWER_NAMES, 1):
        uid = f"user-demo-rev-{i:02d}"
        phone = f"1371000{i:04d}"
        s.ins(c, "user", user_row(uid, phone, name, "reviewer", "reviewer",
                                  DEPARTMENTS[i % len(DEPARTMENTS)], 3 + i))
        s.ins(c, "user_role", {"user_id": uid, "role_id": "role-reviewer"})
        reviewers.append({"id": uid, "name": name, "phone": phone})
    for i, name in enumerate(ADMIN_NAMES, 1):
        uid = f"user-demo-admin-{i:02d}"
        phone = f"1351000{i:04d}"
        s.ins(c, "user", user_row(uid, phone, name, "admin", "admin", "质量管理部", 4 + i))
        s.ins(c, "user_role", {"user_id": uid, "role_id": "role-admin"})
        admins.append({"id": uid, "name": name, "phone": phone})
    for i, name in enumerate(DISABLED_NAMES, 1):
        uid = f"user-demo-disabled-{i:02d}"
        phone = f"1371001{i:04d}"
        s.ins(c, "user", user_row(uid, phone, name, "reviewer", "reviewer",
                                  "质量审核部", 20, status="disabled"))
        s.ins(c, "user_role", {"user_id": uid, "role_id": "role-reviewer"})
    return {"reviewers": reviewers, "admins": admins}


# --------------------------------------------------------------------------- 3. 平台管理员 + 租户（平台运营）
def seed_platform(s: Seeder, c) -> dict:
    from app import auth
    # 平台管理员（平台端 4 个，含初始账号 user-platform）
    for i, name in enumerate(PLATFORM_ADMIN_NAMES, 1):
        if i == 1:
            continue  # 初始平台账号由 seed.py 建（赵磊 13600003333）
        uid = f"user-demo-platform-{i:02d}"
        phone = f"1361000{i:04d}"
        h, salt = auth.hash_password(DEMO_PWD)
        s.ins(c, "user", {
            "id": uid, "username": phone, "name": name, "phone": phone,
            "email": f"{phone}@demo.local", "status": "active", "portal": "platform",
            "password_hash": h, "salt": salt, "must_change_pwd": 0,
            "tenant_id": None, "workspace_id": None, "current_workspace_id": None,
            "department": "平台运营部", "created_by": "user-platform",
            "created_at": s.fmt(BASE_DAY + timedelta(days=6 + i)),
            "account_no": f"PO20261118{i:04d}", "is_initial": 0, "token_version": 0,
            "initial_password": "",
        })
        s.ins(c, "user_role", {"user_id": uid, "role_id": "role-platform_op"})

    tenants, tenant_admins = [], []
    extra_name_idx = 0
    for i, (tid, code, name, status, edition, expires, industry, with_admin) in enumerate(
            DEMO_TENANTS, 1):
        created = s.fmt(BASE_DAY + timedelta(days=i))
        s.ins(c, "tenant", {
            "id": tid, "code": code, "name": name, "status": status,
            "created_at": created, "note": "演示数据：平台运营端开通的示例租户",
            "logo_url": "", "platform_name": "", "industry": industry,
            "contact_name": TENANT_ADMIN_NAMES[(i - 1) % len(TENANT_ADMIN_NAMES)],
            "contact_phone": f"1391000{i:04d}",
            "contact_email": f"contact{i}@demo.local",
            "edition": edition, "expires_at": expires,
        })
        wsid = f"ws-tenant-demo-{i:02d}"
        s.ins(c, "workspace", {
            "id": wsid, "tenant_id": tid, "name": "通用空间", "status": "active",
            "created_by": "user-platform", "created_at": created,
            "settings_json": json.dumps({"setup_required": True}, ensure_ascii=False),
        })
        tenants.append({"id": tid, "name": name, "status": status, "edition": edition,
                        "expires": expires, "workspace_id": wsid, "has_admin": bool(with_admin)})
        if with_admin:
            h, salt = auth.hash_password(DEMO_PWD)
            uid = f"ta-demo-{i:02d}"
            phone = f"1392000{i:04d}"
            s.ins(c, "user", {
                "id": uid, "username": phone, "name": TENANT_ADMIN_NAMES[(i - 1) % len(TENANT_ADMIN_NAMES)],
                "phone": phone, "email": f"ta{i}@demo.local", "status": "active",
                "portal": "admin", "password_hash": h, "salt": salt,
                "must_change_pwd": 0, "tenant_id": tid, "workspace_id": wsid,
                "current_workspace_id": wsid, "department": "质量管理部门",
                "created_by": "user-platform", "created_at": created,
                "account_no": f"TA20261118{i:04d}", "is_initial": 1,
                "token_version": 0, "initial_password": "",
            })
            s.ins(c, "user_role", {"user_id": uid, "role_id": "role-super_admin"})
            tenant_admins.append({"id": uid, "tenant_id": tid, "name": s_name(TENANT_ADMIN_NAMES, i - 1),
                                  "phone": phone})
    # 额外租户管理员（同一租户第二个管理员，演示 12+ 租户管理员）
    for extra in range(3):
        tid = DEMO_TENANTS[extra][0]
        wsid = f"ws-tenant-demo-{extra + 1:02d}"
        uid = f"ta-demo-{11 + extra:02d}"
        phone = f"1392000{100 + extra:04d}"[:11]
        h, salt = auth.hash_password(DEMO_PWD)
        name = TENANT_ADMIN_NAMES[(8 + extra) % len(TENANT_ADMIN_NAMES)]
        s.ins(c, "user", {
            "id": uid, "username": phone, "name": name, "phone": phone,
            "email": f"ta-extra{extra}@demo.local", "status": "active",
            "portal": "admin", "password_hash": h, "salt": salt, "must_change_pwd": 0,
            "tenant_id": tid, "workspace_id": wsid, "current_workspace_id": wsid,
            "department": "质量管理部", "created_by": "user-platform",
            "created_at": s.fmt(BASE_DAY + timedelta(days=12 + extra)),
            "account_no": f"TA20261118{11 + extra:04d}", "is_initial": 0,
            "token_version": 0, "initial_password": "",
        })
        s.ins(c, "user_role", {"user_id": uid, "role_id": "role-super_admin"})
        tenant_admins.append({"id": uid, "tenant_id": tid, "name": name, "phone": phone})
    return {"tenants": tenants, "tenant_admins": tenant_admins}


def s_name(pool: list, idx: int) -> str:
    return pool[idx % len(pool)] if pool else "演示用户"


# --------------------------------------------------------------------------- 4. 密码重置记录
def seed_password_resets(s: Seeder, c, tenant_admins: list, reviewers: list) -> int:
    rows = []
    # 平台生成：租户管理员临时密码（待使用 / 已使用 / 已过期）
    for i in range(8):
        ta = tenant_admins[i % len(tenant_admins)]
        created = BASE_DAY + timedelta(days=10 + i)
        if i % 4 == 0:
            used_at, used_by, temp = s.fmt(created + timedelta(hours=2)), "self", ""
            expires = s.fmt(created + timedelta(days=7))
        elif i % 4 == 1:
            used_at, used_by, temp = "", "", "DemoReset@2026"
            expires = s.fmt(created + timedelta(days=7))
        else:
            used_at, used_by, temp = "", "", "DemoReset@2026"
            expires = s.fmt(created - timedelta(days=1))  # 已过期
        rows.append({
            "id": f"pwr-demo-{i + 1:02d}", "user_id": ta["id"], "actor": "user-platform",
            "source": "platform_tenant_admin", "temp_password": temp,
            "created_at": s.fmt(created), "expires_at": expires,
            "used_at": used_at, "used_by": used_by,
        })
    # 系统管理员端：本租户账号的临时密码记录
    for i in range(6):
        uid = reviewers[i % len(reviewers)]["id"]
        created = BASE_DAY + timedelta(days=14 + i)
        rows.append({
            "id": f"pwr-demo-{9 + i:02d}", "user_id": uid, "actor": "user-admin",
            "source": "admin", "temp_password": ("DemoReset@2026" if i % 3 else ""),
            "created_at": s.fmt(created),
            "expires_at": s.fmt(created + timedelta(days=7)),
            "used_at": (s.fmt(created + timedelta(hours=1)) if i % 3 == 0 else ""),
            "used_by": ("self" if i % 3 == 0 else ""),
        })
    n = 0
    for r in rows:
        n += s.ins(c, "password_reset", r)
    return n


# --------------------------------------------------------------------------- 5. 开放平台（系统管理员 5+ 应用/事件）
def seed_open_platform(s: Seeder, c) -> dict:
    from app.services import secret_box
    apps = []
    for i, (aid, app_key, name, events) in enumerate(OPEN_APPS, 1):
        s.ins(c, "open_app", {
            "id": aid, "app_key": app_key,
            "app_secret": secret_box.seal(f"demo-app-secret-{i:02d}-2026"),
            "name": name, "callback_url": f"https://demo.example.local/callback/{i:02d}",
            "events": events, "status": "active",
            "created_at": s.fmt(BASE_DAY + timedelta(days=3 + i)),
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
        apps.append({"id": aid, "app_key": app_key, "name": name})
    n_events = 0
    # 事件：投递成功/待投递/重试中/失败 混合
    statuses = ["delivered", "delivered", "delivered", "pending", "retry", "failed"]
    for i in range(30):
        app = apps[i % len(apps)]
        st = statuses[i % len(statuses)]
        created = BASE_DAY + timedelta(days=8 + (i % 9), hours=(i * 3) % 20)
        n_events += s.ins(c, "open_event", {
            "id": f"oev-demo-{i + 1:03d}", "task_id": f"demo-task-{i + 1:03d}",
            "type": ["audit.completed", "audit.failed", "ping"][i % 3],
            "payload": json.dumps({
                "demo": True, "event": "演示数据", "task_id": f"demo-task-{i + 1:03d}",
                "project": f"演示项目 {i + 1:02d}", "occurred_at": s.fmt(created),
            }, ensure_ascii=False),
            "delivered": 1 if st == "delivered" else 0,
            "retry_count": {"retry": 2, "failed": 3}.get(st, 0),
            "attempts": {"delivered": 1, "pending": 0, "retry": 2, "failed": 3}.get(st, 0),
            "status": st, "last_error": ("演示：回调超时（connect timeout）" if st in ("retry", "failed") else ""),
            "next_retry_at": (s.fmt(created + timedelta(minutes=30)) if st == "retry" else ""),
            "created_at": s.fmt(created), "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            "app_key": app["app_key"],
            "callback_url": f"https://demo.example.local/callback/{i % len(apps) + 1:02d}",
        })
    # 沙箱验签样例（有效/无效）
    n_sandbox = 0
    for i in range(8):
        app = apps[i % len(apps)]
        created = BASE_DAY + timedelta(days=9 + i, hours=i)
        n_sandbox += s.ins(c, "open_sandbox", {
            "id": f"osb-demo-{i + 1:02d}", "app_key": app["app_key"],
            "signature": "demo-signature-" + ("ok" if i % 3 else "bad") + f"-{i:02d}",
            "timestamp": str(int(created.timestamp())), "nonce": f"demo-nonce-{i:02d}",
            "body": json.dumps({"demo": True, "event": "ping", "seq": i + 1}, ensure_ascii=False),
            "valid": 1 if i % 3 else 0, "received_at": s.fmt(created),
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
    return {"apps": apps, "events": n_events, "sandbox": n_sandbox}


# --------------------------------------------------------------------------- 6. 规则与版本
# --------------------------------------------------------------------------- 6. 规则与版本（60+，五种状态）
_RCLASS_SEVERITY = {"R0": "critical", "R1": "critical", "R2": "warning",
                    "R3": "warning", "R4": "warning", "R5": "info"}
_VERSION_STATUS = {"published": "published", "approved": "approved",
                   "pending": "pending", "draft": "draft", "archived": "superseded"}


def seed_rules(s: Seeder, c) -> list[dict]:
    """规则库 60+：draft / pending / approved / published / archived 五种状态混合。

    - published：版本既 published，current_version_id 指向它（每规则唯一 published）；
    - approved / pending / draft：版本同状态；
    - archived：版本转 superseded 且不保留 current_version_id（与状态机口径一致）。
    """
    rules = []
    all_defs = list(DEMO_RULES) + list(DEMO_RULES_EXTRA)
    for i, (code, name, cat, rclass, status, criterion) in enumerate(all_defs, 1):
        rid = f"r-demo-{i:02d}"
        ridv = f"rv-demo-{i:02d}-01"
        created = s.fmt(BASE_DAY + timedelta(days=4 + (i % 20)))
        vstatus = _VERSION_STATUS.get(status, "draft")
        published = status == "published"
        archived = status == "archived"
        approved = status in ("published", "approved")
        s.ins(c, "rule", {
            "id": rid, "code": code, "name": name, "category": cat, "rclass": rclass,
            "status": status, "source": "演示数据 · 规则库",
            "scope_json": json.dumps({"demo": True, "tags": ["演示数据"]}, ensure_ascii=False),
            "created_at": created, "current_version_id": ("" if archived else ridv),
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            "owner": (REVIEWER_NAMES[i % len(REVIEWER_NAMES)] if i % 2 else "周敏"),
            "owner_id": ("user-reviewer" if i % 2 else "user-tenant"),
        })
        s.ins(c, "rule_version", {
            "id": ridv, "rule_id": rid, "version": "v1",
            "slots_json": json.dumps({
                "criterion": criterion, "condition": criterion,
                "severity": _RCLASS_SEVERITY.get(rclass, "warning"), "demo": True,
            }, ensure_ascii=False),
            "evidence_json": json.dumps({"docs": ["seed/demo_docs"], "demo": True}, ensure_ascii=False),
            "tests_json": "{}",
            "published_at": (created if published else ""),
            "status": vstatus,
            "approved_at": (created if approved else ""),
            "approved_by": ("user-tenant" if approved else ""),
            "superseded_at": (created if archived else ""),
        })
        # 已发布规则保留一个历史草稿版本，演示「规则版本」
        if published:
            s.ins(c, "rule_version", {
                "id": f"rv-demo-{i:02d}-02", "rule_id": rid, "version": "v2",
                "slots_json": json.dumps({"criterion": criterion + "（演示修订草稿）",
                                          "demo": True}, ensure_ascii=False),
                "evidence_json": "[]", "tests_json": "{}", "published_at": "",
                "status": "draft", "approved_at": "", "approved_by": "", "superseded_at": "",
            })
        rules.append({"id": rid, "code": code, "name": name, "status": status,
                      "category": cat, "rclass": rclass})
    s.rules = rules
    s.rule_by_code = {r["code"]: r for r in rules}
    return rules


# --------------------------------------------------------------------------- 6b. 本体建模（30+ 实体 / 60+ 别名 / 40+ 关系）
# type_key 保留引擎本体类型（ProcessStep/HalfProduct/Product/Metric/Unit/Party/Document/Field）；
# 名称/别名全部中文；别名 evidence 指向企业词典术语（term-demo-*），可追溯。
ONTO_ENTITY_DEFS = [
    ("ProcessStep", "卤制工序"), ("ProcessStep", "冷却工序"), ("ProcessStep", "包装工序"),
    ("ProcessStep", "原料验收工序"), ("ProcessStep", "杀菌工序"), ("ProcessStep", "和面工序"),
    ("ProcessStep", "蒸煮工序"), ("ProcessStep", "速冻工序"),
    ("HalfProduct", "酱卤牛肉半成品"), ("HalfProduct", "水饺馅料"), ("HalfProduct", "坚果混合料"),
    ("HalfProduct", "卤汤底料"), ("HalfProduct", "面团坯"), ("HalfProduct", "调味汁"),
    ("Product", "酱卤牛肉"), ("Product", "速冻水饺"), ("Product", "每日坚果"),
    ("Product", "五香卤蛋"), ("Product", "蜜汁鸡胸"),
    ("Metric", "卤制中心温度"), ("Metric", "保温时长"), ("Metric", "冷却时长"),
    ("Metric", "净含量偏差"), ("Metric", "菌落总数"), ("Metric", "亚硝酸盐含量"),
    ("Metric", "水分活度"), ("Metric", "过氧化值"),
    ("Unit", "摄氏度"), ("Unit", "小时"), ("Unit", "克"), ("Unit", "毫克每千克"),
    ("Unit", "百分比"), ("Unit", "千帕"),
    ("Party", "味源食品（苏州）有限公司"), ("Party", "苏州一厂（演示）"),
    ("Party", "华东食品（演示）"), ("Party", "星海科技（演示）"),
    ("Party", "城投供应链（演示）"),
    ("Document", "食品工艺书（演示）"), ("Document", "出厂检验报告（演示）"),
    ("Document", "生产记录（演示）"), ("Document", "供应商资质文件（演示）"),
    ("Field", "批次号"), ("Field", "检验员签字"), ("Field", "生产日期"), ("Field", "净含量标注"),
]

ONTO_ALIAS_DEFS = [
    ("ProcessStep", "卤制工序", ["卤制", "卤煮工序"]),
    ("ProcessStep", "冷却工序", ["冷却处理", "降温工序"]),
    ("ProcessStep", "包装工序", ["包装封口", "成品包装"]),
    ("ProcessStep", "原料验收工序", ["原料检验", "进厂验收"]),
    ("ProcessStep", "杀菌工序", ["灭菌工序", "杀菌处理"]),
    ("ProcessStep", "和面工序", ["和面", "面团调制"]),
    ("ProcessStep", "蒸煮工序", ["蒸煮", "蒸制工序"]),
    ("ProcessStep", "速冻工序", ["速冻处理", "冷冻工序"]),
    ("HalfProduct", "酱卤牛肉半成品", ["卤牛肉半成品", "酱卤半成品"]),
    ("HalfProduct", "水饺馅料", ["饺馅", "水饺馅"]),
    ("HalfProduct", "坚果混合料", ["混合坚果料", "坚果配料"]),
    ("HalfProduct", "卤汤底料", ["老卤汤", "卤水底料"]),
    ("HalfProduct", "面团坯", ["面坯", "水饺面团"]),
    ("HalfProduct", "调味汁", ["调味液", "酱汁"]),
    ("Product", "酱卤牛肉", ["五香酱牛肉", "卤牛肉"]),
    ("Product", "速冻水饺", ["冷冻水饺", "速冻饺子"]),
    ("Product", "每日坚果", ["混合坚果", "每日坚果包"]),
    ("Product", "五香卤蛋", ["卤鸡蛋", "香卤蛋"]),
    ("Product", "蜜汁鸡胸", ["蜜汁鸡胸肉", "鸡胸肉制品"]),
    ("Metric", "卤制中心温度", ["卤制温度", "中心温度实测值"]),
    ("Metric", "保温时长", ["保温时间", "恒温时间"]),
    ("Metric", "冷却时长", ["冷却时间", "降温时长"]),
    ("Metric", "净含量偏差", ["净含量误差", "计量偏差"]),
    ("Metric", "菌落总数", ["细菌总数", "菌落计数"]),
    ("Metric", "亚硝酸盐含量", ["亚硝酸盐残留", "亚硝酸盐检测值"]),
    ("Metric", "水分活度", ["水活度", "Aw值"]),
    ("Metric", "过氧化值", ["油脂过氧化值", "POV值"]),
    ("Unit", "摄氏度", ["℃单位", "摄氏温度"]),
    ("Unit", "小时", ["h单位", "小时制"]),
    ("Unit", "克", ["g单位", "克重"]),
    ("Unit", "毫克每千克", ["mg/kg单位", "毫克/千克"]),
    ("Unit", "百分比", ["%单位", "百分率"]),
    ("Unit", "千帕", ["kPa单位", "千帕斯卡"]),
    ("Party", "味源食品（苏州）有限公司", ["味源食品", "味源苏州"]),
    ("Party", "苏州一厂（演示）", ["苏州一厂", "一厂（演示）"]),
    ("Party", "华东食品（演示）", ["华东食品", "华东食品公司（演示）"]),
    ("Party", "星海科技（演示）", ["星海科技", "星海科技公司（演示）"]),
    ("Party", "城投供应链（演示）", ["城投供应链", "城投供应链公司（演示）"]),
    ("Document", "食品工艺书（演示）", ["工艺书（演示）", "食品工艺文件"]),
    ("Document", "出厂检验报告（演示）", ["检验报告（演示）", "出厂检验单"]),
    ("Document", "生产记录（演示）", ["批生产记录", "生产批记录"]),
    ("Document", "供应商资质文件（演示）", ["供应商资质", "资质文件（演示）"]),
    ("Field", "批次号", ["生产批号", "批号"]),
    ("Field", "检验员签字", ["检验签字", "检验人签字"]),
    ("Field", "生产日期", ["生产日", "制造日期"]),
    ("Field", "净含量标注", ["净含量标识", "净含量标注值"]),
]

ONTO_LINK_DEFS = [
    ("produced_by", "酱卤牛肉半成品", "卤制工序"),
    ("produced_by", "卤汤底料", "卤制工序"),
    ("produced_by", "水饺馅料", "原料验收工序"),
    ("produced_by", "面团坯", "和面工序"),
    ("produced_by", "坚果混合料", "原料验收工序"),
    ("produced_by", "调味汁", "蒸煮工序"),
    ("produced_by", "酱卤牛肉半成品", "冷却工序"),
    ("produced_by", "坚果混合料", "包装工序"),
    ("produced_by", "水饺馅料", "速冻工序"),
    ("measured_by", "卤制工序", "卤制中心温度"),
    ("measured_by", "卤制工序", "保温时长"),
    ("measured_by", "冷却工序", "冷却时长"),
    ("measured_by", "冷却工序", "卤制中心温度"),
    ("measured_by", "杀菌工序", "菌落总数"),
    ("measured_by", "蒸煮工序", "保温时长"),
    ("measured_by", "蒸煮工序", "水分活度"),
    ("measured_by", "包装工序", "净含量偏差"),
    ("measured_by", "速冻工序", "水分活度"),
    ("measured_by", "冷却工序", "过氧化值"),
    ("measured_by", "原料验收工序", "亚硝酸盐含量"),
    ("uses_unit", "卤制中心温度", "摄氏度"),
    ("uses_unit", "保温时长", "小时"),
    ("uses_unit", "冷却时长", "小时"),
    ("uses_unit", "净含量偏差", "克"),
    ("uses_unit", "亚硝酸盐含量", "毫克每千克"),
    ("uses_unit", "水分活度", "百分比"),
    ("uses_unit", "过氧化值", "毫克每千克"),
    ("uses_unit", "菌落总数", "毫克每千克"),
    ("document_field", "食品工艺书（演示）", "批次号"),
    ("document_field", "食品工艺书（演示）", "生产日期"),
    ("document_field", "出厂检验报告（演示）", "检验员签字"),
    ("document_field", "出厂检验报告（演示）", "批次号"),
    ("document_field", "生产记录（演示）", "生产日期"),
    ("document_field", "生产记录（演示）", "批次号"),
    ("document_party", "食品工艺书（演示）", "味源食品（苏州）有限公司"),
    ("document_party", "出厂检验报告（演示）", "味源食品（苏州）有限公司"),
    ("document_party", "生产记录（演示）", "苏州一厂（演示）"),
    ("document_party", "供应商资质文件（演示）", "华东食品（演示）"),
    ("document_party", "供应商资质文件（演示）", "星海科技（演示）"),
    ("document_party", "食品工艺书（演示）", "华东食品（演示）"),
]

# 企业词典术语（与本体实体同名，别名/类型/单位/关系可互相追溯）
BUSINESS_TERM_DEFS = [
    ("DEMO-TERM-01", "卤制中心温度", "卤制工序实测中心温度，是判断中心温度是否达标的关键指标。", ["卤制温度", "中心温度实测值"], "Metric", "摄氏度", [{"type": "measured_by", "to": "卤制工序"}], "演示数据 · 食品工艺"),
    ("DEMO-TERM-02", "保温时长", "卤制后保温保持时间，用于判断杀菌与口感是否达标。", ["保温时间", "恒温时间"], "Metric", "小时", [{"type": "measured_by", "to": "卤制工序"}], "演示数据 · 食品工艺"),
    ("DEMO-TERM-03", "冷却时长", "熟制品冷却至规定温度的时间，超过时限即判不满足。", ["冷却时间", "降温时长"], "Metric", "小时", [{"type": "measured_by", "to": "冷却工序"}], "演示数据 · 食品工艺"),
    ("DEMO-TERM-04", "净含量偏差", "包装净含量与标注值的偏差，用于判定计量是否合规。", ["净含量误差", "计量偏差"], "Metric", "克", [{"type": "measured_by", "to": "包装工序"}], "演示数据 · 食品工艺"),
    ("DEMO-TERM-05", "菌落总数", "食品卫生指标之一，用于判定微生物是否超限。", ["细菌总数", "菌落计数"], "Metric", "毫克每千克", [{"type": "measured_by", "to": "杀菌工序"}], "演示数据 · 食品工艺"),
    ("DEMO-TERM-06", "亚硝酸盐含量", "肉制品中亚硝酸盐残留量，超标即判不满足。", ["亚硝酸盐残留", "亚硝酸盐检测值"], "Metric", "毫克每千克", [{"type": "measured_by", "to": "原料验收工序"}], "演示数据 · 食品工艺"),
    ("DEMO-TERM-07", "酱卤牛肉", "演示用酱卤牛肉产品标准名，用于产品名称归一。", ["五香酱牛肉", "卤牛肉"], "Product", "", [{"type": "produced_by", "to": "卤制工序"}], "演示数据 · 产品词典"),
    ("DEMO-TERM-08", "速冻水饺", "演示用速冻水饺产品标准名。", ["冷冻水饺", "速冻饺子"], "Product", "", [{"type": "produced_by", "to": "速冻工序"}], "演示数据 · 产品词典"),
    ("DEMO-TERM-09", "酱卤牛肉半成品", "卤制后半成品，用于半成品工序闭环校验。", ["卤牛肉半成品", "酱卤半成品"], "HalfProduct", "", [{"type": "produced_by", "to": "卤制工序"}], "演示数据 · 半成品词典"),
    ("DEMO-TERM-10", "水饺馅料", "水饺生产用馅料半成品。", ["饺馅", "水饺馅"], "HalfProduct", "", [{"type": "produced_by", "to": "原料验收工序"}], "演示数据 · 半成品词典"),
    ("DEMO-TERM-11", "卤制工序", "酱卤类产品的核心加热工序。", ["卤制", "卤煮工序"], "ProcessStep", "", [{"type": "measured_by", "to": "卤制中心温度"}], "演示数据 · 工序词典"),
    ("DEMO-TERM-12", "冷却工序", "熟制品冷却工序，需在规定时限内完成。", ["冷却处理", "降温工序"], "ProcessStep", "", [{"type": "measured_by", "to": "冷却时长"}], "演示数据 · 工序词典"),
    ("DEMO-TERM-13", "味源食品（苏州）有限公司", "演示用生产主体，合同与工艺书中的甲方。", ["味源食品", "味源苏州"], "Party", "", [], "演示数据 · 主体词典"),
    ("DEMO-TERM-14", "华东食品（演示）", "演示用供应商主体。", ["华东食品", "华东食品公司（演示）"], "Party", "", [], "演示数据 · 主体词典"),
    ("DEMO-TERM-15", "食品工艺书（演示）", "食品工艺类审核文档，含工序参数与检验记录。", ["工艺书（演示）", "食品工艺文件"], "Document", "", [{"type": "document_field", "to": "批次号"}], "演示数据 · 文档词典"),
    ("DEMO-TERM-16", "出厂检验报告（演示）", "产品出厂检验报告，含检验员签字与检验结论。", ["检验报告（演示）", "出厂检验单"], "Document", "", [{"type": "document_field", "to": "检验员签字"}], "演示数据 · 文档词典"),
]


def _json_list(v) -> list:
    try:
        out = json.loads(v or "[]")
        return out if isinstance(out, list) else []
    except Exception:
        return []


def seed_ontology(s: Seeder, c) -> dict:
    """写本体实体/别名/关系/版本 + 企业词典 + 当前空间术语；全部可追溯、幂等。"""
    created = s.fmt(BASE_DAY + timedelta(days=6))
    # 1) 实体（固定 id；名称中文；type_key 保留）
    name_to_id: dict[tuple, str] = {}
    entity_type: dict[str, str] = {}
    for i, (type_key, name) in enumerate(ONTO_ENTITY_DEFS, 1):
        eid = f"onto-demo-{i:03d}"
        props = {"demo": True, "source": "演示数据", "description": f"演示用{type_key}实体"}
        if type_key == "Unit":
            props["unit"] = name
        s.ins(c, "onto_entity", {
            "id": eid, "type_key": type_key, "name": name,
            "props_json": json.dumps(props, ensure_ascii=False), "created_at": created,
        })
        name_to_id[(type_key, name)] = eid
        entity_type[name] = type_key
        s.ontology_entity_ids.append(eid)
    # 2) 别名（按同类型标准名/既有别名去重；evidence 指向企业词典术语）
    existing_names = {r["name"] for r in c.execute("SELECT name FROM onto_entity").fetchall() if r["name"]}
    existing_aliases = {r["alias"] for r in c.execute("SELECT alias FROM onto_alias").fetchall() if r["alias"]}
    used: set[tuple] = set()
    for type_key, name, aliases in ONTO_ALIAS_DEFS:
        eid = name_to_id.get((type_key, name))
        if not eid:
            continue
        for k, alias in enumerate(aliases, 1):
            alias = str(alias or "").strip()
            key = (type_key, alias)
            if not alias or key in used:
                continue
            if alias in existing_names or alias in existing_aliases:
                continue
            aid = f"onto-demo-al-{type_key[:3].lower()}-{len(used) + 1:03d}"
            term_hint = next((t[0] for t in BUSINESS_TERM_DEFS if t[1] == name), "")
            s.ins(c, "onto_alias", {
                "id": aid, "type_key": type_key, "alias": alias, "entity_id": eid,
                "evidence": f"演示数据：企业词典术语 {term_hint or '-'}；标准名 {name}",
                "source": "manual", "status": "approved", "created_at": created,
            })
            used.add(key)
            s.ontology_alias_ids.append(aid)
    # 3) 关系（produced_by/measured_by/uses_unit/document_field/document_party）
    for i, (key, src_name, tgt_name) in enumerate(ONTO_LINK_DEFS, 1):
        src_id = next((v for (tk, n), v in name_to_id.items() if n == src_name), "")
        tgt_id = next((v for (tk, n), v in name_to_id.items() if n == tgt_name), "")
        if not src_id or not tgt_id:
            continue
        lid = f"onto-demo-lk-{i:03d}"
        s.ins(c, "onto_link", {"id": lid, "key": key, "source_id": src_id, "target_id": tgt_id})
        s.ontology_link_ids.append(lid)
    # 4) 本体版本快照（发布态，演示「本体版本」）
    s.ins(c, "onto_version", {
        "id": "ov-demo-01", "version": "v-demo-20261118", "status": "published",
        "snapshot_json": json.dumps({
            "demo": True, "entities": len(ONTO_ENTITY_DEFS),
            "aliases": len(ONTO_ALIAS_DEFS), "links": len(ONTO_LINK_DEFS),
            "note": "演示数据：本体快照，不代表真实客户本体",
        }, ensure_ascii=False),
        "health_json": json.dumps({"score": 100, "findings": [], "demo": True}, ensure_ascii=False),
        "created_at": created, "published_at": created,
    })
    # 5) 企业词典（business_term，固定 id；与本体实体同名可追溯）
    for i, (term_key, name, definition, synonyms, etype, unit, relations, scope) in enumerate(
            BUSINESS_TERM_DEFS, 1):
        tid = f"term-demo-{i:02d}"
        s.ins(c, "business_term", {
            "id": tid, "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            "term_key": term_key, "name": name, "definition": definition,
            "synonyms_json": json.dumps(synonyms, ensure_ascii=False),
            "not_equal_json": "[]", "source": "演示数据 · 企业词典", "scope": scope,
            "entity_type": etype, "unit": unit,
            "relations_json": json.dumps(relations, ensure_ascii=False),
            "version": 1, "status": "confirmed", "confirmed_by": "user-tenant",
            "confirmed_at": created, "created_at": created,
        })
        s.term_ids.append(tid)
    # 6) 当前空间术语（workspace.settings_json.ontology_terms，供「本体建模」页展示与追溯）
    row = c.execute("SELECT settings_json FROM workspace WHERE id=?", (WS_DEFAULT,)).fetchone()
    try:
        settings = json.loads((row[0] if row else "") or "{}")
    except Exception:
        settings = {}
    terms = settings.get("ontology_terms") if isinstance(settings.get("ontology_terms"), list) else []
    have = {str(x.get("canonical") or "") for x in terms}
    for i, (term_key, name, definition, synonyms, etype, unit, relations, scope) in enumerate(
            BUSINESS_TERM_DEFS, 1):
        if name in have:
            continue
        terms.append({
            "id": f"ot-demo-{i:02d}", "canonical": name,
            "aliases": synonyms, "type": etype, "unit": unit,
            "relations": relations, "term_id": f"term-demo-{i:02d}",
            "source": "manual", "status": "active", "count": 0,
            "evidence": f"演示数据：企业词典 {term_key}｜{definition}",
            "created_at": created, "updated_at": created,
        })
        have.add(name)
    settings["ontology_terms"] = terms
    settings.setdefault("ontology_auto_last_count", 0)
    c.execute("UPDATE workspace SET settings_json=? WHERE id=?", (
        json.dumps(settings, ensure_ascii=False), WS_DEFAULT))
    # 返回库内实际演示行数（幂等复跑时与首跑一致）
    alias_n = int(c.execute("SELECT COUNT(*) FROM onto_alias WHERE id LIKE 'onto-demo-al-%'").fetchone()[0])
    link_n = int(c.execute("SELECT COUNT(*) FROM onto_link WHERE id LIKE 'onto-demo-lk-%'").fetchone()[0])
    return {"entities": len(ONTO_ENTITY_DEFS), "aliases": alias_n,
            "links": link_n, "terms": len(BUSINESS_TERM_DEFS),
            "workspace_terms": len(terms)}


# --------------------------------------------------------------------------- 6c. 决策表（10+）
def seed_decision_tables(s: Seeder, c) -> int:
    made = 0
    for i, (code, name, hit_policy, status, version, scope_types, rules) in enumerate(
            DECISION_TABLE_DEFS, 1):
        tid = f"dt-demo-{i:02d}"
        created = s.fmt(BASE_DAY + timedelta(days=7 + (i % 10)))
        s.ins(c, "decision_table", {
            "id": tid, "code": code, "name": name, "hit_policy": hit_policy,
            "rules_json": json.dumps(rules, ensure_ascii=False), "status": status,
            "version": version, "source": "演示数据 · 决策表",
            "created_at": created,
            "scope_types": json.dumps(scope_types, ensure_ascii=False),
            "canary_percent": (100 if status == "published" else 0 if status == "archived" else 50),
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            "owner": "周敏", "owner_id": "user-tenant",
        })
        s.decision_table_codes.append(code)
        if status == "published":
            s.ins(c, "decision_table_version", {
                "id": f"dtv-demo-{i:02d}", "table_id": tid, "version": version,
                "rules_json": json.dumps(rules, ensure_ascii=False),
                "published_at": created,
            })
        made += 1
    return made


# --------------------------------------------------------------------------- 6d. 规则进化（30+ 候选 + 30+ 台账）
EVOLUTION_ROOT_CAUSES = ["判据过严", "作用域过大", "证据不足", "原文误读", "规则缺失（漏报）"]
EVOLUTION_SUGGESTIONS = {
    "判据过严": "放宽阈值或增加例外条件，先影子验证再发布。",
    "作用域过大": "限定规则作用域（文档类型/章节/对象），避免跨文档误命中。",
    "证据不足": "补充必须证据字段与证据位置要求，不足时转人工。",
    "原文误读": "增加原文定位与单位归一校验，避免 OCR/跨 Sheet 串位。",
    "规则缺失（漏报）": "沉淀为新规则候选，人工确认后进入草稿审批。",
}


def seed_evolution(s: Seeder, c) -> dict:
    """进化台账（evolution_task）+ RSI 候选（rsi_candidate），均只落痕、不自动发布。"""
    fps = [d for d in s.decisions if d.get("decision") == "false_positive"]
    statuses = (["open"] * 10 + ["analyzed"] * 8 + ["settled"] * 10 + ["ignored"] * 6)
    n_task = 0
    for i, d in enumerate(fps[:len(statuses)]):
        status = statuses[i]
        root = EVOLUTION_ROOT_CAUSES[i % len(EVOLUTION_ROOT_CAUSES)]
        action = ("revise" if i % 2 == 0 else "new_rule") if status == "settled" else ""
        rule = s.rule_by_code.get(d.get("rule_code") or "") or {}
        created = s.fmt(datetime.strptime(d["created_at"], "%Y-%m-%d %H:%M:%S")
                        + timedelta(hours=2 + i % 12))
        handled = ""
        if status in ("settled", "ignored"):
            handled = s.fmt(datetime.strptime(created, "%Y-%m-%d %H:%M:%S") + timedelta(days=1))
        tid = f"evo-demo-{i + 1:02d}"
        s.ins(c, "evolution_task", {
            "id": tid, "finding_id": d["finding_id"], "rule_code": d.get("rule_code") or "",
            "title": d.get("title") or "", "status": status, "root_cause": root,
            "suggestion": "演示数据：" + EVOLUTION_SUGGESTIONS[root],
            "action": action, "rule_id": rule.get("id") or "",
            "note": f"演示数据：候选来源错误书 {d['id']}（反馈 fb-"
                    + d["finding_id"].replace("fnd-", "") + "）；仅落痕，人工确认后才可走审批。",
            "created_at": created, "handled_at": handled,
            "handled_by": ("user-tenant" if handled else ""),
        })
        s.evolution_task_ids.append(tid)
        n_task += 1
    # RSI 候选：30 条，pending / accepted / blocked / rolled_back 混合
    decisions = (["pending"] * 12 + ["accepted"] * 8 + ["blocked"] * 6 + ["rolled_back"] * 4)
    actions = ["revise", "threshold", "scope", "new_rule"]
    n_cand = 0
    for i in range(len(decisions)):
        if i >= len(s.decisions):
            break
        d = s.decisions[i]
        rule = s.rule_by_code.get(d.get("rule_code") or "") or {}
        feedback_id = "fb-" + d["finding_id"].replace("fnd-", "")
        decision = decisions[i]
        created = s.fmt(datetime.strptime(d["created_at"], "%Y-%m-%d %H:%M:%S")
                        + timedelta(hours=3 + i % 10))
        decided_at = "" if decision == "pending" else s.fmt(
            datetime.strptime(created, "%Y-%m-%d %H:%M:%S") + timedelta(hours=6))
        cid = f"rc-demo-{i + 1:02d}"
        s.ins(c, "rsi_candidate", {
            "id": cid, "feedback_id": feedback_id, "rule_code": d.get("rule_code") or "",
            "action": actions[i % len(actions)],
            "before_json": json.dumps({"params": {"value": 85, "unit": "摄氏度"},
                                       "behavior": {"fallback": "ask"}, "demo": True},
                                      ensure_ascii=False),
            "after_json": json.dumps({"params": {"value": 88, "unit": "摄氏度"},
                                      "behavior": {"fallback": "abstain"}, "demo": True},
                                     ensure_ascii=False),
            "decision": decision,
            "note": f"演示数据：候选来源错误书 {d['id']} / 反馈 {feedback_id}；"
                    f"根因 {EVOLUTION_ROOT_CAUSES[i % len(EVOLUTION_ROOT_CAUSES)]}；"
                    "候选仅落痕，发布需人工审批，不会自动生效。",
            "created_at": created, "decided_at": decided_at,
            "decided_by": ("" if decision == "pending" else "user-tenant"),
        })
        s.rsi_candidate_ids.append(cid)
        n_cand += 1
    return {"tasks": n_task, "candidates": n_cand,
            "root_causes": sorted({t for t in EVOLUTION_ROOT_CAUSES})}



# --------------------------------------------------------------------------- 7. 项目 / 文档 / 发现 / 复核
def build_projects(s: Seeder, c, reviewers: list[dict], rules: list[dict],
                   spaces: set[str]) -> dict:
    from app import auth  # noqa: F401  (保证 app 包已初始化)

    # 只保留存在的演示文件
    files = []
    for rel, doc_type, audit_type, category in FILE_POOL:
        if os.path.exists(os.path.join(ROOT, rel)):
            files.append({"rel": rel, "doc_type": doc_type, "audit_type": audit_type,
                          "category": category})
    if not files:
        raise RuntimeError("seed/ 下找不到任何演示文件，无法生成项目")
    all_reviewers = [{"id": "user-reviewer", "name": "王芳"}] + reviewers
    builtin_food_codes = ["RW20260525001", "RW20260525005", "RW20260525007", "B-2", "C-3"]
    custom_by_cat = {}
    for r in rules:
        cat = "food" if "-FD-" in r["code"] else ("contract" if "-CT-" in r["code"] else
                                                 "bid" if "-BD-" in r["code"] else
                                                 "application" if "-AP-" in r["code"] else "general")
        custom_by_cat.setdefault(cat, []).append(r["code"])

    cases = []
    for n in range(1, 56):
        if n <= 20:
            status, stage = "completed", "已完成"
            finding_n = 18
            if n <= 10:
                owner = all_reviewers[0]
            else:
                owner = all_reviewers[1 + (n - 11) % 5]
            wid = WS_DEFAULT
        elif n <= 42:
            status, stage = "reviewing", "审核中"
            finding_n = 16
            if n <= 32:
                owner = all_reviewers[0]
            else:
                owner = all_reviewers[6 + (n - 33) % 5]
            wid = WS_DEFAULT if n <= 32 else f"ws-demo-{(n - 33) // 2 + 1:02d}"
            if wid not in spaces:
                wid = WS_DEFAULT
        else:
            status, stage = "draft", "草稿"
            finding_n = 0
            owner = all_reviewers[0] if n <= 49 else all_reviewers[11 + (n - 50) % 6]
            wid = WS_DEFAULT if n <= 48 else f"ws-demo-{(n - 49) % 5 + 6:02d}"
            if wid not in spaces:
                wid = WS_DEFAULT
        f0 = files[(n - 1) % len(files)]
        f1 = files[(n * 2) % len(files)]
        if f0["rel"] == f1["rel"]:
            f1 = files[(n * 3 + 1) % len(files)]
        docs = [f0]
        if status != "draft" or n % 3 == 0:
            docs.append(f1)
        cid = f"case-demo-{n:03d}"
        day = 3 + (n * 3) % 44
        created_dt = BASE_DAY + timedelta(days=day, hours=(n * 5) % 12)
        created = s.fmt(created_dt)
        last_audit = s.fmt(created_dt + timedelta(hours=2 + n % 5)) if finding_n else ""
        run_id = f"run-demo-{n:03d}"
        subject = os.path.splitext(os.path.basename(f0["rel"]))[0]
        name = f"演示项目｜{subject}（{stage} {n:02d}）"
        cat = f0["category"]
        progress = {"completed": 100, "reviewing": 58 + (n * 7) % 32, "draft": 0}[status]
        s.ins(c, "audit_case", {
            "id": cid, "name": name, "status": status, "progress": progress,
            "created_at": created, "created_by": owner["id"],
            "audit_type": f0["audit_type"], "document_type": CATEGORY_DOC_TYPE.get(cat, "通用文件"),
            "audit_category": "演示数据", "focus": "演示数据 · 非真实客户材料",
            "pack_version": "demo-bulk-2026.11", "model_version": "demo",
            "last_audit_at": last_audit, "last_run_id": run_id,
            "tenant_id": TENANT, "workspace_id": wid, "compat_mode": "",
        })
        doc_ids = []
        for di, f in enumerate(docs, 1):
            did = f"doc-demo-{n:03d}-{di}"
            doc_path = os.path.join(ROOT, f["rel"])
            s.ins(c, "document", {
                "id": did, "filename": os.path.basename(f["rel"]),
                "doc_type": f["doc_type"], "hash": s.sha_file(f["rel"]),
                "status": "parsed", "source_system": "seed_demo_bulk",
                "created_at": created, "path": doc_path,
                "parse_status": "ok",
                "parse_summary": f"演示数据：已解析 {os.path.basename(f['rel'])}（{f['doc_type']}）",
                "tenant_id": TENANT, "workspace_id": wid,
            })
            s.ins(c, "case_document", {"case_id": cid, "document_id": did})
            doc_ids.append({"id": did, "rel": f["rel"], "filename": os.path.basename(f["rel"]),
                            "is_xlsx": f["rel"].endswith(".xlsx"), "doc_type": f["doc_type"]})
        s.case_meta[cid] = {"status": status, "owner": owner, "workspace": wid,
                            "created": created, "findings": finding_n, "name": name}
        # 审核批次
        if finding_n:
            _sev = _severity_pattern(finding_n)
            s.ins(c, "audit_run", {
                "id": run_id, "case_id": cid, "created_at": last_audit or created,
                "created_by": owner["id"], "audit_type": f0["audit_type"],
                "focus": "演示数据", "total": finding_n,
                "critical": _sev.count("critical"), "warning": _sev.count("warning"),
                "suspected": _sev.count("info"), "trace_json": "",
            })
        # 发现 + 位置 + 证据
        sev_list = _severity_pattern(finding_n) if finding_n else []
        title_pool = TITLE_POOL.get(cat) or TITLE_POOL["general"]
        rule_pool = (custom_by_cat.get(cat) or [r["code"] for r in rules]) + (
            builtin_food_codes if cat == "food" else [])
        for j in range(1, finding_n + 1):
            sev = sev_list[j - 1]
            dec = _decision_for(status, j)
            fid = f"fnd-demo-{n:03d}-{j:02d}"
            title = title_pool[(n + j) % len(title_pool)]
            doc = doc_ids[j % len(doc_ids)]
            rule_code = rule_pool[(n + j) % len(rule_pool)]
            if doc["is_xlsx"]:
                sheet = ["设备清单", "报价汇总", "评分表", "检验记录"][j % 4]
                locator = f"{sheet}!A{2 + (j * 3) % 28}"
                row_no, sheet_val = 2 + (j * 3) % 28, sheet
            else:
                locator = f"第 {1 + (j * 5) % 12} 页 第 {j % 6 + 1} 段"
                row_no, sheet_val = None, ""
            quote = (f"演示数据原文摘录：{title}；在《{doc['filename']}》{locator} 处记录了"
                     f"相关参数与签批信息，需与同类记录交叉核对。")
            s.ins(c, "finding", {
                "id": fid, "case_id": cid, "rule_id": rule_code, "rule_version": "v1",
                "severity": sev, "certainty": ("deterministic" if j % 3 else "semantic"),
                "confidence": 0.92 if sev == "critical" else 0.85,
                "state": "不满足", "status": dec["status"], "title": title,
                "summary": f"演示数据：{title}。涉及《{doc['filename']}》{locator}；"
                           f"该结论仅用于演示，不代表真实审核结果。",
                "suggestion": SUGGEST_POOL[(n + j) % len(SUGGEST_POOL)],
                "grade": {"critical": "R1", "warning": "R2"}.get(sev, "R3"),
                "engine": "demo_bulk", "run_id": run_id, "point_id": "",
                "source_code": "DEMO", "tenant_id": TENANT, "workspace_id": wid,
                "point_library_version": "", "object_id": "", "occurrence_count": 1,
            })
            aid = f"anc-demo-{n:03d}-{j:02d}"
            s.ins(c, "anchor", {
                "id": aid, "document_id": doc["id"], "sheet": sheet_val,
                "row": row_no, "col": "", "locator": locator, "quote": quote,
                "hash": hashlib.sha256(quote.encode("utf-8")).hexdigest(),
            })
            s.ins(c, "evidence", {
                "id": f"ev-demo-{n:03d}-{j:02d}", "finding_id": fid,
                "document_id": doc["id"], "anchor_id": aid,
                "excerpt": quote, "label": "演示数据证据",
            })
            if dec["decision"]:
                did = f"dec-demo-{n:03d}-{j:02d}"
                s.ins(c, "decision", {
                    "id": did, "finding_id": fid, "decision": dec["decision"],
                    "reason": dec["reason"], "note": "演示数据：示例人工复核意见",
                    "user_id": owner["id"],
                    "created_at": s.fmt(created_dt + timedelta(hours=6 + j)),
                })
                s.decisions.append({
                    "id": did, "finding_id": fid, "case_id": cid,
                    "decision": dec["decision"], "actor": owner["id"],
                    "created_at": s.fmt(created_dt + timedelta(hours=6 + j)),
                    "rule_code": rule_code, "title": title, "severity": sev,
                })
            s.findings_index.append({
                "id": fid, "case_id": cid, "status": dec["status"],
                "severity": sev, "title": title, "rule_code": rule_code,
                "owner": owner["id"], "workspace": wid,
            })
        cases.append(cid)
    return {"cases": cases}


def _severity_pattern(n: int) -> list[str]:
    out = []
    for j in range(1, n + 1):
        m = j % 10
        out.append("critical" if m in (1, 2) else ("info" if m in (0, 8, 9) else "warning"))
    return out


def _decision_for(case_status: str, j: int) -> dict:
    """模拟已复核 / 待复核混合：completed 已复核约 70%，reviewing 约 40%。"""
    m = j % 10
    if case_status == "completed":
        decided = m in (1, 2, 3, 4, 5, 6, 7)
        decision = ("confirmed" if m in (1, 2, 3, 4) else
                    "false_positive" if m in (5, 6) else "need_evidence")
    else:
        decided = m in (1, 2, 3, 4)
        decision = ("confirmed" if m in (1, 2) else
                    "false_positive" if m == 3 else "need_evidence")
    if not decided:
        return {"status": "pending", "decision": "", "reason": ""}
    reason = {
        "confirmed": "演示数据：人工复核确认该问题成立，纳入整改。",
        "false_positive": "演示数据：人工复核判定为误报（口径/阈值偏严），进入错误书复盘。",
        "need_evidence": "演示数据：现有证据不足，要求补充原始记录后再复核。",
    }[decision]
    return {"status": decision, "decision": decision, "reason": reason}


# --------------------------------------------------------------------------- 8. 规则反馈 / 错误书
def seed_feedback(s: Seeder, c) -> int:
    n = 0
    kind_of = {"confirmed": "confirm", "false_positive": "false_positive",
               "need_evidence": "need_evidence"}
    for idx, d in enumerate(s.decisions):
        if idx >= 84:
            break
        kind = kind_of.get(d["decision"], "confirm")
        settled = idx % 5 == 0
        handled_at = s.fmt(datetime.strptime(d["created_at"], "%Y-%m-%d %H:%M:%S")
                           + timedelta(days=1)) if settled else ""
        n += s.ins(c, "feedback", {
            "id": "fb-" + d["finding_id"].replace("fnd-", ""),
            "case_id": d["case_id"], "finding_id": d["finding_id"], "kind": kind,
            "rule_code": d["rule_code"], "title": d["title"],
            "payload": json.dumps({
                "reason": d["decision"] + " 的示例复核理由（演示数据）",
                "suggestion": "演示数据：建议复核阈值/作用域，必要时进入规则修订。",
                "root_cause": ("判据过严" if kind == "false_positive" else "证据不足"),
                "source": "demo_bulk",
            }, ensure_ascii=False),
            "actor": d["actor"], "created_at": d["created_at"],
            "rsi_status": ("settled" if settled else ("ignored" if idx % 11 == 0 else "pending")),
            "rsi_action": ("revise" if settled else ""),
            "rsi_rule_id": ("r-demo-03" if settled else ""),
            "handled_at": handled_at, "handled_by": ("user-tenant" if settled else ""),
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
    # 人工新增问题（漏报信号）12 条
    manual_cases = [cid for cid, m in s.case_meta.items()
                    if m["status"] in ("completed", "reviewing")][:12]
    for i, cid in enumerate(manual_cases, 1):
        meta = s.case_meta[cid]
        n += s.ins(c, "feedback", {
            "id": f"fb-demo-manual-{i:02d}", "case_id": cid, "finding_id": "",
            "kind": "manual", "rule_code": DEMO_RULES[(i - 1) % len(DEMO_RULES)][0],
            "title": f"人工新增问题（演示数据 {i:02d}）：补充核对项",
            "payload": json.dumps({
                "reason": "演示数据：审核员人工补充发现，规则未覆盖。",
                "suggestion": "演示数据：建议沉淀为规则候选，进入规则挖掘。",
                "source": "demo_bulk",
            }, ensure_ascii=False),
            "actor": meta["owner"]["id"],
            "created_at": s.fmt(datetime.strptime(meta["created"], "%Y-%m-%d %H:%M:%S")
                                + timedelta(hours=9 + i)),
            "rsi_status": "pending", "rsi_action": "", "rsi_rule_id": "",
            "handled_at": "", "handled_by": "", "tenant_id": TENANT,
            "workspace_id": meta["workspace"],
        })
    return n


# --------------------------------------------------------------------------- 9. 冲突
# --------------------------------------------------------------------------- 9. 冲突（20+，覆盖 5 类，A/B 规则真实存在）
def seed_conflicts(s: Seeder, c) -> int:
    n = 0
    defs = list(CONFLICT_SEEDS) + list(CONFLICT_EXTRA)
    for i, (a, b, typ, detail, sev, sug, status) in enumerate(defs, 1):
        cid = f"cf-demo-{i:02d}"
        created = s.fmt(BASE_DAY + timedelta(days=10 + (i % 10)))
        resolved = status != "open"
        s.ins(c, "conflict", {
            "id": cid, "rule_a": a, "rule_b": b, "type": typ,
            "detail": "演示数据：" + detail, "status": status, "created_at": created,
            "severity": sev, "suggestion": sug,
            "slots_a": json.dumps({"demo": True, "scope": "演示数据", "rule": a}, ensure_ascii=False),
            "slots_b": json.dumps({"demo": True, "scope": "演示数据", "rule": b}, ensure_ascii=False),
            "resolved_at": (s.fmt(datetime.strptime(created, "%Y-%m-%d %H:%M:%S")
                                  + timedelta(hours=5)) if resolved else ""),
            "resolved_by": ("user-tenant" if resolved else ""),
            "note": ("演示数据：示例裁决记录" if resolved else ""),
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            "resolution": ("both_valid" if status == "resolved" else
                           "ignored" if status == "ignored" else ""),
            "resolution_detail": "", "closed_rule_ids": "", "recreate_rule_id": "",
            "recreate_task": "", "impact_json": "",
        })
        s.conflict_ids.append(cid)
        n += 1
    return n



# --------------------------------------------------------------------------- 10. 站内消息
def seed_notifications(s: Seeder, c) -> int:
    n = 0
    templates = {
        "user-reviewer": [
            ("project.pending_review", "待复核提醒", "项目「演示项目｜采购合同（审核中 21）」还有待复核问题，请在工作台处理。"),
            ("project.pending_review", "待复核提醒", "项目「演示项目｜食品工艺（审核中 22）」新增 6 条待复核发现。"),
            ("rule.feedback", "规则反馈汇总", "演示规则 DEMO-FD-005 收到反向反馈，建议查看错误书。"),
            ("audit.completed", "审核完成", "演示项目「已完成 05」审核完成，共 18 条发现，请复核。"),
            ("system.notice", "系统提示", "演示数据：点位库已更新到最新版本，历史确认可重新复核。"),
        ],
        "user-tenant": [
            ("project.pending_review", "本租户待复核汇总", "本租户演示项目仍有 60+ 条待复核发现，涉及 22 个项目。"),
            ("rule.published", "规则发布", "演示规则 DEMO-CT-002 已发布新版 v1，进入下一次审核。"),
            ("rule.feedback", "规则进化提醒", "错误书新增 5 条误报样本，可生成规则修订草稿。"),
            ("audit.completed", "审核完成", "演示项目批量审核完成，可在审核记录查看全部复核动作。"),
            ("system.notice", "平台提示", "演示数据：开放平台回调有 3 个事件待重试，请关注投递状态。"),
        ],
        "user-admin": [
            ("system.notice", "账号与空间", "演示账号已补齐：20+ 账号、10+ 工作空间。"),
            ("system.notice", "开放平台", "演示开放应用新增 3 个，回调事件有待投递与失败样例。"),
            ("audit.failed", "回调失败提醒", "演示应用「质量中台」回调失败，已进入重试队列。"),
            ("system.notice", "消息配置", "演示数据：站内消息渠道正常，其他渠道未配置。"),
        ],
    }
    start = BASE_DAY + timedelta(days=12)
    for actor, items in templates.items():
        for i in range(30 if actor == "user-reviewer" else (22 if actor == "user-tenant" else 18)):
            typ, title, detail = items[i % len(items)]
            created = s.fmt(start + timedelta(days=i % 7, hours=(i * 2) % 20))
            n += s.ins(c, "notification", {
                "id": f"ntf-demo-{actor.replace('user-', '')}-{i + 1:03d}",
                "actor": actor, "type": typ,
                "title": "演示数据：" + title,
                "detail": "演示数据：" + detail,
                "read": 0 if i % 3 else 1, "created_at": created,
                "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
            })
    # 新对象相关消息（本体 / 规则冲突 / 规则进化 / 决策表）
    extra_msgs = [
        ("user-tenant", "system.notice", "本体已更新", "演示数据：本体新增 46 个中文实体、60+ 别名与 40+ 关系，可在「本体建模」查看。"),
        ("user-tenant", "system.notice", "规则冲突待处理", "演示数据：检测到 20+ 规则冲突，覆盖重复/数值/单位/作用域/优先级五类。"),
        ("user-tenant", "rule.feedback", "规则进化候选", "演示数据：错误书已生成 30 条进化候选与 34 条进化台账，确认前不会自动发布。"),
        ("user-tenant", "system.notice", "决策表已发布", "演示数据：6 张决策表已发布、4 张草稿、2 张归档，可在规则库「决策表」查看。"),
        ("user-tenant", "rule.published", "规则状态覆盖", "演示数据：规则库覆盖草稿/待审/已批准/已发布/已下线五种状态。"),
        ("user-reviewer", "system.notice", "本体与词典", "演示数据：企业词典新增 16 条术语并投影到当前空间本体，审核取数可按别名归一。"),
        ("user-reviewer", "system.notice", "冲突提醒", "演示数据：与本人规则相关的冲突已生成，可在「冲突提醒」查看。"),
        ("user-reviewer", "project.pending_review", "待复核提醒", "演示数据：本人项目新增待复核问题，可直接在问题列表复核。"),
        ("user-reviewer", "rule.feedback", "规则进化", "演示数据：本人反馈已进入进化台账，管理员确认后才生成规则草稿。"),
        ("user-admin", "system.notice", "本体/决策表资产", "演示数据：本体版本与决策表版本已写入，可在运维看板核对。"),
        ("user-admin", "system.notice", "审计覆盖", "演示数据：本体/规则/决策表/进化/冲突写入均已记录审计日志。"),
        ("user-admin", "system.notice", "点位确认", "演示数据：多个空间完成点位确认，可在「空间配置/点位确认」查看。"),
    ]
    start2 = BASE_DAY + timedelta(days=13)
    counters = {"user-reviewer": 31, "user-tenant": 23, "user-admin": 19}
    for i, (actor, typ, title, detail) in enumerate(extra_msgs):
        idx = counters[actor]
        counters[actor] += 1
        created = s.fmt(start2 + timedelta(days=i % 5, hours=i % 12))
        key = actor.replace("user-", "") + f"-{idx:03d}"
        n += s.ins(c, "notification", {
            "id": f"ntf-demo-{key}", "actor": actor, "type": typ,
            "title": "演示数据：" + title, "detail": detail,
            "read": 0 if i % 2 else 1, "created_at": created,
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
    return n


# --------------------------------------------------------------------------- 11. 审计日志
def seed_audit_logs(s: Seeder, c) -> int:
    n = 0
    start = BASE_DAY + timedelta(days=8)
    # 业务审计：复核动作
    top = s.decisions[:60]
    for i, d in enumerate(top):
        created = s.fmt(start + timedelta(days=i % 10, hours=(i // 4) % 20, minutes=(i * 7) % 60))
        n += s.ins(c, "audit_log", {
            "id": f"log-demo-{i + 1:03d}", "actor": d["actor"], "action": "finding.decided",
            "object": d["finding_id"],
            "after_json": json.dumps({"decision": d["decision"], "demo": True,
                                      "case_id": d["case_id"]}, ensure_ascii=False),
            "before_json": "", "request_id": f"demo-req-{i + 1:03d}", "ip": "127.0.0.1",
            "created_at": created, "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
    # 业务审计：项目/规则/登录/失败事件
    extra = [
        ("project.created", "user-reviewer", "case-demo-021"),
        ("project.audited", "user-reviewer", "case-demo-001"),
        ("project.audited", "user-demo-rev-03", "case-demo-013"),
        ("review.completed", "user-reviewer", "case-demo-005"),
        ("review.completed", "user-demo-rev-07", "case-demo-035"),
        ("rule.published", "user-tenant", "r-demo-01"),
        ("rule.published", "user-tenant", "r-demo-05"),
        ("rule.submitted", "user-reviewer", "r-demo-11"),
        ("rule.approved", "user-tenant", "r-demo-02"),
        ("account.created", "user-admin", "user-demo-rev-01"),
        ("account.created", "user-admin", "user-demo-admin-01"),
        ("account.status_changed", "user-admin", "user-demo-disabled-01"),
        ("auth.login", "user-reviewer", "13700002222"),
        ("auth.login", "user-tenant", "13500001111"),
        ("auth.login", "user-admin", "13800000000"),
        ("auth.login_failed", "unknown", "13800009999"),
        ("auth.login_failed", "unknown", "13700008888"),
        ("open.webhook_failed", "system", "oev-demo-005"),
        ("open.app_created", "user-admin", "app-demo-01"),
        ("permission.denied", "user-demo-rev-02", "/api/v1/users"),
        ("feedback.threshold", "system", "DEMO-FD-005"),
        ("point_confirm.stale_marked", "system", "ws-default"),
        ("ontology.published", "user-tenant", "onto-v1"),
        ("model.updated", "user-admin", "mdl-default"),
    ]
    idx = 61
    for k, (action, actor, obj) in enumerate(extra):
        created = s.fmt(start + timedelta(days=k % 10, hours=(k + 3) % 20))
        n += s.ins(c, "audit_log", {
            "id": f"log-demo-{idx:03d}", "actor": actor, "action": action,
            "object": obj,
            "after_json": json.dumps({"demo": True, "detail": "演示数据"}, ensure_ascii=False),
            "before_json": "", "request_id": f"demo-req-{idx:03d}", "ip": "127.0.0.1",
            "created_at": created, "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
        idx += 1
    # 业务审计：项目完成批量（30 条）
    for i in range(30):
        created = s.fmt(start + timedelta(days=(i + 2) % 10, hours=(i + 6) % 20))
        n += s.ins(c, "audit_log", {
            "id": f"log-demo-{idx:03d}", "actor": "user-reviewer", "action": "project.audited",
            "object": f"case-demo-{i + 1:03d}",
            "after_json": json.dumps({"demo": True, "run": f"run-demo-{i + 1:03d}"}, ensure_ascii=False),
            "before_json": "", "request_id": f"demo-req-{idx:03d}", "ip": "127.0.0.1",
            "created_at": created, "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
        idx += 1
    # 平台审计（平台运营端可见：action LIKE 'platform.%'/'tenant.%'）
    platform_rows = [
        ("platform.tenant.create", "tenant.create"), ("platform.tenant_admin.create", "tenant.admin"),
        ("platform.tenant.update", "tenant.update"), ("platform.tenant.status", "tenant.status"),
        ("platform.admin.create", "platform.admin"), ("tenant.config.update", "tenant.config"),
    ]
    for i in range(30):
        action, _kind = platform_rows[i % len(platform_rows)]
        created = s.fmt(start + timedelta(days=(i + 1) % 10, hours=(i * 2 + 1) % 20))
        n += s.ins(c, "audit_log", {
            "id": f"log-demo-platform-{i + 1:03d}", "actor": "user-platform",
            "action": action, "object": DEMO_TENANTS[i % len(DEMO_TENANTS)][0],
            "after_json": json.dumps({"demo": True, "tenant": DEMO_TENANTS[i % len(DEMO_TENANTS)][2]},
                                     ensure_ascii=False),
            "before_json": "", "request_id": f"demo-platform-req-{i + 1:03d}",
            "ip": "127.0.0.1", "created_at": created,
            "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
    # 新对象审计：本体 / 企业词典 / 规则状态 / 决策表 / 进化 / 冲突 / 点位确认
    start2 = BASE_DAY + timedelta(days=9)
    idx2 = 115

    def _log(action, actor, obj, after, i):
        nonlocal idx2, n
        created = s.fmt(start2 + timedelta(days=i % 12, hours=(i * 3) % 20))
        n += s.ins(c, "audit_log", {
            "id": f"log-demo-{idx2:03d}", "actor": actor, "action": action, "object": obj,
            "after_json": json.dumps(after, ensure_ascii=False) if not isinstance(after, str) else after,
            "before_json": "", "request_id": f"demo-req-{idx2:03d}", "ip": "127.0.0.1",
            "created_at": created, "tenant_id": TENANT, "workspace_id": WS_DEFAULT,
        })
        idx2 += 1

    i = 0
    for eid in s.ontology_entity_ids[:40]:
        _log("ontology.entity_added", "user-tenant", eid,
             {"demo": True, "source": "演示数据 · 本体建模"}, i); i += 1
    for aid in s.ontology_alias_ids[:24]:
        _log("ontology.alias_added", "user-tenant", aid,
             {"demo": True, "source": "演示数据 · 企业词典"}, i); i += 1
    _log("ontology.published", "user-tenant", "ov-demo-01",
         {"demo": True, "version": "v-demo-20261118"}, i); i += 1
    for rid in range(1, 13):
        _log("rule.published", "user-tenant", f"r-demo-{rid:02d}",
             {"demo": True, "version": "v1"}, i); i += 1
    for rid in range(13, 19):
        _log("rule.approved", "user-tenant", f"r-demo-{rid:02d}",
             {"demo": True, "status": "approved"}, i); i += 1
    for rid in (32, 35, 47):
        _log("rule.archived", "user-tenant", f"r-demo-{rid:02d}",
             {"demo": True, "status": "archived"}, i); i += 1
    for code in s.decision_table_codes:
        _log("decision_table.published", "user-tenant", code,
             {"demo": True, "source": "演示数据 · 决策表"}, i); i += 1
    for tid in s.evolution_task_ids[:16]:
        _log("evolution.candidate_created", "user-tenant", tid,
             {"demo": True, "note": "候选仅落痕，不自动发布"}, i); i += 1
    for cid in s.conflict_ids[:12]:
        _log("conflict.detected", "user-tenant", cid,
             {"demo": True, "source": "演示数据 · 冲突提醒"}, i); i += 1
    for term_id in s.term_ids:
        _log("term.confirmed", "user-tenant", term_id,
             {"demo": True, "source": "演示数据 · 企业词典"}, i); i += 1
    for k, wid in enumerate(("ws-default", "ws-demo-01", "ws-demo-02", "ws-demo-03")):
        _log("point_confirm.batch_confirmed", "user-admin", wid,
             {"demo": True, "points": 24 if k == 0 else 8}, i); i += 1
    return n


# --------------------------------------------------------------------------- 12. 点位确认 / 空间
# --------------------------------------------------------------------------- 12. 点位确认 / 空间
def seed_point_confirmations(s: Seeder) -> dict:
    """在多个空间确认 20+ 个平台点位（服务层 upsert，天然幂等）。"""
    from app.services import auditpoints, ctx, point_confirm
    result = {"spaces": {}, "errors": []}
    try:
        lib = auditpoints.load()
        point_ids = [p.id for p in (lib.points or []) if getattr(p, "id", "")]
    except Exception as exc:  # pragma: no cover - 点位库不可用时只报告不中断
        result["errors"].append(f"点位库加载失败：{type(exc).__name__}: {exc}")
        return result
    if not point_ids:
        result["errors"].append("点位库为空，跳过点位确认")
        return result
    plan = [(WS_DEFAULT, 24), ("ws-demo-01", 10), ("ws-demo-02", 8),
            ("ws-demo-03", 8), ("ws-demo-04", 6), ("ws-demo-06", 6)]
    cursor = 0
    for wid, count in plan:
        ids = point_ids[cursor:cursor + count]
        cursor += count
        if not ids:
            break
        try:
            with ctx.scoped(TENANT, wid):
                r = point_confirm.confirm_many(ids, "演示数据：批量确认点位模板", actor="user-admin")
            result["spaces"][wid] = int(r.get("updated") or 0) if not r.get("error") else 0
            if r.get("error"):
                result["errors"].append(f"{wid}: {r.get('error')}")
        except Exception as exc:  # pragma: no cover
            result["errors"].append(f"{wid}: {type(exc).__name__}: {exc}")
    return result



# --------------------------------------------------------------------------- 13. 目标校验
def verify_targets(s: Seeder) -> dict:
    q = {}

    def one(sql, params=()):
        c = s.db.connect()
        try:
            return int(c.execute(sql, params).fetchone()[0])
        except Exception:
            return -1
        finally:
            c.close()

    q["projects_total"] = one("SELECT COUNT(*) FROM audit_case")
    q["projects_t_default"] = one("SELECT COUNT(*) FROM audit_case WHERE tenant_id=?", (TENANT,))
    q["projects_completed"] = one("SELECT COUNT(*) FROM audit_case WHERE status='completed'")
    q["projects_reviewing"] = one("SELECT COUNT(*) FROM audit_case WHERE status='reviewing'")
    q["projects_draft"] = one("SELECT COUNT(*) FROM audit_case WHERE status='draft'")
    q["findings_total"] = one("SELECT COUNT(*) FROM finding")
    q["findings_with_evidence"] = one(
        "SELECT COUNT(*) FROM finding f WHERE EXISTS(SELECT 1 FROM evidence e WHERE e.finding_id=f.id)")
    q["findings_with_anchor"] = one(
        "SELECT COUNT(*) FROM finding f WHERE EXISTS(SELECT 1 FROM evidence e "
        "JOIN anchor a ON a.id=e.anchor_id WHERE e.finding_id=f.id "
        "AND COALESCE(a.locator,'')!='')")
    q["reviewer_projects"] = one("SELECT COUNT(*) FROM audit_case WHERE created_by='user-reviewer'")
    q["reviewer_reviewable_projects"] = one(
        "SELECT COUNT(DISTINCT f.case_id) FROM finding f JOIN audit_case c ON c.id=f.case_id "
        "WHERE c.created_by='user-reviewer' AND f.status='pending'")
    q["completed_mixed_projects"] = one(
        "SELECT COUNT(*) FROM audit_case c WHERE c.status='completed' AND "
        "EXISTS(SELECT 1 FROM finding f WHERE f.case_id=c.id AND f.status='pending') AND "
        "EXISTS(SELECT 1 FROM finding f2 WHERE f2.case_id=c.id AND f2.status!='pending')")
    q["audit_logs"] = one("SELECT COUNT(*) FROM audit_log")
    q["platform_audit_logs"] = one(
        "SELECT COUNT(*) FROM audit_log WHERE action LIKE 'platform.%' OR action LIKE 'tenant.%'")
    q["notifications"] = one("SELECT COUNT(*) FROM notification")
    q["feedback"] = one("SELECT COUNT(*) FROM feedback")
    q["error_book"] = one("SELECT COUNT(*) FROM decision WHERE decision='false_positive'")
    q["conflicts"] = one("SELECT COUNT(*) FROM conflict")
    q["rules"] = one("SELECT COUNT(*) FROM rule")
    q["rule_versions"] = one("SELECT COUNT(*) FROM rule_version")
    q["users_total"] = one("SELECT COUNT(*) FROM user WHERE COALESCE(status,'active')!='deleted'")
    q["users_demo_accounts"] = one(
        "SELECT COUNT(*) FROM user WHERE id LIKE 'user-demo-%' AND COALESCE(status,'active')!='deleted'")
    q["workspaces_t_default"] = one(
        "SELECT COUNT(*) FROM workspace WHERE tenant_id=? AND status='active'", (TENANT,))
    q["open_apps"] = one("SELECT COUNT(*) FROM open_app")
    q["open_events"] = one("SELECT COUNT(*) FROM open_event")
    q["tenants"] = one("SELECT COUNT(*) FROM tenant WHERE COALESCE(status,'active')!='deleted'")
    # 租户管理员 = 非默认租户下的 admin / super_admin（平台端「租户管理员」页口径）
    q["tenant_admins"] = one(
        "SELECT COUNT(DISTINCT u.id) FROM user u JOIN user_role ur ON ur.user_id=u.id "
        "JOIN role r ON r.id=ur.role_id WHERE r.code IN ('admin','super_admin') "
        "AND COALESCE(u.tenant_id,'') NOT IN ('', 't-default')")
    q["t_default_admins"] = one(
        "SELECT COUNT(DISTINCT u.id) FROM user u JOIN user_role ur ON ur.user_id=u.id "
        "JOIN role r ON r.id=ur.role_id WHERE r.code IN ('admin','super_admin') "
        "AND u.tenant_id='t-default'")
    q["password_resets"] = one("SELECT COUNT(*) FROM password_reset")
    q["point_confirmations"] = one(
        "SELECT COUNT(*) FROM auditpoint_confirmation WHERE status='confirmed'")
    q["point_confirm_spaces"] = one(
        "SELECT COUNT(DISTINCT workspace_id) FROM auditpoint_confirmation WHERE status='confirmed'")
    q["protected_fixtures"] = one(
        "SELECT COUNT(*) FROM audit_case WHERE id LIKE 'case-hist-%' OR id LIKE 'case-biz-%' "
        "OR id LIKE 'case-complex-%'")
    # ---- 追加域：本体 / 企业词典 / 规则进化 / 决策表 / 规则状态 / 冲突质量
    q["ontology_entities"] = one("SELECT COUNT(*) FROM onto_entity")
    q["ontology_aliases"] = one("SELECT COUNT(*) FROM onto_alias")
    q["ontology_links"] = one("SELECT COUNT(*) FROM onto_link")
    q["ontology_versions"] = one("SELECT COUNT(*) FROM onto_version")
    q["business_terms"] = one("SELECT COUNT(*) FROM business_term")
    ws_terms = 0
    try:
        c = s.db.connect()
        try:
            row = c.execute("SELECT settings_json FROM workspace WHERE id=?", (WS_DEFAULT,)).fetchone()
            settings = json.loads((row[0] if row else "") or "{}")
            ws_terms = len(settings.get("ontology_terms") or [])
        finally:
            c.close()
    except Exception:
        ws_terms = -1
    q["workspace_ontology_terms"] = ws_terms
    q["evolution_tasks"] = one("SELECT COUNT(*) FROM evolution_task")
    q["evolution_root_causes"] = one("SELECT COUNT(DISTINCT root_cause) FROM evolution_task")
    q["evolution_open_tasks"] = one("SELECT COUNT(*) FROM evolution_task WHERE status IN ('open','analyzed')")
    q["evolution_settled_tasks"] = one("SELECT COUNT(*) FROM evolution_task WHERE status IN ('settled','ignored')")
    q["rsi_candidates"] = one("SELECT COUNT(*) FROM rsi_candidate")
    q["rsi_candidate_decisions"] = one("SELECT COUNT(DISTINCT decision) FROM rsi_candidate")
    q["rsi_pending"] = one("SELECT COUNT(*) FROM rsi_candidate WHERE decision='pending'")
    q["rsi_settled"] = one("SELECT COUNT(*) FROM rsi_candidate WHERE decision<>'pending'")
    q["rsi_pending_undecided"] = one(
        "SELECT COUNT(*) FROM rsi_candidate WHERE decision='pending' AND COALESCE(decided_at,'')=''")
    q["rsi_traceable"] = one(
        "SELECT COUNT(*) FROM rsi_candidate WHERE note LIKE '%不会自动生效%'")
    q["rsi_feedback_traceable"] = one(
        "SELECT COUNT(*) FROM rsi_candidate c WHERE EXISTS("
        "SELECT 1 FROM feedback f WHERE f.id=c.feedback_id)")
    q["decision_tables"] = one("SELECT COUNT(*) FROM decision_table")
    q["decision_table_versions"] = one("SELECT COUNT(*) FROM decision_table_version")
    q["decision_table_statuses"] = one("SELECT COUNT(DISTINCT status) FROM decision_table")
    q["decision_table_published"] = one("SELECT COUNT(*) FROM decision_table WHERE status='published'")
    q["rule_statuses"] = one("SELECT COUNT(DISTINCT status) FROM rule")
    q["rules_approved"] = one("SELECT COUNT(*) FROM rule WHERE status='approved'")
    q["rules_archived"] = one("SELECT COUNT(*) FROM rule WHERE status='archived'")
    q["rules_published"] = one("SELECT COUNT(*) FROM rule WHERE status='published'")
    q["rules_pending"] = one("SELECT COUNT(*) FROM rule WHERE status='pending'")
    q["conflict_types"] = one("SELECT COUNT(DISTINCT type) FROM conflict")
    q["conflict_statuses"] = one("SELECT COUNT(DISTINCT status) FROM conflict")
    q["conflicts_with_real_rules"] = one(
        "SELECT COUNT(*) FROM conflict c WHERE EXISTS(SELECT 1 FROM rule r WHERE r.code=c.rule_a) "
        "AND EXISTS(SELECT 1 FROM rule r2 WHERE r2.code=c.rule_b)")
    q["audit_ontology_actions"] = one(
        "SELECT COUNT(*) FROM audit_log WHERE action LIKE 'ontology.%' OR action LIKE 'term.%'")
    q["audit_evolution_actions"] = one(
        "SELECT COUNT(*) FROM audit_log WHERE action LIKE 'evolution.%'")
    q["audit_decision_table_actions"] = one(
        "SELECT COUNT(*) FROM audit_log WHERE action LIKE 'decision_table.%'")
    q["notification_new_objects"] = one(
        "SELECT COUNT(*) FROM notification WHERE title LIKE '%本体%' OR title LIKE '%冲突%' "
        "OR title LIKE '%进化%' OR title LIKE '%决策表%' OR title LIKE '%规则状态%'")
    checks = [
        ("项目 60+", q["projects_total"] >= 60),
        ("完成/审核中/草稿混合", q["projects_completed"] >= 10 and q["projects_reviewing"] >= 10
         and q["projects_draft"] >= 5),
        ("findings 800+", q["findings_total"] >= 800),
        ("每条发现都有证据", q["findings_with_evidence"] >= q["findings_total"]),
        ("每条发现都有位置", q["findings_with_anchor"] >= q["findings_total"]),
        ("reviewer 可复核项目 10+", q["reviewer_reviewable_projects"] >= 10),
        ("completed 项目已复核/待复核混合", q["completed_mixed_projects"] >= 10),
        ("审计日志 80+", q["audit_logs"] >= 80),
        ("平台审计日志 10+", q["platform_audit_logs"] >= 10),
        ("消息/通知 50+", q["notifications"] >= 50),
        ("规则反馈 20+", q["feedback"] >= 20),
        ("错误书 20+", q["error_book"] >= 20),
        ("冲突 10+", q["conflicts"] >= 10),
        ("规则 20+", q["rules"] >= 20),
        ("规则版本 20+", q["rule_versions"] >= 20),
        ("账号 20+", q["users_total"] >= 20),
        ("演示账号 20+", q["users_demo_accounts"] >= 20),
        ("空间 10+", q["workspaces_t_default"] >= 10),
        ("开放应用 5+", q["open_apps"] >= 5),
        ("开放事件 5+", q["open_events"] >= 5),
        ("租户 10+", q["tenants"] >= 10),
        ("租户管理员 12+", q["tenant_admins"] >= 12),
        ("密码重置记录", q["password_resets"] >= 8),
        ("点位确认 15+", q["point_confirmations"] >= 15),
        ("点位确认跨空间", q["point_confirm_spaces"] >= 2),
        ("既有夹具仍在（case-hist/biz/complex）", q["protected_fixtures"] >= 14),
        # ---- 追加域
        ("本体实体 30+", q["ontology_entities"] >= 30),
        ("本体别名 60+", q["ontology_aliases"] >= 60),
        ("本体关系 40+", q["ontology_links"] >= 40),
        ("本体版本快照", q["ontology_versions"] >= 1),
        ("企业词典术语 12+", q["business_terms"] >= 12),
        ("当前空间术语可追溯 12+", q["workspace_ontology_terms"] >= 12),
        ("进化台账 30+", q["evolution_tasks"] >= 30),
        ("进化根因覆盖 5 类", q["evolution_root_causes"] >= 5),
        ("进化状态 pending/settled 混合",
         q["evolution_open_tasks"] >= 10 and q["evolution_settled_tasks"] >= 10),
        ("进化候选 30+", q["rsi_candidates"] >= 30),
        ("候选状态 pending/settled 混合", q["rsi_candidate_decisions"] >= 2
         and q["rsi_pending"] >= 10 and q["rsi_settled"] >= 10),
        ("候选不自动发布（pending 未裁决 + 全部标注 + 可追溯来源）",
         q["rsi_pending_undecided"] >= 10 and q["rsi_traceable"] >= 30
         and q["rsi_feedback_traceable"] >= 30),
        ("决策表 10+", q["decision_tables"] >= 10),
        ("决策表版本落库", q["decision_table_versions"] >= 4),
        ("决策表 draft/published/archived 混合", q["decision_table_statuses"] >= 3),
        ("决策表已发布 4+", q["decision_table_published"] >= 4),
        ("规则 60+", q["rules"] >= 60),
        ("规则状态覆盖 5 种", q["rule_statuses"] >= 5 and q["rules_approved"] >= 3
         and q["rules_archived"] >= 2),
        ("冲突 20+", q["conflicts"] >= 20),
        ("冲突类型 5 类", q["conflict_types"] >= 5),
        ("冲突状态 3 种", q["conflict_statuses"] >= 3),
        ("冲突 A/B 规则真实存在 20+", q["conflicts_with_real_rules"] >= 20),
        ("点位确认 20+", q["point_confirmations"] >= 20),
        ("审计覆盖本体/进化/决策表",
         q["audit_ontology_actions"] >= 20 and q["audit_evolution_actions"] >= 8
         and q["audit_decision_table_actions"] >= 8),
        ("消息覆盖新对象", q["notification_new_objects"] >= 8),
    ]
    failures = [name for name, ok in checks if not ok]
    return {"metrics": q, "checks": [{"name": n, "ok": bool(ok)} for n, ok in checks],
            "failures": failures}


# --------------------------------------------------------------------------- main
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="T-95 四角色大量演示数据扩充（独立脚本，幂等；先运行 seed.py）")
    ap.add_argument("--db", help="SQLite 库路径（默认读取 RULEPROOF_DB；等价于设置环境变量）")
    ap.add_argument("--summary-json", help="把执行摘要写到该 JSON 文件")
    ap.add_argument("--allow-live-db", action="store_true",
                    help="允许写默认库 data/ruleproof.db（仅演示环境使用）")
    args = ap.parse_args(argv)

    if args.db:
        os.environ["RULEPROOF_DB"] = os.path.abspath(args.db)

    started = time.time()
    s = Seeder()
    db = s.db
    db_path = str(db.DB_PATH)
    env = (os.environ.get("RULEPROOF_ENV") or "").strip().lower()
    demo_flag = (os.environ.get("RULEPROOF_SEED_DEMO") or "").strip().lower() in ("1", "true", "yes")
    allow_prod = (os.environ.get("RULEPROOF_DEMO_BULK_ALLOW_PROD") or "").strip() in ("1", "true", "yes")

    # ---- 安全校验
    if env in ("prod", "production") and not allow_prod:
        print("拒绝执行：生产环境（RULEPROOF_ENV=prod）默认不写演示数据。"
              "如确为演示环境，请显式设置 RULEPROOF_DEMO_BULK_ALLOW_PROD=1。", file=sys.stderr)
        return 2
    default_db = os.path.abspath(str(getattr(db, "DEFAULT_DB_PATH", "")))
    if os.path.abspath(db_path) == default_db and not (args.allow_live_db or demo_flag):
        print("拒绝执行：当前目标是默认库 data/ruleproof.db。"
              "请用 RULEPROOF_DB 指向临时/演示库，或显式 --allow-live-db / RULEPROOF_SEED_DEMO=1。",
              file=sys.stderr)
        return 2

    db.init_db()
    # 前置：必须已跑过 seed.py（演示账号/默认租户/默认空间/角色）
    missing = []
    c0 = db.connect()
    try:
        for uid in ("user-reviewer", "user-tenant", "user-admin", "user-platform"):
            if not c0.execute("SELECT 1 FROM user WHERE id=?", (uid,)).fetchone():
                missing.append(uid)
        for sql in ("SELECT 1 FROM tenant WHERE id='t-default'",
                    "SELECT 1 FROM workspace WHERE id='ws-default'",
                    "SELECT 1 FROM role WHERE code='reviewer'"):
            if not c0.execute(sql).fetchone():
                missing.append(sql)
    finally:
        c0.close()
    if missing:
        print("拒绝执行：目标库尚未完成 seed.py 初始化（缺少：" + "、".join(missing) + "）。"
              "请先运行 seed.py。", file=sys.stderr)
        return 2

    print(f"[seed_demo_bulk] 目标库：{db_path}")
    before = s.counts()
    print("[seed_demo_bulk] 写入演示数据 …")
    with db.session() as c:
        spaces = seed_workspaces(s, c)
        accounts = seed_accounts(s, c)
        platform = seed_platform(s, c)
        seed_password_resets(s, c, platform["tenant_admins"], accounts["reviewers"])
        seed_open_platform(s, c)
        onto = seed_ontology(s, c)
        rules = seed_rules(s, c)
        dts = seed_decision_tables(s, c)
        reviewers = accounts["reviewers"]
        build_projects(s, c, reviewers, rules, spaces)
        evolution = seed_evolution(s, c)
        seed_feedback(s, c)
        seed_conflicts(s, c)
        seed_notifications(s, c)
        seed_audit_logs(s, c)

    # 点位确认走服务层（自带事务与幂等 upsert），需在上一事务提交后执行
    pc = seed_point_confirmations(s)
    if pc.get("errors"):
        s.warnings.extend(pc["errors"])
    s.inserted["auditpoint_confirmation_confirmed"] = sum(pc.get("spaces", {}).values())

    after = s.counts()
    verify = verify_targets(s)
    duration = round(time.time() - started, 2)
    delta = {k: (after.get(k, 0) - before.get(k, 0)) for k in after}
    summary = {
        "script": "seed_demo_bulk.py",
        "db": db_path,
        "mode": {"env": env or "dev", "demo_flag": demo_flag, "live_db": os.path.abspath(db_path) == default_db},
        "duration_sec": duration,
        "before": before,
        "after": after,
        "delta": delta,
        "inserted": s.inserted,
        "decisions": len(s.decisions),
        "findings_generated": len(s.findings_index),
        "ontology": onto,
        "decision_tables": dts,
        "evolution": evolution,
        "conflict_total": len(s.conflict_ids),
        "other_doc_type_landed": s.other_doc_type_landed,
        "notes": s.notes,
        "point_confirmation_spaces": pc.get("spaces", {}),
        "warnings": s.warnings,
        "verify": verify,
    }
    if args.summary_json:
        os.makedirs(os.path.dirname(os.path.abspath(args.summary_json)) or ".", exist_ok=True)
        with open(args.summary_json, "w", encoding="utf-8") as fh:
            json.dump(summary, fh, ensure_ascii=False, indent=2)
    print(json.dumps({
        "db": db_path, "duration_sec": duration,
        "delta": {k: v for k, v in delta.items() if v},
        "verify_failures": verify["failures"],
        "metrics": verify["metrics"],
        "notes": s.notes,
        "warnings": s.warnings,
        "ontology": onto,
        "evolution": evolution,
        "decision_tables": dts,
    }, ensure_ascii=False, indent=2))
    if verify["failures"]:
        print("NOT DONE: " + "；".join(verify["failures"]), file=sys.stderr)
        return 1
    print("DONE: 演示数据扩充完成，全部目标达成。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
