(function () {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const TITLES = {home:["首页","平台租户与服务概况"],tenants:["租户管理","开通、维护租户与有效期"],tenantadmins:["租户管理员","查看每个租户的首个管理员"],operators:["平台管理员","开通与维护平台级账号"],architecture:["架构图","浅色 21 张（00–20）· 1.6.0 / v4.5 口径 · 本页内嵌查看（不新开页面）"],cli:["CLI / 命令行入口","原生 CLI 是平台一等入口：与 HTTP 同源；本页只展示与复制命令，不执行命令"],messages:["消息中心","租户到期与待处理提醒"]};
  let tenantId = "", tenantRows = [], operatorRows = [], operatorId = "";
  async function api(url, opt) { const r = await fetch(url, opt); const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || d.reason || ("HTTP " + r.status)); return d; }
  let toastTimer = 0;
  function toast(msg, type) { const el = $("#pf-toast"); el.className = "pf-toast " + (type || ""); el.textContent = msg; el.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => el.hidden = true, 3000); }
  function confirmAction(title, text, okText) {
    return new Promise(resolve => {
      $("#pf-confirm-title").textContent = title; $("#pf-confirm-text").textContent = text; $("#pf-confirm-ok").textContent = okText || "确认";
      const dangerous = /停用|删除|重置/.test(title);
      $("#pf-confirm-ok").className = "pf-btn " + (dangerous ? "confirm-danger" : "primary");
      $("#pf-confirm").hidden = false;
      const done = v => { $("#pf-confirm").hidden = true; resolve(v); };
      $("#pf-confirm-ok").onclick = () => done(true); $("#pf-confirm-cancel").onclick = () => done(false);
    });
  }
  async function busy(btn, label, fn) { const old = btn.textContent; btn.disabled = true; btn.textContent = label; try { return await fn(); } finally { btn.disabled = false; btn.textContent = old; } }
  function tenantDaysLeft(t) {
    if (!t.expires_at) return null;
    const end = new Date(t.expires_at + "T23:59:59");
    if (isNaN(end.getTime())) return null;
    return Math.ceil((end.getTime() - Date.now()) / 86400000);
  }
  function renderOverview() {
    const host = $("#pf-overview-body"); if (!host) return;
    const total = tenantRows.length;
    const formal = tenantRows.filter(t => t.edition === "formal").length;
    const trial = tenantRows.filter(t => t.edition !== "formal").length;
    const active = tenantRows.filter(t => t.status === "active").length;
    const noAdmin = tenantRows.filter(t => !t.has_admin).length;
    const expiring = tenantRows.filter(t => { const d = tenantDaysLeft(t); return d !== null && d >= 0 && d <= 30; });
    const expired = tenantRows.filter(t => { const d = tenantDaysLeft(t); return d !== null && d < 0; });
    const actions = [];
    tenantRows.filter(t => !t.has_admin).forEach(t => actions.push({label: "租户缺少首个管理员", detail: t.name, tab: "tenantadmins"}));
    tenantRows.filter(t => t.status !== "active").forEach(t => actions.push({label: "租户已停用", detail: t.name, tab: "tenants"}));
    expiring.forEach(t => actions.push({label: "租户即将到期", detail: `${t.name} · ${t.expires_at}`, tab: "messages"}));
    expired.forEach(t => actions.push({label: "租户已过期", detail: `${t.name} · ${t.expires_at}`, tab: "messages"}));
    host.innerHTML = `<div class="pf-ov-kpis">
        <div class="pf-ov-kpi"><b>${total}</b><span>租户总数</span></div>
        <div class="pf-ov-kpi"><b>${formal}</b><span>正式租户</span></div>
        <div class="pf-ov-kpi"><b>${trial}</b><span>试用租户</span></div>
        <div class="pf-ov-kpi"><b>${active}</b><span>启用租户</span></div>
        <div class="pf-ov-kpi ${noAdmin ? "warn" : "ok"}"><b>${noAdmin}</b><span>缺少管理员</span></div>
        <div class="pf-ov-kpi ${expiring.length + expired.length ? "warn" : "ok"}"><b>${expiring.length + expired.length}</b><span>到期/过期提醒</span></div>
      </div>
      <div class="pf-ov-lower">
        <div class="pf-ov-panel">
          <div class="pf-ov-title"><span>租户与服务状态</span><span class="pf-ov-sub">实时汇总</span></div>
          <div class="pf-ov-table">
            <div class="pf-ov-line"><span>正式 / 试用</span><b>${formal} / ${trial}</b></div>
            <div class="pf-ov-line"><span>启用 / 停用</span><b>${active} / ${total - active}</b></div>
            <div class="pf-ov-line"><span>30 天内到期</span><b class="${expiring.length ? "warn-text" : ""}">${expiring.length}</b></div>
            <div class="pf-ov-line"><span>已过期</span><b class="${expired.length ? "danger-text" : ""}">${expired.length}</b></div>
          </div>
        </div>
        <div class="pf-ov-panel">
          <div class="pf-ov-title"><span>需要我处理</span><span class="pf-ov-sub">${actions.length ? actions.length + " 项" : "暂无"}</span></div>
          <div class="pf-ov-actions">${actions.length ? actions.slice(0, 6).map(x => `<button class="pf-ov-action" data-ov-tab="${x.tab}"><span class="pf-ov-action-main"><b>${esc(x.label)}</b><small>${esc(x.detail)}</small></span><span class="pf-ov-arrow">查看 →</span></button>`).join("") : '<div class="pf-ov-empty">平台当前没有待处理项</div>'}</div>
        </div>
      </div>`;
    host.querySelectorAll("[data-ov-tab]").forEach(b => b.onclick = () => tab(b.dataset.ovTab));
  }
  async function renderTenantAdmins() {
    const host = $("#tenant-admin-list"); if (!host) return;
    host.innerHTML = '<tr><td colspan="8" class="pf-muted">加载中…</td></tr>';
    const groups = [];
    for (const t of tenantRows) {
      try {
        const d = await api(`/api/v1/platform/tenants/${encodeURIComponent(t.id)}/admins`);
        const admins = d.items || [];
        if (admins.length) groups.push({tenant: t, admins});
      } catch (e) { /* 单个租户读取失败不阻断其他租户 */ }
    }
    const total = groups.reduce((n, g) => n + g.admins.length, 0);
    if (!total) { host.innerHTML = '<tr><td colspan="8" class="pf-muted">暂无已配置的租户管理员</td></tr>'; return; }
    host.innerHTML = groups.map(g => {
      const active = g.admins.filter(a => (a.status || "active") === "active").length;
      return g.admins.map(a => {
        const isActive = (a.status || "active") === "active";
        // 后端 list_tenant_admins 下发 can_disable/disable_block_reason；旧数据回退到同口径计算。
        const reason = isActive
          ? (a.disable_block_reason || (a.can_disable === false || g.admins.length <= 1 || active <= 1
              ? "该租户至少保留一个启用中的管理员，不能停用" : ""))
          : "";
        const cannotDisable = isActive && !!reason;
        const statusBtn = cannotDisable
          ? `<button class="pf-link is-disabled" type="button" aria-disabled="true"
               data-tastatus="${esc(a.id)}" data-cur="active" data-disabled-reason="${esc(reason)}"
               title="${esc(reason)}">停用</button>
             <span class="pf-disabled-hint" title="${esc(reason)}">${esc(reason)}</span>`
          : `<button class="pf-link ${isActive ? "danger" : ""}" type="button"
               data-tastatus="${esc(a.id)}" data-cur="${esc(isActive ? "active" : "disabled")}">${isActive ? "停用" : "启用"}</button>`;
        return `<tr>
          <td><b>${esc(g.tenant.name)}</b></td>
          <td>${esc(a.name)}</td><td>${esc(a.phone)}</td><td>${esc(a.email || "—")}</td>
          <td><span class="pf-pill ${a.is_initial ? "formal" : ""}">${esc(a.role_label || (a.role_code === "super_admin" ? "系统管理员" : "业务管理员"))}</span>${a.is_initial ? ' <span class="pf-muted" style="font-size:11px">初始</span>' : ""}</td>
          <td><span class="pf-pill ${isActive ? "ok" : "off"}">${isActive ? "启用" : "停用"}</span></td>
          <td class="pf-muted">${esc((a.created_at || "").slice(0, 16))}</td>
          <td><div class="pf-actions"><button class="pf-btn" data-taedit="${esc(a.id)}" data-name="${esc(a.name)}" data-email="${esc(a.email || "")}">编辑</button><button class="pf-btn" data-tapwd="${esc(a.id)}" data-name="${esc(a.name)}">重置密码</button>${statusBtn}</div></td>
        </tr>`;
      }).join("");
    }).join("");
    host.querySelectorAll("[data-taedit]").forEach(b => b.onclick = () => editTenantAdmin(b));
    host.querySelectorAll("[data-tapwd]").forEach(b => b.onclick = () => resetTenantAdminPwd(b));
    host.querySelectorAll("[data-tastatus]").forEach(b => b.onclick = () => setTenantAdminStatus(b));
  }

  async function setTenantAdminStatus(btn) {
    const blocked = btn.dataset.disabledReason || (btn.getAttribute("aria-disabled") === "true"
      ? (btn.getAttribute("title") || "该管理员当前不可停用") : "");
    if (blocked) {
      // 不给用户“点了没反应”的错觉；不发请求，后端仍会 fail-closed。
      toast(blocked, "err");
      return;
    }
    const active = btn.dataset.cur === "active";
    const ok = await confirmAction(active ? "停用租户管理员" : "启用租户管理员",
      active ? "停用后该管理员将不能登录管理端；同一租户必须至少保留一个启用中的管理员。" : "确认恢复该管理员的登录？",
      active ? "确认停用" : "确认启用");
    if (!ok) return;
    await busy(btn, "处理中", async () => {
      try {
        await api("/api/v1/platform/tenant-admins/status", {method:"POST", headers:{"Content-Type":"application/json"},
          body: JSON.stringify({id: btn.dataset.tastatus, status: active ? "disabled" : "active"})});
        toast(active ? "管理员已停用" : "管理员已启用");
        await renderTenantAdmins();
      } catch (e) { toast("操作失败：" + e.message, "err"); }
    });
  }

  function openTenantAdminCreate() {
    const sel = $("#ta-tenant");
    sel.innerHTML = tenantRows.map(t => `<option value="${esc(t.id)}">${esc(t.name)}</option>`).join("");
    $("#ta-msg").textContent = ""; $("#ta-name").value = ""; $("#ta-phone").value = ""; $("#ta-email").value = ""; $("#ta-pwd").value = "";
    $("#pf-create-tenant-admin").hidden = false;
  }
  async function editTenantAdmin(btn) {
    const name = prompt("姓名：", btn.dataset.name || ""); if (name === null) return;
    const email = prompt("邮箱：", btn.dataset.email || ""); if (email === null) return;
    try {
      await api("/api/v1/platform/tenant-admins/update", {method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({id:btn.dataset.taedit, name, email})});
      toast("管理员已保存"); await renderTenantAdmins();
    } catch (e) { toast("保存失败：" + e.message, "err"); }
  }

  function showPlatformPwdResult(r, name) {
    $("#pf-pwd-result").hidden = false;
    $("#pf-pwd-result-body").innerHTML = `<div class="pf-muted" style="font-size:12px;margin-bottom:6px">账号：<b>${esc(name || "该账号")}</b></div><div class="pwd-value"><span>${esc(r.temporary_password || "")}</span><button class="pf-btn" id="pf-copy-pwd">复制密码</button></div><div class="pf-muted" style="font-size:11px;line-height:1.7">有效期至 ${esc(r.expires_at || "—")}<br>首次登录必须修改密码；改密成功后临时密码自动失效。</div>`;
    $("#pf-copy-pwd").onclick = async () => { try { await navigator.clipboard.writeText(r.temporary_password || ""); toast("临时密码已复制"); } catch (e) { toast("复制失败，请手动选择", "err"); } };
  }

  async function resetTenantAdminPwd(btn) {
    const ok = await confirmAction("重置租户管理员密码", "系统会生成新的临时密码，首次登录需修改。确认继续？", "确认重置");
    if (!ok) return;
    await busy(btn, "重置中", async () => {
      try {
        const r = await api("/api/v1/platform/tenant-admins/reset-password", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({id:btn.dataset.tapwd})});
        showPlatformPwdResult(r, btn.dataset.name); toast("临时密码已生成"); await renderTenantAdmins();
      } catch (e) { toast("重置失败：" + e.message, "err"); }
    });
  }

  let pfMsgTab = "all", pfMsgPage = 1, pfMsgStatus = "", pfMsgTenant = "";
  const PF_MSG_SIZE = 20;
  function platformMessageStatus(item) {
    if (item.level === "严重" || item.level === "状态" || item.level === "待处理") return "待处理";
    return "提醒";
  }
  function renderPlatformMessages() {
    const host = $("#pf-msg-list"); if (!host) return;
    const items = [];
    tenantRows.forEach(t => {
      const d = tenantDaysLeft(t);
      if (d !== null && d < 0) items.push({tab:"expiry", type:"到期提醒", level:"严重", cls:"alert", title:`租户已过期：${t.name}`, detail:`有效期至 ${t.expires_at}，已超过 ${Math.abs(d)} 天；请确认续期或停用。`, date:t.expires_at, tenant:t.id, tenantName:t.name, action:"tenant"});
      else if (d !== null && d <= 30) items.push({tab:"expiry", type:"到期提醒", level:"严重", cls:"wait", title:`租户即将到期：${t.name}`, detail:`有效期至 ${t.expires_at}，剩余 ${d} 天；请确认续期。`, date:t.expires_at, tenant:t.id, tenantName:t.name, action:"tenant"});
      else if (d !== null && d <= 60 && t.edition !== "formal") items.push({tab:"expiry", type:"到期提醒", level:"提醒", cls:"wait", title:`试用租户即将到期：${t.name}`, detail:`有效期至 ${t.expires_at}，剩余 ${d} 天；请确认是否转正式。`, date:t.expires_at, tenant:t.id, tenantName:t.name, action:"tenant"});
      if (!t.has_admin) items.push({tab:"admin", type:"管理员配置", level:"待处理", cls:"alert", title:`租户缺少管理员：${t.name}`, detail:"尚未配置首个租户管理员，租户无法正常开通。", date:"", tenant:t.id, tenantName:t.name, action:"admin"});
      if (t.status !== "active") items.push({tab:"status", type:"租户状态", level:"状态", cls:"alert", title:`租户已停用：${t.name}`, detail:"该租户当前不能登录；如恢复服务请启用。", date:"", tenant:t.id, tenantName:t.name, action:"tenant"});
    });
    items.forEach(x => { x.status = platformMessageStatus(x); });
    const ts = $("#pf-msg-tenant");
    if (ts) {
      const cur = ts.value;
      ts.innerHTML = '<option value="">全部租户</option>' + tenantRows.map(t => `<option value="${esc(t.id)}">${esc(t.name)}</option>`).join("");
      ts.value = tenantRows.some(t => t.id === cur) ? cur : "";
      pfMsgTenant = ts.value || "";
      if (!ts.dataset.bound) {
        ts.dataset.bound = "1";
        ts.onchange = () => { pfMsgTenant = ts.value || ""; pfMsgPage = 1; renderPlatformMessages(); };
        $("#pf-msg-status").onchange = () => { pfMsgStatus = $("#pf-msg-status").value || ""; pfMsgPage = 1; renderPlatformMessages(); };
      }
    }
    const filtered = items.filter(x => (pfMsgTab === "all" || x.tab === pfMsgTab)
      && (!pfMsgStatus || x.status === pfMsgStatus)
      && (!pfMsgTenant || x.tenant === pfMsgTenant));
    const pages = Math.max(1, Math.ceil(filtered.length / PF_MSG_SIZE));
    pfMsgPage = Math.min(pfMsgPage, pages);
    const start = (pfMsgPage - 1) * PF_MSG_SIZE;
    const shown = filtered.slice(start, start + PF_MSG_SIZE);
    document.querySelectorAll("[data-pfmsg]").forEach(b => b.classList.toggle("on", b.dataset.pfmsg === pfMsgTab));
    const count = $("#pf-msg-count"); if (count) count.textContent = `共 ${filtered.length} 条`;
    host.innerHTML = shown.length ? `<table class="table pf-table"><thead><tr><th style="width:82px">状态</th><th style="width:105px">类型</th><th>租户 / 空间</th><th>内容</th><th style="width:115px">到期 / 时间</th><th style="width:100px">操作</th></tr></thead><tbody>` +
      shown.map(x => `<tr><td><span class="pf-msg-status ${x.status === "待处理" ? "wait" : "alert"}">${esc(x.status)}</span></td>
        <td class="muted">${esc(x.type)}</td><td><b>${esc(x.tenantName)}</b></td>
        <td><div><b>${esc(x.title)}</b></div><div class="muted" style="font-size:11px;line-height:1.5">${esc(x.detail)}</div></td>
        <td class="muted">${esc(x.date || "—")}</td>
        <td>${x.action === "admin" ? `<button class="pf-btn" data-pfmsg-admin="${esc(x.tenant)}">查看管理员</button>` : `<button class="pf-btn" data-pfmsg-tenant="${esc(x.tenant)}">查看租户</button>`}</td></tr>`).join("") + `</tbody></table>`
      : `<div class="empty">${pfMsgTab === "all" ? "暂无租户到期或待处理提醒" : "当前筛选暂无消息"}</div>`;
    const pager = $("#pf-msg-pager");
    if (pager) pager.innerHTML = filtered.length ? `<div class="pager"><span class="pager-total">第 ${start + 1}–${Math.min(start + PF_MSG_SIZE, filtered.length)} 条，共 ${filtered.length} 条 · 第 ${pfMsgPage}/${pages} 页</span><div class="pager-actions"><button data-pfmsg-page="${pfMsgPage - 1}" ${pfMsgPage <= 1 ? "disabled" : ""}>上一页</button>${Array.from({length: pages}, (_, i) => i + 1).slice(Math.max(0, pfMsgPage - 3), Math.max(0, pfMsgPage - 3) + 5).map(n => `<button class="${n === pfMsgPage ? "on" : ""}" data-pfmsg-page="${n}">${n}</button>`).join("")}<button data-pfmsg-page="${pfMsgPage + 1}" ${pfMsgPage >= pages ? "disabled" : ""}>下一页</button></div></div>` : "";
    host.querySelectorAll("[data-pfmsg-tenant]").forEach(b => b.onclick = () => openTenantEdit(b.dataset.pfmsgTenant));
    host.querySelectorAll("[data-pfmsg-admin]").forEach(b => b.onclick = () => tab("tenantadmins"));
    pager?.querySelectorAll("[data-pfmsg-page]").forEach(b => b.onclick = () => {
      const p = Number(b.dataset.pfmsgPage); if (p >= 1 && p <= pages) { pfMsgPage = p; renderPlatformMessages(); }
    });
  }
  document.querySelectorAll("[data-pfmsg]").forEach(b => b.addEventListener("click", () => {
    pfMsgTab = b.dataset.pfmsg; pfMsgPage = 1; renderPlatformMessages();
  }));

  async function resetOperatorPwd(btn) {
    const ok = await confirmAction("重置平台管理员密码", "系统会生成新的临时密码，首次登录需修改。确认继续？", "确认重置");
    if (!ok) return;
    await busy(btn, "重置中", async () => { try { const r = await api("/api/v1/platform/admins/reset-password", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({id:btn.dataset.oppwd})}); showPlatformPwdResult(r, btn.dataset.opname); toast("临时密码已生成"); await loadOperators(); } catch (e) { toast("重置失败：" + e.message, "err"); } });
  }
  $("#t-create").onclick = async function () {
    const btn = this; const name = $("#t-name").value.trim(), aname = $("#t-admin-name").value.trim(),
      phone = $("#t-admin-phone").value.trim(), email = $("#t-admin-email").value.trim(), pwd = $("#t-admin-pwd").value,
      edition = $("#t-edition").value, expires = $("#t-expires").value;
    if (!name || !aname || !phone || !pwd || !expires) { toast("请填租户名称、有效期、管理员姓名、手机号和密码", "err"); return; }
    const ok = await confirmAction("开通租户", `确认开通租户「${name}」并创建首个租户管理员 ${aname}？`, "确认开通");
    if (!ok) return;
    await busy(btn, "开通中", async () => { try {
      const d = await api("/api/v1/platform/tenants/create", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name, edition, expires_at:expires, admin_name:aname, admin_phone:phone, admin_email:email, admin_pwd:pwd})});
      $("#msg").textContent = "租户和首个租户管理员已创建"; toast("租户和首个租户管理员已创建");
      ["#t-name","#t-admin-name","#t-admin-phone","#t-admin-email","#t-admin-pwd","#t-expires"].forEach(s => $(s).value = "");
      $("#pf-create-tenant").hidden = true; await loadTenants();
    } catch (e) { $("#msg").textContent = "新增失败：" + e.message; toast("新增失败：" + e.message, "err"); } });
  };
  async function loadOperators() {
    const d = await api("/api/v1/platform/admins");
    operatorRows = d.items || [];
    $("#admin-rows").innerHTML = operatorRows.map((a, i) => `<tr><td><b>${esc(a.name)}</b></td><td>${esc(a.phone)}</td><td>${esc(a.email || "—")}</td>
      <td><span class="pf-pill ${a.status === "active" ? "ok" : "off"}">${a.status === "active" ? "启用" : "停用"}</span></td><td class="pf-muted">${esc((a.created_at || "").slice(0, 16))}</td>
      <td>${a.protected ? `<span class="pf-pill">初始账号 · 不可操作</span>` : `<div class="pf-actions"><button class="pf-btn" data-opedit="${esc(a.id)}" data-name="${esc(a.name)}" data-email="${esc(a.email || "")}">编辑</button><button class="pf-btn" data-oppwd="${esc(a.id)}" data-opname="${esc(a.name)}">重置密码</button>${a.status === "active" ? `<button class="pf-link danger" data-opstatus="${esc(a.id)}" data-cur="active">停用</button>` : `<button class="pf-link" data-opstatus="${esc(a.id)}" data-cur="${esc(a.status)}">启用</button>`}<button class="pf-link danger" data-opdel="${esc(a.id)}">删除</button></div>`}</td></tr>`).join("") || `<tr><td colspan="6" class="pf-muted">暂无平台管理员账号</td></tr>`;
    document.querySelectorAll("[data-opedit]").forEach(b => b.onclick = () => openOperatorEdit(b));
    document.querySelectorAll("[data-opstatus]").forEach(b => b.onclick = () => setOperatorStatus(b));
    document.querySelectorAll("[data-oppwd]").forEach(b => b.onclick = () => resetOperatorPwd(b));
    document.querySelectorAll("[data-opdel]").forEach(b => b.onclick = () => deleteOperator(b));
    renderOverview();
  }
  function openOperatorEdit(btn) { operatorId = btn.dataset.opedit; $("#op-name").value = btn.dataset.name || ""; $("#op-email").value = btn.dataset.email || ""; $("#op-phone").value = ""; $("#pf-operator").hidden = false; }
  $("#op-save").onclick = async function () { const btn = this; await busy(btn, "保存中", async () => { try { await api("/api/v1/platform/admins/update", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({id:operatorId, name:$("#op-name").value.trim(), email:$("#op-email").value.trim()})}); toast("平台管理员已保存"); $("#pf-operator").hidden = true; await loadOperators(); } catch (e) { toast("保存失败：" + e.message, "err"); } }); };
  async function setOperatorStatus(btn) { const active = btn.dataset.cur === "active"; const ok = await confirmAction(active ? "停用平台管理员" : "启用平台管理员", active ? "停用后该平台管理员不能登录平台端。确认继续？" : "确认恢复该平台管理员的登录？", active ? "确认停用" : "确认启用"); if (!ok) return; await busy(btn, "处理中", async () => { try { await api("/api/v1/platform/admins/status", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({id:btn.dataset.opstatus, status:active?"disabled":"active"})}); toast(active ? "已停用" : "已启用"); await loadOperators(); } catch (e) { toast("操作失败：" + e.message, "err"); } }); }
  async function deleteOperator(btn) { const ok = await confirmAction("删除平台管理员", "删除后该平台管理员不能登录平台端。确认删除？", "确认删除"); if (!ok) return; await busy(btn, "删除中", async () => { try { await api("/api/v1/platform/admins/delete", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({id:btn.dataset.opdel})}); toast("平台管理员已删除"); await loadOperators(); } catch (e) { toast("删除失败：" + e.message, "err"); } }); }
  $("#a-create").onclick = async function () { const btn = this; const name = $("#a-name").value.trim(), phone = $("#a-phone").value.trim(), email = $("#a-email").value.trim(), pwd = $("#a-pwd").value; if (!name || !phone || !pwd) { toast("请填姓名、手机号和初始密码", "err"); return; } const ok = await confirmAction("新增平台管理员", `确认新增平台管理员「${name}」？`, "确认新增"); if (!ok) return; await busy(btn, "新增中", async () => { try { await api("/api/v1/platform/admins", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name, phone, email, password:pwd})}); toast("平台管理员已新增"); $("#a-name").value = $("#a-phone").value = $("#a-email").value = $("#a-pwd").value = ""; await loadOperators(); } catch (e) { toast("新增失败：" + e.message, "err"); } }); };
  $("#ta-open-create").onclick = openTenantAdminCreate;
  $("#ta-create").onclick = async function () {
    const btn = this;
    const tenantId = $("#ta-tenant").value, name = $("#ta-name").value.trim(), phone = $("#ta-phone").value.trim(),
      email = $("#ta-email").value.trim(), pwd = $("#ta-pwd").value;
    if (!tenantId || !name || !phone || !pwd) { $("#ta-msg").textContent = "请填所属租户、姓名、手机号和初始密码"; return; }
    await busy(btn, "新增中", async () => {
      try {
        await api(`/api/v1/platform/tenants/${encodeURIComponent(tenantId)}/admins`, {method:"POST", headers:{"Content-Type":"application/json"},
          body: JSON.stringify({name, phone, email, password: pwd})});
        $("#pf-create-tenant-admin").hidden = true; toast("租户管理员已新增");
        await loadTenants(); await renderTenantAdmins();
      } catch (e) { $("#ta-msg").textContent = "新增失败：" + e.message; }
    });
  };
  $("#t-open-create").onclick = () => {
    $("#msg").textContent = ""; $("#pf-create-tenant").hidden = false;
    const d = new Date(); d.setFullYear(d.getFullYear() + 1);
    $("#t-expires").value = d.toISOString().slice(0, 10);
  };
  $("#a-open-create").onclick = () => { $("#a-msg").textContent = ""; $("#pf-create-operator").hidden = false; };
  $("#t-refresh").onclick = () => loadTenants().then(() => toast("租户列表已刷新"));
  $("#msg-refresh").onclick = () => loadTenants().then(() => { renderPlatformMessages(); toast("消息已刷新"); });

  function renderTenantRows() {
    const host = $("#tenant-rows"); if (!host) return;
    host.innerHTML = tenantRows.map(t => {
      const edition = t.edition === "formal" ? "正式" : "试用";
      const status = (t.status || "active") === "active" ? "启用" : "停用";
      return `<tr><td><b>${esc(t.name)}</b><div class="pf-muted" style="font-size:10px">${esc(t.code || t.id)}</div></td>
        <td><span class="pf-pill ${t.edition === "formal" ? "formal" : ""}">${edition}</span></td>
        <td class="pf-muted">${esc(t.expires_at || "—")}</td>
        <td>${esc(t.admin_name || "未配置")}</td><td class="pf-muted">${esc(t.admin_phone || "—")}</td>
        <td><span class="pf-pill ${status === "启用" ? "ok" : "off"}">${status}</span></td>
        <td class="pf-muted">${esc((t.created_at || "").slice(0, 16))}</td>
        <td><div class="pf-actions"><button class="pf-btn" data-tenant-edit="${esc(t.id)}">编辑</button>
          ${t.protected ? '<span class="pf-pill">默认租户</span>' : `<button class="pf-link ${status === "启用" ? "danger" : ""}" data-tenant-status="${esc(t.id)}" data-cur="${esc(t.status || "active")}">${status === "启用" ? "停用" : "启用"}</button>`}</div></td></tr>`;
    }).join("") || `<tr><td colspan="8" class="pf-muted">暂无租户</td></tr>`;
    host.querySelectorAll("[data-tenant-edit]").forEach(b => b.onclick = () => openTenantEdit(b.dataset.tenantEdit));
    host.querySelectorAll("[data-tenant-status]").forEach(b => b.onclick = () => setTenantStatus(b));
  }

  async function loadTenants() {
    const d = await api("/api/v1/platform/tenants");
    tenantRows = d.items || [];
    renderTenantRows();
    renderOverview();
  }

  function openTenantEdit(id) {
    const t = tenantRows.find(x => x.id === id); if (!t) return;
    tenantId = id;
    $("#pf-tenant-title").textContent = "编辑租户：" + (t.name || "");
    $("#te-name").value = t.name || "";
    $("#te-edition").value = t.edition || "trial";
    $("#te-expires").value = t.expires_at || "";
    $("#pf-tenant").hidden = false;
  }

  async function setTenantStatus(btn) {
    const active = btn.dataset.cur === "active";
    const ok = await confirmAction(active ? "停用租户" : "启用租户",
      active ? "停用后该租户下所有账号不能登录；确认继续？" : "确认恢复该租户服务？",
      active ? "确认停用" : "确认启用");
    if (!ok) return;
    await busy(btn, "处理中", async () => {
      try {
        await api("/api/v1/platform/tenants/update", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: btn.dataset.tenantStatus, status: active ? "disabled" : "active" }) });
        toast(active ? "租户已停用" : "租户已启用");
        await loadTenants();
      } catch (e) { toast("操作失败：" + e.message, "err"); }
    });
  }

  // ── 架构图库：本页内嵌查看器（T-74，不新开页面）─────────────────────
  let archItems = [], archCat = "all", archLoaded = false;
  let archOpenId = "", archFocusId = "", archScrollY = 0, archViewerFromClick = false;
  let archFitTimer = 0, archLoadTimer = 0, archSyncTimer = 0;
  const ARCH_CAT_ORDER = ["全景", "主链", "总览", "规则", "本体", "平台", "执行", "治理", "智能体", "交付"];
  function archEsc(s) { return esc(s); }
  function archById(id) { return archItems.find(x => String(x.id) === String(id)) || null; }
  function archStatusTone(st) {
    const s = String(st || "");
    if (s === "已接通") return "ok";
    if (s === "部分") return "part";
    if (s === "未接通") return "off";
    if (s === "风险") return "risk";
    return "";
  }
  function archHash(id) { return "#architecture/" + encodeURIComponent(id); }
  function parseArchHash() {
    const m = /^#architecture\/([^/?#]+)/.exec(location.hash || "");
    if (!m) return "";
    try { return decodeURIComponent(m[1]); } catch (e) { return ""; }
  }
  function renderArchFilters() {
    const filters = $("#arch-filters"); if (!filters) return;
    const known = new Set(ARCH_CAT_ORDER);
    const extra = Array.from(new Set(archItems.map(x => x.category || "其他").filter(c => !known.has(c))));
    const cats = ["all", ...ARCH_CAT_ORDER.filter(c => archItems.some(x => (x.category || "其他") === c)), ...extra];
    filters.innerHTML = cats.map(c => {
      const n = c === "all" ? archItems.length : archItems.filter(x => (x.category || "其他") === c).length;
      return `<button type="button" data-arch-cat="${archEsc(c)}" class="${c === archCat ? "on" : ""}" aria-pressed="${c === archCat}">${c === "all" ? "全部" : archEsc(c)} <span style="color:#A0A6B0">${n}</span></button>`;
    }).join("");
    filters.querySelectorAll("[data-arch-cat]").forEach(b => b.onclick = () => { archCat = b.dataset.archCat; renderArchitecture(); });
  }
  function renderArchitecture() {
    const host = $("#arch-grid"); if (!host) return;
    renderArchFilters();
    const rows = archItems.filter(x => archCat === "all" || (x.category || "其他") === archCat);
    host.innerHTML = rows.length ? rows.map(x => {
      const tone = archStatusTone(x.status);
      // T-90：manifest cover → 卡片 CSS 变量 `--arch-cover`；无 cover 字段时走渐变回退。
      const cover = x.cover ? encodeURI("/architecture/" + String(x.cover).replace(/^\/+/, "")) : "";
      const coverStyle = cover ? ` style="--arch-cover:url('${archEsc(cover)}')"` : "";
      const coverData = cover ? ` data-arch-cover-src="${archEsc(cover)}"` : "";
      const coverCls = cover ? "arch-cover" : "arch-cover arch-cover--fallback";
      return `<article class="arch-card" data-arch-id="${archEsc(x.id)}" tabindex="0" role="button" aria-label="查看架构图详情：${archEsc(x.title)}">
        <div class="${coverCls}"${coverStyle}${coverData}><div class="arch-cover-bg" aria-hidden="true"></div><div class="arch-cover-top"><small>${archEsc(x.category || "架构图")} · ARCH ${archEsc(x.id)}</small><span class="arch-cover-status ${tone}">${archEsc(x.status || "")}</span></div><b>${archEsc(x.title)}</b><span class="arch-cover-hint">点击查看详情 · 不新开页面</span></div>
        <div class="arch-body"><p>${archEsc(x.summary || "")}</p>
          <div class="arch-tags">${(x.tags || []).map(t => `<span class="arch-tag">${archEsc(t)}</span>`).join("")}<span class="arch-tag">${archEsc(x.status || "")}</span></div>
          <div class="arch-actions"><span class="arch-cta">查看详情 →</span></div>
        </div></article>`;
    }).join("") : '<div class="arch-empty">当前分类没有架构图</div>';
    host.querySelectorAll("[data-arch-id]").forEach(el => {
      el.onclick = () => openArch(el.dataset.archId);
      el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openArch(el.dataset.archId); } };
    });
    // 封面加载失败兜底：预加载对应 JPG；失败先重试一次（防瞬时抖动），仍失败才去掉图片层、
    // 保留深色渐变（标题/状态仍可读）。封面为可选装饰，加载失败不影响卡片点击查看。
    host.querySelectorAll(".arch-cover[data-arch-cover-src]").forEach(el => {
      const src = el.dataset.archCoverSrc;
      if (!src) return;
      let attempt = 0;
      const load = () => {
        const im = new Image();
        im.onerror = () => {
          if (attempt++ < 1) { setTimeout(load, 150); return; }
          el.style.setProperty("--arch-cover", "none");
          el.classList.add("arch-cover--fallback");
        };
        im.src = attempt ? src + (src.includes("?") ? "&" : "?") + "retry=" + attempt : src;
      };
      load();
    });
    const hint = $("#arch-hint");
    if (hint) hint.textContent = `共 ${archItems.length} 张自包含 HTML 架构图（manifest_v4.3 ${archItems.length} 项 · 1.6.0 / v4.5 浅色图集：00–20），每张配 16:9 模糊封面；点击卡片在本页直接查看，顶部固定「← 返回架构图库」，支持浏览器后退与刷新恢复。`;
  }
  async function loadArchitecture() {
    if (!archLoaded) {
      const d = await api("/architecture/manifest_v4.3.json");
      archItems = (Array.isArray(d.items) ? d.items : []).slice().sort((a, b) => String(a.id).localeCompare(String(b.id)));
      archLoaded = true;
    }
    renderArchitecture();
    const want = parseArchHash();
    if (want) {
      const item = archById(want);
      if (item) showArchViewer(item, false);
      else history.replaceState(null, "", "#architecture");
    }
  }
  function fitArchFrame() {
    const frame = $("#arch-frame"); if (!frame || !archOpenId) return;
    try {
      const doc = frame.contentDocument;
      if (!doc || !doc.documentElement) return;
      const h = Math.max(doc.documentElement.scrollHeight || 0, doc.body ? doc.body.scrollHeight : 0);
      if (h > 240) frame.style.height = Math.ceil(h + 2) + "px";
      if (doc.body && frame.dataset.observed !== "1") {
        frame.dataset.observed = "1";
        const win = frame.contentWindow;
        if (win && win.ResizeObserver) { const ro = new win.ResizeObserver(() => scheduleArchFit()); ro.observe(doc.body); }
      }
    } catch (e) { /* 同源读取失败时保留默认高度，不阻断查看 */ }
  }
  function scheduleArchFit() { clearTimeout(archFitTimer); archFitTimer = setTimeout(fitArchFrame, 80); }
  function showArchViewer(item, fromClick) {
    if (!item) return;
    if (!archOpenId) archScrollY = window.scrollY || 0;
    archOpenId = item.id; archFocusId = item.id; archViewerFromClick = !!fromClick;
    const lib = $("#arch-library"), viewer = $("#arch-viewer");
    if (lib) lib.hidden = true;
    if (viewer) viewer.hidden = false;
    $("#arch-vtitle").textContent = item.title || "架构图";
    $("#arch-vsub").textContent = `${item.category || "架构图"} · ARCH ${item.id}/${archItems.length} · ${(item.html || "").replace(/^html\//, "")}`;
    const st = $("#arch-vstatus"); st.textContent = item.status || ""; st.className = "arch-vstatus " + archStatusTone(item.status);
    document.title = `${item.title} · 架构图 · 平台端 · AI 审核平台`;
    const frame = $("#arch-frame");
    if (frame) {
      // P2-06：架构 HTML 经 srcdoc 注入时继承平台 origin；sandbox 禁脚本执行（架构图为
      // 自包含静态 HTML，无脚本），保留 allow-same-origin 以便测量内容高度/自适应。
      frame.setAttribute("sandbox", "allow-same-origin");
      const src = "/architecture/" + item.html;
      frame.dataset.archSrc = src; frame.dataset.loaded = ""; frame.dataset.observed = "";
      frame.title = (item.title || "架构图") + " · " + (item.category || "");
      $("#arch-verr").hidden = true;
      loadArchFrameDocument(src);
      clearTimeout(archLoadTimer);
      archLoadTimer = setTimeout(() => {
        if (!frame.dataset.loaded) { $("#arch-verr").hidden = false; $("#arch-verr-msg").textContent = "未在 30 秒内完成加载：" + src; }
      }, 30000);
    }
    if (fromClick) history.pushState({ arch: item.id }, "", archHash(item.id));
    else history.replaceState({ arch: item.id }, "", archHash(item.id));
    window.scrollTo({ top: 0, behavior: "auto" });
    requestAnimationFrame(() => { const b = $("#arch-back"); if (b) b.focus({ preventScroll: true }); });
    scheduleArchFit();
  }
  function loadArchFrameDocument(src) {
    const frame = $("#arch-frame"); if (!frame || !src) return;
    const token = String(Date.now()) + "-" + Math.random().toString(16).slice(2);
    frame.dataset.req = token;
    $("#arch-verr").hidden = true;
    fetch(src, { credentials: "same-origin" }).then(r => {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.text();
    }).then(html => {
      if (archOpenId && frame.dataset.req === token && html && html.length > 200) { frame.srcdoc = html; }
    }).catch(e => {
      if (frame.dataset.req !== token) return;
      const err = $("#arch-verr");
      if (err) { err.hidden = false; $("#arch-verr-msg").textContent = "加载 " + src + " 失败：" + ((e && e.message) || e); }
    });
  }
  function restoreArchLibrary(opts) {
    opts = opts || {};
    const frame = $("#arch-frame");
    if (frame) { frame.dataset.loaded = ""; frame.dataset.observed = ""; frame.dataset.req = ""; frame.srcdoc = "<!doctype html><html><body style=\"margin:0;background:#F8FAFD\"></body></html>"; }
    const lib = $("#arch-library"), viewer = $("#arch-viewer");
    if (viewer) viewer.hidden = true;
    if (lib) lib.hidden = false;
    archOpenId = ""; archViewerFromClick = false;
    document.title = "平台端 · AI 审核平台";
    renderArchitecture();
    requestAnimationFrame(() => {
      if (opts.keepScroll !== true) window.scrollTo({ top: archScrollY || 0, behavior: "auto" });
      const card = archFocusId ? document.querySelector(`[data-arch-id="${archFocusId}"]`) : null;
      if (card) card.focus({ preventScroll: true });
    });
  }
  function backToArchLibrary() {
    if (!archOpenId) return;
    if (archViewerFromClick && /^#architecture\//.test(location.hash || "")) {
      archViewerFromClick = false;
      history.back();
      return;
    }
    history.replaceState(null, "", "#architecture");
    restoreArchLibrary();
  }
  function syncArchFromLocation() {
    clearTimeout(archSyncTimer);
    archSyncTimer = setTimeout(() => {
      const want = parseArchHash();
      if (want) { const item = archById(want); if (item) { showArchViewer(item, false); return; } }
      if (archOpenId) restoreArchLibrary();
    }, 20);
  }
  function openArch(id) {
    const item = archById(id);
    if (!item) return;
    showArchViewer(item, true);
  }

  function tab(name) {
    const titles = TITLES[name] || ["平台端", ""];
    $("#pf-title").textContent = titles[0];
    $("#pf-sub").textContent = titles[1] || "";
    // 离开架构图页时，收掉查看器并清掉图 hash，避免刷新后停留在已隐藏的查看器
    if (name !== "architecture" && archOpenId) {
      history.replaceState(null, "", location.pathname + location.search);
      restoreArchLibrary({ keepScroll: true });
    }
    document.querySelectorAll("[data-panel]").forEach(p => { p.hidden = p.dataset.panel !== name; });
    document.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("on", b.dataset.tab === name));
    if (name === "home") { loadTenants().then(renderOverview).catch(e => toast(e.message, "err")); }
    else if (name === "tenants") { loadTenants().catch(e => toast(e.message, "err")); }
    else if (name === "tenantadmins") { loadTenants().then(renderTenantAdmins).catch(e => toast(e.message, "err")); }
    else if (name === "operators") { loadOperators().catch(e => toast(e.message, "err")); }
    else if (name === "cli") { renderCliEntry(); }
    else if (name === "messages") { loadTenants().then(renderPlatformMessages).catch(e => toast(e.message, "err")); }
    else if (name === "architecture") { return loadArchitecture().catch(e => toast(e.message, "err")); }
  }

  // ── CLI / 命令行入口（T-101）──────────────────────────────────────────
  // 权限：仅在 boot() 用 /api/v1/me 校验出 platform_op 后调用 renderCliEntry()；
  //       卡片默认 hidden + 空内容 = fail-closed，reviewer/admin/system/未登录均看不到。
  // 安全：只展示/复制命令文本；不提供命令输入框、不请求命令浏览接口、不执行任何命令
  //       （无 eval/new Function/子进程，不开放 RCE）。命令需在服务器/本机终端执行。
  const CLI_ENTRY = {
    help: [
      { cmd: "./rp --help", note: "原生入口帮助（./rp 自动选择 Python 3.10+）" },
      { cmd: "python3 -m app.cli --help", note: "等价入口：两条入口的 --help 输出一致" },
    ],
    examples: [
      { cmd: "./rp --db /tmp/ruleproof.db init", note: "初始化临时演练库（不碰生产库）" },
      { cmd: "./rp --db /tmp/ruleproof.db --user <平台账号> tenant list", note: "平台层：查看租户列表；尖括号 <…> 为占位符，复制后请替换" },
      { cmd: "./rp --db /tmp/ruleproof.db --tenant t-default --ws ws-default --user <平台账号> tenant admin-list --tenant-id <租户ID>", note: "平台层：查看指定租户的管理员（--tenant/--ws 为全局参数）" },
      { cmd: "./rp --db /tmp/ruleproof.db --user <平台账号> version", note: "查看版本、Python 与当前数据库路径（JSON）" },
    ],
    params: [
      ["--db", "SQLite 路径（默认 RULEPROOF_DB）"],
      ["--tenant", "租户（默认 t-default）"],
      ["--ws", "工作空间（默认 ws-default）"],
      ["--user", "操作身份：用户 id / 手机号 / 用户名（默认 RULEPROOF_CLI_USER，未设置则 user-admin）"],
    ],
    outputs: [
      "成功：stdout 输出单个 JSON，便于脚本/自动化处理。",
      "失败：stderr 输出可机读 JSON，进程退出码非 0；无权限 status=403（POSIX 退出码取模，脚本按 status 识别），参数错误退出码 2。",
      "无权限返回 403，不静默成功；写操作记录审计日志。",
      "CLI 与 HTTP API 共用服务层、权限、数据库与审计；不依赖 Web 页面即可完成核心链路。",
    ],
    safety: [
      "本区块只读展示/复制命令，不执行任意命令：没有命令输入框、运行按钮或服务端命令浏览接口（不开放 RCE）。",
      "仅平台管理员（platform_op）可见；其他角色不显示本区块，平台接口对非平台身份返回 403。",
      "不展示任何密钥/凭据；演练请用 --db 指向临时库，不要把生产库路径或账号口令写入截图。",
      "运维看板仍仅系统管理员可用，本入口不恢复运维快捷入口。",
    ],
  };
  // 2026-11-19：CLI 独立菜单——全部 45 个子命令按域分组（静态表；
  // scripts/qa/platform_cli_menu_test.py 会比对 app.cli.build_parser() 防漂移）
  const CLI_ALL = [["初始化与运行", [["init", "初始化数据库与种子"], ["serve", "启动 HTTP 服务"], ["version", "版本信息"], ["doctor", "CLI 环境自检"], ["db", "数据库"], ["gate", "运行构建门禁"]]], ["工作空间与租户", [["ws", "工作空间"], ["tenant", "平台租户治理"], ["user", "账号"]]], ["规则与决策", [["rule", "规则（新建后可 draft→published 直接发布，无需审批；submit/approve 为旧流程 legacy 兼容）"], ["decision", "决策表"], ["conflict-check", "冲突检测状态：run=全量检测并落状态 / status=最近记录"], ["evolution", "规则进化：历史回放/效果趋势/回滚建议"], ["rule-tag", "规则分组标签：list/create/rename/delete/assign/unassign/full-audit（组织分组，与 HTTP /api/v1/rules/tags 同源，不影响 manifest 路由）"]]], ["本体系", [["ontology", "本体建模"], ["terms", "企业业务词典：查看/维护/确认/迁移"]]], ["审核主链", [["doc", "解析文档"], ["kie", "关键信息抽取"], ["audit", "跑一次审核"], ["manifest", "审核清单"], ["point", "点位模板确认"], ["project", "项目"], ["task", "异步任务"], ["resolve", "统一 kind + id 解析（含二级 ID）"]]], ["发现与复核", [["finding", "发现"], ["extra", "Extra 人工复核"], ["human-review", "人工复核闭环（展示项 100%% 复核/漏报对账/报告门禁）"], ["hidden-item", "人工‘显示隐藏疑似问题 (N)’开关：list/裁决/恢复/指标/复核模式/进化池"], ["evidence", "补证事项"], ["exception", "对象级例外授权（unknown 逐项接受，禁止批量）"]]], ["台账与交付物", [["ledger", "审核台账：旧对象级 --case/--batch；T-50 抑制台账 list/recover"], ["adjudication-ledger", "裁决来源台账（L80 P0-C / 89 号规格）：stats=四类互斥统计+模型抽取占比+路由三列；export=逐行CSV/JSON+stats+SHA256SUMS；与 HTTP /api/v1/*/adjudication-stats、/adjudication-ledger 同源（开关 RULEPROOF_ADJUDICATION_LEDGER 默认 0）"], ["artifacts", "四件语义交付物导出"], ["semantic", "确定性语义闭环：结构化根因 / 同案例重审"]]], ["报告与导出", [["report", "导出报告"], ["export", "数据导出（CSV，与 HTTP export 同源）"], ["auditlog", "审计日志（只读）"], ["notifications", "站内消息"]]], ["模型与智能体", [["model", "模型"], ["agent", "智能体（全系统）"]]], ["开放平台与策略", [["open", "开放平台"], ["data-policy", "数据边界策略：状态/配置/删除预览/删除执行"], ["notify-config", "消息事件/可见角色配置"], ["visibility", "可见性策略应用状态；与 /api/v1/visibility 同源"]]], ["双轨与漏报", [["direct-draft", "直连草稿（不可变原始输出）列表/详情；与 /api/v1/direct-drafts 同源"], ["compare", "双轨四桶差异列表/详情；与 /api/v1/comparisons 同源"], ["omission", "人工漏报 add/list；与 /api/v1/human-omissions 同源"]]], ["影子池（三区仲裁）", [["shadow", "影子池：list（默认只给 N）/reveal（二次确认+审计）/decide（四动作）/metrics/export（admin 才可）/escalate（系统动作）；与 /api/v1/projects/{cid}/shadow-items* 同源"], ["knowledge", "知识库：目录/文件列表、上传、重命名/移动、软删/回收站/恢复/彻底删除（与 /api/v1/knowledge 同源）"]]]];
  const CLI_MANUAL_PATH = "docs/CLI手册.md";

  function cliCopy(text) {
    return new Promise((resolve, reject) => {
      const fallback = () => {
        try {
          const ta = document.createElement("textarea");
          ta.value = text; ta.setAttribute("readonly", "");
          ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
          document.body.appendChild(ta); ta.select();
          const ok = typeof document.execCommand === "function" && document.execCommand("copy");
          document.body.removeChild(ta);
          if (ok) resolve(); else reject(new Error("copy blocked"));
        } catch (e) { reject(e); }
      };
      if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
        navigator.clipboard.writeText(text).then(resolve, fallback);
      } else fallback();
    });
  }

  function cliCmdRow(item) {
    const note = item.note ? `<div class="pf-cli-cmd-note">${esc(item.note)}</div>` : "";
    return `<div class="pf-cli-cmd"><code>${esc(item.cmd)}</code><button class="pf-btn" type="button" data-cli-copy="${esc(item.cmd)}" aria-label="复制命令：${esc(item.cmd)}">复制</button>${note}</div>`;
  }

  function renderCliEntry() {
    const host = $("#pf-cli-entry");
    if (!host || host.dataset.ready === "1") return;
    host.innerHTML = `<div id="pf-cli-body">
      <div class="pf-cli-head"><div><h2>CLI / 命令行入口</h2><div class="hint">原生 CLI 是平台一等入口：与 HTTP API 共用同一套服务层、权限与数据；本区块只展示/复制命令，不执行命令。</div></div><span class="pf-cli-badge">只读 · 不执行命令</span></div>
      <div class="pf-cli-sec"><h3>入口</h3>${CLI_ENTRY.help.map(cliCmdRow).join("")}</div>
      <div class="pf-cli-sec"><h3>平台管理员常用命令</h3>${CLI_ENTRY.examples.map(cliCmdRow).join("")}</div>
      <div class="pf-cli-sec"><h3>全部命令（${CLI_ALL.reduce((n, g) => n + g[1].length, 0)} 个 · 按域分组）</h3>
        ${CLI_ALL.map(([g, items]) => `<div class="pf-cli-group"><div class="pf-cli-group-h">${esc(g)}<span class="muted">${items.length}</span></div>` +
          items.map(([cmd, note]) => `<div class="pf-cli-cmd"><code>./rp ${esc(cmd)} --help</code><button class="pf-btn" type="button" data-cli-copy="./rp ${esc(cmd)} --help" aria-label="复制命令">复制</button>${note ? `<div class="pf-cli-cmd-note">${esc(note)}</div>` : ""}</div>`).join("") + `</div>`).join("")}
      </div>
      <div class="pf-cli-sec"><h3>全局参数（任意命令前可用）</h3>
        <table class="pf-cli-kv"><thead><tr><th>参数</th><th>说明</th></tr></thead><tbody>${CLI_ENTRY.params.map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join("")}</tbody></table></div>
      <div class="pf-cli-sec"><h3>输出与退出码</h3><ul class="pf-cli-list">${CLI_ENTRY.outputs.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>
      <div class="pf-cli-sec"><h3>权限与安全边界</h3><ul class="pf-cli-list">${CLI_ENTRY.safety.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>
      <div class="pf-cli-sec"><h3>文档</h3><p>完整命令手册在交付包内：<span class="pf-cli-path">${esc(CLI_MANUAL_PATH)}</span>（本页只读，不提供编辑或执行入口）。</p></div>
    </div>`;
    host.querySelectorAll("[data-cli-copy]").forEach(b => {
      b.onclick = () => {
        cliCopy(b.dataset.cliCopy || "")
          .then(() => toast("命令已复制"))
          .catch(() => toast("复制失败，请手动选择命令文本", "err"));
      };
    });
    host.dataset.ready = "1";
    host.hidden = false;
  }

  async function boot() {
    document.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => tab(b.dataset.tab));
    $("#pf-top-messages").onclick = () => tab("messages");
    document.querySelectorAll("[data-close]").forEach(b => b.onclick = () => { const el = $("#" + b.dataset.close); if (el) el.hidden = true; });
    $("#ov-refresh").onclick = () => loadTenants().then(() => toast("平台概览已刷新")).catch(e => toast(e.message, "err"));
    const _archRefresh = $("#arch-refresh");
    if (_archRefresh) _archRefresh.onclick = () => {
      if (archOpenId) { history.replaceState(null, "", "#architecture"); restoreArchLibrary({ keepScroll: true }); }
      archLoaded = false;
      loadArchitecture().then(() => toast("架构图已刷新")).catch(e => toast(e.message, "err"));
    };
    // 内嵌查看器事件：iframe 高度自适应、返回键、重试、浏览器后退/前进、Esc
    const _frame = $("#arch-frame");
    if (_frame) _frame.addEventListener("load", () => {
      if (!archOpenId) return;
      _frame.dataset.loaded = _frame.dataset.archSrc || "1";
      const err = $("#arch-verr"); if (err) err.hidden = true;
      fitArchFrame(); setTimeout(fitArchFrame, 150);
    });
    const _archBack = $("#arch-back");
    if (_archBack) _archBack.onclick = backToArchLibrary;
    const _archRetry = $("#arch-vretry");
    if (_archRetry) _archRetry.onclick = () => {
      const frame = $("#arch-frame");
      if (!frame || !frame.dataset.archSrc || !archOpenId) return;
      const err = $("#arch-verr"); if (err) err.hidden = true;
      frame.dataset.loaded = "";
      loadArchFrameDocument(frame.dataset.archSrc);
    };
    const _archFallbackBack = $("#arch-vfallback-back");
    if (_archFallbackBack) _archFallbackBack.onclick = backToArchLibrary;
    window.addEventListener("popstate", syncArchFromLocation);
    window.addEventListener("hashchange", syncArchFromLocation);
    window.addEventListener("resize", () => { if (archOpenId) scheduleArchFit(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && archOpenId) { e.preventDefault(); backToArchLibrary(); } });
    $("#te-save").onclick = async function () {
      const btn = this;
      await busy(btn, "保存中", async () => {
        try {
          await api("/api/v1/platform/tenants/update", { method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: tenantId, name: $("#te-name").value.trim(), edition: $("#te-edition").value, expires_at: $("#te-expires").value }) });
          $("#pf-tenant").hidden = true; toast("租户已保存"); await loadTenants();
        } catch (e) { toast("保存失败：" + e.message, "err"); }
      });
    };
    try {
      const me = await api("/api/v1/me");
      const u = me.user || {};
      if (u.role !== "platform_op") {
        $("#console").hidden = true; $("#login-tip").hidden = false; return;
      }
      $("#who").textContent = u.name || u.username || "平台管理员";
      $("#pf-who-role").textContent = "平台管理员";
      // 与共享端 E2E/辅助脚本的只读契约对齐：平台端也暴露当前角色（不参与权限判断）。
      window.currentRole = "platform_op";
      $("#login-tip").hidden = true; $("#console").hidden = false;
      // T-101：CLI 统一入口卡仅在 platform_op 身份校验通过后解锁渲染（fail-closed）。
      renderCliEntry();
      await loadTenants();
      try { await loadOperators(); } catch (e) { /* platform account list may be restricted */ }
      // 刷新/直开 #architecture/<id> 时恢复当前图；否则默认首页
      if (/^#architecture/.test(location.hash || "")) { await tab("architecture"); }
      else { tab("home"); }
    } catch (e) {
      $("#console").hidden = true; $("#login-tip").hidden = false;
      $("#who").textContent = "未登录";
    }
  }

  $("#a-refresh").onclick = () => loadOperators().then(() => toast("平台管理员已刷新"));
  boot();
})();
