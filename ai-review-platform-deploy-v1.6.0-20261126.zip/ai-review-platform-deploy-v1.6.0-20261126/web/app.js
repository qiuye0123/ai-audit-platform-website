const $ = (s) => document.querySelector(s);
// 加载顺序跳板：rule_file_intake.js 在 new_rule_view.js 之后加载，而后者在加载期就
// 直接引用 renderNewRuleFile 注册“上传拆解”。先提供可调用的占位，避免 ReferenceError
// 中断它后续的页签/按钮绑定；DOMContentLoaded 后再把真正实现接上。
window.renderNewRuleFile = function () {
  const impl = window.__renderNewRuleFileImpl;
  if (typeof impl === "function") return impl.apply(this, arguments);
};
document.addEventListener("DOMContentLoaded", function () {
  if (typeof window.renderNewRuleFile === "function") {
    window.__renderNewRuleFileImpl = window.renderNewRuleFile;
  }
});
// 兼容层：项目详情里的点位失效检查误用 GET，而后端该端点只接受 POST；
// 在 project_detail_view.js 修正前，仅对这一条路径把 GET 提升为 POST，避免详情页每次都打 404。
(function normalizePointStaleMethod() {
  if (typeof window.fetch !== "function") return;
  const originalFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    try {
      if (typeof input !== "string" && !(input instanceof URL)) return originalFetch(input, init);
      const raw = String(input);
      const method = String((init && init.method) || "GET").toUpperCase();
      if (method === "GET" && /^\/api\/v1\/projects\/[^/]+\/point-stale(?:\?|$)/.test(raw)) {
        const next = Object.assign({}, init || {}, { method: "POST" });
        const headers = new Headers((init && init.headers) || {});
        if (!headers.has("Content-Type")) headers.set("Content-Type", "application/json");
        next.headers = headers;
        if (!Object.prototype.hasOwnProperty.call(next, "body")) next.body = "{}";
        return originalFetch(input, next);
      }
    } catch (e) { /* 保持原始 fetch 行为 */ }
    return originalFetch(input, init);
  };
})();
// 报告预览抽屉：HTML 里只保留了空占位（div#report-drawer / div#drawer-frame），
// workbench_report.js 会直接给 #drawer-frame 设 src。这里在脚本加载期把占位替换成
// 真正的抽屉结构（iframe + 关闭/下载），避免“查看报告”只弹出一个空白 div。
(function ensureReportDrawerDom() {
  const mask = document.getElementById("report-drawer");
  if (!mask || mask.querySelector("#drawer-frame")) return;
  ["drawer-close", "drawer-download", "drawer-frame"].forEach((id) => {
    const legacy = document.getElementById(id);
    if (legacy) legacy.remove();
  });
  mask.className = "drawer-mask";
  mask.innerHTML = '<div class="drawer"><div class="drawer-head"><h3>审核报告</h3>' +
    '<div class="actions"><a id="drawer-download" class="btn" href="#">下载 DOCX</a>' +
    '<button type="button" class="ws-close" id="drawer-close" aria-label="关闭报告">×</button></div></div>' +
    '<iframe id="drawer-frame" title="审核报告预览"></iframe></div>';
  // P1-3（T-198）：占位 div 原本嵌在 #auto-placeholders[hidden] 内，父容器 display:none
  // 导致抽屉 hidden=false 时 offsetWidth 仍为 0（用户点「查看报告」看不到任何东西）。
  // 挂到 document.body 脱离隐藏祖先，抽屉才能真实可见。
  if (mask.parentElement !== document.body) document.body.appendChild(mask);
})();
function showToast(msg, type) {
  const el = document.querySelector("#app-toast");
  if (!el) { return; }
  el.textContent = msg || "";
  el.className = "app-toast " + (type || "ok");
  el.hidden = false;
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => { el.hidden = true; }, 3200);
}
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* T-168/E-11：统一服务端失败判定（系统性问题：只判 r.error 会把 {ok:false,reason} 当成功）。
   后端有两套错误契约：
   ① 历史 {error, code}（_err() 返回，HTTP 4xx/5xx）；
   ② {ok:false, reason}（服务层直接返回 dict 后 _send(400)，如本体手工术语添加 / 发布校验阻断）。
   apiFail(r) 返回失败文案（成功返回空串），调用方统一写：
     const _af = apiFail(r); if (_af) { 显示 _af 并 return; }
   注意：成功响应里也可能带 reason（如自动发现 {ok:true, started:false, reason}），不算失败。 */
function apiFail(r) {
  if (!r || typeof r !== "object") return "请求失败：响应格式非法";
  if (r.ok === false) return String(r.reason || r.error || "操作失败");
  if (r.error) return String(r.error);
  return "";
}


/* ===================== 全局 UX 统一层 =====================
 * 1. loading / 空态：统一文案 + 骨架 + 文案/操作
 * 2. dirty：主要新建/编辑视图离开提醒（惰性基线，不做无改动拦截）
 * 3. 筛选回显：统一 localStorage（不改变任何 API 契约）
 * 4. 模态/抽屉：Esc 关闭 + 首次焦点 + 关闭还原
 * 5. 移动端导航：<=768 侧栏抽屉
 * 6. 批量结果摘要：成功 N / 失败 M / 跳过 K，失败可展开
 * 所有能力都只做增量包装，不改现有业务数据流。
 */
const UX_FILTER_STORE_KEY = "rp.ux.filters.v1";

function uxLoadingHTML(text, rows) {
  const n = Math.max(1, Math.min(6, Number(rows) || 3));
  return `<div class="ux-loading" role="status" aria-live="polite" aria-busy="true">
    <span class="ux-spinner" aria-hidden="true"></span><span class="ux-loading-text">${esc(text || "加载中…")}</span>
  </div><div class="ux-skeleton" aria-hidden="true">${Array.from({ length: n }, () => '<span class="ux-skel-row"></span>').join("")}</div>`;
}
function uxEmptyHTML(opts) {
  opts = opts || {};
  const title = opts.title || "暂无数据";
  const desc = opts.desc || "";
  const action = opts.action && opts.action.label ? opts.action : null;
  return `<div class="empty ux-empty" role="status" aria-live="polite">
    ${opts.icon ? `<div class="ux-empty-icon" aria-hidden="true">${esc(opts.icon)}</div>` : ""}
    <div class="ux-empty-title">${esc(title)}</div>
    ${desc ? `<div class="ux-empty-desc">${esc(desc)}</div>` : ""}
    ${action ? `<div class="ux-empty-actions"><button type="button" class="btn ${action.primary === false ? "" : "primary"}" data-empty-action="${esc(action.action || "")}">${esc(action.label)}</button></div>` : ""}
  </div>`;
}
function uxSetLoading(target, text, rows) {
  const el = typeof target === "string" ? document.querySelector(target) : target;
  if (!el) return false;
  el.innerHTML = uxLoadingHTML(text, rows);
  return true;
}
function uxSetEmpty(target, opts) {
  const el = typeof target === "string" ? document.querySelector(target) : target;
  if (!el) return false;
  el.innerHTML = uxEmptyHTML(opts);
  el.removeAttribute("aria-busy");
  return true;
}

/* ---------- dirty：主要新建/编辑视图 ---------- */
const UX_DIRTY_VIEWS = Object.create(null);
const UX_VIEW_LABELS = { newproject: "新建项目", newrule: "新建规则", notifyconfig: "通知配置" };
let uxDirtyPromptPending = false;

function uxDirtyRegister(viewId, opts) {
  if (!viewId || UX_DIRTY_VIEWS[viewId]) return false;
  UX_DIRTY_VIEWS[viewId] = {
    root: (opts && opts.root) || (() => document.getElementById("view-" + viewId)),
    extra: (opts && opts.extra) || null,
    baseline: null,
    dirty: false,
  };
  return true;
}
function uxDirtySignature(viewId) {
  const state = UX_DIRTY_VIEWS[viewId];
  if (!state) return "";
  const root = state.root();
  if (!root) return "";
  const parts = [];
  root.querySelectorAll("input, select, textarea").forEach((el, i) => {
    if (el.disabled || el.closest("[data-ux-dirty-ignore]")) return;
    const type = String(el.type || "").toLowerCase();
    if (type === "file" || type === "password") return;
    const key = el.id || el.name || (el.tagName + ":" + i);
    // 仅记录“有值/被选中”的字段：切换表单内部页签新增的空字段不应被误判为未保存修改。
    if (type === "checkbox" || type === "radio") {
      if (el.checked) parts.push(key + "=1");
    } else {
      const value = String(el.value == null ? "" : el.value);
      if (value !== "") parts.push(key + "=" + value);
    }
  });
  if (typeof state.extra === "function") parts.push("extra=" + String(state.extra() || ""));
  return parts.join("\u0001");
}
function uxDirtyCapture(viewId) {
  const state = UX_DIRTY_VIEWS[viewId];
  if (!state) return;
  state.baseline = uxDirtySignature(viewId);
  state.dirty = false;
}
function uxDirtyClear(viewId) { uxDirtyCapture(viewId); }
function uxDirtyReset(viewId) {
  const state = UX_DIRTY_VIEWS[viewId];
  if (!state) return;
  state.baseline = null;
  state.dirty = false;
}
function uxDirtyIsDirty(viewId) {
  const state = UX_DIRTY_VIEWS[viewId];
  if (!state || state.baseline == null) return false;
  return state.dirty || uxDirtySignature(viewId) !== state.baseline;
}
function uxDirtyOwner(el) {
  if (!el || !el.closest) return "";
  for (const viewId of Object.keys(UX_DIRTY_VIEWS)) {
    const state = UX_DIRTY_VIEWS[viewId];
    const root = state.root();
    if (root && root.contains(el)) return viewId;
  }
  return "";
}
function uxDirtyTouch(el) {
  const viewId = uxDirtyOwner(el);
  const state = UX_DIRTY_VIEWS[viewId];
  if (!state) return;
  if (state.baseline == null) {
    uxDirtyCapture(viewId);
    state.dirty = true;
  } else {
    state.dirty = uxDirtySignature(viewId) !== state.baseline;
  }
}
function uxConfirmDiscard(viewId, actionLabel) {
  if (!uxDirtyIsDirty(viewId)) return Promise.resolve(true);
  if (uxDirtyPromptPending) return Promise.resolve(false);
  if (typeof confirmAction !== "function") return Promise.resolve(true);
  uxDirtyPromptPending = true;
  const label = UX_VIEW_LABELS[viewId] || "当前页面";
  return confirmAction(
    "未保存的修改",
    label + "有尚未保存的修改，" + (actionLabel || "离开") + "后将丢失。确定要放弃这些修改吗？",
    "放弃修改",
    true,
  ).then((ok) => {
    uxDirtyPromptPending = false;
    if (ok) uxDirtyClear(viewId);
    return !!ok;
  }).catch(() => {
    uxDirtyPromptPending = false;
    return false;
  });
}
function uxBeforeViewChange(targetView) {
  if (!targetView || targetView === currentView) return true;
  if (!UX_DIRTY_VIEWS[currentView]) return true;
  if (!uxDirtyIsDirty(currentView)) return true;
  return uxConfirmDiscard(currentView, "切换页面");
}
function uxDirtyInit() {
  if (uxDirtyInit.__done) return;
  uxDirtyInit.__done = true;
  uxDirtyRegister("newproject", {
    root: () => document.querySelector("#view-newproject"),
    extra: () => (document.querySelector("#np-files") && document.querySelector("#np-files").textContent) || "",
  });
  uxDirtyRegister("newrule", { root: () => document.querySelector("#view-newrule") });
  uxDirtyRegister("notifyconfig", { root: () => document.querySelector("#view-notifyconfig") });
  const maybeCapture = (target) => {
    const viewId = uxDirtyOwner(target);
    const state = UX_DIRTY_VIEWS[viewId];
    if (state && state.baseline == null) uxDirtyCapture(viewId);
  };
  document.addEventListener("pointerdown", (e) => maybeCapture(e.target), true);
  document.addEventListener("focusin", (e) => maybeCapture(e.target), true);
  const onField = (e) => {
    if (!e.target || !e.target.matches || !e.target.matches("input, select, textarea")) return;
    uxDirtyTouch(e.target);
  };
  document.addEventListener("input", onField, true);
  document.addEventListener("change", onField, true);
  document.addEventListener("drop", (e) => {
    const viewId = uxDirtyOwner(e.target);
    if (!viewId) return;
    uxDirtyCapture(viewId);
    const state = UX_DIRTY_VIEWS[viewId];
    if (state) state.dirty = true;
  }, true);
  window.addEventListener("beforeunload", (e) => {
    const dirty = Object.keys(UX_DIRTY_VIEWS).some((viewId) => uxDirtyIsDirty(viewId));
    if (!dirty) return;
    e.preventDefault();
    e.returnValue = "";
  });
}

/* ---------- 筛选条件回显（localStorage，统一方案） ---------- */
const UX_FILTER_FIELDS = {
  projects: ["pl-q", "pl-status", "pl-space", "pl-from", "pl-to"],
  rules: ["rule-q", "rule-src", "rule-status", "rule-form", "rule-cat", "rule-risk", "rule-exec", "rule-map", "rule-owner"],
  drafts: ["draft-q", "draft-form", "draft-ready"],
  myaudits: ["ma-q", "ma-status", "ma-from", "ma-to"],
  users: ["user-q", "user-role", "user-status"],
  auditlogs: ["al-q", "al-action", "al-result", "al-from", "al-to"],
};
const UX_FILTER_OWNER = (() => {
  const out = {};
  Object.keys(UX_FILTER_FIELDS).forEach((view) => UX_FILTER_FIELDS[view].forEach((id) => { out[id] = view; }));
  return out;
})();
function uxFiltersReadAll() {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(UX_FILTER_STORE_KEY);
    const data = raw ? JSON.parse(raw) : {};
    return data && typeof data === "object" ? data : {};
  } catch (e) { return {}; }
}
function uxFiltersWriteAll(data) {
  if (typeof localStorage === "undefined") return;
  try { localStorage.setItem(UX_FILTER_STORE_KEY, JSON.stringify(data || {})); } catch (e) { /* 隐私模式不阻断业务 */ }
}
function uxFiltersSave(viewId, fieldId, value) {
  if (!UX_FILTER_FIELDS[viewId] || UX_FILTER_FIELDS[viewId].indexOf(fieldId) < 0) return;
  const all = uxFiltersReadAll();
  all[viewId] = all[viewId] || {};
  if (value === "" || value == null) delete all[viewId][fieldId];
  else all[viewId][fieldId] = String(value);
  if (!Object.keys(all[viewId]).length) delete all[viewId];
  uxFiltersWriteAll(all);
}
const UX_FILTER_RESTORED = Object.create(null);
function uxFiltersRestore(viewId) {
  const fields = UX_FILTER_FIELDS[viewId];
  if (!fields) return false;
  UX_FILTER_RESTORED[viewId] = true;
  const saved = (uxFiltersReadAll()[viewId]) || {};
  fields.forEach((fieldId) => {
    const el = document.getElementById(fieldId);
    if (!el || !Object.prototype.hasOwnProperty.call(saved, fieldId)) return;
    const value = String(saved[fieldId] == null ? "" : saved[fieldId]);
    if (el.tagName === "SELECT" && value && ![...el.options].some((o) => o.value === value)) {
      el.dataset.uxPending = value;
      return;
    }
    if (el.value !== value) el.value = value;
    delete el.dataset.uxPending;
  });
  return true;
}
function uxFiltersReset(viewId) {
  const fields = UX_FILTER_FIELDS[viewId] || [];
  fields.forEach((fieldId) => {
    const el = document.getElementById(fieldId);
    if (!el) return;
    el.value = "";
    delete el.dataset.uxPending;
  });
  const all = uxFiltersReadAll();
  delete all[viewId];
  uxFiltersWriteAll(all);
  UX_FILTER_RESTORED[viewId] = true;
}
function uxFiltersRestoreOnce(viewId) {
  if (UX_FILTER_RESTORED[viewId]) return false;
  return uxFiltersRestore(viewId);
}
function uxFilterInit() {
  if (uxFilterInit.__done) return;
  uxFilterInit.__done = true;
  const save = (e) => {
    const el = e.target;
    if (!el || !el.id || !UX_FILTER_OWNER[el.id]) return;
    uxFiltersSave(UX_FILTER_OWNER[el.id], el.id, el.value);
  };
  document.addEventListener("input", save, true);
  document.addEventListener("change", save, true);
}
const UX_FILTER_RELOAD = {
  projects: () => { if (typeof loadProjects === "function") loadProjects(1); },
  rules: () => { rulePage = 1; if (typeof renderList === "function") renderList(); },
  users: () => { if (typeof loadUsers === "function") loadUsers(true); },
  auditlogs: () => { if (typeof loadAuditLogsPaged === "function") loadAuditLogsPaged(true); },
  myaudits: () => { if (typeof loadMyAudits === "function") loadMyAudits(1); },
};

/* ---------- 工作台“发现”筛选（沿用同一 localStorage） ---------- */
function uxWorkbenchFiltersRestore() {
  const saved = (uxFiltersReadAll().workbench) || {};
  if (saved.reviewed === "all" || saved.reviewed === "pending") wbReviewed = saved.reviewed;
  if (saved.sev === "critical" || saved.sev === "warning" || saved.sev === "suspected") wbSev = saved.sev;
  const revSel = document.querySelector("#wb-f-rev");
  if (revSel && wbReviewed) revSel.value = wbReviewed;
  const sevSel = document.querySelector("#wb-f-sev");
  if (sevSel) sevSel.value = wbSev || "";
}
function uxWorkbenchFiltersSave() {
  const all = uxFiltersReadAll();
  all.workbench = { reviewed: wbReviewed || "", sev: wbSev || "" };
  uxFiltersWriteAll(all);
}

/* ---------- 空态操作委托 ---------- */
function uxEmptyAction(action) {
  if (!action) return;
  if (action.indexOf("view:") === 0) { showView(action.slice(5)); return; }
  if (action.indexOf("reset:") === 0) {
    const viewId = action.slice(6);
    uxFiltersReset(viewId);
    const reload = UX_FILTER_RELOAD[viewId];
    if (typeof reload === "function") reload();
    return;
  }
  // L51 规则分组：空态里清掉分组筛选（分组不在 localStorage 筛选里，需显式清）
  if (action === "cleartag:rules") { if (typeof resetRuleTagFilter === "function") resetRuleTagFilter("rules"); return; }
  if (action === "cleartag:drafts") { if (typeof resetRuleTagFilter === "function") resetRuleTagFilter("drafts"); return; }
  if (action === "reload:page") { window.location.reload(); return; }
  if (action === "wb:all") { wbReviewed = "all"; uxWorkbenchFiltersSave(); renderWbTab(); renderWbFindings(); return; }
  if (action === "wb:pending") { wbReviewed = "pending"; uxWorkbenchFiltersSave(); renderWbTab(); renderWbFindings(); }
}

/* ---------- 批量结果摘要 ---------- */
function uxBatchSummaryHTML(opts) {
  opts = opts || {};
  const success = Math.max(0, parseInt(opts.success || 0, 10) || 0);
  const failed = Math.max(0, parseInt(opts.failed || 0, 10) || 0);
  const skipped = Math.max(0, parseInt(opts.skipped || 0, 10) || 0);
  const failures = Array.isArray(opts.failures) ? opts.failures : [];
  const skippedItems = Array.isArray(opts.skippedItems) ? opts.skippedItems : [];
  const rows = [];
  failures.slice(0, 50).forEach((x) => {
    rows.push(`<li><b>失败</b> ${esc((x && (x.name || x.title || x.id)) || "未命名项")}${x && x.reason ? "：" + esc(x.reason) : ""}</li>`);
  });
  skippedItems.slice(0, 50).forEach((x) => {
    rows.push(`<li><b>跳过</b> ${esc((x && (x.name || x.title || x.id)) || String(x || "未命名项"))}${x && x.reason ? "：" + esc(x.reason) : ""}</li>`);
  });
  const detail = rows.length
    ? `<details class="ux-batch-detail"><summary>展开失败/跳过明细（${rows.length} 项）</summary><ul>${rows.join("")}</ul></details>`
    : "";
  return `<div class="ux-batch-summary" role="status" aria-live="polite">
    <div class="ux-batch-head"><b>${esc(opts.title || "批量操作完成")}</b><span class="ux-batch-counts">成功 ${success} / 失败 ${failed} / 跳过 ${skipped}</span></div>
    ${detail}
  </div>`;
}
function showBatchSummary(opts) {
  opts = opts || {};
  const old = document.querySelector("#ux-batch-toast");
  if (old) old.remove();
  const box = document.createElement("div");
  box.id = "ux-batch-toast";
  box.className = "ux-batch-toast";
  box.innerHTML = uxBatchSummaryHTML(opts) + '<button type="button" class="ux-batch-close" aria-label="关闭批量结果">×</button>';
  document.body.appendChild(box);
  const close = () => box.remove();
  box.querySelector(".ux-batch-close").onclick = close;
  const failed = Math.max(0, parseInt(opts.failed || 0, 10) || 0);
  // 统一由摘要面板承载结果，避免 toast 与摘要重复播报。
  window.setTimeout(() => { if (box.isConnected) box.remove(); }, failed ? 15000 : 8000);
  return box;
}

/* ---------- 模态/抽屉：Esc + 焦点管理 ---------- */
const UX_MODAL_SELECTOR = ".modal-mask, .ws-mask, .drawer-mask, .af-drawer, #pwd-form.pwd-dialog, #llm-replay.modal";
const UX_MODAL_STACK = [];
let uxModalScanQueued = false;
function uxElementVisible(el) {
  if (!el || el.hidden || !el.isConnected) return false;
  const cs = window.getComputedStyle(el);
  return cs.display !== "none" && cs.visibility !== "hidden" && el.getClientRects().length > 0;
}
function uxFocusable(root) {
  if (!root) return [];
  return [...root.querySelectorAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])')]
    .filter((el) => !el.disabled && el.getAttribute("aria-hidden") !== "true" && uxElementVisible(el));
}
function uxFocusFirst(root) {
  const items = uxFocusable(root);
  if (!items.length) {
    if (!root.hasAttribute("tabindex")) root.setAttribute("tabindex", "-1");
    try { root.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    return;
  }
  const preferred = items.find((el) => el.hasAttribute("autofocus"))
    || items.find((el) => /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName) && el.type !== "hidden")
    || items[0];
  try { preferred.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
}
function uxScanModals() {
  uxModalScanQueued = false;
  if (!document.body) return;
  const visible = [...document.querySelectorAll(UX_MODAL_SELECTOR)].filter(uxElementVisible);
  const removed = [];
  for (let i = UX_MODAL_STACK.length - 1; i >= 0; i--) {
    if (!visible.includes(UX_MODAL_STACK[i].el)) removed.push(UX_MODAL_STACK.splice(i, 1)[0]);
  }
  if (removed.length) {
    const target = removed[removed.length - 1].previousFocus;
    const restore = () => {
      if (target && target.isConnected && typeof target.focus === "function") {
        try { target.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
      } else if (UX_MODAL_STACK.length) {
        uxFocusFirst(UX_MODAL_STACK[UX_MODAL_STACK.length - 1].el);
      }
    };
    window.setTimeout(restore, 0);
  }
  for (const el of visible) {
    if (UX_MODAL_STACK.some((x) => x.el === el)) continue;
    const active = document.activeElement;
    const previousFocus = active && active !== document.body && !el.contains(active) ? active : null;
    UX_MODAL_STACK.push({ el, previousFocus });
    window.setTimeout(() => {
      if (!uxElementVisible(el)) return;
      if (UX_MODAL_STACK.length && UX_MODAL_STACK[UX_MODAL_STACK.length - 1].el === el) uxFocusFirst(el);
    }, 0);
  }
}
function uxQueueModalScan() {
  if (uxModalScanQueued) return;
  uxModalScanQueued = true;
  window.setTimeout(uxScanModals, 0);
}
function uxTopModal() {
  uxScanModals();
  for (let i = UX_MODAL_STACK.length - 1; i >= 0; i--) {
    if (uxElementVisible(UX_MODAL_STACK[i].el)) return UX_MODAL_STACK[i].el;
  }
  return null;
}
function uxFindCloseControl(root) {
  const pick = [...root.querySelectorAll('[data-cancel], .ws-close, [aria-label*="关闭"], [data-close]')].filter(uxElementVisible);
  if (pick.length) return pick[0];
  const byText = [...root.querySelectorAll("button, a.btn")].filter((el) =>
    uxElementVisible(el) && /^(取消|关闭|返回|×)$/.test(String(el.textContent || "").trim()));
  return byText[0] || null;
}
function uxCloseTopModal() {
  const el = uxTopModal();
  if (!el) return false;
  const target = uxFindCloseControl(el);
  if (target) { target.click(); return true; }
  if (el.id === "confirm-action-modal") { el.remove(); return true; }
  if (typeof el.hidden !== "undefined") el.hidden = true;
  else el.remove();
  uxQueueModalScan();
  return true;
}
function uxHasOpenModal() { return !!uxTopModal(); }
function uxModalInit() {
  if (uxModalInit.__done) return;
  uxModalInit.__done = true;
  uxScanModals();
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape" || e.defaultPrevented) return;
    if (uxCloseTopModal()) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Tab" || e.defaultPrevented) return;
    const top = uxTopModal();
    if (!top) return;
    const items = uxFocusable(top);
    if (!items.length) return;
    const first = items[0], last = items[items.length - 1];
    if (e.shiftKey && (document.activeElement === first || !top.contains(document.activeElement))) {
      e.preventDefault(); last.focus();
    } else if (!e.shiftKey && (document.activeElement === last || !top.contains(document.activeElement))) {
      e.preventDefault(); first.focus();
    }
  }, true);
  if (typeof MutationObserver !== "undefined") {
    new MutationObserver(uxQueueModalScan).observe(document.body, {
      childList: true, subtree: true, attributes: true, attributeFilter: ["hidden"],
    });
  }
}

/* ---------- 移动端导航（<=768px 抽屉；桌面完全保持原样） ---------- */
function uxInitMobileNav() {
  if (uxInitMobileNav.__done) return;
  const btn = document.getElementById("mobile-menu");
  const sidebar = document.querySelector(".sidebar");
  if (!btn || !sidebar) return;
  uxInitMobileNav.__done = true;
  const mq = window.matchMedia("(max-width: 768px)");
  let scrim = document.querySelector("#ux-sidebar-scrim");
  if (!scrim) {
    scrim = document.createElement("div");
    scrim.id = "ux-sidebar-scrim";
    scrim.className = "sidebar-scrim";
    scrim.hidden = true;
    document.body.appendChild(scrim);
  }
  let open = false;
  const sync = () => {
    if (!mq.matches) {
      open = false;
      sidebar.classList.remove("mobile-open");
      document.body.classList.remove("ux-nav-open");
      scrim.hidden = true;
      btn.setAttribute("aria-expanded", "false");
      btn.setAttribute("aria-label", "打开菜单");
      sidebar.removeAttribute("aria-hidden");
      return;
    }
    btn.setAttribute("aria-expanded", open ? "true" : "false");
    btn.setAttribute("aria-label", open ? "关闭菜单" : "打开菜单");
    sidebar.classList.toggle("mobile-open", open);
    sidebar.setAttribute("aria-hidden", open ? "false" : "true");
    document.body.classList.toggle("ux-nav-open", open);
    scrim.hidden = !open;
    scrim.classList.toggle("show", open);
  };
  const setOpen = (next, focusButton) => {
    if (!mq.matches) return;
    open = !!next;
    sync();
    if (!open && focusButton) { try { btn.focus({ preventScroll: true }); } catch (e) {} }
  };
  btn.addEventListener("click", () => setOpen(!open, false));
  scrim.addEventListener("click", () => setOpen(false, true));
  sidebar.addEventListener("click", (e) => {
    if (mq.matches && e.target.closest && e.target.closest(".menu-item")) setOpen(false, false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape" || !open || uxHasOpenModal()) return;
    e.preventDefault(); setOpen(false, true);
  }, true);
  mq.addEventListener ? mq.addEventListener("change", sync) : mq.addListener(sync);
  window.addEventListener("resize", sync);
  sync();
}

function uxInitGlobal() {
  if (uxInitGlobal.__done) return;
  uxInitGlobal.__done = true;
  uxDirtyInit();
  uxFilterInit();
  uxModalInit();
  uxInitMobileNav();
  document.addEventListener("click", (e) => {
    const btn = e.target.closest && e.target.closest("[data-empty-action]");
    if (!btn) return;
    e.preventDefault();
    uxEmptyAction(btn.dataset.emptyAction);
  });
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", uxInitGlobal, { once: true });
else uxInitGlobal();

// 判定模板（旧称“规则类型”）是规则“怎么判”的模板；全局唯一命名，禁止各页面自造类名
const RULE_TYPE_LABELS = {
  limit: "限值",
  consistency: "一致性",
  completeness: "完整性",
  format: "格式",
  preprocess: "前处理",
  record: "记录要求",
  prohibited: "禁止性",
  frequency: "时限/频率",
  personnel: "人员资质",
  equipment: "设备设施",
  label: "标识标签",
  citation: "引用一致",
  // 执行器专用模板（L79 registry：ruleexec 已有确定性执行器，只经 API/导入/编译路径进入，
  // 不在下方 RULE_TEMPLATES 新建表单里选择；这里只用于规则列表/详情的历史数据显示）。
  field_presence: "字段存在性",
  cross_relation: "跨文件关系",
};
const CATEGORY = RULE_TYPE_LABELS;
const STATUS = { draft: "草稿", pending: "待审批", published: "已发布", archived: "已下线" };
const RCLASS = { R0: "结构/存在", R1: "数值/参数", R2: "事实抽取", R3: "跨文档", R4: "语义/裁量", R5: "提示" };
const SEV_LABEL = { critical: "严重", warning: "一般", info: "提示", suspected: "提示" };
function riskLabel(rclass) {
  const _rc = String(rclass || "");
  return ["R0", "R1"].includes(_rc) ? "严重" : _rc === "R5" ? "提示" : "一般";
}
const PROJ_STATUS = { draft: "草稿", reviewing: "审核中", completed: "已完成", auditing: "审核中", audit_failed: "审核失败" };

let rules = [];
let rulePage = 1;
const RULE_PAGE_SIZE = 20;
let currentRole = null;
let currentView = "home";
// E-07（DuMate）：boot 窗口内用户可能已经主动点了菜单。currentView 初始值就是 "home"，
// 不能用它判断「是否已导航」；用显式标记，只在用户主动导航后置 true。
let _bootUserNavigated = false;
let homeAnalyticsDays = 30;
let currentProjectId = null;
// 页面状态提前声明，避免 showView 早于后续 let 初始化触发 TDZ
let npDocTypes = [];
let fbCache = [];
let ONTO_TAB = "types";
let evoTab = "all";

/* ===================== 规则库 ===================== */
async function runAudit() {
  if (!currentProjectId) return;
  $("#btn-run-audit").disabled = true; $("#btn-run-audit").textContent = "审核中…";
  try {
    const r = await (await fetch(`/api/v1/projects/${currentProjectId}/audit`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ai_assist: true }) })).json();
    const _af = apiFail(r);
    if (_af) { alert("审核失败：" + _af); return; }
    await openProject(currentProjectId);
  } finally { $("#btn-run-audit").disabled = false; $("#btn-run-audit").textContent = "运行审核"; }
}

/* ===================== 首页 ===================== */
const KPI_META = [
  [/规则/, "", "#F0F4FF", "#3370FF"],
  [/审批/, "⏳", "#FFF6E8", "#FF8800"],
  [/案例|项目/, "", "#F0F4FF", "#3370FF"],
  [/发现/, "", "#FFF0F0", "#F54A45"],
  [/待复核/, "", "#E8F8F0", "#00B578"],
  [/告警/, "", "#FFF0F0", "#F54A45"],
  [/未读/, "", "#FFF6E8", "#FF8800"],
  [/进行中/, "", "#F0F4FF", "#3370FF"],
  [/已复核/, "", "#E8F8F0", "#00B578"],
  [/^账号$/, "", "#F0F4FF", "#3370FF"],
  [/开放应用/, "", "#F0F4FF", "#3370FF"],
  [/回调/, "", "#FFF6E8", "#FF8800"],
  [/^智能体$/, "", "#F5F0FF", "#7B61FF"],
  [/审计日志/, "", "#F0F4FF", "#3370FF"],
  [/异常/, "", "#FFF0F0", "#F54A45"],
];
function kpiMeta(label) {
  for (const [re, ico, bg, color] of KPI_META) if (re.test(label || "")) return { ico, bg, color };
  return { ico: "", bg: "#F5F6F7", color: "#646A73" };
}

function renderSuperDashboard(d) {
  const host = document.querySelector("#home");
  if (!host) return;
  document.querySelector("#home-analytics")?.remove();
  let box = document.querySelector("#sys-dashboard");
  if (!box) { box = document.createElement("div"); box.id = "sys-dashboard"; host.appendChild(box); }
  const runs = d.agent_runs || [];
  const health = d.health || {}, hm = health.models || {}, hc = health.callbacks || {},
        ha = health.accounts || {}, hg = health.agents || {}, channels = health.channels || [];
  const sm = d.scope_meta || {};
  const scopeChip = (t) => `<span class="scope-chip">${esc(t || "")}</span>`;
  // 模型：四态，不用“已启用”冒充可用；调用量来自 llm_trace 真实记录。
  const modelRows = (d.model_rows || []).map(m => `<div class="it-row"><span>${esc(m.model || "—")}</span><b>${m.calls} 次 · ${m.tokens} tok</b></div>`).join("") || '<div class="empty" style="padding:18px 0">暂无模型调用记录</div>';
  // 智能体：按四态可用性聚合，“管理启用”单列。
  const avRows = (d.agents || []).map(a => {
    const cls = a.state === "ok" ? "published" : a.state === "fail" ? "r" : "draft";
    return `<div class="it-row" title="${esc(a.note || "")}"><span>${esc(a.name || a.id)} ${scopeChip(a.management || "")}</span><b><span class="pill ${cls}">${esc(a.label || "未配置")}</span></b></div>`;
  }).join("") || '<div class="empty" style="padding:18px 0">暂无智能体</div>';
  const ocr = d.ocr || {};
  const ocrLine = (x, name) => {
    if (!x) return `<span class="muted">${name}未预置</span>`;
    const cls = x.state === "ok" ? "published" : x.state === "fail" ? "r" : "draft";
    return `<span>${esc(x.name || name)} <span class="pill ${cls}">${esc(x.state_label || "未配置")}</span></span>`;
  };
  const channelRows = channels.map(c => `<div class="it-row"><span>${esc(c.name)}</span><b><span class="pill ${c.enabled ? "published" : "draft"}">${c.enabled ? "站内可用" : "未配置"}</span></b></div>`).join("") || '<div class="muted">暂无渠道信息</div>';
  const actions = [];
  if ((hm.unconfigured || 0) > 0) actions.push({label: "模型未配置", detail: `${hm.unconfigured} 个模型无凭据（未配置≠可用）`, view: "model", action: "去模型管理"});
  if ((hm.fail || 0) > 0) actions.push({label: "模型连接失败", detail: `${hm.fail} 个模型最近测试失败`, view: "model", action: "去模型管理"});
  if ((hm.configured || 0) > 0) actions.push({label: "模型待测试", detail: `${hm.configured} 个模型已配置凭据但未真实测试`, view: "model", action: "去模型管理"});
  if ((hc.failed || 0) > 0) actions.push({label: "开放回调失败", detail: `${hc.failed} 条投递失败`, view: "openplatform", action: "去开放平台"});
  if ((hc.pending || 0) > 0) actions.push({label: "回调待投递", detail: `${hc.pending} 条待处理`, view: "openplatform", action: "去开放平台"});
  if ((ha.must_change || 0) > 0) actions.push({label: "账号待改密", detail: `${ha.must_change} 个账号仍使用临时密码`, view: "users", action: "去账号列表"});
  if ((ha.disabled || 0) > 0) actions.push({label: "停用账号", detail: `${ha.disabled} 个账号已停用`, view: "users", action: "去账号列表"});

  const actionRows = actions.length ? actions.map(x => `<div class="it-action-row"><div><b>${esc(x.label)}</b><span>${esc(x.detail)}</span></div><button class="btn" data-sys-go="${esc(x.view)}">${esc(x.action)}</button></div>`).join("") : '<div class="empty" style="padding:18px 0">当前没有需要处理的 IT 事项</div>';
  const healthRows = `
    <div class="it-health-row"><span>模型接入 ${scopeChip("本租户")}</span><b>${hm.effective || 0}/${hm.total || 0} 连接正常</b><span class="muted">未配置 ${hm.unconfigured || 0} · 待测 ${hm.configured || 0} · 失败 ${hm.fail || 0}</span></div>
    <div class="it-health-row"><span>智能体可用性 ${scopeChip("四态")}</span><b>${hg.effective || 0}/${hg.total || 0} 可用</b><span class="muted">未配置 ${hg.unconfigured || 0} · 待测 ${hg.configured || 0} · 失败 ${hg.fail || 0}</span></div>
    <div class="it-health-row"><span>开放回调 ${scopeChip("本租户")}</span><b>${hc.pending || 0} 待投递</b><span class="muted">失败 ${hc.failed || 0}</span></div>
    <div class="it-health-row"><span>账号安全 ${scopeChip("本租户")}</span><b>${ha.active || 0} 启用</b><span class="muted">停用 ${ha.disabled || 0} · 待改密 ${ha.must_change || 0}</span></div>
    <div class="it-health-row"><span>最近错误</span><span class="muted" style="flex:1;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(hc.last_error || "")}">${esc(hc.last_error || "无")}</span></div>`;
  box.innerHTML = `<div class="it-dashboard">
    <div class="card"><div class="card-title">需要我处理 <span class="scope-chip">本租户 · 近 7 天异常</span></div><div class="it-action-list">${actionRows}</div></div>
    <div class="card"><div class="card-title">系统健康 ${scopeChip("真实记录")}</div>${healthRows}
      <div class="it-health-row"><span>OCR 主备 ${scopeChip("四态")}</span><span class="muted" style="flex:1;text-align:right">${ocrLine(ocr.primary, "Unlimited-OCR-2")} · ${ocrLine(ocr.backup, "PaddleOCR-VL")}</span></div>
      <div class="muted" style="font-size:11px;line-height:1.6;margin-top:4px">${esc((ocr.policy || ""))}</div></div>
    <div class="card"><div class="card-title">模型调用 ${scopeChip("本租户 · 全时间")}</div><div class="it-kpis"><div><b>${d.llm_total || 0}</b><span>累计调用</span></div><div><b>${d.llm_tokens || 0}</b><span>tokens</span></div><div><b>${d.llm_latency || 0}ms</b><span>平均延迟</span></div></div>${modelRows}
      <div class="muted" style="font-size:11px;line-height:1.6;margin-top:6px">口径：enabled 只是管理开关；未配置/已配置待测/连接失败都不算可用；调用量为 llm_trace 真实记录。</div></div>
    <div class="card"><div class="card-title">智能体可用性 ${scopeChip("四态")}</div><div class="it-kpis"><div><b>${hg.total || 0}</b><span>总数</span></div><div><b>${hg.enabled || 0}</b><span>管理启用</span></div><div><b>${runs.reduce((n, x) => n + (x || 0), 0)}</b><span>近 7 天运行</span></div></div>${avRows}
      <div class="muted" style="font-size:11px;line-height:1.6;margin-top:6px">${esc((hg.policy || ""))}</div></div>
    <div class="card"><div class="card-title">通知渠道</div>${channelRows}
      <div class="muted" style="font-size:11px;line-height:1.6;margin-top:6px">当前仅站内消息；通知配置页可测试发送并查看真实触发记录。</div></div>
  </div>
  <div class="muted" style="font-size:11px;line-height:1.7;margin:10px 2px 0">数据来源：${esc((sm.sources || []).join("、") || "当前库真实记录")}；时间窗：${esc(sm.window || "近 7 天/累计")}；${esc(sm.note || "")}</div>`;
  box.querySelectorAll("[data-sys-go]").forEach(b => b.addEventListener("click", () => showView(b.dataset.sysGo)));
}

async function renderHomeAnalytics() {
  if (!["admin", "reviewer"].includes(currentRole)) { document.querySelector("#home-analytics")?.remove(); return; }
  let host = document.getElementById("home-analytics");
  if (!host) {
    const home = document.getElementById("home");
    if (!home) return;
    host = document.createElement("div");
    host.id = "home-analytics";
    host.style.margin = "0 0 16px";
    const _grid = document.querySelector("#home-todo")?.closest(".card")?.parentElement;
    const _act = document.getElementById("home-activity-row");
    if (_grid) home.insertBefore(host, _grid);
    else if (_act) home.insertBefore(host, _act);
    else home.appendChild(host);
  }
  host.innerHTML = '<div class="muted">加载问题分析…</div>';
  const days = Math.max(1, parseInt(homeAnalyticsDays || 30, 10));
  let d;
  try { d = await (await fetch(`/api/v1/analytics/issues?days=${days}`)).json(); }
  catch (e) { host.innerHTML = `<div class="card"><div class="card-title">问题分析 · 近 ${days} 天</div><div class="empty">分析数据加载失败</div></div>`; return; }
  const _atitle = (currentRole === "reviewer" ? "审核列表" : "问题分析") + ` · 近 ${days} 天`;
  if (!d || d.error) { host.innerHTML = `<div class="card"><div class="card-title">${_atitle}</div><div class="empty">暂无可用分析数据</div></div>`; return; }
  const _cloudItems = (d.top_issues || d.top_rules || []).map(x => ({ title: x.title || x.code || "", count: Number(x.count || 0) })).filter(x => x.title && x.count > 0);
  const cloud = `<canvas id="issue-cloud" class="issue-cloud" role="img" aria-label="高频问题词云"></canvas>`;
  const recurring = (d.recurring || []).slice(0, 6).map(x =>
    `<div class="recurring-row"><span>${esc(x.title || x.code)}</span><b>${x.cases} 个项目</b></div>`).join("") ||
    '<div class="muted" style="font-size:12px">暂无跨项目重复问题</div>';
  const h = window.__homeData || {};
  const stats = h.stats || [];
  const sv = (label) => (stats.find(x => String(x.label || "").includes(label)) || {}).value;
  const todoProjects = (h.todo || []).filter(x => Number(x.pending_count || 0) > 0).slice(0, 4);
  const decisionHtml = ["reviewer", "admin"].includes(currentRole)
    ? `<div class="home-decision-row">
        <div class="home-decision-card"><div class="hdc-kicker">处理进度</div><div class="hdc-main"><b>${sv("待复核") || 0}</b><span>条发现待复核</span></div><div class="hdc-sub">已复核 ${sv("已复核") || 0} 条 · 进行中项目 ${sv("进行中项目") || 0} 个</div></div>
        <div class="home-decision-card"><div class="hdc-kicker">质量问题集中度</div><div class="hdc-main"><b>${d.findings || 0}</b><span>条问题 · ${d.cases || 0} 个项目</span></div><div class="hdc-sub">严重 ${(d.severity||{}).critical||0} · 一般 ${(d.severity||{}).warning||0} · 提示 ${(d.severity||{}).suspected||0}；优先处理严重项和跨项目重复问题。</div></div>
      </div>`
    : `<div class="home-decision-row">
        <div class="home-decision-card"><div class="hdc-kicker">需要我拍板</div><div class="hdc-stat-list"><span>历史待审批（旧流程） <b>${sv("待审批规则") || 0}</b></span><span>待复核发现 <b>${sv("待复核") || 0}</b></span><span>待处理冲突 <b>${sv("冲突") || 0}</b></span></div><div class="hdc-actions"><button class="btn" data-home-go="rules">处理规则</button><button class="btn" data-home-go="conflict">查看冲突</button></div></div>
        <div class="home-decision-card"><div class="hdc-kicker">质量结果</div><div class="hdc-main"><b>${(d.severity||{}).critical||0}</b><span>条严重问题</span></div><div class="hdc-sub">共 ${d.findings || 0} 条问题 · 涉及 ${d.cases || 0} 个项目；规则发布 ${sv("规则") || "—"}。</div></div>
        <div class="home-decision-card"><div class="hdc-kicker">规则健康</div><div class="hdc-stat-list"><span>误报占比 <b>${sv("Override") || "—"}</b></span><span>已复核 <b>${sv("已复核") || 0}</b></span><span>告警 <b>${sv("告警") || 0}</b></span></div><div class="hdc-sub">误报持续偏高的规则，应进入规则进化调整判据。</div></div>
      </div>`;
  const title = "审核概览" + ` · 近 ${days} 天`;
  host.innerHTML =
    `<div class="home-analytics-head"><div><h2>${title}</h2><p>共 ${d.cases || 0} 个项目、${d.findings || 0} 条问题；严重 ${(d.severity||{}).critical||0}、一般 ${(d.severity||{}).warning||0}、提示 ${(d.severity||{}).suspected||0} <span class="scope-note">全部空间汇总</span></p></div><div class="analysis-tools"><select id="home-days" class="field"><option value="7"${days===7?" selected":""}>近 7 天</option><option value="30"${days===30?" selected":""}>近 30 天</option><option value="90"${days===90?" selected":""}>近 90 天</option></select>${currentRole === "reviewer" ? "" : `<a class="analysis-export" href="/api/v1/analytics/issues.csv?days=${days}">导出 CSV</a>`}</div></div>` +
    decisionHtml +
    `<div class="analytics-grid">
      <section class="analysis-module cloud-module"><h3>高频问题（词云）</h3><div class="cloud-wrap">${cloud}</div></section>
      <section class="analysis-module"><h3>重复出现（流程性问题）</h3>${recurring}</section>
    </div>`;
  host.querySelectorAll("[data-home-go]").forEach(b => b.addEventListener("click", () => showView(b.dataset.homeGo)));
  host.querySelectorAll("[data-home-project]").forEach(b => b.addEventListener("click", () => openProject(b.dataset.homeProject)));
  const _daysSel = host.querySelector("#home-days");
  if (_daysSel) _daysSel.onchange = () => { homeAnalyticsDays = parseInt(_daysSel.value || "30", 10); renderHomeAnalytics(); };
  if (host.querySelector("#issue-cloud")) drawIssueCloud(host.querySelector("#issue-cloud"), _cloudItems);
}

function drawIssueCloud(canvas, items) {
  if (!canvas || !items || !items.length) return;
  const PALETTE = ["#2F6BE8", "#5B8FF9", "#3370FF", "#7B61FF", "#E6A23C", "#F56C6C", "#36B37E", "#4E5969", "#2F54EB", "#D46B08"];
  const draw = () => {
    const box = canvas.parentElement;
    const W = Math.max(320, box.clientWidth || 520), H = 230, dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = W * dpr; canvas.height = H * dpr; canvas.style.width = "100%"; canvas.style.height = H + "px";
    const ctx = canvas.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const sorted = [...items].sort((a, b) => b.count - a.count).slice(0, 26);
    const max = Math.max(...sorted.map(x => x.count), 1), min = Math.min(...sorted.map(x => x.count), 1);
    const placed = [];
    const boxes = [];
    const hit = (b) => boxes.some(x => !(b.x2 < x.x1 || b.x1 > x.x2 || b.y2 < x.y1 || b.y1 > x.y2));
    for (let i = 0; i < sorted.length; i++) {
      const item = sorted[i];
      const ratio = max === min ? 1 : (item.count - min) / (max - min);
      let size = Math.round(13 + 30 * Math.sqrt(ratio));
      let done = false;
      for (let attempt = 0; attempt < 2 && !done; attempt++) {
        if (attempt) size = Math.max(10, Math.round(size * 0.8));
        ctx.font = `${size >= 24 ? 700 : 600} ${size}px -apple-system,"PingFang SC","Microsoft YaHei",sans-serif`;
        const tw = ctx.measureText(item.title).width, th = size * 0.92;
        const rotate = (i % 5 === 1 && item.title.length <= 8 && size < 26);
        const bw = rotate ? th : tw, bh = rotate ? tw : th, pad = 5;
        if (bw > W - 24) continue;
        for (let step = 0; step < 1800; step++) {
          const angle = step * 0.38, radius = 5 + 2.5 * Math.sqrt(step) * 1.7;
          const cx = W / 2 + Math.cos(angle) * radius * 1.25;
          const cy = H / 2 + Math.sin(angle) * radius * 0.72;
          const b = { x1: cx - bw / 2 - pad, x2: cx + bw / 2 + pad, y1: cy - bh / 2 - pad, y2: cy + bh / 2 + pad };
          if (b.x1 < 8 || b.x2 > W - 8 || b.y1 < 8 || b.y2 > H - 8) continue;
          if (hit(b)) continue;
          ctx.save(); ctx.translate(cx, cy); if (rotate) ctx.rotate(-Math.PI / 2);
          ctx.fillStyle = PALETTE[i % PALETTE.length]; ctx.textAlign = "center"; ctx.textBaseline = "middle";
          ctx.fillText(item.title, 0, 0); ctx.restore();
          boxes.push(b); placed.push(item); done = true; break;
        }
      }
    }
  };
  canvas.__cloudDraw = draw;
  draw();
  if (!canvas.__cloudResize) {
    canvas.__cloudResize = true;
    let t = null;
    window.addEventListener("resize", () => { clearTimeout(t); t = setTimeout(() => canvas.__cloudDraw && canvas.__cloudDraw(), 180); });
  }
}

function ensureHomeShell() {
  if (document.querySelector("#home #home-greet")) return;
  const home = document.getElementById("home");
  if (!home) return;
  home.innerHTML =
    '<div class="hh" style="display:flex;justify-content:space-between;align-items:flex-start">' +
      '<div><div id="home-greet" style="font-size:22px;font-weight:600"></div>' +
      '<div id="home-sub" class="muted" style="margin-top:4px"></div></div>' +
    '</div>' +
    '<div id="home-kpis" class="kpis" style="display:grid;gap:12px;margin:16px 0"></div>' +
    '<div id="home-kpis-extra" class="kpis" style="display:grid;gap:12px;margin-bottom:16px"></div>' +
    '<div id="home-stale-badge-host" aria-live="polite"></div>' +
    '<div class="home-grid" style="grid-template-columns:1fr 1fr;gap:16px">' +
      '<div class="card"><div class="card-title" id="home-todo-title"></div><div id="home-todo"></div>' +
        '<div id="home-todo-more" class="muted" style="margin-top:8px"></div></div>' +
      '<div class="card"><div class="card-title" id="home-recent-title"></div><div id="home-recent"></div></div>' +
    '</div>' +
    '<div class="card" id="home-activity-row" style="margin-top:16px"><div id="home-activity"></div></div>';
}

function homeStaleBadgeHtml(h) {
  const count = Math.max(0, parseInt((h && h.stale_count) || 0, 10) || 0);
  if (!count) return "";
  const projects = Math.max(0, parseInt((h && h.stale_project_count) || 0, 10) || 0);
  const lib = String((h && h.stale_library_version) || "").trim();
  return `<div id="home-stale-badge" class="stale-badge" role="status" data-stale-count="${count}" data-stale-project-count="${projects}" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 12px;margin:0 0 16px;border:1px solid #F5C2C0;background:#FEF2F2;border-radius:8px;color:#B91C1C">
      <span class="pill r">stale ${count}</span>
      <span style="flex:1;min-width:220px">${count} 条发现基于旧点位判据${projects ? `，涉及 ${projects} 个项目` : ""}${lib ? `；当前点位库 ${esc(lib)}` : ""}。旧结果只提示，不自动改判，可在项目详情逐点重跑。</span>
      <button type="button" class="btn" id="home-stale-go" data-stale-go>查看项目</button>
    </div>`;
}

async function loadHome() {
  ensureHomeShell();
  const h = await (await fetch("/api/v1/home")).json();
  window.__homeData = h;
  const isReviewer = h.role === "reviewer";
  const isHomeWorker = ["reviewer", "admin"].includes(h.role);
  const now = new Date();
  const hour = now.getHours();
  const greet = hour < 6 ? "凌晨好" : hour < 12 ? "上午好" : hour < 18 ? "下午好" : "晚上好";
  $("#home-greet").textContent = `${greet}，${h.name || ""}`;
  // 首页副标题只显示日期，不重复身份、职责或概览文案
  $("#home-sub").textContent = `${now.getFullYear()} 年 ${now.getMonth() + 1} 月 ${now.getDate()} 日`;
  if (h.role !== "super_admin") renderHomeAnalytics();
  /* L84 E3：/api/v1/dashboard 并入首页「系统概览」卡片（仅业务管理员；审核员服务端 403，不渲染）。
     与 /api/v1/home 的关系：/home 是个人工作台 KPI；dashboard 是管理员全局 KPI（规则命中归因/override 率），
     两者字段有重叠但来源不同，卡片标题明确标“全局 KPI”，不把重叠字段混作新口径。 */
  if (h.role === "admin") {
    try { renderHomeDashboardCard(); } catch (e) { console.warn("系统概览卡片加载失败", e); }
  }
  if (h.role === "super_admin") {
    const _todo = document.querySelector("#home-todo")?.closest(".card");
    const _rec = document.querySelector("#home-recent")?.closest(".card");
    if (_todo && _rec) { _todo.parentElement.style.display = "none"; }
    const _act = document.querySelector("#home-activity-row"); if (_act) _act.style.display = "none";
    document.querySelector("#sys-quick")?.remove();
    document.querySelector("#home-analytics")?.remove();
    renderSuperDashboard(h.it_dashboard || {});
  }

  const allStats = h.stats || [];
  const mainStats = allStats.slice(0, 6);
  const extraStats = allStats.slice(6);
  const card = (s) => {
    const m = kpiMeta(s.label);
    const _scope = s.scope || "";
    return `<div class="kpi" title="${esc(s.hint || "")}">
            <b style="color:${m.color}">${esc(s.value)}</b>
      <span>${esc(s.label)}</span>
      ${_scope || s.hint ? `<div class="k-hint">${_scope ? `<span class="scope-chip">${esc(_scope)}</span>` : ""}${_scope && s.hint ? " " : ""}${s.hint ? esc(s.hint) : ""}</div>` : ""}
    </div>`;
  };
  const _allKpi = [...mainStats, ...extraStats];
  const _cols = _allKpi.length === 10 ? 5 : Math.min(_allKpi.length, 6) || 1;
  $("#home-kpis").style.gridTemplateColumns = `repeat(${_cols}, minmax(0, 1fr))`;
  $("#home-kpis").innerHTML = _allKpi.map(card).join("");
  const extraBox = $("#home-kpis-extra");
  if (extraBox) { extraBox.style.display = "none"; extraBox.innerHTML = ""; }
  // stale 是“旧点位判据”的可见性提醒：只在存在旧结果时展示，不混入 KPI 伪造 0 值。
  let staleHost = document.getElementById("home-stale-badge-host");
  if (!staleHost) {
    // 兼容旧 home 骨架/热更新：没有占位节点时在 KPI 后补一个，不丢 stale 提醒。
    const kpis = document.getElementById("home-kpis");
    if (kpis && kpis.parentNode) {
      staleHost = document.createElement("div");
      staleHost.id = "home-stale-badge-host";
      staleHost.setAttribute("aria-live", "polite");
      kpis.insertAdjacentElement("afterend", staleHost);
    }
  }
  if (staleHost) {
    staleHost.innerHTML = h.role === "super_admin" ? "" : homeStaleBadgeHtml(h);
    staleHost.hidden = !staleHost.innerHTML;
    staleHost.querySelector("[data-stale-go]")?.addEventListener("click", () => showView("projects"));
  }

  const isSuper = h.role === "super_admin";
  const todoCard = document.querySelector("#home-todo")?.closest(".card");
  const recentCard = document.querySelector("#home-recent")?.closest(".card");
  if (todoCard) todoCard.style.display = isSuper ? "none" : "";
  if (recentCard) recentCard.style.display = (isSuper || isHomeWorker) ? "none" : "";
  const rulesBtn = document.querySelector('.hh-actions [data-view="rules"]');
  if (rulesBtn) rulesBtn.style.display = (isHomeWorker || isSuper) ? "none" : "";
  $("#home-todo-title").textContent = "待复核发现（按项目）";
  $("#home-recent-title").textContent = "最近项目";
  // E-05（DuMate 20261118）：列表只列前 8 个项目时，KPI「待复核」是全部发现数，
  // 必须给出「查看全部」入口并标注仅展示前 N 个，不能静默截断。
  (function () {
    const moreEl = $("#home-todo-more");
    if (!moreEl) return;
    const total = Number(h.todo_total || 0), shown = Number(h.todo_shown || 0);
    const shownPending = (h.todo || []).reduce((n, c) => n + (Number(c.pending_count) || 0), 0);
    if (total > shown) {
      moreEl.hidden = false;
      moreEl.innerHTML = `<span>共 ${esc(String(total))} 个项目有待复核发现（合计 ${esc(String(h.todo_pending_total || 0))} 条），`
        + `此处仅展示前 ${esc(String(shown))} 个（${esc(String(shownPending))} 条）。</span>`
        + ` <a href="#" data-go="projects" style="color:#1967D2">查看全部项目 →</a>`;
      const link = moreEl.querySelector("[data-go]");
      if (link) link.onclick = (e) => { e.preventDefault(); showView("projects"); };
    } else {
      moreEl.hidden = true;
      moreEl.innerHTML = "";
    }
  })();
  if (isHomeWorker) {
    if (recentCard) recentCard.style.display = "none";
    const _hg = document.querySelector(".home-grid"); if (_hg) _hg.style.gridTemplateColumns = "1fr";
    const _act = document.querySelector("#home-activity-row"); if (_act) _act.style.display = "none";
  }
  // 新建项目仅审核员可用（管理端只读）
  const newBtn = document.querySelector("#btn-quick-new");
  if (newBtn) newBtn.style.display = isReviewer ? "" : "none";
  let todo = [];
  if (isHomeWorker) {
    todo = (h.todo || []).map(c => ({ id: c.id, name: c.name, pending_count: c.pending_count, status: c.status, created_at: c.created_at }));
  } else {
    todo = (h.recent_cases || []).filter(c => (c.pending_count || 0) > 0);
  }
  $("#home-todo").innerHTML = (isHomeWorker ? '<div class="muted" style="font-size:12px;margin:0 0 8px">以下项目还有未处理的发现；点项目进入审核工作台逐条复核。</div>' : '') +
    (todo.length
    ? todo.map(c => `<div class="home-todo-item" data-pid="${esc(c.id)}">
        <div><div class="ht-name">${esc(c.name)}</div><div class="ht-meta">${esc(PROJ_STATUS[c.status] || c.status || "")} · ${esc(c.created_at || "")}</div></div>
        <span class="pill draft">待复核 ${c.pending_count || 0}</span></div>`).join("")
    : `<div class="muted" style="padding:16px 0">${isHomeWorker ? "当前没有待复核发现" : "暂无待办，保持得不错"}</div>`);

  const recent = isHomeWorker ? (h.my_projects || []) : (h.recent_cases || []);
  const recentRows = recent.map(c => {
    const label = c.status_label || PROJ_STATUS[c.status] || c.status || "";
    return `<tr style="cursor:pointer" data-pid="${esc(c.id)}">
      <td>${esc(c.name)}</td>
      <td><span class="pill ${/已确认|完成/.test(label) ? "published" : /异常|失败/.test(label) ? "draft" : "r"}">${esc(label)}</span></td>
      <td>${c.pending_count || 0}</td><td>${c.decided_count || 0}</td></tr>`;
  }).join("");
  $("#home-recent").innerHTML = recent.length
    ? `<table class="table"><thead><tr><th>项目</th><th>状态</th><th>待复核</th><th>已复核</th></tr></thead><tbody>${recentRows}</tbody></table>`
    : `<div class="muted" style="padding:16px 0">暂无项目</div>`;

  try {
    const msgs = await (await fetch("/api/v1/notifications?unread=1")).json();
    const list = (msgs && msgs.items) ? msgs.items : (Array.isArray(msgs) ? msgs : []);
    $("#home-activity").innerHTML = (list || []).length
      ? list.slice(0, 6).map(m => `<div class="home-activity-row"><span class="ha-dot"></span>
          <span class="ha-type">${notifyLabel(m.type)}</span>
          <span>${esc(m.title || "")}</span>
          <span class="ha-time">${esc((m.created_at || "").slice(5, 16))}</span></div>`).join("")
      : `<div class="muted" style="padding:16px 0">暂无动态</div>`;
  } catch (e) {
    $("#home-activity").innerHTML = `<div class="muted" style="padding:16px 0">暂无动态</div>`;
  }
  document.querySelectorAll("#home-todo [data-pid], #home-recent [data-pid]").forEach(el =>
    el.addEventListener("click", () => openProject(el.dataset.pid)));
}

/* ===================== 项目列表 stale 徽标 ===================== */
/*
 * 项目列表视图在 projects_view.js，本分支只允许改 app.js，因此这里不复制列表实现，
 * 而是在 DOMContentLoaded 后包一层 loadProjects：捕获列表接口响应，原样交给列表
 * 渲染，再在表头插入 stale 汇总、在项目行追加 stale_count 徽标。
 * 列表级计数由后端 stats.decorate_project_list 提供（不随筛选/分页变化），
 * items[*].stale_count 只标注当前页项目；没有 stale 时完全不渲染徽标。
 */
function applyProjectStaleBadge(payload) {
  const host = document.getElementById("project-list");
  if (!host || !payload || typeof payload !== "object") return false;
  const count = Math.max(0, parseInt(payload.stale_count || 0, 10) || 0);
  if (!count) {
    host.querySelectorAll("#pl-stale-badge, [data-stale-count]").forEach(el => el.remove());
    return false;
  }
  const projects = Math.max(0, parseInt(payload.stale_project_count || 0, 10) || 0);
  const lib = String(payload.stale_library_version || "").trim();
  const existing = document.getElementById("pl-stale-badge");
  if (existing) existing.remove();
  const table = host.querySelector("table");
  const box = document.createElement("div");
  box.id = "pl-stale-badge";
  box.className = "stale-badge";
  box.setAttribute("role", "status");
  box.dataset.staleCount = String(count);
  box.dataset.staleProjectCount = String(projects);
  box.style.cssText = "display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 12px;margin:0 0 12px;border:1px solid #F5C2C0;background:#FEF2F2;border-radius:8px;color:#B91C1C";
  box.innerHTML = `<span class="pill r">stale ${count}</span>
    <span style="flex:1;min-width:240px">共 ${count} 条发现基于旧点位判据${projects ? `，涉及 ${projects} 个项目` : ""}${lib ? `；当前点位库 ${esc(lib)}` : ""}。汇总按当前数据范围统计，不随关键词/状态/空间筛选变化；旧结果需在项目详情复核或重跑。</span>`;
  // 筛选后列表为空时也要显示汇总：stale 计数本身不随筛选变化。
  if (table && table.parentNode) table.parentNode.insertBefore(box, table);
  else host.insertBefore(box, host.firstChild);
  const byId = {};
  (Array.isArray(payload.items) ? payload.items : []).forEach(item => {
    if (item && item.id != null) byId[String(item.id)] = Math.max(0, parseInt(item.stale_count || 0, 10) || 0);
  });
  host.querySelectorAll("tr[data-id]").forEach(tr => {
    tr.querySelectorAll("td [data-stale-count]").forEach(el => el.remove());
    const n = byId[String(tr.dataset.id || "")] || 0;
    if (!n) return;
    const nameCell = tr.children[1] || tr.querySelector("td");
    if (!nameCell) return;
    const badge = document.createElement("span");
    badge.className = "pill r";
    badge.dataset.staleCount = String(n);
    badge.title = "该项目的发现基于旧点位判据，需复核或重跑";
    badge.style.marginLeft = "6px";
    badge.textContent = `stale ${n}`;
    (nameCell.querySelector("b") || nameCell).insertAdjacentElement("afterend", badge);
  });
  return true;
}

let projectStaleLoadTail = Promise.resolve();

async function loadProjectsWithStaleCapture(original, context, page) {
  const nativeFetch = window.fetch;
  let captured = null;
  try {
    window.fetch = function (input, init) {
      const pending = nativeFetch.apply(this, arguments);
      try {
        const raw = typeof input === "string" ? input : (input && input.url) || "";
        if (pending && typeof pending.then === "function" && /\/api\/v1\/projects(?:\?|$)/.test(raw)) {
          // 先 clone 再交回原逻辑，避免消费同一 Response body。
          pending.then(res => {
            if (!res || typeof res.clone !== "function") return;
            captured = res.clone().json().catch(() => null);
          }).catch(() => {});
        }
      } catch (e) { /* 捕获失败不影响列表本身 */ }
      return pending;
    };
    return await original.call(context, page);
  } finally {
    window.fetch = nativeFetch;
    if (captured) {
      try { applyProjectStaleBadge(await captured); } catch (e) { /* 徽标失败不影响列表 */ }
    }
  }
}

function installProjectStaleBadge() {
  const original = window.loadProjects;
  if (typeof original !== "function" || original.__staleBadgeWrapped) return false;
  const wrapped = function (page) {
    // 串行化，避免连点分页时两层 fetch 包装互相恢复、留下永久包装。
    const run = projectStaleLoadTail.then(
      () => loadProjectsWithStaleCapture(original, this, page),
      () => loadProjectsWithStaleCapture(original, this, page),
    );
    projectStaleLoadTail = run.catch(() => {});
    return run;
  };
  wrapped.__staleBadgeWrapped = true;
  window.loadProjects = wrapped;
  return true;
}

/* ===================== 数据洞察/系统 ===================== */
$("#btn-sediment")?.addEventListener("click", async () => {
  const dir = $("#std-dir").value.trim();
  if (!dir) { $("#sediment-status").textContent = "请输入企业标准目录"; return; }
  $("#sediment-status").textContent = "导入中…";
  const r = await (await fetch("/api/v1/sediment", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dir }) })).json();
  $("#sediment-status").textContent = r.error ? "错误：" + r.error : `已导入 ${r.imported} 条`;
  loadRules();
});
$("#btn-conflict")?.addEventListener("click", async () => {
  const list = await (await fetch("/api/v1/conflicts")).json();
  $("#conflict-out").innerHTML = list.map(v => {
    const st = v.status || "open";
    const ST = { open: ["r", "待处理"], resolved: ["published", "已裁决"], ignored: ["draft", "已忽略"] };
    const [cls, label] = ST[st] || ST.open;
    return `<div style="padding:6px 0;border-bottom:1px dashed #F0F1F2;display:flex;align-items:center;gap:10px">
      <span class="pill ${v.type === '已证明冲突' ? 'draft' : v.type === '无法判定' ? 'r' : 'published'}">${esc(v.type)}</span>
      <span style="flex:1">${esc(v.a)} vs ${esc(v.b)} · <span class="muted">${esc(v.detail || "")}</span></span>
      <span class="pill ${cls}">${label}</span>
      ${st === "open" ? `<button class="btn" data-cres="${esc(v.id)}" data-act="resolved">裁决</button>
        <button class="btn" data-cres="${esc(v.id)}" data-act="ignored">忽略</button>` : ""}
    </div>`;
  }).join("");
  document.querySelectorAll("[data-cres]").forEach(b => b.addEventListener("click", async () => {
    await fetch(`/api/v1/conflicts/${b.dataset.cres}/resolve`, { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: b.dataset.act }) });
    $("#btn-conflict").click();
  }));
});
$("#btn-errorbook")?.addEventListener("click", async () => {
  const list = await (await fetch("/api/v1/errorbook")).json();
  $("#errorbook-out").innerHTML = list.length ? list.map(e => `<div style="padding:3px 0"><span class="pill draft">误报</span> ${esc(e.finding.title)} <span class="muted">${esc(e.finding.rule_id)} · ${esc(e.decision.reason || '—')}</span></div>`).join("") : `<span>暂无</span>`;
});
$("#btn-evolution")?.addEventListener("click", async () => {
  const _k = document.querySelector("#evo-kpis"); if (_k) _k.style.display = "none";
  const list = await (await fetch("/api/v1/evolution")).json();
  const actionable = (Array.isArray(list) ? list : [])
    .filter(r => Number(r.decided || 0) > 0 || Number(r.false_positive || 0) > 0)
    .sort((a, b) => (Number(b.override_rate || 0) - Number(a.override_rate || 0)) || (Number(b.hit || 0) - Number(a.hit || 0)));
  const box = document.querySelector("#evolution-out");
  if (!box) return;
  if (!actionable.length) {
    box.innerHTML = `<div class="evo-empty"><div class="evo-empty-title">暂无可操作规则建议</div><div>进化建议来自“已复核”的确认和误报数据。当前工作空间还没有积累足够的复核样本。</div><div class="evo-empty-actions"><button class="btn" data-evo-go-feedback>去反馈台账</button><span class="muted">完成一些项目复核后再回来。</span></div></div>`;
    box.querySelector("[data-evo-go-feedback]")?.addEventListener("click", () => {
      document.querySelector('[data-evt="all"]')?.click();
    });
    return;
  }
  box.innerHTML = `<div class="evo-suggest-head"><div><b>可操作建议 ${actionable.length} 条</b><div class="muted">按误报率/命中数据排序；只展示已经有人工复核样本的规则。</div></div><span class="pill published">草稿生成后到草稿箱直接发布（无需审批）</span></div>
    <table class="table evo-suggest-table"><thead><tr><th style="width:58px">序号</th><th>规则</th><th class="num">命中</th><th class="num">误报</th><th class="num">Override</th><th>建议</th><th class="actions-cell" style="width:116px">操作</th></tr></thead><tbody>` +
    actionable.map((r, i) => `<tr>
      <td class="muted">${i + 1}</td>
      <td><b>${esc(r.rule_code || "")}</b><div class="muted" style="font-size:11px">${esc(r.name || "")}</div></td>
      <td class="num">${r.hit || 0}</td><td class="num">${r.false_positive || 0}</td>
      <td class="num"><span class="pill ${r.override_rate >= 0.5 ? "draft" : r.override_rate > 0.2 ? "r" : "published"}">${Math.round((r.override_rate || 0) * 100)}%</span></td>
      <td class="muted">${esc(r.suggestion || "建议复核阈值/证据要求")}</td>
      <td class="actions-cell"><button class="btn" data-draft="${esc(r.rule_code)}">生成草稿</button></td></tr>`).join("") + `</tbody></table>
    <div class="evo-suggest-foot">生成的是规则草稿，不会自动发布；到「规则草稿箱」点「发布生效」即可参与审核（规则无需审批）。</div>`;
  box.querySelectorAll("[data-draft]").forEach(b => b.addEventListener("click", async () => {
    b.disabled = true; b.textContent = "生成中…";
    const res = await (await fetch(`/api/v1/evolution/${encodeURIComponent(b.dataset.draft)}/draft`, { method: "POST" })).json();
    if (res && res.error) { showToast(res.error, "err"); b.disabled = false; b.textContent = "生成草稿"; return; }
    showToast("已生成规则草稿：" + (res.rule_id || "") + "，请到「规则草稿箱」发布生效（无需审批）");
    b.textContent = "已生成"; b.className = "btn"; b.disabled = true;
  }));
});
$("#btn-model")?.addEventListener("click", async () => {
  const c = await (await fetch("/api/v1/model/config")).json();
  const pts = await (await fetch("/api/v1/model/points")).json();
  $("#model-out").innerHTML = `<div style="display:flex;flex-wrap:wrap;gap:10px;margin:8px 0"><span class="pill ${c.enabled ? 'published' : 'draft'}">${c.enabled ? '已启用' : '未启用'}</span><span class="pill r">${esc(c.model || '未配置')}</span><span class="pill r">${esc(c.base_url || '')}</span><span class="muted">密钥 ${esc(c.api_key_masked)}</span><button id="btn-model-test" class="btn primary">测试连接</button></div>
    ${pts.map(p => `<div style="padding:6px 0;border-bottom:1px solid #EFF0F1"><div class="ft">${esc(p.name)} <span class="pill ${p.used ? 'published' : 'r'}">${p.used ? '使用中' : '待接入'}</span></div><div class="fd muted">${esc(p.desc)}</div></div>`).join("")}
    <div id="model-test-out" class="muted" style="margin-top:8px"></div>`;
  document.querySelector("#btn-model-test").addEventListener("click", async () => {
    document.querySelector("#model-test-out").textContent = "测试中…";
    const r = await (await fetch("/api/v1/model/test", { method: "POST" })).json();
    document.querySelector("#model-test-out").innerHTML = `<span class="pill ${r.ok ? 'published' : 'draft'}">${r.ok ? '连通正常' : '失败'}</span> ${esc(r.detail)}`;
  });
});
/* 消息中心已拆到 web/messages.js，避免 app.js 继续膨胀。 */


/* ===================== 导航 ===================== */
function openModelView() {
  if (typeof loadModels === "function") return loadModels();
  const old = document.querySelector('script[data-rp-models]');
  if (old) return;
  const s = document.createElement("script");
  s.src = "/models.js"; s.dataset.rpModels = "1";
  s.onload = () => { if (typeof loadModels === "function") loadModels(); };
  document.body.appendChild(s);
}

const TITLES = {home: "首页", projects: "项目列表", myaudits: "审核列表", auditrecords: "审核记录", workbench: "审核工作台", report: "整体结论", newproject: "新建项目", project: "项目详情", users: "账号列表", openplatform: "开放平台", agents: "智能体", auditlogs: "审计日志", datapolicy: "数据边界", rules: "规则库", drafts: "规则草稿箱", newrule: "新建规则", sediment: "标准导入", ontology: "本体建模", terms: "企业词典", model: "模型", tenant: "租户配置", ops: "运维看板", conflict: "冲突提醒", evolution: "规则进化", errorbook: "错误书", messages: "消息中心", notifyconfig: "通知配置", wssettings: "空间列表", knowledge: "知识库",
};

/* ===== 系统管理员页面直达 URL / 菜单权限（与后端 403 口径一致） =====
   1) 前端隐藏的业务页面，即使通过 console 调 showView 也不渲染，提示后回首页；
   2) 系统管理员不可见的审核业务页面：后端写接口 403、只读 GET 仅按白名单放行，
      页面层不提供入口（F-28 口径）。 */
const SUPER_ADMIN_BIZ_VIEWS = ["projects", "myaudits", "auditrecords", "workbench", "report", "project",
  "newproject", "rules", "drafts", "newrule", "sediment", "ontology", "terms", "conflict", "evolution",
  "errorbook", "wssettings", "tenant", "dashboard", "eval"];
const SYSTEM_ADMIN_VIEWS = ["users", "openplatform", "model", "agents", "auditlogs", "notifyconfig", "ops", "datapolicy"];
/* T-111（2026-11-18）用户明确口径：审核员不看本体；业务管理员不做新建项目。
   三层一致：左侧菜单（审核端无本体 / 管理端无新建项目）+ 路由守卫（本函数/showView/直接 URL 哈希）
   + 服务端 403（本体写接口、POST 新建项目/审核）。只读/无权限用禁用/说明，不删页面元素造成歧义。 */
const VIEW_DENY_REVIEWER = {
  ontology: "审核员不看本体：本体建模仅业务管理员可维护（服务端写接口返回 403）",
  terms: "审核员不看本体/企业词典：仅业务管理员可维护（服务端写接口返回 403）",
  wssettings: "工作空间配置由业务管理员维护；审核员只使用已分配空间",
  sediment: "标准导入由业务管理员执行；审核员不提供该入口",
};
const VIEW_DENY_ADMIN = {
  newproject: "业务管理员不能新建项目：新建项目/上传/审核仅审核员可执行（服务端 POST 返回 403）",
};
function roleViewDenied(id) {
  const role = currentRole || (currentUser && currentUser.role) || "";
  if (!role) return "";  // 身份未加载完成时交给后端 403 兜底，不静默放行数据
  if (role === "reviewer" && VIEW_DENY_REVIEWER[id]) return VIEW_DENY_REVIEWER[id];
  if (role === "admin" && VIEW_DENY_ADMIN[id]) return VIEW_DENY_ADMIN[id];
  if (role === "super_admin" && SUPER_ADMIN_BIZ_VIEWS.includes(id)) {
    return "系统管理员不访问审核业务页面（后端写接口同样 403）";
  }
  if (role === "platform_op" && !["home", "openplatform"].includes(id)) {
    return "平台管理员不可访问企业业务页面";
  }
  if (role !== "super_admin" && SYSTEM_ADMIN_VIEWS.includes(id)) {
    return "系统管理员页面仅系统管理员可见（服务端接口返回 403）";
  }
  return "";
}

/* 路由守卫的可见提示：无权限时页面顶部固定说明，不白屏、不静默；离开受限视图后自动收起。
   只做说明，不删除任何页面/按钮元素（避免「入口消失但页面仍可操作」的歧义）。 */
function showPermDeniedNotice(viewId, msg) {
  const content = document.querySelector(".content") || document.body;
  let box = document.getElementById("perm-denied-banner");
  if (!box) {
    box = document.createElement("div");
    box.id = "perm-denied-banner";
    box.setAttribute("role", "alert");
    box.style.cssText = "position:sticky;top:0;z-index:60;margin:0 0 12px;padding:10px 14px;border:1px solid #FFD2D2;background:#FFF3F3;color:#C62828;border-radius:8px;font-size:12px;line-height:1.7;display:flex;gap:10px;align-items:flex-start";
    content.prepend(box);
  }
  const title = (TITLES && TITLES[viewId]) || viewId || "受限页面";
  box.innerHTML = `<div style="flex:1"><b>无权限访问「${esc(title)}」</b> · ${esc(msg)}
      <div style="font-size:11px;color:#8F959E;margin-top:3px">已留在当前页面；服务端接口同样按角色 403，不依赖前端隐藏。左侧菜单不提供该入口。</div></div>
    <button type="button" class="btn" id="perm-denied-close" style="height:26px;min-height:26px;padding:0 8px" aria-label="关闭无权限提示">关闭</button>`;
  box.hidden = false;
  const b = box.querySelector("#perm-denied-close");
  if (b) b.onclick = () => { box.hidden = true; };
}
function clearPermDeniedNotice() {
  const box = document.getElementById("perm-denied-banner");
  if (box) box.hidden = true;
}

/* 直达 URL：#ontology / #newproject / #conflict 等哈希与视图 id 一一对应（仅本端 SPA 使用）。
   守卫统一走 showView/roleViewDenied，受限视图不会渲染；未知哈希忽略，不白屏。 */
function viewIdFromHash() {
  try {
    const raw = String(location.hash || "").replace(/^#\/?/, "").split(/[?&]/)[0].split("/")[0];
    if (!raw) return "";
    const id = decodeURIComponent(raw);
    if (!TITLES || !TITLES[id]) return "";
    if (document.querySelector("#view-" + id)) return id;
    // 受限视图可能没有渲染 section（如审核端的企业词典由脚本动态注入）：仍交给守卫给出「无权限」说明。
    if (roleViewDenied(id)) return id;
    return "";
  } catch (e) { return ""; }
}
function applyHashViewRoute() {
  const id = viewIdFromHash();
  if (!id) return false;
  showView(id);
  return true;
}

function bindRuleStatic() {
  const btn = document.getElementById("btn-rule-static");
  if (!btn || btn.__bound) return;
  btn.__bound = true;
  btn.addEventListener("click", () => {
    window.open("/rules/static-analysis", "_blank", "noopener");
  });
}

/* 空壳视图（历史上由已合并的独立页面残留，hash 仍可直达）：
   不再白屏——统一给空态说明 + 去真实页面入口，不新增页面/不重排布局。 */
const EMPTY_SHELL_VIEWS = {
  auditrecords: {
    title: "该视图已合并到「项目列表」",
    desc: "审核记录随项目详情展示，不再单独成页；请到项目列表打开对应项目查看完整记录。",
    action: { label: "去项目列表", action: "view:projects" },
  },
  report: {
    title: "该视图已合并到「审核工作台」",
    desc: "整体结论在审核工作台的报告抽屉中查看与导出；请从项目列表进入工作台。",
    action: { label: "去项目列表", action: "view:projects" },
  },
  sediment: {
    title: "该视图已合并到「规则库」",
    desc: "企业标准导入已归入规则库/规则草稿箱的导入入口，不再单独成页。",
    action: { label: "去规则库", action: "view:rules" },
  },
};
const VIEW_BACK_PARENT = {
  terms: "ontology", project: "projects", workbench: "projects",
  report: "workbench", tenant: "home", ops: "home",
  sediment: "rules", errorbook: "evolution", auditrecords: "projects",
};
function renderViewBack(id) {
  let b = document.getElementById("view-back");
  if (!b) {
    b = document.createElement("button");
    b.type = "button"; b.id = "view-back"; b.className = "btn";
    b.style.marginRight = "8px";
    b.addEventListener("click", () => {
      const parent = VIEW_BACK_PARENT[currentView];
      if (parent) showView(parent);
    });
    const title = document.querySelector("#page-title");
    if (title && title.parentNode) title.parentNode.insertBefore(b, title);
  }
  const parent = VIEW_BACK_PARENT[id];
  b.hidden = !parent;
  b.textContent = parent ? ("← 返回" + (TITLES[parent] ? " " + TITLES[parent] : "")) : "返回";
}

function showView(id) {
  // 先经过全局 dirty 守卫：有未保存改动的表单视图在切换前确认；无改动直接放行。
  const _uxGuard = uxBeforeViewChange(id);
  if (_uxGuard === false) return;
  if (_uxGuard && typeof _uxGuard.then === "function") {
    _uxGuard.then((ok) => { if (ok) showView(id); });
    return;
  }
  const _denied = roleViewDenied(id);
  if (_denied) {
    if (typeof showToast === "function") showToast(_denied, "err");
    showPermDeniedNotice(id, _denied);
    if (currentView && currentView !== id) return;
    id = "home";
  } else {
    clearPermDeniedNotice();
  }
  const _sameView = id === currentView;
  // T-108：首次引导只在首页；切到冲突等其它页面立即收起，不拦截后续页面、不残留遮罩。
  if (id !== "home") _onboardDismiss();
  currentView = id;
  // 每次进入带筛选的视图，允许从 localStorage 回填一次；同一视图内的查询/分页不重复覆盖用户当前选择。
  if (!_sameView && UX_FILTER_FIELDS[id]) UX_FILTER_RESTORED[id] = false;
  // 进入 dirty 表单视图时以首次用户操作为基线，避免异步回填被误判为未保存修改。
  if (!_sameView && UX_DIRTY_VIEWS[id]) uxDirtyReset(id);
  document.querySelectorAll(".view").forEach(v => v.hidden = true);
  const v = document.querySelector(`#view-${id}`); if (v) v.hidden = false;
  document.querySelectorAll(".menu-item").forEach(m => m.classList.toggle("active", m.dataset.view === id));
  document.querySelector("#page-title").textContent = TITLES[id] || id;
  renderViewBack(id);
  const auto = { home: () => { loadHome(); setTimeout(renderHomeAnalytics, 600); },
    projects: () => { if (typeof loadProjects === "function") loadProjects(); },
    myaudits: () => { if (typeof loadMyAudits === "function") loadMyAudits(); },  workbench: () => {}, report: () => {}, newproject: () => { initNpSelects(); initTypeMemory(); initAuditModeBox(); $("#np-focus")?.focus(); }, rules: () => { loadRules(); bindRuleStatic(); bindRuleMining(); },
    drafts: () => { if (typeof loadDrafts === "function") loadDrafts(); }, users: loadUsers, openplatform: () => { if (typeof loadOpenPlatform === "function") loadOpenPlatform(); }, agents: loadAgents, auditlogs: () => loadAuditLogsPaged(true),
    messages: () => { loadMessages(); },
    ontology: loadOntology, terms: openTermsView, model: () => openModelView(), notifyconfig: loadNotifyConfig,
    tenant: () => { if (window.RPSettingsDrawers && window.RPSettingsDrawers.tenant) window.RPSettingsDrawers.tenant(); },
    datapolicy: () => { if (window.RPSettingsDrawers && window.RPSettingsDrawers.dataPolicy) window.RPSettingsDrawers.dataPolicy(); else showToast("数据边界模块未加载，请刷新页面", "err"); },
    ops: () => { if (window.RPSettingsDrawers && window.RPSettingsDrawers.ops) window.RPSettingsDrawers.ops(); },
    newrule: () => { renderNewRule("nl"); loadRecentRules(); }, conflict: loadConflicts,
    evolution: () => { loadEvolutionPage(); $("#btn-evolution")?.click(); }, errorbook: () => $("#btn-errorbook")?.click(),
    knowledge: () => { if (window.KB && window.KB.onShow) window.KB.onShow(); }, };
  if (id === "projects") installProjectStaleBadge();
  if (auto[id]) auto[id]();
  // 空壳视图：容器内无任何内容时补空态，避免直达 hash 后整页空白
  const _emptyShell = EMPTY_SHELL_VIEWS[id];
  if (_emptyShell) {
    const _host = document.querySelector("#view-" + id);
    if (_host && !_host.textContent.trim()) _host.innerHTML = uxEmptyHTML(_emptyShell);
  }
  if (id === "home") setTimeout(_onboardMaybeShowPending, 60);
  // 工作空间选择器固定显示在规则引擎菜单组内；项目/首页数据不按空间切分
  const _mw = document.querySelector(".menu-ws");
  if (_mw) _mw.style.display = (currentRole === "super_admin" || currentRole === "platform_op") ? "none" : "";
  if (id === "openplatform") loadOpenPlatform();
  if (id === "wssettings") renderWsSettings();
  // 浏览器后退/前进可用：视图切换写 hash（pushState 不触发 hashchange，避免递归）。
  // 只在 hash 与实际视图不一致时写，且尊重用户/直接 URL 的 #view 语义。
  try {
    const want = "#" + id;
    if (location.hash !== want && !(id === "home" && !location.hash)) {
      history.pushState({ view: id }, "", want);
    }
  } catch (e) { /* 非 http(s) 或受限环境忽略 */ }
}
window.addEventListener("popstate", () => { try { applyHashViewRoute(); } catch (e) {} });
document.querySelectorAll(".menu-item").forEach(m => m.addEventListener("click", (e) => {
  if (!m.dataset.view) return;
  _bootUserNavigated = true;   // E-07：用户主动导航，loadUser 不得再覆盖回首页
  showView(m.dataset.view);
}));
document.querySelectorAll("[data-go]").forEach(el => el.addEventListener("click", (e) => { e.preventDefault(); _bootUserNavigated = true; showView(el.dataset.go); }));
/* T-111：哈希直达（#ontology/#newproject/...）与左侧菜单、路由守卫同一入口。 */
window.addEventListener("hashchange", () => { try { applyHashViewRoute(); } catch (e) {} });

function applyReviewerUi() {
  const rev = currentRole === "reviewer";
  ["#btn-conflict-detect", "#btn-dt-new", "#onto-publish", "#onto-add-inst", "#onto-add-alias", "#onto-add-link"].forEach(sel => {
    const el = document.querySelector(sel);
    if (el) el.style.display = rev ? "none" : "";
  });
}

async function applyRole() {
  const r = await fetch("/api/v1/me");
  if (!r.ok) return;
  const u = (await r.json()).user; currentRole = u.role;
  const isAdmin = ["admin", "super_admin"].includes(u.role);
  const isSuper = u.role === "super_admin";
  const isBiz = u.role === "admin";
  const _maMenu = document.querySelector('.menu-item[data-view="myaudits"]');
  if (_maMenu) _maMenu.textContent = "审核列表";
  // 非破坏式：只切换可见性，角色信息变化或重新登录时能自愈
  const set = (sel, visible) => document.querySelectorAll(sel).forEach(el => {
    el.classList.toggle("role-hidden", !visible);
  });
  set(".admin-only", isAdmin);
  set(".super-only", isSuper);
  set(".biz-only", isBiz);
  set(".reviewer-only", !isAdmin);
  // 系统管理员不管理空间：直接移除空间菜单与工作空间选择器，避免残留入口
  if (isSuper) {
    document.querySelectorAll(".menu-ws").forEach(el => el.remove());
    document.querySelectorAll('.menu-item[data-view="wssettings"]').forEach(el => el.remove());
    document.querySelectorAll(".menu-group").forEach(g => {
      if ((g.textContent || "").trim() === "空间管理") g.remove();
    });
  }
  // 隐藏没有可见子项的分组标题（只切隐藏，不删除）
  document.querySelectorAll(".sidebar .menu-group").forEach(g => {
    let n = g.nextElementSibling, has = false;
    while (n && !n.classList.contains("menu-group")) {
      if (n.classList.contains("menu-item") && !n.classList.contains("role-hidden")) { has = true; break; }
      n = n.nextElementSibling;
    }
    g.classList.toggle("role-hidden", !has);
  });
  syncTermsRole();
}
let currentUser = null;
function renderIdentity(u) {
  // 当前版本不展示头像/身份切换菜单；保留身份角色供权限提示使用。
  const chip = document.querySelector("#identity-chip");
  if (chip) {
    const label = { super_admin: "系统管理员", admin: "业务管理员", reviewer: "审核员", platform_op: "平台管理员" }[u.role] || u.role || "";
    chip.textContent = label;
    chip.hidden = !label;
  }
}
function maybePromptIdentity(u) {
  // 单身份账号无需二次选择；保留空实现，避免加载链路中断。
}

/* ===== 首次登录引导 ===== */
let _onboardSteps = [], _onboardIndex = 0, _onboardUser = null;
function _onboardTargetVisible(sel) {
  const el = document.querySelector(sel);
  if (!el) return null;
  if (el.offsetParent === null) return null;
  return el;
}
function _onboardStepsFor(u) {
  const isRev = u.role === "reviewer";
  const isSuper = u.role === "super_admin";
  const isBiz = u.role === "admin";
  const steps = [{
    title: `${u.name || "你好"}，欢迎使用 AI 审核平台`,
    text: isRev
      ? "你的主流程是：新建项目 → 上传文件 → 查看发现 → 逐条复核/补证 → 生成报告。先花 1 分钟认识这几个位置，之后可以随时在消息中心查看进度。"
      : isSuper
        ? "你负责账号、模型、智能体、开放平台和审计，不处理具体项目。这个引导只介绍管理端最常用的入口；业务规则和审核结果由业务管理员/审核员处理。"
        : "你负责本租户的规则、空间、本体和租户品牌，并对项目结果做只读查看。这个引导会带你走一遍规则发布、空间范围、点位确认和结果查看。",
    target: "",
  }];
  const push = (target, title, text) => {
    if (target && !_onboardTargetVisible(target)) return;
    steps.push({ title, text, target: target || "" });
  };
  if (u.must_change_pwd) {
    steps.push({ title: "先修改初始密码", text: "这是临时密码，仅用于首次登录。请先在账号设置中改成自己的密码，再开始工作；修改后临时密码记录会自动清除。", target: isSuper ? "#menu-account" : "" });
  }
  if (isRev) {
    push('[data-view="newproject"]', "从“新建项目”开始", "上传文件前先确认当前工作空间和文件类型；解析失败的文件不要直接送审。上传后系统会先解析、抽取事实，再进入清单和执行，不会跳过解析直接给结论。");
    push('[data-view="rules"]', "规则库决定“怎么审”", "规则必须先发布才会进入下一次审核；草稿、冲突和未确认点位都不会直接生效。遇到“证据不足”不是通过，需要补证或转人工。");
    push('[data-view="projects"]', "项目列表与发现", "项目列表只显示你本人有权查看的项目；进入工作台后先看发现和证据锚点，再决定确认、误报或补证。报告只能在待复核和 unknown 处理完后生成。");
    push('[data-view="messages"]', "消息中心", "审核完成、规则变更、冲突和需要补证的事项会进入消息中心。未读消息可以标为已读，但不要用消息代替复核结论。");
    push('', "遇到不确定，用页面助手", "右下角页面助手只解释当前页面操作，不执行操作、不读取项目正文。涉及业务判断、客户数据或系统配置的问题，它不会回答，请找业务管理员。");
    return steps;
  }
  if (isSuper) {
    push('[data-view="users"]', "账号与角色", "账号按平台端、管理端、审核端隔离；系统管理员只管理账号、模型、智能体、开放平台和审计。停用账号会立即失去会话，重置密码必须使用随机临时密码。");
    push('[data-view="model"]', "模型配置", "文本审核、语义判断和 OCR/视觉是不同能力，不能把文本模型当 OCR。没有配置支持图片的模型时，扫描件会显式降级/待补证，不会伪造 OCR 成功。");
    push('[data-view="agents"]', "智能体是节点，不是装饰", "7 个智能体按解析、事实、规则、冲突、判定、误报、挖掘分工；不是每次全部运行。模型不可用时节点会降级并留下原因，不能把失败写成通过。");
    push('[data-view="auditlogs"]', "审计日志与开放平台", "审计日志只读、不可导出；开放平台用 HMAC、事件订阅和回调重试。AppSecret 只在创建/轮换时显示一次，列表只显示掩码。");
    push('#menu-account', "账号设置", "这里修改自己的邮箱和密码。不要把管理员密码交给业务人员；系统管理员的职责边界是 IT 资产，不进入项目复核和报告。");
    return steps;
  }
  // business admin
  push('[data-view="wssettings"]', "空间是规则和文件类型的边界", "空间决定哪些文件类型、规则和点位可以执行。空间只影响规则引擎，不改变首页/项目列表的汇总口径；审核员只能使用已分配空间。");
  push('[data-view="rules"]', "规则发布前先体检", "规则要补齐适用文件类型、证据要求和判据；无 scope 的规则不会自动全量执行。发布前看冲突、IR 和测试结果，草稿不会进入清单。");
  push('[data-view="ontology"]', "词典与本体先归一", "同义词可以归一，不等同关系禁止合并。术语确认后会投影到本体；删除会反投影，先确认没有规则引用。");
  push('[data-view="projects"]', "项目结果只读", "业务管理员可以查看本租户全部项目，但不能编辑、复核、生成或导出报告；这些是审核员的动作。发现异常时通过规则/点位/复核流程处理。");
  push('[data-view="tenant"]', "租户品牌", "平台名称和 Logo 只影响本租户的登录页、侧栏和报告标题，不会修改平台端品牌。保存前先预览，避免名称过长或 Logo 过大。");
  push('[data-view="messages"]', "通知配置要匹配角色", "只有勾选角色且由真实事件触发的通知才会发送；通知不是审核结论，不能代替复核。规则发布、补证、报告完成等事件要分别配置。");
  return steps;
}
let _onboardPending = false, _onboardKeyHandler = null;
/* T-108：首次引导只在首页渲染（当前视图=首页且无其它页面直达哈希）；切页/完成/跳过都不残留 DOM 与遮罩。 */
function _onboardHomeContext() {
  // 只按当前视图判断：直达 URL 的哈希会在身份加载后被 applyHashViewRoute 解析成实际视图，
  // 因此非首页直达时 currentView 已不是 home，引导不会盖住业务页面。
  return ((typeof currentView === "string" && currentView) || "home") === "home";
}
function _onboardCleanupDom() {
  const ov = document.querySelector("#onboard-overlay");
  if (ov) ov.remove();
  document.querySelectorAll(".onboard-spot").forEach(x => x.remove());
  if (_onboardKeyHandler) {
    document.removeEventListener("keydown", _onboardKeyHandler);
    _onboardKeyHandler = null;
  }
}
function _onboardMarkDone() {
  try { fetch("/api/v1/me/onboarded", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }); } catch (e) {}
  if (_onboardUser) _onboardUser.onboarded_at = _onboardUser.onboarded_at || new Date().toISOString();
}
/* 收起引导（切页/跳过/完成/点遮罩/Esc 同一出口）：默认记“已完成”，避免每次回首页反复拦截。 */
function _onboardDismiss() {
  const had = !!(document.querySelector("#onboard-overlay") || document.querySelectorAll(".onboard-spot").length);
  const wasPending = _onboardPending;
  _onboardPending = false;
  if (!had) {
    if (wasPending && _onboardUser) _onboardMarkDone();  // 引导已排队但用户已切页：视为已看过，避免回首页再弹
    _onboardUser = null;
    return false;
  }
  _onboardCleanupDom();
  _onboardMarkDone();
  _onboardSteps = []; _onboardIndex = 0; _onboardUser = null;
  return true;
}
function _onboardRender() {
  const steps = _onboardSteps;
  if (!steps.length) return;
  if (!_onboardHomeContext()) { _onboardPending = true; return; }   // 不在首页绝不渲染（含强制重看）
  let ov = document.querySelector("#onboard-overlay");
  if (!ov) {
    ov = document.createElement("div");
    ov.id = "onboard-overlay";
    ov.setAttribute("role", "dialog");
    ov.setAttribute("aria-modal", "true");
    ov.innerHTML = '<div class="onboard-card">'
      + '<button type="button" id="onboard-close" aria-label="跳过引导" title="跳过引导" style="position:absolute;top:6px;right:8px;width:28px;height:28px;min-width:28px;min-height:28px;display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:6px;background:transparent;font-size:18px;line-height:1;color:#8F959E;cursor:pointer">×</button>'
      + '<div class="onboard-kicker">首次使用引导 <span id="onboard-step"></span></div><h3 id="onboard-title"></h3><p id="onboard-text"></p>'
      + '<div class="onboard-actions">'
      +   '<div style="display:flex;align-items:center;gap:8px"><button type="button" class="btn" id="onboard-skip" style="color:#3370FF;font-weight:600">跳过引导</button><span class="muted" style="font-size:11px;color:#8F959E">Esc</span></div>'
      +   '<div><button type="button" class="btn" id="onboard-prev" aria-label="上一步">上一步</button><button type="button" class="btn primary" id="onboard-next">下一步</button></div>'
      + '</div></div>';
    document.body.appendChild(ov);
    ov.querySelector("#onboard-skip").onclick = () => _onboardFinish();
    ov.querySelector("#onboard-close").onclick = () => _onboardFinish();
    ov.querySelector("#onboard-prev").onclick = () => { if (_onboardIndex > 0) { _onboardIndex--; _onboardRender(); } };
    ov.querySelector("#onboard-next").onclick = () => {
      if (_onboardIndex >= _onboardSteps.length - 1) { _onboardFinish(); return; }
      _onboardIndex++; _onboardRender();
    };
    // 点遮罩空白处 = 跳过引导（不再“全局拦截点击”）
    ov.addEventListener("click", (e) => { if (e.target === ov) _onboardFinish(); });
    if (_onboardKeyHandler) document.removeEventListener("keydown", _onboardKeyHandler);
    _onboardKeyHandler = (e) => { if (e.key === "Escape") { e.preventDefault(); _onboardFinish(); } };
    document.addEventListener("keydown", _onboardKeyHandler);
  }
  document.querySelectorAll(".onboard-spot").forEach(x => x.remove());
  const step = steps[_onboardIndex];
  const target = step.target ? _onboardTargetVisible(step.target) : null;
  const card = ov.querySelector(".onboard-card");
  ov.querySelector("#onboard-step").textContent = `${_onboardIndex + 1} / ${steps.length}`;
  ov.querySelector("#onboard-title").textContent = step.title;
  ov.querySelector("#onboard-text").textContent = step.text;
  ov.querySelector("#onboard-prev").style.visibility = _onboardIndex ? "visible" : "hidden";
  ov.querySelector("#onboard-next").textContent = _onboardIndex >= steps.length - 1 ? "开始使用" : "下一步";
  if (target) {
    const r = target.getBoundingClientRect();
    const spot = document.createElement("div");
    spot.className = "onboard-spot";
    spot.style.cssText = `left:${Math.max(4, r.left - 4)}px;top:${Math.max(4, r.top - 4)}px;width:${Math.max(40, r.width + 8)}px;height:${Math.max(28, r.height + 8)}px;`;
    document.body.appendChild(spot);
    const cw = 330, ch = 210;
    let left = r.right + 16, top = r.top;
    if (left + cw > window.innerWidth - 12) left = Math.max(12, r.left - cw - 16);
    top = Math.min(Math.max(12, top), window.innerHeight - ch - 12);
    card.style.left = left + "px"; card.style.top = top + "px"; card.style.transform = "none";
  } else {
    card.style.left = "50%"; card.style.top = "50%"; card.style.transform = "translate(-50%,-50%)";
  }
}
async function _onboardFinish() {
  const _pwdFocus = _onboardUser && _onboardUser.must_change_pwd && !document.querySelector("#pwd-form")?.hidden;
  _onboardDismiss();
  if (_pwdFocus) document.querySelector("#pwd-old")?.focus();
}
function maybeShowOnboarding(u, force) {
  if (!u || !u.sub) return;
  if (!force && u.onboarded_at) return;
  if (document.querySelector("#onboard-overlay")) return;
  if (u.must_change_pwd && !force) return;
  // 只在首页显示：其它页面（含直达 #conflict/#ontology）不弹；离开后切回首页再补展示（force 场景）。
  if (!_onboardHomeContext()) { _onboardPending = true; _onboardUser = u; return; }
  _onboardPending = false;
  _onboardUser = u;
  _onboardSteps = _onboardStepsFor(u);
  _onboardIndex = 0;
  if (!_onboardSteps.length) return;
  setTimeout(_onboardRender, 280);
}
/* 强制重看（改密后等）落到非首页时暂存，回到首页再展示，避免引导盖住当前业务页面。 */
function _onboardMaybeShowPending() {
  if (!_onboardPending || !_onboardUser) return;
  if (document.querySelector("#onboard-overlay")) return;
  if (!_onboardHomeContext()) return;
  const u = _onboardUser;
  maybeShowOnboarding(u, true);
}
function normalizeSidebarAccount() {
  // 旧页面缓存中可能还残留左下角“账号设置”；账号设置入口统一在左侧系统菜单。
  document.querySelectorAll(".sidebar-account .sa-btn, .sidebar-account [id='btn-change-pwd']").forEach(el => {
    if (!el.closest || !el.closest(".sa-actions")) return;
    const txt = (el.textContent || "").trim();
    if (txt === "账号设置" || el.id === "btn-change-pwd") el.remove();
  });
}

async function loadUser() {
  const _portal = window.__PORTAL__ || "";
  try {
    const r = await fetch("/api/v1/me");
    if (!r.ok) { window.location.href = _portal ? `/${_portal}/login` : "/login"; return; }
    const u = (await r.json()).user;
    const _valid = _portal === "admin" ? ["super_admin", "admin"].includes(u.role)
      : _portal === "reviewer" ? u.role === "reviewer"
      : true;
    if (!_valid) {
      window.location.replace(u.role === "reviewer" ? "/reviewer" : u.role === "platform_op" ? "/platform" : "/admin");
      return;
    }
    currentUser = u; currentRole = u.role;
    applyReviewerUi();
    try {
      const pr = await (await fetch("/api/v1/me/permissions")).json();
      applyPermissions(pr);
    } catch (e) {}
    try { startEvents(); } catch (e) {}
    window.__roles = u.roles || [u.role];
    window.__role = u.role;
    renderIdentity(u);
    normalizeSidebarAccount();
    maybePromptIdentity(u);
    const _un = $("#user-name"); if (_un) _un.textContent = u.name || u.username || u.sub;
    const _pn = $("#p-name"); if (_pn) _pn.value = u.name || "";
    const _pe = $("#p-email"); if (_pe) _pe.value = u.email || "";
    const _pp = $("#p-phone"); if (_pp) _pp.value = u.phone || "";
    // 审核员：姓名/手机号/邮箱由管理员配置，只读；仅能改密码
    const isRev = u.role === "reviewer";
    ["#p-name", "#p-email", "#p-phone"].forEach(sel => {
      const el = document.querySelector(sel);
      if (el) { el.readOnly = isRev; el.classList.toggle("readonly", isRev); }
    });
    const saveBtn = document.querySelector("#btn-save-profile");
    if (saveBtn) saveBtn.style.display = isRev ? "none" : "";
    const hint = document.querySelector("#profile-readonly-hint");
    if (hint) hint.style.display = isRev ? "" : "none";

    $("#p-created").textContent = u.created_at || "—";
    $("#p-role").textContent = ({ super_admin: "系统管理员", admin: "业务管理员", reviewer: "审核员" })[u.role] || u.role;
    await applyRole();
    // 菜单权限二次应用：角色确定后重算 data-perm / data-super-only，避免首帧按未加载身份隐藏。
    try { loadPermissions(); } catch (e) {}
    // 平台运维只做租户/用量治理：登录直接进入开放平台控制台，避免落到空白业务首页
    if (u.role === "platform_op") {
      // 平台管理员只使用独立平台端 /platform；不再混进企业业务首页或开放平台
      window.location.replace("/platform");
      return;
    }
    if (u.role === "super_admin") {
      // 系统管理员无租户空间：管理端不出现空间选择器
      document.querySelectorAll(".menu-ws").forEach(el => el.style.display = "none");
      const _wsb0 = document.querySelector("#ws-badge"); if (_wsb0) _wsb0.hidden = true;
    }
    // 系统管理员不处理业务消息；业务管理员需要接收待确认反馈
    const _after = sessionStorage.getItem('rp_after_switch');
    // K1（L40 2026-11-24 P1）：boot 必须先解析直达/刷新 hash，再兜底渲染首页。
    // 旧顺序 showView("home") 在 applyHashViewRoute() 之前，而 showView 内部
    // history.pushState 会把 URL 的 #<view> 改写成 #home，后续解析只能读到 #home
    // → 刷新/深链永远回首页（L22 build44 复现：hash_before=#rules → hash_after=#home）。
    // 修法：有合法且未受限的 hash 视图时直接渲染该视图；否则才 showView("home")。
    // 受限 hash 也必须在渲染首页后立刻交给 T-111 守卫给出「无权限」说明：
    // showView("home") 会 pushState 写 #home，若此时才让下方 applyHashViewRoute 读 hash，
    // 受限 hash 已被覆盖、说明丢失（本文件 HEAD 新增的 direct-url-denied 节点实测）。
    let _hashRouted = false;
    if (u.must_change_pwd) { showView("home"); openProfile(true); }
    else if (_after) { sessionStorage.removeItem('rp_after_switch'); showView(_after); }
    // E-07（DuMate 20261118 / dumate-fix 20/20 复现）：boot 窗口 104–149ms 内用户已点菜单时，
    // 这里无条件 showView("home") 会把用户导航覆盖回首页（视图先切走再被改回）。
    // 修法：用 _bootUserNavigated 显式标记，只在「用户未主动导航」时兜底渲染首页。
    // 注意：不能用 !currentView 判断——currentView 初始值就是 "home"，恒 truthy，
    // 会导致普通登录（无 hash）首屏空白（dumate-regress 2026-11-18 实测三端复现）。
    else if (!_bootUserNavigated) {
      const _hashView = viewIdFromHash();
      if (_hashView && !roleViewDenied(_hashView)) { _hashRouted = true; showView(_hashView); }
      else if (_hashView) {
        // 受限视图直达：先在首页可见的前提下还原 hash，再由统一守卫给出「无权限」说明。
        showView("home");
        try { history.replaceState({ view: "home" }, "", "#" + _hashView); } catch (e) {}
        _hashRouted = true;
        try { applyHashViewRoute(); } catch (e) {}
      } else showView("home");
    }
    // T-111：身份加载完成后再处理直达 URL（#view）：受限视图由 roleViewDenied 拒绝并给出说明，不渲染。
    if (!u.must_change_pwd && !_hashRouted) { try { applyHashViewRoute(); } catch (e) {} }
    setTimeout(function(){ ensureWorkspaceSetupGate(); }, 500);
    setTimeout(() => maybeShowOnboarding(u), 450);
  } catch (e) { console.error("loadUser failed:", e && e.stack || e); }
}
function openProfile(force) {
  const panel = $("#profile-panel");
  panel.hidden = false;
  $("#btn-profile").classList.add("active");
  if (force) { $("#pwd-form").hidden = false; $("#pwd-msg").textContent = "首次登录请修改密码后再继续"; }
}
function closeProfile() {
  $("#profile-panel").hidden = true;
  $("#btn-profile").classList.remove("active");
}
$("#btn-profile")?.addEventListener("click", (e) => { e.stopPropagation(); const p = $("#profile-panel"); p.hidden ? openProfile() : closeProfile(); });
document.addEventListener("click", (e) => {
  if (!e.target.closest(".user-menu")) { $("#profile-panel").hidden = true; $("#btn-profile").classList.remove("active"); }
});
function openPwdDialog(){ const f=$("#pwd-form"); if(!f) return; f.hidden=false; $("#pwd-msg").textContent=""; $("#pwd-old").focus(); }
function closePwdDialog(){ const f=$("#pwd-form"); if(f) f.hidden=true; }function openAccountSettings() {
  const old = document.querySelector("#account-settings-modal"); if (old) old.remove();
  fetch("/api/v1/me").then(r => r.json()).then(me => {
    const u = me.user || {};
    const isRev = u.role === "reviewer";
    const mask = document.createElement("div");
    mask.id = "account-settings-modal"; mask.className = "modal-mask";
    mask.innerHTML = `<div class="modal" style="width:min(560px,calc(100vw - 32px))">
      <div class="settings-head"><h3>账号设置</h3><button type="button" class="ws-close" data-as-close aria-label="关闭">×</button></div>
      <div class="settings-section"><div class="settings-title">个人信息</div>
        <div class="settings-grid">
          <label class="np-field"><span>姓名</span><input id="as-name" class="field" value="${esc(u.name || "")}" ${isRev ? "readonly" : ""}></label>
          <label class="np-field"><span>手机号</span><input id="as-phone" class="field" value="${esc(u.phone || u.username || "")}" readonly></label>
          <label class="np-field wide"><span>邮箱（选填，可用于登录）</span><input id="as-email" class="field" value="${esc(u.email || "")}" placeholder="可留空"></label>
        </div>
        <div class="actions" style="margin-top:10px"><button class="btn primary" id="as-save-profile">${isRev ? "保存邮箱" : "保存个人信息"}</button>${isRev ? '<span class="muted">姓名由管理员配置；邮箱可修改，也可清空。</span>' : '<span class="muted">手机号绑定账号，不可修改；邮箱可用于登录。</span>'}<span id="as-profile-msg" class="muted"></span></div>
      </div>
      <div class="settings-section"><div class="settings-title">修改密码</div>
        <div class="settings-grid">
          <label class="np-field wide"><span>当前密码</span><input id="as-old" type="password" class="field" autocomplete="current-password"></label>
          <label class="np-field"><span>新密码（至少 8 位）</span><input id="as-new" type="password" class="field" autocomplete="new-password"></label>
          <label class="np-field"><span>确认新密码</span><input id="as-new2" type="password" class="field" autocomplete="new-password"></label>
        </div>
        <div class="actions" style="margin-top:10px"><button class="btn primary" id="as-save-pwd">修改密码</button><span id="as-pwd-msg" class="muted"></span></div>
      </div>
      <div class="settings-foot"><button class="btn" data-as-close>关闭</button></div>
    </div>`;
    document.body.appendChild(mask);
    const close = () => mask.remove();
    mask.querySelectorAll("[data-as-close]").forEach(b => b.onclick = close);
    mask.onclick = (e) => { if (e.target === mask) close(); };
    mask.querySelector("#as-save-profile")?.addEventListener("click", async () => {
      const msg = mask.querySelector("#as-profile-msg"); msg.textContent = "保存中…";
      const r = await (await fetch("/api/v1/me/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: mask.querySelector("#as-name").value.trim(), email: mask.querySelector("#as-email").value.trim() }) })).json();
      const _af = apiFail(r);
      if (_af) { msg.textContent = _af; return; }
      $("#user-name").textContent = mask.querySelector("#as-name").value.trim() || $("#user-name").textContent;
      msg.textContent = "已保存"; showToast("个人信息已保存");
    });
    mask.querySelector("#as-save-pwd").addEventListener("click", async () => {
      const msg = mask.querySelector("#as-pwd-msg");
      const oldp = mask.querySelector("#as-old").value, np = mask.querySelector("#as-new").value, np2 = mask.querySelector("#as-new2").value;
      if (np.length < 8) { msg.textContent = "新密码至少 8 位"; return; }
      if (np !== np2) { msg.textContent = "两次新密码不一致"; return; }
      msg.textContent = "保存中…";
      const r = await fetch("/api/v1/me/password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ old_password: oldp, new_password: np }) });
      if (!r.ok) { const d = await r.json().catch(() => ({})); msg.textContent = d.error || "修改失败"; return; }
      msg.textContent = "密码已修改"; showToast("密码已修改");
      try {
        const me = (await (await fetch("/api/v1/me")).json()).user;
        currentUser = me; me.must_change_pwd = false;
        maybeShowOnboarding(me, true);
      } catch (e) {}
    });
  }).catch(() => showToast("账号信息读取失败", "err"));
}

document.querySelector("#menu-account")?.addEventListener("click", (e) => { e.preventDefault(); openAccountSettings(); });
$("#btn-change-pwd")?.addEventListener("click", openAccountSettings);
document.querySelectorAll("#btn-cancel-pwd,#btn-cancel-pwd2").forEach(b=>{ if(b) b.onclick=closePwdDialog; });
$("#btn-save-pwd")?.addEventListener("click", async () => {
  const oldp = $("#pwd-old").value, np = $("#pwd-new").value, np2 = $("#pwd-new2").value;
  const msg = $("#pwd-msg");
  if (np.length < 8) { msg.textContent = "新密码至少 8 位"; return; }
  if (np !== np2) { msg.textContent = "两次新密码不一致"; return; }
  const r = await fetch("/api/v1/me/password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ old_password: oldp, new_password: np }) });
  if (!r.ok) { const d = await r.json().catch(() => ({})); msg.textContent = d.error || "修改失败"; return; }
  msg.textContent = "密码已修改";
  $("#pwd-old").value = ""; $("#pwd-new").value = ""; $("#pwd-new2").value = "";
  try {
    const me = (await (await fetch("/api/v1/me")).json()).user;
    currentUser = me;
    setTimeout(() => maybeShowOnboarding(me, true), 300);
  } catch (e) {}
  $("#pwd-form").hidden = true;
});
$("#btn-quick-new")?.addEventListener("click", () => showView("newproject"));

/* ===================== 事件 ===================== */
$("#btn-new-project")?.addEventListener("click", () => showView("newproject"));
$("#btn-create-project")?.addEventListener("click", () => createProject());

$("#btn-run-audit")?.addEventListener("click", runAudit);
$("#file")?.addEventListener("change", async (e) => {
  const f = e.target.files[0]; if (!f || !currentProjectId) return;
  const buf = await f.arrayBuffer();
  let bin = ""; const arr = new Uint8Array(buf); const chunk = 0x8000;
  for (let i = 0; i < arr.length; i += chunk) bin += String.fromCharCode.apply(null, arr.subarray(i, i + chunk));
  const b64 = btoa(bin);
  const r = await (await fetch(`/api/v1/projects/${currentProjectId}/documents`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ filename: f.name, data: b64 }) })).json();
  const _af = apiFail(r);
  if (_af) { alert("上传失败：" + _af); return; }
  e.target.value = "";
  await openProject(currentProjectId);
  // 解析结果 → 决定是否自动/继续审核
  const docs = await (await fetch(`/api/v1/projects/${currentProjectId}/documents`)).json();
  const doc = docs.find(d => d.id === r.document_id) || {};
  if (doc.parse_status === "ok") {
    await runAuditAsync(currentProjectId);
  } else if (doc.parse_status === "partial") {
    if (confirm(`解析不完整：${doc.parse_summary || ""}\n是否以已解析内容继续审核？`)) {
      await runAuditAsync(currentProjectId);
    }
  } else {
    alert("解析失败：" + (doc.parse_summary || "请重传可检索版本"));
  }
});

loadUser();

/* ===================== 账号管理 ===================== */
const userState = { page: 0, size: 20, total: 0 };
function confirmAction(title, text, okLabel, danger) {
  return new Promise(resolve => {
    const old = document.querySelector("#confirm-action-modal"); if (old) old.remove();
    const mask = document.createElement("div");
    mask.id = "confirm-action-modal"; mask.className = "modal-mask";
    mask.innerHTML = `<div class="modal" style="width:min(420px,calc(100vw - 32px))">
      <h3 style="margin:0 0 8px">${esc(title)}</h3>
      <div class="muted" style="font-size:13px;line-height:1.7">${esc(text)}</div>
      <div class="actions" style="margin-top:18px;justify-content:flex-end">
        <button class="btn" data-cancel>取消</button>
        <button class="btn ${danger ? "" : "primary"}" data-ok style="${danger ? "color:#D83931;border-color:#F5C2C0" : ""}">${esc(okLabel || "确认")}</button>
      </div></div>`;
    document.body.appendChild(mask);
    const done = v => { mask.remove(); resolve(v); };
    mask.querySelector("[data-cancel]").onclick = () => done(false);
    mask.querySelector("[data-ok]").onclick = () => done(true);
    mask.onclick = e => { if (e.target === mask) done(false); };
  });
}
async function loadUsers(reset) {
  if (reset) userState.page = 0;
  uxSetLoading("#user-list", "正在加载账号…", 4);
  uxFiltersRestoreOnce("users");
  const myRole = String(currentRole || "").replace(/^role-/, "");
  const myId = (currentUser && (currentUser.sub || currentUser.id)) || "";
  const allow = myRole === "super_admin" ? ["super_admin", "admin", "reviewer"] : [];
  const roleBox = $("#nu-roles");
  if (roleBox) {
    const LABEL = { super_admin: "系统管理员", admin: "业务管理员", reviewer: "审核员" };
    roleBox.innerHTML = allow.map(r => `<label><input type="radio" name="nu-role" value="${r}" ${r === "admin" ? "checked" : ""}> ${LABEL[r] || r}</label>`).join("") || '<span class="muted">当前角色不能开通账号</span>';
  }
  const q = ($("#user-q")?.value || "").trim(), role = $("#user-role")?.value || "", status = $("#user-status")?.value || "";
  const qs = new URLSearchParams({ page: String(userState.page + 1), page_size: String(userState.size) });
  if (q) qs.set("q", q); if (role) qs.set("role", role); if (status) qs.set("status", status);
  let d;
  try { d = await (await fetch("/api/v1/users?" + qs.toString())).json(); }
  catch (e) {
    uxSetEmpty("#user-list", { title: "账号加载失败", desc: "请检查网络后重试；不会修改任何账号。", action: { label: "重新加载", action: "reset:users" } });
    $("#user-pager").innerHTML = "";
    return;
  }
  if (d && d.error) {
    uxSetEmpty("#user-list", { title: "账号加载失败", desc: String(d.error), action: { label: "清空筛选", action: "reset:users" } });
    $("#user-pager").innerHTML = "";
    return;
  }
  const list = Array.isArray(d) ? d : ((d && d.items) || []);
  userState.total = Array.isArray(d) ? list.length : ((d && d.total) || 0);
  const canManage = (tr) => myRole === "super_admin";
  const _target = { super_admin: "系统管理员", admin: "业务管理员", reviewer: "审核员" };
  $("#user-list").innerHTML = list.length ? `<div class="table-wrap"><table class="table user-table"><thead><tr>
      <th style="width:52px">序号</th><th>姓名</th><th>部门</th><th>手机号</th><th>邮箱</th><th>角色</th><th>状态</th><th>最近登录</th><th>开通日期</th><th class="actions-cell">操作</th></tr></thead><tbody>` +
    list.map((u, i) => {
      const can = canManage(u.role);
      const blocked = u.manage_blocked_reason || "";
      const self = !!u.is_self || String(u.id) === String(myId);
      const initAcct = !!u.initial_account || !!u.is_initial;
      const statusTone = u.status !== "active" ? "draft" : (u.must_change_pwd ? "r" : "published");
      const statusText = u.status_label || (u.status !== "active" ? "停用" : (u.must_change_pwd ? "待改密" : "启用"));
      const statusCell = u.status === "active" && u.must_change_pwd
        ? `<span class="pwd-pending"><span class="pill r">待改密</span><span class="muted" style="font-size:10px">首次登录需改密</span></span>`
        : `<span class="pill ${statusTone}">${esc(statusText)}</span>`;
      const ops = can ? `<div class="actions" style="justify-content:flex-end;flex-wrap:wrap">
          <button class="btn" data-edit-user="${esc(u.id)}" data-name="${esc(u.name)}" data-phone="${esc(u.phone || "")}" data-department="${esc(u.department || "")}" data-email="${esc(u.email || "")}">编辑</button>
          <button class="btn" data-login-history="${esc(u.id)}" data-uname="${esc(u.name)}">登录历史</button>
          <button class="btn" data-reset="${esc(u.id)}" data-uname="${esc(u.name)}" data-uphone="${esc(u.phone || "")}">重置密码</button>
          ${(self || initAcct)
            ? `<button class="btn" disabled title="${esc(blocked || "不可操作")}">${u.status === "active" ? "停用" : "启用"}</button><button class="btn" disabled title="${esc(blocked || "不可操作")}">删除</button><div class="blocked-reason" title="${esc(blocked)}">${esc(self ? "自身账号不可停用/删除" : "内置初始账号不可停用/删除")}</div>`
            : `<button class="btn" data-status="${esc(u.id)}" data-cur="${u.status}">${u.status === "active" ? "停用" : "启用"}</button><button class="btn" data-del-user="${esc(u.id)}" data-name="${esc(u.name)}" data-phone="${esc(u.phone || "")}">删除</button>`}
        </div>` : `<span class="muted" title="仅系统管理员可管理账号">—</span>`;
      return `<tr>
      <td class="muted">${userState.total - (userState.page * userState.size + i)}</td>
      <td><b>${esc(u.name)}</b></td><td>${esc(u.department || '—')}</td><td>${esc(u.phone || '—')}</td><td>${esc(u.email || '—')}</td>
      <td><span class="pill ${u.role === 'reviewer' ? 'r' : 'published'}">${esc(u.role_label || _target[u.role] || u.role)}</span></td>
      <td>${statusCell}</td><td class="muted">${esc((u.last_login || "").replace("T", " ").slice(0, 16) || "—")}</td>
      <td class="muted">${esc(String(u.created_at || '').slice(0, 10))}</td>
      <td class="actions-cell">${ops}</td></tr>`;
    }).join("") + `</tbody></table></div>` + (d && d.initial_password_policy ? `<div class="muted" style="font-size:11px;margin-top:6px">${esc(d.initial_password_policy)}</div>` : "") : uxEmptyHTML({
      title: "没有符合条件的账号",
      desc: "调整关键词、角色或状态筛选后重试。",
      action: { label: "清空筛选", action: "reset:users" },
    });
  const pages = Math.max(1, Math.ceil(userState.total / userState.size));
  $("#user-pager").innerHTML = `<div class="pager"><span>共 ${userState.total} 个账号 <span class="scope-chip">本租户</span></span>
    <select id="user-size" class="field">${[10,20,50,100].map(n => `<option value="${n}" ${n === userState.size ? "selected" : ""}>${n} 条/页</option>`).join("")}</select>
    <button id="user-prev" class="btn" ${userState.page <= 0 ? "disabled" : ""}>上一页</button><span>第 ${userState.page + 1} / ${pages} 页</span>
    <button id="user-next" class="btn" ${userState.page >= pages - 1 ? "disabled" : ""}>下一页</button></div>`;
  $("#user-size").onchange = (e) => { userState.size = parseInt(e.target.value); userState.page = 0; loadUsers(false); };
  $("#user-prev").onclick = () => { if (userState.page > 0) { userState.page--; loadUsers(false); } };
  $("#user-next").onclick = () => { if (userState.page < pages - 1) { userState.page++; loadUsers(false); } };
  document.querySelectorAll("[data-edit-user]").forEach(b => b.addEventListener("click", () => {
    $("#ue-name").value = b.dataset.name || "";
    $("#ue-department").value = b.dataset.department || "";
    $("#ue-email").value = b.dataset.email || ""; $("#ue-msg").textContent = "";
    $("#ue-save").dataset.uid = b.dataset.editUser; $("#user-edit").hidden = false;
  }));
  document.querySelectorAll("[data-login-history]").forEach(b => b.addEventListener("click", () => openUserLoginHistory(b.dataset.loginHistory, b.dataset.uname || "")));
  document.querySelectorAll("[data-reset]").forEach(b => b.addEventListener("click", async () => {
    if (!(await confirmAction("重置密码", "确认重置该账号密码？重置后首次登录需要修改密码；临时密码只展示一次。", "确认重置"))) return;
    const r = await (await fetch(`/api/v1/users/${b.dataset.reset}/reset-password`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    const _af = apiFail(r);
    if (_af) { showToast(_af, "err"); return; }
    showTemporaryPassword(r, b.dataset.uname || "该账号", b.dataset.uphone || "");
    loadUsers(false);
  }));
  document.querySelectorAll("[data-status]").forEach(b => b.addEventListener("click", async () => {
    const next = b.dataset.cur === "active" ? "disabled" : "active";
    if (!(await confirmAction(next === "disabled" ? "停用账号" : "启用账号",
      next === "disabled" ? "确认停用该账号？停用后该账号不能登录，历史数据保留。" : "确认启用该账号？",
      next === "disabled" ? "确认停用" : "确认启用", next === "disabled"))) return;
    const r = await (await fetch(`/api/v1/users/${b.dataset.status}/status`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: next }) })).json();
    const _af = apiFail(r);
    if (_af) { showToast(_af, "err"); return; }
    showToast(next === "disabled" ? "账号已停用" : "账号已启用"); loadUsers(false);
  }));
  document.querySelectorAll("[data-del-user]").forEach(b => b.addEventListener("click", async () => {
    if (!(await confirmAction("删除账号", `确认删除账号「${b.dataset.name}」（${b.dataset.phone}）？删除后该手机号可重新开通，历史审计保留。`, "确认删除", true))) return;
    const r = await (await fetch(`/api/v1/users/${b.dataset.delUser}/delete`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    const _af = apiFail(r);
    if (_af) { showToast(_af, "err"); return; }
    showToast("账号已删除"); loadUsers(false);
  }));
}
async function openUserLoginHistory(uid, name) {
  const old = document.getElementById("login-history-modal"); if (old) old.remove();
  const mask = document.createElement("div");
  mask.id = "login-history-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(760px,calc(100vw - 24px))"><div class="settings-head"><h3>登录历史 · ${esc(name || uid)}</h3><button class="ws-close" data-lh-close>×</button></div>
    <div id="login-history-body"><div class="muted" style="padding:16px 0">加载中…</div></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-lh-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  const body = mask.querySelector("#login-history-body");
  try {
    const r = await fetch(`/api/v1/users/${encodeURIComponent(uid)}/login-history`);
    const d = await r.json();
    if (!r.ok || d.error) { body.innerHTML = `<div class="empty">${esc(d.error || ("HTTP " + r.status))}</div>`; return; }
    const items = d.items || [];
    body.innerHTML = `<div class="muted" style="font-size:11.5px;line-height:1.7;margin:0 0 8px">
      最近登录：<b>${esc(d.last_login || "—")}</b> · 会话模型：${esc(d.session_model || "—")}
      <span class="pill ${d.active_sessions_supported ? "published" : "draft"}">${d.active_sessions_supported ? "支持活跃会话" : "活跃会话未支持"}</span>
      <div>${esc(d.active_sessions_note || "")}</div></div>` +
      (items.length ? `<div class="table-wrap"><table class="table" style="min-width:640px"><thead><tr><th>时间</th><th>事件</th><th>IP</th><th>请求编号</th></tr></thead><tbody>` +
        items.map(x => `<tr><td class="muted">${esc((x.created_at || "").replace("T", " ").slice(0, 19))}</td><td><b>${esc(x.action_label || x.action)}</b></td><td class="muted">${esc(x.ip || "—")}</td><td class="muted">${esc(x.request_id || "—")}</td></tr>`).join("") +
        `</tbody></table></div>` : '<div class="empty">暂无登录历史记录（audit_log 中没有该账号的登录/改密事件）</div>');
  } catch (e) {
    body.innerHTML = '<div class="empty">登录历史加载失败（网络错误）</div>';
  }
}
function showTemporaryPassword(r, target, phone = "", modalTitle = "密码已重置") {
  const mask = document.querySelector("#pwd-result-modal");
  if (!mask) { showToast("密码：" + (r.temporary_password || "") + "（首次登录需改密）"); return; }
  const value = r.temporary_password || "";
  mask.hidden = false;
  const _h = mask.querySelector(".settings-head h3"); if (_h) _h.textContent = modalTitle;
  const body = mask.querySelector("#pwd-result-body");
  body.innerHTML = `<div class="pwd-meta">账号：<b>${esc(target)}</b>${phone ? " · " + esc(phone) : ""}</div>
    <div class="pwd-value"><span>${esc(value)}</span><button class="btn" data-copy-pwd>复制密码</button></div>
    <div class="pwd-meta">有效期至：${esc(r.expires_at || "未记录")}<br>首次登录后必须修改密码；修改成功后临时密码会自动失效。</div>
    <div class="actions" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" data-close-pwd>我已记录</button></div>`;
  const close = () => { mask.hidden = true; body.innerHTML = ""; };
  mask.querySelectorAll("[data-close-pwd]").forEach(x => x.onclick = close);
  body.querySelector("[data-copy-pwd]")?.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(value); showToast("临时密码已复制"); }
    catch (e) { const ta = document.createElement("textarea"); ta.value = value; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); showToast("临时密码已复制"); }
  });
}
async function openPwdResetLog() {
  const mask = document.querySelector("#pwd-reset-modal");
  if (!mask) return;
  mask.hidden = false;
  const list = mask.querySelector("#pwd-reset-list");
  list.innerHTML = '<div class="muted" style="padding:16px 0">加载中…</div>';
  const r = await (await fetch("/api/v1/password-resets")).json();
  const _af = apiFail(r);
  if (_af) { list.innerHTML = `<div class="pwd-empty">${esc(_af)}</div>`; return; }
  const items = r.items || [];
  list.innerHTML = items.length ? `<table class="table pwd-record-table"><thead><tr><th>时间</th><th>账号</th><th>手机号</th><th>临时密码</th><th>状态</th><th>有效期至</th><th>操作人</th></tr></thead><tbody>` +
    items.map(x => `<tr><td class="muted">${esc((x.created_at || "").slice(0, 16))}</td><td><b>${esc(x.name || x.user_id || "—")}</b></td><td>${esc(x.phone || "—")}</td>
      <td><span class="pwd-temp">${x.temp_password ? esc(x.temp_password) : "—"}</span>${x.temp_password ? ' <button class="btn" data-copy-log="'+esc(x.temp_password)+'">复制</button>' : ""}</td>
      <td><span class="pill ${x.status === "待使用" ? "r" : "published"}">${esc(x.status || "—")}</span></td><td class="muted">${esc(x.expires_at || "—")}</td><td class="muted">${esc(x.actor || "—")}</td></tr>`).join("") + `</tbody></table>` : '<div class="pwd-empty">还没有密码重置记录</div>';
  list.querySelectorAll("[data-copy-log]").forEach(b => b.onclick = async () => {
    try { await navigator.clipboard.writeText(b.dataset.copyLog); showToast("临时密码已复制"); } catch (e) { showToast("复制失败，请手动选择", "err"); }
  });
}
$("#pwd-reset-log")?.addEventListener("click", openPwdResetLog);
$("#pwd-result-close")?.addEventListener("click", () => { const m=document.querySelector("#pwd-result-modal"); if(m){m.hidden=true; const b=m.querySelector("#pwd-result-body"); if(b)b.innerHTML="";} });
$("#pwd-reset-close")?.addEventListener("click", () => { const m=document.querySelector("#pwd-reset-modal"); if(m)m.hidden=true; });
$("#btn-new-user")?.addEventListener("click", () => { $("#nu-msg").textContent = ""; $("#user-create").hidden = false; });
$("#btn-cancel-user")?.addEventListener("click", () => { $("#user-create").hidden = true; });
$("#ue-cancel")?.addEventListener("click", () => { $("#user-edit").hidden = true; });
$("#ue-save")?.addEventListener("click", async function () {
  const name = $("#ue-name").value.trim(), email = $("#ue-email").value.trim(), department = $("#ue-department").value.trim();
  if (!name) { $("#ue-msg").textContent = "姓名必填"; return; }
  const r = await (await fetch(`/api/v1/users/${this.dataset.uid}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email, department }) })).json();
  const _af = apiFail(r);
  if (_af) { $("#ue-msg").textContent = _af; return; }
  $("#user-edit").hidden = true; loadUsers(false);
});
$("#user-search")?.addEventListener("click", () => loadUsers(true));
$("#user-reset")?.addEventListener("click", () => { uxFiltersReset("users"); loadUsers(true); });
$("#user-q")?.addEventListener("keydown", (e) => { if (e.key === "Enter") loadUsers(true); });
$("#user-role")?.addEventListener("change", () => loadUsers(true));
$("#user-status")?.addEventListener("change", () => loadUsers(true));
$("#btn-create-user")?.addEventListener("click", async () => {
  const msg = $("#nu-msg");
  const name = $("#nu-name").value.trim(), phone = $("#nu-phone").value.trim(), email = $("#nu-email").value.trim(), department = $("#nu-department").value.trim();
  const roles = [...document.querySelectorAll("#nu-roles input:checked")].map(i => i.value);
  if (!name || !phone) { msg.textContent = "姓名、手机号必填"; return; }
  if (roles.length === 0) { msg.textContent = "请选择账号角色"; return; }
  const r = await (await fetch("/api/v1/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, phone, email, department, roles }) })).json();
  const _af = apiFail(r);
  if (_af) { msg.textContent = _af; return; }
  msg.innerHTML = `已创建：<b>${esc(r.username)}</b>，初始密码已生成`;
  $("#user-create").hidden = true;
  $("#nu-name").value = $("#nu-phone").value = $("#nu-department").value = $("#nu-email").value = "";
  loadUsers(true);
  if (r.initial_password) showTemporaryPassword({temporary_password: r.initial_password, expires_at: "首次登录并修改密码前有效"}, name, phone, "初始密码已生成");
});

/* ===================== 开放平台 ===================== */
const openState = { status: "" };
function openModalMask(id, html) {
  const old = document.getElementById(id); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = id; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(680px,calc(100vw - 32px))">${html}</div>`;
  document.body.appendChild(mask);
  mask.querySelectorAll("[data-om-close]").forEach(b => b.onclick = () => mask.remove());
  mask.onclick = e => { if (e.target === mask) mask.remove(); };
  return mask;
}
/* 开放平台页面已拆到 web/open_platform.js。 */
async function loadNotifyChannels() {
  const list = await (await fetch("/api/v1/notify/channels")).json();
  $("#notify-channels").innerHTML = (list || []).map(c =>
    `<span class="ch"><span class="dot ${c.enabled ? "on" : ""}"></span>${esc(c.name)}</span>`).join("");
}


/* ===================== 按钮级权限 ===================== */
function applyPermissions(perms) {
  const acts = (perms && perms.actions) || [];
  const has = (a) => acts.includes("*") || acts.includes(a);
  const map = {
    "audit.run": ["#btn-run-audit"],
    "project.upload": ["#file"],
    "project.create": ["#btn-new-project", "#btn-create-project", "#btn-quick-new"],
    "user.manage": ["#btn-new-user", "#btn-create-user"],
    "open.manage": ["#btn-new-app", "#btn-create-app"],
    "data.export": ["#export-html", "#export-docx"],
  };
  Object.entries(map).forEach(([action, sels]) => {
    if (!has(action)) sels.forEach(sel => document.querySelector(sel)?.remove());
  });
}


/* 审计日志分页 */
const alState = { page: 0, size: 20, total: 0, logs: [] };
async function loadAuditLogsPaged(reset) {
  if (reset) alState.page = 0;
  uxSetLoading("#auditlog-list", "正在加载审计日志…", 4);
  uxFiltersRestoreOnce("auditlogs");
  const q = ($("#al-q")?.value || "").trim();
  const result = $("#al-result")?.value || "";
  const action = $("#al-action")?.value || "";
  const qs = new URLSearchParams();
  if (q) qs.set("q", q);
  if (result) qs.set("result", result);
  if (action) qs.set("action", action);
  if ($("#al-from")?.value) qs.set("from", $("#al-from").value);
  if ($("#al-to")?.value) qs.set("to", $("#al-to").value);
  qs.set("page", String(alState.page + 1));
  qs.set("page_size", String(alState.size));
  let d;
  try { d = await (await fetch("/api/v1/audit-logs?" + qs.toString())).json(); }
  catch (e) {
    uxSetEmpty("#auditlog-list", { title: "审计日志加载失败", desc: "请检查网络后重试；审计日志只读，不会因刷新改变。", action: { label: "重新加载", action: "reset:auditlogs" } });
    $("#auditlog-pager").innerHTML = "";
    return;
  }
  if (!d || d.error) { uxSetEmpty("#auditlog-list", { title: "审计日志加载失败", desc: String((d && d.error) || "接口返回为空"), action: { label: "清空筛选", action: "reset:auditlogs" } }); $("#auditlog-pager").innerHTML = ""; return; }
  const sel = $("#al-action");
  if (sel && !sel.dataset.ready && d.actions) {
    sel.innerHTML = '<option value="">全部操作</option>' + d.actions.map(a => `<option value="${esc(a.action)}">${esc(a.label)}</option>`).join("");
    sel.dataset.ready = "1";
  }
  // 动作下拉是接口动态生成的：选项就绪后再回填一次；若回填值与本次请求不同，重新取一次。
  uxFiltersRestore("auditlogs");
  if (sel && sel.value && sel.value !== action) { loadAuditLogsPaged(false); return; }
  alState.total = d.total || 0;
  alState.logs = d.logs || [];
  const sum = d.summary || {};
  $("#auditlog-kpis").innerHTML = [
    ["总记录", sum.total != null ? sum.total : alState.total, ""],
    ["成功", sum.success || 0, "ok"],
    ["失败", sum.failed || 0, "bad"],
    ["拒绝", sum.denied || 0, "warn"],
  ].map(([label, value, cls]) => `<div class="auditlog-kpi ${cls}"><b>${value}</b><span>${label}</span></div>`).join("");
  $("#auditlog-list").innerHTML = alState.logs.length ? `<table class="table auditlog-table"><thead><tr>
      <th>时间</th><th>操作人 / 部门</th><th>动作</th><th>对象</th><th>结果</th><th>请求编号</th></tr></thead><tbody>` +
    alState.logs.map((l, i) => {
      const rs = l.result || "success";
      const tone = rs === "failed" ? "draft" : rs === "denied" ? "r" : "published";
      const label = rs === "failed" ? "失败" : rs === "denied" ? "拒绝" : "成功";
      return `<tr data-al-idx="${i}"><td class="muted">${esc((l.created_at || "").replace("T", " ").slice(0, 19))}</td>
        <td><b>${esc(l.actor_name || l.actor || "系统")}</b><div class="muted" style="font-size:11px">${esc(l.actor_department || "—")}</div></td>
        <td><b>${esc(l.action_label || l.action || "—")}</b><div class="muted" style="font-size:11px">${esc(l.action || "")}</div></td>
        <td class="muted">${esc(l.object || "—")}</td><td><span class="pill ${tone}">${label}</span></td>
        <td class="muted">${esc(l.request_id || "—")}</td></tr>`;
    }).join("") + `</tbody></table>` : uxEmptyHTML({
      title: "没有匹配的审计记录",
      desc: "调整关键词、操作、结果或日期范围后重试；审计日志只读。",
      action: { label: "清空筛选", action: "reset:auditlogs" },
    });
  document.querySelectorAll("[data-al-idx]").forEach(tr => tr.addEventListener("click", () => openAuditDetail(alState.logs[Number(tr.dataset.alIdx)])));
  const pages = d.pages || Math.max(1, Math.ceil(alState.total / alState.size));
  $("#auditlog-pager").innerHTML = `<div class="pager"><span>共 ${alState.total} 条 · 只读</span>
    <select id="al-size" class="field">${[10,20,50,100].map(n => `<option value="${n}" ${n === alState.size ? "selected" : ""}>${n} 条/页</option>`).join("")}</select>
    <button id="al-prev" class="btn" ${alState.page <= 0 ? "disabled" : ""}>上一页</button><span>第 ${alState.page + 1} / ${pages} 页</span>
    <button id="al-next" class="btn" ${alState.page >= pages - 1 ? "disabled" : ""}>下一页</button></div>`;
  $("#al-size").onchange = (e) => { alState.size = parseInt(e.target.value); alState.page = 0; loadAuditLogsPaged(false); };
  $("#al-prev").onclick = () => { if (alState.page > 0) { alState.page--; loadAuditLogsPaged(false); } };
  $("#al-next").onclick = () => { if (alState.page < pages - 1) { alState.page++; loadAuditLogsPaged(false); } };
  if (!window.__auditReconcileReady) { window.__auditReconcileReady = true; loadAuditReconcile(); }
}
function openAuditDetail(l) {
  if (!l) return;
  const mask = document.querySelector("#auditlog-detail");
  if (!mask) return;
  mask.hidden = false;
  const pretty = (v) => { try { return JSON.stringify(JSON.parse(v || "{}"), null, 2); } catch (e) { return v || "—"; } };
  mask.querySelector("#auditlog-detail-body").innerHTML = `<div class="audit-detail-grid">
      <div><span>时间</span><b>${esc(l.created_at || "—")}</b></div>
      <div><span>操作人</span><b>${esc(l.actor_name || l.actor || "—")}</b></div>
      <div><span>部门</span><b>${esc(l.actor_department || "—")}</b></div>
      <div><span>IP</span><b>${esc(l.ip || "—")}</b></div>
      <div><span>动作</span><b>${esc(l.action_label || l.action || "—")}</b></div>
      <div><span>对象</span><b>${l.object ? `<button class="btn" style="height:22px;min-height:22px;padding:0 6px;font-size:11px" data-audit-trace="${esc(l.object)}">${esc(l.object)} · 追踪</button>` : "—"}</b></div>
      <div><span>结果</span><b>${esc(l.result || "—")}</b></div>
      <div><span>请求编号</span><b>${esc(l.request_id || "—")}</b></div>
    </div>
    <div class="audit-detail-json"><div>详情</div><pre>${esc(pretty(l.after_json || l.detail || ""))}</pre></div>
    <div class="audit-detail-foot">审计记录只读，不可编辑或删除。对象可点「追踪」查看同一对象的全部记录。</div>`;
  mask.querySelectorAll("[data-audit-trace]").forEach(b => b.addEventListener("click", () => { mask.hidden = true; openAuditTrace(b.dataset.auditTrace); }));
}
/* 审计：坏数据对账（只读；JSON 不可解析 / 请求编号缺失，不自动修复） */
async function loadAuditReconcile() {
  const host = document.querySelector("#auditlog-reconcile");
  if (!host) return;
  try {
    const r = await fetch("/api/v1/audit-logs/reconcile");
    const d = await r.json();
    if (!r.ok || d.error) { host.innerHTML = `<div class="muted" style="padding:6px 0">对账读取失败：${esc(d.error || ("HTTP " + r.status))}</div>`; return; }
    const cov = d.request_id_coverage == null ? "—" : Math.round(d.request_id_coverage * 100) + "%";
    host.innerHTML = `<div class="audit-reconcile">
      <div class="ar-kpi"><b>${d.total || 0}</b><span>本租户审计记录</span></div>
      <div class="ar-kpi"><b>${cov}</b><span>请求编号覆盖率</span></div>
      <div class="ar-kpi"><b>${d.request_id_missing || 0}</b><span>缺请求编号</span></div>
      <div class="ar-kpi"><b>${(d.before_json_invalid || 0) + (d.after_json_invalid || 0)}</b><span>非 JSON 详情字段</span></div>
      <div class="ar-kpi"><b>${d.object_missing || 0}</b><span>缺对象</span></div>
    </div>
    <div class="muted" style="font-size:11px;line-height:1.6;margin:-2px 0 10px">${esc(d.note || "")} 时间窗：${esc((d.scope || {}).window || "全时间")}</div>`;
    if ((d.samples || []).length) {
      host.innerHTML += `<details style="margin:0 0 10px"><summary class="muted" style="cursor:pointer;font-size:11.5px">查看对账样本（${d.samples.length} 条；只读）</summary>
        <div class="table-wrap" style="margin-top:6px"><table class="table" style="min-width:720px"><thead><tr><th>时间</th><th>动作</th><th>对象</th><th>请求编号</th><th>问题字段</th></tr></thead><tbody>` +
        d.samples.map(x => `<tr><td class="muted">${esc(x.created_at || "—")}</td><td>${esc(x.action || "—")}</td><td class="muted">${esc(x.object || "—")}</td><td class="muted">${esc(x.request_id || "—")}</td><td>${(x.bad_fields || []).map(f => `<span class="pill draft">${esc(f)}</span>`).join(" ")}</td></tr>`).join("") +
        `</tbody></table></div></details>`;
    }
  } catch (e) {
    host.innerHTML = '<div class="muted" style="padding:6px 0">对账读取失败（网络错误）</div>';
  }
}
/* 审计：对象追踪（同一 object 的全部记录；只读） */
async function openAuditTrace(obj) {
  if (!obj) return;
  const old = document.getElementById("audit-trace-modal"); if (old) old.remove();
  const mask = document.createElement("div");
  mask.id = "audit-trace-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(820px,calc(100vw - 24px))"><div class="settings-head"><h3>对象追踪 · ${esc(obj)}</h3><button class="ws-close" data-at-close>×</button></div>
    <div id="audit-trace-body"><div class="muted" style="padding:16px 0">加载中…</div></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-at-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  const body = mask.querySelector("#audit-trace-body");
  try {
    const r = await fetch(`/api/v1/audit-logs/trace?object=${encodeURIComponent(obj)}&limit=100`);
    const d = await r.json();
    if (!r.ok || d.error) { body.innerHTML = `<div class="empty">${esc(d.error || ("HTTP " + r.status))}</div>`; return; }
    const items = d.items || [];
    body.innerHTML = `<div class="muted" style="font-size:11.5px;margin:0 0 8px">${esc(d.note || "")} 共 ${d.total || 0} 条</div>` +
      (items.length ? `<div class="table-wrap"><table class="table auditlog-table" style="min-width:760px"><thead><tr><th>时间</th><th>操作人</th><th>动作</th><th>请求编号</th><th>详情</th></tr></thead><tbody>` +
        items.map(x => `<tr><td class="muted">${esc((x.created_at || "").replace("T", " ").slice(0, 19))}</td><td>${esc(x.actor || "系统")}</td><td>${esc(x.action || "—")}</td><td class="muted">${esc(x.request_id || "—")}</td><td class="muted" style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(x.detail || "")}">${esc(x.detail || "—")}</td></tr>`).join("") +
        `</tbody></table></div>` : '<div class="empty">该对象暂无其它审计记录</div>') +
      `<div class="actions" style="margin-top:10px;justify-content:flex-end"><button class="btn" data-at-search>把对象填入搜索框</button><button class="btn primary" data-at-close>关闭</button></div>`;
    body.querySelector("[data-at-search]")?.addEventListener("click", () => {
      const el = document.querySelector("#al-q"); if (el) el.value = obj;
      close(); loadAuditLogsPaged(true);
    });
    body.querySelectorAll("[data-at-close]").forEach(b => b.onclick = close);
  } catch (e) {
    body.innerHTML = '<div class="empty">对象追踪加载失败（网络错误）</div>';
  }
}
$("#auditlog-detail-close")?.addEventListener("click", () => { const m=document.querySelector("#auditlog-detail"); if(m)m.hidden=true; });
/* 模型调用回放弹窗（#llm-replay）：关闭按钮兜底绑定。
   节点穷举测试 P3：按钮可见但全 JS 无绑定，点「关闭」无响应（只能点遮罩）；
   UX_MODAL_SELECTOR 已把 #llm-replay.modal 纳入 Esc/焦点管理，这里补齐显式关闭。 */
$("#llm-replay-close")?.addEventListener("click", () => {
  const m = document.querySelector("#llm-replay"); if (m) m.hidden = true;
});
$("#auditlog-refresh")?.addEventListener("click", () => { loadAuditLogsPaged(false); loadAuditReconcile(); });
$("#al-reset")?.addEventListener("click", () => { uxFiltersReset("auditlogs"); loadAuditLogsPaged(true); });

$("#al-search")?.addEventListener("click", () => loadAuditLogsPaged(true));
$("#al-q")?.addEventListener("keydown", (e) => { if (e.key === "Enter") loadAuditLogsPaged(true); });
$("#al-result")?.addEventListener("change", () => loadAuditLogsPaged(true));
$("#al-action")?.addEventListener("change", () => loadAuditLogsPaged(true));
$("#al-from")?.addEventListener("change", () => loadAuditLogsPaged(true));
$("#al-to")?.addEventListener("change", () => loadAuditLogsPaged(true));

/* ===================== 审核列表（按项目；审核员只看自己，业务管理员看全部） ===================== */
const AUDIT_STATUS_CLASS = { draft: "r", parse_issue: "draft", pending_audit: "r", pending_review: "draft", confirmed: "published", auditing: "draft", audit_failed: "r" };
let maPage = 1;
async function loadMyAudits(page = 1) {
  maPage = page;
  uxSetLoading("#my-audit-list", "正在加载审核记录…", 4);
  uxFiltersRestoreOnce("myaudits");
  const qs = new URLSearchParams({
    status: $("#ma-status")?.value || "",
    q: $("#ma-q")?.value || "",
    from: $("#ma-from")?.value || "",
    to: $("#ma-to")?.value || "",
    page: String(page), page_size: "20",
  });
  let d;
  try { d = await (await fetch(`/api/v1/my-audits?${qs}`)).json(); }
  catch (e) {
    uxSetEmpty("#my-audit-list", { title: "审核记录加载失败", desc: "请检查网络后重试；不会影响已有审核结果。", action: { label: "重新加载", action: "reset:myaudits" } });
    $("#ma-total").textContent = "";
    return;
  }
  if (!d || d.error) {
    uxSetEmpty("#my-audit-list", { title: "审核记录加载失败", desc: String(d.error), action: { label: "清空筛选", action: "reset:myaudits" } });
    $("#ma-total").textContent = "";
    return;
  }
  const rows = (d && d.items) || [];
  $("#ma-total").textContent = `共 ${d.total || 0} 条`;
  const totalRows = d.total || rows.length;
  const startNo = ((d.page || 1) - 1) * (d.page_size || 20);
  $("#my-audit-list").innerHTML = rows.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>项目</th><th>最后审核</th><th>AI 发现</th><th>确认 严重/一般/提示</th><th>待复核</th><th>待补证</th><th>状态</th><th>操作</th></tr></thead><tbody>` +
    rows.map((r, i) => `<tr>
      <td class="muted">${totalRows - (startNo + i)}</td>
      <td><b>${esc(r.name)}</b></td>
      <td class="muted">${esc(r.last_audit_at || '—')}</td>
      <td>${r.ai_total}</td>
      <td><span class="pill draft">${r.confirmed_critical}</span> / <span class="pill r">${r.confirmed_warning}</span> / <span class="pill">${r.confirmed_suspected}</span></td>
      <td>${r.pending_count ? `<span class="pill draft">${r.pending_count}</span>` : 0}</td>
      <td>${r.evidence_count ? `<span class="pill r">${r.evidence_count}</span>` : 0}</td>
      <td><span class="pill ${AUDIT_STATUS_CLASS[r.status] || 'r'}">${esc(r.status_label)}</span></td>
      <td class="actions"><button class="btn" data-open="${esc(r.id)}">查看详情</button>
        <button class="btn" data-edit="${esc(r.id)}">继续编辑</button>
        <button class="btn" data-reaudit="${esc(r.id)}">重新审核</button></td>
    </tr>`).join("") + `</tbody></table>`
    : uxEmptyHTML({
      title: "没有符合条件的审核记录",
      desc: "调整状态、关键词或日期范围后重试。",
      action: { label: "清空筛选", action: "reset:myaudits" },
    });
  renderMaPager(d);
  document.querySelectorAll("#my-audit-list [data-open]").forEach(b => b.addEventListener("click", () => openWorkbench(b.dataset.open)));
  document.querySelectorAll("#my-audit-list [data-edit]").forEach(b => b.addEventListener("click", () => openProject(b.dataset.edit)));
  document.querySelectorAll("#my-audit-list [data-reaudit]").forEach(b => b.addEventListener("click", async () => {
    b.disabled = true; b.textContent = "审核中…";
    try {
      const r = await (await fetch(`/api/v1/projects/${b.dataset.reaudit}/audit-async`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ai_assist: true }) })).json();
      const _af = apiFail(r);
      if (_af) { alert("重新审核失败：" + _af); return; }
      for (let i = 0; i < 60; i++) {
        await new Promise(res => setTimeout(res, 1000));
        const t = await (await fetch(`/api/v1/tasks/${r.task_id}`)).json();
        if (t.status === "failed" || t.status === "timeout" || t.status === "cancelled") { alert("重新审核未完成：" + (t.error || t.status)); break; }
        if (t.status === "done") break;
      }
      await loadMyAudits(maPage);
    } finally {
      b.disabled = false; b.textContent = "重新审核";
    }
  }));
}
function renderMaPager(d) {
  const box = $("#ma-pager");
  if (!box) return;
  const pages = d.pages || 1, cur = d.page || 1;
  if (pages <= 1) { box.innerHTML = ""; return; }
  const btn = (p, label, disabled) => `<button class="btn" ${disabled ? "disabled" : ""} data-pg="${p}">${label}</button>`;
  let nums = "";
  const start = Math.max(1, cur - 2), end = Math.min(pages, start + 4);
  for (let i = start; i <= end; i++) nums += `<button class="btn ${i === cur ? "primary" : ""}" data-pg="${i}">${i}</button>`;
  box.innerHTML = btn(1, "首页", cur === 1) + btn(cur - 1, "上一页", cur === 1) + nums + btn(cur + 1, "下一页", cur === pages) + btn(pages, "末页", cur === pages);
  box.querySelectorAll("[data-pg]").forEach(b => b.addEventListener("click", () => loadMyAudits(Number(b.dataset.pg))));
}
$("#btn-ma-search")?.addEventListener("click", () => loadMyAudits(1));
$("#btn-ma-reset")?.addEventListener("click", () => {
  uxFiltersReset("myaudits");
  loadMyAudits(1);
});
$("#btn-ma-refresh")?.addEventListener("click", loadMyAudits);
$("#ma-status")?.addEventListener("change", loadMyAudits);

/* ===================== 审核工作台（双栏） ===================== */
let currentWb = null, wbTab = "issues", wbFindings = [], wbDocs = [], wbRenderSeq = 0;
let wbPreviewMode = "text", wbCurrentDoc = "";
let wbSev = "", wbReviewed = "";

function openManualFinding(pid) {
  const docs = wbDocs || [];
  const old = document.querySelector("#manual-finding-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "manual-finding-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(620px,calc(100vw - 32px))">
    <div class="settings-head"><h3>手动新增问题</h3><button class="ws-close" data-mf-close>×</button></div>
    <div class="muted" style="font-size:11px;line-height:1.65;margin-bottom:10px">用于记录审核员发现、但现有规则没有审出的问题。提交后会进入待复核问题清单，并作为“漏报信号”进入反馈与规则进化。</div>
    <div class="mf-grid">
      <label class="wide"><span>问题标题 <em class="req">*</em></span><input id="mf-title" class="field" placeholder="例如：验收标准缺少连续运行时长要求"></label>
      <label><span>严重程度</span><select id="mf-severity" class="field"><option value="critical">严重</option><option value="warning" selected>一般</option><option value="suspected">提示</option></select></label>
      <label><span>所属文件</span><select id="mf-doc" class="field">${docs.length ? docs.map((d, i) => `<option value="${esc(d.id)}">${esc(d.filename || ("文件" + (i + 1)))}</option>`).join("") : '<option value="">当前项目暂无文件</option>'}</select></label>
      <label class="wide"><span>原文位置</span><input id="mf-locator" class="field" placeholder="例如：第 3 页 / 第 2 条 / Sheet1!B5"></label>
      <label class="wide"><span>原文摘录</span><textarea id="mf-quote" class="field" style="min-height:58px" placeholder="可选；粘贴能证明问题的原文片段"></textarea></label>
      <label class="wide"><span>原因 / 说明 <em class="req">*</em></span><textarea id="mf-detail" class="field" style="min-height:78px" placeholder="说明为什么这是问题，审核员判断依据是什么"></textarea></label>
    </div>
    <div id="mf-msg" class="muted" style="font-size:11px;margin-top:6px"></div>
    <div class="actions" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-mf-close>取消</button><button class="btn primary" id="mf-save">提交人工问题</button></div>
  </div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-mf-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  mask.querySelector("#mf-save").onclick = async () => {
    const title = mask.querySelector("#mf-title").value.trim();
    const detail = mask.querySelector("#mf-detail").value.trim();
    if (!title) { mask.querySelector("#mf-msg").textContent = "请填写问题标题"; return; }
    if (!detail) { mask.querySelector("#mf-msg").textContent = "请填写原因 / 说明"; return; }
    const btn = mask.querySelector("#mf-save"); btn.disabled = true; btn.textContent = "提交中…";
    const r = await (await fetch("/api/v1/findings", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_id: pid, severity: mask.querySelector("#mf-severity").value, title, detail,
        document_id: mask.querySelector("#mf-doc").value, locator: mask.querySelector("#mf-locator").value.trim(),
        quote: mask.querySelector("#mf-quote").value.trim() }) })).json();
    const _af = apiFail(r);
    if (_af) { mask.querySelector("#mf-msg").textContent = _af; btn.disabled = false; btn.textContent = "提交人工问题"; return; }
    close(); showToast("人工问题已新增，并记入漏报信号"); await openWorkbench(pid);
  };
}
/* 工作台 Sheet 切换/预览：从 app.js 拆出；依赖 wbDocs/wbCurrentDoc/currentWb 等全局。 */
async function loadAgents() {
  const _sc = document.querySelector("#agent-stats-card"); if (_sc) _sc.style.display = "";
  const _mc = document.querySelector("#agent-manage-card"); if (_mc) _mc.style.display = "";
  $("#agent-detail-page").hidden = true;
  $("#agent-groups").hidden = false;
  $("#agent-kpis").hidden = false;
  const d = await (await fetch("/api/v1/agents")).json();
  const items = d.items || [];
  const main = items.filter(a => a.main_chain);
  const fail = items.reduce((n, a) => n + Number(a.failure || 0), 0);
  const modelTyped = items.filter(a => Number(a.model_node_count || 0) > 0);
  const covered = items.filter(a => a.prompt_covered);
  $("#agent-kpis").className = "kpis agent-kpis";
  const _avc = d.availability_counts || {};
  $("#agent-kpis").innerHTML = [
    { label: "智能体总数", value: d.total, color: "#7B61FF", scope: "全平台注册" },
    { label: "管理启用", value: d.enabled, color: "#646A73", scope: "开关≠可用" },
    { label: "可用（四态）", value: d.effective != null ? d.effective : _avc.ok || 0, color: "#00B578", scope: "连接正常+程序型" },
    { label: "未配置", value: _avc.unconfigured || 0, color: "#D83931", scope: "依赖模型无凭据" },
    { label: "已配置待测", value: _avc.configured || 0, color: "#B25E00", scope: "依赖模型未真实测试" },
    { label: "连接失败", value: _avc.fail || 0, color: "#D83931", scope: "依赖模型测试失败" },
    { label: "主链路接入", value: main.length, color: "#3370FF", scope: "按触发接入" },
    { label: "模型型 / 程序型", value: `${modelTyped.length}/${items.length - modelTyped.length}`, color: "#7B61FF" },
    { label: "提示词已覆盖", value: `${covered.length}/${items.length}`, color: covered.length === items.length ? "#00B578" : "#D83931" },
    { label: "累计执行", value: d.runs, color: "#1F2329", scope: "全部时间" },
    { label: "成功率", value: d.ok_rate == null ? "—" : Math.round(d.ok_rate * 100) + "%", color: "#B25E00", scope: "真实运行记录" },
    { label: "运行失败", value: fail, color: fail ? "#D83931" : "#646A73", scope: "全部时间" },
  ].map(k => `<div class="kpi"><b style="color:${k.color}">${esc(String(k.value))}</b><span>${k.label}</span>${k.scope ? `<div class="k-hint"><span class="scope-chip">${esc(k.scope)}</span></div>` : ""}</div>`).join("");
  const groups = {};
  items.forEach(a => (groups[a.group || "通用"] = groups[a.group || "通用"] || []).push(a));
  $("#agent-groups").innerHTML = `<div class="agent-list-head"><div><b>智能体目录</b><span class="muted">${items.length} 个智能体 · ${main.length} 个已接入主链路 · ${covered.length} 个模型节点提示词已覆盖 · 可用四态：连接正常 ${_avc.ok || 0} / 已配置待测 ${_avc.configured || 0} / 未配置 ${_avc.unconfigured || 0} / 连接失败 ${_avc.fail || 0}</span></div><span class="pill published">按职责分组</span></div>` +
    Object.keys(groups).map(g => `
    <div class="agent-group-title">${esc(g)} <span class="muted">${groups[g].length}</span></div>
    <div class="agent-grid">${groups[g].map(a => {
      const _kind = a.agent_kind || (Number(a.model_node_count || 0) > 0 ? "模型型" : "程序型");
      const _mn = Number(a.model_node_count || 0), _pc = Number(a.prompt_count || 0);
      const _cov = a.prompt_coverage == null ? "—" : Math.round(a.prompt_coverage * 100) + "%";
      const _pcCls = _mn > 0 && _pc < _mn ? "draft" : "published";
      return `
      <div class="agent-card" data-aid="${esc(a.id)}">
        <div class="ac-head"><div class="ac-name">${esc(a.name)}</div>
          <span class="ac-badge-wrap" style="display:inline-flex;gap:4px;flex-wrap:wrap;justify-content:flex-end">${(() => {
            const _st = a.availability_state || "unconfigured";
            const _cls = _st === "ok" || _st === "program" ? "published" : _st === "fail" ? "r" : "draft";
            return `<span class="pill ${_cls}" title="${esc(a.availability_note || '可用性由依赖模型四态决定')}">${esc(a.availability_label || "未配置")}</span><span class="pill draft" title="管理开关，不等于可用">${esc(a.management_label || (a.status === 'active' ? '管理启用' : '管理停用'))}</span>`;
          })()}</span></div>
        <div class="ac-desc">${esc(a.desc)}</div>
        <div class="muted" style="font-size:11px;line-height:1.5;margin:-2px 0 4px">可用性：${esc(a.availability_note || "依赖模型状态未知")}</div>
        <div class="ac-badges"><span class="pill ${a.main_chain ? 'published' : 'draft'}">${a.main_chain ? '主链路已接入' : '未接入主链路'}</span><span class="ac-tag">${esc(a.capability || a.type || '通用')}</span><span class="ac-tag">${esc(_kind)}</span><span class="pill ${_pcCls}" title="模型节点提示词覆盖">提示词 ${_pc}/${_mn}</span></div>
        <div class="ac-trigger"><span>触发</span>${esc(a.trigger || '未配置')}</div>
        <div class="ac-metrics">
          <div><b>${a.runs}</b>累计执行</div>
          <div><b>${a.ok_rate == null ? '—' : Math.round(a.ok_rate * 100) + '%'}</b>成功率</div>
          <div><b>${a.avg_latency == null ? '—' : a.avg_latency + 'ms'}</b>平均延迟</div>
          <div><b>${_cov}</b>提示词覆盖</div>
        </div>
        <div class="ac-footer"><span>${esc(a.version || a.current_version || '无版本')} · ${esc(a.model || '默认模型')}</span><span>${esc(a.last_run || '尚未运行')}</span></div>
      </div>`;
    }).join("")}</div>`).join("");
  document.querySelectorAll(".agent-card").forEach(c => c.addEventListener("click", () => openAgent(c.dataset.aid)));
}

async function openAgent(aid, keepTab) {
  currentAgent = aid; if (!keepTab) agentTab = "main";
  const _sc = document.querySelector("#agent-stats-card"); if (_sc) _sc.style.display = "none";
  $("#agents-list-page").hidden = true; $("#agent-groups").hidden = true; $("#agent-kpis").hidden = true; $("#agent-detail-page").hidden = false;
  const d = await (await fetch(`/api/v1/agents/${aid}`)).json();
  if (d.error) { alert(d.error); return; }
  window.__agent = d;
  if (!window.__agentModelOptions) {
    try {
      const mr = await (await fetch("/api/v1/models")).json();
      window.__agentModelOptions = (mr.items || []).filter(x => x.enabled !== false && x.status !== "unconfigured");
    } catch (e) { window.__agentModelOptions = []; }
  }
  const m = d.metrics || {};
  const _kind = d.agent_kind || (Number(d.model_node_count || 0) > 0 ? "模型型" : "程序型");
  const _pc = Number(d.prompt_count || 0), _mn = Number(d.model_node_count || 0);
  const _cov = d.prompt_coverage == null ? "—" : Math.round(d.prompt_coverage * 100) + "%";
  $("#agent-head").innerHTML = `
    <div class="agent-detail-head">
      <div><div class="ac-name" style="font-size:17px">${esc(d.name)}</div>
        <div class="muted" style="font-size:12px;margin-top:3px">${esc(d.desc)}</div>
        <div class="agent-detail-tags"><span class="pill ${d.main_chain ? "published" : "draft"}">${d.main_chain ? "主链路已接入" : "未接入主链路"}</span><span class="ac-tag">${esc(d.capability || d.type || "通用")}</span><span class="ac-tag">${esc(_kind)}</span><span class="pill ${_mn > 0 && _pc < _mn ? "draft" : "published"}" title="模型节点提示词覆盖">提示词 ${_pc}/${_mn}</span><span class="muted">触发：${esc(d.trigger || "—")}</span></div>
      </div>
      <div class="agent-detail-actions">${(() => {
        const _st = d.availability_state || "unconfigured";
        const _cls = _st === "ok" || _st === "program" ? "published" : _st === "fail" ? "r" : "draft";
        return `<span class="pill ${_cls}" title="${esc(d.availability_note || '')}">${esc(d.availability_label || "未配置")}</span><span class="pill draft" title="管理开关，不等于可用">${esc(d.management_label || (d.status === "active" ? "管理启用" : "管理停用"))}</span>`;
      })()}<button class="btn" id="agent-toggle-status">${d.status === "active" ? "停用" : "启用"}</button></div>
    </div>
    <div class="ac-kpis agent-detail-kpis">
      <div class="ac-kpi"><b>${m.runs}</b><span>累计执行</span></div>
      <div class="ac-kpi"><b>${m.ok_rate == null ? "—" : Math.round(m.ok_rate * 100) + "%"}</b><span>成功率</span></div>
      <div class="ac-kpi"><b>${m.avg_latency == null ? "—" : m.avg_latency + "ms"}</b><span>平均延迟</span></div>
      <div class="ac-kpi"><b>${esc(d.current_version || "—")}</b><span>当前版本</span></div>
      <div class="ac-kpi"><b>${esc(d.model || "默认")}</b><span>执行模型</span></div>
      <div class="ac-kpi"><b>${_pc}/${_mn} · ${_cov}</b><span>提示词覆盖</span></div>
    </div>`;
  $("#agent-toggle-status")?.addEventListener("click", async () => {
    const next = d.status === "active" ? "draft" : "active";
    if (!confirm(next === "draft" ? "确认停用该智能体？停用后不会被主链路调用。" : "确认启用该智能体？")) return;
    const r = await (await fetch(`/api/v1/agents/${d.id}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: next }) })).json();
    const _af = apiFail(r);
    if (_af) { alert(_af); return; }
    await openAgent(d.id, true);
  });
  const TABS = [["main", "主链路"], ["basic", "职责与接口"], ["workflow", "工作流"], ["params", "参数"], ["prompts", `提示词 ${_pc}/${_mn}`], ["run", "运行记录"], ["quality", "质量"], ["versions", "版本与发布"]];
  $("#agent-tabs").innerHTML = TABS.map(([k, n]) => `<div class="agent-tab ${k === agentTab ? "active" : ""}" data-atab="${k}">${n}</div>`).join("");
  $("#agent-tabs").querySelectorAll("[data-atab]").forEach(t => t.addEventListener("click", () => { agentTab = t.dataset.atab; openAgent(aid, true); }));
  renderAgentTab(d);
  const _back = (e) => { e.preventDefault(); $("#agent-detail-page").hidden = true; $("#agents-list-page").hidden = false; loadAgents(); };
  $("#agent-back").onclick = _back; $("#agent-back2").onclick = _back;
}
function renderAgentTab(d) {
  const box = $("#agent-tab-body");
  if (agentTab === "main") {
    const stage = { preprocess: "审核预处理", rulegen: "规则生成", conflict: "规则冲突分析", judge: "点位判定", post_decision: "复核后归因", post_audit: "审核后规则挖掘" }[d.main_stage] || d.main_stage || "—";
    box.innerHTML = `<div class="card agent-main-card">
      <div class="agent-main-title"><div><h3>主链路参与</h3><p>${esc(d.trigger || "未配置触发时机")}</p></div><span class="pill ${d.main_chain ? "published" : "draft"}">${d.main_chain ? "已接入" : "未接入"}</span></div>
      <div class="agent-flow">${["审核预处理", "规则生成", "规则冲突分析", "点位判定", "复核归因"].map((x, i) => `<span class="${stage === x ? "on" : ""}">${x}</span>${i < 4 ? "<i>→</i>" : ""}`).join("")}</div>
      <div class="agent-interface-grid">
        <div><span>执行能力</span><b>${esc(d.capability || "—")}</b></div>
        <div><span>执行阶段</span><b>${esc(stage)}</b></div>
        <div><span>输入</span><b>${esc(d.input || "—")}</b></div>
        <div><span>输出</span><b>${esc(d.output || "—")}</b></div>
        <div><span>当前版本</span><b>${esc(d.current_version || "无发布版本")}</b></div>
        <div><span>执行模型</span><b>${esc(d.model || "系统默认模型")}</b></div>
      </div>
      <div class="agent-main-note">主链路每次触发都会写入 agent_run，并在审核编排中记录 executed / skipped / failed 及原因。管理状态：${d.status === "active" ? "启用中，下一次审核即可参与" : "已停用，不会进入主链路"}；可用性（四态）：<b>${esc(d.availability_label || "未配置")}</b>。${esc(d.availability_note || "")}。管理启用不等于可用，依赖模型无凭据时模型节点会降级/跳过。</div>
      <div class="actions"><button class="btn" data-agent-goto="run">查看运行记录</button></div>
    </div>`;
    box.querySelectorAll("[data-agent-goto]").forEach(b => b.onclick = () => { agentTab = b.dataset.agentGoto; openAgent(d.id, true); });
  } else if (agentTab === "basic") {
    box.innerHTML = `
      <div class="card" style="border:0;padding:0">
        <h3 style="font-size:15px;margin:6px 0">职责与边界</h3>
        <div class="row2" style="align-items:flex-start;gap:24px">
          <div style="flex:1"><div class="muted" style="font-size:12px;margin-bottom:4px">负责</div>${esc(d.responsibility || "—")}</div>
          <div style="flex:1"><div class="muted" style="font-size:12px;margin-bottom:4px">不负责 / 边界</div>${esc(d.not_responsibility || "—")}</div>
        </div>
        <h3 style="font-size:15px;margin:18px 0 8px">运行方式</h3>
        <div class="ac-kpis" style="grid-template-columns:repeat(4,1fr)">
          ${(d.run_modes || []).map(x => `<div class="ac-kpi"><b style="font-size:13px">${esc(x.k)}</b><span>${esc(x.v)}</span></div>`).join("")}
        </div>
        <div class="row2" style="margin-top:16px;align-items:flex-start;gap:24px">
          <div style="flex:1"><h3 style="font-size:15px;margin:0 0 6px">输入</h3>
            ${(d.inputs || []).map(x => `<div style="font-size:13px;padding:3px 0">· ${esc(x)}</div>`).join("") || '<span class="muted">—</span>'}</div>
          <div style="flex:1"><h3 style="font-size:15px;margin:0 0 6px">输出</h3>
            ${(d.outputs || []).map(x => `<div style="font-size:13px;padding:3px 0">· ${esc(x)}</div>`).join("") || '<span class="muted">—</span>'}</div>
        </div>
        <h3 style="font-size:15px;margin:18px 0 6px">模型联动</h3>
        <div class="muted" style="font-size:12px;line-height:1.7">此智能体通过系统默认模型执行模型节点；默认模型在「模型与接入点」中配置。模型切换后，下一次审核调用立即生效。</div>
      </div>`;
  } else if (agentTab === "workflow") {
    const wf = d.workflow || [];
    const W = 248, H = 128, GAP = 64, PAD = 30, TOP = 180, TERM = 180;
    const positions = {};
    wf.forEach((n, i) => {
      positions[i] = {
        x: Number.isFinite(Number(n.x)) ? Number(n.x) : PAD + TERM + GAP + i * (W + GAP),
        y: Number.isFinite(Number(n.y)) ? Number(n.y) : TOP
      };
    });
    const endX = PAD + TERM + GAP + wf.length * (W + GAP);
    const canvasW = Math.max(900, endX + TERM + PAD);
    const canvasH = 560;
    const nodeHTML = wf.map((n, i) => {
      const np = (d.prompts_list || []).find(p => p.node === n.name && String(p.prompt || "").trim());
      const pos = positions[i];
      return `<div class="af-node ${n.type === "模型" ? "is-model" : ""}" data-af-node="${i}" style="left:${pos.x}px;top:${pos.y}px">
        <div class="af-node-head"><span class="af-dot ${n.type === "模型" ? "model" : n.type === "校验" ? "check" : "program"}"></span><b>${esc(n.name || "未命名节点")}</b><span class="af-step">${String(i + 1).padStart(2, "0")}</span></div>
        <div class="af-node-desc">${esc(n.desc || "未填写节点说明")}</div>
        <div class="af-node-foot"><span class="af-tag">${esc(n.type || "程序")}</span>${np ? '<span class="af-tag primary">提示词</span>' : (n.type === "模型" ? '<span class="af-tag">未配提示词</span>' : '<span class="af-tag">程序执行</span>')}${n.optional ? '<span class="af-tag">按需</span>' : ""}</div>
      </div>`;
    }).join("");
    const _wn = wf.filter(n => n.type === "模型").length;
    const _wp = (d.prompts_list || []).filter(p => String(p.prompt || "").trim()).length;
    box.innerHTML = `<div class="wf-help">拖动节点调整布局；点击节点查看上下游、提示词、模型和参数。Ctrl/⌘ + 滚轮缩放。模型节点显示“提示词”（已覆盖 ${_wp}/${_wn}），程序/校验节点显示“程序执行”，不伪造提示词。</div>
      <div class="af-toolbar">
        <div class="af-zoom"><button type="button" data-af-zoom="-">−</button><button type="button" class="af-zoom-val" data-af-zoom="reset">100%</button><button type="button" data-af-zoom="+">+</button></div>
        <span class="muted" id="af-count">${wf.length} 个节点 · ${wf.filter(n => n.type === "模型").length} 次模型调用</span>
        <button class="btn" id="af-reset">重置布局</button>
        <button class="btn primary" id="af-save">保存节点与布局</button><span class="muted" id="af-msg"></span>
      </div>
      ${wf.length ? `<div class="af-board" id="af-board"><div class="af-stage" id="af-stage" style="width:${canvasW}px;height:${canvasH}px;transform:scale(1);transform-origin:top left">
        <svg class="af-edges" id="af-svg" width="${canvasW}" height="${canvasH}" viewBox="0 0 ${canvasW} ${canvasH}"></svg>
        <div class="af-terminal start" style="left:${PAD}px;top:${TOP}px"><small>触发</small><b>${esc(d.trigger || "业务触发")}</b></div>
        ${nodeHTML}
        <div class="af-terminal end" style="left:${endX}px;top:${TOP}px"><small>输出</small><b>${esc(d.output || "业务结果")}</b></div>
      </div></div>` : '<div class="empty">该智能体暂未配置工作流</div>'}
      <div class="af-drawer" id="af-drawer" hidden><div class="af-drawer-card">
        <div class="af-drawer-head"><h3 id="af-drawer-title">节点</h3><button class="btn" id="af-drawer-close">关闭</button></div>
        <div id="af-drawer-body"></div>
      </div></div>`;
    if (!wf.length) return;
    const stage = box.querySelector("#af-stage"), board = box.querySelector("#af-board"), svg = box.querySelector("#af-svg");
    const zoomVal = box.querySelector("[data-af-zoom='reset']");
    let zoom = 1;
    const drawEdges = () => {
      if (!svg) return;
      const parts = [`<defs><marker id="af-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 10 5 0 10z" fill="#B8C0CC"/></marker></defs>`];
      const path = (x1, y1, x2, y2) => {
        const dx = Math.max(30, (x2 - x1) / 2);
        return `M${x1} ${y1} C${x1+dx} ${y1},${x2-dx} ${y2},${x2} ${y2}`;
      };
      parts.push(`<path class="af-edge" d="${path(PAD + TERM, TOP + H/2, positions[0].x, positions[0].y + H/2)}" marker-end="url(#af-arrow)"/>`);
      for (let i = 0; i < wf.length - 1; i++) {
        parts.push(`<path class="af-edge" d="${path(positions[i].x + W, positions[i].y + H/2, positions[i+1].x, positions[i+1].y + H/2)}" marker-end="url(#af-arrow)"/>`);
      }
      parts.push(`<path class="af-edge" d="${path(positions[wf.length-1].x + W, positions[wf.length-1].y + H/2, endX, TOP + H/2)}" marker-end="url(#af-arrow)"/>`);
      svg.innerHTML = parts.join("");
    };
    const setZoom = (v) => {
      zoom = Math.max(0.5, Math.min(1.6, Math.round(v * 10) / 10));
      stage.style.transform = `scale(${zoom})`;
      zoomVal.textContent = Math.round(zoom * 100) + "%";
    };
    const openNode = (i) => {
      const n = wf[i] || {};
      const np = (d.prompts_list || []).find(p => p.node === n.name && String(p.prompt || "").trim());
      const prev = i > 0 ? (wf[i-1].name || "触发") : "触发";
      const next = i < wf.length - 1 ? (wf[i+1].name || "输出") : "输出";
      const params = (d.params_list || []).map(p => `${p.name}=${p.v}`).join(" · ") || "无";
      const _modelSel = (cur) => `<label style="font-size:10px;color:#8F959E">节点模型 <select class="field" id="af-edit-model" style="height:26px;min-height:26px;font-size:10px;margin-left:5px"><option value="">系统默认</option>${(window.__agentModelOptions || []).map(m => `<option value="${esc(m.id)}"${cur === m.id ? " selected" : ""}>${esc(m.name || m.model_id)}</option>`).join("")}</select></label>`;
      const _promptBlock = np
        ? `<div class="actions" style="margin:2px 0 4px">${_modelSel(np.model_id || "")}</div><textarea class="field" id="af-edit-prompt-text" style="width:100%;min-height:150px;font:11px/1.65 ui-monospace,Menlo,monospace">${esc(np.prompt || "")}</textarea><div class="muted" style="font-size:10px;margin-top:3px">可直接编辑自然语言提示词；保存后发布新版本生效。</div>`
        : (n.type === "模型"
          ? `<p class="muted" style="margin:2px 0 4px">该模型节点尚未配置提示词（模型节点覆盖率不完整）。可在此补充后保存，或到「提示词」页统一维护。</p><div class="actions" style="margin:2px 0 4px">${_modelSel("")}</div><textarea class="field" id="af-edit-prompt-text" style="width:100%;min-height:120px;font:11px/1.65 ui-monospace,Menlo,monospace" placeholder="为模型节点补充提示词…">${esc((d.prompt_defaults || {})[n.name] || "")}</textarea>`
          : `<p class="muted">该节点为${esc(n.type || "程序")}节点，由程序/规则执行，不需要模型提示词（程序执行，不伪造提示词）。</p>`);
      box.querySelector("#af-drawer-title").textContent = n.name || "节点";
      box.querySelector("#af-drawer-body").innerHTML = `
        <div class="af-detail"><small>节点作用</small><p>${esc(n.desc || "未填写")}</p></div>
        ${(() => { const nr = (d.node_runs || []).find(x => x.node_name === n.name); return nr ? `<div class="af-detail af-run-detail"><small>最近执行</small><p><span class="pill ${nr.status === "ok" ? "published" : "draft"}">${esc(nr.status)}</span> ${esc(String(nr.latency ?? "—"))}ms · ${esc(nr.created_at || "")}</p>${nr.error ? `<p class="af-error">${esc(nr.error)}</p>` : ""}${nr.output && Object.keys(nr.output).length ? `<pre class="af-prompt">${esc(JSON.stringify(nr.output, null, 2))}</pre>` : ""}</div>` : `<div class="af-detail"><small>最近执行</small><p class="muted">暂无节点轨迹；点击“运行调试”执行一次。</p></div>`; })()}
        <div class="af-detail-grid"><div><small>顺序</small><b>第 ${i+1} / ${wf.length} 步</b></div><div><small>类型</small><b>${esc(n.type || "程序")}${n.type === "模型" ? "（模型节点）" : "（程序/校验节点）"}</b></div><div><small>上游</small><b>${esc(prev)}</b></div><div><small>下游</small><b>${esc(next)}</b></div></div>
        <div class="af-detail"><small>参数</small><p>${esc(params)}</p></div>
        <div class="af-detail"><small>关联提示词</small>${_promptBlock}</div>
        <div class="af-edit"><label>节点名称<input class="field" id="af-edit-name" value="${esc(n.name || "")}"></label>
          <label>节点类型<select class="field" id="af-edit-type">${["程序", "模型", "校验", "人工"].map(t => `<option${t === n.type ? " selected" : ""}>${t}</option>`).join("")}</select></label>
          <label class="wide">节点说明<input class="field" id="af-edit-desc" value="${esc(n.desc || "")}"></label></div>
        <div class="actions"><button class="btn primary" id="af-edit-save">保存节点/提示词</button><button class="btn" id="af-edit-run">运行调试</button>${np ? '<button class="btn" id="af-edit-reset">恢复默认提示词</button><button class="btn" id="af-edit-prompt">打开提示词页</button>' : ""}</div>`;
      box.querySelector("#af-drawer").hidden = false;
      box.querySelector("#af-drawer-close").onclick = () => box.querySelector("#af-drawer").hidden = true;
      box.querySelector("#af-edit-save").onclick = async () => {
        wf[i] = { ...n, name: box.querySelector("#af-edit-name").value.trim(), type: box.querySelector("#af-edit-type").value, desc: box.querySelector("#af-edit-desc").value.trim(), x: positions[i].x, y: positions[i].y };
        const list = wf.map((x, j) => ({ ...x, x: positions[j].x, y: positions[j].y }));
        const plist = (d.prompts_list || []).map(p => ({ ...p }));
        const _ta = box.querySelector("#af-edit-prompt-text");
        const _ms = box.querySelector("#af-edit-model");
        if (np) {
          const hit = plist.find(p => p.node === n.name);
          if (hit) { hit.prompt = _ta ? _ta.value : hit.prompt; hit.model_id = _ms ? _ms.value : (hit.model_id || ""); }
        } else if (n.type === "模型" && _ta && String(_ta.value || "").trim()) {
          // 模型节点原来没有提示词：保存时补一条，程序/校验节点永远不写提示词
          plist.push({ node: n.name, prompt: _ta.value, model_id: _ms ? _ms.value : "" });
        }
        const r = await (await fetch(`/api/v1/agents/${d.id}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ workflow: list, prompts_list: plist }) })).json();
        box.querySelector("#af-msg").textContent = r.ok ? "节点和提示词已保存；发布新版本后生效" : (r.error || "保存失败");
        box.querySelector("#af-drawer").hidden = true;
        openAgent(d.id, true);
      };
      box.querySelector("#af-edit-run").onclick = () => { agentTab = "run"; openAgent(d.id, true); };
      const rp = box.querySelector("#af-edit-reset");
      if (rp) rp.onclick = () => { const ta = box.querySelector("#af-edit-prompt-text"); if (ta) ta.value = (d.prompt_defaults || {})[n.name] || ""; };
      const ep = box.querySelector("#af-edit-prompt");
      if (ep) ep.onclick = () => { agentTab = "prompts"; openAgent(d.id, true); };
    };
    drawEdges();
    let drag = null;
    box.querySelectorAll("[data-af-node]").forEach(el => {
      const i = Number(el.dataset.afNode);
      el.addEventListener("pointerdown", (ev) => {
        ev.preventDefault(); el.setPointerCapture(ev.pointerId);
        drag = { i, el, sx: ev.clientX, sy: ev.clientY, ox: positions[i].x, oy: positions[i].y, moved: false };
      });
      el.addEventListener("pointermove", (ev) => {
        if (!drag || drag.i !== i) return;
        const dx = (ev.clientX - drag.sx) / zoom, dy = (ev.clientY - drag.sy) / zoom;
        if (!drag.moved && Math.hypot(dx, dy) > 4) drag.moved = true;
        if (!drag.moved) return;
        positions[i].x = Math.max(PAD, drag.ox + dx);
        positions[i].y = Math.max(40, drag.oy + dy);
        el.style.left = positions[i].x + "px"; el.style.top = positions[i].y + "px"; drawEdges();
      });
      el.addEventListener("pointerup", () => {
        if (!drag) return;
        const moved = drag.moved; drag = null;
        if (!moved) openNode(i);
      });
      el.addEventListener("pointercancel", () => { drag = null; });
    });
    box.querySelectorAll("[data-af-zoom]").forEach(b => b.onclick = () => {
      const v = b.dataset.afZoom;
      setZoom(v === "reset" ? 1 : v === "+" ? zoom + 0.1 : zoom - 0.1);
    });
    board.addEventListener("wheel", (e) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      e.preventDefault(); setZoom(zoom + (e.deltaY < 0 ? 0.1 : -0.1));
    }, { passive: false });
    box.querySelector("#af-reset").onclick = () => openAgent(d.id, true);
    box.querySelector("#af-save").onclick = async () => {
      const list = wf.map((x, j) => ({ ...x, x: positions[j].x, y: positions[j].y }));
      const r = await (await fetch(`/api/v1/agents/${d.id}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ workflow: list }) })).json();
      box.querySelector("#af-msg").textContent = r.ok ? "布局已保存；发布新版本后生效" : (r.error || "保存失败");
    };
  } else if (agentTab === "params") {
    const ps = d.params_list || [];
    const _ctl = (p, i) => {
      const t = String(p.type || "string").toLowerCase(), v = p.v == null ? "" : p.v;
      if (t === "bool" || t === "boolean" || t === "switch") return `<select class="field" data-pidx="${i}" style="width:100%"><option value="true"${v === true || v === "true" ? " selected" : ""}>开启</option><option value="false"${v === false || v === "false" ? " selected" : ""}>关闭</option></select>`;
      if (t === "number" || t === "int" || t === "integer" || t === "float") return `<input class="field" type="number" step="any" data-pidx="${i}" value="${esc(v)}" style="width:100%">`;
      if (Array.isArray(p.options) && p.options.length) return `<select class="field" data-pidx="${i}" style="width:100%">${p.options.map(x => `<option${String(x) === String(v) ? " selected" : ""}>${esc(x)}</option>`).join("")}</select>`;
      return `<input class="field" data-pidx="${i}" value="${esc(v)}" style="width:100%">`;
    };
    box.innerHTML = `<div class="wf-help">参数直接参与真实执行；保存后发布新版本生效。参数类型决定控件，不再全部用文本框。</div>` + (ps.length ? ps.map((p, i) => `<div class="card" style="margin-bottom:8px;padding:10px 12px"><div class="af-param-head"><b>${esc(p.name || "参数")}</b><span class="af-tag">${esc(p.type || "string")}</span></div><div class="muted" style="font-size:11px;line-height:1.5;margin:3px 0 6px">${esc(p.desc || "未填写参数说明")}</div>${_ctl(p, i)}</div>`).join("") : `<div class="muted">该智能体暂未配置参数</div>`) +
      (ps.length ? `<div class="actions" style="margin-top:8px"><button class="btn primary" id="agent-save-params">保存参数</button><span class="muted" id="agent-params-msg"></span></div>` : "");
    const save = box.querySelector("#agent-save-params");
    if (save) save.addEventListener("click", async () => {
      const list = ps.map((p, i) => { const el = box.querySelector(`[data-pidx="${i}"]`); let v = el ? el.value : p.v;
        if (["bool", "boolean", "switch"].includes(String(p.type || "").toLowerCase())) v = v === "true";
        else if (["number", "int", "integer", "float"].includes(String(p.type || "").toLowerCase())) v = Number(v);
        return { ...p, v }; });
      const r = await (await fetch(`/api/v1/agents/${d.id}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params_list: list }) })).json();
      box.querySelector("#agent-params-msg").textContent = r.ok ? "已保存；请发布新版本后生效" : (r.error || "保存失败");
    });
  } else if (agentTab === "prompts") {
    const ps = d.prompts_list || [];
    const wf = d.workflow || [];
    const modelNodes = wf.filter(n => n.type === "模型");
    const progNodes = wf.filter(n => n.type !== "模型");
    const _coveredNames = new Set(ps.filter(p => String(p.prompt || "").trim()).map(p => p.node));
    const missing = (Array.isArray(d.model_nodes_missing_prompt) && d.model_nodes_missing_prompt.length
      ? d.model_nodes_missing_prompt : modelNodes.filter(n => !_coveredNames.has(n.name)).map(n => n.name));
    const _pc = Number(d.prompt_count == null ? _coveredNames.size : d.prompt_count);
    const _mn = Number(d.model_node_count == null ? modelNodes.length : d.model_node_count);
    const _cov = _mn ? Math.round(_pc / _mn * 100) + "%" : "—";
    const _models = window.__agentModelOptions || [];
    const _defaults = d.prompt_defaults || {};
    box.innerHTML = `<div class="wf-help"><b>模型节点提示词覆盖 ${_pc}/${_mn}（${_cov}）</b>；有提示词的模型节点显示“提示词”，程序/校验节点由程序执行、不配置也不伪造提示词。发布版本会保存这些节点提示词并供执行读取。</div>`
      + (missing.length ? `<div class="card" style="margin-bottom:10px;border-left:3px solid #D83931;padding:10px 12px"><b style="font-size:13px;color:#D83931">${missing.length} 个模型节点未配置提示词</b><div class="muted" style="font-size:11px;margin-top:4px">${missing.map(x => esc(x)).join(" · ")}。到「工作流」页点击对应模型节点即可补充，保存后发布新版本生效。</div></div>` : "")
      + (ps.length ? ps.map((p, i) => `
      <div class="card" style="margin-bottom:10px"><div class="card-head"><h2 style="font-size:13px">${esc(p.node)}</h2><span class="muted" style="font-size:11px">模型节点 · 提示词</span></div>
      <textarea class="field" data-pidx="${i}" style="width:100%;min-height:118px;font-size:13px;line-height:1.7">${esc(p.prompt)}</textarea>
      <div class="actions" style="margin-top:6px"><label style="font-size:11px;color:#646A73">节点模型 <select class="field" data-pmodel="${i}" style="height:28px;min-height:28px;font-size:11px;margin-left:6px"><option value="">系统默认</option>${_models.map(m => `<option value="${esc(m.id)}"${p.model_id === m.id ? " selected" : ""}>${esc(m.name || m.model_id)}</option>`).join("")}</select></label><button class="btn" data-preset="${i}" style="height:26px;min-height:26px;font-size:10px">恢复系统默认</button></div>${_defaults[p.node] && _defaults[p.node] !== p.prompt ? `<details style="margin-top:6px"><summary class="muted" style="font-size:10px;cursor:pointer">查看系统默认提示词</summary><pre class="af-prompt">${esc(_defaults[p.node])}</pre></details>` : ""}</div>`).join("")
      : `<div class="muted" style="margin-bottom:8px">该智能体暂未配置模型节点提示词</div>`)
      + (progNodes.length ? `<div class="card" style="padding:10px 12px"><div class="card-head"><h2 style="font-size:13px">程序 / 校验节点</h2><span class="muted" style="font-size:11px">${progNodes.length} 个节点</span></div><div class="muted" style="font-size:11px;line-height:1.8">${progNodes.map(n => `<span class="ac-tag" style="margin-right:4px">${esc(n.name || "未命名")} · 程序执行</span>`).join("")}</div><div class="muted" style="font-size:10px;margin-top:4px">这些节点由程序/规则/校验逻辑执行，不配置模型提示词；系统不会为它们伪造提示词。</div></div>` : "")
      + `<div class="actions" style="margin-top:8px"><button class="btn primary" id="agent-save-prompts">保存提示词</button>
       <span class="muted" id="agent-save-msg"></span></div>`;
    box.querySelectorAll("[data-preset]").forEach(b => b.onclick = () => {
      const i = Number(b.dataset.preset), p = ps[i];
      const ta = box.querySelector(`[data-pidx="${i}"]`);
      if (ta) ta.value = _defaults[p.node] || p.prompt || "";
    });
    const btn = box.querySelector("#agent-save-prompts");
    if (btn) btn.addEventListener("click", async () => {
      const list = (d.prompts_list || []).map((p, i) => {
        const ta = box.querySelector(`[data-pidx="${i}"]`);
        const mm = box.querySelector(`[data-pmodel="${i}"]`);
        return { node: p.node, prompt: ta ? ta.value : p.prompt, model_id: mm ? mm.value : (p.model_id || "") };
      });
      const r = await (await fetch(`/api/v1/agents/${d.id}/update`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompts_list: list }) })).json();
      box.querySelector("#agent-save-msg").textContent = r.ok ? "已保存；请发布新版本后生效" : (r.error || "保存失败");
    });
  } else if (agentTab === "run") {
    box.innerHTML = renderRunPanel(d) + renderAgentRunHistory(d);
    bindRunPanel(d);
  } else if (agentTab === "quality") {
    const m = d.metrics || {};
    box.innerHTML = `<div class="card agent-quality-card"><div class="agent-main-title"><div><h3>运行质量</h3><p>来自真实 agent_run 的历史执行；不等同于离线评测集。</p></div><span class="pill ${m.fail ? "draft" : "published"}">${m.fail ? "存在失败" : "运行正常"}</span></div>
      <div class="ac-kpis"><div class="ac-kpi"><b>${m.runs || 0}</b><span>总运行</span></div><div class="ac-kpi"><b>${m.ok || 0}</b><span>成功</span></div><div class="ac-kpi"><b>${m.fail || 0}</b><span>失败</span></div><div class="ac-kpi"><b>${m.ok_rate == null ? "—" : Math.round(m.ok_rate * 100) + "%"}</b><span>成功率</span></div></div>
      ${renderAgentRunHistory(d)}
      <div class="agent-main-note">离线评测集尚未绑定到该智能体；当前质量指标只读取真实运行记录，不做伪造评分。</div></div>`;
  } else {
    const vs = d.versions || [];
    box.innerHTML = `
      <div class="agent-version-head"><div><h3 style="font-size:15px;margin:0 0 6px">版本与发布</h3><p class="muted">发布后新版本进入下一次主链路调用；历史版本保留。</p></div><button class="btn primary" id="agent-publish">${d.current_version ? "发布新版本" : "发布首版"}</button></div>
      <div class="row2" style="align-items:flex-start;gap:24px">
        <div style="flex:1"><h3 style="font-size:13px;margin:0 0 8px">当前发布版本</h3><div class="muted" style="font-size:15px">${esc(d.current_version || "还没有发布版本")}</div></div>
        <div style="flex:1"><h3 style="font-size:13px;margin:0 0 8px">版本历史</h3>
          ${vs.length ? `<table class="table"><thead><tr><th>版本</th><th>状态</th><th>发布时间</th></tr></thead><tbody>${vs.map(v => `<tr><td>${esc(v.version)}</td><td><span class="pill ${v.status === "published" ? "published" : "draft"}">${esc(v.status)}</span></td><td class="muted">${esc(v.published_at || "—")}</td></tr>`).join("")}</tbody></table>` : '<div class="muted">暂无版本</div>'}</div>
      </div>`;
    const pub = box.querySelector("#agent-publish");
    if (pub) pub.onclick = async () => {
      pub.disabled = true; pub.textContent = "发布中…";
      const r = await (await fetch(`/api/v1/agents/${encodeURIComponent(d.id)}/publish`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
      const _af = apiFail(r);
      if (_af) { showToast("发布失败：" + _af, "err"); pub.disabled = false; pub.textContent = "发布新版本"; return; }
      showToast("已发布 " + (r.version || "新版本")); await openAgent(d.id, true);
    };
  }
}
$("#btn-agents-refresh")?.addEventListener("click", loadAgents);
$("#agents-refresh-new")?.addEventListener("click", loadAgents);

$("#btn-model")?.addEventListener("click", () => openModelView());

/* ===================== Jev 校准（超管） ===================== */
async function loadJev() {
  let _jevOff = false;
  try {
    const sr = await (await fetch("/api/v1/workspaces/settings")).json();
    _jevOff = !(sr.modules && sr.modules.mod_jev);
  } catch (e) {}
  if (_jevOff) {
    $("#jev-kpis").innerHTML = "";
    $("#jev-byrule").innerHTML = "";
    $("#jev-curve").innerHTML = "";
    const save = $("#jev-save"); if (save) save.disabled = true;
    const hint = $("#jev-hint");
    if (hint) hint.innerHTML = currentRole === "reviewer"
      ? "当前工作空间未启用 JEV 校准；审核员只读，请联系业务管理员启用。"
      : '当前工作空间未启用 JEV 校准。JEV 只读取人工复核样本，不会伪造校准结果。 <button class="btn" id="jev-goto-enable">去空间配置启用</button>';
    document.querySelector("#jev-goto-enable")?.addEventListener("click", openWsConfig);
    return;
  }
  const d = await (await fetch("/api/v1/calibration")).json();
  if (d && d.error) { $("#jev-hint").textContent = d.error; return; }
  const save = $("#jev-save"); if (save) save.disabled = false;
  $("#jev-kpis").innerHTML = [
    { ico: "", label: "校准样本", value: d.samples || 0, bg: "#F0F4FF", color: "#3370FF" },
    { ico: "", label: "ECE（校准误差）", value: d.ece == null ? "—" : d.ece, bg: "#FFF6E8", color: "#FF8800" },
    { ico: "", label: "弃权阈值", value: d.threshold == null ? "—" : d.threshold, bg: "#F5F0FF", color: "#7B61FF" },
    { ico: "", label: "覆盖率", value: d.coverage == null ? "—" : Math.round(d.coverage * 100) + "%", bg: "#E8F8F0", color: "#00B578" },
    { ico: "", label: "回答准确率", value: d.accuracy == null ? "—" : Math.round(d.accuracy * 100) + "%", bg: "#E8F8F0", color: "#00B578" },
  ].map(k => `<div class="kpi">    <b style="color:${k.color}">${esc(String(k.value))}</b><span>${k.label}</span></div>`).join("");
  $("#jev-min-acc").value = d.min_accuracy == null ? 0.9 : d.min_accuracy;
  $("#jev-hint").textContent = d.note || "";
  // 按规则校准（与规则库联动）
  const byRule = await (await fetch("/api/v1/calibration/rules")).json();
  const rb = $("#jev-byrule");
  if (rb) {
    rb.innerHTML = (Array.isArray(byRule) && byRule.length)
      ? `<table class="table"><thead><tr><th style="width:56px">序号</th><th>规则</th><th>样本</th><th>实际准确率</th><th>平均置信度</th><th>目标</th><th>状态</th></tr></thead><tbody>` +
        byRule.map((x, i) => `<tr>
          <td class="muted">${byRule.length - i}</td>
          <td>${esc(x.rule_code)}</td><td>${x.samples}</td>
          <td>${Math.round(x.accuracy * 100)}%</td>
          <td>${x.avg_confidence == null ? "—" : Math.round(x.avg_confidence * 100) + "%"}</td>
          <td>${Math.round(x.target * 100)}%</td>
          <td><span class="pill ${x.meets_target ? "published" : "draft"}">${x.meets_target ? "达标" : "低于目标"}</span></td>
        </tr>`).join("") + `</tbody></table>`
      : `<div class="muted">还没有按规则的校准样本（人工复核带置信度的模型结论后会自动累积）</div>`;
  }
  const bs = d.buckets || [];
  $("#jev-curve").innerHTML = bs.length ? `<table class="table"><thead><tr>
      <th>置信度区间</th><th>实际准确率</th><th>样本数</th><th>偏差</th></tr></thead><tbody>` +
    bs.map(b => {
      const dev = (b.accuracy - b.confidence);
      return `<tr><td>${b.confidence.toFixed(1)} ~ ${(b.confidence + 0.1).toFixed(1)}</td>
        <td>${Math.round(b.accuracy * 100)}%</td><td>${b.n}</td>
        <td><span class="pill ${Math.abs(dev) > 0.1 ? 'draft' : 'published'}">${dev >= 0 ? '+' : ''}${(dev * 100).toFixed(0)}%</span></td></tr>`;
    }).join("") + `</tbody></table>` : `<div class="muted" style="padding:16px">还没有校准样本。人工复核确认/误报后会自动累积。</div>`;
}
$("#btn-jev")?.addEventListener("click", loadJev);
$("#jev-save")?.addEventListener("click", async () => {
  const v = parseFloat($("#jev-min-acc").value || "0.9");
  const r = await (await fetch("/api/v1/calibration/config", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ min_accuracy: v }) })).json();
  const _af = apiFail(r);
  if (_af) { alert(_af); return; }
  alert("已保存：目标准确率 " + r.min_accuracy);
  loadJev();
});

/* ===================== 新建项目：类型选择 + 常用记忆 ===================== */
const FILE_TYPES = [
  { v: "", t: "AI 自动判断" },
  { v: "food", t: "食品工艺书" },
  { v: "contract", t: "合同" },
  { v: "application", t: "申报材料" },
  { v: "general", t: "通用文件" },
];
const FALLBACK_DOC_TYPES = [
  { name: "食品工艺书", base_type: "food" }, { name: "采购合同", base_type: "contract" },
  { name: "销售合同", base_type: "contract" }, { name: "申报材料", base_type: "application" },
  { name: "通用文件", base_type: "general" },
];
/* T-105：新建空间文件类型选择框最后固定“其他（未列入标准类型）”。
 * 口径与服务端 app/services/workspaces.py 保持一致（字符串/域/阈值两边同名常量+同一数据源
 * /api/v1/audit-points/library 的 document_types 条目；这里只做前端实时提示）。 */
const OTHER_DOC_TYPE = "其他（未列入标准类型）";
const WS_DOC_OVERLAP_MIN = 0.5;
const WS_DOMAIN_LABELS = { food: "食品/工艺域", contract: "合同/采购域", application: "申报/资质域", general: "通用/未归类" };
function wsBaseType(name) {
  const n = String(name || "");
  if (["食品", "工艺", "配方", "检验", "标签", "生产"].some(k => n.indexOf(k) >= 0)) return "food";
  if (["合同", "招标", "投标", "报价", "采购", "销售"].some(k => n.indexOf(k) >= 0)) return "contract";
  if (["申报", "许可", "资质", "执照", "审批", "备案"].some(k => n.indexOf(k) >= 0)) return "application";
  return "general";
}
/* 与服务端 judge_doc_types 同口径：同域允许；跨域时按域聚合 default_audit_types，
 * Jaccard 重叠 >= WS_DOC_OVERLAP_MIN 才允许；“其他”按通用类型处理，不伪造专用规则。 */
function wsJudgeDocTypes(selected, profiles, otherName) {
  const other = otherName || OTHER_DOC_TYPE;
  const sel = (selected || []).map(x => String(x || "").trim()).filter(Boolean);
  const items = [];
  for (const name of sel) {
    if (name === other) { items.push({ type: name, base_type: "general", default_audit_types: [], other: true }); continue; }
    const p = (profiles || {})[name] || {};
    items.push({ type: name, base_type: p.base_type || wsBaseType(name),
      default_audit_types: Array.isArray(p.default_audit_types) ? p.default_audit_types.slice() : [], other: false });
  }
  const otherSelected = items.some(x => x.other);
  const domainTypes = {};
  items.forEach(it => {
    const bt = it.base_type || "general";
    domainTypes[bt] = domainTypes[bt] || new Set();
    it.default_audit_types.forEach(t => domainTypes[bt].add(String(t)));
  });
  const domains = Object.keys(domainTypes).filter(d => d !== "general").sort();
  const res = { compatible: true, reason: "", suggestion: "", groups: [], domains: domains, otherSelected: otherSelected, overlap: null };
  if (!items.length) {
    return { compatible: false, reason: "请选择 1~5 个主文件类型后再判断是否适合同一批规则库", suggestion: "", groups: [], domains: [], otherSelected: false, overlap: null };
  }
  if (!domains.length) {
    res.reason = otherSelected
      ? "所选类型为通用/未归类（含“其他（未列入标准类型）”）：按通用规则执行，不伪造专用规则；审核时需人工确认。"
      : "所选类型均为通用/未归类，适合共用通用规则库。";
    return res;
  }
  if (domains.length === 1) {
    res.reason = "所选文件类型同属「" + (WS_DOMAIN_LABELS[domains[0]] || "同一业务域") + "」，适合共用同一批规则库。";
    return res;
  }
  const pairs = [];
  for (let i = 0; i < domains.length; i++) {
    for (let j = i + 1; j < domains.length; j++) {
      const A = domainTypes[domains[i]] || new Set(), B = domainTypes[domains[j]] || new Set();
      const union = new Set([...A, ...B]);
      const inter = [...A].filter(x => B.has(x));
      const score = union.size ? inter.length / union.size : 1;
      pairs.push({ a: domains[i], b: domains[j], overlap: score });
    }
  }
  const minPair = pairs.reduce((m, p) => (p.overlap < m.overlap ? p : m), pairs[0]);
  res.overlap = minPair.overlap;
  if (minPair.overlap >= WS_DOC_OVERLAP_MIN) {
    res.reason = "所选文件类型跨 " + domains.length + " 个业务域，但默认审核类型重叠足够（最低 " +
      minPair.overlap.toFixed(2) + " ≥ " + WS_DOC_OVERLAP_MIN.toFixed(2) + "），适合共用同一批规则库。";
    return res;
  }
  const groups = domains.map(d => ({ key: d, label: WS_DOMAIN_LABELS[d] || d, types: items.filter(x => x.base_type === d).map(x => x.type) }));
  const generalTypes = items.filter(x => x.base_type === "general").map(x => x.type);
  if (generalTypes.length) groups.push({ key: "general", label: WS_DOMAIN_LABELS.general, types: generalTypes });
  res.compatible = false;
  res.groups = groups;
  res.reason = "所选 " + sel.length + " 个文件类型跨 " + domains.length + " 个业务域（" +
    domains.map(d => WS_DOMAIN_LABELS[d] || d).join("、") + "），且默认审核类型重叠不足（最低 " +
    minPair.overlap.toFixed(2) + " < " + WS_DOC_OVERLAP_MIN.toFixed(2) + "）。同一批规则库无法同时覆盖这些类型，直接创建会让部分类型的规则/点位失效。";
  res.suggestion = "建议拆分为 " + groups.length + " 个空间分别创建：" +
    groups.filter(g => g.types.length).map(g => g.label + "：" + g.types.join("、")).join("；") +
    "。同一空间只放同一业务域的文件类型；如确需混用，请先补齐覆盖两类业务的同一批规则库/点位。";
  return res;
}
let _wsPickerStyleReady = false;
function ensureWsPickerStyle() {
  if (_wsPickerStyleReady || document.getElementById("ws-doctype-picker-style")) { _wsPickerStyleReady = true; return; }
  const st = document.createElement("style");
  st.id = "ws-doctype-picker-style";
  st.textContent = [
    ".ws-dt-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:2px 10px;min-height:320px;max-height:340px;overflow:auto;border:1px solid #EBEDF0;border-radius:8px;padding:10px 12px;margin-top:6px;background:#FAFBFC;}",
    ".ws-dt-grid .dt-option{padding:4px 2px;}",
    "@media(max-width:900px){.ws-dt-grid{grid-template-columns:repeat(2,minmax(0,1fr));min-height:300px;}}",
    "@media(max-width:600px){.ws-dt-grid{grid-template-columns:1fr;min-height:220px;max-height:300px;}}",
    ".ws-dt-other{grid-column:1/-1;border-top:1px dashed #E3E6EB;margin-top:4px;padding:8px 6px 2px;background:#FFF9EB;border-radius:6px;}",
    ".ws-dt-other small{display:block;color:#8A6100;font-size:11px;line-height:1.5;margin-top:2px;}",
    ".ws-dt-other-note{margin:6px 0 0;font-size:11.5px;color:#8A6100;line-height:1.6;background:#FFF9EB;border:1px dashed #E9D8A6;border-radius:6px;padding:7px 9px;}",
    ".ws-dt-count{font-size:12px;color:#8F959E;margin:6px 0 0;}",
    ".ws-suit{margin-top:10px;border:1px solid #E3E6EB;border-radius:8px;padding:9px 11px;font-size:12px;line-height:1.65;background:#FAFBFC;}",
    ".ws-suit.ok{border-color:#B7E4C7;background:#F2FBF5;}",
    ".ws-suit.err{border-color:#F5C2C0;background:#FEF2F2;}",
    ".ws-suit-title{font-weight:600;margin-bottom:2px;}",
    ".ws-suit.ok .ws-suit-title{color:#0F7B4F;}",
    ".ws-suit.err .ws-suit-title{color:#B91C1C;}",
    ".ws-suit-desc{color:#5A5F66;}",
    ".ws-suit-groups{margin:6px 0 0;padding-left:18px;color:#5A5F66;}",
    ".ws-suit-split{color:#B91C1C;margin-top:3px;}",
    ".ws-dialog-wide{width:min(680px,calc(100vw - 32px))!important;}"
  ].join("\n");
  document.head.appendChild(st);
  _wsPickerStyleReady = true;
}
const USAGE_KEY = "rp_type_usage";
function usageMap() {
  try { return JSON.parse(localStorage.getItem(USAGE_KEY) || "{}"); } catch (e) { return {}; }
}
function bumpUsage(kind, val) {
  if (!val) return;
  const u = usageMap();
  u[kind] = u[kind] || {};
  u[kind][val] = (u[kind][val] || 0) + 1;
  try { localStorage.setItem(USAGE_KEY, JSON.stringify(u)); } catch (e) {}
}
function sortByUsage(kind, opts) {
  const u = (usageMap()[kind] || {});
  const fixed = opts.filter(o => o.fixed);
  const rest = opts.filter(o => !o.fixed);
  rest.sort((a, b) => (u[b.v] || 0) - (u[a.v] || 0));
  return [...fixed, ...rest];
}
async function initNpSelects(opts) {
  // T-111：业务管理员不做新建项目（菜单不提供 + 路由守卫 + 服务端 POST 403）；数据加载层同样兜底。
  // T-108：后台预热（DOMContentLoaded）传入 {silent:true}，角色不符时静默跳过，不打扰业务管理员。
  const _silent = !!(opts && opts.silent);
  const _npDeny = typeof roleViewDenied === "function" ? roleViewDenied("newproject") : "";
  if (_npDeny) {
    if (!_silent) {
      showPermDeniedNotice("newproject", _npDeny);
      if (typeof showToast === "function") showToast(_npDeny, "err");
    }
    return;
  }
  let cat = [], docs = [], wsTypes = [];
  try {
    const [cr, lr, wr] = await Promise.all([fetch("/api/v1/audit-categories"), fetch("/api/v1/audit-points/library"), fetch("/api/v1/workspaces")]);
    const cj = await cr.json(); cat = Array.isArray(cj) ? cj : [];
    const lj = await lr.json(); docs = Array.isArray(lj.document_types) ? lj.document_types : [];
    const wj = await wr.json(); wsTypes = (wj && wj.current && Array.isArray(wj.current.doc_types)) ? wj.current.doc_types.filter(Boolean) : [];
  } catch (e) {}
  if (!docs.length) docs = FALLBACK_DOC_TYPES.slice();
  // T-105：文件类型库最后一项是“其他（未列入标准类型）”；接口不可用时也要保证该兜底项可被项目端选择。
  if (!docs.some(x => x.name === OTHER_DOC_TYPE)) {
    docs = docs.concat([{ name: OTHER_DOC_TYPE, base_type: "general", default_audit_types: [], other: true }]);
  }
  // 工作空间声明了文件类型后，项目只能在该范围内选择
  window.__wsDocTypes = wsTypes;
  if (wsTypes.length) {
    const allowed = docs.filter(x => wsTypes.includes(x.name));
    docs = allowed.length ? allowed : wsTypes.map(n => ({ name: n, base_type: wsBaseType(n), other: n === OTHER_DOC_TYPE }));
  }
  npDocTypes = docs;
  const _npLabel = document.querySelector("#np-space-label");
  if (_npLabel) {
    try {
      const wj2 = await (await fetch("/api/v1/workspaces")).json();
      _npLabel.textContent = "当前工作空间：" + (((wj2.current || {}).name) || "通用空间");
    } catch (e) {}
  }
  const catOpts = [{ v: "", t: "AI 自动判断（推荐 · 全部范围）", fixed: true },
                   ...(cat || []).map(c => ({ v: c.id, t: `${c.id} · ${c.name}` }))];
  const fs = $("#np-type"), cs = $("#np-cat");
  const _npTypeHint = $("#np-type-hint");
  const _wsScope = wsTypes.slice();  // 空间原始类型范围（不随项目端选择重排而变）
  function npTypeHintText(name) {
    const n = String(name || "");
    const _ws = _wsScope;
    const scope = _ws.length ? `当前工作空间限定：${_ws.join("、")}；` : "当前工作空间未限定文件类型；";
    if (!n) return scope + "请选择本次项目的文件类型。";
    if (n === OTHER_DOC_TYPE) {
      return scope + "已选「其他（未列入标准类型）」：按通用规则执行，不伪造专用规则，涉及该类型的审核结论需人工确认。";
    }
    return scope + `已选「${n}」（${WS_DOMAIN_LABELS[wsBaseType(n)] || "通用/未归类"}）。`;
  }
  if (fs) {
    const cur = fs.value || "";
    const docOpts = docs.map(x => ({ v: x.name, t: x.name, base: x.base_type || "general" }));
    const sorted = sortByUsage("file", docOpts);
    fs.innerHTML = '<option value="">请选择文档类型</option>' + sorted.map(o => `<option value="${esc(o.v)}" data-base="${esc(o.base || "general")}">${esc(o.t)}</option>`).join("");
    if (cur && [...fs.options].some(o => o.value === cur)) fs.value = cur;
    if (wsTypes.length) {
      const _first = wsTypes.find(t => [...fs.options].some(o => o.value === t));
      if (!fs.value) fs.value = _first || (sorted[0] ? sorted[0].v : "");
      fs.disabled = wsTypes.length === 1;
    } else if (!fs.value && docOpts.length) {
      // 无限定空间保持旧行为：默认继承文件类型库第一个类型的业务域（项目创建仍按所选类型）
      fs.value = docOpts[0].v;
    }
    fs.onchange = () => {
      if (_npTypeHint) _npTypeHint.textContent = npTypeHintText(fs.value);
      // 项目端可选文件类型：new_project_view.createProject 读取 window.__wsDocTypes[0] 作为本次项目文件类型，
      // 这里把用户选择的类型置于首位（不改其他文件；仅切换本次项目继承的类型）。
      try {
        if (fs.value) {
          const _all = (window.__wsDocTypes || []).filter(x => x !== fs.value);
          window.__wsDocTypes = [fs.value].concat(_all);
        }
      } catch (e) {}
    };
    if (_npTypeHint) _npTypeHint.textContent = npTypeHintText(fs.value);
  }
  // 审核范围 A–G 是项目级路由范围，不是规则判定模板：默认保留 AI 自动判断，并展示只读映射说明。
  const _npMap = document.querySelector("#np-cat-map");
  if (_npMap && !_npMap.dataset.ready) {
    _npMap.innerHTML = auditRangeMapHtml();
    _npMap.hidden = false;
    _npMap.dataset.ready = "1";
  }
  const hint = $("#np-type-hint");
  const _nplabel = document.querySelector("#nr-space-label");
  if (_nplabel && document.querySelector("#view-newproject") && !document.querySelector("#view-newproject").hidden) {
    try {
      const w = await (await fetch("/api/v1/workspaces")).json();
      _nplabel.textContent = "当前工作空间：" + ((w.current || {}).name || "通用空间");
    } catch (e) {}
  }
  if (hint && !fs) {
    hint.textContent = wsTypes.length
      ? `当前工作空间限定：${wsTypes.join("、")}；只能从这些类型中选择。`
      : "当前工作空间未限定文件类型；创建空间时可设置 1~5 个类型。";
  }
  if (cs) cs.innerHTML = sortByUsage("cat", catOpts).map(o => `<option value="${esc(o.v)}">${esc(o.t)}</option>`).join("");
  // 异步回填下拉后，如果用户还没改动，则刷新 dirty 基线，避免把回填当未保存修改。
  if (currentView === "newproject" && typeof uxDirtyIsDirty === "function" && !uxDirtyIsDirty("newproject")) uxDirtyReset("newproject");
}

async function initTypeMemory() {
  try {
    const r = await (await fetch("/api/v1/doctypes/last?scope=project&id=")).json();
    const hint = $("#np-type-hint"), sel = $("#np-type");
    if (r && r.doc_type && sel) {
      const _wsTypes = window.__wsDocTypes || [];
      let opt = [...sel.options].find(o => o.text.includes(r.doc_type) || o.value === r.doc_type);
      if (!opt && _wsTypes.length) { if (hint) hint.textContent = `当前工作空间限定：${_wsTypes.join("、")}；上次使用类型不在范围内`; return; }
      if (!opt) {
        // 记忆里的类型不在下拉里（例如自定义类型）：补一个选项，避免“有记忆但不显示”
        opt = document.createElement("option");
        opt.value = r.doc_type; opt.text = `${r.doc_type}（上次使用）`;
        opt.dataset.base = npDocTypes.find(x => x.name === r.doc_type)?.base_type || "general";
        sel.appendChild(opt);
      }
      sel.value = opt.value;
      hint.textContent = _wsTypes.length
        ? `当前工作空间限定：${_wsTypes.join("、")}；已选「${r.doc_type}」。`
        : `已继承上次类型：${r.doc_type}（可修改）`;
    }
  } catch (e) {}
  if (currentView === "newproject" && typeof uxDirtyIsDirty === "function" && !uxDirtyIsDirty("newproject")) uxDirtyReset("newproject");
}
async function addNewType() {
  const box = $("#np-newtype"), hint = $("#np-type-hint"), sel = $("#np-type");
  const name = (box.value || "").trim();
  if (!name) { hint.textContent = "请输入类型名称"; box.focus(); return; }
  if ([...sel.options].some(o => o.value === name)) {
    sel.value = name; hint.textContent = "该类型已存在，已为你选中"; return;
  }
  if (!confirm(`新增文档类型「${name}」并选中？`)) return;
  const base = /食品|工艺|配方|检验|标签/.test(name) ? "food"
    : /合同|招标|投标|报价|采购|销售/.test(name) ? "contract"
    : /申报|许可|资质|执照|审批/.test(name) ? "application" : "general";
  try {
    const r = await fetch("/api/v1/doctypes/create", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, aliases: [name], audit_types: [] }) });
    const j = await r.json();
    if (!j.ok) {
      hint.textContent = j.reason || "未能写入公共类型库，已加入本次选择";
    } else {
      hint.textContent = "已新增并选中：" + name;
    }
  } catch (e) { hint.textContent = "未能写入公共类型库，已加入本次选择"; }
  const opt = document.createElement("option");
  opt.value = name; opt.text = name + "（本次新增）"; opt.dataset.base = base;
  sel.appendChild(opt); sel.value = name; sel.dispatchEvent(new Event("change"));
  box.value = "";
}

document.addEventListener("DOMContentLoaded", () => {
  // T-108：新建项目表单后台预热只对“允许新建项目”的角色执行（reviewer）；
  // 业务管理员/系统管理员静默跳过，避免登录首页出现「无权限访问新建项目」提示。
  setTimeout(() => {
    const _warmNp = () => {
      if (typeof currentRole !== "undefined" && currentRole) {
        if (typeof roleViewDenied === "function" && roleViewDenied("newproject")) return;
        initNpSelects({ silent: true }); initTypeMemory();
      } else {
        setTimeout(_warmNp, 500);
      }
    };
    _warmNp();
  }, 800);
  loadPermissions();
  initWorkspaceSwitcher();
  document.querySelector("#btn-add-newtype")?.addEventListener("click", addNewType);
  document.querySelector("#np-newtype")?.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); addNewType(); } });
});

/* ===================== 智能体运行面板 ===================== */
const RUN_HINT = {
  parse: { label: "文件路径", ph: "/path/to/文件.xlsx", field: "path", extra: "" },
  extract: { label: "待抽取文本", ph: "中心温度达到 85℃ 出锅，冷却至 10℃ 以下…", field: "text", textarea: true },
  rule: { label: "自然语言要求 / 标准片段", ph: "所有炒制工序必须标注中心温度达到 85℃ 以上才能出锅", field: "text", textarea: true },
  conflict: { label: "输入", ph: "留空即分析全部已发布规则", field: "", extra: "" },
  analyze: { label: "每次分析条数", ph: "20", field: "limit", extra: "" },
};
function renderAgentRunHistory(d) {
  const runs = d.recent_runs || [];
  return `<div class="agent-run-history"><div class="agent-run-history-head"><b>最近运行</b><span class="muted">${runs.length ? "来自主链路/手动运行" : "暂无运行记录"}</span></div>` +
    (runs.length ? `<table class="table"><thead><tr><th>时间</th><th>状态</th><th>耗时</th><th>关联项目</th></tr></thead><tbody>` +
      runs.map(r => `<tr><td class="muted">${esc(r.created_at || "—")}</td><td><span class="pill ${r.status === "ok" ? "published" : "draft"}">${esc(r.status || "—")}</span></td><td class="num">${r.latency == null ? "—" : r.latency + "ms"}</td><td class="muted">${esc(r.case_id || "—")}</td></tr>`).join("") + `</tbody></table>`
      : `<div class="empty" style="padding:14px 0">该智能体尚未产生运行记录。</div>`) +
    ((d.node_runs || []).length ? `<div class="agent-run-history-head" style="margin-top:12px"><b>最近节点执行</b><span class="muted">节点级 trace</span></div><table class="table"><thead><tr><th>节点</th><th>类型</th><th>状态</th><th>耗时</th><th>时间</th></tr></thead><tbody>` +
      d.node_runs.slice(0, 12).map(n => `<tr><td>${esc(n.node_name || n.node_id)}</td><td class="muted">${esc(n.node_type || "—")}</td><td><span class="pill ${n.status === "ok" || n.status === "executed" ? "published" : "draft"}">${esc(n.status || "—")}</span></td><td class="num">${n.latency == null ? "—" : n.latency + "ms"}</td><td class="muted">${esc(n.created_at || "—")}</td></tr>`).join("") + `</tbody></table>` : "") + `</div>`;
}
function renderRunPanel(d) {
  const h = RUN_HINT[d.type] || { label: "输入（JSON）", ph: "{}", field: "json" };
  const input = h.textarea
    ? `<textarea id="run-input" class="field" style="width:100%;min-height:90px" placeholder="${esc(h.ph)}"></textarea>`
    : (h.field ? `<input id="run-input" class="field" style="width:100%" placeholder="${esc(h.ph)}">` : "");
  return `<div class="card" style="border:0;padding:0">
    <div class="muted" style="font-size:12px;margin-bottom:8px">${esc(h.label)}${h.field ? "" : "（无需输入）"}</div>
    ${input}
    <div class="actions" style="margin-top:10px"><button class="btn primary" id="agent-run-btn">运行智能体</button>
      <span class="muted" id="agent-run-msg"></span></div>
    <div id="agent-run-result" style="margin-top:12px"></div>
  </div>`;
}
function bindRunPanel(d) {
  const btn = $("#agent-run-btn");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    const h = RUN_HINT[d.type] || {};
    const payload = {};
    const v = $("#run-input")?.value?.trim() || "";
    if (h.field && v) payload[h.field] = (h.field === "limit") ? Number(v) : v;
    btn.disabled = true; btn.textContent = "运行中…";
    try {
      const r = await (await fetch(`/api/v1/agents/${d.id}/run`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload) })).json();
      $("#agent-run-msg").textContent = `${r.status} · ${r.latency_ms}ms`;
      const res = r.result || {};
      let html = "";
      if (res.error) html = `<div class="evidence-bar">${esc(res.error)}</div>`;
      else if (d.type === "parse") html = kvBlock({ 字符数: res.chars, 段落: res.paragraphs, 页数: res.pages, 事实数: res.fact_count });
      else if (d.type === "extract") html = factsTable(res.facts || []);
      else if (d.type === "conflict") html = conflictTable(res.conflicts || []);
      else if (d.type === "analyze") html = fpTable(res.items || [], res.note);
      else html = `<pre style="white-space:pre-wrap;font-size:12px">${esc(JSON.stringify(res, null, 2))}</pre>`;
      $("#agent-run-result").innerHTML = html;
    } finally { btn.disabled = false; btn.textContent = "运行智能体"; }
  });
}
function kvBlock(o) {
  return `<div class="ac-kpis" style="grid-template-columns:repeat(4,1fr)">` +
    Object.entries(o).map(([k, v]) => `<div class="ac-kpi"><b>${esc(String(v))}</b><span>${esc(k)}</span></div>`).join("") + `</div>`;
}
function factsTable(fs) {
  if (!fs.length) return `<div class="muted">无事实</div>`;
  return `<table class="table"><thead><tr><th>类型</th><th>值</th><th>单位</th><th>上下文</th></tr></thead><tbody>` +
    fs.map(f => `<tr><td>${esc(f.kind)}</td><td>${esc(f.value)}</td><td>${esc(f.unit || "")}</td>
      <td class="muted">${esc((f.context || "").slice(0, 40))}</td></tr>`).join("") + `</tbody></table>`;
}
function conflictTable(cs) {
  if (!cs.length) return `<div class="muted">未发现冲突</div>`;
  return `<table class="table"><thead><tr><th>规则 A</th><th>规则 B</th><th>结论</th><th>说明</th></tr></thead><tbody>` +
    cs.map(c => `<tr><td>${esc(c.a)}</td><td>${esc(c.b)}</td>
      <td><span class="pill ${c.type === "已证明冲突" ? "draft" : "published"}">${esc(c.type)}</span></td>
      <td class="muted">${esc(c.detail || "")}</td></tr>`).join("") + `</tbody></table>`;
}
function fpTable(items, note) {
  if (note) return `<div class="muted">${esc(note)}</div>`;
  if (!items.length) return `<div class="muted">无数据</div>`;
  return `<table class="table"><thead><tr><th>规则</th><th>问题</th><th>根因</th><th>建议</th></tr></thead><tbody>` +
    items.map(i => `<tr><td>${esc(i.rule)}</td><td>${esc(i.title)}</td>
      <td><span class="pill draft">${esc(i.root_cause || "待分析")}</span></td>
      <td class="muted">${esc(i.ai_suggestion || i.suggestion || "")}</td></tr>`).join("") + `</tbody></table>`;
}

/* ===================== 新建规则 ===================== */
const CATS = RULE_TYPE_LABELS;
/* L79：新建表单模板清单 = 单一真相源 app/engine/registry.py 的 ui_selectable 投影（10 类）。
 * 历史在这里的 format（格式）/ preprocess（前处理）两类 **没有专属执行器**（无槽位/无判据
 * 执行分支，选了也只会落成语义规则或发布不了），已从新建表单移除，只在 RULE_TYPE_LABELS
 * 里保留展示名（内置规则/历史规则类别仍可正常显示）。
 * 另 2 类执行器专用模板（field_presence 字段存在性 / cross_relation 跨文件关系）在
 * registry 12 类可执行模板内，但只经 API/导入/编译路径进入，不出现在新建表单。 */
const RULE_TEMPLATES = {
  limit: { label: "限值", fields: [["metric","指标","如 中心温度"],["op","比较","",[" >=","<=","=","<",">"]],["value","目标值","如 85"],["unit","单位","如 ℃"],["tolerance","允差/范围","如 ±2"]] },
  completeness: { label: "完整性", fields: [["required_docs","必备文件","逗号分隔"]] },
  record: { label: "记录要求", fields: [["record_field","记录字段","如 检验日期/签名"],["required","是否必填","",["必填","选填"]]] },
  consistency: { label: "一致性", fields: [["objects","比对对象","如 合同金额,报价表金额"],["across","跨文档/位置","如 合同 vs 报价表"]] },
  prohibited: { label: "禁止性", fields: [["object","禁止对象","如 转包/超范围经营"],["forbidden","禁止表述","如 不得转包"]] },
  frequency: { label: "时限/频率", fields: [["action","动作","如 消毒"],["frequency","频率","如 每班"],["window","时间窗","如 4 小时"]] },
  personnel: { label: "人员资质", fields: [["role","岗位/角色","如 检验员"],["qualification","资质要求","如 健康证/上岗证"]] },
  equipment: { label: "设备设施", fields: [["equipment","设备","如 金属探测仪"],["state","状态要求","如 校准有效"]] },
  label: { label: "标识标签", fields: [["item","对象","如 预包装食品"],["label_required","必备标识","如 生产日期/保质期"]] },
  citation: { label: "引用一致", fields: [["cited","被引用内容","如 标准号"],["source","引用来源","如 GB 2760"]] },
};
const DOC_TYPE_OPTIONS = ["食品工艺书","合同","申报材料","通用文件"];
const AUDIT_FACE_OPTIONS = [["A","主体资格"],["B","结构完备"],["C","事实数据"],["D","逻辑结论"],["E","权利义务"],["F","商务执行"],["G","披露申报"]];
/* ===== 审核范围（A–G）与判定模板是两套不同语义的分类 =====
 * - 审核范围 = 项目级路由范围：case.audit_category → manifest `_audit_category_gate`
 * - 判定模板 = 规则级“怎么判”的模板：RULE_TEMPLATES → slots/IR（新建表单可选 10 类；
 *   另有 2 类执行器专用模板只在 app/engine/registry.py 与 API/导入路径，见上）
 * 下面的对应关系镜像后端 app/engine/audit_category.py 的 CATEGORY_TO_RULES（该后端表用
 * rulegen 类别名，含无专属执行器的 format/preprocess），只用于界面说明，不参与判定
 * （前端不新增路由逻辑）。后端未映射的判定模板，在项目选定具体审核范围时不会执行，
 * 此处如实提示“保持 AI 自动判断”，不伪造映射、不合并两套语义。 */
const AUDIT_RANGES = [
  ["A", "主体、资格与程序"],
  ["B", "结构与内容完备"],
  ["C", "事实、数据与证据"],
  ["D", "逻辑、论证与结论"],
  ["E", "权利义务与风险分配"],
  ["F", "商务、执行与合规底线"],
  ["G", "披露、申报与绩效"],
];
const RANGE_TEMPLATES = {
  A: [],
  B: ["completeness", "format"],
  C: ["consistency", "limit"],
  D: ["consistency"],
  E: [],
  F: ["limit", "preprocess"],
  G: [],
};
const TEMPLATE_RANGES = (() => {
  const out = {};
  Object.keys(RULE_TEMPLATES).forEach((key) => {
    out[key] = AUDIT_RANGES.map((r) => r[0]).filter((id) => (RANGE_TEMPLATES[id] || []).includes(key));
  });
  return out;
})();
/** 供 UI 测试/静态核对读取的只读快照（不参与判定）。 */
window.__UX_RANGES = { ranges: AUDIT_RANGES, rangeTemplates: RANGE_TEMPLATES, templateRanges: TEMPLATE_RANGES };
const RANGE_EMPTY_NOTE = "该范围没有内置判定模板映射：平台内置规则与按判定模板保存的客户规则在选定该范围时不会执行（主要由审核点位库覆盖）。需要执行自定义规则时，请把项目保持「AI 自动判断（全部）」。";
function rangeTemplatesText(rangeId) {
  const list = RANGE_TEMPLATES[rangeId] || [];
  // format/preprocess 是 rulegen 类别（后端 audit_category.CATEGORY_TO_RULES 镜像），不在新建
  // 表单模板表里；展示名回退 RULE_TYPE_LABELS，不伪造映射、不删后端既有的路由类别。
  const labelOf = (k) => RULE_TEMPLATES[k]?.label || RULE_TYPE_LABELS[k] || k;
  return list.length ? list.map(labelOf).join("、") : "";
}
function templateRangesText(tpl) {
  const list = TEMPLATE_RANGES[tpl] || [];
  if (!list.length) return "暂无 A–G 路由映射（选择具体审核范围时该规则不会执行；项目请保持「AI 自动判断（全部）」）";
  return list.map((id) => {
    const nm = (AUDIT_RANGES.find((r) => r[0] === id) || [])[1] || "";
    return `${id} ${nm}`;
  }).join("、");
}
function auditRangeMapHtml() {
  const rows = AUDIT_RANGES.map(([id, name]) => {
    const tpls = RANGE_TEMPLATES[id] || [];
    const cls = tpls.length ? "has-tpl" : "no-tpl";
    const rights = tpls.length
      ? `可选点位 + 判定模板为「${tpls.map((k) => RULE_TEMPLATES[k]?.label || RULE_TYPE_LABELS[k] || k).join("、")}」的规则`
      : "仅审核点位库覆盖；无判定模板映射";
    return `<tr class="${cls}"><td><b>${id}</b> ${esc(name)}</td><td>${esc(rights)}</td><td>${tpls.length ? "可路由" : "保持自动判断"}</td></tr>`;
  }).join("");
  return `<details class="np-cat-map-details" open><summary>A–G 审核范围与 12 类判定模板的对应关系（平台内置路由，只读说明）</summary>
    <table class="np-cat-map-table"><thead><tr><th>审核范围（项目级）</th><th>选定后执行的规则类别 / 点位</th><th>建议</th></tr></thead><tbody>${rows}</tbody></table>
    <p class="np-cat-map-note">审核范围决定“本次项目路由到哪些规则类别/点位”，不是规则判定模板；判定模板决定“单条规则怎么判”。不确定时保持「AI 自动判断（全部）」，两者不会互相替代。</p>
  </details>`;
}
/* ===================== 新建规则表单的判定模板 / A–G 说明 ===================== */
/* T-64：新建单条规则按六组字段展示，与规则详情同口径。
   六组（与 T-63 冲突规则快照、规则详情一致）：
   RuleDefinition 规则定义 / Scope 适用范围 / ExecutionPlan 执行计划 /
   Evidence 证据要求 / Lifecycle 生命周期与版本 / Usage 关联与使用。
   生命周期与关联使用由系统生成，新建时只做只读说明；保存后在规则详情看真实值。 */
function renderManualRule(box) {
  const template = (k) => RULE_TEMPLATES[k] || RULE_TEMPLATES.limit;
  const slotField = (f) => {
    const [k, label, ph, opts] = f;
    if (Array.isArray(opts)) return `<label class="nr-field"><span>${label}</span><select data-slot="${k}" class="field">${opts.map(o => `<option${o===ph?" selected":""}>${esc(o)}</option>`).join("")}</select></label>`;
    return `<label class="nr-field"><span>${label}</span><input data-slot="${k}" class="field" placeholder="${esc(ph||"")}"></label>`;
  };
  const renderSlots = (cat) => {
    const t = template(cat);
    return t.fields.map(slotField).join("");
  };
  const examples = {
    limit: "示例：中心温度 ≥ 85℃；实测 70℃ → 不通过。证据看工序参数表里的“实测中心温度”。",
    completeness: "示例：必备文件：营业执照、生产许可证、检验报告；缺少检验报告 → 不通过。",
    consistency: "示例：合同金额与报价表金额一致；合同 100 万、报价表 98 万 → 不通过。",
    prohibited: "示例：合同出现“允许转包”表述 → 不通过；有“不得转包”才通过。",
    record: "示例：检验记录必须有检验日期和检验员签字；日期空白 → 不通过。",
    frequency: "示例：消毒记录每班一次；当天 8 小时班次没有记录 → 不通过。",
    personnel: "示例：检验员必须持有效健康证；健康证过期 → 不通过。",
    equipment: "示例：杀菌锅校准必须在有效期内；校准到期日早于生产日期 → 不通过。",
    label: "示例：预包装食品标签必须有生产日期和保质期；缺少保质期 → 不通过。",
    citation: "示例：引用标准号 GB 2760 与正文标准号一致；正文写 GB 2761 → 不通过。",
  };
  const _ownerLabel = ((currentUser && (currentUser.name || currentUser.sub)) || "当前账号");
  const _groupEn = 'style="font-style:normal;font-weight:400;font-size:11px;color:#8F959E;margin-left:6px"';
  box.innerHTML = `
    <div class="nr-form" id="nr-manual-form">
      <section class="nr-section" id="nr-basic-section"><h3>① 规则定义 <em ${_groupEn}>RuleDefinition</em></h3>
        <div class="nr-help">规则本体：名称、判定模板、风险等级。<b>判定模板决定“单条规则怎么判、填哪些参数”</b>，不是项目级「审核范围（A–G）」，也不是审核点位。</div>
        <div class="nr-grid">
          <label class="nr-field wide"><span>规则名称 <em class="req">必填</em></span><input id="nr-name" class="field" placeholder="例如：卤制中心温度不得低于 85℃"></label>
          <div class="nr-field"><span>判定模板 <em class="req">必填</em></span>
            <select id="nr-cat" class="field">${Object.entries(RULE_TEMPLATES).map(([k,v]) => `<option value="${k}">${esc(v.label)}</option>`).join("")}</select>
            <small class="nr-field-help">决定下面出现哪些判据参数；不是项目级「审核范围（A–G）」，也不是审核点位。</small>
            <div class="nr-template-range" id="nr-template-range">适用审核范围：加载中…</div>
          </div>
          <label class="nr-field"><span>风险等级 <em class="req">必填</em></span><select id="nr-rclass" class="field">
              <option value="R1">严重 · 命中后项目不通过</option>
              <option value="R3" selected>一般 · 命中后提示复核</option>
              <option value="R5">提示 · 仅提示，不阻断项目</option>
            </select>
            <small class="nr-field-help">不是规则难度；它决定报告里的严重度。</small>
          </label>
          <div class="nr-field wide"><span>规则形式（保存时显式记录，详情同口径展示）</span>
            <div style="font-size:12px;color:#1F2329;padding:6px 0">单条参数规则 <span style="color:#8F959E">（本表单选择「单条数据裁决」，保存为单条规则；决策表组合请在决策表编辑器保存）</span></div>
          </div>
        </div>
      </section>
      <section class="nr-section" id="nr-scope-section"><h3>② 适用范围 <em ${_groupEn}>Scope</em></h3>
        <div class="nr-help">说明规则“管什么、给谁看、怎么检索”。<b>审核范围（A–G）、项目文档类型、项目空间是项目级字段，不属于规则字段</b>；本规则会在哪些审核范围执行，由判定模板映射决定（见上方「适用审核范围」）。</div>
        <div class="nr-grid">
          <label class="nr-field wide"><span>规则说明 <em class="opt">选填</em></span><textarea id="nr-desc" class="field" placeholder="给审核员看的业务解释、边界和例外。例如：只适用于卤制工序，不适用于杀菌工序。"></textarea></label>
          <div class="nr-field wide"><span>标签 <em class="opt">选填</em></span>
            <div class="nr-tag-input" id="nr-tags-wrap">
              <div class="nr-tag-chips" id="nr-tags-chips"></div>
              <input id="nr-tags-input" class="nr-tag-text field" type="text" autocomplete="off" placeholder="输入标签后按 Enter 或逗号添加，例如：高温、出厂检验、客户A">
            </div>
            <input id="nr-tags" type="hidden" value="[]">
            <small class="nr-field-help">可添加多个标签；Enter / 逗号添加，点 × 或 Backspace 删除，自动去重。标签只用于搜索和筛选，不参与判定，也不是审核范围。</small>
          </div>
        </div>
        <div class="nr-scope-grid" style="margin-top:10px">
          <div><span>当前工作空间</span><b id="nr-scope-ws">加载中…</b><small>规则归属当前空间；空间是项目/空间级字段，这里只读。</small></div>
          <div><span>自动适用的文档类型（当前空间配置，只读）</span><b id="nr-scope-docs">加载中…</b><small>新规则自动适用于本空间全部文件类型，无需填写；保存时自动写入 slots.applicable_types / scope.applicable_types。空间未配置时显示“未限定，以实际空间配置为准”。</small></div>
          <div><span>规则负责人</span><b id="nr-scope-owner">${esc(_ownerLabel)}</b><small>谁创建规则，谁就是负责人；保存后自动写入。</small></div>
        </div>
      </section>
      <section class="nr-section" id="nr-point-section" style="border-top:1px dashed #E5E6E8"><h3>② 适用范围 · 平台点位映射 <em class="opt">选填</em></h3>
        <div class="nr-help">点位不是执行顺序，也不要求全量选择。默认「自动映射（推荐）」；需要明确绑定时按 <b>审核大类（A–G）→ 审核类型 → 审核点位</b> 三级选择，或用搜索兜底。当前工作空间外的点位不会出现。</div>
        <div class="nr-point-mode" role="radiogroup" aria-label="点位映射方式">
          <label class="nr-point-mode-card on"><input type="radio" name="nr-point-mode" value="auto" checked><span><b>自动映射（推荐）</b><small>保存时不指定点位，由系统按规则名称/判据自动匹配；没有合适点位就保持默认。</small></span></label>
          <label class="nr-point-mode-card"><input type="radio" name="nr-point-mode" value="manual"><span><b>手工指定点位</b><small>按 A–G 大类 → 审核类型 → 点位选择；也可用搜索兜底。</small></span></label>
        </div>
        <div id="nr-point-manual" class="nr-point-manual" hidden>
          <div class="nr-point-cascade">
            <label>① 审核大类<select id="nr-point-cat" class="field"></select></label>
            <label>② 审核类型<select id="nr-point-type" class="field"></select></label>
            <label>③ 审核点位<select id="nr-point" class="field" aria-label="审核点位"></select></label>
          </div>
          <div class="nr-point-search-row">
            <input id="nr-point-search" class="field" placeholder="搜索兜底：点位编码 / 名称 / 审核类型，例如：温度、A01-001">
            <span class="nr-point-count" id="nr-point-count"></span>
          </div>
          <div id="nr-point-results" class="nr-point-results" hidden></div>
          <div id="nr-point-other" class="nr-point-other" hidden>
            <b>其他 / 未收录点位</b>
            <div>当前空间没有匹配的平台点位。可<b>保存为未绑定自定义规则</b>（点位列留空，不自动生成正式点位）；候选点位需业务管理员后续创建（在平台点位库操作），本页不自动生成正式点位。</div>
            <div class="nr-point-other-actions"><button type="button" class="btn" id="nr-point-unbind">按未绑定自定义规则保存</button><button type="button" class="btn" id="nr-point-other-cancel">返回搜索</button></div>
          </div>
          <div id="nr-point-note" class="nr-field-help">正在加载当前空间可用点位…</div>
        </div>
      </section>
      <section class="nr-section nr-kind-section" id="nr-kind-section">
        <h3>③ 执行计划 · 判定方式 <em class="req">必选</em></h3>
        <div class="nr-kind-caption">单条规则判定 / 决策表组合：选择决定保存路径与执行方式；切换后保存按钮始终可见。</div>
        <div class="nr-kind-cards" role="radiogroup" aria-label="判定方式">
          <label class="nr-kind-card on" data-kind="single">
            <input type="radio" name="nr-manual-kind" value="single" checked>
            <span class="nr-kind-card-main"><b>单条数据裁决</b><span>一个判据 / 一个阈值 / 一条条款，判“通过 / 不通过”；使用本表单直接保存为单条规则。</span></span>
            <span class="nr-kind-card-tag">表单保存 · 单条规则</span>
          </label>
          <label class="nr-kind-card" data-kind="decision">
            <input type="radio" name="nr-manual-kind" value="decision">
            <span class="nr-kind-card-main"><b>决策表组合多条件</b><span>多个条件按 且 / 或 组合，命中不同结论；在决策表编辑器中定义并保存。</span></span>
            <span class="nr-kind-card-tag">决策表编辑器 · 多条件</span>
          </label>
        </div>
        <div class="nr-kind-impact" id="nr-kind-impact" role="status"></div>
      </section>
      <div id="nr-single-only">
      <section class="nr-section" id="nr-criteria-section"><h3>③ 执行计划 · 判据与执行参数 <em ${_groupEn}>ExecutionPlan</em></h3>
        <div class="nr-help" id="nr-slots-help">按当前判定模板填写这一组判据参数；例如限值需要指标、比较、目标值、单位。</div>
        <label class="nr-field wide"><span>判据（可执行描述） <em class="req">必填</em></span><textarea id="nr-criterion" class="field" placeholder="写清楚：在什么条件下、比对什么、满足什么算通过，以及需要什么证据。例如：卤制工序实测中心温度必须 ≥ 85℃；以工序参数表“实测中心温度”为准。"></textarea>
          <small class="nr-field-help">审核员和系统都以这段判据为准；不要只写“按标准执行”。</small>
        </label>
        <div class="nr-grid" id="nr-slots" style="margin-top:10px">${renderSlots("limit")}</div>
        <div class="nr-example" id="nr-example">${esc(examples.limit)}</div>
        <div class="nr-help" style="margin-top:12px">系统按证据范围、汇总方式、判定方法和证据不足处理生成执行计划；保存后 manifest 以这组字段执行。<b>与详情「执行计划」同名字段展示。</b></div>
        <div class="nr-grid">
          <label class="nr-field wide"><span>证据范围（可多选）</span>
            <div style="display:flex;gap:12px;flex-wrap:wrap;padding-top:4px">
              <label><input type="checkbox" data-ev="block"> 区块</label>
              <label><input type="checkbox" data-ev="row"> 行</label>
              <label><input type="checkbox" data-ev="sheet"> Sheet</label>
              <label><input type="checkbox" data-ev="document" checked> 整份文档</label>
              <label title="当前仅部分支持"><input type="checkbox" data-ev="document_set"> 跨文件</label>
            </div><small class="nr-field-help">跨文件成对比较当前为部分支持；计划预览会标出未支持项。</small>
          </label>
          <label class="nr-field"><span>汇总方式</span><select id="nr-agg" class="field">
            <option value="single">单值/首行</option><option value="all" selected>全部行/全部子项</option><option value="any">任一满足</option><option value="sum">求和（部分支持）</option><option value="compare">跨对象比较（部分支持）</option>
          </select></label>
          <label class="nr-field"><span>判定方式</span><select id="nr-method" class="field">
            <option value="deterministic">确定性工具/数值</option><option value="semantic">语义判断</option><option value="hybrid">混合</option>
          </select></label>
          <label class="nr-field"><span>证据不足处理</span><select id="nr-fallback" class="field">
            <option value="abstain">转人工/无法判断</option><option value="ask">要求补证</option><option value="fail">判不满足</option><option value="single_block_first">先查单区块，再决定</option>
          </select></label>
        </div>
        <div class="actions"><button type="button" class="btn" id="nr-plan-preview">预览执行计划</button></div>
        <pre id="nr-plan-out" class="muted" style="white-space:pre-wrap;font-size:12px;margin-top:6px"></pre>
      </section>
      <section class="nr-section" id="nr-evidence-section"><h3>④ 证据要求 <em ${_groupEn}>Evidence</em></h3>
        <div class="nr-grid">
          <label class="nr-field wide"><span>必需证据</span><input id="nr-evidence" class="field" placeholder="例如：工序参数表 · 实测中心温度；或 检验报告 · 批准人签字">
            <small class="nr-field-help">告诉审核员判这条规则必须看哪里；不是必填，但建议写清楚。</small>
          </label>
          <label class="nr-field wide"><span>正例（预期满足）</span><textarea id="nr-pos" class="field" placeholder="例如：卤制设备：夹层锅 G-03；实测中心温度 88℃；保持 30 分钟；记录人签字完整。"></textarea></label>
          <label class="nr-field wide"><span>反例（预期不满足）</span><textarea id="nr-neg" class="field" placeholder="例如：卤制设备：夹层锅 G-03；实测中心温度 70℃；提前出锅；记录人签字空白。"></textarea>
            <small class="nr-field-help">正例/反例用于说明和测试规则，不是提交审核的必填材料。</small>
          </label>
        </div>
      </section>
      <section class="nr-section" id="nr-lifecycle-section"><h3>⑤ 生命周期与版本 <em ${_groupEn}>Lifecycle</em></h3>
        <div style="font-size:12px;line-height:1.75;color:#4E5969;background:#FAFBFC;border:1px solid #EEF0F2;border-radius:7px;padding:9px 12px">保存后由系统生成：状态 = 草稿、版本 = v0.1；草稿可直接「发布生效」（规则无需审批），发布前不进审核主链。发布后若检测到规则冲突会提示并跳转冲突提醒，不阻断发布、不回滚。详情页「生命周期与版本」显示真实状态、版本号、生效版本与版本历史。</div>
      </section>
      <section class="nr-section" id="nr-usage-section"><h3>⑥ 关联与使用 <em ${_groupEn}>Usage</em></h3>
        <div style="font-size:12px;line-height:1.75;color:#4E5969;background:#FAFBFC;border:1px solid #EEF0F2;border-radius:7px;padding:9px 12px">保存后系统自动统计：命中问题数、人工 override 数、引用点位与关联项目；新建时不填写。详情页「关联与使用」显示真实统计，不伪造数据。</div>
      </section>
      </div>
    </div>
    <div id="nr-manual-decision" class="nr-manual-decision" hidden>
      <b>决策表组合多条件</b>
      <p>已选择决策表：单条规则的字段会收起，<b>保存入口保持可见</b>（页面底部按钮变为“打开决策表编辑器”）。请在决策表编辑器中定义条件、命中策略和结论；保存后在平台启用并发布，才进入审核主链。</p>
    </div>
    <div class="actions" id="nr-manual-save-actions" style="margin-top:14px"><button id="nr-manual-save" class="btn primary">保存为草稿</button><span class="muted" id="nr-msg2"></span></div>`;
  const cat = box.querySelector("#nr-cat");
  const _templateRange = box.querySelector("#nr-template-range");
  const updateTemplateInfo = () => {
    const label = RULE_TEMPLATES[cat.value]?.label || "判定模板";
    const ranges = TEMPLATE_RANGES[cat.value] || [];
    if (_templateRange) {
      _templateRange.textContent = `适用审核范围：${templateRangesText(cat.value)}`;
      _templateRange.classList.toggle("no-range", !ranges.length);
      _templateRange.dataset.template = cat.value;
      _templateRange.dataset.ranges = ranges.join(",");
    }
    const ex = box.querySelector("#nr-example"); if (ex) ex.textContent = examples[cat.value] || examples.limit;
    const help = box.querySelector("#nr-slots-help");
    if (help) help.textContent = `当前判定模板「${label}」；这里填写这一组判据参数。判定模板决定“怎么判”，不等于项目级审核范围（A–G），也不等于审核点位。`;
  };
  cat.addEventListener("change", () => { box.querySelector("#nr-slots").innerHTML = renderSlots(cat.value); updateTemplateInfo(); });
  updateTemplateInfo();
  initTagChips(box);
  initRulePointPicker(box);

  // 判定方式：单条数据裁决 / 决策表组合。radio card 在「规则定义/适用范围」之后、「执行计划」字段之前；
  // 切到决策表只收起单条字段（适用范围+执行计划+证据+生命周期+使用说明），保存按钮始终可见（文案变为“打开决策表编辑器”）。
  const _kindRadios = Array.from(box.querySelectorAll('input[name="nr-manual-kind"]'));
  const _kindCards = Array.from(box.querySelectorAll(".nr-kind-card"));
  const _singleOnly = box.querySelector("#nr-single-only");
  const _scopeSection = box.querySelector("#nr-scope-section");
  const _pointSection = box.querySelector("#nr-point-section");
  const _decPanel = box.querySelector("#nr-manual-decision");
  const _saveBtn = box.querySelector("#nr-manual-save");
  let _nrSaving = false;   // T-83（D-L2-01）：保存 single-flight，防重复点击重复写
  const _impact = box.querySelector("#nr-kind-impact");
  const _kindValue = () => ((_kindRadios.find((r) => r.checked) || {}).value) || "single";
  const _applyManualKind = function () {
    const kind = _kindValue();
    const isDt = kind === "decision";
    _kindCards.forEach((card) => card.classList.toggle("on", (card.dataset.kind || "") === kind));
    if (_singleOnly) _singleOnly.hidden = isDt;
    if (_scopeSection) _scopeSection.hidden = isDt;
    if (_pointSection) _pointSection.hidden = isDt;
    if (_decPanel) _decPanel.hidden = !isDt;
    if (_saveBtn) { _saveBtn.hidden = false; _saveBtn.disabled = false; _saveBtn.textContent = isDt ? "打开决策表编辑器" : "保存为草稿"; }
    if (_impact) {
      _impact.classList.toggle("is-decision", isDt);
      _impact.innerHTML = isDt
        ? `<b>已选择：决策表组合多条件</b><div>影响：单条规则的适用范围、判据参数、执行计划、点位映射和证据样例会收起；条件与结论在决策表编辑器中定义。保存入口保持可见（点页面底部“打开决策表编辑器”），发布前不会进入审核主链。</div>`
        : `<b>已选择：单条数据裁决</b><div>影响：按本表单保存为一条单条规则；适用范围、判据参数、执行计划和点位映射按当前填写生效。系统仍会按规则内容给出是否更适合决策表的提示。</div>`;
    }
    if (typeof uxDirtyReset === "function" && !isDt) uxDirtyReset("newrule");
  };
  _kindRadios.forEach((r) => r.addEventListener("change", _applyManualKind));
  _applyManualKind();
  // 规则级适用文档类型不再由用户填写：自动取当前工作空间配置（只读缓存）。
  // 空间未配置时返回空数组；保存/预览都不写 applicable_types，页面显示“未限定，以实际空间配置为准”。
  const _autoDocTypes = () => {
    const _dts = (window.__nrScope && Array.isArray(window.__nrScope.docTypes))
      ? window.__nrScope.docTypes.map((x) => String(x || "").trim()).filter(Boolean) : [];
    return _dts;
  };
  const _ensureScopeContext = async () => {
    if (!window.__nrScope) { try { await loadRuleSpaceContext(); } catch (e) {} }
    return _autoDocTypes();
  };
  box.querySelector("#nr-plan-preview").addEventListener("click", async () => {
    const slots = { _template: cat.value, criterion: box.querySelector("#nr-criterion").value.trim() };
    box.querySelectorAll("#nr-slots [data-slot]").forEach(el => { slots[el.dataset.slot] = (el.value || "").trim(); });
    slots.evidence_scope = [...box.querySelectorAll("[data-ev]:checked")].map(x => x.dataset.ev);
    slots.aggregation = box.querySelector("#nr-agg").value;
    slots.evaluation_kind = box.querySelector("#nr-method").value;
    slots.fallback = box.querySelector("#nr-fallback").value;
    const _dts = await _ensureScopeContext();
    if (_dts.length) slots.applicable_types = _dts;
    const r = await (await fetch("/api/v1/rules/plan-preview", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:box.querySelector("#nr-name").value, category:cat.value, rclass:box.querySelector("#nr-rclass").value, slots})})).json();
    const out = box.querySelector("#nr-plan-out");
    const _planLabels = { evidence_scope: "证据范围", aggregation: "汇总方式", evaluation_kind: "判定方式", fallback: "证据不足处理" };
    const _pv = (r.plan || {});
    const _lines = Object.entries(_planLabels).map(([k, lb]) => {
      let v = _pv[k];
      if (Array.isArray(v)) v = v.join("/");
      return `${lb}：${v || "未配置"}`;
    });
    out.textContent = r.plan
      ? (_lines.join(" · ") + (_pv.label ? `\n${_pv.label}` : "") + (_pv.warnings?.length ? "\n注意：" + _pv.warnings.join("；") : ""))
      : (r.error || "预览失败");
    if (!r.plan?.supported) out.style.color = "#B45309"; else out.style.color = "";
  });
  box.querySelector("#nr-manual-save").addEventListener("click", async () => {
    // T-83（D-L2-01）：提交中忽略后续点击。
    // 【C3 修复 2026-11-19】锁必须在**任何 await 之前**置位：原实现把 _nrSaving=true 放在
    // `await _ensureScopeContext()` 之后，同一 JS tick 的第二次 click 会先越过守卫再一起
    // 走到 await，结果两个请求都发出去（E2E L2-208 实测 name 同名产生 2 条规则）。
    // 现在改为进入即置位，并用 _releaseSave() 在每条早退路径复位，避免按钮永久禁用。
    if (_nrSaving) return;
    _nrSaving = true;
    const _releaseSave = () => {
      _nrSaving = false;
      if (_saveBtn) { _saveBtn.disabled = false; _saveBtn.textContent = _kindValue() === "decision" ? "打开决策表编辑器" : "保存为草稿"; }
    };
    if (_kindValue() === "decision") {
      _releaseSave();
      const _dm = box.querySelector("#nr-msg2");
      if (_dm) _dm.textContent = "决策表组合请在决策表编辑器中定义并保存；单条表单不会把组合条件误存成单条规则。";
      try { openDecisionCreate(); } catch (e) { showToast && showToast("决策表编辑器加载失败", "err"); }
      return;
    }
    const name = box.querySelector("#nr-name").value.trim();
    const criterion = box.querySelector("#nr-criterion").value.trim();
    if (!name) { alert("请填写规则名称"); _releaseSave(); return; }
    if (!criterion) { alert("请填写判据"); _releaseSave(); return; }
    const slots = { _template: cat.value, _executor: "rule", criterion };
    box.querySelectorAll("#nr-slots [data-slot]").forEach(el => { slots[el.dataset.slot] = (el.value || "").trim(); });
    slots.evidence_scope = [...box.querySelectorAll("[data-ev]:checked")].map(x => x.dataset.ev);
    slots.aggregation = box.querySelector("#nr-agg").value;
    slots.evaluation_kind = box.querySelector("#nr-method").value;
    slots.fallback = box.querySelector("#nr-fallback").value;
    const _docTypes = await _ensureScopeContext();
    if (_docTypes.length) slots.applicable_types = _docTypes;
    // 标签：chip 多标签输入 → 提交仍为数组（后端 scope.tags 契约不变）
    let _tags = [];
    try { _tags = JSON.parse(box.querySelector("#nr-tags")?.value || "[]"); } catch (e) { _tags = []; }
    if (!Array.isArray(_tags)) _tags = [];
    const _pointMode = (box.querySelector('input[name="nr-point-mode"]:checked') || {}).value || "auto";
    const _pointId = _pointMode === "manual" ? (box.querySelector("#nr-point")?.value || "") : "";
    // scope.form 显式落库（与规则详情/冲突快照同一字段）：选择单条数据裁决保存，就不让详情按文本猜成决策表。
    const scope = { tags: _tags,
      evidence: box.querySelector("#nr-evidence").value.trim(), source: "manual",
      description: box.querySelector("#nr-desc").value.trim(),
      positive_example: box.querySelector("#nr-pos").value.trim(), negative_example: box.querySelector("#nr-neg").value.trim(),
      form: "single", form_reason: "新建规则表单选择「单条数据裁决」，按单条参数规则保存" };
    if (_docTypes.length) scope.applicable_types = _docTypes;
    // 发布门禁口径：适用文档类型来自空间配置，不是用户输入；空间已配置时已在上方自动写入
    // slots/scope().applicable_types，manifest 的 scope_route 因此 declared=true，不再因“表单没填”报 scope_missing。
    const body = { name, category: cat.value, rclass: box.querySelector("#nr-rclass").value, slots, scope,
      point_id: _pointId, source: "manual" };
    const msg = box.querySelector("#nr-msg2");
    // T-83（D-L2-01）：single-flight——提交期间禁用按钮并显示“保存中…”，
    // 同一 JS tick 的第二次 click 被 _nrSaving 拦截且 disabled 按钮不派发 click；
    // 请求结束（成功/失败）在 finally 复位，不影响后续正常保存（产品允许同名草稿）。
    // 锁已在入口置位（C3 修复），这里只更新按钮文案
    if (_saveBtn) { _saveBtn.disabled = true; _saveBtn.textContent = "保存中…"; }
    msg.textContent = "保存中…";
    let r = {};
    try {
      r = await (await fetch("/api/v1/rules/custom", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    } catch (e) {
      msg.textContent = "保存失败，请稍后重试";
      return;
    } finally {
      _nrSaving = false;
      if (_saveBtn) { _saveBtn.disabled = false; _saveBtn.textContent = _kindValue() === "decision" ? "打开决策表编辑器" : "保存为草稿"; }
    }
    const _af = apiFail(r);
    if (_af) { msg.textContent = _af; return; }
    const m = r.mapping || {};
    const _cfN = (r.conflicts || []).length;
    msg.textContent = (m.mapped ? ("已保存草稿；映射点位 " + (m.point_id || "") + " " + (m.point_name || "") + "。到「规则草稿箱」点「发布生效」后才会参与审核（无需审批）。") : (m.override ? "已保存草稿；未绑定正式点位（未绑定自定义规则）。到「规则草稿箱」发布生效（无需审批）。" : "已保存草稿；未映射平台点位，仅按自定义规则执行。到「规则草稿箱」发布生效（无需审批）。")) + (_cfN ? ` 发现 ${_cfN} 条疑似规则冲突，发布后会提醒并跳转「冲突提醒」。` : "");
    if (_cfN) showToast(`已保存草稿；发布后会提示 ${_cfN} 条疑似冲突（不阻断发布）`, "err"); else showToast("规则草稿已保存，请到「规则草稿箱」发布生效（无需审批）");
    if (typeof uxDirtyClear === "function") uxDirtyClear("newrule");
    loadRecentRules(); loadRules();
  });
}

/* 标签 chip 多标签输入：Enter / 逗号添加、点 × 或 Backspace 删除、自动去重；提交仍为数组。 */
function initTagChips(box) {
  const wrap = box.querySelector("#nr-tags-wrap");
  const chipsEl = box.querySelector("#nr-tags-chips");
  const inp = box.querySelector("#nr-tags-input");
  const hidden = box.querySelector("#nr-tags");
  if (!wrap || !chipsEl || !inp || !hidden) return { get: () => [] };
  const MAX_TAGS = 20;
  let tags = [];
  const sync = () => {
    hidden.value = JSON.stringify(tags);
    chipsEl.innerHTML = tags.map((t, i) =>
      `<span class="nr-tag">${esc(t)}<button type="button" class="nr-tag-x" data-tag-rm="${i}" aria-label="删除标签 ${esc(t)}" title="删除标签">×</button></span>`).join("");
    wrap.classList.toggle("has-tags", tags.length > 0);
  };
  const add = (raw) => {
    String(raw || "").split(/[,，、;；\n]/).forEach((part) => {
      const t = part.trim();
      if (!t || tags.includes(t)) return;
      if (tags.length >= MAX_TAGS) { showToast && showToast(`标签最多 ${MAX_TAGS} 个`, "err"); return; }
      tags.push(t);
    });
    sync();
  };
  const removeAt = (i) => { if (i >= 0 && i < tags.length) { tags.splice(i, 1); sync(); } };
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === "," || e.key === "，") {
      if (e.key !== "Enter" || inp.value.trim()) {
        e.preventDefault();
        add(inp.value);
        inp.value = "";
      }
    } else if (e.key === "Backspace" && !inp.value && tags.length) {
      e.preventDefault();
      removeAt(tags.length - 1);
    }
  });
  inp.addEventListener("input", () => {
    if (/[,，]/.test(inp.value)) { add(inp.value); inp.value = ""; }
  });
  inp.addEventListener("blur", () => { if (inp.value.trim()) { add(inp.value); inp.value = ""; } });
  chipsEl.addEventListener("click", (e) => {
    const btn = e.target.closest && e.target.closest("[data-tag-rm]");
    if (btn) { e.preventDefault(); removeAt(Number(btn.dataset.tagRm)); }
  });
  sync();
  return { get: () => tags.slice() };
}

/* 平台点位映射：自动映射（推荐）+ 三级级联 A–G 大类 → 审核类型 → 点位 + 搜索兜底 + 其他/未收录。
 * “其他/未收录”只在前端给提示与入口（保存为未绑定自定义规则；候选点位需业务管理员后续创建），
 * 不调用不存在的 API、不自动生成正式点位。数据只来自现有只读接口。 */
async function initRulePointPicker(box) {
  const manual = box.querySelector("#nr-point-manual");
  const catSel = box.querySelector("#nr-point-cat");
  const typeSel = box.querySelector("#nr-point-type");
  const pointSel = box.querySelector("#nr-point");
  const modeRadios = Array.from(box.querySelectorAll('input[name="nr-point-mode"]'));
  const modeCards = Array.from(box.querySelectorAll(".nr-point-mode-card"));
  const search = box.querySelector("#nr-point-search");
  const results = box.querySelector("#nr-point-results");
  const note = box.querySelector("#nr-point-note");
  const other = box.querySelector("#nr-point-other");
  const unbindBtn = box.querySelector("#nr-point-unbind");
  const otherCancel = box.querySelector("#nr-point-other-cancel");
  const countEl = box.querySelector("#nr-point-count");
  if (!manual || !catSel || !typeSel || !pointSel || !modeRadios.length) return;

  const modeValue = () => ((modeRadios.find((r) => r.checked) || {}).value) || "auto";
  const hideResults = () => { if (results) { results.hidden = true; results.innerHTML = ""; } };
  const hideOther = () => { if (other) other.hidden = true; };
  const showOther = () => { if (other) other.hidden = false; };
  const setMode = (mode) => {
    modeRadios.forEach((r) => { r.checked = r.value === mode; });
    modeCards.forEach((card) => card.classList.toggle("on", ((card.querySelector("input") || {}).value || "") === mode));
    manual.hidden = mode !== "manual";
    if (mode !== "manual") { hideResults(); hideOther(); }
  };

  let all = [];
  let platformStats = null;
  const groups = new Map(); // catId -> Map(typeId -> {id,name,points:[]})
  const pointTypes = (cid) => Array.from((groups.get(cid) || new Map()).values());
  const allTypeIds = () => new Set(all.map((p) => p.type_id || "").filter(Boolean));
  const catNameOf = (cid) => ((AUDIT_RANGES.find((r) => r[0] === cid) || [])[1] || cid);

  const updateNote = () => {
    const typeCount = allTypeIds().size;
    if (countEl) countEl.textContent = all.length ? `当前空间可用点位 ${all.length} 个 / 审核类型 ${typeCount} 类` : "";
    if (!note) return;
    if (!all.length) {
      note.textContent = "当前空间暂未匹配到可用的平台点位。可保存为未绑定自定义规则；候选点位需业务管理员后续创建（在平台点位库操作；本页不自动生成正式点位）。";
      showOther();
      return;
    }
    const cid = catSel.value || "A";
    const tid = typeSel.value || "";
    const suffix = platformStats && Number(platformStats.audit_types)
      ? `；平台审核库共 ${platformStats.audit_types} 类审核类型 / ${platformStats.total} 个点位`
      : "";
    note.textContent = `已按「${cid} ${catNameOf(cid)} → ${tid ? tid + " " : ""}审核类型 → 点位」筛选；当前空间可用 ${all.length} 个点位、${typeCount} 类审核类型${suffix}。默认自动映射，手工指定仅用于需要明确绑定。`;
  };

  const fillPoints = () => {
    const cid = catSel.value, tid = typeSel.value;
    const t = pointTypes(cid).find((x) => x.id === tid);
    const pts = t ? t.points : [];
    const cur = pointSel.value;
    pointSel.innerHTML = '<option value="">请选择点位（留空 = 不手工绑定）</option>' +
      pts.map((p) => `<option value="${esc(p.id)}">${esc(p.code || p.id)} · ${esc(p.name)}</option>`).join("");
    if (pts.some((p) => p.id === cur)) pointSel.value = cur;
    if (modeValue() === "manual" && !pts.length) showOther();
    updateNote();
  };
  const fillTypes = () => {
    const cid = catSel.value;
    const cur = typeSel.value;
    const types = pointTypes(cid);
    typeSel.innerHTML = types.length
      ? types.map((t) => `<option value="${esc(t.id)}">${esc(t.id)} · ${esc(t.name)}（${t.points.length} 个点位）</option>`).join("")
      : '<option value="">（该大类当前空间无可用审核类型）</option>';
    if (types.some((t) => t.id === cur)) typeSel.value = cur;
    fillPoints();
  };
  const fillCats = () => {
    const cur = catSel.value;
    catSel.innerHTML = AUDIT_RANGES.map(([id, name]) => {
      const n = pointTypes(id).length;
      return `<option value="${id}">${id} · ${esc(name)}${n ? `（${n} 类）` : "（当前空间无可用点位）"}</option>`;
    }).join("");
    const prefer = AUDIT_RANGES.map((r) => r[0]).find((id) => pointTypes(id).length) || "A";
    catSel.value = AUDIT_RANGES.some((r) => r[0] === cur) ? cur : prefer;
    fillTypes();
  };
  const renderResults = (q) => {
    if (!results) return;
    const kw = String(q || "").trim().toLowerCase();
    if (!kw) { hideResults(); hideOther(); return; }
    const list = all.filter((p) =>
      [p.code, p.id, p.name, p.type_id, p.type_name, p.category, p.__cat]
        .join(" ").toLowerCase().includes(kw)).slice(0, 40);
    if (!list.length) {
      results.hidden = false;
      results.innerHTML = `<div class="nr-point-empty">没有匹配「${esc(q)}」的可用点位。</div>`;
      showOther();
      return;
    }
    results.hidden = false;
    results.innerHTML = `<div class="nr-point-results-head">搜索结果 ${list.length} 个（点击选择）</div>` +
      list.map((p) => `<button type="button" class="nr-point-result" data-point-pick="${esc(p.id || p.code)}"><b>${esc(p.code || p.id)}</b><span>${esc(p.name)}</span><small>${esc(p.__cat)} 类 · ${esc(p.type_id)} ${esc(p.type_name || "")}</small></button>`).join("");
    hideOther();
  };

  modeRadios.forEach((r) => r.addEventListener("change", () => { setMode(modeValue()); updateNote(); }));
  catSel.addEventListener("change", fillTypes);
  typeSel.addEventListener("change", fillPoints);
  pointSel.addEventListener("change", () => { if (pointSel.value) setMode("manual"); });
  if (search) search.addEventListener("input", () => renderResults(search.value));
  if (results) results.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest("[data-point-pick]");
    if (!b) return;
    const pid = b.dataset.pointPick;
    const p = all.find((x) => String(x.id) === pid) || all.find((x) => String(x.code) === pid);
    if (!p) return;
    setMode("manual");
    catSel.value = p.__cat;
    fillTypes();
    typeSel.value = p.type_id || typeSel.value;
    fillPoints();
    pointSel.value = p.id;
    hideResults();
    hideOther();
    if (search) search.value = "";
    if (note) note.textContent = `已手工指定点位：${p.code || p.id} · ${p.name}（${p.__cat} ${catNameOf(p.__cat)} → ${p.type_id || ""} ${p.type_name || ""}）。`;
  });
  if (unbindBtn) unbindBtn.addEventListener("click", () => {
    if (pointSel) pointSel.value = "";
    if (search) search.value = "";
    hideResults();
    hideOther();
    setMode("auto");
    if (note) note.textContent = "已选择「其他 / 未收录 → 未绑定自定义规则」：点位列留空、不提交手工点位绑定；保存时系统仍会优先自动匹配，未匹配到平台点位则按未绑定自定义规则执行。候选点位需业务管理员后续在平台点位库创建，本页不自动生成正式点位。";
    if (typeof uxDirtyReset === "function") uxDirtyReset("newrule");
  });
  if (otherCancel) otherCancel.addEventListener("click", () => { hideOther(); if (search) { search.value = ""; search.focus(); } });

  try {
    const [od, cj, st] = await Promise.all([
      fetch("/api/v1/audit-points/options").then((r) => r.json()).catch(() => ({})),
      fetch("/api/v1/audit-categories").then((r) => r.json()).catch(() => []),
      fetch("/api/v1/audit-points").then((r) => r.json()).catch(() => null),
    ]);
    platformStats = (st && typeof st === "object" && !st.error) ? st : null;
    const nameToId = new Map();
    (Array.isArray(cj) ? cj : []).forEach((c) => { if (c && c.id && c.name) nameToId.set(String(c.name), String(c.id)); });
    AUDIT_RANGES.forEach(([id, name]) => { if (!nameToId.has(name)) nameToId.set(name, id); });
    all = (((od && od.items) || [])).filter((p) => p && (p.id || p.code)).map((p) => {
      const byName = nameToId.get(String(p.category || ""));
      const prefix = String(p.type_id || p.code || "").charAt(0).toUpperCase();
      const cid = byName || (/[A-G]/.test(prefix) ? prefix : "A");
      return Object.assign({}, p, { __cat: cid });
    });
    // 审核类型按 type_id 归并到唯一大类：补充层存在同一 type_id 的点位 category 名混用（如 FOOD05），
    // 以多数派为准，避免同一审核类型在级联里重复出现、类目计数虚高。
    const typeCatVotes = new Map();
    all.forEach((p) => {
      const tid = p.type_id || "UNKNOWN";
      if (!typeCatVotes.has(tid)) typeCatVotes.set(tid, new Map());
      const votes = typeCatVotes.get(tid);
      votes.set(p.__cat, (votes.get(p.__cat) || 0) + 1);
    });
    const typeCatFinal = new Map();
    typeCatVotes.forEach((votes, tid) => {
      let bestCat = "", bestN = -1;
      votes.forEach((n, cid) => { if (n > bestN) { bestN = n; bestCat = cid; } });
      typeCatFinal.set(tid, bestCat);
    });
    all.forEach((p) => {
      const tid = p.type_id || "UNKNOWN";
      p.__cat = typeCatFinal.get(tid) || p.__cat;
      if (!groups.has(p.__cat)) groups.set(p.__cat, new Map());
      const tm = groups.get(p.__cat);
      if (!tm.has(tid)) tm.set(tid, { id: tid, name: p.type_name || tid, points: [] });
      tm.get(tid).points.push(p);
    });
    fillCats();
    updateNote();
    if (!all.length) showOther();
  } catch (e) {
    if (note) note.textContent = "点位列表加载失败；可留空使用自动映射（未绑定自定义规则）；候选点位需业务管理员后续创建。";
    showOther();
  }
}

async function loadRuleSpaceContext() {
  try {
    const r = await (await fetch("/api/v1/workspaces")).json();
    const cur = (r && r.current) || {};
    const _types = Array.isArray(cur.doc_types) ? cur.doc_types.filter(Boolean) : (window.__wsDocTypes || []);
    // 只读缓存：新建规则表单保存/预览时自动写入，不再读取任何用户输入。
    window.__nrScope = { id: cur.id || "", name: cur.name || "通用空间", docTypes: _types.slice() };
    const el = document.querySelector("#nr-space-label");
    if (el) el.textContent = "当前工作空间：" + (cur.name || "通用空间") + "（规则自动适用本空间全部文件类型，无需填写）";
    const sw = document.querySelector("#nr-scope-ws"); if (sw) sw.textContent = cur.name || "通用空间";
    const sd = document.querySelector("#nr-scope-docs");
    if (sd) {
      sd.textContent = _types.length
        ? `自动适用 ${_types.length} 类：${_types.join("、")}（本空间全部文件类型，无需填写）`
        : "未限定（以当前空间实际配置为准）；新规则自动适用本空间全部文件类型，无需填写";
    }
  } catch (e) {
    window.__nrScope = window.__nrScope || { name: "通用空间", docTypes: [] };
    const el = document.querySelector("#nr-space-label");
    if (el) el.textContent = "当前工作空间：—（读取失败，保存时将按实际空间配置处理）";
    const sd = document.querySelector("#nr-scope-docs");
    if (sd) sd.textContent = "未限定（空间配置读取失败，以实际空间配置为准）";
  }
}
async function loadNewDecisionList() {
  const box = document.querySelector("#nr-decision-list"); if (!box) return;
  box.innerHTML = '<div class="muted" style="padding:10px 0">加载决策表…</div>';
  try {
    const d = await (await fetch("/api/v1/decision-tables")).json();
    const items = d.items || [];
    box.innerHTML = items.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>序号</th><th>编码</th><th>名称</th><th>行数</th><th>状态</th><th>版本</th><th style="width:120px">操作</th></tr></thead><tbody>` +
      items.map((t, i) => `<tr><td class="muted">${i + 1}</td><td>${esc(t.code)}</td><td><b>${esc(t.name)}</b></td><td>${t.rows || 0}</td><td><span class="pill ${t.status === "published" ? "published" : "draft"}">${t.status === "published" ? "已发布" : "草稿"}</span></td><td class="muted">${esc(t.version || "—")}</td><td><button class="btn" data-nr-dt-edit="${esc(t.code)}">${t.status === "published" ? "查看" : "编辑"}</button></td></tr>`).join("") + `</tbody></table></div>`
      : `<div class="empty" style="padding:24px 0">当前空间还没有决策表；新建后发布才会进入审核主链。</div>`;
    box.querySelectorAll("[data-nr-dt-edit]").forEach(b => b.onclick = () => {
      const t = items.find(x => x.code === b.dataset.nrDtEdit) || {};
      if (t.status === "published") openDecisionDetail(b.dataset.nrDtEdit); else openDecisionEdit(b.dataset.nrDtEdit);
    });
  } catch (e) { box.innerHTML = `<div class="empty">决策表读取失败：${esc(e.message)}</div>`; }
}

async function loadRuleLinkage() {
  const d = await (await fetch("/api/v1/rules/linkage")).json();
  const box = $("#rule-linkage");
  if (!box) return;
  const items = d.items || [];
  box.innerHTML = `<div class="muted" style="margin-bottom:8px">共 ${d.total} 条 · 已接入 ${d.linked} 条 · 覆盖率 ${Math.round((d.coverage || 0) * 100)}%</div>` +
    `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>规则</th><th>编码</th><th>点位</th><th>本体</th><th>Jev</th><th>反馈</th><th>冲突</th>
    </tr></thead><tbody>` +
    items.map((x, i) => `<tr>
      <td class="muted">${items.length - i}</td>
      <td>${esc(x.name)}</td>
      <td class="muted">${esc(x.code)}</td>
      <td>${x.points.length ? x.points.map(p => `<span class="pill r">${esc(p)}</span>`).join(" ") : '<span class="muted">—</span>'}</td>
      <td>${esc(x.ontology)}</td>
      <td>${esc(x.jev)}</td>
      <td>${x.feedback ? x.feedback + `（误报 ${x.false_positive}）` : "—"}</td>
      <td>${x.conflicts || "—"}</td>
    </tr>`).join("") + `</tbody></table>`;
}

/* ===================== 新建规则：上传文件拆解 ===================== */
/* ===================== 冲突详情与裁决（T-63） =====================
 * 用户反馈：冲突裁决页太简陋，应与规则库详情一致；用户确认口径：
 * - 裁决权：业务管理员=本租户/本空间全部；审核员=本人项目/本人规则/本人反馈相关；
 *   系统管理员/平台运营只读，不可裁决（服务端强制，前端只做展示）。
 * - 6 条裁决路径：规则 A 正确 / 规则 B 正确 / 两者都不对 / 两者都对 / 证据不足 / 忽略。
 * - 「两者都不对」= 两条规则都按现有生命周期下线（archived，保留版本/审计，不物理删除），
 *   展示影响面（项目/点位/引用）二次确认后提交，并生成「重新新建规则」入口（预填冲突上下文，
 *   新规则必须重新草稿→发布生效（无需审批），不自动发布）。
 * - 裁决必须先选结果再填原因；支持返回/取消/未保存离开确认；详情展示 A/B 六组完整字段与差异。
 */
const CFR_TYPE = { numeric_conflict: "限值矛盾", duplicate: "重复规则", unit_mismatch: "单位不一致", scope_conflict: "作用域重叠", priority_conflict: "优先级冲突" };
const CFR_SEV = { critical: "严重", warning: "一般", info: "提示" };
const CFR_ST = { open: "待处理", resolved: "已裁决", ignored: "已忽略" };
const CFR_RES_LABEL = {
  rule_a: "规则 A 正确", rule_b: "规则 B 正确", both_wrong: "两者都不对",
  both_valid: "两者都对", need_more: "证据不足", ignored: "忽略",
};
const CFR_RES_DESC = {
  rule_a: "确认 A 的判据正确；B 需另行修订/下线，本次不自动改动 B。",
  rule_b: "确认 B 的判据正确；A 需另行修订/下线，本次不自动改动 A。",
  both_wrong: "两条规则都错误：按现有生命周期下线两条规则（保留版本/审计，不物理删除），并生成重新新建规则入口。",
  both_valid: "两条规则可同时成立（作用域/期间不同等），关闭冲突但不改规则状态。",
  need_more: "证据/制度依据不足：冲突保持待处理，可补充依据后再次裁决。",
  ignored: "确认该冲突无需处理（误报/重复检测）：保留原因并关闭冲突，规则状态不变。",
};
const CFR_RES_ACTION = { rule_a: "resolved", rule_b: "resolved", both_wrong: "resolved", both_valid: "resolved", need_more: "open", ignored: "ignored" };

function cfrEnsureStyle() {
  if (document.getElementById("cfr-style")) return;
  const st = document.createElement("style");
  st.id = "cfr-style";
  st.textContent = `
  .cfr-detail{width:min(1040px,calc(100vw - 32px));max-height:92vh;overflow:auto;padding:20px 24px}
  .cfr-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
  .cfr-head h3{margin:0;font-size:18px}
  .cfr-sub{font-size:12px;color:#8F959E;margin-top:4px;line-height:1.6}
  .cfr-pills{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 8px}
  .cfr-banner{border-radius:8px;padding:9px 12px;font-size:12px;line-height:1.7;margin:10px 0}
  .cfr-banner.info{background:#F2F6FF;border:1px solid #D6E4FF;color:#1D4ED8}
  .cfr-banner.warn{background:#FFF8E6;border:1px solid #FCE3A2;color:#A15C00}
  .cfr-banner.ok{background:#F2FBF4;border:1px solid #C6EBCF;color:#0F7B33}
  .cfr-banner.err{background:#FFF3F3;border:1px solid #FFD2D2;color:#C62828}
  .cfr-section{margin-top:16px;border-top:1px solid #F0F1F2;padding-top:14px}
  .cfr-section h4{margin:0 0 8px;font-size:14px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
  .cfr-section h4 .muted{font-weight:400}
  .cfr-cards{display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:start}
  .cfr-card{border:1px solid #EBEDF0;border-radius:9px;padding:12px;background:#fff;min-width:0}
  .cfr-card.missing{border-style:dashed;color:#8F959E;font-size:12px;line-height:1.7}
  .cfr-card-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;flex-wrap:wrap}
  .cfr-card-head b{font-size:13px}
  .cfr-group{border-top:1px dashed #F0F1F2;padding-top:8px;margin-top:8px}
  .cfr-group:first-of-type{border-top:none;padding-top:0;margin-top:0}
  .cfr-group-h{font-size:12px;font-weight:600;color:#1F2329;margin-bottom:6px}
  .cfr-kv{display:grid;grid-template-columns:1fr;gap:3px}
  .cfr-kv-item{display:grid;grid-template-columns:104px 1fr;gap:8px;font-size:12px;line-height:1.65}
  .cfr-k{color:#8F959E;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .cfr-v{color:#1F2329;word-break:break-word}
  .cfr-v.cfr-empty{color:#B7BDC6}
  .cfr-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
  .cfr-chip{font-size:11px;background:#F5F6F7;border:1px solid #EBEDF0;border-radius:10px;padding:1px 7px;color:#4E5969}
  .cfr-diff{width:100%;border-collapse:collapse;font-size:12px}
  .cfr-diff th,.cfr-diff td{border:1px solid #EEF0F2;padding:6px 8px;text-align:left;vertical-align:top}
  .cfr-diff th{background:#FAFBFC;color:#4E5969;font-weight:500}
  .cfr-diff tr.diff td{background:#FFFDF5}
  .cfr-diff .same{color:#8F959E}
  .cfr-ver{font-size:11px;color:#4E5969;margin-top:6px;line-height:1.8}
  .cfr-ver .pill{margin-right:4px}
  .cfr-impact{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .cfr-impact-box{border:1px solid #EBEDF0;border-radius:8px;padding:9px 11px;font-size:12px;line-height:1.75}
  .cfr-impact-box b{font-size:12px}
  .cfr-impact-box ul{margin:5px 0 0;padding-left:17px;color:#4E5969}
  .cfr-hist{font-size:12px}
  .cfr-hist-item{display:grid;grid-template-columns:150px 1fr;gap:10px;padding:6px 0;border-bottom:1px dashed #F2F3F5}
  .cfr-hist-item:last-child{border-bottom:none}
  .cfr-hist-item .t{color:#8F959E}
  .cfr-rel{font-size:12px}
  .cfr-rel-item{padding:6px 0;border-bottom:1px dashed #F2F3F5}
  .cfr-rel-item:last-child{border-bottom:none}
  .cfr-actions{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;margin-top:18px;position:sticky;bottom:-20px;background:#fff;padding:12px 0 2px;border-top:1px solid #F0F1F2}
  .cfr-opts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:8px 0 4px}
  .cfr-opt{display:block;border:1px solid #E5E6EB;border-radius:9px;padding:10px 12px;cursor:pointer;background:#fff;transition:border-color .15s,box-shadow .15s;min-width:0}
  .cfr-opt:hover{border-color:#B9C6FF}
  .cfr-opt.on{border-color:#3B6DF6;box-shadow:0 0 0 2px rgba(59,109,246,.12);background:#F7F9FF}
  .cfr-opt input{margin-right:6px}
  .cfr-opt b{font-size:13px;color:#1F2329}
  .cfr-opt p{margin:4px 0 0;font-size:11px;line-height:1.6;color:#8F959E}
  .cfr-opt .pill{margin-left:4px}
  .cfr-step{font-size:12px;color:#4E5969;margin:12px 0 6px;font-weight:600}
  .cfr-step em{font-style:normal;color:#D83931;font-size:11px;margin-left:4px}
  .cfr-field-label{display:block;font-size:12px;color:#1F2329;margin:8px 0 4px;font-weight:500}
  .cfr-req{color:#D83931;font-size:11px;margin-left:4px}
  .cfr-imp-confirm{border:1px solid #FCE3A2;background:#FFF8E6;border-radius:8px;padding:10px 12px;margin-top:8px;font-size:12px;line-height:1.75}
  .cfr-imp-confirm label{display:flex;gap:8px;align-items:flex-start;font-weight:600;color:#A15C00;cursor:pointer}
  .cfr-imp-list{margin:8px 0 0;padding-left:18px;color:#4E5969}
  .cfr-code{font-family:ui-monospace,Menlo,monospace;font-size:11px;background:#F5F6F7;border-radius:4px;padding:1px 5px;color:#4E5969}
  .cfr-prefill{background:#F7F8FA;border:1px solid #EEF0F2;border-radius:8px;padding:10px 12px;font-size:12px;line-height:1.8;margin-top:8px}
  .cfr-recreate-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
  @media(max-width:820px){.cfr-cards,.cfr-opts,.cfr-impact{grid-template-columns:1fr}.cfr-kv-item{grid-template-columns:92px 1fr}}
  `;
  document.head.appendChild(st);
}

function cfrApi(path, opts) {
  return fetch(path, opts).then(async r => {
    let d = {};
    try { d = await r.json(); } catch (e) { d = {}; }
    return { ok: r.ok, status: r.status, data: d || {} };
  }).catch(e => ({ ok: false, status: 0, data: { error: "网络错误：" + ((e && e.message) || e) } }));
}
function cfrRemove(id) { const el = document.querySelector("#" + id); if (el) el.remove(); }
function cfrPill(label, cls) { return `<span class="pill ${cls || ""}">${esc(label)}</span>`; }
/* T-108：状态/严重度/历史裁决 label 优先消费后端 T-107 返回（status_label/severity_label/
   resolution_label/resolution_display），前端映射只做兜底；不再出现英文 approved/superseded/空裁决。 */
function cfrSeverity(cls, v, label) {
  return cfrPill(label || CFR_SEV[v] || v || "提示", v === "critical" ? "draft" : v === "warning" ? "r" : "");
}
function cfrStatus(v, label) {
  return cfrPill(label || CFR_ST[v] || v || "待处理", v === "open" ? "r" : v === "ignored" ? "draft" : "published");
}
function cfrResolution(v) { return v ? cfrPill(CFR_RES_LABEL[v] || v, "published") : ""; }
/* 历史冲突（旧库）resolution 为空但 status=resolved/ignored：用后端 resolution_display
   “历史裁决（未记录路径）”展示，不显示“—”，也不伪造具体裁决路径。 */
function cfrResolutionText(x) {
  if (!x) return "";
  const res = String(x.resolution || "");
  if (res) return x.resolution_label || CFR_RES_LABEL[res] || res;
  const disp = String(x.resolution_display || "").trim();
  return disp && disp !== "—" ? disp : "";
}
function cfrResolutionCell(x) {
  const t = cfrResolutionText(x);
  if (!t) return '<span class="muted">—</span>';
  return cfrPill(t, String((x || {}).resolution || "") ? "published" : "draft");
}

/* ---------- A/B 规则完整快照（六组字段，与规则库详情同源） ---------- */
function cfrRuleSnapshotHtml(snap, side) {
  const label = side === "a" ? "规则 A" : "规则 B";
  if (!snap || !snap.found) {
    const _why = String((snap && snap.reason) || "").trim();
    return `<div class="cfr-card missing"><b>${label} · ${esc((snap && snap.code) || "—")}</b>
      <div style="margin-top:6px">规则不存在或已不在当前范围${_why ? "（" + esc(_why) + "）" : "（可能为旧数据/决策表行冲突）"}。冲突记录仍保留，未物理删除任何数据。</div></div>`;
  }
  const flat = snap.flat || {};
  const groups = (snap.groups || []).map(g => {
    const kv = (g.fields || []).map(f => `<div class="cfr-kv-item"><span class="cfr-k" title="${esc(f.label)}">${esc(f.label)}</span><span class="cfr-v ${f.empty ? "cfr-empty" : ""}">${esc(f.empty ? "未填写 / 未配置" : f.value)}</span></div>`).join("");
    let extra = "";
    if (g.key === "execution_plan" && (g.slots || []).length) {
      extra += `<div class="cfr-chips">${g.slots.slice(0, 16).map(s => `<span class="cfr-chip"><b>${esc(s.key)}</b> ${esc(s.value)}</span>`).join("")}</div>`;
    }
    if (g.key === "lifecycle" && (g.versions || []).length) {
      extra += `<div class="cfr-ver">` + g.versions.map(v =>
        `<div>${cfrPill(v.status === "published" ? "生效" : v.status === "superseded" ? "已被替代" : (v.status || "—"), v.status === "published" ? "published" : "draft")} ${esc(v.version || "—")}${v.published_at ? " · 发布 " + esc(String(v.published_at).slice(0, 16)) : ""}${v.approved_by ? " · 批准 " + esc(v.approved_by) : ""}${v.superseded_at ? " · 替代 " + esc(String(v.superseded_at).slice(0, 16)) : ""}</div>`).join("") + `</div>`;
    }
    if (g.key === "usage") {
      extra += `<div class="cfr-chips"><span class="cfr-chip">命中 ${esc(String(flat.hit_count || 0))}</span><span class="cfr-chip">override ${esc(String(flat.override_count || 0))}</span><span class="cfr-chip">反馈 ${esc(String(flat.feedback_count || 0))}</span><span class="cfr-chip">版本 ${esc(String((snap.versions || []).length || 0))}</span></div>`;
    }
    return `<div class="cfr-group"><div class="cfr-group-h">${esc(g.label)}</div><div class="cfr-kv">${kv}</div>${extra}</div>`;
  }).join("");
  return `<div class="cfr-card"><div class="cfr-card-head"><b>${label} · ${esc(flat.code || snap.code || "—")}</b>
      <span>${cfrStatus(flat.status, flat.status_label)} ${cfrPill(flat.status_label || flat.status || "—")}</span></div>
    <div class="muted" style="font-size:11px;line-height:1.6;margin-bottom:6px">${esc(flat.name || "—")}${flat.owner ? " · 负责人 " + esc(flat.owner) : ""}</div>
    ${groups}</div>`;
}

function cfrDiffHtml(diffs) {
  const rows = (diffs || []).map(d => `<tr class="${d.diff ? "diff" : ""}"><td>${esc(d.label)}</td>
    <td>${esc(d.a || "—")}</td><td>${esc(d.b || "—")}</td>
    <td>${d.diff ? cfrPill("不同", "draft") : '<span class="same">相同</span>'}</td></tr>`).join("");
  if (!rows) return '<div class="muted">两条规则在阈值/比较符/单位/作用域/优先级/版本等关键字段上未发现差异记录。</div>';
  return `<table class="cfr-diff"><thead><tr><th style="width:110px">字段</th><th>规则 A</th><th>规则 B</th><th style="width:60px">对比</th></tr></thead><tbody>${rows}</tbody></table>`;
}

function cfrImpactHtml(impact) {
  const ip = impact || {};
  const projects = ip.projects || [];
  const points = ip.points || [];
  const findings = ip.findings || {};
  const fb = ip.feedback || {};
  const refs = ip.references || [];
  const prj = projects.length ? `<ul>${projects.map(p => `<li>${esc(p.name || p.case_id)}${p.status ? "（" + esc(PROJ_STATUS[p.status] || p.status) + "）" : ""} · 规则 ${esc((p.rule_codes || []).join("/") || "—")}</li>`).join("")}</ul>` : '<div class="muted">未命中任何项目</div>';
  const pts = points.length ? `<ul>${points.map(p => `<li>${esc(p.point_id)} ${esc(p.point_name || "")}${p.source ? " · " + esc(p.source) : ""}</li>`).join("")}</ul>` : '<div class="muted">未映射点位</div>';
  const fbs = (fb.sample || []).length ? `<ul>${fb.sample.map(x => `<li>${esc(x.kind)} · ${esc(x.rule_code)} · ${esc(x.title || x.id)}</li>`).join("")}</ul>` : '<div class="muted">无相关反馈</div>';
  const refHtml = refs.map(r => `<li>${r.side === "a" ? "A" : "B"} · ${esc(r.code || "—")}${r.found ? " · " + esc(r.status || "") + " · 版本 " + esc(r.version || "—") + " · 命中 " + esc(String(r.findings || 0)) : " · " + esc(r.reason || "未找到")}</li>`).join("");
  return `<div class="cfr-impact">
    <div class="cfr-impact-box"><b>项目（${esc(String(ip.project_count || 0))}${Number(ip.other_project_count || 0) > 0 ? "，另有 " + esc(String(ip.other_project_count)) + " 个其他项目不可见" : ""}）</b>${prj}</div>
    <div class="cfr-impact-box"><b>点位（${esc(String(ip.point_count || 0))}）</b>${pts}</div>
    <div class="cfr-impact-box"><b>命中问题（${esc(String(findings.total || 0))}）</b>
      <div class="cfr-chips">${Object.entries(findings.by_status || {}).map(([k, v]) => `<span class="cfr-chip">${esc(k)} ${esc(String(v))}</span>`).join("") || '<span class="muted">无命中记录</span>'}</div>
      <div class="muted" style="margin-top:6px">下线规则不删除历史命中，报告与复核记录保留。</div></div>
    <div class="cfr-impact-box"><b>引用（版本 ${refs.length} / 反馈 ${esc(String(fb.total || 0))}</b><ul>${refHtml}</ul>${fbs}</div>
  </div>`;
}

function cfrHistoryHtml(history) {
  const items = history || [];
  if (!items.length) return '<div class="muted">暂无裁决/下线历史（旧冲突可能没有审计记录）。</div>';
  return `<div class="cfr-hist">${items.map(h => `<div class="cfr-hist-item"><div class="t">${esc(String(h.at || "").slice(0, 16) || "—")} · ${esc(h.actor || "system")}</div>
    <div><b>${esc(h.label || h.action || "—")}</b>${h.detail ? `<div class="muted" style="word-break:break-all">${esc(h.detail)}</div>` : ""}</div></div>`).join("")}</div>`;
}

function cfrRelatedHtml(related) {
  const items = related || [];
  if (!items.length) return '<div class="muted">暂无共享规则的其他冲突。</div>';
  return `<div class="cfr-rel">${items.map(r => `<div class="cfr-rel-item">${cfrSeverity("", r.severity, r.severity_label)} ${cfrStatus(r.status, r.status_label)} ${cfrPill(r.type_label || r.type, "draft")} ${cfrResolutionCell(r)}
    <b>${esc(r.rule_a)}</b> vs <b>${esc(r.rule_b)}</b> · ${esc(String(r.created_at || "").slice(0, 16))}
    <div class="muted">${esc(r.detail || "")}</div></div>`).join("")}</div>`;
}

function cfrRecreateHtml(detail) {
  const rec = (detail && detail.recreate) || {};
  if (!rec.available) return "";
  const pre = rec.prefill || {};
  const ctx = pre.context || {};
  const linked = rec.linked_rule || {};
  const slots = pre.slots || {};
  const isLinked = !!rec.rule_id;
  const err = ctx.corrected_criterion || (pre.scope || {}).corrected_criterion || "";
  return `<div class="cfr-section" id="cfr-recreate-section"><h4>重新新建规则 <span class="muted">「两者都不对」的后续入口</span></h4>
    <div class="cfr-banner warn">两条规则已按生命周期下线（archived），<b>规则/版本/审计/命中记录全部保留，未物理删除</b>。新规则必须重新走 草稿 → 发布生效（<b>无需审批</b>），<b>不会自动发布</b>。</div>
    <div class="cfr-prefill"><b>预填冲突上下文</b>
      <div>规则名称：${esc(pre.name || "—")}</div>
      <div>判定模板：${esc(pre.category || "—")} · 风险等级：${esc(pre.rclass || "—")} · 来源：${esc(pre.source || "—")}</div>
      <div>指标/比较符/目标值：${esc(slots.metric || "—")} ${esc(slots.op || "未填")} ${esc(String(slots.value ?? ""))}${esc(slots.unit || "")}</div>
      <div>正确判据：${esc(err || "—")}</div>
      <div>适用范围：${esc((pre.scope || {}).description || "—")}</div>
      <div>标签：${esc(((pre.scope || {}).tags || []).join("、") || "—")}</div>
      <div>原规则：${esc((ctx.rule_a || "") + " vs " + (ctx.rule_b || ""))}</div>
    </div>
    <div class="cfr-recreate-actions">${isLinked
      ? `<span class="cfr-code">已关联重建规则 ${esc(linked.code || rec.rule_id)}（${esc(linked.status_label || linked.status || "—")}）</span>
         <button class="btn primary" data-cfr-gorule="${esc(rec.rule_id)}">去规则草稿箱发布生效</button>`
      : `<button class="btn primary" data-cfr-recreate>重新新建规则（生成草稿）</button>
         <button class="btn" data-cfr-repair>更新正确判据（重建失败时）</button>
         <span class="muted" style="font-size:11px">点击只生成草稿，不会自动发布；也可用「新建规则」手工创建后在这里关联。</span>`}</div>
    <div id="cfr-recreate-msg" class="muted" role="status" aria-live="polite" style="font-size:12px;margin-top:8px;min-height:18px"></div></div>`;
}

/* ---------- 冲突详情 ---------- */
async function openConflictDetail(cid) {
  cfrEnsureStyle();
  cfrRemove("conflict-decision-modal");
  const old = document.querySelector("#conflict-detail-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "conflict-detail-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal cfr-detail"><div class="cfr-head"><div><h3>冲突详情</h3>
      <div class="cfr-sub">正在读取冲突聚合详情（冲突头 / A、B 规则完整快照 / 差异 / 证据影响 / 裁决历史）…</div></div>
      <button class="ws-close" data-cfr-close aria-label="关闭">×</button></div>
    <div class="cfr-section" style="border-top:none;padding-top:8px"><div class="muted">加载中…</div></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-cfr-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  const r = await cfrApi(`/api/v1/conflicts/${encodeURIComponent(cid)}`);
  if (!r.ok) {
    const msg = (r.data && (r.data.error || r.data.message)) || ("读取失败（HTTP " + r.status + "）");
    mask.querySelector(".modal").innerHTML = `<div class="cfr-head"><div><h3>冲突详情</h3><div class="cfr-sub">只读详情（读取失败）</div></div><button class="ws-close" data-cfr-close>×</button></div>
      <div class="cfr-banner err" role="alert"><b>冲突详情读取失败</b>：${esc(msg)}
        <div class="muted" style="font-size:11px;margin-top:4px">冲突记录不受影响；可点「重试」重新读取，或返回列表稍后再试。</div></div>
      <div class="cfr-actions"><button class="btn" data-cfr-close>返回列表</button><button class="btn primary" data-cfr-retry>重试</button></div>`;
    mask.querySelectorAll("[data-cfr-close]").forEach(b => b.onclick = close);
    const rb = mask.querySelector("[data-cfr-retry]");
    if (rb) rb.onclick = () => { close(); openConflictDetail(cid); };
    return;
  }
  cfrDetail = r.data;
  const c = r.data.conflict || {};
  const perm = r.data.permissions || {};
  const recHtml = cfrRecreateHtml(r.data);
  const resAvailable = ["rule_a", "rule_b", "both_wrong", "both_valid", "need_more"].includes(c.resolution);
  mask.querySelector(".modal").innerHTML = `
    <div class="cfr-head"><div><h3>冲突详情</h3><div class="cfr-sub">只读详情 · 冲突 ${esc(c.id)} · 创建 ${esc(String(c.created_at || "").slice(0, 16) || "—")} · 仅当前工作空间
      <div style="margin-top:2px">先看摘要 / A-B 快照 / 差异 / 影响面 / 历史 / 关联；裁决动作在底部「开始裁决」独立面板提交。</div></div></div>
      <button class="ws-close" data-cfr-close aria-label="关闭">×</button></div>
    <div class="cfr-pills">${cfrSeverity("", c.severity, c.severity_label)} ${cfrPill(c.type_label || c.type || "—", "draft")} ${cfrStatus(c.status, c.status_label)} ${cfrResolutionText(c) ? cfrResolutionCell(c) : ""}
      ${c.recreate_pending ? cfrPill("待重新新建规则", "draft") : ""}
      <span class="muted" style="font-size:11px">${perm.can_resolve ? "你可裁决该冲突（" + esc(perm.role_label || perm.role || "") + "）" : "只读：" + esc(perm.reason || "无裁决权")}</span></div>
    <div class="cfr-banner ${c.status === "open" ? "warn" : "ok"}">${esc(c.detail || "未填写冲突说明")}
      ${c.suggestion ? `<div style="margin-top:4px"><b>系统建议：</b>${esc(c.suggestion)}</div>` : ""}
      ${c.status !== "open" ? `<div style="margin-top:4px"><b>裁决：</b>${esc(CFR_RES_LABEL[c.resolution] || c.resolution_label || c.resolution_display || "历史裁决")}${c.resolved_by ? " · " + esc(c.resolved_by) : ""}${c.resolved_at ? " · " + esc(String(c.resolved_at).slice(0, 16)) : ""}
        ${c.closed_rule_count ? ` · 已下线规则 ${esc(String(c.closed_rule_count))} 条（版本/审计保留）` : ""}
        ${(c.resolution_detail && typeof c.resolution_detail === "object" && c.resolution_detail.note) ? `<div>裁决原因：${esc(c.resolution_detail.note)}</div>` : ""}
        ${(c.resolution_detail && typeof c.resolution_detail === "object" && c.resolution_detail.corrected_criterion) ? `<div>正确判据：${esc(c.resolution_detail.corrected_criterion)}</div>` : ""}
      </div>` : ""}
      ${c.note && c.status === "open" && c.resolution === "need_more" ? `<div style="margin-top:4px"><b>证据不足记录：</b>${esc(c.note)}</div>` : ""}
    </div>
    <div class="cfr-section" id="cfr-snapshot-section"><h4>A、B 规则完整快照 <span class="muted">六组字段 · 与规则库详情同源读取；空字段显示“未填写 / 未配置”</span></h4>
      <div class="cfr-cards">${cfrRuleSnapshotHtml((r.data.rules || {}).a, "a")}${cfrRuleSnapshotHtml((r.data.rules || {}).b, "b")}</div></div>
    <div class="cfr-section" id="cfr-diff-section"><h4>差异对比 <span class="muted">阈值 / 比较符 / 单位 / 作用域 / 优先级 / 版本</span></h4>${cfrDiffHtml(r.data.differences)}</div>
    <div class="cfr-section"><h4>证据影响 <span class="muted">项目 / 点位 / 引用（命中、反馈、版本）</span></h4>${cfrImpactHtml(r.data.impact)}
      <div class="muted" style="font-size:11px;margin-top:6px">影响面摘要：<span class="cfr-code">${esc(r.data.impact_digest || "—")}</span>${perm.can_resolve && c.status === "open" ? "（「两者都不对」提交时必须确认此摘要）" : ""}</div></div>
    ${recHtml}
    <div class="cfr-section"><h4>裁决与操作历史</h4>${cfrHistoryHtml(r.data.history)}</div>
    <div class="cfr-section"><h4>关联冲突 <span class="muted">共享规则 A/B 的其他冲突</span></h4>${cfrRelatedHtml(r.data.related)}</div>
    <div class="cfr-actions">
      <button class="btn" data-cfr-back>返回列表</button>
      ${c.status !== "open" && c.resolution === "both_wrong" && perm.can_resolve
        && ((r.data.recreate || {}).available) && !((r.data.recreate || {}).rule_id)
        ? `<button class="btn" data-cfr-repair>修复裁决（更新正确判据）</button>` : ""}
      ${c.status === "open" && perm.can_resolve ? `<button class="btn primary" data-cfr-start>开始裁决</button>` : ""}
      ${c.status !== "open" ? `<button class="btn" data-cfr-close>关闭</button>` : ""}
    </div>`;
  const closeBtns = mask.querySelectorAll("[data-cfr-close]");
  closeBtns.forEach(b => b.onclick = close);
  mask.querySelectorAll("[data-cfr-back]").forEach(b => b.onclick = () => { close(); if (typeof loadConflicts === "function") loadConflicts(); });
  mask.querySelector("[data-cfr-start]")?.addEventListener("click", () => openConflictDecision(r.data, close));
  mask.querySelector("[data-cfr-recreate]")?.addEventListener("click", () => cfrCreateRecreate(r.data, close));
  mask.querySelectorAll("[data-cfr-repair]").forEach(b => b.addEventListener("click", () => openConflictRepair(r.data, close)));
  mask.querySelectorAll("[data-cfr-gorule]").forEach(b => b.onclick = () => {
    const rid = b.dataset.cfrGorule;
    close();
    showView("drafts");
    setTimeout(() => {
      if (typeof loadDrafts === "function") loadDrafts();
      if (typeof loadDetail === "function") loadDetail(rid);
    }, 400);
  });
  mask.onclick = e => { if (e.target === mask) close(); };
}

/* ---------- 裁决 modal（先选 radio 再填原因；未保存离开确认） ---------- */
let cfrDetail = null;
function cfrDecisionDirty(mask) {
  if (!mask) return false;
  if (mask.querySelector('input[name="cfr-res"]:checked')) return true;
  const vals = ["#cfr-note", "#cfr-corrected"].map(sel => (mask.querySelector(sel)?.value || "").trim());
  if (vals.some(Boolean)) return true;
  return !!(mask.querySelector("#cfr-impact-confirm")?.checked);
}
function openConflictDecision(detail, closeDetail) {
  cfrEnsureStyle();
  cfrRemove("conflict-decision-modal");
  const c = (detail && detail.conflict) || {};
  const options = (detail && detail.resolution_options) || [];
  const impact = (detail && detail.impact) || {};
  const projects = impact.projects || [];
  const points = impact.points || [];
  const refs = impact.references || [];
  const idemKey = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : ("cfr-" + Date.now() + "-" + Math.random().toString(36).slice(2));
  const mask = document.createElement("div"); mask.id = "conflict-decision-modal"; mask.className = "modal-mask";
  const maskHtml = `<div class="modal" style="width:min(760px,calc(100vw - 32px));max-height:92vh;overflow:auto">
    <div class="cfr-head"><div><h3>裁决冲突</h3><div class="cfr-sub">${esc(c.id)} · ${esc(c.type_label || c.type || "")} · ${esc(c.rule_a)} vs ${esc(c.rule_b)}</div></div>
      <button class="ws-close" data-cfd-close aria-label="关闭">×</button></div>
    <div class="cfr-step">① 选择裁决结果 <em>先选结果，再填写原因</em></div>
    <div class="cfr-opts">${options.map(o => `<label class="cfr-opt" data-cfr-opt="${esc(o.value)}">
        <input type="radio" name="cfr-res" value="${esc(o.value)}">
        <b>${esc(o.label)}</b>${o.closes_rules ? cfrPill("关闭两条规则", "draft") : ""}${o.keeps_open ? cfrPill("保持待处理", "r") : ""}
        <p>${esc(o.description || CFR_RES_DESC[o.value] || "")}</p></label>`).join("")}</div>
    <div class="cfr-step">② 填写裁决原因 <em>必填</em></div>
    <textarea id="cfr-note" class="field" style="width:100%;min-height:82px" placeholder="请先选择裁决结果，再填写裁决原因（会写入审计日志）" disabled></textarea>
    <div id="cfr-extra" style="display:none">
      <div id="cfr-corrected-wrap" style="display:none">
        <label class="cfr-field-label" for="cfr-corrected">正确的判据 <span class="cfr-req">「两者都不对」必填，预填到重新新建规则</span></label>
        <textarea id="cfr-corrected" class="field" style="width:100%;min-height:64px" placeholder="如：中心温度不得低于 90℃（写明正确的指标/比较符/阈值/作用域）"></textarea>
      </div>
      <div id="cfr-impact-confirm-wrap" class="cfr-imp-confirm" style="display:none">
        <label><input type="checkbox" id="cfr-impact-confirm"> 我已确认影响面（项目 / 点位 / 引用），并确认两条规则都错误、需要关闭后重新新建</label>
        <div class="muted" style="margin-top:6px">关闭后：两条规则状态变为「已下线」，规则/版本/审计/历史命中全部保留，不物理删除；新规则不会自动发布。</div>
        <ul class="cfr-imp-list">
          <li>项目：${esc(projects.length ? projects.map(p => p.name || p.case_id).join("、") : "无")}${Number(impact.other_project_count || 0) > 0 ? "（另有 " + esc(String(impact.other_project_count)) + " 个其他项目不可见）" : ""}</li>
          <li>点位：${esc(points.length ? points.map(p => p.point_id).join("、") : "无")}</li>
          <li>引用：${esc(refs.map(r => (r.side === "a" ? "A" : "B") + " " + (r.code || "")).join("、") || "无")} · 命中 ${esc(String((impact.findings || {}).total || 0))} 条</li>
        </ul>
        <div class="muted" style="margin-top:6px">影响面摘要：<span class="cfr-code">${esc(detail.impact_digest || "")}</span></div>
      </div>
    </div>
    <div id="cfr-msg" class="muted" style="font-size:12px;margin-top:8px;min-height:18px"></div>
    <div class="cfr-actions"><button class="btn" data-cfd-back>返回详情</button><button class="btn" data-cfd-close>取消</button>
      <button class="btn primary" id="cfd-submit">提交裁决</button></div></div>`;
  mask.innerHTML = maskHtml;
  document.body.appendChild(mask);
  const noteEl = mask.querySelector("#cfr-note");
  const msgEl = mask.querySelector("#cfr-msg");
  const submitBtn = mask.querySelector("#cfd-submit");
  const state = { selected: "", closed: false };
  const syncOpts = () => {
    mask.querySelectorAll(".cfr-opt").forEach(l => l.classList.toggle("on", l.dataset.cfrOpt === state.selected));
  };
  const guard = async () => {
    if (!cfrDecisionDirty(mask)) return true;
    return await confirmAction("放弃未提交的裁决？", "裁决结果/原因尚未提交，离开后本次填写将丢失。", "放弃并离开", true);
  };
  const close = () => { document.removeEventListener("keydown", onKey); mask.remove(); };
  const onKey = async (e) => { if (e.key === "Escape") { if (await guard()) close(); } };
  document.addEventListener("keydown", onKey);
  mask.querySelectorAll("[data-cfd-close]").forEach(b => b.onclick = async () => { if (await guard()) close(); });
  mask.querySelectorAll("[data-cfd-back]").forEach(b => b.onclick = async () => {
    if (!(await guard())) return;
    close();
    if (closeDetail) closeDetail();
    openConflictDetail(c.id);
  });
  mask.onclick = async e => { if (e.target === mask) { if (await guard()) close(); } };
  mask.querySelectorAll('input[name="cfr-res"]').forEach(input => input.addEventListener("change", () => {
    state.selected = input.value;
    syncOpts();
    noteEl.disabled = false;
    noteEl.placeholder = "请填写裁决原因（必填，写入审计日志）";
    const bothWrong = state.selected === "both_wrong";
    mask.querySelector("#cfr-extra").style.display = bothWrong ? "" : "none";
    mask.querySelector("#cfr-corrected-wrap").style.display = bothWrong ? "" : "none";
    mask.querySelector("#cfr-impact-confirm-wrap").style.display = bothWrong ? "" : "none";
    msgEl.textContent = state.selected === "need_more" ? "提交后该冲突保持「待处理」，后续可再次裁决。" : "";
  }));
  submitBtn.onclick = async () => {
    if (!state.selected) { msgEl.style.color = "#D83931"; msgEl.textContent = "请先选择裁决结果（6 条路径之一）"; return; }
    const note = noteEl.value.trim();
    if (!note) { msgEl.style.color = "#D83931"; msgEl.textContent = "请填写裁决原因"; return; }
    const bothWrong = state.selected === "both_wrong";
    let corrected = "";
    if (bothWrong) {
      corrected = (mask.querySelector("#cfr-corrected")?.value || "").trim();
      if (!corrected) { msgEl.style.color = "#D83931"; msgEl.textContent = "「两者都不对」必须填写正确的判据"; return; }
      if (!mask.querySelector("#cfr-impact-confirm")?.checked) { msgEl.style.color = "#D83931"; msgEl.textContent = "请先确认影响面（项目/点位/引用）"; return; }
    }
    submitBtn.disabled = true; submitBtn.textContent = "提交中…";
    const body = {
      action: CFR_RES_ACTION[state.selected], resolution: state.selected, note,
      corrected_criterion: corrected, confirm_impact: bothWrong,
      impact_digest: bothWrong ? (detail.impact_digest || "") : "",
      idempotency_key: idemKey,
    };
    const r = await cfrApi(`/api/v1/conflicts/${encodeURIComponent(c.id)}/resolve`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    submitBtn.disabled = false; submitBtn.textContent = "提交裁决";
    if (!r.ok) {
      msgEl.style.color = "#D83931";
      const code = (r.data && r.data.code) || "";
      const hint = code === "impact_stale" ? "；影响面已变化，请返回详情刷新后重新确认。"
        : code === "impact_digest_required" || code === "impact_confirm_required" ? "；请勾选影响面确认后再提交。"
        : code === "corrected_criterion_invalid" ? "；请修正「正确的判据」后直接再次提交，规则与冲突状态未变。"
        : code === "already_resolved" ? "；该冲突已裁决，不能重复修改；如需变更请重新发起冲突流程。"
        : "";
      msgEl.textContent = ((r.data && (r.data.error || r.data.message)) || ("提交失败（HTTP " + r.status + "）")) + hint;
      return;
    }
    showToast((r.data && r.data.message) || "已提交裁决");
    if (r.data && r.data.idempotent) showToast("重复提交：已按首次裁决处理");
    close();
    if (closeDetail) closeDetail();
    if (typeof loadConflicts === "function") loadConflicts();
    if (state.selected === "both_wrong" || (r.data && r.data.status === "resolved")) {
      setTimeout(() => openConflictDetail(c.id), 260);
    } else if (state.selected === "need_more") {
      setTimeout(() => openConflictDetail(c.id), 260);
    }
  };
}

/* ---------- 「两者都不对」重建失败不锁死：更新正确判据（T-107 服务层 repairable 路径） ---------- */
function openConflictRepair(detail, closeDetail) {
  cfrEnsureStyle();
  cfrRemove("conflict-repair-modal");
  const c = (detail && detail.conflict) || {};
  const rec = (detail && detail.recreate) || {};
  const pre = rec.prefill || {};
  const cur = String((pre.scope || {}).corrected_criterion || "").trim();
  const mask = document.createElement("div"); mask.id = "conflict-repair-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(640px,calc(100vw - 32px))">
    <div class="cfr-head"><div><h3>修复「两者都不对」裁决判据</h3>
      <div class="cfr-sub">冲突 ${esc(c.id)} · 两条规则已下线；本次只更新重建预填判据，<b>不会重复下线规则</b>，保存后可重试生成草稿。</div></div>
      <button class="ws-close" data-cfrp-close aria-label="关闭">×</button></div>
    <label class="cfr-field-label" for="cfr-repair-criterion">正确的判据 <span class="cfr-req">必填，预填到重建草稿</span></label>
    <textarea id="cfr-repair-criterion" class="field" style="width:100%;min-height:70px" placeholder="如：中心温度不得低于 90℃（写明正确的指标/比较符/阈值/作用域）">${esc(cur)}</textarea>
    <label class="cfr-field-label" for="cfr-repair-note">修复说明 <span class="cfr-req">必填（写入审计）</span></label>
    <input id="cfr-repair-note" class="field" style="width:100%" value="修复重建判据后重试生成草稿">
    <div id="cfr-repair-msg" class="muted" role="status" style="font-size:12px;margin-top:8px;min-height:18px"></div>
    <div class="cfr-actions"><button class="btn" data-cfrp-close>取消</button><button class="btn primary" id="cfr-repair-save">保存判据</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-cfrp-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  mask.querySelector("#cfr-repair-save").onclick = async () => {
    const msg = mask.querySelector("#cfr-repair-msg");
    const corrected = (mask.querySelector("#cfr-repair-criterion").value || "").trim();
    const note = (mask.querySelector("#cfr-repair-note").value || "").trim();
    if (!corrected) { msg.style.color = "#D83931"; msg.textContent = "请填写正确的判据"; return; }
    if (!note) { msg.style.color = "#D83931"; msg.textContent = "请填写修复说明（写入审计）"; return; }
    const btn = mask.querySelector("#cfr-repair-save"); btn.disabled = true; btn.textContent = "保存中…";
    const r = await cfrApi(`/api/v1/conflicts/${encodeURIComponent(c.id)}/resolve`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "resolved", resolution: "both_wrong", note,
        corrected_criterion: corrected, confirm_impact: false, impact_digest: "",
        idempotency_key: "cfr-repair-" + Date.now() }),
    });
    btn.disabled = false; btn.textContent = "保存判据";
    if (!r.ok) {
      msg.style.color = "#D83931";
      msg.textContent = (r.data && (r.data.error || r.data.message)) || ("保存失败（HTTP " + r.status + "）");
      return;
    }
    showToast((r.data && r.data.message) || "已更新重建判据（未重复下线规则），可重试生成草稿");
    close();
    if (closeDetail) closeDetail();
    setTimeout(() => openConflictDetail(c.id), 200);
  };
}

/* ---------- 「两者都不对」→ 重新新建规则（生成草稿，不自动发布） ---------- */
async function cfrCreateRecreate(detail, closeDetail) {
  const c = (detail && detail.conflict) || {};
  const rec = (detail && detail.recreate) || {};
  const pre = rec.prefill || {};
  const slots = pre.slots || {};
  const ok = await confirmAction("重新新建规则（生成草稿）",
    "将按冲突上下文预填生成一条【草稿】规则：\n判定模板 " + (pre.category || "—") +
    " · 指标 " + (slots.metric || "—") + " " + (slots.op || "") + " " + (slots.value ?? "") + (slots.unit || "") +
    "\n正确判据：" + ((pre.scope || {}).corrected_criterion || "—") +
    "\n来源：" + (pre.source || "conflict_recreate") +
    "\n\n只生成草稿，不会自动发布；新规则必须重新走 草稿 → 发布生效（无需审批）。",
    "生成草稿");
  if (!ok) return;
  const btn = document.querySelector("[data-cfr-recreate]");
  const msgEl = document.querySelector("#cfr-recreate-msg");
  if (btn) { btn.disabled = true; btn.textContent = "生成中…"; }
  if (msgEl) { msgEl.style.color = ""; msgEl.textContent = "正在生成草稿…"; }
  const r = await cfrApi(`/api/v1/conflicts/${encodeURIComponent(c.id)}/recreate`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "create_draft" }),
  });
  if (!r.ok) {
    const code = (r.data && r.data.code) || "";
    const err = (r.data && (r.data.error || r.data.message)) || ("生成失败（HTTP " + r.status + "）");
    const hint = code === "recreate_rule_invalid"
      ? "重建判据无法生成可执行规则；可点「更新正确判据（重建失败时）」修复裁决后重试，冲突与规则状态均未变。"
      : "冲突状态未变，可重试；若持续失败请联系管理员。";
    if (msgEl) { msgEl.style.color = "#D83931"; msgEl.textContent = "生成失败：" + err + " " + hint; }
    showToast(err, "err");
    if (btn) { btn.disabled = false; btn.textContent = "重新新建规则（生成草稿）"; }
    return;
  }
  if (msgEl) msgEl.textContent = "已生成重建草稿规则（不会自动发布；到规则草稿箱点「发布生效」后生效）。";
  showToast((r.data && r.data.message) || "已生成草稿规则");
  const ruleId = (r.data && r.data.rule_id) || "";
  const ruleCode = ((r.data && r.data.rule) || {}).code || "";
  if (typeof loadConflicts === "function") loadConflicts();
  const jump = await confirmAction("已生成重建规则草稿",
    "规则 " + (ruleCode || ruleId) + " 已生成，当前状态【草稿】。\n请到「规则草稿箱」点「发布生效」（无需审批）；系统不会自动发布。\n\n现在打开规则草稿箱继续？",
    "打开规则草稿箱");
  if (closeDetail) closeDetail();
  if (jump) {
    showView("drafts");
    setTimeout(() => {
      if (typeof loadDrafts === "function") loadDrafts();
      if (typeof loadDetail === "function" && ruleId) loadDetail(ruleId);
    }, 400);
  } else if (ruleId) {
    openConflictDetail(c.id);
  }
}

/* ---------- 冲突清单 ---------- */
/* T-108：列表与 KPI 使用同一筛选（状态走后端 filter；关键词/严重度/类型/日期在前端同源过滤），
   KPI 从过滤后的 items 计算，避免“列表 0 行但 KPI 仍显示全量”的矛盾；reviewer 只拿可裁范围。 */
let cfItems = [];
let cfListPage = 1;
function cfrStatsOf(items) {
  const st = { total: 0, critical: 0, open: 0, open_awaiting: 0, need_more: 0, resolved: 0, ignored: 0, pending_recreate: 0 };
  (items || []).forEach(x => {
    st.total++;
    if (String(x.severity || "") === "critical") st.critical++;
    const s = String(x.status || "");
    if (s === "open") {
      st.open++; st.open_awaiting++;
      if (String(x.resolution || "") === "need_more") st.need_more++;
    } else if (s === "resolved") st.resolved++;
    else if (s === "ignored") st.ignored++;
    if (x.recreate_pending) st.pending_recreate++;
  });
  return st;
}
function cfrEnsureStatsNote() {
  let n = document.querySelector("#conflict-stats-note");
  if (n) return n;
  const k = document.querySelector("#conflict-kpis");
  if (!k || !k.parentNode) return null;
  n = document.createElement("div");
  n.id = "conflict-stats-note";
  n.className = "muted";
  n.style.cssText = "font-size:11px;line-height:1.7;margin:-2px 0 10px";
  k.insertAdjacentElement("afterend", n);
  return n;
}
async function loadConflicts() {
  applyReviewerUi();
  cfrEnsureStyle();
  const out = $("#conflict-out");
  if (!out) return;
  const st = $("#cf-status")?.value || "";
  if (typeof uxSetLoading === "function") uxSetLoading("#conflict-out", "正在加载冲突…", 3);
  const r = await cfrApi("/api/v1/conflicts" + (st ? `?status=${encodeURIComponent(st)}` : ""));
  if (!out) return;
  if (!r.ok) {
    const msg = (r.data && (r.data.error || r.data.message)) || ("读取失败（HTTP " + r.status + "）");
    out.innerHTML = `<div class="cfr-banner err" role="alert" style="margin:10px 0"><b>冲突数据读取失败</b>：${esc(msg)}
      <div class="muted" style="font-size:11px;margin-top:4px">筛选条件已保留；冲突记录本身不受影响，可点「重新加载」重试。</div>
      <div style="margin-top:8px"><button class="btn" id="cf-retry-load">重新加载</button></div></div>`;
    const rb = document.querySelector("#cf-retry-load");
    if (rb) rb.onclick = () => loadConflicts();
    return;
  }
  const d = r.data || {};
  const rawItems = d.items || [];
  cfItems = rawItems;
  if (typeof loadConflictBadge === "function") loadConflictBadge();
  if (currentRole !== "admin") { const db = $("#btn-conflict-detect"); if (db) db.style.display = "none"; }
  const kw = ($("#cf-q")?.value || "").trim().toLowerCase();
  const sev = $("#cf-sev")?.value || "", typ = $("#cf-type")?.value || "", date = $("#cf-date")?.value || "";
  let items = rawItems.slice();
  if (kw) items = items.filter(x => [x.rule_a, x.rule_b, x.detail, x.suggestion, x.resolution_label, x.resolution_display, x.note, x.status_label, x.severity_label, x.type_label].some(v => String(v || "").toLowerCase().includes(kw)));
  if (sev) items = items.filter(x => (x.severity || "") === sev);
  if (typ) items = items.filter(x => (x.type || "") === typ);
  if (date) items = items.filter(x => (x.created_at || "").slice(0, 10) === date);
  const total = items.length;
  const pages = Math.max(1, Math.ceil(total / 20));
  cfListPage = Math.min(Math.max(1, cfListPage), pages);
  const pageItems = items.slice((cfListPage - 1) * 20, cfListPage * 20);
  // KPI 与列表同一数据源（过滤后的 items）；后端 stats 仅用于交叉核对/口径提示。
  const s = cfrStatsOf(items);
  window.__cfLastStats = s;
  window.__cfLastApiStats = d.stats || {};
  window.__cfFilter = { status: st, keyword: kw, severity: sev, type: typ, date: date, total: total };
  const stats = [
    { label: "冲突总数", value: s.total, hint: "当前筛选后的冲突条数" },
    { label: "严重", value: s.critical, hint: "当前筛选内 critical 冲突" },
    { label: "待处理（含证据不足）", value: s.open, hint: "status=open；含「证据不足」子状态" },
    { label: "已裁决", value: s.resolved, hint: "status=resolved（含历史裁决）" },
    { label: "已忽略", value: s.ignored, hint: "status=ignored（含历史忽略）" },
    { label: "证据不足（待处理子集）", value: s.need_more, hint: "已裁决为 need_more 且仍待处理；不重复计入总数" },
    { label: "待重新新建", value: s.pending_recreate, hint: "「两者都不对」后尚未生成重建规则" },
  ];
  const kpiBox = $("#conflict-kpis");
  if (kpiBox) {
    kpiBox.style.display = rawItems.length || total ? "grid" : "none";
    kpiBox.innerHTML = stats.map(k => `<div class="kpi" title="${esc(k.hint || "")}"><b>${esc(String(k.value))}</b><span>${esc(k.label)}</span></div>`).join("");
  }
  const note = cfrEnsureStatsNote();
  if (note) {
    note.style.display = rawItems.length || total ? "" : "none";
    const api = d.stats || {};
    const apiOk = !kw && !sev && !typ && !date && Number(api.total || 0) === Number(s.total || 0);
    note.innerHTML = "统计与列表使用同一筛选（关键词 / 状态 / 严重度 / 类型 / 日期）；「待处理」包含「证据不足」子状态，不重复计入总数。"
      + (d.scope === "reviewer_related" ? " 审核员统计仅含「可裁范围」。" : "")
      + (apiOk ? "" : "（当前为前端筛选后的口径）");
  }
  const scopeNote = d.scope === "reviewer_related"
    ? `<div class="cfr-banner info" style="margin:10px 0">审核员仅显示与<b>本人项目 / 本人规则 / 本人反馈</b>相关的冲突（可裁范围）；其他冲突不可见、不可裁决。</div>` : "";
  const tableHtml = `<table class="table" id="conflict-table"><thead><tr>
      <th style="width:52px">序号</th><th style="width:74px">严重度</th><th style="width:92px">冲突类型</th>
      <th>规则 A</th><th>规则 B</th><th>说明</th><th style="width:132px">裁决结果</th><th style="width:110px">创建时间</th><th style="width:76px">状态</th><th class="actions-cell" style="width:132px">操作</th>
    </tr></thead><tbody>` + pageItems.map((x, i) => `<tr data-cf-row="${esc(x.id)}">
      <td class="muted">${total - ((cfListPage - 1) * 20 + i)}</td>
      <td>${cfrSeverity("", x.severity, x.severity_label)}</td>
      <td>${esc(x.type_label || CFR_TYPE[x.type] || x.type || "—")}</td>
      <td class="muted">${esc(x.rule_a || "—")}</td><td class="muted">${esc(x.rule_b || "—")}</td>
      <td title="${esc(x.detail || "")}">${esc(x.detail || "—")}${x.recreate_pending ? ' <span class="pill draft">待重新新建</span>' : ""}</td>
      <td>${cfrResolutionCell(x)}</td>
      <td class="muted">${esc((x.created_at || "").slice(0, 16) || "—")}</td>
      <td>${cfrStatus(x.status, x.status_label)}</td>
      <td class="actions-cell"><div class="actions" style="justify-content:flex-end">
        <button class="btn" data-cf-view="${esc(x.id)}">查看详情</button>
        ${x.status === "open" && (x.permissions || {}).can_resolve ? `<button class="btn primary" data-cf-decide="${esc(x.id)}">裁决</button>` : ""}
      </div></td></tr>`).join("") + `</tbody></table>`;
  const emptyHtml = `<div class="empty" style="padding:56px 0"><div style="font-size:14px;color:#1F2329;margin-bottom:6px">当前筛选没有冲突</div>
        <div style="font-size:12px">${d.scope === "reviewer_related" ? "仅本人项目/本人规则/本人反馈相关的冲突会显示在这里。" : "可点右上角「全量检测」扫描当前空间规则（不按上传人过滤）。"}</div></div>`;
  out.innerHTML = scopeNote + (pageItems.length ? tableHtml : emptyHtml);
  const sel = $("#conflict-pager");
  if (sel) sel.innerHTML = total ? `<div class="pager"><span class="pager-total">共 ${total} 条 · 第 ${cfListPage}/${pages} 页</span><div class="pager-actions">${cfListPage > 1 ? `<button data-cfpg="${cfListPage - 1}">上一页</button>` : `<button disabled>上一页</button>`}${Array.from({ length: pages }, (_, i) => i + 1).slice(Math.max(0, cfListPage - 3), Math.max(0, cfListPage - 3) + 5).map(n => `<button class="${n === cfListPage ? 'on' : ''}" data-cfpg="${n}">${n}</button>`).join("")}${cfListPage < pages ? `<button data-cfpg="${cfListPage + 1}">下一页</button>` : `<button disabled>下一页</button>`}</div></div>` : "";
  sel?.querySelectorAll("[data-cfpg]").forEach(b => b.onclick = () => { cfListPage = Number(b.dataset.cfpg); loadConflicts(); });
  document.querySelectorAll("[data-cf-view]").forEach(b => b.addEventListener("click", () => openConflictDetail(b.dataset.cfView)));
  document.querySelectorAll("[data-cf-decide]").forEach(b => b.addEventListener("click", () => openConflictDetail(b.dataset.cfDecide)));
}

$("#btn-conflict")?.addEventListener("click", loadConflicts);

$("#btn-evo-refresh")?.addEventListener("click", () => { loadEvolutionPage(); $("#btn-evolution")?.click(); showToast("反馈已刷新"); });
$("#btn-conflict-detect")?.addEventListener("click", async () => {
  if (!(await confirmAction("全量检测", "只检测当前工作空间内的规则，不按上传人过滤、不跨空间比较；检测可能覆盖已有待处理记录。确认开始？", "开始检测"))) return;
  const r = await (await fetch("/api/v1/conflicts/detect", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
  showToast(`检测 ${r.rules || 0} 条规则，发现 ${(r.conflicts || []).length} 条冲突`);
  loadConflicts();
});
$("#cf-status")?.addEventListener("change", () => { cfListPage = 1; loadConflicts(); });
$("#cf-sev")?.addEventListener("change", () => { cfListPage = 1; loadConflicts(); });
$("#cf-type")?.addEventListener("change", () => { cfListPage = 1; loadConflicts(); });
$("#cf-date")?.addEventListener("change", () => { cfListPage = 1; loadConflicts(); });
$("#cf-q")?.addEventListener("input", () => { cfListPage = 1; loadConflicts(); });
$("#cf-refresh")?.addEventListener("click", () => { cfListPage = 1; loadConflicts(); });
$("#cf-reset")?.addEventListener("click", () => { ["#cf-q","#cf-sev","#cf-type","#cf-date","#cf-status"].forEach(x => { const e = $(x); if (e) e.value = ""; }); cfListPage = 1; loadConflicts(); });

/* ===================== 补充证据（独立入口） ===================== */
function openEvidenceView(fid) {
  const f = wbFindings.find(x => x.id === fid) || {};
  const evs = f.evidence || [];
  const old = document.querySelector("#evidence-view-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "evidence-view-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(620px,calc(100vw - 32px))">
    <div class="settings-head"><h3>证据查看</h3><button class="ws-close" data-evw-close>×</button></div>
    <div class="ev-view-title">${esc(f.title || "问题证据")}</div>
    <div class="ev-view-meta">${esc(f.rule_name || f.rule_code || "人工录入")} · ${esc(f.layer_label || "确定性判定")} · ${evs.length} 条证据</div>
    <div class="ev-view-basis" id="ev-view-basis"><b>判定依据</b> 正在读取规则版本与判定链…</div>
    <div class="ev-view-list">${evs.length ? evs.map((a, i) => `<div class="ev-view-item"><div class="ev-view-head"><b>证据 ${i + 1}</b><span class="muted">${esc(a.sheet || "")}${a.row ? " · 第 " + esc(a.row) + " 行" : ""}${a.col ? " · " + esc(a.col) + " 列" : ""}</span></div>
      <div class="ev-view-loc">${esc(a.locator || a.sheet || "原文位置未记录")}</div>
      <div class="ev-view-quote">${esc(a.quote || "暂无逐字引文")}</div></div>`).join("") : `<div class="empty">该问题暂无结构化证据；可以补充证据，或回到原文人工核对。</div>`}</div>
    <div class="actions" style="margin-top:14px;justify-content:flex-end"><button class="btn" data-evw-close>关闭</button>${evs.length ? `<button class="btn" id="ev-view-locate">定位到原文</button>` : ""}<button class="btn primary" id="ev-view-supplement">补充证据</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-evw-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  const loc = mask.querySelector("#ev-view-locate");
  if (loc) loc.onclick = () => { close(); locateFinding(fid); };
  mask.querySelector("#ev-view-supplement").onclick = () => { close(); openEvidence(fid); };
  (async () => {
    try {
      const p = await (await fetch(`/api/v1/findings/${fid}/provenance`)).json();
      const basis = mask.querySelector("#ev-view-basis"); if (!basis) return;
      const chain = p.chain || [];
      const ruleStep = chain.find(x => x.step === "规则") || {};
      const verStep = chain.find(x => x.step === "规则版本") || {};
      const srcStep = chain.find(x => x.step === "判定来源") || {};
      basis.innerHTML = `<b>判定依据</b> ${esc(f.rule_name || ruleStep.name || f.rule_code || "人工录入")}${ruleStep.version ? " · " + esc(ruleStep.version) : ""} · ${esc(srcStep.layer || f.layer_label || "确定性判定")}${srcStep.engine ? " / " + esc(srcStep.engine) : ""}<div style="margin-top:4px;color:#8F959E">${esc((verStep.hash ? "规则版本指纹 " + verStep.hash : "规则版本未记录") + (chain.length ? " · 证据链 " + chain.length + " 步" : ""))}</div>`;
    } catch (e) {}
  })();
}

function openEvidence(fid) {
  const mask = document.createElement("div");
  mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:520px">
    <h3 style="margin:0 0 6px">补充证据</h3>
    <div class="muted" style="font-size:12px;margin-bottom:12px">证据会挂到该问题下，并记入反馈台账（正向影响规则进化）</div>
    <textarea id="evd-text" class="field" style="width:100%;min-height:88px" placeholder="证据说明，如：原文见包装指示书 A10，该字段属于历史版本"></textarea>
    <div style="display:flex;align-items:center;gap:10px;margin-top:10px">
      <input type="file" id="evd-file" hidden>
      <button class="btn" id="evd-pick">选择文件</button>
      <span class="muted" id="evd-name">未选择</span>
    </div>
    <div class="actions" style="margin-top:14px;justify-content:flex-end">
      <button class="btn" id="evd-cancel">取消</button>
      <button class="btn primary" id="evd-save">提交证据</button>
    </div>
  </div>`;
  document.body.appendChild(mask);
  let picked = null;
  const nameEl = mask.querySelector("#evd-name");
  mask.querySelector("#evd-pick").addEventListener("click", () => mask.querySelector("#evd-file").click());
  mask.querySelector("#evd-file").addEventListener("change", (e) => {
    picked = e.target.files[0] || null;
    nameEl.textContent = picked ? picked.name : "未选择";
  });
  mask.querySelector("#evd-cancel").addEventListener("click", () => mask.remove());
  const saveBtn = mask.querySelector("#evd-save");
  saveBtn.addEventListener("click", async () => {
    const text = mask.querySelector("#evd-text").value.trim();
    if (!text && !picked) { alert("请填写证据说明或选择文件"); return; }
    saveBtn.disabled = true; saveBtn.textContent = "提交中…";
    try {
      const body = { text };
      if (picked) {
        const buf = await picked.arrayBuffer();
        let bin = "";
        const bytes = new Uint8Array(buf);
        for (let i = 0; i < bytes.length; i += 4096) bin += String.fromCharCode(...bytes.subarray(i, i + 4096));
        body.filename = picked.name;
        body.data = btoa(bin);
      }
      const r = await (await fetch(`/api/v1/findings/${fid}/evidence`, { method: "POST",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
      const _af = apiFail(r);
      if (_af) { alert(_af); return; }
      if (typeof currentWb !== "undefined" && currentWb) openWorkbench(currentWb);
    } catch (err) {
      alert("提交失败：" + (err && err.message ? err.message : "网络错误"));
    } finally {
      saveBtn.disabled = false; saveBtn.textContent = "提交证据";
      mask.remove();   // 无论成功失败都关闭，避免残留在页面上
    }
  });
}


/* 补证按钮：事件委托（避免渲染路径遗漏） */
document.addEventListener("click", (e) => {
  const btn = e.target.closest && e.target.closest("[data-evidence]");
  if (btn) {
    e.preventDefault(); e.stopPropagation();
    openEvidenceView(btn.dataset.evidence);
  }
});


/* 规则库筛选 */
$("#btn-rule-search")?.addEventListener("click", () => renderList());
["#rule-src", "#rule-status", "#rule-form", "#rule-cat", "#rule-risk", "#rule-exec", "#rule-map"].forEach(sel => {
  $(sel)?.addEventListener("change", () => { rulePage = 1; renderList(); });
});
["#rule-q", "#rule-owner"].forEach(sel => {
  $(sel)?.addEventListener("input", () => { rulePage = 1; renderList(); });
});
document.querySelector("#btn-rule-reset")?.addEventListener("click", () => {
  uxFiltersReset("rules");
  // L51：重置同时清掉分组筛选（分组筛选走 GET /rules?tag_id=，不在 localStorage 筛选内）
  if (typeof resetRuleTagFilter === "function") resetRuleTagFilter("rules");
  const st = document.querySelector("#rule-status");
  if (st) st.value = "effective";   // 规则库默认只面已发布/生效
  rulePage = 1; renderList();
});
$("#btn-rule-new")?.addEventListener("click", () => showView("newrule"));
/* 草稿箱筛选（独立视图，独立 localStorage key） */
["#draft-form", "#draft-ready"].forEach(sel => {
  $(sel)?.addEventListener("change", () => { if (typeof renderDraftList === "function") renderDraftList((rules || []).filter(isDraftRule)); });
});
$("#draft-q")?.addEventListener("input", () => { if (typeof renderDraftList === "function") renderDraftList((rules || []).filter(isDraftRule)); });
$("#btn-draft-search")?.addEventListener("click", () => { if (typeof renderDraftList === "function") renderDraftList((rules || []).filter(isDraftRule)); });
$("#btn-draft-reset")?.addEventListener("click", () => {
  uxFiltersReset("drafts");
  if (typeof resetRuleTagFilter === "function") resetRuleTagFilter("drafts");
  ["#draft-q", "#draft-form", "#draft-ready"].forEach(sel => { const el = $(sel); if (el) el.value = ""; });
  if (typeof renderDraftList === "function") renderDraftList((rules || []).filter(isDraftRule));
});
$("#btn-draft-refresh")?.addEventListener("click", () => { if (typeof loadDrafts === "function") loadDrafts(); });



/* 分段 tab 通用助手 */
function setSegTab(tabsSel, itemSel, active, onSwitch) {
  document.querySelectorAll(`${tabsSel} .seg-tab`).forEach(b => {
    const key = b.dataset.cal || b.dataset.onto;
    b.classList.toggle("on", key === active);
    if (!b.__bound) {
      b.__bound = true;
      b.addEventListener("click", () => onSwitch(key));
    }
  });
}

/* ===================== 本体建模 ===================== */
async function loadOntoWorkspace() {
  let d;
  try {
    const r = await fetch("/api/v1/ontology/workspace");
    d = await r.json();
    if (!r.ok) {
      const box = document.querySelector("#onto-auto-summary");
      if (box) box.textContent = d.error || "本体模块未启用";
      return;
    }
  } catch (e) {
    const box = document.querySelector("#onto-auto-summary");
    if (box) box.textContent = "本体状态读取失败";
    return;
  }
  const rev = currentRole === "reviewer";
  const th = document.querySelector("#onto-auto-threshold");
  if (th) th.value = d.threshold || 10;
  const summary = document.querySelector("#onto-auto-summary");
  if (summary) summary.textContent = `当前空间审核项目 ${d.project_count || 0} 份 · 启动阈值 ${d.threshold || 10} 份 · ${d.eligible ? "已达到，审核完成后自动发现" : "未达到，不自动启动"}`;
  const note = document.querySelector("#onto-auto-note");
  if (note) note.textContent = d.module_on ? "自动候选不会直接改动主链；业务管理员启用后，别名会在下一次审核取数时生效。人工术语可随时添加。" : "当前工作空间未启用本体模块；请先在空间配置中启用后再自动建模。";
  const run = document.querySelector("#onto-auto-run"); if (run) { run.disabled = rev || !d.eligible || !d.module_on; run.title = !d.eligible ? "审核项目未达到启动阈值" : ""; }
  const save = document.querySelector("#onto-auto-save"); if (save) save.disabled = rev;
  const tinput = document.querySelector("#onto-auto-threshold"); if (tinput) tinput.disabled = rev;
  const manual = document.querySelector("#onto-manual-box"); if (manual) manual.style.display = rev ? "none" : "";
  const terms = Array.isArray(d.terms) ? d.terms : [];
  const box = document.querySelector("#onto-auto-list");
  if (box) {
    box.innerHTML = terms.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>标准名</th><th>别名</th><th>来源</th><th class="num">证据/出现</th><th>状态</th><th>操作</th></tr></thead><tbody>` +
      terms.map(x => `<tr><td><b>${esc(x.canonical || "")}</b>${x.evidence ? `<div class="muted" style="font-size:10px">${esc(x.evidence)}</div>` : ""}${(x.similar_to || []).length ? `<div class="muted" style="font-size:10px;color:#D46B08">相近概念：${esc((x.similar_to || []).map(s => s.term).join("、"))}，需人工确认是否同义</div>` : ""}</td><td class="muted">${esc((x.aliases || []).join("、") || "—")}</td>
        <td><span class="pill ${x.source === "auto" ? "draft" : "published"}">${x.source === "auto" ? "自动发现" : "人工添加"}</span></td>
        <td class="num">${x.count || 0}</td><td><span class="pill ${x.status === "active" ? "published" : x.status === "ignored" ? "draft" : "r"}">${x.status === "active" ? "已启用" : x.status === "ignored" ? "已忽略" : "待确认"}</span></td>
        <td>${rev ? '<span class="muted">只读</span>' : (x.status === "candidate" ? `<button class="btn" data-onto-term="${esc(x.id)}" data-onto-status="active">启用</button><button class="btn" data-onto-term="${esc(x.id)}" data-onto-status="ignored">忽略</button>` : `<span class="muted">—</span>`)}</td></tr>`).join("") + `</tbody></table></div>`
      : `<div class="empty" style="padding:24px 0">当前空间还没有自动候选或人工术语</div>`;
    box.querySelectorAll("[data-onto-term]").forEach(b => b.addEventListener("click", async () => {
      const r = await (await fetch("/api/v1/ontology/workspace/term", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: b.dataset.ontoTerm, status: b.dataset.ontoStatus }) })).json();
      const _af = apiFail(r);
      if (_af) { showToast(_af, "err"); return; }
      loadOntoWorkspace();
    }));
  }
  if (!window.__ontoBound) {
    window.__ontoBound = true;
    document.querySelector("#onto-auto-save")?.addEventListener("click", async () => {
      const r = await (await fetch("/api/v1/ontology/workspace/threshold", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ threshold: Number(document.querySelector("#onto-auto-threshold")?.value || 10) }) })).json();
      const _af = apiFail(r);
      if (_af) { showToast(_af, "err"); return; }
      showToast(`启动阈值已保存：${r.threshold} 份`); loadOntoWorkspace();
    });
    document.querySelector("#onto-auto-run")?.addEventListener("click", async () => {
      const r = await (await fetch("/api/v1/ontology/workspace/discover", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
      const _af = apiFail(r);
      if (_af) { showToast(_af, "err"); return; }
      showToast(r.started ? `发现 ${r.created || 0} 个候选术语` : (r.reason || "未达到启动条件"));
      loadOntoWorkspace();
    });
    document.querySelector("#onto-m-add")?.addEventListener("click", async () => {
      const canonical = document.querySelector("#onto-m-canonical")?.value.trim() || "";
      const aliases = (document.querySelector("#onto-m-aliases")?.value || "").split(/[,，、]/).map(x => x.trim()).filter(Boolean);
      const type = document.querySelector("#onto-m-type")?.value.trim() || "";
      const evidence = document.querySelector("#onto-m-evidence")?.value.trim() || "";
      const msg = document.querySelector("#onto-m-msg");
      if (!canonical) { if (msg) msg.textContent = "请填写标准名"; return; }
      const r = await (await fetch("/api/v1/ontology/workspace/add", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ canonical, aliases, type, evidence }) })).json();
      const _af = apiFail(r);
      if (_af) { if (msg) { msg.style.color = "#D83931"; msg.textContent = _af; } return; }
      if (msg) { msg.style.color = ""; msg.textContent = "已添加；启用的术语会参与下一次审核别名归一"; }
      document.querySelector("#onto-m-canonical").value = ""; document.querySelector("#onto-m-aliases").value = ""; document.querySelector("#onto-m-type").value = ""; document.querySelector("#onto-m-evidence").value = "";
      loadOntoWorkspace();
    });
    document.querySelectorAll("[data-onto-src]").forEach(b => {
      b.addEventListener("click", () => {
        document.querySelectorAll("[data-onto-src]").forEach(x => x.classList.toggle("on", x === b));
        const isAuto = b.dataset.ontoSrc === "auto";
        const ap = document.querySelector("#onto-auto-panel"), mp = document.querySelector("#onto-manual-panel");
        if (ap) ap.hidden = !isAuto; if (mp) mp.hidden = isAuto;
      });
    });
  }
}


async function runOntologyImpact() {
  const term = String(document.querySelector("#onto-impact-term")?.value || "").trim();
  const out = document.querySelector("#onto-impact-out");
  const msg = document.querySelector("#onto-impact-msg");
  if (!out) return;
  if (!term) { if (msg) msg.textContent = "请输入术语"; return; }
  if (msg) msg.textContent = "分析中…";
  const r = await (await fetch("/api/v1/ontology/impact?term=" + encodeURIComponent(term))).json();
  const _af = apiFail(r);
  if (msg) msg.textContent = _af || `影响 ${r.count || 0} 处`;
  if (_af) { out.innerHTML = `<div class="muted">${esc(_af)}</div>`; return; }
  const block = (title, rows, cols) => rows.length ? `<div style="margin-top:8px"><b style="font-size:12px">${title}（${rows.length}）</b><table class="table" style="margin-top:5px"><thead><tr>${cols.map(c => `<th>${c}</th>`).join("")}</tr></thead><tbody>${rows.map(x => `<tr>${cols.map(c => `<td>${esc(String(x[c] ?? "—"))}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : "";
  out.innerHTML = (block("规则", r.rules || [], ["code", "name", "status", "metric"]) +
    block("决策表", r.decision_tables || [], ["code", "name", "status", "version"]) +
    block("智能体", r.agents || [], ["id", "name", "status"])) || `<div class="muted">没有直接引用该术语的规则/决策表/智能体；仍需人工确认。</div>`;
}
function bindOntologyImpact() {
  const btn = document.querySelector("#onto-impact-run");
  if (!btn || btn.__bound) return;
  btn.__bound = true;
  btn.addEventListener("click", runOntologyImpact);
}

/* 本体类型 key → 中文名：页面可见处显示中文，title 保留 key 供技术排查；保存仍用 key。
   真值优先取 /api/v1/ontology 返回的 types[].name（后端类型定义），缺失时用内置兜底映射。 */
const ONTO_TYPE_LABEL_FALLBACK = {
  ProcessStep: "工序", HalfProduct: "半成品", Metric: "指标", Unit: "单位",
  Product: "产品", Subject: "主体", Document: "文档",
};
function ontoTypeLabels(types) {
  const m = { ...ONTO_TYPE_LABEL_FALLBACK };
  (types || []).forEach((t) => {
    const k = String((t && (t.key || t.type_key)) || "").trim();
    if (k) m[k] = String((t && (t.name || t.label)) || m[k] || k);
  });
  return m;
}
function ontoTypeLabel(map, key) {
  const k = String(key || "").trim();
  if (!k) return "";
  return (map && map[k]) || ONTO_TYPE_LABEL_FALLBACK[k] || k;
}

async function loadOntology() {
  // T-111：审核员不看本体（左侧无菜单 + 路由守卫 + 服务端写 403）；数据加载层同样兜底，不静默读取。
  const _ontoDeny = typeof roleViewDenied === "function" ? roleViewDenied("ontology") : "";
  if (_ontoDeny) {
    showPermDeniedNotice("ontology", _ontoDeny);
    if (typeof showToast === "function") showToast(_ontoDeny, "err");
    return;
  }
  setSegTab("#onto-tabs", "[data-onto]", ONTO_TAB, (k) => {
    ONTO_TAB = k;
    ["types", "instances", "aliases", "links"].forEach(t => {
      const el = document.querySelector(`#onto-${t}`);
      if (el) el.hidden = t !== k;
    });
  });
  bindOntologyImpact();
  const d = await (await fetch("/api/v1/ontology")).json();
  const types = d.types || [], insts = d.instances || [], links = d.links || [], linkTypes = d.link_types || [];
  const _tl = ontoTypeLabels(types);
  const aliases = (d.alias_list || []).length;
  const _ontoNote = document.querySelector("#onto-readonly-note");
  if (_ontoNote) _ontoNote.style.display = currentRole === "reviewer" ? "" : "none";
  $("#onto-kpis").innerHTML =
    `<div class="kpi"><b>${types.length}</b><span>类型</span></div>
     <div class="kpi"><b>${insts.length}</b><span>实例</span></div>
     <div class="kpi"><b>${aliases}</b><span>别名</span></div>
     <div class="kpi"><b>${links.length}</b><span>链接</span></div>`;
  $("#ontology-out").innerHTML = types.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>类型</th><th>标识</th><th>属性定义</th><th>实例数</th><th>来源</th><th>说明</th>
    </tr></thead><tbody>` + types.map((t, i) => `<tr>
      <td>${types.length - i}</td><td><b>${esc(t.name || t.key || "")}</b></td>
      <td class="muted" title="${esc(t.key || "")}">${esc(ontoTypeLabel(_tl, t.key || t.name || ""))}${t.parent_key ? `<div class="muted" title="${esc(t.parent_key)}">父：${esc(ontoTypeLabel(_tl, t.parent_key))}</div>` : ""}</td>
      <td class="muted">${Object.values(t.properties || {}).map(pp => `${esc(pp.name || pp.key)}（${esc(pp.data_type || "")}${pp.required ? "，必填" : ""}）`).join("<br>") || "未定义"}</td>
      <td>${(insts.filter(x => x.type_key === (t.key || "")).length)}</td>
      <td class="muted">${esc(t.source || "系统内置")}</td>
      <td class="muted">${esc(t.desc || "")}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">还没有本体类型</div>`;
  $("#onto-inst-out").innerHTML = insts.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>实例</th><th>类型</th><th>别名数</th><th>来源</th><th>创建时间</th>
    </tr></thead><tbody>` + insts.slice(0, 200).map((x, i) => `<tr>
      <td>${insts.length - i}</td><td><b>${esc(x.name || "")}</b></td>
      <td class="muted" title="${esc(x.type_key || "")}">${esc(ontoTypeLabel(_tl, x.type_key))}</td><td>${x.alias_count || 0}</td>
      <td class="muted">${esc(x.source || "系统预置")}</td><td class="muted">${esc((x.created_at || "").slice(0,16) || "—")}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">还没有实例</div>`;
  $("#onto-alias-out").innerHTML = (d.alias_list || []).length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>别名</th><th>归一为</th><th>类型</th><th>依据/来源</th>
    </tr></thead><tbody>` + d.alias_list.map((x, i) => `<tr>
      <td>${d.alias_list.length - i}</td><td>${esc(x.alias)}</td>
      <td><b>${esc(x.name)}</b></td><td class="muted" title="${esc(x.type_key)}">${esc(ontoTypeLabel(_tl, x.type_key))}</td>
      <td class="muted">${esc(x.evidence || "未提供")}${x.source ? ` · ${esc(x.source)}` : ""}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">还没有别名</div>`;
  const _lt = linkTypes.length ? `<div class="evo-note" style="margin-bottom:8px">关系类型定义（本体先声明方向/基数，实例再连边）</div><table class="table" style="margin-bottom:14px"><thead><tr><th>关系键</th><th>名称</th><th>源类型</th><th>目标类型</th><th>基数</th></tr></thead><tbody>` +
    linkTypes.map(x => `<tr><td><b>${esc(x.key)}</b></td><td>${esc(x.name || "")}</td><td>${esc(x.source_type || "")}</td><td>${esc(x.target_type || "")}</td><td class="muted">${esc(x.cardinality || "")}</td></tr>`).join("") + `</tbody></table>` : "";
  $("#onto-link-out").innerHTML = _lt + (links.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>关系</th><th>起点</th><th>终点</th><th>状态</th>
    </tr></thead><tbody>` + links.map((l, i) => `<tr>
      <td>${links.length - i}</td><td class="muted">${esc(l.key)}</td>
      <td>${esc(l.source_name || "")}</td><td>${esc(l.target_name || "")}</td>
      <td><span class="pill ${l.ok ? "published" : "draft"}">${l.ok ? "方向正确" : "方向异常"}</span></td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">还没有实例关系</div>`);
  await loadOntoWorkspace();
}

/* ===================== 企业词典：路由 / 挂载（视图在 dict_view.js） ===================== */
/*
 * 企业词典列表/新增/编辑/删除/确认/迁移/只读角色控制已迁至 web/dict_view.js。
 * app.js 只保留 showView 路由、菜单/视图挂载和加载顺序兜底，不复制词典实现。
 * index.html 在本文件之前加载 dict_view.js；admin.html/reviewer.html 未改
 * 静态引用，因此这里在首次需要时注入一次 /dict_view.js，避免旧入口丢失词典。
 */
let dictViewLoadPromise = null;

function ensureDictViewLoaded() {
  if (typeof ensureTermsUI === "function") return Promise.resolve(true);
  if (dictViewLoadPromise) return dictViewLoadPromise;
  dictViewLoadPromise = new Promise((resolve) => {
    const script = document.createElement("script");
    script.src = "/dict_view.js";
    script.async = false;
    script.onload = () => resolve(typeof ensureTermsUI === "function");
    script.onerror = () => {
      dictViewLoadPromise = null;
      console.error("dict_view.js 加载失败：请确认服务端已暴露 /dict_view.js（app/api/server.py 静态路由）");
      resolve(false);
    };
    (document.head || document.documentElement).appendChild(script);
  });
  return dictViewLoadPromise;
}

function mountTermsView() {
  if (typeof ensureTermsUI === "function") {
    ensureTermsUI();
    return true;
  }
  ensureDictViewLoaded().then((ok) => {
    if (ok && typeof ensureTermsUI === "function") ensureTermsUI();
  });
  return false;
}

function openTermsView() {
  if (typeof loadTermsPage === "function") return loadTermsPage();
  ensureDictViewLoaded().then((ok) => {
    if (ok && typeof loadTermsPage === "function") loadTermsPage();
  });
  return false;
}

function syncTermsRole() {
  if (typeof applyTermsRole !== "function") return false;
  applyTermsRole();
  return true;
}

/* T-109（2026-11-18）规则域 IA：规则库 / 决策表不再使用页签，草稿箱为独立菜单视图；
   决策表作为规则形式出现在规则库列表。旧的 initRuleTabs/RL_TAB 已删除。 */
/* ===================== 规则库：规则 / 决策表 页签 ===================== */
/* 旧页签边界保留为兼容注释（dict_ui_static/dict_stale 用该边界切分企业词典模块；此段已无页签实现）。 */
function loadCalibration() {
  // 兼容旧调用：进入规则库即加载规则库（不再有决策表子页签）
  if (typeof loadRules === "function") loadRules();
}

/* ===================== 规则库：决策表子页签 ===================== */
/* 决策表页面已拆到 web/decision_tables.js。 */
function loadPermissions() {
  return fetch('/api/v1/me/permissions').then(r => r.json()).then(function (r) {
    var actions = r.actions || r.codes || [];
    window.__ALL_PERMS = actions.indexOf('*') >= 0;
    window.__PERMS = new Set(actions.filter(function (x) { return x !== '*'; }));
    window.__MENUS = new Set(r.menus || []);
    applyMenuPermissions();
  }).catch(function () {});
}
function applyMenuPermissions() {
  var all = window.__ALL_PERMS, perms = window.__PERMS || new Set(), menus = window.__MENUS || new Set();
  var role = (typeof currentRole === "string" && currentRole) ||
             (currentUser && currentUser.role) || window.__role || '';
  document.querySelectorAll('[data-perm]').forEach(function (el) {
    var need = (el.getAttribute('data-perm') || '').split(' ')[0];
    var view = el.getAttribute('data-view') || '';
    // 菜单以 menus 为准；actions 只控制按钮，不能让系统管理员因为 "*" 看到业务菜单
    // T-109：草稿箱与规则库同一菜单权限（后端 menus 只有 rules 视图），不新增后端权限点
    var viewKey = view === "drafts" ? "rules" : view;
    var ok = view ? menus.has(viewKey) : (need ? (all || perms.has(need)) : true);
    el.style.display = ok ? '' : 'none';
  });
  // 系统管理员专属页（如数据边界）：服务端 ROLE_PERMS 未列出时，页面以 data-super-only 声明，
  // 仅 super_admin 显示；其它角色直达同一 URL 时页面守卫 + 服务端 403 拒绝。
  document.querySelectorAll('[data-super-only]').forEach(function (el) {
    el.style.display = (role === 'super_admin') ? '' : 'none';
  });
  // T-105：知识库只对业务管理员/审核员开放（后端同一口径 admin/reviewer；系统管理员/平台运营 403）。
  var kbAllowed = role === 'admin' || role === 'reviewer';
  document.querySelectorAll('.menu-item[data-view="knowledge"]').forEach(function (el) {
    el.style.display = kbAllowed ? '' : 'none';
    el.classList.toggle('role-hidden', !kbAllowed);
  });
  // 隐藏没有任何可见子项的分组标题（避免审核员看到空分组）
  document.querySelectorAll('.menu-group').forEach(function (g) {
    var n = g.nextElementSibling, any = false;
    while (n && !n.classList.contains('menu-group')) {
      if (n.classList.contains('menu-item') && n.style.display !== 'none') { any = true; break; }
      n = n.nextElementSibling;
    }
    g.style.display = any ? '' : 'none';
  });
}
async function mountDocTypePicker(containerId, selected, opts) {
  const el = document.getElementById(containerId); if (!el) return null;
  const o = opts || {};
  ensureWsPickerStyle();
  el.innerHTML = '<div class="muted" style="padding:8px 2px">加载文件类型库…</div>';
  let docs = [];
  try {
    const r = await (await fetch("/api/v1/audit-points/library")).json();
    docs = Array.isArray(r.document_types) ? r.document_types : [];
  } catch (e) {}
  const profiles = {};
  const names = [];
  const seen = new Set();
  for (const d of docs) {
    const n = String((d && d.name) || "").trim();
    if (!n || seen.has(n)) continue;
    seen.add(n); names.push(n);
    profiles[n] = {
      base_type: String((d && d.base_type) || wsBaseType(n)),
      default_audit_types: Array.isArray(d && d.default_audit_types) ? d.default_audit_types.map(String) : [],
      other: !!(d && d.other),
    };
  }
  if (!names.length) {
    FALLBACK_DOC_TYPES.forEach(x => {
      if (seen.has(x.name)) return;
      seen.add(x.name); names.push(x.name);
      profiles[x.name] = { base_type: x.base_type || wsBaseType(x.name), default_audit_types: [], other: false };
    });
  }
  let otherName = OTHER_DOC_TYPE;
  const otherEntry = docs.find(d => d && d.other && d.name);
  if (otherEntry) otherName = String(otherEntry.name);
  if (!seen.has(otherName)) { seen.add(otherName); names.push(otherName); }
  profiles[otherName] = { base_type: "general", default_audit_types: [], other: true };
  // “其他（未列入标准类型）”固定最后一项；前面是标准类型库。
  const normalNames = names.filter(n => n !== otherName);
  const picked = new Set((selected || []).map(x => String(x || "").trim()).filter(Boolean));
  el.innerHTML = `<input id="${containerId}-search" class="field dt-search" placeholder="搜索文件类型（共 ${names.length} 个）">
    <div class="ws-dt-grid" id="${containerId}-list">${normalNames.map(n => `<label class="dt-option"><input type="checkbox" value="${esc(n)}" ${picked.has(n) ? "checked" : ""}> <span>${esc(n)}</span></label>`).join("")}<label class="dt-option ws-dt-other"><input type="checkbox" value="${esc(otherName)}" ${picked.has(otherName) ? "checked" : ""}> <span>${esc(otherName)}<small>通用规则 / 需人工确认：不伪造专用规则；涉及该类型的审核结论由人工确认。</small></span></label></div>
    <div class="ws-dt-other-note" id="${containerId}-other-note" hidden>已选择「${esc(otherName)}」：使用通用规则执行，不伪造专用规则；涉及该类型的审核结论需人工确认。</div>
    <div class="ws-dt-count" id="${containerId}-count"></div>
    <div class="ws-suit" id="${containerId}-suit"></div>`;
  const list = el.querySelector(".ws-dt-grid");
  const count = el.querySelector(".ws-dt-count");
  const suit = el.querySelector(".ws-suit");
  const otherNote = el.querySelector(".ws-dt-other-note");
  const selectedValues = () => [...list.querySelectorAll("input:checked")].map(x => x.value);
  const renderSuit = (verdict, sel) => {
    if (!sel.length) {
      suit.className = "ws-suit";
      suit.innerHTML = '<div class="ws-suit-title">将检查是否适合同一批规则库</div>' +
        '<div class="ws-suit-desc">选择 2 个及以上文件类型时，按业务域（食品/工艺、合同/采购、申报/资质、通用）+ 默认审核类型重叠实时判断；不适用时创建按钮会被禁用。</div>';
      return;
    }
    if (verdict.compatible) {
      suit.className = "ws-suit ok";
      suit.innerHTML = '<div class="ws-suit-title">✓ 适合同一批规则库</div><div class="ws-suit-desc">' + esc(verdict.reason) + '</div>';
      return;
    }
    suit.className = "ws-suit err";
    let html = '<div class="ws-suit-title">✗ 不适合同一批规则库，不能创建</div><div class="ws-suit-desc">' + esc(verdict.reason) + '</div>';
    if (verdict.suggestion) html += '<div class="ws-suit-split">' + esc(verdict.suggestion) + '</div>';
    if (verdict.groups && verdict.groups.length) {
      html += '<ul class="ws-suit-groups">' + verdict.groups.filter(g => g.types && g.types.length)
        .map(g => '<li><b>' + esc(g.label) + '</b>：' + esc(g.types.join("、")) + '</li>').join("") + '</ul>';
    }
    suit.innerHTML = html;
  };
  const sync = () => {
    const checked = [...list.querySelectorAll("input:checked")];
    count.textContent = `已选择 ${checked.length} / 5（必须选择 1–5 个）`;
    list.querySelectorAll("input").forEach(cb => { cb.disabled = !cb.checked && checked.length >= 5; });
    const sel = checked.map(x => x.value);
    const verdict = wsJudgeDocTypes(sel, profiles, otherName);
    renderSuit(verdict, sel);
    if (otherNote) otherNote.hidden = sel.indexOf(otherName) < 0;
    if (typeof o.onChange === "function") {
      try { o.onChange({ selected: sel, verdict: verdict, otherSelected: sel.indexOf(otherName) >= 0, otherName: otherName, profiles: profiles }); } catch (e) {}
    }
  };
  list.querySelectorAll("input").forEach(cb => cb.addEventListener("change", sync));
  el.querySelector(".dt-search").addEventListener("input", (e) => {
    const q = e.target.value.trim().toLowerCase();
    list.querySelectorAll("label").forEach(x => {
      x.style.display = !q || x.innerText.toLowerCase().includes(q) ? "" : "none";
    });
  });
  sync();
  return {
    getSelected: selectedValues,
    judge: () => wsJudgeDocTypes(selectedValues(), profiles, otherName),
    otherName: otherName,
    profiles: profiles,
    refresh: sync,
  };
}
function docPickerSelected(containerId) {
  return [...document.querySelectorAll(`#${containerId} input[type="checkbox"]:checked`)].map(x => x.value);
}
function openWsCreateModal(currentId) {
  var old = document.getElementById('ws-create-modal');
  if (old) old.remove();
  var mask = document.createElement('div');
  mask.id = 'ws-create-modal';
  mask.className = 'ws-mask';
  mask.innerHTML = '<div class="ws-dialog ws-dialog-wide" role="dialog" aria-modal="true" aria-labelledby="ws-dialog-title">' +
    '<div class="ws-dialog-head"><h3 id="ws-dialog-title">新建工作空间</h3><button type="button" class="ws-close" aria-label="关闭">×</button></div>' +
    '<label class="ws-label">空间名称<input id="ws-new-name" class="field" placeholder="例如：华东客户审核" autofocus></label>' +
    '<label class="ws-label">主文件类型（必选 1–5 个）</label><div id="ws-new-types-box"></div>' +
    '<div class="ws-hint">工作空间对同租户所有人可见；新建项目只能从这里的文件类型中选择。重要：本空间新增规则默认对所选全部文件类型生效；若不同文件类型的规则不同，请建立不同空间。最后一项「其他（未列入标准类型）」按通用规则执行，需人工确认。</div>' +
    '<div class="ws-dialog-actions"><button type="button" class="btn ws-cancel">取消</button><button type="button" class="btn primary ws-ok">创建空间</button></div>' +
    '<div id="ws-new-msg" class="ws-msg"></div></div>';
  document.body.appendChild(mask);
  var okBtn = mask.querySelector('.ws-ok');
  var picker = null;
  var verdict = null;
  mountDocTypePicker("ws-new-types-box", [], {
    onChange: function (state) {
      verdict = state.selected.length ? state.verdict : null;
      var blocked = !!(verdict && !verdict.compatible);
      okBtn.disabled = blocked;
      okBtn.title = blocked ? (verdict.reason || "所选文件类型不适合同一批规则库") : "";
    },
  }).then(function (p) { picker = p; }).catch(function () {});
  var close = function(){ mask.remove(); };
  mask.querySelector('.ws-close').onclick = close;
  mask.querySelector('.ws-cancel').onclick = close;
  mask.onclick = function(e){ if (e.target === mask) close(); };
  document.getElementById('ws-new-name').focus();
  okBtn.onclick = async function () {
    var name = document.getElementById('ws-new-name').value.trim();
    var raw = docPickerSelected('ws-new-types-box');
    var msg = document.getElementById('ws-new-msg');
    if (name.length < 2) { msg.style.color = '#B91C1C'; msg.textContent = '空间名称至少 2 个字'; return; }
    if (raw.length < 1 || raw.length > 5) { msg.style.color = '#B91C1C'; msg.textContent = '请选择 1~5 个主文件类型'; return; }
    // 不适用同一批规则库：按钮已禁用；这里再兜底一次（不是只 toast）。
    var v = picker ? picker.judge() : verdict;
    if (v && v.selected && v.selected.length && !v.compatible) {
      msg.style.color = '#B91C1C';
      msg.textContent = v.reason + (v.suggestion ? ' ' + v.suggestion : '');
      return;
    }
    msg.style.color = '';
    msg.textContent = '创建中…';
    var res = await (await fetch('/api/v1/workspaces/create', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name:name, settings:{visibility:"tenant", doc_types:raw, members: [], point_confirm_required:true}})})).json();
    if (!res.ok) {
      msg.style.color = '#B91C1C';
      msg.textContent = (res.reason || '创建失败') + (res.suggestion ? ' ' + res.suggestion : '');
      return;
    }
    msg.style.color = '#0F7B4F';
    msg.textContent = '已创建。不会自动切换当前空间；需要使用时请在左侧工作空间切换或编辑配置。';
    if (typeof initWorkspaceSwitcher === 'function') initWorkspaceSwitcher();
    setTimeout(close, 1200);
  };
}

function initWorkspaceSwitcher() {
  var sel = document.getElementById('ws-switcher');
  if (!sel) return;
  fetch('/api/v1/workspaces').then(r => r.json()).then(function (r) {
    var items = (r && r.items) || [], cur = (r && r.current) || {};
    sel.innerHTML = items.map(function (w) {
      return '<option value="' + w.id + '"' + (w.id === cur.id ? ' selected' : '') + '>' + w.name + (w.setup_required ? '（待配置）' : '') + '</option>';
    }).join('');
    sel.onchange = function () {
      sessionStorage.setItem('rp_after_switch', currentView || 'rules');
      fetch('/api/v1/workspaces/switch', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id: sel.value})})
        .then(() => location.reload());
    };
  }).catch(function () {});
}
loadPermissions();
document.addEventListener('DOMContentLoaded', initWorkspaceSwitcher);


/* ===== 空间可见性：上传页/列表页顶部条（P1.3/P1.4） ===== */
function ensureWsBar(view) {
  var host = document.getElementById(view);
  if (!host) return;
  var bar = document.getElementById('ws-bar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'ws-bar';
    bar.className = 'ws-bar';
    bar.innerHTML = '<span class="ws-bar-label">当前工作空间</span>' +
      '<select id="ws-bar-select" class="field" style="max-width:220px"></select>' +
      '<span class="ws-bar-hint">规则、类型范围与审核结果均按此空间生效</span>';
    host.insertBefore(bar, host.firstChild);
  }
  var sel = document.getElementById('ws-bar-select');
  if (!sel || sel.dataset.ready === '1') return;
  fetch('/api/v1/workspaces').then(function (r) { return r.json(); }).then(function (r) {
    var items = (r && r.items) || [], cur = (r && r.current) || {};
    sel.innerHTML = items.map(function (w) {
      return '<option value="' + w.id + '"' + (w.id === cur.id ? ' selected' : '') + '>' + w.name + (w.setup_required ? '（待配置）' : '') + '</option>';
    }).join('');
    if (view === 'projects') {
      sel.insertAdjacentHTML('afterend',
        ' <select id="ws-scope" class="field" style="max-width:130px">' +
        '<option value="current">仅当前空间</option><option value="all">全部空间</option></select>');
      var sc = document.getElementById('ws-scope');
      if (sc) sc.onchange = function () { window.__WS_FILTER = sc.value; loadProjects(1); };
    }
    sel.dataset.ready = '1';
    sel.onchange = function () {
      fetch('/api/v1/workspaces/switch', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id: sel.value})})
        .then(function(){ location.reload(); });
    };
  });
}

/* ===== 跨空间打开项目：空间下拉与项目所属空间保持一致（2026-11-22 体验补齐） =====
   背景：项目列表按产品口径跨空间汇总，后端 P1 已按项目所属 case 的空间切上下文放行
   （打开非当前空间的**自有**项目返回 200）；但左侧「当前工作空间」下拉仍停在原空间，
   打开后下拉显示的空间与项目不一致，用户会误解该项目的规则/类型范围。
   口径：只做前端状态对齐——沿用既有 switch 接口切当前空间并同步下拉，不改后端判权；
   取不到项目空间（旧接口/无 workspace_id）或切换失败时保持现状，不阻断打开、不报错。*/
var __wsSyncCache = null;

function _wsSyncSelects(wsId, wsName) {
  ["ws-switcher", "ws-bar-select"].forEach(function (id) {
    var sel = document.getElementById(id);
    if (!sel) return;
    var has = false;
    for (var i = 0; i < sel.options.length; i++) {
      if (String(sel.options[i].value) === String(wsId)) { has = true; break; }
    }
    if (!has && wsName) {
      var opt = document.createElement("option");
      opt.value = String(wsId); opt.textContent = String(wsName);
      sel.appendChild(opt);
    }
    try { sel.value = String(wsId); } catch (e) { /* 选项不存在时保持原值 */ }
  });
}

/* 下拉里已有该空间的显示名时优先用它（项目详情只带 workspace_id，不带名称）。 */
function _wsSyncNameFor(wsId, fallback) {
  if (fallback) return String(fallback);
  var ids = ["ws-switcher", "ws-bar-select"];
  for (var i = 0; i < ids.length; i++) {
    var sel = document.getElementById(ids[i]);
    if (!sel) continue;
    for (var j = 0; j < sel.options.length; j++) {
      if (String(sel.options[j].value) === String(wsId)) {
        return String(sel.options[j].textContent || wsId);
      }
    }
  }
  return String(wsId);
}

async function wsSyncForProject(caseObj) {
  try {
    // 空间选择器只在业务端可见；平台角色不做切换，避免无谓写库。
    if (currentRole === "super_admin" || currentRole === "platform_op") return false;
    var c = caseObj || {};
    var wsId = String(c.workspace_id || c.space_id || "");
    if (!wsId) return false;                        // 旧接口无空间字段：保持现状
    var cur = "";
    var sel = document.getElementById("ws-switcher");
    if (sel && sel.value) cur = String(sel.value);
    if (!cur) {
      try {
        var ur = await (await fetch("/api/v1/workspaces", {credentials: "same-origin"})).json();
        __wsSyncCache = (ur && ur.current) || null;
        cur = String((__wsSyncCache || {}).id || "");
      } catch (e) { cur = ""; }
    }
    if (cur && cur === wsId) return false;          // 已一致：不产生额外请求
    var res = {};
    try {
      res = await (await fetch("/api/v1/workspaces/switch", {
        method: "POST", headers: {"Content-Type": "application/json"},
        credentials: "same-origin", body: JSON.stringify({id: wsId}),
      })).json();
    } catch (e) { return false; }                   // 切换失败：保持现状，继续按后端判权打开
    if (!res || res.ok !== true || res.error) return false;
    __wsSyncCache = {id: wsId, name: String(c.workspace_name || "")};
    _wsSyncSelects(wsId, c.workspace_name || "");
    if (typeof showToast === "function") {
      showToast("已切换到项目所属空间：" + _wsSyncNameFor(wsId, c.workspace_name));
    }
    return true;
  } catch (e) { return false; }                     // 任何异常都不打断项目打开
}

/* ===== 平台层控制台：租户开通/停用/用量 ===== */
/* ===== 空间管理（P3）：配置落 settings_json 并在审核时生效 ===== */
let wsListPage = 1;
const WS_PAGE_SIZE = 20;

async function renderWsSettings() {
  var host = document.querySelector('#view-wssettings #wssettings');
  if (!host) return;
  host.innerHTML = '<div class="muted">加载中…</div>';
  var wr = await (await fetch('/api/v1/workspaces')).json();
  var spaces = wr.items || [];
  const _wsCanEdit = currentRole !== "reviewer";
  var pages = Math.max(1, Math.ceil(spaces.length / WS_PAGE_SIZE));
  if (wsListPage > pages) wsListPage = pages;
  var begin = (wsListPage - 1) * WS_PAGE_SIZE;
  var pageRows = spaces.slice(begin, begin + WS_PAGE_SIZE);
  var rows = pageRows.map(function (w, i) {
    return '<tr>' +
      '<td class="muted">' + (begin + i + 1) + '</td>' +
      '<td><b>' + esc(w.name || '') + '</b>' + (w.current ? ' <span class="pill published">当前</span>' : '') + '</td>' +
      '<td class="muted">' + esc((w.doc_types || []).join('、') || '—') + '</td>' +
      '<td>' + esc(w.creator_name || '—') + '</td>' +
      '<td class="muted">' + esc((w.created_at || '').slice(0, 16) || '—') + '</td>' +
      '<td class="actions-cell"><div class="actions"><button class="btn" data-ws-view="' + esc(w.id) + '">' + (_wsCanEdit ? '查看详情' : '查看') + '</button></div></td></tr>';
  }).join('');
  var pager = '<div class="pager"><span class="pager-total">共 ' + spaces.length + ' 个空间 · 第 ' + wsListPage + '/' + pages + ' 页 · 每页 ' + WS_PAGE_SIZE + ' 行</span><div class="pager-actions">' +
    '<button data-ws-page="' + (wsListPage - 1) + '"' + (wsListPage <= 1 ? ' disabled' : '') + '>上一页</button>' +
    Array.from({length: pages}, function (_, i) { return i + 1; }).slice(Math.max(0, wsListPage - 3), Math.max(0, wsListPage - 3) + 5).map(function (n) {
      return '<button class="' + (n === wsListPage ? 'on' : '') + '" data-ws-page="' + n + '">' + n + '</button>';
    }).join('') +
    '<button data-ws-page="' + (wsListPage + 1) + '"' + (wsListPage >= pages ? ' disabled' : '') + '>下一页</button></div></div>';
  host.innerHTML = '<div class="page-head"><div><h2>空间列表</h2><p class="page-desc">工作空间按租户隔离，只约束规则引擎和文件类型范围；项目列表与首页不按空间切分。</p></div>' +
    '<div class="ph-right">' + (_wsCanEdit ? '<button class="btn primary" id="ws-list-create">新建空间</button>' : '') + '</div></div>' +
    '<div class="card"><div class="table-wrap"><table class="table"><thead><tr>' +
    '<th style="width:62px">序号</th><th>空间名称</th><th>主文件类型</th><th>创建人</th><th>创建时间</th><th class="actions-cell" style="width:110px">操作</th>' +
    '</tr></thead><tbody>' + (rows || '<tr><td colspan="6" class="empty">暂无空间</td></tr>') + '</tbody></table></div>' + pager + '</div>';
  document.querySelector('#ws-list-create')?.addEventListener('click', function () { openWsCreateModal(); });
  document.querySelectorAll('[data-ws-view]').forEach(function (b) {
    b.onclick = function () { openWsDetail(b.dataset.wsView); };
  });
  document.querySelectorAll('[data-ws-page]').forEach(function (b) {
    b.onclick = function () {
      var n = Number(b.dataset.wsPage || 1);
      if (n < 1 || n > pages) return;
      wsListPage = n; renderWsSettings();
    };
  });
}

/* 非当前空间点位：空间详情可查看任意空间，但点位确认始终写当前空间上下文。
   在错误的空间里点“管理点位确认/一键确认推荐点位”必须显式拦截，不能静默写错空间。 */
function showPointScopeDialog(targetWs, currentWs) {
  var old = document.querySelector('#point-scope-modal'); if (old) old.remove();
  var t = targetWs || {}, c = currentWs || {};
  var targetName = t.name || t.id || '目标空间';
  var currentName = c.name || c.id || '当前空间';
  var mask = document.createElement('div');
  mask.id = 'point-scope-modal';
  mask.className = 'ws-mask';
  mask.dataset.targetWs = t.id || '';
  mask.dataset.currentWs = c.id || '';
  mask.innerHTML = '<div class="ws-dialog" role="dialog" aria-modal="true" aria-labelledby="point-scope-title">' +
    '<div class="ws-dialog-head"><div><h3 id="point-scope-title">非当前空间点位</h3><div class="muted" style="font-size:11px;margin-top:3px">点位确认按工作空间隔离 · 当前空间：' + esc(currentName) + '</div></div><button type="button" class="ws-close" aria-label="关闭">×</button></div>' +
    '<div class="ws-detail-scroll"><div id="point-scope-msg" style="padding:10px 12px;border:1px solid #FCA5A5;background:#FEF2F2;color:#B91C1C;font-size:12px;line-height:1.7;border-radius:4px">' +
    '「' + esc(targetName) + '」不是当前工作空间（当前：' + esc(currentName) + '）。点位确认只能作用于当前空间，本次未提交任何确认。请先切换到「' + esc(targetName) + '」，再逐点复核。' +
    '</div><div class="muted" style="font-size:11px;line-height:1.7;margin-top:10px">不会读取或修改其他空间的点位确认；切换后本页会重新加载。</div>' +
    '<div class="ws-msg" id="point-scope-error"></div></div>' +
    '<div class="ws-dialog-actions"><button type="button" class="btn ws-close">取消</button>' +
    '<button type="button" class="btn primary" id="point-scope-switch"' + (t.id ? '' : ' disabled') + '>切换到「' + esc(targetName) + '」</button></div></div>';
  document.body.appendChild(mask);
  var close = function () { mask.remove(); };
  mask.querySelectorAll('.ws-close').forEach(function (b) { b.onclick = close; });
  mask.onclick = function (e) { if (e.target === mask) close(); };
  var btn = mask.querySelector('#point-scope-switch');
  if (btn && t.id) {
    btn.onclick = async function () {
      var err = mask.querySelector('#point-scope-error');
      btn.disabled = true; btn.textContent = '切换中…';
      try {
        var r = await (await fetch('/api/v1/workspaces/switch', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: t.id})})).json();
        if (r.error || r.ok === false) throw new Error(r.error || '切换空间失败');
        sessionStorage.setItem('rp_after_switch', 'wssettings');
        location.reload();
      } catch (e) {
        if (err) { err.style.color = '#B91C1C'; err.textContent = e.message || '切换空间失败'; }
        btn.disabled = false; btn.textContent = '切换到「' + targetName + '」';
      }
    };
  }
}

async function openPointConfirmDialog() {
  var wsId = arguments[0], wsName = arguments[1], currentWs = arguments[2];
  var old = document.querySelector('#point-confirm-modal'); if (old) old.remove();
  if (!currentWs) {
    try { currentWs = ((await (await fetch('/api/v1/workspaces')).json()).current) || {}; }
    catch (e) { currentWs = {}; }
  }
  if (wsId && currentWs && currentWs.id && String(wsId) !== String(currentWs.id)) {
    showPointScopeDialog({id: String(wsId), name: wsName || String(wsId)}, currentWs);
    return;
  }
  var cr = await (await fetch('/api/v1/audit-points/confirmations')).json();
  var op = await (await fetch('/api/v1/audit-points/options')).json();
  var confirmed = new Set((cr.confirmed || []).filter(function (x) { return x.valid !== false; }).map(function (x) { return x.point_id; }));
  var pendingSet = new Set((cr.pending_review || []).map(function (x) { return x.point_id; }));
  var staleSet = new Set((cr.stale || []).map(function (x) { return x.point_id; }));
  var criterionMap = {};
  (cr.confirmed || []).concat(cr.pending_review || []).forEach(function (x) { criterionMap[x.point_id] = x.criterion || ''; });
  var staleCount = (cr.stale || []).length;
  var PC_CRIT_MAX = 500; // 逐点判据长度上限：超过即在前端拦截，避免静默截断
  var PC_STATUS_ORDER = { pending: 0, stale: 1, confirmed: 2, draft: 3 }; // 待复核默认置顶
  var PC_STATUS_LABEL = { pending: '待复核', stale: '已失效', confirmed: '已确认', draft: '未确认' };
  var items = (op.items || []).map(function (x) {
    var _st = staleSet.has(x.id) ? 'stale' : (pendingSet.has(x.id) ? 'pending' : (confirmed.has(x.id) ? 'confirmed' : 'draft'));
    return { id: x.id, name: x.name || x.id || '', category: x.category, status: _st };
  });
  // 待复核项默认排序在前；筛选只隐藏行，不改变默认顺序。
  items.sort(function (a, b) {
    var _d = PC_STATUS_ORDER[a.status] - PC_STATUS_ORDER[b.status];
    return _d || String(a.name || a.id).localeCompare(String(b.name || b.id));
  });
  var pendingCount = items.filter(function (x) { return x.status === 'pending'; }).length;
  var cats = [];
  items.forEach(function (x) { var c = String(x.category || '未分类'); if (cats.indexOf(c) < 0) cats.push(c); });
  var mask = document.createElement('div');
  mask.id = 'point-confirm-modal'; mask.className = 'ws-mask';
  mask.innerHTML = '<div class="ws-dialog ws-detail-dialog" role="dialog" aria-modal="true">' +
    '<div class="ws-dialog-head"><div><h3>点位模板确认</h3><div class="muted" style="font-size:11px;margin-top:3px">' +
    '当前空间：' + esc(op.workspace || '') + ' · 只显示本空间文件类型匹配的点位 · 共 ' + items.length + ' 个' +
    (pendingCount ? ' · <b style="color:#B45309">待复核 ' + pendingCount + ' 个已置顶</b>' : '') +
    (staleCount ? ' · <b style="color:#B91C1C">' + staleCount + ' 条确认因点位库变更失效</b>' : '') + '</div></div>' +
    '<button type="button" class="ws-close" aria-label="关闭">×</button></div>' +
    '<div class="ws-detail-scroll"><div class="muted" style="margin-bottom:8px">勾选 = 已确认，可作为正式审核依据；未勾选 = 仅模板。待复核项默认排在最前；保存只作用于当前筛选。</div>' +
    (staleCount ? '<div id="pc-stale-banner" style="margin-bottom:8px;padding:6px 8px;border:1px solid #FCA5A5;background:#FEF2F2;color:#B91C1C;font-size:11px;border-radius:4px">有 ' + staleCount + ' 条确认因点位库或判据变更失效：请先更新点位库，再重新打开本窗口逐点确认；失效项禁止直接确认。</div>' : '') +
    '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">' +
    '<input id="pc-search" class="field" style="flex:1;min-width:150px" placeholder="搜索点位名称/ID">' +
    '<select id="pc-cat" class="field" style="width:150px"><option value="">全部分类</option>' +
    cats.map(function (c) { return '<option value="' + esc(c) + '">' + esc(c) + '</option>'; }).join('') + '</select>' +
    '<select id="pc-status" class="field" style="width:170px"><option value="">全部状态（待复核优先）</option><option value="pending">待复核</option><option value="confirmed">已确认</option><option value="stale">已失效</option></select>' +
    '<button type="button" class="btn" id="pc-selall">全选当前筛选</button>' +
    '<button type="button" class="btn" id="pc-clear">取消当前筛选</button></div>' +
    '<div class="muted" id="pc-count" style="margin-bottom:6px"></div>' +
    '<div id="pc-list" style="max-height:380px;overflow:auto">' + (items.length ? items.map(function (x) {
      var _st = x.status, _stale = _st === 'stale';
      var _badge = _st === 'pending' ? ' · <b style="color:#B45309">' + PC_STATUS_LABEL.pending + '</b>' : (_st === 'stale' ? ' · <b style="color:#B91C1C">' + PC_STATUS_LABEL.stale + '</b>' : '');
      var _checked = confirmed.has(x.id) && !_stale;
      return '<div class="pc-row" data-rid="' + esc(x.id) + '" data-cat="' + esc(String(x.category || '未分类')) + '" data-status="' + _st + '" data-priority="' + PC_STATUS_ORDER[_st] + '" data-stale="' + (_stale ? '1' : '0') + '" data-text="' + esc((x.name || '') + ' ' + (x.id || '') + ' ' + (x.category || '')) + '" style="padding:7px 2px;border-bottom:1px solid #eee">' +
        '<label style="display:flex;gap:8px;align-items:flex-start"><input type="checkbox" data-pid="' + esc(x.id) + '"' + (_checked ? ' checked' : '') + (_stale ? ' disabled title="已失效，需先更新点位库"' : '') + '>' +
        '<span><b>' + esc(x.name || x.id) + '</b><small class="muted"> ' + esc(x.id || '') + ' · ' + esc(x.category || '') + _badge + '</small></span></label>' +
        (_stale ? '<div class="pc-stale-hint" data-stale-hint="' + esc(x.id) + '" style="margin-left:22px;color:#B91C1C;font-size:11px;margin-top:3px;cursor:pointer">该确认已失效：请先更新点位库后重新确认；失效项禁止确认。</div>' : '') +
        '<div class="pc-row-err" data-pc-err="' + esc(x.id) + '" style="display:none;margin-left:22px;color:#B91C1C;font-size:11px;margin-top:3px"></div>' +
        '<details style="margin-left:22px;margin-top:3px"><summary class="muted" style="font-size:11px;cursor:pointer">逐点复核判据/备注</summary>' +
        '<textarea data-crit="' + esc(x.id) + '" class="field" style="width:100%;min-height:44px;margin-top:4px"' + (_stale ? ' readonly title="已失效：请先更新点位库后重新确认"' : '') + ' placeholder="该点位的复核判据、证据要求或例外；留空则按模板批量确认">' + esc(criterionMap[x.id] || '') + '</textarea>' +
        '<div style="display:flex;justify-content:space-between;gap:8px;margin-top:2px"><span class="muted pc-crit-hint" data-crit-hint="' + esc(x.id) + '" style="font-size:11px">留空 = 按模板批量确认</span><span class="muted pc-crit-count" data-crit-count="' + esc(x.id) + '" style="font-size:11px;white-space:nowrap">0/' + PC_CRIT_MAX + '</span></div></details></div>';
    }).join('') : '<div class="muted">当前空间没有可用点位；请先在空间详情选择文件类型。</div>') + '</div></div>' +
    '<div class="ws-dialog-actions"><button type="button" class="btn ws-close">取消</button>' +
    '<button type="button" class="btn primary" id="pc-save">保存确认</button></div>' +
    '<div class="ws-msg" id="pc-msg"></div></div>';
  document.body.appendChild(mask);
  var close = function () { mask.remove(); };
  mask.querySelectorAll('.ws-close').forEach(function (b) { b.onclick = close; });
  mask.onclick = function (e) { if (e.target === mask) close(); };
  var list = mask.querySelector('#pc-list'), search = mask.querySelector('#pc-search'), cat = mask.querySelector('#pc-cat'), stSel = mask.querySelector('#pc-status');
  var msg = mask.querySelector('#pc-msg');
  function setMsg(text, kind) {
    msg.textContent = text || '';
    msg.style.color = kind === 'ok' ? '#0F7B4F' : (kind === 'warn' ? '#B45309' : (kind === 'err' ? '#B91C1C' : ''));
  }
  function findRow(pid) {
    var found = null;
    [...list.querySelectorAll('.pc-row')].some(function (r) { if (r.dataset.rid === pid) { found = r; return true; } return false; });
    return found;
  }
  function setRowError(pid, text) {
    var row = findRow(pid); if (!row) return;
    var el = row.querySelector('[data-pc-err]');
    if (el) { el.textContent = text || ''; el.style.display = text ? '' : 'none'; }
    row.classList.toggle('pc-row-err', !!text);
    row.style.background = text ? '#FEF2F2' : '';
    if (text) { var d = row.querySelector('details'); if (d) d.open = true; }
  }
  function criterionError(text) {
    var raw = String(text == null ? '' : text);
    var val = raw.trim();
    if (raw && !val) return '判据不能为空或只包含空白字符';
    if (val.length > PC_CRIT_MAX) return '判据最多 ' + PC_CRIT_MAX + ' 字，当前 ' + val.length + ' 字';
    return '';
  }
  function syncRowCrit(row) {
    var t = row.querySelector('textarea[data-crit]'); if (!t) return '';
    var pid = row.dataset.rid, val = String(t.value || '').trim(), err = criterionError(t.value);
    var hint = row.querySelector('[data-crit-hint]'), cnt = row.querySelector('[data-crit-count]');
    if (cnt) { cnt.textContent = val.length + '/' + PC_CRIT_MAX; cnt.style.color = err ? '#B91C1C' : ''; }
    if (hint) { hint.textContent = err || (val ? '将按逐点判据确认' : '留空 = 按模板批量确认'); hint.style.color = err ? '#B91C1C' : ''; }
    setRowError(pid, err);
    return err;
  }
  function visibleRows() {
    var q = (search.value || '').trim().toLowerCase(), c = cat.value || '', st = stSel.value || '';
    var rows = [...list.querySelectorAll('.pc-row')];
    rows.forEach(function (r) {
      var ok = (!q || (r.dataset.text || '').toLowerCase().indexOf(q) >= 0) && (!c || r.dataset.cat === c) && (!st || r.dataset.status === st);
      r.style.display = ok ? '' : 'none';
    });
    return rows.filter(function (r) { return r.style.display !== 'none'; });
  }
  function syncCount() {
    var boxes = [...list.querySelectorAll('input[data-pid]')];
    var checked = boxes.filter(function (b) { return b.checked; }).length;
    var vis = visibleRows();
    var visChecked = vis.filter(function (r) { var b = r.querySelector('input[data-pid]'); return b && b.checked; }).length;
    mask.querySelector('#pc-count').textContent = '当前筛选 ' + vis.length + ' 个 · 筛选内已勾选 ' + visChecked + ' · 全部已勾选 ' + checked + ' / ' + boxes.length + ' · 保存只作用于当前筛选';
  }
  list.addEventListener('change', function (e) {
    var t = e.target;
    if (t && t.matches && t.matches('textarea[data-crit]')) { var r = t.closest('.pc-row'); if (r) syncRowCrit(r); }
    syncCount();
  });
  list.addEventListener('input', function (e) {
    var t = e.target;
    if (t && t.matches && t.matches('textarea[data-crit]')) { var r = t.closest('.pc-row'); if (r) syncRowCrit(r); }
  });
  search.addEventListener('input', syncCount);
  cat.addEventListener('change', syncCount);
  stSel.addEventListener('change', syncCount);
  [...list.querySelectorAll('textarea[data-crit]')].forEach(function (t) { var r = t.closest('.pc-row'); if (r) syncRowCrit(r); });
  [...list.querySelectorAll('[data-stale-hint]')].forEach(function (el) {
    el.onclick = function () {
      var row = el.closest('.pc-row'), nm = row ? ((row.querySelector('b') || {}).textContent || row.dataset.rid) : '';
      setMsg('「' + nm + '」的确认已因点位库或判据变更失效：请先更新点位库，再重新打开本窗口确认；失效项禁止直接确认。', 'warn');
    };
  });
  mask.querySelector('#pc-selall').onclick = function () {
    visibleRows().forEach(function (r) { var b = r.querySelector('input[data-pid]'); if (b && !b.disabled) b.checked = true; }); syncCount();
  };
  mask.querySelector('#pc-clear').onclick = function () {
    visibleRows().forEach(function (r) { var b = r.querySelector('input[data-pid]'); if (b && !b.disabled) b.checked = false; }); syncCount();
  };
  syncCount();
  mask.querySelector('#pc-save').onclick = async function () {
    var btn = this;
    btn.disabled = true; btn.textContent = '保存中…'; setMsg('');
    try {
      var allRows = [...list.querySelectorAll('.pc-row')];
      var rows = visibleRows(); // 保存只作用于当前筛选
      var visibleSet = new Set(rows.map(function (r) { return r.dataset.rid; }));
      var actionable = rows.filter(function (r) { return r.dataset.stale !== '1'; }); // stale 禁止确认
      var staleSkipped = rows.length - actionable.length;
      var hiddenDirty = allRows.filter(function (r) {
        if (visibleSet.has(r.dataset.rid) || r.dataset.stale === '1') return false;
        var b = r.querySelector('input[data-pid]');
        if (!b || b.disabled) return false;
        var pid = r.dataset.rid;
        if (b.checked !== confirmed.has(pid)) return true;
        // 已确认点位改判据同样属于未保存改动，不能在切换筛选后静默丢弃。
        if (!b.checked) return false;
        var t = r.querySelector('textarea[data-crit]');
        var crit = (t && t.value || '').trim();
        return crit !== String(criterionMap[pid] || '').trim();
      });
      if (hiddenDirty.length && !confirm('当前筛选外还有 ' + hiddenDirty.length + ' 个未保存改动。批量确认只作用于当前筛选，这些改动不会保存；继续保存当前筛选？')) {
        setMsg('已取消保存：请先切换筛选处理筛选外的改动。', 'warn'); return;
      }
      var invalid = [], crits = {};
      actionable.forEach(function (row) {
        var t = row.querySelector('textarea[data-crit]');
        var b = row.querySelector('input[data-pid]');
        var pid = row.dataset.rid;
        crits[pid] = (t && t.value || '').trim();
        if (!b) return;
        if (b.checked) { if (syncRowCrit(row)) invalid.push(pid); } // 只校验会被提交的勾选行
        else { setRowError(pid, ''); }
      });
      if (invalid.length) {
        setMsg('有 ' + invalid.length + ' 个点位判据不合法，请按逐点提示修正后再保存。', 'err'); return;
      }
      var addPer = [], addBulk = [], del = [], failed = [], added = 0, critUpdated = 0;
      actionable.forEach(function (row) {
        var b = row.querySelector('input[data-pid]'); if (!b) return;
        var pid = row.dataset.rid, has = confirmed.has(pid), crit = crits[pid] || '';
        var oldCrit = String(criterionMap[pid] || '').trim();
        if (b.checked) {
          if (!has) {
            if (crit) { addPer.push({ pid: pid, criterion: crit }); added++; }
            else addBulk.push(pid);
          } else if (crit !== oldCrit) {
            // 已确认点位改判据必须重新提交，否则界面显示与后端事实不一致。
            addPer.push({ pid: pid, criterion: crit }); critUpdated++;
          }
        } else if (has) del.push(pid);
      });
      // 逐点确认：单条失败只标该点，不中断其余点位
      for (var i = 0; i < addPer.length; i++) {
        var it = addPer[i];
        try {
          var rp = await (await fetch('/api/v1/audit-points/confirm', {method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({point_id: it.pid, criterion: it.criterion})})).json();
          if (rp.error || rp.ok === false) throw new Error(rp.error || '确认失败');
          confirmed.add(it.pid); criterionMap[it.pid] = it.criterion;
        } catch (e) {
          failed.push(it.pid); setRowError(it.pid, '保存失败：' + (e.message || '网络错误'));
        }
      }
      if (addBulk.length) {
        try {
          var rb = await (await fetch('/api/v1/audit-points/confirm', {method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({point_ids: addBulk})})).json();
          if (rb.error || rb.ok === false) throw new Error(rb.error || '确认失败');
          addBulk.forEach(function (pid) { confirmed.add(pid); });
        } catch (e) {
          addBulk.forEach(function (pid) { failed.push(pid); setRowError(pid, '批量确认失败：' + (e.message || '网络错误')); });
        }
      }
      if (del.length) {
        try {
          var rd = await (await fetch('/api/v1/audit-points/confirm', {method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({point_ids: del, revoke: true})})).json();
          if (rd.error || rd.ok === false) throw new Error(rd.error || '取消确认失败');
          del.forEach(function (pid) { confirmed.delete(pid); });
        } catch (e) {
          del.forEach(function (pid) { failed.push(pid); setRowError(pid, '取消确认失败：' + (e.message || '网络错误')); });
        }
      }
      if (failed.length) {
        setMsg('保存完成，但有 ' + failed.length + ' 个点位失败（见逐点红色提示）；成功项已保存，可修正后重试。', 'err');
      } else {
        var _txt = '已保存：逐点确认 ' + added + '，批量 ' + addBulk.length + '，撤销 ' + del.length + '；下一次审核生效';
        if (critUpdated) _txt = '已保存：逐点确认 ' + added + '，批量 ' + addBulk.length + '，撤销 ' + del.length + '，更新判据 ' + critUpdated + '；下一次审核生效';
        if (staleSkipped) _txt += '；已跳过 ' + staleSkipped + ' 个失效点位（需先更新点位库）';
        if (hiddenDirty.length) { setMsg(_txt + '；筛选外 ' + hiddenDirty.length + ' 个改动未提交。', 'warn'); }
        else { setMsg(_txt, 'ok'); setTimeout(close, 900); }
      }
    } catch (e) { setMsg('保存失败：' + (e.message || '网络错误'), 'err'); }
    finally { btn.disabled = false; btn.textContent = '保存确认'; }
  };
}

async function openWsDetail(wsId) {
  var old = document.querySelector('#ws-detail-modal'); if (old) old.remove();
  var r = await (await fetch('/api/v1/workspaces/settings?id=' + encodeURIComponent(wsId))).json();
  const _af = apiFail(r);
  if (_af) { showToast(_af, 'err'); return; }
  var currentWs = {};
  try { currentWs = ((await (await fetch('/api/v1/workspaces')).json()).current) || {}; } catch (e) {}
  var ws = r.workspace || {}, st = r.settings || {}, mods = r.modules || {};
  var mask = document.createElement('div');
  mask.id = 'ws-detail-modal';
  mask.className = 'ws-mask';
  mask.innerHTML = '<div class="ws-dialog ws-detail-dialog" role="dialog" aria-modal="true">' +
    '<div class="ws-dialog-head"><div><h3>空间详情</h3><div class="muted" style="font-size:11px;margin-top:3px">' + esc(ws.name || '') + ' · 创建人 ' + esc(ws.creator_name || ws.created_by || '—') + ' · ' + esc((ws.created_at || '').slice(0, 16) || '—') + '</div></div><button type="button" class="ws-close" aria-label="关闭">×</button></div>' +
    '<div class="ws-detail-scroll">' +
    '<label class="ws-label">空间名称<input id="wd-name" class="field" value="' + esc(ws.name || '') + '" maxlength="40" placeholder="例如：华东客户审核"></label>' +
    '<label class="ws-label">主文件类型（1–5 个）</label><div id="wd-doc-box"></div>' +
    '<label class="ws-label">补充审核点位<select id="wd-supp" class="field"><option value="0">不补充（默认客户规则）</option><option value="1"' + (st.point_supplement ? ' selected' : '') + '>补充平台点位</option></select><div class="ws-field-hint">默认只用客户规则；需要平台补充审核点位时再打开。新增规则默认对本空间全部主文件类型生效。</div></label>' +
    '<label class="ws-label" style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="wd-pc"' + (st.point_confirm_required ? ' checked' : '') + '> 平台点位必须先确认才执行</label><div class="ws-field-hint">开启后，未确认的 302 模板点位不进入执行；历史空间默认关闭，新建空间默认开启。</div>' +
    '<div style="margin:6px 0 12px;display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="btn" id="wd-manage-points">管理点位确认</button><button type="button" class="btn" id="wd-recommend-points">一键确认推荐点位</button><button type="button" class="btn" id="wd-migrate-points">生成待确认（旧空间迁移）</button><button type="button" class="btn" id="wd-activate-points">启用点位门禁</button></div>' +
    '<div class="ws-msg" id="wd-msg"></div>' +
    '</div><div class="ws-dialog-actions"><button type="button" class="btn ws-close">取消</button><button type="button" class="btn primary" id="wd-save">保存空间配置</button></div></div>';
  document.body.appendChild(mask);
  var close = function () { mask.remove(); };
  mask.querySelectorAll('.ws-close').forEach(function (b) { b.onclick = close; });
  mask.onclick = function (e) { if (e.target === mask) close(); };
  var _wdSaveBtn = document.querySelector('#wd-save');
  mountDocTypePicker('wd-doc-box', st.doc_types || [], {
    onChange: function (state) {
      if (!_wdSaveBtn) return;
      var blocked = !!(state.selected.length && state.verdict && !state.verdict.compatible);
      _wdSaveBtn.disabled = blocked;
      _wdSaveBtn.title = blocked ? (state.verdict.reason || '所选文件类型不适合同一批规则库') : '';
      var m = document.querySelector('#wd-msg');
      if (!m) return;
      if (blocked) {
        m.style.color = '#B91C1C';
        m.textContent = state.verdict.reason + (state.verdict.suggestion ? ' ' + state.verdict.suggestion : '');
      } else if (m.textContent && m.style.color === 'rgb(185, 28, 28)') {
        m.textContent = ''; m.style.color = '';
      }
    }
  });
  var _pcBtn = document.querySelector('#wd-manage-points');
  if (_pcBtn) _pcBtn.onclick = function () { openPointConfirmDialog(ws.id, ws.name, currentWs); };
  var _migBtn = document.querySelector('#wd-migrate-points');
  if (_migBtn) _migBtn.onclick = async function () {
    if (!confirm('按当前空间文件类型生成待确认点位？不会自动确认，也不改变当前执行。')) return;
    var msg = document.querySelector('#wd-msg'); _migBtn.disabled = true;
    try {
      var r = await (await fetch('/api/v1/audit-points/prepare-migration', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({workspace_id:ws.id})})).json();
      if (r.error || r.ok === false) throw new Error(r.error || '迁移失败');
      msg.style.color = '#0F7B4F'; msg.textContent = '已生成待确认 ' + (r.pending_created || 0) + ' 个；请逐点复核后再启用门禁。';
    } catch (e) { msg.style.color = '#B91C1C'; msg.textContent = e.message; }
    finally { _migBtn.disabled = false; }
  };
  var _actBtn = document.querySelector('#wd-activate-points');
  if (_actBtn) _actBtn.onclick = async function () {
    if (!confirm('启用后未确认点位将不再执行；确认已复核待确认点位？')) return;
    var msg = document.querySelector('#wd-msg'); _actBtn.disabled = true;
    try {
      var r = await (await fetch('/api/v1/audit-points/activate-confirm', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({workspace_id:ws.id})})).json();
      if (r.error || r.ok === false) throw new Error(r.error || '启用失败');
      msg.style.color = '#0F7B4F'; msg.textContent = '已启用点位门禁：待复核 ' + (r.pending_review || 0) + '，已确认 ' + (r.confirmed || 0) + '。';
    } catch (e) { msg.style.color = '#B91C1C'; msg.textContent = e.message; }
    finally { _actBtn.disabled = false; }
  };
  var _recBtn = document.querySelector('#wd-recommend-points');
  if (_recBtn) _recBtn.onclick = async function () {
    if (currentWs.id && String(ws.id) !== String(currentWs.id)) { showPointScopeDialog(ws, currentWs); return; }
    if (!confirm('按当前空间文件类型推荐点位并全部确认？')) return;
    var msg = document.querySelector('#wd-msg');
    _recBtn.disabled = true; _recBtn.textContent = '确认中…';
    try {
      var r = await (await fetch('/api/v1/audit-points/confirm-recommended', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'})).json();
      if (r.error || r.ok === false) throw new Error(r.error || '没有可推荐点位');
      msg.style.color = '#0F7B4F'; msg.textContent = '已确认推荐点位 ' + (r.recommended || 0) + ' 个；下一次审核生效';
    } catch (e) { msg.style.color = '#B91C1C'; msg.textContent = e.message; }
    finally { _recBtn.disabled = false; _recBtn.textContent = '一键确认推荐点位'; }
  };
  if (currentRole === "reviewer") {
    mask.querySelectorAll("input,select,button").forEach(function (el) {
      if (!el.matches(".ws-close,[data-ws-close]")) el.disabled = true;
    });
    const _sv = mask.querySelector("#wd-save"); if (_sv) _sv.style.display = "none";
  }
  document.querySelector('#wd-save').onclick = async function () {
    var btn = this, msg = document.querySelector('#wd-msg');
    var types = docPickerSelected('wd-doc-box');
    if (types.length < 1 || types.length > 5) { msg.textContent = '请选择 1~5 个主文件类型'; return; }
    var body = {id: ws.id, name: (document.querySelector('#wd-name')?.value || '').trim(),
      visibility: "tenant", members: [],
      doc_types: types, point_supplement: document.querySelector('#wd-supp').value === '1',
      point_confirm_required: !!document.querySelector('#wd-pc')?.checked};
    btn.disabled = true; btn.textContent = '保存中…'; msg.textContent = '';
    try {
      var res = await (await fetch('/api/v1/workspaces/settings/save', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)})).json();
      if (!res.ok) throw new Error(res.reason || res.error || '保存失败');
      msg.style.color = '#0F7B4F'; msg.textContent = '已保存，下一次审核生效';
      if (st.setup_required) {
        var gate = document.querySelector('#ws-setup-gate'); if (gate) gate.remove();
        setTimeout(function () { location.reload(); }, 400);
      } else {
        setTimeout(function () { close(); renderWsSettings(); }, 500);
      }
    } catch (e) { msg.style.color = '#B91C1C'; msg.textContent = e.message; }
    finally { btn.disabled = false; btn.textContent = '保存空间配置'; }
  };
}

async function ensureWorkspaceSetupGate() {
  if (currentRole !== "admin") return;
  if (document.querySelector("#ws-setup-gate")) return;
  try {
    var r = await (await fetch("/api/v1/workspaces", {credentials:"same-origin"})).json();
    var cur = (r && r.current) || {};
    if (!cur.id || !cur.setup_required) return;
    var mask = document.createElement("div");
    mask.id = "ws-setup-gate"; mask.className = "ws-mask";
    mask.innerHTML = '<div class="ws-dialog" role="dialog" aria-modal="true">' +
      '<div class="ws-dialog-head"><div><h3>先配置通用空间</h3><div class="muted" style="font-size:11px;margin-top:3px">新租户的通用空间默认不可用</div></div></div>' +
      '<div class="ws-setup-body"><p><b>当前通用空间还没有文件类型范围。</b>它不能直接建项目或审核，也不是“万能审核空间”。</p>' +
      '<p>请像正常空间一样编辑：修改名称（可选）、选择 1–5 个主文件类型并保存。保存后该空间才生效。</p>' +
      '<div class="ws-hint">通用空间只是新租户的初始占位；配置后就是普通空间，不拥有跨类型特权。</div></div>' +
      '<div class="ws-dialog-actions"><button type="button" class="btn primary" id="ws-setup-edit">立即配置通用空间</button></div></div>';
    document.body.appendChild(mask);
    document.querySelector("#ws-setup-edit").onclick = function () { openWsDetail(cur.id); };
  } catch (e) { /* 不影响主界面；后端仍有项目创建门禁 */ }
}

function openWsConfig() {
  fetch('/api/v1/workspaces').then(function (r) { return r.json(); }).then(function (r) {
    var cur = r.current || (r.items || [])[0] || {};
    if (cur.id) openWsDetail(cur.id); else showToast('当前没有可配置的空间', 'err');
  });
}


/* 本体：新增实例/别名/关系（业务管理员可维护；审核员只读） */
async function openOntoDialog(kind) {
  if (currentRole === "reviewer") { showToast("审核员只读本体，请联系业务管理员维护", "err"); return; }
  const d = await (await fetch("/api/v1/ontology")).json();
  // 保留 {key,name}：select 显示中文 name，value/保存仍用 key（接口/数据不变）。
  const types = (d.types || []).map(x => ({ key: String(x.key || x.name || ""), name: String(x.name || x.key || "") }))
    .filter(x => x.key);
  const _tl = ontoTypeLabels(types);
  const insts = d.instances || [];
  const old = document.querySelector("#onto-dialog"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "onto-dialog"; mask.className = "modal-mask";
  const typeOpts = types.map(t => `<option value="${esc(t.key)}">${esc(ontoTypeLabel(_tl, t.key))}</option>`).join("");
  let body = "";
  if (kind === "instance") {
    body = `<label class="np-field"><span>类型 *</span><select id="od-type" class="field">${typeOpts}</select></label>
      <label class="np-field wide"><span>实例名称 *</span><input id="od-name" class="field" placeholder="如：酱卤牛肉"></label>`;
  } else if (kind === "alias") {
    body = `<label class="np-field"><span>所属类型 *</span><select id="od-type" class="field">${typeOpts}</select></label>
      <label class="np-field"><span>归一到的实例 *</span><select id="od-entity" class="field"></select></label>
      <label class="np-field wide"><span>别名 *</span><input id="od-alias" class="field" placeholder="如：卤牛肉 / 合同总价"></label>
      <label class="np-field wide"><span>依据 *</span><input id="od-evidence" class="field" placeholder="填写原文、制度条款或术语来源；没有依据不能合并"></label>
      <div class="muted" style="font-size:11px;line-height:1.6;grid-column:1/-1">只允许同类型、同概念的别名；工艺单号≠工单号、半成品≠半成品清单、中心温度≠加热中心温度，除非有明确依据并人工确认。</div>`;
  } else {
    body = `<label class="np-field"><span>关系类型 *</span><select id="od-key" class="field"><option value="produced_by">produced_by · 半成品由工序生产</option><option value="measured_by">measured_by · 工序由指标度量</option></select></label>
      <label class="np-field"><span>起点 *</span><select id="od-source" class="field"></select></label>
      <label class="np-field"><span>终点 *</span><select id="od-target" class="field"></select></label>`;
  }
  mask.innerHTML = `<div class="modal" style="width:min(560px,calc(100vw - 32px))"><div class="settings-head"><div><h3>${kind === "instance" ? "新增实例" : kind === "alias" ? "新增别名" : "新增关系"}</h3><div class="muted" style="font-size:11px;margin-top:3px">保存后下一次审核取数生效；发布前建议先校验关系方向。</div></div><button class="ws-close" data-od-close>×</button></div><div class="ef-grid" style="margin-top:12px">${body}</div><div id="od-msg" class="muted" style="font-size:11px;margin-top:8px"></div><div class="actions" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-od-close>取消</button><button class="btn primary" id="od-save">保存</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove(); mask.querySelectorAll("[data-od-close]").forEach(b => b.onclick = close); mask.onclick = e => { if (e.target === mask) close(); };
  const typeSel = mask.querySelector("#od-type");
  const fillEntities = () => {
    const tk = typeSel?.value || "";
    const list = insts.filter(x => !tk || x.type_key === tk);
    const es = mask.querySelector("#od-entity"); if (es) es.innerHTML = list.map(x => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("") || '<option value="">该类型暂无实例</option>';
  };
  if (typeSel) { typeSel.onchange = fillEntities; fillEntities(); }
  const keySel = mask.querySelector("#od-key");
  const fillLink = () => {
    const k = keySel?.value || "produced_by";
    const srcType = k === "produced_by" ? "HalfProduct" : "ProcessStep";
    const dstType = k === "produced_by" ? "ProcessStep" : "Metric";
    const so = mask.querySelector("#od-source"), to = mask.querySelector("#od-target");
    if (so) so.innerHTML = insts.filter(x => x.type_key === srcType).map(x => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("") || '<option value="">暂无该类型实例</option>';
    if (to) to.innerHTML = insts.filter(x => x.type_key === dstType).map(x => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("") || '<option value="">暂无该类型实例</option>';
  };
  if (keySel) { keySel.onchange = fillLink; fillLink(); }
  mask.querySelector("#od-save").onclick = async () => {
    const msg = mask.querySelector("#od-msg"); msg.textContent = "保存中…";
    let url = "", payload = {};
    if (kind === "instance") {
      const name = (mask.querySelector("#od-name").value || "").trim(); if (!name) { msg.textContent = "请填写实例名称"; return; }
      payload = { type_key: typeSel.value, name };
      url = "/api/v1/ontology/entity";
    } else if (kind === "alias") {
      const alias = (mask.querySelector("#od-alias").value || "").trim(); if (!alias) { msg.textContent = "请填写别名"; return; }
      const evidence = (mask.querySelector("#od-evidence")?.value || "").trim(); if (!evidence) { msg.textContent = "请填写依据；没有依据不能合并概念"; return; }
      payload = { type_key: typeSel.value, entity_id: mask.querySelector("#od-entity").value, alias, evidence };
      url = "/api/v1/ontology/alias";
    } else {
      payload = { key: keySel.value, source_id: mask.querySelector("#od-source").value, target_id: mask.querySelector("#od-target").value };
      if (!payload.source_id || !payload.target_id) { msg.textContent = "起点或终点没有可用实例"; return; }
      url = "/api/v1/ontology/link";
    }
    const r = await (await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })).json();
    const _af = apiFail(r);
    if (_af) { msg.textContent = _af; return; }
    close(); showToast("已保存，下一次审核取数生效"); loadOntology();
  };
}
function ontoAddInstance() { openOntoDialog("instance"); }
function ontoAddAlias() { openOntoDialog("alias"); }
function ontoAddLink() { openOntoDialog("link"); }

document.querySelector("#onto-publish")?.addEventListener("click", async () => {
  if (currentRole === "reviewer") { showToast("审核员只读本体，发布需业务管理员", "err"); return; }
  if (!confirm("发布当前本体？发布后新审核使用新版本，已有项目不追溯。")) return;
  const r = await (await fetch("/api/v1/ontology/publish", { method: "POST" })).json();
  const _af = apiFail(r);
  if (_af) { showToast(_af, "err"); return; }
  showToast(r.version ? `本体已发布 v${r.version}` : "本体已发布"); loadOntology();
});
document.querySelector("#onto-add-inst")?.addEventListener("click", ontoAddInstance);
document.querySelector("#onto-add-alias")?.addEventListener("click", ontoAddAlias);
document.querySelector("#onto-add-link")?.addEventListener("click", ontoAddLink);
document.querySelector("#onto-refresh")?.addEventListener("click", () => { loadOntology(); showToast("本体已刷新"); });

/* 词典页在 DOM 末尾注入：index.html 直接加载 dict_view.js；旧入口由兜底加载补齐。 */
mountTermsView();
/* 项目列表在 projects_view.js；等它加载完再包 stale 徽标，不复制列表实现。 */
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", installProjectStaleBadge, { once: true });
} else {
  installProjectStaleBadge();
}


/* 兼容旧租户配置 URL：进入管理端内联页面，不再维护独立页面 */
function openTenantFromQuery() {
  try {
    var q = new URLSearchParams(location.search);
    if (q.get("open") !== "tenant") return;
    var tries = 0;
    (function attempt() {
      tries++;
      if (currentRole === "admin" || currentRole === "super_admin") {
        /* E-07 的 boot 兜底（loadUser 末尾 showView("home")）会把这里的兼容跳转覆盖回首页，
           使 /tenant-config 与 ?open=tenant 落到首页（用户看不到租户配置）。
           这里先标「用户已导航」，让 boot 兜底不再抢视图。 */
        _bootUserNavigated = true;
        if (window.showView) { showView("tenant"); return; }
        if (window.RPSettingsDrawers && window.RPSettingsDrawers.tenant) {
          window.RPSettingsDrawers.tenant(); return;
        }
      }
      if (tries < 20) setTimeout(attempt, 300);
    })();
  } catch (e) {}
}
openTenantFromQuery();

/* ===================== L84 E3：首页「系统概览」卡片（GET /api/v1/dashboard） =====================
   与 /api/v1/home 不混口径：/home 返回个人工作台 KPI；本卡片显示管理员全局 KPI
   （规则可执行版本 / 规则命中归因 / 冲突 / 复核 override 率），数据源明确写 /api/v1/dashboard。
   权限：服务端 _ADMIN_GET 仅 admin/super_admin；审核员 403。失败如实展示 HTTP，不展示任何假数字。
   空口径：override_rate 在 decided=0 时为 0.0（服务端定义），卡片标注“无已复核样本”而不是声称 0 误报。 */
async function renderHomeDashboardCard() {
  var home = document.getElementById("home");
  if (!home) return;
  var host = document.getElementById("home-sys-overview");
  if (!host) {
    host = document.createElement("div");
    host.id = "home-sys-overview";
    host.style.margin = "0 0 16px";
    var anchor = document.getElementById("home-stale-badge-host")
      || document.getElementById("home-kpis-extra")
      || document.getElementById("home-kpis");
    if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(host, anchor.nextSibling);
    else home.appendChild(host);
  }
  host.innerHTML = '<div class="card"><div class="card-title">系统概览（全局 KPI）</div>' +
    '<div class="muted" style="font-size:12px">读取 /api/v1/dashboard …</div></div>';
  var resp = null, d = null;
  try {
    resp = await fetch("/api/v1/dashboard", { credentials: "same-origin", cache: "no-store" });
    d = await resp.json();
  } catch (e) {
    host.innerHTML = '<div class="card"><div class="card-title">系统概览（全局 KPI）</div>' +
      '<div class="empty" style="padding:14px 0">读取失败：网络错误（' + esc((e && e.message) || e) + '）。不展示任何未经服务端返回的数字。</div></div>';
    return;
  }
  if (!resp.ok || !d || d.error) {
    host.innerHTML = '<div class="card"><div class="card-title">系统概览（全局 KPI）</div>' +
      '<div class="empty" style="padding:14px 0">读取失败（HTTP ' + esc(resp.status) + '）：' +
      esc((d && (d.error || d.message)) || "未知错误") + '。失败不会被当作 0 值。</div></div>';
    return;
  }
  var hits = d.rule_hits || {};
  var rc = d.rule_counts || {};
  var lib = rc.library_points || {};
  var num = function (v) { return v == null ? "—" : String(v); };
  var pct = function (v) { return v == null ? "—" : (Number(v) * 100).toFixed(1) + "%"; };
  var kpi = function (label, value, sub) {
    return '<div class="kpi"><b>' + esc(value) + '</b><span>' + esc(label) + '</span>' +
      (sub ? '<div class="k-hint">' + esc(sub) + '</div>' : '') + '</div>';
  };
  host.innerHTML = '<div class="card"><div class="card-title">系统概览（全局 KPI）' +
    '<span class="muted" style="font-size:11px;font-weight:400;margin-left:8px">数据源 /api/v1/dashboard · 本租户全部空间汇总</span></div>' +
    '<div class="kpis" style="display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin:10px 0">' +
      kpi("可执行规则版本", num(d.rules), "规则行 " + num(d.rules_total) + (rc.builtin_rules == null ? "" : " · 内置 " + rc.builtin_rules)) +
      kpi("项目", num(d.cases), "发现 " + num(d.findings)) +
      kpi("冲突（待处理口径）", num(d.conflicts), "冲突页同口径") +
      kpi("已复核 / 误报", num(d.decided) + " / " + num(d.false_positive), "override " + pct(d.override_rate) + (Number(d.decided || 0) ? "" : "（无已复核样本）")) +
      kpi("严重 / 一般发现", num(d.critical) + " / " + num(d.warning), "按 finding severity 统计") +
    '</div>' +
    '<div class="muted" style="font-size:11.5px;line-height:1.8">' +
      '规则命中归因：total ' + esc(num(hits.total)) + ' · attributed ' + esc(num(hits.attributed)) +
      ' · unattributed ' + esc(num(hits.unattributed)) + ' · attributed_rate ' + esc(pct(hits.attributed_rate)) +
      (lib.merged_points == null ? "" : ' ｜ 点位库：' + esc(String(lib.merged_points)) + ' 个点位 / ' +
        esc(String(lib.merged_audit_types == null ? "—" : lib.merged_audit_types)) + ' 类审核类型') +
      '。<b>口径提示</b>：override_rate 在无已复核样本时服务端记为 0.0，不等于“零误报”；' +
      '本卡不替代问题分析、复核和规则分析。' +
    '</div></div>';
}
