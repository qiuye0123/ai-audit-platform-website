/* 新建规则-制度文件拆解：从 app.js 拆出；依赖 app.js 的 esc/loadRules/loadRecentRules。 */
let decompCandidates = [];
/* L51 制度文件拆解打标：保存时给 POST /api/v1/rules/batch 带 tag_ids / tag_names，
 * 入库后展示 tagged（逐条打标数）/ tag_created（自动新建的分组）；失败不静默。 */
let intakeTags = { items: [], perms: { can_manage: false, can_assign: false }, loaded: false, loading: false, error: "" };
let intakeTagSel = { ids: [], newName: "" };
async function loadIntakeTags(force) {
  if (intakeTags.loading) return;
  if (intakeTags.loaded && !force) { renderIntakeTagPicker(); return; }
  intakeTags.loading = true;
  try {
    const resp = await fetch("/api/v1/rules/tags");
    let d = null;
    try { d = await resp.json(); } catch (e) { d = null; }
    if (!resp.ok || !d || d.ok === false || d.error) {
      intakeTags.error = (d && (d.error || d.message)) || ("读取分组失败（HTTP " + resp.status + "）");
      intakeTags.loaded = false;
    } else {
      intakeTags.items = Array.isArray(d.items) ? d.items : [];
      intakeTags.perms = Object.assign({ can_manage: false, can_assign: false }, d.perms || {});
      intakeTags.error = "";
      intakeTags.loaded = true;
    }
  } catch (e) {
    intakeTags.error = "网络错误，未能读取分组：" + ((e && e.message) || e);
    intakeTags.loaded = false;
  } finally {
    intakeTags.loading = false;
  }
  renderIntakeTagPicker();
}
function intakeTagPickerHTML() {
  const t = intakeTags;
  const canManage = !!(t.perms && t.perms.can_manage);
  if (t.loading && !(t.items || []).length && !t.error) {
    return `<div class="nr-tag-picker" id="nr-tag-picker"><div class="nr-tag-picker-head"><b>归属分组（可选）</b><span class="muted">正在读取分组…</span></div></div>`;
  }
  const opts = (t.items || []).map(x => {
    const rawId = String((x && x.id) || "");
    const id = esc(rawId);
    const name = esc(String((x && x.name) || ""));
    const color = /^#[0-9A-Fa-f]{6}$/.test(String((x && x.color) || "")) ? String(x.color) : "#B0B5BD";
    const on = intakeTagSel.ids.indexOf(rawId) >= 0;
    return `<button type="button" class="nr-tag-opt ${on ? "on" : ""}" data-intake-tag="${id}" title="归属分组：${name}"><i style="background:${color}"></i><span>${name}</span><b>${esc(String(Number((x && x.rule_count) || 0)))}</b></button>`;
  }).join("");
  const newInput = canManage
    ? `<label class="nr-tag-new">新建分组 <input id="nr-tag-new" class="field" maxlength="40" placeholder="输入新分组名称（可选，保存时创建）" value="${esc(intakeTagSel.newName || "")}"></label>`
    : `<span class="muted" style="font-size:11px">审核员只能使用已有分组；新建分组需业务管理员</span>`;
  const tagErr = t.error ? `<div class="rtb-err" style="margin-top:6px">分组读取失败：${esc(t.error)} <button type="button" class="btn" data-intake-tag-retry>重试</button></div>` : "";
  return `<div class="nr-tag-picker" id="nr-tag-picker">
    <div class="nr-tag-picker-head"><b>归属分组（可选）</b><span class="muted">保存后自动把本次入库规则加入所选分组；可多选；分组只用于组织/检索，不影响规则判定。</span></div>
    <div class="nr-tag-opts">${opts || `<span class="muted">当前空间还没有分组标签${canManage ? "，可在下方直接新建" : "，请联系业务管理员创建"}</span>`}</div>
    ${newInput}
    <div class="muted" id="nr-tag-hint" style="font-size:11px;margin-top:4px">${intakeTagSel.ids.length ? "已选 " + intakeTagSel.ids.length + " 个分组" : "未选择分组：本次入库的规则不会自动打标"}</div>
    ${tagErr}
  </div>`;
}
function bindIntakeTagPicker() {
  const host = $("#nr-tag-picker");
  if (!host) return;
  host.querySelectorAll("[data-intake-tag]").forEach(b => b.addEventListener("click", () => {
    const id = String(b.getAttribute("data-intake-tag") || "");
    const i = intakeTagSel.ids.indexOf(id);
    if (i >= 0) intakeTagSel.ids.splice(i, 1); else intakeTagSel.ids.push(id);
    renderIntakeTagPicker();
  }));
  const input = host.querySelector("#nr-tag-new");
  if (input) input.addEventListener("input", () => { intakeTagSel.newName = String(input.value || ""); });
  host.querySelectorAll("[data-intake-tag-retry]").forEach(b => b.addEventListener("click", () => loadIntakeTags(true)));
}
function renderIntakeTagPicker() {
  const box = $("#nr-cands");
  if (!box) return;
  const host = box.querySelector("#nr-tag-picker");
  if (!host) return;
  host.outerHTML = intakeTagPickerHTML();
  bindIntakeTagPicker();
}
/* T-185（KB 评审 P1-1）：导入/拆解路径的作用域自动推断。
 * 断点：候选入库后没有 applicable_types/applicable_when → 发布 400 scope_missing，
 * 且编辑器没有补齐入口 → 规则永远发布不了。这里按「当前空间文档类型 → 来源文件
 * 扩展名 → 原文适用范围语义」给出默认值，**入库前可见可改**，随 scope 一起提交；
 * 入库后仍可在草稿「继续编辑」修改（后端把推断来源一并落库，见 scope.scope_inferred）。 */
let decompScopeCtx = {};
let decompScopeDefault = { applicable_types: [], applicable_when: "", evidence_scope: ["document"] };
const NR_SCOPE_EXT = ["xlsx", "xls", "docx", "doc", "pdf", "txt", "csv"];
const NR_EVIDENCE_LABEL = { document: "整份文档", block: "区块", row: "行", sheet: "Sheet" };
function nrScopeTypesFromSuggestion(sug) {
  const t = (sug && sug.applicable_types) || [];
  return (Array.isArray(t) ? t : [t]).map((x) => String(x || "").trim()).filter(Boolean);
}
function renderScopeInferBar() {
  const box = $("#nr-scope-infer");
  if (!box) return;
  const ws = (decompScopeCtx && decompScopeCtx.workspace) || {};
  const wsTypes = Array.isArray(ws.doc_types) ? ws.doc_types.filter(Boolean) : [];
  const curTypes = decompScopeDefault.applicable_types || [];
  const curLow = new Set(curTypes.map((x) => String(x).toLowerCase().replace(/^\./, "")));
  const extHtml = NR_SCOPE_EXT.map((e) =>
    `<label class="nr-scope-opt"><input type="checkbox" data-scope-type value="${e}"${curLow.has(e) ? " checked" : ""}> ${e}</label>`).join("");
  const wsHtml = wsTypes.filter((t) => !curTypes.includes(t)).map((t) =>
    `<label class="nr-scope-opt"><input type="checkbox" data-scope-type value="${esc(t)}"> ${esc(t)}</label>`).join("");
  const ev = (decompScopeDefault.evidence_scope || ["document"])[0] || "document";
  const evHtml = Object.keys(NR_EVIDENCE_LABEL).map((k) =>
    `<option value="${k}"${k === ev ? " selected" : ""}>${NR_EVIDENCE_LABEL[k]}</option>`).join("");
  const _sugs = decompCandidates.map((x) => x.scope_suggestion || {});
  const _inferredN = _sugs.filter((x) => x.inferred && x.inferred.applied).length;
  box.innerHTML = `<div class="nr-scope-infer-head"><b>适用范围（已自动推断，请确认）</b>
      <span class="muted">推断来源：${esc((decompScopeDefault.inferred_reason) || "当前空间文档类型 / 来源文件类型 / 原文适用范围")}；入库后仍可在草稿「继续编辑」修改</span></div>
    <div class="nr-scope-infer-row"><span class="nr-scope-infer-label">适用文档类型</span>
      <div class="nr-scope-opt-grid">${extHtml}${wsHtml || ""}</div></div>
    <div class="nr-scope-infer-row">
      <label class="nr-scope-infer-field"><span>适用条件（可留空=不限）</span><input id="nr-scope-when" class="field" maxlength="200" value="${esc(decompScopeDefault.applicable_when || "")}" placeholder="例如：卤制工序"></label>
      <label class="nr-scope-infer-field"><span>证据范围</span><select id="nr-scope-ev" class="field">${evHtml}</select></label>
    </div>
    <div class="muted" id="nr-scope-infer-note">已自动推断 ${_inferredN}/${decompCandidates.length} 条候选的作用域；保存后写入草稿 scope，可在「继续编辑」里改。未选择任何适用范围时，发布会被 scope_missing 阻断（后端仍会二次校验）。</div>`;
}
function renderNewRuleFile() {
  const box = $("#nr-panel");
  if (!box) return;
  box.innerHTML = `<div style="padding:4px 0">
    <label class="pt-field" style="display:inline-flex;gap:8px;align-items:center;margin-bottom:10px"><span>来源类型</span>
      <select id="nr-source-type" class="field"><option value="enterprise_standard">企业制度/标准</option><option value="sop">作业指导书/SOP</option><option value="historical_audit">历史审核记录</option><option value="rule_export">历史规则导出</option><option value="other">其他</option></select></label>
    <div class="dz" id="nr-drop" style="border:1px dashed #D9DCE0;border-radius:8px;padding:28px;text-align:center;cursor:pointer">
      <div style="font-size:13px;color:#646A73">点击选择或拖拽制度文件 / 审核规范（xlsx / xls / docx / pdf / txt）</div>
      <div class="muted" style="font-size:11px;margin-top:6px">解析后只进草稿箱，不自动发布；历史审核记录会按条款候选拆解，仍需人工确认。</div>
    </div>
    <input type="file" id="nr-file" hidden accept=".xlsx,.xls,.docx,.pdf,.txt">
    <div class="nr-kb-row">
      <label class="nr-kb-sync"><input type="checkbox" id="nr-kb-sync" checked> 同步到知识库</label>
      <button type="button" class="btn" id="nr-kb-ref">从知识库引用</button>
      <span class="muted nr-kb-note" id="nr-kb-hint">默认把本次上传的制度文件同步到当前工作空间的知识库；同步失败会提示原因，不影响拆解和规则创建。</span>
    </div>
    <div class="actions" style="margin-top:10px">
      <span class="muted" id="nr-file-msg"></span><span class="muted" id="nr-kb-sync-msg"></span>
    </div>
    <div id="nr-cands" style="margin-top:14px"></div>
  </div>`;
  const drop = box.querySelector("#nr-drop");
  const input = box.querySelector("#nr-file");
  drop.addEventListener("click", () => input.click());
  input.addEventListener("change", () => input.files[0] && decomposeFile(input.files[0]));
  box.querySelector("#nr-kb-ref")?.addEventListener("click", pickFromKnowledge);
  loadIntakeTags();   // L51：提前读取分组列表，拆解结果渲染时直接可选
  if (typeof uxDirtyReset === "function") uxDirtyReset("newrule");
  drop.addEventListener("dragover", (e) => { e.preventDefault(); });
  drop.addEventListener("drop", (e) => {
    e.preventDefault();
    if (e.dataTransfer.files[0]) decomposeFile(e.dataTransfer.files[0]);
  });
}

/* 从知识库引用：读取已上传文件内容，与本地文件走同一 /api/v1/rule/decompose 解析入口。 */
function pickFromKnowledge() {
  const hint = $("#nr-kb-hint");
  if (!window.KB || typeof window.KB.pickFile !== "function") {
    if (hint) hint.textContent = "知识库组件未加载，请刷新页面后重试。";
    return;
  }
  window.KB.pickFile({
    title: "从知识库引用制度文件",
    filter: (f) => /\.(xlsx|docx|pdf|txt|eml)$/i.test(String(f.filename || "")),
    onPick: async (f, blob) => {
      const file = (typeof File !== "undefined" && blob instanceof File) ? blob
        : new File([blob], f.filename || "knowledge-file", { type: (blob && blob.type) || "application/octet-stream" });
      if (hint) hint.textContent = `已从知识库引用：${f.filename || ""}（走同一拆解入口，不重复同步到知识库）`;
      await decomposeFile(file, { fromKb: true, kbFileId: f.id });
    },
  });
}

/* 大文件 base64 转换分块，避免超长参数栈溢出（引用/上传都只走这一个解析入口）。 */
function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

/* 新建规则上传文件：默认同步到知识库；同步失败只提示，绝不阻断规则拆解/创建。 */
function syncUploadedFileToKnowledge(file) {
  const note = $("#nr-kb-sync-msg");
  if (!window.KB || typeof window.KB.uploadForRule !== "function") {
    if (note) note.textContent = "同步到知识库失败：知识库组件未加载（不影响规则创建）";
    return;
  }
  if (note) note.textContent = `正在同步到知识库：${file.name}…`;
  window.KB.uploadForRule(file).then((d) => {
    if (note) note.textContent = d && d.deduplicated
      ? `知识库已有相同文件：${(d.file && d.file.filename) || file.name}（未重复保存）`
      : `已同步到知识库：${(d && d.file && d.file.filename) || file.name}`;
  }).catch((e) => {
    if (note) note.textContent = `已拆解；同步到知识库失败：${(e && e.message) || e}（不影响规则创建）`;
    if (typeof showToast === "function") showToast("同步到知识库失败：" + ((e && e.message) || e), "err");
  });
}
async function decomposeFile(file, opts) {
  const _opts = opts || {};
  const msg = $("#nr-file-msg");
  msg.textContent = `解析中：${file.name}${_opts.fromKb ? "（来自知识库）" : ""}`;
  // 只对“本地上传”的文件做默认同步；从知识库引用的文件已在知识库，不重复同步。
  const _syncOn = $("#nr-kb-sync") ? !!$("#nr-kb-sync").checked : true;
  if (!_opts.fromKb && _syncOn) syncUploadedFileToKnowledge(file);
  const buf = await file.arrayBuffer();
  const b64 = arrayBufferToBase64(buf);
  const _stype = $("#nr-source-type")?.value || "enterprise_standard";
  const r = await (await fetch("/api/v1/rule/decompose", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filename: file.name, data: b64, source_type: _stype }) })).json();
  if (r.error) { msg.textContent = r.error; return; }
  decompCandidates = (r.candidates || []).map(x => ({ ...x, checked: (x.representation || "single") !== "decision_table" }));
  // T-185：保存后端作用域建议（可见可改），入库前展示“已自动推断，请确认”
  decompScopeCtx = r.scope_context || {};
  const _sugs = decompCandidates.map(x => x.scope_suggestion || {});
  const _first = _sugs.find(s => (s.applicable_types || []).length) || {};
  const _firstWhen = _sugs.find(s => s.applicable_when) || {};
  const _firstEv = _sugs.find(s => (s.evidence_scope || []).length) || {};
  const _reasons = [];
  _sugs.forEach(s => Object.keys((s.inferred && s.inferred.fields) || {}).forEach(k => {
    const rsn = String(((s.inferred.fields || {})[k] || {}).reason || "");
    if (rsn && !_reasons.includes(rsn)) _reasons.push(rsn);
  }));
  decompScopeDefault = {
    applicable_types: nrScopeTypesFromSuggestion(_first),
    applicable_when: _firstWhen.applicable_when || "",
    evidence_scope: (_firstEv.evidence_scope || ["document"]).slice(0, 1),
    inferred_reason: _reasons.slice(0, 2).join("；") || "当前空间文档类型 / 来源文件类型 / 原文适用范围",
  };
  const _dtN = decompCandidates.filter(x => (x.representation || "single") === "decision_table").length;
  msg.textContent = `${file.name} · 解析 ${r.chars} 字 · 拆出 ${decompCandidates.length} 条候选（${r.source_type || _stype}）；系统判型：单条 ${decompCandidates.length - _dtN}，决策表 ${_dtN}。决策表候选需去决策表编辑器，不能按单条入库。`;
  try { await loadIntakeTags(); } catch (e) { /* 分组读取失败不阻断候选展示，picker 内有可读错误 */ }
  renderCandidates();
}
/* 读取入库前作用域编辑条（下拉/勾选）的当前值；重渲染时保留用户修改。 */
function readScopeInferBar() {
  const box = $("#nr-scope-infer");
  if (!box || !box.querySelector("[data-scope-type]")) return null;
  const types = Array.from(box.querySelectorAll("[data-scope-type]:checked")).map(x => String(x.value || "").trim()).filter(Boolean);
  const when = String(((box.querySelector("#nr-scope-when") || {}).value || "")).trim();
  const ev = String(((box.querySelector("#nr-scope-ev") || {}).value || "document"));
  return { applicable_types: types, applicable_when: when, evidence_scope: [ev] };
}
function renderCandidates() {
  const box = $("#nr-cands");
  if (!box) return;
  if (!decompCandidates.length) { box.innerHTML = ""; return; }
  const _prevBar = readScopeInferBar();
  if (_prevBar) decompScopeDefault = Object.assign({}, decompScopeDefault, _prevBar);
  box.innerHTML = intakeTagPickerHTML() + `<div id="nr-scope-infer" class="nr-scope-infer"></div>
    <table class="table"><thead><tr>
      <th style="width:52px">序号</th><th style="width:44px"><input type="checkbox" id="nr-all" checked></th>
      <th>规则名</th><th>系统判型</th><th>类别</th><th>等级</th><th>依据原文</th>
      <th>适用范围（自动推断）</th><th>置信度</th>
    </tr></thead><tbody>` +
    decompCandidates.map((x, i) => {
      const _dt = (x.representation || "single") === "decision_table";
      const _sug = x.scope_suggestion || {};
      const _st = (nrScopeTypesFromSuggestion(_sug).join("/") || "未推断");
      const _sw = _sug.applicable_when ? (" · " + _sug.applicable_when) : "";
      const _se = (_sug.evidence_scope || []).join("/");
      const _sr = _sug.required_evidence ? `<div class="muted" style="font-size:10px">证据：${esc(_sug.required_evidence)}</div>` : "";
      return `<tr>
      <td class="muted">${decompCandidates.length - i}</td>
      <td><input type="checkbox" data-cand="${i}" ${x.checked ? "checked" : ""} ${_dt ? "disabled" : ""}></td>
      <td><b>${esc(x.name)}</b></td>
      <td>${_dt ? '<span class="pill draft">决策表</span><div class="muted" style="font-size:10px;max-width:150px">' + esc((x.form_reason || "多个条件").slice(0, 60)) + '</div>' : '<span class="pill published">单条</span>'}</td>
      <td>${esc(CATEGORY[x.category] || RULE_TEMPLATES[x.category]?.label || x.category)}</td>
      <td>${esc(riskLabel(x.rclass))}</td>
      <td class="muted">${esc((x.quote || "—").slice(0, 40))}</td>
      <td><span class="pill draft" title="已自动推断，请确认；入库后可在草稿继续编辑修改">${esc(_st)}${esc(_sw)}</span><div class="muted" style="font-size:10px">证据范围：${esc(_se || "默认")}</div>${_sr}</td>
      <td>${Math.round((x.confidence || 0) * 100)}%${_dt ? '<div style="margin-top:4px"><button type="button" class="btn" data-dt-open="' + i + '">去建决策表</button></div>' : ""}</td>
    </tr>`;
    }).join("") + `</tbody></table>
    <div class="actions" style="margin-top:10px">
      <button class="btn primary" id="nr-confirm">确认入库</button>
      <span class="muted">只生成本空间草稿，不自动发布；作用域取上方“适用范围”（已自动推断，可改）。</span>
    </div>
    <div id="nr-confirm-msg" class="muted" aria-live="polite"></div>`;
  renderScopeInferBar();
  bindIntakeTagPicker();   // L51：归属分组选择器（已有分组多选 + 管理员可新建）
  box.querySelectorAll("[data-cand]").forEach(cb => cb.addEventListener("change", () => {
    decompCandidates[Number(cb.dataset.cand)].checked = cb.checked;
  }));
  box.querySelectorAll("[data-dt-open]").forEach(b => b.addEventListener("click", function () {
    try { openDecisionCreate(); } catch (e) { showToast && showToast("决策表编辑器加载失败", "err"); }
  }));
  const all = box.querySelector("#nr-all");
  all?.addEventListener("change", () => {
    decompCandidates.forEach(x => { if ((x.representation || "single") !== "decision_table") x.checked = all.checked; });
    renderCandidates();
  });
  box.querySelector("#nr-confirm")?.addEventListener("click", async () => {
    const picked = decompCandidates.filter(x => x.checked);
    if (!picked.length) { alert("请至少选择一条"); return; }
    // T-185：入库前作用域编辑条的值随 scope 一起提交；未填时仍带 infer_scope=true
    // 让后端按真实信号补齐（前端显式值优先后端不覆盖）。
    const _bar = readScopeInferBar() || {};
    const _barTypes = Array.isArray(_bar.applicable_types) ? _bar.applicable_types : [];
    const _barWhen = String(_bar.applicable_when || "");
    const _barEv = ((_bar.evidence_scope || ["document"])[0]) || "document";
    // 用户未改动的自动推断值不伪装成「显式输入」：交给后端推断并把来源写进草稿
    // （scope.scope_inferred.fields = 值/来源/原因），编辑器里可见可改；改动过才显式提交。
    const _barDirty = (JSON.stringify(_barTypes) !== JSON.stringify(decompScopeDefault.applicable_types || []))
      || (_barWhen !== String(decompScopeDefault.applicable_when || ""))
      || (_barEv !== ((decompScopeDefault.evidence_scope || ["document"])[0] || "document"));
    // L51：归属分组 —— 已有分组用 tag_ids，新分组名用 tag_names（admin 可建；reviewer 未知名称会整体 403）
    const _tagIds = (intakeTagSel.ids || []).slice();
    const _newTagName = String(intakeTagSel.newName || "").trim();
    let r;
    try {
      r = await (await fetch("/api/v1/rules/batch", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ infer_scope: true, filename: $("#nr-file")?.files?.[0]?.name || "",
          tag_ids: _tagIds,
          tag_names: _newTagName ? [_newTagName] : [],
          rules: picked.map(x => {
          const _sug = x.scope_suggestion || {};
          const _slots = Object.assign({}, x.slots || {});
          const _scope = { tags: [], description: "", evidence: x.quote || "",
                           criterion: _slots.criterion || "", positive_example: "",
                           negative_example: "", source: x.source_type || "document_decompose" };
          if (_barDirty) {
            // 用户改过确认条：作为显式声明提交（后端不覆盖显式值）
            _scope.applicable_types = _barTypes;
            _scope.applicable_when = _barWhen;
            _scope.evidence_scope = [_barEv];
            _slots.evidence_scope = [_barEv];
          }
          return { name: x.name, category: x.category, rclass: x.rclass, slots: _slots,
            source: x.source_type || "document_decompose", filename: $("#nr-file")?.files?.[0]?.name || "",
            quote: x.quote || "", scope: _scope };
        }) }) })).json();
    } catch (e) {
      if (typeof showBatchSummary === "function") showBatchSummary({ title: "规则批量入库", success: 0, failed: picked.length, skipped: 0, failures: [{ name: "全部候选", reason: "网络错误，未提交成功" }] });
      return;
    }
    if (r && r.error) {
      if (typeof showBatchSummary === "function") showBatchSummary({ title: "规则批量入库", success: 0, failed: picked.length, skipped: 0, failures: [{ name: "全部候选", reason: r.error }] });
      return;
    }
    const _cfN2 = (r.conflicts || []).reduce((n, x) => n + (x.conflicts || []).length, 0);
    const _skipList = (r.skipped || []).map(x => ({ name: x.name || x.rule_id || "重复候选", reason: "疑似重复，已跳过" }));
    const _success = Math.max(0, parseInt(r.created || 0, 10) || 0);
    const _failed = Math.max(0, picked.length - _success - _skipList.length);
    const _summary = {
      title: "规则批量入库",
      success: _success,
      failed: _failed,
      skipped: _skipList.length,
      failures: _failed ? [{ name: "未返回明细的候选", reason: "接口未返回逐条失败原因，请到规则库核对" }] : [],
      skippedItems: _skipList,
    };
    const msg = box.querySelector("#nr-confirm-msg");
    const _infN2 = Math.max(0, parseInt(r.inferred_count || 0, 10) || 0);
    // L51：展示打标结果（tagged / tag_created / 逐分组 assigned）；失败不静默
    const _tagErr = String(r.tag_error || "");
    const _tagged = Math.max(0, parseInt(r.tagged || 0, 10) || 0);
    const _tagCreated = Array.isArray(r.tag_created) ? r.tag_created.map(x => String(x || "")) : [];
    const _rTags = Array.isArray(r.tags) ? r.tags : [];
    let _tagLine = "";
    if (_tagErr) {
      _tagLine = `<div class="rtb-err" style="margin-top:6px">规则已入库，但自动打标失败：${esc(_tagErr)}（可到规则库手动加入分组，规则本身不受影响）</div>`;
      if (typeof showToast === "function") showToast("规则已入库，但自动打标失败：" + _tagErr, "err");
    } else if (_tagIds.length || _newTagName) {
      const _names = _rTags.map(x => `${esc(String((x && x.name) || ""))}${x && x.created ? "（新建）" : ""} ×${esc(String(Number((x && x.assigned) || 0)))}`).join("、");
      _tagLine = `<div class="ux-batch-extra" id="nr-tag-result" data-tagged="${esc(String(_tagged))}" data-tag-created="${esc(_tagCreated.join(","))}">已打标 ${esc(String(_tagged))} 条规则${_names ? "：" + _names : ""}${_tagCreated.length ? "；自动新建分组：" + _tagCreated.map(x => esc(x)).join("、") : ""}</div>`;
      if (typeof showToast === "function") showToast(`已入库 ${_success} 条，已自动打标 ${_tagged} 条${_tagCreated.length ? "，新建分组 " + _tagCreated.join("、") : ""}`);
    }
    if (msg) {
      msg.innerHTML = (typeof uxBatchSummaryHTML === "function" ? uxBatchSummaryHTML(_summary) : "")
        + (_infN2 ? `<div class="ux-batch-extra">已自动推断适用范围 ${_infN2} 条并写入草稿（推断来源随草稿保存，可在草稿「继续编辑」确认/修改）。</div>` : "")
        + _tagLine
        + (_cfN2 ? `<div class="ux-batch-extra">发现 ${_cfN2} 条疑似规则冲突，请到「冲突提醒」查看。</div>` : "");
    }
    // 刷新分组计数；已选分组保留（重复保存幂等），新分组名清空
    intakeTagSel.newName = "";
    try { await loadIntakeTags(true); } catch (e) { /* 刷新失败不影响入库结果展示 */ }
    if (_infN2 && typeof showToast === "function") showToast(`已入库 ${_success} 条；已自动推断适用范围 ${_infN2} 条，请在草稿「继续编辑」确认`);
    if (typeof showBatchSummary === "function") showBatchSummary(_summary);
    else if (_cfN2) showToast(`已入库，但发现 ${_cfN2} 条规则冲突`, "err");
    if (typeof uxDirtyClear === "function") uxDirtyClear("newrule");
    loadRules(); loadRecentRules();
  });
}

/* ===================== 冲突提醒 ===================== */
const CF_TYPE = { numeric_conflict: "限值矛盾", duplicate: "重复规则", unit_mismatch: "单位不一致", scope_conflict: "作用域重叠", priority_conflict: "优先级冲突" };
const CF_SEV = { critical: "严重", warning: "一般", info: "提示" };
const CF_ST = { open: "待处理", resolved: "已裁决", ignored: "已忽略" };
let cfPage = 1;
