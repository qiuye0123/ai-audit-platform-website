/* 发现列表/人工问题/复核绑定：从 new_project_view.js 修正边界后拆出。 */
function findingRow(f) {
  const _isAI = String(f.engine || "").startsWith("platform");
  return `<div class="finding" data-fid="${esc(f.id)}">
    <div class="ft"><span class="pill ${f.severity === 'critical' ? 'draft' : 'r'}">${f.severity === 'critical' ? '严重' : '一般'}</span>${_isAI ? ' <span class="pill draft">AI 辅助</span>' : ''} ${esc(f.title)} <span class="muted">${esc(f.rule_code || '')}</span></div>
    <div class="fd">${esc(f.summary || '')}</div>
    ${f.suggestion ? `<div class="fd muted">建议：${esc(f.suggestion)}</div>` : ''}
    <div class="loc">${(f.evidence || []).map(a => `<a href="/api/v1/highlight" target="_blank">${esc(a.locator || a.sheet || '')}</a>`).join(" · ")}</div>
    ${currentRole === "reviewer" ? `<div class="actions" style="margin-top:6px">
      <button class="btn" data-act="confirmed" data-fid="${esc(f.id)}">确认</button>
      <button class="btn" data-act="false_positive" data-fid="${esc(f.id)}">误报</button>
      <button class="btn" data-act="need_evidence" data-fid="${esc(f.id)}">补证</button>
      ${_isAI ? `<button class="btn" data-sediment="${esc(f.id)}" data-title="${esc(f.title || '')}" data-summary="${esc(f.summary || '')}">沉淀为规则</button>` : ""}
    </div>` : `<div class="muted" style="margin-top:6px">只读查看 · 复核由审核员完成</div>`}</div>`;
}
function bindSediment() {
  document.querySelectorAll("#proj-findings [data-sediment]").forEach(b => b.addEventListener("click", async () => {
    const name = prompt("规则名称（可修改）：", b.dataset.title || "");
    if (name === null) return;
    const criterion = prompt("规则判据（可修改，越具体越准）：", b.dataset.summary || "");
    if (criterion === null) return;
    const r = await (await fetch(`/api/v1/findings/${b.dataset.sediment}/sediment`, { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name, criterion: criterion }) })).json();
    if (r.error) { alert("沉淀失败：" + r.error); return; }
    b.outerHTML = `<span class="pill published">已生成草稿 ${esc(r.code)}</span>`;
  }));
}

function bindDecisions() {
  document.querySelectorAll("#proj-findings [data-act]").forEach(b => b.addEventListener("click", async () => {
    await fetch(`/api/v1/findings/${b.dataset.fid}/decision`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ decision: b.dataset.act, reason: "人工复核" }) });
    const item = b.closest(".finding"); item.style.opacity = "0.45";
    item.querySelector(".actions").innerHTML = `<span class="pill published">已处理</span>`;
  }));
}

