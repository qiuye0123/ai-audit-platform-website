/* 管理端内置抽屉：租户配置 / 运维看板（不新开页面） */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var mask = null, current = null, inlineHost = null;

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
    });
  }
  function pill(t, c) { return '<span class="sd-pill ' + (c || "") + '">' + esc(t) + "</span>"; }
  function fmtBytes(n) {
    if (n == null) return "—";
    var u = ["B","KB","MB","GB","TB"], i = 0, x = Number(n);
    while (x >= 1024 && i < u.length - 1) { x /= 1024; i++; }
    return (i === 0 ? x : x.toFixed(x < 10 ? 2 : 1)) + " " + u[i];
  }
  function ensureMask() {
    if (mask) return mask;
    mask = document.createElement("div");
    mask.className = "sd-mask";
    mask.id = "sd-mask";
    mask.hidden = true;
    mask.innerHTML = '<aside class="sd-drawer" id="sd-drawer" role="dialog" aria-modal="true" aria-labelledby="sd-title"></aside>';
    document.body.appendChild(mask);
    mask.addEventListener("click", function (e) { if (e.target === mask) close(); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && mask && !mask.hidden && !document.querySelector(".ws-mask, .modal-mask:not([hidden])")) close();
    });
    return mask;
  }
  function close() {
    if (inlineHost) {
      inlineHost.innerHTML = "";
      inlineHost = null;
      current = null;
      return;
    }
    if (!mask) return;
    mask.hidden = true;
    mask.querySelector(".sd-drawer").innerHTML = "";
    current = null;
    document.body.classList.remove("sd-open");
  }
  function mount(html, narrow, hostSel) {
    // 正常页面模式：渲染到主内容区，不创建遮罩/右侧弹窗。
    if (hostSel) {
      var host = $(hostSel);
      if (host) {
        host.innerHTML = html;
        host.className = "sd-inline";
        inlineHost = host;
        document.body.classList.remove("sd-open");
        var hx = $(".sd-x", host); if (hx) hx.onclick = close;
        return host;
      }
    }
    ensureMask();
    var d = mask.querySelector(".sd-drawer");
    d.className = "sd-drawer" + (narrow ? " sd-narrow" : "");
    d.innerHTML = html;
    mask.hidden = false;
    document.body.classList.add("sd-open");
    var x = $(".sd-x", d); if (x) x.onclick = close;
    return d;
  }

  /* ------------------------------------------------------------ 租户配置 */
  function tenantDrawer() {
    current = "tenant";
    var d = mount(
      '<div class="sd-head"><div><h2 id="sd-title">租户配置</h2>' +
      '<p>维护本租户的平台名称与 Logo。保存后同步登录页、左侧品牌、页面标题和报告标题；只影响本租户。</p></div>' +
      '<button class="sd-x" type="button" aria-label="关闭">×</button></div>' +
      '<div class="sd-body"><div id="sd-t-readonly" class="sd-panel sd-readonly" hidden></div>' +
      '<div class="sd-tenant-hero"><div class="sd-preview-logo" id="sd-t-logo">AI</div>' +
      '<div class="sd-tenant-identity"><span class="sd-eyebrow">当前品牌</span><b id="sd-t-preview-name">AI 审核平台</b>' +
      '<span id="sd-t-tenant">当前租户</span><span class="sd-pill" id="sd-t-state">未配置（默认品牌）</span></div>' +
      '<span class="sd-dirty" id="sd-t-dirty" hidden>有未保存修改</span></div>' +
      '<div class="sd-panel sd-form-section"><div class="sd-section-head"><div><h3>品牌名称</h3><p class="hint">留空时回退默认“AI 审核平台”。</p></div><span class="sd-count" id="sd-t-count">0/40</span></div>' +
      '<div class="sd-field"><label for="sd-t-name">平台名称</label><input id="sd-t-name" type="text" maxlength="40" placeholder="例如：星海智能审核" autocomplete="off" aria-describedby="sd-t-name-hint"><p class="sd-hint" id="sd-t-name-hint">显示为“平台名 · 管理端/审核端”；报告标题也使用该名称。</p></div></div>' +
      '<div class="sd-panel sd-form-section"><div class="sd-section-head"><div><h3>Logo</h3><p class="hint">支持图片地址或本地上传，仅本租户可见。</p></div></div>' +
      '<div class="sd-field"><label for="sd-t-url">Logo 图片地址</label><input id="sd-t-url" type="url" placeholder="https://… 或上传后自动填入" autocomplete="off"><p class="sd-hint">PNG / JPEG / WebP / GIF，单张不超过 512KB。</p></div>' +
      '<div class="sd-field"><label for="sd-t-file">从本地上传</label><input id="sd-t-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif"><p class="sd-hint">选择图片后会转换为 data URL，保存前可预览。</p></div>' +
      '<div class="sd-actions"><button class="sd-btn" id="sd-t-clear-logo" type="button">清除 Logo</button><button class="sd-btn" id="sd-t-reset" type="button">恢复默认名称</button></div></div>' +
      '<div class="sd-msg" id="sd-t-msg" role="status" aria-live="polite"></div></div>' +
      '<div class="sd-savebar"><button class="sd-btn primary" id="sd-t-save" type="button">保存配置</button><button class="sd-btn" id="sd-t-cancel" type="button">取消</button><span class="sd-msg" id="sd-t-foot"></span></div>', true, "#tenant-page");
    var name = $("#sd-t-name", d), url = $("#sd-t-url", d), file = $("#sd-t-file", d);
    var msg = $("#sd-t-msg", d), foot = $("#sd-t-foot", d), dirtyEl = $("#sd-t-dirty", d);
    var readonly = false, saving = false, baseline = "";
    function setMsg(text, type) { msg.textContent = text || ""; msg.className = "sd-msg " + (type || ""); foot.textContent = text || ""; foot.className = "sd-msg " + (type || ""); }
    function sig() { return name.value + "\u0001" + url.value; }
    function dirty() { return sig() !== baseline; }
    function setPreview(logo, title) {
      var box = $("#sd-t-logo", d); box.innerHTML = "";
      if (logo) { var img = document.createElement("img"); img.alt = title || "Logo"; img.onerror = function () { box.textContent = "AI"; }; img.src = logo; box.appendChild(img); }
      else box.textContent = "AI";
      $("#sd-t-preview-name", d).textContent = title || "AI 审核平台";
    }
    function updateDirty() {
      var isDirty = dirty();
      dirtyEl.hidden = !isDirty;
      $("#sd-t-count", d).textContent = (name.value || "").length + "/40";
      $("#sd-t-save", d).disabled = readonly || saving || !isDirty;
    }
    function apply(b) {
      b = b || {}; var n = String(b.platform_name || "").trim(), l = String(b.logo_url || "").trim();
      name.value = n === "AI 审核平台" ? "" : n; url.value = l;
      $("#sd-t-tenant", d).textContent = b.tenant_name ? b.tenant_name + "（" + (b.tenant_code || b.tenant_id || "") + "）" : "当前租户";
      $("#sd-t-state", d).textContent = b.configured ? "已配置" : "未配置（默认品牌）";
      $("#sd-t-state", d).className = "sd-pill " + (b.configured ? "ok" : "");
      setPreview(l, n || "AI 审核平台"); baseline = sig(); updateDirty();
    }
    function readOnly(on, note) {
      readonly = on; [name, url, file].forEach(function (x) { x.disabled = on; });
      ["#sd-t-save", "#sd-t-clear-logo", "#sd-t-reset"].forEach(function (s2) { var x = $(s2, d); if (x) x.disabled = on; });
      var box = $("#sd-t-readonly", d);
      if (on) { box.hidden = false; box.textContent = note || "当前账号没有租户配置写权限，仅可查看。"; }
      updateDirty();
    }
    function load() {
      setMsg("加载中…");
      fetch("/api/v1/tenant/config", {credentials:"same-origin", cache:"no-store"}).then(function (r) {
        return r.json().catch(function(){return {}}).then(function (d0) { return {r:r,d:d0}; });
      }).then(function (x) {
        if (!x.r.ok) { readOnly(true, x.d.error || "当前账号无租户配置权限"); setMsg(x.d.error || "只读", "err"); return; }
        apply(x.d.branding || {}); setMsg(""); readOnly(false);
      }).catch(function () { setMsg("加载失败：网络错误", "err"); });
    }
    function save() {
      if (readonly || saving || !dirty()) return;
      var n = name.value.trim(), l = url.value.trim();
      if (n.length > 40) { setMsg("平台名称最多 40 个字", "err"); return; }
      if (l && !/^(https?:\/\/|data:image\/(png|jpe?g|webp|gif);base64,)/i.test(l)) { setMsg("Logo 必须是 http(s) 地址或图片 data URL", "err"); return; }
      saving = true; $("#sd-t-save", d).disabled = true;
      fetch("/api/v1/tenant/config", {method:"POST", credentials:"same-origin", headers:{"Content-Type":"application/json"}, body:JSON.stringify({platform_name:n,logo_url:l})})
        .then(function (r) { return r.json().catch(function(){return {}}).then(function (d0) { return {r:r,d:d0}; }); })
        .then(function (x) {
          if (!x.r.ok || !x.d.ok) { setMsg((x.d && (x.d.error || x.d.reason)) || "保存失败", "err"); return; }
          apply(x.d.branding || {}); setMsg("已保存，刷新页面后全局生效", "ok");
          if (window.RPBranding && window.RPBranding.refresh) window.RPBranding.refresh();
        }).catch(function () { setMsg("保存失败：网络错误", "err"); })
        .finally(function () { saving = false; updateDirty(); });
    }
    var safeClose = function () { if (dirty() && !confirm("有未保存修改，确定放弃并重新加载？")) return; if (inlineHost) { load(); } else { close(); } };
    $("#sd-t-save", d).onclick = save;
    $("#sd-t-cancel", d).onclick = safeClose; var _tc = $("#sd-t-close", d); if (_tc) _tc.onclick = safeClose;
    var x = $(".sd-x", d); if (x) x.onclick = safeClose;
    $("#sd-t-clear-logo", d).onclick = function () { url.value = ""; file.value = ""; setPreview("", name.value || "AI 审核平台"); updateDirty(); };
    $("#sd-t-reset", d).onclick = function () { name.value = ""; setPreview(url.value, "AI 审核平台"); updateDirty(); };
    name.addEventListener("input", function () { setPreview(url.value, name.value || "AI 审核平台"); updateDirty(); });
    url.addEventListener("input", function () { setPreview(url.value.trim(), name.value || "AI 审核平台"); updateDirty(); });
    file.addEventListener("change", function () {
      var f = this.files && this.files[0]; if (!f) return;
      if (!/^image\/(png|jpeg|webp|gif)$/i.test(f.type)) { setMsg("仅支持 PNG/JPEG/WebP/GIF", "err"); this.value = ""; return; }
      if (f.size > 512 * 1024) { setMsg("Logo 不能超过 512KB", "err"); this.value = ""; return; }
      var rd = new FileReader();
      rd.onload = function () { url.value = String(rd.result || ""); setPreview(url.value, name.value || "AI 审核平台"); setMsg("图片已读取，保存后生效"); updateDirty(); };
      rd.onerror = function () { setMsg("读取图片失败", "err"); };
      rd.readAsDataURL(f);
    });
    load();
  }

  /* ------------------------------------------------------------ 运维看板 */
  function opsDrawer() {
    current = "ops";
    var d = mount(
      '<div class="sd-head"><div><h2 id="sd-title">运维看板</h2><p>IT 管理员视角：先给结论和处置清单，再给证据；只读，不代替备份/迁移/重启等写操作。</p></div>' +
      '<div class="sd-head-actions"><span class="sd-muted" id="sd-o-time">—</span><button class="sd-btn" id="sd-o-refresh" type="button">刷新证据</button></div>' +
      '<button class="sd-x" type="button" aria-label="关闭">×</button></div>' +
      '<div class="sd-body"><div class="sd-ops-health" id="sd-o-health-line"></div><div class="sd-action-center" id="sd-o-actions"></div><div class="sd-kpis" id="sd-o-kpis"></div><div id="sd-o-sources"></div>' +
      '<div class="sd-tabs" id="sd-o-tabs"><button class="sd-tab active" data-ops-tab="health">健康总览</button><button class="sd-tab" data-ops-tab="db">数据库</button><button class="sd-tab" data-ops-tab="queue">队列任务</button><button class="sd-tab" data-ops-tab="model">模型调用</button><button class="sd-tab" data-ops-tab="errors">错误</button><button class="sd-tab" data-ops-tab="upgrade">升级</button></div>' +
      '<div id="sd-o-error" class="sd-panel" hidden></div>' +
      '<div class="sd-panel" data-ops-panel="health" id="sd-o-health"></div>' +
      '<div class="sd-panel"><h3>只读排障命令</h3><p class="hint">看板只读；以下命令由 IT 管理员在终端执行，复制后先确认环境/路径。</p><div class="sd-cmd-list" id="sd-o-commands"></div></div>' +
      '<div class="sd-panel" data-ops-panel="db" id="sd-o-db" hidden></div>' +
      '<div class="sd-panel" data-ops-panel="queue" id="sd-o-queue" hidden></div>' +
      '<div class="sd-panel" data-ops-panel="model" id="sd-o-model" hidden></div>' +
      '<div class="sd-panel" data-ops-panel="errors" id="sd-o-errors" hidden></div>' +
      '<div class="sd-panel" data-ops-panel="upgrade" id="sd-o-upgrade" hidden></div>' +
      '</div>', false, "#ops-page");
    var data = {}, active = "health";
    var errBox = $("#sd-o-error", d);
    function setErr(t) { if (!t) { errBox.hidden = true; return; } errBox.hidden = false; errBox.textContent = t; }
    function tab(name) {
      active = name;
      $$(".sd-tab", d).forEach(function (b) { b.classList.toggle("active", b.getAttribute("data-ops-tab") === name); });
      $$("[data-ops-panel]", d).forEach(function (p) { p.hidden = p.getAttribute("data-ops-panel") !== name; });
      $$(".sd-kpi", d).forEach(function (k) { k.classList.toggle("active", k.getAttribute("data-ops-kpi") === name); });
    }
    function kpi(k, v, s, tabName, cls) {
      return '<div class="sd-kpi ' + (cls || "") + '" data-ops-kpi="' + tabName + '"><div class="k"><span>' + k + '</span></div><div class="v">' + v + '</div><div class="s">' + (s || "") + '</div></div>';
    }
    function detail(title, text) {
      return '<div class="sd-panel" style="margin:10px 0 0"><h3>' + esc(title) + '</h3><pre class="sd-mono" style="white-space:pre-wrap;margin:0;max-height:220px;overflow:auto">' + esc(text) + '</pre></div>';
    }
    function sevLabel(sv) { return sv === "critical" ? "高优先级" : sv === "warning" ? "需关注" : "提示"; }
    function sevClass(sv) { return sv === "critical" ? "err" : sv === "warning" ? "warn" : ""; }
    function actionHtml(a) {
      var btns = '<button class="sd-btn" data-ops-jump-tab="' + esc(a.target_tab || "health") + '">看证据</button>';
      if (a.target_view) btns += '<button class="sd-btn" data-ops-go="' + esc(a.target_view) + '">去处理</button>';
      if (a.command) btns += '<button class="sd-btn" data-ops-copy="' + esc(a.command) + '">复制命令</button>';
      return '<div class="sd-action sd-action-' + esc(a.severity || "info") + '"><div class="sd-action-head"><span class="sd-pill ' + sevClass(a.severity) + '">' + esc(sevLabel(a.severity)) + '</span><span class="sd-muted">' + esc(a.area || "") + '</span><b>' + esc(a.title || "") + '</b></div>' +
        '<p>' + esc(a.detail || "") + '</p>' + (a.evidence ? '<div class="sd-action-evidence"><span>证据</span><code>' + esc(a.evidence) + '</code></div>' : '') +
        '<div class="sd-action-foot"><span class="sd-muted">建议：' + esc(a.action || "") + '</span><div class="sd-actions">' + btns + '</div></div></div>';
    }
    function renderActionCenter(actions, d) {
      var box = $("#sd-o-actions", d); if (!box) return;
      var list = actions.actions || [];
      if (!list.length) {
        box.innerHTML = '<div class="sd-action-empty"><b>未发现高优先级异常</b><span>继续看下方证据；不要用空指标代替健康结论。</span></div>';
        return;
      }
      box.innerHTML = '<div class="sd-action-title"><div><h3>待处理清单</h3><span class="muted">按影响排序；每条都有证据、建议和处置入口</span></div><span class="sd-pill ' + (actions.critical ? "err" : actions.warning ? "warn" : "ok") + '">' + esc(actions.summary || "") + '</span></div>' +
        list.map(actionHtml).join("");
    }
    function renderHealthLine(data, d) {
      var box = $("#sd-o-health-line", d); if (!box) return;
      var st = (data.actions || {}).status || "unknown";
      var color = st === "critical" ? "err" : st === "warning" ? "warn" : "ok";
      box.className = "sd-ops-health " + color;
      box.innerHTML = '<span class="sd-health-dot"></span><b>' + (st === "critical" ? "需要立即处理" : st === "warning" ? "需要关注" : "当前未见高优先级异常") + '</b>' +
        '<span>' + esc((data.actions || {}).summary || "") + '</span><span class="sd-health-time">证据时间 ' + esc(data.generated_at || "—") + '</span>';
    }
    function renderSources(data, d) {
      var box = $("#sd-o-sources", d); if (!box) return;
      var src = data.sources || {}, tw = data.time_window || {};
      var bk = data.backup || {};
      var rows = Object.keys(src).map(function (k) {
        var x = src[k] || {};
        return '<tr><td><b>' + esc(k) + '</b></td><td class="sd-muted">' + esc(x.source || "—") + '</td><td class="sd-muted">' + esc(x.window || "—") +
          '</td><td class="sd-muted">' + esc(x.basis || x.note || "—") + '</td></tr>';
      }).join("");
      box.innerHTML = '<div class="sd-panel"><h3>数据来源 / 时间窗 / 备份依据</h3>' +
        '<p class="hint">每项数字的口径在下方逐项列出；口径不清的指标不展示为已生效。</p>' +
        '<div class="sd-table-wrap"><table class="sd-table"><thead><tr><th>模块</th><th>数据源</th><th>时间窗</th><th>说明/依据</th></tr></thead><tbody>' +
        (rows || '<tr><td colspan="4" class="sd-empty">接口未返回数据来源说明</td></tr>') + '</tbody></table></div>' +
        '<div class="sd-muted" style="margin-top:8px">生成时间 ' + esc(tw.generated_at || data.generated_at || "—") +
        ' · 模型 24h=' + esc(tw.model_24h || "近 24 小时") + ' · 错误=' + esc(tw.errors || "最近 20 条") +
        ' · 队列=' + esc(tw.queue || "当前") + ' · 备份=' + esc(tw.backup || "最近备份文件") + '</div>' +
        '<div class="sd-muted" style="margin-top:6px">备份只读依据：' + (bk.latest
          ? '最新 <b>' + esc(bk.latest) + '</b>（' + esc(bk.latest_at || "—") + '，' + (bk.age_hours == null ? "—" : bk.age_hours + " 小时前") + '）'
          : '<span class="sd-pill warn">无可用备份</span>') +
        '；判定依据=存在 size>0 的 .db 文件按 mtime 取最新，不校验内容哈希/可恢复性（可用 <span class="sd-mono">rp db check</span> 验证）。' +
        '页面不发起备份写操作。</div></div>';
    }
    function renderCommands(d) {
      var box = $("#sd-o-commands", d); if (!box) return;
      var cmds = [
        ["备份数据库", "rp db backup"],
        ["数据库检查", "rp db check"],
        ["导出运维快照", "rp ops overview"],
        ["数据层迁移（先备份）", "rp db migrate"],
      ];
      box.innerHTML = cmds.map(function (x) {
        return '<div class="sd-cmd"><div><b>' + esc(x[0]) + '</b><code>' + esc(x[1]) + '</code></div><button class="sd-btn" data-ops-copy="' + esc(x[1]) + '">复制</button></div>';
      }).join("");
    }
    function render(d0) {
      data = d0 || {}; var db = data.db || {}, model = data.model || {}, q = data.queue || {}, err = data.errors || {}, up = data.upgrade || {}, bk = data.backup || {};
      var tj = q.task_job || {}, otq = q.open_task_queue || {};
      $("#sd-o-time", d).textContent = data.generated_at ? "更新 " + data.generated_at : "—";
      $("#sd-o-kpis", d).innerHTML =
        kpi("健康结论", (data.actions || {}).critical ? "需处理" : ((data.actions || {}).warning ? "需关注" : "正常"), (data.actions || {}).summary || "—", "health") +
        kpi("待处理", esc((data.actions || {}).action_count || 0), esc((data.actions || {}).critical || 0) + " 高优 · " + esc((data.actions || {}).warning || 0) + " 需关注", "health") +
        kpi("队列", esc(tj.backlog == null ? 0 : tj.backlog), "失败 " + (tj.failed || 0) + " · 最久 " + (tj.oldest_queued_minutes == null ? "—" : tj.oldest_queued_minutes + "min"), "queue") +
        kpi("模型 24h", (model.success_rate_24h == null ? "无数据" : Math.round(model.success_rate_24h * 100) + "%"), "调用 " + (model.calls_24h || 0) + " · 失败 " + (model.failed_24h || 0), "model") +
        kpi("备份", bk.latest ? (bk.age_hours == null ? "有" : bk.age_hours + "h") : "无", bk.latest ? bk.latest : "未发现备份文件", "upgrade") +
        kpi("数据库", fmtBytes(db.size_bytes), (db.table_count == null ? "—" : db.table_count + " 张表") + " · WAL " + fmtBytes(db.wal_bytes || 0), "db");
      renderHealthLine(data, d); renderActionCenter(data.actions || {}, d); renderSources(data, d); renderCommands(d);
      $("#sd-o-health", d).innerHTML = '<h3>健康总览</h3><p class="hint">先看红色项，再看队列和模型；数据库/升级用于发布与排障。</p>' +
        '<div class="sd-grid2"><div><div class="sd-muted">数据库：<b>' + esc(db.path || "—") + '</b></div><div class="sd-muted">JSON 检查：坏数据 ' + (data.json && data.json.invalid_count ? pill(String(data.json.invalid_count), "err") : pill("0", "ok")) + '</div><div class="sd-muted">模型：' + (model.available ? pill("可用（按配置）", "ok") : pill("不可用", "err")) + ' · ' + esc(model.model || "未配置") + '</div></div>' +
        '<div><div class="sd-muted">队列：task_job 积压 ' + esc(tj.backlog || 0) + '，开放平台未投递 ' + esc(q.open_event_undelivered || 0) + '</div><div class="sd-muted">最近错误：' + esc(err.count || 0) + ' 条；升级：' + esc(up.current_version || "—") + '</div><div class="sd-muted">备份：请在 CLI 执行 <span class="sd-mono">rp db backup</span>，看板不发起备份写操作。</div></div></div>' +
        '<div class="sd-actions"><button class="sd-btn" data-ops-go="model">去模型配置</button><button class="sd-btn" data-ops-go="users">去账号</button><button class="sd-btn" data-ops-go="openplatform">去开放平台</button></div>' +
        '<h3 style="margin-top:16px">检查项</h3><div class="sd-check-grid">' + ((data.actions || {}).checks || []).map(function (c) { return '<div class="sd-check"><span class="sd-pill ' + (c.status === "ok" ? "ok" : c.status === "critical" ? "err" : "warn") + '">' + esc(c.status === "ok" ? "正常" : c.status === "critical" ? "异常" : "关注") + '</span><b>' + esc(c.label || "") + '</b><span>' + esc(c.value || "—") + '</span>' + (c.action ? '<em>' + esc(c.action) + '</em>' : '') + '</div>'; }).join("") + '</div>' +
        ((data.notes || []).length ? '<details style="margin-top:12px"><summary class="sd-muted">数据说明（' + data.notes.length + '）</summary><ul class="sd-muted">' + data.notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + '</ul></details>' : "");
      $("#sd-o-db", d).innerHTML = '<h3>数据库与一致性</h3><p class="hint">SQLite 文件、WAL、页数、索引；JSON 坏数据只报告不自动修改。</p>' +
        '<div class="sd-muted">路径：<span class="sd-mono">' + esc(db.path || "—") + '</span><br>文件 ' + fmtBytes(db.size_bytes) + ' · WAL ' + fmtBytes(db.wal_bytes || 0) + ' · page_size ' + esc(db.page_size || "—") + ' · 索引 ' + esc(db.index_count == null ? "—" : db.index_count) + '</div>' +
        '<div class="sd-muted" style="margin-top:6px">JSON：列 ' + esc((data.json || {}).checked_columns || 0) + ' · 值 ' + esc((data.json || {}).checked_rows || 0) + ' · 坏 ' + esc((data.json || {}).invalid_count || 0) + '</div>' +
        '<div class="sd-table-wrap" style="margin-top:12px"><table class="sd-table"><thead><tr><th>表</th><th>行数</th><th></th></tr></thead><tbody>' +
        ((db.tables || []).slice().sort(function(a,b){return (b.rows||0)-(a.rows||0);}).map(function (t) { return '<tr><td class="sd-mono">' + esc(t.name) + '</td><td>' + esc(t.rows == null ? "—" : t.rows) + '</td><td><button class="sd-btn" data-ops-table="' + esc(t.name) + '" data-rows="' + esc(t.rows == null ? "" : t.rows) + '">详情</button></td></tr>'; }).join("") || '<tr><td colspan="3" class="sd-empty">无表数据</td></tr>') + '</tbody></table></div><div id="sd-o-table-detail"></div>';
      $("#sd-o-queue", d).innerHTML = '<h3>队列与任务</h3><p class="hint">异步审核与开放平台回调；积压优先看 oldest 排队时间。</p>' +
        '<div class="sd-muted">task_job：总计 ' + esc(tj.total || 0) + ' · 排队 ' + esc(tj.queued || 0) + ' · 运行 ' + esc(tj.running || 0) + ' · 完成 ' + esc(tj.done || 0) + ' · 失败 ' + esc(tj.failed || 0) + ' · 超时 ' + esc(tj.timeout || 0) + (tj.oldest_queued_at ? '<br>最久排队：<span class="sd-mono">' + esc(tj.oldest_queued_at) + '</span>' : '') + '</div>' +
        '<div class="sd-muted" style="margin-top:6px">open_task_queue：总计 ' + esc(otq.total || 0) + ' · accepted ' + esc(otq.accepted || 0) + ' · processing ' + esc(otq.processing || 0) + ' · completed ' + esc(otq.completed || 0) + ' · failed ' + esc(otq.failed || 0) + ' · 未投递事件 ' + esc(q.open_event_undelivered || 0) + '</div>';
      $("#sd-o-model", d).innerHTML = '<h3>模型与最近调用</h3><p class="hint">来自 llm_trace 的真实调用；无记录时显示无数据，不虚构成功率。</p>' +
        '<div class="sd-muted">' + esc(model.note || "—") + ' · 启用模型 ' + esc(model.enabled_models || 0) + '/' + esc(model.total_models || 0) + '</div>' +
        '<div class="sd-table-wrap" style="margin-top:10px"><table class="sd-table"><thead><tr><th>时间</th><th>模型</th><th>延迟</th><th>Token</th><th>结果</th><th></th></tr></thead><tbody>' +
        ((model.recent || []).length ? model.recent.map(function (r) { return '<tr><td>' + esc(r.created_at || "—") + '</td><td class="sd-mono">' + esc(r.model || "—") + '</td><td>' + esc(r.latency_ms == null ? "—" : r.latency_ms + "ms") + '</td><td>' + esc((r.tokens_in || 0) + "/" + (r.tokens_out || 0)) + '</td><td>' + (r.ok ? pill("成功","ok") : pill("失败/空","err")) + '</td><td><button class="sd-btn" data-ops-call="' + esc(JSON.stringify(r)) + '">详情</button></td></tr>'; }).join("") : '<tr><td colspan="6" class="sd-empty">无模型调用记录（llm_trace 为空）</td></tr>') + '</tbody></table></div><div id="sd-o-call-detail"></div>';
      $("#sd-o-errors", d).innerHTML = '<h3>最近错误</h3><p class="hint">task_job / audit_log / open_event / open_task_queue 的失败项；点详情看完整错误。</p>' +
        '<div class="sd-table-wrap"><table class="sd-table"><thead><tr><th>来源</th><th>时间</th><th>事件/对象</th><th></th></tr></thead><tbody>' +
        ((err.recent || []).length ? err.recent.map(function (r) { return '<tr><td>' + esc(r.source || "—") + '</td><td>' + esc(r.at || "—") + '</td><td><span class="sd-mono">' + esc(r.event || "") + '</span><br>' + esc(r.title || "") + '</td><td><button class="sd-btn" data-ops-err="' + esc(JSON.stringify(r)) + '">详情</button></td></tr>'; }).join("") : '<tr><td colspan="4" class="sd-empty">无错误记录</td></tr>') + '</tbody></table></div>' +
        ((err.groups || []).length ? '<h3 style="margin-top:16px">错误分组（先处理高频）</h3><div class="sd-table-wrap"><table class="sd-table"><thead><tr><th>来源</th><th>事件</th><th>次数</th><th>最近</th><th>样例</th></tr></thead><tbody>' + err.groups.map(function (g) { return '<tr><td>' + esc(g.source || "—") + '</td><td class="sd-mono">' + esc(g.event || "—") + '</td><td><b>' + esc(g.count || 0) + '</b></td><td>' + esc(g.last_at || "—") + '</td><td class="sd-muted">' + esc((g.sample || "").slice(0, 100)) + '</td></tr>'; }).join("") + '</tbody></table></div>' : '') +
        '<div id="sd-o-err-detail"></div>';
      $("#sd-o-upgrade", d).innerHTML = '<h3>版本与升级</h3><p class="hint">当前 VERSION、schema_migration、最近升级包；备份/升级不在页面内执行写操作。</p>' +
        '<div class="sd-muted">当前版本 <b>' + esc(up.current_version || "—") + '</b><br>schema version ' + esc(up.schema_version == null ? "—" : up.schema_version) + (up.latest_migration ? '<br>最近迁移 ' + esc(up.latest_migration.version + " @ " + up.latest_migration.applied_at) : '') + '<br>最近升级包 ' + esc(up.last_upgrade ? (up.last_upgrade.package + "（" + up.last_upgrade.from_version + " → " + up.last_upgrade.to_version + "）") : "—") + '</div>' +
        '<div class="sd-muted" style="margin-top:10px">最近备份：' + (bk.latest ? '<b>' + esc(bk.latest) + '</b> · ' + esc(bk.latest_at || "—") + ' · ' + esc(bk.age_hours == null ? "—" : bk.age_hours + " 小时前") : '<span class="sd-pill warn">无可用备份</span>') + '</div>' +
        '<div class="sd-actions"><button class="sd-btn" data-ops-copy="rp db backup">复制备份命令</button><button class="sd-btn" data-ops-go="model">模型配置</button><button class="sd-btn" data-ops-go="auditlogs">审计日志</button></div>';
      setErr("");
    }
    function load() {
      var b = $("#sd-o-refresh", d); b.disabled = true; b.textContent = "刷新中…";
      fetch("/api/v1/ops/overview", {credentials:"same-origin", cache:"no-store"}).then(function (r) {
        return r.json().catch(function(){return {}}).then(function (d0) { return {r:r,d:d0}; });
      }).then(function (x) {
        if (!x.r.ok) { setErr("HTTP " + x.r.status + "：" + (x.d.error || "读取失败") + "（仅系统管理员/平台运营可查看）"); return; }
        render(x.d);
      }).catch(function () { setErr("请求失败：网络错误"); })
      .finally(function () { b.disabled = false; b.textContent = "刷新"; });
    }
    tab("health"); load();
    $("#sd-o-refresh", d).onclick = load; var _oc = $("#sd-o-close", d); if (_oc) _oc.onclick = close;
    $$(".sd-tab", d).forEach(function (b) { b.onclick = function () { tab(b.getAttribute("data-ops-tab")); }; });
    d.addEventListener("click", function (e) {
      var k = e.target.closest("[data-ops-kpi]"); if (k) { tab(k.getAttribute("data-ops-kpi")); return; }
      var jt = e.target.closest("[data-ops-jump-tab]"); if (jt) { tab(jt.getAttribute("data-ops-jump-tab")); return; }
      var cp = e.target.closest("[data-ops-copy]"); if (cp) { var cmd = cp.getAttribute("data-ops-copy") || ""; var done = function () { if (window.showToast) showToast("命令已复制：" + cmd); else cp.textContent = "已复制"; }; if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(cmd).then(done).catch(function(){ if (window.showToast) showToast(cmd, "err"); }); } else { if (window.showToast) showToast(cmd); } return; }
      var go = e.target.closest("[data-ops-go]"); if (go) { close(); var v = go.getAttribute("data-ops-go"); if (window.showView) { try { showView(v); } catch (err) {} } return; }
      var tb = e.target.closest("[data-ops-table]"); if (tb) { var box = $("#sd-o-table-detail", d); if (box) box.innerHTML = detail("表 " + tb.getAttribute("data-ops-table"), "行数：" + (tb.getAttribute("data-rows") || "—") + "\n只读统计；业务数据按权限在对应功能页查看。"); return; }
      var ca = e.target.closest("[data-ops-call]"); if (ca) { var cbox = $("#sd-o-call-detail", d); if (cbox) { try { var o = JSON.parse(ca.getAttribute("data-ops-call")); cbox.innerHTML = detail("模型调用详情", JSON.stringify(o, null, 2)); } catch (err) {} } return; }
      var er = e.target.closest("[data-ops-err]"); if (er) { var ebox = $("#sd-o-err-detail", d); if (ebox) { try { var o2 = JSON.parse(er.getAttribute("data-ops-err")); ebox.innerHTML = detail("错误详情", JSON.stringify(o2, null, 2)); } catch (err) {} } return; }
    });
  }


  /* ------------------------------------------------------------ 数据边界（数据出境/留存/删除） */
  // 页面最小入口：只读状态 + 保存配置 + 删除影响面预览 + dry-run；
  // 真实删除（dry_run=false + confirm=确认删除）仅系统管理员可见可用；权限以 HTTP 403 为准。
  var DP_FIELDS = [
    { key: "region", label: "数据处理/存储区域", type: "text", hint: "如 cn-shanghai、客户机房；用于判断是否出境" },
    { key: "external_model", label: "允许文件全文发送外部模型", type: "select",
      choices: [["", "未配置"], ["deny", "禁止（应私有化/本地模型）"], ["allow", "允许（需合同+书面确认）"]] },
    { key: "retention_cases_days", label: "审核项目与上传原文件保留天数", type: "number", hint: "0=不自动删除（需合同明确）" },
    { key: "retention_logs_days", label: "审计日志保留天数", type: "number", hint: "审计日志只读不可删除，仅供归档口径" },
    { key: "retention_cache_days", label: "模型判定缓存保留天数", type: "number", hint: "缓存无租户列，本页不执行删除" },
    { key: "retention_reports_days", label: "审核报告保留天数", type: "number" },
    { key: "deletion_request_window_days", label: "删除/导出申请响应时限（天）", type: "number" },
    { key: "deletion_contact", label: "数据删除/导出申请联系人", type: "text" },
    { key: "disclosure_ack", label: "客户已书面确认数据外发与留存口径", type: "checkbox" },
    { key: "note", label: "交付口径补充说明（合同条款编号等）", type: "text" }
  ];

  function dataPolicyDrawer() {
    current = "datapolicy";
    var d = mount(
      '<div class="sd-head"><div><h2 id="sd-title">数据边界</h2>' +
      '<p>数据出境 / 留存 / 删除策略：未配置会显式警告，不静默套用默认值。保存配置写审计；删除必须先预览、再二次确认，默认 dry-run 0 删除。</p></div>' +
      '<button class="sd-x" type="button" aria-label="关闭">×</button></div>' +
      '<div class="sd-body"><div id="sd-dp-readonly" class="sd-panel sd-readonly" hidden></div>' +
      '<div class="sd-panel"><div class="sd-section-head"><div><h3>当前状态</h3>' +
      '<p class="hint">来源 db/env/unset；未配置项逐项提示，不按“已披露”交付。</p></div>' +
      '<span class="sd-pill" id="sd-dp-state">读取中…</span></div>' +
      '<div id="sd-dp-warnings" class="sd-msg" role="alert" aria-live="polite"></div>' +
      '<div id="sd-dp-meta" class="sd-muted"></div></div>' +
      '<div class="sd-panel sd-form-section"><div class="sd-section-head"><div><h3>策略配置</h3>' +
      '<p class="hint">保存后写 DB（覆盖环境变量默认值）并记录审计 data.policy.updated。</p></div></div>' +
      '<div class="sd-grid2" id="sd-dp-form">' + DP_FIELDS.map(function (f) {
        var input;
        if (f.type === "select") {
          input = '<select id="sd-dp-' + f.key + '">' + f.choices.map(function (c) {
            return '<option value="' + esc(c[0]) + '">' + esc(c[1]) + "</option>";
          }).join("") + "</select>";
        } else if (f.type === "checkbox") {
          input = '<label style="display:flex;gap:8px;align-items:center"><input id="sd-dp-' + f.key + '" type="checkbox"> 已完成书面确认</label>';
        } else {
          input = '<input id="sd-dp-' + f.key + '" type="' + (f.type === "number" ? "number" : "text") + '" ' +
                  (f.type === "number" ? 'min="0" ' : "") + 'autocomplete="off">';
        }
        return '<div class="sd-field"><label for="sd-dp-' + f.key + '">' + esc(f.label) + "</label>" +
               input + (f.hint ? '<p class="sd-hint">' + esc(f.hint) + "</p>" : "") + "</div>";
      }).join("") + '</div>' +
      '<div class="sd-actions"><button class="sd-btn primary" id="sd-dp-save" type="button">保存配置</button>' +
      '<button class="sd-btn" id="sd-dp-refresh" type="button">刷新</button>' +
      '<span class="sd-msg" id="sd-dp-save-msg"></span></div></div>' +
      '<div class="sd-panel sd-form-section"><div class="sd-section-head"><div><h3>删除影响面（预览 → 二次确认）</h3>' +
      '<p class="hint">没有预览凭证不得 DELETE；默认 dry-run 不删除任何行。真实删除仅系统管理员，需输入「确认删除」。</p></div></div>' +
      '<div class="sd-actions"><button class="sd-btn" id="sd-dp-preview" type="button">预览影响面</button>' +
      '<button class="sd-btn" id="sd-dp-dryrun" type="button" disabled>dry-run 执行（0 删除）</button></div>' +
      '<div id="sd-dp-preview-out" class="sd-muted" style="margin-top:8px"></div>' +
      '<div id="sd-dp-exec-box" hidden style="margin-top:10px">' +
      '<div class="sd-field"><label for="sd-dp-confirm">二次确认文本（真实删除）</label>' +
      '<input id="sd-dp-confirm" type="text" placeholder="输入：确认删除" autocomplete="off">' +
      '<p class="sd-hint">真实删除只删除项目/文档/报告，audit_log 与 llm_cache 不删除；执行前请先 rp db backup。</p></div>' +
      '<div class="sd-actions"><button class="sd-btn" id="sd-dp-execute" type="button">真实删除</button>' +
      '<span class="sd-msg" id="sd-dp-exec-msg"></span></div></div></div>' +
      '<div class="sd-msg" id="sd-dp-msg" role="status" aria-live="polite"></div></div>',
      true, "#datapolicy-page");
    var state = { canEdit: false, canExecute: false, token: "", status: null };
    function setMsg(sel, text, type) { var el = $(sel, d); if (el) { el.textContent = text || ""; el.className = "sd-msg " + (type || ""); } }
    function readOnly(on, note) {
      state.canEdit = !on;
      DP_FIELDS.forEach(function (f) { var el = $("#sd-dp-" + f.key, d); if (el) el.disabled = on; });
      var sv = $("#sd-dp-save", d); if (sv) sv.disabled = on;
      var box = $("#sd-dp-readonly", d);
      if (on) { box.hidden = false; box.textContent = note || "当前账号没有数据边界配置写权限，仅可查看。"; }
      else box.hidden = true;
    }
    function renderMeta(p) {
      var meta = p.meta || {}, vals = p.values || {};
      var src = ["db", "env", "unset"].map(function (k) {
        return k + " " + Object.keys(meta).filter(function (kk) { return (meta[kk] || {}).source === k; }).length;
      }).join(" / ");
      var missing = (p.missing_required || []);
      $("#sd-dp-meta", d).innerHTML = "来源：" + esc(src) + "；必需项缺失：" +
        (missing.length ? esc(missing.join("、")) : "无") +
        ((p.updated_at ? "；最近更新：" + esc(p.updated_at) + "（" + esc(p.updated_by || "—") + "）" : ""));
      return vals;
    }
    function fill(vals) {
      DP_FIELDS.forEach(function (f) {
        var el = $("#sd-dp-" + f.key, d); if (!el) return;
        var v = vals[f.key];
        if (f.type === "checkbox") el.checked = v === true;
        else el.value = (v === null || v === undefined) ? "" : String(v);
      });
    }
    function collect() {
      var out = {};
      DP_FIELDS.forEach(function (f) {
        var el = $("#sd-dp-" + f.key, d); if (!el) return;
        if (f.type === "checkbox") { out[f.key] = !!el.checked; return; }
        var v = String(el.value == null ? "" : el.value).trim();
        if (v !== "") out[f.key] = v;
      });
      return out;
    }
    function renderStatus(p) {
      state.status = p;
      state.canExecute = !!p.can_execute_purge;
      $("#sd-dp-state", d).textContent = p.configured ? "已配置" : "未配置（交付前必须配置）";
      $("#sd-dp-state", d).className = "sd-pill " + (p.configured ? "ok" : "warn");
      var warns = p.warnings || [];
      $("#sd-dp-warnings", d).hidden = !warns.length;
      $("#sd-dp-warnings", d).className = "sd-msg " + (p.configured ? "warn" : "err");
      $("#sd-dp-warnings", d).innerHTML = warns.length
        ? warns.map(function (w) { return '<div>⚠ ' + esc(w) + "</div>"; }).join("") : "";
      var vals = renderMeta(p.policy || {});
      fill(vals);
      if (!p.can_edit) readOnly(true, "当前账号没有数据边界配置写权限，仅可查看。");
      else readOnly(false);
      var ex = $("#sd-dp-exec-box", d);
      if (ex) ex.hidden = !state.canExecute;
      if (!state.canExecute) {
        var btn = $("#sd-dp-execute", d); if (btn) btn.disabled = true;
      }
    }
    function load() {
      setMsg("#sd-dp-msg", "读取中…");
      fetch("/api/v1/data-policy", { credentials: "same-origin", cache: "no-store" })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { r: r, j: j }; }); })
        .then(function (x) {
          if (!x.r.ok) { setMsg("#sd-dp-msg", "HTTP " + x.r.status + "：" + (x.j.error || "读取失败"), "err"); return; }
          renderStatus(x.j);
          setMsg("#sd-dp-msg", "状态已刷新（" + (x.j.configured ? "已配置" : "未配置") + "）", x.j.configured ? "" : "warn");
        })
        .catch(function () { setMsg("#sd-dp-msg", "请求失败：网络错误", "err"); });
    }
    function renderPreview(p) {
      var cut = p.cutoffs || {};
      var rows = ["audit_case", "document", "report", "audit_log", "llm_cache"].map(function (k) {
        var c = cut[k] || {};
        return "<tr><td>" + esc(c.label || k) + "</td><td>" + esc(c.retention_days == null ? "未配置" : c.retention_days + " 天") +
          "</td><td>" + esc(c.would_delete == null ? "—" : c.would_delete) + "</td><td>" +
          (c.executable ? pill("会执行", "ok") : pill("不执行", "warn")) + "</td><td class=\"sd-muted\">" +
          esc(c.executable ? (c.note || "") : (c.reason || "")) + "</td></tr>";
      }).join("");
      var excl = p.excluded_categories || {};
      $("#sd-dp-preview-out", d).innerHTML =
        '<div class="sd-muted">租户：<b>' + esc(p.tenant_id) + "</b>；可执行行数上限：<b>" + esc(p.total_executable) + "</b>；" +
        "全部影响面（含不执行的审计日志/缓存）：<b>" + esc(p.total_would_delete) + "</b></div>" +
        '<div class="sd-table-wrap" style="margin-top:8px"><table class="sd-table"><thead><tr><th>类别</th><th>留存</th><th>将影响行数</th><th>执行</th><th>说明</th></tr></thead><tbody>' +
        rows + "</tbody></table></div>" +
        '<details style="margin-top:6px"><summary class="sd-muted">不执行的类别（' + Object.keys(excl).length + "）</summary><ul>" +
        Object.keys(excl).map(function (k) { return "<li><b>" + esc(k) + "</b>：" + esc(excl[k]) + "</li>"; }).join("") + "</ul></details>";
      state.token = p.preview_token || "";
      var dry = $("#sd-dp-dryrun", d); if (dry) dry.disabled = !state.token;
      setMsg("#sd-dp-msg", "预览完成：已签发一次性预览凭证（" + Math.round((p.token_expires_in || 0) / 60) + " 分钟内有效）；未删除任何行", "ok");
    }
    function preview() {
      var btn = $("#sd-dp-preview", d); btn.disabled = true; btn.textContent = "预览中…";
      fetch("/api/v1/data-policy/purge/preview", { method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" }, body: "{}" })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { r: r, j: j }; }); })
        .then(function (x) {
          if (!x.r.ok) { setMsg("#sd-dp-msg", "HTTP " + x.r.status + "：" + (x.j.error || "预览失败"), "err"); return; }
          renderPreview(x.j);
        })
        .catch(function () { setMsg("#sd-dp-msg", "预览失败：网络错误", "err"); })
        .finally(function () { btn.disabled = false; btn.textContent = "预览影响面"; });
    }
    function execute(dryRun) {
      if (!state.token) { setMsg("#sd-dp-msg", "请先预览（没有预览凭证不得执行删除）", "err"); return; }
      var body = { preview_token: state.token, dry_run: !!dryRun };
      if (!dryRun) body.confirm = String(($("#sd-dp-confirm", d) || {}).value || "");
      var sel = dryRun ? "#sd-dp-msg" : "#sd-dp-exec-msg";
      fetch("/api/v1/data-policy/purge/execute", { method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { r: r, j: j }; }); })
        .then(function (x) {
          if (!x.r.ok) { setMsg(sel, "HTTP " + x.r.status + "：" + (x.j.error || "执行失败"), "err"); return; }
          if (x.j.executed) {
            setMsg(sel, "删除完成：顶层 " + x.j.total_deleted + " 行 / 级联 " + (x.j.total_rows_deleted || 0) + " 行；审计日志与缓存未删除", "ok");
            load();
          } else {
            setMsg(sel, x.j.message || "dry-run：未删除任何行", "ok");
          }
        })
        .catch(function () { setMsg(sel, "执行失败：网络错误", "err"); });
    }
    function save() {
      var fields = collect();
      if (!Object.keys(fields).length) { setMsg("#sd-dp-save-msg", "没有可保存的字段", "err"); return; }
      var btn = $("#sd-dp-save", d); btn.disabled = true; btn.textContent = "保存中…";
      fetch("/api/v1/data-policy", { method: "PUT", credentials: "same-origin",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fields: fields }) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { r: r, j: j }; }); })
        .then(function (x) {
          if (!x.r.ok) { setMsg("#sd-dp-save-msg", "HTTP " + x.r.status + "：" + (x.j.error || "保存失败"), "err"); return; }
          var changed = Object.keys(x.j.changed || {});
          setMsg("#sd-dp-save-msg", "已保存：" + (changed.length ? changed.join("、") : "无变化") + "（写审计）", "ok");
          load();
        })
        .catch(function () { setMsg("#sd-dp-save-msg", "保存失败：网络错误", "err"); })
        .finally(function () { btn.disabled = false; btn.textContent = "保存配置"; });
    }
    $("#sd-dp-save", d).onclick = save;
    $("#sd-dp-refresh", d).onclick = load;
    $("#sd-dp-preview", d).onclick = preview;
    $("#sd-dp-dryrun", d).onclick = function () { execute(true); };
    $("#sd-dp-execute", d).onclick = function () { execute(false); };
    load();
  }

  /* ---------------------------------------------------------------- 本体能力开关（T-197 P0-2）
   * 用户口径：「只对 3 类点位有价值，默认关，按空间开，有必要就自动开」。
   * 开关字段：ontology.enabled（默认 false，关=不读本体：cross_doc 不执行 + D4 不读冻结别名）
   *           ontology.mode（auto=按 ΔF1 95%CI 自动开/关；manual=只记录不自动切换）。
   * 在「空间列表 → 查看详情」抽屉内注入；写接口 POST /api/v1/ontology/switch 同事务写审计。 */
  var _pendingWs = "";
  function mountOntologySwitch() {
    var modal = document.querySelector("#ws-detail-modal");
    if (!modal || modal.getAttribute("data-onto-mounted") === "1") return;
    var scroll = modal.querySelector(".ws-detail-scroll");
    if (!scroll) return;
    modal.setAttribute("data-onto-mounted", "1");
    var wsId = "";
    try { wsId = (new URL(location.href)).searchParams.get("ws") || ""; } catch (e) { wsId = ""; }
    var box = document.createElement("div");
    box.className = "sd-panel";
    box.id = "ws-onto-switch";
    box.innerHTML = '<div class="section-head"><div><h3 style="font-size:13px">本体能力</h3>' +
      '<p>默认关。关闭时：跨文档一致性规则不执行、D4 不读本体冻结别名；只能在需要的空间按需开启。</p></div></div>' +
      '<label class="ws-label" style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="wd-onto-enabled"> 启用本体能力（ontology.enabled）</label>' +
      '<div class="ws-field-hint" id="wd-onto-state">读取中…</div>' +
      '<label class="ws-label">自动评估模式（ontology.mode）' +
      '<select id="wd-onto-mode" class="field"><option value="auto">auto · 按 ΔF1 95%CI 自动开/关（默认）</option><option value="manual">manual · 只记录影子差异，不自动切换</option></select></label>' +
      '<div class="ws-field-hint" id="wd-onto-eval"></div>' +
      '<div class="actions" style="margin-top:6px"><button type="button" class="btn primary" id="wd-onto-save">保存本体能力</button>' +
      '<span class="ws-msg" id="wd-onto-msg" role="status" aria-live="polite"></span></div>';
    var msgEl = scroll.querySelector(".ws-msg");
    if (msgEl) scroll.insertBefore(box, msgEl); else scroll.appendChild(box);
    var wid = "";
    try {
      var head = modal.querySelector(".ws-dialog-head .muted");
      wid = (modal.getAttribute("data-ws-id") || "");
    } catch (e) { wid = ""; }
    function setMsg(t, type) {
      var m = $("#wd-onto-msg", box);
      if (!m) return;
      m.textContent = t || "";
      m.style.color = type === "err" ? "#B91C1C" : (type === "ok" ? "#0F7B4F" : "");
    }
    function render(st) {
      var sw = (st && st.switch) || {};
      $("#wd-onto-enabled", box).checked = !!sw.stored_enabled;
      $("#wd-onto-mode", box).value = sw.mode || "auto";
      var ae = (st && st.auto_evaluation) || {};
      var shadow = ae.shadow || {};
      var last = (ae.recent || [])[0];
      $("#wd-onto-state", box).textContent = "当前生效：" + (sw.enabled ? "开" : "关") +
        "（存储=" + (sw.stored_enabled ? "开" : "关") + "，模式=" + (sw.mode || "auto") +
        "，原因=" + (sw.reason || "—") + "）";
      $("#wd-onto-eval", box).textContent =
        "自动评估：门槛 ΔF1 95%CI 下界 ≥ +" + (ae.auto_on_ci_lo_pp || 0.5) + "pp 自动开；" +
        "连续 " + (ae.auto_off_consecutive || 2) + " 轮上界 < 0 自动关；样本下限 " + (ae.min_points || 200) + "。" +
        (last ? ("上一轮：" + last.action + " Δ=" + last.delta_pp + "pp CI[" + last.ci_lo_pp + "," + last.ci_hi_pp + "]") : "") +
        " 影子轮次 " + (shadow.rounds || 0) + "（带标签 " + (shadow.labeled_rounds || 0) + "）。";
    }
    function load(workspaceId) {
      var q = workspaceId ? ("?workspace_id=" + encodeURIComponent(workspaceId)) : "";
      return fetch("/api/v1/ontology/switch" + q, { credentials: "same-origin", cache: "no-store" })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (d) {
          if (!d || d.ok === false) { setMsg(d && (d.error || d.reason) || "读取失败", "err"); return; }
          wid = d.workspace_id || workspaceId || "";
          modal.setAttribute("data-ws-id", wid);
          render(d);
        })
        .catch(function () { setMsg("读取失败：网络错误", "err"); });
    }
    $("#wd-onto-save", box).onclick = function () {
      var btn = this;
      btn.disabled = true;
      setMsg("保存中…");
      fetch("/api/v1/ontology/switch", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workspace_id: wid,
          enabled: !!$("#wd-onto-enabled", box).checked,
          mode: String($("#wd-onto-mode", box).value || "auto"),
          reason: "空间详情页人工切换" })
      }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { r: r, j: j }; }); })
        .then(function (x) {
          if (!x.r.ok || x.j.ok === false) { setMsg("HTTP " + x.r.status + "：" + (x.j.error || x.j.reason || "保存失败"), "err"); return; }
          setMsg("已保存并写审计：本体能力 " + (x.j.after && x.j.after.enabled ? "开" : "关") + "，模式 " + ((x.j.after || {}).mode || ""), "ok");
          render({ switch: x.j.after || {}, auto_evaluation: {} });
        })
        .catch(function () { setMsg("保存失败：网络错误", "err"); })
        .finally(function () { btn.disabled = false; });
    };
    // 空间详情模态自身不带 ws id：在打开链接的点击事件里记录目标空间（捕获阶段）。
    load(_pendingWs);
  }

  /* 本体页顶部提示：当前空间本体能力默认关（让用户在页面就知道"为什么不开"） */
  function mountOntologyBanner() {
    var panel = document.querySelector("#onto-auto-panel");
    if (!panel || document.querySelector("#onto-cap-banner")) return;
    var banner = document.createElement("div");
    banner.id = "onto-cap-banner";
    banner.className = "evo-note";
    banner.style.cssText = "border-color:#FCD34D;background:#FFFBEB;color:#92400E";
    banner.textContent = "本体能力默认关（按空间开启）：关闭时跨文档一致性规则不执行、D4 不读本体冻结别名。开启入口：空间列表 → 查看详情 → 本体能力。";
    panel.insertBefore(banner, panel.firstChild);
    fetch("/api/v1/ontology/switch", { credentials: "same-origin", cache: "no-store" })
      .then(function (r) { return r.json().catch(function () { return {}; }); })
      .then(function (d) {
        if (!d || !d.switch) return;
        banner.textContent = "当前空间本体能力：" + (d.switch.enabled ? "开" : "关") +
          "（mode=" + (d.switch.mode || "auto") + "，原因=" + (d.switch.reason || "—") + "）。" +
          (d.switch.enabled ? "" : "关闭时跨文档一致性规则不执行、D4 不读本体冻结别名。") +
          "开启入口：空间列表 → 查看详情 → 本体能力。";
      }).catch(function () {});
  }
  var _ontoObserver = null;
  function watchOntologyUI() {
    if (_ontoObserver || typeof MutationObserver === "undefined") return;
    _ontoObserver = new MutationObserver(function () {
      mountOntologySwitch();
      if (!document.querySelector("#view-ontology") || document.querySelector("#view-ontology").hidden) return;
      mountOntologyBanner();
    });
    _ontoObserver.observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watchOntologyUI);
  else watchOntologyUI();

  document.addEventListener("click", function (e) {
    var _wsv = e.target.closest("[data-ws-view]");
    if (_wsv && _wsv.getAttribute("data-ws-view")) { _pendingWs = _wsv.getAttribute("data-ws-view"); }
    var t = e.target.closest("[data-open-tenant]"); if (t) { e.preventDefault(); if (window.showView) showView("tenant"); else tenantDrawer(); return; }
    var o = e.target.closest("[data-open-ops]"); if (o) { e.preventDefault(); if (window.showView) showView("ops"); else opsDrawer(); return; }
  });
  window.RPSettingsDrawers = {tenant: tenantDrawer, ops: opsDrawer, dataPolicy: dataPolicyDrawer, close: close};
})();
