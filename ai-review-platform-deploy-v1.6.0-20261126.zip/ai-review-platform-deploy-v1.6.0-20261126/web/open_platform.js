/* 开放平台页面模块：从 app.js 拆出。 */
function openAppForm(app) {
  const edit = !!app;
  const mask = openModalMask("open-app-modal", `<div class="settings-head"><h3>${edit ? "编辑应用" : "创建开放应用"}</h3><button class="ws-close" data-om-close>×</button></div>
    <div class="open-form"><label>应用名称<input id="oa-name" class="field" value="${esc(app?.name || "")}" placeholder="例如：ERP 采购审核"></label>
    <label>回调地址<input id="oa-callback" class="field" value="${esc(app?.callback_url || "")}" placeholder="https://your-system.example.com/webhook"></label>
    <label>订阅事件<input id="oa-events" class="field" value="${esc(app?.events || "audit.completed")}" placeholder="audit.completed,ping"></label>
    ${edit ? "" : '<label class="open-check"><input id="oa-sandbox" type="checkbox"> 使用内置沙箱接收（无外部地址时）</label>'}
    <div class="open-form-note">回调必须为 HTTPS/HTTP 公网地址；系统会做 SSRF 校验。创建后 AppSecret 仅展示一次。</div>
    <div class="actions" style="justify-content:flex-end"><button class="btn" data-om-close>取消</button><button class="btn primary" id="oa-save">${edit ? "保存" : "创建应用"}</button></div></div>`);
  mask.querySelector("#oa-save").onclick = async () => {
    const body = { name: mask.querySelector("#oa-name").value.trim(), callback_url: mask.querySelector("#oa-callback").value.trim(), events: mask.querySelector("#oa-events").value.trim() || "audit.completed" };
    if (!body.name) { showToast("请填写应用名称", "err"); return; }
    if (!edit) body.sandbox = !!mask.querySelector("#oa-sandbox")?.checked;
    const url = edit ? `/api/v1/open/apps/${encodeURIComponent(app.id)}/update` : "/api/v1/open/apps";
    const r = await (await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r.error) { showToast("保存失败：" + r.error, "err"); return; }
    mask.remove();
    if (!edit && r.app_secret) showOpenSecret(r.app_key, r.app_secret, "应用已创建，请立即保存 AppSecret");
    else showToast("应用已保存");
    loadOpenPlatform();
  };
}
function showOpenSecret(appKey, secret, title) {
  const mask = openModalMask("open-secret-modal", `<div class="settings-head"><h3>${esc(title || "应用凭据")}</h3><button class="ws-close" data-om-close>×</button></div>
    <div class="open-secret-note">AppSecret 只在此处展示一次，关闭后无法再次查看；如遗失请轮换密钥。</div>
    <div class="open-secret-line"><span>AppKey</span><code>${esc(appKey || "")}</code><button class="btn" data-copy="${esc(appKey || "")}">复制</button></div>
    <div class="open-secret-line"><span>AppSecret</span><code>${esc(secret || "")}</code><button class="btn" data-copy="${esc(secret || "")}">复制</button></div>
    <div class="actions" style="justify-content:flex-end"><button class="btn primary" data-om-close>我已保存</button></div>`);
  mask.querySelectorAll("[data-copy]").forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copy); showToast("已复制"); } catch (e) { showToast("复制失败，请手动选择", "err"); } });
}
async function loadOpenPlatform() {
  const host = document.getElementById("openplatform-body"); if (!host) return;
  host.innerHTML = '<div class="muted" style="padding:20px 0">开放平台加载中…</div>';
  let apps, events, sandbox;
  try {
    const [ra, re, rs] = await Promise.all([
      fetch("/api/v1/open/apps"), fetch("/api/v1/open/events?limit=100"), fetch("/api/v1/open/sandbox"),
    ]);
    apps = await ra.json(); events = await re.json(); sandbox = await rs.json();
    if (!ra.ok || !re.ok || !rs.ok) throw new Error((apps && apps.error) || ("HTTP " + ra.status));
    if (apps.error || events.error) throw new Error(apps.error || events.error);
    if (!Array.isArray(apps)) apps = [];
    if (!Array.isArray(events)) events = [];
  } catch (e) {
    host.innerHTML = `<div class="card"><div class="empty" style="padding:20px 0">开放平台数据加载失败：${esc(e.message || e)}<div class="muted" style="font-size:11px;margin-top:6px">仅系统管理员可访问；不会伪造应用或投递记录。</div></div><div class="actions" style="justify-content:center"><button class="btn" id="oa-retry">重新加载</button></div></div>`;
    const rb = host.querySelector("#oa-retry"); if (rb) rb.onclick = loadOpenPlatform;
    return;
  }
  const delivered = events.filter(e => e.status === "delivered").length;
  const pending = events.filter(e => e.status === "pending").length;
  const retry = events.filter(e => e.status === "retry").length;
  const failed = events.filter(e => e.status === "failed").length;
  const rate = events.length ? Math.round(delivered / events.length * 100) : null;
  const appRows = apps.map(a => `<tr>
    <td><b>${esc(a.name)}</b><div class="muted" style="font-size:12px">${esc(a.id)}</div></td>
    <td><span class="pill ${a.status === "active" ? "published" : "draft"}">${a.status === "active" ? "启用" : "停用"}</span></td>
    <td><code class="open-key">${esc(a.app_key)}</code></td>
    <td><code class="open-mask">${esc(a.app_secret_masked)}</code></td>
    <td class="muted" style="max-width:190px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(a.callback_url)}">${esc(a.callback_url || "内置沙箱")}</td>
    <td class="muted">${esc(a.events || "—")}</td>
    <td><span class="pill published">${a.delivered || 0}</span> <span class="pill draft">${a.pending || 0}</span> <span class="pill r">${a.failed || 0}</span></td>
    <td class="muted">${esc(a.last_event_at ? a.last_event_at.slice(0, 16) : "—")}</td>
    <td><div class="open-actions">
      <button class="btn" data-oa-test="${esc(a.id)}">发测试事件</button>
      <button class="btn" data-oa-edit="${esc(a.id)}">编辑</button>
      <button class="btn" data-oa-rotate="${esc(a.id)}">轮换密钥</button>
      <button class="btn" data-oa-status="${esc(a.id)}" data-cur="${esc(a.status)}">${a.status === "active" ? "停用" : "启用"}</button>
    </div></td></tr>`).join("");
  const selectedStatus = openState.status;
  const shownEvents = selectedStatus ? events.filter(e => e.status === selectedStatus) : events;
  const eventRows = shownEvents.map(e => {
    const tone = e.status === "delivered" ? "published" : e.status === "failed" ? "r" : "draft";
    return `<tr style="cursor:pointer" data-oa-event="${esc(e.id)}" title="点击查看投递详情"><td class="muted">${esc((e.created_at || "").slice(0, 16))}</td><td><b>${esc(e.type || "—")}</b>${e.is_test_event ? ' <span class="pill draft">测试事件</span>' : ""}<div class="muted" style="font-size:12px">${esc(e.app_key || "—")}</div></td>
      <td class="muted">${esc(e.task_id || "—")}</td><td><span class="pill ${tone}">${esc(e.status || "pending")}</span></td><td>${e.attempts || 0}</td>
      <td class="muted" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(e.last_error || "")}">${esc(e.last_error || "—")}</td>
      <td class="muted">${esc(e.next_retry_at || "—")}</td></tr>`;
  }).join("");
  const sandboxRows = (Array.isArray(sandbox) ? sandbox : []).map(x => `<tr><td><code>${esc(x.app_key || "")}</code></td><td><span class="pill ${x.valid ? "published" : "r"}">${x.valid ? "签名有效" : "签名无效"}</span></td><td class="muted">${esc((x.received_at || "").slice(0, 16))}</td></tr>`).join("");
  host.innerHTML = `
    <div class="open-hero"><div><h2>开放平台</h2><p>通过 HMAC-SHA256 签名接入外部系统，推送审核任务并接收审核结果回调。</p></div><div class="open-hero-actions"><button class="btn" id="oa-deliver">立即投递待发送事件</button><button class="btn primary" id="oa-create">新建应用</button></div></div>
    <div class="open-kpis">
      <div><b>${apps.length}</b><span>接入应用</span></div><div><b>${apps.filter(a => a.status === "active").length}</b><span>启用应用</span></div>
      <div><b>${delivered}</b><span>已投递</span></div><div><b>${pending + retry}</b><span>待投递</span></div><div><b>${failed}</b><span>失败</span></div><div><b>${rate == null ? "—" : rate + "%"}</b><span>投递成功率</span></div>
    </div>
    <div class="card open-card"><div class="section-head"><div><h2>应用接入</h2><p>AppKey 公开；AppSecret 只在创建/轮换时展示一次。</p></div></div>
      ${apps.length ? `<div class="table-wrap"><table class="table open-app-table"><thead><tr><th>应用</th><th>状态</th><th>AppKey</th><th>AppSecret</th><th>回调地址</th><th>订阅事件</th><th>投递</th><th>最近事件</th><th>操作</th></tr></thead><tbody>${appRows}</tbody></table></div>` : '<div class="empty">还没有开放应用，先创建一个应用接入外部系统。</div>'}
    </div>
    <div class="card open-card"><div class="section-head"><div><h2>回调投递</h2><p>失败会按退避策略自动重试，最多 5 次；点任一行查看投递详情（请求头样例、payload、签名预览、错误与下次重试）。「发测试事件」会真实入队一条 ping 事件。</p></div><select id="oa-status-filter" class="field" style="width:130px"><option value="">全部状态</option><option value="delivered" ${selectedStatus === "delivered" ? "selected" : ""}>已投递</option><option value="pending" ${selectedStatus === "pending" ? "selected" : ""}>待投递</option><option value="retry" ${selectedStatus === "retry" ? "selected" : ""}>重试中</option><option value="failed" ${selectedStatus === "failed" ? "selected" : ""}>失败</option></select></div>
      ${shownEvents.length ? `<div class="table-wrap"><table class="table open-event-table"><thead><tr><th>时间</th><th>事件 / 应用</th><th>任务</th><th>状态</th><th>次数</th><th>最近错误</th><th>下次重试</th></tr></thead><tbody>${eventRows}</tbody></table></div>` : '<div class="empty">当前筛选下没有回调记录。</div>'}
    </div>
    <div class="open-lower">
      <div class="card open-card"><div class="section-head"><div><h2>接入说明</h2><p>外部系统按以下方式签名和验证回调。</p></div></div>
        <div class="open-doc"><div>请求头</div><pre>X-App-Key: 应用 AppKey
X-Timestamp: Unix 秒
X-Nonce: 一次性随机串
X-Signature: HMAC-SHA256(AppSecret, AppKey + Timestamp + Nonce + Body)</pre>
        <div>推送接口</div><pre>POST /open/v1/tasks
Content-Type: application/json
{"project_name":"外部任务","files":[{"filename":"a.pdf","content_base64":"..."}]}</pre>
        <div class="muted" style="font-size:11px">AppSecret 不出现在请求头明文；签名错误、时间戳过期、nonce 重放都会被拒绝。</div></div>
      </div>
      <div class="card open-card"><div class="section-head"><div><h2>沙箱接收</h2><p>勾选“内置沙箱”的应用可直接验证签名和回调链路。</p></div></div>
        ${sandboxRows ? `<table class="table open-event-table"><thead><tr><th>AppKey</th><th>验签</th><th>接收时间</th></tr></thead><tbody>${sandboxRows}</tbody></table>` : '<div class="empty">暂无沙箱回调</div>'}
      </div>
    </div>`;
  const byId = id => apps.find(x => x.id === id);
  $("#oa-create").onclick = () => openAppForm(null);
  $("#oa-deliver").onclick = async () => { const r = await (await fetch("/api/v1/open/deliver", { method: "POST" })).json(); showToast(`投递：成功 ${r.delivered || 0} · 重试 ${r.retry || 0} · 失败 ${r.failed || 0}`); loadOpenPlatform(); };
  $("#oa-status-filter").onchange = e => { openState.status = e.target.value; loadOpenPlatform(); };
  host.querySelectorAll("[data-oa-test]").forEach(b => b.onclick = async () => {
    b.disabled = true; const _old = b.textContent; b.textContent = "入队中…";
    try {
      const r = await (await fetch(`/api/v1/open/apps/${encodeURIComponent(b.dataset.oaTest)}/test`, { method: "POST" })).json();
      if (r.error) { showToast(r.error, "err"); return; }
      showToast(`测试事件已入队（event=${esc(r.event_id || "")}，真实 ping 事件）；可点「立即投递待发送事件」触发投递`);
      loadOpenPlatform();
    } finally { b.disabled = false; b.textContent = _old; }
  });
  host.querySelectorAll("[data-oa-event]").forEach(tr => tr.onclick = () => openDeliveryDetail(tr.dataset.oaEvent));
  host.querySelectorAll("[data-oa-edit]").forEach(b => b.onclick = () => openAppForm(byId(b.dataset.oaEdit)));
  host.querySelectorAll("[data-oa-rotate]").forEach(b => b.onclick = async () => {
    if (!(await confirmAction("轮换 AppSecret", "旧 Secret 会立即失效，外部系统必须同步更新。确认轮换？", "确认轮换"))) return;
    const r = await (await fetch(`/api/v1/open/apps/${encodeURIComponent(b.dataset.oaRotate)}/rotate`, { method: "POST" })).json();
    if (r.error) { showToast("轮换失败：" + r.error, "err"); return; }
    showOpenSecret(r.app_key, r.app_secret, "AppSecret 已轮换，请立即保存");
  });
  host.querySelectorAll("[data-oa-status]").forEach(b => b.onclick = async () => {
    const next = b.dataset.cur === "active" ? "disabled" : "active";
    const ok = await confirmAction(
      next === "disabled" ? "停用应用" : "启用应用",
      next === "disabled" ? "停用后外部系统将无法接收该应用的回调；历史投递记录保留。确认停用？" : "确认恢复该应用的开放接口与回调？",
      next === "disabled" ? "确认停用" : "确认启用",
      next === "disabled"
    );
    if (!ok) return;
    const r = await (await fetch(`/api/v1/open/apps/${encodeURIComponent(b.dataset.oaStatus)}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: next }) })).json();
    if (r.error) { showToast("操作失败：" + r.error, "err"); return; } showToast(next === "active" ? "应用已启用" : "应用已停用"); loadOpenPlatform();
  });
}
/* 投递详情（只读）：请求头样例 / payload / 签名预览 / 错误 / 下次重试。 */
async function openDeliveryDetail(eventId) {
  if (!eventId) return;
  const old = document.getElementById("delivery-detail-modal"); if (old) old.remove();
  const mask = document.createElement("div");
  mask.id = "delivery-detail-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(760px,calc(100vw - 24px))"><div class="settings-head"><h3>投递详情</h3><button class="ws-close" data-dd-close>×</button></div>
    <div id="delivery-detail-body"><div class="muted" style="padding:16px 0">加载中…</div></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-dd-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  const body = mask.querySelector("#delivery-detail-body");
  try {
    const r = await fetch(`/api/v1/open/events/${encodeURIComponent(eventId)}`);
    const d = await r.json();
    if (!r.ok || d.error) { body.innerHTML = `<div class="empty">${esc(d.error || ("HTTP " + r.status))}</div>`; return; }
    const kw = (k, v) => `<div class="np-field"><span>${esc(k)}</span><b>${esc(v == null || v === "" ? "—" : String(v))}</b></div>`;
    const hdrs = Object.entries(d.signature_headers_sample || {}).map(([k, v]) => `${k}: ${v}`).join("\n");
    body.innerHTML = `<div class="settings-section"><div class="settings-title">事件</div><div class="np-grid">
        ${kw("事件 ID", d.id)}${kw("类型", d.type + (d.is_test_event ? "（测试事件）" : ""))}${kw("应用", d.app_name || d.app_key)}
        ${kw("状态", d.status)}${kw("投递次数", d.attempts)}${kw("重试次数", d.retry_count)}
        ${kw("回调地址", d.callback_url)}${kw("创建时间", d.created_at)}${kw("下次重试", d.next_retry_at)}
        ${kw("最近错误", d.last_error)}</div></div>
      <div class="settings-section"><div class="settings-title">签名请求头样例（只读）</div>
        <pre class="open-doc" style="white-space:pre-wrap;margin:0">${esc(hdrs || "—")}</pre>
        <div class="muted" style="font-size:11px;line-height:1.6;margin-top:4px">${esc(d.signature_note || "")}</div>
        <div class="muted" style="font-size:11px;line-height:1.6">重试策略：最多 ${esc((d.retry_policy || {}).max_attempts || 5)} 次，退避 ${esc(((d.retry_policy || {}).backoff_seconds || []).join(" / "))} 秒</div></div>
      <div class="settings-section"><div class="settings-title">Payload ${d.payload_truncated ? "（已截断）" : ""}</div>
        <pre class="open-doc" style="white-space:pre-wrap;max-height:260px;overflow:auto;margin:0">${esc(d.payload_preview || "—")}</pre></div>
      <div class="settings-foot"><button class="btn" data-dd-close>关闭</button></div>`;
    body.querySelectorAll("[data-dd-close]").forEach(b => b.onclick = close);
  } catch (e) {
    body.innerHTML = '<div class="empty">投递详情加载失败（网络错误）</div>';
  }
}
/* ===================== 审计日志（系统管理员） ===================== */

/* 个人资料保存 */
(async () => {
  const el = document.querySelector("#btn-save-profile");
  if (!el) return;
  el.addEventListener("click", async () => {
    const r = await fetch("/api/v1/me/profile", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: $("#p-name").value.trim(), email: $("#p-email").value.trim(), phone: $("#p-phone").value.trim() }) });
    if (r.ok) {
      $("#user-name").textContent = $("#p-name").value.trim() || $("#user-name").textContent;
      el.textContent = "已保存";
      setTimeout(() => el.textContent = "保存资料", 1200);
    }
  });
})();

/* 消息类型标签 */
const NOTIFY_LABEL = {
  "project.pending_review": "待复核", "rule_pending": "规则待审批",
  "rule.updated": "规则更新", "system.llm_fail": "模型异常", "open.webhook_failed": "回调失败",
  "project.timeout": "项目超时", "rule_created": "新规则待复核",
  "rule.feedback": "规则反馈", "rule.conflict": "规则冲突", "system.incident": "系统异常",
  "agent.fp_auto": "智能体归因", "type_created": "文档类型待复核",
};
function notifyLabel(t) { return NOTIFY_LABEL[t] || t || "通知"; }

/* 通知渠道 */

