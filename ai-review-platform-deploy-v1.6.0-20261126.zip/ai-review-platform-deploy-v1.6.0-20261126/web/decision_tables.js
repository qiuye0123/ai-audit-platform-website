/* 决策表页面模块：从 app.js 拆出。 */
async function dtRefreshRuleDomain() {
  if (typeof refreshRuleDomain === "function") { refreshRuleDomain(); return; }
  if (typeof loadRules === "function") loadRules();
}
async function loadDecisionTables() {
  const _dtHost = document.querySelector("#dt-list");
  if (!_dtHost) { dtRefreshRuleDomain(); return; }   // T-109：决策表不再有独立 tab，列表在规则库以规则形式展示
  let _modOff = false;
  try {
    const sr = await (await fetch("/api/v1/workspaces/settings")).json();
    _modOff = !(sr.modules && sr.modules.mod_decision_table);
  } catch (e) {}
  const _newBtn = document.querySelector("#btn-dt-new");
  if (_newBtn) {
    _newBtn.disabled = _modOff || currentRole === "reviewer";
    _newBtn.style.display = currentRole === "reviewer" ? "none" : "";
    _newBtn.title = _modOff ? "请先在当前空间启用决策表模块" : "";
  }
  if (_modOff) {
    $("#dt-list").innerHTML = `<div class="dt-module-off"><b>当前工作空间未启用决策表模块</b>
      <p>${currentRole === "reviewer" ? "审核员只读：请联系业务管理员在空间配置中启用。" : "决策表是一种多条件规则，不会在未启用时参与审核。启用后可以新建、发布并测试决策表。"}</p>
      ${currentRole === "reviewer" ? "" : `<button class="btn primary" id="dt-goto-enable">去空间配置启用</button>`}</div>`;
    const b = document.querySelector("#dt-goto-enable");
    if (b) b.onclick = openWsConfig;
    return;
  }
  const d = await (await fetch("/api/v1/decision-tables")).json();
  const items = d.items || [];
  const _dtCanManage = currentRole !== "reviewer";
  applyReviewerUi();
  $("#dt-list").innerHTML = items.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>编码</th><th>名称</th><th>行数</th><th>命中策略</th>
      <th>适用范围</th><th>灰度</th><th>状态</th><th>版本</th><th>负责人</th><th>部门</th><th>日期</th><th>维护记录</th><th style="width:150px">操作</th>
    </tr></thead><tbody>` +
    items.map((t, i) => `<tr>
      <td>${items.length - i}</td><td class="muted">${esc(t.code)}</td><td><b>${esc(t.name)}</b></td>
      <td>${t.rows}</td><td>${esc(t.hit_policy)}</td>
      <td class="muted">${(t.scope_types || []).join(",") || "全部类型"}</td>
      <td>${t.canary_percent == null ? 100 : t.canary_percent}%</td>
      <td><span class="pill ${t.status === "published" ? "published" : "draft"}">${t.status === "published" ? "已发布" : "草稿"}</span></td>
      <td class="muted">${esc(t.version)}</td>
      <td>${esc(t.owner || "—")}</td><td>${esc(t.department || "—")}</td>
      <td class="muted">${esc((t.updated_at || "").slice(0, 10) || "—")}</td>
      <td class="muted">${t.records ? t.records + " 条" : "—"}</td>
      <td class="actions-cell"><div class="actions" style="justify-content:flex-end"><button class="btn" data-dt-view="${esc(t.code)}">详情</button>
        ${_dtCanManage && t.status !== "published" ? `<button class="btn primary" data-dt-pub="${esc(t.code)}">发布</button>
        <button class="btn" data-dt-edit="${esc(t.code)}">编辑</button>` : ""}</div></td>
    </tr>`).join("") + `</tbody></table>` : `<div class="empty" style="padding:42px 0"><div style="font-size:14px;color:#1F2329;margin-bottom:6px">还没有决策表</div><div style="font-size:12px;margin-bottom:12px">先新建一张草稿，配置条件→动作；发布后审核命中才会执行。</div><button class="btn primary" data-dt-new-empty>新建第一张决策表</button></div>`;
  document.querySelectorAll("[data-dt-new-empty]").forEach(b => b.addEventListener("click", openDecisionCreate));
  document.querySelectorAll("[data-dt-new-empty]").forEach(b => b.style.display = _dtCanManage ? "" : "none");
  document.querySelectorAll("[data-dt-view]").forEach(b => b.addEventListener("click", () => openDecisionDetail(b.dataset.dtView)));
  document.querySelectorAll("[data-dt-edit]").forEach(b => b.addEventListener("click", () => openDecisionEdit(b.dataset.dtEdit)));
  document.querySelectorAll("[data-dt-pub]").forEach(b => b.addEventListener("click", async () => {
    if (!(await confirmAction("发布决策表", "发布后，当前空间启用决策表模块时，命中条件的审核会按该表执行。确认发布？", "确认发布"))) return;
    const r = await (await fetch(`/api/v1/decision-tables/${b.dataset.dtPub}/publish`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (r.error) { showToast(r.error, "err"); return; } showToast("决策表已发布"); dtRefreshRuleDomain();
  }));
}
async function openDecisionDetail(code) {
  const d = await (await fetch(`/api/v1/decision-tables/${encodeURIComponent(code)}`)).json();
  if (!d || d.error) { showToast(d.error || "读取失败", "err"); return; }
  const rows = d.rules || [];
  const cond = c => _dtCondText(c);
  const old = document.querySelector("#dt-detail-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "dt-detail-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(760px,calc(100vw - 36px));max-height:88vh;overflow:auto">
    <div class="settings-head"><div><h3>决策表详情</h3><div class="muted" style="font-size:11px;margin-top:3px">${esc(d.code)} · ${esc(d.name)}</div></div><button class="ws-close" data-dtd-close>×</button></div>
    <div class="dt-detail-meta"><span class="pill ${d.status === "published" ? "published" : "draft"}">${esc(d.status === "published" ? "已发布" : "草稿")}</span><span>命中策略：${esc(d.hit_policy === "collect" ? "收集全部命中" : "首次命中")}</span><span>版本：${esc(d.version || "—")}</span><span class="pill draft">规则形式：决策表组合多条件</span></div>
    <table class="table dt-detail-table"><thead><tr><th style="width:50px">行</th><th>条件（when）</th><th>动作（then）</th></tr></thead><tbody>${rows.map((r, i) => `<tr><td class="muted">${i + 1}</td><td>${(r.when || []).map(x => `<span class="dt-cond">${esc(cond(x))}</span>`).join(" ") || "—"}</td><td><b>${esc(r.message || "—")}</b><div class="muted">严重度：${esc(r.severity || "warning")}${r.suggestion ? " · " + esc(r.suggestion) : ""}</div></td></tr>`).join("") || `<tr><td colspan="3" class="empty">没有规则行</td></tr>`}</tbody></table>
    <div class="dt-detail-note">决策表只有发布后、且当前工作空间启用决策表模块时，才会参与审核。判定时按当前文档类型和指标事实求值。</div>
    <div class="actions" style="margin-top:14px;justify-content:flex-end">${d.status !== "published" ? `<button class="btn" id="dtd-edit">编辑草稿</button><button class="btn primary" id="dtd-pub">发布</button>` : `<button class="btn" id="dtd-copy">复制为新草稿</button>`}<button class="btn" data-dtd-close>关闭</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove(); mask.querySelectorAll("[data-dtd-close]").forEach(b => b.onclick = close); mask.onclick = e => { if (e.target === mask) close(); };
  mask.querySelector("#dtd-pub")?.addEventListener("click", async () => {
    if (!(await confirmAction("发布决策表", "发布后，当前空间启用决策表模块时，命中条件的审核会按该表执行。确认发布？", "确认发布"))) return;
    const r = await (await fetch(`/api/v1/decision-tables/${encodeURIComponent(code)}/publish`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (r.error) { showToast(r.error, "err"); return; } close(); showToast("决策表已发布"); dtRefreshRuleDomain();
  });
  mask.querySelector("#dtd-edit")?.addEventListener("click", () => { close(); openDecisionEdit(code); });
  mask.querySelector("#dtd-copy")?.addEventListener("click", async () => {
    const newCode = (code + "-COPY" + Date.now().toString().slice(-4)).slice(0, 40);
    const r = await (await fetch(`/api/v1/decision-tables/${encodeURIComponent(code)}/copy`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ new_code: newCode }) })).json();
    if (r.error) { showToast(r.error, "err"); return; } close(); showToast("已复制为草稿"); dtRefreshRuleDomain();
  });
}

async function openDecisionEdit(code) {
  const d = await (await fetch(`/api/v1/decision-tables/${encodeURIComponent(code)}`)).json();
  if (!d || d.error) { showToast(d.error || "读取失败", "err"); return; }
  openDecisionEditor(d);
}

function openDecisionCreate() {
  if (currentRole === "reviewer") { showToast("审核员只读决策表，请联系业务管理员维护", "err"); return; }
  openDecisionEditor(null);
}
function _dtWhen(r) {
  const w = (r && r.when) || [];
  if (w.length === 1 && w[0] && Array.isArray(w[0].any)) return { mode: "any", conds: w[0].any.map(x => ({ ...x })) };
  if (w.length === 1 && w[0] && Array.isArray(w[0].all)) return { mode: "and", conds: w[0].all.map(x => ({ ...x })) };
  return { mode: "and", conds: (Array.isArray(w) ? w : []).map(x => ({ ...x })) };
}
function _dtCondText(c) {
  if (!c) return "—";
  if (Array.isArray(c.any)) return `任一：${c.any.map(_dtCondText).join(" 或 ")}`;
  if (Array.isArray(c.all)) return `全部：${c.all.map(_dtCondText).join(" 且 ")}`;
  if (c.metric) return `${c.metric} ${c.op || ""} ${c.value ?? c.values ?? (c.lo != null ? c.lo + "~" + c.hi : "")}`;
  return JSON.stringify(c);
}
function _dtCondHtml(c, ri, ci) {
  const ops = [">=", "<=", ">", "<", "=", "!=", "contains", "before", "after"];
  return `<div class="dt-cond-row" data-dt-cond-row="${ci}">
    <input class="field" data-dt-metric="${ri}-${ci}" value="${esc(c.metric || "")}" placeholder="指标，如 合同金额">
    <select class="field" data-dt-op="${ri}-${ci}">${ops.map(x => `<option value="${x}" ${(c.op || ">=") === x ? "selected" : ""}>${x}</option>`).join("")}</select>
    <input class="field" data-dt-value="${ri}-${ci}" value="${esc(c.value ?? "")}" placeholder="目标值">
    <button type="button" class="btn" data-dt-remove-cond="${ci}" title="删除条件">删除条件</button>
  </div>`;
}
function _dtRowHtml(r, ri) {
  const mode = r.mode === "any" ? "any" : "and";
  const conds = (r.conds && r.conds.length) ? r.conds : [{ metric: "", op: ">=", value: "" }];
  return `<div class="dt-row" data-dt-row="${ri}">
    <div class="dt-row-head"><b>规则行 ${ri + 1}</b><span class="muted">多条件 ${mode === "any" ? "任一满足" : "全部满足"}才命中</span><button type="button" class="btn" data-dt-remove-row="${ri}">删除规则行</button></div>
    <div class="dt-cond-mode">条件关系
      <select class="field" data-dt-mode="${ri}"><option value="and" ${mode === "and" ? "selected" : ""}>且 · 全部满足</option><option value="any" ${mode === "any" ? "selected" : ""}>或 · 任一满足</option></select>
    </div>
    <div class="dt-cond-list" data-dt-cond-list="${ri}">${conds.map((c, ci) => _dtCondHtml(c, ri, ci)).join("")}</div>
    <div class="actions" style="margin:4px 0 10px"><button type="button" class="btn" data-dt-add-cond="${ri}">+ 增加条件</button></div>
    <div class="dt-grid">
      <label>严重度<select class="field" data-dt-sev="${ri}"><option value="critical" ${r.severity === "critical" ? "selected" : ""}>严重</option><option value="warning" ${r.severity === "warning" ? "selected" : ""}>一般</option><option value="info" ${r.severity === "info" ? "selected" : ""}>提示</option></select></label>
      <label class="wide">命中说明<input class="field" data-dt-msg="${ri}" value="${esc(r.message || "")}" placeholder="命中后给审核员看的问题描述"></label>
      <label class="wide">建议<input class="field" data-dt-sug="${ri}" value="${esc(r.suggestion || "")}" placeholder="可选，命中后的处理建议"></label>
    </div>
  </div>`;
}
function openDecisionEditor(d) {
  if (currentRole === "reviewer") { showToast("审核员只读决策表，请联系业务管理员维护", "err"); return; }
  const isEdit = !!d;
  const parsed = (d && d.rules && d.rules.length) ? d.rules.map(r => {
    const w = _dtWhen(r);
    return { mode: w.mode, conds: w.conds, severity: r.severity || "warning", message: r.message || "", suggestion: r.suggestion || "" };
  }) : [{ mode: "and", conds: [{ metric: "", op: ">=", value: "" }], severity: "warning", message: "", suggestion: "" }];
  let state = parsed;
  const old = document.querySelector("#dt-editor-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "dt-editor-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(860px,calc(100vw - 36px));max-height:90vh;overflow:auto">
    <div class="settings-head"><div><h3>${isEdit ? "编辑决策表" : "新建决策表"}</h3><div class="muted" style="font-size:11px;margin-top:3px">决策表 = 多条件组合 → 结论；一条规则可包含多个条件，选择“且/或”。</div></div><button class="ws-close" data-dt-close>×</button></div>
    <div class="dt-editor-top"><label>编码<input id="dt-edit-code" class="field" value="${esc(d?.code || "")}" ${isEdit ? "readonly" : ""} placeholder="如 DT-AMOUNT"></label><label>名称<input id="dt-edit-name" class="field" value="${esc(d?.name || "")}" placeholder="如 大额合同转人工"></label><label>命中策略<select id="dt-edit-policy" class="field"><option value="first" ${(!d || d.hit_policy !== "collect") ? "selected" : ""}>首次命中</option><option value="collect" ${d?.hit_policy === "collect" ? "selected" : ""}>收集全部命中</option></select></label></div>
    <div class="dt-editor-top" style="margin-top:8px">
      <label>适用范围（文档/业务类型，可多选；留空=全部类型）<input id="dt-edit-scope" data-dt-scope class="field" value="${esc(((d?.scope_types) || []).join(","))}" placeholder="如 采购合同,销售合同"></label>
      <label>灰度 %（0=全部关闭，100=全量生效）<input id="dt-edit-canary" data-dt-canary class="field" type="number" min="0" max="100" step="1" value="${d?.canary_percent == null ? 100 : Number(d.canary_percent)}"></label>
    </div>
    <div class="dt-editor-note">灰度按案例 ID 稳定分流（同一案例结论稳定）；适用范围按本次审核的业务文档类型判定，不匹配时求值结果显式 skipped（不伪装成未命中）。</div>
    <div class="dt-editor-note">规则行之间按顺序匹配；同一规则行内的条件按“且/或”组合。所有条件均为三值判定，缺事实时不会被当成满足。</div>
    <div id="dt-rows"></div>
    <div class="actions" style="margin-top:10px"><button class="btn" id="dt-add-row">+ 增加规则行</button><span class="muted" id="dt-editor-msg"></span></div>
    <div class="actions" style="margin-top:16px;justify-content:flex-end"><button class="btn" data-dt-close>取消</button><button class="btn primary" id="dt-save">保存草稿</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove(); mask.querySelectorAll("[data-dt-close]").forEach(b => b.onclick = close); mask.onclick = e => { if (e.target === mask) close(); };
  const sync = () => {
    mask.querySelectorAll("[data-dt-row]").forEach(row => {
      const ri = Number(row.dataset.dtRow);
      const mode = row.querySelector(`[data-dt-mode="${ri}"]`)?.value || "and";
      const conds = [...row.querySelectorAll("[data-dt-cond-row]")].map(x => ({
        metric: x.querySelector("[data-dt-metric]").value.trim(),
        op: x.querySelector("[data-dt-op]").value,
        value: x.querySelector("[data-dt-value]").value.trim(),
      }));
      state[ri] = { mode, conds, severity: row.querySelector(`[data-dt-sev="${ri}"]`).value,
        message: row.querySelector(`[data-dt-msg="${ri}"]`).value.trim(),
        suggestion: row.querySelector(`[data-dt-sug="${ri}"]`).value.trim() };
    });
  };
  const render = () => {
    mask.querySelector("#dt-rows").innerHTML = state.map((r, i) => _dtRowHtml(r, i)).join("");
    mask.querySelectorAll("[data-dt-add-cond]").forEach(b => b.onclick = () => {
      sync(); const ri = Number(b.dataset.dtAddCond); state[ri].conds.push({ metric: "", op: ">=", value: "" }); render();
    });
    mask.querySelectorAll("[data-dt-remove-cond]").forEach(b => b.onclick = () => {
      sync(); const row = b.closest("[data-dt-row]"); const ri = Number(row.dataset.dtRow);
      if (state[ri].conds.length <= 1) return; state[ri].conds.splice(Number(b.dataset.dtRemoveCond), 1); render();
    });
    mask.querySelectorAll("[data-dt-remove-row]").forEach(b => b.onclick = () => {
      sync(); if (state.length <= 1) return; state.splice(Number(b.dataset.dtRemoveRow), 1); render();
    });
  };
  render();
  mask.querySelector("#dt-add-row").onclick = () => {
    sync(); state.push({ mode: "and", conds: [{ metric: "", op: ">=", value: "" }], severity: "warning", message: "", suggestion: "" }); render();
  };
  mask.querySelector("#dt-save").onclick = async () => {
    sync();
    const code = mask.querySelector("#dt-edit-code").value.trim(), name = mask.querySelector("#dt-edit-name").value.trim();
    const msg = mask.querySelector("#dt-editor-msg");
    if (!code || !name) { msg.textContent = "编码和名称必填"; return; }
    if (!state.length) { msg.textContent = "至少保留一条规则行"; return; }
    for (const r of state) {
      if (!r.conds.length || r.conds.some(c => !c.metric || c.value === "")) { msg.textContent = "每条规则行至少一个完整条件"; return; }
    }
    const rules = state.map(r => ({
      when: r.mode === "any" ? [{ any: r.conds }] : r.conds,
      severity: r.severity, message: r.message, suggestion: r.suggestion,
    }));
    // P2-B3-03：适用范围 / 灰度随保存提交（旧实现固定 scope_types:[]、canary_percent:100，
    // UI 建的决策表永远是「全部类型 + 全量生效」，灰度/范围只能走脚本）。
    const scopeTypes = String(mask.querySelector("#dt-edit-scope")?.value || "")
      .split(/[,，;；\s]+/).map(x => x.trim()).filter(Boolean);
    const canaryRaw = mask.querySelector("#dt-edit-canary")?.value;
    const canary = (canaryRaw === "" || canaryRaw == null) ? 100 : Number(canaryRaw);
    if (!Number.isInteger(canary) || canary < 0 || canary > 100) {
      msg.textContent = "灰度必须为 0–100 的整数"; return;
    }
    const btn = mask.querySelector("#dt-save"); btn.disabled = true; btn.textContent = "保存中…";
    const url = isEdit ? `/api/v1/decision-tables/${encodeURIComponent(code)}` : "/api/v1/decision-tables";
    const res = await (await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code, name, rules, hit_policy: mask.querySelector("#dt-edit-policy").value, scope_types: scopeTypes, canary_percent: canary }) })).json();
    if (res.error) { msg.textContent = res.error; btn.disabled = false; btn.textContent = "保存草稿"; return; }
    close(); showToast(isEdit ? "决策表已更新" : "决策表草稿已创建"); dtRefreshRuleDomain();
    if (typeof loadNewDecisionList === "function") loadNewDecisionList();
  };
}

$("#btn-dt")?.addEventListener("click", loadDecisionTables);
$("#btn-dt-new")?.addEventListener("click", openDecisionCreate);

/* ===== 权限菜单 + 工作空间切换（重建补齐） ===== */
var __PERMS = null;

