/* 新建规则对话/最近规则：从 app.js 拆出；文件拆解仍留 app.js。 */
function renderNewRule(mode) {
  loadRuleSpaceContext();
  /* L84 E3：新建规则页「推荐点位」面板（GET /api/v1/audit-points/recommended，只读推荐）。
     面板挂在 #newrule 之前，切换 一句话/上传拆解/手工填写 三种模式时保留，不重复请求。*/
  try { renderNrRecommendedPanel(); } catch (e) { console.warn("推荐点位面板挂载失败", e); }
  let box = document.querySelector("#newrule #nr-panel");
  if (!box) {
    const host = $("#newrule");
    if (!host) return;
    box = document.createElement("div");
    box.id = "nr-panel";
    host.appendChild(box);
  }
  if (mode === "nl") {
    if (typeof renderRuleChat === "function") {
      renderRuleChat(box);
      if (typeof uxDirtyReset === "function") uxDirtyReset("newrule");
      return;
    }
    box.innerHTML = '<div class="empty">规则对话模块未加载</div>';
    box.querySelector("#nr-gen").addEventListener("click", async () => {
      const text = box.querySelector("#nr-text").value.trim();
      if (!text) return;
      box.querySelector("#nr-msg").textContent = "生成中…";
      const r = await (await fetch("/api/v1/rule/parse", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }) })).json();
      box.querySelector("#nr-msg").textContent = r.llm ? "已由模型生成" : "已用模板生成";
      var _slots = r.slots || {};
      const _isDt = r.representation === "decision_table";
      const _formNotice = _isDt
        ? `<div class="nr-form-reco"><b>系统判断：决策表组合多条件</b><div>${esc(r.form_reason || "检测到多个条件")}</div><button type="button" class="btn" id="nr-open-dt">打开决策表编辑器</button></div>`
        : `<div class="nr-form-reco single"><b>系统判断：单条参数规则</b><div>${esc(r.form_reason || "单指标/单阈值")}</div></div>`;
      box.querySelector("#nr-result").innerHTML = _formNotice + `
        <div class="muted" style="margin-bottom:6px">请确认/修改结构化结果后再保存（模型可能填错，人工确认是最后一道关）</div>
        <table class="table"><tbody>
          <tr><th style="width:120px">名称</th><td><input id="nr-f-name" class="field" style="width:100%" value="${esc(r.name || "")}"></td></tr>
          <tr><th>类别</th><td><select id="nr-f-cat" class="field" style="width:100%">${Object.entries(CATS).map(([k,v]) => `<option value="${k}"${(r.category===k)?" selected":""}>${esc(v)}</option>`).join("")}</select></td></tr>
          <tr><th>风险等级</th><td><select id="nr-f-rclass" class="field" style="width:100%">
              <option value="R1"${r.rclass==="R1"?" selected":""}>严重 · 命中后项目不通过</option>
              <option value="R3"${r.rclass==="R3"?" selected":""}>一般 · 命中后提示复核</option>
              <option value="R5"${r.rclass==="R5"?" selected":""}>提示 · 仅提示，不阻断项目</option>
            </select><div class="muted">不是规则难度；决定报告严重度。</div></td></tr>
          <tr><th>判据（可编辑）</th><td><textarea id="nr-f-crit" class="field" style="width:100%;min-height:70px">${esc(_slots.criterion || "")}</textarea></td></tr>
          <tr><th>执行计划</th><td><div style="display:flex;gap:6px;flex-wrap:wrap">
            <select id="nr-f-ev" class="field"><option value="document" selected>证据：整份文档</option><option value="block">证据：区块</option><option value="row">证据：行</option><option value="sheet">证据：Sheet</option></select>
            <select id="nr-f-agg" class="field"><option value="all" selected>汇总：全部</option><option value="single">汇总：单值</option><option value="any">汇总：任一</option></select>
            <select id="nr-f-method" class="field"><option value="semantic" selected>方法：语义</option><option value="deterministic">方法：确定性</option><option value="hybrid">方法：混合</option></select>
            <select id="nr-f-fallback" class="field"><option value="abstain" selected>不足：转人工</option><option value="ask">不足：补证</option><option value="fail">不足：判不满足</option></select>
          </div><div class="muted" style="font-size:12px;margin-top:3px">由系统生成计划，不是单选“执行模式”。</div></td></tr>
          <tr><th>适用范围 <em class="req">发布必填</em></th><td>
            <input id="nr-f-types" class="field" style="width:100%" value="${esc(((window.__nrScope && window.__nrScope.docTypes) || []).join("、"))}" placeholder="例如：xlsx、docx、pdf（逗号/顿号分隔）；留空则继承当前空间文档类型">
            <div class="muted" style="font-size:12px;margin-top:3px">已自动带入当前空间文档类型（可改，不是黑盒）；未声明作用域的规则发布时会被 scope_missing 阻断。</div></td></tr>
          <tr><th>适用条件</th><td><input id="nr-f-when" class="field" style="width:100%" placeholder="例如：卤制工序；可留空表示不限"></td></tr>
          <tr><th>必需证据</th><td><input id="nr-f-reqev" class="field" style="width:100%" placeholder="例如：工序参数表 · 实测中心温度（记录/程序类规则发布必填）"></td></tr>
        </tbody></table>
        <div class="actions" style="margin-top:10px"><button id="nr-save" class="btn primary" ${_isDt ? "disabled title=\"该规则应由决策表组合执行\"" : ""}>确认并保存为草稿</button>
          <span class="muted" id="nr-map">${_isDt ? "已判断为决策表组合，请使用上方决策表编辑器" : ""}</span></div>`;
      box.querySelector("#nr-open-dt")?.addEventListener("click", () => openDecisionCreate());
      // T-83（D-L2-01）：与手工表单同口径的保存 single-flight——提交期间禁用按钮，
      // 同一 JS tick 的重复点击不会再发第二个 /api/v1/rules/custom 请求。
      var _nrSaveBtn = box.querySelector("#nr-save");
      var _nrSaveBusy = false;
      box.querySelector("#nr-save").addEventListener("click", async () => {
        if (_nrSaveBusy) return;
        var _name = box.querySelector("#nr-f-name").value.trim();
        if (!_name) { alert("请填写规则名称"); return; }
        var _sl = Object.assign({}, _slots);
        var _crit = box.querySelector("#nr-f-crit").value.trim();
        if (_crit) _sl.criterion = _crit;
        _sl.evidence_scope = [box.querySelector("#nr-f-ev").value];
        _sl.aggregation = box.querySelector("#nr-f-agg").value;
        _sl.evaluation_kind = box.querySelector("#nr-f-method").value;
        _sl.fallback = box.querySelector("#nr-f-fallback").value;
        // T-185：适用范围/适用条件/必需证据随草稿落 scope；后端 infer_scope 补空，推断值可解释
        var _typesRaw = (box.querySelector("#nr-f-types")?.value || "").trim();
        var _scopeTypes = _typesRaw.split(/[、,，;；\s]+/).map(function (x) { return x.trim(); }).filter(Boolean);
        var _scopeWhen = (box.querySelector("#nr-f-when")?.value || "").trim();
        var _reqEv = (box.querySelector("#nr-f-reqev")?.value || "").trim();
        if (_reqEv) _sl.required_evidence = _reqEv;
        var _scope = { applicable_types: _scopeTypes, applicable_when: _scopeWhen,
                       evidence_scope: _sl.evidence_scope || ["document"] };
        if (_reqEv) _scope.required_evidence = _reqEv;
        var _body = { name: _name, category: box.querySelector("#nr-f-cat").value,
                      rclass: box.querySelector("#nr-f-rclass").value, slots: _sl,
                      scope: _scope, infer_scope: true,
                      point_id: "", source: "manual" };
        _nrSaveBusy = true;
        if (_nrSaveBtn) { _nrSaveBtn.disabled = true; _nrSaveBtn.textContent = "保存中…"; }
        let s = {};
        try {
          s = await (await fetch("/api/v1/rules/custom", { method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify(_body) })).json();
        } catch (e) {
          alert("保存失败，请稍后重试");
          return;
        } finally {
          _nrSaveBusy = false;
          if (_nrSaveBtn) { _nrSaveBtn.disabled = !!_isDt; _nrSaveBtn.textContent = "确认并保存为草稿"; }
        }
        if (s.error) { alert(s.error); return; }
        var m = s.mapping || {};
        var _infMsg = s.scope_inferred && s.scope_inferred.applied
          ? "；适用范围已自动推断（" + (s.scope_status || "declared") + "），可在草稿「继续编辑」确认" : "";
        box.querySelector("#nr-map").textContent = (m.mapped
          ? ("已映射点位：" + (m.point_id || "") + " " + (m.point_name || "") + (m.override ? "（手动指定）" : ""))
          : "未映射到平台点位（仅按自定义规则执行）") + _infMsg;
        alert("已保存为草稿");
        if (typeof uxDirtyClear === "function") uxDirtyClear("newrule");
        loadRules(); loadRecentRules();
      });
    });
  } else {
    renderManualRule(box);
  }
  // 表单内部页签切换会重建字段；以重建后的空表单为 dirty 基线，避免无改动的页签切换被拦截。
  if (typeof uxDirtyReset === "function") uxDirtyReset("newrule");
}
async function loadRecentRules() {
  const rules = await (await fetch("/api/v1/rules")).json();
  const box = $("#nr-recent");
  if (!box) return;
  const list = (Array.isArray(rules) ? rules : []).slice(0, 8);
  box.innerHTML = list.length ? `<table class="table"><thead><tr><th style="width:56px">序号</th><th>名称</th><th>编码</th><th>类别</th><th>状态</th></tr></thead><tbody>` +
    list.map((r, i) => `<tr><td class="muted">${list.length - i}</td><td>${esc(r.name)}</td>
      <td class="muted">${esc(r.code)}</td><td>${esc(CATS[r.category] || r.category)}</td>
      <td><span class="pill ${r.status}">${esc(STATUS[r.status] || r.status)}</span></td></tr>`).join("") + `</tbody></table>`
    : `<div class="muted">还没有规则</div>`;
}
$("#btn-nr-file")?.addEventListener("click", renderNewRuleFile);
$("#btn-nr-nl")?.addEventListener("click", () => renderNewRule("nl"));
$("#btn-nr-manual")?.addEventListener("click", () => renderNewRule("manual"));
document.querySelectorAll("[data-nr-mode]").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("[data-nr-mode]").forEach(x => x.classList.toggle("active", x === b));
  const m = b.dataset.nrMode;
  if (m === "file") renderNewRuleFile(); else renderNewRule(m);
}));

/* 规则进化：进化建议 / 错题集 切换 */
document.querySelectorAll("[data-evt]").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("[data-evt]").forEach(x => x.classList.remove("on"));
  b.classList.add("on");
  const isWrong = b.dataset.evt === "wrong";
  const ep = $("#evolve-panel"), wp = $("#wrong-panel");
  if (ep) ep.hidden = isWrong;
  if (wp) wp.hidden = !isWrong;
  if (isWrong) $("#btn-errorbook")?.click(); else $("#btn-evolution")?.click();
}));


/* ===================== 规则进化：反馈台账 → RSI → 规则库 ===================== */
const KIND_LABEL = { confirm: "确认问题", false_positive: "判为误报", need_evidence: "要求补证", manual: "人工新增", supplement: "补充证据" };
const KIND_PILL = { confirm: "published", false_positive: "draft", need_evidence: "r", manual: "draft", supplement: "r" };
async function loadEvolutionPage() {
  const confBox = $("#evo-conf");
  if (confBox && !confBox.hidden) loadJev();
  const kind = $("#fb-kind")?.value || "";
  const _isReviewer = currentRole === "reviewer";
  // 审核员不能读租户全量反馈（GET /api/v1/feedback 是管理员接口，403）；
  // 规则进化对审核员是“只看自己提交的反馈”，走 /api/v1/feedback/mine。
  let d;
  if (_isReviewer) {
    d = await (await fetch("/api/v1/feedback/mine")).json();
  } else {
    d = await (await fetch("/api/v1/feedback" + (kind ? `?kind=${kind}` : ""))).json();
  }
  let items = Array.isArray(d.items) ? d.items : [];
  if (_isReviewer) {
    const _me = (currentUser && (currentUser.name || currentUser.sub)) || "";
    items = items.map(x => {
      let payload = {};
      try { payload = JSON.parse(x.payload || "{}") || {}; } catch (e) {}
      return Object.assign({}, x, {
        kind_label: KIND_LABEL[x.kind] || x.kind || "",
        reason: payload.reason || payload.detail || "",
        root_cause: payload.root_cause || "",
        suggestion: payload.suggestion || "",
        attr_source: payload.source || "",
        rsi_status: x.rsi_status || "pending",
        actor: (_me && x.actor === "user-reviewer") ? _me : (x.actor || ""),
      });
    });
    if (kind) items = items.filter(x => x.kind === kind);
  }
  let st = d.stats || {};
  if (_isReviewer && !d.stats) {
    const _by = {};
    items.forEach(x => { _by[x.kind || ""] = (_by[x.kind || ""] || 0) + 1; });
    const _settled = items.filter(x => x.rsi_status === "settled").length;
    const _polarity = { confirm: "positive", false_positive: "negative", manual: "negative", need_evidence: "neutral", supplement: "neutral" };
    st = {
      total: items.length, by_kind: _by,
      positive: Object.keys(_by).filter(k => _polarity[k] === "positive").reduce((n, k) => n + _by[k], 0),
      negative: Object.keys(_by).filter(k => _polarity[k] === "negative").reduce((n, k) => n + _by[k], 0),
      pending: items.filter(x => x.rsi_status === "pending").length,
      settled: _settled,
      settle_rate: items.length ? Math.round(_settled / items.length * 1000) / 1000 : 0,
    };
  }
  const by = st.by_kind || {};
  fbCache = items;
  $("#evo-kpis").innerHTML = [
    { ico: "", label: "反馈总数", value: st.total || 0, bg: "#F0F4FF", color: "#3370FF" },
    { ico: "", label: "正向（确认）", value: st.positive || 0, bg: "#E8F8F0", color: "#00B578" },
    { ico: "", label: "反向（误报+漏报）", value: st.negative || 0, bg: "#FEF0EF", color: "#F54A45" },
    { ico: "", label: "待沉淀", value: st.pending || 0, bg: "#FFF6E8", color: "#FF8800" },
    { ico: "", label: "沉淀率", value: Math.round((st.settle_rate || 0) * 100) + "%", bg: "#F0F4FF", color: "#3370FF" },
  ].map(k => `<div class="kpi">    <b style="color:${k.color}">${esc(String(k.value))}</b><span>${k.label}</span></div>`).join("");
  $("#evo-badge").textContent = st.pending ? String(st.pending) : "";
  const _evoK = document.querySelector("#evo-kpis");
  if (_evoK) _evoK.style.display = ["evolve", "conf"].includes(evoTab) ? "none" : "grid";
  const _rev = currentRole === "reviewer";
  ["#evo-run-suggest", "#evo-point-suggest"].forEach(sel => { const el = document.querySelector(sel); if (el) el.style.display = _rev ? "none" : ""; });
  const _guide = document.querySelector("#evo-all .evo-note");
  if (_guide) _guide.textContent = _rev
    ? "审核员只读：这里汇总你在审核工作台提交的确认/误报/补证反馈；候选生成和规则发布由业务管理员完成。"
    : "审核员的确认/误报/补证/人工新增会进入这里。待沉淀项可生成修订或新规则草稿；审核员负责反馈，业务管理员负责确认和发布。";

  // 台账
  $("#fb-out").innerHTML = items.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th style="width:100px">类型</th><th>问题 / 规则</th><th>理由 / 证据</th><th style="width:96px">部门</th><th style="width:150px">来源 · 时间</th><th style="width:80px">状态</th><th style="width:150px">操作</th>
    </tr></thead><tbody>` +
    items.map((x, i) => `<tr>
      <td>${items.length - i}</td>
      <td><span class="pill ${KIND_PILL[x.kind] || ""}">${esc(x.kind_label || x.kind)}</span></td>
      <td><div style="font-weight:500">${esc(x.title || "—")}</div>
        <div class="muted" style="font-size:12px;margin-top:2px">${esc(x.rule_code || "—")}</div></td>
      <td class="muted">${esc((x.reason || "—").slice(0, 32))}
        ${x.root_cause ? `<div style="font-size:11px;margin-top:2px">根因：${esc(x.root_cause)} <span class="pill ${x.attr_source === "llm" ? "published" : "draft"}">${x.attr_source === "llm" ? "模型" : "兜底"}</span></div>` : ""}</td>
      <td class="muted">${esc(x.actor || "—")} · ${esc((x.created_at || "").slice(5, 16))}</td>
      <td>${esc({ pending: "待沉淀", settled: "已沉淀", ignored: "已忽略" }[x.rsi_status] || x.rsi_status)}</td>
      <td><div style="display:flex;gap:6px;white-space:nowrap">
        ${currentRole === "reviewer" ? `<span class="muted">只读</span>` : x.rsi_status === "pending" ? `<button class="btn primary" data-fb-settle="${esc(x.id)}">沉淀</button>
          <button class="btn" data-fb-ignore="${esc(x.id)}">忽略</button>` : `<span class="muted">${esc(x.rsi_action || "—")}</span>`}
      </div></td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">暂无反馈</div>`;

  // 错题集 / 漏报集
  const wrong = items.filter(x => x.kind === "false_positive");
  const miss = items.filter(x => x.kind === "manual");
  $("#wrong-out").innerHTML = wrong.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>规则</th><th>问题</th><th>审核员理由</th><th>时间</th><th>状态</th><th style="width:230px">操作</th>
    </tr></thead><tbody>` + wrong.map((x, i) => `<tr>
      <td class="muted">${wrong.length - i}</td><td class="muted">${esc(x.rule_code)}</td><td><b>${esc(x.title)}</b></td>
      <td class="muted">${esc(x.reason || "—")}</td><td class="muted">${esc(x.created_at)}</td>
      <td>${esc({ pending: "待沉淀", settled: "已沉淀", ignored: "已忽略" }[x.rsi_status] || x.rsi_status)}</td>
      <td><div style="display:flex;gap:6px;white-space:nowrap">
        ${currentRole === "reviewer" ? `<span class="muted">只读</span>` : x.rsi_status === "pending" ? `<button class="btn primary" data-fb-settle="${esc(x.id)}">沉淀规则</button>
          <button class="btn" data-fb-ignore="${esc(x.id)}">忽略</button>` : `<span class="muted">${esc(x.rsi_action || "—")}</span>`}
      </div></td></tr>`).join("") + `</tbody></table>` : `<div class="empty">暂无错题</div>`;
  $("#miss-out").innerHTML = miss.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>问题</th><th>说明</th><th>审核员</th><th>时间</th><th>状态</th><th style="width:230px">操作</th>
    </tr></thead><tbody>` + miss.map((x, i) => `<tr>
      <td class="muted">${miss.length - i}</td><td><b>${esc(x.title)}</b></td><td class="muted">${esc(x.reason || "—")}</td>
      <td class="muted">${esc(x.actor || "—")}</td><td class="muted">${esc(x.created_at)}</td>
      <td>${esc({ pending: "待沉淀", settled: "已沉淀", ignored: "已忽略" }[x.rsi_status] || x.rsi_status)}</td>
      <td><div style="display:flex;gap:6px;white-space:nowrap">
        ${currentRole === "reviewer" ? `<span class="muted">只读</span>` : x.rsi_status === "pending" ? `<button class="btn primary" data-fb-settle="${esc(x.id)}">沉淀新规则</button>
          <button class="btn" data-fb-ignore="${esc(x.id)}">忽略</button>` : `<span class="muted">${esc(x.rsi_action || "—")}</span>`}
      </div></td></tr>`).join("") + `</tbody></table>` : `<div class="empty">暂无漏报（人工新增问题会出现在这里）</div>`;

  // 已沉淀
  const settled = items.filter(x => x.rsi_status === "settled");
  $("#settled-out").innerHTML = settled.length ? `<table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>类型</th><th>规则</th><th>问题</th><th>动作</th><th>时间</th>
    </tr></thead><tbody>` + settled.map((x, i) => `<tr>
      <td class="muted">${settled.length - i}</td><td><span class="pill published">${esc(x.kind_label)}</span></td>
      <td class="muted">${esc(x.rule_code)}</td><td>${esc(x.title)}</td>
      <td>${esc({ revise: "修订规则", new_rule: "新建规则", ignore: "忽略" }[x.rsi_action] || x.rsi_action)}</td>
      <td class="muted">${esc(x.created_at)}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">还没有沉淀记录</div>`;

  document.querySelectorAll("[data-fb-settle]").forEach(b => b.addEventListener("click", async () => {
    const item = (fbCache || []).find(x => x.id === b.dataset.fbSettle) || {};
    const old = document.querySelector("#fb-settle-modal"); if (old) old.remove();
    const mask = document.createElement("div"); mask.id = "fb-settle-modal"; mask.className = "modal-mask";
    mask.innerHTML = `<div class="modal" style="width:min(560px,calc(100vw - 32px))"><div class="settings-head"><div><h3>沉淀反馈</h3><div class="muted" style="font-size:11px;margin-top:3px">${esc(item.rule_code || "")} · ${esc(item.title || "")}</div></div><button class="ws-close" data-fbs-close>×</button></div>
      <div class="dm-note">沉淀只会生成草稿，不会自动发布；规则无需审批，生成后到「草稿箱」点「发布生效」即可参与审核。</div>
      <div class="fb-settle-options"><label><input type="radio" name="fbs-action" value="revise" checked><b>修订现有规则</b><span>生成现有规则的新版本草稿，保留历史版本。</span></label><label><input type="radio" name="fbs-action" value="new_rule"><b>新建规则草稿</b><span>用于反馈对应的是一条新规则，生成独立草稿。</span></label></div>
      <label class="np-field wide" style="margin-top:10px"><span>沉淀说明（选填）</span><textarea id="fbs-note" class="field" style="min-height:72px" placeholder="例如：确认是阈值过严，下一版将上限从 85℃ 调整到 90℃"></textarea></label>
      <label style="display:flex;align-items:center;gap:6px;margin-top:8px;font-size:12px"><input type="checkbox" id="fbs-autopublish"> <b>同时发布生效</b><span class="muted">（默认关闭：只生成草稿，人工到草稿箱点「发布生效」；勾选则本次沉淀立即发布，下一轮审核生效）</span></label>
      <div class="actions" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-fbs-close>取消</button><button class="btn primary" id="fbs-save">生成草稿</button></div><div id="fbs-msg" class="muted" style="font-size:11px;margin-top:6px"></div></div>`;
    document.body.appendChild(mask);
    const close = () => mask.remove(); mask.querySelectorAll("[data-fbs-close]").forEach(x => x.onclick = close); mask.onclick = e => { if (e.target === mask) close(); };
    mask.querySelector("#fbs-save").onclick = async () => {
      const action = mask.querySelector('input[name="fbs-action"]:checked')?.value || "revise";
      const note = mask.querySelector("#fbs-note").value.trim();
      const btn = mask.querySelector("#fbs-save"); btn.disabled = true; btn.textContent = "生成中…";
      const autoPublish = !!mask.querySelector("#fbs-autopublish")?.checked;
      const r = await (await fetch(`/api/v1/feedback/${b.dataset.fbSettle}/settle`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, note, auto_publish: autoPublish }) })).json();
      if (r.error) { mask.querySelector("#fbs-msg").textContent = r.error; btn.disabled = false; btn.textContent = "生成草稿"; return; }
      close(); showToast(r.message || "已生成规则草稿"); loadEvolutionPage(); loadRules();
    };
  }));
  document.querySelectorAll("[data-fb-ignore]").forEach(b => b.addEventListener("click", async () => {
    if (!confirm("忽略这条反馈？")) return;
    await fetch(`/api/v1/feedback/${b.dataset.fbIgnore}/settle`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "ignore" }) });
    loadEvolutionPage();
  }));
  // T-177 V1：空间准确率看板（独立文件 web/accuracy_board.js，惰性加载，不改 app.js）
  if (typeof loadAccuracyBoard === "function") loadAccuracyBoard();
}

/* T-177 V1：空间准确率看板脚本惰性加载（文件未随 index/reviewer.html 的 script 列表发布，
   因此在这里按需注入；loadAccuracyBoard 未定义时注入，加载完成后由 loadEvolutionPage 调用）。 */
(function () {
  if (window.__rpAccBoardScript) return;
  window.__rpAccBoardScript = true;
  var s = document.createElement("script");
  s.src = "/accuracy_board.js";
  s.async = true;
  document.head.appendChild(s);
})();

document.querySelectorAll("#evo-tabs .seg-tab").forEach(t => t.addEventListener("click", () => {
  document.querySelectorAll("#evo-tabs .seg-tab").forEach(x => x.classList.remove("on"));
  t.classList.add("on");
  evoTab = t.dataset.evt;
  ["all", "wrong", "miss", "evolve", "settled", "conf", "attr", "cand", "ver"].forEach(k => {
    const el = $("#evo-" + k); if (el) el.hidden = k !== evoTab;
  });
  if (evoTab === "evolve") { const _k = $("#evo-kpis"); if (_k) _k.style.display = "none"; $("#btn-evolution")?.click(); }
  else if (evoTab === "conf") { const _k = $("#evo-kpis"); if (_k) _k.style.display = "none"; loadJev(); }
  else if (evoTab === "attr") { const _k = $("#evo-kpis"); if (_k) _k.style.display = "none"; loadEvolutionAttribution(); }
  else if (evoTab === "cand") { const _k = $("#evo-kpis"); if (_k) _k.style.display = "none"; loadEvolutionCandidates(); }
  else if (evoTab === "ver") { const _k = $("#evo-kpis"); if (_k) _k.style.display = "none"; loadEvolutionVersions(); }
  else loadEvolutionPage();
}));
$("#fb-kind")?.addEventListener("change", () => loadEvolutionPage());
$("#evo-run-suggest")?.addEventListener("click", () => { $("#btn-evolution")?.click(); });
async function loadPointSuggestions() {
  const box = document.querySelector("#evolution-points-out");
  if (!box) return;
  box.innerHTML = `<div class="muted" style="font-size:11px;padding:8px 0">正在统计点位建议…</div>`;
  try {
    const list = await (await fetch("/api/v1/evolution/points")).json();
    const rows = (Array.isArray(list) ? list : []).filter(x => Number(x.hit || 0) > 0 || Number(x.false_positive || 0) > 0);
    box.innerHTML = `<div class="evo-suggest-head" style="margin-top:12px"><div><b>点位级建议 ${rows.length} 条</b><div class="muted">按点位统计误报；用于补充或调整平台点位。</div></div><button class="btn" data-evo-point-close>收起</button></div>` +
      (rows.length ? `<table class="table evo-suggest-table"><thead><tr><th>点位</th><th class="num">命中</th><th class="num">误报</th><th class="num">误报率</th><th>建议</th></tr></thead><tbody>` +
        rows.slice(0, 30).map(x => `<tr><td><b>${esc(x.point_id || "")}</b><div class="muted" style="font-size:11px">${esc(x.name || "")}</div></td><td class="num">${x.hit || 0}</td><td class="num">${x.false_positive || 0}</td><td class="num">${Math.round((x.override_rate || 0) * 100)}%</td><td class="muted">${esc(x.suggestion || "")}</td></tr>`).join("") + `</tbody></table>` : `<div class="evo-empty"><div class="evo-empty-title">暂无点位建议</div><div>点位被复核过之后，这里才会出现误报率和调整建议。</div></div>`);
    box.querySelector("[data-evo-point-close]")?.addEventListener("click", () => { box.innerHTML = ""; });
  } catch (e) { box.innerHTML = `<div class="muted" style="font-size:11px;padding:8px 0">点位建议加载失败</div>`; }
}
$("#evo-point-suggest")?.addEventListener("click", () => { loadPointSuggestions(); });

/* 规则接入矩阵：规则 → 点位 → 本体/Jev/RSI/冲突 */

/* ===================== L18：自进化前端 3 视图（归因复核 / 候选门禁 / 生效版本与回滚） =====================
   依据：docs/CURRENT/59-自进化链路再评估_20261123.md S2/S3/S4；后端只读端点：
     GET /api/v1/evolution/attribution   归因复核（统一枚举 + 双口径映射徽标 + 覆盖率）
     GET /api/v1/evolution/candidates    候选/门禁时间线（状态 + 时间 + 预注册 hash 校验）
     GET /api/v1/evolution/versions      生效版本与回滚（版本列表 + 只读回滚记录）
   hash 篡改阻断在服务端门禁读取时完成，前端只展示校验结果；回滚按钮走既有
   POST /api/v1/rules/{rule_id}/rollback（旧生效版本继续执行到新版本发布）。
   节点登记：tests/fixtures/node_inventory.yaml 在 HEAD 42ad30b 不存在；节点 id 以内嵌
   data-node-id="evo.attr|evo.cand|evo.ver" 标记，G2 节点登记门落地后按此登记。 */
const L18_COLORS = {
  ok: { bg: "#E8F8F0", fg: "#00B578" }, warn: { bg: "#FFF6E8", fg: "#FF8800" },
  bad: { bg: "#FEF0EF", fg: "#F54A45" }, info: { bg: "#F0F4FF", fg: "#3370FF" },
  muted: { bg: "#F5F6FA", fg: "#6B7280" },
};
function l18Pill(text, kind) {
  const c = L18_COLORS[kind] || L18_COLORS.muted;
  return `<span class="pill" style="background:${c.bg};color:${c.fg}">${esc(String(text == null ? "" : text))}</span>`;
}
function l18Kpis(list) {
  return (list || []).map(k => `<div class="kpi"><b style="color:${k.color || "#3370FF"}">${esc(String(k.value == null ? "-" : k.value))}</b><span>${esc(k.label || "")}</span></div>`).join("");
}
function l18Msg(sel, text) { const el = document.querySelector(sel); if (el) el.textContent = text || ""; }
function l18Empty(title, desc) {
  return `<div class="evo-empty"><div class="evo-empty-title">${esc(title || "暂无数据")}</div><div>${esc(desc || "")}</div></div>`;
}
function l18Pct(v) { return v == null ? "-" : Math.round(Number(v) * 1000) / 10 + "%"; }

/* 断点① 归因复核：统一枚举映射徽标 + 复核列表 + 未知值明细 */
async function loadEvolutionAttribution() {
  const box = $("#evo-attr-out"); if (!box) return;
  l18Msg("#evo-attr-msg", "加载中…");
  try {
    const d = await (await fetch("/api/v1/evolution/attribution?limit=200")).json();
    l18Msg("#evo-attr-msg", "");
    if (!d || d.ok === false) { box.innerHTML = l18Empty("归因复核加载失败", (d && (d.error || d.code)) || "接口不可用"); return; }
    const st = d.stats || {};
    const statsBox = $("#evo-attr-stats");
    if (statsBox) statsBox.innerHTML = l18Kpis([
      { label: "归因样本", value: st.scanned || 0, color: "#3370FF" },
      { label: "已映射", value: st.known || 0, color: "#00B578" },
      { label: "未知（other）", value: st.unknown || 0, color: "#F54A45" },
      { label: "未归因", value: st.empty || 0, color: "#FF8800" },
      { label: "映射率", value: l18Pct(st.mapped_rate), color: "#3370FF" },
    ]);
    const mapBox = $("#evo-attr-map");
    const map = (d.enum && d.enum.mapping) || {};
    const rates = map.rates || {};
    if (mapBox) {
      const af = map.agent_fp_to_evolution || {};
      const evm = map.evolution_to_agent_fp || {};
      mapBox.innerHTML = `<div class="evo-suggest-head" style="margin-top:10px"><div><b>统一归因映射表（${esc((d.enum && d.enum.version) || "")}）</b>
        <div class="muted">agent-fp 六类 → evolution：${l18Pct(rates.agent_fp_to_evolution)}（${(map.counts || {}).agent_fp_mapped || 0}/${(map.counts || {}).agent_fp || 0}）；evolution 四类 → agent-fp：${l18Pct(rates.evolution_to_agent_fp)}（${(map.counts || {}).evolution_mapped || 0}/${(map.counts || {}).evolution || 0}）；往返 ${l18Pct(rates.agent_fp_roundtrip)} / ${l18Pct(rates.evolution_roundtrip)}</div></div></div>
        <table class="table"><thead><tr><th>agent-fp 六类</th><th>→ evolution 四类</th><th>evolution 四类</th><th>→ agent-fp 六类</th></tr></thead><tbody><tr>
          <td>${Object.keys(af).map(k => l18Pill(k, "info")).join(" ")}</td>
          <td>${Object.entries(af).map(([k, v]) => `${esc(k)} → ${l18Pill(v, "ok")}`).join("<br>")}</td>
          <td>${Object.keys(evm).map(k => l18Pill(k, "warn")).join(" ")}</td>
          <td>${Object.entries(evm).map(([k, v]) => `${esc(k)} → ${l18Pill(v, "ok")}`).join("<br>")}</td>
        </tr></tbody></table>`;
    }
    const items = Array.isArray(d.items) ? d.items : [];
    box.innerHTML = items.length ? `<div class="evo-suggest-head" style="margin-top:10px"><div><b>归因复核 ${items.length} 条</b><div class="muted">只读：两套枚举来源徽标 + 同一字段统一后的机器码；未知值保留原值并标 other。</div></div></div>
      <table class="table"><thead><tr><th style="width:48px">序号</th><th style="width:88px">来源</th><th>规则 / 问题</th><th>原始 root_cause</th><th>统一归因</th><th style="width:96px">agent-fp</th><th style="width:96px">evolution</th><th style="width:72px">映射</th><th style="width:130px">时间</th></tr></thead><tbody>` +
      items.map((x, i) => `<tr>
        <td class="muted">${i + 1}</td>
        <td>${l18Pill(x.source === "evolution_task" ? "进化任务" : "反馈台账", x.source === "evolution_task" ? "info" : "muted")}</td>
        <td><div style="font-weight:500">${esc(x.title || "—")}</div><div class="muted" style="font-size:11px">${esc(x.rule_code || "—")}</div></td>
        <td class="muted">${esc(x.raw_root_cause || "—")}${x.source_enum ? `<div class="muted" style="font-size:11px">枚举来源：${esc(x.source_enum)}</div>` : ""}</td>
        <td>${x.known ? l18Pill(x.label + " (" + x.code + ")", "ok") : (x.raw_root_cause ? l18Pill("other（保留原值）", "bad") : l18Pill("未归因", "muted"))}</td>
        <td>${x.agent_fp ? l18Pill(x.agent_fp, "info") : '<span class="muted">—</span>'}</td>
        <td>${x.evolution ? l18Pill(x.evolution, "warn") : '<span class="muted">—</span>'}</td>
        <td>${x.raw_root_cause ? (x.known ? l18Pill("已映射", "ok") : l18Pill("other", "bad")) : l18Pill("空", "muted")}</td>
        <td class="muted">${esc((x.created_at || "").slice(5, 16))}</td></tr>`).join("") + `</tbody></table>`
      : l18Empty("暂无归因样本", "审核员提交误报/漏报反馈后，这里会出现归因复核项；无样本时不会伪造已映射率。");
    if (Array.isArray(d.unknown) && d.unknown.length) {
      box.insertAdjacentHTML("beforeend", `<div class="evo-note" style="margin-top:8px">未知值（保留原值，统计记 other）：` +
        d.unknown.slice(0, 20).map(u => `${esc(u.raw)}`).join("、") + `</div>`);
    }
  } catch (e) {
    l18Msg("#evo-attr-msg", "加载失败");
    box.innerHTML = l18Empty("归因复核加载失败", String(e && e.message || e));
  }
}

/* 断点② 候选/门禁时间线：状态 + 时间 + 预注册 hash 校验结果（篡改→blocked+审计） */
async function loadEvolutionCandidates() {
  const box = $("#evo-cand-out"); if (!box) return;
  l18Msg("#evo-cand-msg", "加载中…");
  try {
    const d = await (await fetch("/api/v1/evolution/candidates?limit=50")).json();
    l18Msg("#evo-cand-msg", "");
    if (!d || d.ok === false) { box.innerHTML = l18Empty("候选加载失败", (d && (d.error || d.code)) || "接口不可用"); return; }
    const st = d.stats || {};
    const statsBox = $("#evo-cand-stats");
    if (statsBox) statsBox.innerHTML = l18Kpis([
      { label: "候选总数", value: st.total || 0, color: "#3370FF" },
      { label: "hash 一致", value: st.prereg_verified || 0, color: "#00B578" },
      { label: "hash 不一致·阻断", value: st.prereg_mismatch || 0, color: "#F54A45" },
      { label: "历史候选·未预注册", value: st.prereg_legacy_null || 0, color: "#FF8800" },
      { label: "门禁阻断(含预注册)", value: st.blocked_by_prereg || 0, color: "#F54A45" },
    ]);
    const items = Array.isArray(d.items) ? d.items : [];
    const decisionKind = (x) => x === "accepted" ? "ok" : (x === "blocked" || x === "rolled_back") ? "bad" : (x === "uncertain" ? "warn" : "muted");
    const preregKind = (s) => s === "verified" ? "ok" : s === "mismatch" ? "bad" : (s === "legacy_null" || s === "unreadable") ? "warn" : "muted";
    box.innerHTML = items.length ? `<div class="evo-suggest-head" style="margin-top:10px"><div><b>候选/门禁时间线 ${items.length} 条</b><div class="muted">门禁读取即断言预注册 hash；不一致 → 候选 blocked + 审计 rsi.gate_blocked。</div></div></div>
      <table class="table"><thead><tr><th>候选</th><th>规则 / 动作</th><th style="width:96px">状态</th><th>预注册 hash 校验</th><th style="width:150px">创建 / 决定</th><th>门禁时间线</th></tr></thead><tbody>` +
      items.map(x => {
        const p = x.prereg || {};
        const sha = String(p.sha256 || "").slice(0, 16);
        const events = (x.timeline || []).map(ev => `<div class="muted" style="font-size:11px;line-height:1.5">${esc((ev.at || "").slice(5, 19))} · ${esc(ev.action)}${ev.decision ? " → " + esc(ev.decision) : ""}${ev.actor ? " · " + esc(ev.actor) : ""}</div>`).join("") || '<span class="muted">—</span>';
        return `<tr>
          <td class="muted" style="font-size:11px">${esc(x.id)}</td>
          <td><div style="font-weight:500">${esc(x.rule_code || "—")}</div><div class="muted" style="font-size:11px">${esc(x.action || "")}</div></td>
          <td>${l18Pill(x.decision_label || x.decision, decisionKind(x.decision))}</td>
          <td>${l18Pill(p.label || p.status || "—", preregKind(p.status))}
            <div class="muted" style="font-size:11px">${sha ? "sha256:" + esc(sha) + "…" : "无 hash"}${p.at ? " · " + esc(String(p.at).slice(5, 19)) : ""}</div>
            ${p.status === "mismatch" ? `<div style="color:#F54A45;font-size:11px">expected ${esc(String(p.expected || "").slice(0, 12))}… / actual ${esc(String(p.sha256 || "").slice(0, 12))}…</div>` : ""}</td>
          <td class="muted" style="font-size:11px">创建 ${esc((x.created_at || "").slice(5, 16))}<br>决定 ${esc((x.decided_at || "—").slice(5, 16))} ${esc(x.decided_by || "")}</td>
          <td>${events}</td></tr>`;
      }).join("") + `</tbody></table>` : l18Empty("暂无候选", "反馈沉淀生成候选后，这里会显示候选→门禁时间线与预注册 hash 校验结果。");
  } catch (e) {
    l18Msg("#evo-cand-msg", "加载失败");
    box.innerHTML = l18Empty("候选加载失败", String(e && e.message || e));
  }
}

/* 断点③ 生效版本与回滚：版本列表 + 生效版本对照 + 回滚按钮/只读记录 */
async function l18RollbackRule(ruleId, code) {
  if (!confirm(`回滚规则 ${code} 为草稿？\n旧生效版本会继续执行，直到新版本发布。`)) return;
  try {
    const r = await (await fetch(`/api/v1/rules/${encodeURIComponent(ruleId)}/rollback`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: "{}",
    })).json();
    showToast(r && r.error ? ("回滚失败：" + r.error) : "已回滚为草稿（旧生效版本继续执行）");
  } catch (e) { showToast("回滚失败：" + String(e && e.message || e)); }
  loadEvolutionVersions();
}
async function loadEvolutionVersions() {
  const box = $("#evo-ver-out"); if (!box) return;
  l18Msg("#evo-ver-msg", "加载中…");
  try {
    const d = await (await fetch("/api/v1/evolution/versions?limit=50")).json();
    l18Msg("#evo-ver-msg", "");
    if (!d || d.ok === false) { box.innerHTML = l18Empty("版本加载失败", (d && (d.error || d.code)) || "接口不可用"); return; }
    const st = d.stats || {};
    const perm = d.permissions || {};
    const statsBox = $("#evo-ver-stats");
    if (statsBox) statsBox.innerHTML = l18Kpis([
      { label: "规则数", value: st.rules || 0, color: "#3370FF" },
      { label: "有生效版本", value: st.effective || 0, color: "#00B578" },
      { label: "回滚记录", value: st.rollback_records || 0, color: "#FF8800" },
      { label: "当前角色", value: perm.can_manage ? "可回滚" : "只读", color: perm.can_manage ? "#3370FF" : "#6B7280" },
    ]);
    const items = Array.isArray(d.items) ? d.items : [];
    box.innerHTML = items.length ? `<div class="evo-suggest-head" style="margin-top:10px"><div><b>生效版本 ${items.length} 条规则</b><div class="muted">生效口径 = current_version_id 且版本已发布；版本列表为最近 5 个版本。</div></div></div>
      <table class="table"><thead><tr><th>规则</th><th style="width:84px">状态</th><th>生效版本</th><th>最近版本（新→旧）</th><th style="width:108px">操作</th></tr></thead><tbody>` +
      items.map(x => {
        const eff = x.effective;
        const vers = (x.versions || []).map(v => l18Pill(v.version + " " + (v.status || ""), v.status === "published" ? "ok" : v.status === "superseded" ? "muted" : "info")).join(" ");
        return `<tr>
          <td><div style="font-weight:500">${esc(x.name || x.code)}</div><div class="muted" style="font-size:11px">${esc(x.code)} · ${esc(x.category || "")}</div></td>
          <td>${l18Pill(x.status_label || x.status, x.status === "published" ? "ok" : x.status === "archived" ? "muted" : "info")}</td>
          <td>${eff ? `${l18Pill(eff.version, "ok")}<div class="muted" style="font-size:11px">${esc(eff.published_at || "")}</div>` : l18Pill("无生效版本", "warn")}</td>
          <td>${vers || '<span class="muted">—</span>'}</td>
          <td>${x.can_rollback ? `<button class="btn" data-l18-rollback="${esc(x.rule_id)}" data-l18-code="${esc(x.code)}">回滚为草稿</button>` : `<span class="muted" style="font-size:11px">${perm.can_manage ? esc(x.rollback_hint || "不可回滚") : "只读"}</span>`}</td></tr>`;
      }).join("") + `</tbody></table>` : l18Empty("暂无规则版本", "发布规则后，这里显示生效版本、最近版本与回滚入口。");
    box.querySelectorAll("[data-l18-rollback]").forEach(b => b.addEventListener("click", () => l18RollbackRule(b.dataset.l18Rollback, b.dataset.l18Code)));
    const rb = Array.isArray(d.rollback_records) ? d.rollback_records : [];
    const rbBox = $("#evo-ver-rb");
    if (rbBox) rbBox.innerHTML = rb.length ? `<table class="table"><thead><tr><th style="width:150px">时间</th><th style="width:130px">操作人</th><th style="width:220px">动作</th><th>对象</th><th>记录</th></tr></thead><tbody>` +
      rb.map(r => `<tr><td class="muted">${esc(r.at || "")}</td><td class="muted">${esc(r.actor || "")}</td><td>${l18Pill(r.action || "", "warn")}</td><td class="muted">${esc(r.object || "")}</td><td class="muted" style="font-size:11px">${esc(String(r.detail || "").slice(0, 200))}</td></tr>`).join("") + `</tbody></table>`
      : l18Empty("暂无回滚记录", "回滚属于关键写操作，记录只读留痕；没有记录时不伪造。");
  } catch (e) {
    l18Msg("#evo-ver-msg", "加载失败");
    box.innerHTML = l18Empty("版本加载失败", String(e && e.message || e));
  }
}
$("#evo-attr-refresh")?.addEventListener("click", () => loadEvolutionAttribution());
$("#evo-cand-refresh")?.addEventListener("click", () => loadEvolutionCandidates());
$("#evo-ver-refresh")?.addEventListener("click", () => loadEvolutionVersions());

/* ===================== L84 E3：新建规则页「推荐点位」面板（只读） =====================
   服务端同源接口：GET /api/v1/audit-points/recommended（auditpoints.recommended_points）
   - 按当前空间主文件类型路由出候选点位（选择结果，不是自动执行/自动确认）；
   - 推荐来源可追溯：本面板只渲染接口返回的 doc_types/audit_types/items，无数据如实空态；
   - 管理员可复用既有 POST /api/v1/audit-points/confirm-recommended 确认（该接口在空间设置页已接线），
     审核员只读（确认由业务管理员完成）。不新增后端接口。 */
function renderNrRecommendedPanel() {
  var host = document.querySelector("#newrule");
  if (!host || !host.parentNode) return;
  var panel = document.getElementById("nr-rec-card");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "nr-rec-card";
    panel.className = "card";
    panel.style.margin = "10px 0";
    panel.style.background = "#FAFBFC";
    panel.innerHTML =
      '<div class="card-head" style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">' +
        '<div><h2 style="font-size:13px;margin:0">推荐点位（按当前空间主文件类型路由）</h2>' +
        '<div class="muted" style="font-size:11.5px;margin-top:3px">' +
        '推荐来自平台点位库路由，是<b>候选选择</b>，不是执行结果；确认后才作为执行依据，系统不会自动确认或自动执行。' +
        '来源可追溯：<span class="ops-mono">/api/v1/audit-points/recommended</span>' +
        (currentRole === "reviewer" ? "。审核员只读：确认由业务管理员完成。" : "。") + '</div></div>' +
        '<span class="pill">只读推荐</span></div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0">' +
        '<button type="button" class="btn" id="nr-rec-load">加载推荐点位</button>' +
        (currentRole === "admin"
          ? '<button type="button" class="btn primary" id="nr-rec-confirm">一键确认全部推荐（管理员）</button>' : "") +
        '<span class="muted" id="nr-rec-msg" style="font-size:11.5px"></span>' +
      '</div>' +
      '<div class="muted" style="font-size:11.5px;margin-bottom:6px">' +
        '空态说明：空间未配置可在点位库匹配的主文件类型时，推荐为空是真实结果，不伪造推荐。</div>' +
      '<div id="nr-rec-out"><div class="muted">读取推荐点位中…</div></div>';
    host.parentNode.insertBefore(panel, host);
    panel.querySelector("#nr-rec-load").onclick = function () { loadNrRecommendedPoints(); };
    var cf = panel.querySelector("#nr-rec-confirm");
    if (cf) cf.onclick = function () { nrConfirmRecommended(cf); };
    loadNrRecommendedPoints();
    return;
  }
  // 模式切换时保留已有结果，只在从未加载成功时补拉一次
  if (!panel.dataset.loaded) loadNrRecommendedPoints();
}

async function loadNrRecommendedPoints() {
  var out = document.getElementById("nr-rec-out");
  var msg = document.getElementById("nr-rec-msg");
  if (!out) return;
  out.innerHTML = '<div class="muted">读取推荐点位中…</div>';
  var panel = document.getElementById("nr-rec-card");
  var r;
  try {
    r = await fetch("/api/v1/audit-points/recommended", { credentials: "same-origin" });
  } catch (e) {
    out.innerHTML = '<div class="empty" style="padding:14px 0">推荐点位读取失败：网络错误（' + esc((e && e.message) || e) + '）。失败不会被当作“没有推荐”。</div>';
    return;
  }
  var d = null;
  try { d = await r.json(); } catch (e2) { d = null; }
  if (!r.ok || !d || d.ok === false) {
    out.innerHTML = '<div class="empty" style="padding:14px 0">推荐点位读取失败（HTTP ' + esc(r.status) + '）：' +
      esc((d && (d.error || d.message)) || "未知错误") + '。</div>';
    return;
  }
  if (msg) {
    msg.textContent = "工作空间 " + (d.workspace_id || "—") + " · 主文件类型 " +
      ((d.doc_types || []).length ? d.doc_types.join("、") : "（未配置）") +
      " · 审核类型 " + ((d.audit_types || []).length || 0) + " 类 · 推荐 " + (d.items || []).length + " 个点位";
  }
  var items = d.items || [];
  if (!items.length) {
    out.innerHTML = '<div class="empty" style="padding:14px 0">当前空间没有路由出推荐点位（真实空态）：' +
      ((d.doc_types || []).length
        ? "已匹配主文件类型 " + esc(d.doc_types.join("、")) + "，但点位库未路由出候选。"
        : "主文件类型未在点位库中匹配（当前空间配置：" + esc(((window.__rpWsDocTypes || []).join("、")) || "未配置") + "）。") +
      ' 可在「空间列表 → 当前空间」配置主文件类型后重试；系统不会伪造推荐。</div>';
  } else {
    var shown = items.slice(0, 60);
    out.innerHTML = '<div style="overflow:auto;max-height:340px"><table class="table"><thead><tr>' +
      '<th style="width:110px">点位编码</th><th>点位名称</th><th style="width:210px">审核大类</th><th style="width:200px">审核类型</th>' +
      '</tr></thead><tbody>' +
      shown.map(function (x) {
        return '<tr><td class="muted">' + esc(x.id || "") + '</td><td>' + esc(x.name || "") + '</td>' +
          '<td class="muted">' + esc(x.category || "") + '</td>' +
          '<td class="muted">' + esc((x.type_id || "") + " " + (x.type_name || "")) + '</td></tr>';
      }).join("") + '</tbody></table></div>' +
      (items.length > shown.length
        ? '<div class="muted" style="font-size:11.5px;margin-top:4px">仅展示前 ' + shown.length + ' 条，共 ' + items.length + ' 条（完整列表以接口返回为准）。</div>'
        : "") +
      '<div class="muted" style="font-size:11.5px;margin-top:4px">口径：' + esc(d.note || "推荐点位仍需管理员确认后才执行") + '</div>';
  }
  if (panel) { panel.dataset.loaded = "1"; panel.dataset.count = String(items.length); }
}

async function nrConfirmRecommended(btn) {
  var msg = document.getElementById("nr-rec-msg");
  var ok = false;
  try { ok = confirm("按当前空间主文件类型推荐点位并全部确认？\n\n确认后这些点位才作为执行依据（下一次审核生效）；不会自动执行审核。"); } catch (e) { ok = false; }
  if (!ok) return;
  btn.disabled = true;
  var old = btn.textContent; btn.textContent = "确认中…";
  var r = null, d = null;
  try {
    r = await fetch("/api/v1/audit-points/confirm-recommended",
      { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: "{}" });
    d = await r.json();
  } catch (e2) { d = { error: "网络错误：" + ((e2 && e2.message) || e2) }; }
  btn.disabled = false; btn.textContent = old;
  if (!r || !r.ok || (d && (d.error || d.ok === false))) {
    if (msg) msg.textContent = "确认失败（HTTP " + (r ? r.status : "?") + "）：" + ((d && (d.error || d.message)) || "未知错误");
    return;
  }
  if (msg) msg.textContent = "已确认推荐点位 " + ((d && d.recommended) || 0) + " 个（updated " + ((d && d.updated) || 0) + "）；下一次审核生效。";
  showToast("已确认推荐点位 " + ((d && d.recommended) || 0) + " 个");
  loadNrRecommendedPoints();
}
