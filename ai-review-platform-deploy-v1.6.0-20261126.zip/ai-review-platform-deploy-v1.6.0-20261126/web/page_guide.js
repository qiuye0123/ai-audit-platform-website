(function(){
  "use strict";
  var API="/api/v1/page-guide", page="home", guide=null, modelState=null, role="", panel, msgs, input, sendBtn, body;
  var history=[], maxHistory=6, loadSeq=0;
  function q(s){return document.querySelector(s)}
  function el(id){return document.getElementById(id)}
  /* L183：当前 page key 识别。优先级：
     1) 当前可见的 .view[id^="view-"] —— workbench/report/project/terms 等页面没有
        左侧激活菜单项（或由项目列表/变量动态打开），只看 active menu 会错判成首页；
        按可见视图判断，刷新/切页后 guide 才能正确跟随。
     2) 左侧激活菜单（兼容视图尚未切换的一帧/初始渲染）。
     3) 独立页 /admin/business/tenant-config、/tenant-config 的路径回退。
     4) 兜底 home。 */
  function visibleViewKey(){
    var vs=document.querySelectorAll(".view[id^='view-']");
    for(var i=0;i<vs.length;i++){
      var v=vs[i];
      if(!v||v.hidden) continue;
      var id=String(v.id||"").replace(/^view-/,"");
      if(id) return id;
    }
    return "";
  }
  function pageKey(){
    var vk=visibleViewKey();
    /* 租户配置有两个入口：管理端内 #tenant 视图 + 独立页 /admin/business/tenant-config；
       两者共用同一 page key，保证两处 guide 内容一致。 */
    if(vk==="tenant") return "tenant-config";
    if(vk) return vk;
    var a=document.querySelector(".menu-item.active[data-view]");
    if(a&&a.dataset&&a.dataset.view) return a.dataset.view;
    if(location.pathname.indexOf("tenant-config")>=0) return "tenant-config";
    return "home";
  }
  function esc(s){return String(s||"").replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
  function sourceText(s){
    s=String(s||"");
    if(s.indexOf("PAGE_GUIDE_ENV")===0) return "页面助手专用 Key";
    if(s.indexOf("DB")===0) return "数据库模型配置";
    if(s==="ENV") return "环境变量";
    if(s==="OVERRIDE") return "显式覆盖";
    if(s==="DISABLED") return "已显式关闭";
    if(s==="NONE") return "未配置";
    return s||"未知来源";
  }
  function modelStatusText(m){
    if(!m) return "";
    if(m.available) return "模型："+(m.model_name||m.model||"未知")+" · "+sourceText(m.source)+(m.dedicated_key?"（页面助手专用 Key）":"");
    return "静态提示："+(m.reason||"当前无可用模型");
  }
  function setGuideModel(text){
    var g=el("pg-guide"); if(!g) return;
    var d=el("pg-modelnote");
    if(!text){if(d)d.textContent="";return}
    if(!d){d=document.createElement("div");d.id="pg-modelnote";d.className="pg-note";g.appendChild(d)}
    d.textContent=text;
  }
  function chatNote(d){
    if(d.model_used===true){
      var note="模型："+(d.model_name||d.model||"未知");
      if(d.latency_ms||d.latency_ms===0) note+=" · "+d.latency_ms+"ms";
      if(d.attempts>1) note+=" · 已自动切换（尝试 "+d.attempts+" 个候选模型）";
      if(d.note) note+=" · "+d.note;
      return note;
    }
    var staticNote="静态提示";
    if(d.model) staticNote+=" · 本次尝试模型："+d.model;
    if(d.model_status&&d.model_status!=="none") staticNote+=" · 状态："+d.model_status;
    if(d.note) staticNote+=" · "+d.note;
    return staticNote;
  }
  function build(){
    if(el("pg-root")) return;
    var root=document.createElement("div");root.className="pg-root";root.id="pg-root";
    root.innerHTML='<button class="pg-fab" id="pg-fab" type="button" aria-label="打开页面操作助手" title="页面操作助手"><span class="dot"></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><rect x="5" y="7" width="14" height="11" rx="3"/><path d="M9 11h.01M15 11h.01M9 15h6M12 7V4M8 4h8"/><path d="M3 12v3M21 12v3"/></svg></button>'+
      '<section class="pg-panel" id="pg-panel" hidden aria-label="页面操作助手"><div class="pg-head"><div><h3>页面操作助手</h3><p id="pg-page">当前页面</p></div><button class="pg-close" id="pg-close" aria-label="收起">×</button></div><div class="pg-body"><div id="pg-guide" class="pg-guide"></div><div id="pg-chips" class="pg-chips"></div><div id="pg-msgs" class="pg-msgs"></div></div><div class="pg-hint">只解答当前页面操作，不执行任何操作，不读取项目/文档数据。</div><div class="pg-foot"><input id="pg-input" maxlength="300" placeholder="问本页面的操作…" autocomplete="off"><button id="pg-send" type="button">发送</button></div></section>';
    document.body.appendChild(root);
    panel=el("pg-panel");msgs=el("pg-msgs");input=el("pg-input");sendBtn=el("pg-send");
    el("pg-fab").addEventListener("click",toggleOpen);
    el("pg-close").addEventListener("click",close);
    sendBtn.addEventListener("click",send);
    input.addEventListener("keydown",function(e){if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
    document.addEventListener("keydown",function(e){if(e.key==="Escape"&&!panel.hidden){e.stopPropagation();close()}});
    document.querySelectorAll(".menu-item[data-view]").forEach(function(a){a.addEventListener("click",function(){setTimeout(refreshPage,40)})});
  }
  /* L183：切页后刷新 guide。showView 是 app.js 统一视图入口（pushState 不触发
     hashchange），包装一层在切换完成后同步；hashchange/popstate 覆盖浏览器前进后退。 */
  function watchPageChanges(){
    if(typeof window.showView==="function"&&!window.showView.__pgWatched){
      var orig=window.showView;
      var wrapped=function(){var r=orig.apply(this,arguments);setTimeout(refreshPage,30);return r};
      wrapped.__pgWatched=true;
      window.showView=wrapped;
    }
    window.addEventListener("hashchange",function(){setTimeout(refreshPage,30)});
    window.addEventListener("popstate",function(){setTimeout(refreshPage,30)});
  }
  function open(){
    panel.hidden=false;el("pg-fab").setAttribute("aria-expanded","true");
    var k=pageKey();
    if(k!==page) setPage(k);
    else if(guide) renderGuide(); else loadGuide();
    setTimeout(function(){input.focus()},30);
  }
  function close(){panel.hidden=true;el("pg-fab").setAttribute("aria-expanded","false")}
  function toggleOpen(){panel.hidden?open():close()}
  function setPage(p){
    if(p===page) return; page=p; guide=null; history=[];msgs.innerHTML="";el("pg-chips").innerHTML="";
    if(!panel.hidden) loadGuide();
  }
  function refreshPage(){setPage(pageKey())}
  function renderGuide(){
    if(!guide){el("pg-guide").textContent="页面助手暂不可用。";setGuideModel("");return}
    el("pg-page").textContent=guide.title+" · 本页操作";
    var html='<b>'+esc(guide.summary||"")+'</b>';
    if(guide.steps&&guide.steps.length) html+='<ul>'+guide.steps.map(function(x){return '<li>'+esc(x)+'</li>'}).join('')+'</ul>';
    if(guide.pitfalls&&guide.pitfalls.length) html+='<div style="margin-top:5px;color:#b54708"><b>注意</b><ul>'+guide.pitfalls.map(function(x){return '<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';
    el("pg-guide").innerHTML=html;
    var chips=el("pg-chips");chips.innerHTML="";
    (guide.questions||[]).slice(0,5).forEach(function(qq){var b=document.createElement("button");b.type="button";b.className="pg-chip";b.textContent=qq;b.onclick=function(){ask(qq)};chips.appendChild(b)});
    setGuideModel(modelStatusText(modelState));
  }
  function loadGuide(){
    var p=pageKey();page=p;
    var seq=++loadSeq;
    fetch(API+"/context?page="+encodeURIComponent(p),{credentials:"same-origin"}).then(function(r){
      if(r.status===403) return {ok:false,code:"forbidden"};
      return r.json();
    }).then(function(d){
      if(seq!==loadSeq) return;   // 切页后丢弃上一页的迟到响应
      if(!d||!d.ok){guide=null;modelState=null;el("pg-page").textContent="页面助手";el("pg-guide").textContent="当前页面暂无操作说明。";setGuideModel("");return}
      /* 若响应期间又切了页，以当前可见页面为准，避免 Tabs/直达路由造成错页卡片 */
      var now=pageKey();
      if(now!==page){setPage(now);return}
      guide=d.guide;modelState=d.model||null;role=d.role||"";renderGuide();
    }).catch(function(){if(seq!==loadSeq) return;guide=null;modelState=null;el("pg-guide").textContent="页面助手暂时不可用。";setGuideModel("")});
  }
  function add(cls,text,note){
    var d=document.createElement("div");d.className="pg-msg "+cls;d.textContent=text;msgs.appendChild(d);
    if(note){var n=document.createElement("div");n.className="pg-note";n.textContent=note;msgs.appendChild(n)}
    body=document.querySelector(".pg-body");if(body) body.scrollTop=body.scrollHeight;
  }
  function ask(text){
    text=String(text||"").trim();if(!text) return;
    if(panel.hidden) open();
    add("u",text);input.value="";sendBtn.disabled=true;
    fetch(API+"/chat",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify({page:page,message:text})})
      .then(function(r){return r.json().then(function(d){return {status:r.status,d:d}})})
      .then(function(x){
        var d=x.d||{};
        if(x.status!==200){add("a",d.error||"暂时无法回答。");return}
        add("a",d.answer||"暂时没有答案。",chatNote(d));
        history.push({q:text,a:d.answer});if(history.length>maxHistory)history.shift();
      }).catch(function(){add("a","页面助手连接失败，请稍后再试。")})
      .finally(function(){sendBtn.disabled=false;input.focus()});
  }
  function send(){ask(input.value)}
  function boot(){
    fetch("/api/v1/me",{credentials:"same-origin"}).then(function(r){return r.ok?r.json():null}).then(function(d){
      var role=d&&d.user&&d.user.role;
      if(role!=="reviewer"&&role!=="admin") return;
      build();
      watchPageChanges();
      page=pageKey();
      // 不自动打开；只显示入口
    }).catch(function(){});
  }
  /* L183：暴露 pageKey 供静态/Node 契约测试断言（不改变浏览器行为）。 */
  window.__pgPageKey=pageKey;
  window.__pgVisibleViewKey=visibleViewKey;
  boot();
})();
