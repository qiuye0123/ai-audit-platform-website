/* 消息配置页面模块：从 app.js 拆出。 */
async function loadNotifyConfig() {
  uxSetLoading("#notify-config-list", "正在加载消息配置…", 4);
  let d;
  try { d = await (await fetch("/api/v1/notify/config")).json(); }
  catch (e) {
    uxSetEmpty("#notify-config-list", { title: "消息配置加载失败", desc: "请检查网络后重试；不会发送任何消息。" });
    return;
  }
  if (!d || d.error) {
    uxSetEmpty("#notify-config-list", { title: "消息配置加载失败", desc: String((d && d.error) || "接口返回为空") });
    return;
  }
  const events = (d.events || []).filter(e => e.center_visible !== false), cfg = d.config || {};
  window.__notifyConfig = cfg;
  window.__notifyEvents = events;
  const _sel = document.getElementById("notify-test-event");
  if (_sel) {
    _sel.innerHTML = events.map(e => `<option value="${esc(e.key)}">${esc(e.name)}（${esc(e.key)}）</option>`).join("") || '<option value="system.test">站内消息测试</option>';
  }
  if (!events.length) {
    uxSetEmpty("#notify-config-list", { title: "暂无可配置的消息事件", desc: "当前版本没有可维护的事件；新增事件后会显示在这里。" });
    if (typeof uxDirtyClear === "function") uxDirtyClear("notifyconfig");
    return;
  }
  const roles = [["reviewer", "审核员"], ["admin", "业务管理员"], ["super_admin", "系统管理员"]];
  const pr = { "必推": "r", "建议": "draft", "可选": "" };
  $("#notify-config-list").innerHTML = `<div class="notify-config-hint">只发送站内消息。每个事件可以配置接收角色、是否启用，以及标题/正文模板；模板变量支持 <code>{title}</code>、<code>{detail}</code>、<code>{event}</code>。</div>
    <div class="notify-hidden-note">消息中心按项目通知、规则更新、规则反馈、系统通知分类。审核员只看到自己的项目通知，业务管理员看到本租户全部项目通知；规则冲突只在左侧「冲突提醒」菜单显示红点，不在消息中心重复提醒。</div>
    <table class="table notify-event-table"><thead><tr><th style="width:190px">事件与触发</th><th style="width:150px">值得推送</th><th style="width:145px">可见角色</th><th style="width:55px">启用</th><th>标题模板</th><th>正文模板</th></tr></thead><tbody>` +
    events.map(e => {
      const c = cfg[e.key] || {}; const aud = c.audiences || e.audiences || ["admin"];
      return `<tr data-event="${esc(e.key)}">
      <td><b>${esc(e.name)}</b><div class="muted" style="font-size:12px">${esc(e.key)}</div><div class="muted" style="font-size:12px;line-height:1.5;margin-top:2px">${esc(e.trigger || e.desc || "")}</div></td>
      <td><span class="pill ${pr[e.priority] || ""}">${esc(e.priority || "建议")}</span><div class="muted" style="font-size:12px;margin-top:3px">${esc(e.priority === "必推" ? "关键动作，默认开启" : e.priority === "可选" ? "默认关闭，按需开启" : "有业务价值，默认开启")}</div></td>
      <td><div class="notify-aud">${roles.map(([k, label]) => `<label><input type="checkbox" data-ne-aud="${k}" ${aud.includes(k) ? "checked" : ""}>${label}</label>`).join("")}</div></td>
      <td><input type="checkbox" data-ne-enabled ${c.enabled !== false ? "checked" : ""}></td>
      <td><input class="field notify-tpl" data-ne-title value="${esc(c.title_template || "{title}")}" maxlength="200"></td>
      <td><input class="field notify-tpl" data-ne-detail value="${esc(c.detail_template || "{detail}")}" maxlength="2000"></td>
    </tr>`; }).join("") + `</tbody></table>`;
  // 数据已回填完成，以当前值作为 dirty 基线；单纯切换页面不会提示。
  if (typeof uxDirtyIsDirty !== "function" || !uxDirtyIsDirty("notifyconfig")) {
    if (typeof uxDirtyClear === "function") uxDirtyClear("notifyconfig");
  }
}
async function saveNotifyConfig() {
  const config = { ...(window.__notifyConfig || {}) };
  let invalid = "";
  document.querySelectorAll("#notify-config-list tr[data-event]").forEach(tr => {
    const aud = [...tr.querySelectorAll("[data-ne-aud]")].filter(x => x.checked).map(x => x.dataset.neAud);
    if (!aud.length) invalid = "每个事件至少选择一个可见角色";
    config[tr.dataset.event] = {
      enabled: tr.querySelector("[data-ne-enabled]").checked,
      audiences: aud,
      title_template: tr.querySelector("[data-ne-title]").value.trim() || "{title}",
      detail_template: tr.querySelector("[data-ne-detail]").value.trim() || "{detail}",
    };
  });
  if (invalid) { $("#notify-config-msg").textContent = invalid; showToast(invalid, "err"); return; }
  const r = await (await fetch("/api/v1/notify/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ config }) })).json();
  $("#notify-config-msg").textContent = r.error ? ("保存失败：" + r.error) : "已保存：只发送站内消息，按角色和模板执行";
  if (!r.error) {
    showToast("消息配置已保存");
    if (typeof uxDirtyClear === "function") uxDirtyClear("notifyconfig");
  }
}
$("#notify-config-save")?.addEventListener("click", saveNotifyConfig);
$("#notify-config-refresh")?.addEventListener("click", async () => {
  if (typeof uxConfirmDiscard === "function" && !(await uxConfirmDiscard("notifyconfig", "刷新配置"))) return;
  await loadNotifyConfig();
  showToast("消息配置已刷新");
});

/* ===== 通知：测试发送（真实站内消息）+ 触发记录（notification 表真实写入） ===== */
async function sendNotifyTest() {
  const sel = document.getElementById("notify-test-event");
  const msg = document.getElementById("notify-test-msg");
  const btn = document.getElementById("notify-test-send");
  const event = (sel && sel.value) || "system.test";
  if (btn) { btn.disabled = true; btn.textContent = "发送中…"; }
  if (msg) msg.textContent = "正在发送真实站内消息…";
  try {
    const r = await fetch("/api/v1/notify/test", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event })
    });
    const d = await r.json();
    if (!r.ok || d.error) {
      if (msg) msg.textContent = "发送失败：" + (d.error || ("HTTP " + r.status));
      showToast("测试发送失败：" + (d.error || r.status), "err");
      return;
    }
    if (msg) {
      msg.innerHTML = d.delivered
        ? `已写入真实站内消息：<b>${esc(d.rendered_title || "")}</b>（<code>${esc(d.notification_id || "")}</code>，消息中心可查看）`
        : `未写入消息：${esc(d.note || "事件被禁用或无可见角色")}`;
    }
    showToast(d.delivered ? "测试消息已发送，可在消息中心查看" : "事件未发送，请检查配置", d.delivered ? "ok" : "err");
    loadNotifyRecords();
  } catch (e) {
    if (msg) msg.textContent = "发送失败：网络错误";
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "测试发送（真实站内消息）"; }
  }
}
async function loadNotifyRecords() {
  const host = document.getElementById("notify-records");
  if (!host) return;
  host.innerHTML = '<div class="muted" style="font-size:12px;padding:8px 0">正在加载触发记录…</div>';
  try {
    const r = await fetch("/api/v1/notify/records?limit=30");
    const d = await r.json();
    if (!r.ok || d.error) { host.innerHTML = `<div class="empty">触发记录加载失败：${esc(d.error || ("HTTP " + r.status))}</div>`; return; }
    const byType = d.by_type || [], items = d.items || [];
    host.innerHTML = `<div class="section-head" style="margin-bottom:6px"><div><h2 style="font-size:13px">最近触发记录</h2><p class="muted" style="font-size:11px">来自 notification 表真实写入，只读；时间窗：最近 ${items.length} 条 <span class="scope-chip">本租户</span></p></div></div>` +
      (byType.length ? `<div class="muted" style="font-size:11.5px;line-height:1.8;margin:0 0 6px">按事件：` + byType.map(x => `${esc(notifyLabel(x.type))} ${x.n} 条（最近 ${esc((x.last_at || "").slice(0, 16))}）`).join(" · ") + `</div>` : "") +
      (items.length ? `<div class="table-wrap"><table class="table notify-record-table"><thead><tr><th>时间</th><th>接收人</th><th>事件</th><th>标题</th><th>已读</th></tr></thead><tbody>` +
        items.map(x => `<tr><td class="muted">${esc((x.created_at || "").slice(0, 16))}</td><td>${esc(x.actor_name || x.actor || "—")}</td><td><b>${esc(notifyLabel(x.type))}</b><div class="muted" style="font-size:11px">${esc(x.type || "")}</div></td><td style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(x.detail || "")}">${esc(x.title || "—")}</td><td><span class="pill ${x.read ? "published" : "draft"}">${x.read ? "已读" : "未读"}</span></td></tr>`).join("") +
        `</tbody></table></div>` : '<div class="empty" style="padding:12px 0">还没有触发记录；测试发送或真实业务动作触发后会出现在这里。</div>');
  } catch (e) {
    host.innerHTML = '<div class="empty">触发记录加载失败（网络错误）</div>';
  }
}
document.getElementById("notify-test-send")?.addEventListener("click", sendNotifyTest);
document.getElementById("notify-records-refresh")?.addEventListener("click", loadNotifyRecords);
loadNotifyRecords();

/* 模型管理页面已拆到 web/models.js。 */

