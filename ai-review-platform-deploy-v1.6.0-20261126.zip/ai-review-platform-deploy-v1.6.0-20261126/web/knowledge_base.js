/* T-175 知识库 UI 重做（2026-11-19）+ T-188 P1/P2 修复（2026-11-20）
 *
 * 目标：把知识库从「表格 + 按钮」重做成成熟商业产品质感，并沿用页面的浅蓝（Gemini 参考）
 * 主题层 token。能力边界与数据契约（T-188 起扩展）：
 * - 跟随左侧当前工作空间：空间内所有业务成员可查看/上传/重命名/移动/删除/恢复；
 * - 只有一级文件夹；支持文件/文件夹重命名、文件移动到文件夹（含批量）；
 * - 删除进回收站（软删）：可恢复、可彻底删除（二次确认 + 服务端审计）；
 * - 引用选择器支持搜索（文件名/上传人）、目录筛选、分页（每页 10 条）；
 * - 支持 PDF/DOCX/XLSX/PPTX/TXT/MD/CSV/JSON/图片/EML；office 只安全下载，不在页内渲染；
 * - 后端权限沿用 admin/reviewer（系统管理员/平台运营 403）。
 *
 * 交互（成熟产品基线）：
 * - 语义化布局：Hero（标题/空间/统计/主操作）+ 工具条（面包屑/搜索/排序/视图/目录/回收站）
 *   + 目录树 + 文件区；窄屏（≤1180）目录树收进抽屉，由工具条「目录」按钮打开；
 * - 目录树：全部文件/未归档/一级文件夹，可筛选、当前项高亮、带计数、可删除/重命名；
 * - 搜索（/ 聚焦、Esc 清空）、排序（最近/名称/大小）、列表/网格双视图（localStorage 记住）；
 * - 分页（每页 10 条）、本页全选、Shift 区间连选、多选批量删除/批量移动；
 * - 上传：上传弹窗（拖拽区 + 格式提示 + 队列进度）、页面拖拽上传（dragover 高亮）、
 *   失败重试按钮（弹窗/托盘都真实重发）、50MB 上限前端预检、XHR 超时保护；
 * - 空态（插画 + 一句引导 + 主按钮）、骨架屏（非转圈）、错误态（重试按钮）；
 * - 键盘：Esc 关闭弹窗（走全局 UX 层）/清空搜索，/ 聚焦搜索，R 刷新；弹窗打开焦点进主操作、
 *   关闭后回到触发按钮；
 * - 文件长名省略 + title 悬浮，表格 fixed 布局不因长名撑爆；操作列固定右侧；
 * - 回收站：删除→软删进回收站→恢复→彻底删除（二次确认）；所有写操作由后端写审计。
 *
 * 同时给「新建规则 · 上传拆解」保留：KB.pickFile / KB.fetchFileBlob / KB.uploadForRule。
 */
(function () {
  "use strict";
  const API = "/api/v1/knowledge";
  const esc2 = (s) => (typeof esc === "function" ? esc(s)
    : String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])));
  const $kb = (id) => document.getElementById(id);
  const hasApp = (fn) => typeof window[fn] === "function";
  const PAGE_SIZE = 10;
  const VIEW_STORE_KEY = "kb.viewmode";
  const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;
  const UPLOAD_TIMEOUT_MS = 120000;

  /* ---------------- 错误文案：中文可读 + 保留内部 code 到 title ---------------- */
  const ERROR_TEXT = {
    network_error: "网络异常，请检查网络后重试",
    scope_required: "无法确定当前工作空间，请刷新页面后重试",
    forbidden: "无权限：知识库仅限业务角色在所属空间使用",
    not_found: "文件或文件夹不存在，或不属于当前工作空间",
    confirm_required: "该操作需要二次确认",
    not_in_recycle: "该文件/文件夹不在回收站中",
    recycle_name_conflict: "恢复失败：已有同名文件夹，请先重命名或删除现有文件夹",
    duplicate_folder: "该工作空间已存在同名文件夹",
    duplicate_filename: "当前文件夹已存在同名文件，请换一个名称",
    invalid_folder: "文件夹名称不合法（1–40 字，不能含 / 或 \\）",
    invalid_filename: "文件名称不合法（不能为空、不能含路径分隔符或控制字符）",
    invalid_file_type: "文件类型不在支持范围内（不支持可执行文件与压缩包）",
    invalid_operation: "不支持的操作",
    invalid_request: "请求参数不合法",
    file_too_large: "文件超过 50MB 上限，请压缩后重试",
    empty_file: "文件为空，无法上传",
    nothing_to_do: "没有需要处理的对象",
  };
  function friendlyError(raw, code, status) {
    const c = String(code || "");
    if (c && ERROR_TEXT[c]) return ERROR_TEXT[c];
    const text = String(raw || "").trim();
    // 后端中文 message 直接展示（比前端映射更准确，且不丢细节）
    if (/[\u4e00-\u9fa5]/.test(text)) return text;
    if (status === 401) return "登录状态已失效，请重新登录";
    if (status === 403) return "无权限执行该操作";
    if (status === 404) return ERROR_TEXT.not_found;
    if (status === 409) return "操作冲突：目标已存在或状态已变化，请刷新后重试";
    if (status === 413) return ERROR_TEXT.file_too_large;
    if (status >= 500) return "知识库服务暂时不可用，请稍后重试";
    if (!text || /failed to fetch|networkerror|load failed|^HTTP\s*\d+$/i.test(text)) {
      return ERROR_TEXT.network_error;
    }
    if (/^[a-z0-9_]+$/i.test(text)) return "操作失败（" + text + "），请稍后重试";
    return text;
  }

  function toast(msg, type) {
    if (hasApp("showToast")) return window.showToast(msg, type);
  }
  function setMsg(msg, type) {
    const el = $kb("kb-msg");
    if (!el) return;
    el.textContent = msg || "";
    el.className = "kb-msg " + (type === "err" ? "err" : type === "ok" ? "ok" : "muted");
    el.removeAttribute("title");
  }
  /** 错误提示：中文可读文案 + 机读 code 只进 title（不直出英文内部码）。 */
  function notifyError(prefix, e) {
    const msg = prefix + ((e && e.message) || "操作失败，请重试");
    setMsg(msg, "err");
    const el = $kb("kb-msg");
    if (el && e && e.code) el.title = "错误码：" + e.code;
    toast(msg, "err");
    return msg;
  }

  const STATE = {
    loaded: false, loading: false, error: "",
    folder: "", folders: [], files: [], stats: {}, workspace: "",
    q: "", folderQ: "", sort: "new", view: "list",
    page: 0, selected: new Set(), uploads: [], lastSelectIndex: null,
    recycle: { files: [], folders: [], stats: {} },
  };
  const OFFICE_RE = /\.(docx|xlsx|pptx|doc|xls|ppt|eml)$/i;
  const IMG_RE = /\.(png|jpe?g|gif|webp|bmp)$/i;
  const PDF_RE = /\.pdf$/i;
  const TEXT_RE = /\.(txt|md|csv|json)$/i;

  const ICO = (p, size) => '<svg class="kb-ico" width="' + (size || 16) + '" height="' + (size || 16) +
    '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
  const I = {
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    inbox: '<path d="M4 13h4l2 3h4l2-3h4"/><path d="M5 5h14l2 8v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4z"/>',
    doc: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M8 13h8M8 17h5"/>',
    eye: '<path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="2.6"/>',
    download: '<path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M4 17v2a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2"/>',
    trash: '<path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
    rename: '<path d="M12 20h9"/><path d="M16.6 3.4a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    move: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 13h7"/><path d="m13 10 3 3-3 3"/>',
    restore: '<path d="M4 11a8 8 0 1 0 2.3-5.7"/><path d="M4 5v6h6"/>',
    folderPlus: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v6M9 14h6"/>',
    upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
    alert: '<path d="M12 3 2.6 19a1 1 0 0 0 .9 1.5h17a1 1 0 0 0 .9-1.5L12 3Z"/><path d="M12 9v5M12 17h.01"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    chevron: '<path d="m9 6 6 6-6 6"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  };

  /* ---------------- 格式化 ---------------- */
  function fmtSize(n) {
    const v = Number(n) || 0;
    if (v < 1024) return v + " B";
    if (v < 1024 * 1024) return (v / 1024).toFixed(1) + " KB";
    return (v / 1024 / 1024).toFixed(1) + " MB";
  }
  const pad2 = (n) => String(n).padStart(2, "0");
  function parseTime(s) {
    const raw = String(s || "").trim();
    if (!raw) return null;
    const d = new Date(raw.replace(" ", "T"));
    return isNaN(d.getTime()) ? null : d;
  }
  function fmtTime(s) {
    const d = parseTime(s);
    if (!d) return String(s || "").slice(0, 16) || "—";
    const now = new Date();
    const hm = pad2(d.getHours()) + ":" + pad2(d.getMinutes());
    if (d.toDateString() === now.toDateString()) return "今天 " + hm;
    const y = new Date(now.getTime() - 86400000);
    if (d.toDateString() === y.toDateString()) return "昨天 " + hm;
    if (d.getFullYear() === now.getFullYear()) return pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) + " " + hm;
    return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());
  }
  function fmtTimeFull(s) {
    const raw = String(s || "").trim();
    return raw ? raw.slice(0, 19) : "—";
  }
  function viewUrl(id) { return API + "/files/" + encodeURIComponent(id) + "/view"; }
  function downloadAttrs(file) {
    return ' href="' + esc2(viewUrl(file.id)) + '?download=1" download="' + esc2(file.filename || "file") + '"';
  }
  function fileKind(name) {
    const n = String(name || "").toLowerCase();
    if (/\.pdf$/.test(n)) return { label: "PDF", tone: "pdf" };
    if (/\.(docx|doc)$/.test(n)) return { label: "DOC", tone: "doc" };
    if (/\.(xlsx|xls|csv)$/.test(n)) return { label: "XLS", tone: "sheet" };
    if (/\.(pptx|ppt)$/.test(n)) return { label: "PPT", tone: "slide" };
    if (/\.(txt|md)$/.test(n)) return { label: "TXT", tone: "text" };
    if (/\.json$/.test(n)) return { label: "JSON", tone: "code" };
    if (IMG_RE.test(n)) return { label: "IMG", tone: "img" };
    if (/\.eml$/.test(n)) return { label: "EML", tone: "mail" };
    return { label: "FILE", tone: "file" };
  }
  function typeChip(name, big) {
    const k = fileKind(name);
    return '<span class="kb-type kb-type-' + k.tone + (big ? " kb-type-lg" : "") + '" aria-hidden="true">' + k.label + "</span>";
  }

  /* ---------------- API ---------------- */
  async function apiJson(url, opts) {
    let r;
    try {
      r = await fetch(url, opts);
    } catch (err) {
      const e = new Error(ERROR_TEXT.network_error);
      e.code = "network_error";
      e.status = 0;
      e.raw = String((err && err.message) || err);
      throw e;
    }
    let d = {};
    try { d = await r.json(); } catch (e) { d = {}; }
    if (!r.ok || d.error || (d.ok === false)) {
      const raw = String(d.error || d.reason || ("HTTP " + r.status));
      const code = String(d.code || "");
      const err = new Error(friendlyError(raw, code, r.status));
      err.code = code;
      err.status = r.status;
      err.raw = raw;
      err.detail = d;
      throw err;
    }
    return d;
  }

  /* ---------------- 选择态 / 排序 / 过滤 ---------------- */
  function folderLabel(id) {
    if (!id) return "全部文件";
    if (id === "root") return "未归档";
    const f = STATE.folders.find((x) => String(x.id) === String(id));
    return f ? String(f.name || "文件夹") : "文件夹";
  }
  function currentFiles() {
    return STATE.files.filter((f) => {
      const fid = String(f.folder_id || "");
      if (!STATE.folder) return true;
      if (STATE.folder === "root") return !fid;
      return fid === String(STATE.folder);
    });
  }
  function visibleFiles() {
    let list = currentFiles();
    const q = STATE.q.trim().toLowerCase();
    if (q) {
      list = list.filter((f) => String(f.filename || "").toLowerCase().includes(q)
        || String(f.uploaded_by || "").toLowerCase().includes(q));
    }
    if (STATE.sort === "name") {
      list = list.slice().sort((a, b) => String(a.filename || "").localeCompare(String(b.filename || ""), "zh-Hans-CN"));
    } else if (STATE.sort === "size") {
      list = list.slice().sort((a, b) => (Number(b.size) || 0) - (Number(a.size) || 0));
    } else {
      list = list.slice().sort((a, b) => String(b.created_at || "").localeCompare(String(a.created_at || ""))
        || String(b.id || "").localeCompare(String(a.id || "")));
    }
    return list;
  }
  function pageFiles(list) {
    const start = STATE.page * PAGE_SIZE;
    return list.slice(start, start + PAGE_SIZE);
  }
  function totalPages(list) { return Math.max(1, Math.ceil(list.length / PAGE_SIZE)); }
  function findFile(id) { return STATE.files.find((x) => String(x.id) === String(id)); }
  function pruneSelection() {
    const alive = new Set(STATE.files.map((f) => String(f.id)));
    STATE.selected = new Set([...STATE.selected].filter((id) => alive.has(String(id))));
  }

  /* ---------------- 渲染：Hero / 统计 ---------------- */
  function renderStats() {
    const st = STATE.stats || {};
    const files = Number(st.files) || 0;
    const folders = Number(st.folders) || 0;
    const el = $kb("kb-stats");
    if (el) {
      el.innerHTML = '<span class="kb-stat kb-stat-files"><i aria-hidden="true"></i>共 ' + files + " 个文件</span>" +
        '<span class="kb-stat kb-stat-folders"><i aria-hidden="true"></i>' + folders + " 个文件夹</span>" +
        '<span class="kb-stat kb-stat-bytes"><i aria-hidden="true"></i>' + esc2(fmtSize(st.bytes || 0)) + "</span>";
    }
    const nameEl = $kb("kb-ws-name");
    if (nameEl) nameEl.textContent = STATE.workspace || "当前工作空间";
    const rc = Number(st.recycle_files || 0) + Number(st.recycle_folders || 0);
    const badge = $kb("kb-recycle-count");
    if (badge) {
      badge.textContent = rc > 0 ? String(rc) : "";
      badge.hidden = rc <= 0;
    }
    const btn = $kb("kb-recycle-btn");
    if (btn) btn.title = rc > 0 ? "回收站（" + rc + " 项可恢复）" : "回收站";
  }
  function renderScope() {
    const scope = $kb("kb-scope");
    if (!scope) return;
    if (STATE.loading && !STATE.loaded) { scope.textContent = "正在读取当前工作空间…"; return; }
    if (STATE.error) { scope.textContent = "当前工作空间范围读取失败，可点上方「刷新」重试。"; return; }
    scope.textContent = (STATE.workspace ? "当前工作空间：" + STATE.workspace + "。" : "") +
      "空间内所有成员可查看、上传、重命名、移动、删除；只有一级文件夹，不支持嵌套与压缩包；" +
      "删除先进回收站（可恢复，也可彻底删除）；切换工作空间后本页自动读取对应空间。";
  }

  /* ---------------- 渲染：目录树 ---------------- */
  function treeSkeleton() {
    return '<div class="kb-tree-skel" aria-hidden="true">' +
      '<span class="kb-skel kb-skel-line"></span><span class="kb-skel kb-skel-line"></span><span class="kb-skel kb-skel-line"></span></div>';
  }
  function treeItem(id, label, count, iconPath, extraCls) {
    const on = String(STATE.folder) === String(id);
    return '<button type="button" class="kb-tree-item' + (on ? " on" : "") + (extraCls ? " " + extraCls : "") +
      '" data-kb-folder="' + esc2(id) + '" title="' + esc2(label) + '"' + (on ? ' aria-current="true"' : "") + ">" +
      (iconPath ? '<span class="kb-tree-ico">' + ICO(iconPath, 15) + "</span>" : "") +
      '<span class="kb-tree-label">' + esc2(label) + "</span>" +
      '<span class="kb-tree-count">' + (Number(count) || 0) + "</span></button>";
  }
  function renderFolders() {
    const box = $kb("kb-folder-list");
    if (!box) return;
    if (STATE.loading && !STATE.loaded) { box.innerHTML = treeSkeleton(); return; }
    const total = Number((STATE.stats || {}).files) || 0;
    const unfiled = STATE.files.filter((f) => !f.folder_id).length;
    const q = STATE.folderQ.trim().toLowerCase();
    const folders = STATE.folders.filter((f) => !q || String(f.name || "").toLowerCase().includes(q));
    let html = treeItem("", "全部文件", total, I.folder, "kb-tree-all");
    html += treeItem("root", "未归档", unfiled, I.inbox, "kb-tree-root");
    html += '<div class="kb-tree-group"><span>文件夹</span><span class="kb-tree-group-n">' + STATE.folders.length + "</span></div>";
    if (!STATE.folders.length) {
      html += '<div class="kb-tree-empty">' + (q ? "没有匹配的目录。" : "还没有文件夹，可点右上「新建文件夹」给资料做一层归档。") + "</div>";
    } else if (!folders.length) {
      html += '<div class="kb-tree-empty">没有匹配的目录。</div>';
    } else {
      folders.forEach((f) => {
        html += '<div class="kb-tree-row' + (String(STATE.folder) === String(f.id) ? " on" : "") + '" data-kb-folder-row="' + esc2(f.id) + '">' +
          treeItem(f.id, f.name, f.file_count, null) +
          '<button type="button" class="kb-tree-act kb-tree-ren" data-kb-folder-rename="' + esc2(f.id) + '" title="重命名文件夹" aria-label="重命名文件夹 ' + esc2(f.name) + '">' +
          ICO(I.rename, 13) + "</button>" +
          '<button type="button" class="kb-tree-act kb-tree-del" data-kb-folder-del="' + esc2(f.id) + '" title="删除文件夹（进回收站）" aria-label="删除文件夹 ' + esc2(f.name) + '">' +
          ICO(I.trash, 13) + "</button></div>";
      });
    }
    box.innerHTML = html;
  }

  /* ---------------- 渲染：面包屑 / 列表头 / 分页 / 批量条 ---------------- */
  function renderCrumbs() {
    const el = $kb("kb-crumb");
    if (!el) return;
    let html = '<button type="button" class="kb-crumb-link' + (!STATE.folder ? " on" : "") + '" data-kb-folder="">' +
      ICO(I.folder, 14) + "<span>全部文件</span></button>";
    if (STATE.folder) {
      html += '<span class="kb-crumb-sep" aria-hidden="true">' + ICO(I.chevron, 12) + "</span>" +
        '<span class="kb-crumb-cur">' + esc2(folderLabel(STATE.folder)) + "</span>";
    }
    el.innerHTML = html;
  }
  function listHeadHTML(list, pageList) {
    const q = STATE.q.trim();
    const bits = ['<b>' + list.length + "</b> 个文件"];
    if (STATE.folder) bits.push("当前目录：" + esc2(folderLabel(STATE.folder)));
    if (q) bits.push('搜索「' + esc2(q) + "」");
    const allSelected = pageList.length > 0 && pageList.every((f) => STATE.selected.has(String(f.id)));
    return '<div class="kb-list-meta">' + bits.join('<span class="kb-dot">·</span>') + "</div>" +
      '<label class="kb-check-label"><input type="checkbox" id="kb-select-all"' + (allSelected ? " checked" : "") +
      ' aria-label="全选当前页"> 全选本页</label>';
  }
  function renderPager(total) {
    const el = $kb("kb-pager");
    if (!el) return;
    const pages = totalPages({ length: total });
    if (pages <= 1) { el.hidden = true; el.innerHTML = ""; return; }
    el.hidden = false;
    const cur = STATE.page;
    const btn = (p, label, cls) => '<button type="button" class="kb-page-btn' + (cls ? " " + cls : "") +
      '" data-kb-page="' + p + '"' + (p === cur ? ' aria-current="page"' : "") + ">" + label + "</button>";
    let nums = "";
    const push = (p) => { nums += btn(p, String(p + 1)); };
    if (pages <= 7) { for (let i = 0; i < pages; i++) push(i); }
    else {
      push(0);
      if (cur > 2) nums += '<span class="kb-page-gap">…</span>';
      for (let i = Math.max(1, cur - 1); i <= Math.min(pages - 2, cur + 1); i++) push(i);
      if (cur < pages - 3) nums += '<span class="kb-page-gap">…</span>';
      push(pages - 1);
    }
    el.innerHTML = '<span class="kb-pager-info">共 ' + total + " 项 · 第 " + (cur + 1) + " / " + pages + " 页</span>" +
      '<div class="kb-pager-btns">' + btn(Math.max(0, cur - 1), "上一页", "kb-page-prev") + nums +
      btn(Math.min(pages - 1, cur + 1), "下一页", "kb-page-next") + "</div>";
  }
  function renderBatch() {
    const bar = $kb("kb-batchbar");
    if (!bar) return;
    const n = STATE.selected.size;
    bar.hidden = n === 0;
    const c = $kb("kb-sel-count");
    if (c) c.textContent = String(n);
  }

  /* ---------------- 渲染：空态 / 错误态 / 骨架屏 ---------------- */
  const ART_EMPTY = '<div class="kb-empty-art" aria-hidden="true"><svg width="104" height="80" viewBox="0 0 104 80" fill="none">' +
    '<rect x="10" y="16" width="84" height="56" rx="14" fill="url(#kbga)"/>' +
    '<rect x="24" y="8" width="46" height="54" rx="9" fill="#FFFFFF" stroke="#DADCE0"/>' +
    '<rect x="32" y="20" width="30" height="4" rx="2" fill="#1A73E8" opacity=".55"/>' +
    '<rect x="32" y="30" width="24" height="4" rx="2" fill="#DADCE0"/>' +
    '<rect x="32" y="40" width="27" height="4" rx="2" fill="#DADCE0"/>' +
    '<circle cx="80" cy="18" r="9" fill="#188038" opacity=".14"/><path d="M80 13v10M75 18h10" stroke="#188038" stroke-width="2" stroke-linecap="round"/>' +
    '<circle cx="18" cy="66" r="6" fill="#B06000" opacity=".16"/><circle cx="90" cy="62" r="4" fill="#1A73E8" opacity=".24"/>' +
    '<defs><linearGradient id="kbga" x1="10" y1="16" x2="94" y2="72" gradientUnits="userSpaceOnUse">' +
    '<stop stop-color="#E8F0FE"/><stop offset="1" stop-color="#FEF7E0"/></linearGradient></defs></svg></div>';
  const ART_SEARCH = '<div class="kb-empty-art" aria-hidden="true"><svg width="96" height="80" viewBox="0 0 96 80" fill="none">' +
    '<circle cx="48" cy="38" r="30" fill="#E8F0FE"/><circle cx="43" cy="34" r="13" stroke="#1A73E8" stroke-width="3"/>' +
    '<path d="m53 44 10 10" stroke="#1A73E8" stroke-width="3" stroke-linecap="round"/>' +
    '<circle cx="74" cy="18" r="5" fill="#B06000" opacity=".2"/><circle cx="20" cy="60" r="4" fill="#188038" opacity=".22"/></svg></div>';
  const ART_ERROR = '<div class="kb-empty-art kb-empty-art-error" aria-hidden="true"><svg width="96" height="80" viewBox="0 0 96 80" fill="none">' +
    '<circle cx="48" cy="38" r="30" fill="#FCE8E6"/>' +
    '<path d="M48 22v20" stroke="#C5221F" stroke-width="3.2" stroke-linecap="round"/>' +
    '<circle cx="48" cy="51" r="2.4" fill="#C5221F"/>' +
    '<path d="M20 14l6 6M76 14l-6 6" stroke="#DADCE0" stroke-width="2" stroke-linecap="round"/></svg></div>';
  function emptyHTML() {
    const q = STATE.q.trim();
    if (q) {
      return '<div class="kb-empty kb-empty-search" role="status" aria-live="polite">' + ART_SEARCH +
        '<div class="kb-empty-title">没有找到匹配的文件</div>' +
        '<div class="kb-empty-desc">没有文件名或上传人包含「' + esc2(q) + '」。试试更短的关键词，或清空搜索查看全部文件。</div>' +
        '<div class="kb-empty-actions"><button type="button" class="kb-btn" id="kb-empty-clear">' + ICO(I.search, 15) + "清空搜索</button></div></div>";
    }
    if (STATE.folder) {
      return '<div class="kb-empty" role="status" aria-live="polite">' + ART_EMPTY +
        '<div class="kb-empty-title">当前文件夹还是空的</div>' +
        '<div class="kb-empty-desc">把资料上传到「' + esc2(folderLabel(STATE.folder)) + '」，或回到「全部文件」查看其它资料。不支持压缩包与可执行文件。</div>' +
        '<div class="kb-empty-actions"><button type="button" class="kb-btn kb-btn-primary" id="kb-empty-upload">' + ICO(I.upload, 15) + "上传到这个文件夹</button>" +
        '<button type="button" class="kb-btn" data-kb-folder="">' + ICO(I.folder, 15) + "查看全部文件</button></div></div>";
    }
    return '<div class="kb-empty kb-empty-first" role="status" aria-live="polite">' + ART_EMPTY +
      '<div class="kb-empty-title">把第一份资料放进知识库</div>' +
      '<div class="kb-empty-desc">当前工作空间还没有文件。上传制度、规范、工艺等资料，新建规则时可直接引用。' +
      '支持 PDF / DOCX / XLSX / PPTX / TXT / MD / CSV / JSON / 图片 / EML；压缩包与可执行文件不接受。</div>' +
      '<div class="kb-empty-actions"><button type="button" class="kb-btn kb-btn-primary" id="kb-empty-upload">' + ICO(I.upload, 15) + "上传第一份资料</button>" +
      '<button type="button" class="kb-btn" id="kb-empty-folder">' + ICO(I.folderPlus, 15) + "新建文件夹</button></div></div>";
  }
  function errorHTML() {
    return '<div class="kb-empty kb-empty-error" role="alert">' + ART_ERROR +
      '<div class="kb-empty-title">知识库加载失败</div>' +
      '<div class="kb-empty-desc">' + esc2(STATE.error) + '。请重试；仍失败请联系管理员检查服务与权限。</div>' +
      '<div class="kb-empty-actions"><button type="button" class="kb-btn kb-btn-primary" id="kb-retry">' + ICO(I.alert, 15) + "重新加载</button></div></div>";
  }
  function skeletonHTML(n) {
    let rows = "";
    for (let i = 0; i < (n || 6); i++) {
      rows += '<div class="kb-skel-row"><span class="kb-skel kb-skel-box"></span>' +
        '<span class="kb-skel kb-skel-line"></span><span class="kb-skel kb-skel-line2"></span>' +
        '<span class="kb-skel kb-skel-pill"></span><span class="kb-skel kb-skel-pill"></span></div>';
    }
    return '<div class="kb-skel-wrap" role="status" aria-live="polite" aria-busy="true">' +
      '<div class="kb-skel-text">正在加载知识库…</div>' + rows + "</div>";
  }

  /* ---------------- 渲染：文件列表 / 网格 ---------------- */
  function listViewHTML(pageList) {
    const rows = pageList.map((f) => {
      const id = String(f.id);
      const sel = STATE.selected.has(id);
      return '<tr class="kb-row' + (sel ? " kb-row-selected" : "") + '" data-kb-file-row="' + esc2(id) + '">' +
        '<td class="kb-col-check"><input type="checkbox" data-kb-select="' + esc2(id) + '"' + (sel ? " checked" : "") +
        ' aria-label="选择文件 ' + esc2(f.filename || "") + '"></td>' +
        '<td class="kb-col-name"><div class="kb-name-wrap">' + typeChip(f.filename) +
        '<div class="kb-name-text"><button type="button" class="kb-file-name" data-kb-view="' + esc2(id) +
        '" title="点击查看：' + esc2(f.filename || "未命名") + '">' + esc2(f.filename || "未命名") + "</button>" +
        '<div class="kb-file-sub">sha256 ' + esc2(String(f.sha256 || "").slice(0, 12)) + "…</div></div></div></td>" +
        '<td class="kb-col-size">' + fmtSize(f.size) + "</td>" +
        '<td class="kb-col-folder kb-muted">' + esc2(f.folder_name || "未归档") + "</td>" +
        '<td class="kb-col-user kb-muted">' + esc2(f.uploaded_by || "—") + "</td>" +
        '<td class="kb-col-time kb-muted" title="' + esc2(fmtTimeFull(f.created_at)) + '">' + esc2(fmtTime(f.created_at)) + "</td>" +
        '<td class="kb-col-act"><div class="kb-row-actions">' +
        '<button type="button" class="kb-row-btn" data-kb-view="' + esc2(id) + '" title="查看" aria-label="查看 ' + esc2(f.filename || "") + '">' + ICO(I.eye, 15) + "</button>" +
        '<a class="kb-row-btn" title="下载" aria-label="下载 ' + esc2(f.filename || "") + '" ' + downloadAttrs(f) + ">" + ICO(I.download, 15) + "</a>" +
        '<button type="button" class="kb-row-btn" data-kb-rename="' + esc2(id) + '" title="重命名" aria-label="重命名 ' + esc2(f.filename || "") + '">' + ICO(I.rename, 15) + "</button>" +
        '<button type="button" class="kb-row-btn" data-kb-move="' + esc2(id) + '" title="移动到文件夹" aria-label="移动 ' + esc2(f.filename || "") + '">' + ICO(I.move, 15) + "</button>" +
        '<button type="button" class="kb-row-btn kb-row-btn-danger" data-kb-del="' + esc2(id) + '" title="删除（进回收站）" aria-label="删除 ' + esc2(f.filename || "") + '">' + ICO(I.trash, 15) + "</button>" +
        "</div></td></tr>";
    }).join("");
    return '<div class="kb-table-wrap"><table class="kb-table"><thead><tr>' +
      '<th class="kb-col-check"><span class="kb-sr">选择</span></th><th class="kb-col-name">名称</th>' +
      '<th class="kb-col-size">大小</th><th class="kb-col-folder">文件夹</th><th class="kb-col-user">上传人</th>' +
      '<th class="kb-col-time">上传时间</th><th class="kb-col-act">操作</th>' +
      "</tr></thead><tbody>" + rows + "</tbody></table></div>";
  }
  function gridViewHTML(pageList) {
    const cards = pageList.map((f) => {
      const id = String(f.id);
      const sel = STATE.selected.has(id);
      const k = fileKind(f.filename);
      return '<article class="kb-card' + (sel ? " kb-card-selected" : "") + '" data-kb-file-row="' + esc2(id) + '">' +
        '<div class="kb-card-top"><span class="kb-type kb-type-' + k.tone + ' kb-type-lg">' + k.label + "</span>" +
        '<input type="checkbox" data-kb-select="' + esc2(id) + '"' + (sel ? " checked" : "") +
        ' aria-label="选择文件 ' + esc2(f.filename || "") + '"></div>' +
        '<button type="button" class="kb-card-name" data-kb-view="' + esc2(id) + '" title="点击查看：' + esc2(f.filename || "") + '">' +
        esc2(f.filename || "未命名") + "</button>" +
        '<div class="kb-card-meta">' + fmtSize(f.size) + " · " + esc2(f.uploaded_by || "—") + "</div>" +
        '<div class="kb-card-sub">' + esc2(f.folder_name || "未归档") + "</div>" +
        '<div class="kb-card-foot"><span class="kb-card-time" title="' + esc2(fmtTimeFull(f.created_at)) + '">' + esc2(fmtTime(f.created_at)) + "</span>" +
        '<span class="kb-card-acts">' +
        '<button type="button" class="kb-row-btn" data-kb-view="' + esc2(id) + '" title="查看" aria-label="查看 ' + esc2(f.filename || "") + '">' + ICO(I.eye, 15) + "</button>" +
        '<a class="kb-row-btn" title="下载" aria-label="下载 ' + esc2(f.filename || "") + '" ' + downloadAttrs(f) + ">" + ICO(I.download, 15) + "</a>" +
        '<button type="button" class="kb-row-btn" data-kb-rename="' + esc2(id) + '" title="重命名" aria-label="重命名 ' + esc2(f.filename || "") + '">' + ICO(I.rename, 15) + "</button>" +
        '<button type="button" class="kb-row-btn" data-kb-move="' + esc2(id) + '" title="移动到文件夹" aria-label="移动 ' + esc2(f.filename || "") + '">' + ICO(I.move, 15) + "</button>" +
        '<button type="button" class="kb-row-btn kb-row-btn-danger" data-kb-del="' + esc2(id) + '" title="删除（进回收站）" aria-label="删除 ' + esc2(f.filename || "") + '">' + ICO(I.trash, 15) + "</button>" +
        "</span></div></article>";
    }).join("");
    return '<div class="kb-grid">' + cards + "</div>";
  }
  function renderFiles() {
    const box = $kb("kb-file-list");
    if (!box) return;
    renderCrumbs();
    const head = $kb("kb-list-head");
    if (STATE.loading && !STATE.loaded) {
      box.innerHTML = skeletonHTML(6);
      box.setAttribute("aria-busy", "true");
      if (head) head.innerHTML = "";
      renderPager(0);
      renderBatch();
      return;
    }
    box.removeAttribute("aria-busy");
    if (STATE.error) {
      box.innerHTML = errorHTML();
      if (head) head.innerHTML = "";
      renderPager(0);
      renderBatch();
      return;
    }
    const list = visibleFiles();
    const pages = totalPages(list);
    if (STATE.page >= pages) STATE.page = pages - 1;
    const pageList = pageFiles(list);
    if (head) head.innerHTML = list.length ? listHeadHTML(list, pageList) : "";
    if (!list.length) {
      box.innerHTML = emptyHTML();
      renderPager(0);
      renderBatch();
      return;
    }
    box.innerHTML = STATE.view === "grid" ? gridViewHTML(pageList) : listViewHTML(pageList);
    renderPager(list.length);
    renderBatch();
  }
  function refreshCounts() { renderStats(); renderFolders(); renderCrumbs(); }

  /* ---------------- 上传队列 ---------------- */
  let uploadSeq = 0;
  let trayTimer = null;
  function uploadSummary() {
    const items = STATE.uploads;
    const up = items.filter((u) => u.status === "uploading").length;
    const ok = items.filter((u) => u.status === "done").length;
    const bad = items.filter((u) => u.status === "failed").length;
    let s = "";
    if (up) s += "上传中 " + up + " 个";
    if (ok) s += (s ? " · " : "") + "成功 " + ok + " 个";
    if (bad) s += (s ? " · " : "") + "失败 " + bad + " 个";
    return s || "等待选择文件";
  }
  function uploadRowsHTML(items, withClose) {
    const head = '<div class="kb-up-head"><span class="kb-up-title">上传队列</span><span class="kb-up-summary">' +
      esc2(uploadSummary()) + "</span>" +
      (withClose ? '<button type="button" class="kb-icon-btn kb-up-close" data-kb-tray-close aria-label="清空上传队列">×</button>' : "") + "</div>";
    const rows = items.map((u) => {
      const pct = u.status === "done" ? 100 : u.progress;
      const state = u.status === "uploading" ? (u.progress ? u.progress + "%" : "上传中…")
        : u.status === "done" ? (u.dedup ? "已存在" : "已上传") : "失败";
      return '<div class="kb-up-row" data-status="' + esc2(u.status) + '" data-uid="' + esc2(u.uid) + '">' +
        '<span class="kb-up-name" title="' + esc2(u.name) + '">' + esc2(u.name) + "</span>" +
        '<span class="kb-up-bar" aria-hidden="true"><i style="width:' + Math.max(3, Math.min(100, Number(pct) || 0)) + '%"></i></span>' +
        '<span class="kb-up-state">' + esc2(state) + "</span>" +
        (u.status === "failed"
          ? '<button type="button" class="kb-link-btn" data-kb-retry-upload="' + esc2(u.uid) + '">重试</button>' +
            '<span class="kb-up-err" title="' + esc2(u.error) + '">' + esc2(u.error) + "</span>"
          : "") + "</div>";
    }).join("");
    return head + '<div class="kb-up-list">' + rows + "</div>";
  }
  function renderUploads() {
    const tray = $kb("kb-upload-tray");
    if (tray) {
      if (!STATE.uploads.length) { tray.hidden = true; tray.innerHTML = ""; }
      else { tray.hidden = false; tray.innerHTML = uploadRowsHTML(STATE.uploads, true); }
    }
    const mlist = $kb("kb-upload-modal-list");
    if (mlist) mlist.innerHTML = STATE.uploads.length ? uploadRowsHTML(STATE.uploads, false) : '<div class="kb-up-empty">' + ICO(I.upload, 20) + "<span>还没有选择文件。拖拽文件到上方区域，或点击「选择文件」。</span></div>";
    const msum = $kb("kb-upload-summary");
    if (msum) msum.textContent = uploadSummary();
    const active = STATE.uploads.some((u) => u.status === "uploading");
    if (!active && STATE.uploads.length) {
      if (trayTimer) clearTimeout(trayTimer);
      trayTimer = setTimeout(() => { if (!STATE.uploads.some((u) => u.status === "uploading")) renderUploadsHide(); }, 6000);
    }
  }
  function renderUploadsHide() {
    const tray = $kb("kb-upload-tray");
    if (tray) { tray.hidden = true; tray.innerHTML = ""; }
    STATE.uploads = [];
    const mlist = $kb("kb-upload-modal-list");
    if (mlist) mlist.innerHTML = "";
    const msum = $kb("kb-upload-summary");
    if (msum) msum.textContent = "等待选择文件";
    renderUploads();
  }
  function clearUploads() {
    if (STATE.uploads.some((u) => u.status === "uploading")) { toast("还有文件在上传中，完成后再清空。", "err"); return; }
    STATE.uploads = [];
    renderUploads();
  }
  /* 通用弹窗壳：挂 body、data-cancel/遮罩关闭、关闭后把焦点还给触发按钮。
   * 焦点回填写在这里（T-188 P2-1）：全局 ux 层在「打开当帧就 focus 到弹窗内」时会
   * 拿不到 previousFocus，所以知识库弹窗自己记录触发元素并在关闭时恢复。 */
  function openMask(id, innerHTML, onReady) {
    closeModal(id);
    const trigger = document.activeElement;
    const mask = document.createElement("div");
    mask.id = id;
    mask.className = "modal-mask kb-modal-mask";
    mask.innerHTML = innerHTML;
    document.body.appendChild(mask);
    const close = () => {
      if (!mask.isConnected) return;
      mask.remove();
      window.setTimeout(() => {
        if (document.activeElement && document.activeElement !== document.body) return;
        if (trigger && trigger.isConnected && typeof trigger.focus === "function") {
          try { trigger.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
        }
      }, 0);
    };
    mask.querySelectorAll("[data-cancel]").forEach((b) => { b.onclick = close; });
    mask.onclick = (e) => { if (e.target === mask) close(); };
    if (typeof onReady === "function") onReady(mask, close);
    return { mask, close };
  }
  function startUpload(item) {
    item.status = "uploading"; item.progress = 0; item.error = "";
    renderUploads();
    const fd = new FormData();
    fd.append("file", item.file, item.file.name);
    if (STATE.folder && STATE.folder !== "root") fd.append("folder_id", STATE.folder);
    fd.append("source", "knowledge_ui");
    const xhr = new XMLHttpRequest();
    xhr.open("POST", API + "/files");
    xhr.timeout = UPLOAD_TIMEOUT_MS;  // P2-9：网络半开不再永远「上传中」
    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable || !e.total) return;
      item.progress = Math.max(1, Math.min(99, Math.round((e.loaded / e.total) * 100)));
      renderUploads();
    };
    xhr.onload = () => {
      let d = {};
      try { d = JSON.parse(xhr.responseText || "{}"); } catch (e) { d = {}; }
      const okHttp = xhr.status >= 200 && xhr.status < 300;
      if (okHttp && !d.error && d.ok !== false) {
        item.status = "done"; item.progress = 100; item.dedup = !!d.deduplicated;
        const name = (d.file && d.file.filename) || item.name;
        const okMsg = d.restored_from_recycle
          ? "回收站中已有相同文件，已自动恢复：" + name + "。"
          : d.deduplicated
            ? "知识库已有相同文件（sha256 一致），未重复保存：" + name + "。"
            : "已上传到知识库" + (STATE.folder ? "当前文件夹" : "（未归档）") + "：" + name + "。";
        setMsg(okMsg, "ok");
        toast(d.restored_from_recycle ? "回收站中的相同文件已恢复" :
          d.deduplicated ? "知识库已有相同文件，未重复保存" : "上传成功：" + name, "ok");
        STATE.loaded = false;
        scheduleReload(okMsg);
      } else {
        item.status = "failed";
        item.error = friendlyError(d && d.error, (d && d.code) || "", xhr.status);
        setMsg("上传失败：" + item.error + "。文件未写入知识库。", "err");
        const msgEl = $kb("kb-msg");
        if (msgEl && d && d.code) msgEl.title = "错误码：" + d.code;
        toast("上传失败：" + item.error, "err");
      }
      renderUploads();
    };
    xhr.onerror = () => {
      item.status = "failed"; item.error = ERROR_TEXT.network_error;
      setMsg("上传失败：网络异常，请检查网络后重试。文件未写入知识库。", "err");
      renderUploads();
    };
    xhr.ontimeout = () => {
      item.status = "failed"; item.error = "上传超时，请检查网络后重试";
      setMsg("上传失败：上传超时。文件未写入知识库。", "err");
      renderUploads();
    };
    xhr.send(fd);
  }
  function uploadFiles(fileList) {
    const files = Array.from(fileList || []).filter(Boolean);
    if (!files.length) return;
    if (document.querySelector("#kb-upload-modal-list") && !STATE.uploads.some((u) => u.status === "uploading")) {
      // 每次打开上传弹窗时，清掉上轮已完成的队列，只看本轮
      if (!STATE.uploads.length) renderUploads();
    }
    files.forEach((file) => {
      const item = { uid: "up_" + (++uploadSeq), name: file.name, size: file.size, file: file, status: "uploading", progress: 0, error: "", dedup: false };
      STATE.uploads.push(item);
      // P2-6：50MB 上限前端预检——直接给用户语言，不把内部 body/base64 细节抛给用户
      if (Number(file.size) > MAX_UPLOAD_BYTES) {
        item.status = "failed";
        item.error = "文件超过 50MB 上限，请压缩后重试";
        setMsg("上传失败：" + item.error + "。文件未写入知识库。", "err");
        toast("上传失败：" + item.error, "err");
        return;
      }
      startUpload(item);
    });
    if (STATE.uploads.some((u) => u.status === "uploading")) {
      setMsg("正在上传 " + STATE.uploads.filter((u) => u.status === "uploading").length + " 个文件到「" + folderLabel(STATE.folder) + "」…", "ok");
    }
    renderUploads();
  }
  function retryUpload(uid) {
    const item = (STATE.uploads || []).find((u) => u.uid === uid && u.status === "failed");
    if (!item) return;
    startUpload(item);
  }

  /* ---------------- 上传弹窗 ---------------- */
  function closeModal(id) {
    const el = $kb(id);
    if (el) el.remove();
  }
  function openUploadModal() {
    ensureFileInput();
    if (!STATE.uploads.some((u) => u.status === "uploading")) STATE.uploads = [];
    const wrap = openMask("kb-upload-modal",
      '<div class="kb-modal kb-modal-upload" role="dialog" aria-modal="true" aria-labelledby="kb-upload-title">' +
      '<div class="kb-modal-head"><div><h3 id="kb-upload-title">上传文件到知识库</h3>' +
      '<p class="kb-modal-sub">目标位置：<b class="kb-target-chip">' + esc2(folderLabel(STATE.folder)) + "</b> · 当前工作空间：" +
      esc2(STATE.workspace || "—") + "</p></div>" +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' +
      '<div class="kb-drop" id="kb-upload-drop" tabindex="0" role="button" autofocus aria-label="拖拽文件到此处或选择文件">' +
      '<div class="kb-drop-ico">' + ICO(I.upload, 26) + "</div>" +
      '<div class="kb-drop-main">拖拽文件到这里，或 <span class="kb-link">选择文件</span></div>' +
      '<div class="kb-drop-hint">单个文件 ≤ 50MB · 支持 Office / PDF / 文本 / 图片 / EML，不支持压缩包与可执行文件</div>' +
      "</div>" +
      '<div class="kb-format-chips"><span class="kb-chip kb-chip-pdf">PDF</span><span class="kb-chip kb-chip-doc">DOCX</span>' +
      '<span class="kb-chip kb-chip-sheet">XLSX</span><span class="kb-chip kb-chip-slide">PPTX</span>' +
      '<span class="kb-chip kb-chip-text">TXT</span><span class="kb-chip kb-chip-img">图片</span><span class="kb-chip kb-chip-mail">EML</span></div>' +
      '<div class="kb-up-modal-list" id="kb-upload-modal-list"></div>' +
      '<div class="kb-modal-foot"><span class="kb-modal-note" id="kb-upload-summary">等待选择文件</span>' +
      '<button type="button" class="kb-btn kb-btn-ghost" data-cancel>完成</button></div></div>', (mask) => {
        const drop = mask.querySelector("#kb-upload-drop");
        // P1-2 死按钮修复：弹窗挂 body，委托不能绑在 #kb-panel；这里在弹窗根节点上委托，
        // 队列行重绘后「重试」仍可命中（与托盘行为一致，真实重发 XHR）。
        mask.addEventListener("click", (e) => {
          const retry = e.target && e.target.closest && e.target.closest("[data-kb-retry-upload]");
          if (retry) {
            e.preventDefault();
            retryUpload(retry.getAttribute("data-kb-retry-upload"));
          }
        });
        drop.onclick = () => $kb("kb-file-input")?.click();
        drop.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $kb("kb-file-input")?.click(); } };
        ["dragenter", "dragover"].forEach((t) => drop.addEventListener(t, (e) => {
          e.preventDefault(); e.stopPropagation(); drop.classList.add("kb-dragover");
        }));
        ["dragleave", "dragend"].forEach((t) => drop.addEventListener(t, () => drop.classList.remove("kb-dragover")));
        drop.addEventListener("drop", (e) => {
          e.preventDefault(); e.stopPropagation(); drop.classList.remove("kb-dragover");
          uploadFiles(e.dataTransfer?.files);
        });
        renderUploads();
        // 主操作落点：拖拽区（不是右上关闭按钮）；延迟一帧避开全局 ux 首次聚焦扫描。
        window.setTimeout(() => {
          if (drop.isConnected && document.activeElement !== drop) {
            try { drop.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
          }
        }, 40);
      });
    return wrap;
  }

  /* ---------------- 新建文件夹弹窗 ---------------- */
  function openFolderModal() {
    openMask("kb-folder-modal",
      '<div class="kb-modal kb-modal-sm" role="dialog" aria-modal="true" aria-labelledby="kb-folder-title">' +
      '<div class="kb-modal-head"><div><h3 id="kb-folder-title">新建一级文件夹</h3>' +
      '<p class="kb-modal-sub">只支持一级文件夹，用于给知识库资料做单层归档。</p></div>' +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' +
      '<label class="kb-field"><span>文件夹名称</span>' +
      '<input id="kb-folder-name" class="kb-input" maxlength="40" placeholder="例如：企业标准 / 审核规范" autocomplete="off" autofocus></label>' +
      '<div class="kb-hint-row"><span>最多 40 个字；同空间同名文件夹会被拒绝。</span><span class="kb-count" id="kb-folder-count">0/40</span></div>' +
      '<div class="kb-modal-err" id="kb-folder-err" role="alert"></div>' +
      '<div class="kb-modal-foot"><button type="button" class="kb-btn kb-btn-ghost" data-cancel>取消</button>' +
      '<button type="button" class="kb-btn kb-btn-primary" id="kb-folder-save">创建文件夹</button></div></div>',
      (mask, close) => {
        const input = mask.querySelector("#kb-folder-name");
        const counter = mask.querySelector("#kb-folder-count");
        const err = mask.querySelector("#kb-folder-err");
        if (input) {
          input.addEventListener("input", () => { if (counter) counter.textContent = String(input.value.length) + "/40"; });
          // 焦点落点：输入框（autofocus 交给全局 UX 层；延迟兜底，避免落回右上「×」）
          window.setTimeout(() => {
            if (input.isConnected && document.activeElement !== input) {
              try { input.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
            }
          }, 40);
        }
        const save = async () => {
          const name = (input?.value || "").trim();
          if (err) err.textContent = "";
          if (!name) { if (err) err.textContent = "请输入文件夹名称"; if (input) input.focus(); return; }
          const btn = mask.querySelector("#kb-folder-save");
          if (btn) { btn.disabled = true; btn.textContent = "创建中…"; }
          try {
            await apiJson(API + "/folders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: name }) });
            close();
            toast("已创建文件夹：" + name, "ok");
            STATE.loaded = false;
            await loadKnowledge(true);
          } catch (e) {
            if (err) err.textContent = e.message || "创建失败";
            if (btn) { btn.disabled = false; btn.textContent = "创建文件夹"; }
          }
        };
        mask.querySelector("#kb-folder-save")?.addEventListener("click", save);
        input?.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); save(); } });
      });
  }

  /* ---------------- 重命名弹窗（文件 / 文件夹共用） ---------------- */
  function openRename(kind, id) {
    const isFolder = kind === "folder";
    const target = isFolder
      ? STATE.folders.find((x) => String(x.id) === String(id))
      : findFile(id);
    if (!target) return;
    const oldName = String(isFolder ? (target.name || "") : (target.filename || ""));
    const maxLen = isFolder ? 40 : 180;
    openMask("kb-rename-modal",
      '<div class="kb-modal kb-modal-sm" role="dialog" aria-modal="true" aria-labelledby="kb-rename-title">' +
      '<div class="kb-modal-head"><div><h3 id="kb-rename-title">' + (isFolder ? "重命名文件夹" : "重命名文件") + "</h3>" +
      '<p class="kb-modal-sub">' + (isFolder ? "只改这一层文件夹名称，文件夹内文件随之保留。" :
        "只改文件名；扩展名需保持在支持的类型内（不能改成可执行文件/压缩包）。") + "</p></div>" +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' +
      '<label class="kb-field"><span>新名称</span>' +
      '<input id="kb-rename-name" class="kb-input" maxlength="' + maxLen + '" autocomplete="off" autofocus></label>' +
      '<div class="kb-hint-row"><span id="kb-rename-hint">原名称：' + esc2(oldName) + "</span>" +
      '<span class="kb-count" id="kb-rename-count">' + oldName.length + "/" + maxLen + "</span></div>" +
      '<div class="kb-modal-err" id="kb-rename-err" role="alert"></div>' +
      '<div class="kb-modal-foot"><button type="button" class="kb-btn kb-btn-ghost" data-cancel>取消</button>' +
      '<button type="button" class="kb-btn kb-btn-primary" id="kb-rename-save">保存</button></div></div>',
      (mask, close) => {
        const input = mask.querySelector("#kb-rename-name");
        const counter = mask.querySelector("#kb-rename-count");
        const err = mask.querySelector("#kb-rename-err");
        input.value = oldName;
        if (counter) counter.textContent = String(oldName.length) + "/" + maxLen;
        input.addEventListener("input", () => { if (counter) counter.textContent = String(input.value.length) + "/" + maxLen; });
        window.setTimeout(() => {
          if (!input.isConnected) return;
          try { input.focus({ preventScroll: true }); input.select(); } catch (e) { /* ignore */ }
        }, 40);
        const btn = mask.querySelector("#kb-rename-save");
        const save = async () => {
          const name = (input.value || "").trim();
          if (err) err.textContent = "";
          if (!name) { if (err) err.textContent = "请输入新名称"; return; }
          btn.disabled = true; btn.textContent = "保存中…";
          try {
            await apiJson(API + "/files", { method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ op: "rename", kind: kind, id: String(id), name: name }) });
            close();
            toast("已重命名：" + name, "ok");
            STATE.loaded = false;
            await loadKnowledge(true);
          } catch (e) {
            btn.disabled = false; btn.textContent = "保存";
            if (err) err.textContent = (e.message || "重命名失败");
            if (err && e.code) err.title = "错误码：" + e.code;
          }
        };
        btn?.addEventListener("click", save);
        input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); save(); } });
      });
  }

  /* ---------------- 移动弹窗（单文件 / 批量） ---------------- */
  function openMove(ids) {
    const list = (ids || []).map((id) => findFile(id)).filter(Boolean);
    if (!list.length) return;
    const first = list[0];
    const cur = String(first.folder_id || "");
    const folderOptions = STATE.folders.map((f) =>
      '<label class="kb-move-opt"><input type="radio" name="kb-move-target" value="' + esc2(f.id) + '"' +
      (String(f.id) === cur ? " checked" : "") + "><span>" + ICO(I.folder, 14) + esc2(f.name) + "</span></label>").join("");
    openMask("kb-move-modal",
      '<div class="kb-modal kb-modal-sm" role="dialog" aria-modal="true" aria-labelledby="kb-move-title">' +
      '<div class="kb-modal-head"><div><h3 id="kb-move-title">移动 ' + list.length + " 个文件</h3>" +
      '<p class="kb-modal-sub">选择目标文件夹；移动到「未归档」表示不归入任何文件夹。</p></div>' +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' +
      '<div class="kb-move-list" role="radiogroup" aria-label="目标文件夹">' +
      '<label class="kb-move-opt"><input type="radio" name="kb-move-target" value=""' + (!cur ? " checked" : "") +
      "><span>" + ICO(I.inbox, 14) + "未归档</span></label>" + folderOptions + "</div>" +
      (STATE.folders.length ? "" : '<div class="kb-hint-row"><span>还没有文件夹，可先在知识库「新建文件夹」。</span></div>') +
      '<div class="kb-modal-err" id="kb-move-err" role="alert"></div>' +
      '<div class="kb-modal-foot"><button type="button" class="kb-btn kb-btn-ghost" data-cancel>取消</button>' +
      '<button type="button" class="kb-btn kb-btn-primary" id="kb-move-save">移动到此处</button></div></div>',
      (mask, close) => {
        window.setTimeout(() => {
          const firstRadio = mask.querySelector('input[name="kb-move-target"]');
          if (firstRadio && firstRadio.isConnected) { try { firstRadio.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
        }, 40);
        const save = async () => {
          const picked = mask.querySelector('input[name="kb-move-target"]:checked');
          if (!picked) return;
          const err = mask.querySelector("#kb-move-err");
          const btn = mask.querySelector("#kb-move-save");
          btn.disabled = true; btn.textContent = "移动中…";
          try {
            const d = await apiJson(API + "/files", { method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ op: "move", ids: list.map((f) => String(f.id)), folder_id: picked.value || "" }) });
            close();
            const to = picked.value ? folderLabel(picked.value) : "未归档";
            const skipped = (d.skipped || []).length;
            const msg = "已移动 " + (d.count || 0) + " 个文件到「" + to + "」" +
              (skipped ? "（" + skipped + " 个已在目标位置，跳过）" : "");
            toast(msg, "ok");
            STATE.loaded = false;
            await loadKnowledge(true);
            clearSelection();
          } catch (e) {
            btn.disabled = false; btn.textContent = "移动到此处";
            if (err) { err.textContent = e.message || "移动失败"; if (e.code) err.title = "错误码：" + e.code; }
          }
        };
        mask.querySelector("#kb-move-save")?.addEventListener("click", save);
      });
  }

  /* ---------------- 回收站（软删恢复 / 彻底删除） ---------------- */
  function recycleRowHTML(it, kind) {
    const isFolder = kind === "folder";
    const id = String(it.id || "");
    const name = String((isFolder ? (it.display_name || it.name) : it.filename) || "未命名");
    const meta = isFolder
      ? ((Number(it.file_count) || 0) + " 个文件 · 删除于 " + fmtTime(it.deleted_at))
      : (fmtSize(it.size) + " · " + (it.folder_name || "未归档") + " · 删除于 " + fmtTime(it.deleted_at));
    return '<div class="kb-recycle-row" data-recycle-kind="' + kind + '" data-recycle-id="' + esc2(id) + '">' +
      '<span class="kb-pick-ico">' + (isFolder ? ICO(I.folder, 18).replace('class="kb-ico"', 'class="kb-ico kb-ico-folder"') : typeChip(name)) + "</span>" +
      '<div class="kb-pick-main"><b title="' + esc2(name) + '">' + esc2(name) + "</b>" +
      '<span class="kb-pick-meta">' + esc2(meta) + " · 操作人 " + esc2(it.deleted_by || "—") + "</span></div>" +
      '<button type="button" class="kb-btn kb-btn-ghost" data-kb-restore="' + esc2(id) + '" data-kb-restore-kind="' + kind + '">' + ICO(I.restore, 14) + "恢复</button>" +
      '<button type="button" class="kb-btn kb-btn-danger-ghost" data-kb-purge="' + esc2(id) + '" data-kb-purge-kind="' + kind + '">' + ICO(I.trash, 14) + "彻底删除</button>" +
      "</div>";
  }
  function recycleBodyHTML() {
    const items = STATE.recycle || { files: [], folders: [], stats: {} };
    const folders = items.folders || [];
    const files = items.files || [];
    if (!folders.length && !files.length) {
      return '<div class="kb-empty kb-empty-sm"><div class="kb-empty-title">回收站是空的</div>' +
        '<div class="kb-empty-desc">删除的文件会先进入回收站，可在这里恢复或彻底删除；彻底删除后不可恢复。</div></div>';
    }
    return (folders.length ? '<div class="kb-recycle-group"><div class="kb-recycle-title">文件夹（' + folders.length + '）</div>' +
      folders.map((x) => recycleRowHTML(x, "folder")).join("") + "</div>" : "") +
      (files.length ? '<div class="kb-recycle-group"><div class="kb-recycle-title">文件（' + files.length + '）</div>' +
        files.map((x) => recycleRowHTML(x, "file")).join("") + "</div>" : "");
  }
  async function refreshRecycleBox(mask) {
    const box = mask.querySelector("#kb-recycle-list");
    if (!box) return;
    box.innerHTML = '<div class="kb-pick-loading">正在读取回收站…</div>';
    try {
      const d = await apiJson(API + "/recycle");
      STATE.recycle = { files: d.files || [], folders: d.folders || [], stats: d.stats || {} };
      box.innerHTML = recycleBodyHTML();
    } catch (e) {
      box.innerHTML = '<div class="kb-empty kb-empty-sm kb-empty-error"><div class="kb-empty-title">回收站读取失败</div>' +
        '<div class="kb-empty-desc">' + esc2(e.message || "读取失败") + "</div></div>";
    }
  }
  function openRecycle() {
    openMask("kb-recycle-modal",
      '<div class="kb-modal kb-recycle-modal" role="dialog" aria-modal="true" aria-labelledby="kb-recycle-title">' +
      '<div class="kb-modal-head"><div><h3 id="kb-recycle-title">回收站</h3>' +
      '<p class="kb-modal-sub">只显示当前工作空间已删除的文件/文件夹；恢复后回到原位置，「彻底删除」不可恢复。</p></div>' +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' +
      '<div class="kb-pick-list" id="kb-recycle-list"><div class="kb-pick-loading">正在读取回收站…</div></div>' +
      '<div class="kb-modal-foot"><span class="kb-modal-note">恢复不改变文件内容；彻底删除会同时清理物理文件并写审计。</span>' +
      '<span class="kb-foot-spacer"></span><button type="button" class="kb-btn kb-btn-ghost" data-cancel>关闭</button></div></div>',
      (mask, close) => {
        refreshRecycleBox(mask);
        mask.addEventListener("click", async (e) => {
          const t = e.target;
          if (!t || !t.closest) return;
          const rb = t.closest("[data-kb-restore]");
          const pb = t.closest("[data-kb-purge]");
          if (rb) {
            e.preventDefault();
            rb.disabled = true;
            try {
              const d = await apiJson(API + "/files", { method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ op: "restore", kind: rb.getAttribute("data-kb-restore-kind"),
                  ids: [rb.getAttribute("data-kb-restore")] }) });
              toast("已恢复 " + (d.count || 1) + " 项", "ok");
              STATE.loaded = false;
              await Promise.all([refreshRecycleBox(mask), loadKnowledge(true)]);
            } catch (err) {
              rb.disabled = false;
              notifyError("恢复失败：", err);
            }
            return;
          }
          if (pb) {
            e.preventDefault();
            const kind = pb.getAttribute("data-kb-purge-kind");
            const row = pb.closest(".kb-recycle-row");
            const nameEl = row && row.querySelector(".kb-pick-main b");
            const name = nameEl ? nameEl.textContent : "该项";
            const ok = await confirmDanger("彻底删除" + (kind === "folder" ? "文件夹" : "文件"),
              "确认彻底删除「" + name + "」？彻底删除后不可恢复，且会同步清理存储文件并写审计。", "彻底删除");
            if (!ok) return;
            pb.disabled = true;
            try {
              const d = await apiJson(API + "/files", { method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ op: "purge", kind: kind, ids: [pb.getAttribute("data-kb-purge")], confirm: true }) });
              toast("已彻底删除 " + (d.count || 1) + " 项", "ok");
              STATE.loaded = false;
              await Promise.all([refreshRecycleBox(mask), loadKnowledge(true)]);
            } catch (err) {
              pb.disabled = false;
              notifyError("彻底删除失败：", err);
            }
          }
        });
      });
  }

  /* ---------------- 删除（二次确认 → 回收站） ---------------- */
  async function confirmDanger(title, text, okLabel) {
    if (hasApp("confirmAction")) return !!(await window.confirmAction(title, text, okLabel || "删除", true));
    return window.confirm(title + "\n" + text);
  }
  async function trashFilesAPI(ids) {
    return apiJson(API + "/files", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ op: "trash", kind: "file", ids: (ids || []).map(String) }) });
  }
  async function deleteFile(id) {
    const f = findFile(id);
    if (!f) return;
    const ok = await confirmDanger("删除知识库文件",
      "确认删除「" + (f.filename || "") + "」？删除后将移入回收站，可在回收站恢复；" +
      "从回收站彻底删除后不可恢复。", "移入回收站");
    if (!ok) return;
    try {
      await trashFilesAPI([id]);
      toast("已移入回收站：" + (f.filename || ""), "ok");
      STATE.selected.delete(String(id));
      STATE.loaded = false;
      await loadKnowledge(true);
    } catch (e) {
      notifyError("删除失败：", e);
    }
  }
  async function deleteSelected() {
    const ids = [...STATE.selected];
    if (!ids.length) return;
    const names = ids.map((id) => (findFile(id) || {}).filename).filter(Boolean).slice(0, 3);
    const ok = await confirmDanger("删除已选的 " + ids.length + " 个文件",
      "将删除：" + names.join("、") + (ids.length > names.length ? " 等 " + ids.length + " 个文件" : "") +
      "。删除后移入回收站，可恢复；从回收站彻底删除后不可恢复。", "移入回收站");
    if (!ok) return;
    try {
      const d = await trashFilesAPI(ids);
      STATE.selected.clear();
      STATE.loaded = false;
      await loadKnowledge(true);
      const msg = "已移入回收站 " + (d.count || ids.length) + " 个文件，可在回收站恢复。";
      setMsg(msg, "ok");
      toast(msg, "ok");
    } catch (e) {
      notifyError("批量删除失败：", e);
    }
  }
  async function deleteFolder(id) {
    const fol = STATE.folders.find((x) => String(x.id) === String(id));
    if (!fol) return;
    const n = Number(fol.file_count) || 0;
    const ok = await confirmDanger("删除文件夹 " + (fol.name || ""),
      (n ? "文件夹内还有 " + n + " 个文件，确认后文件夹与文件一起移入回收站，可整体恢复；"
        : "文件夹为空，确认后移入回收站，可恢复；") +
      "从回收站彻底删除后不可恢复。", "移入回收站");
    if (!ok) return;
    try {
      await apiJson(API + "/files", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op: "trash", kind: "folder", ids: [String(id)] }) });
      toast("已移入回收站：文件夹「" + (fol.name || "") + "」" +
        (n ? "及 " + n + " 个文件" : ""), "ok");
      if (String(STATE.folder) === String(id)) STATE.folder = "";
      STATE.loaded = false;
      await loadKnowledge(true);
    } catch (e) {
      notifyError("删除文件夹失败：", e);
    }
  }

  /* ---------------- 查看（本页 modal / iframe，不新开页） ---------------- */
  function openViewer(file) {
    if (!file) return;
    closeModal("kb-view-modal");
    const url = viewUrl(file.id);
    const name = String(file.filename || "文件");
    const isOffice = OFFICE_RE.test(name);
    const meta = '<div class="kb-view-meta">' + esc2(fmtSize(file.size)) + ' · ' + esc2(file.folder_name || "未归档") +
      " · 上传人 " + esc2(file.uploaded_by || "—") + " · " + esc2(fmtTimeFull(file.created_at)) + "</div>";
    let body = "";
    if (IMG_RE.test(name)) {
      body = '<div class="kb-view-body"><img class="kb-view-img" src="' + esc2(url) + '" alt="' + esc2(name) + '"></div>';
    } else if (PDF_RE.test(name)) {
      body = '<div class="kb-view-body"><iframe class="kb-view-frame" src="' + esc2(url) + '" title="' + esc2(name) + '"></iframe></div>';
    } else if (TEXT_RE.test(name)) {
      body = '<div class="kb-view-body"><pre class="kb-view-text" id="kb-view-text">正在读取…</pre></div>';
    } else if (isOffice) {
      body = '<div class="kb-view-body kb-view-office"><div class="kb-view-office-ico">' + typeChip(name, true) + "</div>" +
        '<div class="kb-empty-title">该类型不提供页内渲染</div>' +
        '<div class="kb-empty-desc">Word / Excel / PPT / 邮件等文件不在浏览器内直接渲染，避免脚本与宏风险；请使用下方安全下载查看。</div></div>';
    } else {
      body = '<div class="kb-view-body kb-view-office"><div class="kb-empty-desc">该文件类型不支持页内预览，请安全下载后查看。</div></div>';
    }
    const mask = document.createElement("div");
    mask.id = "kb-view-modal";
    mask.className = "modal-mask kb-modal-mask";
    mask.innerHTML = '<div class="kb-modal kb-view-modal" role="dialog" aria-modal="true" aria-labelledby="kb-view-title">' +
      '<div class="kb-modal-head kb-view-head">' +
      '<div class="kb-view-title-wrap"><div class="kb-view-title-line">' + typeChip(name, true) +
      '<h3 id="kb-view-title" title="' + esc2(name) + '">' + esc2(name) + "</h3></div>" + meta + "</div>" +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' + body +
      '<div class="kb-modal-foot"><a class="kb-btn" ' + downloadAttrs(file) + ">" + ICO(I.download, 15) + "下载文件</a>" +
      '<button type="button" class="kb-btn kb-btn-danger-ghost" data-kb-view-del="' + esc2(file.id) + '">' + ICO(I.trash, 15) + "删除</button>" +
      '<span class="kb-foot-spacer"></span><button type="button" class="kb-btn kb-btn-primary" data-cancel>关闭</button></div></div>';
    document.body.appendChild(mask);
    const close = () => mask.remove();
    mask.querySelectorAll("[data-cancel]").forEach((b) => { b.onclick = close; });
    mask.onclick = (e) => { if (e.target === mask) close(); };
    mask.querySelector("[data-kb-view-del]")?.addEventListener("click", () => { close(); deleteFile(file.id); });
    if (TEXT_RE.test(name)) {
      fetch(url).then((r) => { if (!r.ok) throw new Error("HTTP " + r.status); return r.text(); })
        .then((t) => { const pre = mask.querySelector("#kb-view-text"); if (pre) pre.textContent = t; })
        .catch((e) => { const pre = mask.querySelector("#kb-view-text"); if (pre) pre.textContent = "读取失败：" + (e.message || e); });
    }
  }

  /* ---------------- 给「新建规则 · 上传拆解」用的引用选择器（T-188 P1-3） ----------------
   * 125 文件场景下不再全量渲染（scrollH 7374px）：加搜索（文件名/上传人）、目录筛选、
   * 分页（10/页），选中态与底部「引用选中文件」按钮联动。
   */
  function pickFile(opts) {
    const o = opts || {};
    const PS = { all: [], folders: [], q: "", folder: "", page: 0, selectedId: "" };
    let closedByPick = false;
    openMask("kb-pick-modal",
      '<div class="kb-modal kb-pick-modal" role="dialog" aria-modal="true" aria-labelledby="kb-pick-title">' +
      '<div class="kb-modal-head"><div><h3 id="kb-pick-title">' + esc2(o.title || "从知识库引用文件") + "</h3>" +
      '<p class="kb-modal-sub">选择当前工作空间已上传的文件；引用后仍走同一套规则拆解入口，不会复制文件。</p></div>' +
      '<button type="button" class="kb-modal-x" data-cancel aria-label="关闭">×</button></div>' +
      '<div class="kb-pick-toolbar">' +
      '<div class="kb-search kb-pick-search">' + ICO(I.search, 15) +
      '<input id="kb-pick-q" class="kb-search-input" type="search" placeholder="搜索文件名、上传人…" autocomplete="off" aria-label="搜索可引用文件">' +
      '<button type="button" class="kb-search-clear" id="kb-pick-q-clear" aria-label="清空引用搜索" hidden>×</button></div>' +
      '<label class="kb-pick-filter"><span>目录</span><select id="kb-pick-folder" class="kb-select" aria-label="按目录筛选">' +
      '<option value="">全部目录</option><option value="root">未归档</option></select></label>' +
      "</div>" +
      '<div id="kb-pick-info" class="kb-pick-info">正在读取知识库…</div>' +
      '<div id="kb-pick-list" class="kb-pick-list"><div class="kb-pick-loading">正在读取知识库…</div></div>' +
      '<div class="kb-modal-foot"><span id="kb-pick-pager" class="kb-pick-pager" hidden></span>' +
      '<span class="kb-foot-spacer"></span>' +
      '<button type="button" class="kb-btn kb-btn-ghost" data-cancel>取消</button>' +
      '<button type="button" class="kb-btn kb-btn-primary" id="kb-pick-ok" disabled>引用选中文件</button></div></div>',
      (mask, close) => {
        const box = mask.querySelector("#kb-pick-list");
        const info = mask.querySelector("#kb-pick-info");
        const pager = mask.querySelector("#kb-pick-pager");
        const okBtn = mask.querySelector("#kb-pick-ok");
        const qInput = mask.querySelector("#kb-pick-q");
        const qClear = mask.querySelector("#kb-pick-q-clear");
        const fSel = mask.querySelector("#kb-pick-folder");
        const PAGE = 10;
        fSel.addEventListener("change", () => { PS.folder = fSel.value || ""; PS.page = 0; renderPickList(); });
        qInput.addEventListener("input", () => { PS.q = qInput.value || ""; qClear.hidden = !PS.q; PS.page = 0; renderPickList(); });
        qInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); PS.q = qInput.value || ""; PS.page = 0; renderPickList(); } });
        qClear.addEventListener("click", () => { qInput.value = ""; PS.q = ""; qClear.hidden = true; PS.page = 0; renderPickList(); qInput.focus(); });
        okBtn.addEventListener("click", async () => {
          const f = PS.all.find((x) => String(x.id) === String(PS.selectedId));
          if (!f) return;
          okBtn.disabled = true; okBtn.textContent = "读取中…";
          try {
            const blob = await fetchFileBlob(f.id, f.filename || "file");
            closedByPick = true;
            close();
            if (typeof o.onPick === "function") o.onPick(f, blob);
          } catch (e) {
            okBtn.disabled = false; okBtn.textContent = "引用选中文件";
            notifyError("读取知识库文件失败：", e);
          }
        });
        function pickList() {
          let list = PS.all;
          if (PS.folder === "root") list = list.filter((f) => !str(f.folder_id));
          else if (PS.folder) list = list.filter((f) => String(f.folder_id || "") === PS.folder);
          const q = PS.q.trim().toLowerCase();
          if (q) {
            list = list.filter((f) => String(f.filename || "").toLowerCase().includes(q)
              || String(f.uploaded_by || "").toLowerCase().includes(q)
              || String(f.folder_name || "").toLowerCase().includes(q));
          }
          return list;
        }
        function renderPickList() {
          const list = pickList();
          const pages = Math.max(1, Math.ceil(list.length / PAGE));
          if (PS.page >= pages) PS.page = pages - 1;
          const pageList = list.slice(PS.page * PAGE, PS.page * PAGE + PAGE);
          info.textContent = "共 " + list.length + " 个可引用文件" +
            (PS.q ? " · 搜索「" + PS.q + "」" : "") +
            (PS.folder ? " · 目录：" + (PS.folder === "root" ? "未归档" : folderLabel(PS.folder)) : "");
          if (!list.length) {
            box.innerHTML = '<div class="kb-empty kb-empty-sm"><div class="kb-empty-title">' +
              (PS.q || PS.folder ? "没有找到匹配的可引用文件" : "知识库还没有可引用的文件") + "</div>" +
              '<div class="kb-empty-desc">' + (PS.q || PS.folder
                ? "试试更短的关键词，或切换目录后重试。"
                : "先在「规则引擎 · 知识库」上传文件，或在「上传拆解」上传一次（默认会同步到知识库）。" +
                  (typeof o.filter === "function" ? "引用只列出可拆解的制度文件类型（xlsx/docx/pdf/txt/eml）。" : "")) +
              "</div></div>";
            pager.hidden = true;
            return;
          }
          box.innerHTML = pageList.map((f) => {
            const id = String(f.id);
            const office = OFFICE_RE.test(String(f.filename || ""));
            const on = id === String(PS.selectedId);
            return '<div class="kb-pick-row' + (on ? " on" : "") + '" data-kb-pick-row="' + esc2(id) + '" role="button" tabindex="0">' +
              '<input type="radio" class="kb-pick-radio" name="kb-pick-select" data-kb-pick-select="' + esc2(id) + '"' +
              (on ? " checked" : "") + ' aria-label="选择 ' + esc2(f.filename || "") + '">' +
              '<span class="kb-pick-ico">' + typeChip(f.filename) + "</span>" +
              '<div class="kb-pick-main"><b title="' + esc2(f.filename || "") + '">' + esc2(f.filename || "") + "</b>" +
              '<span class="kb-pick-meta">' + fmtSize(f.size) + " · " + esc2(f.folder_name || "未归档") + " · " +
              esc2(String(f.created_at || "").slice(0, 10)) +
              (office ? ' · <span class="kb-pick-tag">office 走安全下载解析</span>' : "") + "</span></div></div>";
          }).join("");
          if (pages <= 1) { pager.hidden = true; pager.innerHTML = ""; }
          else {
            pager.hidden = false;
            pager.innerHTML = '<span class="kb-picker-page-info">第 ' + (PS.page + 1) + " / " + pages + " 页</span>" +
              '<button type="button" class="kb-page-btn kb-pick-prev"' + (PS.page === 0 ? " disabled" : "") + ">上一页</button>" +
              '<button type="button" class="kb-page-btn kb-pick-next"' + (PS.page >= pages - 1 ? " disabled" : "") + ">下一页</button>";
            pager.querySelector(".kb-pick-prev").onclick = () => { if (PS.page > 0) { PS.page -= 1; renderPickList(); } };
            pager.querySelector(".kb-pick-next").onclick = () => { if (PS.page < pages - 1) { PS.page += 1; renderPickList(); } };
          }
          const selectRow = (row) => {
            PS.selectedId = row.getAttribute("data-kb-pick-row") || "";
            box.querySelectorAll(".kb-pick-row").forEach((r) => r.classList.toggle("on", r === row));
            const radio = row.querySelector("[data-kb-pick-select]");
            if (radio) radio.checked = true;
            okBtn.disabled = !PS.selectedId;
          };
          box.querySelectorAll(".kb-pick-row").forEach((row) => {
            row.addEventListener("click", () => selectRow(row));
            row.addEventListener("keydown", (e) => {
              if (e.key === "Enter" || e.key === " ") { e.preventDefault(); selectRow(row); }
            });
          });
          // 选中态与「引用选中文件」按钮联动（选中项可能翻页后仍在 selectedId 中）
          okBtn.disabled = !PS.selectedId;
        }
        apiJson(API).then((d) => {
          let files = d.files || [];
          if (typeof o.filter === "function") files = files.filter(o.filter);
          PS.all = files;
          PS.folders = d.folders || [];
          const opts2 = PS.folders.map((f) => '<option value="' + esc2(f.id) + '">' + esc2(f.name) + "</option>").join("");
          fSel.innerHTML = '<option value="">全部目录</option><option value="root">未归档</option>' + opts2;
          PS.all.sort((a, b) => String(b.created_at || "").localeCompare(String(a.created_at || ""))
            || String(b.id || "").localeCompare(String(a.id || "")));
          renderPickList();
        }).catch((e) => {
          info.textContent = "知识库读取失败";
          box.innerHTML = '<div class="kb-empty kb-empty-sm kb-empty-error"><div class="kb-empty-title">知识库读取失败</div>' +
            '<div class="kb-empty-desc">' + esc2(e.message || "读取失败") + "</div></div>";
        });
        window.setTimeout(() => {
          if (qInput.isConnected && document.activeElement !== qInput) {
            try { qInput.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
          }
        }, 40);
      });
  }
  function str(v) { return String(v == null ? "" : v); }

  /** 读取知识库文件原始内容为 File（引用路径：与上传拆解同一解析入口）。 */
  async function fetchFileBlob(id, filename) {
    const r = await fetch(viewUrl(id));
    if (!r.ok) {
      let msg = "HTTP " + r.status;
      try { const d = await r.json(); if (d && d.error) msg = d.error; } catch (e) { /* 非 JSON 保留 HTTP 状态 */ }
      throw new Error(msg);
    }
    const blob = await r.blob();
    try { return new File([blob], filename, { type: blob.type || "application/octet-stream" }); }
    catch (e) { blob.name = filename; return blob; }
  }

  /** 新建规则上传文件的默认同步（失败抛错，由调用方提示但不阻断规则创建）。 */
  async function uploadForRule(file) {
    const fd = new FormData();
    fd.append("file", file, file.name);
    fd.append("source", "rule_upload");
    const d = await apiJson(API + "/files", { method: "POST", body: fd });
    STATE.loaded = false;
    return d;
  }

  /* ---------------- 交互动作 ---------------- */
  function selectFolder(id) {
    STATE.folder = id || "";
    STATE.page = 0;
    STATE.selected.clear();
    STATE.lastSelectIndex = null;
    renderFolders();
    renderFiles();
    syncDropTarget();
    closeTreeDrawer();
    const box = $kb("kb-file-list");
    if (box && box.scrollIntoView) { try { box.scrollIntoView({ block: "nearest" }); } catch (e) { /* ignore */ } }
  }
  function syncViewToggle() {
    document.querySelectorAll("#kb-panel [data-kb-viewmode]").forEach((b) => {
      const on = b.getAttribute("data-kb-viewmode") === STATE.view;
      b.classList.toggle("on", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
  }
  function setViewMode(mode) {
    if (mode !== "list" && mode !== "grid") return;
    if (STATE.view === mode) return;
    STATE.view = mode;
    STATE.lastSelectIndex = null;
    try { localStorage.setItem(VIEW_STORE_KEY, mode); } catch (e) { /* 隐私模式忽略 */ }
    syncViewToggle();
    renderFiles();
  }
  function setSearch(q) {
    STATE.q = String(q || "");
    STATE.page = 0;
    STATE.lastSelectIndex = null;
    const clearBtn = $kb("kb-q-clear");
    if (clearBtn) clearBtn.hidden = !STATE.q;
    renderFiles();
  }
  function syncDropTarget() {
    const t = $kb("kb-drop-target");
    if (t) t.textContent = folderLabel(STATE.folder);
  }
  function refresh(silent) {
    STATE.loaded = false;
    if (!silent) toast("正在刷新知识库…", "ok");
    return loadKnowledge(true);
  }
  function toggleSelect(id, on) {
    const key = String(id);
    if (on) STATE.selected.add(key); else STATE.selected.delete(key);
    const row = document.querySelector('#kb-file-list [data-kb-file-row="' + key + '"]');
    if (row) {
      if (row.tagName === "TR") row.classList.toggle("kb-row-selected", on);
      else row.classList.toggle("kb-card-selected", on);
      const cb = row.querySelector("[data-kb-select]");
      if (cb && cb.checked !== on) cb.checked = on;
    }
    renderBatch();
    updateSelectAll();
  }
  /* T-188 P2-2：Shift 区间连选（列表 + 网格都按 DOM 顺序；从上次点击行选到当前行）。 */
  function handleRowCheckboxClick(cb, shiftKey) {
    const box = $kb("kb-file-list");
    if (!box) return;
    const boxes = [...box.querySelectorAll("[data-kb-select]")];
    const idx = boxes.indexOf(cb);
    if (idx < 0) return;
    const on = !!cb.checked;
    const last = STATE.lastSelectIndex;
    if (shiftKey && last != null && last >= 0 && last < boxes.length) {
      const from = Math.min(last, idx), to = Math.max(last, idx);
      for (let i = from; i <= to; i++) {
        const b = boxes[i];
        b.checked = on;
        toggleSelect(b.getAttribute("data-kb-select"), on);
      }
    } else {
      toggleSelect(cb.getAttribute("data-kb-select"), on);
    }
    STATE.lastSelectIndex = idx;
    renderBatch();
    updateSelectAll();
  }
  function updateSelectAll() {
    const all = $kb("kb-select-all");
    if (!all) return;
    const box = $kb("kb-file-list");
    const rows = box ? [...box.querySelectorAll("[data-kb-file-row]")] : [];
    const ids = rows.map((r) => String(r.getAttribute("data-kb-file-row")));
    all.checked = ids.length > 0 && ids.every((id) => STATE.selected.has(id));
    all.indeterminate = !all.checked && ids.some((id) => STATE.selected.has(id));
  }
  function setPageSelect(on) {
    const box = $kb("kb-file-list");
    if (!box) return;
    box.querySelectorAll("[data-kb-file-row]").forEach((r) => {
      const id = String(r.getAttribute("data-kb-file-row"));
      if (on) STATE.selected.add(id); else STATE.selected.delete(id);
      if (r.tagName === "TR") r.classList.toggle("kb-row-selected", on);
      else r.classList.toggle("kb-card-selected", on);
      const cb = r.querySelector("[data-kb-select]");
      if (cb) cb.checked = on;
    });
    STATE.lastSelectIndex = null;
    renderBatch();
    updateSelectAll();
  }
  function clearSelection() {
    STATE.selected.clear();
    STATE.lastSelectIndex = null;
    const box = $kb("kb-file-list");
    if (box) box.querySelectorAll("[data-kb-select]").forEach((cb) => { cb.checked = false; });
    if (box) box.querySelectorAll(".kb-row-selected,.kb-card-selected").forEach((r) => r.classList.remove("kb-row-selected", "kb-card-selected"));
    renderBatch();
    updateSelectAll();
  }
  /* ---------------- 窄屏目录抽屉（P1-5：≤1180 目录树不再排在文件列表下方） ---------------- */
  function treeDrawerEls() {
    return { tree: document.querySelector("#kb-panel .kb-tree"), scrim: $kb("kb-tree-scrim"), btn: $kb("kb-tree-toggle") };
  }
  function openTreeDrawer() {
    const { tree, scrim, btn } = treeDrawerEls();
    if (!tree) return;
    tree.classList.add("open");
    if (scrim) { scrim.hidden = false; window.setTimeout(() => scrim.classList.add("show"), 10); }
    if (btn) btn.setAttribute("aria-expanded", "true");
  }
  function closeTreeDrawer() {
    const { tree, scrim, btn } = treeDrawerEls();
    if (!tree) return;
    tree.classList.remove("open");
    if (scrim) { scrim.classList.remove("show"); scrim.hidden = true; }
    if (btn) btn.setAttribute("aria-expanded", "false");
  }
  function toggleTreeDrawer() {
    const { tree } = treeDrawerEls();
    if (!tree) return;
    if (tree.classList.contains("open")) closeTreeDrawer(); else openTreeDrawer();
  }

  /* ---------------- 加载 ---------------- */
  async function loadKnowledge(force) {
    if (STATE.loading) return;
    if (STATE.loaded && !force) return;
    STATE.loading = true;
    STATE.error = "";
    renderAll();
    try {
      const d = await apiJson(API);
      STATE.loaded = true;
      STATE.folders = d.folders || [];
      STATE.files = d.files || [];
      STATE.stats = d.stats || {};
      STATE.workspace = d.workspace_name || "";
      pruneSelection();
      setMsg("");
    } catch (e) {
      STATE.loaded = false;
      STATE.folders = [];
      STATE.files = [];
      STATE.stats = {};
      STATE.error = e.message || String(e);
      setMsg("知识库加载失败：" + STATE.error + "。", "err");
    } finally {
      STATE.loading = false;
      renderAll();
      if (STATE.afterReloadMsg && !STATE.error) {
        setMsg(STATE.afterReloadMsg, "ok");
        STATE.afterReloadMsg = "";
      }
    }
  }
  function renderAll() {
    renderScope();
    renderStats();
    renderFolders();
    renderFiles();
    syncDropTarget();
  }
  let reloadTimer = null;
  /* 上传后刷新列表：刷新完成时 loadKnowledge 会清空状态文案，这里保留成功提示，
   * 保证「列表已出现 + 提示可见」同时成立（与旧版时序一致）。 */
  function scheduleReload(keepMsg) {
    if (reloadTimer) clearTimeout(reloadTimer);
    if (keepMsg) STATE.afterReloadMsg = keepMsg;
    reloadTimer = setTimeout(() => { STATE.loaded = false; loadKnowledge(true); }, 260);
  }

  /* ---------------- 事件绑定 ---------------- */
  function onPanelClick(e) {
    const t = e.target;
    if (!t || !t.closest) return;
    const panel = $kb("kb-panel");
    if (!panel || !panel.contains(t)) return;
    // Shift 区间连选（P2-2）：复选框点击用 click 事件（能带 shiftKey）处理，
    // change 事件只兜底（键盘/程序化点击），两边最终状态一致。
    const cb = t.closest("[data-kb-select]");
    if (cb && cb.tagName === "INPUT") { handleRowCheckboxClick(cb, !!e.shiftKey); return; }
    const viewBtn = t.closest("[data-kb-view]");
    if (viewBtn) { const f = findFile(viewBtn.getAttribute("data-kb-view")); if (f) openViewer(f); return; }
    const ren = t.closest("[data-kb-rename]");
    if (ren) { e.preventDefault(); e.stopPropagation(); openRename("file", ren.getAttribute("data-kb-rename")); return; }
    const mv = t.closest("[data-kb-move]");
    if (mv) { e.preventDefault(); e.stopPropagation(); openMove([mv.getAttribute("data-kb-move")]); return; }
    const del = t.closest("[data-kb-del]");
    if (del) { e.preventDefault(); e.stopPropagation(); deleteFile(del.getAttribute("data-kb-del")); return; }
    const fren = t.closest("[data-kb-folder-rename]");
    if (fren) { e.preventDefault(); e.stopPropagation(); openRename("folder", fren.getAttribute("data-kb-folder-rename")); return; }
    const fdel = t.closest("[data-kb-folder-del]");
    if (fdel) { e.preventDefault(); e.stopPropagation(); deleteFolder(fdel.getAttribute("data-kb-folder-del")); return; }
    const folder = t.closest("[data-kb-folder]");
    if (folder) { selectFolder(folder.getAttribute("data-kb-folder") || ""); return; }
    const page = t.closest("[data-kb-page]");
    if (page) {
      STATE.page = Number(page.getAttribute("data-kb-page")) || 0;
      STATE.lastSelectIndex = null;
      renderFiles();
      return;
    }
    const vm = t.closest("[data-kb-viewmode]");
    if (vm) { setViewMode(vm.getAttribute("data-kb-viewmode")); return; }
    const retry = t.closest("[data-kb-retry-upload]");
    if (retry) { retryUpload(retry.getAttribute("data-kb-retry-upload")); return; }
    if (t.closest("[data-kb-tray-close]")) { clearUploads(); return; }
    if (t.closest("#kb-recycle-btn")) { openRecycle(); return; }
    if (t.closest("#kb-tree-toggle")) { toggleTreeDrawer(); return; }
    if (t.closest("#kb-tree-scrim")) { closeTreeDrawer(); return; }
    if (t.closest("#kb-empty-upload")) {
      if (document.querySelector("#kb-upload-modal")) $kb("kb-file-input")?.click();
      else openUploadModal();
      return;
    }
    if (t.closest("#kb-empty-folder")) { openFolderModal(); return; }
    if (t.closest("#kb-empty-clear")) { setSearch(""); const q = $kb("kb-q"); if (q) q.value = ""; return; }
    if (t.closest("#kb-retry")) { refresh(); return; }
  }
  function onPanelChange(e) {
    const t = e.target;
    if (!t) return;
    if (t.id === "kb-select-all") { setPageSelect(!!t.checked); return; }
    const sel = t.closest("[data-kb-select]");
    if (sel) {
      // 键盘 Space / 程序化 .click() 不经过上面的 click 分支（例如辅助技术）；
      // 以 checked 为准同步状态即可（不重复翻转）。
      const key = String(sel.getAttribute("data-kb-select"));
      if (!!sel.checked) STATE.selected.add(key); else STATE.selected.delete(key);
      const row = sel.closest("[data-kb-file-row]");
      if (row) {
        if (row.tagName === "TR") row.classList.toggle("kb-row-selected", !!sel.checked);
        else row.classList.toggle("kb-card-selected", !!sel.checked);
      }
      renderBatch();
      updateSelectAll();
    }
  }
  function onDocKeydown(e) {
    if (e.defaultPrevented) return;
    const tag = (e.target && e.target.tagName) || "";
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(tag) || !!(e.target && e.target.isContentEditable);
    const view = $kb("view-knowledge");
    if (!view || view.hidden) return;
    // 注意：页面里存在「隐藏的」全局 modal 容器（rule-detail/user-edit 等），
    // 不能用 !!document.querySelector(".modal-mask") 判断是否有弹窗打开。
    const modalOpen = (typeof window.uxHasOpenModal === "function")
      ? window.uxHasOpenModal()
      : [...document.querySelectorAll(".modal-mask")].some((m) => !m.hidden && window.getComputedStyle(m).display !== "none");
    if (e.key === "/" && !typing && !modalOpen) {
      e.preventDefault();
      const q = $kb("kb-q");
      if (q) { q.focus(); if (q.select) q.select(); }
      return;
    }
    if ((e.key === "r" || e.key === "R") && !typing && !modalOpen && !e.metaKey && !e.ctrlKey && !e.altKey) {
      e.preventDefault();
      refresh();
      return;
    }
    if (e.key === "Escape" && !modalOpen) {
      if (e.target && e.target.id === "kb-q" && $kb("kb-q") && $kb("kb-q").value) {
        e.preventDefault();
        const q = $kb("kb-q");
        q.value = ""; setSearch("");
        return;
      }
      if (STATE.selected.size) { e.preventDefault(); clearSelection(); return; }
      if (STATE.q) { e.preventDefault(); setSearch(""); const q = $kb("kb-q"); if (q) q.value = ""; }
    }
  }
  function bindDropzone() {
    const dz = $kb("kb-dropzone");
    const overlay = $kb("kb-drop-overlay");
    if (!dz) return;
    let depth = 0;
    const show = (on) => {
      dz.classList.toggle("kb-dragover", on);
      if (overlay) overlay.hidden = !on;
      if (on) syncDropTarget();
    };
    ["dragenter", "dragover"].forEach((t) => dz.addEventListener(t, (e) => {
      if (!e.dataTransfer) return;
      const types = e.dataTransfer.types || [];
      const hasFiles = Array.prototype.some.call(types, (x) => x === "Files");
      if (!hasFiles) return;
      e.preventDefault();
      if (t === "dragenter") depth += 1;
      show(true);
    }));
    dz.addEventListener("dragleave", (e) => {
      depth = Math.max(0, depth - 1);
      if (depth === 0) show(false);
    });
    dz.addEventListener("drop", (e) => {
      if (!e.dataTransfer) return;
      e.preventDefault();
      depth = 0;
      show(false);
      const files = e.dataTransfer.files;
      if (files && files.length) uploadFiles(files);
    });
  }
  let fileInputReady = false;
  function onFileInputChange(e) {
    // 注意：清空 input.value 会让 e.target.files 变成空列表，必须先转成普通数组再清空，
    // 否则「选择文件」路径会静默不触发上传（File 对象本身清空后仍可用）。
    const files = Array.from((e.target && e.target.files) || []);
    if (e.target) e.target.value = "";
    if (files.length) uploadFiles(files);
  }
  /* 隐藏文件选择框统一由脚本创建并持有。
   * 原因：reviewer/admin 两个同构页面复用同一个解析期 <input type=file> 时，浏览器内部
   * 状态可能不一致（真实用户点选文件不受影响，但自动化/部分封闭环境下程序化选择文件
   * 会被静默忽略，表现为「选了文件但不上传」）。脚本创建的同 id/同属性节点行为稳定，
   * 且与拖拽上传共用同一个 uploadFiles() 入口。 */
  function ensureFileInput() {
    if (fileInputReady) return $kb("kb-file-input");
    const el = $kb("kb-file-input");
    if (!el || !el.parentNode) return null;
    if (el.getAttribute("data-kb-scripted") === "1") { fileInputReady = true; return el; }
    const fresh = document.createElement("input");
    fresh.type = "file";
    fresh.id = "kb-file-input";
    fresh.hidden = true;
    fresh.multiple = true;
    fresh.setAttribute("accept", ".pdf,.docx,.xlsx,.pptx,.txt,.md,.csv,.json,.png,.jpg,.jpeg,.gif,.webp,.bmp,.eml");
    fresh.setAttribute("data-kb-scripted", "1");
    fresh.addEventListener("change", onFileInputChange);
    el.parentNode.replaceChild(fresh, el);
    fileInputReady = true;
    return fresh;
  }
  function bind() {
    const panel = $kb("kb-panel");
    if (!panel) return;
    panel.addEventListener("click", onPanelClick);
    panel.addEventListener("change", onPanelChange);
    $kb("kb-refresh")?.addEventListener("click", () => refresh());
    $kb("kb-new-folder")?.addEventListener("click", openFolderModal);
    $kb("kb-upload")?.addEventListener("click", openUploadModal);
    ensureFileInput();
    // 窄屏目录抽屉遮罩（P1-5）：挂在 body，点击关闭；桌面尺寸下不可见。
    let scrim = $kb("kb-tree-scrim");
    if (!scrim) {
      scrim = document.createElement("div");
      scrim.id = "kb-tree-scrim";
      scrim.className = "kb-tree-scrim";
      scrim.hidden = true;
      document.body.appendChild(scrim);
      scrim.addEventListener("click", closeTreeDrawer);
    }
    const q = $kb("kb-q");
    let qTimer = null;
    q?.addEventListener("input", () => {
      if (qTimer) clearTimeout(qTimer);
      qTimer = setTimeout(() => setSearch(q.value), 120);
    });
    q?.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); setSearch(q.value); } });
    $kb("kb-q-clear")?.addEventListener("click", () => { if (q) q.value = ""; setSearch(""); q?.focus(); });
    const fq = $kb("kb-folder-q");
    fq?.addEventListener("input", () => { STATE.folderQ = fq.value || ""; renderFolders(); });
    $kb("kb-sort")?.addEventListener("change", (e) => {
      STATE.sort = e.target.value || "new";
      STATE.page = 0;
      STATE.lastSelectIndex = null;
      renderFiles();
    });
    $kb("kb-batch-del")?.addEventListener("click", deleteSelected);
    $kb("kb-batch-move")?.addEventListener("click", () => openMove([...STATE.selected]));
    $kb("kb-batch-clear")?.addEventListener("click", clearSelection);
    try {
      const saved = localStorage.getItem(VIEW_STORE_KEY);
      if (saved === "grid" || saved === "list") STATE.view = saved;
    } catch (e) { /* 隐私模式忽略 */ }
    syncViewToggle();
    bindDropzone();
    document.addEventListener("keydown", onDocKeydown);
    renderAll();
  }

  window.KB = {
    /* 每次进入菜单都重新读取当前工作空间（不缓存跨空间数据）。 */
    onShow: function () { ensureFileInput(); STATE.loaded = false; return loadKnowledge(true); },
    load: function () { STATE.loaded = false; return loadKnowledge(true); },
    pickFile: pickFile,
    fetchFileBlob: fetchFileBlob,
    uploadForRule: uploadForRule,
    state: STATE,
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})();
