/* 租户品牌同步：登录页 /login?tenant=CODE、/admin/business/login?tenant=CODE，
 * 以及登录后的 sidebar-brand、页面 title、logo。
 * 无配置时保持默认“AI 审核平台”，不覆盖任何现有 DOM。
 */
(function () {
  "use strict";
  var DEFAULT_NAME = "AI 审核平台";
  var LOGO_SELECTORS = [".sidebar-brand .logo", ".login-logo", ".mark"];
  var currentName = "";
  var observer = null;
  var applying = false;

  function text(v) { return String(v == null ? "" : v).trim(); }
  function displayName(v) { return text(v) || DEFAULT_NAME; }

  function tenantFromQuery() {
    try {
      return text(new URLSearchParams(window.location.search).get("tenant"));
    } catch (e) { return ""; }
  }

  function isLoginPage() {
    return !!document.querySelector(".login-card, .login-wrap, .portal");
  }

  function replaceInTextNodes(root, from, to, safeDefault) {
    if (!root || !from || from === to || !document.createTreeWalker) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        var p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/.test(p.tagName)) return NodeFilter.FILTER_REJECT;
        return (node.nodeValue || "").indexOf(from) >= 0
          ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    var nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(function (n) {
      n.nodeValue = safeDefault
        ? syncDefaultText(n.nodeValue || "")
        : (n.nodeValue || "").split(from).join(to);
    });
  }

  function applyName(name) {
    name = displayName(name);
    applying = true;
    try {
      var from = currentName || DEFAULT_NAME;
      if (from !== name) {
        replaceInTextNodes(document.body, from, name);
        if (document.title) document.title = document.title.split(from).join(name);
      }
      currentName = name;
      document.querySelectorAll(".sidebar-brand-name").forEach(function (el) {
        if (el.textContent !== name) el.textContent = name;
      });
      document.querySelectorAll(".login-brand b").forEach(function (el) {
        var t = el.textContent || "";
        if (t.indexOf(name) < 0 && t.indexOf(DEFAULT_NAME) >= 0) {
          el.textContent = t.split(DEFAULT_NAME).join(name);
        }
      });
    } finally {
      applying = false;
    }
  }

  function restoreLogo(el) {
    if (el.dataset.rpLogoApplied !== "1") return;
    var wasServerLogo = el.dataset.rpServerLogo === "1";
    el.innerHTML = el.dataset.rpDefaultHtml || "AI";
    el.removeAttribute("style");
    if (!wasServerLogo && el.dataset.rpDefaultStyle) {
      el.setAttribute("style", el.dataset.rpDefaultStyle);
    }
    delete el.dataset.rpLogoApplied;
    delete el.dataset.rpLogoUrl;
  }

  function applyLogo(url, name) {
    url = text(url);
    LOGO_SELECTORS.forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) {
        if (!el.dataset.rpDefaultHtml) {
          el.dataset.rpDefaultHtml = el.dataset.rpServerLogo === "1" ? "AI" : el.innerHTML;
        }
        if (!el.dataset.rpDefaultStyle && el.getAttribute("style")) {
          el.dataset.rpDefaultStyle = el.getAttribute("style");
        }
        if (!url) { restoreLogo(el); return; }
        if (el.dataset.rpLogoApplied === "1" && el.dataset.rpLogoUrl === url) return;
        var size = el.classList.contains("login-logo") ? 34 : el.classList.contains("mark") ? 26 : 30;
        el.innerHTML = "";
        var img = document.createElement("img");
        img.className = "rp-brand-logo";
        img.alt = name || DEFAULT_NAME;
        img.src = url;
        img.style.cssText = "width:" + size + "px;height:" + size + "px;object-fit:contain;" +
          "border-radius:6px;display:block;background:transparent";
        el.style.display = "grid";
        el.style.placeItems = "center";
        el.style.width = size + "px";
        el.style.height = size + "px";
        el.style.border = "0";
        el.style.background = "transparent";
        el.style.boxShadow = "none";
        el.dataset.rpLogoApplied = "1";
        el.dataset.rpLogoUrl = url;
        el.appendChild(img);
      });
    });
  }

  function syncDefaultText(value) {
    // 平台名自身可能包含默认名（如“AI 审核平台华东版”）：已含完整品牌名的文本不再二次替换。
    if (!value || value.indexOf(DEFAULT_NAME) < 0) return value;
    if (currentName !== DEFAULT_NAME && currentName.indexOf(DEFAULT_NAME) >= 0
        && value.indexOf(currentName) >= 0) return value;
    return value.split(DEFAULT_NAME).join(currentName);
  }

  function ensureObserver() {
    if (observer || !window.MutationObserver || !document.body) return;
    observer = new MutationObserver(function (mutations) {
      if (applying || !currentName || currentName === DEFAULT_NAME) return;
      mutations.forEach(function (m) {
        if (m.type === "characterData") {
          var _cur = m.target.nodeValue || "";
          var _next = syncDefaultText(_cur);
          // 关键：相同值不能写回；写回会再次触发 characterData，形成死循环。
          if (_next !== _cur) m.target.nodeValue = _next;
          return;
        }
        m.addedNodes.forEach(function (n) {
          if (n.nodeType === 3) {
            n.nodeValue = syncDefaultText(n.nodeValue || "");
          } else if (n.nodeType === 1) {
            replaceInTextNodes(n, DEFAULT_NAME, currentName, true);
          }
        });
      });
    });
    observer.observe(document.body, {childList: true, subtree: true, characterData: true});
  }

  function apply(branding) {
    if (!branding || typeof branding !== "object") return;
    var name = displayName(branding.platform_name);
    applyName(name);
    applyLogo(branding.logo_url, name);
    ensureObserver();
    window.__RP_BRANDING__ = branding;
  }

  function propagateTenant(code) {
    if (!code || !isLoginPage()) return;
    document.querySelectorAll("a[href]").forEach(function (a) {
      var href = a.getAttribute("href") || "";
      if (href.charAt(0) !== "/" || href.indexOf("tenant=") >= 0) return;
      if (!/(login|\/admin|\/reviewer|\/platform)/.test(href)) return;
      a.setAttribute("href", href + (href.indexOf("?") >= 0 ? "&" : "?") +
        "tenant=" + encodeURIComponent(code));
    });
  }

  async function load(force) {
    var code = tenantFromQuery();
    propagateTenant(code);
    var boot = window.__RP_TENANT_BRANDING__;
    if (boot && boot.branding && !force) {
      apply(boot.branding);
      return;
    }
    // 登录页用公开接口（支持 ?tenant=CODE）；登录后始终按会话账号本租户读取，避免 URL 参数串租户。
    var url = isLoginPage()
      ? "/api/v1/public/tenant-branding" + (code ? "?tenant=" + encodeURIComponent(code) : "")
      : "/api/v1/tenant/branding";
    try {
      var r = await fetch(url, {credentials: "same-origin", headers: {"Accept": "application/json"}});
      if (!r.ok) return;
      var d = await r.json();
      if (d && d.branding) apply(d.branding);
    } catch (e) { /* 网络失败保持默认品牌，不影响登录/业务 */ }
  }

  window.RPBranding = {apply: apply, refresh: function () { return load(true); }};
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { load(false); }, {once: true});
  } else {
    load(false);
  }
})();
