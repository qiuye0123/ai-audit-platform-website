/* 项目列表视图：从 app.js 拆出；依赖 app.js 的 $/esc/showView/currentRole。 */
async function loadProjects(page) {
  plPage = page || plPage || 1;
  uxSetLoading("#project-list", "正在加载项目…", 4);
  await initProjectFilters();
  // 筛选回显：等空间下拉加载完成后再恢复，避免动态选项把已保存值清空。
  uxFiltersRestoreOnce("projects");
  const q = new URLSearchParams({
    q: $("#pl-q")?.value || "", status: $("#pl-status")?.value || "",
    workspace: "all",
    space: $("#pl-space")?.value || "",
    from: $("#pl-from")?.value || "", to: $("#pl-to")?.value || "",
    page: String(plPage), page_size: "20",
  });
  let d;
  try {
    d = await (await fetch(`/api/v1/projects?${q}`)).json();
  } catch (e) {
    uxSetEmpty("#project-list", { title: "项目加载失败", desc: "请检查网络后重试；已保存的项目数据不受影响。", action: { label: "重新加载", action: "reset:projects" } });
    $("#project-pager").innerHTML = "";
    return;
  }
  if (d && d.error) {
    uxSetEmpty("#project-list", { title: "项目加载失败", desc: String(d.error), action: { label: "重新加载", action: "reset:projects" } });
    $("#project-pager").innerHTML = "";
    return;
  }
  const items = (d && d.items) || [];
  const isReviewerList = currentRole === "reviewer";
  const _plq = document.querySelector('.pt-field #pl-q');
  if (_plq) {
    _plq.placeholder = isReviewerList ? "搜索项目" : "搜索项目或创建人";
    const _lbl = _plq.closest('.pt-field')?.querySelector('span');
    if (_lbl) _lbl.textContent = isReviewerList ? "项目" : "项目 / 创建人";
  }
  if (!items.length) {
    $("#project-list").innerHTML = uxEmptyHTML({
      title: "没有符合条件的项目",
      desc: "调整筛选条件后重试；新建项目会从上传文件开始审核。",
      action: isReviewerList ? { label: "新建项目", action: "view:newproject" } : { label: "清空筛选", action: "reset:projects" },
    });
    $("#project-pager").innerHTML = "";
    return;
  }
  const reviewerHead = isReviewerList ? "" : `<th>审核员</th>`;
  const reviewerCell = (p) => isReviewerList ? "" : `<td><b>${esc(p.created_by_name || p.created_by || "—")}</b></td>`;
  $("#project-list").innerHTML = `<div class="list-scope-note">数据范围：全部空间汇总；空间筛选只影响当前项目列表。</div><table class="table"><thead><tr>
      <th style="width:56px">序号</th><th>项目</th><th>空间</th><th>状态</th><th>文件</th>
      <th>发现</th><th>待复核</th><th>已复核</th>${reviewerHead}<th>最后审核</th><th class="actions-cell" style="width:100px">操作</th>
    </tr></thead><tbody>` +
    items.map(p => `<tr data-id="${esc(p.id)}">
      <td class="muted">${p.seq}</td>
      <td><b>${esc(p.name)}</b></td>
      <td class="muted">${esc(p.workspace_name || "—")}</td>
      <td><span class="pill ${p.status === 'completed' ? 'published' : p.status === 'auditing' ? 'draft' : p.status === 'audit_failed' ? 'r' : ''}">${esc(PROJ_STATUS[p.status] || p.status || '—')}</span></td>
      <td>${p.document_count}</td><td>${p.finding_count}</td>
      <td>${p.pending_count ? `<span class="pill draft">${p.pending_count}</span>` : 0}</td>
      <td>${p.decided_count || 0}</td>
      ${reviewerCell(p)}
      <td class="muted">${esc(p.last_audit_at || p.created_at || '')}</td>
      <td class="actions-cell"><a href="#" class="link" data-detail="${esc(p.id)}">查看详情</a></td>
    </tr>`).join("") + `</tbody></table>`;
  $("#project-list").querySelectorAll("[data-detail]").forEach(a => a.addEventListener("click", (e) => {
    e.preventDefault(); e.stopPropagation(); openProject(a.dataset.detail);
  }));
  $("#project-list").querySelectorAll("tr[data-id]").forEach(tr => tr.addEventListener("click", () => openProject(tr.dataset.id)));
  renderPager(d);
}
function renderPager(d) {
  const { page = 1, pages = 1, total = 0 } = d || {};
  if (!total) { $("#project-pager").innerHTML = ""; return; }
  const btn = (n, label, on, dis) => `<button ${on ? 'class="on"' : ''} ${dis ? "disabled" : ""} data-pg="${n}">${label}</button>`;
  const parts = [`<span class="pager-total">共 ${total} 条 · 第 ${page}/${pages} 页</span>`];
  const nums = [];
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) nums.push(i);
  const pagesHtml = [btn(page - 1, "上一页", false, page <= 1), ...nums.map(n => btn(n, String(n), n === page, false)), btn(page + 1, "下一页", false, page >= pages)].join("");
  $("#project-pager").innerHTML = `<div class="pager">${parts[0]}<div class="pager-actions">${pagesHtml}</div></div>`;
  $("#project-pager").querySelectorAll("[data-pg]").forEach(b => b.addEventListener("click", () => {
    const n = Number(b.dataset.pg);
    if (n >= 1 && n <= pages) loadProjects(n);
  }));
}
let reviewerFilled = false;
