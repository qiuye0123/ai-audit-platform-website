/* 审核工作台入口/发现/复核：从 app.js 拆出；依赖 app.js 全局状态与 esc/showView。 */

/* ---------------------------------------------------------------------------
 * E-10（DuMate 第三轮，S2）语义路径可解释性：工作台「本次执行摘要」
 *
 * 背景：模型地址被 net_guard 拒绝（如环回/私网）或模型不可用时，project.audit 仍会
 * 正常 completed 并照常落 finding，但语义节点 0 次真实调用、llm_trace 0 条；前端此前
 * 完全不展示 orchestration，用户看到「已完成 / 0 个问题」会误以为「文件干净」。
 *
 * 这里只做展示：数据全部来自 case 详情接口（GET /api/v1/projects/{id}）已有的
 * orchestration[] / llm_traces[] 字段，不新增后端计算。
 * 四态：executed（中性灰）/ failed（红）/ degraded（黄）/ not_called（黄）。
 * 不改判定逻辑、不改 net_guard、不改任何审核结果字段语义。
 * ------------------------------------------------------------------------- */
const WB_EXEC_STAGE_LABELS = {
  ocr: "OCR", parse: "文档解析", extract: "事实抽取", rulegen: "规则生成",
  conflict: "规则冲突检查", judge: "点位语义判定", feedback: "反馈归因",
  ruleminer: "规则挖掘（委派）", rulemining: "规则挖掘", dag: "审核 DAG",
  jev: "JEV 校准", full_doc_recall: "全文候选召回", rsi: "RSI 沉淀",
};
const WB_EXEC_STATUS_LABELS = {
  executed: "已执行", skipped: "已跳过", failed: "执行失败",
  degraded: "已降级", delegated: "已委派",
};
const WB_EXEC_NOT_CALLED_TEXT = "本次未调用语义模型；当前结论仅来自确定性规则";

function _wbExecStageLabel(stage) {
  var k = String(stage || "");
  var label = WB_EXEC_STAGE_LABELS[k];
  return label ? (label + "（" + k + "）") : (k || "未知节点");
}
function _wbExecStatusLabel(status) {
  var k = String(status || "");
  return WB_EXEC_STATUS_LABELS[k] || (k || "未知");
}
function _wbExecReason(st) {
  /* 原因优先级：顶层 reason → detail.error → detail.reason；都没有时留空由渲染层给兜底文案 */
  var s = (st && typeof st === "object") ? st : {};
  var d = (s.detail && typeof s.detail === "object") ? s.detail : {};
  var cand = [s.reason, d.error, d.reason];
  for (var i = 0; i < cand.length; i++) {
    var t = String(cand[i] == null ? "" : cand[i]).trim();
    if (t) return t;
  }
  return "";
}
function _wbExecAgent(st) {
  var d = (st && st.detail && typeof st.detail === "object") ? st.detail : {};
  return String(d.agent || "").trim();
}

/**
 * 纯函数：把 case 详情响应归一成「本次执行摘要」模型（不碰 DOM，便于单测/四态核对）。
 * @returns {{state:string, level:string, headline:string, sublines:string[],
 *            notCalled:boolean, notCalledSentence:string, tracesKnown:boolean,
 *            llmCalls:number, counts:object, items:Array}}
 */
function wbExecSummaryModel(rep) {
  var r = (rep && typeof rep === "object") ? rep : {};
  var rawStages = Array.isArray(r.orchestration) ? r.orchestration : [];
  var stages = rawStages.filter(function (s) { return s && typeof s === "object"; });
  var tracesKnown = Array.isArray(r.llm_traces);
  var llmCalls = tracesKnown ? r.llm_traces.length : 0;
  var runs = (r.runs && typeof r.runs === "object") ? r.runs : {};
  var caseObj = (r.case && typeof r.case === "object") ? r.case : {};
  var runCount = Number(runs.count || 0) || 0;
  var hasRun = runCount > 0 || !!caseObj.last_run_id;

  var items = stages.map(function (st) {
    var status = String(st.status || "");
    var detail = (st.detail && typeof st.detail === "object") ? st.detail : {};
    var isDegraded = status === "degraded" || detail.degraded === true;
    return {
      stage: String(st.stage || ""),
      status: status,
      degraded: isDegraded,
      reason: _wbExecReason(st),
      agent: _wbExecAgent(st),
    };
  });
  var executedNodes = items.filter(function (x) { return x.status === "executed"; }).length;
  var failedItems = items.filter(function (x) { return x.status === "failed"; });
  var degradedItems = items.filter(function (x) {
    return x.status !== "failed" && x.degraded;
  });
  var skippedItems = items.filter(function (x) { return x.status === "skipped"; });
  var delegatedCount = items.filter(function (x) { return x.status === "delegated"; }).length;

  /* 0 次模型调用判定：优先用后端已下发的 llm_traces（真实调用记录）；
     老版本接口没有该字段时退化为「所有阶段都没有 executed」，不凭空断言。 */
  var notCalled;
  if (tracesKnown) {
    notCalled = llmCalls === 0;
  } else {
    notCalled = items.length > 0 && executedNodes === 0;
  }
  /* 有 run 但编排轨迹为空且没有调用记录，也算「未调用语义模型」而不是「无记录」 */
  var hasRunButNoTrace = hasRun && !items.length && (tracesKnown ? llmCalls === 0 : true);

  var state, level;
  if (!hasRun && !items.length && !llmCalls) {
    state = "not_run"; level = "neutral";
  } else if (failedItems.length) {
    state = "failed"; level = "error";
  } else if (degradedItems.length) {
    state = "degraded"; level = "warn";
  } else if (notCalled || hasRunButNoTrace) {
    state = "not_called"; level = "warn";
  } else {
    state = "executed"; level = "neutral";
  }

  var headline;
  if (state === "failed") {
    headline = failedItems.length + " 个节点执行失败";
  } else if (state === "degraded") {
    headline = degradedItems.length + " 个节点降级";
  } else if (state === "not_called") {
    headline = WB_EXEC_NOT_CALLED_TEXT;
  } else if (state === "executed") {
    headline = executedNodes
      ? ("语义路径已执行（" + executedNodes + " 个节点）")
      : ("语义路径已执行（模型调用 " + llmCalls + " 次）");
  } else {
    headline = "本次执行摘要：尚无审核执行记录";
  }

  var sublines = [];
  if (state === "failed" && degradedItems.length) {
    sublines.push("另有 " + degradedItems.length + " 个节点降级");
  }
  if (state === "executed") {
    if (tracesKnown && llmCalls) sublines.push("语义模型调用 " + llmCalls + " 次");
    if (skippedItems.length) sublines.push(skippedItems.length + " 个节点按场景跳过");
  }
  if (state === "not_called") {
    sublines.push("语义模型调用 0 次");
  }
  if (state === "not_run") {
    sublines.push("运行审核后会在这里显示语义路径/降级/失败情况");
  }

  var counts = {
    stages: items.length,
    executed: executedNodes,
    failed: failedItems.length,
    degraded: degradedItems.length,
    skipped: skippedItems.length,
    delegated: delegatedCount,
    llmCalls: tracesKnown ? llmCalls : null,
  };
  return {
    state: state, level: level, headline: headline, sublines: sublines,
    notCalled: notCalled || hasRunButNoTrace,
    notCalledSentence: WB_EXEC_NOT_CALLED_TEXT,
    tracesKnown: tracesKnown, llmCalls: llmCalls,
    counts: counts, items: items,
  };
}

function wbExecSummaryClear() {
  var old = document.getElementById("wb-exec-summary");
  if (old && old.parentNode) old.parentNode.removeChild(old);
}

function _wbExecItemHTML(it) {
  var label = _wbExecStageLabel(it.stage);
  var stLabel = it.status === "degraded" || it.degraded
    ? "已降级" : _wbExecStatusLabel(it.status);
  var reason = it.reason;
  if (!reason) {
    if (it.status === "failed" || it.degraded) {
      reason = it.agent ? ("未返回原因（" + it.agent + "）") : "未返回原因";
    } else if (it.status === "skipped") {
      reason = "未记录跳过原因";
    }
  }
  var cls = it.status === "failed" ? "is-bad" : (it.degraded || it.status === "degraded" ? "is-warn" : "");
  return '<li class="wb-exec-stage ' + cls + '"><b>' + esc(label) + "</b>"
    + '<span class="wb-exec-st">' + esc(stLabel) + "</span>"
    + (reason ? '<span class="wb-exec-reason">' + esc(reason) + "</span>" : "")
    + "</li>";
}

/**
 * 渲染/更新工作台顶部「本次执行摘要」条（幂等：重复进入工作台只更新不重复插入）。
 * 放在项目标题（.wb-project-head）下方、三栏主区上方；无数据时不渲染空壳。
 */
function wbExecSummaryRender(rep) {
  var host = document.querySelector("#workbench");
  var view = document.querySelector("#view-workbench");
  if (!host && !view) return;
  var model = wbExecSummaryModel(rep);
  var box = document.getElementById("wb-exec-summary");
  if (!box) {
    box = document.createElement("div");
    box.id = "wb-exec-summary";
    var head = document.querySelector("#workbench .wb-project-head");
    if (head && head.parentNode) head.parentNode.insertBefore(box, head.nextSibling);
    else (host || view).insertBefore(box, (host || view).firstChild);
  }
  var levelCls = model.level === "error" ? "is-error"
    : (model.level === "warn" ? "is-warn" : "is-info");
  box.className = "wb-exec-summary " + levelCls;
  box.setAttribute("data-e10-state", model.state);
  box.setAttribute("data-e10-level", model.level);
  box.setAttribute("data-e10-llm-calls", model.tracesKnown ? String(model.llmCalls) : "");
  box.setAttribute("data-e10-failed", String(model.counts.failed));
  box.setAttribute("data-e10-degraded", String(model.counts.degraded));
  box.setAttribute("data-e10-executed", String(model.counts.executed));
  box.setAttribute("data-e10-stages", model.items.map(function (x) { return x.stage; }).join(","));

  var badge = model.tracesKnown
    ? '<span class="wb-exec-badge">语义模型调用 ' + model.llmCalls + " 次</span>"
    : '<span class="wb-exec-badge">调用次数不可读</span>';
  var alertSub = (model.notCalled && model.state !== "not_called")
    ? '<div class="wb-exec-sub"><span class="wb-exec-alert">'
      + esc(model.notCalledSentence) + "</span></div>"
    : "";
  var subs = model.sublines.map(function (t) {
    return '<div class="wb-exec-sub">' + esc(t) + "</div>";
  }).join("");
  var details = model.items.length
    ? '<details class="wb-exec-details"><summary>查看节点明细（'
      + model.items.length + "）</summary><ul>"
      + model.items.map(_wbExecItemHTML).join("") + "</ul></details>"
    : "";
  box.innerHTML = '<div class="wb-exec-head"><span class="wb-exec-dot"></span>'
    + '<b class="wb-exec-title">' + esc(model.headline) + "</b>" + badge + "</div>"
    + alertSub + subs + details;
}

async function openWorkbench(pid) {
  const readOnlyWorkbench = currentRole === "admin";
  // 发现筛选项沿用统一 localStorage；只做回显，不改发现计算与复核状态。
  if (typeof uxWorkbenchFiltersRestore === "function") uxWorkbenchFiltersRestore();
  currentWb = pid; wbTab = "issues"; if (!wbReviewed || readOnlyWorkbench) wbReviewed = readOnlyWorkbench ? "all" : "pending";
  _wbHiddenReset(pid);   // T-51：每次进入复核默认关闭隐藏区（不记忆上次开启）
  if (typeof _wbShadowReset === "function") _wbShadowReset(pid);   // T-203 影子池同步重置
  const _seq = ++wbRenderSeq;
  showView("workbench");
  uxSetLoading("#wb-findings", "正在加载发现…", 4);
  // T-106：三栏结构 + 问题队列固定入口（加载/错误态下按钮也不消失）
  _WB106.pid = String(pid || "");
  _WB106.hidden = null;
  _WB106.hiddenLoading = true;
  _WB106.ctx = { loading: true, docsReady: false, error: "" };
  _WB106.batchSel = {};
  var _oldBatchResult = document.getElementById("wb106-batch-result");
  if (_oldBatchResult) { _oldBatchResult.hidden = true; _oldBatchResult.innerHTML = ""; }
  var _oldBatchFb = document.getElementById("wb106-batch-fb");
  if (_oldBatchFb) _oldBatchFb.remove();
  wbExecSummaryClear();   // E-10：切换项目/重进工作台先清掉上次的执行摘要，避免张冠李戴
  if (typeof wb106Layout === "function") wb106Layout();
  if (typeof wb106QueueHeaderInit === "function") wb106QueueHeaderInit(pid);
  if (typeof wb106EnsureDelegation === "function") wb106EnsureDelegation();
  if (typeof wb106RefreshHidden === "function") wb106RefreshHidden(pid);
  // T-203：影子池 N 与隐藏项 N 分别读（两个独立区；都默认只给 N 不给明细）
  if (typeof wb106RefreshShadow === "function") wb106RefreshShadow(pid);
  let rep, docs;
  try {
    [rep, docs] = await Promise.all([
      (await fetch(`/api/v1/projects/${pid}`)).json(),
      (await fetch(`/api/v1/projects/${pid}/documents`)).json(),
    ]);
  } catch (e) {
    _WB106.ctx = { loading: false, docsReady: false, error: "网络错误：" + ((e && e.message) || e) };
    if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
    uxSetEmpty("#wb-findings", { title: "发现加载失败", desc: "请返回审核列表后重试；不会修改任何复核结果。", action: { label: "返回审核列表", action: "view:myaudits" } });
    return;
  }
  if (!rep || rep.error) {
    _WB106.ctx = { loading: false, docsReady: false, error: String((rep && rep.error) || "接口返回为空") };
    if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
    uxSetEmpty("#wb-findings", { title: "发现加载失败", desc: String((rep && rep.error) || "接口返回为空"), action: { label: "返回审核列表", action: "view:myaudits" } });
    return;
  }
  if (_seq !== wbRenderSeq || currentWb !== pid) return;
  // 跨空间打开：先把「当前工作空间」对齐到项目所属空间（失败/无字段则保持现状）。
  if (typeof wsSyncForProject === "function") { try { await wsSyncForProject(rep.case || {}); } catch (e) {} }
  _WB106.ctx = { loading: false, docsReady: true, error: "" };
  // E-10：本次执行摘要（语义路径已执行/降级/失败/未调用），数据来自 case 详情已有字段
  try { wbExecSummaryRender(rep); }
  catch (e) { console.warn("执行摘要渲染失败（不影响审核结果展示）", e); }
  wbDocs = Array.isArray(docs) ? docs : [];
  wbFindings = (rep && rep.findings) || [];
  const caseObj = (rep && rep.case) || {}, s = (rep && rep.summary) || {};
  $("#wb-title").textContent = caseObj.name || "审核工作台";
  loadWbUnknown(pid);
  if (typeof loadWbHumanLoop === "function") { try { loadWbHumanLoop(pid); } catch (e) {} }
  // T-50（W-14）：双轨数据只读面板（直连草稿/四桶差异/可见性策略，与 CLI 同源）
  if (typeof loadWbDualTrack === "function") { try { loadWbDualTrack(pid); } catch (e) {} }
  /* T-106：顶部动作区精简为“补跑 AI 辅助 / 重新审核”（人工新增问题入口固定在问题队列标题旁）。
     只读角色不渲染可执行按钮，但用一行说明替代“按钮消失”，避免用户不知道这里为何为空。 */
  (function () {
    ["wb-ai-assist", "wb-reaudit", "wb-manual-finding", "wb-retry-failed", "wb-accept-unknown"].forEach(function (id) {
      var old = document.getElementById(id); if (old) old.remove();
    });
    var host = document.getElementById("wb-actions"); if (!host) return;
    host.innerHTML = "";
    host.style.display = "";
    if (readOnlyWorkbench) {
      var ro = document.createElement("span");
      ro.className = "wb106-ro-hint";
      ro.textContent = "只读：可查看问题/证据/报告状态，不可裁决或新增";
      host.appendChild(ro);
      return;
    }
    var b = document.createElement("button");
    b.id = "wb-ai-assist"; b.className = "btn"; b.textContent = "补跑 AI 辅助";
    b.title = "只补查客户规则未覆盖的审核点；结果标 AI 辅助，需人工确认";
    b.onclick = async function () {
      if (!confirm("补跑 AI 辅助会增加时间与调用成本，并可能带来更多误报。继续？")) return;
      b.disabled = true; b.textContent = "补跑中…";
      var r = await (await fetch(`/api/v1/projects/${pid}/ai-assist`, { method: "POST",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) })).json();
      b.disabled = false; b.textContent = "补跑 AI 辅助";
      if (r.error) { alert("补跑失败：" + r.error); return; }
      alert(`补跑完成：共 ${r.total} 条，其中 AI 辅助 ${r.ai_findings} 条`);
      await openWorkbench(pid);
    };
    host.appendChild(b);
    var rb = document.createElement("button");
    rb.id = "wb-reaudit"; rb.className = "btn"; rb.textContent = "重新审核";
    rb.title = "按当前规则重新执行整份项目；用于补充材料或规则更新后重新判定";
    rb.onclick = async function () {
      if (!(await confirmAction("重新审核", "将按当前规则重新执行整份项目，可能覆盖上一次未完成的审核结果；确认继续？", "确认重新审核"))) return;
      rb.disabled = true; rb.textContent = "启动中…";
      await runAuditAsync(pid, false, "", "", caseObj.name || "当前项目");
      rb.disabled = false; rb.textContent = "重新审核";
    };
    host.appendChild(rb);
  })();
  /* L84 E3：双轨 V3.2 数据入口（抑制台账 / 隐藏项指标）。与 #wb-actions 分开挂载，
     业务管理员/审核员都能看到（权限口径由服务层判定，见 _wbV32Api 调用注释）。 */
  try { wbV32Mount(pid); } catch (e) { console.warn("双轨数据入口挂载失败", e); }
  const TYPE_LABEL = { food: "食品工艺书", contract: "合同", application: "申报材料", general: "通用文件" };
  const CAT_LABEL = { A: "主体资格", B: "结构完备", C: "事实数据", D: "逻辑结论", E: "权利义务", F: "商务执行", G: "披露申报" };
  const subs = [];
  if (caseObj.document_type) subs.push(`类型：${caseObj.document_type}`);
  else if (caseObj.audit_type) subs.push(`类型：${TYPE_LABEL[caseObj.audit_type] || caseObj.audit_type}`);
  if (caseObj.created_at) subs.push(`上传：${String(caseObj.created_at).slice(0, 16)}`);
  subs.push(`${wbDocs.length} 个文件`);
  $("#wb-meta").textContent = subs.join(" · ") || "—";
  $("#wb-stats").innerHTML = [
    ["c-critical", s.critical_count || 0, "严重"],
    ["c-warning", s.warning_count || 0, "一般"],
    ["c-suspected", s.suspected_count || 0, "提示"],
    ["c-abstain", s.abstain_count || 0, "弃权"],
    ["c-unknown", s.unknown_count || 0, "未执行"],
  ].map(([cls, n, label]) => `<span class="wb-stat ${cls}"><b>${n}</b>${label}</span>`).join("");
  const pending = wbFindings.filter(f => f.status === "pending").length;
  $("#wb-progress").textContent = `已复核 ${wbFindings.length - pending}/${wbFindings.length}`;
  const cc = s.critical_count || 0, wc = s.warning_count || 0, sc = s.suspected_count || 0;
  const tot = Math.max(cc + wc + sc, 1);
  $("#wb-counts").innerHTML = (cc + wc + sc) ? `
    <div class="wbr-bar">
      ${cc ? `<span style="width:${cc / tot * 100}%;background:#F54A45"></span>` : ""}
      ${wc ? `<span style="width:${wc / tot * 100}%;background:#FF8800"></span>` : ""}
      ${sc ? `<span style="width:${sc / tot * 100}%;background:#7B61FF"></span>` : ""}
    </div>
    <div class="wbr-legend">
      <span><i style="background:#F54A45"></i>严重 ${cc}</span>
      <span><i style="background:#FF8800"></i>一般 ${wc}</span>
      <span><i style="background:#7B61FF"></i>提示 ${sc}</span>
    </div>` : `<div class="wbr-empty">未发现问题</div>`;
  const evN = wbFindings.filter(f => f.status === "need_evidence").length;
  const evBar = $("#wb-evidence-bar");
  if (evBar) {
    evBar.style.display = evN ? "" : "none";
    evBar.textContent = evN ? `有 ${evN} 项待补证：补充材料后请在「审核列表」点「重新审核」再复核` : "";
  }
  // 报告按钮：业务管理员只读查看，不提供下载/生成
  if (!readOnlyWorkbench) {
    $("#wb-download-report").href = `/api/v1/reviews/${pid}/report.docx`;
    $("#wb-preview-report").onclick = () => openReportDrawer(pid);
  } else {
    const _dr = $("#wb-download-report"); if (_dr) _dr.innerHTML = "";
  }
  // 文件 tabs + 预览
  const _fileTabs = document.querySelector("#wb-file-tabs");
  if (_fileTabs) _fileTabs.style.display = wbDocs.length > 1 ? "" : "none";
  $("#wb-file-tabs").innerHTML = wbDocs.map((d, i) =>
    `<span class="wb-file-tab ${i === 0 ? "active" : ""}" data-doc="${esc(d.id)}" title="${esc(d.filename)}">文件${i + 1}预览</span>`).join("");
  $("#wb-file-tabs").querySelectorAll("[data-doc]").forEach(t => t.addEventListener("click", () => {
    $("#wb-file-tabs").querySelectorAll(".wb-file-tab").forEach(x => x.classList.remove("active"));
    t.classList.add("active"); loadWbPreview(t.dataset.doc);
  }));
  wbPreviewMode = "text"; wbCurrentDoc = wbDocs[0]?.id || "";
  await loadWbPreview(wbCurrentDoc, "text");
  renderWbTab();
  renderWbFindings();
  await renderWbReportStatus(pid);
  // T-106：项目加载完成后刷新队列入口状态（新增问题/其他疑似问题），并整理动态面板顺序。
  _WB106.ctx = { loading: false, docsReady: true, error: "" };
  if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
  if (typeof wb106MarkPanels === "function") wb106MarkPanels();
}
function renderWbTab() {
  document.querySelectorAll(".wbr-tab").forEach(t => t.classList.toggle("active", t.dataset.tab === wbTab));
  document.querySelectorAll("[data-wb-filter]").forEach(b => b.classList.toggle("on", b.dataset.wbFilter === wbReviewed));
}
function filteredFindings() {
  return (wbFindings || []).filter(f => {
    if (wbSev && f.severity !== wbSev) return false;
    if (wbReviewed === "done" && f.status === "pending") return false;
    if (wbReviewed === "pending" && f.status !== "pending") return false;
    return true;
  });
}
function wbFindingCard(f) {
  // T-106：问题卡统一由 wb106FindingCard 渲染（固定 5 个操作 + 只读禁用原因）。
  return wb106FindingCard(f);
}
function renderWbFindings() {
  const box = document.querySelector("#wb-findings");
  if (!box) return;
  if (typeof wb106EnsureDelegation === "function") wb106EnsureDelegation();
  const list = filteredFindings();
  const count = document.querySelector("#wb-side-count");
  if (count) count.textContent = `（${list.length} 项${wbReviewed === "pending" ? "待处理" : ""} / 共 ${(wbFindings || []).length} 项）`;
  if (wbTab === "points") { box.innerHTML = `<div class="empty">点位明细请从项目详情查看</div>`; if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState(); return; }
  if (wbTab === "rules") {
    const groups = {};
    list.forEach(f => { const k = f.rule_code || f.rule_id || "—"; (groups[k] = groups[k] || []).push(f); });
    box.innerHTML = Object.keys(groups).length ? Object.entries(groups).map(([code, fs]) => `<div class="fcard"><div class="fc-head"><span class="pill draft">规则</span><span class="fc-title">${esc(code)}</span><span class="muted">${fs.length} 项</span></div><div class="fc-desc"><span>问题</span>${fs.map(f => esc(f.title)).join("；")}</div></div>`).join("") : '<div class="empty">暂无</div>';
    if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
    return;
  }
  if (!list.length) {
    const hasAny = (wbFindings || []).length > 0;
    box.innerHTML = uxEmptyHTML({
      title: wbReviewed === "pending" ? "当前没有待处理问题" : "没有符合筛选条件的问题",
      desc: hasAny
        ? (wbReviewed === "pending" ? "可以点“全部”查看已复核问题，或用「更多 → 改判」修正已复核结论。" : "可以切换筛选或清空严重度筛选。")
        : "当前项目还没有发现；运行审核后问题会显示在这里。也可以点问题队列标题旁的「＋新增问题」人工记录。",
      action: hasAny
        ? (wbReviewed === "pending" ? { label: "查看全部问题", action: "wb:all" } : { label: "只看待处理", action: "wb:pending" })
        : null,
    });
    if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
    return;
  }
  // 动态插入的问题卡由 wb106FindingCard 统一渲染；点击走事件委托，
  // 不会出现“innerHTML 重渲染后按钮失效/卡片空白”的经典问题。
  box.innerHTML = list.map(wbFindingCard).join("");
  if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
  if (typeof wb106MarkPanels === "function") wb106MarkPanels();
}
function openWbDecision(fid, decision) {
  // T-106：统一走 wb106Decide（固定按钮 + 只读/已裁决禁用原因 + 撤销/确认）。
  if (typeof wb106Decide === "function") return wb106Decide(fid, decision);
  showToast("裁决弹窗不可用，请刷新页面重试", "err");
}


async function loadWbUnknown(pid) {
  let box = document.querySelector("#wb-unknown");
  if (!box) {
    const host = document.querySelector("#view-workbench");
    if (!host) return;
    box = document.createElement("div");
    box.id = "wb-unknown";
    box.className = "card";
    box.style.margin = "10px 0";
    host.insertBefore(box, host.firstChild);
  }
  box.innerHTML = '<div class="muted">unknown 分类加载中…</div>';
  let d = {}, cand = {};
  try {
    const [r1, r2] = await Promise.all([
      fetch(`/api/v1/projects/${encodeURIComponent(pid)}/unknown-classes`),
      fetch(`/api/v1/projects/${encodeURIComponent(pid)}/unknown-candidates`),
    ]);
    d = await r1.json();
    cand = await r2.json();
  } catch (e) { box.innerHTML = '<div class="muted">unknown 分类读取失败</div>'; return; }
  if (d.error) { box.innerHTML = `<div class="muted">${esc(d.error)}</div>`; return; }
  const c = d.counts || {};
  const total = (c.customer_unexecuted || 0) + (c.customer_insufficient || 0) +
                (c.customer_not_applicable || 0) + (c.platform_builtin || 0) + (c.not_applicable || 0);
  const _readOnly = currentRole === "admin";
  const _candErr = (cand && cand.error) ? String(cand.error) : "";
  const _cands = (!_candErr && cand && cand.candidates) ? cand.candidates : [];
  const _cc = (!_candErr && cand && cand.counts) ? cand.counts : {};
  if (!total && !_cands.length) { box.remove(); return; }
  const _gate = (!_candErr && cand && cand.report_gate) ? cand.report_gate : {};
  const _gateOk = _gate && _gate.ok === true;
  const _gateText = _gateOk
    ? "报告门禁：当前可生成正式报告（接受/复核状态已同步）"
    : ("报告门禁：仍阻断 — " + (((_gate && _gate.reasons) || []).slice(0, 3).join("；") || "未满足放行条件"));
  const _rows = d.rows || [];
  const _req = _rows.filter(x => x.class === "customer_insufficient" && x.result_id);
  const _btn = (_readOnly ? [] : _req).map(x => `<button class="btn" data-unknown-ev="${esc(x.result_id)}" data-unknown-pid="${esc(x.point_id)}">补证 ${esc(x.point_id)}</button>`).join(" ");

  // T-35 对象级例外授权：每个 unknown 对象一个“逐项接受”按钮；无候选时按钮禁用。
  // 批量入口已由 HTTP 400/CLI 400 固定拒绝，页面不提供“全部接受”。
  const _mine = (currentUser && (currentUser.sub || currentUser.id)) || "";
  const _stateText = { unknown: "未执行/无法判断", insufficient: "证据不足",
                       failed: "执行失败", blocked: "执行受阻", missing: "结果缺失" };
  function _acceptRow(x) {
    const _label = x.label || x.rule_code || x.point_id || x.result_id || "";
    const _kindText = x.kind === "platform_point" ? "平台点位" : (x.key_item ? "关键项" : "客户规则");
    const _actors = (x.actors || []).length;
    const _mineSigned = _mine && (x.actors || []).indexOf(_mine) >= 0;
    let _btnText = "逐项接受";
    if (x.accepted) _btnText = "已授权";
    else if (!x.waivable) _btnText = "不可豁免";
    else if (x.key_item && _actors >= 1) _btnText = "待第二人授权";
    let _disabled = !!x.accept_disabled_reason;
    if (!_disabled && x.key_item && _mineSigned) _disabled = true;
    const _title = x.accept_disabled_reason
      || (x.key_item ? `关键项需 ${x.required_actors} 名不同授权人（当前 ${_actors} 人）；同一人重复接受不生效`
                     : "按对象授权：一次只接受一个对象，禁止批量");
    const _sub = [_kindText, _stateText[x.state] || x.state || "",
                  x.key_item ? `需 ${x.required_actors} 人/当前 ${_actors} 人` : "",
                  x.non_waivable_reason || ""].filter(Boolean).join(" · ");
    return `<div class="kv" style="align-items:center;border-top:1px dashed #eee;padding-top:6px;margin-top:6px">
      <div><span class="k">${esc(_label)}</span>
      <span class="muted" style="font-size:11px"> ${esc(_sub)}</span></div>
      ${_readOnly ? '<span class="pill draft">只读</span>'
        : `<button class="btn${x.accepted || _disabled ? "" : " primary"}" data-unknown-accept="${esc(x.result_id)}"
             title="${esc(_title)}"${_disabled ? " disabled" : ""}>${esc(_btnText)}</button>`}
    </div>`;
  }
  const _listHtml = _cands.length
    ? _cands.map(_acceptRow).join("")
    : '<div class="muted" style="margin-top:6px">当前没有可接受的对象级 unknown 候选 <button class="btn" disabled>逐项接受（无候选）</button></div>';
  const _countsText = `候选 ${_cc.total || 0} · 待授权 ${_cc.pending || 0} · 已授权 ${_cc.accepted || 0}` +
    ((_cc.non_waivable || 0) ? ` · 不可豁免 ${_cc.non_waivable}` : "") +
    ((_cc.key_pending || 0) ? ` · 关键项待双人 ${_cc.key_pending}` : "");
  box.innerHTML = `<div class="card-head"><h2 style="font-size:13px">未执行/弃权分类</h2>
    <span class="muted" style="font-size:11px">客户规则未执行/证据不足会阻断报告；平台点位只作附录</span></div>
    <div class="kv"><div><span class="k">客户规则未执行</span> <span class="v">${c.customer_unexecuted || 0}</span></div>
    <div><span class="k">客户规则证据不足</span> <span class="v">${c.customer_insufficient || 0}</span></div>
    <div><span class="k">客户规则不适用</span> <span class="v">${c.customer_not_applicable || 0}</span></div>
    <div><span class="k">平台/内置</span> <span class="v">${c.platform_builtin || 0}</span></div></div>
    ${_btn ? `<div class="actions" style="margin-top:8px">${_btn}</div>` : ""}
    <div class="card-head" style="margin-top:12px"><h2 style="font-size:13px">对象级例外授权（逐项接受）</h2>
      <span class="muted" style="font-size:11px">${esc(_countsText)}；禁止批量，关键项需两名不同授权人</span></div>
    <div class="muted" style="font-size:11px;margin-top:4px" id="wb-unknown-gate">${esc(_gateText)}</div>
    ${_candErr ? `<div class="muted" style="font-size:11px">候选读取失败：${esc(_candErr)}</div>` : ""}
    <div id="wb-unknown-accept-list">${_listHtml}</div>`;
  box.querySelectorAll("[data-unknown-ev]").forEach(b => b.onclick = async () => {
    const reason = prompt(`为 ${b.dataset.unknownPid} 申请补证，请填写缺口/理由`, "证据不足，需补充原始记录");
    if (!reason) return;
    b.disabled = true;
    const r = await (await fetch(`/api/v1/manifest/results/${encodeURIComponent(b.dataset.unknownEv)}/evidence-request`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reason }) })).json();
    b.disabled = false;
    if (r.error) { alert(r.error); return; }
    showToast("补证事项已创建"); loadWbUnknown(pid);
  });
  box.querySelectorAll("[data-unknown-accept]").forEach(b => b.onclick = async () => {
    const x = _cands.find(y => String(y.result_id) === String(b.dataset.unknownAccept)) || {};
    const reason = prompt(`接受对象级 unknown 例外：${x.label || x.result_id}\n请填写理由（写审计，不能批量）`,
                          "证据不足，经人工确认接受该对象的结果（不覆盖执行失败）");
    if (!reason) return;   // 取消 = 不写审计
    b.disabled = true;
    let r = {};
    try {
      r = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/accept-unknown`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result_id: x.result_id, result_hash: x.result_hash,
                               run_id: x.run_id, reason: reason }),
      })).json();
    } catch (e) { r = { error: "请求失败，请稍后重试" }; }
    if (r.error) {
      b.disabled = false;
      alert("接受失败：" + r.error);
      return;
    }
    if ((r.pending || []).length && !(r.accepted || []).length) {
      showToast("关键项需另一名不同授权人再次接受（本人重复无效）", "err");
    } else if ((r.accepted || []).length) {
      showToast("对象级例外授权已生效，报告门禁已刷新");
    } else {
      showToast("授权已记录");
    }
    // 接受成功后刷新候选与报告门禁状态（“点击成功但报告仍阻断”的修复点）
    await loadWbUnknown(pid);
    if (typeof renderWbReportStatus === "function") { try { await renderWbReportStatus(pid); } catch (e) {} }
  });
}

/* ===================== T-43 人工复核闭环（展示项 100% 复核 / 人工漏报 / 后台对账） =====================
   数据来源：GET /api/v1/projects/{pid}/human-review（与 CLI `human-review` 同一服务层）。
   隐藏项（抑制台账）不在此渲染；提交漏报前接口不返回隐藏项内容，避免锚定。
   报告门禁：展示项未复核 / 人工漏报未对账时，报告区自动显示阻断原因（report-status 同一门禁）。 */
const _WB_HR_SEV = { critical: "严重", warning: "一般", info: "提示" };
const _WB_HR_DECISIONS = [
  ["confirmed_direct_true", "确认直连真、平台漏"],
  ["confirmed_platform_true", "确认平台真、直连误"],
  ["confirmed_both_true", "两边都真（描述不同）"],
  ["direct_false_positive", "直连误报"],
  ["platform_false_positive", "平台误报"],
  ["both_false", "两边都误报"],
  ["evidence_insufficient", "证据不足"],
  ["rule_or_route_error", "规则/路由错误"],
];
const _WB_HR_REASON_REQUIRED = ["direct_false_positive", "platform_false_positive", "both_false",
                                "evidence_insufficient", "rule_or_route_error"];

/* ===================== T-51 人工“显示隐藏疑似问题 (N)”开关 =====================
   服务端同源接口：GET/POST /api/v1/projects/{pid}/hidden-items*（与 CLI
   `rp hidden-item` 同一批服务函数）。口径：
   - 默认关闭，每次进入复核不记忆；production 显示 N，evaluation 提交独立复核前
     不显示 N/内容（API 403）；业务管理员只读，不可打开隐藏池；
   - 打开需二次确认，写 reveal 审计；隐藏区与可见项区物理分开，绝不混入主列表；
   - 打开后仍需逐条裁决：确认真问题才恢复为可见并进报告；
   - 所有隐藏项进入进化池（feedback/evolution 最小钩子）；默认处置只能是
     suspected_false_positive（weak_default，非 gold，不调阈值/不自动训练）。 */
var _WB_HIDDEN = { pid: "", open: false, data: null };
var _WB_HIDDEN_SEV = { critical: "严重", warning: "一般", info: "提示" };

function _wbHiddenReset(pid) {
  _WB_HIDDEN = { pid: String(pid || ""), open: false, data: null };
  var old = document.querySelector("#wb-hidden-panel");
  if (old) old.remove();
}

function _wbHiddenCountText(hidden) {
  hidden = hidden || {};
  if (hidden.count === null || hidden.count === undefined) return "—";
  return String(hidden.count);
}

function _wbHiddenEvoText(it) {
  var evo = (it && it.evolution) || {};
  var status = { pending: "待处置", labeled_strong: "强人工标签",
    labeled_weak: "弱人工标签", default_suspected_false_positive: "TTL 弱默认：疑似误报",
    not_enqueued: "未入池" }[evo.evolution_status] || evo.evolution_status || "";
  var parts = ["进化池 " + status];
  if (it && it.feedback_enqueued) parts.push("已入池");
  if (evo.label_strength) parts.push("强度 " + evo.label_strength);
  if (evo.default_due) parts.push("超 TTL 待默认处置");
  return parts.join(" · ");
}

function _wbHiddenItemCard(it, canReview, targets) {
  var sev = it.severity || "warning";
  var sevLabel = it.severity_label || _WB_HIDDEN_SEV[sev] || sev;
  var sevCls = sev === "critical" ? "draft" : (sev === "warning" ? "r" : "published");
  var adjudication = it.adjudication || "unreviewed";
  var statusCls = adjudication === "confirmed" ? "published"
    : (adjudication === "rejected" ? "draft"
    : (adjudication === "evidence_insufficient" ? "r" : "draft"));
  var title = [it.rule_code || "", it.subject || "", it.issue_type || ""].filter(Boolean).join(" · ") || "隐藏疑似问题";
  var quote = String(it.quote || "").slice(0, 220);
  var issue = String(it.issue || it.reason || "").slice(0, 200);
  var buttons = "";
  if (canReview && it.is_open) {
    var mergeOptions = (targets || []).map(function (t) {
      return '<option value="' + esc(t.item_id) + '">' + esc((t.rule_code || t.item_id) + " · " + (t.subject || "")) + "</option>";
    }).join("");
    buttons = '<span class="fc-decisions">' +
      '<button class="btn primary" data-hidden-act="confirm" data-hidden-id="' + esc(it.hidden_item_id) + '" title="确认真问题：恢复为可见问题 + 记 suppression_error（强标签）">确认恢复</button>' +
      '<button class="btn" data-hidden-act="reject" data-hidden-id="' + esc(it.hidden_item_id) + '" title="人工判为误报：保留隐藏状态（弱人工标签）">误报</button>' +
      '<button class="btn" data-hidden-act="request-evidence" data-hidden-id="' + esc(it.hidden_item_id) + '" title="证据不足：请求补证，隐藏项保持待处置">请求补证</button>' +
      '<button class="btn" data-hidden-act="recover" data-hidden-id="' + esc(it.hidden_item_id) + '" title="恢复为可见问题（需填原因；写审计）">恢复</button>' +
      '<span style="display:inline-flex;gap:4px;align-items:center"><select class="field" data-hidden-merge="' + esc(it.hidden_item_id) + '" style="max-width:190px"><option value="">与可见项重复合并…</option>' + mergeOptions + '</select>' +
      '<button class="btn" data-hidden-act="merge" data-hidden-id="' + esc(it.hidden_item_id) + '">合并</button></span>' +
      '<button class="btn" data-hidden-act="rule-error" data-hidden-id="' + esc(it.hidden_item_id) + '" title="规则/路由错误反馈：进入规则进化反向样本">规则错误</button>' +
      "</span>";
  }
  return '<div class="fcard" data-hidden-card="' + esc(it.hidden_item_id) + '">' +
    '<div class="fc-head"><span class="pill ' + sevCls + '">' + esc(sevLabel) + "</span>" +
    '<span class="pill draft">隐藏项</span>' +
    '<span class="fc-title">' + esc(title) + "</span>" +
    '<span class="muted" style="font-size:11px">' + esc(it.source_label || it.source || "") +
    " · " + esc(it.hidden_reason_label || it.hidden_reason || "") + "</span>" +
    '<span class="pill ' + statusCls + '">' + esc(it.adjudication_label || adjudication) + "</span></div>" +
    (issue ? '<div class="fc-desc"><span>问题</span>' + esc(issue) + "</div>" : "") +
    (quote ? '<div class="fc-basis fc-evidence"><span>原文</span>' + esc(quote) + "</div>" : "") +
    '<div class="fc-basis"><span>隐藏原因</span>' + esc(it.hidden_reason_detail || "") +
    " · 风险 " + esc(it.risk_level || "") + " · 证据 " + esc(it.evidence_status_label || it.evidence_status || "") +
    (it.last_revealed_by ? " · 打开 " + esc(it.reveal_count || 0) + " 次（最近 " + esc(it.last_revealed_by) + "）" : "") + "</div>" +
    '<div class="fc-tools"><span class="muted fc-loc" style="font-size:11px">' + esc(_wbHiddenEvoText(it)) +
    (it.recovered_finding_id ? " · 已恢复 finding " + esc(it.recovered_finding_id) : "") +
    '</span>' + buttons + "</div></div>";
}

function _wbHiddenRender(pid) {
  if (!_WB_HIDDEN.open || _WB_HIDDEN.pid !== String(pid || "")) {
    var stale = document.querySelector("#wb-hidden-panel");
    if (stale) stale.remove();
    return;
  }
  var host = document.querySelector("#wb-human-loop");
  var root = document.querySelector("#view-workbench");
  if (!host || !root) return;
  var data = _WB_HIDDEN.data || {};
  var hidden = data.hidden || {};
  var items = data.items || [];
  var targets = data.visible_targets || [];
  // T-83（D-FLOW-01）：can_review 为唯一判据；旧服务端响应无该字段时兼容回退
  // can_reveal（业务管理员 can_reveal 恒为 false，不会越权渲染裁决按钮）。
  var _wbPerms = data.permissions || {};
  var _wbCanReview = (_wbPerms.can_review === undefined)
    ? !!_wbPerms.can_reveal : !!_wbPerms.can_review;
  var canReview = currentRole === "reviewer" && _wbCanReview;
  var panel = document.querySelector("#wb-hidden-panel");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "wb-hidden-panel";
    panel.className = "card";
    panel.style.margin = "10px 0";
    panel.style.border = "1px dashed #F54A45";
    if (host.parentNode) host.parentNode.insertBefore(panel, host.nextSibling);
    else root.insertBefore(panel, root.firstChild);
  }
  var evo = hidden.evolution || {};
  var evoParts = [];
  if (evo.feedback_coverage !== undefined) evoParts.push("进化池覆盖 " + esc(evo.feedback_coverage) + "%（目标 " + esc(evo.target_feedback_coverage || 100) + "%）");
  if (evo.pending !== undefined) evoParts.push("待处置 " + esc(evo.pending));
  if (evo.default_due) evoParts.push("超 TTL 待默认处置 " + esc(evo.default_due));
  var recovered = data.recovered_items || [];
  panel.innerHTML =
    '<div class="wb-hidden-semantics" role="note" data-hidden-semantics="1">' +
    '<b>这里既可能是误报，也可能是真问题</b>：隐藏区只是默认视图过滤，不是“已确认误报”。' +
    '<span>打开 ≠ 自动确认，必须逐条裁决；<b>确认真问题才恢复为可见问题并进入报告</b>；' +
    '未被确认的不会丢弃，会进二次复核（TTL 弱默认也留审计，不是最终结论）。</span></div>' +
    '<div class="card-head"><h2 style="font-size:13px">隐藏/疑似问题（独立区，不计入展示项复核）</h2>' +
    '<span class="muted" style="font-size:11px">隐藏=可逆视图过滤，不是删除；打开动作已审计；打开 ≠ 自动确认，仍需逐条裁决</span>' +
    '<button class="btn" id="wb-hidden-close">关闭隐藏区</button></div>' +
    '<div class="kv"><div><span class="k">隐藏待裁决</span> <span class="v">' + esc(_wbHiddenCountText(hidden)) + " 条（独立区）</span></div>" +
    '<div><span class="k">已恢复可见</span> <span class="v">' + esc(hidden.recovered_total || 0) + " 条</span></div>" +
    '<div><span class="k">进化池</span> <span class="v">' + (evoParts.join(" · ") || "—") + "</span></div></div>" +
    '<div class="muted" style="font-size:11px;margin-top:4px">' +
    '默认处置=suspected_false_positive（weak_default，非 gold，不调阈值/不自动训练）；' +
    '确认真问题才恢复为可见问题并进入报告；误报/合并/规则错误保留审计痕迹。</div>' +
    '<div id="wb-hidden-list" style="margin-top:8px">' +
    ((items.length ? items.map(function (it) { return _wbHiddenItemCard(it, canReview, targets); }).join("")
      : '<div class="empty">当前没有待裁决的隐藏项</div>')) +
    "</div>" +
    (recovered.length ? '<div class="muted" style="font-size:11px;margin-top:6px">已恢复（现在可见项区展示）：' +
      recovered.slice(0, 20).map(function (x) { return esc(x.rule_code || x.hidden_item_id); }).join(" · ") + "</div>" : "");
  /* T-203：同一「其他疑似问题」面板内再挂**影子池分区**（独立区，物理分开、不混主队列）。
     影子项来自 GET/POST /api/v1/projects/{pid}/shadow-items*（与 CLI `rp shadow *` 同源）；
     默认只给 N，打开才返回明细（写 shadow.revealed 审计）。 */
  var _shadowHome = document.createElement("div");
  _shadowHome.id = "wb-shadow-section";
  _shadowHome.style.borderTop = "1px dashed #E8EAED";
  _shadowHome.style.marginTop = "10px";
  _shadowHome.style.paddingTop = "8px";
  _shadowHome.innerHTML = _wbShadowSectionHtml();
  panel.appendChild(_shadowHome);
  var _shadowExpand = document.createElement("button");
  _shadowExpand.type = "button";
  _shadowExpand.className = "btn";
  _shadowExpand.id = "wb-shadow-reveal";
  _shadowExpand.style.marginTop = "6px";
  _shadowExpand.textContent = _WB_SHADOW.revealed ? "刷新影子明细" : "打开影子池明细（二次确认，写审计）";
  _shadowExpand.onclick = async function () {
    var _d = _WB_SHADOW.data || {};
    if (!_WB_SHADOW.revealed) {
      var _ok = false;
      try {
        _ok = confirm("打开影子池明细？\n\n"
          + "· 这里**既可能是误报，也可能是真问题**；确认前不丢弃、不影响正式报告；\n"
          + "· 打开动作写审计（shadow.revealed）；\n"
          + "· 打开 ≠ 自动确认，需要逐条裁决；未裁决的会进二次复核。");
      } catch (e) { _ok = false; }
      if (!_ok) return;
    }
    var _ok2 = await _wbShadowReveal(pid);
    if (!_ok2) return;
    _wbHiddenRender(pid);
    showToast("影子池明细已打开（已写审计）；请逐条裁决——可能是误报，也可能是真问题");
    var _sec = document.querySelector("#wb-shadow-section");
    if (_sec) { try { _sec.scrollIntoView({ block: "start", behavior: "auto" }); } catch (e) {} }
  };
  /* 入口按钮必须真正挂进影子分区（此前只创建未 append → 界面上没有「打开影子池明细」入口，
     用户无法经 UI 打开明细）。挂载在分区内容之后，不改变外层面板结构。 */
  _shadowHome.appendChild(_shadowExpand);
  _shadowHome.querySelectorAll("[data-shadow-act]").forEach(function (b) {
    b.onclick = function () { _wbShadowDecide(pid, b.dataset.shadowId, b.dataset.shadowAct); };
  });
  var _closeBtnAnchor = panel.querySelector("#wb-hidden-close");
  var closeBtn = _closeBtnAnchor;
  if (closeBtn) closeBtn.onclick = function () { _wbHiddenClose(pid); };
  panel.querySelectorAll("[data-hidden-act]").forEach(function (b) {
    b.onclick = function () {
      var itemId = b.dataset.hiddenId;
      var action = b.dataset.hiddenAct;
      var mergeInto = "";
      if (action === "merge") {
        var sel = panel.querySelector('[data-hidden-merge="' + itemId + '"]');
        mergeInto = sel ? sel.value : "";
        if (!mergeInto) { showToast("请选择要合并到的可见项", "err"); return; }
      }
      _wbHiddenAction(pid, itemId, action, mergeInto);
    };
  });
}

function _wbHiddenScrollToPanel() {
  /* P1-2（T-198）：隐藏区面板由 wb106MarkPanels 统一排到页面底部；用户点开关后
     如果只弹 toast 不滚动，会以为“没打开/没内容”。开关打开后把面板滚进视口。 */
  var panel = document.getElementById("wb-hidden-panel");
  if (!panel) return;
  var go = function () {
    try { panel.scrollIntoView({ block: "start", behavior: "auto" }); } catch (e) {}
    try {
      var r = panel.getBoundingClientRect();
      if (r.top < 0 || r.top > (window.innerHeight - 140)) {
        window.scrollTo(0, Math.max(0, window.scrollY + r.top - 72));
      }
    } catch (e2) {}
  };
  go();
  try {
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(go);
    setTimeout(go, 120);
  } catch (e3) {}
}

function _wbHiddenClose(pid) {
  _WB_HIDDEN.open = false;
  _WB_HIDDEN.data = null;
  var panel = document.querySelector("#wb-hidden-panel");
  if (panel) panel.remove();
  var toggle = document.querySelector("#wb-hidden-toggle");
  if (toggle) toggle.textContent = toggle.dataset.closedLabel || "其他疑似问题";
  if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
}

async function _wbHiddenToggle(pid, btn) {
  if (_WB_HIDDEN.open) { _wbHiddenClose(pid); await loadWbHumanLoop(pid); return; }
  var ok = false;
  try {
    /* P1-1（用户重点）：语义必须双向——隐藏区既可能是误报，也可能是真问题；
       且明确“未确认不丢弃、会进二次复核”“确认真问题才恢复并进报告”。 */
    ok = confirm(
      "隐藏区是默认视图过滤，不删除任何问题。\n\n" +
      "这里既可能是误报，也可能是被规则误判的真问题（或证据不足），请逐条确认。\n" +
      "未被确认的不会丢弃，会进二次复核（超 TTL 的弱默认也会留审计，不是最终结论）。\n\n" +
      "打开动作将被审计；打开 ≠ 自动确认；确认真问题才恢复为可见并进入报告。\n\n" +
      "确认打开隐藏疑似问题区（内含隐藏项 + 影子池两个独立区，物理分开）？");
  } catch (e) { ok = false; }
  if (!ok) return;   // 二次确认取消 = 不打开、不写审计
  if (btn) { btn.disabled = true; btn.textContent = "打开中…"; }
  var r = {};
  try {
    r = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/hidden-items/reveal`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm: true }),
    })).json();
  } catch (e) { r = { error: "打开失败，请稍后重试" }; }
  if (btn) btn.disabled = false;
  if (!r || !r.ok) {
    if (btn) btn.textContent = btn.dataset.closedLabel || "其他疑似问题";
    showToast((r && r.error) || "隐藏项打开失败（评测模式需先提交独立复核）", "err");
    return;
  }
  _WB_HIDDEN.open = true;
  _WB_HIDDEN.pid = String(pid || "");
  _WB_HIDDEN.data = { hidden: r.hidden || {}, items: r.items || [],
                      visible_targets: r.visible_targets || [],
                      permissions: r.permissions || {} };
  _wbHiddenRender(pid);
  if (btn) { btn.textContent = "关闭其他疑似问题"; btn.dataset.closedLabel = "其他疑似问题"; }
  if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
  if (typeof wb106MarkPanels === "function") wb106MarkPanels();
  _wbHiddenScrollToPanel();
  showToast("隐藏区已打开（已写审计）；请逐条裁决——这里可能是误报，也可能是真问题");
}

async function _wbHiddenAction(pid, itemId, action, mergeInto) {
  var reason = "";
  var needReason = ["reject", "request-evidence", "recover", "merge", "rule-error"].indexOf(action) >= 0;
  if (needReason) {
    var tip = { reject: "请说明为什么是误报（写审计，弱人工标签）",
      "request-evidence": "请说明缺口/需要补什么证据",
      recover: "请说明恢复原因（人工动作写审计）",
      merge: "请说明重复依据（合并到所选可见项）",
      "rule-error": "请说明规则/路由错在哪里（写规则进化反馈）" }[action] || "请填写原因";
    reason = prompt(tip, "");
    if (!reason || !reason.trim()) return;
  }
  var payload = { reason: reason || "" };
  if (mergeInto) payload.merge_into = mergeInto;
  var r = {};
  try {
    r = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/hidden-items/${encodeURIComponent(itemId)}/${action}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })).json();
  } catch (e) { r = { error: "裁决提交失败，请稍后重试" }; }
  if (!r || !r.ok) { showToast((r && r.error) || "隐藏项裁决失败", "err"); return; }
  _WB_HIDDEN.data = { hidden: r.hidden || {}, items: r.items || [],
                      visible_targets: r.visible_targets || [],
                      permissions: { can_review: true } };
  _WB_HIDDEN.open = true;
  _WB_HIDDEN.pid = String(pid || "");
  _wbHiddenRender(pid);
  await loadWbHumanLoop(pid);
  if (typeof renderWbReportStatus === "function") { try { await renderWbReportStatus(pid); } catch (e) {} }
  var msg = { confirm: "已确认真问题：恢复为可见 + 记 suppression_error（强标签）",
    recover: "已恢复为可见问题并写回报告 finding",
    reject: "已判为误报（隐藏项保留，弱人工标签）",
    "request-evidence": "已请求补证（隐藏项保持待处置）",
    merge: "已合并到所选可见项（去重，弱人工标签）",
    "rule-error": "已提交规则/路由错误反馈（进入规则进化）" }[action] || "已记录";
  showToast(msg);
}

/* ===================== T-203 影子池（三区仲裁）Phase 2 前端接线 =====================
   服务端同源接口（与 CLI `rp shadow *` 同一批服务函数）：
   - GET  /api/v1/projects/{pid}/shadow-items           默认只返回 N/汇总，**不返回明细**
   - POST /api/v1/projects/{pid}/shadow-items/reveal    二次确认（confirm=true）后返回明细，写审计
   - POST /api/v1/projects/{pid}/shadow-items/{id}/decide  四动作 confirm/false_positive/unsure/skip
   - GET  /api/v1/projects/{pid}/shadow-items/metrics   指标（池大小/真问题比例/升级率）
   口径（用户原话）：默认只给 N；打开需二次确认并写审计；
   **这里既可能是误报，也可能是真问题**；未确认的**不丢弃**，会进二次复核；
   业务管理员只读（按钮 disabled + 原因，不显示数量 N）；盲审/评测模式提交独立复核前不显示 N。
   影子项与隐藏项（抑制台账）是两个独立区，都在「其他疑似问题」面板里物理分区，绝不混入问题队列。 */
var _WB_SHADOW = { pid: "", loading: false, data: null, error: "", revealed: false };
var _WB_SHADOW_ACTIONS = [
  ["confirm", "确认真问题", "已确认：平台 finding 回到正式口径；直连项待晋升 finding"],
  ["false_positive", "判为误报", "判误报：写反例卡进自进化候选（不自动改阈值）"],
  ["unsure", "存疑", "存疑：不丢弃，进入二次复核队列"],
  ["skip", "跳过", "跳过：不判断也不丢弃，仍进二次复核队列"]
];

function _wbShadowReset(pid) {
  _WB_SHADOW = { pid: String(pid || ""), loading: false, data: null, error: "", revealed: false };
}

function _wbShadowCount() {
  var d = _WB_SHADOW.data || {};
  if (d.count === null || d.count === undefined) return null;
  var n = Number(d.count);
  return isFinite(n) ? n : null;
}

async function wb106RefreshShadow(pid) {
  pid = String(pid || _WB106.pid || "");
  if (!pid) return;
  _WB_SHADOW.loading = true;
  var out = null, st = 0;
  try {
    var resp = await fetch("/api/v1/projects/" + encodeURIComponent(pid) + "/shadow-items");
    st = resp.status;
    out = await resp.json();
    if (st === 404 || st === 401) out = { error: "项目不存在或无权限（HTTP " + st + "）" };
  } catch (e) {
    out = { error: "网络错误：" + String((e && e.message) || e) };
  }
  if (String(_WB106.pid) !== String(pid)) return;
  _WB_SHADOW.pid = String(pid);
  _WB_SHADOW.loading = false;
  if (out && (out.ok === false || out.error)) {
    _WB_SHADOW.data = null;
    _WB_SHADOW.error = String(out.error || out.message || "读取失败");
  } else {
    _WB_SHADOW.data = out || null;
    _WB_SHADOW.error = "";
  }
  if (typeof _wb106RenderQueueState === "function") _wb106RenderQueueState();
  if (_WB_SHADOW.revealed && _WB_HIDDEN.open
      && String(_WB_HIDDEN.pid) === String(pid)) {
    _wbHiddenRender(pid);
  }
}

function _wbShadowCard(it, canDecide, decideReason) {
  var zone = String(it.zone || "");
  var statusLabel = it.shadow_status_label || it.shadow_status || "";
  var reasonLabel = it.shadow_reason_label || it.shadow_reason || "";
  var srcLabel = it.zone_source_label || it.zone_source || "";
  var conf = (it.shadow_confidence === null || it.shadow_confidence === undefined)
    ? "" : ("置信 " + Math.round(Number(it.shadow_confidence) * 100) + "%");
  var title = [it.rule_code || "", it.subject || "", it.issue_type || ""]
    .filter(Boolean).join(" · ") || "影子疑似问题";
  var quote = String((it.claim || {}).quote || "").slice(0, 220);
  var buttons = "";
  /* discarded 只留痕不可裁决（服务层 decide 返回 409）：不能给它渲染四按钮，
     否则点了必然失败、且和「只留痕」文案自相矛盾。 */
  var open = !!it.is_open && zone !== "discarded";
  if (open) {
    buttons = '<span class="fc-decisions">' + _WB_SHADOW_ACTIONS.map(function (a) {
      var dis = !canDecide;
      var why = dis ? (decideReason || "只读：业务管理员不可裁决影子项") : a[2];
      return '<button class="btn' + (a[0] === "confirm" && !dis ? " primary" : "") + '"'
        + (dis ? ' disabled aria-disabled="true"' : ' data-shadow-act="' + a[0] + '" data-shadow-id="' + esc(it.id) + '"')
        + ' title="' + esc(why) + '">' + esc(a[1]) + "</button>";
    }).join("") + "</span>";
  } else if (zone === "discarded") {
    buttons = '<span class="muted" style="font-size:11px">已被确定性证伪（discarded）：只留痕、不可裁决，审计可查</span>';
  }
  return '<div class="fcard" data-shadow-card="' + esc(it.id) + '">'
    + '<div class="fc-head"><span class="pill ' + (zone === "discarded" ? "draft" : "r") + '">'
    + esc(zone === "discarded" ? "已丢弃留痕" : "影子项") + "</span>"
    + '<span class="fc-title">' + esc(title) + "</span>"
    + '<span class="muted" style="font-size:11px">' + esc(srcLabel + " · " + reasonLabel)
    + (conf ? " · " + esc(conf) : "") + " · 第 " + esc(it.shadow_round || 1) + " 轮</span>"
    + '<span class="pill draft">' + esc(statusLabel) + "</span></div>"
    + (quote ? '<div class="fc-basis fc-evidence"><span>原文</span>' + esc(quote) + "</div>" : "")
    + '<div class="fc-tools"><span class="muted fc-loc" style="font-size:11px">'
    + esc((it.warning || "")) + '</span>' + buttons + "</div></div>";
}

function _wbShadowSectionHtml() {
  var data = _WB_SHADOW.data || {};
  var info = data.summary || {};
  var perms = data.permissions || {};
  var locked = !!data.locked;
  var openItems = (data.items || []).filter(function (x) { return x.is_open && x.zone !== "discarded"; });
  var resolved = (data.items || []).filter(function (x) { return x.is_resolved && x.zone !== "discarded"; });
  var discarded = (data.items || []).filter(function (x) { return x.zone === "discarded"; });
  var canDecide = !!perms.can_decide;
  var decideReason = locked
    ? String(data.lock_reason || "评测/盲审模式：提交独立复核前不可裁决影子项")
    : "只读：业务管理员不可裁决影子项（可查看）";
  var head = '<div class="card-head"><h2 style="font-size:13px">影子池（三区仲裁，独立区）</h2>'
    + '<span class="muted" style="font-size:11px">影子项不影响正式报告与通过率；确认后才回到正式口径</span></div>';
  if (_WB_SHADOW.error) {
    return head + '<div class="muted" style="font-size:11px">影子池读取失败：'
      + esc(_WB_SHADOW.error) + "</div>";
  }
  if (locked) {
    return head + '<div class="muted" style="font-size:11px">'
      + esc(data.lock_reason || "评测/盲审模式：提交独立复核前不显示影子项数量与内容")
      + "</div>";
  }
  var kv = '<div class="kv"><div><span class="k">影子待裁决</span> <span class="v">'
    + esc(info.open === undefined ? "—" : info.open) + " 条</span></div>"
    + '<div><span class="k">已裁决</span> <span class="v">' + esc(resolved.length) + " 条</span></div>"
    + '<div><span class="k">证伪留痕</span> <span class="v">' + esc(discarded.length) + " 条</span></div>"
    + '<div><span class="k">七成拿不准</span> <span class="v">' + esc(info.by_reason ? Object.keys(info.by_reason).length : 0) + " 类原因</span></div></div>";
  var body = "";
  if (!_WB_SHADOW.revealed) {
    body = '<div class="muted" style="font-size:11px">影子明细默认不展示（先给数量 N）。'
      + "打开动作会写审计；打开 ≠ 自动确认。</div>";
  } else {
    var cards = openItems.concat(resolved).concat(discarded);
    body = '<div id="wb-shadow-list" style="margin-top:8px">'
      + (cards.length ? cards.map(function (it) { return _wbShadowCard(it, canDecide, decideReason); }).join("")
        : '<div class="empty">当前没有影子项</div>') + "</div>";
  }
  return head + kv + body;
}

async function _wbShadowReveal(pid) {
  /* 打开影子池 = 二次确认 + 写 reveal 审计（HTTP 侧强制 confirm=true）。 */
  var r = {};
  try {
    r = await (await fetch("/api/v1/projects/" + encodeURIComponent(pid) + "/shadow-items/reveal", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm: true, note: "审核工作台打开影子池（独立区）" })
    })).json();
  } catch (e) { r = { error: "打开失败，请稍后重试" }; }
  if (!r || !r.ok) {
    showToast((r && r.error) || "影子池打开失败（评测模式需先提交独立复核）", "err");
    return false;
  }
  _WB_SHADOW.data = r;
  _WB_SHADOW.revealed = true;
  return true;
}

async function _wbShadowDecide(pid, itemId, action) {
  var label = (_WB_SHADOW_ACTIONS.filter(function (a) { return a[0] === action; })[0] || [])[1] || action;
  var ok = true;
  try {
    ok = confirm("确认将这条影子项判定为「" + label + "」？\n\n"
      + "· 这里既可能是误报，也可能是真问题；\n"
      + "· 判为误报只写反例卡，不自动改阈值/不自动训练；\n"
      + "· 存疑/跳过不会丢弃，仍进入二次复核；\n"
      + "· 本次裁决写审计（shadow.decided）。");
  } catch (e) { ok = false; }
  if (!ok) return;
  var r = {};
  try {
    r = await (await fetch("/api/v1/projects/" + encodeURIComponent(pid)
      + "/shadow-items/" + encodeURIComponent(itemId) + "/decide", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: action })
      })).json();
  } catch (e) { r = { error: "裁决提交失败，请稍后重试" }; }
  if (!r || !r.ok) { showToast((r && r.error) || "影子项裁决失败", "err"); return; }
  showToast(r.idempotent ? "重复裁决（幂等）：状态未变" : ("已记录影子项裁决：" + (r.status || "")));
  await wb106RefreshShadow(pid);
  if (_WB_SHADOW.revealed) { await _wbShadowReveal(pid); }
  /* 裁决后必须重渲染分区，否则界面仍停留在旧卡片（点了「确认真问题」看不到任何变化）。 */
  if (_WB_HIDDEN.open && String(_WB_HIDDEN.pid) === String(pid)) { _wbHiddenRender(pid); }
  if (typeof renderWbReportStatus === "function") {
    try { await renderWbReportStatus(pid); } catch (e) {}
  }
}

async function _wbSubmitIndependent(pid, btn) {
  if (btn) btn.disabled = true;
  var r = {};
  try {
    r = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/human-review/independent`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ note: "审核员提交独立复核（盲审解锁）" }),
    })).json();
  } catch (e) { r = { error: "提交失败，请稍后重试" }; }
  if (btn) btn.disabled = false;
  if (!r || !r.ok) { showToast((r && r.error) || "提交独立复核失败", "err"); return; }
  showToast("独立复核已提交，现在可打开隐藏项（用于仲裁/差异分析）");
  await loadWbHumanLoop(pid);
}

function _wbHrBox() {
  var box = document.querySelector("#wb-human-loop");
  if (box) return box;
  var host = document.querySelector("#view-workbench");
  if (!host) return null;
  box = document.createElement("div");
  box.id = "wb-human-loop";
  box.className = "card";
  box.style.margin = "10px 0";
  var unknown = document.querySelector("#wb-unknown");
  if (unknown && unknown.parentNode === host) host.insertBefore(box, unknown);
  else host.insertBefore(box, host.firstChild);
  return box;
}

function _wbHrItemCard(it, canReview) {
  var sev = it.severity || "warning";
  var sevLabel = it.severity_label || _WB_HR_SEV[sev] || sev;
  var sevCls = sev === "critical" ? "draft" : (sev === "warning" ? "r" : "published");
  var d = it.direct || {}, p = it.platform || {};
  function _line(side, obj) {
    if (!obj) return "";
    var quote = String(obj.quote || "").slice(0, 220);
    var issue = String(obj.issue || obj.summary || obj.title || "").slice(0, 200);
    var qc = (obj.quote_check || {}).status || "";
    var loc = obj.line ? ("行 " + esc(obj.line)) : (obj.offset != null ? ("偏移 " + esc(obj.offset)) : "");
    var tag = side === "direct" ? "直连" : "平台";
    return `<div class="fc-basis" style="margin-top:2px"><span>${tag}</span>${esc(issue)}` +
      `${quote ? ` · 原文：${esc(quote)}` : ""}${qc ? ` · 证据：${esc(qc)}` : ""}${loc ? " · " + loc : ""}</div>`;
  }
  var title = [it.rule_code || "", it.subject || "", it.issue_type || ""].filter(Boolean).join(" · ");
  var done = it.human_status && it.human_status !== "unreviewed";
  var statusPill = done ? `<span class="pill published">${esc(it.human_label || "已裁决")}</span>` : "";
  var buttons = "";
  /* T-106：只读角色也保留固定裁决按钮（禁用 + 原因），不因权限/已裁决而消失。 */
  var readonly = currentRole === "admin";
  if (!done) {
    var confirmDec = it.bucket === "platform_only" ? "confirmed_platform_true" : "confirmed_direct_true";
    var _dis = !canReview;
    var _why = readonly ? "只读：业务管理员不可裁决展示项" : "当前不可裁决：缺少复核权限或项目未授权";
    buttons = `<span class="fc-decisions">
      <button class="btn${_dis ? "" : " primary"}" ${_dis ? "disabled aria-disabled=\"true\"" : `data-hr-decide="${esc(confirmDec)}" data-hr-item="${esc(it.item_id)}"`} title="${esc(_dis ? _why : "确认为展示项真问题")}">确认问题</button>
      <button class="btn" ${_dis ? "disabled aria-disabled=\"true\"" : `data-hr-decide="evidence_insufficient" data-hr-item="${esc(it.item_id)}"`} title="${esc(_dis ? _why : "问题可能成立但现有证据不足；需补充材料")}">证据不足</button>
      <button class="btn" ${_dis ? "disabled aria-disabled=\"true\"" : `data-hr-decide="rule_or_route_error" data-hr-item="${esc(it.item_id)}"`} title="${esc(_dis ? _why : "规则/路由错误导致误报")}">规则/路由错误</button>
      <select class="field" ${_dis ? "disabled aria-disabled=\"true\"" : `data-hr-select="${esc(it.item_id)}"`} title="${esc(_dis ? _why : "更多裁决")}" style="max-width:150px"><option value="">更多裁决…</option>` +
      _WB_HR_DECISIONS.map(function (d) { return `<option value="${d[0]}">${esc(d[1])}</option>`; }).join("") +
      `</select></span>`;
  } else {
    buttons = `<span class="fc-decisions wb106-hr-done">
      <button class="btn" disabled aria-disabled="true" title="已裁决；如需变更请用「更多裁决」重新裁决">确认问题</button>
      <button class="btn" disabled aria-disabled="true" title="已裁决；如需变更请用「更多裁决」重新裁决">证据不足</button>
      <button class="btn" disabled aria-disabled="true" title="已裁决；如需变更请用「更多裁决」重新裁决">规则/路由错误</button>
    </span>`;
  }
  return `<div class="fcard" data-hr-card="${esc(it.item_id)}">
    <div class="fc-head"><span class="pill ${sevCls}">${esc(sevLabel)}</span>
      <span class="fc-title">${esc(title || "双轨差异")}</span>
      <span class="muted" style="font-size:11px">${esc(it.bucket_label || it.bucket || "")}</span>${statusPill}</div>
    ${_line("direct", d)}${_line("platform", p)}
    <div class="fc-tools"><span class="muted fc-loc">${esc(it.clause || "")}${done && it.human_reason ? " · 原因：" + esc(it.human_reason) : ""}</span>${buttons}</div>
  </div>`;
}

async function loadWbHumanLoop(pid) {
  var box = _wbHrBox();
  if (!box) return;
  var r = {}, st = 0;
  try {
    var resp = await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/human-review`);
    st = resp.status;
    r = await resp.json();
  } catch (e) {
    box.remove(); return;   // 老库/老服务：无该能力时不占位
  }
  if (st === 404 || st === 401) { box.remove(); return; }
  if (!r || r.error) { box.innerHTML = `<div class="muted">人工复核数据读取失败：${esc((r && r.error) || st)}</div>`; return; }
  if (!r.enabled) { box.remove(); return; }   // 无直连草稿/双轨差异：不展示空面板
  var review = r.review || {}, gate = r.gate || {}, perms = r.permissions || {};
  var canReview = !!perms.can_review && currentRole === "reviewer";
  var items = review.items || [];
  var sevCount = review.by_severity || {};
  var gateOk = gate.ok === true;
  // P2-3：正文不出现内部字段名（incomplete_applicable_requirement=1 等），原始全文放 title。
  var _gateSan = (typeof wbGateReasonText === "function")
    ? wbGateReasonText(gate.reasons || []) : { text: (gate.reasons || []).join("；"), full: "" };
  var gateText = gateOk
    ? "报告门禁：展示项已全部裁决、人工漏报已对账，可生成正式报告"
    : ("报告门禁：仍阻断 — " + (_gateSan.text || (gate.reasons || []).slice(0, 3).join("；") || "未满足放行条件"));
  var sevHtml = ["critical", "warning", "info"].map(function (s) {
    var c = sevCount[s] || { total: 0, pending: 0 };
    if (!c.total) return "";
    return `<span><b>${esc(_WB_HR_SEV[s])}</b> ${c.pending}/${c.total} 待裁决</span>`;
  }).filter(Boolean).join(" · ");
  var progress = `已复核 ${review.visible_reviewed || 0}/${review.visible_total || 0} 条展示项`;
  var omStats = r.omissions || {};
  var omissionForm = canReview ? `<details style="margin-top:10px">
    <summary class="muted" style="cursor:pointer;font-size:12px">登记人工漏报（独立填写：位置 / 问题 / 证据）</summary>
    <div class="muted" style="font-size:11px;margin:6px 0">系统不会在提交前显示隐藏/被抑制项（避免锚定）；提交后由后台对账：命中展示项=已报、命中隐藏项=恢复+抑制误差、命中直连草稿=平台漏报、未命中=全新漏报候选。</div>
    <input id="wb-hr-om-loc" class="field" style="width:100%;margin-bottom:6px" placeholder="位置：文件/页码/行/单元格（必填）">
    <input id="wb-hr-om-issue" class="field" style="width:100%;margin-bottom:6px" placeholder="问题：系统漏报了什么（必填）">
    <textarea id="wb-hr-om-quote" class="field" style="width:100%;min-height:56px;margin-bottom:6px" placeholder="证据：原文摘录（必填）"></textarea>
    <div class="actions" style="justify-content:flex-end"><button class="btn primary" id="wb-hr-om-submit">提交漏报</button></div>
  </details>` : '<div class="muted" style="font-size:11px;margin-top:6px">业务管理员只读：不能裁决/登记漏报。</div>';
  var reconcileBtn = canReview
    ? `<button class="btn" id="wb-hr-reconcile"${(omStats.pending || 0) ? "" : " disabled"}>后台对账${(omStats.pending || 0) ? `（${omStats.pending} 条待对账）` : "（无待对账）"}</button>`
    : "";
  // T-51 隐藏疑似问题开关：默认关闭；production 显示 N；evaluation 提交独立复核前
  // 不显示 N 且开关禁用；业务管理员只读、不可打开隐藏池。
  var hiddenInfo = r.hidden || {};
  var hiddenMode = r.review_mode || hiddenInfo.mode || "production";
  var hiddenLocked = !!hiddenInfo.locked;
  var hiddenAdmin = currentRole === "admin";
  var hiddenCountText = _wbHiddenCountText(hiddenInfo);
  var hiddenOpen = _WB_HIDDEN.open && _WB_HIDDEN.pid === String(pid || "");
  // E-09：0 条时入口必须不可点（不只是文案说明）。数量缺失/非法同样禁用，
  // 避免接口字段异常时按钮保持可点、点开才看到「0 条」空面板。
  var hiddenCountKnown = !(hiddenInfo.count === null || hiddenInfo.count === undefined)
    && isFinite(Number(hiddenInfo.count));
  var hiddenZero = !hiddenLocked && !hiddenAdmin && !hiddenOpen
    && hiddenCountKnown && Number(hiddenInfo.count) === 0;
  var hiddenReason = hiddenLocked
    ? String(hiddenInfo.lock_reason || "评测/盲审模式：提交独立复核前不显示隐藏项数量与内容")
    : (hiddenAdmin ? "只读：业务管理员不可打开隐藏池（内容与数量均不展示）"
    : (hiddenZero ? "当前没有待裁决的其他疑似问题（0 条）"
    : (!hiddenCountKnown && !hiddenOpen ? "其他疑似问题数量不可用，暂不可打开" : "")));
  var hiddenDisabled = !!hiddenReason;
  var hiddenLabel = hiddenLocked ? "其他疑似问题（提交独立复核后可用）"
    : (hiddenAdmin ? "其他疑似问题（业务管理员只读）"
    : (hiddenOpen ? "关闭其他疑似问题" : "其他疑似问题 (" + hiddenCountText + ")"));
  var hiddenBar = `<div id="wb-hidden-bar" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;border-top:1px dashed #E8EAED;margin-top:8px;padding-top:8px">
      <span class="muted" style="font-size:11px">复核模式：${esc(r.mode_label || hiddenMode)}</span>
      <button class="btn" id="wb-hidden-toggle" data-closed-label="其他疑似问题 (${esc(hiddenCountText)})" ${hiddenDisabled ? 'disabled aria-disabled="true"' : ""} data-reason="${esc(hiddenReason)}" title="${esc(hiddenReason || "隐藏项默认不展示；里面既可能是误报，也可能是真问题；打开需二次确认并写审计，打开后仍需逐条裁决")}">${esc(hiddenLabel)}</button>
      ${(hiddenMode === "evaluation" && !r.independent_submitted && canReview) ? '<button class="btn primary" id="wb-submit-independent" title="评测/盲审模式：提交独立复核后才允许打开隐藏项（防锚定污染）">提交独立复核</button>' : ""}
      <span class="muted" style="font-size:11px">${hiddenLocked ? "评测/盲审：提交独立复核前不显示隐藏项数量与内容" : (hiddenAdmin ? "业务管理员只读：不可打开隐藏池/不可裁决隐藏项" : "隐藏=可逆视图过滤，不是删除；每次进入默认关闭")}</span>
    </div>`;
  box.innerHTML = `<div class="card-head"><h2 style="font-size:13px">双轨复核（展示项 100% 裁决）</h2>
      <span class="muted" style="font-size:11px">展示项=可见性策略接受展示的差异；隐藏项统一在独立隐藏区（不进主列表）</span></div>
    ${hiddenBar}
    <div class="kv"><div><span class="k">复核进度</span> <span class="v">${esc(progress)}</span></div>
      <div><span class="k">严重度</span> <span class="v">${sevHtml || "—"}</span></div>
      <div><span class="k">人工漏报</span> <span class="v">共 ${esc(omStats.total || 0)} 条 · 待对账 ${esc(omStats.pending || 0)} 条</span></div></div>
    <div class="muted" id="wb-hr-gate" data-gate-reason="1" title="${esc(_gateSan.full || gateText)}" style="font-size:11px;margin-top:4px">${esc(gateText)}</div>
    <div id="wb-hr-list" style="margin-top:8px">${items.length ? items.map(function (it) { return _wbHrItemCard(it, canReview); }).join("") : '<div class="empty">当前没有待裁决的展示项</div>'}</div>
    ${omissionForm}
    <div class="actions" style="margin-top:8px">${reconcileBtn}</div>`;
  box.querySelectorAll("[data-hr-decide]").forEach(function (b) {
    b.onclick = function () { _wbHrDecide(pid, b.dataset.hrItem, b.dataset.hrDecide); };
  });
  box.querySelectorAll("[data-hr-select]").forEach(function (sel) {
    sel.onchange = function () { if (sel.value) _wbHrDecide(pid, sel.dataset.hrSelect, sel.value); };
  });
  var sub = box.querySelector("#wb-hr-om-submit");
  if (sub) sub.onclick = async function () {
    var loc = (box.querySelector("#wb-hr-om-loc").value || "").trim();
    var issue = (box.querySelector("#wb-hr-om-issue").value || "").trim();
    var quote = (box.querySelector("#wb-hr-om-quote").value || "").trim();
    var miss = [];
    if (!loc) miss.push("位置"); if (!issue) miss.push("问题"); if (!quote) miss.push("证据");
    if (miss.length) { showToast("请填写：" + miss.join("、"), "err"); return; }
    sub.disabled = true;
    var rr = {};
    try {
      rr = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/omissions`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locator: { text: loc }, issue: issue, quote: quote }),
      })).json();
    } catch (e) { rr = { error: "提交失败，请稍后重试" }; }
    sub.disabled = false;
    if (rr.error) { showToast(rr.error, "err"); return; }
    showToast("漏报已登记（待后台对账）");
    await loadWbHumanLoop(pid);
    if (typeof renderWbReportStatus === "function") { try { await renderWbReportStatus(pid); } catch (e) {} }
  };
  var recBtn = box.querySelector("#wb-hr-reconcile");
  if (recBtn) recBtn.onclick = async function () {
    recBtn.disabled = true;
    var rr = {};
    try {
      rr = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/omissions/reconcile`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    } catch (e) { rr = { error: "对账失败，请稍后重试" }; }
    if (rr.error) { recBtn.disabled = false; showToast(rr.error, "err"); return; }
    var parts = Object.keys(rr.by_status || {}).map(function (k) { return k + " " + rr.by_status[k]; });
    showToast("对账完成：" + (parts.join(" · ") || "无待对账"));
    await openWorkbench(pid);
  };
  var hToggle = box.querySelector("#wb-hidden-toggle");
  if (hToggle) hToggle.onclick = function () { _wbHiddenToggle(pid, hToggle); };
  var hIndep = box.querySelector("#wb-submit-independent");
  if (hIndep) hIndep.onclick = function () { _wbSubmitIndependent(pid, hIndep); };
  if (_WB_HIDDEN.open && _WB_HIDDEN.pid === String(pid || "")) _wbHiddenRender(pid);
}

async function _wbHrDecide(pid, itemId, decision) {
  var needReason = _WB_HR_REASON_REQUIRED.indexOf(decision) >= 0;
  var reason = "";
  if (needReason) {
    reason = prompt("请填写裁决原因（否定/证据不足类裁决必填，写审计）", "");
    if (!reason || !reason.trim()) return;
  }
  var r = {};
  try {
    r = await (await fetch(`/api/v1/projects/${encodeURIComponent(pid)}/human-review/decide`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ item_id: itemId, decision: decision, reason: reason || "" }),
    })).json();
  } catch (e) { r = { error: "裁决提交失败，请稍后重试" }; }
  if (r.error) { showToast(r.error, "err"); return; }
  var gate = r.gate || {};
  showToast(gate.ok ? "已裁决；展示项复核完成" : "已裁决；仍有未复核展示项/未对账漏报");
  await loadWbHumanLoop(pid);
  if (typeof renderWbReportStatus === "function") { try { await renderWbReportStatus(pid); } catch (e) {} }
}

/* ===========================================================================
 * T-50（Qoder W-14）V3.2 产品接线：双轨数据只读面板
 * 数据源与 CLI 同一批服务函数（HTTP 薄适配）：
 *   GET /api/v1/direct-drafts?case=   直连草稿（不可变原始输出）
 *   GET /api/v1/comparisons?case=     四桶差异（提示性比对，不是裁决）
 *   GET /api/v1/visibility?case=      可见性策略应用状态 + V3.2 §15 四项门禁
 * 边界：只做只读汇总；隐藏/被排除项不在审核工作台渲染（防锚定），
 *       恢复与审计走后台/CLI（suppression_ledger recover 写审计 + 写回 finding）。
 * =========================================================================== */
function _wbDualBox() {
  var box = document.querySelector("#wb-dual-track");
  if (box) return box;
  var host = document.querySelector("#view-workbench");
  if (!host) return null;
  box = document.createElement("div");
  box.id = "wb-dual-track";
  box.className = "card";
  box.style.margin = "10px 0";
  var hr = document.querySelector("#wb-human-loop");
  if (hr && hr.parentNode === host) host.insertBefore(box, hr.nextSibling);
  else host.insertBefore(box, host.firstChild);
  return box;
}

async function loadWbDualTrack(pid) {
  var box = _wbDualBox();
  if (!box) return;
  var q = encodeURIComponent(pid);
  var dd = {}, cp = {}, vs = {};
  try {
    var res = await Promise.all([
      fetch(`/api/v1/direct-drafts?case=${q}`),
      fetch(`/api/v1/comparisons?case=${q}`),
      fetch(`/api/v1/visibility?case=${q}`),
    ]);
    dd = await res[0].json();
    cp = await res[1].json();
    vs = await res[2].json();
  } catch (e) {
    box.remove();
    return;   // 老库/老服务：无该能力时不占位
  }
  if ((dd && dd.status === 404) || (cp && cp.status === 404) || (vs && vs.status === 404)) {
    box.remove(); return;
  }
  if (!(dd && dd.ok) && !(cp && cp.ok) && !(vs && vs.ok)) { box.remove(); return; }
  var enabled = !!(vs && vs.enabled) || Number((cp && cp.total) || 0) > 0
    || Number((dd && dd.total) || 0) > 0;
  if (!enabled) { box.remove(); return; }   // 无直连草稿/双轨数据：不展示空面板
  var dTotal = Number((dd && dd.total) || 0);
  var dItems = ((dd && dd.items) || []).reduce(function (n, it) {
    return n + Number((it && it.items_count) || 0);
  }, 0);
  var buckets = ((cp && cp.counts) || {}).by_bucket || {};
  var bucketLabels = (cp && cp.buckets) || {};
  var bucketText = ["both", "direct_only", "platform_only", "conflict"].map(function (k) {
    return esc(bucketLabels[k] || k) + " " + Number(buckets[k] || 0);
  }).join(" · ");
  var counts = (vs && vs.counts) || {};
  var review = (vs && vs.review) || {};
  var gates = (vs && vs.gates) || {};
  var gateParts = [["visible_unreviewed", "展示项未复核"],
    ["unresolved_critical_conflict", "关键冲突未裁决"],
    ["incomplete_applicable_requirement", "适用要求未完成"],
    ["suppressed_risk_decision_missing", "抑制项缺少风险裁决"]].map(function (kv) {
      var n = Number(gates[kv[0]] || 0);
      return esc(kv[1]) + " " + (n ? `<b class="pill draft">${n}</b>` : "0");
    }).join(" · ");
  var canReview = currentRole === "reviewer";
  box.innerHTML = `<div class="card-head"><h2 style="font-size:13px">双轨数据（直连草稿 / 四桶差异 / 可见性策略）</h2>
      <span class="muted" style="font-size:11px">V3.2 Phase 1：展示项 100% 复核；隐藏=可逆视图过滤（自动抑制关闭）；与 CLI 同一批服务函数</span></div>
    <div class="kv"><div><span class="k">直连草稿</span> <span class="v">${dTotal} 次运行 · ${dItems} 条候选（原始输出不可变，可回查 quote）</span></div>
      <div><span class="k">四桶差异</span> <span class="v">${bucketText}</span></div>
      <div><span class="k">可见性策略</span> <span class="v">已应用 ${Number(counts.total || 0)} 条 · 待应用 ${Number(counts.visibility_unset || 0)} 条 · 展示项已复核 ${Number(review.visible_reviewed || 0)}/${Number(review.visible_total || 0)}</span></div></div>
    <div class="muted" style="font-size:11px;margin-top:4px">报告门禁（V3.2 §15，全部为 0 才可出正式报告）：${gateParts}</div>
    <div class="muted" style="font-size:11px;margin-top:2px">展示项逐条裁决见上方「双轨复核」面板；隐藏/排除项按视图过滤，不在审核工作台渲染（恢复/审计走后台或 CLI）。${canReview ? "" : " 业务管理员只读。"}</div>`;
}

/* ===========================================================================
 * T-106 审核工作台 UX 完善（三栏结构 / 固定人工审核入口 / 只读禁用可见 /
 *       裁决主操作与反馈 / 空-加载-错误三态 / 移动端可达）
 *
 * 设计原则（借鉴成熟商业审核平台）：
 * 1. 左「问题队列」= 待处理工作清单；中「文档预览」= 原文/解析证据；
 *    右「审核检查器」= 统计、报告门禁、复核动作。三层结构固定，不打乱主流程。
 * 2. 问题队列标题旁常驻「＋新增问题」「其他疑似问题 (N)」两个入口：
 *    无数据 / 只读 / 评测锁定 / 读取失败时按钮不消失，禁用并就地显示原因。
 * 3. 每张问题卡固定「确认 / 误报 / 退回补证 / 忽略 / 更多」五个按钮；
 *    只读角色与已裁决卡片按钮禁用（带原因），绝不删除按钮/隐藏操作。
 * 4. 主操作「确认」为唯一 primary；裁决后给结果反馈条（下一条/改判/关闭）；
 *    裁决弹窗内可「撤销」未提交操作。状态词统一：待处理/已确认/已误报/
 *    待补证/已忽略（与后端 DECISIONS 同源，仅做展示层中文化）。
 * 5. 所有 DOM 由 JS 动态创建/改造，不依赖 index.html / reviewer.html 的标记，
 *    因此业务管理员端（admin.html）与审核员端行为一致。
 *
 * 边界：只改前端展示与交互；裁决/复核仍调用现有 API（finding decision /
 * human-review / hidden-items / 人工新增问题），不改判定、不改权限模型。
 * ======================================================================== */
var _WB106 = {
  pid: "", hidden: null, hiddenLoading: false, ctx: { loading: false, docsReady: false, error: "" },
  readonly: false, delegated: false, headerBound: false, moreMenu: null, fbTimer: 0
};
var _WB106_STATUS_LABEL = {
  pending: "待处理", confirmed: "已确认", false_positive: "已误报",
  need_evidence: "待补证", ignored: "已忽略"
};
var _WB106_ACTION_LABEL = { confirmed: "确认", false_positive: "误报", need_evidence: "退回补证", ignored: "忽略" };
var _WB106_DECISION_TITLE = { confirmed: "确认问题", false_positive: "判为误报", need_evidence: "退回补证", ignored: "忽略问题" };
var _WB106_DECISION_ORDER = ["confirmed", "false_positive", "need_evidence", "ignored"];
var _WB106_SEV = {
  critical: ["严重", "draft"], warning: ["一般", "r"], suspected: ["提示", "published"], info: ["提示", "published"]
};
var _WB106_ACTION_HINT = {
  confirmed: "主操作：问题成立，进入已复核；可填写原因（可选）",
  false_positive: "判为误报：保留记录，需填写原因，原因进入规则进化反馈",
  need_evidence: "问题可能成立但现有证据不足；退回补充材料，不删除问题",
  ignored: "忽略不会删除记录；忽略与退回补证是两种不同处理"
};

function _wb106Readonly() { return currentRole === "admin"; }
function _wb106Find(fid) { return (wbFindings || []).find(function (x) { return String(x.id) === String(fid); }) || {}; }
function _wb106First(sel, root) { return (root || document).querySelector(sel); }

/* -------- 1) 三栏结构：队列（左）/ 文档（中）/ 检查器（右） -------- */
function wb106Layout() {
  var root = document.getElementById("view-workbench");
  if (!root) return false;
  var grid = _wb106First(".wb-main-grid", root);
  if (!grid) return false;
  root.classList.add("wb106-3col");
  root.setAttribute("data-wb106-layout", "3col");
  var ctrl = _wb106First(".wb-control-card", root);
  if (ctrl && !_wb106First(".wb106-insp-head", ctrl)) {
    var head = document.createElement("div");
    head.className = "wb106-insp-head";
    head.innerHTML = '<div class="wb106-insp-title"><b>审核检查器</b><span class="wb106-insp-sub">报告门禁 · 统计 · 复核动作</span></div>'
      + '<span class="pill wb106-insp-pill">证据联动</span>';
    ctrl.insertBefore(head, ctrl.firstChild);
    // 兼容缺失元素：待补证证据提示条（openWorkbench 会向 #wb-evidence-bar 写入真实统计）
    if (!_wb106First("#wb-evidence-bar", ctrl)) {
      var ev = document.createElement("div");
      ev.id = "wb-evidence-bar";
      ev.className = "wb106-evidence-bar";
      ev.hidden = true;
      var reportStrip = _wb106First("#wb-report-strip", ctrl);
      if (reportStrip && reportStrip.nextSibling) ctrl.insertBefore(ev, reportStrip.nextSibling);
      else ctrl.appendChild(ev);
    }
  }
  // 动态插入的复核面板（异步加载）随时可能出现：观察直接子节点变化并整理分区顺序。
  if (!root.__wb106MO && window.MutationObserver) {
    try {
      root.__wb106MO = new MutationObserver(function () { wb106MarkPanels(); });
      root.__wb106MO.observe(root, { childList: true });
    } catch (e) { /* 观察失败不阻断主流程 */ }
  }
  wb106MarkPanels();
  return true;
}

/* 动态插入的复核/辅助面板（双轨复核、隐藏区、unknown、双轨数据）保持整页宽度
   依次追加在页面下方；这里给它们统一加上分区标题，避免“动态插入卡”看起来乱序。 */
function wb106MarkPanels() {
  var root = document.getElementById("view-workbench");
  if (!root) return;
  // 固定顺序：双轨复核 → 隐藏疑似问题 → 未执行分类 → 双轨数据只读；
  // 发现后统一移到 #workbench 之后（页面底部整页宽），避免动态插入把页面撑乱/夹在标题上方。
  var ids = ["wb-human-loop", "wb-hidden-panel", "wb-unknown", "wb-dual-track"];
  var panels = [];
  ids.forEach(function (id, i) {
    var el = document.getElementById(id);
    if (!el) return;
    el.setAttribute("data-wb106-panel", String(i));
    panels.push(el);
  });
  var head = document.getElementById("wb106-secondary-head");
  if (!panels.length) { if (head) head.remove(); return; }
  var tail = Array.prototype.slice.call(root.children).slice(-panels.length);
  var same = tail.length === panels.length && tail.every(function (el, i) { return el === panels[i]; });
  if (!same) panels.forEach(function (el) { root.appendChild(el); });
  if (!head) {
    head = document.createElement("div");
    head.id = "wb106-secondary-head";
    head.className = "wb106-secondary-head";
    head.innerHTML = '<span class="wb106-secondary-bar"></span><b>复核与辅助信息</b>'
      + '<span class="muted">双轨复核 / 隐藏疑似问题 / 未执行分类 / 双轨数据（只读）</span>';
  }
  if (head.parentNode !== root || head.nextElementSibling !== panels[0]) {
    root.insertBefore(head, panels[0]);
  }
}

/* -------- 2) 问题队列固定入口：＋新增问题 / 其他疑似问题 (N) -------- */
function _wb106QueueHost() {
  var root = document.getElementById("view-workbench");
  if (!root) return null;
  var head = _wb106First(".wb-side-card .wb-side-head", root);
  if (head) return head;
  // 兼容入口 HTML 被其他任务调整：退化为在 #wb-findings 前自建头部条
  var box = _wb106First("#wb-findings", root);
  if (!box) return null;
  var fallback = document.getElementById("wb106-q-fallback");
  if (!fallback) {
    fallback = document.createElement("div");
    fallback.id = "wb106-q-fallback";
    fallback.className = "wb106-q-fallback";
    box.parentNode.insertBefore(fallback, box);
  }
  return fallback;
}

function wb106QueueHeaderInit(pid) {
  var host = _wb106QueueHost();
  if (!host) return false;
  var first = host.firstElementChild;
  var acts, hint, titleLine;
  if (!first || host.id === "wb106-q-fallback") {
    if (!first) {
      first = document.createElement("div");
      first.className = "wb106-q-main";
      host.appendChild(first);
    }
    first.classList.add("wb106-q-main");
    titleLine = _wb106First(".wb106-q-title", first);
    if (!titleLine) {
      titleLine = document.createElement("div");
      titleLine.className = "wb106-q-title";
      titleLine.innerHTML = '<b>问题队列</b><span id="wb-side-count" class="muted"></span>';
      first.insertBefore(titleLine, first.firstChild);
    }
    acts = _wb106First(".wb106-q-actions", first);
    if (!acts) {
      acts = document.createElement("div");
      acts.className = "wb106-q-actions";
      titleLine.insertAdjacentElement("afterend", acts);
    }
    hint = _wb106First(".wb106-q-hint", first);
    if (!hint) {
      hint = document.createElement("div");
      hint.className = "wb106-q-hint";
      acts.insertAdjacentElement("afterend", hint);
    }
  } else {
    first.classList.add("wb106-q-main");
    var b = _wb106First("b", first);
    var countEl = _wb106First("#wb-side-count", first);
    titleLine = _wb106First(".wb106-q-title", first);
    if (!titleLine) {
      titleLine = document.createElement("div");
      titleLine.className = "wb106-q-title";
      first.insertBefore(titleLine, first.firstChild);
      if (b) titleLine.appendChild(b);
      if (countEl) titleLine.appendChild(countEl);
    } else {
      if (b && b.parentNode !== titleLine) titleLine.insertBefore(b, titleLine.firstChild);
      if (countEl && countEl.parentNode !== titleLine) titleLine.appendChild(countEl);
    }
    if (b) b.textContent = "问题队列";
    acts = _wb106First(".wb106-q-actions", first);
    if (!acts) {
      acts = document.createElement("div");
      acts.className = "wb106-q-actions";
      titleLine.insertAdjacentElement("afterend", acts);
    }
    hint = _wb106First(".wb106-q-hint", first);
    if (!hint) {
      hint = document.createElement("div");
      hint.className = "wb106-q-hint";
      acts.insertAdjacentElement("afterend", hint);
    }
  }
  var addBtn = document.getElementById("wb106-btn-add");
  var hidBtn = document.getElementById("wb106-btn-hidden");
  if (!addBtn) {
    addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.id = "wb106-btn-add";
    addBtn.className = "btn wb106-btn-add";
    addBtn.textContent = "＋新增问题";
    acts.appendChild(addBtn);
  }
  if (!hidBtn) {
    hidBtn = document.createElement("button");
    hidBtn.type = "button";
    hidBtn.id = "wb106-btn-hidden";
    hidBtn.className = "btn wb106-btn-hidden";
    hidBtn.textContent = "其他疑似问题 (—)";
    acts.appendChild(hidBtn);
  }
  if (!_WB106.headerBound) {
    _WB106.headerBound = true;
    addBtn.addEventListener("click", function () {
      if (addBtn.disabled) { _wb106Explain(addBtn); return; }
      if (typeof openManualFinding === "function") openManualFinding(_WB106.pid || currentWb);
      else showToast("新增问题入口不可用（脚本未加载）", "err");
    });
    hidBtn.addEventListener("click", function () {
      if (hidBtn.disabled) { _wb106Explain(hidBtn); return; }
      _wb106ToggleHidden();
    });
  }
  wb106BatchBarInit(first, hint);
  if (typeof wbL161SyncQueueHead === "function") { try { wbL161SyncQueueHead(host, first); } catch (e) {} }
  _WB106.pid = String(pid || _WB106.pid || "");
  _wb106RenderQueueState();
  return true;
}

/* ---------------- P2-2 批量裁决 UI（本页全选 / 批量确认 / 批量误报 / 逐条反馈 / 撤销） ----------------
   二次确认：批量执行前 confirm；误报必填统一原因；服务端逐条写审计 + 批量汇总审计；
   结果条逐条列出成功/跳过/失败；提供「撤销本次批量」（服务端只恢复仍保持本批结论的项）。 */
function wb106BatchBarInit(first, hint) {
  if (!first) return;
  var bar = document.getElementById("wb106-batch-bar");
  if (!bar) {
    bar = document.createElement("div");
    bar.id = "wb106-batch-bar";
    bar.className = "wb106-batch-bar";
    bar.innerHTML =
      '<label class="wb106-batch-all" title="全选当前筛选下所有待处理问题"><input type="checkbox" id="wb106-batch-all">本页全选</label>' +
      '<span class="wb106-batch-count" id="wb106-batch-count">已选 0 条</span>' +
      '<button type="button" class="btn" id="wb106-batch-confirm" data-base-title="批量确认为真问题（二次确认；逐条写审计；可撤销）" title="批量确认为真问题（二次确认；逐条写审计；可撤销）">批量确认</button>' +
      '<button type="button" class="btn" id="wb106-batch-fp" data-base-title="批量判为误报（须填统一原因；二次确认；逐条写审计；可撤销）" title="批量判为误报（须填统一原因；二次确认；逐条写审计；可撤销）">批量误报</button>' +
      '<button type="button" class="btn wb106-batch-clear" id="wb106-batch-clear" title="清空选择">清空</button>';
    if (hint && hint.parentNode) hint.insertAdjacentElement("afterend", bar);
    else first.appendChild(bar);
  }
  var result = document.getElementById("wb106-batch-result");
  if (!result) {
    result = document.createElement("div");
    result.id = "wb106-batch-result";
    result.className = "wb106-batch-result";
    result.hidden = true;
    bar.insertAdjacentElement("afterend", result);
  }
  if (!bar.__bound) {
    bar.__bound = true;
    var all = bar.querySelector("#wb106-batch-all");
    if (all) all.addEventListener("change", function () { wb106BatchSelectAll(!!all.checked); });
    var c = bar.querySelector("#wb106-batch-confirm");
    if (c) c.addEventListener("click", function (ev) { wb106BatchDecide("confirmed", ev); });
    var fp = bar.querySelector("#wb106-batch-fp");
    if (fp) fp.addEventListener("click", function (ev) { wb106BatchDecide("false_positive", ev); });
    var clr = bar.querySelector("#wb106-batch-clear");
    if (clr) clr.addEventListener("click", function () {
      _WB106.batchSel = {};
      renderWbFindings();
      wb106BatchUpdateBar();
    });
  }
  wb106BatchUpdateBar();
  return bar;
}

function wb106BatchSelectedIds() {
  var sel = _WB106.batchSel || {};
  return Object.keys(sel).filter(function (id) { return !!sel[id]; });
}

function wb106BatchSelectAll(on) {
  _WB106.batchSel = {};
  if (on) {
    var list = (typeof filteredFindings === "function" ? filteredFindings() : [])
      .filter(function (f) { return String(f.status || "pending") === "pending"; });
    list.forEach(function (f) { _WB106.batchSel[f.id] = 1; });
  }
  renderWbFindings();
  wb106BatchUpdateBar();
}

function wb106BatchUpdateBar() {
  var bar = document.getElementById("wb106-batch-bar");
  if (!bar) return;
  var readonly = _wb106Readonly();
  var pendingList = (typeof filteredFindings === "function" ? filteredFindings() : [])
    .filter(function (f) { return String(f.status || "pending") === "pending"; });
  var valid = {};
  pendingList.forEach(function (f) { valid[f.id] = 1; });
  var ids = wb106BatchSelectedIds().filter(function (id) { return valid[id]; });
  if (ids.length !== wb106BatchSelectedIds().length) {
    _WB106.batchSel = {};
    ids.forEach(function (id) { _WB106.batchSel[id] = 1; });
  }
  var n = ids.length;
  var all = bar.querySelector("#wb106-batch-all");
  var countEl = bar.querySelector("#wb106-batch-count");
  var c = bar.querySelector("#wb106-batch-confirm");
  var fp = bar.querySelector("#wb106-batch-fp");
  var clr = bar.querySelector("#wb106-batch-clear");
  if (all) {
    all.checked = pendingList.length > 0 && n === pendingList.length;
    all.indeterminate = n > 0 && n < pendingList.length;
    all.disabled = readonly || pendingList.length === 0;
    all.title = readonly ? "只读：业务管理员不可裁决" : "全选当前筛选下所有待处理问题（本页共 " + pendingList.length + " 条待处理）";
  }
  if (countEl) countEl.textContent = readonly ? "只读不可批量" : ("已选 " + n + " 条");
  [c, fp].forEach(function (b) {
    if (!b) return;
    b.disabled = readonly || n === 0;
    b.title = readonly ? "只读：业务管理员不可裁决"
      : (n === 0 ? "请先勾选要批量处理的问题"
                 : String(b.dataset.baseTitle || "批量裁决") + "（已选 " + n + " 条）");
  });
  if (clr) clr.disabled = readonly || n === 0;
}

function wb106BatchShowResult(r) {
  var box = document.getElementById("wb106-batch-result");
  if (!box) return;
  var label = r.label || "裁决";
  var rows = [];
  (r.succeeded || []).forEach(function (x) {
    rows.push('<div class="wb106-br-row is-ok"><span class="wb106-br-mark">✓</span><span class="wb106-br-title">'
      + esc(x.title || x.finding_id) + '</span><span class="wb106-br-note">已' + esc(label) + "</span></div>");
  });
  (r.skipped || []).forEach(function (x) {
    rows.push('<div class="wb106-br-row is-skip"><span class="wb106-br-mark">⏭</span><span class="wb106-br-title">'
      + esc(x.title || x.finding_id) + '</span><span class="wb106-br-note">跳过：结论已是最新，未重复写审计</span></div>');
  });
  (r.failed || []).forEach(function (x) {
    rows.push('<div class="wb106-br-row is-fail"><span class="wb106-br-mark">✗</span><span class="wb106-br-title">'
      + esc(x.title || x.finding_id) + '</span><span class="wb106-br-note">失败：' + esc(x.error || "") + "</span></div>");
  });
  box.hidden = false;
  box.innerHTML = '<div class="wb106-br-head"><b>批量' + esc(label) + '结果</b>'
    + '<span class="muted">成功 ' + (r.succeeded_count || 0) + " · 跳过 " + (r.skipped_count || 0)
    + " · 失败 " + (r.failed_count || 0) + "</span>"
    + '<button type="button" class="btn wb106-br-close" id="wb106-br-close">收起</button></div>'
    + rows.join("");
  var closeBtn = box.querySelector("#wb106-br-close");
  if (closeBtn) closeBtn.onclick = function () { box.hidden = true; box.innerHTML = ""; };
}

function wb106BatchFeedbackBar(r) {
  var old = document.getElementById("wb106-batch-fb");
  if (old) old.remove();
  var bar = document.createElement("div");
  bar.id = "wb106-batch-fb";
  bar.className = "wb106-feedback wb106-batch-fb";
  bar.setAttribute("role", "status");
  bar.innerHTML = '<span class="wb106-fb-icon" aria-hidden="true">✓</span>'
    + '<span class="wb106-fb-msg">批量' + esc(r.label || "裁决") + "完成：成功 <b>" + (r.succeeded_count || 0)
    + "</b> 条" + ((r.skipped_count || 0) ? " · 跳过 " + r.skipped_count : "")
    + ((r.failed_count || 0) ? " · 失败 " + r.failed_count : "")
    + "（已逐条写审计）</span>"
    + '<span class="wb106-fb-actions">'
    + ((r.succeeded_count || 0) ? '<button type="button" class="btn primary" data-batch-fb="undo">撤销本次批量</button>' : "")
    + '<button type="button" class="btn" data-batch-fb="close">关闭</button></span>';
  if (typeof wbL161PlaceFeedback === "function") wbL161PlaceFeedback(bar);
  else document.body.appendChild(bar);
  bar.querySelectorAll("[data-batch-fb]").forEach(function (b) {
    b.addEventListener("click", function (e) {
      e.preventDefault();
      var act = b.dataset.batchFb;
      if (act === "undo") wb106BatchUndo(r.batch_id, b);
      else bar.remove();
    });
  });
  setTimeout(function () {
    var el = document.getElementById("wb106-batch-fb");
    if (el) el.remove();
  }, 30000);
}

/* L171-3）批量裁决弹层（批量确认/批量误报）：数量 + 影响提示 + 二次确认勾选 + 唯一主操作。
   真实用户点击（isTrusted）走弹层；程序化触发（自动化/嵌入式脚本，isTrusted=false）保留
   原有原生 confirm/prompt 链路，保证既有 E2E 门禁与外部集成不被打断（兼容策略见 L171 报告）。
   无论走哪条路径，最终都收敛到 wb171BatchExecute：逐条写审计、结果条逐条反馈、可撤销。 */
async function wb106BatchDecide(decision, ev) {
  if (_wb106Readonly()) { showToast("只读：业务管理员不可裁决", "err"); return; }
  var ids = wb106BatchSelectedIds();
  if (!ids.length) { showToast("请先勾选要批量处理的问题", "err"); return; }
  if (typeof wbL171BatchOpen === "function" && ev && ev.isTrusted === true) {
    wbL171BatchOpen(decision, ids);
    return;
  }
  // ---- 兼容链路：原生二次确认（自动化/嵌入集成 / 不支持自定义弹层的环境） ----
  var reason = "";
  if (decision === "false_positive") {
    reason = prompt("批量误报：请填写统一原因（必填，将逐条写入审计）", "");
    if (!reason || !reason.trim()) return;
    reason = reason.trim();
  }
  var label = decision === "confirmed" ? "确认问题" : "判为误报";
  var ok = false;
  try {
    ok = confirm("将对已选 " + ids.length + " 条问题批量" + label + "。\n"
      + "· 会逐条落库并写审计（可在结果条中「撤销本次批量」）\n"
      + "· 已被他人改判的问题会跳过，不会覆盖他人结论\n\n"
      + "确认执行批量裁决？");
  } catch (e) { ok = false; }
  if (!ok) return;
  return wb171BatchExecute(decision, reason, ids);
}

/* 批量裁决真实执行（弹层与兼容链路共用）：原来的网络/结果/反馈逻辑，行为不变。 */
async function wb171BatchExecute(decision, reason, ids) {
  ids = (ids || []).map(String).filter(Boolean);
  if (!ids.length) { showToast("请先勾选要批量处理的问题", "err"); return; }
  var label = decision === "confirmed" ? "确认问题" : "判为误报";
  var c = document.getElementById("wb106-batch-confirm");
  var fp = document.getElementById("wb106-batch-fp");
  [c, fp].forEach(function (b) { if (b) b.disabled = true; });
  var r = {};
  try {
    r = await (await fetch("/api/v1/findings/batch-decision", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ finding_ids: ids, decision: decision, reason: reason,
                             expected_status: "pending" }),
    })).json();
  } catch (e) { r = { error: "批量裁决失败：" + String((e && e.message) || e) }; }
  [c, fp].forEach(function (b) { if (b) b.disabled = false; });
  if (!r || r.error || r.ok === false) { showToast((r && r.error) || "批量裁决失败", "err"); return; }
  (r.succeeded || []).forEach(function (x) { var f = _wb106Find(x.finding_id); if (f.id) f.status = x.status; });
  (r.skipped || []).forEach(function (x) { var f = _wb106Find(x.finding_id); if (f.id && x.status) f.status = x.status; });
  _WB106.batchSel = {};
  wb106BatchShowResult(r);
  renderWbFindings();
  _wb106UpdateProgress();
  wb106BatchFeedbackBar(r);
  if (typeof renderWbReportStatus === "function" && (currentWb || _WB106.pid)) {
    try { renderWbReportStatus(currentWb || _WB106.pid); } catch (e) {}
  }
  if (typeof wb106MarkPanels === "function") wb106MarkPanels();
  var msg = "批量" + label + "：成功 " + (r.succeeded_count || 0) + " 条";
  if (r.skipped_count) msg += " · 跳过 " + r.skipped_count;
  if (r.failed_count) msg += " · 失败 " + r.failed_count;
  showToast(msg, r.failed_count ? "err" : "ok");
  return r;
}

async function wb106BatchUndo(batchId, btn) {
  if (!batchId) { showToast("没有可撤销的批量操作", "err"); return; }
  var ok = false;
  try {
    ok = confirm("撤销本次批量裁决？\n· 只恢复仍保持本次批量结论的问题\n"
      + "· 已被他人改判的问题不会被覆盖\n· 撤销动作会写审计");
  } catch (e) { ok = false; }
  if (!ok) return;
  if (btn) btn.disabled = true;
  var r = {};
  try {
    r = await (await fetch("/api/v1/findings/batch-undo", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ batch_id: batchId }),
    })).json();
  } catch (e) { r = { error: "撤销失败：" + String((e && e.message) || e) }; }
  if (btn) btn.disabled = false;
  if (!r || r.error || r.ok === false) { showToast((r && r.error) || "撤销失败", "err"); return; }
  (r.restored || []).forEach(function (x) { var f = _wb106Find(x.finding_id); if (f.id) f.status = x.status; });
  var old = document.getElementById("wb106-batch-fb");
  if (old) old.remove();
  var box = document.getElementById("wb106-batch-result");
  if (box && !box.hidden) {
    box.innerHTML = '<div class="wb106-br-head"><b>批量已撤销</b><span class="muted">恢复 '
      + (r.restored_count || 0) + " 条 · 跳过 " + (r.skipped_count || 0) + "</span></div>"
      + (r.restored || []).map(function (x) {
        return '<div class="wb106-br-row is-skip"><span class="wb106-br-mark">↩</span><span class="wb106-br-title">'
          + esc(x.title || x.finding_id) + '</span><span class="wb106-br-note">已恢复为待处理</span></div>';
      }).join("");
  }
  renderWbFindings();
  _wb106UpdateProgress();
  if (typeof renderWbReportStatus === "function" && (currentWb || _WB106.pid)) {
    try { renderWbReportStatus(currentWb || _WB106.pid); } catch (e) {}
  }
  showToast("已撤销本次批量：" + (r.restored_count || 0) + " 条恢复为待处理"
    + ((r.skipped_count || 0) ? "，跳过 " + r.skipped_count + " 条（已被改判）" : ""));
}

function _wb106Explain(btn) {
  var reason = String((btn && btn.dataset && btn.dataset.reason) || "");
  if (!reason) reason = String((btn && btn.title) || "该操作当前不可用");
  if (typeof showToast === "function") showToast(reason, "err");
  else alert(reason);
}

/* 队列入口状态：无数据/只读/锁定/读取失败都保持按钮可见，只禁用并显示原因 */
function _wb106RenderQueueState() {
  var addBtn = document.getElementById("wb106-btn-add");
  var hidBtn = document.getElementById("wb106-btn-hidden");
  var hint = _wb106First("#view-workbench .wb106-q-hint");
  var readonly = _wb106Readonly();
  var ctx = _WB106.ctx || {};
  var addReason = "";
  if (readonly) addReason = "只读：业务管理员不可新增问题（可查看问题/证据/报告状态）";
  else if (ctx.loading) addReason = "项目仍在加载，加载完成后可新增";
  else if (ctx.error) addReason = "项目数据加载失败，暂不能新增：" + ctx.error;
  if (addBtn) {
    addBtn.disabled = !!addReason;
    addBtn.title = addReason || "记录规则未审出、但审核员认为存在的问题；提交后进入待复核队列（漏报信号）";
    addBtn.dataset.reason = addReason;
    addBtn.textContent = "＋新增问题";   // T-106：入口文案固定，不可用原因在 title/提示行说明
  }
  var hiddenReason = "";
  var hidden = _WB106.hidden;
  if (hidBtn) {
    var label = "其他疑似问题 (—)";
    if (_WB106.hiddenLoading && !hidden) { hiddenReason = "其他疑似问题数量加载中…"; }
    else if (!hidden) { hiddenReason = "其他疑似问题数量读取中…"; }
    else if (hidden.error) { hiddenReason = "其他疑似问题读取失败：" + hidden.error; }
    else {
      var info = hidden.hidden || hidden;
      var count = info.count;
      var countText = (count === null || count === undefined) ? "—" : String(count);
      // E-09：count 可能是接口字符串/缺字段；统一数字归一，0 条必须禁用入口，
      // 数量不可用也不能保持可点（点开只看到空面板 = DuMate 记录的体验问题）。
      var countNum = (count === null || count === undefined) ? NaN : Number(count);
      var countKnown = isFinite(countNum);
      var locked = !!hidden.locked;
      var open = _WB_HIDDEN.open && _WB_HIDDEN.pid === String(_WB106.pid);
      /* T-203：同一入口同时反映「隐藏项 + 影子池」两个独立区（影子池为超集语义）。
         N = 隐藏项 N + 影子池待裁决 N；影子池数量来自 GET /shadow-items（默认只给 N）。
         影子池读取失败不影响隐藏项口径（分开降级，不把两个区混成一个数）。 */
      var shadowN = (typeof _wbShadowCount === "function") ? _wbShadowCount() : null;
      if (shadowN === null && _WB_SHADOW && _WB_SHADOW.loading) shadowN = 0;
      var shadowKnown = (shadowN === null || shadowN === undefined) ? false : true;
      if (readonly) shadowKnown = false;      // P2-4：业务管理员只读不暴露任何数量
      var shadowNum = shadowKnown ? Number(shadowN) : 0;
      var totalNum = (countKnown ? countNum : 0) + shadowNum;
      var totalKnown = countKnown || shadowKnown;
      var totalText = totalKnown ? String(totalNum) : "—";
      if (open) label = "关闭其他疑似问题";
      else if (locked) label = "其他疑似问题（提交独立复核后可用）";
      // P2-4：业务管理员只读时不显示数量 N（数量也是信息，只读口径=内容与数量都不展示）。
      else if (readonly) label = "其他疑似问题（业务管理员只读）";
      else label = "其他疑似问题 (" + totalText + ")";
      if (locked) hiddenReason = String(hidden.lock_reason || info.lock_reason || "评测/盲审模式：提交独立复核前不显示隐藏项数量与内容");
      else if (readonly) hiddenReason = "只读：业务管理员不可打开隐藏池（内容与数量均不展示）";
      else if (!open && totalKnown && totalNum === 0) hiddenReason = "当前没有待裁决的其他疑似问题（0 条）";
      else if (!open && !totalKnown) hiddenReason = "其他疑似问题数量不可用，暂不可打开";
      if (!hiddenReason && !open && totalKnown && totalNum > 0) {
        /* 数量拆分只做说明（不改变启停）；影子池为超集，隐藏项是其子集的一部分。 */
        var _split = "隐藏项 " + (countKnown ? countText : "—") + " · 影子池 "
          + (shadowKnown ? String(shadowNum) : "—");
        hidBtn.dataset.split = _split;
      }
    }
    hidBtn.disabled = !!hiddenReason;
    hidBtn.setAttribute("aria-disabled", hiddenReason ? "true" : "false");
    hidBtn.title = hiddenReason || "隐藏项默认关闭；里面既可能是误报，也可能是真问题；打开需二次确认并写审计，打开后仍需逐条裁决";
    hidBtn.dataset.reason = hiddenReason;
    hidBtn.textContent = label;
    hidBtn.classList.toggle("is-open", !!(_WB_HIDDEN.open && _WB_HIDDEN.pid === String(_WB106.pid)));
  }
  if (hint) {
    var parts = [];
    if (readonly) parts.push("只读模式：业务管理员可查看问题/证据/报告状态，不可裁决、新增或打开隐藏池");
    if (addReason && !readonly) parts.push(addReason);
    if (hiddenReason && !readonly) parts.push(hiddenReason);
    if (ctx.loading) parts.push("正在加载项目数据…");
    hint.textContent = parts.join(" · ");
    hint.hidden = !parts.length;
  }
  if (typeof wb106BatchUpdateBar === "function") wb106BatchUpdateBar();
  wb106MarkPanels();
}

async function wb106RefreshHidden(pid) {
  pid = String(pid || _WB106.pid || "");
  if (!pid) return;
  _WB106.hiddenLoading = true;
  _wb106RenderQueueState();
  var out = null;
  try {
    var resp = await fetch("/api/v1/projects/" + encodeURIComponent(pid) + "/hidden-items");
    out = await resp.json();
    if (resp.status === 404 || resp.status === 401) out = { error: "项目不存在或无权限（HTTP " + resp.status + "）" };
  } catch (e) {
    out = { error: "网络错误：" + String((e && e.message) || e) };
  }
  if (String(_WB106.pid) !== String(pid)) return;
  if (out && (out.ok === false || out.error)) {
    _WB106.hidden = { error: String(out.error || out.message || "读取失败") };
  } else {
    _WB106.hidden = out || { error: "接口未返回有效数据" };
  }
  _WB106.hiddenLoading = false;
  _wb106RenderQueueState();
}

async function _wb106ToggleHidden() {
  var pid = _WB106.pid || currentWb;
  if (!pid) return;
  if (_WB_HIDDEN.open && _WB_HIDDEN.pid === String(pid)) {
    _wbHiddenClose(pid);
    _wb106RenderQueueState();
    if (typeof loadWbHumanLoop === "function") { try { await loadWbHumanLoop(pid); } catch (e) {} }
    return;
  }
  var btn = document.getElementById("wb106-btn-hidden");
  if (btn) { btn.disabled = true; btn.textContent = "打开中…"; }
  try { await _wbHiddenToggle(pid, btn); } catch (e) { showToast("隐藏区打开失败：" + String((e && e.message) || e), "err"); }
  _wb106RenderQueueState();
  if (_WB_HIDDEN.open && _WB_HIDDEN.pid === String(pid)) {
    var panel = document.getElementById("wb-hidden-panel");
    if (panel) { try { panel.scrollIntoView({ block: "start", behavior: "smooth" }); } catch (e) {} }
  }
}

/* -------- 3) 问题卡：固定五个按钮；只读/已裁决禁用且给原因 -------- */
function _wb106DisabledReason(f, readonly) {
  if (readonly) return "只读：业务管理员不可裁决；可用「更多」查看定位/证据";
  if (String(f.status || "pending") !== "pending") {
    var label = _WB106_STATUS_LABEL[f.status] || "已裁决";
    return label + "：如需变更结论，请用「更多 → 改判」";
  }
  return "";
}

function _wb106SaveLabel(decision) {
  return { confirmed: "确认问题", false_positive: "确认误报",
           need_evidence: "确认退回补证", ignored: "确认忽略" }[decision] || "确认";
}

function _wb106CardButton(decision, label, primary, disabled, reason, fid) {
  var cls = "btn" + (primary && !disabled ? " primary" : "") + " wb106-decide-btn";
  var attr = disabled ? 'data-wb106-decide="' + esc(decision) + '"'
    : 'data-act="' + esc(decision) + '" data-wb106-decide="' + esc(decision) + '"';
  /* L171：主操作唯一化——卡片行内「确认」保留 .btn.primary 类（L161 D1 / L103 契约），
     但视觉降级为次级描边按钮（style.css L171 段）；同屏唯一填充主操作是吸底「确认问题」。
     data-wb171-* 只做机读标记，不改变任何既有选择器。 */
  var l171 = decision === "confirmed"
    ? ' data-wb171-primary-role="card" data-wb171-primary-label="确认"'
    : ' data-wb171-secondary="1"';
  return '<button type="button" class="' + cls + '" ' + attr
    + (disabled ? ' disabled aria-disabled="true"' : "")
    + ' title="' + esc(disabled ? reason : (_WB106_ACTION_HINT[decision] || label)) + '"'
    + ' data-fid="' + esc(fid) + '"' + l171 + ">" + esc(label) + "</button>";
}

function wb106FindingCard(f) {
  var readonly = _wb106Readonly();
  var sev = String(f.severity || "warning");
  var sevMeta = _WB106_SEV[sev] || _WB106_SEV.warning;
  var status = String(f.status || "pending");
  var done = status !== "pending";
  var statusLabel = _WB106_STATUS_LABEL[status] || status;
  var locs = (f.evidence || []).map(function (a) { return a.locator || a.sheet || ""; }).filter(Boolean);
  var quote = ((f.evidence || [])[0] || {}).quote || "";
  var isManual = String(f.engine || "").toLowerCase() === "manual";
  var reason = _wb106DisabledReason(f, readonly);
  var disabled = readonly || done;
  var basis = f.rule_name || f.rule_code || (isManual ? "人工录入" : "—");
  var basisTail = (f.rule_name && f.rule_code) ? " · " + f.rule_code : "";
  var locText = locs.length ? "位置：" + [...new Set(locs)].slice(0, 2).join(" · ") : "未记录位置";
  var moreTitle = readonly ? "更多（只读：可定位原文/查看证据链）" : "更多操作：定位/证据/编辑/改判";
  // P2-2：批量选择复选框（只读角色不渲染；已裁决项禁用并给原因）。
  var batchCb = "";
  if (!readonly) {
    var _checked = (_WB106.batchSel && _WB106.batchSel[f.id]) ? " checked" : "";
    batchCb = '<input type="checkbox" class="wb106-batch-cb" data-fid="' + esc(f.id) + '"'
      + _checked
      + (done ? ' disabled aria-disabled="true" title="已裁决：不参与批量（逐条改判请用「更多」）"'
              : ' title="勾选后可批量确认/批量误报（队列标题旁有「本页全选」）"')
      + ' aria-label="选择问题：' + esc(f.title || f.id) + '">';
  }
  return '<div class="fcard wb106-card" data-fid="' + esc(f.id) + '" data-status="' + esc(status) + '">'
    + '<div class="fc-head">'
    + batchCb
    + '<span class="pill ' + sevMeta[1] + '">' + esc(sevMeta[0]) + "</span>"
    + (isManual ? '<span class="pill draft">人工新增</span>' : "")
    + '<span class="wb106-status is-' + esc(status) + '">' + esc(statusLabel) + "</span>"
    + '<span class="fc-title">' + esc(f.title || "（无标题）") + "</span>"
    + "</div>"
    + '<div class="fc-basis wb106-basis"><span>判定依据</span>' + esc(basis) + esc(basisTail)
    + '<span class="wb106-loc">' + esc(locText) + "</span></div>"
    + '<div class="fc-desc"><span>问题</span>' + esc(f.summary || f.title || "（无问题描述）") + "</div>"
    + (quote ? '<div class="fc-basis fc-evidence" data-evidence="' + esc(f.id) + '" title="查看证据链/补充材料"><span>原文</span>' + esc(String(quote).slice(0, 160)) + "</div>" : "")
    + '<div class="fc-tools">'
    + '<span class="muted fc-loc wb106-tools-loc">' + (f._historical ? "历史轮次待处理" : (done ? "已裁决，可改判" : "待裁决")) + "</span>"
    + '<span class="fc-decisions wb106-decisions wb161-actions wb171-actions">'
    + '<span class="wb161-act-group wb161-act-ok wb171-act-ok">'
    + _wb106CardButton("confirmed", "确认", true, disabled, reason, f.id)
    + "</span>"
    + '<span class="wb161-group-sep" aria-hidden="true"></span>'
    + '<span class="wb161-act-group wb161-act-alt wb171-act-alt">'
    + _wb106CardButton("false_positive", "误报", false, disabled, reason, f.id)
    + _wb106CardButton("need_evidence", "退回补证", false, disabled, reason, f.id)
    + _wb106CardButton("ignored", "忽略", false, disabled, reason, f.id)
    + "</span>"
    + '<button type="button" class="btn wb106-more-btn" data-wb106-more="1" data-fid="' + esc(f.id) + '" title="' + esc(moreTitle) + '">更多 ▾</button>'
    + "</span></div>"
    + (reason ? '<div class="wb106-card-reason">' + esc(reason) + "</div>" : "")
    + "</div>";
}

/* 事件委托：卡片由 innerHTML 动态渲染，委托避免重复绑定/动态插入后失效 */
function wb106EnsureDelegation() {
  if (_WB106.delegated) return;
  var root = document.getElementById("view-workbench");
  if (!root) return;
  _WB106.delegated = true;
  root.addEventListener("click", function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var more = t.closest("[data-wb106-more]");
    if (more && t.closest("#wb-findings")) {
      e.preventDefault(); e.stopPropagation();
      wb106OpenMoreMenu(more);
      return;
    }
    var dec = t.closest("[data-wb106-decide]");
    if (dec && dec.closest("#wb-findings")) {
      e.preventDefault();
      if (dec.disabled) return;
      var card = dec.closest(".fcard");
      wb106Decide(card ? card.dataset.fid : dec.dataset.fid, dec.dataset.wb106Decide);
      return;
    }
  });
  root.addEventListener("change", function (e) {
    var cb = e.target;
    if (!cb || !cb.classList || !cb.classList.contains("wb106-batch-cb")) return;
    var fid = String(cb.dataset.fid || "");
    if (!fid) return;
    _WB106.batchSel = _WB106.batchSel || {};
    if (cb.checked) _WB106.batchSel[fid] = 1; else delete _WB106.batchSel[fid];
    wb106BatchUpdateBar();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") wb106CloseMoreMenu();
  });
}

/* -------- 4) 「更多」菜单：定位/证据/编辑/改判（只读仅保留只读项） -------- */
function wb106CloseMoreMenu() {
  var old = document.getElementById("wb106-more-menu");
  if (old) old.remove();
  var mask = document.getElementById("wb106-more-mask");
  if (mask) mask.remove();
  _WB106.moreMenu = null;
}

function wb106OpenMoreMenu(btn) {
  wb106CloseMoreMenu();
  var fid = btn.dataset.fid || (btn.closest(".fcard") || {}).dataset.fid || "";
  var f = _wb106Find(fid);
  var readonly = _wb106Readonly();
  var hasEvidence = (f.evidence || []).length > 0;
  var done = String(f.status || "pending") !== "pending";
  var items = [
    { key: "locate", label: "定位原文", hint: "在文档预览中定位该问题的证据位置", disabled: false },
    { key: "evidence", label: "查看证据链", hint: hasEvidence ? "查看逐字引文与判定链" : "该问题暂无结构化证据", disabled: !hasEvidence },
    { key: "edit", label: "编辑问题", hint: readonly ? "只读：业务管理员不可编辑问题" : "修改问题标题/严重度/描述（不改变复核状态）", disabled: readonly },
    { key: "redecide", label: done ? "改判…" : "改判（尚未裁决）", hint: done ? "重新裁决并覆盖当前结论（写审计）" : "尚未裁决，直接点问题卡上的结论按钮", disabled: readonly || !done },
    { key: "copy", label: "复制问题标题", hint: "复制标题用于沟通/记录", disabled: false }
  ];
  var mask = document.createElement("div");
  mask.id = "wb106-more-mask";
  mask.className = "wb106-more-mask";
  mask.addEventListener("click", wb106CloseMoreMenu);
  document.body.appendChild(mask);
  var menu = document.createElement("div");
  menu.id = "wb106-more-menu";
  menu.className = "wb106-more-menu";
  menu.setAttribute("role", "menu");
  menu.innerHTML = '<div class="wb106-more-title" title="' + esc(f.title || "") + '">' + esc(String(f.title || "问题操作").slice(0, 26)) + "</div>"
    + items.map(function (it) {
      return '<button type="button" class="wb106-more-item' + (it.disabled ? " is-disabled" : "") + '"'
        + ' data-wb106-menu="' + it.key + '"' + (it.disabled ? ' aria-disabled="true"' : "")
        + ' title="' + esc(it.hint) + '">' + esc(it.label) + '<span class="wb106-more-hint">' + esc(it.hint) + "</span></button>";
    }).join("");
  document.body.appendChild(menu);
  var rect = btn.getBoundingClientRect();
  var mw = 268;
  var vw = window.innerWidth || 0, vh = window.innerHeight || 0;
  var left = Math.max(8, Math.min(rect.left + rect.width - mw, vw - mw - 8));
  // L161：按真实菜单高度决定向上/向下展开并夹到视口内，卡片在视口底部时菜单不再越界。
  var mh = Math.max(120, Math.round(menu.getBoundingClientRect().height || 280));
  var gap = 4;
  var top = rect.bottom + gap;
  if (top + mh + 8 > vh) top = rect.top - gap - mh;
  top = Math.max(8, Math.min(top, Math.max(8, vh - mh - 8)));
  menu.style.left = Math.round(left) + "px";
  menu.style.top = Math.round(top) + "px";
  _WB106.moreMenu = menu;
  menu.querySelectorAll("[data-wb106-menu]").forEach(function (b) {
    b.addEventListener("click", function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      if (b.classList.contains("is-disabled")) {
        var hint = String(b.title || "该操作当前不可用");
        wb106CloseMoreMenu();
        showToast(hint, "err");
        return;
      }
      wb106MoreAction(b.dataset.wb106Menu, fid);
    });
  });
}

function wb106MoreAction(key, fid) {
  var f = _wb106Find(fid);
  wb106CloseMoreMenu();
  if (key === "locate") {
    if (typeof locateFinding === "function") locateFinding(fid);
    else showToast("定位功能不可用", "err");
    return;
  }
  if (key === "evidence") {
    if (typeof openEvidenceView === "function") openEvidenceView(fid);
    else showToast("证据查看不可用", "err");
    return;
  }
  if (key === "edit") {
    if (_wb106Readonly()) { showToast("只读：业务管理员不可编辑问题", "err"); return; }
    if (typeof openWbEdit === "function") openWbEdit(fid);
    else showToast("编辑功能不可用", "err");
    return;
  }
  if (key === "redecide") {
    if (_wb106Readonly()) { showToast("只读：业务管理员不可裁决", "err"); return; }
    if (String(f.status || "pending") === "pending") { showToast("尚未裁决，请直接点问题卡上的结论按钮", "err"); return; }
    wb106Decide(fid, "");
    return;
  }
  if (key === "copy") {
    var text = String(f.title || "");
    var done = false;
    try { navigator.clipboard.writeText(text); done = true; } catch (e) { done = false; }
    if (!done) {
      try {
        var ta = document.createElement("textarea");
        ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); done = true;
      } catch (e2) { done = false; }
    }
    showToast(done ? "已复制问题标题" : "复制失败，请手动选择标题", done ? "ok" : "err");
  }
}

/* -------- 5) 裁决弹窗：主操作唯一 primary；可撤销未提交操作 -------- */
function wb106Decide(fid, decision) {
  var f = _wb106Find(fid);
  if (!f.id) { showToast("问题不存在或已刷新，请重新加载", "err"); return; }
  if (_wb106Readonly()) { showToast("只读：业务管理员不可裁决", "err"); return; }
  var _prevFocus = null;
  try { _prevFocus = document.activeElement; } catch (e) {}
  var old = document.getElementById("wb-decision-modal");
  if (old) {
    try { if (typeof _WB161 !== "undefined" && _WB161.modalCleanup) _WB161.modalCleanup(); } catch (e) {}
    old.remove();
  }
  var isRedecide = !decision;
  var current = String(f.status || "pending");
  decision = decision || (current !== "pending" ? "confirmed" : "confirmed");
  var label = _WB106_ACTION_LABEL[decision] || decision;
  var title = _WB106_DECISION_TITLE[decision] || label;
  var noteText = decision === "false_positive"
    ? "请说明为什么是误报；原因会进入规则进化反馈。"
    : decision === "need_evidence"
      ? "退回补证：问题可能成立但现有证据不足，要求补充材料后才继续复核；它不删除问题、也不修改问题描述。"
      : decision === "ignored"
        ? "忽略不会删除问题，仍保留记录；忽略和退回补证是两种不同处理。"
        : "确认表示该问题成立，会进入已复核；原因可选填。";
  var reasonRequired = decision !== "confirmed";
  var decisionOptions = isRedecide
    ? '<label class="wb106-decide-select"><span>新结论 <em class="req">*</em></span><select id="wdm-decision" class="field">'
      + _WB106_DECISION_ORDER.map(function (d) {
        return '<option value="' + d + '"' + (d === decision ? " selected" : "") + ">" + esc(_WB106_DECISION_TITLE[d]) + "</option>";
      }).join("") + "</select></label>"
    : "";
  var mask = document.createElement("div");
  mask.id = "wb-decision-modal";
  mask.className = "modal-mask";
  mask.innerHTML = '<div class="modal wb106-decision-modal" style="width:min(560px,calc(100vw - 24px))" role="dialog" aria-modal="true">'
    + '<div class="settings-head"><h3 id="wdm-title">' + esc(isRedecide ? "改判问题" : title) + "</h3>"
    + '<button type="button" class="ws-close" data-wdm-close aria-label="关闭（撤销）">×</button></div>'
    + '<div class="dm-problem">' + esc(f.title || "当前问题") + "</div>"
    + '<div class="wb106-decision-status">当前状态：<b>' + esc(_WB106_STATUS_LABEL[current] || current) + "</b>"
    + (isRedecide ? " · 改判会覆盖当前结论并写审计" : "") + "</div>"
    + decisionOptions
    + '<div class="dm-note">' + esc(noteText) + "</div>"
    + '<textarea id="wdm-reason" class="field" style="width:100%;min-height:88px" placeholder="请填写原因' + (reasonRequired ? "（必填）" : "（可选）") + '"></textarea>'
    + '<div id="wdm-msg" class="muted" style="font-size:11px;margin-top:6px" role="alert"></div>'
    + '<div class="actions wb106-decision-actions">'
    + '<button type="button" class="btn" data-wdm-close>撤销</button>'
    + '<button type="button" class="btn primary" id="wdm-save">' + esc(_wb106SaveLabel(decision)) + "</button>"
    + "</div></div>";
  document.body.appendChild(mask);
  var _modalClosed = false;
  var _onModalKey = function (e) {
    if (_modalClosed) return;
    if (typeof KeyboardEvent !== "undefined" && !(e instanceof KeyboardEvent)) return;
    var k = String(e.key || "");
    if (k === "Escape") { e.preventDefault(); e.stopPropagation(); close(); return; }
    if (k !== "Tab") return;
    // L161：焦点陷阱——Tab/Shift+Tab 只在弹窗内循环，避免焦点跑到遮罩后面的页面
    var nodes = Array.prototype.slice.call(
      mask.querySelectorAll('button, textarea, select, input, a[href], [tabindex]:not([tabindex="-1"])'))
      .filter(function (el) { return !el.disabled && el.offsetParent !== null; });
    if (!nodes.length) return;
    var first = nodes[0], last = nodes[nodes.length - 1], active = document.activeElement;
    if (e.shiftKey) {
      if (active === first || !mask.contains(active)) { e.preventDefault(); last.focus(); }
    } else if (active === last || !mask.contains(active)) { e.preventDefault(); first.focus(); }
  };
  var close = function () {
    if (_modalClosed) return;
    _modalClosed = true;
    try { document.removeEventListener("keydown", _onModalKey, true); } catch (e) {}
    try { mask.remove(); } catch (e) {}
    try { if (typeof _WB161 !== "undefined") _WB161.modalCleanup = null; } catch (e) {}
    // L161：撤销/Tab 关闭后焦点不能掉到 BODY，回到触发按钮或当前问题卡
    try {
      var target = _prevFocus;
      if (!target || target === document.body || !document.contains(target)) {
        target = document.querySelector("#wb-findings .fcard.wb-l103-selected")
          || document.querySelector('#wb-findings .fcard[data-fid="'
              + String(fid).replace(/"/g, '\\"') + '"]')
          || document.getElementById("wb106-btn-add");
      }
      if (target && target.focus) {
        if (!target.hasAttribute("tabindex") && !/^(BUTTON|INPUT|TEXTAREA|SELECT|A)$/.test(target.tagName || "")) {
          target.setAttribute("tabindex", "-1");
        }
        target.focus({ preventScroll: true });
      }
    } catch (e) {}
  };
  try {
    if (typeof _WB161 !== "undefined") {
      _WB161.modalCleanup = function () {
        _modalClosed = true;
        try { document.removeEventListener("keydown", _onModalKey, true); } catch (e) {}
      };
    }
  } catch (e) {}
  document.addEventListener("keydown", _onModalKey, true);
  mask.querySelectorAll("[data-wdm-close]").forEach(function (x) { x.onclick = close; });
  mask.onclick = function (e) { if (e.target === mask) close(); };
  var sel = mask.querySelector("#wdm-decision");
  var save = mask.querySelector("#wdm-save");
  if (sel) {
    sel.addEventListener("change", function () {
      decision = sel.value;
      label = _WB106_ACTION_LABEL[decision] || decision;
      title = _WB106_DECISION_TITLE[decision] || label;
      reasonRequired = decision !== "confirmed";
      var t = mask.querySelector("#wdm-title"); if (t) t.textContent = "改判 · " + title;
      save.textContent = _wb106SaveLabel(decision);
      var note = mask.querySelector(".dm-note");
      if (note) note.textContent = decision === "false_positive" ? "请说明为什么是误报；原因会进入规则进化反馈。"
        : decision === "need_evidence" ? "退回补证：问题可能成立但现有证据不足；不删除问题、不修改描述。"
          : decision === "ignored" ? "忽略不会删除问题，仍保留记录；忽略和退回补证是两种不同处理。"
            : "确认表示该问题成立，会进入已复核；原因可选填。";
      var ta = mask.querySelector("#wdm-reason");
      if (ta) ta.placeholder = "请填写原因" + (reasonRequired ? "（必填）" : "（可选）");
    });
  }
  var reasonEl = mask.querySelector("#wdm-reason");
  if (reasonEl) reasonEl.focus();
  save.onclick = async function () {
    var reason = String((reasonEl && reasonEl.value) || "").trim();
    var msg = mask.querySelector("#wdm-msg");
    if (reasonRequired && !reason) { if (msg) msg.textContent = "请填写原因（" + label + "需要说明理由）"; return; }
    save.disabled = true; save.textContent = "提交中…";
    var r = {};
    var httpStatus = 200;
    try {
      var resp = await fetch("/api/v1/findings/" + encodeURIComponent(fid) + "/decision", {
        method: "POST", headers: { "Content-Type": "application/json" },
        // P1-4：携带打开弹窗时看到的结论状态；期间被他人改判 → 服务端 409 冲突。
        body: JSON.stringify({ decision: decision, reason: reason, expected_status: current })
      });
      httpStatus = resp.status;
      r = await resp.json();
    } catch (e) { r = { error: "网络错误：" + String((e && e.message) || e) }; }
    // P1-4：并发冲突（409）必须提示当前真实结论，不能静默覆盖或假装成功。
    if (httpStatus === 409 || (r && r.code === "decision_conflict")) {
      save.disabled = false; save.textContent = _wb106SaveLabel(decision);
      var cur = (r && r.current) || {};
      var curLabel = cur.label || _WB106_STATUS_LABEL[cur.status] || cur.status || "未知";
      if (msg) {
        msg.textContent = "裁决冲突：该问题已被" + (cur.actor ? "「" + cur.actor + "」" : "他人")
          + "改为「" + curLabel + "」，本次未写入。请关闭弹窗后刷新，按当前结论重新裁决。";
      }
      var oldBar = document.getElementById("wb106-feedback");
      if (oldBar) oldBar.remove();
      showToast("裁决冲突：当前结论已是「" + curLabel + "」，未覆盖他人结论", "err");
      return;
    }
    if (!r || r.error || r.ok === false) {
      save.disabled = false; save.textContent = _wb106SaveLabel(decision);
      var _err = String((r && r.error) || "裁决提交失败，请稍后重试");
      if (r && r.code === "reason_required") {
        _err = "服务端要求填写原因：" + _err;
        try { if (reasonEl) reasonEl.focus(); } catch (e) {}
      }
      if (msg) msg.textContent = _err;
      else if (typeof showToast === "function") showToast(_err, "err");
      return;
    }
    close();
    if (r.idempotent) {
      showToast("该结论此前已提交（幂等：未重复写审计）");
    }
    _wb106AfterDecision(fid, decision);
  };
}

function _wb106AfterDecision(fid, decision) {
  var f = _wb106Find(fid);
  var label = _WB106_STATUS_LABEL[decision] || decision;
  if (f.id) { f.status = decision; }
  var box = document.getElementById("wb-findings");
  var top = box ? box.scrollTop : 0;
  renderWbFindings();
  var box2 = document.getElementById("wb-findings");
  if (box2) box2.scrollTop = top;
  _wb106UpdateProgress();
  wb106FeedbackBar(fid, decision, label);
  // P2-6：保存后焦点不能掉到 BODY（键盘用户丢失位置）→ 回到原问题卡。
  try {
    var card = document.querySelector('#wb-findings .fcard[data-fid="' + String(fid).replace(/"/g, '\\"') + '"]');
    if (card) {
      card.setAttribute("tabindex", "-1");
      card.classList.add("wb106-flash");
      card.focus({ preventScroll: true });
      setTimeout(function () { card.classList.remove("wb106-flash"); }, 1400);
    } else {
      var next = document.querySelector('#wb106-feedback [data-wb106-fb="next"]');
      if (next) next.focus({ preventScroll: true });
    }
  } catch (e) { /* 焦点恢复失败不阻断主流程 */ }
  if (typeof renderWbReportStatus === "function" && (currentWb || _WB106.pid)) {
    try { renderWbReportStatus(currentWb || _WB106.pid); } catch (e) {}
  }
  if (typeof wb106MarkPanels === "function") wb106MarkPanels();
}

function _wb106UpdateProgress() {
  var total = (wbFindings || []).length;
  var pending = (wbFindings || []).filter(function (f) { return String(f.status || "pending") === "pending"; }).length;
  var el = document.getElementById("wb-progress");
  if (el) el.textContent = "已复核 " + (total - pending) + "/" + total;
}

/* 裁决反馈条：结果确认 + 下一条 + 改判 + 关闭（撤销未提交操作在弹窗内） */
function wb106FeedbackBar(fid, decision, label) {
  var old = document.getElementById("wb106-feedback");
  if (old) old.remove();
  clearTimeout(_WB106.fbTimer);
  var f = _wb106Find(fid);
  var bar = document.createElement("div");
  bar.id = "wb106-feedback";
  bar.className = "wb106-feedback";
  bar.setAttribute("role", "status");
  bar.setAttribute("aria-live", "polite");
  bar.innerHTML = '<span class="wb106-fb-icon" aria-hidden="true">✓</span>'
    + '<span class="wb106-fb-msg">已记录：<b>' + esc(label || decision) + "</b> · " + esc(String(f.title || "").slice(0, 40)) + "</span>"
    + '<span class="wb106-fb-actions">'
    + '<button type="button" class="btn primary" data-wb106-fb="next">下一条</button>'
    + '<button type="button" class="btn" data-wb106-fb="redecide" title="重新裁决并覆盖当前结论">改判</button>'
    + '<button type="button" class="btn" data-wb106-fb="close">关闭</button>'
    + "</span>";
  if (typeof wbL161PlaceFeedback === "function") wbL161PlaceFeedback(bar);
  else document.body.appendChild(bar);
  bar.querySelectorAll("[data-wb106-fb]").forEach(function (b) {
    b.addEventListener("click", function (e) {
      e.preventDefault();
      var act = b.dataset.wb106Fb;
      if (act === "next") { wb106NextPending(fid); bar.remove(); }
      else if (act === "redecide") { bar.remove(); wb106Decide(fid, ""); }
      else { bar.remove(); }
    });
  });
  _WB106.fbTimer = setTimeout(function () {
    var el = document.getElementById("wb106-feedback");
    if (el) el.remove();
  }, 12000);
}

function wb106NextPending(fid) {
  var cards = Array.prototype.slice.call(document.querySelectorAll('#wb-findings .fcard[data-status="pending"]'));
  if (!cards.length) { showToast("没有下一条待处理问题（当前筛选下已全部处理）", "ok"); return; }
  var idx = -1;
  cards.forEach(function (c, i) { if (String(c.dataset.fid) === String(fid)) idx = i; });
  var card = idx >= 0 ? cards[(idx + 1) % cards.length] : cards[0];
  // L161：「下一条」直接选中下一条（详情/吸底同步），少一次点击；失败则退回滚动高亮。
  var _selected = false;
  try { _selected = (typeof wbL161SelectNext === "function") ? !!wbL161SelectNext(card) : false; } catch (e) {}
  if (!_selected) {
    try { card.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (e) {}
  }
  card.classList.add("wb106-flash");
  setTimeout(function () { card.classList.remove("wb106-flash"); }, 1400);
  showToast(_selected ? "已选中下一条待处理问题" : "已跳到下一条待处理问题", "ok");
}

/* ===================== L84 E3：双轨 V3.2 数据 UI 接线（抑制台账 / 隐藏项指标） =====================
   服务端同源（与 CLI `rp ledger list` / `rp hidden-item metrics` 同一批服务函数；不改后端）：
   - GET  /api/v1/suppression-ledger[?case=&status=]  抑制台账（业务管理员完整只读；审核员脱敏只读）
   - POST /api/v1/suppression-ledger/{id}/recover     人工恢复（必须填原因；写审计 + 写回 finding）
   - GET  /api/v1/hidden-metrics[?case=]              隐藏项指标（管理员本租户汇总；审核员本人项目）
   口径（与服务层一致，不夸大）：
   - 抑制≠删除：台账行永久保留，恢复只把 visibility_status 改为 recovered 并写回 finding；
   - 恢复仅项目审核员：业务管理员只读（服务层 403），审核员非本人项目 403，原因必填（400 reason_required）；
   - 空态如实展示“没有记录”，不把 0 条说成“已核验无误报”，也不渲染任何假数据。 */
var _WB_V32 = { pid: "", kind: "" };

function _wbV32Api(url, opts) {
  var init = Object.assign({ credentials: "same-origin" }, opts || {});
  if (init.body && typeof init.body !== "string") {
    init.headers = Object.assign({ "Content-Type": "application/json" }, init.headers || {});
    init.body = JSON.stringify(init.body);
  }
  return fetch(url, init).then(async function (resp) {
    var data = null;
    try { data = await resp.json(); } catch (e) { data = null; }
    return { status: resp.status, ok: resp.ok, data: data };
  }).catch(function (e) {
    return { status: 0, ok: false, error: String((e && e.message) || e) };
  });
}

function wbV32Mount(pid) {
  var host = document.getElementById("wb-v32-tools");
  if (!host) {
    host = document.createElement("div");
    host.id = "wb-v32-tools";
    host.className = "wb-v32-tools";
    host.style.cssText = "display:flex;gap:8px;flex-wrap:wrap;align-items:center;"
      + "border-top:1px dashed #E8EAED;margin-top:8px;padding-top:8px";
    var anchor = document.getElementById("wb-actions");
    if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(host, anchor.nextSibling);
    else {
      var card = document.querySelector(".wb-control-card");
      if (card) card.appendChild(host);
    }
  }
  if (!host) return;
  var isAdmin = currentRole === "admin";
  host.innerHTML =
    '<span class="muted" style="font-size:11px">双轨数据（与 CLI 同源）</span>' +
    '<button type="button" class="btn" id="wb-v32-ledger">抑制台账</button>' +
    '<button type="button" class="btn" id="wb-v32-metrics">隐藏项指标</button>' +
    '<span class="muted" style="font-size:11px">' +
      (isAdmin ? "管理员：本租户汇总只读（恢复仅项目审核员执行）"
               : "审核员：本人可见项目；台账内容脱敏，恢复需填原因（写审计）") +
    "</span>";
  host.querySelector("#wb-v32-ledger").onclick = function () { wbV32OpenLedger(pid); };
  host.querySelector("#wb-v32-metrics").onclick = function () { wbV32OpenMetrics(pid); };
}

function _wbV32Drawer() {
  var mask = document.getElementById("wb-v32-drawer");
  if (!mask) {
    mask = document.createElement("div");
    mask.id = "wb-v32-drawer";
    mask.className = "modal-mask";
    mask.style.zIndex = "80";
    mask.innerHTML =
      '<div class="modal" style="width:min(1000px,calc(100vw - 40px));max-height:calc(100vh - 80px);overflow:auto;padding:0">' +
        '<div class="settings-head" style="padding:14px 18px;border-bottom:1px solid #EBEDF0;display:flex;align-items:flex-start;justify-content:space-between;gap:12px">' +
          '<div><h3 id="wb-v32-title" style="margin:0;font-size:15px"></h3>' +
          '<div id="wb-v32-sub" class="muted" style="font-size:11.5px;margin-top:3px"></div></div>' +
          '<button type="button" class="ws-close" id="wb-v32-close" aria-label="关闭">×</button>' +
        '</div>' +
        '<div id="wb-v32-body" style="padding:14px 18px 18px"></div>' +
      '</div>';
    document.body.appendChild(mask);
    mask.querySelector("#wb-v32-close").onclick = _wbV32Close;
    mask.addEventListener("click", function (e) { if (e.target === mask) _wbV32Close(); });
  }
  mask.hidden = false;
  document.body.style.overflow = "hidden";
  return {
    mask: mask,
    title: mask.querySelector("#wb-v32-title"),
    sub: mask.querySelector("#wb-v32-sub"),
    body: mask.querySelector("#wb-v32-body"),
  };
}

function _wbV32Close() {
  var mask = document.getElementById("wb-v32-drawer");
  if (mask) mask.hidden = true;
  var rec = document.getElementById("wb-v32-recover");
  if (rec) rec.remove();
  document.body.style.overflow = "";
}

function _wbV32ScopeNote(pid) {
  if (currentRole === "admin") return "范围：本租户全部项目（管理员汇总视图）";
  return "范围：本人可见项目" + (pid ? "（当前项目 " + pid + "）" : "");
}

async function wbV32OpenLedger(pid) {
  var ui = _wbV32Drawer();
  _WB_V32.pid = String(pid || "");
  _WB_V32.kind = "ledger";
  ui.title.textContent = "抑制台账（抑制≠删除）";
  ui.sub.textContent = (currentRole === "admin"
    ? "业务管理员：完整只读（恢复由项目审核员执行，原因必填）"
    : "审核员：本人项目 · 内容脱敏只读；恢复需填写原因（写审计 + 写回 finding）") + " · " + _wbV32ScopeNote(_WB_V32.pid);
  ui.body.innerHTML =
    '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px">' +
      '<label style="font-size:12px;color:#646A73">状态' +
        '<select id="wb-v32-ledger-status" class="field" style="margin-left:6px">' +
          '<option value="">全部</option><option value="suppressed">已抑制（suppressed）</option>' +
          '<option value="recovered">已恢复（recovered）</option></select></label>' +
      '<button type="button" class="btn" id="wb-v32-ledger-refresh">刷新</button>' +
      '<span class="muted" id="wb-v32-ledger-counts" style="font-size:11.5px"></span>' +
    '</div>' +
    '<div class="muted" style="font-size:11.5px;margin-bottom:8px">' +
      '抑制≠删除：台账行永久保留；恢复只改 visibility_status 并写回一条可见 finding，动作写审计。' +
      (currentRole === "admin" ? ' 业务管理员只读：恢复会被服务层 403 拒绝。' : ' 恢复原因必填，禁止批量。') +
    '</div>' +
    '<div id="wb-v32-ledger-out"><div class="muted">读取台账中…</div></div>';
  ui.body.querySelector("#wb-v32-ledger-refresh").onclick = function () { wbV32LoadLedger(); };
  ui.body.querySelector("#wb-v32-ledger-status").onchange = function () { wbV32LoadLedger(); };
  await wbV32LoadLedger();
}

function _wbV32LedgerTable(items) {
  if (!items.length) {
    return '<div class="empty" style="padding:18px 0">当前没有抑制台账记录（真实空态）。'
      + '抑制项由可见性策略在审核时产生；这里不会用 0 条冒充“已核验无误报”。</div>';
  }
  var isAdmin = currentRole === "admin";
  var isReviewer = currentRole === "reviewer";
  var head = '<tr><th>项目</th><th>规则</th><th>主体 / 问题</th><th>风险</th><th>抑制原因</th>'
    + '<th>状态</th><th>时间</th>' + (isReviewer ? '<th>操作</th>' : '<th>权限</th>') + '</tr>';
  var rows = items.map(function (it) {
    var st = String(it.visibility_status || "");
    var stCls = st === "recovered" ? "published" : "draft";
    var stLabel = st === "recovered" ? "已恢复" : (st === "suppressed" ? "已抑制" : (st || "—"));
    var op = "";
    if (isReviewer) {
      op = st === "suppressed"
        ? '<button type="button" class="btn" data-wbv32-recover="' + esc(it.id) + '">恢复</button>'
        : '<span class="muted">已恢复' + (it.recovered_finding_ref ? " · " + esc(it.recovered_finding_ref) : "") + '</span>';
    } else {
      op = '<span class="muted">只读</span>';
    }
    return '<tr><td>' + esc(it.case_name || it.case_id || "—") +
      (it.content_redacted ? '<div class="muted" style="font-size:11px">内容已脱敏（防锚定）</div>' : "") + '</td>' +
      '<td class="muted">' + esc(it.rule_code || "—") + '</td>' +
      '<td>' + esc(it.subject || "—") + '<div class="muted" style="font-size:11px">' + esc(it.issue_type || "") + '</div>' +
        (isAdmin && it.raw_claim && it.raw_claim.claim
          ? '<div class="muted" style="font-size:11px;margin-top:2px">' + esc(String(it.raw_claim.claim).slice(0, 80)) + '</div>' : "") + '</td>' +
      '<td>' + esc(it.risk_level || "—") + '</td>' +
      '<td class="muted">' + esc(it.suppression_reason || "—") +
        (it.reason_note ? '<div style="font-size:11px">' + esc(it.reason_note) + '</div>' : "") + '</td>' +
      '<td><span class="pill ' + stCls + '">' + esc(stLabel) + '</span></td>' +
      '<td class="muted">' + esc(String(it.recovered_at || it.created_at || "").slice(0, 19)) + '</td>' +
      '<td>' + op + '</td></tr>';
  }).join("");
  return '<div style="overflow:auto;max-height:52vh"><table class="table"><thead>' + head +
    '</thead><tbody>' + rows + '</tbody></table></div>';
}

async function wbV32LoadLedger() {
  var pid = _WB_V32.pid;
  var out = document.getElementById("wb-v32-ledger-out");
  if (!out) return;
  var statusSel = document.getElementById("wb-v32-ledger-status");
  var status = statusSel ? statusSel.value : "";
  var qs = [];
  if (currentRole !== "admin" && pid) qs.push("case=" + encodeURIComponent(pid));
  if (status) qs.push("status=" + encodeURIComponent(status));
  out.innerHTML = '<div class="muted">读取台账中…</div>';
  var r = await _wbV32Api("/api/v1/suppression-ledger" + (qs.length ? "?" + qs.join("&") : ""));
  var d = r.data || {};
  if (!r.ok || d.ok === false) {
    out.innerHTML = '<div class="empty" style="padding:18px 0">抑制台账读取失败（HTTP ' +
      esc(r.status) + '）：' + esc(d.error || d.message || r.error || "未知错误") +
      '。失败不会被当作“没有记录”。</div>';
    return;
  }
  var items = d.items || [];
  var counts = d.counts || {};
  var cnt = document.getElementById("wb-v32-ledger-counts");
  if (cnt) {
    /* 非管理员响应只含 by_status（服务层裁剪派生键 suppressed/recovered），
       不能把缺失字段默认成 0（会与表格里的“已恢复”行自相矛盾）。 */
    var byStatus = counts.by_status || {};
    var nSupp = counts.suppressed == null ? (byStatus.suppressed || 0) : counts.suppressed;
    var nRec = counts.recovered == null ? (byStatus.recovered || 0) : counts.recovered;
    cnt.textContent = "共 " + (d.total == null ? items.length : d.total) + " 条 · 已抑制 " +
      nSupp + " · 已恢复 " + nRec +
      (d.scope && d.scope.cases != null ? " · 可见项目 " + d.scope.cases : "");
  }
  out.innerHTML = _wbV32LedgerTable(items);
  out.querySelectorAll("[data-wbv32-recover]").forEach(function (b) {
    b.onclick = function () { wbV32OpenRecover(b.dataset.wbv32Recover); };
  });
}

function wbV32OpenRecover(ledgerId) {
  var old = document.getElementById("wb-v32-recover");
  if (old) old.remove();
  var mask = document.createElement("div");
  mask.id = "wb-v32-recover";
  mask.className = "modal-mask";
  mask.style.zIndex = "90";
  mask.innerHTML =
    '<div class="modal" style="width:min(560px,calc(100vw - 32px))">' +
      '<div class="settings-head"><div><h3>从抑制池恢复为可见</h3>' +
      '<div class="muted" style="font-size:11px;margin-top:3px">台账 ' + esc(ledgerId) + '</div></div>' +
      '<button type="button" class="ws-close" data-wbv32-cancel>×</button></div>' +
      '<div class="muted" style="font-size:12px;line-height:1.7;margin-bottom:8px">' +
        '恢复不是删除：台账行保留并标记 recovered；恢复原因<b>必填</b>，动作写审计并写回一条可见 finding。' +
        '禁止批量恢复。</div>' +
      '<textarea id="wb-v32-recover-reason" class="field" style="width:100%;min-height:84px" ' +
        'placeholder="请填写恢复原因（必填，例如：人工核对原文确属真问题/误判依据）"></textarea>' +
      '<div id="wb-v32-recover-msg" class="muted" style="font-size:11.5px;margin-top:6px"></div>' +
      '<div class="actions" style="margin-top:12px;justify-content:flex-end">' +
        '<button type="button" class="btn" data-wbv32-cancel>取消</button>' +
        '<button type="button" class="btn primary" id="wb-v32-recover-ok">确认恢复</button></div>' +
    '</div>';
  document.body.appendChild(mask);
  var close = function () { mask.remove(); };
  mask.querySelectorAll("[data-wbv32-cancel]").forEach(function (b) { b.onclick = close; });
  mask.addEventListener("click", function (e) { if (e.target === mask) close(); });
  mask.querySelector("#wb-v32-recover-ok").onclick = async function () {
    var btn = this;
    var input = mask.querySelector("#wb-v32-recover-reason");
    var msg = mask.querySelector("#wb-v32-recover-msg");
    var reason = (input.value || "").trim();
    if (!reason) {
      msg.textContent = "恢复原因必填（用于审计）：请填写后再提交。";
      try { input.focus(); } catch (e) {}
      return;
    }
    btn.disabled = true; btn.textContent = "恢复中…";
    var r = await _wbV32Api("/api/v1/suppression-ledger/" + encodeURIComponent(ledgerId) + "/recover",
      { method: "POST", body: { reason: reason } });
    var d = r.data || {};
    btn.disabled = false; btn.textContent = "确认恢复";
    if (!r.ok || d.ok === false) {
      msg.textContent = "恢复失败（HTTP " + r.status + "）：" + (d.error || d.message || r.error || "未知错误");
      return;
    }
    close();
    showToast("已恢复为可见问题" + (d.finding_id ? "（finding " + d.finding_id + "）" : "") + "；已写审计");
    await wbV32LoadLedger();
  };
}

async function wbV32OpenMetrics(pid) {
  var ui = _wbV32Drawer();
  _WB_V32.pid = String(pid || "");
  _WB_V32.kind = "metrics";
  ui.title.textContent = "隐藏项指标（口径与 CLI 同源）";
  ui.sub.textContent = (currentRole === "admin"
    ? "业务管理员：本租户汇总（分 production/evaluation / 来源 / 原因）"
    : "审核员：本人项目可见范围") + " · " + _wbV32ScopeNote(_WB_V32.pid);
  ui.body.innerHTML =
    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px">' +
      '<button type="button" class="btn" id="wb-v32-metrics-refresh">刷新</button>' +
      '<span class="muted" id="wb-v32-metrics-meta" style="font-size:11.5px"></span></div>' +
    '<div class="muted" style="font-size:11.5px;margin-bottom:10px">' +
      '口径：hidden_total=0 只表示当前没有隐藏项，<b>不等于“无误报”</b>；' +
      'reveal 是自愿行为（有选择偏差）；默认处置=suspected_false_positive 是 weak_default，非 gold。' +
      '本页不展示任何未由服务端返回的指标。</div>' +
    '<div id="wb-v32-metrics-out"><div class="muted">读取指标中…</div></div>';
  ui.body.querySelector("#wb-v32-metrics-refresh").onclick = function () { wbV32LoadMetrics(); };
  await wbV32LoadMetrics();
}

function _wbV32MetricCard(label, value, sub) {
  return '<div class="ops-kpi" style="background:#fff;border:1px solid #EBEDF0;border-radius:10px;padding:12px 14px">' +
    '<div class="muted" style="font-size:11.5px;margin-bottom:6px">' + esc(label) + '</div>' +
    '<div style="font-size:20px;font-weight:600;line-height:1.2">' + esc(value) + '</div>' +
    (sub ? '<div class="muted" style="font-size:11px;margin-top:4px">' + esc(sub) + '</div>' : "") +
    '</div>';
}

function _wbV32KVTable(title, obj) {
  var keys = Object.keys(obj || {});
  if (!keys.length) {
    return '<div class="muted" style="font-size:12px;margin-top:8px">' + esc(title) + '：无数据（真实空态）</div>';
  }
  var rows = keys.map(function (k) {
    var v = obj[k] || {};
    var parts = Object.keys(v).map(function (kk) { return kk + "=" + v[kk]; }).join(" · ");
    return '<tr><td class="muted">' + esc(k) + '</td><td class="muted">' + esc(parts) + '</td></tr>';
  }).join("");
  return '<div style="margin-top:12px"><div style="font-size:12.5px;font-weight:600;margin-bottom:4px">' + esc(title) + '</div>' +
    '<table class="table"><tbody>' + rows + '</tbody></table></div>';
}

async function wbV32LoadMetrics() {
  var pid = _WB_V32.pid;
  var out = document.getElementById("wb-v32-metrics-out");
  if (!out) return;
  var qs = (currentRole !== "admin" && pid) ? ("?case=" + encodeURIComponent(pid)) : "";
  out.innerHTML = '<div class="muted">读取指标中…</div>';
  var r = await _wbV32Api("/api/v1/hidden-metrics" + qs);
  var d = r.data || {};
  if (!r.ok || d.ok === false) {
    out.innerHTML = '<div class="empty" style="padding:18px 0">隐藏项指标读取失败（HTTP ' + esc(r.status) + '）：' +
      esc(d.error || d.message || r.error || "未知错误") + '。失败不会被当作“0 隐藏项”。</div>';
    return;
  }
  var m = d.metrics || {};
  var meta = document.getElementById("wb-v32-metrics-meta");
  if (meta) {
    meta.textContent = "生成时间 " + (m.generated_at || "—") +
      (m.scope && m.scope.cases != null ? " · 可见项目 " + m.scope.cases : "") +
      " · ttl " + (m.ttl_days == null ? "—" : m.ttl_days) + " 天";
  }
  var html = '<div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">' +
    _wbV32MetricCard("隐藏项总数", m.hidden_total == null ? "—" : m.hidden_total, "open " + (m.open == null ? "—" : m.open) + " / recovered " + (m.recovered == null ? "—" : m.recovered)) +
    _wbV32MetricCard("隐藏项覆盖项目", m.cases_with_hidden == null ? "—" : m.cases_with_hidden, "已打开审计项目 " + (m.cases_revealed == null ? "—" : m.cases_revealed)) +
    _wbV32MetricCard("进化池覆盖", m.feedback_coverage == null ? "—" : (m.feedback_coverage + "%"), "目标 " + (m.feedback_coverage_target == null ? "—" : m.feedback_coverage_target) + "% · 已入池 " + (m.feedback_enqueued == null ? "—" : m.feedback_enqueued)) +
    _wbV32MetricCard("恢复率（recovery_rate）", m.recovery_rate == null ? "—" : (m.recovery_rate + "%"), "已恢复为可见 / 隐藏项总数") +
    _wbV32MetricCard("打开率（reveal_rate）", m.reveal_rate == null ? "—" : (m.reveal_rate + "%"), "自愿行为，有选择偏差") +
    _wbV32MetricCard("逐项打开率（item_reveal_rate）", m.item_reveal_rate == null ? "—" : (m.item_reveal_rate + "%"), "被打开过隐藏项 / 总数") +
    _wbV32MetricCard("人工确认 TP", m.hidden_confirmed_tp == null ? "—" : m.hidden_confirmed_tp, "只统计人工裁决事件") +
    _wbV32MetricCard("超 TTL 待默认处置", m.default_due == null ? "—" : m.default_due, "默认 weak_default，非 gold") +
    '</div>';
  if (!m.hidden_total) {
    html += '<div class="empty" style="padding:16px 0;margin-top:10px">当前没有隐藏项（真实空态，计数来自服务端）。'
      + '这不是“已核验无误报”，只是没有进入隐藏池的记录。</div>';
  }
  html += _wbV32KVTable("分审核模式（production / evaluation）", m.by_mode || {});
  html += _wbV32KVTable("分来源", m.by_source || {});
  html += _wbV32KVTable("分抑制原因", m.by_reason || {});
  if ((m.notes || []).length) {
    html += '<div style="margin-top:12px"><div style="font-size:12.5px;font-weight:600;margin-bottom:4px">口径说明（服务端原样返回）</div>' +
      '<ul class="muted" style="font-size:11.5px;line-height:1.7;margin:0;padding-left:18px">' +
      (m.notes || []).map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + '</ul></div>';
  }
  out.innerHTML = html;
}

/* ===========================================================================
 * L103 审核台 UI 改版（2026-11-25）：左栏文档预览 / 右栏完整审核工作台
 *
 * 目标（用户明确要求）：
 *   - 不要「一左一右」分散：预览固定在左，审核操作全部收进右栏；
 *   - 右栏单栏 + tab 分区：发现列表、当前 finding 详情、证据/引文、五态操作、
 *     复核决定、报告签发/导出、审计轨迹；右栏内部滚动，关键操作吸底；
 *   - 保留既有 DOM id/class 契约（本文件只做增量增强，不改后端/不改审核口径）。
 *
 * 数据来源（全部真实接口，不伪造）：
 *   - 发现/证据：openWorkbench 已加载的 GET /api/v1/projects/{id}（findings[].evidence[]）
 *   - 裁决轨迹 + 判定链：GET /api/v1/findings/{id}（decisions[] + chain[]）
 *   - 报告版本/签发/导出：GET /api/v1/reports?case_id=...（与报告签发卡同一接口）
 *   - 五态操作：复用 wb106Decide（服务端 /api/v1/findings/{id}/decision，写审计）
 * ========================================================================= */
var _WB_L103 = { bound: false, pid: "", selected: "", tab: "review", trace: {}, auditSeq: 0 };

function wbL103On() { return !!document.getElementById("wb-l103-tabs"); }
function wbL103Current() {
  var sel = String(_WB_L103.selected || "");
  if (!sel) return null;
  return (wbFindings || []).find(function (f) { return String(f.id) === sel; }) || null;
}
function wbL103SevMeta(sev) {
  var map = { critical: ["严重", "draft"], warning: ["一般", "r"],
              suspected: ["提示", "published"], info: ["提示", "published"] };
  return map[String(sev || "warning")] || ["一般", "r"];
}
function wbL103StatusMeta(status) {
  var map = {
    pending: ["待处理", "is-pending"], confirmed: ["已确认", "is-confirmed"],
    false_positive: ["误报", "is-false_positive"],
    need_evidence: ["需补证", "is-need_evidence"], ignored: ["已忽略", "is-ignored"]
  };
  return map[String(status || "pending")] || ["已裁决", "is-pending"];
}
function wbL103DecisionLabel(d) {
  return ({ confirmed: "确认问题", false_positive: "确认误报", need_evidence: "退回补证",
            ignored: "忽略", rejected: "驳回" })[String(d || "")] || String(d || "裁决");
}
function wbL103Readonly() {
  if (typeof _wb106Readonly === "function") return _wb106Readonly();
  return typeof currentRole !== "undefined" && currentRole === "admin";
}
function wbL103LocText(f) {
  // L143/T-③：优先展示解析后的可读定位（Sheet!B15 / 第N页 / 第N段·字符a-b）；
  // L148/T-③：后端已透出 text_locator / char span / 结构化行列时逐级回退（只用
  // 已有字段、不改 UI 结构）；仍无则显式“未记录位置”，不静默。
  var locs = ((f && f.evidence) || []).map(function (a) {
    if (!a) return "";
    if (typeof wbLocReadable === "function") {
      try {
        var r = wbLocReadable(a, f);
        if (r && r.display) return String(r.display);
      } catch (e) { /* 回退原始字段 */ }
    }
    if (a.text_locator) return String(a.text_locator);
    if (a.sheet && a.row && a.col) return a.sheet + "!" + a.col + a.row;
    return a.locator || a.sheet || "";
  }).filter(Boolean);
  if (!locs.length && typeof wbLocSpan === "function") {
    try {
      var sp = wbLocSpan(f);
      if (sp && sp[0] >= 0 && sp[1] > sp[0]) {
        locs.push("原文 · 字符" + (sp[0] + 1) + "-" + sp[1]);
      }
    } catch (e) { /* 无字符区间 */ }
  }
  if (locs.length) return Array.from(new Set(locs)).slice(0, 2).join(" · ");
  var _noNav = (f && f.navigable === false)
    || (f && Array.isArray(f.missing) && f.missing.length);
  return _noNav ? "未记录位置（无页/单元格/字符区间坐标）" : "未记录位置";
}

/* ---------------- tab 切换 ---------------- */
function wbL103SetTab(tab, opts) {
  if (!wbL103On()) return false;
  opts = opts || {};
  if (["review", "report", "audit"].indexOf(tab) < 0) tab = "review";
  _WB_L103.tab = tab;
  document.querySelectorAll("#wb-l103-tabs .wb-l103-tab").forEach(function (b) {
    var on = b.dataset.wbL103Tab === tab;
    b.classList.toggle("on", on);
    b.setAttribute("aria-selected", on ? "true" : "false");
  });
  document.querySelectorAll("#wb-l103-body [data-wb-l103-pane]").forEach(function (p) {
    p.hidden = p.dataset.wbL103Pane !== tab;
  });
  /* L171：分区状态落到根节点，CSS 据此保证「同屏唯一填充主操作」——审核分区由吸底
     「确认问题」独占 primary；报告分区把裁决 primary 降级，让「签发报告」成为该区唯一主操作；
     审计分区无主操作。只影响视觉层级，不改任何按钮/DOM 契约。 */
  var root = document.getElementById("view-workbench");
  if (root) root.setAttribute("data-wb171-tab", tab);
  var body = document.getElementById("wb-l103-body");
  if (body && !opts.keepScroll) body.scrollTop = 0;
  if (tab === "audit") { try { wbL103RenderAudit(); } catch (e) { console.warn("L103 审计轨迹渲染失败", e); } }
  return true;
}

/* ---------------- 当前 finding 详情 ---------------- */
function wbL103TraceHtml(fid) {
  var t = _WB_L103.trace[String(fid)];
  if (!t) return '<span class="muted">裁决轨迹加载中…</span>';
  if (t.error) return '<span class="muted">裁决轨迹读取失败：' + esc(t.error) + "</span>";
  var chain = Array.isArray(t.chain) ? t.chain : [];
  var ds = Array.isArray(t.decisions) ? t.decisions : [];
  var out = "";
  if (chain.length) {
    out += '<div>判定链（' + chain.length + " 步）：<span class=\"wb-l103-trace-steps\">"
      + chain.map(function (c, i) {
        var label = String((c && c.step) || "");
        var extra = c && (c.code || c.version || c.engine || c.name) ? " · " + String(c.code || c.version || c.engine || c.name) : "";
        return '<span class="wb-l103-trace-step' + (i === 0 ? "" : " is-neutral") + '">'
          + esc(label + extra) + "</span>";
      }).join("") + "</span></div>";
  }
  if (ds.length) {
    out += '<div style="margin-top:6px">裁决记录（' + ds.length + " 条，最新在前）：</div>"
      + ds.slice(0, 6).map(function (d) {
        return '<div class="wb-l103-audit-row"><b>' + esc(wbL103DecisionLabel(d.decision)) + "</b>"
          + "<span>" + esc(String(d.reason || "未填写原因").slice(0, 90)) + "</span>"
          + '<span class="when">' + esc(d.user_id || "") + " · "
          + esc(String(d.created_at || "").slice(0, 16)) + "</span></div>";
      }).join("");
  } else {
    out += '<div class="muted" style="margin-top:4px">尚无裁决记录（待复核）；裁决后写入审计轨迹。</div>';
  }
  return out;
}

function wbL103RenderDetail() {
  var box = document.getElementById("wb-l103-detail");
  if (!box) return;
  box.classList.add("wb161-detail");
  var f = wbL103Current();
  if (!f) { box.hidden = true; box.innerHTML = ""; return; }
  var sev = wbL103SevMeta(f.severity), st = wbL103StatusMeta(f.status);
  var evidence = ((f.evidence || []).filter(function (a) {
    return a && (a.quote || a.excerpt || a.locator || a.text_locator
      || a.sheet || a.row || Number(a.char_start) >= 0);
  }));
  var _rb = (typeof wbLocExplain === "function") ? wbLocExplain(f) : null;
  var quotes = evidence.map(function (a) {
    var _rd = (typeof wbLocReadable === "function") ? wbLocReadable(a, f) : null;
    var loc = (_rd && _rd.display) || [a.text_locator || "", a.locator || "",
               a.sheet ? ("Sheet " + a.sheet) : "",
               a.row ? ("行 " + a.row) : "", a.page ? ("第 " + a.page + " 页") : ""].filter(Boolean).join(" · ");
    // L148：字符区间回退顺序 = 投影解析结果 → 证据自身 char span → finding 级 span
    var _cs = Number(a.char_start), _ce = Number(a.char_end);
    var _sp = (_rd && _rd.span) || (_cs >= 0 && _ce > _cs ? [_cs, _ce] : null);
    var span = _sp ? ("字符" + (_sp[0] + 1) + "-" + _sp[1]) : "";
    var meta = [];
    if (span) meta.push(span);
    if (_rd && _rd.cell) meta.push(_rd.cell);
    else if (a.sheet && a.row && a.col) meta.push(a.sheet + "!" + a.col + a.row);
    if (_rd && _rd.page && !_rd.cell && String(loc).indexOf("第" + _rd.page + "页") < 0) meta.push("第" + _rd.page + "页");
    if (_rd && _rd.strength && _rd.strength !== "none") meta.push("锚点强度 " + _rd.strength);
    if (_rd && _rd.backfill_status) meta.push("回填 " + _rd.backfill_status);
    if (_rd && _rd.missing && _rd.missing.length) meta.push("缺失 " + _rd.missing.join("/"));
    var q = a.quote || a.excerpt || (f && f.verbatim_quote) || "";
    if (!q && !loc) return "";
    return '<div class="wb-l103-quote"><span class="loc">' + esc(loc || "原文")
      + (meta.length ? ' <span class="muted">' + esc(meta.join(" · ")) + "</span>" : "")
      + "</span>" + esc(q || "（该证据未记录逐字引文）") + "</div>";
  }).join("");
  var basis = f.rule_name || f.rule_code || (String(f.engine || "") === "manual" ? "人工录入" : "—");
  var code = (f.rule_name && f.rule_code) ? f.rule_code : "";
  box.innerHTML = '<div class="wb-l103-detail-head">'
    + '<span class="pill ' + sev[1] + '">' + esc(sev[0]) + "</span>"
    + '<span class="wb106-status ' + st[1] + '">' + esc(st[0]) + "</span>"
    + "<b>" + esc(f.title || "（无标题）") + "</b>"
    + '<button type="button" class="btn wb-l103-detail-close" data-wb-l103-detail-act="close" title="收起详情，回到问题清单（不改变裁决）">收起详情</button>'
    + "</div>"
    + '<div class="wb-l103-kv">'
    + '<div><span class="k">判定依据</span><b>' + esc(basis) + (code ? " · " + esc(code) : "") + "</b></div>"
    + '<div><span class="k">位置</span><b>' + esc(wbL103LocText(f)) + "</b></div>"
    + '<div><span class="k">定位可用性</span><b>'
      + (_rb && _rb.navigable
          ? "可跳转（" + esc(_rb.mode === "cell" ? (_rb.cell || "单元格")
              : _rb.span ? "字符" + (_rb.span[0] + 1) + "-" + _rb.span[1]
              : "第" + _rb.page + "页") + "）"
          : (_rb && _rb.quote ? "仅逐字引文可检索（无坐标）"
              : "无坐标，需回原文人工核对（可在证据链查看原因）"))
      + ((_rb && _rb.missing && _rb.missing.length)
          ? "；缺失项：" + esc(_rb.missing.join("/")) : "")
      + "</b></div>"
    + '<div><span class="k">执行来源 / 规则版本</span><b>' + esc(f.layer_label || f.layer || f.engine || "—")
      + " · " + esc(f.rule_version || "—") + "</b></div>"
    + "</div>"
    + ((f.verbatim_quote || (_rb && _rb.span))
        ? '<div class="wb-l103-kv"><div><span class="k">逐字引文</span><b>'
          + esc(String(f.verbatim_quote || (_rb && _rb.quote) || "").slice(0, 120)) + "</b></div>"
          + ((_rb && _rb.span) ? '<div><span class="k">字符区间</span><b>'
            + esc("字符" + (_rb.span[0] + 1) + "-" + _rb.span[1]) + "</b></div>" : "")
          + "</div>" : "")
    + '<div class="wb-l103-block"><b>问题描述</b>' + esc(f.summary || f.title || "—") + "</div>"
    + (f.suggestion ? '<div class="wb-l103-block"><b>整改建议</b>' + esc(f.suggestion) + "</div>" : "")
    + (quotes
        ? '<div class="wb-l103-block" style="background:#fff;border:1px solid #DCE6FF"><b>证据 / 原文引文</b>' + quotes + "</div>"
        : '<div class="wb-l103-audit-empty">该问题暂无结构化引文；可点「查看证据链」或「定位原文」。</div>')
    + '<div class="wb-l103-detail-actions">'
    + '<button type="button" class="btn" data-wb-l103-detail-act="locate">定位原文</button>'
    + '<button type="button" class="btn" data-wb-l103-detail-act="evidence">查看证据链</button>'
    + '<button type="button" class="btn" data-wb-l103-detail-act="trace">审计轨迹</button>'
    + (String(f.status || "pending") !== "pending" && !wbL103Readonly()
        ? '<button type="button" class="btn" data-wb-l103-detail-act="redecide">改判…</button>' : "")
    + "</div>"
    + '<div class="wb-l103-detail-trace" id="wb-l103-detail-trace">' + wbL103TraceHtml(f.id) + "</div>";
  box.hidden = false;
}

/* ---------------- 吸底五态操作 ---------------- */
function wbL103SyncSticky() {
  if (!wbL103On()) return;
  var titleEl = document.getElementById("wb-l103-current-title");
  var metaEl = document.getElementById("wb-l103-current-meta");
  var btns = Array.prototype.slice.call(
    document.querySelectorAll("#wb-l103-sticky-actions [data-wb-l103-decide]"));
  var f = wbL103Current();
  var readonly = wbL103Readonly();
  if (!f) {
    if (titleEl) titleEl.textContent = "尚未选择问题";
    if (metaEl) metaEl.textContent = (wbFindings || []).length
      ? "在问题清单点选一条问题，五态操作会在这里吸底显示"
      : "当前项目暂无可复核问题";
    btns.forEach(function (b) {
      b.disabled = true;
      b.dataset.reason = "请先在问题清单选择一条问题";
      b.title = b.dataset.reason;
    });
    return;
  }
  var sev = wbL103SevMeta(f.severity), st = wbL103StatusMeta(f.status);
  if (titleEl) { titleEl.textContent = f.title || "当前问题"; titleEl.title = f.title || ""; }
  if (metaEl) metaEl.textContent = st[0] + " · " + sev[0] + " · " + wbL103LocText(f);
  var reason = "";
  if (readonly) reason = "只读：业务管理员不可裁决";
  else if (String(f.status || "pending") !== "pending") {
    reason = "已裁决（" + st[0] + "）：如需变更请用卡片「更多 → 改判」";
  }
  btns.forEach(function (b) {
    b.disabled = !!reason;
    b.dataset.reason = reason;
    b.title = reason || ({ confirmed: "确认问题成立（写审计）", false_positive: "判为误报（必填原因，进入规则进化反馈）",
      need_evidence: "退回补证：要求补充材料，不删除问题", ignored: "忽略：保留记录，不删除问题" })[b.dataset.wbL103Decide] || "";
  });
}

/* ---------------- 选中/同步 ---------------- */
function wbL103Select(fid, opts) {
  if (!wbL103On()) return;
  opts = opts || {};
  var f = (wbFindings || []).find(function (x) { return String(x.id) === String(fid); });
  _WB_L103.selected = f ? String(f.id) : "";
  wbL103RenderDetail();
  wbL103SyncSticky();
  document.querySelectorAll("#wb-findings .fcard").forEach(function (c) {
    c.classList.toggle("wb-l103-selected", String(c.dataset.fid) === _WB_L103.selected);
  });
  if (f) {
    try { if (typeof wbL103LoadTrace === "function") wbL103LoadTrace(f.id); } catch (e) {}
    if (opts.scroll !== false) {
      var box = document.getElementById("wb-l103-detail");
      var body = document.getElementById("wb-l103-body");
      if (box && body) {
        try {
          var top = box.offsetTop - body.offsetTop - 6;
          body.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
        } catch (e) {}
      }
    }
  }
}

async function wbL103LoadTrace(fid, force) {
  fid = String(fid || "");
  if (!fid) return;
  if (!force && _WB_L103.trace[fid]) return;
  _WB_L103.trace[fid] = null;
  var out = null;
  try {
    var r = await fetch("/api/v1/findings/" + encodeURIComponent(fid));
    out = await r.json();
    if (!r.ok) out = { error: (out && out.error) || ("HTTP " + r.status) };
  } catch (e) {
    out = { error: String((e && e.message) || e) };
  }
  if (out && out.error) out = { error: String(out.error), chain: [], decisions: [] };
  _WB_L103.trace[fid] = out || { chain: [], decisions: [] };
  if (String(_WB_L103.selected) === fid) {
    var d = document.getElementById("wb-l103-detail-trace");
    if (d) d.innerHTML = wbL103TraceHtml(fid);
  }
  var a = document.getElementById("wb-l103-audit-trace");
  if (a && String(_WB_L103.selected) === fid && _WB_L103.tab === "audit") {
    a.innerHTML = wbL103TraceHtml(fid);
  }
}

function wbL103SyncBadges() {
  var fs = wbFindings || [];
  var pending = fs.filter(function (f) { return String(f.status || "pending") === "pending"; }).length;
  var rb = document.getElementById("wb-l103-tab-review-badge");
  if (rb) {
    if (!fs.length) { rb.hidden = true; }
    else { rb.hidden = false; rb.textContent = pending ? (pending + " 待处理") : "已全部复核"; }
  }
  var iss = (typeof window !== "undefined" && window.__wbReportIssuance) || {};
  var label = ({ none: "未生成", generated: "待签发", signed: "可导出", exported: "已导出" })[String(iss.status || "")] || "";
  var rpb = document.getElementById("wb-l103-tab-report-badge");
  if (rpb) {
    if (!label) { rpb.hidden = true; }
    else { rpb.hidden = false; rpb.textContent = label; }
  }
}

function wbL103Sync() {
  if (!wbL103On()) return;
  if (_WB_L103.selected && !wbL103Current()) _WB_L103.selected = "";
  wbL103SyncBadges();
  wbL103RenderDetail();
  wbL103SyncSticky();
  document.querySelectorAll("#wb-findings .fcard").forEach(function (c) {
    c.classList.toggle("wb-l103-selected", String(c.dataset.fid) === String(_WB_L103.selected));
  });
}

/* ---------------- 审计轨迹 ---------------- */
function wbL103RenderAudit() {
  var host = document.getElementById("wb-l103-audit");
  if (!host) return;
  var fs = wbFindings || [];
  var labels = [["pending", "待处理"], ["confirmed", "已确认"], ["false_positive", "误报"],
                ["need_evidence", "需补证"], ["ignored", "忽略"]];
  var counts = {};
  fs.forEach(function (f) { var s = String(f.status || "pending"); counts[s] = (counts[s] || 0) + 1; });
  var kpis = labels.map(function (x) {
    return '<span class="wb-l103-audit-kpi"><b>' + (counts[x[0]] || 0) + "</b>" + esc(x[1]) + "</span>";
  }).join("") + '<span class="wb-l103-audit-kpi"><b>' + fs.length + "</b>发现总数</span>";
  var f = wbL103Current();
  host.innerHTML =
    '<div class="wb-l103-audit-sec"><h4>复核状态汇总<span class="muted">来自当前项目发现与真实裁决结果</span></h4>'
    + '<div class="wb-l103-audit-kpis">' + kpis + "</div>"
    + '<div class="wb-l103-audit-row" style="margin-top:8px"><b>已复核</b><span>'
    + (fs.length - (counts.pending || 0)) + " / " + fs.length + "</span>"
    + '<span class="when">已复核口径决定报告门禁；未复核项会在报告与签发页给出原因</span></div></div>'
    + '<div class="wb-l103-audit-sec"><h4>当前问题裁决轨迹<span class="muted">'
    + (f ? esc(String(f.title || "").slice(0, 40)) : "未选择问题") + "</span></h4>"
    + '<div id="wb-l103-audit-trace">'
    + (f ? wbL103TraceHtml(f.id)
        : '<div class="wb-l103-audit-empty">在「发现与复核」中选择一条问题后，这里显示该问题的裁决记录与判定链（规则 → 规则版本 → 证据锚点 → 判定来源 → 审核批次 → 项目）。</div>')
    + "</div></div>"
    + '<div class="wb-l103-audit-sec"><h4>报告版本与签发记录<span class="muted" id="wb-l103-audit-report-note"></span></h4>'
    + '<div id="wb-l103-audit-reports"><div class="wb-l103-audit-empty">报告记录加载中…</div></div></div>';
  wbL103LoadAuditReports();
}

async function wbL103LoadAuditReports() {
  var host = document.getElementById("wb-l103-audit-reports");
  var note = document.getElementById("wb-l103-audit-report-note");
  if (!host) return;
  var pid = String(currentWb || _WB106.pid || "");
  var seq = ++_WB_L103.auditSeq;
  if (!pid) return;
  var data = null;
  try {
    var r = await fetch("/api/v1/reports?case_id=" + encodeURIComponent(pid));
    if (r.ok) data = await r.json();
  } catch (e) { data = null; }
  if (seq !== _WB_L103.auditSeq || !document.getElementById("wb-l103-audit-reports")) return;
  var rows = (data && data.items) || [];
  rows = rows.filter(function (x) {
    try { return String((JSON.parse((x && x.summary_json) || "{}") || {})._kind || "") !== "export_receipt"; }
    catch (e) { return true; }
  });
  if (!rows.length) {
    host.innerHTML = '<div class="wb-l103-audit-empty">暂无报告版本记录：完成复核并通过报告门禁后，可到「报告与签发」生成报告；签发/导出会写入报告记录与审计。</div>';
    if (note) note.textContent = "（0 条）";
    return;
  }
  if (note) note.textContent = "（" + rows.length + " 条）";
  host.innerHTML = rows.slice(0, 10).map(function (row) {
    var stat = String(row.status || "").toLowerCase();
    var label = (stat === "exported" || String(row.exported_by || "").trim()) ? "已导出"
      : stat === "signed" ? "已签发" : stat === "generated" ? "已生成" : (stat || "—");
    var pill = (label === "已签发" || label === "已导出") ? "published" : "draft";
    var signer = String(row.signed_by || "").trim() || "未签发";
    var when = String(row.signed_at || row.created_at || "");
    var hash = String(row.content_hash || "");
    return '<div class="wb-l103-audit-row"><span class="pill ' + pill + '">' + esc(label) + "</span>"
      + "<b>" + esc(row.version || "") + "</b><span>" + esc(signer) + "</span>"
      + (hash ? '<code title="内容 hash">' + esc(hash.slice(0, 12)) + "…</code>" : "")
      + '<span class="when">' + esc(when) + "</span></div>";
  }).join("");
}

/* ---------------- 初始化与增强钩子 ---------------- */
function wbL103Bind() {
  if (_WB_L103.bound || !wbL103On()) return;
  _WB_L103.bound = true;
  document.querySelectorAll("#wb-l103-tabs .wb-l103-tab").forEach(function (b) {
    b.addEventListener("click", function () { wbL103SetTab(b.dataset.wbL103Tab); });
  });
  var sticky = document.getElementById("wb-l103-sticky-actions");
  if (sticky) {
    sticky.addEventListener("click", function (e) {
      var b = e.target && e.target.closest ? e.target.closest("[data-wb-l103-decide]") : null;
      if (!b) return;
      if (b.disabled) { if (typeof showToast === "function") showToast(String(b.dataset.reason || "该操作当前不可用"), "err"); return; }
      var f = wbL103Current();
      if (!f) { if (typeof showToast === "function") showToast("请先在问题清单选择一条问题", "err"); return; }
      if (typeof wb106Decide === "function") wb106Decide(f.id, b.dataset.wbL103Decide);
      else if (typeof showToast === "function") showToast("裁决弹窗不可用，请刷新页面重试", "err");
    });
  }
  var gotoReport = document.getElementById("wb-l103-goto-report");
  if (gotoReport) gotoReport.addEventListener("click", function () { wbL103SetTab("report"); });
  var detail = document.getElementById("wb-l103-detail");
  if (detail) {
    detail.addEventListener("click", function (e) {
      var b = e.target && e.target.closest ? e.target.closest("[data-wb-l103-detail-act]") : null;
      if (!b) return;
      var act = b.dataset.wbL103DetailAct;
      var f = wbL103Current();
      if (act === "close") { _WB_L103.selected = ""; wbL103RenderDetail(); wbL103SyncSticky();
        document.querySelectorAll("#wb-findings .fcard.wb-l103-selected").forEach(function (c) { c.classList.remove("wb-l103-selected"); });
        return; }
      if (!f) return;
      if (act === "locate") { if (typeof locateFinding === "function") locateFinding(f.id); return; }
      if (act === "evidence") { if (typeof openEvidenceView === "function") openEvidenceView(f.id); return; }
      if (act === "trace") { wbL103SetTab("audit"); return; }
      if (act === "redecide") { if (typeof wb106Decide === "function") wb106Decide(f.id, ""); return; }
    });
  }
  if (typeof wbL171SyncPrimaryRoles === "function") { try { wbL171SyncPrimaryRoles(); } catch (e) {} }
  else if (typeof wbL161SyncStickyGroups === "function") { try { wbL161SyncStickyGroups(); } catch (e) {} }
  var root = document.getElementById("view-workbench");
  if (root) {
    root.addEventListener("click", function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var card = t.closest("#wb-findings .fcard");
      if (!card) return;
      if (t.closest("button,input,a,select,textarea,label,[data-wb106-more],[data-wb106-decide],.wb106-batch-cb")) return;
      wbL103Select(card.dataset.fid);
    });
  }
}

function wbL103AfterOpen() {
  if (!wbL103On()) return;
  wbL103Bind();
  var pid = String((typeof currentWb !== "undefined" && currentWb) || "");
  if (_WB_L103.pid !== pid) {
    _WB_L103.pid = pid;
    _WB_L103.selected = "";
    _WB_L103.trace = {};
  }
  wbL103SetTab(_WB_L103.tab === "audit" || _WB_L103.tab === "report" ? _WB_L103.tab : "review",
               { keepScroll: true });
  wbL103Sync();
  setTimeout(function () { try { wbL103Sync(); } catch (e) {} }, 700);
  setTimeout(function () { try { wbL103Sync(); } catch (e) {} }, 1800);
}

function wbL103AfterDecision(fid) {
  if (!wbL103On()) return;
  _WB_L103.trace[String(fid)] = null;
  wbL103Sync();
  try { wbL103LoadTrace(fid, true); } catch (e) {}
  if (_WB_L103.tab === "audit") { try { wbL103RenderAudit(); } catch (e) {} }
}

/* 增量补丁：包装既有入口，不修改原函数内部逻辑；任何异常都不得阻断审核主链。 */
(function () {
  if (typeof openWorkbench === "function") {
    var _wbL103OpenOrig = openWorkbench;
    openWorkbench = async function () {
      try { wbL103Bind(); } catch (e) {}
      // 切项目时先清掉上一个项目的标题/报告状态，避免加载期间把旧项目内容误当成新项目
      // （既防止用户误读，也让外部 UI 测试的「加载完成」判定不会命中陈旧文本）。
      try {
        var _t = document.getElementById("wb-title");
        if (_t) _t.textContent = "";
        var _s = document.getElementById("wb-report-strip");
        if (_s) _s.innerHTML = '<span class="muted">报告状态加载中…</span>';
      } catch (e) {}
      var r = await _wbL103OpenOrig.apply(this, arguments);
      try { wbL103AfterOpen(); } catch (e) { console.warn("L103 工作台增强失败（不影响审核结果）", e); }
      return r;
    };
  }
  if (typeof renderWbFindings === "function") {
    var _wbL103RenderOrig = renderWbFindings;
    renderWbFindings = function () {
      var r = _wbL103RenderOrig.apply(this, arguments);
      try { wbL103Sync(); } catch (e) {}
      return r;
    };
  }
  if (typeof _wb106AfterDecision === "function") {
    var _wbL103DecideOrig = _wb106AfterDecision;
    _wb106AfterDecision = function (fid, decision) {
      var r = _wbL103DecideOrig.apply(this, arguments);
      try { wbL103AfterDecision(fid, decision); } catch (e) {}
      return r;
    };
  }
})();

/* ===========================================================================
 * L103 左栏图片预览（不依赖后端改动）：图片类文档走项目内真实文件接口
 *   GET /api/v1/projects/{cid}/documents/{did}/file（同权限 resolver，inline 返回原图）
 * 与 PDF 页图 / DOCX 解析文本共同构成左栏三类预览；支持缩放与双向滚动。
 * ========================================================================= */
var _WB_L103_IMG = { scale: 1, bound: false, docId: "", natural: "" };

function wbL103IsImageDoc(d) {
  var name = String((d && (d.filename || d.path)) || "").toLowerCase();
  var ext = name.indexOf(".") >= 0 ? name.split(".").pop() : "";
  return ["png", "jpg", "jpeg", "gif", "webp", "bmp"].indexOf(ext) >= 0;
}

function wbL103EnsureImageView() {
  var body = document.querySelector("#view-workbench.wb-l103 .wb-doc-card");
  if (!body) return null;
  var view = document.getElementById("wb-l103-imgview");
  if (view) return view;
  view = document.createElement("div");
  view.id = "wb-l103-imgview";
  view.className = "wb-l103-imgview";
  view.hidden = true;
  view.innerHTML = '<div class="wb-l103-imgbar">'
    + '<span class="wb-l103-imgtitle">图片预览</span>'
    + '<button type="button" class="btn" data-wb-l103-img="zoomout" title="缩小">−</button>'
    + '<button type="button" class="btn" id="wb-l103-imgzoom" data-wb-l103-img="reset" title="点击恢复 100%">100%</button>'
    + '<button type="button" class="btn" data-wb-l103-img="zoomin" title="放大">+</button>'
    + '<button type="button" class="btn" data-wb-l103-img="fit" title="适应宽度">适应宽度</button>'
    + '<span class="muted" id="wb-l103-imgmeta"></span></div>'
    + '<div class="wb-l103-imgscroll" id="wb-l103-imgscroll"><img id="wb-l103-img" alt="文档原图预览" draggable="false"></div>';
  body.appendChild(view);
  var img = view.querySelector("#wb-l103-img");
  img.addEventListener("load", function () {
    _WB_L103_IMG.natural = String(img.naturalWidth || 0) + "×" + String(img.naturalHeight || 0);
    wbL103ApplyImageScale();
    var meta = document.getElementById("wb-l103-imgmeta");
    if (meta) meta.textContent = (meta.dataset.name || "") + " · " + _WB_L103_IMG.natural;
  });
  img.addEventListener("error", function () {
    var meta = document.getElementById("wb-l103-imgmeta");
    if (meta) meta.textContent = "图片加载失败：请刷新或检查文件是否存在";
  });
  view.addEventListener("click", function (e) {
    var b = e.target && e.target.closest ? e.target.closest("[data-wb-l103-img]") : null;
    if (!b) return;
    var act = b.dataset.wbL103Img;
    if (act === "zoomin") _WB_L103_IMG.scale = Math.min(4, _WB_L103_IMG.scale + 0.25);
    else if (act === "zoomout") _WB_L103_IMG.scale = Math.max(0.25, _WB_L103_IMG.scale - 0.25);
    else if (act === "reset") _WB_L103_IMG.scale = 1;
    else if (act === "fit") { _WB_L103_IMG.scale = 1; _WB_L103_IMG.fit = true; }
    if (act === "zoomin" || act === "zoomout") _WB_L103_IMG.fit = false;
    wbL103ApplyImageScale();
  });
  return view;
}

function wbL103ApplyImageScale() {
  var img = document.getElementById("wb-l103-img");
  if (!img) return;
  var nw = Number(img.naturalWidth || 0);
  var sc = _WB_L103_IMG.fit ? 1 : Number(_WB_L103_IMG.scale || 1);
  if (nw > 0) img.style.width = Math.round(nw * sc) + "px";
  var z = document.getElementById("wb-l103-imgzoom");
  if (z) z.textContent = _WB_L103_IMG.fit ? "适应宽度" : (Math.round(sc * 100) + "%");
}

/* 单文件 DOCX 等场景下，文件切换/预览模式/Sheet 开关都不可见时收起空的预览工具栏，
   把高度让给文档预览（避免左栏出现一条空白工具条）。 */
function wbL103SyncDocToolbar() {
  var tb = document.querySelector("#view-workbench.wb-l103 .wb-doc-toolbar");
  if (!tb) return;
  var sels = ["#wb-file-tabs", "#wb-preview-modes", "#wb-sheet-switch"];
  var visible = sels.some(function (sel) {
    var el = tb.querySelector(sel);
    if (!el || el.hidden) return false;
    var cs = window.getComputedStyle(el);
    return cs.display !== "none" && cs.visibility !== "hidden" && el.offsetWidth > 0;
  });
  tb.style.display = visible ? "" : "none";
}

function wbL103AfterPreview() {
  if (!wbL103On()) return;
  try { wbL103SyncDocToolbar(); } catch (e) {}
  var view = wbL103EnsureImageView();
  if (!view) return;
  var frame = document.getElementById("wb-doc-frame");
  var docs = (typeof wbDocs !== "undefined" && wbDocs) || [];
  var cur = docs.find(function (d) { return String(d.id) === String(wbCurrentDoc); }) || docs[0] || null;
  if (!cur || !wbL103IsImageDoc(cur)) {
    view.hidden = true;
    if (frame) frame.style.display = "";
    _WB_L103_IMG.docId = "";
    return;
  }
  var pid = String(currentWb || "");
  var src = "/api/v1/projects/" + encodeURIComponent(pid) + "/documents/"
    + encodeURIComponent(cur.id) + "/file";
  if (_WB_L103_IMG.docId !== String(cur.id) || !document.getElementById("wb-l103-img").getAttribute("src")) {
    _WB_L103_IMG.docId = String(cur.id);
    _WB_L103_IMG.scale = 1; _WB_L103_IMG.fit = true; _WB_L103_IMG.natural = "";
    var img = document.getElementById("wb-l103-img");
    img.setAttribute("src", src);
    var meta = document.getElementById("wb-l103-imgmeta");
    if (meta) { meta.dataset.name = String(cur.filename || "图片"); meta.textContent = String(cur.filename || "图片") + " · 加载中…"; }
  }
  view.hidden = false;
  if (frame) frame.style.display = "none";
  try { wbL103ApplyImageScale(); } catch (e) {}
}

(function () {
  function _wbL103PatchPreview() {
    if (typeof loadWbPreview !== "function" || loadWbPreview.__wbL103Patched) return;
    var _wbL103PreviewOrig = loadWbPreview;
    loadWbPreview = async function () {
      var r = await _wbL103PreviewOrig.apply(this, arguments);
      try { wbL103AfterPreview(); } catch (e) { console.warn("L103 图片预览增强失败", e); }
      return r;
    };
    loadWbPreview.__wbL103Patched = true;
  }
  /* workbench_preview.js 在本文件之后加载：DOM 就绪后再打补丁（幂等）。 */
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", _wbL103PatchPreview);
  else _wbL103PatchPreview();
})();

/* ===========================================================================
 * L161 审核台交互 UI 专项（2026-11-25）——「交互 + 视觉」双角度修复
 *
 * 只做布局 / 层级 / 分组 / 文案 / 状态可读性，不删功能、不删按钮、不改后端：
 *  1) 问题队列头部信息层级：标题+计数与「待处理/全部」筛选同一行，新增/隐藏入口
 *     单独一行，批量工具条压缩为单行（勾选后同一行内变为可用的批量确认/误报/清空）；
 *     旧 T-106 三栏样式在 L103 两栏壳里残留成「q-main 263px 窄列 + 筛选悬浮右侧」，
 *     这里用显式分组修正，不依赖旧 grid。
 *  2) 裁决弹窗键盘可达：Esc 撤销（关闭且不写库）、Tab 焦点陷阱、关闭后焦点回到
 *     触发按钮/当前问题卡，避免键盘用户丢失位置。
 *  3) 反馈条不再 fixed 居中遮挡吸底主操作：L103 壳内插到吸底条上方（布局内元素），
 *     不覆盖「确认问题 / 报告签发」等按钮。
 *  4) 危险/负向操作分组：「确认」与「误报/退回补证/忽略」视觉分组，忽略为最右
 *     负向操作；吸底条把「报告签发」（不同域动作）与裁决组分隔。
 *  5)「下一条」真正选中下一条待处理问题（详情+吸底同步），减少一次点击；
 *     焦点由 _wb106AfterDecision 恢复到当前问题卡。
 *  6) 详情证据定位文案去重（「第1页 第1页」→「第1页」）；详情更紧凑，选中后
 *     问题清单仍留出可见区域。
 * ======================================================================== */
var _WB161 = { modalCleanup: null, headSynced: false, stickyGrouped: false };

/* 1) 队列头部：标题行（含计数 + 筛选）+ 入口行 + 批量行；批量条保持单行可读。 */
function wbL161SyncQueueHead(host, first) {
  if (!host || !first) return false;
  host.classList.add("wb161-q-head");
  first.classList.add("wb161-q-main");
  var title = _wb106First(".wb106-q-title", first);
  var filters = _wb106First(".wb-side-filters", host);
  if (title && filters && filters.parentNode !== title) {
    title.appendChild(filters);
    title.classList.add("wb161-q-titlebar");
  }
  var hint = _wb106First(".wb106-q-hint", first);
  if (hint) hint.classList.add("wb161-q-hint");
  var bar = document.getElementById("wb106-batch-bar");
  if (bar) bar.classList.add("wb161-batch-bar");
  _WB161.headSynced = true;
  return true;
}

/* 4) 吸底条分组：确认 | 误报/退回补证/忽略 | 报告签发（不同域动作） */
function wbL161SyncStickyGroups() {
  var host = document.getElementById("wb-l103-sticky-actions");
  if (!host) return false;
  host.classList.add("wb161-sticky-actions");
  if (_WB161.stickyGrouped) return true;
  _WB161.stickyGrouped = true;
  var btns = Array.prototype.slice.call(host.querySelectorAll("[data-wb-l103-decide]"));
  btns.forEach(function (b) {
    var d = String(b.dataset.wbL103Decide || "");
    b.classList.add("wb161-dec-btn");
    if (d === "confirmed") b.classList.add("wb161-dec-ok");
    else b.classList.add("wb161-dec-alt");
    if (d === "ignored") b.classList.add("wb161-dec-danger");
    /* L171 机读标记：吸底「确认问题」= 同屏唯一填充主操作；其余为次级。 */
    if (d === "confirmed") b.setAttribute("data-wb171-primary-role", "sticky");
    else b.setAttribute("data-wb171-secondary", "1");
  });
  var report = document.getElementById("wb-l103-goto-report");
  if (report) {
    report.classList.add("wb161-goto-report");
    if (report.parentNode === host) {
      var sep = document.createElement("span");
      sep.id = "wb161-sticky-report-sep";
      sep.className = "wb161-group-sep";
      sep.setAttribute("aria-hidden", "true");
      host.insertBefore(sep, report);
    }
  }
  return true;
}

/* L171-1) 主操作唯一化：给吸底条加机读类（保留既有 id/class/按钮契约，只加标记与视觉层级）。
   真实填充 primary 只保留吸底「确认问题」；卡片行内「确认」保留 .btn.primary 类但视觉次级；
   报告签发的 primary 在独立「报告与签发」分区（吸底只保留虚线次级入口）。 */
function wbL171SyncPrimaryRoles() {
  var host = document.getElementById("wb-l103-sticky-actions");
  if (!host) return false;
  host.classList.add("wb171-sticky-actions");
  var sticky = host.querySelector('[data-wb-l103-decide="confirmed"]');
  if (sticky) sticky.setAttribute("data-wb171-primary-role", "sticky");
  var report = document.getElementById("wb-l103-goto-report");
  if (report) report.classList.add("wb171-goto-report");
  try { wbL161SyncStickyGroups(); } catch (e) {}
  return true;
}

/* 3) 反馈条宿主：L103 两栏壳内（吸底条上方）；否则保持原 body 固定条。 */
function wbL161FeedbackHost() {
  if (typeof wbL103On !== "function" || !wbL103On()) return null;
  var shell = document.querySelector("#view-workbench .wb-l103-shell");
  var sticky = document.getElementById("wb-l103-sticky");
  if (!shell || !sticky || sticky.parentNode !== shell) return null;
  return { shell: shell, sticky: sticky };
}

/* 3b) 把反馈条放进 L103 右栏（吸底条上方），不再 fixed 居中遮挡底部主操作。 */
function wbL161PlaceFeedback(bar) {
  var host = wbL161FeedbackHost();
  if (host) {
    bar.classList.add("wb161-feedback-inline");
    host.shell.insertBefore(bar, host.sticky);
    return bar;
  }
  document.body.appendChild(bar);
  return bar;
}

/* 5) 「下一条」：选中下一条并同步详情/吸底，而不是只滚动高亮。 */
function wbL161SelectNext(card) {
  if (!card) return false;
  var fid = String(card.dataset.fid || "");
  if (!fid) return false;
  if (typeof wbL103On === "function" && wbL103On() && typeof wbL103Select === "function") {
    try { wbL103Select(fid); return true; } catch (e) { /* 回退到滚动高亮 */ }
  }
  return false;
}

/* ===========================================================================
 * L171 审核台 P2 收口（2026-11-26）——L161 报告 §4 的 4 项高价值 P2
 *
 * 边界：只改前端布局/交互/文案；不改后端（app/、server/ 零 diff）、不改 API、
 *       不改权限与判定；不删按钮、不加新业务动作；保留全部既有 id/class 契约。
 *
 *  1) 主操作唯一化：卡片行内「确认」保留 .btn.primary 类（L161 D1/L103 契约），
 *     视觉降级为次级描边；同屏唯一「填充 primary」= 吸底「确认问题」。
 *     分区联动：报告分区把裁决 primary 降级，让「签发报告」成为该区唯一主操作；
 *     审计分区无主操作。误报/退回补证/忽略始终为次级。
 *  2) 右栏加宽/自适应（style.css L171 段）：1440 保持预览明显大于右栏（≥1.25），
 *     右栏 min 400px（1440 实测 475px），1280 不挤压问题队列；≤1100 仍单列堆叠。
 *  3) 批量裁决弹层：数量 + 影响提示（逐条写审计/跳过不覆盖他人结论/可按条撤销）
 *     + 二次确认勾选 + 唯一主操作；批量误报必填统一原因；保留逐条撤销链路。
 *     真实用户点击（isTrusted）走弹层；程序化触发保留原生 confirm/prompt 兼容链路，
 *     不打断既有自动化和嵌入集成（见 L171 报告「兼容策略」）。
 *  4) 报告阻断原因结构化：把 report-status 的 reasons 数组按
 *     未复核 / 冲突 / 解析缺口 / unknown / 例外 / 其他 分组展示，
 *     原文（含内部字段名）折叠保留、按需展开；正文不拼一坨长句。
 * ======================================================================== */
var _WB171 = { batchMask: null, batchCleanup: null, gateReasonCache: {}, gateReasonSeq: 0 };

function wbL171Esc(s) {
  if (typeof esc === "function") return esc(s);
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}

/* -------- 3) 批量裁决弹层（批量确认 / 批量误报） -------- */
function wbL171BatchExtra(ids) {
  var want = {};
  (ids || []).forEach(function (id) { want[String(id)] = 1; });
  var list = (typeof wbFindings !== "undefined" && wbFindings ? wbFindings : [])
    .filter(function (f) { return f && want[String(f.id)]; });
  var sev = { critical: 0, warning: 0, suspected: 0, info: 0 };
  var others = 0;
  list.forEach(function (f) {
    var k = String(f.severity || "warning");
    if (sev[k] === undefined) others += 1; else sev[k] += 1;
  });
  var label = [];
  if (sev.critical) label.push("严重 " + sev.critical);
  if (sev.warning) label.push("一般 " + sev.warning);
  if (sev.suspected) label.push("提示 " + sev.suspected);
  if (sev.info) label.push("提示 " + sev.info);
  if (others) label.push("其他 " + others);
  return { list: list, sevText: label.join(" · ") };
}

function wbL171BatchOpen(decision, ids) {
  ids = (ids || []).map(String).filter(Boolean);
  if (!ids.length) { showToast("请先勾选要批量处理的问题", "err"); return null; }
  if (_wb106Readonly()) { showToast("只读：业务管理员不可裁决", "err"); return null; }
  wbL171BatchClose();
  var isFp = decision === "false_positive";
  var title = isFp ? "批量判为误报" : "批量确认问题";
  var runLabel = isFp ? "确认执行批量误报" : "确认执行批量确认";
  var n = ids.length;
  var extra = wbL171BatchExtra(ids);
  var preview = extra.list.slice(0, 5).map(function (f) {
    var sev = String(f.severity || "warning");
    var sevLabel = sev === "critical" ? "严重" : (sev === "suspected" || sev === "info" ? "提示" : "一般");
    return '<li><span class="wb171-batch-sev">' + wbL171Esc(sevLabel) + "</span>"
      + wbL171Esc(String(f.title || f.id || "")) + "</li>";
  }).join("");
  var more = n > 5 ? '<li class="wb171-batch-more">… 另有 ' + (n - 5) + " 条（结果条会逐条列出）</li>" : "";
  var mask = document.createElement("div");
  mask.id = "wb171-batch-modal";
  mask.className = "modal-mask wb171-batch-mask";
  mask.innerHTML = '<div class="modal wb171-batch-modal" role="dialog" aria-modal="true"'
    + ' aria-labelledby="wb171-batch-title" style="width:min(560px,calc(100vw - 24px))">'
    + '<div class="settings-head"><h3 id="wb171-batch-title">' + wbL171Esc(title) + "</h3>"
    + '<button type="button" class="ws-close" data-wb171-batch-close aria-label="关闭（取消）">×</button></div>'
    + '<div class="wb171-batch-summary">已选 <b id="wb171-batch-count">' + n + "</b> 条待处理问题"
    + (extra.sevText ? ' <span class="muted">' + wbL171Esc(extra.sevText) + "</span>" : "") + "</div>"
    + '<div class="wb171-batch-impact" id="wb171-batch-impact">'
    + '<div class="wb171-batch-impact-row"><span>落库与审计</span><b>逐条写入裁决与审计（' + n + " 条记录）</b></div>"
    + '<div class="wb171-batch-impact-row"><span>不覆盖</span><b>已被他人改判 / 已裁决的问题自动跳过，不覆盖他人结论</b></div>'
    + '<div class="wb171-batch-impact-row"><span>撤销</span><b>结果条提供「撤销本次批量」，按条恢复仍保持本次结论的问题</b></div>'
    + "</div>"
    + '<div class="wb171-batch-list-title">将要处理的问题（前 5 条）</div>'
    + '<ul class="wb171-batch-list">' + preview + more + "</ul>"
    + (isFp
      ? '<label class="wb171-batch-reason"><span>统一原因 <em class="req">*</em></span>'
        + '<textarea id="wb171-batch-reason" class="field" placeholder="必填：请说明为什么这批问题是误报（逐条写入审计，并进入规则进化反馈）"></textarea>'
        + "</label>"
      : "")
    + '<label class="wb171-batch-ack"><input type="checkbox" id="wb171-batch-ack">'
    + " 我已知晓影响：将对 <b>" + n + "</b> 条问题执行批量" + wbL171Esc(isFp ? "误报" : "确认")
    + "，并逐条写入审计</label>"
    + '<div id="wb171-batch-msg" class="muted" role="alert"></div>'
    + '<div class="actions wb171-batch-actions">'
    + '<button type="button" class="btn" data-wb171-batch-close>取消</button>'
    + '<button type="button" class="btn primary" id="wb171-batch-run" disabled>' + wbL171Esc(runLabel) + "</button>"
    + "</div></div>";
  document.body.appendChild(mask);
  _WB171.batchMask = mask;

  var run = mask.querySelector("#wb171-batch-run");
  var ack = mask.querySelector("#wb171-batch-ack");
  var reasonEl = mask.querySelector("#wb171-batch-reason");
  var msg = mask.querySelector("#wb171-batch-msg");
  var _closed = false;
  var _prevFocus = null;
  try { _prevFocus = document.activeElement; } catch (e) {}

  function close() {
    if (_closed) return;
    _closed = true;
    try { document.removeEventListener("keydown", onKey, true); } catch (e) {}
    try { mask.remove(); } catch (e) {}
    _WB171.batchMask = null;
    _WB171.batchCleanup = null;
    try {
      var back = document.getElementById("wb106-batch-confirm");
      var backFp = document.getElementById("wb106-batch-fp");
      var target = (decision === "confirmed" && back) ? back : (backFp || back);
      if (target && target.focus) target.focus();
      else if (_prevFocus && _prevFocus.focus) _prevFocus.focus();
    } catch (e) {}
  }
  function syncRun() {
    if (!run) return;
    var okAck = !!(ack && ack.checked);
    var okReason = !isFp || !!(reasonEl && String(reasonEl.value || "").trim());
    var ok = okAck && okReason;
    run.disabled = !ok;
    run.title = !okAck ? "请先勾选二次确认，再执行批量" + (isFp ? "误报" : "确认")
      : (!okReason ? "批量误报必须填写统一原因（逐条写入审计）" : "执行批量" + (isFp ? "误报" : "确认") + "（逐条写审计，可按条撤销）");
    if (msg) msg.textContent = !okAck ? "需先勾选上方二次确认。" : (!okReason ? "批量误报必须填写统一原因。" : "");
  }
  var onKey = function (e) {
    if (_closed) return;
    if (typeof KeyboardEvent !== "undefined" && !(e instanceof KeyboardEvent)) return;
    var k = String(e.key || "");
    if (k === "Escape") { e.preventDefault(); e.stopPropagation(); close(); return; }
    if (k !== "Tab") return;
    var nodes = Array.prototype.slice.call(
      mask.querySelectorAll('button, textarea, select, input, a[href], [tabindex]:not([tabindex="-1"])'))
      .filter(function (el) { return !el.disabled && el.offsetParent !== null; });
    if (!nodes.length) return;
    var first = nodes[0], last = nodes[nodes.length - 1], active = document.activeElement;
    if (e.shiftKey) {
      if (active === first || !mask.contains(active)) { e.preventDefault(); last.focus(); }
    } else if (active === last || !mask.contains(active)) { e.preventDefault(); first.focus(); }
  };
  mask.querySelectorAll("[data-wb171-batch-close]").forEach(function (b) {
    b.addEventListener("click", function (ev) { ev.preventDefault(); close(); });
  });
  mask.addEventListener("click", function (ev) { if (ev.target === mask) close(); });
  if (ack) ack.addEventListener("change", syncRun);
  if (reasonEl) reasonEl.addEventListener("input", syncRun);
  if (run) run.addEventListener("click", function (ev) {
    ev.preventDefault();
    if (run.disabled) return;
    var reason = reasonEl ? String(reasonEl.value || "").trim() : "";
    if (isFp && !reason) { syncRun(); return; }
    close();
    try { wb171BatchExecute(decision, reason, ids); } catch (e) { showToast("批量裁决失败：" + String((e && e.message) || e), "err"); }
  });
  document.addEventListener("keydown", onKey, true);
  _WB171.batchCleanup = close;
  syncRun();
  try { if (ack) ack.focus(); } catch (e) {}
  return mask;
}

function wbL171BatchClose() {
  try { if (_WB171.batchCleanup) _WB171.batchCleanup(); } catch (e) {}
  var old = document.getElementById("wb171-batch-modal");
  if (old) old.remove();
  _WB171.batchMask = null;
  _WB171.batchCleanup = null;
}

/* -------- 4) 报告阻断原因结构化（report-status.reasons → 分组） -------- */
function wbL171CleanGateReason(raw) {
  var text = "";
  try {
    if (typeof wbGateReasonText === "function") {
      var c = wbGateReasonText([String(raw || "")]);
      text = String((c && c.text) || "");
    }
  } catch (e) { text = ""; }
  if (!text) text = String(raw || "").trim();
  return text.replace(/\s+/g, " ").replace(/^[；;，,\s]+|[；;，,\s]+$/g, "").trim();
}

/* 纯函数：把 API reasons 数组分成 未复核 / 冲突 / 解析缺口 / unknown / 例外 / 其他。
   顺序即展示顺序；未知/空原因归「其他」。L171 测试直接在真实 Chrome 里调用它做单元断言。 */
function wbL171GateReasonGroups(reasons) {
  var defs = [
    { key: "unreviewed", label: "未复核", re: /未复核|待复核|未签发|高严重度.*未/ },
    { key: "conflict", label: "冲突", re: /冲突|翻转|不一致|矛盾|互斥|打架/ },
    { key: "parse", label: "解析缺口", re: /解析|缺口/ },
    { key: "unknown", label: "unknown", re: /unknown|未执行|执行失败|未完成执行|证据不足|无法判断|结果缺失|适用要求未完成/ },
    { key: "exception", label: "例外", re: /例外|授权|豁免|只读/ },
    { key: "other", label: "其他", re: null }
  ];
  var groups = defs.map(function (d) { return { key: d.key, label: d.label, items: [] }; });
  var list = Array.isArray(reasons) ? reasons : [];
  list.forEach(function (raw) {
    var text = wbL171CleanGateReason(raw);
    if (!text) return;
    var target = null;
    for (var i = 0; i < defs.length - 1; i++) {
      if (defs[i].re && defs[i].re.test(text)) { target = groups[i]; break; }
    }
    (target || groups[groups.length - 1]).items.push({ text: text, raw: String(raw || "") });
  });
  return groups.filter(function (g) { return g.items.length > 0; });
}

function wbL171GateReasonHtml(groups, rawList) {
  var total = groups.reduce(function (a, g) { return a + g.items.length; }, 0);
  var rawText = (rawList || []).map(String).join("；");
  var groupsHtml = groups.map(function (g) {
    var items = g.items.map(function (it) {
      return '<li class="wb171-gate-item" title="' + wbL171Esc(it.raw) + '">' + wbL171Esc(it.text) + "</li>";
    }).join("");
    return '<div class="wb171-gate-group" data-group="' + wbL171Esc(g.key) + '">'
      + '<span class="wb171-gate-tag">' + wbL171Esc(g.label) + ' <b>' + g.items.length + "</b></span>"
      + '<ul class="wb171-gate-list">' + items + "</ul></div>";
  }).join("");
  return '<div class="wb171-gate-head"><b>报告阻断原因</b>'
    + '<span class="wb171-gate-total">共 ' + total + " 条 · " + groups.length + " 类</span></div>"
    + '<div class="wb171-gate-groups">' + groupsHtml + "</div>"
    + '<details class="wb171-gate-raw" data-wb171-raw="1">'
    + "<summary>查看 API 原始原因（" + (rawList || []).length + " 条）</summary>"
    + '<pre class="wb171-gate-rawtext"></pre></details>'
    + '<div class="wb171-gate-rawdata" hidden data-wb171-rawtext="' + wbL171Esc(rawText) + '"></div>';
}

/* 把报告状态条里的 [data-gate-reason] 换成结构化分组；原文进折叠区（展开时才写入
   DOM 文本，避免「隐藏分区 innerText=textContent」把内部字段名带进正文，兼容 P2-3）。 */
function wbL171StructureGateReasons(box, pid) {
  box = box || document.querySelector("#wb-report-strip");
  if (!box) return false;
  var el = box.querySelector("[data-gate-reason]");
  if (!el) { try { box.classList.remove("wb171-has-gate"); } catch (e) {} return false; }
  if (el.getAttribute("data-wb171-structured") === "1") return false;
  var cache = _WB171.gateReasonCache[String(pid || "")];
  var raw = cache && cache.st && Array.isArray(cache.st.reasons) ? cache.st.reasons.slice() : null;
  if (!raw) {
    // 被动观测缺失时的回退：用渲染层保留的完整原文（title）兜底，不额外发请求
    var title = String(el.getAttribute("title") || "");
    if (!title) return false;
    raw = title.split("；").filter(function (x) { return String(x || "").trim(); });
  }
  if (!raw.length) return false;
  var groups = wbL171GateReasonGroups(raw);
  if (!groups.length) return false;
  var host = document.createElement("div");
  host.className = "wb171-gate-reason";
  host.id = "wb171-gate-reason";
  host.setAttribute("data-gate-reason", "1");
  host.setAttribute("data-wb171-structured", "1");
  host.setAttribute("data-wb171-raw-count", String(raw.length));
  host.setAttribute("title", raw.map(String).join("；"));
  host.innerHTML = wbL171GateReasonHtml(groups, raw);
  var det = host.querySelector("details[data-wb171-raw]");
  if (det) {
    det.addEventListener("toggle", function () {
      if (!det.open) return;
      var pre = det.querySelector("pre.wb171-gate-rawtext");
      var data = host.querySelector("[data-wb171-rawtext]");
      if (pre && !String(pre.textContent || "").trim()) {
        pre.textContent = String((data && data.getAttribute("data-wb171-rawtext")) || host.getAttribute("title") || "");
      }
    });
  }
  el.replaceWith(host);
  try { box.classList.add("wb171-has-gate"); } catch (e) {}
  _WB171.gateReasonSeq += 1;
  return true;
}

(function () {
  function _install() {
    /* 4a) 被动观察 report-status 响应（只读观测，不改请求/响应），拿 reasons 数组 */
    if (!window.__wb171FetchObserved && typeof window.fetch === "function") {
      window.__wb171FetchObserved = true;
      var _f = window.fetch;
      window.fetch = function (input, init) {
        var p = _f.apply(this, arguments);
        try {
          var u = String(typeof input === "string" ? input : ((input && input.url) || ""));
          var m = u.match(/\/api\/v1\/reviews\/([^\/?#]+)\/report-status(?:[?#]|$)/);
          if (m && p && typeof p.then === "function") {
            var _pid = "";
            try { _pid = decodeURIComponent(m[1]); } catch (e) { _pid = m[1]; }
            p.then(function (resp) {
              try {
                if (!resp || !resp.ok || !resp.clone) return;
                resp.clone().json().then(function (st) {
                  _WB171.gateReasonCache[String(_pid)] = { st: st || {}, at: Date.now() };
                  try { wbL171StructureGateReasons(document.querySelector("#wb-report-strip"), _pid); } catch (e) {}
                }).catch(function () {});
              } catch (e) {}
            }).catch(function () {});
          }
        } catch (e) {}
        return p;
      };
    }
    /* 4b) 包装报告状态渲染：状态条渲染完后立即结构化阻断原因（唯一入口，不再重复请求） */
    if (typeof renderWbReportStatus === "function" && !renderWbReportStatus.__wb171Patched) {
      var _orig = renderWbReportStatus;
      renderWbReportStatus = async function (pid) {
        var r = await _orig.apply(this, arguments);
        try { wbL171StructureGateReasons(document.querySelector("#wb-report-strip"), pid); } catch (e) {
          console.warn("L171 报告阻断原因结构化失败（不影响报告状态）", e);
        }
        return r;
      };
      renderWbReportStatus.__wb171Patched = true;
    } else if (typeof renderWbReportStatus !== "function" && !window.__wb171ReportRetry) {
      /* workbench_report.js 尚未就绪（异步加载/缓存顺序异常）：短轮询补打补丁 */
      window.__wb171ReportRetry = true;
      var _tries = 0;
      var _timer = setInterval(function () {
        _tries += 1;
        try {
          if (typeof renderWbReportStatus === "function") {
            clearInterval(_timer);
            window.__wb171ReportRetry = false;
            _install();
          } else if (_tries > 40) {
            clearInterval(_timer);
            window.__wb171ReportRetry = false;
          }
        } catch (e) { clearInterval(_timer); window.__wb171ReportRetry = false; }
      }, 100);
    }
    /* 1) 主操作机读标记（吸底唯一 primary；卡片/负向仅标记） */
    try { wbL171SyncPrimaryRoles(); } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", _install);
  else _install();
})();
