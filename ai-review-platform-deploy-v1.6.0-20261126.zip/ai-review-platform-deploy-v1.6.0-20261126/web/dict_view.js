/* ===================== 企业词典（从 app.js 拆出） ===================== */
/*
 * 企业词典视图独立文件，供 index.html 直接加载，也供 admin.html/reviewer.html
 * 由 app.js 动态兜底加载。依赖 app.js 的全局 helper：
 * esc / showToast / confirmAction / showView / currentRole。
 * 本文件先于 app.js 加载；函数体只在 app.js 初始化完成后执行，helper 按运行时解析。
 * 所有词典列表、新增、编辑、删除、确认、迁移和只读角色控制实现只保留在本文件，
 * 禁止在 app.js 复制第二份实现。
 */

/* ===================== 企业词典 ===================== */
/*
 * 企业业务词典维护页。
 * - 列表/关键词/状态：GET /api/v1/terms；
 * - 新增：POST /api/v1/terms；编辑：POST /api/v1/terms/<id>/update；
 * - 删除：POST /api/v1/terms/<id>/delete；确认：POST /api/v1/terms/<id>/confirm；
 * - 旧 ontology_terms：GET /api/v1/terms/migrate/preview + POST /api/v1/terms/migrate；
 * - type/unit/relations/not_equal 一次性提交；审核员进入本页只读，迁移卡片不渲染。
 * 所有写操作在发请求前先做角色拦截，reviewer 直接调用函数也不会发 POST。
 */
let dictState = {
  items: [], loading: false, loaded: false, error: "", query: "", status: "", reqSeq: 0,
  editingId: "", editingScope: "",
  migration: { preview: null, loading: false, error: "", result: null, reqSeq: 0 },
};
let dictBound = false;

function termsRole() {
  const role = currentRole || (typeof window !== "undefined" ? window.__role : "") || "";
  return String(role || "");
}
function termsCanView() {
  // 企业词典属于本体域：只从本体建模进入，业务管理员维护；审核员没有独立入口。
  return termsRole() === "admin";
}
function termsCanWrite() {
  return termsCanView();
}
function termsIsEffective(x) {
  return ["confirmed", "active"].includes(String((x && x.status) || "").toLowerCase());
}
function termsNameKey(value) {
  return String(value == null ? "" : value).replace(/[\s\u3000]+/g, "").toLowerCase();
}
function termsAsList(value) {
  if (Array.isArray(value)) return value.map(x => String(x == null ? "" : x).trim()).filter(Boolean);
  if (typeof value === "string") return termsParseNameList(value);
  return [];
}
function termsAsRelations(value) {
  if (Array.isArray(value)) return value.filter(x => x && typeof x === "object" && !Array.isArray(x));
  if (typeof value === "string") {
    const parsed = termsParseRelations(value);
    return parsed.items || [];
  }
  return [];
}
function termsParseNameList(text) {
  const out = [], seen = new Set();
  String(text || "").split(/[,，;；|、\n\r\t]+/).forEach(raw => {
    const s = raw.trim();
    if (!s) return;
    const key = termsNameKey(s);
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push(s);
  });
  return out;
}
function termsNormalizeRelations(values) {
  const out = [], seen = new Set();
  for (let i = 0; i < values.length; i++) {
    const raw = values[i];
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return { error: `关系第 ${i + 1} 项必须是对象` };
    }
    const type = String(raw.type || raw.rel || "").trim();
    const to = String(raw.to || raw.target || raw.value || "").trim();
    if (!type || !to) return { error: `关系第 ${i + 1} 项缺少 type 或 to` };
    const sig = type + "\u0000" + to;
    if (seen.has(sig)) continue;
    seen.add(sig);
    out.push({ type: type, to: to });
  }
  return { items: out };
}
function termsParseRelations(text) {
  const raw = String(text || "").trim();
  if (!raw) return { items: [] };
  if (raw.charAt(0) === "[" || raw.charAt(0) === "{") {
    let data;
    try { data = JSON.parse(raw); }
    catch (e) { return { error: "关系 JSON 解析失败，请检查格式" }; }
    if (data && !Array.isArray(data) && Array.isArray(data.relations)) data = data.relations;
    if (!Array.isArray(data)) return { error: "关系 JSON 必须是对象数组" };
    return termsNormalizeRelations(data);
  }
  const lines = raw.split(/\n|\r|；|;/).map(x => x.trim()).filter(Boolean);
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^(.+?)\s*(?:->|→|=>|=|：|:)\s*(.+)$/);
    if (!m) return { error: `关系第 ${i + 1} 行格式错误，应为“类型=目标”，例如“属于=采购金额”` };
    const type = m[1].trim(), to = m[2].trim();
    if (!type || !to) return { error: `关系第 ${i + 1} 行类型和目标都不能为空` };
    out.push({ type: type, to: to });
  }
  return termsNormalizeRelations(out);
}
function termsBuildCreatePayload(values) {
  const v = values || {};
  const name = String(v.name || "").trim();
  const definition = String(v.definition || "").trim();
  if (name.length < 2) return { ok: false, error: "术语名称至少 2 个字" };
  if (definition.length < 4) return { ok: false, error: "术语定义至少 4 个字" };
  const synonyms = termsParseNameList(v.synonyms);
  const notEqual = termsParseNameList(v.notEqual);
  const relations = termsParseRelations(v.relations);
  if (relations.error) return { ok: false, error: relations.error };
  if (notEqual.some(x => termsNameKey(x) === termsNameKey(name))) {
    return { ok: false, error: "不等同不能包含术语本身" };
  }
  const synKeys = new Set(synonyms.map(termsNameKey));
  const conflict = notEqual.filter(x => synKeys.has(termsNameKey(x)));
  if (conflict.length) return { ok: false, error: "同义词与不等同冲突：" + conflict.join("、") };
  return {
    ok: true,
    payload: {
      name: name,
      definition: definition,
      synonyms: synonyms,
      not_equal: notEqual,
      source: String(v.source || "").trim(),
      scope: String(v.scope || "").trim(),
      entity_type: String(v.type || "").trim(),
      unit: String(v.unit || "").trim(),
      relations: relations.items,
    },
  };
}
async function termsReadJson(response) {
  try {
    const data = await response.json();
    return data && typeof data === "object" ? data : {};
  } catch (e) {
    return {};
  }
}
function termsErrorMessage(status, data, fallback) {
  if (data && typeof data.error === "string" && data.error) return data.error;
  if (status === 401) return "登录已失效，请重新登录";
  if (status === 403) return "当前角色无权执行该操作";
  if (status === 404) return "术语不存在或已被删除";
  if (status >= 500) return "服务暂时不可用，请稍后重试";
  return fallback || "操作失败";
}
function termsConflictCount(data) {
  if (Array.isArray(data && data.conflicts) && data.conflicts.length) return data.conflicts.length;
  const ap = data && data.projection && data.projection.alias_projection;
  return Array.isArray(ap && ap.conflicts) ? ap.conflicts.length : 0;
}
function termsConflictNote(actionLabel, data) {
  const n = termsConflictCount(data);
  if (!n) return "";
  const first = (Array.isArray(data && data.conflicts) ? data.conflicts : [])
    .slice(0, 2)
    .map(x => String((x && (x.value || x.alias || x.detail || x.kind)) || "").trim())
    .filter(Boolean)
    .join("、");
  return `${actionLabel}，但有 ${n} 条同义词/不等同冲突未投影为别名${first ? `（${first}）` : ""}；请在“冲突提醒”中处理后修正术语并保存。`;
}
function setTermsPageError(msg) {
  dictState.error = msg || "";
  const el = document.getElementById("dict-error");
  if (el) { el.textContent = msg || ""; el.hidden = !msg; }
}
function setTermsFormError(msg) {
  const el = document.getElementById("dict-form-msg");
  if (el) { el.textContent = msg || ""; el.hidden = !msg; }
  if (msg) showToast(msg, "err");
}
function termsStatusMeta(status) {
  const s = String(status || "").toLowerCase();
  if (s === "confirmed") return { label: "已确认", cls: "published", confirmed: true };
  if (s === "active") return { label: "已启用（历史）", cls: "published", confirmed: true };
  if (s === "draft") return { label: "草稿", cls: "draft", confirmed: false };
  if (s === "candidate") return { label: "待确认", cls: "r", confirmed: false };
  return { label: status || "未知", cls: "draft", confirmed: false };
}
function termsRelationLines(value) {
  return termsAsRelations(value)
    .map(r => `${String(r.type || "").trim()}=${String(r.to || r.target || "").trim()}`)
    .filter(x => x !== "=")
    .join("\n");
}
function termsFindTerm(termId) {
  const id = String(termId || "").trim();
  if (!id) return null;
  return (dictState.items || []).find(x => String(x.id || x.term_id || "") === id) || null;
}
function termsSelfConflicts(item) {
  const neq = new Set(termsAsList(item && item.not_equal).map(termsNameKey));
  return termsAsList(item && item.synonyms).filter(x => neq.has(termsNameKey(x)));
}
function termsSetFormValue(id, value) {
  const el = document.getElementById(id);
  if (el) el.value = value == null ? "" : String(value);
}
function termsSearchText(x) {
  const item = x || {};
  return [
    item.name, item.definition, item.entity_type, item.unit, item.source, item.scope,
    termsAsList(item.synonyms).join(" "),
    termsAsList(item.not_equal).join(" "),
    termsAsRelations(item.relations).map(r => String((r.type || "") + " " + (r.to || r.target || ""))).join(" "),
  ].filter(Boolean).join(" ");
}
function termsFilterItems(items, query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return (items || []).slice();
  return (items || []).filter(x => termsSearchText(x).toLowerCase().includes(q));
}
function termsListHtml(items) {
  const canWrite = termsCanWrite();
  const rows = (items || []).map((x, i) => {
    const meta = termsStatusMeta(x.status);
    const id = String(x.id || x.term_id || "");
    const synonyms = termsAsList(x.synonyms);
    const notEqual = termsAsList(x.not_equal);
    const selfConflicts = termsSelfConflicts(x);
    const relations = termsAsRelations(x.relations);
    const typeUnit = [x.entity_type, x.unit].filter(Boolean).map(v => esc(v)).join(" / ") || '<span class="muted">—</span>';
    let op = '<span class="muted">只读</span>';
    if (canWrite) {
      const bits = [];
      if (id) bits.push(`<button type="button" class="btn" data-dict-edit="${esc(id)}">编辑</button>`);
      if (meta.confirmed) bits.push('<span class="muted">已确认</span>');
      else if (id) bits.push(`<button type="button" class="btn primary" data-dict-confirm="${esc(id)}">确认</button>`);
      if (id) bits.push(`<button type="button" class="btn" data-dict-delete="${esc(id)}" data-dict-name="${esc(x.name || "")}" style="color:#B91C1C;border-color:#F5C2C0">删除</button>`);
      op = `<div class="actions" style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end">${bits.join("")}</div>`;
    }
    return `<tr data-dict-id="${esc(id)}">
      <td class="muted">${i + 1}</td>
      <td><b>${esc(x.name || "")}</b><div class="muted" style="font-size:12px;margin-top:3px">${esc(x.definition || "—")}</div>${x.term_key ? `<div class="muted" style="font-size:11px;margin-top:2px">${esc(x.term_key)}</div>` : ""}</td>
      <td>${typeUnit}</td>
      <td class="muted">${esc(synonyms.join("、") || "—")}</td>
      <td>${notEqual.length ? `<span style="color:#B91C1C">${esc(notEqual.join("、"))}</span>` : '<span class="muted">—</span>'}${selfConflicts.length ? `<div style="color:#B91C1C;font-size:11px;margin-top:3px" title="同义词与不等同自相矛盾；确认后不投影这些别名">同义词/不等同冲突：${esc(selfConflicts.join("、"))}</div>` : ""}</td>
      <td class="muted">${relations.length ? relations.map(r => `${esc(r.type || "关系")} → ${esc(r.to || r.target || "")}`).join("<br>") : "—"}</td>
      <td class="muted">${esc(x.source || "—")}${x.scope ? `<div style="font-size:11px">${esc(x.scope)}</div>` : ""}</td>
      <td><span class="pill ${meta.cls}">${esc(meta.label)}</span></td>
      <td>${op}</td>
    </tr>`;
  }).join("");
  return `<div class="table-wrap" style="overflow:auto"><table class="table" aria-label="企业词典术语列表">
    <thead><tr><th style="width:48px">序号</th><th>术语 / 定义</th><th>类型 / 单位</th><th>同义词</th><th>不等同</th><th>关系</th><th>来源</th><th>状态</th><th style="width:168px">操作</th></tr></thead>
    <tbody>${rows}</tbody></table></div>`;
}
function renderTermsPage() {
  applyTermsRole();
  const items = termsFilterItems(dictState.items, dictState.query);
  const pending = dictState.items.filter(x => !termsStatusMeta(x.status).confirmed).length;
  const effective = dictState.items.filter(termsIsEffective).length;
  const notEqualTotal = dictState.items.reduce((n, x) => n + termsAsList(x.not_equal).length, 0);
  const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = String(value); };
  setText("dict-kpi-total", dictState.items.length);
  setText("dict-kpi-draft", pending);
  setText("dict-kpi-confirmed", effective);
  setText("dict-kpi-neq", notEqualTotal);
  const countEl = document.getElementById("dict-count");
  if (countEl) countEl.textContent = dictState.loading ? "加载中…" : `显示 ${items.length} / 共 ${dictState.items.length} 条`;
  const errEl = document.getElementById("dict-error");
  if (errEl) { errEl.textContent = dictState.error || ""; errEl.hidden = !dictState.error; }
  const statusSel = document.getElementById("dict-status");
  if (statusSel && statusSel.value !== dictState.status) statusSel.value = dictState.status;
  const list = document.getElementById("dict-list");
  if (!list) return;
  if (!termsCanView()) { list.innerHTML = '<div class="empty">当前角色无权查看企业词典</div>'; return; }
  if (dictState.loading && !dictState.items.length) { list.innerHTML = '<div class="empty">加载中…</div>'; return; }
  if (!items.length) {
    list.innerHTML = dictState.error
      ? '<div class="empty">术语读取失败，请点击“刷新”重试</div>'
      : `<div class="empty">${dictState.query ? "没有匹配的术语" : (dictState.status ? "当前状态筛选下没有术语" : "当前空间还没有术语，点击“新增术语”创建第一条")}</div>`;
    return;
  }
  list.innerHTML = termsListHtml(items);
  list.querySelectorAll("[data-dict-confirm]").forEach(btn => {
    btn.addEventListener("click", () => confirmTermsTerm(btn.dataset.dictConfirm, btn));
  });
  list.querySelectorAll("[data-dict-edit]").forEach(btn => {
    btn.addEventListener("click", () => openTermsEditDrawer(btn.dataset.dictEdit));
  });
  list.querySelectorAll("[data-dict-delete]").forEach(btn => {
    btn.addEventListener("click", () => deleteTermsTerm(btn.dataset.dictDelete, btn.dataset.dictName, btn));
  });
}
function applyTermsRole() {
  const canView = termsCanView(), canWrite = termsCanWrite();
  const newBtn = document.getElementById("dict-new");
  if (newBtn) newBtn.hidden = !canWrite;
  document.querySelectorAll("#view-terms [data-dict-write]").forEach(el => { el.hidden = !canWrite; });
  const note = document.getElementById("dict-readonly-note");
  if (note) note.hidden = !canView || canWrite;
  if (!canWrite) closeTermsDrawer();
}
function ensureTermsUI() {
  let section = document.getElementById("view-terms");
  if (!section) {
    const host = document.querySelector("main.content") || document.querySelector(".content") || document.querySelector("main") || document.body;
    section = document.createElement("section");
    section.className = "view";
    section.id = "view-terms";
    section.hidden = true;
    section.innerHTML = `
      <div class="card">
        <div class="card-head" style="align-items:flex-start;gap:12px;flex-wrap:wrap">
          <div><h2>企业词典</h2><div class="muted" style="margin-top:4px">维护当前工作空间内会改变审核结论的业务术语；确认后按本体投影规则生效。同义词与不等同冲突时，术语可确认，但冲突别名不会归一。</div></div>
          <div class="actions"><button type="button" class="btn" id="dict-refresh">刷新</button><button type="button" class="btn primary" id="dict-new" data-dict-write>新增术语</button></div>
        </div>
        <div id="dict-readonly-note" class="muted" role="status" style="margin:10px 0;padding:8px 10px;background:#F7F8FA;border-radius:6px" hidden>审核员只读：可查看和搜索企业词典，新增与确认由业务管理员执行。</div>
        <div class="kpis" style="grid-template-columns:repeat(4,minmax(0,1fr))">
          <div class="kpi"><b id="dict-kpi-total">—</b><span>术语总数</span></div>
          <div class="kpi"><b id="dict-kpi-draft">—</b><span>待确认</span></div>
          <div class="kpi"><b id="dict-kpi-confirmed">—</b><span>已生效</span></div>
          <div class="kpi"><b id="dict-kpi-neq">—</b><span>不等同约束</span></div>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:4px 0 10px">
          <input id="dict-search" class="field" style="flex:1;min-width:240px" placeholder="搜索名称、定义、同义词、类型、单位、不等同…" aria-label="搜索企业词典">
          <select id="dict-status" class="field" aria-label="按状态筛选词典">
            <option value="">全部状态</option><option value="draft">草稿</option><option value="confirmed">已确认</option><option value="active">历史启用</option>
          </select>
          <span id="dict-count" class="muted" aria-live="polite"></span>
        </div>
        <div id="dict-error" class="ws-msg" role="alert" style="margin:8px 0" hidden></div>
        <div id="dict-list" aria-live="polite"><div class="empty">加载中…</div></div>
      </div>
      <div class="card" id="dict-migrate-card" data-dict-write style="margin-top:16px">
        <div class="card-head" style="align-items:flex-start;gap:12px;flex-wrap:wrap">
          <div><h3>旧 ontology_terms 迁移</h3><div class="muted" style="margin-top:4px">把旧工作空间 settings_json.ontology_terms 里的术语/别名幂等迁入企业词典。先预览，确认范围后再执行；已确认术语不会被覆盖，预览不写库。</div></div>
          <div class="actions" style="flex-wrap:wrap">
            <label class="muted" style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="dict-migrate-all"> 本租户全部空间</label>
            <button type="button" class="btn" id="dict-migrate-preview">预览迁移</button>
            <button type="button" class="btn primary" id="dict-migrate-run" disabled>执行迁移</button>
          </div>
        </div>
        <div id="dict-migrate-msg" class="ws-msg" role="alert" style="margin:8px 0" hidden></div>
        <div id="dict-migrate-out" class="muted" style="font-size:12px">尚未预览。预览只统计旧数据，不会写数据库；执行后重复迁移会幂等跳过已存在内容。</div>
      </div>
      <div id="dict-drawer" class="drawer-mask" role="dialog" aria-modal="true" aria-labelledby="dict-drawer-title" aria-hidden="true" hidden>
        <div class="drawer" style="width:min(620px,96vw)">
          <div class="drawer-head"><h3 id="dict-drawer-title">新增企业术语</h3><button type="button" class="ws-close" id="dict-drawer-close" aria-label="关闭企业词典抽屉">×</button></div>
          <form id="dict-form" style="flex:1;overflow:auto;padding:16px 20px;margin:0">
            <div class="settings-grid">
              <label class="np-field wide"><span>术语名称 *（至少 2 字）</span><input id="dict-name" name="name" class="field" maxlength="80" autocomplete="off" placeholder="例如：整改关闭"></label>
              <label class="np-field wide"><span>定义 *（至少 4 字）</span><textarea id="dict-definition" name="definition" class="field" rows="3" maxlength="500" style="height:auto;min-height:64px;resize:vertical" placeholder="说明这个术语在业务中的含义和判别口径"></textarea></label>
              <label class="np-field"><span>类型（type）</span><input id="dict-type" name="entity_type" class="field" maxlength="40" placeholder="例如：金额 / 日期 / 状态"></label>
              <label class="np-field"><span>单位（unit）</span><input id="dict-unit" name="unit" class="field" maxlength="20" placeholder="例如：元 / 天 / %"></label>
              <label class="np-field wide"><span>同义词（逗号分隔）</span><input id="dict-synonyms" name="synonyms" class="field" placeholder="例如：结案、整改闭环"></label>
              <label class="np-field wide"><span>不等同（逗号分隔，不能当同义词归一）</span><input id="dict-not-equal" name="not_equal" class="field" placeholder="例如：提交关闭申请、受理"></label>
              <label class="np-field wide"><span>关系（每行“类型=目标”，如“属于=采购金额”；也可粘贴 JSON 数组）</span><textarea id="dict-relations" name="relations" class="field" rows="3" style="height:auto;min-height:64px;resize:vertical" placeholder="属于=采购金额&#10;取值来源=合同"></textarea></label>
              <label class="np-field wide"><span>来源（选填）</span><input id="dict-source" name="source" class="field" maxlength="120" placeholder="制度条款、合同或术语出处"></label>
            </div>
            <div id="dict-edit-hint" class="muted" style="margin-top:10px;padding:8px 10px;background:#F7F8FA;border-radius:6px;font-size:12px" hidden></div>
            <div id="dict-form-msg" class="ws-msg" role="alert" style="margin-top:10px" hidden></div>
            <div class="actions" style="justify-content:flex-end;margin-top:14px"><button type="button" class="btn" id="dict-cancel">取消</button><button type="submit" class="btn primary" id="dict-save" data-dict-write>保存为草稿</button></div>
          </form>
        </div>
      </div>`;
    host.appendChild(section);
  }
  // 企业词典是本体的一部分：不再注入左侧独立菜单，入口放在本体页面。
  const ontoEntry = document.getElementById("onto-terms");
  if (ontoEntry && !ontoEntry.dataset.bound) {
    ontoEntry.dataset.bound = "1";
    ontoEntry.addEventListener("click", (e) => { e.preventDefault(); showView("terms"); });
  }
  bindTermsUi();
  applyTermsRole();
}
function bindTermsUi() {
  if (dictBound) return;
  dictBound = true;
  const on = (id, event, fn) => { const el = document.getElementById(id); if (el) el.addEventListener(event, fn); };
  on("dict-new", "click", openTermsDrawer);
  on("dict-refresh", "click", () => { loadTermsPage(); });
  on("dict-search", "input", (e) => { dictState.query = e.target.value; renderTermsPage(); });
  on("dict-status", "change", (e) => { dictState.status = e.target.value; loadTermsPage(); });
  on("dict-form", "submit", (e) => { e.preventDefault(); saveTermsTerm(); });
  on("dict-cancel", "click", closeTermsDrawer);
  on("dict-drawer-close", "click", closeTermsDrawer);
  on("dict-migrate-preview", "click", () => { previewTermsMigration(); });
  on("dict-migrate-run", "click", () => { runTermsMigration(); });
  on("dict-migrate-all", "change", () => {
    dictState.migration.reqSeq++;
    dictState.migration.preview = null;
    const run = document.getElementById("dict-migrate-run");
    if (run) run.disabled = true;
    const previewBtn = document.getElementById("dict-migrate-preview");
    if (previewBtn) { previewBtn.disabled = false; previewBtn.textContent = "预览迁移"; }
    const out = document.getElementById("dict-migrate-out");
    if (out) { out.classList.add("muted"); out.style.fontSize = "12px"; out.textContent = "迁移范围已变更，请重新预览后再执行。"; }
    setTermsMigrationError("");
  });
  const mask = document.getElementById("dict-drawer");
  if (mask) mask.addEventListener("click", (e) => { if (e.target === mask) closeTermsDrawer(); });
  document.addEventListener("keydown", (e) => {
    const drawer = document.getElementById("dict-drawer");
    if (e.key === "Escape" && drawer && !drawer.hidden) closeTermsDrawer();
  });
}
function openTermsForm(term) {
  ensureTermsUI();
  if (!termsCanWrite()) {
    setTermsPageError("审核员只读：企业词典由业务管理员维护和确认。");
    showToast("审核员只读，不能维护企业词典", "err");
    return false;
  }
  const mask = document.getElementById("dict-drawer");
  if (!mask) return false;
  const editing = !!(term && (term.id || term.term_id));
  dictState.editingId = editing ? String(term.id || term.term_id) : "";
  dictState.editingScope = editing ? String(term.scope || "") : "";
  const title = document.getElementById("dict-drawer-title");
  if (title) title.textContent = editing ? `编辑企业术语${term.name ? "：" + term.name : ""}` : "新增企业术语";
  const saveBtn = document.getElementById("dict-save");
  if (saveBtn) saveBtn.textContent = editing ? "保存修改" : "保存为草稿";
  const hint = document.getElementById("dict-edit-hint");
  if (hint) {
    hint.hidden = !editing;
    hint.textContent = editing
      ? (termsIsEffective(term.status)
        ? "该术语已确认：保存后保留原确认人与确认时间，并重新投影到本体（冲突别名只记录、不投影）；删除前需二次确认。"
        : "修改草稿不会自动确认；确认后才会进入本体投影（同义词与不等同冲突时只记录冲突，不投影该别名）。")
      : "";
  }
  termsSetFormValue("dict-name", editing ? term.name : "");
  termsSetFormValue("dict-definition", editing ? term.definition : "");
  termsSetFormValue("dict-type", editing ? term.entity_type : "");
  termsSetFormValue("dict-unit", editing ? term.unit : "");
  termsSetFormValue("dict-synonyms", editing ? termsAsList(term.synonyms).join("、") : "");
  termsSetFormValue("dict-not-equal", editing ? termsAsList(term.not_equal).join("、") : "");
  termsSetFormValue("dict-relations", editing ? termsRelationLines(term.relations) : "");
  termsSetFormValue("dict-source", editing ? term.source : "");
  setTermsFormError("");
  mask.hidden = false;
  mask.setAttribute("aria-hidden", "false");
  setTimeout(() => document.getElementById("dict-name")?.focus(), 30);
  return true;
}
function openTermsDrawer() {
  return openTermsForm(null);
}
function openTermsEditDrawer(termId) {
  const term = termsFindTerm(termId);
  if (!term) {
    setTermsPageError("术语不存在或列表已刷新，请刷新后重试");
    return false;
  }
  return openTermsForm(term);
}
function closeTermsDrawer() {
  dictState.editingId = "";
  dictState.editingScope = "";
  const mask = document.getElementById("dict-drawer");
  if (!mask || mask.hidden) return false;
  mask.hidden = true;
  mask.setAttribute("aria-hidden", "true");
  return true;
}
async function saveTermsTerm() {
  const editingId = String(dictState.editingId || "").trim();
  if (!termsCanWrite()) { setTermsFormError(editingId ? "审核员只读，不能编辑术语" : "审核员只读，不能新增术语"); return false; }
  const values = {
    name: document.getElementById("dict-name")?.value || "",
    definition: document.getElementById("dict-definition")?.value || "",
    type: document.getElementById("dict-type")?.value || "",
    unit: document.getElementById("dict-unit")?.value || "",
    synonyms: document.getElementById("dict-synonyms")?.value || "",
    notEqual: document.getElementById("dict-not-equal")?.value || "",
    relations: document.getElementById("dict-relations")?.value || "",
    source: document.getElementById("dict-source")?.value || "",
    scope: editingId ? dictState.editingScope : "",
  };
  const built = termsBuildCreatePayload(values);
  if (!built.ok) { setTermsFormError(built.error); return false; }
  const btn = document.getElementById("dict-save");
  if (btn) { btn.disabled = true; btn.textContent = "保存中…"; }
  setTermsFormError("");
  try {
    const url = editingId ? `/api/v1/terms/${encodeURIComponent(editingId)}/update` : "/api/v1/terms";
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(built.payload),
    });
    const d = await termsReadJson(r);
    if (!r.ok || (d && (d.error || d.ok === false))) {
      setTermsFormError(termsErrorMessage(r.status, d, editingId ? "保存修改失败" : "保存失败"));
      return false;
    }
    const note = termsConflictNote(editingId ? "术语已更新" : "术语已保存", d);
    showToast(editingId
      ? (d && d.changed === false ? "术语没有变化" : "术语已更新；已确认术语保留确认记录并按投影规则处理")
      : "术语已保存为草稿；确认后按本体投影规则生效");
    invalidateTermsMigrationPreview("词典已变更，迁移计数可能已变化，请重新预览。");
    closeTermsDrawer();
    dictState.query = ""; dictState.status = "";
    const search = document.getElementById("dict-search"); if (search) search.value = "";
    const statusSel = document.getElementById("dict-status"); if (statusSel) statusSel.value = "";
    await loadTermsPage();
    if (note) { setTermsPageError(note); showToast(note, "err"); }
    return true;
  } catch (e) {
    setTermsFormError("保存失败：网络异常，请稍后重试");
    return false;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = editingId ? "保存修改" : "保存为草稿"; }
  }
}
async function deleteTermsTerm(termId, termName, btn) {
  if (!termsCanWrite()) {
    setTermsPageError("审核员只读：企业词典由业务管理员维护和删除。");
    showToast("审核员只读，不能删除术语", "err");
    return false;
  }
  const id = String(termId || "").trim();
  const name = String(termName || "").trim() || id;
  if (!id) { setTermsPageError("术语 ID 缺失，无法删除"); return false; }
  const ok = await confirmAction(
    "删除企业术语",
    `确定删除「${name}」？删除后会同步移除该术语投影的别名与实体；人工维护的实体不会被删除。此操作不可撤销。`,
    "删除", true,
  );
  if (!ok) return false;
  const original = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "删除中…"; }
  setTermsPageError("");
  try {
    const r = await fetch(`/api/v1/terms/${encodeURIComponent(id)}/delete`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: "{}",
    });
    const d = await termsReadJson(r);
    if (!r.ok || (d && (d.error || d.ok === false))) {
      const msg = termsErrorMessage(r.status, d, "删除失败");
      setTermsPageError(msg);
      showToast(msg, "err");
      if (btn) { btn.disabled = false; btn.textContent = original; }
      return false;
    }
    showToast("术语已删除，相关本体投影已按规则清理");
    invalidateTermsMigrationPreview("术语已删除，迁移计数可能已变化，请重新预览。");
    await loadTermsPage();
    return true;
  } catch (e) {
    const msg = "删除失败：网络异常，请稍后重试";
    setTermsPageError(msg);
    showToast(msg, "err");
    if (btn) { btn.disabled = false; btn.textContent = original; }
    return false;
  }
}
async function confirmTermsTerm(termId, btn) {
  if (!termsCanWrite()) {
    setTermsPageError("审核员只读：企业词典由业务管理员维护和确认。");
    showToast("审核员只读，不能确认术语", "err");
    return false;
  }
  const id = String(termId || "").trim();
  if (!id) { setTermsPageError("术语 ID 缺失，无法确认"); return false; }
  const selfConflicts = termsSelfConflicts(termsFindTerm(id));
  if (selfConflicts.length) {
    const ok = await confirmAction(
      "确认企业术语",
      `同义词「${selfConflicts.join("、")}」同时被声明为不等同：确认后术语会生效，但这组别名不会投影/参与归一。仍要确认吗？`,
      "仍要确认", false,
    );
    if (!ok) return false;
  }
  const original = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "确认中…"; }
  setTermsPageError("");
  try {
    const r = await fetch(`/api/v1/terms/${encodeURIComponent(id)}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: "{}",
    });
    const d = await termsReadJson(r);
    if (!r.ok || (d && (d.error || d.ok === false))) {
      const msg = termsErrorMessage(r.status, d, "确认失败");
      setTermsPageError(msg);
      showToast(msg, "err");
      if (btn) { btn.disabled = false; btn.textContent = original; }
      return false;
    }
    const note = termsConflictNote("术语已确认", d);
    const repeated = !!(d && d.confirmed === false && d.idempotent === true);
    await loadTermsPage();
    if (note) {
      setTermsPageError(note);
      showToast(note, "err");
    } else if (repeated) {
      showToast("该术语已确认过，无需重复确认");
    } else {
      showToast("术语已确认，已按当前本体投影规则处理");
    }
    return true;
  } catch (e) {
    const msg = "确认失败：网络异常，请稍后重试";
    setTermsPageError(msg);
    showToast(msg, "err");
    if (btn) { btn.disabled = false; btn.textContent = original; }
    return false;
  }
}
function setTermsMigrationError(msg) {
  dictState.migration.error = msg || "";
  const el = document.getElementById("dict-migrate-msg");
  if (el) { el.textContent = msg || ""; el.hidden = !msg; }
}
function termsMigrationErrorMessage(status, data, fallback) {
  if (data && typeof data.error === "string" && data.error) return data.error;
  if (status === 404) return "迁移接口或旧数据不存在（404）；请确认服务端已接入迁移路由";
  if (status === 403) return "当前角色无权迁移旧术语";
  return termsErrorMessage(status, data, fallback);
}
function invalidateTermsMigrationPreview(message) {
  dictState.migration.reqSeq++;
  dictState.migration.preview = null;
  dictState.migration.result = null;
  const run = document.getElementById("dict-migrate-run");
  if (run) run.disabled = true;
  const previewBtn = document.getElementById("dict-migrate-preview");
  if (previewBtn) { previewBtn.disabled = false; previewBtn.textContent = "预览迁移"; }
  const out = document.getElementById("dict-migrate-out");
  if (out) {
    out.classList.add("muted");
    out.style.fontSize = "12px";
    out.textContent = message || "词典已变更，请重新预览迁移。";
  }
  setTermsMigrationError("");
}
function termsMigrationAllSpaces() {
  const el = document.getElementById("dict-migrate-all");
  return !!(el && el.checked);
}
function termsMigrationCounts(d) {
  const n = (key) => Math.max(0, parseInt((d && d[key]) || 0, 10) || 0);
  return [
    ["扫描空间", n("scanned_workspaces")], ["含旧数据", n("workspaces_with_legacy")],
    ["旧术语", n("legacy_terms")], ["有效术语", n("valid_terms")],
    ["新增术语", n("created_terms")], ["已存在", n("existing_terms")],
    ["更新术语", n("updated_terms")], ["跳过已确认", n("skipped_confirmed")],
    ["新增别名", n("created_aliases")], ["不等同约束", n("not_equal_terms")],
    ["无效条目", (Array.isArray(d && d.invalid) ? d.invalid.length : 0)],
    ["冲突", (Array.isArray(d && d.conflicts) ? d.conflicts.length : 0)],
  ];
}
function termsMigrationResultHtml(d, executed) {
  const data = d || {};
  // 只有执行请求且服务端明确 dry_run=false 才显示“已执行”，不拿 HTTP 200 当成写库成功。
  const didWrite = !!executed && data.dry_run !== true;
  const label = didWrite ? "已执行" : "预览（未写库）";
  const cls = didWrite ? "published" : "draft";
  const reason = String(data.reason || "").trim();
  const cards = termsMigrationCounts(data).map(([k, v]) => `<div class="kpi" style="padding:10px"><b style="font-size:20px">${v}</b><span>${esc(k)}</span></div>`).join("");
  const workspaces = Array.isArray(data.workspaces) ? data.workspaces : [];
  const wsRows = workspaces.map(w => `<tr>
      <td>${esc(w.name || "—")}</td><td class="muted">${esc(w.workspace_id || "")}</td>
      <td>${Number(w.legacy_terms || 0)}</td><td>${Number(w.valid_terms || 0)}</td>
      <td>${Number(w.created_terms || 0)}</td><td>${Number(w.existing_terms || 0)}</td>
      <td>${Number(w.updated_terms || 0)}</td><td>${Number(w.skipped_confirmed || 0)}</td>
      <td>${Number(w.invalid_terms || 0)}</td></tr>`).join("");
  const invalid = (Array.isArray(data.invalid) ? data.invalid : []).slice(0, 30);
  const invalidHtml = invalid.length
    ? `<div style="margin-top:10px"><div class="muted" style="font-size:12px">无效旧条目（${data.invalid.length}）</div><table class="table"><thead><tr><th>空间</th><th>旧 ID</th><th>名称</th><th>原因</th></tr></thead><tbody>${invalid.map(x => `<tr><td class="muted">${esc(x.workspace_id || "")}</td><td class="muted">${esc(x.legacy_id || "")}</td><td>${esc(x.name || "—")}</td><td class="muted">${esc(x.reason || "")}</td></tr>`).join("")}</tbody></table></div>`
    : "";
  const warnings = (Array.isArray(data.warnings) ? data.warnings : []).slice(0, 20);
  const conflicts = (Array.isArray(data.conflicts) ? data.conflicts : []).slice(0, 20);
  const notes = [...warnings, ...conflicts].map(x => typeof x === "string" ? x : (x && (x.detail || x.reason || x.message)) || JSON.stringify(x)).filter(Boolean);
  const notesHtml = notes.length
    ? `<div class="muted" style="margin-top:8px;font-size:12px;color:#B45309">${notes.map(x => `· ${esc(x)}`).join("<br>")}</div>`
    : "";
  return `<div style="margin-top:4px">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><span class="pill ${cls}">${label}</span><span class="muted" style="font-size:12px">来源：workspace.settings_json.ontology_terms</span></div>
      ${reason ? `<div class="muted" style="margin-top:6px;font-size:12px">${esc(reason)}</div>` : ""}
      <div class="kpis" style="grid-template-columns:repeat(auto-fit,minmax(110px,1fr));margin:10px 0">${cards}</div>
      ${wsRows ? `<div class="table-wrap" style="overflow:auto"><table class="table"><thead><tr><th>空间</th><th>ID</th><th>旧术语</th><th>有效</th><th>新增</th><th>已存在</th><th>更新</th><th>跳过已确认</th><th>无效</th></tr></thead><tbody>${wsRows}</tbody></table></div>` : ""}
      ${invalidHtml}${notesHtml}
    </div>`;
}
function renderTermsMigration(d, executed) {
  const out = document.getElementById("dict-migrate-out");
  if (!out) return;
  out.innerHTML = termsMigrationResultHtml(d, executed);
  out.classList.remove("muted");
  out.style.fontSize = "";
  const run = document.getElementById("dict-migrate-run");
  if (run) run.disabled = !(d && d.ok && Number(d.valid_terms || 0) > 0);
}
async function previewTermsMigration() {
  if (!termsCanWrite()) {
    setTermsMigrationError("审核员只读：迁移由业务管理员预览和执行。");
    showToast("审核员只读，不能迁移旧术语", "err");
    return false;
  }
  const btn = document.getElementById("dict-migrate-preview");
  const all = termsMigrationAllSpaces();
  const seq = ++dictState.migration.reqSeq;
  dictState.migration.preview = null;
  dictState.migration.result = null;
  const run = document.getElementById("dict-migrate-run");
  if (run) run.disabled = true;
  setTermsMigrationError("");
  const out = document.getElementById("dict-migrate-out");
  if (out) { out.classList.add("muted"); out.style.fontSize = "12px"; out.textContent = "正在预览旧 ontology_terms…"; }
  if (btn) { btn.disabled = true; btn.textContent = "预览中…"; }
  try {
    // 显式传 0/1：服务端缺省参数是 all_spaces=1，不能靠“省略”表达当前空间。
    const r = await fetch("/api/v1/terms/migrate/preview?all_spaces=" + (all ? "1" : "0"), {
      headers: { Accept: "application/json" },
    });
    const d = await termsReadJson(r);
    if (seq !== dictState.migration.reqSeq) return false;
    if (!r.ok || (d && d.error)) {
      const msg = termsMigrationErrorMessage(r.status, d, "迁移预览失败");
      setTermsMigrationError(msg);
      if (out) { out.classList.add("muted"); out.style.fontSize = "12px"; out.textContent = "预览失败：" + msg; }
      return false;
    }
    dictState.migration.preview = d || {};
    renderTermsMigration(d, false);
    if (!d || !d.ok || Number(d.valid_terms || 0) <= 0) {
      setTermsMigrationError((d && (d.reason || d.error)) || "没有可迁移的有效旧术语，未写库");
      return false;
    }
    showToast("迁移预览完成：尚未写库，确认后点“执行迁移”");
    return true;
  } catch (e) {
    if (seq !== dictState.migration.reqSeq) return false;
    const msg = "迁移预览失败：网络异常，请稍后重试";
    setTermsMigrationError(msg);
    if (out) { out.classList.add("muted"); out.style.fontSize = "12px"; out.textContent = msg; }
    return false;
  } finally {
    if (seq === dictState.migration.reqSeq && btn) { btn.disabled = false; btn.textContent = "预览迁移"; }
  }
}
async function runTermsMigration() {
  if (!termsCanWrite()) {
    setTermsMigrationError("审核员只读：迁移由业务管理员预览和执行。");
    showToast("审核员只读，不能迁移旧术语", "err");
    return false;
  }
  const preview = dictState.migration.preview;
  if (!preview) {
    setTermsMigrationError("请先预览迁移结果，再执行。");
    return false;
  }
  const valid = Number(preview.valid_terms || 0);
  if (!(valid > 0)) {
    setTermsMigrationError("预览没有可迁移的有效旧术语，不能执行。");
    return false;
  }
  const all = termsMigrationAllSpaces();
  const ok = await confirmAction(
    "执行旧 ontology_terms 迁移",
    `将迁移 ${valid} 条有效旧术语（扫描 ${Number(preview.scanned_workspaces || 0)} 个空间）。迁移幂等：已确认术语不会被覆盖，重复执行不会新增重复记录。`,
    "执行迁移", false,
  );
  if (!ok) return false;
  const btn = document.getElementById("dict-migrate-run");
  if (btn) { btn.disabled = true; btn.textContent = "迁移中…"; }
  setTermsMigrationError("");
  try {
    const r = await fetch("/api/v1/terms/migrate", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ dry_run: false, all_spaces: all }),
    });
    const d = await termsReadJson(r);
    if (!r.ok || (d && (d.error || d.ok === false))) {
      const msg = (d && (d.error || d.reason)) || termsMigrationErrorMessage(r.status, d, "迁移执行失败");
      setTermsMigrationError(msg);
      showToast(msg, "err");
      if (btn) { btn.disabled = false; btn.textContent = "执行迁移"; }
      return false;
    }
    if (d && d.dry_run === true) {
      renderTermsMigration(d, false);
      setTermsMigrationError("服务端返回的仍是预览结果（dry_run=true），未确认写库；请检查迁移路由");
      if (btn) { btn.disabled = false; btn.textContent = "执行迁移"; }
      return false;
    }
    dictState.migration.result = d;
    dictState.migration.preview = d;
    renderTermsMigration(d, true);
    showToast(`迁移完成：新增 ${Number(d.created_terms || 0)} 条术语、${Number(d.created_aliases || 0)} 个别名`);
    await loadTermsPage();
    return true;
  } catch (e) {
    const msg = "迁移执行失败：网络异常，请稍后重试";
    setTermsMigrationError(msg);
    showToast(msg, "err");
    return false;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "执行迁移"; }
  }
}
async function loadTermsPage() {
  ensureTermsUI();
  closeTermsDrawer();
  applyTermsRole();
  const seq = ++dictState.reqSeq;
  dictState.loading = true;
  dictState.error = "";
  setTermsPageError("");
  renderTermsPage();
  if (!termsCanView()) {
    if (seq === dictState.reqSeq) {
      dictState.loading = false;
      setTermsPageError("当前角色无权查看企业词典");
      renderTermsPage();
    }
    return;
  }
  try {
    const qs = dictState.status ? "?status=" + encodeURIComponent(dictState.status) : "";
    const r = await fetch("/api/v1/terms" + qs, { headers: { Accept: "application/json" } });
    const d = await termsReadJson(r);
    if (seq !== dictState.reqSeq) return;
    if (!r.ok || (d && d.error)) {
      dictState.items = [];
      setTermsPageError(termsErrorMessage(r.status, d, "企业词典读取失败"));
    } else {
      dictState.items = Array.isArray(d.items) ? d.items : [];
      setTermsPageError("");
    }
  } catch (e) {
    if (seq !== dictState.reqSeq) return;
    dictState.items = [];
    setTermsPageError("企业词典读取失败：网络异常，请稍后重试");
  } finally {
    if (seq === dictState.reqSeq) {
      dictState.loading = false;
      dictState.loaded = true;
      renderTermsPage();
    }
  }
}
