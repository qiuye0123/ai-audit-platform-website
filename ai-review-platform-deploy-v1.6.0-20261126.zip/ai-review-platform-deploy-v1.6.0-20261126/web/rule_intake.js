/* 规则挖掘对话：自然语言 → ≤3 轮补问 → 草稿箱确认。 */
let _riMessages = [];
let _riRound = 0;
let _riLastDraft = null;
let _riDone = false;

function _riRender(box) {
  const log = box.querySelector("#ri-log");
  if (!log) return;
  log.innerHTML = _riMessages.length ? _riMessages.map(m => {
    const me = m.role === "user";
    return `<div style="display:flex;justify-content:${me ? "flex-end" : "flex-start"};margin:8px 0">
      <div style="max-width:82%;padding:9px 12px;border-radius:10px;font-size:12px;line-height:1.65;white-space:pre-wrap;background:${me ? "#E8F3FF" : "#F5F6F7"};color:#1D2129">${esc(m.content)}</div></div>`;
  }).join("") : '<div class="muted" style="font-size:12px;padding:14px 0">把您知道的企业规则说出来，不要求格式。我会先判断还缺什么，最多追问 3 轮。</div>';
  log.scrollTop = log.scrollHeight;
}

function _riPreview(box, d) {
  const s = d.slots || {};
  const isDt = (d.representation || "single") === "decision_table";
  const warn = (d.warnings || []).length ? `<div style="color:#B54708;font-size:11px;margin-top:6px">${esc(d.warnings.join("；"))}</div>` : "";
  const crit = s.criterion || [s.metric, s.op, s.value, s.unit].filter(Boolean).join(" ");
  box.querySelector("#ri-result").innerHTML = `<div class="card" style="margin-top:12px;padding:12px;border:1px solid #E5E6EB">
    <div style="font-size:12px;font-weight:600;margin-bottom:6px">规则草稿预览</div>
    <div class="nr-form-reco ${isDt ? "" : "single"}" style="margin:0 0 8px"><b>系统判型：${isDt ? "决策表组合多条件" : "单条数据裁决"}</b><div>${esc(d.form_reason || (isDt ? "检测到多个条件" : "单指标/单阈值"))}</div></div>
    <div style="font-size:12px;line-height:1.8"><b>${esc(d.name || "未命名")}</b> · ${esc(d.category || "")} · ${esc(d.rclass || "")}<br>
      <span class="muted">判据：</span>${esc(crit || "—")}<br>
      <span class="muted">适用/证据：</span>${esc(s.scope || "未填写")} / ${esc(s.evidence || "未填写")}
    </div>${warn}
    <div class="actions" style="margin-top:10px">
      ${isDt ? '<button class="btn primary" id="ri-open-dt">打开决策表编辑器</button>' : (d.ready ? '<button class="btn primary" id="ri-save">确认保存为草稿</button>' : '<span class="muted">信息不完整，不能保存为可审核规则</span>')}
      <button class="btn" id="ri-reset">重新描述</button>
      <span class="muted" id="ri-save-msg"></span>
    </div></div>`;
  box.querySelector("#ri-reset").onclick = () => renderRuleChat(box);
  box.querySelector("#ri-open-dt")?.addEventListener("click", function () {
    try { openDecisionCreate(); } catch (e) { showToast && showToast("决策表编辑器加载失败", "err"); }
  });
  box.querySelector("#ri-save")?.addEventListener("click", async () => {
    if (_riDone) return;
    _riDone = true;
    const msg = box.querySelector("#ri-save-msg"); msg.textContent = "保存中…";
    const r = await (await fetch("/api/v1/rules/intake/chat", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: _riMessages, save: true, confirm: true }) })).json();
    if (r.error) { _riDone = false; msg.textContent = r.error; return; }
    msg.textContent = (r.message || "已保存草稿") + "：" + (r.rule_id || "")
      + (r.degraded ? "（未用模型 · 确定性推断）" : "");
    showToast("已保存到规则草稿箱");
    if (typeof uxDirtyClear === "function") uxDirtyClear("newrule");
    _riDone = true;
    loadRules(); loadRecentRules();
  });
}

function renderRuleChat(box) {
  _riMessages = [{ role: "assistant", content: "请用自然语言描述规则。可以只说一部分，我会追问缺口；信息完整后只生成草稿，不会自动发布。" }];
  _riRound = 0; _riDone = false; _riLastDraft = null;
  box.innerHTML = `<div style="padding:4px 0">
    <div id="ri-log" style="max-height:300px;overflow:auto;border:1px solid #E5E6EB;border-radius:8px;padding:10px;background:#fff"></div>
    <div style="display:flex;gap:8px;margin-top:10px;align-items:flex-end">
      <textarea id="ri-text" class="field" style="flex:1;min-height:54px" placeholder="例如：所有炒制工序中心温度必须达到85℃以上，否则不通过；证据不足时待补证"></textarea>
      <button class="btn primary" id="ri-send">发送</button>
      <button class="btn" id="ri-clear">清空</button>
    </div>
    <div class="muted" id="ri-status" style="font-size:11px;margin-top:6px">最多 3 轮补问；不会把草稿直接发布。</div>
    <div id="ri-result"></div></div>`;
  _riRender(box);
  const send = async () => {
    const ta = box.querySelector("#ri-text"); const text = (ta.value || "").trim();
    if (!text || _riDone) return;
    _riMessages.push({ role: "user", content: text }); ta.value = ""; _riRender(box);
    box.querySelector("#ri-status").textContent = "解析中…";
    const r = await (await fetch("/api/v1/rules/intake/chat", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: _riMessages, save: false }) })).json();
    if (r.error) { box.querySelector("#ri-status").textContent = r.error; return; }
    if (r.status === "need_info") {
      _riRound = r.round || (_riRound + 1);
      _riMessages.push({ role: "assistant", content: (r.questions || []).join("\n") });
      _riRender(box);
      box.querySelector("#ri-status").textContent = `第 ${_riRound}/3 轮补问：请补充后再发送。`;
      return;
    }
    _riLastDraft = r.draft || {};
    // B3-01（评审 P1）：确定性回退（未接真实模型）时后端返回 degraded=true，
    // 页面必须明确提示「未用模型、确定性推断」，不能把兜底结果包装成模型生成。
    box.querySelector("#ri-status").innerHTML = (r.message || "已解析")
      + (r.degraded ? ' <span class="pill r" data-ri-degraded="1" title="当前环境未启用大模型：本结果由确定性规则推断，不是模型生成">未用模型 · 确定性推断</span>' : '');
    _riPreview(box, _riLastDraft);
  };
  box.querySelector("#ri-send").onclick = send;
  box.querySelector("#ri-text").addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); send(); }
  });
  box.querySelector("#ri-clear").onclick = () => renderRuleChat(box);
  if (typeof uxDirtyReset === "function") uxDirtyReset("newrule");
}
