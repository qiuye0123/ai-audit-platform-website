/* 工作台报告状态/抽屉：从 app.js 拆出；依赖 app.js 的 $/esc/currentRole/confirmAction。 */

/* P2-3（T-198）：报告门禁原因正文只给中文可读文案，内部字段名/计数（如
   incomplete_applicable_requirement=1）从正文剥离，原始全文放 title 供排查。 */
function wbGateReasonText(reasons) {
  const full = (reasons || []).filter((x) => String(x || "").trim()).map(String);
  const clean = full.map((s) => String(s)
    .replace(/[（(]?[a-z][a-z0-9_]*=\d+[）)]?/g, "")
    .replace(/[（(]\s*[）)]/g, "")
    .replace(/\s*；\s*/g, "；")
    .replace(/；{2,}/g, "；")
    .replace(/^[；;，,\s]+|[；;，,\s]+$/g, "")
    .trim()).filter(Boolean);
  return { text: clean.join("；"), full: full.join("；") };
}

async function renderWbReportStatus(pid) {
  const box = document.querySelector("#wb-report-strip"); if (!box) return;
  box.innerHTML = '<span class="muted">报告状态加载中…</span>';
  let st;
  try { st = await (await fetch(`/api/v1/reviews/${encodeURIComponent(pid)}/report-status`)).json(); }
  catch (e) { box.innerHTML = '<span class="muted">报告状态读取失败</span>'; return; }
  if (st.error) { box.innerHTML = `<span class="muted">${esc(st.error)}</span>`; return; }
  const pending = (st.stats || {}).pending || 0;
  const gateReason = wbGateReasonText(st.reasons || []);
  const reasons = st.reasons || [];
  const generated = st.latest && st.latest.version;
  const readOnly = currentRole === "admin";
  const gateText = gateReason.text || `仍有 ${pending} 条未复核`;
  const gateTitle = esc(gateReason.full || gateText);
  if (st.generated) {
    const stale = st.stale || pending > 0;
    // L97：旧的 GET「下载 DOCX」入口下线（导出只走签发后的 POST /reports/{id}/export，
    // 见下方「报告签发与导出」卡）；「查看报告」为只读预览，不产生导出回执/文件。
    box.innerHTML = `<div class="wb-report-info"><b>审核报告 ${esc(generated)}</b><span>${esc(st.latest.exported_at || "")}</span>${stale ? '<span class="pill draft">有新的复核/发现</span>' : '<span class="pill published">当前有效</span>'}</div>
      <div class="actions"><button class="btn" id="wb-report-view">查看报告</button>${readOnly ? "" : '<button class="btn primary" id="wb-report-generate">重新生成</button>'}</div>`;
  } else if (st.can_generate) {
    box.innerHTML = `<div class="wb-report-info"><b>复核已完成</b><span>${readOnly ? "报告待生成，当前为只读查看" : "可以生成正式审核报告"}</span></div>${readOnly ? "" : '<div class="actions"><button class="btn primary" id="wb-report-generate">生成审核报告</button></div>'}`;
  } else {
    box.innerHTML = `<div class="wb-report-info"><b>报告暂不可生成</b><span data-gate-reason="1" title="${gateTitle}">${esc(gateText)}</span></div>${readOnly ? "" : '<div class="actions"><button class="btn" disabled>生成审核报告</button></div>'}`;
  }
  const gen = box.querySelector("#wb-report-generate");
  if (gen) gen.onclick = async () => {
    if (!(await confirmAction(st.generated ? "重新生成报告" : "生成审核报告", st.generated ? "报告会基于当前复核结果重新生成；旧版本保留记录。确认继续？" : "将基于当前已复核结果生成正式报告；生成后可以预览和下载。确认继续？", st.generated ? "确认重新生成" : "确认生成"))) return;
    gen.disabled = true; gen.textContent = "生成中…";
    const r = await (await fetch(`/api/v1/reviews/${encodeURIComponent(pid)}/report`, { method: "POST" })).json();
    if (r.error) { showToast(r.error, "err"); gen.disabled = false; gen.textContent = "重新生成"; return; }
    showToast(`报告已生成 ${r.version}`);
    await renderWbReportStatus(pid);
    openReportDrawer(pid);
  };
  const view = box.querySelector("#wb-report-view"); if (view) view.onclick = () => openReportDrawer(pid);
  // L97：报告签发/导出卡（挂在报告状态条内；仅 reviewer 本人项目可操作）
  try { await renderWbReportIssue(pid, st); } catch (e) { console.warn("报告签发卡渲染失败（不影响报告状态）", e); }
}

function openReportDrawer(pid) {
  const mask = $("#report-drawer");
  // P1-3（T-198）：兜底脱离 #auto-placeholders[hidden]；否则抽屉 display:flex 但
  // 父级 display:none → 用户看到的是“点了没反应”。
  if (mask && mask.parentElement !== document.body) document.body.appendChild(mask);
  if (mask) { mask.hidden = false; mask.removeAttribute("aria-hidden"); mask.style.display = ""; }
  const frame = $("#drawer-frame");
  // 先探测门禁，被拦截时给出友好提示而不是裸 JSON
  fetch(`/api/v1/reviews/${pid}/report.html`).then(async (r) => {
    if (r.ok) { frame.src = `/api/v1/reviews/${pid}/report.html`; return; }
    let msg = "报告暂不可用";
    try { const j = await r.json(); msg = j.error || msg; } catch (e) {}
    frame.srcdoc = `<div style="font-family:-apple-system,'PingFang SC',sans-serif;padding:40px;text-align:center;color:#646A73">
      <div style="font-weight:600;font-size:15px;margin-bottom:10px">无权访问</div>
      <div style="font-size:15px;color:#1F2329;margin-bottom:8px">报告暂不可生成</div>
      <div style="font-size:13px">${msg}</div></div>`;
  }).catch(() => { frame.srcdoc = "<div style='padding:40px'>加载失败</div>"; });
  const _dl = $("#drawer-download");
  if (_dl) {
    // L97：抽屉里的「下载 DOCX」也必须是已签发报告（导出只走签发后入口），
    // 未签发/无报告时隐藏该链接，并在报告区提示先签发（不伪造可下载状态）。
    const _iss = window.__wbReportIssuance || {};
    const _allow = currentRole !== "admin" && _iss.pid === pid && _iss.signed === true;
    _dl.style.display = _allow ? "" : "none";
    if (_allow) _dl.href = `/api/v1/reviews/${encodeURIComponent(pid)}/report.docx`;
  }
}
$("#drawer-close")?.addEventListener("click", () => { $("#report-drawer").hidden = true; $("#drawer-frame").src = "about:blank"; });
$("#report-drawer")?.addEventListener("click", (e) => { if (e.target.id === "report-drawer") { $("#report-drawer").hidden = true; $("#drawer-frame").src = "about:blank"; } });
$("#wb-f-sev")?.addEventListener("change", () => { wbSev = $("#wb-f-sev").value; if (typeof uxWorkbenchFiltersSave === "function") uxWorkbenchFiltersSave(); renderWbFindings(); });
$("#wb-f-rev")?.addEventListener("change", () => { wbReviewed = $("#wb-f-rev").value; if (typeof uxWorkbenchFiltersSave === "function") uxWorkbenchFiltersSave(); renderWbFindings(); });

/* ===================== L97：报告签发 / 导出卡（2026-11-24） =====================
   目标：审核员在工作台报告区完成「签发 → 导出 HTML/DOCX」闭环；业务管理员/超管/
   平台运营只读展示事实（不渲染签发/导出按钮）。
   事实源：GET /api/v1/reviews/{cid}/report-status 的 issuance 段（L93/L94 服务层同源）。
   状态口径：未生成 / 已生成（待签发）/ 已签发（可导出）/ 已导出。
   错误码（HTTP 409/403）→ 中文可操作提示：report_not_generated / report_not_signed /
   content_hash_mismatch / report_stale / report_blocked / forbidden / pdf_export_removed。
   真实写入口：POST /api/v1/reports/{id}/sign 与 /export（L94；失败不伪造成功）。
   ============================================================================ */
const WB_REPORT_ISSUE_LABEL = {
  none: "未生成", generated: "已生成（待签发）", signed: "已签发（可导出）", exported: "已导出",
};
const WB_REPORT_ISSUE_PILL = { none: "draft", generated: "draft", signed: "published", exported: "published" };

function wbReportIssueShortHash(hash) {
  const s = String(hash || "").trim();
  if (!s) return "";
  const prefix = s.indexOf("sha256:") === 0 ? "sha256:" : "";
  const body = prefix ? s.slice(7) : s;
  if (body.length <= 18) return prefix + body;
  return prefix + body.slice(0, 10) + "…" + body.slice(-6);
}

function wbReportIssueSigner(id) {
  const raw = String(id || "").trim();
  if (!raw) return "—";
  const u = (typeof currentUser !== "undefined" && currentUser) || null;
  if (u && (u.sub === raw || u.id === raw)) return (u.name || raw) + "（本人）";
  return raw;
}

function wbReportIssueErrorText(code, fallback) {
  const c = String(code || "").trim();
  const MAP = {
    report_not_generated: "尚未生成报告：请先完成复核并生成审核报告，生成后才能签发",
    report_not_signed: "报告尚未签发：请先完成签发，签发后才能导出 HTML/DOCX",
    content_hash_mismatch: "报告内容与生成时的内容 hash 不一致（可能被修改），已拒绝操作：请重新生成报告后再签发/导出",
    report_stale: "该报告不是最新版本（项目中已有更新报告）：请点击「刷新」读取最新版本后再操作",
    report_blocked: "报告门禁未通过：请先完成全部复核与漏报对账，门禁通过后才能签发/导出",
    invalid_transition: "当前报告状态不允许该操作：请点击「刷新」读取最新状态后重试",
    report_revoked: "报告已撤销，不能签发：请重新生成报告后再签发",
    report_not_found: "报告不存在或已被删除：请点击「刷新」后重试",
    not_found: "报告不存在或已被删除：请点击「刷新」后重试",
    pdf_export_removed: "PDF 报告导出已移除：请导出 HTML 或 DOCX",
    unauthorized: "需要登录审核员账号才能签发/导出报告",
    forbidden: "无权操作：仅项目所属审核员可签发/导出本人项目报告",
    audit_write_failed: "审计写入失败，操作已回滚：请稍后重试（本次未签发/未导出）",
    network_error: "请求失败：请检查网络后重试",
  };
  if (MAP[c]) return MAP[c];
  const fb = String(fallback || "").trim();
  return fb || "操作失败：请刷新报告状态后重试";
}

function wbReportIssueState(st) {
  const iss = (st && st.issuance) || {};
  const hasReport = !!(iss.available && Number(iss.generated_rows || 0) > 0);
  const signed = hasReport && iss.signed === true;
  const exported = signed && (String(iss.status || "") === "exported"
    || !!String(iss.exported_by || "").trim());
  const status = !hasReport ? "none" : (exported ? "exported" : (signed ? "signed" : "generated"));
  return { iss, hasReport, signed, exported, status };
}

function wbReportIssueSignReason(state, st) {
  const { iss, hasReport, signed, exported } = state;
  const access = (st && st.access) || {};
  if (!hasReport) {
    return (iss && Number(iss.receipt_rows || 0) > 0)
      ? "仅有导出回执行、没有生成报告：请先生成审核报告"
      : "尚未生成报告：请先完成复核并生成审核报告，生成后才能签发";
  }
  if (signed) {
    return exported
      ? "报告已导出：导出后不能再签发；如内容有更新请重新生成报告"
      : "报告已签发：无需重复签发（重复点击不会重复生效）";
  }
  if (access.read_only || (typeof currentRole !== "undefined" && currentRole === "admin")) {
    return "只读：业务管理员可查看报告状态，不能签发";
  }
  if (iss.content_hash_verified === false) {
    return "报告内容与生成时不一致，已禁止签发：请重新生成报告后再签发";
  }
  if (st && st.can_generate === false) {
    const g = wbGateReasonText((st && st.reasons) || []);
    return "报告门禁未通过：" + (g.text || "请先完成复核/漏报对账，门禁通过后才能签发");
  }
  return "";
}

function wbReportIssueExportReason(state, st) {
  const { iss, hasReport, signed } = state;
  if (!hasReport) return "尚未生成报告：没有可导出的报告";
  if (!signed) return "报告未签发：签发后才能导出 HTML/DOCX";
  if (iss.content_hash_verified === false) {
    return "报告内容与生成时不一致，已禁止导出：请重新生成报告后再签发/导出";
  }
  const access = (st && st.access) || {};
  if (access.read_only) return "只读：业务管理员不能导出报告";
  return "";
}

function wbReportIssueShowMsg(card, text, ok, code) {
  if (!card) return;
  const box = card.querySelector("#wb-report-issue-msg");
  if (!box) return;
  box.hidden = false;
  box.className = "wb-ri-msg " + (ok ? "ok" : "err");
  box.dataset.code = String(code || "");
  box.textContent = String(text || "");
}

function wbReportIssueShowError(data) {
  const card = document.getElementById("wb-report-issue");
  const code = String((data && data.code) || "");
  let text = wbReportIssueErrorText(code, data && data.error);
  if (code === "report_blocked" && data && data.error) {
    const g = wbGateReasonText([data.error]);
    if (g.text) text = "报告门禁未通过：" + g.text + "；门禁通过后才能签发/导出";
  }
  wbReportIssueShowMsg(card, text, false, code);
  return text;
}

async function wbReportIssuePost(path, body) {
  const r = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  let j = null;
  try { j = await r.json(); } catch (e) { j = null; }
  return { ok: r.ok, status: r.status, data: j || {} };
}

async function renderWbReportIssue(pid, st) {
  const box = document.querySelector("#wb-report-strip");
  if (!box) return;
  const old = box.querySelector("#wb-report-issue");
  if (old) old.remove();
  const state = wbReportIssueState(st);
  const { iss, hasReport, signed, exported, status } = state;
  // 抽屉「下载 DOCX」按已签发事实显隐（openReportDrawer 读取；不伪造可下载）
  window.__wbReportIssuance = {
    pid: String(pid || ""), rid: String(iss.report_id || ""),
    signed: signed, exported: exported, status: status,
  };
  const reviewer = (typeof currentRole !== "undefined") && currentRole === "reviewer";
  const signReason = reviewer ? wbReportIssueSignReason(state, st) : "";
  const exportReason = reviewer ? wbReportIssueExportReason(state, st) : "";
  const hash = String(iss.content_hash || "");
  const hashHtml = hash
    ? `<code id="wb-report-issue-hash" title="完整内容 hash：${esc(hash)}">${esc(wbReportIssueShortHash(hash))}</code>`
    : '<span class="muted" id="wb-report-issue-hash">历史报告未记录内容 hash（签发时补录）</span>';
  const meta = hasReport
    ? `<span>内容 hash：${hashHtml}</span>
       <span>生成人：<b id="wb-report-issue-generated-by">${esc(wbReportIssueSigner(iss.generated_by))}</b></span>
       <span>签发人：<b id="wb-report-issue-signer">${esc(wbReportIssueSigner(iss.signed_by))}</b></span>
       <span>签发时间：<span id="wb-report-issue-signed-at">${esc(iss.signed_at || "—")}</span></span>
       <span>导出时间：<span id="wb-report-issue-exported-at">${esc(exported ? (iss.exported_at || "—") : "未导出")}</span></span>`
    : `<span id="wb-report-issue-empty">尚未生成报告：完成复核并生成报告后才能签发，签发后才能导出 HTML/DOCX</span>`;

  let hint;
  if (!reviewer) {
    hint = "只读：业务管理员可查看报告状态 / 内容 hash / 签发人 / 导出时间，不能签发或导出报告。";
  } else {
    const base = status === "none"
      ? "尚未生成报告：完成复核并生成报告后才能签发。"
      : status === "generated"
        ? "报告已生成、尚未签发：签发后才能导出 HTML/DOCX。"
        : status === "signed"
          ? "报告已签发：可导出 HTML 或 DOCX；导出后不能再签发。"
          : "报告已导出：导出后不能再签发；如需更新版请重新生成报告。";
    const parts = [];
    if (signReason) parts.push("签发禁用：" + signReason + "。");
    if (exportReason && exportReason !== signReason && status !== "none") {
      parts.push("导出禁用：" + exportReason + "。");
    }
    if (!parts.length) parts.push(base);
    parts.push("PDF 导出已移除，请导出 HTML 或 DOCX。");
    hint = parts.join("");
  }
  const actions = reviewer
    ? `<div class="actions">
         <button class="btn primary" id="wb-report-sign"${signReason ? " disabled" : ""}
           data-reason="${esc(signReason)}"
           title="${esc(signReason || "签发后报告内容锁定，可导出 HTML/DOCX")}">签发报告</button>
         <button class="btn" id="wb-report-export-html"${exportReason ? " disabled" : ""}
           data-reason="${esc(exportReason)}"
           title="${esc(exportReason || "导出 HTML（已签发报告）")}">导出 HTML</button>
         <button class="btn" id="wb-report-export-docx"${exportReason ? " disabled" : ""}
           data-reason="${esc(exportReason)}"
           title="${esc(exportReason || "导出 DOCX（已签发报告）")}">导出 DOCX</button>
         <button class="btn" id="wb-report-export-pdf" disabled
           data-reason="PDF 报告导出已移除：请导出 HTML 或 DOCX"
           title="PDF 报告导出已移除：请导出 HTML 或 DOCX">导出 PDF（已移除）</button>
         <button class="btn" id="wb-report-issue-refresh" title="重新读取报告状态">刷新报告状态</button>
       </div>`
    : `<div class="actions"><button class="btn" id="wb-report-issue-refresh" title="重新读取报告状态">刷新报告状态</button></div>`;
  const card = document.createElement("div");
  card.className = "wb-report-issue";
  card.id = "wb-report-issue";
  card.dataset.status = status;
  card.dataset.role = reviewer ? "reviewer" : String((typeof currentRole !== "undefined" && currentRole) || "");
  card.innerHTML = `
    <div class="wb-ri-head"><b>报告签发与导出</b>
      <span class="pill ${WB_REPORT_ISSUE_PILL[status]}" id="wb-report-issue-status">${esc(WB_REPORT_ISSUE_LABEL[status])}</span>
      <span class="muted" id="wb-report-issue-version">${esc(iss.version || "")}</span>
    </div>
    <div class="wb-ri-meta" id="wb-report-issue-meta">${meta}</div>
    <div class="wb-ri-hint" id="wb-report-issue-hint"
      data-sign-reason="${esc(signReason)}" data-export-reason="${esc(exportReason)}">${esc(hint)}</div>
    ${actions}
    <div class="wb-ri-msg" id="wb-report-issue-msg" hidden></div>
    <details class="wb-ri-history" id="wb-report-issue-history-wrap" hidden>
      <summary>报告记录<span id="wb-report-issue-history-count" class="muted"></span></summary>
      <div id="wb-report-issue-history"></div>
    </details>`;
  box.appendChild(card);

  const refresh = card.querySelector("#wb-report-issue-refresh");
  if (refresh) refresh.onclick = () => renderWbReportStatus(pid);
  const btnSign = card.querySelector("#wb-report-sign");
  if (btnSign && !btnSign.disabled) btnSign.onclick = () => wbReportIssueSign(pid, iss, btnSign);
  const btnHtml = card.querySelector("#wb-report-export-html");
  if (btnHtml && !btnHtml.disabled) btnHtml.onclick = () => wbReportIssueExport(pid, iss, "html", btnHtml);
  const btnDocx = card.querySelector("#wb-report-export-docx");
  if (btnDocx && !btnDocx.disabled) btnDocx.onclick = () => wbReportIssueExport(pid, iss, "docx", btnDocx);
  if (hasReport) {
    wbReportIssueLoadHistory(pid, String(iss.report_id || ""), card).catch(() => {});
  }
}

async function wbReportIssueLoadHistory(pid, currentId, card) {
  const r = await fetch(`/api/v1/reports?case_id=${encodeURIComponent(pid)}`);
  if (!r.ok) return;
  let data = null;
  try { data = await r.json(); } catch (e) { return; }
  let rows = (data && data.items) || [];
  // 排除「导出回执行」：不是正式报告版本（L93 口径），不混入报告记录列表
  rows = rows.filter((x) => {
    try {
      const s = JSON.parse((x && x.summary_json) || "{}");
      return String((s && s._kind) || "") !== "export_receipt";
    } catch (e) { return true; }
  });
  if (!rows.length) return;
  const wrap = card.querySelector("#wb-report-issue-history-wrap");
  const host = card.querySelector("#wb-report-issue-history");
  const count = card.querySelector("#wb-report-issue-history-count");
  if (!wrap || !host) return;
  host.innerHTML = rows.slice(0, 8).map((row) => {
    const id = String(row.id || "");
    const ver = String(row.version || "");
    const stat = String(row.status || "").toLowerCase();
    const label = stat === "exported" || String(row.exported_by || "").trim()
      ? "已导出" : (stat === "signed" ? "已签发" : (stat === "generated" ? "已生成" : (stat || "—")));
    const pill = (label === "已签发" || label === "已导出") ? "published" : "draft";
    const signer = String(row.signed_by || "").trim() ? wbReportIssueSigner(row.signed_by) : "未签发";
    const when = String(row.signed_at || row.created_at || "");
    const shortHash = wbReportIssueShortHash(row.content_hash);
    return `<div class="wb-ri-row" data-report-id="${esc(id)}" data-status="${esc(stat)}">
      <span class="pill ${pill}">${esc(label)}</span><b>${esc(ver)}</b>
      <span>${esc(signer)}</span><span class="muted">${esc(when)}</span>
      ${shortHash ? `<code title="内容 hash">${esc(shortHash)}</code>` : ""}
      ${id === currentId ? '<span class="pill published">当前</span>' : ""}
    </div>`;
  }).join("");
  if (count) count.textContent = `（${rows.length} 条）`;
  wrap.hidden = false;
  wrap.open = true;
}

function wbReportIssueConfirm(title, text, okLabel) {
  if (typeof confirmAction === "function") return confirmAction(title, text, okLabel);
  return Promise.resolve(window.confirm(title + "\n" + text));
}

async function wbReportIssueSign(pid, iss, btn) {
  const name = (typeof currentUser !== "undefined" && currentUser && (currentUser.name || currentUser.sub)) || "当前账号";
  const ok = await wbReportIssueConfirm("签发审核报告",
    `确认签发报告 ${iss.version || ""}？签发人将记录为当前账号（${name}）；`
    + "签发后报告内容与内容 hash 锁定，可导出 HTML/DOCX，导出后不能再签发。", "确认签发");
  if (!ok) return false;
  btn.disabled = true;
  btn.textContent = "签发中…";
  const body = {};
  if (iss.content_hash) body.content_hash = iss.content_hash;
  let res;
  try {
    res = await wbReportIssuePost(
      `/api/v1/reports/${encodeURIComponent(iss.report_id)}/sign`, body);
  } catch (e) {
    wbReportIssueShowError({ code: "network_error" });
    showToast("签发请求失败：请检查网络后重试", "err");
    btn.disabled = false; btn.textContent = "签发报告";
    return false;
  }
  if (!res.ok) {
    const text = wbReportIssueShowError(res.data);
    showToast(text, "err");
    btn.disabled = false; btn.textContent = "签发报告";
    return false;
  }
  const d = res.data || {};
  const msg = d.already_signed
    ? "报告此前已签发（重复签发幂等，不重复写审计）"
    : `报告已签发：${wbReportIssueSigner(d.signed_by)} · ${esc(d.signed_at || "")}；内容 hash ${wbReportIssueShortHash(d.content_hash)}`;
  const wasPid = pid;
  await renderWbReportStatus(pid);
  const card = document.getElementById("wb-report-issue");
  if (card && (window.__wbReportIssuance || {}).pid === wasPid) wbReportIssueShowMsg(card, msg, true, "signed");
  showToast("报告已签发，可导出 HTML/DOCX");
  return true;
}

async function wbReportIssueExport(pid, iss, fmt, btn) {
  const label = fmt === "docx" ? "DOCX" : "HTML";
  const oldText = btn.textContent;
  btn.disabled = true;
  btn.textContent = "导出中…";
  let r;
  try {
    r = await fetch(`/api/v1/reports/${encodeURIComponent(iss.report_id)}/export`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ format: fmt }),
    });
  } catch (e) {
    r = null;
  }
  if (!r) {
    const card0 = document.getElementById("wb-report-issue");
    wbReportIssueShowMsg(card0, wbReportIssueErrorText("network_error"), false, "network_error");
    showToast("导出请求失败：请检查网络后重试", "err");
    btn.disabled = false; btn.textContent = oldText;
    return false;
  }
  if (!r.ok) {
    let j = null;
    try { j = await r.json(); } catch (e) { j = null; }
    const code = String((j && j.code) || "");
    const text = wbReportIssueErrorText(code, (j && j.error) || `导出失败（HTTP ${r.status}）`);
    const card = document.getElementById("wb-report-issue");
    wbReportIssueShowMsg(card, text, false, code);
    showToast(text, "err");
    btn.disabled = false;
    btn.textContent = oldText;
    return false;
  }
  let blob = null;
  try { blob = await r.blob(); } catch (e) { blob = null; }
  const hash = String(r.headers.get("X-Report-Exported-Hash") || "");
  if (blob) {
    try {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `report-${pid}.${fmt}`;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e2) {} }, 15000);
    } catch (e) { /* 下载触发失败不影响回执提示（导出已完成，审计已记录） */ }
  }
  const msg = `已导出 ${label}：内容 ${hash ? wbReportIssueShortHash(hash) : "hash 未返回"}（导出回执已记录）`;
  await renderWbReportStatus(pid);
  const card2 = document.getElementById("wb-report-issue");
  if (card2) {
    wbReportIssueShowMsg(card2, msg, true, "exported");
    card2.dataset.lastExportHash = hash;
    card2.dataset.lastExportFormat = fmt;
    card2.dataset.lastExportBytes = String(blob ? blob.size : 0);
  }
  showToast(`已导出 ${label}，导出回执已记录`);
  return true;
}

/* ===================== 模型配置（多模型） ===================== */
const CAP_TEXT = { chat: "对话/审核判定", vision: "视觉理解", ocr: "图文识别", embed: "向量化" };
/* 消息配置页面已拆到 web/notify_config.js。 */
