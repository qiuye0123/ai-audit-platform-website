/* 工作台预览：PDF 原始页图视图 + 解析文本分页视图。
 *
 * 从 app.js 拆出；依赖 wbDocs/wbCurrentDoc/currentWb/wbPreviewMode 等全局。
 *
 * T-94 修复要点（用户反馈「原始文件」预览空白/显示异常）：
 * 1. 不再把 PDF 交给浏览器原生 iframe 插件渲染，改为后端真实页数 + 逐页 PNG：
 *    工具栏支持上一页/下一页、页码跳转、缩放、适应宽度；滚动容器双向滚动。
 * 2. PDF 解析文本模式保留 iframe 渲染，按可视高度分页（页码稳定、resize 重算），
 *    支持上一页/下一页与宽度缩放；iframe 内上下+左右滚动。
 * 3. 非 PDF 预览保持原行为（xlsx Sheet 切换、docx 文本解析预览不退化）。
 * 4. 加载 / 错误 / 空态明确；键盘（←/→、PageUp/PageDown、Home/End、+/-/0）可用。
 *
 * DOM 由本文件动态创建（不要求 admin.html / index.html / reviewer.html 同步改标记），
 * 因此系统管理员端即使未升级 HTML 也能获得同样的预览能力。
 */

let _wbPdfState = null;
let _wbParseState = null;
let _wbPreviewSeq = 0;
const _WB_PDF_ZOOM_STEPS = [50, 75, 100, 125, 150, 175, 200, 250, 300, 400];
const _WB_PDF_DEFAULT_SIZE = 1600;
const _WB_PARSE_ZOOM_STEP = 0.25;

/* ---------------------------------------------------------------- 基础工具 */
function _wbFrame() {
  return document.querySelector("#wb-doc-frame");
}
function _wbCurDoc() {
  return (wbDocs || []).find(x => x.id === wbCurrentDoc) || (wbDocs || [])[0] || {};
}
function _wbIsPdfDoc(d) {
  const fn = String((d || {}).filename || "");
  return /\.pdf$/i.test(fn) || String((d || {}).doc_type || "").toLowerCase() === "pdf";
}
function _wbEl(sel, root) {
  return (root || document).querySelector(sel);
}
function _wbCard() {
  const fr = _wbFrame();
  return fr ? (fr.closest(".wb-doc-card") || fr.parentElement) : null;
}
function _wbNoticeHtml(title, msg, detail) {
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  return "<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><style>"
    + "body{margin:0;background:#F1F3F5;font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;color:#1F2329}"
    + ".nbox{max-width:640px;margin:40px auto;background:#fff;border:1px solid #E5E6E8;border-radius:10px;padding:26px 30px}"
    + "h2{font-size:15px;margin:0 0 8px}.nmsg{font-size:13px;line-height:1.8;color:#4E5969;white-space:pre-wrap;word-break:break-word}"
    + ".ndetail{margin-top:10px;font-size:11px;line-height:1.7;color:#8F959E;word-break:break-word;white-space:pre-wrap}"
    + "</style></head><body><div class='nbox'><h2>" + esc(title) + "</h2>"
    + "<div class='nmsg'>" + esc(msg) + "</div>"
    + (detail ? "<div class='ndetail'>" + esc(detail) + "</div>" : "")
    + "</div></body></html>";
}

/* ---------------------------------------------------------------- UI 骨架 */
function wbEnsurePreviewUI() {
  const frame = _wbFrame();
  if (!frame) return false;
  const card = _wbCard();
  if (!card) return false;
  if (!_wbEl("#wb-parse-bar")) {
    const bar = document.createElement("div");
    bar.id = "wb-parse-bar";
    bar.className = "wb-parse-bar";
    bar.hidden = true;
    bar.innerHTML =
      '<span class="wb-parse-title">解析文本</span>'
      + '<span class="wb-parse-nav"><button type="button" class="btn" id="wb-parse-prev" title="上一页（PageUp）">‹ 上一页</button>'
      + '<span class="wb-parse-pageinfo">第 <input id="wb-parse-pageinput" class="field" type="text" inputmode="numeric" value="1" aria-label="解析文本页码"> 页 / 共 <b id="wb-parse-pagetotal">-</b> 页</span>'
      + '<button type="button" class="btn" id="wb-parse-next" title="下一页（PageDown）">下一页 ›</button></span>'
      + '<span class="wb-parse-zoom"><button type="button" class="btn" id="wb-parse-zoomout" title="缩小解析文本宽度" aria-label="缩小">−</button>'
      + '<button type="button" class="btn" id="wb-parse-zoomval" title="恢复 100% 宽度">100%</button>'
      + '<button type="button" class="btn" id="wb-parse-zoomin" title="放大解析文本宽度（放大后出现左右滚动条）" aria-label="放大">+</button></span>'
      + '<span id="wb-parse-status" class="wb-parse-status" role="status"></span>';
    card.insertBefore(bar, frame);
    _wbBindParseBar(bar);
  }
  if (!_wbEl("#wb-pdf-viewer")) {
    const viewer = document.createElement("div");
    viewer.id = "wb-pdf-viewer";
    viewer.className = "wb-pdf-viewer";
    viewer.hidden = true;
    viewer.innerHTML =
      '<div class="wb-pdf-bar">'
      + '<span class="wb-pdf-nav"><button type="button" class="btn" id="wb-pdf-prev" title="上一页（← / PageUp）">‹ 上一页</button>'
      + '<span class="wb-pdf-pageinfo">第 <input id="wb-pdf-pageinput" class="field" type="text" inputmode="numeric" value="1" aria-label="PDF 页码"> 页 / 共 <b id="wb-pdf-pagetotal">-</b> 页</span>'
      + '<button type="button" class="btn" id="wb-pdf-next" title="下一页（→ / PageDown）">下一页 ›</button></span>'
      + '<span class="wb-pdf-zoom"><button type="button" class="btn" id="wb-pdf-zoomout" title="缩小（-）" aria-label="缩小">−</button>'
      + '<button type="button" class="btn wb-pdf-zoomval" id="wb-pdf-zoomval" title="点击恢复适应宽度">适应宽度</button>'
      + '<button type="button" class="btn" id="wb-pdf-zoomin" title="放大（+）" aria-label="放大">+</button>'
      + '<button type="button" class="btn" id="wb-pdf-fit" title="适应宽度（0）">适应宽度</button></span>'
      + '<span id="wb-pdf-status" class="wb-pdf-status" role="status"></span>'
      + '</div>'
      + '<div id="wb-pdf-scroll" class="wb-pdf-scroll" tabindex="0" aria-label="PDF 页面滚动区域，可上下左右滚动；方向键翻页，+/- 缩放">'
      + '<div id="wb-pdf-state" class="wb-preview-state" hidden aria-live="polite">'
      + '<div class="wb-preview-state-title"></div><div class="wb-preview-state-msg"></div>'
      + '<button type="button" class="btn" id="wb-pdf-retry" hidden>重试</button></div>'
      + '<img id="wb-pdf-img" class="wb-pdf-img" alt="PDF 页面" hidden draggable="false">'
      + '</div>';
    card.appendChild(viewer);
    _wbBindPdfViewer(viewer);
  }
  return true;
}

/* ---------------------------------------------------------------- PDF 视图 */
function _wbPdfVisible() {
  const v = _wbEl("#wb-pdf-viewer");
  return !!(v && !v.hidden);
}
function _wbShowPdfViewer() {
  const v = _wbEl("#wb-pdf-viewer");
  if (v) v.hidden = false;
}
function _wbHidePdfViewer() {
  const v = _wbEl("#wb-pdf-viewer");
  if (v) v.hidden = true;
}
function _wbPdfStateUI(kind, title, msg, opts) {
  const state = _wbEl("#wb-pdf-state");
  const img = _wbEl("#wb-pdf-img");
  const retry = _wbEl("#wb-pdf-retry");
  const sc = _wbEl("#wb-pdf-scroll");
  if (!state || !img) return;
  const t = _wbEl(".wb-preview-state-title", state);
  const m = _wbEl(".wb-preview-state-msg", state);
  if (t) t.textContent = title || "";
  if (m) m.textContent = msg || "";
  if (!kind || kind === "hide") {
    state.hidden = true;
    if (sc) sc.removeAttribute("aria-busy");
    return;
  }
  state.hidden = false;
  state.className = "wb-preview-state is-" + kind;
  img.hidden = true;
  if (retry) retry.hidden = !(opts && opts.retry);
  if (sc) {
    if (kind === "loading") sc.setAttribute("aria-busy", "true");
    else sc.removeAttribute("aria-busy");
  }
}
function _wbPdfStatus(text) {
  const el = _wbEl("#wb-pdf-status");
  if (el) el.textContent = text || "";
}
function _wbPdfUpdateNav() {
  const st = _wbPdfState;
  const prev = _wbEl("#wb-pdf-prev"), next = _wbEl("#wb-pdf-next");
  const input = _wbEl("#wb-pdf-pageinput"), total = _wbEl("#wb-pdf-pagetotal");
  if (!st) return;
  if (prev) prev.disabled = !(st.loaded && st.page > 1);
  if (next) next.disabled = !(st.loaded && st.page < st.pageCount);
  if (input && document.activeElement !== input) input.value = String(st.page || 1);
  if (total) total.textContent = st.pageCount ? String(st.pageCount) : "-";
}
function _wbPdfUpdateZoomLabel() {
  const st = _wbPdfState;
  const val = _wbEl("#wb-pdf-zoomval");
  if (!st || !val) return;
  val.textContent = st.zoomMode === "fit" ? "适应宽度" : (st.pct + "%");
}
function _wbPdfAvailableWidth() {
  const sc = _wbEl("#wb-pdf-scroll");
  const w = sc ? sc.clientWidth : 0;
  return Math.max(160, w - 28);
}
function _wbPdfApplyZoom() {
  const st = _wbPdfState;
  const img = _wbEl("#wb-pdf-img");
  if (!st || !img || img.hidden) return;
  if (st.zoomMode === "fit") {
    img.classList.add("wb-fit");
    img.style.width = "";
    img.style.maxWidth = "";
  } else {
    img.classList.remove("wb-fit");
    // 自定义缩放：以「适应宽度」为 100% 基准，放大后必然出现左右滚动条
    img.style.width = Math.max(80, Math.round(_wbPdfAvailableWidth() * st.pct / 100)) + "px";
    img.style.maxWidth = "none";
  }
  _wbPdfUpdateZoomLabel();
}
function _wbPdfZoom(dir) {
  const st = _wbPdfState;
  if (!st) return;
  if (st.zoomMode === "fit") {
    st.zoomMode = "pct";
    st.pct = dir > 0 ? 125 : 75;
  } else {
    let idx = _WB_PDF_ZOOM_STEPS.indexOf(st.pct);
    if (idx < 0) idx = _WB_PDF_ZOOM_STEPS.indexOf(100);
    idx = Math.max(0, Math.min(_WB_PDF_ZOOM_STEPS.length - 1, idx + (dir > 0 ? 1 : -1)));
    st.pct = _WB_PDF_ZOOM_STEPS[idx];
  }
  if (st.pct === 100) st.zoomMode = "fit";
  _wbPdfApplyZoom();
  const sc = _wbEl("#wb-pdf-scroll");
  if (sc) sc.focus({ preventScroll: true });
}
function _wbPdfFit() {
  const st = _wbPdfState;
  if (!st) return;
  st.zoomMode = "fit";
  st.pct = 100;
  _wbPdfApplyZoom();
}
function _wbPdfStep(dir) {
  const st = _wbPdfState;
  if (!st || !st.loaded) return;
  st.page = Math.max(1, Math.min(st.pageCount, st.page + dir));
}
async function _wbPdfLoadPage(page) {
  const st = _wbPdfState;
  if (!st) return false;
  const total = st.pageCount || 1;
  page = Math.max(1, Math.min(total, Number(page) || 1));
  st.page = page;
  st.loaded = false;
  const my = ++st.loadToken;
  _wbPdfUpdateNav();
  _wbPdfStatus("正在加载第 " + page + " / " + total + " 页…");
  _wbPdfStateUI("loading", "正在加载第 " + page + " / " + total + " 页…", "");
  const url = "/api/v1/projects/" + encodeURIComponent(currentWb)
    + "/documents/" + encodeURIComponent(st.docId)
    + "/pdf-page?page=" + page + "&size=" + _WB_PDF_DEFAULT_SIZE;
  let resp = null;
  try {
    resp = await fetch(url, { headers: { "Accept": "image/png,application/json" } });
  } catch (e) {
    if (my !== st.loadToken || _wbPdfState !== st) return false;
    _wbPdfStateUI("error", "第 " + page + " 页页图加载失败", "网络错误：" + (e && e.message ? e.message : e), { retry: true });
    _wbPdfStatus("加载失败");
    return false;
  }
  if (!resp.ok) {
    let msg = "HTTP " + resp.status;
    let details = [];
    try {
      const j = await resp.json();
      msg = j.error || j.message || msg;
      details = Array.isArray(j.details) ? j.details : [];
    } catch (e) { /* 非 JSON 错误体 */ }
    if (my !== st.loadToken || _wbPdfState !== st) return false;
    const lines = [msg].concat(details.slice(0, 6).map(x => "· " + x));
    _wbPdfStateUI("error", "第 " + page + " 页无法渲染", lines.join("\n"), { retry: true });
    _wbPdfStatus("第 " + page + " 页渲染失败");
    return false;
  }
  const ctype = String(resp.headers.get("content-type") || "");
  if (ctype && ctype.indexOf("image/") !== 0) {
    if (my !== st.loadToken || _wbPdfState !== st) return false;
    _wbPdfStateUI("error", "第 " + page + " 页页图格式异常", "服务端返回内容类型：" + ctype, { retry: true });
    return false;
  }
  let blob = null;
  try {
    blob = await resp.blob();
  } catch (e) {
    if (my !== st.loadToken || _wbPdfState !== st) return false;
    _wbPdfStateUI("error", "第 " + page + " 页页图读取失败", String((e && e.message) || e), { retry: true });
    return false;
  }
  if (my !== st.loadToken || _wbPdfState !== st) return false;
  const img = _wbEl("#wb-pdf-img");
  if (!img) return false;
  const objUrl = URL.createObjectURL(blob);
  const ok = await new Promise((resolve) => {
    img.onload = () => resolve(true);
    img.onerror = () => resolve(false);
    img.src = objUrl;
  });
  if (my !== st.loadToken || _wbPdfState !== st) {
    try { URL.revokeObjectURL(objUrl); } catch (e) {}
    return false;
  }
  if (!ok || !img.naturalWidth) {
    try { URL.revokeObjectURL(objUrl); } catch (e) {}
    _wbPdfStateUI("error", "第 " + page + " 页页图无法显示", "服务端返回的内容不是有效图片", { retry: true });
    return false;
  }
  if (st.objUrl) {
    try { URL.revokeObjectURL(st.objUrl); } catch (e) {}
  }
  st.objUrl = objUrl;
  img.hidden = false;
  _wbPdfStateUI("hide");
  st.loaded = true;
  _wbPdfApplyZoom();
  const sc = _wbEl("#wb-pdf-scroll");
  if (sc) {
    sc.scrollTop = 0;
    sc.scrollLeft = 0;
  }
  _wbPdfUpdateNav();
  _wbPdfStatus("第 " + page + " / " + total + " 页"
    + (st.renderer && st.renderer !== "cache" ? " · 页图渲染器 " + st.renderer : " · 页图预览"));
  return true;
}
function _wbPdfJumpInput() {
  const st = _wbPdfState;
  const input = _wbEl("#wb-pdf-pageinput");
  if (!st || !input) return;
  const n = parseInt(String(input.value || ""), 10);
  if (!n || isNaN(n)) {
    input.value = String(st.page || 1);
    return;
  }
  _wbPdfLoadPage(n);
}
async function _wbOpenPdfViewer(doc, seq) {
  const viewer = _wbEl("#wb-pdf-viewer");
  if (!viewer) return;
  _wbShowPdfViewer();
  const frame = _wbFrame();
  if (frame) frame.hidden = true;
  const prevState = _wbPdfState;
  if (prevState && prevState.objUrl) {
    try { URL.revokeObjectURL(prevState.objUrl); } catch (e) {}
  }
  const st = _wbPdfState = {
    docId: (doc || {}).id || "", token: seq, page: 1, pageCount: 0,
    zoomMode: "fit", pct: 100, renderer: "", loaded: false, loadToken: 0, objUrl: "",
  };
  const input = _wbEl("#wb-pdf-pageinput");
  if (input) input.value = "1";
  const totalEl0 = _wbEl("#wb-pdf-pagetotal");
  if (totalEl0) totalEl0.textContent = "-";
  const prevB = _wbEl("#wb-pdf-prev"), nextB = _wbEl("#wb-pdf-next");
  if (prevB) prevB.disabled = true;
  if (nextB) nextB.disabled = true;
  _wbPdfUpdateZoomLabel();
  _wbPdfStatus("");
  _wbPdfStateUI("loading", "正在读取 PDF 页信息…", "");
  const url = "/api/v1/projects/" + encodeURIComponent(currentWb)
    + "/documents/" + encodeURIComponent(st.docId) + "/pdf-meta";
  let meta = null;
  try {
    const r = await fetch(url);
    meta = await r.json().catch(() => null);
  } catch (e) {
    if (_wbPdfState !== st || seq !== _wbPreviewSeq) return;
    _wbPdfStateUI("error", "PDF 页信息读取失败", "网络错误：" + (e && e.message ? e.message : e), { retry: true });
    return;
  }
  if (_wbPdfState !== st || seq !== _wbPreviewSeq) return;
  if (!meta || meta.error || !meta.ok) {
    const msg = (meta && (meta.error || meta.message)) || "接口未返回有效数据";
    const details = (meta && meta.count_errors) || [];
    _wbPdfStateUI("error", "无法读取 PDF 页信息",
      [msg].concat(details.slice(0, 6).map(x => "· " + x)).join("\n"), { retry: true });
    _wbPdfStatus("页信息读取失败");
    return;
  }
  st.pageCount = Number(meta.page_count) || 0;
  const render = meta.render || {};
  if (st.pageCount < 1) {
    _wbPdfStateUI("empty", "没有可显示的页面", "后端读取到的 PDF 页数为 0。");
    _wbPdfStatus("无页面");
    return;
  }
  if (!render.available) {
    const lines = [render.error || "页图渲染不可用"];
    (render.details || []).slice(0, 6).forEach(x => lines.push("· " + x));
    _wbPdfStateUI("error", "PDF 页图渲染不可用",
      lines.join("\n") + "\n\n可安装 pypdfium2、安装 poppler，或配置 RULEPROOF_PDF_PAGE_CMD 后重试。",
      { retry: true });
    _wbPdfStatus("渲染器不可用");
    return;
  }
  st.renderer = render.engine || "";
  _wbPdfUpdateNav();
  await _wbPdfLoadPage(1);
}

/* ---------------------------------------------------------------- 解析文本视图 */
function _wbParseVisible() {
  const bar = _wbEl("#wb-parse-bar");
  return !!(bar && !bar.hidden);
}
function _wbShowParseBar() {
  const bar = _wbEl("#wb-parse-bar");
  if (bar) bar.hidden = false;
  const card = _wbCard();
  if (card) card.classList.add("wb-has-parsebar");
}
function _wbHideParseBar() {
  const bar = _wbEl("#wb-parse-bar");
  if (bar) bar.hidden = true;
  const card = _wbCard();
  if (card) card.classList.remove("wb-has-parsebar");
}
function _wbParseStatus(text) {
  const el = _wbEl("#wb-parse-status");
  if (el) el.textContent = text || "";
}
function _wbParseScroller() {
  const frame = _wbFrame();
  if (!frame) return null;
  try {
    const d = frame.contentDocument;
    if (!d) return null;
    return d.scrollingElement || d.documentElement;
  } catch (e) {
    return null;
  }
}
/* 短内容（不足 ~1.6 屏）按“单页”处理，并把纸张在 iframe 内垂直居中，
   避免固定高 iframe 下方出现无解释的大片空白；长内容按可视高度分页。 */
function _wbParseSetShortMode(on) {
  const st = _wbParseState;
  const frame = _wbFrame();
  if (!st || !frame) return;
  let doc = null;
  try { doc = frame.contentDocument; } catch (e) { return; }
  if (!doc) return;
  let style = null;
  try { style = doc.getElementById("wb-parse-short-style"); } catch (e) {}
  if (on) {
    if (!style) {
      try {
        style = doc.createElement("style");
        style.id = "wb-parse-short-style";
        style.textContent = "html{height:100%;overflow:auto!important}"
          + "body{min-height:100%;display:flex;align-items:center;justify-content:center;overflow:auto!important}"
          + ".doc-wrap{width:100%}";
        (doc.head || doc.documentElement).appendChild(style);
      } catch (e) { return; }
    }
    st.shortMode = true;
  } else {
    if (style && style.parentNode) {
      try { style.parentNode.removeChild(style); } catch (e) {}
    }
    st.shortMode = false;
  }
}
function _wbParseUpdateBar() {
  const st = _wbParseState;
  const bar = _wbEl("#wb-parse-bar");
  if (!st || !bar) return;
  const prev = _wbEl("#wb-parse-prev", bar), next = _wbEl("#wb-parse-next", bar);
  const input = _wbEl("#wb-parse-pageinput", bar), total = _wbEl("#wb-parse-pagetotal", bar);
  if (prev) prev.disabled = st.page <= 1;
  if (next) next.disabled = st.page >= st.pageCount;
  if (input && document.activeElement !== input) input.value = String(st.page || 1);
  if (total) total.textContent = String(st.pageCount || 1);
  const zoomval = _wbEl("#wb-parse-zoomval", bar);
  if (zoomval) zoomval.textContent = Math.round((st.zoom || 1) * 100) + "%";
}
function _wbParseAttach() {
  const st = _wbParseState;
  const frame = _wbFrame();
  if (!st || !frame) return;
  let win = null, doc = null;
  try {
    win = frame.contentWindow;
    doc = frame.contentDocument;
  } catch (e) { /* 同源 srcdoc 正常可访问 */ }
  if (!win || !doc) return;
  if (st._win === win) return;
  st._win = win;
  try { doc.documentElement.style.overflow = "auto"; } catch (e) {}
  try {
    // 解析文本 iframe 内同样显示常驻滚动条，避免用户看不到“还能左右/上下滚动”。
    if (!doc.getElementById("wb-parse-scroll-style")) {
      const _ss = doc.createElement("style");
      _ss.id = "wb-parse-scroll-style";
      _ss.textContent = "html{scrollbar-width:thin;scrollbar-color:#C9CDD4 #F1F3F5;}"
        + "::-webkit-scrollbar{width:12px;height:12px;background:#F1F3F5;}"
        + "::-webkit-scrollbar-thumb{background:#C9CDD4;border-radius:6px;border:3px solid #F1F3F5;}"
        + "::-webkit-scrollbar-track{background:#F1F3F5;}"
        + "::-webkit-scrollbar-corner{background:#F1F3F5;}";
      try { (doc.head || doc.documentElement).appendChild(_ss); } catch (e) {}
    }
  } catch (e) {}
  try { win.addEventListener("scroll", _wbParseOnScroll, { passive: true }); } catch (e) {}
  try {
    doc.addEventListener("keydown", (e) => {
      if (!_wbParseVisible() || e.altKey || e.metaKey) return;
      if (e.key === "PageDown") { e.preventDefault(); _wbParseStep(1); }
      else if (e.key === "PageUp") { e.preventDefault(); _wbParseStep(-1); }
      else if (e.key === "Home") { e.preventDefault(); _wbParseGoto(1); }
      else if (e.key === "End" && _wbParseState) { e.preventDefault(); _wbParseGoto(_wbParseState.pageCount); }
    });
  } catch (e) {}
}
function _wbParseRecompute(keepPage) {
  const st = _wbParseState;
  if (!st) return;
  _wbParseSetShortMode(false);
  const sc = _wbParseScroller();
  if (!sc) return;
  st._sc = sc;
  const viewH = Math.max(120, sc.clientHeight || 400);
  const scrollH = Math.max(viewH, sc.scrollHeight || viewH);
  st.pageHeight = viewH;
  st.rawHeight = scrollH;
  st.ratio = scrollH / viewH;
  st.shortMode = st.ratio <= 1.6;
  if (st.shortMode) {
    st.pageCount = 1;
    st.centered = st.ratio <= 1.01;
    if (st.centered) _wbParseSetShortMode(true);
  } else {
    st.centered = false;
    st.pageCount = Math.max(1, Math.ceil(scrollH / viewH));
  }
  if (keepPage) st.page = Math.max(1, Math.min(st.page || 1, st.pageCount));
  _wbParseUpdateBar();
}
function _wbParsePageStatus(page, total, suffix) {
  const tail = suffix ? " · " + suffix : "";
  _wbParseStatus("第 " + page + " 页 / 共 " + total + " 页" + tail);
}
function _wbParseGoto(page) {
  const st = _wbParseState;
  if (!st) return false;
  const total = st.pageCount || 1;
  page = Math.max(1, Math.min(total, Number(page) || 1));
  st.page = page;
  const sc = st._sc || _wbParseScroller();
  if (sc) {
    const maxScroll = Math.max(0, (sc.scrollHeight || 0) - (sc.clientHeight || 0));
    const top = st.shortMode ? 0 : (page >= total ? maxScroll : Math.min(maxScroll, (page - 1) * st.pageHeight));
    try { sc.scrollTop = top; } catch (e) {}
  }
  _wbParseUpdateBar();
  if (st.shortMode) {
    _wbParsePageStatus(1, 1, st.centered ? "内容不足一屏，已居中显示" : "内容较短，单页显示（可上下滚动）");
  } else {
    _wbParsePageStatus(page, total, "按可视高度分页");
  }
  return true;
}
function _wbParseStep(dir) {
  const st = _wbParseState;
  if (!st || st.shortMode) return;
  _wbParseGoto(st.page + dir);
}
let _wbParseScrollRaf = 0;
function _wbParseOnScroll() {
  const st = _wbParseState;
  if (!st || !st._sc || st.shortMode) return;
  if (_wbParseScrollRaf) return;
  _wbParseScrollRaf = requestAnimationFrame(() => {
    _wbParseScrollRaf = 0;
    const st2 = _wbParseState;
    if (!st2 || !st2._sc || st2.shortMode) return;
    const sc = st2._sc;
    const h = st2.pageHeight || 1;
    const maxScroll = Math.max(0, (sc.scrollHeight || 0) - (sc.clientHeight || 0));
    const top = sc.scrollTop || 0;
    let page;
    if (maxScroll > 0 && top >= maxScroll - 2) page = st2.pageCount;
    else page = Math.min(st2.pageCount, Math.floor((top + 2) / h) + 1);
    if (page !== st2.page) {
      st2.page = page;
      _wbParseUpdateBar();
      _wbParsePageStatus(page, st2.pageCount, "按可视高度分页");
    }
  });
}
function _wbParseZoom(dir) {
  const st = _wbParseState;
  if (!st) return;
  const next = Math.max(1, Math.min(3, Math.round(((st.zoom || 1) + dir * _WB_PARSE_ZOOM_STEP) * 100) / 100));
  st.zoom = next;
  const frame = _wbFrame();
  try {
    const doc = frame && frame.contentDocument;
    if (doc && doc.body) {
      // 先复位再量基准宽度：CSS zoom 单独使用时不会产生横向溢出，
      // 需要同时给 body 一个基准 min-width，放大后才能出现真实的左右滚动条。
      doc.body.style.zoom = "";
      doc.body.style.minWidth = "";
      const sc0 = doc.scrollingElement || doc.documentElement;
      const baseW = Math.max(280, sc0.clientWidth || 0);
      if (next > 1) {
        doc.body.style.zoom = String(next);
        doc.body.style.minWidth = Math.round(baseW) + "px";
      }
    }
  } catch (e) {}
  // 缩放后可视高度不变、文档高度变化：重算分页并停在同一逻辑页码
  const page = st.page || 1;
  _wbParseRecompute(false);
  _wbParseGoto(Math.min(page, st.pageCount));
  _wbParseUpdateBar();
}
let _wbParseResizeTimer = 0;
function _wbParseOnResize() {
  const st = _wbParseState;
  if (!st || !_wbParseVisible()) return;
  if (_wbParseResizeTimer) clearTimeout(_wbParseResizeTimer);
  _wbParseResizeTimer = setTimeout(() => {
    _wbParseResizeTimer = 0;
    const st2 = _wbParseState;
    if (!st2 || !_wbParseVisible()) return;
    const page = st2.page || 1;
    _wbParseRecompute(false);
    _wbParseGoto(Math.min(page, st2.pageCount));
    if (!st2.shortMode) _wbParsePageStatus(st2.page, st2.pageCount, "已按窗口高度重算");
  }, 160);
}
function _wbParseJumpInput() {
  const st = _wbParseState;
  const input = _wbEl("#wb-parse-pageinput");
  if (!st || !input) return;
  const n = parseInt(String(input.value || ""), 10);
  if (!n || isNaN(n)) {
    input.value = String(st.page || 1);
    return;
  }
  _wbParseGoto(n);
}
function _wbInitParse(prevPreview) {
  const bar = _wbEl("#wb-parse-bar");
  if (!bar) return;
  _wbParseState = { page: 1, pageCount: 1, pageHeight: 1, zoom: 1, ratio: 1,
                    shortMode: false, centered: false, doc: wbCurrentDoc, _win: null, _sc: null };
  try {
    const d0 = _wbFrame() && _wbFrame().contentDocument;
    if (d0 && d0.body) { d0.body.style.zoom = ""; d0.body.style.minWidth = ""; }
  } catch (e) {}
  _wbShowParseBar();
  const input = _wbEl("#wb-parse-pageinput");
  if (input) input.value = "1";
  const total = _wbEl("#wb-parse-pagetotal");
  if (total) total.textContent = "-";
  _wbParsePageStatus(1, 1, "正在计算分页…");
  _wbParseAttach();
  const calibrate = (keep) => {
    if (!_wbParseState || !_wbParseVisible()) return;
    const page = keep ? (_wbParseState.page || 1) : 1;
    _wbParseRecompute(true);
    _wbParseGoto(Math.min(page, _wbParseState.pageCount));
    if (prevPreview && prevPreview.page_count && _wbParseState && !_wbParseState.shortMode) {
      _wbParseStatus("第 " + _wbParseState.page + " 页 / 共 " + _wbParseState.pageCount
        + " 页（按可视高度分页；PDF 原始共 " + prevPreview.page_count + " 页）");
    }
  };
  requestAnimationFrame(() => calibrate(false));
  // srcdoc 加载后字体/布局可能再变化，二次校准页码总数
  setTimeout(() => calibrate(true), 180);
}

/* ---------------------------------------------------------------- 事件绑定 */
function _wbBindPdfViewer(viewer) {
  const q = (s) => viewer.querySelector(s);
  const prev = q("#wb-pdf-prev"), next = q("#wb-pdf-next");
  if (prev) prev.addEventListener("click", () => { _wbPdfLoadPage((_wbPdfState || {}).page - 1); });
  if (next) next.addEventListener("click", () => { _wbPdfLoadPage((_wbPdfState || {}).page + 1); });
  const zoomin = q("#wb-pdf-zoomin"), zoomout = q("#wb-pdf-zoomout");
  if (zoomin) zoomin.addEventListener("click", () => _wbPdfZoom(1));
  if (zoomout) zoomout.addEventListener("click", () => _wbPdfZoom(-1));
  const fit = q("#wb-pdf-fit"), zoomval = q("#wb-pdf-zoomval");
  if (fit) fit.addEventListener("click", _wbPdfFit);
  if (zoomval) zoomval.addEventListener("click", _wbPdfFit);
  const retry = q("#wb-pdf-retry");
  if (retry) retry.addEventListener("click", () => {
    const st = _wbPdfState;
    if (st) _wbOpenPdfViewer({ id: st.docId }, ++_wbPreviewSeq);
  });
  const input = q("#wb-pdf-pageinput");
  if (input) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); _wbPdfJumpInput(); }
      else if (e.key === "Escape") { input.value = String((_wbPdfState || {}).page || 1); input.blur(); }
    });
    input.addEventListener("change", _wbPdfJumpInput);
  }
  const sc = q("#wb-pdf-scroll");
  if (sc) {
    sc.addEventListener("keydown", (e) => {
      if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
      const st = _wbPdfState;
      if (!st) return;
      if (e.key === "ArrowLeft" || e.key === "PageUp") { e.preventDefault(); _wbPdfLoadPage(st.page - 1); }
      else if (e.key === "ArrowRight" || e.key === "PageDown") { e.preventDefault(); _wbPdfLoadPage(st.page + 1); }
      else if (e.key === "Home") { e.preventDefault(); _wbPdfLoadPage(1); }
      else if (e.key === "End") { e.preventDefault(); _wbPdfLoadPage(st.pageCount); }
      else if (e.key === "+" || e.key === "=") { e.preventDefault(); _wbPdfZoom(1); }
      else if (e.key === "-" || e.key === "_") { e.preventDefault(); _wbPdfZoom(-1); }
      else if (e.key === "0") { e.preventDefault(); _wbPdfFit(); }
    });
    sc.addEventListener("mousedown", () => { try { sc.focus({ preventScroll: true }); } catch (e) {} });
    if (window.ResizeObserver) {
      let raf = 0;
      const ro = new ResizeObserver(() => {
        if (raf) return;
        raf = requestAnimationFrame(() => {
          raf = 0;
          if (_wbPdfVisible() && _wbPdfState && _wbPdfState.zoomMode === "pct") _wbPdfApplyZoom();
        });
      });
      ro.observe(sc);
    } else {
      window.addEventListener("resize", () => { if (_wbPdfVisible()) _wbPdfApplyZoom(); });
    }
  }
}
function _wbBindParseBar(bar) {
  const q = (s) => bar.querySelector(s);
  const prev = q("#wb-parse-prev"), next = q("#wb-parse-next");
  if (prev) prev.addEventListener("click", () => _wbParseStep(-1));
  if (next) next.addEventListener("click", () => _wbParseStep(1));
  const input = q("#wb-parse-pageinput");
  if (input) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); _wbParseJumpInput(); }
      else if (e.key === "Escape") { input.value = String((_wbParseState || {}).page || 1); input.blur(); }
    });
    input.addEventListener("change", _wbParseJumpInput);
  }
  const zoomin = q("#wb-parse-zoomin"), zoomout = q("#wb-parse-zoomout"), zoomval = q("#wb-parse-zoomval");
  if (zoomin) zoomin.addEventListener("click", () => _wbParseZoom(1));
  if (zoomout) zoomout.addEventListener("click", () => _wbParseZoom(-1));
  if (zoomval) zoomval.addEventListener("click", () => {
    const st = _wbParseState;
    if (!st) return;
    const diff = Math.round((1 - (st.zoom || 1)) * 100) / 100;
    if (diff) _wbParseZoom(diff > 0 ? 1 : -1);
  });
  bar.addEventListener("keydown", (e) => {
    if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
    if (e.key === "ArrowLeft") { e.preventDefault(); _wbParseStep(-1); }
    else if (e.key === "ArrowRight") { e.preventDefault(); _wbParseStep(1); }
  });
  window.addEventListener("resize", _wbParseOnResize);
}

/* ---------------------------------------------------------------- 模式切换 */
function setupWbSheetSwitch() {
  const sw = document.querySelector("#wb-sheet-switch"), sel = document.querySelector("#wb-sheet-select"), fr = document.querySelector("#wb-doc-frame");
  const d = (wbDocs || []).find(x => x.id === wbCurrentDoc) || (wbDocs || [])[0] || {};
  const isXlsx = /\.(xlsx|xls)$/i.test(String(d.filename || ""));
  if (!sw || !sel || !fr || !isXlsx) { if (sw) sw.hidden = true; return; }
  let sheets = [];
  try { sheets = [...fr.contentDocument.querySelectorAll(".sheet")]; } catch (e) { sheets = []; }
  if (sheets.length < 1) { sw.hidden = true; return; }
  const names = sheets.map((x, i) => (x.querySelector(".sheet-head")?.textContent || `Sheet${i + 1}`).trim());
  sel.innerHTML = names.map((n, i) => `<option value="${i}">${esc(n)}</option>`).join("");
  sw.hidden = false;
  const apply = (idx) => {
    try {
      const all = [...fr.contentDocument.querySelectorAll(".sheet")];
      all.forEach((x, i) => { x.style.display = i === idx ? "" : "none"; });
      const head = fr.contentDocument.querySelector(".sheet-head");
      if (head) head.scrollIntoView({ block: "start" });
    } catch (e) {}
  };
  sel.onchange = () => apply(Number(sel.value) || 0);
  apply(0);
}

function _wbSetFrameHtml(html) {
  return new Promise((resolve) => {
    const fr = _wbFrame();
    if (!fr) return resolve(false);
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve(true);
    };
    try {
      fr.removeAttribute("src");
      fr.onload = finish;
      fr.srcdoc = html;
    } catch (e) { return resolve(false); }
    setTimeout(finish, 800);
  });
}

async function loadWbPreview(docId, mode) {
  wbCurrentDoc = docId || "";
  if (mode) wbPreviewMode = mode;
  const d = _wbCurDoc();
  const isPdf = _wbIsPdfDoc(d);
  if (!isPdf) wbPreviewMode = "text";
  const seq = ++_wbPreviewSeq;
  const _meta = document.querySelector("#wb-file-meta");
  const _modes = document.querySelector("#wb-preview-modes");
  if (_modes) {
    _modes.hidden = !isPdf;
    _modes.querySelectorAll("[data-preview-mode]").forEach(b => {
      b.classList.toggle("primary", b.dataset.previewMode === wbPreviewMode);
      b.onclick = () => loadWbPreview(wbCurrentDoc, b.dataset.previewMode);
    });
  }
  if (_meta) {
    const _ps = d.parse_status === "ok" ? "解析完整" : d.parse_status === "partial" ? "解析不完整" : d.parse_status === "failed" ? "解析失败" : "解析状态未知";
    const _modeLabel = isPdf ? (wbPreviewMode === "file" ? "原始 PDF 页图视图" : "解析文本视图") : "解析预览";
    _meta.innerHTML = `<b>${esc(d.filename || "当前文件")}</b><span>${esc(_ps)}${d.parse_summary ? " · " + esc(d.parse_summary) : ""}${isPdf ? " · " + _modeLabel : ""}</span>`;
  }
  if (!wbEnsurePreviewUI()) return;
  const frame = _wbFrame();
  if (isPdf && wbPreviewMode === "file") {
    _wbParseState = null;
    _wbHideParseBar();
    const sw = document.querySelector("#wb-sheet-switch");
    if (sw) sw.hidden = true;
    await _wbOpenPdfViewer(d, seq);
    return;
  }
  _wbParseState = null;
  _wbHideParseBar();
  _wbHidePdfViewer();
  if (frame) frame.hidden = false;
  const sw = document.querySelector("#wb-sheet-switch");
  if (sw) sw.hidden = true;
  if (!d.id) {
    await _wbSetFrameHtml(_wbNoticeHtml("暂无文档", "当前项目还没有上传文件。"));
    return;
  }
  const url = "/api/v1/projects/" + encodeURIComponent(currentWb) + "/preview?doc_id=" + encodeURIComponent(d.id);
  let prev = null;
  try {
    const r = await fetch(url);
    prev = await r.json();
  } catch (e) {
    if (seq !== _wbPreviewSeq) return;
    await _wbSetFrameHtml(_wbNoticeHtml("预览加载失败", "网络错误：" + (e && e.message ? e.message : e)));
    return;
  }
  if (seq !== _wbPreviewSeq) return;
  if (!prev || prev.error) {
    await _wbSetFrameHtml(_wbNoticeHtml("预览加载失败", (prev && (prev.error || prev.message)) || "接口未返回有效数据"));
    return;
  }
  await _wbSetFrameHtml(prev.html || _wbNoticeHtml("暂无预览", "该文件没有可渲染的解析结果。"));
  if (seq !== _wbPreviewSeq) return;
  setupWbSheetSwitch();
  if (isPdf) {
    _wbInitParse(prev);
  } else {
    _wbHideParseBar();
  }
}

/* 供「定位」与测试调用：跳到原始 PDF 指定页；视图未就绪返回 false。 */
function wbPdfGotoPage(page) {
  const st = _wbPdfState;
  if (!st || !_wbPdfVisible() || !st.pageCount) return false;
  const n = parseInt(String(page), 10);
  if (!n || isNaN(n)) return false;
  _wbPdfLoadPage(n);
  return true;
}
