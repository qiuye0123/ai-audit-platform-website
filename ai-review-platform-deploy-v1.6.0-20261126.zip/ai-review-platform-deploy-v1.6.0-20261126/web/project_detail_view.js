/* 项目详情渲染：从 app.js 拆出；依赖 app.js 的 $/esc/PROJ_STATUS/openProject。 */
// P2-B5-01：文件数上限与服务端同源（不再前后端各写一个数字）。
let _PJ_MAX_FILES = 10;
function _pjMaxFiles() { return _PJ_MAX_FILES; }
(async function _pjLoadLimits() {
  try {
    const r = await (await fetch("/api/v1/system/capabilities")).json();
    const n = Number((r && r.limits && r.limits.max_files) || 0);
    if (n > 0) _PJ_MAX_FILES = n;
  } catch (e) { /* 取不到退回默认值，不阻断页面 */ }
})();

async function renderProject(id, d) {
  const _co = d.case || d;
  $("#proj-title").textContent = _co.name || "项目";
  let _pl = {};
  try { _pl = await (await fetch("/api/v1/projects")).json(); } catch (e) { _pl = {}; }
  const _arr = Array.isArray(_pl) ? _pl : (_pl.items || []);
  const proj = _arr.find(p => p.id === id) || {};
  $("#proj-meta").textContent = `${PROJ_STATUS[proj.status] || proj.status || ''} · 文件 ${proj.document_count || 0} · 发现 ${proj.finding_count || 0} · 待复核 ${proj.pending_count || 0} · ${_co.created_at || ''}`;
  // 解析缺口接受（后端已有 accept-gap，前端必须有出口）
  (function renderGaps() {
    const box = document.getElementById("proj-gaps");
    if (!box) return;
    const gaps = (d.documents || []).filter(x => ["partial", "failed"].includes(x.parse_status) &&
      !String(x.parse_summary || "").startsWith("[缺口已接受]"));
    box.innerHTML = gaps.length ? `<div class="card"><b>解析缺口（${gaps.length}）</b>` +
      gaps.map(x => `<div style="margin:6px 0">${esc(x.filename)}：${esc(x.parse_summary || x.parse_status)}
        <button class="btn" data-accept-gap="${esc(x.id)}">接受缺口</button></div>`).join("") + `</div>` : "";
    box.querySelectorAll("[data-accept-gap]").forEach(b => b.addEventListener("click", async () => {
      const reason = prompt("接受缺口理由（会写审计日志）", "纯文字文档，无参数表");
      if (!reason) return;
      const r = await (await fetch(`/api/v1/projects/${id}/documents/${b.dataset.acceptGap}/accept-gap`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reason }) })).json();
      if (r.error) { alert(r.error); return; }
      openProject(id);
    }));
  })();
  [["#export-html", "report.html"], ["#export-docx", "report.docx"]]
    .forEach(([sel, f]) => { const el = $(sel); if (el) { el.hidden = false; el.href = `/api/v1/reviews/${id}/${f}`; } });
  // 旧点位判据结果：提示并提供重跑入口
  (async function renderPointStale() {
    try {
      const r = await (await fetch(`/api/v1/projects/${id}/point-stale`)).json();
      if (!r.stale_count) return;
      const box = document.getElementById("proj-gaps"); if (!box) return;
      box.insertAdjacentHTML("afterbegin", `<div class="card" style="border-left:4px solid #B45309;padding:10px 12px;margin-bottom:8px">
        <b>点位判据已更新：${r.stale_count} 条发现基于旧版本</b>
        <div class="muted" style="margin:4px 0 8px">涉及点位：${(r.points || []).slice(0, 8).join("、")}${(r.points || []).length > 8 ? "…" : ""}</div>
        <button class="btn" id="proj-rerun-stale">重跑审核</button></div>`);
      document.getElementById("proj-rerun-stale").onclick = function () {
        runAuditAsync(id, true, "", "", _co.name || "当前项目");
      };
    } catch (e) {}
  })();
  // 文件
  let files = [];
  try { files = await (await fetch(`/api/v1/projects/${id}/documents`)).json(); } catch (e) { files = []; }
  if (!Array.isArray(files)) files = [];
  const PARSE = { ok: ["published", "解析成功"], partial: ["draft", "解析不完整"], failed: ["draft", "解析失败"] };
  $("#proj-files").innerHTML = files.length
    ? files.map(f => {
        const [cls, label] = PARSE[f.parse_status] || ["r", f.parse_status || "未知"];
        return `<div class="file-row"><span class="pill r">${esc(f.doc_type || '')}</span> ${esc(f.filename)}
          <span class="pill ${cls}">${label}</span>
          <span class="muted">${esc(f.parse_summary || '')}</span></div>`;
      }).join("")
    : `<div class="muted">还没有文件，请上传（支持 xlsx/docx/pdf，最多 ${_pjMaxFiles()} 份，单份 ≤100MB、合计 ≤300MB，多份将合并为一份审核）</div>`;
  // 发现
  const s = d.summary || {};
  $("#proj-summary").textContent = s.total ? `严重 ${s.critical_count} · 一般 ${s.warning_count} · 提示 ${s.suspected_count || 0} · 结论 ${s.status}` : "";
  $("#proj-findings").innerHTML = (d.findings || []).length
    ? d.findings.map(f => findingRow(f)).join("")
    : uxEmptyHTML({
        title: "尚未运行审核",
        desc: "上传文件并运行审核后，发现会显示在这里；也可以先返回项目列表查看其他项目。",
        action: { label: "返回项目列表", action: "view:projects" },
      });
  bindDecisions();
  bindSediment();
  // 报告
  $("#proj-report-card").hidden = !(d.findings || []).length;
  if ((d.findings || []).length) $("#proj-report").src = `/api/v1/reviews/${id}/report.html`;
}
