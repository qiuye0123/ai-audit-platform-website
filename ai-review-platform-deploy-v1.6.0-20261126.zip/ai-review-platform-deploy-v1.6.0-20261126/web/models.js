/* 模型管理页面模块：从 app.js 拆出。 */
/* 模型状态文案：OCR 模型只有真实测试连接通过才把状态记为“连接成功（数据库记录）”，
   仅配置了 Key（环境变量或模型配置）时显示“已配置（待测试）”，不伪造连接。 */
function _modelStatusLabel(m) {
  const st = (m && (m.state || m.status)) || "";
  if (st === "ok") return "连接正常（数据库记录）";
  if (st === "configured") return "已配置待测";
  if (st === "fail") return "连接失败";
  if (st === "unconfigured") return "未配置";
  return "○ 未测试";
}
/* 四态徽标：未配置 / 已配置待测 / 连接正常 / 连接失败；管理启用只是开关，不做可用性主徽标。 */
function _modelStatePill(m) {
  const st = (m && (m.state || m.status)) || "unconfigured";
  const label = _modelStatusLabel(m);
  const cls = st === "ok" ? "published" : st === "unconfigured" ? "draft" : st === "fail" ? "r" : "draft";
  return `<span class="pill ${cls}" title="四态：未配置 / 已配置待测 / 连接正常 / 连接失败">${esc(label)}</span>`;
}
async function loadModels() {
  if (typeof uxSetLoading === "function") uxSetLoading("#model-out", "正在加载模型配置…", 3);
  let d, pts;
  try {
    const [rm, rp] = await Promise.all([fetch("/api/v1/models"), fetch("/api/v1/model/points")]);
    d = await rm.json(); pts = await rp.json();
    if (!rm.ok || !rp.ok || !d || d.error) throw new Error((d && d.error) || ("HTTP " + rm.status));
  } catch (e) {
    if (typeof uxSetEmpty === "function") {
      uxSetEmpty("#model-out", { title: "模型配置加载失败", desc: "请检查网络或重新登录后重试；不会修改任何模型配置。" });
    } else {
      $("#model-out").innerHTML = '<div class="empty">模型配置加载失败，请重试</div>';
    }
    $("#model-kpis").innerHTML = "";
    $("#model-stats-table").innerHTML = "";
    $("#model-points").innerHTML = "";
    return;
  }
  window.__models = d.items || [];
  const _av = d.availability || {};
  const _avc = _av.counts || {};
  const _ms = d.items || [];
  const _active = _ms.filter(m => Number((m.stats || {}).calls || 0) > 0);
  const _totCalls = _ms.reduce((n, m) => n + Number((m.stats || {}).calls || 0), 0);
  const _totTokens = _ms.reduce((n, m) => n + Number((m.stats || {}).tokens || 0), 0);
  const _totSuccess = _ms.reduce((n, m) => n + Number((m.stats || {}).success || 0), 0);
  const _totFail = _ms.reduce((n, m) => n + Number((m.stats || {}).failure || 0), 0);
  const _rate = (_totSuccess + _totFail) ? Math.round(_totSuccess / (_totSuccess + _totFail) * 100) : null;
  const _fmt = (n) => Number(n || 0).toLocaleString("zh-CN");
  $("#model-kpis").className = "kpis model-kpis";
  $("#model-kpis").innerHTML = [
    { label: "模型配置行", value: d.total, color: "#3370FF", scope: "本租户" },
    { label: "未配置", value: _avc.unconfigured != null ? _avc.unconfigured : d.unconfigured || 0, color: "#D83931", scope: "无凭据" },
    { label: "已配置待测", value: _avc.configured || 0, color: "#B25E00", scope: "有凭据未真实测试" },
    { label: "连接正常", value: _avc.ok != null ? _avc.ok : d.connected || 0, color: "#00B578", scope: "真实测试成功" },
    { label: "连接失败", value: _avc.fail || 0, color: "#D83931", scope: "最近测试失败" },
    { label: "管理启用", value: d.enabled, color: "#646A73", scope: "开关≠可用" },
    { label: "累计调用", value: _fmt(_totCalls), color: "#1F2329", scope: "本租户 · 全时间" },
    { label: "累计 Tokens", value: _fmt(_totTokens), color: "#1F2329", scope: "本租户 · 全时间" },
    { label: "默认模型", value: d.default_model || "—", color: "#B25E00", scope: "本租户" },
  ].map(k => `<div class="kpi"><b style="color:${k.color};font-size:${String(k.value).length > 8 ? "13px" : String(k.value).length > 5 ? "18px" : "26px"}">${esc(String(k.value))}</b><span>${k.label}</span><div class="k-hint"><span class="scope-chip">${esc(k.scope || "")}</span></div></div>`).join("");
  const _ocr = _av.ocr || {};
  const _ocrLine = (x, fallback) => x
    ? `<b>${esc(x.name || fallback)}</b> ${esc(x.state_label || "")}${x.status_note ? `<div class="muted" style="font-size:11px;line-height:1.5">${esc(x.status_note)}</div>` : ""}`
    : '<span class="muted">未预置</span>';
  const _ocrBox = document.getElementById("model-ocr-line");
  if (_ocrBox) {
    _ocrBox.innerHTML = `<div class="model-ocr-note"><div class="mon-title">OCR 主备链路 <span class="scope-chip">本租户 · 与模型四态同源</span></div>
      <div class="mon-grid"><div><span>主链路</span>${_ocrLine(_ocr.primary, "百度智能云 Unlimited-OCR-2")}</div>
      <div><span>备用</span>${_ocrLine(_ocr.backup, "PaddleOCR-VL")}</div>
      <div><span>真实引擎</span>${_ocr.engine_configured ? '<span class="pill published">已配置</span>' : '<span class="pill draft">未配置</span>'}${_ocr.engine_note ? `<div class="muted" style="font-size:11px">${esc(_ocr.engine_note)}</div>` : ""}</div></div>
      <div class="muted" style="font-size:11px;margin-top:4px">${esc(_ocr.policy || "无 Key 显示未配置，不伪造识别成功")}</div></div>`;
  }
  const statHead = () => `<div class="model-stat-head"><div><b>调用明细</b><span class="muted">活跃模型 ${_active.length}/${_ms.length}${_rate == null ? "" : " · 成功率 " + _rate + "%"}</span></div><label class="model-zero-toggle"><input type="checkbox" id="model-show-zero" ${window.__modelShowZero ? "checked" : ""}> 显示未调用模型</label></div>`;
  const renderModelStats = () => {
    const rows = (window.__modelShowZero ? _ms : _active)
      .slice().sort((a, b) => Number((b.stats || {}).calls || 0) - Number((a.stats || {}).calls || 0));
    if (!rows.length) { $("#model-stats-table").innerHTML = statHead() + '<div class="empty" style="padding:16px 0">暂无模型调用；审核任务调用模型后会在这里累计统计。</div>'; const t = $("#model-show-zero"); if (t) t.onchange = () => { window.__modelShowZero = t.checked; renderModelStats(); }; return; }
    $("#model-stats-table").innerHTML = statHead() + `<table class="table model-stat-table"><thead><tr><th>模型</th><th class="num">调用</th><th class="num">Tokens</th><th class="num">成功 / 失败</th><th class="num">成功率</th><th class="num">平均延迟</th><th>最近调用</th></tr></thead><tbody>` +
      rows.map(m => {
        const st = m.stats || {};
        const rate = st.success_rate == null ? "—" : Math.round(st.success_rate * 100) + "%";
        return `<tr><td><b>${esc(m.name)}</b>${m.is_default ? ' <span class="pill published">默认</span>' : ""}<div class="muted" style="font-size:11px">${esc(m.model_id || "")} · ${esc(m.provider || "")}</div></td>
          <td class="num">${_fmt(st.calls)}</td><td class="num">${_fmt(st.tokens)}</td><td class="num">${_fmt(st.success)} / ${_fmt(st.failure)}</td>
          <td class="num">${rate}</td><td class="num">${st.calls ? Math.round(st.avg_latency_ms || 0) + " ms" : "—"}</td><td class="muted">${esc(st.last_call || "—")}</td></tr>`;
      }).join("") + `</tbody></table>`;
    const t = $("#model-show-zero"); if (t) t.onchange = () => { window.__modelShowZero = t.checked; renderModelStats(); };
  };
  renderModelStats();
  $("#model-out").innerHTML = (d.items || []).length ? `<div class="model-grid">` + d.items.map(m => `
    <div class="model-card" data-mid="${esc(m.id)}">
      <div class="mc-head">
        <div style="flex:1">
          <div class="mc-title">${esc(m.name)} ${m.is_default ? `<span class="pill published">默认</span>` : ""}</div>
          <div class="mc-sub">${esc(m.provider)} · ${esc(m.model_id)}</div>
        </div>
        <span class="mc-state-wrap">${_modelStatePill(m)}<span class="pill draft" title="管理开关，不等于可用">${m.enabled ? "管理启用" : "管理停用"}</span></span>
      </div>
      <div class="mc-caps">${(m.capability_labels || []).map(c => `<span class="mc-cap">${esc(c)}</span>`).join("")}</div>
      <div class="mc-status">${_modelStatusLabel(m)}
        <span class="muted" style="margin-left:auto">${(m.stats && m.stats.calls) ? `${m.stats.calls} 次调用 · ${m.stats.tokens} tokens` : "暂无调用"}</span></div>
      ${m.status_note ? `<div class="muted" style="font-size:11px;line-height:1.5;margin-top:2px">${esc(m.status_note)}</div>` : ""}
      <div class="mc-actions">
        <button class="btn" data-mdetail="${esc(m.id)}">详情</button>
        <button class="btn" data-mtest="${esc(m.id)}" ${m.status === "unconfigured" ? 'disabled title="未配置密钥：先填 API Key 或配置环境变量，再测试连接（不会伪造成功）"' : 'title="发起真实最小调用，失败会如实显示原因"'}>测试连接</button>
        <button class="btn" data-medit="${esc(m.id)}">编辑</button>
        <button class="btn" data-mdflt="${esc(m.id)}">设为默认</button>
        <button class="btn danger" data-mdel="${esc(m.id)}">删除</button>
      </div>
    </div>`).join("") + `</div>` : `<div class="empty">还没有接入模型，点右上角「接入模型」</div>`;
  $("#model-points").innerHTML = `<table class="table"><thead><tr><th style="width:56px">序号</th><th>调用点</th><th>绑定模型</th><th>说明</th><th>触发位置</th><th>模型调用</th><th>成功 / 失败</th><th>成功率</th><th>Token</th><th>状态</th></tr></thead><tbody>` +
    (pts || []).map((p, pi) => {
      const st = p.stats || {};
      return `<tr style="cursor:pointer" data-point-key="${esc(p.key)}"><td class="muted">${(pts || []).length - pi}</td>
        <td><b>${esc(p.name)}</b><div class="muted" style="font-size:11px">${esc(p.key)}</div></td>
        <td>${esc(p.model_name || "未绑定")}<div class="muted" style="font-size:11px">${esc(p.model_code || "")}</div></td>
        <td class="muted">${esc(p.desc)}</td><td class="muted">${esc(p.endpoint)}</td>
        <td>${st.calls || 0}</td><td>${(st.success || 0)} / ${(st.failure || 0)}</td>
        <td>${st.success_rate == null ? "—" : Math.round(st.success_rate * 100) + "%"}</td><td>${st.tokens || 0}</td>
        <td>${p.used ? '<span class="pill published">启用</span>' : '<span class="pill draft">未启用</span>'}${p.status_note ? `<div class="muted" style="font-size:10.5px;line-height:1.45;margin-top:3px;max-width:150px">${esc(p.status_note)}</div>` : ""}</td></tr>`;
    }).join("") +
    `</tbody></table>`;
  document.querySelectorAll("[data-point-key]").forEach(tr => tr.addEventListener("click", () => {
    const p = (pts || []).find(x => x.key === tr.dataset.pointKey); if (p) openEndpointDetail(p);
  }));
  $("#model-out").querySelectorAll("[data-mdetail]").forEach(a => a.addEventListener("click", () => openModelDetail(a.dataset.mdetail)));
  $("#model-out").querySelectorAll("[data-mtest]").forEach(a => a.addEventListener("click", async () => {
    const old = a.textContent; a.disabled = true; a.textContent = "测试中…";
    try {
      const r = await (await fetch(`/api/v1/models/${a.dataset.mtest}/test`, { method: "POST" })).json();
      // OCR 模型走真实 OCR 探测，detail 会说明真实结果（鉴权/任务提交/未配置），不显示假“连接成功”。
      showToast(r.ok ? (r.detail || "连接成功") : ("连接失败：" + (r.detail || "")), r.ok ? "ok" : "err");
      await loadModels();
    } finally { a.disabled = false; a.textContent = old; }
  }));
  $("#model-out").querySelectorAll("[data-mdflt]").forEach(a => a.addEventListener("click", async () => {
    if (!confirm("确认将这条模型设为默认？未显式指定模型的任务都会使用它。")) return;
    const r = await (await fetch(`/api/v1/models/${a.dataset.mdflt}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ is_default: true }) })).json();
    if (r.error) { showToast("设置失败：" + r.error, "err"); return; }
    showToast("已设为默认模型", "ok"); loadModels();
  }));
  $("#model-out").querySelectorAll("[data-mdel]").forEach(a => a.addEventListener("click", async () => {
    if (!confirm("确定删除该模型？删除后任务会回落到默认模型。")) return;
    const r = await (await fetch(`/api/v1/models/${a.dataset.mdel}/delete`, { method: "POST" })).json();
    if (r.error) { showToast("删除失败：" + r.error, "err"); return; }
    showToast("模型已删除", "ok"); loadModels();
  }));
  $("#model-out").querySelectorAll("[data-medit]").forEach(a => a.addEventListener("click", () => modelEdit(a.dataset.medit)));
}
function openModelDetail(mid) {
  const m = (window.__models || []).find(x => x.id === mid); if (!m) return;
  const st = m.stats || {};
  const isOcr = (m.capabilities || []).indexOf("ocr") >= 0;
  const old = document.querySelector("#model-detail-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "model-detail-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(620px,calc(100vw - 32px))">
    <div class="settings-head"><h3>${esc(m.name)}</h3><button class="ws-close" data-md-close>×</button></div>
    <div class="settings-section"><div class="settings-title">基本信息</div>
      <div class="np-grid"><div class="np-field"><span>Provider</span><b>${esc(m.provider || "—")}</b></div>
      <div class="np-field"><span>模型 ID</span><b>${esc(m.model_id || "—")}</b></div>
      <div class="np-field"><span>能力</span><b>${esc((m.capability_labels || []).join("、") || "—")}</b></div>
      <div class="np-field"><span>管理状态</span><b>${m.enabled ? "管理启用（开关）" : "管理停用"}</b></div>
      <div class="np-field"><span>可用性（四态）</span><b>${esc(_modelStatusLabel(m))}</b>${m.status_note ? `<div class="muted" style="font-size:11px;line-height:1.5">${esc(m.status_note)}</div>` : ""}</div>
      <div class="np-field"><span>默认</span><b>${m.is_default ? "是" : "否"}</b></div><div class="np-field"><span>接入时间</span><b>${esc(m.created_at || "—")}</b></div>
      <div class="np-field"><span>密钥来源</span><b>${esc(m.credential_source || "—")}</b></div>
      <div class="np-field wide"><span>状态说明</span><span class="muted">${esc(m.status_note || "—")}</span></div></div>
      ${isOcr ? `<div class="muted" style="font-size:12px;margin-top:8px">OCR 模型：「测试连接」会发起真实最小图片 OCR 请求（百度 Unlimited-OCR / PaddleOCR-VL / 该行视觉 OCR），不会用对话接口冒充 OCR。</div>` : ""}</div>
    <div class="settings-section"><div class="settings-title">调用统计</div>
      <div class="ac-kpis" style="grid-template-columns:repeat(4,minmax(0,1fr))"><div class="ac-kpi"><b>${st.calls || 0}</b><span>调用次数</span></div><div class="ac-kpi"><b>${st.success || 0}</b><span>成功</span></div><div class="ac-kpi"><b>${st.failure || 0}</b><span>失败</span></div><div class="ac-kpi"><b>${st.tokens || 0}</b><span>Token</span></div></div>
      <div class="muted" style="font-size:12px;margin-top:8px">平均延迟 ${st.avg_latency_ms || 0}ms · 最近调用 ${esc(st.last_call || "暂无")}</div></div>
    <div class="settings-foot"><button class="btn" data-md-close>关闭</button></div></div>`;
  document.body.appendChild(mask); const close = () => mask.remove();
  mask.querySelectorAll("[data-md-close]").forEach(b => b.onclick = close); mask.onclick = e => { if (e.target === mask) close(); };
}
function openEndpointDetail(p) {
  const old = document.querySelector("#endpoint-detail-modal"); if (old) old.remove();
  const st = p.stats || {};
  const mask = document.createElement("div"); mask.id = "endpoint-detail-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(660px,calc(100vw - 32px))">
    <div class="settings-head"><h3>${esc(p.name)}</h3><button class="ws-close" data-ep-close>×</button></div>
    <div class="settings-section"><div class="settings-title">绑定与触发</div>
      <div class="np-grid"><div class="np-field"><span>绑定模型</span><b>${esc(p.model_name || "未绑定")}</b></div>
      <div class="np-field"><span>模型标识</span><b>${esc(p.model_code || "—")}</b></div>
      <div class="np-field wide"><span>触发位置</span><b>${esc(p.endpoint || "—")}</b></div>
      <div class="np-field wide"><span>用途</span><span class="muted">${esc(p.desc || "—")}</span></div></div></div>
    <div class="settings-section"><div class="settings-title">绑定模型调用统计</div><div class="muted" style="font-size:11px;margin:-4px 0 8px">当前接入点按绑定模型汇总调用；接入点级独立打点尚未启用。</div>
      <div class="ac-kpis" style="grid-template-columns:repeat(5,minmax(0,1fr))">
        <div class="ac-kpi"><b>${st.calls || 0}</b><span>调用次数</span></div>
        <div class="ac-kpi"><b>${st.success || 0}</b><span>成功</span></div>
        <div class="ac-kpi"><b>${st.failure || 0}</b><span>失败</span></div>
        <div class="ac-kpi"><b>${st.success_rate == null ? "—" : Math.round(st.success_rate * 100) + "%"}</b><span>成功率</span></div>
        <div class="ac-kpi"><b>${st.tokens || 0}</b><span>Token</span></div>
      </div><div class="muted" style="font-size:12px;margin-top:8px">最近调用：${esc(st.last_call || "暂无记录")} · 平均延迟 ${st.lat || st.avg_latency_ms || 0}ms</div></div>
    <div class="settings-foot"><button class="btn" data-ep-close>关闭</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelectorAll("[data-ep-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
}
function modelEdit(mid) {
  const m = (window.__models || []).find(x => x.id === mid);
  if (!m) return;
  $("#model-edit-title").textContent = "编辑模型 · " + (m.name || "");
  $("#me-name").value = m.name || ""; $("#me-provider").value = m.provider || "";
  $("#me-model").value = m.model_id || ""; $("#me-base").value = m.base_url || "";
  $("#me-key").value = ""; $("#me-caps").value = (m.capabilities || []).join(",");
  $("#me-enabled").checked = !!m.enabled; $("#me-default").checked = !!m.is_default;
  $("#me-msg").textContent = ""; $("#me-save").dataset.mid = mid; $("#model-edit").hidden = false;
}
function modelCreate() {
  ["#me-name","#me-provider","#me-model","#me-base","#me-key","#me-caps"].forEach(s => $(s).value = "");
  $("#me-caps").value = "chat"; $("#me-enabled").checked = true; $("#me-default").checked = false;
  $("#model-edit-title").textContent = "接入模型"; $("#me-msg").textContent = "";
  $("#me-save").dataset.mid = ""; $("#model-edit").hidden = false;
}
$("#btn-model-new")?.addEventListener("click", modelCreate);
$("#me-cancel")?.addEventListener("click", () => { $("#model-edit").hidden = true; });
$("#me-save")?.addEventListener("click", async () => {
  const body = { name: $("#me-name").value.trim(), provider: $("#me-provider").value.trim(),
    model_id: $("#me-model").value.trim(), base_url: $("#me-base").value.trim(),
    capabilities: $("#me-caps").value.trim() || "chat",
    enabled: $("#me-enabled").checked, is_default: $("#me-default").checked };
  if ($("#me-key").value) body.api_key = $("#me-key").value;
  if (!body.name || !body.model_id) { $("#me-msg").textContent = "配置名称和模型 ID 必填"; return; }
  const mid = $("#me-save").dataset.mid;
  const btn = $("#me-save"), old = btn.textContent; btn.disabled = true; btn.textContent = "保存中…";
  try {
    const r = await (await fetch(mid ? `/api/v1/models/${mid}/update` : "/api/v1/models", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r.error) { $("#me-msg").textContent = r.error; showToast("保存失败：" + r.error, "err"); return; }
    $("#model-edit").hidden = true; showToast(mid ? "模型配置已保存" : "模型已接入", "ok"); loadModels();
  } catch (e) { $("#me-msg").textContent = "保存失败"; showToast("保存失败", "err"); }
  finally { btn.disabled = false; btn.textContent = old; }
});
async function openModelPresets() {
  const list = await (await fetch("/api/v1/models/presets")).json();
  const box = [];
  for (const p of list) {
    box.push(`<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px dashed #F0F1F2">
      <div style="flex:1"><b>${esc(p.name)}</b><div class="muted" style="font-size:12px">${esc(p.desc)}</div></div>
      <button class="btn primary" data-preset="${esc(p.key)}">添加</button></div>`);
  }
  const mask = document.createElement("div");
  mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:520px"><h3 style="margin:0 0 6px">接入预置模型</h3>
    <div class="muted" style="margin-bottom:10px">密钥沿用服务端已配置的模型凭据，无需手工填写</div>${box.join("")}
    <div class="actions" style="margin-top:12px;justify-content:flex-end"><button class="btn" id="preset-close">关闭</button></div></div>`;
  document.body.appendChild(mask);
  mask.querySelector("#preset-close").addEventListener("click", () => mask.remove());
  mask.querySelectorAll("[data-preset]").forEach(b => b.addEventListener("click", async () => {
    const r = await (await fetch("/api/v1/models/preset", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: b.dataset.preset }) })).json();
    if (r.error) { alert(r.error); return; }
    mask.remove(); loadModels();
  }));
}
function openModelAdd() {
  const mask = document.createElement("div");
  mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:520px"><h3 style="margin:0 0 12px">接入模型</h3>
    <div class="form">
      <input id="nm-name" class="field" placeholder="显示名称，如 DeepSeek Chat">
      <input id="nm-provider" class="field" placeholder="供应商，如 DeepSeek">
      <input id="nm-model" class="field" placeholder="模型 ID，如 deepseek-chat">
      <input id="nm-base" class="field" placeholder="Base URL，如 https://api.deepseek.com">
      <input id="nm-key" class="field" placeholder="API Key（留空沿用服务端配置）">
      <input id="nm-caps" class="field" placeholder="能力：chat,vision,ocr,embed" value="chat">
      <div class="actions" style="justify-content:flex-end;margin-top:10px">
        <button class="btn" id="nm-cancel">取消</button><button class="btn primary" id="nm-ok">接入</button></div>
    </div></div>`;
  document.body.appendChild(mask);
  mask.querySelector("#nm-cancel").addEventListener("click", () => mask.remove());
  mask.querySelector("#nm-ok").addEventListener("click", async () => {
    const body = { name: $("#nm-name").value, provider: $("#nm-provider").value, model_id: $("#nm-model").value,
      base_url: $("#nm-base").value, api_key: $("#nm-key").value, capabilities: $("#nm-caps").value };
    const r = await (await fetch("/api/v1/models", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r.error) { alert(r.error); return; }
    mask.remove(); loadModels();
  });
}
$("#btn-model-preset")?.addEventListener("click", openModelPresets);
$("#btn-model-add")?.addEventListener("click", openModelAdd);

/* ===================== 智能体管理 ===================== */
let agentTab = "basic", currentAgent = null;

