/* 新建项目/文件选择/审核模式：从 app.js 拆出；依赖 app.js 的 $/esc/currentRole/runAuditAsync 等全局。 */
async function initProjectFilters() {
  const sp = $("#pl-space");
  if (sp && !sp.dataset.ready) {
    try {
      const d = await (await fetch("/api/v1/workspaces")).json();
      sp.innerHTML = '<option value="">全部空间（默认）</option>' + ((d.items || []).map(w => `<option value="${esc(w.id)}">${esc(w.name)}</option>`).join(""));
      sp.dataset.ready = "1";
    } catch (e) {}
  }
  ["#pl-refresh", "#pl-reset"].forEach(sel => { const b = $(sel); if (b && !b.dataset.bound) {
    b.dataset.bound = "1";
    b.onclick = () => { if (sel === "#pl-reset") { ["#pl-q","#pl-from","#pl-to"].forEach(x => { const el = $(x); if (el) el.value = ""; }); const ssp = $("#pl-space"); if (ssp) ssp.value = ""; uxFiltersReset("projects"); } loadProjects(1); };
  }});
  ["#pl-q", "#pl-status", "#pl-space", "#pl-from", "#pl-to"].forEach(sel => { const el = $(sel); if (el && !el.dataset.bound) { el.dataset.bound = "1"; el.addEventListener("change", () => loadProjects(1)); } });
}
async function fillReviewerOptions() {
  const sel = $("#pl-reviewer");
  if (!sel || reviewerFilled) return;
  reviewerFilled = true;
  try {
    const tsel = $("#nu-tenant");
  if (tsel) {
    if (myRole === "super_admin") {
      tsel.style.display = "";
      try {
        const td = await (await fetch("/api/v1/platform/tenants")).json();
        tsel.innerHTML = '<option value="">选择目标租户</option>' + ((td.items || []).map(t => `<option value="${esc(t.id)}">${esc(t.name)}（${esc(t.code)}）</option>`).join(""));
      } catch (e) {}
    } else { tsel.style.display = "none"; }
  }
  const list = await (await fetch("/api/v1/users")).json();
    const rv = (Array.isArray(list) ? list : []).filter(u => u.role === "reviewer");
    sel.innerHTML = `<option value="">全部审核员</option>` +
      rv.map(u => `<option value="${esc(u.id)}">${esc(u.name)}</option>`).join("");
  } catch (e) { reviewerFilled = false; }
}
$("#btn-pl-search")?.addEventListener("click", () => loadProjects(1));
$("#btn-pl-reset")?.addEventListener("click", () => {
  ["#pl-q", "#pl-status", "#pl-from", "#pl-to", "#pl-reviewer"].forEach(sel => { const el = $(sel); if (el) el.value = ""; });
  const sp = $("#pl-space"); if (sp) sp.value = "";
  uxFiltersReset("projects");
  loadProjects(1);
});
let npFiles = [];
// P2-B5-01：文件数/体积上限不再前端写死 —— 与服务端 project.MAX_FILES 同一事实源
// （GET /api/v1/system/capabilities → limits），取不到时才回退服务端当前默认值（10 份）。
const NP_LIMITS = { max_files: 10, max_file_mb: 100, max_total_mb: 300 };
let _npLimitsLoaded = false;
async function loadNpLimits() {
  if (_npLimitsLoaded) return NP_LIMITS;
  try {
    const r = await (await fetch("/api/v1/system/capabilities")).json();
    const lim = (r && r.limits) || {};
    if (lim.max_files) NP_LIMITS.max_files = Number(lim.max_files);
    if (lim.max_file_mb) NP_LIMITS.max_file_mb = Number(lim.max_file_mb);
    if (lim.max_total_mb) NP_LIMITS.max_total_mb = Number(lim.max_total_mb);
  } catch (e) { /* 取不到就用手册默认值，不阻断上传 */ }
  _npLimitsLoaded = true;
  return NP_LIMITS;
}
function renderNpFiles() {
  const box = $("#np-files");
  if (!box) return;
  box.innerHTML = npFiles.map((f, i) =>
    `<span class="dz-file">${esc(f.name)}<span class="rm" data-rm="${i}">×</span></span>`).join("");
  box.querySelectorAll("[data-rm]").forEach(x => x.addEventListener("click", (e) => {
    e.stopPropagation(); npFiles.splice(Number(x.dataset.rm), 1); renderNpFiles();
  }));
}
function addNpFiles(list) {
  const LIM = NP_LIMITS;
  for (const f of list) {
    if (npFiles.length >= LIM.max_files) { alert(`最多 ${LIM.max_files} 份文件`); break; }
      if (f.size > LIM.max_file_mb * 1024 * 1024) { alert(`「${f.name}」${(f.size / 1024 / 1024).toFixed(1)}MB，超过单份 ${LIM.max_file_mb}MB 上限`); continue; }
      if (npFiles.reduce((a, x) => a + x.size, 0) + f.size > LIM.max_total_mb * 1024 * 1024) { alert(`文件合计将超过 ${LIM.max_total_mb}MB 上限`); continue; }
    if (!npFiles.find(x => x.name === f.name)) npFiles.push(f);
  }
  renderNpFiles();
}
function bindDropZone() {
  const dz = $("#np-drop"), inp = $("#np-file");
  if (!dz || !inp) return;
  dz.addEventListener("click", (e) => { if (e.target.id !== "np-pick") inp.click(); });
  $("#np-pick")?.addEventListener("click", (e) => { e.preventDefault(); inp.click(); });
  dz.addEventListener("dragover", (e) => { e.preventDefault(); dz.classList.add("drag"); });
  dz.addEventListener("dragleave", () => dz.classList.remove("drag"));
  dz.addEventListener("drop", (e) => { e.preventDefault(); dz.classList.remove("drag"); addNpFiles(e.dataTransfer.files); });
  inp.addEventListener("change", () => { addNpFiles(inp.files); inp.value = ""; });
}
function initAuditModeBox() {
  const btn = $("#btn-create-project");
  if (!btn || $("#np-mode-box")) return;
  const box = document.createElement("div");
  box.id = "np-mode-box";
  box.className = "np-mode-section";
  box.innerHTML = `<details><summary>高级设置（可选）</summary>
    <div class="np-advanced-body">
      <div class="np-advanced-item">
        <div class="np-advanced-item-head"><div><b>AI 辅助补查</b><span>可选项 1</span></div><span class="pill draft">会增加调用成本</span></div>
        <label class="np-advanced-check"><input type="checkbox" id="np-ai-assist" checked> 开启 AI 辅助补查（默认开启）</label>
        <div id="np-ai-hint" class="np-advanced-hint" style="display:block">只补查客户规则未覆盖的点位；新增结果会标记为 AI 辅助，仍需人工确认。不勾选时只跑客户规则，可能漏掉未配置点位的风险。</div>
      </div>
      <div class="np-advanced-divider"></div>
      <div class="np-advanced-item">
        <div class="np-advanced-item-head"><div><b>补充制度 / 标准文本</b><span>可选项 2</span></div><span class="pill">生成候选规则</span></div>
        <div class="np-advanced-hint" style="display:block">粘贴客户制度或标准片段；系统会生成候选规则草稿，不会自动发布。</div>
        <textarea id="np-policy-text" rows="3" placeholder="例如：客户制度第 3.2 条，采购金额不得超过 100 万元，且必须附三家比价记录。"></textarea>
      </div>
    </div></details>`;
  const footer = btn.closest(".np-footer");
  if (footer) footer.parentNode.insertBefore(box, footer); else btn.parentNode.insertBefore(box, btn);
  $("#np-ai-assist")?.addEventListener("change", (e) => {
    $("#np-ai-hint").style.display = e.target.checked ? "block" : "none";
  });
}

async function createProject() {
  if (!npFiles.length) { alert("请先上传文件"); return; }
  // 文档类型不再让用户选择：当前工作空间已限定类型，项目直接继承。
  const _wsTypes = window.__wsDocTypes || [];
  const documentType = _wsTypes[0] || npDocTypes[0]?.name || "";
  if (!documentType) { alert("当前工作空间未配置文件类型，请先在空间配置中选择主文件类型"); return; }
  const btn = $("#btn-create-project");
  btn.disabled = true; btn.textContent = "审核中…";
  const auditType = (npDocTypes.find(x => x.name === documentType)?.base_type) || "general";
  const auditCategory = $("#np-cat")?.value || "";
  const focus = $("#np-focus")?.value.trim() || "";
  const _typedName = ($("#np-name")?.value || "").trim();
  bumpUsage("file", documentType); bumpUsage("cat", auditCategory);
  const name = _typedName || (npFiles[0].name.replace(/\.[^.]+$/, "") + " 审核");
  try {
    const r = await (await fetch("/api/v1/projects", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, audit_type: auditType, document_type: documentType, audit_category: auditCategory, focus }) })).json();
    if (r.error) { alert(r.error); return; }
    for (const f of npFiles) {
      const b64 = await new Promise((res) => {
        const fr = new FileReader();
        fr.onload = () => res(String(fr.result).split(",")[1] || "");
        fr.readAsDataURL(f);
      });
      const up = await (await fetch(`/api/v1/projects/${r.project_id}/documents`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: f.name, data: b64 }) })).json();
      if (up.error) { alert("上传失败：" + up.error); return; }
    }
    const _ai = !!$("#np-ai-assist")?.checked;
    const _dt = auditType;
    const _pt = $("#np-policy-text")?.value.trim() || "";
    npFiles = []; renderNpFiles();
    if ($("#np-name")) $("#np-name").value = "";
    if ($("#np-focus")) $("#np-focus").value = "";
    if ($("#np-policy-text")) $("#np-policy-text").value = "";
    // 项目已创建成功：当前表单不再有未保存内容，切换页面时不应再提示 dirty。
    if (typeof uxDirtyClear === "function") uxDirtyClear("newproject");
    // 解析预览确认：先让用户看解析结果，再决定是否开始审核
    let _docs = [];
    try { _docs = await (await fetch(`/api/v1/projects/${r.project_id}/documents`)).json(); } catch (e) {}
    const _bad = (_docs || []).filter(d => d.parse_status === "failed");
    const _lines = (_docs || []).map(d => `${d.filename}：${d.parse_status === "ok" ? "解析成功" : d.parse_status === "partial" ? "解析不完整" : "解析失败"}（${d.parse_summary || ""}）`).join("\n");
    const _go = confirm("解析结果预览：\n" + (_lines || "（无文件）") +
      (_bad.length ? "\n\n有文件解析失败，继续审核可能漏审。仍要继续？" : "\n\n确认开始审核？"));
    if (!_go) { btn.disabled = false; btn.textContent = "开始审核"; return; }
    await runAuditAsync(r.project_id, _ai, _dt, _pt, name);
  } finally {
    btn.disabled = false; btn.textContent = "开始审核";
  }
}
async function openProject(id) {
  if (currentRole === "reviewer" || currentRole === "admin") { await openWorkbench(id); return; }
  currentProjectId = id;
  showView("project");
  uxSetLoading("#proj-findings", "正在加载发现…", 4);
  uxSetLoading("#proj-files", "正在加载文件…", 2);
  let d;
  try { d = await (await fetch(`/api/v1/projects/${id}`)).json(); }
  catch (e) {
    uxSetEmpty("#proj-findings", { title: "项目加载失败", desc: "请返回项目列表后重试；不会修改任何审核结果。", action: { label: "返回项目列表", action: "view:projects" } });
    return;
  }
  if (!d || d.error) {
    uxSetEmpty("#proj-findings", { title: "项目加载失败", desc: String((d && d.error) || "接口返回为空"), action: { label: "返回项目列表", action: "view:projects" } });
    return;
  }
  // 跨空间打开：先把「当前工作空间」对齐到项目所属空间（失败/无字段则保持现状）。
  if (typeof wsSyncForProject === "function") { try { await wsSyncForProject(d.case || {}); } catch (e) {} }
  await renderProject(id, d);
}
/* DOM 就绪后绑定拖拽区（app.js 已加载 DOM）；同时拉取服务端上限（P2-B5-01） */
bindDropZone();
loadNpLimits();
