/* 规则挖掘视图：从 app.js 拆出；依赖 app.js 的全局 esc/currentRole/loadRules */
async function loadRuleMining() {
  const out = document.querySelector("#rule-mine-out");
  if (!out) return;
  out.hidden = false;
  out.innerHTML = '<div class="muted">正在扫描重复发现与反馈…</div>';
  if (currentRole === "reviewer") {
    out.innerHTML = '<div class="muted">规则挖掘仅业务管理员可操作；审核员可继续使用规则库。</div>';
    return;
  }
  let r = {};
  try { r = await (await fetch("/api/v1/rules/mine")).json(); } catch (e) { r = { error: "请求失败" }; }
  if (r.error) { out.innerHTML = `<div class="muted">${esc(r.error)}</div>`; return; }
  const items = r.items || [];
  out.innerHTML = `<div class="card" style="margin-top:10px"><div class="card-head"><h2 style="font-size:13px">规则挖掘候选（具体问题 → 候选规则）</h2><span class="muted" style="font-size:11px">只生成草稿，不自动发布</span></div>` +
    (items.length ? `<table class="table"><thead><tr><th>候选</th><th>重复次数</th><th>建议形式</th><th>判断依据</th><th>操作</th></tr></thead><tbody>` +
      items.map((x, i) => `<tr><td><b>${esc(x.title)}</b><div class="muted" style="font-size:11px">${esc(x.summary || "")}</div></td>
        <td>${x.count || 0} 次 / ${x.case_count || 0} 个项目</td>
        <td><span class="pill ${x.form === "decision_table" ? "draft" : "published"}">${x.form === "decision_table" ? "决策表组合" : "单条参数"}</span></td>
        <td class="muted">${esc(x.form_reason || "—")}</td>
        <td>${x.draft_rule_id ? `<span class="pill published">已生成草稿</span> <button class="btn" data-mine-open="${esc(x.draft_rule_id)}">查看</button>` : `<button class="btn" data-mine-draft="${i}" data-mine-form="${esc(x.form || "single")}">生成规则草稿</button>`}</td></tr>`).join("") + `</tbody></table>`
      : '<div class="muted" style="padding:14px">暂无重复发现可供挖掘；至少需要同一问题在 2 个项目/发现中出现。</div>') + '</div>';
  // 机制规则目录：把“具体原句”提升为机制+证据，导入仍只生成草稿
  try {
    const mc = await (await fetch("/api/v1/rules/mechanism/catalog")).json();
    if (mc && mc.ok) {
      const box = document.createElement("div");
      box.className = "card"; box.style.marginTop = "10px";
      box.innerHTML = `<div class="card-head"><h2 style="font-size:13px">机制级规则目录（1.6.0）</h2><span class="muted" style="font-size:11px">${mc.count} 个审核点 · 机制 + 证据 + 核查步骤</span></div>` +
        `<div class="muted" style="font-size:12px;margin-bottom:8px">不记录“某句话/某个案例”，而是抽象为“哪类机制被放宽/错配/遗漏”。导入后仍是草稿，需审批发布；发布后才进入审核。</div>` +
        `<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="mechanism-import">导入机制规则草稿</button><span class="muted" id="mechanism-msg" style="font-size:11px"></span></div>`;
      out.appendChild(box);
      box.querySelector("#mechanism-import").onclick = async () => {
        const b = box.querySelector("#mechanism-import"), msg = box.querySelector("#mechanism-msg");
        if (!confirm("将把机制目录导入当前空间，生成待审批草稿；不会自动发布。继续？")) return;
        b.disabled = true; msg.textContent = "导入中…";
        try {
          const r = await (await fetch("/api/v1/rules/mechanism/import", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({publish:false})})).json();
          if (r.error || r.ok === false) throw new Error(r.error || (r.failures && r.failures[0] && r.failures[0].error) || "导入失败");
          msg.textContent = `已生成草稿 ${r.created} 条；请到规则库审批发布`;
          loadRules();
        } catch (e) { msg.textContent = "导入失败：" + (e.message || "网络错误"); }
        finally { b.disabled = false; }
      };
    }
  } catch (e) { /* 目录不可用不影响原候选 */ }
  // 客户反馈 → 机制候选 / 反例卡；只读挖掘，不自动发布
  try {
    const fbx = document.createElement("div");
    fbx.className = "card"; fbx.style.marginTop = "10px";
    fbx.innerHTML = `<div class="card-head"><h2 style="font-size:13px">客户反馈自动挖掘</h2><span class="muted" style="font-size:11px">confirmed / false_positive / need_evidence</span></div>` +
      `<div class="muted" style="font-size:12px;margin-bottom:8px">从真实复核反馈提取机制候选，并把 false_positive 沉淀为反例卡；候选需人工确认，不自动发布。</div>` +
      `<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="mechanism-feedback">扫描客户反馈</button><button class="btn" id="mechanism-negatives">查看反例卡</button><button class="btn" id="mechanism-cal">查看反馈校准</button><span class="muted" id="mechanism-fb-msg" style="font-size:11px"></span></div><div id="mechanism-fb-out" class="muted" style="font-size:11px;margin-top:7px"></div>`;
    out.appendChild(fbx);
    fbx.querySelector("#mechanism-feedback").onclick = async () => {
      const b = fbx.querySelector("#mechanism-feedback"), msg = fbx.querySelector("#mechanism-fb-msg"), box = fbx.querySelector("#mechanism-fb-out");
      b.disabled = true; msg.textContent = "扫描中…";
      try {
        const d = await (await fetch("/api/v1/rules/mechanism/feedback?limit=200")).json();
        if (d.error || d.ok === false) throw new Error(d.error || "扫描失败");
        const items = d.items || [];
        msg.textContent = `反馈 ${d.records || 0} 条，机制候选 ${items.length} 个`;
        box.innerHTML = items.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>机制/审核点</th><th>正向</th><th>负向</th><th>最近</th></tr></thead><tbody>` + items.map(x => `<tr><td><b>${esc(x.point_name || x.point_id)}</b><div class="muted">${esc((x.mechanisms || []).join("；"))}</div></td><td>${x.positive || 0}</td><td>${x.negative || 0}</td><td>${esc(x.last_at || "—")}</td></tr>`).join("") + `</tbody></table></div>` : "暂无客户反馈；先完成复核/误报记录。";
      } catch (e) { msg.textContent = "扫描失败：" + (e.message || "网络错误"); }
      finally { b.disabled = false; }
    };
    fbx.querySelector("#mechanism-cal").onclick = async () => {
      const msg = fbx.querySelector("#mechanism-fb-msg"), box = fbx.querySelector("#mechanism-fb-out");
      try {
        const d = await (await fetch("/api/v1/rules/mechanism/calibration")).json();
        if (d.error || d.ok === false) throw new Error(d.error || "读取失败");
        msg.textContent = `规则 ${d.total_rules || 0} 个，阻断 ${d.blocked || 0} 个`;
        box.innerHTML = (d.items || []).length ? `<div class="table-wrap"><table class="table"><thead><tr><th>规则</th><th>确认</th><th>误报</th><th>平滑准确率</th><th>动作</th></tr></thead><tbody>` + d.items.map(x => `<tr><td><b>${esc(x.rule_code)}</b><div class="muted">${esc(x.reason || "")}</div></td><td>${x.confirm || 0}</td><td>${x.neg || 0}</td><td>${x.smoothed_accuracy == null ? "—" : Math.round(x.smoothed_accuracy * 100) + "%"}</td><td>${x.blocked ? '<span class="pill draft">转人工</span>' : '<span class="pill published">保留</span>'}</td></tr>`).join("") + `</tbody></table></div>` : "暂无反馈样本；先积累复核/误报记录。";
      } catch (e) { msg.textContent = "读取失败：" + (e.message || "网络错误"); }
    };
    fbx.querySelector("#mechanism-negatives").onclick = async () => {
      const msg = fbx.querySelector("#mechanism-fb-msg"), box = fbx.querySelector("#mechanism-fb-out");
      try {
        const d = await (await fetch("/api/v1/rules/mechanism/negative-cards")).json();
        if (d.error || d.ok === false) throw new Error(d.error || "读取失败");
        msg.textContent = `反例卡 ${d.count || 0} 张`;
        box.innerHTML = (d.items || []).length ? `<div class="table-wrap"><table class="table"><thead><tr><th>规则/机制</th><th>类型</th><th>次数</th><th>最近</th></tr></thead><tbody>` + d.items.map(x => `<tr><td><b>${esc(x.rule_code || "")}</b><div class="muted">${esc(x.reason || "")}</div></td><td>${esc(x.kind || "")}</td><td>${x.count || 0}</td><td>${esc(x.last_at || "—")}</td></tr>`).join("") + `</tbody></table></div>` : "暂无 false_positive/manual 反例卡。";
      } catch (e) { msg.textContent = "读取失败：" + (e.message || "网络错误"); }
    };
  } catch (e) { /* 反馈接口不可用不影响主候选 */ }
  out.querySelectorAll("[data-mine-draft]").forEach(b => {
    const x = items[Number(b.dataset.mineDraft)] || {};
    b.onclick = async () => {
      b.disabled = true;
      const res = await (await fetch("/api/v1/rules/mine/draft", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: x.title, summary: x.summary, form: x.form, rule_code: x.rule_id || "" }) })).json();
      b.disabled = false;
      if (res.error) { alert(res.error); return; }
      alert(res.existing ? "该候选已有草稿，未重复创建" : "已生成规则草稿：" + (res.rule_id || ""));
      loadRules(); loadRecentRules(); loadRuleMining();
    };
  });
  out.querySelectorAll("[data-mine-open]").forEach(b => b.onclick = () => {
    const st = document.querySelector("#rule-status"); if (st) st.value = "draft";
    loadRules(); document.querySelector("#view-rules")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}
function bindRuleMining() {
  const btn = document.querySelector("#btn-rule-mine");
  if (!btn || btn.__bound) return;
  btn.__bound = true;
  if (currentRole === "reviewer") { btn.hidden = true; return; }
  btn.addEventListener("click", loadRuleMining);
}

