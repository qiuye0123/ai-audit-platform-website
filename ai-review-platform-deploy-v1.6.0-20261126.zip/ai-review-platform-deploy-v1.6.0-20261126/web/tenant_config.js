/* 租户配置：本租户业务管理员修改平台名称与 Logo；reviewer/系统管理员只读。 */
(function () {
  "use strict";
  var $ = function (s) { return document.querySelector(s); };
  var DEFAULT_NAME = "AI 审核平台";
  var readonly = false;
  var saving = false;

  function setMsg(text, type) {
    var el = $("#tc-msg");
    if (!el) return;
    el.textContent = text || "";
    el.className = "tc-msg" + (type ? " " + type : "");
  }

  function setImage(img, placeholder, url, alt) {
    if (!img || !placeholder) return;
    if (url) {
      img.onerror = function () {
        img.hidden = true;
        placeholder.hidden = false;
      };
      img.onload = function () {
        img.hidden = false;
        placeholder.hidden = true;
      };
      img.alt = alt || "Logo 预览";
      img.src = url;
    } else {
      img.removeAttribute("src");
      img.hidden = true;
      placeholder.hidden = false;
    }
  }

  function validLogo(url) {
    if (!url) return "";
    if (/^data:/i.test(url)) {
      if (!/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i.test(url)) {
        return "Logo 仅支持 PNG/JPEG/WebP/GIF 的图片 data URL";
      }
      var payload = url.replace(/^[^,]*,/, "").replace(/\s+/g, "");
      if (!payload) return "Logo 图片内容为空";
      try {
        var size = Math.floor(payload.length * 3 / 4) - (payload.match(/=*$/) || [""])[0].length;
        if (size > 512 * 1024) return "Logo 图片不能超过 512KB";
      } catch (e) { /* 交给后端做最终校验 */ }
      return "";
    }
    if (/^https?:\/\//i.test(url)) {
      if (url.length > 2048) return "Logo 地址过长（最多 2048 字符）";
      return "";
    }
    return "Logo 必须是 http(s) 地址或图片 data URL";
  }

  var dirty = false;
  var dirtyBaseline = "";
  var dirtyReady = false;
  function formSignature() {
    return String($("#tc-platform-name") ? $("#tc-platform-name").value : "")
      + "\u0001" + String($("#tc-logo-url") ? $("#tc-logo-url").value : "");
  }
  function snapDirty() { dirtyBaseline = formSignature(); dirty = false; dirtyReady = true; }
  function markDirty() { if (!dirtyReady) return; dirty = formSignature() !== dirtyBaseline; }
  window.addEventListener("beforeunload", function (e) {
    if (!dirty) return;
    e.preventDefault();
    e.returnValue = "";
  });

  function applyConfig(b) {
    b = b || {};
    var name = String(b.platform_name || "").trim();
    var logo = String(b.logo_url || "").trim();
    $("#tc-tenant-name").textContent = b.tenant_name ? (b.tenant_name + "（" + (b.tenant_code || b.tenant_id || "") + "）") : "当前租户";
    $("#tc-tenant-code").textContent = b.tenant_code || b.tenant_id || "—";
    $("#tc-platform-name").value = name === DEFAULT_NAME ? "" : name;
    $("#tc-logo-url").value = logo;
    $("#tc-current-name").textContent = name || DEFAULT_NAME;
    $("#tc-config-state").textContent = b.configured ? "已配置" : "未配置（默认品牌）";
    setImage($("#tc-logo-preview"), $("#tc-logo-placeholder"), logo, name || DEFAULT_NAME);
    setImage($("#tc-current-logo"), $("#tc-current-placeholder"), logo, name || DEFAULT_NAME);
  }

  function setReadonly(on, note) {
    readonly = !!on;
    ["#tc-platform-name", "#tc-logo-url", "#tc-logo-file"].forEach(function (s) {
      var el = $(s); if (el) el.disabled = readonly;
    });
    ["#tc-save", "#tc-clear-logo", "#tc-reset-name"].forEach(function (s) {
      var el = $(s); if (el) el.disabled = readonly;
    });
    var box = $("#tc-readonly");
    if (box) {
      box.hidden = !readonly;
      if (note) box.textContent = note;
    }
  }

  async function loadBrandingOnly() {
    try {
      var r = await fetch("/api/v1/tenant/branding", {credentials: "same-origin"});
      if (!r.ok) return false;
      var d = await r.json();
      if (d && d.branding) {
        applyConfig(d.branding);
        return true;
      }
    } catch (e) { /* ignore */ }
    return false;
  }

  async function load() {
    setMsg("加载中…");
    var r;
    try {
      r = await fetch("/api/v1/tenant/config", {credentials: "same-origin"});
    } catch (e) {
      setMsg("网络错误，请重试", "err");
      return;
    }
    if (r.status === 401) {
      window.location.href = "/admin/business/login";
      return;
    }
    var d = {};
    try { d = await r.json(); } catch (e) { d = {}; }
    if (!r.ok) {
      await loadBrandingOnly();
      setReadonly(true, (d && d.error) ? (d.error + "；当前页面只读。") : "当前页面只读：仅本租户业务管理员可修改。");
      setMsg(d && d.error ? d.error : "没有租户配置写权限", "err");
      snapDirty();
      return;
    }
    applyConfig(d.branding || {});
    setReadonly(false);
    setMsg("");
    snapDirty();
  }

  async function save() {
    if (readonly || saving) return;
    var name = String($("#tc-platform-name").value || "").trim();
    var logo = String($("#tc-logo-url").value || "").trim();
    if (name.length > 40) { setMsg("平台名称最多 40 个字", "err"); return; }
    var logoErr = validLogo(logo);
    if (logoErr) { setMsg(logoErr, "err"); return; }
    saving = true;
    var btn = $("#tc-save");
    var old = btn.textContent;
    btn.disabled = true;
    btn.textContent = "保存中…";
    setMsg("");
    try {
      var r = await fetch("/api/v1/tenant/config", {
        method: "POST",
        credentials: "same-origin",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({platform_name: name, logo_url: logo})
      });
      var d = await r.json().catch(function () { return {}; });
      if (!r.ok || !d.ok) {
        setMsg((d && (d.error || d.reason)) || "保存失败", "err");
        return;
      }
      applyConfig(d.branding || {});
      snapDirty();
      setMsg("已保存：本租户登录页、侧栏品牌、页面标题与报告标题将使用新配置", "ok");
      if (window.RPBranding && window.RPBranding.refresh) {
        window.RPBranding.refresh();
      }
    } catch (e) {
      setMsg("保存失败：网络错误", "err");
    } finally {
      saving = false;
      btn.disabled = readonly;
      btn.textContent = old;
    }
  }

  function bind() {
    $("#tc-save").addEventListener("click", save);
    $("#tc-clear-logo").addEventListener("click", function () {
      if (readonly) return;
      $("#tc-logo-url").value = "";
      $("#tc-logo-file").value = "";
      setImage($("#tc-logo-preview"), $("#tc-logo-placeholder"), "", DEFAULT_NAME);
      setMsg("");
      markDirty();
    });
    $("#tc-reset-name").addEventListener("click", function () {
      if (readonly) return;
      $("#tc-platform-name").value = "";
      setMsg("");
      markDirty();
    });
    $("#tc-platform-name").addEventListener("input", markDirty);
    $("#tc-logo-url").addEventListener("input", function () {
      markDirty();
      var url = String(this.value || "").trim();
      if (!url) {
        setImage($("#tc-logo-preview"), $("#tc-logo-placeholder"), "", DEFAULT_NAME);
        return;
      }
      if (!validLogo(url)) {
        setImage($("#tc-logo-preview"), $("#tc-logo-placeholder"), url, $("#tc-platform-name").value || DEFAULT_NAME);
      }
    });
    $("#tc-logo-file").addEventListener("change", function () {
      var file = this.files && this.files[0];
      if (!file) return;
      if (!/^image\/(png|jpeg|webp|gif)$/i.test(file.type)) {
        setMsg("仅支持 PNG / JPEG / WebP / GIF 图片", "err");
        this.value = "";
        return;
      }
      if (file.size > 512 * 1024) {
        setMsg("Logo 图片不能超过 512KB", "err");
        this.value = "";
        return;
      }
      var reader = new FileReader();
      reader.onload = function () {
        $("#tc-logo-url").value = String(reader.result || "");
        setImage($("#tc-logo-preview"), $("#tc-logo-placeholder"), String(reader.result || ""), file.name);
        setMsg("已读取本地图片，点击“保存配置”后生效");
        markDirty();
      };
      reader.onerror = function () { setMsg("读取图片失败，请重试", "err"); };
      reader.readAsDataURL(file);
    });
  }

  function initMobileNav() {
    var btn = document.getElementById("mobile-menu");
    var sidebar = document.querySelector(".sidebar");
    if (!btn || !sidebar) return;
    var mq = window.matchMedia("(max-width: 768px)");
    var scrim = document.createElement("div");
    scrim.id = "ux-sidebar-scrim";
    scrim.className = "sidebar-scrim";
    scrim.hidden = true;
    document.body.appendChild(scrim);
    var open = false;
    function sync() {
      if (!mq.matches) {
        open = false;
        sidebar.classList.remove("mobile-open");
        document.body.classList.remove("ux-nav-open");
        scrim.hidden = true;
        btn.setAttribute("aria-expanded", "false");
        btn.setAttribute("aria-label", "打开菜单");
        sidebar.removeAttribute("aria-hidden");
        return;
      }
      btn.setAttribute("aria-expanded", open ? "true" : "false");
      btn.setAttribute("aria-label", open ? "关闭菜单" : "打开菜单");
      sidebar.classList.toggle("mobile-open", open);
      sidebar.setAttribute("aria-hidden", open ? "false" : "true");
      document.body.classList.toggle("ux-nav-open", open);
      scrim.hidden = !open;
      scrim.classList.toggle("show", open);
    }
    function setOpen(next, focusBtn) {
      if (!mq.matches) return;
      open = !!next;
      sync();
      if (!open && focusBtn) { try { btn.focus({ preventScroll: true }); } catch (e) {} }
    }
    btn.addEventListener("click", function () { setOpen(!open, false); });
    scrim.addEventListener("click", function () { setOpen(false, true); });
    sidebar.addEventListener("click", function (e) {
      if (mq.matches && e.target.closest && e.target.closest(".menu-item")) setOpen(false, false);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape" || !open) return;
      e.preventDefault(); setOpen(false, true);
    }, true);
    mq.addEventListener ? mq.addEventListener("change", sync) : mq.addListener(sync);
    window.addEventListener("resize", sync);
    sync();
  }

  bind();
  initMobileNav();
  load();
  fetch("/api/v1/me", {credentials: "same-origin"}).then(function (r) {
    return r.ok ? r.json() : null;
  }).then(function (d) {
    if (d && d.user && $("#user-name")) $("#user-name").textContent = d.user.name || d.user.username || "业务管理员";
  }).catch(function () {});
})();
