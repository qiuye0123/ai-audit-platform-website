/* 消息中心模块：从 app.js 拆出，依赖 app.js 的全局工具函数。 */
async function loadBell() {
  try {
    const r = await fetch("/api/v1/notifications");
    if (!r.ok) return;
    const rows = await r.json();
    const c = (Array.isArray(rows) ? rows : []).filter(n => !n.read && !MSG_HIDDEN_TYPES.has(n.type)
      && (currentRole !== "super_admin" || MSG_SYSTEM_TYPES.has(n.type))).length;
    const item = document.querySelector("#top-messages");
    if (item) item.classList.toggle("has-unread", c > 0);
    const badge = document.querySelector("#top-msg-badge");
    if (badge) { badge.textContent = c > 99 ? "99+" : String(c); badge.hidden = c <= 0; }
  } catch (e) {}
}
async function loadConflictBadge() {
  try {
    const r = await fetch("/api/v1/conflicts?status=open");
    if (!r.ok) return;
    const d = await r.json();
    const n = (d.items || []).length;
    document.querySelectorAll('.menu-item[data-view="conflict"]').forEach(el => el.classList.toggle("has-unread", n > 0));
  } catch (e) {}
}
let msgTab = "all";
let msgUnreadOnly = false;
let msgPage = 1;
const MSG_PAGE_SIZE = 20;
// 这些事件已有独立的业务入口/红点，不再在消息中心重复提醒
const MSG_HIDDEN_TYPES = new Set(["rule.conflict"]);
const MSG_SYSTEM_TYPES = new Set(["system.llm_fail", "system.incident", "open.webhook_failed",
  "agent.fp_auto", "type_created", "rule.feedback"]);
const MSG_TAB_TYPES = {
  projects: new Set(["project.pending_review", "project.timeout"]),
  rules: new Set(["rule_pending", "rule.updated", "rule_created"]),
  feedback: new Set(["rule.feedback"]),
  system: new Set(["system.llm_fail", "system.incident", "open.webhook_failed", "agent.fp_auto", "type_created"]),
};
async function loadMessages() {
  const lr = await fetch("/api/v1/notifications");
  if (!lr.ok) { $("#messages-out").innerHTML = '<div class="empty">消息读取失败</div>'; return; }
  const list = await lr.json();
  const all = Array.isArray(list) ? list : [];
  const unread = all.filter(n => !n.read).length;
  const uc = $("#msg-unread-count"); if (uc) uc.textContent = unread ? `${unread} 条未读` : "全部已读";
  document.querySelectorAll("[data-msg-tab]").forEach(b => b.classList.toggle("on", b.dataset.msgTab === msgTab));
  const unreadBtn = $("#msg-unread");
  if (unreadBtn) { unreadBtn.classList.toggle("primary", msgUnreadOnly); unreadBtn.textContent = msgUnreadOnly ? "显示全部" : "只看未读"; }
  // 系统管理员只保留系统通知，不展示规则更新/规则反馈业务消息
  const _isSuperMsg = currentRole === "super_admin";
  document.querySelectorAll('[data-msg-tab="projects"],[data-msg-tab="rules"],[data-msg-tab="feedback"]').forEach(el => { el.style.display = _isSuperMsg ? "none" : ""; });
  if (_isSuperMsg && ["projects", "rules", "feedback"].includes(msgTab)) msgTab = "all";
  let filtered = all;
  if (msgTab !== "all") {
    const set = MSG_TAB_TYPES[msgTab] || new Set();
    filtered = all.filter(n => set.has(n.type) || (msgTab === "system" && !Object.values(MSG_TAB_TYPES).some(x => x.has(n.type))));
  }
  if (msgUnreadOnly) filtered = filtered.filter(n => !n.read);
  const pages = Math.max(1, Math.ceil(filtered.length / MSG_PAGE_SIZE));
  msgPage = Math.min(Math.max(1, msgPage), pages);
  const startPage = (msgPage - 1) * MSG_PAGE_SIZE;
  const shown = filtered.slice(startPage, startPage + MSG_PAGE_SIZE);
  const _time = (t) => {
    const x = String(t || "");
    return x.length >= 16 ? x.slice(0, 16) : x || "—";
  };
  $("#messages-out").innerHTML = shown.length ? shown.map(n => `<div class="msg-item ${n.read ? "read" : "unread"}" data-nid="${esc(n.id)}" data-read="${n.read ? "1" : "0"}">
    <div class="msg-item-top"><span class="msg-type">${esc(notifyLabel(n.type))}</span><b class="msg-item-title">${esc(n.title || "通知")}</b>${n.read ? "" : '<span class="msg-unread-dot">未读</span>'}<time class="msg-time">${esc(_time(n.created_at))}</time></div>
    <div class="msg-detail">${esc(n.detail || "")}</div>
    <div class="msg-item-foot">${n.read ? '<span class="muted">已读</span>' : '<button class="btn" data-msg-read>标为已读</button>'}<span class="muted">点击消息可标记已读</span></div>
  </div>`).join("") : `<div class="empty">${msgUnreadOnly ? "当前类型没有未读消息" : "当前类型暂无消息"}</div>`;
  const pager = document.querySelector("#msg-pager");
  if (pager) {
    pager.innerHTML = filtered.length ? `<div class="msg-page-info">第 ${startPage + 1}–${Math.min(startPage + MSG_PAGE_SIZE, filtered.length)} 条，共 ${filtered.length} 条${filtered.length > MSG_PAGE_SIZE ? "（每页最多 20 条）" : ""}</div>
      <div class="msg-page-actions"><button class="btn" data-msg-page="${msgPage - 1}" ${msgPage <= 1 ? "disabled" : ""}>上一页</button><span>${msgPage} / ${pages}</span><button class="btn" data-msg-page="${msgPage + 1}" ${msgPage >= pages ? "disabled" : ""}>下一页</button></div>` : "";
    pager.querySelectorAll("[data-msg-page]").forEach(b => b.onclick = () => { const p = Number(b.dataset.msgPage); if (p >= 1 && p <= pages) { msgPage = p; loadMessages(); } });
  }
  const markRead = async (id) => {
    const res = await fetch(`/api/v1/notifications/${encodeURIComponent(id)}/read`, { method: "POST" });
    if (!res.ok) { showToast("标记已读失败", "err"); return false; }
    showToast("已标记为已读"); loadBell(); return true;
  };
  document.querySelectorAll("#messages-out .msg-item").forEach(el => el.addEventListener("click", async (e) => {
    if (e.target.closest("[data-msg-read]")) return;
    if (el.dataset.read === "1") return;
    await markRead(el.dataset.nid);
  }));
  document.querySelectorAll("#messages-out [data-msg-read]").forEach(b => b.addEventListener("click", (e) => { e.stopPropagation(); markRead(b.closest(".msg-item").dataset.nid); }));
  /* L84 E3：规则告警（GET /api/v1/alerts）并入消息中心，与个人消息分开数据源。 */
  try { loadRuleAlerts(); } catch (e) { console.warn("规则告警卡片加载失败", e); }
}
document.querySelectorAll("[data-msg-tab]").forEach(b => b.addEventListener("click", () => {
  msgTab = b.dataset.msgTab; msgPage = 1; loadMessages();
}));


$("#msg-mark-all")?.addEventListener("click", async () => {
  if (!(await confirmAction("全部标为已读", "确定把当前账号的所有未读消息标为已读？", "全部已读"))) return;
  const r = await (await fetch("/api/v1/notifications/read-all", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
  if (r.error) {
    if (typeof showBatchSummary === "function") showBatchSummary({ title: "全部标为已读", success: 0, failed: 1, skipped: 0, failures: [{ name: "全部未读消息", reason: r.error }] });
    else showToast(r.error, "err");
    return;
  }
  if (typeof showBatchSummary === "function") showBatchSummary({ title: "全部标为已读", success: r.updated || 0, failed: 0, skipped: 0 });
  else showToast(`已处理 ${r.updated || 0} 条未读消息`);
  loadBell(); loadMessages();
});
$("#btn-msgs").addEventListener("click", () => loadMessages());
$("#msg-unread")?.addEventListener("click", () => { msgUnreadOnly = !msgUnreadOnly; msgPage = 1; loadMessages(); });

document.querySelector("#top-messages")?.addEventListener("click", () => {
  showView("messages");
  const _t = document.querySelector("#page-title"); if (_t) _t.textContent = "消息中心";
  loadMessages();
});

loadBell();
loadConflictBadge();

/* ===================== L84 E3：规则告警卡片（消息中心内） =====================
   服务端同源接口：GET /api/v1/alerts（notify.alerts：override 率超阈值的规则）。
   与 /api/v1/notifications（个人站内消息）不是同一数据源：这里是“规则级真实告警”，
   因此并入消息中心展示，不重复造消息、不把 0 条渲染成“全部正常”。
   口径：必须已有复核样本（decided>0）且 override_rate ≥ 告警阈值才出现；失败如实显示 HTTP。 */
async function loadRuleAlerts() {
  var card = document.getElementById("msg-alerts-card");
  if (!card) {
    var tabs = document.getElementById("msg-tabs");
    if (!tabs || !tabs.parentNode) return;
    card = document.createElement("div");
    card.id = "msg-alerts-card";
    card.style.cssText = "border:1px solid #EBEDF0;border-radius:8px;background:#FAFBFC;padding:10px 12px;margin:0 0 12px";
    tabs.parentNode.insertBefore(card, tabs);
  }
  card.innerHTML = '<div class="muted" style="font-size:12px">读取规则告警中…</div>';
  var resp = null, data = null;
  try {
    resp = await fetch("/api/v1/alerts", { credentials: "same-origin" });
    data = await resp.json();
  } catch (e) {
    card.innerHTML = '<div class="muted" style="font-size:12px;color:#D83931">规则告警读取失败：网络错误（' +
      esc((e && e.message) || e) + '）。失败不会被当作“没有告警”。</div>';
    return;
  }
  if (!resp.ok) {
    card.innerHTML = '<div class="muted" style="font-size:12px;color:#D83931">规则告警读取失败（HTTP ' +
      esc(resp.status) + '）：' + esc((data && (data.error || data.message)) || "未知错误") +
      '。失败不会被当作“没有告警”。</div>';
    return;
  }
  var list = Array.isArray(data) ? data : ((data && data.items) || null);
  if (!list) {
    card.innerHTML = '<div class="muted" style="font-size:12px;color:#D83931">规则告警接口返回格式非预期（期望数组），未渲染任何数据。</div>';
    return;
  }
  var head = '<div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;margin-bottom:6px">' +
    '<b style="font-size:12.5px">规则告警</b>' +
    '<span class="muted" style="font-size:11px">GET /api/v1/alerts · 仅统计已有复核样本且误报率超阈值的规则</span>' +
    '<span class="pill" style="font-size:11px">' + esc(String(list.length)) + ' 条</span></div>';
  if (!list.length) {
    card.innerHTML = head +
      '<div class="muted" style="font-size:11.5px;line-height:1.7">当前没有规则告警（真实空态）。' +
      '告警需要该规则已有复核样本（decided&gt;0）且误报率超过阈值；<b>0 条不代表所有规则正常</b>，' +
      '也不替代复核与规则分析。</div>';
    return;
  }
  card.innerHTML = head +
    '<div style="overflow:auto;max-height:240px"><table class="table" style="font-size:12px"><thead><tr>' +
    '<th>规则编码</th><th>名称</th><th class="num">误报率</th><th class="num">已复核</th><th class="num">误报</th><th>建议</th>' +
    '</tr></thead><tbody>' +
    list.map(function (a) {
      var rate = a.override_rate == null ? "—" : (Number(a.override_rate) * 100).toFixed(2) + "%";
      return '<tr><td class="muted">' + esc(a.rule_code || "—") + '</td>' +
        '<td>' + esc(a.name || "—") + '</td>' +
        '<td class="num" style="color:#D83931">' + esc(rate) + '</td>' +
        '<td class="num">' + esc(a.decided == null ? "—" : a.decided) + '</td>' +
        '<td class="num">' + esc(a.false_positive == null ? "—" : a.false_positive) + '</td>' +
        '<td class="muted">' + esc(a.suggestion || "—") + '</td></tr>';
    }).join("") + '</tbody></table></div>';
}
