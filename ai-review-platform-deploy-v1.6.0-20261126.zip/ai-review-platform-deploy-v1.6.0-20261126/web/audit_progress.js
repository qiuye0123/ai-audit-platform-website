/* 异步审核进度：从 app.js 拆出；依赖 app.js 的 openProject/runAudit/task API 等全局。 */
async function runAuditAsync(pid, aiAssist, docType, policyText, projectName) {
  const r = await (await fetch(`/api/v1/projects/${pid}/audit-async`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ai_assist: !!aiAssist, doc_type: docType || "", policy_text: policyText || "" }) })).json();
  if (r.error) { showToast("审核启动失败：" + r.error, "err"); return; }
  showAuditProgress(pid, projectName || "当前项目", r.task_id);
}
function showAuditProgress(pid, projectName, taskId) {
  const old = document.querySelector("#audit-progress-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "audit-progress-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal audit-progress-modal">
    <div class="audit-progress-head"><div class="audit-spinner"></div><div><h3>正在审核</h3><div class="muted" style="font-size:12px">${esc(projectName)}</div></div><button class="ws-close" data-ap-close>×</button></div>
    <div class="audit-steps"><div class="audit-step done">文件已上传</div><div class="audit-step done">文件解析完成</div><div class="audit-step active"><span class="audit-mini-spin"></span>AI 规则审核中</div></div>
    <div class="audit-bar"><span></span></div>
    <div class="audit-progress-meta"><span id="ap-elapsed">已用时 0 秒</span><span>预计 1–3 分钟，视文件大小与规则数量而定</span></div>
    <div class="audit-progress-note">审核在后台继续执行。你可以关闭本窗口，稍后到「项目列表」查看进度和结果。</div>
    <div class="audit-progress-actions"><button class="btn" data-ap-close>留在此页</button><button class="btn" id="ap-cancel">取消审核</button><button class="btn primary" id="ap-goto-list">去项目列表</button></div>
    <div id="ap-result"></div></div>`;
  document.body.appendChild(mask);
  let elapsed = 0, timer = null, poll = null, finished = false;
  const close = () => { if (timer) clearInterval(timer); if (poll) clearInterval(poll); mask.remove(); };
  mask.querySelectorAll("[data-ap-close]").forEach(b => b.onclick = close);
  mask.onclick = e => { if (e.target === mask) close(); };
  mask.querySelector("#ap-goto-list").onclick = () => { close(); showView("projects"); loadProjects(); };
  mask.querySelector("#ap-cancel")?.addEventListener("click", async () => {
    const b = mask.querySelector("#ap-cancel"); if (b) { b.disabled = true; b.textContent = "取消中…"; }
    try {
      const r = await (await fetch(`/api/v1/tasks/${taskId}/cancel`, { method: "POST" })).json();
      if (r.error) { alert(r.error); if (b) { b.disabled = false; b.textContent = "取消审核"; } }
    } catch (e) { if (b) { b.disabled = false; b.textContent = "取消审核"; } }
  });
  const tick = setInterval(() => { elapsed += 1; const el = mask.querySelector("#ap-elapsed"); if (el) el.textContent = `已用时 ${elapsed} 秒`; }, 1000);
  timer = tick;
  const check = async () => {
    if (finished || !mask.isConnected) { clearInterval(timer); if (poll) clearInterval(poll); return; }
    let t;
    try { t = await (await fetch(`/api/v1/tasks/${taskId}`)).json(); }
    catch (e) { return; }
    if (t.status === "done") {
      finished = true; clearInterval(timer); clearInterval(poll);
      const res = t.result || {};
      mask.querySelector(".audit-spinner")?.remove();
      const head = mask.querySelector(".audit-progress-head h3"); if (head) head.textContent = "审核完成";
      mask.querySelectorAll(".audit-step").forEach(x => { x.classList.remove("active"); x.classList.add("done"); });
      const bar = mask.querySelector(".audit-bar span"); if (bar) bar.style.width = "100%";
      const cnt = res.summary || res || {};
      mask.querySelector("#ap-result").innerHTML = `<div class="audit-result-ok">审核已完成，发现 ${cnt.total ?? cnt.finding_count ?? "—"} 条问题，待复核 ${cnt.pending ?? cnt.pending_count ?? "—"} 条。</div>`;
      const acts = mask.querySelector(".audit-progress-actions");
      acts.innerHTML = `<button class="btn" id="ap-goto-list">去项目列表</button><button class="btn primary" id="ap-view">查看审核结果</button>`;
      acts.querySelector("#ap-goto-list").onclick = () => { close(); showView("projects"); loadProjects(); };
      acts.querySelector("#ap-view").onclick = async () => { close(); await openWorkbench(pid); };
    } else if (t.status === "failed" || t.status === "timeout" || t.status === "cancelled") {
      finished = true; clearInterval(timer); clearInterval(poll);
      const head = mask.querySelector(".audit-progress-head h3"); if (head) head.textContent = t.status === "failed" ? "审核失败" : (t.status === "timeout" ? "审核超时" : "审核已取消");
      mask.querySelector(".audit-spinner")?.remove();
      mask.querySelector("#ap-result").innerHTML = `<div class="audit-result-fail">${esc(t.error || (t.status === "timeout" ? "审核超过时限，已终止调度" : (t.status === "cancelled" ? "审核已取消" : "审核执行失败")))}</div>`;
      const acts = mask.querySelector(".audit-progress-actions");
      acts.innerHTML = `<button class="btn" id="ap-goto-list">去项目列表</button><button class="btn" data-ap-close>关闭</button>`;
      acts.querySelector("#ap-goto-list").onclick = () => { close(); showView("projects"); loadProjects(); };
      acts.querySelector("[data-ap-close]").onclick = close;
    }
  };
  check();
  poll = setInterval(check, 1100);
  // 保留轮询句柄，关闭时清理
  const oldClose = close;
  mask.querySelectorAll("[data-ap-close]").forEach(b => b.onclick = () => { clearInterval(poll); oldClose(); });
  const listBtn = mask.querySelector("#ap-goto-list");
  if (listBtn) listBtn.onclick = () => { clearInterval(poll); oldClose(); showView("projects"); loadProjects(); };
}

