/* 规则详情视图：默认只读详情 + 独立「编辑/管理」面板；依赖 app.js 的 rules/esc/RULE_TEMPLATES 等全局。
   T-98（2026-11-18）交互口径：
   1. 列表行 / 「详情」按钮 → 只读详情：正文不渲染 input/select/textarea，不渲染生命周期/阈值写按钮；
   2. 详情头部固定 规则名/编码/状态/风险/判定模板/空间 + 「只读」徽标；业务管理员有「编辑规则」按钮，
      审核员只有本人规则才有「管理规则」按钮（保留其现有回滚/下线权限，其余情况只读）；
   3. 生命周期操作、阈值参数编辑都移入「编辑规则 / 管理规则」面板，详情页不再像表单；
   4. 排版：顶部摘要 + 六个分区的两列 key-value（概览/适用范围/执行计划/证据要求/生命周期与版本/关联与使用），
      减小嵌套卡片，长表格在窄屏横向滚动；只读展示空值「未填写 / 未配置」不隐藏。
   5. T-109（2026-11-18）生命周期新口径：规则不需要审批，草稿直接「发布生效」；
      编辑已发布规则会 fork 新草稿，旧 published 版本继续生效直到新版本发布；
      发布后若检测到冲突只提醒并跳转冲突提醒，不阻断发布、不回滚；approved/superseded 全中文历史。
   字段口径沿用 T-64：RuleDefinition 规则定义 / Scope 适用范围 / ExecutionPlan 执行计划 /
   Evidence 证据要求 / Lifecycle 生命周期与版本 / Usage 关联与使用；模板槽位显示 RULE_TEMPLATES 中文字段名；
   审核范围 A–G、项目文档类型、项目空间属于项目级/空间级字段，只在「适用范围（只读）」里做只读路由说明。 */

const RDF_GROUPS = [
  ["definition", "① 概览 · 规则定义", "RuleDefinition"],
  ["scope", "② 适用范围", "Scope"],
  ["execution_plan", "③ 执行计划", "ExecutionPlan"],
  ["evidence", "④ 证据要求", "Evidence"],
  ["lifecycle", "⑤ 生命周期与版本", "Lifecycle"],
  ["usage", "⑥ 关联与使用", "Usage"],
];
/* 执行计划四项：与新建规则表单、execution_plan.derive 的取值口径一致 */
const RDF_EXEC_SCOPE = { block: "区块", row: "行", sheet: "Sheet", document: "整份文档", document_set: "跨文件（部分支持）" };
const RDF_EXEC_AGG = { single: "单值/首行", all: "全部行/全部子项", any: "任一满足", sum: "求和（部分支持）", compare: "跨对象比较（部分支持）" };
const RDF_EXEC_KIND = { deterministic: "确定性工具/数值", semantic: "语义判断", hybrid: "混合" };
const RDF_EXEC_FALLBACK = { abstain: "转人工/无法判断", ask: "要求补证", fail: "判不满足", single_block_first: "先查单区块，再决定" };
const RDF_STATUS = { draft: "草稿", pending: "待审批（旧流程·历史）", approved: "已批准（旧流程·历史）",
  published: "已发布", archived: "已下线" };
const RDF_VERSION_STATUS = { draft: "草稿", pending: "待审批（旧流程）", approved: "已批准（旧流程）",
  published: "已发布", superseded: "已被替代" };
const RDF_LEGACY_STATUS = ["pending", "approved"];
/* 规则性质（后端 nature code）→ 中文标签；未知值保留原值 */
const RDF_NATURE = { threshold: "阈值/数值", obligation: "义务/禁止", evidence: "事实/证据完备",
  relational: "关系/一致性", procedural: "流程/形式" };
/* 来源口径中文标签（未知来源保留原值，不伪造） */
const RDF_SOURCE = { manual: "手工创建", conversation: "一句话生成", document_decompose: "文件拆解",
  file: "文件拆解", rule_export: "规则导入", rule_pack: "规则包导入", rule_mining: "规则挖掘",
  evolution: "进化沉淀", rsi_feedback: "反馈沉淀", sedimented: "反馈沉淀", builtin: "内置规则",
  decision: "决策表", library: "审核库点位", document: "文档拆解", sop: "制度拆解",
  enterprise_standard: "企业标准拆解", historical_audit: "历史审核沉淀" };
/* 槽位 key → 中文字段名（模板字段优先用 RULE_TEMPLATES 的 label；这里兜底常见扩展 key，绝不展示 _template 等内部 key） */
const RDF_SLOT_LABELS = {
  metric: "指标", parameter: "指标", op: "比较符", operator: "比较符", value: "目标值", threshold: "目标值",
  unit: "单位", tolerance: "允差/范围", pattern: "格式规则", example: "正确样例",
  process: "工序", required_steps: "必备步骤", required_docs: "必备文件", record_field: "记录字段", required: "是否必填",
  objects: "比对对象", across: "跨文档/位置", object: "对象", forbidden: "禁止表述",
  action: "动作", frequency: "频率", window: "时间窗", role: "岗位/角色", qualification: "资质要求",
  equipment: "设备", state: "状态要求", item: "对象", label_required: "必备标识", cited: "被引用内容", source: "引用来源",
  description: "规则说明", detail: "规则说明", tags: "检索/路由标签", scope: "作用域", applicable_when: "适用条件",
  applicable_types: "适用文档类型", doc_types: "适用文档类型", required_evidence: "必需证据",
  required_evidence_list: "结构化证据清单", evidence: "证据", positive_example: "正例", negative_example: "反例",
  combination: "组合方式", combine: "组合方式", require_any: "任一满足项", subrequirements: "子要求",
  when: "条件组", conditions: "条件组", all: "全部条件", any: "任一条件", priority: "优先级",
  effective_period: "生效期间", exceptions: "例外", severity: "严重度", nature: "规则性质",
  criterion: "判据", text: "判据", evidence_scope: "证据范围", aggregation: "汇总方式",
  evaluation_kind: "判定方式", fallback: "证据不足处理",
};
const RDF_INTERNAL_KEYS = new Set(["criterion", "text", "evidence_scope", "evidence_scopes", "aggregation",
  "batch_scope", "evaluation_kind", "method", "fallback", "on_insufficient", "scope", "applicable_when",
  "applicable_types", "doc_types", "description", "detail", "required_evidence", "required_evidence_list",
  "evidence", "positive_example", "negative_example", "tags", "severity", "_nature", "_executor", "_template",
  "when", "conditions", "all", "any", "subrequirements", "require_any", "combination", "combine",
  "priority", "effective_period", "exceptions"]);
const RDF_LIFE_CONFIRM = {
  publish: "发布生效？规则无需审批，发布后立即参与下一次审核。若检测到规则冲突会提示并跳转冲突提醒，不阻断发布、不自动回滚。",
  rollback: "回滚为草稿？已发布版本会继续生效，直到新草稿发布；规则状态变为草稿。",
  archive: "下线这条规则？下线后不再参与审核；版本与审计记录保留，不物理删除。",
};
const RDF_LIFE_DONE = { publish: "已发布生效（无需审批）", rollback: "已回滚为草稿",
  archive: "已下线" };

function rdfJson(text, fallback) {
  try { const v = JSON.parse(text == null ? "" : String(text)); return v == null ? fallback : v; } catch (e) { return fallback; }
}
function rdfTxt(v) {
  if (Array.isArray(v)) return v.filter((x) => String(x == null ? "" : x).trim() !== "").join("、");
  return v == null ? "" : String(v).trim();
}
function rdfArr(v) {
  if (Array.isArray(v)) return v.filter((x) => String(x == null ? "" : x).trim() !== "").map((x) => String(x).trim());
  const s = v == null ? "" : String(v).trim();
  return s ? [s] : [];
}
function rdfEmpty(kind) { return `<span class="rdf-empty">${kind === "cfg" ? "未配置" : "未填写"}</span>`; }
function rdfVal(v, kind) { const s = rdfTxt(v); return s ? esc(s) : rdfEmpty(kind); }
function rdfListVal(v, kind) {
  const list = rdfArr(v);
  if (!list.length) return rdfEmpty(kind);
  return list.map((x) => `<span class="rule-chip">${esc(x)}</span>`).join(" ");
}
/* rows: [标签, 值HTML, 是否整行跨两列] */
function rdfKv(rows) {
  return `<div class="rule-kv">${rows.map((row) => {
    const wide = row && row[2] ? " rdf-kv-wide" : "";
    return `<div class="${wide.trim()}"><span class="k">${esc(row[0])}</span><span class="v">${row[1]}</span></div>`;
  }).join("")}</div>`;
}
function rdfChipRow(items) {
  if (!items.length) return rdfEmpty("cfg");
  return `<div class="rule-chip-row">${items.map((it) => {
    const val = rdfTxt(it.value);
    return `<span class="rule-chip" title="${esc(it.key || "")}"><b>${esc(it.label)}</b>${val ? esc(val) : `<span class="rdf-empty-inline">未填写</span>`}</span>`;
  }).join("")}</div>`;
}
function rdfSubhead(title, extra) {
  return `<div class="rdf-subhead"><b>${esc(title)}</b>${extra ? `<small>${extra}</small>` : ""}</div>`;
}
function rdfSection(key, body, extra) {
  const g = RDF_GROUPS.find((x) => x[0] === key) || [key, key, ""];
  return `<div class="rule-detail-section rdf-group" id="rdf-group-${key}"><h3>${esc(g[1])} <em class="rdf-group-en">${esc(g[2])}</em>${extra || ""}</h3>${body}</div>`;
}
function rdfEnsureStyle() {
  if (document.querySelector("#rdf-style")) return;
  const st = document.createElement("style");
  st.id = "rdf-style";
  st.textContent = [
    ".rdf-group-en{font-style:normal;font-weight:400;font-size:10.5px;color:#A9AEB8;margin-left:2px;letter-spacing:.2px}",
    ".rdf-group-note{font-size:11.5px;line-height:1.7;color:#8F959E;margin-top:8px}",
    ".rdf-subhead{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;font-size:12px;color:#1F2329;font-weight:600;margin:16px 0 6px;padding-top:12px;border-top:1px dashed #EEF0F2}",
    ".rdf-subhead small{font-weight:400;font-size:11px;color:#8F959E}",
    ".rdf-subblock{margin:14px 0 0;padding:0;border:0;background:transparent}",
    ".rdf-subblock-title{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;font-size:12px;font-weight:600;color:#1F2329;margin:0 0 8px;padding-top:12px;border-top:1px dashed #EEF0F2}",
    ".rdf-subblock-title small{font-weight:400;font-size:10.5px;color:#8F959E}",
    ".rdf-empty{color:#B8BDC4}",
    ".rdf-empty-inline{color:#B8BDC4}",
    ".rdf-note{font-size:11.5px;line-height:1.7;color:#8F959E;margin-top:8px}",
    ".rdf-plan-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 24px}",
    ".rdf-src{font-size:10px;color:#8F959E;border:1px solid #E5E6E8;border-radius:4px;padding:0 4px;margin-left:5px;white-space:nowrap}",
    ".rdf-warn{font-size:11.5px;line-height:1.7;color:#8F5E00;background:#FFF8E6;border:1px solid #FFE7A3;border-radius:6px;padding:7px 10px;margin-top:8px}",
    ".rdf-era{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}",
    ".rdf-era span{font-size:11px;color:#4E5969;background:#F2F3F5;border-radius:5px;padding:3px 7px}",
    ".rdf-table-wrap{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}",
    ".rdf-ver-table{width:100%;border-collapse:collapse;font-size:12px;margin-top:6px;min-width:520px}",
    ".rdf-ver-table th{text-align:left;color:#8F959E;font-weight:500;padding:6px 8px;border-bottom:1px solid #EEF0F2;white-space:nowrap}",
    ".rdf-ver-table td{padding:6px 8px;border-bottom:1px solid #F5F6F7;color:#1F2329;vertical-align:top}",
    ".rdf-ver-table tr.rdf-cur td{background:#F5F9FF}",
    ".rdf-explain{font-size:12px;line-height:1.7;color:#4E5969;background:#F7F8FA;border-left:3px solid #3370FF;border-radius:0 6px 6px 0;padding:8px 11px;margin-top:10px}",
    ".rdf-banner{font-size:11.5px;line-height:1.7;color:#8F5E00;background:#FFF8E6;border:1px solid #FFE7A3;border-radius:6px;padding:8px 11px;margin-bottom:12px}",
    ".rdf-hero{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin:0 0 10px;padding:14px 16px;background:#FAFBFC;border:1px solid #EBEDF0;border-radius:10px}",
    ".rdf-hero-title{display:flex;align-items:center;gap:10px;flex-wrap:wrap;min-width:0}",
    ".rdf-hero-title h2{font-size:19px;line-height:1.35;margin:0;font-weight:600;overflow-wrap:anywhere}",
    ".rdf-badge{display:inline-flex;align-items:center;font-size:11px;line-height:19px;padding:0 8px;border-radius:10px;border:1px solid #DEE0E3;background:#F2F3F5;color:#4E5969;font-weight:500;white-space:nowrap}",
    ".rdf-badge-readonly{background:#F2F3F5;border-color:#DEE0E3;color:#4E5969}",
    ".rdf-hero-meta{display:flex;flex-wrap:wrap;gap:6px 18px;margin-top:9px;font-size:12px;color:#8F959E}",
    ".rdf-hero-meta>span{display:inline-flex;align-items:center;gap:5px;min-width:0;max-width:100%}",
    ".rdf-hero-meta em{font-style:normal;color:#8F959E;flex:none}",
    ".rdf-hero-meta b{font-weight:500;color:#1F2329;overflow-wrap:anywhere}",
    ".rdf-hero-actions{flex:none;display:flex;gap:8px;align-items:flex-start}",
    ".rdf-hero-actions .btn{height:34px;padding:0 16px}",
    ".rdf-readonly-hint{font-size:11.5px;line-height:1.7;color:#646A73;background:#FAFBFC;border:1px solid #F0F2F4;border-radius:7px;padding:7px 11px;margin:0 0 6px}",
    ".rule-detail-section{border-top:1px solid #EFF0F1;padding:16px 0 6px}",
    ".rule-detail-section:first-child{border-top:0;padding-top:0}",
    ".rule-detail-section h3{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;font-size:13.5px;font-weight:600;color:#1F2329;margin:0 0 8px}",
    ".rule-kv>div{padding:6px 0;font-size:12.5px;line-height:1.6;gap:12px}",
    ".rule-kv .k{min-width:96px}",
    ".rule-kv>div.rdf-kv-wide{grid-column:1/-1}",
    ".rdf-param-box{background:#FAFBFC;border:1px solid #F0F2F4;border-radius:8px;padding:10px 12px;margin-top:2px}",
    ".rdf-param-box .rule-kv>div{border-bottom:1px solid #EFF1F3}",
    ".rdf-findings{display:flex;flex-direction:column;gap:8px;margin-top:8px}",
    ".rdf-findings .finding{margin-bottom:0}",
    ".rdf-edit-modal{width:min(860px,calc(100vw - 32px));max-height:92vh;overflow:auto;padding:0;display:flex;flex-direction:column}",
    ".rdf-edit-head{position:sticky;top:0;z-index:2;display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:15px 20px;background:#fff;border-bottom:1px solid #EBEDF0;flex:none}",
    ".rdf-edit-head h3{font-size:15.5px;margin:0 0 3px;font-weight:600}",
    ".rdf-edit-head .muted{font-size:11.5px}",
    ".rdf-edit-body{padding:16px 20px 4px;overflow:auto;flex:1 1 auto}",
    ".rdf-edit-note{font-size:11.5px;line-height:1.7;color:#8F5E00;background:#FFF8E6;border:1px solid #FFE7A3;border-radius:6px;padding:8px 11px;margin-bottom:14px}",
    ".rdf-edit-sec{margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid #F2F3F5}",
    ".rdf-edit-sec:last-child{border-bottom:0;margin-bottom:0;padding-bottom:4px}",
    ".rdf-edit-sec h4{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;font-size:12.5px;font-weight:600;color:#1F2329;margin:0 0 10px}",
    ".rdf-edit-sec h4 small{font-weight:400;font-size:10.5px;color:#8F959E}",
    ".rdf-edit-status{font-size:12px;color:#4E5969;margin-bottom:10px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}",
    ".rdf-edit-readonly{font-size:12px;line-height:1.7;color:#4E5969;background:#F7F8FA;border-radius:7px;padding:9px 11px}",
    ".rdf-edit-footer{position:sticky;bottom:0;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 20px;background:#fff;border-top:1px solid #EBEDF0;flex:none}",
    ".rdf-edit-msg{font-size:12px;color:#D83931;line-height:1.5;min-height:18px;flex:1 1 auto;overflow-wrap:anywhere}",
    ".rdf-scope-opt-grid{display:flex;flex-wrap:wrap;gap:6px 14px;padding:7px 10px;border:1px solid #E5E6E8;border-radius:7px;background:#FAFBFC}",
    ".rdf-scope-opt{display:inline-flex;align-items:center;gap:5px;font-size:12px;color:#1F2329;cursor:pointer}",
    ".rdf-edit-footer .actions{flex:none}",
    "@media(max-width:760px){.rdf-plan-grid{grid-template-columns:1fr}.rdf-hero{flex-direction:column;gap:10px;padding:12px 13px}.rdf-hero-actions{width:100%}.rdf-hero-actions .btn{flex:1}.rdf-edit-modal{width:calc(100vw - 16px);max-height:94vh}.rdf-edit-body{padding:12px 14px 2px}.rdf-edit-head,.rdf-edit-footer{padding:11px 14px}.rdf-edit-footer{flex-wrap:wrap}.rdf-edit-msg{min-height:0;width:100%}.rdf-edit-footer .actions{width:100%;justify-content:flex-end}.rule-kv .k{min-width:84px}.rule-detail-section h3{font-size:13px}}",
  ].join("\n");
  document.head.appendChild(st);
}
function rdfVerNum(v) {
  const m = String(v == null ? "" : v).match(/(\d+(?:\.\d+)?)/);
  return m ? parseFloat(m[1]) : -1;
}
/* 版本内容指纹：只展示短哈希，不把 slots_json 原始内部 key（_template 等）暴露到界面 */
function rdfFingerprint(text) {
  const s = String(text == null ? "" : text);
  if (!s) return "";
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return "fp-" + h.toString(16).padStart(8, "0");
}
function rdfTemplateFields(template, category) {
  const tpls = (typeof RULE_TEMPLATES !== "undefined" && RULE_TEMPLATES) || {};
  const t = tpls[template] || tpls[category] || null;
  return t ? t.fields.map((f) => ({ key: f[0], label: f[1] })) : [];
}
function rdfTplLabel(template, category) {
  const tpls = (typeof RULE_TEMPLATES !== "undefined" && RULE_TEMPLATES) || {};
  return (tpls[template] || tpls[category] || {}).label || "";
}
function rdfRangeList(category) {
  try {
    const ranges = (typeof TEMPLATE_RANGES !== "undefined" && TEMPLATE_RANGES[category]) || [];
    return ranges.map((id) => {
      const nm = ((typeof AUDIT_RANGES !== "undefined" && AUDIT_RANGES.find((x) => x[0] === id)) || [])[1] || "";
      return { id: id, name: nm };
    });
  } catch (e) { return []; }
}
/* 把点位列表整理成：id/code → 点位，type_id → {categoryId,typeName}，并给出点位三级 */
function rdfIndexPoints(options, categories) {
  const nameToCat = new Map();
  (Array.isArray(categories) ? categories : []).forEach((c) => {
    if (c && c.id && c.name) nameToCat.set(String(c.name), String(c.id));
  });
  const byId = new Map();
  const byType = new Map();
  const list = (options && options.items) || [];
  list.forEach((p) => {
    if (!p || !(p.id || p.code)) return;
    const byName = nameToCat.get(String(p.category || ""));
    const prefix = String(p.type_id || p.code || p.id || "").charAt(0).toUpperCase();
    const cat = byName || (/[A-G]/.test(prefix) ? prefix : "");
    const item = Object.assign({}, p, { __cat: cat });
    byId.set(String(p.id || p.code), item);
    if (p.code && p.code !== p.id) byId.set(String(p.code), item);
    if (p.type_id) {
      const cur = byType.get(String(p.type_id)) || { category: cat, name: p.type_name || "" };
      if (!cur.category && cat) cur.category = cat;
      byType.set(String(p.type_id), cur);
    }
  });
  return { byId, byType, list, docTypes: (options && options.doc_types) || [] };
}
function rdfPointTriple(pid, idx) {
  const raw = String(pid == null ? "" : pid).trim();
  if (!raw) return { mapped: false, id: "", cat: "", typeId: "", typeName: "", code: "", name: "" };
  const p = (idx && idx.byId.get(raw)) || null;
  if (p) {
    return { mapped: true, id: p.id || raw, cat: p.__cat || "", typeId: p.type_id || "",
             typeName: p.type_name || "", code: p.code || p.id || raw, name: p.name || "" };
  }
  const t = (idx && idx.byType.get(raw)) || null;
  if (t) return { mapped: true, id: "", cat: t.category || "", typeId: raw, typeName: t.name || "", code: "", name: "" };
  return { mapped: true, id: raw, cat: /^[A-G]/.test(raw) ? raw.charAt(0) : "", typeId: "", typeName: "", code: raw, name: "" };
}
function rdfResolveWorkspace(wsResp, base) {
  const cur = (wsResp && wsResp.current) || {};
  const items = (wsResp && (wsResp.items || wsResp.workspaces)) || [];
  const wsId = String(base.workspace_id || cur.id || "");
  const found = (Array.isArray(items) ? items : []).find((x) => x && String(x.id || "") === wsId);
  const name = (found && found.name) || (String(cur.id || "") === wsId ? cur.name : "") || "";
  return { id: wsId, name: name || (wsId ? `空间 ${wsId}` : "未配置"), current: String(cur.id || "") === wsId };
}

function rdfRemoveEditor() {
  const old = document.querySelector("#rule-edit-modal");
  if (!old) return false;
  old.remove();
  return true;
}
function rdfToast(msg, type) {
  if (typeof showToast === "function") { try { showToast(msg, type); return; } catch (e) {} }
  try { console.log("[rule-detail] " + msg); } catch (e) {}
}
function rdfRefreshDetail(ctx, msg) {
  rdfRemoveEditor();
  if (msg) rdfToast(msg);
  try { if (typeof refreshRuleDomain === "function") refreshRuleDomain(); else if (typeof loadRules === "function") loadRules(); } catch (e) {}
  return loadDetail(ctx.detailId);
}
async function rdfPostJson(url, body) {
  const opt = { method: "POST" };
  if (body !== undefined) { opt.headers = { "Content-Type": "application/json" }; opt.body = JSON.stringify(body); }
  try {
    const resp = await fetch(url, opt);
    let data = null;
    try { data = await resp.json(); } catch (e) { data = null; }
    return data || { error: `请求失败（HTTP ${resp.status}）` };
  } catch (e) { return { error: "请求失败：网络错误" }; }
}

/* ---------- 编辑/管理面板（只有这里出现 input/select/textarea 与写操作按钮） ---------- */
function rdfLifeButtons(ctx) {
  const s = String(ctx.statusRaw || "");
  const btn = (act, label, disabled, primary) =>
    `<button class="btn${primary ? " primary" : ""}" type="button" data-life="${act}"${disabled ? " disabled" : ""}>${label}</button>`;
  if (ctx.canManageRule) {
    if (s === "draft") return btn("publish", "发布生效", false, true) + btn("archive", "下线（丢弃草稿）", false);
    if (s === "approved") return btn("publish", "发布生效（旧批准数据兼容）", false, true) + btn("rollback", "回滚为草稿", false) + btn("archive", "下线", false);
    if (s === "pending") return btn("rollback", "回滚为草稿", false, true) + btn("archive", "下线", false)
      + '<span class="muted" style="font-size:12px">旧审批流程遗留：待审批不可直接发布，先回滚为草稿</span>';
    if (s === "published") return btn("rollback", "回滚为草稿（编辑新版本）", false, true) + btn("archive", "下线", false);
    return '<span class="muted">已下线规则不可发布/编辑；版本与审计记录保留。</span>';
  }
  if (ctx.canReviewerLifecycle) {
    if (s === "draft") return btn("archive", "下线（丢弃草稿）", false);
    if (s === "archived") return '<span class="muted">已下线规则无可用操作。</span>';
    return btn("rollback", "回滚为草稿", false) + btn("archive", "下线", false);
  }
  return "";
}
function rdfScopeKv(ctx) {
  return rdfKv([
    ["审核范围（A–G）", ctx.rangeList.length ? ctx.rangeList.map((r) => `<span class="rule-chip">${esc(r.id)} ${esc(r.name)}</span>`).join(" ") : rdfEmpty("cfg")],
    ["适用文档类型", ctx.docTypes.length ? rdfListVal(ctx.docTypes, "cfg") : rdfEmpty("cfg")],
    ["所属空间 / 租户", `${esc(ctx.ws.name)}${ctx.ws.current ? `<span class="rdf-src">当前空间</span>` : ""} / ${esc(ctx.tenantId || "未配置")}`],
    ["指定点位", ctx.point.mapped ? `${esc(ctx.point.code || ctx.point.id)}${ctx.point.name ? ` · ${esc(ctx.point.name)}` : ""}` : rdfEmpty("cfg")],
  ]);
}
function rdfEvidenceKv(ctx) {
  return rdfKv([
    ["必需证据", rdfVal(ctx.requiredEvidence)],
    ["结构化证据清单", ctx.evidenceList.length ? rdfListVal(ctx.evidenceList, "cfg") : rdfEmpty("cfg")],
    ["结构化证据记录", ctx.evidenceRecordHtml],
  ]);
}
function rdfCapabilityReadonly(ctx) {
  const pc = rdfCapabilityState(ctx);
  if (!pc) return "";
  const L = pc.left || {}, R = pc.right || {};
  return `<div class="rdf-kv-wide"><span class="k">执行能力</span><span class="v">跨文档一致性（key_kind=${esc(pc.key_kind || "entity")}，${esc(L.file || "")}.${esc(L.value_label || "")} ↔ ${esc(R.file || "")}.${esc(R.value_label || "")}）</span></div>`;
}
function rdfExecReadonly(ctx) {
  return rdfCapabilityReadonly(ctx) + rdfKv(ctx.execPlanRows) +
    (ctx.planSteps.length ? `<div class="rdf-era">${ctx.planSteps.map((s) => `<span>${esc(s)}</span>`).join("")}</div>` : "") +
    `<div class="rdf-note">${ctx.planLabel ? "后端执行计划：" + esc(ctx.planLabel) : "执行计划未配置：规则没有可推导的执行槽位。"}</div>`;
}
function rdfParamReadonlyHtml(ctx) {
  const p = ctx.paramInfo;
  if (!p) return `<span class="muted">该规则无阈值参数</span>`;
  const val = p.val ? esc(p.val) : rdfEmpty("cfg");
  return `<div class="rule-kv">
    <div><span class="k">指标</span><span class="v">${esc(p.metric || "—")}</span></div>
    <div><span class="k">当前阈值</span><span class="v">${val}${p.revised ? ` <span class="pill draft">已修订</span>` : ""}</span></div>
    <div class="rdf-kv-wide"><span class="k">作用域</span><span class="v">${esc(p.scope || "—")}</span></div>
  </div>
  <div class="rdf-note">阈值参数只读展示；修改与发布在「${ctx.canManageRule ? "编辑规则" : "—"}」面板中完成，不在此页写库。</div>`;
}
/* 阈值参数编辑只在「编辑规则」面板出现；详情只读页不渲染这些输入/按钮 */
function rdfParamEditorHtml(ctx) {
  const p = ctx.paramInfo;
  if (!p) return `<span class="muted">该规则无阈值参数</span>`;
  const val = p.val ? esc(p.val) : rdfEmpty("cfg");
  const raw = p.rawValue != null && p.rawValue !== "" ? esc(String(p.rawValue)) : "";
  return `<div class="rule-kv">
    <div><span class="k">指标</span><span class="v">${esc(p.metric || "—")}</span></div>
    <div><span class="k">当前阈值</span><span class="v">${val}${p.revised ? ` <span class="pill draft">已修订</span>` : ""}</span></div>
    <div class="rdf-kv-wide"><span class="k">作用域</span><span class="v">${esc(p.scope || "—")}</span></div>
  </div>
  <div class="actions" style="margin-top:8px">
    <input id="rp-value" class="field" style="width:120px" placeholder="新阈值" value="${raw}">
    <button class="btn" type="button" id="rp-save">保存草稿</button>
    <button class="btn primary" type="button" id="rp-publish">发布生效</button>
    <span class="muted" id="rp-msg"></span>
  </div>
  <div class="rdf-note">阈值参数走「保存草稿 → 发布生效」两段，发布后从下一轮审核起生效，历史结果不追溯；参数旁路不改变规则版本状态。</div>`;
}
/* T-185（KB 评审 P1-1）：作用域/证据的可编辑字段。
 * 断点：拆解/知识库引用入库的规则只有 `_scope_missing` 标记，没有
 * applicable_types/applicable_when → 发布 400 scope_missing；而本编辑器原先把
 * 「生效范围」写成只读 → 用户没有任何 UI 途径补齐 → 规则永远发布不了。
 * 这里补齐 4 组字段（适用范围/适用条件/证据范围/点位映射）+ 必需证据，
 * 保存走 /api/v1/rules/{id}/update，后端做白名单/长度/真实点位二次校验。 */
const RDF_SCOPE_EXT = ["xlsx", "xls", "docx", "doc", "pdf", "txt", "csv"];
const RDF_EVIDENCE_RANGE_LABEL = { document: "整份文档", block: "区块", row: "行",
                                   sheet: "Sheet", document_set: "跨文件（部分支持）" };
function rdfScopeEditorHtml(ctx) {
  const curTypes = (ctx.docTypes || []).map((x) => String(x || "").trim()).filter(Boolean);
  const curExt = new Set(curTypes.map((x) => x.toLowerCase().replace(/^\./, ""))
    .filter((x) => RDF_SCOPE_EXT.includes(x)));
  const curOther = curTypes.filter((x) => !RDF_SCOPE_EXT.includes(x.toLowerCase().replace(/^\./, "")));
  const wsOther = (ctx.wsDocTypes || []).filter((x) => !curTypes.includes(x));
  const evNow = (ctx.evidenceScopeNow && ctx.evidenceScopeNow.length)
    ? ctx.evidenceScopeNow.map((x) => String(x).toLowerCase()) : ["document"];
  const extHtml = RDF_SCOPE_EXT.map((e) =>
    `<label class="rdf-scope-opt"><input type="checkbox" data-scope-type value="${e}"${curExt.has(e) ? " checked" : ""}> ${e}</label>`).join("");
  const otherHtml = curOther.map((t) =>
    `<label class="rdf-scope-opt"><input type="checkbox" data-scope-type value="${esc(t)}" checked> ${esc(t)}</label>`).join("");
  const wsHtml = wsOther.map((t) =>
    `<label class="rdf-scope-opt"><input type="checkbox" data-scope-type value="${esc(t)}"> ${esc(t)}</label>`).join("");
  const evHtml = Object.keys(RDF_EVIDENCE_RANGE_LABEL).map((k) =>
    `<label class="rdf-scope-opt"><input type="checkbox" data-scope-ev value="${k}"${evNow.includes(k) ? " checked" : ""}> ${esc(RDF_EVIDENCE_RANGE_LABEL[k])}</label>`).join("");
  const pointOpts = (ctx.pointOptions || []).map((p) =>
    `<option value="${esc(p.id)}">${esc(p.code || p.id)} · ${esc(p.name || "")}${p.type_id ? " · " + esc(p.type_id) : ""}</option>`).join("");
  const curPoint = ctx.point && ctx.point.mapped
    ? `${esc(ctx.point.code || ctx.point.id)}${ctx.point.name ? " · " + esc(ctx.point.name) : ""}`
    : "自定义规则（未绑定平台点位）";
  const inferredNote = ctx.scopeInferredNote
    ? `<div class="rdf-warn" style="margin-bottom:8px">${esc(ctx.scopeInferredNote)}</div>` : "";
  return `${inferredNote}
    <div class="nr-grid">
      <div class="nr-field wide"><span>适用范围（文档类型，可多选） <em class="req">发布必填</em></span>
        <div class="rdf-scope-opt-grid">${extHtml}${otherHtml}${wsHtml || ""}</div>
        <small class="nr-field-help">文件扩展名决定被审对象路由；也可勾选当前空间的文档类型。业务范围（如“卤制工序”）请填「适用条件」。一张不选且适用条件为空时，发布会被 scope_missing 阻断。</small>
      </div>
      <label class="nr-field wide"><span>适用条件（可留空 = 不限）</span>
        <input id="re-scope-when" class="field" maxlength="200" value="${esc(ctx.applicableWhen || "")}" placeholder="例如：卤制工序；或本规范适用的业务范围">
      </label>
      <div class="nr-field wide"><span>证据范围（可多选） <em class="opt">选填</em></span>
        <div class="rdf-scope-opt-grid">${evHtml}</div>
        <small class="nr-field-help">决定 D3 证据绑定粒度（整份文档/区块/行/Sheet）；写入执行计划的 evidence_scope。</small>
      </div>
      <label class="nr-field wide"><span>必需证据 <em class="opt">选填（记录/程序类规则发布必填）</em></span>
        <input id="re-required-evidence" class="field" maxlength="500" value="${esc(ctx.evidenceNow || "")}" placeholder="例如：工序参数表 · 实测中心温度；或 批次号记录">
        <small class="nr-field-help">发布门禁按 IR 契约校验：记录/程序（R5）、语义（R3）、关系（R4）类规则缺必需证据会被 ir_needs_structure 阻断。</small>
      </label>
      <label class="nr-field wide"><span>点位映射 <em class="opt">选填</em></span>
        <select id="re-point" class="field">
          <option value="">保持不变（当前：${curPoint}）</option>
          ${pointOpts}
        </select>
        <small class="nr-field-help">点位映射不是发布条件；绑定平台点位只影响审核类型路由。不绑定 = 按自定义规则执行（可选「保持不变」）。</small>
      </label>
    </div>`;
}
/* T-197（P0-1）：本体能力入口——跨文档一致性（同一事实前后一致）。
 * 用户口径：本体只对 3 类点位有价值；本面板只暴露真实接线的 1 类
 * （分项合计/日期链在后端能力清单里如实标注 not_wired，不在此提供假入口）。
 * 保存走 POST /api/v1/ontology/capabilities {action:configure_rule}，服务端校验键/外侧文件/口径。 */
function rdfCapabilityState(ctx) {
  const pc = (ctx.slots && ctx.slots.project_compute) || {};
  if (String(pc.calculation || "") !== "cross_doc_consistency") return null;
  return pc;
}
function rdfCapabilityEditorHtml(ctx) {
  const pc = rdfCapabilityState(ctx);
  const on = !!pc;
  const L = (pc && pc.left) || {}, R = (pc && pc.right) || {};
  const opt = (v, cur, label) => `<option value="${esc(v)}"${String(cur || "") === v ? " selected" : ""}>${esc(label)}</option>`;
  const keyKind = (pc && pc.key_kind) || "entity";
  const vtype = (L.value_type || R.value_type) || "money";
  return `<section class="rdf-edit-sec" id="rdf-edit-capability">
    <h4>执行能力（跨文档一致性） <small>本体能力入口 · 保存后点「发布生效」才执行</small></h4>
    <div class="nr-grid">
      <label class="nr-field"><span>执行能力</span>
        <select id="re-cap-mode" class="field">
          <option value=""${on ? "" : " selected"}>普通规则（不消费本体）</option>
          <option value="cross_doc_consistency"${on ? " selected" : ""}>跨文档一致性（同一事实前后一致）</option>
        </select>
      </label>
      <label class="nr-field"><span>键类型（如何判断两侧是同一事实）</span>
        <select id="re-cap-keykind" class="field">
          ${opt("entity", keyKind, "entity · 实体名（组织形式/本体别名归一）")}
          ${opt("label", keyKind, "label · 口径名（指标别名归一）")}
          ${opt("code", keyKind, "code · 编号（易混字符/前导零归一）")}
        </select>
      </label>
      <label class="nr-field"><span>两侧比较口径</span>
        <select id="re-cap-vtype" class="field">
          ${opt("money", vtype, "money · 金额")}
          ${opt("quantity", vtype, "quantity · 数量")}
          ${opt("date", vtype, "date · 日期")}
          ${opt("code", vtype, "code · 编号")}
        </select>
      </label>
      <label class="nr-field"><span>结论归属文件（owner_file）</span><input id="re-cap-owner" class="field" maxlength="120" value="${esc((pc && pc.owner_file) || "")}" placeholder="默认=左文件"></label>
    </div>
    <div class="nr-grid">
      <label class="nr-field"><span>左侧文件</span><input id="re-cap-l-file" class="field" maxlength="120" value="${esc(L.file || "")}" placeholder="例如：合同A"></label>
      <label class="nr-field"><span>左侧键标签</span><input id="re-cap-l-key" class="field" maxlength="60" value="${esc(L.key_label || L.key || "")}" placeholder="例如：合同编号"></label>
      <label class="nr-field"><span>左侧值标签</span><input id="re-cap-l-val" class="field" maxlength="60" value="${esc(L.value_label || "")}" placeholder="例如：合同金额"></label>
      <label class="nr-field"><span>右侧文件</span><input id="re-cap-r-file" class="field" maxlength="120" value="${esc(R.file || "")}" placeholder="例如：发票"></label>
      <label class="nr-field"><span>右侧键标签</span><input id="re-cap-r-key" class="field" maxlength="60" value="${esc(R.key_label || R.key || "")}" placeholder="例如：合同编号"></label>
      <label class="nr-field"><span>右侧值标签</span><input id="re-cap-r-val" class="field" maxlength="60" value="${esc(R.value_label || "")}" placeholder="例如：发票金额"></label>
    </div>
    <div class="rdf-note" id="re-cap-note">口径：两侧键按字面/归一/编号易混/本体别名对齐后，比较声明的值；键未对齐或取值失败记「证据不足」，不按相似度猜。
      空间本体开关关闭（默认关）时审核不执行该执行器；开关在「空间列表 → 查看详情 → 本体能力」中按空间开启。</div>
  </section>`;
}
function rdfEditorHtml(ctx, mode) {
  const isEdit = mode === "edit";
  const title = isEdit ? "编辑规则" : "管理规则";
  const intro = isEdit
    ? "此面板是唯一的编辑/管理入口：可修改规则内容，并执行生命周期与阈值参数操作。规则无需审批：保存后回到只读详情，点「发布生效」直接生效。修改已发布规则会先生成新草稿版本，旧版本继续生效，直到新版本发布；发布后若检测到冲突只提醒、不阻断、不回滚。"
    : "你是这条规则的创建人：只读详情页不提供写操作，这里只提供生命周期操作（回滚/下线）。规则内容编辑与「发布生效」由业务管理员负责（规则无需审批）。";
  const contentSec = isEdit
    ? `<section class="rdf-edit-sec" id="rdf-edit-content">
        <h4>规则内容 <small>可编辑（名称 / 判定模板 / 判据）</small></h4>
        <div class="nr-grid">
          <label class="nr-field wide"><span>规则名称</span><input id="re-name" class="field" maxlength="60" value="${esc(ctx.name)}"></label>
          <label class="nr-field"><span>判定模板</span><select id="re-cat" class="field">${rdfTemplateOptions(ctx)}</select></label>
          <label class="nr-field wide"><span>判据</span><textarea id="re-criterion" class="field" style="min-height:96px">${esc(ctx.criterion)}</textarea></label>
        </div>
      </section>`
    : `<section class="rdf-edit-sec" id="rdf-edit-content">
        <h4>规则内容 <small>只读</small></h4>
        ${rdfKv([
          ["规则名称", rdfVal(ctx.name)],
          ["规则编码", rdfVal(ctx.code)],
          ["判定模板", ctx.tplLabel ? `${esc(ctx.tplLabel)}<span class="rdf-src">${esc(ctx.categoryLabel || ctx.template || "")}</span>` : rdfEmpty("cfg")],
          ["当前状态", esc(ctx.statusLabel || "未配置")],
          ["判据", ctx.criterion ? esc(ctx.criterion) : rdfEmpty("cfg"), true],
        ])}
      </section>`;
  return `<div class="modal rdf-edit-modal" role="dialog" aria-modal="true" aria-label="${title}">
    <div class="rdf-edit-head">
      <div><h3>${title}</h3><div class="muted">${esc(ctx.name)} · ${esc(ctx.code)}</div></div>
      <button class="ws-close" type="button" data-re-close aria-label="关闭${title}">×</button>
    </div>
    <div class="rdf-edit-body">
      <div class="rdf-edit-note">${intro}</div>
      ${contentSec}
      ${isEdit && ctx.canEditRule ? rdfCapabilityEditorHtml(ctx) : ""}
      <section class="rdf-edit-sec" id="rdf-edit-scope">
        ${isEdit && ctx.canEditRule
          ? `<h4>适用范围 / 适用条件 / 证据范围 / 点位映射 <small>可编辑（发布门禁用这组字段）</small></h4>
             ${rdfScopeEditorHtml(ctx)}`
          : `<h4>生效范围 <small>只读提示：由规则映射与项目路由决定，不在本面板修改</small></h4>
             ${rdfScopeKv(ctx)}
             <div class="rdf-note">当前角色无规则内容编辑权限；业务管理员可在「编辑规则」面板补齐适用范围后发布。</div>`}
      </section>
      <section class="rdf-edit-sec" id="rdf-edit-evidence">
        <h4>证据要求 <small>只读</small></h4>
        ${rdfEvidenceKv(ctx)}
      </section>
      <section class="rdf-edit-sec" id="rdf-edit-exec">
        <h4>执行计划 <small>只读</small></h4>
        ${rdfExecReadonly(ctx)}
      </section>
      <section class="rdf-edit-sec" id="rdf-edit-lifecycle">
        <h4>生命周期操作 <small>草稿 → 发布生效（无需审批）；发布后冲突只提醒</small></h4>
        <div class="rdf-edit-status">当前状态：<span class="pill ${ctx.statusRaw === "published" ? "published" : ctx.statusRaw === "archived" ? "r" : "draft"}">${esc(ctx.statusLabel || "未配置")}</span><span class="muted">操作真实写库，按状态机校验</span></div>
        <div class="actions">${rdfLifeButtons(ctx) || '<span class="muted">当前角色无生命周期写权限</span>'}</div>
        <div class="rdf-note">发布/回滚/下线动作只在此编辑/管理面板出现；编辑已发布规则会生成新草稿，旧生效版本继续执行到新版本发布；发布后若发现冲突会跳转冲突提醒，不阻断发布。</div>
      </section>
      <section class="rdf-edit-sec" id="rdf-edit-params">
        <h4>阈值参数 <small>可发布参数（仅编辑态可改）</small></h4>
        ${isEdit && ctx.canManageRule ? rdfParamEditorHtml(ctx) : rdfParamReadonlyHtml(ctx)}
      </section>
    </div>
    <div class="rdf-edit-footer">
      <span class="rdf-edit-msg" id="re-msg"></span>
      <div class="actions">
        <button class="btn" type="button" data-re-close>取消（返回只读）</button>
        ${isEdit ? '<button class="btn primary" type="button" id="re-save">保存修改</button>' : ""}
      </div>
    </div>
  </div>`;
}
function rdfTemplateOptions(ctx) {
  const tpls = (typeof RULE_TEMPLATES !== "undefined" && RULE_TEMPLATES) || {};
  const cur = String(ctx.category || "");
  const opts = Object.entries(tpls).map(([k, v]) =>
    `<option value="${esc(k)}"${k === cur ? " selected" : ""}>${esc(v.label)}</option>`).join("");
  if (!cur || tpls[cur]) return opts;
  return `<option value="${esc(cur)}" selected>${esc(ctx.categoryLabel || cur)}（当前自定义类别）</option>` + opts;
}
function rdfOpenEditor(ctx, mode) {
  if (mode === "edit" && !ctx.canEditRule) return;
  if (mode === "manage" && !ctx.canReviewerLifecycle) return;
  rdfRemoveEditor();
  const mask = document.createElement("div");
  mask.id = "rule-edit-modal";
  mask.className = "modal-mask";
  mask.innerHTML = rdfEditorHtml(ctx, mode);
  document.body.appendChild(mask);
  mask.querySelectorAll("[data-re-close]").forEach((b) => { b.onclick = () => rdfRemoveEditor(); });
  mask.onclick = (e) => { if (e.target === mask) rdfRemoveEditor(); };
  mask.querySelectorAll("[data-life]").forEach((b) => { b.addEventListener("click", () => rdfLifecycleAction(ctx, b)); });
  if (mode === "edit") {
    const save = mask.querySelector("#re-save");
    if (save) save.onclick = () => rdfSaveEditor(ctx, mask);
    if (ctx.canManageRule) {
      const ps = mask.querySelector("#rp-save");
      if (ps) ps.onclick = () => rdfSaveParam(ctx, mask);
      const pp = mask.querySelector("#rp-publish");
      if (pp) pp.onclick = () => rdfPublishParam(ctx, mask);
    }
  }
}
async function rdfSaveEditor(ctx, mask) {
  const msg = mask.querySelector("#re-msg");
  const q = (s) => mask.querySelector(s);
  const name = String((q("#re-name") || {}).value || "").trim();
  const criterion = String((q("#re-criterion") || {}).value || "").trim();
  const category = String((q("#re-cat") || {}).value || ctx.category || "");
  if (!name || !criterion) { if (msg) msg.textContent = "规则名称和判据不能为空"; return; }
  // T-185：作用域字段（编辑态才有；只读/管理态不写）
  const scopeTypes = Array.from(mask.querySelectorAll("[data-scope-type]:checked"))
    .map((x) => String(x.value || "").trim()).filter(Boolean);
  const scopeWhen = String(((q("#re-scope-when") || {}).value || "")).trim();
  const evidenceScope = Array.from(mask.querySelectorAll("[data-scope-ev]:checked"))
    .map((x) => String(x.value || "").trim()).filter(Boolean);
  const requiredEvidence = String(((q("#re-required-evidence") || {}).value || "")).trim();
  const pointId = String(((q("#re-point") || {}).value || "")).trim();
  const hasScopeEditor = !!mask.querySelector("[data-scope-type]");
  // 前端必填提示（不是唯一防线：后端 update_draft 同口径二次校验）
  if (hasScopeEditor && ctx.scopeNeedsDeclare && !scopeTypes.length && !scopeWhen) {
    if (msg) msg.textContent = "请先选择适用范围（文档类型）或填写适用条件：未声明作用域的规则发布时会被 scope_missing 阻断";
    return;
  }
  const btn = q("#re-save");
  if (btn) { btn.disabled = true; btn.textContent = "保存中…"; }
  const body = { name, category, criterion };
  if (hasScopeEditor) {
    body.scope = { applicable_types: scopeTypes, applicable_when: scopeWhen,
                   evidence_scope: evidenceScope };
    body.evidence_scope = evidenceScope;
    body.required_evidence = requiredEvidence;
    // 后端二次校验开关：声明后仍为 missing 直接 400，不产生“假成功”
    body.scope_declare_required = !!ctx.scopeNeedsDeclare;
    if (pointId) body.point_id = pointId;
  }
  const res = await rdfPostJson(`/api/v1/rules/${encodeURIComponent(ctx.detailId)}/update`, body);
  if (res && res.error) {
    if (msg) msg.textContent = String(res.error);
    if (btn) { btn.disabled = false; btn.textContent = "保存修改"; }
    return;
  }
  // T-197（P0-1）：执行能力配置（本体域 API；服务端做键/文件/口径二次校验）
  const capSel = mask.querySelector("#re-cap-mode");
  if (capSel && mask.querySelector("#re-cap-l-file")) {
    const capMode = String(capSel.value || "");
    const capCur = rdfCapabilityState(ctx);
    const capPrev = capCur ? "cross_doc_consistency" : "";
    if (capMode !== capPrev) {
      if (btn) { btn.disabled = true; btn.textContent = "保存执行能力…"; }
      const cross = capMode ? {
        key_kind: String((q("#re-cap-keykind") || {}).value || "entity"),
        owner_file: String((q("#re-cap-owner") || {}).value || "").trim(),
        left: { file: String((q("#re-cap-l-file") || {}).value || "").trim(),
                key_label: String((q("#re-cap-l-key") || {}).value || "").trim(),
                value_label: String((q("#re-cap-l-val") || {}).value || "").trim(),
                value_type: String((q("#re-cap-vtype") || {}).value || "money") },
        right: { file: String((q("#re-cap-r-file") || {}).value || "").trim(),
                 key_label: String((q("#re-cap-r-key") || {}).value || "").trim(),
                 value_label: String((q("#re-cap-r-val") || {}).value || "").trim(),
                 value_type: String((q("#re-cap-vtype") || {}).value || "money") }
      } : null;
      const capRes = await rdfPostJson("/api/v1/ontology/capabilities", {
        action: "configure_rule", rule_id: ctx.detailId,
        execution_mode: capMode, cross_doc: cross
      });
      if (capRes && (capRes.error || capRes.ok === false)) {
        if (msg) msg.textContent = "规则已保存，但执行能力未保存成功：" + String(capRes.error || capRes.reason || "");
        if (btn) { btn.disabled = false; btn.textContent = "保存修改"; }
        return;
      }
      if (msg) msg.textContent = (msg.textContent || "") + "；执行能力已保存（发布后生效）";
    }
  }
  document.querySelector("#re-msg") && (document.querySelector("#re-msg").textContent = "已保存");
  const _wasEff = ["published", "approved"].includes(String(ctx.statusRaw || ""));
  const _scopeSaved = hasScopeEditor
    ? `；适用范围已声明（${String((res && res.scope_status) || "declared")}），可点「发布生效」`
    : "";
  await rdfRefreshDetail(ctx, (_wasEff
    ? "已保存为新的草稿版本；旧生效版本继续生效，直到点「发布生效」（无需审批）"
    : "规则已保存为草稿；到「草稿箱」或此面板点「发布生效」后生效（无需审批）") + _scopeSaved);
}
async function rdfLifecycleAction(ctx, btn) {
  const act = String(btn.dataset.life || "");
  if (!act) return;
  let ok = true;
  try {
    ok = typeof confirmAction === "function"
      ? await confirmAction(act === "publish" ? "发布生效（无需审批）" : "生命周期操作",
          RDF_LIFE_CONFIRM[act] || `确认执行「${btn.textContent}」？`, act === "publish" ? "发布生效" : "确认")
      : confirm(RDF_LIFE_CONFIRM[act] || `确认执行「${btn.textContent}」？`);
  } catch (e) { ok = false; }
  if (!ok) return;
  btn.disabled = true;
  const res = await rdfPostJson(`/api/v1/rules/${encodeURIComponent(ctx.detailId)}/${act}`);
  if (res && res.error) {
    btn.disabled = false;
    const _msg = String(res.message || res.error);
    // T-185：发布门禁拒绝时显示后端中文原因，并直接打开作用域编辑区（不再只弹内部码）
    const _gateCodes = ["scope_missing", "ir_needs_structure", "ir_incomplete"];
    if (act === "publish" && _gateCodes.includes(String(res.error))) {
      if (_msg) alert(_msg + "\n\n已打开编辑面板：请在「适用范围 / 适用条件 / 证据范围」补齐后保存，再点「发布生效」。");
      rdfOpenEditor(ctx, "edit");
      const sec = document.querySelector("#rdf-edit-scope");
      if (sec && sec.scrollIntoView) sec.scrollIntoView({ block: "start", behavior: "smooth" });
      return;
    }
    alert(_msg);
    return;
  }
  const _conflictN = Number((res || {}).conflict_count || 0);
  await rdfRefreshDetail(ctx, act === "publish" ? "" : (RDF_LIFE_DONE[act] || "操作已完成"));
  if (act !== "publish") { rdfToast(RDF_LIFE_DONE[act] || "操作已完成"); return; }
  if (_conflictN > 0) { rdfRemoveEditor(); const m = document.querySelector("#rule-detail"); if (m) m.hidden = true; document.body.style.overflow = ""; }
  if (typeof handlePublishOutcome === "function") handlePublishOutcome(res);
  else rdfToast((res && res.conflict_reminder) || "已发布生效（无需审批）");
}
async function rdfSaveParam(ctx, mask) {
  if (!ctx.paramInfo || !ctx.paramsCode) return;
  const msg = mask.querySelector("#rp-msg") || mask.querySelector("#re-msg");
  const input = mask.querySelector("#rp-value");
  const v = parseFloat(input ? input.value : "");
  if (isNaN(v)) { alert("请输入数字"); return; }
  const res = await rdfPostJson(`/api/v1/rules/${encodeURIComponent(ctx.paramsCode)}/params`, { value: v });
  if (res && res.error) { if (msg) msg.textContent = String(res.error); return; }
  await rdfRefreshDetail(ctx, `已保存参数草稿 ${v}；点「发布生效」后才生效`);
}
async function rdfPublishParam(ctx, mask) {
  if (!ctx.paramInfo || !ctx.paramsCode) return;
  const msg = mask.querySelector("#rp-msg") || mask.querySelector("#re-msg");
  let ok = true;
  try {
    ok = typeof confirmAction === "function"
      ? await confirmAction("发布参数", "发布后新阈值立即参与下一轮审核，历史结果不追溯。确认发布？", "确认发布")
      : confirm("发布后新阈值立即参与下一轮审核，历史结果不追溯。确认发布？");
  } catch (e) { ok = false; }
  if (!ok) return;
  const res = await rdfPostJson(`/api/v1/rules/${encodeURIComponent(ctx.paramsCode)}/params/publish`, {});
  if (res && res.error) { if (msg) msg.textContent = String(res.error); return; }
  await rdfRefreshDetail(ctx, "参数已发布，下一轮审核生效");
}

/* ---------- 只读详情渲染 ---------- */
function rdfReadonlyHtml(ctx) {
  const heroActions = ctx.canEditRule
    ? '<button class="btn primary" type="button" data-rule-edit>编辑规则</button>'
    : ctx.canReviewerLifecycle
      ? '<button class="btn" type="button" data-rule-manage>管理规则</button>'
      : "";
  const hero = `<div class="rule-detail-hero rdf-hero">
    <div class="rdf-hero-main">
      <div class="rdf-hero-title"><h2>${esc(ctx.name || "未命名规则")}</h2><span class="rdf-badge rdf-badge-readonly">只读</span>${ctx.legacyStatus ? '<span class="rdf-badge" style="background:#FFF6E8;border-color:#FFD8A8;color:#B45309">历史（旧审批流程）</span>' : ""}</div>
      <div class="rdf-hero-meta">
        <span><em>编码</em><b>${esc(ctx.code || "—")}</b></span>
        <span><em>状态</em><span class="pill ${ctx.statusRaw === "published" ? "published" : ctx.statusRaw === "archived" ? "r" : "draft"}">${esc(ctx.statusLabel || "—")}</span></span>
        <span><em>风险</em><b>${esc(ctx.riskText || "—")}</b></span>
        <span><em>判定模板</em><b>${esc(ctx.tplLabel || "—")}</b></span>
        <span><em>空间</em><b>${esc(ctx.ws.name || "未配置")}</b></span>
      </div>
    </div>
    <div class="rdf-hero-actions">${heroActions}</div>
  </div>
  <div class="rdf-readonly-hint">当前为只读详情：正文不提供编辑控件与写操作。${ctx.legacyStatus
    ? "该规则是旧审批流程遗留状态（历史数据），只读；规则无需审批。如需继续，请业务管理员在规则库列表点「转为草稿」后再编辑并「发布生效」。"
    : ctx.canEditRule ? "如需修改，请点右上角「编辑规则」进入独立编辑面板；修改已发布规则会先生成草稿版本，旧版本继续生效，点「发布生效」后替换（无需审批）。"
    : ctx.canReviewerLifecycle ? "如需回滚/下线本人规则，请点右上角「管理规则」；其他修改与发布需业务管理员（规则无需审批）。"
    : "审核员只读；修改规则需业务管理员。"}</div>`;
  const definitionBody = `${rdfKv([
    ["规则名称", rdfVal(ctx.name), true],
    ["规则编码", rdfVal(ctx.code)],
    ["判定模板", ctx.tplLabel ? `${esc(ctx.tplLabel)}<span class="rdf-src">${esc(ctx.categoryLabel || ctx.template || "")}</span>` : rdfEmpty("cfg")],
    ["规则形式", `${esc(ctx.formLabel)}${ctx.formInferred ? '<span class="rdf-src">按模板/判据推导</span>' : ""}`],
    ["风险等级", `${esc(ctx.riskText || "未配置")}（${esc(ctx.rclassRaw || "未配置")}）`],
    ["规则性质", ctx.natureLabel ? esc(ctx.natureLabel) : rdfEmpty("cfg")],
    ["来源", esc(ctx.sourceLabel || "内置规则")],
    ["负责人 / 部门", `${rdfVal(ctx.ownerName || ctx.ownerId)} / ${ctx.dept ? esc(ctx.dept) : rdfEmpty("cfg")}`],
    ["所属空间", `${esc(ctx.ws.name)}${ctx.ws.id ? `<span class="rdf-src">${esc(ctx.ws.id)}</span>` : ""}`],
    ["创建时间", rdfVal(ctx.created)],
    ["最近更新", rdfVal(ctx.updated)],
    ["形式判断依据", ctx.formReason ? esc(ctx.formReason) : rdfEmpty("cfg"), true],
  ])}
  <div class="rdf-group-note">判定模板（12 类）是规则级“怎么判”；项目上的「审核范围（A–G）」是项目级路由字段，不是规则字段，两者不是同一套分类。</div>`;
  const _scopeWarn = ctx.scopeNeedsDeclare
    ? '<div class="rdf-warn">适用范围未声明：发布会被 scope_missing 阻断。点右上角「编辑规则」，在「适用范围」区选择文档类型或填写适用条件后保存即可发布。</div>'
    : (ctx.scopeInferredNote ? `<div class="rdf-note">${esc(ctx.scopeInferredNote)}</div>` : "");
  const scopeBody = `${_scopeWarn}${rdfKv([
    ["规则说明", rdfVal(ctx.scopeDesc), true],
    ["检索 / 路由标签", ctx.tags.length ? rdfListVal(ctx.tags, "cfg") : rdfEmpty("cfg"), true],
    ["作用域", rdfVal(ctx.scopeValue)],
    ["适用条件", rdfVal(ctx.applicableWhen)],
    ["适用文档类型", ctx.docTypes.length ? rdfListVal(ctx.docTypes, "cfg") : rdfEmpty("cfg"), true],
    ["指定点位", ctx.point.mapped ? `${esc(ctx.point.code || ctx.point.id)}${ctx.point.name ? ` · ${esc(ctx.point.name)}` : ""}` : rdfEmpty("cfg")],
    ["点位映射方式", esc(ctx.mappingMode)],
    ["正例", rdfVal(ctx.positiveExample), true],
    ["反例", rdfVal(ctx.negativeExample), true],
  ])}
  ${rdfSubhead("适用范围（只读）", "A–G / 文档类型 / 空间 / 点位三级")}
  <div id="rdf-applicability">
    ${rdfKv([
      ["审核范围（A–G）", ctx.rangeList.length ? ctx.rangeList.map((r) => `<span class="rule-chip">${esc(r.id)} ${esc(r.name)}</span>`).join(" ") : rdfEmpty("cfg")],
      ["适用文档类型", ctx.docTypes.length ? rdfListVal(ctx.docTypes, "cfg") : `${rdfEmpty("cfg")}<span class="rdf-note">（规则不限定文档类型；项目文档类型是项目级字段）</span>`],
      ["所属空间 / 租户", `${esc(ctx.ws.name)}${ctx.ws.current ? '<span class="rdf-src">当前空间</span>' : ""} / ${esc(ctx.tenantId || "未配置")}`],
      ["点位 · 审核大类", ctx.point.cat ? `${esc(ctx.point.cat)} ${esc(((typeof AUDIT_RANGES !== "undefined" && AUDIT_RANGES.find((x) => x[0] === ctx.point.cat)) || [])[1] || "")}` : rdfEmpty("cfg")],
      ["点位 · 审核类型", ctx.point.typeId ? `${esc(ctx.point.typeId)}${ctx.point.typeName ? ` · ${esc(ctx.point.typeName)}` : ""}` : rdfEmpty("cfg")],
      ["点位 · 审核点位", ctx.point.mapped ? `${esc(ctx.point.code || ctx.point.id)}${ctx.point.name ? ` · ${esc(ctx.point.name)}` : ""}` : rdfEmpty("cfg")],
    ])}
    <div class="rdf-note"><b>职责边界：</b>审核范围 A–G、项目文档类型、项目空间都是<b>项目级/空间级字段</b>，不属于规则字段；这里只读展示本规则的适用范围与路由结果（A–G 由判定模板映射得出，点位由规则映射得出），新建项目与新建规则各自填写、互不替代。</div>
  </div>`;
  const execBody = `<div class="rule-criterion">${ctx.criterion ? esc(ctx.criterion) : rdfEmpty("cfg")}</div>
  <div class="rdf-subblock">
    <div class="rdf-subblock-title">执行计划（四项）<small>与新建规则「执行计划」同名字段</small></div>
    <div class="rdf-plan-grid">${rdfKv(ctx.execPlanRows)}</div>
    ${ctx.planSteps.length ? `<div class="rdf-era">${ctx.planSteps.map((s) => `<span>${esc(s)}</span>`).join("")}</div>` : ""}
    ${ctx.planLabel ? `<div class="rdf-note">后端执行计划：${esc(ctx.planLabel)}${ctx.planSupported === false ? "（存在部分支持项）" : ""}</div>` : '<div class="rdf-note">执行计划未配置：规则没有可推导的执行槽位。</div>'}
    ${ctx.planWarnings.length ? `<div class="rdf-warn">注意：${esc(ctx.planWarnings.join("；"))}</div>` : ""}
    ${ctx.planUnsupported.length ? `<div class="rdf-warn">未支持项：${esc(ctx.planUnsupported.join("；"))}</div>` : ""}
  </div>
  ${ctx.isDecisionKind ? `<div class="rdf-subblock">
    <div class="rdf-subblock-title">决策表行（条件 → 结论）<small>命中策略 ${esc(ctx.hitPolicy || "未配置")} · 版本 ${esc(ctx.dtVersion || ctx.latestVersionNo || "未配置")}</small></div>
    ${ctx.decisionRows.length
      ? `<div class="rdf-table-wrap"><table class="rdf-ver-table"><thead><tr><th style="width:44px">行</th><th>条件</th><th>结论</th></tr></thead><tbody>
        ${ctx.decisionRows.map((row, i) => `<tr><td>${i + 1}</td><td>${((row && row.when) || []).map((c) => esc(`${(c && c.metric) || ""} ${(c && c.op) || ""} ${(c && c.value) != null ? c.value : ""}`.trim())).join(" 且 ") || rdfEmpty("cfg")}</td>
          <td>${esc((row && row.severity) || "")} ${esc((row && row.message) || "")}${row && row.suggestion ? `<div class="rdf-note">建议：${esc(row.suggestion)}</div>` : ""}</td></tr>`).join("")}
      </tbody></table></div>`
      : rdfEmpty("cfg")}
    <div class="rdf-note">决策表来源：条件与结论在决策表中定义；本页只读展示（决策表行不丢失），编辑/发布请从规则库列表该决策表行的「决策表」入口或「新建规则 → 决策表组合」进入。${ctx.dtScopeTypes && ctx.dtScopeTypes.length ? " 适用范围（文档类型）：" + esc(ctx.dtScopeTypes.join("、")) : ""}</div>
  </div>`
  : ctx.versionsCount ? `<div class="rdf-subblock">
    <div class="rdf-subblock-title">判据参数（模板槽位）<small>${ctx.tplLabel ? esc(ctx.tplLabel) + " · " : ""}字段名与新建规则表单一致</small></div>
    ${ctx.tplChips.length ? rdfChipRow(ctx.tplChips) : rdfEmpty("cfg")}
    ${ctx.extraChips.length ? `<div style="margin-top:8px">${rdfChipRow(ctx.extraChips)}</div>` : ""}
  </div>` : '<div class="rdf-subblock"><div class="rdf-subblock-title">判据参数（模板槽位）</div><div class="rdf-note">该条目来自审核库/客户规则库列表，没有客户规则版本槽位；判据见上，参数不伪造。客户规则请点「详情」查看数据库中的规则版本。</div></div>'}
  ${ctx.isDecisionKind ? "" : `<div class="rdf-subhead"><b>参数明细</b><small>单条参数规则的关键字段</small></div>${rdfKv([
    ["指标", rdfVal(ctx.slots.metric || ctx.slots.parameter)],
    ["比较符", rdfVal(ctx.slots.op || ctx.slots.operator)],
    ["目标值", rdfVal(ctx.slots.value != null && ctx.slots.value !== "" ? ctx.slots.value : ctx.slots.threshold)],
    ["单位", rdfVal(ctx.slots.unit)],
    ["允差 / 范围", rdfVal(ctx.slots.tolerance)],
    ["优先级", rdfVal(ctx.slots.priority)],
    ["生效期间", rdfVal(ctx.slots.effective_period)],
    ["组合方式", rdfVal(ctx.slots.combination || ctx.slots.combine)],
    ["例外", rdfListVal(ctx.slots.exceptions)],
  ])}
  ${ctx.explainCondition ? `<div class="rdf-explain"><b>为什么这么判：</b>${esc(ctx.explainCondition)}</div>` : ""}
  ${rdfSubhead("阈值参数", "只读；编辑与发布在「" + (ctx.canEditRule ? "编辑规则" : ctx.canReviewerLifecycle ? "管理规则" : "编辑/管理") + "」面板")}
  <div id="rule-params" class="rdf-param-box">${rdfParamReadonlyHtml(ctx)}</div>`}`;
  const evidenceBody = `${rdfKv([
    ["必需证据", rdfVal(ctx.requiredEvidence), true],
    ["结构化证据清单", ctx.evidenceList.length ? rdfListVal(ctx.evidenceList, "cfg") : rdfEmpty("cfg"), true],
    ["结构化证据记录", ctx.evidenceRecordHtml, true],
  ])}
  <div class="rule-exec ${ctx.exec.level === "unjudgeable" ? "bad" : ctx.exec.level === "semi" ? "warn" : ctx.exec.level === "deterministic" ? "ok" : ""}" style="margin-top:10px">
    <b>可执行性：${ctx.exec.level === "unjudgeable" ? "不可判定" : ctx.exec.level === "semi" ? "半可判定" : ctx.exec.level === "deterministic" ? "可执行" : esc(ctx.exec.level || "未检查")}</b>
    ${(ctx.exec.missing || []).length ? `<span>缺少：${esc((ctx.exec.missing || []).join("、"))}</span>` : ""}
    ${(ctx.exec.suggestions || []).length ? `<span class="muted">${esc((ctx.exec.suggestions || []).join("；"))}</span>` : ""}
    ${!(ctx.exec.missing || []).length && !(ctx.exec.suggestions || []).length ? '<span class="muted">无缺口记录</span>' : ""}
  </div>`;
  const _effectiveCell = ctx.effectiveVersionNo
    ? `${esc(ctx.effectiveVersionNo)} <span class="rdf-src">生效中</span>`
    : rdfEmpty("cfg");
  const _latestCell = ctx.latestVersionNo
    ? `${esc(ctx.latestVersionNo)}` + (ctx.latestIsDraft
        ? ' <span class="pill draft">草稿（待发布）</span>'
        : ' <span class="pill published">当前生效</span>')
    : rdfEmpty("cfg");
  const lifecycleBody = `${rdfKv([
    ["当前状态", `${esc(ctx.statusLabel || "未配置")}${ctx.legacyStatus ? ' <span class="pill r">旧审批流程·历史</span>' : ""}`],
    ["当前生效版本", _effectiveCell],
    ["最新版本", _latestCell],
    ["最新版本状态", rdfVal(ctx.latestStatus)],
    ["版本数", esc(String(ctx.versionsCount))],
    ["创建时间", rdfVal(ctx.created)],
    ["最近更新", rdfVal(ctx.updated)],
  ])}
  <div class="timeline" style="margin-top:10px"><span class="node done">沉淀</span><span class="node done">测试</span><span class="node ${ctx.effectiveVersionNo ? "done" : ""}">发布生效（无需审批）</span><span class="node">回放</span></div>
  ${ctx.versions.length ? `<div class="rdf-subhead"><b>版本记录</b><small>共 ${ctx.versionsCount} 个版本，展示最近 ${Math.min(ctx.versionsCount, 8)} 个；版本状态含「已发布 / 已被替代」中文历史</small></div><div class="rdf-table-wrap"><table class="rdf-ver-table"><thead><tr><th>版本</th><th>状态</th><th>发布时间</th><th>批准时间（旧流程）</th><th>内容指纹</th></tr></thead><tbody>
    ${ctx.versions.slice(0, 8).map((v) => {
      const _vst = String(v.status || "");
      const _isEff = String(v.id || "") === String(ctx.effectiveVersionId || "");
      return `<tr class="${_isEff ? "rdf-cur" : ""}">
      <td>${esc(v.version || "—")}${_isEff ? ' <span class="rdf-src">生效中</span>' : ""}</td>
      <td>${esc(RDF_VERSION_STATUS[_vst] || _vst || "—")}</td>
      <td>${esc(v.published_at || "未发布")}</td>
      <td>${esc(v.approved_at || "—")}</td>
      <td class="muted">${v.slots_json ? esc(rdfFingerprint(v.slots_json)) : "—"}</td></tr>`; }).join("")}
  </tbody></table></div>` : '<div class="rdf-note">该条目没有客户规则版本记录（审核库点位由点位库版本管理）。</div>'}
  <div class="rdf-note">规则无需审批：草稿直接「发布生效」。生命周期操作已移到只读页之外的「${ctx.canEditRule ? "编辑规则" : ctx.canReviewerLifecycle ? "管理规则" : "编辑/管理"}」面板，只读页不提供写操作。${ctx.canEditRule
    ? "当前状态：" + esc(ctx.statusLabel || "—") + "；编辑已发布规则会生成新草稿版本，旧生效版本继续执行到新版本发布。"
    : ctx.canReviewerLifecycle ? "你是这条规则的创建人，可在管理面板回滚/下线；其他修改、发布需业务管理员。"
    : "审核员只能查看非本人规则；只有创建人可以回滚或下线自己的规则。"}</div>`;
  const usageBody = `${rdfKv([
    ["命中问题数", esc(String(ctx.findingsNum))],
    ["人工 override 数", esc(String(ctx.overrideNum))],
    ["规则健康度（未 override 比例）", esc(ctx.health)],
    ["引用点位", ctx.point.mapped ? `<span class="rule-chip">${esc(ctx.point.code || ctx.point.id)}${ctx.point.name ? ` · ${esc(ctx.point.name)}` : ""}</span>` : rdfEmpty("cfg")],
  ])}
  <div class="rdf-group-note">关联使用：命中问题数、人工 override 与规则健康度由真实审核/复核数据统计，不伪造；导出与复核权限沿用项目/报告门禁。</div>
  ${rdfSubhead("命中明细", `共 ${ctx.findingsNum} 条${ctx.findings.length ? `，展示 ${Math.min(ctx.findings.length, 20)} 条` : ""}`)}
  ${ctx.findings.length ? `<div class="rdf-findings">${ctx.findings.slice(0, 20).map((f) => `
    <div class="finding"><div class="ft">${esc(f.title)} <span class="pill ${f.severity === "critical" ? "draft" : "r"}">${f.severity === "critical" ? "严重" : "一般"}</span></div>
      <div class="fd">${esc(f.summary || "")}</div><div class="loc">${(f.evidence || []).map((a) => `<a href="/api/v1/highlight" target="_blank">${esc(a.locator || a.sheet)}</a>`).join(" · ")}</div></div>`).join("")}</div>` : '<div class="muted">暂无命中</div>'}`;
  return `${hero}
  ${ctx.banner}
  ${rdfSection("definition", definitionBody)}
  ${rdfSection("scope", scopeBody)}
  ${rdfSection("execution_plan", execBody)}
  ${rdfSection("evidence", evidenceBody)}
  ${rdfSection("lifecycle", lifecycleBody)}
  ${rdfSection("usage", usageBody)}`;
}

async function loadDetail(id, opts) {
  rdfEnsureStyle();
  rdfRemoveEditor();
  const modal = document.querySelector("#rule-detail");
  if (!modal) return;
  /* 并发防串：多次快速打开详情时，只允许最后一次请求把结果写进 DOM（旧请求晚到不得覆盖新详情）。 */
  const reqSeq = (window.__rdfDetailSeq = (window.__rdfDetailSeq || 0) + 1);
  const r = (typeof rules !== "undefined" && rules.find((x) => x.id === id)) || {};
  let d = {};
  let detailStatus = 0;
  try {
    const resp = await fetch(`/api/v1/rules/${encodeURIComponent(id)}`);
    detailStatus = resp.status;
    if (resp.ok) d = await resp.json() || {};
  } catch (e) { detailStatus = -1; }
  const detailMissing = !(d.rule && Object.keys(d.rule || {}).length);
  const base = detailMissing ? r : d.rule;
  let ev = {};
  let planAll = null;
  let paramsAll = null;
  let optionsResp = null;
  let catsResp = null;
  let wsResp = null;
  const slotsProbe = (() => {
    const vs = d.versions || [];
    const v0 = vs.slice().sort((a, b) => rdfVerNum(b.version) - rdfVerNum(a.version))[0] || {};
    return rdfJson(v0.slots_json, {}) || {};
  })();
  const isDecisionKind = String((r && r.kind) || "") === "decision";
  const _tasks = [
    fetch(`/api/v1/rules/${encodeURIComponent(id)}/explain`).then((x) => (x.ok ? x.json() : null)).catch(() => null),
    fetch("/api/v1/rules/params").then((x) => (x.ok ? x.json() : null)).catch(() => null),
    fetch("/api/v1/audit-points/options").then((x) => (x.ok ? x.json() : null)).catch(() => null),
    fetch("/api/v1/audit-categories").then((x) => (x.ok ? x.json() : null)).catch(() => null),
    fetch("/api/v1/workspaces").then((x) => (x.ok ? x.json() : null)).catch(() => null),
  ];
  const _tIdx = {};
  if (Object.keys(slotsProbe).length) {
    _tIdx.plan = _tasks.length;
    _tasks.push(fetch("/api/v1/rules/plan-preview", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: (base && base.name) || "", category: (base && base.category) || "",
                             rclass: (base && base.rclass) || "", slots: slotsProbe }),
    }).then((x) => (x.ok ? x.json() : null)).catch(() => null));
  }
  if (isDecisionKind) {
    _tIdx.dt = _tasks.length;
    _tasks.push(fetch(`/api/v1/decision-tables/${encodeURIComponent(id)}`).then((x) => (x.ok ? x.json() : null)).catch(() => null));
  }
  const _res = await Promise.all(_tasks);
  ev = _res[0] || {};
  paramsAll = _res[1];
  optionsResp = _res[2];
  catsResp = _res[3];
  wsResp = _res[4];
  planAll = _tIdx.plan != null && _res[_tIdx.plan] ? (_res[_tIdx.plan].plan || null) : null;
  const dt = _tIdx.dt != null ? (_res[_tIdx.dt] || null) : null;

  const versions = (d.versions || []).slice().sort((a, b) => rdfVerNum(b.version) - rdfVerNum(a.version));
  const currentVid = String((base && base.current_version_id) || "");
  /* T-109：生效版本 = 版本 status=published（与 manifest/执行同口径）；最新版本 = 最高版本号（可能是草稿）。
     编辑已发布规则后 current_version_id 仍指向旧 published，旧版本继续生效；新草稿是 latest。 */
  const effectiveVersion = versions.find((v) => String(v.status || "") === "published") || null;
  const latest = versions[0] || {};
  const latestIsDraft = !!latest && String(latest.status || "") === "draft";
  const slots = rdfJson((latestIsDraft ? latest : (latest || effectiveVersion || {})).slots_json, {}) || {};
  const scope = rdfJson(base && base.scope_json, {}) || {};
  const scopeMeta = scope.scope_meta || {};
  const mapping = scope.point_mapping || {};
  const findings = (d.findings || []);
  const exec = (r && r.executability) || (base && base.executability) || {};
  const pointIdx = rdfIndexPoints(optionsResp, catsResp);
  const ws = rdfResolveWorkspace(wsResp, base || {});
  const template = String(slots._template || scope.template || (base && base.category) || "");
  const category = String((base && base.category) || "");
  const tplLabel = rdfTplLabel(template, category);
  const categoryLabel = (typeof CATEGORY !== "undefined" && (CATEGORY[category] || "")) || category;
  const statusRaw = String((dt && dt.status) || (base && base.status) || (r && r.status) || "");
  const statusLabel = RDF_STATUS[statusRaw] || statusRaw;
  const criterion = rdfTxt(slots.criterion || slots.text || scope.criterion) || rdfTxt(d.condition);
  const form = isDecisionKind ? "decision_table"
    : String(scope.form || ((slots.when || slots.conditions) ? "decision_table" : "single"));
  const formInferred = !isDecisionKind && !scope.form;
  const formLabel = form === "decision_table" ? "决策表组合多条件" : "单条参数规则";
  const formReason = isDecisionKind
    ? "决策表来源：条件组合与结论在决策表中定义（只读，本页逐行展示）"
    : rdfTxt(scope.form_reason);
  const mappingMode = mapping.override ? "人工指定" : mapping.mapped ? "自动映射" : "未映射";
  const pointId = rdfTxt(mapping.point_id) || rdfTxt(base && base.point_id) || (r && r.kind === "library" ? rdfTxt(base && base.code) : "");
  const point = rdfPointTriple(pointId, pointIdx);
  const tags = rdfArr(scope.tags).length ? rdfArr(scope.tags) : rdfArr(slots.tags);
  const docTypes = rdfArr(slots.applicable_types).length ? rdfArr(slots.applicable_types)
    : rdfArr(scope.applicable_types).length ? rdfArr(scope.applicable_types)
      : rdfArr(scope.doc_types).length ? rdfArr(scope.doc_types)
        : rdfArr(scopeMeta.route_types).concat(rdfArr(scopeMeta.business_scope));
  // T-185：编辑面板的「适用范围」候选（当前空间文档类型）+ 自动推断说明
  const wsDocTypes = rdfArr(optionsResp && optionsResp.doc_types);
  const pointOptions = Array.isArray(optionsResp && optionsResp.items) ? optionsResp.items : [];
  const scopeInferred = (scope && (scope.scope_inferred || scope.inferred)) || null;
  const _infFields = (scopeInferred && scopeInferred.fields) || {};
  const scopeInferredNote = scopeInferred
    ? (scopeInferred.confirmed
      ? "适用范围/证据范围已确认（自动推断值已由人工保存确认）"
      : "已自动推断，请确认：" + Object.keys(_infFields)
          .map((k) => String((_infFields[k] || {}).reason || k)).filter(Boolean).join("；"))
    : "";
  const scopeNeedsDeclare = !!(scope.scope_required || scopeMeta.missing
    || String(scopeMeta.status || "") === "missing");
  const rangeList = rdfRangeList(category);
  const plan = planAll || {};
  const planScope = rdfArr(plan.evidence_scope).length ? rdfArr(plan.evidence_scope) : rdfArr(slots.evidence_scope);
  const planAgg = rdfTxt(plan.aggregation) || rdfTxt(slots.aggregation);
  const planKind = rdfTxt(plan.evaluation_kind) || rdfTxt(slots.evaluation_kind || slots.method);
  const planFallback = rdfTxt(plan.fallback) || rdfTxt(slots.fallback);
  const _stored = (key, planned) => {
    const st = key === "evidence_scope" ? rdfArr(slots.evidence_scope) : rdfTxt(slots[key]);
    const hasStored = Array.isArray(st) ? st.length > 0 : !!st;
    if (hasStored) return "";
    return planned ? "系统推导" : "";
  };
  const _execVal = (list, value, tag) => {
    const label = list[value] || value || "";
    if (!label) return rdfEmpty("cfg");
    return `${esc(label)}${tag ? `<span class="rdf-src">${esc(tag)}</span>` : ""}`;
  };
  const _scopeLabel = planScope.length ? planScope.map((x) => RDF_EXEC_SCOPE[x] || x).join(" / ") : "";
  const execPlanRows = [
    ["证据范围", _scopeLabel ? `${esc(_scopeLabel)}${_stored("evidence_scope", planScope) ? `<span class="rdf-src">${_stored("evidence_scope", planScope)}</span>` : ""}` : rdfEmpty("cfg")],
    ["汇总方式", _execVal(RDF_EXEC_AGG, planAgg, _stored("aggregation", planAgg))],
    ["判定方式", _execVal(RDF_EXEC_KIND, planKind, _stored("evaluation_kind", planKind))],
    ["证据不足处理", _execVal(RDF_EXEC_FALLBACK, planFallback, _stored("fallback", planFallback))],
  ];
  const planSteps = (plan.steps || []).map((s) => `${s.id || ""} ${s.name || ""}`.trim()).filter(Boolean);
  const planWarnings = rdfArr(plan.warnings);
  const planUnsupported = (plan.unsupported_executors || []).map((x) => `${x.step || ""} ${x.capability || ""}：${x.reason || ""}`);
  const planLabel = rdfTxt(plan.label);
  const tplFields = rdfTemplateFields(template, category);
  const tplKeys = new Set(tplFields.map((f) => f.key));
  const tplChips = tplFields.map((f) => ({ key: f.key, label: f.label, value: slots[f.key] }));
  const extraChips = Object.keys(slots || {}).filter((k) => {
    if (String(k).startsWith("_")) return false;
    if (tplKeys.has(k) || RDF_INTERNAL_KEYS.has(k)) return false;
    const v = slots[k];
    return rdfTxt(v) !== "";
  }).map((k) => ({ key: k, label: RDF_SLOT_LABELS[k] || "扩展字段", value: slots[k] }));
  const evidenceRecords = rdfJson(latest.evidence_json, []);
  const evidenceList = rdfArr(slots.required_evidence_list).length ? rdfArr(slots.required_evidence_list)
    : rdfArr(scope.evidence_list);
  const requiredEvidence = rdfTxt(scope.evidence || slots.required_evidence || slots.evidence || slots.required_evidence_list);
  const evidenceRecordHtml = Array.isArray(evidenceRecords) && evidenceRecords.length
    ? evidenceRecords.slice(0, 6).map((x) => `<span class="rule-chip">${esc(typeof x === "string" ? x : (x.excerpt || x.locator || x.sheet || JSON.stringify(x)).toString().slice(0, 80))}</span>`).join(" ")
    : rdfEmpty("cfg");
  const versionsCount = versions.length;
  const latestVersionNo = rdfTxt((dt && dt.version) || latest.version) || rdfTxt(base && base.version);
  const effectiveVersionNo = isDecisionKind
    ? (statusRaw === "published" ? rdfTxt((dt && dt.version) || (base && base.version)) : "")
    : rdfTxt(effectiveVersion && effectiveVersion.version);
  const effectiveVersionId = isDecisionKind ? "" : String((effectiveVersion && effectiveVersion.id) || "");
  const latestStatus = isDecisionKind ? (RDF_STATUS[statusRaw] || statusRaw)
    : (RDF_VERSION_STATUS[String(latest.status || "")] || String(latest.status || ""));
  const legacyStatus = !!r && RDF_LEGACY_STATUS.indexOf(statusRaw) >= 0;
  const findingsNum = Number((d && d.hit_count) != null ? d.hit_count : ((base && base.hit_count) || (r && r.hit_count) || 0)) || 0;
  const overrideNum = Number((d && d.override_count) != null ? d.override_count : ((base && base.override_count) || (r && r.override_count) || 0)) || 0;
  const rowHealthState = String((r && r.health_state) || "");
  const health = findingsNum > 0
    ? `${Math.round(100 * (1 - overrideNum / findingsNum))}%`
    : (rowHealthState === "unattributed" ? "未归因（不可计算）" : "暂无归因命中");
  const canManageRule = currentRole === "admin";
  const _ownerId = String((base && base.owner_id) || r.owner_id || "");
  const _ownerName = String((r && r.owner) || (base && base.owner) || "");
  const _meName = String((currentUser && (currentUser.name || currentUser.sub)) || "");
  const ownsRule = _ownerId ? _ownerId === String((currentUser && currentUser.sub) || "") : (_ownerName && _ownerName === _meName);
  const canReviewerLifecycle = currentRole === "reviewer" && ownsRule;
  const _dept = String((r && r.department) || "");
  const _updated = String((r && r.updated_at) || (base && base.created_at) || "");
  const _created = String((base && base.created_at) || (r && r.created_at) || "");
  const kind = String((r && r.kind) || (base && base.kind) || "");
  const detailId = String((base && base.id) || (r && r.id) || id || "");
  /* 编辑能力必须真实：详情接口没有返回可编辑的库内规则快照（审核库点位/决策表）时不展示编辑入口，避免伪造 */
  /* 编辑能力必须真实：待审批（旧流程，需先回滚）/已下线/库点位/决策表不展示编辑入口 */
  const canEditRule = canManageRule && !detailMissing && !["library", "decision"].includes(kind) && !!detailId
    && String(statusRaw || "") !== "pending" && String(statusRaw || "") !== "archived";
  const natureRaw = String(scope.nature || rdfTxt(slots._nature) || "");
  const sourceRaw = String((base && base.source) || (r && r.source) || "内置规则");
  const _myp = Array.isArray(paramsAll) ? paramsAll.find((x) => String(x.rule_code || "") === String((base && base.code) || (r && r.code) || "")) : null;
  let paramInfo = null;
  let paramsCode = "";
  if (_myp) {
    const p = _myp.params || {};
    const val = p.op === "range" ? `${p.lo} ~ ${p.hi} ${p.unit || ""}` : `${p.op || ""} ${p.value ?? ""} ${p.unit || ""}`;
    paramInfo = { metric: p.metric, val: val.trim(), scope: p.scope, revised: !!_myp.revised,
                  rawValue: p.op === "range" ? p.lo : p.value };
    paramsCode = String(_myp.rule_code || "");
  }
  const ctx = {
    detailId, id: detailId, base, r, isDecisionKind, kind,
    name: String((base && base.name) || r.name || ""),
    code: String((base && base.code) || r.code || ""),
    category, categoryLabel, template, tplLabel, statusRaw, statusLabel,
    riskText: riskLabel((base && base.rclass) || r.rclass),
    rclassRaw: String((base && base.rclass) || r.rclass || ""),
    formLabel, formReason, formInferred,
    natureLabel: natureRaw ? (RDF_NATURE[natureRaw] || natureRaw) : "",
    sourceLabel: RDF_SOURCE[sourceRaw] || sourceRaw,
    ownerId: _ownerId, ownerName: _ownerName, dept: _dept,
    created: _created, updated: _updated, tenantId: rdfTxt((base && base.tenant_id) || (currentUser && currentUser.tenant_id)),
    ws, point, mappingMode, rangeList, tags, docTypes,
    wsDocTypes, pointOptions, scopeInferred, scopeInferredNote, scopeNeedsDeclare,
    evidenceScopeNow: planScope.length ? planScope : rdfArr(slots.evidence_scope),
    evidenceNow: rdfTxt(slots.required_evidence) || rdfTxt(scope.required_evidence) || rdfTxt(scope.evidence),
    scopeDesc: rdfTxt(scope.description || scope.desc || slots.description),
    scopeValue: rdfTxt(slots.scope || scope.scope),
    applicableWhen: rdfTxt(slots.applicable_when || scope.applicable_when),
    positiveExample: rdfTxt(scope.positive_example),
    negativeExample: rdfTxt(scope.negative_example),
    criterion, slots, execPlanRows, planSteps, planWarnings, planUnsupported, planLabel,
    planSupported: plan.supported,
    tplChips, extraChips, explainCondition: rdfTxt(ev.condition),
    requiredEvidence, evidenceList, evidenceRecordHtml, exec,
    decisionRows: (dt && Array.isArray(dt.rules)) ? dt.rules : [],
    hitPolicy: (dt && dt.hit_policy) || "",
    dtVersion: (dt && dt.version) || "",
    dtScopeTypes: (dt && Array.isArray(dt.scope_types)) ? dt.scope_types : [],
    versions, currentVid, versionsCount, latestVersionNo, latestStatus,
    effectiveVersionNo, effectiveVersionId, latestIsDraft, legacyStatus,
    findings, findingsNum, overrideNum, health,
    detailMissing, detailStatus,
    canManageRule, canReviewerLifecycle, ownsRule, canEditRule,
    paramInfo, paramsCode,
    banner: detailMissing
      ? `<div class="rdf-banner">${esc(("当前条目来自规则库列表/审核库点位（详情接口未返回完整快照，HTTP " + (detailStatus || "?")))}：以下按规则库数据展示，空字段如实标「未填写 / 未配置」，不用旧数据伪装。</div>`
      : [
          legacyStatus
            ? '<div class="rdf-banner">旧审批流程遗留状态（历史数据）：待审批/已批准只读展示。新规则不需要审批，草稿在「草稿箱」直接「发布生效」；此规则如需继续，请业务管理员在规则库列表点「转为草稿」后再编辑、发布。</div>'
            : "",
          (!legacyStatus && String(statusRaw || "") === "draft" && effectiveVersion)
            ? `<div class="rdf-banner">当前处于草稿编辑中：生效版本 <b>${esc(effectiveVersionNo || "—")}</b> 继续参与审核；最新版本 <b>${esc(latestVersionNo || "—")}</b> 在「发布生效」后替换，旧版本自动标记「已被替代」。发布后若检测到冲突会提醒并跳转冲突提醒，不阻断发布、不回滚。</div>`
            : "",
        ].join(""),
  };
  if (reqSeq !== window.__rdfDetailSeq) return;
  document.querySelector("#rule-detail-title").textContent = "规则详情（只读）";
  document.querySelector("#rule-detail-body").innerHTML = rdfReadonlyHtml(ctx);
  /* L84 E3 + L95：点位 API 内部调试入口（仅业务管理员；审核员不可见）。
     /api/v1/audit-points/route（只读）、/execute（POST，单点执行）、
     /batch（POST，L95 批量执行：逐项结果/预算上限/审计；GET 仍 405）。 */
  try { rdfMountInternalTools(ctx); } catch (e) { console.warn("内部工具区挂载失败", e); }
  const eb = document.querySelector("#rule-detail-body [data-rule-edit]");
  if (eb) eb.addEventListener("click", () => rdfOpenEditor(ctx, "edit"));
  const mb = document.querySelector("#rule-detail-body [data-rule-manage]");
  if (mb) mb.addEventListener("click", () => rdfOpenEditor(ctx, "manage"));
  modal.hidden = false;
  document.body.style.overflow = "hidden";
  if (opts && opts.openEdit && ctx.canEditRule) {
    rdfOpenEditor(ctx, "edit");
    // T-185：发布被 scope_missing 阻断时「去补适用范围」直接定位到作用域编辑区
    if (opts.focusScope) {
      const sec = document.querySelector("#rdf-edit-scope");
      if (sec && sec.scrollIntoView) sec.scrollIntoView({ block: "start", behavior: "smooth" });
      const first = document.querySelector("#rdf-edit-scope [data-scope-type]");
      if (first && first.focus) first.focus();
    }
  }
}
document.querySelector("#rule-detail-close")?.addEventListener("click", () => { rdfRemoveEditor(); document.querySelector("#rule-detail").hidden = true; document.body.style.overflow = ""; });
document.querySelector("#rule-detail")?.addEventListener("click", (e) => {
  if (e.target.id === "rule-detail") { rdfRemoveEditor(); e.currentTarget.hidden = true; document.body.style.overflow = ""; }
});
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (rdfRemoveEditor()) return;
  const m = document.querySelector("#rule-detail");
  if (m && !m.hidden) { m.hidden = true; document.body.style.overflow = ""; }
});


/* ===================== 项目（核心） ===================== */
let plPage = 1;

/* ===================== L84 E3 + L95：点位 API「内部工具」调试入口（仅业务管理员） =====================
   覆盖应 UI 8 中的三条点位内部接口（不做大页面，只在规则详情只读面板下方加调试区）：
   - GET  /api/v1/audit-points/route?tier=&families=   点位路由只读预览（真实库数据；空态如实展示）
   - POST /api/v1/audit-points/execute                 单点执行（调试用；需二次确认，结果原样展示）
   - POST /api/v1/audit-points/batch                   L95 批量执行（逐项结果 + 预算上限 + 审计；
                                                        与单点 execute 同一服务层/权限；GET 仍被 405 拦截）
   权限：仅业务管理员可见；审核员/系统管理员不渲染该区（系统管理员 POST 执行会被服务端 403 拒绝）。
   本区不写审核主链、不产生正式 manifest；正式点位执行走审核工作台。 */
function rdfMountInternalTools(ctx) {
  if (currentRole !== "admin") return;
  /* T-98 契约：规则详情「只读正文」(#rule-detail-body) 不得含 input/select/textarea。
     内部工具是独立调试区，挂在只读正文之外（.rule-detail-modal 末尾），保持只读正文纯净。 */
  var modal = document.querySelector(".rule-detail-modal");
  var body = document.querySelector("#rule-detail-body");
  if (!modal || !body) return;
  var oldSec = document.getElementById("rdf-internal-tools");
  if (oldSec) oldSec.remove();
  var sec = document.createElement("section");
  sec.id = "rdf-internal-tools";
  sec.style.cssText = "margin:0 22px 22px;border:1px dashed #DDE0E5;border-radius:8px;padding:12px 14px;background:#FAFBFC";
  var pid = (ctx && ctx.point && (ctx.point.id || ctx.point.code)) || "";
  sec.innerHTML =
    '<div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap">' +
      '<h3 style="font-size:13px;margin:0">内部工具 · 点位 API 调试</h3>' +
      '<span class="pill">管理员 / 调试</span>' +
      '<span class="muted" style="font-size:11px">只做接口联调与排障；不进入审核主链，不是业务必用入口。审核员不可见。</span>' +
    '</div>' +
    '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">' +
      '<b style="font-size:12px">点位路由预览</b>' +
      '<label class="muted" style="font-size:12px">tier' +
        '<select id="rdf-it-tier" class="field" style="margin-left:4px">' +
          '<option value="S1">S1</option><option value="S2" selected>S2</option><option value="S3">S3</option></select></label>' +
      '<input id="rdf-it-families" class="field" style="width:200px" placeholder="families（逗号分隔，可空）">' +
      '<button type="button" class="btn" id="rdf-it-route">查询点位路由</button>' +
    '</div>' +
    '<div id="rdf-it-route-out" class="muted" style="font-size:11.5px;margin-top:6px"></div>' +
    '<div style="margin-top:12px;border-top:1px dashed #E8EAED;padding-top:10px">' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">' +
        '<b style="font-size:12px">单点执行（POST execute，二次确认）</b>' +
        '<label class="muted" style="font-size:12px">点位 ID' +
          '<input id="rdf-it-point" class="field" style="width:120px;margin-left:4px" value="' + esc(pid) + '" placeholder="如 A01-001"></label>' +
      '</div>' +
      '<textarea id="rdf-it-doc" class="field" style="width:100%;min-height:64px;margin-top:6px" ' +
        'placeholder="调试用被测文本（doc_text）；真实项目审核请在工作台上传文件执行，不要依赖本调试入口"></textarea>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-top:6px">' +
        '<button type="button" class="btn" id="rdf-it-execute">执行单点（调试）</button>' +
        '<span class="muted" style="font-size:11px">执行结果原样展示（state/reason）；失败如实显示，不伪造成功。</span>' +
      '</div>' +
      '<pre id="rdf-it-exec-out" class="muted" style="font-size:11px;white-space:pre-wrap;margin:6px 0 0;max-height:220px;overflow:auto"></pre>' +
    '</div>' +
    '<div style="margin-top:12px;border-top:1px dashed #E8EAED;padding-top:10px">' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">' +
        '<b style="font-size:12px">批量执行（POST /api/v1/audit-points/batch）</b>' +
        '<label class="muted" style="font-size:12px">点位 ID（逗号分隔，≤10 个）' +
          '<input id="rdf-it-batch-points" class="field" style="width:220px;margin-left:4px" value="' + esc(pid) + '" placeholder="如 A01-001,A01-002"></label>' +
        '<button type="button" class="btn" id="rdf-it-batch">批量执行（调试）</button>' +
      '</div>' +
      '<textarea id="rdf-it-batch-doc" class="field" style="width:100%;min-height:52px;margin-top:6px" ' +
        'placeholder="批量调试用被测文本（doc_text）；与单点执行同一服务层，真实项目审核请在工作台执行"></textarea>' +
      '<div class="muted" style="font-size:11px;margin-top:6px">' +
        '服务端预算上限：≤10 个点位/批、doc_text ≤200000 字符；超限 400 显式拒绝（不静默截断）。' +
        '批量写 1 条审计（不记 doc_text）；GET 该路径仍被 405 写操作拦截，写语义只走 POST。' +
      '</div>' +
      '<pre id="rdf-it-batch-out" class="muted" style="font-size:11px;white-space:pre-wrap;margin:6px 0 0;max-height:220px;overflow:auto"></pre>' +
    '</div>';
  modal.appendChild(sec);
  var api = async function (url, opts) {
    var init = Object.assign({ credentials: "same-origin" }, opts || {});
    if (init.body && typeof init.body !== "string") {
      init.headers = Object.assign({ "Content-Type": "application/json" }, init.headers || {});
      init.body = JSON.stringify(init.body);
    }
    try {
      var resp = await fetch(url, init);
      var data = null;
      try { data = await resp.json(); } catch (e) { data = null; }
      return { status: resp.status, ok: resp.ok, data: data };
    } catch (e) {
      return { status: 0, ok: false, error: String((e && e.message) || e) };
    }
  };
  var fmt = function (r) {
    return "HTTP " + r.status + "\n" + JSON.stringify(r.data == null ? (r.error || null) : r.data, null, 1);
  };
  sec.querySelector("#rdf-it-route").onclick = async function () {
    var out = document.getElementById("rdf-it-route-out");
    var tier = (document.getElementById("rdf-it-tier") || {}).value || "S2";
    var famRaw = ((document.getElementById("rdf-it-families") || {}).value || "").trim();
    var url = "/api/v1/audit-points/route?tier=" + encodeURIComponent(tier);
    if (famRaw) url += "&families=" + encodeURIComponent(famRaw);
    out.textContent = "查询中…";
    var r = await api(url);
    if (!r.ok) { out.textContent = "点位路由读取失败（HTTP " + r.status + "）：" +
      ((r.data && (r.data.error || r.data.message)) || r.error || "未知错误") + "（失败不当空态）"; return; }
    var list = Array.isArray(r.data) ? r.data : [];
    if (!list.length) { out.textContent = "tier=" + tier + " 没有路由点位（真实空态，不是 0 条假数据）。"; return; }
    out.innerHTML = "HTTP " + r.status + " · tier=" + esc(tier) + " · 命中 " + list.length + " 个点位：<br>" +
      list.slice(0, 12).map(function (p) {
        return "· " + esc(p.id || p.code || "") + " " + esc(p.name || "") +
          "（" + esc(p.category || "") + " / " + esc(p.type_id || "") + "）";
      }).join("<br>") + (list.length > 12 ? "<br>… 共 " + list.length + " 条（截断展示）" : "");
  };
  sec.querySelector("#rdf-it-execute").onclick = async function () {
    var out = document.getElementById("rdf-it-exec-out");
    var pointId = ((document.getElementById("rdf-it-point") || {}).value || "").trim();
    var docText = ((document.getElementById("rdf-it-doc") || {}).value || "");
    if (!pointId) { out.textContent = "请填写点位 ID（调试执行必须指向一个平台点位）。"; return; }
    var ok = false;
    try { ok = confirm("调试执行点位 " + pointId + "？\n\n这是接口调试，不写入正式审核主链；结果原样展示。"); } catch (e) { ok = false; }
    if (!ok) return;
    out.textContent = "执行中…";
    var r = await api("/api/v1/audit-points/execute",
      { method: "POST", body: { point: { id: pointId }, doc_text: docText } });
    if (!r.ok) { out.textContent = "执行失败（HTTP " + r.status + "）：" +
      ((r.data && (r.data.error || r.data.message)) || r.error || "未知错误"); return; }
    out.textContent = fmt(r);
  };
  sec.querySelector("#rdf-it-batch").onclick = async function () {
    var out = document.getElementById("rdf-it-batch-out");
    var rawIds = ((document.getElementById("rdf-it-batch-points") || {}).value || "");
    var ids = rawIds.split(/[,，\s]+/).map(function (x) { return x.trim(); }).filter(Boolean);
    var docText = ((document.getElementById("rdf-it-batch-doc") || {}).value || "");
    if (!ids.length) { out.textContent = "请填写至少 1 个点位 ID（逗号分隔）；批量执行必须显式指定点位。"; return; }
    if (ids.length > 10) { out.textContent = "点位数量 " + ids.length + " 超过服务端预算上限 10；请分批执行（不会静默截断）。"; return; }
    var ok = false;
    try { ok = confirm("批量执行 " + ids.length + " 个点位？\n\n这是接口调试，不写入正式审核主链；逐项结果原样展示，单点失败不会伪造成功。"); } catch (e) { ok = false; }
    if (!ok) return;
    out.textContent = "执行中…（" + ids.length + " 个点位）";
    var r = await api("/api/v1/audit-points/batch",
      { method: "POST", body: { point_ids: ids, doc_text: docText } });
    if (!r.ok) { out.textContent = "批量执行失败（HTTP " + r.status + "）：" +
      ((r.data && (r.data.error || r.data.message)) || r.error || "未知错误") + "（失败不当空态）"; return; }
    var d = r.data || {};
    var sm = (d.summary && d.summary.by_state) || {};
    var lines = [];
    lines.push("HTTP " + r.status + " · 批量动作 " + (d.action || "") + " · 共 " +
      ((d.summary && d.summary.total) || 0) + " 个点位");
    lines.push("状态分布：" + (Object.keys(sm).length
      ? Object.keys(sm).map(function (k) { return k + "=" + sm[k]; }).join(" / ") : "无"));
    lines.push("预算：已用 " + (((d.budget || {}).used_points) || 0) + "/" +
      (((d.budget || {}).max_points) || "") + " 个点位；审计 " +
      ((((d.audit || {}).logged)) ? "已留痕" : "未留痕") + "（" + ((d.audit || {}).action || "") + "）");
    (d.items || []).forEach(function (it) {
      lines.push("· #" + (((it.index || 0) + 1)) + " " + (it.point_id || "(自定义点位)") + " → " +
        (it.ok === false ? ("执行失败：" + (it.error || ""))
          : ((it.state || "未知") + (it.reason ? "（" + it.reason + "）" : "") +
             (it.quote ? " · 引文：" + String(it.quote).slice(0, 40) : ""))));
    });
    out.textContent = lines.join("\n");
  };
}
