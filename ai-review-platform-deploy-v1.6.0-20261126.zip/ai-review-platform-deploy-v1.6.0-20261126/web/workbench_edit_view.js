/* 工作台问题编辑弹窗：从 app.js 拆出；依赖 app.js 的 wbFindings/currentWb/esc/showToast。 */
function openWbEdit(fid) {
  const f = (wbFindings || []).find(x => x.id === fid) || {};
  const old = document.querySelector("#edit-finding-modal"); if (old) old.remove();
  const mask = document.createElement("div"); mask.id = "edit-finding-modal"; mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(600px,calc(100vw - 32px))"><div class="settings-head"><h3>编辑问题</h3><button class="ws-close" data-ef-close>×</button></div><div class="ef-grid"><label><span>严重程度</span><select id="ef-sev" class="field"><option value="critical"${f.severity==="critical"?" selected":""}>严重</option><option value="warning"${f.severity==="warning"?" selected":""}>一般</option><option value="suspected"${f.severity==="suspected"?" selected":""}>提示</option></select></label><label class="wide"><span>标题</span><input id="ef-title" class="field" value="${esc(f.title || "")}"></label><label class="wide"><span>问题描述</span><textarea id="ef-detail" class="field" style="min-height:80px">${esc(f.summary || "")}</textarea></label><label class="wide"><span>整改建议（可选）</span><textarea id="ef-sugg" class="field" style="min-height:60px">${esc(f.suggestion || "")}</textarea></label></div><div id="ef-msg" class="muted" style="font-size:11px;margin-top:6px"></div><div class="actions" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-ef-close>取消</button><button class="btn primary" id="ef-save">保存</button></div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove(); mask.querySelectorAll("[data-ef-close]").forEach(x => x.onclick = close); mask.onclick = e => { if (e.target === mask) close(); };
  mask.querySelector("#ef-save").onclick = async () => {
    const title = mask.querySelector("#ef-title").value.trim();
    if (!title) { mask.querySelector("#ef-msg").textContent = "标题不能为空"; return; }
    const r = await (await fetch(`/api/v1/findings/${encodeURIComponent(fid)}/update`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ severity: mask.querySelector("#ef-sev").value, title, detail: mask.querySelector("#ef-detail").value.trim(), suggestion: mask.querySelector("#ef-sugg").value.trim() }) })).json();
    if (r.error) { mask.querySelector("#ef-msg").textContent = r.error; return; }
    close(); showToast("问题已保存"); await openWorkbench(currentWb);
  };
}
document.querySelectorAll("[data-wb-filter]").forEach(b => b.addEventListener("click", () => {
  wbReviewed = b.dataset.wbFilter;
  if (typeof uxWorkbenchFiltersSave === "function") uxWorkbenchFiltersSave();
  renderWbTab();
  renderWbFindings();
}));
