/* T-177 V1：空间准确率看板（独立文件，不改 app.js / index.html / reviewer.html）
 *
 * 数据来源：GET /api/v1/workspace/accuracy（真实评测结果落库；空态不伪造数字）
 * 口径：条目级 micro-F1 · 文档级 bootstrap 95% CI（n_boot=2000, seed=20261119）
 *       相邻轮配对 ΔF1 + 95% CI + δ_min + BLOCK/WARN/PASS/未检出
 * 挂载：规则进化页（#evo-all 存在时），在 #evo-kpis 之后插入一张卡片；
 *       由 new_rule_view.js 末尾惰性加载，loadEvolutionPage() 时调用 loadAccuracyBoard()。
 */
(function () {
  "use strict";
  if (window.__rpAccuracyBoard) return;
  window.__rpAccuracyBoard = true;

  function _esc(v) {
    return String(v === null || v === undefined ? "" : v)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function _pct(v, digits) {
    if (v === null || v === undefined) return "—";
    var d = (digits === undefined) ? 1 : digits;
    return (Number(v) * 100).toFixed(d) + "%";
  }
  function _ci(ci, digits) {
    if (!ci || ci.length < 2 || ci[0] === null || ci[1] === null) return "—";
    return "[" + _pct(ci[0], digits) + ", " + _pct(ci[1], digits) + "]";
  }
  function _dt(s) { return String(s || "").replace("T", " ").slice(0, 16); }

  function _host() {
    var evoAll = document.querySelector("#evo-all");
    if (!evoAll) return null;
    var box = document.querySelector("#evo-accuracy-board");
    if (box) return box;
    box = document.createElement("div");
    box.id = "evo-accuracy-board";
    box.className = "card";
    box.style.margin = "12px 0";
    var kpis = document.querySelector("#evo-kpis");
    if (kpis && kpis.parentNode) kpis.parentNode.insertBefore(box, kpis.nextSibling);
    else if (evoAll.parentNode) evoAll.parentNode.insertBefore(box, evoAll);
    else return null;
    return box;
  }

  function _loadShell(box, method) {
    box.innerHTML =
      '<div class="settings-head"><div><h3>空间准确率看板</h3>' +
      '<div class="muted" style="font-size:11px;margin-top:3px">' +
      '口径：' + _esc((method && method.metric) || "item-level micro-F1") +
      ' · 文档级 bootstrap 95% CI（n_boot=' + _esc((method && method.n_boot) || 2000) +
      ', seed=' + _esc((method && method.seed) || 20261119) + '）· 空态不伪造数字</div></div>' +
      '<button class="btn" id="accb-refresh">刷新</button></div>' +
      '<div id="accb-body"></div>';
    var btn = box.querySelector("#accb-refresh");
    if (btn) btn.addEventListener("click", function () { loadAccuracyBoard(true); });
  }

  function _svgTrend(rounds) {
    var pts = rounds.filter(function (r) { return r.f1 !== null && r.f1 !== undefined; });
    if (!pts.length) return "";
    var W = 680, H = 210, L = 42, R = 12, T = 14, B = 30;
    var n = pts.length;
    function x(i) { return L + (n <= 1 ? (W - L - R) / 2 : (W - L - R) * i / (n - 1)); }
    function y(v) { return T + (H - T - B) * (1 - Math.max(0, Math.min(1, v))); }
    var line = "", bandTop = "", bandBot = "";
    pts.forEach(function (r, i) {
      var ci = r.f1_ci95 || [null, null];
      var lo = (ci[0] === null || ci[0] === undefined) ? r.f1 : ci[0];
      var hi = (ci[1] === null || ci[1] === undefined) ? r.f1 : ci[1];
      line += (i ? "L" : "M") + x(i).toFixed(1) + " " + y(r.f1).toFixed(1) + " ";
      bandTop += (i ? "L" : "M") + x(i).toFixed(1) + " " + y(hi).toFixed(1) + " ";
      bandBot = "L" + x(i).toFixed(1) + " " + y(lo).toFixed(1) + " " + bandBot;
    });
    var dots = "", labels = "";
    pts.forEach(function (r, i) {
      dots += '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(r.f1).toFixed(1) +
        '" r="3.5" fill="#3370FF"><title>第 ' + _esc(r.round_no) + ' 轮 F1 ' + _pct(r.f1) +
        ' CI ' + _ci(r.f1_ci95) + ' n_docs=' + _esc(r.n_docs) + '</title></circle>';
      labels += '<text x="' + x(i).toFixed(1) + '" y="' + (H - 10) + '" font-size="10" ' +
        'text-anchor="middle" fill="#8F959E">R' + _esc(r.round_no) + '</text>';
    });
    var grid = "";
    [0, 0.25, 0.5, 0.75, 1].forEach(function (g) {
      grid += '<line x1="' + L + '" y1="' + y(g).toFixed(1) + '" x2="' + (W - R) +
        '" y2="' + y(g).toFixed(1) + '" stroke="#EFF0F1" stroke-width="1"/>' +
        '<text x="' + (L - 6) + '" y="' + (y(g) + 3).toFixed(1) + '" font-size="10" ' +
        'text-anchor="end" fill="#8F959E">' + Math.round(g * 100) + '%</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H +
      '" role="img" aria-label="空间准确率趋势（F1 与 95% CI 误差带）">' +
      '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="#fff"/>' + grid +
      '<path d="' + bandTop + bandBot + 'Z" fill="#3370FF" fill-opacity="0.12" stroke="none"/>' +
      '<path d="' + line + '" fill="none" stroke="#3370FF" stroke-width="2"/>' +
      dots + labels + '</svg>';
  }

  function _verdictPill(v) {
    var code = (v && v.code) || "";
    var cls = (code === "block") ? "draft" : ((code === "improve" || code === "pass") ? "published" : "r");
    return '<span class="pill ' + cls + '">' + _esc((v && v.label) || "—") + '</span>';
  }

  function _renderTable(rounds) {
    var rows = rounds.slice(-5).reverse();
    return '<table class="table"><thead><tr><th>轮次</th><th>时间</th><th class="num">n_docs</th>' +
      '<th class="num">规则数</th><th class="num">F1 [95% CI]</th><th class="num">ΔF1 [95% CI]</th>' +
      '<th class="num">δ_min</th><th>判定</th></tr></thead><tbody>' +
      rows.map(function (r) {
        var d = r.delta || {};
        return '<tr><td>R' + _esc(r.round_no) + '<div class="muted" style="font-size:11px">' +
          _esc(r.label || "") + '</div></td><td class="muted">' + _esc(_dt(r.created_at)) + '</td>' +
          '<td class="num">' + _esc(r.n_docs) + '</td><td class="num">' + _esc(r.rule_count) + '</td>' +
          '<td class="num"><b>' + _pct(r.f1) + '</b> ' + _ci(r.f1_ci95) + '</td>' +
          '<td class="num">' + (d.available ? (_pct(d.delta_f1) + ' ' + _ci(d.delta_f1_ci95)) : "—") +
          (d.available ? '' : '<div class="muted" style="font-size:11px">' + _esc(d.reason || "首轮") + '</div>') + '</td>' +
          '<td class="num">' + (d.delta_min !== null && d.delta_min !== undefined ? _pct(d.delta_min) : "—") + '</td>' +
          '<td>' + _verdictPill(d.verdict) + '</td></tr>';
      }).join("") + '</tbody></table>';
  }

  function _renderColdstart(cs) {
    if (!cs || cs.empty) {
      return '<div class="muted" style="font-size:12px;margin-top:10px">' +
        _esc((cs && cs.empty_reason) || "暂无冷启动建议（还没有反向反馈）") + '</div>';
    }
    return '<div style="margin-top:14px"><b>冷启动 playbook：建议先补这 ' +
      _esc((cs.suggestions || []).length) + ' 条规则</b>' +
      '<div class="muted" style="font-size:11px;margin:3px 0 6px">' + _esc(cs.method || "") + '</div>' +
      '<table class="table"><thead><tr><th>#</th><th>规则/点位</th><th class="num">漏报</th>' +
      '<th class="num">误报</th><th class="num">误报率</th><th>建议</th></tr></thead><tbody>' +
      (cs.suggestions || []).map(function (s) {
        return '<tr><td>' + _esc(s.rank) + '</td><td class="muted">' + _esc(s.rule_code) + '</td>' +
          '<td class="num">' + _esc(s.miss) + '</td><td class="num">' + _esc(s.false_positive) + '</td>' +
          '<td class="num">' + _pct(s.false_positive_rate, 0) + '</td><td>' + _esc(s.advice) + '</td></tr>';
      }).join("") + '</tbody></table>' +
      '<div class="muted" style="font-size:11px;margin-top:4px">' + _esc(cs.next_step || "") + '</div></div>';
  }

  function _renderBoard(box, data, coldstart) {
    var body = box.querySelector("#accb-body");
    if (!body) return;
    if (!data || data.ok === false) {
      body.innerHTML = '<div class="empty">看板不可用：' +
        _esc((data && data.error) || "接口错误") + '</div>' + _renderColdstart(coldstart);
      return;
    }
    if (data.empty) {
      body.innerHTML = '<div class="empty"><div><b>还没有接入评测结果</b></div>' +
        '<div class="muted" style="font-size:12px;margin-top:6px">' + _esc(data.empty_reason || "") + '</div>' +
        '<div class="muted" style="font-size:11px;margin-top:6px">接入：POST /api/v1/workspace/accuracy/rounds ' +
        '（逐文档 tp/fp/fn）或 <code>./rp evolution accuracy-record --docs \'[...]\'</code></div></div>' +
        _renderColdstart(coldstart);
      return;
    }
    var latest = data.latest || {};
    var added = (data.rounds || []).length ? (data.rounds[data.rounds.length - 1].rules_added || []) : [];
    body.innerHTML =
      '<div class="kpis" style="margin:8px 0">' +
      '<div class="kpi"><b style="color:#3370FF">' + _pct(latest.f1) + '</b><span>最新 F1 [95% CI ' +
      _ci(latest.f1_ci95) + ']</span></div>' +
      '<div class="kpi"><b style="color:#00B578">' + _esc(latest.n_docs) + '</b><span>最新一轮 n_docs</span></div>' +
      '<div class="kpi"><b style="color:#FF8800">' + _esc(latest.rule_count) + '</b><span>生效规则数</span></div>' +
      '<div class="kpi"><b>' + _esc((data.rounds || []).length) + '</b><span>已记录轮次</span></div></div>' +
      _svgTrend(data.rounds || []) + _renderTable(data.rounds || []) +
      '<div class="muted" style="font-size:11px;margin-top:6px">本轮新增生效规则：' +
      (added.length ? added.map(function (x) { return _esc(x.code || x.name || ""); }).join("、") +
        '（' + added.length + ' 条）' : "无") +
      '。ΔF1 是整轮信号，不是单规则因果归因（单规则归因需 A/B）。</div>' +
      _renderColdstart(coldstart);
  }

  function _fetchJson(url, opts) {
    return fetch(url, opts || {}).then(function (r) {
      return r.json().then(function (j) { return { status: r.status, body: j }; })
        .catch(function () { return { status: r.status, body: {} }; });
    });
  }

  function loadAccuracyBoard(force) {
    var box = _host();
    if (!box) return;
    if (box.dataset.loaded === "1" && !force) return;
    box.dataset.loaded = "1";
    box.innerHTML = '<div class="muted" style="font-size:12px">正在加载空间准确率看板…</div>';
    _fetchJson("/api/v1/workspace/accuracy?limit=20").then(function (r) {
      var data = r.body || {};
      if (r.status === 403) { box.innerHTML = ""; return; }  // 系统管理员等角色：不渲染
      _loadShell(box, data.method || {});
      if (!data.ok && r.status !== 200) {
        _renderBoard(box, { ok: false, error: data.error || ("HTTP " + r.status) }, null);
        return;
      }
      _fetchJson("/api/v1/workspace/accuracy/coldstart?limit=5").then(function (c) {
        _renderBoard(box, data, (c.body && c.body.ok !== false) ? c.body : null);
      });
    }).catch(function () {
      box.innerHTML = '<div class="empty">看板加载失败（网络错误）</div>';
    });
  }

  window.loadAccuracyBoard = loadAccuracyBoard;
})();
