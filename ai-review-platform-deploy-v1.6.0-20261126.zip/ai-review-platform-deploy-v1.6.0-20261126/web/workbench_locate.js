/* 工作台原文定位：从 app.js 拆出；依赖 wbFindings/wbPreviewMode/currentWb 等全局。
 *
 * L143/T-③（2026-11-25，按 L132 报告 Top2 修复）：
 *   ① 坐标解析：anchor 结构化 row/col 缺失时解析 locator 里的 ``Sheet!B15``
 *      （产品库 200 条 cell locator 中 185 条缺 row/col，旧实现全部退化成全文检索）；
 *      解析 locator 里的 ``第 N 页``；page 字段缺失也能跳页。
 *   ② 字符区间消费：finding 的 verbatim_quote/char_start/char_end（L71 回填产物）
 *      用于精确选择引文出现位置（多处分歧时按区间比例选），并在提示里显示字符区间。
 *   ③ 不静默：既无坐标也无逐字引文时，提示里必须给出原因（锚点强度/回填状态）+
 *      原文摘录，不能只回一句“没有可定位的片段”。
 * 纯函数（wbLocParseCell/wbLocParsePage/wbLocSpan/wbLocReadable/wbLocExplain/
 * wbLocFallbackMessage）不依赖 DOM，便于 Node 侧断言；locateFinding 仍为唯一入口。
 */
function wbLocParseCell(locator) {
  const s = String(locator || "").trim();
  const m = /([^!！\n\r\t]{1,80}?)\s*[!！]\s*([A-Za-z]{1,3})\s*(\d{1,7})/.exec(s);
  if (!m) return null;
  const sheet = String(m[1] || "").trim();
  const col = String(m[2] || "").toUpperCase();
  const row = parseInt(m[3], 10);
  if (!sheet || !col || !row) return null;
  return { sheet: sheet, row: row, col: col, cell: sheet + "!" + col + row };
}
function wbLocParsePage(locator) {
  const m = /第\s*(\d{1,6})\s*页/.exec(String(locator || ""));
  const n = m ? parseInt(m[1], 10) : 0;
  return n > 0 ? n : 0;
}
function wbLocSpan(f) {
  const src = (f && f.evidence) || [];
  let cs = Number(f && f.char_start), ce = Number(f && f.char_end);
  if (!(cs >= 0 && ce > cs)) {
    for (const a of src) {
      if (!a) continue;
      cs = Number(a.char_start); ce = Number(a.char_end);
      if (cs >= 0 && ce > cs) break;
    }
  }
  return (cs >= 0 && ce > cs) ? [cs, ce] : null;
}
/* 证据级字符区间：优先后端 evidence[].char_start/char_end（provenance 透出），
 * 缺失时回退 finding 级 wbLocSpan（L71 回填产物）。纯函数，不读 DOM。 */
function wbLocAnchorSpan(anchor, finding) {
  const a = anchor || {};
  const cs = Number(a.char_start), ce = Number(a.char_end);
  if (cs >= 0 && ce > cs) return [cs, ce];
  return wbLocSpan(finding);
}
/* 把一条证据/finding 归一成可读定位；纯函数，不读 DOM。
 * L148/T-③：除 locator 文本解析外，兼容后端已透出的结构化字段
 * （locator_kind / text_locator / char_start,char_end / has_char_span / navigable /
 *  missing），不新增 UI 结构；后端字段缺失时全部退回 L143 的文本解析口径。 */
function wbLocReadable(anchor, finding) {
  const a = anchor || {}, f = finding || {};
  const kind = String(a.locator_kind || "").trim();
  const loc = String(a.locator || "").trim();
  const textLoc = String(a.text_locator || "").trim();
  const cell = wbLocParseCell(loc) || wbLocParseCell(textLoc);
  const page = Number(a.page) || wbLocParsePage(loc) || wbLocParsePage(textLoc);
  const sheet = String(a.sheet || (cell && cell.sheet) || "").trim();
  const row = Number(a.row) || (cell && cell.row) || 0;
  const col = String(a.col || (cell && cell.col) || "").trim().toUpperCase();
  const quote = String(a.quote || a.excerpt || f.verbatim_quote || f.quote || "").trim();
  const span = wbLocAnchorSpan(a, f);
  let mode = "none";
  if (sheet && row && col) mode = "cell";
  else if (cell) mode = "cell";
  else if (kind === "cell" && (sheet || row || col)) mode = "cell";
  else if (page) mode = "page";
  else if (quote && span) mode = "text";
  else if (kind === "text_span" && span) mode = "text";
  else if (quote) mode = "quote";
  else if (kind === "manual" || /人工/.test(loc)) mode = "manual";
  const cellName = (sheet && row && col) ? (sheet + "!" + col + row) : (cell ? cell.cell : "");
  const strength = String(a.anchor_strength || f.anchor_strength || "none");
  const backfill = String(f.backfill_status || a.backfill_status || "");
  let display = loc || textLoc || cellName || "";
  if (mode === "text" && span) {
    if (textLoc && /字符/.test(textLoc)) display = (loc && textLoc.indexOf(loc) < 0 ? loc + " · " : "") + textLoc;
    else display = (loc || "原文") + " · 字符" + (span[0] + 1) + "-" + span[1];
  } else if (mode === "cell" && cellName && !loc) {
    display = cellName;
  }
  // 可跳转 = 有真实坐标（cell/page/字符区间）；仅逐字引文可全文检索但不算坐标。
  // 后端显式 navigable=true 时也认（API 已按页/单元格/字符区间判定过）。
  const backendNav = (a.navigable === true || String(a.navigable) === "true");
  const missing = Array.isArray(a.missing) ? a.missing.slice(0) : [];
  const explain = String(a.explain || "");
  const navigable = (mode === "cell" || mode === "page" || mode === "text")
    || (backendNav && !!(cellName || page || span || quote));
  return { mode: mode, cell: cellName, sheet: sheet, row: row, col: col,
           page: page, quote: quote, span: span, locator: loc || textLoc,
           text_locator: textLoc, strength: strength, backfill_status: backfill,
           display: display, navigable: navigable, backend_navigable: backendNav,
           has_char_span: (a.has_char_span === true || String(a.has_char_span) === "true") || !!span,
           missing: missing, explain: explain };
}
/* finding 级定位解释：先选“能跳转/能高亮”的证据，选不到时保留可读原因。 */
function wbLocExplain(f) {
  const evs = ((f && f.evidence) || []).filter(function (a) { return !!a; });
  let best = null;
  for (const a of evs) {
    const r = wbLocReadable(a, f);
    if (!best) { best = r; continue; }
    const rank = function (x) {
      const base = x.mode === "cell" ? 4 : x.mode === "page" ? 3
        : x.mode === "text" ? 2 : x.mode === "quote" ? 1 : 0;
      return base + (x.navigable ? 0.5 : 0);
    };
    if (rank(r) > rank(best)) best = r;
  }
  if (!best) best = wbLocReadable({}, f);
  best.quote = best.quote || String((f && f.verbatim_quote) || (f && f.quote) || "").trim();
  best.span = best.span || wbLocSpan(f);
  if ((!best.missing || !best.missing.length) && Array.isArray(f && f.missing)) {
    best.missing = f.missing.slice(0);
  }
  if (!best.display) best.display = String((f && f.title) || "").slice(0, 40);
  return best;
}
/* 无坐标/无引文时的可读原因（“不静默”契约：原因 + 原文摘录）。 */
function wbLocFallbackMessage(f, rb) {
  const r = rb || wbLocExplain(f);
  const parts = [];
  parts.push("无法自动定位：该问题没有可定位的坐标");
  if (r.mode === "quote") {
    parts.push("（只有逐字引文，没有页/单元格/字符区间）");
  } else if (!r.quote) {
    parts.push("（锚点未记录逐字引文）");
  }
  const reason = [];
  if (r.strength && r.strength !== "none") reason.push("锚点强度=" + r.strength);
  if (r.backfill_status) reason.push("回填状态=" + r.backfill_status);
  if (r.locator) reason.push("定位字段=" + r.locator);
  if (r.missing && r.missing.length) reason.push("缺失项=" + r.missing.join("/"));
  if (r.explain) reason.push(r.explain);
  if (reason.length) parts.push("；" + reason.join("，"));
  if (r.quote) parts.push("。原文摘录：" + r.quote.slice(0, 60));
  else parts.push("。可点「查看证据链」核对规则版本与判定来源，或人工回原文核对。");
  return parts.join("");
}

/* ---- DOM 侧辅助：清历史高亮 / 单元格命中 / 引文精确定位 ---- */
function _wbLocClear(doc) {
  doc.querySelectorAll("td.focus").forEach(function (td) { td.classList.remove("focus"); });
  doc.querySelectorAll("span.wb-loc-highlight").forEach(function (sp) {
    sp.replaceWith(doc.createTextNode(sp.textContent || ""));
  });
  doc.querySelectorAll(".wb-loc-highlight").forEach(function (el) { el.classList.remove("wb-loc-highlight"); });
  doc.querySelectorAll("mark.wb-loc-focus").forEach(function (m) {
    m.replaceWith(doc.createTextNode(m.textContent || ""));
  });
}
function _wbLocFindCell(doc, rb) {
  if (!rb || !rb.cell) return null;
  try {
    const hit = doc.querySelector('td[data-rc="' + CSS.escape(rb.cell) + '"]');
    if (hit) return hit;
  } catch (e) { /* CSS.escape 不可用时走遍历 */ }
  const sheet = String(rb.sheet || "").trim().toLowerCase();
  const row = String(rb.row || ""), col = String(rb.col || "").toUpperCase();
  let loose = null;
  const tds = doc.querySelectorAll("td[data-rc]");
  for (const td of tds) {
    const parts = String(td.getAttribute("data-rc") || "").split("|");
    if (parts.length < 3) continue;
    if (String(parts[1]) !== row || String(parts[2]).toUpperCase() !== col) continue;
    const s = String(parts[0] || "").trim().toLowerCase();
    if (sheet && s === sheet) return td;
    if (!loose) loose = td;
  }
  return loose;
}
function _wbLocTextNodes(doc) {
  const out = [];
  const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = walker.nextNode())) out.push(n);
  return out;
}
function _wbLocOccurrences(doc, needle) {
  const occ = [];
  let abs = 0;
  _wbLocTextNodes(doc).forEach(function (node) {
    const val = node.nodeValue || "";
    let idx = val.indexOf(needle);
    while (idx >= 0) {
      occ.push({ node: node, idx: idx, abs: abs + idx });
      idx = val.indexOf(needle, idx + 1);
    }
    abs += val.length;
  });
  return occ;
}
/* 用字符区间在“多处出现”的引文里选目标位置：按原文长度比例映射到 DOM 文本。 */
function _wbLocPickOccurrence(doc, occ, span) {
  if (!occ.length) return null;
  if (occ.length === 1 || !span) return occ[0];
  let docLen = 0;
  const meta = doc.querySelector(".doc-meta");
  if (meta) {
    const m = /(\d+)\s*字/.exec(meta.textContent || "");
    if (m) docLen = parseInt(m[1], 10) || 0;
  }
  const total = _wbLocTextNodes(doc).reduce(function (s, n) { return s + (n.nodeValue || "").length; }, 0);
  if (!docLen || !total) return occ[0];
  const target = (span[0] / docLen) * total;
  let best = occ[0], bestD = Math.abs(occ[0].abs - target);
  for (const o of occ) {
    const d = Math.abs(o.abs - target);
    if (d < bestD) { best = o; bestD = d; }
  }
  return best;
}
function _wbLocBlockOf(node, doc) {
  let block = node.parentElement;
  while (block && block !== doc.body && !/^(P|H1|H2|H3|H4|LI|TD|TH|BLOCKQUOTE)$/.test(block.tagName)) {
    block = block.parentElement;
  }
  if (!block || block === doc.body) block = node.parentElement;
  if (block && block !== doc.body && /^(DIV)$/.test(block.tagName)) block = null;
  return block;
}
/* 在解析文本/单元格里精确高亮引文；返回是否命中。 */
function _wbLocHighlightQuote(doc, quote, span) {
  const q = String(quote || "").trim();
  if (!q) return false;
  const candidates = q.split(/\n+/).map(function (x) { return x.trim(); })
    .filter(function (x) { return x.length >= 4; });
  if (!candidates.length) candidates.push(q.slice(0, 24));
  for (const line of candidates) {
    const occ = _wbLocOccurrences(doc, line);
    const hit = _wbLocPickOccurrence(doc, occ, span);
    if (!hit) continue;
    const block = _wbLocBlockOf(hit.node, doc);
    if (!block) continue;
    const _big = block.tagName === "P" && ((block.innerText || "").length > 500 || block.querySelector("br"));
    if (_big) {
      try {
        const range = doc.createRange();
        range.setStart(hit.node, hit.idx);
        range.setEnd(hit.node, hit.idx + line.length);
        const sp = doc.createElement("span");
        sp.className = "wb-loc-highlight";
        sp.style.cssText = "background:#FFF3B0;color:inherit;padding:0;border:0;border-radius:0;";
        range.surroundContents(sp);
        sp.scrollIntoView({ block: "center", behavior: "smooth" });
        return true;
      } catch (e) { /* 跨节点时退化为块级高亮 */ }
    }
    block.classList.add("wb-loc-highlight");
    block.scrollIntoView({ block: "center", behavior: "smooth" });
    return true;
  }
  // 全文检索兜底：单行引文可能跨 <br>/节点，用前 36 字再试一次
  const short = q.replace(/\s+/g, " ").slice(0, 36);
  if (short.length >= 4 && short !== q) {
    const occ2 = _wbLocOccurrences(doc, short);
    const hit2 = _wbLocPickOccurrence(doc, occ2, span);
    if (hit2) {
      const block2 = _wbLocBlockOf(hit2.node, doc);
      if (block2) {
        block2.classList.add("wb-loc-highlight");
        block2.scrollIntoView({ block: "center", behavior: "smooth" });
        return true;
      }
    }
  }
  return false;
}
function _wbLocSpanText(span) {
  return span ? ("字符" + (span[0] + 1) + "-" + span[1]) : "";
}

function locateFinding(fid) {
  const f = wbFindings.find(x => x.id === fid);
  if (!f) return;
  const rb = wbLocExplain(f);
  const frame = $("#wb-doc-frame");
  // 原始 PDF 页图模式：由自定义页图视图跳页（不再改 iframe.src，原生插件已移除）
  if (wbPreviewMode === "file") {
    const page = rb.page || 0;
    if (page && typeof wbPdfGotoPage === "function" && wbPdfGotoPage(page)) {
      showToast("已跳到原始 PDF 第 " + page + " 页；精确文字高亮请切换“解析文本”", "ok");
      return;
    }
    if (typeof wbPdfGotoPage === "function" && wbPdfGotoPage(1)) {
      showToast("该问题没有记录页码，已回到原始 PDF 第 1 页；精确文字高亮请切换“解析文本”", "ok");
      return;
    }
    showToast("原始 PDF 视图未就绪，无法跳页；请稍后重试或切换“解析文本”", "err");
    return;
  }
  const doc = frame && frame.contentDocument;
  if (!doc) { alert("预览未就绪"); return; }
  _wbLocClear(doc);
  // ① Excel：按解析出的 Sheet!Cell 高亮单元格（locator 可解析即可，不再要求 row/col 齐备）
  if (rb.mode === "cell") {
    const hit = _wbLocFindCell(doc, rb);
    if (hit) {
      hit.classList.add("focus");
      hit.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
      showToast("已定位到 " + rb.cell + (rb.span ? "（" + _wbLocSpanText(rb.span) + "）" : ""), "ok");
      return;
    }
  }
  // ② 解析文本：按逐字引文 + 字符区间精确高亮（有引文时绝不改预览页码）
  const quote = rb.quote || String(f.quote || "").trim();
  if (quote) {
    if (_wbLocHighlightQuote(doc, quote, rb.span)) {
      const extra = rb.span ? "（" + _wbLocSpanText(rb.span) + "）" : "";
      showToast("已定位到原文引文" + extra + (rb.page ? " · 第" + rb.page + "页" : ""), "ok");
      return;
    }
    // ③ 引文不在当前预览：不静默，显示原因（含定位字段/锚点强度）+ 原文摘录
    showToast(wbLocFallbackMessage(f, rb), "err");
    return;
  }
  // ④ 无引文、只有页坐标：解析文本视图按页分页，跳到对应页并说明原因
  if (rb.page && typeof _wbParseGoto === "function") {
    try {
      _wbParseGoto(rb.page);
      showToast("已跳到解析文本第 " + rb.page + " 页；该问题没有可定位的逐字引文（仅页码坐标）", "ok");
      return;
    } catch (e) { /* 页码越界时走统一失败提示 */ }
  }
  // ⑤ 不静默：显示原文 + 原因（锚点强度/回填状态/定位字段）
  showToast(wbLocFallbackMessage(f, rb), "err");
}
