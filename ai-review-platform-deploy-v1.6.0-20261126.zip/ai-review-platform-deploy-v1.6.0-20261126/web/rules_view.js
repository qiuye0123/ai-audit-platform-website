/* 规则库 + 草稿箱视图（T-109 新口径，依赖 app.js 的全局 esc/rules/CATEGORY 等）。
 *
 * 产品口径（2026-11-18 用户确认，替代旧审批流）：
 *   1. 规则不需要审批：draft 直接「发布生效」；没有提交审批/批准按钮。
 *   2. 规则库只展示「已发布/生效」规则；草稿在独立菜单「草稿箱」；旧 pending/approved
 *      是旧审批流程遗留状态，在规则库按「历史」标记，只读。
 *   3. 决策表不再单独 tab：作为规则形式（单条规则/决策表组合/审核库点位）在规则库筛选，
 *      行内 badge 标识；决策表只能从行内「打开决策表」/新建规则选择决策表进入。
 *   4. 草稿箱：来源/负责人/最近编辑/完整度/冲突/可发布；草稿发布后若检测到冲突，
 *      提示并跳转冲突提醒，不阻断发布、不自动回滚。
 *   5. 命中/健康度按后端新字段（health_state/health_label/hit_count_display/rule_hits）展示，
 *      无法归因显示「未归因」，不伪造 0。
 */

const RULE_FORM_LABEL = { single: "单条规则", decision: "决策表组合", library: "审核库点位" };
const RULE_FORM_PILL = { single: "draft", decision: "published", library: "r" };
const RULE_STATUS_LABEL = {
  draft: "草稿", pending: "待审批（旧流程·历史）", approved: "已批准（旧流程·历史）",
  published: "已发布", archived: "已下线",
};
const LEGACY_STATUS = ["pending", "approved"];
/* 来源中文标签（后端 source 代码 → 展示文案；未知来源保留原值，不伪造） */
const RULE_SOURCE_LABEL = {
  manual: "手工填写", conversation: "对话生成", rule_mining: "规则挖掘",
  rsi_feedback: "进化沉淀", sedimented: "进化沉淀", decision_table_autobind: "决策表包装规则",
  sop: "文件拆解", enterprise_standard: "文件拆解", historical_audit: "文件拆解",
  rule_export: "文件拆解", document: "文件拆解", document_decompose: "文件拆解",
  "内置规则": "内置规则",
};
function ruleSourceLabel(r) {
  if (!r) return "—";
  const raw = String(r.source || "");
  if (r.source_label && r.source_label !== raw && r.source_label !== "") return r.source_label;
  return RULE_SOURCE_LABEL[raw] || raw || "—";
}

/* 后端列表行（rule_library.stats）语义归一 */
function ruleFormOf(r) {
  if (!r) return "single";
  if (r.kind === "library") return "library";
  if (r.kind === "decision") return "decision";
  return "single";
}
function isLegacyRule(r) { return !!r && LEGACY_STATUS.indexOf(String(r.status || "")) >= 0; }
function isDraftRule(r) { return !!r && String(r.status || "") === "draft"; }
function isEffectiveRule(r) {
  if (!r) return false;
  if (r.kind === "library") return true;                 // 审核库点位本身已发布
  if (r.kind === "decision") return String(r.status || "") === "published";
  if (r.effective_status === "published") return true;
  // 兼容旧后端行：无 effective_status 字段时按 published 状态判断，不把 draft 当生效
  return String(r.status || "") === "published";
}
function ruleStatusLabel(r) {
  if (!r) return "—";
  if (r.status_label === "已发布（生效中）") return "已发布（生效中）";
  return RULE_STATUS_LABEL[String(r.status || "")] || r.status_label || r.status || "—";
}
function ruleEffectiveVersion(r) {
  if (!r) return "";
  if (r.kind === "library") return r.version || "库";
  return String(r.effective_version || (r.kind === "decision" ? r.version : "") || "");
}
function fmtTime(v) {
  const s = String(v || "");
  if (!s) return "—";
  return s.length >= 16 ? s.slice(0, 16).replace("T", " ") : s;
}

let ruleHomeStats = null;      // {counts, hits}：规则库/草稿箱 KPI 与命中归因同一后端口径
let draftConflictMap = {};     // rule code -> {count, maxSeverity, ids}（仅 open 冲突）

/* ===================== 规则库 ===================== */
async function loadRules() {
  const listHost = document.querySelector("#rule-list");
  if (listHost) uxSetLoading("#rule-list", "正在加载规则…", 4);
  // 分组标签与规则列表并行加载：分组读取失败不阻断规则列表，只在分组条上给可读错误。
  await Promise.all([loadRuleHomeStats(), loadRuleTags()]);
  const _tagId = String((typeof RULE_TAG_STATE !== "undefined" && RULE_TAG_STATE.ruleFilter) || "");
  const _url = "/api/v1/rules" + (_tagId ? "?tag_id=" + encodeURIComponent(_tagId) : "");
  let _rr = null, _status = 0;
  try {
    const _resp = await fetch(_url);
    _status = _resp.status;
    _rr = await _resp.json();
  } catch (e) {
    if (listHost) uxSetEmpty("#rule-list", { title: "规则加载失败", desc: "请检查网络后重试；不会影响已保存的规则。", action: { label: "重新加载", action: "reset:rules" } });
    return;
  }
  if (_status === 401) {
    if (listHost) uxSetEmpty("#rule-list", { title: "登录已过期", desc: "登录会话已失效，请刷新页面重新登录后查看规则。", action: { label: "刷新页面", action: "reload:page" } });
    return;
  }
  // 未知/跨空间分组：后端 404 不泄露存在性；前端给可读提示并切回全部，不让页面卡在空列表。
  if (_status === 404 && _tagId) {
    const _st = RULE_TAG_STATE;
    _st.ruleFilter = "";
    _st.filterSig = "";
    if (typeof showToast === "function") showToast("该分组不存在或不在当前工作空间（404），已切回「全部」", "err");
    await loadRuleTags(true);
    return loadRules();
  }
  if (_rr && _rr.error) {
    if (listHost) uxSetEmpty("#rule-list", { title: "规则加载失败", desc: String(_rr.error), action: { label: "重新加载", action: "reset:rules" } });
    return;
  }
  // 兼容分页信封/错误对象，页面不能把对象当数组遍历
  rules = Array.isArray(_rr) ? _rr : ((_rr && (_rr.items || _rr.rules)) || []);
  updateDraftMenuBadge(rules.filter(isDraftRule).length);
  populateRuleTypeFilter();
  // 筛选回显：统一 localStorage；规则库默认「生效规则」口径，不因历史筛选值把草稿带进来。
  uxFiltersRestoreOnce("rules");
  const stSel = document.querySelector("#rule-status");
  if (stSel && !stSel.value) stSel.value = "effective";
  renderRuleTagBar("rules");
  renderKPIs(); renderList(); loadRuleLinkage();
}

async function loadRuleHomeStats() {
  try {
    const r = await fetch("/api/v1/home");
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    ruleHomeStats = { counts: d.rule_counts || {}, hits: d.rule_hits || (d.rule_counts || {}).hits || {} };
  } catch (e) {
    ruleHomeStats = null;   // 取不到就显示「—」，不用 0 冒充
  }
}

function populateRuleTypeFilter() {
  const sel = document.querySelector("#rule-cat");
  if (!sel || sel.dataset.ready === "1") return;
  const seen = new Set();
  (rules || []).forEach(r => { if (r.category) seen.add(r.category); });
  const labels = { ...CATEGORY, ...Object.fromEntries(Object.entries(RULE_TEMPLATES).map(([k, v]) => [k, v.label])) };
  sel.innerHTML = '<option value="">全部类型</option>' + [...seen].sort().map(k => `<option value="${esc(k)}">${esc(labels[k] || k)}</option>`).join("");
  sel.dataset.ready = "1";
}

function renderKPIs() {
  const host = document.querySelector("#kpis");
  if (!host || !Array.isArray(rules)) return;
  const counts = (ruleHomeStats && ruleHomeStats.counts) || {};
  const hits = (ruleHomeStats && ruleHomeStats.hits) || null;
  const nonDraft = rules.filter(r => !isDraftRule(r));
  const effective = nonDraft.filter(isEffectiveRule);
  // E-12（DuMate 20261118）：规则库 KPI 与列表必须是同一分母。
  // 旧实现「规则行（客户+内置）」直接取后端口径 counts.rule_rows（含草稿：16 published + 2 draft = 18），
  // 而列表只展示「生效规则行 + 审核库点位」（16 + 319 = 335），同页出现 18 / 335 两个分母；
  // 2 条草稿既不在列表、也无法从 KPI 看出应去草稿箱（草稿名在规则库搜不到）。
  // 现口径：生效规则行（= 列表里的 DB 规则行，不含草稿）+ 审核库点位 + 决策表 = 规则库列表条数；
  // 草稿单独一个 KPI（可点进草稿箱），KPI 下方给一行对账说明，保证同页可对账。
  const draftCount = rules.filter(isDraftRule).length;
  const effDbRows = effective.filter(r => ruleFormOf(r) === "single").length;
  const effLibraryRows = effective.filter(r => ruleFormOf(r) === "library").length;
  const effDecisionRows = effective.filter(r => ruleFormOf(r) === "decision").length;
  const _n = (v, fallback) => (v == null || v === "" ? (fallback == null ? "—" : String(fallback)) : String(v));
  const _num = (v) => (v == null || v === "" || isNaN(Number(v)) ? 0 : Number(v));
  const libPoints = counts.library_points
    ? (counts.library_points.merged_points != null ? counts.library_points.merged_points : counts.library_points.merged)
    : null;
  // 「审核库点位」KPI 必须与列表同一分母：stats() 会把与规则 code 重名的点位去重
  // （seen_codes），所以列表里的点位行数 = effLibraryRows，而 merged_points=319 是
  // 点位库总量（含被规则行覆盖的那几条）。旧 KPI 用 merged_points → 多算 5–6 条，
  // 这正是「逐项合计 ≠ 列表条数」的另一个根因（评审实测 344 vs 339 / 344 vs 338）。
  // 有列表数组时用列表实际行数；仅当列表不可用（数组缺失）才回退后端点位总量。
  const libPointsShown = (rules.length || libPoints == null) ? effLibraryRows : libPoints;
  // P2-B3-05（评审 B3-G8）：「逐项合计 ≠ 列表条数」的根因是 KPI 分母与列表分母不同源 ——
  // counts.decision_tables 含**草稿**决策表，而默认「生效」列表只含 published 决策表；
  // 同时 counts.rule_rows 含草稿规则。旧代码把两套分母相加，于是页面自己打印「≠」。
  // 修复口径：KPI 三项一律取「当前列表数组的实际行」（与 renderList 同一份数据、
  // 同一 isEffectiveRule 过滤），thus 逐项合计恒等于列表条数；后端口径只作为
  // 「含草稿总量」对照显示，不再参与相加。
  const decisionTables = rules.length ? effDecisionRows : _num(counts.decision_tables);
  // counts.rule_rows 含草稿：rules 数组缺失时用「rule_rows - 草稿数」兜底，仍与列表同分母。
  const effectiveRows = rules.length ? effDbRows : Math.max(0, _num(counts.rule_rows) - draftCount);
  const listTotal = effective.length;
  const accounted = _num(effectiveRows) + _num(libPointsShown) + _num(decisionTables);
  // 后端 view_total（含草稿的完整视图条目数）：只作对照，不进用户可见的四则运算。
  const backendViewTotal = counts.view_total != null ? _num(counts.view_total) : null;
  const executedVersions = counts.executable_versions != null ? counts.executable_versions : effectiveRows;
  const hitAttributed = hits && hits.attributed != null ? hits.attributed : null;
  const hitUnattributed = hits && hits.unattributed != null ? hits.unattributed : null;
  const hitCard = (hitAttributed == null && hitUnattributed == null)
    ? `<div class="kpi"><b>—</b><span>命中归因（统计不可用）</span></div>`
    : `<div class="kpi"><b>${esc(String(hitAttributed || 0))} / ${esc(String(hitUnattributed || 0))}</b><span>命中 已归因 / 未归因</span></div>`;
  if (accounted !== _num(listTotal)) {
    // 不把口径差异打印给业务用户（对外可见的自认缺陷）：只在控制台给研发留诊断线索。
    console.error("[规则库KPI] 对账不一致：逐项合计", accounted, "≠ 列表", listTotal, "，请检查后端计数口径。");
  }
  const reconcileNote = `<div class="muted" id="rule-kpi-reconcile" data-kpi-rows="${esc(String(effectiveRows))}"`
    + ` data-kpi-points="${esc(String(libPointsShown))}" data-kpi-decisions="${esc(String(decisionTables))}"`
    + ` data-kpi-drafts="${esc(String(draftCount))}" data-list-total="${esc(String(listTotal))}"`
    + ` data-kpi-backend-view-total="${esc(String(backendViewTotal == null ? "" : backendViewTotal))}"`
    + ` style="font-size:12px;padding:2px 2px 8px">规则库列表共 ${esc(String(listTotal))} 条（默认生效口径）=`
    + ` 生效规则行 ${esc(String(effectiveRows))} + 审核库点位 ${esc(String(libPointsShown))} + 决策表 ${esc(String(decisionTables))}；`
    + `草稿 ${esc(String(draftCount))} 条不计入列表（在「草稿箱」）。对账一致。`
    + `</div>`;
  host.innerHTML = `
    <div class="kpi"><b>${esc(_n(executedVersions, effectiveRows))}</b><span>生效规则版本</span></div>
    <div class="kpi"><b>${esc(String(effectiveRows))}</b><span>生效规则行（客户+内置）</span></div>
    <div class="kpi" data-rule-go="drafts" role="button" tabindex="0" title="草稿在「草稿箱」管理，不计入规则库列表；点击查看" style="cursor:pointer"><b>${esc(String(draftCount))}</b><span>草稿（在草稿箱）</span></div>
    <div class="kpi"><b>${esc(_n(libPointsShown, effLibraryRows))}</b><span>审核库点位</span></div>
    <div class="kpi"><b>${esc(_n(decisionTables, effDecisionRows))}</b><span>决策表</span></div>
    ${hitCard}
  ` + reconcileNote + (hitUnattributed != null
    ? `<div class="muted" id="rule-hits-note" style="font-size:12px;padding:2px 2px 8px">命中归因：已归因 ${esc(String(hitAttributed || 0))} 条 / 未归因 ${esc(String(hitUnattributed || 0))} 条（未归因不按 0 计，行内健康度显示「未归因（不可计算）」）。</div>`
    : `<div class="muted" id="rule-hits-note" style="font-size:12px;padding:2px 2px 8px">命中/健康度统计暂不可用，页面不以 0 冒充。</div>`);
  // 草稿 KPI 是唯一「列表里看不到」的分母，给一个到草稿箱的可达入口（与左侧菜单草稿箱同源）。
  host.querySelectorAll("[data-rule-go]").forEach(el => {
    const go = () => { try { showView(el.getAttribute("data-rule-go")); } catch (e) { /* 视图未加载时忽略 */ } };
    el.addEventListener("click", go);
    el.addEventListener("keydown", (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); } });
  });
}

function renderList() {
  const host = document.querySelector("#rule-list");
  if (!host) return;
  if (!Array.isArray(rules)) rules = [];
  const srcF = $("#rule-src")?.value || "";
  const statusF = $("#rule-status")?.value || "effective";
  const formF = $("#rule-form")?.value || "";
  const catF = $("#rule-cat")?.value || "";
  const riskF = $("#rule-risk")?.value || "";
  const execF = $("#rule-exec")?.value || "";
  const mapF = $("#rule-map")?.value || "";
  const ownerF = ($("#rule-owner")?.value || "").trim().toLowerCase();
  const kw = ($("#rule-q")?.value || "").trim().toLowerCase();
  // L51 批量勾选：筛选条件变化时清空勾选（翻页保留，支持跨页批量）；分组筛选由后端
  // GET /api/v1/rules?tag_id= 完成，这里不重复过滤，只维护选择态。
  const _filterSig = JSON.stringify([srcF, statusF, formF, catF, riskF, execF, mapF, ownerF, kw]);
  if (RULE_TAG_STATE.filterSig !== _filterSig) {
    RULE_TAG_STATE.filterSig = _filterSig;
    RULE_TAG_STATE.selected = new Set();
  }
  const _sel = RULE_TAG_STATE.selected;
  const _tagFilterName = (() => {
    const id = String(RULE_TAG_STATE.ruleFilter || "");
    if (!id) return "";
    const t = (RULE_TAG_STATE.items || []).find(x => String(x.id) === id);
    return String((t && t.name) || "");
  })();
  // 规则库不展示草稿（草稿统一在「草稿箱」菜单）
  let filtered = rules.filter(r => !isDraftRule(r));
  if (statusF === "draft") filtered = [];   // 兼容旧调用（如规则挖掘“查看草稿”）：规则库不展示草稿，引导去草稿箱
  else if (statusF === "effective") filtered = filtered.filter(isEffectiveRule);
  else if (statusF === "legacy") filtered = filtered.filter(isLegacyRule);
  else if (statusF === "archived") filtered = filtered.filter(r => String(r.status || "") === "archived");
  else if (statusF === "published") filtered = filtered.filter(r => String(r.status || "") === "published");
  // statusF === "" → 全部非草稿状态（含历史/已下线）
  if (formF) filtered = filtered.filter(r => ruleFormOf(r) === formF);
  if (srcF) filtered = filtered.filter(r => {
    if (srcF === "library" || srcF === "decision" || srcF === "db") {
      const kind = ruleFormOf(r);
      return kind === srcF;
    }
    const src = String(r.source || "").toLowerCase();
    if (srcF === "conversation") return src === "conversation";
    if (srcF === "file") return ["sop", "enterprise_standard", "historical_audit", "rule_export", "document", "document_decompose"].includes(src);
    if (srcF === "rule_mining") return src === "rule_mining";
    if (srcF === "evolution") return ["rsi_feedback", "sedimented"].includes(src);
    return false;
  });
  if (catF) filtered = filtered.filter(r => (r.category || "") === catF);
  if (riskF) filtered = filtered.filter(r => riskF === "severe" ? ["R0", "R1"].includes(r.rclass) : riskF === "info" ? r.rclass === "R5" : !["R0", "R1", "R5"].includes(r.rclass));
  if (execF) filtered = filtered.filter(r => (r.executability?.level || "") === execF);
  if (mapF === "mapped") filtered = filtered.filter(r => r.mapped === true);
  if (mapF === "unmapped") filtered = filtered.filter(r => r.mapped !== true);
  if (ownerF) filtered = filtered.filter(r => (r.owner || "").toLowerCase().includes(ownerF));
  if (kw) filtered = filtered.filter(r => (r.name || "").toLowerCase().includes(kw) || (r.code || "").toLowerCase().includes(kw));
  const total = filtered.length;
  const pages = Math.max(1, Math.ceil(total / RULE_PAGE_SIZE));
  rulePage = Math.min(Math.max(1, rulePage), pages);
  const shown = filtered.slice((rulePage - 1) * RULE_PAGE_SIZE, rulePage * RULE_PAGE_SIZE);
  if (!shown.length) {
    host.innerHTML = uxEmptyHTML({
      title: _tagFilterName
        ? `分组「${_tagFilterName}」下没有符合筛选条件的生效规则`
        : statusF === "legacy" ? "没有旧审批流程遗留规则"
        : statusF === "draft" ? "草稿在「草稿箱」，不在规则库"
        : "当前筛选没有生效规则",
      desc: _tagFilterName
        ? "该分组可能只包含草稿/已下线规则，或与当前状态/来源筛选不匹配；不会伪造规则。"
        : statusF === "legacy"
        ? "待审批/已批准只作为旧流程历史数据展示；新规则无需审批，草稿在「草稿箱」直接发布生效。"
        : statusF === "draft"
          ? "规则库只展示已发布/生效规则；草稿无需审批，到「草稿箱」点「发布生效」。"
          : "草稿在「草稿箱」中发布生效；规则库只展示已发布/生效规则与审核库点位。",
      action: _tagFilterName
        ? { label: "查看全部分组", action: "cleartag:rules" }
        : statusF === "draft" ? { label: "去草稿箱", action: "view:drafts" } : { label: "清空筛选", action: "reset:rules" },
    });
    updateRuleBatchBar();
  } else {
    host.innerHTML = `<table class="table rule-table">
    <thead><tr><th style="width:36px" title="全选当前页规则（仅可选可打标的单条规则）"><input type="checkbox" id="rule-check-all" title="全选当前页"></th><th style="width:42px">序号</th><th>规则名称 / 编码</th><th style="width:96px">规则形式</th><th style="width:88px">判定模板</th>
      <th style="width:66px">风险</th><th style="width:132px">状态</th><th style="width:104px">生效版本</th>
      <th style="width:86px">命中</th><th style="width:126px">健康度</th><th style="width:76px">负责人</th>
      <th style="width:104px">更新时间</th><th class="actions-cell" style="width:132px">操作</th></tr></thead><tbody>` +
      shown.map((r, i) => {
        const form = ruleFormOf(r);
        const legacy = isLegacyRule(r);
        const effV = ruleEffectiveVersion(r);
        const latestV = String(r.latest_version || r.version || "");
        // 审核库点位（非规则表行）与决策表行（id=决策表 code）不参与分组打标，避免 404
        const canSelect = form === "single" && !!r.id;
        const rowTags = Array.isArray(r.tags) ? r.tags.map(t => String((t && t.id) || "")).filter(Boolean) : [];
        const latestNote = (latestV && effV && latestV !== effV && !legacy)
          ? `<div class="muted" style="font-size:11px">最新草稿 ${esc(latestV)}（未生效）</div>` : "";
        const statusHtml = `<span class="pill ${r.status === "published" || form === "library" ? "published" : r.status === "archived" ? "r" : "draft"}">${esc(ruleStatusLabel(r))}</span>`
          + (legacy ? ` <span class="pill r" title="旧审批流程遗留状态：只读；由业务管理员在列表操作中转回草稿">历史</span>` : "");
        const hitDisplay = r.hit_count_display != null ? r.hit_count_display : (r.hit_count || 0);
        const hitHtml = (hitDisplay === "未归因")
          ? `<span class="muted" title="该规则没有可归因命中；未归因总数见上方 KPI，不按 0 处理">未归因</span>`
          : `${esc(String(hitDisplay))}`;
        const healthHtml = r.health_label
          ? `<span class="${r.health_state === "attributed" ? "" : "muted"}" title="${esc(String(r.health_state || ""))}">${esc(r.health_label)}</span>`
          : `<span class="muted">未归因（不可计算）</span>`;
        let actions = "";
        if (form === "library") {
          actions = `<span class="muted" title="审核库点位由平台点位库管理，不走客户规则详情">库点位</span>`;
        } else if (form === "decision") {
          actions = `<button class="btn" data-detail="${esc(r.id)}" title="只读查看决策表规则行">详情</button>`
            + `<button class="btn" data-dt-open="${esc(r.code)}" title="打开决策表查看/编辑">决策表</button>`;
        } else if (legacy) {
          actions = `<button class="btn" data-detail="${esc(r.id)}" title="只读查看历史规则详情">详情</button>`
            + (currentRole === "admin" ? `<button class="btn" data-legacy-convert="${esc(r.id)}" title="旧审批流程遗留状态：转回草稿后可编辑/发布">转为草稿</button>` : "");
        } else {
          actions = `<button class="btn" data-detail="${esc(r.id)}" title="只读查看规则详情；编辑需在详情内点「编辑规则」">详情</button>`;
        }
        return `<tr class="rule-row" data-id="${esc(r.id)}" data-tags="${esc(rowTags.join(","))}">
        <td class="rt-check-cell">${canSelect
          ? `<input type="checkbox" data-rule-check="${esc(r.id)}" title="勾选后批量加入/移出分组"${_sel.has(String(r.id)) ? " checked" : ""}>`
          : `<span class="muted" title="审核库点位不支持分组打标">—</span>`}</td>
        <td class="muted">${total - ((rulePage - 1) * RULE_PAGE_SIZE + i)}</td>
        <td><b>${esc(r.name)}</b><div class="muted" style="font-size:11px">${esc(r.code)}</div>${ruleTagChipsHTML(r.tags)}</td>
        <td><span class="pill ${RULE_FORM_PILL[form] || "draft"}">${esc(RULE_FORM_LABEL[form] || form)}</span></td>
        <td>${esc(CATEGORY[r.category] || r.category || "—")}</td>
        <td>${esc(riskLabel(r.rclass))}</td>
        <td>${statusHtml}</td>
        <td class="muted">${esc(effV || "—")}${latestNote}</td>
        <td>${hitHtml}</td>
        <td>${healthHtml}</td>
        <td>${esc(r.owner || "—")}</td>
        <td class="muted">${esc(fmtTime(r.updated_at))}</td>
        <td class="actions-cell">${actions}</td></tr>`;
      }).join("") + `</tbody></table>`;
  }
  const pager = $("#rule-pager");
  if (pager) pager.innerHTML = total ? `<div class="pager"><span class="pager-total">共 ${total} 条 · 第 ${rulePage}/${pages} 页</span><div class="pager-actions">${rulePage > 1 ? `<button data-rpg="${rulePage - 1}">上一页</button>` : `<button disabled>上一页</button>`}${Array.from({ length: pages }, (_, i) => i + 1).slice(Math.max(0, rulePage - 3), Math.max(0, rulePage - 3) + 5).map(n => `<button class="${n === rulePage ? "on" : ""}" data-rpg="${n}">${n}</button>`).join("")}${rulePage < pages ? `<button data-rpg="${rulePage + 1}">下一页</button>` : `<button disabled>下一页</button>`}</div></div>` : "";
  pager?.querySelectorAll("[data-rpg]").forEach(b => b.onclick = () => { rulePage = Number(b.dataset.rpg); renderList(); });
  // L51 批量勾选：表头全选（仅当前页），行勾选写入 RULE_TAG_STATE.selected（跨页保留）。
  const _checkAll = host.querySelector("#rule-check-all");
  const _checkBoxes = Array.from(host.querySelectorAll("[data-rule-check]"));
  const _syncCheckAll = () => {
    if (!_checkAll) return;
    const on = _checkBoxes.filter(cb => cb.checked).length;
    _checkAll.checked = _checkBoxes.length > 0 && on === _checkBoxes.length;
    _checkAll.indeterminate = on > 0 && on < _checkBoxes.length;
    _checkAll.disabled = _checkBoxes.length === 0;
  };
  _checkBoxes.forEach(cb => {
    const id = String(cb.getAttribute("data-rule-check") || "");
    cb.checked = _sel.has(id);
    cb.addEventListener("change", () => {
      if (cb.checked) _sel.add(id); else _sel.delete(id);
      _syncCheckAll();
      updateRuleBatchBar();
    });
  });
  if (_checkAll) {
    _checkAll.addEventListener("change", () => {
      _checkBoxes.forEach(cb => {
        const id = String(cb.getAttribute("data-rule-check") || "");
        cb.checked = !!_checkAll.checked;
        if (_checkAll.checked) _sel.add(id); else _sel.delete(id);
      });
      _syncCheckAll();
      updateRuleBatchBar();
    });
  }
  _syncCheckAll();
  updateRuleBatchBar();
  // 详情入口统一只读：行点击 /「详情」按钮都只打开只读详情；编辑需在详情内单独点「编辑规则」。
  // 按钮点击时阻止冒泡，避免行监听器重复 loadDetail（旧实现会请求两次）。
  const openRowDetail = (id, tr) => {
    if (!id) return;
    host.querySelectorAll("tr.rule-row").forEach(x => x.classList.remove("active"));
    tr?.classList.add("active");
    loadDetail(id);
  };
  host.querySelectorAll("[data-detail]").forEach(b => b.addEventListener("click", (ev) => {
    ev.stopPropagation();
    openRowDetail(b.dataset.detail, b.closest("tr"));
  }));
  host.querySelectorAll("[data-dt-open]").forEach(b => b.addEventListener("click", (ev) => {
    ev.stopPropagation();
    const code = b.dataset.dtOpen;
    const row = (rules || []).find(x => x.code === code) || {};
    if (String(row.status || "") === "published") { if (typeof openDecisionDetail === "function") openDecisionDetail(code); }
    else if (typeof openDecisionEdit === "function") openDecisionEdit(code);
  }));
  host.querySelectorAll("[data-legacy-convert]").forEach(b => b.addEventListener("click", (ev) => {
    ev.stopPropagation();
    convertLegacyToDraft(b.dataset.legacyConvert, b);
  }));
  host.querySelectorAll("tr.rule-row").forEach(tr => tr.addEventListener("click", (ev) => {
    if (ev.target.closest("[data-detail],[data-dt-open],[data-legacy-convert],[data-rule-check],#rule-check-all")) return;
    openRowDetail(tr.dataset.id, tr);
  }));
}

async function convertLegacyToDraft(id, btn) {
  if (currentRole !== "admin" || !id) return;
  const ok = typeof confirmAction === "function"
    ? await confirmAction("转为草稿", "这是旧审批流程遗留状态。转回草稿后可继续编辑并「发布生效」（无需审批）。确认继续？", "转为草稿")
    : confirm("转回草稿？旧审批流程遗留状态，转回后可编辑并直接发布。");
  if (!ok) return;
  if (btn) { btn.disabled = true; btn.textContent = "处理中…"; }
  try {
    const res = await (await fetch(`/api/v1/rules/${encodeURIComponent(id)}/rollback`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (res && res.error) { showToast(String(res.error), "err"); return; }
    showToast("已转为草稿，请到「草稿箱」编辑并发布生效（无需审批）");
    refreshRuleDomain();
  } catch (e) {
    showToast("转换失败：网络错误", "err");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "转为草稿"; }
  }
}

/* ===================== 草稿箱（独立菜单；无审批，直接发布生效） ===================== */
async function loadDrafts() {
  const host = document.querySelector("#draft-list");
  if (host) uxSetLoading("#draft-list", "正在加载草稿…", 4);
  // L51：分组条与草稿列表同源加载；分组读取失败不阻断草稿列表。
  await Promise.all([loadDraftConflicts(), loadRuleHomeStats(), loadRuleTags()]);
  const _tagId = String((typeof RULE_TAG_STATE !== "undefined" && RULE_TAG_STATE.draftFilter) || "");
  const _url = "/api/v1/rules" + (_tagId ? "?tag_id=" + encodeURIComponent(_tagId) : "");
  let _rr = null, _status = 0;
  try {
    const _resp = await fetch(_url);
    _status = _resp.status;
    _rr = await _resp.json();
  } catch (e) {
    if (host) uxSetEmpty("#draft-list", { title: "草稿加载失败", desc: "请检查网络后重试；已保存的草稿不会丢失。", action: { label: "重新加载", action: "view:drafts" } });
    return;
  }
  if (_status === 401) {
    if (host) uxSetEmpty("#draft-list", { title: "登录已过期", desc: "登录会话已失效，请刷新页面重新登录后查看草稿。", action: { label: "刷新页面", action: "reload:page" } });
    return;
  }
  if (_status === 404 && _tagId) {
    RULE_TAG_STATE.draftFilter = "";
    if (typeof showToast === "function") showToast("该分组不存在或不在当前工作空间（404），已切回「全部」", "err");
    await loadRuleTags(true);
    return loadDrafts();
  }
  if (_rr && _rr.error) {
    if (host) uxSetEmpty("#draft-list", { title: "草稿加载失败", desc: String(_rr.error), action: { label: "重新加载", action: "view:drafts" } });
    return;
  }
  rules = Array.isArray(_rr) ? _rr : ((_rr && (_rr.items || _rr.rules)) || []);
  const drafts = rules.filter(isDraftRule);
  updateDraftMenuBadge(drafts.length);
  // 筛选回显（草稿箱独立 key，避免与规则库筛选互相污染）
  uxFiltersRestoreOnce("drafts");
  renderRuleTagBar("drafts");
  renderDraftKPIs(drafts);
  renderDraftList(drafts);
}

async function loadDraftConflicts() {
  draftConflictMap = {};
  try {
    const d = await (await fetch("/api/v1/conflicts?status=open")).json();
    const items = Array.isArray(d) ? d : ((d && d.items) || []);
    items.forEach(c => {
      if (String(c.status || "open") === "resolved" || String(c.status || "") === "ignored") return;
      const sev = String(c.severity || "");
      [String(c.rule_a || ""), String(c.rule_b || "")].forEach(code => {
        if (!code) return;
        const cur = draftConflictMap[code] || { count: 0, maxSeverity: "", ids: [] };
        cur.count += 1;
        if (sev === "critical") cur.maxSeverity = "critical";
        else if (!cur.maxSeverity) cur.maxSeverity = sev || "warning";
        if (c.id) cur.ids.push(c.id);
        draftConflictMap[code] = cur;
      });
    });
  } catch (e) {
    draftConflictMap = {};   // 读取失败时显示「读取失败」，不伪造 0 冲突
  }
}

function draftCompleteness(r) {
  const form = ruleFormOf(r);
  if (form === "decision") {
    const rowsMatch = String(r.source || "").match(/(\d+)\s*行/);
    const rows = rowsMatch ? Number(rowsMatch[1]) : 0;
    const ok = rows > 0;
    return { score: ok ? 100 : 0, publishable: ok, checks: [["规则行", ok]],
             reason: ok ? "可在决策表编辑器中发布生效" : "决策表没有规则行，先在编辑器中补充条件→结论" };
  }
  const ir = r.ir || {};
  const ex = r.executability || {};
  const missing = Array.isArray(ex.missing) ? ex.missing : [];
  // T-185（KB 评审 P1-1）：可发布口径必须与后端 _scope_publish_gate 同源——
  // scope_required + status=missing 的规则后端会 400 scope_missing，草稿箱不能同时
  // 显示「待补全 40%」+「发布生效」（自相矛盾）。scope_* 由 /api/v1/rules 下发。
  const scopeRequired = r.scope_required === true;
  const scopeMissing = r.scope_missing === true || String(r.scope_status || "") === "missing";
  const scopeBlocked = scopeRequired && scopeMissing;
  const checks = [
    ["判据", !!ir.complete],
    ["可执行结构", !!ir.publishable],
    ["证据范围", missing.length === 0],
    ["适用范围", !!ir.scope_declared && !scopeBlocked],
    ["点位映射", !!r.mapped],
  ];
  const passed = checks.filter(c => c[1]).length;
  const score = Math.round(passed / checks.length * 100);
  const publishable = !!(ir.publishable && ir.complete) && !scopeBlocked
    && ["draft", "approved"].includes(String(r.status || ""));
  let reason = "";
  if (!publishable) {
    const errs = (ir.contract_errors || []).filter(Boolean);
    if (scopeBlocked) reason = "未声明适用范围：发布会被 scope_missing 阻断，请点「补适用范围」补齐后发布";
    else if (errs.length) reason = String(errs[0]);
    else if (missing.length) reason = "缺少证据/判据：" + missing.join("、");
    else if (!r.mapped) reason = "未映射平台点位（可保存为自定义规则，但建议补点位）";
    else reason = "规则 IR 不完整，补齐判据/证据/适用范围后可发布";
  }
  return { score, publishable, checks, reason };
}

function renderDraftKPIs(drafts) {
  const host = document.querySelector("#draft-kpis");
  if (!host) return;
  let ready = 0, blocked = 0, conflicted = 0;
  drafts.forEach(r => {
    const c = draftCompleteness(r);
    if (c.publishable) ready += 1; else blocked += 1;
    if ((draftConflictMap[r.code] || {}).count) conflicted += 1;
  });
  host.innerHTML = `
    <div class="kpi"><b>${drafts.length}</b><span>草稿总数</span></div>
    <div class="kpi"><b>${ready}</b><span>可发布</span></div>
    <div class="kpi"><b>${blocked}</b><span>待补全</span></div>
    <div class="kpi"><b>${conflicted}</b><span>有未处理冲突</span></div>
    <div class="kpi"><b>0</b><span>审批队列（已取消审批）</span></div>`;
}

function renderDraftList(drafts) {
  const host = document.querySelector("#draft-list");
  if (!host) return;
  const formF = $("#draft-form")?.value || "";
  const readyF = $("#draft-ready")?.value || "";
  const kw = ($("#draft-q")?.value || "").trim().toLowerCase();
  let rows = drafts.slice();
  if (formF) rows = rows.filter(r => ruleFormOf(r) === formF);
  if (readyF === "yes") rows = rows.filter(r => draftCompleteness(r).publishable);
  if (readyF === "no") rows = rows.filter(r => !draftCompleteness(r).publishable);
  if (kw) rows = rows.filter(r => (r.name || "").toLowerCase().includes(kw) || (r.code || "").toLowerCase().includes(kw));
  if (!rows.length) {
    const _draftTagId = String(RULE_TAG_STATE.draftFilter || "");
    const _dtag = _draftTagId ? (RULE_TAG_STATE.items || []).find(x => String(x.id) === _draftTagId) : null;
    host.innerHTML = uxEmptyHTML({
      title: _dtag ? `分组「${String(_dtag.name || "")}」下没有草稿` : (drafts.length ? "当前筛选没有草稿" : "草稿箱为空"),
      desc: _dtag
        ? "该分组当前没有草稿规则；可查看全部分组，或把规则加入该分组后再来。"
        : (drafts.length ? "调整筛选条件后重试。" : "新建规则会先保存为草稿；无需审批，在草稿箱点「发布生效」即可进入审核主链。"),
      action: _dtag ? { label: "查看全部分组", action: "cleartag:drafts" }
        : (drafts.length ? { label: "清空筛选", action: "view:drafts" } : { label: "新建规则", action: "view:newrule" }),
    });
    return;
  }
  host.innerHTML = `<table class="table rule-table">
    <thead><tr><th style="width:42px">序号</th><th>规则名称 / 编码</th><th style="width:96px">规则形式</th>
      <th style="width:128px">来源</th><th style="width:74px">负责人</th><th style="width:132px">最近编辑</th>
      <th style="width:150px">完整度</th><th style="width:120px">冲突</th><th style="width:150px">可发布</th>
      <th class="actions-cell" style="width:210px">操作</th></tr></thead><tbody>` +
    rows.map((r, i) => {
      const form = ruleFormOf(r);
      const comp = draftCompleteness(r);
      const cf = draftConflictMap[r.code] || (Object.keys(draftConflictMap).length ? { count: 0 } : null);
      let cfHtml;
      if (cf === null) cfHtml = `<span class="muted" title="冲突读取失败，不冒充 0">读取失败</span>`;
      else if (!cf.count) cfHtml = `<span class="muted">无未处理冲突</span>`;
      else cfHtml = `<span class="pill ${cf.maxSeverity === "critical" ? "r" : "draft"}" title="发布后冲突只提醒、不阻断">${cf.count} 条待裁决</span>`;
      const missingChecks = comp.checks.filter(c => !c[1]).map(c => c[0]);
      const canPublish = comp.publishable && form !== "decision";
      // T-185：可发布的草稿不再写「缺：…」（KB 评审指出的"40% 待补全 + 发布生效"自相矛盾）；
      // 非阻断项改为「建议补」，阻断项（作用域/IR）才显示「缺」。
      const compHtml = `<b>${comp.score}%</b>` + (missingChecks.length
        ? (canPublish
          ? `<div class="muted" style="font-size:11px" title="以下为建议补全项，不影响发布门禁">可发布（建议补：${esc(missingChecks.join("、"))}）</div>`
          : `<div class="muted" style="font-size:11px" title="${esc(comp.reason)}">缺：${esc(missingChecks.join("、"))}</div>`)
        : `<div class="muted" style="font-size:11px">字段完整</div>`);
      // T-185（KB 评审 P1-1）：待补全草稿必须有可点的补齐入口，不能只显示"暂不可发布"。
      const _scopeBlocked = !!(r.ir && r.ir.scope_declared === false) || missingChecks.includes("适用范围");
      const statusHtml = (currentRole === "admin")
        ? (canPublish
          ? `<button class="btn primary" data-draft-publish="${esc(r.id)}" title="无需审批，直接发布生效">发布生效</button>`
          : `<div style="display:flex;flex-direction:column;gap:4px"><span class="muted" title="${esc(comp.reason)}">待补全，暂不可发布</span>
              <button class="btn" data-draft-scope="${esc(r.id)}" title="打开编辑面板补齐适用范围/证据范围后即可发布">补${_scopeBlocked ? "适用范围" : "证据/判据"}</button></div>`)
        : `<span class="muted" title="审核员可创建草稿；发布生效需业务管理员">发布需业务管理员</span>`;
      const actions = form === "decision"
        ? `<button class="btn" data-detail="${esc(r.id)}" title="只读查看决策表草稿">查看</button><button class="btn primary" data-dt-edit="${esc(r.code)}">打开决策表编辑器</button>`
        : `<button class="btn" data-detail="${esc(r.id)}" title="只读查看草稿详情；点「编辑规则」继续编辑">详情</button><button class="btn" data-draft-edit="${esc(r.id)}">继续编辑</button>`;
      return `<tr class="draft-row" data-id="${esc(r.id)}">
        <td class="muted">${rows.length - i}</td>
        <td><b>${esc(r.name)}</b><div class="muted" style="font-size:11px">${esc(r.code)}</div>${ruleTagChipsHTML(r.tags)}</td>
        <td><span class="pill ${RULE_FORM_PILL[form] || "draft"}">${esc(RULE_FORM_LABEL[form] || form)}</span></td>
        <td class="muted">${esc(ruleSourceLabel(r))}</td>
        <td>${esc(r.owner || "—")}</td>
        <td class="muted">${esc(fmtTime(r.updated_at || r.created_at))}</td>
        <td>${compHtml}</td>
        <td>${cfHtml}</td>
        <td>${statusHtml}</td>
        <td class="actions-cell">${actions}</td></tr>`;
    }).join("") + `</tbody></table>`;
  host.querySelectorAll("[data-detail]").forEach(b => b.addEventListener("click", () => loadDetail(b.dataset.detail)));
  host.querySelectorAll("[data-draft-edit]").forEach(b => b.addEventListener("click", () => loadDetail(b.dataset.draftEdit, { openEdit: true })));
  host.querySelectorAll("[data-dt-edit]").forEach(b => b.addEventListener("click", () => { if (typeof openDecisionEdit === "function") openDecisionEdit(b.dataset.dtEdit); }));
  host.querySelectorAll("[data-draft-publish]").forEach(b => b.addEventListener("click", () => publishDraftRule(b.dataset.draftPublish, b)));
  host.querySelectorAll("[data-draft-scope]").forEach(b => b.addEventListener("click", () => loadDetail(b.dataset.draftScope, { openEdit: true, focusScope: true })));
}

async function publishDraftRule(id, btn) {
  if (!id || currentRole !== "admin") return;
  const row = (rules || []).find(x => x.id === id) || {};
  const ok = typeof confirmAction === "function"
    ? await confirmAction("发布生效", `「${row.name || id}」将立即发布生效并参与下一次审核。\n\n规则无需审批；发布后若检测到规则冲突，会提示并跳转到冲突提醒（不阻断发布、不自动回滚）。`, "发布生效")
    : confirm("发布生效？发布后参与下一次审核，冲突只提醒不阻断。");
  if (!ok) return;
  if (btn) { btn.disabled = true; btn.textContent = "发布中…"; }
  try {
    const res = await (await fetch(`/api/v1/rules/${encodeURIComponent(id)}/publish`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (res && res.error) {
      // T-185（KB 评审 P1-1）：优先展示后端中文 message（原来只显示内部码 scope_missing），
      // 并直接打开编辑面板定位到「适用范围」区，给修复下一步。
      const _msg = String(res.message || res.error);
      const _gateCodes = ["scope_missing", "ir_needs_structure", "ir_incomplete"];
      if (_gateCodes.includes(String(res.error))) {
        showToast(_msg + "；已打开编辑面板，请补齐「适用范围/证据范围」后保存再发布", "err");
        loadDetail(id, { openEdit: true, focusScope: true });
      } else {
        showToast(_msg, "err");
      }
      return;
    }
    handlePublishOutcome(res);
    await loadDrafts();
    if (res && Number(res.conflict_count || 0) > 0) return;   // 已跳转冲突提醒
  } catch (e) {
    showToast("发布失败：网络错误", "err");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "发布生效"; }
  }
}

/* 发布结果统一处理：成功提示生效版本；有冲突则提示并跳转冲突提醒（不阻断/不回滚）。 */
function handlePublishOutcome(res) {
  if (!res || res.error) { showToast((res && res.error) || "发布失败", "err"); return false; }
  const ver = res.effective_version || res.version || "";
  const n = Number(res.conflict_count || 0);
  if (n > 0) {
    showToast(`已发布生效${ver ? "：" + ver : ""}；发现 ${n} 条规则冲突，已打开冲突提醒（不阻断发布、未回滚）`, "err");
    if (typeof showView === "function") showView("conflict");
  } else {
    showToast(`已发布生效${ver ? "：" + ver : ""}（无需审批）`);
  }
  return true;
}

/* 规则域统一刷新：详情/草稿箱/规则库的操作完成后调用。 */
function refreshRuleDomain() {
  updateDraftBadgeFromCurrent();
  if (typeof loadDrafts === "function" && typeof currentView !== "undefined" && currentView === "drafts") { loadDrafts(); return; }
  if (typeof loadRules === "function") loadRules();
}
function updateDraftBadgeFromCurrent() {
  if (Array.isArray(rules)) updateDraftMenuBadge(rules.filter(isDraftRule).length);
}
function updateDraftMenuBadge(n) {
  const badge = document.querySelector("#draft-menu-badge");
  if (!badge) return;
  const v = Number(n || 0);
  badge.textContent = v > 0 ? String(v) : "";
  badge.hidden = v <= 0;
}

/* ===================== L51 规则分组标签（组织维度，独立于 scope.tags 路由标签） =====================
 * 依赖 L50 API（docs/qa/artifacts/l50_rule_tags_20261124/api_contract.json）：
 *   GET  /api/v1/rules/tags                     分组列表 + rule_count + perms
 *   POST /api/v1/rules/tags                     新建分组（admin）
 *   POST /api/v1/rules/tags/{id}/rename         重命名（admin）
 *   POST /api/v1/rules/tags/{id}/delete         删除（admin；只解除关联不删规则）
 *   POST /api/v1/rules/tags/{id}/assign         勾选规则加入分组（reviewer/admin，幂等）
 *   POST /api/v1/rules/tags/{id}/unassign       勾选规则移出分组（同上，幂等）
 *   POST /api/v1/rules/tags/{id}/full-audit     分组全链路自检（只读 dry-run）
 *   GET  /api/v1/rules?tag_id=<id>              规则列表按分组过滤（行内附 tags）
 *
 * 权限：can_manage=新建/改名/删除；can_assign=批量打标；can_full_audit=分组自检。
 * 权限不足时按钮隐藏（服务端仍会 403 兜底）。所有动态文本一律 esc，颜色先做
 * #RRGGBB 白名单校验再进 style，防注入。
 */
const RULE_TAG_STATE = {
  loaded: false, loading: false, error: "", items: [], total: 0,
  perms: { can_manage: false, can_assign: false, can_full_audit: false },
  ruleFilter: "", draftFilter: "", selected: new Set(),
  filterSig: "", allCount: null, draftCount: null, auditTagId: "",
  lastAudit: null,
};

/* 自检 issue / next_action 中文文案（后端 code → 可读文案，未知 code 原样展示不伪造） */
const RT_ISSUE_LABEL = {
  version_missing: "缺版本记录", no_version: "没有版本",
  scope_missing: "缺适用范围", scope_wildcard_forbidden: "适用范围含隐式全量通配",
  scope_workspace_wide_reason_required: "全空间规则需说明理由",
  ir_incomplete: "规则 IR 不完整", ir_needs_structure: "缺可补全的发布结构",
  ir_invalid: "规则 IR 非法", compile_failed: "规则 IR 编译异常",
  executor_unreachable: "执行器不可达",
  decision_table_binding_invalid: "决策表绑定无效",
  decision_table_binding_unverified: "决策表绑定未校验",
  regression_blocked: "版本回归阻断", invalid_transition: "状态迁移非法",
  concurrent_transition: "并发状态冲突", gate_failed: "发布门禁执行异常",
  rule_archived: "规则已下线", rule_missing: "规则已不存在",
};
const RT_NEXT_LABEL = {
  none: "无需操作", publish: "发布生效", approve: "批准（旧审批流程）后发布",
  edit_scope: "补适用范围（scope）", edit_slots: "补判据/槽位",
  fix_executor: "修执行器/模板", fix_binding: "修决策表绑定",
  fix_regression: "修版本回归问题", restore: "恢复已下线规则",
  review: "人工复核发布状态", retry: "稍后重试", remove_item: "从分组移除",
};
const RT_STATE_PILL = { published: "published", ready: "published", draft: "draft", blocked: "r" };

/* ---------- 样式：注入独立 style（不改 style.css，避免与其它 lane 冲突） ---------- */
function ensureRuleTagStyles() {
  if (document.getElementById("rule-tag-styles")) return;
  const style = document.createElement("style");
  style.id = "rule-tag-styles";
  style.textContent = `
.rule-tag-wrap{margin:0 0 10px;border:1px solid #EDEFF2;border-radius:10px;padding:8px 12px;background:#FAFBFC}
.rtb-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:3px 0}
.rtb-row+.rtb-row{border-top:1px dashed #EBEDF0;margin-top:4px;padding-top:7px}
.rtb-title{font-size:12px;color:#8F959E;flex:none}
.rtb-group{display:inline-flex;align-items:center;gap:2px;flex-wrap:wrap}
.rtb-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid #E5E8EC;background:#fff;border-radius:14px;padding:2px 10px;font-size:12px;cursor:pointer;color:#1F2329;line-height:20px}
button.rtb-chip{font-family:inherit}
.rtb-chip:hover{border-color:#B8CDFF;background:#F5F8FF}
.rtb-chip.on{border-color:#2F6BFF;background:#EAF1FF;color:#1A4FD6}
.rtb-chip>i{width:8px;height:8px;border-radius:50%;display:inline-block;flex:none}
.rtb-chip>b{font-weight:600;color:#646A73;font-size:11px}
.rtb-chip.on>b{color:#1A4FD6}
.rtb-mini{border:1px solid transparent;background:transparent;color:#8F959E;font-size:11px;cursor:pointer;padding:0 4px;border-radius:6px;line-height:18px;font-family:inherit}
.rtb-mini:hover{color:#2F6BFF;background:#fff;border-color:#E5E8EC}
.rtb-spacer{margin-left:auto}
.rtb-empty{font-size:12px;color:#8F959E}
.rtb-err{font-size:12px;color:#D83931;background:#FFF2F0;border:1px solid #FFCCC7;border-radius:8px;padding:4px 8px;margin:6px 0 0}
.rtb-sel{font-size:12px;color:#646A73}
.rtb-sel b{color:#1F2329}
.rtag-chips{display:flex;gap:4px;flex-wrap:wrap;margin-top:3px}
.rtag-chip{display:inline-flex;align-items:center;gap:4px;font-size:10.5px;line-height:16px;border-radius:8px;padding:0 6px;background:#F2F3F5;color:#1F2329;border:1px solid #EBEDF0;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rtag-chip>i{width:6px;height:6px;border-radius:50%;flex:none;display:inline-block}
.rt-check-cell{text-align:center}
.rt-check-cell input{cursor:pointer}
.rt-audit-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin:0 0 10px}
.rt-audit-kpi{border:1px solid #EDEFF2;border-radius:10px;padding:8px 10px;background:#fff}
.rt-audit-kpi b{display:block;font-size:20px;line-height:26px}
.rt-audit-kpi span{font-size:11px;color:#8F959E}
.rt-audit-meta{font-size:12px;color:#8F959E;margin-bottom:8px}
.rt-audit-ready{border:1px solid #BFE8D4;background:#F0FBF5;border-radius:10px;padding:8px 12px;font-size:12px;margin-bottom:10px;line-height:1.7}
.rt-audit-ready.blocked{border-color:#FFE0B2;background:#FFF8EE}
.rt-audit-ids{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.rt-audit-ids code{font-size:11px;background:#E8F7F0;border-radius:6px;padding:1px 6px;color:#00875A}
.rt-audit-byissue{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.rt-audit-byissue span{font-size:11px;background:#FFF3E0;color:#B26A00;border-radius:8px;padding:1px 8px}
.rt-audit-rule{border:1px solid #EDEFF2;border-radius:10px;padding:8px 12px;margin-bottom:8px;background:#fff}
.rt-audit-rule-head{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.rt-audit-rule-head b{font-size:13px}
.rt-audit-rule-head .muted{font-size:11px}
.rt-audit-actions{margin-left:auto}
.rt-audit-issue{margin-top:4px;font-size:12px;display:flex;gap:6px;align-items:flex-start;flex-wrap:wrap}
.rt-audit-issue .rt-audit-next{color:#2F6BFF;white-space:nowrap}
.rt-audit-empty{font-size:13px;color:#8F959E;text-align:center;padding:40px 0}
.rt-audit-note{font-size:11px;color:#8F959E;margin-top:10px;line-height:1.7}
.nr-tag-picker{border:1px solid #EBEDF0;background:#FAFBFC;border-radius:8px;padding:8px 10px;margin-bottom:10px}
.nr-tag-picker-head{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:6px}
.nr-tag-opts{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}
.nr-tag-opt{display:inline-flex;align-items:center;gap:5px;border:1px solid #E5E8EC;background:#fff;border-radius:14px;padding:2px 10px;font-size:12px;cursor:pointer;line-height:20px}
.nr-tag-opt.on{border-color:#2F6BFF;background:#EAF1FF;color:#1A4FD6}
.nr-tag-opt>i{width:8px;height:8px;border-radius:50%;display:inline-block}
.nr-tag-opt>b{font-weight:600;color:#8F959E;font-size:11px}
`;
  document.head.appendChild(style);
}

/* ---------- 基础：颜色白名单 / 错误文案 / API 封装 ---------- */
function rtSafeColor(color) {
  const s = String(color || "");
  return /^#[0-9A-Fa-f]{6}$/.test(s) ? s : "#B0B5BD";
}

function ruleTagErrText(data, status) {
  const d = data || {};
  const code = String(d.code || "");
  const msg = String(d.error || d.message || d.reason || "");
  if (status === 401) return "登录已过期或未登录，请刷新页面重新登录后再操作分组";
  if (code === "duplicate_tag") {
    const n = String(d.name || "");
    return n ? `分组标签「${n}」已存在，请换一个名称` : "分组标签名称已存在，请换一个名称";
  }
  if (code === "invalid_tag_name") return msg || "分组标签名称不合法（不能为空、不超过 40 字、不含控制字符）";
  if (code === "invalid_tag_color") return msg || "分组标签颜色不合法（须为 #RRGGBB）";
  if (code === "too_many_tags") return msg || "分组标签数量超过上限（单空间最多 200 个）";
  if (code === "too_many_rules") return msg || "单次最多勾选 500 条规则，请分批操作";
  if (code === "forbidden") return msg || "当前角色无权限执行该分组操作（需业务管理员）";
  if (code === "workspace_required") return "缺少租户/工作空间上下文，请刷新页面后重试（未静默落默认空间）";
  if (code === "tag_not_found" || code === "not_found") return msg || "分组不存在或不在当前工作空间（可能已被删除），已刷新分组列表";
  if (code === "rule_not_found") return msg || "部分规则不存在或不在当前工作空间（可能已被删除），未做任何打标";
  if (code === "rule_tags_failed") return msg || "分组操作失败（服务内部错误），请稍后重试";
  if (status === 403) return msg || "当前角色无权限执行该分组操作（403）";
  if (status === 404) return msg || "分组接口或资源不存在（404）";
  if (status === 0) return msg || "网络错误，分组操作未完成";
  return msg || `分组操作失败（HTTP ${status || "?"}）`;
}

/* 统一返回 {ok,status,data,message}；网络/401/403/404/5xx 都可读，绝不静默。 */
async function ruleTagApi(method, path, body) {
  let resp;
  try {
    const init = { method: method || "GET" };
    if (body !== undefined) {
      init.headers = { "Content-Type": "application/json" };
      init.body = JSON.stringify(body);
    }
    resp = await fetch(path, init);
  } catch (e) {
    return { ok: false, status: 0, data: null, message: "网络错误，分组请求未完成：" + ((e && e.message) || e) };
  }
  let data = null;
  try { data = await resp.json(); } catch (e) { data = null; }
  if (data && typeof data === "object" && data.ok === true) {
    return { ok: true, status: resp.status, data, message: "" };
  }
  return { ok: false, status: resp.status, data: data || {}, message: ruleTagErrText(data || {}, resp.status) };
}

/* ---------- 分组列表读取 ---------- */
let _ruleTagsInflight = null;
async function loadRuleTags(force) {
  const st = RULE_TAG_STATE;
  if (_ruleTagsInflight) return _ruleTagsInflight;
  if (st.loaded && !force && !st.error) { renderRuleTagBars(); return true; }
  st.loading = true;
  renderRuleTagBars();
  _ruleTagsInflight = (async () => {
    const res = await ruleTagApi("GET", "/api/v1/rules/tags");
    st.loading = false;
    if (!res.ok) {
      st.error = res.message;
      st.loaded = false;
      renderRuleTagBars();
      return false;
    }
    const d = res.data || {};
    st.items = Array.isArray(d.items) ? d.items : [];
    st.total = Number(d.total != null ? d.total : st.items.length) || 0;
    st.perms = Object.assign({ can_manage: false, can_assign: false, can_full_audit: false }, d.perms || {});
    st.error = "";
    st.loaded = true;
    renderRuleTagBars();
    return true;
  })();
  try { return await _ruleTagsInflight; } finally { _ruleTagsInflight = null; }
}

/* ---------- 分组条渲染（规则库 + 草稿箱） ---------- */
function ensureRuleTagWrap(which) {
  ensureRuleTagStyles();
  const isDraft = which === "drafts";
  const wrapId = isDraft ? "draft-tag-wrap" : "rule-tag-wrap";
  let wrap = document.getElementById(wrapId);
  if (wrap) return wrap;
  const host = document.querySelector(isDraft ? "#draft-list" : "#rule-list");
  if (!host || !host.parentNode) return null;
  wrap = document.createElement("div");
  wrap.id = wrapId;
  wrap.className = "rule-tag-wrap";
  wrap.setAttribute("data-tag-view", which);
  host.parentNode.insertBefore(wrap, host);
  return wrap;
}

function _rtAllCount(which) {
  const st = RULE_TAG_STATE;
  if (which === "drafts") {
    if (!Array.isArray(rules)) return st.draftCount != null ? st.draftCount : 0;
    if (!st.draftFilter) { st.draftCount = rules.filter(isDraftRule).length; }
    return st.draftCount != null ? st.draftCount : 0;
  }
  if (!Array.isArray(rules)) return st.allCount != null ? st.allCount : 0;
  // 与 renderList 同一分母：规则库列表不含草稿（草稿在「草稿箱」），避免「全部 338」与
  // KPI「列表共 337 条」两个分母同时出现。
  if (!st.ruleFilter) { st.allCount = rules.filter(r => !isDraftRule(r)).length; }
  return st.allCount != null ? st.allCount : (rules || []).filter(r => !isDraftRule(r)).length;
}

function renderRuleTagBars() {
  ["rules", "drafts"].forEach(w => {
    try { renderRuleTagBar(w); } catch (e) { console.error("[规则分组] 渲染失败", w, e); }
  });
}

function renderRuleTagBar(which) {
  const wrap = ensureRuleTagWrap(which);
  if (!wrap) return;
  const st = RULE_TAG_STATE;
  const isDraft = which === "drafts";
  const curFilter = String((isDraft ? st.draftFilter : st.ruleFilter) || "");
  const perms = st.perms || {};
  const canManage = !!perms.can_manage;
  const canAssign = !!perms.can_assign;
  const canAudit = !!perms.can_full_audit;
  if (st.loading) {
    wrap.innerHTML = `<div class="rtb-row"><span class="rtb-title">分组</span><span class="rtb-empty">正在加载分组…</span></div>`;
    return;
  }
  if (st.error) {
    wrap.innerHTML = `<div class="rtb-row"><span class="rtb-title">分组</span><span class="rtb-empty">分组读取失败</span><span class="rtb-spacer"></span></div>
      <div class="rtb-err" role="alert">分组读取失败：${esc(st.error)} <button type="button" class="btn" data-tag-retry>重试</button></div>`;
    wrap.querySelectorAll("[data-tag-retry]").forEach(b => b.addEventListener("click", () => loadRuleTags(true)));
    return;
  }
  const totalAll = _rtAllCount(which);
  const parts = [];
  parts.push(`<button type="button" class="rtb-chip ${curFilter ? "" : "on"}" data-tag-filter="" title="查看全部分组">全部 <b>${esc(String(totalAll))}</b></button>`);
  (st.items || []).forEach(t => {
    const rawId = String((t && t.id) || "");
    if (!rawId) return;
    const id = esc(rawId);
    const name = esc(String((t && t.name) || ""));
    const color = rtSafeColor(t && t.color);
    const n = Number((t && t.rule_count) || 0) || 0;
    const on = curFilter === rawId;
    const group = [];
    group.push(`<span class="rtb-chip ${on ? "on" : ""}" data-tag-filter="${id}" role="button" tabindex="0" title="按分组筛选：${name}（${n} 条规则）"><i style="background:${color}"></i><span>${name}</span><b>${esc(String(n))}</b></span>`);
    if (canAudit) group.push(`<button type="button" class="rtb-mini" data-tag-audit="${id}" title="对分组「${name}」执行全链路自检（只读）">自检</button>`);
    if (canManage) {
      group.push(`<button type="button" class="rtb-mini" data-tag-rename="${id}" title="重命名分组「${name}」">改名</button>`);
      group.push(`<button type="button" class="rtb-mini" data-tag-delete="${id}" title="删除分组「${name}」（只解除关联，不删规则）">删除</button>`);
    }
    parts.push(`<span class="rtb-group">${group.join("")}</span>`);
  });
  let createHtml = "";
  if (canManage) createHtml += `<button type="button" class="btn" data-tag-create title="新建分组标签">＋新建分组</button>`;
  if (!st.items.length) {
    createHtml += `<span class="rtb-empty">${canManage ? "还没有分组标签，点「＋新建分组」创建" : "还没有分组标签；新建/改名/删除分组需业务管理员"}</span>`;
  } else if (!canManage) {
    createHtml += `<span class="rtb-empty">审核员只读分组（新建/改名/删除需业务管理员）</span>`;
  }
  let html = `<div class="rtb-row"><span class="rtb-title">分组</span>${parts.join("")}<span class="rtb-spacer"></span>${createHtml}</div>`;
  if (!isDraft) {
    const nSel = st.selected ? st.selected.size : 0;
    const dis = (!canAssign || !nSel) ? " disabled" : "";
    html += `<div class="rtb-row" data-tag-batch-row="1"><span class="rtb-title">批量打标</span>
      <span class="rtb-sel" id="rule-tag-batch-count">已选 <b>${esc(String(nSel))}</b> 条</span>
      <button type="button" class="btn" id="btn-rule-batch-assign" data-tag-batch="assign"${dis} title="${canAssign ? "把勾选规则加入分组" : "当前角色无打标权限"}">加入分组</button>
      <button type="button" class="btn" id="btn-rule-batch-unassign" data-tag-batch="unassign"${dis} title="${canAssign ? "把勾选规则移出分组" : "当前角色无打标权限"}">移出分组</button>
      <span class="muted" style="font-size:11px">勾选表格左侧复选框（表头可全选当前页）后批量操作；重复操作幂等，不会报错。</span>
      ${canAssign ? "" : `<span class="rtb-empty">当前角色只读分组</span>`}
    </div>`;
  }
  wrap.innerHTML = html;
  wrap.querySelectorAll("[data-tag-filter]").forEach(el => {
    const act = () => applyRuleTagFilter(which, el.getAttribute("data-tag-filter") || "");
    el.addEventListener("click", act);
    el.addEventListener("keydown", (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); act(); } });
  });
  wrap.querySelectorAll("[data-tag-audit]").forEach(b => b.addEventListener("click", (ev) => {
    ev.stopPropagation();
    openRuleTagAudit(b.getAttribute("data-tag-audit"), b);
  }));
  wrap.querySelectorAll("[data-tag-rename]").forEach(b => b.addEventListener("click", (ev) => {
    ev.stopPropagation();
    openRuleTagRenameDialog(b.getAttribute("data-tag-rename"));
  }));
  wrap.querySelectorAll("[data-tag-delete]").forEach(b => b.addEventListener("click", (ev) => {
    ev.stopPropagation();
    deleteRuleTag(b.getAttribute("data-tag-delete"));
  }));
  wrap.querySelectorAll("[data-tag-create]").forEach(b => b.addEventListener("click", () => openRuleTagCreateDialog()));
  wrap.querySelectorAll("[data-tag-batch]").forEach(b => b.addEventListener("click", () => {
    if (b.disabled) return;
    openRuleTagBatchDialog(b.getAttribute("data-tag-batch"));
  }));
}

function applyRuleTagFilter(which, tagId) {
  const st = RULE_TAG_STATE;
  const key = which === "drafts" ? "draftFilter" : "ruleFilter";
  const next = String(tagId || "");
  if (String(st[key] || "") === next) return;
  st[key] = next;
  st.selected = new Set();
  st.filterSig = "";
  if (which === "drafts") {
    if (typeof loadDrafts === "function") loadDrafts();
  } else if (typeof loadRules === "function") {
    loadRules();
  }
}

function resetRuleTagFilter(which) {
  const st = RULE_TAG_STATE;
  if (which === "drafts") { if (st.draftFilter) { st.draftFilter = ""; if (typeof loadDrafts === "function") loadDrafts(); } }
  else if (st.ruleFilter) { st.ruleFilter = ""; if (typeof loadRules === "function") loadRules(); }
}

function updateRuleBatchBar() {
  const st = RULE_TAG_STATE;
  const n = st.selected ? st.selected.size : 0;
  const countEl = document.getElementById("rule-tag-batch-count");
  if (countEl) countEl.innerHTML = `已选 <b>${esc(String(n))}</b> 条`;
  ["btn-rule-batch-assign", "btn-rule-batch-unassign"].forEach(id => {
    const b = document.getElementById(id);
    if (!b) return;
    b.disabled = !((st.perms || {}).can_assign) || n <= 0;
  });
}

/* ---------- 行内 chips ---------- */
function ruleTagChipsHTML(tags) {
  const list = Array.isArray(tags) ? tags : [];
  if (!list.length) return "";
  const html = list.map(t => {
    const name = esc(String((t && t.name) || ""));
    const color = rtSafeColor(t && t.color);
    return `<span class="rtag-chip" title="分组：${name}"><i style="background:${color}"></i>${name}</span>`;
  }).join("");
  return `<div class="rtag-chips" data-rule-tags="1">${html}</div>`;
}

/* ---------- 弹窗（统一确认/输入） ---------- */
function openRuleTagDialog(opts) {
  opts = opts || {};
  const old = document.getElementById("rule-tag-dialog");
  if (old) old.remove();
  const mask = document.createElement("div");
  mask.id = "rule-tag-dialog";
  mask.className = "modal-mask";
  mask.innerHTML = `<div class="modal" style="width:min(560px,calc(100vw - 32px))">
    <h3 style="margin:0 0 8px">${esc(opts.title || "分组操作")}</h3>
    <div id="rule-tag-dialog-body" style="font-size:13px;line-height:1.7">${opts.bodyHTML || ""}</div>
    <div class="actions" style="margin-top:16px;justify-content:flex-end">
      <button type="button" class="btn" data-cancel>取消</button>
      <button type="button" class="btn primary" data-ok>${esc(opts.okLabel || "确定")}</button>
    </div></div>`;
  document.body.appendChild(mask);
  const close = () => mask.remove();
  mask.querySelector("[data-cancel]").onclick = close;
  mask.onclick = (e) => { if (e.target === mask) close(); };
  const ok = mask.querySelector("[data-ok]");
  ok.onclick = async () => {
    try { await opts.onOk({ mask, ok, close, body: mask.querySelector("#rule-tag-dialog-body") }); }
    catch (e) { showRuleTagDialogErr(mask.querySelector("#rt-dialog-err"), "操作失败：" + ((e && e.message) || e)); }
  };
  return mask;
}

function showRuleTagDialogErr(el, msg) {
  if (!el) { if (typeof showToast === "function") showToast(String(msg), "err"); return; }
  el.hidden = false;
  el.textContent = String(msg || "操作失败");
}

function openRuleTagCreateDialog() {
  if (!(RULE_TAG_STATE.perms || {}).can_manage) { if (typeof showToast === "function") showToast("新建分组需业务管理员", "err"); return; }
  openRuleTagDialog({
    title: "新建分组标签",
    okLabel: "创建",
    bodyHTML: `<label style="display:block;margin-bottom:8px">分组名称
        <input id="rt-name-input" class="field" maxlength="40" placeholder="如：重点条款 / 2026 版制度" style="width:100%;margin-top:4px"></label>
      <label style="display:block">颜色（可选，默认按名称取色）
        <input id="rt-color-input" class="field" maxlength="7" placeholder="#2F6BFF" style="width:130px;margin-top:4px"></label>
      <div class="rtb-err" id="rt-dialog-err" hidden></div>
      <div class="muted" style="font-size:11px;margin-top:8px">分组只用于组织/检索规则，不影响 manifest 路由与判定；同工作空间内名称不可重复。</div>`,
    onOk: async (ctx) => {
      const err = ctx.mask.querySelector("#rt-dialog-err");
      const name = String((ctx.mask.querySelector("#rt-name-input") || {}).value || "").trim();
      const color = String((ctx.mask.querySelector("#rt-color-input") || {}).value || "").trim();
      if (!name) { showRuleTagDialogErr(err, "请输入分组名称"); return; }
      ctx.ok.disabled = true; ctx.ok.textContent = "创建中…";
      const res = await ruleTagApi("POST", "/api/v1/rules/tags", color ? { name: name, color: color } : { name: name });
      ctx.ok.disabled = false; ctx.ok.textContent = "创建";
      if (!res.ok) {
        showRuleTagDialogErr(err, res.message);
        if (res.status === 409) { await loadRuleTags(true); }
        return;
      }
      ctx.close();
      if (typeof showToast === "function") showToast(`已新建分组「${String((res.data.tag || {}).name || name)}」`);
      await loadRuleTags(true);
    },
  });
  setTimeout(() => { const i = document.getElementById("rt-name-input"); if (i) i.focus(); }, 30);
}

function openRuleTagRenameDialog(tagId) {
  const st = RULE_TAG_STATE;
  if (!(st.perms || {}).can_manage) { if (typeof showToast === "function") showToast("重命名分组需业务管理员", "err"); return; }
  const tag = (st.items || []).find(t => String(t.id) === String(tagId)) || {};
  openRuleTagDialog({
    title: "重命名分组标签",
    okLabel: "保存",
    bodyHTML: `<label style="display:block;margin-bottom:8px">分组名称
        <input id="rt-name-input" class="field" maxlength="40" value="${esc(String(tag.name || ""))}" style="width:100%;margin-top:4px"></label>
      <label style="display:block">颜色
        <input id="rt-color-input" class="field" maxlength="7" value="${esc(rtSafeColor(tag.color))}" style="width:130px;margin-top:4px"></label>
      <div class="rtb-err" id="rt-dialog-err" hidden></div>`,
    onOk: async (ctx) => {
      const err = ctx.mask.querySelector("#rt-dialog-err");
      const name = String((ctx.mask.querySelector("#rt-name-input") || {}).value || "").trim();
      const color = String((ctx.mask.querySelector("#rt-color-input") || {}).value || "").trim();
      if (!name) { showRuleTagDialogErr(err, "分组名称不能为空"); return; }
      ctx.ok.disabled = true; ctx.ok.textContent = "保存中…";
      const body = { name: name };
      if (color) body.color = color;
      const res = await ruleTagApi("POST", "/api/v1/rules/tags/" + encodeURIComponent(tagId) + "/rename", body);
      ctx.ok.disabled = false; ctx.ok.textContent = "保存";
      if (!res.ok) {
        showRuleTagDialogErr(err, res.message);
        if (res.status === 409) { await loadRuleTags(true); }
        return;
      }
      ctx.close();
      if (typeof showToast === "function") showToast(`已重命名分组为「${String((res.data.tag || {}).name || name)}」`);
      await loadRuleTags(true);
      if (typeof loadRules === "function") loadRules();
    },
  });
  setTimeout(() => { const i = document.getElementById("rt-name-input"); if (i) { i.focus(); i.select && i.select(); } }, 30);
}

async function deleteRuleTag(tagId) {
  const st = RULE_TAG_STATE;
  if (!(st.perms || {}).can_manage) { if (typeof showToast === "function") showToast("删除分组需业务管理员", "err"); return; }
  const tag = (st.items || []).find(t => String(t.id) === String(tagId)) || {};
  const n = Number(tag.rule_count || 0) || 0;
  const ok = (typeof confirmAction === "function")
    ? await confirmAction("删除分组", `删除分组「${String(tag.name || tagId)}」只会解除它与 ${n} 条规则的关联，不会删除任何规则。确认删除？`, "删除", true)
    : window.confirm(`删除分组「${String(tag.name || tagId)}」？（只解除关联，不删规则）`);
  if (!ok) return;
  const res = await ruleTagApi("POST", "/api/v1/rules/tags/" + encodeURIComponent(tagId) + "/delete", {});
  if (!res.ok) {
    if (typeof showToast === "function") showToast(res.message, "err");
    if (res.status === 404) await loadRuleTags(true);
    return;
  }
  if (typeof showToast === "function") {
    showToast(`已删除分组「${String((res.data.tag || {}).name || tag.name || tagId)}」，解除关联 ${Number(res.data.unlinked || 0)} 条规则（规则本身未删除）`);
  }
  if (String(st.ruleFilter) === String(tagId)) st.ruleFilter = "";
  if (String(st.draftFilter) === String(tagId)) st.draftFilter = "";
  await loadRuleTags(true);
  if (typeof loadRules === "function") loadRules();
}

/* ---------- 批量打标（加入/移出分组） ---------- */
function openRuleTagBatchDialog(mode) {
  const st = RULE_TAG_STATE;
  const n = st.selected ? st.selected.size : 0;
  if (!n) { if (typeof showToast === "function") showToast("请先勾选要操作的规则", "err"); return; }
  if (!(st.perms || {}).can_assign) { if (typeof showToast === "function") showToast("当前角色无打标权限", "err"); return; }
  const isAssign = mode === "assign";
  const canManage = !!(st.perms || {}).can_manage;
  const tagOptions = (st.items || []).map(t => {
    const id = esc(String((t && t.id) || ""));
    const name = esc(String((t && t.name) || ""));
    const color = rtSafeColor(t && t.color);
    return `<label class="nr-tag-opt"><input type="radio" name="rt-batch-tag" value="${id}"><i style="background:${color}"></i><span>${name}</span><b>${esc(String(Number((t && t.rule_count) || 0)))}</b></label>`;
  }).join("");
  openRuleTagDialog({
    title: isAssign ? `把 ${n} 条规则加入分组` : `把 ${n} 条规则移出分组`,
    okLabel: isAssign ? "加入分组" : "移出分组",
    bodyHTML: `<div class="muted" style="margin-bottom:8px">已勾选 <b>${n}</b> 条规则（跨页勾选会一并提交）</div>
      <div class="muted" style="margin-bottom:4px">选择分组（单选）</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px" id="rt-batch-opts">${tagOptions || '<span class="muted">当前空间还没有分组标签</span>'}</div>
      ${(isAssign && canManage) ? `<label style="display:block;margin-top:6px">或新建分组：
        <input id="rt-batch-new" class="field" maxlength="40" placeholder="输入新分组名称（可选）" style="width:100%;margin-top:4px"></label>` : ""}
      ${(isAssign && !canManage) ? `<div class="muted" style="font-size:11px">审核员只能使用已有分组；新建分组需业务管理员</div>` : ""}
      <div class="rtb-err" id="rt-dialog-err" hidden></div>`,
    onOk: async (ctx) => {
      const err = ctx.mask.querySelector("#rt-dialog-err");
      const sel = ctx.mask.querySelector('input[name="rt-batch-tag"]:checked');
      const newEl = ctx.mask.querySelector("#rt-batch-new");
      const newName = newEl ? String(newEl.value || "").trim() : "";
      const tagId = sel ? String(sel.value || "") : "";
      if (!tagId && !newName) { showRuleTagDialogErr(err, "请选择一个分组，或填写新分组名称"); return; }
      await doRuleTagBatch(mode, tagId, newName, { ok: ctx.ok, close: ctx.close, err: err, okLabel: isAssign ? "加入分组" : "移出分组" });
    },
  });
}

async function doRuleTagBatch(mode, tagId, newName, ctx) {
  const st = RULE_TAG_STATE;
  const ids = Array.from(st.selected || []);
  if (!ids.length) { showRuleTagDialogErr(ctx && ctx.err, "请先勾选规则"); return; }
  if (ctx && ctx.ok) { ctx.ok.disabled = true; ctx.ok.textContent = "处理中…"; }
  try {
    let tid = String(tagId || "");
    if (!tid && newName) {
      const created = await ruleTagApi("POST", "/api/v1/rules/tags", { name: newName });
      if (created.ok) {
        tid = String((created.data.tag || {}).id || "");
      } else if (created.status === 409) {
        await loadRuleTags(true);
        const found = (st.items || []).find(t => String(t.name) === String(newName));
        if (found) tid = String(found.id || "");
        else { showRuleTagDialogErr(ctx && ctx.err, created.message); return; }
      } else {
        showRuleTagDialogErr(ctx && ctx.err, created.message);
        return;
      }
    }
    if (!tid) { showRuleTagDialogErr(ctx && ctx.err, "分组不存在，请刷新后重试"); return; }
    const path = "/api/v1/rules/tags/" + encodeURIComponent(tid) + (mode === "assign" ? "/assign" : "/unassign");
    const res = await ruleTagApi("POST", path, { rule_ids: ids });
    if (!res.ok) {
      showRuleTagDialogErr(ctx && ctx.err, res.message);
      if (res.status === 404) { await loadRuleTags(true); }
      return;
    }
    const d = res.data || {};
    if (typeof showToast === "function") {
      if (mode === "assign") showToast(`已加入分组：新增 ${Number(d.added || 0)} 条，已在该分组 ${(d.already || []).length} 条`);
      else showToast(`已移出分组：移除 ${(d.removed || []).length} 条，跳过 ${(d.skipped || []).length} 条`);
    }
    if (ctx && ctx.close) ctx.close();
    st.selected = new Set();
    await loadRuleTags(true);
    if (typeof loadRules === "function") loadRules();
  } finally {
    if (ctx && ctx.ok && ctx.ok.isConnected) {
      ctx.ok.disabled = false;
      ctx.ok.textContent = (ctx && ctx.okLabel) || "确定";
    }
  }
}

/* ---------- 分组全链路自检抽屉 ---------- */
function ensureRuleTagAuditDom() {
  ensureRuleTagStyles();
  let mask = document.getElementById("rule-tag-audit-drawer");
  if (mask) return mask;
  mask = document.createElement("div");
  mask.id = "rule-tag-audit-drawer";
  mask.className = "drawer-mask";
  mask.hidden = true;
  mask.innerHTML = `<div class="drawer" style="width:min(880px,96vw)">
    <div class="drawer-head"><h3 id="rt-audit-title" style="margin:0;font-size:15px">分组全链路自检</h3>
      <div class="actions"><button type="button" class="ws-close" id="rt-audit-close" aria-label="关闭分组自检">×</button></div></div>
    <div id="rt-audit-body" style="flex:1;overflow:auto;padding:12px 16px"></div></div>`;
  document.body.appendChild(mask);
  mask.querySelector("#rt-audit-close").onclick = closeRuleTagAudit;
  mask.onclick = (e) => { if (e.target === mask) closeRuleTagAudit(); };
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && mask && !mask.hidden) closeRuleTagAudit();
  });
  return mask;
}

function closeRuleTagAudit() {
  const mask = document.getElementById("rule-tag-audit-drawer");
  if (mask) mask.hidden = true;
}

async function openRuleTagAudit(tagId, btn) {
  const st = RULE_TAG_STATE;
  if (!(st.perms || {}).can_full_audit) {
    if (typeof showToast === "function") showToast("当前角色无权限使用分组全链路自检", "err");
    return;
  }
  if (!tagId) return;
  const tag = (st.items || []).find(t => String(t.id) === String(tagId)) || {};
  const mask = ensureRuleTagAuditDom();
  mask.dataset.tagId = String(tagId);
  mask.dataset.tagName = String(tag.name || "");
  const title = mask.querySelector("#rt-audit-title");
  if (title) title.textContent = "分组全链路自检 · " + String(tag.name || tagId);
  const body = mask.querySelector("#rt-audit-body");
  body.innerHTML = `<div class="ux-loading" role="status" aria-live="polite" aria-busy="true">
      <span class="ux-spinner" aria-hidden="true"></span>
      <span class="ux-loading-text">正在自检分组「${esc(String(tag.name || tagId))}」…</span></div>
    <div class="rt-audit-note">只读 dry-run：不发布规则、不写规则状态、不实际跑文档审核。</div>`;
  mask.hidden = false;
  const oldText = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "自检中…"; }
  try {
    const res = await ruleTagApi("POST", "/api/v1/rules/tags/" + encodeURIComponent(tagId) + "/full-audit", { limit: 200 });
    if (!res.ok) {
      body.innerHTML = `<div class="rtb-err" role="alert">分组自检失败：${esc(res.message)}</div>
        <div style="margin-top:10px"><button type="button" class="btn" data-rt-audit-retry>重试</button></div>`;
      body.querySelectorAll("[data-rt-audit-retry]").forEach(b => b.addEventListener("click", () => openRuleTagAudit(tagId)));
      if (res.status === 404) await loadRuleTags(true);
      return;
    }
    st.lastAudit = res.data;
    st.auditTagId = String(tagId);
    renderRuleTagAudit(res.data, tagId);
  } finally {
    if (btn && btn.isConnected) { btn.disabled = false; btn.textContent = oldText || "自检"; }
  }
}

function renderRuleTagAudit(data, tagId) {
  const mask = document.getElementById("rule-tag-audit-drawer");
  if (!mask) return;
  const body = mask.querySelector("#rt-audit-body");
  if (!body) return;
  const d = data || {};
  const sum = d.summary || {};
  const ruleRows = Array.isArray(d.rules) ? d.rules : [];
  const tag = d.tag || {};
  const title = mask.querySelector("#rt-audit-title");
  if (title) title.textContent = "分组全链路自检 · " + String(tag.name || mask.dataset.tagName || tagId);
  const n = (k) => Number(sum[k] || 0) || 0;
  const four = n("ready") + n("blocked") + n("draft") + n("published");
  const total = n("total");
  const checked = Number(sum.checked != null ? sum.checked : ruleRows.length) || 0;
  const byIssueMap = sum.by_issue || {};
  const byIssueKeys = Object.keys(byIssueMap);
  const byIssueHtml = byIssueKeys.length
    ? `<div class="rt-audit-byissue" data-audit-byissue="1">问题分布：` + byIssueKeys.map(k =>
        `<span>${esc(RT_ISSUE_LABEL[k] || k)} ×${esc(String(byIssueMap[k]))}</span>`).join("") + `</div>`
    : "";
  const readyIds = Array.isArray(d.audit_ready_rule_ids) ? d.audit_ready_rule_ids : [];
  const codeById = {};
  ruleRows.forEach(r => { codeById[String((r && r.rule_id) || "")] = String((r && r.code) || "") || String((r && r.rule_id) || ""); });
  const readyHtml = d.audit_ready
    ? `<div class="rt-audit-ready" data-audit-ready="1"><b>可发起审核（audit_ready）</b>：组内 ${esc(String(readyIds.length))} 条规则已发布且自检健康，可进入下一次全链路审核。
        <div class="rt-audit-ids">${readyIds.slice(0, 30).map(id => `<code title="${esc(String(id))}">${esc(codeById[id] || id)}</code>`).join("")}${readyIds.length > 30 ? `<span class="muted">等 ${esc(String(readyIds.length))} 条</span>` : ""}</div></div>`
    : `<div class="rt-audit-ready blocked" data-audit-ready="0"><b>暂不可发起审核</b>：组内没有「已发布且自检健康」的规则；请先处理下面的阻断/待补全项并发布。</div>`;
  const ruleHtml = ruleRows.map(r => {
    r = r || {};
    const state = String(r.state || "");
    const pill = RT_STATE_PILL[state] || "draft";
    const issues = Array.isArray(r.issues) ? r.issues : [];
    const issueHtml = issues.length
      ? issues.map(it => {
          const lvl = String((it && it.level) || "");
          const cls = lvl === "block" ? "r" : lvl === "draft" ? "draft" : "";
          const lvlLabel = lvl === "block" ? "阻断" : lvl === "draft" ? "待补全" : "提示";
          const next = String((it && it.next_action) || "");
          return `<div class="rt-audit-issue"><span class="pill ${cls}">${esc(lvlLabel)}</span><span>${esc(String((it && it.message) || (it && it.code) || ""))}</span>${next ? `<span class="rt-audit-next">→ ${esc(RT_NEXT_LABEL[next] || next)}</span>` : ""}</div>`;
        }).join("")
      : `<div class="muted" style="font-size:11px;margin-top:4px">自检未发现问题</div>`;
    const ver = r.version || {};
    const verHtml = ver.latest
      ? `<span class="muted">最新 ${esc(String(ver.latest))}${ver.published ? ` / 生效 ${esc(String(ver.published))}` : ""}</span>`
      : `<span class="muted">无版本</span>`;
    const action = String(r.next_action || "review");
    return `<div class="rt-audit-rule" data-rule-id="${esc(String(r.rule_id || ""))}" data-rule-state="${esc(state)}">
      <div class="rt-audit-rule-head">
        <span class="pill ${pill}">${esc(String(r.state_label || state))}</span>
        <b>${esc(String(r.name || ""))}</b>
        <span class="muted">${esc(String(r.code || ""))} · ${esc(String(r.status_label || r.status || ""))}</span>
        ${verHtml}
        <span class="rt-audit-actions"><button type="button" class="btn" data-rt-next="${esc(String(r.rule_id || ""))}" data-rt-action="${esc(action)}" title="按建议处理该规则">${esc(String(r.next_action_label || RT_NEXT_LABEL[action] || "查看规则"))}</button></span>
      </div>
      ${issueHtml}
    </div>`;
  }).join("");
  body.innerHTML = `
    <div class="rt-audit-kpis">
      <div class="rt-audit-kpi"><b style="color:#00B578">${esc(String(n("ready")))}</b><span>可发布（ready）</span></div>
      <div class="rt-audit-kpi"><b style="color:#D83931">${esc(String(n("blocked")))}</b><span>阻断（blocked）</span></div>
      <div class="rt-audit-kpi"><b style="color:#FF8800">${esc(String(n("draft")))}</b><span>待补全（draft）</span></div>
      <div class="rt-audit-kpi"><b style="color:#00B578">${esc(String(n("published")))}</b><span>已发布（published）</span></div>
      <div class="rt-audit-kpi"><b>${esc(String(n("published_unhealthy")))}</b><span>已发布需复核</span></div>
    </div>
    <div class="rt-audit-meta" data-audit-summary="1" data-total="${esc(String(total))}" data-checked="${esc(String(checked))}" data-four="${esc(String(four))}">
      共 ${esc(String(total))} 条规则 · 已检查 ${esc(String(checked))} 条${sum.truncated ? "（结果已截断，上限 " + esc(String(d.limit || "")) + " 条）" : ""} · 有问题 ${esc(String(n("rules_with_issues")))} 条 · 生成时间 ${esc(String(d.generated_at || "—"))}
    </div>
    ${readyHtml}
    ${byIssueHtml}
    <div data-audit-rules="1">${ruleHtml || '<div class="rt-audit-empty">该分组还没有规则；先在规则库勾选规则并「加入分组」。</div>'}</div>
    <div class="rt-audit-note">${(Array.isArray(d.notes) ? d.notes : []).map(x => esc(String(x))).join("<br>")}</div>`;
  body.querySelectorAll("[data-rt-next]").forEach(b => b.addEventListener("click", () => {
    handleRuleTagNextAction(b.getAttribute("data-rt-next"), b.getAttribute("data-rt-action") || "review", tagId, b);
  }));
  body.querySelectorAll("[data-rt-audit-retry]").forEach(b => b.addEventListener("click", () => openRuleTagAudit(tagId)));
}

async function handleRuleTagNextAction(ruleId, action, tagId, btn) {
  const act = String(action || "review");
  if (act === "retry") { openRuleTagAudit(tagId); return; }
  if (act === "none") { if (typeof showToast === "function") showToast("该规则已生效，无需操作"); return; }
  if (act === "remove_item") {
    const ok = (typeof confirmAction === "function")
      ? await confirmAction("从分组移除", "该规则已不存在（可能被清理）；确认把它从当前分组移除？", "移除")
      : window.confirm("从分组移除该失效规则？");
    if (!ok) return;
    const res = await ruleTagApi("POST", "/api/v1/rules/tags/" + encodeURIComponent(tagId) + "/unassign", { rule_ids: [String(ruleId)] });
    if (!res.ok) { if (typeof showToast === "function") showToast(res.message, "err"); return; }
    if (typeof showToast === "function") showToast("已从分组移除失效规则");
    await loadRuleTags(true);
    openRuleTagAudit(tagId);
    return;
  }
  if (act === "approve") {
    if (typeof showToast === "function") showToast("旧审批流程已取消：草稿可直接「发布生效」，无需批准", "err");
  }
  closeRuleTagAudit();
  if (typeof loadDetail === "function") {
    loadDetail(ruleId, { openEdit: act !== "publish", focusScope: act === "edit_scope" });
    return;
  }
  if (typeof showView === "function") showView("rules");
  if (typeof showToast === "function") showToast("已定位规则 " + String(ruleId) + "，请在规则详情中处理");
}

ensureRuleTagStyles();
