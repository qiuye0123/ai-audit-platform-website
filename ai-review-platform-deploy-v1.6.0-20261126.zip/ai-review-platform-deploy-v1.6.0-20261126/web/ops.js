(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var lastAt = "";

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
    });
  }
  function nullText(v) { return v == null || v === "" ? '<span class="ops-null">—（无数据）</span>' : esc(v); }
  function fmtBytes(n) {
    if (n == null) return '<span class="ops-null">—（无数据）</span>';
    var units = ["B", "KB", "MB", "GB", "TB"], i = 0, x = Number(n);
    while (x >= 1024 && i < units.length - 1) { x /= 1024; i++; }
    return esc((i === 0 ? x : x.toFixed(x < 10 ? 2 : 1)) + " " + units[i]) + ' <span class="ops-muted">(' + esc(n) + ' B)</span>';
  }
  function pill(text, cls) { return '<span class="ops-pill ' + (cls || "") + '">' + esc(text) + '</span>'; }

  function setError(msg) {
    var el = $("ops-error");
    if (!msg) { el.hidden = true; el.textContent = ""; return; }
    el.hidden = false; el.textContent = msg;
  }

  function render(d) {
    var db = d.db || {}, model = d.model || {}, q = d.queue || {}, err = d.errors || {}, up = d.upgrade || {};
    var tj = q.task_job || {}, otq = q.open_task_queue || {};
    $("ops-kpis").children[0].innerHTML =
      '<div class="k"><span>数据库</span></div><div class="v">' + fmtBytes(db.size_bytes) + '</div>' +
      '<div class="s">' + esc(db.table_count == null ? "—" : db.table_count + " 张表") + ' · journal=' + esc(db.journal_mode || "—") + '</div>';
    $("ops-kpis").children[1].innerHTML =
      '<div class="k"><span>WAL</span></div><div class="v">' + fmtBytes(db.wal_bytes == null ? 0 : db.wal_bytes) + '</div>' +
      '<div class="s">页数 ' + nullText(db.page_count) + ' · 空闲页 ' + nullText(db.freelist_pages) + '</div>';
    $("ops-kpis").children[2].innerHTML =
      '<div class="k"><span>任务积压</span></div><div class="v">' + esc(tj.backlog == null ? 0 : tj.backlog) + '</div>' +
      '<div class="s">排队 ' + esc(tj.queued || 0) + ' · 运行 ' + esc(tj.running || 0) + ' · 总计 ' + esc(tj.total || 0) + '</div>';
    $("ops-kpis").children[3].innerHTML =
      '<div class="k"><span>模型调用</span></div><div class="v">' + esc(model.calls_total == null ? 0 : model.calls_total) + '</div>' +
      '<div class="s">24h ' + esc(model.calls_24h || 0) + ' · 最近 ' + nullText(model.last_call_at) + '</div>';

    $("ops-err-count").innerHTML = esc(err.count == null ? 0 : err.count);
    $("ops-err-sub").textContent = err.note || (err.count ? "见下方最近错误" : "无错误记录");
    $("ops-open-count").innerHTML = esc(otq.total == null ? 0 : otq.total);
    $("ops-open-sub").textContent = "accepted " + (otq.accepted || 0) + " · processing " + (otq.processing || 0) +
      " · failed " + (otq.failed || 0) + " · 未投递事件 " + (q.open_event_undelivered == null ? 0 : q.open_event_undelivered);
    $("ops-model-state").innerHTML = model.available
      ? pill("可用（按配置）", "ok") : pill("不可用", model.configured ? "warn" : "err");
    $("ops-model-sub").textContent = (model.source || "—") + " · " + (model.model || "未配置") +
      " · 启用模型 " + (model.enabled_models || 0) + "/" + (model.total_models || 0);
    $("ops-version").innerHTML = esc(up.current_version || "—");
    $("ops-version-sub").textContent = "schema " + (up.schema_version == null ? "—" : up.schema_version) +
      " · " + (up.latest_migration ? up.latest_migration.version : "无迁移记录");

    $("ops-db-line").innerHTML = "路径 <span class='ops-mono'>" + esc(db.path || "—") + "</span>" +
      " · 文件 " + fmtBytes(db.size_bytes) + " · WAL " + fmtBytes(db.wal_bytes || 0) +
      " · 索引 " + nullText(db.index_count) + " · page_size " + nullText(db.page_size);
    var js = d.json || {};
    $("ops-json-line").innerHTML = "JSON 检查：列 " + esc(js.checked_columns || 0) +
      " · 值 " + esc(js.checked_rows || 0) + " · 坏数据 " +
      (js.invalid_count ? pill(String(js.invalid_count), "err") : pill("0", "ok")) +
      " <span class='ops-muted'>（" + esc(js.engine || "—") + "；" + esc(js.note || "") + "）</span>";
    var tables = (db.tables || []).slice().sort(function (a, b) { return (b.rows || 0) - (a.rows || 0); });
    $("ops-tables").innerHTML = tables.length
      ? tables.map(function (t) { return "<tr><td class='ops-mono'>" + esc(t.name) + "</td><td>" + nullText(t.rows) + "</td></tr>"; }).join("")
      : "<tr><td colspan='2' class='ops-muted'>无表数据</td></tr>";

    $("ops-model-note").textContent = model.note || ("最近调用 " + (model.recent || []).length + " 条");
    $("ops-model-rows").innerHTML = (model.recent || []).length
      ? model.recent.map(function (r) {
          return "<tr><td>" + nullText(r.created_at) + "</td><td class='ops-mono'>" + esc(r.model || "—") +
            "</td><td>" + nullText(r.latency_ms) + "</td><td>" + esc((r.tokens_in || 0) + " / " + (r.tokens_out || 0)) +
            "</td><td>" + (r.ok ? pill("成功", "ok") : pill("失败/空响应", "err")) + "</td></tr>";
        }).join("")
      : "<tr><td colspan='5' class='ops-muted'>无模型调用记录（llm_trace 为空）</td></tr>";
    var dp = d.data_policy || {};
    var dpState = $("ops-dp-state");
    if (dpState) {
      dpState.textContent = dp.configured === true ? "已配置" : (dp.configured === false ? "未配置" : "读取失败");
      dpState.className = "ops-pill " + (dp.configured === true ? "ok" : (dp.configured === false ? "warn" : "err"));
    }
    var dpLine = $("ops-dp-line");
    if (dpLine) {
      var ext = dp.external_model || {};
      dpLine.textContent = "外发模型：" + (ext.enabled ? "启用" : "未启用") +
        (ext.model ? "（" + ext.model + "）" : "") +
        " · 数据边界策略：" + (dp.configured === true ? "后台已配置" : "未配置/待运维确认") +
        " · 人工例外：" + ((dp.manual_items || []).length) + " 项";
    }
    var dpWarn = $("ops-dp-warn");
    if (dpWarn) {
      dpWarn.innerHTML = (dp.warnings || []).length
        ? (dp.warnings || []).map(function (w) { return "<div>⚠ " + esc(w) + "</div>"; }).join("")
        : "<span class='ops-muted'>无待处理警告</span>";
    }
    var dpManual = $("ops-dp-manual");
    if (dpManual) {
      dpManual.innerHTML = (dp.manual_items || []).length
        ? (dp.manual_items || []).map(function (x) {
            return "<tr><td>" + esc(x.kind || "policy") + "</td><td>" + esc(x.text || "") + "</td></tr>";
          }).join("")
        : "<tr><td colspan='2' class='ops-muted'>无待人工判断项；后台静默处理</td></tr>";
    }
    $("ops-queue-line").textContent = "task_job：总计 " + (tj.total || 0) + " · 排队 " + (tj.queued || 0) +
      " · 运行 " + (tj.running || 0) + " · 完成 " + (tj.done || 0) + " · 失败 " + (tj.failed || 0) +
      " · 取消 " + (tj.cancelled || 0) + " · 超时 " + (tj.timeout || 0) +
      (tj.oldest_queued_at ? " · 最久排队 " + tj.oldest_queued_at : "");
    $("ops-open-line").textContent = "open_task_queue：总计 " + (otq.total || 0) + " · accepted " + (otq.accepted || 0) +
      " · processing " + (otq.processing || 0) + " · completed " + (otq.completed || 0) +
      " · failed " + (otq.failed || 0) + " · open_event 未投递 " + (q.open_event_undelivered || 0);
    $("ops-error-rows").innerHTML = (err.recent || []).length
      ? err.recent.map(function (r) {
          return "<tr><td>" + esc(r.source || "—") + "</td><td>" + nullText(r.at) + "</td><td>" +
            "<span class='ops-mono'>" + esc(r.event || "") + "</span><br>" + esc(r.title || "") +
            "</td><td class='ops-mono'>" + esc(r.detail || "") + "</td></tr>";
        }).join("")
      : "<tr><td colspan='4' class='ops-muted'>无错误记录</td></tr>";

    var lu = up.last_upgrade;
    $("ops-upgrade-line").innerHTML = "当前版本 <b>" + esc(up.current_version || "—") + "</b>" +
      " · schema version " + (up.schema_version == null ? '<span class="ops-null">—（无迁移表）</span>' : esc(up.schema_version)) +
      " · 最近迁移 " + (up.latest_migration ? esc(up.latest_migration.version + " @ " + up.latest_migration.applied_at) : '<span class="ops-null">—（无记录）</span>') +
      " · 最近升级包 " + (lu ? esc(lu.package + "（" + lu.from_version + " → " + lu.to_version + " @ " + lu.applied_at + "）") : '<span class="ops-null">—（无记录）</span>');
    $("ops-notes").innerHTML = (d.notes || []).length
      ? d.notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("")
      : "<li>接口未返回额外说明。</li>";

    // 处置清单 + 检查项（来自真实指标；空库会明确提示“无运行数据”）
    var act = d.actions || {}, list = act.actions || [];
    var hp = $("ops-health-pill");
    if (hp) {
      var st0 = act.status || "unknown";
      hp.textContent = st0 === "critical" ? "需要立即处理" : st0 === "warning" ? "需要关注" : "未见高优先级异常";
      hp.className = "ops-pill " + (st0 === "critical" ? "err" : st0 === "warning" ? "warn" : "ok");
    }
    var av = $("ops-actions");
    if (av) {
      av.innerHTML = list.length
        ? list.map(function (a) {
            return '<div class="sd-action" style="border:1px solid #EBEDF0;border-radius:8px;padding:10px 12px;margin-bottom:8px">' +
              '<div><span class="ops-pill ' + (a.severity === "critical" ? "err" : a.severity === "warning" ? "warn" : "") + '">' +
              esc(a.severity === "critical" ? "高优先级" : a.severity === "warning" ? "需关注" : "提示") + '</span> ' +
              '<b>' + esc(a.area || "") + " · " + esc(a.title || "") + '</b></div>' +
              '<div class="ops-muted" style="margin-top:4px">' + esc(a.detail || "") + '</div>' +
              (a.evidence ? '<div class="ops-mono" style="margin-top:4px">证据：' + esc(a.evidence) + '</div>' : "") +
              '<div class="ops-muted" style="margin-top:4px">建议：' + esc(a.action || "") +
              (a.command ? ' · 命令 <span class="ops-mono">' + esc(a.command) + '</span>' : "") + '</div></div>';
          }).join("")
        : '<div class="ops-muted">未发现高优先级异常；继续看下方证据，不要用空指标代替健康结论。</div>';
    }
    var cv = $("ops-checks");
    if (cv) {
      cv.innerHTML = (act.checks || []).length
        ? act.checks.map(function (c) {
            return "<tr><td>" + esc(c.label || "") + "</td><td>" + (c.status === "ok" ? pill("正常", "ok") : c.status === "critical" ? pill("异常", "err") : pill("关注", "warn")) +
              "</td><td>" + esc(c.value == null ? "—" : c.value) + "</td><td class='ops-muted'>" + esc(c.action || "—") + "</td></tr>";
          }).join("")
        : "<tr><td colspan='4' class='ops-muted'>暂无检查项</td></tr>";
    }

    // 备份依据：只读文件检测（最新文件 mtime/大小），不发起备份、不校验内容哈希
    var bk = d.backup || {};
    var bs = $("ops-backup-state");
    if (bs) {
      bs.textContent = bk.latest ? "有可用备份" : "无可用备份";
      bs.className = "ops-pill " + (bk.latest ? "ok" : "err");
    }
    var bl = $("ops-backup-line"), be = $("ops-backup-extra");
    if (bl) {
      bl.innerHTML = bk.latest
        ? "最新备份 <b>" + esc(bk.latest) + "</b> · " + esc(bk.latest_at || "—") + " · " + fmtBytes(bk.size_bytes) +
          (bk.age_hours != null ? " · " + esc(bk.age_hours) + " 小时前" : "")
        : '<span class="ops-null">未发现备份文件</span>（不伪造“已备份”）';
    }
    if (be) {
      be.innerHTML = "目录 " + esc(bk.dir || "—") + " · 备份文件数 " + esc(bk.count == null ? "—" : bk.count) +
        " · 判定依据：存在 size>0 的 .db 文件按 mtime 取最新，不校验内容哈希/可恢复性（可用 <span class='ops-mono'>rp db check</span> 验证）" +
        ((bk.legacy_locations || []).length ? "<br>非规范目录备份：" + (bk.legacy_locations || []).map(esc).join("、") : "");
    }

    // 数据来源与时间窗
    var src = d.sources || {}, tw = d.time_window || {};
    var sv2 = $("ops-sources");
    if (sv2) {
      var keys = Object.keys(src);
      sv2.innerHTML = keys.length
        ? keys.map(function (k) {
            var x = src[k] || {};
            return "<tr><td><b>" + esc(k) + "</b></td><td class='ops-muted'>" + esc(x.source || "—") + "</td><td class='ops-muted'>" +
              esc(x.window || "—") + "</td><td class='ops-muted'>" + esc(x.basis || x.note || "—") + "</td></tr>";
          }).join("")
        : "<tr><td colspan='4' class='ops-muted'>接口未返回数据来源说明</td></tr>";
    }
    var wv = $("ops-window");
    if (wv) {
      wv.textContent = "生成时间 " + (tw.generated_at || d.generated_at || "—") +
        " · 模型 24h=" + (tw.model_24h || "近 24 小时") + " · 错误=" + (tw.errors || "最近 20 条") +
        " · 队列=" + (tw.queue || "当前") + " · 备份=" + (tw.backup || "最近备份文件");
    }
    lastAt = d.generated_at || "";
    setError("");
  }

  async function load() {
    var btn = $("ops-refresh");
    btn.disabled = true;
    btn.textContent = "刷新中…";
    try {
      var r = await fetch("/api/v1/ops/overview", {credentials: "same-origin", cache: "no-store"});
      var d = await r.json().catch(function () { return {}; });
      if (!r.ok) {
        setError("HTTP " + r.status + "：" + (d.error || "读取失败") + "（仅系统管理员 / 平台运营可查看）");
        return;
      }
      render(d);
    } catch (e) {
      setError("请求失败：" + (e && e.message ? e.message : String(e)));
    } finally {
      btn.disabled = false;
      btn.textContent = "刷新";
    }
  }
  // ================= L14 A1：智能体健康 tab（GET /api/v1/agents/health，只读） =================
  var activeTab = "overview";
  function switchTab(name) {
    activeTab = name === "agents" ? "agents" : "overview";
    var tabs = document.querySelectorAll(".ops-tab");
    for (var i = 0; i < tabs.length; i++) {
      var on = tabs[i].getAttribute("data-tab") === activeTab;
      tabs[i].className = "ops-tab" + (on ? " active" : "");
      tabs[i].setAttribute("aria-selected", on ? "true" : "false");
    }
    var ov = $("ops-tab-overview"), ag = $("ops-tab-agents");
    if (ov) ov.hidden = activeTab !== "overview";
    if (ag) ag.hidden = activeTab !== "agents";
    if (activeTab === "agents") loadAgentsHealth();
  }
  function fmtMs(v) {
    if (v == null) return '<span class="ops-null">—（无数据）</span>';
    return esc(v + " ms");
  }
  function fmtRate(v) {
    if (v == null) return '<span class="ops-null">—（无数据）</span>';
    var pct = (Number(v) * 100).toFixed(2) + "%";
    var cls = Number(v) >= 0.95 ? "ok" : (Number(v) >= 0.8 ? "warn" : "err");
    return pill(pct, cls);
  }
  function renderAgents(d) {
    var s = d.summary || {}, list = d.agents || [];
    var st = $("ops-agents-state");
    if (st) {
      st.textContent = s.empty_state ? "无运行数据（空态）" : "正常";
      st.className = "ops-pill " + (s.empty_state ? "warn" : "ok");
    }
    var sum = $("ops-agents-summary");
    if (sum) {
      sum.innerHTML = "扫描运行 <b>" + esc(s.runs_scanned == null ? 0 : s.runs_scanned) + "</b> 条" +
        "（全库 " + esc(s.runs_total == null ? 0 : s.runs_total) + " 条，窗口 limit=" + esc(s.limit == null ? "—" : s.limit) + "）" +
        " · 时间窗 " + (s.since ? esc(s.since) + " ~ " + esc(s.until || s.since) : '<span class="ops-null">—（无运行）</span>') +
        " · Tokens 可归属 <b>" + esc(s.token_attributed_runs == null ? 0 : s.token_attributed_runs) + "</b> 条" +
        (s.token_attribution_rate != null ? "（" + esc((Number(s.token_attribution_rate) * 100).toFixed(1)) + "%）" : "") +
        (s.unregistered_runs ? " · 未登记运行 " + esc(s.unregistered_runs) + " 条" : "");
    }
    var rows = $("ops-agents-rows");
    if (rows) {
      rows.innerHTML = list.length ? list.map(function (a) {
        var fails = (a.top_failures || []).length
          ? (a.top_failures || []).map(function (f) {
              return '<div class="ops-mono">' + esc(f.reason || "unknown") + " ×" + esc(f.count) + "</div>";
            }).join("")
          : '<span class="ops-muted">—（无失败）</span>';
        var tokens = a.token_runs
          ? esc(a.tokens_in + " / " + a.tokens_out) + ' <span class="ops-muted">(' + esc(a.llm_calls || 0) + " 次调用)</span>"
          : '<span class="ops-null">—（无归属）</span>';
        return "<tr><td><b>" + esc(a.name || a.agent_id) + "</b>" +
          '<div class="ops-muted ops-mono">' + esc(a.agent_id || "") + " · " + esc(a.capability || "") + "</div></td>" +
          "<td>" + esc(a.runs || 0) + '<div class="ops-muted">ok ' + esc(a.success || 0) +
          " / degraded " + esc(a.degraded || 0) + " / fail " + esc(a.failure || 0) + "</div></td>" +
          "<td>" + fmtRate(a.success_rate) + "</td>" +
          "<td>" + fmtMs(a.p50_ms) + "</td>" +
          "<td>" + fmtMs(a.p95_ms) + "</td>" +
          "<td>" + tokens + "</td>" +
          "<td>" + fails + "</td></tr>";
      }).join("") : "<tr><td colspan='7' class='ops-muted'>无智能体登记（不应发生：7 行由 AGENT_META 固定返回）</td></tr>";
    }
    var notes = $("ops-agents-notes");
    if (notes) {
      notes.innerHTML = (d.notes || []).length
        ? (d.notes || []).map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("")
        : "<li>接口未返回口径说明。</li>";
    }
  }
  async function loadAgentsHealth() {
    var st = $("ops-agents-state");
    if (st) { st.textContent = "读取中"; st.className = "ops-pill"; }
    try {
      var r = await fetch("/api/v1/agents/health?limit=5000", {credentials: "same-origin", cache: "no-store"});
      var d = await r.json().catch(function () { return {}; });
      if (!r.ok) {
        if (st) { st.textContent = "读取失败"; st.className = "ops-pill err"; }
        var sum = $("ops-agents-summary");
        if (sum) sum.textContent = "HTTP " + r.status + "：" + (d.error || "读取失败（仅管理员/平台权限可查看）");
        var rows = $("ops-agents-rows");
        if (rows) rows.innerHTML = "<tr><td colspan='7' class='ops-muted'>无法读取智能体健康数据</td></tr>";
        var notes = $("ops-agents-notes");
        if (notes) notes.innerHTML = "<li>" + esc(d.error || "读取失败") + "</li>";
        return;
      }
      renderAgents(d);
    } catch (e) {
      if (st) { st.textContent = "请求失败"; st.className = "ops-pill err"; }
      var sum2 = $("ops-agents-summary");
      if (sum2) sum2.textContent = "请求失败：" + (e && e.message ? e.message : String(e));
    }
  }
  var tabsEl = $("ops-tabs");
  if (tabsEl) {
    tabsEl.addEventListener("click", function (ev) {
      var t = ev.target && ev.target.getAttribute ? ev.target : null;
      while (t && t !== tabsEl && t.getAttribute("data-tab") == null) { t = t.parentNode; }
      if (t && t !== tabsEl) switchTab(t.getAttribute("data-tab"));
    });
  }
  $("ops-refresh").addEventListener("click", function () {
    if (activeTab === "agents") loadAgentsHealth(); else load();
  });
  load();
  setInterval(function () {
    if (activeTab === "agents") loadAgentsHealth();
  }, 30000);
})();
