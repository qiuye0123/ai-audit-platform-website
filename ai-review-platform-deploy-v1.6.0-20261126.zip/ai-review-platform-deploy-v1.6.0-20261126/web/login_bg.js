/* 登录页浅蓝光场：近白中心 + 极浅蓝四周 + 柔和光斑 + 极淡粒子。
 * 独立 Canvas，不依赖 app.js。
 * - 保留 prefers-reduced-motion 降级（只画一帧静态画面，不启动 rAF 循环）
 * - 保留原有性能量级：节点/星尘/光线数量公式与 28ms 抽帧节奏不变，仅换配色与光源形态
 * - 入口选择页（/login，login.html 不在本次写作用域内）由本文件注入作用域限定样式补齐浅色
 */
(function () {
  if (window.__loginNebula) return;
  window.__loginNebula = true;

  /* ---------- 入口选择页：浅蓝主题（仅作用于 body 内含 .portal 的页面） ---------- */
  function injectPortalTheme() {
    try {
      if (!document.querySelector(".portal")) return;
      var html = document.documentElement;
      html.setAttribute("data-lb-portal", "");
      if (document.getElementById("lb-portal-theme")) return;
      var s = document.createElement("style");
      s.id = "lb-portal-theme";
      s.textContent =
        ':root[data-lb-portal]{--bg:#F7F9FC;--surface:rgba(255,255,255,.92);--surface-2:#FFFFFF;' +
        '--line:#E3E8EF;--line-strong:#C9D6EC;--ink:#1F1F1F;--body:#3C4043;--muted:#5F6368;--blue:#1967D2}' +
        'html[data-lb-portal] body{background:' +
        'radial-gradient(1100px 640px at 50% -8%,#FFFFFF 0%,rgba(255,255,255,0) 64%),' +
        'radial-gradient(900px 520px at 88% 6%,#E8F1FE 0%,rgba(232,241,254,0) 68%),' +
        'linear-gradient(180deg,#F7F9FC 0%,#EEF3FB 100%);color:#1F1F1F}' +
        'html[data-lb-portal] .mark{background:rgba(26,115,232,.08);border-color:#C9D6EC;color:#1967D2}' +
        'html[data-lb-portal] .eyebrow{color:#1967D2}' +
        'html[data-lb-portal] .lead{color:#3C4043}' +
        'html[data-lb-portal] .portal{background:#FFFFFF;border-color:#E8EDF5;border-radius:18px;' +
        'box-shadow:0 1px 2px rgba(60,64,67,.08)}' +
        'html[data-lb-portal] .portal:hover{background:#FFFFFF;border-color:#A8C7FA;' +
        'box-shadow:0 10px 30px rgba(26,115,232,.14)}' +
        'html[data-lb-portal] .portal p{color:#3C4043}' +
        'html[data-lb-portal] .portal .num{color:#5F6368}' +
        'html[data-lb-portal] .portal .test-account{background:#F7F9FC;border-color:#E8EDF5}' +
        'html[data-lb-portal] .portal .test-account b{color:#3C4043}' +
        'html[data-lb-portal] .portal .enter{color:#1967D2;border-top-color:#EFF3F9}' +
        'html[data-lb-portal] .portal .enter span{color:#5F6368}' +
        'html[data-lb-portal] footer .rule{background:#E3E8EF}' +
        'html[data-lb-portal] :focus-visible{outline:2px solid #1A73E8;outline-offset:2px}';
      (document.head || document.documentElement).appendChild(s);
    } catch (_) {}
  }
  injectPortalTheme();

  const canvas = document.createElement("canvas");
  canvas.id = "login-nebula";
  canvas.setAttribute("aria-hidden", "true");
  canvas.style.cssText = "position:fixed;inset:0;width:100%;height:100%;z-index:0;pointer-events:none;background:#F7F9FC";
  document.body.insertBefore(canvas, document.body.firstChild);
  const ctx = canvas.getContext("2d", { alpha: false });
  const forceMotion = new URLSearchParams(location.search).has("motion");
  const reduced = !forceMotion && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let W = 0, H = 0, DPR = 1, cx = 0, cy = 0;
  let nodes = [], stars = [], neighbors = [], rays = [], orbs = [];
  let mouse = { x: .5, y: .5, tx: .5, ty: .5 }, last = 0, tick = 0;
  /* 浅蓝白系配色：深蓝只做极少量点缀，整体不超过中低饱和 */
  const PALETTE = ["#7FA6E8", "#A8C7FA", "#5B8DEF", "#9DC2FF", "#C7D9F5", "#8FB7F5"];

  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    cx = W * .52; cy = H * .46;
    canvas.width = Math.floor(W * DPR); canvas.height = Math.floor(H * DPR);
    canvas.style.width = W + "px"; canvas.style.height = H + "px";
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);

    // 三维位置：横向铺满屏幕，深度 ±900，中心区域偏亮
    const count = Math.max(300, Math.min(820, Math.round(W * H / 1050)));
    nodes = [];
    for (let i = 0; i < count; i++) {
      const x = rand(-W * .72, W * .72);
      const y = rand(-H * .68, H * .68);
      const z = rand(-760, 760);
      const near = Math.hypot(x / (W * .42), y / (H * .42), z / 900) < 1.15;
      const warm = near && Math.random() < .62 || Math.random() < .27;
      nodes.push({
        x, y, z, vx: rand(-.055, .055), vy: rand(-.045, .045), vz: rand(-.10, .10),
        r: warm ? rand(1.0, 2.6) : rand(.45, 1.35),
        warm, a: warm ? rand(.30, .62) : rand(.10, .32),
        phase: rand(0, Math.PI * 2),
      });
    }
    // 预计算三维近邻，绘制时只连线，不每帧 O(n²)
    neighbors = nodes.map(() => []);
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i], arr = [];
      for (let j = 0; j < nodes.length; j++) {
        if (i === j) continue;
        const b = nodes[j];
        const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
        arr.push([dx * dx + dy * dy + dz * dz, j]);
      }
      arr.sort((p, q) => p[0] - q[0]);
      neighbors[i] = [arr[0][1], arr[1][1], arr[2][1], arr[3][1], arr[4][1], arr[5][1]];
    }
    stars = [];
    const sc = Math.min(1000, Math.round(W * H / 1800));
    for (let i = 0; i < sc; i++) stars.push({ x: rand(-W * .8, W * .8), y: rand(-H * .8, H * .8), z: rand(-900, 900), r: rand(.25, 1.05), a: rand(.025, .13) });
    // 光线：极淡浅蓝细丝，向外缓慢扩散
    rays = [];
    for (let i = 0; i < 190; i++) rays.push({ a: rand(0, Math.PI * 2), r: rand(8, Math.min(W, H) * .55), speed: rand(.55, 1.6), len: rand(30, 110), w: rand(.3, 1.4), hue: Math.random() < .7 ? "124,166,232" : "168,199,250" });
    // 柔和光斑：大半径、低透明度，缓慢漂移
    orbs = [];
    const orbCount = W < 720 ? 4 : 6;
    for (let i = 0; i < orbCount; i++) {
      orbs.push({
        x: rand(.08, .92) * W, y: rand(.06, .94) * H,
        r: rand(.22, .46) * Math.max(W, H),
        ax: rand(18, 52), ay: rand(14, 40), ph: rand(0, Math.PI * 2),
        sp: rand(.00010, .00024),
        tint: i % 3 === 0 ? "255,255,255" : (i % 3 === 1 ? "168,199,250" : "224,236,255"),
        a: i % 3 === 0 ? rand(.30, .48) : rand(.14, .26),
      });
    }
    if (reduced) draw(0);
  }

  function project(n, t) {
    // 缓慢绕 Y 轴旋转，再轻微绕 X 轴俯仰；深度做透视
    const ay = (t || 0) * 0.000024 + 0.20;
    const ax = Math.sin((t || 0) * 0.000018) * 0.10;
    const cyr = Math.cos(ay), syr = Math.sin(ay);
    const x1 = n.x * cyr - n.z * syr;
    const z1 = n.x * syr + n.z * cyr;
    const y1 = n.y * Math.cos(ax) - z1 * Math.sin(ax);
    const z2 = n.y * Math.sin(ax) + z1 * Math.cos(ax);
    const p = 980 / (980 + z2);
    return { x: cx + x1 * p + (mouse.x - .5) * 22 * p, y: cy + y1 * p + (mouse.y - .5) * 14 * p, s: p, z: z2 };
  }

  function glow(x, y, r, inner, mid, outer) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, inner); g.addColorStop(.35, mid); g.addColorStop(1, outer);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }

  function draw(t) {
    t = t || 0;
    // 浅蓝白底色：中心近白，四周极浅蓝
    const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * .78);
    bg.addColorStop(0, "#FFFFFF"); bg.addColorStop(.45, "#F7F9FC"); bg.addColorStop(1, "#E9F1FB");
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

    // 柔和光斑：缓慢漂移的浅蓝/近白光团
    for (let i = 0; i < orbs.length; i++) {
      const o = orbs[i];
      const ox = o.x + Math.cos(t * o.sp + o.ph) * o.ax;
      const oy = o.y + Math.sin(t * o.sp * .8 + o.ph) * o.ay;
      glow(ox, oy, o.r, `rgba(${o.tint},${o.a})`, `rgba(${o.tint},${o.a * .45})`, `rgba(${o.tint},0)`);
    }

    // 中心呼吸光晕：极淡，不刺眼
    const pulse = 1 + Math.sin(t / 2600) * .05;
    glow(cx, cy, Math.min(W, H) * .46 * pulse, "rgba(255,255,255,.85)", "rgba(168,199,250,.16)", "rgba(168,199,250,0)");
    glow(cx, cy, Math.min(W, H) * .14 * pulse, "rgba(255,255,255,.92)", "rgba(168,199,250,.24)", "rgba(168,199,250,0)");

    // 光线：浅蓝细丝，无限向外扩散，越远越淡
    ctx.globalCompositeOperation = "source-over";
    for (let i = 0; i < rays.length; i++) {
      const q = rays[i];
      if (!reduced) { q.r += q.speed; if (q.r > Math.min(W, H) * .58) { q.r = rand(6, 20); q.a = rand(0, Math.PI * 2); } }
      const k = clamp(1 - q.r / (Math.min(W, H) * .58), 0, 1);
      const x1 = cx + Math.cos(q.a) * q.r, y1 = cy + Math.sin(q.a) * q.r;
      const x2 = cx + Math.cos(q.a) * (q.r + q.len), y2 = cy + Math.sin(q.a) * (q.r + q.len);
      ctx.strokeStyle = `rgba(${q.hue},${(.006 + .042 * k)})`;
      ctx.lineWidth = q.w * (.5 + k * 1.3);
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    }

    // 星尘（带视差和深度）：极淡浅蓝点
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i], p = project(s, t);
      if (p.z < -940 || p.z > 940) continue;
      ctx.globalAlpha = s.a * clamp(p.s, .25, 1.8);
      ctx.fillStyle = i % 8 === 0 ? "#7FA6E8" : "#9FB6D8";
      ctx.beginPath(); ctx.arc(p.x, p.y, s.r * p.s, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;

    if (!reduced) {
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        n.x += n.vx; n.y += n.vy; n.z += n.vz;
        if (n.x < -W * .8) n.x = W * .8; else if (n.x > W * .8) n.x = -W * .8;
        if (n.y < -H * .8) n.y = H * .8; else if (n.y > H * .8) n.y = -H * .8;
        if (n.z < -980) n.z = 980; else if (n.z > 980) n.z = -980;
      }
    }

    const pts = nodes.map(n => project(n, t));
    // 连线：近邻、正交投影后仍保持网络；线宽随深度，颜色为极淡蓝
    ctx.lineCap = "round";
    for (let i = 0; i < nodes.length; i++) {
      const a = pts[i];
      for (let k = 0; k < neighbors[i].length; k++) {
        const j = neighbors[i][k]; if (j <= i) continue;
        const b = pts[j];
        const alpha = clamp((1 - Math.abs(a.z - b.z) / 1200) * .055, .010, .055);
        const nearCore = clamp(1 - Math.hypot((a.x - cx) / (W * .42), (a.y - cy) / (H * .42)), 0, 1);
        const warm = nodes[i].warm || nodes[j].warm || nearCore > .55;
        ctx.strokeStyle = warm ? `rgba(91,141,239,${alpha + nearCore * .018})` : `rgba(150,178,214,${alpha * .7})`;
        ctx.lineWidth = clamp((a.s + b.s) * .5, .25, 1.1);
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      }
    }

    // 节点：浅蓝小点，靠中心略亮
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i], p = pts[i];
      if (p.z < -940 || p.z > 940) continue;
      const breathe = .9 + .1 * Math.sin(t / 1300 + n.phase);
      const nearCore = clamp(1 - Math.hypot((p.x - cx) / (W * .45), (p.y - cy) / (H * .45)), 0, 1);
      const warm = n.warm || nearCore > .58;
      const rr = n.r * clamp(p.s, .35, 1.9) * breathe;
      if (warm) glow(p.x, p.y, rr * 6.5, `rgba(255,255,255,${.55 * n.a})`, `rgba(168,199,250,${.30 * n.a})`, "rgba(168,199,250,0)");
      ctx.globalAlpha = clamp(n.a * (.45 + nearCore * .5), .07, .52);
      ctx.fillStyle = warm ? (i % 3 === 0 ? "#A8C7FA" : PALETTE[i % 3]) : (i % 4 === 0 ? "#C7D9F5" : "#9FB6D8");
      ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(.35, rr), 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;

    // 中心柔和星芒（极淡）
    const ray = Math.min(W, H) * .12;
    const g = ctx.createLinearGradient(cx - ray, cy, cx + ray, cy);
    g.addColorStop(0, "rgba(168,199,250,0)"); g.addColorStop(.5, "rgba(255,255,255,.34)"); g.addColorStop(1, "rgba(168,199,250,0)");
    ctx.strokeStyle = g; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx - ray, cy); ctx.lineTo(cx + ray, cy); ctx.stroke();
    const g2 = ctx.createLinearGradient(cx, cy - ray * .7, cx, cy + ray * .7);
    g2.addColorStop(0, "rgba(168,199,250,0)"); g2.addColorStop(.5, "rgba(168,199,250,.14)"); g2.addColorStop(1, "rgba(168,199,250,0)");
    ctx.strokeStyle = g2; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(cx, cy - ray * .7); ctx.lineTo(cx, cy + ray * .7); ctx.stroke();
  }

  function loop(t) {
    if (!reduced && t - last > 28) { last = t; tick = t; mouse.x += (mouse.tx - mouse.x) * .04; mouse.y += (mouse.ty - mouse.y) * .04; draw(t); }
    requestAnimationFrame(loop);
  }
  window.addEventListener("resize", resize, { passive: true });
  window.addEventListener("pointermove", e => { mouse.tx = e.clientX / Math.max(1, W); mouse.ty = e.clientY / Math.max(1, H); }, { passive: true });
  resize();
  if (!reduced) requestAnimationFrame(loop);
})();
