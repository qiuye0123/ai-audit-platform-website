# AI 审核平台「金规」 · v1.6.0

> 规则驱动的企业文档审核平台：**规则可运营、结论可追溯、证据可回查、人工必须签字**。
> 不是把文件丢给大模型：标准先变成可执行规则，冻结成本次清单，再逐条给出带回原文证据的结论。

## 版本与当前状态

- 产品版本：**1.6.0**（`VERSION`）
- 代码/文档收口：2026-11-26
- 全量 gate：**415 条**（414 静态 + 1 条真实 LLM；唯一脚本 413；包内按环境 SKIP 20 条）
- 四角色 E2E：**328/328 PASS**（L172，临时库 + 交付包，连跑两次）
- 架构图：正式图库为 **浅色 21 张**（`web/architecture/html`，v4.5 / 1.6.0）
- 最终交付包 SHA256：以 `docs/qa/artifacts/RELEASES.md` 1.6.0 行和包外 `.zip.sha256` 为唯一权威

> 本 README 只承诺已验证事实。客户真实 gold、正式 clean-control、OCR 质量、云端 Docker 构建/多副本 HA 尚未验证，不对外承诺商业 SLA/零误报。

## 30 秒启动（开发/演示）

```bash
cp .env.example .env
export RULEPROOF_ENV=dev
export RULEPROOF_SESSION_SECRET="$(python3 -c 'import secrets;print(secrets.token_urlsafe(32))')"
./rp --db data/ruleproof.db init
./rp --db data/ruleproof.db serve     # 或 ./start.sh
# → http://127.0.0.1:8765
```

演示账号（仅 dev/演示库）：审核员 `13700002222 / Rev@123456`；业务管理员 `13500001111 / Acme@123456`；平台运营 `13600003333 / Plat@123456`；系统管理员 `13800000000`（首次登录强制改密，密码以 seed 输出为准）。

## 生产部署

- Docker 部署入口：`deploy/README.md`；生产配置示例：`deploy/.env.production.example`
- 裸机 systemd：`deploy/install-baremetal.sh`
- 模型/OCR 接入：`deploy/模型接入说明.md`
- 默认不调外部模型；无 Key 时确定性规则/解析/门禁/报告/CLI 可用，语义/OCR/智能体模型节点显式降级，不伪造通过。

## 文件与上限

- 新建项目审核仅支持 **PDF / DOCX / XLSX**（服务端 magic-byte 校验；`.xls`、PPTX/TXT/MD/CSV/JSON/图片/EML 不接受）
- 知识库支持更多格式，但知识库文件**不进入项目审核主链**
- 默认单项目最多 **10 份**（`RULEPROOF_MAX_FILES` 可配，下限 3；通常 1–3 份）；单份 ≤100MB，项目合计 ≤300MB
- 报告导出 HTML/DOCX；PDF 报告导出已移除（原始 PDF 上传/预览保留）

## 主链

```text
建项目 → 上传 → 解析 → manifest 冻结 → D1 适用性 → D2 规则版本 → D3 证据绑定
→ D4 子要求执行 → D5 五态组合 → finding/证据 → 人工复核 → 报告门禁 → HTML/DOCX
→ 反馈沉淀 → 规则候选/回放/回滚
```

五态：`pass / fail / na / insufficient / unknown`；unknown 不合并为 pass。

## 目录

- `app/` 服务层/引擎/API/CLI；`web/` 四端前端与浅色 21 张架构图；`rp` 原生 CLI
- `tests/`、`scripts/qa/` 测试与门禁；`deploy/` 部署
- `docs/CURRENT/` 当前规范/状态；`docs/交付/` 1.6.0 交付资料；`docs/qa/` 证据/报告
- 人工阅读入口：`docs/交付/文档总清单_1.6.0_20261126.xlsx`

## 已知边界

- 客户真实数据准确率、369 份正式 clean-control 未取得；挑战集仅工程定位，未计算 95% CI/δ_min
- 扫描件 OCR 质量未测；无 OCR Key 显式降级
- Docker 镜像/阿里云部署未在本轮实测；部署后必须跑 PDF 预览、四角色登录、备份恢复
- SQLite 单机、单进程，适合试点/中小并发；不是 HA/多副本方案
- 历史 QA 证据保持原版本，不回写；正式文档以 1.6.0 版本为准
