#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Webhook 验签示例（与 app/services/open.py 的签名算法一致）。

平台签名串：HMAC-SHA256(secret, app_key + timestamp + nonce + raw_body)
请求头：X-App-Key / X-Timestamp / X-Nonce / X-Signature（hex）

用法：
    python3 sdk/python/examples/verify_webhook.py \
      --secret "$APP_SECRET" --app-key "$APP_KEY" \
      --timestamp "$X_TIMESTAMP" --nonce "$X_NONCE" \
      --signature "$X_SIGNATURE" --body-file payload.json

退出码：0=有效，1=无效/缺参，2=时间戳超出窗口（可配 --max-skew）。
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import sys
import time
from pathlib import Path


def canonical(app_key: str, timestamp: str, nonce: str, body: bytes) -> bytes:
    return (str(app_key) + str(timestamp) + str(nonce)).encode("utf-8") + body


def verify(secret: str, app_key: str, timestamp: str, nonce: str,
           body: bytes, signature: str) -> bool:
    expected = hmac.new(
        str(secret).encode("utf-8"),
        canonical(app_key, timestamp, nonce, body),
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, str(signature or "").strip().lower())


def main() -> int:
    parser = argparse.ArgumentParser(description="规衡开放平台 Webhook 验签")
    parser.add_argument("--secret", required=True, help="AppSecret（只走参数/环境变量，不要入库）")
    parser.add_argument("--app-key", required=True)
    parser.add_argument("--timestamp", required=True)
    parser.add_argument("--nonce", required=True)
    parser.add_argument("--signature", required=True)
    parser.add_argument("--body-file", default="", help="原始 body 文件；留空从 stdin 读")
    parser.add_argument("--max-skew", type=int, default=300, help="允许的时间窗秒数，默认 300")
    args = parser.parse_args()

    if args.body_file:
        body = Path(args.body_file).read_bytes()
    else:
        body = sys.stdin.buffer.read()

    try:
        skew = abs(time.time() - int(args.timestamp))
    except (TypeError, ValueError):
        print(json.dumps({"valid": False, "reason": "timestamp_not_integer"},
                         ensure_ascii=False))
        return 1
    if args.max_skew > 0 and skew > args.max_skew:
        print(json.dumps({"valid": False, "reason": "timestamp_out_of_window",
                          "skew": int(skew), "max_skew": args.max_skew},
                         ensure_ascii=False))
        return 2

    ok = verify(args.secret, args.app_key, args.timestamp, args.nonce,
                body, args.signature)
    print(json.dumps({"valid": bool(ok), "body_bytes": len(body)},
                     ensure_ascii=False))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
