#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读示例：登录 → 看身份 → 项目/规则 → 发现/报告状态。

运行前设置（不要把真实密码写进代码）：
    export RULEPROOF_BASE_URL=http://127.0.0.1:8765
    export RULEPROOF_ACCOUNT=13700002222
    export RULEPROOF_PASSWORD='Rev@123456'
    export RULEPROOF_PORTAL=reviewer

然后：
    PYTHONPATH=sdk/python python3 sdk/python/examples/quickstart.py
"""
from __future__ import annotations

import os
import sys

# 允许直接从仓库根目录运行，不需要安装
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ruleproof_client import RuleProofClient  # noqa: E402


def main() -> int:
    client = RuleProofClient.from_env()
    client.login_from_env()
    user = client.me()
    print("登录：%s（%s）" % (user.get("name"), user.get("role")))

    perms = client.permissions()
    print("动作权限：%s" % ", ".join(perms.get("actions") or []))

    projects = client.list_projects(page=1, page_size=5)
    print("项目：total=%s page=%s/%s" % (projects.total, projects.page, projects.pages))
    for p in projects.items:
        print("  - %s  %s  %s" % (p.get("id"), p.get("name"), p.get("status")))

    rules = client.list_rules(page=1, page_size=5)
    print("规则：total=%s" % rules.total)
    for r in rules.items[:3]:
        print("  - %s  %s  %s" % (r.get("code"), r.get("name"), r.get("status")))

    if not projects.items:
        print("没有项目；跳过发现/报告示例。")
        return 0

    case_id = projects.items[0]["id"]
    findings = client.list_findings(case_id)
    print("发现：total=%s（服务端全量）" % findings.total)
    for f in findings.items[:3]:
        print("  - %s  %s  %s" % (f.get("id"), f.get("severity"), f.get("title")))

    status = client.report_status(case_id)
    print("报告：can_generate=%s generated=%s stale=%s" % (
        status.get("can_generate"), status.get("generated"), status.get("stale")))
    if status.get("reasons"):
        print("门禁原因：")
        for reason in status["reasons"]:
            print("  - %s" % reason)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # 示例：打印可读错误，不吞掉
        print("失败：%s: %s" % (type(exc).__name__, exc), file=sys.stderr)
        raise SystemExit(1)
