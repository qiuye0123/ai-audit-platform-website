#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""规衡 AI 审核平台 · 官方最小 Python SDK（仅标准库）。

设计目标：
- 真实 HTTP，不封装假数据；不依赖 pypi 包；
- 登录使用服务端下发的 ``rp_session`` HttpOnly Cookie；
  也允许把同一 JWT 作为 ``session_token`` 显式传入（不是独立 Bearer 认证）；
- 兼容平台当前的三种列表返回：项目信封、规则“数组/信封”双形态、发现全量；
- 把 HTTP 错误映射为带 ``status/code/request_id`` 的异常，便于调用方分支；
- GET 支持有限重试，POST 不自动重试（避免重复建项目/重复复核）。

兼容 Python 3.9+。用法见同目录 README.md 与 examples/quickstart.py。
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from http.cookiejar import CookieJar
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple, Union

__version__ = "0.1.0"
__all__ = [
    "RuleProofClient",
    "Page",
    "RuleProofError",
    "APIError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ValidationError",
    "ConflictError",
    "RateLimitError",
    "ServerError",
    "APIConnectionError",
    "APITimeoutError",
    "APIResponseError",
]

DEFAULT_BASE_URL = "http://127.0.0.1:8765"
DEFAULT_TIMEOUT = 20.0
COOKIE_NAME = "rp_session"
USER_AGENT = "ruleproof-python-sdk/" + __version__
_RETRYABLE_STATUS = {429, 500, 502, 503, 504}
_DECISIONS = ("confirmed", "false_positive", "need_evidence")


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------
class RuleProofError(Exception):
    """SDK 所有异常的基类。"""


class APIError(RuleProofError):
    """服务端返回了非 2xx，或 2xx 但 body 明确包含 error。"""

    def __init__(
        self,
        status: int,
        message: str,
        *,
        code: str = "",
        payload: Any = None,
        request_id: str = "",
        method: str = "",
        path: str = "",
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(message)
        self.status = int(status)
        self.message = str(message)
        self.code = str(code or "")
        self.payload = payload
        self.request_id = str(request_id or "")
        self.method = str(method or "").upper()
        self.path = str(path or "")
        self.retry_after = retry_after

    @property
    def retryable(self) -> bool:
        """是否值得由调用方/客户端重试；仅 GET 会自动重试。"""
        return self.status in _RETRYABLE_STATUS

    def __str__(self) -> str:
        bits = []
        if self.method or self.path:
            bits.append(f"{self.method} {self.path}".strip())
        bits.append(f"HTTP {self.status}")
        if self.code:
            bits.append(self.code)
        bits.append(self.message)
        text = " · ".join(bits)
        if self.request_id:
            text += f" · request_id={self.request_id}"
        return text


class ValidationError(APIError):
    """HTTP 400。"""


class AuthenticationError(APIError):
    """HTTP 401。"""


class PermissionDeniedError(APIError):
    """HTTP 403。"""


class NotFoundError(APIError):
    """HTTP 404。"""


class ConflictError(APIError):
    """HTTP 409（幂等冲突、报告门禁未过等）。"""


class RateLimitError(APIError):
    """HTTP 429。"""


class ServerError(APIError):
    """HTTP 5xx。"""


class APIConnectionError(RuleProofError):
    """网络层失败（DNS/连接拒绝/断连），不是服务端业务错误。"""

    def __init__(self, message: str, *, method: str = "", path: str = "") -> None:
        super().__init__(message)
        self.method = str(method or "").upper()
        self.path = str(path or "")


class APITimeoutError(APIConnectionError):
    """连接或读取超时。"""


class APIResponseError(RuleProofError):
    """2xx 但响应不是预期 JSON（或结构无法解析）。"""

    def __init__(self, message: str, *, status: int = 0, request_id: str = "",
                 path: str = "") -> None:
        super().__init__(message)
        self.status = int(status)
        self.request_id = str(request_id or "")
        self.path = str(path or "")


# ---------------------------------------------------------------------------
# 分页
# ---------------------------------------------------------------------------
@dataclass
class Page:
    """统一分页对象，兼容服务端数组/信封/全量三种返回。"""

    items: List[Dict[str, Any]] = field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 0
    pages: int = 1
    raw: Any = None

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        return self.items[index]

    @property
    def has_next(self) -> bool:
        return self.page < self.pages

    @property
    def next_page(self) -> Optional[int]:
        return self.page + 1 if self.has_next else None

    @classmethod
    def from_payload(cls, payload: Any, fallback_page: int = 1,
                     fallback_size: int = 20) -> "Page":
        if isinstance(payload, Page):
            return payload
        if isinstance(payload, list):
            items = payload
            total = len(items)
            size = int(fallback_size or len(items) or 1)
            return cls(items=list(items), total=total, page=1,
                       page_size=max(1, size), pages=1, raw=payload)
        if not isinstance(payload, dict):
            raise APIResponseError(
                "列表响应既不是数组也不是对象：%s" % type(payload).__name__)
        raw_items = payload.get("items")
        if raw_items is None:
            raw_items = []
        if not isinstance(raw_items, list):
            raise APIResponseError("列表响应 items 不是数组")
        try:
            total = int(payload.get("total", len(raw_items)) or 0)
        except (TypeError, ValueError):
            total = len(raw_items)
        try:
            page = int(payload.get("page") or fallback_page or 1)
        except (TypeError, ValueError):
            page = int(fallback_page or 1)
        try:
            size = int(payload.get("page_size") or fallback_size or len(raw_items) or 1)
        except (TypeError, ValueError):
            size = int(fallback_size or len(raw_items) or 1)
        size = max(1, size)
        try:
            pages = int(payload.get("pages") or 0)
        except (TypeError, ValueError):
            pages = 0
        if pages < 1:
            pages = max(1, (total + size - 1) // size)
        return cls(items=raw_items, total=total, page=page, page_size=size,
                   pages=pages, raw=payload)


# ---------------------------------------------------------------------------
# 客户端
# ---------------------------------------------------------------------------
class RuleProofClient:
    """规衡 AI 审核平台最小客户端。

    参数：
        base_url: 例如 ``http://127.0.0.1:8765``；不带尾部斜杠也可以。
        timeout: 单次 HTTP 操作超时（秒），默认 20。
        session_token: 已有的 ``rp_session`` JWT；与 ``cookie`` 二选一。
        cookie: 原始 Cookie 请求头（高级用法；与 ``session_token`` 二选一）。
        headers: 额外请求头（例如反向代理的 X-Forwarded-*）。
        max_retries: GET 在 429/5xx/网络错误时的最大重试次数，默认 2；POST 固定 0。
        backoff: 首次重试等待秒数，之后指数退避，默认 0.5。
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        session_token: Optional[str] = None,
        cookie: Optional[str] = None,
        headers: Optional[Mapping[str, str]] = None,
        max_retries: int = 2,
        backoff: float = 0.5,
    ) -> None:
        base = str(base_url or "").strip().rstrip("/")
        if not base:
            raise ValueError("base_url 不能为空")
        parsed = urllib.parse.urlsplit(base)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError("base_url 必须是 http(s)://host[:port]，当前：%r" % (base_url,))
        if session_token and cookie:
            raise ValueError("session_token 与 cookie 只能二选一，避免 Cookie 头重复")
        self.base_url = base
        self.timeout = float(timeout)
        if self.timeout <= 0:
            raise ValueError("timeout 必须大于 0")
        self.max_retries = max(0, int(max_retries))
        self.backoff = max(0.0, float(backoff))
        self._session_token = _clean_token(session_token)
        self._raw_cookie = _clean_cookie(cookie)
        self._headers: Dict[str, str] = {
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        }
        for key, value in (headers or {}).items():
            self._headers[str(key)] = _clean_header_value(str(value))
        self._jar = CookieJar()
        self._opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self._jar)
        )
        self.user: Optional[Dict[str, Any]] = None
        self.need_choose = False
        self.last_request_id = ""

    # -- 会话 --------------------------------------------------------------
    def login(self, account: str, password: str,
              portal: Optional[str] = None) -> Dict[str, Any]:
        """登录并保存服务端 Cookie；返回 user 对象。"""
        if not str(account or "").strip():
            raise ValueError("account 不能为空")
        body: Dict[str, Any] = {"account": str(account), "password": str(password)}
        if portal:
            if portal not in ("platform", "admin", "reviewer"):
                raise ValueError("portal 只能是 platform/admin/reviewer")
            body["portal"] = portal
        payload = self.request("POST", "/api/v1/auth/login", body=body)
        if not isinstance(payload, dict) or not isinstance(payload.get("user"), dict):
            raise APIResponseError("登录响应缺少 user 对象")
        self.user = payload["user"]
        self.need_choose = bool(payload.get("need_choose"))
        # 登录后优先使用 CookieJar 中的新会话，避免旧 token 覆盖新 Cookie。
        self._session_token = None
        self._raw_cookie = None
        return self.user

    def login_from_env(self, prefix: str = "RULEPROOF_") -> Dict[str, Any]:
        """从环境变量读取账号密码登录；密码不会写日志。"""
        account = os.environ.get(prefix + "ACCOUNT") or os.environ.get(prefix + "USERNAME")
        password = os.environ.get(prefix + "PASSWORD")
        portal = os.environ.get(prefix + "PORTAL") or None
        if not account or password is None:
            raise ValueError(
                "缺少 %sACCOUNT / %sPASSWORD 环境变量" % (prefix, prefix))
        return self.login(account, password, portal)

    def session_cookie(self) -> str:
        """当前会话 Cookie 字符串（不要写入公开日志）。"""
        if self._raw_cookie:
            return self._raw_cookie
        if self._session_token:
            return "%s=%s" % (COOKIE_NAME, self._session_token)
        for item in self._jar:
            if item.name == COOKIE_NAME:
                return "%s=%s" % (item.name, item.value)
        return ""

    def me(self) -> Dict[str, Any]:
        payload = self.request("GET", "/api/v1/me")
        if not isinstance(payload, dict) or not isinstance(payload.get("user"), dict):
            raise APIResponseError("me 响应缺少 user 对象")
        self.user = payload["user"]
        return self.user

    def permissions(self) -> Dict[str, Any]:
        payload = self.request("GET", "/api/v1/me/permissions")
        if not isinstance(payload, dict):
            raise APIResponseError("permissions 响应不是对象")
        return payload

    def health(self) -> Dict[str, Any]:
        payload = self.request("GET", "/health")
        if not isinstance(payload, dict):
            raise APIResponseError("health 响应不是对象")
        return payload

    def ops_overview(self) -> Dict[str, Any]:
        """运维概览（仅 super_admin/platform_op；服务端按实际数据返回）。"""
        payload = self.request("GET", "/api/v1/ops/overview")
        if not isinstance(payload, dict):
            raise APIResponseError("ops overview 响应不是对象")
        return payload

    # -- 项目 --------------------------------------------------------------
    def list_projects(
        self,
        *,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        q: Optional[str] = None,
        status: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        reviewer: Optional[str] = None,
        space: Optional[str] = None,
        stale_only: Optional[bool] = None,
    ) -> Page:
        """项目列表（服务端分页）。date_from/date_to 映射为服务端的 from/to。"""
        query: Dict[str, Any] = {}
        if q:
            query["q"] = q
        if status:
            query["status"] = status
        if date_from:
            query["from"] = date_from
        if date_to:
            query["to"] = date_to
        if reviewer:
            query["reviewer"] = reviewer
        if space:
            query["space"] = space
        if stale_only is not None:
            query["stale_only"] = "1" if stale_only else "0"
        if page is not None:
            query["page"] = int(page)
        if page_size is not None:
            query["page_size"] = int(page_size)
        payload = self.request("GET", "/api/v1/projects", query=query)
        return Page.from_payload(payload, page or 1, page_size or 20)

    def create_project(
        self,
        name: str,
        *,
        description: str = "",
        audit_type: str = "",
        focus: str = "",
        audit_category: str = "",
        document_type: str = "",
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """创建项目；返回 ``{"project_id": ...}``。"""
        body: Dict[str, Any] = {"name": str(name or "").strip()}
        if description:
            body["description"] = description
        if audit_type:
            body["audit_type"] = audit_type
        if focus:
            body["focus"] = focus
        if audit_category:
            body["audit_category"] = audit_category
        if document_type:
            body["document_type"] = document_type
        return self.request("POST", "/api/v1/projects", body=body,
                            idempotency_key=idempotency_key)

    def iter_projects(self, *, page_size: int = 50, max_pages: int = 1000,
                      **filters: Any) -> Iterator[Dict[str, Any]]:
        """自动翻页遍历项目；返回项目 dict。"""
        for page in self.iter_pages(
            lambda p, s: self.list_projects(page=p, page_size=s, **filters),
            page_size=page_size,
            max_pages=max_pages,
        ):
            for item in page.items:
                yield item

    # -- 规则 --------------------------------------------------------------
    def list_rules(self, *, page: Optional[int] = None,
                   page_size: Optional[int] = None) -> Page:
        """规则列表；不传 page/page_size 时兼容历史数组返回。"""
        query: Dict[str, Any] = {}
        if page is not None or page_size is not None:
            query["page"] = int(page or 1)
            query["page_size"] = int(page_size or 20)
        payload = self.request("GET", "/api/v1/rules", query=query)
        return Page.from_payload(payload, page or 1, page_size or 20)

    def create_rule(
        self,
        name: str,
        *,
        code: Optional[str] = None,
        category: str = "consistency",
        rclass: str = "R4",
        slots: Optional[Mapping[str, Any]] = None,
        source: str = "sdk",
        scope: Optional[Mapping[str, Any]] = None,
        point_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """创建规则草稿；不会自动发布。"""
        body: Dict[str, Any] = {
            "name": str(name or "").strip(),
            "category": category,
            "rclass": rclass,
            "slots": dict(slots or {}),
            "source": source,
        }
        if code:
            body["code"] = code
        if scope:
            body["scope"] = dict(scope)
        if point_id:
            body["point_id"] = point_id
        return self.request("POST", "/api/v1/rules/custom", body=body)

    def publish_rule(self, rule_id: str) -> Dict[str, Any]:
        """发布规则；失败时服务端可能返回 400 且失败值在 error 而非 code。"""
        return self.request("POST", "/api/v1/rules/%s/publish" % _seg(rule_id), body={})

    def iter_rules(self, *, page_size: int = 100,
                   max_pages: int = 1000) -> Iterator[Dict[str, Any]]:
        for page in self.iter_pages(
            lambda p, s: self.list_rules(page=p, page_size=s),
            page_size=page_size,
            max_pages=max_pages,
        ):
            for item in page.items:
                yield item

    # -- 发现/复核 ---------------------------------------------------------
    def list_findings(
        self,
        case_id: str,
        *,
        severity: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Page:
        """按项目读取发现；服务端无分页，Page 的 page_size 为本次全量条数。"""
        query: Dict[str, Any] = {"case_id": str(case_id or "")}
        if severity:
            query["severity"] = severity
        if status:
            query["status"] = status
        payload = self.request("GET", "/api/v1/findings", query=query)
        items = payload.get("items") if isinstance(payload, dict) else payload
        fallback_size = len(items) if isinstance(items, list) and items else 1
        return Page.from_payload(payload, 1, fallback_size)

    def decide_finding(self, finding_id: str, decision: str, *,
                       reason: str = "", note: str = "",
                       user: str = "审核员") -> Dict[str, Any]:
        """人工复核；decision 必须是 confirmed/false_positive/need_evidence。"""
        if decision not in _DECISIONS:
            raise ValueError("decision 只能是 %s" % "/".join(_DECISIONS))
        body: Dict[str, Any] = {"decision": decision}
        if reason:
            body["reason"] = reason
        if note:
            body["note"] = note
        if user:
            body["user"] = user
        return self.request(
            "POST", "/api/v1/findings/%s/decision" % _seg(finding_id), body=body)

    # -- 报告 --------------------------------------------------------------
    def report_status(self, case_id: str) -> Dict[str, Any]:
        payload = self.request(
            "GET", "/api/v1/reviews/%s/report-status" % _seg(case_id))
        if not isinstance(payload, dict):
            raise APIResponseError("report-status 响应不是对象")
        return payload

    def generate_report(self, case_id: str) -> Dict[str, Any]:
        payload = self.request(
            "POST", "/api/v1/reviews/%s/report" % _seg(case_id), body={})
        if not isinstance(payload, dict):
            raise APIResponseError("generate report 响应不是对象")
        return payload

    def download_report(self, case_id: str, fmt: str = "html") -> bytes:
        """下载报告文件；fmt 只支持 html/docx（PDF 已移除）。"""
        fmt = str(fmt or "").strip().lower().lstrip(".")
        if fmt not in ("html", "docx"):
            raise ValueError("fmt 只支持 html/docx；PDF 报告已移除")
        return self.request(
            "GET", "/api/v1/reviews/%s/report.%s" % (_seg(case_id), fmt),
            raw=True)

    def save_report(self, case_id: str, path: str, fmt: str = "html") -> str:
        data = self.download_report(case_id, fmt=fmt)
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(data)
        return path

    # -- 通用/分页 ---------------------------------------------------------
    def request(
        self,
        method: str,
        path: str,
        *,
        query: Optional[Mapping[str, Any]] = None,
        body: Any = None,
        headers: Optional[Mapping[str, str]] = None,
        raw: bool = False,
        timeout: Optional[float] = None,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        """发送真实 HTTP 请求。

        - ``raw=True`` 返回 bytes（报告下载）；
        - GET/HEAD 在 429/5xx/连接失败时按 ``max_retries`` 重试；
        - POST/PUT/PATCH/DELETE 永不自动重试；
        - 非 2xx 抛 APIError 子类；2xx 但非 JSON 抛 APIResponseError。
        """
        method = str(method or "GET").upper()
        req_headers = self._request_headers(headers)
        data: Optional[bytes] = None
        if body is not None:
            data = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            req_headers.setdefault("Content-Type", "application/json; charset=utf-8")
        if idempotency_key:
            req_headers["Idempotency-Key"] = _clean_header_value(str(idempotency_key))
        url = self._build_url(path, query)
        attempts = 0
        retry_limit = self.max_retries if method in ("GET", "HEAD") else 0
        while True:
            request_id = ""
            try:
                req = urllib.request.Request(
                    url, data=data, headers=req_headers, method=method)
                with self._opener.open(req, timeout=float(timeout or self.timeout)) as resp:
                    status = int(getattr(resp, "status", resp.getcode()))
                    content = resp.read()
                    request_id = resp.headers.get("X-Request-Id", "") or ""
                    content_type = resp.headers.get("Content-Type", "") or ""
                self.last_request_id = request_id
                if raw:
                    return content
                if not content:
                    return {}
                stripped = content.lstrip()
                if ("json" not in content_type.lower()
                        and not stripped.startswith((b"{", b"["))):
                    raise APIResponseError(
                        "期望 JSON，实际 Content-Type=%s" % content_type,
                        status=status, request_id=request_id, path=path)
                try:
                    payload = json.loads(content.decode("utf-8"))
                except (UnicodeDecodeError, ValueError) as exc:
                    raise APIResponseError(
                        "响应不是合法 JSON：%s" % exc,
                        status=status, request_id=request_id, path=path)
                if isinstance(payload, dict) and payload.get("error") and not payload.get("ok"):
                    raise APIError(
                        status, str(payload.get("error") or "请求失败"),
                        code=str(payload.get("code") or ""), payload=payload,
                        request_id=request_id, method=method, path=path)
                return payload
            except urllib.error.HTTPError as exc:
                request_id = (exc.headers.get("X-Request-Id", "") if exc.headers else "") or ""
                self.last_request_id = request_id
                try:
                    error_body = exc.read()
                except Exception:
                    error_body = b""
                retry_after = _parse_retry_after(
                    exc.headers.get("Retry-After", "") if exc.headers else "")
                err = _error_from_http(
                    exc.code, exc.reason, error_body, method, path,
                    request_id=request_id, retry_after=retry_after)
                if attempts < retry_limit and err.retryable:
                    self._sleep(attempts, err.retry_after)
                    attempts += 1
                    continue
                raise err
            except urllib.error.URLError as exc:
                reason = getattr(exc, "reason", exc)
                if isinstance(reason, (socket.timeout, TimeoutError)):
                    err: Union[APITimeoutError, APIConnectionError] = APITimeoutError(
                        "请求超时：%s" % reason, method=method, path=path)
                else:
                    err = APIConnectionError(
                        "连接失败：%s" % reason, method=method, path=path)
                if attempts < retry_limit:
                    self._sleep(attempts, None)
                    attempts += 1
                    continue
                raise err
            except (socket.timeout, TimeoutError) as exc:
                err = APITimeoutError("请求超时：%s" % exc, method=method, path=path)
                if attempts < retry_limit:
                    self._sleep(attempts, None)
                    attempts += 1
                    continue
                raise err
            except OSError as exc:
                err = APIConnectionError(
                    "连接失败：%s" % exc, method=method, path=path)
                if attempts < retry_limit:
                    self._sleep(attempts, None)
                    attempts += 1
                    continue
                raise err

    def iter_pages(self, fetch, *, page_size: int = 50,
                   max_pages: int = 1000) -> Iterator[Page]:
        """通用翻页迭代器；``fetch(page, page_size)`` 返回 Page 或原始 payload。

        防御：服务端若忽略 page 参数、总返回同一页，会因页码重复而停止，
        不会无限循环。
        """
        if int(page_size) < 1:
            raise ValueError("page_size 必须大于 0")
        if int(max_pages) < 1:
            raise ValueError("max_pages 必须大于 0")
        page_no = 1
        seen = set()
        while page_no <= int(max_pages):
            result = fetch(page_no, int(page_size))
            current = result if isinstance(result, Page) else Page.from_payload(
                result, page_no, int(page_size))
            if current.page in seen:
                break
            seen.add(current.page)
            if not current.items:
                break
            yield current
            if current.page >= current.pages:
                break
            page_no = current.page + 1

    # -- 内部 --------------------------------------------------------------
    def _request_headers(self, extra: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
        headers = dict(self._headers)
        if self._raw_cookie:
            headers["Cookie"] = self._raw_cookie
        elif self._session_token:
            headers["Cookie"] = "%s=%s" % (COOKIE_NAME, self._session_token)
        for key, value in (extra or {}).items():
            headers[str(key)] = _clean_header_value(str(value))
        return headers

    def _build_url(self, path: str, query: Optional[Mapping[str, Any]] = None) -> str:
        p = str(path or "")
        if not p.startswith("/"):
            p = "/" + p
        url = self.base_url + p
        pairs: List[Tuple[str, str]] = []
        for key, value in (query or {}).items():
            if value is None:
                continue
            if isinstance(value, bool):
                value = "1" if value else "0"
            if isinstance(value, (list, tuple)):
                for item in value:
                    pairs.append((str(key), str(item)))
            else:
                pairs.append((str(key), str(value)))
        if pairs:
            url += "?" + urllib.parse.urlencode(pairs, doseq=True)
        return url

    def _sleep(self, attempt: int, retry_after: Optional[float]) -> None:
        if retry_after is not None and retry_after >= 0:
            delay = min(float(retry_after), 30.0)
        else:
            delay = min(self.backoff * (2 ** attempt), 10.0)
        if delay > 0:
            time.sleep(delay)

    @classmethod
    def from_env(cls, prefix: str = "RULEPROOF_",
                 **overrides: Any) -> "RuleProofClient":
        """从环境变量构造客户端；不自动登录。"""
        base_url = (
            overrides.pop("base_url", None)
            or os.environ.get(prefix + "BASE_URL")
            or os.environ.get(prefix + "API_URL")
            or DEFAULT_BASE_URL
        )
        timeout = overrides.pop("timeout", None)
        if timeout is None:
            timeout = float(os.environ.get(prefix + "TIMEOUT", DEFAULT_TIMEOUT))
        token = overrides.pop("session_token", None)
        if token is None:
            token = os.environ.get(prefix + "SESSION_TOKEN")
        cookie = overrides.pop("cookie", None)
        if cookie is None:
            cookie = os.environ.get(prefix + "SESSION_COOKIE")
        return cls(base_url, timeout=float(timeout), session_token=token,
                   cookie=cookie, **overrides)

    def __enter__(self) -> "RuleProofClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------
def _seg(value: Any) -> str:
    return urllib.parse.quote(str(value or ""), safe="")


def _clean_token(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    token = str(value).strip()
    if not token:
        return None
    if any(x in token for x in ("\r", "\n", ";", " ")):
        raise ValueError("session_token 含非法字符（不允许空白/分号/换行）")
    return token


def _clean_cookie(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    cookie = str(value).strip()
    if not cookie:
        return None
    if "\r" in cookie or "\n" in cookie:
        raise ValueError("cookie 不能包含换行")
    return cookie


def _clean_header_value(value: str) -> str:
    if "\r" in value or "\n" in value:
        raise ValueError("请求头值不能包含换行")
    return value


def _parse_retry_after(value: Optional[str]) -> Optional[float]:
    if not value:
        return None
    try:
        seconds = float(value)
        return seconds if seconds >= 0 else None
    except (TypeError, ValueError):
        return None


def _error_from_http(status: int, reason: Any, body: bytes, method: str,
                     path: str, request_id: str = "",
                     retry_after: Optional[float] = None) -> APIError:
    payload: Any = None
    message = str(reason or ("HTTP %s" % status))
    code = ""
    if body:
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            text = body.decode("utf-8", errors="replace").strip()
            payload = {"raw": text[:1000]} if text else None
        if isinstance(payload, dict):
            message = str(payload.get("error") or payload.get("message") or message)
            code = str(payload.get("code") or "")
    cls: type
    if status == 400:
        cls = ValidationError
    elif status == 401:
        cls = AuthenticationError
    elif status == 403:
        cls = PermissionDeniedError
    elif status == 404:
        cls = NotFoundError
    elif status == 409:
        cls = ConflictError
    elif status == 429:
        cls = RateLimitError
    elif status >= 500:
        cls = ServerError
    else:
        cls = APIError
    return cls(status, message, code=code, payload=payload,
               request_id=request_id, method=method, path=path,
               retry_after=retry_after)


# ---------------------------------------------------------------------------
# 可选 CLI（不影响库导入）
# ---------------------------------------------------------------------------
def _client_from_args(args: argparse.Namespace) -> RuleProofClient:
    return RuleProofClient(
        args.base_url,
        timeout=args.timeout,
        session_token=args.token,
        cookie=args.cookie,
    )


def _print_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def _main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="ruleproof_client",
        description="规衡 AI 审核平台最小 Python SDK 命令行",
    )
    parser.add_argument("--base-url", default=os.environ.get(
        "RULEPROOF_BASE_URL", DEFAULT_BASE_URL))
    parser.add_argument("--token", default=os.environ.get("RULEPROOF_SESSION_TOKEN"))
    parser.add_argument("--cookie", default=os.environ.get("RULEPROOF_SESSION_COOKIE"))
    parser.add_argument("--timeout", type=float, default=float(
        os.environ.get("RULEPROOF_TIMEOUT", DEFAULT_TIMEOUT)))
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("health", help="健康检查")
    p.set_defaults(fn=_cmd_health)

    p = sub.add_parser("login", help="登录并输出 user（不输出 Cookie）")
    p.add_argument("--account", default=os.environ.get("RULEPROOF_ACCOUNT"))
    p.add_argument("--password", default=os.environ.get("RULEPROOF_PASSWORD"))
    p.add_argument("--portal", default=os.environ.get("RULEPROOF_PORTAL"))
    p.set_defaults(fn=_cmd_login)

    p = sub.add_parser("me", help="当前用户")
    p.set_defaults(fn=_cmd_me)

    p = sub.add_parser("permissions", help="当前权限")
    p.set_defaults(fn=_cmd_permissions)

    p = sub.add_parser("projects", help="项目列表")
    p.add_argument("--page", type=int, default=None)
    p.add_argument("--page-size", type=int, default=None)
    p.set_defaults(fn=_cmd_projects)

    p = sub.add_parser("rules", help="规则列表")
    p.add_argument("--page", type=int, default=None)
    p.add_argument("--page-size", type=int, default=None)
    p.set_defaults(fn=_cmd_rules)

    p = sub.add_parser("findings", help="发现列表")
    p.add_argument("--case", required=True)
    p.set_defaults(fn=_cmd_findings)

    p = sub.add_parser("report-status", help="报告状态")
    p.add_argument("--case", required=True)
    p.set_defaults(fn=_cmd_report_status)

    p = sub.add_parser("report", help="生成并下载报告")
    p.add_argument("--case", required=True)
    p.add_argument("--format", choices=["html", "docx"], default="html")
    p.add_argument("--out", required=True)
    p.set_defaults(fn=_cmd_report)

    args = parser.parse_args(argv)
    try:
        if args.command == "login":
            client = _client_from_args(args)
            if not args.password:
                args.password = getpass.getpass("密码：")
            return int(args.fn(args, client) or 0)
        client = _client_from_args(args)
        return int(args.fn(args, client) or 0)
    except RuleProofError as exc:
        print("错误：%s" % exc, file=sys.stderr)
        return 1
    except ValueError as exc:
        print("参数错误：%s" % exc, file=sys.stderr)
        return 2


def _cmd_health(args: argparse.Namespace, client: RuleProofClient) -> int:
    _print_json(client.health())
    return 0


def _cmd_login(args: argparse.Namespace, client: RuleProofClient) -> int:
    if not args.account:
        raise ValueError("缺少 --account 或 RULEPROOF_ACCOUNT")
    _print_json(client.login(args.account, args.password or "", args.portal))
    return 0


def _cmd_me(args: argparse.Namespace, client: RuleProofClient) -> int:
    _print_json(client.me())
    return 0


def _cmd_permissions(args: argparse.Namespace, client: RuleProofClient) -> int:
    _print_json(client.permissions())
    return 0


def _cmd_projects(args: argparse.Namespace, client: RuleProofClient) -> int:
    page = client.list_projects(page=args.page, page_size=args.page_size)
    _print_json({"items": page.items, "total": page.total, "page": page.page,
                 "page_size": page.page_size, "pages": page.pages})
    return 0


def _cmd_rules(args: argparse.Namespace, client: RuleProofClient) -> int:
    page = client.list_rules(page=args.page, page_size=args.page_size)
    _print_json({"items": page.items, "total": page.total, "page": page.page,
                 "page_size": page.page_size, "pages": page.pages})
    return 0


def _cmd_findings(args: argparse.Namespace, client: RuleProofClient) -> int:
    page = client.list_findings(args.case)
    _print_json({"items": page.items, "total": page.total, "case_id": args.case})
    return 0


def _cmd_report_status(args: argparse.Namespace, client: RuleProofClient) -> int:
    _print_json(client.report_status(args.case))
    return 0


def _cmd_report(args: argparse.Namespace, client: RuleProofClient) -> int:
    generated = client.generate_report(args.case)
    path = client.save_report(args.case, args.out, fmt=args.format)
    _print_json({"generated": generated, "saved": path})
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
