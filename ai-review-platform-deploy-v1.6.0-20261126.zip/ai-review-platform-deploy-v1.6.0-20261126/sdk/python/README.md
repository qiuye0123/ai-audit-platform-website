# 规衡 AI 审核平台 · 官方最小 Python SDK

`ruleproof_client.py` 是**单文件、仅标准库**的 HTTP 客户端，面向平台外部接入与脚本化运维。它不做审核、不调用模型、不直连数据库；所有请求都走平台 HTTP API，权限与审计由服务端负责。

- 版本：`0.1.0`（SDK 自身版本，不是平台版本）
- 兼容：Python 3.9+
- 依赖：无（`urllib`、`json`、`http.cookiejar` 等标准库）
- 契约：[docs/api/openapi.yaml](../../docs/api/openapi.yaml)
- 规范：[docs/architecture/扩展点与连接器规范.md](../../docs/architecture/扩展点与连接器规范.md)

## 1. 安装/引入

不发布到 PyPI；把 `sdk/python` 加入 `PYTHONPATH`，或直接复制 `ruleproof_client.py` 到项目里：

```bash
export PYTHONPATH="$PWD/sdk/python:$PYTHONPATH"
python3 -c "import ruleproof_client; print(ruleproof_client.__version__)"
```

## 2. 认证：Cookie 会话，不是 Bearer

平台登录成功后下发：

```text
Set-Cookie: rp_session=<JWT>; HttpOnly; SameSite=Lax; Path=/; Max-Age=3600
```

后续请求使用 `Cookie: rp_session=<JWT>`。平台**没有**独立的 Bearer access token。

### 2.1 账号密码登录（推荐）

```python
from ruleproof_client import RuleProofClient

with RuleProofClient("http://127.0.0.1:8765") as client:
    user = client.login("13700002222", "Rev@123456", portal="reviewer")
    print(user["name"], user["role"])
    print(client.me())          # Cookie 自动复用
```

### 2.2 已有会话 token/cookie

适用于 CLI、定时任务、已有登录态的服务：

```python
client = RuleProofClient(
    "http://127.0.0.1:8765",
    session_token="<rp_session JWT>",   # 作为 Cookie: rp_session=... 发送
)
# 或：
client = RuleProofClient("http://127.0.0.1:8765", cookie="rp_session=<JWT>")
```

`session_token` 和 `cookie` 只能二选一。**不要把 token 写进公开日志或提交到仓库。**

### 2.3 从环境变量构造

```bash
export RULEPROOF_BASE_URL=http://127.0.0.1:8765
export RULEPROOF_SESSION_TOKEN='<rp_session JWT>'
# 或账号密码：
export RULEPROOF_ACCOUNT=13700002222
export RULEPROOF_PASSWORD='Rev@123456'
export RULEPROOF_PORTAL=reviewer
```

```python
client = RuleProofClient.from_env()
# client.login_from_env()  # 需要账号密码时
```

## 3. 快速开始（只读）

```python
from ruleproof_client import RuleProofClient

client = RuleProofClient.from_env()
client.login_from_env()

print(client.health())
print(client.me())
print(client.permissions()["actions"])

projects = client.list_projects(page=1, page_size=5)
print("projects:", projects.total, [p["name"] for p in projects])

for p in client.iter_projects(page_size=50):
    print(p["id"], p["name"], p["status"])

rules = client.list_rules(page=1, page_size=20)
print("rules:", rules.total, [r["code"] for r in rules[:3]])

if projects.items:
    case_id = projects.items[0]["id"]
    findings = client.list_findings(case_id)
    print("findings:", findings.total)
    print(client.report_status(case_id))
```

完整示例见 [`examples/quickstart.py`](examples/quickstart.py)。

## 4. 方法

| 方法 | HTTP | 说明 |
|---|---|---|
| `login(account, password, portal=None)` | `POST /api/v1/auth/login` | 登录并保存 Cookie；返回 user |
| `login_from_env(prefix="RULEPROOF_")` | 同上 | 从环境变量读取账号密码 |
| `me()` | `GET /api/v1/me` | 当前用户 |
| `permissions()` | `GET /api/v1/me/permissions` | role/menus/actions（只读声明，不是授权保证） |
| `health()` | `GET /health` | 公开健康检查 |
| `ops_overview()` | `GET /api/v1/ops/overview` | 运维概览（仅 super_admin/platform_op） |
| `list_projects(...)` | `GET /api/v1/projects` | 返回 `Page`；服务端分页 |
| `iter_projects(page_size=50, ...)` | 同上 | 自动翻页 |
| `create_project(name, ...)` | `POST /api/v1/projects` | 返回 `{"project_id": ...}`；支持 `idempotency_key` |
| `list_rules(page=None, page_size=None)` | `GET /api/v1/rules` | 不带分页参数兼容历史数组；返回 `Page` |
| `iter_rules(page_size=100)` | 同上 | 始终走分页信封 |
| `create_rule(name, ...)` | `POST /api/v1/rules/custom` | 创建草稿，不自动发布 |
| `publish_rule(rule_id)` | `POST /api/v1/rules/{id}/publish` | 仅业务管理员；门禁失败为 400 |
| `list_findings(case_id, ...)` | `GET /api/v1/findings` | 服务端无分页；`Page` 是本次全量 |
| `decide_finding(finding_id, decision, ...)` | `POST /api/v1/findings/{id}/decision` | confirmed/false_positive/need_evidence |
| `report_status(case_id)` | `GET /api/v1/reviews/{id}/report-status` | 门禁/生成状态 |
| `generate_report(case_id)` | `POST /api/v1/reviews/{id}/report` | 过门禁才生成；409 `report_blocked` |
| `download_report(case_id, fmt="html")` | `GET /api/v1/reviews/{id}/report.{fmt}` | 仅 html/docx；返回 bytes |
| `save_report(case_id, path, fmt="html")` | 同上 | 下载并写文件 |
| `request(method, path, ...)` | — | 高级用法；自定义 query/body/raw |

## 5. 分页语义（重要）

平台三种列表形态不同，SDK 用 `Page` 统一，但不伪造服务端行为：

| 接口 | 服务端 | SDK |
|---|---|---|
| 项目 | 固定 `{items,total,page,page_size,pages}` | `Page` 直接映射 |
| 规则 | 无分页参数→数组；有→信封 | 不传参数时 `Page` 包装数组；`iter_rules` 始终请求信封 |
| 发现 | 按 `case_id` 全量 `{items,total,case_id}` | `Page.page_size` 等于本次全量条数；**没有服务端翻页** |

`Page` 字段：`items/total/page/page_size/pages`，并有 `has_next`、`next_page`。

```python
page = client.list_projects(page=2, page_size=20)
print(page.page, page.pages, page.has_next)

for project in client.iter_projects(page_size=50):
    ...
```

## 6. 错误处理

所有 HTTP 非 2xx 抛 `APIError` 子类，保留：

- `status`：HTTP 状态码
- `code`：服务端 `code`（历史接口可能为空）
- `message`：`body.error`
- `request_id`：响应头 `X-Request-Id`
- `payload`：原始错误 JSON（非 JSON 时为 `{"raw": "..."}`）
- `retryable`：429/5xx 为 True（仅 GET 会自动重试）

| 异常 | HTTP |
|---|---|
| `ValidationError` | 400 |
| `AuthenticationError` | 401 |
| `PermissionDeniedError` | 403 |
| `NotFoundError` | 404 |
| `ConflictError` | 409（含 `report_blocked`） |
| `RateLimitError` | 429，带 `retry_after`（若服务端给 Retry-After） |
| `ServerError` | 5xx |
| `APITimeoutError` / `APIConnectionError` | 网络层 |
| `APIResponseError` | 2xx 但非预期 JSON |

```python
from ruleproof_client import (
    RuleProofClient, ConflictError, PermissionDeniedError, ValidationError,
)

try:
    client.decide_finding(finding_id, "confirmed", reason="已核对原文")
except PermissionDeniedError as exc:
    print("无权限", exc.code, exc.request_id)
except ConflictError as exc:
    print("冲突/门禁", exc.code, exc.message)
except ValidationError as exc:
    print("参数错误", exc.code, exc.message)
```

规则发布失败是特例：服务端返回 400，失败值在 `body.error` 而不是 `body.code`（例如 `executor_unreachable`、`ir_incomplete`、`conflict`），SDK 会把它放在 `ValidationError.message`，`code` 可能为空。

## 7. 超时、重试、幂等

- `timeout`：单次 HTTP 操作超时，默认 20s。
- `max_retries`：GET/HEAD 遇到 429/5xx/网络错误时重试，默认 2 次；指数退避，最大 10s。
- **POST 永不自动重试**，避免重复建项目/重复复核。
- `create_project(..., idempotency_key="...")` 会发送 `Idempotency-Key`；重复使用同一键且请求体不同返回 409 `idempotency_conflict`。
- 429 若带 `Retry-After`，SDK 用它作为等待时间（上限 30s）。

## 8. 已知边界（不要误用）

1. **`/api/v1/ops/overview` 已实现，但仅系统管理员/平台运营可读**：`ops_overview()` 只做只读封装；普通审核员/业务管理员调用会 403。服务端读取失败返回 500 `ops_overview_failed`，不是全 0。
2. **报告**：`generate_report` 会经过报告门禁，未过返回 409 `report_blocked`；PDF 已移除，`download_report` 只接受 `html/docx`。
3. **报告权限现状**：`report.generate` 会严格拒绝业务管理员；但 `.html/.docx` 下载当前未把身份传给 `report.build_report_*`，业务管理员可能仍能下载。这与角色矩阵文档不一致，后续权限统一时收紧（见评估 3.7）。SDK 不据此做授权判断。
4. **规则发布**：仅业务管理员；审核员可创建/提交但不能发布。
5. **发现列表没有服务端分页**：`list_findings` 的 `Page` 是本次全量，不要拿 `next_page` 当服务端翻页。
6. **Cookie 不是 Bearer**：不要给 SDK 传 OAuth access token 并期望 Authorization 头；服务端只认 `rp_session` Cookie。

## 9. 命令行（可选）

SDK 自带一个薄 CLI，方便部署后自检：

```bash
python3 sdk/python/ruleproof_client.py --base-url http://127.0.0.1:8765 health

RULEPROOF_ACCOUNT=13700002222 RULEPROOF_PASSWORD='Rev@123456' \
  python3 sdk/python/ruleproof_client.py login --portal reviewer

export RULEPROOF_SESSION_TOKEN='<JWT>'
python3 sdk/python/ruleproof_client.py me
python3 sdk/python/ruleproof_client.py projects --page-size 5
python3 sdk/python/ruleproof_client.py findings --case <CASE_ID>
python3 sdk/python/ruleproof_client.py report-status --case <CASE_ID>
python3 sdk/python/ruleproof_client.py report --case <CASE_ID> --format html --out /tmp/report.html
```

## 10. 测试

```bash
python3 scripts/qa/sdk_test.py
```

测试使用本地 mock HTTP（`http.server`），覆盖：

- 登录 → Cookie 复用 → `me`
- 显式 `session_token` 作为 `rp_session` 发送
- 项目两页分页、规则数组/信封兼容
- 400/401/403/404/409/5xx 异常映射与 `request_id`
- 0.1s 超时 → `APITimeoutError`
- `Idempotency-Key` 冲突
- 报告 HTML 原始字节下载

不调用真实模型、不写真实数据库、不需要启动平台服务。
