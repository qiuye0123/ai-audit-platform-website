-- ===========================================================================
-- L109（2026-11-25）历史归档：本文件**不参与任何运行路径**（未注册进迁移目录、
-- 无代码执行）。本文件的表/索引/加列已统一收口到：
--   * 表/索引 DDL → app/db.py RUNTIME_EXTENSION_SCHEMA（direct_claim/
--     direct_claim_occurrence/direct_discovery_metrics）
--   * 加列 → app/db.py RUNTIME_EXTENSION_COLUMNS["direct_item"]
--   * 可执行登记 → data_migrations 迁移 20261125_005_l109_runtime_schema（lazy）
-- 运行期仍由 app/services/direct_draft.ensure_claim_schema() 兜底（调用同一常量）。
-- 保留本文件仅作审计留痕，请勿执行。
-- ===========================================================================
-- 002_phase3_claim_metrics.sql
-- 影子池 Phase3 收尾（2026-11-21）：
--   A) 跨轮 claim 去重：direct_item.claim_key 键列 + direct_claim / direct_claim_occurrence
--   C) L11 成本/时延：direct_discovery_metrics
--
-- 只做**新增**：不改既有行/列语义；direct_draft / direct_item 仍不可变
-- （UPDATE/DELETE 触发器不变；ALTER ADD COLUMN 不触发 UPDATE 触发器）。
-- 运行时同样由 app/services/direct_draft.ensure_claim_schema() 幂等补齐（老库自动升级），
-- 本文件供显式迁移/审计留痕；回滚见 002_phase3_claim_metrics_rollback.sql。

-- A) direct_item 幂等键列（可复算：sha256(case_id|rule_code|归一后 quote)，不含 run_id）
ALTER TABLE direct_item ADD COLUMN claim_key TEXT DEFAULT '';
ALTER TABLE direct_item ADD COLUMN document_id TEXT DEFAULT '';
CREATE INDEX IF NOT EXISTS idx_direct_item_claim ON direct_item(case_id, claim_key);

-- A) claim 状态（每 (case_id, claim_key) 一行；可变簿记，不是原件）
CREATE TABLE IF NOT EXISTS direct_claim (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  claim_key TEXT NOT NULL,
  rule_code TEXT DEFAULT '',
  quote TEXT DEFAULT '',
  quote_norm TEXT DEFAULT '',
  issue_type TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  zone TEXT DEFAULT '',
  shadow_item_id TEXT DEFAULT '',
  first_direct_item_id TEXT DEFAULT '',
  first_draft_id TEXT DEFAULT '',
  first_run_id TEXT DEFAULT '',
  first_document_id TEXT DEFAULT '',
  last_direct_item_id TEXT DEFAULT '',
  last_draft_id TEXT DEFAULT '',
  last_run_id TEXT DEFAULT '',
  last_document_id TEXT DEFAULT '',
  times_seen INTEGER DEFAULT 0,
  times_seen_rounds INTEGER DEFAULT 0,
  first_seen_at TEXT DEFAULT '',
  last_seen_at TEXT DEFAULT '',
  updated_at TEXT DEFAULT '',
  UNIQUE(case_id, claim_key)
);
CREATE INDEX IF NOT EXISTS idx_direct_claim_case ON direct_claim(case_id);
CREATE INDEX IF NOT EXISTS idx_direct_claim_status ON direct_claim(case_id, status);

-- A) 每次 claim 被看到的追加式 occurrence（可证明“第二轮看到了但没新增原件”）
CREATE TABLE IF NOT EXISTS direct_claim_occurrence (
  id TEXT PRIMARY KEY,
  claim_id TEXT NOT NULL,
  claim_key TEXT DEFAULT '',
  case_id TEXT NOT NULL,
  run_id TEXT DEFAULT '',
  draft_id TEXT DEFAULT '',
  document_id TEXT DEFAULT '',
  direct_item_id TEXT DEFAULT '',
  is_new_claim INTEGER DEFAULT 0,
  zone TEXT DEFAULT '',
  shadow_item_id TEXT DEFAULT '',
  transition TEXT DEFAULT '',
  created_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_direct_claim_occ_case ON direct_claim_occurrence(case_id);
CREATE INDEX IF NOT EXISTS idx_direct_claim_occ_claim ON direct_claim_occurrence(claim_id);

-- C) 直连发现每次运行的指标（L11：延迟/token/文档数/每文档明细）
CREATE TABLE IF NOT EXISTS direct_discovery_metrics (
  id TEXT PRIMARY KEY,
  run_id TEXT DEFAULT '',
  case_id TEXT NOT NULL,
  tenant_id TEXT DEFAULT '',
  workspace_id TEXT DEFAULT '',
  trigger TEXT DEFAULT '',
  documents INTEGER DEFAULT 0,
  direct_calls INTEGER DEFAULT 0,
  rules INTEGER DEFAULT 0,
  new_direct_items INTEGER DEFAULT 0,
  duplicate_claims INTEGER DEFAULT 0,
  latency_ms INTEGER DEFAULT 0,
  latency_llm_sum_ms INTEGER DEFAULT 0,
  tokens_in INTEGER DEFAULT 0,
  tokens_out INTEGER DEFAULT 0,
  per_doc_json TEXT DEFAULT '[]',
  ok INTEGER DEFAULT 1,
  errors_json TEXT DEFAULT '[]',
  raw_root TEXT DEFAULT '',
  created_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_dd_metrics_case ON direct_discovery_metrics(case_id);
CREATE INDEX IF NOT EXISTS idx_dd_metrics_run ON direct_discovery_metrics(run_id);
CREATE INDEX IF NOT EXISTS idx_dd_metrics_created ON direct_discovery_metrics(created_at);
