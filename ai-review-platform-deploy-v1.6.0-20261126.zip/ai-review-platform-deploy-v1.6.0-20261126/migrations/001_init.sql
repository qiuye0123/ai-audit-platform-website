-- ===========================================================================
-- L109（2026-11-25）历史归档：本文件**不参与任何运行路径**（未注册进
-- app/data_migrations.py 的迁移目录，也没有任何代码/脚本执行它）。
-- 现行 schema 单一事实源：
--   * 基线表/列/索引/触发器 → app/db.py（SCHEMA + init_db 幂等迁移）
--   * 版本化迁移/热路径索引/审计 append-only → app/data_migrations.py
--   * 运行期按需对象 → app/db.py RUNTIME_EXTENSION_*
-- 本文件中的 25 张表已全部由 app/db.py 建成；其中 department/template/
-- template_field 三张历史遗留空表已被 L109 正式纳入 init_db 基线（fresh 与
-- 产品库同构，104 表）。保留本文件仅作 schema 考古/审计留痕，请勿执行。
-- ===========================================================================

CREATE TABLE IF NOT EXISTS org (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, region TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS plant (
  id TEXT PRIMARY KEY, org_id TEXT, name TEXT NOT NULL,
  FOREIGN KEY(org_id) REFERENCES org(id)
);
CREATE TABLE IF NOT EXISTS department (
  id TEXT PRIMARY KEY, plant_id TEXT, name TEXT NOT NULL,
  FOREIGN KEY(plant_id) REFERENCES plant(id)
);
CREATE TABLE IF NOT EXISTS role (
  id TEXT PRIMARY KEY, code TEXT UNIQUE, name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user (
  id TEXT PRIMARY KEY, external_id TEXT, name TEXT, email TEXT,
  status TEXT DEFAULT 'active', plant_id TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS user_role (
  user_id TEXT, role_id TEXT, PRIMARY KEY(user_id, role_id)
);
CREATE TABLE IF NOT EXISTS template (
  id TEXT PRIMARY KEY, code TEXT, name TEXT, doc_type TEXT,
  version TEXT, status TEXT DEFAULT 'draft', schema_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS template_field (
  id TEXT PRIMARY KEY, template_id TEXT, key TEXT, label TEXT, type TEXT,
  unit TEXT, source TEXT, consumed_by TEXT,
  FOREIGN KEY(template_id) REFERENCES template(id)
);
CREATE TABLE IF NOT EXISTS rule (
  id TEXT PRIMARY KEY, code TEXT, name TEXT, category TEXT, rclass TEXT,
  status TEXT DEFAULT 'draft', source TEXT, scope_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS rule_version (
  id TEXT PRIMARY KEY, rule_id TEXT, version TEXT, slots_json TEXT,
  evidence_json TEXT, tests_json TEXT, published_at TEXT, status TEXT DEFAULT 'draft',
  FOREIGN KEY(rule_id) REFERENCES rule(id)
);
CREATE TABLE IF NOT EXISTS document (
  id TEXT PRIMARY KEY, filename TEXT, doc_type TEXT, hash TEXT,
  status TEXT DEFAULT 'parsed', source_system TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS anchor (
  id TEXT PRIMARY KEY, document_id TEXT, sheet TEXT, row INTEGER, col TEXT,
  locator TEXT, quote TEXT, hash TEXT,
  FOREIGN KEY(document_id) REFERENCES document(id)
);
CREATE TABLE IF NOT EXISTS audit_case (
  id TEXT PRIMARY KEY, name TEXT, status TEXT DEFAULT 'created',
  pack_version TEXT, model_version TEXT, progress INTEGER DEFAULT 0, created_at TEXT
);
CREATE TABLE IF NOT EXISTS case_document (
  case_id TEXT, document_id TEXT, PRIMARY KEY(case_id, document_id)
);
CREATE TABLE IF NOT EXISTS finding (
  id TEXT PRIMARY KEY, case_id TEXT, rule_id TEXT, rule_version TEXT,
  severity TEXT, certainty TEXT, confidence REAL, status TEXT DEFAULT 'pending',
  title TEXT, summary TEXT, suggestion TEXT, grade TEXT, engine TEXT,
  FOREIGN KEY(case_id) REFERENCES audit_case(id)
);
CREATE TABLE IF NOT EXISTS evidence (
  id TEXT PRIMARY KEY, finding_id TEXT, document_id TEXT, anchor_id TEXT,
  excerpt TEXT, label TEXT,
  FOREIGN KEY(finding_id) REFERENCES finding(id)
);
CREATE TABLE IF NOT EXISTS decision (
  id TEXT PRIMARY KEY, finding_id TEXT, decision TEXT, reason TEXT, note TEXT,
  user_id TEXT, created_at TEXT,
  FOREIGN KEY(finding_id) REFERENCES finding(id)
);
CREATE TABLE IF NOT EXISTS report (
  id TEXT PRIMARY KEY, case_id TEXT, version TEXT, summary_json TEXT,
  signatures_json TEXT, disclaimer TEXT, exported_at TEXT,
  FOREIGN KEY(case_id) REFERENCES audit_case(id)
);
CREATE TABLE IF NOT EXISTS agent (
  id TEXT PRIMARY KEY, name TEXT, type TEXT, status TEXT DEFAULT 'draft', profile_json TEXT
);
CREATE TABLE IF NOT EXISTS agent_version (
  id TEXT PRIMARY KEY, agent_id TEXT, version TEXT, prompt TEXT, model TEXT,
  tools_json TEXT, published_at TEXT, status TEXT DEFAULT 'draft',
  FOREIGN KEY(agent_id) REFERENCES agent(id)
);
CREATE TABLE IF NOT EXISTS agent_run (
  id TEXT PRIMARY KEY, agent_version_id TEXT, case_id TEXT, status TEXT,
  cost REAL, latency_ms INTEGER, result_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS eval_set (
  id TEXT PRIMARY KEY, name TEXT, golden_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS eval_run (
  id TEXT PRIMARY KEY, eval_set_id TEXT, metrics_json TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY, actor TEXT, action TEXT, object TEXT,
  before_json TEXT, after_json TEXT, request_id TEXT, ip TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS conflict (
  id TEXT PRIMARY KEY, rule_a TEXT, rule_b TEXT, type TEXT, detail TEXT,
  status TEXT DEFAULT 'open', created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_user_role_user ON user_role(user_id);
CREATE INDEX IF NOT EXISTS idx_finding_case ON finding(case_id);
CREATE INDEX IF NOT EXISTS idx_anchor_doc ON anchor(document_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor);

