# migrations/ 目录说明（L109 起）

本目录的 `*.sql` 是**历史归档**，不参与任何运行路径（无代码执行、未注册进
`app/data_migrations.py` 的迁移目录）。

现行 DB schema 单一事实源（L109 收口，2026-11-25）：

| 对象 | 唯一事实源 | 装载路径 |
|---|---|---|
| 基线表/列/索引/触发器 | `app/db.py`（`SCHEMA` + `init_db` 幂等迁移） | 每个入口的 `db.init_db()` |
| 版本化迁移 / 热路径索引 / 平台升级表 | `app/data_migrations.py`（`MIGRATIONS`，`base=True` 由 `ensure_infra_schema()` 装进 init_db） | `rp init`（seed） / `rp db migrate` |
| 审计 append-only 触发器 | `MIGRATIONS` = `20261125_004_l109_audit_append_only` | `rp init`（auto）/ `rp db migrate`（产品库显式） |
| 运行期按需对象（feature-lazy） | `app/db.py` `RUNTIME_EXTENSION_SCHEMA/COLUMNS/UNIQUE_INDEXES` | 运行期 `ensure_*()` 兜底 + `rp db migrate`（`20261125_005_...`，auto=False） |

新增/变更 schema 请改 `app/db.py` 或 `app/data_migrations.py`，**不要**在本目录新增可执行 SQL。
验收：`scripts/qa/l109_db_source_test.py`、`scripts/qa/schema_drift_test.py`。
