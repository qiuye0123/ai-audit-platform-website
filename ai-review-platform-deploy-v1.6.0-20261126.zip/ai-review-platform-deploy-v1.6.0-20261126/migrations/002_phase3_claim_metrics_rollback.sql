-- ===========================================================================
-- L109（2026-11-25）历史归档：回滚脚本仅供人工/迁移批次参考，不参与运行路径。
-- 现行对象定义见 app/db.py RUNTIME_EXTENSION_* 与 data_migrations 的 lazy 迁移。
-- ===========================================================================
-- 002_phase3_claim_metrics_rollback.sql
-- 回滚 002_phase3_claim_metrics.sql（仅人工/迁移脚本显式调用；产品主链不调用）。
--
-- 顺序：先删新增表/索引，再删 direct_item 新增列。
-- 注意：
--   * direct_item 是 append-only 原件表，回滚删除 claim_key/document_id 列不会删除任何行；
--   * SQLite < 3.35 不支持 DROP COLUMN —— 遇到旧版可只保留“删新表”，两列默认值 ''
--     不影响既有读取（回滚脚本失败时打印提示，不静默）。
--   * 本回滚**不**删除 direct_draft / direct_item 数据，也不动 shadow_item。

DROP INDEX IF EXISTS idx_dd_metrics_created;
DROP INDEX IF EXISTS idx_dd_metrics_run;
DROP INDEX IF EXISTS idx_dd_metrics_case;
DROP TABLE IF EXISTS direct_discovery_metrics;

DROP INDEX IF EXISTS idx_direct_claim_occ_claim;
DROP INDEX IF EXISTS idx_direct_claim_occ_case;
DROP TABLE IF EXISTS direct_claim_occurrence;

DROP INDEX IF EXISTS idx_direct_claim_status;
DROP INDEX IF EXISTS idx_direct_claim_case;
DROP TABLE IF EXISTS direct_claim;

DROP INDEX IF EXISTS idx_direct_item_claim;
ALTER TABLE direct_item DROP COLUMN document_id;
ALTER TABLE direct_item DROP COLUMN claim_key;
