# AI 审核平台 · 云服务器部署手册

本目录是**部署入口**，支持两种方式：Docker Compose（推荐）和裸机 systemd。
两种方式都会首次自动建库并写入两个固定默认工作空间：**通用工作空间**、**食品工艺书**（都带演示内容）。

## 0. 先看结论

- 服务器建议：Ubuntu 22.04/24.04 或 Debian 12，2C4G 起步，磁盘 ≥40GB（演示库约 100MB，上传另算）；
- 对外只开 80/443（Nginx），**8765 只监听 127.0.0.1**，不要直接暴露；
- 必须改：`RULEPROOF_SESSION_SECRET`、`RULEPROOF_ADMIN_PASSWORD`；
- 首次登录后立即改系统管理员密码；生产库禁止使用演示口令；
- 数据持久化在 `data/`（Docker 卷 `ai_review_data`），升级/重装不要删；
- 部署后先跑 `deploy/smoke-test.sh`，再打开浏览器。

## 1. Docker Compose（推荐）

前置：服务器已安装 Docker Engine + Compose v2；域名已解析到服务器。

```bash
# 1) 上传并解压部署包
tar -xzf AI审核平台_部署包_*.tar.gz -C /opt
cd /opt/AI审核平台_部署包_*

# 2) 准备生产环境文件
cp deploy/.env.production.example .env.production
python3 - <<'PY'
import secrets, pathlib
p=pathlib.Path('.env.production'); s=p.read_text()
s=s.replace('CHANGE_ME_SESSION_SECRET', secrets.token_urlsafe(32))
s=s.replace('CHANGE_ME_ADMIN_PASSWORD', secrets.token_urlsafe(14))
p.write_text(s); print('已生成 .env.production（管理员初始密码在 RULEPROOF_ADMIN_PASSWORD）')
PY
chmod 600 .env.production

# 3) 启动
docker compose -f deploy/docker-compose.yml up -d --build
docker compose -f deploy/docker-compose.yml ps
curl -fsS http://127.0.0.1:8765/health && echo OK

# 4) Nginx/TLS（域名改成你的）
sudo cp deploy/nginx/ai-review.conf /etc/nginx/conf.d/ai-review.conf
# 修改 server_name 后：
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d review.example.com   # 或使用云厂商证书

# 5) 冒烟
ADMIN_PHONE=13800000000 ADMIN_PASSWORD='<.env.production 里的值>' bash deploy/smoke-test.sh https://review.example.com
```

查看日志：`docker compose -f deploy/docker-compose.yml logs -f --tail=200`
数据卷：`docker volume inspect ai_review_data`；删除容器不会删数据，**不要 `docker compose down -v`**。

## 2. 裸机 systemd（不用 Docker）

前置：Ubuntu/Debian、Python 3.10+、`python3-venv`、`rsync`、`nginx`。

```bash
sudo bash deploy/install-baremetal.sh
# 安装脚本会：
# - 安装到 /opt/ruleproof，建 ruleproof 系统用户
# - 建 venv、装依赖、生成 .env.production（含随机 session secret/admin 密码）
# - 首次 seed（两个默认空间+内容）
# - 安装并启动 systemd 服务 ai-review
curl -fsS http://127.0.0.1:8765/health
```

日志：`journalctl -u ai-review -f`；重启：`systemctl restart ai-review`；
升级：`sudo bash deploy/upgrade.sh <新版本目录>`（自动备份 data）；
回滚：`sudo bash deploy/restore.sh /opt/ruleproof/backups/...db`。

## 3. 首次登录

- 地址：`https://你的域名/`
- 系统管理员：手机号 `13800000000`，密码是 `.env.production` 的 `RULEPROOF_ADMIN_PASSWORD`
- 首次登录会要求改密；改密后原临时密码失效。
- 演示账号（仅 `RULEPROOF_SEED_DEMO=1` 时存在）：
  - 业务管理员 `13500001111` / `Acme@123456`
  - 审核员 `13700002222` / `Rev@123456`
  - 平台运营 `13600003333` / `Plat@123456`
- 生产环境请把 `RULEPROOF_SEED_DEMO=0`，并删除/停用演示账号。

## 4. 两个默认工作空间

首次建库会自动创建：

| ID | 名称 | 内容 |
|---|---|---|
| ws-default | 通用工作空间 | 默认项目/文档/问题 |
| ws-demo | 食品工艺书 | 食品工艺演示项目/文档/问题 |

如果登录后看不到，先确认 `RULEPROOF_SEED_DEMO=1` 且数据库是首次生成的空库；
已有旧库升级不会自动加内容，需执行 `python seed.py`（会按当前环境补默认内容）。

## 4.1 模型/OCR 接入

部署包默认不调外部模型；要接哪些模型、需要哪些 Key、无 Key 时哪些能力降级，见 **`deploy/模型接入说明.md`**。

## 5. 健康检查与验收

```bash
curl -fsS http://127.0.0.1:8765/health
ADMIN_PHONE=13800000000 ADMIN_PASSWORD='...' bash deploy/smoke-test.sh https://你的域名
```

`smoke-test.sh` 会检查：健康、登录、两个默认空间、项目列表、CLI。
**部署完成必须看到 `SMOKE: PASS` 才算完成。**

## 6. 备份与恢复

```bash
sudo bash deploy/backup.sh /opt/ruleproof /opt/ruleproof/backups
sudo bash deploy/restore.sh /opt/ruleproof/backups/ruleproof-YYYYmmdd_HHMMSS.db
```

- 备份包含 SQLite 一致性快照 + uploads/knowledge 文件；
- 每日定时：`crontab -e` 加 `0 2 * * * /opt/ruleproof/deploy/backup.sh /opt/ruleproof /opt/ruleproof/backups`；
- 生产建议把备份同步到对象存储/另一台机器，不要只放本机。

## 7. 常见部署问题

| 现象 | 处理 |
|---|---|
| 502 Bad Gateway | `curl 127.0.0.1:8765/health`；看容器日志/systemd 日志；确认 app 已启动 |
| 登录 401 | 确认手机号/密码；首次 seed 密码看安装输出或 `.env.production`；不要用演示口令登生产库 |
| 看不到两个空间 | 确认首次 seed 成功；旧库执行 `RULEPROOF_SEED_DEMO=1 python seed.py` |
| 上传大文件失败 | Nginx `client_max_body_size 120m`；平台上限 100MB |
| 端口冲突 | 改 `RULEPROOF_PORT`/compose 映射；Nginx 反代同步改 |
| 时间/时区不对 | 服务器设 `Asia/Shanghai`；`timedatectl set-timezone Asia/Shanghai` |
| 磁盘满 | 清理日志/备份；`deploy/backup.sh` 后迁移旧备份 |

## 8. 安全上线检查清单

- [ ] `RULEPROOF_SESSION_SECRET` 已改为随机 32 字节以上，且未提交 Git
- [ ] 管理员初始密码已改；演示账号已删除/停用
- [ ] 8765 未对公网开放（`ss -lntp` 只看到 127.0.0.1:8765）
- [ ] 443 证书有效；HTTP 自动跳 HTTPS
- [ ] `data/` 与备份目录权限 750/600，仅 ruleproof 用户可读
- [ ] 已跑 `smoke-test.sh` 看到 `SMOKE: PASS`
- [ ] 已配置每日备份并验证过一次 restore
- [ ] 如启用真实模型：Key 只放 `.env.production`，不提交 Git

## 9. 不适用/未验证

- 多实例/集群：当前单机 SQLite + 单进程，不支持多副本水平扩展；
- K8s/负载均衡：未提供清单；
- 自动填单/RPA：不属于本平台当前范围；
- 真实 OCR/客户数据：部署包只带演示内容，客户数据需单独导入与权限配置。
