#!/usr/bin/env bash
# AI 审核平台一键启动：复用 rp 的 Python 3.10+ 选择逻辑（裸 python3 在 macOS 3.9
# 上会因 PEP 604 语法（X | None）直接 TypeError，不能作为启动解释器）。
set -euo pipefail
cd "$(dirname "$0")"

# ---- Python 3.10+ 选择（与 ./rp 保持同一优先级，改动时两处同步）----
if [ -n "${RULEPROOF_PYTHON:-}" ]; then
  PY="$RULEPROOF_PYTHON"
else
  PY=""
  for c in "$PWD/.venv/bin/python3" \
           "$HOME/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3" \
           python3.13 python3.12 python3.11 python3.10 python3; do
    if [ -x "$c" ] || command -v "$c" >/dev/null 2>&1; then
      if "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' 2>/dev/null; then
        PY="$c"; break
      fi
    fi
  done
fi
if [ -z "$PY" ]; then
  echo "错误：需要 Python 3.10+（可用 RULEPROOF_PYTHON=/path/to/python3 指定）" >&2
  exit 127
fi
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"

if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env 2>/dev/null || true
  echo "已生成 .env（RULEPROOF_SESSION_SECRET 由首次生产启动自动生成；请按需填写 RULEPROOF_LLM_API_KEY 等）"
fi

# .env 读取单个键（只读解析，不 source 执行 .env）；用于 shell 侧 seed 判定与默认值。
_env_get() {
  local key="$1"
  [ -n "$key" ] && [ -f .env ] || return 0
  sed -n "s/^[[:space:]]*${key}=//p" .env 2>/dev/null | tail -n 1 | tr -d '\r' | sed 's/[[:space:]]*$//'
}

# X1：空/空白的 RULEPROOF_DB 视为“未设置”，回退平台根 data/ruleproof.db 并显式
# export 给 Python（旧实现只在 shell 里算默认，Python 从 .env 读到空串后启动崩溃）。
if [ -z "${RULEPROOF_DB:-}" ]; then
  _env_db="$(_env_get RULEPROOF_DB)"
  if [ -n "$_env_db" ]; then
    RULEPROOF_DB="$_env_db"
  fi
fi
export RULEPROOF_DB="${RULEPROOF_DB:-$PWD/data/ruleproof.db}"

# 生产默认环境：首次部署（库不存在）只建系统管理员与基础数据。
# RULEPROOF_ENV=prod 时 seed.py 自动关闭演示租户/演示用户/演示项目/开放平台演示应用
# （P1-01）；确需演示数据必须显式 RULEPROOF_SEED_DEMO=1，且不得用于生产库。
export RULEPROOF_ENV="${RULEPROOF_ENV:-prod}"
export RULEPROOF_TEST_AUTOLOGIN="${RULEPROOF_TEST_AUTOLOGIN:-0}"

# E-02：生产模式会话密钥必填。空/占位值按“未配置”处理，server 会 fail-fast；
# 一键启动脚本在首次运行时生成随机密钥并持久化到 .env（已有显式配置不覆盖）。
_sec="$(printf '%s' "${RULEPROOF_SESSION_SECRET:-}" | tr -d '[:space:]')"
case "$RULEPROOF_ENV" in
  prod|production)
    if [ -z "$_sec" ] || [ "$_sec" = "ruleproof-session-dev-secret" ]; then
      _sec="$("$PY" -c 'import secrets; print(secrets.token_urlsafe(32))')"
      RULEPROOF_SESSION_SECRET="$_sec"
      export RULEPROOF_SESSION_SECRET
      if [ -f .env ] && [ -w .env ]; then
        _env_tmp="$(mktemp "${TMPDIR:-/tmp}/rp_env.XXXXXX")"
        awk -v k="RULEPROOF_SESSION_SECRET" -v v="$_sec" '
          BEGIN { done = 0 }
          $0 ~ ("^[[:space:]]*" k "=") { print k "=" v; done = 1; next }
          { print }
          END { if (!done) print k "=" v }
        ' .env > "$_env_tmp" && mv "$_env_tmp" .env
        chmod 600 .env 2>/dev/null || true
        echo "已生成 RULEPROOF_SESSION_SECRET 并写入 .env（生产必填；如需外部密钥托管请显式覆盖）"
      else
        echo "警告：.env 不可写，本次启动使用临时生成的 RULEPROOF_SESSION_SECRET；重启后会话失效" >&2
      fi
    fi
    ;;
esac

if [ "${RULEPROOF_SEED:-0}" = "1" ] || [ ! -f "$RULEPROOF_DB" ]; then
  "$PY" seed.py
else
  echo "数据库已存在，跳过 seed（如需重建演示数据：RULEPROOF_SEED_DEMO=1 RULEPROOF_SEED=1 ./start.sh）"
fi
# host 透传：显式设置 RULEPROOF_HOST 时传给 server；未设置时不传，由 app/config.py
# 保持默认 127.0.0.1（本机安全默认；容器部署由 Dockerfile/compose 显式 0.0.0.0）。
# 不在此硬编码 127.0.0.1，避免覆盖 config 从 .env 读取的 RULEPROOF_HOST。
if [ -n "${RULEPROOF_HOST:-}" ]; then
  exec "$PY" -m app.api.server --host "$RULEPROOF_HOST" --port "${RULEPROOF_PORT:-8765}"
fi
exec "$PY" -m app.api.server --port "${RULEPROOF_PORT:-8765}"
