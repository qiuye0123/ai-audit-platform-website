#!/usr/bin/env python3
"""从当前仓库生成“局部升级 zip”。

用法示例::

    # 以最近一次完整交付包为基线，生成只含变更文件的升级包
    python3 scripts/release/build_upgrade_package.py --dry-run
    python3 scripts/release/build_upgrade_package.py --to-version 1.3.7

    # 用显式基线清单（可重复构建）
    python3 scripts/release/build_upgrade_package.py \
        --base-manifest .release_baseline.json --to-version 1.3.7

    # 先写一份当前文件基线（下一次发版用）
    python3 scripts/release/build_upgrade_package.py --write-base-manifest .release_baseline.json

包结构：文件相对路径 + ``UPGRADE_MANIFEST.json`` + ``SHA256SUMS``。
绝不包含 data/、*.db、.env、dist/、backups/、__pycache__ 等路径。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import release_common as rc  # noqa: E402

DEFAULT_ROOT = HERE.parents[1]
MANIFEST_NAME = "UPGRADE_MANIFEST.json"
SUMS_NAME = "SHA256SUMS"


def _emit(obj: dict) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=1, default=str))


def _parse_since(raw: str) -> float | None:
    s = str(raw or "").strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        pass
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        dt = datetime.strptime(s, "%Y-%m-%d")
    return dt.timestamp()


def _zip_datetime() -> tuple:
    raw = os.environ.get("SOURCE_DATE_EPOCH", "").strip()
    if raw:
        try:
            return time.gmtime(int(raw))[:6]
        except Exception:
            pass
    return time.localtime()[:6]


def _zip_info(name: str, mode: int | None = None) -> zipfile.ZipInfo:
    zi = zipfile.ZipInfo(name, date_time=_zip_datetime())
    zi.compress_type = zipfile.ZIP_DEFLATED
    zi.external_attr = ((int(mode) if mode else 0o644) & 0xFFFF) << 16
    return zi


def _migrations_from(files: list[dict]) -> list[dict]:
    out = []
    for f in files:
        path = f["path"]
        if path.startswith("migrations/"):
            out.append({"id": Path(path).stem, "path": path, "sha256": f["sha256"]})
        elif path == "app/data_migrations.py":
            out.append({"id": "app.data_migrations", "path": path,
                        "sha256": f["sha256"]})
    return out


def _load_baseline(args) -> tuple[dict[str, str], dict]:
    if args.base_manifest:
        p = Path(args.base_manifest).resolve()
        return rc.load_baseline_json(p), {"type": "manifest", "ref": str(p)}
    if args.base_package:
        p = Path(args.base_package).resolve()
        return rc.load_baseline_package(p), {"type": "package", "ref": str(p)}
    if args.base_sha256sums:
        p = Path(args.base_sha256sums).resolve()
        return rc.load_sha256sums(p), {"type": "sha256sums", "ref": str(p)}
    p = rc.discover_default_baseline(args.root)
    if p:
        if p.suffix.lower() == ".zip":
            return rc.load_baseline_package(p), {"type": "package", "ref": str(p)}
        return rc.load_baseline_json(p), {"type": "manifest", "ref": str(p)}
    return {}, {"type": "none", "ref": ""}


def _explicit_files(raw_list: list[str] | None, root: Path) -> list[str]:
    out: list[str] = []
    for raw in raw_list or []:
        for item in str(raw).split(","):
            item = item.strip()
            if not item:
                continue
            rel = rc.normalize_rel(item)
            if rc.is_protected_target(rel):
                raise ValueError(f"显式文件命中禁止升级路径：{rel}")
            if not rc.is_tracked(rel):
                raise ValueError(f"显式文件不在可升级白名单：{rel}")
            if not (root / rel).is_file():
                raise FileNotFoundError(f"显式文件不存在：{rel}")
            out.append(rel)
    return sorted(set(out))


def build(args) -> dict:
    root = Path(args.root).resolve()
    if not root.exists():
        return {"ok": False, "code": "root_not_found", "error": f"仓库目录不存在：{root}"}
    version = rc.read_version(root)
    from_version = args.from_version or version
    to_version = args.to_version or (
        f"{from_version}+upgrade.{time.strftime('%Y%m%d%H%M%S')}")
    since = _parse_since(args.changed_since)
    tracked = rc.iter_tracked_files(root)

    if args.write_base_manifest:
        target = Path(args.write_base_manifest).resolve()
        files = []
        for rel in tracked:
            p = root / rel
            files.append({"path": rel, "sha256": rc.sha256_file(p),
                          "size": p.stat().st_size})
        payload = {
            "schema": 1,
            "version": version,
            "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "files": {f["path"]: {"sha256": f["sha256"], "size": f["size"]}
                      for f in files},
        }
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(payload, ensure_ascii=False, indent=1) + "\n",
                          encoding="utf-8")
        return {"ok": True, "mode": "write_base_manifest", "output": str(target),
                "file_count": len(files), "version": version}

    baseline: dict[str, str] = {}
    base_info = {"type": "explicit", "ref": ""}
    explicit = _explicit_files(args.files, root) if args.files else None
    if explicit is not None:
        base_info = {"type": "explicit", "ref": "args.files"}
    elif args.all:
        base_info = {"type": "all", "ref": "args.all"}
    else:
        baseline, base_info = _load_baseline(args)
        if not baseline and not args.allow_no_baseline:
            return {
                "ok": False, "code": "baseline_required",
                "error": "未找到基线。请用 --base-manifest / --base-package / "
                         "--base-sha256sums / --files / --all 指定，或先运行 "
                         "--write-base-manifest 生成基线清单。",
            }
        base_info["file_count"] = len(baseline)

    files = []
    skipped_unchanged = []
    for rel in tracked:
        if explicit is not None and rel not in set(explicit):
            continue
        p = root / rel
        if since is not None and p.stat().st_mtime <= since:
            continue
        h = rc.sha256_file(p)
        if explicit is None and not args.all and baseline.get(rel) == h:
            skipped_unchanged.append(rel)
            continue
        files.append({"path": rel, "sha256": h, "size": p.stat().st_size,
                      "mode": int(p.stat().st_mode & 0o777)})
    files.sort(key=lambda x: x["path"])
    migrations = _migrations_from(files)
    digest = rc.files_digest(files)
    manifest = {
        "schema": 1,
        "from_version": from_version,
        "to_version": to_version,
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "files": files,
        "file_count": len(files),
        "sha256": digest,
        "migrations": migrations,
        "base": base_info,
        "note": "仅包含相对基线发生变更的文件；不包含删除操作，不触碰 data/*.db。",
    }
    safe_to = re.sub(r"[^0-9A-Za-z._+-]+", "_", str(to_version))[:80] or "upgrade"
    out_path = (Path(args.output).resolve() if args.output else
                root / "dist" / "upgrades" /
                f"AI审核平台-{from_version}-to-{safe_to}-局部升级-"
                f"{time.strftime('%Y%m%d')}.zip")
    plan = {
        "ok": True,
        "dry_run": bool(args.dry_run),
        "from_version": from_version,
        "to_version": to_version,
        "file_count": len(files),
        "files": [{"path": f["path"], "size": f["size"], "sha256": f["sha256"],
                   "mode": f.get("mode")} for f in files],
        "migrations": migrations,
        "sha256": digest,
        "output": str(out_path),
        "base": base_info,
        "unchanged_count": len(skipped_unchanged),
    }
    if args.dry_run:
        plan["manifest"] = manifest
        return plan
    if not files:
        return {"ok": False, "code": "no_changes",
                "error": "没有相对基线的变更文件；未生成升级包。",
                "unchanged_count": len(skipped_unchanged), "base": base_info}
    if out_path.exists() and not args.force:
        return {"ok": False, "code": "output_exists",
                "error": f"输出已存在（加 --force 覆盖）：{out_path}"}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_name(out_path.name + f".tmp-{os.getpid()}")
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr(_zip_info(MANIFEST_NAME),
                       json.dumps(manifest, ensure_ascii=False, indent=1) + "\n")
            sums = "".join(f"{f['sha256']}  {f['path']}\n" for f in files)
            z.writestr(_zip_info(SUMS_NAME), sums)
            for f in files:
                z.writestr(_zip_info(f["path"], f.get("mode")),
                           (root / f["path"]).read_bytes())
        os.replace(tmp, out_path)
    except Exception:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        raise
    plan.update({"output": str(out_path), "bytes": out_path.stat().st_size})
    return plan


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="生成局部升级 zip（含 UPGRADE_MANIFEST.json）")
    ap.add_argument("--root", default=str(DEFAULT_ROOT), help="仓库根目录")
    ap.add_argument("--base-manifest", default="", help="基线文件清单 JSON")
    ap.add_argument("--base-package", default="", help="基线完整交付 zip")
    ap.add_argument("--base-sha256sums", default="", help="基线 SHA256SUMS 文件")
    ap.add_argument("--files", action="append", default=[],
                    help="显式变更文件（可逗号分隔/多次）")
    ap.add_argument("--all", action="store_true", help="包含全部受控文件（首次发版）")
    ap.add_argument("--allow-no-baseline", action="store_true",
                    help="没有基线时按 --all 处理；不建议日常使用")
    ap.add_argument("--changed-since", default="", help="只含 mtime 晚于该时间的文件")
    ap.add_argument("--from-version", default="")
    ap.add_argument("--to-version", default="")
    ap.add_argument("--output", default="")
    ap.add_argument("--dry-run", action="store_true", help="只打印计划，不写 zip")
    ap.add_argument("--force", action="store_true", help="覆盖已存在的输出文件")
    ap.add_argument("--write-base-manifest", default="",
                    help="写当前文件基线清单后退出")
    ap.add_argument("--json", action="store_true", help="JSON 输出（默认即 JSON）")
    args = ap.parse_args(argv)
    try:
        result = build(args)
    except Exception as exc:  # noqa: BLE001
        result = {"ok": False, "code": "build_failed",
                  "error": f"{type(exc).__name__}: {exc}"}
    _emit(result)
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
