# 局部升级包（增量升级）

面向“完整交付包已经上线，只替换本次变更文件”的场景。不修改、不重建已有完整包。

## 1. 生成升级包

```bash
# 以最近一次 *完整交付版*.zip 为基线，先看计划
python3 scripts/release/build_upgrade_package.py --dry-run

# 生成（默认输出 dist/upgrades/AI审核平台-<from>-to-<to>-局部升级-<日期>.zip）
python3 scripts/release/build_upgrade_package.py --to-version 1.3.7

# 指定基线（推荐：可重复构建）
python3 scripts/release/build_upgrade_package.py \
  --base-manifest .release_baseline.json \
  --to-version 1.3.7
```

基线来源优先级：`--base-manifest` > `--base-package` > `--base-sha256sums` >
仓库根目录的 `.release_baseline.json` > 最近一次 `*完整交付版*.zip`。
首次给某个版本立基线：

```bash
python3 scripts/release/build_upgrade_package.py \
  --write-base-manifest .release_baseline.json
```

升级包只包含 `app/ web/ migrations/ seed/ scripts/ docs/` 与根目录白名单文件，
并自动排除 `data/`、`*.db`、`uploads/`、`backups/`、`dist/`、`__pycache__/`、
`.env` 等路径。包内包含：

- `UPGRADE_MANIFEST.json`：`from_version / to_version / files / sha256 / migrations / created_at`
  （每个文件带 sha256、size、mode；`sha256` 是 files 列表的聚合摘要）；
- `SHA256SUMS`；
- 变更文件本体（不包含删除操作）。

## 2. 应用升级包

```bash
# 只校验并打印计划，不写任何文件
python3 scripts/release/apply_upgrade_package.py \
  --package dist/upgrades/xxx.zip --dry-run

# 正式应用（显式指定生产库；不指定 --db 则不会碰数据库）
python3 scripts/release/apply_upgrade_package.py \
  --package dist/upgrades/xxx.zip \
  --db data/ruleproof.db
```

行为：

1. 校验清单字段、文件 sha256、聚合摘要、`SHA256SUMS`、zip 路径穿越/符号链接；
2. 当前 `VERSION` 与 `from_version` 不一致时默认拒绝（`--allow-version-mismatch` 可绕过）；
3. 先备份将被覆盖的文件到 `backups/upgrades/<时间>-<to_version>/`，写 `journal.json`；
   同时用 SQLite 在线备份 `--db`；
4. 原子写入文件；再执行 `app.data_migrations`（幂等、事务化、迁移前再备份）；
5. 重复应用时目标文件 sha256 已一致则跳过，不重复写；
6. 文件写入或迁移失败：按 journal 恢复旧文件 / 删除本次新建文件，并保留备份目录；
7. `platform_upgrade` 记录最近一次升级，`/api/v1/ops/overview` 可查看。

## 3. 安全边界

- 升级包永远不能写 `data/`、`uploads/`、`backups/`、`*.db`、`.env`；
- 不删除任何文件；
- 迁移默认不自动运行，必须由升级脚本显式指定 `--db` 才执行；
- 应用失败不会留下“半套文件”：journal 可人工复核。

## 4. 相关测试

```bash
python3 scripts/qa/upgrade_package_test.py
python3 scripts/qa/db_data_layer_test.py
```
