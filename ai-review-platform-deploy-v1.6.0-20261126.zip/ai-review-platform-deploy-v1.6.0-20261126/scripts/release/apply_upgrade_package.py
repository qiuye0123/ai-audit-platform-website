#!/usr/bin/env python3
"""校验并应用“局部升级 zip”。

安全约束（与需求一致）：
- 先校验清单与每个文件 sha256，再 dry-run 可选；
- 应用前先做文件备份（可回滚）与 SQLite 在线备份；
- 只写清单内文件，绝不删除/覆盖 data/、*.db、.env、backups/ 等业务数据；
- 写入失败/迁移失败自动回滚已写文件（从备份目录恢复）；
- 幂等：目标文件 sha256 已一致则跳过，重复应用不重复写。

示例::

    python3 scripts/release/apply_upgrade_package.py --package dist/upgrades/x.zip --dry-run
    python3 scripts/release/apply_upgrade_package.py --package x.zip --db data/ruleproof.db
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(DEFAULT_ROOT))

import release_common as rc  # noqa: E402

MANIFEST_NAME = "UPGRADE_MANIFEST.json"
SUMS_NAME = "SHA256SUMS"
MAX_PACKAGE_BYTES = 500 * 1024 * 1024
REQUIRED_MANIFEST_FIELDS = ("from_version", "to_version", "files", "sha256",
                            "migrations", "created_at")


class PackageError(Exception):
    def __init__(self, errors: list[str], code: str = "invalid_package"):
        super().__init__("; ".join(errors) or code)
        self.errors = errors
        self.code = code


def _emit(obj: dict) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=1, default=str))


def _parse_sums(text: str) -> dict[str, str]:
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        h, name = parts[0].lower(), parts[1].lstrip("*").strip()
        try:
            out[rc.normalize_rel(name)] = h
        except ValueError:
            continue
    return out


def _safe_version(text: str) -> str:
    return re.sub(r"[^0-9A-Za-z._+-]+", "_", str(text or ""))[:80] or "upgrade"


def read_package(path: str | Path) -> dict:
    """读取并完整校验升级包；任何不一致都抛 PackageError。"""
    p = Path(path).resolve()
    if not p.exists():
        raise PackageError([f"升级包不存在：{p}"], "package_not_found")
    errors: list[str] = []
    try:
        zf = zipfile.ZipFile(p)
    except Exception as exc:
        raise PackageError([f"无法打开 zip：{type(exc).__name__}: {exc}"], "bad_zip")
    with zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        total = sum(int(i.file_size or 0) for i in infos)
        if total > MAX_PACKAGE_BYTES:
            errors.append(f"包解压后体积过大：{total} > {MAX_PACKAGE_BYTES}")
        names = [i.filename for i in infos]
        # 兼容“顶层目录”的包；优先要求根目录有清单
        manifest_member = None
        if MANIFEST_NAME in names:
            manifest_member = MANIFEST_NAME
            prefix = ""
        else:
            cands = [n for n in names if n.endswith("/" + MANIFEST_NAME)]
            if len(cands) == 1:
                manifest_member = cands[0]
                prefix = manifest_member[: -len(MANIFEST_NAME)]
            elif len(cands) > 1:
                errors.append("zip 内存在多个 UPGRADE_MANIFEST.json")
        # zip 关闭后仍要校验/应用文件，先一次性读入（上限已做保护）
        raw_bytes = {i.filename: zf.read(i) for i in infos}
    if errors:
        raise PackageError(errors)
    if not manifest_member:
        raise PackageError(["缺少 UPGRADE_MANIFEST.json"], "manifest_missing")
    strip = (lambda n: n[len(prefix):] if prefix and n.startswith(prefix) else n)
    members: dict[str, zipfile.ZipInfo] = {}
    lowered: dict[str, str] = {}
    for info in infos:
        raw = info.filename
        if raw.startswith("/") or "\\" in raw or ".." in raw.split("/"):
            errors.append(f"非法 zip 路径：{raw}")
            continue
        if prefix and not raw.startswith(prefix):
            errors.append(f"zip 顶层目录不一致：{raw}")
            continue
        rel = strip(raw)
        try:
            rel = rc.normalize_rel(rel)
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if rel in members:
            errors.append(f"zip 重复文件：{rel}")
            continue
        if (info.external_attr >> 16) & 0o170000 == 0o120000:
            errors.append(f"zip 不允许符号链接：{rel}")
            continue
        members[rel] = info
        low = rel.lower()
        if low in lowered and lowered[low] != rel:
            errors.append(f"大小写冲突：{lowered[low]} vs {rel}")
        lowered[low] = rel
    if errors:
        raise PackageError(errors)

    if MANIFEST_NAME not in members:
        raise PackageError(["缺少 UPGRADE_MANIFEST.json"], "manifest_missing")
    try:
        manifest = json.loads(raw_bytes[members[MANIFEST_NAME].filename].decode("utf-8"))
    except Exception as exc:
        raise PackageError([f"清单不是合法 JSON：{type(exc).__name__}: {exc}"],
                           "manifest_invalid")
    if not isinstance(manifest, dict):
        raise PackageError(["清单必须是 JSON 对象"], "manifest_invalid")
    for field in REQUIRED_MANIFEST_FIELDS:
        if field not in manifest:
            errors.append(f"清单缺少字段：{field}")
    for field in ("from_version", "to_version", "created_at", "sha256"):
        if not isinstance(manifest.get(field), str) or not manifest.get(field):
            errors.append(f"清单字段必须是非空字符串：{field}")
    raw_files = manifest.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        errors.append("清单 files 必须是非空数组")
        raw_files = []
    files: list[dict] = []
    seen: set[str] = set()
    for item in raw_files:
        if not isinstance(item, dict):
            errors.append("files 条目必须是对象")
            continue
        try:
            rel = rc.normalize_rel(item.get("path") or "")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if rel in seen:
            errors.append(f"清单重复文件：{rel}")
            continue
        seen.add(rel)
        if not rc.is_tracked(rel):
            errors.append(f"清单包含非升级白名单路径：{rel}")
        if rc.is_protected_target(rel):
            errors.append(f"清单包含禁止写入路径：{rel}")
        sha = str(item.get("sha256") or "").lower()
        if not re.fullmatch(r"[0-9a-f]{64}", sha):
            errors.append(f"sha256 格式非法：{rel}")
        size = item.get("size")
        if size is not None and not isinstance(size, int):
            errors.append(f"size 必须是整数：{rel}")
        mode = item.get("mode", 0o644)
        if not isinstance(mode, int) or not (0 <= mode <= 0o777):
            errors.append(f"mode 非法：{rel}")
            mode = 0o644
        files.append({"path": rel, "sha256": sha,
                      "size": int(size) if isinstance(size, int) else None,
                      "mode": int(mode)})
    fc = manifest.get("file_count")
    if fc is not None and fc != len(files):
        errors.append(f"清单 file_count 与 files 数量不一致：{fc} != {len(files)}")
    if errors:
        raise PackageError(errors)

    # 清单外 zip 文件不允许
    extras = {MANIFEST_NAME}
    if SUMS_NAME in members:
        extras.add(SUMS_NAME)
    zip_files = set(members) - extras
    manifest_files = {f["path"] for f in files}
    if zip_files != manifest_files:
        for name in sorted(zip_files - manifest_files):
            errors.append(f"zip 含清单外文件：{name}")
        for name in sorted(manifest_files - zip_files):
            errors.append(f"zip 缺少清单文件：{name}")
    if errors:
        raise PackageError(errors)

    # 逐文件校验 sha256（同时保留 bytes，避免应用时再次读 zip）
    payload: dict[str, bytes] = {}
    for f in files:
        try:
            data = raw_bytes[members[f["path"]].filename]
        except Exception as exc:
            errors.append(f"读取失败 {f['path']}：{exc}")
            continue
        if len(data) != (f["size"] if f["size"] is not None else len(data)):
            errors.append(f"文件大小不一致：{f['path']}")
        if rc.sha256_bytes(data) != f["sha256"]:
            errors.append(f"文件 sha256 不一致：{f['path']}")
        payload[f["path"]] = data
    # 聚合摘要
    if not errors and isinstance(manifest.get("sha256"), str):
        digest = rc.files_digest([{"path": f["path"], "sha256": f["sha256"],
                                   "size": len(payload[f["path"]])} for f in files])
        if digest != manifest["sha256"].lower():
            errors.append("清单聚合 sha256 校验失败（files 列表可能被篡改）")
    # SHA256SUMS（如果存在）与清单严格一致
    if SUMS_NAME in members and not errors:
        sums = _parse_sums(raw_bytes[members[SUMS_NAME].filename].decode("utf-8", "replace"))
        expected = {f["path"]: f["sha256"] for f in files}
        if sums != expected:
            errors.append("SHA256SUMS 与清单不一致")
    # migrations 引用必须存在且 sha 一致
    migrations = manifest.get("migrations")
    if not isinstance(migrations, list):
        errors.append("清单 migrations 必须是数组")
        migrations = []
    by_path = {f["path"]: f for f in files}
    for m in migrations:
        if not isinstance(m, dict):
            errors.append("migrations 条目必须是对象")
            continue
        try:
            mp = rc.normalize_rel(m.get("path") or "")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if mp not in by_path:
            errors.append(f"migrations 引用了未打包文件：{mp}")
        elif m.get("sha256") and str(m["sha256"]).lower() != by_path[mp]["sha256"]:
            errors.append(f"migrations sha256 不一致：{mp}")
    if errors:
        raise PackageError(errors)
    return {"path": p, "manifest": manifest, "files": files,
            "payload": payload, "migrations": migrations}


def _target_plan(root: Path, pkg: dict) -> dict:
    plan = []
    errors = []
    root_real = root.resolve()
    for f in pkg["files"]:
        target = root / f["path"]
        # 防止父目录是符号链接导致写出 root（例如 web -> /etc）
        try:
            target_real = target.resolve()
            if target_real != root_real and root_real not in target_real.parents:
                errors.append(f"目标路径越出部署目录：{f['path']}")
                continue
        except OSError:
            errors.append(f"目标路径无法解析：{f['path']}")
            continue
        existed = target.exists()
        state = "create"
        if target.is_symlink():
            errors.append(f"目标为符号链接，拒绝写入：{f['path']}")
        if existed and not target.is_file():
            errors.append(f"目标是目录/特殊文件，拒绝写入：{f['path']}")
        if existed and target.is_file():
            if rc.sha256_file(target) == f["sha256"]:
                state = "unchanged"
            else:
                state = "update"
        plan.append({**f, "state": state, "existed": existed})
    return {"files": plan, "errors": errors,
            "changed": [x for x in plan if x["state"] != "unchanged"]}


def _atomic_write(target: Path, data: bytes, mode: int) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(f".{target.name}.rp-upgrade-{os.getpid()}")
    with open(tmp, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    try:
        os.chmod(tmp, int(mode) or 0o644)
    except OSError:
        pass
    os.replace(tmp, target)


def _rollback(root: Path, backup_dir: Path, entries: list[dict]) -> list[str]:
    errors = []
    for e in reversed(entries):
        if not e.get("written"):
            continue
        target = root / e["path"]
        try:
            if e.get("existed"):
                src = backup_dir / e["backup"]
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, target)
                try:
                    # 恢复原文件权限，而不是新包权限
                    os.chmod(target, int(e.get("original_mode") or 0o644))
                except OSError:
                    pass
            else:
                if target.exists() and target.is_file():
                    target.unlink()
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{e['path']}: {type(exc).__name__}: {exc}")
    return errors


def _run_module(root: Path, args: list[str], timeout: int = 900) -> dict:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root) + (os.pathsep + env["PYTHONPATH"]
                                     if env.get("PYTHONPATH") else "")
    r = subprocess.run([sys.executable, "-m", "app.data_migrations", *args],
                       cwd=str(root), env=env, capture_output=True, text=True,
                       timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError((r.stdout or "")[-1000:] + (r.stderr or "")[-1000:]
                           or f"exit {r.returncode}")
    try:
        return json.loads(r.stdout or "{}")
    except Exception:
        raise RuntimeError(f"数据迁移输出不是 JSON：{(r.stdout or '')[:500]}")


def apply_package(args) -> dict:
    root = Path(args.root).resolve()
    if not root.is_dir():
        return {"ok": False, "code": "root_not_found",
                "error": f"目标目录不存在：{root}"}
    try:
        pkg = read_package(args.package)
    except PackageError as exc:
        return {"ok": False, "code": exc.code, "errors": exc.errors,
                "error": str(exc)}
    manifest = pkg["manifest"]
    current_version = rc.read_version(root)
    if (manifest.get("from_version") != current_version
            and not (args.force or args.allow_version_mismatch)):
        return {"ok": False, "code": "version_mismatch",
                "error": f"当前版本 {current_version} 与包 from_version "
                         f"{manifest.get('from_version')} 不一致；"
                         f"确认后用 --allow-version-mismatch",
                "current_version": current_version,
                "from_version": manifest.get("from_version")}
    plan = _target_plan(root, pkg)
    if plan["errors"]:
        return {"ok": False, "code": "target_conflict", "errors": plan["errors"],
                "error": "; ".join(plan["errors"])}
    changed = plan["changed"]
    db_path = Path(args.db).resolve() if args.db else None
    need_migrations = bool(pkg["migrations"])
    if need_migrations and not db_path and not args.allow_no_db and not args.dry_run:
        return {"ok": False, "code": "db_required_for_migrations",
                "error": "包内含 migrations，但未指定 --db；"
                         "如确认只升级文件，用 --allow-no-db",
                "migrations": pkg["migrations"]}
    if db_path and not db_path.exists() and need_migrations and not args.allow_no_db:
        return {"ok": False, "code": "db_not_found",
                "error": f"数据库不存在：{db_path}"}
    summary = {
        "ok": True,
        "dry_run": bool(args.dry_run),
        "package": str(pkg["path"]),
        "package_sha256": manifest.get("sha256"),
        "from_version": manifest.get("from_version"),
        "to_version": manifest.get("to_version"),
        "current_version": current_version,
        "file_count": len(pkg["files"]),
        "changed_count": len(changed),
        "created": [x["path"] for x in plan["files"] if x["state"] == "create"],
        "updated": [x["path"] for x in plan["files"] if x["state"] == "update"],
        "unchanged_count": len(plan["files"]) - len(changed),
        "migrations": pkg["migrations"],
        "db": str(db_path) if db_path else None,
        "backup_dir": None,
        "db_backup": None,
        "migration_result": None,
        "db_record": None,
        "notes": [],
    }
    if args.dry_run:
        if need_migrations and not db_path:
            summary["notes"].append("dry-run：包内含 migrations；正式应用时需 --db 才会执行数据库迁移")
        summary["plan"] = [{"path": x["path"], "state": x["state"]} for x in plan["files"]]
        return summary
    if not changed and not need_migrations and not (db_path and db_path.exists()):
        summary["notes"].append("目标文件均已是最新，且无迁移/DB 记录；无需写入")
        return summary

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup_dir = (Path(args.backup_dir).resolve() if args.backup_dir else
                  root / "backups" / "upgrades" /
                  f"{stamp}-{_safe_version(manifest.get('to_version'))}")
    _protected_dirs = [root / "data", root / "uploads", root / ".git"]
    if backup_dir == root or any(backup_dir == d or d in backup_dir.parents
                                 for d in _protected_dirs):
        return {"ok": False, "code": "invalid_backup_dir",
                "error": f"备份目录不能位于业务数据目录内：{backup_dir}"}
    # 1) 文件备份（先于任何写入）
    entries: list[dict] = []
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        for x in changed:
            target = root / x["path"]
            existed = target.exists()
            bpath = ""
            if existed:
                rel_b = "files/" + x["path"]
                (backup_dir / rel_b).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup_dir / rel_b)
                bpath = rel_b
            entries.append({"path": x["path"], "existed": existed,
                            "backup": bpath, "written": False,
                            "mode": x.get("mode"),
                            "original_mode": (target.stat().st_mode & 0o777
                                              if existed else None)})
        # 2) DB 备份（只要指定了 db 且存在；迁移/记录前必须可回滚）
        db_backup_info = None
        if db_path and db_path.exists():
            from app.services import db_backup
            db_backup_info = db_backup.backup(db_path, backup_dir=backup_dir,
                                              label="pre-upgrade")
        journal = {
            "schema": 1,
            "package": str(pkg["path"]),
            "package_sha256": manifest.get("sha256"),
            "from_version": manifest.get("from_version"),
            "to_version": manifest.get("to_version"),
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "db": str(db_path) if db_path else None,
            "db_backup": db_backup_info.get("backup") if db_backup_info else None,
            "entries": entries,
        }
        (backup_dir / "journal.json").write_text(
            json.dumps(journal, ensure_ascii=False, indent=1, default=str) + "\n",
            encoding="utf-8")
        summary["backup_dir"] = str(backup_dir)
        summary["db_backup"] = db_backup_info.get("backup") if db_backup_info else None
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "code": "backup_failed",
                "error": f"备份失败，未写入任何文件：{type(exc).__name__}: {exc}",
                "backup_dir": str(backup_dir)}

    # 3) 写文件；失败立即回滚
    try:
        for e in entries:
            data = pkg["payload"][e["path"]]
            target = root / e["path"]
            _atomic_write(target, data, e.get("mode") or 0o644)
            if rc.sha256_file(target) != next(
                    f["sha256"] for f in pkg["files"] if f["path"] == e["path"]):
                raise RuntimeError(f"写入后校验失败：{e['path']}")
            e["written"] = True
        # 4) DB 迁移
        if need_migrations:
            if db_path and db_path.exists() and not args.skip_migrations:
                _mig_args = ["--db", str(db_path), "--json"]
                if backup_dir:
                    _mig_args += ["--backup-dir", str(backup_dir)]
                summary["migration_result"] = _run_module(root, _mig_args)
            elif args.skip_migrations:
                summary["notes"].append("按 --skip-migrations 跳过数据库迁移")
            else:
                summary["notes"].append("未指定/找不到 --db，跳过数据库迁移")
        elif args.skip_migrations:
            summary["notes"].append("--skip-migrations 指定，但包内无 migrations")
        # 5) 记录升级（幂等；失败只告警，不回滚已成功的迁移）
        if db_path and db_path.exists() and not args.skip_db_record:
            try:
                summary["db_record"] = _run_module(root, [
                    "--db", str(db_path), "--json", "--record-only",
                    "--from-version", str(manifest.get("from_version") or ""),
                    "--to-version", str(manifest.get("to_version") or ""),
                    "--package", str(pkg["path"]),
                    "--package-sha256", str(manifest.get("sha256") or ""),
                    "--files-count", str(len(pkg["files"])),
                ])
            except Exception as exc:  # noqa: BLE001
                summary["notes"].append(
                    f"升级记录写入失败（不影响文件升级）：{type(exc).__name__}: {exc}")
        elif not db_path:
            summary["notes"].append("未指定 --db，未写 platform_upgrade 升级记录")
    except Exception as exc:  # noqa: BLE001
        rb_errors = _rollback(root, backup_dir, entries)
        try:
            journal = json.loads((backup_dir / "journal.json").read_text(encoding="utf-8"))
        except Exception:
            journal = {}
        journal["rolled_back"] = True
        journal["error"] = f"{type(exc).__name__}: {exc}"
        journal["rollback_errors"] = rb_errors
        try:
            (backup_dir / "journal.json").write_text(
                json.dumps(journal, ensure_ascii=False, indent=1, default=str) + "\n",
                encoding="utf-8")
        except Exception:
            pass
        return {"ok": False, "code": "apply_failed",
                "error": f"{type(exc).__name__}: {exc}",
                "rolled_back": True,
                "rollback_errors": rb_errors,
                "backup_dir": str(backup_dir)}
    summary["rolled_back"] = False
    return summary


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="校验并应用局部升级 zip")
    ap.add_argument("--package", required=True, help="局部升级 zip")
    ap.add_argument("--root", default=str(DEFAULT_ROOT), help="目标部署根目录")
    ap.add_argument("--db", default="",
                    help="SQLite 路径；不填则完全不碰 DB（含 migrations 的包必须显式指定）")
    ap.add_argument("--backup-dir", default="", help="备份目录；默认 root/backups/upgrades/<stamp>")
    ap.add_argument("--dry-run", action="store_true", help="只校验并打印计划")
    ap.add_argument("--skip-migrations", action="store_true")
    ap.add_argument("--skip-db-record", action="store_true")
    ap.add_argument("--allow-no-db", action="store_true",
                    help="包内有 migrations 也允许不提供 --db（仅升级文件）")
    ap.add_argument("--allow-version-mismatch", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        result = apply_package(args)
    except Exception as exc:  # noqa: BLE001
        result = {"ok": False, "code": "apply_failed",
                  "error": f"{type(exc).__name__}: {exc}"}
    _emit(result)
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
