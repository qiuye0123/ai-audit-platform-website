"""增量升级包公共工具：路径白名单、sha256、基线清单读取。

被 ``build_upgrade_package.py`` 与 ``apply_upgrade_package.py`` 共用，
避免构建和应用两侧对“哪些文件可升级/哪些路径禁止写”的理解不一致。
"""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path, PurePosixPath

# 只有这些目录/根文件会进入增量升级包；data/、dist/、backups/、__pycache__ 永不打包。
TRACKED_ROOTS = {"app", "web", "migrations", "seed", "scripts", "docs"}
TRACKED_ROOT_FILES = {
    "VERSION", "README.md", "rp", "start.sh", "requirements.txt", "Dockerfile",
    "docker-compose.yml", ".env.example", "AGENTS.md", "PROJECT_MEMORY.md",
    "交付说明.md", "Makefile",
}
EXCLUDE_PARTS = {
    "__pycache__", ".git", ".hg", ".svn", "data", "dist", "backups", ".qa",
    "node_modules", ".venv", "venv", "uploads", "_archive", "tests",
    ".chrome-ia", ".chrome-lib", ".chrome-ui", ".chrome-wb", ".chrome-wb2",
}
EXCLUDE_SUFFIXES = {
    ".pyc", ".pyo", ".db", ".db-wal", ".db-shm", ".sqlite", ".sqlite3",
    ".zip", ".log", ".pid", ".DS_Store", ".swp", ".tmp",
}
PROTECTED_ROOTS = {"data", "uploads", "backups", ".git", "dist"}
PROTECTED_SUFFIXES = {".db", ".db-wal", ".db-shm", ".sqlite", ".sqlite3"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_rel(raw: str) -> str:
    """规范化相对路径；拒绝绝对路径 / .. / 反斜杠穿越。"""
    s = str(raw or "").replace("\\", "/").strip()
    if not s or s.startswith("/") or s.startswith("~"):
        raise ValueError(f"非法路径：{raw!r}")
    p = PurePosixPath(s)
    if any(part in ("..", ".") for part in p.parts):
        raise ValueError(f"非法路径：{raw!r}")
    return p.as_posix()


def is_tracked(rel: str) -> bool:
    try:
        p = PurePosixPath(normalize_rel(rel))
    except ValueError:
        return False
    if not p.parts:
        return False
    if any(part in EXCLUDE_PARTS for part in p.parts):
        return False
    if p.suffix.lower() in EXCLUDE_SUFFIXES:
        return False
    if p.name.startswith(".") and p.as_posix() not in TRACKED_ROOT_FILES:
        return False
    if len(p.parts) == 1:
        return p.as_posix() in TRACKED_ROOT_FILES
    return p.parts[0] in TRACKED_ROOTS


def is_protected_target(rel: str) -> bool:
    """升级包永远不允许写/删的路径（业务数据、数据库、环境密钥）。"""
    try:
        p = PurePosixPath(normalize_rel(rel))
    except ValueError:
        return True
    if not p.parts:
        return True
    if p.parts[0] in PROTECTED_ROOTS:
        return True
    if p.suffix.lower() in PROTECTED_SUFFIXES:
        return True
    if p.name in (".env", ".env.local", ".env.production"):
        return True
    if len(p.parts) == 1 and p.as_posix() not in TRACKED_ROOT_FILES and p.as_posix() != "UPGRADE_MANIFEST.json":
        # 根目录只允许白名单文件 + 包清单
        return True
    return False


def iter_tracked_files(root: str | Path) -> list[str]:
    root = Path(root)
    out: list[str] = []
    for p in root.rglob("*"):
        if not p.is_file() or p.is_symlink():
            continue
        rel = p.relative_to(root).as_posix()
        if is_tracked(rel):
            out.append(rel)
    return sorted(out)


def files_digest(files: list[dict]) -> str:
    """对 files 列表（path/sha256/size）做规范化摘要。"""
    canon = [{"path": f.get("path"), "sha256": f.get("sha256"),
              "size": int(f.get("size") or 0)} for f in files]
    canon.sort(key=lambda x: str(x["path"]))
    raw = json.dumps(canon, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def read_version(root: str | Path) -> str:
    p = Path(root) / "VERSION"
    try:
        return p.read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def load_baseline_json(path: str | Path) -> dict[str, str]:
    """支持 {files:{path:{sha256}}}, {files:{path:sha}}, {files:[...]} 三种格式。"""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    files = data.get("files") if isinstance(data, dict) else data
    out: dict[str, str] = {}
    if isinstance(files, dict):
        for k, v in files.items():
            rel = normalize_rel(k)
            if isinstance(v, dict):
                h = v.get("sha256") or v.get("sha")
            else:
                h = str(v)
            if h:
                out[rel] = h
    elif isinstance(files, list):
        for item in files:
            if not isinstance(item, dict):
                continue
            rel = normalize_rel(item.get("path") or "")
            h = item.get("sha256") or item.get("sha")
            if h:
                out[rel] = h
    else:
        raise ValueError("基线清单格式不支持：缺少 files 对象/数组")
    return out


def _strip_zip_prefix(names: list[str]) -> tuple[str, dict[str, str]]:
    """返回 (公共前缀, {相对路径: zip 内路径})；用于兼容完整包顶层目录。"""
    parts = [n.split("/", 1) for n in names]
    firsts = {p[0] for p in parts if len(p) > 1 and p[1]}
    prefix = ""
    if len(firsts) == 1:
        cand = next(iter(firsts))
        # 所有非目录项都在同一个顶层目录下，且顶层有目录项
        if all((len(p) > 1 and p[0] == cand) for p in parts):
            prefix = cand + "/"
    mapping: dict[str, str] = {}
    for n in names:
        rel = n[len(prefix):] if prefix and n.startswith(prefix) else n
        if rel:
            mapping[rel] = n
    return prefix, mapping


def load_baseline_package(path: str | Path) -> dict[str, str]:
    """从已有完整交付 zip/局部包读取 相对路径 -> sha256。"""
    out: dict[str, str] = {}
    with zipfile.ZipFile(path) as z:
        infos = [i for i in z.infolist() if not i.is_dir()]
        names = [i.filename for i in infos]
        _prefix, mapping = _strip_zip_prefix(names)
        for rel, zname in mapping.items():
            try:
                rel_norm = normalize_rel(rel)
            except ValueError:
                continue
            out[rel_norm] = sha256_bytes(z.read(zname))
    return out


def load_sha256sums(path: str | Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        h, name = parts[0], parts[1].lstrip("*").strip()
        try:
            out[normalize_rel(name)] = h
        except ValueError:
            continue
    return out


def discover_default_baseline(root: str | Path) -> Path | None:
    """默认找当前仓库里的完整交付包作为基线；没有则找 .release_baseline.json。"""
    root = Path(root)
    manifest = root / ".release_baseline.json"
    if manifest.exists():
        return manifest
    candidates = [p for p in root.glob("*.zip") if p.is_file() and "完整交付版" in p.name]
    if not candidates:
        candidates = [p for p in root.glob("*.zip") if p.is_file()
                      and ("full" in p.name.lower() or "交付" in p.name)]
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


__all__ = [
    "TRACKED_ROOTS", "TRACKED_ROOT_FILES", "PROTECTED_ROOTS",
    "sha256_bytes", "sha256_file", "normalize_rel", "is_tracked",
    "is_protected_target", "iter_tracked_files", "files_digest",
    "read_version", "load_baseline_json", "load_baseline_package",
    "load_sha256sums", "discover_default_baseline",
]
