#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L118 #10 D1 对称作用域三联体原型（0-LLM，只读；不接主链、不改 app/）。

目标
----
在 /tmp 内用**现有执行链的纯函数**（`app.services.manifest_exec._d1_from_frozen_route` /
`_d1_scope_condition` / `_apply_d1_anchor_cap` + `app.engine.ruleexec.judge_rule`）跑
Clean / Trap / Violated 三联合成稿，量化 D1（适用性）当前能测到多少：

  Clean    = 作用域内 + 证据满足        → 期望「无 finding」(pass)
  Violated = 作用域内 + 证据不满足      → 期望「finding」(fail)  ← 召回
  TrapType = 证据与 Violated **逐字相同**，只改文件类型作用域（.md → .txt）
  TrapCtx  = 证据与 Violated **逐字相同**，只改业务/文类作用域（招标采购 → 食品工艺）

生成口径（确定性，零 gold 反推）
--------------------------------
* 规则来自 `tests/fixtures/l2_exam_v1/tierd_snapshot.json`（已签发 Tier-D 判据快照）；
* 每条 (rule_code, item) 按 item 的 `_xop_spec` 机制参数**程序化生成**满足/不满足两种取值，
  生成后用 `ruleexec.judge_rule` 自校验（满足/不满足），校验不过则换下一条 item；
* 不使用任何 gold / violation_samples / 人工答案；不读测试集标准答案；
* 作用域声明两种口径：
    A `observed`  —— 只含 tierd 快照里真实存在的作用域（`applicable_types` + 机制锚
                     `applicable_when`），no scope_tags → 对应「真实冻结快照」现状；
    B `declared`  —— 在 A 上补业务作用域 tag（来自 L2 rules.json 的 `domain` 字段，
                     D1 20 条规则 domain 均为「招标采购」）→ 代表「作用域声明补齐后」的上限。
* 只改作用域的三联体约束：Violated 证据块与 TrapType/TrapCtx 证据块**字节相同**；
  Clean 与 Violated 只差一个注入数值（同一模板、同一对象）。

边界
----
* 本文件是**原型**：不修改 app/、不写产品库、不接线；`RULEPROOF_DB` 必须指向 /tmp。
* 合成稿 100% 人造，不是真实客户材料；指标只表示「该测试设计在当前执行链下的行为」，
  不是生产准确率。
"""
from __future__ import annotations

import json
import os
import pathlib
import sys

# ---------------------------------------------------------------- 铁律 6：库隔离前置断言
_DB = os.environ.get("RULEPROOF_DB", "")
if not _DB.startswith("/tmp/"):
    raise SystemExit("REFUSE: RULEPROOF_DB=%r 不在 /tmp 下（铁律 6）" % _DB)

PLATFORM_ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(PLATFORM_ROOT) not in sys.path:
    sys.path.insert(0, str(PLATFORM_ROOT))

FIXTURE_RULES = PLATFORM_ROOT / "tests/fixtures/l2_exam_v1/rules.json"
FIXTURE_TIERD = PLATFORM_ROOT / "tests/fixtures/l2_exam_v1/tierd_snapshot.json"

# D1 20 条规则（rules.json 中 layer == D1）；domain 用于推导业务作用域 tag
IN_SCOPE_DOMAIN = "招标采购"
OUT_SCOPE_DOMAIN = "食品工艺"
IN_SCOPE_SCOPE_LINE = "适用范围：%s项目审核材料。" % IN_SCOPE_DOMAIN
OUT_SCOPE_SCOPE_LINE = "适用范围：%s项目审核材料。" % OUT_SCOPE_DOMAIN
IN_SCOPE_CASE_DOC_TYPE = "招标文件"
OUT_SCOPE_CASE_DOC_TYPE = "工艺规程"

# 每个生成器支持的机制（按优先级尝试；数值越小越先尝试，保证确定性）
MODE_PRIORITY = {
    "sum_eq_total": 10, "sum_ratio_eq": 11, "part_le_total": 12,
    "product_eq_total": 13, "lhs_le_rhs": 14, "sum_check": 15,
    "date_le": 20, "date_eq": 21,
    "range_overlap": 30, "require_present": 40, "require_unchanged": 41,
    "alter_detect": 50, "cross_position": 51, "count_eq_stated": 60,
}
SUPPORTED_MODES = sorted(MODE_PRIORITY)

# 作用域声明开关（进程级；probe 每次会显式设置）
STRUCTURAL_ENV = "RULEPROOF_D1_STRUCTURAL"


def _mode_of(item: dict) -> str:
    slots = item.get("slots") or {}
    kind = str(slots.get("_xop_kind") or "")
    if kind == "cross_role_limit":
        return str((slots.get("_xop_spec") or {}).get("mode") or "")
    if kind in ("sum_check", "alter_detect", "cross_position"):
        return kind
    tpl = str(item.get("template") or "")
    if tpl in ("require_present", "require_unchanged"):
        return tpl
    return ""


def _spec(item: dict) -> dict:
    slots = item.get("slots") or {}
    kind = str(slots.get("_xop_kind") or "")
    if kind == "cross_role_limit":
        return dict(slots.get("_xop_spec") or {})
    if kind in ("sum_check", "alter_detect", "cross_position"):
        return dict((slots.get(kind) or {}))
    return {}


def _scope_tokens(item: dict) -> list:
    """从冻结 item 的机制参数推导 applicable_when token（= 声明的作用域文本锚）。

    口径写死：作用域锚 = 该判据机制真正要求原文出现的角色/锚点词，确定性、可审计，
    **不读 gold**。对应 `applicable_when` 字符串里列举的锚点集合。
    """
    mode = _mode_of(item)
    spec = _spec(item)
    if mode in ("sum_eq_total", "sum_ratio_eq", "part_le_total",
                "product_eq_total", "lhs_le_rhs", "date_le", "date_eq",
                "count_eq_stated", "range_overlap"):
        toks = [str(x) for x in (spec.get("lhs_anchors") or [])]
        rhs = spec.get("rhs_anchor")
        if isinstance(rhs, (list, tuple)):
            toks += [str(x) for x in rhs]
        elif rhs:
            toks.append(str(rhs))
        return [t for t in dict.fromkeys(toks) if t]
    if mode == "sum_check":
        return ["合计", "总计", "共计", "其中"]
    if mode in ("alter_detect", "cross_position"):
        return [str(x) for x in (spec.get("anchors") or []) if str(x).strip()]
    if mode in ("require_present", "require_unchanged"):
        slots = item.get("slots") or {}
        toks = [str(x) for x in (slots.get("applicability") or [])]
        return [t for t in dict.fromkeys(toks) if t]
    return []


def _num(x) -> str:
    """稳定的数值文本（整数无小数点；否则保留 1 位小数）。"""
    f = float(x)
    if abs(f - round(f)) < 1e-9:
        return str(int(round(f)))
    return ("%.1f" % f)


def _sum_parts(total: float, n: int) -> list:
    """把 total 拆成 n 个确定性分项（首项最大，余项递减但不为 0）。"""
    if n <= 1:
        return [total]
    weights = [3.0] + [1.5] * (n - 1)
    wsum = sum(weights)
    vals = [total * w / wsum for w in weights]
    vals = [round(v, 2) for v in vals]
    # 修正舍入尾差到首项
    vals[0] = round(vals[0] + (total - sum(vals)), 2)
    return vals


def generate_evidence(item: dict) -> dict:
    """按机制参数确定性生成 (clean_text, violated_text)；不支持则返回 {}。

    返回 {"mode", "clean", "violated", "inject": {...}}；clean/violated 只差注入值。
    不读 gold、不读样本答案。
    """
    mode = _mode_of(item)
    spec = _spec(item)
    slots = item.get("slots") or {}
    if mode not in SUPPORTED_MODES:
        return {}
    clean = violated = ""
    inject = {}
    if mode in ("sum_eq_total", "part_le_total", "sum_ratio_eq", "product_eq_total",
                "lhs_le_rhs", "count_eq_stated", "range_overlap",
                "date_le", "date_eq", "alter_detect", "cross_position"):
        pass
    if mode == "sum_eq_total":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        rhs = (spec.get("rhs_anchor") or [""])
        rhs = str(rhs[0] if isinstance(rhs, list) else rhs)
        if len(lhs) < 2 or not rhs:
            return {}
        total = 100.0
        vals = _sum_parts(total, len(lhs))
        clean = "%s总计%s米。其中%s。" % (
            rhs, _num(total), "，".join("%s%s米" % (a, _num(v)) for a, v in zip(lhs, vals)))
        bad = list(vals)
        bad[0] = round(bad[0] + 20.0, 2)
        violated = "%s总计%s米。其中%s。" % (
            rhs, _num(total), "，".join("%s%s米" % (a, _num(v)) for a, v in zip(lhs, bad)))
        inject = {"object": rhs, "unit": "米", "clean_value": vals[0], "violated_value": bad[0]}
    elif mode == "part_le_total":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        rhs = (spec.get("rhs_anchor") or [""])
        rhs = str(rhs[0] if isinstance(rhs, list) else rhs)
        if len(lhs) < 1 or not rhs:
            return {}
        total = 1000.0
        parts = [200.0 + 100.0 * i for i in range(len(lhs))]
        clean = "%s为%s万元。%s。" % (
            rhs, _num(total), "，".join("%s%s万元" % (a, _num(v)) for a, v in zip(lhs, parts)))
        bad = list(parts)
        bad[0] = 1200.0
        violated = "%s为%s万元。%s。" % (
            rhs, _num(total), "，".join("%s%s万元" % (a, _num(v)) for a, v in zip(lhs, bad)))
        inject = {"object": rhs, "unit": "万元", "clean_value": parts[0], "violated_value": bad[0]}
    elif mode == "product_eq_total":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        rhs = (spec.get("rhs_anchor") or [""])
        rhs = str(rhs[0] if isinstance(rhs, list) else rhs)
        if len(lhs) < 2 or not rhs:
            return {}
        count, cap, total = 2, 25, 50
        clean = "%s%d台，%s%d兆瓦，%s%d兆瓦。" % (lhs[0], count, lhs[1], cap, rhs, total)
        violated = "%s%d台，%s%d兆瓦，%s%d兆瓦。" % (lhs[0], count, lhs[1], cap, rhs, 60)
        inject = {"object": rhs, "unit": "兆瓦", "clean_value": total, "violated_value": 60}
    elif mode == "count_eq_stated":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        rhs = (spec.get("rhs_anchor") or [""])
        rhs = str(rhs[0] if isinstance(rhs, list) else rhs)
        if len(lhs) < 1 or not rhs:
            return {}
        anchor = lhs[0]
        stated = 3
        clean = "%s。本项目%s%d个标段。" % (
            "、".join("%s%d" % (anchor, i + 1) for i in range(stated)), rhs, stated)
        violated = "%s。本项目%s%d个标段。" % (
            "、".join("%s%d" % (anchor, i + 1) for i in range(stated)), rhs, stated + 1)
        inject = {"object": rhs, "unit": "个", "clean_value": stated, "violated_value": stated + 1}
    elif mode == "lhs_le_rhs":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        rhs = (spec.get("rhs_anchor") or [""])
        rhs = str(rhs[0] if isinstance(rhs, list) else rhs)
        if len(lhs) < 1 or not rhs:
            return {}
        clean = "%s业绩金额500万元，%s1000万元。" % (lhs[0], rhs)
        violated = "%s业绩金额1500万元，%s1000万元。" % (lhs[0], rhs)
        inject = {"object": rhs, "unit": "万元", "clean_value": 500, "violated_value": 1500}
    elif mode == "sum_ratio_eq":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        if len(lhs) < 2:
            return {}
        a, b = lhs[0], lhs[1]
        clean = "%s60.0%%，%s40.0%%。" % (a, b)
        violated = "%s70.0%%，%s40.0%%。" % (a, b)
        inject = {"object": a, "unit": "%", "clean_value": 60.0, "violated_value": 70.0}
    elif mode == "range_overlap":
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        if len(lhs) < 2:
            return {}
        a, b = lhs[0], lhs[1]
        clean = "资质要求：1标段、5-10标段须具备%s资质；2-4标段须具备%s资质。" % (a, b)
        violated = "资质要求：1-5标段须具备%s资质；3-8标段须具备%s资质。" % (a, b)
        inject = {"object": "标段", "unit": "标段", "clean_value": "disjoint",
                  "violated_value": "overlap"}
    elif mode in ("date_le", "date_eq"):
        lhs = [str(x) for x in (spec.get("lhs_anchors") or []) if str(x).strip()]
        rhs = (spec.get("rhs_anchor") or [""])
        rhs = str(rhs[0] if isinstance(rhs, list) else rhs)
        if len(lhs) < 1 or not rhs:
            return {}
        if mode == "date_le":
            clean = "%s：2026-01-01；%s：2026-02-01。" % (lhs[0], rhs)
            violated = "%s：2026-03-01；%s：2026-02-01。" % (lhs[0], rhs)
            inject = {"object": rhs, "unit": "date", "clean_value": "2026-01-01",
                      "violated_value": "2026-03-01"}
        else:
            clean = "%s：2026-02-01；%s：2026-02-01。" % (lhs[0], rhs)
            violated = "%s：2026-02-03；%s：2026-02-01。" % (lhs[0], rhs)
            inject = {"object": rhs, "unit": "date", "clean_value": "2026-02-01",
                      "violated_value": "2026-02-03"}
    elif mode == "sum_check":
        clean = "合计金额100万元，其中：甲60万元，乙40万元。"
        violated = "合计金额100万元，其中：甲60万元，乙40万元，丙30万元。"
        inject = {"object": "合计金额", "unit": "万元", "clean_value": 100,
                  "violated_value": 130}
    elif mode == "require_present":
        req = str(slots.get("require") or "").strip()
        anchors = [str(x) for x in (slots.get("applicability") or []) if str(x).strip()]
        if not req or not anchors:
            return {}
        clean = "%s：%s。" % (anchors[0], req)
        violated = "%s：按先后顺序办理。" % anchors[0]
        inject = {"object": anchors[0], "unit": "text", "clean_value": req,
                  "violated_value": "缺失「%s」" % req}
    elif mode == "require_unchanged":
        allof = list(slots.get("all_of") or [])
        req = forbid = ""
        for c in allof:
            if isinstance(c, dict) and c.get("require"):
                req = str(c["require"])
            if isinstance(c, dict) and c.get("forbid"):
                forbid = str(c["forbid"])
        anchors = [str(x) for x in (slots.get("applicability") or []) if str(x).strip()]
        if not req or not forbid or not anchors:
            return {}
        clean = "%s：%s。" % (anchors[0], req)
        violated = "%s：%s。" % (anchors[0], forbid)
        inject = {"object": anchors[0], "unit": "text", "clean_value": req,
                  "violated_value": forbid}
    elif mode == "alter_detect":
        anchors = [str(x) for x in (spec.get("anchors") or []) if str(x).strip()]
        expected = [str(x) for x in (spec.get("expected") or []) if str(x).strip()]
        conflict = [str(x) for x in (spec.get("conflict_units") or []) if str(x).strip()]
        if not anchors or not expected or not conflict:
            return {}
        clean = "%s120%s。" % (anchors[0], expected[0])
        violated = "%s120%s。" % (anchors[0], conflict[0])
        inject = {"object": anchors[0], "unit": "unit", "clean_value": expected[0],
                  "violated_value": conflict[0]}
    elif mode == "cross_position":
        anchors = [str(x) for x in (spec.get("anchors") or []) if str(x).strip()]
        if not anchors:
            return {}
        a = anchors[0]
        clean = "本项目%s3个标段。补充说明：本项目%s3个标段。" % (a, a)
        violated = "本项目%s3个标段。补充说明：本项目%s4个标段。" % (a, a)
        inject = {"object": a, "unit": "个", "clean_value": 3, "violated_value": 4}
    if not clean or not violated:
        return {}
    return {"mode": mode, "clean": clean, "violated": violated, "inject": inject}


def _judge(slots: dict, text: str) -> dict:
    from app.engine import ruleexec
    return ruleexec.judge_rule(slots, text, facts=[])


def _prepare_item(item: dict, domain: str, declared: bool) -> dict:
    """构造与 manifest.freeze 同形的冻结 item 快照（只含只读快照字段）。"""
    slots = item.get("slots") or {}
    types = [str(x) for x in (slots.get("applicable_types") or ["md", "docx"])]
    aw = _scope_tokens(item)
    tags = ["招标采购"] if declared else []
    route_types = [t for t in types if t.lower().lstrip(".") in
                   ("md", "docx", "txt", "xlsx", "pdf", "doc", "csv", "json")]
    return {
        "code": item.get("code"),
        "rule_id": "probe-" + str(item.get("code")),
        "slots": slots,
        "applicable_when": aw,
        "scope_tags": tags,
        "applicable_types": route_types,
        "scope_meta": {
            "status": "explicit_types" if route_types else "missing",
            "route_types": route_types,
            "business_scope": [],
            "declared": bool(aw) or bool(tags),
        },
        "audit_route": {
            "object_haystack": "%s %s 采购 招标" % (domain, domain),
            "case_document_type": IN_SCOPE_CASE_DOC_TYPE,
            "case_audit_type": "招标",
            "scope_status": "explicit_types",
            "business_resolved": False,
        },
    }


def _decide(item: dict, case: dict, doc: dict, text: str) -> dict:
    """调用现有执行链纯函数：D1 适用性 → (applicable 时) D4 确定性判定。"""
    from app.services import manifest_exec
    d1 = manifest_exec._d1_from_frozen_route(item, case, doc)
    d1 = dict(d1)
    d1.update(manifest_exec._d1_scope_condition(item, d1, case, doc, text) or {})
    out = {"d1_status": d1.get("status"), "d1_reason": d1.get("reason") or "",
           "d1_routed_out": bool(d1.get("routed_out")),
           "d1_reason_chain": list(d1.get("reason_chain") or []),
           "d4_state": None, "d4_detail": "", "finding": False, "decided": False}
    if d1.get("status") != "applicable":
        return out
    jr = _judge(item.get("slots") or {}, text)
    state = str(jr.get("state") or "")
    out["d4_state"] = state
    out["d4_detail"] = str(jr.get("detail") or "")[:240]
    out["decided"] = state in ("满足", "不满足")
    out["finding"] = state == "不满足"
    return out


def _doc(scope: str, code: str, body: str, ext: str = ".md") -> dict:
    return {
        "id": "doc_" + str(code) + "_" + scope,
        "filename": "%s_%s%s" % (code, scope, ext),
        "doc_type": IN_SCOPE_CASE_DOC_TYPE if scope != "trap_ctx" else OUT_SCOPE_CASE_DOC_TYPE,
        "path": "",
    }


def _case(scope: str) -> dict:
    if scope == "trap_ctx":
        return {"document_type": OUT_SCOPE_CASE_DOC_TYPE, "audit_type": OUT_SCOPE_DOMAIN}
    return {"document_type": IN_SCOPE_CASE_DOC_TYPE, "audit_type": "招标"}


def _doc_text(scope_line: str, evidence: str) -> str:
    return scope_line + "\n\n" + evidence + "\n"


def build_triplets(*, declared: bool = False) -> list:
    """生成三联体（+ 两条 Trap 通道）。

    每条记录：
      code / family / mode / evidence_sha / triplet:
        clean / violated / trap_type / trap_ctx
    其中 violated 与 trap_type/trap_ctx 的证据块**字节相同**（断言见 probe）。
    """
    rules = json.loads(FIXTURE_RULES.read_text(encoding="utf-8"))["rules"]
    by_code = {r["rule_code"]: r for r in rules if r.get("layer") == "D1"}
    tierd = json.loads(FIXTURE_TIERD.read_text(encoding="utf-8"))["items"]
    items_by_code = {}
    for it in tierd:
        items_by_code.setdefault(str(it.get("code")), []).append(it)
    # 每条规则最多 2 条 item（不同 mode 优先），保证确定性排序
    out = []
    for code in sorted(by_code):
        r = by_code[code]
        cand = sorted(
            [it for it in items_by_code.get(code, [])
             if generate_evidence(it)],
            key=lambda it: (MODE_PRIORITY.get(_mode_of(it), 99), str(it.get("template")),))
        picked, seen_mode = [], set()
        for it in cand:
            gen = generate_evidence(it)
            mode = gen["mode"]
            if mode in seen_mode and len(picked) >= 1:
                continue
            # 自校验：clean 必须「满足」、violated 必须「不满足」才计入
            jc = _judge(it.get("slots") or {}, gen["clean"])
            jv = _judge(it.get("slots") or {}, gen["violated"])
            if str(jc.get("state")) != "满足" or str(jv.get("state")) != "不满足":
                continue
            picked.append((it, gen))
            seen_mode.add(mode)
            if len(picked) >= 2:
                break
        for it, gen in picked:
            # 冻结 item 的 audit_route 快照必须与被审对象上下文同源：in-scope 两条通道
            # （clean/violated/trap_type）用招标采购上下文，trap_ctx 用食品工艺上下文。
            item_in = _prepare_item(it, IN_SCOPE_DOMAIN, declared)
            item_trap = _prepare_item(it, OUT_SCOPE_DOMAIN, declared)
            evidence_sha = _sha(gen["violated"])
            clean_text = _doc_text(IN_SCOPE_SCOPE_LINE, gen["clean"])
            viol_text = _doc_text(IN_SCOPE_SCOPE_LINE, gen["violated"])
            trap_type_text = viol_text  # 只改文件类型：正文逐字相同
            trap_ctx_text = _doc_text(OUT_SCOPE_SCOPE_LINE, gen["violated"])
            tri = {}
            tri["clean"] = _decide(item_in, _case("clean"),
                                   _doc("clean", code, clean_text), clean_text)
            tri["violated"] = _decide(item_in, _case("violated"),
                                      _doc("violated", code, viol_text), viol_text)
            tri["trap_type"] = _decide(item_in, _case("trap_type"),
                                       _doc("trap_type", code, trap_type_text, ext=".txt"),
                                       trap_type_text)
            tri["trap_ctx"] = _decide(item_trap, _case("trap_ctx"),
                                      _doc("trap_ctx", code, trap_ctx_text),
                                      trap_ctx_text)
            out.append({
                "code": code,
                "family": str(code).split("-")[0],
                "point_name": str(r.get("name") or ""),
                "domain": str(r.get("domain") or ""),
                "mode": gen["mode"],
                "item_family": str(it.get("family") or ""),
                "template": str(it.get("template") or ""),
                "declared": bool(declared),
                "evidence_sha": evidence_sha,
                "clean_text": clean_text,
                "violated_text": viol_text,
                "trap_type_text": trap_type_text,
                "trap_ctx_text": trap_ctx_text,
                "inject": gen["inject"],
                "triplet": tri,
            })
    return out


def _sha(text: str) -> str:
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _cp95(k: int, n: int) -> list:
    """Clopper-Pearson 95% CI（与 scripts/qa 同口径的二分实现）。"""
    if n <= 0:
        return [0.0, 1.0]
    alpha = 0.05

    def _cdf(kk, nn, p):
        import math
        return sum(math.comb(nn, i) * (p ** i) * ((1 - p) ** (nn - i))
                   for i in range(0, kk + 1))

    if k == 0:
        lo = 0.0
    else:
        a, b = 0.0, 1.0
        for _ in range(120):
            mid = (a + b) / 2
            if 1 - _cdf(k - 1, n, mid) < alpha / 2:
                a = mid
            else:
                b = mid
        lo = (a + b) / 2
    if k == n:
        hi = 1.0
    else:
        a, b = 0.0, 1.0
        for _ in range(120):
            mid = (a + b) / 2
            if _cdf(k, n, mid) > alpha / 2:
                a = mid
            else:
                b = mid
        hi = (a + b) / 2
    return [round(lo, 4), round(hi, 4)]


def summarize(triplets: list) -> dict:
    """三联体指标：Clean FP / Violated 召回 / Trap 各通道的弃权与漏放。"""
    n = len(triplets)

    def _rate(items, pred):
        k = sum(1 for x in items if pred(x["triplet"]))
        return {"k": k, "n": len(items), "rate": round(k / len(items), 4) if items else None,
                "cp95": _cp95(k, len(items)) if items else None}

    clean_fp = _rate(triplets, lambda t: t["clean"]["finding"])
    viol_recall = _rate(triplets, lambda t: t["violated"]["finding"])
    viol_decided = _rate(triplets, lambda t: t["violated"]["decided"])
    def _abstain(t):
        """弃权 = D1 routed_out / 未适用，或 D4 明确不了（不适用/证据不足/执行失败）。"""
        if t["d1_status"] != "applicable":
            return True
        return not t["decided"]
    trap_type_abstain = _rate(triplets, lambda t: _abstain(t["trap_type"]))
    trap_ctx_abstain = _rate(triplets, lambda t: _abstain(t["trap_ctx"]))
    trap_type_leak = _rate(triplets, lambda t: t["trap_type"]["finding"])
    trap_ctx_leak = _rate(triplets, lambda t: t["trap_ctx"]["finding"])
    trap_type_silentpass = _rate(
        triplets, lambda t: t["trap_type"]["d1_status"] == "applicable"
        and t["trap_type"]["d4_state"] == "满足")
    trap_ctx_silentpass = _rate(
        triplets, lambda t: t["trap_ctx"]["d1_status"] == "applicable"
        and t["trap_ctx"]["d4_state"] == "满足")
    trap_docs = ([t["triplet"]["trap_type"] for t in triplets]
                 + [t["triplet"]["trap_ctx"] for t in triplets])
    trap_abstain = {"k": sum(1 for t in trap_docs if _abstain(t)), "n": len(trap_docs)}
    trap_abstain["rate"] = round(trap_abstain["k"] / trap_abstain["n"], 4) \
        if trap_abstain["n"] else None
    trap_abstain["cp95"] = _cp95(trap_abstain["k"], trap_abstain["n"]) \
        if trap_abstain["n"] else None
    trap_leak = {"k": sum(1 for t in trap_docs if t["finding"]), "n": len(trap_docs)}
    trap_leak["rate"] = round(trap_leak["k"] / trap_leak["n"], 4) if trap_leak["n"] else None
    trap_leak["cp95"] = _cp95(trap_leak["k"], trap_leak["n"]) if trap_leak["n"] else None
    clean_pass = _rate(triplets, lambda t: t["clean"]["d4_state"] == "满足")
    families = sorted({t["family"] for t in triplets})
    codes = sorted({t["code"] for t in triplets})
    modes = sorted({t["mode"] for t in triplets})
    # 检测通道上限：type 通道由 route_types 硬判（真实快照均有 applicable_types）；
    # ctx 通道只有 declared=True（补 scope_tags）才能被 _d1_scope_condition 判 na。
    return {
        "n_triplets": n,
        "n_rules": n,
        "n_families": len(families),
        "families": families,
        "n_codes": len(codes),
        "codes": codes,
        "n_modes": len(modes),
        "modes": modes,
        "clean_pass": clean_pass,
        "trap_abstain_overall": trap_abstain,
        "trap_leak_overall": trap_leak,
        "clean_fp": clean_fp,
        "violated_recall": viol_recall,
        "violated_decided": viol_decided,
        "trap_type_abstain": trap_type_abstain,
        "trap_ctx_abstain": trap_ctx_abstain,
        "trap_type_leak": trap_type_leak,
        "trap_ctx_leak": trap_ctx_leak,
        "trap_type_silent_pass": trap_type_silentpass,
        "trap_ctx_silent_pass": trap_ctx_silentpass,
        "delta_min_pp": round(2.80 * 0.5 / (max(n, 1) ** 0.5) * 100, 2),
    }


def run(declared: bool, structural: bool) -> dict:
    """跑一组三联体并汇总（切换 RULEPROOF_D1_STRUCTURAL 开关）。"""
    os.environ[STRUCTURAL_ENV] = "1" if structural else "0"
    triplets = build_triplets(declared=declared)
    summary = summarize(triplets)
    summary["declared"] = bool(declared)
    summary["structural"] = bool(structural)
    return {"summary": summary, "triplets": triplets}


def run_matrix() -> dict:
    """四臂矩阵：observed/declared × structural off/on。"""
    arms = {}
    for declared in (False, True):
        for structural in (False, True):
            key = "%s_structural%s" % ("declared" if declared else "observed",
                                       "on" if structural else "off")
            arms[key] = run(declared, structural)["summary"]
    return arms


if __name__ == "__main__":
    _matrix = run_matrix()
    print(json.dumps(_matrix, ensure_ascii=False, indent=1))
