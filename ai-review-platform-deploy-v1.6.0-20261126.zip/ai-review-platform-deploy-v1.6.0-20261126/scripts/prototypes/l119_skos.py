#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L119 · SKOS 只读导出原型（taxonomy / terms / ontology_v2 → SKOS 子集）。

定位（2026-11-25，L104 A9 / 用户 L119 任务书 1–2）：
  * JSON/DB 仍是唯一事实源；本模块只做**只读投影**，不写 app 表、不改默认行为；
  * 导出 SKOS 子集：`skos:ConceptScheme / Concept / prefLabel / altLabel / notation /
    broader / narrower / related / topConceptOf / hasTopConcept`，同时给出 JSON-LD 风格
    的 JSON 与 N-Triples 两种序列化（0 第三方库，供标准工具消费）；
  * 导出后由 `l119_shacl.py` 做 SHACL/Core 子集 + 自写语义校验（环/孤立/重复/空标签/
    租户隔离），本模块自带 N-Triples 回环解析，证明「导出 100% 可解析」。

事实源映射（file:line 以 HEAD 066b0e87 工作树为准）：
  * taxonomy   app/services/taxonomy.py:24 TAXONOMY_VERSION / :25 MAJORS / DEFAULT_TAXONOMY
               （majors → 顶层概念；子类 → narrower；category_map/rclass_map/keywords → altLabel）；
  * ontology_v2 app/services/ontology_v2.py:93 `_load(force=True)` 只读读取已发布 JSON 快照
               （STORE / seed / blind 择优），entities → 概念 + aliases → altLabel，
               relations `属于` → broader、其余 → related；类型/单位/scope 作为 rpx:* 属性；
  * terms      app/services/terms.py:690 `list_terms()`（**按 ctx 租户/空间作用域**）+
               business_term 行 → 每租户一个 scheme；只导出已生效状态（confirmed/active），
               同义词 → altLabel；`not_equal_json` 不导出为 SKOS 语义（仅统计，不伪造）。

边界（诚实）：
  * 不引入 rdflib/pyshacl/OWL DL/Neo4j；SHACL 校验是自写 Core 子集（见 l119_shacl.py）；
  * 不做 OWL 公理/推理；`属于` 之外的 relation 只作 skos:related；
  * ontology_v2 的 JSON 无租户字段 → 归入 `_global` scheme；租户隔离的多租户样本
    由 terms（DB 行）与 taxonomy（租户自定义）产生；
  * 导出不保证与未来 app 内发布器逐字节一致；`content_sha256` 只用于同输入复现。

CLI（库必须 /tmp；铁律 6）：
  python3 scripts/prototypes/l119_skos.py export --db /tmp/l119/db.sqlite \\
      --out /tmp/l119/skos_export.json --nt-out /tmp/l119/skos_export.nt
  python3 scripts/prototypes/l119_skos.py export --db /tmp/l119/db.sqlite --check
  python3 scripts/prototypes/l119_skos.py roundtrip --json /tmp/l119/skos_export.json \\
      --nt /tmp/l119/skos_export.nt
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", ".."))
SCHEMA = "l119_skos_export/v1"
SKOS = "http://www.w3.org/2004/02/skos/core#"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
RPX = "https://ruleproof.local/ns/rpx#"
BASE = "https://ruleproof.local/skos/v1"

#: 术语导出状态：只导出已生效（与 terms.EFFECTIVE_STATUSES 同口径，避免私有依赖）
EFFECTIVE_STATUSES = ("confirmed", "active")

_TMP_MARKERS = ("/tmp/", "/var/folders/", "/private/var/folders/", "/private/tmp/")


# ===========================================================================
# 铁律 6：app import 之前的库隔离安全门（本模块不在 import 时 import app，
# 只在调用时懒加载；届时必须已把 RULEPROOF_DB 指向 /tmp 临时库/副本）。
# ===========================================================================
def ensure_tmp_db(db_path: str = "") -> str:
    """把 RULEPROOF_DB 指向 /tmp；非临时库直接拒绝（只读也不放行）。"""
    if db_path:
        os.environ["RULEPROOF_DB"] = db_path
    raw = os.environ.get("RULEPROOF_DB") or ""
    if not raw:
        raw = os.path.join(tempfile.mkdtemp(prefix="l119_skos_"), "db.sqlite")
        os.environ["RULEPROOF_DB"] = raw
    resolved = os.path.abspath(raw)
    if not any(m in resolved + "/" for m in _TMP_MARKERS):
        raise SystemExit(
            "拒绝运行（铁律 6）：RULEPROOF_DB 必须指向 /tmp 临时库/副本，当前=%s" % resolved)
    return resolved


def _app():
    """懒加载 app 只读模块；调用前必须已通过 ensure_tmp_db。"""
    ensure_tmp_db()
    from app.services import ctx as _ctx          # noqa: F401
    from app.services import ontology_v2 as _onto  # noqa: F401
    from app.services import taxonomy as _tax      # noqa: F401
    from app.services import terms as _terms       # noqa: F401
    from app import db as _db                      # noqa: F401
    return {"ctx": _ctx, "ontology_v2": _onto, "taxonomy": _tax, "terms": _terms, "db": _db}


# ===========================================================================
# 纯函数工具
# ===========================================================================
def canonical_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _slug(text: str) -> str:
    """IRI 片段：保留可读中文，空格/斜杠等转义为下划线后再 percent 编码。"""
    from urllib.parse import quote
    s = re.sub(r"[\s/]+", "_", str(text or "").strip())
    return quote(s, safe="")


def _tenant_slug(tenant: str) -> str:
    return _slug(tenant or "_global")


def _scheme_iri(source: str, tenant: str, workspace: str = "") -> str:
    tail = "/" + _slug(workspace) if workspace else ""
    return "%s/scheme/%s/%s%s" % (BASE, source, _tenant_slug(tenant), tail)


def _concept_iri(source: str, tenant: str, key: str, workspace: str = "") -> str:
    wp = "~" + _slug(workspace) if workspace else ""
    return "%s/concept/%s/%s%s/%s" % (BASE, source, _tenant_slug(tenant), wp, _slug(key))


def _concept(source, tenant, workspace, scheme, pref, alts, notation="", broader=(),
             related=(), top=False, props=None, status="", version=""):
    cid = _concept_iri(source, tenant, pref, workspace)
    return {
        "id": cid,
        "type": "skos:Concept",
        "source": source,
        "tenant": tenant or "_global",
        "workspace": workspace or "",
        "scheme": scheme,
        "prefLabel": str(pref),
        "altLabel": [str(a) for a in alts if str(a).strip() and str(a) != str(pref)],
        "notation": str(notation or ""),
        "broader": sorted(set(broader)),
        "related": sorted(set(related)),
        "topConceptOf": [scheme] if top else [],
        "status": status,
        "props": dict(props or {}),
        "version": value_ver(version),
    }


def value_ver(v) -> str:
    return str(v if v is not None else "")


# ===========================================================================
# 导出：三源
# ===========================================================================
def export_taxonomy(modules, tenants):
    """taxonomy.py → 每租户一个 ConceptScheme（majors 顶层 + 子类 narrower）。"""
    T = modules["taxonomy"]
    schemes, concepts = [], []
    for tenant in tenants:
        tax = T.get_taxonomy(tenant) or {}
        majors = tax.get("majors") or {}
        scheme = _scheme_iri("taxonomy", tenant)
        top = []
        # 1) 大类 = 顶层概念
        major_iris = {}
        for major in T.MAJORS:
            if major not in majors:
                continue
            c = _concept("taxonomy", tenant, "", scheme, major, [],
                         notation="taxonomy:%s" % major,
                         top=True, props={"category": "major"},
                         version=tax.get("version") or "")
            major_iris[major] = c["id"]
            top.append(c["id"])
            concepts.append(c)
        # 2) altLabel 收集：category_map / rclass_map / keywords → 子类概念
        alt_map = {}
        for key, path in (tax.get("category_map") or {}).items():
            if isinstance(path, list) and len(path) == 2:
                alt_map.setdefault(tuple(path), []).append(str(key))
        for key, path in (tax.get("rclass_map") or {}).items():
            if isinstance(path, list) and len(path) == 2:
                alt_map.setdefault(tuple(path), []).append(str(key))
        for kw in tax.get("keywords") or []:
            path = tuple(kw.get("path") or [])
            for k in kw.get("keywords") or []:
                alt_map.setdefault(path, []).append(str(k))
        # 3) 子类 = narrower；缺 broader 的子类会被 SHACL 孤立规则抓出（不隐藏）
        for major, subs in majors.items():
            if major not in major_iris:
                continue
            for sub in subs:
                path = (major, sub)
                c = _concept("taxonomy", tenant, "", scheme, sub,
                             alt_map.get(path, []),
                             notation="taxonomy:%s/%s" % (major, sub),
                             broader=[major_iris[major]],
                             props={"category": "sub", "parent": major},
                             version=tax.get("version") or "")
                concepts.append(c)
        schemes.append({
            "id": scheme, "type": "skos:ConceptScheme", "source": "taxonomy",
            "tenant": tenant or "_global", "workspace": "",
            "prefLabel": "问题分类体系" + ("（%s）" % tenant if tenant else "（全局）"),
            "version": tax.get("version") or "",
            "topConcepts": top,
            "custom": bool(tax.get("custom")),
        })
    return schemes, concepts


def export_ontology(modules):
    """ontology_v2.py → 单个 `_global` scheme（JSON 无租户字段，如实标注）。"""
    O = modules["ontology_v2"]
    d = O._load(force=True) or {}  # 只读读取已发布 JSON 快照（维护/导出用，不受空间消费开关影响）
    ents = d.get("entities") or {}
    rels = d.get("relations") or []
    scheme = _scheme_iri("ontology_v2", "_global")
    # 概念 IRI 先建映射（关系端点必须导出为 IRI，不能留中文名）
    iri_map = {canon: _concept_iri("ontology_v2", "_global", canon) for canon in ents}
    # relations: 属于 → broader；其余 → related
    broader_map, related_map = {}, {}
    for r in rels:
        a, b, t = r.get("from"), r.get("to"), r.get("type")
        if not a or not b or a not in ents or b not in ents:
            continue
        if t == "属于":
            broader_map.setdefault(a, set()).add(iri_map[b])
        else:
            related_map.setdefault(a, set()).add(iri_map[b])
            related_map.setdefault(b, set()).add(iri_map[a])
    concepts, top = [], []
    for canon in ents:
        e = ents.get(canon) or {}
        aliases = [a for a in (e.get("aliases") or []) if a and a != canon]
        c = _concept("ontology_v2", "_global", "", scheme, canon, aliases,
                     notation="",  # 类型不是唯一 notation，放 rpx:entityType
                     broader=sorted(broader_map.get(canon) or []),
                     related=sorted(related_map.get(canon) or []),
                     top=True,  # 扁平概念集合（JSON 无完整上下位公理）；属于关系照实导出
                     props={"entityType": str(e.get("type") or ""),
                            "unit": str(e.get("unit") or ""),
                            "scope": list(e.get("scope") or [])},
                     version=d.get("version") or "")
        top.append(c["id"])
        concepts.append(c)
    schemes = [{
        "id": scheme, "type": "skos:ConceptScheme", "source": "ontology_v2",
        "tenant": "_global", "workspace": "",
        "prefLabel": "业务本体实体（ontology_v2 已发布快照）",
        "version": d.get("version") or "",
        "topConcepts": top, "custom": False,
    }]
    return schemes, concepts, bool(d)


def _discover_term_scopes(db_path: str):
    """从只读副本 DB 里发现 (tenant, workspace) 组合；不依赖 app 连接。"""
    import sqlite3
    out = set()
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=2.0)
        try:
            for t, w in con.execute(
                    "SELECT DISTINCT tenant_id, workspace_id FROM business_term "
                    "WHERE tenant_id IS NOT NULL AND tenant_id<>''"):
                out.add((str(t), str(w or "")))
        finally:
            con.close()
    except Exception:
        pass
    return sorted(out)


def export_terms(modules, scopes):
    """terms.py → 每 (租户, 空间) 一个 scheme；只导出已生效术语（同义词 altLabel）。"""
    terms = modules["terms"]
    ctx = modules["ctx"]
    schemes, concepts = [], []
    stats = {"terms_total": 0, "terms_exported": 0, "terms_skipped_status": 0,
             "not_equal_ignored": 0}
    for tenant, workspace in scopes:
        scheme = _scheme_iri("terms", tenant, workspace)
        rows = []
        try:
            with ctx.scoped(tenant, workspace):
                rows = terms.list_terms()
        except Exception:
            rows = []
        exported = []
        for t in rows:
            stats["terms_total"] += 1
            st = str(t.get("status") or "")
            if st not in EFFECTIVE_STATUSES:
                stats["terms_skipped_status"] += 1
                continue
            stats["not_equal_ignored"] += len(t.get("not_equal") or [])
            c = _concept("terms", tenant, workspace, scheme, t.get("name") or "",
                         t.get("synonyms") or [], notation=t.get("term_key") or "",
                         top=True, status=st,
                         props={"definition": t.get("definition") or "",
                                "entityType": t.get("entity_type") or "",
                                "unit": t.get("unit") or ""},
                         version=t.get("version") or "")
            exported.append(c)
            concepts.append(c)
        if not rows and not any(s["id"] == scheme for s in schemes):
            continue  # 无数据的租户不产出空 scheme（避免噪声），统计里如实 0
        schemes.append({
            "id": scheme, "type": "skos:ConceptScheme", "source": "terms",
            "tenant": tenant or "_global", "workspace": workspace or "",
            "prefLabel": "业务术语表（%s/%s）" % (tenant, workspace or "-"),
            "version": "business_term",
            "topConcepts": [c["id"] for c in exported],
            "custom": True,
        })
        stats["terms_exported"] += len(exported)
    return schemes, concepts, stats


def build_export(db_path: str, tenants=None, term_scopes=None) -> dict:
    """构造完整导出对象（纯内存；不写任何文件）。"""
    modules = _app()
    tenants = list(tenants or [])
    scopes = list(term_scopes or [])
    if not scopes:
        scopes = _discover_term_scopes(db_path)
    # 租户集合：显式租户 + 术语租户 + 全局
    ten_set = []
    for t in tenants + [s[0] for s in scopes]:
        if t and t not in ten_set:
            ten_set.append(t)
    if not ten_set:
        ten_set = ["t-default"]
    tax_schemes, tax_concepts = export_taxonomy(modules, ten_set)
    onto_schemes, onto_concepts, onto_ok = export_ontology(modules)
    term_schemes, term_concepts, term_stats = export_terms(modules, scopes)
    schemes = sorted(tax_schemes + onto_schemes + term_schemes, key=lambda x: x["id"])
    concepts = sorted(tax_concepts + onto_concepts + term_concepts, key=lambda x: x["id"])
    # 反向 narrower（由导出器一次算全，保证 broader/narrower 互逆；校验器仍会复核）
    by_id = {c["id"]: c for c in concepts}
    narrower = {c["id"]: set() for c in concepts}
    for c in concepts:
        for b in c["broader"]:
            if b in by_id:
                narrower[b].add(c["id"])
    for c in concepts:
        c["narrower"] = sorted(narrower[c["id"]])
    body = {
        "schema": SCHEMA,
        "generated_by": "l119_skos.py/v1",
        "source": {
            "taxonomy": "app/services/taxonomy.py",
            "terms": "app/services/terms.py + business_term(只读副本)",
            "ontology_v2": "app/services/ontology_v2.py::_load(force=True)",
            "json_is_source_of_truth": True,
            "ontology_snapshot_found": onto_ok,
        },
        "concept_schemes": schemes,
        "concepts": concepts,
        "statistics": {
            "schemes": len(schemes),
            "concepts": len(concepts),
            "alt_labels": sum(len(c["altLabel"]) for c in concepts),
            "broader_edges": sum(len(c["broader"]) for c in concepts),
            "related_edges": sum(len(c["related"]) for c in concepts) // 2,
            "tenants": sorted({s["tenant"] for s in schemes}),
            "concepts_by_source": {
                src: sum(1 for c in concepts if c["source"] == src)
                for src in ("taxonomy", "ontology_v2", "terms")},
            **term_stats,
        },
    }
    body["content_sha256"] = "sha256:" + sha256_text(canonical_json(body))
    return body


# ===========================================================================
# N-Triples 序列化 + 回环解析（自写，0 依赖）
# ===========================================================================
def _nt_escape(s: str) -> str:
    return (str(s).replace("\\", "\\\\").replace('"', '\\"')
            .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t"))


def _nt_unescape(s: str) -> str:
    out, i = [], 0
    while i < len(s):
        ch = s[i]
        if ch == "\\" and i + 1 < len(s):
            nxt = s[i + 1]
            out.append({"n": "\n", "r": "\r", "t": "\t", '"': '"', "\\": "\\"}.get(nxt, nxt))
            i += 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def _iri(rel: str) -> str:
    return "%s%s" % (BASE, rel) if rel.startswith("/") else rel


def to_nt(export: dict) -> str:
    """SKOS 子集 → N-Triples（行排序，确定性；供标准 RDF 工具消费）。"""
    lines = set()

    def add(s, p, o):
        lines.add("<%s> <%s> %s ." % (s, p, o))

    def lit(s, p, text):
        add(s, p, '"%s"@zh' % _nt_escape(text))

    def str_lit(s, p, text):
        add(s, p, '"%s"' % _nt_escape(text))

    for sc in export["concept_schemes"]:
        add(sc["id"], RDF + "type", "<%sConceptScheme>" % SKOS)
        lit(sc["id"], SKOS + "prefLabel", sc["prefLabel"])
        str_lit(sc["id"], RPX + "tenant", sc["tenant"])
        for tp in sc["topConcepts"]:
            add(sc["id"], SKOS + "hasTopConcept", "<%s>" % tp)
    for c in export["concepts"]:
        add(c["id"], RDF + "type", "<%sConcept>" % SKOS)
        add(c["id"], SKOS + "inScheme", "<%s>" % c["scheme"])
        lit(c["id"], SKOS + "prefLabel", c["prefLabel"])
        for a in c["altLabel"]:
            lit(c["id"], SKOS + "altLabel", a)
        if c["notation"]:
            str_lit(c["id"], SKOS + "notation", c["notation"])
        for b in c["broader"]:
            add(c["id"], SKOS + "broader", "<%s>" % b)
        for n in c["narrower"]:
            add(c["id"], SKOS + "narrower", "<%s>" % n)
        for r in c["related"]:
            add(c["id"], SKOS + "related", "<%s>" % r)
        for tp in c["topConceptOf"]:
            add(c["id"], SKOS + "topConceptOf", "<%s>" % tp)
        str_lit(c["id"], RPX + "tenant", c["tenant"])
        str_lit(c["id"], RPX + "source", c["source"])
        if c["status"]:
            str_lit(c["id"], RPX + "status", c["status"])
        p = c.get("props") or {}
        if p.get("unit"):
            str_lit(c["id"], RPX + "unit", p["unit"])
        if p.get("entityType"):
            str_lit(c["id"], RPX + "entityType", p["entityType"])
    return "\n".join(sorted(lines)) + "\n"


_NT_LINE = re.compile(r'^<([^>]+)> <([^>]+)> (.+) \.$')


def parse_nt(text: str) -> dict:
    """解析本模块产出的 N-Triples 子集；返回统计与图，任何不可解析行都计入 errors。"""
    triples, errors = [], []
    for no, line in enumerate(str(text or "").splitlines(), 1):
        if not line.strip():
            continue
        m = _NT_LINE.match(line)
        if not m:
            errors.append({"line": no, "text": line[:120], "reason": "syntax"})
            continue
        s, p, o = m.group(1), m.group(2), m.group(3)
        if o.startswith("<") and o.endswith(">"):
            obj = ("iri", o[1:-1])
        elif o.startswith('"'):
            q = re.match(r'^"((?:[^"\\]|\\.)*)"(?:@([A-Za-z-]+)|\^\^<([^>]+)>)?$', o)
            if not q:
                errors.append({"line": no, "text": line[:120], "reason": "literal"})
                continue
            obj = ("literal", _nt_unescape(q.group(1)))
            if q.group(2):
                obj = ("lang", _nt_unescape(q.group(1)), q.group(2))
            elif q.group(3):
                obj = ("typed", _nt_unescape(q.group(1)), q.group(3))
        else:
            errors.append({"line": no, "text": line[:120], "reason": "object"})
            continue
        triples.append((s, p, obj))
    concepts = {s for s, p, o in triples
                if p == RDF + "type" and o == ("iri", SKOS + "Concept")}
    schemes = {s for s, p, o in triples
               if p == RDF + "type" and o == ("iri", SKOS + "ConceptScheme")}
    pref = {}
    broader = set()
    related = set()
    for s, p, o in triples:
        if p == SKOS + "prefLabel" and o[0] == "lang":
            pref[s] = o[1]
        elif p == SKOS + "broader" and o[0] == "iri":
            broader.add((s, o[1]))
        elif p == SKOS + "related" and o[0] == "iri":
            related.add((s, o[1]))
    return {"triples": triples, "n_triples": len(triples), "errors": errors,
            "concepts": concepts, "schemes": schemes, "pref": pref,
            "broader": broader, "related": related}


def roundtrip(export: dict, nt_text: str) -> dict:
    """JSON 导出 ↔ N-Triples 回环一致性（概念集合/标签/边/三元组计数）。"""
    parsed = parse_nt(nt_text)
    exp_concepts = {c["id"] for c in export["concepts"]}
    exp_schemes = {s["id"] for s in export["concept_schemes"]}
    exp_broader = {(c["id"], b) for c in export["concepts"] for b in c["broader"]}
    exp_related = {(c["id"], r) for c in export["concepts"] for r in c["related"]}
    exp_pref = {c["id"]: c["prefLabel"] for c in export["concepts"]}
    problems = []
    if parsed["errors"]:
        problems.append("nt_parse_errors=%d" % len(parsed["errors"]))
    if parsed["concepts"] != exp_concepts:
        problems.append("concept_set_diff=%d" % len(parsed["concepts"] ^ exp_concepts))
    if parsed["schemes"] != exp_schemes:
        problems.append("scheme_set_diff=%d" % len(parsed["schemes"] ^ exp_schemes))
    if parsed["broader"] != exp_broader:
        problems.append("broader_diff=%d" % len(parsed["broader"] ^ exp_broader))
    if parsed["related"] != exp_related:
        problems.append("related_diff=%d" % len(parsed["related"] ^ exp_related))
    parsed_pref = {k: v for k, v in parsed["pref"].items() if k in exp_concepts}
    if parsed_pref != exp_pref:
        problems.append("prefLabel_diff=%d" % len(set(parsed_pref.items()) ^ set(exp_pref.items())))
    return {
        "ok": not problems,
        "problems": problems,
        "n_triples": parsed["n_triples"],
        "n_concepts": len(parsed["concepts"]),
        "n_schemes": len(parsed["schemes"]),
        "parse_rate": 1.0 if not parsed["errors"] else round(
            1.0 - len(parsed["errors"]) / max(1, parsed["n_triples"] + len(parsed["errors"])), 6),
    }


# ===========================================================================
# CLI
# ===========================================================================
def _write(path: str, text: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="L119 SKOS 只读导出原型")
    sub = ap.add_subparsers(dest="cmd", required=True)
    ex = sub.add_parser("export", help="从 taxonomy/terms/ontology_v2 只读导出 SKOS 子集")
    ex.add_argument("--db", default="", help="RULEPROOF_DB（必须是 /tmp 副本）")
    ex.add_argument("--out", default="", help="skos_export.json 输出路径（仅 /tmp 或 artifacts）")
    ex.add_argument("--nt-out", default="", help="skos_export.nt 输出路径")
    ex.add_argument("--tenants", default="", help="逗号分隔租户；缺省从 business_term 发现")
    ex.add_argument("--check", action="store_true", help="零写入自检：只输出摘要 JSON")
    rt = sub.add_parser("roundtrip", help="JSON ↔ N-Triples 回环解析校验")
    rt.add_argument("--json", required=True)
    rt.add_argument("--nt", required=True)
    args = ap.parse_args(argv)

    db = ensure_tmp_db(args.db if getattr(args, "db", "") else "")
    if args.cmd == "export":
        tenants = [t.strip() for t in (args.tenants or "").split(",") if t.strip()]
        export = build_export(db, tenants=tenants)
        nt = to_nt(export)
        manifest = {
            "ok": True,
            "schema": export["schema"],
            "db": db,
            "statistics": export["statistics"],
            "content_sha256": export["content_sha256"],
            "nt_sha256": "sha256:" + sha256_text(nt),
            "nt_roundtrip": roundtrip(export, nt),
            "wrote_files": 0,
        }
        if args.check:
            print(json.dumps(manifest, ensure_ascii=False, sort_keys=True))
            return 0 if manifest["nt_roundtrip"]["ok"] else 2
        out = args.out or os.path.join(tempfile.mkdtemp(prefix="l119_skos_out_"), "skos_export.json")
        if args.out:
            _write(args.out, json.dumps(export, ensure_ascii=False, indent=1, sort_keys=True) + "\n")
            manifest["wrote_files"] += 1
        nt_out = args.nt_out or (os.path.splitext(out)[0] + ".nt")
        if args.nt_out:
            _write(args.nt_out, nt)
            manifest["wrote_files"] += 1
        print(json.dumps(manifest, ensure_ascii=False, sort_keys=True))
        return 0 if manifest["nt_roundtrip"]["ok"] else 2
    if args.cmd == "roundtrip":
        export = json.loads(open(args.json, encoding="utf-8").read())
        nt = open(args.nt, encoding="utf-8").read()
        res = roundtrip(export, nt)
        print(json.dumps(res, ensure_ascii=False, sort_keys=True))
        return 0 if res["ok"] else 2
    return 2


if __name__ == "__main__":
    sys.exit(main())
