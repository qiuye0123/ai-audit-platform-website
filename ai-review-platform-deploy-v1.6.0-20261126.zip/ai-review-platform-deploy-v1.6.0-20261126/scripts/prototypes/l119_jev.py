#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L119 · JEV 最小 recompute 试点（payload 构造 + 独立重算 + 族级 blocking 评估）。

JEV = Judge-Evidence-Verify（平台内部术语，L104 §7 映射：J=manifest_exec/ruleexec，
E=evidence_gate+事实身份，V=certificate+report_gate+l95 灰度门）。本 lane 只做 V 的
最小 recompute 试点，**不写主链**：

1. `payloads`：从 L68 归档 `raw_after_r1.json`（20 份食品工艺书 × 12 规则 = 240 条
   fail finding）里挑出**数值/单位/区间/合计/一致性**类 finding，构造
   `recompute_payload`（operands + verifier ref）原型；
2. `recompute`：独立重算 CLI/函数。**不 import app.engine.certificate / ruleexec /
   manifest_exec / 任何 app 模块**（静态可查），实现自己的单位归一与 verifier；
3. `selftest`：8 条合成反向用例（篡改/未知单位/容差内/complete 一致性/未知 verifier…）
   证明「不一致必须被检出、不能静默 pass」；
4. `family`：用 L85 归档 447 条 finding（`l85_findings.csv` + `l85_summary.json`）
   按规则族重算覆盖/误伤，给出族级 allowlist 最小试点阈值与全局 blocking 禁令判定。

诚实边界（重要）：
* 生产 finding 无 executor `recompute` 载荷（L72：16/16 证书 evidence_only）；本试点
  的 operands 来自**归档执行器 detail/quote**（L68 artifact），因此统计的是
  「复算契约 + 独立算术」的一致率，不是抽取正确率；
* 一致性族（R09）归档 detail 只给两个相同取值、缺「共 N 处」其它位置 → payload 显式
  标 incomplete，独立重算给 insufficient（不算一致、不伪装通过），差异原因如实统计；
* 区间包含（R02）现有 app 9 类 verifier 无原生支持，原型用 `range_containment`；
  上界单边规则（R11）按执行器 B1 端点语义取上限，用 app 兼容的 numeric_limit；
* 合计（R10）执行器容差是**绝对值**（0.01 克），app weight_sum 只有相对百分比容差，
  payload 同时给 tolerance_abs/tolerance_pct，原型按绝对值复算并标注该差异。
* 族级 blocking 结论只用于「能否试点」，不改变 app 默认（REQUIRED 仍 0）。

CLI（全部 0-LLM、只读归档；写文件只落 /tmp 或 docs artifacts）：
  python3 scripts/prototypes/l119_jev.py payloads   --out-json /tmp/l119/recompute_payloads.json
  python3 scripts/prototypes/l119_jev.py recompute  --payloads /tmp/l119/recompute_payloads.json \\
      --out-csv /tmp/l119/recompute_results.csv --summary /tmp/l119/recompute_summary.json
  python3 scripts/prototypes/l119_jev.py selftest   --summary /tmp/l119/recompute_selftest.json
  python3 scripts/prototypes/l119_jev.py family     --out-csv /tmp/l119/family_metrics.csv \\
      --summary /tmp/l119/family_metrics.json
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", ".."))
DEFAULT_RAW = os.path.join(REPO, "docs", "qa", "artifacts", "l68_food_process_eval_20261124",
                           "raw_after_r1.json")
DEFAULT_FINDINGS = os.path.join(REPO, "docs", "qa", "artifacts",
                                "l85_certificate_blocking_dryrun_20261124", "l85_findings.csv")
DEFAULT_L85_SUMMARY = os.path.join(REPO, "docs", "qa", "artifacts",
                                   "l85_certificate_blocking_dryrun_20261124", "l85_summary.json")

PAYLOAD_SCHEMA = "l119_recompute_payload/v1"
RESULT_SCHEMA = "l119_recompute_result/v1"
FAMILY_SCHEMA = "l119_family_blocking/v1"
VERIFIER_REF = "l119-proto/1"

#: 选入试点的 L68 规则 → finding 类型（数值/单位/区间/合计/一致性）
TARGET_RULES = ("R01", "R02", "R03", "R04a", "R04b", "R05", "R09", "R10", "R11")
RULE_FAMILY = {
    "R01": "numeric_unit", "R02": "numeric_unit_range", "R03": "numeric_unit",
    "R04a": "numeric_unit", "R04b": "numeric_unit", "R05": "numeric_unit",
    "R09": "consistency", "R10": "weight_sum", "R11": "numeric_unit_range",
}

#: 独立单位表（不 import app）：unit → (dimension, base_unit, factor_to_base)
UNITS = {
    "min": ("time", "min", 1.0), "分钟": ("time", "min", 1.0), "分": ("time", "min", 1.0),
    "h": ("time", "min", 60.0), "小时": ("time", "min", 60.0),
    "s": ("time", "min", 1.0 / 60.0), "秒": ("time", "min", 1.0 / 60.0),
    "g": ("mass", "g", 1.0), "克": ("mass", "g", 1.0),
    "kg": ("mass", "g", 1000.0), "千克": ("mass", "g", 1000.0),
    "mg": ("mass", "g", 0.001), "毫克": ("mass", "g", 0.001),
    "℃": ("temperature", "℃", 1.0), "摄氏度": ("temperature", "℃", 1.0),
    "ppm": ("concentration", "ppm", 1.0), "mg/kg": ("concentration", "ppm", 1.0),
}


def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def canonical_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


# ===========================================================================
# 统计工具（Wilson / Clopper-Pearson 单侧上界；与 AGENTS §13 口径一致）
# ===========================================================================
def wilson_ci(k: int, n: int, z: float = 1.96) -> list:
    if n <= 0:
        return [0.0, 1.0]
    p = k / n
    den = 1 + z * z / n
    center = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(max(0.0, p * (1 - p) / n + z * z / (4 * n * n))) / den
    return [round(max(0.0, center - half), 4), round(min(1.0, center + half), 4)]


def cp_upper_zero(n: int, alpha: float = 0.05) -> float:
    """k=0 时的 Clopper-Pearson 单侧 95% 上界 = 1 - alpha^(1/n)。"""
    if n <= 0:
        return 1.0
    return round(1.0 - alpha ** (1.0 / n), 4)


def delta_min(n: int, sd: float = 0.5) -> float:
    """δ_min = 2.80 × σ / √n（AGENTS §13 设计分辨率，pp 口径返回百分数）。"""
    if n <= 0:
        return 100.0
    return round(2.80 * sd / math.sqrt(n) * 100, 2)


# ===========================================================================
# 单位/数值解析（独立实现）
# ===========================================================================
_NUM = r"[-+]?\d+(?:\.\d+)?"


def parse_unit(text: str) -> str:
    s = str(text or "").strip()
    for unit in sorted(UNITS, key=len, reverse=True):
        if s.endswith(unit) or s == unit:
            return unit
    return s


def to_base(value, unit):
    """返回 (base_value, base_unit) 或 (None, reason)。"""
    meta = UNITS.get(str(unit or "").strip())
    if not meta:
        return None
    return float(value) * meta[2], meta[1]


def _dim(unit):
    meta = UNITS.get(str(unit or "").strip())
    return meta[0] if meta else ""


# ===========================================================================
# 1) payload 构造：L68 归档 → recompute_payload
# ===========================================================================
_RE_THRESHOLD = re.compile(
    r"^(?P<label>.+?)\s(?P<actual>%s)(?P<aunit>[^\s]+)\s+不满足\s+(?P<op>[<>=!]+)\s+"
    r"(?P<limit>%s)(?P<lunit>\S+)$" % (_NUM, _NUM))
_RE_RANGE_BOTH = re.compile(
    r"^(?P<label>.+?)\s(?P<lo>%s)-(?P<hi>%s)(?P<unit>[^\s（]+)（下限/上限双端点）\s+不满足\s+"
    r"(?P<elo>%s)-(?P<ehi>%s)(?P<eunit>\S+)$" % (_NUM, _NUM, _NUM, _NUM))
_RE_RANGE_UPPER = re.compile(
    r"^(?P<label>.+?)\s(?P<lo>%s)-(?P<hi>%s)(?P<unit>[^\s（]+)（下限/上限双端点）\s+不满足\s+"
    r"(?P<op>[<>=]+)\s+(?P<limit>%s)(?P<lunit>\S+)$" % (_NUM, _NUM, _NUM))
_RE_SUM = re.compile(
    r"合计项「(?P<label>.+?)」=(?P<decl>%s)(?P<dunit>\S+?)；分项\s*(?P<n>\d+)\s*项合计="
    r"(?P<sum>%s)(?P<sunit>\S+?)（(?P<parts>.+?)）；要求合计等于合计项；与合计相差\s*"
    r"(?P<diff>%s)(?P<diffunit>\S+?)（容差\s*(?P<tol>%s)(?P<tolunit>\S+?)）"
    % (_NUM, _NUM, _NUM, _NUM))
_RE_CONSISTENCY = re.compile(
    r"同一字段「(?P<field>.+?)」跨位置取值不一致：(?P<a>.+?)\s+与\s+(?P<b>.+?)"
    r"（共\s*(?P<n>\d+)\s*处）")


def _payload(rule, doc_id, detail, quote, char_start, char_end, kind, operands,
             verifier_ref=VERIFIER_REF, app_compatible=True, notes=None):
    body = {
        "schema": PAYLOAD_SCHEMA,
        "test_set": "L68_food_process_audit_20",
        "case": doc_id,
        "rule_code": rule,
        "rule_family": RULE_FAMILY.get(rule, "other"),
        "claimed_state": "fail",
        "verifier": {"kind": kind, "ref": verifier_ref, "version": verifier_ref,
                     "app_compatible": bool(app_compatible),
                     "deterministic": True, "model_calls": 0},
        "operands": operands,
        "source": {"artifact": "docs/qa/artifacts/l68_food_process_eval_20261124/raw_after_r1.json",
                   "detail": detail, "quote": quote or "",
                   "char_start": char_start, "char_end": char_end},
        "notes": list(notes or []),
    }
    body["payload_id"] = "l119-p-" + _sha(canonical_json(body))[:16]
    return body


def payload_from_finding(rule: str, doc_id: str, f: dict) -> dict:
    """把一条归档 finding 转成 payload；解析失败明确抛 ValueError（不猜）。"""
    detail = str(f.get("detail") or "")
    quote = str(f.get("quote") or "")
    cs, ce = f.get("char_start"), f.get("char_end")
    if rule == "R01" or rule in ("R03", "R04a", "R04b", "R05"):
        m = _RE_THRESHOLD.match(detail)
        if not m:
            raise ValueError("threshold_detail_unparsed: %r" % detail)
        return _payload(rule, doc_id, detail, quote, cs, ce, "numeric_limit", {
            "op": m.group("op"),
            "limit": {"value": float(m.group("limit")), "unit": m.group("lunit")},
            "items": [{"label": m.group("label"), "value": float(m.group("actual")),
                       "unit": m.group("aunit"), "quote": quote,
                       "locator": f.get("sheet") or ""}],
        }, notes=["operands 从归档 detail/quote 反解（非 executor 原生载荷）"])
    if rule == "R02":
        m = _RE_RANGE_BOTH.match(detail)
        if not m:
            raise ValueError("range_detail_unparsed: %r" % detail)
        return _payload(rule, doc_id, detail, quote, cs, ce, "range_containment", {
            "actual": {"lo": float(m.group("lo")), "hi": float(m.group("hi")),
                       "unit": m.group("unit"), "quote": quote},
            "expected": {"lo": float(m.group("elo")), "hi": float(m.group("ehi")),
                         "unit": m.group("eunit")},
            "requires_all_bounds": True,
        }, app_compatible=False,
            notes=["app 9 类 verifier 无区间包含语义；原型新增 range_containment，"
                   "接入需扩展 numeric_limit 或执行器展开双端点"])
    if rule == "R11":
        m = _RE_RANGE_UPPER.match(detail)
        if not m:
            raise ValueError("range_upper_detail_unparsed: %r" % detail)
        return _payload(rule, doc_id, detail, quote, cs, ce, "numeric_limit", {
            "op": m.group("op"),
            "limit": {"value": float(m.group("limit")), "unit": m.group("lunit")},
            "items": [{"label": m.group("label"), "value": float(m.group("hi")),
                       "unit": m.group("unit"), "quote": quote,
                       "range": {"lo": float(m.group("lo")), "hi": float(m.group("hi"))},
                       "endpoint": "upper",
                       "locator": f.get("sheet") or ""}],
        }, notes=["B1 区间端点语义：规则只约束上界 → 取区间上限 8℃ 比较；"
                  "payload 保留 range 供审计"])
    if rule == "R10":
        m = _RE_SUM.match(detail)
        if not m:
            raise ValueError("sum_detail_unparsed: %r" % detail)
        parts = []
        for item in m.group("parts").split("、"):
            if "=" not in item:
                raise ValueError("sum_part_unparsed: %r" % item)
            name, val = item.rsplit("=", 1)
            parts.append({"label": name.strip(), "value": float(val),
                          "unit": m.group("sunit"), "quote": quote})
        return _payload(rule, doc_id, detail, quote, cs, ce, "weight_sum", {
            "parts": parts,
            "declared": {"value": float(m.group("decl")), "unit": m.group("dunit")},
            "tolerance_abs": float(m.group("tol")),
            "tolerance_abs_unit": m.group("tolunit"),
            "tolerance_pct": None,
        }, notes=["执行器容差=绝对值 0.01 克；app weight_sum 仅支持相对百分比 → "
                  "原型用 tolerance_abs 复算并记录该契约差异"])
    if rule == "R09":
        m = _RE_CONSISTENCY.match(detail)
        if not m:
            raise ValueError("consistency_detail_unparsed: %r" % detail)
        a, b, n = m.group("a").strip(), m.group("b").strip(), int(m.group("n"))
        values = [{"label": "归档位置A", "value": a, "quote": quote},
                  {"label": "归档位置B", "value": b, "quote": quote}]
        return _payload(rule, doc_id, detail, quote, cs, ce, "consistency", {
            "values": values,
            "expected_locations": n,
            "provided_locations": len(values),
            "archive_anomaly": ("values_identical_in_detail" if a == b else ""),
        }, notes=["归档 detail 只回放 2 个取值（且相同）、未带「共 %d 处」其余位置 → "
                  "payload 标 incomplete，重算如实 insufficient（P2a 需执行器导出全量位置）" % n])
    raise ValueError("unsupported_rule: %r" % rule)


def build_payloads(raw_path: str = "") -> dict:
    raw_path = raw_path or DEFAULT_RAW
    raw = json.loads(open(raw_path, encoding="utf-8").read())
    payloads, skipped = [], []
    for case in raw.get("audit_violated") or []:
        doc_id = str(case.get("doc_id") or "")
        for f in case.get("findings") or []:
            rule = str(f.get("rule_id") or "")
            if rule not in TARGET_RULES:
                skipped.append({"case": doc_id, "rule": rule, "reason": "not_target_family"})
                continue
            try:
                payloads.append(payload_from_finding(rule, doc_id, f))
            except ValueError as exc:
                skipped.append({"case": doc_id, "rule": rule, "reason": str(exc)})
    payloads.sort(key=lambda p: (p["rule_code"], p["case"], p["payload_id"]))
    by_rule, by_kind, by_family = {}, {}, {}
    for p in payloads:
        by_rule[p["rule_code"]] = by_rule.get(p["rule_code"], 0) + 1
        by_kind[p["verifier"]["kind"]] = by_kind.get(p["verifier"]["kind"], 0) + 1
        by_family[p["rule_family"]] = by_family.get(p["rule_family"], 0) + 1
    package = {
        "schema": PAYLOAD_SCHEMA,
        "generated_by": "l119_jev.py/v1",
        "source_artifact": os.path.relpath(raw_path, REPO),
        "source_sha256": "sha256:" + _sha(open(raw_path, "rb").read().decode("utf-8", "replace")),
        "statistics": {
            "n_payloads": len(payloads), "n_skipped": len(skipped),
            "by_rule": by_rule, "by_kind": by_kind, "by_family": by_family,
            "app_compatible": sum(1 for p in payloads if p["verifier"]["app_compatible"]),
            "prototype_kind_only": sum(1 for p in payloads if not p["verifier"]["app_compatible"]),
            "claimed_fail": sum(1 for p in payloads if p["claimed_state"] == "fail"),
        },
        "payloads": payloads,
        "skipped": skipped,
    }
    package["content_sha256"] = "sha256:" + _sha(canonical_json(
        {k: package[k] for k in ("payloads", "skipped", "statistics")}))
    return package


# ===========================================================================
# 2) 独立重算（不 import app）
# ===========================================================================
def _recompute_numeric_limit(operands: dict) -> dict:
    op = str(operands.get("op") or "")
    limit = operands.get("limit") or {}
    items = operands.get("items") or []
    lv, lu = limit.get("value"), limit.get("unit")
    ln = to_base(lv, lu) if lv is not None and lu else None
    if ln is None:
        return {"verdict": "insufficient", "reason": "limit_unit_unknown", "rows": []}
    rows, violations, missing = [], 0, 0
    for it in items:
        v, u = it.get("value"), it.get("unit")
        norm = to_base(v, u) if v is not None and u else None
        if norm is None:
            missing += 1
            rows.append({"label": it.get("label"), "verdict": "insufficient",
                         "reason": "unit_unknown:%r" % (u,)})
            continue
        if norm[1] != ln[1]:
            missing += 1
            rows.append({"label": it.get("label"), "verdict": "insufficient",
                         "reason": "dimension_mismatch:%s!=%s" % (norm[1], ln[1])})
            continue
        a, b = norm[0], ln[0]
        ok = {">=": a >= b, ">": a > b, "<=": a <= b, "<": a < b, "==": a == b,
              "=": a == b, "!=": a != b}.get(op)
        if ok is None:
            return {"verdict": "insufficient", "reason": "unknown_op:%r" % op, "rows": rows}
        rows.append({"label": it.get("label"), "value": v, "unit": u,
                     "base": [a, norm[1]], "limit_base": b,
                     "violated": (not ok), "verdict": "violated" if not ok else "satisfied"})
        if not ok:
            violations += 1
    recompute = {"kind": "numeric_limit", "op": op,
                 "limit_base": [ln[0], ln[1]], "rows": rows,
                 "violations": violations, "missing": missing,
                 "formula": "to_base(actual) <op> to_base(limit) => violated"}
    if missing or not items:
        return {"verdict": "insufficient", "reason": "units_or_items_unknown",
                "recompute": recompute}
    if violations:
        return {"verdict": "claim_holds", "recompute": recompute}
    return {"verdict": "claim_contradicted", "recompute": recompute}


def _recompute_range_containment(operands: dict) -> dict:
    a = operands.get("actual") or {}
    e = operands.get("expected") or {}
    if a.get("unit") != e.get("unit"):
        return {"verdict": "insufficient", "reason": "unit_mismatch",
                "recompute": {"kind": "range_containment"}}
    lo_a, hi_a, lo_e, hi_e = a.get("lo"), a.get("hi"), e.get("lo"), e.get("hi")
    if None in (lo_a, hi_a, lo_e, hi_e):
        return {"verdict": "insufficient", "reason": "bounds_missing",
                "recompute": {"kind": "range_containment"}}
    try:
        lo_a, hi_a = float(lo_a), float(hi_a)
        lo_e, hi_e = float(lo_e), float(hi_e)
    except (TypeError, ValueError):
        return {"verdict": "insufficient", "reason": "bounds_not_numeric",
                "recompute": {"kind": "range_containment"}}
    under, over = lo_a < lo_e, hi_a > hi_e
    recompute = {"kind": "range_containment", "actual": [lo_a, hi_a], "expected": [lo_e, hi_e],
                 "underflow": under, "overflow": over,
                 "formula": "actual ⊆ expected <=> lo_a>=lo_e and hi_a<=hi_e"}
    if under or over:
        return {"verdict": "claim_holds", "recompute": recompute}
    return {"verdict": "claim_contradicted", "recompute": recompute}


def _recompute_weight_sum(operands: dict) -> dict:
    parts, total, base_unit = [], 0.0, ""
    for p in operands.get("parts") or []:
        v, u = p.get("value"), p.get("unit")
        norm = to_base(v, u) if v is not None and u else None
        if norm is None:
            return {"verdict": "insufficient", "reason": "part_unit_unknown:%r" % (u,)}
        total += norm[0]
        base_unit = norm[1]
        parts.append({"label": p.get("label"), "value": v, "unit": u, "base": norm[0]})
    declared = operands.get("declared") or {}
    dn = to_base(declared.get("value"), declared.get("unit")) if declared.get("unit") else None
    if dn is None or not parts:
        return {"verdict": "insufficient", "reason": "declared_or_parts_missing"}
    tol_abs = operands.get("tolerance_abs")
    tol_pct = operands.get("tolerance_pct")
    diff = abs(total - dn[0])
    abs_limit = float(tol_abs) if tol_abs is not None else None
    pct_limit = (float(tol_pct) / 100.0) * max(abs(dn[0]), 1e-12) if tol_pct is not None else None
    if abs_limit is not None and abs_limit > 0:
        violate = diff > abs_limit
        used = {"tolerance_abs": abs_limit, "diff": diff}
    elif pct_limit is not None:
        violate = diff > pct_limit
        used = {"tolerance_pct": tol_pct, "diff": diff}
    else:
        violate = diff > 0
        used = {"tolerance": 0, "diff": diff}
    recompute = {"kind": "weight_sum", "parts": parts, "parts_sum_base": total,
                 "base_unit": base_unit, "declared_base": [dn[0], dn[1]],
                 "base_diff": diff, **used,
                 "formula": "abs(sum(parts)-declared) > tolerance"}
    if violate:
        return {"verdict": "claim_holds", "recompute": recompute}
    return {"verdict": "claim_contradicted", "recompute": recompute}


def _recompute_consistency(operands: dict) -> dict:
    values = list(operands.get("values") or [])
    expected = operands.get("expected_locations")
    normed = {}
    rows = []
    for v in values:
        raw = v.get("value") if v.get("value") is not None else v.get("quote")
        n = "".join(str(raw or "").split()).casefold()
        rows.append({"label": v.get("label"), "value": raw, "normalized": n})
        if n:
            normed.setdefault(n, []).append(v.get("label"))
    recompute = {"kind": "consistency", "distinct": len(normed), "n_values": len(rows),
                 "groups": [{"value": k, "count": len(vs)} for k, vs in normed.items()],
                 "rows": rows, "expected_locations": expected,
                 "provided_locations": len(values),
                 "formula": "complete && distinct>1 => inconsistent; !complete => insufficient"}
    if expected is not None and len(values) < int(expected):
        return {"verdict": "insufficient", "reason": "coverage_incomplete",
                "recompute": recompute}
    if len(normed) >= 2:
        return {"verdict": "claim_holds", "recompute": recompute}
    if len(normed) == 1 and len(rows) >= 2:
        return {"verdict": "claim_contradicted", "recompute": recompute}
    return {"verdict": "insufficient", "reason": "insufficient_values",
            "recompute": recompute}


_VERIFIERS = {
    "numeric_limit": _recompute_numeric_limit,
    "range_containment": _recompute_range_containment,
    "weight_sum": _recompute_weight_sum,
    "consistency": _recompute_consistency,
}


def recompute(payload: dict) -> dict:
    """独立重算一条 payload；未知 verifier/异常 → insufficient（fail-closed）。"""
    verifier = payload.get("verifier") or {}
    kind = str(verifier.get("kind") or "")
    claimed = str(payload.get("claimed_state") or "fail")
    fn = _VERIFIERS.get(kind)
    base = {"payload_id": payload.get("payload_id"), "case": payload.get("case"),
            "rule_code": payload.get("rule_code"), "rule_family": payload.get("rule_family"),
            "kind": kind, "verifier_ref": verifier.get("ref") or "",
            "claimed_state": claimed}
    if fn is None:
        out = {"verdict": "insufficient", "reason": "unknown_verifier:%r" % kind}
    else:
        try:
            out = fn(payload.get("operands") or {})
        except Exception as exc:  # noqa: BLE001 - 任何异常都不许静默 pass
            out = {"verdict": "insufficient", "reason": "verifier_error:%s" % type(exc).__name__}
    verdict = out.get("verdict")
    if claimed == "fail":
        agree = verdict == "claim_holds"
        diff = None if agree else ("claim_not_confirmed" if verdict == "claim_contradicted"
                                   else "recompute_insufficient")
    else:
        agree = verdict == "claim_holds"
        diff = None if agree else "claim_state_not_fail"
    base.update({
        "verdict": verdict,
        "reason": out.get("reason") or "",
        "agree": bool(agree),
        "difference_reason": diff,
        "recompute": out.get("recompute") or ({"kind": kind, "reason": out.get("reason")}),
    })
    return base


def recompute_all(package: dict) -> list:
    return [recompute(p) for p in (package.get("payloads") or [])]


def summarize_results(results: list, label: str = "L68_food_process_audit_20") -> dict:
    n = len(results)
    by_verdict = {}
    by_kind, by_rule = {}, {}
    reasons = {}
    for r in results:
        by_verdict[r["verdict"]] = by_verdict.get(r["verdict"], 0) + 1
        by_kind.setdefault(r["kind"], {}).setdefault(r["verdict"], 0)
        by_kind[r["kind"]][r["verdict"]] += 1
        by_rule.setdefault(r["rule_code"], {}).setdefault(r["verdict"], 0)
        by_rule[r["rule_code"]][r["verdict"]] += 1
        if r.get("difference_reason"):
            reasons[r["difference_reason"]] = reasons.get(r["difference_reason"], 0) + 1
    holds = by_verdict.get("claim_holds", 0)
    contradicted = by_verdict.get("claim_contradicted", 0)
    insufficient = by_verdict.get("insufficient", 0)
    recomputable = holds + contradicted
    agreement = round(holds / recomputable, 6) if recomputable else None
    coverage = round(recomputable / n, 6) if n else None
    summary = {
        "schema": RESULT_SCHEMA,
        "generated_by": "l119_jev.py/v1",
        "label": label,
        "n": n,
        "by_verdict": by_verdict,
        "recomputable": recomputable,
        "claim_holds": holds,
        "claim_contradicted": contradicted,
        "insufficient": insufficient,
        "agreement_rate_recomputable": agreement,
        "agreement_ci_wilson": wilson_ci(holds, recomputable) if recomputable else None,
        "agreement_ci_wilson_note": "Wilson 95%CI; 分母=可判定 finding 数（不含 insufficient）",
        "recompute_coverage": coverage,
        "coverage_ci_wilson": wilson_ci(recomputable, n) if n else None,
        "contradicted_zero_cp_upper": cp_upper_zero(recomputable) if contradicted == 0 else None,
        "delta_min_pp": delta_min(recomputable),
        "n_note": "n=%d（R01/R02/R03/R04a/R04b/R05/R09/R10/R11 数值/单位/区间/合计/一致性类 fail）" % n,
        "difference_reasons": reasons,
        "by_kind": by_kind,
        "by_rule": by_rule,
        "honesty": [
            "operands 从归档执行器 detail/quote 反解，非 executor 原生 recompute 载荷（P2a 未做）",
            "insufficient 单独统计，不并入一致率分母；不写『零差异』，只写可判定子集一致率",
            "一致性族 R09 归档缺全量位置 → coverage_incomplete，属载荷契约缺口而非复算失败",
        ],
    }
    return summary


# ===========================================================================
# 3) selftest：反向/边界用例（期望 verdict 明确，assert 由测试执行）
# ===========================================================================
def build_selftest() -> list:
    def p(payload_id, kind, operands, claimed="fail"):
        return {"payload_id": payload_id, "case": "selftest", "rule_code": "SELFTEST",
                "rule_family": "selftest", "claimed_state": claimed,
                "verifier": {"kind": kind, "ref": VERIFIER_REF},
                "operands": operands}

    cases = [
        ("SE01_numeric_violated", p("SE01", "numeric_limit", {
            "op": "<=", "limit": {"value": 20, "unit": "kg"},
            "items": [{"label": "单锅投料量", "value": 25, "unit": "kg"}]}), "claim_holds"),
        ("SE02_numeric_tampered_satisfied", p("SE02", "numeric_limit", {
            "op": "<=", "limit": {"value": 20, "unit": "kg"},
            "items": [{"label": "单锅投料量", "value": 12, "unit": "kg"}]}), "claim_contradicted"),
        ("SE03_unknown_unit_count", p("SE03", "numeric_limit", {
            "op": "<=", "limit": {"value": 20, "unit": "kg"},
            "items": [{"label": "单锅投料量", "value": 25, "unit": "个"}]}), "insufficient"),
        ("SE04_dimension_mismatch", p("SE04", "numeric_limit", {
            "op": "<=", "limit": {"value": 20, "unit": "kg"},
            "items": [{"label": "单锅投料量", "value": 25, "unit": "min"}]}), "insufficient"),
        ("SE05_range_overflow", p("SE05", "range_containment", {
            "actual": {"lo": 0, "hi": 7, "unit": "℃"},
            "expected": {"lo": 0, "hi": 5, "unit": "℃"}}), "claim_holds"),
        ("SE06_range_satisfied", p("SE06", "range_containment", {
            "actual": {"lo": 0, "hi": 3, "unit": "℃"},
            "expected": {"lo": 0, "hi": 5, "unit": "℃"}}), "claim_contradicted"),
        ("SE07_weight_tolerance_ok", p("SE07", "weight_sum", {
            "parts": [{"label": "a", "value": 190, "unit": "克"},
                      {"label": "b", "value": 170, "unit": "克"}],
            "declared": {"value": 360, "unit": "克"},
            "tolerance_abs": 0.01, "tolerance_abs_unit": "克"}), "claim_contradicted"),
        ("SE08_weight_diff", p("SE08", "weight_sum", {
            "parts": [{"label": "a", "value": 190, "unit": "克"},
                      {"label": "b", "value": 170, "unit": "克"}],
            "declared": {"value": 335, "unit": "克"},
            "tolerance_abs": 0.01, "tolerance_abs_unit": "克"}), "claim_holds"),
        ("SE09_consistency_incomplete", p("SE09", "consistency", {
            "values": [{"label": "A", "value": "V1.0"}, {"label": "B", "value": "V1.0"}],
            "expected_locations": 7, "provided_locations": 2}), "insufficient"),
        ("SE10_consistency_complete_distinct", p("SE10", "consistency", {
            "values": [{"label": "A", "value": "V1.0"}, {"label": "B", "value": "V0.8"}],
            "expected_locations": 2, "provided_locations": 2}), "claim_holds"),
        ("SE11_consistency_complete_equal", p("SE11", "consistency", {
            "values": [{"label": "A", "value": "V1.0"}, {"label": "B", "value": "V1.0"}],
            "expected_locations": 2, "provided_locations": 2}), "claim_contradicted"),
        ("SE12_unknown_verifier", p("SE12", "does_not_exist", {}), "insufficient"),
        ("SE13_unknown_op", p("SE13", "numeric_limit", {
            "op": "≈", "limit": {"value": 1, "unit": "kg"},
            "items": [{"label": "x", "value": 1, "unit": "kg"}]}), "insufficient"),
        ("SE14_claimed_pass_but_fail", p("SE14", "numeric_limit", {
            "op": ">=", "limit": {"value": 85, "unit": "℃"},
            "items": [{"label": "中心温度", "value": 77, "unit": "℃"}]}, claimed="pass"),
         "claim_holds"),
    ]
    out = []
    for cid, payload, expect in cases:
        r = recompute(payload)
        out.append({"case": cid, "expected_verdict": expect, "actual_verdict": r["verdict"],
                    "pass": r["verdict"] == expect, "reason": r.get("reason") or "",
                    "difference_reason": r.get("difference_reason")})
    return out


# ===========================================================================
# 4) 族级 blocking 评估（L85 归档）
# ===========================================================================
def _read_csv(path):
    with open(path, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def family_evaluate(findings_path: str = "", summary_path: str = "",
                    recompute_rules: dict | None = None) -> dict:
    findings_path = findings_path or DEFAULT_FINDINGS
    summary_path = summary_path or DEFAULT_L85_SUMMARY
    rows = _read_csv(findings_path)
    l85 = json.loads(open(summary_path, encoding="utf-8").read())
    fam = l85.get("family_allowlist_measured") or {}
    rule_to_family, fam_meta = {}, {}
    for fam_key, meta in fam.items():
        for rule in meta.get("rules") or []:
            rule_to_family[rule] = fam_key
        fam_meta[fam_key] = {"rules": list(meta.get("rules") or []),
                             "l85_n": meta.get("n"),
                             "l85_coverage_rate": meta.get("coverage_rate"),
                             "l85_injury_rate": meta.get("injury_rate")}
    # S1_L71 证书族不在 family_allowlist_measured 里（L85 单列于 gray_gate_measured），
    # 按 set 补一个族；规则码仍逐条保留，避免「未映射」被静默丢掉。
    s1_rules = sorted({r["rule_code"] for r in rows if r.get("set") == "S1_L71"})
    if s1_rules:
        s1_key = "S1_L71:food_process_v1"
        for rule in s1_rules:
            rule_to_family.setdefault(rule, s1_key)
        fam_meta[s1_key] = {"rules": s1_rules, "l85_n": sum(
            1 for r in rows if r.get("set") == "S1_L71"),
            "l85_coverage_rate": None, "l85_injury_rate": None}
    unmapped = sorted({r["rule_code"] for r in rows if r["rule_code"] not in rule_to_family})
    # 逐族重算（用 CSV 原始行，不抄 summary）
    metrics = []
    for fam_key in sorted(fam_meta):
        sub = [r for r in rows if rule_to_family.get(r["rule_code"]) == fam_key]
        true_rows = [r for r in sub if str(r.get("true")) == "True"]
        pass_rows = [r for r in true_rows if r.get("cert_status") == "pass"]
        blocked = [r for r in true_rows if str(r.get("blocked_by_cert")) == "1"]
        marginal = [r for r in true_rows if str(r.get("new_block_vs_evidence")) == "1"]
        n_true, k = len(true_rows), len(blocked)
        cov = round(len(pass_rows) / n_true, 6) if n_true else None
        inj = round(k / n_true, 6) if n_true else None
        metrics.append({
            "family": fam_key, "rules": fam_meta[fam_key]["rules"],
            "n_rows": len(sub), "n_true": n_true, "n_false": len(sub) - n_true,
            "coverage_rate": cov, "injury_rate": inj,
            "injury_k": k, "injury_ci_wilson": wilson_ci(k, n_true),
            "injury_cp_upper95": cp_upper_zero(n_true) if k == 0 else None,
            "marginal_new_block_k": len(marginal),
            "marginal_new_block_rate": round(len(marginal) / n_true, 6) if n_true else None,
            "no_cert_k": sum(1 for r in true_rows if r.get("cert_status") == "missing"),
            "insufficient_k": sum(1 for r in true_rows if r.get("cert_status") == "insufficient"),
            "l85_coverage_rate": fam_meta[fam_key]["l85_coverage_rate"],
            "l85_injury_rate": fam_meta[fam_key]["l85_injury_rate"],
        })
    # 全局口径
    true_all = [r for r in rows if str(r.get("true")) == "True"]
    blocked_all = [r for r in true_all if str(r.get("blocked_by_cert")) == "1"]
    marginal_all = [r for r in true_all if str(r.get("new_block_vs_evidence")) == "1"]
    s2 = [r for r in true_all if r.get("set") == "S2_L68"]
    s2_blocked = [r for r in s2 if str(r.get("blocked_by_cert")) == "1"]
    g_inj = round(len(blocked_all) / len(true_all), 6) if true_all else None
    g_marg = round(len(marginal_all) / len(true_all), 6) if true_all else None
    s2_inj = round(len(s2_blocked) / len(s2), 6) if s2 else None
    global_blocking = {
        "n_findings_csv": len(rows),
        "n_true": len(true_all), "n_false": len(rows) - len(true_all),
        "blocked_k": len(blocked_all),
        "injury_rate": g_inj,
        "injury_ci_wilson": wilson_ci(len(blocked_all), len(true_all)),
        "marginal_new_block_k": len(marginal_all),
        "marginal_new_block_rate": g_marg,
        "s2_l68_injury_rate": s2_inj,
        "s2_l68_injury_ci_wilson": wilson_ci(len(s2_blocked), len(s2)),
        "verdict": "GLOBAL_BLOCKING_FORBIDDEN",
        "reason": "L85 预演：全局 REQUIRED=1 误伤率 %s（全部真 finding n=%d）；"
                  "S2 L68 上 %.2f%%（n=%d）；边际新增 %s；"
                  "G1 误伤≤2%% 与 G2 覆盖率≥95%% 均不达标 → 只能族级 allowlist"
                  % (("%.2f%%" % (g_inj * 100)) if g_inj is not None else "n/a",
                     len(true_all), (s2_inj * 100) if s2_inj is not None else 0.0, len(s2),
                     ("%.2f%%" % (g_marg * 100)) if g_marg is not None else "n/a"),
    }
    # 族级 allowlist 最小试点阈值
    thresholds = {
        "pilot_entry": {
            "coverage_min": 0.95,
            "injury_k": 0,
            "n_true_min": 100,
            "injury_cp_upper95_max": cp_upper_zero(100),
            "desc": "可进族级 blocking 最小试点（单族）：覆盖率≥95%、误伤 k=0、n_true≥100、"
                    "单侧 CP95 上界≤2.95%（0/100；AGENTS §13 clean-control 双侧口径为 3.62%）；"
                    "必须先回填证书（missing=0）",
        },
        "production_expand": {
            "coverage_min": 0.95,
            "injury_k": 0,
            "n_true_min": 149,
            "injury_cp_upper95_max": cp_upper_zero(149),
            "desc": "扩到生产：n_true≥149 使 0 误伤的 CP95 上界≤2%（≈1.99%）",
        },
        "recompute_required": {
            "agreement_recomputable_min": 0.99,
            "contradicted_max": 0,
            "desc": "族内 recompute 一致率≥99% 且 contradicted=0（P-JEV-2 stop rule）",
        },
    }
    # 判定
    for m in metrics:
        verdicts = []
        if m["n_true"] and m["coverage_rate"] is not None and m["coverage_rate"] >= 0.95 \
                and m["injury_k"] == 0 and m["n_true"] >= 100:
            verdicts.append("PILOT_ENTRY_OK")
        else:
            verdicts.append("HOLD")
        if m["n_true"] and m["injury_k"] == 0 and m["n_true"] >= 149:
            verdicts.append("PRODUCTION_EXPAND_OK")
        if m["family"].endswith("missing_clause") or m["family"].endswith("sum_check"):
            verdicts.append("NO_RECOMPUTE_PAYLOAD_HOLD")
        m["verdicts"] = verdicts
        m["eligible_min_pilot"] = "PILOT_ENTRY_OK" in verdicts
    allowed = [m["family"] for m in metrics if m["eligible_min_pilot"]
               and "NO_RECOMPUTE_PAYLOAD_HOLD" not in m["verdicts"]]
    family_rules = [r for m in metrics if m["family"] in allowed for r in m["rules"]]
    # 规则级 recompute 资格：n>0、claim_holds 全中、contradicted=0、verifier app 兼容
    rec_ok_rules, rec_hold_rules = [], []
    if recompute_rules:
        for rule in family_rules:
            info = recompute_rules.get(rule) or {}
            n_rule = int(info.get("n") or 0)
            if n_rule > 0 and info.get("claim_holds") == n_rule and int(info.get("contradicted") or 0) == 0 \
                    and bool(info.get("app_compatible", True)):
                rec_ok_rules.append(rule)
            else:
                rec_hold_rules.append({
                    "rule": rule, "n": n_rule,
                    "claim_holds": int(info.get("claim_holds") or 0),
                    "contradicted": int(info.get("contradicted") or 0),
                    "insufficient": int(info.get("insufficient") or 0),
                    "app_compatible": bool(info.get("app_compatible", True)),
                    "reason": info.get("reason") or (
                        "app_compatible=False（原型独有 verifier）"
                        if not info.get("app_compatible", True)
                        else "recompute_not_100pct（claim_holds=%d/%d, contradicted=%d, "
                             "insufficient=%d）" % (
                                 int(info.get("claim_holds") or 0), n_rule,
                                 int(info.get("contradicted") or 0),
                                 int(info.get("insufficient") or 0))),
                })
    else:
        rec_ok_rules = list(family_rules)
    phase1_rules = rec_ok_rules
    pilot = {
        "allowlist_families_phase1": allowed,
        "allowlist_rules_family_level": family_rules,
        "allowlist_rules_phase1": phase1_rules,
        "rules_held_from_phase1": rec_hold_rules,
        "phase1_n_findings": sum(1 for r in rows
                                 if r["rule_code"] in phase1_rules and str(r.get("true")) == "True"),
        "recompute_rule_level_checked": bool(recompute_rules),
        "min_pilot": {
            "kernel": 1, "required": 1, "tenant_scope": "t-default",
            "allowed_families": allowed,
            "allowed_rules": phase1_rules,
            "start_condition": "先回填证书且 coverage().stats.missing==0；REQUIRED=0 运行期回退保留；"
                               "仅对 allowlist 规则生效（需 app 内族级 gate，当前只有全局开关）",
            "stop_rule": "任一指标不达标 → REQUIRED=0 回退 + 族级 gate 退回设计",
        },
        "pilot_metrics_measured": {
            "numeric_family_n_true": sum(m["n_true"] for m in metrics
                                        if m["family"] in allowed),
            "numeric_family_injury_k": sum(m["injury_k"] for m in metrics
                                          if m["family"] in allowed),
            "numeric_family_coverage": min((m["coverage_rate"] for m in metrics
                                            if m["family"] in allowed), default=None),
        },
    }
    unmapped_info = {"unmapped_rules": unmapped,
                     "unmapped_rows": sum(1 for r in rows if r["rule_code"] in unmapped),
                     "partition_ok": not unmapped}
    return {
        "schema": FAMILY_SCHEMA,
        "generated_by": "l119_jev.py/v1",
        "source": {"findings_csv": os.path.relpath(findings_path, REPO),
                   "findings_sha256": "sha256:" + _sha(open(findings_path, encoding="utf-8").read()),
                   "l85_summary": os.path.relpath(summary_path, REPO)},
        "n_rows": len(rows),
        "families": metrics,
        "global_blocking": global_blocking,
        "thresholds": thresholds,
        "pilot": pilot,
        "unmapped": unmapped_info,
        "honesty": [
            "误伤=真 finding 被证书门禁拦下（blocked_by_cert）；边际=扣除既有 L4 证据门禁后的新增",
            "0 误伤不写『零误伤』：给 k/N + CP95 单侧上界；n<149 只能算试点样本",
            "全局 blocking 禁止结论只基于 L85 归档回放，非生产运行",
        ],
    }


# ===========================================================================
# CLI
# ===========================================================================
def _write(path, text):
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def _write_payload_csv(path, payloads):
    cols = ["payload_id", "case", "rule_code", "rule_family", "claimed_state",
            "verifier_kind", "verifier_ref", "app_compatible", "quote", "detail"]
    buf = []
    for p in payloads:
        buf.append({
            "payload_id": p["payload_id"], "case": p["case"], "rule_code": p["rule_code"],
            "rule_family": p["rule_family"], "claimed_state": p["claimed_state"],
            "verifier_kind": p["verifier"]["kind"], "verifier_ref": p["verifier"]["ref"],
            "app_compatible": int(bool(p["verifier"]["app_compatible"])),
            "quote": p["source"]["quote"], "detail": p["source"]["detail"],
        })
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(buf)


def _write_result_csv(path, results):
    cols = ["payload_id", "case", "rule_code", "rule_family", "kind", "claimed_state",
            "verdict", "agree", "difference_reason", "reason"]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in results:
            w.writerow({k: r.get(k) for k in cols})


def _write_family_csv(path, families):
    cols = ["family", "rules", "n_rows", "n_true", "n_false", "coverage_rate", "injury_rate",
            "injury_k", "injury_ci_wilson", "injury_cp_upper95", "marginal_new_block_k",
            "marginal_new_block_rate", "insufficient_k", "verdicts"]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for m in families:
            row = dict(m)
            row["rules"] = "|".join(m["rules"])
            row["injury_ci_wilson"] = json.dumps(m["injury_ci_wilson"])
            row["verdicts"] = "|".join(m["verdicts"])
            w.writerow({k: row.get(k) for k in cols})


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="L119 JEV 最小 recompute 试点 / 族级 blocking 评估")
    sub = ap.add_subparsers(dest="cmd", required=True)
    pa = sub.add_parser("payloads")
    pa.add_argument("--raw", default="")
    pa.add_argument("--out-json", default="")
    pa.add_argument("--out-csv", default="")
    rc = sub.add_parser("recompute")
    rc.add_argument("--payloads", default="")
    rc.add_argument("--out-csv", default="")
    rc.add_argument("--summary", default="")
    rc.add_argument("--fail-on-contradiction", action="store_true",
                    help="存在 contradicted/insufficient 时退出码 1（默认只报告）")
    st = sub.add_parser("selftest")
    st.add_argument("--summary", default="")
    fa = sub.add_parser("family")
    fa.add_argument("--findings", default="")
    fa.add_argument("--l85-summary", default="")
    fa.add_argument("--out-csv", default="")
    fa.add_argument("--summary", default="")
    args = ap.parse_args(argv)

    if args.cmd == "payloads":
        package = build_payloads(args.raw)
        text = json.dumps(package, ensure_ascii=False, indent=1, sort_keys=True) + "\n"
        if args.out_json:
            _write(args.out_json, text)
        if args.out_csv:
            _write_payload_csv(args.out_csv, package["payloads"])
        print(json.dumps({"ok": True, "statistics": package["statistics"],
                          "content_sha256": package["content_sha256"],
                          "out_json": args.out_json or "(stdout-only)",
                          "out_csv": args.out_csv}, ensure_ascii=False, sort_keys=True))
        return 0
    if args.cmd == "recompute":
        if args.payloads:
            package = json.loads(open(args.payloads, encoding="utf-8").read())
        else:
            package = build_payloads()
        results = recompute_all(package)
        summary = summarize_results(results)
        if args.out_csv:
            _write_result_csv(args.out_csv, results)
        if args.summary:
            _write(args.summary, json.dumps(summary, ensure_ascii=False, indent=1,
                                            sort_keys=True) + "\n")
        print(json.dumps({"ok": True, "n": summary["n"],
                          "recomputable": summary["recomputable"],
                          "claim_holds": summary["claim_holds"],
                          "claim_contradicted": summary["claim_contradicted"],
                          "insufficient": summary["insufficient"],
                          "agreement_rate_recomputable": summary["agreement_rate_recomputable"],
                          "difference_reasons": summary["difference_reasons"],
                          "summary": args.summary},
                         ensure_ascii=False, sort_keys=True))
        if args.fail_on_contradiction and summary["claim_contradicted"]:
            return 1
        return 0
    if args.cmd == "selftest":
        cases = build_selftest()
        failed = [c for c in cases if not c["pass"]]
        summary = {"n": len(cases), "passed": len(cases) - len(failed),
                   "failed": failed, "cases": cases}
        if args.summary:
            _write(args.summary, json.dumps(summary, ensure_ascii=False, indent=1,
                                            sort_keys=True) + "\n")
        print(json.dumps({"ok": not failed, "n": len(cases),
                          "passed": len(cases) - len(failed),
                          "failed": [c["case"] for c in failed]}, ensure_ascii=False))
        return 0 if not failed else 1
    if args.cmd == "family":
        res = family_evaluate(args.findings, args.l85_summary)
        if args.out_csv:
            _write_family_csv(args.out_csv, res["families"])
        if args.summary:
            _write(args.summary, json.dumps(res, ensure_ascii=False, indent=1,
                                            sort_keys=True) + "\n")
        print(json.dumps({"ok": True, "n_rows": res["n_rows"],
                          "partition_ok": res["unmapped"]["partition_ok"],
                          "global_verdict": res["global_blocking"]["verdict"],
                          "pilot_allowlist_families": res["pilot"]["allowlist_families_phase1"],
                          "families": [{"family": m["family"], "n_true": m["n_true"],
                                        "coverage": m["coverage_rate"],
                                        "injury": m["injury_rate"],
                                        "verdicts": m["verdicts"]}
                                       for m in res["families"]]},
                         ensure_ascii=False, sort_keys=True))
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
