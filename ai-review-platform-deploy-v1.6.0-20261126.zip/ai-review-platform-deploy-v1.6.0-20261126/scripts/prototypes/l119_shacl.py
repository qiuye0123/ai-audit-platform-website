#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L119 · SKOS 导出物的 SHACL/Core 子集校验（自写，0 第三方库）。

背景（任务书 1–2；L104 A9）：
  平台已有 taxonomy/terms/ontology_v2 的 JSON/DB 事实源，缺标准序列化与一致性门禁。
  本模块给 `l119_skos.py` 的导出物做**离线**校验：不连网、不 import app、不写业务库；
  SHACL 形状以 JSON 声明（Core 子集：target_class / path / min_count / max_count /
  node_kind / class / datatype / no_empty / unique_lang），另加 SHACL 难以表达的
  图语义规则（用自写代码实现并在结果中逐条列出）：

    SHACL 结构形状
      - Concept：prefLabel 恰 1；altLabel 非空/去重/≤16；inScheme 恰 1（且指向已知 scheme）；
      - Concept：broader/narrower/related 目标必须是已声明 Concept；
      - Scheme：prefLabel 恰 1；tenant 恰 1；hasTopConcept 目标必须是 Concept。
    自写语义规则（错误=阻断、警告=不阻断）
      - R-CYCLE       broader 图环 = 0（DFS 三色）
      - R-ORPHAN      concept 未挂任何已声明 scheme = 0
      - R-ISOLATED    非 topConcept 且无 broader/related/narrower 的漂浮概念 = 0
      - R-DUP-PREF    同一 scheme 内 prefLabel 重复（NFKC+casefold）= 0
      - R-DUP-ALT     同一 scheme 内 altLabel 跨概念重复 = 0
      - R-DUP-NOTATION同一 scheme 内 notation 重复 = 0
      - R-EMPTY       空标签（prefLabel/altLabel 空白）= 0
      - R-INVERSE     broader ↔ narrower 不互逆 = 0
      - R-TENANT-01   concept.tenant ≠ scheme.tenant = 0
      - R-TENANT-02   跨租户边（broader/narrower/related 端点租户不同）= 0
      - R-TENANT-03   concept IRI 全局重复 = 0
      - R-TOP         topConceptOf ↔ scheme.hasTopConcept 不一致 = 0
      - W-ALT-PREF    altLabel 与本 scheme 其他 concept 的 prefLabel 相同 = 警告
      - W-NO-ALT      无 altLabel 概念数 = 警告

CLI：
  python3 scripts/prototypes/l119_shacl.py shapes --out /tmp/l119/l119_shacl_shapes.json
  python3 scripts/prototypes/l119_shacl.py validate --export /tmp/l119/skos_export.json \\
      --shapes /tmp/l119/l119_shacl_shapes.json --out /tmp/l119/shacl_result.json
  退出码：conforms=0；存在 violations=1；输入/解析错误=2。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import unicodedata
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
SCHEMA_SHAPES = "l119_shacl_shapes/v1"
SCHEMA_RESULT = "l119_shacl_result/v1"
SKOS = "http://www.w3.org/2004/02/skos/core#"
RPX = "https://ruleproof.local/ns/rpx#"

#: SHACL 形状（JSON 声明；validator 真实按声明执行，不是摆设）
SHAPES = {
    "schema": SCHEMA_SHAPES,
    "generated_by": "l119_shacl.py/v1",
    "note": "SHACL Core subset 的 JSON 声明；由 l119_shacl.validate_export 解释执行。",
    "node_shapes": [
        {
            "id": "ConceptShape",
            "target_class": "skos:Concept",
            "properties": [
                {"path": "skos:prefLabel", "name": "prefLabel_exactly_one",
                 "min_count": 1, "max_count": 1, "node_kind": "literal", "no_empty": True},
                {"path": "skos:altLabel", "name": "altLabel_bounded_unique",
                 "min_count": 0, "max_count": 16, "node_kind": "literal",
                 "no_empty": True, "unique_lang": True},
                {"path": "skos:inScheme", "name": "inScheme_exactly_one",
                 "min_count": 1, "max_count": 1, "node_kind": "iri",
                 "class": "skos:ConceptScheme"},
                {"path": "skos:broader", "name": "broader_is_concept",
                 "min_count": 0, "node_kind": "iri", "class": "skos:Concept"},
                {"path": "skos:narrower", "name": "narrower_is_concept",
                 "min_count": 0, "node_kind": "iri", "class": "skos:Concept"},
                {"path": "skos:related", "name": "related_is_concept",
                 "min_count": 0, "node_kind": "iri", "class": "skos:Concept"},
                {"path": "rpx:tenant", "name": "tenant_exactly_one",
                 "min_count": 1, "max_count": 1, "node_kind": "literal", "no_empty": True},
            ],
        },
        {
            "id": "ConceptSchemeShape",
            "target_class": "skos:ConceptScheme",
            "properties": [
                {"path": "skos:prefLabel", "name": "scheme_prefLabel_exactly_one",
                 "min_count": 1, "max_count": 1, "node_kind": "literal", "no_empty": True},
                {"path": "rpx:tenant", "name": "scheme_tenant_exactly_one",
                 "min_count": 1, "max_count": 1, "node_kind": "literal", "no_empty": True},
                {"path": "skos:hasTopConcept", "name": "top_concepts_are_concepts",
                 "min_count": 0, "node_kind": "iri", "class": "skos:Concept"},
            ],
        },
    ],
    "semantic_rules": [
        {"id": "R-CYCLE", "severity": "violation", "desc": "skos:broader 有向图环=0"},
        {"id": "R-ORPHAN", "severity": "violation", "desc": "concept 必须挂在已声明 scheme"},
        {"id": "R-ISOLATED", "severity": "violation", "desc": "非 top 且无边概念=孤立"},
        {"id": "R-DUP-PREF", "severity": "violation", "desc": "scheme 内 prefLabel 重复=0"},
        {"id": "R-DUP-ALT", "severity": "violation", "desc": "scheme 内 altLabel 跨概念重复=0"},
        {"id": "R-DUP-NOTATION", "severity": "violation", "desc": "scheme 内 notation 重复=0"},
        {"id": "R-EMPTY", "severity": "violation", "desc": "空标签=0"},
        {"id": "R-INVERSE", "severity": "violation", "desc": "broader↔narrower 必须互逆"},
        {"id": "R-TENANT-01", "severity": "violation", "desc": "concept.tenant == scheme.tenant"},
        {"id": "R-TENANT-02", "severity": "violation", "desc": "边不得跨租户"},
        {"id": "R-TENANT-03", "severity": "violation", "desc": "concept IRI 全局唯一"},
        {"id": "R-TOP", "severity": "violation", "desc": "topConceptOf 与 scheme.hasTopConcept 一致"},
        {"id": "W-ALT-PREF", "severity": "warning", "desc": "altLabel 不得等于同 scheme 他概念 prefLabel"},
        {"id": "W-NO-ALT", "severity": "warning", "desc": "无 altLabel 的概念数（术语召回提示）"},
    ],
}


# ===========================================================================
# 工具
# ===========================================================================
def _norm(text) -> str:
    s = unicodedata.normalize("NFKC", str(text or ""))
    return "".join(s.split()).casefold()


def _as_list(v):
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return list(v)
    return [v]


def _paths(export):
    """把导出 JSON 的字段映射成 SHACL path → 值列表。"""
    schemes = export.get("concept_schemes") or []
    concepts = export.get("concepts") or []
    scheme_ids = {s.get("id") for s in schemes}
    concept_ids = {c.get("id") for c in concepts}
    for s in schemes:
        yield "ConceptScheme", s, {
            "skos:prefLabel": [s.get("prefLabel")],
            "rpx:tenant": [s.get("tenant")],
            "skos:hasTopConcept": _as_list(s.get("topConcepts")),
            "skos:inScheme": [],
        }
    for c in concepts:
        yield "Concept", c, {
            "skos:prefLabel": _as_list(c.get("prefLabel")),
            "skos:altLabel": _as_list(c.get("altLabel")),
            "skos:inScheme": _as_list(c.get("scheme")),
            "skos:broader": _as_list(c.get("broader")),
            "skos:narrower": _as_list(c.get("narrower")),
            "skos:related": _as_list(c.get("related")),
            "skos:topConceptOf": _as_list(c.get("topConceptOf")),
            "rpx:tenant": _as_list(c.get("tenant")),
        }
    export["_known"] = {"schemes": scheme_ids, "concepts": concept_ids}


def _check_property(shape_name, prop, node, values):
    """执行一条 property shape；返回 violation dict 列表。"""
    name = prop.get("name") or prop.get("path")
    path = prop.get("path")
    vals = [v for v in values if v is not None]
    out = []
    min_c = prop.get("min_count")
    max_c = prop.get("max_count")
    if min_c is not None and len(vals) < int(min_c):
        out.append({"shape": shape_name, "property": path, "rule": "min_count",
                    "node": node.get("id"), "detail": "%d < %d" % (len(vals), int(min_c))})
    if max_c is not None and len(vals) > int(max_c):
        out.append({"shape": shape_name, "property": path, "rule": "max_count",
                    "node": node.get("id"), "detail": "%d > %d" % (len(vals), int(max_c))})
    node_kind = prop.get("node_kind")
    for v in vals:
        if node_kind == "literal" and not isinstance(v, str):
            out.append({"shape": shape_name, "property": path, "rule": "node_kind",
                        "node": node.get("id"), "detail": "expected literal got %r" % (v,)})
        if node_kind == "iri" and not (isinstance(v, str) and v.startswith("http")):
            out.append({"shape": shape_name, "property": path, "rule": "node_kind",
                        "node": node.get("id"), "detail": "expected iri got %r" % (v,)})
        if prop.get("no_empty") and isinstance(v, str) and not str(v).strip():
            out.append({"shape": shape_name, "property": path, "rule": "no_empty",
                        "node": node.get("id"), "detail": "empty label"})
    if prop.get("unique_lang"):
        seen = {}
        for v in vals:
            n = _norm(v)
            if not n:
                continue
            if n in seen:
                out.append({"shape": shape_name, "property": path, "rule": "unique_lang",
                            "node": node.get("id"), "detail": "duplicate altLabel %r" % v})
            seen[n] = 1
    return out


# ===========================================================================
# 语义规则
# ===========================================================================
def _detect_cycles(concepts):
    """broader 有向图 DFS 三色；返回环列表（每个环给节点序列）。"""
    graph = {c["id"]: [b for b in (c.get("broader") or [])] for c in concepts}
    color = {k: 0 for k in graph}  # 0=未访问 1=栈中 2=完成
    cycles, path = [], []

    def dfs(u):
        color[u] = 1
        path.append(u)
        for v in graph.get(u, []):
            if v not in graph:
                continue
            if color[v] == 1:
                i = path.index(v)
                cycles.append(path[i:] + [v])
            elif color[v] == 0:
                dfs(v)
        color[u] = 2
        path.pop()

    for u in sorted(graph):
        if color[u] == 0:
            dfs(u)
    return cycles


def _semantic_checks(export):
    concepts = export.get("concepts") or []
    schemes = export.get("concept_schemes") or []
    by_id = {c.get("id"): c for c in concepts}
    scheme_ids = {s.get("id") for s in schemes}
    checks = []

    def add(cid, title, violations, note=""):
        checks.append({"id": cid, "title": title, "status": "conforms" if not violations else "violated",
                       "n_violations": len(violations), "samples": violations[:10], "note": note})

    # R-CYCLE
    cycles = _detect_cycles(concepts)
    add("R-CYCLE", "broader 环=0", [{"cycle": c} for c in cycles])
    # R-ORPHAN / inScheme 引用
    orphan = [{"concept": c.get("id"), "scheme": c.get("scheme")}
              for c in concepts if c.get("scheme") not in scheme_ids]
    add("R-ORPHAN", "concept 必须挂已声明 scheme", orphan)
    # R-ISOLATED
    isolated = []
    for c in concepts:
        if c.get("topConceptOf"):
            continue
        if not (c.get("broader") or c.get("narrower") or c.get("related")):
            isolated.append({"concept": c.get("id")})
    add("R-ISOLATED", "非 top 且无边概念=孤立", isolated)
    # R-DUP-PREF / R-DUP-ALT / R-DUP-NOTATION（按 scheme 作用域）
    pref_seen, alt_seen, notation_seen = defaultdict(dict), defaultdict(dict), defaultdict(dict)
    dup_pref, dup_alt, dup_notation, empty_labels = [], [], [], []
    for c in concepts:
        scheme = c.get("scheme")
        key = _norm(c.get("prefLabel"))
        if not key:
            empty_labels.append({"concept": c.get("id"), "field": "prefLabel"})
        elif key in pref_seen[scheme]:
            dup_pref.append({"scheme": scheme, "label": c.get("prefLabel"),
                             "concepts": [pref_seen[scheme][key], c.get("id")]})
        else:
            pref_seen[scheme][key] = c.get("id")
        for a in c.get("altLabel") or []:
            n = _norm(a)
            if not n:
                empty_labels.append({"concept": c.get("id"), "field": "altLabel"})
            elif n in alt_seen[scheme] and alt_seen[scheme][n] != c.get("id"):
                dup_alt.append({"scheme": scheme, "label": a,
                                "concepts": [alt_seen[scheme][n], c.get("id")]})
            else:
                alt_seen[scheme][n] = c.get("id")
        if c.get("notation"):
            n = _norm(c.get("notation"))
            if n in notation_seen[scheme] and notation_seen[scheme][n] != c.get("id"):
                dup_notation.append({"scheme": scheme, "notation": c.get("notation"),
                                     "concepts": [notation_seen[scheme][n], c.get("id")]})
            else:
                notation_seen[scheme][n] = c.get("id")
    add("R-DUP-PREF", "scheme 内 prefLabel 重复=0", dup_pref)
    add("R-DUP-ALT", "scheme 内 altLabel 跨概念重复=0", dup_alt)
    add("R-DUP-NOTATION", "scheme 内 notation 重复=0", dup_notation)
    add("R-EMPTY", "空标签=0", empty_labels)
    # R-INVERSE
    inverse_bad = []
    for c in concepts:
        for b in c.get("narrower") or []:
            bc = by_id.get(b)
            if bc is not None and c.get("id") not in (bc.get("broader") or []):
                inverse_bad.append({"parent": c.get("id"), "child": b, "missing": "broader"})
        for b in c.get("broader") or []:
            bc = by_id.get(b)
            if bc is not None and c.get("id") not in (bc.get("narrower") or []):
                inverse_bad.append({"child": c.get("id"), "parent": b, "missing": "narrower"})
    add("R-INVERSE", "broader↔narrower 互逆", inverse_bad)
    # R-TENANT-01
    scheme_tenant = {s.get("id"): s.get("tenant") for s in schemes}
    tenant_bad = [{"concept": c.get("id"), "tenant": c.get("tenant"),
                   "scheme": c.get("scheme"),
                   "scheme_tenant": scheme_tenant.get(c.get("scheme"))}
                  for c in concepts if c.get("tenant") != scheme_tenant.get(c.get("scheme"))]
    add("R-TENANT-01", "concept.tenant == scheme.tenant", tenant_bad)
    # R-TENANT-02 跨租户边
    cross = []
    for c in concepts:
        for field in ("broader", "narrower", "related"):
            for t in c.get(field) or []:
                other = by_id.get(t)
                if other is None:
                    continue
                if c.get("tenant") != other.get("tenant"):
                    cross.append({"from": c.get("id"), "to": t, "field": field,
                                  "tenants": [c.get("tenant"), other.get("tenant")]})
    add("R-TENANT-02", "边不得跨租户", cross)
    # R-TENANT-03 IRI 全局唯一
    ids = [c.get("id") for c in concepts]
    dup_ids = sorted({i for i in ids if ids.count(i) > 1})
    add("R-TENANT-03", "concept IRI 全局唯一", [{"concept": i} for i in dup_ids])
    # R-TOP
    top_bad = []
    for s in schemes:
        declared = set(_as_list(s.get("topConcepts")))
        for c in concepts:
            if c.get("scheme") != s.get("id"):
                continue
            in_concept = s.get("id") in (c.get("topConceptOf") or [])
            if in_concept != (c.get("id") in declared):
                top_bad.append({"concept": c.get("id"), "scheme": s.get("id"),
                                "top_concept_of": in_concept,
                                "scheme_has_top": c.get("id") in declared})
    add("R-TOP", "topConceptOf 与 hasTopConcept 一致", top_bad)
    # W-ALT-PREF
    pref_by_scheme = defaultdict(dict)
    for c in concepts:
        pref_by_scheme[c.get("scheme")][_norm(c.get("prefLabel"))] = c.get("id")
    warn_alt = []
    for c in concepts:
        for a in c.get("altLabel") or []:
            owner = pref_by_scheme[c.get("scheme")].get(_norm(a))
            if owner and owner != c.get("id"):
                warn_alt.append({"concept": c.get("id"), "altLabel": a, "owner": owner})
    checks.append({"id": "W-ALT-PREF", "severity": "warning",
                   "title": "altLabel 不得等于同 scheme 他概念 prefLabel",
                   "status": "conforms" if not warn_alt else "warned",
                   "n_warnings": len(warn_alt), "samples": warn_alt[:10]})
    no_alt = [{"concept": c.get("id")} for c in concepts if not (c.get("altLabel") or [])]
    checks.append({"id": "W-NO-ALT", "severity": "warning",
                   "title": "无 altLabel 概念数",
                   "status": "conforms" if not no_alt else "warned",
                   "n_warnings": len(no_alt), "samples": no_alt[:10]})
    return checks


# ===========================================================================
# 主校验入口
# ===========================================================================
def validate_export(export: dict, shapes: dict | None = None) -> dict:
    """校验导出物；返回机读结果（不写文件）。纯函数，无 IO/无 app import。"""
    shapes = shapes or SHAPES
    violations, per_shape = [], defaultdict(list)
    _paths(export)  # 填 _known（兼容调用）
    nodes = []
    for kind, node, values in _paths(export):
        nodes.append((kind, node, values))
    shape_by_target = {s.get("target_class"): s for s in shapes.get("node_shapes") or []}
    for kind, node, values in nodes:
        shape = shape_by_target.get("skos:" + kind)
        if shape is None:
            continue
        for prop in shape.get("properties") or []:
            path = prop.get("path")
            vals = values.get(path) or []
            v = _check_property(shape.get("id"), prop, node, vals)
            if v:
                per_shape[shape.get("id")].extend(v)
                violations.extend(v)
    # class 约束（inScheme → ConceptScheme；broader → Concept）在语义层复核
    scheme_ids = {s.get("id") for s in export.get("concept_schemes") or []}
    concept_ids = {c.get("id") for c in export.get("concepts") or []}
    for c in export.get("concepts") or []:
        if c.get("scheme") and c.get("scheme") not in scheme_ids:
            violations.append({"shape": "ConceptShape", "property": "skos:inScheme",
                               "rule": "class", "node": c.get("id"),
                               "detail": "inScheme target not a declared ConceptScheme"})
    for s in export.get("concept_schemes") or []:
        for t in s.get("topConcepts") or []:
            if t not in concept_ids:
                violations.append({"shape": "ConceptSchemeShape", "property": "skos:hasTopConcept",
                                   "rule": "class", "node": s.get("id"),
                                   "detail": "hasTopConcept target not a declared Concept"})
    # broader/narrower/related 的目标必须是已声明 Concept（悬空引用 = violation，不是 warning）
    for c in export.get("concepts") or []:
        for field, path in (("broader", "skos:broader"), ("narrower", "skos:narrower"),
                            ("related", "skos:related")):
            for t in c.get(field) or []:
                if t not in concept_ids:
                    violations.append({"shape": "ConceptShape", "property": path,
                                       "rule": "class", "node": c.get("id"),
                                       "detail": "target not a declared Concept: %s" % t})
    semantic = _semantic_checks(export)
    err_sem = [c for c in semantic if c["status"] == "violated"]
    warn_sem = [c for c in semantic if c["status"] == "warned"]
    stats = export.get("statistics") or {}
    result = {
        "schema": SCHEMA_RESULT,
        "generated_by": "l119_shacl.py/v1",
        "export_content_sha256": export.get("content_sha256") or "",
        "shapes_schema": shapes.get("schema"),
        "conforms": not violations and not err_sem,
        "counts": {
            "concepts": len(export.get("concepts") or []),
            "schemes": len(export.get("concept_schemes") or []),
            "nodes": len(nodes),
            "shacl_violations": len(violations),
            "semantic_violations": sum(c["n_violations"] for c in err_sem),
            "warnings": sum(c.get("n_warnings", 0) for c in warn_sem),
            "checks_total": len(shape_by_target) + len(semantic),
            "checks_conforms": (len(shape_by_target) - len(per_shape)) + len(
                [c for c in semantic if c["status"] == "conforms"]),
        },
        "shacl": {
            "shapes": [s.get("id") for s in shapes.get("node_shapes") or []],
            "violations": violations,
            "by_shape": {k: len(v) for k, v in per_shape.items()},
        },
        "semantic_checks": semantic,
        "violated_checks": ([c["id"] for c in err_sem]
                           + sorted({v.get("shape") for v in violations if v.get("shape")})),
        "warnings": [c["id"] for c in warn_sem],
        "statistics": stats,
    }
    result["result_sha256"] = "sha256:" + hashlib.sha256(
        json.dumps({k: result[k] for k in ("conforms", "counts", "violated_checks")},
                   ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return result


def shapes_json(indent: int = 1) -> str:
    return json.dumps(SHAPES, ensure_ascii=False, indent=indent, sort_keys=True) + "\n"


# ===========================================================================
# CLI
# ===========================================================================
def _write(path, text):
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="L119 SHACL/Core 子集校验原型")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sh = sub.add_parser("shapes", help="输出 SHACL 形状 JSON")
    sh.add_argument("--out", required=True)
    va = sub.add_parser("validate", help="校验 skos_export.json")
    va.add_argument("--export", required=True)
    va.add_argument("--shapes", default="")
    va.add_argument("--out", default="")
    args = ap.parse_args(argv)
    if args.cmd == "shapes":
        _write(args.out, shapes_json())
        print(json.dumps({"ok": True, "out": args.out, "wrote_files": 1,
                          "sha256": "sha256:" + hashlib.sha256(
                              shapes_json().encode("utf-8")).hexdigest()}, ensure_ascii=False))
        return 0
    if args.cmd == "validate":
        try:
            export = json.loads(open(args.export, encoding="utf-8").read())
        except Exception as exc:  # noqa: BLE001
            print(json.dumps({"ok": False, "error": "export_unreadable: %s" % exc}, ensure_ascii=False))
            return 2
        shapes = SHAPES
        if args.shapes:
            try:
                shapes = json.loads(open(args.shapes, encoding="utf-8").read())
            except Exception as exc:  # noqa: BLE001
                print(json.dumps({"ok": False, "error": "shapes_unreadable: %s" % exc}, ensure_ascii=False))
                return 2
        res = validate_export(export, shapes)
        if args.out:
            _write(args.out, json.dumps(res, ensure_ascii=False, indent=1, sort_keys=True) + "\n")
        print(json.dumps({"ok": res["conforms"], "conforms": res["conforms"],
                          "counts": res["counts"], "violated_checks": res["violated_checks"],
                          "warnings": res["warnings"]}, ensure_ascii=False, sort_keys=True))
        return 0 if res["conforms"] else 1
    return 2


if __name__ == "__main__":
    sys.exit(main())
