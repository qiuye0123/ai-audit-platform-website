#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L119 · 一键生成试点 artifacts（SKOS 导出 / SHACL 结果 / JEV 重算 / 族级指标 / 指纹）。

约束（任务书 + AGENTS.md）：
  * 0-LLM：显式 `RULEPROOF_LLM_ENABLED=0`，本脚本不调用任何模型/网络；
  * 产品库只读副本：先把 `data/ruleproof.db` 复制到 `/tmp/...`，之后所有 app 写入
    （仅测试术语 fixture）都落在副本；运行前后对产品库做 sha256/size/mtime 三件套守卫；
  * 只新增 `scripts/prototypes`、`docs/qa/artifacts/l119_...` 与报告；不改 app 主链、不 commit；
  * 全部输出文件写 `docs/qa/artifacts/l119_ontology_jev_20261125/`（可复现：同输入同内容）。

用法：
  PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
  PYTHONPATH=/tmp/qa_pylibs:$PWD $PY scripts/prototypes/l119_generate_artifacts.py
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", ".."))
PRODUCT_DB = os.path.join(REPO, "data", "ruleproof.db")
ARTIFACT_DIR = os.path.join(REPO, "docs", "qa", "artifacts", "l119_ontology_jev_20261125")
ARTIFACT_REL = "docs/qa/artifacts/l119_ontology_jev_20261125"
DEFAULT_WORK = "/tmp/l119_pilot"

sys.path.insert(0, HERE)
import l119_skos  # noqa: E402
import l119_shacl  # noqa: E402
import l119_jev   # noqa: E402


# ===========================================================================
# 指纹 / 文件工具
# ===========================================================================
def fingerprint(path: str) -> dict:
    if not os.path.exists(path):
        return {"path": path, "exists": False}
    st = os.stat(path)
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return {"path": path, "exists": True, "sha256": h.hexdigest(),
            "size": st.st_size, "mtime": int(st.st_mtime)}


def file_sha(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: str, obj) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(obj, ensure_ascii=False, indent=1, sort_keys=True) + "\n")


def write_text(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def write_csv(path: str, rows: list, cols: list) -> None:
    import csv as _csv
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = _csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in cols})


def git(*args) -> str:
    try:
        return subprocess.run(["git"] + list(args), cwd=REPO, capture_output=True,
                              text=True, timeout=30).stdout.strip()
    except Exception:  # noqa: BLE001
        return ""


# ===========================================================================
# 测试 fixture：在 /tmp 副本里种多租户术语（只写副本）
# ===========================================================================
def seed_tenant_terms(db_path: str) -> dict:
    """用真实 terms 写入路径在副本里种租户术语（confirmed/draft），供 SKOS 租户隔离验证。"""
    l119_skos.ensure_tmp_db(db_path)
    from app.services import ctx as app_ctx
    from app.services import terms as app_terms
    seeded = []
    specs = [
        ("t-alpha", "ws-alpha", "焦糖色", "食品添加剂着色剂，按 GB2760 限量使用。",
         ["焦糖色素", "酱色"], "confirmed"),
        ("t-alpha", "ws-alpha", "l119草稿术语", "仅用于验证草稿不进入 SKOS 导出。",
         ["草稿别名"], "draft"),
        ("t-beta", "ws-beta", "焦糖色", "β 租户同名术语，用于验证跨租户同名不串租。",
         ["酱色"], "confirmed"),
        ("t-beta", "ws-beta", "β租户原料", "β 租户第二个已生效术语。",
         ["β原料"], "confirmed"),
    ]
    for tenant, workspace, name, definition, synonyms, want in specs:
        try:
            with app_ctx.scoped(tenant, workspace):
                r = app_terms.create_term(name, definition, synonyms=synonyms,
                                          source="l119-fixture", entity_type="Field",
                                          actor="l119")
                tid = r.get("term_id") or ""
                status = r.get("status") or ""
                if want == "confirmed" and tid:
                    c = app_terms.confirm(tid, actor="l119")
                    status = c.get("status") or status
                seeded.append({"tenant": tenant, "workspace": workspace, "name": name,
                               "term_id": tid, "status": status, "ok": bool(r.get("ok"))})
        except Exception as exc:  # noqa: BLE001 - 失败如实记录，不伪装
            seeded.append({"tenant": tenant, "workspace": workspace, "name": name,
                           "ok": False, "error": "%s: %s" % (type(exc).__name__, exc)})
    return {"seeded": seeded}


# ===========================================================================
# 主流程
# ===========================================================================
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="L119 试点 artifacts 一键生成")
    ap.add_argument("--work", default=DEFAULT_WORK)
    ap.add_argument("--out", default=ARTIFACT_DIR)
    ap.add_argument("--skip-seed", action="store_true", help="复用 --work 下已有 DB 副本")
    ap.add_argument("--test-result", default="",
                    help="scripts/qa/l119_ontology_jev_probe.py --json 输出；存在则纳入 artifacts 与 SHA256SUMS")
    args = ap.parse_args(argv)

    os.environ["RULEPROOF_LLM_ENABLED"] = "0"
    os.environ["RULEPROOF_PASSWORD_ENFORCE"] = "0"
    os.environ.setdefault("PYTHONPATH", "/tmp/qa_pylibs:" + REPO)
    work = os.path.abspath(args.work)
    os.makedirs(work, exist_ok=True)
    db_copy = os.path.join(work, "ruleproof_copy.db")

    # 产品库基线（本 lane 开工时登记值；运行窗口内再前后各测一次）
    lane_start_baseline = {
        "sha256": "94d7cbe78e4dcf0ca44247a9187c8f997c288dde28122342a98a18b2ca9261f6",
        "size": 108511232, "mtime": 1795497918,
        "note": "L119 开工（2026-11-25 07:51）复制副本时登记；会话期间其他 lane 可能写入，"
                "本 lane 只对**自身运行窗口**做前后守卫",
    }
    before = fingerprint(PRODUCT_DB)
    repo_before = {
        "head": git("rev-parse", "HEAD"),
        "blind_ontology": fingerprint(os.path.join(REPO, "docs", "blind", "ontology_v2.json")),
        "seed_ontology": fingerprint(os.path.join(REPO, "seed", "ontology_v2.json")),
    }
    if not args.skip_seed or not os.path.exists(db_copy):
        shutil.copy2(PRODUCT_DB, db_copy)
        # 副本不要带产品库 WAL/SHM，避免打开时把未提交页读进来
        for suffix in ("-wal", "-shm"):
            p = db_copy + suffix
            if os.path.exists(p):
                os.remove(p)
    l119_skos.ensure_tmp_db(db_copy)

    seed = {"seeded": [], "note": "skip-seed 复用副本"} if args.skip_seed \
        else seed_tenant_terms(db_copy)

    os.makedirs(args.out, exist_ok=True)

    # ---------------- SKOS 导出（两次同输入 → 同内容；无写入自检） ----------------
    tenants = ["t-default", "t-alpha", "t-beta"]
    export1 = l119_skos.build_export(db_copy, tenants=tenants)
    export2 = l119_skos.build_export(db_copy, tenants=tenants)
    deterministic = export1["content_sha256"] == export2["content_sha256"]
    nt = l119_skos.to_nt(export1)
    rt = l119_skos.roundtrip(export1, nt)
    write_text(os.path.join(args.out, "skos_export.json"),
               json.dumps(export1, ensure_ascii=False, indent=1, sort_keys=True) + "\n")
    write_text(os.path.join(args.out, "skos_export.nt"), nt)
    shapes_text = l119_shacl.shapes_json()
    write_text(os.path.join(args.out, "l119_shacl_shapes.json"), shapes_text)
    shacl_result = l119_shacl.validate_export(export1, l119_shacl.SHAPES)
    write_json(os.path.join(args.out, "shacl_result.json"), shacl_result)
    # --check 零写入语义：只计算、不落盘（子进程验证 wrote_files=0）
    check_proc = subprocess.run(
        [sys.executable, os.path.join(HERE, "l119_skos.py"), "export",
         "--db", db_copy, "--check", "--tenants", ",".join(tenants)],
        cwd=REPO, capture_output=True, text=True, timeout=180,
        env=dict(os.environ, RULEPROOF_DB=db_copy, RULEPROOF_LLM_ENABLED="0",
                 PYTHONPATH=os.environ["PYTHONPATH"]))
    check_manifest = {}
    try:
        check_manifest = json.loads(check_proc.stdout.strip().splitlines()[-1])
    except Exception:  # noqa: BLE001
        check_manifest = {"parse_error": check_proc.stdout[-500:], "stderr": check_proc.stderr[-500:]}

    # ---------------- JEV recompute pilot ----------------
    payload_pkg = l119_jev.build_payloads()
    write_json(os.path.join(args.out, "recompute_payloads.json"), payload_pkg)
    l119_jev._write_payload_csv(os.path.join(args.out, "recompute_payloads.csv"),
                                payload_pkg["payloads"])
    results = l119_jev.recompute_all(payload_pkg)
    recompute_summary = l119_jev.summarize_results(results)
    write_json(os.path.join(args.out, "recompute_summary.json"), recompute_summary)
    l119_jev._write_result_csv(os.path.join(args.out, "recompute_results.csv"), results)
    selftest = l119_jev.build_selftest()
    selftest_summary = {"n": len(selftest), "passed": sum(1 for c in selftest if c["pass"]),
                        "failed": [c for c in selftest if not c["pass"]], "cases": selftest}
    write_json(os.path.join(args.out, "recompute_selftest.json"), selftest_summary)

    # 规则级 recompute 资格（供族级 allowlist 最小试点判定）
    recompute_rules = {}
    for p in payload_pkg["payloads"]:
        r = recompute_rules.setdefault(p["rule_code"], {
            "n": 0, "claim_holds": 0, "contradicted": 0, "insufficient": 0,
            "app_compatible": bool(p["verifier"]["app_compatible"]),
            "kinds": set()})
        r["n"] += 1
        r["kinds"].add(p["verifier"]["kind"])
        r["app_compatible"] = r["app_compatible"] and bool(p["verifier"]["app_compatible"])
    for res in results:
        r = recompute_rules[res["rule_code"]]
        if res["verdict"] == "claim_holds":
            r["claim_holds"] += 1
        elif res["verdict"] == "claim_contradicted":
            r["contradicted"] += 1
        else:
            r["insufficient"] += 1
    for r in recompute_rules.values():
        r["kinds"] = sorted(r["kinds"])
        if not r["app_compatible"]:
            r["reason"] = "app_compatible=False（原型独有 verifier：%s）" % "/".join(r["kinds"])
        elif r["insufficient"]:
            r["reason"] = "insufficient=%d（归档载荷不完整）" % r["insufficient"]
        elif r["contradicted"]:
            r["reason"] = "contradicted=%d" % r["contradicted"]
    family = l119_jev.family_evaluate(recompute_rules=recompute_rules)
    write_json(os.path.join(args.out, "family_metrics.json"), family)
    l119_jev._write_family_csv(os.path.join(args.out, "family_metrics.csv"),
                               family["families"])

    # ---------------- 产品库/仓库守卫（本 lane 运行窗口） ----------------
    after = fingerprint(PRODUCT_DB)
    repo_after = {
        "head": git("rev-parse", "HEAD"),
        "blind_ontology": fingerprint(os.path.join(REPO, "docs", "blind", "ontology_v2.json")),
        "seed_ontology": fingerprint(os.path.join(REPO, "seed", "ontology_v2.json")),
    }
    window_unchanged = _same_guard(before, after)
    repo_files_unchanged = all(
        _same_guard(repo_before[k], repo_after[k])
        for k in ("blind_ontology", "seed_ontology"))
    env = {
        "lane": "L119",
        "date": "2026-11-25",
        "kind": "ontology SKOS/SHACL + JEV recompute pilot（只读原型 + docs/artifacts，不写主链）",
        "python": sys.version.split()[0],
        "repo_head": repo_before["head"],
        "head_unchanged_in_window": repo_before["head"] == repo_after["head"],
        "llm": {"RULEPROOF_LLM_ENABLED": os.environ.get("RULEPROOF_LLM_ENABLED"),
                "model_calls": 0, "network_calls": 0},
        "db": {"ruleproof_db_env": os.environ.get("RULEPROOF_DB"),
               "tmp_copy": db_copy,
               "note": "工具/测试库均为 /tmp；产品库只读复制，未对其执行写操作"},
        "product_db": {
            "lane_start_baseline": lane_start_baseline,
            "window_before": before,
            "window_after": after,
            "window_unchanged": window_unchanged,
            "external_concurrent_write_note": (
                "若 window_before.sha256 != lane_start_baseline.sha256，说明本 lane 开工后、"
                "本脚本运行前已有其他 lane 写入产品库（共享工作区），与本 lane 无关；"
                "本 lane 的守卫口径是 window_before == window_after。")
        },
        "repo_files": {
            "before": repo_before, "after": repo_after,
            "unchanged_in_window": repo_files_unchanged,
        },
        "skos": {
            "export_content_sha256": export1["content_sha256"],
            "nt_sha256": "sha256:" + hashlib.sha256(nt.encode("utf-8")).hexdigest(),
            "deterministic_same_input_same_sha": deterministic,
            "nt_roundtrip": rt,
            "shacl_conforms": shacl_result["conforms"],
            "shacl_counts": shacl_result["counts"],
            "check_mode": {"exit_code": check_proc.returncode,
                           "wrote_files": check_manifest.get("wrote_files"),
                           "ok": check_proc.returncode == 0
                                 and check_manifest.get("wrote_files") == 0},
            "tenants": tenants,
            "seed_terms": seed,
        },
        "jev": {
            "n_payloads": payload_pkg["statistics"]["n_payloads"],
            "agreement_rate_recomputable": recompute_summary["agreement_rate_recomputable"],
            "agreement_ci_wilson": recompute_summary["agreement_ci_wilson"],
            "recomputable": recompute_summary["recomputable"],
            "insufficient": recompute_summary["insufficient"],
            "claim_contradicted": recompute_summary["claim_contradicted"],
            "selftest": {"n": selftest_summary["n"], "passed": selftest_summary["passed"]},
        },
        "family_blocking": {
            "global_verdict": family["global_blocking"]["verdict"],
            "global_injury_rate": family["global_blocking"]["injury_rate"],
            "partition_ok": family["unmapped"]["partition_ok"],
            "pilot_allowlist_families": family["pilot"]["allowlist_families_phase1"],
            "pilot_allowlist_rules": family["pilot"]["allowlist_rules_phase1"],
        },
        "run_at_local": datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    write_json(os.path.join(args.out, "env.json"), env)

    # ---------------- 测试结果（可选纳入，供报告复核） ----------------
    test_result = {}
    if args.test_result and os.path.exists(args.test_result):
        try:
            test_result = json.loads(open(args.test_result, encoding="utf-8").read())
        except Exception:  # noqa: BLE001
            test_result = {"parse_error": True}
        shutil.copy2(args.test_result, os.path.join(args.out, "l119_test_result.json"))
        env["test_result"] = {"source": args.test_result,
                              "total": test_result.get("total"),
                              "passed": test_result.get("passed"),
                              "failed": test_result.get("failed_names"),
                              "ok": test_result.get("ok")}
        write_json(os.path.join(args.out, "env.json"), env)

    # ---------------- SHA256SUMS ----------------
    sums = []
    for name in sorted(os.listdir(args.out)):
        if name in ("SHA256SUMS",) or name.startswith("."):
            continue
        p = os.path.join(args.out, name)
        if os.path.isfile(p):
            sums.append("%s  %s" % (file_sha(p), name))
    write_text(os.path.join(args.out, "SHA256SUMS"), "\n".join(sums) + "\n")

    test_ok = bool(not test_result or test_result.get("ok"))
    summary = {
        "ok": bool(rt["ok"] and shacl_result["conforms"] and deterministic
                   and window_unchanged and env["skos"]["check_mode"]["ok"]
                   and selftest_summary["passed"] == selftest_summary["n"]
                   and test_ok),
        "artifact_dir": os.path.relpath(args.out, REPO),
        "skos": {"concepts": export1["statistics"]["concepts"],
                 "schemes": export1["statistics"]["schemes"],
                 "alt_labels": export1["statistics"]["alt_labels"],
                 "cycles": 0,
                 "shacl_conforms": shacl_result["conforms"],
                 "shacl_violations": shacl_result["counts"]["shacl_violations"],
                 "semantic_violations": shacl_result["counts"]["semantic_violations"],
                 "warnings": shacl_result["counts"]["warnings"],
                 "nt_parse_rate": rt["parse_rate"],
                 "deterministic": deterministic,
                 "check_wrote_files": check_manifest.get("wrote_files")},
        "jev": {"n": recompute_summary["n"], "recomputable": recompute_summary["recomputable"],
                "claim_holds": recompute_summary["claim_holds"],
                "insufficient": recompute_summary["insufficient"],
                "agreement_rate_recomputable": recompute_summary["agreement_rate_recomputable"],
                "difference_reasons": recompute_summary["difference_reasons"],
                "selftest": "%d/%d" % (selftest_summary["passed"], selftest_summary["n"])},
        "family": {"partition_ok": family["unmapped"]["partition_ok"],
                   "global_verdict": family["global_blocking"]["verdict"],
                   "global_injury_rate": family["global_blocking"]["injury_rate"],
                   "pilot_rules": family["pilot"]["allowlist_rules_phase1"]},
        "test_result": env.get("test_result", {}),
        "guards": {"product_db_window_unchanged": window_unchanged,
                   "repo_files_unchanged": repo_files_unchanged,
                   "head_unchanged": env["head_unchanged_in_window"]},
    }
    print(json.dumps(summary, ensure_ascii=False, indent=1, sort_keys=True))
    return 0 if summary["ok"] else 3


def _same_guard(a: dict, b: dict) -> bool:
    keys = ("exists", "sha256", "size", "mtime")
    return all(a.get(k) == b.get(k) for k in keys)


if __name__ == "__main__":
    sys.exit(main())
