# build50 沙箱最小原型（scripts/prototypes/build50_sandbox）

> L113 / build50 设计原型 lane。**不接主链、不 import app、不连数据库、不访问网络、不写产品库。**
> 设计说明见 `platform/docs/prototypes/build50/sandbox/sandbox-design.md`，机读策略见 `sandbox-policy.json`。

## 是什么

`isolated_executor.py` 是一个本地隔离执行器原型：
- 父进程校验执行器 manifest（id/version/sha256/engine_compat/determinism/resource_policy/allowed_imports）；
- 静态扫描源码（import 白名单 + 危险调用 + 必须定义 `run(inputs, ctx)`）；
- 在临时目录 staging 只读输入；
- 子进程隔离执行：`python -I -S` + rlimit + `sys.addaudithook`（拒绝网络/子进程/DB/ctypes/越界文件读写/动态 import）+ 墙钟超时 + 输出上限；
- 确定性复跑比对 `result_sha256`。

## 运行自测（推荐）

```bash
cd platform/scripts/prototypes/build50_sandbox
PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
$PY isolated_executor.py --selftest --out /tmp/l113_sandbox_selftest.json
```

当前实测 **11/11 PASS**。用例覆盖：正常 D1 执行、网络拒绝、越界读/写拒绝、超时、输出超限、SQLite 拒绝、源码 SHA256 篡改、危险 import、D2 拒绝、引擎版本不兼容。

## 执行单个 manifest

```bash
$PY isolated_executor.py --manifest /path/to/manifest.json
```

manifest 形态见 `platform/docs/prototypes/build50/sandbox/manifest.example.json`。原型不提供上传/注册入口。

## 原型限制（不得当成生产沙箱）

1. macOS 实测 `RLIMIT_AS` 不可用（`unsupported:ValueError`）；生产内存上限必须用 Linux cgroup/容器。
2. Python audit hook 可被 C 扩展/解释器漏洞绕过，不是安全边界；生产必须叠加 OS 级隔离（macOS sandbox-exec / Linux seccomp+netns+只读根）。
3. 仅支持确定性等级 D1；不做第三方依赖；输出 schema 强校验未实现。
4. 临时文件全部在系统临时目录，运行后清理（`--keep` 可保留用于排查）。

## 安全声明

- 不要用本原型执行真实客户代码或不可信代码；
- 不要在生产服务器上直接运行 --selftest 之外的未审代码；
- 任何执行器上线前必须走设计文档 §4/§5 的注册、测试、双人评审与灰度流程。
