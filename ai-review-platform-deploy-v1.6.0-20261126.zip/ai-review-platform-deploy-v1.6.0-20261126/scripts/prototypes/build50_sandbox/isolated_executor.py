#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build50 代码沙箱 · 最小本地隔离执行器原型（L113 设计稿，不接主链）
====================================================================
本文件是「代码沙箱设计」的可运行最小原型，用于验证隔离思路是否成立：
- 执行器包 = manifest（id/version/sha256/engine_compat/determinism/allowed_imports/
  resource_policy）+ 单文件 Python 源码（必须定义 run(inputs, ctx)）。
- 父进程：manifest 校验 -> 源码 SHA256 校验 -> 静态导入/危险调用扫描 -> 引擎版本兼容 ->
  临时目录只读输入 -> 子进程隔离执行 -> 墙钟超时 -> 输出大小上限 -> 确定性复跑比对。
- 子进程：资源限制（CPU/内存/文件大小）-> Python audit hook 拒绝网络/子进程/DB/ctypes/
  越界文件读写/动态 import/exec -> 执行用户函数 -> 只通过 stdout 返回 JSON 结果。

明确边界（与设计文档一致）：
1) 这是**原型**，不是生产沙箱。Python audit hook 可被 C 扩展/解释器漏洞绕过；
   生产必须叠加 OS 级隔离（macOS sandbox-exec / Linux seccomp+netns+seccomp）与容器/VM。
2) 不 import app、不连数据库、不读产品库、不访问网络；所有临时文件在系统临时目录。
3) 静态扫描是「降低误用」不是安全边界；真正的边界是子进程隔离 + OS 隔离。
4) 仅支持确定性等级 D1（纯函数）；D2/D3 一律拒绝（需人工评审）。

用法：
  python3 isolated_executor.py --selftest                 # 运行内置自测（推荐）
  python3 isolated_executor.py --manifest m.json          # 执行一个执行器包
  python3 isolated_executor.py --child <in> <out> <max_output>  # 内部使用
"""
import ast
import hashlib
import json
import os
import re
import resource
import shutil
import signal
import subprocess
import sys
import tempfile
import time

ENGINE_VERSION = "1.0.0"

# 原型上限（防止演示时真的申请 10GB 内存）：生产策略由部署配置给出。
PROTOTYPE_CAPS = {
    "wall_ms": 10000,
    "cpu_seconds": 8,
    "memory_mb": 512,
    "fsize_mb": 8,
    "max_output_bytes": 1024 * 1024,
    "max_attempts": 2,
}
REQUIRED_MANIFEST = ("executor_id", "version", "engine_compat", "source", "sha256",
                     "entrypoint", "determinism", "resource_policy", "allowed_imports")
DANGEROUS_MODULES = {
    "os", "sys", "subprocess", "socket", "ctypes", "shutil", "pathlib", "tempfile",
    "multiprocessing", "threading", "asyncio", "http", "urllib", "requests", "ftplib",
    "sqlite3", "psycopg2", "pickle", "marshal", "importlib", "builtins", "gc",
    "inspect", "types", "runpy", "code", "codeop", "pty", "signal", "resource",
}
DANGEROUS_NAMES = {"eval", "exec", "compile", "__import__", "breakpoint"}
FORBIDDEN_EVENTS = (
    "socket.", "subprocess.", "os.system", "os.exec", "os.fork", "os.spawn",
    "os.posix_spawn", "os.kill", "sqlite3.", "ctypes.", "urllib.", "http.",
    "ftplib.", "pickle.", "marshal.", "signal.", "resource.",
)


# ---------------------------------------------------------------------------
# 通用工具
# ---------------------------------------------------------------------------
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def json_digest(obj):
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def version_tuple(v):
    parts = re.findall(r"\d+", str(v))
    if len(parts) < 2:
        parts += ["0"] * (2 - len(parts))
    return tuple(int(x) for x in parts[:3])


def engine_compatible(spec):
    """支持 '>=1.0.0,<2.0.0' 形式的简化约束（原型不引 packaging）。"""
    cur = version_tuple(ENGINE_VERSION)
    for clause in str(spec or "").split(","):
        clause = clause.strip()
        m = re.match(r"^(>=|<=|>|<|==|=)?\s*(\d+(?:\.\d+){0,2})$", clause)
        if not m:
            return False, "engine_compat_unparseable"
        op = m.group(1) or "=="
        target = version_tuple(m.group(2))
        if op in (">=", "=>") and not (cur >= target):
            return False, "engine_too_old"
        if op == "<=" and not (cur <= target):
            return False, "engine_too_new"
        if op == ">" and not (cur > target):
            return False, "engine_too_old"
        if op == "<" and not (cur < target):
            return False, "engine_too_new"
        if op in ("==", "=") and not (cur == target):
            return False, "engine_version_mismatch"
    return True, ""


# ---------------------------------------------------------------------------
# manifest 校验 + 静态扫描
# ---------------------------------------------------------------------------
def load_manifest(path):
    with open(path, "r", encoding="utf-8") as f:
        m = json.load(f)
    missing = [k for k in REQUIRED_MANIFEST if k not in m]
    if missing:
        raise ValueError("manifest_missing_fields:%s" % ",".join(missing))
    if not re.match(r"^[a-z][a-z0-9_.-]{1,63}$", str(m["executor_id"])):
        raise ValueError("manifest_bad_executor_id")
    if not re.match(r"^\d+\.\d+\.\d+$", str(m["version"])):
        raise ValueError("manifest_bad_version")
    if m["determinism"] != "D1":
        raise ValueError("determinism_not_supported:%s" % m["determinism"])
    ok, why = engine_compatible(m["engine_compat"])
    if not ok:
        raise ValueError(why)
    rp = m.get("resource_policy") or {}
    for key, cap in (("wall_ms", PROTOTYPE_CAPS["wall_ms"]),
                     ("cpu_seconds", PROTOTYPE_CAPS["cpu_seconds"]),
                     ("memory_mb", PROTOTYPE_CAPS["memory_mb"]),
                     ("fsize_mb", PROTOTYPE_CAPS["fsize_mb"]),
                     ("max_output_bytes", PROTOTYPE_CAPS["max_output_bytes"])):
        val = rp.get(key)
        if not isinstance(val, int) or val <= 0 or val > cap:
            raise ValueError("resource_policy_invalid:%s" % key)
    if not isinstance(m.get("allowed_imports"), list) or not m["allowed_imports"]:
        raise ValueError("manifest_allowed_imports_invalid")
    return m


def static_scan(source, allowed_imports):
    """静态扫描：拒绝不在白名单的 import 与危险调用/dunder。

    注意：这不是安全边界（可被绕过），只是第一道「明显误用」闸门；执行期由 audit hook 兜底。
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return ["source_syntax_error:%s" % e]
    problems = []
    allowed = {str(x).split(".")[0] for x in allowed_imports}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root not in allowed:
                    problems.append("import_not_allowed:%s" % root)
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root not in allowed:
                problems.append("import_not_allowed:%s" % root)
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in DANGEROUS_NAMES:
                problems.append("dangerous_call:%s" % node.func.id)
        elif isinstance(node, ast.Attribute):
            if node.attr.startswith("__") and node.attr.endswith("__"):
                problems.append("dunder_access:%s" % node.attr)
    # 必须有入口函数 run(inputs, ctx)
    funcs = {n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    if "run" not in funcs:
        problems.append("missing_entrypoint:run")
    return sorted(set(problems))


# ---------------------------------------------------------------------------
# 子进程内：隔离执行
# ---------------------------------------------------------------------------
def child_main(input_dir, out_dir, max_output_bytes):
    """在受限子进程中执行 input/src.py 的 run(inputs, ctx)。"""
    input_dir = os.path.realpath(input_dir)
    out_dir = os.path.realpath(out_dir)
    limits = {}

    # 1) 资源限制（尽力而为；失败可观测，不静默）
    mem_mb = int(os.environ.get("_SBX_MEM_MB", "128"))
    cpu_s = int(os.environ.get("_SBX_CPU_S", "2"))
    fsize_mb = int(os.environ.get("_SBX_FSIZE_MB", "1"))
    for name, val in (("RLIMIT_CPU", (cpu_s, cpu_s + 1)),
                      ("RLIMIT_AS", (mem_mb * 1024 * 1024, mem_mb * 1024 * 1024)),
                      ("RLIMIT_FSIZE", (fsize_mb * 1024 * 1024, fsize_mb * 1024 * 1024))):
        try:
            resource.setrlimit(getattr(resource, name), val)
            limits[name] = "applied:%s" % (val[0],)
        except (ValueError, OSError, AttributeError) as e:
            limits[name] = "unsupported:%s" % type(e).__name__

    # 2) 预加载白名单模块（之后 audit hook 只允许这些模块）
    allowed = [x for x in os.environ.get("_SBX_ALLOWED_IMPORTS", "").split(",") if x]
    preloaded = {}
    for mod in allowed:
        try:
            __import__(mod)
            preloaded[mod] = True
        except Exception as e:  # noqa: BLE001 - 预加载失败要显式记录
            preloaded[mod] = "failed:%s" % type(e).__name__

    # 3) 读取输入并编译源码（在 install hook 之前完成；源码来自只读 staging）
    src_path = os.path.join(input_dir, "src.py")
    inp_path = os.path.join(input_dir, "input.json")
    try:
        with open(inp_path, "r", encoding="utf-8") as f:
            inputs = json.load(f)
        with open(src_path, "r", encoding="utf-8") as f:
            source = f.read()
        code_obj = compile(source, "sandbox_executor.py", "exec")  # noqa: S102 - 受控执行设计意图
    except BaseException as e:  # noqa: BLE001 - staging 失败必须结构化返回
        sys.stdout.write(json.dumps({"ok": False, "error": {"type": type(e).__name__,
                                    "message": "sandbox:stage_read_failed:%s" % str(e)[:200]}},
                                    ensure_ascii=False, sort_keys=True))
        sys.stdout.flush()
        return 0

    # 4) audit hook：网络/子进程/DB/ctypes/越界文件/动态 import 一律拒绝
    def _within(path, roots):
        try:
            real = os.path.realpath(path)
        except Exception:  # noqa: BLE001
            return False
        for r in roots:
            r = os.path.realpath(r)
            if real == r or real.startswith(r + os.sep):
                return True
        return False

    def _audit(event, args):
        if event == "import":
            root = str(args[0]).split(".")[0] if args else ""
            if root not in preloaded or preloaded[root] is not True:
                raise PermissionError("sandbox:import_denied:%s" % root)
            return
        if event.startswith(FORBIDDEN_EVENTS):
            raise PermissionError("sandbox:event_denied:%s" % event)
        if event == "open":
            path = args[0] if args else None
            mode = args[1] if len(args) > 1 else "r"
            flags = args[2] if len(args) > 2 else 0
            if path is None:
                return
            p = str(path)
            if p in ("<stdin>", "<stdout>", "<stderr>"):
                return
            writing = False
            if isinstance(mode, str) and any(ch in mode for ch in "wax+"):
                writing = True
            if isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
                writing = True
            if writing:
                if not _within(p, [out_dir]):
                    raise PermissionError("sandbox:write_denied:%s" % p)
            else:
                if not (_within(p, [input_dir]) or p == os.devnull):
                    raise PermissionError("sandbox:read_denied:%s" % p)
            return
        if event in ("os.remove", "os.rename", "os.mkdir", "os.rmdir"):
            target = args[0] if args else None
            if target and not _within(str(target), [out_dir]):
                raise PermissionError("sandbox:path_denied:%s" % event)

    sys.addaudithook(_audit)

    def _emit(obj):
        raw = json.dumps(obj, ensure_ascii=False, sort_keys=True)
        if len(raw.encode("utf-8")) > max_output_bytes:
            raw = json.dumps({"ok": False, "error": {"type": "OutputTooLarge",
                              "message": "sandbox:output_too_large"}}, ensure_ascii=False)
        sys.stdout.write(raw)
        sys.stdout.flush()

    try:
        ns = {"__name__": "sandbox_executor", "__builtins__": __builtins__}
        exec(code_obj, ns)  # noqa: S102
        fn = ns.get("run")
        if not callable(fn):
            _emit({"ok": False, "error": {"type": "MissingEntrypoint", "message": "missing_entrypoint:run"}})
            return 0
        result = fn(inputs, {"determinism": "D1", "engine_version": ENGINE_VERSION})
        try:
            digest = json_digest(result)
        except TypeError as e:
            _emit({"ok": False, "error": {"type": "OutputNotSerializable", "message": str(e)}})
            return 0
        _emit({"ok": True, "result": result, "result_sha256": digest, "limits": limits,
               "preloaded": sorted(k for k, v in preloaded.items() if v is True)})
        return 0
    except PermissionError as e:
        _emit({"ok": False, "error": {"type": "SandboxDenied", "message": str(e)}, "limits": limits})
        return 0
    except MemoryError:
        _emit({"ok": False, "error": {"type": "MemoryLimit", "message": "memory_limit_exceeded"}, "limits": limits})
        return 0
    except BaseException as e:  # noqa: BLE001 - 任何用户异常都要结构化返回，不许静默
        _emit({"ok": False, "error": {"type": type(e).__name__, "message": str(e)[:500]}, "limits": limits})
        return 0


# ---------------------------------------------------------------------------
# 父进程：staging + 受控执行
# ---------------------------------------------------------------------------
def stage_package(manifest, workdir):
    """在临时目录生成只读输入区（源码 + 输入）与可写输出区。"""
    in_dir = os.path.join(workdir, "input")
    out_dir = os.path.join(workdir, "out")
    os.makedirs(in_dir, exist_ok=True)
    os.makedirs(out_dir, exist_ok=True)
    src_dst = os.path.join(in_dir, "src.py")
    shutil.copyfile(manifest["_source_path"], src_dst)
    with open(os.path.join(in_dir, "input.json"), "w", encoding="utf-8") as f:
        json.dump(manifest.get("_inputs", {}), f, ensure_ascii=False)
    os.chmod(src_dst, 0o444)
    os.chmod(os.path.join(in_dir, "input.json"), 0o444)
    os.chmod(in_dir, 0o555)
    return in_dir, out_dir


def run_once(manifest, in_dir, out_dir, label=""):
    rp = manifest["resource_policy"]
    env = {
        "PATH": "/usr/bin:/bin",
        "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
        "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
        "_SBX_MEM_MB": str(rp["memory_mb"]),
        "_SBX_CPU_S": str(rp["cpu_seconds"]),
        "_SBX_FSIZE_MB": str(rp["fsize_mb"]),
        "_SBX_ALLOWED_IMPORTS": ",".join(manifest["allowed_imports"]),
    }
    cmd = [sys.executable, "-I", "-S", os.path.abspath(__file__), "--child",
           in_dir, out_dir, str(rp["max_output_bytes"])]
    started = time.time()
    proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, env=env, cwd=out_dir, start_new_session=True)
    status = "ok"
    try:
        stdout_b, stderr_b = proc.communicate(timeout=rp["wall_ms"] / 1000.0 + 1.5)
    except subprocess.TimeoutExpired:
        status = "timeout"
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout_b, stderr_b = proc.communicate()
    wall_ms = int((time.time() - started) * 1000)
    if len(stdout_b) > rp["max_output_bytes"] + 4096:
        status = "output_too_large"
    payload = None
    if status == "ok":
        try:
            payload = json.loads(stdout_b.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            status = "runtime_error"
    if status == "ok" and not isinstance(payload, dict):
        status = "runtime_error"
    if status == "ok" and not payload.get("ok"):
        err_type = str((payload.get("error") or {}).get("type") or "")
        if err_type in ("SandboxDenied", "MemoryLimit", "OutputTooLarge", "OutputNotSerializable", "MissingEntrypoint"):
            status = "blocked_by_sandbox"
    out = {
        "label": label, "status": status, "wall_ms": wall_ms, "returncode": proc.returncode,
        "stdout_bytes": len(stdout_b), "stderr_bytes": len(stderr_b),
        "payload": payload if status in ("ok", "blocked_by_sandbox") else None,
        "stderr_tail": stderr_b.decode("utf-8", "replace")[-600:],
    }
    if status == "blocked_by_sandbox" and payload:
        out["blocked_reason"] = (payload.get("error") or {}).get("message", "")
    if status == "timeout":
        out["blocked_reason"] = "sandbox:wall_timeout"
    if status == "output_too_large":
        out["blocked_reason"] = "sandbox:output_too_large"
    return out


def execute_package(manifest_path, inputs=None, workdir=None, check_determinism=True, keep=False):
    """完整执行：manifest 校验 -> 扫描 -> staging -> 执行 -> 确定性复跑。"""
    record = {"manifest_path": os.path.abspath(manifest_path), "status": "rejected",
              "errors": [], "runs": [], "deterministic": None, "sandbox": "python-audit-hook(prototype)"}
    own_tmp = False
    try:
        m = load_manifest(manifest_path)
        base = os.path.dirname(os.path.abspath(manifest_path))
        src = os.path.join(base, m["source"])
        if not os.path.isfile(src):
            record["errors"].append("source_not_found")
            return record
        digest = sha256_file(src)
        if digest != str(m["sha256"]).lower():
            record["errors"].append("sha256_mismatch")
            record["expected_sha256"] = str(m["sha256"]).lower()
            record["actual_sha256"] = digest
            return record
        with open(src, "r", encoding="utf-8") as f:
            source = f.read()
        problems = static_scan(source, m["allowed_imports"])
        if problems:
            record["errors"].extend(problems)
            return record
        m["_source_path"] = src
        m["_inputs"] = inputs or {}
        record["executor_id"] = m["executor_id"]
        record["version"] = m["version"]
        record["source_sha256"] = digest
        if workdir is None:
            workdir = tempfile.mkdtemp(prefix="build50_sbx_")
            own_tmp = True
        if os.path.isdir(workdir):
            shutil.rmtree(workdir, ignore_errors=True)
        os.makedirs(workdir, exist_ok=True)
        in_dir, out_dir = stage_package(m, workdir)
        r1 = run_once(m, in_dir, out_dir, "run1")
        record["runs"].append(r1)
        if check_determinism and r1["status"] == "ok":
            shutil.rmtree(out_dir, ignore_errors=True)
            os.makedirs(out_dir)
            r2 = run_once(m, in_dir, out_dir, "run2")
            record["runs"].append(r2)
            if r2["status"] == "ok":
                d1 = (r1.get("payload") or {}).get("result_sha256")
                d2 = (r2.get("payload") or {}).get("result_sha256")
                record["deterministic"] = bool(d1) and d1 == d2
                record["result_sha256"] = d1
        if r1["status"] == "ok":
            record["status"] = "ok"
        elif r1["status"] == "blocked_by_sandbox":
            record["status"] = "blocked_by_sandbox"
        elif r1["status"] == "timeout":
            record["status"] = "timeout"
        elif r1["status"] == "output_too_large":
            record["status"] = "output_too_large"
        else:
            record["status"] = "runtime_error"
        record["workdir"] = workdir
        return record
    except ValueError as e:
        record["errors"].append(str(e))
        return record
    finally:
        if own_tmp and not keep:
            try:
                shutil.rmtree(record.get("workdir", ""), ignore_errors=True)
                record["workdir"] = "(removed)"
            except Exception:  # noqa: BLE001
                pass


# ---------------------------------------------------------------------------
# 内置自测：动态生成夹具（不把恶意代码放进仓库）
# ---------------------------------------------------------------------------
CASES = [
    {
        "name": "C1 正常确定性执行",
        "source": "def run(inputs, ctx):\n    return {\"sum\": sum(inputs[\"values\"]), \"n\": len(inputs[\"values\"])}\n",
        "inputs": {"values": [1, 2, 3, 4]},
        "expect": "ok", "expect_deterministic": True,
    },
    {
        "name": "C2 网络访问被拒绝",
        "source": "import socket\n\ndef run(inputs, ctx):\n    s = socket.socket()\n    return {\"connected\": False}\n",
        "inputs": {},
        "expect": "blocked_by_sandbox", "expect_reason_contains": "socket",
        "allowed_imports_override": ["json", "math", "socket"],
    },
    {
        "name": "C3 越界写文件被拒绝",
        "source": "def run(inputs, ctx):\n    with open('/tmp/build50_sbx_escape.txt', 'w') as f:\n        f.write('x')\n    return {}\n",
        "inputs": {},
        "expect": "blocked_by_sandbox", "expect_reason_contains": "write_denied",
    },
    {
        "name": "C4 越界读文件被拒绝",
        "source": "def run(inputs, ctx):\n    with open('/etc/hosts', 'r') as f:\n        return {\"n\": len(f.read())}\n",
        "inputs": {},
        "expect": "blocked_by_sandbox", "expect_reason_contains": "read_denied",
    },
    {
        "name": "C5 无限循环超时被杀",
        "source": "def run(inputs, ctx):\n    while True:\n        pass\n",
        "inputs": {},
        "expect": "timeout",
        "resource_override": {"wall_ms": 600},
    },
    {
        "name": "C6 输出超限被拒绝",
        "source": "def run(inputs, ctx):\n    return {\"blob\": \"x\" * 200000}\n",
        "inputs": {},
        "expect": "blocked_by_sandbox", "expect_reason_contains": "output_too_large",
        "resource_override": {"max_output_bytes": 4096},
    },
    {
        "name": "C7 SQLite/数据库访问被拒绝",
        "source": "import sqlite3\n\ndef run(inputs, ctx):\n    sqlite3.connect(':memory:')\n    return {}\n",
        "inputs": {},
        "expect": "blocked_by_sandbox",
        "allowed_imports_override": ["json", "sqlite3"],
    },
    {
        "name": "C8 源码被篡改（SHA256 不符）被拒绝",
        "source": "def run(inputs, ctx):\n    return {\"tampered\": False}\n",
        "inputs": {},
        "expect": "rejected_manifest", "tamper_source": True,
    },
    {
        "name": "C9 危险 import 被静态扫描拒绝",
        "source": "import subprocess\n\ndef run(inputs, ctx):\n    return {}\n",
        "inputs": {},
        "expect": "rejected_manifest",
    },
    {
        "name": "C10 非 D1 确定性等级被拒绝",
        "source": "def run(inputs, ctx):\n    return {}\n",
        "inputs": {},
        "expect": "rejected_manifest", "determinism_override": "D2",
    },
    {
        "name": "C11 引擎版本不兼容被拒绝",
        "source": "def run(inputs, ctx):\n    return {}\n",
        "inputs": {},
        "expect": "rejected_manifest", "engine_override": ">=9.0.0",
    },
]


def _base_manifest(case, src_path, src_sha):
    rp = {"wall_ms": 2000, "cpu_seconds": 2, "memory_mb": 128, "fsize_mb": 1,
          "max_output_bytes": 65536}
    rp.update(case.get("resource_override") or {})
    return {
        "executor_id": "example." + re.sub(r"[^a-z0-9_]+", "_", case["name"].lower())[:40].strip("_"),
        "version": "1.0.0",
        "engine_compat": case.get("engine_override") or ">=1.0.0,<2.0.0",
        "source": os.path.basename(src_path),
        "sha256": src_sha if not case.get("tamper_source") else ("0" * 64),
        "entrypoint": "run",
        "determinism": case.get("determinism_override") or "D1",
        "resource_policy": rp,
        "allowed_imports": case.get("allowed_imports_override") or
                           ["json", "math", "statistics", "decimal", "fractions", "re", "datetime"],
        "input_schema": {},
        "output_schema": {},
    }


def selftest(out_path=None, keep=False):
    root = tempfile.mkdtemp(prefix="build50_sbx_selftest_")
    results = []
    try:
        for idx, case in enumerate(CASES):
            case_dir = os.path.join(root, "case%02d" % (idx + 1))
            os.makedirs(case_dir, exist_ok=True)
            src_path = os.path.join(case_dir, "executor.py")
            with open(src_path, "w", encoding="utf-8") as f:
                f.write(case["source"])
            src_sha = sha256_file(src_path)
            manifest = _base_manifest(case, src_path, src_sha)
            mpath = os.path.join(case_dir, "manifest.json")
            with open(mpath, "w", encoding="utf-8") as f:
                json.dump(manifest, f, ensure_ascii=False, indent=2)
            workdir = os.path.join(root, "work%02d" % (idx + 1))
            record = execute_package(mpath, inputs=case["inputs"], workdir=workdir, keep=keep)
            expect = case["expect"]
            if expect == "rejected_manifest":
                passed = record["status"] == "rejected" and bool(record["errors"])
            else:
                passed = record["status"] == expect
            if passed and case.get("expect_reason_contains"):
                reason = (record.get("runs") or [{}])[0].get("blocked_reason", "") if record.get("runs") else ""
                passed = case["expect_reason_contains"] in str(reason)
            if passed and case.get("expect_deterministic"):
                passed = record.get("deterministic") is True
            reason = ""
            if record.get("runs"):
                reason = record["runs"][0].get("blocked_reason", "")
            elif record.get("errors"):
                reason = "; ".join(record["errors"])
            results.append({
                "case": case["name"], "expect": expect, "passed": passed,
                "record_status": record["status"], "errors": record.get("errors", []),
                "deterministic": record.get("deterministic"),
                "reason": reason,
                "wall_ms": (record.get("runs") or [{}])[0].get("wall_ms"),
                "limits": ((record.get("runs") or [{}])[0].get("payload") or {}).get("limits", {}),
                "env_note": "python=%s" % sys.version.split()[0],
            })
        summary = {
            "meta": {
                "name": "build50 沙箱原型自测",
                "version": "0.1",
                "engine_version": ENGINE_VERSION,
                "sandbox": "python-audit-hook(prototype) + subprocess/rlimit/wall-timeout",
                "boundary": "原型验证隔离思路；生产必须叠加 OS 级隔离（sandbox-exec/seccomp+netns）",
                "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            },
            "total": len(results),
            "passed": sum(1 for r in results if r["passed"]),
            "results": results,
        }
        summary["all_passed"] = summary["passed"] == summary["total"]
        as_status = "unsupported_on_this_platform"
        if any(str(((r.get("limits") or {}).get("RLIMIT_AS")) or "").startswith("applied") for r in results):
            as_status = "applied"
        summary["limitations"] = {
            "rlimit_as": as_status,
            "note": ("RLIMIT_AS 在部分平台不可用（如 macOS 原型实测 ValueError）；"
                     "生产必须用 Linux cgroup/容器内存上限，不能只依赖 Python rlimit。"),
            "audit_hook": "Python audit hook 可被 C 扩展/解释器漏洞绕过；生产必须叠加 OS 级隔离。",
        }
        if out_path:
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(summary, f, ensure_ascii=False, indent=2)
        return summary
    finally:
        if not keep:
            shutil.rmtree(root, ignore_errors=True)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv):
    if "--selftest" in argv:
        out = None
        if "--out" in argv:
            out = argv[argv.index("--out") + 1]
        summary = selftest(out_path=out, keep="--keep" in argv)
        print("=" * 72)
        print("build50 沙箱原型自测：%d/%d PASS  (engine %s)" % (
            summary["passed"], summary["total"], ENGINE_VERSION))
        print("=" * 72)
        for r in summary["results"]:
            mark = "PASS" if r["passed"] else "FAIL"
            extra = r["reason"] or (", ".join(r["errors"]) if r["errors"] else "")
            print("[%s] %-30s status=%-18s %s" % (mark, r["case"], r["record_status"], extra[:90]))
        print("-" * 72)
        print("限制：RLIMIT_AS=%s；audit hook 非安全边界，生产需叠加 OS 隔离。"
              % summary["limitations"]["rlimit_as"])
        print("说明：本原型用 Python audit hook + 子进程 + rlimit + 墙钟超时验证隔离思路；")
        print("生产沙箱必须叠加 OS 级隔离（macOS sandbox-exec / Linux seccomp+netns）。")
        return 0 if summary["all_passed"] else 1

    if "--child" in argv:
        i = argv.index("--child")
        return child_main(argv[i + 1], argv[i + 2], int(argv[i + 3]))

    if "--manifest" in argv:
        mpath = argv[argv.index("--manifest") + 1]
        rec = execute_package(mpath)
        print(json.dumps(rec, ensure_ascii=False, indent=2))
        return 0 if rec["status"] == "ok" else 1

    print(__doc__.strip())
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
