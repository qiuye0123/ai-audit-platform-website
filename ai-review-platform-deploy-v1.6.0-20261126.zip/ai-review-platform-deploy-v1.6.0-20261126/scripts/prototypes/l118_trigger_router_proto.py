#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L118 #20 规则级触发路由原型（0-LLM，只读；不接主链、不改 app/）。

输入
----
D 招采 routed 基准（`/tmp/h1/procurement_routed_benchmark`；缺失时从归档 zip
`docs/qa/artifacts/external_benchmarks_v2_20261123/procurement_routed_benchmark_v2.zip`
解压到 /tmp）：453 条规则（rule_code/rule_family/title/target_doc_type/scope/
trigger_keywords）+ 112 份合成文档（11 份 procurement 无 marker + 101 份其它文类内嵌
`条款核验点XX` marker）+ gold 路由表（**只在评测函数里读，路由函数签名不接收 gold**）。

提出机制
--------
规则级触发路由（rule-level trigger router）：把每条规则的
`title / rule_family / target_doc_type / scope.section_hint / trigger_keywords`
构造成触发特征；对被审文档正文做确定性词面命中与文类判定，逐规则决定是否进入候选清单。
不调用模型、不查产品库、不接收 gold_codes。

被评测臂
--------
A0 `benchmark_ref`   ：复刻 D 基准自身 routed 口径（文类签名 + 同文类 ≥2 触发词）
A1 `content_only`    ：只按内容触发（同文类/异文类都收），用于测跨文类误入
A2 `cohort_gate`     ：文类 cohort 标签（题面给定的真实文类，不含 gold_codes）+ ≥2 触发词
A3 `infer_gate`      ：文档正文推断文类（规则族标题 4-gram 打分，无 gold）+ ≥2 触发词
A4 `anchor_only`     ：候选集只含 15 条内容锚规则（占位规则不参与），A2 口径
A5 `cohort_nomarker` ：A2 口径，但匹配前把正文里的 `条款核验点XX` marker 抹掉
                       （检验基准 101 份非招采文档的 99% 召回是否由文档自报规则身份驱动）

口径（与 L35 对齐）
------------------
recall = Σ|gold∩routed|/Σ|gold|；burden× = Σ|routed|/Σ|gold|；
cross_leak = routed 中 target_doc_type≠文档真实文类 的条数 / |routed|；
门槛：recall≥95% / burden≤2.5× / cross_leak≤5%。
"""
from __future__ import annotations

import hashlib
import json
import math
import pathlib
import re
import sys
import unicodedata
import zipfile

PLATFORM_ROOT = pathlib.Path(__file__).resolve().parents[2]
BENCH_DEFAULT = pathlib.Path("/tmp/h1/procurement_routed_benchmark")
ARCHIVE_ZIP = (PLATFORM_ROOT / "docs/qa/artifacts/external_benchmarks_v2_20261123"
               / "procurement_routed_benchmark_v2.zip")
D_ZIP_SHA = "c034088d1c74b6fb4893691d2713f0b49cdad148fc45c2c894357a46439249c2"

PLACEHOLDER_RE = re.compile(r"^条款核验点")
FAMILY_TO_DOC_TYPE = {
    "A04": "procurement", "C06": "procurement", "F01": "procurement",
    "C08": "procurement", "BX": "bx_exec", "PROCESS": "process_spec",
    "P01": "p01_contract", "CT_STAT": "ct_stat", "CT_TECH": "ct_tech",
    "CT_BUDGET": "ct_budget",
}
DOC_TYPES = ["procurement", "bx_exec", "process_spec", "p01_contract",
             "ct_stat", "ct_tech", "ct_budget"]
TITLE_NOISE_RE = re.compile(r"第\s*\d+\s*项.*$")
TITLE_SPLIT_RE = re.compile(r"[与和、，,/]")
TITLE_GENERIC = ("招采", "条款", "协调", "一致性核查", "响应", "限制")
GATE_RECALL = 0.95
GATE_BURDEN = 2.5
GATE_LEAK = 0.05


# ---------------------------------------------------------------- 基准输入
def ensure_benchmark(root: pathlib.Path = BENCH_DEFAULT) -> pathlib.Path:
    """返回解压后的 D 基准目录（缺失时从归档 zip 解压到 /tmp 并校验 sha256）。"""
    if (root / "rules/rules_453.json").is_file():
        return root
    if not ARCHIVE_ZIP.is_file():
        raise SystemExit("REFUSE: 基准目录缺失且归档 zip 不存在：%s" % ARCHIVE_ZIP)
    import hashlib as _h
    if _h.sha256(ARCHIVE_ZIP.read_bytes()).hexdigest() != D_ZIP_SHA:
        raise SystemExit("REFUSE: 基准归档 zip sha256 与 L35 登记不一致")
    root.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE_ZIP) as z:
        z.extractall(root.parent)
    if not (root / "rules/rules_453.json").is_file():
        raise SystemExit("REFUSE: 解压后未找到 rules_453.json")
    return root


def read_doc_text(path: pathlib.Path) -> str:
    """读 md / xlsx 正文（表格逐单元格拼接；不调模型、不做 OCR）。"""
    if path.suffix.lower() == ".md":
        return path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".xlsx":
        import openpyxl
        wb = openpyxl.load_workbook(str(path), data_only=False)
        chunks = []
        for ws in wb.worksheets:
            chunks.append(ws.title)
            for row in ws.iter_rows(values_only=True):
                for v in row:
                    if v is not None:
                        chunks.append(str(v))
        return "\n".join(chunks)
    return path.read_text(encoding="utf-8", errors="ignore")


def load_benchmark(root: pathlib.Path = BENCH_DEFAULT) -> dict:
    root = ensure_benchmark(root)
    rules = json.loads((root / "rules/rules_453.json").read_text(encoding="utf-8"))["rules"]
    routing = json.loads((root / "rules/rule_doc_type_routing.json").read_text(encoding="utf-8"))
    gold = json.loads((root / "gold/corpus_112_gold.json").read_text(encoding="utf-8"))
    docs = []
    for rec in gold["documents"]:
        p = root / rec["file"]
        docs.append({"doc_id": rec["doc_id"], "file": rec["file"],
                     "doc_type": rec["doc_type"],
                     "is_procurement": bool(rec.get("is_procurement_target")),
                     "text": read_doc_text(p)})
    return {"root": root, "rules": rules, "routing": routing, "docs": docs,
            "gold": {rec["doc_id"]: list(rec["gold_rule_codes"])
                     for rec in gold["documents"]}}


# ---------------------------------------------------------------- 规则特征
def normalize(s: str) -> str:
    """NFKC + 小写 + 去空白（中文匹配不受全半角/空白影响；保留正文字符）。"""
    t = unicodedata.normalize("NFKC", str(s or "")).lower()
    return re.sub(r"\s+", "", t)


def title_keywords(family_title: str) -> list:
    """从规则标题前缀派生辅助触发词（规则名/判据标题 → 特征；不读 gold）。

    例：「招采评审办法与技术需求协调」→ ["评审办法", "技术需求"]；
    用于修复「规则触发词只命中 1/3」时仅靠 trigger_keywords 无法路由的缺口。
    """
    out = []
    for part in TITLE_SPLIT_RE.split(str(family_title or "")):
        t = part.strip()
        for g in TITLE_GENERIC:
            if t.startswith(g) and len(t) > len(g) + 1:
                t = t[len(g):]
            if t.endswith(g) and len(t) > len(g) + 1:
                t = t[:-len(g)]
        t = t.strip()
        if len(t) >= 2 and t not in out:
            out.append(t)
    return out


def rule_features(rule: dict) -> dict:
    """从规则元数据构造触发特征（不读 gold；字段全部来自 rules_453.json）。"""
    kws = [str(x) for x in (rule.get("trigger_keywords") or [])]
    placeholder = [k for k in kws if PLACEHOLDER_RE.match(k)]
    content = [k for k in kws if not PLACEHOLDER_RE.match(k)]
    title = str(rule.get("title") or "")
    family_title = TITLE_NOISE_RE.sub("", title).strip()
    scope = rule.get("scope") if isinstance(rule.get("scope"), dict) else {}
    section = str(scope.get("section_hint") or "")
    target = str(rule.get("target_doc_type") or "")
    return {
        "rule_code": str(rule.get("rule_code") or ""),
        "rule_family": str(rule.get("rule_family") or ""),
        "target_doc_type": target,
        "trigger_keywords": kws,
        "content_keywords": content,
        "placeholder_keywords": placeholder,
        "title": title,
        "family_title": family_title,
        "section_hint": section,
        "title_keywords": title_keywords(family_title),
        "is_anchor_rule": bool(content) and not placeholder,
        "feature_text": " ".join([title, family_title, section] + kws),
    }


def build_features(rules: list) -> list:
    return [rule_features(r) for r in rules]


def family_signatures(features: list) -> dict:
    """文类签名：按 rule_family 聚合标题前缀 token（4-gram 集合），无 gold。

    基准 453 条每族标题前缀一致（如「招采资格审查与废标条款」），可与文档正文做
    4-gram 词面重合打分；不依赖文档自报文类标签。
    """
    sig = {}
    for f in features:
        if not f["target_doc_type"]:
            continue
        prefix = f["family_title"] or f["family_title"]
        base = TITLE_NOISE_RE.sub("", prefix).strip()
        if not base:
            continue
        grams = _grams(base)
        sig.setdefault(f["target_doc_type"], set()).update(grams)
    return sig


def _grams(s: str, n: int = 4) -> set:
    s = normalize(s)
    if len(s) < n:
        return {s} if s else set()
    return {s[i:i + n] for i in range(len(s) - n + 1)}


def infer_doc_type(text: str, sig: dict) -> str:
    """按规则族标题 4-gram 重合度推断文类；同分按 DOC_TYPES 顺序（确定性）。"""
    body = _grams(text[:120000])
    best, best_score = "unknown", 0
    for dt in DOC_TYPES:
        score = len(body & sig.get(dt, set()))
        if score > best_score:
            best, best_score = dt, score
    return best


# ---------------------------------------------------------------- 路由
def _hits(kws: list, text_norm: str) -> int:
    return sum(1 for k in kws if normalize(k) and normalize(k) in text_norm)


def _marker_strip(text: str) -> str:
    """抹掉文档自报规则身份的 `条款核验点XX` marker（只用于 marker 敏感性臂）。"""
    return re.sub(r"条款核验点[A-Za-z0-9_\u4e00-\u9fa5]*", "【marker已抹】", text)


def route_rules(doc_text: str, doc_type: str, features: list, *,
                arm: str = "cohort_gate", sig: dict = None) -> list:
    """规则级触发路由（**不接收 gold_codes**；签名只含正文/文类/规则特征）。

    返回按 rule_code 排序的候选规则码列表。
    """
    if arm not in ("benchmark_ref", "content_only", "cohort_gate", "infer_gate",
                   "anchor_only", "cohort_nomarker", "content_title",
                   "cohort_title", "infer_title"):
        raise ValueError("unknown arm: %s" % arm)
    text = doc_text
    if arm == "cohort_nomarker":
        text = _marker_strip(text)
    text_norm = normalize(text)
    pred_dt = doc_type
    if arm in ("benchmark_ref", "infer_gate", "infer_title"):
        pred_dt = infer_doc_type(text, sig or {})
    routed = []
    for f in features:
        kws = f["trigger_keywords"]
        if not kws:
            continue
        if arm == "anchor_only" and not f["is_anchor_rule"]:
            continue
        if arm == "benchmark_ref":
            # 复刻基准 eval_routed.pure_object_route 口径（同文类 ≥2 触发词；异文类全中）
            hit_n = _hits(kws, text_norm)
            req_n = 2 if len(kws) >= 2 else 1
            if f["target_doc_type"] == pred_dt:
                if hit_n >= req_n:
                    routed.append(f["rule_code"])
            elif len(kws) >= 2 and hit_n == len(kws):
                routed.append(f["rule_code"])
            continue
        if arm == "content_only":
            if _hits(kws, text_norm) >= 2:
                routed.append(f["rule_code"])
            continue
        if arm in ("content_title", "cohort_title", "infer_title"):
            # 规则级触发打分：内容触发词 + 规则标题派生词（标题辅助通道）
            c_hit = _hits(kws, text_norm)
            # 标题辅助通道只对「内容锚规则」生效：占位规则（条款核验点XX + 1 内容词）
            # 的标题是族级模板，若也走标题通道会把整族规则拉进清单（负担爆炸）。
            t_hit = (_hits(f.get("title_keywords") or [], text_norm)
                     if f["is_anchor_rule"] else 0)
            ok = c_hit >= 2 or (c_hit >= 1 and t_hit >= 1)
            if not ok:
                continue
            if arm == "content_title":
                routed.append(f["rule_code"])
            elif f["target_doc_type"] == pred_dt:
                routed.append(f["rule_code"])
            continue
        # cohort_gate / infer_gate / anchor_only / cohort_nomarker：文类门 + ≥2 触发词
        if f["target_doc_type"] == pred_dt and _hits(kws, text_norm) >= 2:
            routed.append(f["rule_code"])
    return sorted(set(routed))


def route_doc(doc: dict, features: list, sig: dict, arm: str) -> dict:
    routed = route_rules(doc["text"], doc["doc_type"], features, arm=arm, sig=sig)
    return {"doc_id": doc["doc_id"], "doc_type": doc["doc_type"],
            "is_procurement": doc["is_procurement"], "routed": routed}


# ---------------------------------------------------------------- 统计
def _cp95(k: int, n: int) -> list:
    if n <= 0:
        return [0.0, 1.0]
    import math as _m
    alpha = 0.05

    def cdf(kk, nn, p):
        return sum(_m.comb(nn, i) * (p ** i) * ((1 - p) ** (nn - i))
                   for i in range(0, kk + 1))

    if k == 0:
        lo = 0.0
    else:
        a, b = 0.0, 1.0
        for _ in range(100):
            mid = (a + b) / 2
            if 1 - cdf(k - 1, n, mid) < alpha / 2:
                a = mid
            else:
                b = mid
        lo = (a + b) / 2
    if k == n:
        hi = 1.0
    else:
        a, b = 0.0, 1.0
        for _ in range(100):
            mid = (a + b) / 2
            if cdf(k, n, mid) > alpha / 2:
                a = mid
            else:
                b = mid
        hi = (a + b) / 2
    return [round(lo, 4), round(hi, 4)]


def _delta_min(n: int) -> float:
    return round(2.80 * 0.5 / (max(n, 1) ** 0.5) * 100, 2)


def _doc_bootstrap(per_doc: list, metric: str, n_boot: int = 2000,
                   seed: int = 20261125) -> dict:
    """按文档有放回 bootstrap（clustered pooled micro 重算 recall/burden）。"""
    import random
    rng = random.Random(seed)
    n = len(per_doc)
    vals = []
    for _ in range(n_boot):
        gold = hit = routed = 0
        for _ in range(n):
            d = per_doc[rng.randrange(n)]
            gold += d["gold_count"]
            hit += d["gold_hit_count"]
            routed += len(d["routed"])
        if gold == 0:
            continue
        vals.append(hit / gold if metric == "recall" else routed / gold)
    vals.sort()
    if not vals:
        return {"point": None, "ci95": None}
    lo = vals[int(0.025 * len(vals))]
    hi = vals[int(0.975 * len(vals)) - 1]
    return {"n_docs": n, "n_boot": n_boot, "seed": seed,
            "point": round(vals[len(vals) // 2], 4),
            "ci95": [round(lo, 4), round(hi, 4)]}


def evaluate_arm(loaded: dict, features: list, sig: dict, arm: str) -> dict:
    """对 112 份文档跑一臂，按 cohort 汇总 recall/burden/cross_leak。"""
    per_doc = []
    for doc in loaded["docs"]:
        gold = set(loaded["gold"].get(doc["doc_id"]) or [])
        routed = set(route_doc(doc, features, sig, arm)["routed"])
        # 跨文类误入：routed 规则的 target_doc_type ≠ 文档真实文类
        target_by_code = {f["rule_code"]: f["target_doc_type"] for f in features}
        cross = {c for c in routed
                 if target_by_code.get(c) and target_by_code[c] != doc["doc_type"]}
        per_doc.append({
            "doc_id": doc["doc_id"], "doc_type": doc["doc_type"],
            "is_procurement": doc["is_procurement"],
            "gold": sorted(gold), "routed": sorted(routed),
            "gold_count": len(gold), "gold_hit_count": len(gold & routed),
            "cross_count": len(cross), "routed_count": len(routed),
        })
    groups = {
        "procurement_11": [d for d in per_doc if d["is_procurement"]],
        "other_101": [d for d in per_doc if not d["is_procurement"]],
        "all_112": per_doc,
    }
    out = {"arm": arm, "by_cohort": {}}
    for gname, rows in groups.items():
        gold = sum(r["gold_count"] for r in rows)
        hit = sum(r["gold_hit_count"] for r in rows)
        routed = sum(r["routed_count"] for r in rows)
        cross = sum(r["cross_count"] for r in rows)
        avg_routed = round(routed / len(rows), 2) if rows else None
        cand_tokens = 0
        tk = {f["rule_code"]: len(f["title"]) + sum(len(k) for k in f["trigger_keywords"])
              for f in features}
        for r in rows:
            cand_tokens += sum(tk.get(c, 0) for c in r["routed"])
        out["by_cohort"][gname] = {
            "n_docs": len(rows), "n_gold": gold,
            "recall": round(hit / gold, 4) if gold else None,
            "recall_cp95": _cp95(hit, gold) if gold else None,
            "hit": hit,
            "routed": routed,
            "burden": round(routed / gold, 4) if gold else None,
            "burden_doc_bootstrap": _doc_bootstrap(rows, "burden"),
            "cross_leak": round(cross / routed, 4) if routed else 0.0,
            "cross_leak_cp95": _cp95(cross, routed) if routed else None,
            "avg_routed_rules_per_doc": avg_routed,
            "avg_candidate_tokens_per_doc": round(cand_tokens / len(rows), 1) if rows else None,
            "delta_min_pp": _delta_min(gold),
        }
        # 三门槛（只在有 gold 的 cohort 上有意义）
        c = out["by_cohort"][gname]
        c["gate"] = {
            "recall_ok": bool(c["recall"] is not None and c["recall"] >= GATE_RECALL),
            "burden_ok": bool(c["burden"] is not None and c["burden"] <= GATE_BURDEN),
            "leak_ok": bool(c["cross_leak"] <= GATE_LEAK),
            "all_pass": bool(c["recall"] is not None and c["recall"] >= GATE_RECALL
                             and c["burden"] <= GATE_BURDEN and c["cross_leak"] <= GATE_LEAK),
        }
    out["per_doc"] = per_doc
    return out


def run_all(loaded: dict = None) -> dict:
    """跑 6 臂 × 3 cohort 全矩阵。"""
    loaded = loaded or load_benchmark()
    features = build_features(loaded["rules"])
    sig = family_signatures(features)
    arms = ["benchmark_ref", "content_only", "cohort_gate", "infer_gate",
            "anchor_only", "cohort_nomarker", "content_title", "cohort_title",
            "infer_title"]
    results = {}
    for arm in arms:
        results[arm] = evaluate_arm(loaded, features, sig, arm)
    # 文类推断自检（无 gold 参与推断；此处只复核推断准确率）
    infer_ok = 0
    for doc in loaded["docs"]:
        if infer_doc_type(doc["text"], sig) == doc["doc_type"]:
            infer_ok += 1
    return {"arms": results, "doc_type_infer_accuracy": round(infer_ok / len(loaded["docs"]), 4),
            "n_docs": len(loaded["docs"]), "n_rules": len(loaded["rules"]),
            "n_anchor_rules": sum(1 for f in features if f["is_anchor_rule"]),
            "n_placeholder_rules": sum(1 for f in features if f["placeholder_keywords"])}


if __name__ == "__main__":
    import json as _json
    res = run_all()
    for arm, r in res["arms"].items():
        print(arm, _json.dumps(r["by_cohort"]["procurement_11"], ensure_ascii=False)[:360])
    print("infer_acc", res["doc_type_infer_accuracy"])
