#!/usr/bin/env python3
"""可选演示数据：扩展工作空间、项目、发现、决策表和本体术语。

不会修改默认 seed；用于演示/联调库。重复执行按名称幂等跳过。
用法：python3 scripts/seed_demo_extra.py [--db PATH]
"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _docx(path: Path, title: str, lines: list):
    from docx import Document
    path.parent.mkdir(parents=True, exist_ok=True)
    d = Document()
    d.add_heading(title, level=1)
    for line in lines:
        d.add_paragraph(line)
    d.save(path)


PROJECTS = [
    ("EXTRA-合同-办公用品", "contract", "采购合同", "2026年度办公用品采购合同",
     ["合同编号：EXTRA-HT-001", "合同金额：人民币 286,000 元", "交付期限：30 日", "质保金比例：5%"],
     [("合同金额与预算一致性", "warning", "合同金额 286,000 元超过年度预算 250,000 元", "合同金额：人民币 286,000 元"),
      ("交付期限明确性", "info", "交付期限为 30 日，未注明起算日", "交付期限：30 日")]),
    ("EXTRA-合同-数据中心维保", "contract", "采购合同", "数据中心基础设施维保服务合同",
     ["合同编号：EXTRA-HT-002", "服务期限：2026-12-01 至 2027-11-30", "服务费：人民币 960,000 元", "SLA：99.9%"],
     [("服务期限与付款节点", "warning", "付款节点未与 99.9% SLA 考核结果挂钩", "SLA：99.9%"),
      ("维保范围完整性", "info", "未明确 UPS 电池更换责任", "数据中心基础设施维保")]),
    ("EXTRA-招标-智慧园区", "bid", "招标文件", "智慧园区二期设备采购招标文件",
     ["项目编号：EXTRA-ZB-003", "最高限价：人民币 8,600,000 元", "投标有效期：90 日历天", "保证金：人民币 80,000 元"],
     [("最高限价与预算", "critical", "最高限价 860 万超过批复预算 800 万", "最高限价：人民币 8,600,000 元"),
      ("投标有效期", "info", "投标有效期 90 日历天，满足要求", "投标有效期：90 日历天")]),
    ("EXTRA-食品-原料检验", "food", "食品工艺书", "华东食品原料入场检验记录",
     ["批次：EXTRA-FOOD-004", "中心温度：78℃", "冷藏库温度：6℃", "消毒液浓度：120ppm"],
     [("原料中心温度", "critical", "加热中心温度 78℃ 低于 85℃", "中心温度：78℃"),
      ("冷藏温度", "warning", "冷藏库温度 6℃ 接近上限", "冷藏库温度：6℃")]),
    ("EXTRA-工程-园区施工", "engineering", "通用文件", "园区道路改造工程施工合同",
     ["合同编号：EXTRA-GC-005", "合同金额：人民币 3,200,000 元", "工期：120 日历天", "质保期：2 年"],
     [("工期与开工令", "warning", "合同工期 120 日，但未附开工令", "工期：120 日历天"),
      ("质保期", "info", "质保期 2 年，满足最低要求", "质保期：2 年")]),
    ("EXTRA-软件-源代码保密", "contract", "通用文件", "云川软件源代码保密协议",
     ["协议编号：EXTRA-NDA-006", "保密期限：5 年", "违约金：人民币 500,000 元", "适用法律：中华人民共和国法律"],
     [("保密期限", "info", "保密期限 5 年", "保密期限：5 年"),
      ("违约责任", "warning", "违约金未约定计算方式", "违约金：人民币 500,000 元")]),
    ("EXTRA-验收-设备", "general", "通用文件", "设备采购到货验收报告",
     ["验收单号：EXTRA-YS-007", "到货数量：12 台", "合格数量：11 台", "不合格数量：1 台"],
     [("到货与合格数量", "warning", "12 台到货仅 11 台合格，缺少不合格处理记录", "合格数量：11 台"),
      ("验收签字", "info", "验收单已有双方签字", "验收单号：EXTRA-YS-007")]),
    ("EXTRA-申报-许可", "application", "通用文件", "食品生产许可申报材料",
     ["申请编号：EXTRA-SP-008", "产品类别：速冻食品", "生产场所：苏州一厂", "食品安全管理员：已配置"],
     [("申报材料完整性", "warning", "缺少生产设备布局图", "生产场所：苏州一厂"),
      ("食品安全管理员", "info", "已配置食品安全管理员", "食品安全管理员：已配置")]),
]

SPACES = [
    ("演示 · 合同审核", ["采购合同", "通用文件"]),
    ("演示 · 招标审核", ["招标文件", "投标文件"]),
    ("演示 · 食品工艺", ["食品工艺书"]),
]

TABLES = [
    ("DEMO-MULTI-CONTRACT", "合同多条件转人工",
     [{"when": [{"metric": "合同金额", "op": ">=", "value": 1000000},
                {"metric": "风险等级", "op": "=", "value": "高"}],
       "severity": "critical", "message": "大额高风险合同需人工复核",
       "suggestion": "核对预算、授权和担保材料"},
      {"when": [{"metric": "交付期限", "op": ">", "value": 90},
                {"metric": "合同金额", "op": ">=", "value": 500000}],
       "severity": "warning", "message": "长交付期且金额较大"}],
     "first"),
    ("DEMO-MULTI-SUPPLIER", "供应商组合风险",
     [{"when": [{"any": [{"metric": "供应商等级", "op": "=", "value": "C"},
                         {"metric": "成立年限", "op": "<", "value": 1}]}],
       "severity": "warning", "message": "供应商资质或成立年限不足"}],
     "collect"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="")
    args = ap.parse_args()
    if args.db:
        os.environ["RULEPROOF_DB"] = args.db
    from app import db
    from app import repositories as R
    from app.services import ctx, workspaces, project, decision_table, ontology_workspace
    from app.services import tenants

    db.init_db()
    docs = ROOT / "seed" / "demo_extra_docs"
    made_projects = made_findings = 0
    with ctx.scoped("t-default", "ws-default"):
        for name, types in SPACES:
            existing = next((w for w in workspaces.list_for("user-admin", "t-default") if w.get("name") == name), None)
            if existing:
                workspaces.save_settings(existing["id"], {"doc_types": types})
            else:
                workspaces.create(name, "user-admin", "t-default", {"doc_types": types, "visibility": "tenant"})
        spaces = {w["name"]: w["id"] for w in workspaces.list_for("user-admin", "t-default")}
        for i, (pname, atype, dtype, title, lines, findings) in enumerate(PROJECTS, 1):
            if R.cases.list("name=?", (pname,)):
                continue
            space_name = ("演示 · 合同审核" if dtype == "采购合同" else
                          "演示 · 招标审核" if dtype in ("招标文件", "投标文件") else
                          "演示 · 食品工艺" if dtype == "食品工艺书" else "通用空间")
            wsid = spaces.get(space_name) or "ws-default"
            path = docs / f"extra_{i:02d}.docx"
            _docx(path, title, lines)
            with ctx.scoped("t-default", wsid):
                cid = project.create(pname, user="user-reviewer", audit_type=atype,
                                     document_type=dtype)
                project.add_document(cid, str(path), path.name)
                R.cases.update(cid, status="completed", progress=100, last_audit_at=db.now())
                for j, (ftitle, sev, detail, quote) in enumerate(findings, 1):
                    fid = f"fnd-extra-{i:02d}-{j:02d}"
                    did = R.cases.documents(cid)[0]["id"]
                    aid = f"anc-extra-{i:02d}-{j:02d}"
                    R.anchors.insert(id=aid, document_id=did, sheet="", row=None, col="",
                                     locator=f"第 {j + 1} 页", quote=quote,
                                     hash=hashlib.sha256(quote.encode()).hexdigest())
                    R.findings.insert(id=fid, case_id=cid, rule_id=f"EXTRA-{i:02d}-{j:02d}",
                                      rule_version="v1", severity=sev, certainty="probable",
                                      confidence=0.86, status="pending", title=ftitle,
                                      summary=detail, suggestion="请结合原始材料复核",
                                      grade="R2", engine="demo_extra", run_id=f"run-extra-{i:02d}",
                                      point_id="", source_code="", tenant_id="t-default",
                                      workspace_id=wsid, state="不满足")
                    R.evidences.insert(id=f"ev-extra-{i:02d}-{j:02d}", finding_id=fid,
                                       document_id=did, anchor_id=aid, excerpt=quote,
                                       label="扩展演示证据")
                    made_findings += 1
                made_projects += 1
        with ctx.scoped("t-default", "ws-default"):
            for code, name, rules, policy in TABLES:
                if not decision_table.get(code):
                    r = decision_table.create(code, name, rules, policy, by="seed-extra")
                    if not r.get("error"):
                        decision_table.publish(code, by="seed-extra")
            for term, aliases, evidence in [
                ("合同金额", ["合同总价", "合同总额"], "合同审核演示：合同总价/总额均指合同金额"),
                ("供应商等级", ["供应商评级"], "供应商管理演示：评级字段统一为供应商等级"),
            ]:
                ontology_workspace.add_manual(term, aliases, "金额" if "金额" in term else "主体",
                                              "seed-extra", evidence)
    # 平台演示租户（需要平台账号权限的数据库级 seed，不经过 UI）
    for name, phone in [("演示 · 华东供应链", "13900002001"), ("演示 · 星海数据", "13900002002")]:
        if not any(t.get("name") == name for t in tenants.list_tenants()):
            tenants.create_tenant(code="DEMO-EXTRA-" + str(abs(hash(name)) % 100000),
                                  name=name, admin_phone=phone, admin_pwd="Demo@123456",
                                  actor="seed-extra", edition="trial", expires_at="2027-06-30",
                                  admin_name="演示管理员")
    print(json.dumps({"ok": True, "projects": made_projects, "findings": made_findings}, ensure_ascii=False))


if __name__ == "__main__":
    main()
