#!/usr/bin/env python3
"""把 docs/handbook Markdown 组装为 Word 文档（产品/测试/架构/合集）。"""
import os
import re
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, Cm, RGBColor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, "docs", "handbook")
OUT = os.path.join(DOCS, "out")
os.makedirs(OUT, exist_ok=True)

SECTIONS = {
    "01-产品总览.md": "产品总览",
    "02-角色权限与四端.md": "角色权限与四端",
    "03-审核主链路.md": "审核主链路",
    "04-规则引擎与决策表.md": "规则引擎与决策表",
    "05-智能体Runtime.md": "智能体 Runtime",
    "06-本体建模.md": "本体建模",
    "07-JEV与规则进化.md": "JEV 与规则进化",
    "08-规则挖掘与消息中心.md": "规则挖掘与消息中心",
    "09-开放平台与CLI.md": "开放平台与 CLI",
    "10-测试与验收.md": "测试与验收",
    "11-架构设计.md": "架构设计",
    "12-数据模型与API.md": "数据模型与 API",
    "13-部署运维与备份.md": "部署运维与备份",
    "14-边界技术债与路线图.md": "边界、技术债与路线图",
    "15-测试用例矩阵.md": "测试用例矩阵",
    "16-故障排查与FAQ.md": "故障排查与 FAQ",
    "17-验收清单.md": "验收清单",
    "18-验收报告_20261114.md": "验收报告（2026-11-14）",
    "19-全局联动矩阵.md": "全局联动矩阵",
    "20-UI按钮自动化点击报告.md": "UI 按钮自动化点击报告",
    "21-数据集多空间回归报告.md": "数据集多空间回归报告",
    "22-真实模型盲测报告.md": "真实模型盲测报告",
    "23-提示词注入在线测试.md": "提示词注入在线测试",
    "24-主链路根因与真实路径.md": "主链路根因与真实路径",
    "25-系统性根因与改造路线.md": "系统性根因与改造路线",
    "26-最终交付总结与自查.md": "最终交付总结与自查",
    "27-两套标注数据测试与根因.md": "两套标注数据测试与根因",
    "28-规则挖掘审核进化三大块复核.md": "规则挖掘审核进化三大块复核",
    "29-分类编码与规则映射复核.md": "分类编码与规则映射复核",
    "30-真实业务情景执行.md": "真实业务情景执行",
    "31-Qoder验收报告复核.md": "Qoder验收报告复核",
    "32-D-H测试结果与根因.md": "D-H测试结果与根因",
    "33-规则三入口一致性.md": "规则三入口一致性",
    "34-异步任务生命周期.md": "异步任务生命周期",
    "35-测试数据集总览.md": "测试数据集总览",
    "36-食品抽检40.md": "食品抽检40",
    "37-食品抽检35期点位基准.md": "食品抽检35期点位基准",
    "38-语义D4真实模型阻塞.md": "语义D4真实模型阻塞",
    "39-语义D4真实模型回归.md": "语义D4真实模型回归",
    "40-pipeline合并兼容契约.md": "pipeline合并兼容契约",
    "41-legacy兼容unknown.md": "legacy兼容unknown",
    "42-legacy-unknown模式修复.md": "legacy-unknown模式修复",
    "43-术语本体接入.md": "术语本体接入",
    "CHANGELOG.md": "变更记录",
}

GROUPS = {
    "产品文档": ["01-产品总览.md", "02-角色权限与四端.md", "03-审核主链路.md",
              "04-规则引擎与决策表.md", "05-智能体Runtime.md", "06-本体建模.md",
              "07-JEV与规则进化.md", "08-规则挖掘与消息中心.md", "09-开放平台与CLI.md"],
    "测试文档": ["10-测试与验收.md", "15-测试用例矩阵.md", "17-验收清单.md", "18-验收报告_20261114.md", "19-全局联动矩阵.md", "20-UI按钮自动化点击报告.md", "21-数据集多空间回归报告.md", "22-真实模型盲测报告.md", "23-提示词注入在线测试.md", "24-主链路根因与真实路径.md", "25-系统性根因与改造路线.md", "26-最终交付总结与自查.md", "27-两套标注数据测试与根因.md", "28-规则挖掘审核进化三大块复核.md", "29-分类编码与规则映射复核.md", "30-真实业务情景执行.md", "31-Qoder验收报告复核.md", "32-D-H测试结果与根因.md", "33-规则三入口一致性.md", "34-异步任务生命周期.md", "35-测试数据集总览.md", "36-食品抽检40.md", "37-食品抽检35期点位基准.md", "38-语义D4真实模型阻塞.md", "39-语义D4真实模型回归.md", "40-pipeline合并兼容契约.md", "41-legacy兼容unknown.md", "42-legacy-unknown模式修复.md", "43-术语本体接入.md"],
    "架构文档": ["11-架构设计.md", "12-数据模型与API.md", "13-部署运维与备份.md",
              "14-边界技术债与路线图.md", "16-故障排查与FAQ.md"],
}


def font(run, size=10.5, bold=False, mono=False):
    run.font.name = "Consolas" if mono else "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold


def setup(doc, title):
    sec = doc.sections[0]
    sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.2); sec.right_margin = Cm(2.2)
    st = doc.styles["Normal"]
    st.font.name = "Microsoft YaHei"; st.font.size = Pt(10.5)
    st._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("AI 审核平台"); font(r, 26, True)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(title); font(r, 20, True)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("v1.3.6 · 2026-11-14"); font(r, 11)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("产品 / 测试 / 架构 / 运维 / 验收")
    r.font.size = Pt(11); r.font.color.rgb = RGBColor(0x64, 0x6A, 0x73)
    doc.add_page_break()


def add_md(doc, filename):
    path = os.path.join(DOCS, filename)
    lines = open(path, encoding="utf-8").read().splitlines()
    in_code = False; code = []; table = []
    def flush_table():
        nonlocal table
        if not table:
            return
        rows = [[c.strip() for c in row.strip().strip("|").split("|")] for row in table
                if not re.match(r"^\s*\|?[\s:\-|]+\|?\s*$", row)]
        if rows:
            cols = max(len(x) for x in rows)
            t = doc.add_table(rows=0, cols=cols); t.style = "Table Grid"
            for row in rows[:80]:
                cells = t.add_row().cells
                for i in range(cols):
                    cells[i].text = row[i] if i < len(row) else ""
                    for p in cells[i].paragraphs:
                        for r in p.runs: font(r, 9)
        table = []
    def flush_code():
        nonlocal code
        if not code: return
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.5)
        r = p.add_run("\n".join(code)); font(r, 9, mono=True)
        p.paragraph_format.space_after = Pt(6)
        code = []
    for raw in lines:
        line = raw.rstrip()
        if line.startswith("```"):
            if in_code:
                flush_code(); in_code = False
            else:
                flush_table(); in_code = True
            continue
        if in_code:
            code.append(line); continue
        if line.startswith("|") and line.endswith("|"):
            table.append(line); continue
        else:
            flush_table()
        if not line.strip():
            continue
        if line.startswith("#### "):
            p = doc.add_heading(line[5:].strip(), level=4)
        elif line.startswith("### "):
            p = doc.add_heading(line[4:].strip(), level=3)
        elif line.startswith("## "):
            p = doc.add_heading(line[3:].strip(), level=2)
        elif line.startswith("# "):
            p = doc.add_heading(line[2:].strip(), level=1)
        elif line.startswith("- [ ] "):
            p = doc.add_paragraph(style="List Bullet"); r=p.add_run("☐ " + line[6:].strip()); font(r)
        elif line.startswith("- "):
            p = doc.add_paragraph(style="List Bullet"); r=p.add_run(re.sub(r"^\-\s+", "", line)); font(r)
        elif re.match(r"^\d+\.\s", line):
            p = doc.add_paragraph(style="List Number"); r=p.add_run(re.sub(r"^\d+\.\s+", "", line)); font(r)
        elif line.startswith("> "):
            p = doc.add_paragraph(); r=p.add_run(line[2:]); font(r, 10.5, False)
            p.paragraph_format.left_indent = Cm(0.6)
            r.font.color.rgb = RGBColor(0x64, 0x6A, 0x73)
        else:
            txt = re.sub(r"\*\*(.*?)\*\*", r"\1", line)
            txt = re.sub(r"`([^`]*)`", r"\1", txt)
            p = doc.add_paragraph(); r=p.add_run(txt); font(r)
    flush_table(); flush_code()


def build(name, files):
    doc = Document(); setup(doc, name)
    for f in files:
        if f not in SECTIONS: continue
        doc.add_heading(SECTIONS[f], level=1)
        add_md(doc, f)
        doc.add_page_break()
    out = os.path.join(OUT, f"AI审核平台_{name}_v1.3.6.docx")
    doc.save(out)
    print(out)


if __name__ == "__main__":
    build("产品文档", GROUPS["产品文档"])
    build("测试文档", GROUPS["测试文档"])
    build("架构文档", GROUPS["架构文档"])
    build("完整手册", list(GROUPS["产品文档"]) + list(GROUPS["测试文档"]) + list(GROUPS["架构文档"])
          + ["CHANGELOG.md"])
