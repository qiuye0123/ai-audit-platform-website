import fs from 'fs';
const dir = process.argv[2], port = process.argv[3];
const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
const page = list.find(x => x.type === 'page') || list[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 1; const pend = new Map();
ws.addEventListener('message', e => { const m = JSON.parse(e.data);
  if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id);
    m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } });
await new Promise(r => ws.addEventListener('open', r, { once: true }));
const send = (m, p = {}) => { const i = id++; ws.send(JSON.stringify({ id: i, method: m, params: p }));
  return new Promise((res, rej) => pend.set(i, { resolve: res, reject: rej })); };
const ev = async e => (await send('Runtime.evaluate', { expression: e, returnByValue: true })).result?.value;
const wait = ms => new Promise(r => setTimeout(r, ms));
await send('Page.enable'); await send('Runtime.enable');
const files = fs.readdirSync(dir + '/html').filter(f => f.endsWith('.html')).sort();
const report = [];
for (const f of files) {
  const name = f.replace(/\.html$/, '');
  await send('Emulation.setDeviceMetricsOverride', { width: 2400, height: 1600, deviceScaleFactor: 2, mobile: false });
  await send('Page.navigate', { url: `file://${dir}/html/${f}` });
  for (let i = 0; i < 40; i++) {
    await wait(300);
    const has = await ev(`(()=>{const s=document.querySelector('svg');const m=(document.querySelector('#marker')||{}).dataset?.name||'';return !!s && m===name;})()`);
    if (has) break;
  }
  await wait(400);
  const info = await ev(`(()=>{const s=document.querySelector('svg');
    if(!s) return {ok:false,why:'no svg'};
    const t=(document.body.innerText||'');
    if(/Syntax error|Parse error/i.test(t)) return {ok:false,why:'syntax'};
    const r=s.getBoundingClientRect();
    const nodes=[...s.querySelectorAll('g.node')].map(n=>{const b=n.getBoundingClientRect();
      return {x:b.x,y:b.y,w:b.width,h:b.height};}).filter(b=>b.w>4&&b.h>4);
    const inside=(a,b)=>a.x>=b.x-1&&a.y>=b.y-1&&a.x+a.w<=b.x+b.w+1&&a.y+a.h<=b.y+b.h+1;
    let over=0;
    for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++){const a=nodes[i],b=nodes[j];
      if(inside(a,b)||inside(b,a)) continue;
      const ix=Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x));
      const iy=Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y));
      if(ix>5&&iy>5) over++;}
    return {ok:true,w:Math.ceil(r.width),h:Math.ceil(r.height),nodes:nodes.length,overlaps:over};})()`);
  if (!info || !info.ok) { console.log('BAD', name, info && info.why); report.push({name, ok:false}); continue; }
  const w = Math.min(info.w + 80, 3000), h = Math.min(info.h + 80, 4000);
  await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 2, mobile: false });
  await wait(500);
  const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
  fs.writeFileSync(`${dir}/png/${name}.png`, Buffer.from(shot.data, 'base64'));
  console.log('OK ', name, w + 'x' + h, 'nodes=' + info.nodes, 'overlaps=' + info.overlaps);
  report.push({ name, ok: true, w, h, nodes: info.nodes, overlaps: info.overlaps });
}
fs.writeFileSync(dir + '/render_report.json', JSON.stringify(report, null, 1));
const ov = report.filter(r => r.overlaps > 0);
console.log('OVERLAP_GROUPS', ov.length, JSON.stringify(ov.map(o => [o.name, o.overlaps])));
process.exit(0);
