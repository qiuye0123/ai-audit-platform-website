import html, sys
from pathlib import Path
TPL = """<!doctype html><html><head><meta charset="utf-8">
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<style>
 body{{margin:24px;background:#fff;font-family:-apple-system,"PingFang SC",sans-serif}}
 .mermaid{{font-size:13px}}
</style></head><body>
<div id="marker" data-name="{name}"></div>
<pre class="mermaid">{code}</pre>
<script>
mermaid.initialize({{startOnLoad:false,theme:'default',
  flowchart:{{htmlLabels:true,nodeSpacing:60,rankSpacing:80,curve:'basis',padding:12}},
  sequence:{{actorMargin:60,messageMargin:30,boxMargin:10}},
  themeVariables:{{fontSize:'13px'}}}});
mermaid.run({{querySelector:'.mermaid'}});
</script></body></html>"""
for f in sorted(Path(".").glob("*.mmd")):
    code = html.escape(f.read_text(encoding="utf-8"))
    Path("html", f"{f.stem}.html").write_text(TPL.format(code=code, name=f.stem), encoding="utf-8")
print("html regenerated")
