# 架构图渲染工具链

1. 生成 HTML：
   `python3 scripts/engineering/gen_diagram_html.py`（在 docs/architecture/diagrams 下执行）
2. 启动 Chrome：`--headless=new --remote-debugging-port=9419`
3. 渲染 + 校验 + 重叠检测：
   `node scripts/engineering/render_diagrams.mjs <diagrams 绝对路径> 9419`

判定标准（缺一不可）：
- 页面出现 `Syntax error` → 失败
- SVG < 200×80 → 失败
- marker 名称与文件名不一致 → 失败
- 真实节点重叠（排除包含关系）> 0 → 记录
输出：`png/*.png` 与 `render_report.json`
