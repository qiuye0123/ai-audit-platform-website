# -*- coding: utf-8 -*-
"""把未完成模块总表 Markdown 转为可读 DOCX（横向、表格宽度受控）。"""
import re, sys
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH

src = Path(sys.argv[1]); out = Path(sys.argv[2])
lines = src.read_text(encoding="utf-8").splitlines()
doc = Document()
sec = doc.sections[0]
sec.orientation = WD_ORIENT.LANDSCAPE
sec.page_width, sec.page_height = sec.page_height, sec.page_width
for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
    setattr(sec, m, Cm(1.6))
style = doc.styles["Normal"]
style.font.name = "微软雅黑"; style.font.size = Pt(9)
style._element.rPr.rFonts.set("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia", "微软雅黑")

def cjk(run):
    run.font.name = "微软雅黑"
    run._element.rPr.rFonts.set("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia", "微软雅黑")

def clean(text):
    return str(text).replace("**", "").replace("`", "").replace(">", "", 1).strip()

def add_para(text, bold=False, size=9, color=None):
    text = clean(text)
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold; r.font.size = Pt(size); cjk(r)
    if color: r.font.color.rgb = RGBColor(*color)
    p.paragraph_format.space_after = Pt(4)
    return p

def add_table(rows):
    cols = len(rows[0])
    t = doc.add_table(rows=0, cols=cols)
    t.style = "Light Grid Accent 1"
    t.autofit = False
    widths = [1.0, 3.2, 1.6, 7.2, 5.2, 5.0][:cols]
    if cols == 5:
        widths = [0.8, 2.4, 2.0, 7.2, 5.2]
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, text in enumerate(row):
            cells[i].width = Cm(widths[i] if i < len(widths) else 2.5)
            p = cells[i].paragraphs[0]
            r = p.add_run(clean(text)); r.font.size = Pt(8); r.bold = (ri == 0); cjk(r)
            p.paragraph_format.space_after = Pt(1)

i = 0
while i < len(lines):
    line = lines[i].rstrip()
    if not line:
        i += 1; continue
    if line.startswith("# "):
        p = doc.add_paragraph(); r = p.add_run(clean(line[2:])); r.bold = True; r.font.size = Pt(18); cjk(r)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif line.startswith("## "):
        p = doc.add_paragraph(); r = p.add_run(clean(line[3:])); r.bold = True; r.font.size = Pt(13); cjk(r)
        p.paragraph_format.space_before = Pt(10)
    elif line.startswith("### "):
        p = doc.add_paragraph(); r = p.add_run(clean(line[4:])); r.bold = True; r.font.size = Pt(11); cjk(r)
    elif line.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            raw = lines[i].strip().strip("|")
            cells = [c.strip() for c in raw.split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c or "-") for c in cells):
                rows.append(cells)
            i += 1
        if rows:
            add_table(rows)
        continue
    elif line.startswith("> "):
        add_para(clean(line[2:]), size=9, color=(0x55, 0x5B, 0x66))
    elif line.startswith("```"):
        code = []
        i += 1
        while i < len(lines) and not lines[i].startswith("```"):
            code.append(lines[i]); i += 1
        p = doc.add_paragraph()
        r = p.add_run("\n".join(code)); r.font.name = "Consolas"; r.font.size = Pt(8)
        p.paragraph_format.left_indent = Cm(0.6)
    elif re.match(r"^\d+\.\s", line) or line.startswith("- "):
        _txt = clean(line[2:] if line.startswith("- ") else re.sub(r"^\d+\.\s*", "", line))
        p = doc.add_paragraph(_txt, style="List Bullet" if line.startswith("- ") else "List Number")
        p.paragraph_format.space_after = Pt(1)
        for r in p.runs: cjk(r); r.font.size = Pt(9)
    else:
        add_para(clean(line))
    i += 1

# footer
footer = sec.footer.paragraphs[0]
footer.text = "AI 审核平台 · 未完成模块总表 · 2026-11-16"
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
for r in footer.runs: cjk(r); r.font.size = Pt(8); r.font.color.rgb = RGBColor(0x8F, 0x95, 0x9E)
doc.save(out)
print("saved", out, "tables", len(doc.tables))
