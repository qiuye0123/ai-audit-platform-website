#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# scripts/ops/backup_restore_drill.sh — 备份加密 + 恢复演练（T-196 Phase A 新增）
#
# 演练链路（全程只碰 /tmp 临时库；产品库只做只读快照复制）：
#   演练源库 → 在线写入压力（备份期间持续写）
#   → sqlite 在线备份（rp db backup：backup API + integrity_check）
#   → openssl 加密（aes-256-cbc + pbkdf2）→ 解密 → sha256 回环一致
#   → 破坏目标库 → rp db restore（含 safety backup）→ 行数/内容指纹/integrity_check 一致
#
# 铁律 6：脚本第一段断言 RULEPROOF_DB 必须指向 /tmp 下的临时库，否则拒绝运行。
# 产品库（platform/data/ruleproof.db）只读：运行前后 sha256 + 大小必须一致。
#
# 关于 sha256 的两个口径（如实说明，避免“假一致”）：
#   · 备份文件 sha256：加密→解密回环后必须与备份文件 sha256 完全一致（本脚本断言）；
#   · 恢复后的库文件 sha256：SQLite backup API 会重写页/空闲页，文件级 sha 不保证与备份相同，
#     因此恢复正确性用「行数 + 全表内容指纹 + integrity_check」校验（本脚本断言）。
#
# 用法：
#   bash scripts/ops/backup_restore_drill.sh                 # 默认：产品库只读快照做演练源
#   RULEPROOF_DB=/tmp/xxx/my.db bash scripts/ops/backup_restore_drill.sh   # 指定 /tmp 库
#   bash scripts/ops/backup_restore_drill.sh --out /tmp/eng_audit/x.json --skip-live-writes
#
# 依赖：bash（3.2+）/ shasum / openssl（无 openssl 时加密步骤如实标 SKIP/NOT TESTED）
# 退出码：0=全部 PASS；1=有 FAIL；2=环境/前置不满足（不伪造 PASS）
set -euo pipefail

# ---------------------------------------------------------------- 铁律 6（第一段）
_EXPLICIT_DB="${RULEPROOF_DB:-}"
_DRILL_DB="${RULEPROOF_DB:-/tmp/eng_audit/backup_drill/source.db}"
case "$_DRILL_DB" in
  /tmp/*|/private/tmp/*|/private/var/folders/*|/var/folders/*) : ;;
  *)
    echo "拒绝运行：RULEPROOF_DB 指向非临时库（${_DRILL_DB}）。" >&2
    echo "本演练只允许 /tmp 下的库；产品库只做只读快照复制。" >&2
    exit 2
    ;;
esac
export RULEPROOF_DB="$_DRILL_DB"
export RULEPROOF_PASSWORD_ENFORCE="${RULEPROOF_PASSWORD_ENFORCE:-0}"
export RULEPROOF_LLM_ENABLED=0
export RULEPROOF_TEST_AUTOLOGIN=0

PLATFORM_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
PRODUCT_DB="$PLATFORM_DIR/data/ruleproof.db"
OUT_JSON="/tmp/eng_audit/backup_restore_drill.json"
RUN_ID="$(date '+%Y%m%d-%H%M%S')"
WORK="/tmp/eng_audit/backup_drill_$RUN_ID"
LIVE_WRITES=1
_OUT_NEXT=0
for arg in "$@"; do
  case "$arg" in
    --out) _OUT_NEXT=1 ;;
    --skip-live-writes) LIVE_WRITES=0 ;;
    --help|-h) sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)
      if [ "${_OUT_NEXT}" = "1" ]; then OUT_JSON="$arg"; _OUT_NEXT=0
      else echo "未知参数：${arg}（--help 查看用法）" >&2; exit 2; fi ;;
  esac
done
mkdir -p "$WORK" "$(dirname "$OUT_JSON")" /tmp/eng_audit

PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
[ -x "$PY" ] || PY="$(command -v python3)"
RP="$PLATFORM_DIR/rp"
SRC="$WORK/source.db"
BACKUP="$WORK/backup-live.db"
ENC="$WORK/backup-live.db.enc"
DEC="$WORK/backup-live.db.dec"
TARGET="$WORK/target.db"
PASS=0; FAIL=0; SKIP=0; FAILED_NAMES=""
HAS_OPENSSL=0; command -v openssl >/dev/null 2>&1 && HAS_OPENSSL=1

say() { printf '%s\n' "$*"; }
check() {  # check <name> <0|1> <detail>
  local name="$1" ok="$2" detail="${3:-}"
  if [ "$ok" = "0" ]; then
    PASS=$((PASS+1)); say "  [PASS] ${name}${detail:+ — $detail}"
  else
    FAIL=$((FAIL+1)); FAILED_NAMES="$FAILED_NAMES$name; "
    say "  [FAIL] ${name} — $detail"
  fi
}
skip() { SKIP=$((SKIP+1)); say "  [SKIP] $1 — $2"; }
sha() { shasum -a 256 "$1" | cut -d' ' -f1; }
now_ms() { "$PY" -c 'import time;print(int(time.time()*1000))'; }
fsize() { stat -f '%z' "$1" 2>/dev/null || stat -c '%s' "$1"; }

rowcounts() {  # rowcounts <db> <out.json>
  "$PY" - "$1" "$2" <<'PYEOF'
import json, sqlite3, sys
src, out = sys.argv[1], sys.argv[2]
tables = ["user", "role", "user_role", "rule", "rule_version", "audit_case",
          "document", "finding", "audit_log", "notification", "open_app"]
res = {}
con = sqlite3.connect(f"file:{src}?mode=ro", uri=True, timeout=10)
try:
    for t in tables:
        try:
            res[t] = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error as e:
            res[t] = f"ERR:{type(e).__name__}"
finally:
    con.close()
open(out, "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False))
PYEOF
}

fingerprint() {  # fingerprint <db> <out.txt>：全表内容指纹（排序后 JSON → sha256）
  "$PY" - "$1" "$2" <<'PYEOF'
import hashlib, json, sqlite3, sys
src, out = sys.argv[1], sys.argv[2]
tables = ["user", "role", "user_role", "rule", "rule_version", "audit_case",
          "document", "finding", "audit_log", "notification", "open_app"]
h = hashlib.sha256()
con = sqlite3.connect(f"file:{src}?mode=ro", uri=True, timeout=10)
try:
    for t in tables:
        h.update(("##" + t + "\n").encode())
        try:
            cur = con.execute(f'SELECT * FROM "{t}" ORDER BY 1')
            for row in cur:
                h.update(json.dumps(["" if v is None else str(v) for v in row],
                                    ensure_ascii=False, sort_keys=False).encode())
                h.update(b"\n")
        except sqlite3.Error as e:
            h.update(f"ERR:{type(e).__name__}".encode())
finally:
    con.close()
open(out, "w", encoding="utf-8").write(h.hexdigest() + "\n")
PYEOF
}

integrity() {  # integrity <db> → integrity_check 结果
  "$PY" - "$1" <<'PYEOF'
import sqlite3, sys
con = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro&immutable=1", uri=True)
try:
    print(con.execute("PRAGMA integrity_check").fetchone()[0])
finally:
    con.close()
PYEOF
}

say "== 备份加密 + 恢复演练（T-196） =="
say "工作目录：$WORK"

# ---------------- 准备演练源（产品库只读快照 / 显式 /tmp 库 / rp init） ----------------
PROD_SHA_BEFORE=""; PROD_BYTES_BEFORE=""
if [ -f "$PRODUCT_DB" ]; then
  PROD_SHA_BEFORE="$(sha "$PRODUCT_DB")"
  PROD_BYTES_BEFORE="$(fsize "$PRODUCT_DB")"
  say "产品库（只读校验）：$PRODUCT_DB sha256=${PROD_SHA_BEFORE}"
fi
if [ -n "$_EXPLICIT_DB" ] && [ -f "$_EXPLICIT_DB" ]; then
  say "显式演练源：${_EXPLICIT_DB}（只读复制）"
  cp -p "$_EXPLICIT_DB" "$SRC"
elif [ -f "$PRODUCT_DB" ]; then
  say "未指定 RULEPROOF_DB：使用产品库只读快照作为演练源（不写产品库）"
  cp -p "$PRODUCT_DB" "$SRC"
else
  say "产品库不存在：改用 rp init 在 /tmp 生成演练库"
  "$RP" --db "$SRC" --user user-admin init >/dev/null 2>&1 || {
    echo "rp init 失败，无法准备演练库" >&2; exit 2; }
fi
SRC_SHA="$(sha "$SRC")"
rowcounts "$SRC" "$WORK/counts_src.json"
check "演练源库可打开且行数可读" "$([ -s "$WORK/counts_src.json" ] && echo 0 || echo 1)" "sha256=${SRC_SHA:0:16}… $(cat "$WORK/counts_src.json")"
say "演练源行数：$(cat "$WORK/counts_src.json")"

# ---------------- 1) 在线写入压力（备份期间持续写，验证在线备份一致性） ----------------
WRITER_PID=""
if [ "$LIVE_WRITES" = "1" ]; then
  "$PY" - "$SRC" >"$WORK/live_writer.log" 2>&1 <<'PYEOF' &
import sqlite3, sys, time
con = sqlite3.connect(sys.argv[1], timeout=10)
con.execute("CREATE TABLE IF NOT EXISTS drill_heartbeat(id INTEGER PRIMARY KEY, ts REAL)")
con.commit()
end = time.time() + 6
i = 0
while time.time() < end:
    con.execute("INSERT INTO drill_heartbeat(ts) VALUES(?)", (time.time(),))
    con.commit()
    i += 1
    time.sleep(0.01)
print(f"writes={i}")
con.close()
PYEOF
  WRITER_PID=$!
  say "在线写入线程已启动（pid=${WRITER_PID}，持续 6s，备份在其间执行）"
  sleep 0.4
else
  say "已按参数跳过在线写入压力"
fi

# ---------------- 2) sqlite 在线备份 ----------------
T0="$(now_ms)"
set +e
BK_OUT="$("$RP" --db "$SRC" --user user-admin db backup --out "$BACKUP" 2>"$WORK/backup.err")"
BK_RC=$?
set -e
T1="$(now_ms)"; BACKUP_MS=$((T1 - T0))
[ -n "$WRITER_PID" ] && { wait "$WRITER_PID" 2>/dev/null || true; }
say "rp db backup 退出码=${BK_RC}，耗时=${BACKUP_MS}ms"
[ -f "$BACKUP" ] && say "备份文件：${BACKUP}（bytes=$(fsize "$BACKUP")）"
check "在线备份生成备份文件" "$([ -f "$BACKUP" ] && echo 0 || echo 1)" "rc=${BK_RC} $(tail -2 "$WORK/backup.err" 2>/dev/null | tr '\n' ' ')"

BK_SHA=""; BK_COUNTS_FILE="$WORK/counts_backup.json"; : > "$BK_COUNTS_FILE"
ENC_SHA=""; DEC_SHA=""; TARGET_SHA=""; TARGET_COUNTS_FILE="$WORK/counts_target.json"; : > "$TARGET_COUNTS_FILE"
FP_SRC="$WORK/fp_src.txt"; FP_BACKUP="$WORK/fp_backup.txt"; FP_TARGET="$WORK/fp_target.txt"
ENC_MS=0; RESTORE_MS=0
if [ ! -f "$BACKUP" ]; then
  skip "备份后全部步骤" "在线备份失败，恢复演练无法执行（不伪造 PASS）"
  FAIL=$((FAIL+1)); FAILED_NAMES="${FAILED_NAMES}在线备份; "
else
  BK_SHA="$(sha "$BACKUP")"
  rowcounts "$BACKUP" "$BK_COUNTS_FILE"
  fingerprint "$SRC" "$FP_SRC"
  fingerprint "$BACKUP" "$FP_BACKUP"
  # CLI 输出里的 sha 与实际文件一致（防“输出是旧值”）
  CLI_SHA="$(printf '%s' "$BK_OUT" | "$PY" -c 'import json,sys
try: print(json.load(sys.stdin).get("sha256") or "")
except Exception: print("")')"
  check "备份文件 sha256 与 CLI 输出一致" "$([ -n "$CLI_SHA" ] && [ "$CLI_SHA" = "$BK_SHA" ] && echo 0 || echo 1)" "cli=${CLI_SHA:0:16}… file=${BK_SHA:0:16}…"
  INTEG="$(integrity "$BACKUP")"
  check "备份库 integrity_check=ok" "$([ "$INTEG" = "ok" ] && echo 0 || echo 1)" "$INTEG"
  FP_OK="$([ "$(cat "$FP_BACKUP")" = "$(cat "$FP_SRC")" ] && echo 0 || echo 1)"
  check "在线备份业务表内容指纹与源库一致（备份期间存在并发写事务）" "$FP_OK" "src=$(cut -c1-16 "$FP_SRC")… backup=$(cut -c1-16 "$FP_BACKUP")…"

  # ---------------- 3) openssl 加密 / 解密回环 ----------------
  if [ "$HAS_OPENSSL" = "1" ]; then
    export DRILL_ENC_PASS="drill-$(date +%s)-$RANDOM"
    T0="$(now_ms)"
    if openssl enc -aes-256-cbc -pbkdf2 -iter 210000 -salt \
        -in "$BACKUP" -out "$ENC" -pass env:DRILL_ENC_PASS 2>"$WORK/openssl.err"; then
      T1="$(now_ms)"; ENC_MS=$((T1 - T0))
      ENC_SHA="$(sha "$ENC")"
      check "openssl 加密产出密文（不同 sha）" "$([ -n "$ENC_SHA" ] && [ "$ENC_SHA" != "$BK_SHA" ] && echo 0 || echo 1)" "enc=${ENC_SHA:0:16}…"
      if openssl enc -d -aes-256-cbc -pbkdf2 -iter 210000 -in "$ENC" -out "$DEC" \
          -pass env:DRILL_ENC_PASS 2>>"$WORK/openssl.err"; then
        DEC_SHA="$(sha "$DEC")"
        check "解密 sha256 与备份 sha256 完全一致" "$([ "$DEC_SHA" = "$BK_SHA" ] && echo 0 || echo 1)" "dec=${DEC_SHA:0:16}… backup=${BK_SHA:0:16}…"
      else
        DEC_SHA=""
        check "openssl 解密回环" 1 "$(tail -2 "$WORK/openssl.err" | tr '\n' ' ')"
      fi
      if openssl enc -d -aes-256-cbc -pbkdf2 -iter 210000 -in "$ENC" -out /dev/null \
          -pass pass:wrong-password 2>/dev/null; then
        check "错误口令解密必须失败（负向）" 1 "错误口令被接受"
      else
        check "错误口令解密必须失败（负向）" 0
      fi
      say "加密耗时：${ENC_MS}ms（aes-256-cbc / pbkdf2 / 210000 迭代）"
    else
      check "openssl 加密" 1 "$(tail -2 "$WORK/openssl.err" | tr '\n' ' ')"
    fi
  else
    skip "openssl 加密" "本机无 openssl 命令：加密能力 NOT TESTED（恢复演练继续走明文备份）"
    cp "$BACKUP" "$DEC"; DEC_SHA="$(sha "$DEC")"
  fi

  # ---------------- 4) 恢复演练：先破坏目标库，再从备份恢复 ----------------
  cp -p "$SRC" "$TARGET"
  "$PY" - "$TARGET" <<'PYEOF'
import sqlite3, sys
con = sqlite3.connect(sys.argv[1], timeout=10)
con.execute("DROP TABLE IF EXISTS drill_heartbeat")
for t in ("finding", "document", "rule_version", "notification"):
    try:
        con.execute(f'DELETE FROM "{t}"')
    except sqlite3.Error:
        pass
con.commit(); con.close()
PYEOF
  rowcounts "$TARGET" "$WORK/counts_target_broken.json"
  say "恢复前目标库已破坏：$(cat "$WORK/counts_target_broken.json")"
  RESTORE_SRC="${DEC:-$BACKUP}"
  T0="$(now_ms)"
  set +e
  RS_OUT="$("$RP" --db "$TARGET" --user user-admin db restore --from "$RESTORE_SRC" --yes 2>"$WORK/restore.err")"
  RS_RC=$?
  set -e
  T1="$(now_ms)"; RESTORE_MS=$((T1 - T0))
  say "rp db restore 退出码=${RS_RC}，耗时=${RESTORE_MS}ms"
  TARGET_SHA="$(sha "$TARGET")"
  rowcounts "$TARGET" "$TARGET_COUNTS_FILE"
  fingerprint "$TARGET" "$FP_TARGET"
  check "恢复命令退出码 0" "$([ "$RS_RC" = "0" ] && echo 0 || echo 1)" "rc=${RS_RC} $(tail -2 "$WORK/restore.err" | tr '\n' ' ')"
  check "恢复后行数与备份一致" "$([ "$(cat "$TARGET_COUNTS_FILE")" = "$(cat "$BK_COUNTS_FILE")" ] && echo 0 || echo 1)" "backup=$(cat "$BK_COUNTS_FILE") target=$(cat "$TARGET_COUNTS_FILE")"
  check "恢复后全表内容指纹与备份一致" "$([ "$(cat "$FP_TARGET")" = "$(cat "$FP_BACKUP")" ] && echo 0 || echo 1)" "backup=$(cut -c1-16 "$FP_BACKUP")… target=$(cut -c1-16 "$FP_TARGET")…"
  INTEG2="$(integrity "$TARGET")"
  check "恢复后 integrity_check=ok" "$([ "$INTEG2" = "ok" ] && echo 0 || echo 1)" "$INTEG2"
  SAMPLE="$("$PY" - "$TARGET" <<'PYEOF'
import sqlite3, sys
con = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True)
try:
    n = con.execute("SELECT COUNT(*) FROM audit_log WHERE created_at IS NOT NULL").fetchone()[0]
    print(f"audit_log_with_ts={n}")
except sqlite3.Error as e:
    print(f"ERR:{type(e).__name__}")
finally:
    con.close()
PYEOF
)"
  check "恢复后审计日志可查询（抽样）" "$(echo "$SAMPLE" | grep -q '^audit_log_with_ts=' && echo 0 || echo 1)" "$SAMPLE"
  # 文件级 sha 差异如实记录（SQLite backup API 重写页，不伪造“一致”）
  say "说明：恢复后库文件 sha256（${TARGET_SHA:0:16}…）与备份文件 sha256（${BK_SHA:0:16}…）不同属预期——"
  say "      SQLite backup API 会重写页布局；恢复正确性以行数+内容指纹+integrity_check 为准。"
fi

# ---------------- 5) 产品库未被写（铁律 6） ----------------
PROD_SHA_AFTER=""; PROD_BYTES_AFTER=""
if [ -f "$PRODUCT_DB" ]; then
  PROD_SHA_AFTER="$(sha "$PRODUCT_DB")"
  PROD_BYTES_AFTER="$(fsize "$PRODUCT_DB")"
  check "产品库 sha256+大小运行前后一致（铁律 6）" \
    "$([ "$PROD_SHA_AFTER" = "$PROD_SHA_BEFORE" ] && [ "$PROD_BYTES_AFTER" = "$PROD_BYTES_BEFORE" ] && echo 0 || echo 1)" \
    "before=${PROD_SHA_BEFORE:0:16}…/${PROD_BYTES_BEFORE}B after=${PROD_SHA_AFTER:0:16}…/${PROD_BYTES_AFTER}B"
else
  skip "产品库隔离校验" "产品库不存在（仅 /tmp 演练）"
fi

# ---------------- 6) 机读结果 ----------------
STATUS="PASS"; [ "$FAIL" -gt 0 ] && STATUS="FAIL"
"$PY" - "$OUT_JSON" "$STATUS" "$PASS" "$FAIL" "$SKIP" "$FAILED_NAMES" "$WORK" "$SRC" \
  "$BK_SHA" "$ENC_SHA" "$DEC_SHA" "$TARGET_SHA" \
  "$WORK/counts_src.json" "$WORK/counts_backup.json" "$WORK/counts_target.json" \
  "$FP_SRC" "$FP_BACKUP" "$FP_TARGET" \
  "$PROD_SHA_BEFORE" "$PROD_SHA_AFTER" "$PROD_BYTES_BEFORE" "$PROD_BYTES_AFTER" \
  "$BACKUP_MS" "$RESTORE_MS" "$ENC_MS" "$LIVE_WRITES" "$HAS_OPENSSL" <<'PYEOF'
import json, sys
(a, status, p, f, s, failed, work, src, bk_sha, enc_sha, dec_sha, target_sha,
 counts_src, counts_bk, counts_tg, fp_src, fp_bk, fp_tg,
 prod_before, prod_after, prod_bytes_before, prod_bytes_after,
 backup_ms, restore_ms, enc_ms, live, openssl) = sys.argv[1:]

def _read(path):
    try:
        return open(path, encoding="utf-8").read().strip()
    except Exception:
        return ""

data = {
    "task": "T-196 / 备份加密+恢复演练",
    "script": "scripts/ops/backup_restore_drill.sh",
    "at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
    "status": status,
    "pass": int(p), "fail": int(f), "skip": int(s),
    "failed": [x for x in failed.split("; ") if x],
    "work_dir": work,
    "drill_db": src,
    "live_writes": bool(int(live)),
    "backup": {"sha256": bk_sha, "rowcounts": json.loads(_read(counts_bk) or "{}"),
               "content_fingerprint": _read(fp_bk), "duration_ms": int(backup_ms)},
    "encryption": {"tool": "openssl enc -aes-256-cbc -pbkdf2 -iter 210000" if int(openssl) else "NOT TESTED（无 openssl）",
                   "encrypted_sha256": enc_sha, "decrypted_sha256": dec_sha,
                   "roundtrip_ok": bool(enc_sha and dec_sha and dec_sha == bk_sha),
                   "duration_ms": int(enc_ms)},
    "restore": {"target_sha256": target_sha,
                "file_sha_note": "SQLite backup API 重写页布局，恢复后文件 sha 不保证等于备份文件 sha；"
                                 "以行数+内容指纹+integrity_check 判一致",
                "rowcounts": json.loads(_read(counts_tg) or "{}"),
                "rowcounts_match": _read(counts_tg) == _read(counts_bk),
                "content_fingerprint": _read(fp_tg),
                "fingerprint_match": bool(_read(fp_tg) and _read(fp_tg) == _read(fp_bk)),
                "duration_ms": int(restore_ms)},
    "source_rowcounts": json.loads(_read(counts_src) or "{}"),
    "rpo_note": "演练用当日产品库只读快照，RPO≈0；生产建议按周期在线备份，RPO=备份周期",
    "rto_measured_ms": int(backup_ms) + int(enc_ms) + int(restore_ms),
    "product_db_untouched": {
        "sha256_before": prod_before, "sha256_after": prod_after,
        "bytes_before": prod_bytes_before, "bytes_after": prod_bytes_after,
        "unchanged": bool(prod_before and prod_before == prod_after
                          and prod_bytes_before == prod_bytes_after)},
}
json.dump(data, open(a, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\n机读结果：{a}")
PYEOF

say ""
say "备份/恢复演练：${STATUS}（PASS ${PASS} / FAIL ${FAIL} / SKIP ${SKIP}）"
[ "$FAIL" -gt 0 ] && exit 1
exit 0
