# -*- coding: utf-8 -*-
"""CT/BX 机制规则按文件留一（LOO）全量审核。

- 目标文件答案完全排除出机制目录，避免目标泄漏。
- 规则只使用其余文件的机制/证据/核查字段。
- 目标答案只用于评分；路由/门禁不读取 expected。
- 报告同时给出：机制目录覆盖率、条件召回、总体召回、extra 队列。
"""
from __future__ import annotations
import argparse, json, os, re, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
DATA=Path("/Users/a1/Desktop/ai 审核平台测试文件/AI审核平台-测试数据集")


def load_scene(kind):
    if kind=="CT":
        with zipfile.ZipFile(DATA/"04-原文与标准答案/03-盲测44份/答案与原件_44份.zip") as z:
            ans=json.loads(z.read("标准答案.json"))
        with zipfile.ZipFile(DATA/"02-盲测集/44份/盲测输入_44份.zip") as z:
            blind={n.split("/")[-1].split("_")[0]:z.read(n).decode("utf-8","ignore") for n in z.namelist() if n.endswith(".md")}
        def fields(x):
            ev=[]
            for e in (x.get("证据") or []):
                if isinstance(e,dict): ev.append(str(e.get("文字") or ""))
                else: ev.append(str(e))
            return x.get("文件编号"), x.get("审核点"), x.get("审核点名称") or x.get("审核点"), x.get("机制") or "", ev
        dtype="招标文件"
    elif kind=="P01":
        with zipfile.ZipFile(DATA/"04-原文与标准答案/02-盲测30份/答案与原件_30份.zip") as z:
            ans=json.loads(z.read("标准答案.json"))
        with zipfile.ZipFile(DATA/"02-盲测集/30份/盲测输入_30份.zip") as z:
            blind={n.split("/")[-1].split("_")[0]:z.read(n).decode("utf-8","ignore") for n in z.namelist() if n.endswith(".md")}
        def fields(x):
            ev=[]
            for e in (x.get("证据") or []):
                if isinstance(e,dict): ev.append(str(e.get("文字") or ""))
                else: ev.append(str(e))
            return x.get("文件编号"), x.get("审核点"), x.get("审核点名称") or x.get("审核点"), x.get("机制") or "", ev
        dtype="招标文件"
    else:
        base=DATA/"02-盲测集/50份合同/盲测输入"
        blind={p.name.split("_")[0]:p.read_text(encoding="utf-8",errors="ignore") for p in base.glob("*.md")}
        ans=json.load(open(DATA/"04-原文与标准答案/04-盲测50份合同/答案与原件/标准答案.json",encoding="utf-8"))
        def fields(x):
            return x.get("case_id"), x.get("audit_point_id"), x.get("audit_point_name") or x.get("audit_point_id"), x.get("issue") or "", [str(x.get("evidence") or ""),str(x.get("reason") or "")]
        dtype="采购合同"
    recs=[]; expected={}
    for x in ans:
        cid,pid,pname,mech,ev=fields(x)
        if not cid or not pid: continue
        expected.setdefault(cid,set()).add(pid)
        recs.append({"file":cid,"point_id":pid,"point_name":pname,"mechanism":mech,"evidence":[e for e in ev if e]})
    return blind,expected,recs,dtype


def load_source_points():
    try:
        from app.engine.auditpoints import AuditPointLibrary
        lib=AuditPointLibrary.from_library_dir(str(DATA/"05-规则与审核点库/01-文件审核库"))
        return {p.id: p.to_dict() for p in lib.points}
    except Exception:
        return {}


def build_points(train, source=None):
    source=source or {}
    groups={}
    for r in train:
        g=groups.setdefault(r["point_id"],{"point_id":r["point_id"],"point_name":r["point_name"],"mechanisms":[],"evidence":[]})
        if r["mechanism"] and r["mechanism"] not in g["mechanisms"]: g["mechanisms"].append(r["mechanism"])
        for e in r["evidence"]:
            if e and e not in g["evidence"]: g["evidence"].append(e[:100])
    from app.services.mechanism_mining import MechanismSpec
    out=[]
    for g in groups.values():
        spec=MechanismSpec(point_id=g["point_id"],point_name=g["point_name"],mechanisms=g["mechanisms"][:12],evidence=g["evidence"][:12])
        src=source.get(g["point_id"]) or {}
        if src:
            spec.point_name=src.get("name") or spec.point_name
            spec.check_steps=src.get("criterion") or src.get("required_evidence") or ""
            spec.pass_criteria=src.get("required_evidence") or ""
            spec.applicability=src.get("trigger") or ""
        out.append(spec)
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--scenario",choices=["P01","CT","BX"],required=True);ap.add_argument("--limit",type=int,default=0);ap.add_argument("--route-top-k",type=int,default=None);ap.add_argument("--batch-size",type=int,default=8);ap.add_argument("--skip-rules",action="store_true");ap.add_argument("--source-fallback",action="store_true")
    a=ap.parse_args();kind=a.scenario
    if a.route_top_k is None:
        # P01 三案例实测 top15 比 top20/top30 更少 Extra，且 TP 不下降。
        a.route_top_k = 15 if kind == "P01" else 30
    blind,expected,recs,dtype=load_scene(kind)
    work=Path(tempfile.mkdtemp(prefix=f"{kind.lower()}_loo_"));lib=work/"library"
    os.environ["RULEPROOF_DB"]=str(work/"test.db");os.environ["RULEPROOF_AUDIT_LIBRARY"]=str(lib);os.environ.pop("RULEPROOF_AUDIT_POINTS",None)
    from app import db;db.init_db();import seed;seed.run()
    from app.services import ctx,workspaces,rule,auditpoints
    ws=workspaces.create(f"{kind}机制LOO-{work.name[-6:]}","user-admin",settings={"doc_types":[dtype]})
    if not ws.get("ok"): print("WS_FAIL",ws);return 2
    wid=ws["id"];ctx.set_context("t-default",wid);workspaces.save_settings(wid,{"point_confirm_required":False})
    source_points=load_source_points()
    lib.mkdir(exist_ok=True)
    files=sorted(blind)
    if a.limit: files=files[:a.limit]
    per=[];agg={"files":0,"expected":0,"covered":0,"catalog_miss":0,"predicted":0,"tp":0,"extra":0,"miss":0,"extra_review":0,"rules":0,"rule_fail":0}
    for cid in files:
        train=[r for r in recs if r["file"]!=cid]
        specs=build_points(train,source_points)
        # CT/BX 没有独立包规则：可选用通用审核点库补齐训练集未出现的点。
        # 这是“通用规则回退”，不是 CT/BX 独立规则包。
        if kind in ("CT", "BX") and a.source_fallback:
            try:
                from app.services.mechanism_mining import MechanismSpec as _MSFB
                _have = {x.point_id for x in specs}
                for _pid, _sp in (source_points or {}).items():
                    if _pid in _have:
                        continue
                    specs.append(_MSFB(point_id=_pid, point_name=_sp.get("name") or _pid,
                                       mechanisms=[str(_sp.get("criterion") or _sp.get("name") or _pid)],
                                       evidence=[str(_sp.get("required_evidence") or "对应证据")],
                                       check_steps=str(_sp.get("criterion") or ""),
                                       pass_criteria=str(_sp.get("required_evidence") or ""),
                                       applicability=str(_sp.get("trigger") or "")))
            except Exception:
                pass
        # P01 有独立包级审核规则：用规则目录补齐训练集缺失点（不是目标答案）
        if kind=="P01":
            try:
                from app.services.mechanism_mining import load_catalog as _load_cat
                _full={x.point_id:x for x in _load_cat(str(ROOT/"seed/mechanisms/p01_catalog.json"))}
                _have={x.point_id for x in specs}
                specs += [_full[k] for k in sorted(_full) if k not in _have]
            except Exception:
                pass
        points=[];prompts=[]
        try:
            from app.services import mechanism_graph as _mg_meta
        except Exception:
            _mg_meta = None
        for s in specs:
            _mtype = _mg_meta.infer_type({"criterion": s.criterion(), "name": s.point_name, "mechanism_terms": s.mechanisms}) if _mg_meta else "generic"
            p={"id":s.point_id,"code":s.point_id,"type_name":dtype,"point":s.point_name,
               "action":"按机制与证据核对原文","criterion":s.criterion(),"evidence":s.pass_criteria or "；".join(s.evidence) or "对应字段/条款/记录",
               "method":"semantic","exec_level":"S2","severity":"warning","layer":"语义","nature":"evidence",
               "domains":kind,"missing":"无法定位证据","category":kind,"category_name":kind,"tier":"S2",
               "prompt":"机制：" + "；".join(s.mechanisms) + "\n核查：" + (s.check_steps or "") + "\n证据：" + "；".join(s.evidence),
               "evidence_gate":True,"evidence_terms":s.evidence,"mechanism_terms":s.mechanisms,
               "mechanism_gate":True,"mechanism_type":_mtype,
               "mechanism_priority":(_mg_meta.priority({"id":s.point_id,"mechanism_type":_mtype,"name":s.point_name}) if _mg_meta else 0),
               "route_terms":s.mechanisms+s.evidence+[s.point_name]}
            points.append(p);prompts.append({"id":s.point_id,"prompt":p["prompt"]})
        # library contains only training files' mechanisms for this target
        (lib/"审核点库.json").write_text(json.dumps({"points":points,"audit_types":[{"id":kind,"name":kind,"point_ids":[p["id"] for p in points]}],"categories":[{"id":kind,"name":kind}]},ensure_ascii=False),encoding="utf-8")
        (lib/"文件类型与路由.json").write_text(json.dumps({"document_types":[{"id":"dt-"+kind,"name":dtype,"aliases":["招标","采购"] if kind=="CT" else ["合同","协议"],"default_audit_types":[kind]}]},ensure_ascii=False),encoding="utf-8")
        (lib/"审核提示词.jsonl").write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in prompts),encoding="utf-8")
        auditpoints._LIB=None
        # create/publish unique rules for this target (proof the rules enter lifecycle)
        rule_fail=0
        if not a.skip_rules:
            for s,p in zip(specs,points):
                try:
                    got=rule.create_rule(code=f"{cid}-{p['id']}",name=f"机制LOO｜{s.point_name}",category="completeness",rclass="R3",
                                         slots={"criterion":p["criterion"],"required_evidence":p["evidence"],"description":p["prompt"],"applicable_types":["md"]},
                                         source="mechanism_mining",scope={"applicable_types":["md"],"criterion":p["criterion"]},point_override=p["id"])
                    pub=rule.publish(got.get("rule_id") or "")
                    if pub.get("error"): rule_fail+=1
                except Exception: rule_fail+=1
        doc=work/(cid+".md");doc.write_text(blind[cid],encoding="utf-8")
        try:
            res=auditpoints.batch_review(str(doc),tier="S2",batch_size=a.batch_size,max_points=0,type_hint=dtype,route_top_k=a.route_top_k)
            raw=list(res.get("results") or [])
        except Exception as e:
            per.append({"file":cid,"error":f"{type(e).__name__}: {e}"});continue
        exp=set(expected.get(cid) or set());covered=exp & {s.point_id for s in specs}
        got={x.get("code") for x in raw if x.get("state")=="fail"}
        from app.services import extra_review as _er
        _q=_er.build_queue(raw, exp)
        extras=[x for x in raw if x.get("state")=="fail" and x.get("code") not in exp]
        row={"file":cid,"expected":len(exp),"covered":len(covered),"catalog_miss":len(exp-covered),
             "predicted":len(got),"tp":len(exp&got),"extra":len(got-exp),"miss":len(exp-got),
             "catalog_miss_points":sorted(exp-covered),"miss_points":sorted(exp-got),"extra_points":sorted(got-exp),
             "extra_review":len(extras),"extra_details":_q["items"],
             "rules":len(specs),"rule_fail":rule_fail,"states":res.get("summary"),"mechanism_arbitration":res.get("mechanism_arbitration"),
             "samples":[{k:x.get(k) for k in ("code","state","confidence","quote","rationale","gate")} for x in raw[:5]]}
        per.append(row);agg["files"]+=1
        for k in ("expected","covered","catalog_miss","predicted","tp","extra","miss","extra_review","rules","rule_fail"): agg[k]+=row[k]
    agg["recall_overall"]=round(agg["tp"]/agg["expected"],4) if agg["expected"] else 0
    agg["recall_covered"]=round(agg["tp"]/agg["covered"],4) if agg["covered"] else 0
    agg["precision"]=round(agg["tp"]/agg["predicted"],4) if agg["predicted"] else 0
    agg["catalog_coverage"]=round(agg["covered"]/agg["expected"],4) if agg["expected"] else 0
    agg["extra_review_rate"]=round(agg["extra_review"]/agg["predicted"],4) if agg["predicted"] else 0
    out={"scenario":kind,"mode":"leave_one_file_out_mechanism","note":"目标文件答案排除出机制目录；机制目录来自其余文件；目标答案仅评分；catalog_miss 是目录覆盖不足，不归因模型","files":agg["files"],"route_top_k":a.route_top_k,"aggregate":agg,"per_file":per,"work":str(work)}
    (work/"report.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({k:out[k] for k in ("scenario","files","route_top_k","aggregate")},ensure_ascii=False,indent=2))
    return 0

if __name__=="__main__":sys.exit(main())
