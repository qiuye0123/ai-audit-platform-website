# -*- coding: utf-8 -*-
"""P01 留一案例验证：训练案例挖规则，目标案例只审核。

不把目标案例的差异/答案写入规则。用全部 83 个训练审核点（不是只挑目标点），
避免“按答案选点”的泄漏；结果额外发现不自动算误报，需人工复核。
"""
from __future__ import annotations
import argparse, json, os, re, sys, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
DATA = Path("/Users/a1/Desktop/AI 审核平台测试文件/AI审核平台-测试数据集")


def load_all():
    with zipfile.ZipFile(DATA / "04-原文与标准答案/02-盲测30份/答案与原件_30份.zip") as z:
        ans = json.loads(z.read("标准答案.json"))
        origs = {n.split("/")[-1].split("_")[0]: z.read(n).decode("utf-8", "ignore")
                 for n in z.namelist() if n.startswith("原件/") and n.endswith(".md")}
    with zipfile.ZipFile(DATA / "02-盲测集/30份/盲测输入_30份.zip") as z:
        blinds = {n.split("/")[-1].split("_")[0]: z.read(n).decode("utf-8", "ignore")
                  for n in z.namelist() if n.endswith(".md")}
    cases = sorted(set(blinds) & set(origs))
    return cases, blinds, origs, ans


def mine_rules(answers: list, exclude: str, mode: str = "diff") -> list:
    groups = {}
    for a in answers:
        case = a.get("文件编号") or ""
        if case == exclude:
            continue
        pid = str(a.get("审核点") or "").strip()
        if not pid:
            continue
        g = groups.setdefault(pid, {"code": pid, "name": a.get("审核点名称") or pid,
                                    "modified": [], "original": [], "reason": [], "mechanism": []})
        for key, val in (("modified", a.get("改动后")), ("original", a.get("原文")),
                         ("reason", a.get("判定理由")), ("mechanism", a.get("机制"))):
            if val and str(val) not in g[key]:
                g[key].append(str(val))
    rules = []
    for pid, g in groups.items():
        mods = g["modified"][:12]
        origs = g["original"][:12]
        mechs = list(dict.fromkeys(g["mechanism"]))[:12]
        reasons = list(dict.fromkeys(g["reason"]))[:12]
        if mode == "mechanism":
            crit = (f"审核点：{g['name']}。"
                    "检查目标文件是否出现同类错误机制：" + "；".join(mechs) +
                    "。典型表现：" + "；".join(reasons) +
                    "。只依据原文证据判 fail；证据不足判 insufficient；不适用判 na；否则 pass。")
            prompt = "训练集常见机制：" + "；".join(mechs) + "\n典型表现：" + "；".join(reasons)
        else:
            crit = ("核查本文件是否出现下列不当表述或做法：" + "；".join(mods) + "。"
                    "正确要求/对照：" + "；".join(origs) + "。"
                    "若原文出现不当表述且与正确要求冲突，判 fail；无法定位证据判 insufficient；否则 pass。")
            prompt = "训练集差异示例（不当）：" + "；".join(mods) + "\n正确要求：" + "；".join(origs)
        rules.append({"code": pid, "name": g["name"], "criterion": crit[:4000],
                      "evidence": "包含错误机制或正确要求的原文片段",
                      "prompt": prompt,
                      "mechanism": "；".join(mechs)[:500]})
    return rules


def build_library(rules: list, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    points = []
    with (outdir / "审核提示词.jsonl").open("w", encoding="utf-8") as f:
        for r in rules:
            points.append({"id": r["code"], "code": r["code"], "type_name": "招标采购文件",
                           "point": r["name"], "action": "按训练差异示例核对目标原文",
                           "criterion": r["criterion"], "evidence": r["evidence"],
                           "method": "semantic", "exec_level": "S2", "severity": "warning",
                           "layer": "语义", "nature": "evidence", "domains": "招标采购",
                           "missing": "无法定位差异片段", "category": "P01", "category_name": "招标采购",
                           "tier": "S2", "applicable_when": r["mechanism"], "prompt": r["prompt"]})
            f.write(json.dumps({"id": r["code"], "prompt": r["prompt"]}, ensure_ascii=False) + "\n")
    (outdir / "审核点库.json").write_text(json.dumps(
        {"points": points, "audit_types": [{"id": "P01", "name": "招标采购", "point_ids": [r["code"] for r in rules]}],
         "categories": [{"id": "P01", "name": "招标采购"}]}, ensure_ascii=False), encoding="utf-8")
    (outdir / "文件类型与路由.json").write_text(json.dumps(
        {"document_types": [{"id": "dt-p01", "name": "招标采购文件", "aliases": ["招标", "采购文件"],
                             "default_audit_types": ["P01"]}]}, ensure_ascii=False), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="P01-001,P01-002,P01-003")
    ap.add_argument("--limit-points", type=int, default=0)
    ap.add_argument("--mode", choices=["diff", "mechanism"], default="diff")
    args = ap.parse_args()
    cases, blinds, origs, answers = load_all()
    targets = [x for x in args.cases.split(",") if x]
    work = Path(tempfile.mkdtemp(prefix="p01_loo_"))
    os.environ["RULEPROOF_DB"] = str(work / "test.db")
    from app import db; db.init_db()
    import seed; seed.run()
    from app.services import ctx, workspaces, rule, auditpoints
    results = []
    for target in targets:
        train = mine_rules(answers, target, mode=args.mode)
        lib = work / f"lib_{target}"
        build_library(train, lib)
        os.environ["RULEPROOF_AUDIT_LIBRARY"] = str(lib)
        os.environ.pop("RULEPROOF_AUDIT_POINTS", None)
        # 重新加载点位库，避免上一个 target 的库缓存
        auditpoints._LIB = None
        ws = workspaces.create(f"LOO·{target}", "user-admin", settings={"doc_types": ["招标采购文件"]})
        wid = ws["id"]; ctx.set_context("t-default", wid)
        workspaces.save_settings(wid, {"point_confirm_required": False})
        created, failed = 0, []
        for r in train:
            try:
                got = rule.create_rule(code=r["code"], name=r["name"], category="completeness", rclass="R3",
                                       slots={"criterion": r["criterion"], "required_evidence": r["evidence"],
                                              "description": r["mechanism"], "applicable_types": ["md"]},
                                       source="loo_mining", scope={"applicable_types": ["md"], "criterion": r["criterion"]},
                                       point_override=r["code"])
                pub = rule.publish(got.get("rule_id") or "")
                created += 1
                if pub.get("error"): failed.append({"code": r["code"], "error": pub.get("error")})
            except Exception as e:
                failed.append({"code": r["code"], "error": type(e).__name__, "message": str(e)[:120]})
        doc = work / f"{target}.md"; doc.write_text(blinds[target], encoding="utf-8")
        res = auditpoints.batch_review(str(doc), tier="S2", batch_size=8,
                                       max_points=args.limit_points, type_hint="招标采购文件")
        expect = {a.get("审核点") for a in answers if a.get("文件编号") == target and a.get("审核点")}
        got = {x.get("code") for x in (res.get("results") or []) if x.get("state") == "fail"}
        item = {"target": target, "train_cases": len(cases) - 1, "rules": len(train), "created": created,
                "failed": failed[:5], "summary": res.get("summary"),
                "expected": len(expect), "predicted": len(got), "tp": len(expect & got),
                "extra": len(got - expect), "miss": len(expect - got),
                "miss_points": sorted(expect - got), "extra_points": sorted(got - expect)}
        results.append(item)
        print(json.dumps(item, ensure_ascii=False), flush=True)
    agg = {"cases": len(results), "expected": sum(x["expected"] for x in results),
           "tp": sum(x["tp"] for x in results), "extra": sum(x["extra"] for x in results),
           "miss": sum(x["miss"] for x in results),
           "recall": round(sum(x["tp"] for x in results) / max(1, sum(x["expected"] for x in results)), 4)}
    out = {"kind": "leave_one_case_out", "mode": args.mode, "note": "训练排除目标案例；83 个训练审核点全量执行，不按目标答案选点",
           "results": results, "aggregate": agg, "work": str(work)}
    (work / "report.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("AGG", json.dumps(agg, ensure_ascii=False))
    print("report", work / "report.json")


if __name__ == "__main__":
    main()
