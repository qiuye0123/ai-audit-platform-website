# -*- coding: utf-8 -*-
"""P01 + CT 全量差异规则覆盖（确定性字符串谓词，不调用模型）。

只回答：由标注差异生成的“不得出现改动后文本”规则，能在盲测原文中定位到多少。
这不是模型审核准确率，额外发现/语义改写不在本指标内。
"""
from __future__ import annotations
import json, zipfile, collections
from pathlib import Path

DATA = Path("/Users/a1/Desktop/ai 审核平台测试文件/AI审核平台-测试数据集")


def p01():
    with zipfile.ZipFile(DATA / "04-原文与标准答案/02-盲测30份/答案与原件_30份.zip") as z:
        ans = json.loads(z.read("标准答案.json"))
    with zipfile.ZipFile(DATA / "02-盲测集/30份/盲测输入_30份.zip") as z:
        docs = {n.split("/")[-1].split("_")[0]: z.read(n).decode("utf-8", "ignore")
                for n in z.namelist() if n.endswith(".md")}
    return "P01", ans, docs, "文件编号", "改动后", "原文"


def ct():
    ans = json.load(open(DATA / "04-原文与标准答案/03-盲测44份/标准答案.json", encoding="utf-8"))
    with zipfile.ZipFile(DATA / "02-盲测集/44份/盲测输入_44份.zip") as z:
        docs = {n.split("/")[-1].split("_")[0]: z.read(n).decode("utf-8", "ignore")
                for n in z.namelist() if n.endswith(".md")}
    return "CT", ans, docs, "文件编号", "改动后", "原文"


def run(label, ans, docs, case_key, mod_key, orig_key):
    by_case = collections.defaultdict(lambda: {"answers": 0, "changed": 0, "hit": 0, "miss": []})
    for a in ans:
        case = str(a.get(case_key) or "")
        if case not in docs:
            continue
        b = by_case[case]; b["answers"] += 1
        mod = str(a.get(mod_key) or "").strip()
        orig = str(a.get(orig_key) or "").strip()
        if not mod or mod == orig:
            continue
        b["changed"] += 1
        if mod in docs[case]:
            b["hit"] += 1
        else:
            b["miss"].append({"id": a.get("问题编号") or a.get("id") or "",
                              "point": a.get("审核点") or a.get("audit_point_id") or "",
                              "modified": mod[:120]})
    totals = {k: sum(v[k] for v in by_case.values()) for k in ("answers", "changed", "hit")}
    totals["miss"] = totals["changed"] - totals["hit"]
    totals["coverage"] = round(totals["hit"] / max(1, totals["changed"]), 4)
    rows = []
    for case in sorted(by_case):
        v = by_case[case]
        rows.append({"case": case, "answers": v["answers"], "changed": v["changed"],
                     "hit": v["hit"], "miss": len(v["miss"]),
                     "coverage": round(v["hit"] / max(1, v["changed"]), 4),
                     "miss_sample": v["miss"][:5]})
    return {"scenario": label, "cases": len(rows), "totals": totals, "rows": rows}


def main():
    out = []
    for fn in (p01, ct):
        label, ans, docs, ck, mk, ok = fn()
        out.append(run(label, ans, docs, ck, mk, ok))
    report = {"kind": "paired_diff_string_coverage",
              "note": "确定性字符串覆盖，不是模型审核准确率；只统计标注改动文本能在盲测原文中定位的比例",
              "scenarios": out}
    p = Path("docs/reports/evidence/paired_diff_coverage_20261116.json")
    p.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    md = ["# P01 + CT 全量差异规则覆盖（确定性）", "",
          "口径：标注的“改动后”文本能否在盲测原文中定位；不是模型准确率。", "",
          "| 场景 | 案例 | 答案 | 有改动 | 命中 | 未命中 | 覆盖率 |", "|---|---:|---:|---:|---:|---:|---:|"]
    for s in out:
        t = s["totals"]
        md.append(f"| {s['scenario']} | {s['cases']} | {t['answers']} | {t['changed']} | {t['hit']} | {t['miss']} | {t['coverage']:.2%} |")
    md += ["", "## 说明", "",
           "- 覆盖率 100% 只说明“字面改动能被找到”，不代表语义规则已经泛化。",
           "- BX 无原文/改动对，不能进入此指标。",
           "- WF 无盲测输入，不进入。",
           "- 下一步必须用机制级规则做留一验证，不能把本指标当审核准确率。"]
    Path("docs/reports/差异规则全量覆盖_20261116.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps({s["scenario"]: s["totals"] for s in out}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
