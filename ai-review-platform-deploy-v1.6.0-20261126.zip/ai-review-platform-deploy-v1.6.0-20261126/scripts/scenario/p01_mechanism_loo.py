# -*- coding: utf-8 -*-
"""机制级规则生产化验证：机制目录 → 规则 → 发布 → 留一目标审核。

训练排除目标案例；规则只使用“机制/证据/触发条件”，不写目标或训练原句。
路由只用目标文档本身。用于验证机制规则是否真正生效，不伪造准确率。
"""
from __future__ import annotations
import argparse, json, os, re, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
DATA=Path("/Users/a1/Desktop/ai 审核平台测试文件/AI审核平台-测试数据集")


def load():
    with zipfile.ZipFile(DATA/"04-原文与标准答案/02-盲测30份/答案与原件_30份.zip") as z:
        ans=json.loads(z.read("标准答案.json"))
        orig={n.split("/")[-1].split("_")[0]:z.read(n).decode("utf-8","ignore") for n in z.namelist() if n.startswith("原件/") and n.endswith(".md")}
    with zipfile.ZipFile(DATA/"02-盲测集/30份/盲测输入_30份.zip") as z:
        blind={n.split("/")[-1].split("_")[0]:z.read(n).decode("utf-8","ignore") for n in z.namelist() if n.endswith(".md")}
    rules=DATA/"05-规则与审核点库/03-包级审核规则/包级审核规则.md"
    return ans,orig,blind,rules.read_text(encoding="utf-8")


def rule_details(md):
    out = {}
    for ch in re.split(r"^###\s+", md, flags=re.M)[1:]:
        lines = ch.splitlines()
        m = re.match(r"([A-Z0-9]+-[A-Z0-9]+)[　\s]+(.+)", lines[0].strip()) if lines else None
        if not m:
            continue
        d = {"point_name": m.group(2).strip(), "evidence": "", "applicability": "", "check_steps": "", "pass_criteria": ""}
        for ln in lines:
            t = ln.strip()
            for key, label in (("evidence", "所需证据"), ("applicability", "适用条件"), ("check_steps", "核查步骤"), ("pass_criteria", "通过判据")):
                mm = re.match(r"-\s*" + label + r"[：:]\s*(.*)", t)
                if mm:
                    d[key] = mm.group(1).strip()
        out[m.group(1)] = d
    return out


def evidence_map(md):
    out={}
    for ch in re.split(r"^###\s+",md,flags=re.M)[1:]:
        lines=ch.splitlines()
        m=re.match(r"([A-Z0-9]+-[A-Z0-9]+)[　\s]+(.+)",lines[0].strip()) if lines else None
        if not m: continue
        ev=""
        for ln in lines:
            mm=re.match(r"-\s*所需证据[：:]\s*(.*)",ln.strip())
            if mm: ev=mm.group(1).strip()
        if ev: out[m.group(1)]=ev
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--case",default="P01-001");ap.add_argument("--top-k",type=int,default=35);ap.add_argument("--no-route",action="store_true")
    args=ap.parse_args()
    ans,orig,blind,md=load(); details=rule_details(md); ev={k:v["evidence"] for k,v in details.items()}
    target=args.case
    recs=[]
    for a in ans:
        if a.get("文件编号")==target: continue
        pid=a.get("审核点") or a.get("audit_point_id") or ""
        if not pid: continue
        _d=details.get(pid,{})
        recs.append({"point_id":pid,"point_name":_d.get("point_name") or a.get("审核点名称") or pid,
                     "mechanism":a.get("机制") or "", "evidence":ev.get(pid,""),
                     "applicability":_d.get("applicability",""),"check_steps":_d.get("check_steps",""),
                     "pass_criteria":_d.get("pass_criteria","")})
    work=Path(tempfile.mkdtemp(prefix="p01_mech_")); lib=work/"library"; lib.mkdir()
    os.environ["RULEPROOF_DB"]=str(work/"test.db");os.environ["RULEPROOF_AUDIT_LIBRARY"]=str(lib);os.environ.pop("RULEPROOF_AUDIT_POINTS",None)
    from app.services import mechanism_mining as mm
    catalog=mm.build_catalog(recs, evidence_by_point=ev)
    rules=catalog
    points=[]; prompts=[]
    for r in rules:
        code=r.point_id
        p={"id":code,"code":code,"type_name":"招标采购文件","point":r.point_name,
           "action":"按机制与证据核对原文","criterion":r.criterion(),"evidence":"；".join(r.evidence) or "对应字段/条款/记录",
           "method":"semantic","exec_level":"S2","severity":"warning","layer":"语义","nature":"evidence",
           "domains":"招标采购","missing":"无法定位证据","category":"P01","category_name":"招标采购","tier":"S2",
           "trigger":"；".join(r.trigger),"prompt":"机制：" + "；".join(r.mechanisms) + "\n证据：" + "；".join(r.evidence),
           "evidence_gate":True,"evidence_terms":r.evidence,"mechanism_terms":r.mechanisms,
           "route_terms":r.mechanisms + r.evidence + [r.point_name]}
        points.append(p);prompts.append({"id":code,"prompt":p["prompt"]})
    (lib/"审核点库.json").write_text(json.dumps({"points":points,"audit_types":[{"id":"P01","name":"招标采购","point_ids":[p["id"] for p in points]}],"categories":[{"id":"P01","name":"招标采购"}]},ensure_ascii=False),encoding="utf-8")
    (lib/"文件类型与路由.json").write_text(json.dumps({"document_types":[{"id":"dt-p01","name":"招标采购文件","aliases":["招标","采购"],"default_audit_types":["P01"]}]},ensure_ascii=False),encoding="utf-8")
    (lib/"审核提示词.jsonl").write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in prompts),encoding="utf-8")
    from app import db;db.init_db();import seed;seed.run()
    from app.services import ctx,workspaces,rule,auditpoints
    auditpoints._LIB=None
    ws=workspaces.create(f"机制规则·{target}-{work.name[-6:]}","user-admin",settings={"doc_types":["招标采购文件"]})
    if not ws.get("ok"):
        print("WORKSPACE_CREATE_FAILED",ws,flush=True);raise SystemExit(2)
    wid=ws["id"];ctx.set_context("t-default",wid);workspaces.save_settings(wid,{"point_confirm_required":False})
    created=0; failed=[]
    for r,p in zip(rules,points):
        try:
            got=rule.create_rule(code=p["id"],name=f"机制规则｜{r.point_name}",category="completeness",rclass="R3",
                                 slots={"criterion":p["criterion"],"required_evidence":p["evidence"],"description":p["prompt"],"applicable_types":["md"]},
                                 source="mechanism_mining",scope={"applicable_types":["md"],"criterion":p["criterion"]},point_override=p["id"])
            pub=rule.publish(got.get("rule_id") or "");created+=1
            if pub.get("error"):failed.append({"point":r.point_id,"error":pub.get("error")})
        except Exception as e: failed.append({"point":r.point_id,"error":type(e).__name__})
    doc=work/"blind.md";doc.write_text(blind[target],encoding="utf-8")
    res=auditpoints.batch_review(str(doc),tier="S2",batch_size=8,max_points=0,type_hint="招标采购文件",route_top_k=0 if args.no_route else args.top_k)
    raw=list(res.get("results") or [])
    expect={a.get("审核点") for a in ans if a.get("文件编号")==target}
    got={x.get("code") for x in raw if x.get("state")=="fail"}
    rep={"case":target,"top_k":0 if args.no_route else args.top_k,"catalog":len(catalog),"routed":len(rules),"routed_points":[r.point_id for r in rules],"created":created,"failed":failed[:5],
         "summary":res.get("summary"),"raw_results":[{k:x.get(k) for k in ("code","state","quote","evidence","confidence","rationale","filtered")} for x in raw],"expected":len(expect),"predicted":len(got),"tp":len(expect&got),"extra":len(got-expect),"miss":len(expect-got),
         "miss_points":sorted(expect-got),"extra_points":sorted(got-expect),"work":str(work)}
    (work/"report.json").write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({k:rep[k] for k in ("case","top_k","catalog","routed","created","failed","summary","expected","predicted","tp","extra","miss","miss_points")},ensure_ascii=False,indent=2))


if __name__=="__main__":main()
