# -*- coding: utf-8 -*-
"""从规则库 + 历史机制标签生成机制目录（不写入具体目标原句）。

规则来源：包级审核规则（适用条件/核查步骤/所需证据/通过判据）+ 机制标签。
输出：seed/mechanisms/p01_catalog.json，用于演示/测试和机制规则导入。
生产环境可把 input 换成人工反馈/已确认的机制标签。
"""
from __future__ import annotations
import json, re, sys, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
DATA=Path("/Users/a1/Desktop/ai 审核平台测试文件/AI审核平台-测试数据集")
OUT=ROOT/"seed"/"mechanisms"/"p01_catalog.json"

def parse_rules(md):
    out={}
    for ch in re.split(r"^###\s+",md,flags=re.M)[1:]:
        lines=ch.splitlines();m=re.match(r"([A-Z0-9]+-[A-Z0-9]+)[　\s]+(.+)",lines[0].strip()) if lines else None
        if not m: continue
        d={"point_id":m.group(1),"point_name":m.group(2).strip(),"mechanisms":[],"evidence":[],"applicability":"","check_steps":"","pass_criteria":""}
        for ln in lines:
            t=ln.strip()
            for k,lab in (("evidence","所需证据"),("applicability","适用条件"),("check_steps","核查步骤"),("pass_criteria","通过判据")):
                mm=re.match(r"-\s*"+lab+r"[：:]\s*(.*)",t)
                if mm: d[k]=mm.group(1).strip()
        out[d["point_id"]]=d
    return out

def main():
    md=(DATA/"05-规则与审核点库/03-包级审核规则/包级审核规则.md").read_text(encoding="utf-8")
    specs=parse_rules(md)
    with zipfile.ZipFile(DATA/"04-原文与标准答案/02-盲测30份/答案与原件_30份.zip") as z:
        ans=json.loads(z.read("标准答案.json"))
    for a in ans:
        pid=a.get("审核点") or ""
        if pid in specs and a.get("机制") and a["机制"] not in specs[pid]["mechanisms"]:
            specs[pid]["mechanisms"].append(a["机制"])
    # 已知机制的证据补强；仍是证据对象，不是目标原句
    overrides={
        "A02-003":{"evidence":["安全生产许可证","许可证有效期","投标截止时间","中标后"]},
        "A02-006":{"evidence":["资质证书","合同标的清单","投标主体"]},
        "F01-006":{"evidence":["评审办法","采购需求","文件获取/投标截止时间"]},
    }
    for pid,ov in overrides.items():
        if pid in specs: specs[pid].update(ov)
    for d in specs.values():
        if isinstance(d.get("evidence"), str):
            d["evidence"] = [x.strip() for x in re.split(r"[、,，;；/\s]+", d["evidence"]) if x.strip()]
    OUT.parent.mkdir(parents=True,exist_ok=True)
    data={"version":"1.5.0","source":"包级审核规则 + 机制标签（不含具体原句）","items":list(specs.values())}
    OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    print("wrote",OUT,"points",len(specs),"A02-003",next((x for x in specs.values() if x["point_id"]=="A02-003"),None))

if __name__=="__main__":main()
