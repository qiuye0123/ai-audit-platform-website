# -*- coding: utf-8 -*-
"""CT/BX 全量执行（oracle 点集）——不是泛化准确率。

每份文件只用答案里的审核点作为输入点集，规则判据来自真实 302 点库；
用于验证全量文件可解析、可执行、可评分、可出 extra 队列。
不得把本结果称为“无路由全量准确率”或“机制泛化”。
"""
from __future__ import annotations
import argparse,json,os,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
DATA=Path("/Users/a1/Desktop/ai 审核平台测试文件/AI审核平台-测试数据集")


def load_scene(kind):
    if kind=="CT":
        with zipfile.ZipFile(DATA/"04-原文与标准答案/03-盲测44份/答案与原件_44份.zip") as z: ans=json.loads(z.read("标准答案.json"))
        with zipfile.ZipFile(DATA/"02-盲测集/44份/盲测输入_44份.zip") as z:
            blind={n.split("/")[-1].split("_")[0]:z.read(n).decode("utf-8","ignore") for n in z.namelist() if n.endswith(".md")}
        pid=lambda x:x.get("审核点"); cid=lambda x:x.get("文件编号"); dtype="招标文件"
    else:
        base=DATA/"02-盲测集/50份合同/盲测输入";blind={p.name.split("_")[0]:p.read_text(encoding="utf-8",errors="ignore") for p in base.glob("*.md")}
        ans=json.load(open(DATA/"04-原文与标准答案/04-盲测50份合同/答案与原件/标准答案.json",encoding="utf-8"))
        pid=lambda x:x.get("audit_point_id"); cid=lambda x:x.get("case_id"); dtype="采购合同"
    expected={}
    for x in ans:
        if cid(x) and pid(x): expected.setdefault(cid(x),set()).add(pid(x))
    return blind,expected,dtype


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--scenario",choices=["CT","BX"],required=True);ap.add_argument("--limit",type=int,default=0);ap.add_argument("--batch-size",type=int,default=20)
    a=ap.parse_args();kind=a.scenario;blind,expected,dtype=load_scene(kind)
    work=Path(tempfile.mkdtemp(prefix=f"{kind.lower()}_oracle_"));lib=work/"library"
    os.environ["RULEPROOF_DB"]=str(work/"test.db");os.environ["RULEPROOF_AUDIT_LIBRARY"]=str(DATA/"05-规则与审核点库/01-文件审核库");os.environ.pop("RULEPROOF_AUDIT_POINTS",None)
    from app import db;db.init_db();import seed;seed.run()
    from app.services import ctx,workspaces,auditpoints
    ws=workspaces.create(f"{kind}全量oracle-{work.name[-6:]}","user-admin",settings={"doc_types":[dtype]})
    if not ws.get("ok"): print("WS_FAIL",ws);return 2
    wid=ws["id"];ctx.set_context("t-default",wid);workspaces.save_settings(wid,{"point_confirm_required":False})
    lib.mkdir(exist_ok=True)
    source=auditpoints.load(force=True);pmap={p.id:p.to_dict() for p in source.points}
    files=sorted(blind)
    if a.limit: files=files[:a.limit]
    per=[];agg={"files":0,"expected":0,"predicted":0,"tp":0,"miss":0,"extra":0,"parse_error":0}
    for cid in files:
        ids=sorted(expected.get(cid) or set());pts=[]
        for i in ids:
            p=pmap.get(i)
            if p: pts.append(p)
        if not pts:
            per.append({"file":cid,"error":"no_source_points"});continue
        (lib/"审核点库.json").write_text(json.dumps({"points":pts,"audit_types":[{"id":kind,"name":kind,"point_ids":[x["id"] for x in pts]}],"categories":[{"id":kind,"name":kind}]},ensure_ascii=False),encoding="utf-8")
        (lib/"文件类型与路由.json").write_text(json.dumps({"document_types":[{"id":"dt-"+kind,"name":dtype,"aliases":["招标","采购"] if kind=="CT" else ["合同","协议"],"default_audit_types":[kind]}]},ensure_ascii=False),encoding="utf-8")
        (lib/"审核提示词.jsonl").write_text("\n".join(json.dumps({"id":x["id"],"prompt":x.get("prompt") or x.get("criterion") or ""},ensure_ascii=False) for x in pts),encoding="utf-8")
        auditpoints._LIB=None
        doc=work/(cid+".md");doc.write_text(blind[cid],encoding="utf-8")
        try:
            res=auditpoints.batch_review(str(doc),tier="S2",batch_size=min(a.batch_size,max(1,len(pts))),max_points=0,type_hint=dtype,route_top_k=0)
            raw=list(res.get("results") or [])
        except Exception as e:
            per.append({"file":cid,"error":f"{type(e).__name__}: {e}"});agg["parse_error"]+=1;continue
        exp=set(expected.get(cid) or set());got={x.get("code") for x in raw if x.get("state")=="fail"}
        row={"file":cid,"expected":len(exp),"predicted":len(got),"tp":len(exp&got),"extra":len(got-exp),"miss":len(exp-got),
             "miss_points":sorted(exp-got),"extra_points":sorted(got-exp),
             "extra_review":len([x for x in raw if x.get("state")=="fail" and x.get("code") not in exp]),
             "states":res.get("summary")}
        per.append(row);agg["files"]+=1
        for k in ("expected","predicted","tp","extra","miss"): agg[k]+=row[k]
    agg["recall"]=round(agg["tp"]/agg["expected"],4) if agg["expected"] else 0
    agg["precision"]=round(agg["tp"]/agg["predicted"],4) if agg["predicted"] else 0
    out={"scenario":kind,"mode":"oracle_point_full","note":"点集来自答案（oracle）；规则判据来自真实点库；不是路由/泛化准确率","files":agg["files"],"batch_size":a.batch_size,"aggregate":agg,"per_file":per,"work":str(work)}
    (work/"report.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"scenario":kind,"files":agg["files"],"aggregate":agg},ensure_ascii=False,indent=2));return 0

if __name__=="__main__":sys.exit(main())
