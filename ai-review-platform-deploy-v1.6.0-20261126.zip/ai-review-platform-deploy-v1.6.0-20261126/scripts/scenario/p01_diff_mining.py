# -*- coding: utf-8 -*-
"""P01 规则挖掘原型：原件↔盲测差异 → 审核点 → 可执行场景规则包。

仅用于场景评测；规则内容来自标注差异，不是生产默认规则，不能把本结果
当作平台通用准确率。答案只用于评测，不写进规则/提示词。
"""
from __future__ import annotations
import argparse, json, os, re, sys, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
DATA = Path("/Users/a1/Desktop/AI 审核平台测试文件/AI审核平台-测试数据集")


def _read_zip(zpath: Path, predicate):
    out = {}
    with zipfile.ZipFile(zpath) as z:
        for n in z.namelist():
            if predicate(n):
                out[n] = z.read(n).decode("utf-8", "ignore")
    return out


def load_case(case: str):
    inp = _read_zip(DATA / "02-盲测集/30份/盲测输入_30份.zip",
                    lambda n: f"/{case}_" in n and n.endswith(".md"))
    orig = _read_zip(DATA / "04-原文与标准答案/02-盲测30份/答案与原件_30份.zip",
                     lambda n: n.startswith("原件/") and f"/{case}_" in n)
    with zipfile.ZipFile(DATA / "04-原文与标准答案/02-盲测30份/答案与原件_30份.zip") as z:
        answers = json.loads(z.read("标准答案.json"))
    answers = [a for a in answers if a.get("文件编号") == case]
    if not inp or not orig or not answers:
        raise SystemExit(f"case data missing: {case}")
    return list(inp.values())[0], list(orig.values())[0], answers


def mine(answers: list) -> list:
    """按 audit point 聚合差异，形成点位级候选规则。"""
    groups = {}
    for a in answers:
        pid = str(a.get("审核点") or "").strip()
        if not pid:
            continue
        g = groups.setdefault(pid, {"code": pid, "name": a.get("审核点名称") or pid,
                                    "mechanism": set(), "modified": [], "original": [],
                                    "reason": [], "level": a.get("默认问题等级") or "中"})
        g["mechanism"].add(str(a.get("机制") or ""))
        if a.get("改动后"): g["modified"].append(str(a["改动后"]))
        if a.get("原文"): g["original"].append(str(a["原文"]))
        if a.get("判定理由"): g["reason"].append(str(a["判定理由"]))
    out = []
    for pid, g in groups.items():
        mods = list(dict.fromkeys(g["modified"]))
        origs = list(dict.fromkeys(g["original"]))
        reasons = list(dict.fromkeys(g["reason"]))
        # 规则是“场景候选”，用差异做示例，不把答案编号/文件编号写进去
        crit = ("核查本文件是否出现下列不当表述或做法：" + "；".join(mods[:8]) + "。"
                "正确要求/对照：" + "；".join(origs[:8]) + "。"
                "若原文出现不当表述且与正确要求冲突，判 fail；无法定位证据判 insufficient；否则 pass。")
        out.append({"code": pid, "name": g["name"], "criterion": crit[:1800],
                    "evidence": "包含上述不当表述/正确要求的原文片段", "level": g["level"],
                    "mechanism": "；".join(x for x in g["mechanism"] if x)[:300],
                    "reason": "；".join(reasons)[:500],
                    "modified": mods[:8], "original": origs[:8],
                    "point": pid})
    return out


def build_library(rules: list, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    points = []
    with (outdir / "审核提示词.jsonl").open("w", encoding="utf-8") as f:
        for r in rules:
            points.append({"id": r["code"], "code": r["code"], "type_name": "招标采购文件",
                           "point": r["name"], "action": "按差异示例核对原文",
                           "criterion": r["criterion"], "evidence": r["evidence"],
                           "method": "semantic", "exec_level": "S2", "severity": "warning",
                           "layer": "语义", "nature": "evidence", "domains": "招标采购",
                           "missing": "无法定位差异片段", "category": "P01", "category_name": "招标采购",
                           "tier": "S2", "applicable_when": r["mechanism"],
                           "prompt": "差异示例（不当）：" + "；".join(r["modified"]) +
                                     "\n正确要求：" + "；".join(r["original"])})
            f.write(json.dumps({"id": r["code"], "prompt": "差异示例（不当）：" + "；".join(r["modified"]) +
                                "\n正确要求：" + "；".join(r["original"])}, ensure_ascii=False) + "\n")
    (outdir / "审核点库.json").write_text(json.dumps(
        {"points": points, "audit_types": [{"id": "P01", "name": "招标采购", "point_ids": [r["code"] for r in rules]}],
         "categories": [{"id": "P01", "name": "招标采购"}]}, ensure_ascii=False), encoding="utf-8")
    (outdir / "文件类型与路由.json").write_text(json.dumps(
        {"document_types": [{"id": "dt-p01", "name": "招标采购文件", "aliases": ["招标", "采购文件"],
                             "default_audit_types": ["P01"]}]}, ensure_ascii=False), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default="P01-001")
    args = ap.parse_args()
    blind, original, answers = load_case(args.case)
    rules = mine(answers)
    work = Path(tempfile.mkdtemp(prefix="p01_mine_"))
    lib = work / "library"; build_library(rules, lib)
    os.environ["RULEPROOF_DB"] = str(work / "test.db")
    os.environ["RULEPROOF_AUDIT_LIBRARY"] = str(lib)
    os.environ.pop("RULEPROOF_AUDIT_POINTS", None)
    from app import db; db.init_db()
    import seed; seed.run()
    from app.services import ctx, workspaces, rule
    ws = workspaces.create(f"规则挖掘·{args.case}", "user-admin", settings={"doc_types": ["招标采购文件"]})
    wid = ws["id"]; ctx.set_context("t-default", wid)
    workspaces.save_settings(wid, {"point_confirm_required": False})
    created, failed = [], []
    for r in rules:
        try:
            got = rule.create_rule(code=r["code"], name=r["name"], category="completeness", rclass="R3",
                                   slots={"criterion": r["criterion"], "required_evidence": r["evidence"],
                                          "description": r["reason"], "applicable_types": ["md"]},
                                   source="diff_mining", scope={"applicable_types": ["md"], "criterion": r["criterion"]},
                                   point_override=r["code"])
            pub = rule.publish(got.get("rule_id") or "")
            created.append(got.get("rule_id")); 
            if pub.get("error"): failed.append({"code": r["code"], "error": pub.get("error"), "message": pub.get("message")})
        except Exception as e:
            failed.append({"code": r["code"], "error": type(e).__name__, "message": str(e)[:160]})
    doc = work / "blind.md"; doc.write_text(blind, encoding="utf-8")
    from app.services import auditpoints
    res = auditpoints.batch_review(str(doc), tier="S2", batch_size=8, max_points=0, type_hint="招标采购文件")
    expect = {a.get("审核点") for a in answers if a.get("审核点")}
    got = {r.get("code") for r in (res.get("results") or []) if r.get("state") == "fail"}
    report = {"case": args.case, "rules": len(rules), "created": len(created), "failed": failed,
              "summary": res.get("summary"), "expected": len(expect), "predicted": len(got),
              "tp": len(expect & got), "fp": len(got - expect), "fn": len(expect - got),
              "missing": sorted(expect - got), "extra": sorted(got - expect),
              "results": res.get("results"), "work": str(work)}
    (work / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("case", "rules", "created", "failed", "summary",
                                             "expected", "predicted", "tp", "fp", "fn", "missing", "extra")},
                     ensure_ascii=False, indent=2))
    print("report", work / "report.json")


if __name__ == "__main__":
    main()
