# -*- coding: utf-8 -*-
"""第1包 招标采购：规则改写/导入 + 单文档真实审核（原型）。
不写死答案；答案只用于评测，不进入规则/提示词。
"""
from __future__ import annotations
import argparse, json, os, re, shutil, sys, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
DATA = Path("/Users/a1/Desktop/AI 审核平台测试文件/AI审核平台-测试数据集")


def parse_rules(md: str) -> list:
    chunks = re.split(r"^###\s+", md, flags=re.M)[1:]
    out = []
    for ch in chunks:
        lines = ch.splitlines()
        if not lines: continue
        m = re.match(r"([A-Z0-9]+-[A-Z0-9]+)[　\s]+(.+)", lines[0].strip())
        if not m: continue
        code, name = m.group(1), m.group(2).strip()
        fields = {}
        for ln in lines[1:]:
            mm = re.match(r"-\s*([^：:]+)[：:]\s*(.*)", ln.strip())
            if mm: fields[mm.group(1).strip()] = mm.group(2).strip()
        out.append({"code": code, "name": name, "fields": fields})
    return out


def build_library(rules: list, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    points = []
    for r in rules:
        f = r["fields"]
        points.append({
            "id": r["code"], "code": r["code"], "type_name": "招标采购文件",
            "point": r["name"], "action": f.get("核查步骤", ""),
            "criterion": f.get("通过判据", ""), "evidence": f.get("所需证据", ""),
            "method": "semantic", "exec_level": "S2", "severity": "warning",
            "layer": "语义", "nature": "evidence", "domains": "招标采购",
            "missing": f.get("缺证处理", ""), "category": "P01",
            "category_name": "招标采购", "family": "P01",
            "tier": "S2", "applicable_when": f.get("适用条件", ""),
            "exception": f.get("例外与边界", ""),
            "trigger": f.get("适用条件", ""),
            "prompt": "\n".join(x for x in [f.get("核查步骤", ""), "适用：" + f.get("适用条件", ""), "例外：" + f.get("例外与边界", ""), "缺证：" + f.get("缺证处理", "")] if x.strip()),
        })
    (outdir / "审核点库.json").write_text(json.dumps(
        {"points": points, "audit_types": [{"id": "P01", "name": "招标采购", "point_ids": [r["code"] for r in rules]}],
         "categories": [{"id": "P01", "name": "招标采购"}]}, ensure_ascii=False), encoding="utf-8")
    (outdir / "文件类型与路由.json").write_text(json.dumps(
        {"document_types": [{"id": "dt-p01", "name": "招标采购文件", "aliases": ["招标", "采购文件", "投标"],
                             "default_audit_types": ["P01"]}]}, ensure_ascii=False), encoding="utf-8")
    with (outdir / "审核提示词.jsonl").open("w", encoding="utf-8") as f:
        for r in rules:
            ff = r["fields"]
            pr = "\n".join(x for x in [ff.get("核查步骤", ""), "适用：" + ff.get("适用条件", ""), "例外：" + ff.get("例外与边界", ""), "缺证：" + ff.get("缺证处理", "")] if x.strip())
            f.write(json.dumps({"id": r["code"], "prompt": pr}, ensure_ascii=False) + "\n")
    return points


def import_rules(rules: list, point_ids: set):
    from app.services import rule
    created, failed = [], []
    for r in rules:
        f = r["fields"]
        slots = {
            "criterion": f.get("通过判据", "") or r["name"],
            "required_evidence": f.get("所需证据", ""),
            "description": f.get("核查步骤", "")[:500],
            "applicable_types": ["md"],
            "on_insufficient": "abstain",
        }
        try:
            got = rule.create_rule(code=r["code"], name=r["name"], category="completeness", rclass="R3",
                                   slots=slots, source="p01_scenario",
                                   scope={"applicable_types": ["md"], "criterion": slots["criterion"]},
                                   point_override=r["code"] if r["code"] in point_ids else "")
            pub = rule.publish(got.get("rule_id") or "")
            created.append({"code": r["code"], "rule_id": got.get("rule_id"), "publish": pub})
            if pub.get("error"):
                failed.append({"code": r["code"], "error": pub.get("error"), "message": pub.get("message")})
        except Exception as e:
            failed.append({"code": r["code"], "error": type(e).__name__, "message": str(e)[:200]})
    return created, failed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default="P01-001")
    ap.add_argument("--max-points", type=int, default=0)
    ap.add_argument("--import-only", action="store_true")
    args = ap.parse_args()
    work = Path(tempfile.mkdtemp(prefix="p01_scene_"))
    libdir = work / "library"
    rules_md = DATA / "05-规则与审核点库/03-包级审核规则/包级审核规则.md"
    rules = parse_rules(rules_md.read_text(encoding="utf-8"))
    print("rules", len(rules), rules[0]["code"], rules[-1]["code"])
    points = build_library(rules, libdir)
    os.environ["RULEPROOF_DB"] = str(work / "test.db")
    os.environ["RULEPROOF_AUDIT_LIBRARY"] = str(libdir)
    os.environ.pop("RULEPROOF_AUDIT_POINTS", None)
    from app import db; db.init_db()
    import seed; seed.run()
    from app.services import ctx, workspaces
    ws = workspaces.create("场景·第1包 招标采购", "user-admin", settings={"doc_types": ["招标采购文件"]})
    print("workspace", ws)
    wid = ws.get("id") or ws.get("workspace_id")
    ctx.set_context("t-default", wid)
    # 空间点位门禁保持默认关闭，先验证真实执行；生产应逐点确认
    workspaces.save_settings(wid, {"point_confirm_required": False})
    created, failed = import_rules(rules, {p["id"] for p in points})
    print("rules_created", len(created), "publish_failed", len(failed), "first_fail", failed[:2])
    if args.import_only:
        print(json.dumps({"work": str(work), "workspace": wid, "rules": len(rules),
                          "created": len(created), "failed": failed[:5]}, ensure_ascii=False))
        return
    # 解压目标文档
    docs_dir = work / "docs"; docs_dir.mkdir()
    zpath = DATA / "02-盲测集/30份/盲测输入_30份.zip"
    picked = None
    with zipfile.ZipFile(zpath) as z:
        for n in z.namelist():
            if Path(n).name.startswith(args.case + "_") and n.endswith(".md"):
                picked = docs_dir / Path(n).name
                picked.write_bytes(z.read(n)); break
    if not picked:
        raise SystemExit("case not found")
    print("doc", picked.name, picked.stat().st_size)
    from app.services import auditpoints
    # 真实模型执行；不改答案
    res = auditpoints.batch_review(str(picked), tier="S2", batch_size=8,
                                   max_points=args.max_points, type_hint="招标采购文件")
    print("summary", json.dumps(res.get("summary") or {}, ensure_ascii=False))
    print("results", len(res.get("results") or []), "findings", len(res.get("findings") or []))
    for x in (res.get("results") or [])[:6]:
        print("sample", {k: x.get(k) for k in ("code", "state", "confidence", "rationale", "quote")})
    (work / "results.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    # 答案只用于对照，不参与判定
    ans_zip = DATA / "04-原文与标准答案/02-盲测30份/答案与原件_30份.zip"
    if ans_zip.exists():
        with zipfile.ZipFile(ans_zip) as z:
            ans = json.loads(z.read("标准答案.json"))
        expect = {a.get("审核点") for a in ans if a.get("文件编号") == args.case}
        got = {r.get("code") for r in (res.get("results") or []) if r.get("state") == "fail"}
        print("eval", {"expected": len(expect), "predicted_fail": len(got),
                       "tp": len(expect & got), "fp": len(got - expect), "fn": len(expect - got),
                       "missing_sample": sorted(expect - got)[:8], "extra_sample": sorted(got - expect)[:8]})
    print(json.dumps({"work": str(work), "workspace": wid, "doc": str(picked)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
