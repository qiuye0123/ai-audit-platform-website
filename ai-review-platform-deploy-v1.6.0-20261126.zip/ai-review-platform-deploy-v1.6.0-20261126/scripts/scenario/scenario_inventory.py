# -*- coding: utf-8 -*-
"""测试文件夹全量盘点：按可审核场景分类，不启动模型。"""
from __future__ import annotations
import json, zipfile, collections
from pathlib import Path

DATA = Path("/Users/a1/Desktop/ai 审核平台测试文件/AI审核平台-测试数据集")


def zip_names(p):
    try:
        with zipfile.ZipFile(p) as z:
            return z.namelist()
    except Exception:
        return []


def json_in_zip(p, name):
    try:
        with zipfile.ZipFile(p) as z:
            return json.loads(z.read(name))
    except Exception:
        return None


def main():
    out = {"root": str(DATA), "scenarios": [], "skipped": []}
    # P01
    p01_ans_zip = DATA / "04-原文与标准答案/02-盲测30份/答案与原件_30份.zip"
    p01_in_zip = DATA / "02-盲测集/30份/盲测输入_30份.zip"
    p01_ans = json_in_zip(p01_ans_zip, "标准答案.json") or []
    p01_rules = DATA / "05-规则与审核点库/03-包级审核规则/包级审核规则.md"
    out["scenarios"].append({
        "id": "p01_tender", "name": "第1包 招标采购", "workspace": "场景·第1包 招标采购",
        "docs": len([n for n in zip_names(p01_in_zip) if n.endswith(".md")]),
        "answers": len(p01_ans), "answer_cases": len({x.get("文件编号") for x in p01_ans}),
        "rules": 83, "rules_source": str(p01_rules), "has_paired_diff": True,
        "has_blind": True, "recommendation": "全量规则导入；差异规则；模型抽测"
    })
    # CT
    ct_ans = json.load(open(DATA / "04-原文与标准答案/03-盲测44份/标准答案.json", encoding="utf-8"))
    ct_in = DATA / "02-盲测集/44份/盲测输入_44份.zip"
    out["scenarios"].append({
        "id": "ct_44", "name": "44 份公开招标/采购文件", "workspace": "场景·44份招标采购",
        "docs": len([n for n in zip_names(ct_in) if n.endswith(".md")]),
        "answers": len(ct_ans), "answer_cases": len({x.get("文件编号") for x in ct_ans}),
        "rules": 0, "rules_source": "", "has_paired_diff": True,
        "has_blind": True, "recommendation": "从差异挖规则；先全量覆盖，再模型抽测"
    })
    # BX
    bx_ans = json.load(open(DATA / "04-原文与标准答案/04-盲测50份合同/答案与原件/标准答案.json", encoding="utf-8"))
    bx_in = DATA / "02-盲测集/50份合同/盲测输入.zip"
    out["scenarios"].append({
        "id": "bx_contracts", "name": "合同 20 份（文件名写50份，实际20份）", "workspace": "场景·合同审核",
        "docs": len([n for n in zip_names(bx_in) if n.endswith(".md")]),
        "answers": len(bx_ans), "answer_cases": len({x.get("case_id") for x in bx_ans}),
        "rules": 0, "rules_source": "", "has_paired_diff": False,
        "has_blind": True, "recommendation": "有答案但无原文/改动对；从 issue/reason 生成规则，只能做弱规则/抽测"
    })
    # WF
    wf_ans = DATA / "04-原文与标准答案/01-WF-30份/标准答案.json"
    wf_docs = list((DATA / "04-原文与标准答案/01-WF-30份").glob("WF-*.pdf"))
    out["scenarios"].append({
        "id": "wf_30", "name": "WF 30 份 PDF", "workspace": "场景·WF 30份",
        "docs": len(wf_docs), "answers": len(json.load(open(wf_ans, encoding="utf-8"))) if wf_ans.exists() else 0,
        "answer_cases": 30, "rules": 0, "rules_source": "",
        "has_paired_diff": False, "has_blind": False,
        "recommendation": "只有原件 PDF + 答案，没有盲测输入/规则；不做模型全量，先抽 PDF 解析"
    })
    # Food
    food_rules = DATA / "05-规则与审核点库/04-食品工艺书规则/rules.json"
    out["scenarios"].append({
        "id": "food_sample", "name": "食品工艺书样例", "workspace": "场景·食品工艺",
        "docs": 3, "answers": 0, "answer_cases": 0,
        "rules": len(json.load(open(food_rules, encoding="utf-8"))) if food_rules.exists() else 0,
        "rules_source": str(food_rules), "has_paired_diff": False,
        "has_blind": False, "recommendation": "3 个 xlsx + 14 条规则；无可对照答案，做规则/解析冒烟，不算准确率"
    })
    out["skipped"] = [
        {"id": "public", "reason": "FinED/FIND/CUAD/CAIL 是学术抽取/法律数据集，不是平台可审核的成对‘原文+答案’场景；可做 KIE，不混入审核准确率"},
        {"id": "reports", "reason": "测试报告/PRD/技术方案不是审核输入，只用于规则来源"},
    ]
    total_docs = sum(x["docs"] for x in out["scenarios"])
    total_answers = sum(x["answers"] for x in out["scenarios"])
    out["totals"] = {"docs": total_docs, "answers": total_answers,
                     "full_e2e_ready": ["p01_tender", "ct_44"],
                     "weak_rule_ready": ["bx_contracts"],
                     "not_audit_ready": ["wf_30", "food_sample"]}
    (Path("docs/reports/evidence")).mkdir(parents=True, exist_ok=True)
    (Path("docs/reports/evidence/scenario_inventory_20261116.json")).write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    md = ["# 测试文件夹场景盘点（2026-11-16）", "", f"根目录：`{DATA}`", "",
          "| 场景 | 文档 | 答案 | 规则 | 成对差异 | 盲测原文 | 建议 |", "|---|---:|---:|---:|---|---|---|"]
    for s in out["scenarios"]:
        md.append(f"| {s['name']} | {s['docs']} | {s['answers']} | {s['rules']} | "
                  f"{'有' if s['has_paired_diff'] else '无'} | {'有' if s['has_blind'] else '无'} | {s['recommendation']} |")
    md += ["", f"合计文档：{total_docs}；答案：{total_answers}", "", "## 跳过", ""]
    for x in out["skipped"]:
        md.append(f"- `{x['id']}`：{x['reason']}")
    md += ["", "## 结论", "",
           "- P01 和 CT 有盲测原文 + 答案 + 成对差异：可以做规则导入与差异规则测试。",
           "- BX 有答案和盲测但无原文/改动对：只能做弱规则/抽测，不能宣称完整规则覆盖。",
           "- WF 有 PDF 原件和答案，但没有盲测输入/规则：不做模型全量准确率。",
           "- 食品只有样例和规则，没有同批答案：只做冒烟。",
           "- 公开数据集不是审核场景，不混入准确率。"]
    (Path("docs/reports/测试文件夹场景盘点_20261116.md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps(out["totals"], ensure_ascii=False))
    for s in out["scenarios"]:
        print(s["id"], s["docs"], s["answers"], s["rules"], s["has_paired_diff"], s["has_blind"])


if __name__ == "__main__":
    main()
