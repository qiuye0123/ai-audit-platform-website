# -*- coding: utf-8 -*-
"""全局功能流程架构 v5：左侧阶段合并成整块，右侧细项带状态灯（绿/黄/红）。"""
import json
from PIL import Image, ImageDraw, ImageFont

def F(s, b=False):
    p = "/System/Library/Fonts/STHeiti Medium.ttc" if b else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try: return ImageFont.truetype(p, s)
    except Exception: return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", s)

STAGES = [
 ("① 规则沉淀", "#3370FF", ["规则来源：上传文档","规则来源：一段话","规则来源：手工填写","文本清洗与分段","规则提炼（LLM 四元组）","实体识别：指标名","实体识别：单位","本体门槛：别名归一","本体门槛：未识别提示","冲突检测：区间无交集","冲突检测：同向冗余","规则草稿入库","规则提交审批","规则发布生效","决策表：条件组合","决策表：结论与严重度","参数：阈值","参数：开关","参数：灰度范围","接线矩阵：点位↔本体","接线矩阵：点位↔Jev","接线矩阵：点位↔反馈"]),
 ("② 解析", "#00B96B", ["文件上传","格式识别","体积与份数校验","xlsx 工作表遍历","docx 段落与表格","pdf 页文本抽取","md 行解析","合并单元格还原","表头识别","扫描件检测","OCR 识别","解析报告：状态","解析报告：缺口原因","解析报告：原始文件名","事实抽取：数值","事实抽取：单位换算","事实抽取：范围","事实抽取：日期","结构化抽取：百分比基数","结构化抽取：分段费率","结构化抽取：时序余额","结构化抽取：勾选项","Anchor：Sheet+Cell","Anchor：第N段","Anchor：第N页"]),
 ("③ 路由", "#FF8800", ["文档类型识别（104）","审核类型识别（74）","A~G 大类过滤","点位路由（319）","场景包匹配","意图识别 focus","点位裁剪","执行计划：确定性","执行计划：语义","执行计划：证据要求"]),
 ("④ 判定", "#7F3BF5", ["读取行为参数","参数：启用状态","参数：忽略词","参数：严重度映射","确定性执行器判定","断言：range","断言：equality","断言：sum_consistency","断言：presence","断言：ordering","断言：contiguity","断言：set_membership","模型判定入口","智能体版本读取","智能体提示词","模型路由解析","LLM 调用","多采样投票","判定缓存","Jev 置信度","Jev 弃权判定","证据校验：引文回查","五态：pass","五态：fail","五态：na","五态：insufficient","五态：unknown"]),
 ("⑤ 结论", "#F54A45", ["点位结论落库","同标题合并","引擎优先去重","严重度聚合","待复核统计","覆盖率统计","批次号写入","报告门禁判断","HTML 报告","DOCX 报告","PDF 报告","证据定位展示"]),
 ("⑥ 人工反馈", "#0FA6A6", ["定位复核：原文高亮","确认问题","标记误报","补充证据","手动新增发现","反馈归一（五类）","写 decision 表","Jev 样本累积","健康度：命中","健康度：override","抽样复核"]),
 ("⑦ 进化", "#7F3BF5", ["归因：模型原因","归因：兜底原因","反向反馈计数","≥3 次触发","候选快照 before","候选快照 after","参数调整","行为调整","新规则沉淀","草稿→发布","回滚到 before","冻结改进器","规则回放","影响面评估","冲突复检","本体修订候选","I-gain 度量"]),
]

GREEN = {"文件上传","格式识别","解析报告：状态","解析报告：缺口原因","解析报告：原始文件名",
 "规则提炼（LLM 四元组）","规则草稿入库","规则提交审批","规则发布生效","冲突检测：区间无交集",
 "决策表：条件组合","决策表：结论与严重度","参数：阈值","参数：开关","参数：灰度范围",
 "接线矩阵：点位↔本体","接线矩阵：点位↔Jev","接线矩阵：点位↔反馈",
 "断言：range","断言：equality","断言：sum_consistency","断言：presence","断言：ordering",
 "断言：contiguity","断言：set_membership","确定性执行器判定","读取行为参数",
 "参数：启用状态","参数：忽略词","参数：严重度映射","智能体版本读取","智能体提示词",
 "模型路由解析","LLM 调用","Jev 置信度","Jev 弃权判定","证据校验：引文回查",
 "五态：pass","五态：fail","五态：na","五态：insufficient","五态：unknown",
 "点位结论落库","待复核统计","覆盖率统计","报告门禁判断","HTML 报告","DOCX 报告","PDF 报告",
 "定位复核：原文高亮","确认问题","标记误报","补充证据","手动新增发现","反馈归一（五类）",
 "写 decision 表","Jev 样本累积","归因：模型原因","归因：兜底原因","反向反馈计数","≥3 次触发",
 "候选快照 before","候选快照 after","参数调整","行为调整","新规则沉淀","草稿→发布",
 "回滚到 before","冻结改进器","规则回放"}
RED = {"本体门槛：别名归一","本体门槛：未识别提示","结构化抽取：百分比基数","结构化抽取：分段费率",
 "结构化抽取：时序余额","结构化抽取：勾选项","冲突复检","本体修订候选","I-gain 度量","多采样投票"}
# 其余默认 yellow（未验证 / 有条件）

_LIVE = {}
try:
    _d = json.load(open("docs/blind/功能状态.json"))
    _LIVE = {k: v.get("status", "yellow") for k, v in (_d.get("items") or {}).items()}
except Exception:
    _LIVE = {}

def status_of(t):
    if t in _LIVE: return _LIVE[t]           # 优先用探针生成的状态
    if t in GREEN: return "green"
    if t in RED: return "red"
    return "yellow"

PER, BW, BH, GX, GY = 9, 330, 76, 30, 34
LABW, ML, MT = 230, 60, 210
W = ML + LABW + 60 + PER * BW + (PER - 1) * GX + 60

rows = []
for si, (name, color, items) in enumerate(STAGES):
    for i in range(0, len(items), PER):
        rows.append((si, items[i:i + PER]))
H = MT + len(rows) * (BH + GY) + 130
img = Image.new("RGB", (W, H), "#FFFFFF"); d = ImageDraw.Draw(img)
d.text((60, 40), "AI 审核平台 · 全局功能流程架构（状态灯版）", font=F(42, True), fill="#1F2329")
d.text((60, 98), "● 绿=已验证生效且准确　● 黄=有条件/未验证　● 红=未生效或有已知问题", font=F(22), fill="#646A73")
cnt = {"green": 0, "yellow": 0, "red": 0}

# 左侧：每个阶段合并成一个整块
stage_y = {}
for si, (name, color, items) in enumerate(STAGES):
    idxs = [i for i, r in enumerate(rows) if r[0] == si]
    y1 = MT + idxs[0] * (BH + GY); y2 = MT + idxs[-1] * (BH + GY) + BH
    stage_y[si] = (y1, y2)
    d.rounded_rectangle([ML, y1, ML + LABW, y2], radius=12, fill=color)
    f = F(26, True); tw = d.textlength(name, font=f)
    ty = (y1 + y2) / 2 - 16
    d.text((ML + (LABW - tw) / 2, ty), name, font=f, fill="#FFFFFF")

for ri, (si, items) in enumerate(rows):
    _, color, _ = STAGES[si]
    y = MT + ri * (BH + GY)
    padded = list(items) + [None] * (PER - len(items))   # 占位，保证每行等宽
    for ci, it in enumerate(padded):
        if it is None:
            x = ML + LABW + 60 + ci * (BW + GX)
            d.rounded_rectangle([x, y, x + BW, y + BH], radius=8, outline="#E5E6EB",
                                width=2, fill="#FAFAFA")
            continue
        x = ML + LABW + 60 + ci * (BW + GX)
        st = status_of(it); cnt[st] += 1
        d.rounded_rectangle([x, y, x + BW, y + BH], radius=8, outline=color, width=3, fill="#FFFFFF")
        dc = {"green": "#00B42A", "yellow": "#FF9A2E", "red": "#F53F3F"}[st]
        d.ellipse([x + 12, y + BH / 2 - 7, x + 26, y + BH / 2 + 7], fill=dc)
        f3 = F(17); txt = it
        while d.textlength(txt, font=f3) > BW - 48 and len(txt) > 4:
            txt = txt[:-2]
        tw2 = d.textlength(txt, font=f3)
        d.text((x + 34 + (BW - 48 - tw2) / 2, y + BH / 2 - 10), txt, font=f3, fill="#1F2329")
        if ci < len(padded) - 1:
            if ri % 2 == 0:      # 左 → 右
                d.line([(x + BW, y + BH // 2), (x + BW + GX, y + BH // 2)], fill=color, width=3)
                d.polygon([(x + BW + GX, y + BH // 2), (x + BW + GX - 9, y + BH // 2 - 6),
                           (x + BW + GX - 9, y + BH // 2 + 6)], fill=color)
            else:                # 右 → 左
                d.line([(x - GX, y + BH // 2), (x, y + BH // 2)], fill=color, width=3)
                d.polygon([(x, y + BH // 2), (x - 9, y + BH // 2 - 6), (x - 9, y + BH // 2 + 6)], fill=color)

X0 = ML + LABW + 60
for ri in range(len(rows) - 1):
    # 跨模块不画箭头：只连接同一阶段内的相邻行
    if rows[ri][0] != rows[ri + 1][0]:
        continue
    # 每行已补齐到 PER，蛇形连接固定为：偶行右端 ↔ 奇行右端；奇行左端 ↔ 偶行左端
    end_c_prev = (PER - 1) if ri % 2 == 0 else 0
    end_c_next = (PER - 1) if (ri + 1) % 2 == 1 else 0
    x_from = X0 + end_c_prev * (BW + GX) + BW // 2
    x_to = X0 + end_c_next * (BW + GX) + BW // 2
    y_from = MT + ri * (BH + GY) + BH
    y_gap = MT + ri * (BH + GY) + BH + GY // 2
    y_to = MT + (ri + 1) * (BH + GY) - 2
    d.line([(x_from, y_from), (x_from, y_gap)], fill="#3370FF", width=4)
    if abs(x_from - x_to) > 1:
        d.line([(x_from, y_gap), (x_to, y_gap)], fill="#3370FF", width=4)
    d.line([(x_to, y_gap), (x_to, y_to)], fill="#3370FF", width=4)
    d.polygon([(x_to, y_to), (x_to - 7, y_to - 10), (x_to + 7, y_to - 10)], fill="#3370FF")

d.text((60, H - 78), f"绿 {cnt['green']} · 黄 {cnt['yellow']} · 红 {cnt['red']}（共 {sum(cnt.values())} 项）；黄/红需逐项补齐并加门禁，目标全绿。",
       font=F(21, True), fill="#1F2329")
d.text((60, H - 42), "左列为阶段合并块；右侧每框一个功能细项；连接线只走行内与行间空白。", font=F(19), fill="#8F959E")
img.save("docs/系统全局功能流程架构_v5.png")

data = {}
for si, (name, color, items) in enumerate(STAGES):
    for it in items:
        data[it] = {"stage": name, "status": status_of(it)}
if not _LIVE:
    json.dump({"items": data, "counts": cnt}, open("docs/blind/功能状态.json", "w"), ensure_ascii=False, indent=1)
print("saved", img.size, "counts", cnt)
