# -*- coding: utf-8 -*-
"""全局功能流程架构 v3：横向宽图，一列一段，一框一项，线只走列内与列间空白。"""
from PIL import Image, ImageDraw, ImageFont

def F(s, b=False):
    p = "/System/Library/Fonts/STHeiti Medium.ttc" if b else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try: return ImageFont.truetype(p, s)
    except Exception: return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", s)

STAGES = [
 ("① 规则沉淀", "#3370FF", ["规则来源：上传文档","规则来源：一段话","规则来源：手工填写","文本清洗与分段","规则提炼（LLM 四元组）","实体识别：指标名","实体识别：单位","本体门槛：别名归一","本体门槛：未识别提示","冲突检测：区间无交集","冲突检测：同向冗余","规则草稿入库","规则提交审批","规则发布生效","决策表：条件组合","决策表：结论与严重度","参数：阈值","参数：开关","参数：灰度范围","接线矩阵：点位↔本体","接线矩阵：点位↔Jev","接线矩阵：点位↔反馈"]),
 ("② 解析", "#00B96B", ["文件上传","格式识别","体积与份数校验","xlsx 工作表遍历","docx 段落与表格","pdf 页文本抽取","md 行解析","合并单元格还原","表头识别","扫描件检测","OCR 识别","解析报告：状态","解析报告：缺口原因","解析报告：原始文件名","事实抽取：数值","事实抽取：单位换算","事实抽取：范围","事实抽取：日期","结构化抽取：百分比基数","结构化抽取：分段费率","结构化抽取：时序余额","结构化抽取：勾选项","Anchor：Sheet+Cell","Anchor：第N段","Anchor：第N页"]),
 ("③ 路由", "#FF8800", ["文档类型识别（104）","审核类型识别（74）","A~G 大类过滤","点位路由（319）","场景包匹配","意图识别 focus","点位裁剪","执行计划：确定性","执行计划：语义","执行计划：证据要求"]),
 ("④ 判定", "#7F3BF5", ["读取行为参数","参数：启用状态","参数：忽略词","参数：严重度映射","确定性执行器判定","断言：range","断言：equality","断言：sum_consistency","断言：presence","断言：ordering","断言：contiguity","断言：set_membership","模型判定入口","智能体版本读取","智能体提示词","模型路由解析","LLM 调用","多采样投票","判定缓存","Jev 置信度","Jev 弃权判定","证据校验：引文回查","五态：pass","五态：fail","五态：na","五态：insufficient","五态：unknown"]),
 ("⑤ 结论", "#F54A45", ["点位结论落库","同标题合并","引擎优先去重","严重度聚合","待复核统计","覆盖率统计","批次号写入","报告门禁判断","HTML 报告","DOCX 报告","PDF 报告","证据定位展示"]),
 ("⑥ 人工反馈", "#0FA6A6", ["定位复核：原文高亮","确认问题","标记误报","补充证据","手动新增发现","反馈归一（五类）","写 decision 表","Jev 样本累积","健康度：命中","健康度：override","抽样复核"]),
 ("⑦ 进化", "#7F3BF5", ["归因：模型原因","归因：兜底原因","反向反馈计数","≥3 次触发","候选快照 before","候选快照 after","参数调整","行为调整","新规则沉淀","草稿→发布","回滚到 before","冻结改进器","规则回放","影响面评估","冲突复检","本体修订候选","I-gain 度量"]),
]

BW, BH, VG, SUBG = 330, 82, 28, 54
SUBS = 3
ML, MT = 120, 230
COLW = SUBS * BW + (SUBS - 1) * SUBG
CG = 120
W = ML + len(STAGES) * COLW + (len(STAGES) - 1) * CG + ML

def rows_for(n): return (n + SUBS - 1) // SUBS
ROWS = max(rows_for(len(s[2])) for s in STAGES)
H = MT + ROWS * (BH + VG) + 160

img = Image.new("RGB", (W, H), "#FFFFFF"); d = ImageDraw.Draw(img)
d.text((ML, 52), "AI 审核平台 · 全局功能流程架构（横向宽图 / 一项一框 / 不含账号与首页）", font=F(46, True), fill="#1F2329")
d.text((ML, 116), "七段从左至右：规则沉淀 → 解析 → 路由 → 判定 → 结论 → 人工反馈 → 进化；列内自上而下推进，列间仅用空白间隙连线", font=F(22), fill="#646A73")

def stage_geom(i):
    x = ML + i * (COLW + CG)
    return x

boxes = []
for i, (name, color, items) in enumerate(STAGES):
    x0 = stage_geom(i)
    d.rounded_rectangle([x0, MT - 74, x0 + COLW, MT - 22], radius=9, fill=color)
    tw = d.textlength(name, font=F(26, True))
    d.text((x0 + (COLW - tw) / 2, MT - 66), name, font=F(26, True), fill="#FFFFFF")
    n = rows_for(len(items))
    for k, it in enumerate(items):
        c, r = divmod(k, n)
        x = x0 + c * (BW + SUBG); y = MT + r * (BH + VG)
        d.rounded_rectangle([x, y, x + BW, y + BH], radius=8, outline=color, width=3, fill="#FFFFFF")
        f = F(18); txt = it
        while d.textlength(txt, font=f) > BW - 22 and len(txt) > 4:
            txt = txt[:-2]
        tw = d.textlength(txt, font=f)
        d.text((x + (BW - tw) / 2, y + BH / 2 - 11), txt, font=f, fill="#1F2329")
        boxes.append((i, c, r, x, y, color))

by = {}
for b in boxes: by.setdefault((b[0], b[1]), []).append(b)
for (i, c), lst in by.items():
    lst.sort(key=lambda b: b[2])
    for a, b2 in zip(lst, lst[1:]):
        d.line([(a[3] + BW // 2, a[4] + BH), (a[3] + BW // 2, b2[4])], fill=a[5], width=3)
        d.polygon([(a[3] + BW // 2 - 7, b2[4] - 10), (a[3] + BW // 2 + 7, b2[4] - 10), (a[3] + BW // 2, b2[4] - 1)], fill=a[5])

for i in range(len(STAGES) - 1):
    xs = stage_geom(i) + COLW
    xe = stage_geom(i + 1)
    y = MT + (BH // 2)
    d.line([(xs + 14, y), (xe - 14, y)], fill="#3370FF", width=4)
    d.polygon([(xe - 14, y), (xe - 26, y - 9), (xe - 26, y + 9)], fill="#3370FF")

d.text((ML, H - 86), "蓝线=段间主链（仅走列间空白）；同列内竖线=顺序推进；每框仅含一个功能项。", font=F(20), fill="#8F959E")
img.save("docs/系统全局功能流程架构_v3.png")
print("saved", img.size, "items", sum(len(s[2]) for s in STAGES), "rows", ROWS)
