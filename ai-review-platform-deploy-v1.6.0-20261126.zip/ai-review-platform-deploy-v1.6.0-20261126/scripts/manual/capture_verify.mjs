// 采集（带去重与页面断言）：每页截图前校验标题，内容哈希重复则跳过
import fs from 'fs'; import crypto from 'crypto';
const OUT = process.env.SHOT_DIR || '/tmp/shots_verify';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT || 9410}/json/list`)).json();
const page = t.find(x => x.type === 'page') || t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 1; const pend = new Map();
ws.addEventListener('message', ev => { const m = JSON.parse(ev.data);
  if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id);
    m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } });
await new Promise((r, j) => { ws.addEventListener('open', r, { once: true }); ws.addEventListener('error', j, { once: true }); });
const send = (method, params = {}) => { const i = id++; ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((res, rej) => pend.set(i, { resolve: res, reject: rej })); };
const ev = async e => (await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true })).result?.value;
const wait = ms => new Promise(r => setTimeout(r, ms));
await send('Page.enable'); await send('Runtime.enable');
await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
const BASE = process.env.BASE || 'http://127.0.0.1:8765';

const seen = new Map(); let n = 0, skipped = 0;
async function shot(name) {
  const r = await send('Page.captureScreenshot', { format: 'png' });
  const buf = Buffer.from(r.data, 'base64');
  const h = crypto.createHash('sha256').update(buf).digest('hex');
  if (seen.has(h)) { skipped++; console.log('SKIP dup', name, '==', seen.get(h)); return; }
  seen.set(h, name); n++;
  fs.writeFileSync(`${OUT}/${String(n).padStart(2, '0')}-${name}.png`, buf);
  console.log('shot', n, name);
}
// 登录
await send('Page.navigate', { url: `${BASE}/login` }); await wait(900);
await ev(`document.querySelector('#username').value='13800138000';document.querySelector('#password').value=${JSON.stringify(process.env.ADMIN_PW || '')};document.querySelector('#login-form').requestSubmit()`);
await wait(2600);
const logged = await ev(`!!document.querySelector('.side, aside, #view-home')`);
console.log('login', logged);

const pages = [
  ['规则库', '规则库'], ['决策表', '决策表'], ['冲突提醒', '冲突提醒'], ['规则进化', '规则进化'],
  ['本体建模', '本体建模'], ['账号管理', '账号管理'], ['消息中心', '消息中心'], ['项目列表', '项目列表'],
  ['新建规则', '新建规则'],
];
await shot('首页');
for (const [label, expect] of pages) {
  const ok = await ev(`(()=>{const els=[...document.querySelectorAll('.menu-item, [data-view], .nav a, button')];
    const e=els.find(x=>(x.textContent||'').trim()===${JSON.stringify(label)}); if(e){e.click();return true}
    return false})()`);
  await wait(1100);
  const head = await ev(`(document.querySelector('h1,h2,.page-title,#view-title')||{}).textContent||''`);
  const body = await ev(`(document.body.innerText||'').slice(0,400)`);
  if (!ok || !String(body).includes(expect)) { console.log('WARN page-mismatch', label, '| head=', String(head).slice(0,20)); }
  await shot(label);
}
// 详情：点击第一条规则
const clicked = await ev(`(()=>{const r=document.querySelector('.rule-row, .rule-item'); if(r){r.click();return true} return false})()`);
await wait(1200);
if (clicked) await shot('规则详情');
console.log(`TOTAL ${n} skipped ${skipped}`);
