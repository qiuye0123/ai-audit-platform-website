# -*- coding: utf-8 -*-
import math
from PIL import Image, ImageDraw, ImageFont

def F(s,b=False):
    p="/System/Library/Fonts/STHeiti Medium.ttc" if b else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try: return ImageFont.truetype(p,s)
    except Exception: return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc",s)

COLS=[("① 规则沉淀","#3370FF","#F3F7FF"),("② 解析","#00B96B","#F1FBF6"),
      ("③ 路由","#FF8800","#FFF7EE"),("④ 判定","#7F3BF5","#F7F3FF"),
      ("⑤ 结论","#F54A45","#FFF3F2"),("⑥ 人工反馈","#0FA6A6","#EFFAFB"),
      ("⑦ 进化","#7F3BF5","#F7F3FF")]
W,L,T,GAP=5600,100,240,92
CW=(W-2*L-GAP*6)//7
X=[L+i*(CW+GAP) for i in range(7)]
ROWH=104

NODES=[]   # (col,row,text,kind)
def N(col,row,text,kind="box"): NODES.append([col,row,text,kind])
N(0,0,"规则来源\n文档 / 一段话 / 手填","term")
N(0,1,"规则提炼\nparse_text / 拆解")
N(0,2,"本体门槛\n实体·别名对齐？","dia")
N(0,3,"冲突检测\n矛盾/重复/单位/集合","dia")
N(0,4,"规则库\n草稿→审批→发布")
N(0,5,"决策表\n条件组合→结论")
N(0,6,"参数：阈值/开关/灰度")
N(0,7,"接线矩阵\n点位·本体·Jev·反馈")
N(1,0,"文件上传\n≤100MB/≤3份","term")
N(1,1,"解析分派\nxlsx/docx/pdf/md")
N(1,2,"结构还原\n表头/段落/页/表")
N(1,3,"无文本层？","dia")
N(1,4,"OCR 视觉模型\n失败→failed")
N(1,5,"解析报告\nstatus+gaps 客户可见")
N(1,6,"事实抽取\n数值/范围/阈值/日期")
N(1,7,"结构化抽取\n基数%/分段/时序/勾选")
N(1,8,"Anchor 定位\nSheet!Cell/第N段")
N(2,0,"文档类型识别\n场景包 104")
N(2,1,"审核类型 74 / A~G")
N(2,2,"点位路由 319")
N(2,3,"意图识别 focus")
N(2,4,"执行计划\n确定性/语义分工")
N(3,0,"行为参数\n启用/灰度/忽略")
N(3,1,"有执行器？","dia")
N(3,2,"断言求值\n7 类断言+表达式")
N(3,3,"模型判定\njudge.points")
N(3,4,"智能体\n已发布版本")
N(3,5,"LLM 路由\nDB→env")
N(3,6,"Jev 弃权\n低置信→人工")
N(3,7,"证据校验\nquote 回查")
N(3,8,"五态\npass/fail/na/insufficient")
N(4,0,"去重归并")
N(4,1,"结论聚合\ncritical/弃权/待复核")
N(4,2,"audit_run 批次")
N(4,3,"报告门禁\n待复核>0→409","dia")
N(4,4,"报告输出\nHTML/DOCX/PDF")
N(5,0,"定位复核")
N(5,1,"确认/误报/补证/新增")
N(5,2,"decision+feedback\n五类归一")
N(5,3,"Jev 样本累积")
N(5,4,"规则健康度")
N(6,0,"归因\n模型/兜底")
N(6,1,"≥3 反向？","dia")
N(6,2,"rsi_candidate\nbefore/after")
N(6,3,"草稿→发布")
N(6,4,"回滚/冻结")
N(6,5,"规则回放")
N(6,6,"冲突复检")
N(6,7,"本体修正（未接）")
N(6,8,"I-gain（骨架）")

ROWS=max(n[1] for n in NODES)+1
H=T+ROWS*ROWH+140
img=Image.new("RGB",(W,H),"#fff"); d=ImageDraw.Draw(img)
RECTS=[]; SEGS=[]
def pos(col,row): return X[col], T+row*ROWH
d.text((L,56),"AI 审核平台 · 全局功能生效流程架构（不含账号/首页）",font=F(50,True),fill="#1F2329")
d.text((L,122),"七段链路：规则沉淀 → 解析 → 路由 → 判定 → 结论 → 人工反馈 → 进化沉淀",font=F(23),fill="#646A73")
for i,(nm,c,f) in enumerate(COLS):
    d.rounded_rectangle([X[i],172,X[i]+CW,214],radius=8,fill=c); RECTS.append((X[i],172,X[i]+CW,214))
    tw=d.textlength(nm,font=F(22,True)); d.text((X[i]+(CW-tw)//2,180),nm,font=F(22,True),fill="#fff")
def draw(n):
    col,row,text,kind=n; x,y=pos(col,row); h=84; w=CW
    c,f=COLS[col][1],COLS[col][2]
    if kind=="dia": d.polygon([(x+w//2,y),(x+w,y+h//2),(x+w//2,y+h),(x,y+h//2)],outline=c,width=3,fill="#fff")
    elif kind=="term": d.rounded_rectangle([x,y,x+w,y+h],radius=42,outline=c,width=3,fill=f)
    else: d.rounded_rectangle([x,y,x+w,y+h],radius=10,outline=c,width=3,fill=f)
    RECTS.append((x,y,x+w,y+h))
    ls=text.split("\n"); ty=y+(h-len(ls)*27)//2
    for s in ls:
        tw=d.textlength(s,font=F(19)); d.text((x+(w-tw)//2,ty),s,font=F(19),fill="#1F2329"); ty+=27
def arrow(p1,p2,c):
    d.line([p1,p2],fill=c,width=3); SEGS.append((p1,p2))
    a=math.atan2(p2[1]-p1[1],p2[0]-p1[0])
    for s in (0.42,-0.42): d.line([p2,(p2[0]-14*math.cos(a+s),p2[1]-14*math.sin(a+s))],fill=c,width=3)
for n in NODES: draw(n)
by={}
for n in NODES: by.setdefault(n[0],[]).append(n)
for col,items in by.items():
    items.sort(key=lambda n:n[1])
    for a,b in zip(items,items[1:]):
        x,y=pos(a[0],a[1]); x2,y2=pos(b[0],b[1])
        arrow((x+CW//2,y+88),(x2+CW//2,y2-6),"#8F959E")
LINKS=[((0,4),(1,0),"#3370FF"),((0,5),(2,2),"#3370FF"),((0,6),(3,0),"#3370FF"),
       ((1,8),(3,7),"#00B96B"),((2,4),(3,1),"#FF8800"),((3,8),(4,0),"#7F3BF5"),
       ((4,4),(5,0),"#F54A45"),((5,2),(6,0),"#0FA6A6"),((6,3),(0,4),"#7F3BF5"),
       ((6,6),(0,3),"#7F3BF5")]
for l in LINKS:
    a,b,c=l[0],l[1],l[2]
    x,y=pos(*a); x2,y2=pos(*b)
    arrow((x+CW,y+42),(x2,y2+42),c)
d.text((L,H-70),"蓝色=正向主链　绿色=解析→判定　紫色=进化回流　灰色=同列顺序；未接通环节见文档标注",font=F(19),fill="#8F959E")
img.save("docs/系统全局功能流程架构.png")
print("saved",img.size,"nodes",len(NODES))
