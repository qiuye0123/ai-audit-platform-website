# -*- coding: utf-8 -*-
"""生成审核全流程详细流程图（PNG，带线条箭头）。"""
import os
from PIL import Image, ImageDraw, ImageFont

W, H = 4200, 3000
FONT = "/System/Library/Fonts/Hiragino Sans GB.ttc"
def f(size, bold=False):
    path = "/System/Library/Fonts/STHeiti Medium.ttc" if bold else FONT
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", size)

img = Image.new("RGB", (W, H), "#FFFFFF")
d = ImageDraw.Draw(img)
C_LINE = "#8F959E"
C_TXT = "#1F2329"
C_MUTED = "#646A73"

STAGES = [
    ("① 文件接入", "#3370FF"),
    ("② 解析结构化", "#00B96B"),
    ("③ 类型识别与路由", "#FF8800"),
    ("④ 逐点判定", "#7F3BF5"),
    ("⑤ 结论聚合", "#F54A45"),
]
COLX = [120, 900, 1680, 2460, 3240]
NODEW, GAP = 640, 150

def box(x, y, w, h, text, color, dashed=False, fill="#FFFFFF"):
    r = 10
    d.rounded_rectangle([x, y, x + w, y + h], radius=r, outline=color, width=3, fill=fill)
    lines = text.split("\n")
    total = len(lines) * 34
    ty = y + (h - total) / 2
    for ln in lines:
        tw = d.textlength(ln, font=f(26))
        d.text((x + (w - tw) / 2, ty), ln, font=f(26), fill=C_TXT)
        ty += 34

def diamond(cx, cy, w, h, text, color="#F54A45"):
    d.polygon([(cx, cy - h/2), (cx + w/2, cy), (cx, cy + h/2), (cx - w/2, cy)],
              outline=color, width=3, fill="#FFFFFF")
    lines = text.split("\n")
    ty = cy - len(lines) * 17
    for ln in lines:
        tw = d.textlength(ln, font=f(24))
        d.text((cx - tw/2, ty), ln, font=f(24), fill=C_TXT)
        ty += 32

def arrow(p1, p2, label="", color=C_LINE, width=3):
    d.line([p1, p2], fill=color, width=width)
    import math
    ang = math.atan2(p2[1]-p1[1], p2[0]-p1[0])
    L, a = 16, 0.45
    for s in (a, -a):
        d.line([p2, (p2[0]-L*math.cos(ang+s), p2[1]-L*math.sin(ang+s))], fill=color, width=width)
    if label:
        mx, my = (p1[0]+p2[0])/2, (p1[1]+p2[1])/2
        d.text((mx+6, my-30), label, font=f(22), fill=C_MUTED)

def poly(points, label="", color=C_LINE):
    for i in range(len(points)-2):
        d.line([points[i], points[i+1]], fill=color, width=3)
    arrow(points[-2], points[-1], label, color)

# 标题
d.text((120, 70), "AI 审核平台 · 审核全流程详解图", font=f(64, True), fill=C_TXT)
d.text((120, 160), "文件接入 → 解析 → 路由 → 逐点判定 → 聚合 → 人工复核 → 报告 → 反馈进化",
       font=f(30), fill=C_MUTED)

# 阶段标题
for i, (name, color) in enumerate(STAGES):
    d.rounded_rectangle([COLX[i], 250, COLX[i]+NODEW, 310], radius=8, fill=color)
    tw = d.textlength(name, font=f(30, True))
    d.text((COLX[i] + (NODEW-tw)/2, 268), name, font=f(30, True), fill="#FFFFFF")

# 列1：接入
x1 = COLX[0]
nodes1 = [
    ("选择文件\n（xlsx / docx / pdf / md）", "#FFFFFF"),
    ("大小 ≤ 100MB？", "#FFF3E8"),
    ("项目合计 ≤ 300MB？", "#FFF3E8"),
    ("份数 < 3？", "#FFF3E8"),
    ("SHA256 去重\n命中则复用解析", "#F0F4FF"),
    ("落盘 + 登记 document\nstatus=uploaded", "#FFFFFF"),
]
ys = [360, 500, 640, 780, 920, 1070]
for (t, fill), y in zip(nodes1, ys):
    if "？" in t:
        diamond(x1 + NODEW/2, y + 55, 560, 110, t, "#FF8800")
    else:
        box(x1, y, NODEW, 110, t, "#3370FF", fill=fill)
from1 = [y+110 for y in ys[:1]] + [y+55 for y in ys[1:4]] + [y+110 for y in ys[4:]]
arrow((x1+NODEW/2, ys[0]+110), (x1+NODEW/2, ys[1]), "")
arrow((x1+NODEW/2, ys[1]+55), (x1+NODEW/2, ys[2]))
arrow((x1+NODEW/2, ys[2]+55), (x1+NODEW/2, ys[3]))
arrow((x1+NODEW/2, ys[3]+55), (x1+NODEW/2, ys[4]))
arrow((x1+NODEW/2, ys[4]+110), (x1+NODEW/2, ys[5]))
rej = [("超限拒绝", 300), ("超限拒绝", 440), ("超限拒绝", 580)]
for txt, off in rej:
    poly([(x1+20, off+60), (x1-70, off+60), (x1-70, off+120)], txt, "#F54A45")
    d.text((x1-64, off+130), "拒绝", font=f(22), fill="#F54A45")

# 列2：解析
x2 = COLX[1]
box(x2, 360, NODEW, 100, "识别扩展名", "#00B96B")
box(x2, 500, NODEW, 110, "xlsx：表头 + 工序 + 半成品\nopenpyxl", "#00B96B", "#F6FFFA")
box(x2, 640, NODEW, 110, "docx：段落 + 表格\npython-docx", "#00B96B", "#F6FFFA")
box(x2, 780, NODEW, 110, "pdf：分页取文本\npypdf", "#00B96B", "#F6FFFA")
box(x2, 920, NODEW, 110, "md/txt：标题 + 段落\n原页定位", "#00B96B", "#F6FFFA")
diamond(x2 + NODEW/2, 1130, 600, 110, "PDF 无文本？\n（扫描件）", "#FF8800")
box(x2, 1230, NODEW, 110, "拆页 → 转 PNG → 视觉模型\n失败则 parse_status=failed", "#F54A45", "#FFF5F5")
box(x2, 1390, NODEW, 120, "事实抽取\n温度 / 浓度 / 重量 / 日期 / 版本", "#7F3BF5", "#F7F2FF")
box(x2, 1540, NODEW, 120, "生成 Anchor\nSheet!单元格 / 第N段 / 第N页", "#7F3BF5", "#F7F2FF")
arrow((x1+NODEW/2+40, ys[5]+55), (x2, 410), "")
arrow((x2+NODEW/2, 460), (x2+NODEW/2, 500))
arrow((x2+NODEW/2, 750), (x2+NODEW/2, 780))
arrow((x2+NODEW/2, 890), (x2+NODEW/2, 920))
arrow((x2+NODEW/2, 640+110), (x2+NODEW/2, 1130-55))
arrow((x2+NODEW/2, 1185), (x2+NODEW/2, 1230), "是", "#F54A45")
arrow((x2+NODEW/2+180, 1130), (x2+NODEW/2+180, 1390), "否", "#00B96B")
arrow((x2+NODEW/2, 1450), (x2+NODEW/2, 1540))

# 列3：路由
x3 = COLX[2]
box(x3, 360, NODEW, 110, "场景包别名匹配\n（文件类型 104 种）", "#FF8800", "#FFF8F0")
diamond(x3 + NODEW/2, 560, 600, 110, "识别成功？", "#FF8800")
box(x3, 660, NODEW, 110, "doc_type=unknown\n走通用点位", "#8F959E", "#FAFAFA")
box(x3, 810, NODEW, 110, "取默认审核类型\n（74 种）", "#FF8800", "#FFF8F0")
box(x3, 960, NODEW, 120, "路由到审核点库\n302 库 + 17 场景 = 319", "#FF8800", "#FFF8F0")
diamond(x3 + NODEW/2, 1170, 620, 110, "用户选了一级类型？", "#FF8800")
box(x3, 1270, NODEW, 110, "按 A~G 类别过滤点位", "#FF8800", "#FFF8F0")
box(x3, 1420, NODEW, 110, "得到本次执行点位清单", "#FF8800", "#FFF8F0")
arrow((x2+NODEW/2+120, 1600), (x3+NODEW/2, 470), "")
arrow((x3+NODEW/2, 470), (x3+NODEW/2, 505))
arrow((x3+NODEW/2-160, 560), (x3+NODEW/2-160, 660), "否", "#F54A45")
arrow((x3+NODEW/2, 615), (x3+NODEW/2, 810), "是", "#00B96B")
arrow((x3+NODEW/2-200, 715), (x3+NODEW/2-200, 1420), "并入", "#8F959E")
arrow((x3+NODEW/2, 870), (x3+NODEW/2, 960))
arrow((x3+NODEW/2, 1080), (x3+NODEW/2, 1115))
arrow((x3+NODEW/2-160, 1170), (x3+NODEW/2-160, 1270), "是", "#00B96B")
arrow((x3+NODEW/2+180, 1170), (x3+NODEW/2+180, 1420), "否：全部", "#8F959E")
arrow((x3+NODEW/2, 1325), (x3+NODEW/2, 1420))

# 列4：判定
x4 = COLX[3]
diamond(x4 + NODEW/2, 420, 620, 120, "点位有执行器？", "#7F3BF5")
box(x4, 520, NODEW, 110, "确定性执行器\n（17 个）", "#7F3BF5", "#F7F2FF")
box(x4, 670, NODEW, 110, "读规则行为参数\nenabled / severity / 忽略词", "#7F3BF5", "#F7F2FF")
diamond(x4 + NODEW/2, 860, 620, 110, "命中忽略关键词？", "#FF8800")
box(x4, 960, NODEW, 100, "记「不适用」跳过", "#8F959E", "#FAFAFA")
box(x4, 1100, NODEW, 120, "执行检查\n阈值来自 rule_param", "#7F3BF5", "#F7F2FF")
box(x4, 1260, NODEW, 110, "判「满足 / 不满足」", "#00B96B", "#F6FFFA")
box(x4, 1410, NODEW, 120, "失败：组装 prompt\n判据 + 证据要求 + 本体别名", "#7F3BF5", "#F7F2FF")
diamond(x4 + NODEW/2, 1610, 620, 120, "模型可用？", "#F54A45")
box(x4, 1710, NODEW, 110, "五态取一\npass / fail / na / insufficient", "#7F3BF5", "#F7F2FF")
box(x4, 1860, NODEW, 120, "Jev 选择性预测\n低置信 → 弃权转人工", "#FF8800", "#FFF8F0")
box(x4, 2020, NODEW, 120, "quote 反查定位\nlocate_quote → Sheet!Cell", "#7F3BF5", "#F7F2FF")
arrow((x3+NODEW/2+120, 1475), (x4+NODEW/2, 360), "")
arrow((x4+NODEW/2-160, 420), (x4+NODEW/2-160, 520), "是", "#00B96B")
arrow((x4+NODEW/2, 575), (x4+NODEW/2, 670))
arrow((x4+NODEW/2, 780), (x4+NODEW/2, 805))
arrow((x4+NODEW/2+160, 860), (x4+NODEW/2+160, 960), "是", "#F54A45")
arrow((x4+NODEW/2, 915), (x4+NODEW/2, 1100), "否", "#00B96B")
arrow((x4+NODEW/2, 1220), (x4+NODEW/2, 1260))
arrow((x4+NODEW/2+180, 420), (x4+NODEW/2+180, 1410), "否：走模型", "#8F959E")
arrow((x4+NODEW/2, 1530), (x4+NODEW/2, 1550))
arrow((x4+NODEW/2-160, 1610), (x4+NODEW/2-160, 1710), "是", "#00B96B")
arrow((x4+NODEW/2+160, 1610), (x4+NODEW/2+160, 2020), "否：执行失败", "#F54A45")
arrow((x4+NODEW/2, 1820), (x4+NODEW/2, 1860))
arrow((x4+NODEW/2, 1980), (x4+NODEW/2, 2020))

# 列5：聚合
x5 = COLX[4]
diamond(x5 + NODEW/2, 420, 620, 120, "存在 critical？", "#F54A45")
diamond(x5 + NODEW/2, 610, 620, 120, "存在待复核？", "#FF8800")
diamond(x5 + NODEW/2, 800, 620, 120, "存在 warning？", "#FF8800")
box(x5, 920, NODEW, 110, "结论：通过", "#00B96B", "#F6FFFA")
box(x5, 1080, NODEW, 110, "结论：建议关注", "#FF8800", "#FFF8F0")
box(x5, 1240, NODEW, 110, "结论：待复核", "#FF8800", "#FFF8F0")
box(x5, 1400, NODEW, 110, "结论：不通过", "#F54A45", "#FFF5F5")
box(x5, 1570, NODEW, 130, "写 audit_run 汇总\ncritical / warning / suspected", "#F54A45", "#FFF5F5")
arrow((x4+NODEW/2+140, 2070), (x5+NODEW/2, 370), "")
arrow((x5+NODEW/2, 480), (x5+NODEW/2, 550), "否", "#00B96B")
arrow((x5+NODEW/2, 670), (x5+NODEW/2, 740), "否", "#00B96B")
arrow((x5+NODEW/2, 860), (x5+NODEW/2, 920), "否", "#00B96B")
arrow((x5+NODEW/2-190, 800), (x5+NODEW/2-190, 1080), "是", "#FF8800")
arrow((x5+40, 610), (x5-80, 610), "")
poly([(x5-80, 610), (x5-80, 1240), (x5, 1240)], "是", "#FF8800")
arrow((x5+120, 420), (x5-30, 420), "")
poly([(x5-30, 420), (x5-30, 1400), (x5, 1400)], "是", "#F54A45")

# 底部：复核 / 报告 / 进化
Y0 = 2180
d.rounded_rectangle([120, Y0-40, W-120, Y0+30], radius=8, fill="#7F3BF5")
d.text((140, Y0-32), "⑥ 人工复核   →   ⑦ 报告门禁与输出   →   ⑧ 反馈与规则进化", font=f(30, True), fill="#FFFFFF")

box(120, Y0+70, 640, 130, "工作台：左原文 / 右问题\n点「定位」高亮 anchor", "#7F3BF5", "#F7F2FF")
box(830, Y0+70, 640, 130, "确认 / 误报 / 补证\n→ 写 decision + feedback", "#7F3BF5", "#F7F2FF")
box(1540, Y0+70, 640, 130, "低置信结论 → Jev 样本\n重算规则健康度", "#FF8800", "#FFF8F0")
box(2250, Y0+70, 640, 130, "报告门禁：待复核 > 0\n→ 409 拒绝出报告", "#F54A45", "#FFF5F5")
box(2960, Y0+70, 640, 130, "输出 HTML / DOCX / PDF\n写 report 表 + 审计", "#00B96B", "#F6FFFA")
box(3670, Y0+70, 440, 130, "反馈台账\n错题 / 漏报", "#7F3BF5", "#F7F2FF")

box(120, Y0+270, 640, 130, "自动归因\n标注「模型 / 兜底」", "#7F3BF5", "#F7F2FF")
box(830, Y0+270, 640, 130, "人工沉淀\n改阈值 / 降级 / 新建规则", "#7F3BF5", "#F7F2FF")
box(1540, Y0+270, 640, 130, "参数草稿 → 发布生效\n（不发布不生效）", "#FF8800", "#FFF8F0")
box(2250, Y0+270, 640, 130, "规则回放\n历史案例影响面", "#FF8800", "#FFF8F0")
box(2960, Y0+270, 640, 130, "冲突检测\n区间矛盾 / 重复 / 集合互斥", "#F54A45", "#FFF5F5")
box(3670, Y0+270, 440, 130, "接入矩阵\n规则↔点位↔本体", "#7F3BF5", "#F7F2FF")

for a, b in [(760, 830), (1470, 1540), (2180, 2250), (2890, 2960), (3600, 3670)]:
    arrow((a, Y0+135), (b, Y0+135))
for a, b in [(760, 830), (1470, 1540), (2180, 2250), (2890, 2960), (3600, 3670)]:
    arrow((a, Y0+335), (b, Y0+335))
arrow((4110, Y0+200), (4110, Y0+270))
arrow((3600, Y0+335), (3670, Y0+335))

# 回环：进化 → 判定
poly([(2960+320, Y0+400), (2960+320, Y0+470), (120-60, Y0+470), (120-60, 1600), (COLX[3]+40, 1600)],
     "下一轮审核生效", "#7F3BF5")

# 图例
LY = H - 260
d.rounded_rectangle([120, LY, 1300, LY+200], radius=10, outline="#E5E6E8", width=2)
d.text((150, LY+20), "图例", font=f(28, True), fill=C_TXT)
box(150, LY+70, 120, 40, "", "#3370FF")
d.text((290, LY+78), "确定性步骤", font=f(24), fill=C_MUTED)
box(560, LY+70, 120, 40, "", "#F54A45")
d.text((700, LY+78), "拒绝 / 失败分支", font=f(24), fill=C_MUTED)
box(1010, LY+70, 120, 40, "", "#7F3BF5")
d.text((1150, LY+78), "模型 / 进化", font=f(24), fill=C_MUTED)

d.text((150, LY+140), "说明：五态 = 满足 / 不满足 / 不适用 / 证据不足 / 执行失败；批次以 audit_run 记录，旧批次不删除。",
       font=f(22), fill=C_MUTED)

out = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                   "docs", "审核全流程详解图.png")
img.save(out)
print("saved", out, img.size)
