// 截图遍历：管理员/审核员全流程，每步截图 + 步骤说明
import fs from 'fs';
const targets = await (await fetch('http://127.0.0.1:9274/json/list')).json();
const page = targets.find(t => t.type === 'page') || targets[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id=1; const pend=new Map(); const errs=[];
ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data); if(m.id&&pend.has(m.id)){const p=pend.get(m.id);pend.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);} else if(m.method==='Runtime.exceptionThrown'){errs.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);}});
await new Promise((res,rej)=>{ws.addEventListener('open',res,{once:true});ws.addEventListener('error',rej,{once:true});});
function send(method,params={}){const i=id++;ws.send(JSON.stringify({id:i,method,params}));return new Promise((resolve,reject)=>pend.set(i,{resolve,reject}));}
async function ev(e){const r=await send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});return r.result?.value;}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const steps=[];
async function shot(name, desc){
  const r=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  fs.writeFileSync(`/tmp/audit_shots2/${name}.png`,Buffer.from(r.data,'base64'));
  steps.push({name, desc});
  console.log('shot', name);
}
async function click(sel, ms=600){ await ev(`document.querySelector('${sel}')?.click()`); await wait(ms); }
await send('Page.enable'); await send('Runtime.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});

async function admin() {
  await send('Page.navigate',{url:'http://127.0.0.1:8765/login?as=admin'}); await wait(2000);
  await shot('admin-01-审核工作台','管理员登录后默认进入审核工作台');
  // 审核：运行
  await click('#btn-review', 12000);
  await shot('admin-02-审核结果','点击「运行」后展示 4 严 7 般发现列表 + AI 复核提示 + 证据锚点');
  await shot('admin-03-报告预览','滚动到底部可见内嵌报告 iframe');
  // 规则
  await click('.menu-item[data-view=rules]', 800);
  await shot('admin-04-规则列表','规则管理：顶部 4 个 KPI + 左侧规则列表');
  await click('.rule-item', 800);
  await shot('admin-05-规则详情','规则详情：定义/为什么这么判/命中/趋势 SVG');
  // 标准导入
  await click('.menu-item[data-view=sediment]', 500);
  await shot('admin-06-标准导入','标准导入：输入企业标准目录');
  // 看板
  await click('.menu-item[data-view=dashboard]', 800);
  await shot('admin-07-看板','看板：全局 KPI');
  // 本体
  await click('.menu-item[data-view=ontology]', 800);
  await shot('admin-08-本体','本体：类型/实例/链接/健康度 + 新增别名');
  // 模型
  await click('.menu-item[data-view=model]', 800);
  await shot('admin-09-模型','模型：配置 + 6 处调用点 + 测试连接');
  await click('#btn-model-test', 2500);
  await shot('admin-10-模型测试','模型连接测试结果');
  // 冲突
  await click('.menu-item[data-view=conflict]', 800);
  await shot('admin-11-冲突','冲突三态示例');
  // 评测
  await click('.menu-item[data-view=eval]', 2500);
  await shot('admin-12-评测','评测：召回/精确/证据定位/覆盖');
  // 进化
  await click('.menu-item[data-view=evolution]', 800);
  await shot('admin-13-进化','规则进化：命中/误报/override/修订建议');
  // 错误书
  await click('.menu-item[data-view=errorbook]', 800);
  await shot('admin-14-错误书','错误书：误报案例');
  // 审计
  await click('.menu-item[data-view=audit]', 800);
  await shot('admin-15-审计','审计：事件时间线回放');
}

async function reviewer() {
  await send('Page.navigate',{url:'http://127.0.0.1:8765/logout'}); await wait(500);
  await send('Page.navigate',{url:'http://127.0.0.1:8765/login'}); await wait(2000);
  await shot('user-01-审核工作台','审核员登录：只看到审核工作台/我的案例两个菜单');
  await click('#btn-review', 12000);
  await shot('user-02-审核结果','审核员运行审核：发现列表');
  // 复核一条
  await click('#review-out .finding [data-act=confirmed]', 800);
  await shot('user-03-复核','点击「确认」复核一条发现，该条变灰标记已处理');
  // 我的案例
  await click('.menu-item[data-view=mine]', 800);
  await shot('user-04-我的案例','我的案例：本人案例 + 待复核计数');
}

await admin();
await reviewer();
fs.writeFileSync('/tmp/audit_shots2/steps.json', JSON.stringify(steps, null, 2));
console.log('总截图', steps.length, '| errors', errs);
ws.close(); process.exit(0);
