// 管理员端深度截图：菜单全遍历 + 详情 + 弹窗 + 表单态
import fs from 'fs';
const OUT = process.env.SHOT_DIR || '/tmp/admin_shots';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT||9410}/json/list`)).json();
const page = t.find(x=>x.type==='page')||t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id=1; const pend=new Map(); const errs=[]; const steps=[];
ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data);
  if(m.method==='Page.javascriptDialogOpening'){ ws.send(JSON.stringify({id:id++,method:'Page.handleJavaScriptDialog',params:{accept:true}})); return; }
  if(m.id&&pend.has(m.id)){const p=pend.get(m.id);pend.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}
  else if(m.method==='Runtime.exceptionThrown'){errs.push(m.params.exceptionDetails.exception?.description||'');}});
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
const send=(m,p={})=>{const i=id++;ws.send(JSON.stringify({id:i,method:m,params:p}));return new Promise((res,rej)=>pend.set(i,{resolve:res,reject:rej}));};
const ev=async e=>{const r=await send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});return r.result?.value;};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let n=0;
async function shot(name, desc){
  n++;
  const r=await send('Page.captureScreenshot',{format:'png'});
  const file = `${String(n).padStart(3,'0')}-${name}.png`;
  fs.writeFileSync(`${OUT}/${file}`, Buffer.from(r.data,'base64'));
  steps.push({file, name, desc});
  console.log('shot', file);
}
const click = async (sel, ms=800) => { const ok = await ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); if(e){e.click();return true} return false})()`); await wait(ms); return ok; };
await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
await send('Network.setCacheDisabled',{cacheDisabled:true});
await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
const BASE = process.env.BASE || 'http://127.0.0.1:8765';
await send('Page.navigate',{url:`${BASE}/logout`}); await wait(500);
await send('Page.navigate',{url:`${BASE}/login`}); await wait(1000);
await shot('登录页', '登录页：仅手机号/邮箱 + 密码 + 企业 SSO，无多余提示');
await ev(`document.querySelector('#username').value=${JSON.stringify(process.env.ADMIN_PHONE||'13800138000')};document.querySelector('#password').value=${JSON.stringify(process.env.ADMIN_PW||'')}`);
await ev(`document.querySelector('#login-form').requestSubmit()`); await wait(2600);
await ev(`document.querySelector('#profile-panel') && (document.querySelector('#profile-panel').hidden=true)`);
await shot('首页', '管理员首页：6 个运营指标 + 4 个规则质量指标 + 待复核/最近项目/最近动态');

const pages = [
  ['projects','项目列表','项目列表：筛选（项目名/审核员/状态/日期）+ 序号倒序 + 查看详情 + 分页'],
  ['rules','规则库-总览','规则库：335 条（16 可编辑 + 319 审核库点位），支持来源筛选'],
  ['newrule','新建规则','新建规则：上传文件拆解 / 一句话生成 / 手工填写'],
  ['conflict','冲突提醒','冲突提醒：KPI + 冲突表 + 裁决/忽略'],
  ['evolution','规则进化-台账','规则进化：反馈台账（确认/误报/补证/人工新增/补充证据）'],
  ['ontology','本体建模','本体建模：类型/实例/链接/健康 + 别名维护'],
  ['decision','决策表','决策表：编码/行数/命中策略/适用范围/灰度/状态'],
  ['jev','Jev校准','Jev 校准：全局阈值 + 按规则校准 + 可靠性曲线'],
  ['users','账号管理','账号管理：序号 + 姓名/手机/角色/状态 + 重置密码/停用'],
  ['messages','消息中心','消息中心：只保留需要行动或真实故障的消息'],
];
for (const [view, name, desc] of pages) {
  await click(`.menu-item[data-view="${view}"]`, 1600);
  await shot(name, desc);
}

// 规则库详情
await click('.menu-item[data-view="rules"]', 1500);
await shot('规则库-列表','规则库左侧分组列表（按类别分组，序号倒序）');
await click('.rule-item', 1200);
await shot('规则库-详情','规则详情：规则定义 / 为什么这么判 / 阈值参数 / 生命周期按钮 / 命中趋势');
// 规则接入状态（页面底部）
await ev(`document.querySelector('#rule-linkage')?.scrollIntoView({block:'start'})`); await wait(600);
await shot('规则库-接入状态','规则接入状态：每条规则 → 点位 / 本体 / Jev / 反馈 / 冲突');
// 反馈台账四个 Tab
await click('.menu-item[data-view="evolution"]', 1500);
await shot('进化-反馈台账','反馈台账：类型标签 + 问题/规则 + 理由/证据 + 来源时间 + 状态 + 操作');
for (const [tab,nm,ds] of [['wrong','进化-错题集','错题集：被判误报的案例，可沉淀规则'],
                            ['miss','进化-漏报集','漏报集：人工新增的问题（AI 未覆盖）'],
                            ['evolve','进化-进化建议','进化建议：规则级 + 审核点级建议'],
                            ['settled','进化-已沉淀','已沉淀：处理记录（修订/新建/忽略）']]) {
  await click(`[data-evt="${tab}"]`, 1200);
  await shot(nm, ds);
}
// 决策表新建
await click('.menu-item[data-view="decision"]', 1500);
await shot('决策表-空态','决策表：列表（空态提示）');
// 冲突检测
await click('.menu-item[data-view="conflict"]', 1200);
await click('#btn-conflict-detect', 2500);
await shot('冲突-全量检测后','冲突全量检测：扫描已发布规则，产出冲突清单');
// 新建规则三个模式
await click('.menu-item[data-view="newrule"]', 1400);
await shot('新建规则-默认','新建规则默认页（上传文件拆解）');
await click('#btn-nr-nl', 800);
await shot('新建规则-一句话','一句话生成：输入自然语言 → 生成规则草稿');
await click('#btn-nr-manual', 800);
await shot('新建规则-手工','手工填写：名称/类别/等级/指标/算子/值/单位/范围');
// 项目详情
await click('.menu-item[data-view="projects"]', 1500);
await click('#project-list [data-detail]', 2500);
await shot('项目详情','项目详情：文件清单 + 审核结果 + 报告预览');

fs.writeFileSync(`${OUT}/steps.json`, JSON.stringify(steps,null,2));
console.log('done', steps.length, 'errs', errs.slice(0,3));
ws.close(); process.exit(0);
