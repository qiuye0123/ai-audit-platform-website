// 扩展截图：全流程 + 每条规则详情 + 每个sheet高亮 + 每个导出 + 每条发现
import fs from 'fs';
const T = process.argv[2] || '9276';
const PORT = process.argv[3] || '8765';
const OUT = '/tmp/audit_shots3';
fs.mkdirSync(OUT, { recursive: true });

const targets = await (await fetch(`http://127.0.0.1:${T}/json/list`)).json();
const page = targets.find(t => t.type === 'page') || targets[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 1; const pend = new Map(); const errs = [];
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); }
  else if (m.method === 'Runtime.exceptionThrown') { errs.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text); }
});
await new Promise((res, rej) => { ws.addEventListener('open', res, { once: true }); ws.addEventListener('error', rej, { once: true }); });
function send(method, params = {}) { const i = id++; ws.send(JSON.stringify({ id: i, method, params })); return new Promise((resolve, reject) => pend.set(i, { resolve, reject })); }
async function ev(e) { const r = await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true }); return r.result?.value; }
const wait = ms => new Promise(r => setTimeout(r, ms));
const steps = [];
async function shot(name, desc) {
  const r = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  fs.writeFileSync(`${OUT}/${name}.png`, Buffer.from(r.data, 'base64'));
  steps.push({ name, desc }); console.log('shot', name);
}
async function click(sel, ms = 500) { await ev(`document.querySelector('${sel}')?.click()`); await wait(ms); }
async function scrollTo(sel, ms = 400) { await ev(`document.querySelector('${sel}')?.scrollIntoView({block:'center'})`); await wait(ms); }

await send('Page.enable'); await send('Runtime.enable');
await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });

// ---- 审核员(先, 免管理员干扰) ----
await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/login` }); await wait(2200);
await shot('user-01-登录首页', '审核员登录后首页');
await click('.menu-item[data-view=review]', 500);
await shot('user-02-审核工作台', '审核工作台');
await click('#btn-review', 12000);
await shot('user-03-运行结果', '运行审核后 4严7般');
await scrollTo('#review-out .finding', 400);
await shot('user-04-发现区', '发现列表 + 证据锚点');
await ev("document.querySelector('#review-out iframe')?.scrollIntoView({block:'start'})"); await wait(400);
await shot('user-05-报告预览', '内嵌报告');
// 复核
const fcount = await ev("document.querySelectorAll('#review-out .finding [data-act]').length");
if (fcount) { await ev("document.querySelector('#review-out .finding [data-act=confirmed]').click()"); await wait(600); }
await shot('user-06-复核后', '点确认后该发现变灰已处理');
await click('.menu-item[data-view=mine]', 600);
await shot('user-07-我的案例', '我的案例 + 待复核');

// ---- 管理员 ----
await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/logout` }); await wait(400);
await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/login?as=admin` }); await wait(2200);
await shot('admin-01-首页', '管理员首页 KPI');
await click('.menu-item[data-view=review]', 500);
await shot('admin-02-工作台', '审核工作台');
await click('#btn-review', 12000);
await shot('admin-03-审核结果', '审核结果');
// 每条规则详情
await click('.menu-item[data-view=rules]', 900);
await shot('admin-04-规则列表', '规则列表');
const ruleCount = await ev("document.querySelectorAll('.rule-item').length");
for (let i = 0; i < ruleCount; i++) {
  await ev(`document.querySelectorAll('.rule-item')[${i}]?.click()`); await wait(350);
  await shot(`admin-rule-${String(i + 1).padStart(2, '0')}`, `规则详情(上) ${i + 1}/${ruleCount}`);
  await ev("document.querySelector('.rule-detail')?.scrollTo(0, 400)"); await wait(250);
  await shot(`admin-rule-${String(i + 1).padStart(2, '0')}-m`, `规则详情(中) ${i + 1}/${ruleCount}`);
  await ev("document.querySelector('.rule-detail')?.scrollTo(0, 99999)"); await wait(250);
  await shot(`admin-rule-${String(i + 1).padStart(2, '0')}-b`, `规则详情(下/趋势) ${i + 1}/${ruleCount}`);
}
// 数据各页
const views = [['dashboard', '看板'], ['ontology', '本体'], ['model', '模型'], ['conflict', '冲突'], ['eval', '评测'], ['evolution', '进化'], ['errorbook', '错误书'], ['audit', '审计']];
for (const [v, name] of views) {
  await click(`.menu-item[data-view=${v}]`, v === 'eval' ? 2500 : 700);
  await shot(`admin-${v}`, name);
  await ev("window.scrollTo(0, document.body.scrollHeight)"); await wait(300);
  await shot(`admin-${v}-b`, `${name}(滚动到底)`);
  await ev("window.scrollTo(0, 0)");
}
// 每条发现（回到审核结果逐条滚动）
await click('.menu-item[data-view=review]', 500);
await click('#btn-review', 11000);
const fcount2 = await ev("document.querySelectorAll('#review-out .finding').length");
for (let i = 0; i < fcount2; i++) {
  await ev(`document.querySelectorAll('#review-out .finding')[${i}]?.scrollIntoView({block:'center'})`); await wait(300);
  const t = await ev(`document.querySelectorAll('#review-out .finding')[${i}]?.querySelector('.ft')?.innerText || ''`);
  await shot(`finding-${String(i + 1).padStart(2, '0')}`, `发现 ${i + 1}/${fcount2}：${t}`);
}
// 导出（HTML 报告快照）
await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/api/v1/reviews/demo/report.html` }); await wait(1200);
for (let i = 0; i < 4; i++) {
  await ev(`window.scrollTo(0, ${i * 900})`); await wait(350);
  await shot(`admin-report-${i + 1}`, `报告分屏 ${i + 1}/4`);
}
await shot('admin-export-docx', '报告导出 DOCX 链接');
await shot('admin-export-pdf', '报告导出 PDF 链接');
// 每个 sheet 高亮
await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/api/v1/highlight` }); await wait(1500);
const sheetCount = await ev("document.querySelectorAll('.sheet').length");
for (let i = 0; i < sheetCount; i++) {
  await ev(`document.querySelectorAll('.sheet')[${i}]?.scrollIntoView({block:'start'})`); await wait(350);
  const title = await ev(`document.querySelectorAll('.sheet')[${i}]?.querySelector('.sheet-head')?.innerText || 'sheet${i+1}'`);
  await shot(`highlight-${String(i + 1).padStart(2, '0')}`, `原文高亮 sheet ${title}`);
}

fs.writeFileSync(`${OUT}/steps.json`, JSON.stringify(steps, null, 2));
console.log('总截图', steps.length, '| errors', errs.length);
ws.close(); process.exit(0);
