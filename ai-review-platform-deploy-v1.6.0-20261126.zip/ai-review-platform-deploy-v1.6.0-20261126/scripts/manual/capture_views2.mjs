import fs from 'fs'; import crypto from 'crypto';
const OUT = process.env.SHOT_DIR || '/tmp/shots_v2'; fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT || 9410}/json/list`)).json();
const page = t.find(x => x.type === 'page') || t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 1; const pend = new Map();
ws.addEventListener('message', ev => { const m = JSON.parse(ev.data);
  if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id);
    m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } });
await new Promise((r, j) => { ws.addEventListener('open', r, { once: true }); ws.addEventListener('error', j, { once: true }); });
const send = (m, p = {}) => { const i = id++; ws.send(JSON.stringify({ id: i, method: m, params: p }));
  return new Promise((res, rej) => pend.set(i, { resolve: res, reject: rej })); };
const ev = async e => (await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true })).result?.value;
const wait = ms => new Promise(r => setTimeout(r, ms));
await send('Page.enable'); await send('Runtime.enable');
await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
const BASE = process.env.BASE || 'http://127.0.0.1:8765';
await send('Page.navigate', { url: `${BASE}/login` }); await wait(1000);
await ev(`document.querySelector('#username').value='13800138000';document.querySelector('#password').value=${JSON.stringify(process.env.ADMIN_PW||'')};document.querySelector('#login-form').requestSubmit()`);
await wait(2800);
console.log('login', await ev(`!!document.querySelector('#view-home')`));
const VIEWS = ['home','projects','myaudits','auditrecords','workbench','report','newproject','project','rules','newrule','sediment','ontology','model','conflict','evolution','errorbook','users','openplatform','auditlogs','agents','messages'];
const seen = new Map(); let n = 0, skipped = 0, noentry = [];
for (const v of VIEWS) {
  const r1 = await ev(`(()=>{const el=document.querySelector('[data-view="${v}"],[data-go="${v}"]');
     if(!el) return 'noentry'; el.click(); return 'clicked';})()`);
  if (r1 === 'noentry') { noentry.push(v); continue; }
  await wait(800);
  const vis = await ev(`(()=>{const el=document.querySelector('#view-${v}'); return el && !el.hidden ? 'ok':'hidden';})()`);
  if (vis !== 'ok') { noentry.push(v + ':' + vis); continue; }
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  const buf = Buffer.from(shot.data, 'base64');
  const h = crypto.createHash('sha256').update(buf).digest('hex');
  if (seen.has(h)) { skipped++; console.log('SKIP dup', v, '==', seen.get(h)); continue; }
  seen.set(h, v); n++;
  fs.writeFileSync(`${OUT}/${String(n).padStart(2,'0')}-${v}.png`, buf);
  console.log('shot', n, v);
}
console.log(`TOTAL ${n} skipped ${skipped} noentry ${JSON.stringify(noentry)}`);
