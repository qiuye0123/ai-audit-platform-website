# -*- coding: utf-8 -*-
"""审核全流程架构图 v2：分层栅格布局 + 正交连线 + 数据层。"""
import math
import os

from PIL import Image, ImageDraw, ImageFont

W, H = 5400, 2600
F_NUM = ImageFont.truetype("/System/Library/Fonts/STHeiti Medium.ttc", 26)
def F(sz, bold=False):
    p = "/System/Library/Fonts/STHeiti Medium.ttc" if bold else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try:
        return ImageFont.truetype(p, sz)
    except Exception:
        return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", sz)

INK, MUT, LINE = "#1F2329", "#646A73", "#B0B5BC"
img = None
d = None

STAGES = [
    ("① 文件接入", "#3370FF", "#F2F6FF"),
    ("② 解析与结构化", "#00B96B", "#F1FBF6"),
    ("③ 类型识别与路由", "#FF8800", "#FFF7EE"),
    ("④ 逐点判定", "#7F3BF5", "#F7F2FF"),
    ("⑤ 结论聚合", "#F54A45", "#FFF3F2"),
    ("⑥ 人工复核", "#0FA6A6", "#EFFAFA"),
    ("⑦ 报告与归档", "#3370FF", "#F2F6FF"),
    ("⑧ 反馈与进化", "#7F3BF5", "#F7F2FF"),
]
COL_W, GAP, LEFT, TOP = 520, 132, 140, 300
COLS = [LEFT + i * (COL_W + GAP) for i in range(len(STAGES))]

NODES = {}   # id -> dict(x,y,w,h,text,kind,color,fill)
ROWS = {}


def add(col, nid, text, kind="box", color=None, lines=None):
    h = 104 if (len(text.split("\n")) <= 2) else 132
    y = ROWS.get(col, TOP)
    NODES[nid] = {"x": COLS[col], "y": y, "w": COL_W, "h": h, "text": text, "kind": kind,
                  "color": color or STAGES[col][1], "fill": STAGES[col][2]}
    ROWS[col] = y + h + 74
    return nid


def dbox(n, r=12):
    x, y, w, h = n["x"], n["y"], n["w"], n["h"]
    fill = n["fill"]
    if n["kind"] == "term":
        d.rounded_rectangle([x, y, x + w, y + h], radius=h // 2, outline=n["color"], width=3, fill=fill)
    elif n["kind"] == "dia":
        cx, cy = x + w // 2, y + h // 2
        d.polygon([(cx, y), (x + w, cy), (cx, y + h), (x, cy)], outline=n["color"], width=3, fill="#FFFFFF")
    elif n["kind"] == "dash":
        d.rounded_rectangle([x, y, x + w, y + h], radius=r, outline=n["color"], width=3, fill=fill)
        for gx in range(x + 8, x + w - 8, 18):
            d.line([(gx, y), (min(gx + 9, x + w - 8), y)], fill=n["color"], width=3)
            d.line([(gx, y + h), (min(gx + 9, x + w - 8), y + h)], fill=n["color"], width=3)
    else:
        d.rounded_rectangle([x, y, x + w, y + h], radius=r, outline=n["color"], width=3, fill=fill)
    ls = n["text"].split("\n")
    lh = 36 if len(ls) > 1 else 34
    ty = (n["y"] + h // 2) - (len(ls) * lh) // 2
    for ln in ls:
        f = F(25)
        if d.textlength(ln, font=f) > w - 26:
            size = 25
            while size > 15 and d.textlength(ln, font=F(size)) > w - 26:
                size -= 1
            f = F(size)
        tw = d.textlength(ln, font=f)
        d.text((x + (w - tw) / 2, ty + (lh - size if 'size' in dir() else 0) // 2), ln, font=f, fill=INK)
        ty += lh


def arrow_head(p1, p2, color):
    ang = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
    L = 17
    for s in (0.42, -0.42):
        d.line([p2, (p2[0] - L * math.cos(ang + s), p2[1] - L * math.sin(ang + s))], fill=color, width=3)


def link(a, b, label="", style="solid", lane=0.5, color=None, midy=None):
    na, nb = NODES[a], NODES[b]
    col = color or (na["color"] if style == "solid" else "#8F959E")
    if abs(na["x"] - nb["x"]) < 10:                       # 同列：竖直
        p1 = (na["x"] + na["w"] // 2, na["y"] + na["h"])
        p2 = (nb["x"] + nb["w"] // 2, nb["y"])
        d.line([p1, p2], fill=col, width=3)
        arrow_head(p1, p2, col)
    else:                                                 # 跨列：正交
        sx = na["x"] + na["w"] if nb["x"] > na["x"] else na["x"]
        sy = na["y"] + na["h"] // 2 if nb["x"] > na["x"] else na["y"] + na["h"] // 2
        tx = nb["x"] if nb["x"] > na["x"] else nb["x"] + nb["w"]
        ty = nb["y"] + nb["h"] // 2
        x1 = na["x"] + na["w"] if nb["x"] > na["x"] else na["x"]
        midx = x1 + (tx - x1) * lane
        pts = [(x1, sy), (midx, sy), (midx, ty), (tx, ty)]
        for i in range(len(pts) - 1):
            d.line([pts[i], pts[i + 1]], fill=col, width=3)
        arrow_head(pts[-2], pts[-1], col)
        if label:
            d.text((midx + 8, sy - 32), label, font=F(21), fill=MUT)


# ---------- ① 接入 ----------
add(0, "a1", "选择文件\n支持 xlsx / docx / pdf / md / txt", "term")
add(0, "a2", "单份 ≤ 100MB ？", "dia")
add(0, "a3", "项目合计 ≤ 300MB ？", "dia")
add(0, "a4", "份数 ≤ 3 ？", "dia")
add(0, "a5", "SHA256 去重\n命中则复用解析结果")
add(0, "a6", "落盘 + 登记 document\nstatus = uploaded")

# ---------- ② 解析 ----------
add(1, "b1", "识别扩展名\n分派解析器")
add(1, "b2", "xlsx：表头 / 工序 / 半成品\nopenpyxl")
add(1, "b3", "docx：段落 / 表格 / 标题\npython-docx")
add(1, "b4", "pdf：按页取文本\npypdf")
add(1, "b5", "md / txt：标题 / 段落\n保留「原页」定位")
add(1, "b6", "PDF 无文本（扫描件）？", "dia")
add(1, "b7", "拆页 → 转图 → 视觉模型\n失败则 parse_status = failed", "box", "#F54A45")
add(1, "b8", "通用事实抽取\n数值+量纲 / 范围 / 阈值 / 日期 / 版本 / 编号")
add(1, "b9", "Anchor 生成\nSheet!单元格 · 第N段 · 第N页")

# ---------- ③ 路由 ----------
add(2, "c1", "加载场景包\n文件类型 104 种 / 审核类型 74 种")
add(2, "c2", "别名与识别要素匹配\nscore ≥ 2 命中", "dia")
add(2, "c3", "doc_type = unknown\n走通用点位", "box", "#8F959E")
add(2, "c4", "取默认审核类型清单")
add(2, "c5", "映射审核点类型库\n302 库 + 17 场景 = 319 类")
add(2, "c6", "用户选了一级类型？", "dia")
add(2, "c7", "按 A~G 类别过滤")
add(2, "c8", "本次执行点位清单")

# ---------- ④ 判定 ----------
add(3, "d1", "遍历点位")
add(3, "d2", "有确定性执行器？", "dia")
add(3, "d3", "执行器判定\n17 个结构检查")
add(3, "d4", "读行为参数\n启用 / 灰度 / 忽略词 / 严重度")
add(3, "d5", "命中忽略关键词？", "dia")
add(3, "d6", "记「不适用」跳过", "box", "#8F959E")
add(3, "d7", "阈值判定\nrule_param 生效值")
add(3, "d8", "模型判定\n窗口选择 + 判据 + 证据要求")
add(3, "d9", "模型可用？", "dia", "#F54A45")
add(3, "d10", "五态\npass / fail / na / insufficient / unknown")
add(3, "d11", "Jev 选择性预测\n低置信 → 弃权转人工")
add(3, "d12", "quote 反查定位\nlocate_quote → Sheet!Cell")

# ---------- ⑤ 聚合 ----------
add(4, "e1", "存在 critical ？", "dia")
add(4, "e2", "存在弃权 / 证据不足 ？", "dia")
add(4, "e3", "存在待复核 ？", "dia")
add(4, "e4", "结论：通过", "box", "#00B96B")
add(4, "e5", "结论：待复核（含弃权）", "box", "#FF8800")
add(4, "e6", "结论：待复核", "box", "#FF8800")
add(4, "e7", "结论：不通过", "box", "#F54A45")
add(4, "e8", "写 audit_run\n批次 / 计数 / 判定批次号")

# ---------- ⑥ 复核 ----------
add(5, "f1", "审核工作台\n左原文 · 右问题 · 定位高亮")
add(5, "f2", "确认 / 误报 / 补证")
add(5, "f3", "手动新增问题\n（漏报信号）")
add(5, "f4", "写 decision + 反馈台账")
add(5, "f5", "Jev 样本累积\n置信度 × 对错")
add(5, "f6", "重算规则健康度")

# ---------- ⑦ 报告 ----------
add(6, "g1", "报告门禁\n待复核 > 0 ？", "dia")
add(6, "g2", "409 拒绝\n提示未复核条数", "box", "#F54A45")
add(6, "g3", "生成报告\n结论 + 发现 + 证据 + 建议")
add(6, "g4", "HTML / DOCX / PDF")
add(6, "g5", "写 report 表 + 审计日志")

# ---------- ⑧ 进化 ----------
add(7, "h1", "反馈台账\n确认 / 误报 / 补证 / 新增")
add(7, "h2", "反向反馈 ≥ 3 ？", "dia")
add(7, "h3", "调度器自动归因\n标注「模型 / 兜底」")
add(7, "h4", "人工沉淀\n改阈值 / 降级 / 新建规则")
add(7, "h5", "参数草稿 → 发布生效")
add(7, "h6", "规则回放\n历史案例影响面")
add(7, "h7", "冲突检测\n区间 / 重复 / 集合互斥")
add(7, "h8", "接入矩阵\n规则 / 点位 / 本体")

MAXY = max(n["y"] + n["h"] for n in NODES.values())
DY = MAXY + 120
H = DY + 210 + 260
img = Image.new("RGB", (W, H), "#FFFFFF")
d = ImageDraw.Draw(img)

# 标题与阶段头
d.text((LEFT, 96), "AI 审核平台 · 全流程架构图", font=F(60, True), fill=INK)
d.text((LEFT, 176), "八段流水线：接入 → 解析 → 路由 → 判定 → 聚合 → 复核 → 报告 → 进化",
       font=F(27), fill=MUT)
d.line([(LEFT, 240), (W - LEFT, 240)], fill="#E5E6E8", width=2)
for i, (name, color, _f) in enumerate(STAGES):
    d.rounded_rectangle([COLS[i], 258, COLS[i] + COL_W, 300], radius=6, fill=color)
    f = F(24, True)
    tw = d.textlength(name, font=f)
    d.text((COLS[i] + (COL_W - tw) / 2, 264), name, font=f, fill="#FFFFFF")
    if i < len(STAGES) - 1:
        ax = COLS[i] + COL_W + GAP // 2
        d.line([(ax - 26, 279), (ax + 20, 279)], fill="#8F959E", width=3)
        arrow_head((ax - 26, 279), (ax + 20, 279), "#8F959E")

for _n in NODES.values():
    dbox(_n)

# 列内竖直连线
for col in range(len(STAGES)):
    ids = [k for k, v in NODES.items() if v["x"] == COLS[col]]
    for i in range(len(ids) - 1):
        link(ids[i], ids[i + 1])

# 列间「承接」箭头：每列最后一个节点 → 下一列第一个节点
for col in range(len(STAGES) - 1):
    left_ids = [k for k, v in NODES.items() if v["x"] == COLS[col]]
    right_ids = [k for k, v in NODES.items() if v["x"] == COLS[col + 1]]
    if not left_ids or not right_ids:
        continue
    a, b = NODES[left_ids[-1]], NODES[right_ids[0]]
    y1 = a["y"] + a["h"] // 2
    y2 = b["y"] + b["h"] // 2
    x1, x2 = a["x"] + a["w"], b["x"]
    midx = (x1 + x2) // 2
    pts = [(x1, y1), (midx, y1), (midx, y2), (x2, y2)]
    for i in range(len(pts) - 1):
        d.line([pts[i], pts[i + 1]], fill="#8F959E", width=3)
    arrow_head(pts[-2], pts[-1], "#8F959E")

# 回环：进化 → 判定
h5 = NODES["h5"]; d4 = NODES["d4"]
loop_y = MAXY + 54
pts = [(h5["x"] + h5["w"] // 2, h5["y"] + h5["h"]), (h5["x"] + h5["w"] // 2, loop_y),
       (d4["x"] + d4["w"] // 2, loop_y), (d4["x"] + d4["w"] // 2, d4["y"] + d4["h"])]
for i in range(len(pts) - 1):
    d.line([pts[i], pts[i + 1]], fill="#7F3BF5", width=4)
arrow_head(pts[-2], pts[-1], "#7F3BF5")
d.text(((d4["x"] + h5["x"]) // 2 - 90, loop_y + 12), "参数发布 / 规则演进后 · 下一轮审核生效",
       font=F(23), fill="#7F3BF5")

# ---------- 数据层 ----------
d.rounded_rectangle([LEFT, DY, W - LEFT, DY + 210], radius=14, outline="#D9DDE3", width=3, fill="#FAFBFC")
d.text((LEFT + 24, DY + 18), "数据层（SQLite / WAL）", font=F(28, True), fill=INK)
tables = [("document", "文件与解析状态"), ("audit_run", "审核批次与判定批次号"), ("finding", "问题与五态"),
          ("point_state", "五态明细（覆盖率来源）"), ("evidence", "证据锚点"), ("rule / rule_param", "规则与阈值"),
          ("decision_table", "决策表"), ("feedback", "反馈台账"), ("calibration", "Jev 样本"),
          ("onto_*", "本体实例 / 别名 / 链接"), ("audit_log", "审计日志")]
x, y = LEFT + 24, DY + 66
for i, (t, desc) in enumerate(tables):
    tw = 330
    if x + tw > W - LEFT - 20:
        x, y = LEFT + 24, y + 52
    label = f"{t}  {desc}"
    if d.textlength(label, font=F(21)) > tw - 22:
        tw = int(d.textlength(label, font=F(21))) + 30
    d.rounded_rectangle([x, y, x + tw, y + 42], radius=8, outline="#B0B5BC", width=2, fill="#FFFFFF")
    d.text((x + 12, y + 8), t, font=F(21, True), fill=INK)
    d.text((x + 12 + d.textlength(t, font=F(21, True)) + 10, y + 11), desc, font=F(18), fill=MUT)
    x += tw + 14

# ---------- 图例 ----------
LY = DY + 230
d.rounded_rectangle([LEFT, LY, LEFT + 1600, LY + 150], radius=12, outline="#E5E6E8", width=2, fill="#FFFFFF")
d.text((LEFT + 20, LY + 16), "图例", font=F(26, True), fill=INK)
entities = [("rounded", "步骤", "#3370FF"), ("dia", "判断", "#FF8800"), ("term", "起点/终点", "#00B96B")]
for i, (k, label, c) in enumerate(entities):
    bx = LEFT + 20 + i * 330
    if k == "dia":
        d.polygon([(bx + 40, LY + 76), (bx + 84, LY + 96), (bx + 40, LY + 116), (bx - 4, LY + 96)],
                  outline=c, width=3, fill="#FFFFFF")
    elif k == "term":
        d.rounded_rectangle([bx, LY + 76, bx + 84, LY + 116], radius=20, outline=c, width=3)
    else:
        d.rounded_rectangle([bx, LY + 76, bx + 84, LY + 116], radius=8, outline=c, width=3)
    d.text((bx + 100, LY + 84), label, font=F(22), fill=MUT)
d.text((LEFT + 20, LY + 128), "五态：满足 / 不满足 / 不适用 / 证据不足 / 执行失败；虚线框 = 外部依赖（模型、OCR）",
       font=F(19), fill=MUT)

out = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                   "docs", "审核全流程架构图_v2.png")
img.save(out)
print("saved", out, img.size)
