import fs from 'fs';
const OUT = process.env.SHOT_DIR || '/tmp/admin_deep3';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT||9412}/json/list`)).json();
const page = t.find(x=>x.type==='page')||t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id=1; const pend=new Map(); const steps=[]; const errs=[];
ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data);
  if(m.method==='Page.javascriptDialogOpening'){ ws.send(JSON.stringify({id:id++,method:'Page.handleJavaScriptDialog',params:{accept:true}})); return; }
  if(m.id&&pend.has(m.id)){const p=pend.get(m.id);pend.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}
  else if(m.method==='Runtime.exceptionThrown'){errs.push((m.params.exceptionDetails.exception?.description||'').slice(0,100));}});
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
const send=(m,p={})=>{const i=id++;ws.send(JSON.stringify({id:i,method:m,params:p}));return new Promise((res,rej)=>pend.set(i,{resolve:res,reject:rej}));};
const ev=async e=>{const r=await send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});return r.result?.value;};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let n=200;
async function shot(name, desc){
  n++;
  const r=await send('Page.captureScreenshot',{format:'png'});
  const file = `${String(n).padStart(3,'0')}-${name}.png`;
  fs.writeFileSync(`${OUT}/${file}`, Buffer.from(r.data,'base64'));
  steps.push({file, name, desc});
}
await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
await send('Network.setCacheDisabled',{cacheDisabled:true});
await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});

// 审核库点位逐个（40 个）
await ev(`document.querySelector('.menu-item[data-view="rules"]')?.click()`); await wait(1800);
await ev(`(()=>{const e=document.querySelector('#rule-src'); e.value='library'; e.dispatchEvent(new Event('change'));})()`); await wait(1200);
for (let i = 0; i < 40; i++) {
  const ok = await ev(`(()=>{const els=document.querySelectorAll('.rule-item'); const e=els[${i}]; if(!e) return null; e.click(); return e.innerText.split('\\n')[0].slice(0,26)})()`);
  if (!ok) break;
  await wait(850);
  await shot(`库点位-${i+1}`, `审核库点位详情：${ok}`);
}

// 可编辑规则逐个（12 个）
await ev(`(()=>{const e=document.querySelector('#rule-src'); e.value='db'; e.dispatchEvent(new Event('change'));})()`); await wait(1200);
for (let i = 0; i < 12; i++) {
  const ok = await ev(`(()=>{const els=document.querySelectorAll('.rule-item'); const e=els[${i}]; if(!e) return null; e.click(); return e.innerText.split('\\n')[0].slice(0,26)})()`);
  if (!ok) break;
  await wait(850);
  await shot(`内置规则-${i+1}`, `内置规则详情：${ok}`);
}

// 项目工作台四个标签
await ev(`document.querySelector('.menu-item[data-view="projects"]')?.click()`); await wait(1600);
for (let p = 0; p < 3; p++) {
  const ok = await ev(`(()=>{const els=document.querySelectorAll('#project-list [data-detail]'); const e=els[${p}]; if(!e) return null; e.click(); return true})()`);
  if (!ok) break;
  await wait(2200);
  for (const [tab, label] of [['issues','问题'],['rules','规则不通过项'],['preview','预览报告']]) {
    const has = await ev(`(()=>{const e=document.querySelector('[data-tab="${tab}"]'); if(e){e.click(); return true} return false})()`);
    if (!has) continue;
    await wait(900);
    await shot(`项目${p+1}-${label}`, `项目 ${p+1} 工作台 · ${label}`);
  }
  await ev(`document.querySelector('.menu-item[data-view="projects"]')?.click()`); await wait(1400);
}

// 各页面滚动段
for (const [view, label] of [['home','首页下半'],['rules','规则库底部'],['users','账号列表底部'],['messages','消息列表']]) {
  await ev(`document.querySelector('.menu-item[data-view="${view}"]')?.click()`); await wait(1300);
  await ev(`window.scrollTo(0, document.body.scrollHeight)`); await wait(700);
  await shot(label, `${label}：表格底部 / 分页 / 空态`);
}
fs.writeFileSync(`${OUT}/steps.json`, JSON.stringify(steps,null,2));
console.log('TOTAL3', steps.length, 'ERRS', errs.slice(0,3));
ws.close(); process.exit(0);
