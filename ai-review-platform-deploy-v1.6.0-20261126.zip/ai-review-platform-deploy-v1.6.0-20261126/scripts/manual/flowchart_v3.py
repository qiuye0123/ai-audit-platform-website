# -*- coding: utf-8 -*-
"""架构图 v3：无重叠布局。规则：
1) 网格列布局，列内节点等距，框与框不重叠；
2) 列内箭头只走垂直间隙；跨列只在「阶段头」与「底部回流带」走线；
3) 图例固定右上角；
4) 文字按框宽自动换行/缩字号，保证字不出框；
5) 渲染后做几何自检：线段不得穿过任何框体。
"""
import math
import os

from PIL import Image, ImageDraw, ImageFont

W = 5200
MARGIN_L, MARGIN_R = 120, 120
TOP_TITLE = 210
HEAD_Y, HEAD_H = 250, 46
NODE_GAP = 58
COL_GAP = 108
COLS_N = 8
COL_W = (W - MARGIN_L - MARGIN_R - COL_GAP * (COLS_N - 1)) // COLS_N
COLS = [MARGIN_L + i * (COL_W + COL_GAP) for i in range(COLS_N)]
FIRST_Y = HEAD_Y + HEAD_H + 46

def F(sz, bold=False):
    p = "/System/Library/Fonts/STHeiti Medium.ttc" if bold else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try:
        return ImageFont.truetype(p, sz)
    except Exception:
        return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", sz)

INK, MUT = "#1F2329", "#646A73"
STAGES = [
    ("① 文件接入", "#3370FF", "#F3F7FF"),
    ("② 解析与结构化", "#00B96B", "#F1FBF6"),
    ("③ 类型识别与路由", "#FF8800", "#FFF7EE"),
    ("④ 逐点判定", "#7F3BF5", "#F7F3FF"),
    ("⑤ 结论聚合", "#F54A45", "#FFF3F2"),
    ("⑥ 人工复核", "#0FA6A6", "#EFFAFB"),
    ("⑦ 报告与归档", "#3370FF", "#F3F7FF"),
    ("⑧ 反馈与进化", "#7F3BF5", "#F7F3FF"),
]

NODES = []
ROWS = [FIRST_Y] * COLS_N


def _wrap(dr, text, maxw, size=24):
    """按最大宽度换行（中文按字符切，英文按词切）。"""
    f = F(size)
    lines, cur = [], ""
    for ch in text:
        if dr.textlength(cur + ch, font=f) <= maxw:
            cur += ch
        else:
            if cur:
                lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines or [""]


def node(col, kind, text, dy=0):
    x = COLS[col]
    size = 24
    tmp = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    lines = []
    for seg in text.split("\n"):
        lines.extend(_wrap(tmp, seg, COL_W - 34, size))
    h = max(84, len(lines) * 33 + 30)
    y = ROWS[col] + dy
    n = {"x": x, "y": y, "w": COL_W, "h": h, "lines": lines, "kind": kind,
         "color": STAGES[col][1], "fill": STAGES[col][2], "size": size}
    NODES.append(n)
    ROWS[col] = y + h + NODE_GAP
    return n


def build_nodes():
    # ① 接入
    node(0, "term", "选择文件：xlsx / docx / pdf / md / txt")
    node(0, "dia", "单份 ≤ 100MB ?")
    node(0, "dia", "项目合计 ≤ 300MB ?")
    node(0, "dia", "份数 ≤ 3 ?")
    node(0, "box", "SHA256 去重，命中复用解析结果")
    node(0, "box", "落盘并登记 document\nstatus = uploaded")
    # ② 解析
    node(1, "box", "识别扩展名，分派解析器")
    node(1, "box", "xlsx：表头 / 工序 / 半成品")
    node(1, "box", "docx：段落 / 表格 / 标题")
    node(1, "box", "pdf：按页取文本")
    node(1, "box", "md / txt：标题 / 段落，保留原页定位")
    node(1, "dia", "PDF 无文本（扫描件）?")
    node(1, "box", "拆页转图 → 视觉模型；失败标 parse_status = failed")
    node(1, "box", "通用事实抽取：数值+量纲 / 范围 / 阈值 / 日期 / 版本 / 编号")
    node(1, "box", "Anchor 生成：Sheet!单元格 / 第N段 / 第N页")
    # ③ 路由
    node(2, "box", "加载场景包：文件类型 104 种 / 审核类型 74 种")
    node(2, "dia", "别名与识别要素匹配，score ≥ 2 ?")
    node(2, "box", "doc_type = unknown，走通用点位")
    node(2, "box", "取默认审核类型清单")
    node(2, "box", "映射审核点类型库：302 库 + 17 场景 = 319 类")
    node(2, "dia", "用户选了一级类型 ?")
    node(2, "box", "按 A~G 类别过滤")
    node(2, "box", "本次执行点位清单")
    # ④ 判定
    node(3, "box", "遍历点位")
    node(3, "dia", "有确定性执行器 ?")
    node(3, "box", "执行器判定：17 个结构检查")
    node(3, "box", "读行为参数：启用 / 灰度 / 忽略词 / 严重度")
    node(3, "dia", "命中忽略关键词 ?")
    node(3, "box", "记「不适用」并跳过")
    node(3, "box", "阈值判定：rule_param 生效值")
    node(3, "box", "模型判定：选窗 + 判据 + 证据要求")
    node(3, "dia", "模型可用 ?")
    node(3, "box", "五态：pass / fail / na / insufficient / unknown")
    node(3, "box", "Jev 选择性预测：低置信 → 弃权转人工")
    node(3, "box", "quote 反查定位：locate_quote → Sheet!Cell")
    # ⑤ 聚合
    node(4, "dia", "存在 critical ?")
    node(4, "dia", "存在弃权 / 证据不足 ?")
    node(4, "dia", "存在待复核 ?")
    node(4, "box", "结论：通过")
    node(4, "box", "结论：待复核（含弃权）")
    node(4, "box", "结论：待复核")
    node(4, "box", "结论：不通过")
    node(4, "box", "写 audit_run：批次 / 计数 / 判定批次号")
    # ⑥ 复核
    node(5, "box", "审核工作台：左原文 / 右问题 / 定位高亮")
    node(5, "box", "确认 / 误报 / 补证")
    node(5, "box", "手动新增问题（漏报信号）")
    node(5, "box", "写 decision + 反馈台账")
    node(5, "box", "Jev 样本累积：置信度 × 对错")
    node(5, "box", "重算规则健康度")
    # ⑦ 报告
    node(6, "dia", "待复核 > 0 ?")
    node(6, "box", "409 拒绝，提示未复核条数")
    node(6, "box", "生成报告：结论 + 发现 + 证据 + 建议")
    node(6, "box", "输出 HTML / DOCX / PDF")
    node(6, "box", "写 report 表 + 审计日志")
    # ⑧ 进化
    node(7, "box", "反馈台账：确认 / 误报 / 补证 / 新增")
    node(7, "dia", "反向反馈 ≥ 3 ?")
    node(7, "box", "调度器自动归因，标注「模型 / 兜底」")
    node(7, "box", "人工沉淀：改阈值 / 降级 / 新建规则")
    node(7, "box", "参数草稿 → 发布生效")
    node(7, "box", "规则回放：历史案例影响面")
    node(7, "box", "冲突检测：区间 / 重复 / 集合互斥")
    node(7, "box", "接入矩阵：规则 / 点位 / 本体")


build_nodes()
COL_BOTTOM = max(n["y"] + n["h"] for n in NODES)
LOOP_Y = COL_BOTTOM + 96
H = LOOP_Y + 150

img = Image.new("RGB", (W, H), "#FFFFFF")
d = ImageDraw.Draw(img)
SEGS = []          # 已绘制的线段（用于自检）
RECTS = []         # 框体矩形


def rrect(n):
    return (n["x"], n["y"], n["x"] + n["w"], n["y"] + n["h"])


def line(p1, p2, color, w=3):
    d.line([p1, p2], fill=color, width=w)
    SEGS.append((p1, p2))


def arrow(p1, p2, color, w=3):
    line(p1, p2, color, w)
    ang = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
    for s in (0.42, -0.42):
        d.line([p2, (p2[0] - 16 * math.cos(ang + s), p2[1] - 16 * math.sin(ang + s))],
               fill=color, width=w)


def draw_node(n):
    x, y, w, h = n["x"], n["y"], n["w"], n["h"]
    if n["kind"] == "term":
        d.rounded_rectangle([x, y, x + w, y + h], radius=h // 2, outline=n["color"], width=3, fill=n["fill"])
    elif n["kind"] == "dia":
        cx, cy = x + w // 2, y + h // 2
        d.polygon([(cx, y), (x + w, cy), (cx, y + h), (x, cy)], outline=n["color"], width=3, fill="#FFFFFF")
    else:
        d.rounded_rectangle([x, y, x + w, y + h], radius=10, outline=n["color"], width=3, fill=n["fill"])
    lh = 33
    ty = y + (h - len(n["lines"]) * lh) / 2
    f = F(n["size"])
    for ln in n["lines"]:
        tw = d.textlength(ln, font=f)
        d.text((x + (w - tw) / 2, ty), ln, font=f, fill=INK)
        ty += lh
    RECTS.append((x, y, x + w, y + h))


# 标题
d.text((MARGIN_L, 74), "AI 审核平台 · 全流程架构图", font=F(56, True), fill=INK)
d.text((MARGIN_L, 148), "八段流水线：接入 → 解析 → 路由 → 判定 → 聚合 → 复核 → 报告 → 进化",
       font=F(26), fill=MUT)

# 阶段头
for i, (name, color, _f) in enumerate(STAGES):
    d.rounded_rectangle([COLS[i], HEAD_Y, COLS[i] + COL_W, HEAD_Y + HEAD_H], radius=8, fill=color)
    f = F(23, True)
    tw = d.textlength(name, font=f)
    d.text((COLS[i] + (COL_W - tw) / 2, HEAD_Y + 10), name, font=f, fill="#FFFFFF")
    RECTS.append((COLS[i], HEAD_Y, COLS[i] + COL_W, HEAD_Y + HEAD_H))

# 阶段头之间的箭头（在列间隙内）
for i in range(COLS_N - 1):
    x1 = COLS[i] + COL_W + 14
    x2 = COLS[i + 1] - 14
    yy = HEAD_Y + HEAD_H // 2
    arrow((x1, yy), (x2, yy), "#8F959E", 3)

# 节点
for n in NODES:
    draw_node(n)

# 列内竖直箭头（只走节点间隙）
for col in range(COLS_N):
    col_nodes = [n for n in NODES if n["x"] == COLS[col]]
    col_nodes.sort(key=lambda n: n["y"])
    for a, b in zip(col_nodes, col_nodes[1:]):
        cx = a["x"] + a["w"] // 2
        arrow((cx, a["y"] + a["h"] + 6), (cx, b["y"] - 8), "#8F959E", 3)

# 底部回流带：⑧ 最后一框 → ④ 首框（走底部预留走廊，不穿任何框）
last8 = [n for n in NODES if n["x"] == COLS[7]][-1]
first4 = [n for n in NODES if n["x"] == COLS[3]][0]
lx = last8["x"] + last8["w"] // 2
gutter = COLS[3] - COL_GAP // 2          # 第③④列之间的空隙，走竖线不穿框
entry_y = first4["y"] + first4["h"] // 2
line((lx, last8["y"] + last8["h"]), (lx, LOOP_Y), "#7F3BF5", 4)
line((lx, LOOP_Y), (gutter, LOOP_Y), "#7F3BF5", 4)
line((gutter, LOOP_Y), (gutter, entry_y), "#7F3BF5", 4)
arrow((gutter, entry_y), (first4["x"] - 8, entry_y), "#7F3BF5", 4)
d.text((gutter + 14, LOOP_Y + 12),
       "参数发布 / 规则演进后 · 下一轮审核生效", font=F(22), fill="#7F3BF5")

# 图例（右上角）
LX, LY = W - MARGIN_R - 620, 64
d.rounded_rectangle([LX, LY, LX + 620, LY + 150], radius=12, outline="#E5E6E8", width=2, fill="#FFFFFF")
d.text((LX + 20, LY + 14), "图例", font=F(24, True), fill=INK)
items = [("box", "步骤"), ("dia", "判断"), ("term", "起止")]
bx = LX + 22
for kind, label in items:
    if kind == "dia":
        d.polygon([(bx + 40, LY + 74), (bx + 78, LY + 94), (bx + 40, LY + 114), (bx + 2, LY + 94)],
                  outline="#3370FF", width=3, fill="#FFFFFF")
    elif kind == "term":
        d.rounded_rectangle([bx, LY + 74, bx + 80, LY + 114], radius=20, outline="#3370FF", width=3)
    else:
        d.rounded_rectangle([bx, LY + 74, bx + 80, LY + 114], radius=8, outline="#3370FF", width=3)
    d.text((bx + 94, LY + 82), label, font=F(21), fill=MUT)
    bx += 196
d.text((LX + 20, LY + 124), "五态：满足 / 不满足 / 不适用 / 证据不足 / 执行失败", font=F(19), fill=MUT)

# ---------------- 几何自检：线段不得穿过框体 ----------------
def seg_hits_rect(p1, p2, r):
    x1, y1, x2, y2 = r
    ax, ay = p1
    bx, by = p2
    # 水平线
    if abs(ay - by) < 0.5:
        if not (min(y1, y2) < ay < max(y1, y2)):
            return False
        lo, hi = sorted((ax, bx))
        return lo < x2 and hi > x1
    # 垂直线
    if abs(ax - bx) < 0.5:
        if not (min(x1, x2) < ax < max(x1, x2)):
            return False
        lo, hi = sorted((ay, by))
        return lo < y2 and hi > y1
    return False


bad = []
for p1, p2 in SEGS:
    for r in RECTS:
        if seg_hits_rect(p1, p2, r):
            bad.append((p1, p2, r))
            break

out = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                   "docs", "审核全流程架构图.png")
img.save(out)
print("saved", out, img.size, "| 穿越框体的线段:", len(bad))
if bad:
    for p1, p2, r in bad[:5]:
        print("  ", p1, p2, "→ 框", r)
