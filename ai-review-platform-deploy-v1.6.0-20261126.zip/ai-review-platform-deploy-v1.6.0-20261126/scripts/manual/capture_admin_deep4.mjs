import fs from 'fs';
const OUT = process.env.SHOT_DIR || '/tmp/admin_deep4';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT||9412}/json/list`)).json();
const page = t.find(x=>x.type==='page')||t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id=1; const pend=new Map(); const steps=[]; const errs=[];
ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data);
  if(m.method==='Page.javascriptDialogOpening'){ ws.send(JSON.stringify({id:id++,method:'Page.handleJavaScriptDialog',params:{accept:true}})); return; }
  if(m.id&&pend.has(m.id)){const p=pend.get(m.id);pend.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}
  else if(m.method==='Runtime.exceptionThrown'){errs.push((m.params.exceptionDetails.exception?.description||'').slice(0,80));}});
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
const send=(m,p={})=>{const i=id++;ws.send(JSON.stringify({id:i,method:m,params:p}));return new Promise((res,rej)=>pend.set(i,{resolve:res,reject:rej}));};
const ev=async e=>{const r=await send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});return r.result?.value;};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let n=300;
async function shot(name, desc){
  n++;
  const r=await send('Page.captureScreenshot',{format:'png'});
  const file = `${String(n).padStart(3,'0')}-${name}.png`;
  fs.writeFileSync(`${OUT}/${file}`, Buffer.from(r.data,'base64'));
  steps.push({file, name, desc});
}
await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
await send('Network.setCacheDisabled',{cacheDisabled:true});
await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});

const PAGES = [
  ['home','首页'], ['projects','项目列表'], ['rules','规则库'], ['conflict','冲突提醒'],
  ['evolution','规则进化'], ['ontology','本体建模'], ['decision','决策表'], ['jev','Jev 校准'],
  ['users','账号管理'], ['messages','消息中心'], ['newrule','新建规则'],
];
for (const [view, label] of PAGES) {
  const ok = await ev(`(()=>{const e=document.querySelector('.menu-item[data-view="${view}"]'); if(e){e.click();return true} return false})()`);
  if (!ok) continue;
  await wait(1500);
  for (let k = 0; k < 3; k++) {
    await ev(`window.scrollTo(0, ${k * 620})`); await wait(650);
    await shot(`${label}-段${k+1}`, `${label}：第 ${k+1} 屏内容`);
  }
}

// 弹窗族
const modals = [
  ['newrule','#btn-nr-manual','新建规则-手工表单','名称/类别/等级/指标/算子/值/单位/适用范围'],
  ['decision','#btn-dt-new','决策表-新建弹窗','编码 → 名称 → 规则 JSON → 适用范围 → 灰度'],
  ['users','#btn-user-new','账号-新建弹窗','姓名 / 手机号 / 角色 / 初始密码'],
  ['conflict','#btn-conflict-detect','冲突-检测执行','全量扫描已发布规则'],
];
for (const [view, sel, name, desc] of modals) {
  await ev(`document.querySelector('.menu-item[data-view="${view}"]')?.click()`); await wait(1400);
  await ev(`(()=>{const e=document.querySelector('${sel}'); if(e) e.click()})()`); await wait(1600);
  await shot(name, desc);
  await ev(`document.querySelectorAll('.mask').forEach(m=>m.remove())`);
}
fs.writeFileSync(`${OUT}/steps.json`, JSON.stringify(steps,null,2));
console.log('TOTAL4', steps.length, 'ERRS', errs.slice(0,2));
ws.close(); process.exit(0);
