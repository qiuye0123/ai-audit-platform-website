# -*- coding: utf-8 -*-
"""系统全局功能流程架构图 v2：泳道式，一线一项，框/字/线不重叠。"""
from PIL import Image, ImageDraw, ImageFont

def F(s, b=False):
    p = "/System/Library/Fonts/STHeiti Medium.ttc" if b else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try: return ImageFont.truetype(p, s)
    except Exception: return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", s)

STAGES = [
 ("① 规则沉淀", "#3370FF", ["规则来源：上传文档", "规则来源：一段话", "规则来源：手工填写",
        "文本清洗与分段", "规则提炼（LLM 四元组）", "实体识别：指标名", "实体识别：单位",
        "本体门槛：别名归一", "本体门槛：未识别→提示", "冲突检测：区间无交集",
        "冲突检测：同向冗余", "规则草稿入库", "规则提交审批", "规则发布生效",
        "决策表：条件组合", "决策表：结论与严重度", "参数：阈值", "参数：开关", "参数：灰度范围",
        "接线矩阵：点位↔本体", "接线矩阵：点位↔Jev", "接线矩阵：点位↔反馈"]),
 ("② 解析", "#00B96B", ["文件上传", "格式识别", "体积与份数校验", "xlsx 工作表遍历", "docx 段落与表格",
        "pdf 页文本抽取", "md 行解析", "合并单元格还原", "表头识别", "扫描件检测",
        "OCR 识别", "解析报告：状态", "解析报告：缺口原因", "解析报告：原始文件名",
        "事实抽取：数值", "事实抽取：单位换算", "事实抽取：范围", "事实抽取：日期",
        "结构化抽取：百分比基数", "结构化抽取：分段费率", "结构化抽取：时序余额", "结构化抽取：勾选项",
        "Anchor：Sheet+Cell", "Anchor：第N段", "Anchor：第N页"]),
 ("③ 路由", "#FF8800", ["文档类型识别（104 类）", "审核类型识别（74 类）", "A~G 大类过滤",
        "点位路由（319）", "场景包匹配", "意图识别 focus", "点位裁剪", "执行计划：确定性",
        "执行计划：语义", "执行计划：证据要求"]),
 ("④ 判定", "#7F3BF5", ["读取行为参数", "参数：启用状态", "参数：忽略词", "参数：严重度映射",
        "确定性执行器判定", "断言求值：range", "断言求值：equality", "断言求值：sum_consistency",
        "断言求值：presence", "断言求值：ordering", "断言求值：contiguity", "断言求值：set_membership",
        "模型判定入口", "智能体版本读取", "智能体提示词", "模型路由解析", "LLM 调用",
        "多采样投票", "判定缓存", "Jev 置信度计算", "Jev 弃权判定", "证据校验：引文回查",
        "五态：pass", "五态：fail", "五态：na", "五态：insufficient", "五态：unknown"]),
 ("⑤ 结论", "#F54A45", ["点位结论落库", "同标题合并", "引擎优先去重", "严重度聚合",
        "待复核统计", "覆盖率统计", "批次号写入", "报告门禁判断", "HTML 报告", "DOCX 报告",
        "PDF 报告", "证据定位展示"]),
 ("⑥ 人工反馈", "#0FA6A6", ["定位复核：原文高亮", "确认问题", "标记误报", "补充证据",
        "手动新增发现", "反馈归一（五类）", "写 decision 表", "Jev 样本累积", "规则健康度：命中",
        "规则健康度：override", "抽样复核"]),
 ("⑦ 进化", "#7F3BF5", ["归因：模型原因", "归因：兜底原因", "反向反馈计数", "≥3 次触发",
        "候选快照 before", "候选快照 after", "参数调整", "行为调整", "新规则沉淀",
        "草稿→发布", "回滚到 before", "冻结改进器", "规则回放", "影响面评估",
        "冲突复检", "本体修订候选", "I-gain 度量"]),
]

BW, BH, GX, GY = 340, 92, 34, 30
PER = 5
ML, MT = 300, 170
W = ML + PER * BW + (PER - 1) * GX + 260

def layout():
    ys, out = MT, {}
    for name, color, items in STAGES:
        nrow = (len(items) + PER - 1) // PER
        out[name] = {"y": ys, "h": 52 + nrow * (BH + GY), "nrow": nrow, "items": []}
        for i, it in enumerate(items):
            r, c = divmod(i, PER)
            out[name]["items"].append((ML + c * (BW + GX), ys + 52 + r * (BH + GY), it))
        ys += out[name]["h"] + 120
    return out, ys

layout_, H = layout()
img = Image.new("RGB", (W, H + 60), "#FFFFFF"); d = ImageDraw.Draw(img)
d.text((40, 46), "AI 审核平台 · 全局功能流程架构（一项一框，不含账号/首页）", font=F(44, True), fill="#1F2329")
d.text((40, 106), "七段泳道：规则沉淀 → 解析 → 路由 → 判定 → 结论 → 人工反馈 → 进化；右侧竖线为进化回流", font=F(22), fill="#646A73")

def chain_arrow(p1, p2, color):
    d.line([p1, p2], fill=color, width=3)
    d.ellipse([p2[0] - 5, p2[1] - 5, p2[0] + 5, p2[1] + 5], fill=color)

for name, color, items in STAGES:
    info = layout_[name]
    d.rounded_rectangle([70, info["y"], 240, info["y"] + info["h"] - 10], radius=10, fill=color)
    f = F(24, True)
    lines = [name[:2], name[3:]] if len(name) > 6 else [name]
    ty = info["y"] + info["h"] // 2 - 34
    for ln in lines:
        tw = d.textlength(ln, font=f); d.text((70 + (170 - tw) // 2, ty), ln, font=f, fill="#FFFFFF"); ty += 34
    boxes = info["items"]
    for (x, y, txt) in boxes:
        d.rounded_rectangle([x, y, x + BW, y + BH], radius=9, outline=color, width=3, fill="#FFFFFF")
        f2 = F(19)
        tw = d.textlength(txt, font=f2)
        while tw > BW - 26 and len(txt) > 4:
            txt = txt[:-2]; tw = d.textlength(txt, font=f2)
        d.text((x + (BW - tw) / 2, y + BH / 2 - 12), txt, font=f2, fill="#1F2329")
    for i, (x, y, _) in enumerate(boxes):
        r, c = divmod(i, PER)
        if c < PER - 1 and i + 1 < len(boxes):
            d.line([(x + BW, y + BH // 2), (x + BW + GX, y + BH // 2)], fill=color, width=3)
        if c == PER - 1 and i + 1 < len(boxes):
            nx, ny, _ = boxes[i + 1]
            d.line([(x + BW // 2, y + BH), (x + BW // 2, y + BH + GY // 2)], fill=color, width=3)
            d.line([(x + BW // 2, y + BH + GY // 2), (nx + BW // 2, y + BH + GY // 2)], fill=color, width=3)
            d.line([(nx + BW // 2, y + BH + GY // 2), (nx + BW // 2, ny)], fill=color, width=3)

names = [s[0] for s in STAGES]
for a, b in zip(names, names[1:]):
    ia, ib = layout_[a], layout_[b]
    ax, ay, _ = ia["items"][0]
    bx, by, _ = ib["items"][0]
    cx = ML + BW // 2
    y1 = ia["y"] + ia["h"] - 14
    y2 = by - 12
    d.line([(cx, y1), (cx, y2)], fill="#3370FF", width=4)
    d.polygon([(bx + BW // 2 - 8, by - 10), (bx + BW // 2 + 8, by - 10), (bx + BW // 2, by + 2)], fill="#3370FF")

fi = layout_["⑦ 进化"]; si = layout_["① 规则沉淀"]
LX = 34
y_bottom = fi["y"] + fi["h"] + 24
y_top = si["y"] - 34
d.line([(240, y_bottom), (LX, y_bottom)], fill="#7F3BF5", width=4)
d.line([(LX, y_bottom), (LX, y_top)], fill="#7F3BF5", width=4)
d.line([(LX, y_top), (240, y_top)], fill="#7F3BF5", width=4)
d.polygon([(252, y_top), (238, y_top - 8), (238, y_top + 8)], fill="#7F3BF5")
d.text((6, y_top + 48), "进\n化\n回\n流", font=F(19), fill="#7F3BF5", spacing=6)

d.text((40, H + 10), "蓝线=主链跨段；框内为单一功能项；同段内由左向右推进，换行处向下折返。",
       font=F(19), fill="#8F959E")
img.save("docs/系统全局功能流程架构_v2.png")
print("saved", img.size, "items", sum(len(s[2]) for s in STAGES))
