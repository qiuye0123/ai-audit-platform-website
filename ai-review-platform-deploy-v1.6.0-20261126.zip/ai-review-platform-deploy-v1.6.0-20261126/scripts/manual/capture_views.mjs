// 逐视图采集：直接切 showView(id) → 断言 #view-id 可见 → 截图（sha256 去重）
import fs from 'fs'; import crypto from 'crypto';
const OUT = process.env.SHOT_DIR || '/tmp/shots_views';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT || 9410}/json/list`)).json();
const page = t.find(x => x.type === 'page') || t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 1; const pend = new Map();
ws.addEventListener('message', ev => { const m = JSON.parse(ev.data);
  if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id);
    m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } });
await new Promise((r, j) => { ws.addEventListener('open', r, { once: true }); ws.addEventListener('error', j, { once: true }); });
const send = (method, params = {}) => { const i = id++; ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((res, rej) => pend.set(i, { resolve: res, reject: rej })); };
const ev = async e => (await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true })).result?.value;
const wait = ms => new Promise(r => setTimeout(r, ms));
await send('Page.enable'); await send('Runtime.enable');
await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
const BASE = process.env.BASE || 'http://127.0.0.1:8765';
await send('Page.navigate', { url: `${BASE}/login` }); await wait(900);
await ev(`document.querySelector('#username').value='13800138000';document.querySelector('#password').value=${JSON.stringify(process.env.ADMIN_PW || '')};document.querySelector('#login-form').requestSubmit()`);
await wait(2600);
console.log('login', await ev(`!!document.querySelector('#view-home')`));

const VIEWS = ['home','projects','myaudits','auditrecords','workbench','report','newproject','project',
 'rules','newrule','sediment','ontology','model','conflict','evolution','errorbook','users','openplatform','auditlogs','agents','messages'];
const seen = new Map(); let n = 0, skipped = 0, failed = [];
for (const v of VIEWS) {
  const ok = await ev(`(()=>{ if(typeof showView!=='function') return 'nofn'; showView(${JSON.stringify(v)});
    const el=document.querySelector('#view-'+${JSON.stringify(v)}); return el ? (el.hidden? 'hidden':'ok') : 'missing'; })()`);
  await wait(700);
  if (ok !== 'ok') { failed.push([v, ok]); console.log('WARN', v, ok); continue; }
  const r = await send('Page.captureScreenshot', { format: 'png' });
  const buf = Buffer.from(r.data, 'base64');
  const h = crypto.createHash('sha256').update(buf).digest('hex');
  if (seen.has(h)) { skipped++; console.log('SKIP dup', v, '==', seen.get(h)); continue; }
  seen.set(h, v); n++;
  fs.writeFileSync(`${OUT}/${String(n).padStart(2,'0')}-view-${v}.png`, buf);
  console.log('shot', n, v);
}
// 弹窗/抽屉
for (const [name, sel] of [['newproject-modal','#btn-new-project'], ['report-drawer','#wb-preview-report'], ['profile','#btn-profile']]) {
  const clicked = await ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); if(!e) return false; e.click(); return true})()`);
  await wait(600);
  if (!clicked) { console.log('WARN no-trigger', name); continue; }
  const r = await send('Page.captureScreenshot', { format: 'png' });
  const buf = Buffer.from(r.data, 'base64');
  const h = crypto.createHash('sha256').update(buf).digest('hex');
  if (seen.has(h)) { skipped++; console.log('SKIP dup', name); continue; }
  seen.set(h, name); n++;
  fs.writeFileSync(`${OUT}/${String(n).padStart(2,'0')}-${name}.png`, buf);
  console.log('shot', n, name);
  await ev(`document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))`); await wait(300);
}
console.log(`TOTAL ${n} skipped ${skipped} failed ${JSON.stringify(failed)}`);
