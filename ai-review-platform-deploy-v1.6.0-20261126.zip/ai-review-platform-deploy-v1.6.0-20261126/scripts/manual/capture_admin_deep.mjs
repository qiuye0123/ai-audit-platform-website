// 管理员端深度截图（数据驱动，目标 100+ 张）
import fs from 'fs';
const OUT = process.env.SHOT_DIR || '/tmp/admin_deep';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT||9412}/json/list`)).json();
const page = t.find(x=>x.type==='page')||t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id=1; const pend=new Map(); const errs=[]; const steps=[];
ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data);
  if(m.method==='Page.javascriptDialogOpening'){ const pv=m.params;
    ws.send(JSON.stringify({id:id++,method:'Page.handleJavaScriptDialog',params:{accept:true,promptText: (globalThis.__prompt||'')}})); return; }
  if(m.id&&pend.has(m.id)){const p=pend.get(m.id);pend.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}
  else if(m.method==='Runtime.exceptionThrown'){errs.push((m.params.exceptionDetails.exception?.description||'').slice(0,120));}});
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
const send=(m,p={})=>{const i=id++;ws.send(JSON.stringify({id:i,method:m,params:p}));return new Promise((res,rej)=>pend.set(i,{resolve:res,reject:rej}));};
const ev=async e=>{const r=await send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});return r.result?.value;};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let n=0;
async function shot(name, desc){
  n++;
  const r=await send('Page.captureScreenshot',{format:'png'});
  const file = `${String(n).padStart(3,'0')}-${name}.png`;
  fs.writeFileSync(`${OUT}/${file}`, Buffer.from(r.data,'base64'));
  steps.push({file, name, desc});
  console.log('shot', file);
}
const BASE = process.env.BASE || 'http://127.0.0.1:8765';

// 页面定义：[视图, 名称, 说明, 交互列表]
const PAGES = [
  ['home','首页','管理员首页：6 个运营指标 + 4 个规则质量指标',[
    ['shot','首屏总览','顶部 10 个 KPI 卡片，展示今日待复核、规则命中、平均健康度'],
    ['scroll','y=600','下滑到待复核项目'],
    ['shot','待复核项目','按待复核数量排序的项目列表'],
    ['scroll','y=1200','下滑到最近动态'],
    ['shot','最近动态','规则变更与审核动作的时间线'],
  ]],
  ['projects','项目列表','项目列表：筛选 + 序号倒序 + 分页',[
    ['shot','列表默认','默认按创建时间倒序，序号最大在最上'],
    ['click','#proj-filter-status','打开状态筛选'],
    ['shot','状态筛选','状态下拉：全部/待审核/待复核/已确认'],
    ['fill','#proj-q','工艺','项目名关键字筛选'],
    ['click','#btn-proj-search','执行筛选'],
    ['shot','筛选结果','按关键字「工艺」过滤后的结果'],
    ['click','#proj-page-next','翻到下一页'],
    ['shot','分页','分页器：上一页/下一页 + 总数'],
    ['click','#project-list [data-detail]','打开项目详情'],
    ['shot','项目详情','文件清单 + 审核结论 + 问题数 + 报告入口'],
  ]],
  ['rules','规则库','规则库：335 条（16 可编辑 + 319 审核库点位）',[
    ['shot','默认列表','左侧分组列表（按类别），右侧详情面板'],
    ['click','#btn-rule-search','查询'],
    ['fill','#rule-q','温度','按关键字搜索规则'],
    ['click','#btn-rule-search','执行搜索'],
    ['shot','搜索结果','匹配「温度」的规则'],
    ['select','#rule-src','library','筛选审核库点位'],
    ['shot','仅库点位','319 条审核库点位'],
    ['select','#rule-src','db','切回可编辑规则'],
    ['click','.rule-item','打开第一条规则详情'],
    ['shot','规则详情','规则定义 / 为什么这么判 / 阈值参数 / 生命周期'],
    ['click','#rp-save','保存参数草稿'],
    ['shot','参数草稿','保存后提示「已保存草稿，点发布生效后才生效」'],
    ['click','#rp-publish','发布参数'],
    ['shot','参数发布','发布成功后提示「下一轮审核生效」'],
  ]],
  ['newrule','新建规则','新建规则：上传拆解 / 一句话生成 / 手工填写',[
    ['shot','上传拆解','默认模式：上传文件后由系统拆解出规则草稿'],
    ['click','#btn-nr-nl','切到一句话生成'],
    ['shot','一句话生成','输入自然语言描述，生成规则草稿'],
    ['click','#btn-nr-manual','切到手工填写'],
    ['shot','手工填写','名称/类别/等级/指标/算子/值/单位/适用范围'],
  ]],
  ['conflict','冲突提醒','冲突提醒：检测 + 裁决',[
    ['shot','默认','KPI + 冲突清单（空态提示）'],
    ['click','#btn-conflict-detect','执行全量检测'],
    ['shot','检测后','扫描已发布规则，产出区间矛盾/重复/集合互斥'],
  ]],
  ['evolution','规则进化','规则进化：反馈台账 + 沉淀',[
    ['shot','反馈台账','类型标签 + 问题/规则 + 理由 + 来源时间 + 状态'],
    ['click','[data-evt="wrong"]','错题集'],
    ['shot','错题集','被判误报的案例，可沉淀为规则修订'],
    ['click','[data-evt="miss"]','漏报集'],
    ['shot','漏报集','人工新增的问题（AI 未覆盖）'],
    ['click','[data-evt="evolve"]','进化建议'],
    ['shot','进化建议','规则级 + 审核点级建议'],
    ['click','[data-evt="settled"]','已沉淀'],
    ['shot','已沉淀','处理记录：修订 / 新建 / 忽略'],
  ]],
  ['ontology','本体建模','本体建模：类型 / 实例 / 别名 / 链接',[
    ['shot','默认','左侧类型树，右侧实例与健康度'],
    ['click','.onto-type','选择类型'],
    ['shot','实例列表','该类型下的全部实例与别名'],
  ]],
  ['decision','决策表','决策表：多条件组合判定',[
    ['shot','列表','编码/行数/命中策略/适用范围/灰度/状态'],
    ['click','#btn-dt-new','新建决策表'],
    ['shot','新建引导','弹窗引导：编码 → 名称 → 规则 JSON → 适用范围 → 灰度'],
  ]],
  ['jev','Jev 校准','Jev 校准：选择性预测',[
    ['shot','总览','样本数 / ECE / 覆盖率 / 阈值'],
    ['click','[data-jev="rules"]','按规则'],
    ['shot','按规则','每条规则的样本与准确率'],
  ]],
  ['users','账号管理','账号管理：审核员与管理员',[
    ['shot','列表','序号 + 姓名 + 手机 + 角色 + 状态 + 操作'],
    ['click','#btn-user-new','新建账号'],
    ['shot','新建账号','表单：姓名 / 手机 / 角色 / 初始密码'],
  ]],
  ['messages','消息中心','消息中心',[
    ['shot','列表','只保留需要行动或真实故障的消息'],
  ]],
];

await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
await send('Network.setCacheDisabled',{cacheDisabled:true});
await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
await send('Page.navigate',{url:`${BASE}/logout`}); await wait(500);
await send('Page.navigate',{url:`${BASE}/login`}); await wait(1000);
await shot('登录页','登录页：手机号 + 密码 + 企业 SSO 单点登录');
await ev(`document.querySelector('#username').value=${JSON.stringify(process.env.ADMIN_PHONE||'13800138000')};document.querySelector('#password').value=${JSON.stringify(process.env.ADMIN_PW||'')}`);
await ev(`document.querySelector('#login-form').requestSubmit()`); await wait(2600);
await ev(`document.querySelector('#profile-panel') && (document.querySelector('#profile-panel').hidden=true)`);
await shot('登录后首页','登录后进入管理员首页');

for (const [view, name, desc, acts] of PAGES) {
  const ok = await ev(`(()=>{const e=document.querySelector('.menu-item[data-view="${view}"]'); if(e){e.click();return true} return false})()`);
  await wait(1600);
  if (!ok) { await shot(name+'-缺失', desc+'（页面未找到）'); continue; }
  await shot(name, desc);
  for (const a of acts) {
    const [kind, sel, val, cap] = a;
    if (kind === 'shot') { await shot(sel, val); continue; }
    if (kind === 'click') { await ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); if(e){e.click();return true} return false})()`); await wait(900); }
    if (kind === 'fill') { await ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); if(e){e.value=${JSON.stringify(sel==='#rule-q'?val:'')}; if(e.id==='rule-q'){e.value=${JSON.stringify(val)};} return true} return false})()`); await wait(300); }
    if (kind === 'select') { await ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)}); if(e){e.value=${JSON.stringify(val)}; e.dispatchEvent(new Event('change')); return true} return false})()`); await wait(900); }
    if (kind === 'scroll') { await ev(`window.scrollTo(0, ${parseInt(String(val).replace('y=',''))})`); await wait(600); }
  }
}
fs.writeFileSync(`${OUT}/steps.json`, JSON.stringify(steps,null,2));
console.log('TOTAL', steps.length, 'ERRS', errs.slice(0,3));
ws.close(); process.exit(0);
