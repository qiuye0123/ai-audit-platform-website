// 管理员端深度截图 2：逐条规则 / 逐个项目 / 逐类本体 / 工作台标签
import fs from 'fs';
const OUT = process.env.SHOT_DIR || '/tmp/admin_deep2';
fs.mkdirSync(OUT, { recursive: true });
const t = await (await fetch(`http://127.0.0.1:${process.env.CDP_PORT||9412}/json/list`)).json();
const page = t.find(x=>x.type==='page')||t[0];
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id=1; const pend=new Map(); const steps=[]; const errs=[];
ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data);
  if(m.method==='Page.javascriptDialogOpening'){ ws.send(JSON.stringify({id:id++,method:'Page.handleJavaScriptDialog',params:{accept:true}})); return; }
  if(m.id&&pend.has(m.id)){const p=pend.get(m.id);pend.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}
  else if(m.method==='Runtime.exceptionThrown'){errs.push((m.params.exceptionDetails.exception?.description||'').slice(0,100));}});
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
const send=(m,p={})=>{const i=id++;ws.send(JSON.stringify({id:i,method:m,params:p}));return new Promise((res,rej)=>pend.set(i,{resolve:res,reject:rej}));};
const ev=async e=>{const r=await send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});return r.result?.value;};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let n=100;
async function shot(name, desc){
  n++;
  const r=await send('Page.captureScreenshot',{format:'png'});
  const file = `${String(n).padStart(3,'0')}-${name}.png`;
  fs.writeFileSync(`${OUT}/${file}`, Buffer.from(r.data,'base64'));
  steps.push({file, name, desc});
}
await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
await send('Network.setCacheDisabled',{cacheDisabled:true});
await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
const BASE = process.env.BASE || 'http://127.0.0.1:8765';

// 逐条规则详情
await ev(`document.querySelector('.menu-item[data-view="rules"]')?.click()`); await wait(1800);
const ruleCount = await ev(`document.querySelectorAll('.rule-item').length`);
for (let i = 0; i < Math.min(ruleCount, 24); i++) {
  const ok = await ev(`(()=>{const els=document.querySelectorAll('.rule-item'); const e=els[${i}]; if(!e) return null; e.click(); return e.innerText.split('\\n')[0].slice(0,20)})()`);
  if (!ok) break;
  await wait(1100);
  await shot(`规则详情-${i+1}`, `第 ${i+1} 条规则详情：${ok}（判据 / 阈值 / 生命周期 / 命中趋势）`);
}

// 逐个项目详情
await ev(`document.querySelector('.menu-item[data-view="projects"]')?.click()`); await wait(1800);
const projCount = await ev(`document.querySelectorAll('#project-list [data-detail]').length`);
for (let i = 0; i < Math.min(projCount, 5); i++) {
  const ok = await ev(`(()=>{const els=document.querySelectorAll('#project-list [data-detail]'); const e=els[${i}]; if(!e) return null; e.click(); return true})()`);
  if (!ok) break;
  await wait(2200);
  const title = await ev(`document.querySelector('#proj-title')?.innerText || ''`);
  await shot(`项目详情-${i+1}`, `项目：${title}（文件清单 + 审核结论 + 问题明细 + 报告）`);
  // 工作台标签
  await ev(`document.querySelector('[data-tab="rules"]')?.click()`); await wait(900);
  await shot(`项目详情-${i+1}-规则项`, `项目 ${i+1}：规则不通过项（按规则聚合，含命中位置）`);
  await ev(`document.querySelector('.menu-item[data-view="projects"]')?.click()`); await wait(1400);
}

// 本体类型逐个
await ev(`document.querySelector('.menu-item[data-view="ontology"]')?.click()`); await wait(1600);
const ontoCount = await ev(`document.querySelectorAll('.onto-type').length`);
for (let i = 0; i < Math.min(ontoCount, 8); i++) {
  const ok = await ev(`(()=>{const els=document.querySelectorAll('.onto-type'); const e=els[${i}]; if(!e) return null; e.click(); return e.innerText.split('\\n')[0].slice(0,16)})()`);
  if (!ok) break;
  await wait(900);
  await shot(`本体-${i+1}`, `本体类型：${ok}（实例 / 别名 / 链接）`);
}

// Jev / 冲突 / 消息 二次
await ev(`document.querySelector('.menu-item[data-view="jev"]')?.click()`); await wait(1400);
await shot('Jev-阈值设置', 'Jev：最小准确率设置与阈值反推');
await ev(`document.querySelector('.menu-item[data-view="conflict"]')?.click()`); await wait(1400);
await ev(`document.querySelector('#btn-conflict-detect')?.click()`); await wait(2600);
await shot('冲突-检测完成', '冲突全量检测结果：类型 / 严重度 / 涉及规则 / 裁决入口');
await ev(`document.querySelector('.menu-item[data-view="users"]')?.click()`); await wait(1400);
await shot('账号-操作列', '账号管理：重置密码 / 停用 / 角色调整');
await ev(`document.querySelector('#btn-user-new')?.click()`); await wait(900);
await shot('账号-新建表单', '新建账号表单：姓名 / 手机号 / 角色 / 初始密码规则');

fs.writeFileSync(`${OUT}/steps.json`, JSON.stringify(steps,null,2));
console.log('TOTAL2', steps.length, 'ERRS', errs.slice(0,3));
ws.close(); process.exit(0);
