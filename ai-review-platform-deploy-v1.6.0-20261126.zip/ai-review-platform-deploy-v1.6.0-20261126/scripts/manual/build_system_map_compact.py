#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compact horizontal rhythm for the AI 审核平台 system map.

Reads the existing self-drawn map (web/system_map.html), relocates all 12 bands
and 77 cards with a tighter horizontal rhythm, re-routes every connector as an
orthogonal M/H/V path, and writes:

  web/system_map.html                         -> service copy, relative screenshots
  docs/artifacts/系统全景图_外网版.html        -> single-file copy (data URI screenshots)
  /tmp/system_map_2600.html                   -> compact rhythm used for PNG
  /tmp/system_map_2400.html                   -> optional extra-compact rhythm

The PNG itself is captured by Chrome headless from the 2600px file.
No backend / route / business file is touched.
"""
from __future__ import annotations

import base64
import io
import json
import re
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "web" / "system_map.html"
ASSETS = ROOT / "web" / "architecture_assets"
OUT_WEB = SRC
OUT_EXTERNAL = ROOT / "docs" / "artifacts" / "系统全景图_外网版.html"
OUT_2600 = Path("/tmp/system_map_2600.html")
OUT_2400 = Path("/tmp/system_map_2400.html")

# Two deliberately different rhythms:
# HTML: 2720px, a little more air; PNG: 2600px, tighter cards/gaps/padding.
HTML_CFG = dict(
    content_fit=True,
    width=2720,
    height=1120,
    margin=12,
    sec_gap=10,
    band_pad=10,
    card_gap=8,
    css_head_pad="5px 7px 4px",
    css_body_pad="4px 7px 5px",
    css_head_font="10.4px",
    css_body_font="9.3px",
    css_body_line="1.29",
    css_band_left="10px",
    css_band_right="10px",
    css_band_note_font="8.4px",
)
PNG_CFG = dict(
    content_fit=True,
    width=2600,
    height=1120,
    margin=8,
    sec_gap=6,
    band_pad=8,
    card_gap=6,
    css_head_pad="4px 6px 3px",
    css_body_pad="3px 6px 4px",
    css_head_font="10.1px",
    css_body_font="9.1px",
    css_body_line="1.28",
    css_band_left="8px",
    css_band_right="8px",
    css_band_note_font="8px",
)

RE_MAP = re.compile(r"const MAP=(\{.*?\});\nconst params", re.S)
RE_CANVAS = re.compile(r"\.canvas\{position:absolute;width:\d+px;height:\d+px;")
RE_EDGES_CSS = re.compile(r"#edges\{position:absolute;inset:0;width:\d+px;height:\d+px;")
RE_SVG = re.compile(r'<svg id="edges" width="\d+" height="\d+" viewBox="0 0 \d+ \d+">')
RE_SHOT = re.compile(
    r'<figure class="shot"><a href="\$\{x\.src\}" target="_blank" rel="noopener">'
    r'<img src="\$\{x\.src\}" alt="\$\{x\.cap\}" loading="lazy"></a>'
    r'<figcaption>\$\{x\.cap\}</figcaption></figure>'
)


def allocate(weights: list[int], total: int, gap: int) -> list[int]:
    """Split `total` into integer widths, leaving `gap` between neighbours."""
    n = len(weights)
    if n == 0:
        return []
    available = total - gap * (n - 1)
    if available <= 0:
        raise ValueError("not enough horizontal room")
    raw = [available * w / sum(weights) for w in weights]
    out = [max(1, int(round(v))) for v in raw]
    # Fix rounding drift on the widest / last card so the row ends exactly.
    drift = total - gap * (n - 1) - sum(out)
    out[-1] += drift
    if out[-1] < 1:
        raise ValueError("bad allocation")
    return out


def row_groups(items: list[dict]) -> list[list[dict]]:
    """Group cards/sections by their current y, then left-to-right."""
    groups: dict[float, list[dict]] = {}
    for it in items:
        groups.setdefault(float(it["y"]), []).append(it)
    return [sorted(g, key=lambda x: x["x"]) for _, g in sorted(groups.items())]




def _text_width(text: str, font: float) -> float:
    """Approximate rendered width; CJK 1em, Latin ~0.56em. Used only for layout."""
    import re as _re
    t = _re.sub(r"<[^>]+>", "", str(text or ""))
    return sum((font if ord(ch) > 127 else font * 0.56) for ch in t)


def _natural_card_width(card: dict) -> int:
    """Content-fit card width: longest body line + a small breathing pad."""
    # header has a number badge, title, right-aligned sub and paddings; body has
    # 6px side padding. +58/+26 prevents the ellipsis that a pure text estimate
    # would otherwise cause (the previous build truncated titles like 系统管理…).
    head = _text_width(card.get("title"), 10.1) + _text_width(card.get("sub"), 8.0) + 58
    body = max([_text_width(x, 9.1) for x in (card.get("points") or [])] or [60])
    return max(112, int(max(head, body) + 26))


def _content_fit(mp: dict, cfg: dict) -> dict:
    """Cards hug their text; sections hug their rows; both axes are packed.

    Previous versions only removed horizontal stretch, leaving large vertical
    gaps between bands. This function reflows section rows vertically too, so
    the map is genuinely compact rather than a wide sparse canvas.
    """
    margin = int(cfg["margin"]); sec_gap = int(cfg["sec_gap"]); band_pad = int(cfg["band_pad"])
    card_gap = int(cfg["card_gap"])
    by_sec = {}
    for c in mp["cards"]:
        c["w"] = _natural_card_width(c)
        by_sec.setdefault(c["sec"], []).append(c)
    # 1) width/height of every section from its content rows
    for sec in mp["sections"]:
        rows = row_groups(by_sec.get(sec["id"], []))
        widest = 0
        inner_h = 24  # band title
        for i, row in enumerate(rows):
            widest = max(widest, sum(c["w"] for c in row) + card_gap * max(0, len(row) - 1))
            inner_h += max((c["h"] for c in row), default=0) + (card_gap if i < len(rows) - 1 else 0)
        sec["_content_w"] = max(160, widest + 2 * band_pad)
        sec["_content_h"] = inner_h + band_pad
    # 2) preserve original y-grouping; use the second row as the common width.
    # Every other row widens its sections/cards to the same total width, so all
    # rows form one aligned column instead of ragged widths.
    original_rows = row_groups(mp["sections"])
    row_widths = [sum(s["_content_w"] for s in row) + sec_gap * max(0, len(row) - 1)
                  for row in original_rows]
    target = row_widths[1] if len(row_widths) > 1 else max(row_widths)
    target = max(target, max(row_widths))  # never shrink a row with richer content
    canvas_w = max(1400, target + 2 * margin)
    y = margin
    for row, total in zip(original_rows, row_widths):
        # widen section shells proportionally to their content
        old_sec_sum = sum(s["_content_w"] for s in row)
        delta = max(0, target - total)
        assigned = 0
        for i, sec in enumerate(row):
            if i == len(row) - 1:
                add = delta - assigned
            else:
                add = int(round(delta * sec["_content_w"] / old_sec_sum)) if old_sec_sum else 0
                assigned += add
            sec["_target_w"] = sec["_content_w"] + max(0, add)
            # widen cards inside this section to fill the new shell
            cards = row_groups(by_sec.get(sec["id"], []))
            old_inner = max(1, sec["_content_w"] - 2 * band_pad)
            new_inner = max(1, sec["_target_w"] - 2 * band_pad)
            factor = new_inner / old_inner
            for cr in cards:
                for c in cr:
                    c["w"] = max(c["w"], int(round(c["w"] * factor)))
        # final correction: make the row exactly target wide
        used = sum(s["_target_w"] for s in row) + sec_gap * max(0, len(row) - 1)
        if used != target:
            row[-1]["_target_w"] += target - used
        x = margin
        row_h = max(s["_content_h"] for s in row)
        for sec in row:
            sec["x"] = x
            sec["w"] = sec["_target_w"]
            sec["y"] = y
            sec["h"] = row_h
            x += sec["w"] + sec_gap
        y += row_h + sec_gap
    # 3) cards inside their section, starting below the band title
    for sec in mp["sections"]:
        rows = row_groups(by_sec.get(sec["id"], []))
        cy = sec["y"] + band_pad + 20
        for row in rows:
            total = sum(c["w"] for c in row) + card_gap * max(0, len(row) - 1)
            x = sec["x"] + (sec["w"] - total) / 2
            for c in row:
                c["x"] = x
                c["y"] = cy
                x += c["w"] + card_gap
            cy += max((c["h"] for c in row), default=0) + card_gap
    for sec in mp["sections"]:
        sec.pop("_content_w", None); sec.pop("_content_h", None); sec.pop("_target_w", None)
    canvas_h = max(int(cfg["height"]), int(y + margin))
    mp["canvas"] = {"w": canvas_w, "h": canvas_h}
    return mp

def layout_map(src: dict, cfg: dict) -> dict:
    """Return a deep-copied map with new x/width values and re-routed edges."""
    mp = json.loads(json.dumps(src))  # deep copy
    width = int(cfg["width"])
    height = int(cfg["height"])
    mp["canvas"] = {"w": width, "h": height}
    if cfg.get("content_fit"):
        return _content_fit(mp, cfg)

    # ---- bands: fill every horizontal row edge to edge ----------------
    sec_rows = row_groups(mp["sections"])
    for row in sec_rows:
        total = width - 2 * cfg["margin"]
        widths = allocate([s["w"] for s in row], total, cfg["sec_gap"])
        x = cfg["margin"]
        for s, w in zip(row, widths):
            s["x"] = x
            s["w"] = w
            x += w + cfg["sec_gap"]

    # ---- cards: fill each band row edge to edge -----------------------
    by_sec: dict[str, list[dict]] = {}
    for c in mp["cards"]:
        by_sec.setdefault(c["sec"], []).append(c)
    for s in mp["sections"]:
        cards = by_sec.get(s["id"], [])
        for crow in row_groups(cards):
            total = s["w"] - 2 * cfg["band_pad"]
            widths = allocate([c["w"] for c in crow], total, cfg["card_gap"])
            x = s["x"] + cfg["band_pad"]
            for c, w in zip(crow, widths):
                c["x"] = x
                c["w"] = w
                x += w + cfg["card_gap"]

    # ---- orthogonal connectors ---------------------------------------
    cmap = {c["id"]: c for c in mp["cards"]}
    smap = {s["id"]: s for s in mp["sections"]}

    def cy(c):
        return c["y"] + c["h"] / 2

    def cx(c):
        return c["x"] + c["w"] / 2

    for e in mp["edges"]:
        f, t = cmap.get(e["f"]), cmap.get(e["t"])
        if not f or not t:
            continue
        fname = e["f"]
        # Four roles -> entry: a single bus above the role cards.
        if fname.startswith("role-") and e["t"] == "entry":
            bus_y = f["y"] - 5
            if fname == "role-platform":
                e["d"] = (
                    f"M {f['x'] + f['w'] / 2:.2f} {f['y']:.2f} "
                    f"V {bus_y:.2f} H {cx(t):.2f} V {t['y']:.2f}"
                )
            else:
                e["d"] = f"M {f['x'] + f['w'] / 2:.2f} {f['y']:.2f} V {bus_y:.2f}"
            continue

        # protocol / runtime / principles -> entry: a bus under the cards.
        if fname in {"protocol", "runtime", "principles"} and e["t"] == "entry":
            bus_y = f["y"] + f["h"] + 5
            if fname == "principles":
                e["d"] = (
                    f"M {f['x'] + f['w'] / 2:.2f} {f['y'] + f['h']:.2f} "
                    f"V {bus_y:.2f} H {cx(t):.2f} V {t['y'] + t['h']:.2f}"
                )
            else:
                e["d"] = (
                    f"M {f['x'] + f['w'] / 2:.2f} {f['y'] + f['h']:.2f} V {bus_y:.2f}"
                )
            continue

        # entry -> project: drop through the gap between bands, then left.
        if fname == "entry" and e["t"] == "project":
            lane_x = f["x"] - 3
            lane_y = smap[t["sec"]]["y"] - 5
            e["d"] = (
                f"M {f['x']:.2f} {cy(f):.2f} H {lane_x:.2f} V {lane_y:.2f} "
                f"H {cx(t):.2f} V {t['y']:.2f}"
            )
            continue

        # Same-row neighbours: straight horizontal; reverse flows included.
        if t["x"] >= f["x"] + f["w"] - 0.5:
            e["d"] = f"M {f['x'] + f['w']:.2f} {cy(f):.2f} H {t['x']:.2f}"
        elif t["x"] + t["w"] <= f["x"] + 0.5:
            e["d"] = f"M {f['x']:.2f} {cy(f):.2f} H {t['x'] + t['w']:.2f}"
        else:
            # Stacked rows inside one band (rules / mining / evolve).
            if cy(t) >= cy(f):
                e["d"] = f"M {cx(f):.2f} {f['y'] + f['h']:.2f} V {t['y']:.2f}"
            else:
                e["d"] = f"M {cx(f):.2f} {f['y']:.2f} V {t['y'] + t['h']:.2f}"
    return mp


def rhythm_css(cfg: dict) -> str:
    return f"""
/* build:rhythm */
.band-title{{left:{cfg['css_band_left']};}}
.band-note{{right:{cfg['css_band_right']};font-size:{cfg['css_band_note_font']};}}
.node-head{{padding:{cfg['css_head_pad']};font-size:{cfg['css_head_font']};}}
.node-body{{padding:{cfg['css_body_pad']};font-size:{cfg['css_body_font']};line-height:{cfg['css_body_line']};}}
.node-head em{{max-width:42%;}}
.shot img{{cursor:zoom-in;}}
.lightbox{{position:fixed;inset:0;z-index:80;background:rgba(15,23,42,.78);display:none;align-items:center;justify-content:center;padding:28px;backdrop-filter:blur(3px);}}
.lightbox.open{{display:flex;}}
.lightbox figure{{margin:0;max-width:min(1100px,92vw);max-height:92vh;display:flex;flex-direction:column;gap:8px;background:#fff;border-radius:10px;padding:8px;box-shadow:0 24px 70px rgba(0,0,0,.35);}}
.lightbox img{{display:block;max-width:100%;max-height:80vh;width:auto;height:auto;border-radius:6px;}}
.lightbox figcaption{{font-size:11px;color:#475467;text-align:center;}}
.lightbox-close{{position:absolute;right:18px;top:16px;z-index:2;}}
/* build:rhythm-end */
"""


LIGHTBOX_HTML = """<!-- build:lightbox -->
<div class="lightbox" id="lightbox" aria-hidden="true"><button class="btn lightbox-close" id="lightboxClose">关闭</button><figure><img id="lightboxImg" alt=""><figcaption id="lightboxCap"></figcaption></figure></div>
<!-- build:lightbox-end -->
"""


LIGHTBOX_JS = r"""
<script>
(function(){
  const lb=document.getElementById('lightbox');
  if(!lb)return;
  const im=document.getElementById('lightboxImg'), cap=document.getElementById('lightboxCap');
  function open(src,text){im.src=src;cap.textContent=text||'';lb.classList.add('open');lb.setAttribute('aria-hidden','false')}
  function close(){lb.classList.remove('open');lb.setAttribute('aria-hidden','true');im.removeAttribute('src')}
  document.getElementById('drawerContent').addEventListener('click',function(e){
    const s=e.target.closest('.shot img');
    if(s)open(s.src,s.dataset.cap||s.alt);
  });
  document.getElementById('lightboxClose').addEventListener('click',close);
  lb.addEventListener('click',function(e){if(e.target===lb)close()});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&lb.classList.contains('open'))close()});
})();
</script>
"""


SELFTEST_JS = r"""
<script>
(function(){
  const q=new URLSearchParams(location.search);
  if(q.get('selftest')!=='1')return;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const fmt=n=>Math.round(n*100)/100;
  function uniqueGaps(items,key){
    const groups={};
    for(const it of items){const g=(it.sec||it.id)+'@'+it.y;(groups[g]=groups[g]||[]).push(it)}
    const out=new Set();
    for(const g of Object.values(groups)){
      g.sort((a,b)=>a.x-b.x);
      for(let i=1;i<g.length;i++)out.add(Math.round(g[i].x-(g[i-1].x+g[i-1].w)));
    }
    return [...out].sort((a,b)=>a-b);
  }
  async function run(){
    const want=q.get('drawer')||'role-platform';
    try{openDrawer(want)}catch(e){}
    await sleep(450);
    try{await document.fonts.ready}catch(e){}
    const imgs=[...document.querySelectorAll('#drawer .shot img')];
    await Promise.all(imgs.map(im=>new Promise(res=>{
      if(im.complete)return res();
      im.addEventListener('load',res,{once:true});
      im.addEventListener('error',res,{once:true});
      setTimeout(res,1800);
    })));
    await sleep(120);
    const sections=MAP.sections;
    const cards=MAP.cards;
    const left=Math.min(...sections.map(s=>s.x));
    const right=Math.max(...sections.map(s=>s.x+s.w));
    const cardLeft=Math.min(...cards.map(c=>c.x));
    const cardRight=Math.max(...cards.map(c=>c.x+c.w));
    const auditCards=cards.map(c=>{
      const el=document.getElementById('n-'+c.id);
      const body=el.querySelector('.node-body');
      const ttl=el.querySelector('.ttl');
      const em=el.querySelector('em');
      return {
        id:c.id,x:c.x,y:c.y,w:c.w,h:c.h,
        overflow:el.scrollHeight>el.clientHeight+1||el.scrollWidth>el.clientWidth+1,
        bodyOverflow:body.scrollHeight>body.clientHeight+1||body.scrollWidth>body.clientWidth+1,
        titleEllipsis:ttl.scrollWidth>ttl.clientWidth+1,
        subEllipsis:em.scrollWidth>em.clientWidth+1,
        scrollW:el.scrollWidth,scrollH:el.scrollHeight,clientW:el.clientWidth,clientH:el.clientHeight
      };
    });
    const bands=[...document.querySelectorAll('.band-note,.band-title')].map(el=>({
      cls:el.className,text:el.textContent.trim(),clientW:el.clientWidth,scrollW:el.scrollWidth,
      overflow:el.scrollWidth>el.clientWidth+1
    }));
    const edges=[...document.querySelectorAll('#edges path.edge')];
    const pathRe=/^M -?\d+(?:\.\d+)? -?\d+(?:\.\d+)?(?: [HV] -?\d+(?:\.\d+)?)*$/;
    const badEdges=edges.filter(p=>!pathRe.test(p.getAttribute('d')||'')).map(p=>({f:p.dataset.f,t:p.dataset.t,d:p.getAttribute('d')}));
    const drawer=document.getElementById('drawer');
    const dr=drawer.getBoundingClientRect();
    const dcs=getComputedStyle(drawer);
    const agentCards=cards.filter(c=>c.sec==='agents');
    const head=document.querySelector('.node-head');
    const body=document.querySelector('.node-body');
    const bandTitle=document.querySelector('.band-title');
    const headCS=getComputedStyle(head), bodyCS=getComputedStyle(body), bandCS=getComputedStyle(bandTitle);
    const out={
      protocol:location.protocol,
      href:location.href,
      canvas:MAP.canvas,
      viewport:{w:innerWidth,h:innerHeight},
      document:{scrollW:document.documentElement.scrollWidth,clientW:document.documentElement.clientWidth,
                bodyScrollW:document.body.scrollWidth,bodyClientW:document.body.clientWidth},
      horizontalScroll:document.documentElement.scrollWidth>document.documentElement.clientWidth+1||
                       document.body.scrollWidth>document.body.clientWidth+1,
      content:{sectionLeft:fmt(left),sectionRight:fmt(right),
               sectionBlankLeft:fmt(left),sectionBlankRight:fmt(MAP.canvas.w-right),
               cardLeft:fmt(cardLeft),cardRight:fmt(cardRight),
               cardBlankLeft:fmt(cardLeft),cardBlankRight:fmt(MAP.canvas.w-cardRight),
               fillPct:fmt((right-left)/MAP.canvas.w*100)},
      rhythm:{cardGaps:uniqueGaps(cards),sectionGaps:(()=>{const s=[...sections].sort((a,b)=>a.y-b.y||a.x-b.x);const by={};for(const x of s){(by[x.y]=by[x.y]||[]).push(x)}const out=new Set();for(const g of Object.values(by)){g.sort((a,b)=>a.x-b.x);for(let i=1;i<g.length;i++)out.add(Math.round(g[i].x-(g[i-1].x+g[i-1].w)))}return [...out].sort((a,b)=>a-b)})(),
              headPadding:headCS.padding,bodyPadding:bodyCS.padding,bodyFont:bodyCS.fontSize,bodyLine:bodyCS.lineHeight,
              bandTitleLeft:bandCS.left},
      cards:{count:auditCards.length,
             overflow:auditCards.filter(c=>c.overflow),
             bodyOverflow:auditCards.filter(c=>c.bodyOverflow),
             titleEllipsis:auditCards.filter(c=>c.titleEllipsis),
             subEllipsis:auditCards.filter(c=>c.subEllipsis)},
      agents:{count:agentCards.length,uniqueY:[...new Set(agentCards.map(c=>c.y))],
              oneRow:agentCards.length===8&&new Set(agentCards.map(c=>c.y)).size===1},
      bands:{count:bands.length,overflow:bands.filter(b=>b.overflow)},
      edges:{count:edges.length,orthogonal:badEdges.length===0,bad:badEdges},
      drawer:{requested:want,open:drawer.classList.contains('open'),aria:drawer.getAttribute('aria-hidden'),
              left:fmt(dr.left),top:fmt(dr.top),width:fmt(dr.width),height:fmt(dr.height),transform:dcs.transform},
      images:{count:imgs.length,loaded:imgs.filter(im=>im.complete&&im.naturalWidth>0).length,
              allDataUri:imgs.length>0&&imgs.every(im=>im.src.startsWith('data:image/')),
              details:imgs.map(im=>({alt:im.alt,loaded:im.complete&&im.naturalWidth>0,w:im.naturalWidth,h:im.naturalHeight,src:im.src.slice(0,32)}))},
      lightbox:!!document.getElementById('lightbox')
    };
    let pre=document.getElementById('map-selftest');
    if(!pre){pre=document.createElement('pre');pre.id='map-selftest';pre.style.display='none';document.body.appendChild(pre)}
    pre.textContent=JSON.stringify(out);
    document.documentElement.setAttribute('data-selftest','1');
  }
  run();
})();
</script>
"""


OLD_SHOT = (
    '<figure class="shot"><a href="${x.src}" target="_blank" rel="noopener">'
    '<img src="${x.src}" alt="${x.cap}" loading="lazy"></a>'
    '<figcaption>${x.cap}</figcaption></figure>'
)
NEW_SHOT = (
    '<figure class="shot"><img src="${shotSrc(x.src)}" alt="${x.cap}" class="shot-img" '
    'data-cap="${x.cap}"><figcaption>${x.cap}</figcaption></figure>'
)

SHOT_SRC_JS = """/* build:shot-src */
function shotSrc(s){
  if(!s) return s;
  if(s.indexOf('data:')===0) return s;
  if(location.protocol==='file:' && s.indexOf('/architecture-assets/')===0)
    return 'architecture_assets/' + s.slice('/architecture-assets/'.length);
  return s;
}
/* build:shot-src-end */
"""


def clean_template(html: str) -> str:
    """Make re-runs idempotent by peeling off every build-injected block."""
    html = re.sub(r"\n?/\* build:rhythm \*/.*?/\* build:rhythm-end \*/", "", html, flags=re.S)
    html = re.sub(r"<!-- build:lightbox -->.*?<!-- build:lightbox-end -->\n?", "", html, flags=re.S)
    html = re.sub(r"<!-- build:scripts -->.*?<!-- build:scripts-end -->\n?", "", html, flags=re.S)
    html = re.sub(r"/\* build:shot-src \*/.*?/\* build:shot-src-end \*/\n?", "", html, flags=re.S)
    html = re.sub(r'<meta name="offline" content="true">\n?', "", html)
    html = re.sub(r"<!-- build:map-comment -->\n?", "", html)
    html = re.sub(r"<!-- 自包含离线版：.*?-->\n?", "", html)
    html = html.replace(NEW_SHOT, OLD_SHOT)
    # A previously-built service copy stores relative screenshot paths; the
    # builder always starts from the server-style absolute source form.
    html = re.sub(r"src:'architecture_assets/", "src:'/architecture-assets/", html)
    return html


def optimize_data_uri(path: Path) -> tuple[str, int, int]:
    """Downscale screenshots to a drawer-friendly size; never embed originals."""
    im = Image.open(path).convert("RGB")
    w, h = im.size
    max_w = 800
    if w > max_w:
        im = im.resize((max_w, round(h * max_w / w)), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=74, optimize=True, progressive=True, subsampling=2)
    raw = buf.getvalue()
    return "data:image/jpeg;base64," + base64.b64encode(raw).decode("ascii"), im.width, im.height


def build_html(template: str, mp: dict, cfg: dict, *, offline: bool) -> tuple[str, dict]:
    html = template
    compact_json = json.dumps(mp, ensure_ascii=False, separators=(",", ":"))
    html, n = RE_MAP.subn(lambda _m: "const MAP=" + compact_json + ";\nconst params", html, count=1)
    if n != 1:
        raise RuntimeError("could not replace MAP")
    html, n1 = RE_CANVAS.subn(
        f".canvas{{position:absolute;width:{cfg['width']}px;height:{cfg['height']}px;", html, count=1
    )
    html, n2 = RE_EDGES_CSS.subn(
        f"#edges{{position:absolute;inset:0;width:{cfg['width']}px;height:{cfg['height']}px;", html, count=1
    )
    html, n3 = RE_SVG.subn(
        f'<svg id="edges" width="{cfg["width"]}" height="{cfg["height"]}" '
        f'viewBox="0 0 {cfg["width"]} {cfg["height"]}">', html, count=1
    )
    if (n1, n2, n3) != (1, 1, 1):
        raise RuntimeError(f"canvas replacement failed: {n1},{n2},{n3}")

    # Replace the screenshot anchor with a safe lightbox trigger (data URIs must
    # not be opened as top-level navigation in some browsers).
    html, n = RE_SHOT.subn(lambda _m: NEW_SHOT, html, count=1)
    if n != 1:
        raise RuntimeError("could not replace screenshot markup")

    # Inject the rhythm CSS before the only </style>.
    html = html.replace("</style>", rhythm_css(cfg) + "</style>", 1)

    html = html.replace("const SHOTS={", SHOT_SRC_JS + "const SHOTS={", 1)

    if offline:
        used = sorted(set(re.findall(r"/architecture-assets/([A-Za-z0-9_.-]+)", html)))
        report = {"images": []}
        for name in used:
            uri, w, h = optimize_data_uri(ASSETS / name)
            html = html.replace(f"/architecture-assets/{name}", uri)
            report["images"].append({"name": name, "w": w, "h": h,
                                     "bytes": len(uri) - len("data:image/jpeg;base64,")})
        if re.search(r"/architecture-assets/[A-Za-z0-9_.-]+", html):
            raise RuntimeError("offline build still references architecture assets")
    else:
        report = {"images": "absolute /architecture-assets/ (file:// falls back to web/architecture_assets/)"}

    # Lightbox markup + behaviour.
    html = html.replace('<div class="hint">', LIGHTBOX_HTML + '<div class="hint">', 1)
    html = re.sub(
        r"</script>\s*</body></html>",
        lambda _m: "</script>\n<!-- build:scripts -->" + LIGHTBOX_JS + SELFTEST_JS
        + "<!-- build:scripts-end -->\n</body></html>",
        html, count=1,
    )
    if offline:
        html = html.replace(
            "<head>",
            '<head>\n<meta name="offline" content="true">\n'
            "<!-- 自包含离线版：无服务端依赖，无 127.0.0.1 资源引用，抽屉截图全部内嵌为 data URI -->",
            1,
        )
    return html, report


def main():
    template = clean_template(SRC.read_text(encoding="utf-8"))
    m = RE_MAP.search(template)
    if not m:
        raise SystemExit("MAP JSON not found in web/system_map.html")
    src_map = json.loads(m.group(1))

    web_map = layout_map(src_map, HTML_CFG)
    web_cfg = dict(HTML_CFG, width=web_map["canvas"]["w"], height=web_map["canvas"]["h"], content_fit=True)
    web_html, web_report = build_html(template, web_map, web_cfg, offline=False)
    OUT_WEB.write_text(web_html, encoding="utf-8")

    ext_html, ext_report = build_html(template, web_map, web_cfg, offline=True)
    OUT_EXTERNAL.write_text(ext_html, encoding="utf-8")

    png_map = layout_map(src_map, PNG_CFG)
    png_cfg = dict(PNG_CFG, width=png_map["canvas"]["w"], height=png_map["canvas"]["h"], content_fit=True)
    png_html, png_report = build_html(template, png_map, png_cfg, offline=True)
    OUT_2600.write_text(png_html, encoding="utf-8")

    # Optional extra-compact build, only used if it passes the same audit.
    compact_cfg = dict(PNG_CFG, content_fit=True)
    compact_map = layout_map(src_map, compact_cfg)
    compact_cfg = dict(compact_cfg, width=compact_map["canvas"]["w"], height=compact_map["canvas"]["h"])
    compact_html, compact_report = build_html(template, compact_map, compact_cfg, offline=True)
    OUT_2400.write_text(compact_html, encoding="utf-8")

    print(json.dumps({
        "web": {"path": str(OUT_WEB), "bytes": OUT_WEB.stat().st_size,
                "canvas": web_map["canvas"], "rhythm": {k: HTML_CFG[k] for k in ("margin", "sec_gap", "band_pad", "card_gap")},
                "images": web_report["images"]},
        "external": {"path": str(OUT_EXTERNAL), "bytes": OUT_EXTERNAL.stat().st_size,
                     "canvas": web_map["canvas"], "embedded": ext_report["images"]},
        "png2600": {"path": str(OUT_2600), "bytes": OUT_2600.stat().st_size,
                    "canvas": png_map["canvas"], "rhythm": {k: PNG_CFG[k] for k in ("margin", "sec_gap", "band_pad", "card_gap")}},
        "png2400": {"path": str(OUT_2400), "bytes": OUT_2400.stat().st_size,
                    "canvas": compact_map["canvas"]},
    }, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
