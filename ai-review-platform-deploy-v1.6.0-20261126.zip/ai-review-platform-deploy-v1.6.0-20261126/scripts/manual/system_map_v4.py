# -*- coding: utf-8 -*-
"""全局功能流程架构 v4：宽幅横图，一行 9 个标签，逐行向下。"""
from PIL import Image, ImageDraw, ImageFont

def F(s, b=False):
    p = "/System/Library/Fonts/STHeiti Medium.ttc" if b else "/System/Library/Fonts/Hiragino Sans GB.ttc"
    try: return ImageFont.truetype(p, s)
    except Exception: return ImageFont.truetype("/System/Library/Fonts/Supplemental/Songti.ttc", s)

STAGES = [
 ("① 规则沉淀", "#3370FF", ["规则来源：上传文档","规则来源：一段话","规则来源：手工填写","文本清洗与分段","规则提炼（LLM 四元组）","实体识别：指标名","实体识别：单位","本体门槛：别名归一","本体门槛：未识别提示","冲突检测：区间无交集","冲突检测：同向冗余","规则草稿入库","规则提交审批","规则发布生效","决策表：条件组合","决策表：结论与严重度","参数：阈值","参数：开关","参数：灰度范围","接线矩阵：点位↔本体","接线矩阵：点位↔Jev","接线矩阵：点位↔反馈"]),
 ("② 解析", "#00B96B", ["文件上传","格式识别","体积与份数校验","xlsx 工作表遍历","docx 段落与表格","pdf 页文本抽取","md 行解析","合并单元格还原","表头识别","扫描件检测","OCR 识别","解析报告：状态","解析报告：缺口原因","解析报告：原始文件名","事实抽取：数值","事实抽取：单位换算","事实抽取：范围","事实抽取：日期","结构化抽取：百分比基数","结构化抽取：分段费率","结构化抽取：时序余额","结构化抽取：勾选项","Anchor：Sheet+Cell","Anchor：第N段","Anchor：第N页"]),
 ("③ 路由", "#FF8800", ["文档类型识别（104）","审核类型识别（74）","A~G 大类过滤","点位路由（319）","场景包匹配","意图识别 focus","点位裁剪","执行计划：确定性","执行计划：语义","执行计划：证据要求"]),
 ("④ 判定", "#7F3BF5", ["读取行为参数","参数：启用状态","参数：忽略词","参数：严重度映射","确定性执行器判定","断言：range","断言：equality","断言：sum_consistency","断言：presence","断言：ordering","断言：contiguity","断言：set_membership","模型判定入口","智能体版本读取","智能体提示词","模型路由解析","LLM 调用","多采样投票","判定缓存","Jev 置信度","Jev 弃权判定","证据校验：引文回查","五态：pass","五态：fail","五态：na","五态：insufficient","五态：unknown"]),
 ("⑤ 结论", "#F54A45", ["点位结论落库","同标题合并","引擎优先去重","严重度聚合","待复核统计","覆盖率统计","批次号写入","报告门禁判断","HTML 报告","DOCX 报告","PDF 报告","证据定位展示"]),
 ("⑥ 人工反馈", "#0FA6A6", ["定位复核：原文高亮","确认问题","标记误报","补充证据","手动新增发现","反馈归一（五类）","写 decision 表","Jev 样本累积","健康度：命中","健康度：override","抽样复核"]),
 ("⑦ 进化", "#7F3BF5", ["归因：模型原因","归因：兜底原因","反向反馈计数","≥3 次触发","候选快照 before","候选快照 after","参数调整","行为调整","新规则沉淀","草稿→发布","回滚到 before","冻结改进器","规则回放","影响面评估","冲突复检","本体修订候选","I-gain 度量"]),
]

PER, BW, BH, GX, GY = 9, 330, 76, 30, 34
ML, MT, LABEL = 250, 210, 210
W = ML + LABEL + PER * BW + (PER - 1) * GX + 60

rows = []           # (stage_idx, [items])
for si, (name, color, items) in enumerate(STAGES):
    for i in range(0, len(items), PER):
        rows.append((si, items[i:i + PER]))

H = MT + len(rows) * (BH + GY) + 120
img = Image.new("RGB", (W, H), "#FFFFFF"); d = ImageDraw.Draw(img)
d.text((60, 44), "AI 审核平台 · 全局功能流程架构（宽幅横图 / 一行 9 项 / 一项一框）", font=F(44, True), fill="#1F2329")
d.text((60, 104), "七段按序向下推进：规则沉淀 → 解析 → 路由 → 判定 → 结论 → 人工反馈 → 进化", font=F(22), fill="#646A73")

pos = {}
for ri, (si, items) in enumerate(rows):
    name, color, _ = STAGES[si]
    y = MT + ri * (BH + GY)
    d.rounded_rectangle([60, y, 60 + LABEL, y + BH], radius=8, fill=color)
    shown = name if ri == next(k for k, r in enumerate(rows) if r[0] == si) else "（续）"
    f2 = F(22, True) if shown != "（续）" else F(18)
    tw = d.textlength(shown, font=f2)
    d.text((60 + (LABEL - tw) / 2, y + BH / 2 - 14), shown, font=f2, fill="#FFFFFF")
    for ci, it in enumerate(items):
        x = ML + LABEL + ci * (BW + GX)
        d.rounded_rectangle([x, y, x + BW, y + BH], radius=8, outline=color, width=3, fill="#FFFFFF")
        f3 = F(18); txt = it
        while d.textlength(txt, font=f3) > BW - 20 and len(txt) > 4:
            txt = txt[:-2]
        tw2 = d.textlength(txt, font=f3)
        d.text((x + (BW - tw2) / 2, y + BH / 2 - 11), txt, font=f3, fill="#1F2329")
        pos[(ri, ci)] = (x, y)
        if ci < len(items) - 1:
            d.line([(x + BW, y + BH // 2), (x + BW + GX - 4, y + BH // 2)], fill=color, width=3)
            d.polygon([(x + BW + GX - 2, y + BH // 2), (x + BW + GX - 12, y + BH // 2 - 6), (x + BW + GX - 12, y + BH // 2 + 6)], fill=color)

for ri in range(len(rows) - 1):
    x = pos[(ri, 0)][0] + BW // 2
    y1 = pos[(ri, 0)][1] + BH
    y2 = pos[(ri + 1, 0)][1] - 2
    d.line([(x, y1), (x, y2)], fill="#3370FF", width=4)
    d.polygon([(x, y2), (x - 7, y2 - 10), (x + 7, y2 - 10)], fill="#3370FF")

d.text((60, H - 70), "蓝线=相邻行的顺序连接（只在行间空白处）；彩色左边条=所属阶段；框内为单一功能项。", font=F(20), fill="#8F959E")
img.save("docs/系统全局功能流程架构_v4.png")
print("saved", img.size, "rows", len(rows), "items", sum(len(s[2]) for s in STAGES))
