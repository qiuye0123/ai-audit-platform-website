# -*- coding: utf-8 -*-
"""用 AIClub gpt-5.2 独立评审技术路径文档（可脚本化，替代 Trae GUI 交互）。

为什么不用 Trae：Trae CN 的 CLI 只提供 `chat`（GUI agent 会话，结果落窗口不可靠捕获），
无法稳定拿到结构化评审输出；AIClub 直连 gpt-5.2 走同一平台、同一模型，可复跑、可留档。

用法：
  python3 scripts/ai/review_doc_with_gpt52.py --files docs/交付/技术路径文档/01-*.md
  python3 scripts/ai/review_doc_with_gpt52.py --all --out /tmp/doc_review
铁律 6：本脚本只读文档、只调外部模型，不 import app、不写产品库。
"""
import argparse, json, os, re, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = "https://aiclub.zimaocloud.com/model/openApi/v1"
MODEL = "gpt-5.2"
CRED = Path.home() / ".dsh/.credentials.yaml"

SYSTEM = """你是资深架构评审专家（20 年经验，做过大型企业级审核系统与合规系统）。
你的任务：审查一份「AI 审核平台」的技术路径文档，指出**具体、可执行**的问题与改进建议。

评审维度（每个维度都要给结论）：
1 完整性：主链每个阶段是否都有 入口/输入/处理/输出/状态/失败语义？有没有明显缺失环节？
2 准确性：描述与真实系统行为是否可能不符？（注意：你无法看代码，请标出"需核对代码"的可疑断言）
3 可执行性：一个新工程师照这份文档能否跑通/改对一个功能？哪些地方仍含糊？
4 结构化：层级、术语一致性、交叉引用、图表是否到位？
5 契约性：五态/证据锚点/冻结/状态机等契约是否定义到"可测试"的程度？
6 风险与盲点：文档没覆盖但生产必须有的内容（并发/幂等/降级/权限边界/数据一致性）。

输出格式（严格）：
## 总体评分
X/10 + 一句话理由
## 必须修的问题（P0，按影响排序，最多 10 条）
每条：位置（章节/原文片段）→ 问题 → 具体怎么改
## 建议改进（P1，最多 15 条）
每条：位置 → 建议 → 收益
## 可选优化（P2，最多 10 条）
## 需核对代码的可疑断言（列出原文片段 + 为什么可疑）
## 文档缺什么（生产必须但文档没有）
不要泛泛而谈，不要复述文档内容，只给判断与建议。"""


def load_key() -> str:
    if not CRED.is_file():
        raise SystemExit("找不到凭据文件")
    inrefs = False
    for line in CRED.read_text(encoding="utf-8").splitlines():
        if line.strip() == "refs:":
            inrefs = True
            continue
        if inrefs:
            m = re.match(r"^\s{2}([A-Za-z0-9_]+):\s*(\S+)\s*$", line)
            if m and m.group(1) == "AICLUB_API_KEY":
                return m.group(2)
            if line and not line.startswith(" "):
                break
    raise SystemExit("凭据里没有 AICLUB_API_KEY")


def call_gpt52(key: str, prompt: str, *, timeout: int = 600) -> str:
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": SYSTEM},
                     {"role": "user", "content": prompt}],
        "max_tokens": 16000,
        "temperature": 0.2,
    }
    cmd = ["curl", "-s", "--max-time", str(timeout), "--noproxy", "*",
           "-H", f"Authorization: Bearer {key}",
           "-H", "Content-Type: application/json",
           "-X", "POST", BASE + "/chat/completions",
           "-d", json.dumps(payload)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    try:
        j = json.loads(r.stdout)
    except Exception:
        return f"[调用失败] {r.stdout[:400]}"
    ch = j.get("choices") or []
    if not ch:
        return f"[无返回] {json.dumps(j, ensure_ascii=False)[:400]}"
    msg = ch[0].get("message") or {}
    return msg.get("content") or "[空内容]"


def chunk_text(text: str, limit: int = 60000) -> list:
    if len(text) <= limit:
        return [text]
    parts, cur = [], ""
    for para in text.split("\n\n"):
        if len(cur) + len(para) > limit and cur:
            parts.append(cur)
            cur = ""
        cur += para + "\n\n"
    if cur.strip():
        parts.append(cur)
    return parts


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--files", nargs="*", default=[])
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--out", default="/tmp/doc_review")
    a = ap.parse_args()
    files = [Path(f) for f in a.files]
    if a.all or not files:
        d = ROOT / "docs/交付/技术路径文档"
        files = sorted(d.glob("*.md"))
    if not files:
        raise SystemExit("没有找到待评审文档")
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    key = load_key()
    summary = []
    for f in files:
        if not f.is_file():
            continue
        text = f.read_text(encoding="utf-8")
        chunks = chunk_text(text)
        reviews = []
        for i, ch in enumerate(chunks, 1):
            head = (f"文档：{f.name}（第 {i}/{len(chunks)} 段，共 {len(text)} 字符）\n"
                    f"请按系统提示的评审维度与输出格式给出评审。\n\n=== 文档内容 ===\n")
            t0 = time.time()
            rv = call_gpt52(key, head + ch)
            reviews.append({"chunk": i, "seconds": round(time.time() - t0, 1), "review": rv})
            print(f"  {f.name} 段{i}/{len(chunks)} 完成 {reviews[-1]['seconds']}s", flush=True)
        md = [f"# gpt-5.2 独立评审：{f.name}", "",
              f"> 模型 aiclub/{MODEL}｜文档 {len(text)} 字符 / {len(chunks)} 段｜"
              f"生成 {time.strftime('%Y-%m-%d %H:%M:%S')}", ""]
        for x in reviews:
            md.append(f"## 第 {x['chunk']} 段评审（{x['seconds']}s）")
            md.append(x["review"])
            md.append("")
        outp = out / (f.stem + ".gpt52-review.md")
        outp.write_text("\n".join(md), encoding="utf-8")
        summary.append({"file": f.name, "chars": len(text), "chunks": len(chunks),
                        "review": str(outp), "seconds": sum(x["seconds"] for x in reviews)})
    (out / "review_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\n结果：", out)
    for s in summary:
        print(f"  {s['file']}: {s['chars']} 字 / {s['chunks']} 段 / {s['seconds']}s → {s['review']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
