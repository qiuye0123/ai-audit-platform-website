#!/bin/bash
# 驱动本机 DuMate 内置 AI（opencode 内核）跑非交互任务 —— 2026-11-19 能力验证通过
#
# 原理：DuMate.app 自带 dumate-opencode（opencode fork），支持 `opencode run`
# 非交互模式；用独立的 XDG 配置/数据目录 + 复制出来的 provider 凭证即可跑，
# 不碰 DuMate 正在运行的实例（它自己的 server 用 inappkey 鉴权，本脚本不碰）。
#
# 用法：
#   scripts/ai/drive_local_ai.sh <workdir> <prompt> [附加文件...]
#   scripts/ai/drive_local_ai.sh <workdir> - [附加文件...]   ← prompt 从 stdin 读
#   MODEL=QianfanPersonalQuota/deepseek-v41-flash scripts/ai/drive_local_ai.sh ...
#
# 权限说明（重要）：
#   opencode 的 permission=allow 在 DuMate 的 inapp 层**不完全生效**：
#   写文件/部分工具调用仍可能被 "user_rejected" 拒绝。
#   已验证可靠的两种模式：
#     ① 只要结果 → 让 AI 把结果**打印在回复里**（stdout 可捕获），自己落盘
#     ② 允许写 → 大部分 write 能成功；失败则改用模式 ①
#   因此调用方必须把 RejectedError 当作"部分成功"处理，检查产物后再决定是否重试。
#
# 环境要求：DuMate.app 已安装且至少登录过一次（凭证在 Application Support）。
set -o pipefail

OC="/Applications/DuMate.app/Contents/Resources/extra-resource/opencode/bin/dumate-opencode"
[ -x "$OC" ] || { echo "找不到 dumate-opencode: $OC" >&2; exit 2; }

WD="$1"; shift
PROMPT="$1"; shift

# 隔离的运行目录（首次会自动复制 DuMate 配置与凭证）
BASE="${AI_DRIVE_BASE:-/tmp/ai_drive_base}"
if [ ! -d "$BASE/cfg/opencode" ]; then
  mkdir -p "$BASE/cfg" "$BASE/data/opencode"
  # 找当前活跃 profile（多个 qianfan_desk_xdg/* 时取最近修改）
  SRC=$(ls -dt "/Users/$USER/Library/Application Support/qianfan-desktop-app/qianfan_desk_xdg"/*/ 2>/dev/null | head -1)
  [ -n "$SRC" ] && cp -R "$SRC/config/opencode" "$BASE/cfg/" 2>/dev/null
  cp "/Users/$USER/Library/Application Support/qianfan-desktop-app/auth.json" "$BASE/data/opencode/auth.json" 2>/dev/null
  # 放开权限（只影响隔离副本）
  python3 - "$BASE/cfg/opencode/opencode.json" <<'PY'
import json,sys
p=sys.argv[1]
try: d=json.load(open(p))
except Exception: d={}
d.setdefault("permission",{})
for k in ("edit","bash","webfetch","read","write"): d["permission"][k]="allow"
json.dump(d, open(p,"w"), ensure_ascii=False, indent=2)
PY
fi

export DUMATE_EDITION=dumate DUMATE_APPDATA_DIRNAME=qianfan-desktop-app \
       DUMATE_HOME_DIRNAME=.qianfan DUMATE_NAMED_WORKSPACE_ROOT=DuMate \
       XDG_CONFIG_HOME="$BASE/cfg" XDG_DATA_HOME="$BASE/data"
unset OPENCODE_CONFIG OPENCODE_CONFIG_CONTENT 2>/dev/null

mkdir -p "$WD"
if [ "$PROMPT" = "-" ]; then PROMPT=$(cat); fi
ARGS=()
for f in "$@"; do ARGS+=(-f "$f"); done
MODEL_ARG=()
[ -n "$MODEL" ] && MODEL_ARG=(--model "$MODEL")

cd "$WD" || exit 1
"$OC" run --dir "$WD" ${MODEL_ARG[@]+"${MODEL_ARG[@]}"} "$PROMPT" ${ARGS[@]+"${ARGS[@]}"}
rc=$?
if [ $rc -ne 0 ]; then
  echo "[drive_local_ai] 退出码 $rc（若含 user_rejected，检查产物后改用「打印在回复里」模式重试）" >&2
fi
exit $rc
