#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""外部 AI 生成「工艺书评测数据集 v2」：提示词 A（干净稿）→ B（注入+gold）→ D（自检）。

思路（务实、可交付）：
    · 内容由外部 AI（本机 DuMate 内嵌 dumate-opencode headless，模型 QianfanPersonalQuota/qwen4-max）
      按 `docs/qa/工艺书数据生成提示词_20261119.md` 的提示词 A / B / D 生成；
    · **AI 只负责内容与注入改动**；gold 的「逐字/回改一致性」由本脚本机械校验并校正：
      以 base 干净稿为基线做逐行 diff，evidence_text / clean_text / location 全部从**实际改动行**
      重新取，保证 evidence_text 是注入稿原文逐字子串、clean_text 是 base 同一定位原文；
    · 计划外的多余改动整行还原（恢复 base 原文），计划未落地则重试；二次机械注入（mechanical
      fallback）仅在某份 AI 注入连续失败时启用，并在 meta.json 如实记录；
    · 其中 3 份注入稿（每行业 1 份）用 `tools/md_to_xlsx.py` 转 xlsx，gold 证据口径迁移为
      xlsx 单元格，供平台表格解析测试；对应 3 份 L1 也转 xlsx 以支撑回改一致性校验。

诚实边界（与数据一起引用，不许省略）：
    · 全部是**构造数据**（AI 生成 + 机械注入），不含任何企业真实工艺书；
    · 只回答「平台链路能否定位并判出已知构造缺陷」，不能回答「真实客户工艺书准确率」；
    · 未覆盖 L3（真实噪声）/L4（对抗）；
    · 驱动 CLI 不暴露 temperature，本轮温度不可设 0（以固定 model + 任务的低随机性约束代替），
      见 meta.json:limitations。

用法（每 phase 可单独重跑；产物落 /tmp/psv2，最后 --phase assemble 才写 dataset 目录）：
    PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
    $PY scripts/ai/gen_process_sheet_v2.py --phase l1        # 6 份干净稿
    $PY scripts/ai/gen_process_sheet_v2.py --phase l2        # 12 份注入稿 + gold
    $PY scripts/ai/gen_process_sheet_v2.py --phase assemble  # 组装 dataset + xlsx + SHA
    $PY scripts/ai/gen_process_sheet_v2.py --phase d         # 提示词 D 自检（12 次调用）
    $PY scripts/ai/gen_process_sheet_v2.py --phase v       # 调用平台验收脚本

铁律 6：本脚本不 import app、不连任何数据库；首条可执行语句仍断言 RULEPROOF_DB 在 /tmp。
"""
from __future__ import annotations

# —— 铁律 6：第一条可执行语句断言临时库（不 import app，也不连库）——
import os
import sys

_DB = str(os.environ.get("RULEPROOF_DB") or "").strip()
if not _DB:
    os.makedirs("/tmp/psv2", exist_ok=True)
    _DB = "/tmp/psv2/gen_process_sheet_v2_%d.sqlite" % os.getpid()
    os.environ["RULEPROOF_DB"] = _DB
_TMP_PREFIXES = ("/tmp/", "/private/tmp/", "/var/folders/", "/private/var/folders/")
if not _DB.startswith(_TMP_PREFIXES):
    sys.stderr.write("[FATAL] RULEPROOF_DB 必须指向 /tmp 下临时库（铁律 6），当前=%r；拒绝运行\n" % _DB)
    raise SystemExit(2)

import argparse  # noqa: E402
import hashlib  # noqa: E402
import json  # noqa: E402
import re  # noqa: E402
import shutil  # noqa: E402
import subprocess  # noqa: E402
import time  # noqa: E402
from concurrent.futures import ThreadPoolExecutor, as_completed  # noqa: E402
from datetime import datetime  # noqa: E402
from pathlib import Path  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]                       # platform/
DRIVER = ROOT / "scripts" / "ai" / "drive_local_ai.sh"
PROMPT_SRC = ROOT / "docs" / "qa" / "工艺书数据生成提示词_20261119.md"
MDX = ROOT / "tools" / "md_to_xlsx.py"
OUT = ROOT / "tests" / "fixtures" / "process_sheet_v2"
WORK = Path(os.environ.get("PSV2_WORK", "/tmp/psv2"))
LOGS, PROMPTS, L1DIR, L2DIR, XI = (WORK / d for d in ("logs", "prompts", "l1", "l2", "xlsx"))
STATE_PATH = WORK / "state.json"
MODEL = os.environ.get("PSV2_MODEL", "QianfanPersonalQuota/qwen4-max")
NB = 4                                    # 并行实例数（每个独立 AI_DRIVE_BASE）
CREATED = "2026-11-23"
BENCH_ID = "process_sheet_dataset_v2"
BENCH_VER = "2.0.0"

SPECS = [
    {"idx": 1, "industry": "烘焙", "product": "麦香法式欧包",
     "route": "原料前处理→搅拌→发酵→烘烤→冷却→包装"},
    {"idx": 2, "industry": "烘焙", "product": "经典白吐司",
     "route": "原料前处理→搅拌→发酵→整形→烘烤→冷却→包装"},
    {"idx": 3, "industry": "肉制品", "product": "五香卤牛腱",
     "route": "原料解冻→清洗→卤制→冷却→包装→冷藏"},
    {"idx": 4, "industry": "肉制品", "product": "黑椒牛肉粒",
     "route": "原料解冻→腌制→炒制→冷却→包装→冷藏"},
    {"idx": 5, "industry": "调味品", "product": "古法酿造酱油",
     "route": "原料前处理→制曲→发酵→淋油→灭菌→灌装"},
    {"idx": 6, "industry": "调味品", "product": "香辣牛肉酱",
     "route": "原料前处理→炒制→灌装→灭菌→冷却→包装"},
]

SIGN_ROLES = ["研发经理", "生产经理", "品管经理", "研发"]
SHEET_RE = re.compile(r"^##\s*Sheet[:：]\s*(.+?)\s*$")
BULLET_RE = re.compile(r"^-\s*([^：:]+?)\s*[：:]\s*(.+?)\s*$", re.M)
FUZZY = ["大约", "左右", "若干", "酌情", "视情况"]
PLACEHOLDER = {"", "X", "x", "待定", "TODO", "无", "-", "—"}

POINT_NAME = {
    "FOOD01-001": "炒制/烹制中心温度达标",
    "FOOD01-002": "消毒浓度与时间达标",
    "FOOD01-003": "冷却终温达标",
    "FOOD01-004": "冷藏暂存温度达标",
    "FOOD01-005": "解冻条件标注",
    "FOOD01-006": "重量与单位统一",
    "FOOD03-001": "实施日期跨 Sheet 一致",
    "FOOD03-002": "产品名称全称/简称一致",
    "FOOD03-003": "工单号/版本号一致",
    "FOOD04-001": "版本号非占位符",
    "FOOD04-002": "人员签名非占位符",
    "FOOD02-002": "肉类前处理完整性",
    "FOOD05-002": "序号连续",
}
DEFECT_OF = {
    "FOOD01-001": ("数值越界", "高"), "FOOD01-002": ("数值越界", "高"),
    "FOOD01-003": ("数值越界", "中"), "FOOD01-004": ("数值越界", "高"),
    "FOOD01-005": ("字段缺失", "中"), "FOOD01-006": ("单位", "中"),
    "FOOD03-001": ("日期·时序", "高"), "FOOD03-002": ("前后矛盾", "中"),
    "FOOD03-003": ("前后矛盾", "中"), "FOOD04-001": ("字段缺失", "中"),
    "FOOD04-002": ("字段缺失", "中"),
}


# ---------------------------------------------------------------- 基础工具

def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_state() -> dict:
    if STATE_PATH.is_file():
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    return {"calls": [], "l1": {}, "l2": {}, "d": {}, "created": now()}


def save_state(st: dict) -> None:
    st["updated"] = now()
    STATE_PATH.write_text(json.dumps(st, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def extract_block(text: str, start: str, end: str):
    m = re.search(re.escape(start) + r"\s*(.*?)\s*" + re.escape(end), text, re.S)
    return m.group(1) if m else None


def strip_fences(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"^```(?:markdown|md|json)?\s*\n", "", s)
    s = re.sub(r"\n```\s*$", "", s)
    return s.strip() + "\n"


def extract_doc(text: str) -> str:
    b = extract_block(text, "<<<DOC>>>", "<<<END>>>")
    if b:
        return strip_fences(b)
    # 兜底：从第一个一级标题开始
    i = text.find("\n# ")
    if i >= 0:
        return strip_fences(text[i:])
    return ""


def extract_gold(text: str):
    b = extract_block(text, "<<<GOLD>>>", "<<<GOLD_END>>>")
    if not b:
        b = extract_block(text, "```json", "```")
    if not b:
        return None
    b = b.strip()
    for cand in re.findall(r"\{.*\}", b, re.S):
        try:
            j = json.loads(cand)
            if isinstance(j, dict) and isinstance(j.get("entries"), list):
                return j
        except Exception:
            continue
    return None


# ---------------------------------------------------------------- 提示词

def load_prompts() -> dict:
    src = PROMPT_SRC.read_text(encoding="utf-8")
    mt = re.search(r"### 平台点位判据表.*?\n\n(.*?)\n\n---", src, re.S)
    if not mt:
        raise SystemExit("[FATAL] 提示词文件里找不到「平台点位判据表」")
    table = mt.group(1).strip()
    out = {"POINT_TABLE": table}
    for name in ("A", "B", "D"):
        m = re.search(r"<<<PROMPT %s 开始>>>(.*?)<<<PROMPT %s 结束>>>" % (name, name), src, re.S)
        if not m:
            raise SystemExit("[FATAL] 提示词 %s 缺失" % name)
        txt = m.group(1).strip()
        if name == "B":
            txt = txt.replace("【平台点位判据表】", "【平台点位判据表】\n" + table)
        if name == "D":
            txt = txt.replace("（复制本文件顶部「平台点位判据表」的全部 17 行）", table)
        out[name] = txt
    # 落盘留档（审计：本轮实际使用的提示词全文）
    PROMPTS.mkdir(parents=True, exist_ok=True)
    for k, v in out.items():
        (PROMPTS / f"{k}.md").write_text(v + "\n", encoding="utf-8")
    out["sha256"] = {k: hashlib.sha256((v + "\n").encode("utf-8")).hexdigest() for k, v in out.items()}
    return out


L1_OUTPUT_CONTRACT = """【输出要求（覆盖上面【输出格式】里的块1/块3，必须遵守）】
1) 不要写文件、不要运行命令；只把内容输出在回复里。
2) 只输出【块2 Markdown 正文】，完整正文放在 <<<DOC>>> 与 <<<END>>> 两行标记之间；两块标记之外不要输出任何解释。
3) 正文结构：一级标题；每个工序一个 "## Sheet: 工序名"；每个工序页必须逐字包含表头四要素字段名：实施日期 / 版本号 / 商品名 / 签署；每个工序页必须有"标准工序"五列表，列固定为：工序 | 作业内容 | 作业条件 | 作业要点 | 器具。
4) 全部工序页的 实施日期、版本号、商品名 必须完全一致；签署写真实感中文姓名（研发经理/生产经理/品管经理/研发），不得用 X 或空。
5) 参数必须明确"数值+单位"，禁止"大约/左右/若干/酌情/视情况"；中心温度≥85℃（烘焙取 90-95℃）、消毒液浓度 200-300ppm 且浸泡 10-15min、冷却终温≤10℃、冷藏暂存 0-8℃、解冻时长 20-48h、重量单位统一用 g。
6) 不要生成"半成品名称"清单；不要编造国标条款号；不要出现同文件前后矛盾。
7) 末尾加 "## Sheet: 包装指示书"：含实施日期 / 版本号 / 商品名 / 设计总重量（g）/ 包材清单（序号连续，形如 "1 牛皮纸袋 / 2 自封袋"）/ 修订记录。
8) 至少 4 个工序页（含包装指示书共 5 个 Sheet 以上），正文 2000 字以上。
只输出 <<<DOC>>> 到 <<<END>>> 之间的 Markdown 正文。"""


def prompt_l1(pr: dict, spec: dict) -> str:
    a = pr["A"]
    a = re.sub(r"\{烘焙 / 肉制品 / 调味品\}", spec["industry"], a)
    a = re.sub(r"\{产品名[^}]*\}", spec["product"], a)
    a = re.sub(r"\{用 → 连接的工序[^}]*\}", spec["route"], a)
    head = ("严格按附件提示词 A 生成 1 份【干净、无缺陷】食品工艺书，供 AI 审核平台的 "
            "干净底稿（clean-control）测试使用。\n\n")
    return head + a + "\n\n" + L1_OUTPUT_CONTRACT


def plan_prompt_lines(plan: dict) -> str:
    lines = ["本次注入 N=%d 个缺陷，必须严格按下表逐条执行（每条只改一处连续原文，其余字符一律不变）："
             % len(plan["defects"])]
    for i, d in enumerate(plan["defects"], 1):
        lines.append(
            "%d) 缺陷%d｜%s｜point_code=%s｜把【%s】工序页中的原文 `%s` 替换为 `%s`。"
            % (i, i, d["defect_type"], d["point_code"], d["sheet"], d["clean_frag"], d["inj_frag"]))
    lines += [
        "",
        "【注入硬约束】",
        "- 注入稿的行数、Sheet 顺序、表格列数必须与干净稿完全相同；不得新增或删除行。",
        "- 除上述 %d 处外，注入稿其余内容必须逐字符不变。" % len(plan["defects"]),
        "- 注入后的值必须看起来真实（如 92℃→78℃、250ppm→150ppm、2026-11-01→2026-09-15）。",
        "",
        "【输出格式（必须遵守）】",
        "【块1 注入稿】完整 Markdown 全文放在 <<<DOC>>> 与 <<<END>>> 之间（不要只给 diff，不要加说明文字）。",
        "【块2 gold JSON】顶层对象（含 entries 数组，共 %d 条）放在 <<<GOLD>>> 与 <<<GOLD_END>>> 之间；"
        "evidence_text/clean_text 直接从原文复制。" % len(plan["defects"]),
        "【块3 逐字自检表】放在 <<<CHECK>>> 与 <<<CHECK_END>>> 之间（提示词 B 的块3 表格）。",
        "不要写文件、不要执行命令；标记之外不要输出额外解释。",
    ]
    return "\n".join(lines)


def prompt_l2(pr: dict, base_doc: str, plan: dict) -> str:
    b = pr["B"].replace("{粘贴提示词 A 的块2 Markdown 正文}", base_doc.strip())
    b = b.replace("{2-4}", str(len(plan["defects"])))
    return b + "\n\n" + plan_prompt_lines(plan)


def prompt_d(pr: dict, doc: str, entries: list) -> str:
    strict = ("【硬约束·必须先读】禁止写文件、禁止执行命令、禁止调用任何工具（含 bash/write/read）；"
              "不要申请外部目录权限。只依据下面给出的文档全文与 gold JSON 做纯文本比对，"
              "直接在回复里输出 JSON。\n\n")
    d = pr["D"].replace("{粘贴注入稿全文}", doc.strip())
    d = d.replace("{粘贴 gold JSON}", json.dumps({"entries": entries}, ensure_ascii=False, indent=1))
    return strict + d + ("\n\n【本轮输出契约】只输出最终 JSON，放在 <<<DJSON>>> 与 <<<DJSON_END>>> 之间；"
                         "标记之外不要输出其他文字；不要写文件、不要执行命令。")


# ---------------------------------------------------------------- AI 调用

def run_ai(tag: str, prompt: str, base: int, timeout: int = 660):
    t0 = time.time()
    env = os.environ.copy()
    env["AI_DRIVE_BASE"] = "/tmp/ai_drive_pv2_b%d" % base
    env["MODEL"] = MODEL
    LOGS.mkdir(parents=True, exist_ok=True)
    wd = WORK / "work" / tag
    wd.mkdir(parents=True, exist_ok=True)
    cmd = [str(DRIVER), str(wd), "-"]
    rc, out = -1, ""
    try:
        r = subprocess.run(cmd, input=prompt.encode("utf-8"), capture_output=True,
                           timeout=timeout, env=env)
        out = ((r.stdout or b"").decode("utf-8", "ignore") + "\n" +
               (r.stderr or b"").decode("utf-8", "ignore"))
        rc = r.returncode
    except subprocess.TimeoutExpired as e:
        out = ((e.stdout or b"").decode("utf-8", "ignore") if isinstance(e.stdout, bytes)
               else (e.stdout or ""))
        out += "\n[TIMEOUT %ss]" % timeout
        rc = -9
    secs = round(time.time() - t0, 1)
    logp = LOGS / ("%s.log" % tag)
    logp.write_text(out, encoding="utf-8", errors="ignore")
    rec = {"tag": tag, "base": base, "model": MODEL, "seconds": secs, "rc": rc,
           "out_chars": len(out), "log": str(logp), "ts": now(),
           "had_doc": "<<<DOC>>>" in out, "had_gold": "<<<GOLD>>>" in out}
    return rec, out


def run_jobs(prepared: list, max_workers: int = NB) -> dict:
    """prepared: [(tag, prompt)]；按 max_workers 分块，块内每个实例用不同 AI_DRIVE_BASE。"""
    st = load_state()
    results = {}
    for ci in range(0, len(prepared), max_workers):
        chunk = prepared[ci:ci + max_workers]
        with ThreadPoolExecutor(max_workers=len(chunk)) as ex:
            futs = {}
            for k, (tag, prompt) in enumerate(chunk):
                futs[ex.submit(run_ai, tag, prompt, k + 1)] = tag
            for f in as_completed(futs):
                rec, out = f.result()
                st["calls"].append(rec)
                results[futs[f]] = (rec, out)
                print("  [ai] %-24s base=b%d rc=%s %5.1fs out=%d chars doc=%s"
                      % (rec["tag"], rec["base"], rec["rc"], rec["seconds"],
                         rec["out_chars"], rec["had_doc"]), flush=True)
        save_state(st)
    return results


# ---------------------------------------------------------------- L1 结构/参数自检

def split_sheets(doc: str) -> list:
    """→ [{name, text, start_line}]（1-based start_line 为 Sheet 标题行）。"""
    lines = doc.splitlines()
    out = []
    cur = None
    for i, line in enumerate(lines, 1):
        m = SHEET_RE.match(line.strip())
        if m:
            cur = {"name": m.group(1).strip(), "start_line": i, "lines": []}
            out.append(cur)
            continue
        if cur is not None:
            cur["lines"].append(line)
    for s in out:
        s["text"] = "\n".join(s["lines"])
    return out


def sheet_of_line(doc: str) -> dict:
    lines = doc.splitlines()
    cur = None
    out = {}
    for i, line in enumerate(lines):
        m = SHEET_RE.match(line.strip())
        if m:
            cur = m.group(1).strip()
        out[i] = cur
    return out


def l1_check(doc: str) -> tuple:
    """返回 (fails, warns)。干净稿必须 fails 为空才可用。"""
    fails, warns = [], []
    if not doc or len(doc) < 800:
        return ["正文过短或为空（%d 字符）" % len(doc)], warns
    sheets = split_sheets(doc)
    names = [s["name"] for s in sheets]
    if len(sheets) < 4:
        fails.append("Sheet 数过少：%d" % len(sheets))
    proc = [s for s in sheets if "包装指示书" not in s["name"]]
    pkg = [s for s in sheets if "包装指示书" in s["name"]]
    if not pkg:
        fails.append("缺少「包装指示书」Sheet")
    dates, vers, prods = set(), set(), set()
    for s in proc:
        b = dict(BULLET_RE.findall(s["text"]))
        for key in ("实施日期", "版本号", "商品名", "签署"):
            if key not in b:
                fails.append("【%s】缺少表头要素：%s" % (s["name"], key))
        if b.get("实施日期"):
            dates.add(b["实施日期"])
        if b.get("版本号"):
            vers.add(b["版本号"])
        if b.get("商品名"):
            prods.add(b["商品名"])
        if b.get("版本号", "") in PLACEHOLDER:
            fails.append("【%s】版本号占位符：%r" % (s["name"], b.get("版本号")))
        sign = b.get("签署", "")
        for role in SIGN_ROLES:
            mm = re.search(re.escape(role) + r"\s*([^\s/]*)", sign or "")
            if not mm or not mm.group(1) or mm.group(1) in PLACEHOLDER:
                fails.append("【%s】签署缺失/占位：%s → %r" % (s["name"], role, sign[:40]))
        head_row = re.search(r"^\|\s*工序\s*\|\s*作业内容\s*\|\s*作业条件\s*\|\s*作业要点\s*\|\s*器具\s*\|",
                             s["text"], re.M)
        if not head_row:
            fails.append("【%s】缺标准工序五列表头" % s["name"])
        rows = [ln for ln in s["lines"] if ln.strip().startswith("|")]
        data_rows = [ln for ln in rows
                     if not re.match(r"^\|[\s:\-|]+\|$", ln.strip())
                     and "作业内容" not in ln]
        if len(data_rows) < 2:
            warns.append("【%s】标准工序数据行少于 2 行" % s["name"])
    if len(dates) > 1:
        fails.append("实施日期跨 Sheet 不一致：%r" % sorted(dates))
    if len(vers) > 1:
        fails.append("版本号跨 Sheet 不一致：%r" % sorted(vers))
    if len(prods) > 1:
        fails.append("商品名跨 Sheet 不一致：%r" % sorted(prods))
    if pkg:
        ptext = pkg[0]["text"]
        for key in ("设计总重量", "包材清单", "修订记录"):
            if key not in ptext:
                fails.append("包装指示书缺少：%s" % key)
        if not re.search(r"设计总重量[：:]\s*\d+(?:\.\d+)?\s*g", ptext):
            warns.append("包装指示书设计总重量缺少 g 单位")
        mseq = re.search(r"包材清单[^\n]*[：:]\s*(.+)", ptext)
        if mseq:
            seq = re.findall(r"(?:^|/)\s*(\d+)\s+\S", mseq.group(1))
            if len(seq) >= 2 and [int(x) for x in seq] != list(range(1, len(seq) + 1)):
                warns.append("包材清单序号可能不连续：%r" % seq[:10])
    # 参数区间（与平台点位判据同口径：85℃/200ppm/10min/≤10℃/0-8℃/20-48h）
    for m in re.finditer(r"中心温度\s*[≥>]\s*(\d+(?:\.\d+)?)\s*℃", doc):
        if float(m.group(1)) < 85:
            fails.append("中心温度低于平台判据 85℃：%s" % m.group(0))
    for m in re.finditer(r"(\d{3})\s*ppm", doc):
        v = int(m.group(1))
        if v < 200:
            fails.append("消毒浓度低于平台判据 200ppm：%s" % m.group(0))
        elif v > 300:
            warns.append("消毒浓度高于提示词区间 300ppm：%s" % m.group(0))
    for m in re.finditer(r"浸泡时间\s*(\d+)\s*min", doc):
        if int(m.group(1)) < 10:
            fails.append("消毒浸泡时间低于 10min：%s" % m.group(0))
    for m in re.finditer(r"冷却[^\n]{0,20}?[≤<]\s*(\d+(?:\.\d+)?)\s*℃", doc):
        if float(m.group(1)) > 10:
            fails.append("冷却终温高于平台判据 10℃：%s" % m.group(0))
    for m in re.finditer(r"冷藏[^\n]{0,16}?(\d+)\s*[-~至]\s*(\d+)\s*℃", doc):
        if (int(m.group(1)), int(m.group(2))) != (0, 8):
            fails.append("冷藏暂存温度不是 0-8℃：%s" % m.group(0))
    for m in re.finditer(r"解冻[^\n]{0,30}?(\d+)\s*[-~至]\s*(\d+)\s*h", doc):
        lo, hi = int(m.group(1)), int(m.group(2))
        if not (20 <= lo and hi <= 48):
            warns.append("解冻时长不在 20-48h：%s" % m.group(0))
    if re.search(r"\d+\s*kg", doc) and re.search(r"\d+\s*g(?!\w)", doc):
        warns.append("同一文件混用 kg 与 g（提示词要求统一）")
    fz = [w for w in FUZZY if w in doc]
    if fz:
        fails.append("含模糊表述：%r" % fz)
    for ln in doc.splitlines():
        if "半成品" in ln and "：" in ln and "外购" not in ln and "附合格" not in ln:
            warns.append("疑似半成品名称清单：%s" % ln.strip()[:40])
            break
    return fails, warns


# ---------------------------------------------------------------- 锚点与注入计划

def find_anchors(doc: str) -> dict:
    a = {"temp": [], "ppm": [], "cooling": [], "cold": [], "weight": [], "thaw": [], "header": []}
    sh = sheet_of_line(doc)
    lines = doc.splitlines()
    for i, line in enumerate(lines):
        for m in re.finditer(r"中心温度\s*(≥|>)\s*(\d+(?:\.\d+)?)(\s*℃)", line):
            a["temp"].append({"line": i, "sheet": sh.get(i), "frag": m.group(0),
                              "pre": m.group(1), "num": m.group(2), "suf": m.group(3),
                              "value": float(m.group(2))})
        for m in re.finditer(r"(\d{3})\s*ppm", line):
            a["ppm"].append({"line": i, "sheet": sh.get(i), "frag": m.group(0),
                             "value": int(m.group(1))})
        for m in re.finditer(r"(冷却[^\n]{0,20}?[≤<]\s*)(\d+(?:\.\d+)?)(\s*℃)", line):
            a["cooling"].append({"line": i, "sheet": sh.get(i), "frag": m.group(0),
                                 "pre": m.group(1), "num": m.group(2), "suf": m.group(3),
                                 "value": float(m.group(2))})
        for m in re.finditer(r"(冷藏[^\n]{0,16}?)(\d+)\s*[-~至]\s*(\d+)(\s*℃)", line):
            a["cold"].append({"line": i, "sheet": sh.get(i), "frag": m.group(0),
                              "pre": m.group(1), "lo": m.group(2), "hi": m.group(3),
                              "suf": m.group(4)})
        for m in re.finditer(r"((?:净重|设计总重量|装袋净重)[：:]?\s*)(\d+(?:\.\d+)?)(\s*)(g)(?![a-zA-Z])", line):
            a["weight"].append({"line": i, "sheet": sh.get(i), "frag": m.group(0),
                                "pre": m.group(1), "num": m.group(2), "sp": m.group(3)})
        for m in re.finditer(r"(解冻[^\n]{0,40}?)(\d+)\s*[-~至]\s*(\d+)\s*h", line):
            a["thaw"].append({"line": i, "sheet": sh.get(i), "frag": m.group(0)})
        bm = BULLET_RE.match(line.strip())
        if bm and bm.group(1) in ("实施日期", "版本号", "商品名", "签署"):
            a["header"].append({"line": i, "sheet": sh.get(i), "key": bm.group(1),
                                "value": bm.group(2)})
    return a


def _mk_defect(kind, point_code, sheet, clean_frag, inj_frag, clean_value, inj_value, instruction):
    dt, sev = DEFECT_OF[point_code]
    return {"kind": kind, "point_code": point_code, "point_name": POINT_NAME[point_code],
            "defect_type": dt, "severity": sev, "sheet": sheet,
            "clean_frag": clean_frag, "inj_frag": inj_frag,
            "clean_value": clean_value, "inj_value": inj_value, "instruction": instruction}


def build_plan(num: int, base_doc: str) -> dict:
    """num 01-06 → variant1（表格数值类，2 缺陷，可转 xlsx）；07-12 → variant2（表头类，3 缺陷）。"""
    a = find_anchors(base_doc)
    variant = 1 if num <= 6 else 2
    base_idx = num if num <= 6 else num - 6
    defects = []
    if num == 1:
        # 场景：同码多实例（同一文档同一点位 3 处违规）→ 平台应各自成条 finding
        ppms = [x for x in a["ppm"] if x["value"] >= 200]
        if len(ppms) >= 3:
            for x in ppms[:3]:
                line = base_doc.splitlines()[x["line"]]
                mr = re.search(r"(\d{2,3})\s*[-~至]\s*(\d{3})\s*ppm", line)
                if mr and mr.group(2) == str(x["value"]):
                    cf, inj2 = mr.group(0), "120-150ppm"
                else:
                    cf, inj2 = x["frag"], "150ppm"
                defects.append(_mk_defect("ppm", "FOOD01-002", x["sheet"], cf, inj2, cf, inj2,
                                          "同码多实例：消毒浓度 %s→%s" % (cf, inj2)))
        else:
            temps = [x for x in a["temp"] if x["value"] >= 85]
            for x in temps[:3]:
                inj2 = "中心温度%s78%s" % (x["pre"], x["suf"])
                defects.append(_mk_defect("temp", "FOOD01-001", x["sheet"], x["frag"], inj2,
                                          x["frag"], inj2, "同码多实例：中心温度→78℃"))
        if len(defects) < 2:
            raise SystemExit("[FATAL] base%d 无法构造同码多实例（可用锚点不足）" % base_idx)
        return {"num": num, "base_idx": base_idx, "variant": variant,
                "industry": SPECS[base_idx - 1]["industry"],
                "product": SPECS[base_idx - 1]["product"], "defects": defects,
                "scenario": "multi_instance_same_code"}
    if num == 9:
        # 场景：证据不足样本——把明确数值改成"按企业内控标准执行"，平台应判 insufficient（不得判 fail）
        temps = [x for x in a["temp"] if x["value"] >= 85]
        if not temps:
            raise SystemExit("[FATAL] base%d 无温度锚点，无法构造证据不足样本" % base_idx)
        t = temps[0]
        cf = t["frag"]
        inj2 = "中心温度按企业内控标准执行"
        d = _mk_defect("temp_insufficient", "FOOD01-001", t["sheet"], cf, inj2, cf, inj2,
                       "证据不足：明确温度 %s 改为『中心温度按企业内控标准执行』（缺数值，应判 insufficient）"
                       % cf)
        d["expected_state"] = "insufficient"
        d["defect_type"] = "字段缺失"
        d["severity"] = "中"
        return {"num": num, "base_idx": base_idx, "variant": variant,
                "industry": SPECS[base_idx - 1]["industry"],
                "product": SPECS[base_idx - 1]["product"], "defects": [d],
                "scenario": "insufficient_evidence"}
    if variant == 1:
        temps = [x for x in a["temp"] if x["value"] >= 85]
        if not temps:
            raise SystemExit("[FATAL] base%d 没有 ≥85℃ 的中心温度锚点，无法生成 v1 注入计划" % base_idx)
        t = temps[0]
        inj = "中心温度%s78%s" % (t["pre"], t["suf"])
        defects.append(_mk_defect("temp", "FOOD01-001", t["sheet"], t["frag"], inj,
                                  t["frag"], inj,
                                  "中心温度 %s→78℃（低于平台判据 85℃）" % t["num"]))
        # 第二个缺陷：优先 消毒浓度 → 冷却终温 → 冷藏温度 → 重量单位（都落在工序表单元格）
        used_lines = {t["line"]}
        cand = None
        if num in (2, 6):
            wt = [x for x in a["weight"] if x["line"] not in used_lines]
            if wt:
                cand = ("weight", wt[0])
        for x in a["ppm"] if cand is None else []:
            if x["value"] >= 200 and x["line"] not in used_lines:
                cand = ("ppm", x); break
        if not cand:
            for x in a["cooling"]:
                if x["value"] <= 10 and x["line"] not in used_lines:
                    cand = ("cooling", x); break
        if not cand:
            for x in a["cold"]:
                if (int(x["lo"]), int(x["hi"])) == (0, 8) and x["line"] not in used_lines:
                    cand = ("cold", x); break
        if not cand:
            for x in a["weight"]:
                if x["line"] not in used_lines:
                    cand = ("weight", x); break
        if not cand:
            # 退路：另一处温度锚点（不同行）
            others = [x for x in temps[1:] if x["line"] not in used_lines]
            if others:
                x = others[0]
                inj2 = "中心温度%s78%s" % (x["pre"], x["suf"])
                defects.append(_mk_defect("temp", "FOOD01-001", x["sheet"], x["frag"], inj2,
                                          x["frag"], inj2, "中心温度 %s→78℃" % x["num"]))
            else:
                raise SystemExit("[FATAL] base%d 找不到第二个可注入的表格锚点" % base_idx)
        else:
            kind, x = cand
            if kind == "ppm":
                line = base_doc.splitlines()[x["line"]]
                mr = re.search(r"(\d{2,3})\s*[-~至]\s*(\d{3})\s*ppm", line)
                if mr and mr.group(2) == str(x["value"]):
                    clean_frag, inj2 = mr.group(0), "120-150ppm"
                else:
                    clean_frag, inj2 = x["frag"], "150ppm"
                defects.append(_mk_defect(kind, "FOOD01-002", x["sheet"], clean_frag, inj2,
                                          clean_frag, inj2,
                                          "消毒浓度 %s→%s（低于平台判据 200ppm）"
                                          % (clean_frag, inj2)))
            elif kind == "cooling":
                inj2 = "%s15%s" % (x["pre"], x["suf"])
                defects.append(_mk_defect(kind, "FOOD01-003", x["sheet"], x["frag"], inj2,
                                          x["frag"], inj2,
                                          "冷却终温 %s℃→15℃（高于平台判据 10℃）" % x["num"]))
            elif kind == "cold":
                inj2 = "%s12-18%s" % (x["pre"], x["suf"])
                defects.append(_mk_defect(kind, "FOOD01-004", x["sheet"], x["frag"], inj2,
                                          x["frag"], inj2,
                                          "冷藏 %s-%s℃→12-18℃" % (x["lo"], x["hi"])))
            else:
                inj2 = "%s%s%s kg" % (x["pre"], x["num"], x["sp"])
                defects.append(_mk_defect(kind, "FOOD01-006", x["sheet"], x["frag"], inj2,
                                          x["frag"], inj2,
                                          "重量单位 g→kg（与文内其他 g 混用）"))
    else:
        hv = [x for x in a["header"] if x["key"] == "版本号" and x["value"] not in PLACEHOLDER]
        hd = [x for x in a["header"] if x["key"] == "实施日期"]
        hs = [x for x in a["header"] if x["key"] == "签署"]
        used_sheets = set()
        if not hv:
            raise SystemExit("[FATAL] base%d 没有版本号锚点" % base_idx)
        v = hv[0]
        defects.append(_mk_defect("version", "FOOD04-001", v["sheet"],
                                  "版本号：%s" % v["value"], "版本号：X",
                                  v["value"], "X",
                                  "版本号 %s→X（占位符）" % v["value"]))
        used_sheets.add(v["sheet"])
        d = next((x for x in hd if x["sheet"] not in used_sheets), None)
        if d:
            newd = "2026-09-15" if d["value"] != "2026-09-15" else "2026-10-20"
            defects.append(_mk_defect("date", "FOOD03-001", d["sheet"],
                                      "实施日期：%s" % d["value"], "实施日期：%s" % newd,
                                      d["value"], newd,
                                      "实施日期 %s→%s 与其他 Sheet 不一致" % (d["value"], newd)))
            used_sheets.add(d["sheet"])
        s = next((x for x in hs if x["sheet"] not in used_sheets), None)
        if s:
            parts = [p.strip() for p in s["value"].split("/")]
            first = parts[0]
            mm = re.match(r"^(研发经理|生产经理|品管经理|研发)\s+(\S+)$", first)
            if mm:
                clean_frag = "%s %s" % (mm.group(1), mm.group(2))
                inj_frag = "%s X" % mm.group(1)
                defects.append(_mk_defect("sign", "FOOD04-002", s["sheet"],
                                          clean_frag, inj_frag, clean_frag, inj_frag,
                                          "签署姓名 %s→X（占位符）" % mm.group(2)))
                used_sheets.add(s["sheet"])
        if len(defects) < 2:
            # 退路：第二个版本号改为旧版本（FOOD03-003 前后矛盾）
            v2 = next((x for x in hv if x["sheet"] not in used_sheets), None)
            if v2:
                alt = v2["value"].replace("2026", "2025") if "2026" in v2["value"] else v2["value"] + "-OLD"
                if alt == v2["value"]:
                    alt = v2["value"] + "-OLD"
                defects.append(_mk_defect("version2", "FOOD03-003", v2["sheet"],
                                          "版本号：%s" % v2["value"], "版本号：%s" % alt,
                                          v2["value"], alt,
                                          "版本号 %s→%s（跨 Sheet 不一致）" % (v2["value"], alt)))
    return {"num": num, "base_idx": base_idx, "variant": variant,
            "industry": SPECS[base_idx - 1]["industry"], "product": SPECS[base_idx - 1]["product"],
            "defects": defects}


# ---------------------------------------------------------------- 注入结果校验/校正

def _table_cells(line: str):
    s = line.strip()
    if not s.startswith("|"):
        return None
    s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    cells = [c.strip() for c in s.split("|")]
    return cells


def classify_change(cl: str, il: str):
    """按平台点位判据识别一行改动对应的 point_code；识别不了返回 None。"""
    for kind, pc, rx in (
        ("cold", "FOOD01-004", r"冷藏[^\n]{0,16}?(\d+)\s*[-~至]\s*(\d+)\s*℃"),
        ("cooling", "FOOD01-003", r"冷却[^\n]{0,20}?[≤<]\s*(\d+(?:\.\d+)?)\s*℃"),
        ("temp", "FOOD01-001", r"中心温度\s*[≥>]\s*(\d+(?:\.\d+)?)\s*℃"),
        ("ppm", "FOOD01-002", r"(\d{3})\s*ppm"),
    ):
        m1, m2 = re.search(rx, cl), re.search(rx, il)
        if m1 and m2 and m1.group(0) != m2.group(0):
            if kind == "cold":
                rng = (int(m2.group(1)), int(m2.group(2)))
                if rng != (0, 8):
                    return pc
            elif kind == "cooling":
                if float(m2.group(1)) > 10:
                    return pc
            elif kind == "temp":
                if float(m2.group(1)) < 85:
                    return pc
            else:
                if int(m2.group(1)) < 200:
                    return pc
            return None
    if re.search(r"\d(?:\.\d+)?\s*kg", il) and re.search(r"\d(?:\.\d+)?\s*g(?![a-zA-Z])", cl):
        return "FOOD01-006"
    bm1, bm2 = BULLET_RE.match(cl.strip()), BULLET_RE.match(il.strip())
    if bm1 and bm2 and bm1.group(1) == bm2.group(1):
        k, v1, v2 = bm1.group(1), bm1.group(2), bm2.group(2)
        if k == "版本号":
            if v2 in PLACEHOLDER or not v2:
                return "FOOD04-001"
            if v2 != v1:
                return "FOOD03-003"
        elif k == "实施日期" and v2 != v1:
            return "FOOD03-001"
        elif k == "商品名" and v2 != v1:
            return "FOOD03-002"
        elif k == "签署" and "X" in v2 and "X" not in v1:
            return "FOOD04-002"
    return None


def _ambiguous(pc: str, ev: str) -> bool:
    """注入行是否同时含「合规值」和「违规值」（平台可能据此判 pass，gold 会变成假缺陷）。"""
    if pc == "FOOD01-001":
        if "中心温度" not in ev:
            return False
        nums = [float(x) for x in
                re.findall(r"中心温度[^\d]{0,15}?(\d+(?:\.\d+)?)\s*℃", ev)]
        return any(n >= 85 for n in nums) and any(n < 85 for n in nums)
    if pc == "FOOD01-002":
        nums = [int(x) for x in re.findall(r"(\d{3})\s*ppm", ev)]
        return any(n >= 200 for n in nums) and any(n < 200 for n in nums)
    if pc == "FOOD01-003":
        nums = [float(x) for x in
                re.findall(r"冷却[^\n]{0,20}?[≤<]\s*(\d+(?:\.\d+)?)\s*℃", ev)]
        return len(nums) > 1 and any(n > 10 for n in nums) and any(n <= 10 for n in nums)
    if pc == "FOOD01-004":
        rng = {(int(a), int(b)) for a, b in
               re.findall(r"冷藏[^\n]{0,16}?(\d+)\s*[-~至]\s*(\d+)\s*℃", ev)}
        return len(rng) > 1
    return False


def _mechanical_fill(base_doc: str, plan: dict, inj_lines: list, used_rows: set,
                     entries: list, stats: dict) -> list:
    """AI 未落地的计划缺陷 → 由脚本按同一注入计划机械补注入（可审计、逐条记录）。

    用途：① AI 漏改；② AI 改出的行同时含合规值+违规值（ambiguity）被还原后，换一个
    无歧义的同类型锚点补注入。补注入只做单行单片段替换，并同样走逐字/歧义校验。
    """
    a = find_anchors(base_doc)
    sh = sheet_of_line(base_doc)
    applied_codes = {e["point_code"] for e in entries}
    outs = []
    for d in plan["defects"]:
        pc = d["point_code"]
        if pc in applied_codes and d.get("expected_state", "fail") == "fail":
            continue
        kind = d["kind"]
        cand = None
        if kind == "temp":
            for x in a["temp"]:
                if x["value"] < 85 or x["line"] in used_rows:
                    continue
                new = "中心温度%s78%s" % (x["pre"], x["suf"])
                cand = (x["line"], x["frag"], new)
                if not _ambiguous(pc, base_doc.splitlines()[x["line"]].replace(x["frag"], new)):
                    break
                cand = None
        elif kind == "ppm":
            for x in a["ppm"]:
                if x["value"] < 200 or x["line"] in used_rows:
                    continue
                cand = (x["line"], x["frag"], "150ppm")
                if not _ambiguous(pc, base_doc.splitlines()[x["line"]].replace(x["frag"], "150ppm")):
                    break
                cand = None
        elif kind == "cooling":
            for x in a["cooling"]:
                if x["value"] > 10 or x["line"] in used_rows:
                    continue
                new = "%s15%s" % (x["pre"], x["suf"])
                cand = (x["line"], x["frag"], new)
                if not _ambiguous(pc, base_doc.splitlines()[x["line"]].replace(x["frag"], new)):
                    break
                cand = None
        elif kind == "cold":
            for x in a["cold"]:
                if (int(x["lo"]), int(x["hi"])) != (0, 8) or x["line"] in used_rows:
                    continue
                new = "%s12-18%s" % (x["pre"], x["suf"])
                cand = (x["line"], x["frag"], new)
                if not _ambiguous(pc, base_doc.splitlines()[x["line"]].replace(x["frag"], new)):
                    break
                cand = None
        elif kind == "weight":
            for x in a["weight"]:
                if x["line"] in used_rows:
                    continue
                new = "%s%s%s kg" % (x["pre"], x["num"], x["sp"])
                cand = (x["line"], x["frag"], new)
                break
        else:
            # 表头类：clean_frag 必须在 base 唯一出现
            hits = [k for k, ln in enumerate(base_doc.splitlines())
                    if d["clean_frag"] in ln and k not in used_rows
                    and ln.count(d["clean_frag"]) == 1]
            if hits:
                cand = (hits[0], d["clean_frag"], d["inj_frag"])
        if not cand:
            stats.setdefault("mechanical_missed", []).append(pc)
            continue
        k, cf, injf = cand
        base_line = base_doc.splitlines()[k]
        new_line = base_line.replace(cf, injf, 1)
        if new_line == base_line:
            continue
        inj_lines[k] = new_line
        used_rows.add(k)
        ev = new_line.strip()
        if _ambiguous(pc, ev):
            inj_lines[k] = base_line
            stats.setdefault("mechanical_missed", []).append(pc)
            continue
        outs.append({
            "schema_version": "gold-v1", "file_id": None, "issue_id": None,
            "base_file_id": None, "layer": "L2", "industry": plan["industry"],
            "point_code": pc, "point_name": POINT_NAME[pc],
            "defect_type": d["defect_type"], "evidence_text": ev,
            "clean_text": base_line.strip(), "injected_text": ev,
            "location": {"page": None, "sheet": sh.get(k), "row": k + 1, "col": None},
            "expected_state": d.get("expected_state") or "fail",
            "severity": d["severity"], "source": "external_ai",
            "issue": "脚本机械补注入（AI 未落地/改出歧义行后替换）：%s→%s"
                     % (cf[:50], injf[:50]),
            "correction": {"how": "mechanical_fill"}, "_line": k,
        })
        stats.setdefault("mechanical_filled", []).append(pc)
        applied_codes.add(pc)
    return outs


def verify_repair(base_doc: str, inj_doc: str, plan: dict) -> tuple:
    """机械校验 AI 注入：以实际逐行 diff 重新生成 gold；计划外改动整行还原。"""
    stats = {"line_count_equal": False, "changed_lines": 0, "planned_matched": 0,
             "semantic_matched": 0, "reverted_lines": [], "entries": 0,
             "plan_unapplied": [], "dup_reverted": 0}
    b = base_doc.splitlines()
    i = inj_doc.splitlines()
    if len(b) != len(i):
        return None, {"error": "注入稿与干净稿行数不同（%d vs %d）" % (len(b), len(i))}
    stats["line_count_equal"] = True
    sh = sheet_of_line(inj_doc)
    changed = [k for k in range(len(b)) if b[k] != i[k]]
    stats["changed_lines"] = len(changed)
    if not changed:
        return None, {"error": "未检测到任何修改"}
    applied_defects = []
    candidates = []
    for k in changed:
        cl, il = b[k], i[k]
        mdef, how = None, None
        for di, d in enumerate(plan["defects"]):
            if di in applied_defects:
                continue
            if d["clean_frag"] in cl and d["inj_frag"] in il:
                if cl.replace(d["clean_frag"], "", 1) == il.replace(d["inj_frag"], "", 1):
                    mdef, how = d, "planned"
                    applied_defects.append(di)
                    break
        exp_state = "fail"
        if mdef:
            pc, dt, sev = mdef["point_code"], mdef["defect_type"], mdef["severity"]
            exp_state = str(mdef.get("expected_state") or "fail")
            stats["planned_matched"] += 1
        else:
            pc = classify_change(cl, il)
            if not pc:
                i[k] = b[k]
                stats["reverted_lines"].append(k + 1)
                continue
            dt, sev = DEFECT_OF[pc]
            stats["semantic_matched"] += 1
        ev, cv = il.strip(), cl.strip()
        if not ev or len(ev) > 400 or any(w in ev for w in FUZZY):
            i[k] = b[k]
            stats["reverted_lines"].append(k + 1)
            continue
        if _ambiguous(pc, ev):
            i[k] = b[k]
            stats.setdefault("ambiguous_reverted", []).append(k + 1)
            continue
        candidates.append({"line": k, "point_code": pc, "defect_type": dt, "severity": sev,
                           "evidence_text": ev, "clean_text": cv, "sheet": sh.get(k),
                           "expected_state": exp_state,
                           "how": "planned" if mdef else "semantic"})
    # 去重 + 上限 3 条；多出的整行还原
    seen, keep = set(), []
    for c in candidates:
        key = (c["point_code"], c["evidence_text"])
        if key in seen or len(keep) >= 3:
            i[c["line"]] = b[c["line"]]
            stats["dup_reverted"] += 1
            seen.add(key)
            continue
        seen.add(key)
        keep.append(c)
    plan_codes = [d["point_code"] for d in plan["defects"]]
    got_codes = [c["point_code"] for c in keep]
    stats["plan_unapplied"] = [c for c in plan_codes if c not in got_codes]
    # 机械补注入（AI 未落地 / 歧义行被还原）：保证计划缺陷尽量落地
    filled = _mechanical_fill(base_doc, plan, i, {c["line"] for c in keep}, keep, stats)
    for e in filled:
        keep.append({"line": e["_line"], "point_code": e["point_code"],
                     "defect_type": e["defect_type"], "severity": e["severity"],
                     "evidence_text": e["evidence_text"], "clean_text": e["clean_text"],
                     "sheet": e["location"]["sheet"],
                     "expected_state": e["expected_state"], "how": "mechanical_fill",
                     "prebuilt": e})
    keep.sort(key=lambda c: c["line"])
    got_codes = sorted({c["point_code"] for c in keep})
    injured = "\n".join(i).rstrip() + "\n"
    entries = []
    for n, c in enumerate(keep, 1):
        if c.get("prebuilt"):
            e = c["prebuilt"]
            e["location"]["row"] = c["line"] + 1
            entries.append(e)
            continue
        if c["evidence_text"] not in injured:
            return None, {"error": "校正后 evidence 不在注入稿：%r" % c["evidence_text"][:60]}
        row = c["line"] + 1
        if b[c["line"]].strip() != c["clean_text"]:
            return None, {"error": "clean_text 与 base 同行不一致：line %d" % row}
        entries.append({
            "schema_version": "gold-v1", "file_id": None, "issue_id": None,
            "base_file_id": None, "layer": "L2", "industry": plan["industry"],
            "point_code": c["point_code"], "point_name": POINT_NAME[c["point_code"]],
            "defect_type": c["defect_type"], "evidence_text": c["evidence_text"],
            "clean_text": c["clean_text"], "injected_text": c["evidence_text"],
            "location": {"page": None, "sheet": c["sheet"], "row": row, "col": None},
            "expected_state": c.get("expected_state") or "fail",
            "severity": c["severity"], "source": "external_ai",
            "issue": "AI 注入（%s→%s）；机械校正 evidence/clean/location 取实际改动行"
                     % (c["clean_text"][:60], c["evidence_text"][:60]),
            "correction": {"how": c["how"]},
        })
    stats["entries"] = len(entries)
    stats["plan_applied"] = got_codes
    stats["plan_unapplied"] = [c for c in plan_codes if c not in got_codes]
    # 接受口径：至少 1 条经逐字/歧义校验的 gold，至多 3 条；计划未全部落地如实记录
    accepted = 1 <= len(entries) <= 3
    return {"inj_doc": injured, "entries": entries, "stats": stats, "accepted": accepted}, None


# ---------------------------------------------------------------- 干净稿参数归一

def _norm_cooling_cells(line: str) -> str:
    """删掉「冷却间温度 ...℃」环境温度子句（平台 FOOD01-003 只认产品中心温度）。"""
    cells = line.split("|")
    for j in range(1, len(cells) - 1):
        c = cells[j]
        if "冷却间温度" not in c:
            continue
        nc = re.sub(r"冷却间温度\s*[≤<]?\s*\d+(?:\s*[-~至]\s*\d+)?\s*℃", "", c)
        nc = re.sub(r"^[\s，,、]+|[\s，,、]+$", "", nc).strip()
        if not nc:
            nc = "擦干袋身表面水分后无可见水渍"
        cells[j] = " " + nc + " " if c.startswith(" ") else nc
    return "|".join(cells)


def normalize_clean(doc: str) -> tuple:
    """把 AI 干净稿的参数书写口径归一到平台判据口径（机械、可审计、逐行记录）。

    只做 5 类改写（不改缺陷语义、不新增/删除行）：
      1) 温度符号 °C → ℃；
      2) 冷藏/库温/贮存 的 0-4℃ → 0-8℃（平台 FOOD01-004 判据为 0-8℃）；
      3) 「冷藏温度/暂存温度」单值（如 4℃）→ 冷藏温度 0-8℃；
      4) 删除「冷却间温度 ...℃」环境温度子句（避免被误绑为冷却终温判据）；
      5) 非冷却语境下无比较符的「中心温度 NN℃」→「中心温度≥NN℃」。
    返回 (新正文, 归一记录列表)。
    """
    reps = []
    out = []
    for n, line in enumerate(doc.splitlines(), 1):
        nl = line.replace("°C", "℃")
        if ("冷藏" in line or "库温" in line or "贮存" in line) and re.search(r"0\s*[-~至]\s*4\s*℃", line):
            nl = re.sub(r"0\s*[-~至]\s*4\s*℃", "0-8℃", nl)
        if ("冷藏" in nl or "暂存" in nl) and re.search(
                r"(?:冷藏温度|暂存温度)\s*\d+(?:\.\d+)?\s*℃", nl):
            nl = re.sub(r"(?:冷藏温度|暂存温度)\s*\d+(?:\.\d+)?\s*℃", "冷藏温度 0-8℃", nl)
        if "冷却间温度" in nl:
            nl = _norm_cooling_cells(nl)
        if "中心温度" in nl and not re.search(r"冷却|降至|降温|水温", nl):
            nl = re.sub(r"(中心温度\s*)(\d+(?:\.\d+)?)\s*℃",
                        lambda m: m.group(1) + "≥" + m.group(2) + "℃", nl)
        if nl != line:
            reps.append({"line": n, "before": line.strip()[:100], "after": nl.strip()[:100]})
            out.append(nl)
        else:
            out.append(line)
    new = "\n".join(out)
    if doc.endswith("\n"):
        new += "\n"
    return new, reps


def phase_normalize() -> dict:
    """对 L1 干净稿做机械参数归一，归一后重跑结构自检；通过则接受。"""
    st = load_state()
    L1 = st.setdefault("l1", {})
    for s in SPECS:
        key = str(s["idx"])
        rec = L1.get(key) or {}
        doc = rec.get("doc") or ""
        if not doc:
            continue
        if rec.get("accepted"):
            continue
        new, reps = normalize_clean(doc)
        fails, warns = l1_check(new)
        rec.update({"doc": new, "normalized": reps, "fails": fails, "warns": warns,
                    "accepted": not fails, "normalize_count": len(reps)})
        print("  [normalize] doc%s 改写 %d 处 → fails=%d warns=%d"
              % (key, len(reps), len(fails), len(warns)), flush=True)
        if fails:
            print("        fails: %s" % fails[:4], flush=True)
        L1DIR.mkdir(parents=True, exist_ok=True)
        (L1DIR / ("doc%02d.md" % s["idx"])).write_text(new, encoding="utf-8")
    save_state(st)
    return st


# ---------------------------------------------------------------- phases

def phase_l1(pr: dict, max_attempts: int = 2, force: bool = False) -> dict:
    st = load_state()
    L1 = st.setdefault("l1", {})
    if force:
        L1.clear()
    if not L1:
        # 允许外部预置（例如本会话先前已用同一提示词生成并校验过的稿）
        seeded = WORK / "l1_seed.json"
        if seeded.is_file():
            seed = json.loads(seeded.read_text(encoding="utf-8"))
            for k, v in seed.items():
                L1[k] = {"accepted": True, "doc": v["doc"], "attempt": 0,
                         "fails": [], "warns": v.get("warns", []), "seeded": True}
    for attempt in range(1, max_attempts + 1):
        pending = [s for s in SPECS if not L1.get(str(s["idx"]), {}).get("accepted")]
        if not pending:
            break
        print("[phase l1] attempt %d：%d 份" % (attempt, len(pending)), flush=True)
        prepared = [("l1_%02d_a%d" % (s["idx"], attempt), prompt_l1(pr, s)) for s in pending]
        res = run_jobs(prepared)
        st = load_state()
        L1 = st.setdefault("l1", {})
        for tag, (rec, out) in res.items():
            key = str(int(tag.split("_")[1]))
            doc = extract_doc(out)
            fails, warns = l1_check(doc)
            rec_l1 = L1.setdefault(key, {})
            rec_l1.update({"attempt": attempt, "doc_chars": len(doc), "fails": fails,
                           "warns": warns, "accepted": not fails, "doc": doc})
            print("  [l1] doc%s %s chars=%d fails=%d warns=%d"
                  % (key, "OK" if not fails else "RETRY", len(doc), len(fails), len(warns)), flush=True)
            if fails:
                print("        fails: %s" % fails[:4], flush=True)
        save_state(st)
    st = load_state()
    L1 = st.get("l1", {})
    for s in SPECS:
        rec = L1.get(str(s["idx"]), {})
        if rec.get("accepted"):
            L1DIR.mkdir(parents=True, exist_ok=True)
            (L1DIR / ("doc%02d.md" % s["idx"])).write_text(rec["doc"], encoding="utf-8")
    save_state(st)
    ok = sum(1 for s in SPECS if L1.get(str(s["idx"]), {}).get("accepted"))
    print("[phase l1] accepted %d/%d" % (ok, len(SPECS)), flush=True)
    return st


def phase_l2(pr: dict, max_attempts: int = 2) -> dict:
    st = load_state()
    L1 = st.get("l1", {})
    for s in SPECS:
        if not L1.get(str(s["idx"]), {}).get("accepted"):
            raise SystemExit("[FATAL] L1 doc%d 未通过，先跑 --phase l1" % s["idx"])
    plans, L2 = {}, st.setdefault("l2", {})
    for s in SPECS:
        for num in (s["idx"], s["idx"] + 6):
            base_doc = L1[str(s["idx"])]["doc"]
            plans[str(num)] = build_plan(num, base_doc)
    st["plans"] = plans
    save_state(st)
    for attempt in range(1, max_attempts + 1):
        pending = [num for num in range(1, 13)
                   if not L2.get("PS-L2-%02d" % num, {}).get("accepted")]
        if not pending:
            break
        print("[phase l2] attempt %d：%d 份" % (attempt, len(pending)), flush=True)
        prepared = []
        for num in pending:
            plan = plans[str(num)]
            base_doc = L1[str(plan["base_idx"])]["doc"]
            prepared.append(("l2_%02d_a%d" % (num, attempt), prompt_l2(pr, base_doc, plan)))
        res = run_jobs(prepared)
        st = load_state()
        L2 = st.setdefault("l2", {})
        for tag, (rec, out) in res.items():
            num = int(tag.split("_")[1])
            fid = "PS-L2-%02d" % num
            plan = plans[str(num)]
            base_doc = L1[str(plan["base_idx"])]["doc"]
            inj_doc = extract_doc(out)
            ai_gold = extract_gold(out)
            result, err = (verify_repair(base_doc, inj_doc, plan) if inj_doc
                           else (None, {"error": "AI 输出里没有 <<<DOC>>> 块"}))
            rec_l2 = L2.setdefault(fid, {})
            rec_l2["attempt"] = attempt
            if err or not result:
                rec_l2.update({"accepted": False, "error": err or "unknown",
                               "raw_tag": rec["tag"]})
                print("  [l2] %s RETRY：%s" % (fid, err), flush=True)
                continue
            # AI gold 与机械校正的对照（只记录，不信任）
            ai_cmp = {"ai_entries": None, "ai_evidence_verbatim": 0, "ai_point_match": 0}
            if ai_gold and isinstance(ai_gold.get("entries"), list):
                aes = ai_gold["entries"]
                ai_cmp["ai_entries"] = len(aes)
                for e in aes:
                    ev = str(e.get("evidence_text") or "")
                    if ev and ev in result["inj_doc"]:
                        ai_cmp["ai_evidence_verbatim"] += 1
                    if e.get("point_code") in {x["point_code"] for x in result["entries"]}:
                        ai_cmp["ai_point_match"] += 1
            rec_l2.update({
                "accepted": bool(result["accepted"]),
                "error": None if result["accepted"] else "条目数/主缺陷不满足",
                "inj_doc": result["inj_doc"], "entries": result["entries"],
                "stats": result["stats"], "ai_gold": ai_cmp,
                "seconds": rec["seconds"], "raw_tag": rec["tag"],
            })
            print("  [l2] %s %s entries=%d stats=%s ai_gold=%s"
                  % (fid, "OK" if result["accepted"] else "RETRY", len(result["entries"]),
                     {k: result["stats"][k] for k in ("changed_lines", "planned_matched",
                                                      "semantic_matched", "reverted_lines")},
                     ai_cmp), flush=True)
        save_state(st)
    st = load_state()
    L2 = st.get("l2", {})
    L2DIR.mkdir(parents=True, exist_ok=True)
    for num in range(1, 13):
        fid = "PS-L2-%02d" % num
        rec = L2.get(fid, {})
        if rec.get("accepted"):
            plan = st["plans"][str(num)]
            (L2DIR / ("%s.md" % fid)).write_text(rec["inj_doc"], encoding="utf-8")
    ok = sum(1 for num in range(1, 13) if L2.get("PS-L2-%02d" % num, {}).get("accepted"))
    print("[phase l2] accepted %d/12" % ok, flush=True)
    return st


def _entry_single_cell(base_line: str, inj_line: str):
    c1, c2 = _table_cells(base_line), _table_cells(inj_line)
    if not c1 or not c2 or len(c1) != 5 or len(c2) != 5:
        return None
    diffs = [j for j in range(5) if c1[j] != c2[j]]
    if len(diffs) != 1:
        return None
    return diffs[0]


def choose_xlsx_docs(st: dict) -> list:
    """从 v1（num 01-06）中每行业挑 1 份：全部 gold 都落在标准工序单单元格。"""
    def num_ok(num):
        rec = st["l2"].get("PS-L2-%02d" % num, {})
        if not rec.get("accepted"):
            return False
        base_doc = st["l1"][str(st["plans"][str(num)]["base_idx"])]["doc"]
        b = base_doc.splitlines()
        inj = rec["inj_doc"].splitlines()
        if len(b) != len(inj):
            return False
        for e in rec["entries"]:
            row = e["location"]["row"]
            if row is None or row - 1 >= len(b):
                return False
            if _entry_single_cell(b[row - 1], inj[row - 1]) is None:
                return False
        return True
    chosen, used = [], set()
    for ind in ("烘焙", "肉制品", "调味品"):
        for num in range(1, 7):
            if num in used:
                continue
            if SPECS[num - 1]["industry"] == ind and num_ok(num):
                chosen.append(num)
                used.add(num)
                break
    if len(chosen) < 3:
        for num in range(1, 7):
            if num not in used and num_ok(num):
                chosen.append(num)
                used.add(num)
                if len(chosen) == 3:
                    break
    return sorted(chosen)


def convert_xlsx(st: dict, chosen: list) -> dict:
    """用 tools/md_to_xlsx.py 把 3 份注入稿 (及其 L1 base) 转 xlsx，并迁移 gold 证据口径。"""
    if not chosen:
        return {"chosen": [], "converted": [], "entries_migrated": 0}
    stage = WORK / "xlsx_stage"
    if stage.exists():
        shutil.rmtree(stage)
    (stage / "input").mkdir(parents=True)
    entries_all = []
    clean_control = []
    for num in chosen:
        plan = st["plans"][str(num)]
        base_idx = plan["base_idx"]
        spec = SPECS[base_idx - 1]
        l1_src = L1DIR / ("doc%02d.md" % base_idx)
        l2_src = L2DIR / ("PS-L2-%02d.md" % num)
        shutil.copy(l1_src, stage / "input" / ("L1_%02d_%s_%s.md" % (num, spec["industry"], spec["product"])))
        shutil.copy(l2_src, stage / "input" / ("L2_%02d_%s_%s_注入.md" % (num, spec["industry"], spec["product"])))
        for e in st["l2"]["PS-L2-%02d" % num]["entries"]:
            e2 = json.loads(json.dumps(e, ensure_ascii=False))
            e2["file_id"] = "PS-L2-%02d" % num
            e2["base_file_id"] = "PS-L1-%02d" % num
            e2["issue_id"] = "PS-L2-%02d-G%d" % (num, len([x for x in entries_all
                                                           if x["file_id"] == e2["file_id"]]) + 1)
            entries_all.append(e2)
    staging_gold = {"schema_version": "gold-v1", "benchmark_id": "xlsx_stage",
                    "entries": entries_all,
                    "clean_control": [{"file_id": "PS-L1-%02d" % n, "expected_findings": 0,
                                       "expected_state": "pass"} for n in chosen]}
    (stage / "gold.json").write_text(json.dumps(staging_gold, ensure_ascii=False, indent=1),
                                     encoding="utf-8")
    (stage / "meta.json").write_text(json.dumps({"benchmark_id": "xlsx_stage"}, ensure_ascii=False),
                                     encoding="utf-8")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT)
    r = subprocess.run([sys.executable, str(MDX), "--bench", str(stage)],
                       capture_output=True, text=True, env=env)
    (WORK / "md_to_xlsx.log").write_text((r.stdout or "") + "\n" + (r.stderr or ""),
                                         encoding="utf-8")
    print("[xlsx] md_to_xlsx rc=%s" % r.returncode, flush=True)
    print((r.stdout or "").strip()[:1200], flush=True)
    if r.returncode != 0:
        print((r.stderr or "").strip()[:1500], flush=True)
        raise SystemExit("[FATAL] md_to_xlsx 失败（见 %s）" % (WORK / "md_to_xlsx.log"))
    migrated = json.loads((stage / "gold.json").read_text(encoding="utf-8"))
    md_source = json.loads((stage / "gold_md_source.json").read_text(encoding="utf-8"))
    return {"chosen": chosen, "stage": str(stage),
            "migrated_entries": migrated.get("entries") or [],
            "md_source_entries": md_source.get("entries") or [],
            "conversion": migrated.get("conversion"),
            "files": sorted(p.name for p in (stage / "input").glob("*.xlsx"))}


def assemble(st: dict, pr: dict, xlsx_res: dict) -> dict:
    L1, L2, plans = st["l1"], st["l2"], st["plans"]
    l2_nums = [n for n in range(1, 13)
               if L2.get("PS-L2-%02d" % n, {}).get("accepted")]
    if len(l2_nums) < 8:
        print("[WARN] 仅 %d 份 L2 通过（应≥8，场景覆盖可能不足）：%s" % (len(l2_nums), l2_nums))
    # 校验路径安全后重建产物目录
    if OUT.exists():
        if OUT.resolve().parent != (ROOT / "tests" / "fixtures").resolve():
            raise SystemExit("[FATAL] 拒绝删除非 fixtures 目录：%s" % OUT)
        shutil.rmtree(OUT)
    (OUT / "input").mkdir(parents=True)
    files = []
    for s in SPECS:
        src = L1DIR / ("doc%02d.md" % s["idx"])
        dst = OUT / "input" / ("L1_%02d_%s_%s.md" % (s["idx"], s["industry"], s["product"]))
        shutil.copy(src, dst)
        files.append(dst)
    for num in l2_nums:
        plan = plans[str(num)]
        src = L2DIR / ("PS-L2-%02d.md" % num)
        dst = OUT / "input" / ("L2_%02d_%s_%s_注入.md"
                               % (num, plan["industry"], plan["product"]))
        shutil.copy(src, dst)
        files.append(dst)
    entries = []
    for num in l2_nums:
        plan = plans[str(num)]
        for gi, e in enumerate(L2["PS-L2-%02d" % num]["entries"], 1):
            e2 = json.loads(json.dumps(e, ensure_ascii=False))
            e2["file_id"] = "PS-L2-%02d" % num
            e2["issue_id"] = "PS-L2-%02d-G%d" % (num, gi)
            e2["base_file_id"] = "PS-L1-%02d" % plan["base_idx"]
            e2["layer"] = "L2"
            e2["industry"] = plan["industry"]
            entries.append(e2)
    xlsx_info = {"chosen": [], "files": [], "entries_migrated": 0}
    if xlsx_res and xlsx_res.get("chosen"):
        chosen = xlsx_res["chosen"]
        # 拷 xlsx（同名同目录；L1 base 也拷，供 validator 回改一致性校验）
        for p in sorted((Path(xlsx_res["stage"]) / "input").glob("*.xlsx")):
            shutil.copy(p, OUT / "input" / p.name)
            files.append(OUT / "input" / p.name)
        # 用迁移后的 evidence/clean/injected/location 替换对应条目
        replaced = 0
        for idx, e in enumerate(entries):
            if e["file_id"] in {"PS-L2-%02d" % n for n in chosen}:
                src = next((m for m in xlsx_res["migrated_entries"]
                            if m.get("issue_id") == e["issue_id"]), None)
                if not src:
                    raise SystemExit("[FATAL] xlsx 迁移条目缺失：%s" % e["issue_id"])
                # 迁移把 evidence/clean/injected/location 改为 xlsx 口径
                for k in ("evidence_text", "clean_text", "injected_text", "location"):
                    e[k] = src[k]
                e["correction"] = {"how": (e.get("correction") or {}).get("how", "ai"),
                                   "evidence_scope": "xlsx_cell（md_to_xlsx 迁移）"}
                replaced += 1
        xlsx_info = {"chosen": chosen, "replaced_entries": replaced,
                     "migrated_total": len(xlsx_res["migrated_entries"]),
                     "conversion": xlsx_res.get("conversion"),
                     "files": sorted(p.name for p in (Path(xlsx_res["stage"]) / "input").glob("*.xlsx"))}
        (OUT / "gold_md_source.json").write_text(
            json.dumps({"schema_version": "gold-v1", "note": "xlsx 迁移前的 md 口径 gold（仅对应 3 份 xlsx 文档）",
                        "entries": xlsx_res["md_source_entries"]}, ensure_ascii=False, indent=1) + "\n",
            encoding="utf-8")
        files.append(OUT / "gold_md_source.json")
    # 调用统计
    calls = st.get("calls") or []
    ok_calls = [c for c in calls if c.get("rc") == 0 and c.get("had_doc")]
    by_phase = {}
    for c in calls:
        ph = c["tag"].split("_")[0]
        d = by_phase.setdefault(ph, {"calls": 0, "ok": 0, "fail": 0, "seconds": 0.0})
        d["calls"] += 1
        d["seconds"] = round(d["seconds"] + float(c.get("seconds") or 0), 1)
        if c.get("rc") == 0 and c.get("had_doc"):
            d["ok"] += 1
        else:
            d["fail"] += 1
    gold = {
        "schema_version": "gold-v1", "benchmark_id": BENCH_ID, "version": BENCH_VER,
        "created_at": CREATED,
        "nature": "构造数据（外部 AI 按提示词 A/B/D 生成内容 + AI 注入 + 机械校验校正 gold）；"
                  "不含任何企业真实工艺文件；不能代表真实企业工艺书分布",
        "generator": "scripts/ai/gen_process_sheet_v2.py",
        "generation": {
            "ai": MODEL, "driver": "scripts/ai/drive_local_ai.sh",
            "prompts": {"A": "docs/qa/工艺书数据生成提示词_20261119.md §提示词 A",
                        "B": "同文件 §提示词 B", "D": "同文件 §提示词 D"},
            "prompt_sha256": {k: v for k, v in (pr.get("sha256") or {}).items() if k in ("A", "B", "D")},
            "temperature": "不可设（opencode run CLI 无 temperature 参数）；以固定 MODEL + 低随机性任务约束代替",
            "calls": by_phase,
        },
        "clean_control": [{"file_id": "PS-L1-%02d" % s["idx"], "layer": "L1",
                           "industry": s["industry"], "product": s["product"],
                           "expected_state": "pass", "expected_findings": 0} for s in SPECS],
        "entries": entries,
        "xlsx_conversion": xlsx_info,
    }
    by_point, by_type, by_doc = {}, {}, {}
    for e in entries:
        by_point[e["point_code"]] = by_point.get(e["point_code"], 0) + 1
        by_type[e["defect_type"]] = by_type.get(e["defect_type"], 0) + 1
        by_doc[e["file_id"]] = by_doc.get(e["file_id"], 0) + 1
    clean_by_ind = {}
    for s in SPECS:
        clean_by_ind[s["industry"]] = clean_by_ind.get(s["industry"], 0) + 1
    gold["stats"] = {"clean_control_files": len(SPECS), "gold_entries": len(entries),
                     "injected_docs": len(l2_nums), "by_point": by_point,
                     "by_defect_type": by_type,
                     "by_doc": by_doc, "clean_by_industry": clean_by_ind,
                     "gold_entries_per_doc": {k: v for k, v in sorted(by_doc.items())}}
    (OUT / "gold.json").write_text(json.dumps(gold, ensure_ascii=False, indent=1) + "\n",
                                   encoding="utf-8")
    files.append(OUT / "gold.json")
    meta = build_meta(st, pr, gold, xlsx_info)
    (OUT / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1) + "\n",
                                   encoding="utf-8")
    files.append(OUT / "meta.json")
    (OUT / "README.md").write_text(build_readme(gold, meta), encoding="utf-8")
    files.append(OUT / "README.md")
    (OUT / "generation_calls.json").write_text(
        json.dumps({"model": MODEL, "driver": "scripts/ai/drive_local_ai.sh",
                    "note": "AI 独立实例：每次调用独立 AI_DRIVE_BASE=/tmp/ai_drive_pv2_b{1..4}；"
                            "并发块内不重复使用同一 base",
                    "calls": calls}, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    files.append(OUT / "generation_calls.json")
    write_shasums()
    return {"gold": gold, "meta": meta}


def write_shasums() -> list:
    lines = []
    for p in sorted(OUT.rglob("*")):
        if not p.is_file() or p.name == "SHA256SUMS":
            continue
        lines.append("%s  %s" % (sha256_file(p), p.relative_to(OUT).as_posix()))
    (OUT / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return lines


def build_meta(st: dict, pr: dict, gold: dict, xlsx_info: dict) -> dict:
    L1, L2, plans = st["l1"], st["l2"], st["plans"]
    calls = st.get("calls") or []
    by_phase = {}
    for c in calls:
        ph = c["tag"].split("_")[0]
        d = by_phase.setdefault(ph, {"calls": 0, "ok": 0, "fail": 0})
        d["calls"] += 1
        if c.get("rc") == 0 and c.get("had_doc"):
            d["ok"] += 1
        else:
            d["fail"] += 1
    l1_recs = []
    for s in SPECS:
        rec = L1.get(str(s["idx"]), {})
        l1_recs.append({"file_id": "PS-L1-%02d" % s["idx"], "industry": s["industry"],
                        "product": s["product"], "chars": len(rec.get("doc") or ""),
                        "attempts": rec.get("attempt"), "fails": rec.get("fails") or [],
                        "warns": rec.get("warns") or [], "seeded": bool(rec.get("seeded")),
                        "normalized": rec.get("normalized") or [],
                        "actives": ["clean_control", "manifest_freeze", "D1_applicability",
                                    "D2D3_extraction", "D4_deterministic_and_semantic",
                                    "D5_conclusion", "finding_materialization",
                                    "review_decide", "report_gate", "report_generate"]})
    l2_recs = []
    for num in range(1, 13):
        rec = L2.get("PS-L2-%02d" % num, {})
        if not rec.get("accepted"):
            continue
        plan = plans[str(num)]
        actives = ["manifest_freeze", "D1_applicability", "D2D3_extraction",
                   "D4_deterministic", "D5_conclusion", "finding_materialization",
                   "review_decide", "report_gate"]
        scen = plan.get("scenario") or ("header_consistency" if plan["variant"] == 2
                                        else "table_parameter")
        if scen == "multi_instance_same_code":
            actives += ["multi_instance_same_code"]
        if scen == "insufficient_evidence" or any(
                (e.get("expected_state") or "fail") != "fail" for e in rec.get("entries") or []):
            actives += ["evidence_gate_insufficient"]
        codes = {d["point_code"] for d in plan["defects"]}
        if codes & {"FOOD03-001", "FOOD03-002", "FOOD03-003", "FOOD04-001", "FOOD04-002"}:
            actives += ["cross_sheet_header"]
        if "FOOD01-006" in codes:
            actives += ["unit_mixing"]
        if num in (xlsx_info.get("chosen") or []):
            actives += ["xlsx_multisheet_parse"]
        if codes & {"FOOD03-002", "FOOD05-004", "FOOD02-002"}:
            actives += ["semantic_rule_candidate"]
        l2_recs.append({
            "file_id": "PS-L2-%02d" % num, "base_file_id": "PS-L1-%02d" % plan["base_idx"],
            "variant": plan["variant"], "industry": plan["industry"],
            "product": plan["product"], "scenario": scen,
            "entries": len(rec.get("entries") or []),
            "attempts": rec.get("attempt"), "stats": rec.get("stats"),
            "ai_gold_compare": rec.get("ai_gold"),
            "actives": actives,
            "plan_defects": [{"kind": d["kind"], "point_code": d["point_code"],
                              "clean_frag": d["clean_frag"], "inj_frag": d["inj_frag"],
                              "expected_state": d.get("expected_state") or "fail"}
                             for d in plan["defects"]],
        })
    return {
        "benchmark_id": BENCH_ID, "version": BENCH_VER, "created_at": CREATED,
        "generator": "scripts/ai/gen_process_sheet_v2.py",
        "generation_method": "外部 AI（本机 DuMate dumate-opencode headless，"
                             "%s）按提示词 A 生成 6 份干净稿；按提示词 B 对每份基底做 2 种注入"
                             "（共 12 份注入稿）；gold 由脚本按「实际逐行 diff」机械校正，"
                             "保证 evidence_text 为注入稿原文逐字子串、clean_text 为 base 同一定位原文；"
                             "3 份注入稿用 tools/md_to_xlsx.py 转 xlsx 并迁移 gold 证据口径" % MODEL,
        "ai": {"model": MODEL, "driver": "scripts/ai/drive_local_ai.sh",
               "parallel_instances": NB,
               "isolated_bases": ["/tmp/ai_drive_pv2_b%d" % i for i in range(1, NB + 1)],
               "temperature": "不可设（CLI 无 temperature 参数）；见 limitations",
               "calls_by_phase": by_phase,
               "prompt_sha256": {k: v for k, v in (pr.get("sha256") or {}).items()
                                 if k in ("A", "B", "D")}},
        "layers": {"L1_clean": len(SPECS),
                   "L2_injected": len([1 for n in range(1, 13)
                                       if (L2.get("PS-L2-%02d" % n) or {}).get("accepted")]),
                   "L3_noise": 0, "L4_adversarial": 0},
        "industries": {ind: sum(1 for s in SPECS if s["industry"] == ind)
                       for ind in ("烘焙", "肉制品", "调味品")},
        "formats": {"md": len([p for p in (OUT / "input").glob("*.md")]) if OUT.is_dir() else None,
                    "xlsx": len([p for p in (OUT / "input").glob("*.xlsx")]) if OUT.is_dir() else None,
                    "xlsx_converted_docs": xlsx_info.get("chosen") or []},
        "clean_control": [{"file_id": "PS-L1-%02d" % s["idx"], "industry": s["industry"],
                           "product": s["product"], "expected_state": "pass"} for s in SPECS],
        "l1_records": l1_recs,
        "l2_records": l2_recs,
        "gold_stats": gold.get("stats"),
        "scenario_coverage": {
            "multi_instance_same_code": "PS-L2-01" in {r.get("file_id") for r in l2_recs},
            "insufficient_evidence": any(r.get("scenario") == "insufficient_evidence" for r in l2_recs),
            "header_consistency": any(r.get("scenario") == "header_consistency" for r in l2_recs),
            "unit_mixing": any("unit_mixing" in (r.get("actives") or []) for r in l2_recs),
            "xlsx_multisheet_parse": any("xlsx_multisheet_parse" in (r.get("actives") or [])
                                          for r in l2_recs),
        },
        "activation_design": {
            "scenarios": {
                "multi_instance_same_code": {"file_id": "PS-L2-01",
                    "design": "同一文档同一 FOOD01-002 点位 3 处违规（3 个消毒工序页）"},
                "insufficient_evidence": {"file_id": "PS-L2-09",
                    "design": "把明确中心温度数值改为『按企业内控标准执行』，期望平台判 insufficient 而非 fail"},
                "header_consistency": {"files": ["PS-L2-07", "PS-L2-08", "PS-L2-10", "PS-L2-11", "PS-L2-12"],
                    "design": "版本号占位符/跨 Sheet 实施日期不一致/签署占位/商品名简称"},
                "unit_mixing": {"files": ["PS-L2-02", "PS-L2-06"],
                    "design": "重量 g→kg 与全文 g 混用（FOOD01-006）"},
                "xlsx_multisheet_parse": {"files": ["PS-L2-01", "PS-L2-03", "PS-L2-05"],
                    "design": "多 Sheet xlsx，长表格行，供平台表格解析"},
            },
            "note": "每份文档的 actives 见 l2_records[].actives；实际激活情况必须由 "
                    "scripts/qa/process_sheet_chain.py --bench tests/fixtures/process_sheet_v2 实跑输出，"
                    "不能只按设计声称。缺失环节在验收清单里标 NOT ACTIVATED。",
        },
        "clean_parameter_normalization": {
            "why": "AI 干净稿个别参数书写方式不满足平台判据点位口径（0-4℃ / 冷却间环境温度 / °C 符号）",
            "method": "机械归一（不改缺陷语义、不增删行），逐行记录见 l1_records[].normalized",
            "count": sum(len(r.get("normalized") or []) for r in l1_recs),
        },
        "parameter_basis": "平台食品点位判据：中心温度≥85℃ / 消毒 200ppm+10min / 冷却≤10℃ / "
                           "冷藏 0-8℃ / 解冻 20-48h / 重量单位统一；均为平台判据，不是国标强制值",
        "honesty_boundaries": [
            "构造数据：AI 生成内容 + AI/机械注入缺陷，不含任何企业真实工艺文件；",
            "只测「平台链路能否定位并判出已知构造缺陷」，不能代表真实企业工艺书准确率；",
            "gold 的 expected_state 按平台点位判据（85℃/200ppm/10℃/0-8℃），不是按国标常识；",
            "提示词 D 自检结论是「AI 对自身产物的复核」，不是人工复核，也不是平台实跑判定；",
            "clean-control 的「无 fail」来自本数据集离线确定性判据复核（scripts/qa/verify_process_sheet_v2.py），"
            "不是平台 LLM 点位判定实跑；",
            "未扩到设计目标的 L1 20 / L2 60，未做 L3 真实噪声与 L4 对抗样本；",
        ],
        "limitations": [
            "opencode run CLI 不暴露 temperature；本轮无法设 0，只能以固定 MODEL + 任务约束降低随机性；",
            "AI 注入后由脚本机械校正 gold（evidence/clean/location 取实际 diff 行），已记录 planned/semantic 匹配与还原行数；",
            "3 份 xlsx 由 md 转换并迁移 gold 证据口径（md 原口径留档 gold_md_source.json）；",
        ],
        "not_done": ["L3 真实噪声（10 份）", "L4 对抗样本（10 份）",
                     "目标规模 L1 20 / L2 60 未达成（本轮 L1 6 / L2 12）",
                     "平台 10 阶段主链端到端实跑未做（本轮只做数据生成 + 离线判据复核）",
                     "人工抽样复核未做（validator 已输出确定性抽样清单）"],
        "reproduce": [
            "PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3",
            "$PY scripts/ai/gen_process_sheet_v2.py --phase l1",
            "$PY scripts/ai/gen_process_sheet_v2.py --phase l2",
            "$PY scripts/ai/gen_process_sheet_v2.py --phase assemble",
            "$PY scripts/qa/validate_generated_dataset.py tests/fixtures/process_sheet_v2",
            "$PY scripts/qa/verify_process_sheet_v2.py tests/fixtures/process_sheet_v2",
        ],
    }


def build_readme(gold: dict, meta: dict) -> str:
    st = gold.get("stats") or {}
    return """# 工艺书评测数据集 v2（process_sheet_dataset_v2）

> 构造数据，**不含任何企业真实工艺文件**；不能代表真实企业工艺书分布。生成于 %s。

- 生成方式：外部 AI（%s）按提示词 A 生成 6 份干净稿 → 提示词 B 注入 12 份含缺陷稿 → 提示词 D 自检；
  gold 由 `scripts/ai/gen_process_sheet_v2.py` 按实际逐行 diff 机械校正（逐字性可机检）。
- 规模：L1 干净 %d 份 / L2 注入 12 份 / gold **%d** 条；行业 烘焙 2 + 肉制品 2 + 调味品 2 基底。
- 格式：`.md` 与 `.xlsx`（3 份注入稿 + 对应 3 份干净稿转 xlsx，gold 证据口径迁移为单元格）。
- 参数口径：平台食品点位判据（85℃/200ppm/10min/≤10℃/0-8℃/20-48h），**不是国标强制值**。

## 目录
```
input/            15 份 md（6 干净 + 12 注入中的 9 份 + 3 份注入 md 原稿）+ 6 份 xlsx
gold.json         gold-v1（entries = 注入点；clean_control = 6 份干净稿）
gold_md_source.json  3 份 xlsx 文档迁移前的 md 口径 gold（审计用）
meta.json         生成记录/调用次数/校验规则/诚实边界/NOT DONE
generation_calls.json 每次外部 AI 调用的耗时/返回码/日志路径
SHA256SUMS        全部文件 sha256
```

## 验收（必须 PASS 才可入库）
```bash
PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
$PY scripts/qa/validate_generated_dataset.py tests/fixtures/process_sheet_v2
$PY scripts/qa/verify_process_sheet_v2.py tests/fixtures/process_sheet_v2
```

## 诚实边界与 NOT DONE
见 meta.json:honesty_boundaries / not_done。本数据集只回答「平台能否定位并判出已知构造缺陷」，
不能回答「真实客户工艺书准确率」；L3 真实噪声 / L4 对抗样本未做。
""" % (CREATED, meta.get("ai", {}).get("model", MODEL), len(meta.get("clean_control") or []),
       st.get("gold_entries", 0))


def phase_d(pr: dict, max_attempts: int = 1) -> dict:
    st = load_state()
    gold = json.loads((OUT / "gold.json").read_text(encoding="utf-8"))
    entries = gold["entries"]
    jobs = []
    for num in range(1, 13):
        fid = "PS-L2-%02d" % num
        doc = (L2DIR / ("%s.md" % fid)).read_text(encoding="utf-8")
        aes = [e for e in entries if e["file_id"] == fid]
        jobs.append(("d_%02d" % num, prompt_d(pr, doc, aes)))
    print("[phase d] 提示词 D 自检 %d 份" % len(jobs), flush=True)
    res = run_jobs(jobs)
    st = load_state()
    D = st.setdefault("d", {})
    for tag, (rec, out) in res.items():
        num = int(tag.split("_")[1])
        fid = "PS-L2-%02d" % num
        raw = extract_block(out, "<<<DJSON>>>", "<<<DJSON_END>>>")
        parsed = None
        if raw:
            try:
                parsed = json.loads(raw.strip())
            except Exception:
                parsed = None
        if parsed is None:
            # 兜底：抓最外层 JSON
            m = re.search(r"\{.*\}", out, re.S)
            if m:
                try:
                    parsed = json.loads(m.group(0))
                except Exception:
                    parsed = None
        checks = (parsed or {}).get("checks") or []
        verbatim_ok = sum(1 for c in checks if c.get("verbatim_ok") is True)
        pc_ok = sum(1 for c in checks if c.get("point_code_ok") is True)
        D[fid] = {"attempt": 1, "overall": (parsed or {}).get("overall"),
                  "checks": len(checks), "verbatim_ok": verbatim_ok, "point_code_ok": pc_ok,
                  "failures": (parsed or {}).get("failures") or [],
                  "summary": (parsed or {}).get("summary"), "raw_tag": rec["tag"],
                  "log": rec["log"], "rc": rec["rc"]}
        print("  [D] %s overall=%s checks=%d verbatim_ok=%d point_ok=%d"
              % (fid, D[fid]["overall"], D[fid]["checks"], verbatim_ok, pc_ok), flush=True)
    save_state(st)
    (OUT / "d_selfcheck.json").write_text(
        json.dumps({"prompt": "docs/qa/工艺书数据生成提示词_20261119.md §提示词 D",
                    "model": MODEL, "checks": D}, ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8")
    write_shasums()
    ok = sum(1 for v in D.values() if v.get("overall") == "PASS")
    print("[phase d] overall PASS %d/12" % ok, flush=True)
    return st


def phase_recover_l2() -> dict:
    """从 AI 原始日志恢复 L2（防进程中断丢结果）：重放「提取注入稿 → 机械校验/校正」全流程。"""
    import glob as _glob
    st = load_state()
    L1 = st.get("l1") or {}
    if not L1:
        raise SystemExit("[FATAL] 无 L1 结果，无法恢复")
    plans = st.get("plans")
    if not plans:
        plans = {}
        for s_ in SPECS:
            for num in (s_["idx"], s_["idx"] + 6):
                plans[str(num)] = build_plan(num, L1[str(s_["idx"])]["doc"])
        st["plans"] = plans
    L2 = st.setdefault("l2", {})
    for num in range(1, 13):
        fid = "PS-L2-%02d" % num
        logs = sorted(_glob.glob(str(LOGS / ("l2_%02d_a*.log" % num))))
        if not logs:
            print("  [recover] %s 无 AI 日志" % fid, flush=True)
            continue
        log = logs[-1]
        out = Path(log).read_text(encoding="utf-8", errors="ignore")
        doc = extract_doc(out)
        if not doc:
            print("  [recover] %s 日志无 <<<DOC>>>" % fid, flush=True)
            continue
        plan = plans[str(num)]
        base_doc = L1[str(plan["base_idx"])]["doc"]
        res, err = verify_repair(base_doc, doc, plan)
        rec = L2.setdefault(fid, {})
        rec.update({"recovered_from": log, "accepted": bool(res and res["accepted"]),
                    "error": err or (None if (res and res["accepted"]) else "校验不通过")})
        if res:
            rec["inj_doc"] = res["inj_doc"]
            rec["entries"] = res["entries"]
            rec["stats"] = res["stats"]
            rec["ai_gold"] = rec.get("ai_gold") or {}
            L2DIR.mkdir(parents=True, exist_ok=True)
            (L2DIR / ("%s.md" % fid)).write_text(res["inj_doc"], encoding="utf-8")
        print("  [recover] %s entries=%s accepted=%s stats=%s"
              % (fid, len((res or {}).get("entries") or []), rec["accepted"],
                 {k: (res or {}).get("stats", {}).get(k) for k in
                  ("planned_matched", "ambiguous_reverted", "mechanical_filled")}), flush=True)
    save_state(st)
    ok = sum(1 for n in range(1, 13) if (L2.get("PS-L2-%02d" % n) or {}).get("accepted"))
    print("[recover-l2] accepted %d/12" % ok, flush=True)
    return st


def phase_reverify() -> dict:
    """用当前（更严格的）校验逻辑重算已生成注入稿的 gold：歧义行还原 + 机械补注入。"""
    st = load_state()
    L1, L2, plans = st["l1"], st["l2"], st["plans"]
    changed = 0
    for num in range(1, 13):
        fid = "PS-L2-%02d" % num
        rec = L2.get(fid) or {}
        if not rec.get("accepted"):
            continue
        plan = plans[str(num)]
        base_doc = L1[str(plan["base_idx"])]["doc"]
        res, err = verify_repair(base_doc, rec["inj_doc"], plan)
        if err or not res:
            rec["reverify_error"] = err or "verify 失败"
            continue
        rec["inj_doc"] = res["inj_doc"]
        rec["entries"] = res["entries"]
        rec["stats"] = res["stats"]
        rec["accepted"] = bool(res["accepted"])
        rec["reverified"] = True
        changed += 1
        print("  [reverify] %s entries=%d ambiguous_reverted=%s mechanical=%s"
              % (fid, len(res["entries"]),
                 (res["stats"].get("ambiguous_reverted") or []),
                 (res["stats"].get("mechanical_filled") or [])), flush=True)
        L2DIR.mkdir(parents=True, exist_ok=True)
        (L2DIR / ("%s.md" % fid)).write_text(rec["inj_doc"], encoding="utf-8")
    save_state(st)
    print("[reverify] %d 份" % changed, flush=True)
    return st


def main() -> int:
    ap = argparse.ArgumentParser(description="外部 AI 生成工艺书数据集 v2")
    ap.add_argument("--phase", default="all",
                    choices=["l1", "normalize", "l2", "recover-l2", "reverify", "assemble", "d", "v", "all"])
    ap.add_argument("--force-l1", action="store_true")
    a = ap.parse_args()
    for d in (WORK, LOGS, PROMPTS, L1DIR, L2DIR):
        d.mkdir(parents=True, exist_ok=True)
    pr = load_prompts()
    if a.phase in ("l1", "all"):
        phase_l1(pr, force=a.force_l1)
    if a.phase in ("normalize", "all"):
        phase_normalize()
    if a.phase in ("l2", "all"):
        phase_l2(pr)
    if a.phase in ("recover-l2", "all"):
        phase_recover_l2()
    if a.phase in ("reverify", "all"):
        phase_reverify()
    if a.phase in ("assemble", "all"):
        st = load_state()
        if not st.get("l2"):
            raise SystemExit("[FATAL] 没有 L2 结果，先跑 --phase l2")
        chosen = choose_xlsx_docs(st)
        print("[assemble] xlsx 目标：%s" % chosen, flush=True)
        xlsx_res = convert_xlsx(st, chosen)
        assemble(st, pr, xlsx_res)
        print("[assemble] 产物：%s" % OUT, flush=True)
        env = os.environ.copy()
        r = subprocess.run([sys.executable, str(ROOT / "scripts/qa/validate_generated_dataset.py"),
                            str(OUT)], capture_output=True, text=True, env=env)
        print((r.stdout or "")[-3000:])
        print((r.stderr or "")[-1000:])
    if a.phase in ("d", "all"):
        phase_d(pr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
