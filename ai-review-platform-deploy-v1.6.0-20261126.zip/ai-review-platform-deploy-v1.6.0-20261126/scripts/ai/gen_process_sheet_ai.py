# -*- coding: utf-8 -*-
"""用本机 AI（DuMate 内置 opencode）造工艺书数据集：L1 干净稿 → 机械注入 → gold（按构造保证逐字）。

设计取舍（重要）：
  · AI 只负责**内容**（真实感的干净工艺书正文，prompt A 的输入契约）
  · 缺陷注入 + gold 由**我们的代码机械完成**：正则在 L1 正文上做单点替换，
    evidence_text 就是替换后的那一行原文 → **逐字性由构造保证**，不依赖 LLM 自觉
  · 不用 AI 生成 xlsx（slot/行号契约太细，LLM 填错会让 gold 全错）；本批只产 .md
  · source 标 "external_ai"，与 benchmark 里已有的 "constructed_injection" 区分

用法：
  python3 scripts/ai/gen_process_sheet_ai.py --count 3 --out tests/fixtures/process_sheet_benchmark_ai
  python3 scripts/ai/gen_process_sheet_ai.py --count 3 --out ... --reuse   # 复用已生成的 L1 不重新调 AI
  python3 scripts/ai/gen_process_sheet_ai.py --count 3 --out ... --reuse --xlsx
      # --xlsx：生成后自动跑 tools/md_to_xlsx.py 转成平台可解析的 xlsx，
      #         并把 gold 证据口径迁移为 xlsx（与主链确定性执行器取数口径一致）
"""
import argparse, hashlib, json, re, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROMPT_A = ROOT / "工艺书提示词" / "提示词A_生成干净工艺书.md"
if not PROMPT_A.is_file():
    PROMPT_A = ROOT / "docs" / "qa" / "工艺书数据生成提示词_20261119.md"
DRIVER = ROOT / "scripts" / "ai" / "drive_local_ai.sh"

# 批次规格：行业 + 产品 + 工艺路线（确定性，便于复现）
SPECS = [
    ("烘焙", "麦香法式欧包", "原料前处理→搅拌→发酵→烘烤→冷却→包装"),
    ("烘焙", "经典白吐司", "原料前处理→搅拌→发酵→整形→烘烤→冷却→包装"),
    ("烘焙", "黄油曲奇", "原料前处理→打发→成型→烘烤→冷却→包装"),
    ("肉制品", "五香卤牛腱", "原料解冻→清洗→卤制→冷却→包装→冷藏"),
    ("肉制品", "速冻水饺", "原料前处理→拌馅→成型→速冻→包装→冷藏"),
    ("肉制品", "酱卤鸭翅", "原料解冻→腌制→卤制→冷却→包装→冷藏"),
    ("调味品", "古法酿造酱油", "原料前处理→制曲→发酵→淋油→灭菌→灌装"),
    ("调味品", "香辣牛肉酱", "原料前处理→炒制→灌装→灭菌→冷却→包装"),
    ("调味品", "酿造食醋", "原料前处理→糖化→酒精发酵→醋酸发酵→淋醋→灭菌"),
]

# 机械注入规则：(defect_type, point_code, point_name, 匹配正则, 替换函数, severity)
INJECTIONS = [
    ("数值越界", "FOOD01-001", "炒制/烹制中心温度达标",
     re.compile(r"中心温度\s*[≥>]\s*(9\d|8[5-9])\s*℃"), lambda m: m.group(0).replace(m.group(1), "78"), "高"),
    ("参数越界", "FOOD01-002", "消毒浓度与时间达标",
     re.compile(r"(\d{3})\s*ppm"), lambda m: m.group(0).replace(m.group(1), "150"), "高"),
    ("数值越界", "FOOD01-003", "冷却终温达标",
     re.compile(r"冷却[^\n]{0,12}?[≤<]\s*(10|8|6)\s*℃"), lambda m: m.group(0).replace(m.group(1), "15"), "中"),
    ("单位", "FOOD01-006", "重量与单位统一",
     re.compile(r"单[袋瓶包]净[重含]量\s*(\d+)\s*g"), lambda m: m.group(0).replace("g", "kg"), "中"),
    ("占位符", "FOOD04-001", "版本号非占位符",
     re.compile(r"版本号[：:]\s*[A-Z]{2,4}-[A-Z0-9-]{2,}"), lambda m: "版本号：X", "中"),
    ("值冲突", "FOOD01-004", "冷藏暂存温度达标",
     re.compile(r"冷藏(?:库|间)?(?:温度|暂存)[^\n]{0,10}?(\d)\s*[-~]\s*(\d)\s*℃"),
     lambda m: m.group(0).replace(m.group(1) + "-" + m.group(2), "12-18"), "高"),
]


def call_ai(workdir: Path, prompt: str, extra_files=(), timeout=600) -> str:
    cmd = [str(DRIVER), str(workdir), prompt] + [str(f) for f in extra_files]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    out = (r.stdout or "") + "\n" + (r.stderr or "")
    return out


def extract_doc(text: str) -> str:
    """从 AI 回复里抽出 <<<DOC>>>…<<<END>>> 之间的正文；没有则退回整段。"""
    m = re.search(r"<<<DOC>>>\s*(.*?)\s*<<<END>>>", text, re.S)
    body = m.group(1) if m else ""
    if not body:
        # 退化：抓从第一个 '# ' 开始到文末的 markdown
        i = text.find("\n# ")
        body = text[i:] if i >= 0 else text
    # 去掉 markdown 围栏与提示性前后缀
    body = re.sub(r"^```(?:markdown|md)?\s*", "", body.strip())
    body = re.sub(r"```\s*$", "", body.strip())
    return body.strip() + "\n"


def gen_l1(spec, idx, workdir: Path) -> dict:
    industry, product, route = spec
    prompt = (
        f"严格按附件提示词 A 生成 1 份 L1 干净工艺书。输入契约：行业={industry}；产品={product}；工艺路线={route}。\n"
        "输出要求（覆盖提示词里'写文件'的部分）：\n"
        "1) 不要写文件、不要跑命令；\n"
        "2) 把**块2 Markdown 正文**完整放在 <<<DOC>>> 与 <<<END>>> 两行标记之间；\n"
        "3) 在正文之后、<<<END>>> 之前不要加任何解释；\n"
        "4) 在标记之后再用一行 JSON 给出块1元数据（params_notes 字段必须有）。\n"
        "正文必须包含每个工序页的 `## Sheet: 工序名` 与表头四要素（实施日期/版本号/商品名/签署），"
        "并含「标准工序」表；参数落在提示词给的区间内。"
    )
    t0 = time.time()
    out = call_ai(workdir, prompt, [PROMPT_A])
    doc = extract_doc(out)
    meta = {}
    m = re.search(r"\{[^{}]*\"file_id\"[^{}]*\}", out, re.S)
    if m:
        try:
            # 抓最后一个含 file_id 的 JSON 块
            for cand in re.findall(r"\{.*?\}", out, re.S)[-6:]:
                try:
                    j = json.loads(cand)
                    if "file_id" in j:
                        meta = j
                except Exception:
                    continue
        except Exception:
            pass
    return {"idx": idx, "industry": industry, "product": product, "route": route,
            "doc": doc, "meta": meta, "seconds": round(time.time() - t0, 1), "raw_len": len(out)}


def inject(doc: str, max_inj: int = 3) -> tuple:
    """在 L1 正文上做最多 max_inj 个单点替换；返回 (注入后正文, gold 条目列表)。"""
    lines = doc.splitlines(keepends=True)
    gold, used = [], set()
    for defect_type, pcode, pname, rx, repl, sev in INJECTIONS:
        if len(gold) >= max_inj:
            break
        if pcode in used:
            continue
        for i, ln in enumerate(lines):
            m = rx.search(ln)
            if not m:
                continue
            repl_text = repl(m)
            if repl_text == m.group(0):
                continue
            new_line = ln.replace(m.group(0), repl_text, 1)   # 只替换匹配片段，保留整行
            if new_line == ln:
                continue
            clean_line = ln.rstrip("\n")
            new_clean = new_line.rstrip("\n")
            # 定位所属 Sheet
            sheet = None
            for j in range(i, -1, -1):
                sm = re.match(r"^##\s*Sheet[:：]\s*(.+)$", lines[j].strip())
                if sm:
                    sheet = sm.group(1).strip(); break
            lines[i] = new_line if new_line.endswith("\n") else new_line + "\n"
            gold.append({
                "schema_version": "gold-v1",
                "file_id": None,  # 稍后填
                "issue_id": None,
                "base_file_id": None,
                "layer": "L2",
                "industry": None,
                "point_code": pcode,
                "point_name": pname,
                "defect_type": defect_type,
                "evidence_text": new_clean.strip(),
                "clean_text": clean_line.strip(),
                "injected_text": new_clean.strip(),
                "location": {"page": None, "sheet": sheet, "row": i + 1, "col": None},
                "expected_state": "fail",
                "severity": sev,
                "source": "external_ai",
                "computable": pcode in ("FOOD01-001", "FOOD01-002", "FOOD01-003", "FOOD01-004", "FOOD01-006"),
                "issue": f"{pname}：{clean_line.strip()} → {new_clean.strip()}",
            })
            used.add(pcode)
            break
    return "".join(lines), gold


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=3)
    ap.add_argument("--out", default="tests/fixtures/process_sheet_benchmark_ai")
    ap.add_argument("--reuse", action="store_true", help="复用已有 L1（不重新调 AI）")
    ap.add_argument("--xlsx", action="store_true",
                    help="生成后调用 tools/md_to_xlsx.py 转 xlsx 并迁移 gold 证据口径")
    a = ap.parse_args()
    out = ROOT / a.out
    (out / "input").mkdir(parents=True, exist_ok=True)
    work = Path("/tmp/ai_gen_batch")
    work.mkdir(parents=True, exist_ok=True)
    specs = SPECS[: a.count]

    entries, l1_meta, l2_files = [], [], []
    for i, spec in enumerate(specs, 1):
        industry, product, _ = spec
        num = 20 + i          # 接在现有 PS-L1-20 之后
        tag = f"PS-L1-{num}"   # file_id 用 validator 认的格式
        name_l1 = f"L1_{num}_{industry}_{product}.md"
        l1 = out / "input" / name_l1
        if a.reuse and l1.is_file():
            doc = l1.read_text(encoding="utf-8")
            info = {"idx": i, "industry": industry, "product": product, "doc": doc, "meta": {}, "seconds": 0}
            print(f"[{i}/{len(specs)}] 复用 L1: {l1.name}")
        else:
            print(f"[{i}/{len(specs)}] 调本机 AI 生成 L1: {industry}/{product} …", flush=True)
            info = gen_l1(spec, i, work / f"doc{i}")
            if len(info["doc"]) < 400:
                print(f"    ⚠️ 正文过短（{len(info['doc'])} 字符），跳过该份：{info['doc'][:120]}")
                continue
            l1.write_text(info["doc"], encoding="utf-8")
            print(f"    L1 写入 {l1.name}  {len(info['doc'])} 字符  {info['seconds']}s")
        l1_meta.append(info)
        # 机械注入
        inj_doc, golds = inject(info["doc"], max_inj=3)
        l2tag = f"PS-L2-{num}"
        name_l2 = f"L2_{num}_{industry}_{product}.md"
        l2 = out / "input" / name_l2
        l2.write_text(inj_doc, encoding="utf-8")
        n = 0
        for g in golds:
            n += 1
            g.update({"file_id": l2tag, "issue_id": f"{l2tag}-G{n}", "base_file_id": tag, "industry": industry})
            entries.append(g)
        l2_files.append(l2tag)
        print(f"    注入 {len(golds)} 处 → {l2.name}")

    # 交叉校验：每条 gold 的 evidence_text 必须在注入稿里逐字出现
    bad = []
    if entries:
        for g in entries:
            _idx = g["file_id"].split("-")[-1]
            _hits = list((out / "input").glob(f"L2_{_idx}_*.md"))
            t = _hits[0].read_text(encoding="utf-8") if _hits else ""
            if g["evidence_text"] not in t:
                bad.append(g["issue_id"])
    print(f"\n逐字校验：{len(entries) - len(bad)}/{len(entries)} 通过" + (f"；失败 {bad[:5]}" if bad else ""))

    gold = {
        "schema_version": "gold-v1", "benchmark_id": "process_sheet_benchmark_ai",
        "version": "0.1.0", "created_at": time.strftime("%Y-%m-%d"),
        "nature": "AI 生成内容（本机 DuMate 内置 AI）+ 机械注入；不含企业真实工艺文件",
        "generator": "scripts/ai/gen_process_sheet_ai.py",
        "entries": entries,
        "stats": {"entries": len(entries), "l1": len(l1_meta), "l2": len(l2_files),
                  "by_point": {p: sum(1 for e in entries if e["point_code"] == p) for p in sorted({e["point_code"] for e in entries})}},
    }
    (out / "gold.json").write_text(json.dumps(gold, ensure_ascii=False, indent=1), encoding="utf-8")
    meta = {
        "benchmark_id": "process_sheet_benchmark_ai", "version": "0.1.0",
        "created_at": time.strftime("%Y-%m-%d"),
        "generator": "scripts/ai/gen_process_sheet_ai.py",
        "generation_method": "本机 AI 生成 L1 正文（提示词 A）+ 代码机械注入缺陷；gold 逐字性由构造保证",
        "nature": "AI 生成 + 机械注入；非企业真实文件；不能宣称真实客户准确率",
        "layers": {"L1": len(l1_meta), "L2": len(l2_files)},
        "docs": [{"idx": x["idx"], "industry": x["industry"], "product": x["product"],
                  "chars": len(x["doc"]), "ai_seconds": x["seconds"], "ai_meta": x.get("meta") or {}} for x in l1_meta],
    }
    (out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    if a.xlsx:
        # T-176：md → xlsx（平台食品包版式）+ gold 证据口径迁移（md 行 → xlsx 单元格）
        sys.path.insert(0, str(ROOT))
        from tools.md_to_xlsx import convert_benchmark
        conv = convert_benchmark(out, rewrite_gold=True, update_meta=True)
        print(f"xlsx: 转换 {len(conv['converted'])} 份；gold 证据迁移 "
              f"{(conv.get('gold') or {}).get('conversion', {}).get('entries_changed')} 条；"
              f"SHA256SUMS 覆盖 {len(conv.get('sha256sums') or [])} 个文件")
    else:
        # SHA256SUMS（仅 md 口径；加 --xlsx 时由 convert_benchmark 统一重算，含 xlsx）
        lines = []
        for f in sorted(list((out / "input").glob("*.md")) + [out / "gold.json", out / "meta.json"]):
            lines.append(f"{sha256(f)}  {f.relative_to(out)}")
        (out / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"产物: {out}  条目 {len(entries)}  L1 {len(l1_meta)}  L2 {len(l2_files)}")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
