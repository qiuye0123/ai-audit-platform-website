# scripts/ai —— 驱动本机 DuMate 内置 AI

**能力验证：2026-11-19 通过**（详见 `docs/qa/本机AI驱动能力验证_20261119.md`）

## 一句话

`DuMate.app` 内置 `dumate-opencode`（opencode fork），支持 `opencode run` 非交互模式。
本脚本用**独立 XDG 目录 + 复制出的 provider 凭证**驱动它，不起浏览器、不碰 DuMate 正在跑的实例。

## 能用它做什么（已验证）

| 用途 | 验证结果 |
|---|---|
| 生成数据集（按 `docs/qa/工艺书数据生成提示词_20261119.md`） | ✅ 生成 128 行 L1 工艺书 + meta.json，结构合规 |
| 缺陷注入 + gold | ✅ 3 条 gold，evidence_text 逐字；且它自己指出我们的 schema 缺 `source/clean_text` 字段（真读了校验脚本） |
| 独立复测（跑 curl/bash 验证 HTTP 行为） | ✅ 实测 8765 六路径全部 200，并如实标注"未校验响应体" |
| 代码审查 / 读仓库给意见 | ✅ 会读 `scripts/qa/*.py` 并指出契约问题 |

## 用法

```bash
# 生成（结果打印在回复里，stdout 捕获）
scripts/ai/drive_local_ai.sh /tmp/out "生成一份..." docs/qa/工艺书数据生成提示词_20261119.md

# 指定模型（默认用配置里的 glm-5；可换 deepseek）
MODEL=QianfanPersonalQuota/deepseek-v41-flash scripts/ai/drive_local_ai.sh ...
```

## 已知限制（必须知道）

1. **权限不完全放开**：`permission=allow` 在 DuMate 的 inapp 层只部分生效，写文件/个别工具调用仍可能被 `user_rejected`。
   **可靠模式**：让 AI 把结果打印在回复里，我们自己落盘。
2. **不是完全独立的第三方**：它和 DuMate 用同一套模型供应商（千帆），不算外部独立评测；只能算"另一个会话"。
3. **共享配额**：消耗的是本机登录的千帆个人额度。
4. **不能点 UI**：没有浏览器自动化（除非另行接 CDP）。UI 级复测仍需人工或 Playwright/CDP。
5. **不驱动可见聊天窗口**：开的是新的 headless 会话；要驱动那个窗口需要 inappkey（DuMate 内部鉴权，不做绕过）。
