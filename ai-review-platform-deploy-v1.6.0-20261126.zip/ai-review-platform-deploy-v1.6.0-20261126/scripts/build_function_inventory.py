# -*- coding: utf-8 -*-
"""从功能数据生成产品功能清单：详细版（多 sheet）+ 汇总版（单 sheet）。"""
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(HERE, "docs", "product")
os.makedirs(OUT, exist_ok=True)

# 端 / 模块 / 功能点 / 简述 / 状态
F = []
def add(端, 模块, 功能点, 简述, 状态="已实现"):
    F.append({"端": 端, "模块": 模块, "功能点": 功能点, "简述": 简述, "状态": 状态})

# 审核员端
add("审核员", "我的工作台", "我的任务", "待复核/进行中/已完成，含待复核计数")
add("审核员", "我的工作台", "个人统计", "审核数量/严重/一般/复核率", "待实现")
add("审核员", "审核", "上传文档", "xlsx/docx/pdf（类型/大小/严格base64校验）")
add("审核员", "审核", "单文件审核", "确定性规则 + R4 语义判断")
add("审核员", "审核", "多文件审核", "一次案例挂多文档")
add("审核员", "审核", "对比审核", "原版 vs 新版：新增/已解决/未变")
add("审核员", "审核", "结果分级", "严重/一般（确定/一般/疑似）")
add("审核员", "审核", "证据定位", "锚点→原文高亮（问题单元格着色）")
add("审核员", "审核", "五态覆盖统计", "应检/完成/证据不足/执行失败")
add("审核员", "人工复核", "四选一复核", "确认/误报/补证/转专家")
add("审核员", "人工复核", "AI 语义提示", "成立/不成立/需人工 + 置信度")
add("审核员", "人工复核", "历史误报提示", "⚠ 历史误报 N 次")
add("审核员", "人工复核", "反馈回写", "触发规则进化信号")
add("审核员", "报告", "查看报告", "结论/发现/标准对照/复核/签名")
add("审核员", "报告", "导出", "DOCX/HTML/PDF")
add("审核员", "通知", "站内通知", "铃铛 + 未读角标 + 点击已读")
add("审核员", "规则查阅", "只读规则库", "分类/R0-R4/状态/命中/健康")
add("审核员", "规则查阅", "为什么这么判", "条件 + 命中证据")
add("审核员", "规则查阅", "命中趋势", "每次审核命中序列")
add("审核员", "规则查阅", "标准对照", "工艺要点 vs 工艺书，三态")
add("审核员", "规则查阅", "冲突三态", "规则-规则冲突结果")

# 管理员端
add("管理员", "规则管理", "规则库列表", "分类/执行级/状态/命中/override/健康度")
add("管理员", "规则管理", "规则详情", "四维 schema + 条件 + 版本 + 命中 + 趋势")
add("管理员", "规则管理", "新建-模板", "10 类条款模板（限值/齐套/记录/一致性…）")
add("管理员", "规则管理", "新建-自然语言", "LLM 槽位填充 + 确定性兜底")
add("管理员", "规则管理", "新建-人工表单", "指标/比较符/值/单位")
add("管理员", "规则管理", "新建-标准导入", "PDF 限值抽取 → 规则草稿")
add("管理员", "规则管理", "规则测试", "正例/反例/边界跑批")
add("管理员", "规则管理", "生命周期", "草稿→待审批→发布→回滚→下线（审计留痕）")
add("管理员", "规则管理", "冲突检测", "三态：已证明/未发现/无法判定")
add("管理员", "标准知识库", "企业标准库", "PDF 上传/版本/生效日期/状态")
add("管理员", "标准知识库", "限值抽取", "理化指标 ≤ 值 单位")
add("管理员", "标准知识库", "限值沉淀", "标准 → 规则草稿一键入库")
add("管理员", "标准知识库", "工艺要点维护", "检查清单")
add("管理员", "本体", "本体模型", "对象类型/实例/别名/链接")
add("管理员", "本体", "实体消歧", "canonical_id 别名归一")
add("管理员", "本体", "链接闭环", "半成品--produced_by-->工序")
add("管理员", "本体", "健康度", "孤岛实例/悬空链接/评分")
add("管理员", "用户权限", "用户管理", "增删改查/启停用")
add("管理员", "用户权限", "角色", "管理员/审核员/质量总监/规则管理员/法规顾问")
add("管理员", "用户权限", "双身份鉴权", "登录后使用，接口级 401/403")
add("管理员", "用户权限", "SSO", "OIDC 授权码流 + JWT 会话")
add("管理员", "评测质量", "评测集", "黄金 + 合成负向用例")
add("管理员", "评测质量", "多用例评测", "P/R/证据定位覆盖率")
add("管理员", "评测质量", "回归门禁", "零漏检统计上界")
add("管理员", "评测质量", "负例沉淀", "误报 → 负例库")
add("管理员", "审计", "审计日志", "谁/何时/做什么/前后值/rid/IP")
add("管理员", "审计", "事件回放", "重建时间线，不重跑引擎")
add("管理员", "审计", "版本不可变", "发布门禁 + 运行台账")
add("管理员", "看板", "系统看板", "规则/案例/发现/冲突/复核/override")
add("管理员", "看板", "规则进化", "命中/误报/override/修订建议")
add("管理员", "看板", "错误书", "误报案例 + 证据 + 理由")
add("管理员", "看板", "命中趋势", "规则命中时间序列")
add("管理员", "系统配置", "模型网关", "语义判断 provider（不默认 Jev）")
add("管理员", "系统配置", "OCR", "扫描件 OCR 挂载点")
add("管理员", "系统配置", "上传限制", "类型/大小/严格 base64")
add("管理员", "系统配置", "告警阈值", "override 率超阈值告警（可配置）")
add("管理员", "本体", "本体编辑", "新增实体/别名/链接，即时重载")

# 业务域能力
D = [
    ("规则沉淀", "10 类模板 + NL/表单/标准导入，发布后不可改"),
    ("规则执行", "解析→事实→规则注册表→五态→锚点，确定性优先"),
    ("规则进化", "人工复核→错误书→负例库→修订建议"),
    ("规则冲突", "规则-规则三态 + 规则-事实三态"),
    ("可解释", "为什么这么判 + 证据锚点 + 命中趋势"),
    ("本体", "实体消歧 + 链接闭环（不用 OWL/SHACL）"),
    ("审计", "日志 + 回放 + 版本不可变"),
    ("评测", "多用例 + 门禁 + 负例沉淀"),
]

# 主要接口
APIS = [
    ("POST", "/api/v1/reviews", "跑审核（幂等键）"),
    ("POST", "/api/v1/upload", "上传审核（base64）"),
    ("POST", "/api/v1/findings/{id}/decision", "人工复核"),
    ("GET", "/api/v1/rules", "规则列表（分页）"),
    ("GET", "/api/v1/rules/{id}", "规则详情"),
    ("GET", "/api/v1/rules/{id}/explain", "可解释"),
    ("POST", "/api/v1/rules/{id}/submit|approve|rollback|archive", "规则生命周期"),
    ("POST", "/api/v1/sediment", "标准导入沉淀"),
    ("GET", "/api/v1/ontology", "本体视图"),
    ("GET", "/api/v1/conflicts", "冲突三态"),
    ("GET", "/api/v1/eval|/eval/multi", "评测"),
    ("GET", "/api/v1/dashboard|/audit/{id}|/trend/{code}", "看板/审计/趋势"),
    ("GET", "/api/v1/errorbook|/evolution", "错误书/进化"),
    ("GET", "/api/v1/reviews/{id}/report.docx|.pdf|.html", "报告导出"),
    ("GET", "/login /callback /api/v1/me", "OIDC 登录/会话"),
]

# 数据字典（26 表摘要）
TABLES = [
    ("org/plant/department", "组织/工厂/部门"),
    ("role/user/user_role", "角色/用户/用户-角色"),
    ("template/template_field", "条款模板/模板字段"),
    ("rule/rule_version", "规则/规则版本"),
    ("document/anchor", "文档/证据锚点"),
    ("audit_case/case_document", "审核案例/案例-文档"),
    ("finding/evidence/decision", "发现/证据/复核决策"),
    ("report", "报告"),
    ("agent/agent_version/agent_run", "智能体/版本/运行"),
    ("eval_set/eval_run", "评测集/评测运行"),
    ("audit_log", "审计日志"),
    ("conflict", "冲突"),
    ("rule_snapshot", "规则命中快照"),
]

# 边界与约定
BOUND = [
    ("产品只输出差异/缺口/待人工确认，不下合规/不合规结论"),
    ("不默认接 Jev（校准路由/选择性预测+弃权需实验证明）"),
    ("本体用实体字典+canonical_id，不用 OWL/SHACL"),
    ("规则版本不可变，发布后改则新版本"),
    ("密钥不进仓库，.env 现场填写"),
    ("内置 mock IdP 仅联调，生产接真实 IdP"),
]

hdr_fill = PatternFill("solid", fgColor="3370FF")
hdr_font = Font(color="FFFFFF", bold=True)

def style_header(ws, row=1):
    for c in ws[row]:
        c.fill = hdr_fill; c.font = hdr_font; c.alignment = Alignment(horizontal="center")

# ===== 汇总版 =====
wb = Workbook(); ws = wb.active; ws.title = "功能清单"
ws.append(["端", "模块", "功能点", "简述", "状态"])
for f in F:
    ws.append([f["端"], f["模块"], f["功能点"], f["简述"], f["状态"]])
style_header(ws)
for col, w in zip("ABCDE", [10, 14, 20, 46, 10]):
    ws.column_dimensions[col].width = w
ws.freeze_panes = "A2"
ws.auto_filter.ref = f"A1:E{len(F)+1}"
wb.save(os.path.join(OUT, "AI审核平台_产品功能清单_汇总版_v1.0.xlsx"))

# ===== 详细版 =====
wb = Workbook()
def sheet(name, header, rows):
    s = wb.create_sheet(name); s.append(header)
    for r in rows: s.append(r)
    style_header(s)
    return s

s0 = wb.active; s0.title = "说明"
for line in [
    ["AI 审核平台 · 产品功能清单 v1.0"],
    ["生成：2026-11-09"],
    ["用途：需求评审与实施对齐；状态=已实现/待实现。"],
    ["端：审核员端 / 管理员端。"],
]: s0.append(line)

sheet("功能清单", ["端", "模块", "功能点", "简述", "状态"], [[f["端"], f["模块"], f["功能点"], f["简述"], f["状态"]] for f in F])
sheet("审核员端", ["模块", "功能点", "简述", "状态"], [[f["模块"], f["功能点"], f["简述"], f["状态"]] for f in F if f["端"] == "审核员"])
sheet("管理员端", ["模块", "功能点", "简述", "状态"], [[f["模块"], f["功能点"], f["简述"], f["状态"]] for f in F if f["端"] == "管理员"])
sheet("业务域能力", ["能力", "说明"], D)
sheet("主要接口", ["方法", "路径", "说明"], APIS)
sheet("数据字典", ["表", "用途"], TABLES)
sheet("边界与约定", ["约定"], [[b] for b in BOUND])
wb.save(os.path.join(OUT, "AI审核平台_产品功能清单_详细版_v1.0.xlsx"))

print("生成完成：")
print("  汇总版:", os.path.join(OUT, "AI审核平台_产品功能清单_汇总版_v1.0.xlsx"), f"({len(F)} 条)")
print("  详细版:", os.path.join(OUT, "AI审核平台_产品功能清单_详细版_v1.0.xlsx"))
