#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# scripts/ci/pipeline.sh — 交付 CI 流水线（T-196 Phase A 新增）
#
# 串成一条可执行的 tag→发布链（当前仓库只有零散脚本，无 .github/.gitlab-ci 定义）：
#   [1] tag 校验      git tag 存在且与 VERSION/包名一致（v<version>-<date>-build<N>）
#   [2] 全量门禁      scripts/qa/gate.py --json /private/tmp/gate_final_20261118.json
#                     （build 脚本硬编码读这个 JSON + /tmp/gate_rerun_20261118.log）
#   [3] 构建交付包    dist/build_final_package_20261118.py（写 dist/，仅在 --run 时执行）
#   [4] 包验证        dist/validate_final_package_20261118.py（68 项，写 dist/验收证据）
#   [5] 交付包 CI     scripts/qa/package_ci.py --zip <zip>（解压→seed→起服→5 账号→UI 冒烟）
#   [6] SHA256 清单   zip sidecar 校验 + /tmp/ci_artifacts/SHA256SUMS_<tag>.txt
#
# T-201 新增 --security 阶段（SCA/SAST 阈值门禁，可单独跑）：
#   [S] 安全扫描      scripts/qa/dependency_scan.py（pip-audit SCA + bandit SAST）
#                     + 直接 bandit 逐规则阈值判定（默认 HIGH 未白名单必须 0、
#                       MEDIUM 未白名单必须 0；白名单 scripts/ci/security_allowlist.json）
#                     结果写 <art-dir>/security_gate.json + dependency_scan.json + bandit.json
#                     dry-run 也会真实执行本阶段（本地可复核）；--security-only 只跑本阶段。
#
# 安全默认：**默认 dry-run**（只打印命令 + 跑前置检查，不写 dist/、不跑 18 分钟 gate）。
#          真正执行必须显式 --run（会写 dist/、耗时约 20+ 分钟）。
#
# 铁律 6：脚本第一段断言 RULEPROOF_DB 必须指向 /tmp 临时库，否则拒绝运行
#         （本脚本启动 gate/包 CI 子进程时继承；gate 自带 _isolate() 每项独立 /tmp 库）。
#
# 用法：
#   bash scripts/ci/pipeline.sh                 # dry-run：前置检查 + 打印 6 步
#   bash scripts/ci/pipeline.sh --tag v1.5.0-20261118-build16
#   bash scripts/ci/pipeline.sh --run           # 真跑（警告：写 dist/、约 20+ 分钟）
#   bash scripts/ci/pipeline.sh --security      # dry-run + 真实执行 SCA/SAST 阈值门禁
#   bash scripts/ci/pipeline.sh --security-only # 只跑安全阶段（CI 用；exit 码即安全结论）
#   bash scripts/ci/pipeline.sh --out /tmp/eng_audit/ci_pipeline.json
#
# 安全阈值 env（CI 可覆盖）：CI_SEC_HIGH_MAX（默认 0）、CI_SEC_MEDIUM_MAX（默认 0）、
#   CI_SEC_SCA_REQUIRE（默认 1=requirements 漏洞必须 0）、CI_SEC_QUICK（1=跳过 bandit）、
#   CI_SEC_ALLOWLIST（白名单 JSON 路径，默认 scripts/ci/security_allowlist.json）。
#
# 退出码：0=dry-run 前置全部通过 / --run 全步骤成功；1=有步骤失败；2=前置失败（不伪造通过）
set -euo pipefail

# ---------------------------------------------------------------- 铁律 6（第一段）
_CI_DB="${RULEPROOF_DB:-/tmp/eng_audit/ci_pipeline/fixture.db}"
case "$_CI_DB" in
  /tmp/*|/private/tmp/*|/private/var/folders/*|/var/folders/*) : ;;
  *)
    echo "拒绝运行：RULEPROOF_DB 指向非临时库（${_CI_DB}）。" >&2
    echo "CI 只允许 /tmp 下的库；产品库 data/ruleproof.db 不得被流水线写入。" >&2
    exit 2
    ;;
esac
export RULEPROOF_DB="$_CI_DB"
export RULEPROOF_PASSWORD_ENFORCE="${RULEPROOF_PASSWORD_ENFORCE:-0}"
export RULEPROOF_LLM_ENABLED="${RULEPROOF_LLM_ENABLED:-0}"

HERE="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$HERE"
PY=/Users/a1/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/bin/python3
[ -x "$PY" ] || PY="$(command -v python3)"
GATE_JSON="/private/tmp/gate_final_20261118.json"
GATE_LOG="/tmp/gate_rerun_20261118.log"
ZIP="dist/AI审核平台-v1.5.0-20261118-完整交付版.zip"
ZIP_SHA_FILE="$ZIP.sha256"
BUILD_PY="dist/build_final_package_20261118.py"
VALIDATE_PY="dist/validate_final_package_20261118.py"
PACKAGE_CI="scripts/qa/package_ci.py"
GATE_PY="scripts/qa/gate.py"
OUT="/tmp/eng_audit/ci_pipeline.json"
MODE="dry-run"
TAG=""
ART_DIR="/tmp/ci_artifacts"
SEC=0
SEC_ONLY=0
SEC_OUT=""
SEC_QUICK="${CI_SEC_QUICK:-0}"
SEC_ALLOWLIST="${CI_SEC_ALLOWLIST:-scripts/ci/security_allowlist.json}"

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) MODE="dry-run" ;;
    --run) MODE="run" ;;
    --tag) shift; TAG="${1:-}" ;;
    --tag=*) TAG="${1#--tag=}" ;;
    --out) shift; OUT="${1:-}" ;;
    --out=*) OUT="${1#--out=}" ;;
    --art-dir) shift; ART_DIR="${1:-}" ;;
    --art-dir=*) ART_DIR="${1#--art-dir=}" ;;
    --security) SEC=1 ;;
    --security-only) SEC=1; SEC_ONLY=1 ;;
    --security-quick) SEC=1; SEC_QUICK=1 ;;
    --security-quick-only) SEC=1; SEC_ONLY=1; SEC_QUICK=1 ;;
    --security-out) shift; SEC_OUT="${1:-}" ;;
    --security-out=*) SEC_OUT="${1#--security-out=}" ;;
    --security-allowlist) shift; SEC_ALLOWLIST="${1:-}" ;;
    --security-allowlist=*) SEC_ALLOWLIST="${1#--security-allowlist=}" ;;
    --help|-h)
      sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "未知参数：$1（--help 查看用法）" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$(dirname "$OUT")" "$ART_DIR"
PASS=0; FAIL=0; WARN=0; STEPS_JSON="[]"; WARNINGS=""
STEPS_JSON_FILE="$ART_DIR/.steps.$$"

precheck() {  # precheck <name> <0|1> <detail>
  if [ "$2" = "0" ]; then
    PASS=$((PASS+1)); printf '  [PRECHECK PASS] %s%s\n' "$1" "${3:+ — $3}"
  else
    FAIL=$((FAIL+1)); printf '  [PRECHECK FAIL] %s — %s\n' "$1" "${3:-}"
  fi
}
warn() { WARN=$((WARN+1)); WARNINGS="${WARNINGS}$1; "; printf '  [PRECHECK WARN] %s — %s\n' "$1" "${2:-}"; }

# ------------------------------------------------------------------ 0) 前置检查
# ------------------------------------------------------------------ 安全阶段（T-201）
run_security() {
  local sec_out="${SEC_OUT:-$ART_DIR}"
  mkdir -p "$sec_out" "$ART_DIR"
  local dep_json="$sec_out/dependency_scan.json"
  local bandit_json="$sec_out/bandit.json"
  local gate_json="$sec_out/security_gate.json"
  local allowlist="$SEC_ALLOWLIST"
  [ -f "$allowlist" ] || allowlist="$(pwd)/scripts/ci/security_allowlist.json"
  local quick_arg=""
  [ "$SEC_QUICK" = "1" ] && quick_arg="--quick"
  say ""
  say "== [SECURITY] SCA（dependency_scan.py）+ SAST（bandit）阈值门禁 =="
  say "  阈值：HIGH 未白名单 ≤ ${CI_SEC_HIGH_MAX:-0}；MEDIUM 未白名单 ≤ ${CI_SEC_MEDIUM_MAX:-0}；SCA requirements 漏洞必须为 0，否则 FAIL"
  say "  白名单：$allowlist"
  local dep_rc=0
  set +e
  "$PY" scripts/qa/dependency_scan.py $quick_arg --out "$dep_json" > "$sec_out/dependency_scan.log" 2>&1
  dep_rc=$?
  rm -f "$bandit_json"
  if [ "$SEC_QUICK" != "1" ] && "$PY" -c "import bandit" >/dev/null 2>&1; then
    "$PY" -m bandit -r app -f json -q -o "$bandit_json" > "$sec_out/bandit.log" 2>&1 || true
  fi
  set -e
  set +e
  "$PY" - "$sec_out" "$dep_json" "$dep_rc" "$bandit_json" "$allowlist" \
    "${CI_SEC_HIGH_MAX:-0}" "${CI_SEC_MEDIUM_MAX:-0}" "${CI_SEC_SCA_REQUIRE:-1}" \
    "$SEC_QUICK" <<'PYEOF'
import collections
import json
import os
import sys
import time

(sec_out, dep_path, dep_rc, bandit_path, allow_path,
 high_max, med_max, sca_require, quick) = sys.argv[1:10]
high_max, med_max = int(float(high_max)), int(float(med_max))
sca_require, quick, dep_rc = int(float(sca_require)), int(float(quick)), int(dep_rc)
gate_path = os.path.join(sec_out, "security_gate.json")

dep = {}
if os.path.isfile(dep_path):
    try:
        dep = json.load(open(dep_path, encoding="utf-8"))
    except Exception:
        dep = {"__parse_error__": dep_path}
summary = dep.get("summary") or {}
sca = dep.get("sca") or {}
sast_dep = dep.get("sast") or {}

allow = {}
if os.path.isfile(allow_path):
    try:
        allow = json.load(open(allow_path, encoding="utf-8"))
    except Exception:
        allow = {}
allow_high = set((allow.get("high_allowlist") or {}).keys())
allow_medium = set((allow.get("medium_allowlist") or {}).keys())

results = []
bandit_available = False
if not quick and os.path.isfile(bandit_path):
    try:
        bdoc = json.load(open(bandit_path, encoding="utf-8"))
        results = bdoc.get("results") or []
        bandit_available = True
    except Exception:
        results = []
high_by_rule = collections.Counter()
med_by_rule = collections.Counter()
low_by_rule = collections.Counter()
for it in results:
    sev = str(it.get("issue_severity") or "").upper()
    tid = str(it.get("test_id") or "")
    if sev == "HIGH":
        high_by_rule[tid] += 1
    elif sev == "MEDIUM":
        med_by_rule[tid] += 1
    elif sev == "LOW":
        low_by_rule[tid] += 1
high_unallow = {k: v for k, v in high_by_rule.items() if k not in allow_high}
med_unallow = {k: v for k, v in med_by_rule.items() if k not in allow_medium}
high_ok = sum(high_unallow.values()) <= high_max
med_ok = sum(med_unallow.values()) <= med_max
req_vulns = int(summary.get("requirements_vuln_count") or 0)
inst_vulns = int(summary.get("installed_env_vuln_count") or 0)
sca_ok = (req_vulns == 0) or not sca_require
tools_ok = bool(bandit_available) and (sast_dep.get("status") == "OK")
dep_ok = (dep_rc == 0 and bool(summary))
fail_reasons = []
if not dep_ok:
    fail_reasons.append("dependency_scan.py 未产出有效报告（rc=%s）" % dep_rc)
if not sca_ok:
    fail_reasons.append("SCA：requirements 口径存在 %d 个漏洞（要求 0）" % req_vulns)
if not high_ok:
    fail_reasons.append("SAST：HIGH 未白名单 %d 处（允许 %d）：%s"
                        % (sum(high_unallow.values()), high_max,
                           ",".join(sorted(high_unallow)) or "-"))
if not med_ok:
    fail_reasons.append("SAST：MEDIUM 未白名单 %d 处（允许 %d）：%s"
                        % (sum(med_unallow.values()), med_max,
                           ",".join(sorted(med_unallow)) or "-"))
warn_reasons = []
if inst_vulns > 0:
    warn_reasons.append("SCA：已安装环境存在漏洞（%d 处，包：%s），只报 WARN 不阻断 release"
                        % (inst_vulns, ",".join(summary.get("installed_env_vuln_packages") or [])))
if quick:
    warn_reasons.append("CI_SEC_QUICK=1：本轮跳过 bandit（SAST 未覆盖，不等于无问题）")
elif not bandit_available:
    warn_reasons.append("bandit 不可用：SAST 未覆盖（不得当作 PASS）")
if summary.get("static_p1_findings"):
    fail_reasons.append("SCA：requirements 静态核对 P1 项 %s 个"
                        % summary.get("static_p1_findings"))
status = "FAIL" if fail_reasons else ("PASS_WITH_WARN" if warn_reasons else "PASS")
gate = {
    "task": "T-201 / CI SCA+SAST 安全阈值门禁",
    "at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "status": status,
    "thresholds": {"high_unallowlisted_max": high_max,
                   "medium_unallowlisted_max": med_max,
                   "sca_requirements_vulns_max": 0 if sca_require else None},
    "bandit_available": bandit_available,
    "sast": {
        "high_by_rule": dict(sorted(high_by_rule.items())),
        "high_allowlisted_rules": sorted(allow_high),
        "high_unallowlisted": high_unallow,
        "medium_by_rule": dict(sorted(med_by_rule.items())),
        "medium_allowlisted_rules": sorted(allow_medium),
        "medium_unallowlisted": med_unallow,
        "low_by_rule": dict(sorted(low_by_rule.items())),
        "low_count": sum(low_by_rule.values()),
    },
    "sca": {"status": summary.get("status"),
            "tool": (sca.get("tool") or ""),
            "requirements_vuln_count": req_vulns,
            "installed_env_vuln_count": inst_vulns,
            "installed_env_vuln_packages": summary.get("installed_env_vuln_packages") or [],
            "static_p1_findings": summary.get("static_p1_findings"),
            "static_p2_findings": summary.get("static_p2_findings")},
    "allowlist": os.path.abspath(allow_path),
    "quick": bool(quick),
    "reports": {"dependency_scan": os.path.abspath(dep_path),
                "bandit": os.path.abspath(bandit_path),
                "security_gate": gate_path},
    "fail_reasons": fail_reasons,
    "warn_reasons": warn_reasons,
}
open(gate_path, "w", encoding="utf-8").write(json.dumps(gate, ensure_ascii=False, indent=1))
print("  [SECURITY] SCA：%s（requirements_vuln=%d，installed_env_vuln=%d，static_p1=%s）"
      % (summary.get("status") or "UNKNOWN", req_vulns, inst_vulns,
         summary.get("static_p1_findings")))
print("  [SECURITY] SAST：bandit=%s HIGH=%d（白名单规则 %s，未白名单 %d）/ "
      "MEDIUM=%d（白名单 %d，未白名单 %d）/ LOW=%d"
      % ("available" if bandit_available else "unavailable",
         sum(high_by_rule.values()), ",".join(sorted(allow_high)) or "-",
         sum(high_unallow.values()), sum(med_by_rule.values()),
         sum(v for k, v in med_by_rule.items() if k in allow_medium),
         sum(med_unallow.values()), sum(low_by_rule.values())))
for w in warn_reasons:
    print("  [SECURITY WARN] %s" % w)
for f in fail_reasons:
    print("  [SECURITY FAIL] %s" % f)
print("  [SECURITY %s] 结论：%s（机读：%s）" % (status, status, gate_path))
if status == "FAIL":
    raise SystemExit(1)
PYEOF
  local rc=$?
  set -e
  [ "$rc" = "0" ] && return 0
  say "  安全阶段失败（rc=${rc}），见 $sec_out/security_gate.json"
  return "$rc"
}

say() { printf '%s\n' "$*"; }
say "== 交付 CI 流水线（模式：${MODE}） =="
say "仓库：$HERE"
say "临时库：$RULEPROOF_DB"

[ -f "$GATE_PY" ] && precheck "全量门禁脚本存在" 0 "$GATE_PY" || precheck "全量门禁脚本存在" 1 "$GATE_PY"
[ -f "$BUILD_PY" ] && precheck "打包脚本存在" 0 "$BUILD_PY" || precheck "打包脚本存在" 1 "$BUILD_PY"
[ -f "$VALIDATE_PY" ] && precheck "包验证脚本存在" 0 "$VALIDATE_PY" || precheck "包验证脚本存在" 1 "$VALIDATE_PY"
[ -f "$PACKAGE_CI" ] && precheck "交付包 CI 脚本存在" 0 "$PACKAGE_CI" || precheck "交付包 CI 脚本存在" 1 "$PACKAGE_CI"
[ -f VERSION ] && precheck "VERSION 存在" 0 "VERSION=$(cat VERSION 2>/dev/null || true)" || precheck "VERSION 存在" 1
command -v unzip >/dev/null 2>&1 && precheck "unzip 可用" 0 "$(unzip -v 2>/dev/null | head -1)" || precheck "unzip 可用" 1
[ -d .git ] && precheck "git 仓库存在（tag 校验依赖）" 0 || precheck "git 仓库存在（tag 校验依赖）" 1

VERSION_TXT="$(cat VERSION 2>/dev/null || echo '')"
GATE_REGISTERED="$("$PY" "$GATE_PY" --list 2>/dev/null | grep -c . || true)"
VALIDATE_EXPECTED_TOTAL="$(grep -oE 'SKIP [0-9]+ / [0-9]+' "$VALIDATE_PY" 2>/dev/null | head -1 | grep -oE '/ [0-9]+' | tr -d '/ ' || true)"
say "  gate 注册门禁数（源码模式）：${GATE_REGISTERED:-未知}"
say "  validate 脚本冻结期望门禁总数：${VALIDATE_EXPECTED_TOTAL:-未知}"
if [ -n "$VALIDATE_EXPECTED_TOTAL" ] && [ "$VALIDATE_EXPECTED_TOTAL" != "$GATE_REGISTERED" ]; then
  warn "gate 数量与 build16 冻结口径不一致" \
    "当前注册 ${GATE_REGISTERED} 项，validate 期望 ${VALIDATE_EXPECTED_TOTAL} 项；--run 会在 [4] 包验证 失败（需 Phase B 更新 validate/重建基线或回到 build16 提交）"
fi

# tag 校验
if [ -z "$TAG" ]; then
  TAG="$(git describe --tags --exact-match 2>/dev/null || true)"
fi
say "  tag：${TAG:-（未指定且 HEAD 无精确 tag）}"
if [ -n "$TAG" ]; then
  if git rev-parse -q --verify "refs/tags/$TAG" >/dev/null 2>&1; then
    precheck "tag 存在：$TAG" 0 "$(git log -1 --format='%h %s' "$TAG" 2>/dev/null | cut -c1-100)"
  else
    precheck "tag 存在：$TAG" 1 "git tag 未找到"
  fi
  case "$TAG" in
    "v${VERSION_TXT}-"*) precheck "tag 与 VERSION 一致（${VERSION_TXT}）" 0 ;;
    *) precheck "tag 与 VERSION 一致（${VERSION_TXT}）" 1 "$TAG 前缀应为 v${VERSION_TXT}-" ;;
  esac
  case "$TAG" in
    v*-*-build[0-9]*) precheck "tag 命名符合 v<version>-<date>-build<N>" 0 ;;
    *) warn "tag 命名不符合 v<version>-<date>-build<N>" "$TAG" ;;
  esac
else
  warn "未提供 tag" "发布流水线需 --tag vX.Y.Z-YYYYMMDD-buildN 才能保证可追溯"
fi

# zip/sidecar（[5] 需要）
if [ -f "$ZIP" ]; then
  ACT_SHA="$(shasum -a 256 "$ZIP" | cut -d' ' -f1)"
  precheck "交付 zip 存在" 0 "${ZIP}（sha256=${ACT_SHA:0:16}…）"
  if [ -f "$ZIP_SHA_FILE" ]; then
    REC_SHA="$(cut -d' ' -f1 "$ZIP_SHA_FILE")"
    if [ "$REC_SHA" = "$ACT_SHA" ]; then
      precheck "zip 与 sidecar SHA256 一致" 0
    else
      precheck "zip 与 sidecar SHA256 一致" 1 "sidecar=$REC_SHA actual=$ACT_SHA"
    fi
  else
    warn "zip sidecar 不存在" "${ZIP_SHA_FILE}（[6] 会生成）"
  fi
else
  warn "交付 zip 不存在" "${ZIP}（[3] 构建后产生；dry-run 不要求）"
fi

# ------------------------------------------------------------------ 安全阶段（--security-only 早退）
# 只跑安全阶段：不依赖 dist/、不跑全量 gate，退出码就是安全结论（供 CI 单独 step 使用）。
if [ "$SEC_ONLY" = "1" ]; then
  set +e
  run_security
  SEC_RC=$?
  set -e
  say ""
  say "security-only 完成：rc=${SEC_RC}（机读：${SEC_OUT:-$ART_DIR}/security_gate.json）"
  exit "$SEC_RC"
fi

# ------------------------------------------------------------------ 1-6 步骤定义
step_line() { printf '  [STEP %s] %-16s %s\n' "$1" "$2" "${3:-}"; }

STEPS_DEF=(
  "tag|tag 校验（tag 存在 + 与 VERSION/包名一致）|git describe --tags --exact-match；tag 缺失时报错（--run）"
  "gate|全量 gate（gate.py --list 计数见前，约 17-20 分钟）|$PY $GATE_PY --json $GATE_JSON 2>&1 | tee $GATE_LOG"
  "build|构建交付包（写 dist/）|$PY $BUILD_PY"
  "validate|包验证 68 项（写 dist/验收证据_20261118/）|$PY $VALIDATE_PY"
  "package_ci|交付包 CI（解压→seed→起服→5 账号→UI 冒烟）|$PY $PACKAGE_CI --zip $ZIP"
  "sha256|SHA256 清单（zip 实测 + sidecar 校验 + 制品清单）|shasum -a 256 $ZIP > $ART_DIR/SHA256SUMS_<tag>.txt"
)
# T-201：--security 时在机读步骤表最前插入安全阶段（真实执行顺序也是先安全后 gate）
if [ "$SEC" = "1" ]; then
  STEPS_DEF=("security|SCA+SAST 安全阈值（HIGH/MEDIUM 白名单）|bash scripts/ci/pipeline.sh --security-only --art-dir $ART_DIR" "${STEPS_DEF[@]}")
fi

say ""
say "流水线步骤："
STEP_IDX=0
for def in "${STEPS_DEF[@]}"; do
  STEP_IDX=$((STEP_IDX + 1))
  IFS='|' read -r sid name cmd <<< "$def"
  step_line "$STEP_IDX" "$name" "$cmd"
  # 关键前置：每个步骤的输入存在性
  case "$sid" in
    gate) [ -x "$PY" ] || [ -n "$(command -v "$PY")" ] ;;
    build) [ -f "$GATE_JSON" ] || warn "build 前置缺 gate JSON" "${GATE_JSON}（[2] 产出）" ;;
    validate) [ -f "$ZIP" ] || warn "validate 前置缺 zip" "${ZIP}（[3] 产出）" ;;
    package_ci) [ -s "$ZIP" ] && precheck "[5] 前置 zip 存在" 0 || warn "[5] 前置 zip 不存在" "先跑 [3]" ;;
    sha256) : ;;
  esac
done

# 记录 dry-run 是否触碰 dist/（dry-run 只读）
DIST_SHA_BEFORE=""
[ -f "$ZIP" ] && DIST_SHA_BEFORE="$(shasum -a 256 "$ZIP" | cut -d' ' -f1)"

if [ "$MODE" = "run" ]; then
  say ""
  say "!! --run：将写 dist/ 并执行全量 gate（预计 20+ 分钟）、会覆盖 dist 交付包 !!"
  if [ "$FAIL" -gt 0 ]; then
    say "前置检查有 FAIL，拒绝真跑（先修复上面 [PRECHECK FAIL]）"
    exit 2
  fi
  RUN_ID="$(date '+%Y%m%d-%H%M%S')"
  CI_LOG="$ART_DIR/ci_run_$RUN_ID.log"
  : > "$CI_LOG"
  STEP_N=0
  run_step() {  # run_step <name> <cmd...>  → 0 成功 / 非 0 失败（失败不退出，由调用方处理）
    STEP_N=$((STEP_N + 1))
    local sname="$1"; shift
    say ""
    say "== [STEP $STEP_N] $sname =="
    local t0 t1 rc
    t0=$(date +%s)
    set +e
    "$@" 2>&1 | tee -a "$CI_LOG"
    rc=${PIPESTATUS[0]}
    set -e
    t1=$(date +%s)
    if [ "$rc" = "0" ]; then
      PASS=$((PASS + 1))
      printf '  [STEP PASS] %s（%ss）\n' "$sname" "$((t1 - t0))" | tee -a "$CI_LOG"
      return 0
    fi
    FAIL=$((FAIL + 1))
    printf '  [STEP FAIL] %s（rc=%s，%ss）\n' "$sname" "$rc" "$((t1 - t0))" | tee -a "$CI_LOG"
    say "流水线中止：$sname 失败"
    return "$rc"
  }
  RUN_RC=0
  SEC_RC=0
  if [ "$SEC" = "1" ]; then
    run_step "SCA+SAST 安全阶段" run_security || { RUN_RC=$?; SEC_RC=$RUN_RC; }
  fi
  if [ "$RUN_RC" = "0" ]; then
    run_step "全量 gate" "$PY" "$GATE_PY" --json "$GATE_JSON" || RUN_RC=$?
    cp "$CI_LOG" "$GATE_LOG" 2>/dev/null || true
  fi
  if [ "$RUN_RC" = "0" ]; then
    run_step "构建交付包" "$PY" "$BUILD_PY" || RUN_RC=$?
  fi
  if [ "$RUN_RC" = "0" ]; then
    run_step "包验证" "$PY" "$VALIDATE_PY" || RUN_RC=$?
  fi
  if [ "$RUN_RC" = "0" ]; then
    run_step "交付包 CI" "$PY" "$PACKAGE_CI" --zip "$ZIP" || RUN_RC=$?
  fi
  if [ "$RUN_RC" = "0" ]; then
    STEP_N=$((STEP_N + 1))
    say ""
    say "== [STEP $STEP_N] SHA256 清单 =="
    INV="$ART_DIR/SHA256SUMS_${TAG:-ci}.txt"
    if [ -f "$ZIP" ]; then
      ACT_SHA="$(shasum -a 256 "$ZIP" | cut -d' ' -f1)"
      {
        echo "# tag: ${TAG:-unknown}"
        echo "# built_at: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "# version: $VERSION_TXT"
        shasum -a 256 "$ZIP"
        if [ -f "$ZIP_SHA_FILE" ]; then
          REC="$(cut -d' ' -f1 "$ZIP_SHA_FILE")"
          echo "sidecar_recorded: $REC"
          [ "$REC" = "$ACT_SHA" ] && echo "sidecar_match: true" || echo "sidecar_match: false"
        fi
        echo "zip_bytes: $(stat -f '%z' "$ZIP" 2>/dev/null || stat -c '%s' "$ZIP")"
      } > "$INV"
      say "  清单：$INV"
      say "  zip sha256：$ACT_SHA"
      PASS=$((PASS + 1))
    else
      FAIL=$((FAIL + 1)); RUN_RC=1
      say "  [FAIL] zip 不存在，无法生成 SHA256 清单"
    fi
  fi
  if [ "$RUN_RC" != "0" ]; then MODE="run-failed"; fi
  DIST_SHA_AFTER=""
  [ -f "$ZIP" ] && DIST_SHA_AFTER="$(shasum -a 256 "$ZIP" | cut -d' ' -f1)"
else
  SEC_RC=0
  if [ "$SEC" = "1" ]; then
    set +e
    run_security
    SEC_RC=$?
    set -e
  fi
  say ""
  say "dry-run 完成：未写 dist/、未跑全量 gate、未构建。"
  say "  [PRECHECK] PASS=$PASS FAIL=$FAIL WARN=$WARN"
  [ -n "$WARNINGS" ] && say "  [WARNINGS] $WARNINGS"
  DIST_SHA_AFTER=""
  [ -f "$ZIP" ] && DIST_SHA_AFTER="$(shasum -a 256 "$ZIP" | cut -d' ' -f1)"
  say "  dist zip sha256 前后一致：$([ "$DIST_SHA_BEFORE" = "$DIST_SHA_AFTER" ] && echo yes || echo no)"
fi

# ------------------------------------------------------------------ 机读结果
_STEPS="$(printf '%s;;' "${STEPS_DEF[@]}")"
"$PY" - "$OUT" "$MODE" "$PASS" "$FAIL" "$WARN" "$WARNINGS" "$TAG" "$VERSION_TXT" \
  "$GATE_REGISTERED" "$VALIDATE_EXPECTED_TOTAL" "$DIST_SHA_BEFORE" "${DIST_SHA_AFTER:-}" \
  "$_STEPS" "${SEC:-0}" "${SEC_RC:-0}" "${SEC_OUT:-$ART_DIR}" <<'PYEOF'
import json, os, sys, time
(out, mode, p, f, w, warnings, tag, version, gate_registered,
 validate_expected, dist_before, dist_after, steps_raw,
 sec_enabled, sec_rc, sec_dir) = sys.argv[1:]

def _read_security(sec_dir):
    path = os.path.join(sec_dir, "security_gate.json")
    if not os.path.isfile(path):
        return None, path
    try:
        doc = json.load(open(path, encoding="utf-8"))
        return doc, path
    except Exception:
        return {"status": "UNPARSEABLE"}, path

security = {"enabled": str(sec_enabled) == "1", "rc": int(float(sec_rc or 0))}
sec_doc, sec_path = _read_security(sec_dir)
security["report"] = sec_path
security["status"] = ((sec_doc or {}).get("status") or
                      ("NOT_RUN" if not security["enabled"] else "UNKNOWN"))
security["high_unallowlisted"] = (((sec_doc or {}).get("sast") or {})
                                  .get("high_unallowlisted") or {})
security["medium_unallowlisted"] = (((sec_doc or {}).get("sast") or {})
                                    .get("medium_unallowlisted") or {})
security["sca_requirements_vuln_count"] = (((sec_doc or {}).get("sca") or {})
                                           .get("requirements_vuln_count"))
sec_fail = security["enabled"] and (security["rc"] != 0 or security["status"] == "FAIL")
status = "FAIL" if (int(f) > 0 or sec_fail) else ("PASS" if int(w) == 0 else "PASS_WITH_WARN")
if mode == "dry-run":
    status = "DRY_RUN_OK" if (int(f) == 0 and not sec_fail) else "DRY_RUN_FAIL"
data = {
    "task": "T-196 / CI 流水线",
    "script": "scripts/ci/pipeline.sh",
    "at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "mode": mode,
    "status": status,
    "precheck_pass": int(p), "precheck_fail": int(f), "precheck_warn": int(w),
    "warnings": [x for x in warnings.split("; ") if x],
    "tag": tag, "version": version,
    "gate_registered_cases": gate_registered,
    "validate_expected_gate_total": validate_expected,
    "gate_count_match_validate": (gate_registered == validate_expected) if validate_expected else None,
    "dist_zip_sha256_before": dist_before,
    "dist_zip_sha256_after": dist_after,
    "dist_untouched_in_dry_run": (mode != "dry-run") or (dist_before == dist_after),
    "security": security,
    "steps": [dict(zip(("id", "name", "command"), s.split("|")))
              for s in [x for x in steps_raw.split(";;") if x.strip()]],
    "notes": ("默认 dry-run 只做前置检查+打印命令，不写 dist/、不跑 18 分钟 gate；"
              "--run 才真正执行全链。gate 数量与 build16 冻结 validate 期望不一致时会在 [4] 失败，"
              "属当前真实差距（Phase B：重建基线/更新 validate）。"),
}
json.dump(data, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\n机读结果：{out}")
PYEOF

if [ "$MODE" = "dry-run" ] && { [ "$FAIL" -gt 0 ] || [ "${SEC_RC:-0}" != "0" ]; }; then exit 2; fi
if [ "$MODE" = "run" ] && { [ "$FAIL" -gt 0 ] || [ "${SEC_RC:-0}" != "0" ]; }; then exit 1; fi
exit 0
