#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""scripts/ci/artifacts_manifest.py — CI 制品清单（T-201 新增）

给每次 release 产出可复核的制品清单（文件名/大小/SHA256/生成时间），用于：
1. GitHub Actions artifacts 上传前的完整性清单；
2. 交付包 SHA256 复核（人工或下游脚本读取同一份 JSON）；
3. 与 ``SHA256SUMS`` 文本互相校验（``--sha256sums`` 可选输出）。

铁律 6：脚本第一段断言 RULEPROOF_DB（若设置）必须指向 /tmp 临时库；本脚本不 import app、
不写任何数据库，只读文件系统。

用法：
  python3 scripts/ci/artifacts_manifest.py --dir dist --tag v1.5.0-20261120-build1 \\
      --out /tmp/ci_artifacts/artifacts_manifest.json \\
      --sha256sums /tmp/ci_artifacts/SHA256SUMS.txt
  python3 scripts/ci/artifacts_manifest.py --files a.zip b.zip --out /tmp/m.json
  python3 scripts/ci/artifacts_manifest.py --dir dist --exclude '*.db' --json

退出码：0=清单已生成；2=参数/前置错误（目录不存在、输入为空）。
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import sys
import tempfile
import time

# ---------------------------------------------------------------- 铁律 6（第一段）
_BOOT_DB = os.environ.get("RULEPROOF_DB") or ""
if not _BOOT_DB:
    os.environ["RULEPROOF_DB"] = os.path.join(tempfile.mkdtemp(prefix="artman_"), "boot.db")
elif not any(k in _BOOT_DB for k in ("/tmp/", "/private/tmp/", "/var/folders/",
                                     "/private/var/folders/")):
    raise SystemExit(f"拒绝运行：RULEPROOF_DB 指向非临时库（{_BOOT_DB}）；"
                     "CI 制品清单不得触碰产品库")
HERE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

CHUNK = 1024 * 1024


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(CHUNK)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _rel(path: str, root: str) -> str:
    try:
        return os.path.relpath(path, root)
    except ValueError:
        return path


def collect(files: list, root: str = "") -> dict:
    """生成清单：files 为绝对/相对路径列表；返回清单 dict（也供测试直接调用）。"""
    root = os.path.abspath(root or os.getcwd())
    entries = []
    seen = set()
    for path in files:
        full = path if os.path.isabs(path) else os.path.join(root, path)
        full = os.path.abspath(full)
        if full in seen:
            continue
        seen.add(full)
        if not os.path.isfile(full):
            continue
        st = os.stat(full)
        entries.append({
            "name": os.path.basename(full),
            "path": _rel(full, root),
            "size": int(st.st_size),
            "sha256": sha256_file(full),
            "mtime": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime)),
        })
    entries.sort(key=lambda x: x["path"])
    return {
        "task": "T-201 / CI 制品清单",
        "algorithm": "sha256",
        "root": root,
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_files": len(entries),
        "total_bytes": sum(e["size"] for e in entries),
        "files": entries,
    }


def scan_dir(directory: str, exclude: list | None = None) -> list:
    """递归扫描目录（排除 _qa/.git/__pycache__ 等噪音；exclude 支持 fnmatch）。"""
    exclude = list(exclude or [])
    out = []
    for dirpath, dirnames, filenames in os.walk(directory):
        dirnames[:] = sorted(d for d in dirnames if d not in (
            ".git", "__pycache__", ".pytest_cache", ".mypy_cache", "_qa"))
        for name in sorted(filenames):
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, directory)
            if any(fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(name, pat)
                   for pat in exclude):
                continue
            out.append(full)
    return out


def _sha256sums_text(manifest: dict) -> str:
    lines = ["# artifacts_manifest（T-201）root=%s generated_at=%s"
             % (manifest.get("root"), manifest.get("generated_at"))]
    if manifest.get("tag"):
        lines.append("# tag=%s" % manifest["tag"])
    for item in manifest.get("files") or []:
        lines.append("%s  %s" % (item["sha256"], item["path"]))
    return "\n".join(lines) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="CI 制品清单（文件名/大小/SHA256/生成时间）")
    ap.add_argument("--dir", default="", help="扫描目录（递归）")
    ap.add_argument("--files", nargs="*", default=[], help="显式文件列表（与 --dir 可叠加）")
    ap.add_argument("--out", default="", help="清单 JSON 输出路径（缺省 stdout）")
    ap.add_argument("--sha256sums", default="", help="额外输出 SHA256SUMS 文本路径")
    ap.add_argument("--tag", default="", help="发布 tag（写入清单）")
    ap.add_argument("--exclude", action="append", default=[],
                    help="排除模式（fnmatch，可多次；如 --exclude '*.db'）")
    ap.add_argument("--root", default="", help="清单相对路径锚点（默认：扫描目录或 cwd）")
    ap.add_argument("--json", action="store_true", help="把清单 JSON 打到 stdout")
    ns = ap.parse_args(argv)

    files = list(ns.files)
    root = os.path.abspath(ns.root or os.getcwd())
    if ns.dir:
        target = os.path.abspath(ns.dir)
        if not os.path.isdir(target):
            print(f"错误：目录不存在：{target}", file=sys.stderr)
            return 2
        files.extend(scan_dir(target, ns.exclude))
        if not ns.root:
            root = target
    if not files:
        print("错误：没有可列入清单的文件（--dir/--files 均未命中）", file=sys.stderr)
        return 2
    manifest = collect(files, root=root)
    if ns.tag:
        manifest["tag"] = str(ns.tag)
    if manifest["total_files"] == 0:
        print("错误：输入文件均不存在，清单为空（不伪造）", file=sys.stderr)
        return 2
    text = json.dumps(manifest, ensure_ascii=False, indent=1)
    if ns.out:
        os.makedirs(os.path.dirname(os.path.abspath(ns.out)) or ".", exist_ok=True)
        with open(ns.out, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        print(f"制品清单：{ns.out}（{manifest['total_files']} 个文件，"
              f"{manifest['total_bytes']} 字节）")
    if ns.sha256sums:
        os.makedirs(os.path.dirname(os.path.abspath(ns.sha256sums)) or ".", exist_ok=True)
        with open(ns.sha256sums, "w", encoding="utf-8") as f:
            f.write(_sha256sums_text(manifest))
        print(f"SHA256SUMS：{ns.sha256sums}")
    if ns.json or not ns.out:
        print(text)
    # 人读摘要（stdout 末行；机读以 --out JSON 为准）
    for item in manifest["files"]:
        print(f"  {item['sha256'][:16]}…  {item['size']:>12}  {item['path']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
