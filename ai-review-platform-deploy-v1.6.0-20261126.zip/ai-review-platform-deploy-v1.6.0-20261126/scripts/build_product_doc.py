# -*- coding: utf-8 -*-
"""把产品文档 Markdown 渲染为 DOCX（含封面、目录域、表格、代码块、页眉页脚）。"""
import re
import sys
from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

SRC = Path(sys.argv[1] if len(sys.argv) > 1 else "docs/reports/产品文档_主审核链路与未完成模块_20261115.md")
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "docs/reports/产品文档_主审核链路与未完成模块_20261115.docx")
BODY_FONT = "宋体"
HEAD_FONT = "微软雅黑"
CODE_FONT = "Consolas"
ACCENT = RGBColor(0x1F, 0x3A, 0x5F)
MUTED = RGBColor(0x59, 0x5F, 0x69)


def set_run_font(run, name=BODY_FONT, size=None, bold=None, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = color


def shade(cell_or_par, hex_color):
    el = cell_or_par._element
    if el.tag.endswith("}tc"):
        pr = el.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:fill"), hex_color)
        pr.append(shd)
    else:
        pPr = el.get_or_add_pPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:fill"), hex_color)
        pPr.append(shd)


def set_cell_margins(table, top=40, bottom=40, left=70, right=70):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("bottom", bottom), ("left", left), ("right", right)):
        el = OxmlElement(f"w:{k}")
        el.set(qn("w:w"), str(v))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def add_field(par, instr):
    r = par.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), instr)
    t = OxmlElement("w:t")
    t.text = "1"
    rr = OxmlElement("w:r")
    rr.append(t)
    fld.append(rr)
    r._element.addnext(fld)


def set_page_number(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("第 ")
    set_run_font(run, BODY_FONT, 8.5, color=MUTED)
    add_field(p, "PAGE")
    run2 = p.add_run(" 页")
    set_run_font(run2, BODY_FONT, 8.5, color=MUTED)


def add_inline(par, text, size=10.5, base_color=None):
    """支持 **粗体** 与 `代码`。"""
    pos = 0
    for m in re.finditer(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if m.start() > pos:
            set_run_font(par.add_run(text[pos:m.start()]), BODY_FONT, size, color=base_color)
        tok = m.group(0)
        if tok.startswith("**"):
            set_run_font(par.add_run(tok[2:-2]), BODY_FONT, size, bold=True, color=base_color)
        else:
            r = par.add_run(tok[1:-1])
            set_run_font(r, CODE_FONT, max(8.0, size - 1.2), color=RGBColor(0x8B, 0x1A, 0x1A))
            r.font.highlight_color = None
        pos = m.end()
    if pos < len(text):
        set_run_font(par.add_run(text[pos:]), BODY_FONT, size, color=base_color)


def add_code_block(doc, lines):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.4)
    p.paragraph_format.right_indent = Cm(0.2)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(6)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "4")
        el.set(qn("w:color"), "D9DCE0")
        pBdr.append(el)
    pPr.append(pBdr)
    shade(p, "F6F8FA")
    for i, line in enumerate(lines):
        if i:
            p.add_run().add_break()
        set_run_font(p.add_run(line), CODE_FONT, 8.6, color=RGBColor(0x24, 0x29, 0x2F))
    return p


def set_heading(par, level):
    sizes = {1: 18, 2: 14.5, 3: 12.5, 4: 11.5}
    for r in par.runs:
        set_run_font(r, HEAD_FONT, sizes.get(level, 11), bold=True, color=ACCENT)
    par.paragraph_format.space_before = Pt(14 if level == 1 else 9)
    par.paragraph_format.space_after = Pt(5 if level == 1 else 3)
    par.paragraph_format.keep_with_next = True
    if level == 1:
        par.paragraph_format.page_break_before = True


def add_table(doc, rows):
    if not rows:
        return
    ncols = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=ncols)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    set_cell_margins(table)
    for i, row in enumerate(rows):
        for j in range(ncols):
            cell = table.cell(i, j)
            text = row[j] if j < len(row) else ""
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            add_inline(p, text.strip(), size=8.6)
            if i == 0:
                shade(cell, "EAF0F8")
                for r in p.runs:
                    r.bold = True
                    r.font.color.rgb = ACCENT
    repeat_header(table.rows[0])
    # 表后留白
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_toc(doc, entries):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run("目录")
    set_run_font(r, HEAD_FONT, 16, bold=True, color=ACCENT)
    if not entries:
        return
    table = doc.add_table(rows=len(entries) + 1, cols=2)
    table.style = "Table Grid"; table.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_cell_margins(table, 45, 45, 90, 90)
    for j, text in enumerate(("序号", "章节")):
        cell = table.cell(0, j); cell.text = ""
        pp = cell.paragraphs[0]; pp.paragraph_format.space_after = Pt(0)
        add_inline(pp, text, size=9)
        shade(cell, "EAF0F8")
        for rr in pp.runs: rr.bold = True
    for i, text in enumerate(entries, 1):
        for j, val in enumerate((str(i), text)):
            cell = table.cell(i, j); cell.text = ""
            pp = cell.paragraphs[0]; pp.paragraph_format.space_after = Pt(0)
            add_inline(pp, val, size=9)
    repeat_header(table.rows[0])
    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(6)
    set_run_font(note.add_run("目录为章节导航；页码可用 Word 导航窗格查看，或在 Word 中插入自动目录。"),
                 BODY_FONT, 8.5, color=MUTED)


def header_text(section):
    p = section.header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_run_font(p.add_run("AI 审核平台 · 产品文档 v1.3.6-product-20261115"), HEAD_FONT, 8, color=MUTED)


def main():
    md = SRC.read_text(encoding="utf-8")
    lines = md.splitlines()
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0); sec.page_height = Cm(29.7)
    sec.left_margin = Cm(2.1); sec.right_margin = Cm(2.1)
    sec.top_margin = Cm(2.0); sec.bottom_margin = Cm(1.8)
    sec.different_first_page_header_footer = True
    header_text(sec)
    set_page_number(sec)
    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal.font.size = Pt(10.5)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    normal.paragraph_format.line_spacing = 1.35
    normal.paragraph_format.space_after = Pt(4)

    # 封面
    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run_font(p.add_run("AI 审核平台"), HEAD_FONT, 28, bold=True, color=ACCENT)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run_font(p.add_run("产品文档"), HEAD_FONT, 24, bold=True, color=ACCENT)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(8)
    set_run_font(p.add_run("主审核链路详解与未完成模块清单"), HEAD_FONT, 15, color=MUTED)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(20)
    set_run_font(p.add_run("v1.3.6-product-20261115  ·  2026-11-15"), BODY_FONT, 10, color=MUTED)

    # 封面信息框
    doc.add_paragraph()
    info = doc.add_table(rows=4, cols=2)
    info.style = "Table Grid"; info.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_cell_margins(info, 70, 70, 100, 100)
    vals = [("文档定位", "产品 / 研发 / 验收共用；说明已做到什么、还不许宣称什么"),
            ("主链路", "项目预检 → manifest 冻结 → D1–D5 → 7 节点 DAG → 发现 → 复核/补证 → 报告"),
            ("当前基线", "全链路 35/35；/reviews 契约 PASS；默认 DAG；包 CI ok"),
            ("状态原则", "未完成就写未完成；SKIP 不写成 PASS；局部测试不冒充全量")]
    for i, (k, v) in enumerate(vals):
        for j, text in enumerate((k, v)):
            cell = info.cell(i, j); cell.text = ""
            pp = cell.paragraphs[0]; pp.paragraph_format.space_after = Pt(0)
            add_inline(pp, text, size=9)
            if j == 0:
                shade(cell, "EAF0F8")
                for r in pp.runs: r.bold = True
    doc.add_page_break()

    # 正文：跳过 Markdown 一级标题与副标题
    body = lines[:]
    if body and body[0].startswith("# "):
        body = body[1:]
    while body and not body[0].strip():
        body = body[1:]
    if body and body[0].startswith("## 主审核链路"):
        body = body[1:]

    # 目录（静态章节导航，避免未更新域显示空框）
    toc_entries = [re.sub(r"^#\s+", "", x).strip() for x in body if re.match(r"^#\s+", x)]
    add_toc(doc, toc_entries)
    doc.add_page_break()

    in_code = False; code = []; table_rows = []
    i = 0
    while i < len(body):
        line = body[i]
        stripped = line.strip()
        if stripped.startswith("```"):
            if in_code:
                add_code_block(doc, code); code = []; in_code = False
            else:
                in_code = True
            i += 1; continue
        if in_code:
            code.append(line.rstrip("\n")); i += 1; continue
        if stripped.startswith("|") and stripped.endswith("|"):
            cells = [x.strip() for x in stripped.strip("|").split("|")]
            if i + 1 < len(body) and re.match(r"^\|?\s*:?-{2,}", body[i + 1].strip()):
                i += 1  # skip separator
            table_rows.append(cells); i += 1
            # 连续表格行
            while i < len(body) and body[i].strip().startswith("|"):
                if re.match(r"^\|?\s*:?-{2,}", body[i].strip()):
                    i += 1; continue
                table_rows.append([x.strip() for x in body[i].strip().strip("|").split("|")])
                i += 1
            add_table(doc, table_rows); table_rows = []
            continue
        if stripped.startswith("#"):
            m = re.match(r"^(#{1,4})\s+(.*)$", stripped)
            if m:
                level = len(m.group(1))
                p = doc.add_heading(level=level)
                # add_heading 已加 run，重建
                for r in list(p.runs): r._element.getparent().remove(r._element)
                add_inline(p, m.group(2), size={1: 18, 2: 14.5, 3: 12.5, 4: 11.5}.get(level, 11))
                set_heading(p, level)
                if level == 1:
                    p.paragraph_format.page_break_before = m.group(2).startswith(
                        ("三、", "四、"))
                i += 1; continue
        if stripped in ("---", "***"):
            p = doc.add_paragraph()
            pPr = p._p.get_or_add_pPr()
            pBdr = OxmlElement("w:pBdr")
            bottom = OxmlElement("w:bottom")
            bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), "6")
            bottom.set(qn("w:space"), "1"); bottom.set(qn("w:color"), "D0D5DD")
            pBdr.append(bottom); pPr.append(pBdr)
            i += 1; continue
        if stripped.startswith(">"):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.5)
            p.paragraph_format.space_before = Pt(4); p.paragraph_format.space_after = Pt(6)
            pPr = p._p.get_or_add_pPr()
            pBdr = OxmlElement("w:pBdr")
            left = OxmlElement("w:left")
            left.set(qn("w:val"), "single"); left.set(qn("w:sz"), "18")
            left.set(qn("w:space"), "8"); left.set(qn("w:color"), "8EA9C1")
            pBdr.append(left); pPr.append(pBdr)
            add_inline(p, stripped[1:].strip(), size=9.5, base_color=MUTED)
            i += 1; continue
        m = re.match(r"^(\s*)[-*]\s+(.*)$", line)
        if m:
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.left_indent = Cm(0.7)
            p.paragraph_format.space_after = Pt(2)
            add_inline(p, m.group(2), size=10.2)
            i += 1; continue
        m = re.match(r"^(\s*)\d+\.\s+(.*)$", line)
        if m:
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.left_indent = Cm(0.7)
            p.paragraph_format.space_after = Pt(2)
            add_inline(p, m.group(2), size=10.2)
            i += 1; continue
        if not stripped:
            i += 1; continue
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        add_inline(p, stripped, size=10.5)
        i += 1

    if in_code:
        add_code_block(doc, code)
    if table_rows:
        add_table(doc, table_rows)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print("saved", OUT, "paragraphs", len(doc.paragraphs), "tables", len(doc.tables))


if __name__ == "__main__":
    main()
