# -*- coding: utf-8 -*-
"""规模化对抗评测：N 份文档 × 每份 K 个随机问题 = 问题实例，双通道(15规则 + 事实层)评测。

量化：每类问题审出率、总审出率、漏报、误报，并按根因归因。
"""
import os
import random
import sys
import tempfile
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.engine import engine, factreview  # noqa: E402
from adversarial import PROBLEMS, clean as clean_doc, build2  # noqa: E402

N_DOCS = 50
K_PROBLEMS = 8


def inject_doc(base, problem):
    c = base()
    try:
        return problem["apply"](c)
    except Exception:
        return None


def main():
    random.seed(42)
    tmp = tempfile.mkdtemp(prefix="rp_scale_")
    # 每类问题统计
    detect = defaultdict(lambda: {"hit": 0, "total": 0, "root": ""})
    false_pos = 0
    total_instances = 0

    for di in range(N_DOCS):
        chosen = random.sample(PROBLEMS, K_PROBLEMS)
        for pr in chosen:
            total_instances += 1
            detect[pr["name"]]["total"] += 1
            detect[pr["name"]]["root"] = pr.get("root", "")
            c = inject_doc(clean_doc, pr)
            if c is None:
                continue
            p = os.path.join(tmp, f"d{di}_{pr['name']}.xlsx")
            build2(p, c)
            got = [f["id"] for f in engine.build_report(p)["findings"]]
            if pr["expect"]:
                if pr["expect"] in got:
                    detect[pr["name"]]["hit"] += 1
            else:
                # 期望漏报的问题，若被任何规则捕获也算"意外捕获"（非漏报）
                if got:
                    detect[pr["name"]]["hit"] += 1

    # 误报：干净文档（换内容）不应有发现
    clean_fp = 0
    for i in range(10):
        p = os.path.join(tmp, f"clean{i}.xlsx")
        build2(p, clean_doc())
        if engine.build_report(p)["findings"]:
            clean_fp += 1

    # 输出矩阵
    print(f"{'问题点':16} {'期望':6} {'审出/总数':10} {'审出率':8} {'根因'}")
    print("-" * 72)
    hits = 0
    for name, d in sorted(detect.items(), key=lambda x: -x[1]["hit"] / max(x[1]["total"], 1)):
        rate = d["hit"] / max(d["total"], 1)
        hits += d["hit"]
        print(f"{name:16} {('漏报' if d['root'] else '捕获'):6} {d['hit']:2}/{d['total']:<8} {rate*100:5.0f}%   {d['root'] or ''}")

    print("-" * 72)
    print(f"总量级：{N_DOCS} 份 × {K_PROBLEMS} 问题 = {total_instances} 实例")
    print(f"总审出：{hits}/{total_instances}（{hits/max(total_instances,1)*100:.0f}%）")
    print(f"干净文档误报：{clean_fp}/10")

    # 根因分布
    root = Counter(d["root"] or "已覆盖" for d in detect.values())
    print(f"根因分布：{dict(root)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
