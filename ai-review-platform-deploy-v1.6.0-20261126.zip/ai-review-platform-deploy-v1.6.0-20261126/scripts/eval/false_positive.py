# -*- coding: utf-8 -*-
"""误报审计（专门针对"没问题说成有问题"）：

1. 合规文档语料（随机合规值 + 边界值 85℃/200ppm/10℃/8℃/20h + 良性变体）
   → 期望 0 发现。
2. 边界测试：恰好达标值必须【不报】，差一点（84℃/199ppm/11℃/9℃/19h）必须【报】。
3. 记录误报率。
"""
import os
import random
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from docx import Document  # noqa: E402
from app.engine import factreview  # noqa: E402

OUT = tempfile.mkdtemp(prefix="rp_fp_")


def render(path, c):
    d = Document()
    d.add_heading("产品出厂检验报告", 0)
    d.add_paragraph(f"报告编号：{c['version']}")
    d.add_paragraph(f"检验日期：{c['date']}")
    d.add_paragraph(f"复核日期：{c['date']}")          # 日期一致
    d.add_paragraph(f"产品名称：{c['name']}")
    d.add_paragraph(f"1. 加热工艺：{c['temp']}")
    d.add_paragraph(f"2. 贮存条件：{c['cold']}")
    d.add_paragraph(f"3. 卫生控制：消毒液浓度{c['conc']}ppm")
    d.add_paragraph(f"4. 原料处理：原料解冻时长{c['thaw']}h")
    if c.get("extra"):
        d.add_paragraph(c["extra"])
    d.save(path)


def make_clean(idx, boundary=False):
    if boundary:
        # 恰好达标的边界值：必须不报
        vals = dict(temp=85, cold=8, conc=200, thaw=20)
    else:
        # 随机合规值（严格达标，留余量）
        vals = dict(temp=random.choice([86, 90, 95, 100]),
                    cold=random.choice([0, 2, 4, 6]),
                    conc=random.choice([250, 300, 400, 500]),
                    thaw=random.choice([24, 30, 36, 48]))
    return dict(
        version=f"QY-JY-2026-A{idx}",
        date="2026-03-17",
        name="某即食产品",
        temp=f"中心温度{vals['temp']}℃以上出锅",
        cold=f"冷藏库内温度0-{vals['cold']}℃",
        conc=vals["conc"], thaw=vals["thaw"],
        extra=(f"备注：本批共 {random.randint(10, 999)} 件" if idx % 3 == 0 else ""),
    )


def main():
    random.seed(2024)
    # 1) 合规语料（60 份：50 随机 + 10 边界）
    clean_total = 60
    clean_fp = 0
    for i in range(clean_total):
        c = make_clean(i, boundary=(i >= 50))
        p = os.path.join(OUT, f"clean{i}.docx")
        render(p, c)
        fs = factreview.review_document(p)["findings"]
        if fs:
            clean_fp += 1
            print(f"  [误报] clean{i}: {[f['id'] for f in fs]}")
    print(f"合规文档误报：{clean_fp}/{clean_total}（{clean_fp/clean_total*100:.0f}%）")

    # 2) 边界测试：达标值不报，差一点必报
    cases = [
        ("中心温度85℃(达标)", "中心温度85℃出锅", False),
        ("中心温度84℃(差1℃)", "中心温度84℃出锅", True),
        ("冷藏8℃(达标)", "冷藏库内温度8℃", False),
        ("冷藏9℃(超1℃)", "冷藏库内温度9℃", True),
        ("消毒200ppm(达标)", "消毒液浓度200ppm", False),
        ("消毒199ppm(差1)", "消毒液浓度199ppm", True),
        ("解冻20h(达标)", "原料解冻时长20h", False),
        ("解冻19h(差1h)", "原料解冻时长19h", True),
        ("冷却10℃(达标)", "冷却至10℃", False),
        ("冷却11℃(超1℃)", "冷却至11℃", True),
    ]
    ok = 0
    for name, text, should_flag in cases:
        c = make_clean(0)
        c["temp"] = "中心温度90℃以上出锅"  # 其它指标合规
        if "中心温度" in text:
            c["temp"] = text
        elif "冷藏" in text:
            c["cold"] = text
        elif "消毒" in text:
            c["conc"] = 200 if "199" not in text else 199  # 用文本覆盖
        elif "解冻" in text:
            c["thaw"] = text
        elif "冷却" in text:
            c["extra"] = text
        p = os.path.join(OUT, "b.docx")
        # 直接写纯文本段落，避免模板干扰
        d = Document(); d.add_paragraph(text); d.save(p)
        fs = factreview.review_document(p)["findings"]
        flagged = len(fs) > 0
        good = (flagged == should_flag)
        ok += good
        mark = "✅" if good else "❌"
        print(f"{mark} {name}: 期望{'报' if should_flag else '不报'} → 实际{'报' if flagged else '不报'} {[f['id'] for f in fs]}")
    print(f"边界准确：{ok}/{len(cases)}")

    print("\n结论：合规误报率 =", f"{clean_fp/clean_total*100:.0f}%", "| 边界准确率 =", f"{ok/len(cases)*100:.0f}%")
    return 0


if __name__ == "__main__":
    sys.exit(main())
