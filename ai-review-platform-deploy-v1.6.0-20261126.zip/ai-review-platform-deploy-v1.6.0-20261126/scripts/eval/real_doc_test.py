# -*- coding: utf-8 -*-
"""真实文件 + 高难度问题注入评测（防作弊）。

取真实 PDF（专利/标准）文本作为正文，注入 18 个高难度问题（含多种真实写法变体），
跑通用解析器 + 事实层审核，诚实统计：审出/漏报/原因。
"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from pypdf import PdfReader  # noqa: E402
from docx import Document  # noqa: E402
from app.engine import factreview  # noqa: E402

OUT = tempfile.mkdtemp(prefix="rp_real_")

# 18 个高难度问题：每条是 (名称, 文本片段, 期望的 finding id 或 None=预期漏报)
PROBLEMS = [
    ("中心温度70℃(标准)", "加热工序：中心温度70℃出锅。", "F-中心温度"),
    ("中心温度70℃(空格)", "加热工序：中心温度 70 ℃ 出锅。", "F-中心温度"),
    ("中心温度70度(°字)", "加热工序：中心温度70度出锅。", "F-中心温度"),
    ("中心温度表格管道", "加热工序：中心温度 | 70 | ℃ 出锅。", "F-中心温度"),
    ("加热终温同义词", "加热工序：加热终温70℃出锅。", "F-中心温度"),
    ("无对象词70℃", "加热工序：出锅温度70℃。", "F-中心温度"),
    ("冷却15℃", "冷却工序：冷却至15℃。", "F-冷却"),
    ("冷藏12℃", "贮存：冷藏库内温度12℃。", "F-冷藏"),
    ("消毒150ppm", "卫生：消毒液浓度150ppm。", "F-消毒"),
    ("解冻15h", "原料：解冻时长15h。", "F-解冻"),
    ("解冻15小时", "原料：解冻时长15小时。", "F-解冻"),
    ("版本号X", "报告编号：X", "F-版本"),
    ("日期不一致(横线)", "检验日期：2026-03-17；复核日期：2026-04-01。", "F-日期"),
    ("日期不一致(斜杠)", "检验日期：2026/3/17；复核日期：2026-04-01。", "F-日期"),
    ("重量单位混淆", "净含量：360kg。", "F-单位"),
    ("产品名错别字", "产品名称：烤内拌饭。", "F-名称"),
    ("签名占位符", "检验员：X；审核员：X。", "F-签名"),
    ("重量不匹配", "设计总重量：500g；半成品合计：360g。", "F-重量"),
]


def real_text(pdf):
    return "".join((p.extract_text() or "") for p in PdfReader(pdf).pages)


def build_doc(path, base_text, inject):
    d = Document()
    d.add_heading("检验记录（基于真实文件内容）", 0)
    for para in base_text[:2500].split("\n"):
        para = para.strip()
        if para:
            d.add_paragraph(para)
    d.add_heading("工艺与检验数据", 1)
    for name, text, _ in inject:
        d.add_paragraph(text)
    d.save(path)


def main():
    base_dir = "/tmp/realdocs"
    docs = [("真实专利·香肠工艺", f"{base_dir}/patent_sausage.pdf"),
            ("真实团体标准·食品风险管控", f"{base_dir}/ttbz_std.pdf")]
    grand_hit = grand_total = 0
    for doc_name, pdf in docs:
        if not os.path.exists(pdf):
            print(f"跳过 {doc_name}（文件不存在）")
            continue
        txt = real_text(pdf)
        hit = 0
        print(f"\n== {doc_name}（真实正文 {len(txt)} 字，逐问题隔离测试）==")
        for name, text, expect in PROBLEMS:
            p = os.path.join(OUT, f"{os.path.basename(pdf)}_{name}.docx")
            build_doc(p, txt, [(name, text, expect)])   # 只注入这一个问题
            got = [f["id"] for f in factreview.review_document(p)["findings"]]
            ok = expect in got
            hit += 1 if ok else 0
            mark = "✅" if ok else "❌"
            why = "" if ok else "（未覆盖）"
            print(f"  {mark} {name:20} 『{text[:28]}』 → {'审出' if ok else '未审出'}{why}")
        grand_hit += hit
        grand_total += len(PROBLEMS)
        print(f"  本文件审出 {hit}/{len(PROBLEMS)}")
    print(f"\n总计：{grand_hit}/{grand_total}（{grand_hit/max(grand_total,1)*100:.0f}%）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
