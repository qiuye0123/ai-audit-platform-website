# -*- coding: utf-8 -*-
"""对抗评测（真刀真枪）：多样工艺书 + 高难度问题点注入 → 跑引擎 → 审出/漏报/误报 + 根因。"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from openpyxl import Workbook  # noqa: E402
from app.engine import engine  # noqa: E402

ROLES = ["研发经理", "生产经理", "品管经理", "研发"]
SIG = ["张三", "李四", "王五", "赵六"]


def build(path, sheets, header, half, mats, design, unit):
    wb = Workbook()
    wb.remove(wb.active)
    for sn, proc, rows in sheets:
        ws = wb.create_sheet(sn)
        ws["A3"] = "实施日期"; ws["C3"] = header.get("date", "2026-03-17")
        ws["A4"] = "版本号"; ws["C4"] = header.get("version", "LHHK-C-RD-STP-649A1")
        ws["A7"] = "商品名"; ws["D7"] = header.get("product", "烤肉拌饭")
        ws["A9"] = "工序名称"; ws["C9"] = proc
        for i, role in enumerate(ROLES):
            ws.cell(row=5, column=i + 1, value=role)
            ws.cell(row=6, column=i + 1, value=header.get("sigs", SIG)[i])
        ws.cell(row=11, column=1, value="标准工序")
        for j, (seq, txt) in enumerate(rows):
            ws.cell(row=12 + j, column=1, value=seq)
            ws.cell(row=12 + j, column=2, value=txt)
    wp = wb.create_sheet("包装指示书 ")
    wp["A1"] = "设计总重量"; wp["D1"] = design; wp["E1"] = unit
    wp["A3"] = "半成品名称"
    for j, (seq, name, w) in enumerate(half):
        wp.cell(row=4 + j, column=1, value=seq)
        wp.cell(row=4 + j, column=2, value=name)
        wp.cell(row=4 + j, column=8, value=w)
        wp.cell(row=4 + j, column=10, value="g")
    wp["A20"] = "包材编号"
    for j, (seq, name) in enumerate(mats):
        wp.cell(row=21 + j, column=1, value=seq)
        wp.cell(row=21 + j, column=2, value=name)
    wb.save(path)


def clean():
    return dict(
        header={"date": "2026-03-17", "version": "LHHK-C-RD-STP-649A1", "sigs": SIG, "product": "烤肉拌饭"},
        sheets=[
            ("蔬菜前处理", "炒卷心菜", [("清洗消毒", "消毒液浓度200ppm 浸泡10min"), ("切制", "蒜打成蒜泥 粒径≤1mm")]),
            ("肉类前处理", "肉类前处理", [("解冻", "鸡胸肉20h 0-8℃"), ("切块", "鸡胸肉清洗去筋膜切块")]),
            ("焯水蔬菜", "焯水蔬菜", [("焯水", "中心温度85℃出锅 冷却至10℃")]),
        ],
        half=[(1, "炒卷心菜", 360)], mats=[(1, "收缩膜"), (2, "纸箱")],
        design=360, unit="g",
    )


def P(name, cat, apply, expect, root):
    return {"name": name, "cat": cat, "apply": apply, "expect": expect, "root": root}


def sh(sheets, idx, name=None, rows=None):
    sn, proc, r = sheets[idx]
    return (name or sn, proc, rows if rows is not None else r)


PROBLEMS = [
    P("实施日期不一致", "一致性", lambda c: c.update(sheets=[sh(c["sheets"], 0), sh(c["sheets"], 1, rows=[("解冻", "鸡胸肉20h"), ("切块", "鸡胸肉清洗切块")]), sh(c["sheets"], 2)]) or c.__setitem__("header", {**c["header"], "date": None}) or _setdate(c), "S1", "设计"),
    P("版本号X", "占位符", lambda c: c["header"].update(version="X") or c, "S2", "设计"),
    P("签名X", "占位符", lambda c: c["header"].update(sigs=["X", "X", "X", "X"]) or c, "S3", "设计"),
    P("产品名混用", "一致性", lambda c: _mixname(c), "S4", "设计"),
    P("半成品无工序", "闭环", lambda c: c.update(half=c["half"] + [(2, "酱油饭", 10)]) or c, "G-酱油饭", "本体"),
    P("序号跳号", "格式", lambda c: c.update(half=[(1, "炒卷心菜", 200), (3, "炒卷心菜", 160)]) or c, "G3", "设计"),
    P("包材缺序号", "格式", lambda c: c.update(mats=[("", "收缩膜"), (2, "纸箱")]) or c, "G4", "设计"),
    P("重量不匹配", "数值", lambda c: c.update(half=[(1, "炒卷心菜", 300)], design=500) or c, "G5", "设计"),
    P("蒜泥无规格", "规格", lambda c: c.update(sheets=[("蔬菜前处理", "炒卷心菜", [("切制", "蒜打成蒜泥 粉碎机")]), sh(c["sheets"], 1), sh(c["sheets"], 2)]) or c, "G6", "设计"),
    P("鸡肉缺清洗", "完整性", lambda c: c.update(sheets=[sh(c["sheets"], 0), ("肉类前处理", "肉类前处理", [("解冻", "鸡胸肉20h"), ("切块", "鸡胸肉切块")]), sh(c["sheets"], 2)]) or c, "G7", "设计"),
    P("中心温度偏低", "参数值", lambda c: c.update(sheets=[("焯水蔬菜", "焯水蔬菜", [("焯水", "中心温度70℃出锅")]), sh(c["sheets"], 0), sh(c["sheets"], 1)]) or c, "P-中心温度", "设计"),
    P("消毒浓度偏低", "参数值", lambda c: c.update(sheets=[("蔬菜前处理", "炒卷心菜", [("清洗消毒", "消毒液浓度150ppm 浸泡10min")]), sh(c["sheets"], 1), sh(c["sheets"], 2)]) or c, "P-消毒", "设计"),
    P("产品名错别字", "名称", lambda c: c["header"].update(product="烤内拌饭") or c, "P-名称", "本体"),
    P("冷却温度超标", "参数值", lambda c: c.update(sheets=[("焯水蔬菜", "焯水蔬菜", [("焯水", "中心温度85℃出锅 冷却至15℃")]), sh(c["sheets"], 0), sh(c["sheets"], 1)]) or c, "P-冷却", "设计"),
    # 高难度（预期漏报）
    P("解冻时长不足", "参数值", lambda c: c.update(sheets=[sh(c["sheets"], 0), ("肉类前处理", "肉类前处理", [("解冻", "鸡胸肉15h 0-8℃"), ("切块", "鸡胸肉清洗切块")]), sh(c["sheets"], 2)]) or c, None, "设计(缺规则)"),
    P("冷藏温度超标", "参数值", lambda c: c.update(sheets=[sh(c["sheets"], 0), ("肉类前处理", "肉类前处理", [("暂存", "库内温度12℃"), ("切块", "鸡胸肉清洗切块")]), sh(c["sheets"], 2)]) or c, None, "设计(缺规则)"),
    P("重量单位混淆", "数值单位", lambda c: c.update(design=360, unit="kg") or c, None, "设计(单位)"),
    P("工序名错别字", "本体别名", lambda c: c.update(half=[(1, "炒卷新菜", 360)]) or c, None, "本体(缺别名)"),
    P("日期格式异常", "归一化", lambda c: c["header"].update(date="2026/3/17") or c, None, "设计(归一化)"),
]


def _setdate(c):
    # 让第 2 张表日期不同：直接在 header 层做不了，改 sheets 第二张表 proc 不变但单独写日期
    # 简化：改 product 不同 sheet 日期 → 用 header 无法表达，改用返回定制 sheets
    c["sheets"] = [c["sheets"][0], ("肉类前处理", "肉类前处理", [("解冻", "鸡胸肉20h"), ("切块", "鸡胸肉清洗切块")]), c["sheets"][2]]
    c["_date_override"] = {"肉类前处理": "2026-03-18"}
    return c


def _mixname(c):
    c["_product_override"] = {"肉类前处理": "喷香烤肉拌饭"}
    return c


def build2(path, c):
    """支持 per-sheet date/product 覆盖。"""
    wb = Workbook()
    wb.remove(wb.active)
    for sn, proc, rows in c["sheets"]:
        ws = wb.create_sheet(sn)
        h = c["header"]
        ws["A3"] = "实施日期"; ws["C3"] = c.get("_date_override", {}).get(sn, h.get("date", "2026-03-17"))
        ws["A4"] = "版本号"; ws["C4"] = h.get("version", "LHHK-C-RD-STP-649A1")
        ws["A7"] = "商品名"; ws["D7"] = c.get("_product_override", {}).get(sn, h.get("product", "烤肉拌饭"))
        ws["A9"] = "工序名称"; ws["C9"] = proc
        for i, role in enumerate(ROLES):
            ws.cell(row=5, column=i + 1, value=role)
            ws.cell(row=6, column=i + 1, value=h.get("sigs", SIG)[i])
        ws.cell(row=11, column=1, value="标准工序")
        for j, (seq, txt) in enumerate(rows):
            ws.cell(row=12 + j, column=1, value=seq)
            ws.cell(row=12 + j, column=2, value=txt)
    wp = wb.create_sheet("包装指示书 ")
    wp["A1"] = "设计总重量"; wp["D1"] = c["design"]; wp["E1"] = c["unit"]
    wp["A3"] = "半成品名称"
    for j, (seq, name, w) in enumerate(c["half"]):
        wp.cell(row=4 + j, column=1, value=seq)
        wp.cell(row=4 + j, column=2, value=name)
        wp.cell(row=4 + j, column=8, value=w)
        wp.cell(row=4 + j, column=10, value="g")
    wp["A20"] = "包材编号"
    for j, (seq, name) in enumerate(c["mats"]):
        wp.cell(row=21 + j, column=1, value=seq)
        wp.cell(row=21 + j, column=2, value=name)
    wb.save(path)


def main():
    tmp = tempfile.mkdtemp(prefix="rp_adv_")
    print(f"{'问题点':16} {'类别':7} {'期望':12} {'实际'}")
    print("-" * 88)
    hit = miss = fp = 0
    for i, pr in enumerate(PROBLEMS):
        c = clean()
        try:
            c = pr["apply"](c)
        except Exception as e:
            print(f"{pr['name']:16} 注入失败 {e}")
            continue
        p = os.path.join(tmp, f"d{i}.xlsx")
        build2(p, c)
        got = [f["id"] for f in engine.build_report(p)["findings"]]
        if pr["expect"]:
            ok = pr["expect"] in got
            if ok:
                hit += 1
            else:
                miss += 1
        else:
            ok = len(got) == 0
            if not ok:
                fp += 1
        print(f"{'✅' if ok else '❌'} {pr['name']:15} {pr['cat']:7} {pr['expect'] or '漏报':12} {'审出 ' + ','.join(got) if got else '未审出'}")
    # 误报：干净文档
    clean_fp = 0
    for i in range(5):
        p = os.path.join(tmp, f"c{i}.xlsx")
        build2(p, clean())
        got = [f["id"] for f in engine.build_report(p)["findings"]]
        if got:
            clean_fp += 1
            print(f"  [误报] 干净文档: {got}")
    print("-" * 88)
    n_cov = sum(1 for x in PROBLEMS if x["expect"])
    print(f"结果：覆盖项审出 {hit}/{n_cov}｜漏报 {miss}｜高难度误审 {fp}｜干净文档误报 {clean_fp}/5")
    return 0


if __name__ == "__main__":
    sys.exit(main())
