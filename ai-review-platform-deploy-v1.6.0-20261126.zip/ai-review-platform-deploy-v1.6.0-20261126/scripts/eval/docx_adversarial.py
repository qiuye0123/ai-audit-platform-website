# -*- coding: utf-8 -*-
"""真实专业文件 + 高难度问题 对抗评测（docx 版，走事实层审核 factreview）。

生成「检测报告/作业指导书」类专业文档，注入高难度问题，跑通用解析器+事实层审核，
量化审出率。配合「真实下载 PDF」形成"真实文件 + 量级"证据链。
"""
import os
import random
import sys
import tempfile
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from docx import Document  # noqa: E402
from app.engine import factreview  # noqa: E402

N_DOCS = 40
K_PROBLEMS = 6


def base_doc():
    """专业检测报告底稿。"""
    return {
        "title": "产品出厂检验报告",
        "date1": "2026-03-17", "date2": "2026-03-17",
        "version": "QY-JY-2026-A1",
        "product": "某即食产品",
        "temp": "中心温度85℃以上出锅", "cool": "冷却至10℃以下",
        "cold": "冷藏库内温度0-8℃", "conc": "消毒液浓度200ppm",
        "thaw": "原料解冻时长20h",
    }


def render(path, c):
    d = Document()
    d.add_heading(c["title"], 0)
    d.add_paragraph(f"报告编号：{c['version']}")
    d.add_paragraph(f"检验日期：{c['date1']}")
    d.add_paragraph(f"复核日期：{c['date2']}")
    d.add_paragraph(f"产品名称：{c['product']}")
    d.add_heading("一、检验项目", level=1)
    d.add_paragraph(f"1. 加热工艺：{c['temp']}，{c['cool']}。")
    d.add_paragraph(f"2. 贮存条件：{c['cold']}。")
    d.add_paragraph(f"3. 卫生控制：{c['conc']}。")
    d.add_paragraph(f"4. 原料处理：{c['thaw']}。")
    d.add_heading("二、结论", level=1)
    d.add_paragraph("上述项目检验合格。")
    d.save(path)


def inject(c, problem):
    c = dict(c)
    problem(c)
    return c


PROBLEMS = [
    ("日期不一致", lambda c: c.update(date2="2026-04-01"), "F-日期"),
    ("版本号X", lambda c: c.update(version="X"), "F-版本"),
    ("中心温度偏低", lambda c: c.update(temp="中心温度70℃出锅"), "F-中心温度"),
    ("冷却温度超标", lambda c: c.update(cool="冷却至15℃"), "F-冷却"),
    ("冷藏温度超标", lambda c: c.update(cold="冷藏库内温度12℃"), "F-冷藏"),
    ("消毒浓度偏低", lambda c: c.update(conc="消毒液浓度150ppm"), "F-消毒"),
    ("解冻时长不足", lambda c: c.update(thaw="原料解冻时长15h"), "F-解冻"),
]


def main():
    random.seed(7)
    tmp = tempfile.mkdtemp(prefix="rp_docx_")
    detect = defaultdict(lambda: {"hit": 0, "total": 0})
    total = 0
    for di in range(N_DOCS):
        chosen = random.sample(PROBLEMS, K_PROBLEMS)
        for name, fn, expect in chosen:
            total += 1
            detect[name]["total"] += 1
            c = inject(base_doc(), fn)
            p = os.path.join(tmp, f"d{di}_{name}.docx")
            render(p, c)
            got = [f["id"] for f in factreview.review_document(p)["findings"]]
            if expect in got:
                detect[name]["hit"] += 1

    # 干净文档误报
    fp = 0
    for i in range(10):
        p = os.path.join(tmp, f"clean{i}.docx")
        render(p, base_doc())
        if factreview.review_document(p)["findings"]:
            fp += 1

    print(f"{'问题点':14} {'审出/总数':10} {'审出率'}")
    print("-" * 44)
    hits = 0
    for name, d in sorted(detect.items(), key=lambda x: -x[1]["hit"] / max(x[1]["total"], 1)):
        hits += d["hit"]
        print(f"{name:14} {d['hit']:2}/{d['total']:<8} {d['hit']/max(d['total'],1)*100:4.0f}%")
    print("-" * 44)
    print(f"量级：{N_DOCS} 份专业文件 × {K_PROBLEMS} 问题 = {total} 实例")
    print(f"审出：{hits}/{total}（{hits/max(total,1)*100:.0f}%）｜干净文档误报 {fp}/10")
    return 0


if __name__ == "__main__":
    sys.exit(main())
