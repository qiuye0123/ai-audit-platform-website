# -*- coding: utf-8 -*-
"""格式鲁棒性测试（防作弊）：同一个「中心温度70℃超标」问题，换 10 种真实写法，
看规则是否都能识别。若只在注入格式上命中，说明"作弊"（规则只认测试格式）。
"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from docx import Document  # noqa: E402
from app.engine import factreview  # noqa: E402

OUT = tempfile.mkdtemp(prefix="rp_fmt_")

# 同一问题（中心温度70℃，应<85判违规）的不同真实写法
VARIANTS = [
    ("标准", "中心温度70℃"),
    ("空格", "中心温度 70 ℃"),
    ("°C 写法", "中心温度70°C"),
    ("“度”字", "中心温度70度"),
    ("为字", "中心温度为70℃"),
    ("表格管道", "中心温度 | 70 | ℃"),
    ("冒号", "中心温度：70℃"),
    ("全角数字", "中心温度７０℃"),
    ("同义词(加热终温)", "加热终温70℃"),
    ("范围写法", "中心温度60-70℃"),
    ("括号", "中心温度（70℃）"),
    ("无对象词", "70℃"),
]


def run(text):
    p = os.path.join(OUT, "t.docx")
    d = Document(); d.add_paragraph(f"加热工艺：{text}出锅。"); d.save(p)
    fs = factreview.review_document(p)["findings"]
    return [f["id"] for f in fs]


def main():
    hit = 0
    for name, text in VARIANTS:
        got = run(text)
        ok = "F-中心温度" in got
        hit += ok
        print(f"{'✅' if ok else '❌'} {name:14} 「{text}」 → {got or '未识别'}")
    print(f"\n格式鲁棒性：{hit}/{len(VARIANTS)}（{hit/len(VARIANTS)*100:.0f}%）")
    print("未命中的格式 = 真实文档里会漏报的写法（诚实暴露）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
