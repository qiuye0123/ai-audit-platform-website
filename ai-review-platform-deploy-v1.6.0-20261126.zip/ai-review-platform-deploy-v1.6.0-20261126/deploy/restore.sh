#!/usr/bin/env bash
# 恢复数据库（先停服务，自动保留当前库）；用法：sudo bash deploy/restore.sh <backup.db>
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "请用 root/sudo 运行"; exit 1; }
DB="$1"; ROOT="/opt/ruleproof"
[ -f "$DB" ] || { echo "备份不存在：$DB"; exit 1; }
systemctl stop ai-review 2>/dev/null || true
KEEP="$ROOT/backups/pre-restore-$(date +%Y%m%d_%H%M%S).db"
cp -a "$ROOT/data/ruleproof.db" "$KEEP" 2>/dev/null || true
cp -a "$DB" "$ROOT/data/ruleproof.db"
chown ruleproof:ruleproof "$ROOT/data/ruleproof.db"
systemctl start ai-review 2>/dev/null || true
sleep 3
curl -fsS http://127.0.0.1:8765/health >/dev/null && echo "恢复完成；原库保留：$KEEP" || { echo "健康检查 FAIL"; exit 1; }
