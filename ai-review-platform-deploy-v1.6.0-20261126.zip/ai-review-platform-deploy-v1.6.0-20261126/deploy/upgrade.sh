#!/usr/bin/env bash
# 升级代码（保留 data/.env.production）；用法：sudo bash deploy/upgrade.sh <新版本目录>
set -euo pipefail
SRC="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
DEST="/opt/ruleproof"
[ "$(id -u)" -eq 0 ] || { echo "请用 root/sudo 运行"; exit 1; }
[ -f "$DEST/.env.production" ] || { echo "未安装：$DEST"; exit 1; }
BACKUP="$DEST/backups/upgrade-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$DEST/data" "$BACKUP/data"
rsync -a --delete \
  --exclude '.git' --exclude 'dist' --exclude '__pycache__' --exclude '*.pyc' \
  --exclude '.env' --exclude '.env.production' --exclude 'data' --exclude '.venv' \
  "$SRC"/ "$DEST"/
"$DEST/.venv/bin/pip" install --no-cache-dir -r "$DEST/requirements.txt"
/systemctl restart ai-review 2>/dev/null || systemctl restart ai-review
sleep 3
curl -fsS "http://127.0.0.1:8765/health" >/dev/null && echo "升级完成，健康检查 PASS；备份：$BACKUP" || { echo "健康检查 FAIL，请用 $BACKUP 回滚"; exit 1; }
