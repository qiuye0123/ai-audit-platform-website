#!/usr/bin/env bash
# 部署后冒烟：健康、登录、两个默认空间、项目列表、CLI。无登录密码时只跑健康。
set -uo pipefail
BASE="${1:-http://127.0.0.1:8765}"
PHONE="${ADMIN_PHONE:-13800000000}"
PASS="${ADMIN_PASSWORD:-}"
fail=0
say(){ printf '%s\n' "$*"; }
say "1) /health"; curl -fsS --max-time 5 "$BASE/health" >/dev/null && say PASS || { say FAIL; fail=1; }
if [ -z "$PASS" ]; then say "跳过登录/空间检查：未提供 ADMIN_PASSWORD"; exit $fail; fi
JAR="$(mktemp)"
say "2) 管理员登录"
LOGIN="$(curl -sS --max-time 10 -c "$JAR" -H 'Content-Type: application/json' \
  -d "{\"account\":\"$PHONE\",\"password\":\"$PASS\"}" "$BASE/api/v1/auth/login")"
echo "$LOGIN" | grep -q '"user"' && say PASS || { say "FAIL: $LOGIN"; fail=1; }
# 首次登录/临时密码：需要先改密才能访问业务接口；如提供 ADMIN_NEW_PASSWORD 则自动完成。
NEWPASS="${ADMIN_NEW_PASSWORD:-}"
if echo "$LOGIN" | grep -q '"must_change_pwd": true'; then
  if [ -n "$NEWPASS" ]; then
    say "2b) 首次登录改密"
    CH="$(curl -sS --max-time 10 -b "$JAR" -c "$JAR" -H 'Content-Type: application/json' \
      -d "{\"old_password\":\"$PASS\",\"new_password\":\"$NEWPASS\"}" "$BASE/api/v1/me/password")"
    echo "$CH" | grep -q '"ok"' && { say PASS; PASS="$NEWPASS"; } || { say "FAIL: $CH"; fail=1; }
  else
    say "WARN 首次登录需改密，未提供 ADMIN_NEW_PASSWORD；跳过空间检查"
    rm -f "$JAR"; exit $fail
  fi
fi
say "3) 默认工作空间"
WS="$(curl -sS --max-time 10 -b "$JAR" "$BASE/api/v1/workspaces")"
for name in '通用工作空间' '食品工艺书'; do
  echo "$WS" | grep -q "$name" && say "PASS $name" || { say "FAIL 缺少 $name"; fail=1; }
done
say "4) 项目列表"; curl -sS --max-time 10 -b "$JAR" "$BASE/api/v1/projects" | grep -q '"items"' && say PASS || { say FAIL; fail=1; }
say "5) CLI"; ROOT="$(cd "$(dirname "$0")/.." && pwd)"; if [ -x "$ROOT/rp" ]; then "$ROOT/rp" --help >/dev/null 2>&1 && say PASS || { say FAIL; fail=1; }; else say SKIP; fi
rm -f "$JAR"
[ "$fail" -eq 0 ] && say "SMOKE: PASS" || say "SMOKE: FAIL"
exit $fail
