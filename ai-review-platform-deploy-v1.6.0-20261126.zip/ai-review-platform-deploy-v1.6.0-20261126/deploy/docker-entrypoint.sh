#!/usr/bin/env bash
# AI 审核平台容器入口：首次启动自动建库/迁移/种子，然后启动 HTTP 服务。
set -euo pipefail
cd "$(dirname "$0")/.."
export RULEPROOF_HOST="${RULEPROOF_HOST:-0.0.0.0}"
export RULEPROOF_PORT="${RULEPROOF_PORT:-8765}"
export RULEPROOF_DB="${RULEPROOF_DB:-/app/data/ruleproof.db}"
export RULEPROOF_ENV="${RULEPROOF_ENV:-prod}"
mkdir -p "$(dirname "$RULEPROOF_DB")"
if [ ! -s "$RULEPROOF_DB" ]; then
  echo "[entrypoint] 首次启动：初始化数据库并写入默认工作空间（通用工作空间/食品工艺书）"
  # 云服务器默认演示内容；如要空生产库，把 RULEPROOF_SEED_DEMO=0 并在部署前清空 data/
  RULEPROOF_SEED_DEMO="${RULEPROOF_SEED_DEMO:-1}" \
  RULEPROOF_ADMIN_PASSWORD="${RULEPROOF_ADMIN_PASSWORD:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(18))')}" \
    python3 seed.py
fi
exec python3 app/api/server.py
