#!/usr/bin/env bash
# 备份数据库 + 上传/知识库文件；加密备份：备份目录放加密盘，不要把密钥放同机。
set -euo pipefail
ROOT="${1:-/opt/ruleproof}"
OUT="${2:-$ROOT/backups}"
TS="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"
DB="$ROOT/data/ruleproof.db"
[ -f "$DB" ] || { echo "数据库不存在：$DB"; exit 1; }
PY="${RULEPROOF_PYTHON:-}"
if [ -z "$PY" ]; then
  if [ -x "$ROOT/.venv/bin/python" ]; then PY="$ROOT/.venv/bin/python"; else PY="$(command -v python3)"; fi
fi
[ -n "$PY" ] || { echo "找不到 Python3"; exit 1; }
# SQLite 在线一致性备份
ROOT="$ROOT" DB="$DB" OUT="$OUT/ruleproof-$TS.db" "$PY" - <<'PY'
import os,sqlite3
src=sqlite3.connect(os.environ["DB"]); dst=sqlite3.connect(os.environ["OUT"])
with dst: src.backup(dst)
dst.close(); src.close()
PY
tar -czf "$OUT/ruleproof-files-$TS.tar.gz" -C "$ROOT/data" uploads knowledge 2>/dev/null || true
sha256sum "$OUT"/ruleproof-"$TS".db "$OUT"/ruleproof-files-"$TS".tar.gz > "$OUT/SHA256-$TS.txt" 2>/dev/null || true
echo "备份完成：$OUT/ruleproof-$TS.db"; cat "$OUT/SHA256-$TS.txt" 2>/dev/null || true
