#!/usr/bin/env bash
# 裸机/云服务器安装（Ubuntu 22.04+/Debian 12+；需 root）
# 用法：sudo bash deploy/install-baremetal.sh
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
DEST="/opt/ruleproof"
if [ "$(id -u)" -ne 0 ]; then echo "请用 root/sudo 运行"; exit 1; fi
if [ -d "$DEST" ] && [ -f "$DEST/app/api/server.py" ]; then
  echo "检测到已有安装 $DEST；升级请用 deploy/upgrade.sh，不要重复安装"; exit 2
fi
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' 2>/dev/null; then PY="$(command -v "$c")"; break; fi
done
[ -n "$PY" ] || { echo "需要 Python 3.10+（apt install python3 python3-venv）"; exit 1; }
command -v rsync >/dev/null || { echo "需要 rsync（apt install rsync）"; exit 1; }
id ruleproof >/dev/null 2>&1 || useradd --system --home "$DEST" --shell /usr/sbin/nologin ruleproof
mkdir -p "$DEST"
rsync -a --delete \
  --exclude '.git' --exclude 'dist' --exclude '__pycache__' --exclude '*.pyc' \
  --exclude '.env' --exclude '.env.production' --exclude 'data/*.db-wal' --exclude 'data/*.db-shm' \
  "$SRC"/ "$DEST"/
mkdir -p "$DEST/data"
"$PY" -m venv "$DEST/.venv"
"$DEST/.venv/bin/pip" install --no-cache-dir -U pip >/dev/null
"$DEST/.venv/bin/pip" install --no-cache-dir -r "$DEST/requirements.txt"
if [ ! -f "$DEST/.env.production" ]; then
  cp "$DEST/deploy/.env.production.example" "$DEST/.env.production"
  SECRET="$("$DEST/.venv/bin/python" -c 'import secrets;print(secrets.token_urlsafe(32))')"
  ADMIN_PWD="$("$DEST/.venv/bin/python" -c 'import secrets;print(secrets.token_urlsafe(14))')"
  "$DEST/.venv/bin/python" - "$DEST/.env.production" "$SECRET" "$ADMIN_PWD" <<'PY'
import sys,pathlib
p=pathlib.Path(sys.argv[1]); s=p.read_text()
s=s.replace('CHANGE_ME_SESSION_SECRET',sys.argv[2]).replace('CHANGE_ME_ADMIN_PASSWORD',sys.argv[3])
s=s.replace('RULEPROOF_DB=/opt/ruleproof/data/ruleproof.db','RULEPROOF_DB=/opt/ruleproof/data/ruleproof.db')
p.write_text(s)
PY
  chmod 600 "$DEST/.env.production"
  echo "已生成 $DEST/.env.production"
  echo "系统管理员初始密码：$ADMIN_PWD （首次登录强制改密；只显示这一次，请立即保存）"
fi
# 首次建库（带演示内容：通用工作空间/食品工艺书）；生产空库可把 RULEPROOF_SEED_DEMO 改 0
set -a; . "$DEST/.env.production"; set +a
export RULEPROOF_ENV=prod RULEPROOF_DB=/opt/ruleproof/data/ruleproof.db
export RULEPROOF_SEED_DEMO="${RULEPROOF_SEED_DEMO:-1}"
"$DEST/.venv/bin/python" "$DEST/seed.py"
chown -R ruleproof:ruleproof "$DEST/data" "$DEST/.env.production"
chmod 750 "$DEST/data"
install -m 0644 "$DEST/deploy/systemd/ai-review.service" /etc/systemd/system/ai-review.service
systemctl daemon-reload
systemctl enable --now ai-review
sleep 3
systemctl --no-pager --full status ai-review | head -20 || true
echo "部署完成。健康检查：curl -fsS http://127.0.0.1:8765/health"
echo "下一步：配置 Nginx/TLS（deploy/nginx/ai-review.conf），再跑 deploy/smoke-test.sh"
