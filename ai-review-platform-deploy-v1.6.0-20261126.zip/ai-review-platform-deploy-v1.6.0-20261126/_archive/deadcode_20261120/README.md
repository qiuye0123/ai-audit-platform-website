# 死代码归档（T-200 / 2026-11-20）

本目录只留本地、**不进 git、不进产品包**（`.gitignore: _archive/`），用于保留被删除代码的可复原副本。

| 归档文件 | 原路径 | 行数 | 删除依据 |
|---|---|---:|---|
| `app/services/lab_l4.py` | `platform/app/services/lab_l4.py` | 15 | S5 死模块；`app/` 零 import、CLI/HTTP 零入口、测试零引用（全仓仅 docs 提及）；见 `docs/qa/死代码死开关死表决定清单_20261120.md` §1 |

恢复方式：把文件放回原路径即可（其依赖 `lab_l2` 仍在 `app/services/`）。
