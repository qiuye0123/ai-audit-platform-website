"""L4：Jev 仅记录与排序（不参与放行/过滤），验证召回与精确率不变。"""
from . import lab_l2


def _conf(f: dict) -> float:
    # 简化：决定性要素缺失 → 0.6；否则 0.85
    return 0.6 if f.get("decisive_missing") else 0.85


def l4_judge(path: str, limit: int = 20) -> dict:
    r = lab_l2.l2_judge(path, limit=limit)
    for f in r["findings"]:
        f["confidence"] = _conf(f)
    r["findings"].sort(key=lambda x: -float(x.get("confidence") or 0))
    return r
