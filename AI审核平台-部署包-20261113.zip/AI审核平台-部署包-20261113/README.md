# AI 审核平台官网

静态多页官网，无构建依赖。

## 页面

- `index.html`：产品功能首页，包含痛点、执行流程与内嵌页面、平台架构、对比优势、超级 AI 规则引擎、预制规则类型库、AI 证据链与产品功能总表
- `ai.html`：AI 能力，包含 AI 架构、解析、本体、规则、智能体、JEV、RSI 与 AI 质量评测
- `cases.html`：三个客户案例
- `404.html`：错误页

## 目录

- `assets/css`：全站样式
- `assets/js/site.js`：导航、渐入、执行轨迹、FAQ
- `assets/img`：图标、favicon 与社交分享图
- `sitemap.xml`、`robots.txt`、`llms.txt`、`site.webmanifest`：抓取与 GEO 文件

## 本地预览

```bash
cd website
python3 -m http.server 8899
```

打开 `http://127.0.0.1:8899/`。

## SEO / GEO

- 4 个可索引页面均有唯一标题、描述、canonical、hreflang、Open Graph 与 Twitter Card
- JSON-LD 覆盖 Organization、WebSite、SoftwareApplication、WebPage、BreadcrumbList 与 DefinedTermSet
- `llms.txt` 面向生成式引擎提供五态、能力、边界与页面索引
- 上线前替换 `ruleproof.example`、公司信息与商务邮箱

详见 `SEO-GEO-优化说明.md`。
